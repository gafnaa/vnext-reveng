// lib: , url: package:flutter/src/cupertino/button.dart

// class id: 1048771, size: 0x8
class :: {
}

// class id: 5606, size: 0x38, field offset: 0x1c
class _CupertinoButtonState extends _MixinApplication385&State&SingleTickerProviderStateMixin {

  late AnimationController _animationController; // offset: 0x20
  static late final WidgetStateProperty<MouseCursor> _defaultCursor; // offset: 0x9b0
  late final Map<Type, Action<Intent>> _actionMap; // offset: 0x34
  late bool isFocused; // offset: 0x28
  late Animation<double> _opacityAnimation; // offset: 0x24

  _ build(/* No info */) {
    // ** addr: 0xd743e4, size: 0xa0c
    // 0xd743e4: EnterFrame
    //     0xd743e4: stp             fp, lr, [SP, #-0x10]!
    //     0xd743e8: mov             fp, SP
    // 0xd743ec: AllocStack(0x90)
    //     0xd743ec: sub             SP, SP, #0x90
    // 0xd743f0: SetupParameters(_CupertinoButtonState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xd743f0: mov             x0, x1
    //     0xd743f4: stur            x1, [fp, #-8]
    //     0xd743f8: mov             x1, x2
    //     0xd743fc: stur            x2, [fp, #-0x10]
    // 0xd74400: CheckStackOverflow
    //     0xd74400: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd74404: cmp             SP, x16
    //     0xd74408: b.ls            #0xd74d44
    // 0xd7440c: r1 = 3
    //     0xd7440c: mov             x1, #3
    // 0xd74410: r0 = AllocateContext()
    //     0xd74410: bl              #0x13de838  ; AllocateContextStub
    // 0xd74414: ldur            x1, [fp, #-8]
    // 0xd74418: stur            x0, [fp, #-0x18]
    // 0xd7441c: StoreField: r0->field_f = r1
    //     0xd7441c: stur            w1, [x0, #0xf]
    // 0xd74420: LoadField: r2 = r1->field_b
    //     0xd74420: ldur            w2, [x1, #0xb]
    // 0xd74424: DecompressPointer r2
    //     0xd74424: add             x2, x2, HEAP, lsl #32
    // 0xd74428: cmp             w2, NULL
    // 0xd7442c: b.eq            #0xd74d4c
    // 0xd74430: r3 = true
    //     0xd74430: add             x3, NULL, #0x20  ; true
    // 0xd74434: StoreField: r0->field_13 = r3
    //     0xd74434: stur            w3, [x0, #0x13]
    // 0xd74438: LoadField: r4 = r2->field_27
    //     0xd74438: ldur            w4, [x2, #0x27]
    // 0xd7443c: DecompressPointer r4
    //     0xd7443c: add             x4, x4, HEAP, lsl #32
    // 0xd74440: cmp             w4, NULL
    // 0xd74444: b.ne            #0xd74450
    // 0xd74448: r0 = Null
    //     0xd74448: mov             x0, NULL
    // 0xd7444c: b               #0xd74468
    // 0xd74450: LoadField: d0 = r4->field_7
    //     0xd74450: ldur            d0, [x4, #7]
    // 0xd74454: stur            d0, [fp, #-0x70]
    // 0xd74458: r0 = Size()
    //     0xd74458: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xd7445c: ldur            d0, [fp, #-0x70]
    // 0xd74460: StoreField: r0->field_7 = d0
    //     0xd74460: stur            d0, [x0, #7]
    // 0xd74464: StoreField: r0->field_f = d0
    //     0xd74464: stur            d0, [x0, #0xf]
    // 0xd74468: ldur            x1, [fp, #-0x10]
    // 0xd7446c: stur            x0, [fp, #-0x20]
    // 0xd74470: r0 = of()
    //     0xd74470: bl              #0xccc364  ; [package:flutter/src/cupertino/theme.dart] CupertinoTheme::of
    // 0xd74474: stur            x0, [fp, #-0x30]
    // 0xd74478: r1 = LoadClassIdInstr(r0)
    //     0xd74478: ldur            x1, [x0, #-1]
    //     0xd7447c: ubfx            x1, x1, #0xc, #0x14
    // 0xd74480: r17 = 4617
    //     0xd74480: mov             x17, #0x1209
    // 0xd74484: cmp             x1, x17
    // 0xd74488: b.ne            #0xd744a4
    // 0xd7448c: LoadField: r1 = r0->field_27
    //     0xd7448c: ldur            w1, [x0, #0x27]
    // 0xd74490: DecompressPointer r1
    //     0xd74490: add             x1, x1, HEAP, lsl #32
    // 0xd74494: LoadField: r2 = r1->field_b
    //     0xd74494: ldur            w2, [x1, #0xb]
    // 0xd74498: DecompressPointer r2
    //     0xd74498: add             x2, x2, HEAP, lsl #32
    // 0xd7449c: mov             x4, x2
    // 0xd744a0: b               #0xd744c0
    // 0xd744a4: LoadField: r1 = r0->field_2b
    //     0xd744a4: ldur            w1, [x0, #0x2b]
    // 0xd744a8: DecompressPointer r1
    //     0xd744a8: add             x1, x1, HEAP, lsl #32
    // 0xd744ac: LoadField: r2 = r1->field_3f
    //     0xd744ac: ldur            w2, [x1, #0x3f]
    // 0xd744b0: DecompressPointer r2
    //     0xd744b0: add             x2, x2, HEAP, lsl #32
    // 0xd744b4: LoadField: r1 = r2->field_b
    //     0xd744b4: ldur            w1, [x2, #0xb]
    // 0xd744b8: DecompressPointer r1
    //     0xd744b8: add             x1, x1, HEAP, lsl #32
    // 0xd744bc: mov             x4, x1
    // 0xd744c0: ldur            x3, [fp, #-8]
    // 0xd744c4: stur            x4, [fp, #-0x28]
    // 0xd744c8: LoadField: r1 = r3->field_b
    //     0xd744c8: ldur            w1, [x3, #0xb]
    // 0xd744cc: DecompressPointer r1
    //     0xd744cc: add             x1, x1, HEAP, lsl #32
    // 0xd744d0: cmp             w1, NULL
    // 0xd744d4: b.eq            #0xd74d50
    // 0xd744d8: LoadField: r2 = r1->field_13
    //     0xd744d8: ldur            w2, [x1, #0x13]
    // 0xd744dc: DecompressPointer r2
    //     0xd744dc: add             x2, x2, HEAP, lsl #32
    // 0xd744e0: cmp             w2, NULL
    // 0xd744e4: b.ne            #0xd744f0
    // 0xd744e8: r2 = Null
    //     0xd744e8: mov             x2, NULL
    // 0xd744ec: b               #0xd74500
    // 0xd744f0: mov             x1, x2
    // 0xd744f4: ldur            x2, [fp, #-0x10]
    // 0xd744f8: r0 = resolve()
    //     0xd744f8: bl              #0xce150c  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolve
    // 0xd744fc: mov             x2, x0
    // 0xd74500: stur            x2, [fp, #-0x38]
    // 0xd74504: cmp             w2, NULL
    // 0xd74508: b.ne            #0xd74514
    // 0xd7450c: r3 = Null
    //     0xd7450c: mov             x3, NULL
    // 0xd74510: b               #0xd745b0
    // 0xd74514: ldur            x3, [fp, #-8]
    // 0xd74518: LoadField: r0 = r3->field_b
    //     0xd74518: ldur            w0, [x3, #0xb]
    // 0xd7451c: DecompressPointer r0
    //     0xd7451c: add             x0, x0, HEAP, lsl #32
    // 0xd74520: cmp             w0, NULL
    // 0xd74524: b.eq            #0xd74d54
    // 0xd74528: LoadField: r1 = r0->field_13
    //     0xd74528: ldur            w1, [x0, #0x13]
    // 0xd7452c: DecompressPointer r1
    //     0xd7452c: add             x1, x1, HEAP, lsl #32
    // 0xd74530: cmp             w1, NULL
    // 0xd74534: b.ne            #0xd74540
    // 0xd74538: r0 = Null
    //     0xd74538: mov             x0, NULL
    // 0xd7453c: b               #0xd74580
    // 0xd74540: r0 = LoadClassIdInstr(r1)
    //     0xd74540: ldur            x0, [x1, #-1]
    //     0xd74544: ubfx            x0, x0, #0xc, #0x14
    // 0xd74548: r0 = GDT[cid_x0 + -0xfab]()
    //     0xd74548: sub             lr, x0, #0xfab
    //     0xd7454c: ldr             lr, [x21, lr, lsl #3]
    //     0xd74550: blr             lr
    // 0xd74554: r0 = inline_Allocate_Double()
    //     0xd74554: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xd74558: add             x0, x0, #0x10
    //     0xd7455c: cmp             x1, x0
    //     0xd74560: b.ls            #0xd74d58
    //     0xd74564: str             x0, [THR, #0x60]  ; THR::top
    //     0xd74568: sub             x0, x0, #0xf
    //     0xd7456c: mov             x1, #0xe19c
    //     0xd74570: movk            x1, #3, lsl #16
    //     0xd74574: stur            x1, [x0, #-1]
    // 0xd74578: dmb             ishst
    // 0xd7457c: StoreField: r0->field_7 = d0
    //     0xd7457c: stur            d0, [x0, #7]
    // 0xd74580: cmp             w0, NULL
    // 0xd74584: b.ne            #0xd74590
    // 0xd74588: d0 = 1.000000
    //     0xd74588: fmov            d0, #1.00000000
    // 0xd7458c: b               #0xd74594
    // 0xd74590: LoadField: d0 = r0->field_7
    //     0xd74590: ldur            d0, [x0, #7]
    // 0xd74594: ldur            x1, [fp, #-0x38]
    // 0xd74598: r0 = LoadClassIdInstr(r1)
    //     0xd74598: ldur            x0, [x1, #-1]
    //     0xd7459c: ubfx            x0, x0, #0xc, #0x14
    // 0xd745a0: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd745a0: sub             lr, x0, #1, lsl #12
    //     0xd745a4: ldr             lr, [x21, lr, lsl #3]
    //     0xd745a8: blr             lr
    // 0xd745ac: mov             x3, x0
    // 0xd745b0: ldur            x2, [fp, #-8]
    // 0xd745b4: stur            x3, [fp, #-0x38]
    // 0xd745b8: LoadField: r0 = r2->field_b
    //     0xd745b8: ldur            w0, [x2, #0xb]
    // 0xd745bc: DecompressPointer r0
    //     0xd745bc: add             x0, x0, HEAP, lsl #32
    // 0xd745c0: cmp             w0, NULL
    // 0xd745c4: b.eq            #0xd74d68
    // 0xd745c8: cmp             w3, NULL
    // 0xd745cc: b.ne            #0xd745dc
    // 0xd745d0: r1 = Instance_CupertinoDynamicColor
    //     0xd745d0: add             x1, PP, #0xac, lsl #12  ; [pp+0xacc58] Obj!CupertinoDynamicColor@12b37f1
    //     0xd745d4: ldr             x1, [x1, #0xc58]
    // 0xd745d8: b               #0xd745e0
    // 0xd745dc: mov             x1, x3
    // 0xd745e0: r0 = LoadClassIdInstr(r1)
    //     0xd745e0: ldur            x0, [x1, #-1]
    //     0xd745e4: ubfx            x0, x0, #0xc, #0x14
    // 0xd745e8: d0 = 0.800000
    //     0xd745e8: add             x17, PP, #0x13, lsl #12  ; [pp+0x13a58] IMM: double(0.8) from 0x3fe999999999999a
    //     0xd745ec: ldr             d0, [x17, #0xa58]
    // 0xd745f0: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd745f0: sub             lr, x0, #1, lsl #12
    //     0xd745f4: ldr             lr, [x21, lr, lsl #3]
    //     0xd745f8: blr             lr
    // 0xd745fc: mov             x2, x0
    // 0xd74600: r1 = Null
    //     0xd74600: mov             x1, NULL
    // 0xd74604: r0 = HSLColor.fromColor()
    //     0xd74604: bl              #0xd43b8c  ; [package:flutter/src/painting/colors.dart] HSLColor::HSLColor.fromColor
    // 0xd74608: mov             x1, x0
    // 0xd7460c: r0 = withLightness()
    //     0xd7460c: bl              #0xd43b34  ; [package:flutter/src/painting/colors.dart] HSLColor::withLightness
    // 0xd74610: mov             x1, x0
    // 0xd74614: r0 = withSaturation()
    //     0xd74614: bl              #0xd43ad0  ; [package:flutter/src/painting/colors.dart] HSLColor::withSaturation
    // 0xd74618: mov             x1, x0
    // 0xd7461c: r0 = toColor()
    //     0xd7461c: bl              #0xd43270  ; [package:flutter/src/painting/colors.dart] HSLColor::toColor
    // 0xd74620: mov             x2, x0
    // 0xd74624: ldur            x0, [fp, #-8]
    // 0xd74628: stur            x2, [fp, #-0x40]
    // 0xd7462c: LoadField: r1 = r0->field_b
    //     0xd7462c: ldur            w1, [x0, #0xb]
    // 0xd74630: DecompressPointer r1
    //     0xd74630: add             x1, x1, HEAP, lsl #32
    // 0xd74634: cmp             w1, NULL
    // 0xd74638: b.eq            #0xd74d6c
    // 0xd7463c: ldur            x1, [fp, #-0x30]
    // 0xd74640: r0 = textTheme()
    //     0xd74640: bl              #0x1282dd4  ; [package:flutter/src/cupertino/theme.dart] CupertinoThemeData::textTheme
    // 0xd74644: mov             x1, x0
    // 0xd74648: r0 = actionTextStyle()
    //     0xd74648: bl              #0xd74e58  ; [package:flutter/src/cupertino/text_theme.dart] CupertinoTextThemeData::actionTextStyle
    // 0xd7464c: ldur            x16, [fp, #-0x28]
    // 0xd74650: str             x16, [SP]
    // 0xd74654: mov             x1, x0
    // 0xd74658: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0xd74658: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0xd7465c: ldr             x4, [x4, #0x7f0]
    // 0xd74660: r0 = copyWith()
    //     0xd74660: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xd74664: ldur            x1, [fp, #-0x10]
    // 0xd74668: stur            x0, [fp, #-0x30]
    // 0xd7466c: r0 = of()
    //     0xd7466c: bl              #0xd0e004  ; [package:flutter/src/widgets/icon_theme.dart] IconTheme::of
    // 0xd74670: ldur            x2, [fp, #-0x30]
    // 0xd74674: LoadField: r1 = r2->field_1f
    //     0xd74674: ldur            w1, [x2, #0x1f]
    // 0xd74678: DecompressPointer r1
    //     0xd74678: add             x1, x1, HEAP, lsl #32
    // 0xd7467c: cmp             w1, NULL
    // 0xd74680: b.eq            #0xd7469c
    // 0xd74684: d0 = 1.200000
    //     0xd74684: add             x17, PP, #0x1f, lsl #12  ; [pp+0x1f208] IMM: double(1.2) from 0x3ff3333333333333
    //     0xd74688: ldr             d0, [x17, #0x208]
    // 0xd7468c: LoadField: d1 = r1->field_7
    //     0xd7468c: ldur            d1, [x1, #7]
    // 0xd74690: fmul            d2, d1, d0
    // 0xd74694: mov             v0.16b, v2.16b
    // 0xd74698: b               #0xd746a0
    // 0xd7469c: d0 = 20.000000
    //     0xd7469c: fmov            d0, #20.00000000
    // 0xd746a0: ldur            x3, [fp, #-8]
    // 0xd746a4: ldur            x4, [fp, #-0x18]
    // 0xd746a8: r1 = inline_Allocate_Double()
    //     0xd746a8: ldp             x1, x5, [THR, #0x60]  ; THR::top
    //     0xd746ac: add             x1, x1, #0x10
    //     0xd746b0: cmp             x5, x1
    //     0xd746b4: b.ls            #0xd74d70
    //     0xd746b8: str             x1, [THR, #0x60]  ; THR::top
    //     0xd746bc: sub             x1, x1, #0xf
    //     0xd746c0: mov             x5, #0xe19c
    //     0xd746c4: movk            x5, #3, lsl #16
    //     0xd746c8: stur            x5, [x1, #-1]
    // 0xd746cc: dmb             ishst
    // 0xd746d0: StoreField: r1->field_7 = d0
    //     0xd746d0: stur            d0, [x1, #7]
    // 0xd746d4: r5 = LoadClassIdInstr(r0)
    //     0xd746d4: ldur            x5, [x0, #-1]
    //     0xd746d8: ubfx            x5, x5, #0xc, #0x14
    // 0xd746dc: ldur            x16, [fp, #-0x28]
    // 0xd746e0: stp             x1, x16, [SP]
    // 0xd746e4: mov             x1, x0
    // 0xd746e8: mov             x0, x5
    // 0xd746ec: r4 = const [0, 0x3, 0x2, 0x1, color, 0x1, size, 0x2, null]
    //     0xd746ec: add             x4, PP, #0xac, lsl #12  ; [pp+0xacc60] List(9) [0, 0x3, 0x2, 0x1, "color", 0x1, "size", 0x2, Null]
    //     0xd746f0: ldr             x4, [x4, #0xc60]
    // 0xd746f4: r0 = GDT[cid_x0 + -0xff8]()
    //     0xd746f4: sub             lr, x0, #0xff8
    //     0xd746f8: ldr             lr, [x21, lr, lsl #3]
    //     0xd746fc: blr             lr
    // 0xd74700: ldur            x1, [fp, #-0x10]
    // 0xd74704: stur            x0, [fp, #-0x10]
    // 0xd74708: r0 = maybeGestureSettingsOf()
    //     0xd74708: bl              #0xd74dfc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::maybeGestureSettingsOf
    // 0xd7470c: ldur            x2, [fp, #-0x18]
    // 0xd74710: ArrayStore: r2[0] = r0  ; List_4
    //     0xd74710: stur            w0, [x2, #0x17]
    //     0xd74714: ldurb           w16, [x2, #-1]
    //     0xd74718: ldurb           w17, [x0, #-1]
    //     0xd7471c: and             x16, x17, x16, lsr #2
    //     0xd74720: tst             x16, HEAP, lsr #32
    //     0xd74724: b.eq            #0xd7472c
    //     0xd74728: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd7472c: r1 = <WidgetState>
    //     0xd7472c: add             x1, PP, #0x84, lsl #12  ; [pp+0x84a10] TypeArguments: <WidgetState>
    //     0xd74730: ldr             x1, [x1, #0xa10]
    // 0xd74734: r0 = _Set()
    //     0xd74734: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0xd74738: mov             x3, x0
    // 0xd7473c: r0 = _Uint32List
    //     0xd7473c: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0xd74740: stur            x3, [fp, #-0x28]
    // 0xd74744: StoreField: r3->field_1b = r0
    //     0xd74744: stur            w0, [x3, #0x1b]
    // 0xd74748: StoreField: r3->field_b = rZR
    //     0xd74748: stur            wzr, [x3, #0xb]
    // 0xd7474c: r0 = const []
    //     0xd7474c: ldr             x0, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0xd74750: StoreField: r3->field_f = r0
    //     0xd74750: stur            w0, [x3, #0xf]
    // 0xd74754: StoreField: r3->field_13 = rZR
    //     0xd74754: stur            wzr, [x3, #0x13]
    // 0xd74758: ArrayStore: r3[0] = rZR  ; List_4
    //     0xd74758: stur            wzr, [x3, #0x17]
    // 0xd7475c: ldur            x0, [fp, #-8]
    // 0xd74760: LoadField: r1 = r0->field_2f
    //     0xd74760: ldur            w1, [x0, #0x2f]
    // 0xd74764: DecompressPointer r1
    //     0xd74764: add             x1, x1, HEAP, lsl #32
    // 0xd74768: tbnz            w1, #4, #0xd7477c
    // 0xd7476c: mov             x1, x3
    // 0xd74770: r2 = Instance_WidgetState
    //     0xd74770: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0xd74774: ldr             x2, [x2, #0xa48]
    // 0xd74778: r0 = add()
    //     0xd74778: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xd7477c: ldur            x0, [fp, #-8]
    // 0xd74780: LoadField: r1 = r0->field_27
    //     0xd74780: ldur            w1, [x0, #0x27]
    // 0xd74784: DecompressPointer r1
    //     0xd74784: add             x1, x1, HEAP, lsl #32
    // 0xd74788: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd7478c: cmp             w1, w16
    // 0xd74790: b.eq            #0xd74d94
    // 0xd74794: tbnz            w1, #4, #0xd747a8
    // 0xd74798: ldur            x1, [fp, #-0x28]
    // 0xd7479c: r2 = Instance_WidgetState
    //     0xd7479c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xd747a0: ldr             x2, [x2, #0xa60]
    // 0xd747a4: r0 = add()
    //     0xd747a4: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xd747a8: ldur            x1, [fp, #-8]
    // 0xd747ac: LoadField: r0 = r1->field_b
    //     0xd747ac: ldur            w0, [x1, #0xb]
    // 0xd747b0: DecompressPointer r0
    //     0xd747b0: add             x0, x0, HEAP, lsl #32
    // 0xd747b4: cmp             w0, NULL
    // 0xd747b8: b.eq            #0xd74da0
    // 0xd747bc: r16 = <MouseCursor?>
    //     0xd747bc: add             x16, PP, #0x15, lsl #12  ; [pp+0x15ab8] TypeArguments: <MouseCursor?>
    //     0xd747c0: ldr             x16, [x16, #0xab8]
    // 0xd747c4: stp             NULL, x16, [SP, #8]
    // 0xd747c8: ldur            x16, [fp, #-0x28]
    // 0xd747cc: str             x16, [SP]
    // 0xd747d0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xd747d0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xd747d4: r0 = resolveAs()
    //     0xd747d4: bl              #0x8de57c  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveAs
    // 0xd747d8: r0 = LoadStaticField(0x9b0)
    //     0xd747d8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xd747dc: ldr             x0, [x0, #0x1360]
    // 0xd747e0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd747e4: cmp             w0, w16
    // 0xd747e8: b.ne            #0xd747f8
    // 0xd747ec: r2 = _defaultCursor
    //     0xd747ec: add             x2, PP, #0xac, lsl #12  ; [pp+0xacc68] Field <_CupertinoButtonState@292145554._defaultCursor@292145554>: static late final (offset: 0x9b0)
    //     0xd747f0: ldr             x2, [x2, #0xc68]
    // 0xd747f4: r0 = InitLateFinalStaticField()
    //     0xd747f4: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xd747f8: mov             x1, x0
    // 0xd747fc: ldur            x2, [fp, #-0x28]
    // 0xd74800: r0 = build()
    //     0xd74800: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xd74804: ldur            x1, [fp, #-8]
    // 0xd74808: stur            x0, [fp, #-0x28]
    // 0xd7480c: LoadField: r2 = r1->field_27
    //     0xd7480c: ldur            w2, [x1, #0x27]
    // 0xd74810: DecompressPointer r2
    //     0xd74810: add             x2, x2, HEAP, lsl #32
    // 0xd74814: tbnz            w2, #4, #0xd74850
    // 0xd74818: ldur            x2, [fp, #-0x40]
    // 0xd7481c: r0 = BorderSide()
    //     0xd7481c: bl              #0x8a73bc  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0xd74820: mov             x1, x0
    // 0xd74824: ldur            x0, [fp, #-0x40]
    // 0xd74828: StoreField: r1->field_7 = r0
    //     0xd74828: stur            w0, [x1, #7]
    // 0xd7482c: d0 = 3.500000
    //     0xd7482c: fmov            d0, #3.50000000
    // 0xd74830: StoreField: r1->field_b = d0
    //     0xd74830: stur            d0, [x1, #0xb]
    // 0xd74834: r0 = Instance_BorderStyle
    //     0xd74834: add             x0, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0xd74838: ldr             x0, [x0, #0xdc8]
    // 0xd7483c: StoreField: r1->field_13 = r0
    //     0xd7483c: stur            w0, [x1, #0x13]
    // 0xd74840: d0 = 1.000000
    //     0xd74840: fmov            d0, #1.00000000
    // 0xd74844: ArrayStore: r1[0] = d0  ; List_8
    //     0xd74844: stur            d0, [x1, #0x17]
    // 0xd74848: mov             x3, x1
    // 0xd7484c: b               #0xd74858
    // 0xd74850: r3 = Instance_BorderSide
    //     0xd74850: add             x3, PP, #0x18, lsl #12  ; [pp+0x18310] Obj!BorderSide@12b1b31
    //     0xd74854: ldr             x3, [x3, #0x310]
    // 0xd74858: ldur            x0, [fp, #-8]
    // 0xd7485c: stur            x3, [fp, #-0x40]
    // 0xd74860: LoadField: r1 = r0->field_b
    //     0xd74860: ldur            w1, [x0, #0xb]
    // 0xd74864: DecompressPointer r1
    //     0xd74864: add             x1, x1, HEAP, lsl #32
    // 0xd74868: cmp             w1, NULL
    // 0xd7486c: b.eq            #0xd74da4
    // 0xd74870: LoadField: r2 = r1->field_37
    //     0xd74870: ldur            w2, [x1, #0x37]
    // 0xd74874: DecompressPointer r2
    //     0xd74874: add             x2, x2, HEAP, lsl #32
    // 0xd74878: cmp             w2, NULL
    // 0xd7487c: b.ne            #0xd74898
    // 0xd74880: r1 = _ConstMap len:3
    //     0xd74880: add             x1, PP, #0xac, lsl #12  ; [pp+0xacc70] Map<CupertinoButtonSize, BorderRadius>(3)
    //     0xd74884: ldr             x1, [x1, #0xc70]
    // 0xd74888: r2 = Instance_CupertinoButtonSize
    //     0xd74888: add             x2, PP, #0x95, lsl #12  ; [pp+0x95fd8] Obj!CupertinoButtonSize@12c6081
    //     0xd7488c: ldr             x2, [x2, #0xfd8]
    // 0xd74890: r0 = []()
    //     0xd74890: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0xd74894: b               #0xd7489c
    // 0xd74898: mov             x0, x2
    // 0xd7489c: cmp             w0, NULL
    // 0xd748a0: b.ne            #0xd748b0
    // 0xd748a4: r4 = Instance_BorderRadius
    //     0xd748a4: add             x4, PP, #0x99, lsl #12  ; [pp+0x99508] Obj!BorderRadius@129e311
    //     0xd748a8: ldr             x4, [x4, #0x508]
    // 0xd748ac: b               #0xd748b4
    // 0xd748b0: mov             x4, x0
    // 0xd748b4: ldur            x1, [fp, #-8]
    // 0xd748b8: ldur            x3, [fp, #-0x20]
    // 0xd748bc: ldur            x2, [fp, #-0x38]
    // 0xd748c0: ldur            x0, [fp, #-0x40]
    // 0xd748c4: stur            x4, [fp, #-0x48]
    // 0xd748c8: r0 = RoundedSuperellipseBorder()
    //     0xd748c8: bl              #0xd74df0  ; AllocateRoundedSuperellipseBorderStub -> RoundedSuperellipseBorder (size=0x10)
    // 0xd748cc: mov             x1, x0
    // 0xd748d0: ldur            x0, [fp, #-0x48]
    // 0xd748d4: stur            x1, [fp, #-0x50]
    // 0xd748d8: StoreField: r1->field_b = r0
    //     0xd748d8: stur            w0, [x1, #0xb]
    // 0xd748dc: ldur            x0, [fp, #-0x40]
    // 0xd748e0: StoreField: r1->field_7 = r0
    //     0xd748e0: stur            w0, [x1, #7]
    // 0xd748e4: r0 = ShapeDecoration()
    //     0xd748e4: bl              #0xb6e288  ; AllocateShapeDecorationStub -> ShapeDecoration (size=0x1c)
    // 0xd748e8: mov             x2, x0
    // 0xd748ec: ldur            x0, [fp, #-0x38]
    // 0xd748f0: stur            x2, [fp, #-0x40]
    // 0xd748f4: StoreField: r2->field_7 = r0
    //     0xd748f4: stur            w0, [x2, #7]
    // 0xd748f8: ldur            x0, [fp, #-0x50]
    // 0xd748fc: ArrayStore: r2[0] = r0  ; List_4
    //     0xd748fc: stur            w0, [x2, #0x17]
    // 0xd74900: ldur            x1, [fp, #-8]
    // 0xd74904: LoadField: r0 = r1->field_33
    //     0xd74904: ldur            w0, [x1, #0x33]
    // 0xd74908: DecompressPointer r0
    //     0xd74908: add             x0, x0, HEAP, lsl #32
    // 0xd7490c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd74910: cmp             w0, w16
    // 0xd74914: b.ne            #0xd74924
    // 0xd74918: r2 = _actionMap
    //     0xd74918: add             x2, PP, #0xac, lsl #12  ; [pp+0xacc78] Field <_CupertinoButtonState@292145554._actionMap@292145554>: late final (offset: 0x34)
    //     0xd7491c: ldr             x2, [x2, #0xc78]
    // 0xd74920: r0 = InitLateFinalInstanceField()
    //     0xd74920: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd74924: ldur            x2, [fp, #-8]
    // 0xd74928: stur            x0, [fp, #-0x38]
    // 0xd7492c: LoadField: r1 = r2->field_b
    //     0xd7492c: ldur            w1, [x2, #0xb]
    // 0xd74930: DecompressPointer r1
    //     0xd74930: add             x1, x1, HEAP, lsl #32
    // 0xd74934: cmp             w1, NULL
    // 0xd74938: b.eq            #0xd74da8
    // 0xd7493c: r16 = <Type, GestureRecognizerFactory<GestureRecognizer>>
    //     0xd7493c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15500] TypeArguments: <Type, GestureRecognizerFactory<GestureRecognizer>>
    //     0xd74940: ldr             x16, [x16, #0x500]
    // 0xd74944: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0xd74948: stp             lr, x16, [SP]
    // 0xd7494c: r0 = Map._fromLiteral()
    //     0xd7494c: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xd74950: r1 = <TapGestureRecognizer>
    //     0xd74950: add             x1, PP, #0x84, lsl #12  ; [pp+0x84d58] TypeArguments: <TapGestureRecognizer>
    //     0xd74954: ldr             x1, [x1, #0xd58]
    // 0xd74958: stur            x0, [fp, #-0x48]
    // 0xd7495c: r0 = GestureRecognizerFactoryWithHandlers()
    //     0xd7495c: bl              #0xd37854  ; AllocateGestureRecognizerFactoryWithHandlersStub -> GestureRecognizerFactoryWithHandlers<X0 bound GestureRecognizer> (size=0x14)
    // 0xd74960: r1 = Function '<anonymous closure>':.
    //     0xd74960: add             x1, PP, #0xac, lsl #12  ; [pp+0xacc80] AnonymousClosure: (0xd757e0), in [package:flutter/src/cupertino/button.dart] _CupertinoButtonState::build (0xd743e4)
    //     0xd74964: ldr             x1, [x1, #0xc80]
    // 0xd74968: r2 = Null
    //     0xd74968: mov             x2, NULL
    // 0xd7496c: stur            x0, [fp, #-0x50]
    // 0xd74970: r0 = AllocateClosure()
    //     0xd74970: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd74974: ldur            x3, [fp, #-0x50]
    // 0xd74978: StoreField: r3->field_b = r0
    //     0xd74978: stur            w0, [x3, #0xb]
    // 0xd7497c: ldur            x2, [fp, #-0x18]
    // 0xd74980: r1 = Function '<anonymous closure>':.
    //     0xd74980: add             x1, PP, #0xac, lsl #12  ; [pp+0xacc88] AnonymousClosure: (0xd74f78), in [package:flutter/src/cupertino/button.dart] _CupertinoButtonState::build (0xd743e4)
    //     0xd74984: ldr             x1, [x1, #0xc88]
    // 0xd74988: r0 = AllocateClosure()
    //     0xd74988: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd7498c: ldur            x3, [fp, #-0x50]
    // 0xd74990: StoreField: r3->field_f = r0
    //     0xd74990: stur            w0, [x3, #0xf]
    // 0xd74994: ldur            x1, [fp, #-0x48]
    // 0xd74998: r2 = TapGestureRecognizer
    //     0xd74998: add             x2, PP, #0x84, lsl #12  ; [pp+0x84d70] Type: TapGestureRecognizer
    //     0xd7499c: ldr             x2, [x2, #0xd70]
    // 0xd749a0: r0 = []=()
    //     0xd749a0: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xd749a4: ldur            x0, [fp, #-8]
    // 0xd749a8: LoadField: r1 = r0->field_b
    //     0xd749a8: ldur            w1, [x0, #0xb]
    // 0xd749ac: DecompressPointer r1
    //     0xd749ac: add             x1, x1, HEAP, lsl #32
    // 0xd749b0: cmp             w1, NULL
    // 0xd749b4: b.eq            #0xd74dac
    // 0xd749b8: ldur            x3, [fp, #-0x20]
    // 0xd749bc: cmp             w3, NULL
    // 0xd749c0: b.ne            #0xd749cc
    // 0xd749c4: r1 = Null
    //     0xd749c4: mov             x1, NULL
    // 0xd749c8: b               #0xd749fc
    // 0xd749cc: LoadField: d0 = r3->field_7
    //     0xd749cc: ldur            d0, [x3, #7]
    // 0xd749d0: r1 = inline_Allocate_Double()
    //     0xd749d0: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xd749d4: add             x1, x1, #0x10
    //     0xd749d8: cmp             x2, x1
    //     0xd749dc: b.ls            #0xd74db0
    //     0xd749e0: str             x1, [THR, #0x60]  ; THR::top
    //     0xd749e4: sub             x1, x1, #0xf
    //     0xd749e8: mov             x2, #0xe19c
    //     0xd749ec: movk            x2, #3, lsl #16
    //     0xd749f0: stur            x2, [x1, #-1]
    // 0xd749f4: dmb             ishst
    // 0xd749f8: StoreField: r1->field_7 = d0
    //     0xd749f8: stur            d0, [x1, #7]
    // 0xd749fc: cmp             w1, NULL
    // 0xd74a00: b.ne            #0xd74a1c
    // 0xd74a04: r1 = _ConstMap len:3
    //     0xd74a04: add             x1, PP, #0xac, lsl #12  ; [pp+0xacc90] Map<CupertinoButtonSize, double>(3)
    //     0xd74a08: ldr             x1, [x1, #0xc90]
    // 0xd74a0c: r2 = Instance_CupertinoButtonSize
    //     0xd74a0c: add             x2, PP, #0x95, lsl #12  ; [pp+0x95fd8] Obj!CupertinoButtonSize@12c6081
    //     0xd74a10: ldr             x2, [x2, #0xfd8]
    // 0xd74a14: r0 = []()
    //     0xd74a14: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0xd74a18: b               #0xd74a20
    // 0xd74a1c: mov             x0, x1
    // 0xd74a20: cmp             w0, NULL
    // 0xd74a24: b.ne            #0xd74a34
    // 0xd74a28: d0 = 44.000000
    //     0xd74a28: add             x17, PP, #0x8f, lsl #12  ; [pp+0x8f600] IMM: double(44) from 0x4046000000000000
    //     0xd74a2c: ldr             d0, [x17, #0x600]
    // 0xd74a30: b               #0xd74a38
    // 0xd74a34: LoadField: d0 = r0->field_7
    //     0xd74a34: ldur            d0, [x0, #7]
    // 0xd74a38: ldur            x0, [fp, #-0x20]
    // 0xd74a3c: stur            d0, [fp, #-0x70]
    // 0xd74a40: cmp             w0, NULL
    // 0xd74a44: b.ne            #0xd74a50
    // 0xd74a48: r0 = Null
    //     0xd74a48: mov             x0, NULL
    // 0xd74a4c: b               #0xd74a80
    // 0xd74a50: LoadField: d1 = r0->field_f
    //     0xd74a50: ldur            d1, [x0, #0xf]
    // 0xd74a54: r0 = inline_Allocate_Double()
    //     0xd74a54: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xd74a58: add             x0, x0, #0x10
    //     0xd74a5c: cmp             x1, x0
    //     0xd74a60: b.ls            #0xd74dcc
    //     0xd74a64: str             x0, [THR, #0x60]  ; THR::top
    //     0xd74a68: sub             x0, x0, #0xf
    //     0xd74a6c: mov             x1, #0xe19c
    //     0xd74a70: movk            x1, #3, lsl #16
    //     0xd74a74: stur            x1, [x0, #-1]
    // 0xd74a78: dmb             ishst
    // 0xd74a7c: StoreField: r0->field_7 = d1
    //     0xd74a7c: stur            d1, [x0, #7]
    // 0xd74a80: cmp             w0, NULL
    // 0xd74a84: b.ne            #0xd74ab0
    // 0xd74a88: ldur            x0, [fp, #-8]
    // 0xd74a8c: LoadField: r1 = r0->field_b
    //     0xd74a8c: ldur            w1, [x0, #0xb]
    // 0xd74a90: DecompressPointer r1
    //     0xd74a90: add             x1, x1, HEAP, lsl #32
    // 0xd74a94: cmp             w1, NULL
    // 0xd74a98: b.eq            #0xd74ddc
    // 0xd74a9c: r1 = _ConstMap len:3
    //     0xd74a9c: add             x1, PP, #0xac, lsl #12  ; [pp+0xacc90] Map<CupertinoButtonSize, double>(3)
    //     0xd74aa0: ldr             x1, [x1, #0xc90]
    // 0xd74aa4: r2 = Instance_CupertinoButtonSize
    //     0xd74aa4: add             x2, PP, #0x95, lsl #12  ; [pp+0x95fd8] Obj!CupertinoButtonSize@12c6081
    //     0xd74aa8: ldr             x2, [x2, #0xfd8]
    // 0xd74aac: r0 = []()
    //     0xd74aac: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0xd74ab0: cmp             w0, NULL
    // 0xd74ab4: b.ne            #0xd74ac4
    // 0xd74ab8: d1 = 44.000000
    //     0xd74ab8: add             x17, PP, #0x8f, lsl #12  ; [pp+0x8f600] IMM: double(44) from 0x4046000000000000
    //     0xd74abc: ldr             d1, [x17, #0x600]
    // 0xd74ac0: b               #0xd74acc
    // 0xd74ac4: LoadField: d0 = r0->field_7
    //     0xd74ac4: ldur            d0, [x0, #7]
    // 0xd74ac8: mov             v1.16b, v0.16b
    // 0xd74acc: ldur            x2, [fp, #-8]
    // 0xd74ad0: ldur            x6, [fp, #-0x30]
    // 0xd74ad4: ldur            x5, [fp, #-0x10]
    // 0xd74ad8: ldur            x4, [fp, #-0x28]
    // 0xd74adc: ldur            x3, [fp, #-0x40]
    // 0xd74ae0: ldur            x0, [fp, #-0x48]
    // 0xd74ae4: ldur            d0, [fp, #-0x70]
    // 0xd74ae8: ldur            x1, [fp, #-0x38]
    // 0xd74aec: stur            d1, [fp, #-0x78]
    // 0xd74af0: r0 = BoxConstraints()
    //     0xd74af0: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xd74af4: ldur            d0, [fp, #-0x70]
    // 0xd74af8: stur            x0, [fp, #-0x60]
    // 0xd74afc: StoreField: r0->field_7 = d0
    //     0xd74afc: stur            d0, [x0, #7]
    // 0xd74b00: d0 = inf
    //     0xd74b00: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xd74b04: StoreField: r0->field_f = d0
    //     0xd74b04: stur            d0, [x0, #0xf]
    // 0xd74b08: ldur            d1, [fp, #-0x78]
    // 0xd74b0c: ArrayStore: r0[0] = d1  ; List_8
    //     0xd74b0c: stur            d1, [x0, #0x17]
    // 0xd74b10: StoreField: r0->field_1f = d0
    //     0xd74b10: stur            d0, [x0, #0x1f]
    // 0xd74b14: ldur            x2, [fp, #-8]
    // 0xd74b18: LoadField: r1 = r2->field_23
    //     0xd74b18: ldur            w1, [x2, #0x23]
    // 0xd74b1c: DecompressPointer r1
    //     0xd74b1c: add             x1, x1, HEAP, lsl #32
    // 0xd74b20: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd74b24: cmp             w1, w16
    // 0xd74b28: b.eq            #0xd74de0
    // 0xd74b2c: stur            x1, [fp, #-0x58]
    // 0xd74b30: LoadField: r3 = r2->field_b
    //     0xd74b30: ldur            w3, [x2, #0xb]
    // 0xd74b34: DecompressPointer r3
    //     0xd74b34: add             x3, x3, HEAP, lsl #32
    // 0xd74b38: cmp             w3, NULL
    // 0xd74b3c: b.eq            #0xd74dec
    // 0xd74b40: LoadField: r4 = r3->field_f
    //     0xd74b40: ldur            w4, [x3, #0xf]
    // 0xd74b44: DecompressPointer r4
    //     0xd74b44: add             x4, x4, HEAP, lsl #32
    // 0xd74b48: stur            x4, [fp, #-0x50]
    // 0xd74b4c: LoadField: r5 = r3->field_3f
    //     0xd74b4c: ldur            w5, [x3, #0x3f]
    // 0xd74b50: DecompressPointer r5
    //     0xd74b50: add             x5, x5, HEAP, lsl #32
    // 0xd74b54: stur            x5, [fp, #-0x20]
    // 0xd74b58: LoadField: r6 = r3->field_b
    //     0xd74b58: ldur            w6, [x3, #0xb]
    // 0xd74b5c: DecompressPointer r6
    //     0xd74b5c: add             x6, x6, HEAP, lsl #32
    // 0xd74b60: stur            x6, [fp, #-0x18]
    // 0xd74b64: r0 = IconTheme()
    //     0xd74b64: bl              #0xd0c668  ; AllocateIconThemeStub -> IconTheme (size=0x14)
    // 0xd74b68: mov             x1, x0
    // 0xd74b6c: ldur            x0, [fp, #-0x10]
    // 0xd74b70: stur            x1, [fp, #-0x68]
    // 0xd74b74: StoreField: r1->field_f = r0
    //     0xd74b74: stur            w0, [x1, #0xf]
    // 0xd74b78: ldur            x0, [fp, #-0x18]
    // 0xd74b7c: StoreField: r1->field_b = r0
    //     0xd74b7c: stur            w0, [x1, #0xb]
    // 0xd74b80: r0 = DefaultTextStyle()
    //     0xd74b80: bl              #0xd0b11c  ; AllocateDefaultTextStyleStub -> DefaultTextStyle (size=0x2c)
    // 0xd74b84: mov             x1, x0
    // 0xd74b88: ldur            x0, [fp, #-0x30]
    // 0xd74b8c: stur            x1, [fp, #-0x10]
    // 0xd74b90: StoreField: r1->field_f = r0
    //     0xd74b90: stur            w0, [x1, #0xf]
    // 0xd74b94: r0 = true
    //     0xd74b94: add             x0, NULL, #0x20  ; true
    // 0xd74b98: ArrayStore: r1[0] = r0  ; List_4
    //     0xd74b98: stur            w0, [x1, #0x17]
    // 0xd74b9c: r2 = Instance_TextOverflow
    //     0xd74b9c: add             x2, PP, #0x20, lsl #12  ; [pp+0x20108] Obj!TextOverflow@12c47c1
    //     0xd74ba0: ldr             x2, [x2, #0x108]
    // 0xd74ba4: StoreField: r1->field_1b = r2
    //     0xd74ba4: stur            w2, [x1, #0x1b]
    // 0xd74ba8: r2 = Instance_TextWidthBasis
    //     0xd74ba8: add             x2, PP, #0x20, lsl #12  ; [pp+0x20110] Obj!TextWidthBasis@12c4781
    //     0xd74bac: ldr             x2, [x2, #0x110]
    // 0xd74bb0: StoreField: r1->field_23 = r2
    //     0xd74bb0: stur            w2, [x1, #0x23]
    // 0xd74bb4: ldur            x2, [fp, #-0x68]
    // 0xd74bb8: StoreField: r1->field_b = r2
    //     0xd74bb8: stur            w2, [x1, #0xb]
    // 0xd74bbc: r0 = Align()
    //     0xd74bbc: bl              #0xb281f8  ; AllocateAlignStub -> Align (size=0x1c)
    // 0xd74bc0: mov             x1, x0
    // 0xd74bc4: ldur            x0, [fp, #-0x20]
    // 0xd74bc8: stur            x1, [fp, #-0x18]
    // 0xd74bcc: StoreField: r1->field_f = r0
    //     0xd74bcc: stur            w0, [x1, #0xf]
    // 0xd74bd0: r0 = 1.000000
    //     0xd74bd0: ldr             x0, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xd74bd4: StoreField: r1->field_13 = r0
    //     0xd74bd4: stur            w0, [x1, #0x13]
    // 0xd74bd8: ArrayStore: r1[0] = r0  ; List_4
    //     0xd74bd8: stur            w0, [x1, #0x17]
    // 0xd74bdc: ldur            x0, [fp, #-0x10]
    // 0xd74be0: StoreField: r1->field_b = r0
    //     0xd74be0: stur            w0, [x1, #0xb]
    // 0xd74be4: r0 = Padding()
    //     0xd74be4: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xd74be8: mov             x1, x0
    // 0xd74bec: ldur            x0, [fp, #-0x50]
    // 0xd74bf0: stur            x1, [fp, #-0x10]
    // 0xd74bf4: StoreField: r1->field_f = r0
    //     0xd74bf4: stur            w0, [x1, #0xf]
    // 0xd74bf8: ldur            x0, [fp, #-0x18]
    // 0xd74bfc: StoreField: r1->field_b = r0
    //     0xd74bfc: stur            w0, [x1, #0xb]
    // 0xd74c00: r0 = DecoratedBox()
    //     0xd74c00: bl              #0xd66318  ; AllocateDecoratedBoxStub -> DecoratedBox (size=0x18)
    // 0xd74c04: mov             x1, x0
    // 0xd74c08: ldur            x0, [fp, #-0x40]
    // 0xd74c0c: stur            x1, [fp, #-0x18]
    // 0xd74c10: StoreField: r1->field_f = r0
    //     0xd74c10: stur            w0, [x1, #0xf]
    // 0xd74c14: r0 = Instance_DecorationPosition
    //     0xd74c14: add             x0, PP, #0x80, lsl #12  ; [pp+0x80ef0] Obj!DecorationPosition@12c4381
    //     0xd74c18: ldr             x0, [x0, #0xef0]
    // 0xd74c1c: StoreField: r1->field_13 = r0
    //     0xd74c1c: stur            w0, [x1, #0x13]
    // 0xd74c20: ldur            x0, [fp, #-0x10]
    // 0xd74c24: StoreField: r1->field_b = r0
    //     0xd74c24: stur            w0, [x1, #0xb]
    // 0xd74c28: r0 = FadeTransition()
    //     0xd74c28: bl              #0xb28358  ; AllocateFadeTransitionStub -> FadeTransition (size=0x18)
    // 0xd74c2c: mov             x1, x0
    // 0xd74c30: ldur            x0, [fp, #-0x58]
    // 0xd74c34: stur            x1, [fp, #-0x10]
    // 0xd74c38: StoreField: r1->field_f = r0
    //     0xd74c38: stur            w0, [x1, #0xf]
    // 0xd74c3c: r0 = false
    //     0xd74c3c: add             x0, NULL, #0x30  ; false
    // 0xd74c40: StoreField: r1->field_13 = r0
    //     0xd74c40: stur            w0, [x1, #0x13]
    // 0xd74c44: ldur            x2, [fp, #-0x18]
    // 0xd74c48: StoreField: r1->field_b = r2
    //     0xd74c48: stur            w2, [x1, #0xb]
    // 0xd74c4c: r0 = ConstrainedBox()
    //     0xd74c4c: bl              #0xd0a588  ; AllocateConstrainedBoxStub -> ConstrainedBox (size=0x14)
    // 0xd74c50: mov             x1, x0
    // 0xd74c54: ldur            x0, [fp, #-0x60]
    // 0xd74c58: stur            x1, [fp, #-0x18]
    // 0xd74c5c: StoreField: r1->field_f = r0
    //     0xd74c5c: stur            w0, [x1, #0xf]
    // 0xd74c60: ldur            x0, [fp, #-0x10]
    // 0xd74c64: StoreField: r1->field_b = r0
    //     0xd74c64: stur            w0, [x1, #0xb]
    // 0xd74c68: r0 = Semantics()
    //     0xd74c68: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xd74c6c: stur            x0, [fp, #-0x10]
    // 0xd74c70: r16 = true
    //     0xd74c70: add             x16, NULL, #0x20  ; true
    // 0xd74c74: ldur            lr, [fp, #-0x18]
    // 0xd74c78: stp             lr, x16, [SP]
    // 0xd74c7c: mov             x1, x0
    // 0xd74c80: r4 = const [0, 0x3, 0x2, 0x1, button, 0x1, child, 0x2, null]
    //     0xd74c80: add             x4, PP, #0x8f, lsl #12  ; [pp+0x8ff08] List(9) [0, 0x3, 0x2, 0x1, "button", 0x1, "child", 0x2, Null]
    //     0xd74c84: ldr             x4, [x4, #0xf08]
    // 0xd74c88: r0 = Semantics()
    //     0xd74c88: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xd74c8c: r0 = RawGestureDetector()
    //     0xd74c8c: bl              #0xd37630  ; AllocateRawGestureDetectorStub -> RawGestureDetector (size=0x20)
    // 0xd74c90: mov             x1, x0
    // 0xd74c94: ldur            x0, [fp, #-0x10]
    // 0xd74c98: stur            x1, [fp, #-0x18]
    // 0xd74c9c: StoreField: r1->field_b = r0
    //     0xd74c9c: stur            w0, [x1, #0xb]
    // 0xd74ca0: ldur            x0, [fp, #-0x48]
    // 0xd74ca4: StoreField: r1->field_f = r0
    //     0xd74ca4: stur            w0, [x1, #0xf]
    // 0xd74ca8: r0 = Instance_HitTestBehavior
    //     0xd74ca8: add             x0, PP, #0x15, lsl #12  ; [pp+0x155c0] Obj!HitTestBehavior@12c43c1
    //     0xd74cac: ldr             x0, [x0, #0x5c0]
    // 0xd74cb0: StoreField: r1->field_13 = r0
    //     0xd74cb0: stur            w0, [x1, #0x13]
    // 0xd74cb4: r0 = false
    //     0xd74cb4: add             x0, NULL, #0x30  ; false
    // 0xd74cb8: ArrayStore: r1[0] = r0  ; List_4
    //     0xd74cb8: stur            w0, [x1, #0x17]
    // 0xd74cbc: r0 = FocusableActionDetector()
    //     0xd74cbc: bl              #0xd11ab4  ; AllocateFocusableActionDetectorStub -> FocusableActionDetector (size=0x40)
    // 0xd74cc0: mov             x3, x0
    // 0xd74cc4: r0 = true
    //     0xd74cc4: add             x0, NULL, #0x20  ; true
    // 0xd74cc8: stur            x3, [fp, #-0x10]
    // 0xd74ccc: StoreField: r3->field_b = r0
    //     0xd74ccc: stur            w0, [x3, #0xb]
    // 0xd74cd0: r1 = false
    //     0xd74cd0: add             x1, NULL, #0x30  ; false
    // 0xd74cd4: StoreField: r3->field_13 = r1
    //     0xd74cd4: stur            w1, [x3, #0x13]
    // 0xd74cd8: ArrayStore: r3[0] = r0  ; List_4
    //     0xd74cd8: stur            w0, [x3, #0x17]
    // 0xd74cdc: StoreField: r3->field_1b = r0
    //     0xd74cdc: stur            w0, [x3, #0x1b]
    // 0xd74ce0: ldur            x1, [fp, #-0x38]
    // 0xd74ce4: StoreField: r3->field_1f = r1
    //     0xd74ce4: stur            w1, [x3, #0x1f]
    // 0xd74ce8: ldur            x2, [fp, #-8]
    // 0xd74cec: r1 = Function '_onShowFocusHighlight@292145554':.
    //     0xd74cec: add             x1, PP, #0xac, lsl #12  ; [pp+0xacc98] AnonymousClosure: (0xd74ea4), in [package:flutter/src/cupertino/button.dart] _CupertinoButtonState::_onShowFocusHighlight (0xd74ee0)
    //     0xd74cf0: ldr             x1, [x1, #0xc98]
    // 0xd74cf4: r0 = AllocateClosure()
    //     0xd74cf4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd74cf8: mov             x1, x0
    // 0xd74cfc: ldur            x0, [fp, #-0x10]
    // 0xd74d00: StoreField: r0->field_27 = r1
    //     0xd74d00: stur            w1, [x0, #0x27]
    // 0xd74d04: r1 = Instance__DeferringMouseCursor
    //     0xd74d04: ldr             x1, [PP, #0x2208]  ; [pp+0x2208] Obj!_DeferringMouseCursor@12b3241
    // 0xd74d08: StoreField: r0->field_33 = r1
    //     0xd74d08: stur            w1, [x0, #0x33]
    // 0xd74d0c: r1 = true
    //     0xd74d0c: add             x1, NULL, #0x20  ; true
    // 0xd74d10: StoreField: r0->field_37 = r1
    //     0xd74d10: stur            w1, [x0, #0x37]
    // 0xd74d14: ldur            x2, [fp, #-0x18]
    // 0xd74d18: StoreField: r0->field_3b = r2
    //     0xd74d18: stur            w2, [x0, #0x3b]
    // 0xd74d1c: r0 = MouseRegion()
    //     0xd74d1c: bl              #0xd1c8fc  ; AllocateMouseRegionStub -> MouseRegion (size=0x28)
    // 0xd74d20: ldur            x1, [fp, #-0x28]
    // 0xd74d24: StoreField: r0->field_1b = r1
    //     0xd74d24: stur            w1, [x0, #0x1b]
    // 0xd74d28: r1 = true
    //     0xd74d28: add             x1, NULL, #0x20  ; true
    // 0xd74d2c: StoreField: r0->field_1f = r1
    //     0xd74d2c: stur            w1, [x0, #0x1f]
    // 0xd74d30: ldur            x1, [fp, #-0x10]
    // 0xd74d34: StoreField: r0->field_b = r1
    //     0xd74d34: stur            w1, [x0, #0xb]
    // 0xd74d38: LeaveFrame
    //     0xd74d38: mov             SP, fp
    //     0xd74d3c: ldp             fp, lr, [SP], #0x10
    // 0xd74d40: ret
    //     0xd74d40: ret             
    // 0xd74d44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd74d44: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd74d48: b               #0xd7440c
    // 0xd74d4c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd74d4c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd74d50: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd74d50: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd74d54: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd74d54: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd74d58: SaveReg d0
    //     0xd74d58: str             q0, [SP, #-0x10]!
    // 0xd74d5c: r0 = AllocateDouble()
    //     0xd74d5c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd74d60: RestoreReg d0
    //     0xd74d60: ldr             q0, [SP], #0x10
    // 0xd74d64: b               #0xd7457c
    // 0xd74d68: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd74d68: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd74d6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd74d6c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd74d70: SaveReg d0
    //     0xd74d70: str             q0, [SP, #-0x10]!
    // 0xd74d74: stp             x3, x4, [SP, #-0x10]!
    // 0xd74d78: stp             x0, x2, [SP, #-0x10]!
    // 0xd74d7c: r0 = AllocateDouble()
    //     0xd74d7c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd74d80: mov             x1, x0
    // 0xd74d84: ldp             x0, x2, [SP], #0x10
    // 0xd74d88: ldp             x3, x4, [SP], #0x10
    // 0xd74d8c: RestoreReg d0
    //     0xd74d8c: ldr             q0, [SP], #0x10
    // 0xd74d90: b               #0xd746d0
    // 0xd74d94: r9 = isFocused
    //     0xd74d94: add             x9, PP, #0xac, lsl #12  ; [pp+0xacca0] Field <_CupertinoButtonState@292145554.isFocused>: late (offset: 0x28)
    //     0xd74d98: ldr             x9, [x9, #0xca0]
    // 0xd74d9c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd74d9c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd74da0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd74da0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd74da4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd74da4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd74da8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd74da8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd74dac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd74dac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd74db0: SaveReg d0
    //     0xd74db0: str             q0, [SP, #-0x10]!
    // 0xd74db4: stp             x0, x3, [SP, #-0x10]!
    // 0xd74db8: r0 = AllocateDouble()
    //     0xd74db8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd74dbc: mov             x1, x0
    // 0xd74dc0: ldp             x0, x3, [SP], #0x10
    // 0xd74dc4: RestoreReg d0
    //     0xd74dc4: ldr             q0, [SP], #0x10
    // 0xd74dc8: b               #0xd749f8
    // 0xd74dcc: stp             q0, q1, [SP, #-0x20]!
    // 0xd74dd0: r0 = AllocateDouble()
    //     0xd74dd0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd74dd4: ldp             q0, q1, [SP], #0x20
    // 0xd74dd8: b               #0xd74a7c
    // 0xd74ddc: r0 = NullCastErrorSharedWithFPURegs()
    //     0xd74ddc: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xd74de0: r9 = _opacityAnimation
    //     0xd74de0: add             x9, PP, #0xac, lsl #12  ; [pp+0xacca8] Field <_CupertinoButtonState@292145554._opacityAnimation@292145554>: late (offset: 0x24)
    //     0xd74de4: ldr             x9, [x9, #0xca8]
    // 0xd74de8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd74de8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd74dec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd74dec: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _onShowFocusHighlight(dynamic, bool) {
    // ** addr: 0xd74ea4, size: 0x3c
    // 0xd74ea4: EnterFrame
    //     0xd74ea4: stp             fp, lr, [SP, #-0x10]!
    //     0xd74ea8: mov             fp, SP
    // 0xd74eac: ldr             x0, [fp, #0x18]
    // 0xd74eb0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd74eb0: ldur            w1, [x0, #0x17]
    // 0xd74eb4: DecompressPointer r1
    //     0xd74eb4: add             x1, x1, HEAP, lsl #32
    // 0xd74eb8: CheckStackOverflow
    //     0xd74eb8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd74ebc: cmp             SP, x16
    //     0xd74ec0: b.ls            #0xd74ed8
    // 0xd74ec4: ldr             x2, [fp, #0x10]
    // 0xd74ec8: r0 = _onShowFocusHighlight()
    //     0xd74ec8: bl              #0xd74ee0  ; [package:flutter/src/cupertino/button.dart] _CupertinoButtonState::_onShowFocusHighlight
    // 0xd74ecc: LeaveFrame
    //     0xd74ecc: mov             SP, fp
    //     0xd74ed0: ldp             fp, lr, [SP], #0x10
    // 0xd74ed4: ret
    //     0xd74ed4: ret             
    // 0xd74ed8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd74ed8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd74edc: b               #0xd74ec4
  }
  _ _onShowFocusHighlight(/* No info */) {
    // ** addr: 0xd74ee0, size: 0x70
    // 0xd74ee0: EnterFrame
    //     0xd74ee0: stp             fp, lr, [SP, #-0x10]!
    //     0xd74ee4: mov             fp, SP
    // 0xd74ee8: AllocStack(0x10)
    //     0xd74ee8: sub             SP, SP, #0x10
    // 0xd74eec: SetupParameters(_CupertinoButtonState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xd74eec: stur            x1, [fp, #-8]
    //     0xd74ef0: stur            x2, [fp, #-0x10]
    // 0xd74ef4: CheckStackOverflow
    //     0xd74ef4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd74ef8: cmp             SP, x16
    //     0xd74efc: b.ls            #0xd74f48
    // 0xd74f00: r1 = 2
    //     0xd74f00: mov             x1, #2
    // 0xd74f04: r0 = AllocateContext()
    //     0xd74f04: bl              #0x13de838  ; AllocateContextStub
    // 0xd74f08: mov             x1, x0
    // 0xd74f0c: ldur            x0, [fp, #-8]
    // 0xd74f10: StoreField: r1->field_f = r0
    //     0xd74f10: stur            w0, [x1, #0xf]
    // 0xd74f14: ldur            x2, [fp, #-0x10]
    // 0xd74f18: StoreField: r1->field_13 = r2
    //     0xd74f18: stur            w2, [x1, #0x13]
    // 0xd74f1c: mov             x2, x1
    // 0xd74f20: r1 = Function '<anonymous closure>':.
    //     0xd74f20: add             x1, PP, #0xac, lsl #12  ; [pp+0xaccb0] AnonymousClosure: (0xd74f50), in [package:flutter/src/cupertino/button.dart] _CupertinoButtonState::_onShowFocusHighlight (0xd74ee0)
    //     0xd74f24: ldr             x1, [x1, #0xcb0]
    // 0xd74f28: r0 = AllocateClosure()
    //     0xd74f28: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd74f2c: ldur            x1, [fp, #-8]
    // 0xd74f30: mov             x2, x0
    // 0xd74f34: r0 = setState()
    //     0xd74f34: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xd74f38: r0 = Null
    //     0xd74f38: mov             x0, NULL
    // 0xd74f3c: LeaveFrame
    //     0xd74f3c: mov             SP, fp
    //     0xd74f40: ldp             fp, lr, [SP], #0x10
    // 0xd74f44: ret
    //     0xd74f44: ret             
    // 0xd74f48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd74f48: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd74f4c: b               #0xd74f00
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xd74f50, size: 0x28
    // 0xd74f50: ldr             x1, [SP]
    // 0xd74f54: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xd74f54: ldur            w2, [x1, #0x17]
    // 0xd74f58: DecompressPointer r2
    //     0xd74f58: add             x2, x2, HEAP, lsl #32
    // 0xd74f5c: LoadField: r1 = r2->field_f
    //     0xd74f5c: ldur            w1, [x2, #0xf]
    // 0xd74f60: DecompressPointer r1
    //     0xd74f60: add             x1, x1, HEAP, lsl #32
    // 0xd74f64: LoadField: r3 = r2->field_13
    //     0xd74f64: ldur            w3, [x2, #0x13]
    // 0xd74f68: DecompressPointer r3
    //     0xd74f68: add             x3, x3, HEAP, lsl #32
    // 0xd74f6c: StoreField: r1->field_27 = r3
    //     0xd74f6c: stur            w3, [x1, #0x27]
    // 0xd74f70: r0 = Null
    //     0xd74f70: mov             x0, NULL
    // 0xd74f74: ret
    //     0xd74f74: ret             
  }
  [closure] void <anonymous closure>(dynamic, TapGestureRecognizer) {
    // ** addr: 0xd74f78, size: 0x178
    // 0xd74f78: EnterFrame
    //     0xd74f78: stp             fp, lr, [SP, #-0x10]!
    //     0xd74f7c: mov             fp, SP
    // 0xd74f80: AllocStack(0x10)
    //     0xd74f80: sub             SP, SP, #0x10
    // 0xd74f84: SetupParameters([dynamic _ /* r0 */])
    //     0xd74f84: ldr             x0, [fp, #0x18]
    //     0xd74f88: ldur            w3, [x0, #0x17]
    //     0xd74f8c: add             x3, x3, HEAP, lsl #32
    //     0xd74f90: stur            x3, [fp, #-0x10]
    // 0xd74f94: LoadField: r0 = r3->field_13
    //     0xd74f94: ldur            w0, [x3, #0x13]
    // 0xd74f98: DecompressPointer r0
    //     0xd74f98: add             x0, x0, HEAP, lsl #32
    // 0xd74f9c: stur            x0, [fp, #-8]
    // 0xd74fa0: tbnz            w0, #4, #0xd74fbc
    // 0xd74fa4: LoadField: r2 = r3->field_f
    //     0xd74fa4: ldur            w2, [x3, #0xf]
    // 0xd74fa8: DecompressPointer r2
    //     0xd74fa8: add             x2, x2, HEAP, lsl #32
    // 0xd74fac: r1 = Function '_handleTapDown@292145554':.
    //     0xd74fac: add             x1, PP, #0xac, lsl #12  ; [pp+0xaccb8] AnonymousClosure: (0xd75724), in [package:flutter/src/cupertino/button.dart] _CupertinoButtonState::_handleTapDown (0xd75760)
    //     0xd74fb0: ldr             x1, [x1, #0xcb8]
    // 0xd74fb4: r0 = AllocateClosure()
    //     0xd74fb4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd74fb8: b               #0xd74fc0
    // 0xd74fbc: r0 = Null
    //     0xd74fbc: mov             x0, NULL
    // 0xd74fc0: ldr             x4, [fp, #0x10]
    // 0xd74fc4: ldur            x3, [fp, #-8]
    // 0xd74fc8: StoreField: r4->field_57 = r0
    //     0xd74fc8: stur            w0, [x4, #0x57]
    //     0xd74fcc: ldurb           w16, [x4, #-1]
    //     0xd74fd0: ldurb           w17, [x0, #-1]
    //     0xd74fd4: and             x16, x17, x16, lsr #2
    //     0xd74fd8: tst             x16, HEAP, lsr #32
    //     0xd74fdc: b.eq            #0xd74fe4
    //     0xd74fe0: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xd74fe4: tbnz            w3, #4, #0xd75004
    // 0xd74fe8: ldur            x0, [fp, #-0x10]
    // 0xd74fec: LoadField: r2 = r0->field_f
    //     0xd74fec: ldur            w2, [x0, #0xf]
    // 0xd74ff0: DecompressPointer r2
    //     0xd74ff0: add             x2, x2, HEAP, lsl #32
    // 0xd74ff4: r1 = Function '_handleTapUp@292145554':.
    //     0xd74ff4: add             x1, PP, #0xac, lsl #12  ; [pp+0xaccc0] AnonymousClosure: (0xd75488), in [package:flutter/src/cupertino/button.dart] _CupertinoButtonState::_handleTapUp (0xd754c4)
    //     0xd74ff8: ldr             x1, [x1, #0xcc0]
    // 0xd74ffc: r0 = AllocateClosure()
    //     0xd74ffc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd75000: b               #0xd75008
    // 0xd75004: r0 = Null
    //     0xd75004: mov             x0, NULL
    // 0xd75008: ldr             x4, [fp, #0x10]
    // 0xd7500c: ldur            x3, [fp, #-8]
    // 0xd75010: StoreField: r4->field_5b = r0
    //     0xd75010: stur            w0, [x4, #0x5b]
    //     0xd75014: ldurb           w16, [x4, #-1]
    //     0xd75018: ldurb           w17, [x0, #-1]
    //     0xd7501c: and             x16, x17, x16, lsr #2
    //     0xd75020: tst             x16, HEAP, lsr #32
    //     0xd75024: b.eq            #0xd7502c
    //     0xd75028: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xd7502c: tbnz            w3, #4, #0xd7504c
    // 0xd75030: ldur            x0, [fp, #-0x10]
    // 0xd75034: LoadField: r2 = r0->field_f
    //     0xd75034: ldur            w2, [x0, #0xf]
    // 0xd75038: DecompressPointer r2
    //     0xd75038: add             x2, x2, HEAP, lsl #32
    // 0xd7503c: r1 = Function '_handleTapCancel@292145554':.
    //     0xd7503c: add             x1, PP, #0xac, lsl #12  ; [pp+0xaccc8] AnonymousClosure: (0xd753d0), in [package:flutter/src/cupertino/button.dart] _CupertinoButtonState::_handleTapCancel (0xd75408)
    //     0xd75040: ldr             x1, [x1, #0xcc8]
    // 0xd75044: r0 = AllocateClosure()
    //     0xd75044: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd75048: b               #0xd75050
    // 0xd7504c: r0 = Null
    //     0xd7504c: mov             x0, NULL
    // 0xd75050: ldr             x3, [fp, #0x10]
    // 0xd75054: ldur            x1, [fp, #-8]
    // 0xd75058: StoreField: r3->field_67 = r0
    //     0xd75058: stur            w0, [x3, #0x67]
    //     0xd7505c: ldurb           w16, [x3, #-1]
    //     0xd75060: ldurb           w17, [x0, #-1]
    //     0xd75064: and             x16, x17, x16, lsr #2
    //     0xd75068: tst             x16, HEAP, lsr #32
    //     0xd7506c: b.eq            #0xd75074
    //     0xd75070: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xd75074: tbnz            w1, #4, #0xd75094
    // 0xd75078: ldur            x0, [fp, #-0x10]
    // 0xd7507c: LoadField: r2 = r0->field_f
    //     0xd7507c: ldur            w2, [x0, #0xf]
    // 0xd75080: DecompressPointer r2
    //     0xd75080: add             x2, x2, HEAP, lsl #32
    // 0xd75084: r1 = Function '_handleTapMove@292145554':.
    //     0xd75084: add             x1, PP, #0xac, lsl #12  ; [pp+0xaccd0] AnonymousClosure: (0xd750f0), in [package:flutter/src/cupertino/button.dart] _CupertinoButtonState::_handleTapMove (0xd7512c)
    //     0xd75088: ldr             x1, [x1, #0xcd0]
    // 0xd7508c: r0 = AllocateClosure()
    //     0xd7508c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd75090: b               #0xd75098
    // 0xd75094: r0 = Null
    //     0xd75094: mov             x0, NULL
    // 0xd75098: ldr             x1, [fp, #0x10]
    // 0xd7509c: ldur            x2, [fp, #-0x10]
    // 0xd750a0: StoreField: r1->field_63 = r0
    //     0xd750a0: stur            w0, [x1, #0x63]
    //     0xd750a4: ldurb           w16, [x1, #-1]
    //     0xd750a8: ldurb           w17, [x0, #-1]
    //     0xd750ac: and             x16, x17, x16, lsr #2
    //     0xd750b0: tst             x16, HEAP, lsr #32
    //     0xd750b4: b.eq            #0xd750bc
    //     0xd750b8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd750bc: ArrayLoad: r0 = r2[0]  ; List_4
    //     0xd750bc: ldur            w0, [x2, #0x17]
    // 0xd750c0: DecompressPointer r0
    //     0xd750c0: add             x0, x0, HEAP, lsl #32
    // 0xd750c4: StoreField: r1->field_7 = r0
    //     0xd750c4: stur            w0, [x1, #7]
    //     0xd750c8: ldurb           w16, [x1, #-1]
    //     0xd750cc: ldurb           w17, [x0, #-1]
    //     0xd750d0: and             x16, x17, x16, lsr #2
    //     0xd750d4: tst             x16, HEAP, lsr #32
    //     0xd750d8: b.eq            #0xd750e0
    //     0xd750dc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd750e0: r0 = Null
    //     0xd750e0: mov             x0, NULL
    // 0xd750e4: LeaveFrame
    //     0xd750e4: mov             SP, fp
    //     0xd750e8: ldp             fp, lr, [SP], #0x10
    // 0xd750ec: ret
    //     0xd750ec: ret             
  }
  [closure] void _handleTapMove(dynamic, TapMoveDetails) {
    // ** addr: 0xd750f0, size: 0x3c
    // 0xd750f0: EnterFrame
    //     0xd750f0: stp             fp, lr, [SP, #-0x10]!
    //     0xd750f4: mov             fp, SP
    // 0xd750f8: ldr             x0, [fp, #0x18]
    // 0xd750fc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd750fc: ldur            w1, [x0, #0x17]
    // 0xd75100: DecompressPointer r1
    //     0xd75100: add             x1, x1, HEAP, lsl #32
    // 0xd75104: CheckStackOverflow
    //     0xd75104: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd75108: cmp             SP, x16
    //     0xd7510c: b.ls            #0xd75124
    // 0xd75110: ldr             x2, [fp, #0x10]
    // 0xd75114: r0 = _handleTapMove()
    //     0xd75114: bl              #0xd7512c  ; [package:flutter/src/cupertino/button.dart] _CupertinoButtonState::_handleTapMove
    // 0xd75118: LeaveFrame
    //     0xd75118: mov             SP, fp
    //     0xd7511c: ldp             fp, lr, [SP], #0x10
    // 0xd75120: ret
    //     0xd75120: ret             
    // 0xd75124: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd75124: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd75128: b               #0xd75110
  }
  _ _handleTapMove(/* No info */) {
    // ** addr: 0xd7512c, size: 0x10c
    // 0xd7512c: EnterFrame
    //     0xd7512c: stp             fp, lr, [SP, #-0x10]!
    //     0xd75130: mov             fp, SP
    // 0xd75134: AllocStack(0x18)
    //     0xd75134: sub             SP, SP, #0x18
    // 0xd75138: SetupParameters(_CupertinoButtonState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xd75138: mov             x0, x1
    //     0xd7513c: stur            x1, [fp, #-8]
    //     0xd75140: stur            x2, [fp, #-0x10]
    // 0xd75144: CheckStackOverflow
    //     0xd75144: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd75148: cmp             SP, x16
    //     0xd7514c: b.ls            #0xd75228
    // 0xd75150: LoadField: r1 = r0->field_f
    //     0xd75150: ldur            w1, [x0, #0xf]
    // 0xd75154: DecompressPointer r1
    //     0xd75154: add             x1, x1, HEAP, lsl #32
    // 0xd75158: cmp             w1, NULL
    // 0xd7515c: b.eq            #0xd75230
    // 0xd75160: r0 = renderObject()
    //     0xd75160: bl              #0x123f10c  ; [package:flutter/src/widgets/framework.dart] Element::renderObject
    // 0xd75164: mov             x3, x0
    // 0xd75168: stur            x3, [fp, #-0x18]
    // 0xd7516c: cmp             w3, NULL
    // 0xd75170: b.eq            #0xd75234
    // 0xd75174: mov             x0, x3
    // 0xd75178: r2 = Null
    //     0xd75178: mov             x2, NULL
    // 0xd7517c: r1 = Null
    //     0xd7517c: mov             x1, NULL
    // 0xd75180: r4 = LoadClassIdInstr(r0)
    //     0xd75180: ldur            x4, [x0, #-1]
    //     0xd75184: ubfx            x4, x4, #0xc, #0x14
    // 0xd75188: r17 = -4710
    //     0xd75188: mov             x17, #-0x1266
    // 0xd7518c: add             x4, x4, x17
    // 0xd75190: cmp             x4, #0x109
    // 0xd75194: b.ls            #0xd751a8
    // 0xd75198: r8 = RenderBox
    //     0xd75198: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0xd7519c: r3 = Null
    //     0xd7519c: add             x3, PP, #0xa4, lsl #12  ; [pp+0xa4050] Null
    //     0xd751a0: ldr             x3, [x3, #0x50]
    // 0xd751a4: r0 = RenderBox()
    //     0xd751a4: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0xd751a8: ldur            x0, [fp, #-0x10]
    // 0xd751ac: LoadField: r2 = r0->field_7
    //     0xd751ac: ldur            w2, [x0, #7]
    // 0xd751b0: DecompressPointer r2
    //     0xd751b0: add             x2, x2, HEAP, lsl #32
    // 0xd751b4: ldur            x1, [fp, #-0x18]
    // 0xd751b8: r0 = globalToLocal()
    //     0xd751b8: bl              #0x867840  ; [package:flutter/src/rendering/box.dart] RenderBox::globalToLocal
    // 0xd751bc: ldur            x1, [fp, #-0x18]
    // 0xd751c0: stur            x0, [fp, #-0x10]
    // 0xd751c4: r0 = size()
    //     0xd751c4: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xd751c8: mov             x2, x0
    // 0xd751cc: r1 = Instance_Offset
    //     0xd751cc: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xd751d0: r0 = &()
    //     0xd751d0: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xd751d4: stur            x0, [fp, #-0x18]
    // 0xd751d8: r0 = tapMoveSlop()
    //     0xd751d8: bl              #0xd753c4  ; [package:flutter/src/cupertino/button.dart] CupertinoButton::tapMoveSlop
    // 0xd751dc: ldur            x1, [fp, #-0x18]
    // 0xd751e0: r0 = inflate()
    //     0xd751e0: bl              #0x882f50  ; [dart:ui] Rect::inflate
    // 0xd751e4: mov             x1, x0
    // 0xd751e8: ldur            x2, [fp, #-0x10]
    // 0xd751ec: r0 = contains()
    //     0xd751ec: bl              #0x81cce0  ; [dart:ui] Rect::contains
    // 0xd751f0: ldur            x1, [fp, #-8]
    // 0xd751f4: LoadField: r2 = r1->field_2f
    //     0xd751f4: ldur            w2, [x1, #0x2f]
    // 0xd751f8: DecompressPointer r2
    //     0xd751f8: add             x2, x2, HEAP, lsl #32
    // 0xd751fc: tbnz            w2, #4, #0xd75218
    // 0xd75200: LoadField: r2 = r1->field_2b
    //     0xd75200: ldur            w2, [x1, #0x2b]
    // 0xd75204: DecompressPointer r2
    //     0xd75204: add             x2, x2, HEAP, lsl #32
    // 0xd75208: cmp             w0, w2
    // 0xd7520c: b.eq            #0xd75218
    // 0xd75210: StoreField: r1->field_2b = r0
    //     0xd75210: stur            w0, [x1, #0x2b]
    // 0xd75214: r0 = _animate()
    //     0xd75214: bl              #0xd75238  ; [package:flutter/src/cupertino/button.dart] _CupertinoButtonState::_animate
    // 0xd75218: r0 = Null
    //     0xd75218: mov             x0, NULL
    // 0xd7521c: LeaveFrame
    //     0xd7521c: mov             SP, fp
    //     0xd75220: ldp             fp, lr, [SP], #0x10
    // 0xd75224: ret
    //     0xd75224: ret             
    // 0xd75228: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd75228: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd7522c: b               #0xd75150
    // 0xd75230: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd75230: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd75234: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd75234: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _animate(/* No info */) {
    // ** addr: 0xd75238, size: 0x11c
    // 0xd75238: EnterFrame
    //     0xd75238: stp             fp, lr, [SP, #-0x10]!
    //     0xd7523c: mov             fp, SP
    // 0xd75240: AllocStack(0x28)
    //     0xd75240: sub             SP, SP, #0x28
    // 0xd75244: SetupParameters(_CupertinoButtonState this /* r1 => r1, fp-0x8 */)
    //     0xd75244: stur            x1, [fp, #-8]
    // 0xd75248: CheckStackOverflow
    //     0xd75248: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd7524c: cmp             SP, x16
    //     0xd75250: b.ls            #0xd75340
    // 0xd75254: r1 = 2
    //     0xd75254: mov             x1, #2
    // 0xd75258: r0 = AllocateContext()
    //     0xd75258: bl              #0x13de838  ; AllocateContextStub
    // 0xd7525c: mov             x2, x0
    // 0xd75260: ldur            x0, [fp, #-8]
    // 0xd75264: stur            x2, [fp, #-0x10]
    // 0xd75268: StoreField: r2->field_f = r0
    //     0xd75268: stur            w0, [x2, #0xf]
    // 0xd7526c: LoadField: r1 = r0->field_1f
    //     0xd7526c: ldur            w1, [x0, #0x1f]
    // 0xd75270: DecompressPointer r1
    //     0xd75270: add             x1, x1, HEAP, lsl #32
    // 0xd75274: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd75278: cmp             w1, w16
    // 0xd7527c: b.eq            #0xd75348
    // 0xd75280: LoadField: r3 = r1->field_2f
    //     0xd75280: ldur            w3, [x1, #0x2f]
    // 0xd75284: DecompressPointer r3
    //     0xd75284: add             x3, x3, HEAP, lsl #32
    // 0xd75288: cmp             w3, NULL
    // 0xd7528c: b.eq            #0xd752b0
    // 0xd75290: LoadField: r4 = r3->field_7
    //     0xd75290: ldur            w4, [x3, #7]
    // 0xd75294: DecompressPointer r4
    //     0xd75294: add             x4, x4, HEAP, lsl #32
    // 0xd75298: cmp             w4, NULL
    // 0xd7529c: b.eq            #0xd752b0
    // 0xd752a0: r0 = Null
    //     0xd752a0: mov             x0, NULL
    // 0xd752a4: LeaveFrame
    //     0xd752a4: mov             SP, fp
    //     0xd752a8: ldp             fp, lr, [SP], #0x10
    // 0xd752ac: ret
    //     0xd752ac: ret             
    // 0xd752b0: LoadField: r3 = r0->field_2b
    //     0xd752b0: ldur            w3, [x0, #0x2b]
    // 0xd752b4: DecompressPointer r3
    //     0xd752b4: add             x3, x3, HEAP, lsl #32
    // 0xd752b8: StoreField: r2->field_13 = r3
    //     0xd752b8: stur            w3, [x2, #0x13]
    // 0xd752bc: tbnz            w3, #4, #0xd752e4
    // 0xd752c0: r16 = Instance_Duration
    //     0xd752c0: add             x16, PP, #0xa4, lsl #12  ; [pp+0xa4060] Obj!Duration@12c8b11
    //     0xd752c4: ldr             x16, [x16, #0x60]
    // 0xd752c8: r30 = Instance_ThreePointCubic
    //     0xd752c8: add             lr, PP, #0xa4, lsl #12  ; [pp+0xa4068] Obj!ThreePointCubic@129f3e1
    //     0xd752cc: ldr             lr, [lr, #0x68]
    // 0xd752d0: stp             lr, x16, [SP]
    // 0xd752d4: d0 = 1.000000
    //     0xd752d4: fmov            d0, #1.00000000
    // 0xd752d8: r4 = const [0, 0x4, 0x2, 0x2, curve, 0x3, duration, 0x2, null]
    //     0xd752d8: ldr             x4, [PP, #0x5158]  ; [pp+0x5158] List(9) [0, 0x4, 0x2, 0x2, "curve", 0x3, "duration", 0x2, Null]
    // 0xd752dc: r0 = animateTo()
    //     0xd752dc: bl              #0x866084  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::animateTo
    // 0xd752e0: b               #0xd75304
    // 0xd752e4: r16 = Instance_Duration
    //     0xd752e4: add             x16, PP, #0xa4, lsl #12  ; [pp+0xa4070] Obj!Duration@12c8b01
    //     0xd752e8: ldr             x16, [x16, #0x70]
    // 0xd752ec: r30 = Instance_Cubic
    //     0xd752ec: add             lr, PP, #0x7b, lsl #12  ; [pp+0x7b760] Obj!Cubic@129f6c1
    //     0xd752f0: ldr             lr, [lr, #0x760]
    // 0xd752f4: stp             lr, x16, [SP]
    // 0xd752f8: d0 = 0.000000
    //     0xd752f8: eor             v0.16b, v0.16b, v0.16b
    // 0xd752fc: r4 = const [0, 0x4, 0x2, 0x2, curve, 0x3, duration, 0x2, null]
    //     0xd752fc: ldr             x4, [PP, #0x5158]  ; [pp+0x5158] List(9) [0, 0x4, 0x2, 0x2, "curve", 0x3, "duration", 0x2, Null]
    // 0xd75300: r0 = animateTo()
    //     0xd75300: bl              #0x866084  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::animateTo
    // 0xd75304: ldur            x2, [fp, #-0x10]
    // 0xd75308: stur            x0, [fp, #-8]
    // 0xd7530c: r1 = Function '<anonymous closure>':.
    //     0xd7530c: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa4078] AnonymousClosure: (0xd75354), in [package:flutter/src/cupertino/button.dart] _CupertinoButtonState::_animate (0xd75238)
    //     0xd75310: ldr             x1, [x1, #0x78]
    // 0xd75314: r0 = AllocateClosure()
    //     0xd75314: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd75318: r16 = <void?>
    //     0xd75318: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xd7531c: ldur            lr, [fp, #-8]
    // 0xd75320: stp             lr, x16, [SP, #8]
    // 0xd75324: str             x0, [SP]
    // 0xd75328: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xd75328: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xd7532c: r0 = then()
    //     0xd7532c: bl              #0x13083d8  ; [package:flutter/src/scheduler/ticker.dart] TickerFuture::then
    // 0xd75330: r0 = Null
    //     0xd75330: mov             x0, NULL
    // 0xd75334: LeaveFrame
    //     0xd75334: mov             SP, fp
    //     0xd75338: ldp             fp, lr, [SP], #0x10
    // 0xd7533c: ret
    //     0xd7533c: ret             
    // 0xd75340: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd75340: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd75344: b               #0xd75254
    // 0xd75348: r9 = _animationController
    //     0xd75348: add             x9, PP, #0xa4, lsl #12  ; [pp+0xa4080] Field <_CupertinoButtonState@292145554._animationController@292145554>: late (offset: 0x20)
    //     0xd7534c: ldr             x9, [x9, #0x80]
    // 0xd75350: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd75350: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Null <anonymous closure>(dynamic, void) {
    // ** addr: 0xd75354, size: 0x70
    // 0xd75354: EnterFrame
    //     0xd75354: stp             fp, lr, [SP, #-0x10]!
    //     0xd75358: mov             fp, SP
    // 0xd7535c: ldr             x0, [fp, #0x18]
    // 0xd75360: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd75360: ldur            w1, [x0, #0x17]
    // 0xd75364: DecompressPointer r1
    //     0xd75364: add             x1, x1, HEAP, lsl #32
    // 0xd75368: CheckStackOverflow
    //     0xd75368: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd7536c: cmp             SP, x16
    //     0xd75370: b.ls            #0xd753bc
    // 0xd75374: LoadField: r0 = r1->field_f
    //     0xd75374: ldur            w0, [x1, #0xf]
    // 0xd75378: DecompressPointer r0
    //     0xd75378: add             x0, x0, HEAP, lsl #32
    // 0xd7537c: LoadField: r2 = r0->field_f
    //     0xd7537c: ldur            w2, [x0, #0xf]
    // 0xd75380: DecompressPointer r2
    //     0xd75380: add             x2, x2, HEAP, lsl #32
    // 0xd75384: cmp             w2, NULL
    // 0xd75388: b.eq            #0xd753ac
    // 0xd7538c: LoadField: r2 = r1->field_13
    //     0xd7538c: ldur            w2, [x1, #0x13]
    // 0xd75390: DecompressPointer r2
    //     0xd75390: add             x2, x2, HEAP, lsl #32
    // 0xd75394: LoadField: r1 = r0->field_2b
    //     0xd75394: ldur            w1, [x0, #0x2b]
    // 0xd75398: DecompressPointer r1
    //     0xd75398: add             x1, x1, HEAP, lsl #32
    // 0xd7539c: cmp             w2, w1
    // 0xd753a0: b.eq            #0xd753ac
    // 0xd753a4: mov             x1, x0
    // 0xd753a8: r0 = _animate()
    //     0xd753a8: bl              #0xd75238  ; [package:flutter/src/cupertino/button.dart] _CupertinoButtonState::_animate
    // 0xd753ac: r0 = Null
    //     0xd753ac: mov             x0, NULL
    // 0xd753b0: LeaveFrame
    //     0xd753b0: mov             SP, fp
    //     0xd753b4: ldp             fp, lr, [SP], #0x10
    // 0xd753b8: ret
    //     0xd753b8: ret             
    // 0xd753bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd753bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd753c0: b               #0xd75374
  }
  [closure] void _handleTapCancel(dynamic) {
    // ** addr: 0xd753d0, size: 0x38
    // 0xd753d0: EnterFrame
    //     0xd753d0: stp             fp, lr, [SP, #-0x10]!
    //     0xd753d4: mov             fp, SP
    // 0xd753d8: ldr             x0, [fp, #0x10]
    // 0xd753dc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd753dc: ldur            w1, [x0, #0x17]
    // 0xd753e0: DecompressPointer r1
    //     0xd753e0: add             x1, x1, HEAP, lsl #32
    // 0xd753e4: CheckStackOverflow
    //     0xd753e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd753e8: cmp             SP, x16
    //     0xd753ec: b.ls            #0xd75400
    // 0xd753f0: r0 = _handleTapCancel()
    //     0xd753f0: bl              #0xd75408  ; [package:flutter/src/cupertino/button.dart] _CupertinoButtonState::_handleTapCancel
    // 0xd753f4: LeaveFrame
    //     0xd753f4: mov             SP, fp
    //     0xd753f8: ldp             fp, lr, [SP], #0x10
    // 0xd753fc: ret
    //     0xd753fc: ret             
    // 0xd75400: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd75400: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd75404: b               #0xd753f0
  }
  _ _handleTapCancel(/* No info */) {
    // ** addr: 0xd75408, size: 0x80
    // 0xd75408: EnterFrame
    //     0xd75408: stp             fp, lr, [SP, #-0x10]!
    //     0xd7540c: mov             fp, SP
    // 0xd75410: AllocStack(0x8)
    //     0xd75410: sub             SP, SP, #8
    // 0xd75414: SetupParameters(_CupertinoButtonState this /* r1 => r1, fp-0x8 */)
    //     0xd75414: stur            x1, [fp, #-8]
    // 0xd75418: CheckStackOverflow
    //     0xd75418: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd7541c: cmp             SP, x16
    //     0xd75420: b.ls            #0xd75480
    // 0xd75424: r1 = 1
    //     0xd75424: mov             x1, #1
    // 0xd75428: r0 = AllocateContext()
    //     0xd75428: bl              #0x13de838  ; AllocateContextStub
    // 0xd7542c: mov             x1, x0
    // 0xd75430: ldur            x0, [fp, #-8]
    // 0xd75434: StoreField: r1->field_f = r0
    //     0xd75434: stur            w0, [x1, #0xf]
    // 0xd75438: mov             x2, x1
    // 0xd7543c: r1 = Function '<anonymous closure>':.
    //     0xd7543c: add             x1, PP, #0xac, lsl #12  ; [pp+0xaccd8] AnonymousClosure: (0xd1f860), in [package:flutter/src/material/dropdown.dart] _DropdownButtonState::_handleTap (0xd1ee4c)
    //     0xd75440: ldr             x1, [x1, #0xcd8]
    // 0xd75444: r0 = AllocateClosure()
    //     0xd75444: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd75448: ldur            x1, [fp, #-8]
    // 0xd7544c: mov             x2, x0
    // 0xd75450: r0 = setState()
    //     0xd75450: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xd75454: ldur            x1, [fp, #-8]
    // 0xd75458: LoadField: r0 = r1->field_2b
    //     0xd75458: ldur            w0, [x1, #0x2b]
    // 0xd7545c: DecompressPointer r0
    //     0xd7545c: add             x0, x0, HEAP, lsl #32
    // 0xd75460: tbnz            w0, #4, #0xd75470
    // 0xd75464: r0 = false
    //     0xd75464: add             x0, NULL, #0x30  ; false
    // 0xd75468: StoreField: r1->field_2b = r0
    //     0xd75468: stur            w0, [x1, #0x2b]
    // 0xd7546c: r0 = _animate()
    //     0xd7546c: bl              #0xd75238  ; [package:flutter/src/cupertino/button.dart] _CupertinoButtonState::_animate
    // 0xd75470: r0 = Null
    //     0xd75470: mov             x0, NULL
    // 0xd75474: LeaveFrame
    //     0xd75474: mov             SP, fp
    //     0xd75478: ldp             fp, lr, [SP], #0x10
    // 0xd7547c: ret
    //     0xd7547c: ret             
    // 0xd75480: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd75480: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd75484: b               #0xd75424
  }
  [closure] void _handleTapUp(dynamic, TapUpDetails) {
    // ** addr: 0xd75488, size: 0x3c
    // 0xd75488: EnterFrame
    //     0xd75488: stp             fp, lr, [SP, #-0x10]!
    //     0xd7548c: mov             fp, SP
    // 0xd75490: ldr             x0, [fp, #0x18]
    // 0xd75494: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd75494: ldur            w1, [x0, #0x17]
    // 0xd75498: DecompressPointer r1
    //     0xd75498: add             x1, x1, HEAP, lsl #32
    // 0xd7549c: CheckStackOverflow
    //     0xd7549c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd754a0: cmp             SP, x16
    //     0xd754a4: b.ls            #0xd754bc
    // 0xd754a8: ldr             x2, [fp, #0x10]
    // 0xd754ac: r0 = _handleTapUp()
    //     0xd754ac: bl              #0xd754c4  ; [package:flutter/src/cupertino/button.dart] _CupertinoButtonState::_handleTapUp
    // 0xd754b0: LeaveFrame
    //     0xd754b0: mov             SP, fp
    //     0xd754b4: ldp             fp, lr, [SP], #0x10
    // 0xd754b8: ret
    //     0xd754b8: ret             
    // 0xd754bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd754bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd754c0: b               #0xd754a8
  }
  _ _handleTapUp(/* No info */) {
    // ** addr: 0xd754c4, size: 0x148
    // 0xd754c4: EnterFrame
    //     0xd754c4: stp             fp, lr, [SP, #-0x10]!
    //     0xd754c8: mov             fp, SP
    // 0xd754cc: AllocStack(0x18)
    //     0xd754cc: sub             SP, SP, #0x18
    // 0xd754d0: SetupParameters(_CupertinoButtonState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xd754d0: stur            x1, [fp, #-8]
    //     0xd754d4: stur            x2, [fp, #-0x10]
    // 0xd754d8: CheckStackOverflow
    //     0xd754d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd754dc: cmp             SP, x16
    //     0xd754e0: b.ls            #0xd755fc
    // 0xd754e4: r1 = 1
    //     0xd754e4: mov             x1, #1
    // 0xd754e8: r0 = AllocateContext()
    //     0xd754e8: bl              #0x13de838  ; AllocateContextStub
    // 0xd754ec: mov             x1, x0
    // 0xd754f0: ldur            x0, [fp, #-8]
    // 0xd754f4: StoreField: r1->field_f = r0
    //     0xd754f4: stur            w0, [x1, #0xf]
    // 0xd754f8: mov             x2, x1
    // 0xd754fc: r1 = Function '<anonymous closure>':.
    //     0xd754fc: add             x1, PP, #0xac, lsl #12  ; [pp+0xacce0] AnonymousClosure: (0xd1f860), in [package:flutter/src/material/dropdown.dart] _DropdownButtonState::_handleTap (0xd1ee4c)
    //     0xd75500: ldr             x1, [x1, #0xce0]
    // 0xd75504: r0 = AllocateClosure()
    //     0xd75504: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd75508: ldur            x1, [fp, #-8]
    // 0xd7550c: mov             x2, x0
    // 0xd75510: r0 = setState()
    //     0xd75510: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xd75514: ldur            x0, [fp, #-8]
    // 0xd75518: LoadField: r1 = r0->field_2b
    //     0xd75518: ldur            w1, [x0, #0x2b]
    // 0xd7551c: DecompressPointer r1
    //     0xd7551c: add             x1, x1, HEAP, lsl #32
    // 0xd75520: tbnz            w1, #4, #0xd75534
    // 0xd75524: r1 = false
    //     0xd75524: add             x1, NULL, #0x30  ; false
    // 0xd75528: StoreField: r0->field_2b = r1
    //     0xd75528: stur            w1, [x0, #0x2b]
    // 0xd7552c: mov             x1, x0
    // 0xd75530: r0 = _animate()
    //     0xd75530: bl              #0xd75238  ; [package:flutter/src/cupertino/button.dart] _CupertinoButtonState::_animate
    // 0xd75534: ldur            x0, [fp, #-8]
    // 0xd75538: ldur            x2, [fp, #-0x10]
    // 0xd7553c: LoadField: r1 = r0->field_f
    //     0xd7553c: ldur            w1, [x0, #0xf]
    // 0xd75540: DecompressPointer r1
    //     0xd75540: add             x1, x1, HEAP, lsl #32
    // 0xd75544: cmp             w1, NULL
    // 0xd75548: b.eq            #0xd75604
    // 0xd7554c: r0 = renderObject()
    //     0xd7554c: bl              #0x123f10c  ; [package:flutter/src/widgets/framework.dart] Element::renderObject
    // 0xd75550: mov             x3, x0
    // 0xd75554: stur            x3, [fp, #-0x18]
    // 0xd75558: cmp             w3, NULL
    // 0xd7555c: b.eq            #0xd75608
    // 0xd75560: mov             x0, x3
    // 0xd75564: r2 = Null
    //     0xd75564: mov             x2, NULL
    // 0xd75568: r1 = Null
    //     0xd75568: mov             x1, NULL
    // 0xd7556c: r4 = LoadClassIdInstr(r0)
    //     0xd7556c: ldur            x4, [x0, #-1]
    //     0xd75570: ubfx            x4, x4, #0xc, #0x14
    // 0xd75574: r17 = -4710
    //     0xd75574: mov             x17, #-0x1266
    // 0xd75578: add             x4, x4, x17
    // 0xd7557c: cmp             x4, #0x109
    // 0xd75580: b.ls            #0xd75594
    // 0xd75584: r8 = RenderBox
    //     0xd75584: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0xd75588: r3 = Null
    //     0xd75588: add             x3, PP, #0xac, lsl #12  ; [pp+0xacce8] Null
    //     0xd7558c: ldr             x3, [x3, #0xce8]
    // 0xd75590: r0 = RenderBox()
    //     0xd75590: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0xd75594: ldur            x0, [fp, #-0x10]
    // 0xd75598: LoadField: r2 = r0->field_7
    //     0xd75598: ldur            w2, [x0, #7]
    // 0xd7559c: DecompressPointer r2
    //     0xd7559c: add             x2, x2, HEAP, lsl #32
    // 0xd755a0: ldur            x1, [fp, #-0x18]
    // 0xd755a4: r0 = globalToLocal()
    //     0xd755a4: bl              #0x867840  ; [package:flutter/src/rendering/box.dart] RenderBox::globalToLocal
    // 0xd755a8: ldur            x1, [fp, #-0x18]
    // 0xd755ac: stur            x0, [fp, #-0x10]
    // 0xd755b0: r0 = size()
    //     0xd755b0: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xd755b4: mov             x2, x0
    // 0xd755b8: r1 = Instance_Offset
    //     0xd755b8: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xd755bc: r0 = &()
    //     0xd755bc: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xd755c0: stur            x0, [fp, #-0x18]
    // 0xd755c4: r0 = tapMoveSlop()
    //     0xd755c4: bl              #0xd753c4  ; [package:flutter/src/cupertino/button.dart] CupertinoButton::tapMoveSlop
    // 0xd755c8: ldur            x1, [fp, #-0x18]
    // 0xd755cc: r0 = inflate()
    //     0xd755cc: bl              #0x882f50  ; [dart:ui] Rect::inflate
    // 0xd755d0: mov             x1, x0
    // 0xd755d4: ldur            x2, [fp, #-0x10]
    // 0xd755d8: r0 = contains()
    //     0xd755d8: bl              #0x81cce0  ; [dart:ui] Rect::contains
    // 0xd755dc: tbnz            w0, #4, #0xd755ec
    // 0xd755e0: ldur            x1, [fp, #-8]
    // 0xd755e4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd755e4: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd755e8: r0 = _handleTap()
    //     0xd755e8: bl              #0xd7560c  ; [package:flutter/src/cupertino/button.dart] _CupertinoButtonState::_handleTap
    // 0xd755ec: r0 = Null
    //     0xd755ec: mov             x0, NULL
    // 0xd755f0: LeaveFrame
    //     0xd755f0: mov             SP, fp
    //     0xd755f4: ldp             fp, lr, [SP], #0x10
    // 0xd755f8: ret
    //     0xd755f8: ret             
    // 0xd755fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd755fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd75600: b               #0xd754e4
    // 0xd75604: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd75604: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd75608: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd75608: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _handleTap(/* No info */) {
    // ** addr: 0xd7560c, size: 0xa8
    // 0xd7560c: EnterFrame
    //     0xd7560c: stp             fp, lr, [SP, #-0x10]!
    //     0xd75610: mov             fp, SP
    // 0xd75614: AllocStack(0x10)
    //     0xd75614: sub             SP, SP, #0x10
    // 0xd75618: SetupParameters(_CupertinoButtonState this /* r1 => r1, fp-0x8 */)
    //     0xd75618: stur            x1, [fp, #-8]
    // 0xd7561c: CheckStackOverflow
    //     0xd7561c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd75620: cmp             SP, x16
    //     0xd75624: b.ls            #0xd7569c
    // 0xd75628: LoadField: r0 = r1->field_b
    //     0xd75628: ldur            w0, [x1, #0xb]
    // 0xd7562c: DecompressPointer r0
    //     0xd7562c: add             x0, x0, HEAP, lsl #32
    // 0xd75630: cmp             w0, NULL
    // 0xd75634: b.eq            #0xd756a4
    // 0xd75638: LoadField: r2 = r0->field_1f
    //     0xd75638: ldur            w2, [x0, #0x1f]
    // 0xd7563c: DecompressPointer r2
    //     0xd7563c: add             x2, x2, HEAP, lsl #32
    // 0xd75640: cmp             w2, NULL
    // 0xd75644: b.eq            #0xd756a8
    // 0xd75648: str             x2, [SP]
    // 0xd7564c: mov             x0, x2
    // 0xd75650: ClosureCall
    //     0xd75650: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xd75654: ldur            x2, [x0, #0x1f]
    //     0xd75658: blr             x2
    // 0xd7565c: ldur            x0, [fp, #-8]
    // 0xd75660: LoadField: r1 = r0->field_f
    //     0xd75660: ldur            w1, [x0, #0xf]
    // 0xd75664: DecompressPointer r1
    //     0xd75664: add             x1, x1, HEAP, lsl #32
    // 0xd75668: cmp             w1, NULL
    // 0xd7566c: b.eq            #0xd756ac
    // 0xd75670: r0 = renderObject()
    //     0xd75670: bl              #0x123f10c  ; [package:flutter/src/widgets/framework.dart] Element::renderObject
    // 0xd75674: cmp             w0, NULL
    // 0xd75678: b.eq            #0xd756b0
    // 0xd7567c: mov             x1, x0
    // 0xd75680: r2 = Instance_TapSemanticEvent
    //     0xd75680: add             x2, PP, #0x90, lsl #12  ; [pp+0x904c0] Obj!TapSemanticEvent@129c0b1
    //     0xd75684: ldr             x2, [x2, #0x4c0]
    // 0xd75688: r0 = sendSemanticsEvent()
    //     0xd75688: bl              #0xd12090  ; [package:flutter/src/rendering/object.dart] RenderObject::sendSemanticsEvent
    // 0xd7568c: r0 = Null
    //     0xd7568c: mov             x0, NULL
    // 0xd75690: LeaveFrame
    //     0xd75690: mov             SP, fp
    //     0xd75694: ldp             fp, lr, [SP], #0x10
    // 0xd75698: ret
    //     0xd75698: ret             
    // 0xd7569c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd7569c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd756a0: b               #0xd75628
    // 0xd756a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd756a4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd756a8: r0 = NullErrorSharedWithoutFPURegs()
    //     0xd756a8: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xd756ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd756ac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd756b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd756b0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleTap(dynamic, [Intent?]) {
    // ** addr: 0xd756b4, size: 0x70
    // 0xd756b4: EnterFrame
    //     0xd756b4: stp             fp, lr, [SP, #-0x10]!
    //     0xd756b8: mov             fp, SP
    // 0xd756bc: AllocStack(0x8)
    //     0xd756bc: sub             SP, SP, #8
    // 0xd756c0: SetupParameters(_CupertinoButtonState this /* r0 */, [dynamic _ = Null /* r1 */])
    //     0xd756c0: ldur            w0, [x4, #0x13]
    //     0xd756c4: sub             x1, x0, #2
    //     0xd756c8: add             x0, fp, w1, sxtw #2
    //     0xd756cc: ldr             x0, [x0, #0x10]
    //     0xd756d0: cmp             w1, #2
    //     0xd756d4: b.lt            #0xd756e8
    //     0xd756d8: add             x2, fp, w1, sxtw #2
    //     0xd756dc: ldr             x2, [x2, #8]
    //     0xd756e0: mov             x1, x2
    //     0xd756e4: b               #0xd756ec
    //     0xd756e8: mov             x1, NULL
    //     0xd756ec: ldur            w2, [x0, #0x17]
    //     0xd756f0: add             x2, x2, HEAP, lsl #32
    // 0xd756f4: CheckStackOverflow
    //     0xd756f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd756f8: cmp             SP, x16
    //     0xd756fc: b.ls            #0xd7571c
    // 0xd75700: str             x1, [SP]
    // 0xd75704: mov             x1, x2
    // 0xd75708: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0xd75708: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0xd7570c: r0 = _handleTap()
    //     0xd7570c: bl              #0xd7560c  ; [package:flutter/src/cupertino/button.dart] _CupertinoButtonState::_handleTap
    // 0xd75710: LeaveFrame
    //     0xd75710: mov             SP, fp
    //     0xd75714: ldp             fp, lr, [SP], #0x10
    // 0xd75718: ret
    //     0xd75718: ret             
    // 0xd7571c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd7571c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd75720: b               #0xd75700
  }
  [closure] void _handleTapDown(dynamic, TapDownDetails) {
    // ** addr: 0xd75724, size: 0x3c
    // 0xd75724: EnterFrame
    //     0xd75724: stp             fp, lr, [SP, #-0x10]!
    //     0xd75728: mov             fp, SP
    // 0xd7572c: ldr             x0, [fp, #0x18]
    // 0xd75730: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd75730: ldur            w1, [x0, #0x17]
    // 0xd75734: DecompressPointer r1
    //     0xd75734: add             x1, x1, HEAP, lsl #32
    // 0xd75738: CheckStackOverflow
    //     0xd75738: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd7573c: cmp             SP, x16
    //     0xd75740: b.ls            #0xd75758
    // 0xd75744: ldr             x2, [fp, #0x10]
    // 0xd75748: r0 = _handleTapDown()
    //     0xd75748: bl              #0xd75760  ; [package:flutter/src/cupertino/button.dart] _CupertinoButtonState::_handleTapDown
    // 0xd7574c: LeaveFrame
    //     0xd7574c: mov             SP, fp
    //     0xd75750: ldp             fp, lr, [SP], #0x10
    // 0xd75754: ret
    //     0xd75754: ret             
    // 0xd75758: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd75758: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd7575c: b               #0xd75744
  }
  _ _handleTapDown(/* No info */) {
    // ** addr: 0xd75760, size: 0x80
    // 0xd75760: EnterFrame
    //     0xd75760: stp             fp, lr, [SP, #-0x10]!
    //     0xd75764: mov             fp, SP
    // 0xd75768: AllocStack(0x8)
    //     0xd75768: sub             SP, SP, #8
    // 0xd7576c: SetupParameters(_CupertinoButtonState this /* r1 => r1, fp-0x8 */)
    //     0xd7576c: stur            x1, [fp, #-8]
    // 0xd75770: CheckStackOverflow
    //     0xd75770: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd75774: cmp             SP, x16
    //     0xd75778: b.ls            #0xd757d8
    // 0xd7577c: r1 = 1
    //     0xd7577c: mov             x1, #1
    // 0xd75780: r0 = AllocateContext()
    //     0xd75780: bl              #0x13de838  ; AllocateContextStub
    // 0xd75784: mov             x1, x0
    // 0xd75788: ldur            x0, [fp, #-8]
    // 0xd7578c: StoreField: r1->field_f = r0
    //     0xd7578c: stur            w0, [x1, #0xf]
    // 0xd75790: mov             x2, x1
    // 0xd75794: r1 = Function '<anonymous closure>':.
    //     0xd75794: add             x1, PP, #0xac, lsl #12  ; [pp+0xaccf8] AnonymousClosure: (0xd1f70c), in [package:flutter/src/material/dropdown.dart] _DropdownButtonState::_handleTap (0xd1ee4c)
    //     0xd75798: ldr             x1, [x1, #0xcf8]
    // 0xd7579c: r0 = AllocateClosure()
    //     0xd7579c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd757a0: ldur            x1, [fp, #-8]
    // 0xd757a4: mov             x2, x0
    // 0xd757a8: r0 = setState()
    //     0xd757a8: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xd757ac: ldur            x1, [fp, #-8]
    // 0xd757b0: LoadField: r0 = r1->field_2b
    //     0xd757b0: ldur            w0, [x1, #0x2b]
    // 0xd757b4: DecompressPointer r0
    //     0xd757b4: add             x0, x0, HEAP, lsl #32
    // 0xd757b8: tbz             w0, #4, #0xd757c8
    // 0xd757bc: r0 = true
    //     0xd757bc: add             x0, NULL, #0x20  ; true
    // 0xd757c0: StoreField: r1->field_2b = r0
    //     0xd757c0: stur            w0, [x1, #0x2b]
    // 0xd757c4: r0 = _animate()
    //     0xd757c4: bl              #0xd75238  ; [package:flutter/src/cupertino/button.dart] _CupertinoButtonState::_animate
    // 0xd757c8: r0 = Null
    //     0xd757c8: mov             x0, NULL
    // 0xd757cc: LeaveFrame
    //     0xd757cc: mov             SP, fp
    //     0xd757d0: ldp             fp, lr, [SP], #0x10
    // 0xd757d4: ret
    //     0xd757d4: ret             
    // 0xd757d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd757d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd757dc: b               #0xd7577c
  }
  [closure] TapGestureRecognizer <anonymous closure>(dynamic) {
    // ** addr: 0xd757e0, size: 0x4c
    // 0xd757e0: EnterFrame
    //     0xd757e0: stp             fp, lr, [SP, #-0x10]!
    //     0xd757e4: mov             fp, SP
    // 0xd757e8: AllocStack(0x18)
    //     0xd757e8: sub             SP, SP, #0x18
    // 0xd757ec: CheckStackOverflow
    //     0xd757ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd757f0: cmp             SP, x16
    //     0xd757f4: b.ls            #0xd75824
    // 0xd757f8: r0 = TapGestureRecognizer()
    //     0xd757f8: bl              #0xc0a29c  ; AllocateTapGestureRecognizerStub -> TapGestureRecognizer (size=0x88)
    // 0xd757fc: stur            x0, [fp, #-8]
    // 0xd75800: stp             NULL, NULL, [SP]
    // 0xd75804: mov             x1, x0
    // 0xd75808: r4 = const [0, 0x3, 0x2, 0x1, postAcceptSlopTolerance, 0x2, supportedDevices, 0x1, null]
    //     0xd75808: add             x4, PP, #0x7a, lsl #12  ; [pp+0x7ab70] List(9) [0, 0x3, 0x2, 0x1, "postAcceptSlopTolerance", 0x2, "supportedDevices", 0x1, Null]
    //     0xd7580c: ldr             x4, [x4, #0xb70]
    // 0xd75810: r0 = BaseTapGestureRecognizer()
    //     0xd75810: bl              #0xc0a1bc  ; [package:flutter/src/gestures/tap.dart] BaseTapGestureRecognizer::BaseTapGestureRecognizer
    // 0xd75814: ldur            x0, [fp, #-8]
    // 0xd75818: LeaveFrame
    //     0xd75818: mov             SP, fp
    //     0xd7581c: ldp             fp, lr, [SP], #0x10
    // 0xd75820: ret
    //     0xd75820: ret             
    // 0xd75824: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd75824: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd75828: b               #0xd757f8
  }
  Map<Type, Action<Intent>> _actionMap(_CupertinoButtonState) {
    // ** addr: 0xd7582c, size: 0x14c
    // 0xd7582c: EnterFrame
    //     0xd7582c: stp             fp, lr, [SP, #-0x10]!
    //     0xd75830: mov             fp, SP
    // 0xd75834: AllocStack(0x28)
    //     0xd75834: sub             SP, SP, #0x28
    // 0xd75838: CheckStackOverflow
    //     0xd75838: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd7583c: cmp             SP, x16
    //     0xd75840: b.ls            #0xd75970
    // 0xd75844: r1 = Null
    //     0xd75844: mov             x1, NULL
    // 0xd75848: r2 = 4
    //     0xd75848: mov             x2, #4
    // 0xd7584c: r0 = AllocateArray()
    //     0xd7584c: bl              #0x13df928  ; AllocateArrayStub
    // 0xd75850: mov             x1, x0
    // 0xd75854: stur            x1, [fp, #-8]
    // 0xd75858: r16 = ActivateIntent
    //     0xd75858: add             x16, PP, #0x90, lsl #12  ; [pp+0x904d0] Type: ActivateIntent
    //     0xd7585c: ldr             x16, [x16, #0x4d0]
    // 0xd75860: StoreField: r1->field_f = r16
    //     0xd75860: stur            w16, [x1, #0xf]
    // 0xd75864: ldr             x0, [fp, #0x10]
    // 0xd75868: r2 = 60
    //     0xd75868: mov             x2, #0x3c
    // 0xd7586c: branchIfSmi(r0, 0xd75878)
    //     0xd7586c: tbz             w0, #0, #0xd75878
    // 0xd75870: r2 = LoadClassIdInstr(r0)
    //     0xd75870: ldur            x2, [x0, #-1]
    //     0xd75874: ubfx            x2, x2, #0xc, #0x14
    // 0xd75878: str             x0, [SP]
    // 0xd7587c: mov             x0, x2
    // 0xd75880: r0 = GDT[cid_x0 + -0x59]()
    //     0xd75880: sub             lr, x0, #0x59
    //     0xd75884: ldr             lr, [x21, lr, lsl #3]
    //     0xd75888: blr             lr
    // 0xd7588c: r1 = <ActivateIntent>
    //     0xd7588c: add             x1, PP, #0x90, lsl #12  ; [pp+0x904d8] TypeArguments: <ActivateIntent>
    //     0xd75890: ldr             x1, [x1, #0x4d8]
    // 0xd75894: stur            x0, [fp, #-0x10]
    // 0xd75898: r0 = CallbackAction()
    //     0xd75898: bl              #0xd126e8  ; AllocateCallbackActionStub -> CallbackAction<X0 bound Intent> (size=0x18)
    // 0xd7589c: mov             x2, x0
    // 0xd758a0: ldur            x0, [fp, #-0x10]
    // 0xd758a4: stur            x2, [fp, #-0x18]
    // 0xd758a8: StoreField: r2->field_13 = r0
    //     0xd758a8: stur            w0, [x2, #0x13]
    // 0xd758ac: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0xd758ac: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a7a0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0xd758b0: ldr             x1, [x1, #0x7a0]
    // 0xd758b4: r0 = ObserverList()
    //     0xd758b4: bl              #0x89f8bc  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0xd758b8: mov             x3, x0
    // 0xd758bc: r0 = false
    //     0xd758bc: add             x0, NULL, #0x30  ; false
    // 0xd758c0: stur            x3, [fp, #-0x10]
    // 0xd758c4: StoreField: r3->field_f = r0
    //     0xd758c4: stur            w0, [x3, #0xf]
    // 0xd758c8: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xd758cc: StoreField: r3->field_13 = r0
    //     0xd758cc: stur            w0, [x3, #0x13]
    // 0xd758d0: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0xd758d0: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a7a0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0xd758d4: ldr             x1, [x1, #0x7a0]
    // 0xd758d8: r2 = 0
    //     0xd758d8: mov             x2, #0
    // 0xd758dc: r0 = _GrowableList()
    //     0xd758dc: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xd758e0: ldur            x1, [fp, #-0x10]
    // 0xd758e4: StoreField: r1->field_b = r0
    //     0xd758e4: stur            w0, [x1, #0xb]
    //     0xd758e8: ldurb           w16, [x1, #-1]
    //     0xd758ec: ldurb           w17, [x0, #-1]
    //     0xd758f0: and             x16, x17, x16, lsr #2
    //     0xd758f4: tst             x16, HEAP, lsr #32
    //     0xd758f8: b.eq            #0xd75900
    //     0xd758fc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd75900: mov             x0, x1
    // 0xd75904: ldur            x1, [fp, #-0x18]
    // 0xd75908: StoreField: r1->field_b = r0
    //     0xd75908: stur            w0, [x1, #0xb]
    //     0xd7590c: ldurb           w16, [x1, #-1]
    //     0xd75910: ldurb           w17, [x0, #-1]
    //     0xd75914: and             x16, x17, x16, lsr #2
    //     0xd75918: tst             x16, HEAP, lsr #32
    //     0xd7591c: b.eq            #0xd75924
    //     0xd75920: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd75924: mov             x0, x1
    // 0xd75928: ldur            x1, [fp, #-8]
    // 0xd7592c: ArrayStore: r1[1] = r0  ; List_4
    //     0xd7592c: add             x25, x1, #0x13
    //     0xd75930: str             w0, [x25]
    //     0xd75934: tbz             w0, #0, #0xd75950
    //     0xd75938: ldurb           w16, [x1, #-1]
    //     0xd7593c: ldurb           w17, [x0, #-1]
    //     0xd75940: and             x16, x17, x16, lsr #2
    //     0xd75944: tst             x16, HEAP, lsr #32
    //     0xd75948: b.eq            #0xd75950
    //     0xd7594c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd75950: r16 = <Type, Action<Intent>>
    //     0xd75950: add             x16, PP, #0x84, lsl #12  ; [pp+0x84b80] TypeArguments: <Type, Action<Intent>>
    //     0xd75954: ldr             x16, [x16, #0xb80]
    // 0xd75958: ldur            lr, [fp, #-8]
    // 0xd7595c: stp             lr, x16, [SP]
    // 0xd75960: r0 = Map._fromLiteral()
    //     0xd75960: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xd75964: LeaveFrame
    //     0xd75964: mov             SP, fp
    //     0xd75968: ldp             fp, lr, [SP], #0x10
    // 0xd7596c: ret
    //     0xd7596c: ret             
    // 0xd75970: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd75970: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd75974: b               #0xd75844
  }
  static WidgetStateProperty<MouseCursor> _defaultCursor() {
    // ** addr: 0xd75978, size: 0x4c
    // 0xd75978: EnterFrame
    //     0xd75978: stp             fp, lr, [SP, #-0x10]!
    //     0xd7597c: mov             fp, SP
    // 0xd75980: AllocStack(0x10)
    //     0xd75980: sub             SP, SP, #0x10
    // 0xd75984: CheckStackOverflow
    //     0xd75984: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd75988: cmp             SP, x16
    //     0xd7598c: b.ls            #0xd759bc
    // 0xd75990: r1 = Function '<anonymous closure>': static.
    //     0xd75990: add             x1, PP, #0xac, lsl #12  ; [pp+0xacd08] AnonymousClosure: static (0xd759c4), in [package:flutter/src/cupertino/button.dart] _CupertinoButtonState::_defaultCursor (0xd75978)
    //     0xd75994: ldr             x1, [x1, #0xd08]
    // 0xd75998: r2 = Null
    //     0xd75998: mov             x2, NULL
    // 0xd7599c: r0 = AllocateClosure()
    //     0xd7599c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd759a0: r16 = <MouseCursor>
    //     0xd759a0: ldr             x16, [PP, #0x21a8]  ; [pp+0x21a8] TypeArguments: <MouseCursor>
    // 0xd759a4: stp             x0, x16, [SP]
    // 0xd759a8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd759a8: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd759ac: r0 = resolveWith()
    //     0xd759ac: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd759b0: LeaveFrame
    //     0xd759b0: mov             SP, fp
    //     0xd759b4: ldp             fp, lr, [SP], #0x10
    // 0xd759b8: ret
    //     0xd759b8: ret             
    // 0xd759bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd759bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd759c0: b               #0xd75990
  }
  [closure] static MouseCursor <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xd759c4, size: 0x54
    // 0xd759c4: EnterFrame
    //     0xd759c4: stp             fp, lr, [SP, #-0x10]!
    //     0xd759c8: mov             fp, SP
    // 0xd759cc: CheckStackOverflow
    //     0xd759cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd759d0: cmp             SP, x16
    //     0xd759d4: b.ls            #0xd75a10
    // 0xd759d8: ldr             x1, [fp, #0x10]
    // 0xd759dc: r0 = LoadClassIdInstr(r1)
    //     0xd759dc: ldur            x0, [x1, #-1]
    //     0xd759e0: ubfx            x0, x0, #0xc, #0x14
    // 0xd759e4: r2 = Instance_WidgetState
    //     0xd759e4: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xd759e8: ldr             x2, [x2, #0xa70]
    // 0xd759ec: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd759ec: mov             x17, #0x2929
    //     0xd759f0: movk            x17, #1, lsl #16
    //     0xd759f4: add             lr, x0, x17
    //     0xd759f8: ldr             lr, [x21, lr, lsl #3]
    //     0xd759fc: blr             lr
    // 0xd75a00: r0 = Instance__DeferringMouseCursor
    //     0xd75a00: ldr             x0, [PP, #0x2208]  ; [pp+0x2208] Obj!_DeferringMouseCursor@12b3241
    // 0xd75a04: LeaveFrame
    //     0xd75a04: mov             SP, fp
    //     0xd75a08: ldp             fp, lr, [SP], #0x10
    // 0xd75a0c: ret
    //     0xd75a0c: ret             
    // 0xd75a10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd75a10: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd75a14: b               #0xd759d8
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf44ec0, size: 0xc0
    // 0xf44ec0: EnterFrame
    //     0xf44ec0: stp             fp, lr, [SP, #-0x10]!
    //     0xf44ec4: mov             fp, SP
    // 0xf44ec8: AllocStack(0x10)
    //     0xf44ec8: sub             SP, SP, #0x10
    // 0xf44ecc: SetupParameters(_CupertinoButtonState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xf44ecc: mov             x4, x1
    //     0xf44ed0: mov             x3, x2
    //     0xf44ed4: stur            x1, [fp, #-8]
    //     0xf44ed8: stur            x2, [fp, #-0x10]
    // 0xf44edc: CheckStackOverflow
    //     0xf44edc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf44ee0: cmp             SP, x16
    //     0xf44ee4: b.ls            #0xf44f78
    // 0xf44ee8: mov             x0, x3
    // 0xf44eec: r2 = Null
    //     0xf44eec: mov             x2, NULL
    // 0xf44ef0: r1 = Null
    //     0xf44ef0: mov             x1, NULL
    // 0xf44ef4: r4 = 60
    //     0xf44ef4: mov             x4, #0x3c
    // 0xf44ef8: branchIfSmi(r0, 0xf44f04)
    //     0xf44ef8: tbz             w0, #0, #0xf44f04
    // 0xf44efc: r4 = LoadClassIdInstr(r0)
    //     0xf44efc: ldur            x4, [x0, #-1]
    //     0xf44f00: ubfx            x4, x4, #0xc, #0x14
    // 0xf44f04: r17 = 6528
    //     0xf44f04: mov             x17, #0x1980
    // 0xf44f08: cmp             x4, x17
    // 0xf44f0c: b.eq            #0xf44f24
    // 0xf44f10: r8 = CupertinoButton
    //     0xf44f10: add             x8, PP, #0xac, lsl #12  ; [pp+0xacd10] Type: CupertinoButton
    //     0xf44f14: ldr             x8, [x8, #0xd10]
    // 0xf44f18: r3 = Null
    //     0xf44f18: add             x3, PP, #0xac, lsl #12  ; [pp+0xacd18] Null
    //     0xf44f1c: ldr             x3, [x3, #0xd18]
    // 0xf44f20: r0 = CupertinoButton()
    //     0xf44f20: bl              #0xad6ad8  ; IsType_CupertinoButton_Stub
    // 0xf44f24: ldur            x3, [fp, #-8]
    // 0xf44f28: LoadField: r2 = r3->field_7
    //     0xf44f28: ldur            w2, [x3, #7]
    // 0xf44f2c: DecompressPointer r2
    //     0xf44f2c: add             x2, x2, HEAP, lsl #32
    // 0xf44f30: ldur            x0, [fp, #-0x10]
    // 0xf44f34: r1 = Null
    //     0xf44f34: mov             x1, NULL
    // 0xf44f38: cmp             w2, NULL
    // 0xf44f3c: b.eq            #0xf44f60
    // 0xf44f40: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf44f40: ldur            w4, [x2, #0x17]
    // 0xf44f44: DecompressPointer r4
    //     0xf44f44: add             x4, x4, HEAP, lsl #32
    // 0xf44f48: r8 = X0 bound StatefulWidget
    //     0xf44f48: add             x8, PP, #0x12, lsl #12  ; [pp+0x12498] TypeParameter: X0 bound StatefulWidget
    //     0xf44f4c: ldr             x8, [x8, #0x498]
    // 0xf44f50: LoadField: r9 = r4->field_7
    //     0xf44f50: ldur            x9, [x4, #7]
    // 0xf44f54: r3 = Null
    //     0xf44f54: add             x3, PP, #0xac, lsl #12  ; [pp+0xacd28] Null
    //     0xf44f58: ldr             x3, [x3, #0xd28]
    // 0xf44f5c: blr             x9
    // 0xf44f60: ldur            x1, [fp, #-8]
    // 0xf44f64: r0 = _setTween()
    //     0xf44f64: bl              #0xf44f80  ; [package:flutter/src/cupertino/button.dart] _CupertinoButtonState::_setTween
    // 0xf44f68: r0 = Null
    //     0xf44f68: mov             x0, NULL
    // 0xf44f6c: LeaveFrame
    //     0xf44f6c: mov             SP, fp
    //     0xf44f70: ldp             fp, lr, [SP], #0x10
    // 0xf44f74: ret
    //     0xf44f74: ret             
    // 0xf44f78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf44f78: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf44f7c: b               #0xf44ee8
  }
  _ _setTween(/* No info */) {
    // ** addr: 0xf44f80, size: 0x98
    // 0xf44f80: EnterFrame
    //     0xf44f80: stp             fp, lr, [SP, #-0x10]!
    //     0xf44f84: mov             fp, SP
    // 0xf44f88: LoadField: r2 = r1->field_1b
    //     0xf44f88: ldur            w2, [x1, #0x1b]
    // 0xf44f8c: DecompressPointer r2
    //     0xf44f8c: add             x2, x2, HEAP, lsl #32
    // 0xf44f90: LoadField: r3 = r1->field_b
    //     0xf44f90: ldur            w3, [x1, #0xb]
    // 0xf44f94: DecompressPointer r3
    //     0xf44f94: add             x3, x3, HEAP, lsl #32
    // 0xf44f98: cmp             w3, NULL
    // 0xf44f9c: b.eq            #0xf44ffc
    // 0xf44fa0: LoadField: d0 = r3->field_2f
    //     0xf44fa0: ldur            d0, [x3, #0x2f]
    // 0xf44fa4: r0 = inline_Allocate_Double()
    //     0xf44fa4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xf44fa8: add             x0, x0, #0x10
    //     0xf44fac: cmp             x1, x0
    //     0xf44fb0: b.ls            #0xf45000
    //     0xf44fb4: str             x0, [THR, #0x60]  ; THR::top
    //     0xf44fb8: sub             x0, x0, #0xf
    //     0xf44fbc: mov             x1, #0xe19c
    //     0xf44fc0: movk            x1, #3, lsl #16
    //     0xf44fc4: stur            x1, [x0, #-1]
    // 0xf44fc8: dmb             ishst
    // 0xf44fcc: StoreField: r0->field_7 = d0
    //     0xf44fcc: stur            d0, [x0, #7]
    // 0xf44fd0: StoreField: r2->field_f = r0
    //     0xf44fd0: stur            w0, [x2, #0xf]
    //     0xf44fd4: ldurb           w16, [x2, #-1]
    //     0xf44fd8: ldurb           w17, [x0, #-1]
    //     0xf44fdc: and             x16, x17, x16, lsr #2
    //     0xf44fe0: tst             x16, HEAP, lsr #32
    //     0xf44fe4: b.eq            #0xf44fec
    //     0xf44fe8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf44fec: r0 = Null
    //     0xf44fec: mov             x0, NULL
    // 0xf44ff0: LeaveFrame
    //     0xf44ff0: mov             SP, fp
    //     0xf44ff4: ldp             fp, lr, [SP], #0x10
    // 0xf44ff8: ret
    //     0xf44ff8: ret             
    // 0xf44ffc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf44ffc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf45000: SaveReg d0
    //     0xf45000: str             q0, [SP, #-0x10]!
    // 0xf45004: SaveReg r2
    //     0xf45004: str             x2, [SP, #-8]!
    // 0xf45008: r0 = AllocateDouble()
    //     0xf45008: bl              #0x13df878  ; AllocateDoubleStub
    // 0xf4500c: RestoreReg r2
    //     0xf4500c: ldr             x2, [SP], #8
    // 0xf45010: RestoreReg d0
    //     0xf45010: ldr             q0, [SP], #0x10
    // 0xf45014: b               #0xf44fcc
  }
  _ initState(/* No info */) {
    // ** addr: 0xf86cb0, size: 0x118
    // 0xf86cb0: EnterFrame
    //     0xf86cb0: stp             fp, lr, [SP, #-0x10]!
    //     0xf86cb4: mov             fp, SP
    // 0xf86cb8: AllocStack(0x28)
    //     0xf86cb8: sub             SP, SP, #0x28
    // 0xf86cbc: r0 = false
    //     0xf86cbc: add             x0, NULL, #0x30  ; false
    // 0xf86cc0: mov             x2, x1
    // 0xf86cc4: stur            x1, [fp, #-8]
    // 0xf86cc8: CheckStackOverflow
    //     0xf86cc8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf86ccc: cmp             SP, x16
    //     0xf86cd0: b.ls            #0xf86dc0
    // 0xf86cd4: StoreField: r2->field_27 = r0
    //     0xf86cd4: stur            w0, [x2, #0x27]
    // 0xf86cd8: r1 = <double>
    //     0xf86cd8: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf86cdc: r0 = AnimationController()
    //     0xf86cdc: bl              #0x87522c  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0xf86ce0: stur            x0, [fp, #-0x10]
    // 0xf86ce4: r16 = Instance_Duration
    //     0xf86ce4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xf86ce8: ldr             x16, [x16, #0x318]
    // 0xf86cec: r30 = 0.000000
    //     0xf86cec: ldr             lr, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xf86cf0: stp             lr, x16, [SP]
    // 0xf86cf4: mov             x1, x0
    // 0xf86cf8: ldur            x2, [fp, #-8]
    // 0xf86cfc: r4 = const [0, 0x4, 0x2, 0x2, duration, 0x2, value, 0x3, null]
    //     0xf86cfc: add             x4, PP, #0x8d, lsl #12  ; [pp+0x8d6f8] List(9) [0, 0x4, 0x2, 0x2, "duration", 0x2, "value", 0x3, Null]
    //     0xf86d00: ldr             x4, [x4, #0x6f8]
    // 0xf86d04: r0 = AnimationController()
    //     0xf86d04: bl              #0x874ea4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0xf86d08: ldur            x0, [fp, #-0x10]
    // 0xf86d0c: ldur            x2, [fp, #-8]
    // 0xf86d10: StoreField: r2->field_1f = r0
    //     0xf86d10: stur            w0, [x2, #0x1f]
    //     0xf86d14: ldurb           w16, [x2, #-1]
    //     0xf86d18: ldurb           w17, [x0, #-1]
    //     0xf86d1c: and             x16, x17, x16, lsr #2
    //     0xf86d20: tst             x16, HEAP, lsr #32
    //     0xf86d24: b.eq            #0xf86d2c
    //     0xf86d28: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf86d2c: r1 = <double>
    //     0xf86d2c: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf86d30: r0 = CurveTween()
    //     0xf86d30: bl              #0xb280f4  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0xf86d34: mov             x1, x0
    // 0xf86d38: r0 = Instance__DecelerateCurve
    //     0xf86d38: ldr             x0, [PP, #0x5150]  ; [pp+0x5150] Obj!_DecelerateCurve@129f3d1
    // 0xf86d3c: StoreField: r1->field_b = r0
    //     0xf86d3c: stur            w0, [x1, #0xb]
    // 0xf86d40: ldur            x2, [fp, #-0x10]
    // 0xf86d44: r0 = animate()
    //     0xf86d44: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xf86d48: mov             x4, x0
    // 0xf86d4c: ldur            x3, [fp, #-8]
    // 0xf86d50: stur            x4, [fp, #-0x18]
    // 0xf86d54: LoadField: r5 = r3->field_1b
    //     0xf86d54: ldur            w5, [x3, #0x1b]
    // 0xf86d58: DecompressPointer r5
    //     0xf86d58: add             x5, x5, HEAP, lsl #32
    // 0xf86d5c: mov             x0, x4
    // 0xf86d60: stur            x5, [fp, #-0x10]
    // 0xf86d64: r2 = Null
    //     0xf86d64: mov             x2, NULL
    // 0xf86d68: r1 = Null
    //     0xf86d68: mov             x1, NULL
    // 0xf86d6c: r8 = Animation<double>
    //     0xf86d6c: add             x8, PP, #0x80, lsl #12  ; [pp+0x809a8] Type: Animation<double>
    //     0xf86d70: ldr             x8, [x8, #0x9a8]
    // 0xf86d74: r3 = Null
    //     0xf86d74: add             x3, PP, #0xac, lsl #12  ; [pp+0xacd38] Null
    //     0xf86d78: ldr             x3, [x3, #0xd38]
    // 0xf86d7c: r0 = Animation<double>()
    //     0xf86d7c: bl              #0x829684  ; IsType_Animation<double>_Stub
    // 0xf86d80: ldur            x1, [fp, #-0x10]
    // 0xf86d84: ldur            x2, [fp, #-0x18]
    // 0xf86d88: r0 = animate()
    //     0xf86d88: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xf86d8c: ldur            x1, [fp, #-8]
    // 0xf86d90: StoreField: r1->field_23 = r0
    //     0xf86d90: stur            w0, [x1, #0x23]
    //     0xf86d94: ldurb           w16, [x1, #-1]
    //     0xf86d98: ldurb           w17, [x0, #-1]
    //     0xf86d9c: and             x16, x17, x16, lsr #2
    //     0xf86da0: tst             x16, HEAP, lsr #32
    //     0xf86da4: b.eq            #0xf86dac
    //     0xf86da8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf86dac: r0 = _setTween()
    //     0xf86dac: bl              #0xf44f80  ; [package:flutter/src/cupertino/button.dart] _CupertinoButtonState::_setTween
    // 0xf86db0: r0 = Null
    //     0xf86db0: mov             x0, NULL
    // 0xf86db4: LeaveFrame
    //     0xf86db4: mov             SP, fp
    //     0xf86db8: ldp             fp, lr, [SP], #0x10
    // 0xf86dbc: ret
    //     0xf86dbc: ret             
    // 0xf86dc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf86dc0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf86dc4: b               #0xf86cd4
  }
  _ _CupertinoButtonState(/* No info */) {
    // ** addr: 0xfa01cc, size: 0x74
    // 0xfa01cc: EnterFrame
    //     0xfa01cc: stp             fp, lr, [SP, #-0x10]!
    //     0xfa01d0: mov             fp, SP
    // 0xfa01d4: AllocStack(0x8)
    //     0xfa01d4: sub             SP, SP, #8
    // 0xfa01d8: ldr             x2, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa01dc: r0 = false
    //     0xfa01dc: add             x0, NULL, #0x30  ; false
    // 0xfa01e0: mov             x3, x1
    // 0xfa01e4: stur            x1, [fp, #-8]
    // 0xfa01e8: StoreField: r3->field_1f = r2
    //     0xfa01e8: stur            w2, [x3, #0x1f]
    // 0xfa01ec: StoreField: r3->field_23 = r2
    //     0xfa01ec: stur            w2, [x3, #0x23]
    // 0xfa01f0: StoreField: r3->field_27 = r2
    //     0xfa01f0: stur            w2, [x3, #0x27]
    // 0xfa01f4: StoreField: r3->field_2b = r0
    //     0xfa01f4: stur            w0, [x3, #0x2b]
    // 0xfa01f8: StoreField: r3->field_2f = r0
    //     0xfa01f8: stur            w0, [x3, #0x2f]
    // 0xfa01fc: StoreField: r3->field_33 = r2
    //     0xfa01fc: stur            w2, [x3, #0x33]
    // 0xfa0200: r1 = <double>
    //     0xfa0200: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xfa0204: r0 = Tween()
    //     0xfa0204: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xfa0208: r1 = 1.000000
    //     0xfa0208: ldr             x1, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xfa020c: StoreField: r0->field_b = r1
    //     0xfa020c: stur            w1, [x0, #0xb]
    // 0xfa0210: ldur            x1, [fp, #-8]
    // 0xfa0214: StoreField: r1->field_1b = r0
    //     0xfa0214: stur            w0, [x1, #0x1b]
    //     0xfa0218: ldurb           w16, [x1, #-1]
    //     0xfa021c: ldurb           w17, [x0, #-1]
    //     0xfa0220: and             x16, x17, x16, lsr #2
    //     0xfa0224: tst             x16, HEAP, lsr #32
    //     0xfa0228: b.eq            #0xfa0230
    //     0xfa022c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfa0230: r0 = Null
    //     0xfa0230: mov             x0, NULL
    // 0xfa0234: LeaveFrame
    //     0xfa0234: mov             SP, fp
    //     0xfa0238: ldp             fp, lr, [SP], #0x10
    // 0xfa023c: ret
    //     0xfa023c: ret             
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10e11b4, size: 0x64
    // 0x10e11b4: EnterFrame
    //     0x10e11b4: stp             fp, lr, [SP, #-0x10]!
    //     0x10e11b8: mov             fp, SP
    // 0x10e11bc: AllocStack(0x8)
    //     0x10e11bc: sub             SP, SP, #8
    // 0x10e11c0: SetupParameters(_CupertinoButtonState this /* r1 => r0, fp-0x8 */)
    //     0x10e11c0: mov             x0, x1
    //     0x10e11c4: stur            x1, [fp, #-8]
    // 0x10e11c8: CheckStackOverflow
    //     0x10e11c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e11cc: cmp             SP, x16
    //     0x10e11d0: b.ls            #0x10e1204
    // 0x10e11d4: LoadField: r1 = r0->field_1f
    //     0x10e11d4: ldur            w1, [x0, #0x1f]
    // 0x10e11d8: DecompressPointer r1
    //     0x10e11d8: add             x1, x1, HEAP, lsl #32
    // 0x10e11dc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10e11e0: cmp             w1, w16
    // 0x10e11e4: b.eq            #0x10e120c
    // 0x10e11e8: r0 = dispose()
    //     0x10e11e8: bl              #0x9164f4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x10e11ec: ldur            x1, [fp, #-8]
    // 0x10e11f0: r0 = dispose()
    //     0x10e11f0: bl              #0x10e1218  ; [dart:mixin_deduplication] _MixinApplication385&State&SingleTickerProviderStateMixin::dispose
    // 0x10e11f4: r0 = Null
    //     0x10e11f4: mov             x0, NULL
    // 0x10e11f8: LeaveFrame
    //     0x10e11f8: mov             SP, fp
    //     0x10e11fc: ldp             fp, lr, [SP], #0x10
    // 0x10e1200: ret
    //     0x10e1200: ret             
    // 0x10e1204: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e1204: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e1208: b               #0x10e11d4
    // 0x10e120c: r9 = _animationController
    //     0x10e120c: add             x9, PP, #0xa4, lsl #12  ; [pp+0xa4080] Field <_CupertinoButtonState@292145554._animationController@292145554>: late (offset: 0x20)
    //     0x10e1210: ldr             x9, [x9, #0x80]
    // 0x10e1214: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x10e1214: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  dynamic _handleTap(dynamic) {
    // ** addr: 0x1262524, size: 0x24
    // 0x1262524: EnterFrame
    //     0x1262524: stp             fp, lr, [SP, #-0x10]!
    //     0x1262528: mov             fp, SP
    // 0x126252c: ldr             x2, [fp, #0x10]
    // 0x1262530: r1 = Function '_handleTap@292145554':.
    //     0x1262530: add             x1, PP, #0xcc, lsl #12  ; [pp+0xcc890] AnonymousClosure: (0xd756b4), in [package:flutter/src/cupertino/button.dart] _CupertinoButtonState::_handleTap (0xd7560c)
    //     0x1262534: ldr             x1, [x1, #0x890]
    // 0x1262538: r0 = AllocateClosure()
    //     0x1262538: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x126253c: LeaveFrame
    //     0x126253c: mov             SP, fp
    //     0x1262540: ldp             fp, lr, [SP], #0x10
    // 0x1262544: ret
    //     0x1262544: ret             
  }
}

// class id: 6528, size: 0x5c, field offset: 0xc
//   const constructor, 
class CupertinoButton extends StatefulWidget {

  static double tapMoveSlop() {
    // ** addr: 0xd753c4, size: 0xc
    // 0xd753c4: d0 = 70.000000
    //     0xd753c4: add             x17, PP, #0x13, lsl #12  ; [pp+0x137a8] IMM: double(70) from 0x4051800000000000
    //     0xd753c8: ldr             d0, [x17, #0x7a8]
    // 0xd753cc: ret
    //     0xd753cc: ret             
  }
  _ createState(/* No info */) {
    // ** addr: 0xfa0184, size: 0x48
    // 0xfa0184: EnterFrame
    //     0xfa0184: stp             fp, lr, [SP, #-0x10]!
    //     0xfa0188: mov             fp, SP
    // 0xfa018c: AllocStack(0x8)
    //     0xfa018c: sub             SP, SP, #8
    // 0xfa0190: CheckStackOverflow
    //     0xfa0190: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa0194: cmp             SP, x16
    //     0xfa0198: b.ls            #0xfa01c4
    // 0xfa019c: r1 = <CupertinoButton>
    //     0xfa019c: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2c08] TypeArguments: <CupertinoButton>
    //     0xfa01a0: ldr             x1, [x1, #0xc08]
    // 0xfa01a4: r0 = _CupertinoButtonState()
    //     0xfa01a4: bl              #0xfa0240  ; Allocate_CupertinoButtonStateStub -> _CupertinoButtonState (size=0x38)
    // 0xfa01a8: mov             x1, x0
    // 0xfa01ac: stur            x0, [fp, #-8]
    // 0xfa01b0: r0 = _CupertinoButtonState()
    //     0xfa01b0: bl              #0xfa01cc  ; [package:flutter/src/cupertino/button.dart] _CupertinoButtonState::_CupertinoButtonState
    // 0xfa01b4: ldur            x0, [fp, #-8]
    // 0xfa01b8: LeaveFrame
    //     0xfa01b8: mov             SP, fp
    //     0xfa01bc: ldp             fp, lr, [SP], #0x10
    // 0xfa01c0: ret
    //     0xfa01c0: ret             
    // 0xfa01c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa01c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa01c8: b               #0xfa019c
  }
}

// class id: 8319, size: 0x14, field offset: 0x14
enum _CupertinoButtonStyle extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11a96d0, size: 0x64
    // 0x11a96d0: EnterFrame
    //     0x11a96d0: stp             fp, lr, [SP, #-0x10]!
    //     0x11a96d4: mov             fp, SP
    // 0x11a96d8: AllocStack(0x10)
    //     0x11a96d8: sub             SP, SP, #0x10
    // 0x11a96dc: SetupParameters(_CupertinoButtonStyle this /* r1 => r0, fp-0x8 */)
    //     0x11a96dc: mov             x0, x1
    //     0x11a96e0: stur            x1, [fp, #-8]
    // 0x11a96e4: CheckStackOverflow
    //     0x11a96e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a96e8: cmp             SP, x16
    //     0x11a96ec: b.ls            #0x11a972c
    // 0x11a96f0: r1 = Null
    //     0x11a96f0: mov             x1, NULL
    // 0x11a96f4: r2 = 4
    //     0x11a96f4: mov             x2, #4
    // 0x11a96f8: r0 = AllocateArray()
    //     0x11a96f8: bl              #0x13df928  ; AllocateArrayStub
    // 0x11a96fc: r16 = "_CupertinoButtonStyle."
    //     0x11a96fc: add             x16, PP, #0xa2, lsl #12  ; [pp+0xa2bf8] "_CupertinoButtonStyle."
    //     0x11a9700: ldr             x16, [x16, #0xbf8]
    // 0x11a9704: StoreField: r0->field_f = r16
    //     0x11a9704: stur            w16, [x0, #0xf]
    // 0x11a9708: ldur            x1, [fp, #-8]
    // 0x11a970c: LoadField: r2 = r1->field_f
    //     0x11a970c: ldur            w2, [x1, #0xf]
    // 0x11a9710: DecompressPointer r2
    //     0x11a9710: add             x2, x2, HEAP, lsl #32
    // 0x11a9714: StoreField: r0->field_13 = r2
    //     0x11a9714: stur            w2, [x0, #0x13]
    // 0x11a9718: str             x0, [SP]
    // 0x11a971c: r0 = _interpolate()
    //     0x11a971c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11a9720: LeaveFrame
    //     0x11a9720: mov             SP, fp
    //     0x11a9724: ldp             fp, lr, [SP], #0x10
    // 0x11a9728: ret
    //     0x11a9728: ret             
    // 0x11a972c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a972c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a9730: b               #0x11a96f0
  }
}

// class id: 8320, size: 0x14, field offset: 0x14
enum CupertinoButtonSize extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11a966c, size: 0x64
    // 0x11a966c: EnterFrame
    //     0x11a966c: stp             fp, lr, [SP, #-0x10]!
    //     0x11a9670: mov             fp, SP
    // 0x11a9674: AllocStack(0x10)
    //     0x11a9674: sub             SP, SP, #0x10
    // 0x11a9678: SetupParameters(CupertinoButtonSize this /* r1 => r0, fp-0x8 */)
    //     0x11a9678: mov             x0, x1
    //     0x11a967c: stur            x1, [fp, #-8]
    // 0x11a9680: CheckStackOverflow
    //     0x11a9680: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a9684: cmp             SP, x16
    //     0x11a9688: b.ls            #0x11a96c8
    // 0x11a968c: r1 = Null
    //     0x11a968c: mov             x1, NULL
    // 0x11a9690: r2 = 4
    //     0x11a9690: mov             x2, #4
    // 0x11a9694: r0 = AllocateArray()
    //     0x11a9694: bl              #0x13df928  ; AllocateArrayStub
    // 0x11a9698: r16 = "CupertinoButtonSize."
    //     0x11a9698: add             x16, PP, #0xa2, lsl #12  ; [pp+0xa2c00] "CupertinoButtonSize."
    //     0x11a969c: ldr             x16, [x16, #0xc00]
    // 0x11a96a0: StoreField: r0->field_f = r16
    //     0x11a96a0: stur            w16, [x0, #0xf]
    // 0x11a96a4: ldur            x1, [fp, #-8]
    // 0x11a96a8: LoadField: r2 = r1->field_f
    //     0x11a96a8: ldur            w2, [x1, #0xf]
    // 0x11a96ac: DecompressPointer r2
    //     0x11a96ac: add             x2, x2, HEAP, lsl #32
    // 0x11a96b0: StoreField: r0->field_13 = r2
    //     0x11a96b0: stur            w2, [x0, #0x13]
    // 0x11a96b4: str             x0, [SP]
    // 0x11a96b8: r0 = _interpolate()
    //     0x11a96b8: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11a96bc: LeaveFrame
    //     0x11a96bc: mov             SP, fp
    //     0x11a96c0: ldp             fp, lr, [SP], #0x10
    // 0x11a96c4: ret
    //     0x11a96c4: ret             
    // 0x11a96c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a96c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a96cc: b               #0x11a968c
  }
}
