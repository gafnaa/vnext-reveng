// lib: , url: package:flutter/src/cupertino/desktop_text_selection_toolbar.dart

// class id: 1048776, size: 0x8
class :: {
}

// class id: 6209, size: 0x14, field offset: 0xc
//   const constructor, 
class CupertinoDesktopTextSelectionToolbar extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfaba18, size: 0x160
    // 0xfaba18: EnterFrame
    //     0xfaba18: stp             fp, lr, [SP, #-0x10]!
    //     0xfaba1c: mov             fp, SP
    // 0xfaba20: AllocStack(0x30)
    //     0xfaba20: sub             SP, SP, #0x30
    // 0xfaba24: SetupParameters(CupertinoDesktopTextSelectionToolbar this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xfaba24: mov             x0, x2
    //     0xfaba28: stur            x2, [fp, #-0x10]
    //     0xfaba2c: mov             x2, x1
    //     0xfaba30: stur            x1, [fp, #-8]
    // 0xfaba34: CheckStackOverflow
    //     0xfaba34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfaba38: cmp             SP, x16
    //     0xfaba3c: b.ls            #0xfabb70
    // 0xfaba40: mov             x1, x0
    // 0xfaba44: r0 = paddingOf()
    //     0xfaba44: bl              #0xd1a984  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::paddingOf
    // 0xfaba48: LoadField: d0 = r0->field_f
    //     0xfaba48: ldur            d0, [x0, #0xf]
    // 0xfaba4c: d1 = 8.000000
    //     0xfaba4c: fmov            d1, #8.00000000
    // 0xfaba50: fadd            d2, d0, d1
    // 0xfaba54: stur            d2, [fp, #-0x30]
    // 0xfaba58: r0 = Offset()
    //     0xfaba58: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xfaba5c: d0 = 8.000000
    //     0xfaba5c: fmov            d0, #8.00000000
    // 0xfaba60: stur            x0, [fp, #-0x18]
    // 0xfaba64: StoreField: r0->field_7 = d0
    //     0xfaba64: stur            d0, [x0, #7]
    // 0xfaba68: ldur            d1, [fp, #-0x30]
    // 0xfaba6c: StoreField: r0->field_f = d1
    //     0xfaba6c: stur            d1, [x0, #0xf]
    // 0xfaba70: r0 = EdgeInsets()
    //     0xfaba70: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xfaba74: d0 = 8.000000
    //     0xfaba74: fmov            d0, #8.00000000
    // 0xfaba78: stur            x0, [fp, #-0x20]
    // 0xfaba7c: StoreField: r0->field_7 = d0
    //     0xfaba7c: stur            d0, [x0, #7]
    // 0xfaba80: ldur            d1, [fp, #-0x30]
    // 0xfaba84: StoreField: r0->field_f = d1
    //     0xfaba84: stur            d1, [x0, #0xf]
    // 0xfaba88: ArrayStore: r0[0] = d0  ; List_8
    //     0xfaba88: stur            d0, [x0, #0x17]
    // 0xfaba8c: StoreField: r0->field_1f = d0
    //     0xfaba8c: stur            d0, [x0, #0x1f]
    // 0xfaba90: ldur            x3, [fp, #-8]
    // 0xfaba94: LoadField: r1 = r3->field_b
    //     0xfaba94: ldur            w1, [x3, #0xb]
    // 0xfaba98: DecompressPointer r1
    //     0xfaba98: add             x1, x1, HEAP, lsl #32
    // 0xfaba9c: ldur            x2, [fp, #-0x18]
    // 0xfabaa0: r0 = -()
    //     0xfabaa0: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0xfabaa4: stur            x0, [fp, #-0x18]
    // 0xfabaa8: r0 = DesktopTextSelectionToolbarLayoutDelegate()
    //     0xfabaa8: bl              #0xfabe60  ; AllocateDesktopTextSelectionToolbarLayoutDelegateStub -> DesktopTextSelectionToolbarLayoutDelegate (size=0x10)
    // 0xfabaac: mov             x1, x0
    // 0xfabab0: ldur            x0, [fp, #-0x18]
    // 0xfabab4: stur            x1, [fp, #-0x28]
    // 0xfabab8: StoreField: r1->field_b = r0
    //     0xfabab8: stur            w0, [x1, #0xb]
    // 0xfababc: ldur            x0, [fp, #-8]
    // 0xfabac0: LoadField: r2 = r0->field_f
    //     0xfabac0: ldur            w2, [x0, #0xf]
    // 0xfabac4: DecompressPointer r2
    //     0xfabac4: add             x2, x2, HEAP, lsl #32
    // 0xfabac8: stur            x2, [fp, #-0x18]
    // 0xfabacc: r0 = Column()
    //     0xfabacc: bl              #0x8a5b1c  ; AllocateColumnStub -> Column (size=0x38)
    // 0xfabad0: mov             x1, x0
    // 0xfabad4: r0 = Instance_Axis
    //     0xfabad4: ldr             x0, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xfabad8: StoreField: r1->field_f = r0
    //     0xfabad8: stur            w0, [x1, #0xf]
    // 0xfabadc: r0 = Instance_MainAxisAlignment
    //     0xfabadc: add             x0, PP, #0x15, lsl #12  ; [pp+0x15820] Obj!MainAxisAlignment@12c4541
    //     0xfabae0: ldr             x0, [x0, #0x820]
    // 0xfabae4: StoreField: r1->field_13 = r0
    //     0xfabae4: stur            w0, [x1, #0x13]
    // 0xfabae8: r0 = Instance_MainAxisSize
    //     0xfabae8: add             x0, PP, #0x17, lsl #12  ; [pp+0x17200] Obj!MainAxisSize@12c4601
    //     0xfabaec: ldr             x0, [x0, #0x200]
    // 0xfabaf0: ArrayStore: r1[0] = r0  ; List_4
    //     0xfabaf0: stur            w0, [x1, #0x17]
    // 0xfabaf4: r0 = Instance_CrossAxisAlignment
    //     0xfabaf4: add             x0, PP, #0x15, lsl #12  ; [pp+0x15888] Obj!CrossAxisAlignment@12c44a1
    //     0xfabaf8: ldr             x0, [x0, #0x888]
    // 0xfabafc: StoreField: r1->field_1b = r0
    //     0xfabafc: stur            w0, [x1, #0x1b]
    // 0xfabb00: r0 = Instance_VerticalDirection
    //     0xfabb00: add             x0, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xfabb04: ldr             x0, [x0, #0x838]
    // 0xfabb08: StoreField: r1->field_23 = r0
    //     0xfabb08: stur            w0, [x1, #0x23]
    // 0xfabb0c: r0 = Instance_Clip
    //     0xfabb0c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xfabb10: ldr             x0, [x0, #0x840]
    // 0xfabb14: StoreField: r1->field_2b = r0
    //     0xfabb14: stur            w0, [x1, #0x2b]
    // 0xfabb18: StoreField: r1->field_2f = rZR
    //     0xfabb18: stur            xzr, [x1, #0x2f]
    // 0xfabb1c: ldur            x0, [fp, #-0x18]
    // 0xfabb20: StoreField: r1->field_b = r0
    //     0xfabb20: stur            w0, [x1, #0xb]
    // 0xfabb24: mov             x2, x1
    // 0xfabb28: ldur            x1, [fp, #-0x10]
    // 0xfabb2c: r0 = _defaultToolbarBuilder()
    //     0xfabb2c: bl              #0xfabb78  ; [package:flutter/src/cupertino/desktop_text_selection_toolbar.dart] CupertinoDesktopTextSelectionToolbar::_defaultToolbarBuilder
    // 0xfabb30: stur            x0, [fp, #-8]
    // 0xfabb34: r0 = CustomSingleChildLayout()
    //     0xfabb34: bl              #0xd70b7c  ; AllocateCustomSingleChildLayoutStub -> CustomSingleChildLayout (size=0x14)
    // 0xfabb38: mov             x1, x0
    // 0xfabb3c: ldur            x0, [fp, #-0x28]
    // 0xfabb40: stur            x1, [fp, #-0x10]
    // 0xfabb44: StoreField: r1->field_f = r0
    //     0xfabb44: stur            w0, [x1, #0xf]
    // 0xfabb48: ldur            x0, [fp, #-8]
    // 0xfabb4c: StoreField: r1->field_b = r0
    //     0xfabb4c: stur            w0, [x1, #0xb]
    // 0xfabb50: r0 = Padding()
    //     0xfabb50: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xfabb54: ldur            x1, [fp, #-0x20]
    // 0xfabb58: StoreField: r0->field_f = r1
    //     0xfabb58: stur            w1, [x0, #0xf]
    // 0xfabb5c: ldur            x1, [fp, #-0x10]
    // 0xfabb60: StoreField: r0->field_b = r1
    //     0xfabb60: stur            w1, [x0, #0xb]
    // 0xfabb64: LeaveFrame
    //     0xfabb64: mov             SP, fp
    //     0xfabb68: ldp             fp, lr, [SP], #0x10
    // 0xfabb6c: ret
    //     0xfabb6c: ret             
    // 0xfabb70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfabb70: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfabb74: b               #0xfaba40
  }
  static _ _defaultToolbarBuilder(/* No info */) {
    // ** addr: 0xfabb78, size: 0x1e0
    // 0xfabb78: EnterFrame
    //     0xfabb78: stp             fp, lr, [SP, #-0x10]!
    //     0xfabb7c: mov             fp, SP
    // 0xfabb80: AllocStack(0x48)
    //     0xfabb80: sub             SP, SP, #0x48
    // 0xfabb84: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xfabb84: mov             x0, x1
    //     0xfabb88: stur            x1, [fp, #-8]
    //     0xfabb8c: stur            x2, [fp, #-0x10]
    // 0xfabb90: CheckStackOverflow
    //     0xfabb90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfabb94: cmp             SP, x16
    //     0xfabb98: b.ls            #0xfabd50
    // 0xfabb9c: r0 = _matrixWithSaturation()
    //     0xfabb9c: bl              #0xfabd58  ; [package:flutter/src/cupertino/desktop_text_selection_toolbar.dart] CupertinoDesktopTextSelectionToolbar::_matrixWithSaturation
    // 0xfabba0: stur            x0, [fp, #-0x18]
    // 0xfabba4: r0 = ColorFilter()
    //     0xfabba4: bl              #0xce353c  ; AllocateColorFilterStub -> ColorFilter (size=0x1c)
    // 0xfabba8: mov             x1, x0
    // 0xfabbac: ldur            x0, [fp, #-0x18]
    // 0xfabbb0: stur            x1, [fp, #-0x20]
    // 0xfabbb4: StoreField: r1->field_f = r0
    //     0xfabbb4: stur            w0, [x1, #0xf]
    // 0xfabbb8: r0 = 2
    //     0xfabbb8: mov             x0, #2
    // 0xfabbbc: StoreField: r1->field_13 = r0
    //     0xfabbbc: stur            x0, [x1, #0x13]
    // 0xfabbc0: r0 = _GaussianBlurImageFilter()
    //     0xfabbc0: bl              #0x9191c8  ; Allocate_GaussianBlurImageFilterStub -> _GaussianBlurImageFilter (size=0x24)
    // 0xfabbc4: mov             x1, x0
    // 0xfabbc8: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xfabbcc: StoreField: r1->field_1f = r0
    //     0xfabbcc: stur            w0, [x1, #0x1f]
    // 0xfabbd0: d0 = 20.000000
    //     0xfabbd0: fmov            d0, #20.00000000
    // 0xfabbd4: StoreField: r1->field_7 = d0
    //     0xfabbd4: stur            d0, [x1, #7]
    // 0xfabbd8: StoreField: r1->field_f = d0
    //     0xfabbd8: stur            d0, [x1, #0xf]
    // 0xfabbdc: mov             x2, x1
    // 0xfabbe0: ldur            x3, [fp, #-0x20]
    // 0xfabbe4: r1 = Null
    //     0xfabbe4: mov             x1, NULL
    // 0xfabbe8: r0 = ImageFilter.compose()
    //     0xfabbe8: bl              #0xc18e24  ; [dart:ui] ImageFilter::ImageFilter.compose
    // 0xfabbec: ldur            x2, [fp, #-8]
    // 0xfabbf0: r1 = Instance_CupertinoDynamicColor
    //     0xfabbf0: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8cae0] Obj!CupertinoDynamicColor@12b3e71
    //     0xfabbf4: ldr             x1, [x1, #0xae0]
    // 0xfabbf8: stur            x0, [fp, #-0x18]
    // 0xfabbfc: r0 = resolveFrom()
    //     0xfabbfc: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0xfabc00: ldur            x2, [fp, #-8]
    // 0xfabc04: r1 = Instance_CupertinoDynamicColor
    //     0xfabc04: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8cae8] Obj!CupertinoDynamicColor@12b3e31
    //     0xfabc08: ldr             x1, [x1, #0xae8]
    // 0xfabc0c: stur            x0, [fp, #-8]
    // 0xfabc10: r0 = resolveFrom()
    //     0xfabc10: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0xfabc14: stur            x0, [fp, #-0x20]
    // 0xfabc18: r0 = BorderSide()
    //     0xfabc18: bl              #0x8a73bc  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0xfabc1c: mov             x1, x0
    // 0xfabc20: ldur            x0, [fp, #-0x20]
    // 0xfabc24: stur            x1, [fp, #-0x28]
    // 0xfabc28: StoreField: r1->field_7 = r0
    //     0xfabc28: stur            w0, [x1, #7]
    // 0xfabc2c: d0 = 1.000000
    //     0xfabc2c: fmov            d0, #1.00000000
    // 0xfabc30: StoreField: r1->field_b = d0
    //     0xfabc30: stur            d0, [x1, #0xb]
    // 0xfabc34: r0 = Instance_BorderStyle
    //     0xfabc34: add             x0, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0xfabc38: ldr             x0, [x0, #0xdc8]
    // 0xfabc3c: StoreField: r1->field_13 = r0
    //     0xfabc3c: stur            w0, [x1, #0x13]
    // 0xfabc40: d0 = -1.000000
    //     0xfabc40: fmov            d0, #-1.00000000
    // 0xfabc44: ArrayStore: r1[0] = d0  ; List_8
    //     0xfabc44: stur            d0, [x1, #0x17]
    // 0xfabc48: r0 = RoundedSuperellipseBorder()
    //     0xfabc48: bl              #0xd74df0  ; AllocateRoundedSuperellipseBorderStub -> RoundedSuperellipseBorder (size=0x10)
    // 0xfabc4c: mov             x1, x0
    // 0xfabc50: r0 = Instance_BorderRadius
    //     0xfabc50: add             x0, PP, #0x8c, lsl #12  ; [pp+0x8caf0] Obj!BorderRadius@129e4b1
    //     0xfabc54: ldr             x0, [x0, #0xaf0]
    // 0xfabc58: stur            x1, [fp, #-0x20]
    // 0xfabc5c: StoreField: r1->field_b = r0
    //     0xfabc5c: stur            w0, [x1, #0xb]
    // 0xfabc60: ldur            x0, [fp, #-0x28]
    // 0xfabc64: StoreField: r1->field_7 = r0
    //     0xfabc64: stur            w0, [x1, #7]
    // 0xfabc68: r0 = ShapeDecoration()
    //     0xfabc68: bl              #0xb6e288  ; AllocateShapeDecorationStub -> ShapeDecoration (size=0x1c)
    // 0xfabc6c: mov             x1, x0
    // 0xfabc70: ldur            x0, [fp, #-8]
    // 0xfabc74: stur            x1, [fp, #-0x28]
    // 0xfabc78: StoreField: r1->field_7 = r0
    //     0xfabc78: stur            w0, [x1, #7]
    // 0xfabc7c: ldur            x0, [fp, #-0x20]
    // 0xfabc80: ArrayStore: r1[0] = r0  ; List_4
    //     0xfabc80: stur            w0, [x1, #0x17]
    // 0xfabc84: r0 = Padding()
    //     0xfabc84: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xfabc88: mov             x1, x0
    // 0xfabc8c: r0 = Instance_EdgeInsets
    //     0xfabc8c: add             x0, PP, #0x28, lsl #12  ; [pp+0x286f8] Obj!EdgeInsets@129dc21
    //     0xfabc90: ldr             x0, [x0, #0x6f8]
    // 0xfabc94: stur            x1, [fp, #-8]
    // 0xfabc98: StoreField: r1->field_f = r0
    //     0xfabc98: stur            w0, [x1, #0xf]
    // 0xfabc9c: ldur            x0, [fp, #-0x10]
    // 0xfabca0: StoreField: r1->field_b = r0
    //     0xfabca0: stur            w0, [x1, #0xb]
    // 0xfabca4: r0 = DecoratedBox()
    //     0xfabca4: bl              #0xd66318  ; AllocateDecoratedBoxStub -> DecoratedBox (size=0x18)
    // 0xfabca8: mov             x1, x0
    // 0xfabcac: ldur            x0, [fp, #-0x28]
    // 0xfabcb0: stur            x1, [fp, #-0x10]
    // 0xfabcb4: StoreField: r1->field_f = r0
    //     0xfabcb4: stur            w0, [x1, #0xf]
    // 0xfabcb8: r0 = Instance_DecorationPosition
    //     0xfabcb8: add             x0, PP, #0x80, lsl #12  ; [pp+0x80ef0] Obj!DecorationPosition@12c4381
    //     0xfabcbc: ldr             x0, [x0, #0xef0]
    // 0xfabcc0: StoreField: r1->field_13 = r0
    //     0xfabcc0: stur            w0, [x1, #0x13]
    // 0xfabcc4: ldur            x0, [fp, #-8]
    // 0xfabcc8: StoreField: r1->field_b = r0
    //     0xfabcc8: stur            w0, [x1, #0xb]
    // 0xfabccc: r0 = BackdropFilter()
    //     0xfabccc: bl              #0x9190e4  ; AllocateBackdropFilterStub -> BackdropFilter (size=0x28)
    // 0xfabcd0: mov             x1, x0
    // 0xfabcd4: ldur            x0, [fp, #-0x18]
    // 0xfabcd8: stur            x1, [fp, #-8]
    // 0xfabcdc: StoreField: r1->field_f = r0
    //     0xfabcdc: stur            w0, [x1, #0xf]
    // 0xfabce0: r0 = Instance_BlendMode
    //     0xfabce0: add             x0, PP, #0x16, lsl #12  ; [pp+0x16eb8] Obj!BlendMode@12c82e1
    //     0xfabce4: ldr             x0, [x0, #0xeb8]
    // 0xfabce8: ArrayStore: r1[0] = r0  ; List_4
    //     0xfabce8: stur            w0, [x1, #0x17]
    // 0xfabcec: r0 = true
    //     0xfabcec: add             x0, NULL, #0x20  ; true
    // 0xfabcf0: StoreField: r1->field_1b = r0
    //     0xfabcf0: stur            w0, [x1, #0x1b]
    // 0xfabcf4: r0 = false
    //     0xfabcf4: add             x0, NULL, #0x30  ; false
    // 0xfabcf8: StoreField: r1->field_23 = r0
    //     0xfabcf8: stur            w0, [x1, #0x23]
    // 0xfabcfc: ldur            x0, [fp, #-0x10]
    // 0xfabd00: StoreField: r1->field_b = r0
    //     0xfabd00: stur            w0, [x1, #0xb]
    // 0xfabd04: r0 = Container()
    //     0xfabd04: bl              #0x8a5af8  ; AllocateContainerStub -> Container (size=0x38)
    // 0xfabd08: stur            x0, [fp, #-0x10]
    // 0xfabd0c: r16 = 222.000000
    //     0xfabd0c: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8c998] 222
    //     0xfabd10: ldr             x16, [x16, #0x998]
    // 0xfabd14: r30 = Instance_Clip
    //     0xfabd14: add             lr, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xfabd18: ldr             lr, [lr, #0x850]
    // 0xfabd1c: stp             lr, x16, [SP, #0x10]
    // 0xfabd20: r16 = Instance_ShapeDecoration
    //     0xfabd20: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8caf8] Obj!ShapeDecoration@12b3411
    //     0xfabd24: ldr             x16, [x16, #0xaf8]
    // 0xfabd28: ldur            lr, [fp, #-8]
    // 0xfabd2c: stp             lr, x16, [SP]
    // 0xfabd30: mov             x1, x0
    // 0xfabd34: r4 = const [0, 0x5, 0x4, 0x1, child, 0x4, clipBehavior, 0x2, decoration, 0x3, width, 0x1, null]
    //     0xfabd34: add             x4, PP, #0x8c, lsl #12  ; [pp+0x8cb00] List(13) [0, 0x5, 0x4, 0x1, "child", 0x4, "clipBehavior", 0x2, "decoration", 0x3, "width", 0x1, Null]
    //     0xfabd38: ldr             x4, [x4, #0xb00]
    // 0xfabd3c: r0 = Container()
    //     0xfabd3c: bl              #0x8a54e0  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0xfabd40: ldur            x0, [fp, #-0x10]
    // 0xfabd44: LeaveFrame
    //     0xfabd44: mov             SP, fp
    //     0xfabd48: ldp             fp, lr, [SP], #0x10
    // 0xfabd4c: ret
    //     0xfabd4c: ret             
    // 0xfabd50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfabd50: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfabd54: b               #0xfabb9c
  }
  static _ _matrixWithSaturation(/* No info */) {
    // ** addr: 0xfabd58, size: 0x108
    // 0xfabd58: EnterFrame
    //     0xfabd58: stp             fp, lr, [SP, #-0x10]!
    //     0xfabd5c: mov             fp, SP
    // 0xfabd60: AllocStack(0x8)
    //     0xfabd60: sub             SP, SP, #8
    // 0xfabd64: r0 = 40
    //     0xfabd64: mov             x0, #0x28
    // 0xfabd68: mov             x2, x0
    // 0xfabd6c: r1 = <double>
    //     0xfabd6c: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xfabd70: r0 = AllocateArray()
    //     0xfabd70: bl              #0x13df928  ; AllocateArrayStub
    // 0xfabd74: stur            x0, [fp, #-8]
    // 0xfabd78: r16 = 2.574000
    //     0xfabd78: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8cb08] 2.574
    //     0xfabd7c: ldr             x16, [x16, #0xb08]
    // 0xfabd80: StoreField: r0->field_f = r16
    //     0xfabd80: stur            w16, [x0, #0xf]
    // 0xfabd84: r16 = -1.430000
    //     0xfabd84: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8cb10] -1.43
    //     0xfabd88: ldr             x16, [x16, #0xb10]
    // 0xfabd8c: StoreField: r0->field_13 = r16
    //     0xfabd8c: stur            w16, [x0, #0x13]
    // 0xfabd90: r16 = -0.144000
    //     0xfabd90: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8cb18] -0.144
    //     0xfabd94: ldr             x16, [x16, #0xb18]
    // 0xfabd98: ArrayStore: r0[0] = r16  ; List_4
    //     0xfabd98: stur            w16, [x0, #0x17]
    // 0xfabd9c: r16 = 0.000000
    //     0xfabd9c: ldr             x16, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xfabda0: StoreField: r0->field_1b = r16
    //     0xfabda0: stur            w16, [x0, #0x1b]
    // 0xfabda4: r16 = 0.000000
    //     0xfabda4: ldr             x16, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xfabda8: StoreField: r0->field_1f = r16
    //     0xfabda8: stur            w16, [x0, #0x1f]
    // 0xfabdac: r16 = -0.426000
    //     0xfabdac: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8cb20] -0.426
    //     0xfabdb0: ldr             x16, [x16, #0xb20]
    // 0xfabdb4: StoreField: r0->field_23 = r16
    //     0xfabdb4: stur            w16, [x0, #0x23]
    // 0xfabdb8: r16 = 1.570000
    //     0xfabdb8: add             x16, PP, #0x7a, lsl #12  ; [pp+0x7afd0] 1.57
    //     0xfabdbc: ldr             x16, [x16, #0xfd0]
    // 0xfabdc0: StoreField: r0->field_27 = r16
    //     0xfabdc0: stur            w16, [x0, #0x27]
    // 0xfabdc4: r16 = -0.144000
    //     0xfabdc4: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8cb18] -0.144
    //     0xfabdc8: ldr             x16, [x16, #0xb18]
    // 0xfabdcc: StoreField: r0->field_2b = r16
    //     0xfabdcc: stur            w16, [x0, #0x2b]
    // 0xfabdd0: r16 = 0.000000
    //     0xfabdd0: ldr             x16, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xfabdd4: StoreField: r0->field_2f = r16
    //     0xfabdd4: stur            w16, [x0, #0x2f]
    // 0xfabdd8: r16 = 0.000000
    //     0xfabdd8: ldr             x16, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xfabddc: StoreField: r0->field_33 = r16
    //     0xfabddc: stur            w16, [x0, #0x33]
    // 0xfabde0: r16 = -0.426000
    //     0xfabde0: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8cb20] -0.426
    //     0xfabde4: ldr             x16, [x16, #0xb20]
    // 0xfabde8: StoreField: r0->field_37 = r16
    //     0xfabde8: stur            w16, [x0, #0x37]
    // 0xfabdec: r16 = -1.430000
    //     0xfabdec: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8cb10] -1.43
    //     0xfabdf0: ldr             x16, [x16, #0xb10]
    // 0xfabdf4: StoreField: r0->field_3b = r16
    //     0xfabdf4: stur            w16, [x0, #0x3b]
    // 0xfabdf8: r16 = 2.856000
    //     0xfabdf8: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8cb28] 2.856
    //     0xfabdfc: ldr             x16, [x16, #0xb28]
    // 0xfabe00: StoreField: r0->field_3f = r16
    //     0xfabe00: stur            w16, [x0, #0x3f]
    // 0xfabe04: r16 = 0.000000
    //     0xfabe04: ldr             x16, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xfabe08: StoreField: r0->field_43 = r16
    //     0xfabe08: stur            w16, [x0, #0x43]
    // 0xfabe0c: r16 = 0.000000
    //     0xfabe0c: ldr             x16, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xfabe10: StoreField: r0->field_47 = r16
    //     0xfabe10: stur            w16, [x0, #0x47]
    // 0xfabe14: r16 = 0.000000
    //     0xfabe14: ldr             x16, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xfabe18: StoreField: r0->field_4b = r16
    //     0xfabe18: stur            w16, [x0, #0x4b]
    // 0xfabe1c: r16 = 0.000000
    //     0xfabe1c: ldr             x16, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xfabe20: StoreField: r0->field_4f = r16
    //     0xfabe20: stur            w16, [x0, #0x4f]
    // 0xfabe24: r16 = 0.000000
    //     0xfabe24: ldr             x16, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xfabe28: StoreField: r0->field_53 = r16
    //     0xfabe28: stur            w16, [x0, #0x53]
    // 0xfabe2c: r16 = 1.000000
    //     0xfabe2c: ldr             x16, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xfabe30: StoreField: r0->field_57 = r16
    //     0xfabe30: stur            w16, [x0, #0x57]
    // 0xfabe34: r16 = 0.000000
    //     0xfabe34: ldr             x16, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xfabe38: StoreField: r0->field_5b = r16
    //     0xfabe38: stur            w16, [x0, #0x5b]
    // 0xfabe3c: r1 = <double>
    //     0xfabe3c: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xfabe40: r0 = AllocateGrowableArray()
    //     0xfabe40: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xfabe44: ldur            x1, [fp, #-8]
    // 0xfabe48: StoreField: r0->field_f = r1
    //     0xfabe48: stur            w1, [x0, #0xf]
    // 0xfabe4c: r1 = 40
    //     0xfabe4c: mov             x1, #0x28
    // 0xfabe50: StoreField: r0->field_b = r1
    //     0xfabe50: stur            w1, [x0, #0xb]
    // 0xfabe54: LeaveFrame
    //     0xfabe54: mov             SP, fp
    //     0xfabe58: ldp             fp, lr, [SP], #0x10
    // 0xfabe5c: ret
    //     0xfabe5c: ret             
  }
}
