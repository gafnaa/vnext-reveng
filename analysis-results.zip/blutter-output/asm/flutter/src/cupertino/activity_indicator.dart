// lib: , url: package:flutter/src/cupertino/activity_indicator.dart

// class id: 1048769, size: 0x8
class :: {
}

// class id: 4346, size: 0x20, field offset: 0xc
class _CupertinoActivityIndicatorPainter extends CustomPainter {

  _ paint(/* No info */) {
    // ** addr: 0xb74588, size: 0x380
    // 0xb74588: EnterFrame
    //     0xb74588: stp             fp, lr, [SP, #-0x10]!
    //     0xb7458c: mov             fp, SP
    // 0xb74590: AllocStack(0x60)
    //     0xb74590: sub             SP, SP, #0x60
    // 0xb74594: SetupParameters(_CupertinoActivityIndicatorPainter this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xb74594: mov             x0, x1
    //     0xb74598: stur            x1, [fp, #-8]
    //     0xb7459c: mov             x1, x2
    //     0xb745a0: stur            x2, [fp, #-0x10]
    //     0xb745a4: stur            x3, [fp, #-0x18]
    // 0xb745a8: CheckStackOverflow
    //     0xb745a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb745ac: cmp             SP, x16
    //     0xb745b0: b.ls            #0xb748ac
    // 0xb745b4: r16 = 136
    //     0xb745b4: mov             x16, #0x88
    // 0xb745b8: stp             x16, NULL, [SP]
    // 0xb745bc: r0 = ByteData()
    //     0xb745bc: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xb745c0: stur            x0, [fp, #-0x20]
    // 0xb745c4: r0 = Paint()
    //     0xb745c4: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xb745c8: mov             x2, x0
    // 0xb745cc: ldur            x0, [fp, #-0x20]
    // 0xb745d0: stur            x2, [fp, #-0x30]
    // 0xb745d4: StoreField: r2->field_7 = r0
    //     0xb745d4: stur            w0, [x2, #7]
    // 0xb745d8: ldur            x0, [fp, #-0x10]
    // 0xb745dc: LoadField: r1 = r0->field_7
    //     0xb745dc: ldur            w1, [x0, #7]
    // 0xb745e0: DecompressPointer r1
    //     0xb745e0: add             x1, x1, HEAP, lsl #32
    // 0xb745e4: cmp             w1, NULL
    // 0xb745e8: b.eq            #0xb748b4
    // 0xb745ec: LoadField: r3 = r1->field_7
    //     0xb745ec: ldur            x3, [x1, #7]
    // 0xb745f0: ldr             x1, [x3]
    // 0xb745f4: cbz             x1, #0xb7486c
    // 0xb745f8: ldur            x3, [fp, #-0x18]
    // 0xb745fc: mov             x4, x1
    // 0xb74600: stur            x4, [fp, #-0x28]
    // 0xb74604: r1 = <Never>
    //     0xb74604: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb74608: r0 = Pointer()
    //     0xb74608: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb7460c: mov             x1, x0
    // 0xb74610: ldur            x0, [fp, #-0x28]
    // 0xb74614: StoreField: r1->field_7 = r0
    //     0xb74614: stur            x0, [x1, #7]
    // 0xb74618: r0 = _save$Method$FfiNative()
    //     0xb74618: bl              #0xb74adc  ; [dart:ui] _NativeCanvas::_save$Method$FfiNative
    // 0xb7461c: ldur            x0, [fp, #-0x18]
    // 0xb74620: LoadField: d0 = r0->field_7
    //     0xb74620: ldur            d0, [x0, #7]
    // 0xb74624: d1 = 2.000000
    //     0xb74624: fmov            d1, #2.00000000
    // 0xb74628: fdiv            d2, d0, d1
    // 0xb7462c: stur            d2, [fp, #-0x50]
    // 0xb74630: LoadField: d0 = r0->field_f
    //     0xb74630: ldur            d0, [x0, #0xf]
    // 0xb74634: fdiv            d3, d0, d1
    // 0xb74638: ldur            x0, [fp, #-0x10]
    // 0xb7463c: stur            d3, [fp, #-0x48]
    // 0xb74640: LoadField: r1 = r0->field_7
    //     0xb74640: ldur            w1, [x0, #7]
    // 0xb74644: DecompressPointer r1
    //     0xb74644: add             x1, x1, HEAP, lsl #32
    // 0xb74648: cmp             w1, NULL
    // 0xb7464c: b.eq            #0xb748b8
    // 0xb74650: LoadField: r2 = r1->field_7
    //     0xb74650: ldur            x2, [x1, #7]
    // 0xb74654: ldr             x1, [x2]
    // 0xb74658: cbz             x1, #0xb7487c
    // 0xb7465c: ldur            x2, [fp, #-8]
    // 0xb74660: mov             x3, x1
    // 0xb74664: stur            x3, [fp, #-0x28]
    // 0xb74668: r1 = <Never>
    //     0xb74668: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb7466c: r0 = Pointer()
    //     0xb7466c: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb74670: mov             x1, x0
    // 0xb74674: ldur            x0, [fp, #-0x28]
    // 0xb74678: StoreField: r1->field_7 = r0
    //     0xb74678: stur            x0, [x1, #7]
    // 0xb7467c: ldur            d0, [fp, #-0x50]
    // 0xb74680: ldur            d1, [fp, #-0x48]
    // 0xb74684: r0 = _translate$Method$FfiNative()
    //     0xb74684: bl              #0xb74a38  ; [dart:ui] _NativeCanvas::_translate$Method$FfiNative
    // 0xb74688: ldur            x0, [fp, #-8]
    // 0xb7468c: LoadField: r1 = r0->field_b
    //     0xb7468c: ldur            w1, [x0, #0xb]
    // 0xb74690: DecompressPointer r1
    //     0xb74690: add             x1, x1, HEAP, lsl #32
    // 0xb74694: LoadField: r2 = r1->field_37
    //     0xb74694: ldur            w2, [x1, #0x37]
    // 0xb74698: DecompressPointer r2
    //     0xb74698: add             x2, x2, HEAP, lsl #32
    // 0xb7469c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb746a0: cmp             w2, w16
    // 0xb746a4: b.eq            #0xb748bc
    // 0xb746a8: LoadField: d0 = r2->field_7
    //     0xb746a8: ldur            d0, [x2, #7]
    // 0xb746ac: d1 = 8.000000
    //     0xb746ac: fmov            d1, #8.00000000
    // 0xb746b0: fmul            d2, d0, d1
    // 0xb746b4: fcmp            d2, d2
    // 0xb746b8: b.vs            #0xb748c4
    // 0xb746bc: fcvtms          x1, d2
    // 0xb746c0: asr             x16, x1, #0x1e
    // 0xb746c4: cmp             x16, x1, asr #63
    // 0xb746c8: b.ne            #0xb748c4
    // 0xb746cc: lsl             x1, x1, #1
    // 0xb746d0: LoadField: d0 = r0->field_13
    //     0xb746d0: ldur            d0, [x0, #0x13]
    // 0xb746d4: stur            d0, [fp, #-0x50]
    // 0xb746d8: fmul            d2, d0, d1
    // 0xb746dc: stur            d2, [fp, #-0x48]
    // 0xb746e0: r3 = LoadInt32Instr(r1)
    //     0xb746e0: sbfx            x3, x1, #1, #0x1f
    //     0xb746e4: tbz             w1, #0, #0xb746ec
    //     0xb746e8: ldur            x3, [x1, #7]
    // 0xb746ec: stur            x3, [fp, #-0x38]
    // 0xb746f0: LoadField: r4 = r0->field_f
    //     0xb746f0: ldur            w4, [x0, #0xf]
    // 0xb746f4: DecompressPointer r4
    //     0xb746f4: add             x4, x4, HEAP, lsl #32
    // 0xb746f8: stur            x4, [fp, #-0x20]
    // 0xb746fc: LoadField: r5 = r0->field_1b
    //     0xb746fc: ldur            w5, [x0, #0x1b]
    // 0xb74700: DecompressPointer r5
    //     0xb74700: add             x5, x5, HEAP, lsl #32
    // 0xb74704: stur            x5, [fp, #-0x18]
    // 0xb74708: r9 = 0
    //     0xb74708: mov             x9, #0
    // 0xb7470c: ldur            x6, [fp, #-0x10]
    // 0xb74710: r8 = const [0x2f, 0x2f, 0x2f, 0x2f, 0x48, 0x61, 0x7a, 0x93]
    //     0xb74710: add             x8, PP, #0xa2, lsl #12  ; [pp+0xa2c10] List<int>(8)
    //     0xb74714: ldr             x8, [x8, #0xc10]
    // 0xb74718: d1 = 1.000000
    //     0xb74718: fmov            d1, #1.00000000
    // 0xb7471c: r7 = 8
    //     0xb7471c: mov             x7, #8
    // 0xb74720: stur            x9, [fp, #-0x28]
    // 0xb74724: CheckStackOverflow
    //     0xb74724: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb74728: cmp             SP, x16
    //     0xb7472c: b.ls            #0xb748f0
    // 0xb74730: scvtf           d3, x9
    // 0xb74734: fcmp            d2, d3
    // 0xb74738: b.le            #0xb7481c
    // 0xb7473c: sub             x0, x9, x3
    // 0xb74740: sdiv            x2, x0, x7
    // 0xb74744: msub            x1, x2, x7, x0
    // 0xb74748: cmp             x1, xzr
    // 0xb7474c: b.lt            #0xb748f8
    // 0xb74750: fcmp            d1, d0
    // 0xb74754: b.le            #0xb74760
    // 0xb74758: r2 = 147
    //     0xb74758: mov             x2, #0x93
    // 0xb7475c: b               #0xb7477c
    // 0xb74760: ArrayLoad: r0 = r8[r1]  ; Unknown_4
    //     0xb74760: add             x16, x8, x1, lsl #2
    //     0xb74764: ldur            w0, [x16, #0xf]
    // 0xb74768: DecompressPointer r0
    //     0xb74768: add             x0, x0, HEAP, lsl #32
    // 0xb7476c: r1 = LoadInt32Instr(r0)
    //     0xb7476c: sbfx            x1, x0, #1, #0x1f
    //     0xb74770: tbz             w0, #0, #0xb74778
    //     0xb74774: ldur            x1, [x0, #7]
    // 0xb74778: mov             x2, x1
    // 0xb7477c: r0 = LoadClassIdInstr(r4)
    //     0xb7477c: ldur            x0, [x4, #-1]
    //     0xb74780: ubfx            x0, x0, #0xc, #0x14
    // 0xb74784: mov             x1, x4
    // 0xb74788: r0 = GDT[cid_x0 + -0xff4]()
    //     0xb74788: sub             lr, x0, #0xff4
    //     0xb7478c: ldr             lr, [x21, lr, lsl #3]
    //     0xb74790: blr             lr
    // 0xb74794: ldur            x1, [fp, #-0x30]
    // 0xb74798: mov             x2, x0
    // 0xb7479c: r0 = color=()
    //     0xb7479c: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xb747a0: ldur            x1, [fp, #-0x10]
    // 0xb747a4: ldur            x2, [fp, #-0x18]
    // 0xb747a8: ldur            x3, [fp, #-0x30]
    // 0xb747ac: r0 = drawRRect()
    //     0xb747ac: bl              #0xb6dce0  ; [dart:ui] _NativeCanvas::drawRRect
    // 0xb747b0: ldur            x0, [fp, #-0x10]
    // 0xb747b4: LoadField: r1 = r0->field_7
    //     0xb747b4: ldur            w1, [x0, #7]
    // 0xb747b8: DecompressPointer r1
    //     0xb747b8: add             x1, x1, HEAP, lsl #32
    // 0xb747bc: cmp             w1, NULL
    // 0xb747c0: b.eq            #0xb74900
    // 0xb747c4: LoadField: r2 = r1->field_7
    //     0xb747c4: ldur            x2, [x1, #7]
    // 0xb747c8: ldr             x1, [x2]
    // 0xb747cc: cbz             x1, #0xb7488c
    // 0xb747d0: ldur            x2, [fp, #-0x28]
    // 0xb747d4: mov             x3, x1
    // 0xb747d8: stur            x3, [fp, #-0x40]
    // 0xb747dc: r1 = <Never>
    //     0xb747dc: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb747e0: r0 = Pointer()
    //     0xb747e0: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb747e4: mov             x1, x0
    // 0xb747e8: ldur            x0, [fp, #-0x40]
    // 0xb747ec: StoreField: r1->field_7 = r0
    //     0xb747ec: stur            x0, [x1, #7]
    // 0xb747f0: d0 = 0.785398
    //     0xb747f0: add             x17, PP, #0x98, lsl #12  ; [pp+0x98e70] IMM: double(0.7853981633974483) from 0x3fe921fb54442d18
    //     0xb747f4: ldr             d0, [x17, #0xe70]
    // 0xb747f8: r0 = _rotate$Method$FfiNative()
    //     0xb747f8: bl              #0xb7499c  ; [dart:ui] _NativeCanvas::_rotate$Method$FfiNative
    // 0xb747fc: ldur            x0, [fp, #-0x28]
    // 0xb74800: add             x9, x0, #1
    // 0xb74804: ldur            d0, [fp, #-0x50]
    // 0xb74808: ldur            d2, [fp, #-0x48]
    // 0xb7480c: ldur            x4, [fp, #-0x20]
    // 0xb74810: ldur            x5, [fp, #-0x18]
    // 0xb74814: ldur            x3, [fp, #-0x38]
    // 0xb74818: b               #0xb7470c
    // 0xb7481c: mov             x0, x6
    // 0xb74820: LoadField: r1 = r0->field_7
    //     0xb74820: ldur            w1, [x0, #7]
    // 0xb74824: DecompressPointer r1
    //     0xb74824: add             x1, x1, HEAP, lsl #32
    // 0xb74828: cmp             w1, NULL
    // 0xb7482c: b.eq            #0xb74904
    // 0xb74830: LoadField: r2 = r1->field_7
    //     0xb74830: ldur            x2, [x1, #7]
    // 0xb74834: ldr             x1, [x2]
    // 0xb74838: cbz             x1, #0xb7489c
    // 0xb7483c: mov             x2, x1
    // 0xb74840: stur            x2, [fp, #-0x28]
    // 0xb74844: r1 = <Never>
    //     0xb74844: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb74848: r0 = Pointer()
    //     0xb74848: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb7484c: mov             x1, x0
    // 0xb74850: ldur            x0, [fp, #-0x28]
    // 0xb74854: StoreField: r1->field_7 = r0
    //     0xb74854: stur            x0, [x1, #7]
    // 0xb74858: r0 = _restore$Method$FfiNative()
    //     0xb74858: bl              #0xb74908  ; [dart:ui] _NativeCanvas::_restore$Method$FfiNative
    // 0xb7485c: r0 = Null
    //     0xb7485c: mov             x0, NULL
    // 0xb74860: LeaveFrame
    //     0xb74860: mov             SP, fp
    //     0xb74864: ldp             fp, lr, [SP], #0x10
    // 0xb74868: ret
    //     0xb74868: ret             
    // 0xb7486c: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb7486c: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb74870: str             x16, [SP]
    // 0xb74874: r0 = _throwNew()
    //     0xb74874: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb74878: brk             #0
    // 0xb7487c: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb7487c: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb74880: str             x16, [SP]
    // 0xb74884: r0 = _throwNew()
    //     0xb74884: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb74888: brk             #0
    // 0xb7488c: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb7488c: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb74890: str             x16, [SP]
    // 0xb74894: r0 = _throwNew()
    //     0xb74894: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb74898: brk             #0
    // 0xb7489c: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb7489c: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb748a0: str             x16, [SP]
    // 0xb748a4: r0 = _throwNew()
    //     0xb748a4: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb748a8: brk             #0
    // 0xb748ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb748ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb748b0: b               #0xb745b4
    // 0xb748b4: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb748b4: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xb748b8: r0 = NullErrorSharedWithFPURegs()
    //     0xb748b8: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0xb748bc: r9 = _value
    //     0xb748bc: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0xb748c0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xb748c0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xb748c4: stp             q1, q2, [SP, #-0x20]!
    // 0xb748c8: SaveReg r0
    //     0xb748c8: str             x0, [SP, #-8]!
    // 0xb748cc: d0 = 0.000000
    //     0xb748cc: fmov            d0, d2
    // 0xb748d0: r0 = 70
    //     0xb748d0: mov             x0, #0x46
    // 0xb748d4: r30 = DoubleToIntegerStub
    //     0xb748d4: ldr             lr, [PP, #0x1b70]  ; [pp+0x1b70] Stub: DoubleToInteger (0x7d18e4)
    // 0xb748d8: LoadField: r30 = r30->field_7
    //     0xb748d8: ldur            lr, [lr, #7]
    // 0xb748dc: blr             lr
    // 0xb748e0: mov             x1, x0
    // 0xb748e4: RestoreReg r0
    //     0xb748e4: ldr             x0, [SP], #8
    // 0xb748e8: ldp             q1, q2, [SP], #0x20
    // 0xb748ec: b               #0xb746d0
    // 0xb748f0: r0 = StackOverflowSharedWithFPURegs()
    //     0xb748f0: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb748f4: b               #0xb74730
    // 0xb748f8: add             x1, x1, x7
    // 0xb748fc: b               #0xb74750
    // 0xb74900: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb74900: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xb74904: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb74904: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ shouldRepaint(/* No info */) {
    // ** addr: 0xb92ed0, size: 0xf4
    // 0xb92ed0: EnterFrame
    //     0xb92ed0: stp             fp, lr, [SP, #-0x10]!
    //     0xb92ed4: mov             fp, SP
    // 0xb92ed8: AllocStack(0x20)
    //     0xb92ed8: sub             SP, SP, #0x20
    // 0xb92edc: SetupParameters(_CupertinoActivityIndicatorPainter this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xb92edc: mov             x4, x1
    //     0xb92ee0: mov             x3, x2
    //     0xb92ee4: stur            x1, [fp, #-8]
    //     0xb92ee8: stur            x2, [fp, #-0x10]
    // 0xb92eec: CheckStackOverflow
    //     0xb92eec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb92ef0: cmp             SP, x16
    //     0xb92ef4: b.ls            #0xb92fbc
    // 0xb92ef8: mov             x0, x3
    // 0xb92efc: r2 = Null
    //     0xb92efc: mov             x2, NULL
    // 0xb92f00: r1 = Null
    //     0xb92f00: mov             x1, NULL
    // 0xb92f04: r4 = 60
    //     0xb92f04: mov             x4, #0x3c
    // 0xb92f08: branchIfSmi(r0, 0xb92f14)
    //     0xb92f08: tbz             w0, #0, #0xb92f14
    // 0xb92f0c: r4 = LoadClassIdInstr(r0)
    //     0xb92f0c: ldur            x4, [x0, #-1]
    //     0xb92f10: ubfx            x4, x4, #0xc, #0x14
    // 0xb92f14: r17 = 4346
    //     0xb92f14: mov             x17, #0x10fa
    // 0xb92f18: cmp             x4, x17
    // 0xb92f1c: b.eq            #0xb92f34
    // 0xb92f20: r8 = _CupertinoActivityIndicatorPainter
    //     0xb92f20: add             x8, PP, #0x98, lsl #12  ; [pp+0x98728] Type: _CupertinoActivityIndicatorPainter
    //     0xb92f24: ldr             x8, [x8, #0x728]
    // 0xb92f28: r3 = Null
    //     0xb92f28: add             x3, PP, #0x98, lsl #12  ; [pp+0x98730] Null
    //     0xb92f2c: ldr             x3, [x3, #0x730]
    // 0xb92f30: r0 = DefaultTypeTest()
    //     0xb92f30: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb92f34: ldur            x1, [fp, #-0x10]
    // 0xb92f38: LoadField: r0 = r1->field_b
    //     0xb92f38: ldur            w0, [x1, #0xb]
    // 0xb92f3c: DecompressPointer r0
    //     0xb92f3c: add             x0, x0, HEAP, lsl #32
    // 0xb92f40: ldur            x2, [fp, #-8]
    // 0xb92f44: LoadField: r3 = r2->field_b
    //     0xb92f44: ldur            w3, [x2, #0xb]
    // 0xb92f48: DecompressPointer r3
    //     0xb92f48: add             x3, x3, HEAP, lsl #32
    // 0xb92f4c: cmp             w0, w3
    // 0xb92f50: b.ne            #0xb92f84
    // 0xb92f54: LoadField: r0 = r1->field_f
    //     0xb92f54: ldur            w0, [x1, #0xf]
    // 0xb92f58: DecompressPointer r0
    //     0xb92f58: add             x0, x0, HEAP, lsl #32
    // 0xb92f5c: LoadField: r3 = r2->field_f
    //     0xb92f5c: ldur            w3, [x2, #0xf]
    // 0xb92f60: DecompressPointer r3
    //     0xb92f60: add             x3, x3, HEAP, lsl #32
    // 0xb92f64: r4 = LoadClassIdInstr(r0)
    //     0xb92f64: ldur            x4, [x0, #-1]
    //     0xb92f68: ubfx            x4, x4, #0xc, #0x14
    // 0xb92f6c: stp             x3, x0, [SP]
    // 0xb92f70: mov             x0, x4
    // 0xb92f74: mov             lr, x0
    // 0xb92f78: ldr             lr, [x21, lr, lsl #3]
    // 0xb92f7c: blr             lr
    // 0xb92f80: tbz             w0, #4, #0xb92f8c
    // 0xb92f84: r0 = true
    //     0xb92f84: add             x0, NULL, #0x20  ; true
    // 0xb92f88: b               #0xb92fb0
    // 0xb92f8c: ldur            x2, [fp, #-8]
    // 0xb92f90: ldur            x1, [fp, #-0x10]
    // 0xb92f94: LoadField: d0 = r1->field_13
    //     0xb92f94: ldur            d0, [x1, #0x13]
    // 0xb92f98: LoadField: d1 = r2->field_13
    //     0xb92f98: ldur            d1, [x2, #0x13]
    // 0xb92f9c: fcmp            d0, d1
    // 0xb92fa0: r16 = true
    //     0xb92fa0: add             x16, NULL, #0x20  ; true
    // 0xb92fa4: r17 = false
    //     0xb92fa4: add             x17, NULL, #0x30  ; false
    // 0xb92fa8: csel            x1, x16, x17, ne
    // 0xb92fac: mov             x0, x1
    // 0xb92fb0: LeaveFrame
    //     0xb92fb0: mov             SP, fp
    //     0xb92fb4: ldp             fp, lr, [SP], #0x10
    // 0xb92fb8: ret
    //     0xb92fb8: ret             
    // 0xb92fbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb92fbc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb92fc0: b               #0xb92ef8
  }
  _ _CupertinoActivityIndicatorPainter(/* No info */) {
    // ** addr: 0xd742a4, size: 0x134
    // 0xd742a4: EnterFrame
    //     0xd742a4: stp             fp, lr, [SP, #-0x10]!
    //     0xd742a8: mov             fp, SP
    // 0xd742ac: AllocStack(0x30)
    //     0xd742ac: sub             SP, SP, #0x30
    // 0xd742b0: d3 = 10.000000
    //     0xd742b0: fmov            d3, #10.00000000
    // 0xd742b4: d2 = 3.000000
    //     0xd742b4: fmov            d2, #3.00000000
    // 0xd742b8: mov             x0, x3
    // 0xd742bc: stur            x1, [fp, #-8]
    // 0xd742c0: mov             x16, x2
    // 0xd742c4: mov             x2, x1
    // 0xd742c8: mov             x1, x16
    // 0xd742cc: mov             x16, x3
    // 0xd742d0: mov             x3, x2
    // 0xd742d4: mov             x2, x16
    // 0xd742d8: stur            x2, [fp, #-0x10]
    // 0xd742dc: StoreField: r3->field_b = r0
    //     0xd742dc: stur            w0, [x3, #0xb]
    //     0xd742e0: ldurb           w16, [x3, #-1]
    //     0xd742e4: ldurb           w17, [x0, #-1]
    //     0xd742e8: and             x16, x17, x16, lsr #2
    //     0xd742ec: tst             x16, HEAP, lsr #32
    //     0xd742f0: b.eq            #0xd742f8
    //     0xd742f4: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xd742f8: mov             x0, x1
    // 0xd742fc: StoreField: r3->field_f = r0
    //     0xd742fc: stur            w0, [x3, #0xf]
    //     0xd74300: ldurb           w16, [x3, #-1]
    //     0xd74304: ldurb           w17, [x0, #-1]
    //     0xd74308: and             x16, x17, x16, lsr #2
    //     0xd7430c: tst             x16, HEAP, lsr #32
    //     0xd74310: b.eq            #0xd74318
    //     0xd74314: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xd74318: StoreField: r3->field_13 = d0
    //     0xd74318: stur            d0, [x3, #0x13]
    // 0xd7431c: fneg            d0, d1
    // 0xd74320: stur            d0, [fp, #-0x30]
    // 0xd74324: fdiv            d4, d0, d3
    // 0xd74328: stur            d4, [fp, #-0x28]
    // 0xd7432c: fdiv            d5, d0, d2
    // 0xd74330: stur            d5, [fp, #-0x20]
    // 0xd74334: fdiv            d2, d1, d3
    // 0xd74338: stur            d2, [fp, #-0x18]
    // 0xd7433c: r1 = <RRect>
    //     0xd7433c: add             x1, PP, #0x85, lsl #12  ; [pp+0x85108] TypeArguments: <RRect>
    //     0xd74340: ldr             x1, [x1, #0x108]
    // 0xd74344: r0 = RRect()
    //     0xd74344: bl              #0xb6e214  ; AllocateRRectStub -> RRect (size=0x6c)
    // 0xd74348: ldur            d0, [fp, #-0x28]
    // 0xd7434c: StoreField: r0->field_b = d0
    //     0xd7434c: stur            d0, [x0, #0xb]
    // 0xd74350: ldur            d0, [fp, #-0x20]
    // 0xd74354: StoreField: r0->field_13 = d0
    //     0xd74354: stur            d0, [x0, #0x13]
    // 0xd74358: ldur            d0, [fp, #-0x18]
    // 0xd7435c: StoreField: r0->field_1b = d0
    //     0xd7435c: stur            d0, [x0, #0x1b]
    // 0xd74360: ldur            d1, [fp, #-0x30]
    // 0xd74364: StoreField: r0->field_23 = d1
    //     0xd74364: stur            d1, [x0, #0x23]
    // 0xd74368: StoreField: r0->field_2b = d0
    //     0xd74368: stur            d0, [x0, #0x2b]
    // 0xd7436c: StoreField: r0->field_33 = d0
    //     0xd7436c: stur            d0, [x0, #0x33]
    // 0xd74370: StoreField: r0->field_3b = d0
    //     0xd74370: stur            d0, [x0, #0x3b]
    // 0xd74374: StoreField: r0->field_43 = d0
    //     0xd74374: stur            d0, [x0, #0x43]
    // 0xd74378: StoreField: r0->field_4b = d0
    //     0xd74378: stur            d0, [x0, #0x4b]
    // 0xd7437c: StoreField: r0->field_53 = d0
    //     0xd7437c: stur            d0, [x0, #0x53]
    // 0xd74380: StoreField: r0->field_5b = d0
    //     0xd74380: stur            d0, [x0, #0x5b]
    // 0xd74384: StoreField: r0->field_63 = d0
    //     0xd74384: stur            d0, [x0, #0x63]
    // 0xd74388: ldur            x1, [fp, #-8]
    // 0xd7438c: StoreField: r1->field_1b = r0
    //     0xd7438c: stur            w0, [x1, #0x1b]
    //     0xd74390: ldurb           w16, [x1, #-1]
    //     0xd74394: ldurb           w17, [x0, #-1]
    //     0xd74398: and             x16, x17, x16, lsr #2
    //     0xd7439c: tst             x16, HEAP, lsr #32
    //     0xd743a0: b.eq            #0xd743a8
    //     0xd743a4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd743a8: ldur            x0, [fp, #-0x10]
    // 0xd743ac: StoreField: r1->field_7 = r0
    //     0xd743ac: stur            w0, [x1, #7]
    //     0xd743b0: ldurb           w16, [x1, #-1]
    //     0xd743b4: ldurb           w17, [x0, #-1]
    //     0xd743b8: and             x16, x17, x16, lsr #2
    //     0xd743bc: tst             x16, HEAP, lsr #32
    //     0xd743c0: b.eq            #0xd743c8
    //     0xd743c4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd743c8: r0 = Null
    //     0xd743c8: mov             x0, NULL
    // 0xd743cc: LeaveFrame
    //     0xd743cc: mov             SP, fp
    //     0xd743d0: ldp             fp, lr, [SP], #0x10
    // 0xd743d4: ret
    //     0xd743d4: ret             
  }
}

// class id: 5608, size: 0x20, field offset: 0x1c
class _CupertinoActivityIndicatorState extends _MixinApplication384&State&SingleTickerProviderStateMixin {

  late AnimationController _controller; // offset: 0x1c

  _ build(/* No info */) {
    // ** addr: 0xd74124, size: 0x180
    // 0xd74124: EnterFrame
    //     0xd74124: stp             fp, lr, [SP, #-0x10]!
    //     0xd74128: mov             fp, SP
    // 0xd7412c: AllocStack(0x30)
    //     0xd7412c: sub             SP, SP, #0x30
    // 0xd74130: d0 = 2.000000
    //     0xd74130: fmov            d0, #2.00000000
    // 0xd74134: mov             x0, x1
    // 0xd74138: stur            x1, [fp, #-0x10]
    // 0xd7413c: CheckStackOverflow
    //     0xd7413c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd74140: cmp             SP, x16
    //     0xd74144: b.ls            #0xd74270
    // 0xd74148: LoadField: r1 = r0->field_b
    //     0xd74148: ldur            w1, [x0, #0xb]
    // 0xd7414c: DecompressPointer r1
    //     0xd7414c: add             x1, x1, HEAP, lsl #32
    // 0xd74150: cmp             w1, NULL
    // 0xd74154: b.eq            #0xd74278
    // 0xd74158: LoadField: d1 = r1->field_13
    //     0xd74158: ldur            d1, [x1, #0x13]
    // 0xd7415c: fmul            d2, d1, d0
    // 0xd74160: stur            d2, [fp, #-0x20]
    // 0xd74164: LoadField: r3 = r0->field_1b
    //     0xd74164: ldur            w3, [x0, #0x1b]
    // 0xd74168: DecompressPointer r3
    //     0xd74168: add             x3, x3, HEAP, lsl #32
    // 0xd7416c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd74170: cmp             w3, w16
    // 0xd74174: b.eq            #0xd7427c
    // 0xd74178: stur            x3, [fp, #-8]
    // 0xd7417c: LoadField: r4 = r1->field_b
    //     0xd7417c: ldur            w4, [x1, #0xb]
    // 0xd74180: DecompressPointer r4
    //     0xd74180: add             x4, x4, HEAP, lsl #32
    // 0xd74184: cmp             w4, NULL
    // 0xd74188: b.ne            #0xd741a0
    // 0xd7418c: r1 = Instance_CupertinoDynamicColor
    //     0xd7418c: add             x1, PP, #0x8e, lsl #12  ; [pp+0x8e738] Obj!CupertinoDynamicColor@12b38f1
    //     0xd74190: ldr             x1, [x1, #0x738]
    // 0xd74194: r0 = resolveFrom()
    //     0xd74194: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0xd74198: mov             x2, x0
    // 0xd7419c: b               #0xd741a4
    // 0xd741a0: mov             x2, x4
    // 0xd741a4: ldur            x0, [fp, #-0x10]
    // 0xd741a8: ldur            d0, [fp, #-0x20]
    // 0xd741ac: stur            x2, [fp, #-0x18]
    // 0xd741b0: LoadField: r1 = r0->field_b
    //     0xd741b0: ldur            w1, [x0, #0xb]
    // 0xd741b4: DecompressPointer r1
    //     0xd741b4: add             x1, x1, HEAP, lsl #32
    // 0xd741b8: cmp             w1, NULL
    // 0xd741bc: b.eq            #0xd74288
    // 0xd741c0: LoadField: d1 = r1->field_13
    //     0xd741c0: ldur            d1, [x1, #0x13]
    // 0xd741c4: stur            d1, [fp, #-0x30]
    // 0xd741c8: LoadField: d2 = r1->field_1b
    //     0xd741c8: ldur            d2, [x1, #0x1b]
    // 0xd741cc: stur            d2, [fp, #-0x28]
    // 0xd741d0: r0 = _CupertinoActivityIndicatorPainter()
    //     0xd741d0: bl              #0xd743d8  ; Allocate_CupertinoActivityIndicatorPainterStub -> _CupertinoActivityIndicatorPainter (size=0x20)
    // 0xd741d4: mov             x1, x0
    // 0xd741d8: ldur            x2, [fp, #-0x18]
    // 0xd741dc: ldur            x3, [fp, #-8]
    // 0xd741e0: ldur            d0, [fp, #-0x28]
    // 0xd741e4: ldur            d1, [fp, #-0x30]
    // 0xd741e8: stur            x0, [fp, #-8]
    // 0xd741ec: r0 = _CupertinoActivityIndicatorPainter()
    //     0xd741ec: bl              #0xd742a4  ; [package:flutter/src/cupertino/activity_indicator.dart] _CupertinoActivityIndicatorPainter::_CupertinoActivityIndicatorPainter
    // 0xd741f0: r0 = CustomPaint()
    //     0xd741f0: bl              #0xd0a594  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0xd741f4: mov             x1, x0
    // 0xd741f8: ldur            x0, [fp, #-8]
    // 0xd741fc: stur            x1, [fp, #-0x10]
    // 0xd74200: StoreField: r1->field_f = r0
    //     0xd74200: stur            w0, [x1, #0xf]
    // 0xd74204: r0 = Instance_Size
    //     0xd74204: ldr             x0, [PP, #0x7f28]  ; [pp+0x7f28] Obj!Size@12a74d1
    // 0xd74208: ArrayStore: r1[0] = r0  ; List_4
    //     0xd74208: stur            w0, [x1, #0x17]
    // 0xd7420c: r0 = false
    //     0xd7420c: add             x0, NULL, #0x30  ; false
    // 0xd74210: StoreField: r1->field_1b = r0
    //     0xd74210: stur            w0, [x1, #0x1b]
    // 0xd74214: StoreField: r1->field_1f = r0
    //     0xd74214: stur            w0, [x1, #0x1f]
    // 0xd74218: ldur            d0, [fp, #-0x20]
    // 0xd7421c: r0 = inline_Allocate_Double()
    //     0xd7421c: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xd74220: add             x0, x0, #0x10
    //     0xd74224: cmp             x2, x0
    //     0xd74228: b.ls            #0xd7428c
    //     0xd7422c: str             x0, [THR, #0x60]  ; THR::top
    //     0xd74230: sub             x0, x0, #0xf
    //     0xd74234: mov             x2, #0xe19c
    //     0xd74238: movk            x2, #3, lsl #16
    //     0xd7423c: stur            x2, [x0, #-1]
    // 0xd74240: dmb             ishst
    // 0xd74244: StoreField: r0->field_7 = d0
    //     0xd74244: stur            d0, [x0, #7]
    // 0xd74248: stur            x0, [fp, #-8]
    // 0xd7424c: r0 = SizedBox()
    //     0xd7424c: bl              #0x8a7210  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0xd74250: ldur            x1, [fp, #-8]
    // 0xd74254: StoreField: r0->field_f = r1
    //     0xd74254: stur            w1, [x0, #0xf]
    // 0xd74258: StoreField: r0->field_13 = r1
    //     0xd74258: stur            w1, [x0, #0x13]
    // 0xd7425c: ldur            x1, [fp, #-0x10]
    // 0xd74260: StoreField: r0->field_b = r1
    //     0xd74260: stur            w1, [x0, #0xb]
    // 0xd74264: LeaveFrame
    //     0xd74264: mov             SP, fp
    //     0xd74268: ldp             fp, lr, [SP], #0x10
    // 0xd7426c: ret
    //     0xd7426c: ret             
    // 0xd74270: r0 = StackOverflowSharedWithFPURegs()
    //     0xd74270: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xd74274: b               #0xd74148
    // 0xd74278: r0 = NullCastErrorSharedWithFPURegs()
    //     0xd74278: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xd7427c: r9 = _controller
    //     0xd7427c: add             x9, PP, #0x8e, lsl #12  ; [pp+0x8e740] Field <_CupertinoActivityIndicatorState@291022161._controller@291022161>: late (offset: 0x1c)
    //     0xd74280: ldr             x9, [x9, #0x740]
    // 0xd74284: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xd74284: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xd74288: r0 = NullCastErrorSharedWithFPURegs()
    //     0xd74288: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xd7428c: SaveReg d0
    //     0xd7428c: str             q0, [SP, #-0x10]!
    // 0xd74290: SaveReg r1
    //     0xd74290: str             x1, [SP, #-8]!
    // 0xd74294: r0 = AllocateDouble()
    //     0xd74294: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd74298: RestoreReg r1
    //     0xd74298: ldr             x1, [SP], #8
    // 0xd7429c: RestoreReg d0
    //     0xd7429c: ldr             q0, [SP], #0x10
    // 0xd742a0: b               #0xd74244
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf44d7c, size: 0x144
    // 0xf44d7c: EnterFrame
    //     0xf44d7c: stp             fp, lr, [SP, #-0x10]!
    //     0xf44d80: mov             fp, SP
    // 0xf44d84: AllocStack(0x10)
    //     0xf44d84: sub             SP, SP, #0x10
    // 0xf44d88: SetupParameters(_CupertinoActivityIndicatorState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xf44d88: mov             x4, x1
    //     0xf44d8c: mov             x3, x2
    //     0xf44d90: stur            x1, [fp, #-8]
    //     0xf44d94: stur            x2, [fp, #-0x10]
    // 0xf44d98: CheckStackOverflow
    //     0xf44d98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf44d9c: cmp             SP, x16
    //     0xf44da0: b.ls            #0xf44e9c
    // 0xf44da4: mov             x0, x3
    // 0xf44da8: r2 = Null
    //     0xf44da8: mov             x2, NULL
    // 0xf44dac: r1 = Null
    //     0xf44dac: mov             x1, NULL
    // 0xf44db0: r4 = 60
    //     0xf44db0: mov             x4, #0x3c
    // 0xf44db4: branchIfSmi(r0, 0xf44dc0)
    //     0xf44db4: tbz             w0, #0, #0xf44dc0
    // 0xf44db8: r4 = LoadClassIdInstr(r0)
    //     0xf44db8: ldur            x4, [x0, #-1]
    //     0xf44dbc: ubfx            x4, x4, #0xc, #0x14
    // 0xf44dc0: r17 = 6530
    //     0xf44dc0: mov             x17, #0x1982
    // 0xf44dc4: cmp             x4, x17
    // 0xf44dc8: b.eq            #0xf44de0
    // 0xf44dcc: r8 = CupertinoActivityIndicator
    //     0xf44dcc: add             x8, PP, #0x8e, lsl #12  ; [pp+0x8e748] Type: CupertinoActivityIndicator
    //     0xf44dd0: ldr             x8, [x8, #0x748]
    // 0xf44dd4: r3 = Null
    //     0xf44dd4: add             x3, PP, #0x8e, lsl #12  ; [pp+0x8e750] Null
    //     0xf44dd8: ldr             x3, [x3, #0x750]
    // 0xf44ddc: r0 = CupertinoActivityIndicator()
    //     0xf44ddc: bl              #0xad68bc  ; IsType_CupertinoActivityIndicator_Stub
    // 0xf44de0: ldur            x3, [fp, #-8]
    // 0xf44de4: LoadField: r2 = r3->field_7
    //     0xf44de4: ldur            w2, [x3, #7]
    // 0xf44de8: DecompressPointer r2
    //     0xf44de8: add             x2, x2, HEAP, lsl #32
    // 0xf44dec: ldur            x0, [fp, #-0x10]
    // 0xf44df0: r1 = Null
    //     0xf44df0: mov             x1, NULL
    // 0xf44df4: cmp             w2, NULL
    // 0xf44df8: b.eq            #0xf44e1c
    // 0xf44dfc: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf44dfc: ldur            w4, [x2, #0x17]
    // 0xf44e00: DecompressPointer r4
    //     0xf44e00: add             x4, x4, HEAP, lsl #32
    // 0xf44e04: r8 = X0 bound StatefulWidget
    //     0xf44e04: add             x8, PP, #0x12, lsl #12  ; [pp+0x12498] TypeParameter: X0 bound StatefulWidget
    //     0xf44e08: ldr             x8, [x8, #0x498]
    // 0xf44e0c: LoadField: r9 = r4->field_7
    //     0xf44e0c: ldur            x9, [x4, #7]
    // 0xf44e10: r3 = Null
    //     0xf44e10: add             x3, PP, #0x8e, lsl #12  ; [pp+0x8e760] Null
    //     0xf44e14: ldr             x3, [x3, #0x760]
    // 0xf44e18: blr             x9
    // 0xf44e1c: ldur            x0, [fp, #-8]
    // 0xf44e20: LoadField: r1 = r0->field_b
    //     0xf44e20: ldur            w1, [x0, #0xb]
    // 0xf44e24: DecompressPointer r1
    //     0xf44e24: add             x1, x1, HEAP, lsl #32
    // 0xf44e28: cmp             w1, NULL
    // 0xf44e2c: b.eq            #0xf44ea4
    // 0xf44e30: LoadField: r2 = r1->field_f
    //     0xf44e30: ldur            w2, [x1, #0xf]
    // 0xf44e34: DecompressPointer r2
    //     0xf44e34: add             x2, x2, HEAP, lsl #32
    // 0xf44e38: ldur            x1, [fp, #-0x10]
    // 0xf44e3c: LoadField: r3 = r1->field_f
    //     0xf44e3c: ldur            w3, [x1, #0xf]
    // 0xf44e40: DecompressPointer r3
    //     0xf44e40: add             x3, x3, HEAP, lsl #32
    // 0xf44e44: cmp             w2, w3
    // 0xf44e48: b.eq            #0xf44e8c
    // 0xf44e4c: tbnz            w2, #4, #0xf44e70
    // 0xf44e50: LoadField: r1 = r0->field_1b
    //     0xf44e50: ldur            w1, [x0, #0x1b]
    // 0xf44e54: DecompressPointer r1
    //     0xf44e54: add             x1, x1, HEAP, lsl #32
    // 0xf44e58: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf44e5c: cmp             w1, w16
    // 0xf44e60: b.eq            #0xf44ea8
    // 0xf44e64: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xf44e64: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xf44e68: r0 = repeat()
    //     0xf44e68: bl              #0xf3bd88  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::repeat
    // 0xf44e6c: b               #0xf44e8c
    // 0xf44e70: LoadField: r1 = r0->field_1b
    //     0xf44e70: ldur            w1, [x0, #0x1b]
    // 0xf44e74: DecompressPointer r1
    //     0xf44e74: add             x1, x1, HEAP, lsl #32
    // 0xf44e78: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf44e7c: cmp             w1, w16
    // 0xf44e80: b.eq            #0xf44eb4
    // 0xf44e84: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xf44e84: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xf44e88: r0 = stop()
    //     0xf44e88: bl              #0x82eb24  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::stop
    // 0xf44e8c: r0 = Null
    //     0xf44e8c: mov             x0, NULL
    // 0xf44e90: LeaveFrame
    //     0xf44e90: mov             SP, fp
    //     0xf44e94: ldp             fp, lr, [SP], #0x10
    // 0xf44e98: ret
    //     0xf44e98: ret             
    // 0xf44e9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf44e9c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf44ea0: b               #0xf44da4
    // 0xf44ea4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf44ea4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf44ea8: r9 = _controller
    //     0xf44ea8: add             x9, PP, #0x8e, lsl #12  ; [pp+0x8e740] Field <_CupertinoActivityIndicatorState@291022161._controller@291022161>: late (offset: 0x1c)
    //     0xf44eac: ldr             x9, [x9, #0x740]
    // 0xf44eb0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf44eb0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xf44eb4: r9 = _controller
    //     0xf44eb4: add             x9, PP, #0x8e, lsl #12  ; [pp+0x8e740] Field <_CupertinoActivityIndicatorState@291022161._controller@291022161>: late (offset: 0x1c)
    //     0xf44eb8: ldr             x9, [x9, #0x740]
    // 0xf44ebc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf44ebc: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0xf86c00, size: 0xb0
    // 0xf86c00: EnterFrame
    //     0xf86c00: stp             fp, lr, [SP, #-0x10]!
    //     0xf86c04: mov             fp, SP
    // 0xf86c08: AllocStack(0x18)
    //     0xf86c08: sub             SP, SP, #0x18
    // 0xf86c0c: SetupParameters(_CupertinoActivityIndicatorState this /* r1 => r2, fp-0x8 */)
    //     0xf86c0c: mov             x2, x1
    //     0xf86c10: stur            x1, [fp, #-8]
    // 0xf86c14: CheckStackOverflow
    //     0xf86c14: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf86c18: cmp             SP, x16
    //     0xf86c1c: b.ls            #0xf86ca4
    // 0xf86c20: r1 = <double>
    //     0xf86c20: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf86c24: r0 = AnimationController()
    //     0xf86c24: bl              #0x87522c  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0xf86c28: stur            x0, [fp, #-0x10]
    // 0xf86c2c: r16 = Instance_Duration
    //     0xf86c2c: ldr             x16, [PP, #0xa80]  ; [pp+0xa80] Obj!Duration@12c8921
    // 0xf86c30: str             x16, [SP]
    // 0xf86c34: mov             x1, x0
    // 0xf86c38: ldur            x2, [fp, #-8]
    // 0xf86c3c: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0xf86c3c: add             x4, PP, #0x15, lsl #12  ; [pp+0x155a0] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0xf86c40: ldr             x4, [x4, #0x5a0]
    // 0xf86c44: r0 = AnimationController()
    //     0xf86c44: bl              #0x874ea4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0xf86c48: ldur            x0, [fp, #-0x10]
    // 0xf86c4c: ldur            x1, [fp, #-8]
    // 0xf86c50: StoreField: r1->field_1b = r0
    //     0xf86c50: stur            w0, [x1, #0x1b]
    //     0xf86c54: ldurb           w16, [x1, #-1]
    //     0xf86c58: ldurb           w17, [x0, #-1]
    //     0xf86c5c: and             x16, x17, x16, lsr #2
    //     0xf86c60: tst             x16, HEAP, lsr #32
    //     0xf86c64: b.eq            #0xf86c6c
    //     0xf86c68: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf86c6c: LoadField: r0 = r1->field_b
    //     0xf86c6c: ldur            w0, [x1, #0xb]
    // 0xf86c70: DecompressPointer r0
    //     0xf86c70: add             x0, x0, HEAP, lsl #32
    // 0xf86c74: cmp             w0, NULL
    // 0xf86c78: b.eq            #0xf86cac
    // 0xf86c7c: LoadField: r1 = r0->field_f
    //     0xf86c7c: ldur            w1, [x0, #0xf]
    // 0xf86c80: DecompressPointer r1
    //     0xf86c80: add             x1, x1, HEAP, lsl #32
    // 0xf86c84: tbnz            w1, #4, #0xf86c94
    // 0xf86c88: ldur            x1, [fp, #-0x10]
    // 0xf86c8c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xf86c8c: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xf86c90: r0 = repeat()
    //     0xf86c90: bl              #0xf3bd88  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::repeat
    // 0xf86c94: r0 = Null
    //     0xf86c94: mov             x0, NULL
    // 0xf86c98: LeaveFrame
    //     0xf86c98: mov             SP, fp
    //     0xf86c9c: ldp             fp, lr, [SP], #0x10
    // 0xf86ca0: ret
    //     0xf86ca0: ret             
    // 0xf86ca4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf86ca4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf86ca8: b               #0xf86c20
    // 0xf86cac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf86cac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10e10bc, size: 0x64
    // 0x10e10bc: EnterFrame
    //     0x10e10bc: stp             fp, lr, [SP, #-0x10]!
    //     0x10e10c0: mov             fp, SP
    // 0x10e10c4: AllocStack(0x8)
    //     0x10e10c4: sub             SP, SP, #8
    // 0x10e10c8: SetupParameters(_CupertinoActivityIndicatorState this /* r1 => r0, fp-0x8 */)
    //     0x10e10c8: mov             x0, x1
    //     0x10e10cc: stur            x1, [fp, #-8]
    // 0x10e10d0: CheckStackOverflow
    //     0x10e10d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e10d4: cmp             SP, x16
    //     0x10e10d8: b.ls            #0x10e110c
    // 0x10e10dc: LoadField: r1 = r0->field_1b
    //     0x10e10dc: ldur            w1, [x0, #0x1b]
    // 0x10e10e0: DecompressPointer r1
    //     0x10e10e0: add             x1, x1, HEAP, lsl #32
    // 0x10e10e4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10e10e8: cmp             w1, w16
    // 0x10e10ec: b.eq            #0x10e1114
    // 0x10e10f0: r0 = dispose()
    //     0x10e10f0: bl              #0x9164f4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x10e10f4: ldur            x1, [fp, #-8]
    // 0x10e10f8: r0 = dispose()
    //     0x10e10f8: bl              #0x10e1120  ; [dart:mixin_deduplication] _MixinApplication384&State&SingleTickerProviderStateMixin::dispose
    // 0x10e10fc: r0 = Null
    //     0x10e10fc: mov             x0, NULL
    // 0x10e1100: LeaveFrame
    //     0x10e1100: mov             SP, fp
    //     0x10e1104: ldp             fp, lr, [SP], #0x10
    // 0x10e1108: ret
    //     0x10e1108: ret             
    // 0x10e110c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e110c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e1110: b               #0x10e10dc
    // 0x10e1114: r9 = _controller
    //     0x10e1114: add             x9, PP, #0x8e, lsl #12  ; [pp+0x8e740] Field <_CupertinoActivityIndicatorState@291022161._controller@291022161>: late (offset: 0x1c)
    //     0x10e1118: ldr             x9, [x9, #0x740]
    // 0x10e111c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x10e111c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 6530, size: 0x24, field offset: 0xc
//   const constructor, 
class CupertinoActivityIndicator extends StatefulWidget {

  bool field_10;
  _Double field_14;
  _Double field_1c;
  Color field_c;

  _ createState(/* No info */) {
    // ** addr: 0xfa014c, size: 0x2c
    // 0xfa014c: EnterFrame
    //     0xfa014c: stp             fp, lr, [SP, #-0x10]!
    //     0xfa0150: mov             fp, SP
    // 0xfa0154: mov             x0, x1
    // 0xfa0158: r1 = <CupertinoActivityIndicator>
    //     0xfa0158: add             x1, PP, #0x81, lsl #12  ; [pp+0x81d70] TypeArguments: <CupertinoActivityIndicator>
    //     0xfa015c: ldr             x1, [x1, #0xd70]
    // 0xfa0160: r0 = _CupertinoActivityIndicatorState()
    //     0xfa0160: bl              #0xfa0178  ; Allocate_CupertinoActivityIndicatorStateStub -> _CupertinoActivityIndicatorState (size=0x20)
    // 0xfa0164: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa0168: StoreField: r0->field_1b = r1
    //     0xfa0168: stur            w1, [x0, #0x1b]
    // 0xfa016c: LeaveFrame
    //     0xfa016c: mov             SP, fp
    //     0xfa0170: ldp             fp, lr, [SP], #0x10
    // 0xfa0174: ret
    //     0xfa0174: ret             
  }
}
