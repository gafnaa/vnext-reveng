// lib: , url: package:flutter/src/cupertino/cupertino_focus_halo.dart

// class id: 1048774, size: 0x8
class :: {
}

// class id: 5496, size: 0x18, field offset: 0x14
class _CupertinoFocusHaloState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0xde2e00, size: 0x18c
    // 0xde2e00: EnterFrame
    //     0xde2e00: stp             fp, lr, [SP, #-0x10]!
    //     0xde2e04: mov             fp, SP
    // 0xde2e08: AllocStack(0x28)
    //     0xde2e08: sub             SP, SP, #0x28
    // 0xde2e0c: SetupParameters(_CupertinoFocusHaloState this /* r1 => r1, fp-0x8 */)
    //     0xde2e0c: stur            x1, [fp, #-8]
    // 0xde2e10: CheckStackOverflow
    //     0xde2e10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde2e14: cmp             SP, x16
    //     0xde2e18: b.ls            #0xde2f7c
    // 0xde2e1c: r1 = 1
    //     0xde2e1c: mov             x1, #1
    // 0xde2e20: r0 = AllocateContext()
    //     0xde2e20: bl              #0x13de838  ; AllocateContextStub
    // 0xde2e24: mov             x2, x0
    // 0xde2e28: ldur            x0, [fp, #-8]
    // 0xde2e2c: stur            x2, [fp, #-0x10]
    // 0xde2e30: StoreField: r2->field_f = r0
    //     0xde2e30: stur            w0, [x2, #0xf]
    // 0xde2e34: LoadField: r1 = r0->field_b
    //     0xde2e34: ldur            w1, [x0, #0xb]
    // 0xde2e38: DecompressPointer r1
    //     0xde2e38: add             x1, x1, HEAP, lsl #32
    // 0xde2e3c: cmp             w1, NULL
    // 0xde2e40: b.eq            #0xde2f84
    // 0xde2e44: LoadField: r1 = r0->field_13
    //     0xde2e44: ldur            w1, [x0, #0x13]
    // 0xde2e48: DecompressPointer r1
    //     0xde2e48: add             x1, x1, HEAP, lsl #32
    // 0xde2e4c: tbnz            w1, #4, #0xde2e8c
    // 0xde2e50: mov             x1, x0
    // 0xde2e54: r0 = _effectiveFocusOutlineColor()
    //     0xde2e54: bl              #0xde307c  ; [package:flutter/src/cupertino/cupertino_focus_halo.dart] _CupertinoFocusHaloState::_effectiveFocusOutlineColor
    // 0xde2e58: stur            x0, [fp, #-0x18]
    // 0xde2e5c: r0 = BorderSide()
    //     0xde2e5c: bl              #0x8a73bc  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0xde2e60: mov             x1, x0
    // 0xde2e64: ldur            x0, [fp, #-0x18]
    // 0xde2e68: StoreField: r1->field_7 = r0
    //     0xde2e68: stur            w0, [x1, #7]
    // 0xde2e6c: d0 = 3.500000
    //     0xde2e6c: fmov            d0, #3.50000000
    // 0xde2e70: StoreField: r1->field_b = d0
    //     0xde2e70: stur            d0, [x1, #0xb]
    // 0xde2e74: r0 = Instance_BorderStyle
    //     0xde2e74: add             x0, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0xde2e78: ldr             x0, [x0, #0xdc8]
    // 0xde2e7c: StoreField: r1->field_13 = r0
    //     0xde2e7c: stur            w0, [x1, #0x13]
    // 0xde2e80: d0 = -1.000000
    //     0xde2e80: fmov            d0, #-1.00000000
    // 0xde2e84: ArrayStore: r1[0] = d0  ; List_8
    //     0xde2e84: stur            d0, [x1, #0x17]
    // 0xde2e88: b               #0xde2e94
    // 0xde2e8c: r1 = Instance_BorderSide
    //     0xde2e8c: add             x1, PP, #0x18, lsl #12  ; [pp+0x18310] Obj!BorderSide@12b1b31
    //     0xde2e90: ldr             x1, [x1, #0x310]
    // 0xde2e94: ldur            x0, [fp, #-8]
    // 0xde2e98: stur            x1, [fp, #-0x20]
    // 0xde2e9c: LoadField: r2 = r0->field_b
    //     0xde2e9c: ldur            w2, [x0, #0xb]
    // 0xde2ea0: DecompressPointer r2
    //     0xde2ea0: add             x2, x2, HEAP, lsl #32
    // 0xde2ea4: stur            x2, [fp, #-0x18]
    // 0xde2ea8: cmp             w2, NULL
    // 0xde2eac: b.eq            #0xde2f88
    // 0xde2eb0: LoadField: r0 = r2->field_b
    //     0xde2eb0: ldur            w0, [x2, #0xb]
    // 0xde2eb4: DecompressPointer r0
    //     0xde2eb4: add             x0, x0, HEAP, lsl #32
    // 0xde2eb8: stur            x0, [fp, #-8]
    // 0xde2ebc: r0 = RoundedRectangleBorder()
    //     0xde2ebc: bl              #0xd2ea90  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0xde2ec0: mov             x1, x0
    // 0xde2ec4: ldur            x0, [fp, #-8]
    // 0xde2ec8: stur            x1, [fp, #-0x28]
    // 0xde2ecc: StoreField: r1->field_b = r0
    //     0xde2ecc: stur            w0, [x1, #0xb]
    // 0xde2ed0: ldur            x0, [fp, #-0x20]
    // 0xde2ed4: StoreField: r1->field_7 = r0
    //     0xde2ed4: stur            w0, [x1, #7]
    // 0xde2ed8: r0 = ShapeDecoration()
    //     0xde2ed8: bl              #0xb6e288  ; AllocateShapeDecorationStub -> ShapeDecoration (size=0x1c)
    // 0xde2edc: mov             x1, x0
    // 0xde2ee0: ldur            x0, [fp, #-0x28]
    // 0xde2ee4: stur            x1, [fp, #-0x20]
    // 0xde2ee8: ArrayStore: r1[0] = r0  ; List_4
    //     0xde2ee8: stur            w0, [x1, #0x17]
    // 0xde2eec: ldur            x0, [fp, #-0x18]
    // 0xde2ef0: LoadField: r2 = r0->field_13
    //     0xde2ef0: ldur            w2, [x0, #0x13]
    // 0xde2ef4: DecompressPointer r2
    //     0xde2ef4: add             x2, x2, HEAP, lsl #32
    // 0xde2ef8: stur            x2, [fp, #-8]
    // 0xde2efc: r0 = DecoratedBox()
    //     0xde2efc: bl              #0xd66318  ; AllocateDecoratedBoxStub -> DecoratedBox (size=0x18)
    // 0xde2f00: mov             x1, x0
    // 0xde2f04: ldur            x0, [fp, #-0x20]
    // 0xde2f08: stur            x1, [fp, #-0x18]
    // 0xde2f0c: StoreField: r1->field_f = r0
    //     0xde2f0c: stur            w0, [x1, #0xf]
    // 0xde2f10: r0 = Instance_DecorationPosition
    //     0xde2f10: add             x0, PP, #0x80, lsl #12  ; [pp+0x80ef8] Obj!DecorationPosition@12c4361
    //     0xde2f14: ldr             x0, [x0, #0xef8]
    // 0xde2f18: StoreField: r1->field_13 = r0
    //     0xde2f18: stur            w0, [x1, #0x13]
    // 0xde2f1c: ldur            x0, [fp, #-8]
    // 0xde2f20: StoreField: r1->field_b = r0
    //     0xde2f20: stur            w0, [x1, #0xb]
    // 0xde2f24: r0 = Focus()
    //     0xde2f24: bl              #0xd1c8f0  ; AllocateFocusStub -> Focus (size=0x40)
    // 0xde2f28: mov             x3, x0
    // 0xde2f2c: ldur            x0, [fp, #-0x18]
    // 0xde2f30: stur            x3, [fp, #-8]
    // 0xde2f34: StoreField: r3->field_f = r0
    //     0xde2f34: stur            w0, [x3, #0xf]
    // 0xde2f38: r0 = false
    //     0xde2f38: add             x0, NULL, #0x30  ; false
    // 0xde2f3c: ArrayStore: r3[0] = r0  ; List_4
    //     0xde2f3c: stur            w0, [x3, #0x17]
    // 0xde2f40: ldur            x2, [fp, #-0x10]
    // 0xde2f44: r1 = Function '<anonymous closure>':.
    //     0xde2f44: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4f98] AnonymousClosure: (0xde30dc), in [package:flutter/src/cupertino/cupertino_focus_halo.dart] _CupertinoFocusHaloState::build (0xde2e00)
    //     0xde2f48: ldr             x1, [x1, #0xf98]
    // 0xde2f4c: r0 = AllocateClosure()
    //     0xde2f4c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xde2f50: mov             x1, x0
    // 0xde2f54: ldur            x0, [fp, #-8]
    // 0xde2f58: StoreField: r0->field_1b = r1
    //     0xde2f58: stur            w1, [x0, #0x1b]
    // 0xde2f5c: r1 = false
    //     0xde2f5c: add             x1, NULL, #0x30  ; false
    // 0xde2f60: StoreField: r0->field_37 = r1
    //     0xde2f60: stur            w1, [x0, #0x37]
    // 0xde2f64: StoreField: r0->field_27 = r1
    //     0xde2f64: stur            w1, [x0, #0x27]
    // 0xde2f68: r1 = true
    //     0xde2f68: add             x1, NULL, #0x20  ; true
    // 0xde2f6c: StoreField: r0->field_2b = r1
    //     0xde2f6c: stur            w1, [x0, #0x2b]
    // 0xde2f70: LeaveFrame
    //     0xde2f70: mov             SP, fp
    //     0xde2f74: ldp             fp, lr, [SP], #0x10
    // 0xde2f78: ret
    //     0xde2f78: ret             
    // 0xde2f7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde2f7c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde2f80: b               #0xde2e1c
    // 0xde2f84: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde2f84: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde2f88: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde2f88: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _effectiveFocusOutlineColor(/* No info */) {
    // ** addr: 0xde307c, size: 0x60
    // 0xde307c: EnterFrame
    //     0xde307c: stp             fp, lr, [SP, #-0x10]!
    //     0xde3080: mov             fp, SP
    // 0xde3084: CheckStackOverflow
    //     0xde3084: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde3088: cmp             SP, x16
    //     0xde308c: b.ls            #0xde30d4
    // 0xde3090: r1 = Instance_Color
    //     0xde3090: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4da8] Obj!Color@12a2a91
    //     0xde3094: ldr             x1, [x1, #0xda8]
    // 0xde3098: d0 = 0.800000
    //     0xde3098: add             x17, PP, #0x13, lsl #12  ; [pp+0x13a58] IMM: double(0.8) from 0x3fe999999999999a
    //     0xde309c: ldr             d0, [x17, #0xa58]
    // 0xde30a0: r0 = withOpacity()
    //     0xde30a0: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xde30a4: mov             x2, x0
    // 0xde30a8: r1 = Null
    //     0xde30a8: mov             x1, NULL
    // 0xde30ac: r0 = HSLColor.fromColor()
    //     0xde30ac: bl              #0xd43b8c  ; [package:flutter/src/painting/colors.dart] HSLColor::HSLColor.fromColor
    // 0xde30b0: mov             x1, x0
    // 0xde30b4: r0 = withLightness()
    //     0xde30b4: bl              #0xd43b34  ; [package:flutter/src/painting/colors.dart] HSLColor::withLightness
    // 0xde30b8: mov             x1, x0
    // 0xde30bc: r0 = withSaturation()
    //     0xde30bc: bl              #0xd43ad0  ; [package:flutter/src/painting/colors.dart] HSLColor::withSaturation
    // 0xde30c0: mov             x1, x0
    // 0xde30c4: r0 = toColor()
    //     0xde30c4: bl              #0xd43270  ; [package:flutter/src/painting/colors.dart] HSLColor::toColor
    // 0xde30c8: LeaveFrame
    //     0xde30c8: mov             SP, fp
    //     0xde30cc: ldp             fp, lr, [SP], #0x10
    // 0xde30d0: ret
    //     0xde30d0: ret             
    // 0xde30d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde30d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde30d8: b               #0xde3090
  }
  [closure] void <anonymous closure>(dynamic, bool) {
    // ** addr: 0xde30dc, size: 0x84
    // 0xde30dc: EnterFrame
    //     0xde30dc: stp             fp, lr, [SP, #-0x10]!
    //     0xde30e0: mov             fp, SP
    // 0xde30e4: AllocStack(0x10)
    //     0xde30e4: sub             SP, SP, #0x10
    // 0xde30e8: SetupParameters([dynamic _ /* r0 */])
    //     0xde30e8: ldr             x0, [fp, #0x18]
    //     0xde30ec: ldur            w1, [x0, #0x17]
    //     0xde30f0: add             x1, x1, HEAP, lsl #32
    //     0xde30f4: stur            x1, [fp, #-8]
    // 0xde30f8: CheckStackOverflow
    //     0xde30f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde30fc: cmp             SP, x16
    //     0xde3100: b.ls            #0xde3158
    // 0xde3104: r1 = 1
    //     0xde3104: mov             x1, #1
    // 0xde3108: r0 = AllocateContext()
    //     0xde3108: bl              #0x13de838  ; AllocateContextStub
    // 0xde310c: mov             x1, x0
    // 0xde3110: ldur            x0, [fp, #-8]
    // 0xde3114: StoreField: r1->field_b = r0
    //     0xde3114: stur            w0, [x1, #0xb]
    // 0xde3118: ldr             x2, [fp, #0x10]
    // 0xde311c: StoreField: r1->field_f = r2
    //     0xde311c: stur            w2, [x1, #0xf]
    // 0xde3120: LoadField: r3 = r0->field_f
    //     0xde3120: ldur            w3, [x0, #0xf]
    // 0xde3124: DecompressPointer r3
    //     0xde3124: add             x3, x3, HEAP, lsl #32
    // 0xde3128: mov             x2, x1
    // 0xde312c: stur            x3, [fp, #-0x10]
    // 0xde3130: r1 = Function '<anonymous closure>':.
    //     0xde3130: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4fa0] AnonymousClosure: (0xde3160), in [package:flutter/src/cupertino/cupertino_focus_halo.dart] _CupertinoFocusHaloState::build (0xde2e00)
    //     0xde3134: ldr             x1, [x1, #0xfa0]
    // 0xde3138: r0 = AllocateClosure()
    //     0xde3138: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xde313c: ldur            x1, [fp, #-0x10]
    // 0xde3140: mov             x2, x0
    // 0xde3144: r0 = setState()
    //     0xde3144: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xde3148: r0 = Null
    //     0xde3148: mov             x0, NULL
    // 0xde314c: LeaveFrame
    //     0xde314c: mov             SP, fp
    //     0xde3150: ldp             fp, lr, [SP], #0x10
    // 0xde3154: ret
    //     0xde3154: ret             
    // 0xde3158: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde3158: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde315c: b               #0xde3104
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xde3160, size: 0x30
    // 0xde3160: ldr             x1, [SP]
    // 0xde3164: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xde3164: ldur            w2, [x1, #0x17]
    // 0xde3168: DecompressPointer r2
    //     0xde3168: add             x2, x2, HEAP, lsl #32
    // 0xde316c: LoadField: r1 = r2->field_b
    //     0xde316c: ldur            w1, [x2, #0xb]
    // 0xde3170: DecompressPointer r1
    //     0xde3170: add             x1, x1, HEAP, lsl #32
    // 0xde3174: LoadField: r3 = r1->field_f
    //     0xde3174: ldur            w3, [x1, #0xf]
    // 0xde3178: DecompressPointer r3
    //     0xde3178: add             x3, x3, HEAP, lsl #32
    // 0xde317c: LoadField: r1 = r2->field_f
    //     0xde317c: ldur            w1, [x2, #0xf]
    // 0xde3180: DecompressPointer r1
    //     0xde3180: add             x1, x1, HEAP, lsl #32
    // 0xde3184: StoreField: r3->field_13 = r1
    //     0xde3184: stur            w1, [x3, #0x13]
    // 0xde3188: r0 = Null
    //     0xde3188: mov             x0, NULL
    // 0xde318c: ret
    //     0xde318c: ret             
  }
}

// class id: 6526, size: 0x18, field offset: 0xc
//   const constructor, 
class CupertinoFocusHalo extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa0384, size: 0x2c
    // 0xfa0384: EnterFrame
    //     0xfa0384: stp             fp, lr, [SP, #-0x10]!
    //     0xfa0388: mov             fp, SP
    // 0xfa038c: mov             x0, x1
    // 0xfa0390: r1 = <CupertinoFocusHalo>
    //     0xfa0390: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4eb8] TypeArguments: <CupertinoFocusHalo>
    //     0xfa0394: ldr             x1, [x1, #0xeb8]
    // 0xfa0398: r0 = _CupertinoFocusHaloState()
    //     0xfa0398: bl              #0xfa03b0  ; Allocate_CupertinoFocusHaloStateStub -> _CupertinoFocusHaloState (size=0x18)
    // 0xfa039c: r1 = false
    //     0xfa039c: add             x1, NULL, #0x30  ; false
    // 0xfa03a0: StoreField: r0->field_13 = r1
    //     0xfa03a0: stur            w1, [x0, #0x13]
    // 0xfa03a4: LeaveFrame
    //     0xfa03a4: mov             SP, fp
    //     0xfa03a8: ldp             fp, lr, [SP], #0x10
    // 0xfa03ac: ret
    //     0xfa03ac: ret             
  }
}
