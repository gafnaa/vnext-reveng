// lib: , url: package:flutter/src/cupertino/interface_level.dart

// class id: 1048780, size: 0x8
class :: {
}

// class id: 6820, size: 0x14, field offset: 0x10
//   const constructor, 
class CupertinoUserInterfaceLevel extends InheritedWidget {

  _ updateShouldNotify(/* No info */) {
    // ** addr: 0xc009f4, size: 0x5c
    // 0xc009f4: EnterFrame
    //     0xc009f4: stp             fp, lr, [SP, #-0x10]!
    //     0xc009f8: mov             fp, SP
    // 0xc009fc: mov             x0, x2
    // 0xc00a00: mov             x4, x1
    // 0xc00a04: mov             x3, x2
    // 0xc00a08: r2 = Null
    //     0xc00a08: mov             x2, NULL
    // 0xc00a0c: r1 = Null
    //     0xc00a0c: mov             x1, NULL
    // 0xc00a10: r4 = 60
    //     0xc00a10: mov             x4, #0x3c
    // 0xc00a14: branchIfSmi(r0, 0xc00a20)
    //     0xc00a14: tbz             w0, #0, #0xc00a20
    // 0xc00a18: r4 = LoadClassIdInstr(r0)
    //     0xc00a18: ldur            x4, [x0, #-1]
    //     0xc00a1c: ubfx            x4, x4, #0xc, #0x14
    // 0xc00a20: r17 = 6820
    //     0xc00a20: mov             x17, #0x1aa4
    // 0xc00a24: cmp             x4, x17
    // 0xc00a28: b.eq            #0xc00a40
    // 0xc00a2c: r8 = CupertinoUserInterfaceLevel
    //     0xc00a2c: add             x8, PP, #0xa1, lsl #12  ; [pp+0xa1030] Type: CupertinoUserInterfaceLevel
    //     0xc00a30: ldr             x8, [x8, #0x30]
    // 0xc00a34: r3 = Null
    //     0xc00a34: add             x3, PP, #0xa1, lsl #12  ; [pp+0xa1038] Null
    //     0xc00a38: ldr             x3, [x3, #0x38]
    // 0xc00a3c: r0 = DefaultTypeTest()
    //     0xc00a3c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xc00a40: r0 = false
    //     0xc00a40: add             x0, NULL, #0x30  ; false
    // 0xc00a44: LeaveFrame
    //     0xc00a44: mov             SP, fp
    //     0xc00a48: ldp             fp, lr, [SP], #0x10
    // 0xc00a4c: ret
    //     0xc00a4c: ret             
  }
  static _ maybeOf(/* No info */) {
    // ** addr: 0xce2188, size: 0x58
    // 0xce2188: EnterFrame
    //     0xce2188: stp             fp, lr, [SP, #-0x10]!
    //     0xce218c: mov             fp, SP
    // 0xce2190: AllocStack(0x10)
    //     0xce2190: sub             SP, SP, #0x10
    // 0xce2194: CheckStackOverflow
    //     0xce2194: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce2198: cmp             SP, x16
    //     0xce219c: b.ls            #0xce21d8
    // 0xce21a0: r16 = <CupertinoUserInterfaceLevel>
    //     0xce21a0: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e8a0] TypeArguments: <CupertinoUserInterfaceLevel>
    //     0xce21a4: ldr             x16, [x16, #0x8a0]
    // 0xce21a8: stp             x1, x16, [SP]
    // 0xce21ac: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xce21ac: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xce21b0: r0 = dependOnInheritedWidgetOfExactType()
    //     0xce21b0: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xce21b4: cmp             w0, NULL
    // 0xce21b8: b.ne            #0xce21c4
    // 0xce21bc: r0 = Null
    //     0xce21bc: mov             x0, NULL
    // 0xce21c0: b               #0xce21cc
    // 0xce21c4: r0 = Instance_CupertinoUserInterfaceLevelData
    //     0xce21c4: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e890] Obj!CupertinoUserInterfaceLevelData@12c5fe1
    //     0xce21c8: ldr             x0, [x0, #0x890]
    // 0xce21cc: LeaveFrame
    //     0xce21cc: mov             SP, fp
    //     0xce21d0: ldp             fp, lr, [SP], #0x10
    // 0xce21d4: ret
    //     0xce21d4: ret             
    // 0xce21d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce21d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce21dc: b               #0xce21a0
  }
}

// class id: 8318, size: 0x14, field offset: 0x14
enum CupertinoUserInterfaceLevelData extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11a9734, size: 0x64
    // 0x11a9734: EnterFrame
    //     0x11a9734: stp             fp, lr, [SP, #-0x10]!
    //     0x11a9738: mov             fp, SP
    // 0x11a973c: AllocStack(0x10)
    //     0x11a973c: sub             SP, SP, #0x10
    // 0x11a9740: SetupParameters(CupertinoUserInterfaceLevelData this /* r1 => r0, fp-0x8 */)
    //     0x11a9740: mov             x0, x1
    //     0x11a9744: stur            x1, [fp, #-8]
    // 0x11a9748: CheckStackOverflow
    //     0x11a9748: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a974c: cmp             SP, x16
    //     0x11a9750: b.ls            #0x11a9790
    // 0x11a9754: r1 = Null
    //     0x11a9754: mov             x1, NULL
    // 0x11a9758: r2 = 4
    //     0x11a9758: mov             x2, #4
    // 0x11a975c: r0 = AllocateArray()
    //     0x11a975c: bl              #0x13df928  ; AllocateArrayStub
    // 0x11a9760: r16 = "CupertinoUserInterfaceLevelData."
    //     0x11a9760: add             x16, PP, #0x80, lsl #12  ; [pp+0x80a40] "CupertinoUserInterfaceLevelData."
    //     0x11a9764: ldr             x16, [x16, #0xa40]
    // 0x11a9768: StoreField: r0->field_f = r16
    //     0x11a9768: stur            w16, [x0, #0xf]
    // 0x11a976c: ldur            x1, [fp, #-8]
    // 0x11a9770: LoadField: r2 = r1->field_f
    //     0x11a9770: ldur            w2, [x1, #0xf]
    // 0x11a9774: DecompressPointer r2
    //     0x11a9774: add             x2, x2, HEAP, lsl #32
    // 0x11a9778: StoreField: r0->field_13 = r2
    //     0x11a9778: stur            w2, [x0, #0x13]
    // 0x11a977c: str             x0, [SP]
    // 0x11a9780: r0 = _interpolate()
    //     0x11a9780: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11a9784: LeaveFrame
    //     0x11a9784: mov             SP, fp
    //     0x11a9788: ldp             fp, lr, [SP], #0x10
    // 0x11a978c: ret
    //     0x11a978c: ret             
    // 0x11a9790: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a9790: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a9794: b               #0x11a9754
  }
}
