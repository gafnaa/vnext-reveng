// lib: , url: package:flutter/src/cupertino/slider.dart

// class id: 1048785, size: 0x8
class :: {
}

// class id: 4962, size: 0xa4, field offset: 0x58
class _RenderCupertinoSlider extends RenderConstrainedBox
    implements MouseTrackerAnnotation {

  late AnimationController _position; // offset: 0x84
  late HorizontalDragGestureRecognizer _drag; // offset: 0x88

  _ hitTestSelf(/* No info */) {
    // ** addr: 0xb5ce4c, size: 0x84
    // 0xb5ce4c: EnterFrame
    //     0xb5ce4c: stp             fp, lr, [SP, #-0x10]!
    //     0xb5ce50: mov             fp, SP
    // 0xb5ce54: AllocStack(0x8)
    //     0xb5ce54: sub             SP, SP, #8
    // 0xb5ce58: CheckStackOverflow
    //     0xb5ce58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb5ce5c: cmp             SP, x16
    //     0xb5ce60: b.ls            #0xb5cec8
    // 0xb5ce64: LoadField: d0 = r2->field_7
    //     0xb5ce64: ldur            d0, [x2, #7]
    // 0xb5ce68: stur            d0, [fp, #-8]
    // 0xb5ce6c: r0 = _thumbCenter()
    //     0xb5ce6c: bl              #0xb5d05c  ; [package:flutter/src/cupertino/slider.dart] _RenderCupertinoSlider::_thumbCenter
    // 0xb5ce70: mov             v1.16b, v0.16b
    // 0xb5ce74: ldur            d0, [fp, #-8]
    // 0xb5ce78: fsub            d2, d0, d1
    // 0xb5ce7c: d0 = 0.000000
    //     0xb5ce7c: eor             v0.16b, v0.16b, v0.16b
    // 0xb5ce80: fcmp            d2, d0
    // 0xb5ce84: b.ne            #0xb5ce90
    // 0xb5ce88: d1 = 0.000000
    //     0xb5ce88: eor             v1.16b, v1.16b, v1.16b
    // 0xb5ce8c: b               #0xb5cea8
    // 0xb5ce90: fcmp            d0, d2
    // 0xb5ce94: b.le            #0xb5cea0
    // 0xb5ce98: fneg            d0, d2
    // 0xb5ce9c: b               #0xb5cea4
    // 0xb5cea0: mov             v0.16b, v2.16b
    // 0xb5cea4: mov             v1.16b, v0.16b
    // 0xb5cea8: d0 = 22.000000
    //     0xb5cea8: fmov            d0, #22.00000000
    // 0xb5ceac: fcmp            d0, d1
    // 0xb5ceb0: r16 = true
    //     0xb5ceb0: add             x16, NULL, #0x20  ; true
    // 0xb5ceb4: r17 = false
    //     0xb5ceb4: add             x17, NULL, #0x30  ; false
    // 0xb5ceb8: csel            x0, x16, x17, gt
    // 0xb5cebc: LeaveFrame
    //     0xb5cebc: mov             SP, fp
    //     0xb5cec0: ldp             fp, lr, [SP], #0x10
    // 0xb5cec4: ret
    //     0xb5cec4: ret             
    // 0xb5cec8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb5cec8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb5cecc: b               #0xb5ce64
  }
  double dyn:get:value(_RenderCupertinoSlider) {
    // ** addr: 0xb5cee8, size: 0x70
    // 0xb5cee8: EnterFrame
    //     0xb5cee8: stp             fp, lr, [SP, #-0x10]!
    //     0xb5ceec: mov             fp, SP
    // 0xb5cef0: ldr             x1, [fp, #0x10]
    // 0xb5cef4: LoadField: d0 = r1->field_57
    //     0xb5cef4: ldur            d0, [x1, #0x57]
    // 0xb5cef8: r0 = inline_Allocate_Double()
    //     0xb5cef8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb5cefc: add             x0, x0, #0x10
    //     0xb5cf00: cmp             x1, x0
    //     0xb5cf04: b.ls            #0xb5cf30
    //     0xb5cf08: str             x0, [THR, #0x60]  ; THR::top
    //     0xb5cf0c: sub             x0, x0, #0xf
    //     0xb5cf10: mov             x1, #0xe19c
    //     0xb5cf14: movk            x1, #3, lsl #16
    //     0xb5cf18: stur            x1, [x0, #-1]
    // 0xb5cf1c: dmb             ishst
    // 0xb5cf20: StoreField: r0->field_7 = d0
    //     0xb5cf20: stur            d0, [x0, #7]
    // 0xb5cf24: LeaveFrame
    //     0xb5cf24: mov             SP, fp
    //     0xb5cf28: ldp             fp, lr, [SP], #0x10
    // 0xb5cf2c: ret
    //     0xb5cf2c: ret             
    // 0xb5cf30: SaveReg d0
    //     0xb5cf30: str             q0, [SP, #-0x10]!
    // 0xb5cf34: r0 = AllocateDouble()
    //     0xb5cf34: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb5cf38: RestoreReg d0
    //     0xb5cf38: ldr             q0, [SP], #0x10
    // 0xb5cf3c: b               #0xb5cf20
  }
  void dyn:set:value(_RenderCupertinoSlider, double) {
    // ** addr: 0xb5cf58, size: 0x80
    // 0xb5cf58: EnterFrame
    //     0xb5cf58: stp             fp, lr, [SP, #-0x10]!
    //     0xb5cf5c: mov             fp, SP
    // 0xb5cf60: CheckStackOverflow
    //     0xb5cf60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb5cf64: cmp             SP, x16
    //     0xb5cf68: b.ls            #0xb5cfb8
    // 0xb5cf6c: ldr             x0, [fp, #0x10]
    // 0xb5cf70: r2 = Null
    //     0xb5cf70: mov             x2, NULL
    // 0xb5cf74: r1 = Null
    //     0xb5cf74: mov             x1, NULL
    // 0xb5cf78: r4 = 60
    //     0xb5cf78: mov             x4, #0x3c
    // 0xb5cf7c: branchIfSmi(r0, 0xb5cf88)
    //     0xb5cf7c: tbz             w0, #0, #0xb5cf88
    // 0xb5cf80: r4 = LoadClassIdInstr(r0)
    //     0xb5cf80: ldur            x4, [x0, #-1]
    //     0xb5cf84: ubfx            x4, x4, #0xc, #0x14
    // 0xb5cf88: cmp             x4, #0x3e
    // 0xb5cf8c: b.eq            #0xb5cfa0
    // 0xb5cf90: r8 = double
    //     0xb5cf90: ldr             x8, [PP, #0x6e90]  ; [pp+0x6e90] Type: double
    // 0xb5cf94: r3 = Null
    //     0xb5cf94: add             x3, PP, #0xd0, lsl #12  ; [pp+0xd0110] Null
    //     0xb5cf98: ldr             x3, [x3, #0x110]
    // 0xb5cf9c: r0 = double()
    //     0xb5cf9c: bl              #0x13ee3d0  ; IsType_double_Stub
    // 0xb5cfa0: ldr             x1, [fp, #0x18]
    // 0xb5cfa4: ldr             x2, [fp, #0x10]
    // 0xb5cfa8: r0 = value=()
    //     0xb5cfa8: bl              #0xb5cfc0  ; [package:flutter/src/cupertino/slider.dart] _RenderCupertinoSlider::value=
    // 0xb5cfac: LeaveFrame
    //     0xb5cfac: mov             SP, fp
    //     0xb5cfb0: ldp             fp, lr, [SP], #0x10
    // 0xb5cfb4: ret
    //     0xb5cfb4: ret             
    // 0xb5cfb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb5cfb8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb5cfbc: b               #0xb5cf6c
  }
  set void value=(_RenderCupertinoSlider, double) {
    // ** addr: 0xb5cfc0, size: 0x9c
    // 0xb5cfc0: EnterFrame
    //     0xb5cfc0: stp             fp, lr, [SP, #-0x10]!
    //     0xb5cfc4: mov             fp, SP
    // 0xb5cfc8: AllocStack(0x10)
    //     0xb5cfc8: sub             SP, SP, #0x10
    // 0xb5cfcc: SetupParameters(_RenderCupertinoSlider this /* r1 => r0, fp-0x8 */)
    //     0xb5cfcc: mov             x0, x1
    //     0xb5cfd0: stur            x1, [fp, #-8]
    // 0xb5cfd4: CheckStackOverflow
    //     0xb5cfd4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb5cfd8: cmp             SP, x16
    //     0xb5cfdc: b.ls            #0xb5d048
    // 0xb5cfe0: LoadField: d0 = r0->field_57
    //     0xb5cfe0: ldur            d0, [x0, #0x57]
    // 0xb5cfe4: LoadField: d1 = r2->field_7
    //     0xb5cfe4: ldur            d1, [x2, #7]
    // 0xb5cfe8: fcmp            d1, d0
    // 0xb5cfec: b.ne            #0xb5d000
    // 0xb5cff0: r0 = Null
    //     0xb5cff0: mov             x0, NULL
    // 0xb5cff4: LeaveFrame
    //     0xb5cff4: mov             SP, fp
    //     0xb5cff8: ldp             fp, lr, [SP], #0x10
    // 0xb5cffc: ret
    //     0xb5cffc: ret             
    // 0xb5d000: StoreField: r0->field_57 = d1
    //     0xb5d000: stur            d1, [x0, #0x57]
    // 0xb5d004: LoadField: r1 = r0->field_83
    //     0xb5d004: ldur            w1, [x0, #0x83]
    // 0xb5d008: DecompressPointer r1
    //     0xb5d008: add             x1, x1, HEAP, lsl #32
    // 0xb5d00c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb5d010: cmp             w1, w16
    // 0xb5d014: b.eq            #0xb5d050
    // 0xb5d018: r16 = Instance_Cubic
    //     0xb5d018: ldr             x16, [PP, #0x5660]  ; [pp+0x5660] Obj!Cubic@129f451
    // 0xb5d01c: str             x16, [SP]
    // 0xb5d020: mov             v0.16b, v1.16b
    // 0xb5d024: r4 = const [0, 0x3, 0x1, 0x2, curve, 0x2, null]
    //     0xb5d024: add             x4, PP, #0xa3, lsl #12  ; [pp+0xa3758] List(7) [0, 0x3, 0x1, 0x2, "curve", 0x2, Null]
    //     0xb5d028: ldr             x4, [x4, #0x758]
    // 0xb5d02c: r0 = animateTo()
    //     0xb5d02c: bl              #0x866084  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::animateTo
    // 0xb5d030: ldur            x1, [fp, #-8]
    // 0xb5d034: r0 = markNeedsSemanticsUpdate()
    //     0xb5d034: bl              #0x8373c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0xb5d038: r0 = Null
    //     0xb5d038: mov             x0, NULL
    // 0xb5d03c: LeaveFrame
    //     0xb5d03c: mov             SP, fp
    //     0xb5d040: ldp             fp, lr, [SP], #0x10
    // 0xb5d044: ret
    //     0xb5d044: ret             
    // 0xb5d048: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb5d048: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb5d04c: b               #0xb5cfe0
    // 0xb5d050: r9 = _position
    //     0xb5d050: add             x9, PP, #0xcc, lsl #12  ; [pp+0xcc868] Field <_RenderCupertinoSlider@296348729._position@296348729>: late (offset: 0x84)
    //     0xb5d054: ldr             x9, [x9, #0x868]
    // 0xb5d058: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xb5d058: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
  }
  double _thumbCenter(_RenderCupertinoSlider) {
    // ** addr: 0xb5d05c, size: 0x110
    // 0xb5d05c: EnterFrame
    //     0xb5d05c: stp             fp, lr, [SP, #-0x10]!
    //     0xb5d060: mov             fp, SP
    // 0xb5d064: AllocStack(0x8)
    //     0xb5d064: sub             SP, SP, #8
    // 0xb5d068: CheckStackOverflow
    //     0xb5d068: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb5d06c: cmp             SP, x16
    //     0xb5d070: b.ls            #0xb5d134
    // 0xb5d074: LoadField: r0 = r1->field_7f
    //     0xb5d074: ldur            w0, [x1, #0x7f]
    // 0xb5d078: DecompressPointer r0
    //     0xb5d078: add             x0, x0, HEAP, lsl #32
    // 0xb5d07c: LoadField: r2 = r0->field_7
    //     0xb5d07c: ldur            x2, [x0, #7]
    // 0xb5d080: cmp             x2, #0
    // 0xb5d084: b.gt            #0xb5d09c
    // 0xb5d088: d0 = 1.000000
    //     0xb5d088: fmov            d0, #1.00000000
    // 0xb5d08c: LoadField: d1 = r1->field_57
    //     0xb5d08c: ldur            d1, [x1, #0x57]
    // 0xb5d090: fsub            d2, d0, d1
    // 0xb5d094: mov             v0.16b, v2.16b
    // 0xb5d098: b               #0xb5d0a0
    // 0xb5d09c: LoadField: d0 = r1->field_57
    //     0xb5d09c: ldur            d0, [x1, #0x57]
    // 0xb5d0a0: stur            d0, [fp, #-8]
    // 0xb5d0a4: r0 = size()
    //     0xb5d0a4: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xb5d0a8: LoadField: d0 = r0->field_7
    //     0xb5d0a8: ldur            d0, [x0, #7]
    // 0xb5d0ac: d1 = 8.000000
    //     0xb5d0ac: fmov            d1, #8.00000000
    // 0xb5d0b0: fsub            d2, d0, d1
    // 0xb5d0b4: d0 = 14.000000
    //     0xb5d0b4: fmov            d0, #14.00000000
    // 0xb5d0b8: fsub            d1, d2, d0
    // 0xb5d0bc: ldur            d0, [fp, #-8]
    // 0xb5d0c0: r3 = inline_Allocate_Double()
    //     0xb5d0c0: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0xb5d0c4: add             x3, x3, #0x10
    //     0xb5d0c8: cmp             x0, x3
    //     0xb5d0cc: b.ls            #0xb5d13c
    //     0xb5d0d0: str             x3, [THR, #0x60]  ; THR::top
    //     0xb5d0d4: sub             x3, x3, #0xf
    //     0xb5d0d8: mov             x0, #0xe19c
    //     0xb5d0dc: movk            x0, #3, lsl #16
    //     0xb5d0e0: stur            x0, [x3, #-1]
    // 0xb5d0e4: dmb             ishst
    // 0xb5d0e8: StoreField: r3->field_7 = d0
    //     0xb5d0e8: stur            d0, [x3, #7]
    // 0xb5d0ec: r2 = inline_Allocate_Double()
    //     0xb5d0ec: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0xb5d0f0: add             x2, x2, #0x10
    //     0xb5d0f4: cmp             x0, x2
    //     0xb5d0f8: b.ls            #0xb5d150
    //     0xb5d0fc: str             x2, [THR, #0x60]  ; THR::top
    //     0xb5d100: sub             x2, x2, #0xf
    //     0xb5d104: mov             x0, #0xe19c
    //     0xb5d108: movk            x0, #3, lsl #16
    //     0xb5d10c: stur            x0, [x2, #-1]
    // 0xb5d110: dmb             ishst
    // 0xb5d114: StoreField: r2->field_7 = d1
    //     0xb5d114: stur            d1, [x2, #7]
    // 0xb5d118: r1 = 22.000000
    //     0xb5d118: add             x1, PP, #0x7b, lsl #12  ; [pp+0x7b568] 22
    //     0xb5d11c: ldr             x1, [x1, #0x568]
    // 0xb5d120: r0 = lerpDouble()
    //     0xb5d120: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0xb5d124: LoadField: d0 = r0->field_7
    //     0xb5d124: ldur            d0, [x0, #7]
    // 0xb5d128: LeaveFrame
    //     0xb5d128: mov             SP, fp
    //     0xb5d12c: ldp             fp, lr, [SP], #0x10
    // 0xb5d130: ret
    //     0xb5d130: ret             
    // 0xb5d134: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb5d134: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb5d138: b               #0xb5d074
    // 0xb5d13c: stp             q0, q1, [SP, #-0x20]!
    // 0xb5d140: r0 = AllocateDouble()
    //     0xb5d140: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb5d144: mov             x3, x0
    // 0xb5d148: ldp             q0, q1, [SP], #0x20
    // 0xb5d14c: b               #0xb5d0e8
    // 0xb5d150: SaveReg d1
    //     0xb5d150: str             q1, [SP, #-0x10]!
    // 0xb5d154: SaveReg r3
    //     0xb5d154: str             x3, [SP, #-8]!
    // 0xb5d158: r0 = AllocateDouble()
    //     0xb5d158: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb5d15c: mov             x2, x0
    // 0xb5d160: RestoreReg r3
    //     0xb5d160: ldr             x3, [SP], #8
    // 0xb5d164: RestoreReg d1
    //     0xb5d164: ldr             q1, [SP], #0x10
    // 0xb5d168: b               #0xb5d114
  }
  double _trackRight(_RenderCupertinoSlider) {
    // ** addr: 0xb5d16c, size: 0x38
    // 0xb5d16c: EnterFrame
    //     0xb5d16c: stp             fp, lr, [SP, #-0x10]!
    //     0xb5d170: mov             fp, SP
    // 0xb5d174: CheckStackOverflow
    //     0xb5d174: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb5d178: cmp             SP, x16
    //     0xb5d17c: b.ls            #0xb5d19c
    // 0xb5d180: r0 = size()
    //     0xb5d180: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xb5d184: LoadField: d1 = r0->field_7
    //     0xb5d184: ldur            d1, [x0, #7]
    // 0xb5d188: d2 = 8.000000
    //     0xb5d188: fmov            d2, #8.00000000
    // 0xb5d18c: fsub            d0, d1, d2
    // 0xb5d190: LeaveFrame
    //     0xb5d190: mov             SP, fp
    //     0xb5d194: ldp             fp, lr, [SP], #0x10
    // 0xb5d198: ret
    //     0xb5d198: ret             
    // 0xb5d19c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb5d19c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb5d1a0: b               #0xb5d180
  }
  _ describeSemanticsConfiguration(/* No info */) {
    // ** addr: 0xbf4c0c, size: 0x49c
    // 0xbf4c0c: EnterFrame
    //     0xbf4c0c: stp             fp, lr, [SP, #-0x10]!
    //     0xbf4c10: mov             fp, SP
    // 0xbf4c14: AllocStack(0x28)
    //     0xbf4c14: sub             SP, SP, #0x28
    // 0xbf4c18: r0 = true
    //     0xbf4c18: add             x0, NULL, #0x20  ; true
    // 0xbf4c1c: mov             x3, x1
    // 0xbf4c20: stur            x1, [fp, #-8]
    // 0xbf4c24: stur            x2, [fp, #-0x10]
    // 0xbf4c28: CheckStackOverflow
    //     0xbf4c28: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf4c2c: cmp             SP, x16
    //     0xbf4c30: b.ls            #0xbf502c
    // 0xbf4c34: StoreField: r2->field_7 = r0
    //     0xbf4c34: stur            w0, [x2, #7]
    // 0xbf4c38: LoadField: r1 = r2->field_c3
    //     0xbf4c38: ldur            w1, [x2, #0xc3]
    // 0xbf4c3c: DecompressPointer r1
    //     0xbf4c3c: add             x1, x1, HEAP, lsl #32
    // 0xbf4c40: r16 = true
    //     0xbf4c40: add             x16, NULL, #0x20  ; true
    // 0xbf4c44: str             x16, [SP]
    // 0xbf4c48: r4 = const [0, 0x2, 0x1, 0x1, isSlider, 0x1, null]
    //     0xbf4c48: add             x4, PP, #0xad, lsl #12  ; [pp+0xad748] List(7) [0, 0x2, 0x1, 0x1, "isSlider", 0x1, Null]
    //     0xbf4c4c: ldr             x4, [x4, #0x748]
    // 0xbf4c50: r0 = copyWith()
    //     0xbf4c50: bl              #0x8905b0  ; [dart:ui] SemanticsFlags::copyWith
    // 0xbf4c54: ldur            x3, [fp, #-0x10]
    // 0xbf4c58: StoreField: r3->field_c3 = r0
    //     0xbf4c58: stur            w0, [x3, #0xc3]
    //     0xbf4c5c: ldurb           w16, [x3, #-1]
    //     0xbf4c60: ldurb           w17, [x0, #-1]
    //     0xbf4c64: and             x16, x17, x16, lsr #2
    //     0xbf4c68: tst             x16, HEAP, lsr #32
    //     0xbf4c6c: b.eq            #0xbf4c74
    //     0xbf4c70: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbf4c74: r4 = true
    //     0xbf4c74: add             x4, NULL, #0x20  ; true
    // 0xbf4c78: StoreField: r3->field_1f = r4
    //     0xbf4c78: stur            w4, [x3, #0x1f]
    // 0xbf4c7c: ldur            x5, [fp, #-8]
    // 0xbf4c80: LoadField: r0 = r5->field_7f
    //     0xbf4c80: ldur            w0, [x5, #0x7f]
    // 0xbf4c84: DecompressPointer r0
    //     0xbf4c84: add             x0, x0, HEAP, lsl #32
    // 0xbf4c88: StoreField: r3->field_83 = r0
    //     0xbf4c88: stur            w0, [x3, #0x83]
    //     0xbf4c8c: ldurb           w16, [x3, #-1]
    //     0xbf4c90: ldurb           w17, [x0, #-1]
    //     0xbf4c94: and             x16, x17, x16, lsr #2
    //     0xbf4c98: tst             x16, HEAP, lsr #32
    //     0xbf4c9c: b.eq            #0xbf4ca4
    //     0xbf4ca0: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbf4ca4: mov             x2, x5
    // 0xbf4ca8: r1 = Function '_increaseAction@296348729':.
    //     0xbf4ca8: add             x1, PP, #0xd0, lsl #12  ; [pp+0xd00e8] AnonymousClosure: (0xbf54bc), in [package:flutter/src/cupertino/slider.dart] _RenderCupertinoSlider::_increaseAction (0xbf54f4)
    //     0xbf4cac: ldr             x1, [x1, #0xe8]
    // 0xbf4cb0: r0 = AllocateClosure()
    //     0xbf4cb0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xbf4cb4: ldur            x1, [fp, #-0x10]
    // 0xbf4cb8: mov             x3, x0
    // 0xbf4cbc: r2 = Instance_SemanticsAction
    //     0xbf4cbc: add             x2, PP, #0xad, lsl #12  ; [pp+0xad740] Obj!SemanticsAction@12a0821
    //     0xbf4cc0: ldr             x2, [x2, #0x740]
    // 0xbf4cc4: r0 = _addArgumentlessAction()
    //     0xbf4cc4: bl              #0xbf36cc  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::_addArgumentlessAction
    // 0xbf4cc8: ldur            x2, [fp, #-8]
    // 0xbf4ccc: r1 = Function '_decreaseAction@296348729':.
    //     0xbf4ccc: add             x1, PP, #0xd0, lsl #12  ; [pp+0xd00f0] AnonymousClosure: (0xbf5270), in [package:flutter/src/cupertino/slider.dart] _RenderCupertinoSlider::_decreaseAction (0xbf52a8)
    //     0xbf4cd0: ldr             x1, [x1, #0xf0]
    // 0xbf4cd4: r0 = AllocateClosure()
    //     0xbf4cd4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xbf4cd8: ldur            x1, [fp, #-0x10]
    // 0xbf4cdc: mov             x3, x0
    // 0xbf4ce0: r2 = Instance_SemanticsAction
    //     0xbf4ce0: add             x2, PP, #0xad, lsl #12  ; [pp+0xad738] Obj!SemanticsAction@12a0801
    //     0xbf4ce4: ldr             x2, [x2, #0x738]
    // 0xbf4ce8: r0 = _addArgumentlessAction()
    //     0xbf4ce8: bl              #0xbf36cc  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::_addArgumentlessAction
    // 0xbf4cec: ldur            x19, [fp, #-8]
    // 0xbf4cf0: LoadField: d0 = r19->field_57
    //     0xbf4cf0: ldur            d0, [x19, #0x57]
    // 0xbf4cf4: d1 = 100.000000
    //     0xbf4cf4: add             x17, PP, #0x13, lsl #12  ; [pp+0x130a8] IMM: double(100) from 0x4059000000000000
    //     0xbf4cf8: ldr             d1, [x17, #0xa8]
    // 0xbf4cfc: fmul            d2, d0, d1
    // 0xbf4d00: mov             v0.16b, v2.16b
    // 0xbf4d04: stp             fp, lr, [SP, #-0x10]!
    // 0xbf4d08: mov             fp, SP
    // 0xbf4d0c: CallRuntime_LibcRound(double) -> double
    //     0xbf4d0c: and             SP, SP, #0xfffffffffffffff0
    //     0xbf4d10: mov             sp, SP
    //     0xbf4d14: ldr             x16, [THR, #0x770]  ; THR::LibcRound
    //     0xbf4d18: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xbf4d1c: blr             x16
    //     0xbf4d20: mov             x16, #8
    //     0xbf4d24: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xbf4d28: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xbf4d2c: sub             sp, x16, #1, lsl #12
    //     0xbf4d30: mov             SP, fp
    //     0xbf4d34: ldp             fp, lr, [SP], #0x10
    // 0xbf4d38: fcmp            d0, d0
    // 0xbf4d3c: b.vs            #0xbf5034
    // 0xbf4d40: fcvtzs          x0, d0
    // 0xbf4d44: asr             x16, x0, #0x1e
    // 0xbf4d48: cmp             x16, x0, asr #63
    // 0xbf4d4c: b.ne            #0xbf5034
    // 0xbf4d50: lsl             x0, x0, #1
    // 0xbf4d54: stur            x0, [fp, #-0x18]
    // 0xbf4d58: r1 = Null
    //     0xbf4d58: mov             x1, NULL
    // 0xbf4d5c: r2 = 4
    //     0xbf4d5c: mov             x2, #4
    // 0xbf4d60: r0 = AllocateArray()
    //     0xbf4d60: bl              #0x13df928  ; AllocateArrayStub
    // 0xbf4d64: mov             x1, x0
    // 0xbf4d68: ldur            x0, [fp, #-0x18]
    // 0xbf4d6c: StoreField: r1->field_f = r0
    //     0xbf4d6c: stur            w0, [x1, #0xf]
    // 0xbf4d70: r16 = "%"
    //     0xbf4d70: ldr             x16, [PP, #0x10c0]  ; [pp+0x10c0] "%"
    // 0xbf4d74: StoreField: r1->field_13 = r16
    //     0xbf4d74: stur            w16, [x1, #0x13]
    // 0xbf4d78: str             x1, [SP]
    // 0xbf4d7c: r0 = _interpolate()
    //     0xbf4d7c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xbf4d80: stur            x0, [fp, #-0x18]
    // 0xbf4d84: r0 = AttributedString()
    //     0xbf4d84: bl              #0x837ffc  ; AllocateAttributedStringStub -> AttributedString (size=0x10)
    // 0xbf4d88: mov             x1, x0
    // 0xbf4d8c: ldur            x0, [fp, #-0x18]
    // 0xbf4d90: StoreField: r1->field_7 = r0
    //     0xbf4d90: stur            w0, [x1, #7]
    // 0xbf4d94: r2 = const []
    //     0xbf4d94: ldr             x2, [PP, #0x2708]  ; [pp+0x2708] List<StringAttribute>(0)
    // 0xbf4d98: StoreField: r1->field_b = r2
    //     0xbf4d98: stur            w2, [x1, #0xb]
    // 0xbf4d9c: mov             x0, x1
    // 0xbf4da0: ldur            x3, [fp, #-0x10]
    // 0xbf4da4: StoreField: r3->field_6b = r0
    //     0xbf4da4: stur            w0, [x3, #0x6b]
    //     0xbf4da8: ldurb           w16, [x3, #-1]
    //     0xbf4dac: ldurb           w17, [x0, #-1]
    //     0xbf4db0: and             x16, x17, x16, lsr #2
    //     0xbf4db4: tst             x16, HEAP, lsr #32
    //     0xbf4db8: b.eq            #0xbf4dc0
    //     0xbf4dbc: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbf4dc0: r0 = true
    //     0xbf4dc0: add             x0, NULL, #0x20  ; true
    // 0xbf4dc4: StoreField: r3->field_1f = r0
    //     0xbf4dc4: stur            w0, [x3, #0x1f]
    // 0xbf4dc8: ldur            x4, [fp, #-8]
    // 0xbf4dcc: LoadField: d0 = r4->field_57
    //     0xbf4dcc: ldur            d0, [x4, #0x57]
    // 0xbf4dd0: mov             x1, x4
    // 0xbf4dd4: stur            d0, [fp, #-0x20]
    // 0xbf4dd8: r0 = _semanticActionUnit()
    //     0xbf4dd8: bl              #0xbf525c  ; [package:flutter/src/cupertino/slider.dart] _RenderCupertinoSlider::_semanticActionUnit
    // 0xbf4ddc: mov             v1.16b, v0.16b
    // 0xbf4de0: ldur            d0, [fp, #-0x20]
    // 0xbf4de4: fadd            d2, d0, d1
    // 0xbf4de8: d1 = 0.000000
    //     0xbf4de8: eor             v1.16b, v1.16b, v1.16b
    // 0xbf4dec: fcmp            d1, d2
    // 0xbf4df0: b.le            #0xbf4e00
    // 0xbf4df4: d0 = 0.000000
    //     0xbf4df4: eor             v0.16b, v0.16b, v0.16b
    // 0xbf4df8: d3 = 1.000000
    //     0xbf4df8: fmov            d3, #1.00000000
    // 0xbf4dfc: b               #0xbf4e28
    // 0xbf4e00: d3 = 1.000000
    //     0xbf4e00: fmov            d3, #1.00000000
    // 0xbf4e04: fcmp            d2, d3
    // 0xbf4e08: b.le            #0xbf4e14
    // 0xbf4e0c: d0 = 1.000000
    //     0xbf4e0c: fmov            d0, #1.00000000
    // 0xbf4e10: b               #0xbf4e28
    // 0xbf4e14: fcmp            d2, d2
    // 0xbf4e18: b.vc            #0xbf4e24
    // 0xbf4e1c: d0 = 1.000000
    //     0xbf4e1c: fmov            d0, #1.00000000
    // 0xbf4e20: b               #0xbf4e28
    // 0xbf4e24: mov             v0.16b, v2.16b
    // 0xbf4e28: ldur            x20, [fp, #-8]
    // 0xbf4e2c: ldur            x19, [fp, #-0x10]
    // 0xbf4e30: d2 = 100.000000
    //     0xbf4e30: add             x17, PP, #0x13, lsl #12  ; [pp+0x130a8] IMM: double(100) from 0x4059000000000000
    //     0xbf4e34: ldr             d2, [x17, #0xa8]
    // 0xbf4e38: fmul            d4, d0, d2
    // 0xbf4e3c: mov             v0.16b, v4.16b
    // 0xbf4e40: stp             fp, lr, [SP, #-0x10]!
    // 0xbf4e44: mov             fp, SP
    // 0xbf4e48: CallRuntime_LibcRound(double) -> double
    //     0xbf4e48: and             SP, SP, #0xfffffffffffffff0
    //     0xbf4e4c: mov             sp, SP
    //     0xbf4e50: ldr             x16, [THR, #0x770]  ; THR::LibcRound
    //     0xbf4e54: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xbf4e58: blr             x16
    //     0xbf4e5c: mov             x16, #8
    //     0xbf4e60: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xbf4e64: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xbf4e68: sub             sp, x16, #1, lsl #12
    //     0xbf4e6c: mov             SP, fp
    //     0xbf4e70: ldp             fp, lr, [SP], #0x10
    // 0xbf4e74: fcmp            d0, d0
    // 0xbf4e78: b.vs            #0xbf5058
    // 0xbf4e7c: fcvtzs          x0, d0
    // 0xbf4e80: asr             x16, x0, #0x1e
    // 0xbf4e84: cmp             x16, x0, asr #63
    // 0xbf4e88: b.ne            #0xbf5058
    // 0xbf4e8c: lsl             x0, x0, #1
    // 0xbf4e90: stur            x0, [fp, #-0x18]
    // 0xbf4e94: r1 = Null
    //     0xbf4e94: mov             x1, NULL
    // 0xbf4e98: r2 = 4
    //     0xbf4e98: mov             x2, #4
    // 0xbf4e9c: r0 = AllocateArray()
    //     0xbf4e9c: bl              #0x13df928  ; AllocateArrayStub
    // 0xbf4ea0: mov             x1, x0
    // 0xbf4ea4: ldur            x0, [fp, #-0x18]
    // 0xbf4ea8: StoreField: r1->field_f = r0
    //     0xbf4ea8: stur            w0, [x1, #0xf]
    // 0xbf4eac: r16 = "%"
    //     0xbf4eac: ldr             x16, [PP, #0x10c0]  ; [pp+0x10c0] "%"
    // 0xbf4eb0: StoreField: r1->field_13 = r16
    //     0xbf4eb0: stur            w16, [x1, #0x13]
    // 0xbf4eb4: str             x1, [SP]
    // 0xbf4eb8: r0 = _interpolate()
    //     0xbf4eb8: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xbf4ebc: stur            x0, [fp, #-0x18]
    // 0xbf4ec0: r0 = AttributedString()
    //     0xbf4ec0: bl              #0x837ffc  ; AllocateAttributedStringStub -> AttributedString (size=0x10)
    // 0xbf4ec4: mov             x1, x0
    // 0xbf4ec8: ldur            x0, [fp, #-0x18]
    // 0xbf4ecc: StoreField: r1->field_7 = r0
    //     0xbf4ecc: stur            w0, [x1, #7]
    // 0xbf4ed0: r19 = const []
    //     0xbf4ed0: ldr             x19, [PP, #0x2708]  ; [pp+0x2708] List<StringAttribute>(0)
    // 0xbf4ed4: StoreField: r1->field_b = r19
    //     0xbf4ed4: stur            w19, [x1, #0xb]
    // 0xbf4ed8: mov             x0, x1
    // 0xbf4edc: ldur            x20, [fp, #-0x10]
    // 0xbf4ee0: StoreField: r20->field_6f = r0
    //     0xbf4ee0: stur            w0, [x20, #0x6f]
    //     0xbf4ee4: ldurb           w16, [x20, #-1]
    //     0xbf4ee8: ldurb           w17, [x0, #-1]
    //     0xbf4eec: and             x16, x17, x16, lsr #2
    //     0xbf4ef0: tst             x16, HEAP, lsr #32
    //     0xbf4ef4: b.eq            #0xbf4efc
    //     0xbf4ef8: bl              #0x13de174  ; WriteBarrierWrappersStub
    // 0xbf4efc: r23 = true
    //     0xbf4efc: add             x23, NULL, #0x20  ; true
    // 0xbf4f00: StoreField: r20->field_1f = r23
    //     0xbf4f00: stur            w23, [x20, #0x1f]
    // 0xbf4f04: ldur            x0, [fp, #-8]
    // 0xbf4f08: LoadField: d0 = r0->field_57
    //     0xbf4f08: ldur            d0, [x0, #0x57]
    // 0xbf4f0c: LoadField: r1 = r0->field_5f
    //     0xbf4f0c: ldur            x1, [x0, #0x5f]
    // 0xbf4f10: scvtf           d1, x1
    // 0xbf4f14: d2 = 1.000000
    //     0xbf4f14: fmov            d2, #1.00000000
    // 0xbf4f18: fdiv            d3, d2, d1
    // 0xbf4f1c: fsub            d1, d0, d3
    // 0xbf4f20: d0 = 0.000000
    //     0xbf4f20: eor             v0.16b, v0.16b, v0.16b
    // 0xbf4f24: fcmp            d0, d1
    // 0xbf4f28: b.le            #0xbf4f34
    // 0xbf4f2c: d1 = 0.000000
    //     0xbf4f2c: eor             v1.16b, v1.16b, v1.16b
    // 0xbf4f30: b               #0xbf4f50
    // 0xbf4f34: fcmp            d1, d2
    // 0xbf4f38: b.le            #0xbf4f44
    // 0xbf4f3c: d1 = 1.000000
    //     0xbf4f3c: fmov            d1, #1.00000000
    // 0xbf4f40: b               #0xbf4f50
    // 0xbf4f44: fcmp            d1, d1
    // 0xbf4f48: b.vc            #0xbf4f50
    // 0xbf4f4c: d1 = 1.000000
    //     0xbf4f4c: fmov            d1, #1.00000000
    // 0xbf4f50: d0 = 100.000000
    //     0xbf4f50: add             x17, PP, #0x13, lsl #12  ; [pp+0x130a8] IMM: double(100) from 0x4059000000000000
    //     0xbf4f54: ldr             d0, [x17, #0xa8]
    // 0xbf4f58: fmul            d2, d1, d0
    // 0xbf4f5c: mov             v0.16b, v2.16b
    // 0xbf4f60: stp             fp, lr, [SP, #-0x10]!
    // 0xbf4f64: mov             fp, SP
    // 0xbf4f68: CallRuntime_LibcRound(double) -> double
    //     0xbf4f68: and             SP, SP, #0xfffffffffffffff0
    //     0xbf4f6c: mov             sp, SP
    //     0xbf4f70: ldr             x16, [THR, #0x770]  ; THR::LibcRound
    //     0xbf4f74: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xbf4f78: blr             x16
    //     0xbf4f7c: mov             x16, #8
    //     0xbf4f80: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xbf4f84: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xbf4f88: sub             sp, x16, #1, lsl #12
    //     0xbf4f8c: mov             SP, fp
    //     0xbf4f90: ldp             fp, lr, [SP], #0x10
    // 0xbf4f94: fcmp            d0, d0
    // 0xbf4f98: b.vs            #0xbf507c
    // 0xbf4f9c: fcvtzs          x0, d0
    // 0xbf4fa0: asr             x16, x0, #0x1e
    // 0xbf4fa4: cmp             x16, x0, asr #63
    // 0xbf4fa8: b.ne            #0xbf507c
    // 0xbf4fac: lsl             x0, x0, #1
    // 0xbf4fb0: stur            x0, [fp, #-8]
    // 0xbf4fb4: r1 = Null
    //     0xbf4fb4: mov             x1, NULL
    // 0xbf4fb8: r2 = 4
    //     0xbf4fb8: mov             x2, #4
    // 0xbf4fbc: r0 = AllocateArray()
    //     0xbf4fbc: bl              #0x13df928  ; AllocateArrayStub
    // 0xbf4fc0: mov             x1, x0
    // 0xbf4fc4: ldur            x0, [fp, #-8]
    // 0xbf4fc8: StoreField: r1->field_f = r0
    //     0xbf4fc8: stur            w0, [x1, #0xf]
    // 0xbf4fcc: r16 = "%"
    //     0xbf4fcc: ldr             x16, [PP, #0x10c0]  ; [pp+0x10c0] "%"
    // 0xbf4fd0: StoreField: r1->field_13 = r16
    //     0xbf4fd0: stur            w16, [x1, #0x13]
    // 0xbf4fd4: str             x1, [SP]
    // 0xbf4fd8: r0 = _interpolate()
    //     0xbf4fd8: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xbf4fdc: stur            x0, [fp, #-8]
    // 0xbf4fe0: r0 = AttributedString()
    //     0xbf4fe0: bl              #0x837ffc  ; AllocateAttributedStringStub -> AttributedString (size=0x10)
    // 0xbf4fe4: ldur            x1, [fp, #-8]
    // 0xbf4fe8: StoreField: r0->field_7 = r1
    //     0xbf4fe8: stur            w1, [x0, #7]
    // 0xbf4fec: r1 = const []
    //     0xbf4fec: ldr             x1, [PP, #0x2708]  ; [pp+0x2708] List<StringAttribute>(0)
    // 0xbf4ff0: StoreField: r0->field_b = r1
    //     0xbf4ff0: stur            w1, [x0, #0xb]
    // 0xbf4ff4: ldur            x1, [fp, #-0x10]
    // 0xbf4ff8: StoreField: r1->field_73 = r0
    //     0xbf4ff8: stur            w0, [x1, #0x73]
    //     0xbf4ffc: ldurb           w16, [x1, #-1]
    //     0xbf5000: ldurb           w17, [x0, #-1]
    //     0xbf5004: and             x16, x17, x16, lsr #2
    //     0xbf5008: tst             x16, HEAP, lsr #32
    //     0xbf500c: b.eq            #0xbf5014
    //     0xbf5010: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbf5014: r2 = true
    //     0xbf5014: add             x2, NULL, #0x20  ; true
    // 0xbf5018: StoreField: r1->field_1f = r2
    //     0xbf5018: stur            w2, [x1, #0x1f]
    // 0xbf501c: r0 = Null
    //     0xbf501c: mov             x0, NULL
    // 0xbf5020: LeaveFrame
    //     0xbf5020: mov             SP, fp
    //     0xbf5024: ldp             fp, lr, [SP], #0x10
    // 0xbf5028: ret
    //     0xbf5028: ret             
    // 0xbf502c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf502c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf5030: b               #0xbf4c34
    // 0xbf5034: SaveReg d0
    //     0xbf5034: str             q0, [SP, #-0x10]!
    // 0xbf5038: SaveReg r19
    //     0xbf5038: str             x19, [SP, #-8]!
    // 0xbf503c: r0 = 76
    //     0xbf503c: mov             x0, #0x4c
    // 0xbf5040: r30 = DoubleToIntegerStub
    //     0xbf5040: ldr             lr, [PP, #0x1b70]  ; [pp+0x1b70] Stub: DoubleToInteger (0x7d18e4)
    // 0xbf5044: LoadField: r30 = r30->field_7
    //     0xbf5044: ldur            lr, [lr, #7]
    // 0xbf5048: blr             lr
    // 0xbf504c: RestoreReg r19
    //     0xbf504c: ldr             x19, [SP], #8
    // 0xbf5050: RestoreReg d0
    //     0xbf5050: ldr             q0, [SP], #0x10
    // 0xbf5054: b               #0xbf4d54
    // 0xbf5058: SaveReg d0
    //     0xbf5058: str             q0, [SP, #-0x10]!
    // 0xbf505c: stp             x19, x20, [SP, #-0x10]!
    // 0xbf5060: r0 = 76
    //     0xbf5060: mov             x0, #0x4c
    // 0xbf5064: r30 = DoubleToIntegerStub
    //     0xbf5064: ldr             lr, [PP, #0x1b70]  ; [pp+0x1b70] Stub: DoubleToInteger (0x7d18e4)
    // 0xbf5068: LoadField: r30 = r30->field_7
    //     0xbf5068: ldur            lr, [lr, #7]
    // 0xbf506c: blr             lr
    // 0xbf5070: ldp             x19, x20, [SP], #0x10
    // 0xbf5074: RestoreReg d0
    //     0xbf5074: ldr             q0, [SP], #0x10
    // 0xbf5078: b               #0xbf4e90
    // 0xbf507c: SaveReg d0
    //     0xbf507c: str             q0, [SP, #-0x10]!
    // 0xbf5080: stp             x20, x23, [SP, #-0x10]!
    // 0xbf5084: SaveReg r19
    //     0xbf5084: str             x19, [SP, #-8]!
    // 0xbf5088: r0 = 76
    //     0xbf5088: mov             x0, #0x4c
    // 0xbf508c: r30 = DoubleToIntegerStub
    //     0xbf508c: ldr             lr, [PP, #0x1b70]  ; [pp+0x1b70] Stub: DoubleToInteger (0x7d18e4)
    // 0xbf5090: LoadField: r30 = r30->field_7
    //     0xbf5090: ldur            lr, [lr, #7]
    // 0xbf5094: blr             lr
    // 0xbf5098: RestoreReg r19
    //     0xbf5098: ldr             x19, [SP], #8
    // 0xbf509c: ldp             x20, x23, [SP], #0x10
    // 0xbf50a0: RestoreReg d0
    //     0xbf50a0: ldr             q0, [SP], #0x10
    // 0xbf50a4: b               #0xbf4fb0
  }
  double _semanticActionUnit(_RenderCupertinoSlider) {
    // ** addr: 0xbf525c, size: 0x14
    // 0xbf525c: d1 = 1.000000
    //     0xbf525c: fmov            d1, #1.00000000
    // 0xbf5260: LoadField: r0 = r1->field_5f
    //     0xbf5260: ldur            x0, [x1, #0x5f]
    // 0xbf5264: scvtf           d2, x0
    // 0xbf5268: fdiv            d0, d1, d2
    // 0xbf526c: ret
    //     0xbf526c: ret             
  }
  [closure] void _decreaseAction(dynamic) {
    // ** addr: 0xbf5270, size: 0x38
    // 0xbf5270: EnterFrame
    //     0xbf5270: stp             fp, lr, [SP, #-0x10]!
    //     0xbf5274: mov             fp, SP
    // 0xbf5278: ldr             x0, [fp, #0x10]
    // 0xbf527c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbf527c: ldur            w1, [x0, #0x17]
    // 0xbf5280: DecompressPointer r1
    //     0xbf5280: add             x1, x1, HEAP, lsl #32
    // 0xbf5284: CheckStackOverflow
    //     0xbf5284: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf5288: cmp             SP, x16
    //     0xbf528c: b.ls            #0xbf52a0
    // 0xbf5290: r0 = _decreaseAction()
    //     0xbf5290: bl              #0xbf52a8  ; [package:flutter/src/cupertino/slider.dart] _RenderCupertinoSlider::_decreaseAction
    // 0xbf5294: LeaveFrame
    //     0xbf5294: mov             SP, fp
    //     0xbf5298: ldp             fp, lr, [SP], #0x10
    // 0xbf529c: ret
    //     0xbf529c: ret             
    // 0xbf52a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf52a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf52a4: b               #0xbf5290
  }
  _ _decreaseAction(/* No info */) {
    // ** addr: 0xbf52a8, size: 0xdc
    // 0xbf52a8: EnterFrame
    //     0xbf52a8: stp             fp, lr, [SP, #-0x10]!
    //     0xbf52ac: mov             fp, SP
    // 0xbf52b0: d1 = 1.000000
    //     0xbf52b0: fmov            d1, #1.00000000
    // 0xbf52b4: d0 = 0.000000
    //     0xbf52b4: eor             v0.16b, v0.16b, v0.16b
    // 0xbf52b8: CheckStackOverflow
    //     0xbf52b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf52bc: cmp             SP, x16
    //     0xbf52c0: b.ls            #0xbf5360
    // 0xbf52c4: LoadField: r0 = r1->field_73
    //     0xbf52c4: ldur            w0, [x1, #0x73]
    // 0xbf52c8: DecompressPointer r0
    //     0xbf52c8: add             x0, x0, HEAP, lsl #32
    // 0xbf52cc: LoadField: d2 = r1->field_57
    //     0xbf52cc: ldur            d2, [x1, #0x57]
    // 0xbf52d0: LoadField: r2 = r1->field_5f
    //     0xbf52d0: ldur            x2, [x1, #0x5f]
    // 0xbf52d4: scvtf           d3, x2
    // 0xbf52d8: fdiv            d4, d1, d3
    // 0xbf52dc: fsub            d3, d2, d4
    // 0xbf52e0: fcmp            d0, d3
    // 0xbf52e4: b.le            #0xbf52f0
    // 0xbf52e8: d0 = 0.000000
    //     0xbf52e8: eor             v0.16b, v0.16b, v0.16b
    // 0xbf52ec: b               #0xbf5314
    // 0xbf52f0: fcmp            d3, d1
    // 0xbf52f4: b.le            #0xbf5300
    // 0xbf52f8: d0 = 1.000000
    //     0xbf52f8: fmov            d0, #1.00000000
    // 0xbf52fc: b               #0xbf5314
    // 0xbf5300: fcmp            d3, d3
    // 0xbf5304: b.vc            #0xbf5310
    // 0xbf5308: d0 = 1.000000
    //     0xbf5308: fmov            d0, #1.00000000
    // 0xbf530c: b               #0xbf5314
    // 0xbf5310: mov             v0.16b, v3.16b
    // 0xbf5314: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbf5314: ldur            w1, [x0, #0x17]
    // 0xbf5318: DecompressPointer r1
    //     0xbf5318: add             x1, x1, HEAP, lsl #32
    // 0xbf531c: r2 = inline_Allocate_Double()
    //     0xbf531c: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0xbf5320: add             x2, x2, #0x10
    //     0xbf5324: cmp             x0, x2
    //     0xbf5328: b.ls            #0xbf5368
    //     0xbf532c: str             x2, [THR, #0x60]  ; THR::top
    //     0xbf5330: sub             x2, x2, #0xf
    //     0xbf5334: mov             x0, #0xe19c
    //     0xbf5338: movk            x0, #3, lsl #16
    //     0xbf533c: stur            x0, [x2, #-1]
    // 0xbf5340: dmb             ishst
    // 0xbf5344: StoreField: r2->field_7 = d0
    //     0xbf5344: stur            d0, [x2, #7]
    // 0xbf5348: r3 = false
    //     0xbf5348: add             x3, NULL, #0x30  ; false
    // 0xbf534c: r0 = _handleChanged()
    //     0xbf534c: bl              #0xbf53c4  ; [package:flutter/src/cupertino/slider.dart] _CupertinoSliderState::_handleChanged
    // 0xbf5350: r0 = Null
    //     0xbf5350: mov             x0, NULL
    // 0xbf5354: LeaveFrame
    //     0xbf5354: mov             SP, fp
    //     0xbf5358: ldp             fp, lr, [SP], #0x10
    // 0xbf535c: ret
    //     0xbf535c: ret             
    // 0xbf5360: r0 = StackOverflowSharedWithFPURegs()
    //     0xbf5360: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xbf5364: b               #0xbf52c4
    // 0xbf5368: SaveReg d0
    //     0xbf5368: str             q0, [SP, #-0x10]!
    // 0xbf536c: SaveReg r1
    //     0xbf536c: str             x1, [SP, #-8]!
    // 0xbf5370: r0 = AllocateDouble()
    //     0xbf5370: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbf5374: mov             x2, x0
    // 0xbf5378: RestoreReg r1
    //     0xbf5378: ldr             x1, [SP], #8
    // 0xbf537c: RestoreReg d0
    //     0xbf537c: ldr             q0, [SP], #0x10
    // 0xbf5380: b               #0xbf5344
  }
  [closure] void _increaseAction(dynamic) {
    // ** addr: 0xbf54bc, size: 0x38
    // 0xbf54bc: EnterFrame
    //     0xbf54bc: stp             fp, lr, [SP, #-0x10]!
    //     0xbf54c0: mov             fp, SP
    // 0xbf54c4: ldr             x0, [fp, #0x10]
    // 0xbf54c8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbf54c8: ldur            w1, [x0, #0x17]
    // 0xbf54cc: DecompressPointer r1
    //     0xbf54cc: add             x1, x1, HEAP, lsl #32
    // 0xbf54d0: CheckStackOverflow
    //     0xbf54d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf54d4: cmp             SP, x16
    //     0xbf54d8: b.ls            #0xbf54ec
    // 0xbf54dc: r0 = _increaseAction()
    //     0xbf54dc: bl              #0xbf54f4  ; [package:flutter/src/cupertino/slider.dart] _RenderCupertinoSlider::_increaseAction
    // 0xbf54e0: LeaveFrame
    //     0xbf54e0: mov             SP, fp
    //     0xbf54e4: ldp             fp, lr, [SP], #0x10
    // 0xbf54e8: ret
    //     0xbf54e8: ret             
    // 0xbf54ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf54ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf54f0: b               #0xbf54dc
  }
  _ _increaseAction(/* No info */) {
    // ** addr: 0xbf54f4, size: 0xdc
    // 0xbf54f4: EnterFrame
    //     0xbf54f4: stp             fp, lr, [SP, #-0x10]!
    //     0xbf54f8: mov             fp, SP
    // 0xbf54fc: d1 = 1.000000
    //     0xbf54fc: fmov            d1, #1.00000000
    // 0xbf5500: d0 = 0.000000
    //     0xbf5500: eor             v0.16b, v0.16b, v0.16b
    // 0xbf5504: CheckStackOverflow
    //     0xbf5504: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf5508: cmp             SP, x16
    //     0xbf550c: b.ls            #0xbf55ac
    // 0xbf5510: LoadField: r0 = r1->field_73
    //     0xbf5510: ldur            w0, [x1, #0x73]
    // 0xbf5514: DecompressPointer r0
    //     0xbf5514: add             x0, x0, HEAP, lsl #32
    // 0xbf5518: LoadField: d2 = r1->field_57
    //     0xbf5518: ldur            d2, [x1, #0x57]
    // 0xbf551c: LoadField: r2 = r1->field_5f
    //     0xbf551c: ldur            x2, [x1, #0x5f]
    // 0xbf5520: scvtf           d3, x2
    // 0xbf5524: fdiv            d4, d1, d3
    // 0xbf5528: fadd            d3, d2, d4
    // 0xbf552c: fcmp            d0, d3
    // 0xbf5530: b.le            #0xbf553c
    // 0xbf5534: d0 = 0.000000
    //     0xbf5534: eor             v0.16b, v0.16b, v0.16b
    // 0xbf5538: b               #0xbf5560
    // 0xbf553c: fcmp            d3, d1
    // 0xbf5540: b.le            #0xbf554c
    // 0xbf5544: d0 = 1.000000
    //     0xbf5544: fmov            d0, #1.00000000
    // 0xbf5548: b               #0xbf5560
    // 0xbf554c: fcmp            d3, d3
    // 0xbf5550: b.vc            #0xbf555c
    // 0xbf5554: d0 = 1.000000
    //     0xbf5554: fmov            d0, #1.00000000
    // 0xbf5558: b               #0xbf5560
    // 0xbf555c: mov             v0.16b, v3.16b
    // 0xbf5560: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbf5560: ldur            w1, [x0, #0x17]
    // 0xbf5564: DecompressPointer r1
    //     0xbf5564: add             x1, x1, HEAP, lsl #32
    // 0xbf5568: r2 = inline_Allocate_Double()
    //     0xbf5568: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0xbf556c: add             x2, x2, #0x10
    //     0xbf5570: cmp             x0, x2
    //     0xbf5574: b.ls            #0xbf55b4
    //     0xbf5578: str             x2, [THR, #0x60]  ; THR::top
    //     0xbf557c: sub             x2, x2, #0xf
    //     0xbf5580: mov             x0, #0xe19c
    //     0xbf5584: movk            x0, #3, lsl #16
    //     0xbf5588: stur            x0, [x2, #-1]
    // 0xbf558c: dmb             ishst
    // 0xbf5590: StoreField: r2->field_7 = d0
    //     0xbf5590: stur            d0, [x2, #7]
    // 0xbf5594: r3 = false
    //     0xbf5594: add             x3, NULL, #0x30  ; false
    // 0xbf5598: r0 = _handleChanged()
    //     0xbf5598: bl              #0xbf53c4  ; [package:flutter/src/cupertino/slider.dart] _CupertinoSliderState::_handleChanged
    // 0xbf559c: r0 = Null
    //     0xbf559c: mov             x0, NULL
    // 0xbf55a0: LeaveFrame
    //     0xbf55a0: mov             SP, fp
    //     0xbf55a4: ldp             fp, lr, [SP], #0x10
    // 0xbf55a8: ret
    //     0xbf55a8: ret             
    // 0xbf55ac: r0 = StackOverflowSharedWithFPURegs()
    //     0xbf55ac: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xbf55b0: b               #0xbf5510
    // 0xbf55b4: SaveReg d0
    //     0xbf55b4: str             q0, [SP, #-0x10]!
    // 0xbf55b8: SaveReg r1
    //     0xbf55b8: str             x1, [SP, #-8]!
    // 0xbf55bc: r0 = AllocateDouble()
    //     0xbf55bc: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbf55c0: mov             x2, x0
    // 0xbf55c4: RestoreReg r1
    //     0xbf55c4: ldr             x1, [SP], #8
    // 0xbf55c8: RestoreReg d0
    //     0xbf55c8: ldr             q0, [SP], #0x10
    // 0xbf55cc: b               #0xbf5590
  }
  _ dispose(/* No info */) {
    // ** addr: 0xc027d0, size: 0x8c
    // 0xc027d0: EnterFrame
    //     0xc027d0: stp             fp, lr, [SP, #-0x10]!
    //     0xc027d4: mov             fp, SP
    // 0xc027d8: AllocStack(0x8)
    //     0xc027d8: sub             SP, SP, #8
    // 0xc027dc: SetupParameters(_RenderCupertinoSlider this /* r1 => r0, fp-0x8 */)
    //     0xc027dc: mov             x0, x1
    //     0xc027e0: stur            x1, [fp, #-8]
    // 0xc027e4: CheckStackOverflow
    //     0xc027e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc027e8: cmp             SP, x16
    //     0xc027ec: b.ls            #0xc0283c
    // 0xc027f0: LoadField: r1 = r0->field_87
    //     0xc027f0: ldur            w1, [x0, #0x87]
    // 0xc027f4: DecompressPointer r1
    //     0xc027f4: add             x1, x1, HEAP, lsl #32
    // 0xc027f8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc027fc: cmp             w1, w16
    // 0xc02800: b.eq            #0xc02844
    // 0xc02804: r0 = dispose()
    //     0xc02804: bl              #0xbb16bc  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::dispose
    // 0xc02808: ldur            x0, [fp, #-8]
    // 0xc0280c: LoadField: r1 = r0->field_83
    //     0xc0280c: ldur            w1, [x0, #0x83]
    // 0xc02810: DecompressPointer r1
    //     0xc02810: add             x1, x1, HEAP, lsl #32
    // 0xc02814: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc02818: cmp             w1, w16
    // 0xc0281c: b.eq            #0xc02850
    // 0xc02820: r0 = dispose()
    //     0xc02820: bl              #0x9164f4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0xc02824: ldur            x1, [fp, #-8]
    // 0xc02828: r0 = dispose()
    //     0xc02828: bl              #0xc04c8c  ; [package:flutter/src/rendering/object.dart] RenderObject::dispose
    // 0xc0282c: r0 = Null
    //     0xc0282c: mov             x0, NULL
    // 0xc02830: LeaveFrame
    //     0xc02830: mov             SP, fp
    //     0xc02834: ldp             fp, lr, [SP], #0x10
    // 0xc02838: ret
    //     0xc02838: ret             
    // 0xc0283c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc0283c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc02840: b               #0xc027f0
    // 0xc02844: r9 = _drag
    //     0xc02844: add             x9, PP, #0xd0, lsl #12  ; [pp+0xd00e0] Field <_RenderCupertinoSlider@296348729._drag@296348729>: late (offset: 0x88)
    //     0xc02848: ldr             x9, [x9, #0xe0]
    // 0xc0284c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc0284c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xc02850: r9 = _position
    //     0xc02850: add             x9, PP, #0xcc, lsl #12  ; [pp+0xcc868] Field <_RenderCupertinoSlider@296348729._position@296348729>: late (offset: 0x84)
    //     0xc02854: ldr             x9, [x9, #0x868]
    // 0xc02858: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc02858: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ paint(/* No info */) {
    // ** addr: 0xc17060, size: 0x404
    // 0xc17060: EnterFrame
    //     0xc17060: stp             fp, lr, [SP, #-0x10]!
    //     0xc17064: mov             fp, SP
    // 0xc17068: AllocStack(0x78)
    //     0xc17068: sub             SP, SP, #0x78
    // 0xc1706c: SetupParameters(_RenderCupertinoSlider this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */, dynamic _ /* r3 => r0, fp-0x18 */)
    //     0xc1706c: mov             x5, x1
    //     0xc17070: stur            x1, [fp, #-8]
    //     0xc17074: mov             x1, x2
    //     0xc17078: mov             x0, x3
    //     0xc1707c: stur            x2, [fp, #-0x10]
    //     0xc17080: stur            x3, [fp, #-0x18]
    // 0xc17084: CheckStackOverflow
    //     0xc17084: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc17088: cmp             SP, x16
    //     0xc1708c: b.ls            #0xc17408
    // 0xc17090: LoadField: r2 = r5->field_7f
    //     0xc17090: ldur            w2, [x5, #0x7f]
    // 0xc17094: DecompressPointer r2
    //     0xc17094: add             x2, x2, HEAP, lsl #32
    // 0xc17098: LoadField: r3 = r2->field_7
    //     0xc17098: ldur            x3, [x2, #7]
    // 0xc1709c: cmp             x3, #0
    // 0xc170a0: b.gt            #0xc17120
    // 0xc170a4: d0 = 1.000000
    //     0xc170a4: fmov            d0, #1.00000000
    // 0xc170a8: LoadField: r2 = r5->field_83
    //     0xc170a8: ldur            w2, [x5, #0x83]
    // 0xc170ac: DecompressPointer r2
    //     0xc170ac: add             x2, x2, HEAP, lsl #32
    // 0xc170b0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc170b4: cmp             w2, w16
    // 0xc170b8: b.eq            #0xc17410
    // 0xc170bc: LoadField: r3 = r2->field_37
    //     0xc170bc: ldur            w3, [x2, #0x37]
    // 0xc170c0: DecompressPointer r3
    //     0xc170c0: add             x3, x3, HEAP, lsl #32
    // 0xc170c4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc170c8: cmp             w3, w16
    // 0xc170cc: b.eq            #0xc1741c
    // 0xc170d0: LoadField: d1 = r3->field_7
    //     0xc170d0: ldur            d1, [x3, #7]
    // 0xc170d4: fsub            d2, d0, d1
    // 0xc170d8: LoadField: r3 = r5->field_67
    //     0xc170d8: ldur            w3, [x5, #0x67]
    // 0xc170dc: DecompressPointer r3
    //     0xc170dc: add             x3, x3, HEAP, lsl #32
    // 0xc170e0: LoadField: r4 = r5->field_6f
    //     0xc170e0: ldur            w4, [x5, #0x6f]
    // 0xc170e4: DecompressPointer r4
    //     0xc170e4: add             x4, x4, HEAP, lsl #32
    // 0xc170e8: r2 = inline_Allocate_Double()
    //     0xc170e8: ldp             x2, x6, [THR, #0x60]  ; THR::top
    //     0xc170ec: add             x2, x2, #0x10
    //     0xc170f0: cmp             x6, x2
    //     0xc170f4: b.ls            #0xc17424
    //     0xc170f8: str             x2, [THR, #0x60]  ; THR::top
    //     0xc170fc: sub             x2, x2, #0xf
    //     0xc17100: mov             x6, #0xe19c
    //     0xc17104: movk            x6, #3, lsl #16
    //     0xc17108: stur            x6, [x2, #-1]
    // 0xc1710c: dmb             ishst
    // 0xc17110: StoreField: r2->field_7 = d2
    //     0xc17110: stur            d2, [x2, #7]
    // 0xc17114: r0 = AllocateRecord3()
    //     0xc17114: bl              #0x13de3f4  ; AllocateRecord3Stub
    // 0xc17118: mov             x1, x0
    // 0xc1711c: b               #0xc17164
    // 0xc17120: mov             x1, x5
    // 0xc17124: LoadField: r0 = r1->field_83
    //     0xc17124: ldur            w0, [x1, #0x83]
    // 0xc17128: DecompressPointer r0
    //     0xc17128: add             x0, x0, HEAP, lsl #32
    // 0xc1712c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc17130: cmp             w0, w16
    // 0xc17134: b.eq            #0xc17450
    // 0xc17138: LoadField: r2 = r0->field_37
    //     0xc17138: ldur            w2, [x0, #0x37]
    // 0xc1713c: DecompressPointer r2
    //     0xc1713c: add             x2, x2, HEAP, lsl #32
    // 0xc17140: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc17144: cmp             w2, w16
    // 0xc17148: b.eq            #0xc1745c
    // 0xc1714c: LoadField: r3 = r1->field_6f
    //     0xc1714c: ldur            w3, [x1, #0x6f]
    // 0xc17150: DecompressPointer r3
    //     0xc17150: add             x3, x3, HEAP, lsl #32
    // 0xc17154: LoadField: r4 = r1->field_67
    //     0xc17154: ldur            w4, [x1, #0x67]
    // 0xc17158: DecompressPointer r4
    //     0xc17158: add             x4, x4, HEAP, lsl #32
    // 0xc1715c: r0 = AllocateRecord3()
    //     0xc1715c: bl              #0x13de3f4  ; AllocateRecord3Stub
    // 0xc17160: mov             x1, x0
    // 0xc17164: ldur            x0, [fp, #-0x18]
    // 0xc17168: LoadField: r2 = r1->field_f
    //     0xc17168: ldur            w2, [x1, #0xf]
    // 0xc1716c: DecompressPointer r2
    //     0xc1716c: add             x2, x2, HEAP, lsl #32
    // 0xc17170: stur            x2, [fp, #-0x30]
    // 0xc17174: LoadField: r3 = r1->field_13
    //     0xc17174: ldur            w3, [x1, #0x13]
    // 0xc17178: DecompressPointer r3
    //     0xc17178: add             x3, x3, HEAP, lsl #32
    // 0xc1717c: stur            x3, [fp, #-0x28]
    // 0xc17180: ArrayLoad: r4 = r1[0]  ; List_4
    //     0xc17180: ldur            w4, [x1, #0x17]
    // 0xc17184: DecompressPointer r4
    //     0xc17184: add             x4, x4, HEAP, lsl #32
    // 0xc17188: stur            x4, [fp, #-0x20]
    // 0xc1718c: LoadField: d0 = r0->field_f
    //     0xc1718c: ldur            d0, [x0, #0xf]
    // 0xc17190: ldur            x1, [fp, #-8]
    // 0xc17194: stur            d0, [fp, #-0x38]
    // 0xc17198: r0 = size()
    //     0xc17198: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc1719c: LoadField: d0 = r0->field_f
    //     0xc1719c: ldur            d0, [x0, #0xf]
    // 0xc171a0: d1 = 2.000000
    //     0xc171a0: fmov            d1, #2.00000000
    // 0xc171a4: fdiv            d2, d0, d1
    // 0xc171a8: ldur            d0, [fp, #-0x38]
    // 0xc171ac: fadd            d1, d0, d2
    // 0xc171b0: ldur            x0, [fp, #-0x18]
    // 0xc171b4: stur            d1, [fp, #-0x58]
    // 0xc171b8: LoadField: d0 = r0->field_7
    //     0xc171b8: ldur            d0, [x0, #7]
    // 0xc171bc: stur            d0, [fp, #-0x50]
    // 0xc171c0: d2 = 8.000000
    //     0xc171c0: fmov            d2, #8.00000000
    // 0xc171c4: fadd            d3, d0, d2
    // 0xc171c8: stur            d3, [fp, #-0x48]
    // 0xc171cc: d2 = 1.000000
    //     0xc171cc: fmov            d2, #1.00000000
    // 0xc171d0: fsub            d4, d1, d2
    // 0xc171d4: stur            d4, [fp, #-0x40]
    // 0xc171d8: fadd            d5, d1, d2
    // 0xc171dc: ldur            x1, [fp, #-8]
    // 0xc171e0: stur            d5, [fp, #-0x38]
    // 0xc171e4: r0 = _trackRight()
    //     0xc171e4: bl              #0xb5d16c  ; [package:flutter/src/cupertino/slider.dart] _RenderCupertinoSlider::_trackRight
    // 0xc171e8: mov             v1.16b, v0.16b
    // 0xc171ec: ldur            d0, [fp, #-0x50]
    // 0xc171f0: fadd            d2, d0, d1
    // 0xc171f4: ldur            x1, [fp, #-8]
    // 0xc171f8: stur            d2, [fp, #-0x60]
    // 0xc171fc: r0 = _thumbCenter()
    //     0xc171fc: bl              #0xb5d05c  ; [package:flutter/src/cupertino/slider.dart] _RenderCupertinoSlider::_thumbCenter
    // 0xc17200: mov             v1.16b, v0.16b
    // 0xc17204: ldur            d0, [fp, #-0x50]
    // 0xc17208: fadd            d2, d0, d1
    // 0xc1720c: ldur            x1, [fp, #-0x10]
    // 0xc17210: stur            d2, [fp, #-0x68]
    // 0xc17214: r0 = canvas()
    //     0xc17214: bl              #0xc17694  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0xc17218: mov             x1, x0
    // 0xc1721c: ldur            x0, [fp, #-0x30]
    // 0xc17220: stur            x1, [fp, #-8]
    // 0xc17224: LoadField: d0 = r0->field_7
    //     0xc17224: ldur            d0, [x0, #7]
    // 0xc17228: stur            d0, [fp, #-0x50]
    // 0xc1722c: d1 = 0.000000
    //     0xc1722c: eor             v1.16b, v1.16b, v1.16b
    // 0xc17230: fcmp            d0, d1
    // 0xc17234: b.le            #0xc172d8
    // 0xc17238: ldur            d2, [fp, #-0x48]
    // 0xc1723c: ldur            d3, [fp, #-0x40]
    // 0xc17240: ldur            d4, [fp, #-0x38]
    // 0xc17244: ldur            d1, [fp, #-0x68]
    // 0xc17248: r16 = 136
    //     0xc17248: mov             x16, #0x88
    // 0xc1724c: stp             x16, NULL, [SP]
    // 0xc17250: r0 = ByteData()
    //     0xc17250: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xc17254: stur            x0, [fp, #-0x10]
    // 0xc17258: r0 = Paint()
    //     0xc17258: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xc1725c: mov             x3, x0
    // 0xc17260: ldur            x0, [fp, #-0x10]
    // 0xc17264: stur            x3, [fp, #-0x18]
    // 0xc17268: StoreField: r3->field_7 = r0
    //     0xc17268: stur            w0, [x3, #7]
    // 0xc1726c: mov             x1, x3
    // 0xc17270: ldur            x2, [fp, #-0x20]
    // 0xc17274: r0 = color=()
    //     0xc17274: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xc17278: r1 = <RRect>
    //     0xc17278: add             x1, PP, #0x85, lsl #12  ; [pp+0x85108] TypeArguments: <RRect>
    //     0xc1727c: ldr             x1, [x1, #0x108]
    // 0xc17280: r0 = RRect()
    //     0xc17280: bl              #0xb6e214  ; AllocateRRectStub -> RRect (size=0x6c)
    // 0xc17284: ldur            d0, [fp, #-0x48]
    // 0xc17288: StoreField: r0->field_b = d0
    //     0xc17288: stur            d0, [x0, #0xb]
    // 0xc1728c: ldur            d0, [fp, #-0x40]
    // 0xc17290: StoreField: r0->field_13 = d0
    //     0xc17290: stur            d0, [x0, #0x13]
    // 0xc17294: ldur            d1, [fp, #-0x68]
    // 0xc17298: StoreField: r0->field_1b = d1
    //     0xc17298: stur            d1, [x0, #0x1b]
    // 0xc1729c: ldur            d2, [fp, #-0x38]
    // 0xc172a0: StoreField: r0->field_23 = d2
    //     0xc172a0: stur            d2, [x0, #0x23]
    // 0xc172a4: d3 = 1.000000
    //     0xc172a4: fmov            d3, #1.00000000
    // 0xc172a8: StoreField: r0->field_2b = d3
    //     0xc172a8: stur            d3, [x0, #0x2b]
    // 0xc172ac: StoreField: r0->field_33 = d3
    //     0xc172ac: stur            d3, [x0, #0x33]
    // 0xc172b0: StoreField: r0->field_3b = d3
    //     0xc172b0: stur            d3, [x0, #0x3b]
    // 0xc172b4: StoreField: r0->field_43 = d3
    //     0xc172b4: stur            d3, [x0, #0x43]
    // 0xc172b8: StoreField: r0->field_4b = d3
    //     0xc172b8: stur            d3, [x0, #0x4b]
    // 0xc172bc: StoreField: r0->field_53 = d3
    //     0xc172bc: stur            d3, [x0, #0x53]
    // 0xc172c0: StoreField: r0->field_5b = d3
    //     0xc172c0: stur            d3, [x0, #0x5b]
    // 0xc172c4: StoreField: r0->field_63 = d3
    //     0xc172c4: stur            d3, [x0, #0x63]
    // 0xc172c8: ldur            x1, [fp, #-8]
    // 0xc172cc: mov             x2, x0
    // 0xc172d0: ldur            x3, [fp, #-0x18]
    // 0xc172d4: r0 = drawRRect()
    //     0xc172d4: bl              #0xb6dce0  ; [dart:ui] _NativeCanvas::drawRRect
    // 0xc172d8: ldur            d1, [fp, #-0x50]
    // 0xc172dc: d0 = 1.000000
    //     0xc172dc: fmov            d0, #1.00000000
    // 0xc172e0: fcmp            d0, d1
    // 0xc172e4: b.le            #0xc17388
    // 0xc172e8: ldur            d1, [fp, #-0x40]
    // 0xc172ec: ldur            d3, [fp, #-0x38]
    // 0xc172f0: ldur            d4, [fp, #-0x60]
    // 0xc172f4: ldur            d2, [fp, #-0x68]
    // 0xc172f8: r16 = 136
    //     0xc172f8: mov             x16, #0x88
    // 0xc172fc: stp             x16, NULL, [SP]
    // 0xc17300: r0 = ByteData()
    //     0xc17300: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xc17304: stur            x0, [fp, #-0x10]
    // 0xc17308: r0 = Paint()
    //     0xc17308: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xc1730c: mov             x3, x0
    // 0xc17310: ldur            x0, [fp, #-0x10]
    // 0xc17314: stur            x3, [fp, #-0x18]
    // 0xc17318: StoreField: r3->field_7 = r0
    //     0xc17318: stur            w0, [x3, #7]
    // 0xc1731c: mov             x1, x3
    // 0xc17320: ldur            x2, [fp, #-0x28]
    // 0xc17324: r0 = color=()
    //     0xc17324: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xc17328: r1 = <RRect>
    //     0xc17328: add             x1, PP, #0x85, lsl #12  ; [pp+0x85108] TypeArguments: <RRect>
    //     0xc1732c: ldr             x1, [x1, #0x108]
    // 0xc17330: r0 = RRect()
    //     0xc17330: bl              #0xb6e214  ; AllocateRRectStub -> RRect (size=0x6c)
    // 0xc17334: ldur            d0, [fp, #-0x68]
    // 0xc17338: StoreField: r0->field_b = d0
    //     0xc17338: stur            d0, [x0, #0xb]
    // 0xc1733c: ldur            d1, [fp, #-0x40]
    // 0xc17340: StoreField: r0->field_13 = d1
    //     0xc17340: stur            d1, [x0, #0x13]
    // 0xc17344: ldur            d1, [fp, #-0x60]
    // 0xc17348: StoreField: r0->field_1b = d1
    //     0xc17348: stur            d1, [x0, #0x1b]
    // 0xc1734c: ldur            d1, [fp, #-0x38]
    // 0xc17350: StoreField: r0->field_23 = d1
    //     0xc17350: stur            d1, [x0, #0x23]
    // 0xc17354: d1 = 1.000000
    //     0xc17354: fmov            d1, #1.00000000
    // 0xc17358: StoreField: r0->field_2b = d1
    //     0xc17358: stur            d1, [x0, #0x2b]
    // 0xc1735c: StoreField: r0->field_33 = d1
    //     0xc1735c: stur            d1, [x0, #0x33]
    // 0xc17360: StoreField: r0->field_3b = d1
    //     0xc17360: stur            d1, [x0, #0x3b]
    // 0xc17364: StoreField: r0->field_43 = d1
    //     0xc17364: stur            d1, [x0, #0x43]
    // 0xc17368: StoreField: r0->field_4b = d1
    //     0xc17368: stur            d1, [x0, #0x4b]
    // 0xc1736c: StoreField: r0->field_53 = d1
    //     0xc1736c: stur            d1, [x0, #0x53]
    // 0xc17370: StoreField: r0->field_5b = d1
    //     0xc17370: stur            d1, [x0, #0x5b]
    // 0xc17374: StoreField: r0->field_63 = d1
    //     0xc17374: stur            d1, [x0, #0x63]
    // 0xc17378: ldur            x1, [fp, #-8]
    // 0xc1737c: mov             x2, x0
    // 0xc17380: ldur            x3, [fp, #-0x18]
    // 0xc17384: r0 = drawRRect()
    //     0xc17384: bl              #0xb6dce0  ; [dart:ui] _NativeCanvas::drawRRect
    // 0xc17388: ldur            d1, [fp, #-0x58]
    // 0xc1738c: ldur            d0, [fp, #-0x68]
    // 0xc17390: r0 = Offset()
    //     0xc17390: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xc17394: ldur            d0, [fp, #-0x68]
    // 0xc17398: stur            x0, [fp, #-0x10]
    // 0xc1739c: StoreField: r0->field_7 = d0
    //     0xc1739c: stur            d0, [x0, #7]
    // 0xc173a0: ldur            d0, [fp, #-0x58]
    // 0xc173a4: StoreField: r0->field_f = d0
    //     0xc173a4: stur            d0, [x0, #0xf]
    // 0xc173a8: r0 = CupertinoThumbPainter()
    //     0xc173a8: bl              #0xc17688  ; AllocateCupertinoThumbPainterStub -> CupertinoThumbPainter (size=0x10)
    // 0xc173ac: mov             x1, x0
    // 0xc173b0: r0 = Instance_Color
    //     0xc173b0: add             x0, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0xc173b4: ldr             x0, [x0, #0xc38]
    // 0xc173b8: stur            x1, [fp, #-0x18]
    // 0xc173bc: StoreField: r1->field_7 = r0
    //     0xc173bc: stur            w0, [x1, #7]
    // 0xc173c0: r0 = const [Instance of 'BoxShadow', Instance of 'BoxShadow', Instance of 'BoxShadow']
    //     0xc173c0: add             x0, PP, #0xd0, lsl #12  ; [pp+0xd00f8] List<BoxShadow>(3)
    //     0xc173c4: ldr             x0, [x0, #0xf8]
    // 0xc173c8: StoreField: r1->field_b = r0
    //     0xc173c8: stur            w0, [x1, #0xb]
    // 0xc173cc: r0 = Rect()
    //     0xc173cc: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0xc173d0: mov             x1, x0
    // 0xc173d4: ldur            x2, [fp, #-0x10]
    // 0xc173d8: d0 = 28.000000
    //     0xc173d8: fmov            d0, #28.00000000
    // 0xc173dc: d1 = 28.000000
    //     0xc173dc: fmov            d1, #28.00000000
    // 0xc173e0: stur            x0, [fp, #-0x10]
    // 0xc173e4: r0 = Rect.fromCenter()
    //     0xc173e4: bl              #0x86ddc8  ; [dart:ui] Rect::Rect.fromCenter
    // 0xc173e8: ldur            x1, [fp, #-0x18]
    // 0xc173ec: ldur            x2, [fp, #-8]
    // 0xc173f0: ldur            x3, [fp, #-0x10]
    // 0xc173f4: r0 = paint()
    //     0xc173f4: bl              #0xc17464  ; [package:flutter/src/cupertino/thumb_painter.dart] CupertinoThumbPainter::paint
    // 0xc173f8: r0 = Null
    //     0xc173f8: mov             x0, NULL
    // 0xc173fc: LeaveFrame
    //     0xc173fc: mov             SP, fp
    //     0xc17400: ldp             fp, lr, [SP], #0x10
    // 0xc17404: ret
    //     0xc17404: ret             
    // 0xc17408: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc17408: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1740c: b               #0xc17090
    // 0xc17410: r9 = _position
    //     0xc17410: add             x9, PP, #0xcc, lsl #12  ; [pp+0xcc868] Field <_RenderCupertinoSlider@296348729._position@296348729>: late (offset: 0x84)
    //     0xc17414: ldr             x9, [x9, #0x868]
    // 0xc17418: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xc17418: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xc1741c: r9 = _value
    //     0xc1741c: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0xc17420: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xc17420: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xc17424: stp             q0, q2, [SP, #-0x20]!
    // 0xc17428: stp             x4, x5, [SP, #-0x10]!
    // 0xc1742c: stp             x1, x3, [SP, #-0x10]!
    // 0xc17430: SaveReg r0
    //     0xc17430: str             x0, [SP, #-8]!
    // 0xc17434: r0 = AllocateDouble()
    //     0xc17434: bl              #0x13df878  ; AllocateDoubleStub
    // 0xc17438: mov             x2, x0
    // 0xc1743c: RestoreReg r0
    //     0xc1743c: ldr             x0, [SP], #8
    // 0xc17440: ldp             x1, x3, [SP], #0x10
    // 0xc17444: ldp             x4, x5, [SP], #0x10
    // 0xc17448: ldp             q0, q2, [SP], #0x20
    // 0xc1744c: b               #0xc17110
    // 0xc17450: r9 = _position
    //     0xc17450: add             x9, PP, #0xcc, lsl #12  ; [pp+0xcc868] Field <_RenderCupertinoSlider@296348729._position@296348729>: late (offset: 0x84)
    //     0xc17454: ldr             x9, [x9, #0x868]
    // 0xc17458: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc17458: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xc1745c: r9 = _value
    //     0xc1745c: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0xc17460: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc17460: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ handleEvent(/* No info */) {
    // ** addr: 0xcd0768, size: 0xec
    // 0xcd0768: EnterFrame
    //     0xcd0768: stp             fp, lr, [SP, #-0x10]!
    //     0xcd076c: mov             fp, SP
    // 0xcd0770: AllocStack(0x10)
    //     0xcd0770: sub             SP, SP, #0x10
    // 0xcd0774: SetupParameters(_RenderCupertinoSlider this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */, dynamic _ /* r3 => r0 */)
    //     0xcd0774: mov             x4, x1
    //     0xcd0778: mov             x0, x3
    //     0xcd077c: mov             x3, x2
    //     0xcd0780: stur            x1, [fp, #-8]
    //     0xcd0784: stur            x2, [fp, #-0x10]
    // 0xcd0788: CheckStackOverflow
    //     0xcd0788: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcd078c: cmp             SP, x16
    //     0xcd0790: b.ls            #0xcd0840
    // 0xcd0794: r2 = Null
    //     0xcd0794: mov             x2, NULL
    // 0xcd0798: r1 = Null
    //     0xcd0798: mov             x1, NULL
    // 0xcd079c: r4 = 60
    //     0xcd079c: mov             x4, #0x3c
    // 0xcd07a0: branchIfSmi(r0, 0xcd07ac)
    //     0xcd07a0: tbz             w0, #0, #0xcd07ac
    // 0xcd07a4: r4 = LoadClassIdInstr(r0)
    //     0xcd07a4: ldur            x4, [x0, #-1]
    //     0xcd07a8: ubfx            x4, x4, #0xc, #0x14
    // 0xcd07ac: cmp             x4, #0xc65
    // 0xcd07b0: b.eq            #0xcd07c8
    // 0xcd07b4: r8 = BoxHitTestEntry
    //     0xcd07b4: add             x8, PP, #0x15, lsl #12  ; [pp+0x155d0] Type: BoxHitTestEntry
    //     0xcd07b8: ldr             x8, [x8, #0x5d0]
    // 0xcd07bc: r3 = Null
    //     0xcd07bc: add             x3, PP, #0xd0, lsl #12  ; [pp+0xd0100] Null
    //     0xcd07c0: ldr             x3, [x3, #0x100]
    // 0xcd07c4: r0 = DefaultTypeTest()
    //     0xcd07c4: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcd07c8: ldur            x0, [fp, #-0x10]
    // 0xcd07cc: r2 = Null
    //     0xcd07cc: mov             x2, NULL
    // 0xcd07d0: r1 = Null
    //     0xcd07d0: mov             x1, NULL
    // 0xcd07d4: cmp             w0, NULL
    // 0xcd07d8: b.eq            #0xcd0800
    // 0xcd07dc: branchIfSmi(r0, 0xcd0800)
    //     0xcd07dc: tbz             w0, #0, #0xcd0800
    // 0xcd07e0: r3 = LoadClassIdInstr(r0)
    //     0xcd07e0: ldur            x3, [x0, #-1]
    //     0xcd07e4: ubfx            x3, x3, #0xc, #0x14
    // 0xcd07e8: r17 = 4159
    //     0xcd07e8: mov             x17, #0x103f
    // 0xcd07ec: cmp             x3, x17
    // 0xcd07f0: b.eq            #0xcd0808
    // 0xcd07f4: r17 = 5288
    //     0xcd07f4: mov             x17, #0x14a8
    // 0xcd07f8: cmp             x3, x17
    // 0xcd07fc: b.eq            #0xcd0808
    // 0xcd0800: r0 = false
    //     0xcd0800: add             x0, NULL, #0x30  ; false
    // 0xcd0804: b               #0xcd080c
    // 0xcd0808: r0 = true
    //     0xcd0808: add             x0, NULL, #0x20  ; true
    // 0xcd080c: tbnz            w0, #4, #0xcd0830
    // 0xcd0810: ldur            x0, [fp, #-8]
    // 0xcd0814: LoadField: r1 = r0->field_87
    //     0xcd0814: ldur            w1, [x0, #0x87]
    // 0xcd0818: DecompressPointer r1
    //     0xcd0818: add             x1, x1, HEAP, lsl #32
    // 0xcd081c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xcd0820: cmp             w1, w16
    // 0xcd0824: b.eq            #0xcd0848
    // 0xcd0828: ldur            x2, [fp, #-0x10]
    // 0xcd082c: r0 = addPointer()
    //     0xcd082c: bl              #0xd04e70  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::addPointer
    // 0xcd0830: r0 = Null
    //     0xcd0830: mov             x0, NULL
    // 0xcd0834: LeaveFrame
    //     0xcd0834: mov             SP, fp
    //     0xcd0838: ldp             fp, lr, [SP], #0x10
    // 0xcd083c: ret
    //     0xcd083c: ret             
    // 0xcd0840: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd0840: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd0844: b               #0xcd0794
    // 0xcd0848: r9 = _drag
    //     0xcd0848: add             x9, PP, #0xd0, lsl #12  ; [pp+0xd00e0] Field <_RenderCupertinoSlider@296348729._drag@296348729>: late (offset: 0x88)
    //     0xcd084c: ldr             x9, [x9, #0xe0]
    // 0xcd0850: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xcd0850: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  set _ textDirection=(/* No info */) {
    // ** addr: 0xce1554, size: 0x70
    // 0xce1554: EnterFrame
    //     0xce1554: stp             fp, lr, [SP, #-0x10]!
    //     0xce1558: mov             fp, SP
    // 0xce155c: mov             x0, x2
    // 0xce1560: CheckStackOverflow
    //     0xce1560: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce1564: cmp             SP, x16
    //     0xce1568: b.ls            #0xce15bc
    // 0xce156c: LoadField: r2 = r1->field_7f
    //     0xce156c: ldur            w2, [x1, #0x7f]
    // 0xce1570: DecompressPointer r2
    //     0xce1570: add             x2, x2, HEAP, lsl #32
    // 0xce1574: cmp             w2, w0
    // 0xce1578: b.ne            #0xce158c
    // 0xce157c: r0 = Null
    //     0xce157c: mov             x0, NULL
    // 0xce1580: LeaveFrame
    //     0xce1580: mov             SP, fp
    //     0xce1584: ldp             fp, lr, [SP], #0x10
    // 0xce1588: ret
    //     0xce1588: ret             
    // 0xce158c: StoreField: r1->field_7f = r0
    //     0xce158c: stur            w0, [x1, #0x7f]
    //     0xce1590: ldurb           w16, [x1, #-1]
    //     0xce1594: ldurb           w17, [x0, #-1]
    //     0xce1598: and             x16, x17, x16, lsr #2
    //     0xce159c: tst             x16, HEAP, lsr #32
    //     0xce15a0: b.eq            #0xce15a8
    //     0xce15a4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xce15a8: r0 = markNeedsPaint()
    //     0xce15a8: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xce15ac: r0 = Null
    //     0xce15ac: mov             x0, NULL
    // 0xce15b0: LeaveFrame
    //     0xce15b0: mov             SP, fp
    //     0xce15b4: ldp             fp, lr, [SP], #0x10
    // 0xce15b8: ret
    //     0xce15b8: ret             
    // 0xce15bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce15bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce15c0: b               #0xce156c
  }
  set _ onChanged=(/* No info */) {
    // ** addr: 0xce15c4, size: 0x84
    // 0xce15c4: EnterFrame
    //     0xce15c4: stp             fp, lr, [SP, #-0x10]!
    //     0xce15c8: mov             fp, SP
    // 0xce15cc: AllocStack(0x20)
    //     0xce15cc: sub             SP, SP, #0x20
    // 0xce15d0: SetupParameters(_RenderCupertinoSlider this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xce15d0: mov             x0, x2
    //     0xce15d4: stur            x1, [fp, #-8]
    //     0xce15d8: stur            x2, [fp, #-0x10]
    // 0xce15dc: CheckStackOverflow
    //     0xce15dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce15e0: cmp             SP, x16
    //     0xce15e4: b.ls            #0xce1640
    // 0xce15e8: LoadField: r2 = r1->field_73
    //     0xce15e8: ldur            w2, [x1, #0x73]
    // 0xce15ec: DecompressPointer r2
    //     0xce15ec: add             x2, x2, HEAP, lsl #32
    // 0xce15f0: stp             x2, x0, [SP]
    // 0xce15f4: r0 = ==()
    //     0xce15f4: bl              #0x12b7e74  ; [dart:core] _Closure::==
    // 0xce15f8: tbnz            w0, #4, #0xce160c
    // 0xce15fc: r0 = Null
    //     0xce15fc: mov             x0, NULL
    // 0xce1600: LeaveFrame
    //     0xce1600: mov             SP, fp
    //     0xce1604: ldp             fp, lr, [SP], #0x10
    // 0xce1608: ret
    //     0xce1608: ret             
    // 0xce160c: ldur            x1, [fp, #-8]
    // 0xce1610: ldur            x0, [fp, #-0x10]
    // 0xce1614: StoreField: r1->field_73 = r0
    //     0xce1614: stur            w0, [x1, #0x73]
    //     0xce1618: ldurb           w16, [x1, #-1]
    //     0xce161c: ldurb           w17, [x0, #-1]
    //     0xce1620: and             x16, x17, x16, lsr #2
    //     0xce1624: tst             x16, HEAP, lsr #32
    //     0xce1628: b.eq            #0xce1630
    //     0xce162c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xce1630: r0 = Null
    //     0xce1630: mov             x0, NULL
    // 0xce1634: LeaveFrame
    //     0xce1634: mov             SP, fp
    //     0xce1638: ldp             fp, lr, [SP], #0x10
    // 0xce163c: ret
    //     0xce163c: ret             
    // 0xce1640: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce1640: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce1644: b               #0xce15e8
  }
  set _ trackColor=(/* No info */) {
    // ** addr: 0xce1648, size: 0x88
    // 0xce1648: EnterFrame
    //     0xce1648: stp             fp, lr, [SP, #-0x10]!
    //     0xce164c: mov             fp, SP
    // 0xce1650: AllocStack(0x20)
    //     0xce1650: sub             SP, SP, #0x20
    // 0xce1654: SetupParameters(_RenderCupertinoSlider this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xce1654: mov             x0, x2
    //     0xce1658: stur            x1, [fp, #-8]
    //     0xce165c: stur            x2, [fp, #-0x10]
    // 0xce1660: CheckStackOverflow
    //     0xce1660: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce1664: cmp             SP, x16
    //     0xce1668: b.ls            #0xce16c8
    // 0xce166c: LoadField: r2 = r1->field_6f
    //     0xce166c: ldur            w2, [x1, #0x6f]
    // 0xce1670: DecompressPointer r2
    //     0xce1670: add             x2, x2, HEAP, lsl #32
    // 0xce1674: stp             x2, x0, [SP]
    // 0xce1678: r0 = ==()
    //     0xce1678: bl              #0x12629d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::==
    // 0xce167c: tbnz            w0, #4, #0xce1690
    // 0xce1680: r0 = Null
    //     0xce1680: mov             x0, NULL
    // 0xce1684: LeaveFrame
    //     0xce1684: mov             SP, fp
    //     0xce1688: ldp             fp, lr, [SP], #0x10
    // 0xce168c: ret
    //     0xce168c: ret             
    // 0xce1690: ldur            x1, [fp, #-8]
    // 0xce1694: ldur            x0, [fp, #-0x10]
    // 0xce1698: StoreField: r1->field_6f = r0
    //     0xce1698: stur            w0, [x1, #0x6f]
    //     0xce169c: ldurb           w16, [x1, #-1]
    //     0xce16a0: ldurb           w17, [x0, #-1]
    //     0xce16a4: and             x16, x17, x16, lsr #2
    //     0xce16a8: tst             x16, HEAP, lsr #32
    //     0xce16ac: b.eq            #0xce16b4
    //     0xce16b0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xce16b4: r0 = markNeedsPaint()
    //     0xce16b4: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xce16b8: r0 = Null
    //     0xce16b8: mov             x0, NULL
    // 0xce16bc: LeaveFrame
    //     0xce16bc: mov             SP, fp
    //     0xce16c0: ldp             fp, lr, [SP], #0x10
    // 0xce16c4: ret
    //     0xce16c4: ret             
    // 0xce16c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce16c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce16cc: b               #0xce166c
  }
  set _ thumbColor=(/* No info */) {
    // ** addr: 0xce24b0, size: 0x74
    // 0xce24b0: EnterFrame
    //     0xce24b0: stp             fp, lr, [SP, #-0x10]!
    //     0xce24b4: mov             fp, SP
    // 0xce24b8: AllocStack(0x18)
    //     0xce24b8: sub             SP, SP, #0x18
    // 0xce24bc: SetupParameters(_RenderCupertinoSlider this /* r1 => r1, fp-0x8 */)
    //     0xce24bc: stur            x1, [fp, #-8]
    // 0xce24c0: CheckStackOverflow
    //     0xce24c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce24c4: cmp             SP, x16
    //     0xce24c8: b.ls            #0xce251c
    // 0xce24cc: r16 = Instance_Color
    //     0xce24cc: add             x16, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0xce24d0: ldr             x16, [x16, #0xc38]
    // 0xce24d4: r30 = Instance_Color
    //     0xce24d4: add             lr, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0xce24d8: ldr             lr, [lr, #0xc38]
    // 0xce24dc: stp             lr, x16, [SP]
    // 0xce24e0: r0 = ==()
    //     0xce24e0: bl              #0x128cb50  ; [dart:ui] Color::==
    // 0xce24e4: tbnz            w0, #4, #0xce24f8
    // 0xce24e8: r0 = Null
    //     0xce24e8: mov             x0, NULL
    // 0xce24ec: LeaveFrame
    //     0xce24ec: mov             SP, fp
    //     0xce24f0: ldp             fp, lr, [SP], #0x10
    // 0xce24f4: ret
    //     0xce24f4: ret             
    // 0xce24f8: ldur            x1, [fp, #-8]
    // 0xce24fc: r0 = Instance_Color
    //     0xce24fc: add             x0, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0xce2500: ldr             x0, [x0, #0xc38]
    // 0xce2504: StoreField: r1->field_6b = r0
    //     0xce2504: stur            w0, [x1, #0x6b]
    // 0xce2508: r0 = markNeedsPaint()
    //     0xce2508: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xce250c: r0 = Null
    //     0xce250c: mov             x0, NULL
    // 0xce2510: LeaveFrame
    //     0xce2510: mov             SP, fp
    //     0xce2514: ldp             fp, lr, [SP], #0x10
    // 0xce2518: ret
    //     0xce2518: ret             
    // 0xce251c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce251c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce2520: b               #0xce24cc
  }
  set _ activeColor=(/* No info */) {
    // ** addr: 0xce2524, size: 0xa4
    // 0xce2524: EnterFrame
    //     0xce2524: stp             fp, lr, [SP, #-0x10]!
    //     0xce2528: mov             fp, SP
    // 0xce252c: AllocStack(0x20)
    //     0xce252c: sub             SP, SP, #0x20
    // 0xce2530: SetupParameters(_RenderCupertinoSlider this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xce2530: stur            x1, [fp, #-8]
    //     0xce2534: mov             x16, x2
    //     0xce2538: mov             x2, x1
    //     0xce253c: mov             x1, x16
    //     0xce2540: stur            x1, [fp, #-0x10]
    // 0xce2544: CheckStackOverflow
    //     0xce2544: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce2548: cmp             SP, x16
    //     0xce254c: b.ls            #0xce25c0
    // 0xce2550: LoadField: r0 = r2->field_67
    //     0xce2550: ldur            w0, [x2, #0x67]
    // 0xce2554: DecompressPointer r0
    //     0xce2554: add             x0, x0, HEAP, lsl #32
    // 0xce2558: r3 = LoadClassIdInstr(r1)
    //     0xce2558: ldur            x3, [x1, #-1]
    //     0xce255c: ubfx            x3, x3, #0xc, #0x14
    // 0xce2560: stp             x0, x1, [SP]
    // 0xce2564: mov             x0, x3
    // 0xce2568: mov             lr, x0
    // 0xce256c: ldr             lr, [x21, lr, lsl #3]
    // 0xce2570: blr             lr
    // 0xce2574: tbnz            w0, #4, #0xce2588
    // 0xce2578: r0 = Null
    //     0xce2578: mov             x0, NULL
    // 0xce257c: LeaveFrame
    //     0xce257c: mov             SP, fp
    //     0xce2580: ldp             fp, lr, [SP], #0x10
    // 0xce2584: ret
    //     0xce2584: ret             
    // 0xce2588: ldur            x1, [fp, #-8]
    // 0xce258c: ldur            x0, [fp, #-0x10]
    // 0xce2590: StoreField: r1->field_67 = r0
    //     0xce2590: stur            w0, [x1, #0x67]
    //     0xce2594: ldurb           w16, [x1, #-1]
    //     0xce2598: ldurb           w17, [x0, #-1]
    //     0xce259c: and             x16, x17, x16, lsr #2
    //     0xce25a0: tst             x16, HEAP, lsr #32
    //     0xce25a4: b.eq            #0xce25ac
    //     0xce25a8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xce25ac: r0 = markNeedsPaint()
    //     0xce25ac: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xce25b0: r0 = Null
    //     0xce25b0: mov             x0, NULL
    // 0xce25b4: LeaveFrame
    //     0xce25b4: mov             SP, fp
    //     0xce25b8: ldp             fp, lr, [SP], #0x10
    // 0xce25bc: ret
    //     0xce25bc: ret             
    // 0xce25c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce25c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce25c4: b               #0xce2550
  }
  set _ divisions=(/* No info */) {
    // ** addr: 0xce25c8, size: 0x50
    // 0xce25c8: EnterFrame
    //     0xce25c8: stp             fp, lr, [SP, #-0x10]!
    //     0xce25cc: mov             fp, SP
    // 0xce25d0: CheckStackOverflow
    //     0xce25d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce25d4: cmp             SP, x16
    //     0xce25d8: b.ls            #0xce2610
    // 0xce25dc: LoadField: r0 = r1->field_5f
    //     0xce25dc: ldur            x0, [x1, #0x5f]
    // 0xce25e0: cmp             x2, x0
    // 0xce25e4: b.ne            #0xce25f8
    // 0xce25e8: r0 = Null
    //     0xce25e8: mov             x0, NULL
    // 0xce25ec: LeaveFrame
    //     0xce25ec: mov             SP, fp
    //     0xce25f0: ldp             fp, lr, [SP], #0x10
    // 0xce25f4: ret
    //     0xce25f4: ret             
    // 0xce25f8: StoreField: r1->field_5f = r2
    //     0xce25f8: stur            x2, [x1, #0x5f]
    // 0xce25fc: r0 = markNeedsPaint()
    //     0xce25fc: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xce2600: r0 = Null
    //     0xce2600: mov             x0, NULL
    // 0xce2604: LeaveFrame
    //     0xce2604: mov             SP, fp
    //     0xce2608: ldp             fp, lr, [SP], #0x10
    // 0xce260c: ret
    //     0xce260c: ret             
    // 0xce2610: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce2610: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce2614: b               #0xce25dc
  }
  _ _RenderCupertinoSlider(/* No info */) {
    // ** addr: 0x11bf298, size: 0x298
    // 0x11bf298: EnterFrame
    //     0x11bf298: stp             fp, lr, [SP, #-0x10]!
    //     0x11bf29c: mov             fp, SP
    // 0x11bf2a0: AllocStack(0x30)
    //     0x11bf2a0: sub             SP, SP, #0x30
    // 0x11bf2a4: ldr             x8, [THR, #0x90]  ; THR::object_sentinel
    // 0x11bf2a8: r0 = Instance__DeferringMouseCursor
    //     0x11bf2a8: ldr             x0, [PP, #0x2208]  ; [pp+0x2208] Obj!_DeferringMouseCursor@12b3241
    // 0x11bf2ac: r4 = Instance_Color
    //     0x11bf2ac: add             x4, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0x11bf2b0: ldr             x4, [x4, #0xc38]
    // 0x11bf2b4: stur            x1, [fp, #-8]
    // 0x11bf2b8: mov             x16, x7
    // 0x11bf2bc: mov             x7, x1
    // 0x11bf2c0: mov             x1, x16
    // 0x11bf2c4: mov             x16, x6
    // 0x11bf2c8: mov             x6, x2
    // 0x11bf2cc: mov             x2, x16
    // 0x11bf2d0: mov             x16, x5
    // 0x11bf2d4: mov             x5, x3
    // 0x11bf2d8: mov             x3, x16
    // 0x11bf2dc: stur            d0, [fp, #-0x20]
    // 0x11bf2e0: CheckStackOverflow
    //     0x11bf2e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11bf2e4: cmp             SP, x16
    //     0x11bf2e8: b.ls            #0x11bf510
    // 0x11bf2ec: StoreField: r7->field_83 = r8
    //     0x11bf2ec: stur            w8, [x7, #0x83]
    // 0x11bf2f0: StoreField: r7->field_87 = r8
    //     0x11bf2f0: stur            w8, [x7, #0x87]
    // 0x11bf2f4: StoreField: r7->field_8b = rZR
    //     0x11bf2f4: stur            xzr, [x7, #0x8b]
    // 0x11bf2f8: StoreField: r7->field_97 = r0
    //     0x11bf2f8: stur            w0, [x7, #0x97]
    // 0x11bf2fc: StoreField: r7->field_57 = d0
    //     0x11bf2fc: stur            d0, [x7, #0x57]
    // 0x11bf300: StoreField: r7->field_5f = r5
    //     0x11bf300: stur            x5, [x7, #0x5f]
    // 0x11bf304: mov             x0, x6
    // 0x11bf308: StoreField: r7->field_67 = r0
    //     0x11bf308: stur            w0, [x7, #0x67]
    //     0x11bf30c: ldurb           w16, [x7, #-1]
    //     0x11bf310: ldurb           w17, [x0, #-1]
    //     0x11bf314: and             x16, x17, x16, lsr #2
    //     0x11bf318: tst             x16, HEAP, lsr #32
    //     0x11bf31c: b.eq            #0x11bf324
    //     0x11bf320: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0x11bf324: StoreField: r7->field_6b = r4
    //     0x11bf324: stur            w4, [x7, #0x6b]
    // 0x11bf328: mov             x0, x1
    // 0x11bf32c: StoreField: r7->field_6f = r0
    //     0x11bf32c: stur            w0, [x7, #0x6f]
    //     0x11bf330: ldurb           w16, [x7, #-1]
    //     0x11bf334: ldurb           w17, [x0, #-1]
    //     0x11bf338: and             x16, x17, x16, lsr #2
    //     0x11bf33c: tst             x16, HEAP, lsr #32
    //     0x11bf340: b.eq            #0x11bf348
    //     0x11bf344: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0x11bf348: mov             x0, x3
    // 0x11bf34c: StoreField: r7->field_73 = r0
    //     0x11bf34c: stur            w0, [x7, #0x73]
    //     0x11bf350: ldurb           w16, [x7, #-1]
    //     0x11bf354: ldurb           w17, [x0, #-1]
    //     0x11bf358: and             x16, x17, x16, lsr #2
    //     0x11bf35c: tst             x16, HEAP, lsr #32
    //     0x11bf360: b.eq            #0x11bf368
    //     0x11bf364: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0x11bf368: mov             x0, x2
    // 0x11bf36c: StoreField: r7->field_7f = r0
    //     0x11bf36c: stur            w0, [x7, #0x7f]
    //     0x11bf370: ldurb           w16, [x7, #-1]
    //     0x11bf374: ldurb           w17, [x0, #-1]
    //     0x11bf378: and             x16, x17, x16, lsr #2
    //     0x11bf37c: tst             x16, HEAP, lsr #32
    //     0x11bf380: b.eq            #0x11bf388
    //     0x11bf384: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0x11bf388: mov             x1, x7
    // 0x11bf38c: r2 = Instance_BoxConstraints
    //     0x11bf38c: add             x2, PP, #0xcc, lsl #12  ; [pp+0xcc870] Obj!BoxConstraints@129c591
    //     0x11bf390: ldr             x2, [x2, #0x870]
    // 0x11bf394: r0 = RenderIntrinsicWidth()
    //     0x11bf394: bl              #0x11bf530  ; [package:flutter/src/rendering/proxy_box.dart] RenderIntrinsicWidth::RenderIntrinsicWidth
    // 0x11bf398: r0 = HorizontalDragGestureRecognizer()
    //     0x11bf398: bl              #0xb8d854  ; AllocateHorizontalDragGestureRecognizerStub -> HorizontalDragGestureRecognizer (size=0x90)
    // 0x11bf39c: mov             x1, x0
    // 0x11bf3a0: r2 = Null
    //     0x11bf3a0: mov             x2, NULL
    // 0x11bf3a4: stur            x0, [fp, #-0x10]
    // 0x11bf3a8: r0 = DragGestureRecognizer()
    //     0x11bf3a8: bl              #0xb8d344  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::DragGestureRecognizer
    // 0x11bf3ac: ldur            x2, [fp, #-8]
    // 0x11bf3b0: r1 = Function '_handleDragStart@296348729':.
    //     0x11bf3b0: add             x1, PP, #0xcc, lsl #12  ; [pp+0xcc878] AnonymousClosure: (0x11bf904), of [package:flutter/src/cupertino/slider.dart] _RenderCupertinoSlider
    //     0x11bf3b4: ldr             x1, [x1, #0x878]
    // 0x11bf3b8: r0 = AllocateClosure()
    //     0x11bf3b8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11bf3bc: ldur            x3, [fp, #-0x10]
    // 0x11bf3c0: StoreField: r3->field_2f = r0
    //     0x11bf3c0: stur            w0, [x3, #0x2f]
    //     0x11bf3c4: ldurb           w16, [x3, #-1]
    //     0x11bf3c8: ldurb           w17, [x0, #-1]
    //     0x11bf3cc: and             x16, x17, x16, lsr #2
    //     0x11bf3d0: tst             x16, HEAP, lsr #32
    //     0x11bf3d4: b.eq            #0x11bf3dc
    //     0x11bf3d8: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x11bf3dc: ldur            x2, [fp, #-8]
    // 0x11bf3e0: r1 = Function '_handleDragUpdate@296348729':.
    //     0x11bf3e0: add             x1, PP, #0xcc, lsl #12  ; [pp+0xcc880] AnonymousClosure: (0x11bf608), in [package:flutter/src/cupertino/slider.dart] _RenderCupertinoSlider::_handleDragUpdate (0x11bf644)
    //     0x11bf3e4: ldr             x1, [x1, #0x880]
    // 0x11bf3e8: r0 = AllocateClosure()
    //     0x11bf3e8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11bf3ec: ldur            x3, [fp, #-0x10]
    // 0x11bf3f0: StoreField: r3->field_33 = r0
    //     0x11bf3f0: stur            w0, [x3, #0x33]
    //     0x11bf3f4: ldurb           w16, [x3, #-1]
    //     0x11bf3f8: ldurb           w17, [x0, #-1]
    //     0x11bf3fc: and             x16, x17, x16, lsr #2
    //     0x11bf400: tst             x16, HEAP, lsr #32
    //     0x11bf404: b.eq            #0x11bf40c
    //     0x11bf408: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x11bf40c: ldur            x2, [fp, #-8]
    // 0x11bf410: r1 = Function '_handleDragEnd@296348729':.
    //     0x11bf410: add             x1, PP, #0xcc, lsl #12  ; [pp+0xcc888] AnonymousClosure: (0x11bf5bc), of [package:flutter/src/cupertino/slider.dart] _RenderCupertinoSlider
    //     0x11bf414: ldr             x1, [x1, #0x888]
    // 0x11bf418: r0 = AllocateClosure()
    //     0x11bf418: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11bf41c: ldur            x1, [fp, #-0x10]
    // 0x11bf420: StoreField: r1->field_37 = r0
    //     0x11bf420: stur            w0, [x1, #0x37]
    //     0x11bf424: ldurb           w16, [x1, #-1]
    //     0x11bf428: ldurb           w17, [x0, #-1]
    //     0x11bf42c: and             x16, x17, x16, lsr #2
    //     0x11bf430: tst             x16, HEAP, lsr #32
    //     0x11bf434: b.eq            #0x11bf43c
    //     0x11bf438: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11bf43c: mov             x0, x1
    // 0x11bf440: ldur            x2, [fp, #-8]
    // 0x11bf444: StoreField: r2->field_87 = r0
    //     0x11bf444: stur            w0, [x2, #0x87]
    //     0x11bf448: ldurb           w16, [x2, #-1]
    //     0x11bf44c: ldurb           w17, [x0, #-1]
    //     0x11bf450: and             x16, x17, x16, lsr #2
    //     0x11bf454: tst             x16, HEAP, lsr #32
    //     0x11bf458: b.eq            #0x11bf460
    //     0x11bf45c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11bf460: ldur            d0, [fp, #-0x20]
    // 0x11bf464: r0 = inline_Allocate_Double()
    //     0x11bf464: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x11bf468: add             x0, x0, #0x10
    //     0x11bf46c: cmp             x1, x0
    //     0x11bf470: b.ls            #0x11bf518
    //     0x11bf474: str             x0, [THR, #0x60]  ; THR::top
    //     0x11bf478: sub             x0, x0, #0xf
    //     0x11bf47c: mov             x1, #0xe19c
    //     0x11bf480: movk            x1, #3, lsl #16
    //     0x11bf484: stur            x1, [x0, #-1]
    // 0x11bf488: dmb             ishst
    // 0x11bf48c: StoreField: r0->field_7 = d0
    //     0x11bf48c: stur            d0, [x0, #7]
    // 0x11bf490: stur            x0, [fp, #-0x10]
    // 0x11bf494: r1 = <double>
    //     0x11bf494: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0x11bf498: r0 = AnimationController()
    //     0x11bf498: bl              #0x87522c  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x11bf49c: stur            x0, [fp, #-0x18]
    // 0x11bf4a0: ldur            x16, [fp, #-0x10]
    // 0x11bf4a4: r30 = Instance_Duration
    //     0x11bf4a4: ldr             lr, [PP, #0x5248]  ; [pp+0x5248] Obj!Duration@12c8931
    // 0x11bf4a8: stp             lr, x16, [SP]
    // 0x11bf4ac: mov             x1, x0
    // 0x11bf4b0: ldr             x2, [fp, #0x10]
    // 0x11bf4b4: r4 = const [0, 0x4, 0x2, 0x2, duration, 0x3, value, 0x2, null]
    //     0x11bf4b4: add             x4, PP, #0x84, lsl #12  ; [pp+0x84ce0] List(9) [0, 0x4, 0x2, 0x2, "duration", 0x3, "value", 0x2, Null]
    //     0x11bf4b8: ldr             x4, [x4, #0xce0]
    // 0x11bf4bc: r0 = AnimationController()
    //     0x11bf4bc: bl              #0x874ea4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x11bf4c0: ldur            x2, [fp, #-8]
    // 0x11bf4c4: r1 = Function 'markNeedsPaint':.
    //     0x11bf4c4: add             x1, PP, #0x90, lsl #12  ; [pp+0x901f0] AnonymousClosure: (0xbf0a50), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0xbf0858)
    //     0x11bf4c8: ldr             x1, [x1, #0x1f0]
    // 0x11bf4cc: r0 = AllocateClosure()
    //     0x11bf4cc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11bf4d0: ldur            x1, [fp, #-0x18]
    // 0x11bf4d4: mov             x2, x0
    // 0x11bf4d8: r0 = addListener()
    //     0x11bf4d8: bl              #0xd0440c  ; [dart:mixin_deduplication] _MixinApplication455&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::addListener
    // 0x11bf4dc: ldur            x0, [fp, #-0x18]
    // 0x11bf4e0: ldur            x1, [fp, #-8]
    // 0x11bf4e4: StoreField: r1->field_83 = r0
    //     0x11bf4e4: stur            w0, [x1, #0x83]
    //     0x11bf4e8: ldurb           w16, [x1, #-1]
    //     0x11bf4ec: ldurb           w17, [x0, #-1]
    //     0x11bf4f0: and             x16, x17, x16, lsr #2
    //     0x11bf4f4: tst             x16, HEAP, lsr #32
    //     0x11bf4f8: b.eq            #0x11bf500
    //     0x11bf4fc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11bf500: r0 = Null
    //     0x11bf500: mov             x0, NULL
    // 0x11bf504: LeaveFrame
    //     0x11bf504: mov             SP, fp
    //     0x11bf508: ldp             fp, lr, [SP], #0x10
    // 0x11bf50c: ret
    //     0x11bf50c: ret             
    // 0x11bf510: r0 = StackOverflowSharedWithFPURegs()
    //     0x11bf510: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x11bf514: b               #0x11bf2ec
    // 0x11bf518: SaveReg d0
    //     0x11bf518: str             q0, [SP, #-0x10]!
    // 0x11bf51c: SaveReg r2
    //     0x11bf51c: str             x2, [SP, #-8]!
    // 0x11bf520: r0 = AllocateDouble()
    //     0x11bf520: bl              #0x13df878  ; AllocateDoubleStub
    // 0x11bf524: RestoreReg r2
    //     0x11bf524: ldr             x2, [SP], #8
    // 0x11bf528: RestoreReg d0
    //     0x11bf528: ldr             q0, [SP], #0x10
    // 0x11bf52c: b               #0x11bf48c
  }
  [closure] void _handleDragEnd(dynamic, DragEndDetails) {
    // ** addr: 0x11bf5bc, size: 0x3c
    // 0x11bf5bc: EnterFrame
    //     0x11bf5bc: stp             fp, lr, [SP, #-0x10]!
    //     0x11bf5c0: mov             fp, SP
    // 0x11bf5c4: ldr             x0, [fp, #0x18]
    // 0x11bf5c8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x11bf5c8: ldur            w1, [x0, #0x17]
    // 0x11bf5cc: DecompressPointer r1
    //     0x11bf5cc: add             x1, x1, HEAP, lsl #32
    // 0x11bf5d0: CheckStackOverflow
    //     0x11bf5d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11bf5d4: cmp             SP, x16
    //     0x11bf5d8: b.ls            #0x11bf5f0
    // 0x11bf5dc: r0 = _endInteraction()
    //     0x11bf5dc: bl              #0x11bf5f8  ; [package:flutter/src/cupertino/slider.dart] _RenderCupertinoSlider::_endInteraction
    // 0x11bf5e0: r0 = Null
    //     0x11bf5e0: mov             x0, NULL
    // 0x11bf5e4: LeaveFrame
    //     0x11bf5e4: mov             SP, fp
    //     0x11bf5e8: ldp             fp, lr, [SP], #0x10
    // 0x11bf5ec: ret
    //     0x11bf5ec: ret             
    // 0x11bf5f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11bf5f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11bf5f4: b               #0x11bf5dc
  }
  _ _endInteraction(/* No info */) {
    // ** addr: 0x11bf5f8, size: 0x10
    // 0x11bf5f8: StoreField: r1->field_8b = rZR
    //     0x11bf5f8: stur            xzr, [x1, #0x8b]
    // 0x11bf5fc: StoreField: r1->field_93 = rNULL
    //     0x11bf5fc: stur            NULL, [x1, #0x93]
    // 0x11bf600: r0 = Null
    //     0x11bf600: mov             x0, NULL
    // 0x11bf604: ret
    //     0x11bf604: ret             
  }
  [closure] void _handleDragUpdate(dynamic, DragUpdateDetails) {
    // ** addr: 0x11bf608, size: 0x3c
    // 0x11bf608: EnterFrame
    //     0x11bf608: stp             fp, lr, [SP, #-0x10]!
    //     0x11bf60c: mov             fp, SP
    // 0x11bf610: ldr             x0, [fp, #0x18]
    // 0x11bf614: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x11bf614: ldur            w1, [x0, #0x17]
    // 0x11bf618: DecompressPointer r1
    //     0x11bf618: add             x1, x1, HEAP, lsl #32
    // 0x11bf61c: CheckStackOverflow
    //     0x11bf61c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11bf620: cmp             SP, x16
    //     0x11bf624: b.ls            #0x11bf63c
    // 0x11bf628: ldr             x2, [fp, #0x10]
    // 0x11bf62c: r0 = _handleDragUpdate()
    //     0x11bf62c: bl              #0x11bf644  ; [package:flutter/src/cupertino/slider.dart] _RenderCupertinoSlider::_handleDragUpdate
    // 0x11bf630: LeaveFrame
    //     0x11bf630: mov             SP, fp
    //     0x11bf634: ldp             fp, lr, [SP], #0x10
    // 0x11bf638: ret
    //     0x11bf638: ret             
    // 0x11bf63c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11bf63c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11bf640: b               #0x11bf628
  }
  _ _handleDragUpdate(/* No info */) {
    // ** addr: 0x11bf644, size: 0x1d0
    // 0x11bf644: EnterFrame
    //     0x11bf644: stp             fp, lr, [SP, #-0x10]!
    //     0x11bf648: mov             fp, SP
    // 0x11bf64c: AllocStack(0x18)
    //     0x11bf64c: sub             SP, SP, #0x18
    // 0x11bf650: SetupParameters(_RenderCupertinoSlider this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x11bf650: mov             x0, x1
    //     0x11bf654: stur            x1, [fp, #-8]
    //     0x11bf658: stur            x2, [fp, #-0x10]
    // 0x11bf65c: CheckStackOverflow
    //     0x11bf65c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11bf660: cmp             SP, x16
    //     0x11bf664: b.ls            #0x11bf7ec
    // 0x11bf668: mov             x1, x0
    // 0x11bf66c: r0 = size()
    //     0x11bf66c: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0x11bf670: LoadField: d0 = r0->field_7
    //     0x11bf670: ldur            d0, [x0, #7]
    // 0x11bf674: d1 = 44.000000
    //     0x11bf674: add             x17, PP, #0x8f, lsl #12  ; [pp+0x8f600] IMM: double(44) from 0x4046000000000000
    //     0x11bf678: ldr             d1, [x17, #0x600]
    // 0x11bf67c: fsub            d2, d0, d1
    // 0x11bf680: d0 = 8.000000
    //     0x11bf680: fmov            d0, #8.00000000
    // 0x11bf684: fmax            v1.2d, v0.2d, v2.2d
    // 0x11bf688: ldur            x0, [fp, #-0x10]
    // 0x11bf68c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x11bf68c: ldur            w1, [x0, #0x17]
    // 0x11bf690: DecompressPointer r1
    //     0x11bf690: add             x1, x1, HEAP, lsl #32
    // 0x11bf694: cmp             w1, NULL
    // 0x11bf698: b.eq            #0x11bf7f4
    // 0x11bf69c: LoadField: d0 = r1->field_7
    //     0x11bf69c: ldur            d0, [x1, #7]
    // 0x11bf6a0: fdiv            d2, d0, d1
    // 0x11bf6a4: ldur            x1, [fp, #-8]
    // 0x11bf6a8: LoadField: d0 = r1->field_8b
    //     0x11bf6a8: ldur            d0, [x1, #0x8b]
    // 0x11bf6ac: LoadField: r2 = r1->field_7f
    //     0x11bf6ac: ldur            w2, [x1, #0x7f]
    // 0x11bf6b0: DecompressPointer r2
    //     0x11bf6b0: add             x2, x2, HEAP, lsl #32
    // 0x11bf6b4: LoadField: r3 = r2->field_7
    //     0x11bf6b4: ldur            x3, [x2, #7]
    // 0x11bf6b8: cmp             x3, #0
    // 0x11bf6bc: b.gt            #0x11bf6c8
    // 0x11bf6c0: fneg            d1, d2
    // 0x11bf6c4: b               #0x11bf6cc
    // 0x11bf6c8: mov             v1.16b, v2.16b
    // 0x11bf6cc: fadd            d3, d0, d1
    // 0x11bf6d0: StoreField: r1->field_8b = d3
    //     0x11bf6d0: stur            d3, [x1, #0x8b]
    // 0x11bf6d4: LoadField: r2 = r0->field_f
    //     0x11bf6d4: ldur            w2, [x0, #0xf]
    // 0x11bf6d8: DecompressPointer r2
    //     0x11bf6d8: add             x2, x2, HEAP, lsl #32
    // 0x11bf6dc: cmp             w2, NULL
    // 0x11bf6e0: b.eq            #0x11bf764
    // 0x11bf6e4: LoadField: r0 = r1->field_93
    //     0x11bf6e4: ldur            w0, [x1, #0x93]
    // 0x11bf6e8: DecompressPointer r0
    //     0x11bf6e8: add             x0, x0, HEAP, lsl #32
    // 0x11bf6ec: cmp             w0, NULL
    // 0x11bf6f0: b.eq            #0x11bf764
    // 0x11bf6f4: r3 = 1000
    //     0x11bf6f4: mov             x3, #0x3e8
    // 0x11bf6f8: d0 = 0.000000
    //     0x11bf6f8: eor             v0.16b, v0.16b, v0.16b
    // 0x11bf6fc: LoadField: r4 = r2->field_7
    //     0x11bf6fc: ldur            x4, [x2, #7]
    // 0x11bf700: LoadField: r5 = r0->field_7
    //     0x11bf700: ldur            x5, [x0, #7]
    // 0x11bf704: sub             x0, x4, x5
    // 0x11bf708: sdiv            x4, x0, x3
    // 0x11bf70c: fcmp            d2, d0
    // 0x11bf710: b.ne            #0x11bf71c
    // 0x11bf714: d2 = 0.000000
    //     0x11bf714: eor             v2.16b, v2.16b, v2.16b
    // 0x11bf718: b               #0x11bf734
    // 0x11bf71c: fcmp            d0, d2
    // 0x11bf720: b.le            #0x11bf72c
    // 0x11bf724: fneg            d0, d2
    // 0x11bf728: b               #0x11bf730
    // 0x11bf72c: mov             v0.16b, v2.16b
    // 0x11bf730: mov             v2.16b, v0.16b
    // 0x11bf734: d1 = 1000.000000
    //     0x11bf734: add             x17, PP, #0x16, lsl #12  ; [pp+0x16a58] IMM: double(1000) from 0x408f400000000000
    //     0x11bf738: ldr             d1, [x17, #0xa58]
    // 0x11bf73c: d0 = 1.000000
    //     0x11bf73c: fmov            d0, #1.00000000
    // 0x11bf740: fmul            d3, d2, d1
    // 0x11bf744: scvtf           d1, x4
    // 0x11bf748: fdiv            d2, d3, d1
    // 0x11bf74c: fcmp            d2, d0
    // 0x11bf750: r16 = true
    //     0x11bf750: add             x16, NULL, #0x20  ; true
    // 0x11bf754: r17 = false
    //     0x11bf754: add             x17, NULL, #0x30  ; false
    // 0x11bf758: csel            x0, x16, x17, gt
    // 0x11bf75c: mov             x3, x0
    // 0x11bf760: b               #0x11bf768
    // 0x11bf764: r3 = false
    //     0x11bf764: add             x3, NULL, #0x30  ; false
    // 0x11bf768: mov             x0, x2
    // 0x11bf76c: stur            x3, [fp, #-0x18]
    // 0x11bf770: StoreField: r1->field_93 = r0
    //     0x11bf770: stur            w0, [x1, #0x93]
    //     0x11bf774: ldurb           w16, [x1, #-1]
    //     0x11bf778: ldurb           w17, [x0, #-1]
    //     0x11bf77c: and             x16, x17, x16, lsr #2
    //     0x11bf780: tst             x16, HEAP, lsr #32
    //     0x11bf784: b.eq            #0x11bf78c
    //     0x11bf788: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11bf78c: LoadField: r0 = r1->field_73
    //     0x11bf78c: ldur            w0, [x1, #0x73]
    // 0x11bf790: DecompressPointer r0
    //     0x11bf790: add             x0, x0, HEAP, lsl #32
    // 0x11bf794: stur            x0, [fp, #-0x10]
    // 0x11bf798: r0 = _discretizedCurrentDragValue()
    //     0x11bf798: bl              #0x11bf814  ; [package:flutter/src/cupertino/slider.dart] _RenderCupertinoSlider::_discretizedCurrentDragValue
    // 0x11bf79c: ldur            x0, [fp, #-0x10]
    // 0x11bf7a0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x11bf7a0: ldur            w1, [x0, #0x17]
    // 0x11bf7a4: DecompressPointer r1
    //     0x11bf7a4: add             x1, x1, HEAP, lsl #32
    // 0x11bf7a8: r2 = inline_Allocate_Double()
    //     0x11bf7a8: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0x11bf7ac: add             x2, x2, #0x10
    //     0x11bf7b0: cmp             x0, x2
    //     0x11bf7b4: b.ls            #0x11bf7f8
    //     0x11bf7b8: str             x2, [THR, #0x60]  ; THR::top
    //     0x11bf7bc: sub             x2, x2, #0xf
    //     0x11bf7c0: mov             x0, #0xe19c
    //     0x11bf7c4: movk            x0, #3, lsl #16
    //     0x11bf7c8: stur            x0, [x2, #-1]
    // 0x11bf7cc: dmb             ishst
    // 0x11bf7d0: StoreField: r2->field_7 = d0
    //     0x11bf7d0: stur            d0, [x2, #7]
    // 0x11bf7d4: ldur            x3, [fp, #-0x18]
    // 0x11bf7d8: r0 = _handleChanged()
    //     0x11bf7d8: bl              #0xbf53c4  ; [package:flutter/src/cupertino/slider.dart] _CupertinoSliderState::_handleChanged
    // 0x11bf7dc: r0 = Null
    //     0x11bf7dc: mov             x0, NULL
    // 0x11bf7e0: LeaveFrame
    //     0x11bf7e0: mov             SP, fp
    //     0x11bf7e4: ldp             fp, lr, [SP], #0x10
    // 0x11bf7e8: ret
    //     0x11bf7e8: ret             
    // 0x11bf7ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11bf7ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11bf7f0: b               #0x11bf668
    // 0x11bf7f4: r0 = NullCastErrorSharedWithFPURegs()
    //     0x11bf7f4: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0x11bf7f8: SaveReg d0
    //     0x11bf7f8: str             q0, [SP, #-0x10]!
    // 0x11bf7fc: SaveReg r1
    //     0x11bf7fc: str             x1, [SP, #-8]!
    // 0x11bf800: r0 = AllocateDouble()
    //     0x11bf800: bl              #0x13df878  ; AllocateDoubleStub
    // 0x11bf804: mov             x2, x0
    // 0x11bf808: RestoreReg r1
    //     0x11bf808: ldr             x1, [SP], #8
    // 0x11bf80c: RestoreReg d0
    //     0x11bf80c: ldr             q0, [SP], #0x10
    // 0x11bf810: b               #0x11bf7d0
  }
  double _discretizedCurrentDragValue(_RenderCupertinoSlider) {
    // ** addr: 0x11bf814, size: 0xf0
    // 0x11bf814: EnterFrame
    //     0x11bf814: stp             fp, lr, [SP, #-0x10]!
    //     0x11bf818: mov             fp, SP
    // 0x11bf81c: AllocStack(0x8)
    //     0x11bf81c: sub             SP, SP, #8
    // 0x11bf820: d0 = 0.000000
    //     0x11bf820: eor             v0.16b, v0.16b, v0.16b
    // 0x11bf824: LoadField: d1 = r1->field_8b
    //     0x11bf824: ldur            d1, [x1, #0x8b]
    // 0x11bf828: fcmp            d0, d1
    // 0x11bf82c: b.le            #0x11bf838
    // 0x11bf830: d0 = 0.000000
    //     0x11bf830: eor             v0.16b, v0.16b, v0.16b
    // 0x11bf834: b               #0x11bf860
    // 0x11bf838: d0 = 1.000000
    //     0x11bf838: fmov            d0, #1.00000000
    // 0x11bf83c: fcmp            d1, d0
    // 0x11bf840: b.le            #0x11bf84c
    // 0x11bf844: d0 = 1.000000
    //     0x11bf844: fmov            d0, #1.00000000
    // 0x11bf848: b               #0x11bf860
    // 0x11bf84c: fcmp            d1, d1
    // 0x11bf850: b.vc            #0x11bf85c
    // 0x11bf854: d0 = 1.000000
    //     0x11bf854: fmov            d0, #1.00000000
    // 0x11bf858: b               #0x11bf860
    // 0x11bf85c: mov             v0.16b, v1.16b
    // 0x11bf860: LoadField: r19 = r1->field_5f
    //     0x11bf860: ldur            x19, [x1, #0x5f]
    // 0x11bf864: scvtf           d1, x19
    // 0x11bf868: stur            d1, [fp, #-8]
    // 0x11bf86c: fmul            d2, d0, d1
    // 0x11bf870: mov             v0.16b, v2.16b
    // 0x11bf874: stp             fp, lr, [SP, #-0x10]!
    // 0x11bf878: mov             fp, SP
    // 0x11bf87c: CallRuntime_LibcRound(double) -> double
    //     0x11bf87c: and             SP, SP, #0xfffffffffffffff0
    //     0x11bf880: mov             sp, SP
    //     0x11bf884: ldr             x16, [THR, #0x770]  ; THR::LibcRound
    //     0x11bf888: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x11bf88c: blr             x16
    //     0x11bf890: mov             x16, #8
    //     0x11bf894: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x11bf898: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x11bf89c: sub             sp, x16, #1, lsl #12
    //     0x11bf8a0: mov             SP, fp
    //     0x11bf8a4: ldp             fp, lr, [SP], #0x10
    // 0x11bf8a8: fcmp            d0, d0
    // 0x11bf8ac: b.vs            #0x11bf8e8
    // 0x11bf8b0: fcvtzs          x0, d0
    // 0x11bf8b4: asr             x16, x0, #0x1e
    // 0x11bf8b8: cmp             x16, x0, asr #63
    // 0x11bf8bc: b.ne            #0x11bf8e8
    // 0x11bf8c0: lsl             x0, x0, #1
    // 0x11bf8c4: r1 = LoadInt32Instr(r0)
    //     0x11bf8c4: sbfx            x1, x0, #1, #0x1f
    //     0x11bf8c8: tbz             w0, #0, #0x11bf8d0
    //     0x11bf8cc: ldur            x1, [x0, #7]
    // 0x11bf8d0: scvtf           d1, x1
    // 0x11bf8d4: ldur            d2, [fp, #-8]
    // 0x11bf8d8: fdiv            d0, d1, d2
    // 0x11bf8dc: LeaveFrame
    //     0x11bf8dc: mov             SP, fp
    //     0x11bf8e0: ldp             fp, lr, [SP], #0x10
    // 0x11bf8e4: ret
    //     0x11bf8e4: ret             
    // 0x11bf8e8: SaveReg d0
    //     0x11bf8e8: str             q0, [SP, #-0x10]!
    // 0x11bf8ec: r0 = 76
    //     0x11bf8ec: mov             x0, #0x4c
    // 0x11bf8f0: r30 = DoubleToIntegerStub
    //     0x11bf8f0: ldr             lr, [PP, #0x1b70]  ; [pp+0x1b70] Stub: DoubleToInteger (0x7d18e4)
    // 0x11bf8f4: LoadField: r30 = r30->field_7
    //     0x11bf8f4: ldur            lr, [lr, #7]
    // 0x11bf8f8: blr             lr
    // 0x11bf8fc: RestoreReg d0
    //     0x11bf8fc: ldr             q0, [SP], #0x10
    // 0x11bf900: b               #0x11bf8c4
  }
  [closure] void _handleDragStart(dynamic, DragStartDetails) {
    // ** addr: 0x11bf904, size: 0x40
    // 0x11bf904: EnterFrame
    //     0x11bf904: stp             fp, lr, [SP, #-0x10]!
    //     0x11bf908: mov             fp, SP
    // 0x11bf90c: ldr             x0, [fp, #0x18]
    // 0x11bf910: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x11bf910: ldur            w1, [x0, #0x17]
    // 0x11bf914: DecompressPointer r1
    //     0x11bf914: add             x1, x1, HEAP, lsl #32
    // 0x11bf918: CheckStackOverflow
    //     0x11bf918: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11bf91c: cmp             SP, x16
    //     0x11bf920: b.ls            #0x11bf93c
    // 0x11bf924: ldr             x2, [fp, #0x10]
    // 0x11bf928: r0 = _startInteraction()
    //     0x11bf928: bl              #0x11bf944  ; [package:flutter/src/cupertino/slider.dart] _RenderCupertinoSlider::_startInteraction
    // 0x11bf92c: r0 = Null
    //     0x11bf92c: mov             x0, NULL
    // 0x11bf930: LeaveFrame
    //     0x11bf930: mov             SP, fp
    //     0x11bf934: ldp             fp, lr, [SP], #0x10
    // 0x11bf938: ret
    //     0x11bf938: ret             
    // 0x11bf93c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11bf93c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11bf940: b               #0x11bf924
  }
  _ _startInteraction(/* No info */) {
    // ** addr: 0x11bf944, size: 0xc8
    // 0x11bf944: EnterFrame
    //     0x11bf944: stp             fp, lr, [SP, #-0x10]!
    //     0x11bf948: mov             fp, SP
    // 0x11bf94c: AllocStack(0x8)
    //     0x11bf94c: sub             SP, SP, #8
    // 0x11bf950: CheckStackOverflow
    //     0x11bf950: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11bf954: cmp             SP, x16
    //     0x11bf958: b.ls            #0x11bf9e8
    // 0x11bf95c: LoadField: d0 = r1->field_57
    //     0x11bf95c: ldur            d0, [x1, #0x57]
    // 0x11bf960: StoreField: r1->field_8b = d0
    //     0x11bf960: stur            d0, [x1, #0x8b]
    // 0x11bf964: LoadField: r0 = r2->field_f
    //     0x11bf964: ldur            w0, [x2, #0xf]
    // 0x11bf968: DecompressPointer r0
    //     0x11bf968: add             x0, x0, HEAP, lsl #32
    // 0x11bf96c: StoreField: r1->field_93 = r0
    //     0x11bf96c: stur            w0, [x1, #0x93]
    //     0x11bf970: ldurb           w16, [x1, #-1]
    //     0x11bf974: ldurb           w17, [x0, #-1]
    //     0x11bf978: and             x16, x17, x16, lsr #2
    //     0x11bf97c: tst             x16, HEAP, lsr #32
    //     0x11bf980: b.eq            #0x11bf988
    //     0x11bf984: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11bf988: LoadField: r0 = r1->field_73
    //     0x11bf988: ldur            w0, [x1, #0x73]
    // 0x11bf98c: DecompressPointer r0
    //     0x11bf98c: add             x0, x0, HEAP, lsl #32
    // 0x11bf990: stur            x0, [fp, #-8]
    // 0x11bf994: r0 = _discretizedCurrentDragValue()
    //     0x11bf994: bl              #0x11bf814  ; [package:flutter/src/cupertino/slider.dart] _RenderCupertinoSlider::_discretizedCurrentDragValue
    // 0x11bf998: ldur            x0, [fp, #-8]
    // 0x11bf99c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x11bf99c: ldur            w1, [x0, #0x17]
    // 0x11bf9a0: DecompressPointer r1
    //     0x11bf9a0: add             x1, x1, HEAP, lsl #32
    // 0x11bf9a4: r2 = inline_Allocate_Double()
    //     0x11bf9a4: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0x11bf9a8: add             x2, x2, #0x10
    //     0x11bf9ac: cmp             x0, x2
    //     0x11bf9b0: b.ls            #0x11bf9f0
    //     0x11bf9b4: str             x2, [THR, #0x60]  ; THR::top
    //     0x11bf9b8: sub             x2, x2, #0xf
    //     0x11bf9bc: mov             x0, #0xe19c
    //     0x11bf9c0: movk            x0, #3, lsl #16
    //     0x11bf9c4: stur            x0, [x2, #-1]
    // 0x11bf9c8: dmb             ishst
    // 0x11bf9cc: StoreField: r2->field_7 = d0
    //     0x11bf9cc: stur            d0, [x2, #7]
    // 0x11bf9d0: r3 = false
    //     0x11bf9d0: add             x3, NULL, #0x30  ; false
    // 0x11bf9d4: r0 = _handleChanged()
    //     0x11bf9d4: bl              #0xbf53c4  ; [package:flutter/src/cupertino/slider.dart] _CupertinoSliderState::_handleChanged
    // 0x11bf9d8: r0 = Null
    //     0x11bf9d8: mov             x0, NULL
    // 0x11bf9dc: LeaveFrame
    //     0x11bf9dc: mov             SP, fp
    //     0x11bf9e0: ldp             fp, lr, [SP], #0x10
    // 0x11bf9e4: ret
    //     0x11bf9e4: ret             
    // 0x11bf9e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11bf9e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11bf9ec: b               #0x11bf95c
    // 0x11bf9f0: SaveReg d0
    //     0x11bf9f0: str             q0, [SP, #-0x10]!
    // 0x11bf9f4: SaveReg r1
    //     0x11bf9f4: str             x1, [SP, #-8]!
    // 0x11bf9f8: r0 = AllocateDouble()
    //     0x11bf9f8: bl              #0x13df878  ; AllocateDoubleStub
    // 0x11bf9fc: mov             x2, x0
    // 0x11bfa00: RestoreReg r1
    //     0x11bfa00: ldr             x1, [SP], #8
    // 0x11bfa04: RestoreReg d0
    //     0x11bfa04: ldr             q0, [SP], #0x10
    // 0x11bfa08: b               #0x11bf9cc
  }
}

// class id: 5601, size: 0x1c, field offset: 0x1c
class _CupertinoSliderState extends _MixinApplication406&State&TickerProviderStateMixin {

  [closure] void _handleChanged(dynamic, double, bool) {
    // ** addr: 0xbf5384, size: 0x40
    // 0xbf5384: EnterFrame
    //     0xbf5384: stp             fp, lr, [SP, #-0x10]!
    //     0xbf5388: mov             fp, SP
    // 0xbf538c: ldr             x0, [fp, #0x20]
    // 0xbf5390: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbf5390: ldur            w1, [x0, #0x17]
    // 0xbf5394: DecompressPointer r1
    //     0xbf5394: add             x1, x1, HEAP, lsl #32
    // 0xbf5398: CheckStackOverflow
    //     0xbf5398: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf539c: cmp             SP, x16
    //     0xbf53a0: b.ls            #0xbf53bc
    // 0xbf53a4: ldr             x2, [fp, #0x18]
    // 0xbf53a8: ldr             x3, [fp, #0x10]
    // 0xbf53ac: r0 = _handleChanged()
    //     0xbf53ac: bl              #0xbf53c4  ; [package:flutter/src/cupertino/slider.dart] _CupertinoSliderState::_handleChanged
    // 0xbf53b0: LeaveFrame
    //     0xbf53b0: mov             SP, fp
    //     0xbf53b4: ldp             fp, lr, [SP], #0x10
    // 0xbf53b8: ret
    //     0xbf53b8: ret             
    // 0xbf53bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf53bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf53c0: b               #0xbf53a4
  }
  _ _handleChanged(/* No info */) {
    // ** addr: 0xbf53c4, size: 0xf8
    // 0xbf53c4: EnterFrame
    //     0xbf53c4: stp             fp, lr, [SP, #-0x10]!
    //     0xbf53c8: mov             fp, SP
    // 0xbf53cc: AllocStack(0x18)
    //     0xbf53cc: sub             SP, SP, #0x18
    // 0xbf53d0: SetupParameters(_CupertinoSliderState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0 */)
    //     0xbf53d0: mov             x4, x1
    //     0xbf53d4: mov             x0, x2
    //     0xbf53d8: stur            x1, [fp, #-8]
    // 0xbf53dc: CheckStackOverflow
    //     0xbf53dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf53e0: cmp             SP, x16
    //     0xbf53e4: b.ls            #0xbf548c
    // 0xbf53e8: LoadField: r1 = r4->field_b
    //     0xbf53e8: ldur            w1, [x4, #0xb]
    // 0xbf53ec: DecompressPointer r1
    //     0xbf53ec: add             x1, x1, HEAP, lsl #32
    // 0xbf53f0: cmp             w1, NULL
    // 0xbf53f4: b.eq            #0xbf5494
    // 0xbf53f8: LoadField: d0 = r1->field_27
    //     0xbf53f8: ldur            d0, [x1, #0x27]
    // 0xbf53fc: r2 = inline_Allocate_Double()
    //     0xbf53fc: ldp             x2, x1, [THR, #0x60]  ; THR::top
    //     0xbf5400: add             x2, x2, #0x10
    //     0xbf5404: cmp             x1, x2
    //     0xbf5408: b.ls            #0xbf5498
    //     0xbf540c: str             x2, [THR, #0x60]  ; THR::top
    //     0xbf5410: sub             x2, x2, #0xf
    //     0xbf5414: mov             x1, #0xe19c
    //     0xbf5418: movk            x1, #3, lsl #16
    //     0xbf541c: stur            x1, [x2, #-1]
    // 0xbf5420: dmb             ishst
    // 0xbf5424: StoreField: r2->field_7 = d0
    //     0xbf5424: stur            d0, [x2, #7]
    // 0xbf5428: mov             x3, x0
    // 0xbf542c: r1 = 0.000000
    //     0xbf542c: ldr             x1, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xbf5430: r0 = lerpDouble()
    //     0xbf5430: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0xbf5434: mov             x1, x0
    // 0xbf5438: ldur            x0, [fp, #-8]
    // 0xbf543c: LoadField: r2 = r0->field_b
    //     0xbf543c: ldur            w2, [x0, #0xb]
    // 0xbf5440: DecompressPointer r2
    //     0xbf5440: add             x2, x2, HEAP, lsl #32
    // 0xbf5444: cmp             w2, NULL
    // 0xbf5448: b.eq            #0xbf54b4
    // 0xbf544c: LoadField: d0 = r1->field_7
    //     0xbf544c: ldur            d0, [x1, #7]
    // 0xbf5450: LoadField: d1 = r2->field_b
    //     0xbf5450: ldur            d1, [x2, #0xb]
    // 0xbf5454: fcmp            d0, d1
    // 0xbf5458: b.eq            #0xbf547c
    // 0xbf545c: LoadField: r0 = r2->field_13
    //     0xbf545c: ldur            w0, [x2, #0x13]
    // 0xbf5460: DecompressPointer r0
    //     0xbf5460: add             x0, x0, HEAP, lsl #32
    // 0xbf5464: cmp             w0, NULL
    // 0xbf5468: b.eq            #0xbf54b8
    // 0xbf546c: stp             x1, x0, [SP]
    // 0xbf5470: ClosureCall
    //     0xbf5470: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xbf5474: ldur            x2, [x0, #0x1f]
    //     0xbf5478: blr             x2
    // 0xbf547c: r0 = Null
    //     0xbf547c: mov             x0, NULL
    // 0xbf5480: LeaveFrame
    //     0xbf5480: mov             SP, fp
    //     0xbf5484: ldp             fp, lr, [SP], #0x10
    // 0xbf5488: ret
    //     0xbf5488: ret             
    // 0xbf548c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf548c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf5490: b               #0xbf53e8
    // 0xbf5494: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf5494: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf5498: SaveReg d0
    //     0xbf5498: str             q0, [SP, #-0x10]!
    // 0xbf549c: stp             x0, x4, [SP, #-0x10]!
    // 0xbf54a0: r0 = AllocateDouble()
    //     0xbf54a0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbf54a4: mov             x2, x0
    // 0xbf54a8: ldp             x0, x4, [SP], #0x10
    // 0xbf54ac: RestoreReg d0
    //     0xbf54ac: ldr             q0, [SP], #0x10
    // 0xbf54b0: b               #0xbf5424
    // 0xbf54b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf54b4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf54b8: r0 = NullErrorSharedWithoutFPURegs()
    //     0xbf54b8: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ build(/* No info */) {
    // ** addr: 0xd76fd4, size: 0x15c
    // 0xd76fd4: EnterFrame
    //     0xd76fd4: stp             fp, lr, [SP, #-0x10]!
    //     0xd76fd8: mov             fp, SP
    // 0xd76fdc: AllocStack(0x28)
    //     0xd76fdc: sub             SP, SP, #0x28
    // 0xd76fe0: d0 = 0.000000
    //     0xd76fe0: eor             v0.16b, v0.16b, v0.16b
    // 0xd76fe4: mov             x0, x2
    // 0xd76fe8: stur            x2, [fp, #-0x18]
    // 0xd76fec: mov             x2, x1
    // 0xd76ff0: stur            x1, [fp, #-0x10]
    // 0xd76ff4: CheckStackOverflow
    //     0xd76ff4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd76ff8: cmp             SP, x16
    //     0xd76ffc: b.ls            #0xd77120
    // 0xd77000: LoadField: r1 = r2->field_b
    //     0xd77000: ldur            w1, [x2, #0xb]
    // 0xd77004: DecompressPointer r1
    //     0xd77004: add             x1, x1, HEAP, lsl #32
    // 0xd77008: cmp             w1, NULL
    // 0xd7700c: b.eq            #0xd77128
    // 0xd77010: LoadField: d1 = r1->field_b
    //     0xd77010: ldur            d1, [x1, #0xb]
    // 0xd77014: fsub            d2, d1, d0
    // 0xd77018: LoadField: d1 = r1->field_27
    //     0xd77018: ldur            d1, [x1, #0x27]
    // 0xd7701c: fsub            d3, d1, d0
    // 0xd77020: fdiv            d0, d2, d3
    // 0xd77024: stur            d0, [fp, #-0x28]
    // 0xd77028: LoadField: r3 = r1->field_2f
    //     0xd77028: ldur            x3, [x1, #0x2f]
    // 0xd7702c: stur            x3, [fp, #-8]
    // 0xd77030: LoadField: r4 = r1->field_37
    //     0xd77030: ldur            w4, [x1, #0x37]
    // 0xd77034: DecompressPointer r4
    //     0xd77034: add             x4, x4, HEAP, lsl #32
    // 0xd77038: cmp             w4, NULL
    // 0xd7703c: b.ne            #0xd77094
    // 0xd77040: mov             x1, x0
    // 0xd77044: r0 = of()
    //     0xd77044: bl              #0xccc364  ; [package:flutter/src/cupertino/theme.dart] CupertinoTheme::of
    // 0xd77048: r1 = LoadClassIdInstr(r0)
    //     0xd77048: ldur            x1, [x0, #-1]
    //     0xd7704c: ubfx            x1, x1, #0xc, #0x14
    // 0xd77050: r17 = 4617
    //     0xd77050: mov             x17, #0x1209
    // 0xd77054: cmp             x1, x17
    // 0xd77058: b.ne            #0xd77070
    // 0xd7705c: LoadField: r1 = r0->field_27
    //     0xd7705c: ldur            w1, [x0, #0x27]
    // 0xd77060: DecompressPointer r1
    //     0xd77060: add             x1, x1, HEAP, lsl #32
    // 0xd77064: LoadField: r0 = r1->field_b
    //     0xd77064: ldur            w0, [x1, #0xb]
    // 0xd77068: DecompressPointer r0
    //     0xd77068: add             x0, x0, HEAP, lsl #32
    // 0xd7706c: b               #0xd7708c
    // 0xd77070: LoadField: r1 = r0->field_2b
    //     0xd77070: ldur            w1, [x0, #0x2b]
    // 0xd77074: DecompressPointer r1
    //     0xd77074: add             x1, x1, HEAP, lsl #32
    // 0xd77078: LoadField: r0 = r1->field_3f
    //     0xd77078: ldur            w0, [x1, #0x3f]
    // 0xd7707c: DecompressPointer r0
    //     0xd7707c: add             x0, x0, HEAP, lsl #32
    // 0xd77080: LoadField: r1 = r0->field_b
    //     0xd77080: ldur            w1, [x0, #0xb]
    // 0xd77084: DecompressPointer r1
    //     0xd77084: add             x1, x1, HEAP, lsl #32
    // 0xd77088: mov             x0, x1
    // 0xd7708c: mov             x1, x0
    // 0xd77090: b               #0xd77098
    // 0xd77094: mov             x1, x4
    // 0xd77098: ldur            x0, [fp, #-0x10]
    // 0xd7709c: ldur            d0, [fp, #-0x28]
    // 0xd770a0: ldur            x3, [fp, #-8]
    // 0xd770a4: ldur            x2, [fp, #-0x18]
    // 0xd770a8: r0 = resolve()
    //     0xd770a8: bl              #0xce150c  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolve
    // 0xd770ac: ldur            x2, [fp, #-0x10]
    // 0xd770b0: stur            x0, [fp, #-0x18]
    // 0xd770b4: LoadField: r1 = r2->field_b
    //     0xd770b4: ldur            w1, [x2, #0xb]
    // 0xd770b8: DecompressPointer r1
    //     0xd770b8: add             x1, x1, HEAP, lsl #32
    // 0xd770bc: cmp             w1, NULL
    // 0xd770c0: b.eq            #0xd7712c
    // 0xd770c4: r0 = _CupertinoSliderRenderObjectWidget()
    //     0xd770c4: bl              #0xd77130  ; Allocate_CupertinoSliderRenderObjectWidgetStub -> _CupertinoSliderRenderObjectWidget (size=0x34)
    // 0xd770c8: ldur            d0, [fp, #-0x28]
    // 0xd770cc: stur            x0, [fp, #-0x20]
    // 0xd770d0: StoreField: r0->field_b = d0
    //     0xd770d0: stur            d0, [x0, #0xb]
    // 0xd770d4: ldur            x1, [fp, #-8]
    // 0xd770d8: StoreField: r0->field_13 = r1
    //     0xd770d8: stur            x1, [x0, #0x13]
    // 0xd770dc: ldur            x1, [fp, #-0x18]
    // 0xd770e0: StoreField: r0->field_1b = r1
    //     0xd770e0: stur            w1, [x0, #0x1b]
    // 0xd770e4: r1 = Instance_Color
    //     0xd770e4: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0xd770e8: ldr             x1, [x1, #0xc38]
    // 0xd770ec: StoreField: r0->field_1f = r1
    //     0xd770ec: stur            w1, [x0, #0x1f]
    // 0xd770f0: ldur            x2, [fp, #-0x10]
    // 0xd770f4: r1 = Function '_handleChanged@296348729':.
    //     0xd770f4: add             x1, PP, #0xac, lsl #12  ; [pp+0xacc50] AnonymousClosure: (0xbf5384), in [package:flutter/src/cupertino/slider.dart] _CupertinoSliderState::_handleChanged (0xbf53c4)
    //     0xd770f8: ldr             x1, [x1, #0xc50]
    // 0xd770fc: r0 = AllocateClosure()
    //     0xd770fc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd77100: mov             x1, x0
    // 0xd77104: ldur            x0, [fp, #-0x20]
    // 0xd77108: StoreField: r0->field_23 = r1
    //     0xd77108: stur            w1, [x0, #0x23]
    // 0xd7710c: ldur            x1, [fp, #-0x10]
    // 0xd77110: StoreField: r0->field_2f = r1
    //     0xd77110: stur            w1, [x0, #0x2f]
    // 0xd77114: LeaveFrame
    //     0xd77114: mov             SP, fp
    //     0xd77118: ldp             fp, lr, [SP], #0x10
    // 0xd7711c: ret
    //     0xd7711c: ret             
    // 0xd77120: r0 = StackOverflowSharedWithFPURegs()
    //     0xd77120: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xd77124: b               #0xd77000
    // 0xd77128: r0 = NullCastErrorSharedWithFPURegs()
    //     0xd77128: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xd7712c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd7712c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 6509, size: 0x40, field offset: 0xc
//   const constructor, 
class CupertinoSlider extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa095c, size: 0x24
    // 0xfa095c: EnterFrame
    //     0xfa095c: stp             fp, lr, [SP, #-0x10]!
    //     0xfa0960: mov             fp, SP
    // 0xfa0964: mov             x0, x1
    // 0xfa0968: r1 = <CupertinoSlider>
    //     0xfa0968: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2aa8] TypeArguments: <CupertinoSlider>
    //     0xfa096c: ldr             x1, [x1, #0xaa8]
    // 0xfa0970: r0 = _CupertinoSliderState()
    //     0xfa0970: bl              #0xfa0980  ; Allocate_CupertinoSliderStateStub -> _CupertinoSliderState (size=0x1c)
    // 0xfa0974: LeaveFrame
    //     0xfa0974: mov             SP, fp
    //     0xfa0978: ldp             fp, lr, [SP], #0x10
    // 0xfa097c: ret
    //     0xfa097c: ret             
  }
}

// class id: 6731, size: 0x34, field offset: 0xc
//   const constructor, 
class _CupertinoSliderRenderObjectWidget extends LeafRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xce13b0, size: 0x15c
    // 0xce13b0: EnterFrame
    //     0xce13b0: stp             fp, lr, [SP, #-0x10]!
    //     0xce13b4: mov             fp, SP
    // 0xce13b8: AllocStack(0x18)
    //     0xce13b8: sub             SP, SP, #0x18
    // 0xce13bc: SetupParameters(_CupertinoSliderRenderObjectWidget this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xce13bc: mov             x5, x1
    //     0xce13c0: mov             x4, x2
    //     0xce13c4: stur            x1, [fp, #-8]
    //     0xce13c8: stur            x2, [fp, #-0x10]
    //     0xce13cc: stur            x3, [fp, #-0x18]
    // 0xce13d0: CheckStackOverflow
    //     0xce13d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce13d4: cmp             SP, x16
    //     0xce13d8: b.ls            #0xce14e8
    // 0xce13dc: mov             x0, x3
    // 0xce13e0: r2 = Null
    //     0xce13e0: mov             x2, NULL
    // 0xce13e4: r1 = Null
    //     0xce13e4: mov             x1, NULL
    // 0xce13e8: r4 = 60
    //     0xce13e8: mov             x4, #0x3c
    // 0xce13ec: branchIfSmi(r0, 0xce13f8)
    //     0xce13ec: tbz             w0, #0, #0xce13f8
    // 0xce13f0: r4 = LoadClassIdInstr(r0)
    //     0xce13f0: ldur            x4, [x0, #-1]
    //     0xce13f4: ubfx            x4, x4, #0xc, #0x14
    // 0xce13f8: r17 = 4962
    //     0xce13f8: mov             x17, #0x1362
    // 0xce13fc: cmp             x4, x17
    // 0xce1400: b.eq            #0xce1418
    // 0xce1404: r8 = _RenderCupertinoSlider
    //     0xce1404: add             x8, PP, #0xcc, lsl #12  ; [pp+0xcc848] Type: _RenderCupertinoSlider
    //     0xce1408: ldr             x8, [x8, #0x848]
    // 0xce140c: r3 = Null
    //     0xce140c: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcc850] Null
    //     0xce1410: ldr             x3, [x3, #0x850]
    // 0xce1414: r0 = DefaultTypeTest()
    //     0xce1414: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xce1418: ldur            x0, [fp, #-8]
    // 0xce141c: LoadField: d0 = r0->field_b
    //     0xce141c: ldur            d0, [x0, #0xb]
    // 0xce1420: r2 = inline_Allocate_Double()
    //     0xce1420: ldp             x2, x1, [THR, #0x60]  ; THR::top
    //     0xce1424: add             x2, x2, #0x10
    //     0xce1428: cmp             x1, x2
    //     0xce142c: b.ls            #0xce14f0
    //     0xce1430: str             x2, [THR, #0x60]  ; THR::top
    //     0xce1434: sub             x2, x2, #0xf
    //     0xce1438: mov             x1, #0xe19c
    //     0xce143c: movk            x1, #3, lsl #16
    //     0xce1440: stur            x1, [x2, #-1]
    // 0xce1444: dmb             ishst
    // 0xce1448: StoreField: r2->field_7 = d0
    //     0xce1448: stur            d0, [x2, #7]
    // 0xce144c: ldur            x1, [fp, #-0x18]
    // 0xce1450: r0 = value=()
    //     0xce1450: bl              #0xb5cfc0  ; [package:flutter/src/cupertino/slider.dart] _RenderCupertinoSlider::value=
    // 0xce1454: ldur            x0, [fp, #-8]
    // 0xce1458: LoadField: r2 = r0->field_13
    //     0xce1458: ldur            x2, [x0, #0x13]
    // 0xce145c: ldur            x1, [fp, #-0x18]
    // 0xce1460: r0 = divisions=()
    //     0xce1460: bl              #0xce25c8  ; [package:flutter/src/cupertino/slider.dart] _RenderCupertinoSlider::divisions=
    // 0xce1464: ldur            x0, [fp, #-8]
    // 0xce1468: LoadField: r2 = r0->field_1b
    //     0xce1468: ldur            w2, [x0, #0x1b]
    // 0xce146c: DecompressPointer r2
    //     0xce146c: add             x2, x2, HEAP, lsl #32
    // 0xce1470: ldur            x1, [fp, #-0x18]
    // 0xce1474: r0 = activeColor=()
    //     0xce1474: bl              #0xce2524  ; [package:flutter/src/cupertino/slider.dart] _RenderCupertinoSlider::activeColor=
    // 0xce1478: ldur            x1, [fp, #-0x18]
    // 0xce147c: r2 = Instance_Color
    //     0xce147c: add             x2, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0xce1480: ldr             x2, [x2, #0xc38]
    // 0xce1484: r0 = thumbColor=()
    //     0xce1484: bl              #0xce24b0  ; [package:flutter/src/cupertino/slider.dart] _RenderCupertinoSlider::thumbColor=
    // 0xce1488: ldur            x2, [fp, #-0x10]
    // 0xce148c: r1 = Instance_CupertinoDynamicColor
    //     0xce148c: add             x1, PP, #0xcc, lsl #12  ; [pp+0xcc860] Obj!CupertinoDynamicColor@12b3831
    //     0xce1490: ldr             x1, [x1, #0x860]
    // 0xce1494: r0 = resolveFrom()
    //     0xce1494: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0xce1498: ldur            x1, [fp, #-0x18]
    // 0xce149c: mov             x2, x0
    // 0xce14a0: r0 = trackColor=()
    //     0xce14a0: bl              #0xce1648  ; [package:flutter/src/cupertino/slider.dart] _RenderCupertinoSlider::trackColor=
    // 0xce14a4: ldur            x0, [fp, #-8]
    // 0xce14a8: LoadField: r2 = r0->field_23
    //     0xce14a8: ldur            w2, [x0, #0x23]
    // 0xce14ac: DecompressPointer r2
    //     0xce14ac: add             x2, x2, HEAP, lsl #32
    // 0xce14b0: ldur            x1, [fp, #-0x18]
    // 0xce14b4: r0 = onChanged=()
    //     0xce14b4: bl              #0xce15c4  ; [package:flutter/src/cupertino/slider.dart] _RenderCupertinoSlider::onChanged=
    // 0xce14b8: ldur            x0, [fp, #-0x18]
    // 0xce14bc: StoreField: r0->field_77 = rNULL
    //     0xce14bc: stur            NULL, [x0, #0x77]
    // 0xce14c0: StoreField: r0->field_7b = rNULL
    //     0xce14c0: stur            NULL, [x0, #0x7b]
    // 0xce14c4: ldur            x1, [fp, #-0x10]
    // 0xce14c8: r0 = of()
    //     0xce14c8: bl              #0x87371c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0xce14cc: ldur            x1, [fp, #-0x18]
    // 0xce14d0: mov             x2, x0
    // 0xce14d4: r0 = textDirection=()
    //     0xce14d4: bl              #0xce1554  ; [package:flutter/src/cupertino/slider.dart] _RenderCupertinoSlider::textDirection=
    // 0xce14d8: r0 = Null
    //     0xce14d8: mov             x0, NULL
    // 0xce14dc: LeaveFrame
    //     0xce14dc: mov             SP, fp
    //     0xce14e0: ldp             fp, lr, [SP], #0x10
    // 0xce14e4: ret
    //     0xce14e4: ret             
    // 0xce14e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce14e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce14ec: b               #0xce13dc
    // 0xce14f0: SaveReg d0
    //     0xce14f0: str             q0, [SP, #-0x10]!
    // 0xce14f4: SaveReg r0
    //     0xce14f4: str             x0, [SP, #-8]!
    // 0xce14f8: r0 = AllocateDouble()
    //     0xce14f8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xce14fc: mov             x2, x0
    // 0xce1500: RestoreReg r0
    //     0xce1500: ldr             x0, [SP], #8
    // 0xce1504: RestoreReg d0
    //     0xce1504: ldr             q0, [SP], #0x10
    // 0xce1508: b               #0xce1448
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11bf1cc, size: 0xcc
    // 0x11bf1cc: EnterFrame
    //     0x11bf1cc: stp             fp, lr, [SP, #-0x10]!
    //     0x11bf1d0: mov             fp, SP
    // 0x11bf1d4: AllocStack(0x48)
    //     0x11bf1d4: sub             SP, SP, #0x48
    // 0x11bf1d8: SetupParameters(_CupertinoSliderRenderObjectWidget this /* r1 => r3, fp-0x18 */, dynamic _ /* r2 => r0, fp-0x20 */)
    //     0x11bf1d8: mov             x3, x1
    //     0x11bf1dc: mov             x0, x2
    //     0x11bf1e0: stur            x1, [fp, #-0x18]
    //     0x11bf1e4: stur            x2, [fp, #-0x20]
    // 0x11bf1e8: CheckStackOverflow
    //     0x11bf1e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11bf1ec: cmp             SP, x16
    //     0x11bf1f0: b.ls            #0x11bf290
    // 0x11bf1f4: LoadField: d0 = r3->field_b
    //     0x11bf1f4: ldur            d0, [x3, #0xb]
    // 0x11bf1f8: stur            d0, [fp, #-0x40]
    // 0x11bf1fc: LoadField: r4 = r3->field_13
    //     0x11bf1fc: ldur            x4, [x3, #0x13]
    // 0x11bf200: stur            x4, [fp, #-0x10]
    // 0x11bf204: LoadField: r5 = r3->field_1b
    //     0x11bf204: ldur            w5, [x3, #0x1b]
    // 0x11bf208: DecompressPointer r5
    //     0x11bf208: add             x5, x5, HEAP, lsl #32
    // 0x11bf20c: mov             x2, x0
    // 0x11bf210: stur            x5, [fp, #-8]
    // 0x11bf214: r1 = Instance_CupertinoDynamicColor
    //     0x11bf214: add             x1, PP, #0xcc, lsl #12  ; [pp+0xcc860] Obj!CupertinoDynamicColor@12b3831
    //     0x11bf218: ldr             x1, [x1, #0x860]
    // 0x11bf21c: r0 = resolveFrom()
    //     0x11bf21c: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0x11bf220: mov             x2, x0
    // 0x11bf224: ldur            x0, [fp, #-0x18]
    // 0x11bf228: stur            x2, [fp, #-0x38]
    // 0x11bf22c: LoadField: r5 = r0->field_23
    //     0x11bf22c: ldur            w5, [x0, #0x23]
    // 0x11bf230: DecompressPointer r5
    //     0x11bf230: add             x5, x5, HEAP, lsl #32
    // 0x11bf234: stur            x5, [fp, #-0x30]
    // 0x11bf238: LoadField: r3 = r0->field_2f
    //     0x11bf238: ldur            w3, [x0, #0x2f]
    // 0x11bf23c: DecompressPointer r3
    //     0x11bf23c: add             x3, x3, HEAP, lsl #32
    // 0x11bf240: ldur            x1, [fp, #-0x20]
    // 0x11bf244: stur            x3, [fp, #-0x28]
    // 0x11bf248: r0 = of()
    //     0x11bf248: bl              #0x87371c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0x11bf24c: stur            x0, [fp, #-0x18]
    // 0x11bf250: r0 = _RenderCupertinoSlider()
    //     0x11bf250: bl              #0x11bfa0c  ; Allocate_RenderCupertinoSliderStub -> _RenderCupertinoSlider (size=0xa4)
    // 0x11bf254: stur            x0, [fp, #-0x20]
    // 0x11bf258: ldur            x16, [fp, #-0x28]
    // 0x11bf25c: str             x16, [SP]
    // 0x11bf260: mov             x1, x0
    // 0x11bf264: ldur            x2, [fp, #-8]
    // 0x11bf268: ldur            x3, [fp, #-0x10]
    // 0x11bf26c: ldur            x5, [fp, #-0x30]
    // 0x11bf270: ldur            x6, [fp, #-0x18]
    // 0x11bf274: ldur            x7, [fp, #-0x38]
    // 0x11bf278: ldur            d0, [fp, #-0x40]
    // 0x11bf27c: r0 = _RenderCupertinoSlider()
    //     0x11bf27c: bl              #0x11bf298  ; [package:flutter/src/cupertino/slider.dart] _RenderCupertinoSlider::_RenderCupertinoSlider
    // 0x11bf280: ldur            x0, [fp, #-0x20]
    // 0x11bf284: LeaveFrame
    //     0x11bf284: mov             SP, fp
    //     0x11bf288: ldp             fp, lr, [SP], #0x10
    // 0x11bf28c: ret
    //     0x11bf28c: ret             
    // 0x11bf290: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11bf290: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11bf294: b               #0x11bf1f4
  }
}
