// lib: , url: package:flutter/src/cupertino/checkbox.dart

// class id: 1048772, size: 0x8
class :: {
}

// class id: 4516, size: 0x78, field offset: 0x60
class _CheckboxPainter extends ToggleablePainter {

  _ paint(/* No info */) {
    // ** addr: 0xb68dcc, size: 0x368
    // 0xb68dcc: EnterFrame
    //     0xb68dcc: stp             fp, lr, [SP, #-0x10]!
    //     0xb68dd0: mov             fp, SP
    // 0xb68dd4: AllocStack(0x48)
    //     0xb68dd4: sub             SP, SP, #0x48
    // 0xb68dd8: SetupParameters(_CheckboxPainter this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r0, fp-0x18 */)
    //     0xb68dd8: mov             x0, x3
    //     0xb68ddc: stur            x3, [fp, #-0x18]
    //     0xb68de0: mov             x3, x1
    //     0xb68de4: stur            x1, [fp, #-8]
    //     0xb68de8: stur            x2, [fp, #-0x10]
    // 0xb68dec: CheckStackOverflow
    //     0xb68dec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb68df0: cmp             SP, x16
    //     0xb68df4: b.ls            #0xb69110
    // 0xb68df8: mov             x1, x3
    // 0xb68dfc: r0 = _createStrokePaint()
    //     0xb68dfc: bl              #0xb6a500  ; [package:flutter/src/cupertino/checkbox.dart] _CheckboxPainter::_createStrokePaint
    // 0xb68e00: ldur            x1, [fp, #-0x18]
    // 0xb68e04: d0 = 2.000000
    //     0xb68e04: fmov            d0, #2.00000000
    // 0xb68e08: stur            x0, [fp, #-0x18]
    // 0xb68e0c: r0 = /()
    //     0xb68e0c: bl              #0x8a6e1c  ; [dart:ui] Size::/
    // 0xb68e10: r1 = Instance_Size
    //     0xb68e10: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2ab0] Obj!Size@12a7551
    //     0xb68e14: ldr             x1, [x1, #0xab0]
    // 0xb68e18: d0 = 2.000000
    //     0xb68e18: fmov            d0, #2.00000000
    // 0xb68e1c: stur            x0, [fp, #-0x20]
    // 0xb68e20: r0 = /()
    //     0xb68e20: bl              #0x8a6e1c  ; [dart:ui] Size::/
    // 0xb68e24: ldur            x1, [fp, #-0x20]
    // 0xb68e28: mov             x2, x0
    // 0xb68e2c: r0 = -()
    //     0xb68e2c: bl              #0x81d2c0  ; [dart:ui] Size::-
    // 0xb68e30: ldur            x1, [fp, #-8]
    // 0xb68e34: mov             x2, x0
    // 0xb68e38: stur            x0, [fp, #-0x20]
    // 0xb68e3c: r0 = _outerRectAt()
    //     0xb68e3c: bl              #0xb6a4a0  ; [package:flutter/src/cupertino/checkbox.dart] _CheckboxPainter::_outerRectAt
    // 0xb68e40: stur            x0, [fp, #-0x28]
    // 0xb68e44: r16 = 136
    //     0xb68e44: mov             x16, #0x88
    // 0xb68e48: stp             x16, NULL, [SP]
    // 0xb68e4c: r0 = ByteData()
    //     0xb68e4c: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xb68e50: stur            x0, [fp, #-0x30]
    // 0xb68e54: r0 = Paint()
    //     0xb68e54: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xb68e58: mov             x3, x0
    // 0xb68e5c: ldur            x0, [fp, #-0x30]
    // 0xb68e60: stur            x3, [fp, #-0x38]
    // 0xb68e64: StoreField: r3->field_7 = r0
    //     0xb68e64: stur            w0, [x3, #7]
    // 0xb68e68: ldur            x0, [fp, #-8]
    // 0xb68e6c: LoadField: r1 = r0->field_63
    //     0xb68e6c: ldur            w1, [x0, #0x63]
    // 0xb68e70: DecompressPointer r1
    //     0xb68e70: add             x1, x1, HEAP, lsl #32
    // 0xb68e74: cmp             w1, NULL
    // 0xb68e78: b.ne            #0xb68e84
    // 0xb68e7c: r2 = true
    //     0xb68e7c: add             x2, NULL, #0x20  ; true
    // 0xb68e80: b               #0xb68e88
    // 0xb68e84: mov             x2, x1
    // 0xb68e88: mov             x1, x0
    // 0xb68e8c: r0 = _colorAt()
    //     0xb68e8c: bl              #0xb6a43c  ; [package:flutter/src/cupertino/checkbox.dart] _CheckboxPainter::_colorAt
    // 0xb68e90: ldur            x1, [fp, #-0x38]
    // 0xb68e94: mov             x2, x0
    // 0xb68e98: r0 = color=()
    //     0xb68e98: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xb68e9c: ldur            x0, [fp, #-8]
    // 0xb68ea0: LoadField: r7 = r0->field_63
    //     0xb68ea0: ldur            w7, [x0, #0x63]
    // 0xb68ea4: DecompressPointer r7
    //     0xb68ea4: add             x7, x7, HEAP, lsl #32
    // 0xb68ea8: r16 = false
    //     0xb68ea8: add             x16, NULL, #0x30  ; false
    // 0xb68eac: cmp             w7, w16
    // 0xb68eb0: b.ne            #0xb68edc
    // 0xb68eb4: LoadField: r6 = r0->field_6f
    //     0xb68eb4: ldur            w6, [x0, #0x6f]
    // 0xb68eb8: DecompressPointer r6
    //     0xb68eb8: add             x6, x6, HEAP, lsl #32
    // 0xb68ebc: cmp             w6, NULL
    // 0xb68ec0: b.eq            #0xb69118
    // 0xb68ec4: mov             x1, x0
    // 0xb68ec8: ldur            x2, [fp, #-0x10]
    // 0xb68ecc: ldur            x3, [fp, #-0x28]
    // 0xb68ed0: ldur            x5, [fp, #-0x38]
    // 0xb68ed4: r0 = _drawBox()
    //     0xb68ed4: bl              #0xb69ec0  ; [package:flutter/src/cupertino/checkbox.dart] _CheckboxPainter::_drawBox
    // 0xb68ed8: b               #0xb68f70
    // 0xb68edc: r16 = true
    //     0xb68edc: add             x16, NULL, #0x20  ; true
    // 0xb68ee0: cmp             w7, w16
    // 0xb68ee4: b.ne            #0xb68f28
    // 0xb68ee8: ldur            x0, [fp, #-8]
    // 0xb68eec: LoadField: r6 = r0->field_6f
    //     0xb68eec: ldur            w6, [x0, #0x6f]
    // 0xb68ef0: DecompressPointer r6
    //     0xb68ef0: add             x6, x6, HEAP, lsl #32
    // 0xb68ef4: cmp             w6, NULL
    // 0xb68ef8: b.eq            #0xb6911c
    // 0xb68efc: mov             x1, x0
    // 0xb68f00: ldur            x2, [fp, #-0x10]
    // 0xb68f04: ldur            x3, [fp, #-0x28]
    // 0xb68f08: ldur            x5, [fp, #-0x38]
    // 0xb68f0c: r0 = _drawBox()
    //     0xb68f0c: bl              #0xb69ec0  ; [package:flutter/src/cupertino/checkbox.dart] _CheckboxPainter::_drawBox
    // 0xb68f10: ldur            x1, [fp, #-8]
    // 0xb68f14: ldur            x2, [fp, #-0x10]
    // 0xb68f18: ldur            x3, [fp, #-0x20]
    // 0xb68f1c: ldur            x5, [fp, #-0x18]
    // 0xb68f20: r0 = _drawCheck()
    //     0xb68f20: bl              #0xb695e0  ; [package:flutter/src/cupertino/checkbox.dart] _CheckboxPainter::_drawCheck
    // 0xb68f24: b               #0xb68f70
    // 0xb68f28: cmp             w7, NULL
    // 0xb68f2c: b.ne            #0xb68f70
    // 0xb68f30: ldur            x0, [fp, #-8]
    // 0xb68f34: LoadField: r6 = r0->field_6f
    //     0xb68f34: ldur            w6, [x0, #0x6f]
    // 0xb68f38: DecompressPointer r6
    //     0xb68f38: add             x6, x6, HEAP, lsl #32
    // 0xb68f3c: cmp             w6, NULL
    // 0xb68f40: b.eq            #0xb69120
    // 0xb68f44: mov             x1, x0
    // 0xb68f48: ldur            x2, [fp, #-0x10]
    // 0xb68f4c: ldur            x3, [fp, #-0x28]
    // 0xb68f50: ldur            x5, [fp, #-0x38]
    // 0xb68f54: r7 = true
    //     0xb68f54: add             x7, NULL, #0x20  ; true
    // 0xb68f58: r0 = _drawBox()
    //     0xb68f58: bl              #0xb69ec0  ; [package:flutter/src/cupertino/checkbox.dart] _CheckboxPainter::_drawBox
    // 0xb68f5c: ldur            x1, [fp, #-8]
    // 0xb68f60: ldur            x2, [fp, #-0x10]
    // 0xb68f64: ldur            x3, [fp, #-0x20]
    // 0xb68f68: ldur            x5, [fp, #-0x18]
    // 0xb68f6c: r0 = _drawDash()
    //     0xb68f6c: bl              #0xb692b0  ; [package:flutter/src/cupertino/checkbox.dart] _CheckboxPainter::_drawDash
    // 0xb68f70: ldur            x1, [fp, #-8]
    // 0xb68f74: LoadField: r0 = r1->field_4f
    //     0xb68f74: ldur            w0, [x1, #0x4f]
    // 0xb68f78: DecompressPointer r0
    //     0xb68f78: add             x0, x0, HEAP, lsl #32
    // 0xb68f7c: cmp             w0, NULL
    // 0xb68f80: b.eq            #0xb69030
    // 0xb68f84: r16 = 136
    //     0xb68f84: mov             x16, #0x88
    // 0xb68f88: stp             x16, NULL, [SP]
    // 0xb68f8c: r0 = ByteData()
    //     0xb68f8c: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xb68f90: stur            x0, [fp, #-0x18]
    // 0xb68f94: r0 = Paint()
    //     0xb68f94: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xb68f98: mov             x2, x0
    // 0xb68f9c: ldur            x0, [fp, #-0x18]
    // 0xb68fa0: stur            x2, [fp, #-0x20]
    // 0xb68fa4: StoreField: r2->field_7 = r0
    //     0xb68fa4: stur            w0, [x2, #7]
    // 0xb68fa8: ldur            x0, [fp, #-8]
    // 0xb68fac: LoadField: r1 = r0->field_73
    //     0xb68fac: ldur            w1, [x0, #0x73]
    // 0xb68fb0: DecompressPointer r1
    //     0xb68fb0: add             x1, x1, HEAP, lsl #32
    // 0xb68fb4: r16 = Instance_Brightness
    //     0xb68fb4: ldr             x16, [PP, #0x6da0]  ; [pp+0x6da0] Obj!Brightness@12c71c1
    // 0xb68fb8: cmp             w1, w16
    // 0xb68fbc: b.ne            #0xb68fdc
    // 0xb68fc0: r1 = Instance_Color
    //     0xb68fc0: add             x1, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0xb68fc4: ldr             x1, [x1, #0x948]
    // 0xb68fc8: d0 = 0.150000
    //     0xb68fc8: add             x17, PP, #0x12, lsl #12  ; [pp+0x12ee8] IMM: double(0.15) from 0x3fc3333333333333
    //     0xb68fcc: ldr             d0, [x17, #0xee8]
    // 0xb68fd0: r0 = withOpacity()
    //     0xb68fd0: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xb68fd4: mov             x2, x0
    // 0xb68fd8: b               #0xb68ff4
    // 0xb68fdc: r1 = Instance_Color
    //     0xb68fdc: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0xb68fe0: ldr             x1, [x1, #0xc38]
    // 0xb68fe4: d0 = 0.150000
    //     0xb68fe4: add             x17, PP, #0x12, lsl #12  ; [pp+0x12ee8] IMM: double(0.15) from 0x3fc3333333333333
    //     0xb68fe8: ldr             d0, [x17, #0xee8]
    // 0xb68fec: r0 = withOpacity()
    //     0xb68fec: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xb68ff0: mov             x2, x0
    // 0xb68ff4: ldur            x0, [fp, #-8]
    // 0xb68ff8: ldur            x1, [fp, #-0x20]
    // 0xb68ffc: r0 = color=()
    //     0xb68ffc: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xb69000: ldur            x0, [fp, #-8]
    // 0xb69004: LoadField: r1 = r0->field_6b
    //     0xb69004: ldur            w1, [x0, #0x6b]
    // 0xb69008: DecompressPointer r1
    //     0xb69008: add             x1, x1, HEAP, lsl #32
    // 0xb6900c: cmp             w1, NULL
    // 0xb69010: b.eq            #0xb69124
    // 0xb69014: ldur            x2, [fp, #-0x10]
    // 0xb69018: ldur            x3, [fp, #-0x28]
    // 0xb6901c: ldur            x5, [fp, #-0x20]
    // 0xb69020: r1 = Instance_RoundedRectangleBorder
    //     0xb69020: add             x1, PP, #0x26, lsl #12  ; [pp+0x26218] Obj!RoundedRectangleBorder@129ec21
    //     0xb69024: ldr             x1, [x1, #0x218]
    // 0xb69028: r4 = const [0, 0x4, 0, 0x4, null]
    //     0xb69028: ldr             x4, [PP, #0xff0]  ; [pp+0xff0] List(5) [0, 0x4, 0, 0x4, Null]
    // 0xb6902c: r0 = paintInterior()
    //     0xb6902c: bl              #0x12ebae0  ; [package:flutter/src/painting/rounded_rectangle_border.dart] RoundedRectangleBorder::paintInterior
    // 0xb69030: ldur            x0, [fp, #-8]
    // 0xb69034: LoadField: r1 = r0->field_53
    //     0xb69034: ldur            w1, [x0, #0x53]
    // 0xb69038: DecompressPointer r1
    //     0xb69038: add             x1, x1, HEAP, lsl #32
    // 0xb6903c: cmp             w1, NULL
    // 0xb69040: b.eq            #0xb69128
    // 0xb69044: tbnz            w1, #4, #0xb69100
    // 0xb69048: ldur            x1, [fp, #-0x28]
    // 0xb6904c: d0 = 1.000000
    //     0xb6904c: fmov            d0, #1.00000000
    // 0xb69050: r0 = inflate()
    //     0xb69050: bl              #0x882f50  ; [dart:ui] Rect::inflate
    // 0xb69054: stur            x0, [fp, #-0x18]
    // 0xb69058: r16 = 136
    //     0xb69058: mov             x16, #0x88
    // 0xb6905c: stp             x16, NULL, [SP]
    // 0xb69060: r0 = ByteData()
    //     0xb69060: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xb69064: stur            x0, [fp, #-0x20]
    // 0xb69068: r0 = Paint()
    //     0xb69068: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xb6906c: mov             x3, x0
    // 0xb69070: ldur            x0, [fp, #-0x20]
    // 0xb69074: stur            x3, [fp, #-0x28]
    // 0xb69078: StoreField: r3->field_7 = r0
    //     0xb69078: stur            w0, [x3, #7]
    // 0xb6907c: ldur            x4, [fp, #-8]
    // 0xb69080: LoadField: r2 = r4->field_47
    //     0xb69080: ldur            w2, [x4, #0x47]
    // 0xb69084: DecompressPointer r2
    //     0xb69084: add             x2, x2, HEAP, lsl #32
    // 0xb69088: cmp             w2, NULL
    // 0xb6908c: b.eq            #0xb6912c
    // 0xb69090: mov             x1, x3
    // 0xb69094: r0 = color=()
    //     0xb69094: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xb69098: ldur            x0, [fp, #-0x20]
    // 0xb6909c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb6909c: ldur            w1, [x0, #0x17]
    // 0xb690a0: DecompressPointer r1
    //     0xb690a0: add             x1, x1, HEAP, lsl #32
    // 0xb690a4: LoadField: r0 = r1->field_7
    //     0xb690a4: ldur            x0, [x1, #7]
    // 0xb690a8: r2 = 1
    //     0xb690a8: mov             x2, #1
    // 0xb690ac: str             w2, [x0, #0x1c]
    // 0xb690b0: LoadField: r0 = r1->field_7
    //     0xb690b0: ldur            x0, [x1, #7]
    // 0xb690b4: d0 = 0.000000
    //     0xb690b4: add             x17, PP, #0xa2, lsl #12  ; [pp+0xa2ab8] IMM: 0x40600000
    //     0xb690b8: ldr             s0, [x17, #0xab8]
    // 0xb690bc: str             s0, [x0, #0x20]
    // 0xb690c0: ldur            x1, [fp, #-8]
    // 0xb690c4: LoadField: r6 = r1->field_6f
    //     0xb690c4: ldur            w6, [x1, #0x6f]
    // 0xb690c8: DecompressPointer r6
    //     0xb690c8: add             x6, x6, HEAP, lsl #32
    // 0xb690cc: cmp             w6, NULL
    // 0xb690d0: b.eq            #0xb69130
    // 0xb690d4: LoadField: r0 = r1->field_63
    //     0xb690d4: ldur            w0, [x1, #0x63]
    // 0xb690d8: DecompressPointer r0
    //     0xb690d8: add             x0, x0, HEAP, lsl #32
    // 0xb690dc: cmp             w0, NULL
    // 0xb690e0: b.ne            #0xb690ec
    // 0xb690e4: r7 = true
    //     0xb690e4: add             x7, NULL, #0x20  ; true
    // 0xb690e8: b               #0xb690f0
    // 0xb690ec: mov             x7, x0
    // 0xb690f0: ldur            x2, [fp, #-0x10]
    // 0xb690f4: ldur            x3, [fp, #-0x18]
    // 0xb690f8: ldur            x5, [fp, #-0x28]
    // 0xb690fc: r0 = _drawBox()
    //     0xb690fc: bl              #0xb69ec0  ; [package:flutter/src/cupertino/checkbox.dart] _CheckboxPainter::_drawBox
    // 0xb69100: r0 = Null
    //     0xb69100: mov             x0, NULL
    // 0xb69104: LeaveFrame
    //     0xb69104: mov             SP, fp
    //     0xb69108: ldp             fp, lr, [SP], #0x10
    // 0xb6910c: ret
    //     0xb6910c: ret             
    // 0xb69110: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb69110: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb69114: b               #0xb68df8
    // 0xb69118: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb69118: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6911c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6911c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb69120: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb69120: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb69124: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb69124: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb69128: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb69128: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6912c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6912c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb69130: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb69130: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  void dyn:set:value(_CheckboxPainter, bool?) {
    // ** addr: 0xb69248, size: 0x80
    // 0xb69248: EnterFrame
    //     0xb69248: stp             fp, lr, [SP, #-0x10]!
    //     0xb6924c: mov             fp, SP
    // 0xb69250: CheckStackOverflow
    //     0xb69250: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb69254: cmp             SP, x16
    //     0xb69258: b.ls            #0xb692a8
    // 0xb6925c: ldr             x0, [fp, #0x10]
    // 0xb69260: r2 = Null
    //     0xb69260: mov             x2, NULL
    // 0xb69264: r1 = Null
    //     0xb69264: mov             x1, NULL
    // 0xb69268: r4 = 60
    //     0xb69268: mov             x4, #0x3c
    // 0xb6926c: branchIfSmi(r0, 0xb69278)
    //     0xb6926c: tbz             w0, #0, #0xb69278
    // 0xb69270: r4 = LoadClassIdInstr(r0)
    //     0xb69270: ldur            x4, [x0, #-1]
    //     0xb69274: ubfx            x4, x4, #0xc, #0x14
    // 0xb69278: cmp             x4, #0x3f
    // 0xb6927c: b.eq            #0xb69290
    // 0xb69280: r8 = bool?
    //     0xb69280: ldr             x8, [PP, #0x5fd0]  ; [pp+0x5fd0] Type: bool?
    // 0xb69284: r3 = Null
    //     0xb69284: add             x3, PP, #0xa2, lsl #12  ; [pp+0xa2af8] Null
    //     0xb69288: ldr             x3, [x3, #0xaf8]
    // 0xb6928c: r0 = bool?()
    //     0xb6928c: bl              #0x7ecd2c  ; IsType_bool?_Stub
    // 0xb69290: ldr             x1, [fp, #0x18]
    // 0xb69294: ldr             x2, [fp, #0x10]
    // 0xb69298: r0 = value=()
    //     0xb69298: bl              #0xb691dc  ; [package:flutter/src/material/checkbox.dart] _CheckboxPainter::value=
    // 0xb6929c: LeaveFrame
    //     0xb6929c: mov             SP, fp
    //     0xb692a0: ldp             fp, lr, [SP], #0x10
    // 0xb692a4: ret
    //     0xb692a4: ret             
    // 0xb692a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb692a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb692ac: b               #0xb6925c
  }
  _ _drawDash(/* No info */) {
    // ** addr: 0xb692b0, size: 0x7c
    // 0xb692b0: EnterFrame
    //     0xb692b0: stp             fp, lr, [SP, #-0x10]!
    //     0xb692b4: mov             fp, SP
    // 0xb692b8: AllocStack(0x18)
    //     0xb692b8: sub             SP, SP, #0x18
    // 0xb692bc: SetupParameters(dynamic _ /* r2 => r3, fp-0x8 */, dynamic _ /* r3 => r0, fp-0x10 */, dynamic _ /* r5 => r5, fp-0x18 */)
    //     0xb692bc: mov             x0, x3
    //     0xb692c0: stur            x3, [fp, #-0x10]
    //     0xb692c4: mov             x3, x2
    //     0xb692c8: stur            x2, [fp, #-8]
    //     0xb692cc: stur            x5, [fp, #-0x18]
    // 0xb692d0: CheckStackOverflow
    //     0xb692d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb692d4: cmp             SP, x16
    //     0xb692d8: b.ls            #0xb69324
    // 0xb692dc: mov             x1, x0
    // 0xb692e0: r2 = Instance_Offset
    //     0xb692e0: add             x2, PP, #0xa2, lsl #12  ; [pp+0xa2ac0] Obj!Offset@12a7c31
    //     0xb692e4: ldr             x2, [x2, #0xac0]
    // 0xb692e8: r0 = +()
    //     0xb692e8: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0xb692ec: ldur            x1, [fp, #-0x10]
    // 0xb692f0: r2 = Instance_Offset
    //     0xb692f0: add             x2, PP, #0xa2, lsl #12  ; [pp+0xa2ac8] Obj!Offset@12a7c11
    //     0xb692f4: ldr             x2, [x2, #0xac8]
    // 0xb692f8: stur            x0, [fp, #-0x10]
    // 0xb692fc: r0 = +()
    //     0xb692fc: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0xb69300: ldur            x1, [fp, #-8]
    // 0xb69304: ldur            x2, [fp, #-0x10]
    // 0xb69308: mov             x3, x0
    // 0xb6930c: ldur            x5, [fp, #-0x18]
    // 0xb69310: r0 = drawLine()
    //     0xb69310: bl              #0xb6932c  ; [dart:ui] _NativeCanvas::drawLine
    // 0xb69314: r0 = Null
    //     0xb69314: mov             x0, NULL
    // 0xb69318: LeaveFrame
    //     0xb69318: mov             SP, fp
    //     0xb6931c: ldp             fp, lr, [SP], #0x10
    // 0xb69320: ret
    //     0xb69320: ret             
    // 0xb69324: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb69324: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb69328: b               #0xb692dc
  }
  _ _drawCheck(/* No info */) {
    // ** addr: 0xb695e0, size: 0x314
    // 0xb695e0: EnterFrame
    //     0xb695e0: stp             fp, lr, [SP, #-0x10]!
    //     0xb695e4: mov             fp, SP
    // 0xb695e8: AllocStack(0x58)
    //     0xb695e8: sub             SP, SP, #0x58
    // 0xb695ec: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */, dynamic _ /* r5 => r5, fp-0x18 */)
    //     0xb695ec: stur            x2, [fp, #-8]
    //     0xb695f0: stur            x3, [fp, #-0x10]
    //     0xb695f4: stur            x5, [fp, #-0x18]
    // 0xb695f8: CheckStackOverflow
    //     0xb695f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb695fc: cmp             SP, x16
    //     0xb69600: b.ls            #0xb698d4
    // 0xb69604: r0 = _NativePath()
    //     0xb69604: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0xb69608: mov             x1, x0
    // 0xb6960c: stur            x0, [fp, #-0x20]
    // 0xb69610: r0 = __constructor$Method$FfiNative()
    //     0xb69610: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0xb69614: ldur            x0, [fp, #-0x10]
    // 0xb69618: LoadField: d0 = r0->field_7
    //     0xb69618: ldur            d0, [x0, #7]
    // 0xb6961c: stur            d0, [fp, #-0x50]
    // 0xb69620: r1 = Instance_Offset
    //     0xb69620: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2ad0] Obj!Offset@12a7c91
    //     0xb69624: ldr             x1, [x1, #0xad0]
    // 0xb69628: LoadField: d1 = r1->field_7
    //     0xb69628: ldur            d1, [x1, #7]
    // 0xb6962c: fadd            d2, d0, d1
    // 0xb69630: stur            d2, [fp, #-0x48]
    // 0xb69634: LoadField: d1 = r0->field_f
    //     0xb69634: ldur            d1, [x0, #0xf]
    // 0xb69638: stur            d1, [fp, #-0x40]
    // 0xb6963c: LoadField: d3 = r1->field_f
    //     0xb6963c: ldur            d3, [x1, #0xf]
    // 0xb69640: fadd            d4, d1, d3
    // 0xb69644: ldur            x0, [fp, #-0x20]
    // 0xb69648: stur            d4, [fp, #-0x38]
    // 0xb6964c: LoadField: r1 = r0->field_7
    //     0xb6964c: ldur            w1, [x0, #7]
    // 0xb69650: DecompressPointer r1
    //     0xb69650: add             x1, x1, HEAP, lsl #32
    // 0xb69654: cmp             w1, NULL
    // 0xb69658: b.eq            #0xb698dc
    // 0xb6965c: LoadField: r2 = r1->field_7
    //     0xb6965c: ldur            x2, [x1, #7]
    // 0xb69660: ldr             x1, [x2]
    // 0xb69664: cbz             x1, #0xb69884
    // 0xb69668: mov             x2, x1
    // 0xb6966c: stur            x2, [fp, #-0x28]
    // 0xb69670: r1 = <Never>
    //     0xb69670: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb69674: r0 = Pointer()
    //     0xb69674: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb69678: mov             x1, x0
    // 0xb6967c: ldur            x0, [fp, #-0x28]
    // 0xb69680: StoreField: r1->field_7 = r0
    //     0xb69680: stur            x0, [x1, #7]
    // 0xb69684: ldur            d0, [fp, #-0x48]
    // 0xb69688: ldur            d1, [fp, #-0x38]
    // 0xb6968c: r0 = _moveTo$Method$FfiNative()
    //     0xb6968c: bl              #0xb69c74  ; [dart:ui] _NativePath::_moveTo$Method$FfiNative
    // 0xb69690: r0 = Instance_Offset
    //     0xb69690: add             x0, PP, #0xa2, lsl #12  ; [pp+0xa2ad8] Obj!Offset@12a7c71
    //     0xb69694: ldr             x0, [x0, #0xad8]
    // 0xb69698: LoadField: d0 = r0->field_7
    //     0xb69698: ldur            d0, [x0, #7]
    // 0xb6969c: ldur            d1, [fp, #-0x50]
    // 0xb696a0: fadd            d2, d1, d0
    // 0xb696a4: stur            d2, [fp, #-0x48]
    // 0xb696a8: LoadField: d0 = r0->field_f
    //     0xb696a8: ldur            d0, [x0, #0xf]
    // 0xb696ac: ldur            d3, [fp, #-0x40]
    // 0xb696b0: fadd            d4, d3, d0
    // 0xb696b4: ldur            x0, [fp, #-0x20]
    // 0xb696b8: stur            d4, [fp, #-0x38]
    // 0xb696bc: LoadField: r1 = r0->field_7
    //     0xb696bc: ldur            w1, [x0, #7]
    // 0xb696c0: DecompressPointer r1
    //     0xb696c0: add             x1, x1, HEAP, lsl #32
    // 0xb696c4: cmp             w1, NULL
    // 0xb696c8: b.eq            #0xb698e0
    // 0xb696cc: LoadField: r2 = r1->field_7
    //     0xb696cc: ldur            x2, [x1, #7]
    // 0xb696d0: ldr             x1, [x2]
    // 0xb696d4: cbz             x1, #0xb69894
    // 0xb696d8: mov             x2, x1
    // 0xb696dc: stur            x2, [fp, #-0x28]
    // 0xb696e0: r1 = <Never>
    //     0xb696e0: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb696e4: r0 = Pointer()
    //     0xb696e4: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb696e8: mov             x1, x0
    // 0xb696ec: ldur            x0, [fp, #-0x28]
    // 0xb696f0: StoreField: r1->field_7 = r0
    //     0xb696f0: stur            x0, [x1, #7]
    // 0xb696f4: ldur            d0, [fp, #-0x48]
    // 0xb696f8: ldur            d1, [fp, #-0x38]
    // 0xb696fc: r0 = _lineTo$Method$FfiNative()
    //     0xb696fc: bl              #0xb69bd0  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0xb69700: ldur            x0, [fp, #-0x20]
    // 0xb69704: LoadField: r1 = r0->field_7
    //     0xb69704: ldur            w1, [x0, #7]
    // 0xb69708: DecompressPointer r1
    //     0xb69708: add             x1, x1, HEAP, lsl #32
    // 0xb6970c: cmp             w1, NULL
    // 0xb69710: b.eq            #0xb698e4
    // 0xb69714: LoadField: r2 = r1->field_7
    //     0xb69714: ldur            x2, [x1, #7]
    // 0xb69718: ldr             x1, [x2]
    // 0xb6971c: cbz             x1, #0xb698a4
    // 0xb69720: ldur            d0, [fp, #-0x50]
    // 0xb69724: ldur            d1, [fp, #-0x40]
    // 0xb69728: mov             x2, x1
    // 0xb6972c: stur            x2, [fp, #-0x28]
    // 0xb69730: r1 = <Never>
    //     0xb69730: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb69734: r0 = Pointer()
    //     0xb69734: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb69738: mov             x1, x0
    // 0xb6973c: ldur            x0, [fp, #-0x28]
    // 0xb69740: StoreField: r1->field_7 = r0
    //     0xb69740: stur            x0, [x1, #7]
    // 0xb69744: ldur            d0, [fp, #-0x48]
    // 0xb69748: ldur            d1, [fp, #-0x38]
    // 0xb6974c: r0 = _moveTo$Method$FfiNative()
    //     0xb6974c: bl              #0xb69c74  ; [dart:ui] _NativePath::_moveTo$Method$FfiNative
    // 0xb69750: r0 = Instance_Offset
    //     0xb69750: add             x0, PP, #0xa2, lsl #12  ; [pp+0xa2ae0] Obj!Offset@12a7c51
    //     0xb69754: ldr             x0, [x0, #0xae0]
    // 0xb69758: LoadField: d0 = r0->field_7
    //     0xb69758: ldur            d0, [x0, #7]
    // 0xb6975c: ldur            d1, [fp, #-0x50]
    // 0xb69760: fadd            d2, d1, d0
    // 0xb69764: stur            d2, [fp, #-0x48]
    // 0xb69768: LoadField: d0 = r0->field_f
    //     0xb69768: ldur            d0, [x0, #0xf]
    // 0xb6976c: ldur            d1, [fp, #-0x40]
    // 0xb69770: fadd            d3, d1, d0
    // 0xb69774: ldur            x0, [fp, #-0x20]
    // 0xb69778: stur            d3, [fp, #-0x38]
    // 0xb6977c: LoadField: r1 = r0->field_7
    //     0xb6977c: ldur            w1, [x0, #7]
    // 0xb69780: DecompressPointer r1
    //     0xb69780: add             x1, x1, HEAP, lsl #32
    // 0xb69784: cmp             w1, NULL
    // 0xb69788: b.eq            #0xb698e8
    // 0xb6978c: LoadField: r2 = r1->field_7
    //     0xb6978c: ldur            x2, [x1, #7]
    // 0xb69790: ldr             x1, [x2]
    // 0xb69794: cbz             x1, #0xb698b4
    // 0xb69798: ldur            x3, [fp, #-8]
    // 0xb6979c: ldur            x2, [fp, #-0x18]
    // 0xb697a0: mov             x4, x1
    // 0xb697a4: stur            x4, [fp, #-0x28]
    // 0xb697a8: r1 = <Never>
    //     0xb697a8: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb697ac: r0 = Pointer()
    //     0xb697ac: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb697b0: mov             x1, x0
    // 0xb697b4: ldur            x0, [fp, #-0x28]
    // 0xb697b8: StoreField: r1->field_7 = r0
    //     0xb697b8: stur            x0, [x1, #7]
    // 0xb697bc: ldur            d0, [fp, #-0x48]
    // 0xb697c0: ldur            d1, [fp, #-0x38]
    // 0xb697c4: r0 = _lineTo$Method$FfiNative()
    //     0xb697c4: bl              #0xb69bd0  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0xb697c8: ldur            x0, [fp, #-0x18]
    // 0xb697cc: LoadField: r3 = r0->field_b
    //     0xb697cc: ldur            w3, [x0, #0xb]
    // 0xb697d0: DecompressPointer r3
    //     0xb697d0: add             x3, x3, HEAP, lsl #32
    // 0xb697d4: stur            x3, [fp, #-0x30]
    // 0xb697d8: LoadField: r5 = r0->field_7
    //     0xb697d8: ldur            w5, [x0, #7]
    // 0xb697dc: DecompressPointer r5
    //     0xb697dc: add             x5, x5, HEAP, lsl #32
    // 0xb697e0: ldur            x0, [fp, #-8]
    // 0xb697e4: stur            x5, [fp, #-0x10]
    // 0xb697e8: LoadField: r1 = r0->field_7
    //     0xb697e8: ldur            w1, [x0, #7]
    // 0xb697ec: DecompressPointer r1
    //     0xb697ec: add             x1, x1, HEAP, lsl #32
    // 0xb697f0: cmp             w1, NULL
    // 0xb697f4: b.eq            #0xb698ec
    // 0xb697f8: LoadField: r2 = r1->field_7
    //     0xb697f8: ldur            x2, [x1, #7]
    // 0xb697fc: ldr             x1, [x2]
    // 0xb69800: cbz             x1, #0xb698c4
    // 0xb69804: ldur            x2, [fp, #-0x20]
    // 0xb69808: mov             x4, x1
    // 0xb6980c: stur            x4, [fp, #-0x28]
    // 0xb69810: r1 = <Never>
    //     0xb69810: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb69814: r0 = Pointer()
    //     0xb69814: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb69818: mov             x2, x0
    // 0xb6981c: ldur            x0, [fp, #-0x28]
    // 0xb69820: stur            x2, [fp, #-0x18]
    // 0xb69824: StoreField: r2->field_7 = r0
    //     0xb69824: stur            x0, [x2, #7]
    // 0xb69828: ldur            x0, [fp, #-0x20]
    // 0xb6982c: LoadField: r1 = r0->field_7
    //     0xb6982c: ldur            w1, [x0, #7]
    // 0xb69830: DecompressPointer r1
    //     0xb69830: add             x1, x1, HEAP, lsl #32
    // 0xb69834: cmp             w1, NULL
    // 0xb69838: b.eq            #0xb698f0
    // 0xb6983c: LoadField: r3 = r1->field_7
    //     0xb6983c: ldur            x3, [x1, #7]
    // 0xb69840: ldr             x1, [x3]
    // 0xb69844: mov             x3, x1
    // 0xb69848: stur            x3, [fp, #-0x28]
    // 0xb6984c: r1 = <Never>
    //     0xb6984c: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb69850: r0 = Pointer()
    //     0xb69850: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb69854: mov             x1, x0
    // 0xb69858: ldur            x0, [fp, #-0x28]
    // 0xb6985c: StoreField: r1->field_7 = r0
    //     0xb6985c: stur            x0, [x1, #7]
    // 0xb69860: mov             x2, x1
    // 0xb69864: ldur            x1, [fp, #-0x18]
    // 0xb69868: ldur            x3, [fp, #-0x30]
    // 0xb6986c: ldur            x5, [fp, #-0x10]
    // 0xb69870: r0 = __drawPath$Method$FfiNative()
    //     0xb69870: bl              #0xb69a00  ; [dart:ui] _NativeCanvas::__drawPath$Method$FfiNative
    // 0xb69874: r0 = Null
    //     0xb69874: mov             x0, NULL
    // 0xb69878: LeaveFrame
    //     0xb69878: mov             SP, fp
    //     0xb6987c: ldp             fp, lr, [SP], #0x10
    // 0xb69880: ret
    //     0xb69880: ret             
    // 0xb69884: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb69884: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb69888: str             x16, [SP]
    // 0xb6988c: r0 = _throwNew()
    //     0xb6988c: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb69890: brk             #0
    // 0xb69894: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb69894: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb69898: str             x16, [SP]
    // 0xb6989c: r0 = _throwNew()
    //     0xb6989c: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb698a0: brk             #0
    // 0xb698a4: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb698a4: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb698a8: str             x16, [SP]
    // 0xb698ac: r0 = _throwNew()
    //     0xb698ac: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb698b0: brk             #0
    // 0xb698b4: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb698b4: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb698b8: str             x16, [SP]
    // 0xb698bc: r0 = _throwNew()
    //     0xb698bc: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb698c0: brk             #0
    // 0xb698c4: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb698c4: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb698c8: str             x16, [SP]
    // 0xb698cc: r0 = _throwNew()
    //     0xb698cc: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb698d0: brk             #0
    // 0xb698d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb698d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb698d8: b               #0xb69604
    // 0xb698dc: r0 = NullErrorSharedWithFPURegs()
    //     0xb698dc: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0xb698e0: r0 = NullErrorSharedWithFPURegs()
    //     0xb698e0: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0xb698e4: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb698e4: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xb698e8: r0 = NullErrorSharedWithFPURegs()
    //     0xb698e8: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0xb698ec: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb698ec: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xb698f0: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb698f0: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ _drawBox(/* No info */) {
    // ** addr: 0xb69ec0, size: 0x1a0
    // 0xb69ec0: EnterFrame
    //     0xb69ec0: stp             fp, lr, [SP, #-0x10]!
    //     0xb69ec4: mov             fp, SP
    // 0xb69ec8: AllocStack(0x30)
    //     0xb69ec8: sub             SP, SP, #0x30
    // 0xb69ecc: SetupParameters(_CheckboxPainter this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r0, fp-0x20 */, dynamic _ /* r6 => r2, fp-0x28 */)
    //     0xb69ecc: mov             x0, x5
    //     0xb69ed0: stur            x5, [fp, #-0x20]
    //     0xb69ed4: mov             x5, x1
    //     0xb69ed8: mov             x4, x2
    //     0xb69edc: stur            x2, [fp, #-0x10]
    //     0xb69ee0: mov             x2, x6
    //     0xb69ee4: stur            x1, [fp, #-8]
    //     0xb69ee8: stur            x3, [fp, #-0x18]
    //     0xb69eec: stur            x6, [fp, #-0x28]
    // 0xb69ef0: CheckStackOverflow
    //     0xb69ef0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb69ef4: cmp             SP, x16
    //     0xb69ef8: b.ls            #0xb6a044
    // 0xb69efc: LoadField: r1 = r5->field_73
    //     0xb69efc: ldur            w1, [x5, #0x73]
    // 0xb69f00: DecompressPointer r1
    //     0xb69f00: add             x1, x1, HEAP, lsl #32
    // 0xb69f04: r16 = Instance_Brightness
    //     0xb69f04: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0xb69f08: cmp             w1, w16
    // 0xb69f0c: b.ne            #0xb69fc8
    // 0xb69f10: LoadField: r1 = r5->field_5b
    //     0xb69f10: ldur            w1, [x5, #0x5b]
    // 0xb69f14: DecompressPointer r1
    //     0xb69f14: add             x1, x1, HEAP, lsl #32
    // 0xb69f18: cmp             w1, NULL
    // 0xb69f1c: b.eq            #0xb6a04c
    // 0xb69f20: tbnz            w1, #4, #0xb69f30
    // 0xb69f24: tbnz            w7, #4, #0xb69f30
    // 0xb69f28: mov             x0, x5
    // 0xb69f2c: b               #0xb69fcc
    // 0xb69f30: mov             x1, x0
    // 0xb69f34: r0 = color()
    //     0xb69f34: bl              #0xb6a1dc  ; [dart:ui] Paint::color
    // 0xb69f38: mov             x1, x0
    // 0xb69f3c: ldur            x0, [fp, #-8]
    // 0xb69f40: LoadField: r2 = r0->field_5b
    //     0xb69f40: ldur            w2, [x0, #0x5b]
    // 0xb69f44: DecompressPointer r2
    //     0xb69f44: add             x2, x2, HEAP, lsl #32
    // 0xb69f48: cmp             w2, NULL
    // 0xb69f4c: b.eq            #0xb6a050
    // 0xb69f50: tbnz            w2, #4, #0xb69f60
    // 0xb69f54: d0 = 0.140000
    //     0xb69f54: add             x17, PP, #0xa2, lsl #12  ; [pp+0xa2ae8] IMM: double(0.14) from 0x3fc1eb851eb851ec
    //     0xb69f58: ldr             d0, [x17, #0xae8]
    // 0xb69f5c: b               #0xb69f68
    // 0xb69f60: d0 = 0.080000
    //     0xb69f60: add             x17, PP, #0x15, lsl #12  ; [pp+0x15a58] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0xb69f64: ldr             d0, [x17, #0xa58]
    // 0xb69f68: r0 = withOpacity()
    //     0xb69f68: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xb69f6c: ldur            x1, [fp, #-0x20]
    // 0xb69f70: stur            x0, [fp, #-0x30]
    // 0xb69f74: r0 = color()
    //     0xb69f74: bl              #0xb6a1dc  ; [dart:ui] Paint::color
    // 0xb69f78: mov             x1, x0
    // 0xb69f7c: ldur            x0, [fp, #-8]
    // 0xb69f80: LoadField: r2 = r0->field_5b
    //     0xb69f80: ldur            w2, [x0, #0x5b]
    // 0xb69f84: DecompressPointer r2
    //     0xb69f84: add             x2, x2, HEAP, lsl #32
    // 0xb69f88: cmp             w2, NULL
    // 0xb69f8c: b.eq            #0xb6a054
    // 0xb69f90: tbnz            w2, #4, #0xb69fa0
    // 0xb69f94: d0 = 0.290000
    //     0xb69f94: add             x17, PP, #0x13, lsl #12  ; [pp+0x131a8] IMM: double(0.29) from 0x3fd28f5c28f5c28f
    //     0xb69f98: ldr             d0, [x17, #0x1a8]
    // 0xb69f9c: b               #0xb69fa8
    // 0xb69fa0: d0 = 0.140000
    //     0xb69fa0: add             x17, PP, #0xa2, lsl #12  ; [pp+0xa2ae8] IMM: double(0.14) from 0x3fc1eb851eb851ec
    //     0xb69fa4: ldr             d0, [x17, #0xae8]
    // 0xb69fa8: r0 = withOpacity()
    //     0xb69fa8: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xb69fac: ldur            x1, [fp, #-8]
    // 0xb69fb0: ldur            x2, [fp, #-0x10]
    // 0xb69fb4: ldur            x3, [fp, #-0x18]
    // 0xb69fb8: ldur            x5, [fp, #-0x30]
    // 0xb69fbc: mov             x6, x0
    // 0xb69fc0: r0 = _drawFillGradient()
    //     0xb69fc0: bl              #0xb6a060  ; [package:flutter/src/cupertino/checkbox.dart] _CheckboxPainter::_drawFillGradient
    // 0xb69fc4: b               #0xb69ff8
    // 0xb69fc8: ldur            x0, [fp, #-8]
    // 0xb69fcc: LoadField: r1 = r0->field_6b
    //     0xb69fcc: ldur            w1, [x0, #0x6b]
    // 0xb69fd0: DecompressPointer r1
    //     0xb69fd0: add             x1, x1, HEAP, lsl #32
    // 0xb69fd4: cmp             w1, NULL
    // 0xb69fd8: b.eq            #0xb6a058
    // 0xb69fdc: ldur            x2, [fp, #-0x10]
    // 0xb69fe0: ldur            x3, [fp, #-0x18]
    // 0xb69fe4: ldur            x5, [fp, #-0x20]
    // 0xb69fe8: r1 = Instance_RoundedRectangleBorder
    //     0xb69fe8: add             x1, PP, #0x26, lsl #12  ; [pp+0x26218] Obj!RoundedRectangleBorder@129ec21
    //     0xb69fec: ldr             x1, [x1, #0x218]
    // 0xb69ff0: r4 = const [0, 0x4, 0, 0x4, null]
    //     0xb69ff0: ldr             x4, [PP, #0xff0]  ; [pp+0xff0] List(5) [0, 0x4, 0, 0x4, Null]
    // 0xb69ff4: r0 = paintInterior()
    //     0xb69ff4: bl              #0x12ebae0  ; [package:flutter/src/painting/rounded_rectangle_border.dart] RoundedRectangleBorder::paintInterior
    // 0xb69ff8: ldur            x0, [fp, #-8]
    // 0xb69ffc: LoadField: r1 = r0->field_6b
    //     0xb69ffc: ldur            w1, [x0, #0x6b]
    // 0xb6a000: DecompressPointer r1
    //     0xb6a000: add             x1, x1, HEAP, lsl #32
    // 0xb6a004: cmp             w1, NULL
    // 0xb6a008: b.eq            #0xb6a05c
    // 0xb6a00c: ldur            x2, [fp, #-0x28]
    // 0xb6a010: r1 = Instance_RoundedRectangleBorder
    //     0xb6a010: add             x1, PP, #0x26, lsl #12  ; [pp+0x26218] Obj!RoundedRectangleBorder@129ec21
    //     0xb6a014: ldr             x1, [x1, #0x218]
    // 0xb6a018: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xb6a018: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xb6a01c: r0 = copyWith()
    //     0xb6a01c: bl              #0x1301674  ; [package:flutter/src/painting/rounded_rectangle_border.dart] RoundedRectangleBorder::copyWith
    // 0xb6a020: mov             x1, x0
    // 0xb6a024: ldur            x2, [fp, #-0x10]
    // 0xb6a028: ldur            x3, [fp, #-0x18]
    // 0xb6a02c: r4 = const [0, 0x3, 0, 0x3, null]
    //     0xb6a02c: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0xb6a030: r0 = paint()
    //     0xb6a030: bl              #0x12ecb18  ; [package:flutter/src/painting/rounded_rectangle_border.dart] RoundedRectangleBorder::paint
    // 0xb6a034: r0 = Null
    //     0xb6a034: mov             x0, NULL
    // 0xb6a038: LeaveFrame
    //     0xb6a038: mov             SP, fp
    //     0xb6a03c: ldp             fp, lr, [SP], #0x10
    // 0xb6a040: ret
    //     0xb6a040: ret             
    // 0xb6a044: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb6a044: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb6a048: b               #0xb69efc
    // 0xb6a04c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6a04c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6a050: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6a050: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6a054: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6a054: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6a058: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6a058: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6a05c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6a05c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _drawFillGradient(/* No info */) {
    // ** addr: 0xb6a060, size: 0x170
    // 0xb6a060: EnterFrame
    //     0xb6a060: stp             fp, lr, [SP, #-0x10]!
    //     0xb6a064: mov             fp, SP
    // 0xb6a068: AllocStack(0x48)
    //     0xb6a068: sub             SP, SP, #0x48
    // 0xb6a06c: r0 = 4
    //     0xb6a06c: mov             x0, #4
    // 0xb6a070: mov             x7, x1
    // 0xb6a074: mov             x4, x2
    // 0xb6a078: stur            x1, [fp, #-8]
    // 0xb6a07c: stur            x2, [fp, #-0x10]
    // 0xb6a080: stur            x3, [fp, #-0x18]
    // 0xb6a084: stur            x5, [fp, #-0x20]
    // 0xb6a088: stur            x6, [fp, #-0x28]
    // 0xb6a08c: CheckStackOverflow
    //     0xb6a08c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb6a090: cmp             SP, x16
    //     0xb6a094: b.ls            #0xb6a1c4
    // 0xb6a098: mov             x2, x0
    // 0xb6a09c: r1 = Null
    //     0xb6a09c: mov             x1, NULL
    // 0xb6a0a0: r0 = AllocateArray()
    //     0xb6a0a0: bl              #0x13df928  ; AllocateArrayStub
    // 0xb6a0a4: mov             x2, x0
    // 0xb6a0a8: ldur            x0, [fp, #-0x20]
    // 0xb6a0ac: stur            x2, [fp, #-0x30]
    // 0xb6a0b0: StoreField: r2->field_f = r0
    //     0xb6a0b0: stur            w0, [x2, #0xf]
    // 0xb6a0b4: ldur            x0, [fp, #-0x28]
    // 0xb6a0b8: StoreField: r2->field_13 = r0
    //     0xb6a0b8: stur            w0, [x2, #0x13]
    // 0xb6a0bc: r1 = <Color>
    //     0xb6a0bc: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xb6a0c0: ldr             x1, [x1, #0xa90]
    // 0xb6a0c4: r0 = AllocateGrowableArray()
    //     0xb6a0c4: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xb6a0c8: mov             x1, x0
    // 0xb6a0cc: ldur            x0, [fp, #-0x30]
    // 0xb6a0d0: stur            x1, [fp, #-0x20]
    // 0xb6a0d4: StoreField: r1->field_f = r0
    //     0xb6a0d4: stur            w0, [x1, #0xf]
    // 0xb6a0d8: r0 = 4
    //     0xb6a0d8: mov             x0, #4
    // 0xb6a0dc: StoreField: r1->field_b = r0
    //     0xb6a0dc: stur            w0, [x1, #0xb]
    // 0xb6a0e0: r0 = LinearGradient()
    //     0xb6a0e0: bl              #0xb6a1d0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0xb6a0e4: mov             x1, x0
    // 0xb6a0e8: r0 = Instance_Alignment
    //     0xb6a0e8: add             x0, PP, #0x19, lsl #12  ; [pp+0x197a8] Obj!Alignment@129e7d1
    //     0xb6a0ec: ldr             x0, [x0, #0x7a8]
    // 0xb6a0f0: stur            x1, [fp, #-0x28]
    // 0xb6a0f4: StoreField: r1->field_13 = r0
    //     0xb6a0f4: stur            w0, [x1, #0x13]
    // 0xb6a0f8: r0 = Instance_Alignment
    //     0xb6a0f8: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e1b8] Obj!Alignment@129e6f1
    //     0xb6a0fc: ldr             x0, [x0, #0x1b8]
    // 0xb6a100: ArrayStore: r1[0] = r0  ; List_4
    //     0xb6a100: stur            w0, [x1, #0x17]
    // 0xb6a104: r0 = Instance_TileMode
    //     0xb6a104: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e900] Obj!TileMode@12c7f61
    //     0xb6a108: ldr             x0, [x0, #0x900]
    // 0xb6a10c: StoreField: r1->field_1b = r0
    //     0xb6a10c: stur            w0, [x1, #0x1b]
    // 0xb6a110: ldur            x0, [fp, #-0x20]
    // 0xb6a114: StoreField: r1->field_7 = r0
    //     0xb6a114: stur            w0, [x1, #7]
    // 0xb6a118: r16 = 136
    //     0xb6a118: mov             x16, #0x88
    // 0xb6a11c: stp             x16, NULL, [SP]
    // 0xb6a120: r0 = ByteData()
    //     0xb6a120: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xb6a124: stur            x0, [fp, #-0x20]
    // 0xb6a128: r0 = Paint()
    //     0xb6a128: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xb6a12c: mov             x3, x0
    // 0xb6a130: ldur            x0, [fp, #-0x20]
    // 0xb6a134: stur            x3, [fp, #-0x30]
    // 0xb6a138: StoreField: r3->field_7 = r0
    //     0xb6a138: stur            w0, [x3, #7]
    // 0xb6a13c: ldur            x1, [fp, #-0x28]
    // 0xb6a140: ldur            x2, [fp, #-0x18]
    // 0xb6a144: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xb6a144: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xb6a148: r0 = createShader()
    //     0xb6a148: bl              #0x1305638  ; [package:flutter/src/painting/gradient.dart] LinearGradient::createShader
    // 0xb6a14c: ldur            x1, [fp, #-0x30]
    // 0xb6a150: stur            x0, [fp, #-0x20]
    // 0xb6a154: r0 = _ensureObjectsInitialized()
    //     0xb6a154: bl              #0xaf5568  ; [dart:ui] Paint::_ensureObjectsInitialized
    // 0xb6a158: r1 = LoadClassIdInstr(r0)
    //     0xb6a158: ldur            x1, [x0, #-1]
    //     0xb6a15c: ubfx            x1, x1, #0xc, #0x14
    // 0xb6a160: stp             xzr, x0, [SP, #8]
    // 0xb6a164: ldur            x16, [fp, #-0x20]
    // 0xb6a168: str             x16, [SP]
    // 0xb6a16c: mov             x0, x1
    // 0xb6a170: r0 = GDT[cid_x0 + 0x18dc8]()
    //     0xb6a170: mov             x17, #0x8dc8
    //     0xb6a174: movk            x17, #1, lsl #16
    //     0xb6a178: add             lr, x0, x17
    //     0xb6a17c: ldr             lr, [x21, lr, lsl #3]
    //     0xb6a180: blr             lr
    // 0xb6a184: ldur            x0, [fp, #-8]
    // 0xb6a188: LoadField: r1 = r0->field_6b
    //     0xb6a188: ldur            w1, [x0, #0x6b]
    // 0xb6a18c: DecompressPointer r1
    //     0xb6a18c: add             x1, x1, HEAP, lsl #32
    // 0xb6a190: cmp             w1, NULL
    // 0xb6a194: b.eq            #0xb6a1cc
    // 0xb6a198: ldur            x2, [fp, #-0x10]
    // 0xb6a19c: ldur            x3, [fp, #-0x18]
    // 0xb6a1a0: ldur            x5, [fp, #-0x30]
    // 0xb6a1a4: r1 = Instance_RoundedRectangleBorder
    //     0xb6a1a4: add             x1, PP, #0x26, lsl #12  ; [pp+0x26218] Obj!RoundedRectangleBorder@129ec21
    //     0xb6a1a8: ldr             x1, [x1, #0x218]
    // 0xb6a1ac: r4 = const [0, 0x4, 0, 0x4, null]
    //     0xb6a1ac: ldr             x4, [PP, #0xff0]  ; [pp+0xff0] List(5) [0, 0x4, 0, 0x4, Null]
    // 0xb6a1b0: r0 = paintInterior()
    //     0xb6a1b0: bl              #0x12ebae0  ; [package:flutter/src/painting/rounded_rectangle_border.dart] RoundedRectangleBorder::paintInterior
    // 0xb6a1b4: r0 = Null
    //     0xb6a1b4: mov             x0, NULL
    // 0xb6a1b8: LeaveFrame
    //     0xb6a1b8: mov             SP, fp
    //     0xb6a1bc: ldp             fp, lr, [SP], #0x10
    // 0xb6a1c0: ret
    //     0xb6a1c0: ret             
    // 0xb6a1c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb6a1c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb6a1c8: b               #0xb6a098
    // 0xb6a1cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6a1cc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _colorAt(/* No info */) {
    // ** addr: 0xb6a43c, size: 0x64
    // 0xb6a43c: EnterFrame
    //     0xb6a43c: stp             fp, lr, [SP, #-0x10]!
    //     0xb6a440: mov             fp, SP
    // 0xb6a444: tbnz            w2, #4, #0xb6a474
    // 0xb6a448: LoadField: r2 = r1->field_5b
    //     0xb6a448: ldur            w2, [x1, #0x5b]
    // 0xb6a44c: DecompressPointer r2
    //     0xb6a44c: add             x2, x2, HEAP, lsl #32
    // 0xb6a450: cmp             w2, NULL
    // 0xb6a454: b.eq            #0xb6a494
    // 0xb6a458: tbnz            w2, #4, #0xb6a474
    // 0xb6a45c: LoadField: r2 = r1->field_33
    //     0xb6a45c: ldur            w2, [x1, #0x33]
    // 0xb6a460: DecompressPointer r2
    //     0xb6a460: add             x2, x2, HEAP, lsl #32
    // 0xb6a464: cmp             w2, NULL
    // 0xb6a468: b.eq            #0xb6a498
    // 0xb6a46c: mov             x0, x2
    // 0xb6a470: b               #0xb6a488
    // 0xb6a474: LoadField: r2 = r1->field_37
    //     0xb6a474: ldur            w2, [x1, #0x37]
    // 0xb6a478: DecompressPointer r2
    //     0xb6a478: add             x2, x2, HEAP, lsl #32
    // 0xb6a47c: cmp             w2, NULL
    // 0xb6a480: b.eq            #0xb6a49c
    // 0xb6a484: mov             x0, x2
    // 0xb6a488: LeaveFrame
    //     0xb6a488: mov             SP, fp
    //     0xb6a48c: ldp             fp, lr, [SP], #0x10
    // 0xb6a490: ret
    //     0xb6a490: ret             
    // 0xb6a494: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6a494: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6a498: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6a498: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6a49c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6a49c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _outerRectAt(/* No info */) {
    // ** addr: 0xb6a4a0, size: 0x60
    // 0xb6a4a0: EnterFrame
    //     0xb6a4a0: stp             fp, lr, [SP, #-0x10]!
    //     0xb6a4a4: mov             fp, SP
    // 0xb6a4a8: AllocStack(0x20)
    //     0xb6a4a8: sub             SP, SP, #0x20
    // 0xb6a4ac: d0 = 14.000000
    //     0xb6a4ac: fmov            d0, #14.00000000
    // 0xb6a4b0: LoadField: d1 = r2->field_7
    //     0xb6a4b0: ldur            d1, [x2, #7]
    // 0xb6a4b4: stur            d1, [fp, #-0x20]
    // 0xb6a4b8: LoadField: d2 = r2->field_f
    //     0xb6a4b8: ldur            d2, [x2, #0xf]
    // 0xb6a4bc: stur            d2, [fp, #-0x18]
    // 0xb6a4c0: fadd            d3, d1, d0
    // 0xb6a4c4: stur            d3, [fp, #-0x10]
    // 0xb6a4c8: fadd            d4, d2, d0
    // 0xb6a4cc: stur            d4, [fp, #-8]
    // 0xb6a4d0: r0 = Rect()
    //     0xb6a4d0: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0xb6a4d4: ldur            d0, [fp, #-0x20]
    // 0xb6a4d8: StoreField: r0->field_7 = d0
    //     0xb6a4d8: stur            d0, [x0, #7]
    // 0xb6a4dc: ldur            d0, [fp, #-0x18]
    // 0xb6a4e0: StoreField: r0->field_f = d0
    //     0xb6a4e0: stur            d0, [x0, #0xf]
    // 0xb6a4e4: ldur            d0, [fp, #-0x10]
    // 0xb6a4e8: ArrayStore: r0[0] = d0  ; List_8
    //     0xb6a4e8: stur            d0, [x0, #0x17]
    // 0xb6a4ec: ldur            d0, [fp, #-8]
    // 0xb6a4f0: StoreField: r0->field_1f = d0
    //     0xb6a4f0: stur            d0, [x0, #0x1f]
    // 0xb6a4f4: LeaveFrame
    //     0xb6a4f4: mov             SP, fp
    //     0xb6a4f8: ldp             fp, lr, [SP], #0x10
    // 0xb6a4fc: ret
    //     0xb6a4fc: ret             
  }
  _ _createStrokePaint(/* No info */) {
    // ** addr: 0xb6a500, size: 0xa8
    // 0xb6a500: EnterFrame
    //     0xb6a500: stp             fp, lr, [SP, #-0x10]!
    //     0xb6a504: mov             fp, SP
    // 0xb6a508: AllocStack(0x28)
    //     0xb6a508: sub             SP, SP, #0x28
    // 0xb6a50c: SetupParameters(_CheckboxPainter this /* r1 => r1, fp-0x8 */)
    //     0xb6a50c: stur            x1, [fp, #-8]
    // 0xb6a510: CheckStackOverflow
    //     0xb6a510: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb6a514: cmp             SP, x16
    //     0xb6a518: b.ls            #0xb6a59c
    // 0xb6a51c: r16 = 136
    //     0xb6a51c: mov             x16, #0x88
    // 0xb6a520: stp             x16, NULL, [SP]
    // 0xb6a524: r0 = ByteData()
    //     0xb6a524: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xb6a528: stur            x0, [fp, #-0x10]
    // 0xb6a52c: r0 = Paint()
    //     0xb6a52c: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xb6a530: mov             x3, x0
    // 0xb6a534: ldur            x0, [fp, #-0x10]
    // 0xb6a538: stur            x3, [fp, #-0x18]
    // 0xb6a53c: StoreField: r3->field_7 = r0
    //     0xb6a53c: stur            w0, [x3, #7]
    // 0xb6a540: ldur            x1, [fp, #-8]
    // 0xb6a544: LoadField: r2 = r1->field_5f
    //     0xb6a544: ldur            w2, [x1, #0x5f]
    // 0xb6a548: DecompressPointer r2
    //     0xb6a548: add             x2, x2, HEAP, lsl #32
    // 0xb6a54c: cmp             w2, NULL
    // 0xb6a550: b.eq            #0xb6a5a4
    // 0xb6a554: mov             x1, x3
    // 0xb6a558: r0 = color=()
    //     0xb6a558: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xb6a55c: ldur            x1, [fp, #-0x10]
    // 0xb6a560: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xb6a560: ldur            w2, [x1, #0x17]
    // 0xb6a564: DecompressPointer r2
    //     0xb6a564: add             x2, x2, HEAP, lsl #32
    // 0xb6a568: LoadField: r1 = r2->field_7
    //     0xb6a568: ldur            x1, [x2, #7]
    // 0xb6a56c: r3 = 1
    //     0xb6a56c: mov             x3, #1
    // 0xb6a570: str             w3, [x1, #0x1c]
    // 0xb6a574: LoadField: r1 = r2->field_7
    //     0xb6a574: ldur            x1, [x2, #7]
    // 0xb6a578: d0 = 0.000000
    //     0xb6a578: add             x17, PP, #0xa2, lsl #12  ; [pp+0xa2af0] IMM: 0x40000000
    //     0xb6a57c: ldr             s0, [x17, #0xaf0]
    // 0xb6a580: str             s0, [x1, #0x20]
    // 0xb6a584: LoadField: r1 = r2->field_7
    //     0xb6a584: ldur            x1, [x2, #7]
    // 0xb6a588: str             w3, [x1, #0x24]
    // 0xb6a58c: ldur            x0, [fp, #-0x18]
    // 0xb6a590: LeaveFrame
    //     0xb6a590: mov             SP, fp
    //     0xb6a594: ldp             fp, lr, [SP], #0x10
    // 0xb6a598: ret
    //     0xb6a598: ret             
    // 0xb6a59c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb6a59c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb6a5a0: b               #0xb6a51c
    // 0xb6a5a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6a5a4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ brightness=(/* No info */) {
    // ** addr: 0xd76814, size: 0x70
    // 0xd76814: EnterFrame
    //     0xd76814: stp             fp, lr, [SP, #-0x10]!
    //     0xd76818: mov             fp, SP
    // 0xd7681c: mov             x0, x2
    // 0xd76820: CheckStackOverflow
    //     0xd76820: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd76824: cmp             SP, x16
    //     0xd76828: b.ls            #0xd7687c
    // 0xd7682c: LoadField: r2 = r1->field_73
    //     0xd7682c: ldur            w2, [x1, #0x73]
    // 0xd76830: DecompressPointer r2
    //     0xd76830: add             x2, x2, HEAP, lsl #32
    // 0xd76834: cmp             w2, w0
    // 0xd76838: b.ne            #0xd7684c
    // 0xd7683c: r0 = Null
    //     0xd7683c: mov             x0, NULL
    // 0xd76840: LeaveFrame
    //     0xd76840: mov             SP, fp
    //     0xd76844: ldp             fp, lr, [SP], #0x10
    // 0xd76848: ret
    //     0xd76848: ret             
    // 0xd7684c: StoreField: r1->field_73 = r0
    //     0xd7684c: stur            w0, [x1, #0x73]
    //     0xd76850: ldurb           w16, [x1, #-1]
    //     0xd76854: ldurb           w17, [x0, #-1]
    //     0xd76858: and             x16, x17, x16, lsr #2
    //     0xd7685c: tst             x16, HEAP, lsr #32
    //     0xd76860: b.eq            #0xd76868
    //     0xd76864: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd76868: r0 = notifyListeners()
    //     0xd76868: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xd7686c: r0 = Null
    //     0xd7686c: mov             x0, NULL
    // 0xd76870: LeaveFrame
    //     0xd76870: mov             SP, fp
    //     0xd76874: ldp             fp, lr, [SP], #0x10
    // 0xd76878: ret
    //     0xd76878: ret             
    // 0xd7687c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd7687c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd76880: b               #0xd7682c
  }
  set _ shape=(/* No info */) {
    // ** addr: 0xd76884, size: 0x88
    // 0xd76884: EnterFrame
    //     0xd76884: stp             fp, lr, [SP, #-0x10]!
    //     0xd76888: mov             fp, SP
    // 0xd7688c: AllocStack(0x18)
    //     0xd7688c: sub             SP, SP, #0x18
    // 0xd76890: SetupParameters(_CheckboxPainter this /* r1 => r1, fp-0x8 */)
    //     0xd76890: stur            x1, [fp, #-8]
    // 0xd76894: CheckStackOverflow
    //     0xd76894: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd76898: cmp             SP, x16
    //     0xd7689c: b.ls            #0xd76904
    // 0xd768a0: LoadField: r0 = r1->field_6b
    //     0xd768a0: ldur            w0, [x1, #0x6b]
    // 0xd768a4: DecompressPointer r0
    //     0xd768a4: add             x0, x0, HEAP, lsl #32
    // 0xd768a8: r2 = LoadClassIdInstr(r0)
    //     0xd768a8: ldur            x2, [x0, #-1]
    //     0xd768ac: ubfx            x2, x2, #0xc, #0x14
    // 0xd768b0: r16 = Instance_RoundedRectangleBorder
    //     0xd768b0: add             x16, PP, #0x26, lsl #12  ; [pp+0x26218] Obj!RoundedRectangleBorder@129ec21
    //     0xd768b4: ldr             x16, [x16, #0x218]
    // 0xd768b8: stp             x16, x0, [SP]
    // 0xd768bc: mov             x0, x2
    // 0xd768c0: mov             lr, x0
    // 0xd768c4: ldr             lr, [x21, lr, lsl #3]
    // 0xd768c8: blr             lr
    // 0xd768cc: tbnz            w0, #4, #0xd768e0
    // 0xd768d0: r0 = Null
    //     0xd768d0: mov             x0, NULL
    // 0xd768d4: LeaveFrame
    //     0xd768d4: mov             SP, fp
    //     0xd768d8: ldp             fp, lr, [SP], #0x10
    // 0xd768dc: ret
    //     0xd768dc: ret             
    // 0xd768e0: ldur            x1, [fp, #-8]
    // 0xd768e4: r0 = Instance_RoundedRectangleBorder
    //     0xd768e4: add             x0, PP, #0x26, lsl #12  ; [pp+0x26218] Obj!RoundedRectangleBorder@129ec21
    //     0xd768e8: ldr             x0, [x0, #0x218]
    // 0xd768ec: StoreField: r1->field_6b = r0
    //     0xd768ec: stur            w0, [x1, #0x6b]
    // 0xd768f0: r0 = notifyListeners()
    //     0xd768f0: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xd768f4: r0 = Null
    //     0xd768f4: mov             x0, NULL
    // 0xd768f8: LeaveFrame
    //     0xd768f8: mov             SP, fp
    //     0xd768fc: ldp             fp, lr, [SP], #0x10
    // 0xd76900: ret
    //     0xd76900: ret             
    // 0xd76904: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd76904: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd76908: b               #0xd768a0
  }
}

// class id: 5604, size: 0x58, field offset: 0x50
class _CupertinoCheckboxState extends _MixinApplication387&State&TickerProviderStateMixin&ToggleableStateMixin {

  _ build(/* No info */) {
    // ** addr: 0xd75a18, size: 0x4d4
    // 0xd75a18: EnterFrame
    //     0xd75a18: stp             fp, lr, [SP, #-0x10]!
    //     0xd75a1c: mov             fp, SP
    // 0xd75a20: AllocStack(0x78)
    //     0xd75a20: sub             SP, SP, #0x78
    // 0xd75a24: SetupParameters(_CupertinoCheckboxState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xd75a24: mov             x0, x1
    //     0xd75a28: stur            x1, [fp, #-8]
    //     0xd75a2c: mov             x1, x2
    //     0xd75a30: stur            x2, [fp, #-0x10]
    // 0xd75a34: CheckStackOverflow
    //     0xd75a34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd75a38: cmp             SP, x16
    //     0xd75a3c: b.ls            #0xd75eb0
    // 0xd75a40: r1 = 1
    //     0xd75a40: mov             x1, #1
    // 0xd75a44: r0 = AllocateContext()
    //     0xd75a44: bl              #0x13de838  ; AllocateContextStub
    // 0xd75a48: mov             x2, x0
    // 0xd75a4c: ldur            x0, [fp, #-8]
    // 0xd75a50: stur            x2, [fp, #-0x18]
    // 0xd75a54: StoreField: r2->field_f = r0
    //     0xd75a54: stur            w0, [x2, #0xf]
    // 0xd75a58: mov             x1, x0
    // 0xd75a5c: r0 = states()
    //     0xd75a5c: bl              #0x129f6f4  ; [dart:mixin_deduplication] _MixinApplication387&State&TickerProviderStateMixin&ToggleableStateMixin::states
    // 0xd75a60: mov             x1, x0
    // 0xd75a64: r2 = Instance_WidgetState
    //     0xd75a64: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xd75a68: ldr             x2, [x2, #0x100]
    // 0xd75a6c: stur            x0, [fp, #-0x20]
    // 0xd75a70: r0 = add()
    //     0xd75a70: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xd75a74: ldur            x1, [fp, #-8]
    // 0xd75a78: r0 = states()
    //     0xd75a78: bl              #0x129f6f4  ; [dart:mixin_deduplication] _MixinApplication387&State&TickerProviderStateMixin&ToggleableStateMixin::states
    // 0xd75a7c: mov             x1, x0
    // 0xd75a80: r2 = Instance_WidgetState
    //     0xd75a80: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xd75a84: ldr             x2, [x2, #0x100]
    // 0xd75a88: stur            x0, [fp, #-0x28]
    // 0xd75a8c: r0 = remove()
    //     0xd75a8c: bl              #0x115bfd0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::remove
    // 0xd75a90: ldur            x1, [fp, #-8]
    // 0xd75a94: r0 = states()
    //     0xd75a94: bl              #0x129f6f4  ; [dart:mixin_deduplication] _MixinApplication387&State&TickerProviderStateMixin&ToggleableStateMixin::states
    // 0xd75a98: ldur            x1, [fp, #-8]
    // 0xd75a9c: stur            x0, [fp, #-0x30]
    // 0xd75aa0: LoadField: r2 = r1->field_b
    //     0xd75aa0: ldur            w2, [x1, #0xb]
    // 0xd75aa4: DecompressPointer r2
    //     0xd75aa4: add             x2, x2, HEAP, lsl #32
    // 0xd75aa8: cmp             w2, NULL
    // 0xd75aac: b.eq            #0xd75eb8
    // 0xd75ab0: r1 = 1
    //     0xd75ab0: mov             x1, #1
    // 0xd75ab4: r0 = AllocateContext()
    //     0xd75ab4: bl              #0x13de838  ; AllocateContextStub
    // 0xd75ab8: mov             x1, x0
    // 0xd75abc: ldur            x0, [fp, #-8]
    // 0xd75ac0: StoreField: r1->field_f = r0
    //     0xd75ac0: stur            w0, [x1, #0xf]
    // 0xd75ac4: mov             x2, x1
    // 0xd75ac8: r1 = Function '<anonymous closure>':.
    //     0xd75ac8: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2b08] AnonymousClosure: (0xd76eb4), in [package:flutter/src/cupertino/checkbox.dart] _CupertinoCheckboxState::_defaultFillColor (0xd76dd8)
    //     0xd75acc: ldr             x1, [x1, #0xb08]
    // 0xd75ad0: r0 = AllocateClosure()
    //     0xd75ad0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd75ad4: r16 = <Color>
    //     0xd75ad4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xd75ad8: ldr             x16, [x16, #0xa90]
    // 0xd75adc: stp             x0, x16, [SP]
    // 0xd75ae0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd75ae0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd75ae4: r0 = resolveWith()
    //     0xd75ae4: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd75ae8: mov             x1, x0
    // 0xd75aec: ldur            x2, [fp, #-0x20]
    // 0xd75af0: r0 = build()
    //     0xd75af0: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xd75af4: mov             x2, x0
    // 0xd75af8: ldur            x0, [fp, #-8]
    // 0xd75afc: stur            x2, [fp, #-0x20]
    // 0xd75b00: LoadField: r1 = r0->field_b
    //     0xd75b00: ldur            w1, [x0, #0xb]
    // 0xd75b04: DecompressPointer r1
    //     0xd75b04: add             x1, x1, HEAP, lsl #32
    // 0xd75b08: cmp             w1, NULL
    // 0xd75b0c: b.eq            #0xd75ebc
    // 0xd75b10: mov             x1, x0
    // 0xd75b14: r0 = _defaultFillColor()
    //     0xd75b14: bl              #0xd76dd8  ; [package:flutter/src/cupertino/checkbox.dart] _CupertinoCheckboxState::_defaultFillColor
    // 0xd75b18: mov             x1, x0
    // 0xd75b1c: ldur            x2, [fp, #-0x28]
    // 0xd75b20: r0 = build()
    //     0xd75b20: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xd75b24: mov             x3, x0
    // 0xd75b28: ldur            x0, [fp, #-8]
    // 0xd75b2c: stur            x3, [fp, #-0x28]
    // 0xd75b30: LoadField: r1 = r0->field_b
    //     0xd75b30: ldur            w1, [x0, #0xb]
    // 0xd75b34: DecompressPointer r1
    //     0xd75b34: add             x1, x1, HEAP, lsl #32
    // 0xd75b38: cmp             w1, NULL
    // 0xd75b3c: b.eq            #0xd75ec0
    // 0xd75b40: mov             x1, x0
    // 0xd75b44: ldur            x2, [fp, #-0x30]
    // 0xd75b48: r0 = _resolveSide()
    //     0xd75b48: bl              #0xd76d84  ; [package:flutter/src/cupertino/checkbox.dart] _CupertinoCheckboxState::_resolveSide
    // 0xd75b4c: ldur            x1, [fp, #-8]
    // 0xd75b50: r0 = _defaultSide()
    //     0xd75b50: bl              #0xd76b3c  ; [package:flutter/src/cupertino/checkbox.dart] _CupertinoCheckboxState::_defaultSide
    // 0xd75b54: mov             x1, x0
    // 0xd75b58: ldur            x2, [fp, #-0x30]
    // 0xd75b5c: r0 = build()
    //     0xd75b5c: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xd75b60: mov             x3, x0
    // 0xd75b64: ldur            x2, [fp, #-8]
    // 0xd75b68: stur            x3, [fp, #-0x38]
    // 0xd75b6c: LoadField: r0 = r2->field_b
    //     0xd75b6c: ldur            w0, [x2, #0xb]
    // 0xd75b70: DecompressPointer r0
    //     0xd75b70: add             x0, x0, HEAP, lsl #32
    // 0xd75b74: cmp             w0, NULL
    // 0xd75b78: b.eq            #0xd75ec4
    // 0xd75b7c: ldur            x4, [fp, #-0x20]
    // 0xd75b80: r0 = LoadClassIdInstr(r4)
    //     0xd75b80: ldur            x0, [x4, #-1]
    //     0xd75b84: ubfx            x0, x0, #0xc, #0x14
    // 0xd75b88: mov             x1, x4
    // 0xd75b8c: d0 = 0.800000
    //     0xd75b8c: add             x17, PP, #0x13, lsl #12  ; [pp+0x13a58] IMM: double(0.8) from 0x3fe999999999999a
    //     0xd75b90: ldr             d0, [x17, #0xa58]
    // 0xd75b94: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd75b94: sub             lr, x0, #1, lsl #12
    //     0xd75b98: ldr             lr, [x21, lr, lsl #3]
    //     0xd75b9c: blr             lr
    // 0xd75ba0: mov             x2, x0
    // 0xd75ba4: r1 = Null
    //     0xd75ba4: mov             x1, NULL
    // 0xd75ba8: r0 = HSLColor.fromColor()
    //     0xd75ba8: bl              #0xd43b8c  ; [package:flutter/src/painting/colors.dart] HSLColor::HSLColor.fromColor
    // 0xd75bac: mov             x1, x0
    // 0xd75bb0: r0 = withLightness()
    //     0xd75bb0: bl              #0xd43b34  ; [package:flutter/src/painting/colors.dart] HSLColor::withLightness
    // 0xd75bb4: mov             x1, x0
    // 0xd75bb8: r0 = withSaturation()
    //     0xd75bb8: bl              #0xd43ad0  ; [package:flutter/src/painting/colors.dart] HSLColor::withSaturation
    // 0xd75bbc: mov             x1, x0
    // 0xd75bc0: r0 = toColor()
    //     0xd75bc0: bl              #0xd43270  ; [package:flutter/src/painting/colors.dart] HSLColor::toColor
    // 0xd75bc4: ldur            x2, [fp, #-0x18]
    // 0xd75bc8: r1 = Function '<anonymous closure>':.
    //     0xd75bc8: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2b10] AnonymousClosure: (0xd76e40), in [package:flutter/src/cupertino/checkbox.dart] _CupertinoCheckboxState::build (0xd75a18)
    //     0xd75bcc: ldr             x1, [x1, #0xb10]
    // 0xd75bd0: stur            x0, [fp, #-0x18]
    // 0xd75bd4: r0 = AllocateClosure()
    //     0xd75bd4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd75bd8: r16 = <MouseCursor>
    //     0xd75bd8: ldr             x16, [PP, #0x21a8]  ; [pp+0x21a8] TypeArguments: <MouseCursor>
    // 0xd75bdc: stp             x0, x16, [SP]
    // 0xd75be0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd75be0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd75be4: r0 = resolveWith()
    //     0xd75be4: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd75be8: mov             x3, x0
    // 0xd75bec: ldur            x0, [fp, #-8]
    // 0xd75bf0: stur            x3, [fp, #-0x58]
    // 0xd75bf4: LoadField: r1 = r0->field_b
    //     0xd75bf4: ldur            w1, [x0, #0xb]
    // 0xd75bf8: DecompressPointer r1
    //     0xd75bf8: add             x1, x1, HEAP, lsl #32
    // 0xd75bfc: cmp             w1, NULL
    // 0xd75c00: b.eq            #0xd75ec8
    // 0xd75c04: LoadField: r2 = r1->field_b
    //     0xd75c04: ldur            w2, [x1, #0xb]
    // 0xd75c08: DecompressPointer r2
    //     0xd75c08: add             x2, x2, HEAP, lsl #32
    // 0xd75c0c: cmp             w2, NULL
    // 0xd75c10: b.ne            #0xd75c1c
    // 0xd75c14: r4 = false
    //     0xd75c14: add             x4, NULL, #0x30  ; false
    // 0xd75c18: b               #0xd75c20
    // 0xd75c1c: mov             x4, x2
    // 0xd75c20: stur            x4, [fp, #-0x50]
    // 0xd75c24: LoadField: r5 = r1->field_23
    //     0xd75c24: ldur            w5, [x1, #0x23]
    // 0xd75c28: DecompressPointer r5
    //     0xd75c28: add             x5, x5, HEAP, lsl #32
    // 0xd75c2c: tbnz            w5, #4, #0xd75c48
    // 0xd75c30: cmp             w2, NULL
    // 0xd75c34: r16 = true
    //     0xd75c34: add             x16, NULL, #0x20  ; true
    // 0xd75c38: r17 = false
    //     0xd75c38: add             x17, NULL, #0x30  ; false
    // 0xd75c3c: csel            x1, x16, x17, eq
    // 0xd75c40: mov             x5, x1
    // 0xd75c44: b               #0xd75c4c
    // 0xd75c48: r5 = Null
    //     0xd75c48: mov             x5, NULL
    // 0xd75c4c: stur            x5, [fp, #-0x48]
    // 0xd75c50: LoadField: r6 = r0->field_4f
    //     0xd75c50: ldur            w6, [x0, #0x4f]
    // 0xd75c54: DecompressPointer r6
    //     0xd75c54: add             x6, x6, HEAP, lsl #32
    // 0xd75c58: stur            x6, [fp, #-0x40]
    // 0xd75c5c: LoadField: r2 = r0->field_1f
    //     0xd75c5c: ldur            w2, [x0, #0x1f]
    // 0xd75c60: DecompressPointer r2
    //     0xd75c60: add             x2, x2, HEAP, lsl #32
    // 0xd75c64: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd75c68: cmp             w2, w16
    // 0xd75c6c: b.eq            #0xd75ecc
    // 0xd75c70: mov             x1, x6
    // 0xd75c74: r0 = position=()
    //     0xd75c74: bl              #0xd131b8  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::position=
    // 0xd75c78: ldur            x0, [fp, #-8]
    // 0xd75c7c: LoadField: r2 = r0->field_27
    //     0xd75c7c: ldur            w2, [x0, #0x27]
    // 0xd75c80: DecompressPointer r2
    //     0xd75c80: add             x2, x2, HEAP, lsl #32
    // 0xd75c84: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd75c88: cmp             w2, w16
    // 0xd75c8c: b.eq            #0xd75ed8
    // 0xd75c90: ldur            x1, [fp, #-0x40]
    // 0xd75c94: r0 = reaction=()
    //     0xd75c94: bl              #0xd130e8  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::reaction=
    // 0xd75c98: ldur            x1, [fp, #-0x40]
    // 0xd75c9c: ldur            x2, [fp, #-0x18]
    // 0xd75ca0: r0 = focusColor=()
    //     0xd75ca0: bl              #0xd12cb8  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::focusColor=
    // 0xd75ca4: ldur            x0, [fp, #-8]
    // 0xd75ca8: LoadField: r2 = r0->field_43
    //     0xd75ca8: ldur            w2, [x0, #0x43]
    // 0xd75cac: DecompressPointer r2
    //     0xd75cac: add             x2, x2, HEAP, lsl #32
    // 0xd75cb0: ldur            x1, [fp, #-0x40]
    // 0xd75cb4: r0 = downPosition=()
    //     0xd75cb4: bl              #0xd12b48  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::downPosition=
    // 0xd75cb8: ldur            x1, [fp, #-0x30]
    // 0xd75cbc: r2 = Instance_WidgetState
    //     0xd75cbc: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xd75cc0: ldr             x2, [x2, #0xa60]
    // 0xd75cc4: r0 = contains()
    //     0xd75cc4: bl              #0xbafbf4  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0xd75cc8: mov             x1, x0
    // 0xd75ccc: ldur            x0, [fp, #-0x40]
    // 0xd75cd0: LoadField: r2 = r0->field_53
    //     0xd75cd0: ldur            w2, [x0, #0x53]
    // 0xd75cd4: DecompressPointer r2
    //     0xd75cd4: add             x2, x2, HEAP, lsl #32
    // 0xd75cd8: cmp             w1, w2
    // 0xd75cdc: b.eq            #0xd75cf0
    // 0xd75ce0: StoreField: r0->field_53 = r1
    //     0xd75ce0: stur            w1, [x0, #0x53]
    // 0xd75ce4: mov             x1, x0
    // 0xd75ce8: r0 = notifyListeners()
    //     0xd75ce8: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xd75cec: ldur            x0, [fp, #-0x40]
    // 0xd75cf0: ldur            x1, [fp, #-0x30]
    // 0xd75cf4: r2 = Instance_WidgetState
    //     0xd75cf4: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xd75cf8: ldr             x2, [x2, #0xa50]
    // 0xd75cfc: r0 = contains()
    //     0xd75cfc: bl              #0xbafbf4  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0xd75d00: mov             x1, x0
    // 0xd75d04: ldur            x0, [fp, #-0x40]
    // 0xd75d08: LoadField: r2 = r0->field_57
    //     0xd75d08: ldur            w2, [x0, #0x57]
    // 0xd75d0c: DecompressPointer r2
    //     0xd75d0c: add             x2, x2, HEAP, lsl #32
    // 0xd75d10: cmp             w1, w2
    // 0xd75d14: b.eq            #0xd75d28
    // 0xd75d18: StoreField: r0->field_57 = r1
    //     0xd75d18: stur            w1, [x0, #0x57]
    // 0xd75d1c: mov             x1, x0
    // 0xd75d20: r0 = notifyListeners()
    //     0xd75d20: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xd75d24: ldur            x0, [fp, #-0x40]
    // 0xd75d28: mov             x1, x0
    // 0xd75d2c: ldur            x2, [fp, #-0x20]
    // 0xd75d30: r0 = activeColor=()
    //     0xd75d30: bl              #0xd129fc  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::activeColor=
    // 0xd75d34: ldur            x1, [fp, #-0x40]
    // 0xd75d38: ldur            x2, [fp, #-0x28]
    // 0xd75d3c: r0 = inactiveColor=()
    //     0xd75d3c: bl              #0xcf0d78  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::inactiveColor=
    // 0xd75d40: ldur            x1, [fp, #-8]
    // 0xd75d44: r0 = _defaultCheckColor()
    //     0xd75d44: bl              #0xd76960  ; [package:flutter/src/cupertino/checkbox.dart] _CupertinoCheckboxState::_defaultCheckColor
    // 0xd75d48: mov             x1, x0
    // 0xd75d4c: ldur            x2, [fp, #-0x30]
    // 0xd75d50: r0 = build()
    //     0xd75d50: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xd75d54: ldur            x1, [fp, #-0x40]
    // 0xd75d58: mov             x2, x0
    // 0xd75d5c: r0 = checkColor=()
    //     0xd75d5c: bl              #0xd12958  ; [package:flutter/src/material/checkbox.dart] _CheckboxPainter::checkColor=
    // 0xd75d60: ldur            x1, [fp, #-8]
    // 0xd75d64: r0 = value()
    //     0xd75d64: bl              #0x11a0f58  ; [package:flutter/src/cupertino/checkbox.dart] _CupertinoCheckboxState::value
    // 0xd75d68: mov             x1, x0
    // 0xd75d6c: ldur            x0, [fp, #-0x40]
    // 0xd75d70: LoadField: r2 = r0->field_63
    //     0xd75d70: ldur            w2, [x0, #0x63]
    // 0xd75d74: DecompressPointer r2
    //     0xd75d74: add             x2, x2, HEAP, lsl #32
    // 0xd75d78: cmp             w2, w1
    // 0xd75d7c: b.eq            #0xd75d8c
    // 0xd75d80: StoreField: r0->field_63 = r1
    //     0xd75d80: stur            w1, [x0, #0x63]
    // 0xd75d84: mov             x1, x0
    // 0xd75d88: r0 = notifyListeners()
    //     0xd75d88: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xd75d8c: ldur            x0, [fp, #-8]
    // 0xd75d90: LoadField: r2 = r0->field_53
    //     0xd75d90: ldur            w2, [x0, #0x53]
    // 0xd75d94: DecompressPointer r2
    //     0xd75d94: add             x2, x2, HEAP, lsl #32
    // 0xd75d98: ldur            x1, [fp, #-0x40]
    // 0xd75d9c: r0 = previousValue=()
    //     0xd75d9c: bl              #0xd12904  ; [package:flutter/src/material/checkbox.dart] _CheckboxPainter::previousValue=
    // 0xd75da0: ldur            x0, [fp, #-8]
    // 0xd75da4: LoadField: r1 = r0->field_b
    //     0xd75da4: ldur            w1, [x0, #0xb]
    // 0xd75da8: DecompressPointer r1
    //     0xd75da8: add             x1, x1, HEAP, lsl #32
    // 0xd75dac: cmp             w1, NULL
    // 0xd75db0: b.eq            #0xd75ee4
    // 0xd75db4: LoadField: r2 = r1->field_f
    //     0xd75db4: ldur            w2, [x1, #0xf]
    // 0xd75db8: DecompressPointer r2
    //     0xd75db8: add             x2, x2, HEAP, lsl #32
    // 0xd75dbc: cmp             w2, NULL
    // 0xd75dc0: r16 = true
    //     0xd75dc0: add             x16, NULL, #0x20  ; true
    // 0xd75dc4: r17 = false
    //     0xd75dc4: add             x17, NULL, #0x30  ; false
    // 0xd75dc8: csel            x1, x16, x17, ne
    // 0xd75dcc: mov             x2, x1
    // 0xd75dd0: ldur            x1, [fp, #-0x40]
    // 0xd75dd4: r0 = isActive=()
    //     0xd75dd4: bl              #0xd7690c  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::isActive=
    // 0xd75dd8: ldur            x0, [fp, #-8]
    // 0xd75ddc: LoadField: r1 = r0->field_b
    //     0xd75ddc: ldur            w1, [x0, #0xb]
    // 0xd75de0: DecompressPointer r1
    //     0xd75de0: add             x1, x1, HEAP, lsl #32
    // 0xd75de4: cmp             w1, NULL
    // 0xd75de8: b.eq            #0xd75ee8
    // 0xd75dec: ldur            x1, [fp, #-0x40]
    // 0xd75df0: r2 = Instance_RoundedRectangleBorder
    //     0xd75df0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26218] Obj!RoundedRectangleBorder@129ec21
    //     0xd75df4: ldr             x2, [x2, #0x218]
    // 0xd75df8: r0 = shape=()
    //     0xd75df8: bl              #0xd76884  ; [package:flutter/src/cupertino/checkbox.dart] _CheckboxPainter::shape=
    // 0xd75dfc: ldur            x1, [fp, #-0x40]
    // 0xd75e00: ldur            x2, [fp, #-0x38]
    // 0xd75e04: r0 = activeSide=()
    //     0xd75e04: bl              #0xd127bc  ; [package:flutter/src/material/checkbox.dart] _CheckboxPainter::activeSide=
    // 0xd75e08: ldur            x1, [fp, #-0x10]
    // 0xd75e0c: r0 = of()
    //     0xd75e0c: bl              #0xccc364  ; [package:flutter/src/cupertino/theme.dart] CupertinoTheme::of
    // 0xd75e10: r1 = LoadClassIdInstr(r0)
    //     0xd75e10: ldur            x1, [x0, #-1]
    //     0xd75e14: ubfx            x1, x1, #0xc, #0x14
    // 0xd75e18: r17 = 4617
    //     0xd75e18: mov             x17, #0x1209
    // 0xd75e1c: cmp             x1, x17
    // 0xd75e20: b.ne            #0xd75e34
    // 0xd75e24: LoadField: r1 = r0->field_7
    //     0xd75e24: ldur            w1, [x0, #7]
    // 0xd75e28: DecompressPointer r1
    //     0xd75e28: add             x1, x1, HEAP, lsl #32
    // 0xd75e2c: mov             x2, x1
    // 0xd75e30: b               #0xd75e50
    // 0xd75e34: LoadField: r1 = r0->field_2b
    //     0xd75e34: ldur            w1, [x0, #0x2b]
    // 0xd75e38: DecompressPointer r1
    //     0xd75e38: add             x1, x1, HEAP, lsl #32
    // 0xd75e3c: LoadField: r0 = r1->field_3f
    //     0xd75e3c: ldur            w0, [x1, #0x3f]
    // 0xd75e40: DecompressPointer r0
    //     0xd75e40: add             x0, x0, HEAP, lsl #32
    // 0xd75e44: LoadField: r1 = r0->field_7
    //     0xd75e44: ldur            w1, [x0, #7]
    // 0xd75e48: DecompressPointer r1
    //     0xd75e48: add             x1, x1, HEAP, lsl #32
    // 0xd75e4c: mov             x2, x1
    // 0xd75e50: ldur            x1, [fp, #-0x40]
    // 0xd75e54: r0 = brightness=()
    //     0xd75e54: bl              #0xd76814  ; [package:flutter/src/cupertino/checkbox.dart] _CheckboxPainter::brightness=
    // 0xd75e58: ldur            x1, [fp, #-8]
    // 0xd75e5c: ldur            x2, [fp, #-0x58]
    // 0xd75e60: ldur            x3, [fp, #-0x40]
    // 0xd75e64: r5 = Instance_Size
    //     0xd75e64: add             x5, PP, #0xa2, lsl #12  ; [pp+0xa2b18] Obj!Size@12a7771
    //     0xd75e68: ldr             x5, [x5, #0xb18]
    // 0xd75e6c: r0 = buildToggleable()
    //     0xd75e6c: bl              #0xd75eec  ; [dart:mixin_deduplication] _MixinApplication387&State&TickerProviderStateMixin&ToggleableStateMixin::buildToggleable
    // 0xd75e70: stur            x0, [fp, #-8]
    // 0xd75e74: r0 = Semantics()
    //     0xd75e74: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xd75e78: stur            x0, [fp, #-0x10]
    // 0xd75e7c: ldur            x16, [fp, #-0x50]
    // 0xd75e80: stp             x16, NULL, [SP, #0x10]
    // 0xd75e84: ldur            x16, [fp, #-0x48]
    // 0xd75e88: ldur            lr, [fp, #-8]
    // 0xd75e8c: stp             lr, x16, [SP]
    // 0xd75e90: mov             x1, x0
    // 0xd75e94: r4 = const [0, 0x5, 0x4, 0x1, checked, 0x2, child, 0x4, label, 0x1, mixed, 0x3, null]
    //     0xd75e94: add             x4, PP, #0x90, lsl #12  ; [pp+0x90420] List(13) [0, 0x5, 0x4, 0x1, "checked", 0x2, "child", 0x4, "label", 0x1, "mixed", 0x3, Null]
    //     0xd75e98: ldr             x4, [x4, #0x420]
    // 0xd75e9c: r0 = Semantics()
    //     0xd75e9c: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xd75ea0: ldur            x0, [fp, #-0x10]
    // 0xd75ea4: LeaveFrame
    //     0xd75ea4: mov             SP, fp
    //     0xd75ea8: ldp             fp, lr, [SP], #0x10
    // 0xd75eac: ret
    //     0xd75eac: ret             
    // 0xd75eb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd75eb0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd75eb4: b               #0xd75a40
    // 0xd75eb8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd75eb8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd75ebc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd75ebc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd75ec0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd75ec0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd75ec4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd75ec4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd75ec8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd75ec8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd75ecc: r9 = _position
    //     0xd75ecc: add             x9, PP, #0xa2, lsl #12  ; [pp+0xa2b20] Field <_MixinApplication387&State&TickerProviderStateMixin&ToggleableStateMixin@18353248._position@61045596>: late (offset: 0x20)
    //     0xd75ed0: ldr             x9, [x9, #0xb20]
    // 0xd75ed4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd75ed4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd75ed8: r9 = _reaction
    //     0xd75ed8: add             x9, PP, #0xa2, lsl #12  ; [pp+0xa2b28] Field <_MixinApplication387&State&TickerProviderStateMixin&ToggleableStateMixin@18353248._reaction@61045596>: late (offset: 0x28)
    //     0xd75edc: ldr             x9, [x9, #0xb28]
    // 0xd75ee0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd75ee0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd75ee4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd75ee4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd75ee8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd75ee8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _defaultCheckColor(/* No info */) {
    // ** addr: 0xd76960, size: 0x68
    // 0xd76960: EnterFrame
    //     0xd76960: stp             fp, lr, [SP, #-0x10]!
    //     0xd76964: mov             fp, SP
    // 0xd76968: AllocStack(0x18)
    //     0xd76968: sub             SP, SP, #0x18
    // 0xd7696c: SetupParameters(_CupertinoCheckboxState this /* r1 => r1, fp-0x8 */)
    //     0xd7696c: stur            x1, [fp, #-8]
    // 0xd76970: CheckStackOverflow
    //     0xd76970: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd76974: cmp             SP, x16
    //     0xd76978: b.ls            #0xd769c0
    // 0xd7697c: r1 = 1
    //     0xd7697c: mov             x1, #1
    // 0xd76980: r0 = AllocateContext()
    //     0xd76980: bl              #0x13de838  ; AllocateContextStub
    // 0xd76984: mov             x1, x0
    // 0xd76988: ldur            x0, [fp, #-8]
    // 0xd7698c: StoreField: r1->field_f = r0
    //     0xd7698c: stur            w0, [x1, #0xf]
    // 0xd76990: mov             x2, x1
    // 0xd76994: r1 = Function '<anonymous closure>':.
    //     0xd76994: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2ba0] AnonymousClosure: (0xd769c8), in [package:flutter/src/cupertino/checkbox.dart] _CupertinoCheckboxState::_defaultCheckColor (0xd76960)
    //     0xd76998: ldr             x1, [x1, #0xba0]
    // 0xd7699c: r0 = AllocateClosure()
    //     0xd7699c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd769a0: r16 = <Color>
    //     0xd769a0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xd769a4: ldr             x16, [x16, #0xa90]
    // 0xd769a8: stp             x0, x16, [SP]
    // 0xd769ac: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd769ac: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd769b0: r0 = resolveWith()
    //     0xd769b0: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd769b4: LeaveFrame
    //     0xd769b4: mov             SP, fp
    //     0xd769b8: ldp             fp, lr, [SP], #0x10
    // 0xd769bc: ret
    //     0xd769bc: ret             
    // 0xd769c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd769c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd769c4: b               #0xd7697c
  }
  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xd769c8, size: 0x174
    // 0xd769c8: EnterFrame
    //     0xd769c8: stp             fp, lr, [SP, #-0x10]!
    //     0xd769cc: mov             fp, SP
    // 0xd769d0: AllocStack(0x8)
    //     0xd769d0: sub             SP, SP, #8
    // 0xd769d4: SetupParameters([dynamic _ /* r0 */])
    //     0xd769d4: ldr             x0, [fp, #0x18]
    //     0xd769d8: ldur            w3, [x0, #0x17]
    //     0xd769dc: add             x3, x3, HEAP, lsl #32
    //     0xd769e0: stur            x3, [fp, #-8]
    // 0xd769e4: CheckStackOverflow
    //     0xd769e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd769e8: cmp             SP, x16
    //     0xd769ec: b.ls            #0xd76b24
    // 0xd769f0: ldr             x4, [fp, #0x10]
    // 0xd769f4: r0 = LoadClassIdInstr(r4)
    //     0xd769f4: ldur            x0, [x4, #-1]
    //     0xd769f8: ubfx            x0, x0, #0xc, #0x14
    // 0xd769fc: mov             x1, x4
    // 0xd76a00: r2 = Instance_WidgetState
    //     0xd76a00: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xd76a04: ldr             x2, [x2, #0xa70]
    // 0xd76a08: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd76a08: mov             x17, #0x2929
    //     0xd76a0c: movk            x17, #1, lsl #16
    //     0xd76a10: add             lr, x0, x17
    //     0xd76a14: ldr             lr, [x21, lr, lsl #3]
    //     0xd76a18: blr             lr
    // 0xd76a1c: tbnz            w0, #4, #0xd76a9c
    // 0xd76a20: ldr             x3, [fp, #0x10]
    // 0xd76a24: r0 = LoadClassIdInstr(r3)
    //     0xd76a24: ldur            x0, [x3, #-1]
    //     0xd76a28: ubfx            x0, x0, #0xc, #0x14
    // 0xd76a2c: mov             x1, x3
    // 0xd76a30: r2 = Instance_WidgetState
    //     0xd76a30: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xd76a34: ldr             x2, [x2, #0x100]
    // 0xd76a38: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd76a38: mov             x17, #0x2929
    //     0xd76a3c: movk            x17, #1, lsl #16
    //     0xd76a40: add             lr, x0, x17
    //     0xd76a44: ldr             lr, [x21, lr, lsl #3]
    //     0xd76a48: blr             lr
    // 0xd76a4c: tbnz            w0, #4, #0xd76a94
    // 0xd76a50: ldur            x3, [fp, #-8]
    // 0xd76a54: LoadField: r0 = r3->field_f
    //     0xd76a54: ldur            w0, [x3, #0xf]
    // 0xd76a58: DecompressPointer r0
    //     0xd76a58: add             x0, x0, HEAP, lsl #32
    // 0xd76a5c: LoadField: r1 = r0->field_b
    //     0xd76a5c: ldur            w1, [x0, #0xb]
    // 0xd76a60: DecompressPointer r1
    //     0xd76a60: add             x1, x1, HEAP, lsl #32
    // 0xd76a64: cmp             w1, NULL
    // 0xd76a68: b.eq            #0xd76b2c
    // 0xd76a6c: LoadField: r2 = r0->field_f
    //     0xd76a6c: ldur            w2, [x0, #0xf]
    // 0xd76a70: DecompressPointer r2
    //     0xd76a70: add             x2, x2, HEAP, lsl #32
    // 0xd76a74: cmp             w2, NULL
    // 0xd76a78: b.eq            #0xd76b30
    // 0xd76a7c: r1 = Instance_CupertinoDynamicColor
    //     0xd76a7c: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2ba8] Obj!CupertinoDynamicColor@12b3971
    //     0xd76a80: ldr             x1, [x1, #0xba8]
    // 0xd76a84: r0 = resolveFrom()
    //     0xd76a84: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0xd76a88: LeaveFrame
    //     0xd76a88: mov             SP, fp
    //     0xd76a8c: ldp             fp, lr, [SP], #0x10
    // 0xd76a90: ret
    //     0xd76a90: ret             
    // 0xd76a94: ldur            x3, [fp, #-8]
    // 0xd76a98: b               #0xd76aa0
    // 0xd76a9c: ldur            x3, [fp, #-8]
    // 0xd76aa0: ldr             x1, [fp, #0x10]
    // 0xd76aa4: r0 = LoadClassIdInstr(r1)
    //     0xd76aa4: ldur            x0, [x1, #-1]
    //     0xd76aa8: ubfx            x0, x0, #0xc, #0x14
    // 0xd76aac: r2 = Instance_WidgetState
    //     0xd76aac: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xd76ab0: ldr             x2, [x2, #0x100]
    // 0xd76ab4: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd76ab4: mov             x17, #0x2929
    //     0xd76ab8: movk            x17, #1, lsl #16
    //     0xd76abc: add             lr, x0, x17
    //     0xd76ac0: ldr             lr, [x21, lr, lsl #3]
    //     0xd76ac4: blr             lr
    // 0xd76ac8: tbnz            w0, #4, #0xd76b10
    // 0xd76acc: ldur            x0, [fp, #-8]
    // 0xd76ad0: LoadField: r1 = r0->field_f
    //     0xd76ad0: ldur            w1, [x0, #0xf]
    // 0xd76ad4: DecompressPointer r1
    //     0xd76ad4: add             x1, x1, HEAP, lsl #32
    // 0xd76ad8: LoadField: r0 = r1->field_b
    //     0xd76ad8: ldur            w0, [x1, #0xb]
    // 0xd76adc: DecompressPointer r0
    //     0xd76adc: add             x0, x0, HEAP, lsl #32
    // 0xd76ae0: cmp             w0, NULL
    // 0xd76ae4: b.eq            #0xd76b34
    // 0xd76ae8: LoadField: r2 = r1->field_f
    //     0xd76ae8: ldur            w2, [x1, #0xf]
    // 0xd76aec: DecompressPointer r2
    //     0xd76aec: add             x2, x2, HEAP, lsl #32
    // 0xd76af0: cmp             w2, NULL
    // 0xd76af4: b.eq            #0xd76b38
    // 0xd76af8: r1 = Instance_CupertinoDynamicColor
    //     0xd76af8: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2bb0] Obj!CupertinoDynamicColor@12b3931
    //     0xd76afc: ldr             x1, [x1, #0xbb0]
    // 0xd76b00: r0 = resolveFrom()
    //     0xd76b00: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0xd76b04: LeaveFrame
    //     0xd76b04: mov             SP, fp
    //     0xd76b08: ldp             fp, lr, [SP], #0x10
    // 0xd76b0c: ret
    //     0xd76b0c: ret             
    // 0xd76b10: r0 = Instance_Color
    //     0xd76b10: add             x0, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0xd76b14: ldr             x0, [x0, #0xc38]
    // 0xd76b18: LeaveFrame
    //     0xd76b18: mov             SP, fp
    //     0xd76b1c: ldp             fp, lr, [SP], #0x10
    // 0xd76b20: ret
    //     0xd76b20: ret             
    // 0xd76b24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd76b24: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd76b28: b               #0xd769f0
    // 0xd76b2c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd76b2c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd76b30: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd76b30: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd76b34: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd76b34: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd76b38: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd76b38: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _defaultSide(/* No info */) {
    // ** addr: 0xd76b3c, size: 0x68
    // 0xd76b3c: EnterFrame
    //     0xd76b3c: stp             fp, lr, [SP, #-0x10]!
    //     0xd76b40: mov             fp, SP
    // 0xd76b44: AllocStack(0x18)
    //     0xd76b44: sub             SP, SP, #0x18
    // 0xd76b48: SetupParameters(_CupertinoCheckboxState this /* r1 => r1, fp-0x8 */)
    //     0xd76b48: stur            x1, [fp, #-8]
    // 0xd76b4c: CheckStackOverflow
    //     0xd76b4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd76b50: cmp             SP, x16
    //     0xd76b54: b.ls            #0xd76b9c
    // 0xd76b58: r1 = 1
    //     0xd76b58: mov             x1, #1
    // 0xd76b5c: r0 = AllocateContext()
    //     0xd76b5c: bl              #0x13de838  ; AllocateContextStub
    // 0xd76b60: mov             x1, x0
    // 0xd76b64: ldur            x0, [fp, #-8]
    // 0xd76b68: StoreField: r1->field_f = r0
    //     0xd76b68: stur            w0, [x1, #0xf]
    // 0xd76b6c: mov             x2, x1
    // 0xd76b70: r1 = Function '<anonymous closure>':.
    //     0xd76b70: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2bb8] AnonymousClosure: (0xd76ba4), in [package:flutter/src/cupertino/checkbox.dart] _CupertinoCheckboxState::_defaultSide (0xd76b3c)
    //     0xd76b74: ldr             x1, [x1, #0xbb8]
    // 0xd76b78: r0 = AllocateClosure()
    //     0xd76b78: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd76b7c: r16 = <BorderSide>
    //     0xd76b7c: add             x16, PP, #0x80, lsl #12  ; [pp+0x80c98] TypeArguments: <BorderSide>
    //     0xd76b80: ldr             x16, [x16, #0xc98]
    // 0xd76b84: stp             x0, x16, [SP]
    // 0xd76b88: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd76b88: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd76b8c: r0 = resolveWith()
    //     0xd76b8c: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd76b90: LeaveFrame
    //     0xd76b90: mov             SP, fp
    //     0xd76b94: ldp             fp, lr, [SP], #0x10
    // 0xd76b98: ret
    //     0xd76b98: ret             
    // 0xd76b9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd76b9c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd76ba0: b               #0xd76b58
  }
  [closure] BorderSide <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xd76ba4, size: 0x1e0
    // 0xd76ba4: EnterFrame
    //     0xd76ba4: stp             fp, lr, [SP, #-0x10]!
    //     0xd76ba8: mov             fp, SP
    // 0xd76bac: AllocStack(0x10)
    //     0xd76bac: sub             SP, SP, #0x10
    // 0xd76bb0: SetupParameters([dynamic _ /* r0 */])
    //     0xd76bb0: ldr             x0, [fp, #0x18]
    //     0xd76bb4: ldur            w3, [x0, #0x17]
    //     0xd76bb8: add             x3, x3, HEAP, lsl #32
    //     0xd76bbc: stur            x3, [fp, #-8]
    // 0xd76bc0: CheckStackOverflow
    //     0xd76bc0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd76bc4: cmp             SP, x16
    //     0xd76bc8: b.ls            #0xd76d74
    // 0xd76bcc: ldr             x4, [fp, #0x10]
    // 0xd76bd0: r0 = LoadClassIdInstr(r4)
    //     0xd76bd0: ldur            x0, [x4, #-1]
    //     0xd76bd4: ubfx            x0, x0, #0xc, #0x14
    // 0xd76bd8: mov             x1, x4
    // 0xd76bdc: r2 = Instance_WidgetState
    //     0xd76bdc: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xd76be0: ldr             x2, [x2, #0x100]
    // 0xd76be4: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd76be4: mov             x17, #0x2929
    //     0xd76be8: movk            x17, #1, lsl #16
    //     0xd76bec: add             lr, x0, x17
    //     0xd76bf0: ldr             lr, [x21, lr, lsl #3]
    //     0xd76bf4: blr             lr
    // 0xd76bf8: tbz             w0, #4, #0xd76c2c
    // 0xd76bfc: ldr             x3, [fp, #0x10]
    // 0xd76c00: r0 = LoadClassIdInstr(r3)
    //     0xd76c00: ldur            x0, [x3, #-1]
    //     0xd76c04: ubfx            x0, x0, #0xc, #0x14
    // 0xd76c08: mov             x1, x3
    // 0xd76c0c: r2 = Instance_WidgetState
    //     0xd76c0c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xd76c10: ldr             x2, [x2, #0xa60]
    // 0xd76c14: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd76c14: mov             x17, #0x2929
    //     0xd76c18: movk            x17, #1, lsl #16
    //     0xd76c1c: add             lr, x0, x17
    //     0xd76c20: ldr             lr, [x21, lr, lsl #3]
    //     0xd76c24: blr             lr
    // 0xd76c28: tbnz            w0, #4, #0xd76c70
    // 0xd76c2c: ldr             x3, [fp, #0x10]
    // 0xd76c30: r0 = LoadClassIdInstr(r3)
    //     0xd76c30: ldur            x0, [x3, #-1]
    //     0xd76c34: ubfx            x0, x0, #0xc, #0x14
    // 0xd76c38: mov             x1, x3
    // 0xd76c3c: r2 = Instance_WidgetState
    //     0xd76c3c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xd76c40: ldr             x2, [x2, #0xa70]
    // 0xd76c44: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd76c44: mov             x17, #0x2929
    //     0xd76c48: movk            x17, #1, lsl #16
    //     0xd76c4c: add             lr, x0, x17
    //     0xd76c50: ldr             lr, [x21, lr, lsl #3]
    //     0xd76c54: blr             lr
    // 0xd76c58: tbz             w0, #4, #0xd76c70
    // 0xd76c5c: r0 = Instance_BorderSide
    //     0xd76c5c: add             x0, PP, #0x26, lsl #12  ; [pp+0x264f8] Obj!BorderSide@12b1b71
    //     0xd76c60: ldr             x0, [x0, #0x4f8]
    // 0xd76c64: LeaveFrame
    //     0xd76c64: mov             SP, fp
    //     0xd76c68: ldp             fp, lr, [SP], #0x10
    // 0xd76c6c: ret
    //     0xd76c6c: ret             
    // 0xd76c70: ldr             x1, [fp, #0x10]
    // 0xd76c74: r0 = LoadClassIdInstr(r1)
    //     0xd76c74: ldur            x0, [x1, #-1]
    //     0xd76c78: ubfx            x0, x0, #0xc, #0x14
    // 0xd76c7c: r2 = Instance_WidgetState
    //     0xd76c7c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xd76c80: ldr             x2, [x2, #0xa70]
    // 0xd76c84: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd76c84: mov             x17, #0x2929
    //     0xd76c88: movk            x17, #1, lsl #16
    //     0xd76c8c: add             lr, x0, x17
    //     0xd76c90: ldr             lr, [x21, lr, lsl #3]
    //     0xd76c94: blr             lr
    // 0xd76c98: tbnz            w0, #4, #0xd76d04
    // 0xd76c9c: ldur            x0, [fp, #-8]
    // 0xd76ca0: LoadField: r1 = r0->field_f
    //     0xd76ca0: ldur            w1, [x0, #0xf]
    // 0xd76ca4: DecompressPointer r1
    //     0xd76ca4: add             x1, x1, HEAP, lsl #32
    // 0xd76ca8: LoadField: r2 = r1->field_f
    //     0xd76ca8: ldur            w2, [x1, #0xf]
    // 0xd76cac: DecompressPointer r2
    //     0xd76cac: add             x2, x2, HEAP, lsl #32
    // 0xd76cb0: cmp             w2, NULL
    // 0xd76cb4: b.eq            #0xd76d7c
    // 0xd76cb8: r1 = Instance_CupertinoDynamicColor
    //     0xd76cb8: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2bc0] Obj!CupertinoDynamicColor@12b39f1
    //     0xd76cbc: ldr             x1, [x1, #0xbc0]
    // 0xd76cc0: r0 = resolveFrom()
    //     0xd76cc0: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0xd76cc4: stur            x0, [fp, #-0x10]
    // 0xd76cc8: r0 = BorderSide()
    //     0xd76cc8: bl              #0x8a73bc  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0xd76ccc: mov             x1, x0
    // 0xd76cd0: ldur            x0, [fp, #-0x10]
    // 0xd76cd4: StoreField: r1->field_7 = r0
    //     0xd76cd4: stur            w0, [x1, #7]
    // 0xd76cd8: d0 = 1.000000
    //     0xd76cd8: fmov            d0, #1.00000000
    // 0xd76cdc: StoreField: r1->field_b = d0
    //     0xd76cdc: stur            d0, [x1, #0xb]
    // 0xd76ce0: r3 = Instance_BorderStyle
    //     0xd76ce0: add             x3, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0xd76ce4: ldr             x3, [x3, #0xdc8]
    // 0xd76ce8: StoreField: r1->field_13 = r3
    //     0xd76ce8: stur            w3, [x1, #0x13]
    // 0xd76cec: d1 = -1.000000
    //     0xd76cec: fmov            d1, #-1.00000000
    // 0xd76cf0: ArrayStore: r1[0] = d1  ; List_8
    //     0xd76cf0: stur            d1, [x1, #0x17]
    // 0xd76cf4: mov             x0, x1
    // 0xd76cf8: LeaveFrame
    //     0xd76cf8: mov             SP, fp
    //     0xd76cfc: ldp             fp, lr, [SP], #0x10
    // 0xd76d00: ret
    //     0xd76d00: ret             
    // 0xd76d04: ldur            x0, [fp, #-8]
    // 0xd76d08: r3 = Instance_BorderStyle
    //     0xd76d08: add             x3, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0xd76d0c: ldr             x3, [x3, #0xdc8]
    // 0xd76d10: d0 = 1.000000
    //     0xd76d10: fmov            d0, #1.00000000
    // 0xd76d14: d1 = -1.000000
    //     0xd76d14: fmov            d1, #-1.00000000
    // 0xd76d18: LoadField: r1 = r0->field_f
    //     0xd76d18: ldur            w1, [x0, #0xf]
    // 0xd76d1c: DecompressPointer r1
    //     0xd76d1c: add             x1, x1, HEAP, lsl #32
    // 0xd76d20: LoadField: r2 = r1->field_f
    //     0xd76d20: ldur            w2, [x1, #0xf]
    // 0xd76d24: DecompressPointer r2
    //     0xd76d24: add             x2, x2, HEAP, lsl #32
    // 0xd76d28: cmp             w2, NULL
    // 0xd76d2c: b.eq            #0xd76d80
    // 0xd76d30: r1 = Instance_CupertinoDynamicColor
    //     0xd76d30: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2bc8] Obj!CupertinoDynamicColor@12b39b1
    //     0xd76d34: ldr             x1, [x1, #0xbc8]
    // 0xd76d38: r0 = resolveFrom()
    //     0xd76d38: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0xd76d3c: stur            x0, [fp, #-8]
    // 0xd76d40: r0 = BorderSide()
    //     0xd76d40: bl              #0x8a73bc  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0xd76d44: ldur            x1, [fp, #-8]
    // 0xd76d48: StoreField: r0->field_7 = r1
    //     0xd76d48: stur            w1, [x0, #7]
    // 0xd76d4c: d0 = 1.000000
    //     0xd76d4c: fmov            d0, #1.00000000
    // 0xd76d50: StoreField: r0->field_b = d0
    //     0xd76d50: stur            d0, [x0, #0xb]
    // 0xd76d54: r1 = Instance_BorderStyle
    //     0xd76d54: add             x1, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0xd76d58: ldr             x1, [x1, #0xdc8]
    // 0xd76d5c: StoreField: r0->field_13 = r1
    //     0xd76d5c: stur            w1, [x0, #0x13]
    // 0xd76d60: d0 = -1.000000
    //     0xd76d60: fmov            d0, #-1.00000000
    // 0xd76d64: ArrayStore: r0[0] = d0  ; List_8
    //     0xd76d64: stur            d0, [x0, #0x17]
    // 0xd76d68: LeaveFrame
    //     0xd76d68: mov             SP, fp
    //     0xd76d6c: ldp             fp, lr, [SP], #0x10
    // 0xd76d70: ret
    //     0xd76d70: ret             
    // 0xd76d74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd76d74: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd76d78: b               #0xd76bcc
    // 0xd76d7c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd76d7c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd76d80: r0 = NullCastErrorSharedWithFPURegs()
    //     0xd76d80: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  _ _resolveSide(/* No info */) {
    // ** addr: 0xd76d84, size: 0x54
    // 0xd76d84: EnterFrame
    //     0xd76d84: stp             fp, lr, [SP, #-0x10]!
    //     0xd76d88: mov             fp, SP
    // 0xd76d8c: mov             x0, x1
    // 0xd76d90: mov             x1, x2
    // 0xd76d94: CheckStackOverflow
    //     0xd76d94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd76d98: cmp             SP, x16
    //     0xd76d9c: b.ls            #0xd76dd0
    // 0xd76da0: r2 = Instance_WidgetState
    //     0xd76da0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xd76da4: ldr             x2, [x2, #0x100]
    // 0xd76da8: r0 = contains()
    //     0xd76da8: bl              #0xbafbf4  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0xd76dac: tbz             w0, #4, #0xd76dc0
    // 0xd76db0: r0 = Null
    //     0xd76db0: mov             x0, NULL
    // 0xd76db4: LeaveFrame
    //     0xd76db4: mov             SP, fp
    //     0xd76db8: ldp             fp, lr, [SP], #0x10
    // 0xd76dbc: ret
    //     0xd76dbc: ret             
    // 0xd76dc0: r0 = Null
    //     0xd76dc0: mov             x0, NULL
    // 0xd76dc4: LeaveFrame
    //     0xd76dc4: mov             SP, fp
    //     0xd76dc8: ldp             fp, lr, [SP], #0x10
    // 0xd76dcc: ret
    //     0xd76dcc: ret             
    // 0xd76dd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd76dd0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd76dd4: b               #0xd76da0
  }
  get _ _defaultFillColor(/* No info */) {
    // ** addr: 0xd76dd8, size: 0x68
    // 0xd76dd8: EnterFrame
    //     0xd76dd8: stp             fp, lr, [SP, #-0x10]!
    //     0xd76ddc: mov             fp, SP
    // 0xd76de0: AllocStack(0x18)
    //     0xd76de0: sub             SP, SP, #0x18
    // 0xd76de4: SetupParameters(_CupertinoCheckboxState this /* r1 => r1, fp-0x8 */)
    //     0xd76de4: stur            x1, [fp, #-8]
    // 0xd76de8: CheckStackOverflow
    //     0xd76de8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd76dec: cmp             SP, x16
    //     0xd76df0: b.ls            #0xd76e38
    // 0xd76df4: r1 = 1
    //     0xd76df4: mov             x1, #1
    // 0xd76df8: r0 = AllocateContext()
    //     0xd76df8: bl              #0x13de838  ; AllocateContextStub
    // 0xd76dfc: mov             x1, x0
    // 0xd76e00: ldur            x0, [fp, #-8]
    // 0xd76e04: StoreField: r1->field_f = r0
    //     0xd76e04: stur            w0, [x1, #0xf]
    // 0xd76e08: mov             x2, x1
    // 0xd76e0c: r1 = Function '<anonymous closure>':.
    //     0xd76e0c: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2b08] AnonymousClosure: (0xd76eb4), in [package:flutter/src/cupertino/checkbox.dart] _CupertinoCheckboxState::_defaultFillColor (0xd76dd8)
    //     0xd76e10: ldr             x1, [x1, #0xb08]
    // 0xd76e14: r0 = AllocateClosure()
    //     0xd76e14: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd76e18: r16 = <Color>
    //     0xd76e18: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xd76e1c: ldr             x16, [x16, #0xa90]
    // 0xd76e20: stp             x0, x16, [SP]
    // 0xd76e24: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd76e24: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd76e28: r0 = resolveWith()
    //     0xd76e28: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xd76e2c: LeaveFrame
    //     0xd76e2c: mov             SP, fp
    //     0xd76e30: ldp             fp, lr, [SP], #0x10
    // 0xd76e34: ret
    //     0xd76e34: ret             
    // 0xd76e38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd76e38: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd76e3c: b               #0xd76df4
  }
  [closure] MouseCursor <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xd76e40, size: 0x74
    // 0xd76e40: EnterFrame
    //     0xd76e40: stp             fp, lr, [SP, #-0x10]!
    //     0xd76e44: mov             fp, SP
    // 0xd76e48: AllocStack(0x18)
    //     0xd76e48: sub             SP, SP, #0x18
    // 0xd76e4c: SetupParameters([dynamic _ /* r0 */])
    //     0xd76e4c: ldr             x0, [fp, #0x18]
    //     0xd76e50: ldur            w1, [x0, #0x17]
    //     0xd76e54: add             x1, x1, HEAP, lsl #32
    // 0xd76e58: CheckStackOverflow
    //     0xd76e58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd76e5c: cmp             SP, x16
    //     0xd76e60: b.ls            #0xd76ea8
    // 0xd76e64: LoadField: r0 = r1->field_f
    //     0xd76e64: ldur            w0, [x1, #0xf]
    // 0xd76e68: DecompressPointer r0
    //     0xd76e68: add             x0, x0, HEAP, lsl #32
    // 0xd76e6c: LoadField: r1 = r0->field_b
    //     0xd76e6c: ldur            w1, [x0, #0xb]
    // 0xd76e70: DecompressPointer r1
    //     0xd76e70: add             x1, x1, HEAP, lsl #32
    // 0xd76e74: cmp             w1, NULL
    // 0xd76e78: b.eq            #0xd76eb0
    // 0xd76e7c: r16 = <MouseCursor?>
    //     0xd76e7c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15ab8] TypeArguments: <MouseCursor?>
    //     0xd76e80: ldr             x16, [x16, #0xab8]
    // 0xd76e84: stp             NULL, x16, [SP, #8]
    // 0xd76e88: ldr             x16, [fp, #0x10]
    // 0xd76e8c: str             x16, [SP]
    // 0xd76e90: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xd76e90: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xd76e94: r0 = resolveAs()
    //     0xd76e94: bl              #0x8de57c  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveAs
    // 0xd76e98: r0 = Instance_SystemMouseCursor
    //     0xd76e98: ldr             x0, [PP, #0x21b0]  ; [pp+0x21b0] Obj!SystemMouseCursor@12b3201
    // 0xd76e9c: LeaveFrame
    //     0xd76e9c: mov             SP, fp
    //     0xd76ea0: ldp             fp, lr, [SP], #0x10
    // 0xd76ea4: ret
    //     0xd76ea4: ret             
    // 0xd76ea8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd76ea8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd76eac: b               #0xd76e64
    // 0xd76eb0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd76eb0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xd76eb4, size: 0x120
    // 0xd76eb4: EnterFrame
    //     0xd76eb4: stp             fp, lr, [SP, #-0x10]!
    //     0xd76eb8: mov             fp, SP
    // 0xd76ebc: AllocStack(0x8)
    //     0xd76ebc: sub             SP, SP, #8
    // 0xd76ec0: SetupParameters([dynamic _ /* r0 */])
    //     0xd76ec0: ldr             x0, [fp, #0x18]
    //     0xd76ec4: ldur            w3, [x0, #0x17]
    //     0xd76ec8: add             x3, x3, HEAP, lsl #32
    //     0xd76ecc: stur            x3, [fp, #-8]
    // 0xd76ed0: CheckStackOverflow
    //     0xd76ed0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd76ed4: cmp             SP, x16
    //     0xd76ed8: b.ls            #0xd76fc4
    // 0xd76edc: ldr             x4, [fp, #0x10]
    // 0xd76ee0: r0 = LoadClassIdInstr(r4)
    //     0xd76ee0: ldur            x0, [x4, #-1]
    //     0xd76ee4: ubfx            x0, x0, #0xc, #0x14
    // 0xd76ee8: mov             x1, x4
    // 0xd76eec: r2 = Instance_WidgetState
    //     0xd76eec: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xd76ef0: ldr             x2, [x2, #0xa70]
    // 0xd76ef4: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd76ef4: mov             x17, #0x2929
    //     0xd76ef8: movk            x17, #1, lsl #16
    //     0xd76efc: add             lr, x0, x17
    //     0xd76f00: ldr             lr, [x21, lr, lsl #3]
    //     0xd76f04: blr             lr
    // 0xd76f08: tbnz            w0, #4, #0xd76f28
    // 0xd76f0c: r1 = Instance_Color
    //     0xd76f0c: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0xd76f10: ldr             x1, [x1, #0xc38]
    // 0xd76f14: d0 = 0.500000
    //     0xd76f14: fmov            d0, #0.50000000
    // 0xd76f18: r0 = withOpacity()
    //     0xd76f18: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xd76f1c: LeaveFrame
    //     0xd76f1c: mov             SP, fp
    //     0xd76f20: ldp             fp, lr, [SP], #0x10
    // 0xd76f24: ret
    //     0xd76f24: ret             
    // 0xd76f28: ldr             x1, [fp, #0x10]
    // 0xd76f2c: r0 = LoadClassIdInstr(r1)
    //     0xd76f2c: ldur            x0, [x1, #-1]
    //     0xd76f30: ubfx            x0, x0, #0xc, #0x14
    // 0xd76f34: r2 = Instance_WidgetState
    //     0xd76f34: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xd76f38: ldr             x2, [x2, #0x100]
    // 0xd76f3c: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd76f3c: mov             x17, #0x2929
    //     0xd76f40: movk            x17, #1, lsl #16
    //     0xd76f44: add             lr, x0, x17
    //     0xd76f48: ldr             lr, [x21, lr, lsl #3]
    //     0xd76f4c: blr             lr
    // 0xd76f50: tbnz            w0, #4, #0xd76fb0
    // 0xd76f54: ldur            x0, [fp, #-8]
    // 0xd76f58: LoadField: r1 = r0->field_f
    //     0xd76f58: ldur            w1, [x0, #0xf]
    // 0xd76f5c: DecompressPointer r1
    //     0xd76f5c: add             x1, x1, HEAP, lsl #32
    // 0xd76f60: LoadField: r0 = r1->field_b
    //     0xd76f60: ldur            w0, [x1, #0xb]
    // 0xd76f64: DecompressPointer r0
    //     0xd76f64: add             x0, x0, HEAP, lsl #32
    // 0xd76f68: cmp             w0, NULL
    // 0xd76f6c: b.eq            #0xd76fcc
    // 0xd76f70: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xd76f70: ldur            w2, [x0, #0x17]
    // 0xd76f74: DecompressPointer r2
    //     0xd76f74: add             x2, x2, HEAP, lsl #32
    // 0xd76f78: cmp             w2, NULL
    // 0xd76f7c: b.ne            #0xd76fa0
    // 0xd76f80: LoadField: r2 = r1->field_f
    //     0xd76f80: ldur            w2, [x1, #0xf]
    // 0xd76f84: DecompressPointer r2
    //     0xd76f84: add             x2, x2, HEAP, lsl #32
    // 0xd76f88: cmp             w2, NULL
    // 0xd76f8c: b.eq            #0xd76fd0
    // 0xd76f90: r1 = Instance_CupertinoDynamicColor
    //     0xd76f90: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2b30] Obj!CupertinoDynamicColor@12b3a31
    //     0xd76f94: ldr             x1, [x1, #0xb30]
    // 0xd76f98: r0 = resolveFrom()
    //     0xd76f98: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0xd76f9c: b               #0xd76fa4
    // 0xd76fa0: mov             x0, x2
    // 0xd76fa4: LeaveFrame
    //     0xd76fa4: mov             SP, fp
    //     0xd76fa8: ldp             fp, lr, [SP], #0x10
    // 0xd76fac: ret
    //     0xd76fac: ret             
    // 0xd76fb0: r0 = Instance_Color
    //     0xd76fb0: add             x0, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0xd76fb4: ldr             x0, [x0, #0xc38]
    // 0xd76fb8: LeaveFrame
    //     0xd76fb8: mov             SP, fp
    //     0xd76fbc: ldp             fp, lr, [SP], #0x10
    // 0xd76fc0: ret
    //     0xd76fc0: ret             
    // 0xd76fc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd76fc4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd76fc8: b               #0xd76edc
    // 0xd76fcc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd76fcc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd76fd0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd76fd0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf45018, size: 0xdc
    // 0xf45018: EnterFrame
    //     0xf45018: stp             fp, lr, [SP, #-0x10]!
    //     0xf4501c: mov             fp, SP
    // 0xf45020: AllocStack(0x10)
    //     0xf45020: sub             SP, SP, #0x10
    // 0xf45024: SetupParameters(_CupertinoCheckboxState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xf45024: mov             x0, x2
    //     0xf45028: mov             x4, x1
    //     0xf4502c: mov             x3, x2
    //     0xf45030: stur            x1, [fp, #-8]
    //     0xf45034: stur            x2, [fp, #-0x10]
    // 0xf45038: r2 = Null
    //     0xf45038: mov             x2, NULL
    // 0xf4503c: r1 = Null
    //     0xf4503c: mov             x1, NULL
    // 0xf45040: r4 = 60
    //     0xf45040: mov             x4, #0x3c
    // 0xf45044: branchIfSmi(r0, 0xf45050)
    //     0xf45044: tbz             w0, #0, #0xf45050
    // 0xf45048: r4 = LoadClassIdInstr(r0)
    //     0xf45048: ldur            x4, [x0, #-1]
    //     0xf4504c: ubfx            x4, x4, #0xc, #0x14
    // 0xf45050: r17 = 6527
    //     0xf45050: mov             x17, #0x197f
    // 0xf45054: cmp             x4, x17
    // 0xf45058: b.eq            #0xf45070
    // 0xf4505c: r8 = CupertinoCheckbox
    //     0xf4505c: add             x8, PP, #0xa2, lsl #12  ; [pp+0xa2bd0] Type: CupertinoCheckbox
    //     0xf45060: ldr             x8, [x8, #0xbd0]
    // 0xf45064: r3 = Null
    //     0xf45064: add             x3, PP, #0xa2, lsl #12  ; [pp+0xa2bd8] Null
    //     0xf45068: ldr             x3, [x3, #0xbd8]
    // 0xf4506c: r0 = CupertinoCheckbox()
    //     0xf4506c: bl              #0xad6dc4  ; IsType_CupertinoCheckbox_Stub
    // 0xf45070: ldur            x3, [fp, #-8]
    // 0xf45074: LoadField: r2 = r3->field_7
    //     0xf45074: ldur            w2, [x3, #7]
    // 0xf45078: DecompressPointer r2
    //     0xf45078: add             x2, x2, HEAP, lsl #32
    // 0xf4507c: ldur            x0, [fp, #-0x10]
    // 0xf45080: r1 = Null
    //     0xf45080: mov             x1, NULL
    // 0xf45084: cmp             w2, NULL
    // 0xf45088: b.eq            #0xf450ac
    // 0xf4508c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf4508c: ldur            w4, [x2, #0x17]
    // 0xf45090: DecompressPointer r4
    //     0xf45090: add             x4, x4, HEAP, lsl #32
    // 0xf45094: r8 = X0 bound StatefulWidget
    //     0xf45094: add             x8, PP, #0x12, lsl #12  ; [pp+0x12498] TypeParameter: X0 bound StatefulWidget
    //     0xf45098: ldr             x8, [x8, #0x498]
    // 0xf4509c: LoadField: r9 = r4->field_7
    //     0xf4509c: ldur            x9, [x4, #7]
    // 0xf450a0: r3 = Null
    //     0xf450a0: add             x3, PP, #0xa2, lsl #12  ; [pp+0xa2be8] Null
    //     0xf450a4: ldr             x3, [x3, #0xbe8]
    // 0xf450a8: blr             x9
    // 0xf450ac: ldur            x1, [fp, #-0x10]
    // 0xf450b0: LoadField: r2 = r1->field_b
    //     0xf450b0: ldur            w2, [x1, #0xb]
    // 0xf450b4: DecompressPointer r2
    //     0xf450b4: add             x2, x2, HEAP, lsl #32
    // 0xf450b8: ldur            x1, [fp, #-8]
    // 0xf450bc: LoadField: r3 = r1->field_b
    //     0xf450bc: ldur            w3, [x1, #0xb]
    // 0xf450c0: DecompressPointer r3
    //     0xf450c0: add             x3, x3, HEAP, lsl #32
    // 0xf450c4: cmp             w3, NULL
    // 0xf450c8: b.eq            #0xf450f0
    // 0xf450cc: LoadField: r4 = r3->field_b
    //     0xf450cc: ldur            w4, [x3, #0xb]
    // 0xf450d0: DecompressPointer r4
    //     0xf450d0: add             x4, x4, HEAP, lsl #32
    // 0xf450d4: cmp             w2, w4
    // 0xf450d8: b.eq            #0xf450e0
    // 0xf450dc: StoreField: r1->field_53 = r2
    //     0xf450dc: stur            w2, [x1, #0x53]
    // 0xf450e0: r0 = Null
    //     0xf450e0: mov             x0, NULL
    // 0xf450e4: LeaveFrame
    //     0xf450e4: mov             SP, fp
    //     0xf450e8: ldp             fp, lr, [SP], #0x10
    // 0xf450ec: ret
    //     0xf450ec: ret             
    // 0xf450f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf450f0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0xf86dc8, size: 0x64
    // 0xf86dc8: EnterFrame
    //     0xf86dc8: stp             fp, lr, [SP, #-0x10]!
    //     0xf86dcc: mov             fp, SP
    // 0xf86dd0: AllocStack(0x8)
    //     0xf86dd0: sub             SP, SP, #8
    // 0xf86dd4: SetupParameters(_CupertinoCheckboxState this /* r1 => r0, fp-0x8 */)
    //     0xf86dd4: mov             x0, x1
    //     0xf86dd8: stur            x1, [fp, #-8]
    // 0xf86ddc: CheckStackOverflow
    //     0xf86ddc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf86de0: cmp             SP, x16
    //     0xf86de4: b.ls            #0xf86e20
    // 0xf86de8: mov             x1, x0
    // 0xf86dec: r0 = initState()
    //     0xf86dec: bl              #0xf7938c  ; [dart:mixin_deduplication] _MixinApplication26&State&TickerProviderStateMixin&ToggleableStateMixin::initState
    // 0xf86df0: ldur            x1, [fp, #-8]
    // 0xf86df4: LoadField: r2 = r1->field_b
    //     0xf86df4: ldur            w2, [x1, #0xb]
    // 0xf86df8: DecompressPointer r2
    //     0xf86df8: add             x2, x2, HEAP, lsl #32
    // 0xf86dfc: cmp             w2, NULL
    // 0xf86e00: b.eq            #0xf86e28
    // 0xf86e04: LoadField: r3 = r2->field_b
    //     0xf86e04: ldur            w3, [x2, #0xb]
    // 0xf86e08: DecompressPointer r3
    //     0xf86e08: add             x3, x3, HEAP, lsl #32
    // 0xf86e0c: StoreField: r1->field_53 = r3
    //     0xf86e0c: stur            w3, [x1, #0x53]
    // 0xf86e10: r0 = Null
    //     0xf86e10: mov             x0, NULL
    // 0xf86e14: LeaveFrame
    //     0xf86e14: mov             SP, fp
    //     0xf86e18: ldp             fp, lr, [SP], #0x10
    // 0xf86e1c: ret
    //     0xf86e1c: ret             
    // 0xf86e20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf86e20: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf86e24: b               #0xf86de8
    // 0xf86e28: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf86e28: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _CupertinoCheckboxState(/* No info */) {
    // ** addr: 0xfa0294, size: 0x94
    // 0xfa0294: EnterFrame
    //     0xfa0294: stp             fp, lr, [SP, #-0x10]!
    //     0xfa0298: mov             fp, SP
    // 0xfa029c: AllocStack(0x10)
    //     0xfa029c: sub             SP, SP, #0x10
    // 0xfa02a0: SetupParameters(_CupertinoCheckboxState this /* r1 => r1, fp-0x8 */)
    //     0xfa02a0: stur            x1, [fp, #-8]
    // 0xfa02a4: CheckStackOverflow
    //     0xfa02a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa02a8: cmp             SP, x16
    //     0xfa02ac: b.ls            #0xfa0320
    // 0xfa02b0: r0 = _CheckboxPainter()
    //     0xfa02b0: bl              #0xfa036c  ; Allocate_CheckboxPainterStub -> _CheckboxPainter (size=0x78)
    // 0xfa02b4: stur            x0, [fp, #-0x10]
    // 0xfa02b8: StoreField: r0->field_7 = rZR
    //     0xfa02b8: stur            xzr, [x0, #7]
    // 0xfa02bc: StoreField: r0->field_13 = rZR
    //     0xfa02bc: stur            xzr, [x0, #0x13]
    // 0xfa02c0: StoreField: r0->field_1b = rZR
    //     0xfa02c0: stur            xzr, [x0, #0x1b]
    // 0xfa02c4: r0 = LoadStaticField(0x45c)
    //     0xfa02c4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xfa02c8: ldr             x0, [x0, #0x8b8]
    // 0xfa02cc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa02d0: cmp             w0, w16
    // 0xfa02d4: b.ne            #0xfa02e0
    // 0xfa02d8: r2 = _emptyListeners
    //     0xfa02d8: ldr             x2, [PP, #0x17f0]  ; [pp+0x17f0] Field <ChangeNotifier._emptyListeners@28329750>: static late final (offset: 0x45c)
    // 0xfa02dc: r0 = InitLateFinalStaticField()
    //     0xfa02dc: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xfa02e0: mov             x1, x0
    // 0xfa02e4: ldur            x0, [fp, #-0x10]
    // 0xfa02e8: StoreField: r0->field_f = r1
    //     0xfa02e8: stur            w1, [x0, #0xf]
    // 0xfa02ec: ldur            x1, [fp, #-8]
    // 0xfa02f0: StoreField: r1->field_4f = r0
    //     0xfa02f0: stur            w0, [x1, #0x4f]
    //     0xfa02f4: ldurb           w16, [x1, #-1]
    //     0xfa02f8: ldurb           w17, [x0, #-1]
    //     0xfa02fc: and             x16, x17, x16, lsr #2
    //     0xfa0300: tst             x16, HEAP, lsr #32
    //     0xfa0304: b.eq            #0xfa030c
    //     0xfa0308: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfa030c: r0 = _MixinApplication257&State&TickerProviderStateMixin&ToggleableStateMixin()
    //     0xfa030c: bl              #0xfa0328  ; [dart:mixin_deduplication] _MixinApplication257&State&TickerProviderStateMixin&ToggleableStateMixin::_MixinApplication257&State&TickerProviderStateMixin&ToggleableStateMixin
    // 0xfa0310: r0 = Null
    //     0xfa0310: mov             x0, NULL
    // 0xfa0314: LeaveFrame
    //     0xfa0314: mov             SP, fp
    //     0xfa0318: ldp             fp, lr, [SP], #0x10
    // 0xfa031c: ret
    //     0xfa031c: ret             
    // 0xfa0320: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa0320: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa0324: b               #0xfa02b0
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10e12ac, size: 0x4c
    // 0x10e12ac: EnterFrame
    //     0x10e12ac: stp             fp, lr, [SP, #-0x10]!
    //     0x10e12b0: mov             fp, SP
    // 0x10e12b4: AllocStack(0x8)
    //     0x10e12b4: sub             SP, SP, #8
    // 0x10e12b8: SetupParameters(_CupertinoCheckboxState this /* r1 => r0, fp-0x8 */)
    //     0x10e12b8: mov             x0, x1
    //     0x10e12bc: stur            x1, [fp, #-8]
    // 0x10e12c0: CheckStackOverflow
    //     0x10e12c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e12c4: cmp             SP, x16
    //     0x10e12c8: b.ls            #0x10e12f0
    // 0x10e12cc: LoadField: r1 = r0->field_4f
    //     0x10e12cc: ldur            w1, [x0, #0x4f]
    // 0x10e12d0: DecompressPointer r1
    //     0x10e12d0: add             x1, x1, HEAP, lsl #32
    // 0x10e12d4: r0 = dispose()
    //     0x10e12d4: bl              #0x10eef48  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::dispose
    // 0x10e12d8: ldur            x1, [fp, #-8]
    // 0x10e12dc: r0 = dispose()
    //     0x10e12dc: bl              #0x10e12f8  ; [dart:mixin_deduplication] _MixinApplication387&State&TickerProviderStateMixin&ToggleableStateMixin::dispose
    // 0x10e12e0: r0 = Null
    //     0x10e12e0: mov             x0, NULL
    // 0x10e12e4: LeaveFrame
    //     0x10e12e4: mov             SP, fp
    //     0x10e12e8: ldp             fp, lr, [SP], #0x10
    // 0x10e12ec: ret
    //     0x10e12ec: ret             
    // 0x10e12f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e12f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e12f4: b               #0x10e12cc
  }
  bool? value(_CupertinoCheckboxState) {
    // ** addr: 0x11a0f58, size: 0x28
    // 0x11a0f58: LoadField: r2 = r1->field_b
    //     0x11a0f58: ldur            w2, [x1, #0xb]
    // 0x11a0f5c: DecompressPointer r2
    //     0x11a0f5c: add             x2, x2, HEAP, lsl #32
    // 0x11a0f60: cmp             w2, NULL
    // 0x11a0f64: b.eq            #0x11a0f74
    // 0x11a0f68: LoadField: r0 = r2->field_b
    //     0x11a0f68: ldur            w0, [x2, #0xb]
    // 0x11a0f6c: DecompressPointer r0
    //     0x11a0f6c: add             x0, x0, HEAP, lsl #32
    // 0x11a0f70: ret
    //     0x11a0f70: ret             
    // 0x11a0f74: EnterFrame
    //     0x11a0f74: stp             fp, lr, [SP, #-0x10]!
    //     0x11a0f78: mov             fp, SP
    // 0x11a0f7c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x11a0f7c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ tristate(/* No info */) {
    // ** addr: 0x11a19dc, size: 0x28
    // 0x11a19dc: LoadField: r2 = r1->field_b
    //     0x11a19dc: ldur            w2, [x1, #0xb]
    // 0x11a19e0: DecompressPointer r2
    //     0x11a19e0: add             x2, x2, HEAP, lsl #32
    // 0x11a19e4: cmp             w2, NULL
    // 0x11a19e8: b.eq            #0x11a19f8
    // 0x11a19ec: LoadField: r0 = r2->field_23
    //     0x11a19ec: ldur            w0, [x2, #0x23]
    // 0x11a19f0: DecompressPointer r0
    //     0x11a19f0: add             x0, x0, HEAP, lsl #32
    // 0x11a19f4: ret
    //     0x11a19f4: ret             
    // 0x11a19f8: EnterFrame
    //     0x11a19f8: stp             fp, lr, [SP, #-0x10]!
    //     0x11a19fc: mov             fp, SP
    // 0x11a1a00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x11a1a00: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 6527, size: 0x44, field offset: 0xc
//   const constructor, 
class CupertinoCheckbox extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa024c, size: 0x48
    // 0xfa024c: EnterFrame
    //     0xfa024c: stp             fp, lr, [SP, #-0x10]!
    //     0xfa0250: mov             fp, SP
    // 0xfa0254: AllocStack(0x8)
    //     0xfa0254: sub             SP, SP, #8
    // 0xfa0258: CheckStackOverflow
    //     0xfa0258: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa025c: cmp             SP, x16
    //     0xfa0260: b.ls            #0xfa028c
    // 0xfa0264: r1 = <CupertinoCheckbox>
    //     0xfa0264: add             x1, PP, #0x98, lsl #12  ; [pp+0x98720] TypeArguments: <CupertinoCheckbox>
    //     0xfa0268: ldr             x1, [x1, #0x720]
    // 0xfa026c: r0 = _CupertinoCheckboxState()
    //     0xfa026c: bl              #0xfa0378  ; Allocate_CupertinoCheckboxStateStub -> _CupertinoCheckboxState (size=0x58)
    // 0xfa0270: mov             x1, x0
    // 0xfa0274: stur            x0, [fp, #-8]
    // 0xfa0278: r0 = _CupertinoCheckboxState()
    //     0xfa0278: bl              #0xfa0294  ; [package:flutter/src/cupertino/checkbox.dart] _CupertinoCheckboxState::_CupertinoCheckboxState
    // 0xfa027c: ldur            x0, [fp, #-8]
    // 0xfa0280: LeaveFrame
    //     0xfa0280: mov             SP, fp
    //     0xfa0284: ldp             fp, lr, [SP], #0x10
    // 0xfa0288: ret
    //     0xfa0288: ret             
    // 0xfa028c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa028c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa0290: b               #0xfa0264
  }
}
