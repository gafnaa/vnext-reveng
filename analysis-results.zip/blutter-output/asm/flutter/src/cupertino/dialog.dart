// lib: , url: package:flutter/src/cupertino/dialog.dart

// class id: 1048778, size: 0x8
class :: {

  static _ _isInAccessibilityMode(/* No info */) {
    // ** addr: 0xde3760, size: 0x94
    // 0xde3760: EnterFrame
    //     0xde3760: stp             fp, lr, [SP, #-0x10]!
    //     0xde3764: mov             fp, SP
    // 0xde3768: CheckStackOverflow
    //     0xde3768: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde376c: cmp             SP, x16
    //     0xde3770: b.ls            #0xde37ec
    // 0xde3774: r0 = maybeTextScalerOf()
    //     0xde3774: bl              #0xd161a0  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::maybeTextScalerOf
    // 0xde3778: cmp             w0, NULL
    // 0xde377c: b.ne            #0xde3788
    // 0xde3780: r1 = Null
    //     0xde3780: mov             x1, NULL
    // 0xde3784: b               #0xde37b0
    // 0xde3788: r1 = LoadClassIdInstr(r0)
    //     0xde3788: ldur            x1, [x0, #-1]
    //     0xde378c: ubfx            x1, x1, #0xc, #0x14
    // 0xde3790: mov             x16, x0
    // 0xde3794: mov             x0, x1
    // 0xde3798: mov             x1, x16
    // 0xde379c: d0 = 14.000000
    //     0xde379c: fmov            d0, #14.00000000
    // 0xde37a0: r0 = GDT[cid_x0 + -0x1000]()
    //     0xde37a0: sub             lr, x0, #1, lsl #12
    //     0xde37a4: ldr             lr, [x21, lr, lsl #3]
    //     0xde37a8: blr             lr
    // 0xde37ac: mov             x1, x0
    // 0xde37b0: cmp             w1, NULL
    // 0xde37b4: b.eq            #0xde37dc
    // 0xde37b8: d0 = 19.600000
    //     0xde37b8: add             x17, PP, #0xab, lsl #12  ; [pp+0xab2d0] IMM: double(19.599999999999998) from 0x4033999999999999
    //     0xde37bc: ldr             d0, [x17, #0x2d0]
    // 0xde37c0: LoadField: d1 = r1->field_7
    //     0xde37c0: ldur            d1, [x1, #7]
    // 0xde37c4: fcmp            d1, d0
    // 0xde37c8: r16 = true
    //     0xde37c8: add             x16, NULL, #0x20  ; true
    // 0xde37cc: r17 = false
    //     0xde37cc: add             x17, NULL, #0x30  ; false
    // 0xde37d0: csel            x1, x16, x17, gt
    // 0xde37d4: mov             x0, x1
    // 0xde37d8: b               #0xde37e0
    // 0xde37dc: r0 = false
    //     0xde37dc: add             x0, NULL, #0x30  ; false
    // 0xde37e0: LeaveFrame
    //     0xde37e0: mov             SP, fp
    //     0xde37e4: ldp             fp, lr, [SP], #0x10
    // 0xde37e8: ret
    //     0xde37e8: ret             
    // 0xde37ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde37ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde37f0: b               #0xde3774
  }
}

// class id: 3276, size: 0x8, field offset: 0x8
abstract class _SlideTarget extends Object {
}

// class id: 4430, size: 0x24, field offset: 0x18
class _TargetSelectionGestureRecognizer extends GestureRecognizer {

  [closure] void _onEnd(dynamic, Offset) {
    // ** addr: 0xb9d208, size: 0x3c
    // 0xb9d208: EnterFrame
    //     0xb9d208: stp             fp, lr, [SP, #-0x10]!
    //     0xb9d20c: mov             fp, SP
    // 0xb9d210: ldr             x0, [fp, #0x18]
    // 0xb9d214: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb9d214: ldur            w1, [x0, #0x17]
    // 0xb9d218: DecompressPointer r1
    //     0xb9d218: add             x1, x1, HEAP, lsl #32
    // 0xb9d21c: CheckStackOverflow
    //     0xb9d21c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9d220: cmp             SP, x16
    //     0xb9d224: b.ls            #0xb9d23c
    // 0xb9d228: ldr             x2, [fp, #0x10]
    // 0xb9d22c: r0 = _onEnd()
    //     0xb9d22c: bl              #0xb9f468  ; [package:flutter/src/cupertino/dialog.dart] _TargetSelectionGestureRecognizer::_onEnd
    // 0xb9d230: LeaveFrame
    //     0xb9d230: mov             SP, fp
    //     0xb9d234: ldp             fp, lr, [SP], #0x10
    // 0xb9d238: ret
    //     0xb9d238: ret             
    // 0xb9d23c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9d23c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9d240: b               #0xb9d228
  }
  [closure] void _onUpdate(dynamic, Offset) {
    // ** addr: 0xb9d268, size: 0x3c
    // 0xb9d268: EnterFrame
    //     0xb9d268: stp             fp, lr, [SP, #-0x10]!
    //     0xb9d26c: mov             fp, SP
    // 0xb9d270: ldr             x0, [fp, #0x18]
    // 0xb9d274: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb9d274: ldur            w1, [x0, #0x17]
    // 0xb9d278: DecompressPointer r1
    //     0xb9d278: add             x1, x1, HEAP, lsl #32
    // 0xb9d27c: CheckStackOverflow
    //     0xb9d27c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9d280: cmp             SP, x16
    //     0xb9d284: b.ls            #0xb9d29c
    // 0xb9d288: ldr             x2, [fp, #0x10]
    // 0xb9d28c: r0 = _onUpdate()
    //     0xb9d28c: bl              #0xb9f994  ; [package:flutter/src/cupertino/dialog.dart] _TargetSelectionGestureRecognizer::_onUpdate
    // 0xb9d290: LeaveFrame
    //     0xb9d290: mov             SP, fp
    //     0xb9d294: ldp             fp, lr, [SP], #0x10
    // 0xb9d298: ret
    //     0xb9d298: ret             
    // 0xb9d29c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9d29c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9d2a0: b               #0xb9d288
  }
  _ _onEnd(/* No info */) {
    // ** addr: 0xb9f468, size: 0x100
    // 0xb9f468: EnterFrame
    //     0xb9f468: stp             fp, lr, [SP, #-0x10]!
    //     0xb9f46c: mov             fp, SP
    // 0xb9f470: AllocStack(0x20)
    //     0xb9f470: sub             SP, SP, #0x20
    // 0xb9f474: SetupParameters(_TargetSelectionGestureRecognizer this /* r1 => r0, fp-0x8 */)
    //     0xb9f474: mov             x0, x1
    //     0xb9f478: stur            x1, [fp, #-8]
    // 0xb9f47c: CheckStackOverflow
    //     0xb9f47c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9f480: cmp             SP, x16
    //     0xb9f484: b.ls            #0xb9f558
    // 0xb9f488: mov             x1, x0
    // 0xb9f48c: r3 = false
    //     0xb9f48c: add             x3, NULL, #0x30  ; false
    // 0xb9f490: r0 = _updateDrag()
    //     0xb9f490: bl              #0xb9f568  ; [package:flutter/src/cupertino/dialog.dart] _TargetSelectionGestureRecognizer::_updateDrag
    // 0xb9f494: ldur            x0, [fp, #-8]
    // 0xb9f498: LoadField: r2 = r0->field_1b
    //     0xb9f498: ldur            w2, [x0, #0x1b]
    // 0xb9f49c: DecompressPointer r2
    //     0xb9f49c: add             x2, x2, HEAP, lsl #32
    // 0xb9f4a0: stur            x2, [fp, #-0x20]
    // 0xb9f4a4: LoadField: r0 = r2->field_b
    //     0xb9f4a4: ldur            w0, [x2, #0xb]
    // 0xb9f4a8: r3 = LoadInt32Instr(r0)
    //     0xb9f4a8: sbfx            x3, x0, #1, #0x1f
    // 0xb9f4ac: stur            x3, [fp, #-0x18]
    // 0xb9f4b0: r0 = 0
    //     0xb9f4b0: mov             x0, #0
    // 0xb9f4b4: CheckStackOverflow
    //     0xb9f4b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9f4b8: cmp             SP, x16
    //     0xb9f4bc: b.ls            #0xb9f560
    // 0xb9f4c0: LoadField: r1 = r2->field_b
    //     0xb9f4c0: ldur            w1, [x2, #0xb]
    // 0xb9f4c4: r4 = LoadInt32Instr(r1)
    //     0xb9f4c4: sbfx            x4, x1, #1, #0x1f
    // 0xb9f4c8: cmp             x3, x4
    // 0xb9f4cc: b.ne            #0xb9f538
    // 0xb9f4d0: cmp             x0, x4
    // 0xb9f4d4: b.ge            #0xb9f520
    // 0xb9f4d8: LoadField: r1 = r2->field_f
    //     0xb9f4d8: ldur            w1, [x2, #0xf]
    // 0xb9f4dc: DecompressPointer r1
    //     0xb9f4dc: add             x1, x1, HEAP, lsl #32
    // 0xb9f4e0: ArrayLoad: r4 = r1[r0]  ; Unknown_4
    //     0xb9f4e0: add             x16, x1, x0, lsl #2
    //     0xb9f4e4: ldur            w4, [x16, #0xf]
    // 0xb9f4e8: DecompressPointer r4
    //     0xb9f4e8: add             x4, x4, HEAP, lsl #32
    // 0xb9f4ec: add             x5, x0, #1
    // 0xb9f4f0: stur            x5, [fp, #-0x10]
    // 0xb9f4f4: r0 = LoadClassIdInstr(r4)
    //     0xb9f4f4: ldur            x0, [x4, #-1]
    //     0xb9f4f8: ubfx            x0, x0, #0xc, #0x14
    // 0xb9f4fc: mov             x1, x4
    // 0xb9f500: r0 = GDT[cid_x0 + 0x1a13]()
    //     0xb9f500: mov             x17, #0x1a13
    //     0xb9f504: add             lr, x0, x17
    //     0xb9f508: ldr             lr, [x21, lr, lsl #3]
    //     0xb9f50c: blr             lr
    // 0xb9f510: ldur            x0, [fp, #-0x10]
    // 0xb9f514: ldur            x2, [fp, #-0x20]
    // 0xb9f518: ldur            x3, [fp, #-0x18]
    // 0xb9f51c: b               #0xb9f4b4
    // 0xb9f520: ldur            x1, [fp, #-0x20]
    // 0xb9f524: r0 = clear()
    //     0xb9f524: bl              #0xa16074  ; [dart:core] _GrowableList::clear
    // 0xb9f528: r0 = Null
    //     0xb9f528: mov             x0, NULL
    // 0xb9f52c: LeaveFrame
    //     0xb9f52c: mov             SP, fp
    //     0xb9f530: ldp             fp, lr, [SP], #0x10
    // 0xb9f534: ret
    //     0xb9f534: ret             
    // 0xb9f538: mov             x0, x2
    // 0xb9f53c: r0 = ConcurrentModificationError()
    //     0xb9f53c: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xb9f540: mov             x1, x0
    // 0xb9f544: ldur            x0, [fp, #-0x20]
    // 0xb9f548: StoreField: r1->field_b = r0
    //     0xb9f548: stur            w0, [x1, #0xb]
    // 0xb9f54c: mov             x0, x1
    // 0xb9f550: r0 = Throw()
    //     0xb9f550: bl              #0x13ddb2c  ; ThrowStub
    // 0xb9f554: brk             #0
    // 0xb9f558: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9f558: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9f55c: b               #0xb9f488
    // 0xb9f560: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9f560: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9f564: b               #0xb9f4c0
  }
  _ _updateDrag(/* No info */) {
    // ** addr: 0xb9f568, size: 0x3f8
    // 0xb9f568: EnterFrame
    //     0xb9f568: stp             fp, lr, [SP, #-0x10]!
    //     0xb9f56c: mov             fp, SP
    // 0xb9f570: AllocStack(0x50)
    //     0xb9f570: sub             SP, SP, #0x50
    // 0xb9f574: SetupParameters(_TargetSelectionGestureRecognizer this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0 */, dynamic _ /* r3 => r2, fp-0x10 */)
    //     0xb9f574: mov             x0, x2
    //     0xb9f578: mov             x2, x3
    //     0xb9f57c: stur            x1, [fp, #-8]
    //     0xb9f580: stur            x3, [fp, #-0x10]
    // 0xb9f584: CheckStackOverflow
    //     0xb9f584: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9f588: cmp             SP, x16
    //     0xb9f58c: b.ls            #0xb9f940
    // 0xb9f590: ArrayLoad: r3 = r1[0]  ; List_4
    //     0xb9f590: ldur            w3, [x1, #0x17]
    // 0xb9f594: DecompressPointer r3
    //     0xb9f594: add             x3, x3, HEAP, lsl #32
    // 0xb9f598: stp             x0, x3, [SP]
    // 0xb9f59c: mov             x0, x3
    // 0xb9f5a0: ClosureCall
    //     0xb9f5a0: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xb9f5a4: ldur            x2, [x0, #0x1f]
    //     0xb9f5a8: blr             x2
    // 0xb9f5ac: r1 = <_SlideTarget>
    //     0xb9f5ac: add             x1, PP, #0xb0, lsl #12  ; [pp+0xb0930] TypeArguments: <_SlideTarget>
    //     0xb9f5b0: ldr             x1, [x1, #0x930]
    // 0xb9f5b4: r2 = 0
    //     0xb9f5b4: mov             x2, #0
    // 0xb9f5b8: stur            x0, [fp, #-0x18]
    // 0xb9f5bc: r0 = _GrowableList()
    //     0xb9f5bc: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xb9f5c0: mov             x3, x0
    // 0xb9f5c4: ldur            x0, [fp, #-0x18]
    // 0xb9f5c8: stur            x3, [fp, #-0x38]
    // 0xb9f5cc: LoadField: r4 = r0->field_7
    //     0xb9f5cc: ldur            w4, [x0, #7]
    // 0xb9f5d0: DecompressPointer r4
    //     0xb9f5d0: add             x4, x4, HEAP, lsl #32
    // 0xb9f5d4: stur            x4, [fp, #-0x30]
    // 0xb9f5d8: LoadField: r0 = r4->field_b
    //     0xb9f5d8: ldur            w0, [x4, #0xb]
    // 0xb9f5dc: r5 = LoadInt32Instr(r0)
    //     0xb9f5dc: sbfx            x5, x0, #1, #0x1f
    // 0xb9f5e0: stur            x5, [fp, #-0x28]
    // 0xb9f5e4: r0 = 0
    //     0xb9f5e4: mov             x0, #0
    // 0xb9f5e8: CheckStackOverflow
    //     0xb9f5e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9f5ec: cmp             SP, x16
    //     0xb9f5f0: b.ls            #0xb9f948
    // 0xb9f5f4: LoadField: r1 = r4->field_b
    //     0xb9f5f4: ldur            w1, [x4, #0xb]
    // 0xb9f5f8: r2 = LoadInt32Instr(r1)
    //     0xb9f5f8: sbfx            x2, x1, #1, #0x1f
    // 0xb9f5fc: cmp             x5, x2
    // 0xb9f600: b.ne            #0xb9f920
    // 0xb9f604: cmp             x0, x2
    // 0xb9f608: b.ge            #0xb9f738
    // 0xb9f60c: LoadField: r1 = r4->field_f
    //     0xb9f60c: ldur            w1, [x4, #0xf]
    // 0xb9f610: DecompressPointer r1
    //     0xb9f610: add             x1, x1, HEAP, lsl #32
    // 0xb9f614: ArrayLoad: r2 = r1[r0]  ; Unknown_4
    //     0xb9f614: add             x16, x1, x0, lsl #2
    //     0xb9f618: ldur            w2, [x16, #0xf]
    // 0xb9f61c: DecompressPointer r2
    //     0xb9f61c: add             x2, x2, HEAP, lsl #32
    // 0xb9f620: add             x6, x0, #1
    // 0xb9f624: stur            x6, [fp, #-0x20]
    // 0xb9f628: LoadField: r0 = r2->field_b
    //     0xb9f628: ldur            w0, [x2, #0xb]
    // 0xb9f62c: DecompressPointer r0
    //     0xb9f62c: add             x0, x0, HEAP, lsl #32
    // 0xb9f630: r1 = LoadClassIdInstr(r0)
    //     0xb9f630: ldur            x1, [x0, #-1]
    //     0xb9f634: ubfx            x1, x1, #0xc, #0x14
    // 0xb9f638: r17 = 4952
    //     0xb9f638: mov             x17, #0x1358
    // 0xb9f63c: cmp             x1, x17
    // 0xb9f640: b.ne            #0xb9f720
    // 0xb9f644: LoadField: r7 = r0->field_57
    //     0xb9f644: ldur            w7, [x0, #0x57]
    // 0xb9f648: DecompressPointer r7
    //     0xb9f648: add             x7, x7, HEAP, lsl #32
    // 0xb9f64c: mov             x0, x7
    // 0xb9f650: stur            x7, [fp, #-0x18]
    // 0xb9f654: r2 = Null
    //     0xb9f654: mov             x2, NULL
    // 0xb9f658: r1 = Null
    //     0xb9f658: mov             x1, NULL
    // 0xb9f65c: cmp             w0, NULL
    // 0xb9f660: b.eq            #0xb9f68c
    // 0xb9f664: branchIfSmi(r0, 0xb9f68c)
    //     0xb9f664: tbz             w0, #0, #0xb9f68c
    // 0xb9f668: r3 = LoadClassIdInstr(r0)
    //     0xb9f668: ldur            x3, [x0, #-1]
    //     0xb9f66c: ubfx            x3, x3, #0xc, #0x14
    // 0xb9f670: r17 = -5488
    //     0xb9f670: mov             x17, #-0x1570
    // 0xb9f674: add             x3, x3, x17
    // 0xb9f678: cmp             x3, #1
    // 0xb9f67c: b.ls            #0xb9f694
    // 0xb9f680: sub             x3, x3, #3
    // 0xb9f684: cmp             x3, #1
    // 0xb9f688: b.ls            #0xb9f694
    // 0xb9f68c: r0 = false
    //     0xb9f68c: add             x0, NULL, #0x30  ; false
    // 0xb9f690: b               #0xb9f698
    // 0xb9f694: r0 = true
    //     0xb9f694: add             x0, NULL, #0x20  ; true
    // 0xb9f698: tbnz            w0, #4, #0xb9f718
    // 0xb9f69c: ldur            x0, [fp, #-0x38]
    // 0xb9f6a0: LoadField: r1 = r0->field_b
    //     0xb9f6a0: ldur            w1, [x0, #0xb]
    // 0xb9f6a4: LoadField: r2 = r0->field_f
    //     0xb9f6a4: ldur            w2, [x0, #0xf]
    // 0xb9f6a8: DecompressPointer r2
    //     0xb9f6a8: add             x2, x2, HEAP, lsl #32
    // 0xb9f6ac: LoadField: r3 = r2->field_b
    //     0xb9f6ac: ldur            w3, [x2, #0xb]
    // 0xb9f6b0: r2 = LoadInt32Instr(r1)
    //     0xb9f6b0: sbfx            x2, x1, #1, #0x1f
    // 0xb9f6b4: stur            x2, [fp, #-0x40]
    // 0xb9f6b8: r1 = LoadInt32Instr(r3)
    //     0xb9f6b8: sbfx            x1, x3, #1, #0x1f
    // 0xb9f6bc: cmp             x2, x1
    // 0xb9f6c0: b.ne            #0xb9f6cc
    // 0xb9f6c4: mov             x1, x0
    // 0xb9f6c8: r0 = _growToNextCapacity()
    //     0xb9f6c8: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb9f6cc: ldur            x2, [fp, #-0x38]
    // 0xb9f6d0: ldur            x3, [fp, #-0x40]
    // 0xb9f6d4: add             x0, x3, #1
    // 0xb9f6d8: lsl             x1, x0, #1
    // 0xb9f6dc: StoreField: r2->field_b = r1
    //     0xb9f6dc: stur            w1, [x2, #0xb]
    // 0xb9f6e0: LoadField: r1 = r2->field_f
    //     0xb9f6e0: ldur            w1, [x2, #0xf]
    // 0xb9f6e4: DecompressPointer r1
    //     0xb9f6e4: add             x1, x1, HEAP, lsl #32
    // 0xb9f6e8: ldur            x0, [fp, #-0x18]
    // 0xb9f6ec: ArrayStore: r1[r3] = r0  ; List_4
    //     0xb9f6ec: add             x25, x1, x3, lsl #2
    //     0xb9f6f0: add             x25, x25, #0xf
    //     0xb9f6f4: str             w0, [x25]
    //     0xb9f6f8: tbz             w0, #0, #0xb9f714
    //     0xb9f6fc: ldurb           w16, [x1, #-1]
    //     0xb9f700: ldurb           w17, [x0, #-1]
    //     0xb9f704: and             x16, x17, x16, lsr #2
    //     0xb9f708: tst             x16, HEAP, lsr #32
    //     0xb9f70c: b.eq            #0xb9f714
    //     0xb9f710: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xb9f714: b               #0xb9f724
    // 0xb9f718: ldur            x2, [fp, #-0x38]
    // 0xb9f71c: b               #0xb9f724
    // 0xb9f720: mov             x2, x3
    // 0xb9f724: ldur            x0, [fp, #-0x20]
    // 0xb9f728: mov             x3, x2
    // 0xb9f72c: ldur            x4, [fp, #-0x30]
    // 0xb9f730: ldur            x5, [fp, #-0x28]
    // 0xb9f734: b               #0xb9f5e8
    // 0xb9f738: ldur            x0, [fp, #-8]
    // 0xb9f73c: mov             x2, x3
    // 0xb9f740: LoadField: r1 = r0->field_1b
    //     0xb9f740: ldur            w1, [x0, #0x1b]
    // 0xb9f744: DecompressPointer r1
    //     0xb9f744: add             x1, x1, HEAP, lsl #32
    // 0xb9f748: stur            x1, [fp, #-0x18]
    // 0xb9f74c: r16 = <_SlideTarget>
    //     0xb9f74c: add             x16, PP, #0xb0, lsl #12  ; [pp+0xb0930] TypeArguments: <_SlideTarget>
    //     0xb9f750: ldr             x16, [x16, #0x930]
    // 0xb9f754: stp             x1, x16, [SP]
    // 0xb9f758: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xb9f758: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xb9f75c: r0 = IterableExtensions.firstOrNull()
    //     0xb9f75c: bl              #0x8bf918  ; [dart:collection] ::IterableExtensions.firstOrNull
    // 0xb9f760: stur            x0, [fp, #-8]
    // 0xb9f764: r16 = <_SlideTarget>
    //     0xb9f764: add             x16, PP, #0xb0, lsl #12  ; [pp+0xb0930] TypeArguments: <_SlideTarget>
    //     0xb9f768: ldr             x16, [x16, #0x930]
    // 0xb9f76c: ldur            lr, [fp, #-0x38]
    // 0xb9f770: stp             lr, x16, [SP]
    // 0xb9f774: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xb9f774: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xb9f778: r0 = IterableExtensions.firstOrNull()
    //     0xb9f778: bl              #0x8bf918  ; [dart:collection] ::IterableExtensions.firstOrNull
    // 0xb9f77c: mov             x1, x0
    // 0xb9f780: ldur            x0, [fp, #-8]
    // 0xb9f784: r2 = 60
    //     0xb9f784: mov             x2, #0x3c
    // 0xb9f788: branchIfSmi(r0, 0xb9f794)
    //     0xb9f788: tbz             w0, #0, #0xb9f794
    // 0xb9f78c: r2 = LoadClassIdInstr(r0)
    //     0xb9f78c: ldur            x2, [x0, #-1]
    //     0xb9f790: ubfx            x2, x2, #0xc, #0x14
    // 0xb9f794: stp             x1, x0, [SP]
    // 0xb9f798: mov             x0, x2
    // 0xb9f79c: mov             lr, x0
    // 0xb9f7a0: ldr             lr, [x21, lr, lsl #3]
    // 0xb9f7a4: blr             lr
    // 0xb9f7a8: tbz             w0, #4, #0xb9f8d0
    // 0xb9f7ac: ldur            x2, [fp, #-0x18]
    // 0xb9f7b0: LoadField: r0 = r2->field_b
    //     0xb9f7b0: ldur            w0, [x2, #0xb]
    // 0xb9f7b4: r3 = LoadInt32Instr(r0)
    //     0xb9f7b4: sbfx            x3, x0, #1, #0x1f
    // 0xb9f7b8: stur            x3, [fp, #-0x28]
    // 0xb9f7bc: r0 = 0
    //     0xb9f7bc: mov             x0, #0
    // 0xb9f7c0: CheckStackOverflow
    //     0xb9f7c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9f7c4: cmp             SP, x16
    //     0xb9f7c8: b.ls            #0xb9f950
    // 0xb9f7cc: LoadField: r1 = r2->field_b
    //     0xb9f7cc: ldur            w1, [x2, #0xb]
    // 0xb9f7d0: r4 = LoadInt32Instr(r1)
    //     0xb9f7d0: sbfx            x4, x1, #1, #0x1f
    // 0xb9f7d4: cmp             x3, x4
    // 0xb9f7d8: b.ne            #0xb9f900
    // 0xb9f7dc: cmp             x0, x4
    // 0xb9f7e0: b.ge            #0xb9f828
    // 0xb9f7e4: LoadField: r1 = r2->field_f
    //     0xb9f7e4: ldur            w1, [x2, #0xf]
    // 0xb9f7e8: DecompressPointer r1
    //     0xb9f7e8: add             x1, x1, HEAP, lsl #32
    // 0xb9f7ec: ArrayLoad: r4 = r1[r0]  ; Unknown_4
    //     0xb9f7ec: add             x16, x1, x0, lsl #2
    //     0xb9f7f0: ldur            w4, [x16, #0xf]
    // 0xb9f7f4: DecompressPointer r4
    //     0xb9f7f4: add             x4, x4, HEAP, lsl #32
    // 0xb9f7f8: add             x5, x0, #1
    // 0xb9f7fc: stur            x5, [fp, #-0x20]
    // 0xb9f800: r0 = LoadClassIdInstr(r4)
    //     0xb9f800: ldur            x0, [x4, #-1]
    //     0xb9f804: ubfx            x0, x0, #0xc, #0x14
    // 0xb9f808: mov             x1, x4
    // 0xb9f80c: r0 = GDT[cid_x0 + 0xd69]()
    //     0xb9f80c: add             lr, x0, #0xd69
    //     0xb9f810: ldr             lr, [x21, lr, lsl #3]
    //     0xb9f814: blr             lr
    // 0xb9f818: ldur            x0, [fp, #-0x20]
    // 0xb9f81c: ldur            x2, [fp, #-0x18]
    // 0xb9f820: ldur            x3, [fp, #-0x28]
    // 0xb9f824: b               #0xb9f7c0
    // 0xb9f828: mov             x0, x2
    // 0xb9f82c: mov             x1, x0
    // 0xb9f830: r0 = clear()
    //     0xb9f830: bl              #0xa16074  ; [dart:core] _GrowableList::clear
    // 0xb9f834: ldur            x1, [fp, #-0x18]
    // 0xb9f838: ldur            x2, [fp, #-0x38]
    // 0xb9f83c: r0 = addAll()
    //     0xb9f83c: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0xb9f840: ldur            x4, [fp, #-0x18]
    // 0xb9f844: LoadField: r0 = r4->field_b
    //     0xb9f844: ldur            w0, [x4, #0xb]
    // 0xb9f848: r5 = LoadInt32Instr(r0)
    //     0xb9f848: sbfx            x5, x0, #1, #0x1f
    // 0xb9f84c: stur            x5, [fp, #-0x28]
    // 0xb9f850: r3 = true
    //     0xb9f850: add             x3, NULL, #0x20  ; true
    // 0xb9f854: r0 = 0
    //     0xb9f854: mov             x0, #0
    // 0xb9f858: CheckStackOverflow
    //     0xb9f858: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9f85c: cmp             SP, x16
    //     0xb9f860: b.ls            #0xb9f958
    // 0xb9f864: LoadField: r1 = r4->field_b
    //     0xb9f864: ldur            w1, [x4, #0xb]
    // 0xb9f868: r2 = LoadInt32Instr(r1)
    //     0xb9f868: sbfx            x2, x1, #1, #0x1f
    // 0xb9f86c: cmp             x5, x2
    // 0xb9f870: b.ne            #0xb9f8e0
    // 0xb9f874: cmp             x0, x2
    // 0xb9f878: b.ge            #0xb9f8d0
    // 0xb9f87c: LoadField: r1 = r4->field_f
    //     0xb9f87c: ldur            w1, [x4, #0xf]
    // 0xb9f880: DecompressPointer r1
    //     0xb9f880: add             x1, x1, HEAP, lsl #32
    // 0xb9f884: ArrayLoad: r2 = r1[r0]  ; Unknown_4
    //     0xb9f884: add             x16, x1, x0, lsl #2
    //     0xb9f888: ldur            w2, [x16, #0xf]
    // 0xb9f88c: DecompressPointer r2
    //     0xb9f88c: add             x2, x2, HEAP, lsl #32
    // 0xb9f890: add             x6, x0, #1
    // 0xb9f894: stur            x6, [fp, #-0x20]
    // 0xb9f898: r0 = LoadClassIdInstr(r2)
    //     0xb9f898: ldur            x0, [x2, #-1]
    //     0xb9f89c: ubfx            x0, x0, #0xc, #0x14
    // 0xb9f8a0: mov             x1, x2
    // 0xb9f8a4: ldur            x2, [fp, #-0x10]
    // 0xb9f8a8: r0 = GDT[cid_x0 + 0x12e4]()
    //     0xb9f8a8: mov             x17, #0x12e4
    //     0xb9f8ac: add             lr, x0, x17
    //     0xb9f8b0: ldr             lr, [x21, lr, lsl #3]
    //     0xb9f8b4: blr             lr
    // 0xb9f8b8: mov             x1, x0
    // 0xb9f8bc: mov             x3, x1
    // 0xb9f8c0: ldur            x0, [fp, #-0x20]
    // 0xb9f8c4: ldur            x4, [fp, #-0x18]
    // 0xb9f8c8: ldur            x5, [fp, #-0x28]
    // 0xb9f8cc: b               #0xb9f858
    // 0xb9f8d0: r0 = Null
    //     0xb9f8d0: mov             x0, NULL
    // 0xb9f8d4: LeaveFrame
    //     0xb9f8d4: mov             SP, fp
    //     0xb9f8d8: ldp             fp, lr, [SP], #0x10
    // 0xb9f8dc: ret
    //     0xb9f8dc: ret             
    // 0xb9f8e0: mov             x0, x4
    // 0xb9f8e4: r0 = ConcurrentModificationError()
    //     0xb9f8e4: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xb9f8e8: mov             x1, x0
    // 0xb9f8ec: ldur            x0, [fp, #-0x18]
    // 0xb9f8f0: StoreField: r1->field_b = r0
    //     0xb9f8f0: stur            w0, [x1, #0xb]
    // 0xb9f8f4: mov             x0, x1
    // 0xb9f8f8: r0 = Throw()
    //     0xb9f8f8: bl              #0x13ddb2c  ; ThrowStub
    // 0xb9f8fc: brk             #0
    // 0xb9f900: mov             x0, x2
    // 0xb9f904: r0 = ConcurrentModificationError()
    //     0xb9f904: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xb9f908: mov             x1, x0
    // 0xb9f90c: ldur            x0, [fp, #-0x18]
    // 0xb9f910: StoreField: r1->field_b = r0
    //     0xb9f910: stur            w0, [x1, #0xb]
    // 0xb9f914: mov             x0, x1
    // 0xb9f918: r0 = Throw()
    //     0xb9f918: bl              #0x13ddb2c  ; ThrowStub
    // 0xb9f91c: brk             #0
    // 0xb9f920: mov             x0, x4
    // 0xb9f924: r0 = ConcurrentModificationError()
    //     0xb9f924: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xb9f928: mov             x1, x0
    // 0xb9f92c: ldur            x0, [fp, #-0x30]
    // 0xb9f930: StoreField: r1->field_b = r0
    //     0xb9f930: stur            w0, [x1, #0xb]
    // 0xb9f934: mov             x0, x1
    // 0xb9f938: r0 = Throw()
    //     0xb9f938: bl              #0x13ddb2c  ; ThrowStub
    // 0xb9f93c: brk             #0
    // 0xb9f940: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9f940: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9f944: b               #0xb9f590
    // 0xb9f948: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9f948: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9f94c: b               #0xb9f5f4
    // 0xb9f950: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9f950: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9f954: b               #0xb9f7cc
    // 0xb9f958: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9f958: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9f95c: b               #0xb9f864
  }
  _ _onUpdate(/* No info */) {
    // ** addr: 0xb9f994, size: 0x34
    // 0xb9f994: EnterFrame
    //     0xb9f994: stp             fp, lr, [SP, #-0x10]!
    //     0xb9f998: mov             fp, SP
    // 0xb9f99c: CheckStackOverflow
    //     0xb9f99c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9f9a0: cmp             SP, x16
    //     0xb9f9a4: b.ls            #0xb9f9c0
    // 0xb9f9a8: r3 = false
    //     0xb9f9a8: add             x3, NULL, #0x30  ; false
    // 0xb9f9ac: r0 = _updateDrag()
    //     0xb9f9ac: bl              #0xb9f568  ; [package:flutter/src/cupertino/dialog.dart] _TargetSelectionGestureRecognizer::_updateDrag
    // 0xb9f9b0: r0 = Null
    //     0xb9f9b0: mov             x0, NULL
    // 0xb9f9b4: LeaveFrame
    //     0xb9f9b4: mov             SP, fp
    //     0xb9f9b8: ldp             fp, lr, [SP], #0x10
    // 0xb9f9bc: ret
    //     0xb9f9bc: ret             
    // 0xb9f9c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9f9c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9f9c4: b               #0xb9f9a8
  }
  _ dispose(/* No info */) {
    // ** addr: 0xbb1990, size: 0x3c
    // 0xbb1990: EnterFrame
    //     0xbb1990: stp             fp, lr, [SP, #-0x10]!
    //     0xbb1994: mov             fp, SP
    // 0xbb1998: CheckStackOverflow
    //     0xbb1998: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbb199c: cmp             SP, x16
    //     0xbb19a0: b.ls            #0xbb19c4
    // 0xbb19a4: LoadField: r0 = r1->field_1f
    //     0xbb19a4: ldur            w0, [x1, #0x1f]
    // 0xbb19a8: DecompressPointer r0
    //     0xbb19a8: add             x0, x0, HEAP, lsl #32
    // 0xbb19ac: mov             x1, x0
    // 0xbb19b0: r0 = dispose()
    //     0xbb19b0: bl              #0xbb16bc  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::dispose
    // 0xbb19b4: r0 = Null
    //     0xbb19b4: mov             x0, NULL
    // 0xbb19b8: LeaveFrame
    //     0xbb19b8: mov             SP, fp
    //     0xbb19bc: ldp             fp, lr, [SP], #0x10
    // 0xbb19c0: ret
    //     0xbb19c0: ret             
    // 0xbb19c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbb19c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbb19c8: b               #0xbb19a4
  }
  _ addPointerPanZoom(/* No info */) {
    // ** addr: 0xd03fc4, size: 0x3c
    // 0xd03fc4: EnterFrame
    //     0xd03fc4: stp             fp, lr, [SP, #-0x10]!
    //     0xd03fc8: mov             fp, SP
    // 0xd03fcc: CheckStackOverflow
    //     0xd03fcc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd03fd0: cmp             SP, x16
    //     0xd03fd4: b.ls            #0xd03ff8
    // 0xd03fd8: LoadField: r0 = r1->field_1f
    //     0xd03fd8: ldur            w0, [x1, #0x1f]
    // 0xd03fdc: DecompressPointer r0
    //     0xd03fdc: add             x0, x0, HEAP, lsl #32
    // 0xd03fe0: mov             x1, x0
    // 0xd03fe4: r0 = addPointerPanZoom()
    //     0xd03fe4: bl              #0xd04000  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::addPointerPanZoom
    // 0xd03fe8: r0 = Null
    //     0xd03fe8: mov             x0, NULL
    // 0xd03fec: LeaveFrame
    //     0xd03fec: mov             SP, fp
    //     0xd03ff0: ldp             fp, lr, [SP], #0x10
    // 0xd03ff4: ret
    //     0xd03ff4: ret             
    // 0xd03ff8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd03ff8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd03ffc: b               #0xd03fd8
  }
  _ addPointer(/* No info */) {
    // ** addr: 0xd04e34, size: 0x3c
    // 0xd04e34: EnterFrame
    //     0xd04e34: stp             fp, lr, [SP, #-0x10]!
    //     0xd04e38: mov             fp, SP
    // 0xd04e3c: CheckStackOverflow
    //     0xd04e3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd04e40: cmp             SP, x16
    //     0xd04e44: b.ls            #0xd04e68
    // 0xd04e48: LoadField: r0 = r1->field_1f
    //     0xd04e48: ldur            w0, [x1, #0x1f]
    // 0xd04e4c: DecompressPointer r0
    //     0xd04e4c: add             x0, x0, HEAP, lsl #32
    // 0xd04e50: mov             x1, x0
    // 0xd04e54: r0 = addPointer()
    //     0xd04e54: bl              #0xd04e70  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::addPointer
    // 0xd04e58: r0 = Null
    //     0xd04e58: mov             x0, NULL
    // 0xd04e5c: LeaveFrame
    //     0xd04e5c: mov             SP, fp
    //     0xd04e60: ldp             fp, lr, [SP], #0x10
    // 0xd04e64: ret
    //     0xd04e64: ret             
    // 0xd04e68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd04e68: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd04e6c: b               #0xd04e48
  }
  _ _TargetSelectionGestureRecognizer(/* No info */) {
    // ** addr: 0xfac150, size: 0x1d8
    // 0xfac150: EnterFrame
    //     0xfac150: stp             fp, lr, [SP, #-0x10]!
    //     0xfac154: mov             fp, SP
    // 0xfac158: AllocStack(0x20)
    //     0xfac158: sub             SP, SP, #0x20
    // 0xfac15c: SetupParameters(_TargetSelectionGestureRecognizer this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xfac15c: mov             x3, x1
    //     0xfac160: mov             x0, x2
    //     0xfac164: stur            x1, [fp, #-8]
    //     0xfac168: stur            x2, [fp, #-0x10]
    // 0xfac16c: CheckStackOverflow
    //     0xfac16c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfac170: cmp             SP, x16
    //     0xfac174: b.ls            #0xfac320
    // 0xfac178: r1 = <_SlideTarget>
    //     0xfac178: add             x1, PP, #0xb0, lsl #12  ; [pp+0xb0930] TypeArguments: <_SlideTarget>
    //     0xfac17c: ldr             x1, [x1, #0x930]
    // 0xfac180: r2 = 0
    //     0xfac180: mov             x2, #0
    // 0xfac184: r0 = _GrowableList()
    //     0xfac184: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xfac188: ldur            x2, [fp, #-8]
    // 0xfac18c: StoreField: r2->field_1b = r0
    //     0xfac18c: stur            w0, [x2, #0x1b]
    //     0xfac190: ldurb           w16, [x2, #-1]
    //     0xfac194: ldurb           w17, [x0, #-1]
    //     0xfac198: and             x16, x17, x16, lsr #2
    //     0xfac19c: tst             x16, HEAP, lsr #32
    //     0xfac1a0: b.eq            #0xfac1a8
    //     0xfac1a4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xfac1a8: ldur            x0, [fp, #-0x10]
    // 0xfac1ac: ArrayStore: r2[0] = r0  ; List_4
    //     0xfac1ac: stur            w0, [x2, #0x17]
    //     0xfac1b0: ldurb           w16, [x2, #-1]
    //     0xfac1b4: ldurb           w17, [x0, #-1]
    //     0xfac1b8: and             x16, x17, x16, lsr #2
    //     0xfac1bc: tst             x16, HEAP, lsr #32
    //     0xfac1c0: b.eq            #0xfac1c8
    //     0xfac1c4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xfac1c8: r0 = _SlidingTapGestureRecognizer()
    //     0xfac1c8: bl              #0xfac328  ; Allocate_SlidingTapGestureRecognizerStub -> _SlidingTapGestureRecognizer (size=0x9c)
    // 0xfac1cc: mov             x1, x0
    // 0xfac1d0: r2 = Null
    //     0xfac1d0: mov             x2, NULL
    // 0xfac1d4: stur            x0, [fp, #-0x10]
    // 0xfac1d8: r0 = DragGestureRecognizer()
    //     0xfac1d8: bl              #0xb8d344  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::DragGestureRecognizer
    // 0xfac1dc: ldur            x1, [fp, #-0x10]
    // 0xfac1e0: r0 = Instance_DragStartBehavior
    //     0xfac1e0: add             x0, PP, #0x84, lsl #12  ; [pp+0x84e20] Obj!DragStartBehavior@12c5c81
    //     0xfac1e4: ldr             x0, [x0, #0xe20]
    // 0xfac1e8: StoreField: r1->field_23 = r0
    //     0xfac1e8: stur            w0, [x1, #0x23]
    // 0xfac1ec: mov             x0, x1
    // 0xfac1f0: ldur            x2, [fp, #-8]
    // 0xfac1f4: StoreField: r2->field_1f = r0
    //     0xfac1f4: stur            w0, [x2, #0x1f]
    //     0xfac1f8: ldurb           w16, [x2, #-1]
    //     0xfac1fc: ldurb           w17, [x0, #-1]
    //     0xfac200: and             x16, x17, x16, lsr #2
    //     0xfac204: tst             x16, HEAP, lsr #32
    //     0xfac208: b.eq            #0xfac210
    //     0xfac20c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xfac210: r16 = <int, PointerDeviceKind>
    //     0xfac210: add             x16, PP, #0x15, lsl #12  ; [pp+0x15598] TypeArguments: <int, PointerDeviceKind>
    //     0xfac214: ldr             x16, [x16, #0x598]
    // 0xfac218: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0xfac21c: stp             lr, x16, [SP]
    // 0xfac220: r0 = Map._fromLiteral()
    //     0xfac220: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xfac224: ldur            x3, [fp, #-8]
    // 0xfac228: StoreField: r3->field_13 = r0
    //     0xfac228: stur            w0, [x3, #0x13]
    //     0xfac22c: ldurb           w16, [x3, #-1]
    //     0xfac230: ldurb           w17, [x0, #-1]
    //     0xfac234: and             x16, x17, x16, lsr #2
    //     0xfac238: tst             x16, HEAP, lsr #32
    //     0xfac23c: b.eq            #0xfac244
    //     0xfac240: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xfac244: r0 = Closure: (int) => bool from Function '_defaultButtonAcceptBehavior@301296176': static.
    //     0xfac244: add             x0, PP, #0x15, lsl #12  ; [pp+0x15578] Closure: (int) => bool from Function '_defaultButtonAcceptBehavior@301296176': static. (0x7f2adb2c1294)
    //     0xfac248: ldr             x0, [x0, #0x578]
    // 0xfac24c: StoreField: r3->field_f = r0
    //     0xfac24c: stur            w0, [x3, #0xf]
    // 0xfac250: mov             x2, x3
    // 0xfac254: r1 = Function '_onDown@708079770':.
    //     0xfac254: add             x1, PP, #0xb0, lsl #12  ; [pp+0xb0938] AnonymousClosure: (0xfac450), in [package:flutter/src/cupertino/dialog.dart] _TargetSelectionGestureRecognizer::_onDown (0xfac48c)
    //     0xfac258: ldr             x1, [x1, #0x938]
    // 0xfac25c: r0 = AllocateClosure()
    //     0xfac25c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfac260: ldur            x3, [fp, #-0x10]
    // 0xfac264: StoreField: r3->field_2b = r0
    //     0xfac264: stur            w0, [x3, #0x2b]
    //     0xfac268: ldurb           w16, [x3, #-1]
    //     0xfac26c: ldurb           w17, [x0, #-1]
    //     0xfac270: and             x16, x17, x16, lsr #2
    //     0xfac274: tst             x16, HEAP, lsr #32
    //     0xfac278: b.eq            #0xfac280
    //     0xfac27c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xfac280: ldur            x2, [fp, #-8]
    // 0xfac284: r1 = Function '_onUpdate@708079770':.
    //     0xfac284: add             x1, PP, #0xb0, lsl #12  ; [pp+0xb0940] AnonymousClosure: (0xb9d268), in [package:flutter/src/cupertino/dialog.dart] _TargetSelectionGestureRecognizer::_onUpdate (0xb9f994)
    //     0xfac288: ldr             x1, [x1, #0x940]
    // 0xfac28c: r0 = AllocateClosure()
    //     0xfac28c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfac290: ldur            x3, [fp, #-0x10]
    // 0xfac294: StoreField: r3->field_8f = r0
    //     0xfac294: stur            w0, [x3, #0x8f]
    //     0xfac298: ldurb           w16, [x3, #-1]
    //     0xfac29c: ldurb           w17, [x0, #-1]
    //     0xfac2a0: and             x16, x17, x16, lsr #2
    //     0xfac2a4: tst             x16, HEAP, lsr #32
    //     0xfac2a8: b.eq            #0xfac2b0
    //     0xfac2ac: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xfac2b0: ldur            x2, [fp, #-8]
    // 0xfac2b4: r1 = Function '_onEnd@708079770':.
    //     0xfac2b4: add             x1, PP, #0xb0, lsl #12  ; [pp+0xb0948] AnonymousClosure: (0xb9d208), in [package:flutter/src/cupertino/dialog.dart] _TargetSelectionGestureRecognizer::_onEnd (0xb9f468)
    //     0xfac2b8: ldr             x1, [x1, #0x948]
    // 0xfac2bc: r0 = AllocateClosure()
    //     0xfac2bc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfac2c0: ldur            x3, [fp, #-0x10]
    // 0xfac2c4: StoreField: r3->field_93 = r0
    //     0xfac2c4: stur            w0, [x3, #0x93]
    //     0xfac2c8: ldurb           w16, [x3, #-1]
    //     0xfac2cc: ldurb           w17, [x0, #-1]
    //     0xfac2d0: and             x16, x17, x16, lsr #2
    //     0xfac2d4: tst             x16, HEAP, lsr #32
    //     0xfac2d8: b.eq            #0xfac2e0
    //     0xfac2dc: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xfac2e0: ldur            x2, [fp, #-8]
    // 0xfac2e4: r1 = Function '_onCancel@708079770':.
    //     0xfac2e4: add             x1, PP, #0xb0, lsl #12  ; [pp+0xb0950] AnonymousClosure: (0xfac334), in [package:flutter/src/cupertino/dialog.dart] _TargetSelectionGestureRecognizer::_onCancel (0xfac36c)
    //     0xfac2e8: ldr             x1, [x1, #0x950]
    // 0xfac2ec: r0 = AllocateClosure()
    //     0xfac2ec: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfac2f0: ldur            x1, [fp, #-0x10]
    // 0xfac2f4: StoreField: r1->field_3b = r0
    //     0xfac2f4: stur            w0, [x1, #0x3b]
    //     0xfac2f8: ldurb           w16, [x1, #-1]
    //     0xfac2fc: ldurb           w17, [x0, #-1]
    //     0xfac300: and             x16, x17, x16, lsr #2
    //     0xfac304: tst             x16, HEAP, lsr #32
    //     0xfac308: b.eq            #0xfac310
    //     0xfac30c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfac310: r0 = Null
    //     0xfac310: mov             x0, NULL
    // 0xfac314: LeaveFrame
    //     0xfac314: mov             SP, fp
    //     0xfac318: ldp             fp, lr, [SP], #0x10
    // 0xfac31c: ret
    //     0xfac31c: ret             
    // 0xfac320: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfac320: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfac324: b               #0xfac178
  }
  [closure] void _onCancel(dynamic) {
    // ** addr: 0xfac334, size: 0x38
    // 0xfac334: EnterFrame
    //     0xfac334: stp             fp, lr, [SP, #-0x10]!
    //     0xfac338: mov             fp, SP
    // 0xfac33c: ldr             x0, [fp, #0x10]
    // 0xfac340: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xfac340: ldur            w1, [x0, #0x17]
    // 0xfac344: DecompressPointer r1
    //     0xfac344: add             x1, x1, HEAP, lsl #32
    // 0xfac348: CheckStackOverflow
    //     0xfac348: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfac34c: cmp             SP, x16
    //     0xfac350: b.ls            #0xfac364
    // 0xfac354: r0 = _onCancel()
    //     0xfac354: bl              #0xfac36c  ; [package:flutter/src/cupertino/dialog.dart] _TargetSelectionGestureRecognizer::_onCancel
    // 0xfac358: LeaveFrame
    //     0xfac358: mov             SP, fp
    //     0xfac35c: ldp             fp, lr, [SP], #0x10
    // 0xfac360: ret
    //     0xfac360: ret             
    // 0xfac364: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfac364: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfac368: b               #0xfac354
  }
  _ _onCancel(/* No info */) {
    // ** addr: 0xfac36c, size: 0xe4
    // 0xfac36c: EnterFrame
    //     0xfac36c: stp             fp, lr, [SP, #-0x10]!
    //     0xfac370: mov             fp, SP
    // 0xfac374: AllocStack(0x18)
    //     0xfac374: sub             SP, SP, #0x18
    // 0xfac378: CheckStackOverflow
    //     0xfac378: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfac37c: cmp             SP, x16
    //     0xfac380: b.ls            #0xfac440
    // 0xfac384: LoadField: r2 = r1->field_1b
    //     0xfac384: ldur            w2, [x1, #0x1b]
    // 0xfac388: DecompressPointer r2
    //     0xfac388: add             x2, x2, HEAP, lsl #32
    // 0xfac38c: stur            x2, [fp, #-0x18]
    // 0xfac390: LoadField: r0 = r2->field_b
    //     0xfac390: ldur            w0, [x2, #0xb]
    // 0xfac394: r3 = LoadInt32Instr(r0)
    //     0xfac394: sbfx            x3, x0, #1, #0x1f
    // 0xfac398: stur            x3, [fp, #-0x10]
    // 0xfac39c: r0 = 0
    //     0xfac39c: mov             x0, #0
    // 0xfac3a0: CheckStackOverflow
    //     0xfac3a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfac3a4: cmp             SP, x16
    //     0xfac3a8: b.ls            #0xfac448
    // 0xfac3ac: LoadField: r1 = r2->field_b
    //     0xfac3ac: ldur            w1, [x2, #0xb]
    // 0xfac3b0: r4 = LoadInt32Instr(r1)
    //     0xfac3b0: sbfx            x4, x1, #1, #0x1f
    // 0xfac3b4: cmp             x3, x4
    // 0xfac3b8: b.ne            #0xfac420
    // 0xfac3bc: cmp             x0, x4
    // 0xfac3c0: b.ge            #0xfac408
    // 0xfac3c4: LoadField: r1 = r2->field_f
    //     0xfac3c4: ldur            w1, [x2, #0xf]
    // 0xfac3c8: DecompressPointer r1
    //     0xfac3c8: add             x1, x1, HEAP, lsl #32
    // 0xfac3cc: ArrayLoad: r4 = r1[r0]  ; Unknown_4
    //     0xfac3cc: add             x16, x1, x0, lsl #2
    //     0xfac3d0: ldur            w4, [x16, #0xf]
    // 0xfac3d4: DecompressPointer r4
    //     0xfac3d4: add             x4, x4, HEAP, lsl #32
    // 0xfac3d8: add             x5, x0, #1
    // 0xfac3dc: stur            x5, [fp, #-8]
    // 0xfac3e0: r0 = LoadClassIdInstr(r4)
    //     0xfac3e0: ldur            x0, [x4, #-1]
    //     0xfac3e4: ubfx            x0, x0, #0xc, #0x14
    // 0xfac3e8: mov             x1, x4
    // 0xfac3ec: r0 = GDT[cid_x0 + 0xd69]()
    //     0xfac3ec: add             lr, x0, #0xd69
    //     0xfac3f0: ldr             lr, [x21, lr, lsl #3]
    //     0xfac3f4: blr             lr
    // 0xfac3f8: ldur            x0, [fp, #-8]
    // 0xfac3fc: ldur            x2, [fp, #-0x18]
    // 0xfac400: ldur            x3, [fp, #-0x10]
    // 0xfac404: b               #0xfac3a0
    // 0xfac408: ldur            x1, [fp, #-0x18]
    // 0xfac40c: r0 = clear()
    //     0xfac40c: bl              #0xa16074  ; [dart:core] _GrowableList::clear
    // 0xfac410: r0 = Null
    //     0xfac410: mov             x0, NULL
    // 0xfac414: LeaveFrame
    //     0xfac414: mov             SP, fp
    //     0xfac418: ldp             fp, lr, [SP], #0x10
    // 0xfac41c: ret
    //     0xfac41c: ret             
    // 0xfac420: mov             x0, x2
    // 0xfac424: r0 = ConcurrentModificationError()
    //     0xfac424: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xfac428: mov             x1, x0
    // 0xfac42c: ldur            x0, [fp, #-0x18]
    // 0xfac430: StoreField: r1->field_b = r0
    //     0xfac430: stur            w0, [x1, #0xb]
    // 0xfac434: mov             x0, x1
    // 0xfac438: r0 = Throw()
    //     0xfac438: bl              #0x13ddb2c  ; ThrowStub
    // 0xfac43c: brk             #0
    // 0xfac440: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfac440: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfac444: b               #0xfac384
    // 0xfac448: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfac448: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfac44c: b               #0xfac3ac
  }
  [closure] void _onDown(dynamic, DragDownDetails) {
    // ** addr: 0xfac450, size: 0x3c
    // 0xfac450: EnterFrame
    //     0xfac450: stp             fp, lr, [SP, #-0x10]!
    //     0xfac454: mov             fp, SP
    // 0xfac458: ldr             x0, [fp, #0x18]
    // 0xfac45c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xfac45c: ldur            w1, [x0, #0x17]
    // 0xfac460: DecompressPointer r1
    //     0xfac460: add             x1, x1, HEAP, lsl #32
    // 0xfac464: CheckStackOverflow
    //     0xfac464: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfac468: cmp             SP, x16
    //     0xfac46c: b.ls            #0xfac484
    // 0xfac470: ldr             x2, [fp, #0x10]
    // 0xfac474: r0 = _onDown()
    //     0xfac474: bl              #0xfac48c  ; [package:flutter/src/cupertino/dialog.dart] _TargetSelectionGestureRecognizer::_onDown
    // 0xfac478: LeaveFrame
    //     0xfac478: mov             SP, fp
    //     0xfac47c: ldp             fp, lr, [SP], #0x10
    // 0xfac480: ret
    //     0xfac480: ret             
    // 0xfac484: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfac484: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfac488: b               #0xfac470
  }
  _ _onDown(/* No info */) {
    // ** addr: 0xfac48c, size: 0x40
    // 0xfac48c: EnterFrame
    //     0xfac48c: stp             fp, lr, [SP, #-0x10]!
    //     0xfac490: mov             fp, SP
    // 0xfac494: CheckStackOverflow
    //     0xfac494: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfac498: cmp             SP, x16
    //     0xfac49c: b.ls            #0xfac4c4
    // 0xfac4a0: LoadField: r0 = r2->field_7
    //     0xfac4a0: ldur            w0, [x2, #7]
    // 0xfac4a4: DecompressPointer r0
    //     0xfac4a4: add             x0, x0, HEAP, lsl #32
    // 0xfac4a8: mov             x2, x0
    // 0xfac4ac: r3 = true
    //     0xfac4ac: add             x3, NULL, #0x20  ; true
    // 0xfac4b0: r0 = _updateDrag()
    //     0xfac4b0: bl              #0xb9f568  ; [package:flutter/src/cupertino/dialog.dart] _TargetSelectionGestureRecognizer::_updateDrag
    // 0xfac4b4: r0 = Null
    //     0xfac4b4: mov             x0, NULL
    // 0xfac4b8: LeaveFrame
    //     0xfac4b8: mov             SP, fp
    //     0xfac4bc: ldp             fp, lr, [SP], #0x10
    // 0xfac4c0: ret
    //     0xfac4c0: ret             
    // 0xfac4c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfac4c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfac4c8: b               #0xfac4a0
  }
  _ rejectGesture(/* No info */) {
    // ** addr: 0x116d29c, size: 0x3c
    // 0x116d29c: EnterFrame
    //     0x116d29c: stp             fp, lr, [SP, #-0x10]!
    //     0x116d2a0: mov             fp, SP
    // 0x116d2a4: CheckStackOverflow
    //     0x116d2a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x116d2a8: cmp             SP, x16
    //     0x116d2ac: b.ls            #0x116d2d0
    // 0x116d2b0: LoadField: r0 = r1->field_1f
    //     0x116d2b0: ldur            w0, [x1, #0x1f]
    // 0x116d2b4: DecompressPointer r0
    //     0x116d2b4: add             x0, x0, HEAP, lsl #32
    // 0x116d2b8: mov             x1, x0
    // 0x116d2bc: r0 = rejectGesture()
    //     0x116d2bc: bl              #0x116ce98  ; [package:flutter/src/cupertino/dialog.dart] _SlidingTapGestureRecognizer::rejectGesture
    // 0x116d2c0: r0 = Null
    //     0x116d2c0: mov             x0, NULL
    // 0x116d2c4: LeaveFrame
    //     0x116d2c4: mov             SP, fp
    //     0x116d2c8: ldp             fp, lr, [SP], #0x10
    // 0x116d2cc: ret
    //     0x116d2cc: ret             
    // 0x116d2d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x116d2d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x116d2d4: b               #0x116d2b0
  }
  _ acceptGesture(/* No info */) {
    // ** addr: 0x119cb74, size: 0x3c
    // 0x119cb74: EnterFrame
    //     0x119cb74: stp             fp, lr, [SP, #-0x10]!
    //     0x119cb78: mov             fp, SP
    // 0x119cb7c: CheckStackOverflow
    //     0x119cb7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x119cb80: cmp             SP, x16
    //     0x119cb84: b.ls            #0x119cba8
    // 0x119cb88: LoadField: r0 = r1->field_1f
    //     0x119cb88: ldur            w0, [x1, #0x1f]
    // 0x119cb8c: DecompressPointer r0
    //     0x119cb8c: add             x0, x0, HEAP, lsl #32
    // 0x119cb90: mov             x1, x0
    // 0x119cb94: r0 = acceptGesture()
    //     0x119cb94: bl              #0x119c370  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::acceptGesture
    // 0x119cb98: r0 = Null
    //     0x119cb98: mov             x0, NULL
    // 0x119cb9c: LeaveFrame
    //     0x119cb9c: mov             SP, fp
    //     0x119cba0: ldp             fp, lr, [SP], #0x10
    // 0x119cba4: ret
    //     0x119cba4: ret             
    // 0x119cba8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x119cba8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x119cbac: b               #0x119cb88
  }
}

// class id: 4448, size: 0x9c, field offset: 0x90
class _SlidingTapGestureRecognizer extends VerticalDragGestureRecognizer {

  dynamic handleEvent(dynamic) {
    // ** addr: 0xb9cef8, size: 0x24
    // 0xb9cef8: EnterFrame
    //     0xb9cef8: stp             fp, lr, [SP, #-0x10]!
    //     0xb9cefc: mov             fp, SP
    // 0xb9cf00: ldr             x2, [fp, #0x10]
    // 0xb9cf04: r1 = Function 'handleEvent':.
    //     0xb9cf04: add             x1, PP, #0xcf, lsl #12  ; [pp+0xcf858] AnonymousClosure: (0xb9cf1c), in [package:flutter/src/cupertino/dialog.dart] _SlidingTapGestureRecognizer::handleEvent (0xb9cf58)
    //     0xb9cf08: ldr             x1, [x1, #0x858]
    // 0xb9cf0c: r0 = AllocateClosure()
    //     0xb9cf0c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb9cf10: LeaveFrame
    //     0xb9cf10: mov             SP, fp
    //     0xb9cf14: ldp             fp, lr, [SP], #0x10
    // 0xb9cf18: ret
    //     0xb9cf18: ret             
  }
  [closure] void handleEvent(dynamic, PointerEvent) {
    // ** addr: 0xb9cf1c, size: 0x3c
    // 0xb9cf1c: EnterFrame
    //     0xb9cf1c: stp             fp, lr, [SP, #-0x10]!
    //     0xb9cf20: mov             fp, SP
    // 0xb9cf24: ldr             x0, [fp, #0x18]
    // 0xb9cf28: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb9cf28: ldur            w1, [x0, #0x17]
    // 0xb9cf2c: DecompressPointer r1
    //     0xb9cf2c: add             x1, x1, HEAP, lsl #32
    // 0xb9cf30: CheckStackOverflow
    //     0xb9cf30: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9cf34: cmp             SP, x16
    //     0xb9cf38: b.ls            #0xb9cf50
    // 0xb9cf3c: ldr             x2, [fp, #0x10]
    // 0xb9cf40: r0 = handleEvent()
    //     0xb9cf40: bl              #0xb9cf58  ; [package:flutter/src/cupertino/dialog.dart] _SlidingTapGestureRecognizer::handleEvent
    // 0xb9cf44: LeaveFrame
    //     0xb9cf44: mov             SP, fp
    //     0xb9cf48: ldp             fp, lr, [SP], #0x10
    // 0xb9cf4c: ret
    //     0xb9cf4c: ret             
    // 0xb9cf50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9cf50: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9cf54: b               #0xb9cf3c
  }
  _ handleEvent(/* No info */) {
    // ** addr: 0xb9cf58, size: 0x2b0
    // 0xb9cf58: EnterFrame
    //     0xb9cf58: stp             fp, lr, [SP, #-0x10]!
    //     0xb9cf5c: mov             fp, SP
    // 0xb9cf60: AllocStack(0x18)
    //     0xb9cf60: sub             SP, SP, #0x18
    // 0xb9cf64: SetupParameters(_SlidingTapGestureRecognizer this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xb9cf64: mov             x3, x1
    //     0xb9cf68: stur            x1, [fp, #-8]
    //     0xb9cf6c: stur            x2, [fp, #-0x10]
    // 0xb9cf70: CheckStackOverflow
    //     0xb9cf70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9cf74: cmp             SP, x16
    //     0xb9cf78: b.ls            #0xb9d1fc
    // 0xb9cf7c: r0 = LoadClassIdInstr(r2)
    //     0xb9cf7c: ldur            x0, [x2, #-1]
    //     0xb9cf80: ubfx            x0, x0, #0xc, #0x14
    // 0xb9cf84: mov             x1, x2
    // 0xb9cf88: r0 = GDT[cid_x0 + -0x1]()
    //     0xb9cf88: sub             lr, x0, #1
    //     0xb9cf8c: ldr             lr, [x21, lr, lsl #3]
    //     0xb9cf90: blr             lr
    // 0xb9cf94: mov             x2, x0
    // 0xb9cf98: ldur            x3, [fp, #-8]
    // 0xb9cf9c: LoadField: r4 = r3->field_97
    //     0xb9cf9c: ldur            w4, [x3, #0x97]
    // 0xb9cfa0: DecompressPointer r4
    //     0xb9cfa0: add             x4, x4, HEAP, lsl #32
    // 0xb9cfa4: r0 = BoxInt64Instr(r2)
    //     0xb9cfa4: sbfiz           x0, x2, #1, #0x1f
    //     0xb9cfa8: cmp             x2, x0, asr #1
    //     0xb9cfac: b.eq            #0xb9cfb8
    //     0xb9cfb0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb9cfb4: stur            x2, [x0, #7]
    // 0xb9cfb8: cmp             w0, w4
    // 0xb9cfbc: b.eq            #0xb9cff8
    // 0xb9cfc0: and             w16, w0, w4
    // 0xb9cfc4: branchIfSmi(r16, 0xb9d1e0)
    //     0xb9cfc4: tbz             w16, #0, #0xb9d1e0
    // 0xb9cfc8: r16 = LoadClassIdInstr(r0)
    //     0xb9cfc8: ldur            x16, [x0, #-1]
    //     0xb9cfcc: ubfx            x16, x16, #0xc, #0x14
    // 0xb9cfd0: cmp             x16, #0x3d
    // 0xb9cfd4: b.ne            #0xb9d1e0
    // 0xb9cfd8: r16 = LoadClassIdInstr(r4)
    //     0xb9cfd8: ldur            x16, [x4, #-1]
    //     0xb9cfdc: ubfx            x16, x16, #0xc, #0x14
    // 0xb9cfe0: cmp             x16, #0x3d
    // 0xb9cfe4: b.ne            #0xb9d1e0
    // 0xb9cfe8: LoadField: r16 = r0->field_7
    //     0xb9cfe8: ldur            x16, [x0, #7]
    // 0xb9cfec: LoadField: r17 = r4->field_7
    //     0xb9cfec: ldur            x17, [x4, #7]
    // 0xb9cff0: cmp             x16, x17
    // 0xb9cff4: b.ne            #0xb9d1e0
    // 0xb9cff8: ldur            x0, [fp, #-0x10]
    // 0xb9cffc: r2 = Null
    //     0xb9cffc: mov             x2, NULL
    // 0xb9d000: r1 = Null
    //     0xb9d000: mov             x1, NULL
    // 0xb9d004: cmp             w0, NULL
    // 0xb9d008: b.eq            #0xb9d030
    // 0xb9d00c: branchIfSmi(r0, 0xb9d030)
    //     0xb9d00c: tbz             w0, #0, #0xb9d030
    // 0xb9d010: r3 = LoadClassIdInstr(r0)
    //     0xb9d010: ldur            x3, [x0, #-1]
    //     0xb9d014: ubfx            x3, x3, #0xc, #0x14
    // 0xb9d018: r17 = 4157
    //     0xb9d018: mov             x17, #0x103d
    // 0xb9d01c: cmp             x3, x17
    // 0xb9d020: b.eq            #0xb9d038
    // 0xb9d024: r17 = 5286
    //     0xb9d024: mov             x17, #0x14a6
    // 0xb9d028: cmp             x3, x17
    // 0xb9d02c: b.eq            #0xb9d038
    // 0xb9d030: r0 = false
    //     0xb9d030: add             x0, NULL, #0x30  ; false
    // 0xb9d034: b               #0xb9d03c
    // 0xb9d038: r0 = true
    //     0xb9d038: add             x0, NULL, #0x20  ; true
    // 0xb9d03c: tbnz            w0, #4, #0xb9d09c
    // 0xb9d040: ldur            x2, [fp, #-8]
    // 0xb9d044: LoadField: r3 = r2->field_8f
    //     0xb9d044: ldur            w3, [x2, #0x8f]
    // 0xb9d048: DecompressPointer r3
    //     0xb9d048: add             x3, x3, HEAP, lsl #32
    // 0xb9d04c: stur            x3, [fp, #-0x18]
    // 0xb9d050: cmp             w3, NULL
    // 0xb9d054: b.eq            #0xb9d09c
    // 0xb9d058: ldur            x4, [fp, #-0x10]
    // 0xb9d05c: r0 = LoadClassIdInstr(r4)
    //     0xb9d05c: ldur            x0, [x4, #-1]
    //     0xb9d060: ubfx            x0, x0, #0xc, #0x14
    // 0xb9d064: mov             x1, x4
    // 0xb9d068: r0 = GDT[cid_x0 + 0x13f27]()
    //     0xb9d068: mov             x17, #0x3f27
    //     0xb9d06c: movk            x17, #1, lsl #16
    //     0xb9d070: add             lr, x0, x17
    //     0xb9d074: ldr             lr, [x21, lr, lsl #3]
    //     0xb9d078: blr             lr
    // 0xb9d07c: mov             x1, x0
    // 0xb9d080: ldur            x0, [fp, #-0x18]
    // 0xb9d084: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xb9d084: ldur            w2, [x0, #0x17]
    // 0xb9d088: DecompressPointer r2
    //     0xb9d088: add             x2, x2, HEAP, lsl #32
    // 0xb9d08c: mov             x16, x1
    // 0xb9d090: mov             x1, x2
    // 0xb9d094: mov             x2, x16
    // 0xb9d098: r0 = _onUpdate()
    //     0xb9d098: bl              #0xb9f994  ; [package:flutter/src/cupertino/dialog.dart] _TargetSelectionGestureRecognizer::_onUpdate
    // 0xb9d09c: ldur            x0, [fp, #-0x10]
    // 0xb9d0a0: r2 = Null
    //     0xb9d0a0: mov             x2, NULL
    // 0xb9d0a4: r1 = Null
    //     0xb9d0a4: mov             x1, NULL
    // 0xb9d0a8: cmp             w0, NULL
    // 0xb9d0ac: b.eq            #0xb9d0d4
    // 0xb9d0b0: branchIfSmi(r0, 0xb9d0d4)
    //     0xb9d0b0: tbz             w0, #0, #0xb9d0d4
    // 0xb9d0b4: r3 = LoadClassIdInstr(r0)
    //     0xb9d0b4: ldur            x3, [x0, #-1]
    //     0xb9d0b8: ubfx            x3, x3, #0xc, #0x14
    // 0xb9d0bc: r17 = 4155
    //     0xb9d0bc: mov             x17, #0x103b
    // 0xb9d0c0: cmp             x3, x17
    // 0xb9d0c4: b.eq            #0xb9d0dc
    // 0xb9d0c8: r17 = 5284
    //     0xb9d0c8: mov             x17, #0x14a4
    // 0xb9d0cc: cmp             x3, x17
    // 0xb9d0d0: b.eq            #0xb9d0dc
    // 0xb9d0d4: r0 = false
    //     0xb9d0d4: add             x0, NULL, #0x30  ; false
    // 0xb9d0d8: b               #0xb9d0e0
    // 0xb9d0dc: r0 = true
    //     0xb9d0dc: add             x0, NULL, #0x20  ; true
    // 0xb9d0e0: tbnz            w0, #4, #0xb9d17c
    // 0xb9d0e4: ldur            x0, [fp, #-8]
    // 0xb9d0e8: LoadField: r2 = r0->field_97
    //     0xb9d0e8: ldur            w2, [x0, #0x97]
    // 0xb9d0ec: DecompressPointer r2
    //     0xb9d0ec: add             x2, x2, HEAP, lsl #32
    // 0xb9d0f0: cmp             w2, NULL
    // 0xb9d0f4: b.eq            #0xb9d204
    // 0xb9d0f8: mov             x1, x0
    // 0xb9d0fc: r0 = stopTrackingPointer()
    //     0xb9d0fc: bl              #0xb8be24  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::stopTrackingPointer
    // 0xb9d100: ldur            x2, [fp, #-8]
    // 0xb9d104: LoadField: r3 = r2->field_93
    //     0xb9d104: ldur            w3, [x2, #0x93]
    // 0xb9d108: DecompressPointer r3
    //     0xb9d108: add             x3, x3, HEAP, lsl #32
    // 0xb9d10c: stur            x3, [fp, #-0x18]
    // 0xb9d110: cmp             w3, NULL
    // 0xb9d114: b.ne            #0xb9d120
    // 0xb9d118: mov             x3, x2
    // 0xb9d11c: b               #0xb9d168
    // 0xb9d120: ldur            x4, [fp, #-0x10]
    // 0xb9d124: r0 = LoadClassIdInstr(r4)
    //     0xb9d124: ldur            x0, [x4, #-1]
    //     0xb9d128: ubfx            x0, x0, #0xc, #0x14
    // 0xb9d12c: mov             x1, x4
    // 0xb9d130: r0 = GDT[cid_x0 + 0x13f27]()
    //     0xb9d130: mov             x17, #0x3f27
    //     0xb9d134: movk            x17, #1, lsl #16
    //     0xb9d138: add             lr, x0, x17
    //     0xb9d13c: ldr             lr, [x21, lr, lsl #3]
    //     0xb9d140: blr             lr
    // 0xb9d144: mov             x1, x0
    // 0xb9d148: ldur            x0, [fp, #-0x18]
    // 0xb9d14c: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xb9d14c: ldur            w2, [x0, #0x17]
    // 0xb9d150: DecompressPointer r2
    //     0xb9d150: add             x2, x2, HEAP, lsl #32
    // 0xb9d154: mov             x16, x1
    // 0xb9d158: mov             x1, x2
    // 0xb9d15c: mov             x2, x16
    // 0xb9d160: r0 = _onEnd()
    //     0xb9d160: bl              #0xb9f468  ; [package:flutter/src/cupertino/dialog.dart] _TargetSelectionGestureRecognizer::_onEnd
    // 0xb9d164: ldur            x3, [fp, #-8]
    // 0xb9d168: StoreField: r3->field_97 = rNULL
    //     0xb9d168: stur            NULL, [x3, #0x97]
    // 0xb9d16c: r0 = Null
    //     0xb9d16c: mov             x0, NULL
    // 0xb9d170: LeaveFrame
    //     0xb9d170: mov             SP, fp
    //     0xb9d174: ldp             fp, lr, [SP], #0x10
    // 0xb9d178: ret
    //     0xb9d178: ret             
    // 0xb9d17c: ldur            x3, [fp, #-8]
    // 0xb9d180: ldur            x4, [fp, #-0x10]
    // 0xb9d184: mov             x0, x4
    // 0xb9d188: r2 = Null
    //     0xb9d188: mov             x2, NULL
    // 0xb9d18c: r1 = Null
    //     0xb9d18c: mov             x1, NULL
    // 0xb9d190: cmp             w0, NULL
    // 0xb9d194: b.eq            #0xb9d1bc
    // 0xb9d198: branchIfSmi(r0, 0xb9d1bc)
    //     0xb9d198: tbz             w0, #0, #0xb9d1bc
    // 0xb9d19c: r3 = LoadClassIdInstr(r0)
    //     0xb9d19c: ldur            x3, [x0, #-1]
    //     0xb9d1a0: ubfx            x3, x3, #0xc, #0x14
    // 0xb9d1a4: r17 = 4139
    //     0xb9d1a4: mov             x17, #0x102b
    // 0xb9d1a8: cmp             x3, x17
    // 0xb9d1ac: b.eq            #0xb9d1c4
    // 0xb9d1b0: r17 = 5276
    //     0xb9d1b0: mov             x17, #0x149c
    // 0xb9d1b4: cmp             x3, x17
    // 0xb9d1b8: b.eq            #0xb9d1c4
    // 0xb9d1bc: r0 = false
    //     0xb9d1bc: add             x0, NULL, #0x30  ; false
    // 0xb9d1c0: b               #0xb9d1c8
    // 0xb9d1c4: r0 = true
    //     0xb9d1c4: add             x0, NULL, #0x20  ; true
    // 0xb9d1c8: tbnz            w0, #4, #0xb9d1d8
    // 0xb9d1cc: ldur            x1, [fp, #-8]
    // 0xb9d1d0: StoreField: r1->field_97 = rNULL
    //     0xb9d1d0: stur            NULL, [x1, #0x97]
    // 0xb9d1d4: b               #0xb9d1e4
    // 0xb9d1d8: ldur            x1, [fp, #-8]
    // 0xb9d1dc: b               #0xb9d1e4
    // 0xb9d1e0: mov             x1, x3
    // 0xb9d1e4: ldur            x2, [fp, #-0x10]
    // 0xb9d1e8: r0 = handleEvent()
    //     0xb9d1e8: bl              #0xb9d2a4  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::handleEvent
    // 0xb9d1ec: r0 = Null
    //     0xb9d1ec: mov             x0, NULL
    // 0xb9d1f0: LeaveFrame
    //     0xb9d1f0: mov             SP, fp
    //     0xb9d1f4: ldp             fp, lr, [SP], #0x10
    // 0xb9d1f8: ret
    //     0xb9d1f8: ret             
    // 0xb9d1fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9d1fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9d200: b               #0xb9cf7c
    // 0xb9d204: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb9d204: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ addAllowedPointer(/* No info */) {
    // ** addr: 0xba7968, size: 0xb0
    // 0xba7968: EnterFrame
    //     0xba7968: stp             fp, lr, [SP, #-0x10]!
    //     0xba796c: mov             fp, SP
    // 0xba7970: AllocStack(0x10)
    //     0xba7970: sub             SP, SP, #0x10
    // 0xba7974: SetupParameters(_SlidingTapGestureRecognizer this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xba7974: mov             x3, x1
    //     0xba7978: stur            x1, [fp, #-8]
    //     0xba797c: stur            x2, [fp, #-0x10]
    // 0xba7980: CheckStackOverflow
    //     0xba7980: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba7984: cmp             SP, x16
    //     0xba7988: b.ls            #0xba7a10
    // 0xba798c: LoadField: r0 = r3->field_97
    //     0xba798c: ldur            w0, [x3, #0x97]
    // 0xba7990: DecompressPointer r0
    //     0xba7990: add             x0, x0, HEAP, lsl #32
    // 0xba7994: cmp             w0, NULL
    // 0xba7998: b.ne            #0xba79f4
    // 0xba799c: r0 = LoadClassIdInstr(r2)
    //     0xba799c: ldur            x0, [x2, #-1]
    //     0xba79a0: ubfx            x0, x0, #0xc, #0x14
    // 0xba79a4: mov             x1, x2
    // 0xba79a8: r0 = GDT[cid_x0 + -0x1]()
    //     0xba79a8: sub             lr, x0, #1
    //     0xba79ac: ldr             lr, [x21, lr, lsl #3]
    //     0xba79b0: blr             lr
    // 0xba79b4: mov             x2, x0
    // 0xba79b8: r0 = BoxInt64Instr(r2)
    //     0xba79b8: sbfiz           x0, x2, #1, #0x1f
    //     0xba79bc: cmp             x2, x0, asr #1
    //     0xba79c0: b.eq            #0xba79cc
    //     0xba79c4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba79c8: stur            x2, [x0, #7]
    // 0xba79cc: ldur            x1, [fp, #-8]
    // 0xba79d0: StoreField: r1->field_97 = r0
    //     0xba79d0: stur            w0, [x1, #0x97]
    //     0xba79d4: tbz             w0, #0, #0xba79f0
    //     0xba79d8: ldurb           w16, [x1, #-1]
    //     0xba79dc: ldurb           w17, [x0, #-1]
    //     0xba79e0: and             x16, x17, x16, lsr #2
    //     0xba79e4: tst             x16, HEAP, lsr #32
    //     0xba79e8: b.eq            #0xba79f0
    //     0xba79ec: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xba79f0: b               #0xba79f8
    // 0xba79f4: mov             x1, x3
    // 0xba79f8: ldur            x2, [fp, #-0x10]
    // 0xba79fc: r0 = addAllowedPointer()
    //     0xba79fc: bl              #0xba7a18  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::addAllowedPointer
    // 0xba7a00: r0 = Null
    //     0xba7a00: mov             x0, NULL
    // 0xba7a04: LeaveFrame
    //     0xba7a04: mov             SP, fp
    //     0xba7a08: ldp             fp, lr, [SP], #0x10
    // 0xba7a0c: ret
    //     0xba7a0c: ret             
    // 0xba7a10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba7a10: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba7a14: b               #0xba798c
  }
  _ rejectGesture(/* No info */) {
    // ** addr: 0x116ce98, size: 0x98
    // 0x116ce98: EnterFrame
    //     0x116ce98: stp             fp, lr, [SP, #-0x10]!
    //     0x116ce9c: mov             fp, SP
    // 0x116cea0: mov             x3, x1
    // 0x116cea4: CheckStackOverflow
    //     0x116cea4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x116cea8: cmp             SP, x16
    //     0x116ceac: b.ls            #0x116cf28
    // 0x116ceb0: LoadField: r4 = r3->field_97
    //     0x116ceb0: ldur            w4, [x3, #0x97]
    // 0x116ceb4: DecompressPointer r4
    //     0x116ceb4: add             x4, x4, HEAP, lsl #32
    // 0x116ceb8: r0 = BoxInt64Instr(r2)
    //     0x116ceb8: sbfiz           x0, x2, #1, #0x1f
    //     0x116cebc: cmp             x2, x0, asr #1
    //     0x116cec0: b.eq            #0x116cecc
    //     0x116cec4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x116cec8: stur            x2, [x0, #7]
    // 0x116cecc: cmp             w0, w4
    // 0x116ced0: b.eq            #0x116cf0c
    // 0x116ced4: and             w16, w0, w4
    // 0x116ced8: branchIfSmi(r16, 0x116cf10)
    //     0x116ced8: tbz             w16, #0, #0x116cf10
    // 0x116cedc: r16 = LoadClassIdInstr(r0)
    //     0x116cedc: ldur            x16, [x0, #-1]
    //     0x116cee0: ubfx            x16, x16, #0xc, #0x14
    // 0x116cee4: cmp             x16, #0x3d
    // 0x116cee8: b.ne            #0x116cf10
    // 0x116ceec: r16 = LoadClassIdInstr(r4)
    //     0x116ceec: ldur            x16, [x4, #-1]
    //     0x116cef0: ubfx            x16, x16, #0xc, #0x14
    // 0x116cef4: cmp             x16, #0x3d
    // 0x116cef8: b.ne            #0x116cf10
    // 0x116cefc: LoadField: r16 = r0->field_7
    //     0x116cefc: ldur            x16, [x0, #7]
    // 0x116cf00: LoadField: r17 = r4->field_7
    //     0x116cf00: ldur            x17, [x4, #7]
    // 0x116cf04: cmp             x16, x17
    // 0x116cf08: b.ne            #0x116cf10
    // 0x116cf0c: StoreField: r3->field_97 = rNULL
    //     0x116cf0c: stur            NULL, [x3, #0x97]
    // 0x116cf10: mov             x1, x3
    // 0x116cf14: r0 = _giveUpPointer()
    //     0x116cf14: bl              #0xb9f334  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::_giveUpPointer
    // 0x116cf18: r0 = Null
    //     0x116cf18: mov             x0, NULL
    // 0x116cf1c: LeaveFrame
    //     0x116cf1c: mov             SP, fp
    //     0x116cf20: ldp             fp, lr, [SP], #0x10
    // 0x116cf24: ret
    //     0x116cf24: ret             
    // 0x116cf28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x116cf28: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x116cf2c: b               #0x116ceb0
  }
}

// class id: 4863, size: 0xa0, field offset: 0x98
class _RenderPriorityColumn extends RenderFlex {

  _ computeMinIntrinsicHeight(/* No info */) {
    // ** addr: 0xb23d54, size: 0x8c
    // 0xb23d54: EnterFrame
    //     0xb23d54: stp             fp, lr, [SP, #-0x10]!
    //     0xb23d58: mov             fp, SP
    // 0xb23d5c: AllocStack(0x18)
    //     0xb23d5c: sub             SP, SP, #0x18
    // 0xb23d60: SetupParameters(_RenderPriorityColumn this /* r1 => r0, fp-0x8 */)
    //     0xb23d60: mov             x0, x1
    //     0xb23d64: stur            x1, [fp, #-8]
    // 0xb23d68: CheckStackOverflow
    //     0xb23d68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb23d6c: cmp             SP, x16
    //     0xb23d70: b.ls            #0xb23dd0
    // 0xb23d74: LoadField: r1 = r0->field_57
    //     0xb23d74: ldur            w1, [x0, #0x57]
    // 0xb23d78: DecompressPointer r1
    //     0xb23d78: add             x1, x1, HEAP, lsl #32
    // 0xb23d7c: cmp             w1, NULL
    // 0xb23d80: b.eq            #0xb23dd8
    // 0xb23d84: LoadField: d1 = r2->field_7
    //     0xb23d84: ldur            d1, [x2, #7]
    // 0xb23d88: mov             v0.16b, v1.16b
    // 0xb23d8c: stur            d1, [fp, #-0x10]
    // 0xb23d90: r0 = getMinIntrinsicHeight()
    //     0xb23d90: bl              #0xb177d8  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicHeight
    // 0xb23d94: mov             v1.16b, v0.16b
    // 0xb23d98: ldur            x0, [fp, #-8]
    // 0xb23d9c: stur            d1, [fp, #-0x18]
    // 0xb23da0: LoadField: r1 = r0->field_5b
    //     0xb23da0: ldur            w1, [x0, #0x5b]
    // 0xb23da4: DecompressPointer r1
    //     0xb23da4: add             x1, x1, HEAP, lsl #32
    // 0xb23da8: cmp             w1, NULL
    // 0xb23dac: b.eq            #0xb23ddc
    // 0xb23db0: ldur            d0, [fp, #-0x10]
    // 0xb23db4: r0 = getMinIntrinsicHeight()
    //     0xb23db4: bl              #0xb177d8  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicHeight
    // 0xb23db8: ldur            d1, [fp, #-0x18]
    // 0xb23dbc: fadd            d2, d1, d0
    // 0xb23dc0: mov             v0.16b, v2.16b
    // 0xb23dc4: LeaveFrame
    //     0xb23dc4: mov             SP, fp
    //     0xb23dc8: ldp             fp, lr, [SP], #0x10
    // 0xb23dcc: ret
    //     0xb23dcc: ret             
    // 0xb23dd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb23dd0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb23dd4: b               #0xb23d74
    // 0xb23dd8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb23dd8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb23ddc: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb23ddc: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0xb23de0, size: 0x78
    // 0xb23de0: EnterFrame
    //     0xb23de0: stp             fp, lr, [SP, #-0x10]!
    //     0xb23de4: mov             fp, SP
    // 0xb23de8: ldr             x0, [fp, #0x18]
    // 0xb23dec: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb23dec: ldur            w1, [x0, #0x17]
    // 0xb23df0: DecompressPointer r1
    //     0xb23df0: add             x1, x1, HEAP, lsl #32
    // 0xb23df4: CheckStackOverflow
    //     0xb23df4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb23df8: cmp             SP, x16
    //     0xb23dfc: b.ls            #0xb23e40
    // 0xb23e00: ldr             x2, [fp, #0x10]
    // 0xb23e04: r0 = computeMinIntrinsicHeight()
    //     0xb23e04: bl              #0xb23d54  ; [package:flutter/src/cupertino/dialog.dart] _RenderPriorityColumn::computeMinIntrinsicHeight
    // 0xb23e08: r0 = inline_Allocate_Double()
    //     0xb23e08: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb23e0c: add             x0, x0, #0x10
    //     0xb23e10: cmp             x1, x0
    //     0xb23e14: b.ls            #0xb23e48
    //     0xb23e18: str             x0, [THR, #0x60]  ; THR::top
    //     0xb23e1c: sub             x0, x0, #0xf
    //     0xb23e20: mov             x1, #0xe19c
    //     0xb23e24: movk            x1, #3, lsl #16
    //     0xb23e28: stur            x1, [x0, #-1]
    // 0xb23e2c: dmb             ishst
    // 0xb23e30: StoreField: r0->field_7 = d0
    //     0xb23e30: stur            d0, [x0, #7]
    // 0xb23e34: LeaveFrame
    //     0xb23e34: mov             SP, fp
    //     0xb23e38: ldp             fp, lr, [SP], #0x10
    // 0xb23e3c: ret
    //     0xb23e3c: ret             
    // 0xb23e40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb23e40: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb23e44: b               #0xb23e00
    // 0xb23e48: SaveReg d0
    //     0xb23e48: str             q0, [SP, #-0x10]!
    // 0xb23e4c: r0 = AllocateDouble()
    //     0xb23e4c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb23e50: RestoreReg d0
    //     0xb23e50: ldr             q0, [SP], #0x10
    // 0xb23e54: b               #0xb23e30
  }
  _ computeMaxIntrinsicHeight(/* No info */) {
    // ** addr: 0xb2a86c, size: 0x8c
    // 0xb2a86c: EnterFrame
    //     0xb2a86c: stp             fp, lr, [SP, #-0x10]!
    //     0xb2a870: mov             fp, SP
    // 0xb2a874: AllocStack(0x18)
    //     0xb2a874: sub             SP, SP, #0x18
    // 0xb2a878: SetupParameters(_RenderPriorityColumn this /* r1 => r0, fp-0x8 */)
    //     0xb2a878: mov             x0, x1
    //     0xb2a87c: stur            x1, [fp, #-8]
    // 0xb2a880: CheckStackOverflow
    //     0xb2a880: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2a884: cmp             SP, x16
    //     0xb2a888: b.ls            #0xb2a8e8
    // 0xb2a88c: LoadField: r1 = r0->field_57
    //     0xb2a88c: ldur            w1, [x0, #0x57]
    // 0xb2a890: DecompressPointer r1
    //     0xb2a890: add             x1, x1, HEAP, lsl #32
    // 0xb2a894: cmp             w1, NULL
    // 0xb2a898: b.eq            #0xb2a8f0
    // 0xb2a89c: LoadField: d1 = r2->field_7
    //     0xb2a89c: ldur            d1, [x2, #7]
    // 0xb2a8a0: mov             v0.16b, v1.16b
    // 0xb2a8a4: stur            d1, [fp, #-0x10]
    // 0xb2a8a8: r0 = getMaxIntrinsicHeight()
    //     0xb2a8a8: bl              #0xb16950  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicHeight
    // 0xb2a8ac: mov             v1.16b, v0.16b
    // 0xb2a8b0: ldur            x0, [fp, #-8]
    // 0xb2a8b4: stur            d1, [fp, #-0x18]
    // 0xb2a8b8: LoadField: r1 = r0->field_5b
    //     0xb2a8b8: ldur            w1, [x0, #0x5b]
    // 0xb2a8bc: DecompressPointer r1
    //     0xb2a8bc: add             x1, x1, HEAP, lsl #32
    // 0xb2a8c0: cmp             w1, NULL
    // 0xb2a8c4: b.eq            #0xb2a8f4
    // 0xb2a8c8: ldur            d0, [fp, #-0x10]
    // 0xb2a8cc: r0 = getMaxIntrinsicHeight()
    //     0xb2a8cc: bl              #0xb16950  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicHeight
    // 0xb2a8d0: ldur            d1, [fp, #-0x18]
    // 0xb2a8d4: fadd            d2, d1, d0
    // 0xb2a8d8: mov             v0.16b, v2.16b
    // 0xb2a8dc: LeaveFrame
    //     0xb2a8dc: mov             SP, fp
    //     0xb2a8e0: ldp             fp, lr, [SP], #0x10
    // 0xb2a8e4: ret
    //     0xb2a8e4: ret             
    // 0xb2a8e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2a8e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2a8ec: b               #0xb2a88c
    // 0xb2a8f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb2a8f0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb2a8f4: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb2a8f4: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0xb2a8f8, size: 0x78
    // 0xb2a8f8: EnterFrame
    //     0xb2a8f8: stp             fp, lr, [SP, #-0x10]!
    //     0xb2a8fc: mov             fp, SP
    // 0xb2a900: ldr             x0, [fp, #0x18]
    // 0xb2a904: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb2a904: ldur            w1, [x0, #0x17]
    // 0xb2a908: DecompressPointer r1
    //     0xb2a908: add             x1, x1, HEAP, lsl #32
    // 0xb2a90c: CheckStackOverflow
    //     0xb2a90c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2a910: cmp             SP, x16
    //     0xb2a914: b.ls            #0xb2a958
    // 0xb2a918: ldr             x2, [fp, #0x10]
    // 0xb2a91c: r0 = computeMaxIntrinsicHeight()
    //     0xb2a91c: bl              #0xb2a86c  ; [package:flutter/src/cupertino/dialog.dart] _RenderPriorityColumn::computeMaxIntrinsicHeight
    // 0xb2a920: r0 = inline_Allocate_Double()
    //     0xb2a920: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2a924: add             x0, x0, #0x10
    //     0xb2a928: cmp             x1, x0
    //     0xb2a92c: b.ls            #0xb2a960
    //     0xb2a930: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2a934: sub             x0, x0, #0xf
    //     0xb2a938: mov             x1, #0xe19c
    //     0xb2a93c: movk            x1, #3, lsl #16
    //     0xb2a940: stur            x1, [x0, #-1]
    // 0xb2a944: dmb             ishst
    // 0xb2a948: StoreField: r0->field_7 = d0
    //     0xb2a948: stur            d0, [x0, #7]
    // 0xb2a94c: LeaveFrame
    //     0xb2a94c: mov             SP, fp
    //     0xb2a950: ldp             fp, lr, [SP], #0x10
    // 0xb2a954: ret
    //     0xb2a954: ret             
    // 0xb2a958: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2a958: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2a95c: b               #0xb2a918
    // 0xb2a960: SaveReg d0
    //     0xb2a960: str             q0, [SP, #-0x10]!
    // 0xb2a964: r0 = AllocateDouble()
    //     0xb2a964: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2a968: RestoreReg d0
    //     0xb2a968: ldr             q0, [SP], #0x10
    // 0xb2a96c: b               #0xb2a948
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xb4e270, size: 0x6c
    // 0xb4e270: EnterFrame
    //     0xb4e270: stp             fp, lr, [SP, #-0x10]!
    //     0xb4e274: mov             fp, SP
    // 0xb4e278: AllocStack(0x10)
    //     0xb4e278: sub             SP, SP, #0x10
    // 0xb4e27c: CheckStackOverflow
    //     0xb4e27c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb4e280: cmp             SP, x16
    //     0xb4e284: b.ls            #0xb4e2d4
    // 0xb4e288: LoadField: d2 = r2->field_f
    //     0xb4e288: ldur            d2, [x2, #0xf]
    // 0xb4e28c: stur            d2, [fp, #-8]
    // 0xb4e290: LoadField: d1 = r2->field_1f
    //     0xb4e290: ldur            d1, [x2, #0x1f]
    // 0xb4e294: mov             v0.16b, v2.16b
    // 0xb4e298: r0 = _childrenHeights()
    //     0xb4e298: bl              #0xb4e2dc  ; [package:flutter/src/cupertino/dialog.dart] _RenderPriorityColumn::_childrenHeights
    // 0xb4e29c: mov             x2, x0
    // 0xb4e2a0: mov             x3, x1
    // 0xb4e2a4: LoadField: d0 = r2->field_7
    //     0xb4e2a4: ldur            d0, [x2, #7]
    // 0xb4e2a8: LoadField: d1 = r3->field_7
    //     0xb4e2a8: ldur            d1, [x3, #7]
    // 0xb4e2ac: fadd            d2, d1, d0
    // 0xb4e2b0: stur            d2, [fp, #-0x10]
    // 0xb4e2b4: r0 = Size()
    //     0xb4e2b4: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb4e2b8: ldur            d0, [fp, #-8]
    // 0xb4e2bc: StoreField: r0->field_7 = d0
    //     0xb4e2bc: stur            d0, [x0, #7]
    // 0xb4e2c0: ldur            d0, [fp, #-0x10]
    // 0xb4e2c4: StoreField: r0->field_f = d0
    //     0xb4e2c4: stur            d0, [x0, #0xf]
    // 0xb4e2c8: LeaveFrame
    //     0xb4e2c8: mov             SP, fp
    //     0xb4e2cc: ldp             fp, lr, [SP], #0x10
    // 0xb4e2d0: ret
    //     0xb4e2d0: ret             
    // 0xb4e2d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb4e2d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb4e2d8: b               #0xb4e288
  }
  _ _childrenHeights(/* No info */) {
    // ** addr: 0xb4e2dc, size: 0x2b0
    // 0xb4e2dc: EnterFrame
    //     0xb4e2dc: stp             fp, lr, [SP, #-0x10]!
    //     0xb4e2e0: mov             fp, SP
    // 0xb4e2e4: AllocStack(0x20)
    //     0xb4e2e4: sub             SP, SP, #0x20
    // 0xb4e2e8: SetupParameters(_RenderPriorityColumn this /* r1 => r0, fp-0x8 */, dynamic _ /* d0 => d2, fp-0x10 */, dynamic _ /* d1 => d1, fp-0x18 */)
    //     0xb4e2e8: mov             x0, x1
    //     0xb4e2ec: mov             v2.16b, v0.16b
    //     0xb4e2f0: stur            x1, [fp, #-8]
    //     0xb4e2f4: stur            d0, [fp, #-0x10]
    //     0xb4e2f8: stur            d1, [fp, #-0x18]
    // 0xb4e2fc: CheckStackOverflow
    //     0xb4e2fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb4e300: cmp             SP, x16
    //     0xb4e304: b.ls            #0xb4e4e8
    // 0xb4e308: LoadField: r1 = r0->field_57
    //     0xb4e308: ldur            w1, [x0, #0x57]
    // 0xb4e30c: DecompressPointer r1
    //     0xb4e30c: add             x1, x1, HEAP, lsl #32
    // 0xb4e310: cmp             w1, NULL
    // 0xb4e314: b.eq            #0xb4e4f0
    // 0xb4e318: mov             v0.16b, v2.16b
    // 0xb4e31c: r0 = getMinIntrinsicHeight()
    //     0xb4e31c: bl              #0xb177d8  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicHeight
    // 0xb4e320: mov             v1.16b, v0.16b
    // 0xb4e324: ldur            x0, [fp, #-8]
    // 0xb4e328: stur            d1, [fp, #-0x20]
    // 0xb4e32c: LoadField: r1 = r0->field_5b
    //     0xb4e32c: ldur            w1, [x0, #0x5b]
    // 0xb4e330: DecompressPointer r1
    //     0xb4e330: add             x1, x1, HEAP, lsl #32
    // 0xb4e334: cmp             w1, NULL
    // 0xb4e338: b.eq            #0xb4e4f4
    // 0xb4e33c: ldur            d0, [fp, #-0x10]
    // 0xb4e340: r0 = getMinIntrinsicHeight()
    //     0xb4e340: bl              #0xb177d8  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicHeight
    // 0xb4e344: mov             v1.16b, v0.16b
    // 0xb4e348: ldur            d0, [fp, #-0x20]
    // 0xb4e34c: fadd            d2, d0, d1
    // 0xb4e350: ldur            d3, [fp, #-0x18]
    // 0xb4e354: fcmp            d3, d2
    // 0xb4e358: b.lt            #0xb4e3c0
    // 0xb4e35c: r1 = inline_Allocate_Double()
    //     0xb4e35c: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xb4e360: add             x1, x1, #0x10
    //     0xb4e364: cmp             x2, x1
    //     0xb4e368: b.ls            #0xb4e4f8
    //     0xb4e36c: str             x1, [THR, #0x60]  ; THR::top
    //     0xb4e370: sub             x1, x1, #0xf
    //     0xb4e374: mov             x2, #0xe19c
    //     0xb4e378: movk            x2, #3, lsl #16
    //     0xb4e37c: stur            x2, [x1, #-1]
    // 0xb4e380: dmb             ishst
    // 0xb4e384: StoreField: r1->field_7 = d0
    //     0xb4e384: stur            d0, [x1, #7]
    // 0xb4e388: r0 = inline_Allocate_Double()
    //     0xb4e388: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xb4e38c: add             x0, x0, #0x10
    //     0xb4e390: cmp             x2, x0
    //     0xb4e394: b.ls            #0xb4e50c
    //     0xb4e398: str             x0, [THR, #0x60]  ; THR::top
    //     0xb4e39c: sub             x0, x0, #0xf
    //     0xb4e3a0: mov             x2, #0xe19c
    //     0xb4e3a4: movk            x2, #3, lsl #16
    //     0xb4e3a8: stur            x2, [x0, #-1]
    // 0xb4e3ac: dmb             ishst
    // 0xb4e3b0: StoreField: r0->field_7 = d1
    //     0xb4e3b0: stur            d1, [x0, #7]
    // 0xb4e3b4: LeaveFrame
    //     0xb4e3b4: mov             SP, fp
    //     0xb4e3b8: ldp             fp, lr, [SP], #0x10
    // 0xb4e3bc: ret
    //     0xb4e3bc: ret             
    // 0xb4e3c0: ldur            x2, [fp, #-8]
    // 0xb4e3c4: LoadField: d2 = r2->field_97
    //     0xb4e3c4: ldur            d2, [x2, #0x97]
    // 0xb4e3c8: fmin            v4.2d, v2.2d, v1.2d
    // 0xb4e3cc: fsub            d1, d3, d0
    // 0xb4e3d0: fcmp            d1, d4
    // 0xb4e3d4: b.lt            #0xb4e43c
    // 0xb4e3d8: r1 = inline_Allocate_Double()
    //     0xb4e3d8: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xb4e3dc: add             x1, x1, #0x10
    //     0xb4e3e0: cmp             x2, x1
    //     0xb4e3e4: b.ls            #0xb4e524
    //     0xb4e3e8: str             x1, [THR, #0x60]  ; THR::top
    //     0xb4e3ec: sub             x1, x1, #0xf
    //     0xb4e3f0: mov             x2, #0xe19c
    //     0xb4e3f4: movk            x2, #3, lsl #16
    //     0xb4e3f8: stur            x2, [x1, #-1]
    // 0xb4e3fc: dmb             ishst
    // 0xb4e400: StoreField: r1->field_7 = d0
    //     0xb4e400: stur            d0, [x1, #7]
    // 0xb4e404: r0 = inline_Allocate_Double()
    //     0xb4e404: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xb4e408: add             x0, x0, #0x10
    //     0xb4e40c: cmp             x2, x0
    //     0xb4e410: b.ls            #0xb4e538
    //     0xb4e414: str             x0, [THR, #0x60]  ; THR::top
    //     0xb4e418: sub             x0, x0, #0xf
    //     0xb4e41c: mov             x2, #0xe19c
    //     0xb4e420: movk            x2, #3, lsl #16
    //     0xb4e424: stur            x2, [x0, #-1]
    // 0xb4e428: dmb             ishst
    // 0xb4e42c: StoreField: r0->field_7 = d1
    //     0xb4e42c: stur            d1, [x0, #7]
    // 0xb4e430: LeaveFrame
    //     0xb4e430: mov             SP, fp
    //     0xb4e434: ldp             fp, lr, [SP], #0x10
    // 0xb4e438: ret
    //     0xb4e438: ret             
    // 0xb4e43c: fcmp            d3, d4
    // 0xb4e440: b.lt            #0xb4e4ac
    // 0xb4e444: fsub            d0, d3, d4
    // 0xb4e448: r0 = inline_Allocate_Double()
    //     0xb4e448: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xb4e44c: add             x0, x0, #0x10
    //     0xb4e450: cmp             x2, x0
    //     0xb4e454: b.ls            #0xb4e550
    //     0xb4e458: str             x0, [THR, #0x60]  ; THR::top
    //     0xb4e45c: sub             x0, x0, #0xf
    //     0xb4e460: mov             x2, #0xe19c
    //     0xb4e464: movk            x2, #3, lsl #16
    //     0xb4e468: stur            x2, [x0, #-1]
    // 0xb4e46c: dmb             ishst
    // 0xb4e470: StoreField: r0->field_7 = d4
    //     0xb4e470: stur            d4, [x0, #7]
    // 0xb4e474: r1 = inline_Allocate_Double()
    //     0xb4e474: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xb4e478: add             x1, x1, #0x10
    //     0xb4e47c: cmp             x2, x1
    //     0xb4e480: b.ls            #0xb4e560
    //     0xb4e484: str             x1, [THR, #0x60]  ; THR::top
    //     0xb4e488: sub             x1, x1, #0xf
    //     0xb4e48c: mov             x2, #0xe19c
    //     0xb4e490: movk            x2, #3, lsl #16
    //     0xb4e494: stur            x2, [x1, #-1]
    // 0xb4e498: dmb             ishst
    // 0xb4e49c: StoreField: r1->field_7 = d0
    //     0xb4e49c: stur            d0, [x1, #7]
    // 0xb4e4a0: LeaveFrame
    //     0xb4e4a0: mov             SP, fp
    //     0xb4e4a4: ldp             fp, lr, [SP], #0x10
    // 0xb4e4a8: ret
    //     0xb4e4a8: ret             
    // 0xb4e4ac: r0 = inline_Allocate_Double()
    //     0xb4e4ac: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xb4e4b0: add             x0, x0, #0x10
    //     0xb4e4b4: cmp             x2, x0
    //     0xb4e4b8: b.ls            #0xb4e57c
    //     0xb4e4bc: str             x0, [THR, #0x60]  ; THR::top
    //     0xb4e4c0: sub             x0, x0, #0xf
    //     0xb4e4c4: mov             x2, #0xe19c
    //     0xb4e4c8: movk            x2, #3, lsl #16
    //     0xb4e4cc: stur            x2, [x0, #-1]
    // 0xb4e4d0: dmb             ishst
    // 0xb4e4d4: StoreField: r0->field_7 = d3
    //     0xb4e4d4: stur            d3, [x0, #7]
    // 0xb4e4d8: r1 = 0.000000
    //     0xb4e4d8: ldr             x1, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xb4e4dc: LeaveFrame
    //     0xb4e4dc: mov             SP, fp
    //     0xb4e4e0: ldp             fp, lr, [SP], #0x10
    // 0xb4e4e4: ret
    //     0xb4e4e4: ret             
    // 0xb4e4e8: r0 = StackOverflowSharedWithFPURegs()
    //     0xb4e4e8: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb4e4ec: b               #0xb4e308
    // 0xb4e4f0: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb4e4f0: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xb4e4f4: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb4e4f4: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xb4e4f8: stp             q0, q1, [SP, #-0x20]!
    // 0xb4e4fc: r0 = AllocateDouble()
    //     0xb4e4fc: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb4e500: mov             x1, x0
    // 0xb4e504: ldp             q0, q1, [SP], #0x20
    // 0xb4e508: b               #0xb4e384
    // 0xb4e50c: SaveReg d1
    //     0xb4e50c: str             q1, [SP, #-0x10]!
    // 0xb4e510: SaveReg r1
    //     0xb4e510: str             x1, [SP, #-8]!
    // 0xb4e514: r0 = AllocateDouble()
    //     0xb4e514: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb4e518: RestoreReg r1
    //     0xb4e518: ldr             x1, [SP], #8
    // 0xb4e51c: RestoreReg d1
    //     0xb4e51c: ldr             q1, [SP], #0x10
    // 0xb4e520: b               #0xb4e3b0
    // 0xb4e524: stp             q0, q1, [SP, #-0x20]!
    // 0xb4e528: r0 = AllocateDouble()
    //     0xb4e528: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb4e52c: mov             x1, x0
    // 0xb4e530: ldp             q0, q1, [SP], #0x20
    // 0xb4e534: b               #0xb4e400
    // 0xb4e538: SaveReg d1
    //     0xb4e538: str             q1, [SP, #-0x10]!
    // 0xb4e53c: SaveReg r1
    //     0xb4e53c: str             x1, [SP, #-8]!
    // 0xb4e540: r0 = AllocateDouble()
    //     0xb4e540: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb4e544: RestoreReg r1
    //     0xb4e544: ldr             x1, [SP], #8
    // 0xb4e548: RestoreReg d1
    //     0xb4e548: ldr             q1, [SP], #0x10
    // 0xb4e54c: b               #0xb4e42c
    // 0xb4e550: stp             q0, q4, [SP, #-0x20]!
    // 0xb4e554: r0 = AllocateDouble()
    //     0xb4e554: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb4e558: ldp             q0, q4, [SP], #0x20
    // 0xb4e55c: b               #0xb4e470
    // 0xb4e560: SaveReg d0
    //     0xb4e560: str             q0, [SP, #-0x10]!
    // 0xb4e564: SaveReg r0
    //     0xb4e564: str             x0, [SP, #-8]!
    // 0xb4e568: r0 = AllocateDouble()
    //     0xb4e568: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb4e56c: mov             x1, x0
    // 0xb4e570: RestoreReg r0
    //     0xb4e570: ldr             x0, [SP], #8
    // 0xb4e574: RestoreReg d0
    //     0xb4e574: ldr             q0, [SP], #0x10
    // 0xb4e578: b               #0xb4e49c
    // 0xb4e57c: SaveReg d3
    //     0xb4e57c: str             q3, [SP, #-0x10]!
    // 0xb4e580: r0 = AllocateDouble()
    //     0xb4e580: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb4e584: RestoreReg d3
    //     0xb4e584: ldr             q3, [SP], #0x10
    // 0xb4e588: b               #0xb4e4d4
  }
  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0xb5e6e0, size: 0x24
    // 0xb5e6e0: EnterFrame
    //     0xb5e6e0: stp             fp, lr, [SP, #-0x10]!
    //     0xb5e6e4: mov             fp, SP
    // 0xb5e6e8: ldr             x2, [fp, #0x10]
    // 0xb5e6ec: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0xb5e6ec: add             x1, PP, #0xcf, lsl #12  ; [pp+0xcf860] AnonymousClosure: (0xb2a8f8), in [package:flutter/src/cupertino/dialog.dart] _RenderPriorityColumn::computeMaxIntrinsicHeight (0xb2a86c)
    //     0xb5e6f0: ldr             x1, [x1, #0x860]
    // 0xb5e6f4: r0 = AllocateClosure()
    //     0xb5e6f4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb5e6f8: LeaveFrame
    //     0xb5e6f8: mov             SP, fp
    //     0xb5e6fc: ldp             fp, lr, [SP], #0x10
    // 0xb5e700: ret
    //     0xb5e700: ret             
  }
  _ performLayout(/* No info */) {
    // ** addr: 0xbbedcc, size: 0x2e8
    // 0xbbedcc: EnterFrame
    //     0xbbedcc: stp             fp, lr, [SP, #-0x10]!
    //     0xbbedd0: mov             fp, SP
    // 0xbbedd4: AllocStack(0x38)
    //     0xbbedd4: sub             SP, SP, #0x38
    // 0xbbedd8: SetupParameters(_RenderPriorityColumn this /* r1 => r3, fp-0x10 */)
    //     0xbbedd8: mov             x3, x1
    //     0xbbeddc: stur            x1, [fp, #-0x10]
    // 0xbbede0: CheckStackOverflow
    //     0xbbede0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbbede4: cmp             SP, x16
    //     0xbbede8: b.ls            #0xbbf094
    // 0xbbedec: LoadField: r4 = r3->field_27
    //     0xbbedec: ldur            w4, [x3, #0x27]
    // 0xbbedf0: DecompressPointer r4
    //     0xbbedf0: add             x4, x4, HEAP, lsl #32
    // 0xbbedf4: stur            x4, [fp, #-8]
    // 0xbbedf8: cmp             w4, NULL
    // 0xbbedfc: b.eq            #0xbbf078
    // 0xbbee00: mov             x0, x4
    // 0xbbee04: r2 = Null
    //     0xbbee04: mov             x2, NULL
    // 0xbbee08: r1 = Null
    //     0xbbee08: mov             x1, NULL
    // 0xbbee0c: r4 = LoadClassIdInstr(r0)
    //     0xbbee0c: ldur            x4, [x0, #-1]
    //     0xbbee10: ubfx            x4, x4, #0xc, #0x14
    // 0xbbee14: sub             x4, x4, #0xb46
    // 0xbbee18: cmp             x4, #1
    // 0xbbee1c: b.ls            #0xbbee30
    // 0xbbee20: r8 = BoxConstraints
    //     0xbbee20: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbbee24: r3 = Null
    //     0xbbee24: add             x3, PP, #0xcf, lsl #12  ; [pp+0xcf870] Null
    //     0xbbee28: ldr             x3, [x3, #0x870]
    // 0xbbee2c: r0 = BoxConstraints()
    //     0xbbee2c: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbbee30: ldur            x0, [fp, #-8]
    // 0xbbee34: LoadField: d2 = r0->field_f
    //     0xbbee34: ldur            d2, [x0, #0xf]
    // 0xbbee38: stur            d2, [fp, #-0x18]
    // 0xbbee3c: LoadField: d1 = r0->field_1f
    //     0xbbee3c: ldur            d1, [x0, #0x1f]
    // 0xbbee40: ldur            x1, [fp, #-0x10]
    // 0xbbee44: mov             v0.16b, v2.16b
    // 0xbbee48: r0 = _childrenHeights()
    //     0xbbee48: bl              #0xb4e2dc  ; [package:flutter/src/cupertino/dialog.dart] _RenderPriorityColumn::_childrenHeights
    // 0xbbee4c: mov             x2, x0
    // 0xbbee50: mov             x3, x1
    // 0xbbee54: LoadField: d0 = r2->field_7
    //     0xbbee54: ldur            d0, [x2, #7]
    // 0xbbee58: stur            d0, [fp, #-0x30]
    // 0xbbee5c: LoadField: d1 = r3->field_7
    //     0xbbee5c: ldur            d1, [x3, #7]
    // 0xbbee60: stur            d1, [fp, #-0x28]
    // 0xbbee64: fadd            d2, d1, d0
    // 0xbbee68: stur            d2, [fp, #-0x20]
    // 0xbbee6c: r0 = Size()
    //     0xbbee6c: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xbbee70: ldur            d0, [fp, #-0x18]
    // 0xbbee74: StoreField: r0->field_7 = d0
    //     0xbbee74: stur            d0, [x0, #7]
    // 0xbbee78: ldur            d1, [fp, #-0x20]
    // 0xbbee7c: StoreField: r0->field_f = d1
    //     0xbbee7c: stur            d1, [x0, #0xf]
    // 0xbbee80: ldur            x1, [fp, #-0x10]
    // 0xbbee84: StoreField: r1->field_4b = r0
    //     0xbbee84: stur            w0, [x1, #0x4b]
    //     0xbbee88: ldurb           w16, [x1, #-1]
    //     0xbbee8c: ldurb           w17, [x0, #-1]
    //     0xbbee90: and             x16, x17, x16, lsr #2
    //     0xbbee94: tst             x16, HEAP, lsr #32
    //     0xbbee98: b.eq            #0xbbeea0
    //     0xbbee9c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbbeea0: LoadField: r0 = r1->field_57
    //     0xbbeea0: ldur            w0, [x1, #0x57]
    // 0xbbeea4: DecompressPointer r0
    //     0xbbeea4: add             x0, x0, HEAP, lsl #32
    // 0xbbeea8: stur            x0, [fp, #-8]
    // 0xbbeeac: cmp             w0, NULL
    // 0xbbeeb0: b.eq            #0xbbf09c
    // 0xbbeeb4: r0 = BoxConstraints()
    //     0xbbeeb4: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xbbeeb8: ldur            d0, [fp, #-0x18]
    // 0xbbeebc: StoreField: r0->field_7 = d0
    //     0xbbeebc: stur            d0, [x0, #7]
    // 0xbbeec0: StoreField: r0->field_f = d0
    //     0xbbeec0: stur            d0, [x0, #0xf]
    // 0xbbeec4: ldur            d1, [fp, #-0x28]
    // 0xbbeec8: ArrayStore: r0[0] = d1  ; List_8
    //     0xbbeec8: stur            d1, [x0, #0x17]
    // 0xbbeecc: StoreField: r0->field_1f = d1
    //     0xbbeecc: stur            d1, [x0, #0x1f]
    // 0xbbeed0: ldur            x1, [fp, #-8]
    // 0xbbeed4: r2 = LoadClassIdInstr(r1)
    //     0xbbeed4: ldur            x2, [x1, #-1]
    //     0xbbeed8: ubfx            x2, x2, #0xc, #0x14
    // 0xbbeedc: r16 = true
    //     0xbbeedc: add             x16, NULL, #0x20  ; true
    // 0xbbeee0: str             x16, [SP]
    // 0xbbeee4: mov             x16, x0
    // 0xbbeee8: mov             x0, x2
    // 0xbbeeec: mov             x2, x16
    // 0xbbeef0: r4 = const [0, 0x3, 0x1, 0x2, parentUsesSize, 0x2, null]
    //     0xbbeef0: add             x4, PP, #0xd, lsl #12  ; [pp+0xded0] List(7) [0, 0x3, 0x1, 0x2, "parentUsesSize", 0x2, Null]
    //     0xbbeef4: ldr             x4, [x4, #0xed0]
    // 0xbbeef8: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0xbbeef8: mov             x17, #0xe6b9
    //     0xbbeefc: add             lr, x0, x17
    //     0xbbef00: ldr             lr, [x21, lr, lsl #3]
    //     0xbbef04: blr             lr
    // 0xbbef08: ldur            x3, [fp, #-0x10]
    // 0xbbef0c: LoadField: r0 = r3->field_57
    //     0xbbef0c: ldur            w0, [x3, #0x57]
    // 0xbbef10: DecompressPointer r0
    //     0xbbef10: add             x0, x0, HEAP, lsl #32
    // 0xbbef14: cmp             w0, NULL
    // 0xbbef18: b.eq            #0xbbf0a0
    // 0xbbef1c: LoadField: r4 = r0->field_7
    //     0xbbef1c: ldur            w4, [x0, #7]
    // 0xbbef20: DecompressPointer r4
    //     0xbbef20: add             x4, x4, HEAP, lsl #32
    // 0xbbef24: stur            x4, [fp, #-8]
    // 0xbbef28: cmp             w4, NULL
    // 0xbbef2c: b.eq            #0xbbf0a4
    // 0xbbef30: mov             x0, x4
    // 0xbbef34: r2 = Null
    //     0xbbef34: mov             x2, NULL
    // 0xbbef38: r1 = Null
    //     0xbbef38: mov             x1, NULL
    // 0xbbef3c: r4 = LoadClassIdInstr(r0)
    //     0xbbef3c: ldur            x4, [x0, #-1]
    //     0xbbef40: ubfx            x4, x4, #0xc, #0x14
    // 0xbbef44: r17 = 4212
    //     0xbbef44: mov             x17, #0x1074
    // 0xbbef48: cmp             x4, x17
    // 0xbbef4c: b.eq            #0xbbef64
    // 0xbbef50: r8 = FlexParentData
    //     0xbbef50: add             x8, PP, #0x85, lsl #12  ; [pp+0x85010] Type: FlexParentData
    //     0xbbef54: ldr             x8, [x8, #0x10]
    // 0xbbef58: r3 = Null
    //     0xbbef58: add             x3, PP, #0xcf, lsl #12  ; [pp+0xcf880] Null
    //     0xbbef5c: ldr             x3, [x3, #0x880]
    // 0xbbef60: r0 = DefaultTypeTest()
    //     0xbbef60: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbbef64: ldur            x0, [fp, #-8]
    // 0xbbef68: r1 = Instance_Offset
    //     0xbbef68: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xbbef6c: StoreField: r0->field_7 = r1
    //     0xbbef6c: stur            w1, [x0, #7]
    // 0xbbef70: ldur            x0, [fp, #-0x10]
    // 0xbbef74: LoadField: r1 = r0->field_5b
    //     0xbbef74: ldur            w1, [x0, #0x5b]
    // 0xbbef78: DecompressPointer r1
    //     0xbbef78: add             x1, x1, HEAP, lsl #32
    // 0xbbef7c: stur            x1, [fp, #-8]
    // 0xbbef80: cmp             w1, NULL
    // 0xbbef84: b.eq            #0xbbf0a8
    // 0xbbef88: r0 = BoxConstraints()
    //     0xbbef88: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xbbef8c: ldur            d0, [fp, #-0x18]
    // 0xbbef90: StoreField: r0->field_7 = d0
    //     0xbbef90: stur            d0, [x0, #7]
    // 0xbbef94: StoreField: r0->field_f = d0
    //     0xbbef94: stur            d0, [x0, #0xf]
    // 0xbbef98: ldur            d0, [fp, #-0x30]
    // 0xbbef9c: ArrayStore: r0[0] = d0  ; List_8
    //     0xbbef9c: stur            d0, [x0, #0x17]
    // 0xbbefa0: StoreField: r0->field_1f = d0
    //     0xbbefa0: stur            d0, [x0, #0x1f]
    // 0xbbefa4: ldur            x1, [fp, #-8]
    // 0xbbefa8: r2 = LoadClassIdInstr(r1)
    //     0xbbefa8: ldur            x2, [x1, #-1]
    //     0xbbefac: ubfx            x2, x2, #0xc, #0x14
    // 0xbbefb0: r16 = true
    //     0xbbefb0: add             x16, NULL, #0x20  ; true
    // 0xbbefb4: str             x16, [SP]
    // 0xbbefb8: mov             x16, x0
    // 0xbbefbc: mov             x0, x2
    // 0xbbefc0: mov             x2, x16
    // 0xbbefc4: r4 = const [0, 0x3, 0x1, 0x2, parentUsesSize, 0x2, null]
    //     0xbbefc4: add             x4, PP, #0xd, lsl #12  ; [pp+0xded0] List(7) [0, 0x3, 0x1, 0x2, "parentUsesSize", 0x2, Null]
    //     0xbbefc8: ldr             x4, [x4, #0xed0]
    // 0xbbefcc: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0xbbefcc: mov             x17, #0xe6b9
    //     0xbbefd0: add             lr, x0, x17
    //     0xbbefd4: ldr             lr, [x21, lr, lsl #3]
    //     0xbbefd8: blr             lr
    // 0xbbefdc: ldur            x0, [fp, #-0x10]
    // 0xbbefe0: LoadField: r1 = r0->field_5b
    //     0xbbefe0: ldur            w1, [x0, #0x5b]
    // 0xbbefe4: DecompressPointer r1
    //     0xbbefe4: add             x1, x1, HEAP, lsl #32
    // 0xbbefe8: cmp             w1, NULL
    // 0xbbefec: b.eq            #0xbbf0ac
    // 0xbbeff0: LoadField: r3 = r1->field_7
    //     0xbbeff0: ldur            w3, [x1, #7]
    // 0xbbeff4: DecompressPointer r3
    //     0xbbeff4: add             x3, x3, HEAP, lsl #32
    // 0xbbeff8: stur            x3, [fp, #-8]
    // 0xbbeffc: cmp             w3, NULL
    // 0xbbf000: b.eq            #0xbbf0b0
    // 0xbbf004: mov             x0, x3
    // 0xbbf008: r2 = Null
    //     0xbbf008: mov             x2, NULL
    // 0xbbf00c: r1 = Null
    //     0xbbf00c: mov             x1, NULL
    // 0xbbf010: r4 = LoadClassIdInstr(r0)
    //     0xbbf010: ldur            x4, [x0, #-1]
    //     0xbbf014: ubfx            x4, x4, #0xc, #0x14
    // 0xbbf018: r17 = 4212
    //     0xbbf018: mov             x17, #0x1074
    // 0xbbf01c: cmp             x4, x17
    // 0xbbf020: b.eq            #0xbbf038
    // 0xbbf024: r8 = FlexParentData
    //     0xbbf024: add             x8, PP, #0x85, lsl #12  ; [pp+0x85010] Type: FlexParentData
    //     0xbbf028: ldr             x8, [x8, #0x10]
    // 0xbbf02c: r3 = Null
    //     0xbbf02c: add             x3, PP, #0xcf, lsl #12  ; [pp+0xcf890] Null
    //     0xbbf030: ldr             x3, [x3, #0x890]
    // 0xbbf034: r0 = DefaultTypeTest()
    //     0xbbf034: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbbf038: r0 = Offset()
    //     0xbbf038: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xbbf03c: StoreField: r0->field_7 = rZR
    //     0xbbf03c: stur            xzr, [x0, #7]
    // 0xbbf040: ldur            d0, [fp, #-0x28]
    // 0xbbf044: StoreField: r0->field_f = d0
    //     0xbbf044: stur            d0, [x0, #0xf]
    // 0xbbf048: ldur            x1, [fp, #-8]
    // 0xbbf04c: StoreField: r1->field_7 = r0
    //     0xbbf04c: stur            w0, [x1, #7]
    //     0xbbf050: ldurb           w16, [x1, #-1]
    //     0xbbf054: ldurb           w17, [x0, #-1]
    //     0xbbf058: and             x16, x17, x16, lsr #2
    //     0xbbf05c: tst             x16, HEAP, lsr #32
    //     0xbbf060: b.eq            #0xbbf068
    //     0xbbf064: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbbf068: r0 = Null
    //     0xbbf068: mov             x0, NULL
    // 0xbbf06c: LeaveFrame
    //     0xbbf06c: mov             SP, fp
    //     0xbbf070: ldp             fp, lr, [SP], #0x10
    // 0xbbf074: ret
    //     0xbbf074: ret             
    // 0xbbf078: r0 = StateError()
    //     0xbbf078: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbbf07c: mov             x1, x0
    // 0xbbf080: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbbf080: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbbf084: StoreField: r1->field_b = r0
    //     0xbbf084: stur            w0, [x1, #0xb]
    // 0xbbf088: mov             x0, x1
    // 0xbbf08c: r0 = Throw()
    //     0xbbf08c: bl              #0x13ddb2c  ; ThrowStub
    // 0xbbf090: brk             #0
    // 0xbbf094: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbbf094: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbbf098: b               #0xbbedec
    // 0xbbf09c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbbf09c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbbf0a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbf0a0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbbf0a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbf0a4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbbf0a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbf0a8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbbf0ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbf0ac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbbf0b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbf0b0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ bottomMinHeight=(/* No info */) {
    // ** addr: 0xcee448, size: 0x40
    // 0xcee448: EnterFrame
    //     0xcee448: stp             fp, lr, [SP, #-0x10]!
    //     0xcee44c: mov             fp, SP
    // 0xcee450: CheckStackOverflow
    //     0xcee450: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcee454: cmp             SP, x16
    //     0xcee458: b.ls            #0xcee480
    // 0xcee45c: LoadField: d1 = r1->field_97
    //     0xcee45c: ldur            d1, [x1, #0x97]
    // 0xcee460: fcmp            d0, d1
    // 0xcee464: b.eq            #0xcee470
    // 0xcee468: StoreField: r1->field_97 = d0
    //     0xcee468: stur            d0, [x1, #0x97]
    // 0xcee46c: r0 = markNeedsLayout()
    //     0xcee46c: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcee470: r0 = Null
    //     0xcee470: mov             x0, NULL
    // 0xcee474: LeaveFrame
    //     0xcee474: mov             SP, fp
    //     0xcee478: ldp             fp, lr, [SP], #0x10
    // 0xcee47c: ret
    //     0xcee47c: ret             
    // 0xcee480: r0 = StackOverflowSharedWithFPURegs()
    //     0xcee480: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xcee484: b               #0xcee45c
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x10eff64, size: 0x24
    // 0x10eff64: EnterFrame
    //     0x10eff64: stp             fp, lr, [SP, #-0x10]!
    //     0x10eff68: mov             fp, SP
    // 0x10eff6c: ldr             x2, [fp, #0x10]
    // 0x10eff70: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x10eff70: add             x1, PP, #0xcf, lsl #12  ; [pp+0xcf868] AnonymousClosure: (0xb23de0), in [package:flutter/src/cupertino/dialog.dart] _RenderPriorityColumn::computeMinIntrinsicHeight (0xb23d54)
    //     0x10eff74: ldr             x1, [x1, #0x868]
    // 0x10eff78: r0 = AllocateClosure()
    //     0x10eff78: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10eff7c: LeaveFrame
    //     0x10eff7c: mov             SP, fp
    //     0x10eff80: ldp             fp, lr, [SP], #0x10
    // 0x10eff84: ret
    //     0x10eff84: ret             
  }
}

// class id: 4864, size: 0xa0, field offset: 0x98
class _RenderAlertDialogActionsLayout extends RenderFlex {

  _ computeMinIntrinsicHeight(/* No info */) {
    // ** addr: 0xb237dc, size: 0x100
    // 0xb237dc: EnterFrame
    //     0xb237dc: stp             fp, lr, [SP, #-0x10]!
    //     0xb237e0: mov             fp, SP
    // 0xb237e4: AllocStack(0x20)
    //     0xb237e4: sub             SP, SP, #0x20
    // 0xb237e8: SetupParameters(_RenderAlertDialogActionsLayout this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xb237e8: mov             x0, x1
    //     0xb237ec: stur            x1, [fp, #-8]
    //     0xb237f0: stur            x2, [fp, #-0x10]
    // 0xb237f4: CheckStackOverflow
    //     0xb237f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb237f8: cmp             SP, x16
    //     0xb237fc: b.ls            #0xb238c4
    // 0xb23800: LoadField: d1 = r2->field_7
    //     0xb23800: ldur            d1, [x2, #7]
    // 0xb23804: mov             x1, x0
    // 0xb23808: mov             v0.16b, v1.16b
    // 0xb2380c: stur            d1, [fp, #-0x20]
    // 0xb23810: r0 = _useHorizontalLayout()
    //     0xb23810: bl              #0xb23ab8  ; [package:flutter/src/cupertino/dialog.dart] _RenderAlertDialogActionsLayout::_useHorizontalLayout
    // 0xb23814: tbz             w0, #4, #0xb23830
    // 0xb23818: ldur            x1, [fp, #-8]
    // 0xb2381c: ldur            x2, [fp, #-0x10]
    // 0xb23820: r0 = computeMinIntrinsicHeight()
    //     0xb23820: bl              #0xb23e58  ; [package:flutter/src/rendering/flex.dart] RenderFlex::computeMinIntrinsicHeight
    // 0xb23824: LeaveFrame
    //     0xb23824: mov             SP, fp
    //     0xb23828: ldp             fp, lr, [SP], #0x10
    // 0xb2382c: ret
    //     0xb2382c: ret             
    // 0xb23830: ldur            x1, [fp, #-8]
    // 0xb23834: ldur            d0, [fp, #-0x20]
    // 0xb23838: r0 = horizontalSlotWidthFor()
    //     0xb23838: bl              #0xb23aa0  ; [package:flutter/src/cupertino/dialog.dart] _RenderAlertDialogActionsLayout::horizontalSlotWidthFor
    // 0xb2383c: r0 = inline_Allocate_Double()
    //     0xb2383c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb23840: add             x0, x0, #0x10
    //     0xb23844: cmp             x1, x0
    //     0xb23848: b.ls            #0xb238cc
    //     0xb2384c: str             x0, [THR, #0x60]  ; THR::top
    //     0xb23850: sub             x0, x0, #0xf
    //     0xb23854: mov             x1, #0xe19c
    //     0xb23858: movk            x1, #3, lsl #16
    //     0xb2385c: stur            x1, [x0, #-1]
    // 0xb23860: dmb             ishst
    // 0xb23864: StoreField: r0->field_7 = d0
    //     0xb23864: stur            d0, [x0, #7]
    // 0xb23868: stur            x0, [fp, #-0x10]
    // 0xb2386c: r1 = 2
    //     0xb2386c: mov             x1, #2
    // 0xb23870: r0 = AllocateContext()
    //     0xb23870: bl              #0x13de838  ; AllocateContextStub
    // 0xb23874: mov             x3, x0
    // 0xb23878: ldur            x0, [fp, #-0x10]
    // 0xb2387c: stur            x3, [fp, #-0x18]
    // 0xb23880: StoreField: r3->field_f = r0
    //     0xb23880: stur            w0, [x3, #0xf]
    // 0xb23884: r0 = 0.000000
    //     0xb23884: ldr             x0, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xb23888: StoreField: r3->field_13 = r0
    //     0xb23888: stur            w0, [x3, #0x13]
    // 0xb2388c: mov             x2, x3
    // 0xb23890: r1 = Function '<anonymous closure>':.
    //     0xb23890: add             x1, PP, #0xd1, lsl #12  ; [pp+0xd1a00] AnonymousClosure: (0xb23c8c), in [package:flutter/src/cupertino/dialog.dart] _RenderAlertDialogActionsLayout::computeMinIntrinsicHeight (0xb237dc)
    //     0xb23894: ldr             x1, [x1, #0xa00]
    // 0xb23898: r0 = AllocateClosure()
    //     0xb23898: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb2389c: ldur            x1, [fp, #-8]
    // 0xb238a0: mov             x2, x0
    // 0xb238a4: r0 = _forEachSlot()
    //     0xb238a4: bl              #0xb23954  ; [package:flutter/src/cupertino/dialog.dart] _RenderAlertDialogActionsLayout::_forEachSlot
    // 0xb238a8: ldur            x0, [fp, #-0x18]
    // 0xb238ac: LoadField: r1 = r0->field_13
    //     0xb238ac: ldur            w1, [x0, #0x13]
    // 0xb238b0: DecompressPointer r1
    //     0xb238b0: add             x1, x1, HEAP, lsl #32
    // 0xb238b4: LoadField: d0 = r1->field_7
    //     0xb238b4: ldur            d0, [x1, #7]
    // 0xb238b8: LeaveFrame
    //     0xb238b8: mov             SP, fp
    //     0xb238bc: ldp             fp, lr, [SP], #0x10
    // 0xb238c0: ret
    //     0xb238c0: ret             
    // 0xb238c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb238c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb238c8: b               #0xb23800
    // 0xb238cc: SaveReg d0
    //     0xb238cc: str             q0, [SP, #-0x10]!
    // 0xb238d0: r0 = AllocateDouble()
    //     0xb238d0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb238d4: RestoreReg d0
    //     0xb238d4: ldr             q0, [SP], #0x10
    // 0xb238d8: b               #0xb23864
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0xb238dc, size: 0x78
    // 0xb238dc: EnterFrame
    //     0xb238dc: stp             fp, lr, [SP, #-0x10]!
    //     0xb238e0: mov             fp, SP
    // 0xb238e4: ldr             x0, [fp, #0x18]
    // 0xb238e8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb238e8: ldur            w1, [x0, #0x17]
    // 0xb238ec: DecompressPointer r1
    //     0xb238ec: add             x1, x1, HEAP, lsl #32
    // 0xb238f0: CheckStackOverflow
    //     0xb238f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb238f4: cmp             SP, x16
    //     0xb238f8: b.ls            #0xb2393c
    // 0xb238fc: ldr             x2, [fp, #0x10]
    // 0xb23900: r0 = computeMinIntrinsicHeight()
    //     0xb23900: bl              #0xb237dc  ; [package:flutter/src/cupertino/dialog.dart] _RenderAlertDialogActionsLayout::computeMinIntrinsicHeight
    // 0xb23904: r0 = inline_Allocate_Double()
    //     0xb23904: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb23908: add             x0, x0, #0x10
    //     0xb2390c: cmp             x1, x0
    //     0xb23910: b.ls            #0xb23944
    //     0xb23914: str             x0, [THR, #0x60]  ; THR::top
    //     0xb23918: sub             x0, x0, #0xf
    //     0xb2391c: mov             x1, #0xe19c
    //     0xb23920: movk            x1, #3, lsl #16
    //     0xb23924: stur            x1, [x0, #-1]
    // 0xb23928: dmb             ishst
    // 0xb2392c: StoreField: r0->field_7 = d0
    //     0xb2392c: stur            d0, [x0, #7]
    // 0xb23930: LeaveFrame
    //     0xb23930: mov             SP, fp
    //     0xb23934: ldp             fp, lr, [SP], #0x10
    // 0xb23938: ret
    //     0xb23938: ret             
    // 0xb2393c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2393c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb23940: b               #0xb238fc
    // 0xb23944: SaveReg d0
    //     0xb23944: str             q0, [SP, #-0x10]!
    // 0xb23948: r0 = AllocateDouble()
    //     0xb23948: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2394c: RestoreReg d0
    //     0xb2394c: ldr             q0, [SP], #0x10
    // 0xb23950: b               #0xb2392c
  }
  _ _forEachSlot(/* No info */) {
    // ** addr: 0xb23954, size: 0x14c
    // 0xb23954: EnterFrame
    //     0xb23954: stp             fp, lr, [SP, #-0x10]!
    //     0xb23958: mov             fp, SP
    // 0xb2395c: AllocStack(0x28)
    //     0xb2395c: sub             SP, SP, #0x28
    // 0xb23960: SetupParameters(_RenderAlertDialogActionsLayout this /* r1 => r0 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xb23960: mov             x0, x1
    //     0xb23964: mov             x1, x2
    //     0xb23968: stur            x2, [fp, #-0x10]
    // 0xb2396c: CheckStackOverflow
    //     0xb2396c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb23970: cmp             SP, x16
    //     0xb23974: b.ls            #0xb23a80
    // 0xb23978: LoadField: r2 = r0->field_57
    //     0xb23978: ldur            w2, [x0, #0x57]
    // 0xb2397c: DecompressPointer r2
    //     0xb2397c: add             x2, x2, HEAP, lsl #32
    // 0xb23980: cmp             w2, NULL
    // 0xb23984: b.eq            #0xb23a88
    // 0xb23988: stur            x2, [fp, #-8]
    // 0xb2398c: CheckStackOverflow
    //     0xb2398c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb23990: cmp             SP, x16
    //     0xb23994: b.ls            #0xb23a8c
    // 0xb23998: stp             x2, x1, [SP]
    // 0xb2399c: mov             x0, x1
    // 0xb239a0: ClosureCall
    //     0xb239a0: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xb239a4: ldur            x2, [x0, #0x1f]
    //     0xb239a8: blr             x2
    // 0xb239ac: ldur            x0, [fp, #-8]
    // 0xb239b0: LoadField: r3 = r0->field_7
    //     0xb239b0: ldur            w3, [x0, #7]
    // 0xb239b4: DecompressPointer r3
    //     0xb239b4: add             x3, x3, HEAP, lsl #32
    // 0xb239b8: stur            x3, [fp, #-0x18]
    // 0xb239bc: cmp             w3, NULL
    // 0xb239c0: b.eq            #0xb23a94
    // 0xb239c4: mov             x0, x3
    // 0xb239c8: r2 = Null
    //     0xb239c8: mov             x2, NULL
    // 0xb239cc: r1 = Null
    //     0xb239cc: mov             x1, NULL
    // 0xb239d0: r4 = LoadClassIdInstr(r0)
    //     0xb239d0: ldur            x4, [x0, #-1]
    //     0xb239d4: ubfx            x4, x4, #0xc, #0x14
    // 0xb239d8: r17 = 4212
    //     0xb239d8: mov             x17, #0x1074
    // 0xb239dc: cmp             x4, x17
    // 0xb239e0: b.eq            #0xb239f8
    // 0xb239e4: r8 = FlexParentData
    //     0xb239e4: add             x8, PP, #0x85, lsl #12  ; [pp+0x85010] Type: FlexParentData
    //     0xb239e8: ldr             x8, [x8, #0x10]
    // 0xb239ec: r3 = Null
    //     0xb239ec: add             x3, PP, #0xd1, lsl #12  ; [pp+0xd19e0] Null
    //     0xb239f0: ldr             x3, [x3, #0x9e0]
    // 0xb239f4: r0 = DefaultTypeTest()
    //     0xb239f4: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb239f8: ldur            x0, [fp, #-0x18]
    // 0xb239fc: LoadField: r1 = r0->field_13
    //     0xb239fc: ldur            w1, [x0, #0x13]
    // 0xb23a00: DecompressPointer r1
    //     0xb23a00: add             x1, x1, HEAP, lsl #32
    // 0xb23a04: cmp             w1, NULL
    // 0xb23a08: b.eq            #0xb23a70
    // 0xb23a0c: LoadField: r3 = r1->field_7
    //     0xb23a0c: ldur            w3, [x1, #7]
    // 0xb23a10: DecompressPointer r3
    //     0xb23a10: add             x3, x3, HEAP, lsl #32
    // 0xb23a14: stur            x3, [fp, #-8]
    // 0xb23a18: cmp             w3, NULL
    // 0xb23a1c: b.eq            #0xb23a98
    // 0xb23a20: mov             x0, x3
    // 0xb23a24: r2 = Null
    //     0xb23a24: mov             x2, NULL
    // 0xb23a28: r1 = Null
    //     0xb23a28: mov             x1, NULL
    // 0xb23a2c: r4 = LoadClassIdInstr(r0)
    //     0xb23a2c: ldur            x4, [x0, #-1]
    //     0xb23a30: ubfx            x4, x4, #0xc, #0x14
    // 0xb23a34: r17 = 4212
    //     0xb23a34: mov             x17, #0x1074
    // 0xb23a38: cmp             x4, x17
    // 0xb23a3c: b.eq            #0xb23a54
    // 0xb23a40: r8 = FlexParentData
    //     0xb23a40: add             x8, PP, #0x85, lsl #12  ; [pp+0x85010] Type: FlexParentData
    //     0xb23a44: ldr             x8, [x8, #0x10]
    // 0xb23a48: r3 = Null
    //     0xb23a48: add             x3, PP, #0xd1, lsl #12  ; [pp+0xd19f0] Null
    //     0xb23a4c: ldr             x3, [x3, #0x9f0]
    // 0xb23a50: r0 = DefaultTypeTest()
    //     0xb23a50: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb23a54: ldur            x1, [fp, #-8]
    // 0xb23a58: LoadField: r2 = r1->field_13
    //     0xb23a58: ldur            w2, [x1, #0x13]
    // 0xb23a5c: DecompressPointer r2
    //     0xb23a5c: add             x2, x2, HEAP, lsl #32
    // 0xb23a60: cmp             w2, NULL
    // 0xb23a64: b.eq            #0xb23a9c
    // 0xb23a68: ldur            x1, [fp, #-0x10]
    // 0xb23a6c: b               #0xb23988
    // 0xb23a70: r0 = Null
    //     0xb23a70: mov             x0, NULL
    // 0xb23a74: LeaveFrame
    //     0xb23a74: mov             SP, fp
    //     0xb23a78: ldp             fp, lr, [SP], #0x10
    // 0xb23a7c: ret
    //     0xb23a7c: ret             
    // 0xb23a80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb23a80: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb23a84: b               #0xb23978
    // 0xb23a88: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb23a88: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb23a8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb23a8c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb23a90: b               #0xb23998
    // 0xb23a94: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb23a94: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb23a98: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb23a98: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb23a9c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb23a9c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ horizontalSlotWidthFor(/* No info */) {
    // ** addr: 0xb23aa0, size: 0x18
    // 0xb23aa0: d2 = 2.000000
    //     0xb23aa0: fmov            d2, #2.00000000
    // 0xb23aa4: d1 = 0.300000
    //     0xb23aa4: add             x17, PP, #0x13, lsl #12  ; [pp+0x13a88] IMM: double(0.3) from 0x3fd3333333333333
    //     0xb23aa8: ldr             d1, [x17, #0xa88]
    // 0xb23aac: fsub            d3, d0, d1
    // 0xb23ab0: fdiv            d0, d3, d2
    // 0xb23ab4: ret
    //     0xb23ab4: ret             
  }
  _ _useHorizontalLayout(/* No info */) {
    // ** addr: 0xb23ab8, size: 0x1d4
    // 0xb23ab8: EnterFrame
    //     0xb23ab8: stp             fp, lr, [SP, #-0x10]!
    //     0xb23abc: mov             fp, SP
    // 0xb23ac0: AllocStack(0x40)
    //     0xb23ac0: sub             SP, SP, #0x40
    // 0xb23ac4: SetupParameters(_RenderAlertDialogActionsLayout this /* r1 => r0, fp-0x8 */)
    //     0xb23ac4: mov             x0, x1
    //     0xb23ac8: stur            x1, [fp, #-8]
    // 0xb23acc: CheckStackOverflow
    //     0xb23acc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb23ad0: cmp             SP, x16
    //     0xb23ad4: b.ls            #0xb23c6c
    // 0xb23ad8: LoadField: r1 = r0->field_4f
    //     0xb23ad8: ldur            x1, [x0, #0x4f]
    // 0xb23adc: cmp             x1, #3
    // 0xb23ae0: b.eq            #0xb23af4
    // 0xb23ae4: r0 = false
    //     0xb23ae4: add             x0, NULL, #0x30  ; false
    // 0xb23ae8: LeaveFrame
    //     0xb23ae8: mov             SP, fp
    //     0xb23aec: ldp             fp, lr, [SP], #0x10
    // 0xb23af0: ret
    //     0xb23af0: ret             
    // 0xb23af4: mov             x1, x0
    // 0xb23af8: r0 = horizontalSlotWidthFor()
    //     0xb23af8: bl              #0xb23aa0  ; [package:flutter/src/cupertino/dialog.dart] _RenderAlertDialogActionsLayout::horizontalSlotWidthFor
    // 0xb23afc: ldur            x0, [fp, #-8]
    // 0xb23b00: stur            d0, [fp, #-0x18]
    // 0xb23b04: LoadField: r1 = r0->field_57
    //     0xb23b04: ldur            w1, [x0, #0x57]
    // 0xb23b08: DecompressPointer r1
    //     0xb23b08: add             x1, x1, HEAP, lsl #32
    // 0xb23b0c: cmp             w1, NULL
    // 0xb23b10: b.eq            #0xb23c74
    // 0xb23b14: stur            x1, [fp, #-8]
    // 0xb23b18: CheckStackOverflow
    //     0xb23b18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb23b1c: cmp             SP, x16
    //     0xb23b20: b.ls            #0xb23c78
    // 0xb23b24: r0 = LoadClassIdInstr(r1)
    //     0xb23b24: ldur            x0, [x1, #-1]
    //     0xb23b28: ubfx            x0, x0, #0xc, #0x14
    // 0xb23b2c: str             x1, [SP]
    // 0xb23b30: r0 = GDT[cid_x0 + 0x12498]()
    //     0xb23b30: mov             x17, #0x2498
    //     0xb23b34: movk            x17, #1, lsl #16
    //     0xb23b38: add             lr, x0, x17
    //     0xb23b3c: ldr             lr, [x21, lr, lsl #3]
    //     0xb23b40: blr             lr
    // 0xb23b44: r16 = <double, double>
    //     0xb23b44: add             x16, PP, #0x7c, lsl #12  ; [pp+0x7c228] TypeArguments: <double, double>
    //     0xb23b48: ldr             x16, [x16, #0x228]
    // 0xb23b4c: ldur            lr, [fp, #-8]
    // 0xb23b50: stp             lr, x16, [SP, #0x18]
    // 0xb23b54: r16 = Instance__IntrinsicDimension
    //     0xb23b54: add             x16, PP, #0x96, lsl #12  ; [pp+0x969d8] Obj!_IntrinsicDimension@12c46a1
    //     0xb23b58: ldr             x16, [x16, #0x9d8]
    // 0xb23b5c: r30 = inf
    //     0xb23b5c: add             lr, PP, #0x15, lsl #12  ; [pp+0x158a8] inf
    //     0xb23b60: ldr             lr, [lr, #0x8a8]
    // 0xb23b64: stp             lr, x16, [SP, #8]
    // 0xb23b68: str             x0, [SP]
    // 0xb23b6c: r4 = const [0x2, 0x4, 0x4, 0x4, null]
    //     0xb23b6c: ldr             x4, [PP, #0x700]  ; [pp+0x700] List(5) [0x2, 0x4, 0x4, 0x4, Null]
    // 0xb23b70: r0 = _computeIntrinsics()
    //     0xb23b70: bl              #0xb16358  ; [package:flutter/src/rendering/box.dart] RenderBox::_computeIntrinsics
    // 0xb23b74: LoadField: d0 = r0->field_7
    //     0xb23b74: ldur            d0, [x0, #7]
    // 0xb23b78: ldur            d1, [fp, #-0x18]
    // 0xb23b7c: fcmp            d0, d1
    // 0xb23b80: b.gt            #0xb23c5c
    // 0xb23b84: ldur            x0, [fp, #-8]
    // 0xb23b88: LoadField: r3 = r0->field_7
    //     0xb23b88: ldur            w3, [x0, #7]
    // 0xb23b8c: DecompressPointer r3
    //     0xb23b8c: add             x3, x3, HEAP, lsl #32
    // 0xb23b90: stur            x3, [fp, #-0x10]
    // 0xb23b94: cmp             w3, NULL
    // 0xb23b98: b.eq            #0xb23c80
    // 0xb23b9c: mov             x0, x3
    // 0xb23ba0: r2 = Null
    //     0xb23ba0: mov             x2, NULL
    // 0xb23ba4: r1 = Null
    //     0xb23ba4: mov             x1, NULL
    // 0xb23ba8: r4 = LoadClassIdInstr(r0)
    //     0xb23ba8: ldur            x4, [x0, #-1]
    //     0xb23bac: ubfx            x4, x4, #0xc, #0x14
    // 0xb23bb0: r17 = 4212
    //     0xb23bb0: mov             x17, #0x1074
    // 0xb23bb4: cmp             x4, x17
    // 0xb23bb8: b.eq            #0xb23bd0
    // 0xb23bbc: r8 = FlexParentData
    //     0xb23bbc: add             x8, PP, #0x85, lsl #12  ; [pp+0x85010] Type: FlexParentData
    //     0xb23bc0: ldr             x8, [x8, #0x10]
    // 0xb23bc4: r3 = Null
    //     0xb23bc4: add             x3, PP, #0xd1, lsl #12  ; [pp+0xd19b8] Null
    //     0xb23bc8: ldr             x3, [x3, #0x9b8]
    // 0xb23bcc: r0 = DefaultTypeTest()
    //     0xb23bcc: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb23bd0: ldur            x0, [fp, #-0x10]
    // 0xb23bd4: LoadField: r1 = r0->field_13
    //     0xb23bd4: ldur            w1, [x0, #0x13]
    // 0xb23bd8: DecompressPointer r1
    //     0xb23bd8: add             x1, x1, HEAP, lsl #32
    // 0xb23bdc: cmp             w1, NULL
    // 0xb23be0: b.eq            #0xb23c4c
    // 0xb23be4: LoadField: r3 = r1->field_7
    //     0xb23be4: ldur            w3, [x1, #7]
    // 0xb23be8: DecompressPointer r3
    //     0xb23be8: add             x3, x3, HEAP, lsl #32
    // 0xb23bec: stur            x3, [fp, #-8]
    // 0xb23bf0: cmp             w3, NULL
    // 0xb23bf4: b.eq            #0xb23c84
    // 0xb23bf8: mov             x0, x3
    // 0xb23bfc: r2 = Null
    //     0xb23bfc: mov             x2, NULL
    // 0xb23c00: r1 = Null
    //     0xb23c00: mov             x1, NULL
    // 0xb23c04: r4 = LoadClassIdInstr(r0)
    //     0xb23c04: ldur            x4, [x0, #-1]
    //     0xb23c08: ubfx            x4, x4, #0xc, #0x14
    // 0xb23c0c: r17 = 4212
    //     0xb23c0c: mov             x17, #0x1074
    // 0xb23c10: cmp             x4, x17
    // 0xb23c14: b.eq            #0xb23c2c
    // 0xb23c18: r8 = FlexParentData
    //     0xb23c18: add             x8, PP, #0x85, lsl #12  ; [pp+0x85010] Type: FlexParentData
    //     0xb23c1c: ldr             x8, [x8, #0x10]
    // 0xb23c20: r3 = Null
    //     0xb23c20: add             x3, PP, #0xd1, lsl #12  ; [pp+0xd19c8] Null
    //     0xb23c24: ldr             x3, [x3, #0x9c8]
    // 0xb23c28: r0 = DefaultTypeTest()
    //     0xb23c28: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb23c2c: ldur            x1, [fp, #-8]
    // 0xb23c30: LoadField: r0 = r1->field_13
    //     0xb23c30: ldur            w0, [x1, #0x13]
    // 0xb23c34: DecompressPointer r0
    //     0xb23c34: add             x0, x0, HEAP, lsl #32
    // 0xb23c38: cmp             w0, NULL
    // 0xb23c3c: b.eq            #0xb23c88
    // 0xb23c40: mov             x1, x0
    // 0xb23c44: ldur            d0, [fp, #-0x18]
    // 0xb23c48: b               #0xb23b14
    // 0xb23c4c: r0 = true
    //     0xb23c4c: add             x0, NULL, #0x20  ; true
    // 0xb23c50: LeaveFrame
    //     0xb23c50: mov             SP, fp
    //     0xb23c54: ldp             fp, lr, [SP], #0x10
    // 0xb23c58: ret
    //     0xb23c58: ret             
    // 0xb23c5c: r0 = false
    //     0xb23c5c: add             x0, NULL, #0x30  ; false
    // 0xb23c60: LeaveFrame
    //     0xb23c60: mov             SP, fp
    //     0xb23c64: ldp             fp, lr, [SP], #0x10
    // 0xb23c68: ret
    //     0xb23c68: ret             
    // 0xb23c6c: r0 = StackOverflowSharedWithFPURegs()
    //     0xb23c6c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb23c70: b               #0xb23ad8
    // 0xb23c74: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb23c74: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xb23c78: r0 = StackOverflowSharedWithFPURegs()
    //     0xb23c78: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb23c7c: b               #0xb23b24
    // 0xb23c80: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb23c80: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xb23c84: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb23c84: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb23c88: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb23c88: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, RenderBox) {
    // ** addr: 0xb23c8c, size: 0xc8
    // 0xb23c8c: EnterFrame
    //     0xb23c8c: stp             fp, lr, [SP, #-0x10]!
    //     0xb23c90: mov             fp, SP
    // 0xb23c94: AllocStack(0x10)
    //     0xb23c94: sub             SP, SP, #0x10
    // 0xb23c98: SetupParameters([dynamic _ /* r0 */])
    //     0xb23c98: ldr             x0, [fp, #0x18]
    //     0xb23c9c: ldur            w2, [x0, #0x17]
    //     0xb23ca0: add             x2, x2, HEAP, lsl #32
    //     0xb23ca4: stur            x2, [fp, #-0x10]
    // 0xb23ca8: CheckStackOverflow
    //     0xb23ca8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb23cac: cmp             SP, x16
    //     0xb23cb0: b.ls            #0xb23d3c
    // 0xb23cb4: LoadField: r0 = r2->field_13
    //     0xb23cb4: ldur            w0, [x2, #0x13]
    // 0xb23cb8: DecompressPointer r0
    //     0xb23cb8: add             x0, x0, HEAP, lsl #32
    // 0xb23cbc: stur            x0, [fp, #-8]
    // 0xb23cc0: LoadField: r1 = r2->field_f
    //     0xb23cc0: ldur            w1, [x2, #0xf]
    // 0xb23cc4: DecompressPointer r1
    //     0xb23cc4: add             x1, x1, HEAP, lsl #32
    // 0xb23cc8: LoadField: d0 = r1->field_7
    //     0xb23cc8: ldur            d0, [x1, #7]
    // 0xb23ccc: ldr             x1, [fp, #0x10]
    // 0xb23cd0: r0 = getMinIntrinsicHeight()
    //     0xb23cd0: bl              #0xb177d8  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicHeight
    // 0xb23cd4: ldur            x1, [fp, #-8]
    // 0xb23cd8: LoadField: d1 = r1->field_7
    //     0xb23cd8: ldur            d1, [x1, #7]
    // 0xb23cdc: fmax            v2.2d, v1.2d, v0.2d
    // 0xb23ce0: r0 = inline_Allocate_Double()
    //     0xb23ce0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb23ce4: add             x0, x0, #0x10
    //     0xb23ce8: cmp             x1, x0
    //     0xb23cec: b.ls            #0xb23d44
    //     0xb23cf0: str             x0, [THR, #0x60]  ; THR::top
    //     0xb23cf4: sub             x0, x0, #0xf
    //     0xb23cf8: mov             x1, #0xe19c
    //     0xb23cfc: movk            x1, #3, lsl #16
    //     0xb23d00: stur            x1, [x0, #-1]
    // 0xb23d04: dmb             ishst
    // 0xb23d08: StoreField: r0->field_7 = d2
    //     0xb23d08: stur            d2, [x0, #7]
    // 0xb23d0c: ldur            x1, [fp, #-0x10]
    // 0xb23d10: StoreField: r1->field_13 = r0
    //     0xb23d10: stur            w0, [x1, #0x13]
    //     0xb23d14: ldurb           w16, [x1, #-1]
    //     0xb23d18: ldurb           w17, [x0, #-1]
    //     0xb23d1c: and             x16, x17, x16, lsr #2
    //     0xb23d20: tst             x16, HEAP, lsr #32
    //     0xb23d24: b.eq            #0xb23d2c
    //     0xb23d28: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb23d2c: r0 = Null
    //     0xb23d2c: mov             x0, NULL
    // 0xb23d30: LeaveFrame
    //     0xb23d30: mov             SP, fp
    //     0xb23d34: ldp             fp, lr, [SP], #0x10
    // 0xb23d38: ret
    //     0xb23d38: ret             
    // 0xb23d3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb23d3c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb23d40: b               #0xb23cb4
    // 0xb23d44: SaveReg d2
    //     0xb23d44: str             q2, [SP, #-0x10]!
    // 0xb23d48: r0 = AllocateDouble()
    //     0xb23d48: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb23d4c: RestoreReg d2
    //     0xb23d4c: ldr             q2, [SP], #0x10
    // 0xb23d50: b               #0xb23d08
  }
  _ computeMaxIntrinsicHeight(/* No info */) {
    // ** addr: 0xb2a62c, size: 0x100
    // 0xb2a62c: EnterFrame
    //     0xb2a62c: stp             fp, lr, [SP, #-0x10]!
    //     0xb2a630: mov             fp, SP
    // 0xb2a634: AllocStack(0x20)
    //     0xb2a634: sub             SP, SP, #0x20
    // 0xb2a638: SetupParameters(_RenderAlertDialogActionsLayout this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xb2a638: mov             x0, x1
    //     0xb2a63c: stur            x1, [fp, #-8]
    //     0xb2a640: stur            x2, [fp, #-0x10]
    // 0xb2a644: CheckStackOverflow
    //     0xb2a644: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2a648: cmp             SP, x16
    //     0xb2a64c: b.ls            #0xb2a714
    // 0xb2a650: LoadField: d1 = r2->field_7
    //     0xb2a650: ldur            d1, [x2, #7]
    // 0xb2a654: mov             x1, x0
    // 0xb2a658: mov             v0.16b, v1.16b
    // 0xb2a65c: stur            d1, [fp, #-0x20]
    // 0xb2a660: r0 = _useHorizontalLayout()
    //     0xb2a660: bl              #0xb23ab8  ; [package:flutter/src/cupertino/dialog.dart] _RenderAlertDialogActionsLayout::_useHorizontalLayout
    // 0xb2a664: tbz             w0, #4, #0xb2a680
    // 0xb2a668: ldur            x1, [fp, #-8]
    // 0xb2a66c: ldur            x2, [fp, #-0x10]
    // 0xb2a670: r0 = computeMaxIntrinsicHeight()
    //     0xb2a670: bl              #0xb2a970  ; [package:flutter/src/rendering/flex.dart] RenderFlex::computeMaxIntrinsicHeight
    // 0xb2a674: LeaveFrame
    //     0xb2a674: mov             SP, fp
    //     0xb2a678: ldp             fp, lr, [SP], #0x10
    // 0xb2a67c: ret
    //     0xb2a67c: ret             
    // 0xb2a680: ldur            x1, [fp, #-8]
    // 0xb2a684: ldur            d0, [fp, #-0x20]
    // 0xb2a688: r0 = horizontalSlotWidthFor()
    //     0xb2a688: bl              #0xb23aa0  ; [package:flutter/src/cupertino/dialog.dart] _RenderAlertDialogActionsLayout::horizontalSlotWidthFor
    // 0xb2a68c: r0 = inline_Allocate_Double()
    //     0xb2a68c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2a690: add             x0, x0, #0x10
    //     0xb2a694: cmp             x1, x0
    //     0xb2a698: b.ls            #0xb2a71c
    //     0xb2a69c: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2a6a0: sub             x0, x0, #0xf
    //     0xb2a6a4: mov             x1, #0xe19c
    //     0xb2a6a8: movk            x1, #3, lsl #16
    //     0xb2a6ac: stur            x1, [x0, #-1]
    // 0xb2a6b0: dmb             ishst
    // 0xb2a6b4: StoreField: r0->field_7 = d0
    //     0xb2a6b4: stur            d0, [x0, #7]
    // 0xb2a6b8: stur            x0, [fp, #-0x10]
    // 0xb2a6bc: r1 = 2
    //     0xb2a6bc: mov             x1, #2
    // 0xb2a6c0: r0 = AllocateContext()
    //     0xb2a6c0: bl              #0x13de838  ; AllocateContextStub
    // 0xb2a6c4: mov             x3, x0
    // 0xb2a6c8: ldur            x0, [fp, #-0x10]
    // 0xb2a6cc: stur            x3, [fp, #-0x18]
    // 0xb2a6d0: StoreField: r3->field_f = r0
    //     0xb2a6d0: stur            w0, [x3, #0xf]
    // 0xb2a6d4: r0 = 0.000000
    //     0xb2a6d4: ldr             x0, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xb2a6d8: StoreField: r3->field_13 = r0
    //     0xb2a6d8: stur            w0, [x3, #0x13]
    // 0xb2a6dc: mov             x2, x3
    // 0xb2a6e0: r1 = Function '<anonymous closure>':.
    //     0xb2a6e0: add             x1, PP, #0xd1, lsl #12  ; [pp+0xd19d8] AnonymousClosure: (0xb2a7a4), in [package:flutter/src/cupertino/dialog.dart] _RenderAlertDialogActionsLayout::computeMaxIntrinsicHeight (0xb2a62c)
    //     0xb2a6e4: ldr             x1, [x1, #0x9d8]
    // 0xb2a6e8: r0 = AllocateClosure()
    //     0xb2a6e8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb2a6ec: ldur            x1, [fp, #-8]
    // 0xb2a6f0: mov             x2, x0
    // 0xb2a6f4: r0 = _forEachSlot()
    //     0xb2a6f4: bl              #0xb23954  ; [package:flutter/src/cupertino/dialog.dart] _RenderAlertDialogActionsLayout::_forEachSlot
    // 0xb2a6f8: ldur            x0, [fp, #-0x18]
    // 0xb2a6fc: LoadField: r1 = r0->field_13
    //     0xb2a6fc: ldur            w1, [x0, #0x13]
    // 0xb2a700: DecompressPointer r1
    //     0xb2a700: add             x1, x1, HEAP, lsl #32
    // 0xb2a704: LoadField: d0 = r1->field_7
    //     0xb2a704: ldur            d0, [x1, #7]
    // 0xb2a708: LeaveFrame
    //     0xb2a708: mov             SP, fp
    //     0xb2a70c: ldp             fp, lr, [SP], #0x10
    // 0xb2a710: ret
    //     0xb2a710: ret             
    // 0xb2a714: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2a714: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2a718: b               #0xb2a650
    // 0xb2a71c: SaveReg d0
    //     0xb2a71c: str             q0, [SP, #-0x10]!
    // 0xb2a720: r0 = AllocateDouble()
    //     0xb2a720: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2a724: RestoreReg d0
    //     0xb2a724: ldr             q0, [SP], #0x10
    // 0xb2a728: b               #0xb2a6b4
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0xb2a72c, size: 0x78
    // 0xb2a72c: EnterFrame
    //     0xb2a72c: stp             fp, lr, [SP, #-0x10]!
    //     0xb2a730: mov             fp, SP
    // 0xb2a734: ldr             x0, [fp, #0x18]
    // 0xb2a738: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb2a738: ldur            w1, [x0, #0x17]
    // 0xb2a73c: DecompressPointer r1
    //     0xb2a73c: add             x1, x1, HEAP, lsl #32
    // 0xb2a740: CheckStackOverflow
    //     0xb2a740: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2a744: cmp             SP, x16
    //     0xb2a748: b.ls            #0xb2a78c
    // 0xb2a74c: ldr             x2, [fp, #0x10]
    // 0xb2a750: r0 = computeMaxIntrinsicHeight()
    //     0xb2a750: bl              #0xb2a62c  ; [package:flutter/src/cupertino/dialog.dart] _RenderAlertDialogActionsLayout::computeMaxIntrinsicHeight
    // 0xb2a754: r0 = inline_Allocate_Double()
    //     0xb2a754: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2a758: add             x0, x0, #0x10
    //     0xb2a75c: cmp             x1, x0
    //     0xb2a760: b.ls            #0xb2a794
    //     0xb2a764: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2a768: sub             x0, x0, #0xf
    //     0xb2a76c: mov             x1, #0xe19c
    //     0xb2a770: movk            x1, #3, lsl #16
    //     0xb2a774: stur            x1, [x0, #-1]
    // 0xb2a778: dmb             ishst
    // 0xb2a77c: StoreField: r0->field_7 = d0
    //     0xb2a77c: stur            d0, [x0, #7]
    // 0xb2a780: LeaveFrame
    //     0xb2a780: mov             SP, fp
    //     0xb2a784: ldp             fp, lr, [SP], #0x10
    // 0xb2a788: ret
    //     0xb2a788: ret             
    // 0xb2a78c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2a78c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2a790: b               #0xb2a74c
    // 0xb2a794: SaveReg d0
    //     0xb2a794: str             q0, [SP, #-0x10]!
    // 0xb2a798: r0 = AllocateDouble()
    //     0xb2a798: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2a79c: RestoreReg d0
    //     0xb2a79c: ldr             q0, [SP], #0x10
    // 0xb2a7a0: b               #0xb2a77c
  }
  [closure] void <anonymous closure>(dynamic, RenderBox) {
    // ** addr: 0xb2a7a4, size: 0xc8
    // 0xb2a7a4: EnterFrame
    //     0xb2a7a4: stp             fp, lr, [SP, #-0x10]!
    //     0xb2a7a8: mov             fp, SP
    // 0xb2a7ac: AllocStack(0x10)
    //     0xb2a7ac: sub             SP, SP, #0x10
    // 0xb2a7b0: SetupParameters([dynamic _ /* r0 */])
    //     0xb2a7b0: ldr             x0, [fp, #0x18]
    //     0xb2a7b4: ldur            w2, [x0, #0x17]
    //     0xb2a7b8: add             x2, x2, HEAP, lsl #32
    //     0xb2a7bc: stur            x2, [fp, #-0x10]
    // 0xb2a7c0: CheckStackOverflow
    //     0xb2a7c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2a7c4: cmp             SP, x16
    //     0xb2a7c8: b.ls            #0xb2a854
    // 0xb2a7cc: LoadField: r0 = r2->field_13
    //     0xb2a7cc: ldur            w0, [x2, #0x13]
    // 0xb2a7d0: DecompressPointer r0
    //     0xb2a7d0: add             x0, x0, HEAP, lsl #32
    // 0xb2a7d4: stur            x0, [fp, #-8]
    // 0xb2a7d8: LoadField: r1 = r2->field_f
    //     0xb2a7d8: ldur            w1, [x2, #0xf]
    // 0xb2a7dc: DecompressPointer r1
    //     0xb2a7dc: add             x1, x1, HEAP, lsl #32
    // 0xb2a7e0: LoadField: d0 = r1->field_7
    //     0xb2a7e0: ldur            d0, [x1, #7]
    // 0xb2a7e4: ldr             x1, [fp, #0x10]
    // 0xb2a7e8: r0 = getMaxIntrinsicHeight()
    //     0xb2a7e8: bl              #0xb16950  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicHeight
    // 0xb2a7ec: ldur            x1, [fp, #-8]
    // 0xb2a7f0: LoadField: d1 = r1->field_7
    //     0xb2a7f0: ldur            d1, [x1, #7]
    // 0xb2a7f4: fmax            v2.2d, v1.2d, v0.2d
    // 0xb2a7f8: r0 = inline_Allocate_Double()
    //     0xb2a7f8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2a7fc: add             x0, x0, #0x10
    //     0xb2a800: cmp             x1, x0
    //     0xb2a804: b.ls            #0xb2a85c
    //     0xb2a808: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2a80c: sub             x0, x0, #0xf
    //     0xb2a810: mov             x1, #0xe19c
    //     0xb2a814: movk            x1, #3, lsl #16
    //     0xb2a818: stur            x1, [x0, #-1]
    // 0xb2a81c: dmb             ishst
    // 0xb2a820: StoreField: r0->field_7 = d2
    //     0xb2a820: stur            d2, [x0, #7]
    // 0xb2a824: ldur            x1, [fp, #-0x10]
    // 0xb2a828: StoreField: r1->field_13 = r0
    //     0xb2a828: stur            w0, [x1, #0x13]
    //     0xb2a82c: ldurb           w16, [x1, #-1]
    //     0xb2a830: ldurb           w17, [x0, #-1]
    //     0xb2a834: and             x16, x17, x16, lsr #2
    //     0xb2a838: tst             x16, HEAP, lsr #32
    //     0xb2a83c: b.eq            #0xb2a844
    //     0xb2a840: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb2a844: r0 = Null
    //     0xb2a844: mov             x0, NULL
    // 0xb2a848: LeaveFrame
    //     0xb2a848: mov             SP, fp
    //     0xb2a84c: ldp             fp, lr, [SP], #0x10
    // 0xb2a850: ret
    //     0xb2a850: ret             
    // 0xb2a854: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2a854: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2a858: b               #0xb2a7cc
    // 0xb2a85c: SaveReg d2
    //     0xb2a85c: str             q2, [SP, #-0x10]!
    // 0xb2a860: r0 = AllocateDouble()
    //     0xb2a860: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2a864: RestoreReg d2
    //     0xb2a864: ldr             q2, [SP], #0x10
    // 0xb2a868: b               #0xb2a820
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xb4e1e0, size: 0x90
    // 0xb4e1e0: EnterFrame
    //     0xb4e1e0: stp             fp, lr, [SP, #-0x10]!
    //     0xb4e1e4: mov             fp, SP
    // 0xb4e1e8: AllocStack(0x20)
    //     0xb4e1e8: sub             SP, SP, #0x20
    // 0xb4e1ec: SetupParameters(_RenderAlertDialogActionsLayout this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xb4e1ec: mov             x0, x1
    //     0xb4e1f0: stur            x1, [fp, #-8]
    //     0xb4e1f4: stur            x2, [fp, #-0x10]
    // 0xb4e1f8: CheckStackOverflow
    //     0xb4e1f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb4e1fc: cmp             SP, x16
    //     0xb4e200: b.ls            #0xb4e268
    // 0xb4e204: LoadField: d1 = r2->field_f
    //     0xb4e204: ldur            d1, [x2, #0xf]
    // 0xb4e208: mov             x1, x0
    // 0xb4e20c: mov             v0.16b, v1.16b
    // 0xb4e210: stur            d1, [fp, #-0x18]
    // 0xb4e214: r0 = _useHorizontalLayout()
    //     0xb4e214: bl              #0xb23ab8  ; [package:flutter/src/cupertino/dialog.dart] _RenderAlertDialogActionsLayout::_useHorizontalLayout
    // 0xb4e218: tbz             w0, #4, #0xb4e234
    // 0xb4e21c: ldur            x1, [fp, #-8]
    // 0xb4e220: ldur            x2, [fp, #-0x10]
    // 0xb4e224: r0 = computeDryLayout()
    //     0xb4e224: bl              #0xb4e58c  ; [package:flutter/src/rendering/flex.dart] RenderFlex::computeDryLayout
    // 0xb4e228: LeaveFrame
    //     0xb4e228: mov             SP, fp
    //     0xb4e22c: ldp             fp, lr, [SP], #0x10
    // 0xb4e230: ret
    //     0xb4e230: ret             
    // 0xb4e234: ldur            d1, [fp, #-0x18]
    // 0xb4e238: ldur            x1, [fp, #-8]
    // 0xb4e23c: mov             v0.16b, v1.16b
    // 0xb4e240: r0 = getMinIntrinsicHeight()
    //     0xb4e240: bl              #0xb177d8  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicHeight
    // 0xb4e244: stur            d0, [fp, #-0x20]
    // 0xb4e248: r0 = Size()
    //     0xb4e248: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb4e24c: ldur            d0, [fp, #-0x18]
    // 0xb4e250: StoreField: r0->field_7 = d0
    //     0xb4e250: stur            d0, [x0, #7]
    // 0xb4e254: ldur            d0, [fp, #-0x20]
    // 0xb4e258: StoreField: r0->field_f = d0
    //     0xb4e258: stur            d0, [x0, #0xf]
    // 0xb4e25c: LeaveFrame
    //     0xb4e25c: mov             SP, fp
    //     0xb4e260: ldp             fp, lr, [SP], #0x10
    // 0xb4e264: ret
    //     0xb4e264: ret             
    // 0xb4e268: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb4e268: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb4e26c: b               #0xb4e204
  }
  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0xb5e6bc, size: 0x24
    // 0xb5e6bc: EnterFrame
    //     0xb5e6bc: stp             fp, lr, [SP, #-0x10]!
    //     0xb5e6c0: mov             fp, SP
    // 0xb5e6c4: ldr             x2, [fp, #0x10]
    // 0xb5e6c8: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0xb5e6c8: add             x1, PP, #0xd1, lsl #12  ; [pp+0xd1968] AnonymousClosure: (0xb2a72c), in [package:flutter/src/cupertino/dialog.dart] _RenderAlertDialogActionsLayout::computeMaxIntrinsicHeight (0xb2a62c)
    //     0xb5e6cc: ldr             x1, [x1, #0x968]
    // 0xb5e6d0: r0 = AllocateClosure()
    //     0xb5e6d0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb5e6d4: LeaveFrame
    //     0xb5e6d4: mov             SP, fp
    //     0xb5e6d8: ldp             fp, lr, [SP], #0x10
    // 0xb5e6dc: ret
    //     0xb5e6dc: ret             
  }
  _ performLayout(/* No info */) {
    // ** addr: 0xbbe7c0, size: 0x60c
    // 0xbbe7c0: EnterFrame
    //     0xbbe7c0: stp             fp, lr, [SP, #-0x10]!
    //     0xbbe7c4: mov             fp, SP
    // 0xbbe7c8: AllocStack(0x40)
    //     0xbbe7c8: sub             SP, SP, #0x40
    // 0xbbe7cc: SetupParameters(_RenderAlertDialogActionsLayout this /* r1 => r3, fp-0x10 */)
    //     0xbbe7cc: mov             x3, x1
    //     0xbbe7d0: stur            x1, [fp, #-0x10]
    // 0xbbe7d4: CheckStackOverflow
    //     0xbbe7d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbbe7d8: cmp             SP, x16
    //     0xbbe7dc: b.ls            #0xbbedac
    // 0xbbe7e0: LoadField: r0 = r3->field_57
    //     0xbbe7e0: ldur            w0, [x3, #0x57]
    // 0xbbe7e4: DecompressPointer r0
    //     0xbbe7e4: add             x0, x0, HEAP, lsl #32
    // 0xbbe7e8: cmp             w0, NULL
    // 0xbbe7ec: b.ne            #0xbbe86c
    // 0xbbe7f0: LoadField: r4 = r3->field_27
    //     0xbbe7f0: ldur            w4, [x3, #0x27]
    // 0xbbe7f4: DecompressPointer r4
    //     0xbbe7f4: add             x4, x4, HEAP, lsl #32
    // 0xbbe7f8: stur            x4, [fp, #-8]
    // 0xbbe7fc: cmp             w4, NULL
    // 0xbbe800: b.eq            #0xbbec08
    // 0xbbe804: mov             x0, x4
    // 0xbbe808: r2 = Null
    //     0xbbe808: mov             x2, NULL
    // 0xbbe80c: r1 = Null
    //     0xbbe80c: mov             x1, NULL
    // 0xbbe810: r4 = LoadClassIdInstr(r0)
    //     0xbbe810: ldur            x4, [x0, #-1]
    //     0xbbe814: ubfx            x4, x4, #0xc, #0x14
    // 0xbbe818: sub             x4, x4, #0xb46
    // 0xbbe81c: cmp             x4, #1
    // 0xbbe820: b.ls            #0xbbe834
    // 0xbbe824: r8 = BoxConstraints
    //     0xbbe824: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbbe828: r3 = Null
    //     0xbbe828: add             x3, PP, #0xd1, lsl #12  ; [pp+0xd1978] Null
    //     0xbbe82c: ldr             x3, [x3, #0x978]
    // 0xbbe830: r0 = BoxConstraints()
    //     0xbbe830: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbbe834: ldur            x1, [fp, #-8]
    // 0xbbe838: r0 = smallest()
    //     0xbbe838: bl              #0xb214d4  ; [package:flutter/src/rendering/box.dart] BoxConstraints::smallest
    // 0xbbe83c: ldur            x3, [fp, #-0x10]
    // 0xbbe840: StoreField: r3->field_4b = r0
    //     0xbbe840: stur            w0, [x3, #0x4b]
    //     0xbbe844: ldurb           w16, [x3, #-1]
    //     0xbbe848: ldurb           w17, [x0, #-1]
    //     0xbbe84c: and             x16, x17, x16, lsr #2
    //     0xbbe850: tst             x16, HEAP, lsr #32
    //     0xbbe854: b.eq            #0xbbe85c
    //     0xbbe858: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbbe85c: r0 = Null
    //     0xbbe85c: mov             x0, NULL
    // 0xbbe860: LeaveFrame
    //     0xbbe860: mov             SP, fp
    //     0xbbe864: ldp             fp, lr, [SP], #0x10
    // 0xbbe868: ret
    //     0xbbe868: ret             
    // 0xbbe86c: LoadField: r4 = r3->field_27
    //     0xbbe86c: ldur            w4, [x3, #0x27]
    // 0xbbe870: DecompressPointer r4
    //     0xbbe870: add             x4, x4, HEAP, lsl #32
    // 0xbbe874: stur            x4, [fp, #-8]
    // 0xbbe878: cmp             w4, NULL
    // 0xbbe87c: b.eq            #0xbbec24
    // 0xbbe880: mov             x0, x4
    // 0xbbe884: r2 = Null
    //     0xbbe884: mov             x2, NULL
    // 0xbbe888: r1 = Null
    //     0xbbe888: mov             x1, NULL
    // 0xbbe88c: r4 = LoadClassIdInstr(r0)
    //     0xbbe88c: ldur            x4, [x0, #-1]
    //     0xbbe890: ubfx            x4, x4, #0xc, #0x14
    // 0xbbe894: sub             x4, x4, #0xb46
    // 0xbbe898: cmp             x4, #1
    // 0xbbe89c: b.ls            #0xbbe8b0
    // 0xbbe8a0: r8 = BoxConstraints
    //     0xbbe8a0: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbbe8a4: r3 = Null
    //     0xbbe8a4: add             x3, PP, #0xd1, lsl #12  ; [pp+0xd1988] Null
    //     0xbbe8a8: ldr             x3, [x3, #0x988]
    // 0xbbe8ac: r0 = BoxConstraints()
    //     0xbbe8ac: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbbe8b0: ldur            x0, [fp, #-8]
    // 0xbbe8b4: LoadField: d1 = r0->field_f
    //     0xbbe8b4: ldur            d1, [x0, #0xf]
    // 0xbbe8b8: ldur            x1, [fp, #-0x10]
    // 0xbbe8bc: mov             v0.16b, v1.16b
    // 0xbbe8c0: stur            d1, [fp, #-0x28]
    // 0xbbe8c4: r0 = _useHorizontalLayout()
    //     0xbbe8c4: bl              #0xb23ab8  ; [package:flutter/src/cupertino/dialog.dart] _RenderAlertDialogActionsLayout::_useHorizontalLayout
    // 0xbbe8c8: tbz             w0, #4, #0xbbe8e4
    // 0xbbe8cc: ldur            x1, [fp, #-0x10]
    // 0xbbe8d0: r0 = performLayout()
    //     0xbbe8d0: bl              #0xbbf548  ; [package:flutter/src/rendering/flex.dart] RenderFlex::performLayout
    // 0xbbe8d4: r0 = Null
    //     0xbbe8d4: mov             x0, NULL
    // 0xbbe8d8: LeaveFrame
    //     0xbbe8d8: mov             SP, fp
    //     0xbbe8dc: ldp             fp, lr, [SP], #0x10
    // 0xbbe8e0: ret
    //     0xbbe8e0: ret             
    // 0xbbe8e4: ldur            x0, [fp, #-0x10]
    // 0xbbe8e8: ldur            d1, [fp, #-0x28]
    // 0xbbe8ec: mov             x1, x0
    // 0xbbe8f0: mov             v0.16b, v1.16b
    // 0xbbe8f4: r0 = horizontalSlotWidthFor()
    //     0xbbe8f4: bl              #0xb23aa0  ; [package:flutter/src/cupertino/dialog.dart] _RenderAlertDialogActionsLayout::horizontalSlotWidthFor
    // 0xbbe8f8: ldur            x1, [fp, #-0x10]
    // 0xbbe8fc: mov             v1.16b, v0.16b
    // 0xbbe900: ldur            d0, [fp, #-0x28]
    // 0xbbe904: stur            d1, [fp, #-0x30]
    // 0xbbe908: r0 = getMinIntrinsicHeight()
    //     0xbbe908: bl              #0xb177d8  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicHeight
    // 0xbbe90c: stur            d0, [fp, #-0x38]
    // 0xbbe910: r0 = Size()
    //     0xbbe910: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xbbe914: ldur            d0, [fp, #-0x28]
    // 0xbbe918: StoreField: r0->field_7 = d0
    //     0xbbe918: stur            d0, [x0, #7]
    // 0xbbe91c: ldur            d1, [fp, #-0x38]
    // 0xbbe920: StoreField: r0->field_f = d1
    //     0xbbe920: stur            d1, [x0, #0xf]
    // 0xbbe924: ldur            x1, [fp, #-0x10]
    // 0xbbe928: StoreField: r1->field_4b = r0
    //     0xbbe928: stur            w0, [x1, #0x4b]
    //     0xbbe92c: ldurb           w16, [x1, #-1]
    //     0xbbe930: ldurb           w17, [x0, #-1]
    //     0xbbe934: and             x16, x17, x16, lsr #2
    //     0xbbe938: tst             x16, HEAP, lsr #32
    //     0xbbe93c: b.eq            #0xbbe944
    //     0xbbe940: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbbe944: LoadField: r0 = r1->field_73
    //     0xbbe944: ldur            w0, [x1, #0x73]
    // 0xbbe948: DecompressPointer r0
    //     0xbbe948: add             x0, x0, HEAP, lsl #32
    // 0xbbe94c: r16 = Instance_TextDirection
    //     0xbbe94c: ldr             x16, [PP, #0x25b0]  ; [pp+0x25b0] Obj!TextDirection@12c73a1
    // 0xbbe950: cmp             w0, w16
    // 0xbbe954: r16 = true
    //     0xbbe954: add             x16, NULL, #0x20  ; true
    // 0xbbe958: r17 = false
    //     0xbbe958: add             x17, NULL, #0x30  ; false
    // 0xbbe95c: csel            x2, x16, x17, eq
    // 0xbbe960: stur            x2, [fp, #-0x18]
    // 0xbbe964: LoadField: r0 = r1->field_57
    //     0xbbe964: ldur            w0, [x1, #0x57]
    // 0xbbe968: DecompressPointer r0
    //     0xbbe968: add             x0, x0, HEAP, lsl #32
    // 0xbbe96c: cmp             w0, NULL
    // 0xbbe970: b.eq            #0xbbedb4
    // 0xbbe974: tbnz            w2, #4, #0xbbe984
    // 0xbbe978: ldur            d2, [fp, #-0x30]
    // 0xbbe97c: d0 = 0.000000
    //     0xbbe97c: eor             v0.16b, v0.16b, v0.16b
    // 0xbbe980: b               #0xbbe990
    // 0xbbe984: ldur            d2, [fp, #-0x30]
    // 0xbbe988: fsub            d3, d0, d2
    // 0xbbe98c: mov             v0.16b, v3.16b
    // 0xbbe990: mov             x1, x0
    // 0xbbe994: stur            x1, [fp, #-8]
    // 0xbbe998: stur            d0, [fp, #-0x28]
    // 0xbbe99c: CheckStackOverflow
    //     0xbbe99c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbbe9a0: cmp             SP, x16
    //     0xbbe9a4: b.ls            #0xbbedb8
    // 0xbbe9a8: r0 = BoxConstraints()
    //     0xbbe9a8: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xbbe9ac: ldur            d0, [fp, #-0x30]
    // 0xbbe9b0: StoreField: r0->field_7 = d0
    //     0xbbe9b0: stur            d0, [x0, #7]
    // 0xbbe9b4: StoreField: r0->field_f = d0
    //     0xbbe9b4: stur            d0, [x0, #0xf]
    // 0xbbe9b8: ldur            d1, [fp, #-0x38]
    // 0xbbe9bc: ArrayStore: r0[0] = d1  ; List_8
    //     0xbbe9bc: stur            d1, [x0, #0x17]
    // 0xbbe9c0: StoreField: r0->field_1f = d1
    //     0xbbe9c0: stur            d1, [x0, #0x1f]
    // 0xbbe9c4: ldur            x3, [fp, #-8]
    // 0xbbe9c8: r1 = LoadClassIdInstr(r3)
    //     0xbbe9c8: ldur            x1, [x3, #-1]
    //     0xbbe9cc: ubfx            x1, x1, #0xc, #0x14
    // 0xbbe9d0: r16 = true
    //     0xbbe9d0: add             x16, NULL, #0x20  ; true
    // 0xbbe9d4: str             x16, [SP]
    // 0xbbe9d8: mov             x2, x0
    // 0xbbe9dc: mov             x0, x1
    // 0xbbe9e0: mov             x1, x3
    // 0xbbe9e4: r4 = const [0, 0x3, 0x1, 0x2, parentUsesSize, 0x2, null]
    //     0xbbe9e4: add             x4, PP, #0xd, lsl #12  ; [pp+0xded0] List(7) [0, 0x3, 0x1, 0x2, "parentUsesSize", 0x2, Null]
    //     0xbbe9e8: ldr             x4, [x4, #0xed0]
    // 0xbbe9ec: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0xbbe9ec: mov             x17, #0xe6b9
    //     0xbbe9f0: add             lr, x0, x17
    //     0xbbe9f4: ldr             lr, [x21, lr, lsl #3]
    //     0xbbe9f8: blr             lr
    // 0xbbe9fc: ldur            x3, [fp, #-8]
    // 0xbbea00: LoadField: r4 = r3->field_7
    //     0xbbea00: ldur            w4, [x3, #7]
    // 0xbbea04: DecompressPointer r4
    //     0xbbea04: add             x4, x4, HEAP, lsl #32
    // 0xbbea08: stur            x4, [fp, #-0x10]
    // 0xbbea0c: cmp             w4, NULL
    // 0xbbea10: b.eq            #0xbbedc0
    // 0xbbea14: mov             x0, x4
    // 0xbbea18: r2 = Null
    //     0xbbea18: mov             x2, NULL
    // 0xbbea1c: r1 = Null
    //     0xbbea1c: mov             x1, NULL
    // 0xbbea20: r4 = LoadClassIdInstr(r0)
    //     0xbbea20: ldur            x4, [x0, #-1]
    //     0xbbea24: ubfx            x4, x4, #0xc, #0x14
    // 0xbbea28: r17 = 4212
    //     0xbbea28: mov             x17, #0x1074
    // 0xbbea2c: cmp             x4, x17
    // 0xbbea30: b.eq            #0xbbea48
    // 0xbbea34: r8 = FlexParentData
    //     0xbbea34: add             x8, PP, #0x85, lsl #12  ; [pp+0x85010] Type: FlexParentData
    //     0xbbea38: ldr             x8, [x8, #0x10]
    // 0xbbea3c: r3 = Null
    //     0xbbea3c: add             x3, PP, #0xd1, lsl #12  ; [pp+0xd1998] Null
    //     0xbbea40: ldr             x3, [x3, #0x998]
    // 0xbbea44: r0 = DefaultTypeTest()
    //     0xbbea44: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbbea48: r0 = Offset()
    //     0xbbea48: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xbbea4c: ldur            d0, [fp, #-0x28]
    // 0xbbea50: StoreField: r0->field_7 = d0
    //     0xbbea50: stur            d0, [x0, #7]
    // 0xbbea54: StoreField: r0->field_f = rZR
    //     0xbbea54: stur            xzr, [x0, #0xf]
    // 0xbbea58: ldur            x1, [fp, #-0x10]
    // 0xbbea5c: StoreField: r1->field_7 = r0
    //     0xbbea5c: stur            w0, [x1, #7]
    //     0xbbea60: ldurb           w16, [x1, #-1]
    //     0xbbea64: ldurb           w17, [x0, #-1]
    //     0xbbea68: and             x16, x17, x16, lsr #2
    //     0xbbea6c: tst             x16, HEAP, lsr #32
    //     0xbbea70: b.eq            #0xbbea78
    //     0xbbea74: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbbea78: ldur            x0, [fp, #-0x18]
    // 0xbbea7c: tbnz            w0, #4, #0xbbeaa4
    // 0xbbea80: ldur            x3, [fp, #-8]
    // 0xbbea84: LoadField: r2 = r3->field_4b
    //     0xbbea84: ldur            w2, [x3, #0x4b]
    // 0xbbea88: DecompressPointer r2
    //     0xbbea88: add             x2, x2, HEAP, lsl #32
    // 0xbbea8c: cmp             w2, NULL
    // 0xbbea90: b.eq            #0xbbec44
    // 0xbbea94: LoadField: d1 = r2->field_7
    //     0xbbea94: ldur            d1, [x2, #7]
    // 0xbbea98: fadd            d2, d0, d1
    // 0xbbea9c: mov             v0.16b, v2.16b
    // 0xbbeaa0: b               #0xbbeac4
    // 0xbbeaa4: ldur            x3, [fp, #-8]
    // 0xbbeaa8: LoadField: r2 = r3->field_4b
    //     0xbbeaa8: ldur            w2, [x3, #0x4b]
    // 0xbbeaac: DecompressPointer r2
    //     0xbbeaac: add             x2, x2, HEAP, lsl #32
    // 0xbbeab0: cmp             w2, NULL
    // 0xbbeab4: b.eq            #0xbbecf8
    // 0xbbeab8: LoadField: d1 = r2->field_7
    //     0xbbeab8: ldur            d1, [x2, #7]
    // 0xbbeabc: fsub            d2, d0, d1
    // 0xbbeac0: mov             v0.16b, v2.16b
    // 0xbbeac4: stur            d0, [fp, #-0x28]
    // 0xbbeac8: LoadField: r2 = r1->field_13
    //     0xbbeac8: ldur            w2, [x1, #0x13]
    // 0xbbeacc: DecompressPointer r2
    //     0xbbeacc: add             x2, x2, HEAP, lsl #32
    // 0xbbead0: stur            x2, [fp, #-0x20]
    // 0xbbead4: cmp             w2, NULL
    // 0xbbead8: b.eq            #0xbbebf8
    // 0xbbeadc: ldur            d1, [fp, #-0x38]
    // 0xbbeae0: r0 = BoxConstraints()
    //     0xbbeae0: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xbbeae4: d0 = 0.300000
    //     0xbbeae4: add             x17, PP, #0x13, lsl #12  ; [pp+0x13a88] IMM: double(0.3) from 0x3fd3333333333333
    //     0xbbeae8: ldr             d0, [x17, #0xa88]
    // 0xbbeaec: StoreField: r0->field_7 = d0
    //     0xbbeaec: stur            d0, [x0, #7]
    // 0xbbeaf0: StoreField: r0->field_f = d0
    //     0xbbeaf0: stur            d0, [x0, #0xf]
    // 0xbbeaf4: ldur            d1, [fp, #-0x38]
    // 0xbbeaf8: ArrayStore: r0[0] = d1  ; List_8
    //     0xbbeaf8: stur            d1, [x0, #0x17]
    // 0xbbeafc: StoreField: r0->field_1f = d1
    //     0xbbeafc: stur            d1, [x0, #0x1f]
    // 0xbbeb00: ldur            x3, [fp, #-0x20]
    // 0xbbeb04: r1 = LoadClassIdInstr(r3)
    //     0xbbeb04: ldur            x1, [x3, #-1]
    //     0xbbeb08: ubfx            x1, x1, #0xc, #0x14
    // 0xbbeb0c: mov             x2, x0
    // 0xbbeb10: mov             x0, x1
    // 0xbbeb14: mov             x1, x3
    // 0xbbeb18: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xbbeb18: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xbbeb1c: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0xbbeb1c: mov             x17, #0xe6b9
    //     0xbbeb20: add             lr, x0, x17
    //     0xbbeb24: ldr             lr, [x21, lr, lsl #3]
    //     0xbbeb28: blr             lr
    // 0xbbeb2c: ldur            x0, [fp, #-0x20]
    // 0xbbeb30: LoadField: r3 = r0->field_7
    //     0xbbeb30: ldur            w3, [x0, #7]
    // 0xbbeb34: DecompressPointer r3
    //     0xbbeb34: add             x3, x3, HEAP, lsl #32
    // 0xbbeb38: stur            x3, [fp, #-0x10]
    // 0xbbeb3c: cmp             w3, NULL
    // 0xbbeb40: b.eq            #0xbbedc4
    // 0xbbeb44: mov             x0, x3
    // 0xbbeb48: r2 = Null
    //     0xbbeb48: mov             x2, NULL
    // 0xbbeb4c: r1 = Null
    //     0xbbeb4c: mov             x1, NULL
    // 0xbbeb50: r4 = LoadClassIdInstr(r0)
    //     0xbbeb50: ldur            x4, [x0, #-1]
    //     0xbbeb54: ubfx            x4, x4, #0xc, #0x14
    // 0xbbeb58: r17 = 4212
    //     0xbbeb58: mov             x17, #0x1074
    // 0xbbeb5c: cmp             x4, x17
    // 0xbbeb60: b.eq            #0xbbeb78
    // 0xbbeb64: r8 = FlexParentData
    //     0xbbeb64: add             x8, PP, #0x85, lsl #12  ; [pp+0x85010] Type: FlexParentData
    //     0xbbeb68: ldr             x8, [x8, #0x10]
    // 0xbbeb6c: r3 = Null
    //     0xbbeb6c: add             x3, PP, #0xd1, lsl #12  ; [pp+0xd19a8] Null
    //     0xbbeb70: ldr             x3, [x3, #0x9a8]
    // 0xbbeb74: r0 = DefaultTypeTest()
    //     0xbbeb74: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbbeb78: r0 = Offset()
    //     0xbbeb78: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xbbeb7c: ldur            d0, [fp, #-0x28]
    // 0xbbeb80: StoreField: r0->field_7 = d0
    //     0xbbeb80: stur            d0, [x0, #7]
    // 0xbbeb84: StoreField: r0->field_f = rZR
    //     0xbbeb84: stur            xzr, [x0, #0xf]
    // 0xbbeb88: ldur            x1, [fp, #-0x10]
    // 0xbbeb8c: StoreField: r1->field_7 = r0
    //     0xbbeb8c: stur            w0, [x1, #7]
    //     0xbbeb90: ldurb           w16, [x1, #-1]
    //     0xbbeb94: ldurb           w17, [x0, #-1]
    //     0xbbeb98: and             x16, x17, x16, lsr #2
    //     0xbbeb9c: tst             x16, HEAP, lsr #32
    //     0xbbeba0: b.eq            #0xbbeba8
    //     0xbbeba4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbbeba8: ldur            x0, [fp, #-0x18]
    // 0xbbebac: tbnz            w0, #4, #0xbbebc4
    // 0xbbebb0: d1 = 0.300000
    //     0xbbebb0: add             x17, PP, #0x13, lsl #12  ; [pp+0x13a88] IMM: double(0.3) from 0x3fd3333333333333
    //     0xbbebb4: ldr             d1, [x17, #0xa88]
    // 0xbbebb8: fadd            d2, d0, d1
    // 0xbbebbc: mov             v0.16b, v2.16b
    // 0xbbebc0: b               #0xbbebd4
    // 0xbbebc4: d1 = 0.300000
    //     0xbbebc4: add             x17, PP, #0x13, lsl #12  ; [pp+0x13a88] IMM: double(0.3) from 0x3fd3333333333333
    //     0xbbebc8: ldr             d1, [x17, #0xa88]
    // 0xbbebcc: fsub            d2, d0, d1
    // 0xbbebd0: mov             v0.16b, v2.16b
    // 0xbbebd4: LoadField: r2 = r1->field_13
    //     0xbbebd4: ldur            w2, [x1, #0x13]
    // 0xbbebd8: DecompressPointer r2
    //     0xbbebd8: add             x2, x2, HEAP, lsl #32
    // 0xbbebdc: cmp             w2, NULL
    // 0xbbebe0: b.eq            #0xbbedc8
    // 0xbbebe4: mov             x1, x2
    // 0xbbebe8: ldur            d2, [fp, #-0x30]
    // 0xbbebec: ldur            d1, [fp, #-0x38]
    // 0xbbebf0: mov             x2, x0
    // 0xbbebf4: b               #0xbbe994
    // 0xbbebf8: r0 = Null
    //     0xbbebf8: mov             x0, NULL
    // 0xbbebfc: LeaveFrame
    //     0xbbebfc: mov             SP, fp
    //     0xbbec00: ldp             fp, lr, [SP], #0x10
    // 0xbbec04: ret
    //     0xbbec04: ret             
    // 0xbbec08: r0 = StateError()
    //     0xbbec08: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbbec0c: mov             x1, x0
    // 0xbbec10: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbbec10: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbbec14: StoreField: r1->field_b = r0
    //     0xbbec14: stur            w0, [x1, #0xb]
    // 0xbbec18: mov             x0, x1
    // 0xbbec1c: r0 = Throw()
    //     0xbbec1c: bl              #0x13ddb2c  ; ThrowStub
    // 0xbbec20: brk             #0
    // 0xbbec24: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbbec24: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbbec28: r0 = StateError()
    //     0xbbec28: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbbec2c: mov             x1, x0
    // 0xbbec30: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbbec30: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbbec34: StoreField: r1->field_b = r0
    //     0xbbec34: stur            w0, [x1, #0xb]
    // 0xbbec38: mov             x0, x1
    // 0xbbec3c: r0 = Throw()
    //     0xbbec3c: bl              #0x13ddb2c  ; ThrowStub
    // 0xbbec40: brk             #0
    // 0xbbec44: r1 = Null
    //     0xbbec44: mov             x1, NULL
    // 0xbbec48: r2 = 8
    //     0xbbec48: mov             x2, #8
    // 0xbbec4c: r0 = AllocateArray()
    //     0xbbec4c: bl              #0x13df928  ; AllocateArrayStub
    // 0xbbec50: stur            x0, [fp, #-0x10]
    // 0xbbec54: r16 = "RenderBox was not laid out: "
    //     0xbbec54: ldr             x16, [PP, #0x47e0]  ; [pp+0x47e0] "RenderBox was not laid out: "
    // 0xbbec58: StoreField: r0->field_f = r16
    //     0xbbec58: stur            w16, [x0, #0xf]
    // 0xbbec5c: ldur            x16, [fp, #-8]
    // 0xbbec60: str             x16, [SP]
    // 0xbbec64: r0 = runtimeType()
    //     0xbbec64: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0xbbec68: ldur            x1, [fp, #-0x10]
    // 0xbbec6c: ArrayStore: r1[1] = r0  ; List_4
    //     0xbbec6c: add             x25, x1, #0x13
    //     0xbbec70: str             w0, [x25]
    //     0xbbec74: tbz             w0, #0, #0xbbec90
    //     0xbbec78: ldurb           w16, [x1, #-1]
    //     0xbbec7c: ldurb           w17, [x0, #-1]
    //     0xbbec80: and             x16, x17, x16, lsr #2
    //     0xbbec84: tst             x16, HEAP, lsr #32
    //     0xbbec88: b.eq            #0xbbec90
    //     0xbbec8c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbbec90: ldur            x0, [fp, #-0x10]
    // 0xbbec94: r16 = "#"
    //     0xbbec94: ldr             x16, [PP, #0x8e8]  ; [pp+0x8e8] "#"
    // 0xbbec98: ArrayStore: r0[0] = r16  ; List_4
    //     0xbbec98: stur            w16, [x0, #0x17]
    // 0xbbec9c: ldur            x1, [fp, #-8]
    // 0xbbeca0: r0 = shortHash()
    //     0xbbeca0: bl              #0x858904  ; [package:flutter/src/foundation/diagnostics.dart] ::shortHash
    // 0xbbeca4: ldur            x1, [fp, #-0x10]
    // 0xbbeca8: ArrayStore: r1[3] = r0  ; List_4
    //     0xbbeca8: add             x25, x1, #0x1b
    //     0xbbecac: str             w0, [x25]
    //     0xbbecb0: tbz             w0, #0, #0xbbeccc
    //     0xbbecb4: ldurb           w16, [x1, #-1]
    //     0xbbecb8: ldurb           w17, [x0, #-1]
    //     0xbbecbc: and             x16, x17, x16, lsr #2
    //     0xbbecc0: tst             x16, HEAP, lsr #32
    //     0xbbecc4: b.eq            #0xbbeccc
    //     0xbbecc8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbbeccc: ldur            x16, [fp, #-0x10]
    // 0xbbecd0: str             x16, [SP]
    // 0xbbecd4: r0 = _interpolate()
    //     0xbbecd4: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xbbecd8: stur            x0, [fp, #-0x10]
    // 0xbbecdc: r0 = StateError()
    //     0xbbecdc: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbbece0: mov             x1, x0
    // 0xbbece4: ldur            x0, [fp, #-0x10]
    // 0xbbece8: StoreField: r1->field_b = r0
    //     0xbbece8: stur            w0, [x1, #0xb]
    // 0xbbecec: mov             x0, x1
    // 0xbbecf0: r0 = Throw()
    //     0xbbecf0: bl              #0x13ddb2c  ; ThrowStub
    // 0xbbecf4: brk             #0
    // 0xbbecf8: r1 = Null
    //     0xbbecf8: mov             x1, NULL
    // 0xbbecfc: r2 = 8
    //     0xbbecfc: mov             x2, #8
    // 0xbbed00: r0 = AllocateArray()
    //     0xbbed00: bl              #0x13df928  ; AllocateArrayStub
    // 0xbbed04: stur            x0, [fp, #-0x10]
    // 0xbbed08: r16 = "RenderBox was not laid out: "
    //     0xbbed08: ldr             x16, [PP, #0x47e0]  ; [pp+0x47e0] "RenderBox was not laid out: "
    // 0xbbed0c: StoreField: r0->field_f = r16
    //     0xbbed0c: stur            w16, [x0, #0xf]
    // 0xbbed10: ldur            x16, [fp, #-8]
    // 0xbbed14: str             x16, [SP]
    // 0xbbed18: r0 = runtimeType()
    //     0xbbed18: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0xbbed1c: ldur            x1, [fp, #-0x10]
    // 0xbbed20: ArrayStore: r1[1] = r0  ; List_4
    //     0xbbed20: add             x25, x1, #0x13
    //     0xbbed24: str             w0, [x25]
    //     0xbbed28: tbz             w0, #0, #0xbbed44
    //     0xbbed2c: ldurb           w16, [x1, #-1]
    //     0xbbed30: ldurb           w17, [x0, #-1]
    //     0xbbed34: and             x16, x17, x16, lsr #2
    //     0xbbed38: tst             x16, HEAP, lsr #32
    //     0xbbed3c: b.eq            #0xbbed44
    //     0xbbed40: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbbed44: ldur            x0, [fp, #-0x10]
    // 0xbbed48: r16 = "#"
    //     0xbbed48: ldr             x16, [PP, #0x8e8]  ; [pp+0x8e8] "#"
    // 0xbbed4c: ArrayStore: r0[0] = r16  ; List_4
    //     0xbbed4c: stur            w16, [x0, #0x17]
    // 0xbbed50: ldur            x1, [fp, #-8]
    // 0xbbed54: r0 = shortHash()
    //     0xbbed54: bl              #0x858904  ; [package:flutter/src/foundation/diagnostics.dart] ::shortHash
    // 0xbbed58: ldur            x1, [fp, #-0x10]
    // 0xbbed5c: ArrayStore: r1[3] = r0  ; List_4
    //     0xbbed5c: add             x25, x1, #0x1b
    //     0xbbed60: str             w0, [x25]
    //     0xbbed64: tbz             w0, #0, #0xbbed80
    //     0xbbed68: ldurb           w16, [x1, #-1]
    //     0xbbed6c: ldurb           w17, [x0, #-1]
    //     0xbbed70: and             x16, x17, x16, lsr #2
    //     0xbbed74: tst             x16, HEAP, lsr #32
    //     0xbbed78: b.eq            #0xbbed80
    //     0xbbed7c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbbed80: ldur            x16, [fp, #-0x10]
    // 0xbbed84: str             x16, [SP]
    // 0xbbed88: r0 = _interpolate()
    //     0xbbed88: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xbbed8c: stur            x0, [fp, #-8]
    // 0xbbed90: r0 = StateError()
    //     0xbbed90: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbbed94: mov             x1, x0
    // 0xbbed98: ldur            x0, [fp, #-8]
    // 0xbbed9c: StoreField: r1->field_b = r0
    //     0xbbed9c: stur            w0, [x1, #0xb]
    // 0xbbeda0: mov             x0, x1
    // 0xbbeda4: r0 = Throw()
    //     0xbbeda4: bl              #0x13ddb2c  ; ThrowStub
    // 0xbbeda8: brk             #0
    // 0xbbedac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbbedac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbbedb0: b               #0xbbe7e0
    // 0xbbedb4: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbbedb4: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbbedb8: r0 = StackOverflowSharedWithFPURegs()
    //     0xbbedb8: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xbbedbc: b               #0xbbe9a8
    // 0xbbedc0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbedc0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbbedc4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbedc4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbbedc8: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbbedc8: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  set _ dividerThickness=(/* No info */) {
    // ** addr: 0xcee37c, size: 0x44
    // 0xcee37c: EnterFrame
    //     0xcee37c: stp             fp, lr, [SP, #-0x10]!
    //     0xcee380: mov             fp, SP
    // 0xcee384: d1 = 0.300000
    //     0xcee384: add             x17, PP, #0x13, lsl #12  ; [pp+0x13a88] IMM: double(0.3) from 0x3fd3333333333333
    //     0xcee388: ldr             d1, [x17, #0xa88]
    // 0xcee38c: CheckStackOverflow
    //     0xcee38c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcee390: cmp             SP, x16
    //     0xcee394: b.ls            #0xcee3b8
    // 0xcee398: fcmp            d1, d1
    // 0xcee39c: b.eq            #0xcee3a8
    // 0xcee3a0: StoreField: r1->field_97 = d1
    //     0xcee3a0: stur            d1, [x1, #0x97]
    // 0xcee3a4: r0 = markNeedsLayout()
    //     0xcee3a4: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcee3a8: r0 = Null
    //     0xcee3a8: mov             x0, NULL
    // 0xcee3ac: LeaveFrame
    //     0xcee3ac: mov             SP, fp
    //     0xcee3b0: ldp             fp, lr, [SP], #0x10
    // 0xcee3b4: ret
    //     0xcee3b4: ret             
    // 0xcee3b8: r0 = StackOverflowSharedWithFPURegs()
    //     0xcee3b8: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xcee3bc: b               #0xcee398
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x10eff40, size: 0x24
    // 0x10eff40: EnterFrame
    //     0x10eff40: stp             fp, lr, [SP, #-0x10]!
    //     0x10eff44: mov             fp, SP
    // 0x10eff48: ldr             x2, [fp, #0x10]
    // 0x10eff4c: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x10eff4c: add             x1, PP, #0xd1, lsl #12  ; [pp+0xd1970] AnonymousClosure: (0xb238dc), in [package:flutter/src/cupertino/dialog.dart] _RenderAlertDialogActionsLayout::computeMinIntrinsicHeight (0xb237dc)
    //     0x10eff50: ldr             x1, [x1, #0x970]
    // 0x10eff54: r0 = AllocateClosure()
    //     0x10eff54: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10eff58: LeaveFrame
    //     0x10eff58: mov             SP, fp
    //     0x10eff5c: ldp             fp, lr, [SP], #0x10
    // 0x10eff60: ret
    //     0x10eff60: ret             
  }
}

// class id: 5488, size: 0x14, field offset: 0x14
class _CupertinoDialogActionState extends State<dynamic>
    implements _SlideTarget {

  _ build(/* No info */) {
    // ** addr: 0xde5b58, size: 0x320
    // 0xde5b58: EnterFrame
    //     0xde5b58: stp             fp, lr, [SP, #-0x10]!
    //     0xde5b5c: mov             fp, SP
    // 0xde5b60: AllocStack(0x30)
    //     0xde5b60: sub             SP, SP, #0x30
    // 0xde5b64: SetupParameters(_CupertinoDialogActionState this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xde5b64: mov             x0, x2
    //     0xde5b68: stur            x2, [fp, #-0x10]
    //     0xde5b6c: mov             x2, x1
    //     0xde5b70: stur            x1, [fp, #-8]
    // 0xde5b74: CheckStackOverflow
    //     0xde5b74: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde5b78: cmp             SP, x16
    //     0xde5b7c: b.ls            #0xde5e54
    // 0xde5b80: LoadField: r1 = r2->field_b
    //     0xde5b80: ldur            w1, [x2, #0xb]
    // 0xde5b84: DecompressPointer r1
    //     0xde5b84: add             x1, x1, HEAP, lsl #32
    // 0xde5b88: cmp             w1, NULL
    // 0xde5b8c: b.eq            #0xde5e5c
    // 0xde5b90: mov             x1, x0
    // 0xde5b94: r0 = of()
    //     0xde5b94: bl              #0xccc364  ; [package:flutter/src/cupertino/theme.dart] CupertinoTheme::of
    // 0xde5b98: r1 = LoadClassIdInstr(r0)
    //     0xde5b98: ldur            x1, [x0, #-1]
    //     0xde5b9c: ubfx            x1, x1, #0xc, #0x14
    // 0xde5ba0: r17 = 4617
    //     0xde5ba0: mov             x17, #0x1209
    // 0xde5ba4: cmp             x1, x17
    // 0xde5ba8: b.ne            #0xde5bc4
    // 0xde5bac: LoadField: r1 = r0->field_27
    //     0xde5bac: ldur            w1, [x0, #0x27]
    // 0xde5bb0: DecompressPointer r1
    //     0xde5bb0: add             x1, x1, HEAP, lsl #32
    // 0xde5bb4: LoadField: r0 = r1->field_b
    //     0xde5bb4: ldur            w0, [x1, #0xb]
    // 0xde5bb8: DecompressPointer r0
    //     0xde5bb8: add             x0, x0, HEAP, lsl #32
    // 0xde5bbc: mov             x1, x0
    // 0xde5bc0: b               #0xde5bdc
    // 0xde5bc4: LoadField: r1 = r0->field_2b
    //     0xde5bc4: ldur            w1, [x0, #0x2b]
    // 0xde5bc8: DecompressPointer r1
    //     0xde5bc8: add             x1, x1, HEAP, lsl #32
    // 0xde5bcc: LoadField: r0 = r1->field_3f
    //     0xde5bcc: ldur            w0, [x1, #0x3f]
    // 0xde5bd0: DecompressPointer r0
    //     0xde5bd0: add             x0, x0, HEAP, lsl #32
    // 0xde5bd4: LoadField: r1 = r0->field_b
    //     0xde5bd4: ldur            w1, [x0, #0xb]
    // 0xde5bd8: DecompressPointer r1
    //     0xde5bd8: add             x1, x1, HEAP, lsl #32
    // 0xde5bdc: ldur            x0, [fp, #-8]
    // 0xde5be0: ldur            x2, [fp, #-0x10]
    // 0xde5be4: r0 = resolve()
    //     0xde5be4: bl              #0xce150c  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolve
    // 0xde5be8: str             x0, [SP]
    // 0xde5bec: r1 = Instance_TextStyle
    //     0xde5bec: add             x1, PP, #0xab, lsl #12  ; [pp+0xab2d8] Obj!TextStyle@12b0d91
    //     0xde5bf0: ldr             x1, [x1, #0x2d8]
    // 0xde5bf4: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0xde5bf4: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0xde5bf8: ldr             x4, [x4, #0x7f0]
    // 0xde5bfc: r0 = copyWith()
    //     0xde5bfc: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xde5c00: mov             x1, x0
    // 0xde5c04: ldur            x0, [fp, #-8]
    // 0xde5c08: LoadField: r2 = r0->field_b
    //     0xde5c08: ldur            w2, [x0, #0xb]
    // 0xde5c0c: DecompressPointer r2
    //     0xde5c0c: add             x2, x2, HEAP, lsl #32
    // 0xde5c10: cmp             w2, NULL
    // 0xde5c14: b.eq            #0xde5e60
    // 0xde5c18: r2 = Null
    //     0xde5c18: mov             x2, NULL
    // 0xde5c1c: r0 = merge()
    //     0xde5c1c: bl              #0x8a98e8  ; [package:flutter/src/painting/text_style.dart] TextStyle::merge
    // 0xde5c20: mov             x1, x0
    // 0xde5c24: ldur            x0, [fp, #-8]
    // 0xde5c28: LoadField: r2 = r0->field_b
    //     0xde5c28: ldur            w2, [x0, #0xb]
    // 0xde5c2c: DecompressPointer r2
    //     0xde5c2c: add             x2, x2, HEAP, lsl #32
    // 0xde5c30: cmp             w2, NULL
    // 0xde5c34: b.eq            #0xde5e64
    // 0xde5c38: LoadField: r3 = r2->field_f
    //     0xde5c38: ldur            w3, [x2, #0xf]
    // 0xde5c3c: DecompressPointer r3
    //     0xde5c3c: add             x3, x3, HEAP, lsl #32
    // 0xde5c40: tbnz            w3, #4, #0xde5c64
    // 0xde5c44: r16 = Instance_FontWeight
    //     0xde5c44: add             x16, PP, #0x14, lsl #12  ; [pp+0x14190] Obj!FontWeight@12a0561
    //     0xde5c48: ldr             x16, [x16, #0x190]
    // 0xde5c4c: str             x16, [SP]
    // 0xde5c50: r4 = const [0, 0x2, 0x1, 0x1, fontWeight, 0x1, null]
    //     0xde5c50: add             x4, PP, #0x22, lsl #12  ; [pp+0x22140] List(7) [0, 0x2, 0x1, 0x1, "fontWeight", 0x1, Null]
    //     0xde5c54: ldr             x4, [x4, #0x140]
    // 0xde5c58: r0 = copyWith()
    //     0xde5c58: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xde5c5c: mov             x3, x0
    // 0xde5c60: b               #0xde5c68
    // 0xde5c64: mov             x3, x1
    // 0xde5c68: ldur            x0, [fp, #-8]
    // 0xde5c6c: stur            x3, [fp, #-0x18]
    // 0xde5c70: LoadField: r1 = r0->field_b
    //     0xde5c70: ldur            w1, [x0, #0xb]
    // 0xde5c74: DecompressPointer r1
    //     0xde5c74: add             x1, x1, HEAP, lsl #32
    // 0xde5c78: cmp             w1, NULL
    // 0xde5c7c: b.eq            #0xde5e68
    // 0xde5c80: LoadField: r1 = r3->field_1f
    //     0xde5c80: ldur            w1, [x3, #0x1f]
    // 0xde5c84: DecompressPointer r1
    //     0xde5c84: add             x1, x1, HEAP, lsl #32
    // 0xde5c88: cmp             w1, NULL
    // 0xde5c8c: b.ne            #0xde5c98
    // 0xde5c90: d1 = 14.000000
    //     0xde5c90: fmov            d1, #14.00000000
    // 0xde5c94: b               #0xde5ca0
    // 0xde5c98: LoadField: d0 = r1->field_7
    //     0xde5c98: ldur            d0, [x1, #7]
    // 0xde5c9c: mov             v1.16b, v0.16b
    // 0xde5ca0: d0 = 0.000000
    //     0xde5ca0: eor             v0.16b, v0.16b, v0.16b
    // 0xde5ca4: fcmp            d1, d0
    // 0xde5ca8: b.ne            #0xde5cb4
    // 0xde5cac: d0 = 14.000000
    //     0xde5cac: fmov            d0, #14.00000000
    // 0xde5cb0: b               #0xde5cb8
    // 0xde5cb4: mov             v0.16b, v1.16b
    // 0xde5cb8: ldur            x1, [fp, #-0x10]
    // 0xde5cbc: stur            d0, [fp, #-0x28]
    // 0xde5cc0: r0 = textScalerOf()
    //     0xde5cc0: bl              #0xd16168  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::textScalerOf
    // 0xde5cc4: r1 = LoadClassIdInstr(r0)
    //     0xde5cc4: ldur            x1, [x0, #-1]
    //     0xde5cc8: ubfx            x1, x1, #0xc, #0x14
    // 0xde5ccc: mov             x16, x0
    // 0xde5cd0: mov             x0, x1
    // 0xde5cd4: mov             x1, x16
    // 0xde5cd8: ldur            d0, [fp, #-0x28]
    // 0xde5cdc: r0 = GDT[cid_x0 + -0x1000]()
    //     0xde5cdc: sub             lr, x0, #1, lsl #12
    //     0xde5ce0: ldr             lr, [x21, lr, lsl #3]
    //     0xde5ce4: blr             lr
    // 0xde5ce8: LoadField: d0 = r0->field_7
    //     0xde5ce8: ldur            d0, [x0, #7]
    // 0xde5cec: ldur            d1, [fp, #-0x28]
    // 0xde5cf0: fdiv            d2, d0, d1
    // 0xde5cf4: d0 = 8.000000
    //     0xde5cf4: fmov            d0, #8.00000000
    // 0xde5cf8: fmul            d1, d2, d0
    // 0xde5cfc: ldur            x1, [fp, #-0x10]
    // 0xde5d00: stur            d1, [fp, #-0x28]
    // 0xde5d04: r0 = _isInAccessibilityMode()
    //     0xde5d04: bl              #0xde3760  ; [package:flutter/src/cupertino/dialog.dart] ::_isInAccessibilityMode
    // 0xde5d08: tbnz            w0, #4, #0xde5d3c
    // 0xde5d0c: ldur            x0, [fp, #-8]
    // 0xde5d10: LoadField: r1 = r0->field_b
    //     0xde5d10: ldur            w1, [x0, #0xb]
    // 0xde5d14: DecompressPointer r1
    //     0xde5d14: add             x1, x1, HEAP, lsl #32
    // 0xde5d18: cmp             w1, NULL
    // 0xde5d1c: b.eq            #0xde5e6c
    // 0xde5d20: LoadField: r2 = r1->field_1f
    //     0xde5d20: ldur            w2, [x1, #0x1f]
    // 0xde5d24: DecompressPointer r2
    //     0xde5d24: add             x2, x2, HEAP, lsl #32
    // 0xde5d28: mov             x1, x0
    // 0xde5d2c: ldur            x3, [fp, #-0x18]
    // 0xde5d30: r0 = _buildContentWithAccessibilitySizingPolicy()
    //     0xde5d30: bl              #0xde608c  ; [package:flutter/src/cupertino/dialog.dart] _CupertinoDialogActionState::_buildContentWithAccessibilitySizingPolicy
    // 0xde5d34: mov             x1, x0
    // 0xde5d38: b               #0xde5d70
    // 0xde5d3c: ldur            x0, [fp, #-8]
    // 0xde5d40: LoadField: r1 = r0->field_b
    //     0xde5d40: ldur            w1, [x0, #0xb]
    // 0xde5d44: DecompressPointer r1
    //     0xde5d44: add             x1, x1, HEAP, lsl #32
    // 0xde5d48: cmp             w1, NULL
    // 0xde5d4c: b.eq            #0xde5e70
    // 0xde5d50: LoadField: r2 = r1->field_1f
    //     0xde5d50: ldur            w2, [x1, #0x1f]
    // 0xde5d54: DecompressPointer r2
    //     0xde5d54: add             x2, x2, HEAP, lsl #32
    // 0xde5d58: mov             x1, x0
    // 0xde5d5c: ldur            x3, [fp, #-0x10]
    // 0xde5d60: ldur            d0, [fp, #-0x28]
    // 0xde5d64: ldur            x5, [fp, #-0x18]
    // 0xde5d68: r0 = _buildContentWithRegularSizingPolicy()
    //     0xde5d68: bl              #0xde5e9c  ; [package:flutter/src/cupertino/dialog.dart] _CupertinoDialogActionState::_buildContentWithRegularSizingPolicy
    // 0xde5d6c: mov             x1, x0
    // 0xde5d70: ldur            x0, [fp, #-8]
    // 0xde5d74: ldur            d0, [fp, #-0x28]
    // 0xde5d78: stur            x1, [fp, #-0x10]
    // 0xde5d7c: LoadField: r2 = r0->field_b
    //     0xde5d7c: ldur            w2, [x0, #0xb]
    // 0xde5d80: DecompressPointer r2
    //     0xde5d80: add             x2, x2, HEAP, lsl #32
    // 0xde5d84: cmp             w2, NULL
    // 0xde5d88: b.eq            #0xde5e74
    // 0xde5d8c: r0 = EdgeInsets()
    //     0xde5d8c: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xde5d90: ldur            d0, [fp, #-0x28]
    // 0xde5d94: stur            x0, [fp, #-0x18]
    // 0xde5d98: StoreField: r0->field_7 = d0
    //     0xde5d98: stur            d0, [x0, #7]
    // 0xde5d9c: StoreField: r0->field_f = d0
    //     0xde5d9c: stur            d0, [x0, #0xf]
    // 0xde5da0: ArrayStore: r0[0] = d0  ; List_8
    //     0xde5da0: stur            d0, [x0, #0x17]
    // 0xde5da4: StoreField: r0->field_1f = d0
    //     0xde5da4: stur            d0, [x0, #0x1f]
    // 0xde5da8: r0 = Center()
    //     0xde5da8: bl              #0xd0c898  ; AllocateCenterStub -> Center (size=0x1c)
    // 0xde5dac: mov             x1, x0
    // 0xde5db0: r0 = Instance_Alignment
    //     0xde5db0: add             x0, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xde5db4: ldr             x0, [x0, #0xb80]
    // 0xde5db8: stur            x1, [fp, #-0x20]
    // 0xde5dbc: StoreField: r1->field_f = r0
    //     0xde5dbc: stur            w0, [x1, #0xf]
    // 0xde5dc0: ldur            x0, [fp, #-0x10]
    // 0xde5dc4: StoreField: r1->field_b = r0
    //     0xde5dc4: stur            w0, [x1, #0xb]
    // 0xde5dc8: r0 = Padding()
    //     0xde5dc8: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xde5dcc: mov             x1, x0
    // 0xde5dd0: ldur            x0, [fp, #-0x18]
    // 0xde5dd4: stur            x1, [fp, #-0x10]
    // 0xde5dd8: StoreField: r1->field_f = r0
    //     0xde5dd8: stur            w0, [x1, #0xf]
    // 0xde5ddc: ldur            x0, [fp, #-0x20]
    // 0xde5de0: StoreField: r1->field_b = r0
    //     0xde5de0: stur            w0, [x1, #0xb]
    // 0xde5de4: r0 = ConstrainedBox()
    //     0xde5de4: bl              #0xd0a588  ; AllocateConstrainedBoxStub -> ConstrainedBox (size=0x14)
    // 0xde5de8: mov             x1, x0
    // 0xde5dec: r0 = Instance_BoxConstraints
    //     0xde5dec: add             x0, PP, #0xab, lsl #12  ; [pp+0xab2e0] Obj!BoxConstraints@129c2f1
    //     0xde5df0: ldr             x0, [x0, #0x2e0]
    // 0xde5df4: stur            x1, [fp, #-0x18]
    // 0xde5df8: StoreField: r1->field_f = r0
    //     0xde5df8: stur            w0, [x1, #0xf]
    // 0xde5dfc: ldur            x0, [fp, #-0x10]
    // 0xde5e00: StoreField: r1->field_b = r0
    //     0xde5e00: stur            w0, [x1, #0xb]
    // 0xde5e04: r0 = MetaData()
    //     0xde5e04: bl              #0xde5108  ; AllocateMetaDataStub -> MetaData (size=0x18)
    // 0xde5e08: mov             x1, x0
    // 0xde5e0c: ldur            x0, [fp, #-8]
    // 0xde5e10: stur            x1, [fp, #-0x10]
    // 0xde5e14: StoreField: r1->field_f = r0
    //     0xde5e14: stur            w0, [x1, #0xf]
    // 0xde5e18: r0 = Instance_HitTestBehavior
    //     0xde5e18: add             x0, PP, #0x15, lsl #12  ; [pp+0x155c0] Obj!HitTestBehavior@12c43c1
    //     0xde5e1c: ldr             x0, [x0, #0x5c0]
    // 0xde5e20: StoreField: r1->field_13 = r0
    //     0xde5e20: stur            w0, [x1, #0x13]
    // 0xde5e24: ldur            x0, [fp, #-0x18]
    // 0xde5e28: StoreField: r1->field_b = r0
    //     0xde5e28: stur            w0, [x1, #0xb]
    // 0xde5e2c: r0 = MouseRegion()
    //     0xde5e2c: bl              #0xd1c8fc  ; AllocateMouseRegionStub -> MouseRegion (size=0x28)
    // 0xde5e30: r1 = Instance__DeferringMouseCursor
    //     0xde5e30: ldr             x1, [PP, #0x2208]  ; [pp+0x2208] Obj!_DeferringMouseCursor@12b3241
    // 0xde5e34: StoreField: r0->field_1b = r1
    //     0xde5e34: stur            w1, [x0, #0x1b]
    // 0xde5e38: r1 = true
    //     0xde5e38: add             x1, NULL, #0x20  ; true
    // 0xde5e3c: StoreField: r0->field_1f = r1
    //     0xde5e3c: stur            w1, [x0, #0x1f]
    // 0xde5e40: ldur            x1, [fp, #-0x10]
    // 0xde5e44: StoreField: r0->field_b = r1
    //     0xde5e44: stur            w1, [x0, #0xb]
    // 0xde5e48: LeaveFrame
    //     0xde5e48: mov             SP, fp
    //     0xde5e4c: ldp             fp, lr, [SP], #0x10
    // 0xde5e50: ret
    //     0xde5e50: ret             
    // 0xde5e54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde5e54: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde5e58: b               #0xde5b80
    // 0xde5e5c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde5e5c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde5e60: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde5e60: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde5e64: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde5e64: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde5e68: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde5e68: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde5e6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde5e6c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde5e70: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde5e70: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde5e74: r0 = NullCastErrorSharedWithFPURegs()
    //     0xde5e74: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  _ _buildContentWithRegularSizingPolicy(/* No info */) {
    // ** addr: 0xde5e9c, size: 0x1f0
    // 0xde5e9c: EnterFrame
    //     0xde5e9c: stp             fp, lr, [SP, #-0x10]!
    //     0xde5ea0: mov             fp, SP
    // 0xde5ea4: AllocStack(0x50)
    //     0xde5ea4: sub             SP, SP, #0x50
    // 0xde5ea8: SetupParameters(_CupertinoDialogActionState this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r0, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */, dynamic _ /* d0 => d0, fp-0x30 */)
    //     0xde5ea8: mov             x0, x3
    //     0xde5eac: stur            x3, [fp, #-0x18]
    //     0xde5eb0: mov             x3, x1
    //     0xde5eb4: stur            x1, [fp, #-8]
    //     0xde5eb8: stur            x2, [fp, #-0x10]
    //     0xde5ebc: stur            x5, [fp, #-0x20]
    //     0xde5ec0: stur            d0, [fp, #-0x30]
    // 0xde5ec4: CheckStackOverflow
    //     0xde5ec4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde5ec8: cmp             SP, x16
    //     0xde5ecc: b.ls            #0xde607c
    // 0xde5ed0: mov             x1, x0
    // 0xde5ed4: r0 = _isInAccessibilityMode()
    //     0xde5ed4: bl              #0xde3760  ; [package:flutter/src/cupertino/dialog.dart] ::_isInAccessibilityMode
    // 0xde5ed8: tbnz            w0, #4, #0xde5ee8
    // 0xde5edc: d1 = 310.000000
    //     0xde5edc: add             x17, PP, #0xab, lsl #12  ; [pp+0xab270] IMM: double(310) from 0x4073600000000000
    //     0xde5ee0: ldr             d1, [x17, #0x270]
    // 0xde5ee4: b               #0xde5ef0
    // 0xde5ee8: d1 = 270.000000
    //     0xde5ee8: add             x17, PP, #0x92, lsl #12  ; [pp+0x92e48] IMM: double(270) from 0x4070e00000000000
    //     0xde5eec: ldr             d1, [x17, #0xe48]
    // 0xde5ef0: ldur            x3, [fp, #-8]
    // 0xde5ef4: ldur            x2, [fp, #-0x10]
    // 0xde5ef8: ldur            d0, [fp, #-0x30]
    // 0xde5efc: ldur            x0, [fp, #-0x20]
    // 0xde5f00: ldur            x1, [fp, #-0x18]
    // 0xde5f04: stur            d1, [fp, #-0x38]
    // 0xde5f08: r0 = textScalerOf()
    //     0xde5f08: bl              #0xd16168  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::textScalerOf
    // 0xde5f0c: ldur            x2, [fp, #-0x20]
    // 0xde5f10: LoadField: r1 = r2->field_1f
    //     0xde5f10: ldur            w1, [x2, #0x1f]
    // 0xde5f14: DecompressPointer r1
    //     0xde5f14: add             x1, x1, HEAP, lsl #32
    // 0xde5f18: cmp             w1, NULL
    // 0xde5f1c: b.eq            #0xde6084
    // 0xde5f20: LoadField: d0 = r1->field_7
    //     0xde5f20: ldur            d0, [x1, #7]
    // 0xde5f24: r1 = LoadClassIdInstr(r0)
    //     0xde5f24: ldur            x1, [x0, #-1]
    //     0xde5f28: ubfx            x1, x1, #0xc, #0x14
    // 0xde5f2c: mov             x16, x0
    // 0xde5f30: mov             x0, x1
    // 0xde5f34: mov             x1, x16
    // 0xde5f38: r0 = GDT[cid_x0 + -0x1000]()
    //     0xde5f38: sub             lr, x0, #1, lsl #12
    //     0xde5f3c: ldr             lr, [x21, lr, lsl #3]
    //     0xde5f40: blr             lr
    // 0xde5f44: LoadField: d0 = r0->field_7
    //     0xde5f44: ldur            d0, [x0, #7]
    // 0xde5f48: d1 = 10.000000
    //     0xde5f48: fmov            d1, #10.00000000
    // 0xde5f4c: fdiv            d2, d0, d1
    // 0xde5f50: ldur            d0, [fp, #-0x30]
    // 0xde5f54: d1 = 2.000000
    //     0xde5f54: fmov            d1, #2.00000000
    // 0xde5f58: fmul            d3, d0, d1
    // 0xde5f5c: ldur            d0, [fp, #-0x38]
    // 0xde5f60: fsub            d1, d0, d3
    // 0xde5f64: fmul            d0, d2, d1
    // 0xde5f68: stur            d0, [fp, #-0x30]
    // 0xde5f6c: r0 = BoxConstraints()
    //     0xde5f6c: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xde5f70: stur            x0, [fp, #-0x18]
    // 0xde5f74: StoreField: r0->field_7 = rZR
    //     0xde5f74: stur            xzr, [x0, #7]
    // 0xde5f78: ldur            d0, [fp, #-0x30]
    // 0xde5f7c: StoreField: r0->field_f = d0
    //     0xde5f7c: stur            d0, [x0, #0xf]
    // 0xde5f80: ArrayStore: r0[0] = rZR  ; List_8
    //     0xde5f80: stur            xzr, [x0, #0x17]
    // 0xde5f84: d0 = inf
    //     0xde5f84: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xde5f88: StoreField: r0->field_1f = d0
    //     0xde5f88: stur            d0, [x0, #0x1f]
    // 0xde5f8c: ldur            x1, [fp, #-8]
    // 0xde5f90: LoadField: r2 = r1->field_b
    //     0xde5f90: ldur            w2, [x1, #0xb]
    // 0xde5f94: DecompressPointer r2
    //     0xde5f94: add             x2, x2, HEAP, lsl #32
    // 0xde5f98: cmp             w2, NULL
    // 0xde5f9c: b.eq            #0xde6088
    // 0xde5fa0: LoadField: r1 = r2->field_b
    //     0xde5fa0: ldur            w1, [x2, #0xb]
    // 0xde5fa4: DecompressPointer r1
    //     0xde5fa4: add             x1, x1, HEAP, lsl #32
    // 0xde5fa8: stur            x1, [fp, #-8]
    // 0xde5fac: r0 = DefaultTextStyle()
    //     0xde5fac: bl              #0xd0b11c  ; AllocateDefaultTextStyleStub -> DefaultTextStyle (size=0x2c)
    // 0xde5fb0: mov             x1, x0
    // 0xde5fb4: ldur            x0, [fp, #-0x20]
    // 0xde5fb8: stur            x1, [fp, #-0x28]
    // 0xde5fbc: StoreField: r1->field_f = r0
    //     0xde5fbc: stur            w0, [x1, #0xf]
    // 0xde5fc0: r0 = Instance_TextAlign
    //     0xde5fc0: ldr             x0, [PP, #0x4c68]  ; [pp+0x4c68] Obj!TextAlign@12c7561
    // 0xde5fc4: StoreField: r1->field_13 = r0
    //     0xde5fc4: stur            w0, [x1, #0x13]
    // 0xde5fc8: r0 = true
    //     0xde5fc8: add             x0, NULL, #0x20  ; true
    // 0xde5fcc: ArrayStore: r1[0] = r0  ; List_4
    //     0xde5fcc: stur            w0, [x1, #0x17]
    // 0xde5fd0: r0 = Instance_TextOverflow
    //     0xde5fd0: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1ac18] Obj!TextOverflow@12c47a1
    //     0xde5fd4: ldr             x0, [x0, #0xc18]
    // 0xde5fd8: StoreField: r1->field_1b = r0
    //     0xde5fd8: stur            w0, [x1, #0x1b]
    // 0xde5fdc: r0 = 2
    //     0xde5fdc: mov             x0, #2
    // 0xde5fe0: StoreField: r1->field_1f = r0
    //     0xde5fe0: stur            w0, [x1, #0x1f]
    // 0xde5fe4: r0 = Instance_TextWidthBasis
    //     0xde5fe4: add             x0, PP, #0x20, lsl #12  ; [pp+0x20110] Obj!TextWidthBasis@12c4781
    //     0xde5fe8: ldr             x0, [x0, #0x110]
    // 0xde5fec: StoreField: r1->field_23 = r0
    //     0xde5fec: stur            w0, [x1, #0x23]
    // 0xde5ff0: ldur            x0, [fp, #-0x10]
    // 0xde5ff4: StoreField: r1->field_b = r0
    //     0xde5ff4: stur            w0, [x1, #0xb]
    // 0xde5ff8: r0 = Semantics()
    //     0xde5ff8: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xde5ffc: stur            x0, [fp, #-0x10]
    // 0xde6000: r16 = true
    //     0xde6000: add             x16, NULL, #0x20  ; true
    // 0xde6004: ldur            lr, [fp, #-8]
    // 0xde6008: stp             lr, x16, [SP, #8]
    // 0xde600c: ldur            x16, [fp, #-0x28]
    // 0xde6010: str             x16, [SP]
    // 0xde6014: mov             x1, x0
    // 0xde6018: r4 = const [0, 0x4, 0x3, 0x1, button, 0x1, child, 0x3, onTap, 0x2, null]
    //     0xde6018: add             x4, PP, #0xab, lsl #12  ; [pp+0xab2e8] List(11) [0, 0x4, 0x3, 0x1, "button", 0x1, "child", 0x3, "onTap", 0x2, Null]
    //     0xde601c: ldr             x4, [x4, #0x2e8]
    // 0xde6020: r0 = Semantics()
    //     0xde6020: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xde6024: r0 = ConstrainedBox()
    //     0xde6024: bl              #0xd0a588  ; AllocateConstrainedBoxStub -> ConstrainedBox (size=0x14)
    // 0xde6028: mov             x1, x0
    // 0xde602c: ldur            x0, [fp, #-0x18]
    // 0xde6030: stur            x1, [fp, #-8]
    // 0xde6034: StoreField: r1->field_f = r0
    //     0xde6034: stur            w0, [x1, #0xf]
    // 0xde6038: ldur            x0, [fp, #-0x10]
    // 0xde603c: StoreField: r1->field_b = r0
    //     0xde603c: stur            w0, [x1, #0xb]
    // 0xde6040: r0 = FittedBox()
    //     0xde6040: bl              #0xd78304  ; AllocateFittedBoxStub -> FittedBox (size=0x1c)
    // 0xde6044: r1 = Instance_BoxFit
    //     0xde6044: add             x1, PP, #0x89, lsl #12  ; [pp+0x89e58] Obj!BoxFit@12c48c1
    //     0xde6048: ldr             x1, [x1, #0xe58]
    // 0xde604c: StoreField: r0->field_f = r1
    //     0xde604c: stur            w1, [x0, #0xf]
    // 0xde6050: r1 = Instance_Alignment
    //     0xde6050: add             x1, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xde6054: ldr             x1, [x1, #0xb80]
    // 0xde6058: StoreField: r0->field_13 = r1
    //     0xde6058: stur            w1, [x0, #0x13]
    // 0xde605c: r1 = Instance_Clip
    //     0xde605c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xde6060: ldr             x1, [x1, #0x840]
    // 0xde6064: ArrayStore: r0[0] = r1  ; List_4
    //     0xde6064: stur            w1, [x0, #0x17]
    // 0xde6068: ldur            x1, [fp, #-8]
    // 0xde606c: StoreField: r0->field_b = r1
    //     0xde606c: stur            w1, [x0, #0xb]
    // 0xde6070: LeaveFrame
    //     0xde6070: mov             SP, fp
    //     0xde6074: ldp             fp, lr, [SP], #0x10
    // 0xde6078: ret
    //     0xde6078: ret             
    // 0xde607c: r0 = StackOverflowSharedWithFPURegs()
    //     0xde607c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xde6080: b               #0xde5ed0
    // 0xde6084: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde6084: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde6088: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde6088: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _buildContentWithAccessibilitySizingPolicy(/* No info */) {
    // ** addr: 0xde608c, size: 0x5c
    // 0xde608c: EnterFrame
    //     0xde608c: stp             fp, lr, [SP, #-0x10]!
    //     0xde6090: mov             fp, SP
    // 0xde6094: AllocStack(0x10)
    //     0xde6094: sub             SP, SP, #0x10
    // 0xde6098: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xde6098: stur            x2, [fp, #-8]
    //     0xde609c: stur            x3, [fp, #-0x10]
    // 0xde60a0: r0 = DefaultTextStyle()
    //     0xde60a0: bl              #0xd0b11c  ; AllocateDefaultTextStyleStub -> DefaultTextStyle (size=0x2c)
    // 0xde60a4: ldur            x1, [fp, #-0x10]
    // 0xde60a8: StoreField: r0->field_f = r1
    //     0xde60a8: stur            w1, [x0, #0xf]
    // 0xde60ac: r1 = Instance_TextAlign
    //     0xde60ac: ldr             x1, [PP, #0x4c68]  ; [pp+0x4c68] Obj!TextAlign@12c7561
    // 0xde60b0: StoreField: r0->field_13 = r1
    //     0xde60b0: stur            w1, [x0, #0x13]
    // 0xde60b4: r1 = true
    //     0xde60b4: add             x1, NULL, #0x20  ; true
    // 0xde60b8: ArrayStore: r0[0] = r1  ; List_4
    //     0xde60b8: stur            w1, [x0, #0x17]
    // 0xde60bc: r1 = Instance_TextOverflow
    //     0xde60bc: add             x1, PP, #0x20, lsl #12  ; [pp+0x20108] Obj!TextOverflow@12c47c1
    //     0xde60c0: ldr             x1, [x1, #0x108]
    // 0xde60c4: StoreField: r0->field_1b = r1
    //     0xde60c4: stur            w1, [x0, #0x1b]
    // 0xde60c8: r1 = Instance_TextWidthBasis
    //     0xde60c8: add             x1, PP, #0x20, lsl #12  ; [pp+0x20110] Obj!TextWidthBasis@12c4781
    //     0xde60cc: ldr             x1, [x1, #0x110]
    // 0xde60d0: StoreField: r0->field_23 = r1
    //     0xde60d0: stur            w1, [x0, #0x23]
    // 0xde60d4: ldur            x1, [fp, #-8]
    // 0xde60d8: StoreField: r0->field_b = r1
    //     0xde60d8: stur            w1, [x0, #0xb]
    // 0xde60dc: LeaveFrame
    //     0xde60dc: mov             SP, fp
    //     0xde60e0: ldp             fp, lr, [SP], #0x10
    // 0xde60e4: ret
    //     0xde60e4: ret             
  }
  _ didConfirm(/* No info */) {
    // ** addr: 0x11a7be4, size: 0x6c
    // 0x11a7be4: EnterFrame
    //     0x11a7be4: stp             fp, lr, [SP, #-0x10]!
    //     0x11a7be8: mov             fp, SP
    // 0x11a7bec: AllocStack(0x8)
    //     0x11a7bec: sub             SP, SP, #8
    // 0x11a7bf0: CheckStackOverflow
    //     0x11a7bf0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a7bf4: cmp             SP, x16
    //     0x11a7bf8: b.ls            #0x11a7c40
    // 0x11a7bfc: LoadField: r0 = r1->field_b
    //     0x11a7bfc: ldur            w0, [x1, #0xb]
    // 0x11a7c00: DecompressPointer r0
    //     0x11a7c00: add             x0, x0, HEAP, lsl #32
    // 0x11a7c04: cmp             w0, NULL
    // 0x11a7c08: b.eq            #0x11a7c48
    // 0x11a7c0c: LoadField: r1 = r0->field_b
    //     0x11a7c0c: ldur            w1, [x0, #0xb]
    // 0x11a7c10: DecompressPointer r1
    //     0x11a7c10: add             x1, x1, HEAP, lsl #32
    // 0x11a7c14: cmp             w1, NULL
    // 0x11a7c18: b.eq            #0x11a7c4c
    // 0x11a7c1c: str             x1, [SP]
    // 0x11a7c20: mov             x0, x1
    // 0x11a7c24: ClosureCall
    //     0x11a7c24: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x11a7c28: ldur            x2, [x0, #0x1f]
    //     0x11a7c2c: blr             x2
    // 0x11a7c30: r0 = Null
    //     0x11a7c30: mov             x0, NULL
    // 0x11a7c34: LeaveFrame
    //     0x11a7c34: mov             SP, fp
    //     0x11a7c38: ldp             fp, lr, [SP], #0x10
    // 0x11a7c3c: ret
    //     0x11a7c3c: ret             
    // 0x11a7c40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a7c40: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a7c44: b               #0x11a7bfc
    // 0x11a7c48: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x11a7c48: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x11a7c4c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x11a7c4c: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
}

// class id: 5489, size: 0x14, field offset: 0x14
class _AlertDialogButtonBackgroundState extends State<dynamic>
    implements _SlideTarget {

  _ build(/* No info */) {
    // ** addr: 0xde5a24, size: 0x110
    // 0xde5a24: EnterFrame
    //     0xde5a24: stp             fp, lr, [SP, #-0x10]!
    //     0xde5a28: mov             fp, SP
    // 0xde5a2c: AllocStack(0x30)
    //     0xde5a2c: sub             SP, SP, #0x30
    // 0xde5a30: SetupParameters(_AlertDialogButtonBackgroundState this /* r1 => r0, fp-0x8 */)
    //     0xde5a30: mov             x0, x1
    //     0xde5a34: stur            x1, [fp, #-8]
    // 0xde5a38: CheckStackOverflow
    //     0xde5a38: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde5a3c: cmp             SP, x16
    //     0xde5a40: b.ls            #0xde5b24
    // 0xde5a44: LoadField: r1 = r0->field_b
    //     0xde5a44: ldur            w1, [x0, #0xb]
    // 0xde5a48: DecompressPointer r1
    //     0xde5a48: add             x1, x1, HEAP, lsl #32
    // 0xde5a4c: cmp             w1, NULL
    // 0xde5a50: b.eq            #0xde5b2c
    // 0xde5a54: LoadField: r3 = r1->field_b
    //     0xde5a54: ldur            w3, [x1, #0xb]
    // 0xde5a58: DecompressPointer r3
    //     0xde5a58: add             x3, x3, HEAP, lsl #32
    // 0xde5a5c: tbnz            w3, #4, #0xde5a70
    // 0xde5a60: ArrayLoad: r3 = r1[0]  ; List_4
    //     0xde5a60: ldur            w3, [x1, #0x17]
    // 0xde5a64: DecompressPointer r3
    //     0xde5a64: add             x3, x3, HEAP, lsl #32
    // 0xde5a68: mov             x1, x3
    // 0xde5a6c: b               #0xde5a7c
    // 0xde5a70: LoadField: r3 = r1->field_13
    //     0xde5a70: ldur            w3, [x1, #0x13]
    // 0xde5a74: DecompressPointer r3
    //     0xde5a74: add             x3, x3, HEAP, lsl #32
    // 0xde5a78: mov             x1, x3
    // 0xde5a7c: r0 = resolveFrom()
    //     0xde5a7c: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0xde5a80: stur            x0, [fp, #-0x10]
    // 0xde5a84: r0 = BoxDecoration()
    //     0xde5a84: bl              #0x8a721c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0xde5a88: mov             x1, x0
    // 0xde5a8c: ldur            x0, [fp, #-0x10]
    // 0xde5a90: stur            x1, [fp, #-0x18]
    // 0xde5a94: StoreField: r1->field_7 = r0
    //     0xde5a94: stur            w0, [x1, #7]
    // 0xde5a98: r0 = Instance_BoxShape
    //     0xde5a98: add             x0, PP, #0x17, lsl #12  ; [pp+0x171f8] Obj!BoxShape@12c4921
    //     0xde5a9c: ldr             x0, [x0, #0x1f8]
    // 0xde5aa0: StoreField: r1->field_23 = r0
    //     0xde5aa0: stur            w0, [x1, #0x23]
    // 0xde5aa4: ldur            x0, [fp, #-8]
    // 0xde5aa8: LoadField: r2 = r0->field_b
    //     0xde5aa8: ldur            w2, [x0, #0xb]
    // 0xde5aac: DecompressPointer r2
    //     0xde5aac: add             x2, x2, HEAP, lsl #32
    // 0xde5ab0: cmp             w2, NULL
    // 0xde5ab4: b.eq            #0xde5b30
    // 0xde5ab8: LoadField: r3 = r2->field_1b
    //     0xde5ab8: ldur            w3, [x2, #0x1b]
    // 0xde5abc: DecompressPointer r3
    //     0xde5abc: add             x3, x3, HEAP, lsl #32
    // 0xde5ac0: stur            x3, [fp, #-0x10]
    // 0xde5ac4: r0 = Container()
    //     0xde5ac4: bl              #0x8a5af8  ; AllocateContainerStub -> Container (size=0x38)
    // 0xde5ac8: stur            x0, [fp, #-0x20]
    // 0xde5acc: ldur            x16, [fp, #-0x18]
    // 0xde5ad0: ldur            lr, [fp, #-0x10]
    // 0xde5ad4: stp             lr, x16, [SP]
    // 0xde5ad8: mov             x1, x0
    // 0xde5adc: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, decoration, 0x1, null]
    //     0xde5adc: add             x4, PP, #0x1e, lsl #12  ; [pp+0x1eab8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "decoration", 0x1, Null]
    //     0xde5ae0: ldr             x4, [x4, #0xab8]
    // 0xde5ae4: r0 = Container()
    //     0xde5ae4: bl              #0x8a54e0  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0xde5ae8: r0 = MergeSemantics()
    //     0xde5ae8: bl              #0xd32f80  ; AllocateMergeSemanticsStub -> MergeSemantics (size=0x10)
    // 0xde5aec: mov             x1, x0
    // 0xde5af0: ldur            x0, [fp, #-0x20]
    // 0xde5af4: stur            x1, [fp, #-0x10]
    // 0xde5af8: StoreField: r1->field_b = r0
    //     0xde5af8: stur            w0, [x1, #0xb]
    // 0xde5afc: r0 = MetaData()
    //     0xde5afc: bl              #0xde5108  ; AllocateMetaDataStub -> MetaData (size=0x18)
    // 0xde5b00: ldur            x1, [fp, #-8]
    // 0xde5b04: StoreField: r0->field_f = r1
    //     0xde5b04: stur            w1, [x0, #0xf]
    // 0xde5b08: r1 = Instance_HitTestBehavior
    //     0xde5b08: ldr             x1, [PP, #0x5368]  ; [pp+0x5368] Obj!HitTestBehavior@12c43a1
    // 0xde5b0c: StoreField: r0->field_13 = r1
    //     0xde5b0c: stur            w1, [x0, #0x13]
    // 0xde5b10: ldur            x1, [fp, #-0x10]
    // 0xde5b14: StoreField: r0->field_b = r1
    //     0xde5b14: stur            w1, [x0, #0xb]
    // 0xde5b18: LeaveFrame
    //     0xde5b18: mov             SP, fp
    //     0xde5b1c: ldp             fp, lr, [SP], #0x10
    // 0xde5b20: ret
    //     0xde5b20: ret             
    // 0xde5b24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde5b24: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde5b28: b               #0xde5a44
    // 0xde5b2c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde5b2c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde5b30: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde5b30: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didEnter(/* No info */) {
    // ** addr: 0x121b26c, size: 0x8c
    // 0x121b26c: EnterFrame
    //     0x121b26c: stp             fp, lr, [SP, #-0x10]!
    //     0x121b270: mov             fp, SP
    // 0x121b274: AllocStack(0x20)
    //     0x121b274: sub             SP, SP, #0x20
    // 0x121b278: SetupParameters(_AlertDialogButtonBackgroundState this /* r1 => r0 */, dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r1, fp-0x10 */)
    //     0x121b278: mov             x0, x1
    //     0x121b27c: mov             x1, x3
    //     0x121b280: stur            x2, [fp, #-8]
    //     0x121b284: stur            x3, [fp, #-0x10]
    // 0x121b288: CheckStackOverflow
    //     0x121b288: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x121b28c: cmp             SP, x16
    //     0x121b290: b.ls            #0x121b2e8
    // 0x121b294: LoadField: r3 = r0->field_b
    //     0x121b294: ldur            w3, [x0, #0xb]
    // 0x121b298: DecompressPointer r3
    //     0x121b298: add             x3, x3, HEAP, lsl #32
    // 0x121b29c: cmp             w3, NULL
    // 0x121b2a0: b.eq            #0x121b2f0
    // 0x121b2a4: LoadField: r0 = r3->field_f
    //     0x121b2a4: ldur            w0, [x3, #0xf]
    // 0x121b2a8: DecompressPointer r0
    //     0x121b2a8: add             x0, x0, HEAP, lsl #32
    // 0x121b2ac: cmp             w0, NULL
    // 0x121b2b0: b.eq            #0x121b2f4
    // 0x121b2b4: stp             x1, x0, [SP]
    // 0x121b2b8: ClosureCall
    //     0x121b2b8: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x121b2bc: ldur            x2, [x0, #0x1f]
    //     0x121b2c0: blr             x2
    // 0x121b2c4: ldur            x0, [fp, #-0x10]
    // 0x121b2c8: tbnz            w0, #4, #0x121b2d8
    // 0x121b2cc: ldur            x1, [fp, #-8]
    // 0x121b2d0: tbz             w1, #4, #0x121b2d8
    // 0x121b2d4: r0 = selectionClick()
    //     0x121b2d4: bl              #0x859550  ; [package:flutter/src/services/haptic_feedback.dart] HapticFeedback::selectionClick
    // 0x121b2d8: ldur            x0, [fp, #-0x10]
    // 0x121b2dc: LeaveFrame
    //     0x121b2dc: mov             SP, fp
    //     0x121b2e0: ldp             fp, lr, [SP], #0x10
    // 0x121b2e4: ret
    //     0x121b2e4: ret             
    // 0x121b2e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x121b2e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x121b2ec: b               #0x121b294
    // 0x121b2f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x121b2f0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x121b2f4: r0 = NullErrorSharedWithoutFPURegs()
    //     0x121b2f4: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ didLeave(/* No info */) {
    // ** addr: 0x124933c, size: 0x70
    // 0x124933c: EnterFrame
    //     0x124933c: stp             fp, lr, [SP, #-0x10]!
    //     0x1249340: mov             fp, SP
    // 0x1249344: AllocStack(0x10)
    //     0x1249344: sub             SP, SP, #0x10
    // 0x1249348: CheckStackOverflow
    //     0x1249348: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x124934c: cmp             SP, x16
    //     0x1249350: b.ls            #0x124939c
    // 0x1249354: LoadField: r0 = r1->field_b
    //     0x1249354: ldur            w0, [x1, #0xb]
    // 0x1249358: DecompressPointer r0
    //     0x1249358: add             x0, x0, HEAP, lsl #32
    // 0x124935c: cmp             w0, NULL
    // 0x1249360: b.eq            #0x12493a4
    // 0x1249364: LoadField: r1 = r0->field_f
    //     0x1249364: ldur            w1, [x0, #0xf]
    // 0x1249368: DecompressPointer r1
    //     0x1249368: add             x1, x1, HEAP, lsl #32
    // 0x124936c: cmp             w1, NULL
    // 0x1249370: b.eq            #0x12493a8
    // 0x1249374: r16 = false
    //     0x1249374: add             x16, NULL, #0x30  ; false
    // 0x1249378: stp             x16, x1, [SP]
    // 0x124937c: mov             x0, x1
    // 0x1249380: ClosureCall
    //     0x1249380: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x1249384: ldur            x2, [x0, #0x1f]
    //     0x1249388: blr             x2
    // 0x124938c: r0 = Null
    //     0x124938c: mov             x0, NULL
    // 0x1249390: LeaveFrame
    //     0x1249390: mov             SP, fp
    //     0x1249394: ldp             fp, lr, [SP], #0x10
    // 0x1249398: ret
    //     0x1249398: ret             
    // 0x124939c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x124939c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12493a0: b               #0x1249354
    // 0x12493a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12493a4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x12493a8: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12493a8: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
}

// class id: 5490, size: 0x24, field offset: 0x14
class _OverscrollBackgroundState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0xde5584, size: 0x334
    // 0xde5584: EnterFrame
    //     0xde5584: stp             fp, lr, [SP, #-0x10]!
    //     0xde5588: mov             fp, SP
    // 0xde558c: AllocStack(0x30)
    //     0xde558c: sub             SP, SP, #0x30
    // 0xde5590: SetupParameters(_OverscrollBackgroundState this /* r1 => r0, fp-0x18 */)
    //     0xde5590: mov             x0, x1
    //     0xde5594: stur            x1, [fp, #-0x18]
    // 0xde5598: LoadField: r1 = r0->field_b
    //     0xde5598: ldur            w1, [x0, #0xb]
    // 0xde559c: DecompressPointer r1
    //     0xde559c: add             x1, x1, HEAP, lsl #32
    // 0xde55a0: stur            x1, [fp, #-0x10]
    // 0xde55a4: cmp             w1, NULL
    // 0xde55a8: b.eq            #0xde5878
    // 0xde55ac: LoadField: r2 = r1->field_b
    //     0xde55ac: ldur            w2, [x1, #0xb]
    // 0xde55b0: DecompressPointer r2
    //     0xde55b0: add             x2, x2, HEAP, lsl #32
    // 0xde55b4: stur            x2, [fp, #-8]
    // 0xde55b8: r0 = BoxDecoration()
    //     0xde55b8: bl              #0x8a721c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0xde55bc: mov             x1, x0
    // 0xde55c0: ldur            x0, [fp, #-8]
    // 0xde55c4: stur            x1, [fp, #-0x28]
    // 0xde55c8: StoreField: r1->field_7 = r0
    //     0xde55c8: stur            w0, [x1, #7]
    // 0xde55cc: r2 = Instance_BoxShape
    //     0xde55cc: add             x2, PP, #0x17, lsl #12  ; [pp+0x171f8] Obj!BoxShape@12c4921
    //     0xde55d0: ldr             x2, [x2, #0x1f8]
    // 0xde55d4: StoreField: r1->field_23 = r2
    //     0xde55d4: stur            w2, [x1, #0x23]
    // 0xde55d8: ldur            x3, [fp, #-0x18]
    // 0xde55dc: LoadField: d0 = r3->field_13
    //     0xde55dc: ldur            d0, [x3, #0x13]
    // 0xde55e0: r4 = inline_Allocate_Double()
    //     0xde55e0: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xde55e4: add             x4, x4, #0x10
    //     0xde55e8: cmp             x5, x4
    //     0xde55ec: b.ls            #0xde587c
    //     0xde55f0: str             x4, [THR, #0x60]  ; THR::top
    //     0xde55f4: sub             x4, x4, #0xf
    //     0xde55f8: mov             x5, #0xe19c
    //     0xde55fc: movk            x5, #3, lsl #16
    //     0xde5600: stur            x5, [x4, #-1]
    // 0xde5604: dmb             ishst
    // 0xde5608: StoreField: r4->field_7 = d0
    //     0xde5608: stur            d0, [x4, #7]
    // 0xde560c: stur            x4, [fp, #-0x20]
    // 0xde5610: r0 = SizedBox()
    //     0xde5610: bl              #0x8a7210  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0xde5614: mov             x1, x0
    // 0xde5618: ldur            x0, [fp, #-0x20]
    // 0xde561c: stur            x1, [fp, #-0x30]
    // 0xde5620: StoreField: r1->field_13 = r0
    //     0xde5620: stur            w0, [x1, #0x13]
    // 0xde5624: r0 = DecoratedBox()
    //     0xde5624: bl              #0xd66318  ; AllocateDecoratedBoxStub -> DecoratedBox (size=0x18)
    // 0xde5628: mov             x1, x0
    // 0xde562c: ldur            x0, [fp, #-0x28]
    // 0xde5630: stur            x1, [fp, #-0x20]
    // 0xde5634: StoreField: r1->field_f = r0
    //     0xde5634: stur            w0, [x1, #0xf]
    // 0xde5638: r0 = Instance_DecorationPosition
    //     0xde5638: add             x0, PP, #0x80, lsl #12  ; [pp+0x80ef0] Obj!DecorationPosition@12c4381
    //     0xde563c: ldr             x0, [x0, #0xef0]
    // 0xde5640: StoreField: r1->field_13 = r0
    //     0xde5640: stur            w0, [x1, #0x13]
    // 0xde5644: ldur            x2, [fp, #-0x30]
    // 0xde5648: StoreField: r1->field_b = r2
    //     0xde5648: stur            w2, [x1, #0xb]
    // 0xde564c: r0 = BoxDecoration()
    //     0xde564c: bl              #0x8a721c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0xde5650: mov             x1, x0
    // 0xde5654: ldur            x0, [fp, #-8]
    // 0xde5658: stur            x1, [fp, #-0x28]
    // 0xde565c: StoreField: r1->field_7 = r0
    //     0xde565c: stur            w0, [x1, #7]
    // 0xde5660: r0 = Instance_BoxShape
    //     0xde5660: add             x0, PP, #0x17, lsl #12  ; [pp+0x171f8] Obj!BoxShape@12c4921
    //     0xde5664: ldr             x0, [x0, #0x1f8]
    // 0xde5668: StoreField: r1->field_23 = r0
    //     0xde5668: stur            w0, [x1, #0x23]
    // 0xde566c: ldur            x2, [fp, #-0x18]
    // 0xde5670: LoadField: d0 = r2->field_1b
    //     0xde5670: ldur            d0, [x2, #0x1b]
    // 0xde5674: r0 = inline_Allocate_Double()
    //     0xde5674: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0xde5678: add             x0, x0, #0x10
    //     0xde567c: cmp             x3, x0
    //     0xde5680: b.ls            #0xde58a0
    //     0xde5684: str             x0, [THR, #0x60]  ; THR::top
    //     0xde5688: sub             x0, x0, #0xf
    //     0xde568c: mov             x3, #0xe19c
    //     0xde5690: movk            x3, #3, lsl #16
    //     0xde5694: stur            x3, [x0, #-1]
    // 0xde5698: dmb             ishst
    // 0xde569c: StoreField: r0->field_7 = d0
    //     0xde569c: stur            d0, [x0, #7]
    // 0xde56a0: stur            x0, [fp, #-8]
    // 0xde56a4: r0 = SizedBox()
    //     0xde56a4: bl              #0x8a7210  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0xde56a8: mov             x1, x0
    // 0xde56ac: ldur            x0, [fp, #-8]
    // 0xde56b0: stur            x1, [fp, #-0x30]
    // 0xde56b4: StoreField: r1->field_13 = r0
    //     0xde56b4: stur            w0, [x1, #0x13]
    // 0xde56b8: r0 = DecoratedBox()
    //     0xde56b8: bl              #0xd66318  ; AllocateDecoratedBoxStub -> DecoratedBox (size=0x18)
    // 0xde56bc: mov             x3, x0
    // 0xde56c0: ldur            x0, [fp, #-0x28]
    // 0xde56c4: stur            x3, [fp, #-8]
    // 0xde56c8: StoreField: r3->field_f = r0
    //     0xde56c8: stur            w0, [x3, #0xf]
    // 0xde56cc: r0 = Instance_DecorationPosition
    //     0xde56cc: add             x0, PP, #0x80, lsl #12  ; [pp+0x80ef0] Obj!DecorationPosition@12c4381
    //     0xde56d0: ldr             x0, [x0, #0xef0]
    // 0xde56d4: StoreField: r3->field_13 = r0
    //     0xde56d4: stur            w0, [x3, #0x13]
    // 0xde56d8: ldur            x0, [fp, #-0x30]
    // 0xde56dc: StoreField: r3->field_b = r0
    //     0xde56dc: stur            w0, [x3, #0xb]
    // 0xde56e0: r1 = Null
    //     0xde56e0: mov             x1, NULL
    // 0xde56e4: r2 = 4
    //     0xde56e4: mov             x2, #4
    // 0xde56e8: r0 = AllocateArray()
    //     0xde56e8: bl              #0x13df928  ; AllocateArrayStub
    // 0xde56ec: mov             x2, x0
    // 0xde56f0: ldur            x0, [fp, #-0x20]
    // 0xde56f4: stur            x2, [fp, #-0x28]
    // 0xde56f8: StoreField: r2->field_f = r0
    //     0xde56f8: stur            w0, [x2, #0xf]
    // 0xde56fc: ldur            x0, [fp, #-8]
    // 0xde5700: StoreField: r2->field_13 = r0
    //     0xde5700: stur            w0, [x2, #0x13]
    // 0xde5704: r1 = <Widget>
    //     0xde5704: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xde5708: r0 = AllocateGrowableArray()
    //     0xde5708: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xde570c: mov             x1, x0
    // 0xde5710: ldur            x0, [fp, #-0x28]
    // 0xde5714: stur            x1, [fp, #-8]
    // 0xde5718: StoreField: r1->field_f = r0
    //     0xde5718: stur            w0, [x1, #0xf]
    // 0xde571c: r2 = 4
    //     0xde571c: mov             x2, #4
    // 0xde5720: StoreField: r1->field_b = r2
    //     0xde5720: stur            w2, [x1, #0xb]
    // 0xde5724: r0 = Column()
    //     0xde5724: bl              #0x8a5b1c  ; AllocateColumnStub -> Column (size=0x38)
    // 0xde5728: mov             x2, x0
    // 0xde572c: r0 = Instance_Axis
    //     0xde572c: ldr             x0, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xde5730: stur            x2, [fp, #-0x20]
    // 0xde5734: StoreField: r2->field_f = r0
    //     0xde5734: stur            w0, [x2, #0xf]
    // 0xde5738: r0 = Instance_MainAxisAlignment
    //     0xde5738: add             x0, PP, #0x17, lsl #12  ; [pp+0x177b0] Obj!MainAxisAlignment@12c45c1
    //     0xde573c: ldr             x0, [x0, #0x7b0]
    // 0xde5740: StoreField: r2->field_13 = r0
    //     0xde5740: stur            w0, [x2, #0x13]
    // 0xde5744: r0 = Instance_MainAxisSize
    //     0xde5744: add             x0, PP, #0x17, lsl #12  ; [pp+0x17200] Obj!MainAxisSize@12c4601
    //     0xde5748: ldr             x0, [x0, #0x200]
    // 0xde574c: ArrayStore: r2[0] = r0  ; List_4
    //     0xde574c: stur            w0, [x2, #0x17]
    // 0xde5750: r0 = Instance_CrossAxisAlignment
    //     0xde5750: add             x0, PP, #0x7b, lsl #12  ; [pp+0x7bc40] Obj!CrossAxisAlignment@12c4521
    //     0xde5754: ldr             x0, [x0, #0xc40]
    // 0xde5758: StoreField: r2->field_1b = r0
    //     0xde5758: stur            w0, [x2, #0x1b]
    // 0xde575c: r0 = Instance_VerticalDirection
    //     0xde575c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xde5760: ldr             x0, [x0, #0x838]
    // 0xde5764: StoreField: r2->field_23 = r0
    //     0xde5764: stur            w0, [x2, #0x23]
    // 0xde5768: r0 = Instance_Clip
    //     0xde5768: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xde576c: ldr             x0, [x0, #0x840]
    // 0xde5770: StoreField: r2->field_2b = r0
    //     0xde5770: stur            w0, [x2, #0x2b]
    // 0xde5774: StoreField: r2->field_2f = rZR
    //     0xde5774: stur            xzr, [x2, #0x2f]
    // 0xde5778: ldur            x0, [fp, #-8]
    // 0xde577c: StoreField: r2->field_b = r0
    //     0xde577c: stur            w0, [x2, #0xb]
    // 0xde5780: r1 = <StackParentData>
    //     0xde5780: add             x1, PP, #0x15, lsl #12  ; [pp+0x15858] TypeArguments: <StackParentData>
    //     0xde5784: ldr             x1, [x1, #0x858]
    // 0xde5788: r0 = Positioned()
    //     0xde5788: bl              #0x8a54a4  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0xde578c: mov             x3, x0
    // 0xde5790: r0 = 0.000000
    //     0xde5790: ldr             x0, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xde5794: stur            x3, [fp, #-0x28]
    // 0xde5798: StoreField: r3->field_13 = r0
    //     0xde5798: stur            w0, [x3, #0x13]
    // 0xde579c: ArrayStore: r3[0] = r0  ; List_4
    //     0xde579c: stur            w0, [x3, #0x17]
    // 0xde57a0: StoreField: r3->field_1b = r0
    //     0xde57a0: stur            w0, [x3, #0x1b]
    // 0xde57a4: StoreField: r3->field_1f = r0
    //     0xde57a4: stur            w0, [x3, #0x1f]
    // 0xde57a8: ldur            x0, [fp, #-0x20]
    // 0xde57ac: StoreField: r3->field_b = r0
    //     0xde57ac: stur            w0, [x3, #0xb]
    // 0xde57b0: ldur            x0, [fp, #-0x10]
    // 0xde57b4: LoadField: r4 = r0->field_f
    //     0xde57b4: ldur            w4, [x0, #0xf]
    // 0xde57b8: DecompressPointer r4
    //     0xde57b8: add             x4, x4, HEAP, lsl #32
    // 0xde57bc: ldur            x2, [fp, #-0x18]
    // 0xde57c0: stur            x4, [fp, #-8]
    // 0xde57c4: r1 = Function '_onScrollUpdate@708079770':.
    //     0xde57c4: add             x1, PP, #0xcf, lsl #12  ; [pp+0xcf840] AnonymousClosure: (0xde58b8), in [package:flutter/src/cupertino/dialog.dart] _OverscrollBackgroundState::_onScrollUpdate (0xde58f4)
    //     0xde57c8: ldr             x1, [x1, #0x840]
    // 0xde57cc: r0 = AllocateClosure()
    //     0xde57cc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xde57d0: r1 = <ScrollUpdateNotification>
    //     0xde57d0: add             x1, PP, #0xcf, lsl #12  ; [pp+0xcf848] TypeArguments: <ScrollUpdateNotification>
    //     0xde57d4: ldr             x1, [x1, #0x848]
    // 0xde57d8: stur            x0, [fp, #-0x10]
    // 0xde57dc: r0 = NotificationListener()
    //     0xde57dc: bl              #0xd2ea9c  ; AllocateNotificationListenerStub -> NotificationListener<X0 bound Notification> (size=0x18)
    // 0xde57e0: mov             x3, x0
    // 0xde57e4: ldur            x0, [fp, #-0x10]
    // 0xde57e8: stur            x3, [fp, #-0x18]
    // 0xde57ec: StoreField: r3->field_13 = r0
    //     0xde57ec: stur            w0, [x3, #0x13]
    // 0xde57f0: ldur            x0, [fp, #-8]
    // 0xde57f4: StoreField: r3->field_b = r0
    //     0xde57f4: stur            w0, [x3, #0xb]
    // 0xde57f8: r1 = Null
    //     0xde57f8: mov             x1, NULL
    // 0xde57fc: r2 = 4
    //     0xde57fc: mov             x2, #4
    // 0xde5800: r0 = AllocateArray()
    //     0xde5800: bl              #0x13df928  ; AllocateArrayStub
    // 0xde5804: mov             x2, x0
    // 0xde5808: ldur            x0, [fp, #-0x28]
    // 0xde580c: stur            x2, [fp, #-8]
    // 0xde5810: StoreField: r2->field_f = r0
    //     0xde5810: stur            w0, [x2, #0xf]
    // 0xde5814: ldur            x0, [fp, #-0x18]
    // 0xde5818: StoreField: r2->field_13 = r0
    //     0xde5818: stur            w0, [x2, #0x13]
    // 0xde581c: r1 = <Widget>
    //     0xde581c: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xde5820: r0 = AllocateGrowableArray()
    //     0xde5820: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xde5824: mov             x1, x0
    // 0xde5828: ldur            x0, [fp, #-8]
    // 0xde582c: stur            x1, [fp, #-0x10]
    // 0xde5830: StoreField: r1->field_f = r0
    //     0xde5830: stur            w0, [x1, #0xf]
    // 0xde5834: r0 = 4
    //     0xde5834: mov             x0, #4
    // 0xde5838: StoreField: r1->field_b = r0
    //     0xde5838: stur            w0, [x1, #0xb]
    // 0xde583c: r0 = Stack()
    //     0xde583c: bl              #0xd1a854  ; AllocateStackStub -> Stack (size=0x20)
    // 0xde5840: r1 = Instance_AlignmentDirectional
    //     0xde5840: add             x1, PP, #0x15, lsl #12  ; [pp+0x158d8] Obj!AlignmentDirectional@129e611
    //     0xde5844: ldr             x1, [x1, #0x8d8]
    // 0xde5848: StoreField: r0->field_f = r1
    //     0xde5848: stur            w1, [x0, #0xf]
    // 0xde584c: r1 = Instance_StackFit
    //     0xde584c: add             x1, PP, #0x15, lsl #12  ; [pp+0x158e0] Obj!StackFit@12c4221
    //     0xde5850: ldr             x1, [x1, #0x8e0]
    // 0xde5854: ArrayStore: r0[0] = r1  ; List_4
    //     0xde5854: stur            w1, [x0, #0x17]
    // 0xde5858: r1 = Instance_Clip
    //     0xde5858: add             x1, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xde585c: ldr             x1, [x1, #0x850]
    // 0xde5860: StoreField: r0->field_1b = r1
    //     0xde5860: stur            w1, [x0, #0x1b]
    // 0xde5864: ldur            x1, [fp, #-0x10]
    // 0xde5868: StoreField: r0->field_b = r1
    //     0xde5868: stur            w1, [x0, #0xb]
    // 0xde586c: LeaveFrame
    //     0xde586c: mov             SP, fp
    //     0xde5870: ldp             fp, lr, [SP], #0x10
    // 0xde5874: ret
    //     0xde5874: ret             
    // 0xde5878: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde5878: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde587c: SaveReg d0
    //     0xde587c: str             q0, [SP, #-0x10]!
    // 0xde5880: stp             x2, x3, [SP, #-0x10]!
    // 0xde5884: stp             x0, x1, [SP, #-0x10]!
    // 0xde5888: r0 = AllocateDouble()
    //     0xde5888: bl              #0x13df878  ; AllocateDoubleStub
    // 0xde588c: mov             x4, x0
    // 0xde5890: ldp             x0, x1, [SP], #0x10
    // 0xde5894: ldp             x2, x3, [SP], #0x10
    // 0xde5898: RestoreReg d0
    //     0xde5898: ldr             q0, [SP], #0x10
    // 0xde589c: b               #0xde5608
    // 0xde58a0: SaveReg d0
    //     0xde58a0: str             q0, [SP, #-0x10]!
    // 0xde58a4: stp             x1, x2, [SP, #-0x10]!
    // 0xde58a8: r0 = AllocateDouble()
    //     0xde58a8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xde58ac: ldp             x1, x2, [SP], #0x10
    // 0xde58b0: RestoreReg d0
    //     0xde58b0: ldr             q0, [SP], #0x10
    // 0xde58b4: b               #0xde569c
  }
  [closure] bool _onScrollUpdate(dynamic, ScrollUpdateNotification) {
    // ** addr: 0xde58b8, size: 0x3c
    // 0xde58b8: EnterFrame
    //     0xde58b8: stp             fp, lr, [SP, #-0x10]!
    //     0xde58bc: mov             fp, SP
    // 0xde58c0: ldr             x0, [fp, #0x18]
    // 0xde58c4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xde58c4: ldur            w1, [x0, #0x17]
    // 0xde58c8: DecompressPointer r1
    //     0xde58c8: add             x1, x1, HEAP, lsl #32
    // 0xde58cc: CheckStackOverflow
    //     0xde58cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde58d0: cmp             SP, x16
    //     0xde58d4: b.ls            #0xde58ec
    // 0xde58d8: ldr             x2, [fp, #0x10]
    // 0xde58dc: r0 = _onScrollUpdate()
    //     0xde58dc: bl              #0xde58f4  ; [package:flutter/src/cupertino/dialog.dart] _OverscrollBackgroundState::_onScrollUpdate
    // 0xde58e0: LeaveFrame
    //     0xde58e0: mov             SP, fp
    //     0xde58e4: ldp             fp, lr, [SP], #0x10
    // 0xde58e8: ret
    //     0xde58e8: ret             
    // 0xde58ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde58ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde58f0: b               #0xde58d8
  }
  _ _onScrollUpdate(/* No info */) {
    // ** addr: 0xde58f4, size: 0x78
    // 0xde58f4: EnterFrame
    //     0xde58f4: stp             fp, lr, [SP, #-0x10]!
    //     0xde58f8: mov             fp, SP
    // 0xde58fc: AllocStack(0x10)
    //     0xde58fc: sub             SP, SP, #0x10
    // 0xde5900: SetupParameters(_OverscrollBackgroundState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xde5900: stur            x1, [fp, #-8]
    //     0xde5904: stur            x2, [fp, #-0x10]
    // 0xde5908: CheckStackOverflow
    //     0xde5908: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde590c: cmp             SP, x16
    //     0xde5910: b.ls            #0xde5964
    // 0xde5914: r1 = 2
    //     0xde5914: mov             x1, #2
    // 0xde5918: r0 = AllocateContext()
    //     0xde5918: bl              #0x13de838  ; AllocateContextStub
    // 0xde591c: mov             x1, x0
    // 0xde5920: ldur            x0, [fp, #-8]
    // 0xde5924: StoreField: r1->field_f = r0
    //     0xde5924: stur            w0, [x1, #0xf]
    // 0xde5928: ldur            x2, [fp, #-0x10]
    // 0xde592c: LoadField: r3 = r2->field_f
    //     0xde592c: ldur            w3, [x2, #0xf]
    // 0xde5930: DecompressPointer r3
    //     0xde5930: add             x3, x3, HEAP, lsl #32
    // 0xde5934: StoreField: r1->field_13 = r3
    //     0xde5934: stur            w3, [x1, #0x13]
    // 0xde5938: mov             x2, x1
    // 0xde593c: r1 = Function '<anonymous closure>':.
    //     0xde593c: add             x1, PP, #0xcf, lsl #12  ; [pp+0xcf850] AnonymousClosure: (0xde596c), in [package:flutter/src/cupertino/dialog.dart] _OverscrollBackgroundState::_onScrollUpdate (0xde58f4)
    //     0xde5940: ldr             x1, [x1, #0x850]
    // 0xde5944: r0 = AllocateClosure()
    //     0xde5944: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xde5948: ldur            x1, [fp, #-8]
    // 0xde594c: mov             x2, x0
    // 0xde5950: r0 = setState()
    //     0xde5950: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xde5954: r0 = false
    //     0xde5954: add             x0, NULL, #0x30  ; false
    // 0xde5958: LeaveFrame
    //     0xde5958: mov             SP, fp
    //     0xde595c: ldp             fp, lr, [SP], #0x10
    // 0xde5960: ret
    //     0xde5960: ret             
    // 0xde5964: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde5964: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde5968: b               #0xde5914
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xde596c, size: 0xb8
    // 0xde596c: EnterFrame
    //     0xde596c: stp             fp, lr, [SP, #-0x10]!
    //     0xde5970: mov             fp, SP
    // 0xde5974: d0 = 0.000000
    //     0xde5974: eor             v0.16b, v0.16b, v0.16b
    // 0xde5978: ldr             x1, [fp, #0x10]
    // 0xde597c: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xde597c: ldur            w2, [x1, #0x17]
    // 0xde5980: DecompressPointer r2
    //     0xde5980: add             x2, x2, HEAP, lsl #32
    // 0xde5984: LoadField: r1 = r2->field_f
    //     0xde5984: ldur            w1, [x2, #0xf]
    // 0xde5988: DecompressPointer r1
    //     0xde5988: add             x1, x1, HEAP, lsl #32
    // 0xde598c: LoadField: r3 = r2->field_13
    //     0xde598c: ldur            w3, [x2, #0x13]
    // 0xde5990: DecompressPointer r3
    //     0xde5990: add             x3, x3, HEAP, lsl #32
    // 0xde5994: LoadField: r2 = r3->field_7
    //     0xde5994: ldur            w2, [x3, #7]
    // 0xde5998: DecompressPointer r2
    //     0xde5998: add             x2, x2, HEAP, lsl #32
    // 0xde599c: cmp             w2, NULL
    // 0xde59a0: b.eq            #0xde5a14
    // 0xde59a4: LoadField: r4 = r3->field_f
    //     0xde59a4: ldur            w4, [x3, #0xf]
    // 0xde59a8: DecompressPointer r4
    //     0xde59a8: add             x4, x4, HEAP, lsl #32
    // 0xde59ac: cmp             w4, NULL
    // 0xde59b0: b.eq            #0xde5a18
    // 0xde59b4: LoadField: d1 = r2->field_7
    //     0xde59b4: ldur            d1, [x2, #7]
    // 0xde59b8: LoadField: d2 = r4->field_7
    //     0xde59b8: ldur            d2, [x4, #7]
    // 0xde59bc: fsub            d3, d1, d2
    // 0xde59c0: fmax            v1.2d, v3.2d, v0.2d
    // 0xde59c4: LoadField: r2 = r3->field_13
    //     0xde59c4: ldur            w2, [x3, #0x13]
    // 0xde59c8: DecompressPointer r2
    //     0xde59c8: add             x2, x2, HEAP, lsl #32
    // 0xde59cc: cmp             w2, NULL
    // 0xde59d0: b.eq            #0xde5a1c
    // 0xde59d4: LoadField: d3 = r2->field_7
    //     0xde59d4: ldur            d3, [x2, #7]
    // 0xde59d8: fmin            v4.2d, v1.2d, v3.2d
    // 0xde59dc: StoreField: r1->field_13 = d4
    //     0xde59dc: stur            d4, [x1, #0x13]
    // 0xde59e0: LoadField: r2 = r3->field_b
    //     0xde59e0: ldur            w2, [x3, #0xb]
    // 0xde59e4: DecompressPointer r2
    //     0xde59e4: add             x2, x2, HEAP, lsl #32
    // 0xde59e8: cmp             w2, NULL
    // 0xde59ec: b.eq            #0xde5a20
    // 0xde59f0: LoadField: d1 = r2->field_7
    //     0xde59f0: ldur            d1, [x2, #7]
    // 0xde59f4: fsub            d4, d2, d1
    // 0xde59f8: fmax            v1.2d, v4.2d, v0.2d
    // 0xde59fc: fmin            v0.2d, v1.2d, v3.2d
    // 0xde5a00: StoreField: r1->field_1b = d0
    //     0xde5a00: stur            d0, [x1, #0x1b]
    // 0xde5a04: r0 = Null
    //     0xde5a04: mov             x0, NULL
    // 0xde5a08: LeaveFrame
    //     0xde5a08: mov             SP, fp
    //     0xde5a0c: ldp             fp, lr, [SP], #0x10
    // 0xde5a10: ret
    //     0xde5a10: ret             
    // 0xde5a14: r0 = NullCastErrorSharedWithFPURegs()
    //     0xde5a14: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xde5a18: r0 = NullCastErrorSharedWithFPURegs()
    //     0xde5a18: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xde5a1c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xde5a1c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xde5a20: r0 = NullCastErrorSharedWithFPURegs()
    //     0xde5a20: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
}

// class id: 5491, size: 0x14, field offset: 0x14
class _ActionSheetButtonBackgroundState extends State<dynamic>
    implements _SlideTarget {

  _ build(/* No info */) {
    // ** addr: 0xde53d8, size: 0x1ac
    // 0xde53d8: EnterFrame
    //     0xde53d8: stp             fp, lr, [SP, #-0x10]!
    //     0xde53dc: mov             fp, SP
    // 0xde53e0: AllocStack(0x20)
    //     0xde53e0: sub             SP, SP, #0x20
    // 0xde53e4: SetupParameters(_ActionSheetButtonBackgroundState this /* r1 => r0, fp-0x8 */)
    //     0xde53e4: mov             x0, x1
    //     0xde53e8: stur            x1, [fp, #-8]
    // 0xde53ec: CheckStackOverflow
    //     0xde53ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde53f0: cmp             SP, x16
    //     0xde53f4: b.ls            #0xde5570
    // 0xde53f8: LoadField: r1 = r0->field_b
    //     0xde53f8: ldur            w1, [x0, #0xb]
    // 0xde53fc: DecompressPointer r1
    //     0xde53fc: add             x1, x1, HEAP, lsl #32
    // 0xde5400: cmp             w1, NULL
    // 0xde5404: b.eq            #0xde5578
    // 0xde5408: LoadField: r3 = r1->field_b
    //     0xde5408: ldur            w3, [x1, #0xb]
    // 0xde540c: DecompressPointer r3
    //     0xde540c: add             x3, x3, HEAP, lsl #32
    // 0xde5410: tbz             w3, #4, #0xde5484
    // 0xde5414: LoadField: r3 = r1->field_f
    //     0xde5414: ldur            w3, [x1, #0xf]
    // 0xde5418: DecompressPointer r3
    //     0xde5418: add             x3, x3, HEAP, lsl #32
    // 0xde541c: tbnz            w3, #4, #0xde542c
    // 0xde5420: r1 = Instance_CupertinoDynamicColor
    //     0xde5420: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4fc0] Obj!CupertinoDynamicColor@12b3cf1
    //     0xde5424: ldr             x1, [x1, #0xfc0]
    // 0xde5428: b               #0xde5434
    // 0xde542c: r1 = Instance_CupertinoDynamicColor
    //     0xde542c: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4f08] Obj!CupertinoDynamicColor@12b3d31
    //     0xde5430: ldr             x1, [x1, #0xf08]
    // 0xde5434: r0 = resolveFrom()
    //     0xde5434: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0xde5438: mov             x1, x0
    // 0xde543c: ldur            x0, [fp, #-8]
    // 0xde5440: stur            x1, [fp, #-0x18]
    // 0xde5444: LoadField: r2 = r0->field_b
    //     0xde5444: ldur            w2, [x0, #0xb]
    // 0xde5448: DecompressPointer r2
    //     0xde5448: add             x2, x2, HEAP, lsl #32
    // 0xde544c: cmp             w2, NULL
    // 0xde5450: b.eq            #0xde557c
    // 0xde5454: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xde5454: ldur            w3, [x2, #0x17]
    // 0xde5458: DecompressPointer r3
    //     0xde5458: add             x3, x3, HEAP, lsl #32
    // 0xde545c: stur            x3, [fp, #-0x10]
    // 0xde5460: r0 = ColoredBox()
    //     0xde5460: bl              #0xd1a914  ; AllocateColoredBoxStub -> ColoredBox (size=0x18)
    // 0xde5464: mov             x1, x0
    // 0xde5468: ldur            x0, [fp, #-0x18]
    // 0xde546c: StoreField: r1->field_f = r0
    //     0xde546c: stur            w0, [x1, #0xf]
    // 0xde5470: r0 = true
    //     0xde5470: add             x0, NULL, #0x20  ; true
    // 0xde5474: StoreField: r1->field_13 = r0
    //     0xde5474: stur            w0, [x1, #0x13]
    // 0xde5478: ldur            x0, [fp, #-0x10]
    // 0xde547c: StoreField: r1->field_b = r0
    //     0xde547c: stur            w0, [x1, #0xb]
    // 0xde5480: b               #0xde5540
    // 0xde5484: LoadField: r0 = r1->field_f
    //     0xde5484: ldur            w0, [x1, #0xf]
    // 0xde5488: DecompressPointer r0
    //     0xde5488: add             x0, x0, HEAP, lsl #32
    // 0xde548c: tbnz            w0, #4, #0xde549c
    // 0xde5490: r1 = Instance_CupertinoDynamicColor
    //     0xde5490: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4fc8] Obj!CupertinoDynamicColor@12b3cb1
    //     0xde5494: ldr             x1, [x1, #0xfc8]
    // 0xde5498: b               #0xde54a4
    // 0xde549c: r1 = Instance_CupertinoDynamicColor
    //     0xde549c: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4fd0] Obj!CupertinoDynamicColor@12b3c71
    //     0xde54a0: ldr             x1, [x1, #0xfd0]
    // 0xde54a4: ldur            x0, [fp, #-8]
    // 0xde54a8: r0 = resolveFrom()
    //     0xde54a8: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0xde54ac: stur            x0, [fp, #-0x10]
    // 0xde54b0: r0 = BoxDecoration()
    //     0xde54b0: bl              #0x8a721c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0xde54b4: mov             x1, x0
    // 0xde54b8: ldur            x0, [fp, #-0x10]
    // 0xde54bc: stur            x1, [fp, #-0x18]
    // 0xde54c0: StoreField: r1->field_7 = r0
    //     0xde54c0: stur            w0, [x1, #7]
    // 0xde54c4: r0 = Instance_BoxShape
    //     0xde54c4: add             x0, PP, #0x17, lsl #12  ; [pp+0x171f8] Obj!BoxShape@12c4921
    //     0xde54c8: ldr             x0, [x0, #0x1f8]
    // 0xde54cc: StoreField: r1->field_23 = r0
    //     0xde54cc: stur            w0, [x1, #0x23]
    // 0xde54d0: ldur            x0, [fp, #-8]
    // 0xde54d4: LoadField: r2 = r0->field_b
    //     0xde54d4: ldur            w2, [x0, #0xb]
    // 0xde54d8: DecompressPointer r2
    //     0xde54d8: add             x2, x2, HEAP, lsl #32
    // 0xde54dc: cmp             w2, NULL
    // 0xde54e0: b.eq            #0xde5580
    // 0xde54e4: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xde54e4: ldur            w3, [x2, #0x17]
    // 0xde54e8: DecompressPointer r3
    //     0xde54e8: add             x3, x3, HEAP, lsl #32
    // 0xde54ec: stur            x3, [fp, #-0x10]
    // 0xde54f0: r0 = DecoratedBox()
    //     0xde54f0: bl              #0xd66318  ; AllocateDecoratedBoxStub -> DecoratedBox (size=0x18)
    // 0xde54f4: mov             x1, x0
    // 0xde54f8: ldur            x0, [fp, #-0x18]
    // 0xde54fc: stur            x1, [fp, #-0x20]
    // 0xde5500: StoreField: r1->field_f = r0
    //     0xde5500: stur            w0, [x1, #0xf]
    // 0xde5504: r0 = Instance_DecorationPosition
    //     0xde5504: add             x0, PP, #0x80, lsl #12  ; [pp+0x80ef0] Obj!DecorationPosition@12c4381
    //     0xde5508: ldr             x0, [x0, #0xef0]
    // 0xde550c: StoreField: r1->field_13 = r0
    //     0xde550c: stur            w0, [x1, #0x13]
    // 0xde5510: ldur            x0, [fp, #-0x10]
    // 0xde5514: StoreField: r1->field_b = r0
    //     0xde5514: stur            w0, [x1, #0xb]
    // 0xde5518: r0 = ClipRSuperellipse()
    //     0xde5518: bl              #0xde4e24  ; AllocateClipRSuperellipseStub -> ClipRSuperellipse (size=0x1c)
    // 0xde551c: mov             x1, x0
    // 0xde5520: r0 = Instance_BorderRadius
    //     0xde5520: add             x0, PP, #0xd4, lsl #12  ; [pp+0xd4fd8] Obj!BorderRadius@129e3f1
    //     0xde5524: ldr             x0, [x0, #0xfd8]
    // 0xde5528: StoreField: r1->field_f = r0
    //     0xde5528: stur            w0, [x1, #0xf]
    // 0xde552c: r0 = Instance_Clip
    //     0xde552c: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e6f0] Obj!Clip@12c8101
    //     0xde5530: ldr             x0, [x0, #0x6f0]
    // 0xde5534: ArrayStore: r1[0] = r0  ; List_4
    //     0xde5534: stur            w0, [x1, #0x17]
    // 0xde5538: ldur            x0, [fp, #-0x20]
    // 0xde553c: StoreField: r1->field_b = r0
    //     0xde553c: stur            w0, [x1, #0xb]
    // 0xde5540: ldur            x0, [fp, #-8]
    // 0xde5544: stur            x1, [fp, #-0x10]
    // 0xde5548: r0 = MetaData()
    //     0xde5548: bl              #0xde5108  ; AllocateMetaDataStub -> MetaData (size=0x18)
    // 0xde554c: ldur            x1, [fp, #-8]
    // 0xde5550: StoreField: r0->field_f = r1
    //     0xde5550: stur            w1, [x0, #0xf]
    // 0xde5554: r1 = Instance_HitTestBehavior
    //     0xde5554: ldr             x1, [PP, #0x5368]  ; [pp+0x5368] Obj!HitTestBehavior@12c43a1
    // 0xde5558: StoreField: r0->field_13 = r1
    //     0xde5558: stur            w1, [x0, #0x13]
    // 0xde555c: ldur            x1, [fp, #-0x10]
    // 0xde5560: StoreField: r0->field_b = r1
    //     0xde5560: stur            w1, [x0, #0xb]
    // 0xde5564: LeaveFrame
    //     0xde5564: mov             SP, fp
    //     0xde5568: ldp             fp, lr, [SP], #0x10
    // 0xde556c: ret
    //     0xde556c: ret             
    // 0xde5570: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde5570: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde5574: b               #0xde53f8
    // 0xde5578: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde5578: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde557c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde557c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde5580: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde5580: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didEnter(/* No info */) {
    // ** addr: 0x121b1bc, size: 0x88
    // 0x121b1bc: EnterFrame
    //     0x121b1bc: stp             fp, lr, [SP, #-0x10]!
    //     0x121b1c0: mov             fp, SP
    // 0x121b1c4: AllocStack(0x20)
    //     0x121b1c4: sub             SP, SP, #0x20
    // 0x121b1c8: SetupParameters(_ActionSheetButtonBackgroundState this /* r1 => r0 */, dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r1, fp-0x10 */)
    //     0x121b1c8: mov             x0, x1
    //     0x121b1cc: mov             x1, x3
    //     0x121b1d0: stur            x2, [fp, #-8]
    //     0x121b1d4: stur            x3, [fp, #-0x10]
    // 0x121b1d8: CheckStackOverflow
    //     0x121b1d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x121b1dc: cmp             SP, x16
    //     0x121b1e0: b.ls            #0x121b234
    // 0x121b1e4: LoadField: r3 = r0->field_b
    //     0x121b1e4: ldur            w3, [x0, #0xb]
    // 0x121b1e8: DecompressPointer r3
    //     0x121b1e8: add             x3, x3, HEAP, lsl #32
    // 0x121b1ec: cmp             w3, NULL
    // 0x121b1f0: b.eq            #0x121b23c
    // 0x121b1f4: LoadField: r0 = r3->field_13
    //     0x121b1f4: ldur            w0, [x3, #0x13]
    // 0x121b1f8: DecompressPointer r0
    //     0x121b1f8: add             x0, x0, HEAP, lsl #32
    // 0x121b1fc: cmp             w0, NULL
    // 0x121b200: b.eq            #0x121b240
    // 0x121b204: r16 = true
    //     0x121b204: add             x16, NULL, #0x20  ; true
    // 0x121b208: stp             x16, x0, [SP]
    // 0x121b20c: ClosureCall
    //     0x121b20c: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x121b210: ldur            x2, [x0, #0x1f]
    //     0x121b214: blr             x2
    // 0x121b218: ldur            x0, [fp, #-8]
    // 0x121b21c: tbz             w0, #4, #0x121b224
    // 0x121b220: r0 = selectionClick()
    //     0x121b220: bl              #0x859550  ; [package:flutter/src/services/haptic_feedback.dart] HapticFeedback::selectionClick
    // 0x121b224: ldur            x0, [fp, #-0x10]
    // 0x121b228: LeaveFrame
    //     0x121b228: mov             SP, fp
    //     0x121b22c: ldp             fp, lr, [SP], #0x10
    // 0x121b230: ret
    //     0x121b230: ret             
    // 0x121b234: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x121b234: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x121b238: b               #0x121b1e4
    // 0x121b23c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x121b23c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x121b240: r0 = NullErrorSharedWithoutFPURegs()
    //     0x121b240: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ didLeave(/* No info */) {
    // ** addr: 0x12492a0, size: 0x70
    // 0x12492a0: EnterFrame
    //     0x12492a0: stp             fp, lr, [SP, #-0x10]!
    //     0x12492a4: mov             fp, SP
    // 0x12492a8: AllocStack(0x10)
    //     0x12492a8: sub             SP, SP, #0x10
    // 0x12492ac: CheckStackOverflow
    //     0x12492ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12492b0: cmp             SP, x16
    //     0x12492b4: b.ls            #0x1249300
    // 0x12492b8: LoadField: r0 = r1->field_b
    //     0x12492b8: ldur            w0, [x1, #0xb]
    // 0x12492bc: DecompressPointer r0
    //     0x12492bc: add             x0, x0, HEAP, lsl #32
    // 0x12492c0: cmp             w0, NULL
    // 0x12492c4: b.eq            #0x1249308
    // 0x12492c8: LoadField: r1 = r0->field_13
    //     0x12492c8: ldur            w1, [x0, #0x13]
    // 0x12492cc: DecompressPointer r1
    //     0x12492cc: add             x1, x1, HEAP, lsl #32
    // 0x12492d0: cmp             w1, NULL
    // 0x12492d4: b.eq            #0x124930c
    // 0x12492d8: r16 = false
    //     0x12492d8: add             x16, NULL, #0x30  ; false
    // 0x12492dc: stp             x16, x1, [SP]
    // 0x12492e0: mov             x0, x1
    // 0x12492e4: ClosureCall
    //     0x12492e4: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x12492e8: ldur            x2, [x0, #0x1f]
    //     0x12492ec: blr             x2
    // 0x12492f0: r0 = Null
    //     0x12492f0: mov             x0, NULL
    // 0x12492f4: LeaveFrame
    //     0x12492f4: mov             SP, fp
    //     0x12492f8: ldp             fp, lr, [SP], #0x10
    // 0x12492fc: ret
    //     0x12492fc: ret             
    // 0x1249300: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1249300: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1249304: b               #0x12492b8
    // 0x1249308: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1249308: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x124930c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x124930c: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
}

// class id: 5492, size: 0x1c, field offset: 0x14
class _CupertinoActionSheetActionState extends State<dynamic>
    implements _SlideTarget {

  late final Map<Type, Action<Intent>> _actionMap; // offset: 0x18

  _ build(/* No info */) {
    // ** addr: 0xde4e7c, size: 0x28c
    // 0xde4e7c: EnterFrame
    //     0xde4e7c: stp             fp, lr, [SP, #-0x10]!
    //     0xde4e80: mov             fp, SP
    // 0xde4e84: AllocStack(0x50)
    //     0xde4e84: sub             SP, SP, #0x50
    // 0xde4e88: SetupParameters(_CupertinoActionSheetActionState this /* r1 => r0, fp-0x8 */)
    //     0xde4e88: mov             x0, x1
    //     0xde4e8c: stur            x1, [fp, #-8]
    // 0xde4e90: CheckStackOverflow
    //     0xde4e90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde4e94: cmp             SP, x16
    //     0xde4e98: b.ls            #0xde50f4
    // 0xde4e9c: LoadField: r1 = r0->field_b
    //     0xde4e9c: ldur            w1, [x0, #0xb]
    // 0xde4ea0: DecompressPointer r1
    //     0xde4ea0: add             x1, x1, HEAP, lsl #32
    // 0xde4ea4: cmp             w1, NULL
    // 0xde4ea8: b.eq            #0xde50fc
    // 0xde4eac: mov             x1, x0
    // 0xde4eb0: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xde4eb0: ldur            w0, [x1, #0x17]
    // 0xde4eb4: DecompressPointer r0
    //     0xde4eb4: add             x0, x0, HEAP, lsl #32
    // 0xde4eb8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xde4ebc: cmp             w0, w16
    // 0xde4ec0: b.ne            #0xde4ed0
    // 0xde4ec4: r2 = _actionMap
    //     0xde4ec4: add             x2, PP, #0xd4, lsl #12  ; [pp+0xd4d88] Field <_CupertinoActionSheetActionState@708079770._actionMap@708079770>: late final (offset: 0x18)
    //     0xde4ec8: ldr             x2, [x2, #0xd88]
    // 0xde4ecc: r0 = InitLateFinalInstanceField()
    //     0xde4ecc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xde4ed0: mov             x2, x0
    // 0xde4ed4: ldur            x0, [fp, #-8]
    // 0xde4ed8: stur            x2, [fp, #-0x18]
    // 0xde4edc: LoadField: r1 = r0->field_b
    //     0xde4edc: ldur            w1, [x0, #0xb]
    // 0xde4ee0: DecompressPointer r1
    //     0xde4ee0: add             x1, x1, HEAP, lsl #32
    // 0xde4ee4: cmp             w1, NULL
    // 0xde4ee8: b.eq            #0xde5100
    // 0xde4eec: LoadField: r3 = r1->field_b
    //     0xde4eec: ldur            w3, [x1, #0xb]
    // 0xde4ef0: DecompressPointer r3
    //     0xde4ef0: add             x3, x3, HEAP, lsl #32
    // 0xde4ef4: stur            x3, [fp, #-0x10]
    // 0xde4ef8: LoadField: r4 = r0->field_13
    //     0xde4ef8: ldur            w4, [x0, #0x13]
    // 0xde4efc: DecompressPointer r4
    //     0xde4efc: add             x4, x4, HEAP, lsl #32
    // 0xde4f00: tbnz            w4, #4, #0xde4fb0
    // 0xde4f04: mov             x1, x0
    // 0xde4f08: r0 = effectiveFocusBackgroundColor()
    //     0xde4f08: bl              #0xde5120  ; [package:flutter/src/cupertino/dialog.dart] _CupertinoActionSheetActionState::effectiveFocusBackgroundColor
    // 0xde4f0c: stur            x0, [fp, #-0x20]
    // 0xde4f10: r0 = BoxDecoration()
    //     0xde4f10: bl              #0x8a721c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0xde4f14: mov             x1, x0
    // 0xde4f18: ldur            x0, [fp, #-0x20]
    // 0xde4f1c: stur            x1, [fp, #-0x30]
    // 0xde4f20: StoreField: r1->field_7 = r0
    //     0xde4f20: stur            w0, [x1, #7]
    // 0xde4f24: r0 = Instance_BoxShape
    //     0xde4f24: add             x0, PP, #0x17, lsl #12  ; [pp+0x171f8] Obj!BoxShape@12c4921
    //     0xde4f28: ldr             x0, [x0, #0x1f8]
    // 0xde4f2c: StoreField: r1->field_23 = r0
    //     0xde4f2c: stur            w0, [x1, #0x23]
    // 0xde4f30: ldur            x2, [fp, #-8]
    // 0xde4f34: LoadField: r0 = r2->field_b
    //     0xde4f34: ldur            w0, [x2, #0xb]
    // 0xde4f38: DecompressPointer r0
    //     0xde4f38: add             x0, x0, HEAP, lsl #32
    // 0xde4f3c: cmp             w0, NULL
    // 0xde4f40: b.eq            #0xde5104
    // 0xde4f44: LoadField: r3 = r0->field_13
    //     0xde4f44: ldur            w3, [x0, #0x13]
    // 0xde4f48: DecompressPointer r3
    //     0xde4f48: add             x3, x3, HEAP, lsl #32
    // 0xde4f4c: stur            x3, [fp, #-0x28]
    // 0xde4f50: LoadField: r4 = r0->field_23
    //     0xde4f50: ldur            w4, [x0, #0x23]
    // 0xde4f54: DecompressPointer r4
    //     0xde4f54: add             x4, x4, HEAP, lsl #32
    // 0xde4f58: stur            x4, [fp, #-0x20]
    // 0xde4f5c: r0 = _ActionSheetActionContent()
    //     0xde4f5c: bl              #0xde5114  ; Allocate_ActionSheetActionContentStub -> _ActionSheetActionContent (size=0x18)
    // 0xde4f60: mov             x1, x0
    // 0xde4f64: ldur            x0, [fp, #-0x28]
    // 0xde4f68: stur            x1, [fp, #-0x38]
    // 0xde4f6c: StoreField: r1->field_b = r0
    //     0xde4f6c: stur            w0, [x1, #0xb]
    // 0xde4f70: r0 = false
    //     0xde4f70: add             x0, NULL, #0x30  ; false
    // 0xde4f74: StoreField: r1->field_f = r0
    //     0xde4f74: stur            w0, [x1, #0xf]
    // 0xde4f78: ldur            x2, [fp, #-0x20]
    // 0xde4f7c: StoreField: r1->field_13 = r2
    //     0xde4f7c: stur            w2, [x1, #0x13]
    // 0xde4f80: r0 = DecoratedBox()
    //     0xde4f80: bl              #0xd66318  ; AllocateDecoratedBoxStub -> DecoratedBox (size=0x18)
    // 0xde4f84: mov             x1, x0
    // 0xde4f88: ldur            x0, [fp, #-0x30]
    // 0xde4f8c: StoreField: r1->field_f = r0
    //     0xde4f8c: stur            w0, [x1, #0xf]
    // 0xde4f90: r0 = Instance_DecorationPosition
    //     0xde4f90: add             x0, PP, #0x80, lsl #12  ; [pp+0x80ef0] Obj!DecorationPosition@12c4381
    //     0xde4f94: ldr             x0, [x0, #0xef0]
    // 0xde4f98: StoreField: r1->field_13 = r0
    //     0xde4f98: stur            w0, [x1, #0x13]
    // 0xde4f9c: ldur            x0, [fp, #-0x38]
    // 0xde4fa0: StoreField: r1->field_b = r0
    //     0xde4fa0: stur            w0, [x1, #0xb]
    // 0xde4fa4: mov             x3, x1
    // 0xde4fa8: r0 = false
    //     0xde4fa8: add             x0, NULL, #0x30  ; false
    // 0xde4fac: b               #0xde4fec
    // 0xde4fb0: LoadField: r0 = r1->field_13
    //     0xde4fb0: ldur            w0, [x1, #0x13]
    // 0xde4fb4: DecompressPointer r0
    //     0xde4fb4: add             x0, x0, HEAP, lsl #32
    // 0xde4fb8: stur            x0, [fp, #-0x28]
    // 0xde4fbc: LoadField: r2 = r1->field_23
    //     0xde4fbc: ldur            w2, [x1, #0x23]
    // 0xde4fc0: DecompressPointer r2
    //     0xde4fc0: add             x2, x2, HEAP, lsl #32
    // 0xde4fc4: stur            x2, [fp, #-0x20]
    // 0xde4fc8: r0 = _ActionSheetActionContent()
    //     0xde4fc8: bl              #0xde5114  ; Allocate_ActionSheetActionContentStub -> _ActionSheetActionContent (size=0x18)
    // 0xde4fcc: mov             x1, x0
    // 0xde4fd0: ldur            x0, [fp, #-0x28]
    // 0xde4fd4: StoreField: r1->field_b = r0
    //     0xde4fd4: stur            w0, [x1, #0xb]
    // 0xde4fd8: r0 = false
    //     0xde4fd8: add             x0, NULL, #0x30  ; false
    // 0xde4fdc: StoreField: r1->field_f = r0
    //     0xde4fdc: stur            w0, [x1, #0xf]
    // 0xde4fe0: ldur            x2, [fp, #-0x20]
    // 0xde4fe4: StoreField: r1->field_13 = r2
    //     0xde4fe4: stur            w2, [x1, #0x13]
    // 0xde4fe8: mov             x3, x1
    // 0xde4fec: ldur            x2, [fp, #-8]
    // 0xde4ff0: ldur            x1, [fp, #-0x18]
    // 0xde4ff4: stur            x3, [fp, #-0x20]
    // 0xde4ff8: r0 = Semantics()
    //     0xde4ff8: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xde4ffc: stur            x0, [fp, #-0x28]
    // 0xde5000: r16 = true
    //     0xde5000: add             x16, NULL, #0x20  ; true
    // 0xde5004: ldur            lr, [fp, #-0x10]
    // 0xde5008: stp             lr, x16, [SP, #8]
    // 0xde500c: ldur            x16, [fp, #-0x20]
    // 0xde5010: str             x16, [SP]
    // 0xde5014: mov             x1, x0
    // 0xde5018: r4 = const [0, 0x4, 0x3, 0x1, button, 0x1, child, 0x3, onTap, 0x2, null]
    //     0xde5018: add             x4, PP, #0xab, lsl #12  ; [pp+0xab2e8] List(11) [0, 0x4, 0x3, 0x1, "button", 0x1, "child", 0x3, "onTap", 0x2, Null]
    //     0xde501c: ldr             x4, [x4, #0x2e8]
    // 0xde5020: r0 = Semantics()
    //     0xde5020: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xde5024: r0 = FocusableActionDetector()
    //     0xde5024: bl              #0xd11ab4  ; AllocateFocusableActionDetectorStub -> FocusableActionDetector (size=0x40)
    // 0xde5028: mov             x3, x0
    // 0xde502c: r0 = true
    //     0xde502c: add             x0, NULL, #0x20  ; true
    // 0xde5030: stur            x3, [fp, #-0x10]
    // 0xde5034: StoreField: r3->field_b = r0
    //     0xde5034: stur            w0, [x3, #0xb]
    // 0xde5038: r1 = false
    //     0xde5038: add             x1, NULL, #0x30  ; false
    // 0xde503c: StoreField: r3->field_13 = r1
    //     0xde503c: stur            w1, [x3, #0x13]
    // 0xde5040: ArrayStore: r3[0] = r0  ; List_4
    //     0xde5040: stur            w0, [x3, #0x17]
    // 0xde5044: StoreField: r3->field_1b = r0
    //     0xde5044: stur            w0, [x3, #0x1b]
    // 0xde5048: ldur            x1, [fp, #-0x18]
    // 0xde504c: StoreField: r3->field_1f = r1
    //     0xde504c: stur            w1, [x3, #0x1f]
    // 0xde5050: ldur            x2, [fp, #-8]
    // 0xde5054: r1 = Function '_onShowFocusHighlight@708079770':.
    //     0xde5054: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4d90] AnonymousClosure: (0xde51b8), in [package:flutter/src/cupertino/dialog.dart] _CupertinoActionSheetActionState::_onShowFocusHighlight (0xde51f4)
    //     0xde5058: ldr             x1, [x1, #0xd90]
    // 0xde505c: r0 = AllocateClosure()
    //     0xde505c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xde5060: mov             x1, x0
    // 0xde5064: ldur            x0, [fp, #-0x10]
    // 0xde5068: StoreField: r0->field_27 = r1
    //     0xde5068: stur            w1, [x0, #0x27]
    // 0xde506c: r1 = Instance__DeferringMouseCursor
    //     0xde506c: ldr             x1, [PP, #0x2208]  ; [pp+0x2208] Obj!_DeferringMouseCursor@12b3241
    // 0xde5070: StoreField: r0->field_33 = r1
    //     0xde5070: stur            w1, [x0, #0x33]
    // 0xde5074: r2 = true
    //     0xde5074: add             x2, NULL, #0x20  ; true
    // 0xde5078: StoreField: r0->field_37 = r2
    //     0xde5078: stur            w2, [x0, #0x37]
    // 0xde507c: ldur            x3, [fp, #-0x28]
    // 0xde5080: StoreField: r0->field_3b = r3
    //     0xde5080: stur            w3, [x0, #0x3b]
    // 0xde5084: r0 = ConstrainedBox()
    //     0xde5084: bl              #0xd0a588  ; AllocateConstrainedBoxStub -> ConstrainedBox (size=0x14)
    // 0xde5088: mov             x1, x0
    // 0xde508c: r0 = Instance_BoxConstraints
    //     0xde508c: add             x0, PP, #0xd4, lsl #12  ; [pp+0xd4d98] Obj!BoxConstraints@129c2c1
    //     0xde5090: ldr             x0, [x0, #0xd98]
    // 0xde5094: stur            x1, [fp, #-0x18]
    // 0xde5098: StoreField: r1->field_f = r0
    //     0xde5098: stur            w0, [x1, #0xf]
    // 0xde509c: ldur            x0, [fp, #-0x10]
    // 0xde50a0: StoreField: r1->field_b = r0
    //     0xde50a0: stur            w0, [x1, #0xb]
    // 0xde50a4: r0 = MetaData()
    //     0xde50a4: bl              #0xde5108  ; AllocateMetaDataStub -> MetaData (size=0x18)
    // 0xde50a8: mov             x1, x0
    // 0xde50ac: ldur            x0, [fp, #-8]
    // 0xde50b0: stur            x1, [fp, #-0x10]
    // 0xde50b4: StoreField: r1->field_f = r0
    //     0xde50b4: stur            w0, [x1, #0xf]
    // 0xde50b8: r0 = Instance_HitTestBehavior
    //     0xde50b8: add             x0, PP, #0x15, lsl #12  ; [pp+0x155c0] Obj!HitTestBehavior@12c43c1
    //     0xde50bc: ldr             x0, [x0, #0x5c0]
    // 0xde50c0: StoreField: r1->field_13 = r0
    //     0xde50c0: stur            w0, [x1, #0x13]
    // 0xde50c4: ldur            x0, [fp, #-0x18]
    // 0xde50c8: StoreField: r1->field_b = r0
    //     0xde50c8: stur            w0, [x1, #0xb]
    // 0xde50cc: r0 = MouseRegion()
    //     0xde50cc: bl              #0xd1c8fc  ; AllocateMouseRegionStub -> MouseRegion (size=0x28)
    // 0xde50d0: r1 = Instance__DeferringMouseCursor
    //     0xde50d0: ldr             x1, [PP, #0x2208]  ; [pp+0x2208] Obj!_DeferringMouseCursor@12b3241
    // 0xde50d4: StoreField: r0->field_1b = r1
    //     0xde50d4: stur            w1, [x0, #0x1b]
    // 0xde50d8: r1 = true
    //     0xde50d8: add             x1, NULL, #0x20  ; true
    // 0xde50dc: StoreField: r0->field_1f = r1
    //     0xde50dc: stur            w1, [x0, #0x1f]
    // 0xde50e0: ldur            x1, [fp, #-0x10]
    // 0xde50e4: StoreField: r0->field_b = r1
    //     0xde50e4: stur            w1, [x0, #0xb]
    // 0xde50e8: LeaveFrame
    //     0xde50e8: mov             SP, fp
    //     0xde50ec: ldp             fp, lr, [SP], #0x10
    // 0xde50f0: ret
    //     0xde50f0: ret             
    // 0xde50f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde50f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde50f8: b               #0xde4e9c
    // 0xde50fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde50fc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde5100: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde5100: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde5104: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde5104: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ effectiveFocusBackgroundColor(/* No info */) {
    // ** addr: 0xde5120, size: 0x98
    // 0xde5120: EnterFrame
    //     0xde5120: stp             fp, lr, [SP, #-0x10]!
    //     0xde5124: mov             fp, SP
    // 0xde5128: CheckStackOverflow
    //     0xde5128: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde512c: cmp             SP, x16
    //     0xde5130: b.ls            #0xde51a8
    // 0xde5134: LoadField: r0 = r1->field_b
    //     0xde5134: ldur            w0, [x1, #0xb]
    // 0xde5138: DecompressPointer r0
    //     0xde5138: add             x0, x0, HEAP, lsl #32
    // 0xde513c: cmp             w0, NULL
    // 0xde5140: b.eq            #0xde51b0
    // 0xde5144: LoadField: r0 = r1->field_f
    //     0xde5144: ldur            w0, [x1, #0xf]
    // 0xde5148: DecompressPointer r0
    //     0xde5148: add             x0, x0, HEAP, lsl #32
    // 0xde514c: cmp             w0, NULL
    // 0xde5150: b.eq            #0xde51b4
    // 0xde5154: mov             x1, x0
    // 0xde5158: r0 = brightnessOf()
    //     0xde5158: bl              #0xd776f8  ; [package:flutter/src/cupertino/theme.dart] CupertinoTheme::brightnessOf
    // 0xde515c: r16 = Instance_Brightness
    //     0xde515c: ldr             x16, [PP, #0x6da0]  ; [pp+0x6da0] Obj!Brightness@12c71c1
    // 0xde5160: cmp             w0, w16
    // 0xde5164: b.ne            #0xde5174
    // 0xde5168: d0 = 0.120000
    //     0xde5168: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xde516c: ldr             d0, [x17, #0xc40]
    // 0xde5170: b               #0xde517c
    // 0xde5174: d0 = 0.260000
    //     0xde5174: add             x17, PP, #0xab, lsl #12  ; [pp+0xab918] IMM: double(0.26) from 0x3fd0a3d70a3d70a4
    //     0xde5178: ldr             d0, [x17, #0x918]
    // 0xde517c: r1 = Instance_Color
    //     0xde517c: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4da8] Obj!Color@12a2a91
    //     0xde5180: ldr             x1, [x1, #0xda8]
    // 0xde5184: r0 = withOpacity()
    //     0xde5184: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xde5188: mov             x2, x0
    // 0xde518c: r1 = Null
    //     0xde518c: mov             x1, NULL
    // 0xde5190: r0 = HSLColor.fromColor()
    //     0xde5190: bl              #0xd43b8c  ; [package:flutter/src/painting/colors.dart] HSLColor::HSLColor.fromColor
    // 0xde5194: mov             x1, x0
    // 0xde5198: r0 = toColor()
    //     0xde5198: bl              #0xd43270  ; [package:flutter/src/painting/colors.dart] HSLColor::toColor
    // 0xde519c: LeaveFrame
    //     0xde519c: mov             SP, fp
    //     0xde51a0: ldp             fp, lr, [SP], #0x10
    // 0xde51a4: ret
    //     0xde51a4: ret             
    // 0xde51a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde51a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde51ac: b               #0xde5134
    // 0xde51b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde51b0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde51b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde51b4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _onShowFocusHighlight(dynamic, bool) {
    // ** addr: 0xde51b8, size: 0x3c
    // 0xde51b8: EnterFrame
    //     0xde51b8: stp             fp, lr, [SP, #-0x10]!
    //     0xde51bc: mov             fp, SP
    // 0xde51c0: ldr             x0, [fp, #0x18]
    // 0xde51c4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xde51c4: ldur            w1, [x0, #0x17]
    // 0xde51c8: DecompressPointer r1
    //     0xde51c8: add             x1, x1, HEAP, lsl #32
    // 0xde51cc: CheckStackOverflow
    //     0xde51cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde51d0: cmp             SP, x16
    //     0xde51d4: b.ls            #0xde51ec
    // 0xde51d8: ldr             x2, [fp, #0x10]
    // 0xde51dc: r0 = _onShowFocusHighlight()
    //     0xde51dc: bl              #0xde51f4  ; [package:flutter/src/cupertino/dialog.dart] _CupertinoActionSheetActionState::_onShowFocusHighlight
    // 0xde51e0: LeaveFrame
    //     0xde51e0: mov             SP, fp
    //     0xde51e4: ldp             fp, lr, [SP], #0x10
    // 0xde51e8: ret
    //     0xde51e8: ret             
    // 0xde51ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde51ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde51f0: b               #0xde51d8
  }
  _ _onShowFocusHighlight(/* No info */) {
    // ** addr: 0xde51f4, size: 0x70
    // 0xde51f4: EnterFrame
    //     0xde51f4: stp             fp, lr, [SP, #-0x10]!
    //     0xde51f8: mov             fp, SP
    // 0xde51fc: AllocStack(0x10)
    //     0xde51fc: sub             SP, SP, #0x10
    // 0xde5200: SetupParameters(_CupertinoActionSheetActionState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xde5200: stur            x1, [fp, #-8]
    //     0xde5204: stur            x2, [fp, #-0x10]
    // 0xde5208: CheckStackOverflow
    //     0xde5208: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde520c: cmp             SP, x16
    //     0xde5210: b.ls            #0xde525c
    // 0xde5214: r1 = 2
    //     0xde5214: mov             x1, #2
    // 0xde5218: r0 = AllocateContext()
    //     0xde5218: bl              #0x13de838  ; AllocateContextStub
    // 0xde521c: mov             x1, x0
    // 0xde5220: ldur            x0, [fp, #-8]
    // 0xde5224: StoreField: r1->field_f = r0
    //     0xde5224: stur            w0, [x1, #0xf]
    // 0xde5228: ldur            x2, [fp, #-0x10]
    // 0xde522c: StoreField: r1->field_13 = r2
    //     0xde522c: stur            w2, [x1, #0x13]
    // 0xde5230: mov             x2, x1
    // 0xde5234: r1 = Function '<anonymous closure>':.
    //     0xde5234: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4da0] AnonymousClosure: (0xde5264), in [package:flutter/src/cupertino/dialog.dart] _CupertinoActionSheetActionState::_onShowFocusHighlight (0xde51f4)
    //     0xde5238: ldr             x1, [x1, #0xda0]
    // 0xde523c: r0 = AllocateClosure()
    //     0xde523c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xde5240: ldur            x1, [fp, #-8]
    // 0xde5244: mov             x2, x0
    // 0xde5248: r0 = setState()
    //     0xde5248: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xde524c: r0 = Null
    //     0xde524c: mov             x0, NULL
    // 0xde5250: LeaveFrame
    //     0xde5250: mov             SP, fp
    //     0xde5254: ldp             fp, lr, [SP], #0x10
    // 0xde5258: ret
    //     0xde5258: ret             
    // 0xde525c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde525c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde5260: b               #0xde5214
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xde5264, size: 0x28
    // 0xde5264: ldr             x1, [SP]
    // 0xde5268: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xde5268: ldur            w2, [x1, #0x17]
    // 0xde526c: DecompressPointer r2
    //     0xde526c: add             x2, x2, HEAP, lsl #32
    // 0xde5270: LoadField: r1 = r2->field_f
    //     0xde5270: ldur            w1, [x2, #0xf]
    // 0xde5274: DecompressPointer r1
    //     0xde5274: add             x1, x1, HEAP, lsl #32
    // 0xde5278: LoadField: r3 = r2->field_13
    //     0xde5278: ldur            w3, [x2, #0x13]
    // 0xde527c: DecompressPointer r3
    //     0xde527c: add             x3, x3, HEAP, lsl #32
    // 0xde5280: StoreField: r1->field_13 = r3
    //     0xde5280: stur            w3, [x1, #0x13]
    // 0xde5284: r0 = Null
    //     0xde5284: mov             x0, NULL
    // 0xde5288: ret
    //     0xde5288: ret             
  }
  Map<Type, Action<Intent>> _actionMap(_CupertinoActionSheetActionState) {
    // ** addr: 0xde528c, size: 0x14c
    // 0xde528c: EnterFrame
    //     0xde528c: stp             fp, lr, [SP, #-0x10]!
    //     0xde5290: mov             fp, SP
    // 0xde5294: AllocStack(0x28)
    //     0xde5294: sub             SP, SP, #0x28
    // 0xde5298: CheckStackOverflow
    //     0xde5298: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde529c: cmp             SP, x16
    //     0xde52a0: b.ls            #0xde53d0
    // 0xde52a4: r1 = Null
    //     0xde52a4: mov             x1, NULL
    // 0xde52a8: r2 = 4
    //     0xde52a8: mov             x2, #4
    // 0xde52ac: r0 = AllocateArray()
    //     0xde52ac: bl              #0x13df928  ; AllocateArrayStub
    // 0xde52b0: mov             x1, x0
    // 0xde52b4: stur            x1, [fp, #-8]
    // 0xde52b8: r16 = ActivateIntent
    //     0xde52b8: add             x16, PP, #0x90, lsl #12  ; [pp+0x904d0] Type: ActivateIntent
    //     0xde52bc: ldr             x16, [x16, #0x4d0]
    // 0xde52c0: StoreField: r1->field_f = r16
    //     0xde52c0: stur            w16, [x1, #0xf]
    // 0xde52c4: ldr             x0, [fp, #0x10]
    // 0xde52c8: r2 = 60
    //     0xde52c8: mov             x2, #0x3c
    // 0xde52cc: branchIfSmi(r0, 0xde52d8)
    //     0xde52cc: tbz             w0, #0, #0xde52d8
    // 0xde52d0: r2 = LoadClassIdInstr(r0)
    //     0xde52d0: ldur            x2, [x0, #-1]
    //     0xde52d4: ubfx            x2, x2, #0xc, #0x14
    // 0xde52d8: str             x0, [SP]
    // 0xde52dc: mov             x0, x2
    // 0xde52e0: r0 = GDT[cid_x0 + 0x47]()
    //     0xde52e0: add             lr, x0, #0x47
    //     0xde52e4: ldr             lr, [x21, lr, lsl #3]
    //     0xde52e8: blr             lr
    // 0xde52ec: r1 = <ActivateIntent>
    //     0xde52ec: add             x1, PP, #0x90, lsl #12  ; [pp+0x904d8] TypeArguments: <ActivateIntent>
    //     0xde52f0: ldr             x1, [x1, #0x4d8]
    // 0xde52f4: stur            x0, [fp, #-0x10]
    // 0xde52f8: r0 = CallbackAction()
    //     0xde52f8: bl              #0xd126e8  ; AllocateCallbackActionStub -> CallbackAction<X0 bound Intent> (size=0x18)
    // 0xde52fc: mov             x2, x0
    // 0xde5300: ldur            x0, [fp, #-0x10]
    // 0xde5304: stur            x2, [fp, #-0x18]
    // 0xde5308: StoreField: r2->field_13 = r0
    //     0xde5308: stur            w0, [x2, #0x13]
    // 0xde530c: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0xde530c: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a7a0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0xde5310: ldr             x1, [x1, #0x7a0]
    // 0xde5314: r0 = ObserverList()
    //     0xde5314: bl              #0x89f8bc  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0xde5318: mov             x3, x0
    // 0xde531c: r0 = false
    //     0xde531c: add             x0, NULL, #0x30  ; false
    // 0xde5320: stur            x3, [fp, #-0x10]
    // 0xde5324: StoreField: r3->field_f = r0
    //     0xde5324: stur            w0, [x3, #0xf]
    // 0xde5328: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xde532c: StoreField: r3->field_13 = r0
    //     0xde532c: stur            w0, [x3, #0x13]
    // 0xde5330: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0xde5330: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a7a0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0xde5334: ldr             x1, [x1, #0x7a0]
    // 0xde5338: r2 = 0
    //     0xde5338: mov             x2, #0
    // 0xde533c: r0 = _GrowableList()
    //     0xde533c: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xde5340: ldur            x1, [fp, #-0x10]
    // 0xde5344: StoreField: r1->field_b = r0
    //     0xde5344: stur            w0, [x1, #0xb]
    //     0xde5348: ldurb           w16, [x1, #-1]
    //     0xde534c: ldurb           w17, [x0, #-1]
    //     0xde5350: and             x16, x17, x16, lsr #2
    //     0xde5354: tst             x16, HEAP, lsr #32
    //     0xde5358: b.eq            #0xde5360
    //     0xde535c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xde5360: mov             x0, x1
    // 0xde5364: ldur            x1, [fp, #-0x18]
    // 0xde5368: StoreField: r1->field_b = r0
    //     0xde5368: stur            w0, [x1, #0xb]
    //     0xde536c: ldurb           w16, [x1, #-1]
    //     0xde5370: ldurb           w17, [x0, #-1]
    //     0xde5374: and             x16, x17, x16, lsr #2
    //     0xde5378: tst             x16, HEAP, lsr #32
    //     0xde537c: b.eq            #0xde5384
    //     0xde5380: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xde5384: mov             x0, x1
    // 0xde5388: ldur            x1, [fp, #-8]
    // 0xde538c: ArrayStore: r1[1] = r0  ; List_4
    //     0xde538c: add             x25, x1, #0x13
    //     0xde5390: str             w0, [x25]
    //     0xde5394: tbz             w0, #0, #0xde53b0
    //     0xde5398: ldurb           w16, [x1, #-1]
    //     0xde539c: ldurb           w17, [x0, #-1]
    //     0xde53a0: and             x16, x17, x16, lsr #2
    //     0xde53a4: tst             x16, HEAP, lsr #32
    //     0xde53a8: b.eq            #0xde53b0
    //     0xde53ac: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xde53b0: r16 = <Type, Action<Intent>>
    //     0xde53b0: add             x16, PP, #0x84, lsl #12  ; [pp+0x84b80] TypeArguments: <Type, Action<Intent>>
    //     0xde53b4: ldr             x16, [x16, #0xb80]
    // 0xde53b8: ldur            lr, [fp, #-8]
    // 0xde53bc: stp             lr, x16, [SP]
    // 0xde53c0: r0 = Map._fromLiteral()
    //     0xde53c0: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xde53c4: LeaveFrame
    //     0xde53c4: mov             SP, fp
    //     0xde53c8: ldp             fp, lr, [SP], #0x10
    // 0xde53cc: ret
    //     0xde53cc: ret             
    // 0xde53d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde53d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde53d4: b               #0xde52a4
  }
  _ didConfirm(/* No info */) {
    // ** addr: 0x11a7b84, size: 0x60
    // 0x11a7b84: EnterFrame
    //     0x11a7b84: stp             fp, lr, [SP, #-0x10]!
    //     0x11a7b88: mov             fp, SP
    // 0x11a7b8c: AllocStack(0x8)
    //     0x11a7b8c: sub             SP, SP, #8
    // 0x11a7b90: CheckStackOverflow
    //     0x11a7b90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a7b94: cmp             SP, x16
    //     0x11a7b98: b.ls            #0x11a7bd8
    // 0x11a7b9c: LoadField: r0 = r1->field_b
    //     0x11a7b9c: ldur            w0, [x1, #0xb]
    // 0x11a7ba0: DecompressPointer r0
    //     0x11a7ba0: add             x0, x0, HEAP, lsl #32
    // 0x11a7ba4: cmp             w0, NULL
    // 0x11a7ba8: b.eq            #0x11a7be0
    // 0x11a7bac: LoadField: r1 = r0->field_b
    //     0x11a7bac: ldur            w1, [x0, #0xb]
    // 0x11a7bb0: DecompressPointer r1
    //     0x11a7bb0: add             x1, x1, HEAP, lsl #32
    // 0x11a7bb4: str             x1, [SP]
    // 0x11a7bb8: mov             x0, x1
    // 0x11a7bbc: ClosureCall
    //     0x11a7bbc: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x11a7bc0: ldur            x2, [x0, #0x1f]
    //     0x11a7bc4: blr             x2
    // 0x11a7bc8: r0 = Null
    //     0x11a7bc8: mov             x0, NULL
    // 0x11a7bcc: LeaveFrame
    //     0x11a7bcc: mov             SP, fp
    //     0x11a7bd0: ldp             fp, lr, [SP], #0x10
    // 0x11a7bd4: ret
    //     0x11a7bd4: ret             
    // 0x11a7bd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a7bd8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a7bdc: b               #0x11a7b9c
    // 0x11a7be0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x11a7be0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  dynamic _handleTap(dynamic) {
    // ** addr: 0x12623f4, size: 0x24
    // 0x12623f4: EnterFrame
    //     0x12623f4: stp             fp, lr, [SP, #-0x10]!
    //     0x12623f8: mov             fp, SP
    // 0x12623fc: ldr             x2, [fp, #0x10]
    // 0x1262400: r1 = Function '_handleTap@708079770':.
    //     0x1262400: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4f18] AnonymousClosure: (0x1262418), in [package:flutter/src/cupertino/dialog.dart] _CupertinoActionSheetActionState::_handleTap (0x1262488)
    //     0x1262404: ldr             x1, [x1, #0xf18]
    // 0x1262408: r0 = AllocateClosure()
    //     0x1262408: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x126240c: LeaveFrame
    //     0x126240c: mov             SP, fp
    //     0x1262410: ldp             fp, lr, [SP], #0x10
    // 0x1262414: ret
    //     0x1262414: ret             
  }
  [closure] void _handleTap(dynamic, [Intent?]) {
    // ** addr: 0x1262418, size: 0x70
    // 0x1262418: EnterFrame
    //     0x1262418: stp             fp, lr, [SP, #-0x10]!
    //     0x126241c: mov             fp, SP
    // 0x1262420: AllocStack(0x8)
    //     0x1262420: sub             SP, SP, #8
    // 0x1262424: SetupParameters(_CupertinoActionSheetActionState this /* r0 */, [dynamic _ = Null /* r1 */])
    //     0x1262424: ldur            w0, [x4, #0x13]
    //     0x1262428: sub             x1, x0, #2
    //     0x126242c: add             x0, fp, w1, sxtw #2
    //     0x1262430: ldr             x0, [x0, #0x10]
    //     0x1262434: cmp             w1, #2
    //     0x1262438: b.lt            #0x126244c
    //     0x126243c: add             x2, fp, w1, sxtw #2
    //     0x1262440: ldr             x2, [x2, #8]
    //     0x1262444: mov             x1, x2
    //     0x1262448: b               #0x1262450
    //     0x126244c: mov             x1, NULL
    //     0x1262450: ldur            w2, [x0, #0x17]
    //     0x1262454: add             x2, x2, HEAP, lsl #32
    // 0x1262458: CheckStackOverflow
    //     0x1262458: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x126245c: cmp             SP, x16
    //     0x1262460: b.ls            #0x1262480
    // 0x1262464: str             x1, [SP]
    // 0x1262468: mov             x1, x2
    // 0x126246c: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x126246c: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x1262470: r0 = _handleTap()
    //     0x1262470: bl              #0x1262488  ; [package:flutter/src/cupertino/dialog.dart] _CupertinoActionSheetActionState::_handleTap
    // 0x1262474: LeaveFrame
    //     0x1262474: mov             SP, fp
    //     0x1262478: ldp             fp, lr, [SP], #0x10
    // 0x126247c: ret
    //     0x126247c: ret             
    // 0x1262480: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1262480: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1262484: b               #0x1262464
  }
  _ _handleTap(/* No info */) {
    // ** addr: 0x1262488, size: 0x9c
    // 0x1262488: EnterFrame
    //     0x1262488: stp             fp, lr, [SP, #-0x10]!
    //     0x126248c: mov             fp, SP
    // 0x1262490: AllocStack(0x10)
    //     0x1262490: sub             SP, SP, #0x10
    // 0x1262494: SetupParameters(_CupertinoActionSheetActionState this /* r1 => r1, fp-0x8 */)
    //     0x1262494: stur            x1, [fp, #-8]
    // 0x1262498: CheckStackOverflow
    //     0x1262498: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x126249c: cmp             SP, x16
    //     0x12624a0: b.ls            #0x1262510
    // 0x12624a4: LoadField: r0 = r1->field_b
    //     0x12624a4: ldur            w0, [x1, #0xb]
    // 0x12624a8: DecompressPointer r0
    //     0x12624a8: add             x0, x0, HEAP, lsl #32
    // 0x12624ac: cmp             w0, NULL
    // 0x12624b0: b.eq            #0x1262518
    // 0x12624b4: LoadField: r2 = r0->field_b
    //     0x12624b4: ldur            w2, [x0, #0xb]
    // 0x12624b8: DecompressPointer r2
    //     0x12624b8: add             x2, x2, HEAP, lsl #32
    // 0x12624bc: str             x2, [SP]
    // 0x12624c0: mov             x0, x2
    // 0x12624c4: ClosureCall
    //     0x12624c4: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x12624c8: ldur            x2, [x0, #0x1f]
    //     0x12624cc: blr             x2
    // 0x12624d0: ldur            x0, [fp, #-8]
    // 0x12624d4: LoadField: r1 = r0->field_f
    //     0x12624d4: ldur            w1, [x0, #0xf]
    // 0x12624d8: DecompressPointer r1
    //     0x12624d8: add             x1, x1, HEAP, lsl #32
    // 0x12624dc: cmp             w1, NULL
    // 0x12624e0: b.eq            #0x126251c
    // 0x12624e4: r0 = renderObject()
    //     0x12624e4: bl              #0x123f10c  ; [package:flutter/src/widgets/framework.dart] Element::renderObject
    // 0x12624e8: cmp             w0, NULL
    // 0x12624ec: b.eq            #0x1262520
    // 0x12624f0: mov             x1, x0
    // 0x12624f4: r2 = Instance_TapSemanticEvent
    //     0x12624f4: add             x2, PP, #0x90, lsl #12  ; [pp+0x904c0] Obj!TapSemanticEvent@129c0b1
    //     0x12624f8: ldr             x2, [x2, #0x4c0]
    // 0x12624fc: r0 = sendSemanticsEvent()
    //     0x12624fc: bl              #0xd12090  ; [package:flutter/src/rendering/object.dart] RenderObject::sendSemanticsEvent
    // 0x1262500: r0 = Null
    //     0x1262500: mov             x0, NULL
    // 0x1262504: LeaveFrame
    //     0x1262504: mov             SP, fp
    //     0x1262508: ldp             fp, lr, [SP], #0x10
    // 0x126250c: ret
    //     0x126250c: ret             
    // 0x1262510: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1262510: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1262514: b               #0x12624a4
    // 0x1262518: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1262518: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x126251c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x126251c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x1262520: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1262520: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 5493, size: 0x20, field offset: 0x14
class _CupertinoActionSheetState extends State<dynamic> {

  get _ _effectiveActionScrollController(/* No info */) {
    // ** addr: 0xde4080, size: 0x90
    // 0xde4080: EnterFrame
    //     0xde4080: stp             fp, lr, [SP, #-0x10]!
    //     0xde4084: mov             fp, SP
    // 0xde4088: AllocStack(0x10)
    //     0xde4088: sub             SP, SP, #0x10
    // 0xde408c: SetupParameters(_CupertinoActionSheetState this /* r1 => r1, fp-0x8 */)
    //     0xde408c: stur            x1, [fp, #-8]
    // 0xde4090: CheckStackOverflow
    //     0xde4090: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde4094: cmp             SP, x16
    //     0xde4098: b.ls            #0xde4104
    // 0xde409c: LoadField: r0 = r1->field_b
    //     0xde409c: ldur            w0, [x1, #0xb]
    // 0xde40a0: DecompressPointer r0
    //     0xde40a0: add             x0, x0, HEAP, lsl #32
    // 0xde40a4: cmp             w0, NULL
    // 0xde40a8: b.eq            #0xde410c
    // 0xde40ac: LoadField: r0 = r1->field_1b
    //     0xde40ac: ldur            w0, [x1, #0x1b]
    // 0xde40b0: DecompressPointer r0
    //     0xde40b0: add             x0, x0, HEAP, lsl #32
    // 0xde40b4: cmp             w0, NULL
    // 0xde40b8: b.ne            #0xde40f8
    // 0xde40bc: r0 = ScrollController()
    //     0xde40bc: bl              #0x86d97c  ; AllocateScrollControllerStub -> ScrollController (size=0x40)
    // 0xde40c0: mov             x1, x0
    // 0xde40c4: stur            x0, [fp, #-0x10]
    // 0xde40c8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xde40c8: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xde40cc: r0 = ScrollController()
    //     0xde40cc: bl              #0x86d884  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::ScrollController
    // 0xde40d0: ldur            x0, [fp, #-0x10]
    // 0xde40d4: ldur            x1, [fp, #-8]
    // 0xde40d8: StoreField: r1->field_1b = r0
    //     0xde40d8: stur            w0, [x1, #0x1b]
    //     0xde40dc: ldurb           w16, [x1, #-1]
    //     0xde40e0: ldurb           w17, [x0, #-1]
    //     0xde40e4: and             x16, x17, x16, lsr #2
    //     0xde40e8: tst             x16, HEAP, lsr #32
    //     0xde40ec: b.eq            #0xde40f4
    //     0xde40f0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xde40f4: ldur            x0, [fp, #-0x10]
    // 0xde40f8: LeaveFrame
    //     0xde40f8: mov             SP, fp
    //     0xde40fc: ldp             fp, lr, [SP], #0x10
    // 0xde4100: ret
    //     0xde4100: ret             
    // 0xde4104: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde4104: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde4108: b               #0xde409c
    // 0xde410c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde410c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ build(/* No info */) {
    // ** addr: 0xde44d8, size: 0x4e8
    // 0xde44d8: EnterFrame
    //     0xde44d8: stp             fp, lr, [SP, #-0x10]!
    //     0xde44dc: mov             fp, SP
    // 0xde44e0: AllocStack(0x88)
    //     0xde44e0: sub             SP, SP, #0x88
    // 0xde44e4: SetupParameters(_CupertinoActionSheetState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xde44e4: stur            x1, [fp, #-8]
    //     0xde44e8: stur            x2, [fp, #-0x10]
    // 0xde44ec: CheckStackOverflow
    //     0xde44ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde44f0: cmp             SP, x16
    //     0xde44f4: b.ls            #0xde4998
    // 0xde44f8: r0 = _GaussianBlurImageFilter()
    //     0xde44f8: bl              #0x9191c8  ; Allocate_GaussianBlurImageFilterStub -> _GaussianBlurImageFilter (size=0x24)
    // 0xde44fc: mov             x2, x0
    // 0xde4500: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xde4504: stur            x2, [fp, #-0x20]
    // 0xde4508: StoreField: r2->field_1f = r0
    //     0xde4508: stur            w0, [x2, #0x1f]
    // 0xde450c: d0 = 30.000000
    //     0xde450c: fmov            d0, #30.00000000
    // 0xde4510: StoreField: r2->field_7 = d0
    //     0xde4510: stur            d0, [x2, #7]
    // 0xde4514: StoreField: r2->field_f = d0
    //     0xde4514: stur            d0, [x2, #0xf]
    // 0xde4518: ldur            x0, [fp, #-8]
    // 0xde451c: LoadField: r3 = r0->field_13
    //     0xde451c: ldur            w3, [x0, #0x13]
    // 0xde4520: DecompressPointer r3
    //     0xde4520: add             x3, x3, HEAP, lsl #32
    // 0xde4524: mov             x1, x0
    // 0xde4528: stur            x3, [fp, #-0x18]
    // 0xde452c: r0 = _effectiveActionScrollController()
    //     0xde452c: bl              #0xde4080  ; [package:flutter/src/cupertino/dialog.dart] _CupertinoActionSheetState::_effectiveActionScrollController
    // 0xde4530: ldur            x1, [fp, #-8]
    // 0xde4534: stur            x0, [fp, #-0x28]
    // 0xde4538: r0 = tristate()
    //     0xde4538: bl              #0x11a1528  ; [package:flutter/src/widgets/raw_radio.dart] _RawRadioState::tristate
    // 0xde453c: ldur            x0, [fp, #-8]
    // 0xde4540: LoadField: r1 = r0->field_b
    //     0xde4540: ldur            w1, [x0, #0xb]
    // 0xde4544: DecompressPointer r1
    //     0xde4544: add             x1, x1, HEAP, lsl #32
    // 0xde4548: cmp             w1, NULL
    // 0xde454c: b.eq            #0xde49a0
    // 0xde4550: LoadField: r3 = r1->field_13
    //     0xde4550: ldur            w3, [x1, #0x13]
    // 0xde4554: DecompressPointer r3
    //     0xde4554: add             x3, x3, HEAP, lsl #32
    // 0xde4558: ldur            x2, [fp, #-0x10]
    // 0xde455c: stur            x3, [fp, #-0x30]
    // 0xde4560: r1 = Instance_CupertinoDynamicColor
    //     0xde4560: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4db0] Obj!CupertinoDynamicColor@12b3c31
    //     0xde4564: ldr             x1, [x1, #0xdb0]
    // 0xde4568: r0 = resolveFrom()
    //     0xde4568: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0xde456c: stur            x0, [fp, #-0x38]
    // 0xde4570: r0 = _ActionSheetMainSheet()
    //     0xde4570: bl              #0xde4e30  ; Allocate_ActionSheetMainSheetStub -> _ActionSheetMainSheet (size=0x24)
    // 0xde4574: mov             x3, x0
    // 0xde4578: ldur            x0, [fp, #-0x18]
    // 0xde457c: stur            x3, [fp, #-0x40]
    // 0xde4580: StoreField: r3->field_b = r0
    //     0xde4580: stur            w0, [x3, #0xb]
    // 0xde4584: ldur            x2, [fp, #-8]
    // 0xde4588: r1 = Function '_onPressedUpdate@708079770':.
    //     0xde4588: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4db8] AnonymousClosure: (0xde4e3c), in [package:flutter/src/cupertino/dialog.dart] _CupertinoActionSheetState::_onPressedUpdate (0xde4d40)
    //     0xde458c: ldr             x1, [x1, #0xdb8]
    // 0xde4590: r0 = AllocateClosure()
    //     0xde4590: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xde4594: mov             x1, x0
    // 0xde4598: ldur            x0, [fp, #-0x40]
    // 0xde459c: StoreField: r0->field_f = r1
    //     0xde459c: stur            w1, [x0, #0xf]
    // 0xde45a0: ldur            x1, [fp, #-0x28]
    // 0xde45a4: StoreField: r0->field_13 = r1
    //     0xde45a4: stur            w1, [x0, #0x13]
    // 0xde45a8: ldur            x1, [fp, #-0x30]
    // 0xde45ac: ArrayStore: r0[0] = r1  ; List_4
    //     0xde45ac: stur            w1, [x0, #0x17]
    // 0xde45b0: ldur            x1, [fp, #-0x38]
    // 0xde45b4: StoreField: r0->field_1f = r1
    //     0xde45b4: stur            w1, [x0, #0x1f]
    // 0xde45b8: r0 = BackdropFilter()
    //     0xde45b8: bl              #0x9190e4  ; AllocateBackdropFilterStub -> BackdropFilter (size=0x28)
    // 0xde45bc: mov             x1, x0
    // 0xde45c0: ldur            x0, [fp, #-0x20]
    // 0xde45c4: stur            x1, [fp, #-0x18]
    // 0xde45c8: StoreField: r1->field_f = r0
    //     0xde45c8: stur            w0, [x1, #0xf]
    // 0xde45cc: r0 = Instance_BlendMode
    //     0xde45cc: add             x0, PP, #0x16, lsl #12  ; [pp+0x16eb8] Obj!BlendMode@12c82e1
    //     0xde45d0: ldr             x0, [x0, #0xeb8]
    // 0xde45d4: ArrayStore: r1[0] = r0  ; List_4
    //     0xde45d4: stur            w0, [x1, #0x17]
    // 0xde45d8: r0 = true
    //     0xde45d8: add             x0, NULL, #0x20  ; true
    // 0xde45dc: StoreField: r1->field_1b = r0
    //     0xde45dc: stur            w0, [x1, #0x1b]
    // 0xde45e0: r2 = false
    //     0xde45e0: add             x2, NULL, #0x30  ; false
    // 0xde45e4: StoreField: r1->field_23 = r2
    //     0xde45e4: stur            w2, [x1, #0x23]
    // 0xde45e8: ldur            x3, [fp, #-0x40]
    // 0xde45ec: StoreField: r1->field_b = r3
    //     0xde45ec: stur            w3, [x1, #0xb]
    // 0xde45f0: r0 = ClipRSuperellipse()
    //     0xde45f0: bl              #0xde4e24  ; AllocateClipRSuperellipseStub -> ClipRSuperellipse (size=0x1c)
    // 0xde45f4: mov             x2, x0
    // 0xde45f8: r0 = Instance_BorderRadius
    //     0xde45f8: add             x0, PP, #0xd4, lsl #12  ; [pp+0xd4dc0] Obj!BorderRadius@129e3b1
    //     0xde45fc: ldr             x0, [x0, #0xdc0]
    // 0xde4600: stur            x2, [fp, #-0x20]
    // 0xde4604: StoreField: r2->field_f = r0
    //     0xde4604: stur            w0, [x2, #0xf]
    // 0xde4608: r0 = Instance_Clip
    //     0xde4608: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e6f0] Obj!Clip@12c8101
    //     0xde460c: ldr             x0, [x0, #0x6f0]
    // 0xde4610: ArrayStore: r2[0] = r0  ; List_4
    //     0xde4610: stur            w0, [x2, #0x17]
    // 0xde4614: ldur            x0, [fp, #-0x18]
    // 0xde4618: StoreField: r2->field_b = r0
    //     0xde4618: stur            w0, [x2, #0xb]
    // 0xde461c: r1 = <FlexParentData>
    //     0xde461c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15878] TypeArguments: <FlexParentData>
    //     0xde4620: ldr             x1, [x1, #0x878]
    // 0xde4624: r0 = Flexible()
    //     0xde4624: bl              #0xd0fd68  ; AllocateFlexibleStub -> Flexible (size=0x20)
    // 0xde4628: mov             x3, x0
    // 0xde462c: r0 = 1
    //     0xde462c: mov             x0, #1
    // 0xde4630: stur            x3, [fp, #-0x18]
    // 0xde4634: StoreField: r3->field_13 = r0
    //     0xde4634: stur            x0, [x3, #0x13]
    // 0xde4638: r0 = Instance_FlexFit
    //     0xde4638: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1ac30] Obj!FlexFit@12c4661
    //     0xde463c: ldr             x0, [x0, #0xc30]
    // 0xde4640: StoreField: r3->field_1b = r0
    //     0xde4640: stur            w0, [x3, #0x1b]
    // 0xde4644: ldur            x0, [fp, #-0x20]
    // 0xde4648: StoreField: r3->field_b = r0
    //     0xde4648: stur            w0, [x3, #0xb]
    // 0xde464c: r1 = Null
    //     0xde464c: mov             x1, NULL
    // 0xde4650: r2 = 2
    //     0xde4650: mov             x2, #2
    // 0xde4654: r0 = AllocateArray()
    //     0xde4654: bl              #0x13df928  ; AllocateArrayStub
    // 0xde4658: mov             x2, x0
    // 0xde465c: ldur            x0, [fp, #-0x18]
    // 0xde4660: stur            x2, [fp, #-0x20]
    // 0xde4664: StoreField: r2->field_f = r0
    //     0xde4664: stur            w0, [x2, #0xf]
    // 0xde4668: r1 = <Widget>
    //     0xde4668: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xde466c: r0 = AllocateGrowableArray()
    //     0xde466c: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xde4670: mov             x2, x0
    // 0xde4674: ldur            x0, [fp, #-0x20]
    // 0xde4678: stur            x2, [fp, #-0x18]
    // 0xde467c: StoreField: r2->field_f = r0
    //     0xde467c: stur            w0, [x2, #0xf]
    // 0xde4680: r0 = 2
    //     0xde4680: mov             x0, #2
    // 0xde4684: StoreField: r2->field_b = r0
    //     0xde4684: stur            w0, [x2, #0xb]
    // 0xde4688: ldur            x0, [fp, #-8]
    // 0xde468c: LoadField: r1 = r0->field_b
    //     0xde468c: ldur            w1, [x0, #0xb]
    // 0xde4690: DecompressPointer r1
    //     0xde4690: add             x1, x1, HEAP, lsl #32
    // 0xde4694: cmp             w1, NULL
    // 0xde4698: b.eq            #0xde49a4
    // 0xde469c: LoadField: r3 = r1->field_1b
    //     0xde469c: ldur            w3, [x1, #0x1b]
    // 0xde46a0: DecompressPointer r3
    //     0xde46a0: add             x3, x3, HEAP, lsl #32
    // 0xde46a4: cmp             w3, NULL
    // 0xde46a8: b.eq            #0xde4734
    // 0xde46ac: mov             x1, x0
    // 0xde46b0: r0 = _buildCancelButton()
    //     0xde46b0: bl              #0xde4b50  ; [package:flutter/src/cupertino/dialog.dart] _CupertinoActionSheetState::_buildCancelButton
    // 0xde46b4: mov             x2, x0
    // 0xde46b8: ldur            x0, [fp, #-0x18]
    // 0xde46bc: stur            x2, [fp, #-0x20]
    // 0xde46c0: LoadField: r1 = r0->field_b
    //     0xde46c0: ldur            w1, [x0, #0xb]
    // 0xde46c4: LoadField: r3 = r0->field_f
    //     0xde46c4: ldur            w3, [x0, #0xf]
    // 0xde46c8: DecompressPointer r3
    //     0xde46c8: add             x3, x3, HEAP, lsl #32
    // 0xde46cc: LoadField: r4 = r3->field_b
    //     0xde46cc: ldur            w4, [x3, #0xb]
    // 0xde46d0: r3 = LoadInt32Instr(r1)
    //     0xde46d0: sbfx            x3, x1, #1, #0x1f
    // 0xde46d4: stur            x3, [fp, #-0x48]
    // 0xde46d8: r1 = LoadInt32Instr(r4)
    //     0xde46d8: sbfx            x1, x4, #1, #0x1f
    // 0xde46dc: cmp             x3, x1
    // 0xde46e0: b.ne            #0xde46ec
    // 0xde46e4: mov             x1, x0
    // 0xde46e8: r0 = _growToNextCapacity()
    //     0xde46e8: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xde46ec: ldur            x2, [fp, #-0x18]
    // 0xde46f0: ldur            x3, [fp, #-0x48]
    // 0xde46f4: add             x0, x3, #1
    // 0xde46f8: lsl             x1, x0, #1
    // 0xde46fc: StoreField: r2->field_b = r1
    //     0xde46fc: stur            w1, [x2, #0xb]
    // 0xde4700: LoadField: r1 = r2->field_f
    //     0xde4700: ldur            w1, [x2, #0xf]
    // 0xde4704: DecompressPointer r1
    //     0xde4704: add             x1, x1, HEAP, lsl #32
    // 0xde4708: ldur            x0, [fp, #-0x20]
    // 0xde470c: ArrayStore: r1[r3] = r0  ; List_4
    //     0xde470c: add             x25, x1, x3, lsl #2
    //     0xde4710: add             x25, x25, #0xf
    //     0xde4714: str             w0, [x25]
    //     0xde4718: tbz             w0, #0, #0xde4734
    //     0xde471c: ldurb           w16, [x1, #-1]
    //     0xde4720: ldurb           w17, [x0, #-1]
    //     0xde4724: and             x16, x17, x16, lsr #2
    //     0xde4728: tst             x16, HEAP, lsr #32
    //     0xde472c: b.eq            #0xde4734
    //     0xde4730: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xde4734: ldur            x1, [fp, #-0x10]
    // 0xde4738: r0 = orientationOf()
    //     0xde4738: bl              #0xd172a4  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::orientationOf
    // 0xde473c: LoadField: r1 = r0->field_7
    //     0xde473c: ldur            x1, [x0, #7]
    // 0xde4740: cmp             x1, #0
    // 0xde4744: b.gt            #0xde4754
    // 0xde4748: ldur            x1, [fp, #-0x10]
    // 0xde474c: r0 = widthOf()
    //     0xde474c: bl              #0xd6f80c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::widthOf
    // 0xde4750: b               #0xde475c
    // 0xde4754: ldur            x1, [fp, #-0x10]
    // 0xde4758: r0 = heightOf()
    //     0xde4758: bl              #0xd30414  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::heightOf
    // 0xde475c: ldur            x0, [fp, #-0x18]
    // 0xde4760: ldur            x1, [fp, #-0x10]
    // 0xde4764: stur            d0, [fp, #-0x50]
    // 0xde4768: r0 = of()
    //     0xde4768: bl              #0xd3827c  ; [package:flutter/src/widgets/scroll_configuration.dart] ScrollConfiguration::of
    // 0xde476c: r1 = LoadClassIdInstr(r0)
    //     0xde476c: ldur            x1, [x0, #-1]
    //     0xde4770: ubfx            x1, x1, #0xc, #0x14
    // 0xde4774: mov             x16, x0
    // 0xde4778: mov             x0, x1
    // 0xde477c: mov             x1, x16
    // 0xde4780: r2 = false
    //     0xde4780: add             x2, NULL, #0x30  ; false
    // 0xde4784: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xde4784: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xde4788: r0 = GDT[cid_x0 + -0xffe]()
    //     0xde4788: sub             lr, x0, #0xffe
    //     0xde478c: ldr             lr, [x21, lr, lsl #3]
    //     0xde4790: blr             lr
    // 0xde4794: ldur            x1, [fp, #-8]
    // 0xde4798: ldur            x2, [fp, #-0x10]
    // 0xde479c: stur            x0, [fp, #-8]
    // 0xde47a0: r0 = _topPadding()
    //     0xde47a0: bl              #0xde49c0  ; [package:flutter/src/cupertino/dialog.dart] _CupertinoActionSheetState::_topPadding
    // 0xde47a4: stur            d0, [fp, #-0x58]
    // 0xde47a8: r0 = EdgeInsets()
    //     0xde47a8: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xde47ac: d0 = 8.000000
    //     0xde47ac: fmov            d0, #8.00000000
    // 0xde47b0: stur            x0, [fp, #-0x10]
    // 0xde47b4: StoreField: r0->field_7 = d0
    //     0xde47b4: stur            d0, [x0, #7]
    // 0xde47b8: ldur            d1, [fp, #-0x58]
    // 0xde47bc: StoreField: r0->field_f = d1
    //     0xde47bc: stur            d1, [x0, #0xf]
    // 0xde47c0: ArrayStore: r0[0] = d0  ; List_8
    //     0xde47c0: stur            d0, [x0, #0x17]
    // 0xde47c4: StoreField: r0->field_1f = rZR
    //     0xde47c4: stur            xzr, [x0, #0x1f]
    // 0xde47c8: ldur            d1, [fp, #-0x50]
    // 0xde47cc: d0 = 16.000000
    //     0xde47cc: fmov            d0, #16.00000000
    // 0xde47d0: fsub            d2, d1, d0
    // 0xde47d4: stur            d2, [fp, #-0x58]
    // 0xde47d8: r0 = Column()
    //     0xde47d8: bl              #0x8a5b1c  ; AllocateColumnStub -> Column (size=0x38)
    // 0xde47dc: mov             x1, x0
    // 0xde47e0: r0 = Instance_Axis
    //     0xde47e0: ldr             x0, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xde47e4: stur            x1, [fp, #-0x20]
    // 0xde47e8: StoreField: r1->field_f = r0
    //     0xde47e8: stur            w0, [x1, #0xf]
    // 0xde47ec: r0 = Instance_MainAxisAlignment
    //     0xde47ec: add             x0, PP, #0x18, lsl #12  ; [pp+0x182b8] Obj!MainAxisAlignment@12c45e1
    //     0xde47f0: ldr             x0, [x0, #0x2b8]
    // 0xde47f4: StoreField: r1->field_13 = r0
    //     0xde47f4: stur            w0, [x1, #0x13]
    // 0xde47f8: r0 = Instance_MainAxisSize
    //     0xde47f8: add             x0, PP, #0x17, lsl #12  ; [pp+0x17200] Obj!MainAxisSize@12c4601
    //     0xde47fc: ldr             x0, [x0, #0x200]
    // 0xde4800: ArrayStore: r1[0] = r0  ; List_4
    //     0xde4800: stur            w0, [x1, #0x17]
    // 0xde4804: r0 = Instance_CrossAxisAlignment
    //     0xde4804: add             x0, PP, #0x7b, lsl #12  ; [pp+0x7bc40] Obj!CrossAxisAlignment@12c4521
    //     0xde4808: ldr             x0, [x0, #0xc40]
    // 0xde480c: StoreField: r1->field_1b = r0
    //     0xde480c: stur            w0, [x1, #0x1b]
    // 0xde4810: r0 = Instance_VerticalDirection
    //     0xde4810: add             x0, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xde4814: ldr             x0, [x0, #0x838]
    // 0xde4818: StoreField: r1->field_23 = r0
    //     0xde4818: stur            w0, [x1, #0x23]
    // 0xde481c: r0 = Instance_Clip
    //     0xde481c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xde4820: ldr             x0, [x0, #0x840]
    // 0xde4824: StoreField: r1->field_2b = r0
    //     0xde4824: stur            w0, [x1, #0x2b]
    // 0xde4828: StoreField: r1->field_2f = rZR
    //     0xde4828: stur            xzr, [x1, #0x2f]
    // 0xde482c: ldur            x0, [fp, #-0x18]
    // 0xde4830: StoreField: r1->field_b = r0
    //     0xde4830: stur            w0, [x1, #0xb]
    // 0xde4834: r0 = Semantics()
    //     0xde4834: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xde4838: stur            x0, [fp, #-0x18]
    // 0xde483c: r16 = true
    //     0xde483c: add             x16, NULL, #0x20  ; true
    // 0xde4840: ldur            lr, [fp, #-0x20]
    // 0xde4844: stp             lr, x16, [SP]
    // 0xde4848: mov             x1, x0
    // 0xde484c: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, explicitChildNodes, 0x1, null]
    //     0xde484c: add             x4, PP, #0x80, lsl #12  ; [pp+0x80e48] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "explicitChildNodes", 0x1, Null]
    //     0xde4850: ldr             x4, [x4, #0xe48]
    // 0xde4854: r0 = Semantics()
    //     0xde4854: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xde4858: r0 = _ActionSheetGestureDetector()
    //     0xde4858: bl              #0xde3b4c  ; Allocate_ActionSheetGestureDetectorStub -> _ActionSheetGestureDetector (size=0x10)
    // 0xde485c: mov             x1, x0
    // 0xde4860: ldur            x0, [fp, #-0x18]
    // 0xde4864: stur            x1, [fp, #-0x20]
    // 0xde4868: StoreField: r1->field_b = r0
    //     0xde4868: stur            w0, [x1, #0xb]
    // 0xde486c: ldur            d0, [fp, #-0x58]
    // 0xde4870: r0 = inline_Allocate_Double()
    //     0xde4870: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xde4874: add             x0, x0, #0x10
    //     0xde4878: cmp             x2, x0
    //     0xde487c: b.ls            #0xde49a8
    //     0xde4880: str             x0, [THR, #0x60]  ; THR::top
    //     0xde4884: sub             x0, x0, #0xf
    //     0xde4888: mov             x2, #0xe19c
    //     0xde488c: movk            x2, #3, lsl #16
    //     0xde4890: stur            x2, [x0, #-1]
    // 0xde4894: dmb             ishst
    // 0xde4898: StoreField: r0->field_7 = d0
    //     0xde4898: stur            d0, [x0, #7]
    // 0xde489c: stur            x0, [fp, #-0x18]
    // 0xde48a0: r0 = SizedBox()
    //     0xde48a0: bl              #0x8a7210  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0xde48a4: mov             x1, x0
    // 0xde48a8: ldur            x0, [fp, #-0x18]
    // 0xde48ac: stur            x1, [fp, #-0x28]
    // 0xde48b0: StoreField: r1->field_f = r0
    //     0xde48b0: stur            w0, [x1, #0xf]
    // 0xde48b4: ldur            x0, [fp, #-0x20]
    // 0xde48b8: StoreField: r1->field_b = r0
    //     0xde48b8: stur            w0, [x1, #0xb]
    // 0xde48bc: r0 = Padding()
    //     0xde48bc: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xde48c0: mov             x1, x0
    // 0xde48c4: ldur            x0, [fp, #-0x10]
    // 0xde48c8: stur            x1, [fp, #-0x18]
    // 0xde48cc: StoreField: r1->field_f = r0
    //     0xde48cc: stur            w0, [x1, #0xf]
    // 0xde48d0: ldur            x0, [fp, #-0x28]
    // 0xde48d4: StoreField: r1->field_b = r0
    //     0xde48d4: stur            w0, [x1, #0xb]
    // 0xde48d8: r0 = CupertinoUserInterfaceLevel()
    //     0xde48d8: bl              #0xde3748  ; AllocateCupertinoUserInterfaceLevelStub -> CupertinoUserInterfaceLevel (size=0x14)
    // 0xde48dc: mov             x1, x0
    // 0xde48e0: r0 = Instance_CupertinoUserInterfaceLevelData
    //     0xde48e0: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e890] Obj!CupertinoUserInterfaceLevelData@12c5fe1
    //     0xde48e4: ldr             x0, [x0, #0x890]
    // 0xde48e8: stur            x1, [fp, #-0x10]
    // 0xde48ec: StoreField: r1->field_f = r0
    //     0xde48ec: stur            w0, [x1, #0xf]
    // 0xde48f0: ldur            x0, [fp, #-0x18]
    // 0xde48f4: StoreField: r1->field_b = r0
    //     0xde48f4: stur            w0, [x1, #0xb]
    // 0xde48f8: r0 = Semantics()
    //     0xde48f8: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xde48fc: stur            x0, [fp, #-0x18]
    // 0xde4900: r16 = true
    //     0xde4900: add             x16, NULL, #0x20  ; true
    // 0xde4904: r30 = true
    //     0xde4904: add             lr, NULL, #0x20  ; true
    // 0xde4908: stp             lr, x16, [SP, #0x20]
    // 0xde490c: r16 = true
    //     0xde490c: add             x16, NULL, #0x20  ; true
    // 0xde4910: r30 = Instance_SemanticsRole
    //     0xde4910: add             lr, PP, #0x7b, lsl #12  ; [pp+0x7b7b8] Obj!SemanticsRole@12c78c1
    //     0xde4914: ldr             lr, [lr, #0x7b8]
    // 0xde4918: stp             lr, x16, [SP, #0x10]
    // 0xde491c: r16 = "Alert"
    //     0xde491c: add             x16, PP, #0xa7, lsl #12  ; [pp+0xa7f68] "Alert"
    //     0xde4920: ldr             x16, [x16, #0xf68]
    // 0xde4924: ldur            lr, [fp, #-0x10]
    // 0xde4928: stp             lr, x16, [SP]
    // 0xde492c: mov             x1, x0
    // 0xde4930: r4 = const [0, 0x7, 0x6, 0x1, child, 0x6, explicitChildNodes, 0x3, label, 0x5, namesRoute, 0x1, role, 0x4, scopesRoute, 0x2, null]
    //     0xde4930: add             x4, PP, #0xd4, lsl #12  ; [pp+0xd4dc8] List(17) [0, 0x7, 0x6, 0x1, "child", 0x6, "explicitChildNodes", 0x3, "label", 0x5, "namesRoute", 0x1, "role", 0x4, "scopesRoute", 0x2, Null]
    //     0xde4934: ldr             x4, [x4, #0xdc8]
    // 0xde4938: r0 = Semantics()
    //     0xde4938: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xde493c: r0 = ScrollConfiguration()
    //     0xde493c: bl              #0xde3754  ; AllocateScrollConfigurationStub -> ScrollConfiguration (size=0x14)
    // 0xde4940: mov             x1, x0
    // 0xde4944: ldur            x0, [fp, #-8]
    // 0xde4948: stur            x1, [fp, #-0x10]
    // 0xde494c: StoreField: r1->field_f = r0
    //     0xde494c: stur            w0, [x1, #0xf]
    // 0xde4950: ldur            x0, [fp, #-0x18]
    // 0xde4954: StoreField: r1->field_b = r0
    //     0xde4954: stur            w0, [x1, #0xb]
    // 0xde4958: r0 = SafeArea()
    //     0xde4958: bl              #0xd73100  ; AllocateSafeAreaStub -> SafeArea (size=0x28)
    // 0xde495c: r1 = true
    //     0xde495c: add             x1, NULL, #0x20  ; true
    // 0xde4960: StoreField: r0->field_b = r1
    //     0xde4960: stur            w1, [x0, #0xb]
    // 0xde4964: StoreField: r0->field_f = r1
    //     0xde4964: stur            w1, [x0, #0xf]
    // 0xde4968: StoreField: r0->field_13 = r1
    //     0xde4968: stur            w1, [x0, #0x13]
    // 0xde496c: ArrayStore: r0[0] = r1  ; List_4
    //     0xde496c: stur            w1, [x0, #0x17]
    // 0xde4970: r1 = Instance_EdgeInsets
    //     0xde4970: add             x1, PP, #0x88, lsl #12  ; [pp+0x886e8] Obj!EdgeInsets@129d021
    //     0xde4974: ldr             x1, [x1, #0x6e8]
    // 0xde4978: StoreField: r0->field_1b = r1
    //     0xde4978: stur            w1, [x0, #0x1b]
    // 0xde497c: r1 = false
    //     0xde497c: add             x1, NULL, #0x30  ; false
    // 0xde4980: StoreField: r0->field_1f = r1
    //     0xde4980: stur            w1, [x0, #0x1f]
    // 0xde4984: ldur            x1, [fp, #-0x10]
    // 0xde4988: StoreField: r0->field_23 = r1
    //     0xde4988: stur            w1, [x0, #0x23]
    // 0xde498c: LeaveFrame
    //     0xde498c: mov             SP, fp
    //     0xde4990: ldp             fp, lr, [SP], #0x10
    // 0xde4994: ret
    //     0xde4994: ret             
    // 0xde4998: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde4998: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde499c: b               #0xde44f8
    // 0xde49a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde49a0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde49a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde49a4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde49a8: SaveReg d0
    //     0xde49a8: str             q0, [SP, #-0x10]!
    // 0xde49ac: SaveReg r1
    //     0xde49ac: str             x1, [SP, #-8]!
    // 0xde49b0: r0 = AllocateDouble()
    //     0xde49b0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xde49b4: RestoreReg r1
    //     0xde49b4: ldr             x1, [SP], #8
    // 0xde49b8: RestoreReg d0
    //     0xde49b8: ldr             q0, [SP], #0x10
    // 0xde49bc: b               #0xde4898
  }
  _ _topPadding(/* No info */) {
    // ** addr: 0xde49c0, size: 0xc4
    // 0xde49c0: EnterFrame
    //     0xde49c0: stp             fp, lr, [SP, #-0x10]!
    //     0xde49c4: mov             fp, SP
    // 0xde49c8: AllocStack(0x10)
    //     0xde49c8: sub             SP, SP, #0x10
    // 0xde49cc: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0xde49cc: mov             x0, x2
    //     0xde49d0: stur            x2, [fp, #-8]
    // 0xde49d4: CheckStackOverflow
    //     0xde49d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde49d8: cmp             SP, x16
    //     0xde49dc: b.ls            #0xde4a7c
    // 0xde49e0: mov             x1, x0
    // 0xde49e4: r0 = orientationOf()
    //     0xde49e4: bl              #0xd172a4  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::orientationOf
    // 0xde49e8: r16 = Instance_Orientation
    //     0xde49e8: add             x16, PP, #0x14, lsl #12  ; [pp+0x143c0] Obj!Orientation@12c2ee1
    //     0xde49ec: ldr             x16, [x16, #0x3c0]
    // 0xde49f0: cmp             w0, w16
    // 0xde49f4: b.ne            #0xde4a08
    // 0xde49f8: d0 = 8.000000
    //     0xde49f8: fmov            d0, #8.00000000
    // 0xde49fc: LeaveFrame
    //     0xde49fc: mov             SP, fp
    //     0xde4a00: ldp             fp, lr, [SP], #0x10
    // 0xde4a04: ret
    //     0xde4a04: ret             
    // 0xde4a08: ldur            x1, [fp, #-8]
    // 0xde4a0c: r0 = viewPaddingOf()
    //     0xde4a0c: bl              #0xd0be80  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::viewPaddingOf
    // 0xde4a10: LoadField: d1 = r0->field_f
    //     0xde4a10: ldur            d1, [x0, #0xf]
    // 0xde4a14: mov             v0.16b, v1.16b
    // 0xde4a18: stur            d1, [fp, #-0x10]
    // 0xde4a1c: r0 = _lerp()
    //     0xde4a1c: bl              #0xde4a84  ; [package:flutter/src/cupertino/dialog.dart] _CupertinoActionSheetState::_lerp
    // 0xde4a20: mov             v1.16b, v0.16b
    // 0xde4a24: ldur            d0, [fp, #-0x10]
    // 0xde4a28: fmul            d2, d1, d0
    // 0xde4a2c: mov             v0.16b, v2.16b
    // 0xde4a30: stp             fp, lr, [SP, #-0x10]!
    // 0xde4a34: mov             fp, SP
    // 0xde4a38: CallRuntime_LibcRound(double) -> double
    //     0xde4a38: and             SP, SP, #0xfffffffffffffff0
    //     0xde4a3c: mov             sp, SP
    //     0xde4a40: ldr             x16, [THR, #0x770]  ; THR::LibcRound
    //     0xde4a44: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xde4a48: blr             x16
    //     0xde4a4c: mov             x16, #8
    //     0xde4a50: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xde4a54: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xde4a58: sub             sp, x16, #1, lsl #12
    //     0xde4a5c: mov             SP, fp
    //     0xde4a60: ldp             fp, lr, [SP], #0x10
    // 0xde4a64: d1 = 20.000000
    //     0xde4a64: fmov            d1, #20.00000000
    // 0xde4a68: fmax            v2.2d, v0.2d, v1.2d
    // 0xde4a6c: mov             v0.16b, v2.16b
    // 0xde4a70: LeaveFrame
    //     0xde4a70: mov             SP, fp
    //     0xde4a74: ldp             fp, lr, [SP], #0x10
    // 0xde4a78: ret
    //     0xde4a78: ret             
    // 0xde4a7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde4a7c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde4a80: b               #0xde49e0
  }
  static _ _lerp(/* No info */) {
    // ** addr: 0xde4a84, size: 0xcc
    // 0xde4a84: EnterFrame
    //     0xde4a84: stp             fp, lr, [SP, #-0x10]!
    //     0xde4a88: mov             fp, SP
    // 0xde4a8c: d1 = 47.000000
    //     0xde4a8c: add             x17, PP, #0xd3, lsl #12  ; [pp+0xd3fd8] IMM: double(47) from 0x4047800000000000
    //     0xde4a90: ldr             d1, [x17, #0xfd8]
    // 0xde4a94: CheckStackOverflow
    //     0xde4a94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde4a98: cmp             SP, x16
    //     0xde4a9c: b.ls            #0xde4b34
    // 0xde4aa0: fcmp            d1, d0
    // 0xde4aa4: b.lt            #0xde4ab8
    // 0xde4aa8: d0 = 1.000000
    //     0xde4aa8: fmov            d0, #1.00000000
    // 0xde4aac: LeaveFrame
    //     0xde4aac: mov             SP, fp
    //     0xde4ab0: ldp             fp, lr, [SP], #0x10
    // 0xde4ab4: ret
    //     0xde4ab4: ret             
    // 0xde4ab8: d2 = 59.000000
    //     0xde4ab8: add             x17, PP, #0x98, lsl #12  ; [pp+0x98eb0] IMM: double(59) from 0x404d800000000000
    //     0xde4abc: ldr             d2, [x17, #0xeb0]
    // 0xde4ac0: fcmp            d0, d2
    // 0xde4ac4: b.lt            #0xde4adc
    // 0xde4ac8: d0 = 0.915254
    //     0xde4ac8: add             x17, PP, #0xd4, lsl #12  ; [pp+0xd4de0] IMM: double(0.9152542372881356) from 0x3fed49c34115b1e6
    //     0xde4acc: ldr             d0, [x17, #0xde0]
    // 0xde4ad0: LeaveFrame
    //     0xde4ad0: mov             SP, fp
    //     0xde4ad4: ldp             fp, lr, [SP], #0x10
    // 0xde4ad8: ret
    //     0xde4ad8: ret             
    // 0xde4adc: d2 = 12.000000
    //     0xde4adc: fmov            d2, #12.00000000
    // 0xde4ae0: fsub            d3, d0, d1
    // 0xde4ae4: fdiv            d0, d3, d2
    // 0xde4ae8: r3 = inline_Allocate_Double()
    //     0xde4ae8: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0xde4aec: add             x3, x3, #0x10
    //     0xde4af0: cmp             x0, x3
    //     0xde4af4: b.ls            #0xde4b3c
    //     0xde4af8: str             x3, [THR, #0x60]  ; THR::top
    //     0xde4afc: sub             x3, x3, #0xf
    //     0xde4b00: mov             x0, #0xe19c
    //     0xde4b04: movk            x0, #3, lsl #16
    //     0xde4b08: stur            x0, [x3, #-1]
    // 0xde4b0c: dmb             ishst
    // 0xde4b10: StoreField: r3->field_7 = d0
    //     0xde4b10: stur            d0, [x3, #7]
    // 0xde4b14: r1 = 1.000000
    //     0xde4b14: ldr             x1, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xde4b18: r2 = 0.915254
    //     0xde4b18: add             x2, PP, #0xd4, lsl #12  ; [pp+0xd4de8] 0.9152542372881356
    //     0xde4b1c: ldr             x2, [x2, #0xde8]
    // 0xde4b20: r0 = lerpDouble()
    //     0xde4b20: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0xde4b24: LoadField: d0 = r0->field_7
    //     0xde4b24: ldur            d0, [x0, #7]
    // 0xde4b28: LeaveFrame
    //     0xde4b28: mov             SP, fp
    //     0xde4b2c: ldp             fp, lr, [SP], #0x10
    // 0xde4b30: ret
    //     0xde4b30: ret             
    // 0xde4b34: r0 = StackOverflowSharedWithFPURegs()
    //     0xde4b34: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xde4b38: b               #0xde4aa0
    // 0xde4b3c: SaveReg d0
    //     0xde4b3c: str             q0, [SP, #-0x10]!
    // 0xde4b40: r0 = AllocateDouble()
    //     0xde4b40: bl              #0x13df878  ; AllocateDoubleStub
    // 0xde4b44: mov             x3, x0
    // 0xde4b48: RestoreReg d0
    //     0xde4b48: ldr             q0, [SP], #0x10
    // 0xde4b4c: b               #0xde4b10
  }
  _ _buildCancelButton(/* No info */) {
    // ** addr: 0xde4b50, size: 0x164
    // 0xde4b50: EnterFrame
    //     0xde4b50: stp             fp, lr, [SP, #-0x10]!
    //     0xde4b54: mov             fp, SP
    // 0xde4b58: AllocStack(0x30)
    //     0xde4b58: sub             SP, SP, #0x30
    // 0xde4b5c: SetupParameters(_CupertinoActionSheetState this /* r1 => r1, fp-0x8 */)
    //     0xde4b5c: stur            x1, [fp, #-8]
    // 0xde4b60: CheckStackOverflow
    //     0xde4b60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde4b64: cmp             SP, x16
    //     0xde4b68: b.ls            #0xde4c9c
    // 0xde4b6c: r1 = 1
    //     0xde4b6c: mov             x1, #1
    // 0xde4b70: r0 = AllocateContext()
    //     0xde4b70: bl              #0x13de838  ; AllocateContextStub
    // 0xde4b74: mov             x1, x0
    // 0xde4b78: ldur            x0, [fp, #-8]
    // 0xde4b7c: stur            x1, [fp, #-0x10]
    // 0xde4b80: StoreField: r1->field_f = r0
    //     0xde4b80: stur            w0, [x1, #0xf]
    // 0xde4b84: LoadField: r2 = r0->field_b
    //     0xde4b84: ldur            w2, [x0, #0xb]
    // 0xde4b88: DecompressPointer r2
    //     0xde4b88: add             x2, x2, HEAP, lsl #32
    // 0xde4b8c: cmp             w2, NULL
    // 0xde4b90: b.eq            #0xde4ca4
    // 0xde4b94: r0 = EdgeInsets()
    //     0xde4b94: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xde4b98: stur            x0, [fp, #-0x18]
    // 0xde4b9c: StoreField: r0->field_7 = rZR
    //     0xde4b9c: stur            xzr, [x0, #7]
    // 0xde4ba0: d0 = 8.000000
    //     0xde4ba0: fmov            d0, #8.00000000
    // 0xde4ba4: StoreField: r0->field_f = d0
    //     0xde4ba4: stur            d0, [x0, #0xf]
    // 0xde4ba8: ArrayStore: r0[0] = rZR  ; List_8
    //     0xde4ba8: stur            xzr, [x0, #0x17]
    // 0xde4bac: StoreField: r0->field_1f = rZR
    //     0xde4bac: stur            xzr, [x0, #0x1f]
    // 0xde4bb0: r1 = _ConstMap len:3
    //     0xde4bb0: add             x1, PP, #0xac, lsl #12  ; [pp+0xacc70] Map<CupertinoButtonSize, BorderRadius>(3)
    //     0xde4bb4: ldr             x1, [x1, #0xc70]
    // 0xde4bb8: r2 = Instance_CupertinoButtonSize
    //     0xde4bb8: add             x2, PP, #0x95, lsl #12  ; [pp+0x95fd8] Obj!CupertinoButtonSize@12c6081
    //     0xde4bbc: ldr             x2, [x2, #0xfd8]
    // 0xde4bc0: r0 = []()
    //     0xde4bc0: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0xde4bc4: stur            x0, [fp, #-0x28]
    // 0xde4bc8: cmp             w0, NULL
    // 0xde4bcc: b.eq            #0xde4ca8
    // 0xde4bd0: ldur            x1, [fp, #-8]
    // 0xde4bd4: LoadField: r2 = r1->field_13
    //     0xde4bd4: ldur            w2, [x1, #0x13]
    // 0xde4bd8: DecompressPointer r2
    //     0xde4bd8: add             x2, x2, HEAP, lsl #32
    // 0xde4bdc: cmn             w2, #2
    // 0xde4be0: r16 = true
    //     0xde4be0: add             x16, NULL, #0x20  ; true
    // 0xde4be4: r17 = false
    //     0xde4be4: add             x17, NULL, #0x30  ; false
    // 0xde4be8: csel            x3, x16, x17, eq
    // 0xde4bec: stur            x3, [fp, #-0x20]
    // 0xde4bf0: LoadField: r2 = r1->field_b
    //     0xde4bf0: ldur            w2, [x1, #0xb]
    // 0xde4bf4: DecompressPointer r2
    //     0xde4bf4: add             x2, x2, HEAP, lsl #32
    // 0xde4bf8: cmp             w2, NULL
    // 0xde4bfc: b.eq            #0xde4cac
    // 0xde4c00: LoadField: r1 = r2->field_1b
    //     0xde4c00: ldur            w1, [x2, #0x1b]
    // 0xde4c04: DecompressPointer r1
    //     0xde4c04: add             x1, x1, HEAP, lsl #32
    // 0xde4c08: stur            x1, [fp, #-8]
    // 0xde4c0c: cmp             w1, NULL
    // 0xde4c10: b.eq            #0xde4cb0
    // 0xde4c14: r0 = _ActionSheetButtonBackground()
    //     0xde4c14: bl              #0xde4cc0  ; Allocate_ActionSheetButtonBackgroundStub -> _ActionSheetButtonBackground (size=0x1c)
    // 0xde4c18: mov             x3, x0
    // 0xde4c1c: r0 = true
    //     0xde4c1c: add             x0, NULL, #0x20  ; true
    // 0xde4c20: stur            x3, [fp, #-0x30]
    // 0xde4c24: StoreField: r3->field_b = r0
    //     0xde4c24: stur            w0, [x3, #0xb]
    // 0xde4c28: ldur            x0, [fp, #-0x20]
    // 0xde4c2c: StoreField: r3->field_f = r0
    //     0xde4c2c: stur            w0, [x3, #0xf]
    // 0xde4c30: ldur            x2, [fp, #-0x10]
    // 0xde4c34: r1 = Function '<anonymous closure>':.
    //     0xde4c34: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4df0] AnonymousClosure: (0xde4cf0), in [package:flutter/src/cupertino/dialog.dart] _CupertinoActionSheetState::_buildCancelButton (0xde4b50)
    //     0xde4c38: ldr             x1, [x1, #0xdf0]
    // 0xde4c3c: r0 = AllocateClosure()
    //     0xde4c3c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xde4c40: mov             x1, x0
    // 0xde4c44: ldur            x0, [fp, #-0x30]
    // 0xde4c48: StoreField: r0->field_13 = r1
    //     0xde4c48: stur            w1, [x0, #0x13]
    // 0xde4c4c: ldur            x1, [fp, #-8]
    // 0xde4c50: ArrayStore: r0[0] = r1  ; List_4
    //     0xde4c50: stur            w1, [x0, #0x17]
    // 0xde4c54: r0 = CupertinoFocusHalo()
    //     0xde4c54: bl              #0xde4cb4  ; AllocateCupertinoFocusHaloStub -> CupertinoFocusHalo (size=0x18)
    // 0xde4c58: mov             x1, x0
    // 0xde4c5c: ldur            x0, [fp, #-0x30]
    // 0xde4c60: stur            x1, [fp, #-8]
    // 0xde4c64: StoreField: r1->field_13 = r0
    //     0xde4c64: stur            w0, [x1, #0x13]
    // 0xde4c68: ldur            x0, [fp, #-0x28]
    // 0xde4c6c: StoreField: r1->field_b = r0
    //     0xde4c6c: stur            w0, [x1, #0xb]
    // 0xde4c70: r0 = Closure: ({BorderSide side, BorderRadiusGeometry borderRadius}) => RoundedRectangleBorder from Function 'RoundedRectangleBorder.': static.
    //     0xde4c70: add             x0, PP, #0xd4, lsl #12  ; [pp+0xd4df8] Closure: ({BorderSide side, BorderRadiusGeometry borderRadius}) => RoundedRectangleBorder from Function 'RoundedRectangleBorder.': static. (0x7f2adacc9f8c)
    //     0xde4c74: ldr             x0, [x0, #0xdf8]
    // 0xde4c78: StoreField: r1->field_f = r0
    //     0xde4c78: stur            w0, [x1, #0xf]
    // 0xde4c7c: r0 = Padding()
    //     0xde4c7c: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xde4c80: ldur            x1, [fp, #-0x18]
    // 0xde4c84: StoreField: r0->field_f = r1
    //     0xde4c84: stur            w1, [x0, #0xf]
    // 0xde4c88: ldur            x1, [fp, #-8]
    // 0xde4c8c: StoreField: r0->field_b = r1
    //     0xde4c8c: stur            w1, [x0, #0xb]
    // 0xde4c90: LeaveFrame
    //     0xde4c90: mov             SP, fp
    //     0xde4c94: ldp             fp, lr, [SP], #0x10
    // 0xde4c98: ret
    //     0xde4c98: ret             
    // 0xde4c9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde4c9c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde4ca0: b               #0xde4b6c
    // 0xde4ca4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde4ca4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde4ca8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde4ca8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde4cac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde4cac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde4cb0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde4cb0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, bool) {
    // ** addr: 0xde4cf0, size: 0x50
    // 0xde4cf0: EnterFrame
    //     0xde4cf0: stp             fp, lr, [SP, #-0x10]!
    //     0xde4cf4: mov             fp, SP
    // 0xde4cf8: ldr             x0, [fp, #0x18]
    // 0xde4cfc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xde4cfc: ldur            w1, [x0, #0x17]
    // 0xde4d00: DecompressPointer r1
    //     0xde4d00: add             x1, x1, HEAP, lsl #32
    // 0xde4d04: CheckStackOverflow
    //     0xde4d04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde4d08: cmp             SP, x16
    //     0xde4d0c: b.ls            #0xde4d38
    // 0xde4d10: LoadField: r0 = r1->field_f
    //     0xde4d10: ldur            w0, [x1, #0xf]
    // 0xde4d14: DecompressPointer r0
    //     0xde4d14: add             x0, x0, HEAP, lsl #32
    // 0xde4d18: mov             x1, x0
    // 0xde4d1c: ldr             x3, [fp, #0x10]
    // 0xde4d20: r2 = -2
    //     0xde4d20: mov             x2, #-2
    // 0xde4d24: r0 = _onPressedUpdate()
    //     0xde4d24: bl              #0xde4d40  ; [package:flutter/src/cupertino/dialog.dart] _CupertinoActionSheetState::_onPressedUpdate
    // 0xde4d28: r0 = Null
    //     0xde4d28: mov             x0, NULL
    // 0xde4d2c: LeaveFrame
    //     0xde4d2c: mov             SP, fp
    //     0xde4d30: ldp             fp, lr, [SP], #0x10
    // 0xde4d34: ret
    //     0xde4d34: ret             
    // 0xde4d38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde4d38: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde4d3c: b               #0xde4d10
  }
  _ _onPressedUpdate(/* No info */) {
    // ** addr: 0xde4d40, size: 0xe4
    // 0xde4d40: EnterFrame
    //     0xde4d40: stp             fp, lr, [SP, #-0x10]!
    //     0xde4d44: mov             fp, SP
    // 0xde4d48: AllocStack(0x18)
    //     0xde4d48: sub             SP, SP, #0x18
    // 0xde4d4c: SetupParameters(_CupertinoActionSheetState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xde4d4c: stur            x1, [fp, #-8]
    //     0xde4d50: stur            x2, [fp, #-0x10]
    //     0xde4d54: stur            x3, [fp, #-0x18]
    // 0xde4d58: CheckStackOverflow
    //     0xde4d58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde4d5c: cmp             SP, x16
    //     0xde4d60: b.ls            #0xde4e1c
    // 0xde4d64: r1 = 2
    //     0xde4d64: mov             x1, #2
    // 0xde4d68: r0 = AllocateContext()
    //     0xde4d68: bl              #0x13de838  ; AllocateContextStub
    // 0xde4d6c: mov             x1, x0
    // 0xde4d70: ldur            x0, [fp, #-8]
    // 0xde4d74: StoreField: r1->field_f = r0
    //     0xde4d74: stur            w0, [x1, #0xf]
    // 0xde4d78: ldur            x2, [fp, #-0x10]
    // 0xde4d7c: StoreField: r1->field_13 = r2
    //     0xde4d7c: stur            w2, [x1, #0x13]
    // 0xde4d80: ldur            x3, [fp, #-0x18]
    // 0xde4d84: tbz             w3, #4, #0xde4df0
    // 0xde4d88: LoadField: r3 = r0->field_13
    //     0xde4d88: ldur            w3, [x0, #0x13]
    // 0xde4d8c: DecompressPointer r3
    //     0xde4d8c: add             x3, x3, HEAP, lsl #32
    // 0xde4d90: cmp             w3, w2
    // 0xde4d94: b.eq            #0xde4dd0
    // 0xde4d98: and             w16, w3, w2
    // 0xde4d9c: branchIfSmi(r16, 0xde4e0c)
    //     0xde4d9c: tbz             w16, #0, #0xde4e0c
    // 0xde4da0: r16 = LoadClassIdInstr(r3)
    //     0xde4da0: ldur            x16, [x3, #-1]
    //     0xde4da4: ubfx            x16, x16, #0xc, #0x14
    // 0xde4da8: cmp             x16, #0x3d
    // 0xde4dac: b.ne            #0xde4e0c
    // 0xde4db0: r16 = LoadClassIdInstr(r2)
    //     0xde4db0: ldur            x16, [x2, #-1]
    //     0xde4db4: ubfx            x16, x16, #0xc, #0x14
    // 0xde4db8: cmp             x16, #0x3d
    // 0xde4dbc: b.ne            #0xde4e0c
    // 0xde4dc0: LoadField: r16 = r3->field_7
    //     0xde4dc0: ldur            x16, [x3, #7]
    // 0xde4dc4: LoadField: r17 = r2->field_7
    //     0xde4dc4: ldur            x17, [x2, #7]
    // 0xde4dc8: cmp             x16, x17
    // 0xde4dcc: b.ne            #0xde4e0c
    // 0xde4dd0: mov             x2, x1
    // 0xde4dd4: r1 = Function '<anonymous closure>':.
    //     0xde4dd4: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4dd0] AnonymousClosure: (0xbaf364), in [package:flutter/src/widgets/overlay.dart] _OverlayPortalState::hide (0xbaf384)
    //     0xde4dd8: ldr             x1, [x1, #0xdd0]
    // 0xde4ddc: r0 = AllocateClosure()
    //     0xde4ddc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xde4de0: ldur            x1, [fp, #-8]
    // 0xde4de4: mov             x2, x0
    // 0xde4de8: r0 = setState()
    //     0xde4de8: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xde4dec: b               #0xde4e0c
    // 0xde4df0: mov             x2, x1
    // 0xde4df4: r1 = Function '<anonymous closure>':.
    //     0xde4df4: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4dd8] AnonymousClosure: (0xcfbb80), in [package:flutter/src/widgets/overlay.dart] _OverlayPortalState::show (0xcfbaf8)
    //     0xde4df8: ldr             x1, [x1, #0xdd8]
    // 0xde4dfc: r0 = AllocateClosure()
    //     0xde4dfc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xde4e00: ldur            x1, [fp, #-8]
    // 0xde4e04: mov             x2, x0
    // 0xde4e08: r0 = setState()
    //     0xde4e08: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xde4e0c: r0 = Null
    //     0xde4e0c: mov             x0, NULL
    // 0xde4e10: LeaveFrame
    //     0xde4e10: mov             SP, fp
    //     0xde4e14: ldp             fp, lr, [SP], #0x10
    // 0xde4e18: ret
    //     0xde4e18: ret             
    // 0xde4e1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde4e1c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde4e20: b               #0xde4d64
  }
  [closure] void _onPressedUpdate(dynamic, int, bool) {
    // ** addr: 0xde4e3c, size: 0x40
    // 0xde4e3c: EnterFrame
    //     0xde4e3c: stp             fp, lr, [SP, #-0x10]!
    //     0xde4e40: mov             fp, SP
    // 0xde4e44: ldr             x0, [fp, #0x20]
    // 0xde4e48: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xde4e48: ldur            w1, [x0, #0x17]
    // 0xde4e4c: DecompressPointer r1
    //     0xde4e4c: add             x1, x1, HEAP, lsl #32
    // 0xde4e50: CheckStackOverflow
    //     0xde4e50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde4e54: cmp             SP, x16
    //     0xde4e58: b.ls            #0xde4e74
    // 0xde4e5c: ldr             x2, [fp, #0x18]
    // 0xde4e60: ldr             x3, [fp, #0x10]
    // 0xde4e64: r0 = _onPressedUpdate()
    //     0xde4e64: bl              #0xde4d40  ; [package:flutter/src/cupertino/dialog.dart] _CupertinoActionSheetState::_onPressedUpdate
    // 0xde4e68: LeaveFrame
    //     0xde4e68: mov             SP, fp
    //     0xde4e6c: ldp             fp, lr, [SP], #0x10
    // 0xde4e70: ret
    //     0xde4e70: ret             
    // 0xde4e74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde4e74: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde4e78: b               #0xde4e5c
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10e48b4, size: 0x44
    // 0x10e48b4: EnterFrame
    //     0x10e48b4: stp             fp, lr, [SP, #-0x10]!
    //     0x10e48b8: mov             fp, SP
    // 0x10e48bc: CheckStackOverflow
    //     0x10e48bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e48c0: cmp             SP, x16
    //     0x10e48c4: b.ls            #0x10e48f0
    // 0x10e48c8: LoadField: r0 = r1->field_1b
    //     0x10e48c8: ldur            w0, [x1, #0x1b]
    // 0x10e48cc: DecompressPointer r0
    //     0x10e48cc: add             x0, x0, HEAP, lsl #32
    // 0x10e48d0: cmp             w0, NULL
    // 0x10e48d4: b.eq            #0x10e48e0
    // 0x10e48d8: mov             x1, x0
    // 0x10e48dc: r0 = dispose()
    //     0x10e48dc: bl              #0x10ef540  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::dispose
    // 0x10e48e0: r0 = Null
    //     0x10e48e0: mov             x0, NULL
    // 0x10e48e4: LeaveFrame
    //     0x10e48e4: mov             SP, fp
    //     0x10e48e8: ldp             fp, lr, [SP], #0x10
    // 0x10e48ec: ret
    //     0x10e48ec: ret             
    // 0x10e48f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e48f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e48f4: b               #0x10e48c8
  }
}

// class id: 5494, size: 0x20, field offset: 0x14
class _CupertinoAlertDialogState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0xde35ec, size: 0x138
    // 0xde35ec: EnterFrame
    //     0xde35ec: stp             fp, lr, [SP, #-0x10]!
    //     0xde35f0: mov             fp, SP
    // 0xde35f4: AllocStack(0x20)
    //     0xde35f4: sub             SP, SP, #0x20
    // 0xde35f8: SetupParameters(_CupertinoAlertDialogState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xde35f8: mov             x0, x1
    //     0xde35fc: stur            x1, [fp, #-8]
    //     0xde3600: mov             x1, x2
    //     0xde3604: stur            x2, [fp, #-0x10]
    // 0xde3608: CheckStackOverflow
    //     0xde3608: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde360c: cmp             SP, x16
    //     0xde3610: b.ls            #0xde371c
    // 0xde3614: r1 = 3
    //     0xde3614: mov             x1, #3
    // 0xde3618: r0 = AllocateContext()
    //     0xde3618: bl              #0x13de838  ; AllocateContextStub
    // 0xde361c: mov             x2, x0
    // 0xde3620: ldur            x0, [fp, #-8]
    // 0xde3624: stur            x2, [fp, #-0x18]
    // 0xde3628: StoreField: r2->field_f = r0
    //     0xde3628: stur            w0, [x2, #0xf]
    // 0xde362c: ldur            x1, [fp, #-0x10]
    // 0xde3630: r0 = of()
    //     0xde3630: bl              #0xde37f4  ; [package:flutter/src/cupertino/localizations.dart] CupertinoLocalizations::of
    // 0xde3634: ldur            x2, [fp, #-0x18]
    // 0xde3638: StoreField: r2->field_13 = r0
    //     0xde3638: stur            w0, [x2, #0x13]
    //     0xde363c: ldurb           w16, [x2, #-1]
    //     0xde3640: ldurb           w17, [x0, #-1]
    //     0xde3644: and             x16, x17, x16, lsr #2
    //     0xde3648: tst             x16, HEAP, lsr #32
    //     0xde364c: b.eq            #0xde3654
    //     0xde3650: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xde3654: ldur            x1, [fp, #-0x10]
    // 0xde3658: r0 = _isInAccessibilityMode()
    //     0xde3658: bl              #0xde3760  ; [package:flutter/src/cupertino/dialog.dart] ::_isInAccessibilityMode
    // 0xde365c: ldur            x2, [fp, #-0x18]
    // 0xde3660: ArrayStore: r2[0] = r0  ; List_4
    //     0xde3660: stur            w0, [x2, #0x17]
    // 0xde3664: ldur            x1, [fp, #-0x10]
    // 0xde3668: r0 = of()
    //     0xde3668: bl              #0xd3827c  ; [package:flutter/src/widgets/scroll_configuration.dart] ScrollConfiguration::of
    // 0xde366c: r1 = LoadClassIdInstr(r0)
    //     0xde366c: ldur            x1, [x0, #-1]
    //     0xde3670: ubfx            x1, x1, #0xc, #0x14
    // 0xde3674: mov             x16, x0
    // 0xde3678: mov             x0, x1
    // 0xde367c: mov             x1, x16
    // 0xde3680: r2 = false
    //     0xde3680: add             x2, NULL, #0x30  ; false
    // 0xde3684: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xde3684: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xde3688: r0 = GDT[cid_x0 + -0xffe]()
    //     0xde3688: sub             lr, x0, #0xffe
    //     0xde368c: ldr             lr, [x21, lr, lsl #3]
    //     0xde3690: blr             lr
    // 0xde3694: ldur            x2, [fp, #-0x18]
    // 0xde3698: r1 = Function '<anonymous closure>':.
    //     0xde3698: add             x1, PP, #0xab, lsl #12  ; [pp+0xab260] AnonymousClosure: (0xde384c), in [package:flutter/src/cupertino/dialog.dart] _CupertinoAlertDialogState::build (0xde35ec)
    //     0xde369c: ldr             x1, [x1, #0x260]
    // 0xde36a0: stur            x0, [fp, #-8]
    // 0xde36a4: r0 = AllocateClosure()
    //     0xde36a4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xde36a8: r1 = <BoxConstraints>
    //     0xde36a8: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c3f0] TypeArguments: <BoxConstraints>
    //     0xde36ac: ldr             x1, [x1, #0x3f0]
    // 0xde36b0: stur            x0, [fp, #-0x10]
    // 0xde36b4: r0 = LayoutBuilder()
    //     0xde36b4: bl              #0xd15d50  ; AllocateLayoutBuilderStub -> LayoutBuilder (size=0x14)
    // 0xde36b8: mov             x1, x0
    // 0xde36bc: ldur            x0, [fp, #-0x10]
    // 0xde36c0: stur            x1, [fp, #-0x18]
    // 0xde36c4: StoreField: r1->field_f = r0
    //     0xde36c4: stur            w0, [x1, #0xf]
    // 0xde36c8: r0 = ScrollConfiguration()
    //     0xde36c8: bl              #0xde3754  ; AllocateScrollConfigurationStub -> ScrollConfiguration (size=0x14)
    // 0xde36cc: mov             x1, x0
    // 0xde36d0: ldur            x0, [fp, #-8]
    // 0xde36d4: StoreField: r1->field_f = r0
    //     0xde36d4: stur            w0, [x1, #0xf]
    // 0xde36d8: ldur            x0, [fp, #-0x18]
    // 0xde36dc: StoreField: r1->field_b = r0
    //     0xde36dc: stur            w0, [x1, #0xb]
    // 0xde36e0: r16 = 1.000000
    //     0xde36e0: ldr             x16, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xde36e4: str             x16, [SP]
    // 0xde36e8: r4 = const [0, 0x2, 0x1, 0x1, minScaleFactor, 0x1, null]
    //     0xde36e8: add             x4, PP, #0xab, lsl #12  ; [pp+0xab268] List(7) [0, 0x2, 0x1, 0x1, "minScaleFactor", 0x1, Null]
    //     0xde36ec: ldr             x4, [x4, #0x268]
    // 0xde36f0: r0 = withClampedTextScaling()
    //     0xde36f0: bl              #0xd16294  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::withClampedTextScaling
    // 0xde36f4: stur            x0, [fp, #-8]
    // 0xde36f8: r0 = CupertinoUserInterfaceLevel()
    //     0xde36f8: bl              #0xde3748  ; AllocateCupertinoUserInterfaceLevelStub -> CupertinoUserInterfaceLevel (size=0x14)
    // 0xde36fc: r1 = Instance_CupertinoUserInterfaceLevelData
    //     0xde36fc: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e890] Obj!CupertinoUserInterfaceLevelData@12c5fe1
    //     0xde3700: ldr             x1, [x1, #0x890]
    // 0xde3704: StoreField: r0->field_f = r1
    //     0xde3704: stur            w1, [x0, #0xf]
    // 0xde3708: ldur            x1, [fp, #-8]
    // 0xde370c: StoreField: r0->field_b = r1
    //     0xde370c: stur            w1, [x0, #0xb]
    // 0xde3710: LeaveFrame
    //     0xde3710: mov             SP, fp
    //     0xde3714: ldp             fp, lr, [SP], #0x10
    // 0xde3718: ret
    //     0xde3718: ret             
    // 0xde371c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde371c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde3720: b               #0xde3614
  }
  [closure] AnimatedPadding <anonymous closure>(dynamic, BuildContext, BoxConstraints) {
    // ** addr: 0xde384c, size: 0x244
    // 0xde384c: EnterFrame
    //     0xde384c: stp             fp, lr, [SP, #-0x10]!
    //     0xde3850: mov             fp, SP
    // 0xde3854: AllocStack(0x58)
    //     0xde3854: sub             SP, SP, #0x58
    // 0xde3858: SetupParameters([dynamic _ /* r0 */])
    //     0xde3858: ldr             x0, [fp, #0x20]
    //     0xde385c: ldur            w2, [x0, #0x17]
    //     0xde3860: add             x2, x2, HEAP, lsl #32
    //     0xde3864: stur            x2, [fp, #-8]
    // 0xde3868: CheckStackOverflow
    //     0xde3868: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde386c: cmp             SP, x16
    //     0xde3870: b.ls            #0xde3a6c
    // 0xde3874: ldr             x1, [fp, #0x18]
    // 0xde3878: r0 = viewInsetsOf()
    //     0xde3878: bl              #0xd362b0  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::viewInsetsOf
    // 0xde387c: mov             x1, x0
    // 0xde3880: r2 = Instance_EdgeInsets
    //     0xde3880: add             x2, PP, #0x8c, lsl #12  ; [pp+0x8cc00] Obj!EdgeInsets@129d501
    //     0xde3884: ldr             x2, [x2, #0xc00]
    // 0xde3888: r0 = +()
    //     0xde3888: bl              #0x8584ec  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::+
    // 0xde388c: mov             x3, x0
    // 0xde3890: ldur            x2, [fp, #-8]
    // 0xde3894: stur            x3, [fp, #-0x10]
    // 0xde3898: LoadField: r0 = r2->field_f
    //     0xde3898: ldur            w0, [x2, #0xf]
    // 0xde389c: DecompressPointer r0
    //     0xde389c: add             x0, x0, HEAP, lsl #32
    // 0xde38a0: LoadField: r1 = r0->field_b
    //     0xde38a0: ldur            w1, [x0, #0xb]
    // 0xde38a4: DecompressPointer r1
    //     0xde38a4: add             x1, x1, HEAP, lsl #32
    // 0xde38a8: cmp             w1, NULL
    // 0xde38ac: b.eq            #0xde3a74
    // 0xde38b0: ArrayLoad: r0 = r2[0]  ; List_4
    //     0xde38b0: ldur            w0, [x2, #0x17]
    // 0xde38b4: DecompressPointer r0
    //     0xde38b4: add             x0, x0, HEAP, lsl #32
    // 0xde38b8: tbnz            w0, #4, #0xde38c8
    // 0xde38bc: d0 = 310.000000
    //     0xde38bc: add             x17, PP, #0xab, lsl #12  ; [pp+0xab270] IMM: double(310) from 0x4073600000000000
    //     0xde38c0: ldr             d0, [x17, #0x270]
    // 0xde38c4: b               #0xde38d0
    // 0xde38c8: d0 = 270.000000
    //     0xde38c8: add             x17, PP, #0x92, lsl #12  ; [pp+0x92e48] IMM: double(270) from 0x4070e00000000000
    //     0xde38cc: ldr             d0, [x17, #0xe48]
    // 0xde38d0: stur            d0, [fp, #-0x28]
    // 0xde38d4: LoadField: r1 = r2->field_13
    //     0xde38d4: ldur            w1, [x2, #0x13]
    // 0xde38d8: DecompressPointer r1
    //     0xde38d8: add             x1, x1, HEAP, lsl #32
    // 0xde38dc: r0 = LoadClassIdInstr(r1)
    //     0xde38dc: ldur            x0, [x1, #-1]
    //     0xde38e0: ubfx            x0, x0, #0xc, #0x14
    // 0xde38e4: r0 = GDT[cid_x0 + 0x16bb7]()
    //     0xde38e4: mov             x17, #0x6bb7
    //     0xde38e8: movk            x17, #1, lsl #16
    //     0xde38ec: add             lr, x0, x17
    //     0xde38f0: ldr             lr, [x21, lr, lsl #3]
    //     0xde38f4: blr             lr
    // 0xde38f8: mov             x3, x0
    // 0xde38fc: ldur            x0, [fp, #-8]
    // 0xde3900: stur            x3, [fp, #-0x18]
    // 0xde3904: LoadField: r1 = r0->field_f
    //     0xde3904: ldur            w1, [x0, #0xf]
    // 0xde3908: DecompressPointer r1
    //     0xde3908: add             x1, x1, HEAP, lsl #32
    // 0xde390c: ldr             x2, [fp, #0x18]
    // 0xde3910: r0 = _buildBody()
    //     0xde3910: bl              #0xde3b64  ; [package:flutter/src/cupertino/dialog.dart] _CupertinoAlertDialogState::_buildBody
    // 0xde3914: stur            x0, [fp, #-8]
    // 0xde3918: r0 = Semantics()
    //     0xde3918: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xde391c: stur            x0, [fp, #-0x20]
    // 0xde3920: r16 = Instance_SemanticsRole
    //     0xde3920: add             x16, PP, #0x80, lsl #12  ; [pp+0x80ac0] Obj!SemanticsRole@12c7921
    //     0xde3924: ldr             x16, [x16, #0xac0]
    // 0xde3928: r30 = true
    //     0xde3928: add             lr, NULL, #0x20  ; true
    // 0xde392c: stp             lr, x16, [SP, #0x20]
    // 0xde3930: r16 = true
    //     0xde3930: add             x16, NULL, #0x20  ; true
    // 0xde3934: r30 = true
    //     0xde3934: add             lr, NULL, #0x20  ; true
    // 0xde3938: stp             lr, x16, [SP, #0x10]
    // 0xde393c: ldur            x16, [fp, #-0x18]
    // 0xde3940: ldur            lr, [fp, #-8]
    // 0xde3944: stp             lr, x16, [SP]
    // 0xde3948: mov             x1, x0
    // 0xde394c: r4 = const [0, 0x7, 0x6, 0x1, child, 0x6, explicitChildNodes, 0x4, label, 0x5, namesRoute, 0x2, role, 0x1, scopesRoute, 0x3, null]
    //     0xde394c: add             x4, PP, #0xab, lsl #12  ; [pp+0xab278] List(17) [0, 0x7, 0x6, 0x1, "child", 0x6, "explicitChildNodes", 0x4, "label", 0x5, "namesRoute", 0x2, "role", 0x1, "scopesRoute", 0x3, Null]
    //     0xde3950: ldr             x4, [x4, #0x278]
    // 0xde3954: r0 = Semantics()
    //     0xde3954: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xde3958: r0 = CupertinoPopupSurface()
    //     0xde3958: bl              #0xde3b58  ; AllocateCupertinoPopupSurfaceStub -> CupertinoPopupSurface (size=0x1c)
    // 0xde395c: d0 = 30.000000
    //     0xde395c: fmov            d0, #30.00000000
    // 0xde3960: stur            x0, [fp, #-8]
    // 0xde3964: StoreField: r0->field_b = d0
    //     0xde3964: stur            d0, [x0, #0xb]
    // 0xde3968: r1 = false
    //     0xde3968: add             x1, NULL, #0x30  ; false
    // 0xde396c: StoreField: r0->field_13 = r1
    //     0xde396c: stur            w1, [x0, #0x13]
    // 0xde3970: ldur            x1, [fp, #-0x20]
    // 0xde3974: ArrayStore: r0[0] = r1  ; List_4
    //     0xde3974: stur            w1, [x0, #0x17]
    // 0xde3978: r0 = _ActionSheetGestureDetector()
    //     0xde3978: bl              #0xde3b4c  ; Allocate_ActionSheetGestureDetectorStub -> _ActionSheetGestureDetector (size=0x10)
    // 0xde397c: mov             x1, x0
    // 0xde3980: ldur            x0, [fp, #-8]
    // 0xde3984: stur            x1, [fp, #-0x18]
    // 0xde3988: StoreField: r1->field_b = r0
    //     0xde3988: stur            w0, [x1, #0xb]
    // 0xde398c: ldur            d0, [fp, #-0x28]
    // 0xde3990: r0 = inline_Allocate_Double()
    //     0xde3990: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xde3994: add             x0, x0, #0x10
    //     0xde3998: cmp             x2, x0
    //     0xde399c: b.ls            #0xde3a78
    //     0xde39a0: str             x0, [THR, #0x60]  ; THR::top
    //     0xde39a4: sub             x0, x0, #0xf
    //     0xde39a8: mov             x2, #0xe19c
    //     0xde39ac: movk            x2, #3, lsl #16
    //     0xde39b0: stur            x2, [x0, #-1]
    // 0xde39b4: dmb             ishst
    // 0xde39b8: StoreField: r0->field_7 = d0
    //     0xde39b8: stur            d0, [x0, #7]
    // 0xde39bc: stur            x0, [fp, #-8]
    // 0xde39c0: r0 = SizedBox()
    //     0xde39c0: bl              #0x8a7210  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0xde39c4: mov             x1, x0
    // 0xde39c8: ldur            x0, [fp, #-8]
    // 0xde39cc: stur            x1, [fp, #-0x20]
    // 0xde39d0: StoreField: r1->field_f = r0
    //     0xde39d0: stur            w0, [x1, #0xf]
    // 0xde39d4: ldur            x0, [fp, #-0x18]
    // 0xde39d8: StoreField: r1->field_b = r0
    //     0xde39d8: stur            w0, [x1, #0xb]
    // 0xde39dc: r0 = Padding()
    //     0xde39dc: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xde39e0: mov             x1, x0
    // 0xde39e4: r0 = Instance_EdgeInsets
    //     0xde39e4: add             x0, PP, #0x91, lsl #12  ; [pp+0x91948] Obj!EdgeInsets@129d4d1
    //     0xde39e8: ldr             x0, [x0, #0x948]
    // 0xde39ec: stur            x1, [fp, #-8]
    // 0xde39f0: StoreField: r1->field_f = r0
    //     0xde39f0: stur            w0, [x1, #0xf]
    // 0xde39f4: ldur            x0, [fp, #-0x20]
    // 0xde39f8: StoreField: r1->field_b = r0
    //     0xde39f8: stur            w0, [x1, #0xb]
    // 0xde39fc: r0 = Center()
    //     0xde39fc: bl              #0xd0c898  ; AllocateCenterStub -> Center (size=0x1c)
    // 0xde3a00: mov             x2, x0
    // 0xde3a04: r0 = Instance_Alignment
    //     0xde3a04: add             x0, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xde3a08: ldr             x0, [x0, #0xb80]
    // 0xde3a0c: stur            x2, [fp, #-0x18]
    // 0xde3a10: StoreField: r2->field_f = r0
    //     0xde3a10: stur            w0, [x2, #0xf]
    // 0xde3a14: ldur            x0, [fp, #-8]
    // 0xde3a18: StoreField: r2->field_b = r0
    //     0xde3a18: stur            w0, [x2, #0xb]
    // 0xde3a1c: r1 = <_MediaQueryAspect>
    //     0xde3a1c: add             x1, PP, #0x12, lsl #12  ; [pp+0x12828] TypeArguments: <_MediaQueryAspect>
    //     0xde3a20: ldr             x1, [x1, #0x828]
    // 0xde3a24: r0 = MediaQuery()
    //     0xde3a24: bl              #0xd0af24  ; AllocateMediaQueryStub -> MediaQuery (size=0x18)
    // 0xde3a28: mov             x1, x0
    // 0xde3a2c: ldur            x2, [fp, #-0x18]
    // 0xde3a30: ldr             x3, [fp, #0x18]
    // 0xde3a34: stur            x0, [fp, #-8]
    // 0xde3a38: r0 = MediaQuery.removeViewInsets()
    //     0xde3a38: bl              #0xde3a9c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::MediaQuery.removeViewInsets
    // 0xde3a3c: r0 = AnimatedPadding()
    //     0xde3a3c: bl              #0xde3a90  ; AllocateAnimatedPaddingStub -> AnimatedPadding (size=0x20)
    // 0xde3a40: ldur            x1, [fp, #-0x10]
    // 0xde3a44: ArrayStore: r0[0] = r1  ; List_4
    //     0xde3a44: stur            w1, [x0, #0x17]
    // 0xde3a48: ldur            x1, [fp, #-8]
    // 0xde3a4c: StoreField: r0->field_1b = r1
    //     0xde3a4c: stur            w1, [x0, #0x1b]
    // 0xde3a50: r1 = Instance__DecelerateCurve
    //     0xde3a50: ldr             x1, [PP, #0x5150]  ; [pp+0x5150] Obj!_DecelerateCurve@129f3d1
    // 0xde3a54: StoreField: r0->field_b = r1
    //     0xde3a54: stur            w1, [x0, #0xb]
    // 0xde3a58: r1 = Instance_Duration
    //     0xde3a58: ldr             x1, [PP, #0x5668]  ; [pp+0x5668] Obj!Duration@12c8941
    // 0xde3a5c: StoreField: r0->field_f = r1
    //     0xde3a5c: stur            w1, [x0, #0xf]
    // 0xde3a60: LeaveFrame
    //     0xde3a60: mov             SP, fp
    //     0xde3a64: ldp             fp, lr, [SP], #0x10
    // 0xde3a68: ret
    //     0xde3a68: ret             
    // 0xde3a6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde3a6c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde3a70: b               #0xde3874
    // 0xde3a74: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde3a74: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde3a78: SaveReg d0
    //     0xde3a78: str             q0, [SP, #-0x10]!
    // 0xde3a7c: SaveReg r1
    //     0xde3a7c: str             x1, [SP, #-8]!
    // 0xde3a80: r0 = AllocateDouble()
    //     0xde3a80: bl              #0x13df878  ; AllocateDoubleStub
    // 0xde3a84: RestoreReg r1
    //     0xde3a84: ldr             x1, [SP], #8
    // 0xde3a88: RestoreReg d0
    //     0xde3a88: ldr             q0, [SP], #0x10
    // 0xde3a8c: b               #0xde39b8
  }
  _ _buildBody(/* No info */) {
    // ** addr: 0xde3b64, size: 0x11c
    // 0xde3b64: EnterFrame
    //     0xde3b64: stp             fp, lr, [SP, #-0x10]!
    //     0xde3b68: mov             fp, SP
    // 0xde3b6c: AllocStack(0x38)
    //     0xde3b6c: sub             SP, SP, #0x38
    // 0xde3b70: SetupParameters(_CupertinoAlertDialogState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xde3b70: stur            x1, [fp, #-8]
    //     0xde3b74: stur            x2, [fp, #-0x10]
    // 0xde3b78: CheckStackOverflow
    //     0xde3b78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde3b7c: cmp             SP, x16
    //     0xde3b80: b.ls            #0xde3c78
    // 0xde3b84: r1 = 3
    //     0xde3b84: mov             x1, #3
    // 0xde3b88: r0 = AllocateContext()
    //     0xde3b88: bl              #0x13de838  ; AllocateContextStub
    // 0xde3b8c: mov             x3, x0
    // 0xde3b90: ldur            x0, [fp, #-8]
    // 0xde3b94: stur            x3, [fp, #-0x18]
    // 0xde3b98: StoreField: r3->field_f = r0
    //     0xde3b98: stur            w0, [x3, #0xf]
    // 0xde3b9c: ldur            x2, [fp, #-0x10]
    // 0xde3ba0: r1 = Instance_CupertinoDynamicColor
    //     0xde3ba0: add             x1, PP, #0xab, lsl #12  ; [pp+0xab280] Obj!CupertinoDynamicColor@12b3bf1
    //     0xde3ba4: ldr             x1, [x1, #0x280]
    // 0xde3ba8: r0 = resolveFrom()
    //     0xde3ba8: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0xde3bac: ldur            x3, [fp, #-0x18]
    // 0xde3bb0: StoreField: r3->field_13 = r0
    //     0xde3bb0: stur            w0, [x3, #0x13]
    //     0xde3bb4: ldurb           w16, [x3, #-1]
    //     0xde3bb8: ldurb           w17, [x0, #-1]
    //     0xde3bbc: and             x16, x17, x16, lsr #2
    //     0xde3bc0: tst             x16, HEAP, lsr #32
    //     0xde3bc4: b.eq            #0xde3bcc
    //     0xde3bc8: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xde3bcc: ldur            x2, [fp, #-0x10]
    // 0xde3bd0: r1 = Instance_CupertinoDynamicColor
    //     0xde3bd0: add             x1, PP, #0xab, lsl #12  ; [pp+0xab288] Obj!CupertinoDynamicColor@12b3bb1
    //     0xde3bd4: ldr             x1, [x1, #0x288]
    // 0xde3bd8: r0 = resolveFrom()
    //     0xde3bd8: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0xde3bdc: ldur            x2, [fp, #-0x18]
    // 0xde3be0: ArrayStore: r2[0] = r0  ; List_4
    //     0xde3be0: stur            w0, [x2, #0x17]
    //     0xde3be4: ldurb           w16, [x2, #-1]
    //     0xde3be8: ldurb           w17, [x0, #-1]
    //     0xde3bec: and             x16, x17, x16, lsr #2
    //     0xde3bf0: tst             x16, HEAP, lsr #32
    //     0xde3bf4: b.eq            #0xde3bfc
    //     0xde3bf8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xde3bfc: r1 = Function '<anonymous closure>':.
    //     0xde3bfc: add             x1, PP, #0xab, lsl #12  ; [pp+0xab290] AnonymousClosure: (0xde3c80), in [package:flutter/src/cupertino/dialog.dart] _CupertinoAlertDialogState::_buildBody (0xde3b64)
    //     0xde3c00: ldr             x1, [x1, #0x290]
    // 0xde3c04: r0 = AllocateClosure()
    //     0xde3c04: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xde3c08: r1 = <BoxConstraints>
    //     0xde3c08: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c3f0] TypeArguments: <BoxConstraints>
    //     0xde3c0c: ldr             x1, [x1, #0x3f0]
    // 0xde3c10: stur            x0, [fp, #-8]
    // 0xde3c14: r0 = LayoutBuilder()
    //     0xde3c14: bl              #0xd15d50  ; AllocateLayoutBuilderStub -> LayoutBuilder (size=0x14)
    // 0xde3c18: mov             x2, x0
    // 0xde3c1c: ldur            x0, [fp, #-8]
    // 0xde3c20: stur            x2, [fp, #-0x18]
    // 0xde3c24: StoreField: r2->field_f = r0
    //     0xde3c24: stur            w0, [x2, #0xf]
    // 0xde3c28: r1 = <_MediaQueryAspect>
    //     0xde3c28: add             x1, PP, #0x12, lsl #12  ; [pp+0x12828] TypeArguments: <_MediaQueryAspect>
    //     0xde3c2c: ldr             x1, [x1, #0x828]
    // 0xde3c30: r0 = MediaQuery()
    //     0xde3c30: bl              #0xd0af24  ; AllocateMediaQueryStub -> MediaQuery (size=0x18)
    // 0xde3c34: stur            x0, [fp, #-8]
    // 0xde3c38: r16 = true
    //     0xde3c38: add             x16, NULL, #0x20  ; true
    // 0xde3c3c: r30 = true
    //     0xde3c3c: add             lr, NULL, #0x20  ; true
    // 0xde3c40: stp             lr, x16, [SP, #0x10]
    // 0xde3c44: r16 = true
    //     0xde3c44: add             x16, NULL, #0x20  ; true
    // 0xde3c48: r30 = true
    //     0xde3c48: add             lr, NULL, #0x20  ; true
    // 0xde3c4c: stp             lr, x16, [SP]
    // 0xde3c50: mov             x1, x0
    // 0xde3c54: ldur            x2, [fp, #-0x18]
    // 0xde3c58: ldur            x3, [fp, #-0x10]
    // 0xde3c5c: r4 = const [0, 0x7, 0x4, 0x3, removeBottom, 0x6, removeLeft, 0x3, removeRight, 0x5, removeTop, 0x4, null]
    //     0xde3c5c: add             x4, PP, #0x26, lsl #12  ; [pp+0x26720] List(13) [0, 0x7, 0x4, 0x3, "removeBottom", 0x6, "removeLeft", 0x3, "removeRight", 0x5, "removeTop", 0x4, Null]
    //     0xde3c60: ldr             x4, [x4, #0x720]
    // 0xde3c64: r0 = MediaQuery.removePadding()
    //     0xde3c64: bl              #0xd0a5a0  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::MediaQuery.removePadding
    // 0xde3c68: ldur            x0, [fp, #-8]
    // 0xde3c6c: LeaveFrame
    //     0xde3c6c: mov             SP, fp
    //     0xde3c70: ldp             fp, lr, [SP], #0x10
    // 0xde3c74: ret
    //     0xde3c74: ret             
    // 0xde3c78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde3c78: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde3c7c: b               #0xde3b84
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext, BoxConstraints) {
    // ** addr: 0xde3c80, size: 0x234
    // 0xde3c80: EnterFrame
    //     0xde3c80: stp             fp, lr, [SP, #-0x10]!
    //     0xde3c84: mov             fp, SP
    // 0xde3c88: AllocStack(0x30)
    //     0xde3c88: sub             SP, SP, #0x30
    // 0xde3c8c: SetupParameters([dynamic _ /* r0 */])
    //     0xde3c8c: ldr             x0, [fp, #0x20]
    //     0xde3c90: ldur            w3, [x0, #0x17]
    //     0xde3c94: add             x3, x3, HEAP, lsl #32
    //     0xde3c98: stur            x3, [fp, #-8]
    // 0xde3c9c: CheckStackOverflow
    //     0xde3c9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde3ca0: cmp             SP, x16
    //     0xde3ca4: b.ls            #0xde3eac
    // 0xde3ca8: LoadField: r1 = r3->field_f
    //     0xde3ca8: ldur            w1, [x3, #0xf]
    // 0xde3cac: DecompressPointer r1
    //     0xde3cac: add             x1, x1, HEAP, lsl #32
    // 0xde3cb0: ldr             x2, [fp, #0x18]
    // 0xde3cb4: r0 = _buildContent()
    //     0xde3cb4: bl              #0xde4234  ; [package:flutter/src/cupertino/dialog.dart] _CupertinoAlertDialogState::_buildContent
    // 0xde3cb8: mov             x2, x0
    // 0xde3cbc: ldur            x0, [fp, #-8]
    // 0xde3cc0: stur            x2, [fp, #-0x10]
    // 0xde3cc4: LoadField: r1 = r0->field_f
    //     0xde3cc4: ldur            w1, [x0, #0xf]
    // 0xde3cc8: DecompressPointer r1
    //     0xde3cc8: add             x1, x1, HEAP, lsl #32
    // 0xde3ccc: r0 = _buildActions()
    //     0xde3ccc: bl              #0xde3f90  ; [package:flutter/src/cupertino/dialog.dart] _CupertinoAlertDialogState::_buildActions
    // 0xde3cd0: stur            x0, [fp, #-0x20]
    // 0xde3cd4: cmp             w0, NULL
    // 0xde3cd8: b.ne            #0xde3cec
    // 0xde3cdc: ldur            x0, [fp, #-0x10]
    // 0xde3ce0: LeaveFrame
    //     0xde3ce0: mov             SP, fp
    //     0xde3ce4: ldp             fp, lr, [SP], #0x10
    // 0xde3ce8: ret
    //     0xde3ce8: ret             
    // 0xde3cec: ldur            x1, [fp, #-8]
    // 0xde3cf0: LoadField: r2 = r1->field_13
    //     0xde3cf0: ldur            w2, [x1, #0x13]
    // 0xde3cf4: DecompressPointer r2
    //     0xde3cf4: add             x2, x2, HEAP, lsl #32
    // 0xde3cf8: stur            x2, [fp, #-0x18]
    // 0xde3cfc: r0 = _OverscrollBackground()
    //     0xde3cfc: bl              #0xde3f60  ; Allocate_OverscrollBackgroundStub -> _OverscrollBackground (size=0x14)
    // 0xde3d00: mov             x2, x0
    // 0xde3d04: ldur            x0, [fp, #-0x18]
    // 0xde3d08: stur            x2, [fp, #-0x28]
    // 0xde3d0c: StoreField: r2->field_b = r0
    //     0xde3d0c: stur            w0, [x2, #0xb]
    // 0xde3d10: ldur            x1, [fp, #-0x20]
    // 0xde3d14: StoreField: r2->field_f = r1
    //     0xde3d14: stur            w1, [x2, #0xf]
    // 0xde3d18: ldr             x1, [fp, #0x18]
    // 0xde3d1c: r0 = _isInAccessibilityMode()
    //     0xde3d1c: bl              #0xde3760  ; [package:flutter/src/cupertino/dialog.dart] ::_isInAccessibilityMode
    // 0xde3d20: tbnz            w0, #4, #0xde3d48
    // 0xde3d24: ldr             x0, [fp, #0x10]
    // 0xde3d28: d1 = 2.000000
    //     0xde3d28: fmov            d1, #2.00000000
    // 0xde3d2c: d0 = 0.300000
    //     0xde3d2c: add             x17, PP, #0x13, lsl #12  ; [pp+0x13a88] IMM: double(0.3) from 0x3fd3333333333333
    //     0xde3d30: ldr             d0, [x17, #0xa88]
    // 0xde3d34: LoadField: d2 = r0->field_1f
    //     0xde3d34: ldur            d2, [x0, #0x1f]
    // 0xde3d38: fdiv            d3, d2, d1
    // 0xde3d3c: fadd            d1, d3, d0
    // 0xde3d40: mov             v0.16b, v1.16b
    // 0xde3d44: b               #0xde3d50
    // 0xde3d48: d0 = 68.100000
    //     0xde3d48: add             x17, PP, #0xab, lsl #12  ; [pp+0xab298] IMM: double(68.1) from 0x4051066666666666
    //     0xde3d4c: ldr             d0, [x17, #0x298]
    // 0xde3d50: ldur            x2, [fp, #-8]
    // 0xde3d54: ldur            x1, [fp, #-0x28]
    // 0xde3d58: ldur            x0, [fp, #-0x18]
    // 0xde3d5c: stur            d0, [fp, #-0x30]
    // 0xde3d60: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xde3d60: ldur            w3, [x2, #0x17]
    // 0xde3d64: DecompressPointer r3
    //     0xde3d64: add             x3, x3, HEAP, lsl #32
    // 0xde3d68: stur            x3, [fp, #-0x20]
    // 0xde3d6c: r0 = _Divider()
    //     0xde3d6c: bl              #0xde3f54  ; Allocate_DividerStub -> _Divider (size=0x18)
    // 0xde3d70: mov             x1, x0
    // 0xde3d74: ldur            x0, [fp, #-0x20]
    // 0xde3d78: stur            x1, [fp, #-8]
    // 0xde3d7c: StoreField: r1->field_b = r0
    //     0xde3d7c: stur            w0, [x1, #0xb]
    // 0xde3d80: ldur            x0, [fp, #-0x18]
    // 0xde3d84: StoreField: r1->field_f = r0
    //     0xde3d84: stur            w0, [x1, #0xf]
    // 0xde3d88: r0 = false
    //     0xde3d88: add             x0, NULL, #0x30  ; false
    // 0xde3d8c: StoreField: r1->field_13 = r0
    //     0xde3d8c: stur            w0, [x1, #0x13]
    // 0xde3d90: r0 = SizedBox()
    //     0xde3d90: bl              #0x8a7210  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0xde3d94: mov             x2, x0
    // 0xde3d98: r0 = inf
    //     0xde3d98: add             x0, PP, #0x15, lsl #12  ; [pp+0x158a8] inf
    //     0xde3d9c: ldr             x0, [x0, #0x8a8]
    // 0xde3da0: stur            x2, [fp, #-0x18]
    // 0xde3da4: StoreField: r2->field_f = r0
    //     0xde3da4: stur            w0, [x2, #0xf]
    // 0xde3da8: ldur            x0, [fp, #-8]
    // 0xde3dac: StoreField: r2->field_b = r0
    //     0xde3dac: stur            w0, [x2, #0xb]
    // 0xde3db0: r1 = <FlexParentData>
    //     0xde3db0: add             x1, PP, #0x15, lsl #12  ; [pp+0x15878] TypeArguments: <FlexParentData>
    //     0xde3db4: ldr             x1, [x1, #0x878]
    // 0xde3db8: r0 = Flexible()
    //     0xde3db8: bl              #0xd0fd68  ; AllocateFlexibleStub -> Flexible (size=0x20)
    // 0xde3dbc: mov             x3, x0
    // 0xde3dc0: r0 = 1
    //     0xde3dc0: mov             x0, #1
    // 0xde3dc4: stur            x3, [fp, #-8]
    // 0xde3dc8: StoreField: r3->field_13 = r0
    //     0xde3dc8: stur            x0, [x3, #0x13]
    // 0xde3dcc: r0 = Instance_FlexFit
    //     0xde3dcc: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1ac30] Obj!FlexFit@12c4661
    //     0xde3dd0: ldr             x0, [x0, #0xc30]
    // 0xde3dd4: StoreField: r3->field_1b = r0
    //     0xde3dd4: stur            w0, [x3, #0x1b]
    // 0xde3dd8: ldur            x0, [fp, #-0x28]
    // 0xde3ddc: StoreField: r3->field_b = r0
    //     0xde3ddc: stur            w0, [x3, #0xb]
    // 0xde3de0: r1 = Null
    //     0xde3de0: mov             x1, NULL
    // 0xde3de4: r2 = 4
    //     0xde3de4: mov             x2, #4
    // 0xde3de8: r0 = AllocateArray()
    //     0xde3de8: bl              #0x13df928  ; AllocateArrayStub
    // 0xde3dec: mov             x2, x0
    // 0xde3df0: ldur            x0, [fp, #-0x18]
    // 0xde3df4: stur            x2, [fp, #-0x20]
    // 0xde3df8: StoreField: r2->field_f = r0
    //     0xde3df8: stur            w0, [x2, #0xf]
    // 0xde3dfc: ldur            x0, [fp, #-8]
    // 0xde3e00: StoreField: r2->field_13 = r0
    //     0xde3e00: stur            w0, [x2, #0x13]
    // 0xde3e04: r1 = <Widget>
    //     0xde3e04: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xde3e08: r0 = AllocateGrowableArray()
    //     0xde3e08: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xde3e0c: mov             x1, x0
    // 0xde3e10: ldur            x0, [fp, #-0x20]
    // 0xde3e14: stur            x1, [fp, #-8]
    // 0xde3e18: StoreField: r1->field_f = r0
    //     0xde3e18: stur            w0, [x1, #0xf]
    // 0xde3e1c: r0 = 4
    //     0xde3e1c: mov             x0, #4
    // 0xde3e20: StoreField: r1->field_b = r0
    //     0xde3e20: stur            w0, [x1, #0xb]
    // 0xde3e24: r0 = Column()
    //     0xde3e24: bl              #0x8a5b1c  ; AllocateColumnStub -> Column (size=0x38)
    // 0xde3e28: mov             x1, x0
    // 0xde3e2c: r0 = Instance_Axis
    //     0xde3e2c: ldr             x0, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xde3e30: stur            x1, [fp, #-0x18]
    // 0xde3e34: StoreField: r1->field_f = r0
    //     0xde3e34: stur            w0, [x1, #0xf]
    // 0xde3e38: r0 = Instance_MainAxisAlignment
    //     0xde3e38: add             x0, PP, #0x15, lsl #12  ; [pp+0x15820] Obj!MainAxisAlignment@12c4541
    //     0xde3e3c: ldr             x0, [x0, #0x820]
    // 0xde3e40: StoreField: r1->field_13 = r0
    //     0xde3e40: stur            w0, [x1, #0x13]
    // 0xde3e44: r0 = Instance_MainAxisSize
    //     0xde3e44: add             x0, PP, #0x15, lsl #12  ; [pp+0x15828] Obj!MainAxisSize@12c4621
    //     0xde3e48: ldr             x0, [x0, #0x828]
    // 0xde3e4c: ArrayStore: r1[0] = r0  ; List_4
    //     0xde3e4c: stur            w0, [x1, #0x17]
    // 0xde3e50: r0 = Instance_CrossAxisAlignment
    //     0xde3e50: add             x0, PP, #0x15, lsl #12  ; [pp+0x15888] Obj!CrossAxisAlignment@12c44a1
    //     0xde3e54: ldr             x0, [x0, #0x888]
    // 0xde3e58: StoreField: r1->field_1b = r0
    //     0xde3e58: stur            w0, [x1, #0x1b]
    // 0xde3e5c: r0 = Instance_VerticalDirection
    //     0xde3e5c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xde3e60: ldr             x0, [x0, #0x838]
    // 0xde3e64: StoreField: r1->field_23 = r0
    //     0xde3e64: stur            w0, [x1, #0x23]
    // 0xde3e68: r0 = Instance_Clip
    //     0xde3e68: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xde3e6c: ldr             x0, [x0, #0x840]
    // 0xde3e70: StoreField: r1->field_2b = r0
    //     0xde3e70: stur            w0, [x1, #0x2b]
    // 0xde3e74: StoreField: r1->field_2f = rZR
    //     0xde3e74: stur            xzr, [x1, #0x2f]
    // 0xde3e78: ldur            x0, [fp, #-8]
    // 0xde3e7c: StoreField: r1->field_b = r0
    //     0xde3e7c: stur            w0, [x1, #0xb]
    // 0xde3e80: r0 = _PriorityColumn()
    //     0xde3e80: bl              #0xde3f48  ; Allocate_PriorityColumnStub -> _PriorityColumn (size=0x18)
    // 0xde3e84: mov             x1, x0
    // 0xde3e88: ldur            x2, [fp, #-0x18]
    // 0xde3e8c: ldur            d0, [fp, #-0x30]
    // 0xde3e90: ldur            x3, [fp, #-0x10]
    // 0xde3e94: stur            x0, [fp, #-8]
    // 0xde3e98: r0 = _PriorityColumn()
    //     0xde3e98: bl              #0xde3eb4  ; [package:flutter/src/cupertino/dialog.dart] _PriorityColumn::_PriorityColumn
    // 0xde3e9c: ldur            x0, [fp, #-8]
    // 0xde3ea0: LeaveFrame
    //     0xde3ea0: mov             SP, fp
    //     0xde3ea4: ldp             fp, lr, [SP], #0x10
    // 0xde3ea8: ret
    //     0xde3ea8: ret             
    // 0xde3eac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde3eac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde3eb0: b               #0xde3ca8
  }
  _ _buildActions(/* No info */) {
    // ** addr: 0xde3f90, size: 0xe4
    // 0xde3f90: EnterFrame
    //     0xde3f90: stp             fp, lr, [SP, #-0x10]!
    //     0xde3f94: mov             fp, SP
    // 0xde3f98: AllocStack(0x28)
    //     0xde3f98: sub             SP, SP, #0x28
    // 0xde3f9c: SetupParameters(_CupertinoAlertDialogState this /* r1 => r0, fp-0x8 */)
    //     0xde3f9c: mov             x0, x1
    //     0xde3fa0: stur            x1, [fp, #-8]
    // 0xde3fa4: CheckStackOverflow
    //     0xde3fa4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde3fa8: cmp             SP, x16
    //     0xde3fac: b.ls            #0xde4064
    // 0xde3fb0: LoadField: r1 = r0->field_b
    //     0xde3fb0: ldur            w1, [x0, #0xb]
    // 0xde3fb4: DecompressPointer r1
    //     0xde3fb4: add             x1, x1, HEAP, lsl #32
    // 0xde3fb8: cmp             w1, NULL
    // 0xde3fbc: b.eq            #0xde406c
    // 0xde3fc0: LoadField: r2 = r1->field_13
    //     0xde3fc0: ldur            w2, [x1, #0x13]
    // 0xde3fc4: DecompressPointer r2
    //     0xde3fc4: add             x2, x2, HEAP, lsl #32
    // 0xde3fc8: LoadField: r1 = r2->field_b
    //     0xde3fc8: ldur            w1, [x2, #0xb]
    // 0xde3fcc: cbnz            w1, #0xde3fe0
    // 0xde3fd0: r0 = Null
    //     0xde3fd0: mov             x0, NULL
    // 0xde3fd4: LeaveFrame
    //     0xde3fd4: mov             SP, fp
    //     0xde3fd8: ldp             fp, lr, [SP], #0x10
    // 0xde3fdc: ret
    //     0xde3fdc: ret             
    // 0xde3fe0: mov             x1, x0
    // 0xde3fe4: r0 = _effectiveActionScrollController()
    //     0xde3fe4: bl              #0xde4080  ; [package:flutter/src/cupertino/dialog.dart] _CupertinoActionSheetState::_effectiveActionScrollController
    // 0xde3fe8: ldur            x2, [fp, #-8]
    // 0xde3fec: stur            x0, [fp, #-0x20]
    // 0xde3ff0: LoadField: r1 = r2->field_b
    //     0xde3ff0: ldur            w1, [x2, #0xb]
    // 0xde3ff4: DecompressPointer r1
    //     0xde3ff4: add             x1, x1, HEAP, lsl #32
    // 0xde3ff8: cmp             w1, NULL
    // 0xde3ffc: b.eq            #0xde4070
    // 0xde4000: LoadField: r3 = r1->field_13
    //     0xde4000: ldur            w3, [x1, #0x13]
    // 0xde4004: DecompressPointer r3
    //     0xde4004: add             x3, x3, HEAP, lsl #32
    // 0xde4008: stur            x3, [fp, #-0x18]
    // 0xde400c: LoadField: r1 = r2->field_13
    //     0xde400c: ldur            w1, [x2, #0x13]
    // 0xde4010: DecompressPointer r1
    //     0xde4010: add             x1, x1, HEAP, lsl #32
    // 0xde4014: stur            x1, [fp, #-0x10]
    // 0xde4018: r0 = _CupertinoAlertActionSection()
    //     0xde4018: bl              #0xde4074  ; Allocate_CupertinoAlertActionSectionStub -> _CupertinoAlertActionSection (size=0x1c)
    // 0xde401c: mov             x3, x0
    // 0xde4020: ldur            x0, [fp, #-0x18]
    // 0xde4024: stur            x3, [fp, #-0x28]
    // 0xde4028: StoreField: r3->field_b = r0
    //     0xde4028: stur            w0, [x3, #0xb]
    // 0xde402c: ldur            x2, [fp, #-8]
    // 0xde4030: r1 = Function '_onPressedUpdate@708079770':.
    //     0xde4030: add             x1, PP, #0xab, lsl #12  ; [pp+0xab2a0] AnonymousClosure: (0xde4110), in [package:flutter/src/cupertino/dialog.dart] _CupertinoAlertDialogState::_onPressedUpdate (0xde4150)
    //     0xde4034: ldr             x1, [x1, #0x2a0]
    // 0xde4038: r0 = AllocateClosure()
    //     0xde4038: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xde403c: mov             x1, x0
    // 0xde4040: ldur            x0, [fp, #-0x28]
    // 0xde4044: StoreField: r0->field_f = r1
    //     0xde4044: stur            w1, [x0, #0xf]
    // 0xde4048: ldur            x1, [fp, #-0x10]
    // 0xde404c: StoreField: r0->field_13 = r1
    //     0xde404c: stur            w1, [x0, #0x13]
    // 0xde4050: ldur            x1, [fp, #-0x20]
    // 0xde4054: ArrayStore: r0[0] = r1  ; List_4
    //     0xde4054: stur            w1, [x0, #0x17]
    // 0xde4058: LeaveFrame
    //     0xde4058: mov             SP, fp
    //     0xde405c: ldp             fp, lr, [SP], #0x10
    // 0xde4060: ret
    //     0xde4060: ret             
    // 0xde4064: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde4064: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde4068: b               #0xde3fb0
    // 0xde406c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde406c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde4070: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde4070: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _onPressedUpdate(dynamic, int, bool) {
    // ** addr: 0xde4110, size: 0x40
    // 0xde4110: EnterFrame
    //     0xde4110: stp             fp, lr, [SP, #-0x10]!
    //     0xde4114: mov             fp, SP
    // 0xde4118: ldr             x0, [fp, #0x20]
    // 0xde411c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xde411c: ldur            w1, [x0, #0x17]
    // 0xde4120: DecompressPointer r1
    //     0xde4120: add             x1, x1, HEAP, lsl #32
    // 0xde4124: CheckStackOverflow
    //     0xde4124: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde4128: cmp             SP, x16
    //     0xde412c: b.ls            #0xde4148
    // 0xde4130: ldr             x2, [fp, #0x18]
    // 0xde4134: ldr             x3, [fp, #0x10]
    // 0xde4138: r0 = _onPressedUpdate()
    //     0xde4138: bl              #0xde4150  ; [package:flutter/src/cupertino/dialog.dart] _CupertinoAlertDialogState::_onPressedUpdate
    // 0xde413c: LeaveFrame
    //     0xde413c: mov             SP, fp
    //     0xde4140: ldp             fp, lr, [SP], #0x10
    // 0xde4144: ret
    //     0xde4144: ret             
    // 0xde4148: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde4148: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde414c: b               #0xde4130
  }
  _ _onPressedUpdate(/* No info */) {
    // ** addr: 0xde4150, size: 0xe4
    // 0xde4150: EnterFrame
    //     0xde4150: stp             fp, lr, [SP, #-0x10]!
    //     0xde4154: mov             fp, SP
    // 0xde4158: AllocStack(0x18)
    //     0xde4158: sub             SP, SP, #0x18
    // 0xde415c: SetupParameters(_CupertinoAlertDialogState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xde415c: stur            x1, [fp, #-8]
    //     0xde4160: stur            x2, [fp, #-0x10]
    //     0xde4164: stur            x3, [fp, #-0x18]
    // 0xde4168: CheckStackOverflow
    //     0xde4168: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde416c: cmp             SP, x16
    //     0xde4170: b.ls            #0xde422c
    // 0xde4174: r1 = 2
    //     0xde4174: mov             x1, #2
    // 0xde4178: r0 = AllocateContext()
    //     0xde4178: bl              #0x13de838  ; AllocateContextStub
    // 0xde417c: mov             x1, x0
    // 0xde4180: ldur            x0, [fp, #-8]
    // 0xde4184: StoreField: r1->field_f = r0
    //     0xde4184: stur            w0, [x1, #0xf]
    // 0xde4188: ldur            x2, [fp, #-0x10]
    // 0xde418c: StoreField: r1->field_13 = r2
    //     0xde418c: stur            w2, [x1, #0x13]
    // 0xde4190: ldur            x3, [fp, #-0x18]
    // 0xde4194: tbnz            w3, #4, #0xde41b8
    // 0xde4198: mov             x2, x1
    // 0xde419c: r1 = Function '<anonymous closure>':.
    //     0xde419c: add             x1, PP, #0xab, lsl #12  ; [pp+0xab2a8] AnonymousClosure: (0xcfbb80), in [package:flutter/src/widgets/overlay.dart] _OverlayPortalState::show (0xcfbaf8)
    //     0xde41a0: ldr             x1, [x1, #0x2a8]
    // 0xde41a4: r0 = AllocateClosure()
    //     0xde41a4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xde41a8: ldur            x1, [fp, #-8]
    // 0xde41ac: mov             x2, x0
    // 0xde41b0: r0 = setState()
    //     0xde41b0: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xde41b4: b               #0xde421c
    // 0xde41b8: LoadField: r3 = r0->field_13
    //     0xde41b8: ldur            w3, [x0, #0x13]
    // 0xde41bc: DecompressPointer r3
    //     0xde41bc: add             x3, x3, HEAP, lsl #32
    // 0xde41c0: cmp             w3, w2
    // 0xde41c4: b.eq            #0xde4200
    // 0xde41c8: and             w16, w3, w2
    // 0xde41cc: branchIfSmi(r16, 0xde421c)
    //     0xde41cc: tbz             w16, #0, #0xde421c
    // 0xde41d0: r16 = LoadClassIdInstr(r3)
    //     0xde41d0: ldur            x16, [x3, #-1]
    //     0xde41d4: ubfx            x16, x16, #0xc, #0x14
    // 0xde41d8: cmp             x16, #0x3d
    // 0xde41dc: b.ne            #0xde421c
    // 0xde41e0: r16 = LoadClassIdInstr(r2)
    //     0xde41e0: ldur            x16, [x2, #-1]
    //     0xde41e4: ubfx            x16, x16, #0xc, #0x14
    // 0xde41e8: cmp             x16, #0x3d
    // 0xde41ec: b.ne            #0xde421c
    // 0xde41f0: LoadField: r16 = r3->field_7
    //     0xde41f0: ldur            x16, [x3, #7]
    // 0xde41f4: LoadField: r17 = r2->field_7
    //     0xde41f4: ldur            x17, [x2, #7]
    // 0xde41f8: cmp             x16, x17
    // 0xde41fc: b.ne            #0xde421c
    // 0xde4200: mov             x2, x1
    // 0xde4204: r1 = Function '<anonymous closure>':.
    //     0xde4204: add             x1, PP, #0xab, lsl #12  ; [pp+0xab2b0] AnonymousClosure: (0xbaf364), in [package:flutter/src/widgets/overlay.dart] _OverlayPortalState::hide (0xbaf384)
    //     0xde4208: ldr             x1, [x1, #0x2b0]
    // 0xde420c: r0 = AllocateClosure()
    //     0xde420c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xde4210: ldur            x1, [fp, #-8]
    // 0xde4214: mov             x2, x0
    // 0xde4218: r0 = setState()
    //     0xde4218: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xde421c: r0 = Null
    //     0xde421c: mov             x0, NULL
    // 0xde4220: LeaveFrame
    //     0xde4220: mov             SP, fp
    //     0xde4224: ldp             fp, lr, [SP], #0x10
    // 0xde4228: ret
    //     0xde4228: ret             
    // 0xde422c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde422c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde4230: b               #0xde4174
  }
  _ _buildContent(/* No info */) {
    // ** addr: 0xde4234, size: 0x208
    // 0xde4234: EnterFrame
    //     0xde4234: stp             fp, lr, [SP, #-0x10]!
    //     0xde4238: mov             fp, SP
    // 0xde423c: AllocStack(0x60)
    //     0xde423c: sub             SP, SP, #0x60
    // 0xde4240: SetupParameters(_CupertinoAlertDialogState this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xde4240: mov             x0, x2
    //     0xde4244: stur            x2, [fp, #-0x10]
    //     0xde4248: mov             x2, x1
    //     0xde424c: stur            x1, [fp, #-8]
    // 0xde4250: CheckStackOverflow
    //     0xde4250: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde4254: cmp             SP, x16
    //     0xde4258: b.ls            #0xde4428
    // 0xde425c: LoadField: r1 = r2->field_b
    //     0xde425c: ldur            w1, [x2, #0xb]
    // 0xde4260: DecompressPointer r1
    //     0xde4260: add             x1, x1, HEAP, lsl #32
    // 0xde4264: cmp             w1, NULL
    // 0xde4268: b.eq            #0xde4430
    // 0xde426c: mov             x1, x0
    // 0xde4270: r0 = textScalerOf()
    //     0xde4270: bl              #0xd16168  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::textScalerOf
    // 0xde4274: r1 = LoadClassIdInstr(r0)
    //     0xde4274: ldur            x1, [x0, #-1]
    //     0xde4278: ubfx            x1, x1, #0xc, #0x14
    // 0xde427c: mov             x16, x0
    // 0xde4280: mov             x0, x1
    // 0xde4284: mov             x1, x16
    // 0xde4288: d0 = 14.000000
    //     0xde4288: fmov            d0, #14.00000000
    // 0xde428c: r0 = GDT[cid_x0 + -0x1000]()
    //     0xde428c: sub             lr, x0, #1, lsl #12
    //     0xde4290: ldr             lr, [x21, lr, lsl #3]
    //     0xde4294: blr             lr
    // 0xde4298: LoadField: d0 = r0->field_7
    //     0xde4298: ldur            d0, [x0, #7]
    // 0xde429c: d1 = 14.000000
    //     0xde429c: fmov            d1, #14.00000000
    // 0xde42a0: fdiv            d2, d0, d1
    // 0xde42a4: ldur            x0, [fp, #-8]
    // 0xde42a8: stur            d2, [fp, #-0x50]
    // 0xde42ac: LoadField: r1 = r0->field_b
    //     0xde42ac: ldur            w1, [x0, #0xb]
    // 0xde42b0: DecompressPointer r1
    //     0xde42b0: add             x1, x1, HEAP, lsl #32
    // 0xde42b4: cmp             w1, NULL
    // 0xde42b8: b.eq            #0xde4434
    // 0xde42bc: LoadField: r2 = r1->field_b
    //     0xde42bc: ldur            w2, [x1, #0xb]
    // 0xde42c0: DecompressPointer r2
    //     0xde42c0: add             x2, x2, HEAP, lsl #32
    // 0xde42c4: stur            x2, [fp, #-0x20]
    // 0xde42c8: LoadField: r3 = r1->field_f
    //     0xde42c8: ldur            w3, [x1, #0xf]
    // 0xde42cc: DecompressPointer r3
    //     0xde42cc: add             x3, x3, HEAP, lsl #32
    // 0xde42d0: mov             x1, x0
    // 0xde42d4: stur            x3, [fp, #-0x18]
    // 0xde42d8: r0 = _effectiveScrollController()
    //     0xde42d8: bl              #0xde4448  ; [package:flutter/src/cupertino/dialog.dart] _CupertinoAlertDialogState::_effectiveScrollController
    // 0xde42dc: mov             x1, x0
    // 0xde42e0: ldur            x0, [fp, #-8]
    // 0xde42e4: stur            x1, [fp, #-0x28]
    // 0xde42e8: LoadField: r2 = r0->field_b
    //     0xde42e8: ldur            w2, [x0, #0xb]
    // 0xde42ec: DecompressPointer r2
    //     0xde42ec: add             x2, x2, HEAP, lsl #32
    // 0xde42f0: cmp             w2, NULL
    // 0xde42f4: b.eq            #0xde4438
    // 0xde42f8: ldur            d0, [fp, #-0x50]
    // 0xde42fc: d1 = 20.000000
    //     0xde42fc: fmov            d1, #20.00000000
    // 0xde4300: fmul            d2, d0, d1
    // 0xde4304: stur            d2, [fp, #-0x58]
    // 0xde4308: r0 = EdgeInsets()
    //     0xde4308: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xde430c: d0 = 20.000000
    //     0xde430c: fmov            d0, #20.00000000
    // 0xde4310: stur            x0, [fp, #-8]
    // 0xde4314: StoreField: r0->field_7 = d0
    //     0xde4314: stur            d0, [x0, #7]
    // 0xde4318: ldur            d1, [fp, #-0x58]
    // 0xde431c: StoreField: r0->field_f = d1
    //     0xde431c: stur            d1, [x0, #0xf]
    // 0xde4320: ArrayStore: r0[0] = d0  ; List_8
    //     0xde4320: stur            d0, [x0, #0x17]
    // 0xde4324: d2 = 1.000000
    //     0xde4324: fmov            d2, #1.00000000
    // 0xde4328: StoreField: r0->field_1f = d2
    //     0xde4328: stur            d2, [x0, #0x1f]
    // 0xde432c: r0 = EdgeInsets()
    //     0xde432c: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xde4330: d0 = 20.000000
    //     0xde4330: fmov            d0, #20.00000000
    // 0xde4334: stur            x0, [fp, #-0x30]
    // 0xde4338: StoreField: r0->field_7 = d0
    //     0xde4338: stur            d0, [x0, #7]
    // 0xde433c: d1 = 1.000000
    //     0xde433c: fmov            d1, #1.00000000
    // 0xde4340: StoreField: r0->field_f = d1
    //     0xde4340: stur            d1, [x0, #0xf]
    // 0xde4344: ArrayStore: r0[0] = d0  ; List_8
    //     0xde4344: stur            d0, [x0, #0x17]
    // 0xde4348: ldur            d0, [fp, #-0x58]
    // 0xde434c: StoreField: r0->field_1f = d0
    //     0xde434c: stur            d0, [x0, #0x1f]
    // 0xde4350: ldur            x2, [fp, #-0x10]
    // 0xde4354: r1 = Instance_CupertinoDynamicColor
    //     0xde4354: add             x1, PP, #0xab, lsl #12  ; [pp+0xab2b8] Obj!CupertinoDynamicColor@12b3731
    //     0xde4358: ldr             x1, [x1, #0x2b8]
    // 0xde435c: r0 = resolveFrom()
    //     0xde435c: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0xde4360: str             x0, [SP]
    // 0xde4364: r1 = Instance_TextStyle
    //     0xde4364: add             x1, PP, #0xab, lsl #12  ; [pp+0xab2c0] Obj!TextStyle@12b0d21
    //     0xde4368: ldr             x1, [x1, #0x2c0]
    // 0xde436c: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0xde436c: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0xde4370: ldr             x4, [x4, #0x7f0]
    // 0xde4374: r0 = copyWith()
    //     0xde4374: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xde4378: ldur            x2, [fp, #-0x10]
    // 0xde437c: r1 = Instance_CupertinoDynamicColor
    //     0xde437c: add             x1, PP, #0xab, lsl #12  ; [pp+0xab2b8] Obj!CupertinoDynamicColor@12b3731
    //     0xde4380: ldr             x1, [x1, #0x2b8]
    // 0xde4384: stur            x0, [fp, #-0x38]
    // 0xde4388: r0 = resolveFrom()
    //     0xde4388: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0xde438c: str             x0, [SP]
    // 0xde4390: r1 = Instance_TextStyle
    //     0xde4390: add             x1, PP, #0xab, lsl #12  ; [pp+0xab2c8] Obj!TextStyle@12b0cb1
    //     0xde4394: ldr             x1, [x1, #0x2c8]
    // 0xde4398: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0xde4398: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0xde439c: ldr             x4, [x4, #0x7f0]
    // 0xde43a0: r0 = copyWith()
    //     0xde43a0: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xde43a4: stur            x0, [fp, #-0x40]
    // 0xde43a8: r0 = _CupertinoAlertContentSection()
    //     0xde43a8: bl              #0xde443c  ; Allocate_CupertinoAlertContentSectionStub -> _CupertinoAlertContentSection (size=0x2c)
    // 0xde43ac: mov             x3, x0
    // 0xde43b0: ldur            x0, [fp, #-0x20]
    // 0xde43b4: stur            x3, [fp, #-0x48]
    // 0xde43b8: StoreField: r3->field_b = r0
    //     0xde43b8: stur            w0, [x3, #0xb]
    // 0xde43bc: ldur            x0, [fp, #-0x18]
    // 0xde43c0: StoreField: r3->field_f = r0
    //     0xde43c0: stur            w0, [x3, #0xf]
    // 0xde43c4: ldur            x0, [fp, #-0x28]
    // 0xde43c8: StoreField: r3->field_13 = r0
    //     0xde43c8: stur            w0, [x3, #0x13]
    // 0xde43cc: ldur            x0, [fp, #-8]
    // 0xde43d0: ArrayStore: r3[0] = r0  ; List_4
    //     0xde43d0: stur            w0, [x3, #0x17]
    // 0xde43d4: ldur            x0, [fp, #-0x30]
    // 0xde43d8: StoreField: r3->field_1b = r0
    //     0xde43d8: stur            w0, [x3, #0x1b]
    // 0xde43dc: ldur            x0, [fp, #-0x38]
    // 0xde43e0: StoreField: r3->field_23 = r0
    //     0xde43e0: stur            w0, [x3, #0x23]
    // 0xde43e4: ldur            x0, [fp, #-0x40]
    // 0xde43e8: StoreField: r3->field_27 = r0
    //     0xde43e8: stur            w0, [x3, #0x27]
    // 0xde43ec: ldur            x2, [fp, #-0x10]
    // 0xde43f0: r1 = Instance_CupertinoDynamicColor
    //     0xde43f0: add             x1, PP, #0xab, lsl #12  ; [pp+0xab280] Obj!CupertinoDynamicColor@12b3bf1
    //     0xde43f4: ldr             x1, [x1, #0x280]
    // 0xde43f8: r0 = resolveFrom()
    //     0xde43f8: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0xde43fc: stur            x0, [fp, #-8]
    // 0xde4400: r0 = ColoredBox()
    //     0xde4400: bl              #0xd1a914  ; AllocateColoredBoxStub -> ColoredBox (size=0x18)
    // 0xde4404: ldur            x1, [fp, #-8]
    // 0xde4408: StoreField: r0->field_f = r1
    //     0xde4408: stur            w1, [x0, #0xf]
    // 0xde440c: r1 = true
    //     0xde440c: add             x1, NULL, #0x20  ; true
    // 0xde4410: StoreField: r0->field_13 = r1
    //     0xde4410: stur            w1, [x0, #0x13]
    // 0xde4414: ldur            x1, [fp, #-0x48]
    // 0xde4418: StoreField: r0->field_b = r1
    //     0xde4418: stur            w1, [x0, #0xb]
    // 0xde441c: LeaveFrame
    //     0xde441c: mov             SP, fp
    //     0xde4420: ldp             fp, lr, [SP], #0x10
    // 0xde4424: ret
    //     0xde4424: ret             
    // 0xde4428: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde4428: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde442c: b               #0xde425c
    // 0xde4430: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde4430: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde4434: r0 = NullCastErrorSharedWithFPURegs()
    //     0xde4434: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xde4438: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde4438: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _effectiveScrollController(/* No info */) {
    // ** addr: 0xde4448, size: 0x90
    // 0xde4448: EnterFrame
    //     0xde4448: stp             fp, lr, [SP, #-0x10]!
    //     0xde444c: mov             fp, SP
    // 0xde4450: AllocStack(0x10)
    //     0xde4450: sub             SP, SP, #0x10
    // 0xde4454: SetupParameters(_CupertinoAlertDialogState this /* r1 => r1, fp-0x8 */)
    //     0xde4454: stur            x1, [fp, #-8]
    // 0xde4458: CheckStackOverflow
    //     0xde4458: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde445c: cmp             SP, x16
    //     0xde4460: b.ls            #0xde44cc
    // 0xde4464: LoadField: r0 = r1->field_b
    //     0xde4464: ldur            w0, [x1, #0xb]
    // 0xde4468: DecompressPointer r0
    //     0xde4468: add             x0, x0, HEAP, lsl #32
    // 0xde446c: cmp             w0, NULL
    // 0xde4470: b.eq            #0xde44d4
    // 0xde4474: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xde4474: ldur            w0, [x1, #0x17]
    // 0xde4478: DecompressPointer r0
    //     0xde4478: add             x0, x0, HEAP, lsl #32
    // 0xde447c: cmp             w0, NULL
    // 0xde4480: b.ne            #0xde44c0
    // 0xde4484: r0 = ScrollController()
    //     0xde4484: bl              #0x86d97c  ; AllocateScrollControllerStub -> ScrollController (size=0x40)
    // 0xde4488: mov             x1, x0
    // 0xde448c: stur            x0, [fp, #-0x10]
    // 0xde4490: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xde4490: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xde4494: r0 = ScrollController()
    //     0xde4494: bl              #0x86d884  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::ScrollController
    // 0xde4498: ldur            x0, [fp, #-0x10]
    // 0xde449c: ldur            x1, [fp, #-8]
    // 0xde44a0: ArrayStore: r1[0] = r0  ; List_4
    //     0xde44a0: stur            w0, [x1, #0x17]
    //     0xde44a4: ldurb           w16, [x1, #-1]
    //     0xde44a8: ldurb           w17, [x0, #-1]
    //     0xde44ac: and             x16, x17, x16, lsr #2
    //     0xde44b0: tst             x16, HEAP, lsr #32
    //     0xde44b4: b.eq            #0xde44bc
    //     0xde44b8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xde44bc: ldur            x0, [fp, #-0x10]
    // 0xde44c0: LeaveFrame
    //     0xde44c0: mov             SP, fp
    //     0xde44c4: ldp             fp, lr, [SP], #0x10
    // 0xde44c8: ret
    //     0xde44c8: ret             
    // 0xde44cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde44cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde44d0: b               #0xde4464
    // 0xde44d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde44d4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10e4850, size: 0x64
    // 0x10e4850: EnterFrame
    //     0x10e4850: stp             fp, lr, [SP, #-0x10]!
    //     0x10e4854: mov             fp, SP
    // 0x10e4858: AllocStack(0x8)
    //     0x10e4858: sub             SP, SP, #8
    // 0x10e485c: SetupParameters(_CupertinoAlertDialogState this /* r1 => r0, fp-0x8 */)
    //     0x10e485c: mov             x0, x1
    //     0x10e4860: stur            x1, [fp, #-8]
    // 0x10e4864: CheckStackOverflow
    //     0x10e4864: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e4868: cmp             SP, x16
    //     0x10e486c: b.ls            #0x10e48ac
    // 0x10e4870: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x10e4870: ldur            w1, [x0, #0x17]
    // 0x10e4874: DecompressPointer r1
    //     0x10e4874: add             x1, x1, HEAP, lsl #32
    // 0x10e4878: cmp             w1, NULL
    // 0x10e487c: b.eq            #0x10e4888
    // 0x10e4880: r0 = dispose()
    //     0x10e4880: bl              #0x10ef540  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::dispose
    // 0x10e4884: ldur            x0, [fp, #-8]
    // 0x10e4888: LoadField: r1 = r0->field_1b
    //     0x10e4888: ldur            w1, [x0, #0x1b]
    // 0x10e488c: DecompressPointer r1
    //     0x10e488c: add             x1, x1, HEAP, lsl #32
    // 0x10e4890: cmp             w1, NULL
    // 0x10e4894: b.eq            #0x10e489c
    // 0x10e4898: r0 = dispose()
    //     0x10e4898: bl              #0x10ef540  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::dispose
    // 0x10e489c: r0 = Null
    //     0x10e489c: mov             x0, NULL
    // 0x10e48a0: LeaveFrame
    //     0x10e48a0: mov             SP, fp
    //     0x10e48a4: ldp             fp, lr, [SP], #0x10
    // 0x10e48a8: ret
    //     0x10e48a8: ret             
    // 0x10e48ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e48ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e48b0: b               #0x10e4870
  }
}

// class id: 6201, size: 0x1c, field offset: 0xc
//   const constructor, 
class _CupertinoAlertActionSection extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfad514, size: 0x54c
    // 0xfad514: EnterFrame
    //     0xfad514: stp             fp, lr, [SP, #-0x10]!
    //     0xfad518: mov             fp, SP
    // 0xfad51c: AllocStack(0x60)
    //     0xfad51c: sub             SP, SP, #0x60
    // 0xfad520: SetupParameters(_CupertinoAlertActionSection this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xfad520: stur            x1, [fp, #-8]
    //     0xfad524: stur            x2, [fp, #-0x10]
    // 0xfad528: CheckStackOverflow
    //     0xfad528: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfad52c: cmp             SP, x16
    //     0xfad530: b.ls            #0xfada4c
    // 0xfad534: r1 = 1
    //     0xfad534: mov             x1, #1
    // 0xfad538: r0 = AllocateContext()
    //     0xfad538: bl              #0x13de838  ; AllocateContextStub
    // 0xfad53c: mov             x3, x0
    // 0xfad540: ldur            x0, [fp, #-8]
    // 0xfad544: stur            x3, [fp, #-0x18]
    // 0xfad548: StoreField: r3->field_f = r0
    //     0xfad548: stur            w0, [x3, #0xf]
    // 0xfad54c: ldur            x2, [fp, #-0x10]
    // 0xfad550: r1 = Instance_CupertinoDynamicColor
    //     0xfad550: add             x1, PP, #0xab, lsl #12  ; [pp+0xab280] Obj!CupertinoDynamicColor@12b3bf1
    //     0xfad554: ldr             x1, [x1, #0x280]
    // 0xfad558: r0 = resolveFrom()
    //     0xfad558: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0xfad55c: ldur            x2, [fp, #-0x10]
    // 0xfad560: r1 = Instance_CupertinoDynamicColor
    //     0xfad560: add             x1, PP, #0xb0, lsl #12  ; [pp+0xb08e8] Obj!CupertinoDynamicColor@12b3ef1
    //     0xfad564: ldr             x1, [x1, #0x8e8]
    // 0xfad568: stur            x0, [fp, #-0x20]
    // 0xfad56c: r0 = resolveFrom()
    //     0xfad56c: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0xfad570: ldur            x2, [fp, #-0x10]
    // 0xfad574: r1 = Instance_CupertinoDynamicColor
    //     0xfad574: add             x1, PP, #0xab, lsl #12  ; [pp+0xab288] Obj!CupertinoDynamicColor@12b3bb1
    //     0xfad578: ldr             x1, [x1, #0x288]
    // 0xfad57c: stur            x0, [fp, #-0x10]
    // 0xfad580: r0 = resolveFrom()
    //     0xfad580: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0xfad584: r1 = <Widget>
    //     0xfad584: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xfad588: r2 = 0
    //     0xfad588: mov             x2, #0
    // 0xfad58c: stur            x0, [fp, #-0x28]
    // 0xfad590: r0 = _GrowableList()
    //     0xfad590: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xfad594: stur            x0, [fp, #-0x30]
    // 0xfad598: r1 = 1
    //     0xfad598: mov             x1, #1
    // 0xfad59c: r0 = AllocateContext()
    //     0xfad59c: bl              #0x13de838  ; AllocateContextStub
    // 0xfad5a0: mov             x1, x0
    // 0xfad5a4: ldur            x0, [fp, #-0x18]
    // 0xfad5a8: StoreField: r1->field_b = r0
    //     0xfad5a8: stur            w0, [x1, #0xb]
    // 0xfad5ac: StoreField: r1->field_f = rZR
    //     0xfad5ac: stur            wzr, [x1, #0xf]
    // 0xfad5b0: ldur            x2, [fp, #-8]
    // 0xfad5b4: LoadField: r3 = r2->field_b
    //     0xfad5b4: ldur            w3, [x2, #0xb]
    // 0xfad5b8: DecompressPointer r3
    //     0xfad5b8: add             x3, x3, HEAP, lsl #32
    // 0xfad5bc: stur            x3, [fp, #-0x48]
    // 0xfad5c0: LoadField: r4 = r2->field_13
    //     0xfad5c0: ldur            w4, [x2, #0x13]
    // 0xfad5c4: DecompressPointer r4
    //     0xfad5c4: add             x4, x4, HEAP, lsl #32
    // 0xfad5c8: stur            x4, [fp, #-0x40]
    // 0xfad5cc: mov             x10, x1
    // 0xfad5d0: r9 = 0
    //     0xfad5d0: mov             x9, #0
    // 0xfad5d4: ldur            x5, [fp, #-0x30]
    // 0xfad5d8: ldur            x8, [fp, #-0x20]
    // 0xfad5dc: ldur            x7, [fp, #-0x10]
    // 0xfad5e0: ldur            x6, [fp, #-0x28]
    // 0xfad5e4: stur            x10, [fp, #-0x38]
    // 0xfad5e8: CheckStackOverflow
    //     0xfad5e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfad5ec: cmp             SP, x16
    //     0xfad5f0: b.ls            #0xfada54
    // 0xfad5f4: LoadField: r0 = r3->field_b
    //     0xfad5f4: ldur            w0, [x3, #0xb]
    // 0xfad5f8: r1 = LoadInt32Instr(r0)
    //     0xfad5f8: sbfx            x1, x0, #1, #0x1f
    // 0xfad5fc: cmp             x9, x1
    // 0xfad600: b.ge            #0xfad944
    // 0xfad604: cbz             x9, #0xfad770
    // 0xfad608: sub             x11, x9, #1
    // 0xfad60c: r0 = BoxInt64Instr(r11)
    //     0xfad60c: sbfiz           x0, x11, #1, #0x1f
    //     0xfad610: cmp             x11, x0, asr #1
    //     0xfad614: b.eq            #0xfad620
    //     0xfad618: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xfad61c: stur            x11, [x0, #7]
    // 0xfad620: cmp             w4, w0
    // 0xfad624: b.eq            #0xfad660
    // 0xfad628: and             w16, w4, w0
    // 0xfad62c: branchIfSmi(r16, 0xfad668)
    //     0xfad62c: tbz             w16, #0, #0xfad668
    // 0xfad630: r16 = LoadClassIdInstr(r4)
    //     0xfad630: ldur            x16, [x4, #-1]
    //     0xfad634: ubfx            x16, x16, #0xc, #0x14
    // 0xfad638: cmp             x16, #0x3d
    // 0xfad63c: b.ne            #0xfad668
    // 0xfad640: r16 = LoadClassIdInstr(r0)
    //     0xfad640: ldur            x16, [x0, #-1]
    //     0xfad644: ubfx            x16, x16, #0xc, #0x14
    // 0xfad648: cmp             x16, #0x3d
    // 0xfad64c: b.ne            #0xfad668
    // 0xfad650: LoadField: r16 = r4->field_7
    //     0xfad650: ldur            x16, [x4, #7]
    // 0xfad654: LoadField: r17 = r0->field_7
    //     0xfad654: ldur            x17, [x0, #7]
    // 0xfad658: cmp             x16, x17
    // 0xfad65c: b.ne            #0xfad668
    // 0xfad660: r0 = true
    //     0xfad660: add             x0, NULL, #0x20  ; true
    // 0xfad664: b               #0xfad6cc
    // 0xfad668: r0 = BoxInt64Instr(r9)
    //     0xfad668: sbfiz           x0, x9, #1, #0x1f
    //     0xfad66c: cmp             x9, x0, asr #1
    //     0xfad670: b.eq            #0xfad67c
    //     0xfad674: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xfad678: stur            x9, [x0, #7]
    // 0xfad67c: cmp             w4, w0
    // 0xfad680: b.eq            #0xfad6c4
    // 0xfad684: and             w16, w4, w0
    // 0xfad688: branchIfSmi(r16, 0xfad6bc)
    //     0xfad688: tbz             w16, #0, #0xfad6bc
    // 0xfad68c: r16 = LoadClassIdInstr(r4)
    //     0xfad68c: ldur            x16, [x4, #-1]
    //     0xfad690: ubfx            x16, x16, #0xc, #0x14
    // 0xfad694: cmp             x16, #0x3d
    // 0xfad698: b.ne            #0xfad6bc
    // 0xfad69c: r16 = LoadClassIdInstr(r0)
    //     0xfad69c: ldur            x16, [x0, #-1]
    //     0xfad6a0: ubfx            x16, x16, #0xc, #0x14
    // 0xfad6a4: cmp             x16, #0x3d
    // 0xfad6a8: b.ne            #0xfad6bc
    // 0xfad6ac: LoadField: r16 = r4->field_7
    //     0xfad6ac: ldur            x16, [x4, #7]
    // 0xfad6b0: LoadField: r17 = r0->field_7
    //     0xfad6b0: ldur            x17, [x0, #7]
    // 0xfad6b4: cmp             x16, x17
    // 0xfad6b8: b.eq            #0xfad6c4
    // 0xfad6bc: r1 = false
    //     0xfad6bc: add             x1, NULL, #0x30  ; false
    // 0xfad6c0: b               #0xfad6c8
    // 0xfad6c4: r1 = true
    //     0xfad6c4: add             x1, NULL, #0x20  ; true
    // 0xfad6c8: mov             x0, x1
    // 0xfad6cc: stur            x0, [fp, #-0x18]
    // 0xfad6d0: r0 = _Divider()
    //     0xfad6d0: bl              #0xde3f54  ; Allocate_DividerStub -> _Divider (size=0x18)
    // 0xfad6d4: mov             x2, x0
    // 0xfad6d8: ldur            x0, [fp, #-0x28]
    // 0xfad6dc: stur            x2, [fp, #-0x58]
    // 0xfad6e0: StoreField: r2->field_b = r0
    //     0xfad6e0: stur            w0, [x2, #0xb]
    // 0xfad6e4: ldur            x3, [fp, #-0x20]
    // 0xfad6e8: StoreField: r2->field_f = r3
    //     0xfad6e8: stur            w3, [x2, #0xf]
    // 0xfad6ec: ldur            x1, [fp, #-0x18]
    // 0xfad6f0: StoreField: r2->field_13 = r1
    //     0xfad6f0: stur            w1, [x2, #0x13]
    // 0xfad6f4: ldur            x4, [fp, #-0x30]
    // 0xfad6f8: LoadField: r1 = r4->field_b
    //     0xfad6f8: ldur            w1, [x4, #0xb]
    // 0xfad6fc: LoadField: r5 = r4->field_f
    //     0xfad6fc: ldur            w5, [x4, #0xf]
    // 0xfad700: DecompressPointer r5
    //     0xfad700: add             x5, x5, HEAP, lsl #32
    // 0xfad704: LoadField: r6 = r5->field_b
    //     0xfad704: ldur            w6, [x5, #0xb]
    // 0xfad708: r5 = LoadInt32Instr(r1)
    //     0xfad708: sbfx            x5, x1, #1, #0x1f
    // 0xfad70c: stur            x5, [fp, #-0x50]
    // 0xfad710: r1 = LoadInt32Instr(r6)
    //     0xfad710: sbfx            x1, x6, #1, #0x1f
    // 0xfad714: cmp             x5, x1
    // 0xfad718: b.ne            #0xfad724
    // 0xfad71c: mov             x1, x4
    // 0xfad720: r0 = _growToNextCapacity()
    //     0xfad720: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xfad724: ldur            x2, [fp, #-0x30]
    // 0xfad728: ldur            x3, [fp, #-0x50]
    // 0xfad72c: add             x0, x3, #1
    // 0xfad730: lsl             x1, x0, #1
    // 0xfad734: StoreField: r2->field_b = r1
    //     0xfad734: stur            w1, [x2, #0xb]
    // 0xfad738: LoadField: r1 = r2->field_f
    //     0xfad738: ldur            w1, [x2, #0xf]
    // 0xfad73c: DecompressPointer r1
    //     0xfad73c: add             x1, x1, HEAP, lsl #32
    // 0xfad740: ldur            x0, [fp, #-0x58]
    // 0xfad744: ArrayStore: r1[r3] = r0  ; List_4
    //     0xfad744: add             x25, x1, x3, lsl #2
    //     0xfad748: add             x25, x25, #0xf
    //     0xfad74c: str             w0, [x25]
    //     0xfad750: tbz             w0, #0, #0xfad76c
    //     0xfad754: ldurb           w16, [x1, #-1]
    //     0xfad758: ldurb           w17, [x0, #-1]
    //     0xfad75c: and             x16, x17, x16, lsr #2
    //     0xfad760: tst             x16, HEAP, lsr #32
    //     0xfad764: b.eq            #0xfad76c
    //     0xfad768: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xfad76c: b               #0xfad774
    // 0xfad770: mov             x2, x5
    // 0xfad774: ldur            x7, [fp, #-0x38]
    // 0xfad778: ldur            x4, [fp, #-0x48]
    // 0xfad77c: ldur            x5, [fp, #-0x40]
    // 0xfad780: ldur            x3, [fp, #-0x20]
    // 0xfad784: ldur            x6, [fp, #-0x10]
    // 0xfad788: LoadField: r0 = r7->field_f
    //     0xfad788: ldur            w0, [x7, #0xf]
    // 0xfad78c: DecompressPointer r0
    //     0xfad78c: add             x0, x0, HEAP, lsl #32
    // 0xfad790: cmp             w5, w0
    // 0xfad794: b.eq            #0xfad7d8
    // 0xfad798: and             w16, w5, w0
    // 0xfad79c: branchIfSmi(r16, 0xfad7d0)
    //     0xfad79c: tbz             w16, #0, #0xfad7d0
    // 0xfad7a0: r16 = LoadClassIdInstr(r5)
    //     0xfad7a0: ldur            x16, [x5, #-1]
    //     0xfad7a4: ubfx            x16, x16, #0xc, #0x14
    // 0xfad7a8: cmp             x16, #0x3d
    // 0xfad7ac: b.ne            #0xfad7d0
    // 0xfad7b0: r16 = LoadClassIdInstr(r0)
    //     0xfad7b0: ldur            x16, [x0, #-1]
    //     0xfad7b4: ubfx            x16, x16, #0xc, #0x14
    // 0xfad7b8: cmp             x16, #0x3d
    // 0xfad7bc: b.ne            #0xfad7d0
    // 0xfad7c0: LoadField: r16 = r5->field_7
    //     0xfad7c0: ldur            x16, [x5, #7]
    // 0xfad7c4: LoadField: r17 = r0->field_7
    //     0xfad7c4: ldur            x17, [x0, #7]
    // 0xfad7c8: cmp             x16, x17
    // 0xfad7cc: b.eq            #0xfad7d8
    // 0xfad7d0: r8 = false
    //     0xfad7d0: add             x8, NULL, #0x30  ; false
    // 0xfad7d4: b               #0xfad7dc
    // 0xfad7d8: r8 = true
    //     0xfad7d8: add             x8, NULL, #0x20  ; true
    // 0xfad7dc: stur            x8, [fp, #-0x58]
    // 0xfad7e0: LoadField: r1 = r4->field_b
    //     0xfad7e0: ldur            w1, [x4, #0xb]
    // 0xfad7e4: r9 = LoadInt32Instr(r0)
    //     0xfad7e4: sbfx            x9, x0, #1, #0x1f
    //     0xfad7e8: tbz             w0, #0, #0xfad7f0
    //     0xfad7ec: ldur            x9, [x0, #7]
    // 0xfad7f0: r0 = LoadInt32Instr(r1)
    //     0xfad7f0: sbfx            x0, x1, #1, #0x1f
    // 0xfad7f4: mov             x1, x9
    // 0xfad7f8: cmp             x1, x0
    // 0xfad7fc: b.hs            #0xfada5c
    // 0xfad800: LoadField: r0 = r4->field_f
    //     0xfad800: ldur            w0, [x4, #0xf]
    // 0xfad804: DecompressPointer r0
    //     0xfad804: add             x0, x0, HEAP, lsl #32
    // 0xfad808: ArrayLoad: r1 = r0[r9]  ; Unknown_4
    //     0xfad808: add             x16, x0, x9, lsl #2
    //     0xfad80c: ldur            w1, [x16, #0xf]
    // 0xfad810: DecompressPointer r1
    //     0xfad810: add             x1, x1, HEAP, lsl #32
    // 0xfad814: stur            x1, [fp, #-0x18]
    // 0xfad818: r0 = _AlertDialogButtonBackground()
    //     0xfad818: bl              #0xfada6c  ; Allocate_AlertDialogButtonBackgroundStub -> _AlertDialogButtonBackground (size=0x20)
    // 0xfad81c: mov             x3, x0
    // 0xfad820: ldur            x0, [fp, #-0x20]
    // 0xfad824: stur            x3, [fp, #-0x60]
    // 0xfad828: StoreField: r3->field_13 = r0
    //     0xfad828: stur            w0, [x3, #0x13]
    // 0xfad82c: ldur            x4, [fp, #-0x10]
    // 0xfad830: ArrayStore: r3[0] = r4  ; List_4
    //     0xfad830: stur            w4, [x3, #0x17]
    // 0xfad834: ldur            x1, [fp, #-0x58]
    // 0xfad838: StoreField: r3->field_b = r1
    //     0xfad838: stur            w1, [x3, #0xb]
    // 0xfad83c: ldur            x2, [fp, #-0x38]
    // 0xfad840: r1 = Function '<anonymous closure>':.
    //     0xfad840: add             x1, PP, #0xb0, lsl #12  ; [pp+0xb08f0] AnonymousClosure: (0xfada78), in [package:flutter/src/cupertino/dialog.dart] _CupertinoAlertActionSection::build (0xfad514)
    //     0xfad844: ldr             x1, [x1, #0x8f0]
    // 0xfad848: r0 = AllocateClosure()
    //     0xfad848: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfad84c: mov             x1, x0
    // 0xfad850: ldur            x0, [fp, #-0x60]
    // 0xfad854: StoreField: r0->field_f = r1
    //     0xfad854: stur            w1, [x0, #0xf]
    // 0xfad858: ldur            x1, [fp, #-0x18]
    // 0xfad85c: StoreField: r0->field_1b = r1
    //     0xfad85c: stur            w1, [x0, #0x1b]
    // 0xfad860: ldur            x2, [fp, #-0x30]
    // 0xfad864: LoadField: r1 = r2->field_b
    //     0xfad864: ldur            w1, [x2, #0xb]
    // 0xfad868: LoadField: r3 = r2->field_f
    //     0xfad868: ldur            w3, [x2, #0xf]
    // 0xfad86c: DecompressPointer r3
    //     0xfad86c: add             x3, x3, HEAP, lsl #32
    // 0xfad870: LoadField: r4 = r3->field_b
    //     0xfad870: ldur            w4, [x3, #0xb]
    // 0xfad874: r3 = LoadInt32Instr(r1)
    //     0xfad874: sbfx            x3, x1, #1, #0x1f
    // 0xfad878: stur            x3, [fp, #-0x50]
    // 0xfad87c: r1 = LoadInt32Instr(r4)
    //     0xfad87c: sbfx            x1, x4, #1, #0x1f
    // 0xfad880: cmp             x3, x1
    // 0xfad884: b.ne            #0xfad890
    // 0xfad888: mov             x1, x2
    // 0xfad88c: r0 = _growToNextCapacity()
    //     0xfad88c: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xfad890: ldur            x2, [fp, #-0x30]
    // 0xfad894: ldur            x3, [fp, #-0x50]
    // 0xfad898: add             x0, x3, #1
    // 0xfad89c: lsl             x1, x0, #1
    // 0xfad8a0: StoreField: r2->field_b = r1
    //     0xfad8a0: stur            w1, [x2, #0xb]
    // 0xfad8a4: LoadField: r1 = r2->field_f
    //     0xfad8a4: ldur            w1, [x2, #0xf]
    // 0xfad8a8: DecompressPointer r1
    //     0xfad8a8: add             x1, x1, HEAP, lsl #32
    // 0xfad8ac: ldur            x0, [fp, #-0x60]
    // 0xfad8b0: ArrayStore: r1[r3] = r0  ; List_4
    //     0xfad8b0: add             x25, x1, x3, lsl #2
    //     0xfad8b4: add             x25, x25, #0xf
    //     0xfad8b8: str             w0, [x25]
    //     0xfad8bc: tbz             w0, #0, #0xfad8d8
    //     0xfad8c0: ldurb           w16, [x1, #-1]
    //     0xfad8c4: ldurb           w17, [x0, #-1]
    //     0xfad8c8: and             x16, x17, x16, lsr #2
    //     0xfad8cc: tst             x16, HEAP, lsr #32
    //     0xfad8d0: b.eq            #0xfad8d8
    //     0xfad8d4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xfad8d8: ldur            x5, [fp, #-0x38]
    // 0xfad8dc: r0 = CloneContext()
    //     0xfad8dc: bl              #0x13de1f4  ; CloneContextStub
    // 0xfad8e0: mov             x2, x0
    // 0xfad8e4: LoadField: r0 = r2->field_f
    //     0xfad8e4: ldur            w0, [x2, #0xf]
    // 0xfad8e8: DecompressPointer r0
    //     0xfad8e8: add             x0, x0, HEAP, lsl #32
    // 0xfad8ec: r1 = LoadInt32Instr(r0)
    //     0xfad8ec: sbfx            x1, x0, #1, #0x1f
    //     0xfad8f0: tbz             w0, #0, #0xfad8f8
    //     0xfad8f4: ldur            x1, [x0, #7]
    // 0xfad8f8: add             x9, x1, #1
    // 0xfad8fc: r0 = BoxInt64Instr(r9)
    //     0xfad8fc: sbfiz           x0, x9, #1, #0x1f
    //     0xfad900: cmp             x9, x0, asr #1
    //     0xfad904: b.eq            #0xfad910
    //     0xfad908: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xfad90c: stur            x9, [x0, #7]
    // 0xfad910: StoreField: r2->field_f = r0
    //     0xfad910: stur            w0, [x2, #0xf]
    //     0xfad914: tbz             w0, #0, #0xfad930
    //     0xfad918: ldurb           w16, [x2, #-1]
    //     0xfad91c: ldurb           w17, [x0, #-1]
    //     0xfad920: and             x16, x17, x16, lsr #2
    //     0xfad924: tst             x16, HEAP, lsr #32
    //     0xfad928: b.eq            #0xfad930
    //     0xfad92c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xfad930: mov             x10, x2
    // 0xfad934: ldur            x2, [fp, #-8]
    // 0xfad938: ldur            x3, [fp, #-0x48]
    // 0xfad93c: ldur            x4, [fp, #-0x40]
    // 0xfad940: b               #0xfad5d4
    // 0xfad944: mov             x1, x2
    // 0xfad948: mov             x0, x5
    // 0xfad94c: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xfad94c: ldur            w2, [x1, #0x17]
    // 0xfad950: DecompressPointer r2
    //     0xfad950: add             x2, x2, HEAP, lsl #32
    // 0xfad954: stur            x2, [fp, #-0x10]
    // 0xfad958: r0 = _AlertDialogActionsLayout()
    //     0xfad958: bl              #0xfada60  ; Allocate_AlertDialogActionsLayoutStub -> _AlertDialogActionsLayout (size=0x18)
    // 0xfad95c: d0 = 0.300000
    //     0xfad95c: add             x17, PP, #0x13, lsl #12  ; [pp+0x13a88] IMM: double(0.3) from 0x3fd3333333333333
    //     0xfad960: ldr             d0, [x17, #0xa88]
    // 0xfad964: stur            x0, [fp, #-8]
    // 0xfad968: StoreField: r0->field_f = d0
    //     0xfad968: stur            d0, [x0, #0xf]
    // 0xfad96c: ldur            x1, [fp, #-0x30]
    // 0xfad970: StoreField: r0->field_b = r1
    //     0xfad970: stur            w1, [x0, #0xb]
    // 0xfad974: r0 = SingleChildScrollView()
    //     0xfad974: bl              #0xdc8fa4  ; AllocateSingleChildScrollViewStub -> SingleChildScrollView (size=0x3c)
    // 0xfad978: mov             x1, x0
    // 0xfad97c: r0 = Instance_Axis
    //     0xfad97c: ldr             x0, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xfad980: stur            x1, [fp, #-0x18]
    // 0xfad984: StoreField: r1->field_b = r0
    //     0xfad984: stur            w0, [x1, #0xb]
    // 0xfad988: r0 = false
    //     0xfad988: add             x0, NULL, #0x30  ; false
    // 0xfad98c: StoreField: r1->field_f = r0
    //     0xfad98c: stur            w0, [x1, #0xf]
    // 0xfad990: ldur            x2, [fp, #-0x10]
    // 0xfad994: ArrayStore: r1[0] = r2  ; List_4
    //     0xfad994: stur            w2, [x1, #0x17]
    // 0xfad998: ldur            x3, [fp, #-8]
    // 0xfad99c: StoreField: r1->field_23 = r3
    //     0xfad99c: stur            w3, [x1, #0x23]
    // 0xfad9a0: r3 = Instance_DragStartBehavior
    //     0xfad9a0: ldr             x3, [PP, #0x5360]  ; [pp+0x5360] Obj!DragStartBehavior@12c5c61
    // 0xfad9a4: StoreField: r1->field_27 = r3
    //     0xfad9a4: stur            w3, [x1, #0x27]
    // 0xfad9a8: r3 = Instance_Clip
    //     0xfad9a8: add             x3, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xfad9ac: ldr             x3, [x3, #0x850]
    // 0xfad9b0: StoreField: r1->field_2b = r3
    //     0xfad9b0: stur            w3, [x1, #0x2b]
    // 0xfad9b4: r3 = Instance_HitTestBehavior
    //     0xfad9b4: add             x3, PP, #0x15, lsl #12  ; [pp+0x155c0] Obj!HitTestBehavior@12c43c1
    //     0xfad9b8: ldr             x3, [x3, #0x5c0]
    // 0xfad9bc: StoreField: r1->field_2f = r3
    //     0xfad9bc: stur            w3, [x1, #0x2f]
    // 0xfad9c0: r0 = CupertinoScrollbar()
    //     0xfad9c0: bl              #0xfacf50  ; AllocateCupertinoScrollbarStub -> CupertinoScrollbar (size=0x78)
    // 0xfad9c4: d0 = 8.000000
    //     0xfad9c4: fmov            d0, #8.00000000
    // 0xfad9c8: StoreField: r0->field_6b = d0
    //     0xfad9c8: stur            d0, [x0, #0x6b]
    // 0xfad9cc: r1 = Instance_Radius
    //     0xfad9cc: add             x1, PP, #0x9d, lsl #12  ; [pp+0x9d080] Obj!Radius@12a7121
    //     0xfad9d0: ldr             x1, [x1, #0x80]
    // 0xfad9d4: StoreField: r0->field_73 = r1
    //     0xfad9d4: stur            w1, [x0, #0x73]
    // 0xfad9d8: ldur            x1, [fp, #-0x18]
    // 0xfad9dc: StoreField: r0->field_b = r1
    //     0xfad9dc: stur            w1, [x0, #0xb]
    // 0xfad9e0: ldur            x1, [fp, #-0x10]
    // 0xfad9e4: StoreField: r0->field_f = r1
    //     0xfad9e4: stur            w1, [x0, #0xf]
    // 0xfad9e8: r1 = false
    //     0xfad9e8: add             x1, NULL, #0x30  ; false
    // 0xfad9ec: StoreField: r0->field_13 = r1
    //     0xfad9ec: stur            w1, [x0, #0x13]
    // 0xfad9f0: r1 = Instance_Radius
    //     0xfad9f0: add             x1, PP, #0xb0, lsl #12  ; [pp+0xb08f8] Obj!Radius@12a71c1
    //     0xfad9f4: ldr             x1, [x1, #0x8f8]
    // 0xfad9f8: StoreField: r0->field_1b = r1
    //     0xfad9f8: stur            w1, [x0, #0x1b]
    // 0xfad9fc: r1 = 3.000000
    //     0xfad9fc: add             x1, PP, #0x22, lsl #12  ; [pp+0x223f8] 3
    //     0xfada00: ldr             x1, [x1, #0x3f8]
    // 0xfada04: StoreField: r0->field_1f = r1
    //     0xfada04: stur            w1, [x0, #0x1f]
    // 0xfada08: d0 = 18.000000
    //     0xfada08: fmov            d0, #18.00000000
    // 0xfada0c: StoreField: r0->field_27 = d0
    //     0xfada0c: stur            d0, [x0, #0x27]
    // 0xfada10: r1 = Instance_Duration
    //     0xfada10: add             x1, PP, #0xc, lsl #12  ; [pp+0xc920] Obj!Duration@12c89c1
    //     0xfada14: ldr             x1, [x1, #0x920]
    // 0xfada18: StoreField: r0->field_43 = r1
    //     0xfada18: stur            w1, [x0, #0x43]
    // 0xfada1c: r1 = Instance_Duration
    //     0xfada1c: add             x1, PP, #0x94, lsl #12  ; [pp+0x94bf0] Obj!Duration@12c8b81
    //     0xfada20: ldr             x1, [x1, #0xbf0]
    // 0xfada24: StoreField: r0->field_47 = r1
    //     0xfada24: stur            w1, [x0, #0x47]
    // 0xfada28: r1 = Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static.
    //     0xfada28: add             x1, PP, #0x18, lsl #12  ; [pp+0x18158] Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static. (0x7f2adac1b19c)
    //     0xfada2c: ldr             x1, [x1, #0x158]
    // 0xfada30: StoreField: r0->field_4b = r1
    //     0xfada30: stur            w1, [x0, #0x4b]
    // 0xfada34: d0 = 3.000000
    //     0xfada34: fmov            d0, #3.00000000
    // 0xfada38: StoreField: r0->field_57 = d0
    //     0xfada38: stur            d0, [x0, #0x57]
    // 0xfada3c: StoreField: r0->field_5f = rZR
    //     0xfada3c: stur            xzr, [x0, #0x5f]
    // 0xfada40: LeaveFrame
    //     0xfada40: mov             SP, fp
    //     0xfada44: ldp             fp, lr, [SP], #0x10
    // 0xfada48: ret
    //     0xfada48: ret             
    // 0xfada4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfada4c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfada50: b               #0xfad534
    // 0xfada54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfada54: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfada58: b               #0xfad5f4
    // 0xfada5c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xfada5c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, bool) {
    // ** addr: 0xfada78, size: 0x68
    // 0xfada78: EnterFrame
    //     0xfada78: stp             fp, lr, [SP, #-0x10]!
    //     0xfada7c: mov             fp, SP
    // 0xfada80: ldr             x0, [fp, #0x18]
    // 0xfada84: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xfada84: ldur            w1, [x0, #0x17]
    // 0xfada88: DecompressPointer r1
    //     0xfada88: add             x1, x1, HEAP, lsl #32
    // 0xfada8c: CheckStackOverflow
    //     0xfada8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfada90: cmp             SP, x16
    //     0xfada94: b.ls            #0xfadad8
    // 0xfada98: LoadField: r2 = r1->field_f
    //     0xfada98: ldur            w2, [x1, #0xf]
    // 0xfada9c: DecompressPointer r2
    //     0xfada9c: add             x2, x2, HEAP, lsl #32
    // 0xfadaa0: LoadField: r0 = r1->field_b
    //     0xfadaa0: ldur            w0, [x1, #0xb]
    // 0xfadaa4: DecompressPointer r0
    //     0xfadaa4: add             x0, x0, HEAP, lsl #32
    // 0xfadaa8: LoadField: r1 = r0->field_f
    //     0xfadaa8: ldur            w1, [x0, #0xf]
    // 0xfadaac: DecompressPointer r1
    //     0xfadaac: add             x1, x1, HEAP, lsl #32
    // 0xfadab0: LoadField: r0 = r1->field_f
    //     0xfadab0: ldur            w0, [x1, #0xf]
    // 0xfadab4: DecompressPointer r0
    //     0xfadab4: add             x0, x0, HEAP, lsl #32
    // 0xfadab8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xfadab8: ldur            w1, [x0, #0x17]
    // 0xfadabc: DecompressPointer r1
    //     0xfadabc: add             x1, x1, HEAP, lsl #32
    // 0xfadac0: ldr             x3, [fp, #0x10]
    // 0xfadac4: r0 = _onPressedUpdate()
    //     0xfadac4: bl              #0xde4150  ; [package:flutter/src/cupertino/dialog.dart] _CupertinoAlertDialogState::_onPressedUpdate
    // 0xfadac8: r0 = Null
    //     0xfadac8: mov             x0, NULL
    // 0xfadacc: LeaveFrame
    //     0xfadacc: mov             SP, fp
    //     0xfadad0: ldp             fp, lr, [SP], #0x10
    // 0xfadad4: ret
    //     0xfadad4: ret             
    // 0xfadad8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfadad8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfadadc: b               #0xfada98
  }
}

// class id: 6202, size: 0x2c, field offset: 0xc
//   const constructor, 
class _CupertinoAlertContentSection extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfad198, size: 0x37c
    // 0xfad198: EnterFrame
    //     0xfad198: stp             fp, lr, [SP, #-0x10]!
    //     0xfad19c: mov             fp, SP
    // 0xfad1a0: AllocStack(0x48)
    //     0xfad1a0: sub             SP, SP, #0x48
    // 0xfad1a4: SetupParameters(_CupertinoAlertContentSection this /* r1 => r0, fp-0x8 */)
    //     0xfad1a4: mov             x0, x1
    //     0xfad1a8: stur            x1, [fp, #-8]
    // 0xfad1ac: CheckStackOverflow
    //     0xfad1ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfad1b0: cmp             SP, x16
    //     0xfad1b4: b.ls            #0xfad50c
    // 0xfad1b8: r1 = <Widget>
    //     0xfad1b8: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xfad1bc: r2 = 0
    //     0xfad1bc: mov             x2, #0
    // 0xfad1c0: r0 = _GrowableList()
    //     0xfad1c0: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xfad1c4: mov             x1, x0
    // 0xfad1c8: ldur            x0, [fp, #-8]
    // 0xfad1cc: stur            x1, [fp, #-0x28]
    // 0xfad1d0: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xfad1d0: ldur            w2, [x0, #0x17]
    // 0xfad1d4: DecompressPointer r2
    //     0xfad1d4: add             x2, x2, HEAP, lsl #32
    // 0xfad1d8: stur            x2, [fp, #-0x20]
    // 0xfad1dc: LoadField: r3 = r0->field_23
    //     0xfad1dc: ldur            w3, [x0, #0x23]
    // 0xfad1e0: DecompressPointer r3
    //     0xfad1e0: add             x3, x3, HEAP, lsl #32
    // 0xfad1e4: stur            x3, [fp, #-0x18]
    // 0xfad1e8: LoadField: r4 = r0->field_b
    //     0xfad1e8: ldur            w4, [x0, #0xb]
    // 0xfad1ec: DecompressPointer r4
    //     0xfad1ec: add             x4, x4, HEAP, lsl #32
    // 0xfad1f0: stur            x4, [fp, #-0x10]
    // 0xfad1f4: r0 = DefaultTextStyle()
    //     0xfad1f4: bl              #0xd0b11c  ; AllocateDefaultTextStyleStub -> DefaultTextStyle (size=0x2c)
    // 0xfad1f8: mov             x1, x0
    // 0xfad1fc: ldur            x0, [fp, #-0x18]
    // 0xfad200: stur            x1, [fp, #-0x30]
    // 0xfad204: StoreField: r1->field_f = r0
    //     0xfad204: stur            w0, [x1, #0xf]
    // 0xfad208: r0 = Instance_TextAlign
    //     0xfad208: ldr             x0, [PP, #0x4c68]  ; [pp+0x4c68] Obj!TextAlign@12c7561
    // 0xfad20c: StoreField: r1->field_13 = r0
    //     0xfad20c: stur            w0, [x1, #0x13]
    // 0xfad210: r2 = true
    //     0xfad210: add             x2, NULL, #0x20  ; true
    // 0xfad214: ArrayStore: r1[0] = r2  ; List_4
    //     0xfad214: stur            w2, [x1, #0x17]
    // 0xfad218: r3 = Instance_TextOverflow
    //     0xfad218: add             x3, PP, #0x20, lsl #12  ; [pp+0x20108] Obj!TextOverflow@12c47c1
    //     0xfad21c: ldr             x3, [x3, #0x108]
    // 0xfad220: StoreField: r1->field_1b = r3
    //     0xfad220: stur            w3, [x1, #0x1b]
    // 0xfad224: r4 = Instance_TextWidthBasis
    //     0xfad224: add             x4, PP, #0x20, lsl #12  ; [pp+0x20110] Obj!TextWidthBasis@12c4781
    //     0xfad228: ldr             x4, [x4, #0x110]
    // 0xfad22c: StoreField: r1->field_23 = r4
    //     0xfad22c: stur            w4, [x1, #0x23]
    // 0xfad230: ldur            x5, [fp, #-0x10]
    // 0xfad234: StoreField: r1->field_b = r5
    //     0xfad234: stur            w5, [x1, #0xb]
    // 0xfad238: r0 = Padding()
    //     0xfad238: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xfad23c: mov             x2, x0
    // 0xfad240: ldur            x0, [fp, #-0x20]
    // 0xfad244: stur            x2, [fp, #-0x10]
    // 0xfad248: StoreField: r2->field_f = r0
    //     0xfad248: stur            w0, [x2, #0xf]
    // 0xfad24c: ldur            x0, [fp, #-0x30]
    // 0xfad250: StoreField: r2->field_b = r0
    //     0xfad250: stur            w0, [x2, #0xb]
    // 0xfad254: ldur            x0, [fp, #-0x28]
    // 0xfad258: LoadField: r1 = r0->field_b
    //     0xfad258: ldur            w1, [x0, #0xb]
    // 0xfad25c: LoadField: r3 = r0->field_f
    //     0xfad25c: ldur            w3, [x0, #0xf]
    // 0xfad260: DecompressPointer r3
    //     0xfad260: add             x3, x3, HEAP, lsl #32
    // 0xfad264: LoadField: r4 = r3->field_b
    //     0xfad264: ldur            w4, [x3, #0xb]
    // 0xfad268: r3 = LoadInt32Instr(r1)
    //     0xfad268: sbfx            x3, x1, #1, #0x1f
    // 0xfad26c: stur            x3, [fp, #-0x38]
    // 0xfad270: r1 = LoadInt32Instr(r4)
    //     0xfad270: sbfx            x1, x4, #1, #0x1f
    // 0xfad274: cmp             x3, x1
    // 0xfad278: b.ne            #0xfad284
    // 0xfad27c: mov             x1, x0
    // 0xfad280: r0 = _growToNextCapacity()
    //     0xfad280: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xfad284: ldur            x4, [fp, #-8]
    // 0xfad288: ldur            x2, [fp, #-0x28]
    // 0xfad28c: ldur            x3, [fp, #-0x38]
    // 0xfad290: add             x5, x3, #1
    // 0xfad294: stur            x5, [fp, #-0x40]
    // 0xfad298: lsl             x0, x5, #1
    // 0xfad29c: StoreField: r2->field_b = r0
    //     0xfad29c: stur            w0, [x2, #0xb]
    // 0xfad2a0: LoadField: r6 = r2->field_f
    //     0xfad2a0: ldur            w6, [x2, #0xf]
    // 0xfad2a4: DecompressPointer r6
    //     0xfad2a4: add             x6, x6, HEAP, lsl #32
    // 0xfad2a8: mov             x1, x6
    // 0xfad2ac: ldur            x0, [fp, #-0x10]
    // 0xfad2b0: stur            x6, [fp, #-0x30]
    // 0xfad2b4: ArrayStore: r1[r3] = r0  ; List_4
    //     0xfad2b4: add             x25, x1, x3, lsl #2
    //     0xfad2b8: add             x25, x25, #0xf
    //     0xfad2bc: str             w0, [x25]
    //     0xfad2c0: tbz             w0, #0, #0xfad2dc
    //     0xfad2c4: ldurb           w16, [x1, #-1]
    //     0xfad2c8: ldurb           w17, [x0, #-1]
    //     0xfad2cc: and             x16, x17, x16, lsr #2
    //     0xfad2d0: tst             x16, HEAP, lsr #32
    //     0xfad2d4: b.eq            #0xfad2dc
    //     0xfad2d8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xfad2dc: LoadField: r0 = r4->field_1b
    //     0xfad2dc: ldur            w0, [x4, #0x1b]
    // 0xfad2e0: DecompressPointer r0
    //     0xfad2e0: add             x0, x0, HEAP, lsl #32
    // 0xfad2e4: stur            x0, [fp, #-0x20]
    // 0xfad2e8: LoadField: r1 = r4->field_27
    //     0xfad2e8: ldur            w1, [x4, #0x27]
    // 0xfad2ec: DecompressPointer r1
    //     0xfad2ec: add             x1, x1, HEAP, lsl #32
    // 0xfad2f0: stur            x1, [fp, #-0x18]
    // 0xfad2f4: LoadField: r3 = r4->field_f
    //     0xfad2f4: ldur            w3, [x4, #0xf]
    // 0xfad2f8: DecompressPointer r3
    //     0xfad2f8: add             x3, x3, HEAP, lsl #32
    // 0xfad2fc: stur            x3, [fp, #-0x10]
    // 0xfad300: r0 = DefaultTextStyle()
    //     0xfad300: bl              #0xd0b11c  ; AllocateDefaultTextStyleStub -> DefaultTextStyle (size=0x2c)
    // 0xfad304: mov             x1, x0
    // 0xfad308: ldur            x0, [fp, #-0x18]
    // 0xfad30c: stur            x1, [fp, #-0x48]
    // 0xfad310: StoreField: r1->field_f = r0
    //     0xfad310: stur            w0, [x1, #0xf]
    // 0xfad314: r0 = Instance_TextAlign
    //     0xfad314: ldr             x0, [PP, #0x4c68]  ; [pp+0x4c68] Obj!TextAlign@12c7561
    // 0xfad318: StoreField: r1->field_13 = r0
    //     0xfad318: stur            w0, [x1, #0x13]
    // 0xfad31c: r0 = true
    //     0xfad31c: add             x0, NULL, #0x20  ; true
    // 0xfad320: ArrayStore: r1[0] = r0  ; List_4
    //     0xfad320: stur            w0, [x1, #0x17]
    // 0xfad324: r0 = Instance_TextOverflow
    //     0xfad324: add             x0, PP, #0x20, lsl #12  ; [pp+0x20108] Obj!TextOverflow@12c47c1
    //     0xfad328: ldr             x0, [x0, #0x108]
    // 0xfad32c: StoreField: r1->field_1b = r0
    //     0xfad32c: stur            w0, [x1, #0x1b]
    // 0xfad330: r0 = Instance_TextWidthBasis
    //     0xfad330: add             x0, PP, #0x20, lsl #12  ; [pp+0x20110] Obj!TextWidthBasis@12c4781
    //     0xfad334: ldr             x0, [x0, #0x110]
    // 0xfad338: StoreField: r1->field_23 = r0
    //     0xfad338: stur            w0, [x1, #0x23]
    // 0xfad33c: ldur            x0, [fp, #-0x10]
    // 0xfad340: StoreField: r1->field_b = r0
    //     0xfad340: stur            w0, [x1, #0xb]
    // 0xfad344: r0 = Padding()
    //     0xfad344: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xfad348: mov             x2, x0
    // 0xfad34c: ldur            x0, [fp, #-0x20]
    // 0xfad350: stur            x2, [fp, #-0x10]
    // 0xfad354: StoreField: r2->field_f = r0
    //     0xfad354: stur            w0, [x2, #0xf]
    // 0xfad358: ldur            x0, [fp, #-0x48]
    // 0xfad35c: StoreField: r2->field_b = r0
    //     0xfad35c: stur            w0, [x2, #0xb]
    // 0xfad360: ldur            x0, [fp, #-0x30]
    // 0xfad364: LoadField: r1 = r0->field_b
    //     0xfad364: ldur            w1, [x0, #0xb]
    // 0xfad368: r0 = LoadInt32Instr(r1)
    //     0xfad368: sbfx            x0, x1, #1, #0x1f
    // 0xfad36c: ldur            x3, [fp, #-0x40]
    // 0xfad370: cmp             x3, x0
    // 0xfad374: b.ne            #0xfad380
    // 0xfad378: ldur            x1, [fp, #-0x28]
    // 0xfad37c: r0 = _growToNextCapacity()
    //     0xfad37c: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xfad380: ldur            x4, [fp, #-8]
    // 0xfad384: ldur            x3, [fp, #-0x28]
    // 0xfad388: ldur            x2, [fp, #-0x40]
    // 0xfad38c: add             x0, x2, #1
    // 0xfad390: lsl             x1, x0, #1
    // 0xfad394: StoreField: r3->field_b = r1
    //     0xfad394: stur            w1, [x3, #0xb]
    // 0xfad398: LoadField: r1 = r3->field_f
    //     0xfad398: ldur            w1, [x3, #0xf]
    // 0xfad39c: DecompressPointer r1
    //     0xfad39c: add             x1, x1, HEAP, lsl #32
    // 0xfad3a0: ldur            x0, [fp, #-0x10]
    // 0xfad3a4: ArrayStore: r1[r2] = r0  ; List_4
    //     0xfad3a4: add             x25, x1, x2, lsl #2
    //     0xfad3a8: add             x25, x25, #0xf
    //     0xfad3ac: str             w0, [x25]
    //     0xfad3b0: tbz             w0, #0, #0xfad3cc
    //     0xfad3b4: ldurb           w16, [x1, #-1]
    //     0xfad3b8: ldurb           w17, [x0, #-1]
    //     0xfad3bc: and             x16, x17, x16, lsr #2
    //     0xfad3c0: tst             x16, HEAP, lsr #32
    //     0xfad3c4: b.eq            #0xfad3cc
    //     0xfad3c8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xfad3cc: LoadField: r0 = r4->field_13
    //     0xfad3cc: ldur            w0, [x4, #0x13]
    // 0xfad3d0: DecompressPointer r0
    //     0xfad3d0: add             x0, x0, HEAP, lsl #32
    // 0xfad3d4: stur            x0, [fp, #-0x10]
    // 0xfad3d8: r0 = Column()
    //     0xfad3d8: bl              #0x8a5b1c  ; AllocateColumnStub -> Column (size=0x38)
    // 0xfad3dc: mov             x1, x0
    // 0xfad3e0: r0 = Instance_Axis
    //     0xfad3e0: ldr             x0, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xfad3e4: stur            x1, [fp, #-8]
    // 0xfad3e8: StoreField: r1->field_f = r0
    //     0xfad3e8: stur            w0, [x1, #0xf]
    // 0xfad3ec: r2 = Instance_MainAxisAlignment
    //     0xfad3ec: add             x2, PP, #0x15, lsl #12  ; [pp+0x15820] Obj!MainAxisAlignment@12c4541
    //     0xfad3f0: ldr             x2, [x2, #0x820]
    // 0xfad3f4: StoreField: r1->field_13 = r2
    //     0xfad3f4: stur            w2, [x1, #0x13]
    // 0xfad3f8: r2 = Instance_MainAxisSize
    //     0xfad3f8: add             x2, PP, #0x15, lsl #12  ; [pp+0x15828] Obj!MainAxisSize@12c4621
    //     0xfad3fc: ldr             x2, [x2, #0x828]
    // 0xfad400: ArrayStore: r1[0] = r2  ; List_4
    //     0xfad400: stur            w2, [x1, #0x17]
    // 0xfad404: r2 = Instance_CrossAxisAlignment
    //     0xfad404: add             x2, PP, #0x7b, lsl #12  ; [pp+0x7bc40] Obj!CrossAxisAlignment@12c4521
    //     0xfad408: ldr             x2, [x2, #0xc40]
    // 0xfad40c: StoreField: r1->field_1b = r2
    //     0xfad40c: stur            w2, [x1, #0x1b]
    // 0xfad410: r2 = Instance_VerticalDirection
    //     0xfad410: add             x2, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xfad414: ldr             x2, [x2, #0x838]
    // 0xfad418: StoreField: r1->field_23 = r2
    //     0xfad418: stur            w2, [x1, #0x23]
    // 0xfad41c: r2 = Instance_Clip
    //     0xfad41c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xfad420: ldr             x2, [x2, #0x840]
    // 0xfad424: StoreField: r1->field_2b = r2
    //     0xfad424: stur            w2, [x1, #0x2b]
    // 0xfad428: StoreField: r1->field_2f = rZR
    //     0xfad428: stur            xzr, [x1, #0x2f]
    // 0xfad42c: ldur            x2, [fp, #-0x28]
    // 0xfad430: StoreField: r1->field_b = r2
    //     0xfad430: stur            w2, [x1, #0xb]
    // 0xfad434: r0 = SingleChildScrollView()
    //     0xfad434: bl              #0xdc8fa4  ; AllocateSingleChildScrollViewStub -> SingleChildScrollView (size=0x3c)
    // 0xfad438: mov             x1, x0
    // 0xfad43c: r0 = Instance_Axis
    //     0xfad43c: ldr             x0, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xfad440: stur            x1, [fp, #-0x18]
    // 0xfad444: StoreField: r1->field_b = r0
    //     0xfad444: stur            w0, [x1, #0xb]
    // 0xfad448: r0 = false
    //     0xfad448: add             x0, NULL, #0x30  ; false
    // 0xfad44c: StoreField: r1->field_f = r0
    //     0xfad44c: stur            w0, [x1, #0xf]
    // 0xfad450: ldur            x2, [fp, #-0x10]
    // 0xfad454: ArrayStore: r1[0] = r2  ; List_4
    //     0xfad454: stur            w2, [x1, #0x17]
    // 0xfad458: ldur            x3, [fp, #-8]
    // 0xfad45c: StoreField: r1->field_23 = r3
    //     0xfad45c: stur            w3, [x1, #0x23]
    // 0xfad460: r3 = Instance_DragStartBehavior
    //     0xfad460: ldr             x3, [PP, #0x5360]  ; [pp+0x5360] Obj!DragStartBehavior@12c5c61
    // 0xfad464: StoreField: r1->field_27 = r3
    //     0xfad464: stur            w3, [x1, #0x27]
    // 0xfad468: r3 = Instance_Clip
    //     0xfad468: add             x3, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xfad46c: ldr             x3, [x3, #0x850]
    // 0xfad470: StoreField: r1->field_2b = r3
    //     0xfad470: stur            w3, [x1, #0x2b]
    // 0xfad474: r3 = Instance_HitTestBehavior
    //     0xfad474: add             x3, PP, #0x15, lsl #12  ; [pp+0x155c0] Obj!HitTestBehavior@12c43c1
    //     0xfad478: ldr             x3, [x3, #0x5c0]
    // 0xfad47c: StoreField: r1->field_2f = r3
    //     0xfad47c: stur            w3, [x1, #0x2f]
    // 0xfad480: r0 = CupertinoScrollbar()
    //     0xfad480: bl              #0xfacf50  ; AllocateCupertinoScrollbarStub -> CupertinoScrollbar (size=0x78)
    // 0xfad484: d0 = 8.000000
    //     0xfad484: fmov            d0, #8.00000000
    // 0xfad488: StoreField: r0->field_6b = d0
    //     0xfad488: stur            d0, [x0, #0x6b]
    // 0xfad48c: r1 = Instance_Radius
    //     0xfad48c: add             x1, PP, #0x9d, lsl #12  ; [pp+0x9d080] Obj!Radius@12a7121
    //     0xfad490: ldr             x1, [x1, #0x80]
    // 0xfad494: StoreField: r0->field_73 = r1
    //     0xfad494: stur            w1, [x0, #0x73]
    // 0xfad498: ldur            x1, [fp, #-0x18]
    // 0xfad49c: StoreField: r0->field_b = r1
    //     0xfad49c: stur            w1, [x0, #0xb]
    // 0xfad4a0: ldur            x1, [fp, #-0x10]
    // 0xfad4a4: StoreField: r0->field_f = r1
    //     0xfad4a4: stur            w1, [x0, #0xf]
    // 0xfad4a8: r1 = false
    //     0xfad4a8: add             x1, NULL, #0x30  ; false
    // 0xfad4ac: StoreField: r0->field_13 = r1
    //     0xfad4ac: stur            w1, [x0, #0x13]
    // 0xfad4b0: r1 = Instance_Radius
    //     0xfad4b0: add             x1, PP, #0xb0, lsl #12  ; [pp+0xb08f8] Obj!Radius@12a71c1
    //     0xfad4b4: ldr             x1, [x1, #0x8f8]
    // 0xfad4b8: StoreField: r0->field_1b = r1
    //     0xfad4b8: stur            w1, [x0, #0x1b]
    // 0xfad4bc: r1 = 3.000000
    //     0xfad4bc: add             x1, PP, #0x22, lsl #12  ; [pp+0x223f8] 3
    //     0xfad4c0: ldr             x1, [x1, #0x3f8]
    // 0xfad4c4: StoreField: r0->field_1f = r1
    //     0xfad4c4: stur            w1, [x0, #0x1f]
    // 0xfad4c8: d0 = 18.000000
    //     0xfad4c8: fmov            d0, #18.00000000
    // 0xfad4cc: StoreField: r0->field_27 = d0
    //     0xfad4cc: stur            d0, [x0, #0x27]
    // 0xfad4d0: r1 = Instance_Duration
    //     0xfad4d0: add             x1, PP, #0xc, lsl #12  ; [pp+0xc920] Obj!Duration@12c89c1
    //     0xfad4d4: ldr             x1, [x1, #0x920]
    // 0xfad4d8: StoreField: r0->field_43 = r1
    //     0xfad4d8: stur            w1, [x0, #0x43]
    // 0xfad4dc: r1 = Instance_Duration
    //     0xfad4dc: add             x1, PP, #0x94, lsl #12  ; [pp+0x94bf0] Obj!Duration@12c8b81
    //     0xfad4e0: ldr             x1, [x1, #0xbf0]
    // 0xfad4e4: StoreField: r0->field_47 = r1
    //     0xfad4e4: stur            w1, [x0, #0x47]
    // 0xfad4e8: r1 = Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static.
    //     0xfad4e8: add             x1, PP, #0x18, lsl #12  ; [pp+0x18158] Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static. (0x7f2adac1b19c)
    //     0xfad4ec: ldr             x1, [x1, #0x158]
    // 0xfad4f0: StoreField: r0->field_4b = r1
    //     0xfad4f0: stur            w1, [x0, #0x4b]
    // 0xfad4f4: d0 = 3.000000
    //     0xfad4f4: fmov            d0, #3.00000000
    // 0xfad4f8: StoreField: r0->field_57 = d0
    //     0xfad4f8: stur            d0, [x0, #0x57]
    // 0xfad4fc: StoreField: r0->field_5f = rZR
    //     0xfad4fc: stur            xzr, [x0, #0x5f]
    // 0xfad500: LeaveFrame
    //     0xfad500: mov             SP, fp
    //     0xfad504: ldp             fp, lr, [SP], #0x10
    // 0xfad508: ret
    //     0xfad508: ret             
    // 0xfad50c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfad50c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfad510: b               #0xfad1b8
  }
}

// class id: 6203, size: 0x24, field offset: 0xc
//   const constructor, 
class _ActionSheetMainSheet extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfacfc4, size: 0x50
    // 0xfacfc4: EnterFrame
    //     0xfacfc4: stp             fp, lr, [SP, #-0x10]!
    //     0xfacfc8: mov             fp, SP
    // 0xfacfcc: CheckStackOverflow
    //     0xfacfcc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfacfd0: cmp             SP, x16
    //     0xfacfd4: b.ls            #0xfad00c
    // 0xfacfd8: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xfacfd8: ldur            w0, [x1, #0x17]
    // 0xfacfdc: DecompressPointer r0
    //     0xfacfdc: add             x0, x0, HEAP, lsl #32
    // 0xfacfe0: LoadField: r3 = r0->field_b
    //     0xfacfe0: ldur            w3, [x0, #0xb]
    // 0xfacfe4: cbnz            w3, #0xfacffc
    // 0xfacfe8: r0 = Instance_LimitedBox
    //     0xfacfe8: add             x0, PP, #0xd4, lsl #12  ; [pp+0xd4f00] Obj!LimitedBox@12b70c1
    //     0xfacfec: ldr             x0, [x0, #0xf00]
    // 0xfacff0: LeaveFrame
    //     0xfacff0: mov             SP, fp
    //     0xfacff4: ldp             fp, lr, [SP], #0x10
    // 0xfacff8: ret
    //     0xfacff8: ret             
    // 0xfacffc: r0 = _scrolledActionsSection()
    //     0xfacffc: bl              #0xfad014  ; [package:flutter/src/cupertino/dialog.dart] _ActionSheetMainSheet::_scrolledActionsSection
    // 0xfad000: LeaveFrame
    //     0xfad000: mov             SP, fp
    //     0xfad004: ldp             fp, lr, [SP], #0x10
    // 0xfad008: ret
    //     0xfad008: ret             
    // 0xfad00c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfad00c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfad010: b               #0xfacfd8
  }
  _ _scrolledActionsSection(/* No info */) {
    // ** addr: 0xfad014, size: 0x124
    // 0xfad014: EnterFrame
    //     0xfad014: stp             fp, lr, [SP, #-0x10]!
    //     0xfad018: mov             fp, SP
    // 0xfad01c: AllocStack(0x40)
    //     0xfad01c: sub             SP, SP, #0x40
    // 0xfad020: SetupParameters(_ActionSheetMainSheet this /* r1 => r0, fp-0x8 */)
    //     0xfad020: mov             x0, x1
    //     0xfad024: stur            x1, [fp, #-8]
    // 0xfad028: CheckStackOverflow
    //     0xfad028: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfad02c: cmp             SP, x16
    //     0xfad030: b.ls            #0xfad12c
    // 0xfad034: r1 = Instance_CupertinoDynamicColor
    //     0xfad034: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4f08] Obj!CupertinoDynamicColor@12b3d31
    //     0xfad038: ldr             x1, [x1, #0xf08]
    // 0xfad03c: r0 = resolveFrom()
    //     0xfad03c: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0xfad040: r1 = _ConstMap len:3
    //     0xfad040: add             x1, PP, #0xac, lsl #12  ; [pp+0xacc70] Map<CupertinoButtonSize, BorderRadius>(3)
    //     0xfad044: ldr             x1, [x1, #0xc70]
    // 0xfad048: r2 = Instance_CupertinoButtonSize
    //     0xfad048: add             x2, PP, #0x95, lsl #12  ; [pp+0x95fd8] Obj!CupertinoButtonSize@12c6081
    //     0xfad04c: ldr             x2, [x2, #0xfd8]
    // 0xfad050: stur            x0, [fp, #-0x10]
    // 0xfad054: r0 = []()
    //     0xfad054: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0xfad058: cmp             w0, NULL
    // 0xfad05c: b.eq            #0xfad134
    // 0xfad060: mov             x1, x0
    // 0xfad064: r0 = copyWith()
    //     0xfad064: bl              #0xfad144  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::copyWith
    // 0xfad068: mov             x1, x0
    // 0xfad06c: ldur            x0, [fp, #-8]
    // 0xfad070: stur            x1, [fp, #-0x40]
    // 0xfad074: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xfad074: ldur            w2, [x0, #0x17]
    // 0xfad078: DecompressPointer r2
    //     0xfad078: add             x2, x2, HEAP, lsl #32
    // 0xfad07c: stur            x2, [fp, #-0x38]
    // 0xfad080: LoadField: r3 = r0->field_13
    //     0xfad080: ldur            w3, [x0, #0x13]
    // 0xfad084: DecompressPointer r3
    //     0xfad084: add             x3, x3, HEAP, lsl #32
    // 0xfad088: stur            x3, [fp, #-0x30]
    // 0xfad08c: LoadField: r4 = r0->field_1f
    //     0xfad08c: ldur            w4, [x0, #0x1f]
    // 0xfad090: DecompressPointer r4
    //     0xfad090: add             x4, x4, HEAP, lsl #32
    // 0xfad094: stur            x4, [fp, #-0x28]
    // 0xfad098: LoadField: r5 = r0->field_b
    //     0xfad098: ldur            w5, [x0, #0xb]
    // 0xfad09c: DecompressPointer r5
    //     0xfad09c: add             x5, x5, HEAP, lsl #32
    // 0xfad0a0: stur            x5, [fp, #-0x20]
    // 0xfad0a4: LoadField: r6 = r0->field_f
    //     0xfad0a4: ldur            w6, [x0, #0xf]
    // 0xfad0a8: DecompressPointer r6
    //     0xfad0a8: add             x6, x6, HEAP, lsl #32
    // 0xfad0ac: stur            x6, [fp, #-0x18]
    // 0xfad0b0: r0 = _ActionSheetActionSection()
    //     0xfad0b0: bl              #0xfad138  ; Allocate_ActionSheetActionSectionStub -> _ActionSheetActionSection (size=0x20)
    // 0xfad0b4: mov             x1, x0
    // 0xfad0b8: ldur            x0, [fp, #-0x38]
    // 0xfad0bc: stur            x1, [fp, #-8]
    // 0xfad0c0: StoreField: r1->field_b = r0
    //     0xfad0c0: stur            w0, [x1, #0xb]
    // 0xfad0c4: ldur            x0, [fp, #-0x20]
    // 0xfad0c8: StoreField: r1->field_13 = r0
    //     0xfad0c8: stur            w0, [x1, #0x13]
    // 0xfad0cc: ldur            x0, [fp, #-0x28]
    // 0xfad0d0: ArrayStore: r1[0] = r0  ; List_4
    //     0xfad0d0: stur            w0, [x1, #0x17]
    // 0xfad0d4: ldur            x0, [fp, #-0x18]
    // 0xfad0d8: StoreField: r1->field_f = r0
    //     0xfad0d8: stur            w0, [x1, #0xf]
    // 0xfad0dc: ldur            x0, [fp, #-0x30]
    // 0xfad0e0: StoreField: r1->field_1b = r0
    //     0xfad0e0: stur            w0, [x1, #0x1b]
    // 0xfad0e4: r0 = CupertinoFocusHalo()
    //     0xfad0e4: bl              #0xde4cb4  ; AllocateCupertinoFocusHaloStub -> CupertinoFocusHalo (size=0x18)
    // 0xfad0e8: mov             x1, x0
    // 0xfad0ec: ldur            x0, [fp, #-8]
    // 0xfad0f0: stur            x1, [fp, #-0x18]
    // 0xfad0f4: StoreField: r1->field_13 = r0
    //     0xfad0f4: stur            w0, [x1, #0x13]
    // 0xfad0f8: ldur            x0, [fp, #-0x40]
    // 0xfad0fc: StoreField: r1->field_b = r0
    //     0xfad0fc: stur            w0, [x1, #0xb]
    // 0xfad100: r0 = Closure: ({BorderSide side, BorderRadiusGeometry borderRadius}) => RoundedRectangleBorder from Function 'RoundedRectangleBorder.': static.
    //     0xfad100: add             x0, PP, #0xd4, lsl #12  ; [pp+0xd4df8] Closure: ({BorderSide side, BorderRadiusGeometry borderRadius}) => RoundedRectangleBorder from Function 'RoundedRectangleBorder.': static. (0x7f2adacc9f8c)
    //     0xfad104: ldr             x0, [x0, #0xdf8]
    // 0xfad108: StoreField: r1->field_f = r0
    //     0xfad108: stur            w0, [x1, #0xf]
    // 0xfad10c: r0 = _OverscrollBackground()
    //     0xfad10c: bl              #0xde3f60  ; Allocate_OverscrollBackgroundStub -> _OverscrollBackground (size=0x14)
    // 0xfad110: ldur            x1, [fp, #-0x10]
    // 0xfad114: StoreField: r0->field_b = r1
    //     0xfad114: stur            w1, [x0, #0xb]
    // 0xfad118: ldur            x1, [fp, #-0x18]
    // 0xfad11c: StoreField: r0->field_f = r1
    //     0xfad11c: stur            w1, [x0, #0xf]
    // 0xfad120: LeaveFrame
    //     0xfad120: mov             SP, fp
    //     0xfad124: ldp             fp, lr, [SP], #0x10
    // 0xfad128: ret
    //     0xfad128: ret             
    // 0xfad12c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfad12c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfad130: b               #0xfad034
    // 0xfad134: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xfad134: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 6204, size: 0x20, field offset: 0xc
//   const constructor, 
class _ActionSheetActionSection extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfac9f0, size: 0x560
    // 0xfac9f0: EnterFrame
    //     0xfac9f0: stp             fp, lr, [SP, #-0x10]!
    //     0xfac9f4: mov             fp, SP
    // 0xfac9f8: AllocStack(0x50)
    //     0xfac9f8: sub             SP, SP, #0x50
    // 0xfac9fc: SetupParameters(_ActionSheetActionSection this /* r1 => r1, fp-0x8 */)
    //     0xfac9fc: stur            x1, [fp, #-8]
    // 0xfaca00: CheckStackOverflow
    //     0xfaca00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfaca04: cmp             SP, x16
    //     0xfaca08: b.ls            #0xfacf3c
    // 0xfaca0c: r1 = 1
    //     0xfaca0c: mov             x1, #1
    // 0xfaca10: r0 = AllocateContext()
    //     0xfaca10: bl              #0x13de838  ; AllocateContextStub
    // 0xfaca14: mov             x3, x0
    // 0xfaca18: ldur            x0, [fp, #-8]
    // 0xfaca1c: stur            x3, [fp, #-0x18]
    // 0xfaca20: StoreField: r3->field_f = r0
    //     0xfaca20: stur            w0, [x3, #0xf]
    // 0xfaca24: LoadField: r4 = r0->field_b
    //     0xfaca24: ldur            w4, [x0, #0xb]
    // 0xfaca28: DecompressPointer r4
    //     0xfaca28: add             x4, x4, HEAP, lsl #32
    // 0xfaca2c: stur            x4, [fp, #-0x10]
    // 0xfaca30: LoadField: r1 = r4->field_b
    //     0xfaca30: ldur            w1, [x4, #0xb]
    // 0xfaca34: cbnz            w1, #0xfaca4c
    // 0xfaca38: r0 = Instance_LimitedBox
    //     0xfaca38: add             x0, PP, #0xd4, lsl #12  ; [pp+0xd4f00] Obj!LimitedBox@12b70c1
    //     0xfaca3c: ldr             x0, [x0, #0xf00]
    // 0xfaca40: LeaveFrame
    //     0xfaca40: mov             SP, fp
    //     0xfaca44: ldp             fp, lr, [SP], #0x10
    // 0xfaca48: ret
    //     0xfaca48: ret             
    // 0xfaca4c: r1 = <Widget>
    //     0xfaca4c: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xfaca50: r2 = 0
    //     0xfaca50: mov             x2, #0
    // 0xfaca54: r0 = _GrowableList()
    //     0xfaca54: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xfaca58: stur            x0, [fp, #-0x20]
    // 0xfaca5c: r1 = 1
    //     0xfaca5c: mov             x1, #1
    // 0xfaca60: r0 = AllocateContext()
    //     0xfaca60: bl              #0x13de838  ; AllocateContextStub
    // 0xfaca64: mov             x1, x0
    // 0xfaca68: ldur            x0, [fp, #-0x18]
    // 0xfaca6c: StoreField: r1->field_b = r0
    //     0xfaca6c: stur            w0, [x1, #0xb]
    // 0xfaca70: StoreField: r1->field_f = rZR
    //     0xfaca70: stur            wzr, [x1, #0xf]
    // 0xfaca74: ldur            x2, [fp, #-8]
    // 0xfaca78: LoadField: r3 = r2->field_13
    //     0xfaca78: ldur            w3, [x2, #0x13]
    // 0xfaca7c: DecompressPointer r3
    //     0xfaca7c: add             x3, x3, HEAP, lsl #32
    // 0xfaca80: stur            x3, [fp, #-0x38]
    // 0xfaca84: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xfaca84: ldur            w4, [x2, #0x17]
    // 0xfaca88: DecompressPointer r4
    //     0xfaca88: add             x4, x4, HEAP, lsl #32
    // 0xfaca8c: stur            x4, [fp, #-0x30]
    // 0xfaca90: mov             x8, x1
    // 0xfaca94: r7 = 0
    //     0xfaca94: mov             x7, #0
    // 0xfaca98: ldur            x6, [fp, #-0x10]
    // 0xfaca9c: ldur            x5, [fp, #-0x20]
    // 0xfacaa0: stur            x8, [fp, #-0x28]
    // 0xfacaa4: CheckStackOverflow
    //     0xfacaa4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfacaa8: cmp             SP, x16
    //     0xfacaac: b.ls            #0xfacf44
    // 0xfacab0: LoadField: r0 = r6->field_b
    //     0xfacab0: ldur            w0, [x6, #0xb]
    // 0xfacab4: r1 = LoadInt32Instr(r0)
    //     0xfacab4: sbfx            x1, x0, #1, #0x1f
    // 0xfacab8: cmp             x7, x1
    // 0xfacabc: b.ge            #0xfacdf4
    // 0xfacac0: cbz             x7, #0xfacc30
    // 0xfacac4: sub             x9, x7, #1
    // 0xfacac8: r0 = BoxInt64Instr(r9)
    //     0xfacac8: sbfiz           x0, x9, #1, #0x1f
    //     0xfacacc: cmp             x9, x0, asr #1
    //     0xfacad0: b.eq            #0xfacadc
    //     0xfacad4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xfacad8: stur            x9, [x0, #7]
    // 0xfacadc: cmp             w3, w0
    // 0xfacae0: b.eq            #0xfacb1c
    // 0xfacae4: and             w16, w3, w0
    // 0xfacae8: branchIfSmi(r16, 0xfacb24)
    //     0xfacae8: tbz             w16, #0, #0xfacb24
    // 0xfacaec: r16 = LoadClassIdInstr(r3)
    //     0xfacaec: ldur            x16, [x3, #-1]
    //     0xfacaf0: ubfx            x16, x16, #0xc, #0x14
    // 0xfacaf4: cmp             x16, #0x3d
    // 0xfacaf8: b.ne            #0xfacb24
    // 0xfacafc: r16 = LoadClassIdInstr(r0)
    //     0xfacafc: ldur            x16, [x0, #-1]
    //     0xfacb00: ubfx            x16, x16, #0xc, #0x14
    // 0xfacb04: cmp             x16, #0x3d
    // 0xfacb08: b.ne            #0xfacb24
    // 0xfacb0c: LoadField: r16 = r3->field_7
    //     0xfacb0c: ldur            x16, [x3, #7]
    // 0xfacb10: LoadField: r17 = r0->field_7
    //     0xfacb10: ldur            x17, [x0, #7]
    // 0xfacb14: cmp             x16, x17
    // 0xfacb18: b.ne            #0xfacb24
    // 0xfacb1c: r0 = true
    //     0xfacb1c: add             x0, NULL, #0x20  ; true
    // 0xfacb20: b               #0xfacb88
    // 0xfacb24: r0 = BoxInt64Instr(r7)
    //     0xfacb24: sbfiz           x0, x7, #1, #0x1f
    //     0xfacb28: cmp             x7, x0, asr #1
    //     0xfacb2c: b.eq            #0xfacb38
    //     0xfacb30: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xfacb34: stur            x7, [x0, #7]
    // 0xfacb38: cmp             w3, w0
    // 0xfacb3c: b.eq            #0xfacb80
    // 0xfacb40: and             w16, w3, w0
    // 0xfacb44: branchIfSmi(r16, 0xfacb78)
    //     0xfacb44: tbz             w16, #0, #0xfacb78
    // 0xfacb48: r16 = LoadClassIdInstr(r3)
    //     0xfacb48: ldur            x16, [x3, #-1]
    //     0xfacb4c: ubfx            x16, x16, #0xc, #0x14
    // 0xfacb50: cmp             x16, #0x3d
    // 0xfacb54: b.ne            #0xfacb78
    // 0xfacb58: r16 = LoadClassIdInstr(r0)
    //     0xfacb58: ldur            x16, [x0, #-1]
    //     0xfacb5c: ubfx            x16, x16, #0xc, #0x14
    // 0xfacb60: cmp             x16, #0x3d
    // 0xfacb64: b.ne            #0xfacb78
    // 0xfacb68: LoadField: r16 = r3->field_7
    //     0xfacb68: ldur            x16, [x3, #7]
    // 0xfacb6c: LoadField: r17 = r0->field_7
    //     0xfacb6c: ldur            x17, [x0, #7]
    // 0xfacb70: cmp             x16, x17
    // 0xfacb74: b.eq            #0xfacb80
    // 0xfacb78: r1 = false
    //     0xfacb78: add             x1, NULL, #0x30  ; false
    // 0xfacb7c: b               #0xfacb84
    // 0xfacb80: r1 = true
    //     0xfacb80: add             x1, NULL, #0x20  ; true
    // 0xfacb84: mov             x0, x1
    // 0xfacb88: stur            x0, [fp, #-0x18]
    // 0xfacb8c: r0 = _Divider()
    //     0xfacb8c: bl              #0xde3f54  ; Allocate_DividerStub -> _Divider (size=0x18)
    // 0xfacb90: mov             x2, x0
    // 0xfacb94: ldur            x0, [fp, #-0x30]
    // 0xfacb98: stur            x2, [fp, #-0x48]
    // 0xfacb9c: StoreField: r2->field_b = r0
    //     0xfacb9c: stur            w0, [x2, #0xb]
    // 0xfacba0: r3 = Instance_CupertinoDynamicColor
    //     0xfacba0: add             x3, PP, #0xd4, lsl #12  ; [pp+0xd4f08] Obj!CupertinoDynamicColor@12b3d31
    //     0xfacba4: ldr             x3, [x3, #0xf08]
    // 0xfacba8: StoreField: r2->field_f = r3
    //     0xfacba8: stur            w3, [x2, #0xf]
    // 0xfacbac: ldur            x1, [fp, #-0x18]
    // 0xfacbb0: StoreField: r2->field_13 = r1
    //     0xfacbb0: stur            w1, [x2, #0x13]
    // 0xfacbb4: ldur            x4, [fp, #-0x20]
    // 0xfacbb8: LoadField: r1 = r4->field_b
    //     0xfacbb8: ldur            w1, [x4, #0xb]
    // 0xfacbbc: LoadField: r5 = r4->field_f
    //     0xfacbbc: ldur            w5, [x4, #0xf]
    // 0xfacbc0: DecompressPointer r5
    //     0xfacbc0: add             x5, x5, HEAP, lsl #32
    // 0xfacbc4: LoadField: r6 = r5->field_b
    //     0xfacbc4: ldur            w6, [x5, #0xb]
    // 0xfacbc8: r5 = LoadInt32Instr(r1)
    //     0xfacbc8: sbfx            x5, x1, #1, #0x1f
    // 0xfacbcc: stur            x5, [fp, #-0x40]
    // 0xfacbd0: r1 = LoadInt32Instr(r6)
    //     0xfacbd0: sbfx            x1, x6, #1, #0x1f
    // 0xfacbd4: cmp             x5, x1
    // 0xfacbd8: b.ne            #0xfacbe4
    // 0xfacbdc: mov             x1, x4
    // 0xfacbe0: r0 = _growToNextCapacity()
    //     0xfacbe0: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xfacbe4: ldur            x2, [fp, #-0x20]
    // 0xfacbe8: ldur            x3, [fp, #-0x40]
    // 0xfacbec: add             x0, x3, #1
    // 0xfacbf0: lsl             x1, x0, #1
    // 0xfacbf4: StoreField: r2->field_b = r1
    //     0xfacbf4: stur            w1, [x2, #0xb]
    // 0xfacbf8: LoadField: r1 = r2->field_f
    //     0xfacbf8: ldur            w1, [x2, #0xf]
    // 0xfacbfc: DecompressPointer r1
    //     0xfacbfc: add             x1, x1, HEAP, lsl #32
    // 0xfacc00: ldur            x0, [fp, #-0x48]
    // 0xfacc04: ArrayStore: r1[r3] = r0  ; List_4
    //     0xfacc04: add             x25, x1, x3, lsl #2
    //     0xfacc08: add             x25, x25, #0xf
    //     0xfacc0c: str             w0, [x25]
    //     0xfacc10: tbz             w0, #0, #0xfacc2c
    //     0xfacc14: ldurb           w16, [x1, #-1]
    //     0xfacc18: ldurb           w17, [x0, #-1]
    //     0xfacc1c: and             x16, x17, x16, lsr #2
    //     0xfacc20: tst             x16, HEAP, lsr #32
    //     0xfacc24: b.eq            #0xfacc2c
    //     0xfacc28: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xfacc2c: b               #0xfacc34
    // 0xfacc30: mov             x2, x5
    // 0xfacc34: ldur            x4, [fp, #-0x10]
    // 0xfacc38: ldur            x5, [fp, #-0x28]
    // 0xfacc3c: ldur            x3, [fp, #-0x38]
    // 0xfacc40: LoadField: r0 = r5->field_f
    //     0xfacc40: ldur            w0, [x5, #0xf]
    // 0xfacc44: DecompressPointer r0
    //     0xfacc44: add             x0, x0, HEAP, lsl #32
    // 0xfacc48: cmp             w3, w0
    // 0xfacc4c: b.eq            #0xfacc90
    // 0xfacc50: and             w16, w3, w0
    // 0xfacc54: branchIfSmi(r16, 0xfacc88)
    //     0xfacc54: tbz             w16, #0, #0xfacc88
    // 0xfacc58: r16 = LoadClassIdInstr(r3)
    //     0xfacc58: ldur            x16, [x3, #-1]
    //     0xfacc5c: ubfx            x16, x16, #0xc, #0x14
    // 0xfacc60: cmp             x16, #0x3d
    // 0xfacc64: b.ne            #0xfacc88
    // 0xfacc68: r16 = LoadClassIdInstr(r0)
    //     0xfacc68: ldur            x16, [x0, #-1]
    //     0xfacc6c: ubfx            x16, x16, #0xc, #0x14
    // 0xfacc70: cmp             x16, #0x3d
    // 0xfacc74: b.ne            #0xfacc88
    // 0xfacc78: LoadField: r16 = r3->field_7
    //     0xfacc78: ldur            x16, [x3, #7]
    // 0xfacc7c: LoadField: r17 = r0->field_7
    //     0xfacc7c: ldur            x17, [x0, #7]
    // 0xfacc80: cmp             x16, x17
    // 0xfacc84: b.eq            #0xfacc90
    // 0xfacc88: r6 = false
    //     0xfacc88: add             x6, NULL, #0x30  ; false
    // 0xfacc8c: b               #0xfacc94
    // 0xfacc90: r6 = true
    //     0xfacc90: add             x6, NULL, #0x20  ; true
    // 0xfacc94: stur            x6, [fp, #-0x48]
    // 0xfacc98: LoadField: r1 = r4->field_b
    //     0xfacc98: ldur            w1, [x4, #0xb]
    // 0xfacc9c: r7 = LoadInt32Instr(r0)
    //     0xfacc9c: sbfx            x7, x0, #1, #0x1f
    //     0xfacca0: tbz             w0, #0, #0xfacca8
    //     0xfacca4: ldur            x7, [x0, #7]
    // 0xfacca8: r0 = LoadInt32Instr(r1)
    //     0xfacca8: sbfx            x0, x1, #1, #0x1f
    // 0xfaccac: mov             x1, x7
    // 0xfaccb0: cmp             x1, x0
    // 0xfaccb4: b.hs            #0xfacf4c
    // 0xfaccb8: LoadField: r0 = r4->field_f
    //     0xfaccb8: ldur            w0, [x4, #0xf]
    // 0xfaccbc: DecompressPointer r0
    //     0xfaccbc: add             x0, x0, HEAP, lsl #32
    // 0xfaccc0: ArrayLoad: r1 = r0[r7]  ; Unknown_4
    //     0xfaccc0: add             x16, x0, x7, lsl #2
    //     0xfaccc4: ldur            w1, [x16, #0xf]
    // 0xfaccc8: DecompressPointer r1
    //     0xfaccc8: add             x1, x1, HEAP, lsl #32
    // 0xfacccc: stur            x1, [fp, #-0x18]
    // 0xfaccd0: r0 = _ActionSheetButtonBackground()
    //     0xfaccd0: bl              #0xde4cc0  ; Allocate_ActionSheetButtonBackgroundStub -> _ActionSheetButtonBackground (size=0x1c)
    // 0xfaccd4: mov             x3, x0
    // 0xfaccd8: r0 = false
    //     0xfaccd8: add             x0, NULL, #0x30  ; false
    // 0xfaccdc: stur            x3, [fp, #-0x50]
    // 0xfacce0: StoreField: r3->field_b = r0
    //     0xfacce0: stur            w0, [x3, #0xb]
    // 0xfacce4: ldur            x1, [fp, #-0x48]
    // 0xfacce8: StoreField: r3->field_f = r1
    //     0xfacce8: stur            w1, [x3, #0xf]
    // 0xfaccec: ldur            x2, [fp, #-0x28]
    // 0xfaccf0: r1 = Function '<anonymous closure>':.
    //     0xfaccf0: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4fb8] AnonymousClosure: (0xfacf5c), in [package:flutter/src/cupertino/dialog.dart] _ActionSheetActionSection::build (0xfac9f0)
    //     0xfaccf4: ldr             x1, [x1, #0xfb8]
    // 0xfaccf8: r0 = AllocateClosure()
    //     0xfaccf8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfaccfc: mov             x1, x0
    // 0xfacd00: ldur            x0, [fp, #-0x50]
    // 0xfacd04: StoreField: r0->field_13 = r1
    //     0xfacd04: stur            w1, [x0, #0x13]
    // 0xfacd08: ldur            x1, [fp, #-0x18]
    // 0xfacd0c: ArrayStore: r0[0] = r1  ; List_4
    //     0xfacd0c: stur            w1, [x0, #0x17]
    // 0xfacd10: ldur            x2, [fp, #-0x20]
    // 0xfacd14: LoadField: r1 = r2->field_b
    //     0xfacd14: ldur            w1, [x2, #0xb]
    // 0xfacd18: LoadField: r3 = r2->field_f
    //     0xfacd18: ldur            w3, [x2, #0xf]
    // 0xfacd1c: DecompressPointer r3
    //     0xfacd1c: add             x3, x3, HEAP, lsl #32
    // 0xfacd20: LoadField: r4 = r3->field_b
    //     0xfacd20: ldur            w4, [x3, #0xb]
    // 0xfacd24: r3 = LoadInt32Instr(r1)
    //     0xfacd24: sbfx            x3, x1, #1, #0x1f
    // 0xfacd28: stur            x3, [fp, #-0x40]
    // 0xfacd2c: r1 = LoadInt32Instr(r4)
    //     0xfacd2c: sbfx            x1, x4, #1, #0x1f
    // 0xfacd30: cmp             x3, x1
    // 0xfacd34: b.ne            #0xfacd40
    // 0xfacd38: mov             x1, x2
    // 0xfacd3c: r0 = _growToNextCapacity()
    //     0xfacd3c: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xfacd40: ldur            x2, [fp, #-0x20]
    // 0xfacd44: ldur            x3, [fp, #-0x40]
    // 0xfacd48: add             x0, x3, #1
    // 0xfacd4c: lsl             x1, x0, #1
    // 0xfacd50: StoreField: r2->field_b = r1
    //     0xfacd50: stur            w1, [x2, #0xb]
    // 0xfacd54: LoadField: r1 = r2->field_f
    //     0xfacd54: ldur            w1, [x2, #0xf]
    // 0xfacd58: DecompressPointer r1
    //     0xfacd58: add             x1, x1, HEAP, lsl #32
    // 0xfacd5c: ldur            x0, [fp, #-0x50]
    // 0xfacd60: ArrayStore: r1[r3] = r0  ; List_4
    //     0xfacd60: add             x25, x1, x3, lsl #2
    //     0xfacd64: add             x25, x25, #0xf
    //     0xfacd68: str             w0, [x25]
    //     0xfacd6c: tbz             w0, #0, #0xfacd88
    //     0xfacd70: ldurb           w16, [x1, #-1]
    //     0xfacd74: ldurb           w17, [x0, #-1]
    //     0xfacd78: and             x16, x17, x16, lsr #2
    //     0xfacd7c: tst             x16, HEAP, lsr #32
    //     0xfacd80: b.eq            #0xfacd88
    //     0xfacd84: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xfacd88: ldur            x5, [fp, #-0x28]
    // 0xfacd8c: r0 = CloneContext()
    //     0xfacd8c: bl              #0x13de1f4  ; CloneContextStub
    // 0xfacd90: mov             x2, x0
    // 0xfacd94: LoadField: r0 = r2->field_f
    //     0xfacd94: ldur            w0, [x2, #0xf]
    // 0xfacd98: DecompressPointer r0
    //     0xfacd98: add             x0, x0, HEAP, lsl #32
    // 0xfacd9c: r1 = LoadInt32Instr(r0)
    //     0xfacd9c: sbfx            x1, x0, #1, #0x1f
    //     0xfacda0: tbz             w0, #0, #0xfacda8
    //     0xfacda4: ldur            x1, [x0, #7]
    // 0xfacda8: add             x7, x1, #1
    // 0xfacdac: r0 = BoxInt64Instr(r7)
    //     0xfacdac: sbfiz           x0, x7, #1, #0x1f
    //     0xfacdb0: cmp             x7, x0, asr #1
    //     0xfacdb4: b.eq            #0xfacdc0
    //     0xfacdb8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xfacdbc: stur            x7, [x0, #7]
    // 0xfacdc0: StoreField: r2->field_f = r0
    //     0xfacdc0: stur            w0, [x2, #0xf]
    //     0xfacdc4: tbz             w0, #0, #0xfacde0
    //     0xfacdc8: ldurb           w16, [x2, #-1]
    //     0xfacdcc: ldurb           w17, [x0, #-1]
    //     0xfacdd0: and             x16, x17, x16, lsr #2
    //     0xfacdd4: tst             x16, HEAP, lsr #32
    //     0xfacdd8: b.eq            #0xfacde0
    //     0xfacddc: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xfacde0: mov             x8, x2
    // 0xfacde4: ldur            x2, [fp, #-8]
    // 0xfacde8: ldur            x3, [fp, #-0x38]
    // 0xfacdec: ldur            x4, [fp, #-0x30]
    // 0xfacdf0: b               #0xfaca98
    // 0xfacdf4: mov             x1, x2
    // 0xfacdf8: mov             x0, x5
    // 0xfacdfc: LoadField: r2 = r1->field_1b
    //     0xfacdfc: ldur            w2, [x1, #0x1b]
    // 0xface00: DecompressPointer r2
    //     0xface00: add             x2, x2, HEAP, lsl #32
    // 0xface04: stur            x2, [fp, #-0x10]
    // 0xface08: r0 = Column()
    //     0xface08: bl              #0x8a5b1c  ; AllocateColumnStub -> Column (size=0x38)
    // 0xface0c: mov             x1, x0
    // 0xface10: r0 = Instance_Axis
    //     0xface10: ldr             x0, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xface14: stur            x1, [fp, #-8]
    // 0xface18: StoreField: r1->field_f = r0
    //     0xface18: stur            w0, [x1, #0xf]
    // 0xface1c: r2 = Instance_MainAxisAlignment
    //     0xface1c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15820] Obj!MainAxisAlignment@12c4541
    //     0xface20: ldr             x2, [x2, #0x820]
    // 0xface24: StoreField: r1->field_13 = r2
    //     0xface24: stur            w2, [x1, #0x13]
    // 0xface28: r2 = Instance_MainAxisSize
    //     0xface28: add             x2, PP, #0x15, lsl #12  ; [pp+0x15828] Obj!MainAxisSize@12c4621
    //     0xface2c: ldr             x2, [x2, #0x828]
    // 0xface30: ArrayStore: r1[0] = r2  ; List_4
    //     0xface30: stur            w2, [x1, #0x17]
    // 0xface34: r2 = Instance_CrossAxisAlignment
    //     0xface34: add             x2, PP, #0x7b, lsl #12  ; [pp+0x7bc40] Obj!CrossAxisAlignment@12c4521
    //     0xface38: ldr             x2, [x2, #0xc40]
    // 0xface3c: StoreField: r1->field_1b = r2
    //     0xface3c: stur            w2, [x1, #0x1b]
    // 0xface40: r2 = Instance_VerticalDirection
    //     0xface40: add             x2, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xface44: ldr             x2, [x2, #0x838]
    // 0xface48: StoreField: r1->field_23 = r2
    //     0xface48: stur            w2, [x1, #0x23]
    // 0xface4c: r2 = Instance_Clip
    //     0xface4c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xface50: ldr             x2, [x2, #0x840]
    // 0xface54: StoreField: r1->field_2b = r2
    //     0xface54: stur            w2, [x1, #0x2b]
    // 0xface58: StoreField: r1->field_2f = rZR
    //     0xface58: stur            xzr, [x1, #0x2f]
    // 0xface5c: ldur            x2, [fp, #-0x20]
    // 0xface60: StoreField: r1->field_b = r2
    //     0xface60: stur            w2, [x1, #0xb]
    // 0xface64: r0 = SingleChildScrollView()
    //     0xface64: bl              #0xdc8fa4  ; AllocateSingleChildScrollViewStub -> SingleChildScrollView (size=0x3c)
    // 0xface68: mov             x1, x0
    // 0xface6c: r0 = Instance_Axis
    //     0xface6c: ldr             x0, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xface70: stur            x1, [fp, #-0x18]
    // 0xface74: StoreField: r1->field_b = r0
    //     0xface74: stur            w0, [x1, #0xb]
    // 0xface78: r0 = false
    //     0xface78: add             x0, NULL, #0x30  ; false
    // 0xface7c: StoreField: r1->field_f = r0
    //     0xface7c: stur            w0, [x1, #0xf]
    // 0xface80: ldur            x2, [fp, #-0x10]
    // 0xface84: ArrayStore: r1[0] = r2  ; List_4
    //     0xface84: stur            w2, [x1, #0x17]
    // 0xface88: ldur            x3, [fp, #-8]
    // 0xface8c: StoreField: r1->field_23 = r3
    //     0xface8c: stur            w3, [x1, #0x23]
    // 0xface90: r3 = Instance_DragStartBehavior
    //     0xface90: ldr             x3, [PP, #0x5360]  ; [pp+0x5360] Obj!DragStartBehavior@12c5c61
    // 0xface94: StoreField: r1->field_27 = r3
    //     0xface94: stur            w3, [x1, #0x27]
    // 0xface98: r3 = Instance_Clip
    //     0xface98: add             x3, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xface9c: ldr             x3, [x3, #0x850]
    // 0xfacea0: StoreField: r1->field_2b = r3
    //     0xfacea0: stur            w3, [x1, #0x2b]
    // 0xfacea4: r3 = Instance_HitTestBehavior
    //     0xfacea4: add             x3, PP, #0x15, lsl #12  ; [pp+0x155c0] Obj!HitTestBehavior@12c43c1
    //     0xfacea8: ldr             x3, [x3, #0x5c0]
    // 0xfaceac: StoreField: r1->field_2f = r3
    //     0xfaceac: stur            w3, [x1, #0x2f]
    // 0xfaceb0: r0 = CupertinoScrollbar()
    //     0xfaceb0: bl              #0xfacf50  ; AllocateCupertinoScrollbarStub -> CupertinoScrollbar (size=0x78)
    // 0xfaceb4: d0 = 8.000000
    //     0xfaceb4: fmov            d0, #8.00000000
    // 0xfaceb8: StoreField: r0->field_6b = d0
    //     0xfaceb8: stur            d0, [x0, #0x6b]
    // 0xfacebc: r1 = Instance_Radius
    //     0xfacebc: add             x1, PP, #0x9d, lsl #12  ; [pp+0x9d080] Obj!Radius@12a7121
    //     0xfacec0: ldr             x1, [x1, #0x80]
    // 0xfacec4: StoreField: r0->field_73 = r1
    //     0xfacec4: stur            w1, [x0, #0x73]
    // 0xfacec8: ldur            x1, [fp, #-0x18]
    // 0xfacecc: StoreField: r0->field_b = r1
    //     0xfacecc: stur            w1, [x0, #0xb]
    // 0xfaced0: ldur            x1, [fp, #-0x10]
    // 0xfaced4: StoreField: r0->field_f = r1
    //     0xfaced4: stur            w1, [x0, #0xf]
    // 0xfaced8: r1 = false
    //     0xfaced8: add             x1, NULL, #0x30  ; false
    // 0xfacedc: StoreField: r0->field_13 = r1
    //     0xfacedc: stur            w1, [x0, #0x13]
    // 0xfacee0: r1 = Instance_Radius
    //     0xfacee0: add             x1, PP, #0xb0, lsl #12  ; [pp+0xb08f8] Obj!Radius@12a71c1
    //     0xfacee4: ldr             x1, [x1, #0x8f8]
    // 0xfacee8: StoreField: r0->field_1b = r1
    //     0xfacee8: stur            w1, [x0, #0x1b]
    // 0xfaceec: r1 = 3.000000
    //     0xfaceec: add             x1, PP, #0x22, lsl #12  ; [pp+0x223f8] 3
    //     0xfacef0: ldr             x1, [x1, #0x3f8]
    // 0xfacef4: StoreField: r0->field_1f = r1
    //     0xfacef4: stur            w1, [x0, #0x1f]
    // 0xfacef8: d0 = 18.000000
    //     0xfacef8: fmov            d0, #18.00000000
    // 0xfacefc: StoreField: r0->field_27 = d0
    //     0xfacefc: stur            d0, [x0, #0x27]
    // 0xfacf00: r1 = Instance_Duration
    //     0xfacf00: add             x1, PP, #0xc, lsl #12  ; [pp+0xc920] Obj!Duration@12c89c1
    //     0xfacf04: ldr             x1, [x1, #0x920]
    // 0xfacf08: StoreField: r0->field_43 = r1
    //     0xfacf08: stur            w1, [x0, #0x43]
    // 0xfacf0c: r1 = Instance_Duration
    //     0xfacf0c: add             x1, PP, #0x94, lsl #12  ; [pp+0x94bf0] Obj!Duration@12c8b81
    //     0xfacf10: ldr             x1, [x1, #0xbf0]
    // 0xfacf14: StoreField: r0->field_47 = r1
    //     0xfacf14: stur            w1, [x0, #0x47]
    // 0xfacf18: r1 = Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static.
    //     0xfacf18: add             x1, PP, #0x18, lsl #12  ; [pp+0x18158] Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static. (0x7f2adac1b19c)
    //     0xfacf1c: ldr             x1, [x1, #0x158]
    // 0xfacf20: StoreField: r0->field_4b = r1
    //     0xfacf20: stur            w1, [x0, #0x4b]
    // 0xfacf24: d0 = 3.000000
    //     0xfacf24: fmov            d0, #3.00000000
    // 0xfacf28: StoreField: r0->field_57 = d0
    //     0xfacf28: stur            d0, [x0, #0x57]
    // 0xfacf2c: StoreField: r0->field_5f = rZR
    //     0xfacf2c: stur            xzr, [x0, #0x5f]
    // 0xfacf30: LeaveFrame
    //     0xfacf30: mov             SP, fp
    //     0xfacf34: ldp             fp, lr, [SP], #0x10
    // 0xfacf38: ret
    //     0xfacf38: ret             
    // 0xfacf3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfacf3c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfacf40: b               #0xfaca0c
    // 0xfacf44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfacf44: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfacf48: b               #0xfacab0
    // 0xfacf4c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xfacf4c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, bool) {
    // ** addr: 0xfacf5c, size: 0x68
    // 0xfacf5c: EnterFrame
    //     0xfacf5c: stp             fp, lr, [SP, #-0x10]!
    //     0xfacf60: mov             fp, SP
    // 0xfacf64: ldr             x0, [fp, #0x18]
    // 0xfacf68: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xfacf68: ldur            w1, [x0, #0x17]
    // 0xfacf6c: DecompressPointer r1
    //     0xfacf6c: add             x1, x1, HEAP, lsl #32
    // 0xfacf70: CheckStackOverflow
    //     0xfacf70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfacf74: cmp             SP, x16
    //     0xfacf78: b.ls            #0xfacfbc
    // 0xfacf7c: LoadField: r2 = r1->field_f
    //     0xfacf7c: ldur            w2, [x1, #0xf]
    // 0xfacf80: DecompressPointer r2
    //     0xfacf80: add             x2, x2, HEAP, lsl #32
    // 0xfacf84: LoadField: r0 = r1->field_b
    //     0xfacf84: ldur            w0, [x1, #0xb]
    // 0xfacf88: DecompressPointer r0
    //     0xfacf88: add             x0, x0, HEAP, lsl #32
    // 0xfacf8c: LoadField: r1 = r0->field_f
    //     0xfacf8c: ldur            w1, [x0, #0xf]
    // 0xfacf90: DecompressPointer r1
    //     0xfacf90: add             x1, x1, HEAP, lsl #32
    // 0xfacf94: LoadField: r0 = r1->field_f
    //     0xfacf94: ldur            w0, [x1, #0xf]
    // 0xfacf98: DecompressPointer r0
    //     0xfacf98: add             x0, x0, HEAP, lsl #32
    // 0xfacf9c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xfacf9c: ldur            w1, [x0, #0x17]
    // 0xfacfa0: DecompressPointer r1
    //     0xfacfa0: add             x1, x1, HEAP, lsl #32
    // 0xfacfa4: ldr             x3, [fp, #0x10]
    // 0xfacfa8: r0 = _onPressedUpdate()
    //     0xfacfa8: bl              #0xde4d40  ; [package:flutter/src/cupertino/dialog.dart] _CupertinoActionSheetState::_onPressedUpdate
    // 0xfacfac: r0 = Null
    //     0xfacfac: mov             x0, NULL
    // 0xfacfb0: LeaveFrame
    //     0xfacfb0: mov             SP, fp
    //     0xfacfb4: ldp             fp, lr, [SP], #0x10
    // 0xfacfb8: ret
    //     0xfacfb8: ret             
    // 0xfacfbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfacfbc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfacfc0: b               #0xfacf7c
  }
}

// class id: 6205, size: 0x18, field offset: 0xc
//   const constructor, 
class _Divider extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfac91c, size: 0xd4
    // 0xfac91c: EnterFrame
    //     0xfac91c: stp             fp, lr, [SP, #-0x10]!
    //     0xfac920: mov             fp, SP
    // 0xfac924: AllocStack(0x10)
    //     0xfac924: sub             SP, SP, #0x10
    // 0xfac928: CheckStackOverflow
    //     0xfac928: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfac92c: cmp             SP, x16
    //     0xfac930: b.ls            #0xfac9e8
    // 0xfac934: LoadField: r0 = r1->field_13
    //     0xfac934: ldur            w0, [x1, #0x13]
    // 0xfac938: DecompressPointer r0
    //     0xfac938: add             x0, x0, HEAP, lsl #32
    // 0xfac93c: tbnz            w0, #4, #0xfac954
    // 0xfac940: LoadField: r0 = r1->field_f
    //     0xfac940: ldur            w0, [x1, #0xf]
    // 0xfac944: DecompressPointer r0
    //     0xfac944: add             x0, x0, HEAP, lsl #32
    // 0xfac948: mov             x1, x0
    // 0xfac94c: r0 = resolveFrom()
    //     0xfac94c: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0xfac950: b               #0xfac95c
    // 0xfac954: LoadField: r0 = r1->field_b
    //     0xfac954: ldur            w0, [x1, #0xb]
    // 0xfac958: DecompressPointer r0
    //     0xfac958: add             x0, x0, HEAP, lsl #32
    // 0xfac95c: stur            x0, [fp, #-8]
    // 0xfac960: r0 = BoxDecoration()
    //     0xfac960: bl              #0x8a721c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0xfac964: mov             x1, x0
    // 0xfac968: ldur            x0, [fp, #-8]
    // 0xfac96c: stur            x1, [fp, #-0x10]
    // 0xfac970: StoreField: r1->field_7 = r0
    //     0xfac970: stur            w0, [x1, #7]
    // 0xfac974: r0 = Instance_BoxShape
    //     0xfac974: add             x0, PP, #0x17, lsl #12  ; [pp+0x171f8] Obj!BoxShape@12c4921
    //     0xfac978: ldr             x0, [x0, #0x1f8]
    // 0xfac97c: StoreField: r1->field_23 = r0
    //     0xfac97c: stur            w0, [x1, #0x23]
    // 0xfac980: r0 = DecoratedBox()
    //     0xfac980: bl              #0xd66318  ; AllocateDecoratedBoxStub -> DecoratedBox (size=0x18)
    // 0xfac984: mov             x1, x0
    // 0xfac988: ldur            x0, [fp, #-0x10]
    // 0xfac98c: stur            x1, [fp, #-8]
    // 0xfac990: StoreField: r1->field_f = r0
    //     0xfac990: stur            w0, [x1, #0xf]
    // 0xfac994: r0 = Instance_DecorationPosition
    //     0xfac994: add             x0, PP, #0x80, lsl #12  ; [pp+0x80ef0] Obj!DecorationPosition@12c4381
    //     0xfac998: ldr             x0, [x0, #0xef0]
    // 0xfac99c: StoreField: r1->field_13 = r0
    //     0xfac99c: stur            w0, [x1, #0x13]
    // 0xfac9a0: r0 = ConstrainedBox()
    //     0xfac9a0: bl              #0xd0a588  ; AllocateConstrainedBoxStub -> ConstrainedBox (size=0x14)
    // 0xfac9a4: mov             x1, x0
    // 0xfac9a8: r0 = Instance_BoxConstraints
    //     0xfac9a8: add             x0, PP, #0xb0, lsl #12  ; [pp+0xb0958] Obj!BoxConstraints@129c411
    //     0xfac9ac: ldr             x0, [x0, #0x958]
    // 0xfac9b0: stur            x1, [fp, #-0x10]
    // 0xfac9b4: StoreField: r1->field_f = r0
    //     0xfac9b4: stur            w0, [x1, #0xf]
    // 0xfac9b8: ldur            x0, [fp, #-8]
    // 0xfac9bc: StoreField: r1->field_b = r0
    //     0xfac9bc: stur            w0, [x1, #0xb]
    // 0xfac9c0: r0 = LimitedBox()
    //     0xfac9c0: bl              #0xd1a978  ; AllocateLimitedBoxStub -> LimitedBox (size=0x20)
    // 0xfac9c4: d0 = 0.300000
    //     0xfac9c4: add             x17, PP, #0x13, lsl #12  ; [pp+0x13a88] IMM: double(0.3) from 0x3fd3333333333333
    //     0xfac9c8: ldr             d0, [x17, #0xa88]
    // 0xfac9cc: StoreField: r0->field_f = d0
    //     0xfac9cc: stur            d0, [x0, #0xf]
    // 0xfac9d0: ArrayStore: r0[0] = d0  ; List_8
    //     0xfac9d0: stur            d0, [x0, #0x17]
    // 0xfac9d4: ldur            x1, [fp, #-0x10]
    // 0xfac9d8: StoreField: r0->field_b = r1
    //     0xfac9d8: stur            w1, [x0, #0xb]
    // 0xfac9dc: LeaveFrame
    //     0xfac9dc: mov             SP, fp
    //     0xfac9e0: ldp             fp, lr, [SP], #0x10
    // 0xfac9e4: ret
    //     0xfac9e4: ret             
    // 0xfac9e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfac9e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfac9ec: b               #0xfac934
  }
}

// class id: 6206, size: 0x18, field offset: 0xc
//   const constructor, 
class _ActionSheetActionContent extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfac5a4, size: 0x240
    // 0xfac5a4: EnterFrame
    //     0xfac5a4: stp             fp, lr, [SP, #-0x10]!
    //     0xfac5a8: mov             fp, SP
    // 0xfac5ac: AllocStack(0x48)
    //     0xfac5ac: sub             SP, SP, #0x48
    // 0xfac5b0: SetupParameters(_ActionSheetActionContent this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xfac5b0: mov             x0, x2
    //     0xfac5b4: stur            x2, [fp, #-0x10]
    //     0xfac5b8: mov             x2, x1
    //     0xfac5bc: stur            x1, [fp, #-8]
    // 0xfac5c0: CheckStackOverflow
    //     0xfac5c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfac5c4: cmp             SP, x16
    //     0xfac5c8: b.ls            #0xfac7c0
    // 0xfac5cc: mov             x1, x0
    // 0xfac5d0: r0 = textScalerOf()
    //     0xfac5d0: bl              #0xd16168  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::textScalerOf
    // 0xfac5d4: r1 = LoadClassIdInstr(r0)
    //     0xfac5d4: ldur            x1, [x0, #-1]
    //     0xfac5d8: ubfx            x1, x1, #0xc, #0x14
    // 0xfac5dc: mov             x16, x0
    // 0xfac5e0: mov             x0, x1
    // 0xfac5e4: mov             x1, x16
    // 0xfac5e8: d0 = 17.000000
    //     0xfac5e8: fmov            d0, #17.00000000
    // 0xfac5ec: r0 = GDT[cid_x0 + -0x1000]()
    //     0xfac5ec: sub             lr, x0, #1, lsl #12
    //     0xfac5f0: ldr             lr, [x21, lr, lsl #3]
    //     0xfac5f4: blr             lr
    // 0xfac5f8: LoadField: d0 = r0->field_7
    //     0xfac5f8: ldur            d0, [x0, #7]
    // 0xfac5fc: d1 = 17.000000
    //     0xfac5fc: fmov            d1, #17.00000000
    // 0xfac600: fdiv            d2, d0, d1
    // 0xfac604: stur            d2, [fp, #-0x28]
    // 0xfac608: r0 = _buttonFontSize()
    //     0xfac608: bl              #0xfac7e4  ; [package:flutter/src/cupertino/dialog.dart] _ActionSheetActionContent::_buttonFontSize
    // 0xfac60c: mov             v1.16b, v0.16b
    // 0xfac610: ldur            d0, [fp, #-0x28]
    // 0xfac614: stur            d1, [fp, #-0x38]
    // 0xfac618: fdiv            d2, d1, d0
    // 0xfac61c: ldur            x0, [fp, #-8]
    // 0xfac620: stur            d2, [fp, #-0x30]
    // 0xfac624: LoadField: r1 = r0->field_b
    //     0xfac624: ldur            w1, [x0, #0xb]
    // 0xfac628: DecompressPointer r1
    //     0xfac628: add             x1, x1, HEAP, lsl #32
    // 0xfac62c: tbnz            w1, #4, #0xfac648
    // 0xfac630: ldur            x2, [fp, #-0x10]
    // 0xfac634: r1 = Instance_CupertinoDynamicColor
    //     0xfac634: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4ed8] Obj!CupertinoDynamicColor@12b3eb1
    //     0xfac638: ldr             x1, [x1, #0xed8]
    // 0xfac63c: r0 = resolveFrom()
    //     0xfac63c: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0xfac640: mov             x1, x0
    // 0xfac644: b               #0xfac698
    // 0xfac648: ldur            x1, [fp, #-0x10]
    // 0xfac64c: r0 = of()
    //     0xfac64c: bl              #0xccc364  ; [package:flutter/src/cupertino/theme.dart] CupertinoTheme::of
    // 0xfac650: r1 = LoadClassIdInstr(r0)
    //     0xfac650: ldur            x1, [x0, #-1]
    //     0xfac654: ubfx            x1, x1, #0xc, #0x14
    // 0xfac658: r17 = 4617
    //     0xfac658: mov             x17, #0x1209
    // 0xfac65c: cmp             x1, x17
    // 0xfac660: b.ne            #0xfac678
    // 0xfac664: LoadField: r1 = r0->field_27
    //     0xfac664: ldur            w1, [x0, #0x27]
    // 0xfac668: DecompressPointer r1
    //     0xfac668: add             x1, x1, HEAP, lsl #32
    // 0xfac66c: LoadField: r0 = r1->field_b
    //     0xfac66c: ldur            w0, [x1, #0xb]
    // 0xfac670: DecompressPointer r0
    //     0xfac670: add             x0, x0, HEAP, lsl #32
    // 0xfac674: b               #0xfac694
    // 0xfac678: LoadField: r1 = r0->field_2b
    //     0xfac678: ldur            w1, [x0, #0x2b]
    // 0xfac67c: DecompressPointer r1
    //     0xfac67c: add             x1, x1, HEAP, lsl #32
    // 0xfac680: LoadField: r0 = r1->field_3f
    //     0xfac680: ldur            w0, [x1, #0x3f]
    // 0xfac684: DecompressPointer r0
    //     0xfac684: add             x0, x0, HEAP, lsl #32
    // 0xfac688: LoadField: r1 = r0->field_b
    //     0xfac688: ldur            w1, [x0, #0xb]
    // 0xfac68c: DecompressPointer r1
    //     0xfac68c: add             x1, x1, HEAP, lsl #32
    // 0xfac690: mov             x0, x1
    // 0xfac694: mov             x1, x0
    // 0xfac698: ldur            x0, [fp, #-8]
    // 0xfac69c: ldur            d0, [fp, #-0x38]
    // 0xfac6a0: ldur            d1, [fp, #-0x30]
    // 0xfac6a4: r2 = inline_Allocate_Double()
    //     0xfac6a4: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xfac6a8: add             x2, x2, #0x10
    //     0xfac6ac: cmp             x3, x2
    //     0xfac6b0: b.ls            #0xfac7c8
    //     0xfac6b4: str             x2, [THR, #0x60]  ; THR::top
    //     0xfac6b8: sub             x2, x2, #0xf
    //     0xfac6bc: mov             x3, #0xe19c
    //     0xfac6c0: movk            x3, #3, lsl #16
    //     0xfac6c4: stur            x3, [x2, #-1]
    // 0xfac6c8: dmb             ishst
    // 0xfac6cc: StoreField: r2->field_7 = d1
    //     0xfac6cc: stur            d1, [x2, #7]
    // 0xfac6d0: stp             x1, x2, [SP]
    // 0xfac6d4: r1 = Instance_TextStyle
    //     0xfac6d4: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4ee0] Obj!TextStyle@12b0fc1
    //     0xfac6d8: ldr             x1, [x1, #0xee0]
    // 0xfac6dc: r4 = const [0, 0x3, 0x2, 0x1, color, 0x2, fontSize, 0x1, null]
    //     0xfac6dc: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1fc10] List(9) [0, 0x3, 0x2, 0x1, "color", 0x2, "fontSize", 0x1, Null]
    //     0xfac6e0: ldr             x4, [x4, #0xc10]
    // 0xfac6e4: r0 = copyWith()
    //     0xfac6e4: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xfac6e8: ldur            d0, [fp, #-0x38]
    // 0xfac6ec: d1 = 0.400000
    //     0xfac6ec: add             x17, PP, #0x13, lsl #12  ; [pp+0x13368] IMM: double(0.4) from 0x3fd999999999999a
    //     0xfac6f0: ldr             d1, [x17, #0x368]
    // 0xfac6f4: stur            x0, [fp, #-0x10]
    // 0xfac6f8: fmul            d2, d0, d1
    // 0xfac6fc: d0 = 1.800000
    //     0xfac6fc: add             x17, PP, #0xd4, lsl #12  ; [pp+0xd4ee8] IMM: double(1.8) from 0x3ffccccccccccccd
    //     0xfac700: ldr             d0, [x17, #0xee8]
    // 0xfac704: fadd            d1, d2, d0
    // 0xfac708: stur            d1, [fp, #-0x28]
    // 0xfac70c: r0 = EdgeInsets()
    //     0xfac70c: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xfac710: d0 = 10.000000
    //     0xfac710: fmov            d0, #10.00000000
    // 0xfac714: stur            x0, [fp, #-0x20]
    // 0xfac718: StoreField: r0->field_7 = d0
    //     0xfac718: stur            d0, [x0, #7]
    // 0xfac71c: ldur            d1, [fp, #-0x28]
    // 0xfac720: StoreField: r0->field_f = d1
    //     0xfac720: stur            d1, [x0, #0xf]
    // 0xfac724: ArrayStore: r0[0] = d0  ; List_8
    //     0xfac724: stur            d0, [x0, #0x17]
    // 0xfac728: StoreField: r0->field_1f = d1
    //     0xfac728: stur            d1, [x0, #0x1f]
    // 0xfac72c: ldur            x1, [fp, #-8]
    // 0xfac730: LoadField: r2 = r1->field_13
    //     0xfac730: ldur            w2, [x1, #0x13]
    // 0xfac734: DecompressPointer r2
    //     0xfac734: add             x2, x2, HEAP, lsl #32
    // 0xfac738: stur            x2, [fp, #-0x18]
    // 0xfac73c: r0 = Center()
    //     0xfac73c: bl              #0xd0c898  ; AllocateCenterStub -> Center (size=0x1c)
    // 0xfac740: mov             x1, x0
    // 0xfac744: r0 = Instance_Alignment
    //     0xfac744: add             x0, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xfac748: ldr             x0, [x0, #0xb80]
    // 0xfac74c: stur            x1, [fp, #-8]
    // 0xfac750: StoreField: r1->field_f = r0
    //     0xfac750: stur            w0, [x1, #0xf]
    // 0xfac754: ldur            x0, [fp, #-0x18]
    // 0xfac758: StoreField: r1->field_b = r0
    //     0xfac758: stur            w0, [x1, #0xb]
    // 0xfac75c: r0 = DefaultTextStyle()
    //     0xfac75c: bl              #0xd0b11c  ; AllocateDefaultTextStyleStub -> DefaultTextStyle (size=0x2c)
    // 0xfac760: mov             x1, x0
    // 0xfac764: ldur            x0, [fp, #-0x10]
    // 0xfac768: stur            x1, [fp, #-0x18]
    // 0xfac76c: StoreField: r1->field_f = r0
    //     0xfac76c: stur            w0, [x1, #0xf]
    // 0xfac770: r0 = Instance_TextAlign
    //     0xfac770: ldr             x0, [PP, #0x4c68]  ; [pp+0x4c68] Obj!TextAlign@12c7561
    // 0xfac774: StoreField: r1->field_13 = r0
    //     0xfac774: stur            w0, [x1, #0x13]
    // 0xfac778: r0 = true
    //     0xfac778: add             x0, NULL, #0x20  ; true
    // 0xfac77c: ArrayStore: r1[0] = r0  ; List_4
    //     0xfac77c: stur            w0, [x1, #0x17]
    // 0xfac780: r0 = Instance_TextOverflow
    //     0xfac780: add             x0, PP, #0x20, lsl #12  ; [pp+0x20108] Obj!TextOverflow@12c47c1
    //     0xfac784: ldr             x0, [x0, #0x108]
    // 0xfac788: StoreField: r1->field_1b = r0
    //     0xfac788: stur            w0, [x1, #0x1b]
    // 0xfac78c: r0 = Instance_TextWidthBasis
    //     0xfac78c: add             x0, PP, #0x20, lsl #12  ; [pp+0x20110] Obj!TextWidthBasis@12c4781
    //     0xfac790: ldr             x0, [x0, #0x110]
    // 0xfac794: StoreField: r1->field_23 = r0
    //     0xfac794: stur            w0, [x1, #0x23]
    // 0xfac798: ldur            x0, [fp, #-8]
    // 0xfac79c: StoreField: r1->field_b = r0
    //     0xfac79c: stur            w0, [x1, #0xb]
    // 0xfac7a0: r0 = Padding()
    //     0xfac7a0: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xfac7a4: ldur            x1, [fp, #-0x20]
    // 0xfac7a8: StoreField: r0->field_f = r1
    //     0xfac7a8: stur            w1, [x0, #0xf]
    // 0xfac7ac: ldur            x1, [fp, #-0x18]
    // 0xfac7b0: StoreField: r0->field_b = r1
    //     0xfac7b0: stur            w1, [x0, #0xb]
    // 0xfac7b4: LeaveFrame
    //     0xfac7b4: mov             SP, fp
    //     0xfac7b8: ldp             fp, lr, [SP], #0x10
    // 0xfac7bc: ret
    //     0xfac7bc: ret             
    // 0xfac7c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfac7c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfac7c4: b               #0xfac5cc
    // 0xfac7c8: stp             q0, q1, [SP, #-0x20]!
    // 0xfac7cc: stp             x0, x1, [SP, #-0x10]!
    // 0xfac7d0: r0 = AllocateDouble()
    //     0xfac7d0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xfac7d4: mov             x2, x0
    // 0xfac7d8: ldp             x0, x1, [SP], #0x10
    // 0xfac7dc: ldp             q0, q1, [SP], #0x20
    // 0xfac7e0: b               #0xfac6cc
  }
  static _ _buttonFontSize(/* No info */) {
    // ** addr: 0xfac7e4, size: 0x138
    // 0xfac7e4: EnterFrame
    //     0xfac7e4: stp             fp, lr, [SP, #-0x10]!
    //     0xfac7e8: mov             fp, SP
    // 0xfac7ec: d1 = 17.000000
    //     0xfac7ec: fmov            d1, #17.00000000
    // 0xfac7f0: CheckStackOverflow
    //     0xfac7f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfac7f4: cmp             SP, x16
    //     0xfac7f8: b.ls            #0xfac8ec
    // 0xfac7fc: fcmp            d1, d0
    // 0xfac800: b.lt            #0xfac80c
    // 0xfac804: d0 = 21.000000
    //     0xfac804: fmov            d0, #21.00000000
    // 0xfac808: b               #0xfac8e0
    // 0xfac80c: d2 = 19.000000
    //     0xfac80c: fmov            d2, #19.00000000
    // 0xfac810: fcmp            d2, d0
    // 0xfac814: b.lt            #0xfac86c
    // 0xfac818: d3 = 2.000000
    //     0xfac818: fmov            d3, #2.00000000
    // 0xfac81c: fsub            d2, d0, d1
    // 0xfac820: fdiv            d0, d2, d3
    // 0xfac824: r3 = inline_Allocate_Double()
    //     0xfac824: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0xfac828: add             x3, x3, #0x10
    //     0xfac82c: cmp             x0, x3
    //     0xfac830: b.ls            #0xfac8f4
    //     0xfac834: str             x3, [THR, #0x60]  ; THR::top
    //     0xfac838: sub             x3, x3, #0xf
    //     0xfac83c: mov             x0, #0xe19c
    //     0xfac840: movk            x0, #3, lsl #16
    //     0xfac844: stur            x0, [x3, #-1]
    // 0xfac848: dmb             ishst
    // 0xfac84c: StoreField: r3->field_7 = d0
    //     0xfac84c: stur            d0, [x3, #7]
    // 0xfac850: r1 = 21.000000
    //     0xfac850: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4ef0] 21
    //     0xfac854: ldr             x1, [x1, #0xef0]
    // 0xfac858: r2 = 23.000000
    //     0xfac858: add             x2, PP, #0xd4, lsl #12  ; [pp+0xd4ef8] 23
    //     0xfac85c: ldr             x2, [x2, #0xef8]
    // 0xfac860: r0 = lerpDouble()
    //     0xfac860: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0xfac864: LoadField: d0 = r0->field_7
    //     0xfac864: ldur            d0, [x0, #7]
    // 0xfac868: b               #0xfac8e0
    // 0xfac86c: d3 = 2.000000
    //     0xfac86c: fmov            d3, #2.00000000
    // 0xfac870: d1 = 21.000000
    //     0xfac870: fmov            d1, #21.00000000
    // 0xfac874: fcmp            d1, d0
    // 0xfac878: b.lt            #0xfac8d0
    // 0xfac87c: fsub            d1, d0, d2
    // 0xfac880: fdiv            d0, d1, d3
    // 0xfac884: r3 = inline_Allocate_Double()
    //     0xfac884: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0xfac888: add             x3, x3, #0x10
    //     0xfac88c: cmp             x0, x3
    //     0xfac890: b.ls            #0xfac908
    //     0xfac894: str             x3, [THR, #0x60]  ; THR::top
    //     0xfac898: sub             x3, x3, #0xf
    //     0xfac89c: mov             x0, #0xe19c
    //     0xfac8a0: movk            x0, #3, lsl #16
    //     0xfac8a4: stur            x0, [x3, #-1]
    // 0xfac8a8: dmb             ishst
    // 0xfac8ac: StoreField: r3->field_7 = d0
    //     0xfac8ac: stur            d0, [x3, #7]
    // 0xfac8b0: r1 = 23.000000
    //     0xfac8b0: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4ef8] 23
    //     0xfac8b4: ldr             x1, [x1, #0xef8]
    // 0xfac8b8: r2 = 24.000000
    //     0xfac8b8: add             x2, PP, #0x1e, lsl #12  ; [pp+0x1e4d0] 24
    //     0xfac8bc: ldr             x2, [x2, #0x4d0]
    // 0xfac8c0: r0 = lerpDouble()
    //     0xfac8c0: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0xfac8c4: LoadField: d1 = r0->field_7
    //     0xfac8c4: ldur            d1, [x0, #7]
    // 0xfac8c8: mov             v0.16b, v1.16b
    // 0xfac8cc: b               #0xfac8e0
    // 0xfac8d0: d1 = 24.000000
    //     0xfac8d0: fmov            d1, #24.00000000
    // 0xfac8d4: fcmp            d1, d0
    // 0xfac8d8: b.lt            #0xfac8e0
    // 0xfac8dc: d0 = 24.000000
    //     0xfac8dc: fmov            d0, #24.00000000
    // 0xfac8e0: LeaveFrame
    //     0xfac8e0: mov             SP, fp
    //     0xfac8e4: ldp             fp, lr, [SP], #0x10
    // 0xfac8e8: ret
    //     0xfac8e8: ret             
    // 0xfac8ec: r0 = StackOverflowSharedWithFPURegs()
    //     0xfac8ec: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xfac8f0: b               #0xfac7fc
    // 0xfac8f4: SaveReg d0
    //     0xfac8f4: str             q0, [SP, #-0x10]!
    // 0xfac8f8: r0 = AllocateDouble()
    //     0xfac8f8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xfac8fc: mov             x3, x0
    // 0xfac900: RestoreReg d0
    //     0xfac900: ldr             q0, [SP], #0x10
    // 0xfac904: b               #0xfac84c
    // 0xfac908: SaveReg d0
    //     0xfac908: str             q0, [SP, #-0x10]!
    // 0xfac90c: r0 = AllocateDouble()
    //     0xfac90c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xfac910: mov             x3, x0
    // 0xfac914: RestoreReg d0
    //     0xfac914: ldr             q0, [SP], #0x10
    // 0xfac918: b               #0xfac8ac
  }
}

// class id: 6207, size: 0x10, field offset: 0xc
//   const constructor, 
class _ActionSheetGestureDetector extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfac008, size: 0xe8
    // 0xfac008: EnterFrame
    //     0xfac008: stp             fp, lr, [SP, #-0x10]!
    //     0xfac00c: mov             fp, SP
    // 0xfac010: AllocStack(0x28)
    //     0xfac010: sub             SP, SP, #0x28
    // 0xfac014: SetupParameters(_ActionSheetGestureDetector this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xfac014: stur            x1, [fp, #-8]
    //     0xfac018: stur            x2, [fp, #-0x10]
    // 0xfac01c: CheckStackOverflow
    //     0xfac01c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfac020: cmp             SP, x16
    //     0xfac024: b.ls            #0xfac0e8
    // 0xfac028: r1 = 2
    //     0xfac028: mov             x1, #2
    // 0xfac02c: r0 = AllocateContext()
    //     0xfac02c: bl              #0x13de838  ; AllocateContextStub
    // 0xfac030: mov             x1, x0
    // 0xfac034: ldur            x0, [fp, #-8]
    // 0xfac038: stur            x1, [fp, #-0x18]
    // 0xfac03c: StoreField: r1->field_f = r0
    //     0xfac03c: stur            w0, [x1, #0xf]
    // 0xfac040: ldur            x2, [fp, #-0x10]
    // 0xfac044: StoreField: r1->field_13 = r2
    //     0xfac044: stur            w2, [x1, #0x13]
    // 0xfac048: r16 = <Type, GestureRecognizerFactory<GestureRecognizer>>
    //     0xfac048: add             x16, PP, #0x15, lsl #12  ; [pp+0x15500] TypeArguments: <Type, GestureRecognizerFactory<GestureRecognizer>>
    //     0xfac04c: ldr             x16, [x16, #0x500]
    // 0xfac050: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0xfac054: stp             lr, x16, [SP]
    // 0xfac058: r0 = Map._fromLiteral()
    //     0xfac058: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xfac05c: r1 = <_TargetSelectionGestureRecognizer>
    //     0xfac05c: add             x1, PP, #0xb0, lsl #12  ; [pp+0xb0908] TypeArguments: <_TargetSelectionGestureRecognizer>
    //     0xfac060: ldr             x1, [x1, #0x908]
    // 0xfac064: stur            x0, [fp, #-0x10]
    // 0xfac068: r0 = GestureRecognizerFactoryWithHandlers()
    //     0xfac068: bl              #0xd37854  ; AllocateGestureRecognizerFactoryWithHandlersStub -> GestureRecognizerFactoryWithHandlers<X0 bound GestureRecognizer> (size=0x14)
    // 0xfac06c: ldur            x2, [fp, #-0x18]
    // 0xfac070: r1 = Function '<anonymous closure>':.
    //     0xfac070: add             x1, PP, #0xb0, lsl #12  ; [pp+0xb0910] AnonymousClosure: (0xfac0f0), in [package:flutter/src/cupertino/dialog.dart] _ActionSheetGestureDetector::build (0xfac008)
    //     0xfac074: ldr             x1, [x1, #0x910]
    // 0xfac078: stur            x0, [fp, #-0x18]
    // 0xfac07c: r0 = AllocateClosure()
    //     0xfac07c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfac080: ldur            x3, [fp, #-0x18]
    // 0xfac084: StoreField: r3->field_b = r0
    //     0xfac084: stur            w0, [x3, #0xb]
    // 0xfac088: r1 = Function '<anonymous closure>':.
    //     0xfac088: add             x1, PP, #0xb0, lsl #12  ; [pp+0xb0918] Function: [dart:ui] Shader::Shader._ (0x13cf838)
    //     0xfac08c: ldr             x1, [x1, #0x918]
    // 0xfac090: r2 = Null
    //     0xfac090: mov             x2, NULL
    // 0xfac094: r0 = AllocateClosure()
    //     0xfac094: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfac098: ldur            x3, [fp, #-0x18]
    // 0xfac09c: StoreField: r3->field_f = r0
    //     0xfac09c: stur            w0, [x3, #0xf]
    // 0xfac0a0: ldur            x1, [fp, #-0x10]
    // 0xfac0a4: r2 = _TargetSelectionGestureRecognizer
    //     0xfac0a4: add             x2, PP, #0xb0, lsl #12  ; [pp+0xb0920] Type: _TargetSelectionGestureRecognizer
    //     0xfac0a8: ldr             x2, [x2, #0x920]
    // 0xfac0ac: r0 = []=()
    //     0xfac0ac: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xfac0b0: ldur            x0, [fp, #-8]
    // 0xfac0b4: LoadField: r1 = r0->field_b
    //     0xfac0b4: ldur            w1, [x0, #0xb]
    // 0xfac0b8: DecompressPointer r1
    //     0xfac0b8: add             x1, x1, HEAP, lsl #32
    // 0xfac0bc: stur            x1, [fp, #-0x18]
    // 0xfac0c0: r0 = RawGestureDetector()
    //     0xfac0c0: bl              #0xd37630  ; AllocateRawGestureDetectorStub -> RawGestureDetector (size=0x20)
    // 0xfac0c4: ldur            x1, [fp, #-0x18]
    // 0xfac0c8: StoreField: r0->field_b = r1
    //     0xfac0c8: stur            w1, [x0, #0xb]
    // 0xfac0cc: ldur            x1, [fp, #-0x10]
    // 0xfac0d0: StoreField: r0->field_f = r1
    //     0xfac0d0: stur            w1, [x0, #0xf]
    // 0xfac0d4: r1 = true
    //     0xfac0d4: add             x1, NULL, #0x20  ; true
    // 0xfac0d8: ArrayStore: r0[0] = r1  ; List_4
    //     0xfac0d8: stur            w1, [x0, #0x17]
    // 0xfac0dc: LeaveFrame
    //     0xfac0dc: mov             SP, fp
    //     0xfac0e0: ldp             fp, lr, [SP], #0x10
    // 0xfac0e4: ret
    //     0xfac0e4: ret             
    // 0xfac0e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfac0e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfac0ec: b               #0xfac028
  }
  [closure] _TargetSelectionGestureRecognizer <anonymous closure>(dynamic) {
    // ** addr: 0xfac0f0, size: 0x60
    // 0xfac0f0: EnterFrame
    //     0xfac0f0: stp             fp, lr, [SP, #-0x10]!
    //     0xfac0f4: mov             fp, SP
    // 0xfac0f8: AllocStack(0x8)
    //     0xfac0f8: sub             SP, SP, #8
    // 0xfac0fc: SetupParameters([dynamic _ /* r0 */])
    //     0xfac0fc: ldr             x0, [fp, #0x10]
    //     0xfac100: ldur            w2, [x0, #0x17]
    //     0xfac104: add             x2, x2, HEAP, lsl #32
    // 0xfac108: CheckStackOverflow
    //     0xfac108: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfac10c: cmp             SP, x16
    //     0xfac110: b.ls            #0xfac148
    // 0xfac114: r1 = Function '<anonymous closure>':.
    //     0xfac114: add             x1, PP, #0xb0, lsl #12  ; [pp+0xb0928] AnonymousClosure: (0xfac4d8), in [package:flutter/src/cupertino/dialog.dart] _ActionSheetGestureDetector::build (0xfac008)
    //     0xfac118: ldr             x1, [x1, #0x928]
    // 0xfac11c: r0 = AllocateClosure()
    //     0xfac11c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfac120: stur            x0, [fp, #-8]
    // 0xfac124: r0 = _TargetSelectionGestureRecognizer()
    //     0xfac124: bl              #0xfac4cc  ; Allocate_TargetSelectionGestureRecognizerStub -> _TargetSelectionGestureRecognizer (size=0x24)
    // 0xfac128: mov             x1, x0
    // 0xfac12c: ldur            x2, [fp, #-8]
    // 0xfac130: stur            x0, [fp, #-8]
    // 0xfac134: r0 = _TargetSelectionGestureRecognizer()
    //     0xfac134: bl              #0xfac150  ; [package:flutter/src/cupertino/dialog.dart] _TargetSelectionGestureRecognizer::_TargetSelectionGestureRecognizer
    // 0xfac138: ldur            x0, [fp, #-8]
    // 0xfac13c: LeaveFrame
    //     0xfac13c: mov             SP, fp
    //     0xfac140: ldp             fp, lr, [SP], #0x10
    // 0xfac144: ret
    //     0xfac144: ret             
    // 0xfac148: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfac148: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfac14c: b               #0xfac114
  }
  [closure] HitTestResult <anonymous closure>(dynamic, Offset) {
    // ** addr: 0xfac4d8, size: 0x50
    // 0xfac4d8: EnterFrame
    //     0xfac4d8: stp             fp, lr, [SP, #-0x10]!
    //     0xfac4dc: mov             fp, SP
    // 0xfac4e0: ldr             x0, [fp, #0x18]
    // 0xfac4e4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xfac4e4: ldur            w1, [x0, #0x17]
    // 0xfac4e8: DecompressPointer r1
    //     0xfac4e8: add             x1, x1, HEAP, lsl #32
    // 0xfac4ec: CheckStackOverflow
    //     0xfac4ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfac4f0: cmp             SP, x16
    //     0xfac4f4: b.ls            #0xfac520
    // 0xfac4f8: LoadField: r0 = r1->field_f
    //     0xfac4f8: ldur            w0, [x1, #0xf]
    // 0xfac4fc: DecompressPointer r0
    //     0xfac4fc: add             x0, x0, HEAP, lsl #32
    // 0xfac500: LoadField: r2 = r1->field_13
    //     0xfac500: ldur            w2, [x1, #0x13]
    // 0xfac504: DecompressPointer r2
    //     0xfac504: add             x2, x2, HEAP, lsl #32
    // 0xfac508: mov             x1, x0
    // 0xfac50c: ldr             x3, [fp, #0x10]
    // 0xfac510: r0 = _hitTest()
    //     0xfac510: bl              #0xfac528  ; [package:flutter/src/cupertino/dialog.dart] _ActionSheetGestureDetector::_hitTest
    // 0xfac514: LeaveFrame
    //     0xfac514: mov             SP, fp
    //     0xfac518: ldp             fp, lr, [SP], #0x10
    // 0xfac51c: ret
    //     0xfac51c: ret             
    // 0xfac520: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfac520: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfac524: b               #0xfac4f8
  }
  _ _hitTest(/* No info */) {
    // ** addr: 0xfac528, size: 0x7c
    // 0xfac528: EnterFrame
    //     0xfac528: stp             fp, lr, [SP, #-0x10]!
    //     0xfac52c: mov             fp, SP
    // 0xfac530: AllocStack(0x18)
    //     0xfac530: sub             SP, SP, #0x18
    // 0xfac534: SetupParameters(_ActionSheetGestureDetector this /* r1 => r0 */, dynamic _ /* r2 => r1 */, dynamic _ /* r3 => r3, fp-0x8 */)
    //     0xfac534: mov             x0, x1
    //     0xfac538: mov             x1, x2
    //     0xfac53c: stur            x3, [fp, #-8]
    // 0xfac540: CheckStackOverflow
    //     0xfac540: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfac544: cmp             SP, x16
    //     0xfac548: b.ls            #0xfac598
    // 0xfac54c: r0 = of()
    //     0xfac54c: bl              #0x864fc4  ; [package:flutter/src/widgets/view.dart] View::of
    // 0xfac550: LoadField: r5 = r0->field_7
    //     0xfac550: ldur            x5, [x0, #7]
    // 0xfac554: stur            x5, [fp, #-0x10]
    // 0xfac558: r0 = HitTestResult()
    //     0xfac558: bl              #0x836ee0  ; AllocateHitTestResultStub -> HitTestResult (size=0x14)
    // 0xfac55c: mov             x1, x0
    // 0xfac560: stur            x0, [fp, #-0x18]
    // 0xfac564: r0 = HitTestResult()
    //     0xfac564: bl              #0x836bac  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::HitTestResult
    // 0xfac568: r1 = LoadStaticField(0x6a0)
    //     0xfac568: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0xfac56c: ldr             x1, [x1, #0xd40]
    // 0xfac570: cmp             w1, NULL
    // 0xfac574: b.eq            #0xfac5a0
    // 0xfac578: ldur            x2, [fp, #-0x18]
    // 0xfac57c: ldur            x3, [fp, #-8]
    // 0xfac580: ldur            x5, [fp, #-0x10]
    // 0xfac584: r0 = hitTestInView()
    //     0xfac584: bl              #0x83663c  ; [dart:mixin_deduplication] _MixinApplication207&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding&PaintingBinding&SemanticsBinding&RendererBinding::hitTestInView
    // 0xfac588: ldur            x0, [fp, #-0x18]
    // 0xfac58c: LeaveFrame
    //     0xfac58c: mov             SP, fp
    //     0xfac590: ldp             fp, lr, [SP], #0x10
    // 0xfac594: ret
    //     0xfac594: ret             
    // 0xfac598: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfac598: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfac59c: b               #0xfac54c
    // 0xfac5a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xfac5a0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 6208, size: 0x1c, field offset: 0xc
//   const constructor, 
class CupertinoPopupSurface extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfabe6c, size: 0xbc
    // 0xfabe6c: EnterFrame
    //     0xfabe6c: stp             fp, lr, [SP, #-0x10]!
    //     0xfabe70: mov             fp, SP
    // 0xfabe74: AllocStack(0x18)
    //     0xfabe74: sub             SP, SP, #0x18
    // 0xfabe78: SetupParameters(CupertinoPopupSurface this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1 */)
    //     0xfabe78: mov             x0, x1
    //     0xfabe7c: stur            x1, [fp, #-8]
    //     0xfabe80: mov             x1, x2
    // 0xfabe84: CheckStackOverflow
    //     0xfabe84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfabe88: cmp             SP, x16
    //     0xfabe8c: b.ls            #0xfabf20
    // 0xfabe90: r0 = maybeBrightnessOf()
    //     0xfabe90: bl              #0xce22c0  ; [package:flutter/src/cupertino/theme.dart] CupertinoTheme::maybeBrightnessOf
    // 0xfabe94: ldur            x1, [fp, #-8]
    // 0xfabe98: mov             x2, x0
    // 0xfabe9c: r0 = _buildFilter()
    //     0xfabe9c: bl              #0xfabf28  ; [package:flutter/src/cupertino/dialog.dart] CupertinoPopupSurface::_buildFilter
    // 0xfabea0: mov             x1, x0
    // 0xfabea4: ldur            x0, [fp, #-8]
    // 0xfabea8: stur            x1, [fp, #-0x18]
    // 0xfabeac: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xfabeac: ldur            w2, [x0, #0x17]
    // 0xfabeb0: DecompressPointer r2
    //     0xfabeb0: add             x2, x2, HEAP, lsl #32
    // 0xfabeb4: stur            x2, [fp, #-0x10]
    // 0xfabeb8: r0 = BackdropFilter()
    //     0xfabeb8: bl              #0x9190e4  ; AllocateBackdropFilterStub -> BackdropFilter (size=0x28)
    // 0xfabebc: mov             x1, x0
    // 0xfabec0: ldur            x0, [fp, #-0x18]
    // 0xfabec4: stur            x1, [fp, #-8]
    // 0xfabec8: StoreField: r1->field_13 = r0
    //     0xfabec8: stur            w0, [x1, #0x13]
    // 0xfabecc: r0 = Instance_BlendMode
    //     0xfabecc: add             x0, PP, #0x16, lsl #12  ; [pp+0x16eb8] Obj!BlendMode@12c82e1
    //     0xfabed0: ldr             x0, [x0, #0xeb8]
    // 0xfabed4: ArrayStore: r1[0] = r0  ; List_4
    //     0xfabed4: stur            w0, [x1, #0x17]
    // 0xfabed8: r0 = true
    //     0xfabed8: add             x0, NULL, #0x20  ; true
    // 0xfabedc: StoreField: r1->field_1b = r0
    //     0xfabedc: stur            w0, [x1, #0x1b]
    // 0xfabee0: r0 = false
    //     0xfabee0: add             x0, NULL, #0x30  ; false
    // 0xfabee4: StoreField: r1->field_23 = r0
    //     0xfabee4: stur            w0, [x1, #0x23]
    // 0xfabee8: ldur            x0, [fp, #-0x10]
    // 0xfabeec: StoreField: r1->field_b = r0
    //     0xfabeec: stur            w0, [x1, #0xb]
    // 0xfabef0: r0 = ClipRSuperellipse()
    //     0xfabef0: bl              #0xde4e24  ; AllocateClipRSuperellipseStub -> ClipRSuperellipse (size=0x1c)
    // 0xfabef4: r1 = Instance_BorderRadius
    //     0xfabef4: add             x1, PP, #0xb0, lsl #12  ; [pp+0xb08d0] Obj!BorderRadius@129e4d1
    //     0xfabef8: ldr             x1, [x1, #0x8d0]
    // 0xfabefc: StoreField: r0->field_f = r1
    //     0xfabefc: stur            w1, [x0, #0xf]
    // 0xfabf00: r1 = Instance_Clip
    //     0xfabf00: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e6f0] Obj!Clip@12c8101
    //     0xfabf04: ldr             x1, [x1, #0x6f0]
    // 0xfabf08: ArrayStore: r0[0] = r1  ; List_4
    //     0xfabf08: stur            w1, [x0, #0x17]
    // 0xfabf0c: ldur            x1, [fp, #-8]
    // 0xfabf10: StoreField: r0->field_b = r1
    //     0xfabf10: stur            w1, [x0, #0xb]
    // 0xfabf14: LeaveFrame
    //     0xfabf14: mov             SP, fp
    //     0xfabf18: ldp             fp, lr, [SP], #0x10
    // 0xfabf1c: ret
    //     0xfabf1c: ret             
    // 0xfabf20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfabf20: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfabf24: b               #0xfabe90
  }
  _ _buildFilter(/* No info */) {
    // ** addr: 0xfabf28, size: 0xc8
    // 0xfabf28: EnterFrame
    //     0xfabf28: stp             fp, lr, [SP, #-0x10]!
    //     0xfabf2c: mov             fp, SP
    // 0xfabf30: AllocStack(0x10)
    //     0xfabf30: sub             SP, SP, #0x10
    // 0xfabf34: r16 = Instance_Brightness
    //     0xfabf34: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0xfabf38: cmp             w2, w16
    // 0xfabf3c: b.ne            #0xfabf4c
    // 0xfabf40: r0 = Instance_ColorFilter
    //     0xfabf40: add             x0, PP, #0xb0, lsl #12  ; [pp+0xb08d8] Obj!ColorFilter@12a1531
    //     0xfabf44: ldr             x0, [x0, #0x8d8]
    // 0xfabf48: b               #0xfabf70
    // 0xfabf4c: r16 = Instance_Brightness
    //     0xfabf4c: ldr             x16, [PP, #0x6da0]  ; [pp+0x6da0] Obj!Brightness@12c71c1
    // 0xfabf50: cmp             w2, w16
    // 0xfabf54: b.eq            #0xfabf60
    // 0xfabf58: cmp             w2, NULL
    // 0xfabf5c: b.ne            #0xfabf6c
    // 0xfabf60: r0 = Instance_ColorFilter
    //     0xfabf60: add             x0, PP, #0xb0, lsl #12  ; [pp+0xb08e0] Obj!ColorFilter@12a1511
    //     0xfabf64: ldr             x0, [x0, #0x8e0]
    // 0xfabf68: b               #0xfabf70
    // 0xfabf6c: r0 = Null
    //     0xfabf6c: mov             x0, NULL
    // 0xfabf70: stur            x0, [fp, #-8]
    // 0xfabf74: r0 = _DirectImageFilterConfig()
    //     0xfabf74: bl              #0xcf5b04  ; Allocate_DirectImageFilterConfigStub -> _DirectImageFilterConfig (size=0xc)
    // 0xfabf78: mov             x1, x0
    // 0xfabf7c: ldur            x0, [fp, #-8]
    // 0xfabf80: stur            x1, [fp, #-0x10]
    // 0xfabf84: StoreField: r1->field_7 = r0
    //     0xfabf84: stur            w0, [x1, #7]
    // 0xfabf88: d1 = 0.000000
    //     0xfabf88: eor             v1.16b, v1.16b, v1.16b
    // 0xfabf8c: d0 = 30.000000
    //     0xfabf8c: fmov            d0, #30.00000000
    // 0xfabf90: fcmp            d1, d0
    // 0xfabf94: b.ne            #0xfabfa8
    // 0xfabf98: mov             x0, x1
    // 0xfabf9c: LeaveFrame
    //     0xfabf9c: mov             SP, fp
    //     0xfabfa0: ldp             fp, lr, [SP], #0x10
    // 0xfabfa4: ret
    //     0xfabfa4: ret             
    // 0xfabfa8: r0 = _BlurImageFilterConfig()
    //     0xfabfa8: bl              #0xfabffc  ; Allocate_BlurImageFilterConfigStub -> _BlurImageFilterConfig (size=0x20)
    // 0xfabfac: d0 = 30.000000
    //     0xfabfac: fmov            d0, #30.00000000
    // 0xfabfb0: stur            x0, [fp, #-8]
    // 0xfabfb4: StoreField: r0->field_7 = d0
    //     0xfabfb4: stur            d0, [x0, #7]
    // 0xfabfb8: StoreField: r0->field_f = d0
    //     0xfabfb8: stur            d0, [x0, #0xf]
    // 0xfabfbc: r1 = Instance_TileMode
    //     0xfabfbc: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e900] Obj!TileMode@12c7f61
    //     0xfabfc0: ldr             x1, [x1, #0x900]
    // 0xfabfc4: ArrayStore: r0[0] = r1  ; List_4
    //     0xfabfc4: stur            w1, [x0, #0x17]
    // 0xfabfc8: r1 = false
    //     0xfabfc8: add             x1, NULL, #0x30  ; false
    // 0xfabfcc: StoreField: r0->field_1b = r1
    //     0xfabfcc: stur            w1, [x0, #0x1b]
    // 0xfabfd0: r0 = _ComposeImageFilterConfig()
    //     0xfabfd0: bl              #0xfabff0  ; Allocate_ComposeImageFilterConfigStub -> _ComposeImageFilterConfig (size=0x10)
    // 0xfabfd4: ldur            x1, [fp, #-8]
    // 0xfabfd8: StoreField: r0->field_7 = r1
    //     0xfabfd8: stur            w1, [x0, #7]
    // 0xfabfdc: ldur            x1, [fp, #-0x10]
    // 0xfabfe0: StoreField: r0->field_b = r1
    //     0xfabfe0: stur            w1, [x0, #0xb]
    // 0xfabfe4: LeaveFrame
    //     0xfabfe4: mov             SP, fp
    //     0xfabfe8: ldp             fp, lr, [SP], #0x10
    // 0xfabfec: ret
    //     0xfabfec: ret             
  }
}

// class id: 6518, size: 0x24, field offset: 0xc
//   const constructor, 
class CupertinoDialogAction extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa052c, size: 0x24
    // 0xfa052c: EnterFrame
    //     0xfa052c: stp             fp, lr, [SP, #-0x10]!
    //     0xfa0530: mov             fp, SP
    // 0xfa0534: mov             x0, x1
    // 0xfa0538: r1 = <CupertinoDialogAction>
    //     0xfa0538: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa1048] TypeArguments: <CupertinoDialogAction>
    //     0xfa053c: ldr             x1, [x1, #0x48]
    // 0xfa0540: r0 = _CupertinoDialogActionState()
    //     0xfa0540: bl              #0xfa0550  ; Allocate_CupertinoDialogActionStateStub -> _CupertinoDialogActionState (size=0x14)
    // 0xfa0544: LeaveFrame
    //     0xfa0544: mov             SP, fp
    //     0xfa0548: ldp             fp, lr, [SP], #0x10
    // 0xfa054c: ret
    //     0xfa054c: ret             
  }
}

// class id: 6519, size: 0x20, field offset: 0xc
//   const constructor, 
class _AlertDialogButtonBackground extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa04fc, size: 0x24
    // 0xfa04fc: EnterFrame
    //     0xfa04fc: stp             fp, lr, [SP, #-0x10]!
    //     0xfa0500: mov             fp, SP
    // 0xfa0504: mov             x0, x1
    // 0xfa0508: r1 = <_AlertDialogButtonBackground>
    //     0xfa0508: add             x1, PP, #0xcf, lsl #12  ; [pp+0xcf820] TypeArguments: <_AlertDialogButtonBackground>
    //     0xfa050c: ldr             x1, [x1, #0x820]
    // 0xfa0510: r0 = _AlertDialogButtonBackgroundState()
    //     0xfa0510: bl              #0xfa0520  ; Allocate_AlertDialogButtonBackgroundStateStub -> _AlertDialogButtonBackgroundState (size=0x14)
    // 0xfa0514: LeaveFrame
    //     0xfa0514: mov             SP, fp
    //     0xfa0518: ldp             fp, lr, [SP], #0x10
    // 0xfa051c: ret
    //     0xfa051c: ret             
  }
}

// class id: 6520, size: 0x14, field offset: 0xc
//   const constructor, 
class _OverscrollBackground extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa04c4, size: 0x2c
    // 0xfa04c4: EnterFrame
    //     0xfa04c4: stp             fp, lr, [SP, #-0x10]!
    //     0xfa04c8: mov             fp, SP
    // 0xfa04cc: mov             x0, x1
    // 0xfa04d0: r1 = <_OverscrollBackground>
    //     0xfa04d0: add             x1, PP, #0xb0, lsl #12  ; [pp+0xb0900] TypeArguments: <_OverscrollBackground>
    //     0xfa04d4: ldr             x1, [x1, #0x900]
    // 0xfa04d8: r0 = _OverscrollBackgroundState()
    //     0xfa04d8: bl              #0xfa04f0  ; Allocate_OverscrollBackgroundStateStub -> _OverscrollBackgroundState (size=0x24)
    // 0xfa04dc: StoreField: r0->field_13 = rZR
    //     0xfa04dc: stur            xzr, [x0, #0x13]
    // 0xfa04e0: StoreField: r0->field_1b = rZR
    //     0xfa04e0: stur            xzr, [x0, #0x1b]
    // 0xfa04e4: LeaveFrame
    //     0xfa04e4: mov             SP, fp
    //     0xfa04e8: ldp             fp, lr, [SP], #0x10
    // 0xfa04ec: ret
    //     0xfa04ec: ret             
  }
}

// class id: 6521, size: 0x1c, field offset: 0xc
//   const constructor, 
class _ActionSheetButtonBackground extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa0494, size: 0x24
    // 0xfa0494: EnterFrame
    //     0xfa0494: stp             fp, lr, [SP, #-0x10]!
    //     0xfa0498: mov             fp, SP
    // 0xfa049c: mov             x0, x1
    // 0xfa04a0: r1 = <_ActionSheetButtonBackground>
    //     0xfa04a0: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4f10] TypeArguments: <_ActionSheetButtonBackground>
    //     0xfa04a4: ldr             x1, [x1, #0xf10]
    // 0xfa04a8: r0 = _ActionSheetButtonBackgroundState()
    //     0xfa04a8: bl              #0xfa04b8  ; Allocate_ActionSheetButtonBackgroundStateStub -> _ActionSheetButtonBackgroundState (size=0x14)
    // 0xfa04ac: LeaveFrame
    //     0xfa04ac: mov             SP, fp
    //     0xfa04b0: ldp             fp, lr, [SP], #0x10
    // 0xfa04b4: ret
    //     0xfa04b4: ret             
  }
}

// class id: 6522, size: 0x28, field offset: 0xc
//   const constructor, 
class CupertinoActionSheetAction extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa0454, size: 0x34
    // 0xfa0454: EnterFrame
    //     0xfa0454: stp             fp, lr, [SP, #-0x10]!
    //     0xfa0458: mov             fp, SP
    // 0xfa045c: mov             x0, x1
    // 0xfa0460: r1 = <CupertinoActionSheetAction>
    //     0xfa0460: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4730] TypeArguments: <CupertinoActionSheetAction>
    //     0xfa0464: ldr             x1, [x1, #0x730]
    // 0xfa0468: r0 = _CupertinoActionSheetActionState()
    //     0xfa0468: bl              #0xfa0488  ; Allocate_CupertinoActionSheetActionStateStub -> _CupertinoActionSheetActionState (size=0x1c)
    // 0xfa046c: r1 = false
    //     0xfa046c: add             x1, NULL, #0x30  ; false
    // 0xfa0470: StoreField: r0->field_13 = r1
    //     0xfa0470: stur            w1, [x0, #0x13]
    // 0xfa0474: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa0478: ArrayStore: r0[0] = r1  ; List_4
    //     0xfa0478: stur            w1, [x0, #0x17]
    // 0xfa047c: LeaveFrame
    //     0xfa047c: mov             SP, fp
    //     0xfa0480: ldp             fp, lr, [SP], #0x10
    // 0xfa0484: ret
    //     0xfa0484: ret             
  }
}

// class id: 6523, size: 0x20, field offset: 0xc
//   const constructor, 
class CupertinoActionSheet extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa0424, size: 0x24
    // 0xfa0424: EnterFrame
    //     0xfa0424: stp             fp, lr, [SP, #-0x10]!
    //     0xfa0428: mov             fp, SP
    // 0xfa042c: mov             x0, x1
    // 0xfa0430: r1 = <CupertinoActionSheet>
    //     0xfa0430: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd49f0] TypeArguments: <CupertinoActionSheet>
    //     0xfa0434: ldr             x1, [x1, #0x9f0]
    // 0xfa0438: r0 = _CupertinoActionSheetState()
    //     0xfa0438: bl              #0xfa0448  ; Allocate_CupertinoActionSheetStateStub -> _CupertinoActionSheetState (size=0x20)
    // 0xfa043c: LeaveFrame
    //     0xfa043c: mov             SP, fp
    //     0xfa0440: ldp             fp, lr, [SP], #0x10
    // 0xfa0444: ret
    //     0xfa0444: ret             
  }
}

// class id: 6524, size: 0x28, field offset: 0xc
//   const constructor, 
class CupertinoAlertDialog extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa03f4, size: 0x24
    // 0xfa03f4: EnterFrame
    //     0xfa03f4: stp             fp, lr, [SP, #-0x10]!
    //     0xfa03f8: mov             fp, SP
    // 0xfa03fc: mov             x0, x1
    // 0xfa0400: r1 = <CupertinoAlertDialog>
    //     0xfa0400: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa1050] TypeArguments: <CupertinoAlertDialog>
    //     0xfa0404: ldr             x1, [x1, #0x50]
    // 0xfa0408: r0 = _CupertinoAlertDialogState()
    //     0xfa0408: bl              #0xfa0418  ; Allocate_CupertinoAlertDialogStateStub -> _CupertinoAlertDialogState (size=0x20)
    // 0xfa040c: LeaveFrame
    //     0xfa040c: mov             SP, fp
    //     0xfa0410: ldp             fp, lr, [SP], #0x10
    // 0xfa0414: ret
    //     0xfa0414: ret             
  }
}

// class id: 6697, size: 0x18, field offset: 0x10
class _PriorityColumn extends MultiChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcee3c0, size: 0x88
    // 0xcee3c0: EnterFrame
    //     0xcee3c0: stp             fp, lr, [SP, #-0x10]!
    //     0xcee3c4: mov             fp, SP
    // 0xcee3c8: AllocStack(0x10)
    //     0xcee3c8: sub             SP, SP, #0x10
    // 0xcee3cc: SetupParameters(_PriorityColumn this /* r1 => r4, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xcee3cc: mov             x4, x1
    //     0xcee3d0: stur            x1, [fp, #-8]
    //     0xcee3d4: stur            x3, [fp, #-0x10]
    // 0xcee3d8: CheckStackOverflow
    //     0xcee3d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcee3dc: cmp             SP, x16
    //     0xcee3e0: b.ls            #0xcee440
    // 0xcee3e4: mov             x0, x3
    // 0xcee3e8: r2 = Null
    //     0xcee3e8: mov             x2, NULL
    // 0xcee3ec: r1 = Null
    //     0xcee3ec: mov             x1, NULL
    // 0xcee3f0: r4 = 60
    //     0xcee3f0: mov             x4, #0x3c
    // 0xcee3f4: branchIfSmi(r0, 0xcee400)
    //     0xcee3f4: tbz             w0, #0, #0xcee400
    // 0xcee3f8: r4 = LoadClassIdInstr(r0)
    //     0xcee3f8: ldur            x4, [x0, #-1]
    //     0xcee3fc: ubfx            x4, x4, #0xc, #0x14
    // 0xcee400: r17 = 4863
    //     0xcee400: mov             x17, #0x12ff
    // 0xcee404: cmp             x4, x17
    // 0xcee408: b.eq            #0xcee420
    // 0xcee40c: r8 = _RenderPriorityColumn
    //     0xcee40c: add             x8, PP, #0xb0, lsl #12  ; [pp+0xb0960] Type: _RenderPriorityColumn
    //     0xcee410: ldr             x8, [x8, #0x960]
    // 0xcee414: r3 = Null
    //     0xcee414: add             x3, PP, #0xb0, lsl #12  ; [pp+0xb0968] Null
    //     0xcee418: ldr             x3, [x3, #0x968]
    // 0xcee41c: r0 = DefaultTypeTest()
    //     0xcee41c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcee420: ldur            x0, [fp, #-8]
    // 0xcee424: LoadField: d0 = r0->field_f
    //     0xcee424: ldur            d0, [x0, #0xf]
    // 0xcee428: ldur            x1, [fp, #-0x10]
    // 0xcee42c: r0 = bottomMinHeight=()
    //     0xcee42c: bl              #0xcee448  ; [package:flutter/src/cupertino/dialog.dart] _RenderPriorityColumn::bottomMinHeight=
    // 0xcee430: r0 = Null
    //     0xcee430: mov             x0, NULL
    // 0xcee434: LeaveFrame
    //     0xcee434: mov             SP, fp
    //     0xcee438: ldp             fp, lr, [SP], #0x10
    // 0xcee43c: ret
    //     0xcee43c: ret             
    // 0xcee440: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcee440: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcee444: b               #0xcee3e4
  }
  _ _PriorityColumn(/* No info */) {
    // ** addr: 0xde3eb4, size: 0x94
    // 0xde3eb4: EnterFrame
    //     0xde3eb4: stp             fp, lr, [SP, #-0x10]!
    //     0xde3eb8: mov             fp, SP
    // 0xde3ebc: AllocStack(0x20)
    //     0xde3ebc: sub             SP, SP, #0x20
    // 0xde3ec0: r0 = 4
    //     0xde3ec0: mov             x0, #4
    // 0xde3ec4: mov             x5, x1
    // 0xde3ec8: mov             x4, x2
    // 0xde3ecc: stur            x1, [fp, #-8]
    // 0xde3ed0: stur            x2, [fp, #-0x10]
    // 0xde3ed4: stur            x3, [fp, #-0x18]
    // 0xde3ed8: StoreField: r5->field_f = d0
    //     0xde3ed8: stur            d0, [x5, #0xf]
    // 0xde3edc: mov             x2, x0
    // 0xde3ee0: r1 = Null
    //     0xde3ee0: mov             x1, NULL
    // 0xde3ee4: r0 = AllocateArray()
    //     0xde3ee4: bl              #0x13df928  ; AllocateArrayStub
    // 0xde3ee8: mov             x2, x0
    // 0xde3eec: ldur            x0, [fp, #-0x18]
    // 0xde3ef0: stur            x2, [fp, #-0x20]
    // 0xde3ef4: StoreField: r2->field_f = r0
    //     0xde3ef4: stur            w0, [x2, #0xf]
    // 0xde3ef8: ldur            x0, [fp, #-0x10]
    // 0xde3efc: StoreField: r2->field_13 = r0
    //     0xde3efc: stur            w0, [x2, #0x13]
    // 0xde3f00: r1 = <Widget>
    //     0xde3f00: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xde3f04: r0 = AllocateGrowableArray()
    //     0xde3f04: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xde3f08: ldur            x1, [fp, #-0x20]
    // 0xde3f0c: StoreField: r0->field_f = r1
    //     0xde3f0c: stur            w1, [x0, #0xf]
    // 0xde3f10: r1 = 4
    //     0xde3f10: mov             x1, #4
    // 0xde3f14: StoreField: r0->field_b = r1
    //     0xde3f14: stur            w1, [x0, #0xb]
    // 0xde3f18: ldur            x1, [fp, #-8]
    // 0xde3f1c: StoreField: r1->field_b = r0
    //     0xde3f1c: stur            w0, [x1, #0xb]
    //     0xde3f20: ldurb           w16, [x1, #-1]
    //     0xde3f24: ldurb           w17, [x0, #-1]
    //     0xde3f28: and             x16, x17, x16, lsr #2
    //     0xde3f2c: tst             x16, HEAP, lsr #32
    //     0xde3f30: b.eq            #0xde3f38
    //     0xde3f34: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xde3f38: r0 = Null
    //     0xde3f38: mov             x0, NULL
    // 0xde3f3c: LeaveFrame
    //     0xde3f3c: mov             SP, fp
    //     0xde3f40: ldp             fp, lr, [SP], #0x10
    // 0xde3f44: ret
    //     0xde3f44: ret             
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11ca0b4, size: 0x68
    // 0x11ca0b4: EnterFrame
    //     0x11ca0b4: stp             fp, lr, [SP, #-0x10]!
    //     0x11ca0b8: mov             fp, SP
    // 0x11ca0bc: AllocStack(0x10)
    //     0x11ca0bc: sub             SP, SP, #0x10
    // 0x11ca0c0: CheckStackOverflow
    //     0x11ca0c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11ca0c4: cmp             SP, x16
    //     0x11ca0c8: b.ls            #0x11ca114
    // 0x11ca0cc: LoadField: d0 = r1->field_f
    //     0x11ca0cc: ldur            d0, [x1, #0xf]
    // 0x11ca0d0: stur            d0, [fp, #-0x10]
    // 0x11ca0d4: r0 = _RenderPriorityColumn()
    //     0x11ca0d4: bl              #0x11ca11c  ; Allocate_RenderPriorityColumnStub -> _RenderPriorityColumn (size=0xa0)
    // 0x11ca0d8: ldur            d0, [fp, #-0x10]
    // 0x11ca0dc: stur            x0, [fp, #-8]
    // 0x11ca0e0: StoreField: r0->field_97 = d0
    //     0x11ca0e0: stur            d0, [x0, #0x97]
    // 0x11ca0e4: mov             x1, x0
    // 0x11ca0e8: r2 = Instance_CrossAxisAlignment
    //     0x11ca0e8: add             x2, PP, #0x7b, lsl #12  ; [pp+0x7bc40] Obj!CrossAxisAlignment@12c4521
    //     0x11ca0ec: ldr             x2, [x2, #0xc40]
    // 0x11ca0f0: r3 = Instance_Axis
    //     0x11ca0f0: ldr             x3, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0x11ca0f4: r5 = Instance_MainAxisSize
    //     0x11ca0f4: add             x5, PP, #0x17, lsl #12  ; [pp+0x17200] Obj!MainAxisSize@12c4601
    //     0x11ca0f8: ldr             x5, [x5, #0x200]
    // 0x11ca0fc: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x11ca0fc: ldr             x4, [PP, #0xff0]  ; [pp+0xff0] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x11ca100: r0 = RenderFlex()
    //     0x11ca100: bl              #0x11c9c4c  ; [package:flutter/src/rendering/flex.dart] RenderFlex::RenderFlex
    // 0x11ca104: ldur            x0, [fp, #-8]
    // 0x11ca108: LeaveFrame
    //     0x11ca108: mov             SP, fp
    //     0x11ca10c: ldp             fp, lr, [SP], #0x10
    // 0x11ca110: ret
    //     0x11ca110: ret             
    // 0x11ca114: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11ca114: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11ca118: b               #0x11ca0cc
  }
}

// class id: 6698, size: 0x18, field offset: 0x10
//   const constructor, 
class _AlertDialogActionsLayout extends MultiChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcee258, size: 0xc4
    // 0xcee258: EnterFrame
    //     0xcee258: stp             fp, lr, [SP, #-0x10]!
    //     0xcee25c: mov             fp, SP
    // 0xcee260: AllocStack(0x10)
    //     0xcee260: sub             SP, SP, #0x10
    // 0xcee264: SetupParameters(dynamic _ /* r2 => r4, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xcee264: mov             x4, x2
    //     0xcee268: stur            x2, [fp, #-8]
    //     0xcee26c: stur            x3, [fp, #-0x10]
    // 0xcee270: CheckStackOverflow
    //     0xcee270: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcee274: cmp             SP, x16
    //     0xcee278: b.ls            #0xcee314
    // 0xcee27c: mov             x0, x3
    // 0xcee280: r2 = Null
    //     0xcee280: mov             x2, NULL
    // 0xcee284: r1 = Null
    //     0xcee284: mov             x1, NULL
    // 0xcee288: r4 = 60
    //     0xcee288: mov             x4, #0x3c
    // 0xcee28c: branchIfSmi(r0, 0xcee298)
    //     0xcee28c: tbz             w0, #0, #0xcee298
    // 0xcee290: r4 = LoadClassIdInstr(r0)
    //     0xcee290: ldur            x4, [x0, #-1]
    //     0xcee294: ubfx            x4, x4, #0xc, #0x14
    // 0xcee298: r17 = 4864
    //     0xcee298: mov             x17, #0x1300
    // 0xcee29c: cmp             x4, x17
    // 0xcee2a0: b.eq            #0xcee2b8
    // 0xcee2a4: r8 = _RenderAlertDialogActionsLayout
    //     0xcee2a4: add             x8, PP, #0xcf, lsl #12  ; [pp+0xcf828] Type: _RenderAlertDialogActionsLayout
    //     0xcee2a8: ldr             x8, [x8, #0x828]
    // 0xcee2ac: r3 = Null
    //     0xcee2ac: add             x3, PP, #0xcf, lsl #12  ; [pp+0xcf830] Null
    //     0xcee2b0: ldr             x3, [x3, #0x830]
    // 0xcee2b4: r0 = DefaultTypeTest()
    //     0xcee2b4: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcee2b8: ldur            x1, [fp, #-0x10]
    // 0xcee2bc: d0 = 0.300000
    //     0xcee2bc: add             x17, PP, #0x13, lsl #12  ; [pp+0x13a88] IMM: double(0.3) from 0x3fd3333333333333
    //     0xcee2c0: ldr             d0, [x17, #0xa88]
    // 0xcee2c4: r0 = dividerThickness=()
    //     0xcee2c4: bl              #0xcee37c  ; [package:flutter/src/cupertino/dialog.dart] _RenderAlertDialogActionsLayout::dividerThickness=
    // 0xcee2c8: ldur            x1, [fp, #-8]
    // 0xcee2cc: r0 = of()
    //     0xcee2cc: bl              #0x87371c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0xcee2d0: ldur            x1, [fp, #-0x10]
    // 0xcee2d4: LoadField: r2 = r1->field_73
    //     0xcee2d4: ldur            w2, [x1, #0x73]
    // 0xcee2d8: DecompressPointer r2
    //     0xcee2d8: add             x2, x2, HEAP, lsl #32
    // 0xcee2dc: cmp             w2, w0
    // 0xcee2e0: b.eq            #0xcee304
    // 0xcee2e4: StoreField: r1->field_73 = r0
    //     0xcee2e4: stur            w0, [x1, #0x73]
    //     0xcee2e8: ldurb           w16, [x1, #-1]
    //     0xcee2ec: ldurb           w17, [x0, #-1]
    //     0xcee2f0: and             x16, x17, x16, lsr #2
    //     0xcee2f4: tst             x16, HEAP, lsr #32
    //     0xcee2f8: b.eq            #0xcee300
    //     0xcee2fc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcee300: r0 = markNeedsLayout()
    //     0xcee300: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcee304: r0 = Null
    //     0xcee304: mov             x0, NULL
    // 0xcee308: LeaveFrame
    //     0xcee308: mov             SP, fp
    //     0xcee30c: ldp             fp, lr, [SP], #0x10
    // 0xcee310: ret
    //     0xcee310: ret             
    // 0xcee314: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcee314: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcee318: b               #0xcee27c
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11c9bcc, size: 0x80
    // 0x11c9bcc: EnterFrame
    //     0x11c9bcc: stp             fp, lr, [SP, #-0x10]!
    //     0x11c9bd0: mov             fp, SP
    // 0x11c9bd4: AllocStack(0x18)
    //     0x11c9bd4: sub             SP, SP, #0x18
    // 0x11c9bd8: SetupParameters(_AlertDialogActionsLayout this /* r1 => r0 */, dynamic _ /* r2 => r1 */)
    //     0x11c9bd8: mov             x0, x1
    //     0x11c9bdc: mov             x1, x2
    // 0x11c9be0: CheckStackOverflow
    //     0x11c9be0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11c9be4: cmp             SP, x16
    //     0x11c9be8: b.ls            #0x11c9c44
    // 0x11c9bec: r0 = of()
    //     0x11c9bec: bl              #0x87371c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0x11c9bf0: stur            x0, [fp, #-8]
    // 0x11c9bf4: r0 = _RenderAlertDialogActionsLayout()
    //     0x11c9bf4: bl              #0x11ca0a8  ; Allocate_RenderAlertDialogActionsLayoutStub -> _RenderAlertDialogActionsLayout (size=0xa0)
    // 0x11c9bf8: d0 = 0.300000
    //     0x11c9bf8: add             x17, PP, #0x13, lsl #12  ; [pp+0x13a88] IMM: double(0.3) from 0x3fd3333333333333
    //     0x11c9bfc: ldr             d0, [x17, #0xa88]
    // 0x11c9c00: stur            x0, [fp, #-0x10]
    // 0x11c9c04: StoreField: r0->field_97 = d0
    //     0x11c9c04: stur            d0, [x0, #0x97]
    // 0x11c9c08: ldur            x16, [fp, #-8]
    // 0x11c9c0c: str             x16, [SP]
    // 0x11c9c10: mov             x1, x0
    // 0x11c9c14: r2 = Instance_CrossAxisAlignment
    //     0x11c9c14: add             x2, PP, #0x7b, lsl #12  ; [pp+0x7bc40] Obj!CrossAxisAlignment@12c4521
    //     0x11c9c18: ldr             x2, [x2, #0xc40]
    // 0x11c9c1c: r3 = Instance_Axis
    //     0x11c9c1c: ldr             x3, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0x11c9c20: r5 = Instance_MainAxisSize
    //     0x11c9c20: add             x5, PP, #0x17, lsl #12  ; [pp+0x17200] Obj!MainAxisSize@12c4601
    //     0x11c9c24: ldr             x5, [x5, #0x200]
    // 0x11c9c28: r4 = const [0, 0x5, 0x1, 0x4, textDirection, 0x4, null]
    //     0x11c9c28: add             x4, PP, #0xa0, lsl #12  ; [pp+0xa0cc0] List(7) [0, 0x5, 0x1, 0x4, "textDirection", 0x4, Null]
    //     0x11c9c2c: ldr             x4, [x4, #0xcc0]
    // 0x11c9c30: r0 = RenderFlex()
    //     0x11c9c30: bl              #0x11c9c4c  ; [package:flutter/src/rendering/flex.dart] RenderFlex::RenderFlex
    // 0x11c9c34: ldur            x0, [fp, #-0x10]
    // 0x11c9c38: LeaveFrame
    //     0x11c9c38: mov             SP, fp
    //     0x11c9c3c: ldp             fp, lr, [SP], #0x10
    // 0x11c9c40: ret
    //     0x11c9c40: ret             
    // 0x11c9c44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11c9c44: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11c9c48: b               #0x11c9bec
  }
}
