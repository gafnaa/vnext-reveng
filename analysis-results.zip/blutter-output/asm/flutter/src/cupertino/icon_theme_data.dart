// lib: , url: package:flutter/src/cupertino/icon_theme_data.dart

// class id: 1048779, size: 0x8
class :: {
}

// class id: 5303, size: 0x2c, field offset: 0x2c
//   const constructor, 
class CupertinoIconThemeData extends _MixinApplication392&IconThemeData&Diagnosticable {

  IconThemeData resolve(CupertinoIconThemeData, BuildContext) {
    // ** addr: 0xd0e400, size: 0x8c
    // 0xd0e400: EnterFrame
    //     0xd0e400: stp             fp, lr, [SP, #-0x10]!
    //     0xd0e404: mov             fp, SP
    // 0xd0e408: CheckStackOverflow
    //     0xd0e408: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0e40c: cmp             SP, x16
    //     0xd0e410: b.ls            #0xd0e46c
    // 0xd0e414: ldr             x0, [fp, #0x10]
    // 0xd0e418: r2 = Null
    //     0xd0e418: mov             x2, NULL
    // 0xd0e41c: r1 = Null
    //     0xd0e41c: mov             x1, NULL
    // 0xd0e420: r4 = 60
    //     0xd0e420: mov             x4, #0x3c
    // 0xd0e424: branchIfSmi(r0, 0xd0e430)
    //     0xd0e424: tbz             w0, #0, #0xd0e430
    // 0xd0e428: r4 = LoadClassIdInstr(r0)
    //     0xd0e428: ldur            x4, [x0, #-1]
    //     0xd0e42c: ubfx            x4, x4, #0xc, #0x14
    // 0xd0e430: r17 = -5795
    //     0xd0e430: mov             x17, #-0x16a3
    // 0xd0e434: add             x4, x4, x17
    // 0xd0e438: cmp             x4, #0x30
    // 0xd0e43c: b.ls            #0xd0e454
    // 0xd0e440: r8 = BuildContext
    //     0xd0e440: add             x8, PP, #0x12, lsl #12  ; [pp+0x12868] Type: BuildContext
    //     0xd0e444: ldr             x8, [x8, #0x868]
    // 0xd0e448: r3 = Null
    //     0xd0e448: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8c440] Null
    //     0xd0e44c: ldr             x3, [x3, #0x440]
    // 0xd0e450: r0 = DefaultTypeTest()
    //     0xd0e450: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xd0e454: ldr             x1, [fp, #0x18]
    // 0xd0e458: ldr             x2, [fp, #0x10]
    // 0xd0e45c: r0 = resolve()
    //     0xd0e45c: bl              #0x125c268  ; [package:flutter/src/cupertino/icon_theme_data.dart] CupertinoIconThemeData::resolve
    // 0xd0e460: LeaveFrame
    //     0xd0e460: mov             SP, fp
    //     0xd0e464: ldp             fp, lr, [SP], #0x10
    // 0xd0e468: ret
    //     0xd0e468: ret             
    // 0xd0e46c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0e46c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0e470: b               #0xd0e414
  }
  IconThemeData resolve(CupertinoIconThemeData, BuildContext) {
    // ** addr: 0x125c268, size: 0x90
    // 0x125c268: EnterFrame
    //     0x125c268: stp             fp, lr, [SP, #-0x10]!
    //     0x125c26c: mov             fp, SP
    // 0x125c270: AllocStack(0x28)
    //     0x125c270: sub             SP, SP, #0x28
    // 0x125c274: SetupParameters(CupertinoIconThemeData this /* r1 => r0, fp-0x10 */)
    //     0x125c274: mov             x0, x1
    //     0x125c278: stur            x1, [fp, #-0x10]
    // 0x125c27c: CheckStackOverflow
    //     0x125c27c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x125c280: cmp             SP, x16
    //     0x125c284: b.ls            #0x125c2f0
    // 0x125c288: LoadField: r3 = r0->field_1b
    //     0x125c288: ldur            w3, [x0, #0x1b]
    // 0x125c28c: DecompressPointer r3
    //     0x125c28c: add             x3, x3, HEAP, lsl #32
    // 0x125c290: mov             x1, x3
    // 0x125c294: stur            x3, [fp, #-8]
    // 0x125c298: r0 = resolve()
    //     0x125c298: bl              #0xce150c  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolve
    // 0x125c29c: mov             x1, x0
    // 0x125c2a0: stur            x1, [fp, #-0x18]
    // 0x125c2a4: r0 = LoadClassIdInstr(r1)
    //     0x125c2a4: ldur            x0, [x1, #-1]
    //     0x125c2a8: ubfx            x0, x0, #0xc, #0x14
    // 0x125c2ac: ldur            x16, [fp, #-8]
    // 0x125c2b0: stp             x16, x1, [SP]
    // 0x125c2b4: mov             lr, x0
    // 0x125c2b8: ldr             lr, [x21, lr, lsl #3]
    // 0x125c2bc: blr             lr
    // 0x125c2c0: tbnz            w0, #4, #0x125c2cc
    // 0x125c2c4: ldur            x0, [fp, #-0x10]
    // 0x125c2c8: b               #0x125c2e4
    // 0x125c2cc: ldur            x16, [fp, #-0x18]
    // 0x125c2d0: str             x16, [SP]
    // 0x125c2d4: ldur            x1, [fp, #-0x10]
    // 0x125c2d8: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0x125c2d8: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0x125c2dc: ldr             x4, [x4, #0x7f0]
    // 0x125c2e0: r0 = copyWith()
    //     0x125c2e0: bl              #0x12ab1f4  ; [package:flutter/src/cupertino/icon_theme_data.dart] CupertinoIconThemeData::copyWith
    // 0x125c2e4: LeaveFrame
    //     0x125c2e4: mov             SP, fp
    //     0x125c2e8: ldp             fp, lr, [SP], #0x10
    // 0x125c2ec: ret
    //     0x125c2ec: ret             
    // 0x125c2f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x125c2f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x125c2f4: b               #0x125c288
  }
  _ copyWith(/* No info */) {
    // ** addr: 0x12ab1f4, size: 0x430
    // 0x12ab1f4: EnterFrame
    //     0x12ab1f4: stp             fp, lr, [SP, #-0x10]!
    //     0x12ab1f8: mov             fp, SP
    // 0x12ab1fc: AllocStack(0x48)
    //     0x12ab1fc: sub             SP, SP, #0x48
    // 0x12ab200: SetupParameters(CupertinoIconThemeData this /* r1 => r0, fp-0x40 */, {dynamic applyTextScaling = Null /* r3, fp-0x38 */, dynamic color = Null /* r5 */, dynamic fill = Null /* r6 */, dynamic grade = Null /* r7 */, dynamic opacity = Null /* r8 */, dynamic opticalSize = Null /* r9 */, dynamic size = Null /* r10 */, dynamic weight = Null /* r1 */})
    //     0x12ab200: mov             x0, x1
    //     0x12ab204: stur            x1, [fp, #-0x40]
    //     0x12ab208: ldur            w1, [x4, #0x13]
    //     0x12ab20c: ldur            w2, [x4, #0x1f]
    //     0x12ab210: add             x2, x2, HEAP, lsl #32
    //     0x12ab214: add             x16, PP, #0x80, lsl #12  ; [pp+0x80c38] "applyTextScaling"
    //     0x12ab218: ldr             x16, [x16, #0xc38]
    //     0x12ab21c: cmp             w2, w16
    //     0x12ab220: b.ne            #0x12ab244
    //     0x12ab224: ldur            w2, [x4, #0x23]
    //     0x12ab228: add             x2, x2, HEAP, lsl #32
    //     0x12ab22c: sub             w3, w1, w2
    //     0x12ab230: add             x2, fp, w3, sxtw #2
    //     0x12ab234: ldr             x2, [x2, #8]
    //     0x12ab238: mov             x3, x2
    //     0x12ab23c: mov             x2, #1
    //     0x12ab240: b               #0x12ab24c
    //     0x12ab244: mov             x3, NULL
    //     0x12ab248: mov             x2, #0
    //     0x12ab24c: stur            x3, [fp, #-0x38]
    //     0x12ab250: lsl             x5, x2, #1
    //     0x12ab254: lsl             w6, w5, #1
    //     0x12ab258: add             w7, w6, #8
    //     0x12ab25c: add             x16, x4, w7, sxtw #1
    //     0x12ab260: ldur            w8, [x16, #0xf]
    //     0x12ab264: add             x8, x8, HEAP, lsl #32
    //     0x12ab268: ldr             x16, [PP, #0x4a70]  ; [pp+0x4a70] "color"
    //     0x12ab26c: cmp             w8, w16
    //     0x12ab270: b.ne            #0x12ab2a4
    //     0x12ab274: add             w2, w6, #0xa
    //     0x12ab278: add             x16, x4, w2, sxtw #1
    //     0x12ab27c: ldur            w6, [x16, #0xf]
    //     0x12ab280: add             x6, x6, HEAP, lsl #32
    //     0x12ab284: sub             w2, w1, w6
    //     0x12ab288: add             x6, fp, w2, sxtw #2
    //     0x12ab28c: ldr             x6, [x6, #8]
    //     0x12ab290: add             w2, w5, #2
    //     0x12ab294: sbfx            x5, x2, #1, #0x1f
    //     0x12ab298: mov             x2, x5
    //     0x12ab29c: mov             x5, x6
    //     0x12ab2a0: b               #0x12ab2a8
    //     0x12ab2a4: mov             x5, NULL
    //     0x12ab2a8: lsl             x6, x2, #1
    //     0x12ab2ac: lsl             w7, w6, #1
    //     0x12ab2b0: add             w8, w7, #8
    //     0x12ab2b4: add             x16, x4, w8, sxtw #1
    //     0x12ab2b8: ldur            w9, [x16, #0xf]
    //     0x12ab2bc: add             x9, x9, HEAP, lsl #32
    //     0x12ab2c0: add             x16, PP, #0x80, lsl #12  ; [pp+0x80c40] "fill"
    //     0x12ab2c4: ldr             x16, [x16, #0xc40]
    //     0x12ab2c8: cmp             w9, w16
    //     0x12ab2cc: b.ne            #0x12ab300
    //     0x12ab2d0: add             w2, w7, #0xa
    //     0x12ab2d4: add             x16, x4, w2, sxtw #1
    //     0x12ab2d8: ldur            w7, [x16, #0xf]
    //     0x12ab2dc: add             x7, x7, HEAP, lsl #32
    //     0x12ab2e0: sub             w2, w1, w7
    //     0x12ab2e4: add             x7, fp, w2, sxtw #2
    //     0x12ab2e8: ldr             x7, [x7, #8]
    //     0x12ab2ec: add             w2, w6, #2
    //     0x12ab2f0: sbfx            x6, x2, #1, #0x1f
    //     0x12ab2f4: mov             x2, x6
    //     0x12ab2f8: mov             x6, x7
    //     0x12ab2fc: b               #0x12ab304
    //     0x12ab300: mov             x6, NULL
    //     0x12ab304: lsl             x7, x2, #1
    //     0x12ab308: lsl             w8, w7, #1
    //     0x12ab30c: add             w9, w8, #8
    //     0x12ab310: add             x16, x4, w9, sxtw #1
    //     0x12ab314: ldur            w10, [x16, #0xf]
    //     0x12ab318: add             x10, x10, HEAP, lsl #32
    //     0x12ab31c: add             x16, PP, #0x22, lsl #12  ; [pp+0x22d88] "grade"
    //     0x12ab320: ldr             x16, [x16, #0xd88]
    //     0x12ab324: cmp             w10, w16
    //     0x12ab328: b.ne            #0x12ab35c
    //     0x12ab32c: add             w2, w8, #0xa
    //     0x12ab330: add             x16, x4, w2, sxtw #1
    //     0x12ab334: ldur            w8, [x16, #0xf]
    //     0x12ab338: add             x8, x8, HEAP, lsl #32
    //     0x12ab33c: sub             w2, w1, w8
    //     0x12ab340: add             x8, fp, w2, sxtw #2
    //     0x12ab344: ldr             x8, [x8, #8]
    //     0x12ab348: add             w2, w7, #2
    //     0x12ab34c: sbfx            x7, x2, #1, #0x1f
    //     0x12ab350: mov             x2, x7
    //     0x12ab354: mov             x7, x8
    //     0x12ab358: b               #0x12ab360
    //     0x12ab35c: mov             x7, NULL
    //     0x12ab360: lsl             x8, x2, #1
    //     0x12ab364: lsl             w9, w8, #1
    //     0x12ab368: add             w10, w9, #8
    //     0x12ab36c: add             x16, x4, w10, sxtw #1
    //     0x12ab370: ldur            w11, [x16, #0xf]
    //     0x12ab374: add             x11, x11, HEAP, lsl #32
    //     0x12ab378: add             x16, PP, #0x80, lsl #12  ; [pp+0x80c48] "opacity"
    //     0x12ab37c: ldr             x16, [x16, #0xc48]
    //     0x12ab380: cmp             w11, w16
    //     0x12ab384: b.ne            #0x12ab3b8
    //     0x12ab388: add             w2, w9, #0xa
    //     0x12ab38c: add             x16, x4, w2, sxtw #1
    //     0x12ab390: ldur            w9, [x16, #0xf]
    //     0x12ab394: add             x9, x9, HEAP, lsl #32
    //     0x12ab398: sub             w2, w1, w9
    //     0x12ab39c: add             x9, fp, w2, sxtw #2
    //     0x12ab3a0: ldr             x9, [x9, #8]
    //     0x12ab3a4: add             w2, w8, #2
    //     0x12ab3a8: sbfx            x8, x2, #1, #0x1f
    //     0x12ab3ac: mov             x2, x8
    //     0x12ab3b0: mov             x8, x9
    //     0x12ab3b4: b               #0x12ab3bc
    //     0x12ab3b8: mov             x8, NULL
    //     0x12ab3bc: lsl             x9, x2, #1
    //     0x12ab3c0: lsl             w10, w9, #1
    //     0x12ab3c4: add             w11, w10, #8
    //     0x12ab3c8: add             x16, x4, w11, sxtw #1
    //     0x12ab3cc: ldur            w12, [x16, #0xf]
    //     0x12ab3d0: add             x12, x12, HEAP, lsl #32
    //     0x12ab3d4: add             x16, PP, #0x80, lsl #12  ; [pp+0x80c50] "opticalSize"
    //     0x12ab3d8: ldr             x16, [x16, #0xc50]
    //     0x12ab3dc: cmp             w12, w16
    //     0x12ab3e0: b.ne            #0x12ab414
    //     0x12ab3e4: add             w2, w10, #0xa
    //     0x12ab3e8: add             x16, x4, w2, sxtw #1
    //     0x12ab3ec: ldur            w10, [x16, #0xf]
    //     0x12ab3f0: add             x10, x10, HEAP, lsl #32
    //     0x12ab3f4: sub             w2, w1, w10
    //     0x12ab3f8: add             x10, fp, w2, sxtw #2
    //     0x12ab3fc: ldr             x10, [x10, #8]
    //     0x12ab400: add             w2, w9, #2
    //     0x12ab404: sbfx            x9, x2, #1, #0x1f
    //     0x12ab408: mov             x2, x9
    //     0x12ab40c: mov             x9, x10
    //     0x12ab410: b               #0x12ab418
    //     0x12ab414: mov             x9, NULL
    //     0x12ab418: lsl             x10, x2, #1
    //     0x12ab41c: lsl             w11, w10, #1
    //     0x12ab420: add             w12, w11, #8
    //     0x12ab424: add             x16, x4, w12, sxtw #1
    //     0x12ab428: ldur            w13, [x16, #0xf]
    //     0x12ab42c: add             x13, x13, HEAP, lsl #32
    //     0x12ab430: add             x16, PP, #0x22, lsl #12  ; [pp+0x22310] "size"
    //     0x12ab434: ldr             x16, [x16, #0x310]
    //     0x12ab438: cmp             w13, w16
    //     0x12ab43c: b.ne            #0x12ab470
    //     0x12ab440: add             w2, w11, #0xa
    //     0x12ab444: add             x16, x4, w2, sxtw #1
    //     0x12ab448: ldur            w11, [x16, #0xf]
    //     0x12ab44c: add             x11, x11, HEAP, lsl #32
    //     0x12ab450: sub             w2, w1, w11
    //     0x12ab454: add             x11, fp, w2, sxtw #2
    //     0x12ab458: ldr             x11, [x11, #8]
    //     0x12ab45c: add             w2, w10, #2
    //     0x12ab460: sbfx            x10, x2, #1, #0x1f
    //     0x12ab464: mov             x2, x10
    //     0x12ab468: mov             x10, x11
    //     0x12ab46c: b               #0x12ab474
    //     0x12ab470: mov             x10, NULL
    //     0x12ab474: lsl             x11, x2, #1
    //     0x12ab478: lsl             w2, w11, #1
    //     0x12ab47c: add             w11, w2, #8
    //     0x12ab480: add             x16, x4, w11, sxtw #1
    //     0x12ab484: ldur            w12, [x16, #0xf]
    //     0x12ab488: add             x12, x12, HEAP, lsl #32
    //     0x12ab48c: add             x16, PP, #0x22, lsl #12  ; [pp+0x22d98] "weight"
    //     0x12ab490: ldr             x16, [x16, #0xd98]
    //     0x12ab494: cmp             w12, w16
    //     0x12ab498: b.ne            #0x12ab4bc
    //     0x12ab49c: add             w11, w2, #0xa
    //     0x12ab4a0: add             x16, x4, w11, sxtw #1
    //     0x12ab4a4: ldur            w2, [x16, #0xf]
    //     0x12ab4a8: add             x2, x2, HEAP, lsl #32
    //     0x12ab4ac: sub             w4, w1, w2
    //     0x12ab4b0: add             x1, fp, w4, sxtw #2
    //     0x12ab4b4: ldr             x1, [x1, #8]
    //     0x12ab4b8: b               #0x12ab4c0
    //     0x12ab4bc: mov             x1, NULL
    // 0x12ab4c0: CheckStackOverflow
    //     0x12ab4c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12ab4c4: cmp             SP, x16
    //     0x12ab4c8: b.ls            #0x12ab61c
    // 0x12ab4cc: cmp             w10, NULL
    // 0x12ab4d0: b.ne            #0x12ab4e0
    // 0x12ab4d4: LoadField: r2 = r0->field_7
    //     0x12ab4d4: ldur            w2, [x0, #7]
    // 0x12ab4d8: DecompressPointer r2
    //     0x12ab4d8: add             x2, x2, HEAP, lsl #32
    // 0x12ab4dc: b               #0x12ab4e4
    // 0x12ab4e0: mov             x2, x10
    // 0x12ab4e4: stur            x2, [fp, #-0x30]
    // 0x12ab4e8: cmp             w6, NULL
    // 0x12ab4ec: b.ne            #0x12ab4fc
    // 0x12ab4f0: LoadField: r4 = r0->field_b
    //     0x12ab4f0: ldur            w4, [x0, #0xb]
    // 0x12ab4f4: DecompressPointer r4
    //     0x12ab4f4: add             x4, x4, HEAP, lsl #32
    // 0x12ab4f8: b               #0x12ab500
    // 0x12ab4fc: mov             x4, x6
    // 0x12ab500: stur            x4, [fp, #-0x28]
    // 0x12ab504: cmp             w1, NULL
    // 0x12ab508: b.ne            #0x12ab51c
    // 0x12ab50c: LoadField: r1 = r0->field_f
    //     0x12ab50c: ldur            w1, [x0, #0xf]
    // 0x12ab510: DecompressPointer r1
    //     0x12ab510: add             x1, x1, HEAP, lsl #32
    // 0x12ab514: mov             x6, x1
    // 0x12ab518: b               #0x12ab520
    // 0x12ab51c: mov             x6, x1
    // 0x12ab520: stur            x6, [fp, #-0x20]
    // 0x12ab524: cmp             w7, NULL
    // 0x12ab528: b.ne            #0x12ab538
    // 0x12ab52c: LoadField: r1 = r0->field_13
    //     0x12ab52c: ldur            w1, [x0, #0x13]
    // 0x12ab530: DecompressPointer r1
    //     0x12ab530: add             x1, x1, HEAP, lsl #32
    // 0x12ab534: mov             x7, x1
    // 0x12ab538: stur            x7, [fp, #-0x18]
    // 0x12ab53c: cmp             w9, NULL
    // 0x12ab540: b.ne            #0x12ab550
    // 0x12ab544: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x12ab544: ldur            w1, [x0, #0x17]
    // 0x12ab548: DecompressPointer r1
    //     0x12ab548: add             x1, x1, HEAP, lsl #32
    // 0x12ab54c: mov             x9, x1
    // 0x12ab550: stur            x9, [fp, #-0x10]
    // 0x12ab554: cmp             w5, NULL
    // 0x12ab558: b.ne            #0x12ab568
    // 0x12ab55c: LoadField: r1 = r0->field_1b
    //     0x12ab55c: ldur            w1, [x0, #0x1b]
    // 0x12ab560: DecompressPointer r1
    //     0x12ab560: add             x1, x1, HEAP, lsl #32
    // 0x12ab564: mov             x5, x1
    // 0x12ab568: stur            x5, [fp, #-8]
    // 0x12ab56c: cmp             w8, NULL
    // 0x12ab570: b.ne            #0x12ab584
    // 0x12ab574: mov             x1, x0
    // 0x12ab578: r0 = opacity()
    //     0x12ab578: bl              #0xd0c778  ; [package:flutter/src/widgets/icon_theme_data.dart] IconThemeData::opacity
    // 0x12ab57c: mov             x1, x0
    // 0x12ab580: b               #0x12ab588
    // 0x12ab584: mov             x1, x8
    // 0x12ab588: ldur            x0, [fp, #-0x38]
    // 0x12ab58c: stur            x1, [fp, #-0x48]
    // 0x12ab590: cmp             w0, NULL
    // 0x12ab594: b.ne            #0x12ab5ac
    // 0x12ab598: ldur            x0, [fp, #-0x40]
    // 0x12ab59c: LoadField: r2 = r0->field_27
    //     0x12ab59c: ldur            w2, [x0, #0x27]
    // 0x12ab5a0: DecompressPointer r2
    //     0x12ab5a0: add             x2, x2, HEAP, lsl #32
    // 0x12ab5a4: mov             x7, x2
    // 0x12ab5a8: b               #0x12ab5b0
    // 0x12ab5ac: mov             x7, x0
    // 0x12ab5b0: ldur            x0, [fp, #-0x30]
    // 0x12ab5b4: ldur            x2, [fp, #-0x28]
    // 0x12ab5b8: ldur            x3, [fp, #-0x20]
    // 0x12ab5bc: ldur            x4, [fp, #-0x18]
    // 0x12ab5c0: ldur            x5, [fp, #-0x10]
    // 0x12ab5c4: ldur            x6, [fp, #-8]
    // 0x12ab5c8: stur            x7, [fp, #-0x38]
    // 0x12ab5cc: r0 = CupertinoIconThemeData()
    //     0x12ab5cc: bl              #0xfaddc8  ; AllocateCupertinoIconThemeDataStub -> CupertinoIconThemeData (size=0x2c)
    // 0x12ab5d0: ldur            x1, [fp, #-0x30]
    // 0x12ab5d4: StoreField: r0->field_7 = r1
    //     0x12ab5d4: stur            w1, [x0, #7]
    // 0x12ab5d8: ldur            x1, [fp, #-0x28]
    // 0x12ab5dc: StoreField: r0->field_b = r1
    //     0x12ab5dc: stur            w1, [x0, #0xb]
    // 0x12ab5e0: ldur            x1, [fp, #-0x20]
    // 0x12ab5e4: StoreField: r0->field_f = r1
    //     0x12ab5e4: stur            w1, [x0, #0xf]
    // 0x12ab5e8: ldur            x1, [fp, #-0x18]
    // 0x12ab5ec: StoreField: r0->field_13 = r1
    //     0x12ab5ec: stur            w1, [x0, #0x13]
    // 0x12ab5f0: ldur            x1, [fp, #-0x10]
    // 0x12ab5f4: ArrayStore: r0[0] = r1  ; List_4
    //     0x12ab5f4: stur            w1, [x0, #0x17]
    // 0x12ab5f8: ldur            x1, [fp, #-8]
    // 0x12ab5fc: StoreField: r0->field_1b = r1
    //     0x12ab5fc: stur            w1, [x0, #0x1b]
    // 0x12ab600: ldur            x1, [fp, #-0x38]
    // 0x12ab604: StoreField: r0->field_27 = r1
    //     0x12ab604: stur            w1, [x0, #0x27]
    // 0x12ab608: ldur            x1, [fp, #-0x48]
    // 0x12ab60c: StoreField: r0->field_1f = r1
    //     0x12ab60c: stur            w1, [x0, #0x1f]
    // 0x12ab610: LeaveFrame
    //     0x12ab610: mov             SP, fp
    //     0x12ab614: ldp             fp, lr, [SP], #0x10
    // 0x12ab618: ret
    //     0x12ab618: ret             
    // 0x12ab61c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12ab61c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12ab620: b               #0x12ab4cc
  }
}
