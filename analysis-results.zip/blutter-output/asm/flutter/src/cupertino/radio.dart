// lib: , url: package:flutter/src/cupertino/radio.dart

// class id: 1048782, size: 0x8
class :: {

  static late final Color _kDisabledOuterColor; // offset: 0xce8

  static Color _kDisabledOuterColor() {
    // ** addr: 0xb6b2cc, size: 0x38
    // 0xb6b2cc: EnterFrame
    //     0xb6b2cc: stp             fp, lr, [SP, #-0x10]!
    //     0xb6b2d0: mov             fp, SP
    // 0xb6b2d4: CheckStackOverflow
    //     0xb6b2d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb6b2d8: cmp             SP, x16
    //     0xb6b2dc: b.ls            #0xb6b2fc
    // 0xb6b2e0: r1 = Instance_Color
    //     0xb6b2e0: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0xb6b2e4: ldr             x1, [x1, #0xc38]
    // 0xb6b2e8: d0 = 0.500000
    //     0xb6b2e8: fmov            d0, #0.50000000
    // 0xb6b2ec: r0 = withOpacity()
    //     0xb6b2ec: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xb6b2f0: LeaveFrame
    //     0xb6b2f0: mov             SP, fp
    //     0xb6b2f4: ldp             fp, lr, [SP], #0x10
    // 0xb6b2f8: ret
    //     0xb6b2f8: ret             
    // 0xb6b2fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb6b2fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb6b300: b               #0xb6b2e0
  }
}

// class id: 4515, size: 0x74, field offset: 0x60
class _RadioPainter extends ToggleablePainter {

  _ paint(/* No info */) {
    // ** addr: 0xb6a5a8, size: 0x478
    // 0xb6a5a8: EnterFrame
    //     0xb6a5a8: stp             fp, lr, [SP, #-0x10]!
    //     0xb6a5ac: mov             fp, SP
    // 0xb6a5b0: AllocStack(0x40)
    //     0xb6a5b0: sub             SP, SP, #0x40
    // 0xb6a5b4: SetupParameters(_RadioPainter this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r2 */)
    //     0xb6a5b4: mov             x0, x2
    //     0xb6a5b8: stur            x2, [fp, #-0x10]
    //     0xb6a5bc: mov             x2, x3
    //     0xb6a5c0: mov             x3, x1
    //     0xb6a5c4: stur            x1, [fp, #-8]
    // 0xb6a5c8: CheckStackOverflow
    //     0xb6a5c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb6a5cc: cmp             SP, x16
    //     0xb6a5d0: b.ls            #0xb6a9e8
    // 0xb6a5d4: r1 = Instance_Offset
    //     0xb6a5d4: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xb6a5d8: r0 = &()
    //     0xb6a5d8: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xb6a5dc: mov             x1, x0
    // 0xb6a5e0: r0 = center()
    //     0xb6a5e0: bl              #0x869350  ; [dart:ui] Rect::center
    // 0xb6a5e4: ldur            x1, [fp, #-8]
    // 0xb6a5e8: stur            x0, [fp, #-0x18]
    // 0xb6a5ec: LoadField: r2 = r1->field_5f
    //     0xb6a5ec: ldur            w2, [x1, #0x5f]
    // 0xb6a5f0: DecompressPointer r2
    //     0xb6a5f0: add             x2, x2, HEAP, lsl #32
    // 0xb6a5f4: cmp             w2, NULL
    // 0xb6a5f8: b.eq            #0xb6a7c8
    // 0xb6a5fc: tbnz            w2, #4, #0xb6a7c4
    // 0xb6a600: r16 = 136
    //     0xb6a600: mov             x16, #0x88
    // 0xb6a604: stp             x16, NULL, [SP]
    // 0xb6a608: r0 = ByteData()
    //     0xb6a608: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xb6a60c: stur            x0, [fp, #-0x20]
    // 0xb6a610: r0 = Paint()
    //     0xb6a610: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xb6a614: mov             x3, x0
    // 0xb6a618: ldur            x0, [fp, #-0x20]
    // 0xb6a61c: stur            x3, [fp, #-0x28]
    // 0xb6a620: StoreField: r3->field_7 = r0
    //     0xb6a620: stur            w0, [x3, #7]
    // 0xb6a624: ldur            x0, [fp, #-8]
    // 0xb6a628: LoadField: r2 = r0->field_33
    //     0xb6a628: ldur            w2, [x0, #0x33]
    // 0xb6a62c: DecompressPointer r2
    //     0xb6a62c: add             x2, x2, HEAP, lsl #32
    // 0xb6a630: cmp             w2, NULL
    // 0xb6a634: b.eq            #0xb6a9f0
    // 0xb6a638: mov             x1, x3
    // 0xb6a63c: r0 = color=()
    //     0xb6a63c: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xb6a640: ldur            x0, [fp, #-8]
    // 0xb6a644: LoadField: r1 = r0->field_6b
    //     0xb6a644: ldur            w1, [x0, #0x6b]
    // 0xb6a648: DecompressPointer r1
    //     0xb6a648: add             x1, x1, HEAP, lsl #32
    // 0xb6a64c: r16 = Instance_Brightness
    //     0xb6a64c: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0xb6a650: cmp             w1, w16
    // 0xb6a654: b.ne            #0xb6a704
    // 0xb6a658: LoadField: r1 = r0->field_5b
    //     0xb6a658: ldur            w1, [x0, #0x5b]
    // 0xb6a65c: DecompressPointer r1
    //     0xb6a65c: add             x1, x1, HEAP, lsl #32
    // 0xb6a660: cmp             w1, NULL
    // 0xb6a664: b.eq            #0xb6a9f4
    // 0xb6a668: tbz             w1, #4, #0xb6a704
    // 0xb6a66c: ldur            x1, [fp, #-0x28]
    // 0xb6a670: r0 = color()
    //     0xb6a670: bl              #0xb6a1dc  ; [dart:ui] Paint::color
    // 0xb6a674: mov             x1, x0
    // 0xb6a678: ldur            x0, [fp, #-8]
    // 0xb6a67c: LoadField: r2 = r0->field_5b
    //     0xb6a67c: ldur            w2, [x0, #0x5b]
    // 0xb6a680: DecompressPointer r2
    //     0xb6a680: add             x2, x2, HEAP, lsl #32
    // 0xb6a684: cmp             w2, NULL
    // 0xb6a688: b.eq            #0xb6a9f8
    // 0xb6a68c: tbnz            w2, #4, #0xb6a69c
    // 0xb6a690: d0 = 0.140000
    //     0xb6a690: add             x17, PP, #0xa2, lsl #12  ; [pp+0xa2ae8] IMM: double(0.14) from 0x3fc1eb851eb851ec
    //     0xb6a694: ldr             d0, [x17, #0xae8]
    // 0xb6a698: b               #0xb6a6a4
    // 0xb6a69c: d0 = 0.080000
    //     0xb6a69c: add             x17, PP, #0x15, lsl #12  ; [pp+0x15a58] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0xb6a6a0: ldr             d0, [x17, #0xa58]
    // 0xb6a6a4: r0 = withOpacity()
    //     0xb6a6a4: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xb6a6a8: ldur            x1, [fp, #-0x28]
    // 0xb6a6ac: stur            x0, [fp, #-0x20]
    // 0xb6a6b0: r0 = color()
    //     0xb6a6b0: bl              #0xb6a1dc  ; [dart:ui] Paint::color
    // 0xb6a6b4: mov             x1, x0
    // 0xb6a6b8: ldur            x0, [fp, #-8]
    // 0xb6a6bc: LoadField: r2 = r0->field_5b
    //     0xb6a6bc: ldur            w2, [x0, #0x5b]
    // 0xb6a6c0: DecompressPointer r2
    //     0xb6a6c0: add             x2, x2, HEAP, lsl #32
    // 0xb6a6c4: cmp             w2, NULL
    // 0xb6a6c8: b.eq            #0xb6a9fc
    // 0xb6a6cc: tbnz            w2, #4, #0xb6a6dc
    // 0xb6a6d0: d0 = 0.290000
    //     0xb6a6d0: add             x17, PP, #0x13, lsl #12  ; [pp+0x131a8] IMM: double(0.29) from 0x3fd28f5c28f5c28f
    //     0xb6a6d4: ldr             d0, [x17, #0x1a8]
    // 0xb6a6d8: b               #0xb6a6e4
    // 0xb6a6dc: d0 = 0.140000
    //     0xb6a6dc: add             x17, PP, #0xa2, lsl #12  ; [pp+0xa2ae8] IMM: double(0.14) from 0x3fc1eb851eb851ec
    //     0xb6a6e0: ldr             d0, [x17, #0xae8]
    // 0xb6a6e4: r0 = withOpacity()
    //     0xb6a6e4: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xb6a6e8: ldur            x1, [fp, #-8]
    // 0xb6a6ec: ldur            x2, [fp, #-0x10]
    // 0xb6a6f0: ldur            x3, [fp, #-0x18]
    // 0xb6a6f4: ldur            x5, [fp, #-0x20]
    // 0xb6a6f8: mov             x6, x0
    // 0xb6a6fc: r0 = _drawFillGradient()
    //     0xb6a6fc: bl              #0xb6af74  ; [package:flutter/src/cupertino/radio.dart] _RadioPainter::_drawFillGradient
    // 0xb6a700: b               #0xb6a718
    // 0xb6a704: ldur            x1, [fp, #-0x10]
    // 0xb6a708: ldur            x2, [fp, #-0x18]
    // 0xb6a70c: ldur            x3, [fp, #-0x28]
    // 0xb6a710: d0 = 7.000000
    //     0xb6a710: fmov            d0, #7.00000000
    // 0xb6a714: r0 = drawCircle()
    //     0xb6a714: bl              #0xb6acd4  ; [dart:ui] _NativeCanvas::drawCircle
    // 0xb6a718: ldur            x0, [fp, #-8]
    // 0xb6a71c: LoadField: r1 = r0->field_4f
    //     0xb6a71c: ldur            w1, [x0, #0x4f]
    // 0xb6a720: DecompressPointer r1
    //     0xb6a720: add             x1, x1, HEAP, lsl #32
    // 0xb6a724: cmp             w1, NULL
    // 0xb6a728: b.eq            #0xb6a73c
    // 0xb6a72c: mov             x1, x0
    // 0xb6a730: ldur            x2, [fp, #-0x10]
    // 0xb6a734: ldur            x3, [fp, #-0x18]
    // 0xb6a738: r0 = _drawPressedOverlay()
    //     0xb6a738: bl              #0xb6ac00  ; [package:flutter/src/cupertino/radio.dart] _RadioPainter::_drawPressedOverlay
    // 0xb6a73c: ldur            x1, [fp, #-8]
    // 0xb6a740: r16 = 136
    //     0xb6a740: mov             x16, #0x88
    // 0xb6a744: stp             x16, NULL, [SP]
    // 0xb6a748: r0 = ByteData()
    //     0xb6a748: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xb6a74c: stur            x0, [fp, #-0x20]
    // 0xb6a750: r0 = Paint()
    //     0xb6a750: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xb6a754: mov             x3, x0
    // 0xb6a758: ldur            x0, [fp, #-0x20]
    // 0xb6a75c: stur            x3, [fp, #-0x28]
    // 0xb6a760: StoreField: r3->field_7 = r0
    //     0xb6a760: stur            w0, [x3, #7]
    // 0xb6a764: ldur            x0, [fp, #-8]
    // 0xb6a768: LoadField: r2 = r0->field_63
    //     0xb6a768: ldur            w2, [x0, #0x63]
    // 0xb6a76c: DecompressPointer r2
    //     0xb6a76c: add             x2, x2, HEAP, lsl #32
    // 0xb6a770: cmp             w2, NULL
    // 0xb6a774: b.eq            #0xb6aa00
    // 0xb6a778: mov             x1, x3
    // 0xb6a77c: r0 = color=()
    //     0xb6a77c: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xb6a780: ldur            x1, [fp, #-0x10]
    // 0xb6a784: ldur            x2, [fp, #-0x18]
    // 0xb6a788: ldur            x3, [fp, #-0x28]
    // 0xb6a78c: d0 = 2.975000
    //     0xb6a78c: add             x17, PP, #0xd5, lsl #12  ; [pp+0xd5178] IMM: double(2.975) from 0x4007cccccccccccd
    //     0xb6a790: ldr             d0, [x17, #0x178]
    // 0xb6a794: r0 = drawCircle()
    //     0xb6a794: bl              #0xb6acd4  ; [dart:ui] _NativeCanvas::drawCircle
    // 0xb6a798: ldur            x0, [fp, #-8]
    // 0xb6a79c: LoadField: r1 = r0->field_5b
    //     0xb6a79c: ldur            w1, [x0, #0x5b]
    // 0xb6a7a0: DecompressPointer r1
    //     0xb6a7a0: add             x1, x1, HEAP, lsl #32
    // 0xb6a7a4: cmp             w1, NULL
    // 0xb6a7a8: b.eq            #0xb6aa04
    // 0xb6a7ac: tbz             w1, #4, #0xb6a940
    // 0xb6a7b0: mov             x1, x0
    // 0xb6a7b4: ldur            x2, [fp, #-0x10]
    // 0xb6a7b8: ldur            x3, [fp, #-0x18]
    // 0xb6a7bc: r0 = _drawOuterBorder()
    //     0xb6a7bc: bl              #0xb6ab34  ; [package:flutter/src/cupertino/radio.dart] _RadioPainter::_drawOuterBorder
    // 0xb6a7c0: b               #0xb6a940
    // 0xb6a7c4: ldur            x1, [fp, #-8]
    // 0xb6a7c8: r16 = 136
    //     0xb6a7c8: mov             x16, #0x88
    // 0xb6a7cc: stp             x16, NULL, [SP]
    // 0xb6a7d0: r0 = ByteData()
    //     0xb6a7d0: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xb6a7d4: stur            x0, [fp, #-0x20]
    // 0xb6a7d8: r0 = Paint()
    //     0xb6a7d8: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xb6a7dc: mov             x1, x0
    // 0xb6a7e0: ldur            x0, [fp, #-0x20]
    // 0xb6a7e4: stur            x1, [fp, #-0x28]
    // 0xb6a7e8: StoreField: r1->field_7 = r0
    //     0xb6a7e8: stur            w0, [x1, #7]
    // 0xb6a7ec: ldur            x0, [fp, #-8]
    // 0xb6a7f0: LoadField: r2 = r0->field_5b
    //     0xb6a7f0: ldur            w2, [x0, #0x5b]
    // 0xb6a7f4: DecompressPointer r2
    //     0xb6a7f4: add             x2, x2, HEAP, lsl #32
    // 0xb6a7f8: cmp             w2, NULL
    // 0xb6a7fc: b.eq            #0xb6aa08
    // 0xb6a800: tbnz            w2, #4, #0xb6a818
    // 0xb6a804: LoadField: r2 = r0->field_37
    //     0xb6a804: ldur            w2, [x0, #0x37]
    // 0xb6a808: DecompressPointer r2
    //     0xb6a808: add             x2, x2, HEAP, lsl #32
    // 0xb6a80c: cmp             w2, NULL
    // 0xb6a810: b.eq            #0xb6aa0c
    // 0xb6a814: b               #0xb6a840
    // 0xb6a818: r0 = LoadStaticField(0xce8)
    //     0xb6a818: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xb6a81c: ldr             x0, [x0, #0x19d0]
    // 0xb6a820: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb6a824: cmp             w0, w16
    // 0xb6a828: b.ne            #0xb6a838
    // 0xb6a82c: r2 = _kDisabledOuterColor
    //     0xb6a82c: add             x2, PP, #0xd5, lsl #12  ; [pp+0xd5150] Field <::._kDisabledOuterColor@811254404>: static late final (offset: 0xce8)
    //     0xb6a830: ldr             x2, [x2, #0x150]
    // 0xb6a834: r0 = InitLateFinalStaticField()
    //     0xb6a834: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xb6a838: mov             x2, x0
    // 0xb6a83c: ldur            x0, [fp, #-8]
    // 0xb6a840: ldur            x1, [fp, #-0x28]
    // 0xb6a844: r0 = color=()
    //     0xb6a844: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xb6a848: ldur            x0, [fp, #-8]
    // 0xb6a84c: LoadField: r1 = r0->field_6b
    //     0xb6a84c: ldur            w1, [x0, #0x6b]
    // 0xb6a850: DecompressPointer r1
    //     0xb6a850: add             x1, x1, HEAP, lsl #32
    // 0xb6a854: r16 = Instance_Brightness
    //     0xb6a854: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0xb6a858: cmp             w1, w16
    // 0xb6a85c: b.ne            #0xb6a8f8
    // 0xb6a860: ldur            x1, [fp, #-0x28]
    // 0xb6a864: r0 = color()
    //     0xb6a864: bl              #0xb6a1dc  ; [dart:ui] Paint::color
    // 0xb6a868: mov             x1, x0
    // 0xb6a86c: ldur            x0, [fp, #-8]
    // 0xb6a870: LoadField: r2 = r0->field_5b
    //     0xb6a870: ldur            w2, [x0, #0x5b]
    // 0xb6a874: DecompressPointer r2
    //     0xb6a874: add             x2, x2, HEAP, lsl #32
    // 0xb6a878: cmp             w2, NULL
    // 0xb6a87c: b.eq            #0xb6aa10
    // 0xb6a880: tbnz            w2, #4, #0xb6a890
    // 0xb6a884: d0 = 0.140000
    //     0xb6a884: add             x17, PP, #0xa2, lsl #12  ; [pp+0xa2ae8] IMM: double(0.14) from 0x3fc1eb851eb851ec
    //     0xb6a888: ldr             d0, [x17, #0xae8]
    // 0xb6a88c: b               #0xb6a898
    // 0xb6a890: d0 = 0.080000
    //     0xb6a890: add             x17, PP, #0x15, lsl #12  ; [pp+0x15a58] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0xb6a894: ldr             d0, [x17, #0xa58]
    // 0xb6a898: r0 = withOpacity()
    //     0xb6a898: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xb6a89c: ldur            x1, [fp, #-0x28]
    // 0xb6a8a0: stur            x0, [fp, #-0x20]
    // 0xb6a8a4: r0 = color()
    //     0xb6a8a4: bl              #0xb6a1dc  ; [dart:ui] Paint::color
    // 0xb6a8a8: mov             x1, x0
    // 0xb6a8ac: ldur            x0, [fp, #-8]
    // 0xb6a8b0: LoadField: r2 = r0->field_5b
    //     0xb6a8b0: ldur            w2, [x0, #0x5b]
    // 0xb6a8b4: DecompressPointer r2
    //     0xb6a8b4: add             x2, x2, HEAP, lsl #32
    // 0xb6a8b8: cmp             w2, NULL
    // 0xb6a8bc: b.eq            #0xb6aa14
    // 0xb6a8c0: tbnz            w2, #4, #0xb6a8d0
    // 0xb6a8c4: d0 = 0.290000
    //     0xb6a8c4: add             x17, PP, #0x13, lsl #12  ; [pp+0x131a8] IMM: double(0.29) from 0x3fd28f5c28f5c28f
    //     0xb6a8c8: ldr             d0, [x17, #0x1a8]
    // 0xb6a8cc: b               #0xb6a8d8
    // 0xb6a8d0: d0 = 0.140000
    //     0xb6a8d0: add             x17, PP, #0xa2, lsl #12  ; [pp+0xa2ae8] IMM: double(0.14) from 0x3fc1eb851eb851ec
    //     0xb6a8d4: ldr             d0, [x17, #0xae8]
    // 0xb6a8d8: r0 = withOpacity()
    //     0xb6a8d8: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xb6a8dc: ldur            x1, [fp, #-8]
    // 0xb6a8e0: ldur            x2, [fp, #-0x10]
    // 0xb6a8e4: ldur            x3, [fp, #-0x18]
    // 0xb6a8e8: ldur            x5, [fp, #-0x20]
    // 0xb6a8ec: mov             x6, x0
    // 0xb6a8f0: r0 = _drawFillGradient()
    //     0xb6a8f0: bl              #0xb6af74  ; [package:flutter/src/cupertino/radio.dart] _RadioPainter::_drawFillGradient
    // 0xb6a8f4: b               #0xb6a90c
    // 0xb6a8f8: ldur            x1, [fp, #-0x10]
    // 0xb6a8fc: ldur            x2, [fp, #-0x18]
    // 0xb6a900: ldur            x3, [fp, #-0x28]
    // 0xb6a904: d0 = 7.000000
    //     0xb6a904: fmov            d0, #7.00000000
    // 0xb6a908: r0 = drawCircle()
    //     0xb6a908: bl              #0xb6acd4  ; [dart:ui] _NativeCanvas::drawCircle
    // 0xb6a90c: ldur            x0, [fp, #-8]
    // 0xb6a910: LoadField: r1 = r0->field_4f
    //     0xb6a910: ldur            w1, [x0, #0x4f]
    // 0xb6a914: DecompressPointer r1
    //     0xb6a914: add             x1, x1, HEAP, lsl #32
    // 0xb6a918: cmp             w1, NULL
    // 0xb6a91c: b.eq            #0xb6a930
    // 0xb6a920: mov             x1, x0
    // 0xb6a924: ldur            x2, [fp, #-0x10]
    // 0xb6a928: ldur            x3, [fp, #-0x18]
    // 0xb6a92c: r0 = _drawPressedOverlay()
    //     0xb6a92c: bl              #0xb6ac00  ; [package:flutter/src/cupertino/radio.dart] _RadioPainter::_drawPressedOverlay
    // 0xb6a930: ldur            x1, [fp, #-8]
    // 0xb6a934: ldur            x2, [fp, #-0x10]
    // 0xb6a938: ldur            x3, [fp, #-0x18]
    // 0xb6a93c: r0 = _drawOuterBorder()
    //     0xb6a93c: bl              #0xb6ab34  ; [package:flutter/src/cupertino/radio.dart] _RadioPainter::_drawOuterBorder
    // 0xb6a940: ldur            x0, [fp, #-8]
    // 0xb6a944: LoadField: r1 = r0->field_53
    //     0xb6a944: ldur            w1, [x0, #0x53]
    // 0xb6a948: DecompressPointer r1
    //     0xb6a948: add             x1, x1, HEAP, lsl #32
    // 0xb6a94c: cmp             w1, NULL
    // 0xb6a950: b.eq            #0xb6aa18
    // 0xb6a954: tbnz            w1, #4, #0xb6a9d8
    // 0xb6a958: r16 = 136
    //     0xb6a958: mov             x16, #0x88
    // 0xb6a95c: stp             x16, NULL, [SP]
    // 0xb6a960: r0 = ByteData()
    //     0xb6a960: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xb6a964: stur            x0, [fp, #-0x20]
    // 0xb6a968: r0 = Paint()
    //     0xb6a968: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xb6a96c: mov             x3, x0
    // 0xb6a970: ldur            x0, [fp, #-0x20]
    // 0xb6a974: stur            x3, [fp, #-0x30]
    // 0xb6a978: StoreField: r3->field_7 = r0
    //     0xb6a978: stur            w0, [x3, #7]
    // 0xb6a97c: ArrayLoad: r4 = r0[0]  ; List_4
    //     0xb6a97c: ldur            w4, [x0, #0x17]
    // 0xb6a980: DecompressPointer r4
    //     0xb6a980: add             x4, x4, HEAP, lsl #32
    // 0xb6a984: stur            x4, [fp, #-0x28]
    // 0xb6a988: LoadField: r0 = r4->field_7
    //     0xb6a988: ldur            x0, [x4, #7]
    // 0xb6a98c: r1 = 1
    //     0xb6a98c: mov             x1, #1
    // 0xb6a990: str             w1, [x0, #0x1c]
    // 0xb6a994: ldur            x0, [fp, #-8]
    // 0xb6a998: LoadField: r2 = r0->field_47
    //     0xb6a998: ldur            w2, [x0, #0x47]
    // 0xb6a99c: DecompressPointer r2
    //     0xb6a99c: add             x2, x2, HEAP, lsl #32
    // 0xb6a9a0: cmp             w2, NULL
    // 0xb6a9a4: b.eq            #0xb6aa1c
    // 0xb6a9a8: mov             x1, x3
    // 0xb6a9ac: r0 = color=()
    //     0xb6a9ac: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xb6a9b0: ldur            x0, [fp, #-0x28]
    // 0xb6a9b4: LoadField: r1 = r0->field_7
    //     0xb6a9b4: ldur            x1, [x0, #7]
    // 0xb6a9b8: d0 = 0.000000
    //     0xb6a9b8: add             x17, PP, #0xd5, lsl #12  ; [pp+0xd5180] IMM: 0x40400000
    //     0xb6a9bc: ldr             s0, [x17, #0x180]
    // 0xb6a9c0: str             s0, [x1, #0x20]
    // 0xb6a9c4: ldur            x1, [fp, #-0x10]
    // 0xb6a9c8: ldur            x2, [fp, #-0x18]
    // 0xb6a9cc: ldur            x3, [fp, #-0x30]
    // 0xb6a9d0: d0 = 8.500000
    //     0xb6a9d0: fmov            d0, #8.50000000
    // 0xb6a9d4: r0 = drawCircle()
    //     0xb6a9d4: bl              #0xb6acd4  ; [dart:ui] _NativeCanvas::drawCircle
    // 0xb6a9d8: r0 = Null
    //     0xb6a9d8: mov             x0, NULL
    // 0xb6a9dc: LeaveFrame
    //     0xb6a9dc: mov             SP, fp
    //     0xb6a9e0: ldp             fp, lr, [SP], #0x10
    // 0xb6a9e4: ret
    //     0xb6a9e4: ret             
    // 0xb6a9e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb6a9e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb6a9ec: b               #0xb6a5d4
    // 0xb6a9f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6a9f0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6a9f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6a9f4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6a9f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6a9f8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6a9fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6a9fc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6aa00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6aa00: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6aa04: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6aa04: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6aa08: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6aa08: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6aa0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6aa0c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6aa10: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6aa10: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6aa14: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6aa14: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6aa18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6aa18: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6aa1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6aa1c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  bool? dyn:get:value(_RadioPainter) {
    // ** addr: 0xb6aa38, size: 0x28
    // 0xb6aa38: ldr             x1, [SP]
    // 0xb6aa3c: LoadField: r0 = r1->field_5f
    //     0xb6aa3c: ldur            w0, [x1, #0x5f]
    // 0xb6aa40: DecompressPointer r0
    //     0xb6aa40: add             x0, x0, HEAP, lsl #32
    // 0xb6aa44: ret
    //     0xb6aa44: ret             
  }
  void dyn:set:value(_RadioPainter, bool?) {
    // ** addr: 0xb6aa60, size: 0x98
    // 0xb6aa60: EnterFrame
    //     0xb6aa60: stp             fp, lr, [SP, #-0x10]!
    //     0xb6aa64: mov             fp, SP
    // 0xb6aa68: CheckStackOverflow
    //     0xb6aa68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb6aa6c: cmp             SP, x16
    //     0xb6aa70: b.ls            #0xb6aad8
    // 0xb6aa74: ldr             x0, [fp, #0x10]
    // 0xb6aa78: r2 = Null
    //     0xb6aa78: mov             x2, NULL
    // 0xb6aa7c: r1 = Null
    //     0xb6aa7c: mov             x1, NULL
    // 0xb6aa80: r4 = 60
    //     0xb6aa80: mov             x4, #0x3c
    // 0xb6aa84: branchIfSmi(r0, 0xb6aa90)
    //     0xb6aa84: tbz             w0, #0, #0xb6aa90
    // 0xb6aa88: r4 = LoadClassIdInstr(r0)
    //     0xb6aa88: ldur            x4, [x0, #-1]
    //     0xb6aa8c: ubfx            x4, x4, #0xc, #0x14
    // 0xb6aa90: cmp             x4, #0x3f
    // 0xb6aa94: b.eq            #0xb6aaa8
    // 0xb6aa98: r8 = bool?
    //     0xb6aa98: ldr             x8, [PP, #0x5fd0]  ; [pp+0x5fd0] Type: bool?
    // 0xb6aa9c: r3 = Null
    //     0xb6aa9c: add             x3, PP, #0xd5, lsl #12  ; [pp+0xd5190] Null
    //     0xb6aaa0: ldr             x3, [x3, #0x190]
    // 0xb6aaa4: r0 = bool?()
    //     0xb6aaa4: bl              #0x7ecd2c  ; IsType_bool?_Stub
    // 0xb6aaa8: ldr             x1, [fp, #0x18]
    // 0xb6aaac: LoadField: r0 = r1->field_5f
    //     0xb6aaac: ldur            w0, [x1, #0x5f]
    // 0xb6aab0: DecompressPointer r0
    //     0xb6aab0: add             x0, x0, HEAP, lsl #32
    // 0xb6aab4: ldr             x2, [fp, #0x10]
    // 0xb6aab8: cmp             w0, w2
    // 0xb6aabc: b.eq            #0xb6aac8
    // 0xb6aac0: StoreField: r1->field_5f = r2
    //     0xb6aac0: stur            w2, [x1, #0x5f]
    // 0xb6aac4: r0 = notifyListeners()
    //     0xb6aac4: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xb6aac8: r0 = Null
    //     0xb6aac8: mov             x0, NULL
    // 0xb6aacc: LeaveFrame
    //     0xb6aacc: mov             SP, fp
    //     0xb6aad0: ldp             fp, lr, [SP], #0x10
    // 0xb6aad4: ret
    //     0xb6aad4: ret             
    // 0xb6aad8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb6aad8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb6aadc: b               #0xb6aa74
  }
  set void value=(_RadioPainter, bool?) {
    // ** addr: 0xb6aae0, size: 0x54
    // 0xb6aae0: EnterFrame
    //     0xb6aae0: stp             fp, lr, [SP, #-0x10]!
    //     0xb6aae4: mov             fp, SP
    // 0xb6aae8: CheckStackOverflow
    //     0xb6aae8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb6aaec: cmp             SP, x16
    //     0xb6aaf0: b.ls            #0xb6ab2c
    // 0xb6aaf4: LoadField: r0 = r1->field_5f
    //     0xb6aaf4: ldur            w0, [x1, #0x5f]
    // 0xb6aaf8: DecompressPointer r0
    //     0xb6aaf8: add             x0, x0, HEAP, lsl #32
    // 0xb6aafc: cmp             w0, w2
    // 0xb6ab00: b.ne            #0xb6ab14
    // 0xb6ab04: r0 = Null
    //     0xb6ab04: mov             x0, NULL
    // 0xb6ab08: LeaveFrame
    //     0xb6ab08: mov             SP, fp
    //     0xb6ab0c: ldp             fp, lr, [SP], #0x10
    // 0xb6ab10: ret
    //     0xb6ab10: ret             
    // 0xb6ab14: StoreField: r1->field_5f = r2
    //     0xb6ab14: stur            w2, [x1, #0x5f]
    // 0xb6ab18: r0 = notifyListeners()
    //     0xb6ab18: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xb6ab1c: r0 = Null
    //     0xb6ab1c: mov             x0, NULL
    // 0xb6ab20: LeaveFrame
    //     0xb6ab20: mov             SP, fp
    //     0xb6ab24: ldp             fp, lr, [SP], #0x10
    // 0xb6ab28: ret
    //     0xb6ab28: ret             
    // 0xb6ab2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb6ab2c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb6ab30: b               #0xb6aaf4
  }
  _ _drawOuterBorder(/* No info */) {
    // ** addr: 0xb6ab34, size: 0xcc
    // 0xb6ab34: EnterFrame
    //     0xb6ab34: stp             fp, lr, [SP, #-0x10]!
    //     0xb6ab38: mov             fp, SP
    // 0xb6ab3c: AllocStack(0x40)
    //     0xb6ab3c: sub             SP, SP, #0x40
    // 0xb6ab40: SetupParameters(_RadioPainter this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */, dynamic _ /* r3 => r2, fp-0x18 */)
    //     0xb6ab40: mov             x0, x1
    //     0xb6ab44: stur            x1, [fp, #-8]
    //     0xb6ab48: mov             x1, x2
    //     0xb6ab4c: stur            x2, [fp, #-0x10]
    //     0xb6ab50: mov             x2, x3
    //     0xb6ab54: stur            x3, [fp, #-0x18]
    // 0xb6ab58: CheckStackOverflow
    //     0xb6ab58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb6ab5c: cmp             SP, x16
    //     0xb6ab60: b.ls            #0xb6abf4
    // 0xb6ab64: r16 = 136
    //     0xb6ab64: mov             x16, #0x88
    // 0xb6ab68: stp             x16, NULL, [SP]
    // 0xb6ab6c: r0 = ByteData()
    //     0xb6ab6c: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xb6ab70: stur            x0, [fp, #-0x20]
    // 0xb6ab74: r0 = Paint()
    //     0xb6ab74: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xb6ab78: mov             x3, x0
    // 0xb6ab7c: ldur            x0, [fp, #-0x20]
    // 0xb6ab80: stur            x3, [fp, #-0x30]
    // 0xb6ab84: StoreField: r3->field_7 = r0
    //     0xb6ab84: stur            w0, [x3, #7]
    // 0xb6ab88: ArrayLoad: r4 = r0[0]  ; List_4
    //     0xb6ab88: ldur            w4, [x0, #0x17]
    // 0xb6ab8c: DecompressPointer r4
    //     0xb6ab8c: add             x4, x4, HEAP, lsl #32
    // 0xb6ab90: stur            x4, [fp, #-0x28]
    // 0xb6ab94: LoadField: r0 = r4->field_7
    //     0xb6ab94: ldur            x0, [x4, #7]
    // 0xb6ab98: r1 = 1
    //     0xb6ab98: mov             x1, #1
    // 0xb6ab9c: str             w1, [x0, #0x1c]
    // 0xb6aba0: ldur            x0, [fp, #-8]
    // 0xb6aba4: LoadField: r2 = r0->field_6f
    //     0xb6aba4: ldur            w2, [x0, #0x6f]
    // 0xb6aba8: DecompressPointer r2
    //     0xb6aba8: add             x2, x2, HEAP, lsl #32
    // 0xb6abac: cmp             w2, NULL
    // 0xb6abb0: b.eq            #0xb6abfc
    // 0xb6abb4: mov             x1, x3
    // 0xb6abb8: r0 = color=()
    //     0xb6abb8: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xb6abbc: ldur            x0, [fp, #-0x28]
    // 0xb6abc0: LoadField: r1 = r0->field_7
    //     0xb6abc0: ldur            x1, [x0, #7]
    // 0xb6abc4: d0 = 0.000000
    //     0xb6abc4: add             x17, PP, #0xd5, lsl #12  ; [pp+0xd5188] IMM: 0x3e99999a
    //     0xb6abc8: ldr             s0, [x17, #0x188]
    // 0xb6abcc: str             s0, [x1, #0x20]
    // 0xb6abd0: ldur            x1, [fp, #-0x10]
    // 0xb6abd4: ldur            x2, [fp, #-0x18]
    // 0xb6abd8: ldur            x3, [fp, #-0x30]
    // 0xb6abdc: d0 = 7.000000
    //     0xb6abdc: fmov            d0, #7.00000000
    // 0xb6abe0: r0 = drawCircle()
    //     0xb6abe0: bl              #0xb6acd4  ; [dart:ui] _NativeCanvas::drawCircle
    // 0xb6abe4: r0 = Null
    //     0xb6abe4: mov             x0, NULL
    // 0xb6abe8: LeaveFrame
    //     0xb6abe8: mov             SP, fp
    //     0xb6abec: ldp             fp, lr, [SP], #0x10
    // 0xb6abf0: ret
    //     0xb6abf0: ret             
    // 0xb6abf4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb6abf4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb6abf8: b               #0xb6ab64
    // 0xb6abfc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6abfc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _drawPressedOverlay(/* No info */) {
    // ** addr: 0xb6ac00, size: 0xd4
    // 0xb6ac00: EnterFrame
    //     0xb6ac00: stp             fp, lr, [SP, #-0x10]!
    //     0xb6ac04: mov             fp, SP
    // 0xb6ac08: AllocStack(0x38)
    //     0xb6ac08: sub             SP, SP, #0x38
    // 0xb6ac0c: SetupParameters(_RadioPainter this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */, dynamic _ /* r3 => r2, fp-0x18 */)
    //     0xb6ac0c: mov             x0, x1
    //     0xb6ac10: stur            x1, [fp, #-8]
    //     0xb6ac14: mov             x1, x2
    //     0xb6ac18: stur            x2, [fp, #-0x10]
    //     0xb6ac1c: mov             x2, x3
    //     0xb6ac20: stur            x3, [fp, #-0x18]
    // 0xb6ac24: CheckStackOverflow
    //     0xb6ac24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb6ac28: cmp             SP, x16
    //     0xb6ac2c: b.ls            #0xb6accc
    // 0xb6ac30: r16 = 136
    //     0xb6ac30: mov             x16, #0x88
    // 0xb6ac34: stp             x16, NULL, [SP]
    // 0xb6ac38: r0 = ByteData()
    //     0xb6ac38: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xb6ac3c: stur            x0, [fp, #-0x20]
    // 0xb6ac40: r0 = Paint()
    //     0xb6ac40: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xb6ac44: mov             x2, x0
    // 0xb6ac48: ldur            x0, [fp, #-0x20]
    // 0xb6ac4c: stur            x2, [fp, #-0x28]
    // 0xb6ac50: StoreField: r2->field_7 = r0
    //     0xb6ac50: stur            w0, [x2, #7]
    // 0xb6ac54: ldur            x0, [fp, #-8]
    // 0xb6ac58: LoadField: r1 = r0->field_6b
    //     0xb6ac58: ldur            w1, [x0, #0x6b]
    // 0xb6ac5c: DecompressPointer r1
    //     0xb6ac5c: add             x1, x1, HEAP, lsl #32
    // 0xb6ac60: r16 = Instance_Brightness
    //     0xb6ac60: ldr             x16, [PP, #0x6da0]  ; [pp+0x6da0] Obj!Brightness@12c71c1
    // 0xb6ac64: cmp             w1, w16
    // 0xb6ac68: b.ne            #0xb6ac88
    // 0xb6ac6c: r1 = Instance_Color
    //     0xb6ac6c: add             x1, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0xb6ac70: ldr             x1, [x1, #0x948]
    // 0xb6ac74: d0 = 0.150000
    //     0xb6ac74: add             x17, PP, #0x12, lsl #12  ; [pp+0x12ee8] IMM: double(0.15) from 0x3fc3333333333333
    //     0xb6ac78: ldr             d0, [x17, #0xee8]
    // 0xb6ac7c: r0 = withOpacity()
    //     0xb6ac7c: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xb6ac80: mov             x2, x0
    // 0xb6ac84: b               #0xb6aca0
    // 0xb6ac88: r1 = Instance_Color
    //     0xb6ac88: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0xb6ac8c: ldr             x1, [x1, #0xc38]
    // 0xb6ac90: d0 = 0.150000
    //     0xb6ac90: add             x17, PP, #0x12, lsl #12  ; [pp+0x12ee8] IMM: double(0.15) from 0x3fc3333333333333
    //     0xb6ac94: ldr             d0, [x17, #0xee8]
    // 0xb6ac98: r0 = withOpacity()
    //     0xb6ac98: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xb6ac9c: mov             x2, x0
    // 0xb6aca0: ldur            x1, [fp, #-0x28]
    // 0xb6aca4: r0 = color=()
    //     0xb6aca4: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xb6aca8: ldur            x1, [fp, #-0x10]
    // 0xb6acac: ldur            x2, [fp, #-0x18]
    // 0xb6acb0: ldur            x3, [fp, #-0x28]
    // 0xb6acb4: d0 = 7.000000
    //     0xb6acb4: fmov            d0, #7.00000000
    // 0xb6acb8: r0 = drawCircle()
    //     0xb6acb8: bl              #0xb6acd4  ; [dart:ui] _NativeCanvas::drawCircle
    // 0xb6acbc: r0 = Null
    //     0xb6acbc: mov             x0, NULL
    // 0xb6acc0: LeaveFrame
    //     0xb6acc0: mov             SP, fp
    //     0xb6acc4: ldp             fp, lr, [SP], #0x10
    // 0xb6acc8: ret
    //     0xb6acc8: ret             
    // 0xb6accc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb6accc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb6acd0: b               #0xb6ac30
  }
  _ _drawFillGradient(/* No info */) {
    // ** addr: 0xb6af74, size: 0x2a4
    // 0xb6af74: EnterFrame
    //     0xb6af74: stp             fp, lr, [SP, #-0x10]!
    //     0xb6af78: mov             fp, SP
    // 0xb6af7c: AllocStack(0x68)
    //     0xb6af7c: sub             SP, SP, #0x68
    // 0xb6af80: r0 = 4
    //     0xb6af80: mov             x0, #4
    // 0xb6af84: mov             x4, x2
    // 0xb6af88: stur            x2, [fp, #-8]
    // 0xb6af8c: stur            x3, [fp, #-0x10]
    // 0xb6af90: stur            x5, [fp, #-0x18]
    // 0xb6af94: stur            x6, [fp, #-0x20]
    // 0xb6af98: CheckStackOverflow
    //     0xb6af98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb6af9c: cmp             SP, x16
    //     0xb6afa0: b.ls            #0xb6b204
    // 0xb6afa4: mov             x2, x0
    // 0xb6afa8: r1 = Null
    //     0xb6afa8: mov             x1, NULL
    // 0xb6afac: r0 = AllocateArray()
    //     0xb6afac: bl              #0x13df928  ; AllocateArrayStub
    // 0xb6afb0: mov             x2, x0
    // 0xb6afb4: ldur            x0, [fp, #-0x18]
    // 0xb6afb8: stur            x2, [fp, #-0x28]
    // 0xb6afbc: StoreField: r2->field_f = r0
    //     0xb6afbc: stur            w0, [x2, #0xf]
    // 0xb6afc0: ldur            x0, [fp, #-0x20]
    // 0xb6afc4: StoreField: r2->field_13 = r0
    //     0xb6afc4: stur            w0, [x2, #0x13]
    // 0xb6afc8: r1 = <Color>
    //     0xb6afc8: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xb6afcc: ldr             x1, [x1, #0xa90]
    // 0xb6afd0: r0 = AllocateGrowableArray()
    //     0xb6afd0: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xb6afd4: mov             x1, x0
    // 0xb6afd8: ldur            x0, [fp, #-0x28]
    // 0xb6afdc: stur            x1, [fp, #-0x18]
    // 0xb6afe0: StoreField: r1->field_f = r0
    //     0xb6afe0: stur            w0, [x1, #0xf]
    // 0xb6afe4: r0 = 4
    //     0xb6afe4: mov             x0, #4
    // 0xb6afe8: StoreField: r1->field_b = r0
    //     0xb6afe8: stur            w0, [x1, #0xb]
    // 0xb6afec: r0 = LinearGradient()
    //     0xb6afec: bl              #0xb6a1d0  ; AllocateLinearGradientStub -> LinearGradient (size=0x20)
    // 0xb6aff0: mov             x1, x0
    // 0xb6aff4: r0 = Instance_Alignment
    //     0xb6aff4: add             x0, PP, #0x19, lsl #12  ; [pp+0x197a8] Obj!Alignment@129e7d1
    //     0xb6aff8: ldr             x0, [x0, #0x7a8]
    // 0xb6affc: stur            x1, [fp, #-0x20]
    // 0xb6b000: StoreField: r1->field_13 = r0
    //     0xb6b000: stur            w0, [x1, #0x13]
    // 0xb6b004: r0 = Instance_Alignment
    //     0xb6b004: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e1b8] Obj!Alignment@129e6f1
    //     0xb6b008: ldr             x0, [x0, #0x1b8]
    // 0xb6b00c: ArrayStore: r1[0] = r0  ; List_4
    //     0xb6b00c: stur            w0, [x1, #0x17]
    // 0xb6b010: r0 = Instance_TileMode
    //     0xb6b010: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e900] Obj!TileMode@12c7f61
    //     0xb6b014: ldr             x0, [x0, #0x900]
    // 0xb6b018: StoreField: r1->field_1b = r0
    //     0xb6b018: stur            w0, [x1, #0x1b]
    // 0xb6b01c: ldur            x0, [fp, #-0x18]
    // 0xb6b020: StoreField: r1->field_7 = r0
    //     0xb6b020: stur            w0, [x1, #7]
    // 0xb6b024: r0 = Rect()
    //     0xb6b024: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0xb6b028: mov             x1, x0
    // 0xb6b02c: ldur            x2, [fp, #-0x10]
    // 0xb6b030: d0 = 14.000000
    //     0xb6b030: fmov            d0, #14.00000000
    // 0xb6b034: d1 = 14.000000
    //     0xb6b034: fmov            d1, #14.00000000
    // 0xb6b038: stur            x0, [fp, #-0x10]
    // 0xb6b03c: r0 = Rect.fromCenter()
    //     0xb6b03c: bl              #0x86ddc8  ; [dart:ui] Rect::Rect.fromCenter
    // 0xb6b040: r16 = 136
    //     0xb6b040: mov             x16, #0x88
    // 0xb6b044: stp             x16, NULL, [SP]
    // 0xb6b048: r0 = ByteData()
    //     0xb6b048: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xb6b04c: stur            x0, [fp, #-0x18]
    // 0xb6b050: r0 = Paint()
    //     0xb6b050: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xb6b054: ldur            x5, [fp, #-0x18]
    // 0xb6b058: stur            x0, [fp, #-0x28]
    // 0xb6b05c: StoreField: r0->field_7 = r5
    //     0xb6b05c: stur            w5, [x0, #7]
    // 0xb6b060: ldur            x1, [fp, #-0x20]
    // 0xb6b064: ldur            x2, [fp, #-0x10]
    // 0xb6b068: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xb6b068: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xb6b06c: r0 = createShader()
    //     0xb6b06c: bl              #0x1305638  ; [package:flutter/src/painting/gradient.dart] LinearGradient::createShader
    // 0xb6b070: ldur            x1, [fp, #-0x28]
    // 0xb6b074: stur            x0, [fp, #-0x20]
    // 0xb6b078: r0 = _ensureObjectsInitialized()
    //     0xb6b078: bl              #0xaf5568  ; [dart:ui] Paint::_ensureObjectsInitialized
    // 0xb6b07c: r1 = LoadClassIdInstr(r0)
    //     0xb6b07c: ldur            x1, [x0, #-1]
    //     0xb6b080: ubfx            x1, x1, #0xc, #0x14
    // 0xb6b084: stp             xzr, x0, [SP, #8]
    // 0xb6b088: ldur            x16, [fp, #-0x20]
    // 0xb6b08c: str             x16, [SP]
    // 0xb6b090: mov             x0, x1
    // 0xb6b094: r0 = GDT[cid_x0 + 0x18dc8]()
    //     0xb6b094: mov             x17, #0x8dc8
    //     0xb6b098: movk            x17, #1, lsl #16
    //     0xb6b09c: add             lr, x0, x17
    //     0xb6b0a0: ldr             lr, [x21, lr, lsl #3]
    //     0xb6b0a4: blr             lr
    // 0xb6b0a8: r0 = _NativePath()
    //     0xb6b0a8: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0xb6b0ac: mov             x1, x0
    // 0xb6b0b0: stur            x0, [fp, #-0x20]
    // 0xb6b0b4: r0 = __constructor$Method$FfiNative()
    //     0xb6b0b4: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0xb6b0b8: ldur            x0, [fp, #-0x10]
    // 0xb6b0bc: LoadField: d0 = r0->field_7
    //     0xb6b0bc: ldur            d0, [x0, #7]
    // 0xb6b0c0: stur            d0, [fp, #-0x50]
    // 0xb6b0c4: LoadField: d1 = r0->field_f
    //     0xb6b0c4: ldur            d1, [x0, #0xf]
    // 0xb6b0c8: stur            d1, [fp, #-0x48]
    // 0xb6b0cc: ArrayLoad: d2 = r0[0]  ; List_8
    //     0xb6b0cc: ldur            d2, [x0, #0x17]
    // 0xb6b0d0: stur            d2, [fp, #-0x40]
    // 0xb6b0d4: LoadField: d3 = r0->field_1f
    //     0xb6b0d4: ldur            d3, [x0, #0x1f]
    // 0xb6b0d8: ldur            x0, [fp, #-0x20]
    // 0xb6b0dc: stur            d3, [fp, #-0x38]
    // 0xb6b0e0: LoadField: r1 = r0->field_7
    //     0xb6b0e0: ldur            w1, [x0, #7]
    // 0xb6b0e4: DecompressPointer r1
    //     0xb6b0e4: add             x1, x1, HEAP, lsl #32
    // 0xb6b0e8: cmp             w1, NULL
    // 0xb6b0ec: b.eq            #0xb6b20c
    // 0xb6b0f0: LoadField: r2 = r1->field_7
    //     0xb6b0f0: ldur            x2, [x1, #7]
    // 0xb6b0f4: ldr             x1, [x2]
    // 0xb6b0f8: cbz             x1, #0xb6b1e4
    // 0xb6b0fc: ldur            x3, [fp, #-8]
    // 0xb6b100: ldur            x2, [fp, #-0x28]
    // 0xb6b104: mov             x4, x1
    // 0xb6b108: stur            x4, [fp, #-0x30]
    // 0xb6b10c: r1 = <Never>
    //     0xb6b10c: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb6b110: r0 = Pointer()
    //     0xb6b110: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb6b114: mov             x1, x0
    // 0xb6b118: ldur            x0, [fp, #-0x30]
    // 0xb6b11c: StoreField: r1->field_7 = r0
    //     0xb6b11c: stur            x0, [x1, #7]
    // 0xb6b120: ldur            d0, [fp, #-0x50]
    // 0xb6b124: ldur            d1, [fp, #-0x48]
    // 0xb6b128: ldur            d2, [fp, #-0x40]
    // 0xb6b12c: ldur            d3, [fp, #-0x38]
    // 0xb6b130: r0 = __addOval$Method$FfiNative()
    //     0xb6b130: bl              #0xb6b218  ; [dart:ui] _NativePath::__addOval$Method$FfiNative
    // 0xb6b134: ldur            x0, [fp, #-0x28]
    // 0xb6b138: LoadField: r3 = r0->field_b
    //     0xb6b138: ldur            w3, [x0, #0xb]
    // 0xb6b13c: DecompressPointer r3
    //     0xb6b13c: add             x3, x3, HEAP, lsl #32
    // 0xb6b140: ldur            x0, [fp, #-8]
    // 0xb6b144: stur            x3, [fp, #-0x10]
    // 0xb6b148: LoadField: r1 = r0->field_7
    //     0xb6b148: ldur            w1, [x0, #7]
    // 0xb6b14c: DecompressPointer r1
    //     0xb6b14c: add             x1, x1, HEAP, lsl #32
    // 0xb6b150: cmp             w1, NULL
    // 0xb6b154: b.eq            #0xb6b210
    // 0xb6b158: LoadField: r2 = r1->field_7
    //     0xb6b158: ldur            x2, [x1, #7]
    // 0xb6b15c: ldr             x1, [x2]
    // 0xb6b160: cbz             x1, #0xb6b1f4
    // 0xb6b164: ldur            x2, [fp, #-0x20]
    // 0xb6b168: mov             x4, x1
    // 0xb6b16c: stur            x4, [fp, #-0x30]
    // 0xb6b170: r1 = <Never>
    //     0xb6b170: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb6b174: r0 = Pointer()
    //     0xb6b174: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb6b178: mov             x2, x0
    // 0xb6b17c: ldur            x0, [fp, #-0x30]
    // 0xb6b180: stur            x2, [fp, #-0x28]
    // 0xb6b184: StoreField: r2->field_7 = r0
    //     0xb6b184: stur            x0, [x2, #7]
    // 0xb6b188: ldur            x0, [fp, #-0x20]
    // 0xb6b18c: LoadField: r1 = r0->field_7
    //     0xb6b18c: ldur            w1, [x0, #7]
    // 0xb6b190: DecompressPointer r1
    //     0xb6b190: add             x1, x1, HEAP, lsl #32
    // 0xb6b194: cmp             w1, NULL
    // 0xb6b198: b.eq            #0xb6b214
    // 0xb6b19c: LoadField: r3 = r1->field_7
    //     0xb6b19c: ldur            x3, [x1, #7]
    // 0xb6b1a0: ldr             x1, [x3]
    // 0xb6b1a4: mov             x3, x1
    // 0xb6b1a8: stur            x3, [fp, #-0x30]
    // 0xb6b1ac: r1 = <Never>
    //     0xb6b1ac: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb6b1b0: r0 = Pointer()
    //     0xb6b1b0: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb6b1b4: mov             x1, x0
    // 0xb6b1b8: ldur            x0, [fp, #-0x30]
    // 0xb6b1bc: StoreField: r1->field_7 = r0
    //     0xb6b1bc: stur            x0, [x1, #7]
    // 0xb6b1c0: mov             x2, x1
    // 0xb6b1c4: ldur            x1, [fp, #-0x28]
    // 0xb6b1c8: ldur            x3, [fp, #-0x10]
    // 0xb6b1cc: ldur            x5, [fp, #-0x18]
    // 0xb6b1d0: r0 = __drawPath$Method$FfiNative()
    //     0xb6b1d0: bl              #0xb69a00  ; [dart:ui] _NativeCanvas::__drawPath$Method$FfiNative
    // 0xb6b1d4: r0 = Null
    //     0xb6b1d4: mov             x0, NULL
    // 0xb6b1d8: LeaveFrame
    //     0xb6b1d8: mov             SP, fp
    //     0xb6b1dc: ldp             fp, lr, [SP], #0x10
    // 0xb6b1e0: ret
    //     0xb6b1e0: ret             
    // 0xb6b1e4: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb6b1e4: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb6b1e8: str             x16, [SP]
    // 0xb6b1ec: r0 = _throwNew()
    //     0xb6b1ec: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb6b1f0: brk             #0
    // 0xb6b1f4: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb6b1f4: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb6b1f8: str             x16, [SP]
    // 0xb6b1fc: r0 = _throwNew()
    //     0xb6b1fc: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb6b200: brk             #0
    // 0xb6b204: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb6b204: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb6b208: b               #0xb6afa4
    // 0xb6b20c: r0 = NullErrorSharedWithFPURegs()
    //     0xb6b20c: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0xb6b210: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb6b210: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xb6b214: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb6b214: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  set _ brightness=(/* No info */) {
    // ** addr: 0xde68bc, size: 0x70
    // 0xde68bc: EnterFrame
    //     0xde68bc: stp             fp, lr, [SP, #-0x10]!
    //     0xde68c0: mov             fp, SP
    // 0xde68c4: mov             x0, x2
    // 0xde68c8: CheckStackOverflow
    //     0xde68c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde68cc: cmp             SP, x16
    //     0xde68d0: b.ls            #0xde6924
    // 0xde68d4: LoadField: r2 = r1->field_6b
    //     0xde68d4: ldur            w2, [x1, #0x6b]
    // 0xde68d8: DecompressPointer r2
    //     0xde68d8: add             x2, x2, HEAP, lsl #32
    // 0xde68dc: cmp             w2, w0
    // 0xde68e0: b.ne            #0xde68f4
    // 0xde68e4: r0 = Null
    //     0xde68e4: mov             x0, NULL
    // 0xde68e8: LeaveFrame
    //     0xde68e8: mov             SP, fp
    //     0xde68ec: ldp             fp, lr, [SP], #0x10
    // 0xde68f0: ret
    //     0xde68f0: ret             
    // 0xde68f4: StoreField: r1->field_6b = r0
    //     0xde68f4: stur            w0, [x1, #0x6b]
    //     0xde68f8: ldurb           w16, [x1, #-1]
    //     0xde68fc: ldurb           w17, [x0, #-1]
    //     0xde6900: and             x16, x17, x16, lsr #2
    //     0xde6904: tst             x16, HEAP, lsr #32
    //     0xde6908: b.eq            #0xde6910
    //     0xde690c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xde6910: r0 = notifyListeners()
    //     0xde6910: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xde6914: r0 = Null
    //     0xde6914: mov             x0, NULL
    // 0xde6918: LeaveFrame
    //     0xde6918: mov             SP, fp
    //     0xde691c: ldp             fp, lr, [SP], #0x10
    // 0xde6920: ret
    //     0xde6920: ret             
    // 0xde6924: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde6924: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde6928: b               #0xde68d4
  }
  set _ fillColor=(/* No info */) {
    // ** addr: 0xde692c, size: 0xa4
    // 0xde692c: EnterFrame
    //     0xde692c: stp             fp, lr, [SP, #-0x10]!
    //     0xde6930: mov             fp, SP
    // 0xde6934: AllocStack(0x20)
    //     0xde6934: sub             SP, SP, #0x20
    // 0xde6938: SetupParameters(_RadioPainter this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xde6938: stur            x1, [fp, #-8]
    //     0xde693c: mov             x16, x2
    //     0xde6940: mov             x2, x1
    //     0xde6944: mov             x1, x16
    //     0xde6948: stur            x1, [fp, #-0x10]
    // 0xde694c: CheckStackOverflow
    //     0xde694c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde6950: cmp             SP, x16
    //     0xde6954: b.ls            #0xde69c8
    // 0xde6958: LoadField: r0 = r2->field_63
    //     0xde6958: ldur            w0, [x2, #0x63]
    // 0xde695c: DecompressPointer r0
    //     0xde695c: add             x0, x0, HEAP, lsl #32
    // 0xde6960: r3 = LoadClassIdInstr(r1)
    //     0xde6960: ldur            x3, [x1, #-1]
    //     0xde6964: ubfx            x3, x3, #0xc, #0x14
    // 0xde6968: stp             x0, x1, [SP]
    // 0xde696c: mov             x0, x3
    // 0xde6970: mov             lr, x0
    // 0xde6974: ldr             lr, [x21, lr, lsl #3]
    // 0xde6978: blr             lr
    // 0xde697c: tbnz            w0, #4, #0xde6990
    // 0xde6980: r0 = Null
    //     0xde6980: mov             x0, NULL
    // 0xde6984: LeaveFrame
    //     0xde6984: mov             SP, fp
    //     0xde6988: ldp             fp, lr, [SP], #0x10
    // 0xde698c: ret
    //     0xde698c: ret             
    // 0xde6990: ldur            x1, [fp, #-8]
    // 0xde6994: ldur            x0, [fp, #-0x10]
    // 0xde6998: StoreField: r1->field_63 = r0
    //     0xde6998: stur            w0, [x1, #0x63]
    //     0xde699c: ldurb           w16, [x1, #-1]
    //     0xde69a0: ldurb           w17, [x0, #-1]
    //     0xde69a4: and             x16, x17, x16, lsr #2
    //     0xde69a8: tst             x16, HEAP, lsr #32
    //     0xde69ac: b.eq            #0xde69b4
    //     0xde69b0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xde69b4: r0 = notifyListeners()
    //     0xde69b4: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xde69b8: r0 = Null
    //     0xde69b8: mov             x0, NULL
    // 0xde69bc: LeaveFrame
    //     0xde69bc: mov             SP, fp
    //     0xde69c0: ldp             fp, lr, [SP], #0x10
    // 0xde69c4: ret
    //     0xde69c4: ret             
    // 0xde69c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde69c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde69cc: b               #0xde6958
  }
}

// class id: 5486, size: 0x18, field offset: 0x14
class _RadioPaintState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0xde6454, size: 0x468
    // 0xde6454: EnterFrame
    //     0xde6454: stp             fp, lr, [SP, #-0x10]!
    //     0xde6458: mov             fp, SP
    // 0xde645c: AllocStack(0x50)
    //     0xde645c: sub             SP, SP, #0x50
    // 0xde6460: SetupParameters(_RadioPaintState this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xde6460: mov             x3, x1
    //     0xde6464: stur            x1, [fp, #-8]
    //     0xde6468: stur            x2, [fp, #-0x10]
    // 0xde646c: CheckStackOverflow
    //     0xde646c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde6470: cmp             SP, x16
    //     0xde6474: b.ls            #0xde6888
    // 0xde6478: LoadField: r0 = r3->field_b
    //     0xde6478: ldur            w0, [x3, #0xb]
    // 0xde647c: DecompressPointer r0
    //     0xde647c: add             x0, x0, HEAP, lsl #32
    // 0xde6480: cmp             w0, NULL
    // 0xde6484: b.eq            #0xde6890
    // 0xde6488: LoadField: r1 = r0->field_b
    //     0xde6488: ldur            w1, [x0, #0xb]
    // 0xde648c: DecompressPointer r1
    //     0xde648c: add             x1, x1, HEAP, lsl #32
    // 0xde6490: r0 = LoadClassIdInstr(r1)
    //     0xde6490: ldur            x0, [x1, #-1]
    //     0xde6494: ubfx            x0, x0, #0xc, #0x14
    // 0xde6498: r0 = GDT[cid_x0 + -0xc50]()
    //     0xde6498: sub             lr, x0, #0xc50
    //     0xde649c: ldr             lr, [x21, lr, lsl #3]
    //     0xde64a0: blr             lr
    // 0xde64a4: mov             x1, x0
    // 0xde64a8: r2 = Instance_WidgetState
    //     0xde64a8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xde64ac: ldr             x2, [x2, #0x100]
    // 0xde64b0: stur            x0, [fp, #-0x18]
    // 0xde64b4: r0 = add()
    //     0xde64b4: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xde64b8: ldur            x2, [fp, #-8]
    // 0xde64bc: LoadField: r0 = r2->field_b
    //     0xde64bc: ldur            w0, [x2, #0xb]
    // 0xde64c0: DecompressPointer r0
    //     0xde64c0: add             x0, x0, HEAP, lsl #32
    // 0xde64c4: cmp             w0, NULL
    // 0xde64c8: b.eq            #0xde6894
    // 0xde64cc: LoadField: r1 = r0->field_b
    //     0xde64cc: ldur            w1, [x0, #0xb]
    // 0xde64d0: DecompressPointer r1
    //     0xde64d0: add             x1, x1, HEAP, lsl #32
    // 0xde64d4: r0 = LoadClassIdInstr(r1)
    //     0xde64d4: ldur            x0, [x1, #-1]
    //     0xde64d8: ubfx            x0, x0, #0xc, #0x14
    // 0xde64dc: r0 = GDT[cid_x0 + -0xc50]()
    //     0xde64dc: sub             lr, x0, #0xc50
    //     0xde64e0: ldr             lr, [x21, lr, lsl #3]
    //     0xde64e4: blr             lr
    // 0xde64e8: mov             x1, x0
    // 0xde64ec: r2 = Instance_WidgetState
    //     0xde64ec: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xde64f0: ldr             x2, [x2, #0x100]
    // 0xde64f4: stur            x0, [fp, #-0x20]
    // 0xde64f8: r0 = remove()
    //     0xde64f8: bl              #0x115bfd0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::remove
    // 0xde64fc: ldur            x2, [fp, #-8]
    // 0xde6500: LoadField: r0 = r2->field_b
    //     0xde6500: ldur            w0, [x2, #0xb]
    // 0xde6504: DecompressPointer r0
    //     0xde6504: add             x0, x0, HEAP, lsl #32
    // 0xde6508: cmp             w0, NULL
    // 0xde650c: b.eq            #0xde6898
    // 0xde6510: LoadField: r1 = r0->field_b
    //     0xde6510: ldur            w1, [x0, #0xb]
    // 0xde6514: DecompressPointer r1
    //     0xde6514: add             x1, x1, HEAP, lsl #32
    // 0xde6518: r0 = LoadClassIdInstr(r1)
    //     0xde6518: ldur            x0, [x1, #-1]
    //     0xde651c: ubfx            x0, x0, #0xc, #0x14
    // 0xde6520: r0 = GDT[cid_x0 + -0xc50]()
    //     0xde6520: sub             lr, x0, #0xc50
    //     0xde6524: ldr             lr, [x21, lr, lsl #3]
    //     0xde6528: blr             lr
    // 0xde652c: ldur            x1, [fp, #-8]
    // 0xde6530: stur            x0, [fp, #-0x28]
    // 0xde6534: r0 = _defaultOuterColor()
    //     0xde6534: bl              #0xde6c10  ; [package:flutter/src/cupertino/radio.dart] _RadioPaintState::_defaultOuterColor
    // 0xde6538: mov             x1, x0
    // 0xde653c: ldur            x2, [fp, #-0x18]
    // 0xde6540: r0 = build()
    //     0xde6540: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xde6544: stur            x0, [fp, #-0x18]
    // 0xde6548: r1 = 1
    //     0xde6548: mov             x1, #1
    // 0xde654c: r0 = AllocateContext()
    //     0xde654c: bl              #0x13de838  ; AllocateContextStub
    // 0xde6550: mov             x1, x0
    // 0xde6554: ldur            x0, [fp, #-8]
    // 0xde6558: StoreField: r1->field_f = r0
    //     0xde6558: stur            w0, [x1, #0xf]
    // 0xde655c: mov             x2, x1
    // 0xde6560: r1 = Function '<anonymous closure>':.
    //     0xde6560: add             x1, PP, #0xd5, lsl #12  ; [pp+0xd5148] AnonymousClosure: (0xde6c78), in [package:flutter/src/cupertino/radio.dart] _RadioPaintState::_defaultOuterColor (0xde6c10)
    //     0xde6564: ldr             x1, [x1, #0x148]
    // 0xde6568: r0 = AllocateClosure()
    //     0xde6568: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xde656c: r16 = <Color>
    //     0xde656c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xde6570: ldr             x16, [x16, #0xa90]
    // 0xde6574: stp             x0, x16, [SP]
    // 0xde6578: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xde6578: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xde657c: r0 = resolveWith()
    //     0xde657c: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xde6580: mov             x1, x0
    // 0xde6584: ldur            x2, [fp, #-0x20]
    // 0xde6588: r0 = build()
    //     0xde6588: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xde658c: mov             x3, x0
    // 0xde6590: ldur            x2, [fp, #-8]
    // 0xde6594: stur            x3, [fp, #-0x20]
    // 0xde6598: LoadField: r0 = r2->field_b
    //     0xde6598: ldur            w0, [x2, #0xb]
    // 0xde659c: DecompressPointer r0
    //     0xde659c: add             x0, x0, HEAP, lsl #32
    // 0xde65a0: cmp             w0, NULL
    // 0xde65a4: b.eq            #0xde689c
    // 0xde65a8: ldur            x4, [fp, #-0x18]
    // 0xde65ac: r0 = LoadClassIdInstr(r4)
    //     0xde65ac: ldur            x0, [x4, #-1]
    //     0xde65b0: ubfx            x0, x0, #0xc, #0x14
    // 0xde65b4: mov             x1, x4
    // 0xde65b8: d0 = 0.800000
    //     0xde65b8: add             x17, PP, #0x13, lsl #12  ; [pp+0x13a58] IMM: double(0.8) from 0x3fe999999999999a
    //     0xde65bc: ldr             d0, [x17, #0xa58]
    // 0xde65c0: r0 = GDT[cid_x0 + -0x1000]()
    //     0xde65c0: sub             lr, x0, #1, lsl #12
    //     0xde65c4: ldr             lr, [x21, lr, lsl #3]
    //     0xde65c8: blr             lr
    // 0xde65cc: mov             x2, x0
    // 0xde65d0: r1 = Null
    //     0xde65d0: mov             x1, NULL
    // 0xde65d4: r0 = HSLColor.fromColor()
    //     0xde65d4: bl              #0xd43b8c  ; [package:flutter/src/painting/colors.dart] HSLColor::HSLColor.fromColor
    // 0xde65d8: mov             x1, x0
    // 0xde65dc: r0 = withLightness()
    //     0xde65dc: bl              #0xd43b34  ; [package:flutter/src/painting/colors.dart] HSLColor::withLightness
    // 0xde65e0: mov             x1, x0
    // 0xde65e4: r0 = withSaturation()
    //     0xde65e4: bl              #0xd43ad0  ; [package:flutter/src/painting/colors.dart] HSLColor::withSaturation
    // 0xde65e8: mov             x1, x0
    // 0xde65ec: r0 = toColor()
    //     0xde65ec: bl              #0xd43270  ; [package:flutter/src/painting/colors.dart] HSLColor::toColor
    // 0xde65f0: ldur            x1, [fp, #-8]
    // 0xde65f4: stur            x0, [fp, #-0x30]
    // 0xde65f8: r0 = _defaultInnerColor()
    //     0xde65f8: bl              #0xde6ba8  ; [package:flutter/src/cupertino/radio.dart] _RadioPaintState::_defaultInnerColor
    // 0xde65fc: mov             x1, x0
    // 0xde6600: ldur            x2, [fp, #-0x28]
    // 0xde6604: r0 = build()
    //     0xde6604: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xde6608: ldur            x1, [fp, #-8]
    // 0xde660c: stur            x0, [fp, #-0x38]
    // 0xde6610: r0 = _defaultBorderColor()
    //     0xde6610: bl              #0xde69d0  ; [package:flutter/src/cupertino/radio.dart] _RadioPaintState::_defaultBorderColor
    // 0xde6614: mov             x1, x0
    // 0xde6618: ldur            x2, [fp, #-0x28]
    // 0xde661c: r0 = build()
    //     0xde661c: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xde6620: mov             x3, x0
    // 0xde6624: ldur            x2, [fp, #-8]
    // 0xde6628: stur            x3, [fp, #-0x40]
    // 0xde662c: LoadField: r4 = r2->field_13
    //     0xde662c: ldur            w4, [x2, #0x13]
    // 0xde6630: DecompressPointer r4
    //     0xde6630: add             x4, x4, HEAP, lsl #32
    // 0xde6634: stur            x4, [fp, #-0x28]
    // 0xde6638: LoadField: r0 = r2->field_b
    //     0xde6638: ldur            w0, [x2, #0xb]
    // 0xde663c: DecompressPointer r0
    //     0xde663c: add             x0, x0, HEAP, lsl #32
    // 0xde6640: cmp             w0, NULL
    // 0xde6644: b.eq            #0xde68a0
    // 0xde6648: LoadField: r1 = r0->field_b
    //     0xde6648: ldur            w1, [x0, #0xb]
    // 0xde664c: DecompressPointer r1
    //     0xde664c: add             x1, x1, HEAP, lsl #32
    // 0xde6650: r0 = LoadClassIdInstr(r1)
    //     0xde6650: ldur            x0, [x1, #-1]
    //     0xde6654: ubfx            x0, x0, #0xc, #0x14
    // 0xde6658: r0 = GDT[cid_x0 + 0xec4]()
    //     0xde6658: add             lr, x0, #0xec4
    //     0xde665c: ldr             lr, [x21, lr, lsl #3]
    //     0xde6660: blr             lr
    // 0xde6664: ldur            x1, [fp, #-0x28]
    // 0xde6668: mov             x2, x0
    // 0xde666c: r0 = position=()
    //     0xde666c: bl              #0xd131b8  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::position=
    // 0xde6670: ldur            x2, [fp, #-8]
    // 0xde6674: LoadField: r0 = r2->field_b
    //     0xde6674: ldur            w0, [x2, #0xb]
    // 0xde6678: DecompressPointer r0
    //     0xde6678: add             x0, x0, HEAP, lsl #32
    // 0xde667c: cmp             w0, NULL
    // 0xde6680: b.eq            #0xde68a4
    // 0xde6684: LoadField: r1 = r0->field_b
    //     0xde6684: ldur            w1, [x0, #0xb]
    // 0xde6688: DecompressPointer r1
    //     0xde6688: add             x1, x1, HEAP, lsl #32
    // 0xde668c: r0 = LoadClassIdInstr(r1)
    //     0xde668c: ldur            x0, [x1, #-1]
    //     0xde6690: ubfx            x0, x0, #0xc, #0x14
    // 0xde6694: r0 = GDT[cid_x0 + 0xd20]()
    //     0xde6694: add             lr, x0, #0xd20
    //     0xde6698: ldr             lr, [x21, lr, lsl #3]
    //     0xde669c: blr             lr
    // 0xde66a0: ldur            x1, [fp, #-0x28]
    // 0xde66a4: mov             x2, x0
    // 0xde66a8: r0 = reaction=()
    //     0xde66a8: bl              #0xd130e8  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::reaction=
    // 0xde66ac: ldur            x1, [fp, #-0x28]
    // 0xde66b0: ldur            x2, [fp, #-0x30]
    // 0xde66b4: r0 = focusColor=()
    //     0xde66b4: bl              #0xd12cb8  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::focusColor=
    // 0xde66b8: ldur            x2, [fp, #-8]
    // 0xde66bc: LoadField: r0 = r2->field_b
    //     0xde66bc: ldur            w0, [x2, #0xb]
    // 0xde66c0: DecompressPointer r0
    //     0xde66c0: add             x0, x0, HEAP, lsl #32
    // 0xde66c4: cmp             w0, NULL
    // 0xde66c8: b.eq            #0xde68a8
    // 0xde66cc: LoadField: r1 = r0->field_b
    //     0xde66cc: ldur            w1, [x0, #0xb]
    // 0xde66d0: DecompressPointer r1
    //     0xde66d0: add             x1, x1, HEAP, lsl #32
    // 0xde66d4: r0 = LoadClassIdInstr(r1)
    //     0xde66d4: ldur            x0, [x1, #-1]
    //     0xde66d8: ubfx            x0, x0, #0xc, #0x14
    // 0xde66dc: r0 = GDT[cid_x0 + 0x4f2]()
    //     0xde66dc: add             lr, x0, #0x4f2
    //     0xde66e0: ldr             lr, [x21, lr, lsl #3]
    //     0xde66e4: blr             lr
    // 0xde66e8: ldur            x1, [fp, #-0x28]
    // 0xde66ec: mov             x2, x0
    // 0xde66f0: r0 = downPosition=()
    //     0xde66f0: bl              #0xd12b48  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::downPosition=
    // 0xde66f4: ldur            x0, [fp, #-8]
    // 0xde66f8: LoadField: r1 = r0->field_b
    //     0xde66f8: ldur            w1, [x0, #0xb]
    // 0xde66fc: DecompressPointer r1
    //     0xde66fc: add             x1, x1, HEAP, lsl #32
    // 0xde6700: cmp             w1, NULL
    // 0xde6704: b.eq            #0xde68ac
    // 0xde6708: LoadField: r2 = r1->field_27
    //     0xde6708: ldur            w2, [x1, #0x27]
    // 0xde670c: DecompressPointer r2
    //     0xde670c: add             x2, x2, HEAP, lsl #32
    // 0xde6710: ldur            x3, [fp, #-0x28]
    // 0xde6714: LoadField: r1 = r3->field_53
    //     0xde6714: ldur            w1, [x3, #0x53]
    // 0xde6718: DecompressPointer r1
    //     0xde6718: add             x1, x1, HEAP, lsl #32
    // 0xde671c: cmp             w2, w1
    // 0xde6720: b.eq            #0xde6738
    // 0xde6724: StoreField: r3->field_53 = r2
    //     0xde6724: stur            w2, [x3, #0x53]
    // 0xde6728: mov             x1, x3
    // 0xde672c: r0 = notifyListeners()
    //     0xde672c: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xde6730: ldur            x0, [fp, #-8]
    // 0xde6734: ldur            x3, [fp, #-0x28]
    // 0xde6738: mov             x1, x3
    // 0xde673c: ldur            x2, [fp, #-0x18]
    // 0xde6740: r0 = activeColor=()
    //     0xde6740: bl              #0xd129fc  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::activeColor=
    // 0xde6744: ldur            x1, [fp, #-0x28]
    // 0xde6748: ldur            x2, [fp, #-0x20]
    // 0xde674c: r0 = inactiveColor=()
    //     0xde674c: bl              #0xcf0d78  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::inactiveColor=
    // 0xde6750: ldur            x1, [fp, #-0x28]
    // 0xde6754: ldur            x2, [fp, #-0x38]
    // 0xde6758: r0 = fillColor=()
    //     0xde6758: bl              #0xde692c  ; [package:flutter/src/cupertino/radio.dart] _RadioPainter::fillColor=
    // 0xde675c: ldur            x2, [fp, #-8]
    // 0xde6760: LoadField: r0 = r2->field_b
    //     0xde6760: ldur            w0, [x2, #0xb]
    // 0xde6764: DecompressPointer r0
    //     0xde6764: add             x0, x0, HEAP, lsl #32
    // 0xde6768: cmp             w0, NULL
    // 0xde676c: b.eq            #0xde68b0
    // 0xde6770: LoadField: r1 = r0->field_b
    //     0xde6770: ldur            w1, [x0, #0xb]
    // 0xde6774: DecompressPointer r1
    //     0xde6774: add             x1, x1, HEAP, lsl #32
    // 0xde6778: r0 = LoadClassIdInstr(r1)
    //     0xde6778: ldur            x0, [x1, #-1]
    //     0xde677c: ubfx            x0, x0, #0xc, #0x14
    // 0xde6780: r0 = GDT[cid_x0 + 0x1e94]()
    //     0xde6780: mov             x17, #0x1e94
    //     0xde6784: add             lr, x0, x17
    //     0xde6788: ldr             lr, [x21, lr, lsl #3]
    //     0xde678c: blr             lr
    // 0xde6790: ldur            x1, [fp, #-0x28]
    // 0xde6794: mov             x2, x0
    // 0xde6798: r0 = value=()
    //     0xde6798: bl              #0xb6aae0  ; [package:flutter/src/cupertino/radio.dart] _RadioPainter::value=
    // 0xde679c: ldur            x0, [fp, #-8]
    // 0xde67a0: LoadField: r1 = r0->field_b
    //     0xde67a0: ldur            w1, [x0, #0xb]
    // 0xde67a4: DecompressPointer r1
    //     0xde67a4: add             x1, x1, HEAP, lsl #32
    // 0xde67a8: cmp             w1, NULL
    // 0xde67ac: b.eq            #0xde68b4
    // 0xde67b0: ldur            x1, [fp, #-0x28]
    // 0xde67b4: r2 = false
    //     0xde67b4: add             x2, NULL, #0x30  ; false
    // 0xde67b8: r0 = Shader._()
    //     0xde67b8: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xde67bc: ldur            x0, [fp, #-8]
    // 0xde67c0: LoadField: r1 = r0->field_b
    //     0xde67c0: ldur            w1, [x0, #0xb]
    // 0xde67c4: DecompressPointer r1
    //     0xde67c4: add             x1, x1, HEAP, lsl #32
    // 0xde67c8: cmp             w1, NULL
    // 0xde67cc: b.eq            #0xde68b8
    // 0xde67d0: LoadField: r0 = r1->field_23
    //     0xde67d0: ldur            w0, [x1, #0x23]
    // 0xde67d4: DecompressPointer r0
    //     0xde67d4: add             x0, x0, HEAP, lsl #32
    // 0xde67d8: ldur            x2, [fp, #-0x28]
    // 0xde67dc: LoadField: r1 = r2->field_5b
    //     0xde67dc: ldur            w1, [x2, #0x5b]
    // 0xde67e0: DecompressPointer r1
    //     0xde67e0: add             x1, x1, HEAP, lsl #32
    // 0xde67e4: cmp             w0, w1
    // 0xde67e8: b.eq            #0xde67f8
    // 0xde67ec: StoreField: r2->field_5b = r0
    //     0xde67ec: stur            w0, [x2, #0x5b]
    // 0xde67f0: mov             x1, x2
    // 0xde67f4: r0 = notifyListeners()
    //     0xde67f4: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xde67f8: ldur            x1, [fp, #-0x28]
    // 0xde67fc: ldur            x2, [fp, #-0x40]
    // 0xde6800: r0 = activeSide=()
    //     0xde6800: bl              #0xd127bc  ; [package:flutter/src/material/checkbox.dart] _CheckboxPainter::activeSide=
    // 0xde6804: ldur            x1, [fp, #-0x10]
    // 0xde6808: r0 = of()
    //     0xde6808: bl              #0xccc364  ; [package:flutter/src/cupertino/theme.dart] CupertinoTheme::of
    // 0xde680c: r1 = LoadClassIdInstr(r0)
    //     0xde680c: ldur            x1, [x0, #-1]
    //     0xde6810: ubfx            x1, x1, #0xc, #0x14
    // 0xde6814: r17 = 4617
    //     0xde6814: mov             x17, #0x1209
    // 0xde6818: cmp             x1, x17
    // 0xde681c: b.ne            #0xde6830
    // 0xde6820: LoadField: r1 = r0->field_7
    //     0xde6820: ldur            w1, [x0, #7]
    // 0xde6824: DecompressPointer r1
    //     0xde6824: add             x1, x1, HEAP, lsl #32
    // 0xde6828: mov             x2, x1
    // 0xde682c: b               #0xde684c
    // 0xde6830: LoadField: r1 = r0->field_2b
    //     0xde6830: ldur            w1, [x0, #0x2b]
    // 0xde6834: DecompressPointer r1
    //     0xde6834: add             x1, x1, HEAP, lsl #32
    // 0xde6838: LoadField: r0 = r1->field_3f
    //     0xde6838: ldur            w0, [x1, #0x3f]
    // 0xde683c: DecompressPointer r0
    //     0xde683c: add             x0, x0, HEAP, lsl #32
    // 0xde6840: LoadField: r1 = r0->field_7
    //     0xde6840: ldur            w1, [x0, #7]
    // 0xde6844: DecompressPointer r1
    //     0xde6844: add             x1, x1, HEAP, lsl #32
    // 0xde6848: mov             x2, x1
    // 0xde684c: ldur            x0, [fp, #-0x28]
    // 0xde6850: mov             x1, x0
    // 0xde6854: r0 = brightness=()
    //     0xde6854: bl              #0xde68bc  ; [package:flutter/src/cupertino/radio.dart] _RadioPainter::brightness=
    // 0xde6858: r0 = CustomPaint()
    //     0xde6858: bl              #0xd0a594  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0xde685c: ldur            x1, [fp, #-0x28]
    // 0xde6860: StoreField: r0->field_f = r1
    //     0xde6860: stur            w1, [x0, #0xf]
    // 0xde6864: r1 = Instance_Size
    //     0xde6864: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa4098] Obj!Size@12a7571
    //     0xde6868: ldr             x1, [x1, #0x98]
    // 0xde686c: ArrayStore: r0[0] = r1  ; List_4
    //     0xde686c: stur            w1, [x0, #0x17]
    // 0xde6870: r1 = false
    //     0xde6870: add             x1, NULL, #0x30  ; false
    // 0xde6874: StoreField: r0->field_1b = r1
    //     0xde6874: stur            w1, [x0, #0x1b]
    // 0xde6878: StoreField: r0->field_1f = r1
    //     0xde6878: stur            w1, [x0, #0x1f]
    // 0xde687c: LeaveFrame
    //     0xde687c: mov             SP, fp
    //     0xde6880: ldp             fp, lr, [SP], #0x10
    // 0xde6884: ret
    //     0xde6884: ret             
    // 0xde6888: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde6888: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde688c: b               #0xde6478
    // 0xde6890: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde6890: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde6894: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde6894: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde6898: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde6898: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde689c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde689c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde68a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde68a0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde68a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde68a4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde68a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde68a8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde68ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde68ac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde68b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde68b0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde68b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde68b4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde68b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde68b8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _defaultBorderColor(/* No info */) {
    // ** addr: 0xde69d0, size: 0x68
    // 0xde69d0: EnterFrame
    //     0xde69d0: stp             fp, lr, [SP, #-0x10]!
    //     0xde69d4: mov             fp, SP
    // 0xde69d8: AllocStack(0x18)
    //     0xde69d8: sub             SP, SP, #0x18
    // 0xde69dc: SetupParameters(_RadioPaintState this /* r1 => r1, fp-0x8 */)
    //     0xde69dc: stur            x1, [fp, #-8]
    // 0xde69e0: CheckStackOverflow
    //     0xde69e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde69e4: cmp             SP, x16
    //     0xde69e8: b.ls            #0xde6a30
    // 0xde69ec: r1 = 1
    //     0xde69ec: mov             x1, #1
    // 0xde69f0: r0 = AllocateContext()
    //     0xde69f0: bl              #0x13de838  ; AllocateContextStub
    // 0xde69f4: mov             x1, x0
    // 0xde69f8: ldur            x0, [fp, #-8]
    // 0xde69fc: StoreField: r1->field_f = r0
    //     0xde69fc: stur            w0, [x1, #0xf]
    // 0xde6a00: mov             x2, x1
    // 0xde6a04: r1 = Function '<anonymous closure>':.
    //     0xde6a04: add             x1, PP, #0xd5, lsl #12  ; [pp+0xd5158] AnonymousClosure: (0xde6a38), in [package:flutter/src/cupertino/radio.dart] _RadioPaintState::_defaultBorderColor (0xde69d0)
    //     0xde6a08: ldr             x1, [x1, #0x158]
    // 0xde6a0c: r0 = AllocateClosure()
    //     0xde6a0c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xde6a10: r16 = <Color>
    //     0xde6a10: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xde6a14: ldr             x16, [x16, #0xa90]
    // 0xde6a18: stp             x0, x16, [SP]
    // 0xde6a1c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xde6a1c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xde6a20: r0 = resolveWith()
    //     0xde6a20: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xde6a24: LeaveFrame
    //     0xde6a24: mov             SP, fp
    //     0xde6a28: ldp             fp, lr, [SP], #0x10
    // 0xde6a2c: ret
    //     0xde6a2c: ret             
    // 0xde6a30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde6a30: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde6a34: b               #0xde69ec
  }
  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xde6a38, size: 0x170
    // 0xde6a38: EnterFrame
    //     0xde6a38: stp             fp, lr, [SP, #-0x10]!
    //     0xde6a3c: mov             fp, SP
    // 0xde6a40: AllocStack(0x8)
    //     0xde6a40: sub             SP, SP, #8
    // 0xde6a44: SetupParameters([dynamic _ /* r0 */])
    //     0xde6a44: ldr             x0, [fp, #0x18]
    //     0xde6a48: ldur            w3, [x0, #0x17]
    //     0xde6a4c: add             x3, x3, HEAP, lsl #32
    //     0xde6a50: stur            x3, [fp, #-8]
    // 0xde6a54: CheckStackOverflow
    //     0xde6a54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde6a58: cmp             SP, x16
    //     0xde6a5c: b.ls            #0xde6b98
    // 0xde6a60: ldr             x4, [fp, #0x10]
    // 0xde6a64: r0 = LoadClassIdInstr(r4)
    //     0xde6a64: ldur            x0, [x4, #-1]
    //     0xde6a68: ubfx            x0, x0, #0xc, #0x14
    // 0xde6a6c: mov             x1, x4
    // 0xde6a70: r2 = Instance_WidgetState
    //     0xde6a70: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xde6a74: ldr             x2, [x2, #0x100]
    // 0xde6a78: r0 = GDT[cid_x0 + 0x12929]()
    //     0xde6a78: mov             x17, #0x2929
    //     0xde6a7c: movk            x17, #1, lsl #16
    //     0xde6a80: add             lr, x0, x17
    //     0xde6a84: ldr             lr, [x21, lr, lsl #3]
    //     0xde6a88: blr             lr
    // 0xde6a8c: tbz             w0, #4, #0xde6ac0
    // 0xde6a90: ldr             x3, [fp, #0x10]
    // 0xde6a94: r0 = LoadClassIdInstr(r3)
    //     0xde6a94: ldur            x0, [x3, #-1]
    //     0xde6a98: ubfx            x0, x0, #0xc, #0x14
    // 0xde6a9c: mov             x1, x3
    // 0xde6aa0: r2 = Instance_WidgetState
    //     0xde6aa0: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xde6aa4: ldr             x2, [x2, #0xa60]
    // 0xde6aa8: r0 = GDT[cid_x0 + 0x12929]()
    //     0xde6aa8: mov             x17, #0x2929
    //     0xde6aac: movk            x17, #1, lsl #16
    //     0xde6ab0: add             lr, x0, x17
    //     0xde6ab4: ldr             lr, [x21, lr, lsl #3]
    //     0xde6ab8: blr             lr
    // 0xde6abc: tbnz            w0, #4, #0xde6b04
    // 0xde6ac0: ldr             x3, [fp, #0x10]
    // 0xde6ac4: r0 = LoadClassIdInstr(r3)
    //     0xde6ac4: ldur            x0, [x3, #-1]
    //     0xde6ac8: ubfx            x0, x0, #0xc, #0x14
    // 0xde6acc: mov             x1, x3
    // 0xde6ad0: r2 = Instance_WidgetState
    //     0xde6ad0: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xde6ad4: ldr             x2, [x2, #0xa70]
    // 0xde6ad8: r0 = GDT[cid_x0 + 0x12929]()
    //     0xde6ad8: mov             x17, #0x2929
    //     0xde6adc: movk            x17, #1, lsl #16
    //     0xde6ae0: add             lr, x0, x17
    //     0xde6ae4: ldr             lr, [x21, lr, lsl #3]
    //     0xde6ae8: blr             lr
    // 0xde6aec: tbz             w0, #4, #0xde6b04
    // 0xde6af0: r0 = Instance_Color
    //     0xde6af0: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xde6af4: ldr             x0, [x0, #0x810]
    // 0xde6af8: LeaveFrame
    //     0xde6af8: mov             SP, fp
    //     0xde6afc: ldp             fp, lr, [SP], #0x10
    // 0xde6b00: ret
    //     0xde6b00: ret             
    // 0xde6b04: ldr             x1, [fp, #0x10]
    // 0xde6b08: r0 = LoadClassIdInstr(r1)
    //     0xde6b08: ldur            x0, [x1, #-1]
    //     0xde6b0c: ubfx            x0, x0, #0xc, #0x14
    // 0xde6b10: r2 = Instance_WidgetState
    //     0xde6b10: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xde6b14: ldr             x2, [x2, #0xa70]
    // 0xde6b18: r0 = GDT[cid_x0 + 0x12929]()
    //     0xde6b18: mov             x17, #0x2929
    //     0xde6b1c: movk            x17, #1, lsl #16
    //     0xde6b20: add             lr, x0, x17
    //     0xde6b24: ldr             lr, [x21, lr, lsl #3]
    //     0xde6b28: blr             lr
    // 0xde6b2c: tbnz            w0, #4, #0xde6b64
    // 0xde6b30: ldur            x0, [fp, #-8]
    // 0xde6b34: LoadField: r1 = r0->field_f
    //     0xde6b34: ldur            w1, [x0, #0xf]
    // 0xde6b38: DecompressPointer r1
    //     0xde6b38: add             x1, x1, HEAP, lsl #32
    // 0xde6b3c: LoadField: r2 = r1->field_f
    //     0xde6b3c: ldur            w2, [x1, #0xf]
    // 0xde6b40: DecompressPointer r2
    //     0xde6b40: add             x2, x2, HEAP, lsl #32
    // 0xde6b44: cmp             w2, NULL
    // 0xde6b48: b.eq            #0xde6ba0
    // 0xde6b4c: r1 = Instance_CupertinoDynamicColor
    //     0xde6b4c: add             x1, PP, #0xd5, lsl #12  ; [pp+0xd5160] Obj!CupertinoDynamicColor@12b3db1
    //     0xde6b50: ldr             x1, [x1, #0x160]
    // 0xde6b54: r0 = resolveFrom()
    //     0xde6b54: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0xde6b58: LeaveFrame
    //     0xde6b58: mov             SP, fp
    //     0xde6b5c: ldp             fp, lr, [SP], #0x10
    // 0xde6b60: ret
    //     0xde6b60: ret             
    // 0xde6b64: ldur            x0, [fp, #-8]
    // 0xde6b68: LoadField: r1 = r0->field_f
    //     0xde6b68: ldur            w1, [x0, #0xf]
    // 0xde6b6c: DecompressPointer r1
    //     0xde6b6c: add             x1, x1, HEAP, lsl #32
    // 0xde6b70: LoadField: r2 = r1->field_f
    //     0xde6b70: ldur            w2, [x1, #0xf]
    // 0xde6b74: DecompressPointer r2
    //     0xde6b74: add             x2, x2, HEAP, lsl #32
    // 0xde6b78: cmp             w2, NULL
    // 0xde6b7c: b.eq            #0xde6ba4
    // 0xde6b80: r1 = Instance_CupertinoDynamicColor
    //     0xde6b80: add             x1, PP, #0xd5, lsl #12  ; [pp+0xd5168] Obj!CupertinoDynamicColor@12b3d71
    //     0xde6b84: ldr             x1, [x1, #0x168]
    // 0xde6b88: r0 = resolveFrom()
    //     0xde6b88: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0xde6b8c: LeaveFrame
    //     0xde6b8c: mov             SP, fp
    //     0xde6b90: ldp             fp, lr, [SP], #0x10
    // 0xde6b94: ret
    //     0xde6b94: ret             
    // 0xde6b98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde6b98: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde6b9c: b               #0xde6a60
    // 0xde6ba0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde6ba0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde6ba4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde6ba4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _defaultInnerColor(/* No info */) {
    // ** addr: 0xde6ba8, size: 0x68
    // 0xde6ba8: EnterFrame
    //     0xde6ba8: stp             fp, lr, [SP, #-0x10]!
    //     0xde6bac: mov             fp, SP
    // 0xde6bb0: AllocStack(0x18)
    //     0xde6bb0: sub             SP, SP, #0x18
    // 0xde6bb4: SetupParameters(_RadioPaintState this /* r1 => r1, fp-0x8 */)
    //     0xde6bb4: stur            x1, [fp, #-8]
    // 0xde6bb8: CheckStackOverflow
    //     0xde6bb8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde6bbc: cmp             SP, x16
    //     0xde6bc0: b.ls            #0xde6c08
    // 0xde6bc4: r1 = 1
    //     0xde6bc4: mov             x1, #1
    // 0xde6bc8: r0 = AllocateContext()
    //     0xde6bc8: bl              #0x13de838  ; AllocateContextStub
    // 0xde6bcc: mov             x1, x0
    // 0xde6bd0: ldur            x0, [fp, #-8]
    // 0xde6bd4: StoreField: r1->field_f = r0
    //     0xde6bd4: stur            w0, [x1, #0xf]
    // 0xde6bd8: mov             x2, x1
    // 0xde6bdc: r1 = Function '<anonymous closure>':.
    //     0xde6bdc: add             x1, PP, #0xd5, lsl #12  ; [pp+0xd5170] AnonymousClosure: (0xd769c8), in [package:flutter/src/cupertino/checkbox.dart] _CupertinoCheckboxState::_defaultCheckColor (0xd76960)
    //     0xde6be0: ldr             x1, [x1, #0x170]
    // 0xde6be4: r0 = AllocateClosure()
    //     0xde6be4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xde6be8: r16 = <Color>
    //     0xde6be8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xde6bec: ldr             x16, [x16, #0xa90]
    // 0xde6bf0: stp             x0, x16, [SP]
    // 0xde6bf4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xde6bf4: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xde6bf8: r0 = resolveWith()
    //     0xde6bf8: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xde6bfc: LeaveFrame
    //     0xde6bfc: mov             SP, fp
    //     0xde6c00: ldp             fp, lr, [SP], #0x10
    // 0xde6c04: ret
    //     0xde6c04: ret             
    // 0xde6c08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde6c08: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde6c0c: b               #0xde6bc4
  }
  get _ _defaultOuterColor(/* No info */) {
    // ** addr: 0xde6c10, size: 0x68
    // 0xde6c10: EnterFrame
    //     0xde6c10: stp             fp, lr, [SP, #-0x10]!
    //     0xde6c14: mov             fp, SP
    // 0xde6c18: AllocStack(0x18)
    //     0xde6c18: sub             SP, SP, #0x18
    // 0xde6c1c: SetupParameters(_RadioPaintState this /* r1 => r1, fp-0x8 */)
    //     0xde6c1c: stur            x1, [fp, #-8]
    // 0xde6c20: CheckStackOverflow
    //     0xde6c20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde6c24: cmp             SP, x16
    //     0xde6c28: b.ls            #0xde6c70
    // 0xde6c2c: r1 = 1
    //     0xde6c2c: mov             x1, #1
    // 0xde6c30: r0 = AllocateContext()
    //     0xde6c30: bl              #0x13de838  ; AllocateContextStub
    // 0xde6c34: mov             x1, x0
    // 0xde6c38: ldur            x0, [fp, #-8]
    // 0xde6c3c: StoreField: r1->field_f = r0
    //     0xde6c3c: stur            w0, [x1, #0xf]
    // 0xde6c40: mov             x2, x1
    // 0xde6c44: r1 = Function '<anonymous closure>':.
    //     0xde6c44: add             x1, PP, #0xd5, lsl #12  ; [pp+0xd5148] AnonymousClosure: (0xde6c78), in [package:flutter/src/cupertino/radio.dart] _RadioPaintState::_defaultOuterColor (0xde6c10)
    //     0xde6c48: ldr             x1, [x1, #0x148]
    // 0xde6c4c: r0 = AllocateClosure()
    //     0xde6c4c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xde6c50: r16 = <Color>
    //     0xde6c50: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xde6c54: ldr             x16, [x16, #0xa90]
    // 0xde6c58: stp             x0, x16, [SP]
    // 0xde6c5c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xde6c5c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xde6c60: r0 = resolveWith()
    //     0xde6c60: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xde6c64: LeaveFrame
    //     0xde6c64: mov             SP, fp
    //     0xde6c68: ldp             fp, lr, [SP], #0x10
    // 0xde6c6c: ret
    //     0xde6c6c: ret             
    // 0xde6c70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde6c70: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde6c74: b               #0xde6c2c
  }
  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xde6c78, size: 0x160
    // 0xde6c78: EnterFrame
    //     0xde6c78: stp             fp, lr, [SP, #-0x10]!
    //     0xde6c7c: mov             fp, SP
    // 0xde6c80: AllocStack(0x8)
    //     0xde6c80: sub             SP, SP, #8
    // 0xde6c84: SetupParameters([dynamic _ /* r0 */])
    //     0xde6c84: ldr             x0, [fp, #0x18]
    //     0xde6c88: ldur            w3, [x0, #0x17]
    //     0xde6c8c: add             x3, x3, HEAP, lsl #32
    //     0xde6c90: stur            x3, [fp, #-8]
    // 0xde6c94: CheckStackOverflow
    //     0xde6c94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde6c98: cmp             SP, x16
    //     0xde6c9c: b.ls            #0xde6dc0
    // 0xde6ca0: ldr             x4, [fp, #0x10]
    // 0xde6ca4: r0 = LoadClassIdInstr(r4)
    //     0xde6ca4: ldur            x0, [x4, #-1]
    //     0xde6ca8: ubfx            x0, x0, #0xc, #0x14
    // 0xde6cac: mov             x1, x4
    // 0xde6cb0: r2 = Instance_WidgetState
    //     0xde6cb0: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xde6cb4: ldr             x2, [x2, #0xa70]
    // 0xde6cb8: r0 = GDT[cid_x0 + 0x12929]()
    //     0xde6cb8: mov             x17, #0x2929
    //     0xde6cbc: movk            x17, #1, lsl #16
    //     0xde6cc0: add             lr, x0, x17
    //     0xde6cc4: ldr             lr, [x21, lr, lsl #3]
    //     0xde6cc8: blr             lr
    // 0xde6ccc: tbnz            w0, #4, #0xde6d1c
    // 0xde6cd0: ldur            x0, [fp, #-8]
    // 0xde6cd4: r0 = LoadStaticField(0xce8)
    //     0xde6cd4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xde6cd8: ldr             x0, [x0, #0x19d0]
    // 0xde6cdc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xde6ce0: cmp             w0, w16
    // 0xde6ce4: b.ne            #0xde6cf4
    // 0xde6ce8: r2 = _kDisabledOuterColor
    //     0xde6ce8: add             x2, PP, #0xd5, lsl #12  ; [pp+0xd5150] Field <::._kDisabledOuterColor@811254404>: static late final (offset: 0xce8)
    //     0xde6cec: ldr             x2, [x2, #0x150]
    // 0xde6cf0: r0 = InitLateFinalStaticField()
    //     0xde6cf0: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xde6cf4: ldur            x3, [fp, #-8]
    // 0xde6cf8: LoadField: r1 = r3->field_f
    //     0xde6cf8: ldur            w1, [x3, #0xf]
    // 0xde6cfc: DecompressPointer r1
    //     0xde6cfc: add             x1, x1, HEAP, lsl #32
    // 0xde6d00: LoadField: r2 = r1->field_f
    //     0xde6d00: ldur            w2, [x1, #0xf]
    // 0xde6d04: DecompressPointer r2
    //     0xde6d04: add             x2, x2, HEAP, lsl #32
    // 0xde6d08: cmp             w2, NULL
    // 0xde6d0c: b.eq            #0xde6dc8
    // 0xde6d10: LeaveFrame
    //     0xde6d10: mov             SP, fp
    //     0xde6d14: ldp             fp, lr, [SP], #0x10
    // 0xde6d18: ret
    //     0xde6d18: ret             
    // 0xde6d1c: ldr             x1, [fp, #0x10]
    // 0xde6d20: ldur            x3, [fp, #-8]
    // 0xde6d24: r0 = LoadClassIdInstr(r1)
    //     0xde6d24: ldur            x0, [x1, #-1]
    //     0xde6d28: ubfx            x0, x0, #0xc, #0x14
    // 0xde6d2c: r2 = Instance_WidgetState
    //     0xde6d2c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xde6d30: ldr             x2, [x2, #0x100]
    // 0xde6d34: r0 = GDT[cid_x0 + 0x12929]()
    //     0xde6d34: mov             x17, #0x2929
    //     0xde6d38: movk            x17, #1, lsl #16
    //     0xde6d3c: add             lr, x0, x17
    //     0xde6d40: ldr             lr, [x21, lr, lsl #3]
    //     0xde6d44: blr             lr
    // 0xde6d48: tbnz            w0, #4, #0xde6d90
    // 0xde6d4c: ldur            x0, [fp, #-8]
    // 0xde6d50: LoadField: r1 = r0->field_f
    //     0xde6d50: ldur            w1, [x0, #0xf]
    // 0xde6d54: DecompressPointer r1
    //     0xde6d54: add             x1, x1, HEAP, lsl #32
    // 0xde6d58: LoadField: r0 = r1->field_b
    //     0xde6d58: ldur            w0, [x1, #0xb]
    // 0xde6d5c: DecompressPointer r0
    //     0xde6d5c: add             x0, x0, HEAP, lsl #32
    // 0xde6d60: cmp             w0, NULL
    // 0xde6d64: b.eq            #0xde6dcc
    // 0xde6d68: LoadField: r2 = r1->field_f
    //     0xde6d68: ldur            w2, [x1, #0xf]
    // 0xde6d6c: DecompressPointer r2
    //     0xde6d6c: add             x2, x2, HEAP, lsl #32
    // 0xde6d70: cmp             w2, NULL
    // 0xde6d74: b.eq            #0xde6dd0
    // 0xde6d78: r1 = Instance_CupertinoDynamicColor
    //     0xde6d78: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2b30] Obj!CupertinoDynamicColor@12b3a31
    //     0xde6d7c: ldr             x1, [x1, #0xb30]
    // 0xde6d80: r0 = resolveFrom()
    //     0xde6d80: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0xde6d84: LeaveFrame
    //     0xde6d84: mov             SP, fp
    //     0xde6d88: ldp             fp, lr, [SP], #0x10
    // 0xde6d8c: ret
    //     0xde6d8c: ret             
    // 0xde6d90: ldur            x0, [fp, #-8]
    // 0xde6d94: LoadField: r1 = r0->field_f
    //     0xde6d94: ldur            w1, [x0, #0xf]
    // 0xde6d98: DecompressPointer r1
    //     0xde6d98: add             x1, x1, HEAP, lsl #32
    // 0xde6d9c: LoadField: r2 = r1->field_b
    //     0xde6d9c: ldur            w2, [x1, #0xb]
    // 0xde6da0: DecompressPointer r2
    //     0xde6da0: add             x2, x2, HEAP, lsl #32
    // 0xde6da4: cmp             w2, NULL
    // 0xde6da8: b.eq            #0xde6dd4
    // 0xde6dac: r0 = Instance_Color
    //     0xde6dac: add             x0, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0xde6db0: ldr             x0, [x0, #0xc38]
    // 0xde6db4: LeaveFrame
    //     0xde6db4: mov             SP, fp
    //     0xde6db8: ldp             fp, lr, [SP], #0x10
    // 0xde6dbc: ret
    //     0xde6dbc: ret             
    // 0xde6dc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde6dc0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde6dc4: b               #0xde6ca0
    // 0xde6dc8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde6dc8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde6dcc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde6dcc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde6dd0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde6dd0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde6dd4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde6dd4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _RadioPaintState(/* No info */) {
    // ** addr: 0xfa05ec, size: 0x9c
    // 0xfa05ec: EnterFrame
    //     0xfa05ec: stp             fp, lr, [SP, #-0x10]!
    //     0xfa05f0: mov             fp, SP
    // 0xfa05f4: AllocStack(0x10)
    //     0xfa05f4: sub             SP, SP, #0x10
    // 0xfa05f8: SetupParameters(_RadioPaintState this /* r1 => r1, fp-0x8 */)
    //     0xfa05f8: stur            x1, [fp, #-8]
    // 0xfa05fc: CheckStackOverflow
    //     0xfa05fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa0600: cmp             SP, x16
    //     0xfa0604: b.ls            #0xfa0680
    // 0xfa0608: r0 = _RadioPainter()
    //     0xfa0608: bl              #0xfa0688  ; Allocate_RadioPainterStub -> _RadioPainter (size=0x74)
    // 0xfa060c: mov             x1, x0
    // 0xfa0610: r0 = false
    //     0xfa0610: add             x0, NULL, #0x30  ; false
    // 0xfa0614: stur            x1, [fp, #-0x10]
    // 0xfa0618: StoreField: r1->field_67 = r0
    //     0xfa0618: stur            w0, [x1, #0x67]
    // 0xfa061c: StoreField: r1->field_7 = rZR
    //     0xfa061c: stur            xzr, [x1, #7]
    // 0xfa0620: StoreField: r1->field_13 = rZR
    //     0xfa0620: stur            xzr, [x1, #0x13]
    // 0xfa0624: StoreField: r1->field_1b = rZR
    //     0xfa0624: stur            xzr, [x1, #0x1b]
    // 0xfa0628: r0 = LoadStaticField(0x45c)
    //     0xfa0628: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xfa062c: ldr             x0, [x0, #0x8b8]
    // 0xfa0630: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa0634: cmp             w0, w16
    // 0xfa0638: b.ne            #0xfa0644
    // 0xfa063c: r2 = _emptyListeners
    //     0xfa063c: ldr             x2, [PP, #0x17f0]  ; [pp+0x17f0] Field <ChangeNotifier._emptyListeners@28329750>: static late final (offset: 0x45c)
    // 0xfa0640: r0 = InitLateFinalStaticField()
    //     0xfa0640: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xfa0644: mov             x1, x0
    // 0xfa0648: ldur            x0, [fp, #-0x10]
    // 0xfa064c: StoreField: r0->field_f = r1
    //     0xfa064c: stur            w1, [x0, #0xf]
    // 0xfa0650: ldur            x1, [fp, #-8]
    // 0xfa0654: StoreField: r1->field_13 = r0
    //     0xfa0654: stur            w0, [x1, #0x13]
    //     0xfa0658: ldurb           w16, [x1, #-1]
    //     0xfa065c: ldurb           w17, [x0, #-1]
    //     0xfa0660: and             x16, x17, x16, lsr #2
    //     0xfa0664: tst             x16, HEAP, lsr #32
    //     0xfa0668: b.eq            #0xfa0670
    //     0xfa066c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfa0670: r0 = Null
    //     0xfa0670: mov             x0, NULL
    // 0xfa0674: LeaveFrame
    //     0xfa0674: mov             SP, fp
    //     0xfa0678: ldp             fp, lr, [SP], #0x10
    // 0xfa067c: ret
    //     0xfa067c: ret             
    // 0xfa0680: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa0680: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa0684: b               #0xfa0608
  }
}

// class id: 5487, size: 0x18, field offset: 0x14
class _CupertinoRadioState<C1X0> extends State<C1X0> {

  _ build(/* No info */) {
    // ** addr: 0xde60e8, size: 0x184
    // 0xde60e8: EnterFrame
    //     0xde60e8: stp             fp, lr, [SP, #-0x10]!
    //     0xde60ec: mov             fp, SP
    // 0xde60f0: AllocStack(0x48)
    //     0xde60f0: sub             SP, SP, #0x48
    // 0xde60f4: SetupParameters(_CupertinoRadioState<C1X0> this /* r1 => r1, fp-0x8 */)
    //     0xde60f4: stur            x1, [fp, #-8]
    // 0xde60f8: CheckStackOverflow
    //     0xde60f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde60fc: cmp             SP, x16
    //     0xde6100: b.ls            #0xde6258
    // 0xde6104: r1 = 1
    //     0xde6104: mov             x1, #1
    // 0xde6108: r0 = AllocateContext()
    //     0xde6108: bl              #0x13de838  ; AllocateContextStub
    // 0xde610c: mov             x3, x0
    // 0xde6110: ldur            x0, [fp, #-8]
    // 0xde6114: stur            x3, [fp, #-0x10]
    // 0xde6118: StoreField: r3->field_f = r0
    //     0xde6118: stur            w0, [x3, #0xf]
    // 0xde611c: mov             x2, x3
    // 0xde6120: r1 = Function '<anonymous closure>':.
    //     0xde6120: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4f88] AnonymousClosure: (0xde63b8), in [package:flutter/src/cupertino/radio.dart] _CupertinoRadioState::build (0xde60e8)
    //     0xde6124: ldr             x1, [x1, #0xf88]
    // 0xde6128: r0 = AllocateClosure()
    //     0xde6128: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xde612c: r16 = <MouseCursor>
    //     0xde612c: ldr             x16, [PP, #0x21a8]  ; [pp+0x21a8] TypeArguments: <MouseCursor>
    // 0xde6130: stp             x0, x16, [SP]
    // 0xde6134: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xde6134: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xde6138: r0 = resolveWith()
    //     0xde6138: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xde613c: mov             x2, x0
    // 0xde6140: ldur            x0, [fp, #-8]
    // 0xde6144: stur            x2, [fp, #-0x20]
    // 0xde6148: LoadField: r1 = r0->field_b
    //     0xde6148: ldur            w1, [x0, #0xb]
    // 0xde614c: DecompressPointer r1
    //     0xde614c: add             x1, x1, HEAP, lsl #32
    // 0xde6150: cmp             w1, NULL
    // 0xde6154: b.eq            #0xde6260
    // 0xde6158: LoadField: r3 = r1->field_f
    //     0xde6158: ldur            w3, [x1, #0xf]
    // 0xde615c: DecompressPointer r3
    //     0xde615c: add             x3, x3, HEAP, lsl #32
    // 0xde6160: mov             x1, x0
    // 0xde6164: stur            x3, [fp, #-0x18]
    // 0xde6168: r0 = _effectiveRegistry()
    //     0xde6168: bl              #0xde62c8  ; [package:flutter/src/cupertino/radio.dart] _CupertinoRadioState::_effectiveRegistry
    // 0xde616c: mov             x2, x0
    // 0xde6170: ldur            x0, [fp, #-8]
    // 0xde6174: stur            x2, [fp, #-0x28]
    // 0xde6178: LoadField: r1 = r0->field_b
    //     0xde6178: ldur            w1, [x0, #0xb]
    // 0xde617c: DecompressPointer r1
    //     0xde617c: add             x1, x1, HEAP, lsl #32
    // 0xde6180: cmp             w1, NULL
    // 0xde6184: b.eq            #0xde6264
    // 0xde6188: mov             x1, x0
    // 0xde618c: r0 = restorationId()
    //     0xde618c: bl              #0xde62a0  ; [package:flutter/src/widgets/scrollable.dart] ScrollableState::restorationId
    // 0xde6190: mov             x2, x0
    // 0xde6194: ldur            x0, [fp, #-8]
    // 0xde6198: stur            x2, [fp, #-0x30]
    // 0xde619c: LoadField: r1 = r0->field_b
    //     0xde619c: ldur            w1, [x0, #0xb]
    // 0xde61a0: DecompressPointer r1
    //     0xde61a0: add             x1, x1, HEAP, lsl #32
    // 0xde61a4: cmp             w1, NULL
    // 0xde61a8: b.eq            #0xde6268
    // 0xde61ac: mov             x1, x0
    // 0xde61b0: r0 = _enabled()
    //     0xde61b0: bl              #0xde6278  ; [package:flutter/src/cupertino/radio.dart] _CupertinoRadioState::_enabled
    // 0xde61b4: mov             x4, x0
    // 0xde61b8: ldur            x0, [fp, #-8]
    // 0xde61bc: stur            x4, [fp, #-0x38]
    // 0xde61c0: LoadField: r2 = r0->field_7
    //     0xde61c0: ldur            w2, [x0, #7]
    // 0xde61c4: DecompressPointer r2
    //     0xde61c4: add             x2, x2, HEAP, lsl #32
    // 0xde61c8: r1 = Null
    //     0xde61c8: mov             x1, NULL
    // 0xde61cc: r3 = <C1X0>
    //     0xde61cc: add             x3, PP, #0x11, lsl #12  ; [pp+0x11880] TypeArguments: <C1X0>
    //     0xde61d0: ldr             x3, [x3, #0x880]
    // 0xde61d4: r0 = Null
    //     0xde61d4: mov             x0, NULL
    // 0xde61d8: cmp             x2, x0
    // 0xde61dc: b.eq            #0xde61ec
    // 0xde61e0: r30 = InstantiateTypeArgumentsStub
    //     0xde61e0: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0xde61e4: LoadField: r30 = r30->field_7
    //     0xde61e4: ldur            lr, [lr, #7]
    // 0xde61e8: blr             lr
    // 0xde61ec: mov             x1, x0
    // 0xde61f0: r0 = RawRadio()
    //     0xde61f0: bl              #0xde626c  ; AllocateRawRadioStub -> RawRadio<X0> (size=0x30)
    // 0xde61f4: mov             x3, x0
    // 0xde61f8: ldur            x0, [fp, #-0x18]
    // 0xde61fc: stur            x3, [fp, #-8]
    // 0xde6200: StoreField: r3->field_f = r0
    //     0xde6200: stur            w0, [x3, #0xf]
    // 0xde6204: ldur            x0, [fp, #-0x20]
    // 0xde6208: StoreField: r3->field_13 = r0
    //     0xde6208: stur            w0, [x3, #0x13]
    // 0xde620c: r0 = false
    //     0xde620c: add             x0, NULL, #0x30  ; false
    // 0xde6210: ArrayStore: r3[0] = r0  ; List_4
    //     0xde6210: stur            w0, [x3, #0x17]
    // 0xde6214: ldur            x1, [fp, #-0x30]
    // 0xde6218: StoreField: r3->field_1b = r1
    //     0xde6218: stur            w1, [x3, #0x1b]
    // 0xde621c: StoreField: r3->field_1f = r0
    //     0xde621c: stur            w0, [x3, #0x1f]
    // 0xde6220: ldur            x0, [fp, #-0x28]
    // 0xde6224: StoreField: r3->field_2b = r0
    //     0xde6224: stur            w0, [x3, #0x2b]
    // 0xde6228: ldur            x0, [fp, #-0x38]
    // 0xde622c: StoreField: r3->field_27 = r0
    //     0xde622c: stur            w0, [x3, #0x27]
    // 0xde6230: ldur            x2, [fp, #-0x10]
    // 0xde6234: r1 = Function '<anonymous closure>':.
    //     0xde6234: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4f90] AnonymousClosure: (0xde62f0), in [package:flutter/src/cupertino/radio.dart] _CupertinoRadioState::build (0xde60e8)
    //     0xde6238: ldr             x1, [x1, #0xf90]
    // 0xde623c: r0 = AllocateClosure()
    //     0xde623c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xde6240: mov             x1, x0
    // 0xde6244: ldur            x0, [fp, #-8]
    // 0xde6248: StoreField: r0->field_23 = r1
    //     0xde6248: stur            w1, [x0, #0x23]
    // 0xde624c: LeaveFrame
    //     0xde624c: mov             SP, fp
    //     0xde6250: ldp             fp, lr, [SP], #0x10
    // 0xde6254: ret
    //     0xde6254: ret             
    // 0xde6258: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde6258: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde625c: b               #0xde6104
    // 0xde6260: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde6260: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde6264: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde6264: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde6268: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde6268: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _enabled(/* No info */) {
    // ** addr: 0xde6278, size: 0x28
    // 0xde6278: LoadField: r2 = r1->field_b
    //     0xde6278: ldur            w2, [x1, #0xb]
    // 0xde627c: DecompressPointer r2
    //     0xde627c: add             x2, x2, HEAP, lsl #32
    // 0xde6280: cmp             w2, NULL
    // 0xde6284: b.eq            #0xde6294
    // 0xde6288: LoadField: r0 = r2->field_3b
    //     0xde6288: ldur            w0, [x2, #0x3b]
    // 0xde628c: DecompressPointer r0
    //     0xde628c: add             x0, x0, HEAP, lsl #32
    // 0xde6290: ret
    //     0xde6290: ret             
    // 0xde6294: EnterFrame
    //     0xde6294: stp             fp, lr, [SP, #-0x10]!
    //     0xde6298: mov             fp, SP
    // 0xde629c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde629c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _effectiveRegistry(/* No info */) {
    // ** addr: 0xde62c8, size: 0x28
    // 0xde62c8: LoadField: r2 = r1->field_b
    //     0xde62c8: ldur            w2, [x1, #0xb]
    // 0xde62cc: DecompressPointer r2
    //     0xde62cc: add             x2, x2, HEAP, lsl #32
    // 0xde62d0: cmp             w2, NULL
    // 0xde62d4: b.eq            #0xde62e4
    // 0xde62d8: LoadField: r0 = r2->field_37
    //     0xde62d8: ldur            w0, [x2, #0x37]
    // 0xde62dc: DecompressPointer r0
    //     0xde62dc: add             x0, x0, HEAP, lsl #32
    // 0xde62e0: ret
    //     0xde62e0: ret             
    // 0xde62e4: EnterFrame
    //     0xde62e4: stp             fp, lr, [SP, #-0x10]!
    //     0xde62e8: mov             fp, SP
    // 0xde62ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde62ec: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] _RadioPaint <anonymous closure>(dynamic, BuildContext, ToggleableStateMixin<StatefulWidget>) {
    // ** addr: 0xde62f0, size: 0x98
    // 0xde62f0: EnterFrame
    //     0xde62f0: stp             fp, lr, [SP, #-0x10]!
    //     0xde62f4: mov             fp, SP
    // 0xde62f8: AllocStack(0x10)
    //     0xde62f8: sub             SP, SP, #0x10
    // 0xde62fc: SetupParameters([dynamic _ /* r0 */])
    //     0xde62fc: ldr             x0, [fp, #0x20]
    //     0xde6300: ldur            w1, [x0, #0x17]
    //     0xde6304: add             x1, x1, HEAP, lsl #32
    // 0xde6308: CheckStackOverflow
    //     0xde6308: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde630c: cmp             SP, x16
    //     0xde6310: b.ls            #0xde637c
    // 0xde6314: LoadField: r0 = r1->field_f
    //     0xde6314: ldur            w0, [x1, #0xf]
    // 0xde6318: DecompressPointer r0
    //     0xde6318: add             x0, x0, HEAP, lsl #32
    // 0xde631c: LoadField: r1 = r0->field_b
    //     0xde631c: ldur            w1, [x0, #0xb]
    // 0xde6320: DecompressPointer r1
    //     0xde6320: add             x1, x1, HEAP, lsl #32
    // 0xde6324: cmp             w1, NULL
    // 0xde6328: b.eq            #0xde6384
    // 0xde632c: LoadField: r0 = r1->field_3b
    //     0xde632c: ldur            w0, [x1, #0x3b]
    // 0xde6330: DecompressPointer r0
    //     0xde6330: add             x0, x0, HEAP, lsl #32
    // 0xde6334: stur            x0, [fp, #-8]
    // 0xde6338: LoadField: r2 = r1->field_2f
    //     0xde6338: ldur            w2, [x1, #0x2f]
    // 0xde633c: DecompressPointer r2
    //     0xde633c: add             x2, x2, HEAP, lsl #32
    // 0xde6340: mov             x1, x2
    // 0xde6344: r0 = hasFocus()
    //     0xde6344: bl              #0x843d08  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::hasFocus
    // 0xde6348: stur            x0, [fp, #-0x10]
    // 0xde634c: r0 = _RadioPaint()
    //     0xde634c: bl              #0xde6388  ; Allocate_RadioPaintStub -> _RadioPaint (size=0x2c)
    // 0xde6350: ldur            x1, [fp, #-0x10]
    // 0xde6354: StoreField: r0->field_27 = r1
    //     0xde6354: stur            w1, [x0, #0x27]
    // 0xde6358: ldr             x1, [fp, #0x10]
    // 0xde635c: StoreField: r0->field_b = r1
    //     0xde635c: stur            w1, [x0, #0xb]
    // 0xde6360: r1 = false
    //     0xde6360: add             x1, NULL, #0x30  ; false
    // 0xde6364: StoreField: r0->field_1f = r1
    //     0xde6364: stur            w1, [x0, #0x1f]
    // 0xde6368: ldur            x1, [fp, #-8]
    // 0xde636c: StoreField: r0->field_23 = r1
    //     0xde636c: stur            w1, [x0, #0x23]
    // 0xde6370: LeaveFrame
    //     0xde6370: mov             SP, fp
    //     0xde6374: ldp             fp, lr, [SP], #0x10
    // 0xde6378: ret
    //     0xde6378: ret             
    // 0xde637c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde637c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde6380: b               #0xde6314
    // 0xde6384: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde6384: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] MouseCursor <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xde63b8, size: 0x9c
    // 0xde63b8: EnterFrame
    //     0xde63b8: stp             fp, lr, [SP, #-0x10]!
    //     0xde63bc: mov             fp, SP
    // 0xde63c0: AllocStack(0x18)
    //     0xde63c0: sub             SP, SP, #0x18
    // 0xde63c4: SetupParameters([dynamic _ /* r0 */])
    //     0xde63c4: ldr             x0, [fp, #0x18]
    //     0xde63c8: ldur            w1, [x0, #0x17]
    //     0xde63cc: add             x1, x1, HEAP, lsl #32
    // 0xde63d0: CheckStackOverflow
    //     0xde63d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde63d4: cmp             SP, x16
    //     0xde63d8: b.ls            #0xde6448
    // 0xde63dc: LoadField: r0 = r1->field_f
    //     0xde63dc: ldur            w0, [x1, #0xf]
    // 0xde63e0: DecompressPointer r0
    //     0xde63e0: add             x0, x0, HEAP, lsl #32
    // 0xde63e4: LoadField: r1 = r0->field_b
    //     0xde63e4: ldur            w1, [x0, #0xb]
    // 0xde63e8: DecompressPointer r1
    //     0xde63e8: add             x1, x1, HEAP, lsl #32
    // 0xde63ec: cmp             w1, NULL
    // 0xde63f0: b.eq            #0xde6450
    // 0xde63f4: r16 = <MouseCursor?>
    //     0xde63f4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15ab8] TypeArguments: <MouseCursor?>
    //     0xde63f8: ldr             x16, [x16, #0xab8]
    // 0xde63fc: stp             NULL, x16, [SP, #8]
    // 0xde6400: ldr             x16, [fp, #0x10]
    // 0xde6404: str             x16, [SP]
    // 0xde6408: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xde6408: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xde640c: r0 = resolveAs()
    //     0xde640c: bl              #0x8de57c  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveAs
    // 0xde6410: ldr             x1, [fp, #0x10]
    // 0xde6414: r0 = LoadClassIdInstr(r1)
    //     0xde6414: ldur            x0, [x1, #-1]
    //     0xde6418: ubfx            x0, x0, #0xc, #0x14
    // 0xde641c: r2 = Instance_WidgetState
    //     0xde641c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xde6420: ldr             x2, [x2, #0xa70]
    // 0xde6424: r0 = GDT[cid_x0 + 0x12929]()
    //     0xde6424: mov             x17, #0x2929
    //     0xde6428: movk            x17, #1, lsl #16
    //     0xde642c: add             lr, x0, x17
    //     0xde6430: ldr             lr, [x21, lr, lsl #3]
    //     0xde6434: blr             lr
    // 0xde6438: r0 = Instance_SystemMouseCursor
    //     0xde6438: ldr             x0, [PP, #0x21b0]  ; [pp+0x21b0] Obj!SystemMouseCursor@12b3201
    // 0xde643c: LeaveFrame
    //     0xde643c: mov             SP, fp
    //     0xde6440: ldp             fp, lr, [SP], #0x10
    // 0xde6444: ret
    //     0xde6444: ret             
    // 0xde6448: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde6448: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde644c: b               #0xde63dc
    // 0xde6450: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde6450: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 6516, size: 0x2c, field offset: 0xc
//   const constructor, 
class _RadioPaint extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa05a4, size: 0x48
    // 0xfa05a4: EnterFrame
    //     0xfa05a4: stp             fp, lr, [SP, #-0x10]!
    //     0xfa05a8: mov             fp, SP
    // 0xfa05ac: AllocStack(0x8)
    //     0xfa05ac: sub             SP, SP, #8
    // 0xfa05b0: CheckStackOverflow
    //     0xfa05b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa05b4: cmp             SP, x16
    //     0xfa05b8: b.ls            #0xfa05e4
    // 0xfa05bc: r1 = <_RadioPaint>
    //     0xfa05bc: add             x1, PP, #0xd5, lsl #12  ; [pp+0xd5140] TypeArguments: <_RadioPaint>
    //     0xfa05c0: ldr             x1, [x1, #0x140]
    // 0xfa05c4: r0 = _RadioPaintState()
    //     0xfa05c4: bl              #0xfa0694  ; Allocate_RadioPaintStateStub -> _RadioPaintState (size=0x18)
    // 0xfa05c8: mov             x1, x0
    // 0xfa05cc: stur            x0, [fp, #-8]
    // 0xfa05d0: r0 = _RadioPaintState()
    //     0xfa05d0: bl              #0xfa05ec  ; [package:flutter/src/cupertino/radio.dart] _RadioPaintState::_RadioPaintState
    // 0xfa05d4: ldur            x0, [fp, #-8]
    // 0xfa05d8: LeaveFrame
    //     0xfa05d8: mov             SP, fp
    //     0xfa05dc: ldp             fp, lr, [SP], #0x10
    // 0xfa05e0: ret
    //     0xfa05e0: ret             
    // 0xfa05e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa05e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa05e8: b               #0xfa05bc
  }
}

// class id: 6517, size: 0x40, field offset: 0xc
//   const constructor, 
class CupertinoRadio<X0> extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa055c, size: 0x3c
    // 0xfa055c: EnterFrame
    //     0xfa055c: stp             fp, lr, [SP, #-0x10]!
    //     0xfa0560: mov             fp, SP
    // 0xfa0564: LoadField: r2 = r1->field_b
    //     0xfa0564: ldur            w2, [x1, #0xb]
    // 0xfa0568: DecompressPointer r2
    //     0xfa0568: add             x2, x2, HEAP, lsl #32
    // 0xfa056c: r1 = Null
    //     0xfa056c: mov             x1, NULL
    // 0xfa0570: r3 = <CupertinoRadio<X0>, X0>
    //     0xfa0570: add             x3, PP, #0xd4, lsl #12  ; [pp+0xd4eb0] TypeArguments: <CupertinoRadio<X0>, X0>
    //     0xfa0574: ldr             x3, [x3, #0xeb0]
    // 0xfa0578: r30 = InstantiateTypeArgumentsStub
    //     0xfa0578: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0xfa057c: LoadField: r30 = r30->field_7
    //     0xfa057c: ldur            lr, [lr, #7]
    // 0xfa0580: blr             lr
    // 0xfa0584: mov             x1, x0
    // 0xfa0588: r0 = _CupertinoRadioState()
    //     0xfa0588: bl              #0xfa0598  ; Allocate_CupertinoRadioStateStub -> _CupertinoRadioState<C1X0> (size=0x18)
    // 0xfa058c: LeaveFrame
    //     0xfa058c: mov             SP, fp
    //     0xfa0590: ldp             fp, lr, [SP], #0x10
    // 0xfa0594: ret
    //     0xfa0594: ret             
  }
}
