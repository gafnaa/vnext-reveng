// lib: , url: package:flutter/src/cupertino/text_selection_toolbar.dart

// class id: 1048787, size: 0x8
class :: {
}

// class id: 4342, size: 0x14, field offset: 0xc
abstract class _CupertinoChevronPainter extends CustomPainter {

  _ paint(/* No info */) {
    // ** addr: 0xb74ed8, size: 0x1c4
    // 0xb74ed8: EnterFrame
    //     0xb74ed8: stp             fp, lr, [SP, #-0x10]!
    //     0xb74edc: mov             fp, SP
    // 0xb74ee0: AllocStack(0x60)
    //     0xb74ee0: sub             SP, SP, #0x60
    // 0xb74ee4: d0 = 4.000000
    //     0xb74ee4: fmov            d0, #4.00000000
    // 0xb74ee8: mov             x0, x1
    // 0xb74eec: stur            x1, [fp, #-0x10]
    // 0xb74ef0: mov             x1, x2
    // 0xb74ef4: stur            x2, [fp, #-0x18]
    // 0xb74ef8: CheckStackOverflow
    //     0xb74ef8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb74efc: cmp             SP, x16
    //     0xb74f00: b.ls            #0xb75094
    // 0xb74f04: LoadField: d1 = r3->field_f
    //     0xb74f04: ldur            d1, [x3, #0xf]
    // 0xb74f08: stur            d1, [fp, #-0x48]
    // 0xb74f0c: fdiv            d2, d1, d0
    // 0xb74f10: LoadField: r2 = r0->field_f
    //     0xb74f10: ldur            w2, [x0, #0xf]
    // 0xb74f14: DecompressPointer r2
    //     0xb74f14: add             x2, x2, HEAP, lsl #32
    // 0xb74f18: stur            x2, [fp, #-8]
    // 0xb74f1c: tbnz            w2, #4, #0xb74f28
    // 0xb74f20: r3 = 1
    //     0xb74f20: mov             x3, #1
    // 0xb74f24: b               #0xb74f2c
    // 0xb74f28: r3 = -1
    //     0xb74f28: mov             x3, #-1
    // 0xb74f2c: scvtf           d0, x3
    // 0xb74f30: fmul            d3, d2, d0
    // 0xb74f34: stur            d3, [fp, #-0x40]
    // 0xb74f38: r0 = Offset()
    //     0xb74f38: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xb74f3c: ldur            d0, [fp, #-0x40]
    // 0xb74f40: stur            x0, [fp, #-0x20]
    // 0xb74f44: StoreField: r0->field_7 = d0
    //     0xb74f44: stur            d0, [x0, #7]
    // 0xb74f48: StoreField: r0->field_f = rZR
    //     0xb74f48: stur            xzr, [x0, #0xf]
    // 0xb74f4c: ldur            d0, [fp, #-0x48]
    // 0xb74f50: d1 = 2.000000
    //     0xb74f50: fmov            d1, #2.00000000
    // 0xb74f54: fdiv            d2, d0, d1
    // 0xb74f58: stur            d2, [fp, #-0x40]
    // 0xb74f5c: r0 = Offset()
    //     0xb74f5c: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xb74f60: ldur            d0, [fp, #-0x40]
    // 0xb74f64: StoreField: r0->field_7 = d0
    //     0xb74f64: stur            d0, [x0, #7]
    // 0xb74f68: StoreField: r0->field_f = rZR
    //     0xb74f68: stur            xzr, [x0, #0xf]
    // 0xb74f6c: mov             x1, x0
    // 0xb74f70: ldur            x2, [fp, #-0x20]
    // 0xb74f74: r0 = +()
    //     0xb74f74: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0xb74f78: mov             x1, x0
    // 0xb74f7c: ldur            x0, [fp, #-8]
    // 0xb74f80: stur            x1, [fp, #-0x28]
    // 0xb74f84: tbnz            w0, #4, #0xb74f90
    // 0xb74f88: d2 = 0.000000
    //     0xb74f88: eor             v2.16b, v2.16b, v2.16b
    // 0xb74f8c: b               #0xb74f94
    // 0xb74f90: ldur            d2, [fp, #-0x48]
    // 0xb74f94: ldur            x0, [fp, #-0x10]
    // 0xb74f98: ldur            d0, [fp, #-0x40]
    // 0xb74f9c: ldur            d1, [fp, #-0x48]
    // 0xb74fa0: stur            d2, [fp, #-0x50]
    // 0xb74fa4: r0 = Offset()
    //     0xb74fa4: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xb74fa8: ldur            d0, [fp, #-0x50]
    // 0xb74fac: StoreField: r0->field_7 = d0
    //     0xb74fac: stur            d0, [x0, #7]
    // 0xb74fb0: ldur            d0, [fp, #-0x40]
    // 0xb74fb4: StoreField: r0->field_f = d0
    //     0xb74fb4: stur            d0, [x0, #0xf]
    // 0xb74fb8: mov             x1, x0
    // 0xb74fbc: ldur            x2, [fp, #-0x20]
    // 0xb74fc0: r0 = +()
    //     0xb74fc0: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0xb74fc4: stur            x0, [fp, #-8]
    // 0xb74fc8: r0 = Offset()
    //     0xb74fc8: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xb74fcc: ldur            d0, [fp, #-0x40]
    // 0xb74fd0: StoreField: r0->field_7 = d0
    //     0xb74fd0: stur            d0, [x0, #7]
    // 0xb74fd4: ldur            d0, [fp, #-0x48]
    // 0xb74fd8: StoreField: r0->field_f = d0
    //     0xb74fd8: stur            d0, [x0, #0xf]
    // 0xb74fdc: mov             x1, x0
    // 0xb74fe0: ldur            x2, [fp, #-0x20]
    // 0xb74fe4: r0 = +()
    //     0xb74fe4: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0xb74fe8: stur            x0, [fp, #-0x20]
    // 0xb74fec: r16 = 136
    //     0xb74fec: mov             x16, #0x88
    // 0xb74ff0: stp             x16, NULL, [SP]
    // 0xb74ff4: r0 = ByteData()
    //     0xb74ff4: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xb74ff8: stur            x0, [fp, #-0x30]
    // 0xb74ffc: r0 = Paint()
    //     0xb74ffc: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xb75000: mov             x3, x0
    // 0xb75004: ldur            x0, [fp, #-0x30]
    // 0xb75008: stur            x3, [fp, #-0x38]
    // 0xb7500c: StoreField: r3->field_7 = r0
    //     0xb7500c: stur            w0, [x3, #7]
    // 0xb75010: ldur            x1, [fp, #-0x10]
    // 0xb75014: LoadField: r2 = r1->field_b
    //     0xb75014: ldur            w2, [x1, #0xb]
    // 0xb75018: DecompressPointer r2
    //     0xb75018: add             x2, x2, HEAP, lsl #32
    // 0xb7501c: mov             x1, x3
    // 0xb75020: r0 = color=()
    //     0xb75020: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xb75024: ldur            x0, [fp, #-0x30]
    // 0xb75028: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb75028: ldur            w1, [x0, #0x17]
    // 0xb7502c: DecompressPointer r1
    //     0xb7502c: add             x1, x1, HEAP, lsl #32
    // 0xb75030: LoadField: r0 = r1->field_7
    //     0xb75030: ldur            x0, [x1, #7]
    // 0xb75034: r2 = 1
    //     0xb75034: mov             x2, #1
    // 0xb75038: str             w2, [x0, #0x1c]
    // 0xb7503c: LoadField: r0 = r1->field_7
    //     0xb7503c: ldur            x0, [x1, #7]
    // 0xb75040: d0 = 0.000000
    //     0xb75040: add             x17, PP, #0xa2, lsl #12  ; [pp+0xa2af0] IMM: 0x40000000
    //     0xb75044: ldr             s0, [x17, #0xaf0]
    // 0xb75048: str             s0, [x0, #0x20]
    // 0xb7504c: LoadField: r0 = r1->field_7
    //     0xb7504c: ldur            x0, [x1, #7]
    // 0xb75050: str             w2, [x0, #0x24]
    // 0xb75054: LoadField: r0 = r1->field_7
    //     0xb75054: ldur            x0, [x1, #7]
    // 0xb75058: str             w2, [x0, #0x28]
    // 0xb7505c: ldur            x1, [fp, #-0x18]
    // 0xb75060: ldur            x2, [fp, #-0x28]
    // 0xb75064: ldur            x3, [fp, #-8]
    // 0xb75068: ldur            x5, [fp, #-0x38]
    // 0xb7506c: r0 = drawLine()
    //     0xb7506c: bl              #0xb6932c  ; [dart:ui] _NativeCanvas::drawLine
    // 0xb75070: ldur            x1, [fp, #-0x18]
    // 0xb75074: ldur            x2, [fp, #-8]
    // 0xb75078: ldur            x3, [fp, #-0x20]
    // 0xb7507c: ldur            x5, [fp, #-0x38]
    // 0xb75080: r0 = drawLine()
    //     0xb75080: bl              #0xb6932c  ; [dart:ui] _NativeCanvas::drawLine
    // 0xb75084: r0 = Null
    //     0xb75084: mov             x0, NULL
    // 0xb75088: LeaveFrame
    //     0xb75088: mov             SP, fp
    //     0xb7508c: ldp             fp, lr, [SP], #0x10
    // 0xb75090: ret
    //     0xb75090: ret             
    // 0xb75094: r0 = StackOverflowSharedWithFPURegs()
    //     0xb75094: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb75098: b               #0xb74f04
  }
  _ shouldRepaint(/* No info */) {
    // ** addr: 0xb93064, size: 0xd4
    // 0xb93064: EnterFrame
    //     0xb93064: stp             fp, lr, [SP, #-0x10]!
    //     0xb93068: mov             fp, SP
    // 0xb9306c: AllocStack(0x20)
    //     0xb9306c: sub             SP, SP, #0x20
    // 0xb93070: SetupParameters(_CupertinoChevronPainter this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xb93070: mov             x4, x1
    //     0xb93074: mov             x3, x2
    //     0xb93078: stur            x1, [fp, #-8]
    //     0xb9307c: stur            x2, [fp, #-0x10]
    // 0xb93080: CheckStackOverflow
    //     0xb93080: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb93084: cmp             SP, x16
    //     0xb93088: b.ls            #0xb93130
    // 0xb9308c: mov             x0, x3
    // 0xb93090: r2 = Null
    //     0xb93090: mov             x2, NULL
    // 0xb93094: r1 = Null
    //     0xb93094: mov             x1, NULL
    // 0xb93098: r4 = 60
    //     0xb93098: mov             x4, #0x3c
    // 0xb9309c: branchIfSmi(r0, 0xb930a8)
    //     0xb9309c: tbz             w0, #0, #0xb930a8
    // 0xb930a0: r4 = LoadClassIdInstr(r0)
    //     0xb930a0: ldur            x4, [x0, #-1]
    //     0xb930a4: ubfx            x4, x4, #0xc, #0x14
    // 0xb930a8: r17 = -4343
    //     0xb930a8: mov             x17, #-0x10f7
    // 0xb930ac: add             x4, x4, x17
    // 0xb930b0: cmp             x4, #1
    // 0xb930b4: b.ls            #0xb930cc
    // 0xb930b8: r8 = _CupertinoChevronPainter
    //     0xb930b8: add             x8, PP, #0xac, lsl #12  ; [pp+0xacc10] Type: _CupertinoChevronPainter
    //     0xb930bc: ldr             x8, [x8, #0xc10]
    // 0xb930c0: r3 = Null
    //     0xb930c0: add             x3, PP, #0xac, lsl #12  ; [pp+0xacc18] Null
    //     0xb930c4: ldr             x3, [x3, #0xc18]
    // 0xb930c8: r0 = DefaultTypeTest()
    //     0xb930c8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb930cc: ldur            x0, [fp, #-0x10]
    // 0xb930d0: LoadField: r1 = r0->field_b
    //     0xb930d0: ldur            w1, [x0, #0xb]
    // 0xb930d4: DecompressPointer r1
    //     0xb930d4: add             x1, x1, HEAP, lsl #32
    // 0xb930d8: ldur            x2, [fp, #-8]
    // 0xb930dc: LoadField: r3 = r2->field_b
    //     0xb930dc: ldur            w3, [x2, #0xb]
    // 0xb930e0: DecompressPointer r3
    //     0xb930e0: add             x3, x3, HEAP, lsl #32
    // 0xb930e4: stp             x3, x1, [SP]
    // 0xb930e8: r0 = ==()
    //     0xb930e8: bl              #0x12629d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::==
    // 0xb930ec: tbz             w0, #4, #0xb930f8
    // 0xb930f0: r0 = true
    //     0xb930f0: add             x0, NULL, #0x20  ; true
    // 0xb930f4: b               #0xb93124
    // 0xb930f8: ldur            x2, [fp, #-8]
    // 0xb930fc: ldur            x1, [fp, #-0x10]
    // 0xb93100: LoadField: r3 = r1->field_f
    //     0xb93100: ldur            w3, [x1, #0xf]
    // 0xb93104: DecompressPointer r3
    //     0xb93104: add             x3, x3, HEAP, lsl #32
    // 0xb93108: LoadField: r1 = r2->field_f
    //     0xb93108: ldur            w1, [x2, #0xf]
    // 0xb9310c: DecompressPointer r1
    //     0xb9310c: add             x1, x1, HEAP, lsl #32
    // 0xb93110: cmp             w3, w1
    // 0xb93114: r16 = true
    //     0xb93114: add             x16, NULL, #0x20  ; true
    // 0xb93118: r17 = false
    //     0xb93118: add             x17, NULL, #0x30  ; false
    // 0xb9311c: csel            x2, x16, x17, ne
    // 0xb93120: mov             x0, x2
    // 0xb93124: LeaveFrame
    //     0xb93124: mov             SP, fp
    //     0xb93128: ldp             fp, lr, [SP], #0x10
    // 0xb9312c: ret
    //     0xb9312c: ret             
    // 0xb93130: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb93130: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb93134: b               #0xb9308c
  }
}

// class id: 4343, size: 0x14, field offset: 0x14
class _RightCupertinoChevronPainter extends _CupertinoChevronPainter {
}

// class id: 4344, size: 0x14, field offset: 0x14
class _LeftCupertinoChevronPainter extends _CupertinoChevronPainter {
}

// class id: 4843, size: 0x88, field offset: 0x60
class _RenderCupertinoTextSelectionToolbarItems extends _MixinApplication419&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin {

  late bool hasNextPage; // offset: 0x64
  late bool hasPreviousPage; // offset: 0x68

  _ performLayout(/* No info */) {
    // ** addr: 0xbc4444, size: 0x704
    // 0xbc4444: EnterFrame
    //     0xbc4444: stp             fp, lr, [SP, #-0x10]!
    //     0xbc4448: mov             fp, SP
    // 0xbc444c: AllocStack(0x40)
    //     0xbc444c: sub             SP, SP, #0x40
    // 0xbc4450: SetupParameters(_RenderCupertinoTextSelectionToolbarItems this /* r1 => r1, fp-0x8 */)
    //     0xbc4450: stur            x1, [fp, #-8]
    // 0xbc4454: CheckStackOverflow
    //     0xbc4454: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbc4458: cmp             SP, x16
    //     0xbc445c: b.ls            #0xbc4ae8
    // 0xbc4460: r1 = 7
    //     0xbc4460: mov             x1, #7
    // 0xbc4464: r0 = AllocateContext()
    //     0xbc4464: bl              #0x13de838  ; AllocateContextStub
    // 0xbc4468: ldur            x3, [fp, #-8]
    // 0xbc446c: stur            x0, [fp, #-0x18]
    // 0xbc4470: StoreField: r0->field_f = r3
    //     0xbc4470: stur            w3, [x0, #0xf]
    // 0xbc4474: LoadField: r1 = r3->field_57
    //     0xbc4474: ldur            w1, [x3, #0x57]
    // 0xbc4478: DecompressPointer r1
    //     0xbc4478: add             x1, x1, HEAP, lsl #32
    // 0xbc447c: cmp             w1, NULL
    // 0xbc4480: b.ne            #0xbc4500
    // 0xbc4484: LoadField: r4 = r3->field_27
    //     0xbc4484: ldur            w4, [x3, #0x27]
    // 0xbc4488: DecompressPointer r4
    //     0xbc4488: add             x4, x4, HEAP, lsl #32
    // 0xbc448c: stur            x4, [fp, #-0x10]
    // 0xbc4490: cmp             w4, NULL
    // 0xbc4494: b.eq            #0xbc4a50
    // 0xbc4498: mov             x0, x4
    // 0xbc449c: r2 = Null
    //     0xbc449c: mov             x2, NULL
    // 0xbc44a0: r1 = Null
    //     0xbc44a0: mov             x1, NULL
    // 0xbc44a4: r4 = LoadClassIdInstr(r0)
    //     0xbc44a4: ldur            x4, [x0, #-1]
    //     0xbc44a8: ubfx            x4, x4, #0xc, #0x14
    // 0xbc44ac: sub             x4, x4, #0xb46
    // 0xbc44b0: cmp             x4, #1
    // 0xbc44b4: b.ls            #0xbc44c8
    // 0xbc44b8: r8 = BoxConstraints
    //     0xbc44b8: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbc44bc: r3 = Null
    //     0xbc44bc: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcc770] Null
    //     0xbc44c0: ldr             x3, [x3, #0x770]
    // 0xbc44c4: r0 = BoxConstraints()
    //     0xbc44c4: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbc44c8: ldur            x1, [fp, #-0x10]
    // 0xbc44cc: r0 = smallest()
    //     0xbc44cc: bl              #0xb214d4  ; [package:flutter/src/rendering/box.dart] BoxConstraints::smallest
    // 0xbc44d0: ldur            x3, [fp, #-8]
    // 0xbc44d4: StoreField: r3->field_4b = r0
    //     0xbc44d4: stur            w0, [x3, #0x4b]
    //     0xbc44d8: ldurb           w16, [x3, #-1]
    //     0xbc44dc: ldurb           w17, [x0, #-1]
    //     0xbc44e0: and             x16, x17, x16, lsr #2
    //     0xbc44e4: tst             x16, HEAP, lsr #32
    //     0xbc44e8: b.eq            #0xbc44f0
    //     0xbc44ec: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbc44f0: r0 = Null
    //     0xbc44f0: mov             x0, NULL
    // 0xbc44f4: LeaveFrame
    //     0xbc44f4: mov             SP, fp
    //     0xbc44f8: ldp             fp, lr, [SP], #0x10
    // 0xbc44fc: ret
    //     0xbc44fc: ret             
    // 0xbc4500: r4 = 0.000000
    //     0xbc4500: ldr             x4, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xbc4504: StoreField: r0->field_13 = r4
    //     0xbc4504: stur            w4, [x0, #0x13]
    // 0xbc4508: mov             x2, x0
    // 0xbc450c: r1 = Function '<anonymous closure>':.
    //     0xbc450c: add             x1, PP, #0xcc, lsl #12  ; [pp+0xcc780] AnonymousClosure: (0xbc5220), in [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarItems::performLayout (0xbc4444)
    //     0xbc4510: ldr             x1, [x1, #0x780]
    // 0xbc4514: r0 = AllocateClosure()
    //     0xbc4514: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xbc4518: ldur            x1, [fp, #-8]
    // 0xbc451c: mov             x2, x0
    // 0xbc4520: r0 = visitChildren()
    //     0xbc4520: bl              #0xbeeed4  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarItems::visitChildren
    // 0xbc4524: ldur            x3, [fp, #-8]
    // 0xbc4528: LoadField: r4 = r3->field_27
    //     0xbc4528: ldur            w4, [x3, #0x27]
    // 0xbc452c: DecompressPointer r4
    //     0xbc452c: add             x4, x4, HEAP, lsl #32
    // 0xbc4530: stur            x4, [fp, #-0x10]
    // 0xbc4534: cmp             w4, NULL
    // 0xbc4538: b.eq            #0xbc4a6c
    // 0xbc453c: ldur            x5, [fp, #-0x18]
    // 0xbc4540: mov             x0, x4
    // 0xbc4544: r2 = Null
    //     0xbc4544: mov             x2, NULL
    // 0xbc4548: r1 = Null
    //     0xbc4548: mov             x1, NULL
    // 0xbc454c: r4 = LoadClassIdInstr(r0)
    //     0xbc454c: ldur            x4, [x0, #-1]
    //     0xbc4550: ubfx            x4, x4, #0xc, #0x14
    // 0xbc4554: sub             x4, x4, #0xb46
    // 0xbc4558: cmp             x4, #1
    // 0xbc455c: b.ls            #0xbc4570
    // 0xbc4560: r8 = BoxConstraints
    //     0xbc4560: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbc4564: r3 = Null
    //     0xbc4564: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcc788] Null
    //     0xbc4568: ldr             x3, [x3, #0x788]
    // 0xbc456c: r0 = BoxConstraints()
    //     0xbc456c: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbc4570: ldur            x0, [fp, #-0x10]
    // 0xbc4574: LoadField: d0 = r0->field_f
    //     0xbc4574: ldur            d0, [x0, #0xf]
    // 0xbc4578: ldur            x2, [fp, #-0x18]
    // 0xbc457c: stur            d0, [fp, #-0x38]
    // 0xbc4580: LoadField: r0 = r2->field_13
    //     0xbc4580: ldur            w0, [x2, #0x13]
    // 0xbc4584: DecompressPointer r0
    //     0xbc4584: add             x0, x0, HEAP, lsl #32
    // 0xbc4588: stur            x0, [fp, #-0x10]
    // 0xbc458c: r0 = BoxConstraints()
    //     0xbc458c: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xbc4590: mov             x3, x0
    // 0xbc4594: stur            x3, [fp, #-0x20]
    // 0xbc4598: StoreField: r3->field_7 = rZR
    //     0xbc4598: stur            xzr, [x3, #7]
    // 0xbc459c: ldur            d0, [fp, #-0x38]
    // 0xbc45a0: StoreField: r3->field_f = d0
    //     0xbc45a0: stur            d0, [x3, #0xf]
    // 0xbc45a4: ldur            x0, [fp, #-0x10]
    // 0xbc45a8: LoadField: d0 = r0->field_7
    //     0xbc45a8: ldur            d0, [x0, #7]
    // 0xbc45ac: ArrayStore: r3[0] = d0  ; List_8
    //     0xbc45ac: stur            d0, [x3, #0x17]
    // 0xbc45b0: StoreField: r3->field_1f = d0
    //     0xbc45b0: stur            d0, [x3, #0x1f]
    // 0xbc45b4: ldur            x4, [fp, #-8]
    // 0xbc45b8: LoadField: r1 = r4->field_7f
    //     0xbc45b8: ldur            w1, [x4, #0x7f]
    // 0xbc45bc: DecompressPointer r1
    //     0xbc45bc: add             x1, x1, HEAP, lsl #32
    // 0xbc45c0: cmp             w1, NULL
    // 0xbc45c4: b.eq            #0xbc4af0
    // 0xbc45c8: r0 = LoadClassIdInstr(r1)
    //     0xbc45c8: ldur            x0, [x1, #-1]
    //     0xbc45cc: ubfx            x0, x0, #0xc, #0x14
    // 0xbc45d0: r16 = true
    //     0xbc45d0: add             x16, NULL, #0x20  ; true
    // 0xbc45d4: str             x16, [SP]
    // 0xbc45d8: mov             x2, x3
    // 0xbc45dc: r4 = const [0, 0x3, 0x1, 0x2, parentUsesSize, 0x2, null]
    //     0xbc45dc: add             x4, PP, #0xd, lsl #12  ; [pp+0xded0] List(7) [0, 0x3, 0x1, 0x2, "parentUsesSize", 0x2, Null]
    //     0xbc45e0: ldr             x4, [x4, #0xed0]
    // 0xbc45e4: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0xbc45e4: mov             x17, #0xe6b9
    //     0xbc45e8: add             lr, x0, x17
    //     0xbc45ec: ldr             lr, [x21, lr, lsl #3]
    //     0xbc45f0: blr             lr
    // 0xbc45f4: ldur            x3, [fp, #-8]
    // 0xbc45f8: LoadField: r1 = r3->field_83
    //     0xbc45f8: ldur            w1, [x3, #0x83]
    // 0xbc45fc: DecompressPointer r1
    //     0xbc45fc: add             x1, x1, HEAP, lsl #32
    // 0xbc4600: cmp             w1, NULL
    // 0xbc4604: b.eq            #0xbc4af4
    // 0xbc4608: r0 = LoadClassIdInstr(r1)
    //     0xbc4608: ldur            x0, [x1, #-1]
    //     0xbc460c: ubfx            x0, x0, #0xc, #0x14
    // 0xbc4610: r16 = true
    //     0xbc4610: add             x16, NULL, #0x20  ; true
    // 0xbc4614: str             x16, [SP]
    // 0xbc4618: ldur            x2, [fp, #-0x20]
    // 0xbc461c: r4 = const [0, 0x3, 0x1, 0x2, parentUsesSize, 0x2, null]
    //     0xbc461c: add             x4, PP, #0xd, lsl #12  ; [pp+0xded0] List(7) [0, 0x3, 0x1, 0x2, "parentUsesSize", 0x2, Null]
    //     0xbc4620: ldr             x4, [x4, #0xed0]
    // 0xbc4624: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0xbc4624: mov             x17, #0xe6b9
    //     0xbc4628: add             lr, x0, x17
    //     0xbc462c: ldr             lr, [x21, lr, lsl #3]
    //     0xbc4630: blr             lr
    // 0xbc4634: ldur            x0, [fp, #-8]
    // 0xbc4638: LoadField: r1 = r0->field_7f
    //     0xbc4638: ldur            w1, [x0, #0x7f]
    // 0xbc463c: DecompressPointer r1
    //     0xbc463c: add             x1, x1, HEAP, lsl #32
    // 0xbc4640: cmp             w1, NULL
    // 0xbc4644: b.eq            #0xbc4af8
    // 0xbc4648: r0 = size()
    //     0xbc4648: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbc464c: LoadField: d0 = r0->field_7
    //     0xbc464c: ldur            d0, [x0, #7]
    // 0xbc4650: ldur            x0, [fp, #-8]
    // 0xbc4654: stur            d0, [fp, #-0x38]
    // 0xbc4658: LoadField: r1 = r0->field_83
    //     0xbc4658: ldur            w1, [x0, #0x83]
    // 0xbc465c: DecompressPointer r1
    //     0xbc465c: add             x1, x1, HEAP, lsl #32
    // 0xbc4660: cmp             w1, NULL
    // 0xbc4664: b.eq            #0xbc4afc
    // 0xbc4668: r0 = size()
    //     0xbc4668: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbc466c: LoadField: d0 = r0->field_7
    //     0xbc466c: ldur            d0, [x0, #7]
    // 0xbc4670: ldur            d1, [fp, #-0x38]
    // 0xbc4674: fadd            d2, d1, d0
    // 0xbc4678: r0 = inline_Allocate_Double()
    //     0xbc4678: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbc467c: add             x0, x0, #0x10
    //     0xbc4680: cmp             x1, x0
    //     0xbc4684: b.ls            #0xbc4b00
    //     0xbc4688: str             x0, [THR, #0x60]  ; THR::top
    //     0xbc468c: sub             x0, x0, #0xf
    //     0xbc4690: mov             x1, #0xe19c
    //     0xbc4694: movk            x1, #3, lsl #16
    //     0xbc4698: stur            x1, [x0, #-1]
    // 0xbc469c: dmb             ishst
    // 0xbc46a0: StoreField: r0->field_7 = d2
    //     0xbc46a0: stur            d2, [x0, #7]
    // 0xbc46a4: ldur            x3, [fp, #-0x18]
    // 0xbc46a8: ArrayStore: r3[0] = r0  ; List_4
    //     0xbc46a8: stur            w0, [x3, #0x17]
    //     0xbc46ac: ldurb           w16, [x3, #-1]
    //     0xbc46b0: ldurb           w17, [x0, #-1]
    //     0xbc46b4: and             x16, x17, x16, lsr #2
    //     0xbc46b8: tst             x16, HEAP, lsr #32
    //     0xbc46bc: b.eq            #0xbc46c4
    //     0xbc46c0: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbc46c4: r0 = 0.000000
    //     0xbc46c4: ldr             x0, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xbc46c8: StoreField: r3->field_1b = r0
    //     0xbc46c8: stur            w0, [x3, #0x1b]
    // 0xbc46cc: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xbc46d0: StoreField: r3->field_1f = r0
    //     0xbc46d0: stur            w0, [x3, #0x1f]
    // 0xbc46d4: StoreField: r3->field_23 = rZR
    //     0xbc46d4: stur            wzr, [x3, #0x23]
    // 0xbc46d8: r0 = -2
    //     0xbc46d8: mov             x0, #-2
    // 0xbc46dc: StoreField: r3->field_27 = r0
    //     0xbc46dc: stur            w0, [x3, #0x27]
    // 0xbc46e0: mov             x2, x3
    // 0xbc46e4: r1 = Function '<anonymous closure>':.
    //     0xbc46e4: add             x1, PP, #0xcc, lsl #12  ; [pp+0xcc798] AnonymousClosure: (0xbc4b48), in [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarItems::performLayout (0xbc4444)
    //     0xbc46e8: ldr             x1, [x1, #0x798]
    // 0xbc46ec: r0 = AllocateClosure()
    //     0xbc46ec: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xbc46f0: ldur            x1, [fp, #-8]
    // 0xbc46f4: mov             x2, x0
    // 0xbc46f8: r0 = visitChildren()
    //     0xbc46f8: bl              #0xbeeed4  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarItems::visitChildren
    // 0xbc46fc: ldur            x3, [fp, #-0x18]
    // 0xbc4700: LoadField: r0 = r3->field_23
    //     0xbc4700: ldur            w0, [x3, #0x23]
    // 0xbc4704: DecompressPointer r0
    //     0xbc4704: add             x0, x0, HEAP, lsl #32
    // 0xbc4708: r4 = LoadInt32Instr(r0)
    //     0xbc4708: sbfx            x4, x0, #1, #0x1f
    //     0xbc470c: tbz             w0, #0, #0xbc4714
    //     0xbc4710: ldur            x4, [x0, #7]
    // 0xbc4714: stur            x4, [fp, #-0x28]
    // 0xbc4718: cmp             x4, #0
    // 0xbc471c: b.le            #0xbc48dc
    // 0xbc4720: ldur            x5, [fp, #-8]
    // 0xbc4724: LoadField: r6 = r5->field_83
    //     0xbc4724: ldur            w6, [x5, #0x83]
    // 0xbc4728: DecompressPointer r6
    //     0xbc4728: add             x6, x6, HEAP, lsl #32
    // 0xbc472c: stur            x6, [fp, #-0x20]
    // 0xbc4730: cmp             w6, NULL
    // 0xbc4734: b.eq            #0xbc4b10
    // 0xbc4738: LoadField: r7 = r6->field_7
    //     0xbc4738: ldur            w7, [x6, #7]
    // 0xbc473c: DecompressPointer r7
    //     0xbc473c: add             x7, x7, HEAP, lsl #32
    // 0xbc4740: stur            x7, [fp, #-0x10]
    // 0xbc4744: cmp             w7, NULL
    // 0xbc4748: b.eq            #0xbc4b14
    // 0xbc474c: mov             x0, x7
    // 0xbc4750: r2 = Null
    //     0xbc4750: mov             x2, NULL
    // 0xbc4754: r1 = Null
    //     0xbc4754: mov             x1, NULL
    // 0xbc4758: r4 = LoadClassIdInstr(r0)
    //     0xbc4758: ldur            x4, [x0, #-1]
    //     0xbc475c: ubfx            x4, x4, #0xc, #0x14
    // 0xbc4760: r17 = 4205
    //     0xbc4760: mov             x17, #0x106d
    // 0xbc4764: cmp             x4, x17
    // 0xbc4768: b.eq            #0xbc4780
    // 0xbc476c: r8 = ToolbarItemsParentData
    //     0xbc476c: add             x8, PP, #0xcc, lsl #12  ; [pp+0xcc6c0] Type: ToolbarItemsParentData
    //     0xbc4770: ldr             x8, [x8, #0x6c0]
    // 0xbc4774: r3 = Null
    //     0xbc4774: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcc7a0] Null
    //     0xbc4778: ldr             x3, [x3, #0x7a0]
    // 0xbc477c: r0 = DefaultTypeTest()
    //     0xbc477c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbc4780: ldur            x3, [fp, #-8]
    // 0xbc4784: LoadField: r0 = r3->field_7f
    //     0xbc4784: ldur            w0, [x3, #0x7f]
    // 0xbc4788: DecompressPointer r0
    //     0xbc4788: add             x0, x0, HEAP, lsl #32
    // 0xbc478c: cmp             w0, NULL
    // 0xbc4790: b.eq            #0xbc4b18
    // 0xbc4794: LoadField: r4 = r0->field_7
    //     0xbc4794: ldur            w4, [x0, #7]
    // 0xbc4798: DecompressPointer r4
    //     0xbc4798: add             x4, x4, HEAP, lsl #32
    // 0xbc479c: stur            x4, [fp, #-0x30]
    // 0xbc47a0: cmp             w4, NULL
    // 0xbc47a4: b.eq            #0xbc4b1c
    // 0xbc47a8: mov             x0, x4
    // 0xbc47ac: r2 = Null
    //     0xbc47ac: mov             x2, NULL
    // 0xbc47b0: r1 = Null
    //     0xbc47b0: mov             x1, NULL
    // 0xbc47b4: r4 = LoadClassIdInstr(r0)
    //     0xbc47b4: ldur            x4, [x0, #-1]
    //     0xbc47b8: ubfx            x4, x4, #0xc, #0x14
    // 0xbc47bc: r17 = 4205
    //     0xbc47bc: mov             x17, #0x106d
    // 0xbc47c0: cmp             x4, x17
    // 0xbc47c4: b.eq            #0xbc47dc
    // 0xbc47c8: r8 = ToolbarItemsParentData
    //     0xbc47c8: add             x8, PP, #0xcc, lsl #12  ; [pp+0xcc6c0] Type: ToolbarItemsParentData
    //     0xbc47cc: ldr             x8, [x8, #0x6c0]
    // 0xbc47d0: r3 = Null
    //     0xbc47d0: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcc7b0] Null
    //     0xbc47d4: ldr             x3, [x3, #0x7b0]
    // 0xbc47d8: r0 = DefaultTypeTest()
    //     0xbc47d8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbc47dc: ldur            x0, [fp, #-8]
    // 0xbc47e0: LoadField: r1 = r0->field_6b
    //     0xbc47e0: ldur            x1, [x0, #0x6b]
    // 0xbc47e4: ldur            x2, [fp, #-0x28]
    // 0xbc47e8: cmp             x1, x2
    // 0xbc47ec: b.eq            #0xbc48b0
    // 0xbc47f0: ldur            x1, [fp, #-0x18]
    // 0xbc47f4: LoadField: r2 = r1->field_1f
    //     0xbc47f4: ldur            w2, [x1, #0x1f]
    // 0xbc47f8: DecompressPointer r2
    //     0xbc47f8: add             x2, x2, HEAP, lsl #32
    // 0xbc47fc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xbc4800: cmp             w2, w16
    // 0xbc4804: b.eq            #0xbc4a8c
    // 0xbc4808: ldur            x3, [fp, #-0x10]
    // 0xbc480c: LoadField: d0 = r2->field_7
    //     0xbc480c: ldur            d0, [x2, #7]
    // 0xbc4810: stur            d0, [fp, #-0x38]
    // 0xbc4814: r0 = Offset()
    //     0xbc4814: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xbc4818: ldur            d0, [fp, #-0x38]
    // 0xbc481c: StoreField: r0->field_7 = d0
    //     0xbc481c: stur            d0, [x0, #7]
    // 0xbc4820: StoreField: r0->field_f = rZR
    //     0xbc4820: stur            xzr, [x0, #0xf]
    // 0xbc4824: ldur            x1, [fp, #-0x10]
    // 0xbc4828: StoreField: r1->field_7 = r0
    //     0xbc4828: stur            w0, [x1, #7]
    //     0xbc482c: ldurb           w16, [x1, #-1]
    //     0xbc4830: ldurb           w17, [x0, #-1]
    //     0xbc4834: and             x16, x17, x16, lsr #2
    //     0xbc4838: tst             x16, HEAP, lsr #32
    //     0xbc483c: b.eq            #0xbc4844
    //     0xbc4840: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbc4844: r0 = true
    //     0xbc4844: add             x0, NULL, #0x20  ; true
    // 0xbc4848: ArrayStore: r1[0] = r0  ; List_4
    //     0xbc4848: stur            w0, [x1, #0x17]
    // 0xbc484c: ldur            x1, [fp, #-0x20]
    // 0xbc4850: r0 = size()
    //     0xbc4850: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbc4854: LoadField: d0 = r0->field_7
    //     0xbc4854: ldur            d0, [x0, #7]
    // 0xbc4858: ldur            d1, [fp, #-0x38]
    // 0xbc485c: fadd            d2, d1, d0
    // 0xbc4860: r0 = inline_Allocate_Double()
    //     0xbc4860: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbc4864: add             x0, x0, #0x10
    //     0xbc4868: cmp             x1, x0
    //     0xbc486c: b.ls            #0xbc4b20
    //     0xbc4870: str             x0, [THR, #0x60]  ; THR::top
    //     0xbc4874: sub             x0, x0, #0xf
    //     0xbc4878: mov             x1, #0xe19c
    //     0xbc487c: movk            x1, #3, lsl #16
    //     0xbc4880: stur            x1, [x0, #-1]
    // 0xbc4884: dmb             ishst
    // 0xbc4888: StoreField: r0->field_7 = d2
    //     0xbc4888: stur            d2, [x0, #7]
    // 0xbc488c: ldur            x3, [fp, #-0x18]
    // 0xbc4890: StoreField: r3->field_1f = r0
    //     0xbc4890: stur            w0, [x3, #0x1f]
    //     0xbc4894: ldurb           w16, [x3, #-1]
    //     0xbc4898: ldurb           w17, [x0, #-1]
    //     0xbc489c: and             x16, x17, x16, lsr #2
    //     0xbc48a0: tst             x16, HEAP, lsr #32
    //     0xbc48a4: b.eq            #0xbc48ac
    //     0xbc48a8: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbc48ac: b               #0xbc48b4
    // 0xbc48b0: ldur            x3, [fp, #-0x18]
    // 0xbc48b4: ldur            x4, [fp, #-8]
    // 0xbc48b8: LoadField: r0 = r4->field_6b
    //     0xbc48b8: ldur            x0, [x4, #0x6b]
    // 0xbc48bc: cmp             x0, #0
    // 0xbc48c0: b.le            #0xbc4948
    // 0xbc48c4: ldur            x1, [fp, #-0x30]
    // 0xbc48c8: r0 = true
    //     0xbc48c8: add             x0, NULL, #0x20  ; true
    // 0xbc48cc: r2 = Instance_Offset
    //     0xbc48cc: ldr             x2, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xbc48d0: StoreField: r1->field_7 = r2
    //     0xbc48d0: stur            w2, [x1, #7]
    // 0xbc48d4: ArrayStore: r1[0] = r0  ; List_4
    //     0xbc48d4: stur            w0, [x1, #0x17]
    // 0xbc48d8: b               #0xbc4948
    // 0xbc48dc: ldur            x4, [fp, #-8]
    // 0xbc48e0: LoadField: r0 = r3->field_1f
    //     0xbc48e0: ldur            w0, [x3, #0x1f]
    // 0xbc48e4: DecompressPointer r0
    //     0xbc48e4: add             x0, x0, HEAP, lsl #32
    // 0xbc48e8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xbc48ec: cmp             w0, w16
    // 0xbc48f0: b.eq            #0xbc4aa0
    // 0xbc48f4: LoadField: d0 = r4->field_77
    //     0xbc48f4: ldur            d0, [x4, #0x77]
    // 0xbc48f8: LoadField: d1 = r0->field_7
    //     0xbc48f8: ldur            d1, [x0, #7]
    // 0xbc48fc: fsub            d2, d1, d0
    // 0xbc4900: r0 = inline_Allocate_Double()
    //     0xbc4900: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbc4904: add             x0, x0, #0x10
    //     0xbc4908: cmp             x1, x0
    //     0xbc490c: b.ls            #0xbc4b30
    //     0xbc4910: str             x0, [THR, #0x60]  ; THR::top
    //     0xbc4914: sub             x0, x0, #0xf
    //     0xbc4918: mov             x1, #0xe19c
    //     0xbc491c: movk            x1, #3, lsl #16
    //     0xbc4920: stur            x1, [x0, #-1]
    // 0xbc4924: dmb             ishst
    // 0xbc4928: StoreField: r0->field_7 = d2
    //     0xbc4928: stur            d2, [x0, #7]
    // 0xbc492c: StoreField: r3->field_1f = r0
    //     0xbc492c: stur            w0, [x3, #0x1f]
    //     0xbc4930: ldurb           w16, [x3, #-1]
    //     0xbc4934: ldurb           w17, [x0, #-1]
    //     0xbc4938: and             x16, x17, x16, lsr #2
    //     0xbc493c: tst             x16, HEAP, lsr #32
    //     0xbc4940: b.eq            #0xbc4948
    //     0xbc4944: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbc4948: LoadField: r0 = r4->field_6b
    //     0xbc4948: ldur            x0, [x4, #0x6b]
    // 0xbc494c: LoadField: r1 = r3->field_23
    //     0xbc494c: ldur            w1, [x3, #0x23]
    // 0xbc4950: DecompressPointer r1
    //     0xbc4950: add             x1, x1, HEAP, lsl #32
    // 0xbc4954: r2 = LoadInt32Instr(r1)
    //     0xbc4954: sbfx            x2, x1, #1, #0x1f
    //     0xbc4958: tbz             w1, #0, #0xbc4960
    //     0xbc495c: ldur            x2, [x1, #7]
    // 0xbc4960: cmp             x0, x2
    // 0xbc4964: r16 = true
    //     0xbc4964: add             x16, NULL, #0x20  ; true
    // 0xbc4968: r17 = false
    //     0xbc4968: add             x17, NULL, #0x30  ; false
    // 0xbc496c: csel            x1, x16, x17, ne
    // 0xbc4970: StoreField: r4->field_63 = r1
    //     0xbc4970: stur            w1, [x4, #0x63]
    // 0xbc4974: cmp             x0, #0
    // 0xbc4978: r16 = true
    //     0xbc4978: add             x16, NULL, #0x20  ; true
    // 0xbc497c: r17 = false
    //     0xbc497c: add             x17, NULL, #0x30  ; false
    // 0xbc4980: csel            x1, x16, x17, gt
    // 0xbc4984: StoreField: r4->field_67 = r1
    //     0xbc4984: stur            w1, [x4, #0x67]
    // 0xbc4988: LoadField: r5 = r4->field_27
    //     0xbc4988: ldur            w5, [x4, #0x27]
    // 0xbc498c: DecompressPointer r5
    //     0xbc498c: add             x5, x5, HEAP, lsl #32
    // 0xbc4990: stur            x5, [fp, #-0x10]
    // 0xbc4994: cmp             w5, NULL
    // 0xbc4998: b.eq            #0xbc4ab4
    // 0xbc499c: mov             x0, x5
    // 0xbc49a0: r2 = Null
    //     0xbc49a0: mov             x2, NULL
    // 0xbc49a4: r1 = Null
    //     0xbc49a4: mov             x1, NULL
    // 0xbc49a8: r4 = LoadClassIdInstr(r0)
    //     0xbc49a8: ldur            x4, [x0, #-1]
    //     0xbc49ac: ubfx            x4, x4, #0xc, #0x14
    // 0xbc49b0: sub             x4, x4, #0xb46
    // 0xbc49b4: cmp             x4, #1
    // 0xbc49b8: b.ls            #0xbc49cc
    // 0xbc49bc: r8 = BoxConstraints
    //     0xbc49bc: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbc49c0: r3 = Null
    //     0xbc49c0: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcc7c0] Null
    //     0xbc49c4: ldr             x3, [x3, #0x7c0]
    // 0xbc49c8: r0 = BoxConstraints()
    //     0xbc49c8: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbc49cc: ldur            x0, [fp, #-0x18]
    // 0xbc49d0: LoadField: r1 = r0->field_1f
    //     0xbc49d0: ldur            w1, [x0, #0x1f]
    // 0xbc49d4: DecompressPointer r1
    //     0xbc49d4: add             x1, x1, HEAP, lsl #32
    // 0xbc49d8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xbc49dc: cmp             w1, w16
    // 0xbc49e0: b.eq            #0xbc4ad4
    // 0xbc49e4: ldur            x2, [fp, #-8]
    // 0xbc49e8: LoadField: r3 = r0->field_13
    //     0xbc49e8: ldur            w3, [x0, #0x13]
    // 0xbc49ec: DecompressPointer r3
    //     0xbc49ec: add             x3, x3, HEAP, lsl #32
    // 0xbc49f0: stur            x3, [fp, #-0x20]
    // 0xbc49f4: LoadField: d0 = r1->field_7
    //     0xbc49f4: ldur            d0, [x1, #7]
    // 0xbc49f8: stur            d0, [fp, #-0x38]
    // 0xbc49fc: r0 = Size()
    //     0xbc49fc: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xbc4a00: ldur            d0, [fp, #-0x38]
    // 0xbc4a04: StoreField: r0->field_7 = d0
    //     0xbc4a04: stur            d0, [x0, #7]
    // 0xbc4a08: ldur            x1, [fp, #-0x20]
    // 0xbc4a0c: LoadField: d0 = r1->field_7
    //     0xbc4a0c: ldur            d0, [x1, #7]
    // 0xbc4a10: StoreField: r0->field_f = d0
    //     0xbc4a10: stur            d0, [x0, #0xf]
    // 0xbc4a14: ldur            x1, [fp, #-0x10]
    // 0xbc4a18: mov             x2, x0
    // 0xbc4a1c: r0 = constrain()
    //     0xbc4a1c: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xbc4a20: ldur            x1, [fp, #-8]
    // 0xbc4a24: StoreField: r1->field_4b = r0
    //     0xbc4a24: stur            w0, [x1, #0x4b]
    //     0xbc4a28: ldurb           w16, [x1, #-1]
    //     0xbc4a2c: ldurb           w17, [x0, #-1]
    //     0xbc4a30: and             x16, x17, x16, lsr #2
    //     0xbc4a34: tst             x16, HEAP, lsr #32
    //     0xbc4a38: b.eq            #0xbc4a40
    //     0xbc4a3c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbc4a40: r0 = Null
    //     0xbc4a40: mov             x0, NULL
    // 0xbc4a44: LeaveFrame
    //     0xbc4a44: mov             SP, fp
    //     0xbc4a48: ldp             fp, lr, [SP], #0x10
    // 0xbc4a4c: ret
    //     0xbc4a4c: ret             
    // 0xbc4a50: r0 = StateError()
    //     0xbc4a50: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbc4a54: mov             x1, x0
    // 0xbc4a58: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbc4a58: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbc4a5c: StoreField: r1->field_b = r0
    //     0xbc4a5c: stur            w0, [x1, #0xb]
    // 0xbc4a60: mov             x0, x1
    // 0xbc4a64: r0 = Throw()
    //     0xbc4a64: bl              #0x13ddb2c  ; ThrowStub
    // 0xbc4a68: brk             #0
    // 0xbc4a6c: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbc4a6c: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbc4a70: r0 = StateError()
    //     0xbc4a70: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbc4a74: mov             x1, x0
    // 0xbc4a78: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbc4a78: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbc4a7c: StoreField: r1->field_b = r0
    //     0xbc4a7c: stur            w0, [x1, #0xb]
    // 0xbc4a80: mov             x0, x1
    // 0xbc4a84: r0 = Throw()
    //     0xbc4a84: bl              #0x13ddb2c  ; ThrowStub
    // 0xbc4a88: brk             #0
    // 0xbc4a8c: r16 = "toolbarWidth"
    //     0xbc4a8c: add             x16, PP, #0xcc, lsl #12  ; [pp+0xcc7d0] "toolbarWidth"
    //     0xbc4a90: ldr             x16, [x16, #0x7d0]
    // 0xbc4a94: str             x16, [SP]
    // 0xbc4a98: r0 = _throwLocalNotInitialized()
    //     0xbc4a98: bl              #0x82b57c  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0xbc4a9c: brk             #0
    // 0xbc4aa0: r16 = "toolbarWidth"
    //     0xbc4aa0: add             x16, PP, #0xcc, lsl #12  ; [pp+0xcc7d0] "toolbarWidth"
    //     0xbc4aa4: ldr             x16, [x16, #0x7d0]
    // 0xbc4aa8: str             x16, [SP]
    // 0xbc4aac: r0 = _throwLocalNotInitialized()
    //     0xbc4aac: bl              #0x82b57c  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0xbc4ab0: brk             #0
    // 0xbc4ab4: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbc4ab4: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbc4ab8: r0 = StateError()
    //     0xbc4ab8: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbc4abc: mov             x1, x0
    // 0xbc4ac0: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbc4ac0: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbc4ac4: StoreField: r1->field_b = r0
    //     0xbc4ac4: stur            w0, [x1, #0xb]
    // 0xbc4ac8: mov             x0, x1
    // 0xbc4acc: r0 = Throw()
    //     0xbc4acc: bl              #0x13ddb2c  ; ThrowStub
    // 0xbc4ad0: brk             #0
    // 0xbc4ad4: r16 = "toolbarWidth"
    //     0xbc4ad4: add             x16, PP, #0xcc, lsl #12  ; [pp+0xcc7d0] "toolbarWidth"
    //     0xbc4ad8: ldr             x16, [x16, #0x7d0]
    // 0xbc4adc: str             x16, [SP]
    // 0xbc4ae0: r0 = _throwLocalNotInitialized()
    //     0xbc4ae0: bl              #0x82b57c  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0xbc4ae4: brk             #0
    // 0xbc4ae8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbc4ae8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbc4aec: b               #0xbc4460
    // 0xbc4af0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbc4af0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbc4af4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbc4af4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbc4af8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbc4af8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbc4afc: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbc4afc: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbc4b00: SaveReg d2
    //     0xbc4b00: str             q2, [SP, #-0x10]!
    // 0xbc4b04: r0 = AllocateDouble()
    //     0xbc4b04: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbc4b08: RestoreReg d2
    //     0xbc4b08: ldr             q2, [SP], #0x10
    // 0xbc4b0c: b               #0xbc46a0
    // 0xbc4b10: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbc4b10: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbc4b14: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbc4b14: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbc4b18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbc4b18: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbc4b1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbc4b1c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbc4b20: SaveReg d2
    //     0xbc4b20: str             q2, [SP, #-0x10]!
    // 0xbc4b24: r0 = AllocateDouble()
    //     0xbc4b24: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbc4b28: RestoreReg d2
    //     0xbc4b28: ldr             q2, [SP], #0x10
    // 0xbc4b2c: b               #0xbc4888
    // 0xbc4b30: SaveReg d2
    //     0xbc4b30: str             q2, [SP, #-0x10]!
    // 0xbc4b34: stp             x3, x4, [SP, #-0x10]!
    // 0xbc4b38: r0 = AllocateDouble()
    //     0xbc4b38: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbc4b3c: ldp             x3, x4, [SP], #0x10
    // 0xbc4b40: RestoreReg d2
    //     0xbc4b40: ldr             q2, [SP], #0x10
    // 0xbc4b44: b               #0xbc4928
  }
  [closure] void <anonymous closure>(dynamic, RenderObject) {
    // ** addr: 0xbc4b48, size: 0x6d8
    // 0xbc4b48: EnterFrame
    //     0xbc4b48: stp             fp, lr, [SP, #-0x10]!
    //     0xbc4b4c: mov             fp, SP
    // 0xbc4b50: AllocStack(0x40)
    //     0xbc4b50: sub             SP, SP, #0x40
    // 0xbc4b54: SetupParameters([dynamic _ /* r0 */])
    //     0xbc4b54: ldr             x0, [fp, #0x18]
    //     0xbc4b58: ldur            w3, [x0, #0x17]
    //     0xbc4b5c: add             x3, x3, HEAP, lsl #32
    //     0xbc4b60: stur            x3, [fp, #-0x10]
    // 0xbc4b64: CheckStackOverflow
    //     0xbc4b64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbc4b68: cmp             SP, x16
    //     0xbc4b6c: b.ls            #0xbc51d0
    // 0xbc4b70: LoadField: r0 = r3->field_27
    //     0xbc4b70: ldur            w0, [x3, #0x27]
    // 0xbc4b74: DecompressPointer r0
    //     0xbc4b74: add             x0, x0, HEAP, lsl #32
    // 0xbc4b78: r1 = LoadInt32Instr(r0)
    //     0xbc4b78: sbfx            x1, x0, #1, #0x1f
    //     0xbc4b7c: tbz             w0, #0, #0xbc4b84
    //     0xbc4b80: ldur            x1, [x0, #7]
    // 0xbc4b84: add             x4, x1, #1
    // 0xbc4b88: stur            x4, [fp, #-8]
    // 0xbc4b8c: r0 = BoxInt64Instr(r4)
    //     0xbc4b8c: sbfiz           x0, x4, #1, #0x1f
    //     0xbc4b90: cmp             x4, x0, asr #1
    //     0xbc4b94: b.eq            #0xbc4ba0
    //     0xbc4b98: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xbc4b9c: stur            x4, [x0, #7]
    // 0xbc4ba0: StoreField: r3->field_27 = r0
    //     0xbc4ba0: stur            w0, [x3, #0x27]
    //     0xbc4ba4: tbz             w0, #0, #0xbc4bc0
    //     0xbc4ba8: ldurb           w16, [x3, #-1]
    //     0xbc4bac: ldurb           w17, [x0, #-1]
    //     0xbc4bb0: and             x16, x17, x16, lsr #2
    //     0xbc4bb4: tst             x16, HEAP, lsr #32
    //     0xbc4bb8: b.eq            #0xbc4bc0
    //     0xbc4bbc: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbc4bc0: ldr             x0, [fp, #0x10]
    // 0xbc4bc4: r2 = Null
    //     0xbc4bc4: mov             x2, NULL
    // 0xbc4bc8: r1 = Null
    //     0xbc4bc8: mov             x1, NULL
    // 0xbc4bcc: r4 = LoadClassIdInstr(r0)
    //     0xbc4bcc: ldur            x4, [x0, #-1]
    //     0xbc4bd0: ubfx            x4, x4, #0xc, #0x14
    // 0xbc4bd4: r17 = -4710
    //     0xbc4bd4: mov             x17, #-0x1266
    // 0xbc4bd8: add             x4, x4, x17
    // 0xbc4bdc: cmp             x4, #0x109
    // 0xbc4be0: b.ls            #0xbc4bf4
    // 0xbc4be4: r8 = RenderBox
    //     0xbc4be4: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0xbc4be8: r3 = Null
    //     0xbc4be8: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcc7d8] Null
    //     0xbc4bec: ldr             x3, [x3, #0x7d8]
    // 0xbc4bf0: r0 = RenderBox()
    //     0xbc4bf0: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0xbc4bf4: ldr             x3, [fp, #0x10]
    // 0xbc4bf8: LoadField: r4 = r3->field_7
    //     0xbc4bf8: ldur            w4, [x3, #7]
    // 0xbc4bfc: DecompressPointer r4
    //     0xbc4bfc: add             x4, x4, HEAP, lsl #32
    // 0xbc4c00: stur            x4, [fp, #-0x18]
    // 0xbc4c04: cmp             w4, NULL
    // 0xbc4c08: b.eq            #0xbc51d8
    // 0xbc4c0c: mov             x0, x4
    // 0xbc4c10: r2 = Null
    //     0xbc4c10: mov             x2, NULL
    // 0xbc4c14: r1 = Null
    //     0xbc4c14: mov             x1, NULL
    // 0xbc4c18: r4 = LoadClassIdInstr(r0)
    //     0xbc4c18: ldur            x4, [x0, #-1]
    //     0xbc4c1c: ubfx            x4, x4, #0xc, #0x14
    // 0xbc4c20: r17 = 4205
    //     0xbc4c20: mov             x17, #0x106d
    // 0xbc4c24: cmp             x4, x17
    // 0xbc4c28: b.eq            #0xbc4c40
    // 0xbc4c2c: r8 = ToolbarItemsParentData
    //     0xbc4c2c: add             x8, PP, #0xcc, lsl #12  ; [pp+0xcc6c0] Type: ToolbarItemsParentData
    //     0xbc4c30: ldr             x8, [x8, #0x6c0]
    // 0xbc4c34: r3 = Null
    //     0xbc4c34: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcc7e8] Null
    //     0xbc4c38: ldr             x3, [x3, #0x7e8]
    // 0xbc4c3c: r0 = DefaultTypeTest()
    //     0xbc4c3c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbc4c40: ldur            x0, [fp, #-0x18]
    // 0xbc4c44: r1 = false
    //     0xbc4c44: add             x1, NULL, #0x30  ; false
    // 0xbc4c48: ArrayStore: r0[0] = r1  ; List_4
    //     0xbc4c48: stur            w1, [x0, #0x17]
    // 0xbc4c4c: ldur            x2, [fp, #-0x10]
    // 0xbc4c50: LoadField: r1 = r2->field_f
    //     0xbc4c50: ldur            w1, [x2, #0xf]
    // 0xbc4c54: DecompressPointer r1
    //     0xbc4c54: add             x1, x1, HEAP, lsl #32
    // 0xbc4c58: LoadField: r3 = r1->field_7f
    //     0xbc4c58: ldur            w3, [x1, #0x7f]
    // 0xbc4c5c: DecompressPointer r3
    //     0xbc4c5c: add             x3, x3, HEAP, lsl #32
    // 0xbc4c60: ldr             x4, [fp, #0x10]
    // 0xbc4c64: cmp             w4, w3
    // 0xbc4c68: b.eq            #0xbc4c9c
    // 0xbc4c6c: LoadField: r3 = r1->field_83
    //     0xbc4c6c: ldur            w3, [x1, #0x83]
    // 0xbc4c70: DecompressPointer r3
    //     0xbc4c70: add             x3, x3, HEAP, lsl #32
    // 0xbc4c74: cmp             w4, w3
    // 0xbc4c78: b.eq            #0xbc4c9c
    // 0xbc4c7c: LoadField: r5 = r2->field_23
    //     0xbc4c7c: ldur            w5, [x2, #0x23]
    // 0xbc4c80: DecompressPointer r5
    //     0xbc4c80: add             x5, x5, HEAP, lsl #32
    // 0xbc4c84: LoadField: r6 = r1->field_6b
    //     0xbc4c84: ldur            x6, [x1, #0x6b]
    // 0xbc4c88: r7 = LoadInt32Instr(r5)
    //     0xbc4c88: sbfx            x7, x5, #1, #0x1f
    //     0xbc4c8c: tbz             w5, #0, #0xbc4c94
    //     0xbc4c90: ldur            x7, [x5, #7]
    // 0xbc4c94: cmp             x7, x6
    // 0xbc4c98: b.le            #0xbc4cac
    // 0xbc4c9c: r0 = Null
    //     0xbc4c9c: mov             x0, NULL
    // 0xbc4ca0: LeaveFrame
    //     0xbc4ca0: mov             SP, fp
    //     0xbc4ca4: ldp             fp, lr, [SP], #0x10
    // 0xbc4ca8: ret
    //     0xbc4ca8: ret             
    // 0xbc4cac: cbnz            x7, #0xbc4ce8
    // 0xbc4cb0: ldur            x5, [fp, #-8]
    // 0xbc4cb4: LoadField: r6 = r1->field_4f
    //     0xbc4cb4: ldur            x6, [x1, #0x4f]
    // 0xbc4cb8: add             x1, x6, #1
    // 0xbc4cbc: cmp             x5, x1
    // 0xbc4cc0: b.ne            #0xbc4ccc
    // 0xbc4cc4: d0 = 0.000000
    //     0xbc4cc4: eor             v0.16b, v0.16b, v0.16b
    // 0xbc4cc8: b               #0xbc4ce0
    // 0xbc4ccc: cmp             w3, NULL
    // 0xbc4cd0: b.eq            #0xbc51dc
    // 0xbc4cd4: mov             x1, x3
    // 0xbc4cd8: r0 = size()
    //     0xbc4cd8: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbc4cdc: LoadField: d0 = r0->field_7
    //     0xbc4cdc: ldur            d0, [x0, #7]
    // 0xbc4ce0: ldur            x3, [fp, #-0x10]
    // 0xbc4ce4: b               #0xbc4cf8
    // 0xbc4ce8: mov             x3, x2
    // 0xbc4cec: ArrayLoad: r0 = r3[0]  ; List_4
    //     0xbc4cec: ldur            w0, [x3, #0x17]
    // 0xbc4cf0: DecompressPointer r0
    //     0xbc4cf0: add             x0, x0, HEAP, lsl #32
    // 0xbc4cf4: LoadField: d0 = r0->field_7
    //     0xbc4cf4: ldur            d0, [x0, #7]
    // 0xbc4cf8: stur            d0, [fp, #-0x30]
    // 0xbc4cfc: LoadField: r0 = r3->field_f
    //     0xbc4cfc: ldur            w0, [x3, #0xf]
    // 0xbc4d00: DecompressPointer r0
    //     0xbc4d00: add             x0, x0, HEAP, lsl #32
    // 0xbc4d04: LoadField: r4 = r0->field_27
    //     0xbc4d04: ldur            w4, [x0, #0x27]
    // 0xbc4d08: DecompressPointer r4
    //     0xbc4d08: add             x4, x4, HEAP, lsl #32
    // 0xbc4d0c: stur            x4, [fp, #-0x20]
    // 0xbc4d10: cmp             w4, NULL
    // 0xbc4d14: b.eq            #0xbc5174
    // 0xbc4d18: ldr             x5, [fp, #0x10]
    // 0xbc4d1c: mov             x0, x4
    // 0xbc4d20: r2 = Null
    //     0xbc4d20: mov             x2, NULL
    // 0xbc4d24: r1 = Null
    //     0xbc4d24: mov             x1, NULL
    // 0xbc4d28: r4 = LoadClassIdInstr(r0)
    //     0xbc4d28: ldur            x4, [x0, #-1]
    //     0xbc4d2c: ubfx            x4, x4, #0xc, #0x14
    // 0xbc4d30: sub             x4, x4, #0xb46
    // 0xbc4d34: cmp             x4, #1
    // 0xbc4d38: b.ls            #0xbc4d4c
    // 0xbc4d3c: r8 = BoxConstraints
    //     0xbc4d3c: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbc4d40: r3 = Null
    //     0xbc4d40: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcc7f8] Null
    //     0xbc4d44: ldr             x3, [x3, #0x7f8]
    // 0xbc4d48: r0 = BoxConstraints()
    //     0xbc4d48: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbc4d4c: ldur            x0, [fp, #-0x20]
    // 0xbc4d50: LoadField: d0 = r0->field_f
    //     0xbc4d50: ldur            d0, [x0, #0xf]
    // 0xbc4d54: ldur            d1, [fp, #-0x30]
    // 0xbc4d58: fsub            d2, d0, d1
    // 0xbc4d5c: ldur            x0, [fp, #-0x10]
    // 0xbc4d60: stur            d2, [fp, #-0x38]
    // 0xbc4d64: LoadField: r1 = r0->field_13
    //     0xbc4d64: ldur            w1, [x0, #0x13]
    // 0xbc4d68: DecompressPointer r1
    //     0xbc4d68: add             x1, x1, HEAP, lsl #32
    // 0xbc4d6c: stur            x1, [fp, #-0x20]
    // 0xbc4d70: r0 = BoxConstraints()
    //     0xbc4d70: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xbc4d74: StoreField: r0->field_7 = rZR
    //     0xbc4d74: stur            xzr, [x0, #7]
    // 0xbc4d78: ldur            d0, [fp, #-0x38]
    // 0xbc4d7c: StoreField: r0->field_f = d0
    //     0xbc4d7c: stur            d0, [x0, #0xf]
    // 0xbc4d80: ldur            x1, [fp, #-0x20]
    // 0xbc4d84: LoadField: d0 = r1->field_7
    //     0xbc4d84: ldur            d0, [x1, #7]
    // 0xbc4d88: ArrayStore: r0[0] = d0  ; List_8
    //     0xbc4d88: stur            d0, [x0, #0x17]
    // 0xbc4d8c: StoreField: r0->field_1f = d0
    //     0xbc4d8c: stur            d0, [x0, #0x1f]
    // 0xbc4d90: ldr             x3, [fp, #0x10]
    // 0xbc4d94: r1 = LoadClassIdInstr(r3)
    //     0xbc4d94: ldur            x1, [x3, #-1]
    //     0xbc4d98: ubfx            x1, x1, #0xc, #0x14
    // 0xbc4d9c: r16 = true
    //     0xbc4d9c: add             x16, NULL, #0x20  ; true
    // 0xbc4da0: str             x16, [SP]
    // 0xbc4da4: mov             x2, x0
    // 0xbc4da8: mov             x0, x1
    // 0xbc4dac: mov             x1, x3
    // 0xbc4db0: r4 = const [0, 0x3, 0x1, 0x2, parentUsesSize, 0x2, null]
    //     0xbc4db0: add             x4, PP, #0xd, lsl #12  ; [pp+0xded0] List(7) [0, 0x3, 0x1, 0x2, "parentUsesSize", 0x2, Null]
    //     0xbc4db4: ldr             x4, [x4, #0xed0]
    // 0xbc4db8: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0xbc4db8: mov             x17, #0xe6b9
    //     0xbc4dbc: add             lr, x0, x17
    //     0xbc4dc0: ldr             lr, [x21, lr, lsl #3]
    //     0xbc4dc4: blr             lr
    // 0xbc4dc8: ldur            x0, [fp, #-0x10]
    // 0xbc4dcc: LoadField: r1 = r0->field_1b
    //     0xbc4dcc: ldur            w1, [x0, #0x1b]
    // 0xbc4dd0: DecompressPointer r1
    //     0xbc4dd0: add             x1, x1, HEAP, lsl #32
    // 0xbc4dd4: LoadField: d0 = r1->field_7
    //     0xbc4dd4: ldur            d0, [x1, #7]
    // 0xbc4dd8: ldur            d1, [fp, #-0x30]
    // 0xbc4ddc: fadd            d2, d0, d1
    // 0xbc4de0: ldr             x1, [fp, #0x10]
    // 0xbc4de4: stur            d2, [fp, #-0x38]
    // 0xbc4de8: r0 = size()
    //     0xbc4de8: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbc4dec: LoadField: d0 = r0->field_7
    //     0xbc4dec: ldur            d0, [x0, #7]
    // 0xbc4df0: ldur            d1, [fp, #-0x38]
    // 0xbc4df4: fadd            d2, d1, d0
    // 0xbc4df8: ldur            x3, [fp, #-0x10]
    // 0xbc4dfc: stur            d2, [fp, #-0x30]
    // 0xbc4e00: LoadField: r4 = r3->field_f
    //     0xbc4e00: ldur            w4, [x3, #0xf]
    // 0xbc4e04: DecompressPointer r4
    //     0xbc4e04: add             x4, x4, HEAP, lsl #32
    // 0xbc4e08: stur            x4, [fp, #-0x28]
    // 0xbc4e0c: LoadField: r5 = r4->field_27
    //     0xbc4e0c: ldur            w5, [x4, #0x27]
    // 0xbc4e10: DecompressPointer r5
    //     0xbc4e10: add             x5, x5, HEAP, lsl #32
    // 0xbc4e14: stur            x5, [fp, #-0x20]
    // 0xbc4e18: cmp             w5, NULL
    // 0xbc4e1c: b.eq            #0xbc5190
    // 0xbc4e20: mov             x0, x5
    // 0xbc4e24: r2 = Null
    //     0xbc4e24: mov             x2, NULL
    // 0xbc4e28: r1 = Null
    //     0xbc4e28: mov             x1, NULL
    // 0xbc4e2c: r4 = LoadClassIdInstr(r0)
    //     0xbc4e2c: ldur            x4, [x0, #-1]
    //     0xbc4e30: ubfx            x4, x4, #0xc, #0x14
    // 0xbc4e34: sub             x4, x4, #0xb46
    // 0xbc4e38: cmp             x4, #1
    // 0xbc4e3c: b.ls            #0xbc4e50
    // 0xbc4e40: r8 = BoxConstraints
    //     0xbc4e40: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbc4e44: r3 = Null
    //     0xbc4e44: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcc808] Null
    //     0xbc4e48: ldr             x3, [x3, #0x808]
    // 0xbc4e4c: r0 = BoxConstraints()
    //     0xbc4e4c: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbc4e50: ldur            x0, [fp, #-0x20]
    // 0xbc4e54: LoadField: d0 = r0->field_f
    //     0xbc4e54: ldur            d0, [x0, #0xf]
    // 0xbc4e58: ldur            d1, [fp, #-0x30]
    // 0xbc4e5c: fcmp            d1, d0
    // 0xbc4e60: b.le            #0xbc5050
    // 0xbc4e64: ldur            x2, [fp, #-0x10]
    // 0xbc4e68: ldur            x3, [fp, #-0x28]
    // 0xbc4e6c: LoadField: r0 = r2->field_23
    //     0xbc4e6c: ldur            w0, [x2, #0x23]
    // 0xbc4e70: DecompressPointer r0
    //     0xbc4e70: add             x0, x0, HEAP, lsl #32
    // 0xbc4e74: r1 = LoadInt32Instr(r0)
    //     0xbc4e74: sbfx            x1, x0, #1, #0x1f
    //     0xbc4e78: tbz             w0, #0, #0xbc4e80
    //     0xbc4e7c: ldur            x1, [x0, #7]
    // 0xbc4e80: add             x4, x1, #1
    // 0xbc4e84: r0 = BoxInt64Instr(r4)
    //     0xbc4e84: sbfiz           x0, x4, #1, #0x1f
    //     0xbc4e88: cmp             x4, x0, asr #1
    //     0xbc4e8c: b.eq            #0xbc4e98
    //     0xbc4e90: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xbc4e94: stur            x4, [x0, #7]
    // 0xbc4e98: StoreField: r2->field_23 = r0
    //     0xbc4e98: stur            w0, [x2, #0x23]
    //     0xbc4e9c: tbz             w0, #0, #0xbc4eb8
    //     0xbc4ea0: ldurb           w16, [x2, #-1]
    //     0xbc4ea4: ldurb           w17, [x0, #-1]
    //     0xbc4ea8: and             x16, x17, x16, lsr #2
    //     0xbc4eac: tst             x16, HEAP, lsr #32
    //     0xbc4eb0: b.eq            #0xbc4eb8
    //     0xbc4eb4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xbc4eb8: LoadField: r1 = r3->field_7f
    //     0xbc4eb8: ldur            w1, [x3, #0x7f]
    // 0xbc4ebc: DecompressPointer r1
    //     0xbc4ebc: add             x1, x1, HEAP, lsl #32
    // 0xbc4ec0: cmp             w1, NULL
    // 0xbc4ec4: b.eq            #0xbc51e0
    // 0xbc4ec8: r0 = size()
    //     0xbc4ec8: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbc4ecc: LoadField: d0 = r0->field_7
    //     0xbc4ecc: ldur            d0, [x0, #7]
    // 0xbc4ed0: ldur            x2, [fp, #-0x10]
    // 0xbc4ed4: LoadField: r1 = r2->field_f
    //     0xbc4ed4: ldur            w1, [x2, #0xf]
    // 0xbc4ed8: DecompressPointer r1
    //     0xbc4ed8: add             x1, x1, HEAP, lsl #32
    // 0xbc4edc: LoadField: d1 = r1->field_77
    //     0xbc4edc: ldur            d1, [x1, #0x77]
    // 0xbc4ee0: fadd            d2, d0, d1
    // 0xbc4ee4: r0 = inline_Allocate_Double()
    //     0xbc4ee4: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0xbc4ee8: add             x0, x0, #0x10
    //     0xbc4eec: cmp             x3, x0
    //     0xbc4ef0: b.ls            #0xbc51e4
    //     0xbc4ef4: str             x0, [THR, #0x60]  ; THR::top
    //     0xbc4ef8: sub             x0, x0, #0xf
    //     0xbc4efc: mov             x3, #0xe19c
    //     0xbc4f00: movk            x3, #3, lsl #16
    //     0xbc4f04: stur            x3, [x0, #-1]
    // 0xbc4f08: dmb             ishst
    // 0xbc4f0c: StoreField: r0->field_7 = d2
    //     0xbc4f0c: stur            d2, [x0, #7]
    // 0xbc4f10: StoreField: r2->field_1b = r0
    //     0xbc4f10: stur            w0, [x2, #0x1b]
    //     0xbc4f14: ldurb           w16, [x2, #-1]
    //     0xbc4f18: ldurb           w17, [x0, #-1]
    //     0xbc4f1c: and             x16, x17, x16, lsr #2
    //     0xbc4f20: tst             x16, HEAP, lsr #32
    //     0xbc4f24: b.eq            #0xbc4f2c
    //     0xbc4f28: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xbc4f2c: LoadField: r0 = r1->field_7f
    //     0xbc4f2c: ldur            w0, [x1, #0x7f]
    // 0xbc4f30: DecompressPointer r0
    //     0xbc4f30: add             x0, x0, HEAP, lsl #32
    // 0xbc4f34: cmp             w0, NULL
    // 0xbc4f38: b.eq            #0xbc51fc
    // 0xbc4f3c: mov             x1, x0
    // 0xbc4f40: r0 = size()
    //     0xbc4f40: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbc4f44: LoadField: d0 = r0->field_7
    //     0xbc4f44: ldur            d0, [x0, #7]
    // 0xbc4f48: ldur            x0, [fp, #-0x10]
    // 0xbc4f4c: stur            d0, [fp, #-0x30]
    // 0xbc4f50: LoadField: r1 = r0->field_f
    //     0xbc4f50: ldur            w1, [x0, #0xf]
    // 0xbc4f54: DecompressPointer r1
    //     0xbc4f54: add             x1, x1, HEAP, lsl #32
    // 0xbc4f58: LoadField: r2 = r1->field_83
    //     0xbc4f58: ldur            w2, [x1, #0x83]
    // 0xbc4f5c: DecompressPointer r2
    //     0xbc4f5c: add             x2, x2, HEAP, lsl #32
    // 0xbc4f60: cmp             w2, NULL
    // 0xbc4f64: b.eq            #0xbc5200
    // 0xbc4f68: mov             x1, x2
    // 0xbc4f6c: r0 = size()
    //     0xbc4f6c: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbc4f70: LoadField: d0 = r0->field_7
    //     0xbc4f70: ldur            d0, [x0, #7]
    // 0xbc4f74: ldur            d1, [fp, #-0x30]
    // 0xbc4f78: fadd            d2, d1, d0
    // 0xbc4f7c: ldur            x3, [fp, #-0x10]
    // 0xbc4f80: stur            d2, [fp, #-0x38]
    // 0xbc4f84: LoadField: r0 = r3->field_f
    //     0xbc4f84: ldur            w0, [x3, #0xf]
    // 0xbc4f88: DecompressPointer r0
    //     0xbc4f88: add             x0, x0, HEAP, lsl #32
    // 0xbc4f8c: LoadField: r4 = r0->field_27
    //     0xbc4f8c: ldur            w4, [x0, #0x27]
    // 0xbc4f90: DecompressPointer r4
    //     0xbc4f90: add             x4, x4, HEAP, lsl #32
    // 0xbc4f94: stur            x4, [fp, #-0x20]
    // 0xbc4f98: cmp             w4, NULL
    // 0xbc4f9c: b.eq            #0xbc51b0
    // 0xbc4fa0: ldr             x5, [fp, #0x10]
    // 0xbc4fa4: mov             x0, x4
    // 0xbc4fa8: r2 = Null
    //     0xbc4fa8: mov             x2, NULL
    // 0xbc4fac: r1 = Null
    //     0xbc4fac: mov             x1, NULL
    // 0xbc4fb0: r4 = LoadClassIdInstr(r0)
    //     0xbc4fb0: ldur            x4, [x0, #-1]
    //     0xbc4fb4: ubfx            x4, x4, #0xc, #0x14
    // 0xbc4fb8: sub             x4, x4, #0xb46
    // 0xbc4fbc: cmp             x4, #1
    // 0xbc4fc0: b.ls            #0xbc4fd4
    // 0xbc4fc4: r8 = BoxConstraints
    //     0xbc4fc4: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbc4fc8: r3 = Null
    //     0xbc4fc8: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcc818] Null
    //     0xbc4fcc: ldr             x3, [x3, #0x818]
    // 0xbc4fd0: r0 = BoxConstraints()
    //     0xbc4fd0: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbc4fd4: ldur            x0, [fp, #-0x20]
    // 0xbc4fd8: LoadField: d0 = r0->field_f
    //     0xbc4fd8: ldur            d0, [x0, #0xf]
    // 0xbc4fdc: ldur            d1, [fp, #-0x38]
    // 0xbc4fe0: fsub            d2, d0, d1
    // 0xbc4fe4: ldur            x0, [fp, #-0x10]
    // 0xbc4fe8: stur            d2, [fp, #-0x30]
    // 0xbc4fec: LoadField: r1 = r0->field_13
    //     0xbc4fec: ldur            w1, [x0, #0x13]
    // 0xbc4ff0: DecompressPointer r1
    //     0xbc4ff0: add             x1, x1, HEAP, lsl #32
    // 0xbc4ff4: stur            x1, [fp, #-0x20]
    // 0xbc4ff8: r0 = BoxConstraints()
    //     0xbc4ff8: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xbc4ffc: StoreField: r0->field_7 = rZR
    //     0xbc4ffc: stur            xzr, [x0, #7]
    // 0xbc5000: ldur            d0, [fp, #-0x30]
    // 0xbc5004: StoreField: r0->field_f = d0
    //     0xbc5004: stur            d0, [x0, #0xf]
    // 0xbc5008: ldur            x1, [fp, #-0x20]
    // 0xbc500c: LoadField: d0 = r1->field_7
    //     0xbc500c: ldur            d0, [x1, #7]
    // 0xbc5010: ArrayStore: r0[0] = d0  ; List_8
    //     0xbc5010: stur            d0, [x0, #0x17]
    // 0xbc5014: StoreField: r0->field_1f = d0
    //     0xbc5014: stur            d0, [x0, #0x1f]
    // 0xbc5018: ldr             x3, [fp, #0x10]
    // 0xbc501c: r1 = LoadClassIdInstr(r3)
    //     0xbc501c: ldur            x1, [x3, #-1]
    //     0xbc5020: ubfx            x1, x1, #0xc, #0x14
    // 0xbc5024: r16 = true
    //     0xbc5024: add             x16, NULL, #0x20  ; true
    // 0xbc5028: str             x16, [SP]
    // 0xbc502c: mov             x2, x0
    // 0xbc5030: mov             x0, x1
    // 0xbc5034: mov             x1, x3
    // 0xbc5038: r4 = const [0, 0x3, 0x1, 0x2, parentUsesSize, 0x2, null]
    //     0xbc5038: add             x4, PP, #0xd, lsl #12  ; [pp+0xded0] List(7) [0, 0x3, 0x1, 0x2, "parentUsesSize", 0x2, Null]
    //     0xbc503c: ldr             x4, [x4, #0xed0]
    // 0xbc5040: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0xbc5040: mov             x17, #0xe6b9
    //     0xbc5044: add             lr, x0, x17
    //     0xbc5048: ldr             lr, [x21, lr, lsl #3]
    //     0xbc504c: blr             lr
    // 0xbc5050: ldur            x0, [fp, #-0x10]
    // 0xbc5054: ldur            x1, [fp, #-0x18]
    // 0xbc5058: LoadField: r2 = r0->field_1b
    //     0xbc5058: ldur            w2, [x0, #0x1b]
    // 0xbc505c: DecompressPointer r2
    //     0xbc505c: add             x2, x2, HEAP, lsl #32
    // 0xbc5060: LoadField: d0 = r2->field_7
    //     0xbc5060: ldur            d0, [x2, #7]
    // 0xbc5064: stur            d0, [fp, #-0x30]
    // 0xbc5068: r0 = Offset()
    //     0xbc5068: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xbc506c: ldur            d0, [fp, #-0x30]
    // 0xbc5070: StoreField: r0->field_7 = d0
    //     0xbc5070: stur            d0, [x0, #7]
    // 0xbc5074: StoreField: r0->field_f = rZR
    //     0xbc5074: stur            xzr, [x0, #0xf]
    // 0xbc5078: ldur            x2, [fp, #-0x18]
    // 0xbc507c: StoreField: r2->field_7 = r0
    //     0xbc507c: stur            w0, [x2, #7]
    //     0xbc5080: ldurb           w16, [x2, #-1]
    //     0xbc5084: ldurb           w17, [x0, #-1]
    //     0xbc5088: and             x16, x17, x16, lsr #2
    //     0xbc508c: tst             x16, HEAP, lsr #32
    //     0xbc5090: b.eq            #0xbc5098
    //     0xbc5094: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xbc5098: ldr             x1, [fp, #0x10]
    // 0xbc509c: r0 = size()
    //     0xbc509c: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbc50a0: LoadField: d0 = r0->field_7
    //     0xbc50a0: ldur            d0, [x0, #7]
    // 0xbc50a4: ldur            x1, [fp, #-0x10]
    // 0xbc50a8: LoadField: r2 = r1->field_f
    //     0xbc50a8: ldur            w2, [x1, #0xf]
    // 0xbc50ac: DecompressPointer r2
    //     0xbc50ac: add             x2, x2, HEAP, lsl #32
    // 0xbc50b0: LoadField: d1 = r2->field_77
    //     0xbc50b0: ldur            d1, [x2, #0x77]
    // 0xbc50b4: fadd            d2, d0, d1
    // 0xbc50b8: ldur            d0, [fp, #-0x30]
    // 0xbc50bc: fadd            d1, d0, d2
    // 0xbc50c0: r3 = inline_Allocate_Double()
    //     0xbc50c0: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0xbc50c4: add             x3, x3, #0x10
    //     0xbc50c8: cmp             x0, x3
    //     0xbc50cc: b.ls            #0xbc5204
    //     0xbc50d0: str             x3, [THR, #0x60]  ; THR::top
    //     0xbc50d4: sub             x3, x3, #0xf
    //     0xbc50d8: mov             x0, #0xe19c
    //     0xbc50dc: movk            x0, #3, lsl #16
    //     0xbc50e0: stur            x0, [x3, #-1]
    // 0xbc50e4: dmb             ishst
    // 0xbc50e8: StoreField: r3->field_7 = d1
    //     0xbc50e8: stur            d1, [x3, #7]
    // 0xbc50ec: mov             x0, x3
    // 0xbc50f0: StoreField: r1->field_1b = r0
    //     0xbc50f0: stur            w0, [x1, #0x1b]
    //     0xbc50f4: ldurb           w16, [x1, #-1]
    //     0xbc50f8: ldurb           w17, [x0, #-1]
    //     0xbc50fc: and             x16, x17, x16, lsr #2
    //     0xbc5100: tst             x16, HEAP, lsr #32
    //     0xbc5104: b.eq            #0xbc510c
    //     0xbc5108: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbc510c: LoadField: r0 = r1->field_23
    //     0xbc510c: ldur            w0, [x1, #0x23]
    // 0xbc5110: DecompressPointer r0
    //     0xbc5110: add             x0, x0, HEAP, lsl #32
    // 0xbc5114: LoadField: r4 = r2->field_6b
    //     0xbc5114: ldur            x4, [x2, #0x6b]
    // 0xbc5118: r2 = LoadInt32Instr(r0)
    //     0xbc5118: sbfx            x2, x0, #1, #0x1f
    //     0xbc511c: tbz             w0, #0, #0xbc5124
    //     0xbc5120: ldur            x2, [x0, #7]
    // 0xbc5124: cmp             x2, x4
    // 0xbc5128: r16 = true
    //     0xbc5128: add             x16, NULL, #0x20  ; true
    // 0xbc512c: r17 = false
    //     0xbc512c: add             x17, NULL, #0x30  ; false
    // 0xbc5130: csel            x0, x16, x17, eq
    // 0xbc5134: ldur            x5, [fp, #-0x18]
    // 0xbc5138: ArrayStore: r5[0] = r0  ; List_4
    //     0xbc5138: stur            w0, [x5, #0x17]
    // 0xbc513c: cmp             x2, x4
    // 0xbc5140: b.ne            #0xbc5164
    // 0xbc5144: mov             x0, x3
    // 0xbc5148: StoreField: r1->field_1f = r0
    //     0xbc5148: stur            w0, [x1, #0x1f]
    //     0xbc514c: ldurb           w16, [x1, #-1]
    //     0xbc5150: ldurb           w17, [x0, #-1]
    //     0xbc5154: and             x16, x17, x16, lsr #2
    //     0xbc5158: tst             x16, HEAP, lsr #32
    //     0xbc515c: b.eq            #0xbc5164
    //     0xbc5160: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbc5164: r0 = Null
    //     0xbc5164: mov             x0, NULL
    // 0xbc5168: LeaveFrame
    //     0xbc5168: mov             SP, fp
    //     0xbc516c: ldp             fp, lr, [SP], #0x10
    // 0xbc5170: ret
    //     0xbc5170: ret             
    // 0xbc5174: r0 = StateError()
    //     0xbc5174: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbc5178: mov             x1, x0
    // 0xbc517c: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbc517c: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbc5180: StoreField: r1->field_b = r0
    //     0xbc5180: stur            w0, [x1, #0xb]
    // 0xbc5184: mov             x0, x1
    // 0xbc5188: r0 = Throw()
    //     0xbc5188: bl              #0x13ddb2c  ; ThrowStub
    // 0xbc518c: brk             #0
    // 0xbc5190: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbc5190: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbc5194: r0 = StateError()
    //     0xbc5194: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbc5198: mov             x1, x0
    // 0xbc519c: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbc519c: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbc51a0: StoreField: r1->field_b = r0
    //     0xbc51a0: stur            w0, [x1, #0xb]
    // 0xbc51a4: mov             x0, x1
    // 0xbc51a8: r0 = Throw()
    //     0xbc51a8: bl              #0x13ddb2c  ; ThrowStub
    // 0xbc51ac: brk             #0
    // 0xbc51b0: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbc51b0: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbc51b4: r0 = StateError()
    //     0xbc51b4: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbc51b8: mov             x1, x0
    // 0xbc51bc: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbc51bc: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbc51c0: StoreField: r1->field_b = r0
    //     0xbc51c0: stur            w0, [x1, #0xb]
    // 0xbc51c4: mov             x0, x1
    // 0xbc51c8: r0 = Throw()
    //     0xbc51c8: bl              #0x13ddb2c  ; ThrowStub
    // 0xbc51cc: brk             #0
    // 0xbc51d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbc51d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbc51d4: b               #0xbc4b70
    // 0xbc51d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbc51d8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbc51dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbc51dc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbc51e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbc51e0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbc51e4: SaveReg d2
    //     0xbc51e4: str             q2, [SP, #-0x10]!
    // 0xbc51e8: stp             x1, x2, [SP, #-0x10]!
    // 0xbc51ec: r0 = AllocateDouble()
    //     0xbc51ec: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbc51f0: ldp             x1, x2, [SP], #0x10
    // 0xbc51f4: RestoreReg d2
    //     0xbc51f4: ldr             q2, [SP], #0x10
    // 0xbc51f8: b               #0xbc4f0c
    // 0xbc51fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbc51fc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbc5200: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbc5200: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbc5204: SaveReg d1
    //     0xbc5204: str             q1, [SP, #-0x10]!
    // 0xbc5208: stp             x1, x2, [SP, #-0x10]!
    // 0xbc520c: r0 = AllocateDouble()
    //     0xbc520c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbc5210: mov             x3, x0
    // 0xbc5214: ldp             x1, x2, [SP], #0x10
    // 0xbc5218: RestoreReg d1
    //     0xbc5218: ldr             q1, [SP], #0x10
    // 0xbc521c: b               #0xbc50e8
  }
  [closure] void <anonymous closure>(dynamic, RenderObject) {
    // ** addr: 0xbc5220, size: 0x168
    // 0xbc5220: EnterFrame
    //     0xbc5220: stp             fp, lr, [SP, #-0x10]!
    //     0xbc5224: mov             fp, SP
    // 0xbc5228: AllocStack(0x10)
    //     0xbc5228: sub             SP, SP, #0x10
    // 0xbc522c: SetupParameters([dynamic _ /* r0 */])
    //     0xbc522c: ldr             x0, [fp, #0x18]
    //     0xbc5230: ldur            w3, [x0, #0x17]
    //     0xbc5234: add             x3, x3, HEAP, lsl #32
    //     0xbc5238: stur            x3, [fp, #-8]
    // 0xbc523c: CheckStackOverflow
    //     0xbc523c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbc5240: cmp             SP, x16
    //     0xbc5244: b.ls            #0xbc5368
    // 0xbc5248: ldr             x0, [fp, #0x10]
    // 0xbc524c: r2 = Null
    //     0xbc524c: mov             x2, NULL
    // 0xbc5250: r1 = Null
    //     0xbc5250: mov             x1, NULL
    // 0xbc5254: r4 = LoadClassIdInstr(r0)
    //     0xbc5254: ldur            x4, [x0, #-1]
    //     0xbc5258: ubfx            x4, x4, #0xc, #0x14
    // 0xbc525c: r17 = -4710
    //     0xbc525c: mov             x17, #-0x1266
    // 0xbc5260: add             x4, x4, x17
    // 0xbc5264: cmp             x4, #0x109
    // 0xbc5268: b.ls            #0xbc527c
    // 0xbc526c: r8 = RenderBox
    //     0xbc526c: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0xbc5270: r3 = Null
    //     0xbc5270: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcc828] Null
    //     0xbc5274: ldr             x3, [x3, #0x828]
    // 0xbc5278: r0 = RenderBox()
    //     0xbc5278: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0xbc527c: ldur            x3, [fp, #-8]
    // 0xbc5280: LoadField: r0 = r3->field_f
    //     0xbc5280: ldur            w0, [x3, #0xf]
    // 0xbc5284: DecompressPointer r0
    //     0xbc5284: add             x0, x0, HEAP, lsl #32
    // 0xbc5288: LoadField: r4 = r0->field_27
    //     0xbc5288: ldur            w4, [x0, #0x27]
    // 0xbc528c: DecompressPointer r4
    //     0xbc528c: add             x4, x4, HEAP, lsl #32
    // 0xbc5290: stur            x4, [fp, #-0x10]
    // 0xbc5294: cmp             w4, NULL
    // 0xbc5298: b.eq            #0xbc534c
    // 0xbc529c: mov             x0, x4
    // 0xbc52a0: r2 = Null
    //     0xbc52a0: mov             x2, NULL
    // 0xbc52a4: r1 = Null
    //     0xbc52a4: mov             x1, NULL
    // 0xbc52a8: r4 = LoadClassIdInstr(r0)
    //     0xbc52a8: ldur            x4, [x0, #-1]
    //     0xbc52ac: ubfx            x4, x4, #0xc, #0x14
    // 0xbc52b0: sub             x4, x4, #0xb46
    // 0xbc52b4: cmp             x4, #1
    // 0xbc52b8: b.ls            #0xbc52cc
    // 0xbc52bc: r8 = BoxConstraints
    //     0xbc52bc: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbc52c0: r3 = Null
    //     0xbc52c0: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcc838] Null
    //     0xbc52c4: ldr             x3, [x3, #0x838]
    // 0xbc52c8: r0 = BoxConstraints()
    //     0xbc52c8: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbc52cc: ldur            x0, [fp, #-0x10]
    // 0xbc52d0: LoadField: d0 = r0->field_f
    //     0xbc52d0: ldur            d0, [x0, #0xf]
    // 0xbc52d4: ldr             x1, [fp, #0x10]
    // 0xbc52d8: r0 = getMaxIntrinsicHeight()
    //     0xbc52d8: bl              #0xb16950  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicHeight
    // 0xbc52dc: ldur            x1, [fp, #-8]
    // 0xbc52e0: LoadField: r0 = r1->field_13
    //     0xbc52e0: ldur            w0, [x1, #0x13]
    // 0xbc52e4: DecompressPointer r0
    //     0xbc52e4: add             x0, x0, HEAP, lsl #32
    // 0xbc52e8: LoadField: d1 = r0->field_7
    //     0xbc52e8: ldur            d1, [x0, #7]
    // 0xbc52ec: fcmp            d0, d1
    // 0xbc52f0: b.le            #0xbc533c
    // 0xbc52f4: r0 = inline_Allocate_Double()
    //     0xbc52f4: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xbc52f8: add             x0, x0, #0x10
    //     0xbc52fc: cmp             x2, x0
    //     0xbc5300: b.ls            #0xbc5370
    //     0xbc5304: str             x0, [THR, #0x60]  ; THR::top
    //     0xbc5308: sub             x0, x0, #0xf
    //     0xbc530c: mov             x2, #0xe19c
    //     0xbc5310: movk            x2, #3, lsl #16
    //     0xbc5314: stur            x2, [x0, #-1]
    // 0xbc5318: dmb             ishst
    // 0xbc531c: StoreField: r0->field_7 = d0
    //     0xbc531c: stur            d0, [x0, #7]
    // 0xbc5320: StoreField: r1->field_13 = r0
    //     0xbc5320: stur            w0, [x1, #0x13]
    //     0xbc5324: ldurb           w16, [x1, #-1]
    //     0xbc5328: ldurb           w17, [x0, #-1]
    //     0xbc532c: and             x16, x17, x16, lsr #2
    //     0xbc5330: tst             x16, HEAP, lsr #32
    //     0xbc5334: b.eq            #0xbc533c
    //     0xbc5338: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbc533c: r0 = Null
    //     0xbc533c: mov             x0, NULL
    // 0xbc5340: LeaveFrame
    //     0xbc5340: mov             SP, fp
    //     0xbc5344: ldp             fp, lr, [SP], #0x10
    // 0xbc5348: ret
    //     0xbc5348: ret             
    // 0xbc534c: r0 = StateError()
    //     0xbc534c: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbc5350: mov             x1, x0
    // 0xbc5354: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbc5354: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbc5358: StoreField: r1->field_b = r0
    //     0xbc5358: stur            w0, [x1, #0xb]
    // 0xbc535c: mov             x0, x1
    // 0xbc5360: r0 = Throw()
    //     0xbc5360: bl              #0x13ddb2c  ; ThrowStub
    // 0xbc5364: brk             #0
    // 0xbc5368: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbc5368: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbc536c: b               #0xbc5248
    // 0xbc5370: SaveReg d0
    //     0xbc5370: str             q0, [SP, #-0x10]!
    // 0xbc5374: SaveReg r1
    //     0xbc5374: str             x1, [SP, #-8]!
    // 0xbc5378: r0 = AllocateDouble()
    //     0xbc5378: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbc537c: RestoreReg r1
    //     0xbc537c: ldr             x1, [SP], #8
    // 0xbc5380: RestoreReg d0
    //     0xbc5380: ldr             q0, [SP], #0x10
    // 0xbc5384: b               #0xbc531c
  }
  _ visitChildrenForSemantics(/* No info */) {
    // ** addr: 0xbebe48, size: 0x68
    // 0xbebe48: EnterFrame
    //     0xbebe48: stp             fp, lr, [SP, #-0x10]!
    //     0xbebe4c: mov             fp, SP
    // 0xbebe50: AllocStack(0x10)
    //     0xbebe50: sub             SP, SP, #0x10
    // 0xbebe54: SetupParameters(_RenderCupertinoTextSelectionToolbarItems this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xbebe54: stur            x1, [fp, #-8]
    //     0xbebe58: stur            x2, [fp, #-0x10]
    // 0xbebe5c: CheckStackOverflow
    //     0xbebe5c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbebe60: cmp             SP, x16
    //     0xbebe64: b.ls            #0xbebea8
    // 0xbebe68: r1 = 1
    //     0xbebe68: mov             x1, #1
    // 0xbebe6c: r0 = AllocateContext()
    //     0xbebe6c: bl              #0x13de838  ; AllocateContextStub
    // 0xbebe70: mov             x1, x0
    // 0xbebe74: ldur            x0, [fp, #-0x10]
    // 0xbebe78: StoreField: r1->field_f = r0
    //     0xbebe78: stur            w0, [x1, #0xf]
    // 0xbebe7c: mov             x2, x1
    // 0xbebe80: r1 = Function '<anonymous closure>':.
    //     0xbebe80: add             x1, PP, #0xcc, lsl #12  ; [pp+0xcc6a8] AnonymousClosure: (0xbebeb0), in [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarItems::visitChildrenForSemantics (0xbebe48)
    //     0xbebe84: ldr             x1, [x1, #0x6a8]
    // 0xbebe88: r0 = AllocateClosure()
    //     0xbebe88: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xbebe8c: ldur            x1, [fp, #-8]
    // 0xbebe90: mov             x2, x0
    // 0xbebe94: r0 = visitChildren()
    //     0xbebe94: bl              #0xbeeed4  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarItems::visitChildren
    // 0xbebe98: r0 = Null
    //     0xbebe98: mov             x0, NULL
    // 0xbebe9c: LeaveFrame
    //     0xbebe9c: mov             SP, fp
    //     0xbebea0: ldp             fp, lr, [SP], #0x10
    // 0xbebea4: ret
    //     0xbebea4: ret             
    // 0xbebea8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbebea8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbebeac: b               #0xbebe68
  }
  [closure] void <anonymous closure>(dynamic, RenderObject) {
    // ** addr: 0xbebeb0, size: 0xf8
    // 0xbebeb0: EnterFrame
    //     0xbebeb0: stp             fp, lr, [SP, #-0x10]!
    //     0xbebeb4: mov             fp, SP
    // 0xbebeb8: AllocStack(0x20)
    //     0xbebeb8: sub             SP, SP, #0x20
    // 0xbebebc: SetupParameters([dynamic _ /* r0 */])
    //     0xbebebc: ldr             x0, [fp, #0x18]
    //     0xbebec0: ldur            w3, [x0, #0x17]
    //     0xbebec4: add             x3, x3, HEAP, lsl #32
    //     0xbebec8: stur            x3, [fp, #-8]
    // 0xbebecc: CheckStackOverflow
    //     0xbebecc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbebed0: cmp             SP, x16
    //     0xbebed4: b.ls            #0xbebf9c
    // 0xbebed8: ldr             x0, [fp, #0x10]
    // 0xbebedc: r2 = Null
    //     0xbebedc: mov             x2, NULL
    // 0xbebee0: r1 = Null
    //     0xbebee0: mov             x1, NULL
    // 0xbebee4: r4 = LoadClassIdInstr(r0)
    //     0xbebee4: ldur            x4, [x0, #-1]
    //     0xbebee8: ubfx            x4, x4, #0xc, #0x14
    // 0xbebeec: r17 = -4710
    //     0xbebeec: mov             x17, #-0x1266
    // 0xbebef0: add             x4, x4, x17
    // 0xbebef4: cmp             x4, #0x109
    // 0xbebef8: b.ls            #0xbebf0c
    // 0xbebefc: r8 = RenderBox
    //     0xbebefc: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0xbebf00: r3 = Null
    //     0xbebf00: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcc6b0] Null
    //     0xbebf04: ldr             x3, [x3, #0x6b0]
    // 0xbebf08: r0 = RenderBox()
    //     0xbebf08: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0xbebf0c: ldr             x3, [fp, #0x10]
    // 0xbebf10: LoadField: r4 = r3->field_7
    //     0xbebf10: ldur            w4, [x3, #7]
    // 0xbebf14: DecompressPointer r4
    //     0xbebf14: add             x4, x4, HEAP, lsl #32
    // 0xbebf18: stur            x4, [fp, #-0x10]
    // 0xbebf1c: cmp             w4, NULL
    // 0xbebf20: b.eq            #0xbebfa4
    // 0xbebf24: mov             x0, x4
    // 0xbebf28: r2 = Null
    //     0xbebf28: mov             x2, NULL
    // 0xbebf2c: r1 = Null
    //     0xbebf2c: mov             x1, NULL
    // 0xbebf30: r4 = LoadClassIdInstr(r0)
    //     0xbebf30: ldur            x4, [x0, #-1]
    //     0xbebf34: ubfx            x4, x4, #0xc, #0x14
    // 0xbebf38: r17 = 4205
    //     0xbebf38: mov             x17, #0x106d
    // 0xbebf3c: cmp             x4, x17
    // 0xbebf40: b.eq            #0xbebf58
    // 0xbebf44: r8 = ToolbarItemsParentData
    //     0xbebf44: add             x8, PP, #0xcc, lsl #12  ; [pp+0xcc6c0] Type: ToolbarItemsParentData
    //     0xbebf48: ldr             x8, [x8, #0x6c0]
    // 0xbebf4c: r3 = Null
    //     0xbebf4c: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcc6c8] Null
    //     0xbebf50: ldr             x3, [x3, #0x6c8]
    // 0xbebf54: r0 = DefaultTypeTest()
    //     0xbebf54: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbebf58: ldur            x0, [fp, #-0x10]
    // 0xbebf5c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbebf5c: ldur            w1, [x0, #0x17]
    // 0xbebf60: DecompressPointer r1
    //     0xbebf60: add             x1, x1, HEAP, lsl #32
    // 0xbebf64: tbnz            w1, #4, #0xbebf8c
    // 0xbebf68: ldur            x0, [fp, #-8]
    // 0xbebf6c: LoadField: r1 = r0->field_f
    //     0xbebf6c: ldur            w1, [x0, #0xf]
    // 0xbebf70: DecompressPointer r1
    //     0xbebf70: add             x1, x1, HEAP, lsl #32
    // 0xbebf74: ldr             x16, [fp, #0x10]
    // 0xbebf78: stp             x16, x1, [SP]
    // 0xbebf7c: mov             x0, x1
    // 0xbebf80: ClosureCall
    //     0xbebf80: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xbebf84: ldur            x2, [x0, #0x1f]
    //     0xbebf88: blr             x2
    // 0xbebf8c: r0 = Null
    //     0xbebf8c: mov             x0, NULL
    // 0xbebf90: LeaveFrame
    //     0xbebf90: mov             SP, fp
    //     0xbebf94: ldp             fp, lr, [SP], #0x10
    // 0xbebf98: ret
    //     0xbebf98: ret             
    // 0xbebf9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbebf9c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbebfa0: b               #0xbebed8
    // 0xbebfa4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbebfa4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ visitChildren(/* No info */) {
    // ** addr: 0xbeeed4, size: 0xa0
    // 0xbeeed4: EnterFrame
    //     0xbeeed4: stp             fp, lr, [SP, #-0x10]!
    //     0xbeeed8: mov             fp, SP
    // 0xbeeedc: AllocStack(0x20)
    //     0xbeeedc: sub             SP, SP, #0x20
    // 0xbeeee0: SetupParameters(_RenderCupertinoTextSelectionToolbarItems this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xbeeee0: stur            x1, [fp, #-8]
    //     0xbeeee4: mov             x16, x2
    //     0xbeeee8: mov             x2, x1
    //     0xbeeeec: mov             x1, x16
    //     0xbeeef0: stur            x1, [fp, #-0x10]
    // 0xbeeef4: CheckStackOverflow
    //     0xbeeef4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbeeef8: cmp             SP, x16
    //     0xbeeefc: b.ls            #0xbeef6c
    // 0xbeef00: LoadField: r0 = r2->field_7f
    //     0xbeef00: ldur            w0, [x2, #0x7f]
    // 0xbeef04: DecompressPointer r0
    //     0xbeef04: add             x0, x0, HEAP, lsl #32
    // 0xbeef08: cmp             w0, NULL
    // 0xbeef0c: b.eq            #0xbeef24
    // 0xbeef10: stp             x0, x1, [SP]
    // 0xbeef14: mov             x0, x1
    // 0xbeef18: ClosureCall
    //     0xbeef18: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xbeef1c: ldur            x2, [x0, #0x1f]
    //     0xbeef20: blr             x2
    // 0xbeef24: ldur            x1, [fp, #-8]
    // 0xbeef28: LoadField: r0 = r1->field_83
    //     0xbeef28: ldur            w0, [x1, #0x83]
    // 0xbeef2c: DecompressPointer r0
    //     0xbeef2c: add             x0, x0, HEAP, lsl #32
    // 0xbeef30: cmp             w0, NULL
    // 0xbeef34: b.eq            #0xbeef50
    // 0xbeef38: ldur            x16, [fp, #-0x10]
    // 0xbeef3c: stp             x0, x16, [SP]
    // 0xbeef40: ldur            x0, [fp, #-0x10]
    // 0xbeef44: ClosureCall
    //     0xbeef44: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xbeef48: ldur            x2, [x0, #0x1f]
    //     0xbeef4c: blr             x2
    // 0xbeef50: ldur            x1, [fp, #-8]
    // 0xbeef54: ldur            x2, [fp, #-0x10]
    // 0xbeef58: r0 = visitChildren()
    //     0xbeef58: bl              #0xbeef74  ; [dart:mixin_deduplication] _MixinApplication118&RenderBox&ContainerRenderObjectMixin::visitChildren
    // 0xbeef5c: r0 = Null
    //     0xbeef5c: mov             x0, NULL
    // 0xbeef60: LeaveFrame
    //     0xbeef60: mov             SP, fp
    //     0xbeef64: ldp             fp, lr, [SP], #0x10
    // 0xbeef68: ret
    //     0xbeef68: ret             
    // 0xbeef6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbeef6c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbeef70: b               #0xbeef00
  }
  _ detach(/* No info */) {
    // ** addr: 0xc06e48, size: 0x10c
    // 0xc06e48: EnterFrame
    //     0xc06e48: stp             fp, lr, [SP, #-0x10]!
    //     0xc06e4c: mov             fp, SP
    // 0xc06e50: AllocStack(0x18)
    //     0xc06e50: sub             SP, SP, #0x18
    // 0xc06e54: SetupParameters(_RenderCupertinoTextSelectionToolbarItems this /* r1 => r0, fp-0x8 */)
    //     0xc06e54: mov             x0, x1
    //     0xc06e58: stur            x1, [fp, #-8]
    // 0xc06e5c: CheckStackOverflow
    //     0xc06e5c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc06e60: cmp             SP, x16
    //     0xc06e64: b.ls            #0xc06f44
    // 0xc06e68: mov             x1, x0
    // 0xc06e6c: r0 = detach()
    //     0xc06e6c: bl              #0xc06f54  ; [dart:mixin_deduplication] _MixinApplication118&RenderBox&ContainerRenderObjectMixin::detach
    // 0xc06e70: ldur            x0, [fp, #-8]
    // 0xc06e74: LoadField: r2 = r0->field_5f
    //     0xc06e74: ldur            w2, [x0, #0x5f]
    // 0xc06e78: DecompressPointer r2
    //     0xc06e78: add             x2, x2, HEAP, lsl #32
    // 0xc06e7c: stur            x2, [fp, #-0x10]
    // 0xc06e80: r1 = <RenderBox>
    //     0xc06e80: add             x1, PP, #0x15, lsl #12  ; [pp+0x155c8] TypeArguments: <RenderBox>
    //     0xc06e84: ldr             x1, [x1, #0x5c8]
    // 0xc06e88: r0 = _CompactValuesIterable()
    //     0xc06e88: bl              #0x7f3fb4  ; Allocate_CompactValuesIterableStub -> _CompactValuesIterable<X0> (size=0x10)
    // 0xc06e8c: mov             x1, x0
    // 0xc06e90: ldur            x0, [fp, #-0x10]
    // 0xc06e94: StoreField: r1->field_b = r0
    //     0xc06e94: stur            w0, [x1, #0xb]
    // 0xc06e98: r0 = iterator()
    //     0xc06e98: bl              #0xb09b20  ; [dart:_compact_hash] _CompactValuesIterable::iterator
    // 0xc06e9c: stur            x0, [fp, #-0x10]
    // 0xc06ea0: LoadField: r2 = r0->field_7
    //     0xc06ea0: ldur            w2, [x0, #7]
    // 0xc06ea4: DecompressPointer r2
    //     0xc06ea4: add             x2, x2, HEAP, lsl #32
    // 0xc06ea8: stur            x2, [fp, #-8]
    // 0xc06eac: CheckStackOverflow
    //     0xc06eac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc06eb0: cmp             SP, x16
    //     0xc06eb4: b.ls            #0xc06f4c
    // 0xc06eb8: mov             x1, x0
    // 0xc06ebc: r0 = moveNext()
    //     0xc06ebc: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0xc06ec0: tbnz            w0, #4, #0xc06f34
    // 0xc06ec4: ldur            x3, [fp, #-0x10]
    // 0xc06ec8: LoadField: r4 = r3->field_33
    //     0xc06ec8: ldur            w4, [x3, #0x33]
    // 0xc06ecc: DecompressPointer r4
    //     0xc06ecc: add             x4, x4, HEAP, lsl #32
    // 0xc06ed0: stur            x4, [fp, #-0x18]
    // 0xc06ed4: cmp             w4, NULL
    // 0xc06ed8: b.ne            #0xc06f0c
    // 0xc06edc: mov             x0, x4
    // 0xc06ee0: ldur            x2, [fp, #-8]
    // 0xc06ee4: r1 = Null
    //     0xc06ee4: mov             x1, NULL
    // 0xc06ee8: cmp             w2, NULL
    // 0xc06eec: b.eq            #0xc06f0c
    // 0xc06ef0: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xc06ef0: ldur            w4, [x2, #0x17]
    // 0xc06ef4: DecompressPointer r4
    //     0xc06ef4: add             x4, x4, HEAP, lsl #32
    // 0xc06ef8: r8 = X0
    //     0xc06ef8: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xc06efc: LoadField: r9 = r4->field_7
    //     0xc06efc: ldur            x9, [x4, #7]
    // 0xc06f00: r3 = Null
    //     0xc06f00: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcc6f0] Null
    //     0xc06f04: ldr             x3, [x3, #0x6f0]
    // 0xc06f08: blr             x9
    // 0xc06f0c: ldur            x1, [fp, #-0x18]
    // 0xc06f10: r0 = LoadClassIdInstr(r1)
    //     0xc06f10: ldur            x0, [x1, #-1]
    //     0xc06f14: ubfx            x0, x0, #0xc, #0x14
    // 0xc06f18: r0 = GDT[cid_x0 + 0xf618]()
    //     0xc06f18: mov             x17, #0xf618
    //     0xc06f1c: add             lr, x0, x17
    //     0xc06f20: ldr             lr, [x21, lr, lsl #3]
    //     0xc06f24: blr             lr
    // 0xc06f28: ldur            x0, [fp, #-0x10]
    // 0xc06f2c: ldur            x2, [fp, #-8]
    // 0xc06f30: b               #0xc06eac
    // 0xc06f34: r0 = Null
    //     0xc06f34: mov             x0, NULL
    // 0xc06f38: LeaveFrame
    //     0xc06f38: mov             SP, fp
    //     0xc06f3c: ldp             fp, lr, [SP], #0x10
    // 0xc06f40: ret
    //     0xc06f40: ret             
    // 0xc06f44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc06f44: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc06f48: b               #0xc06e68
    // 0xc06f4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc06f4c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc06f50: b               #0xc06eb8
  }
  _ attach(/* No info */) {
    // ** addr: 0xc0a758, size: 0x11c
    // 0xc0a758: EnterFrame
    //     0xc0a758: stp             fp, lr, [SP, #-0x10]!
    //     0xc0a75c: mov             fp, SP
    // 0xc0a760: AllocStack(0x20)
    //     0xc0a760: sub             SP, SP, #0x20
    // 0xc0a764: SetupParameters(_RenderCupertinoTextSelectionToolbarItems this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xc0a764: mov             x3, x1
    //     0xc0a768: mov             x0, x2
    //     0xc0a76c: stur            x1, [fp, #-8]
    //     0xc0a770: stur            x2, [fp, #-0x10]
    // 0xc0a774: CheckStackOverflow
    //     0xc0a774: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc0a778: cmp             SP, x16
    //     0xc0a77c: b.ls            #0xc0a864
    // 0xc0a780: mov             x1, x3
    // 0xc0a784: mov             x2, x0
    // 0xc0a788: r0 = attach()
    //     0xc0a788: bl              #0xc0a874  ; [dart:mixin_deduplication] _MixinApplication118&RenderBox&ContainerRenderObjectMixin::attach
    // 0xc0a78c: ldur            x0, [fp, #-8]
    // 0xc0a790: LoadField: r2 = r0->field_5f
    //     0xc0a790: ldur            w2, [x0, #0x5f]
    // 0xc0a794: DecompressPointer r2
    //     0xc0a794: add             x2, x2, HEAP, lsl #32
    // 0xc0a798: stur            x2, [fp, #-0x18]
    // 0xc0a79c: r1 = <RenderBox>
    //     0xc0a79c: add             x1, PP, #0x15, lsl #12  ; [pp+0x155c8] TypeArguments: <RenderBox>
    //     0xc0a7a0: ldr             x1, [x1, #0x5c8]
    // 0xc0a7a4: r0 = _CompactValuesIterable()
    //     0xc0a7a4: bl              #0x7f3fb4  ; Allocate_CompactValuesIterableStub -> _CompactValuesIterable<X0> (size=0x10)
    // 0xc0a7a8: mov             x1, x0
    // 0xc0a7ac: ldur            x0, [fp, #-0x18]
    // 0xc0a7b0: StoreField: r1->field_b = r0
    //     0xc0a7b0: stur            w0, [x1, #0xb]
    // 0xc0a7b4: r0 = iterator()
    //     0xc0a7b4: bl              #0xb09b20  ; [dart:_compact_hash] _CompactValuesIterable::iterator
    // 0xc0a7b8: stur            x0, [fp, #-0x18]
    // 0xc0a7bc: LoadField: r2 = r0->field_7
    //     0xc0a7bc: ldur            w2, [x0, #7]
    // 0xc0a7c0: DecompressPointer r2
    //     0xc0a7c0: add             x2, x2, HEAP, lsl #32
    // 0xc0a7c4: stur            x2, [fp, #-8]
    // 0xc0a7c8: CheckStackOverflow
    //     0xc0a7c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc0a7cc: cmp             SP, x16
    //     0xc0a7d0: b.ls            #0xc0a86c
    // 0xc0a7d4: mov             x1, x0
    // 0xc0a7d8: r0 = moveNext()
    //     0xc0a7d8: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0xc0a7dc: tbnz            w0, #4, #0xc0a854
    // 0xc0a7e0: ldur            x3, [fp, #-0x18]
    // 0xc0a7e4: LoadField: r4 = r3->field_33
    //     0xc0a7e4: ldur            w4, [x3, #0x33]
    // 0xc0a7e8: DecompressPointer r4
    //     0xc0a7e8: add             x4, x4, HEAP, lsl #32
    // 0xc0a7ec: stur            x4, [fp, #-0x20]
    // 0xc0a7f0: cmp             w4, NULL
    // 0xc0a7f4: b.ne            #0xc0a828
    // 0xc0a7f8: mov             x0, x4
    // 0xc0a7fc: ldur            x2, [fp, #-8]
    // 0xc0a800: r1 = Null
    //     0xc0a800: mov             x1, NULL
    // 0xc0a804: cmp             w2, NULL
    // 0xc0a808: b.eq            #0xc0a828
    // 0xc0a80c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xc0a80c: ldur            w4, [x2, #0x17]
    // 0xc0a810: DecompressPointer r4
    //     0xc0a810: add             x4, x4, HEAP, lsl #32
    // 0xc0a814: r8 = X0
    //     0xc0a814: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xc0a818: LoadField: r9 = r4->field_7
    //     0xc0a818: ldur            x9, [x4, #7]
    // 0xc0a81c: r3 = Null
    //     0xc0a81c: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcc700] Null
    //     0xc0a820: ldr             x3, [x3, #0x700]
    // 0xc0a824: blr             x9
    // 0xc0a828: ldur            x1, [fp, #-0x20]
    // 0xc0a82c: r0 = LoadClassIdInstr(r1)
    //     0xc0a82c: ldur            x0, [x1, #-1]
    //     0xc0a830: ubfx            x0, x0, #0xc, #0x14
    // 0xc0a834: ldur            x2, [fp, #-0x10]
    // 0xc0a838: r0 = GDT[cid_x0 + 0xf4f5]()
    //     0xc0a838: mov             x17, #0xf4f5
    //     0xc0a83c: add             lr, x0, x17
    //     0xc0a840: ldr             lr, [x21, lr, lsl #3]
    //     0xc0a844: blr             lr
    // 0xc0a848: ldur            x0, [fp, #-0x18]
    // 0xc0a84c: ldur            x2, [fp, #-8]
    // 0xc0a850: b               #0xc0a7c8
    // 0xc0a854: r0 = Null
    //     0xc0a854: mov             x0, NULL
    // 0xc0a858: LeaveFrame
    //     0xc0a858: mov             SP, fp
    //     0xc0a85c: ldp             fp, lr, [SP], #0x10
    // 0xc0a860: ret
    //     0xc0a860: ret             
    // 0xc0a864: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc0a864: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc0a868: b               #0xc0a780
    // 0xc0a86c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc0a86c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc0a870: b               #0xc0a7d4
  }
  _ setupParentData(/* No info */) {
    // ** addr: 0xc0db5c, size: 0xc0
    // 0xc0db5c: EnterFrame
    //     0xc0db5c: stp             fp, lr, [SP, #-0x10]!
    //     0xc0db60: mov             fp, SP
    // 0xc0db64: AllocStack(0x8)
    //     0xc0db64: sub             SP, SP, #8
    // 0xc0db68: SetupParameters(_RenderCupertinoTextSelectionToolbarItems this /* r1 => r4 */, dynamic _ /* r2 => r0, fp-0x8 */)
    //     0xc0db68: mov             x0, x2
    //     0xc0db6c: mov             x4, x1
    //     0xc0db70: mov             x3, x2
    //     0xc0db74: stur            x2, [fp, #-8]
    // 0xc0db78: r2 = Null
    //     0xc0db78: mov             x2, NULL
    // 0xc0db7c: r1 = Null
    //     0xc0db7c: mov             x1, NULL
    // 0xc0db80: r4 = 60
    //     0xc0db80: mov             x4, #0x3c
    // 0xc0db84: branchIfSmi(r0, 0xc0db90)
    //     0xc0db84: tbz             w0, #0, #0xc0db90
    // 0xc0db88: r4 = LoadClassIdInstr(r0)
    //     0xc0db88: ldur            x4, [x0, #-1]
    //     0xc0db8c: ubfx            x4, x4, #0xc, #0x14
    // 0xc0db90: r17 = -4710
    //     0xc0db90: mov             x17, #-0x1266
    // 0xc0db94: add             x4, x4, x17
    // 0xc0db98: cmp             x4, #0x109
    // 0xc0db9c: b.ls            #0xc0dbb0
    // 0xc0dba0: r8 = RenderBox
    //     0xc0dba0: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0xc0dba4: r3 = Null
    //     0xc0dba4: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcc738] Null
    //     0xc0dba8: ldr             x3, [x3, #0x738]
    // 0xc0dbac: r0 = RenderBox()
    //     0xc0dbac: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0xc0dbb0: ldur            x0, [fp, #-8]
    // 0xc0dbb4: LoadField: r1 = r0->field_7
    //     0xc0dbb4: ldur            w1, [x0, #7]
    // 0xc0dbb8: DecompressPointer r1
    //     0xc0dbb8: add             x1, x1, HEAP, lsl #32
    // 0xc0dbbc: r2 = LoadClassIdInstr(r1)
    //     0xc0dbbc: ldur            x2, [x1, #-1]
    //     0xc0dbc0: ubfx            x2, x2, #0xc, #0x14
    // 0xc0dbc4: r17 = 4205
    //     0xc0dbc4: mov             x17, #0x106d
    // 0xc0dbc8: cmp             x2, x17
    // 0xc0dbcc: b.eq            #0xc0dc0c
    // 0xc0dbd0: r1 = <RenderBox>
    //     0xc0dbd0: add             x1, PP, #0x15, lsl #12  ; [pp+0x155c8] TypeArguments: <RenderBox>
    //     0xc0dbd4: ldr             x1, [x1, #0x5c8]
    // 0xc0dbd8: r0 = ToolbarItemsParentData()
    //     0xc0dbd8: bl              #0xc0d6f8  ; AllocateToolbarItemsParentDataStub -> ToolbarItemsParentData (size=0x1c)
    // 0xc0dbdc: r1 = false
    //     0xc0dbdc: add             x1, NULL, #0x30  ; false
    // 0xc0dbe0: ArrayStore: r0[0] = r1  ; List_4
    //     0xc0dbe0: stur            w1, [x0, #0x17]
    // 0xc0dbe4: r1 = Instance_Offset
    //     0xc0dbe4: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc0dbe8: StoreField: r0->field_7 = r1
    //     0xc0dbe8: stur            w1, [x0, #7]
    // 0xc0dbec: ldur            x1, [fp, #-8]
    // 0xc0dbf0: StoreField: r1->field_7 = r0
    //     0xc0dbf0: stur            w0, [x1, #7]
    //     0xc0dbf4: ldurb           w16, [x1, #-1]
    //     0xc0dbf8: ldurb           w17, [x0, #-1]
    //     0xc0dbfc: and             x16, x17, x16, lsr #2
    //     0xc0dc00: tst             x16, HEAP, lsr #32
    //     0xc0dc04: b.eq            #0xc0dc0c
    //     0xc0dc08: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc0dc0c: r0 = Null
    //     0xc0dc0c: mov             x0, NULL
    // 0xc0dc10: LeaveFrame
    //     0xc0dc10: mov             SP, fp
    //     0xc0dc14: ldp             fp, lr, [SP], #0x10
    // 0xc0dc18: ret
    //     0xc0dc18: ret             
  }
  _ redepthChildren(/* No info */) {
    // ** addr: 0xc0f5f4, size: 0x64
    // 0xc0f5f4: EnterFrame
    //     0xc0f5f4: stp             fp, lr, [SP, #-0x10]!
    //     0xc0f5f8: mov             fp, SP
    // 0xc0f5fc: AllocStack(0x8)
    //     0xc0f5fc: sub             SP, SP, #8
    // 0xc0f600: SetupParameters(_RenderCupertinoTextSelectionToolbarItems this /* r1 => r1, fp-0x8 */)
    //     0xc0f600: stur            x1, [fp, #-8]
    // 0xc0f604: CheckStackOverflow
    //     0xc0f604: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc0f608: cmp             SP, x16
    //     0xc0f60c: b.ls            #0xc0f650
    // 0xc0f610: r1 = 1
    //     0xc0f610: mov             x1, #1
    // 0xc0f614: r0 = AllocateContext()
    //     0xc0f614: bl              #0x13de838  ; AllocateContextStub
    // 0xc0f618: mov             x1, x0
    // 0xc0f61c: ldur            x0, [fp, #-8]
    // 0xc0f620: StoreField: r1->field_f = r0
    //     0xc0f620: stur            w0, [x1, #0xf]
    // 0xc0f624: mov             x2, x1
    // 0xc0f628: r1 = Function '<anonymous closure>':.
    //     0xc0f628: add             x1, PP, #0xcc, lsl #12  ; [pp+0xcc6d8] AnonymousClosure: (0xc0f658), in [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarItems::redepthChildren (0xc0f5f4)
    //     0xc0f62c: ldr             x1, [x1, #0x6d8]
    // 0xc0f630: r0 = AllocateClosure()
    //     0xc0f630: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc0f634: ldur            x1, [fp, #-8]
    // 0xc0f638: mov             x2, x0
    // 0xc0f63c: r0 = visitChildren()
    //     0xc0f63c: bl              #0xbeeed4  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarItems::visitChildren
    // 0xc0f640: r0 = Null
    //     0xc0f640: mov             x0, NULL
    // 0xc0f644: LeaveFrame
    //     0xc0f644: mov             SP, fp
    //     0xc0f648: ldp             fp, lr, [SP], #0x10
    // 0xc0f64c: ret
    //     0xc0f64c: ret             
    // 0xc0f650: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc0f650: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc0f654: b               #0xc0f610
  }
  [closure] void <anonymous closure>(dynamic, RenderObject) {
    // ** addr: 0xc0f658, size: 0x88
    // 0xc0f658: EnterFrame
    //     0xc0f658: stp             fp, lr, [SP, #-0x10]!
    //     0xc0f65c: mov             fp, SP
    // 0xc0f660: AllocStack(0x8)
    //     0xc0f660: sub             SP, SP, #8
    // 0xc0f664: SetupParameters([dynamic _ /* r0 */])
    //     0xc0f664: ldr             x0, [fp, #0x18]
    //     0xc0f668: ldur            w3, [x0, #0x17]
    //     0xc0f66c: add             x3, x3, HEAP, lsl #32
    //     0xc0f670: stur            x3, [fp, #-8]
    // 0xc0f674: CheckStackOverflow
    //     0xc0f674: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc0f678: cmp             SP, x16
    //     0xc0f67c: b.ls            #0xc0f6d8
    // 0xc0f680: ldr             x0, [fp, #0x10]
    // 0xc0f684: r2 = Null
    //     0xc0f684: mov             x2, NULL
    // 0xc0f688: r1 = Null
    //     0xc0f688: mov             x1, NULL
    // 0xc0f68c: r4 = LoadClassIdInstr(r0)
    //     0xc0f68c: ldur            x4, [x0, #-1]
    //     0xc0f690: ubfx            x4, x4, #0xc, #0x14
    // 0xc0f694: r17 = -4710
    //     0xc0f694: mov             x17, #-0x1266
    // 0xc0f698: add             x4, x4, x17
    // 0xc0f69c: cmp             x4, #0x109
    // 0xc0f6a0: b.ls            #0xc0f6b4
    // 0xc0f6a4: r8 = RenderBox
    //     0xc0f6a4: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0xc0f6a8: r3 = Null
    //     0xc0f6a8: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcc6e0] Null
    //     0xc0f6ac: ldr             x3, [x3, #0x6e0]
    // 0xc0f6b0: r0 = RenderBox()
    //     0xc0f6b0: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0xc0f6b4: ldur            x0, [fp, #-8]
    // 0xc0f6b8: LoadField: r1 = r0->field_f
    //     0xc0f6b8: ldur            w1, [x0, #0xf]
    // 0xc0f6bc: DecompressPointer r1
    //     0xc0f6bc: add             x1, x1, HEAP, lsl #32
    // 0xc0f6c0: ldr             x2, [fp, #0x10]
    // 0xc0f6c4: r0 = redepthChild()
    //     0xc0f6c4: bl              #0xc05584  ; [package:flutter/src/rendering/object.dart] RenderObject::redepthChild
    // 0xc0f6c8: r0 = Null
    //     0xc0f6c8: mov             x0, NULL
    // 0xc0f6cc: LeaveFrame
    //     0xc0f6cc: mov             SP, fp
    //     0xc0f6d0: ldp             fp, lr, [SP], #0x10
    // 0xc0f6d4: ret
    //     0xc0f6d4: ret             
    // 0xc0f6d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc0f6d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc0f6dc: b               #0xc0f680
  }
  _ paint(/* No info */) {
    // ** addr: 0xc255b8, size: 0x7c
    // 0xc255b8: EnterFrame
    //     0xc255b8: stp             fp, lr, [SP, #-0x10]!
    //     0xc255bc: mov             fp, SP
    // 0xc255c0: AllocStack(0x18)
    //     0xc255c0: sub             SP, SP, #0x18
    // 0xc255c4: SetupParameters(_RenderCupertinoTextSelectionToolbarItems this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xc255c4: stur            x1, [fp, #-8]
    //     0xc255c8: stur            x2, [fp, #-0x10]
    //     0xc255cc: stur            x3, [fp, #-0x18]
    // 0xc255d0: CheckStackOverflow
    //     0xc255d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc255d4: cmp             SP, x16
    //     0xc255d8: b.ls            #0xc2562c
    // 0xc255dc: r1 = 3
    //     0xc255dc: mov             x1, #3
    // 0xc255e0: r0 = AllocateContext()
    //     0xc255e0: bl              #0x13de838  ; AllocateContextStub
    // 0xc255e4: mov             x1, x0
    // 0xc255e8: ldur            x0, [fp, #-8]
    // 0xc255ec: StoreField: r1->field_f = r0
    //     0xc255ec: stur            w0, [x1, #0xf]
    // 0xc255f0: ldur            x2, [fp, #-0x10]
    // 0xc255f4: StoreField: r1->field_13 = r2
    //     0xc255f4: stur            w2, [x1, #0x13]
    // 0xc255f8: ldur            x2, [fp, #-0x18]
    // 0xc255fc: ArrayStore: r1[0] = r2  ; List_4
    //     0xc255fc: stur            w2, [x1, #0x17]
    // 0xc25600: mov             x2, x1
    // 0xc25604: r1 = Function '<anonymous closure>':.
    //     0xc25604: add             x1, PP, #0xcc, lsl #12  ; [pp+0xcc748] AnonymousClosure: (0xc25634), in [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarItems::paint (0xc255b8)
    //     0xc25608: ldr             x1, [x1, #0x748]
    // 0xc2560c: r0 = AllocateClosure()
    //     0xc2560c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc25610: ldur            x1, [fp, #-8]
    // 0xc25614: mov             x2, x0
    // 0xc25618: r0 = visitChildren()
    //     0xc25618: bl              #0xbeeed4  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarItems::visitChildren
    // 0xc2561c: r0 = Null
    //     0xc2561c: mov             x0, NULL
    // 0xc25620: LeaveFrame
    //     0xc25620: mov             SP, fp
    //     0xc25624: ldp             fp, lr, [SP], #0x10
    // 0xc25628: ret
    //     0xc25628: ret             
    // 0xc2562c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc2562c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc25630: b               #0xc255dc
  }
  [closure] void <anonymous closure>(dynamic, RenderObject) {
    // ** addr: 0xc25634, size: 0x224
    // 0xc25634: EnterFrame
    //     0xc25634: stp             fp, lr, [SP, #-0x10]!
    //     0xc25638: mov             fp, SP
    // 0xc2563c: AllocStack(0x50)
    //     0xc2563c: sub             SP, SP, #0x50
    // 0xc25640: SetupParameters([dynamic _ /* r0 */])
    //     0xc25640: ldr             x0, [fp, #0x18]
    //     0xc25644: ldur            w3, [x0, #0x17]
    //     0xc25648: add             x3, x3, HEAP, lsl #32
    //     0xc2564c: stur            x3, [fp, #-8]
    // 0xc25650: CheckStackOverflow
    //     0xc25650: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc25654: cmp             SP, x16
    //     0xc25658: b.ls            #0xc2584c
    // 0xc2565c: ldr             x0, [fp, #0x10]
    // 0xc25660: r2 = Null
    //     0xc25660: mov             x2, NULL
    // 0xc25664: r1 = Null
    //     0xc25664: mov             x1, NULL
    // 0xc25668: r4 = LoadClassIdInstr(r0)
    //     0xc25668: ldur            x4, [x0, #-1]
    //     0xc2566c: ubfx            x4, x4, #0xc, #0x14
    // 0xc25670: r17 = -4710
    //     0xc25670: mov             x17, #-0x1266
    // 0xc25674: add             x4, x4, x17
    // 0xc25678: cmp             x4, #0x109
    // 0xc2567c: b.ls            #0xc25690
    // 0xc25680: r8 = RenderBox
    //     0xc25680: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0xc25684: r3 = Null
    //     0xc25684: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcc750] Null
    //     0xc25688: ldr             x3, [x3, #0x750]
    // 0xc2568c: r0 = RenderBox()
    //     0xc2568c: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0xc25690: ldr             x3, [fp, #0x10]
    // 0xc25694: LoadField: r4 = r3->field_7
    //     0xc25694: ldur            w4, [x3, #7]
    // 0xc25698: DecompressPointer r4
    //     0xc25698: add             x4, x4, HEAP, lsl #32
    // 0xc2569c: stur            x4, [fp, #-0x10]
    // 0xc256a0: cmp             w4, NULL
    // 0xc256a4: b.eq            #0xc25854
    // 0xc256a8: mov             x0, x4
    // 0xc256ac: r2 = Null
    //     0xc256ac: mov             x2, NULL
    // 0xc256b0: r1 = Null
    //     0xc256b0: mov             x1, NULL
    // 0xc256b4: r4 = LoadClassIdInstr(r0)
    //     0xc256b4: ldur            x4, [x0, #-1]
    //     0xc256b8: ubfx            x4, x4, #0xc, #0x14
    // 0xc256bc: r17 = 4205
    //     0xc256bc: mov             x17, #0x106d
    // 0xc256c0: cmp             x4, x17
    // 0xc256c4: b.eq            #0xc256dc
    // 0xc256c8: r8 = ToolbarItemsParentData
    //     0xc256c8: add             x8, PP, #0xcc, lsl #12  ; [pp+0xcc6c0] Type: ToolbarItemsParentData
    //     0xc256cc: ldr             x8, [x8, #0x6c0]
    // 0xc256d0: r3 = Null
    //     0xc256d0: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcc760] Null
    //     0xc256d4: ldr             x3, [x3, #0x760]
    // 0xc256d8: r0 = DefaultTypeTest()
    //     0xc256d8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xc256dc: ldur            x0, [fp, #-0x10]
    // 0xc256e0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xc256e0: ldur            w1, [x0, #0x17]
    // 0xc256e4: DecompressPointer r1
    //     0xc256e4: add             x1, x1, HEAP, lsl #32
    // 0xc256e8: tbnz            w1, #4, #0xc2583c
    // 0xc256ec: ldur            x3, [fp, #-8]
    // 0xc256f0: LoadField: r1 = r0->field_7
    //     0xc256f0: ldur            w1, [x0, #7]
    // 0xc256f4: DecompressPointer r1
    //     0xc256f4: add             x1, x1, HEAP, lsl #32
    // 0xc256f8: ArrayLoad: r2 = r3[0]  ; List_4
    //     0xc256f8: ldur            w2, [x3, #0x17]
    // 0xc256fc: DecompressPointer r2
    //     0xc256fc: add             x2, x2, HEAP, lsl #32
    // 0xc25700: r0 = +()
    //     0xc25700: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0xc25704: mov             x4, x0
    // 0xc25708: ldur            x0, [fp, #-8]
    // 0xc2570c: stur            x4, [fp, #-0x18]
    // 0xc25710: LoadField: r1 = r0->field_13
    //     0xc25710: ldur            w1, [x0, #0x13]
    // 0xc25714: DecompressPointer r1
    //     0xc25714: add             x1, x1, HEAP, lsl #32
    // 0xc25718: ldr             x2, [fp, #0x10]
    // 0xc2571c: mov             x3, x4
    // 0xc25720: r0 = paintChild()
    //     0xc25720: bl              #0xc169c4  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0xc25724: ldur            x0, [fp, #-0x10]
    // 0xc25728: LoadField: r1 = r0->field_13
    //     0xc25728: ldur            w1, [x0, #0x13]
    // 0xc2572c: DecompressPointer r1
    //     0xc2572c: add             x1, x1, HEAP, lsl #32
    // 0xc25730: cmp             w1, NULL
    // 0xc25734: b.eq            #0xc25744
    // 0xc25738: ldr             x2, [fp, #0x10]
    // 0xc2573c: ldur            x0, [fp, #-8]
    // 0xc25740: b               #0xc25764
    // 0xc25744: ldr             x2, [fp, #0x10]
    // 0xc25748: ldur            x0, [fp, #-8]
    // 0xc2574c: LoadField: r1 = r0->field_f
    //     0xc2574c: ldur            w1, [x0, #0xf]
    // 0xc25750: DecompressPointer r1
    //     0xc25750: add             x1, x1, HEAP, lsl #32
    // 0xc25754: LoadField: r3 = r1->field_7f
    //     0xc25754: ldur            w3, [x1, #0x7f]
    // 0xc25758: DecompressPointer r3
    //     0xc25758: add             x3, x3, HEAP, lsl #32
    // 0xc2575c: cmp             w2, w3
    // 0xc25760: b.ne            #0xc2583c
    // 0xc25764: LoadField: r1 = r0->field_13
    //     0xc25764: ldur            w1, [x0, #0x13]
    // 0xc25768: DecompressPointer r1
    //     0xc25768: add             x1, x1, HEAP, lsl #32
    // 0xc2576c: r0 = canvas()
    //     0xc2576c: bl              #0xc17694  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0xc25770: ldr             x1, [fp, #0x10]
    // 0xc25774: stur            x0, [fp, #-0x10]
    // 0xc25778: r0 = size()
    //     0xc25778: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc2577c: LoadField: d0 = r0->field_7
    //     0xc2577c: ldur            d0, [x0, #7]
    // 0xc25780: stur            d0, [fp, #-0x38]
    // 0xc25784: r0 = Offset()
    //     0xc25784: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xc25788: ldur            d0, [fp, #-0x38]
    // 0xc2578c: StoreField: r0->field_7 = d0
    //     0xc2578c: stur            d0, [x0, #7]
    // 0xc25790: StoreField: r0->field_f = rZR
    //     0xc25790: stur            xzr, [x0, #0xf]
    // 0xc25794: mov             x1, x0
    // 0xc25798: ldur            x2, [fp, #-0x18]
    // 0xc2579c: r0 = +()
    //     0xc2579c: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0xc257a0: ldr             x1, [fp, #0x10]
    // 0xc257a4: stur            x0, [fp, #-0x20]
    // 0xc257a8: r0 = size()
    //     0xc257a8: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc257ac: LoadField: d0 = r0->field_7
    //     0xc257ac: ldur            d0, [x0, #7]
    // 0xc257b0: ldr             x1, [fp, #0x10]
    // 0xc257b4: stur            d0, [fp, #-0x38]
    // 0xc257b8: r0 = size()
    //     0xc257b8: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc257bc: LoadField: d0 = r0->field_f
    //     0xc257bc: ldur            d0, [x0, #0xf]
    // 0xc257c0: stur            d0, [fp, #-0x40]
    // 0xc257c4: r0 = Offset()
    //     0xc257c4: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xc257c8: ldur            d0, [fp, #-0x38]
    // 0xc257cc: StoreField: r0->field_7 = d0
    //     0xc257cc: stur            d0, [x0, #7]
    // 0xc257d0: ldur            d0, [fp, #-0x40]
    // 0xc257d4: StoreField: r0->field_f = d0
    //     0xc257d4: stur            d0, [x0, #0xf]
    // 0xc257d8: mov             x1, x0
    // 0xc257dc: ldur            x2, [fp, #-0x18]
    // 0xc257e0: r0 = +()
    //     0xc257e0: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0xc257e4: stur            x0, [fp, #-0x18]
    // 0xc257e8: r16 = 136
    //     0xc257e8: mov             x16, #0x88
    // 0xc257ec: stp             x16, NULL, [SP]
    // 0xc257f0: r0 = ByteData()
    //     0xc257f0: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xc257f4: stur            x0, [fp, #-0x28]
    // 0xc257f8: r0 = Paint()
    //     0xc257f8: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xc257fc: mov             x3, x0
    // 0xc25800: ldur            x0, [fp, #-0x28]
    // 0xc25804: stur            x3, [fp, #-0x30]
    // 0xc25808: StoreField: r3->field_7 = r0
    //     0xc25808: stur            w0, [x3, #7]
    // 0xc2580c: ldur            x0, [fp, #-8]
    // 0xc25810: LoadField: r1 = r0->field_f
    //     0xc25810: ldur            w1, [x0, #0xf]
    // 0xc25814: DecompressPointer r1
    //     0xc25814: add             x1, x1, HEAP, lsl #32
    // 0xc25818: LoadField: r2 = r1->field_73
    //     0xc25818: ldur            w2, [x1, #0x73]
    // 0xc2581c: DecompressPointer r2
    //     0xc2581c: add             x2, x2, HEAP, lsl #32
    // 0xc25820: mov             x1, x3
    // 0xc25824: r0 = color=()
    //     0xc25824: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xc25828: ldur            x1, [fp, #-0x10]
    // 0xc2582c: ldur            x2, [fp, #-0x20]
    // 0xc25830: ldur            x3, [fp, #-0x18]
    // 0xc25834: ldur            x5, [fp, #-0x30]
    // 0xc25838: r0 = drawLine()
    //     0xc25838: bl              #0xb6932c  ; [dart:ui] _NativeCanvas::drawLine
    // 0xc2583c: r0 = Null
    //     0xc2583c: mov             x0, NULL
    // 0xc25840: LeaveFrame
    //     0xc25840: mov             SP, fp
    //     0xc25844: ldp             fp, lr, [SP], #0x10
    // 0xc25848: ret
    //     0xc25848: ret             
    // 0xc2584c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc2584c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc25850: b               #0xc2565c
    // 0xc25854: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc25854: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ dividerWidth=(/* No info */) {
    // ** addr: 0xcfe5d0, size: 0x50
    // 0xcfe5d0: EnterFrame
    //     0xcfe5d0: stp             fp, lr, [SP, #-0x10]!
    //     0xcfe5d4: mov             fp, SP
    // 0xcfe5d8: CheckStackOverflow
    //     0xcfe5d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcfe5dc: cmp             SP, x16
    //     0xcfe5e0: b.ls            #0xcfe618
    // 0xcfe5e4: LoadField: d1 = r1->field_77
    //     0xcfe5e4: ldur            d1, [x1, #0x77]
    // 0xcfe5e8: fcmp            d0, d1
    // 0xcfe5ec: b.ne            #0xcfe600
    // 0xcfe5f0: r0 = Null
    //     0xcfe5f0: mov             x0, NULL
    // 0xcfe5f4: LeaveFrame
    //     0xcfe5f4: mov             SP, fp
    //     0xcfe5f8: ldp             fp, lr, [SP], #0x10
    // 0xcfe5fc: ret
    //     0xcfe5fc: ret             
    // 0xcfe600: StoreField: r1->field_77 = d0
    //     0xcfe600: stur            d0, [x1, #0x77]
    // 0xcfe604: r0 = markNeedsLayout()
    //     0xcfe604: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcfe608: r0 = Null
    //     0xcfe608: mov             x0, NULL
    // 0xcfe60c: LeaveFrame
    //     0xcfe60c: mov             SP, fp
    //     0xcfe610: ldp             fp, lr, [SP], #0x10
    // 0xcfe614: ret
    //     0xcfe614: ret             
    // 0xcfe618: r0 = StackOverflowSharedWithFPURegs()
    //     0xcfe618: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xcfe61c: b               #0xcfe5e4
  }
  set _ dividerColor=(/* No info */) {
    // ** addr: 0xcfe620, size: 0x88
    // 0xcfe620: EnterFrame
    //     0xcfe620: stp             fp, lr, [SP, #-0x10]!
    //     0xcfe624: mov             fp, SP
    // 0xcfe628: AllocStack(0x20)
    //     0xcfe628: sub             SP, SP, #0x20
    // 0xcfe62c: SetupParameters(_RenderCupertinoTextSelectionToolbarItems this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xcfe62c: mov             x0, x2
    //     0xcfe630: stur            x1, [fp, #-8]
    //     0xcfe634: stur            x2, [fp, #-0x10]
    // 0xcfe638: CheckStackOverflow
    //     0xcfe638: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcfe63c: cmp             SP, x16
    //     0xcfe640: b.ls            #0xcfe6a0
    // 0xcfe644: LoadField: r2 = r1->field_73
    //     0xcfe644: ldur            w2, [x1, #0x73]
    // 0xcfe648: DecompressPointer r2
    //     0xcfe648: add             x2, x2, HEAP, lsl #32
    // 0xcfe64c: stp             x2, x0, [SP]
    // 0xcfe650: r0 = ==()
    //     0xcfe650: bl              #0x12629d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::==
    // 0xcfe654: tbnz            w0, #4, #0xcfe668
    // 0xcfe658: r0 = Null
    //     0xcfe658: mov             x0, NULL
    // 0xcfe65c: LeaveFrame
    //     0xcfe65c: mov             SP, fp
    //     0xcfe660: ldp             fp, lr, [SP], #0x10
    // 0xcfe664: ret
    //     0xcfe664: ret             
    // 0xcfe668: ldur            x1, [fp, #-8]
    // 0xcfe66c: ldur            x0, [fp, #-0x10]
    // 0xcfe670: StoreField: r1->field_73 = r0
    //     0xcfe670: stur            w0, [x1, #0x73]
    //     0xcfe674: ldurb           w16, [x1, #-1]
    //     0xcfe678: ldurb           w17, [x0, #-1]
    //     0xcfe67c: and             x16, x17, x16, lsr #2
    //     0xcfe680: tst             x16, HEAP, lsr #32
    //     0xcfe684: b.eq            #0xcfe68c
    //     0xcfe688: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcfe68c: r0 = markNeedsLayout()
    //     0xcfe68c: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcfe690: r0 = Null
    //     0xcfe690: mov             x0, NULL
    // 0xcfe694: LeaveFrame
    //     0xcfe694: mov             SP, fp
    //     0xcfe698: ldp             fp, lr, [SP], #0x10
    // 0xcfe69c: ret
    //     0xcfe69c: ret             
    // 0xcfe6a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcfe6a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcfe6a4: b               #0xcfe644
  }
  set _ page=(/* No info */) {
    // ** addr: 0xcfe6a8, size: 0x50
    // 0xcfe6a8: EnterFrame
    //     0xcfe6a8: stp             fp, lr, [SP, #-0x10]!
    //     0xcfe6ac: mov             fp, SP
    // 0xcfe6b0: CheckStackOverflow
    //     0xcfe6b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcfe6b4: cmp             SP, x16
    //     0xcfe6b8: b.ls            #0xcfe6f0
    // 0xcfe6bc: LoadField: r0 = r1->field_6b
    //     0xcfe6bc: ldur            x0, [x1, #0x6b]
    // 0xcfe6c0: cmp             x2, x0
    // 0xcfe6c4: b.ne            #0xcfe6d8
    // 0xcfe6c8: r0 = Null
    //     0xcfe6c8: mov             x0, NULL
    // 0xcfe6cc: LeaveFrame
    //     0xcfe6cc: mov             SP, fp
    //     0xcfe6d0: ldp             fp, lr, [SP], #0x10
    // 0xcfe6d4: ret
    //     0xcfe6d4: ret             
    // 0xcfe6d8: StoreField: r1->field_6b = r2
    //     0xcfe6d8: stur            x2, [x1, #0x6b]
    // 0xcfe6dc: r0 = markNeedsLayout()
    //     0xcfe6dc: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcfe6e0: r0 = Null
    //     0xcfe6e0: mov             x0, NULL
    // 0xcfe6e4: LeaveFrame
    //     0xcfe6e4: mov             SP, fp
    //     0xcfe6e8: ldp             fp, lr, [SP], #0x10
    // 0xcfe6ec: ret
    //     0xcfe6ec: ret             
    // 0xcfe6f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcfe6f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcfe6f4: b               #0xcfe6bc
  }
  _ hitTestChildren(/* No info */) {
    // ** addr: 0x10ead00, size: 0x1c4
    // 0x10ead00: EnterFrame
    //     0x10ead00: stp             fp, lr, [SP, #-0x10]!
    //     0x10ead04: mov             fp, SP
    // 0x10ead08: AllocStack(0x30)
    //     0x10ead08: sub             SP, SP, #0x30
    // 0x10ead0c: SetupParameters(_RenderCupertinoTextSelectionToolbarItems this /* r1 => r4, fp-0x18 */, dynamic _ /* r2 => r3, fp-0x20 */, dynamic _ /* r3 => r5, fp-0x28 */)
    //     0x10ead0c: mov             x4, x1
    //     0x10ead10: mov             x5, x3
    //     0x10ead14: stur            x3, [fp, #-0x28]
    //     0x10ead18: mov             x3, x2
    //     0x10ead1c: stur            x1, [fp, #-0x18]
    //     0x10ead20: stur            x2, [fp, #-0x20]
    // 0x10ead24: CheckStackOverflow
    //     0x10ead24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10ead28: cmp             SP, x16
    //     0x10ead2c: b.ls            #0x10eaeb0
    // 0x10ead30: LoadField: r0 = r4->field_5b
    //     0x10ead30: ldur            w0, [x4, #0x5b]
    // 0x10ead34: DecompressPointer r0
    //     0x10ead34: add             x0, x0, HEAP, lsl #32
    // 0x10ead38: mov             x6, x0
    // 0x10ead3c: stur            x6, [fp, #-0x10]
    // 0x10ead40: CheckStackOverflow
    //     0x10ead40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10ead44: cmp             SP, x16
    //     0x10ead48: b.ls            #0x10eaeb8
    // 0x10ead4c: cmp             w6, NULL
    // 0x10ead50: b.eq            #0x10eae48
    // 0x10ead54: LoadField: r7 = r6->field_7
    //     0x10ead54: ldur            w7, [x6, #7]
    // 0x10ead58: DecompressPointer r7
    //     0x10ead58: add             x7, x7, HEAP, lsl #32
    // 0x10ead5c: stur            x7, [fp, #-8]
    // 0x10ead60: cmp             w7, NULL
    // 0x10ead64: b.eq            #0x10eaec0
    // 0x10ead68: mov             x0, x7
    // 0x10ead6c: r2 = Null
    //     0x10ead6c: mov             x2, NULL
    // 0x10ead70: r1 = Null
    //     0x10ead70: mov             x1, NULL
    // 0x10ead74: r4 = LoadClassIdInstr(r0)
    //     0x10ead74: ldur            x4, [x0, #-1]
    //     0x10ead78: ubfx            x4, x4, #0xc, #0x14
    // 0x10ead7c: r17 = 4205
    //     0x10ead7c: mov             x17, #0x106d
    // 0x10ead80: cmp             x4, x17
    // 0x10ead84: b.eq            #0x10ead9c
    // 0x10ead88: r8 = ToolbarItemsParentData
    //     0x10ead88: add             x8, PP, #0xcc, lsl #12  ; [pp+0xcc6c0] Type: ToolbarItemsParentData
    //     0x10ead8c: ldr             x8, [x8, #0x6c0]
    // 0x10ead90: r3 = Null
    //     0x10ead90: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcc710] Null
    //     0x10ead94: ldr             x3, [x3, #0x710]
    // 0x10ead98: r0 = DefaultTypeTest()
    //     0x10ead98: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x10ead9c: ldur            x0, [fp, #-8]
    // 0x10eada0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x10eada0: ldur            w1, [x0, #0x17]
    // 0x10eada4: DecompressPointer r1
    //     0x10eada4: add             x1, x1, HEAP, lsl #32
    // 0x10eada8: stur            x1, [fp, #-0x30]
    // 0x10eadac: tbz             w1, #4, #0x10eadc0
    // 0x10eadb0: LoadField: r1 = r0->field_f
    //     0x10eadb0: ldur            w1, [x0, #0xf]
    // 0x10eadb4: DecompressPointer r1
    //     0x10eadb4: add             x1, x1, HEAP, lsl #32
    // 0x10eadb8: mov             x6, x1
    // 0x10eadbc: b               #0x10eae28
    // 0x10eadc0: ldur            x2, [fp, #-0x10]
    // 0x10eadc4: r1 = 1
    //     0x10eadc4: mov             x1, #1
    // 0x10eadc8: r0 = AllocateContext()
    //     0x10eadc8: bl              #0x13de838  ; AllocateContextStub
    // 0x10eadcc: mov             x1, x0
    // 0x10eadd0: ldur            x0, [fp, #-0x10]
    // 0x10eadd4: StoreField: r1->field_f = r0
    //     0x10eadd4: stur            w0, [x1, #0xf]
    // 0x10eadd8: ldur            x0, [fp, #-0x30]
    // 0x10eaddc: tbnz            w0, #4, #0x10eae18
    // 0x10eade0: ldur            x0, [fp, #-8]
    // 0x10eade4: LoadField: r3 = r0->field_7
    //     0x10eade4: ldur            w3, [x0, #7]
    // 0x10eade8: DecompressPointer r3
    //     0x10eade8: add             x3, x3, HEAP, lsl #32
    // 0x10eadec: mov             x2, x1
    // 0x10eadf0: stur            x3, [fp, #-0x10]
    // 0x10eadf4: r1 = Function '<anonymous closure>': static.
    //     0x10eadf4: add             x1, PP, #0xcc, lsl #12  ; [pp+0xcc720] AnonymousClosure: (0x10e9b40), in [package:flutter/src/rendering/shifted_box.dart] RenderShiftedBox::hitTestChildren (0x10e9a40)
    //     0x10eadf8: ldr             x1, [x1, #0x720]
    // 0x10eadfc: r0 = AllocateClosure()
    //     0x10eadfc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10eae00: ldur            x1, [fp, #-0x20]
    // 0x10eae04: mov             x2, x0
    // 0x10eae08: ldur            x3, [fp, #-0x10]
    // 0x10eae0c: ldur            x5, [fp, #-0x28]
    // 0x10eae10: r0 = addWithPaintOffset()
    //     0x10eae10: bl              #0xaf9d3c  ; [package:flutter/src/rendering/box.dart] BoxHitTestResult::addWithPaintOffset
    // 0x10eae14: tbz             w0, #4, #0x10eae38
    // 0x10eae18: ldur            x0, [fp, #-8]
    // 0x10eae1c: LoadField: r1 = r0->field_f
    //     0x10eae1c: ldur            w1, [x0, #0xf]
    // 0x10eae20: DecompressPointer r1
    //     0x10eae20: add             x1, x1, HEAP, lsl #32
    // 0x10eae24: mov             x6, x1
    // 0x10eae28: ldur            x4, [fp, #-0x18]
    // 0x10eae2c: ldur            x3, [fp, #-0x20]
    // 0x10eae30: ldur            x5, [fp, #-0x28]
    // 0x10eae34: b               #0x10ead3c
    // 0x10eae38: r0 = true
    //     0x10eae38: add             x0, NULL, #0x20  ; true
    // 0x10eae3c: LeaveFrame
    //     0x10eae3c: mov             SP, fp
    //     0x10eae40: ldp             fp, lr, [SP], #0x10
    // 0x10eae44: ret
    //     0x10eae44: ret             
    // 0x10eae48: mov             x0, x4
    // 0x10eae4c: LoadField: r1 = r0->field_7f
    //     0x10eae4c: ldur            w1, [x0, #0x7f]
    // 0x10eae50: DecompressPointer r1
    //     0x10eae50: add             x1, x1, HEAP, lsl #32
    // 0x10eae54: ldur            x2, [fp, #-0x20]
    // 0x10eae58: ldur            x3, [fp, #-0x28]
    // 0x10eae5c: r0 = hitTestChild()
    //     0x10eae5c: bl              #0x10eaec4  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarItems::hitTestChild
    // 0x10eae60: tbnz            w0, #4, #0x10eae74
    // 0x10eae64: r0 = true
    //     0x10eae64: add             x0, NULL, #0x20  ; true
    // 0x10eae68: LeaveFrame
    //     0x10eae68: mov             SP, fp
    //     0x10eae6c: ldp             fp, lr, [SP], #0x10
    // 0x10eae70: ret
    //     0x10eae70: ret             
    // 0x10eae74: ldur            x0, [fp, #-0x18]
    // 0x10eae78: LoadField: r1 = r0->field_83
    //     0x10eae78: ldur            w1, [x0, #0x83]
    // 0x10eae7c: DecompressPointer r1
    //     0x10eae7c: add             x1, x1, HEAP, lsl #32
    // 0x10eae80: ldur            x2, [fp, #-0x20]
    // 0x10eae84: ldur            x3, [fp, #-0x28]
    // 0x10eae88: r0 = hitTestChild()
    //     0x10eae88: bl              #0x10eaec4  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarItems::hitTestChild
    // 0x10eae8c: tbnz            w0, #4, #0x10eaea0
    // 0x10eae90: r0 = true
    //     0x10eae90: add             x0, NULL, #0x20  ; true
    // 0x10eae94: LeaveFrame
    //     0x10eae94: mov             SP, fp
    //     0x10eae98: ldp             fp, lr, [SP], #0x10
    // 0x10eae9c: ret
    //     0x10eae9c: ret             
    // 0x10eaea0: r0 = false
    //     0x10eaea0: add             x0, NULL, #0x30  ; false
    // 0x10eaea4: LeaveFrame
    //     0x10eaea4: mov             SP, fp
    //     0x10eaea8: ldp             fp, lr, [SP], #0x10
    // 0x10eaeac: ret
    //     0x10eaeac: ret             
    // 0x10eaeb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10eaeb0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10eaeb4: b               #0x10ead30
    // 0x10eaeb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10eaeb8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10eaebc: b               #0x10ead4c
    // 0x10eaec0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10eaec0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static _ hitTestChild(/* No info */) {
    // ** addr: 0x10eaec4, size: 0x110
    // 0x10eaec4: EnterFrame
    //     0x10eaec4: stp             fp, lr, [SP, #-0x10]!
    //     0x10eaec8: mov             fp, SP
    // 0x10eaecc: AllocStack(0x28)
    //     0x10eaecc: sub             SP, SP, #0x28
    // 0x10eaed0: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */, dynamic _ /* r3 => r5, fp-0x18 */)
    //     0x10eaed0: mov             x0, x1
    //     0x10eaed4: stur            x1, [fp, #-8]
    //     0x10eaed8: mov             x1, x2
    //     0x10eaedc: mov             x5, x3
    //     0x10eaee0: stur            x2, [fp, #-0x10]
    //     0x10eaee4: stur            x3, [fp, #-0x18]
    // 0x10eaee8: CheckStackOverflow
    //     0x10eaee8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10eaeec: cmp             SP, x16
    //     0x10eaef0: b.ls            #0x10eafc8
    // 0x10eaef4: r1 = 1
    //     0x10eaef4: mov             x1, #1
    // 0x10eaef8: r0 = AllocateContext()
    //     0x10eaef8: bl              #0x13de838  ; AllocateContextStub
    // 0x10eaefc: mov             x3, x0
    // 0x10eaf00: ldur            x0, [fp, #-8]
    // 0x10eaf04: stur            x3, [fp, #-0x28]
    // 0x10eaf08: StoreField: r3->field_f = r0
    //     0x10eaf08: stur            w0, [x3, #0xf]
    // 0x10eaf0c: cmp             w0, NULL
    // 0x10eaf10: b.ne            #0x10eaf24
    // 0x10eaf14: r0 = false
    //     0x10eaf14: add             x0, NULL, #0x30  ; false
    // 0x10eaf18: LeaveFrame
    //     0x10eaf18: mov             SP, fp
    //     0x10eaf1c: ldp             fp, lr, [SP], #0x10
    // 0x10eaf20: ret
    //     0x10eaf20: ret             
    // 0x10eaf24: LoadField: r4 = r0->field_7
    //     0x10eaf24: ldur            w4, [x0, #7]
    // 0x10eaf28: DecompressPointer r4
    //     0x10eaf28: add             x4, x4, HEAP, lsl #32
    // 0x10eaf2c: stur            x4, [fp, #-0x20]
    // 0x10eaf30: cmp             w4, NULL
    // 0x10eaf34: b.eq            #0x10eafd0
    // 0x10eaf38: mov             x0, x4
    // 0x10eaf3c: r2 = Null
    //     0x10eaf3c: mov             x2, NULL
    // 0x10eaf40: r1 = Null
    //     0x10eaf40: mov             x1, NULL
    // 0x10eaf44: r4 = LoadClassIdInstr(r0)
    //     0x10eaf44: ldur            x4, [x0, #-1]
    //     0x10eaf48: ubfx            x4, x4, #0xc, #0x14
    // 0x10eaf4c: r17 = 4205
    //     0x10eaf4c: mov             x17, #0x106d
    // 0x10eaf50: cmp             x4, x17
    // 0x10eaf54: b.eq            #0x10eaf6c
    // 0x10eaf58: r8 = ToolbarItemsParentData
    //     0x10eaf58: add             x8, PP, #0xcc, lsl #12  ; [pp+0xcc6c0] Type: ToolbarItemsParentData
    //     0x10eaf5c: ldr             x8, [x8, #0x6c0]
    // 0x10eaf60: r3 = Null
    //     0x10eaf60: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcc728] Null
    //     0x10eaf64: ldr             x3, [x3, #0x728]
    // 0x10eaf68: r0 = DefaultTypeTest()
    //     0x10eaf68: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x10eaf6c: ldur            x0, [fp, #-0x20]
    // 0x10eaf70: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x10eaf70: ldur            w1, [x0, #0x17]
    // 0x10eaf74: DecompressPointer r1
    //     0x10eaf74: add             x1, x1, HEAP, lsl #32
    // 0x10eaf78: tbz             w1, #4, #0x10eaf8c
    // 0x10eaf7c: r0 = false
    //     0x10eaf7c: add             x0, NULL, #0x30  ; false
    // 0x10eaf80: LeaveFrame
    //     0x10eaf80: mov             SP, fp
    //     0x10eaf84: ldp             fp, lr, [SP], #0x10
    // 0x10eaf88: ret
    //     0x10eaf88: ret             
    // 0x10eaf8c: LoadField: r3 = r0->field_7
    //     0x10eaf8c: ldur            w3, [x0, #7]
    // 0x10eaf90: DecompressPointer r3
    //     0x10eaf90: add             x3, x3, HEAP, lsl #32
    // 0x10eaf94: ldur            x2, [fp, #-0x28]
    // 0x10eaf98: stur            x3, [fp, #-8]
    // 0x10eaf9c: r1 = Function '<anonymous closure>': static.
    //     0x10eaf9c: add             x1, PP, #0xcc, lsl #12  ; [pp+0xcc720] AnonymousClosure: (0x10e9b40), in [package:flutter/src/rendering/shifted_box.dart] RenderShiftedBox::hitTestChildren (0x10e9a40)
    //     0x10eafa0: ldr             x1, [x1, #0x720]
    // 0x10eafa4: r0 = AllocateClosure()
    //     0x10eafa4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10eafa8: ldur            x1, [fp, #-0x10]
    // 0x10eafac: mov             x2, x0
    // 0x10eafb0: ldur            x3, [fp, #-8]
    // 0x10eafb4: ldur            x5, [fp, #-0x18]
    // 0x10eafb8: r0 = addWithPaintOffset()
    //     0x10eafb8: bl              #0xaf9d3c  ; [package:flutter/src/rendering/box.dart] BoxHitTestResult::addWithPaintOffset
    // 0x10eafbc: LeaveFrame
    //     0x10eafbc: mov             SP, fp
    //     0x10eafc0: ldp             fp, lr, [SP], #0x10
    // 0x10eafc4: ret
    //     0x10eafc4: ret             
    // 0x10eafc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10eafc8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10eafcc: b               #0x10eaef4
    // 0x10eafd0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10eafd0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ nextButton=(/* No info */) {
    // ** addr: 0x114624c, size: 0x74
    // 0x114624c: EnterFrame
    //     0x114624c: stp             fp, lr, [SP, #-0x10]!
    //     0x1146250: mov             fp, SP
    // 0x1146254: AllocStack(0x8)
    //     0x1146254: sub             SP, SP, #8
    // 0x1146258: SetupParameters(_RenderCupertinoTextSelectionToolbarItems this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r3 */)
    //     0x1146258: mov             x0, x1
    //     0x114625c: mov             x3, x2
    //     0x1146260: stur            x1, [fp, #-8]
    // 0x1146264: CheckStackOverflow
    //     0x1146264: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1146268: cmp             SP, x16
    //     0x114626c: b.ls            #0x11462b8
    // 0x1146270: LoadField: r2 = r0->field_83
    //     0x1146270: ldur            w2, [x0, #0x83]
    // 0x1146274: DecompressPointer r2
    //     0x1146274: add             x2, x2, HEAP, lsl #32
    // 0x1146278: mov             x1, x0
    // 0x114627c: r5 = Instance__CupertinoTextSelectionToolbarItemsSlot
    //     0x114627c: add             x5, PP, #0xcc, lsl #12  ; [pp+0xcc590] Obj!_CupertinoTextSelectionToolbarItemsSlot@12c5fa1
    //     0x1146280: ldr             x5, [x5, #0x590]
    // 0x1146284: r0 = _updateChild()
    //     0x1146284: bl              #0x11462c0  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarItems::_updateChild
    // 0x1146288: ldur            x1, [fp, #-8]
    // 0x114628c: StoreField: r1->field_83 = r0
    //     0x114628c: stur            w0, [x1, #0x83]
    //     0x1146290: ldurb           w16, [x1, #-1]
    //     0x1146294: ldurb           w17, [x0, #-1]
    //     0x1146298: and             x16, x17, x16, lsr #2
    //     0x114629c: tst             x16, HEAP, lsr #32
    //     0x11462a0: b.eq            #0x11462a8
    //     0x11462a4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11462a8: r0 = Null
    //     0x11462a8: mov             x0, NULL
    // 0x11462ac: LeaveFrame
    //     0x11462ac: mov             SP, fp
    //     0x11462b0: ldp             fp, lr, [SP], #0x10
    // 0x11462b4: ret
    //     0x11462b4: ret             
    // 0x11462b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11462b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11462bc: b               #0x1146270
  }
  _ _updateChild(/* No info */) {
    // ** addr: 0x11462c0, size: 0x98
    // 0x11462c0: EnterFrame
    //     0x11462c0: stp             fp, lr, [SP, #-0x10]!
    //     0x11462c4: mov             fp, SP
    // 0x11462c8: AllocStack(0x18)
    //     0x11462c8: sub             SP, SP, #0x18
    // 0x11462cc: SetupParameters(_RenderCupertinoTextSelectionToolbarItems this /* r1 => r4, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */, dynamic _ /* r5 => r0, fp-0x18 */)
    //     0x11462cc: mov             x4, x1
    //     0x11462d0: mov             x0, x5
    //     0x11462d4: stur            x1, [fp, #-8]
    //     0x11462d8: stur            x3, [fp, #-0x10]
    //     0x11462dc: stur            x5, [fp, #-0x18]
    // 0x11462e0: CheckStackOverflow
    //     0x11462e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11462e4: cmp             SP, x16
    //     0x11462e8: b.ls            #0x1146350
    // 0x11462ec: cmp             w2, NULL
    // 0x11462f0: b.eq            #0x1146310
    // 0x11462f4: mov             x1, x4
    // 0x11462f8: r0 = dropChild()
    //     0x11462f8: bl              #0xbee868  ; [package:flutter/src/rendering/object.dart] RenderObject::dropChild
    // 0x11462fc: ldur            x0, [fp, #-8]
    // 0x1146300: LoadField: r1 = r0->field_5f
    //     0x1146300: ldur            w1, [x0, #0x5f]
    // 0x1146304: DecompressPointer r1
    //     0x1146304: add             x1, x1, HEAP, lsl #32
    // 0x1146308: ldur            x2, [fp, #-0x18]
    // 0x114630c: r0 = remove()
    //     0x114630c: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x1146310: ldur            x0, [fp, #-0x10]
    // 0x1146314: cmp             w0, NULL
    // 0x1146318: b.eq            #0x1146340
    // 0x114631c: ldur            x4, [fp, #-8]
    // 0x1146320: LoadField: r1 = r4->field_5f
    //     0x1146320: ldur            w1, [x4, #0x5f]
    // 0x1146324: DecompressPointer r1
    //     0x1146324: add             x1, x1, HEAP, lsl #32
    // 0x1146328: ldur            x2, [fp, #-0x18]
    // 0x114632c: mov             x3, x0
    // 0x1146330: r0 = []=()
    //     0x1146330: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x1146334: ldur            x1, [fp, #-8]
    // 0x1146338: ldur            x2, [fp, #-0x10]
    // 0x114633c: r0 = adoptChild()
    //     0x114633c: bl              #0xc05494  ; [package:flutter/src/rendering/object.dart] RenderObject::adoptChild
    // 0x1146340: ldur            x0, [fp, #-0x10]
    // 0x1146344: LeaveFrame
    //     0x1146344: mov             SP, fp
    //     0x1146348: ldp             fp, lr, [SP], #0x10
    // 0x114634c: ret
    //     0x114634c: ret             
    // 0x1146350: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1146350: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1146354: b               #0x11462ec
  }
  set _ backButton=(/* No info */) {
    // ** addr: 0x1146358, size: 0x74
    // 0x1146358: EnterFrame
    //     0x1146358: stp             fp, lr, [SP, #-0x10]!
    //     0x114635c: mov             fp, SP
    // 0x1146360: AllocStack(0x8)
    //     0x1146360: sub             SP, SP, #8
    // 0x1146364: SetupParameters(_RenderCupertinoTextSelectionToolbarItems this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r3 */)
    //     0x1146364: mov             x0, x1
    //     0x1146368: mov             x3, x2
    //     0x114636c: stur            x1, [fp, #-8]
    // 0x1146370: CheckStackOverflow
    //     0x1146370: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1146374: cmp             SP, x16
    //     0x1146378: b.ls            #0x11463c4
    // 0x114637c: LoadField: r2 = r0->field_7f
    //     0x114637c: ldur            w2, [x0, #0x7f]
    // 0x1146380: DecompressPointer r2
    //     0x1146380: add             x2, x2, HEAP, lsl #32
    // 0x1146384: mov             x1, x0
    // 0x1146388: r5 = Instance__CupertinoTextSelectionToolbarItemsSlot
    //     0x1146388: add             x5, PP, #0xcc, lsl #12  ; [pp+0xcc588] Obj!_CupertinoTextSelectionToolbarItemsSlot@12c5fc1
    //     0x114638c: ldr             x5, [x5, #0x588]
    // 0x1146390: r0 = _updateChild()
    //     0x1146390: bl              #0x11462c0  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarItems::_updateChild
    // 0x1146394: ldur            x1, [fp, #-8]
    // 0x1146398: StoreField: r1->field_7f = r0
    //     0x1146398: stur            w0, [x1, #0x7f]
    //     0x114639c: ldurb           w16, [x1, #-1]
    //     0x11463a0: ldurb           w17, [x0, #-1]
    //     0x11463a4: and             x16, x17, x16, lsr #2
    //     0x11463a8: tst             x16, HEAP, lsr #32
    //     0x11463ac: b.eq            #0x11463b4
    //     0x11463b0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11463b4: r0 = Null
    //     0x11463b4: mov             x0, NULL
    // 0x11463b8: LeaveFrame
    //     0x11463b8: mov             SP, fp
    //     0x11463bc: ldp             fp, lr, [SP], #0x10
    // 0x11463c0: ret
    //     0x11463c0: ret             
    // 0x11463c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11463c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11463c8: b               #0x114637c
  }
  _ _RenderCupertinoTextSelectionToolbarItems(/* No info */) {
    // ** addr: 0x11d48f4, size: 0xe8
    // 0x11d48f4: EnterFrame
    //     0x11d48f4: stp             fp, lr, [SP, #-0x10]!
    //     0x11d48f8: mov             fp, SP
    // 0x11d48fc: AllocStack(0x30)
    //     0x11d48fc: sub             SP, SP, #0x30
    // 0x11d4900: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x11d4904: stur            x1, [fp, #-8]
    // 0x11d4908: mov             x16, x2
    // 0x11d490c: mov             x2, x1
    // 0x11d4910: mov             x1, x16
    // 0x11d4914: stur            x1, [fp, #-0x10]
    // 0x11d4918: stur            x3, [fp, #-0x18]
    // 0x11d491c: stur            d0, [fp, #-0x20]
    // 0x11d4920: CheckStackOverflow
    //     0x11d4920: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d4924: cmp             SP, x16
    //     0x11d4928: b.ls            #0x11d49d4
    // 0x11d492c: StoreField: r2->field_63 = r0
    //     0x11d492c: stur            w0, [x2, #0x63]
    // 0x11d4930: StoreField: r2->field_67 = r0
    //     0x11d4930: stur            w0, [x2, #0x67]
    // 0x11d4934: r16 = <_CupertinoTextSelectionToolbarItemsSlot, RenderBox>
    //     0x11d4934: add             x16, PP, #0xac, lsl #12  ; [pp+0xacc48] TypeArguments: <_CupertinoTextSelectionToolbarItemsSlot, RenderBox>
    //     0x11d4938: ldr             x16, [x16, #0xc48]
    // 0x11d493c: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x11d4940: stp             lr, x16, [SP]
    // 0x11d4944: r0 = Map._fromLiteral()
    //     0x11d4944: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x11d4948: ldur            x1, [fp, #-8]
    // 0x11d494c: StoreField: r1->field_5f = r0
    //     0x11d494c: stur            w0, [x1, #0x5f]
    //     0x11d4950: ldurb           w16, [x1, #-1]
    //     0x11d4954: ldurb           w17, [x0, #-1]
    //     0x11d4958: and             x16, x17, x16, lsr #2
    //     0x11d495c: tst             x16, HEAP, lsr #32
    //     0x11d4960: b.eq            #0x11d4968
    //     0x11d4964: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11d4968: ldur            x0, [fp, #-0x10]
    // 0x11d496c: StoreField: r1->field_73 = r0
    //     0x11d496c: stur            w0, [x1, #0x73]
    //     0x11d4970: ldurb           w16, [x1, #-1]
    //     0x11d4974: ldurb           w17, [x0, #-1]
    //     0x11d4978: and             x16, x17, x16, lsr #2
    //     0x11d497c: tst             x16, HEAP, lsr #32
    //     0x11d4980: b.eq            #0x11d4988
    //     0x11d4984: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11d4988: ldur            d0, [fp, #-0x20]
    // 0x11d498c: StoreField: r1->field_77 = d0
    //     0x11d498c: stur            d0, [x1, #0x77]
    // 0x11d4990: ldur            x0, [fp, #-0x18]
    // 0x11d4994: StoreField: r1->field_6b = r0
    //     0x11d4994: stur            x0, [x1, #0x6b]
    // 0x11d4998: StoreField: r1->field_4f = rZR
    //     0x11d4998: stur            xzr, [x1, #0x4f]
    // 0x11d499c: r0 = _LayoutCacheStorage()
    //     0x11d499c: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11d49a0: ldur            x1, [fp, #-8]
    // 0x11d49a4: StoreField: r1->field_47 = r0
    //     0x11d49a4: stur            w0, [x1, #0x47]
    //     0x11d49a8: ldurb           w16, [x1, #-1]
    //     0x11d49ac: ldurb           w17, [x0, #-1]
    //     0x11d49b0: and             x16, x17, x16, lsr #2
    //     0x11d49b4: tst             x16, HEAP, lsr #32
    //     0x11d49b8: b.eq            #0x11d49c0
    //     0x11d49bc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11d49c0: r0 = RenderObject()
    //     0x11d49c0: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11d49c4: r0 = Null
    //     0x11d49c4: mov             x0, NULL
    // 0x11d49c8: LeaveFrame
    //     0x11d49c8: mov             SP, fp
    //     0x11d49cc: ldp             fp, lr, [SP], #0x10
    // 0x11d49d0: ret
    //     0x11d49d0: ret             
    // 0x11d49d4: r0 = StackOverflowSharedWithFPURegs()
    //     0x11d49d4: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x11d49d8: b               #0x11d492c
  }
}

// class id: 4882, size: 0x64, field offset: 0x54
class _RenderCupertinoTextSelectionToolbarShape extends RenderShiftedBox {

  _ computeDryBaseline(/* No info */) {
    // ** addr: 0xb607a8, size: 0x140
    // 0xb607a8: EnterFrame
    //     0xb607a8: stp             fp, lr, [SP, #-0x10]!
    //     0xb607ac: mov             fp, SP
    // 0xb607b0: AllocStack(0x20)
    //     0xb607b0: sub             SP, SP, #0x20
    // 0xb607b4: SetupParameters(_RenderCupertinoTextSelectionToolbarShape this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xb607b4: mov             x5, x1
    //     0xb607b8: mov             x4, x2
    //     0xb607bc: stur            x1, [fp, #-8]
    //     0xb607c0: stur            x2, [fp, #-0x10]
    //     0xb607c4: stur            x3, [fp, #-0x18]
    // 0xb607c8: CheckStackOverflow
    //     0xb607c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb607cc: cmp             SP, x16
    //     0xb607d0: b.ls            #0xb608cc
    // 0xb607d4: mov             x0, x4
    // 0xb607d8: r2 = Null
    //     0xb607d8: mov             x2, NULL
    // 0xb607dc: r1 = Null
    //     0xb607dc: mov             x1, NULL
    // 0xb607e0: r4 = 60
    //     0xb607e0: mov             x4, #0x3c
    // 0xb607e4: branchIfSmi(r0, 0xb607f0)
    //     0xb607e4: tbz             w0, #0, #0xb607f0
    // 0xb607e8: r4 = LoadClassIdInstr(r0)
    //     0xb607e8: ldur            x4, [x0, #-1]
    //     0xb607ec: ubfx            x4, x4, #0xc, #0x14
    // 0xb607f0: sub             x4, x4, #0xb46
    // 0xb607f4: cmp             x4, #1
    // 0xb607f8: b.ls            #0xb6080c
    // 0xb607fc: r8 = BoxConstraints
    //     0xb607fc: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xb60800: r3 = Null
    //     0xb60800: add             x3, PP, #0x98, lsl #12  ; [pp+0x98708] Null
    //     0xb60804: ldr             x3, [x3, #0x708]
    // 0xb60808: r0 = BoxConstraints()
    //     0xb60808: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xb6080c: ldur            x0, [fp, #-8]
    // 0xb60810: LoadField: r3 = r0->field_4f
    //     0xb60810: ldur            w3, [x0, #0x4f]
    // 0xb60814: DecompressPointer r3
    //     0xb60814: add             x3, x3, HEAP, lsl #32
    // 0xb60818: stur            x3, [fp, #-0x20]
    // 0xb6081c: cmp             w3, NULL
    // 0xb60820: b.ne            #0xb60834
    // 0xb60824: r0 = Null
    //     0xb60824: mov             x0, NULL
    // 0xb60828: LeaveFrame
    //     0xb60828: mov             SP, fp
    //     0xb6082c: ldp             fp, lr, [SP], #0x10
    // 0xb60830: ret
    //     0xb60830: ret             
    // 0xb60834: mov             x1, x0
    // 0xb60838: ldur            x2, [fp, #-0x10]
    // 0xb6083c: r0 = _constraintsForChild()
    //     0xb6083c: bl              #0xb60970  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarShape::_constraintsForChild
    // 0xb60840: ldur            x1, [fp, #-0x20]
    // 0xb60844: mov             x2, x0
    // 0xb60848: ldur            x3, [fp, #-0x18]
    // 0xb6084c: stur            x0, [fp, #-0x10]
    // 0xb60850: r0 = getDryBaseline()
    //     0xb60850: bl              #0xb19678  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryBaseline
    // 0xb60854: stur            x0, [fp, #-0x18]
    // 0xb60858: cmp             w0, NULL
    // 0xb6085c: b.ne            #0xb60868
    // 0xb60860: r0 = Null
    //     0xb60860: mov             x0, NULL
    // 0xb60864: b               #0xb608c0
    // 0xb60868: ldur            x1, [fp, #-0x20]
    // 0xb6086c: ldur            x2, [fp, #-0x10]
    // 0xb60870: r0 = getDryLayout()
    //     0xb60870: bl              #0xb20410  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xb60874: ldur            x1, [fp, #-8]
    // 0xb60878: mov             x2, x0
    // 0xb6087c: r0 = _computeChildOffset()
    //     0xb6087c: bl              #0xb608e8  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarShape::_computeChildOffset
    // 0xb60880: LoadField: d0 = r0->field_f
    //     0xb60880: ldur            d0, [x0, #0xf]
    // 0xb60884: ldur            x1, [fp, #-0x18]
    // 0xb60888: LoadField: d1 = r1->field_7
    //     0xb60888: ldur            d1, [x1, #7]
    // 0xb6088c: fadd            d2, d1, d0
    // 0xb60890: r1 = inline_Allocate_Double()
    //     0xb60890: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xb60894: add             x1, x1, #0x10
    //     0xb60898: cmp             x2, x1
    //     0xb6089c: b.ls            #0xb608d4
    //     0xb608a0: str             x1, [THR, #0x60]  ; THR::top
    //     0xb608a4: sub             x1, x1, #0xf
    //     0xb608a8: mov             x2, #0xe19c
    //     0xb608ac: movk            x2, #3, lsl #16
    //     0xb608b0: stur            x2, [x1, #-1]
    // 0xb608b4: dmb             ishst
    // 0xb608b8: StoreField: r1->field_7 = d2
    //     0xb608b8: stur            d2, [x1, #7]
    // 0xb608bc: mov             x0, x1
    // 0xb608c0: LeaveFrame
    //     0xb608c0: mov             SP, fp
    //     0xb608c4: ldp             fp, lr, [SP], #0x10
    // 0xb608c8: ret
    //     0xb608c8: ret             
    // 0xb608cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb608cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb608d0: b               #0xb607d4
    // 0xb608d4: SaveReg d2
    //     0xb608d4: str             q2, [SP, #-0x10]!
    // 0xb608d8: r0 = AllocateDouble()
    //     0xb608d8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb608dc: mov             x1, x0
    // 0xb608e0: RestoreReg d2
    //     0xb608e0: ldr             q2, [SP], #0x10
    // 0xb608e4: b               #0xb608b8
  }
  _ _computeChildOffset(/* No info */) {
    // ** addr: 0xb608e8, size: 0x58
    // 0xb608e8: EnterFrame
    //     0xb608e8: stp             fp, lr, [SP, #-0x10]!
    //     0xb608ec: mov             fp, SP
    // 0xb608f0: AllocStack(0x8)
    //     0xb608f0: sub             SP, SP, #8
    // 0xb608f4: CheckStackOverflow
    //     0xb608f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb608f8: cmp             SP, x16
    //     0xb608fc: b.ls            #0xb60938
    // 0xb60900: LoadField: d0 = r2->field_f
    //     0xb60900: ldur            d0, [x2, #0xf]
    // 0xb60904: r0 = _isAbove()
    //     0xb60904: bl              #0xb60940  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarShape::_isAbove
    // 0xb60908: tbnz            w0, #4, #0xb60914
    // 0xb6090c: d0 = -7.000000
    //     0xb6090c: fmov            d0, #-7.00000000
    // 0xb60910: b               #0xb60918
    // 0xb60914: d0 = 0.000000
    //     0xb60914: eor             v0.16b, v0.16b, v0.16b
    // 0xb60918: stur            d0, [fp, #-8]
    // 0xb6091c: r0 = Offset()
    //     0xb6091c: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xb60920: StoreField: r0->field_7 = rZR
    //     0xb60920: stur            xzr, [x0, #7]
    // 0xb60924: ldur            d0, [fp, #-8]
    // 0xb60928: StoreField: r0->field_f = d0
    //     0xb60928: stur            d0, [x0, #0xf]
    // 0xb6092c: LeaveFrame
    //     0xb6092c: mov             SP, fp
    //     0xb60930: ldp             fp, lr, [SP], #0x10
    // 0xb60934: ret
    //     0xb60934: ret             
    // 0xb60938: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb60938: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb6093c: b               #0xb60900
  }
  _ _isAbove(/* No info */) {
    // ** addr: 0xb60940, size: 0x30
    // 0xb60940: r2 = Instance_Size
    //     0xb60940: add             x2, PP, #0x98, lsl #12  ; [pp+0x986b0] Obj!Size@12a7531
    //     0xb60944: ldr             x2, [x2, #0x6b0]
    // 0xb60948: LoadField: r3 = r1->field_53
    //     0xb60948: ldur            w3, [x1, #0x53]
    // 0xb6094c: DecompressPointer r3
    //     0xb6094c: add             x3, x3, HEAP, lsl #32
    // 0xb60950: LoadField: d1 = r3->field_f
    //     0xb60950: ldur            d1, [x3, #0xf]
    // 0xb60954: LoadField: d2 = r2->field_f
    //     0xb60954: ldur            d2, [x2, #0xf]
    // 0xb60958: fsub            d3, d0, d2
    // 0xb6095c: fcmp            d1, d3
    // 0xb60960: r16 = true
    //     0xb60960: add             x16, NULL, #0x20  ; true
    // 0xb60964: r17 = false
    //     0xb60964: add             x17, NULL, #0x30  ; false
    // 0xb60968: csel            x0, x16, x17, ge
    // 0xb6096c: ret
    //     0xb6096c: ret             
  }
  _ _constraintsForChild(/* No info */) {
    // ** addr: 0xb60970, size: 0x6c
    // 0xb60970: EnterFrame
    //     0xb60970: stp             fp, lr, [SP, #-0x10]!
    //     0xb60974: mov             fp, SP
    // 0xb60978: AllocStack(0x10)
    //     0xb60978: sub             SP, SP, #0x10
    // 0xb6097c: SetupParameters(_RenderCupertinoTextSelectionToolbarShape this /* r1 => r0 */, dynamic _ /* r2 => r1, fp-0x8 */)
    //     0xb6097c: mov             x0, x1
    //     0xb60980: mov             x1, x2
    //     0xb60984: stur            x2, [fp, #-8]
    // 0xb60988: CheckStackOverflow
    //     0xb60988: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb6098c: cmp             SP, x16
    //     0xb60990: b.ls            #0xb609d4
    // 0xb60994: r0 = BoxConstraints()
    //     0xb60994: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb60998: d0 = 30.000000
    //     0xb60998: fmov            d0, #30.00000000
    // 0xb6099c: stur            x0, [fp, #-0x10]
    // 0xb609a0: StoreField: r0->field_7 = d0
    //     0xb609a0: stur            d0, [x0, #7]
    // 0xb609a4: d0 = inf
    //     0xb609a4: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb609a8: StoreField: r0->field_f = d0
    //     0xb609a8: stur            d0, [x0, #0xf]
    // 0xb609ac: ArrayStore: r0[0] = rZR  ; List_8
    //     0xb609ac: stur            xzr, [x0, #0x17]
    // 0xb609b0: StoreField: r0->field_1f = d0
    //     0xb609b0: stur            d0, [x0, #0x1f]
    // 0xb609b4: ldur            x1, [fp, #-8]
    // 0xb609b8: r0 = loosen()
    //     0xb609b8: bl              #0xb4ae38  ; [package:flutter/src/rendering/box.dart] BoxConstraints::loosen
    // 0xb609bc: ldur            x1, [fp, #-0x10]
    // 0xb609c0: mov             x2, x0
    // 0xb609c4: r0 = enforce()
    //     0xb609c4: bl              #0xb2154c  ; [package:flutter/src/rendering/box.dart] BoxConstraints::enforce
    // 0xb609c8: LeaveFrame
    //     0xb609c8: mov             SP, fp
    //     0xb609cc: ldp             fp, lr, [SP], #0x10
    // 0xb609d0: ret
    //     0xb609d0: ret             
    // 0xb609d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb609d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb609d8: b               #0xb60994
  }
  _ performLayout(/* No info */) {
    // ** addr: 0xbbc3c0, size: 0x1ec
    // 0xbbc3c0: EnterFrame
    //     0xbbc3c0: stp             fp, lr, [SP, #-0x10]!
    //     0xbbc3c4: mov             fp, SP
    // 0xbbc3c8: AllocStack(0x30)
    //     0xbbc3c8: sub             SP, SP, #0x30
    // 0xbbc3cc: SetupParameters(_RenderCupertinoTextSelectionToolbarShape this /* r1 => r3, fp-0x18 */)
    //     0xbbc3cc: mov             x3, x1
    //     0xbbc3d0: stur            x1, [fp, #-0x18]
    // 0xbbc3d4: CheckStackOverflow
    //     0xbbc3d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbbc3d8: cmp             SP, x16
    //     0xbbc3dc: b.ls            #0xbbc5a0
    // 0xbbc3e0: LoadField: r4 = r3->field_4f
    //     0xbbc3e0: ldur            w4, [x3, #0x4f]
    // 0xbbc3e4: DecompressPointer r4
    //     0xbbc3e4: add             x4, x4, HEAP, lsl #32
    // 0xbbc3e8: stur            x4, [fp, #-0x10]
    // 0xbbc3ec: cmp             w4, NULL
    // 0xbbc3f0: b.ne            #0xbbc404
    // 0xbbc3f4: r0 = Null
    //     0xbbc3f4: mov             x0, NULL
    // 0xbbc3f8: LeaveFrame
    //     0xbbc3f8: mov             SP, fp
    //     0xbbc3fc: ldp             fp, lr, [SP], #0x10
    // 0xbbc400: ret
    //     0xbbc400: ret             
    // 0xbbc404: LoadField: r5 = r3->field_27
    //     0xbbc404: ldur            w5, [x3, #0x27]
    // 0xbbc408: DecompressPointer r5
    //     0xbbc408: add             x5, x5, HEAP, lsl #32
    // 0xbbc40c: stur            x5, [fp, #-8]
    // 0xbbc410: cmp             w5, NULL
    // 0xbbc414: b.eq            #0xbbc584
    // 0xbbc418: mov             x0, x5
    // 0xbbc41c: r2 = Null
    //     0xbbc41c: mov             x2, NULL
    // 0xbbc420: r1 = Null
    //     0xbbc420: mov             x1, NULL
    // 0xbbc424: r4 = LoadClassIdInstr(r0)
    //     0xbbc424: ldur            x4, [x0, #-1]
    //     0xbbc428: ubfx            x4, x4, #0xc, #0x14
    // 0xbbc42c: sub             x4, x4, #0xb46
    // 0xbbc430: cmp             x4, #1
    // 0xbbc434: b.ls            #0xbbc448
    // 0xbbc438: r8 = BoxConstraints
    //     0xbbc438: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbbc43c: r3 = Null
    //     0xbbc43c: add             x3, PP, #0x98, lsl #12  ; [pp+0x986e8] Null
    //     0xbbc440: ldr             x3, [x3, #0x6e8]
    // 0xbbc444: r0 = BoxConstraints()
    //     0xbbc444: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbbc448: ldur            x1, [fp, #-0x18]
    // 0xbbc44c: ldur            x2, [fp, #-8]
    // 0xbbc450: r0 = _constraintsForChild()
    //     0xbbc450: bl              #0xb60970  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarShape::_constraintsForChild
    // 0xbbc454: ldur            x3, [fp, #-0x10]
    // 0xbbc458: r1 = LoadClassIdInstr(r3)
    //     0xbbc458: ldur            x1, [x3, #-1]
    //     0xbbc45c: ubfx            x1, x1, #0xc, #0x14
    // 0xbbc460: r16 = true
    //     0xbbc460: add             x16, NULL, #0x20  ; true
    // 0xbbc464: str             x16, [SP]
    // 0xbbc468: mov             x2, x0
    // 0xbbc46c: mov             x0, x1
    // 0xbbc470: mov             x1, x3
    // 0xbbc474: r4 = const [0, 0x3, 0x1, 0x2, parentUsesSize, 0x2, null]
    //     0xbbc474: add             x4, PP, #0xd, lsl #12  ; [pp+0xded0] List(7) [0, 0x3, 0x1, 0x2, "parentUsesSize", 0x2, Null]
    //     0xbbc478: ldr             x4, [x4, #0xed0]
    // 0xbbc47c: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0xbbc47c: mov             x17, #0xe6b9
    //     0xbbc480: add             lr, x0, x17
    //     0xbbc484: ldr             lr, [x21, lr, lsl #3]
    //     0xbbc488: blr             lr
    // 0xbbc48c: ldur            x3, [fp, #-0x10]
    // 0xbbc490: LoadField: r4 = r3->field_7
    //     0xbbc490: ldur            w4, [x3, #7]
    // 0xbbc494: DecompressPointer r4
    //     0xbbc494: add             x4, x4, HEAP, lsl #32
    // 0xbbc498: stur            x4, [fp, #-8]
    // 0xbbc49c: cmp             w4, NULL
    // 0xbbc4a0: b.eq            #0xbbc5a8
    // 0xbbc4a4: mov             x0, x4
    // 0xbbc4a8: r2 = Null
    //     0xbbc4a8: mov             x2, NULL
    // 0xbbc4ac: r1 = Null
    //     0xbbc4ac: mov             x1, NULL
    // 0xbbc4b0: r4 = LoadClassIdInstr(r0)
    //     0xbbc4b0: ldur            x4, [x0, #-1]
    //     0xbbc4b4: ubfx            x4, x4, #0xc, #0x14
    // 0xbbc4b8: r17 = -4190
    //     0xbbc4b8: mov             x17, #-0x105e
    // 0xbbc4bc: add             x4, x4, x17
    // 0xbbc4c0: cmp             x4, #0x17
    // 0xbbc4c4: b.ls            #0xbbc4dc
    // 0xbbc4c8: r8 = BoxParentData
    //     0xbbc4c8: add             x8, PP, #0x15, lsl #12  ; [pp+0x155e8] Type: BoxParentData
    //     0xbbc4cc: ldr             x8, [x8, #0x5e8]
    // 0xbbc4d0: r3 = Null
    //     0xbbc4d0: add             x3, PP, #0x98, lsl #12  ; [pp+0x986f8] Null
    //     0xbbc4d4: ldr             x3, [x3, #0x6f8]
    // 0xbbc4d8: r0 = DefaultTypeTest()
    //     0xbbc4d8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbbc4dc: ldur            x1, [fp, #-0x10]
    // 0xbbc4e0: r0 = size()
    //     0xbbc4e0: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbbc4e4: ldur            x1, [fp, #-0x18]
    // 0xbbc4e8: mov             x2, x0
    // 0xbbc4ec: r0 = _computeChildOffset()
    //     0xbbc4ec: bl              #0xb608e8  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarShape::_computeChildOffset
    // 0xbbc4f0: ldur            x1, [fp, #-8]
    // 0xbbc4f4: StoreField: r1->field_7 = r0
    //     0xbbc4f4: stur            w0, [x1, #7]
    //     0xbbc4f8: ldurb           w16, [x1, #-1]
    //     0xbbc4fc: ldurb           w17, [x0, #-1]
    //     0xbbc500: and             x16, x17, x16, lsr #2
    //     0xbbc504: tst             x16, HEAP, lsr #32
    //     0xbbc508: b.eq            #0xbbc510
    //     0xbbc50c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbbc510: ldur            x1, [fp, #-0x10]
    // 0xbbc514: r0 = size()
    //     0xbbc514: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbbc518: LoadField: d0 = r0->field_7
    //     0xbbc518: ldur            d0, [x0, #7]
    // 0xbbc51c: ldur            x1, [fp, #-0x10]
    // 0xbbc520: stur            d0, [fp, #-0x20]
    // 0xbbc524: r0 = size()
    //     0xbbc524: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbbc528: LoadField: d0 = r0->field_f
    //     0xbbc528: ldur            d0, [x0, #0xf]
    // 0xbbc52c: r0 = Instance_Size
    //     0xbbc52c: add             x0, PP, #0x98, lsl #12  ; [pp+0x986b0] Obj!Size@12a7531
    //     0xbbc530: ldr             x0, [x0, #0x6b0]
    // 0xbbc534: LoadField: d1 = r0->field_f
    //     0xbbc534: ldur            d1, [x0, #0xf]
    // 0xbbc538: fsub            d2, d0, d1
    // 0xbbc53c: stur            d2, [fp, #-0x28]
    // 0xbbc540: r0 = Size()
    //     0xbbc540: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xbbc544: ldur            d0, [fp, #-0x20]
    // 0xbbc548: StoreField: r0->field_7 = d0
    //     0xbbc548: stur            d0, [x0, #7]
    // 0xbbc54c: ldur            d0, [fp, #-0x28]
    // 0xbbc550: StoreField: r0->field_f = d0
    //     0xbbc550: stur            d0, [x0, #0xf]
    // 0xbbc554: ldur            x1, [fp, #-0x18]
    // 0xbbc558: StoreField: r1->field_4b = r0
    //     0xbbc558: stur            w0, [x1, #0x4b]
    //     0xbbc55c: ldurb           w16, [x1, #-1]
    //     0xbbc560: ldurb           w17, [x0, #-1]
    //     0xbbc564: and             x16, x17, x16, lsr #2
    //     0xbbc568: tst             x16, HEAP, lsr #32
    //     0xbbc56c: b.eq            #0xbbc574
    //     0xbbc570: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbbc574: r0 = Null
    //     0xbbc574: mov             x0, NULL
    // 0xbbc578: LeaveFrame
    //     0xbbc578: mov             SP, fp
    //     0xbbc57c: ldp             fp, lr, [SP], #0x10
    // 0xbbc580: ret
    //     0xbbc580: ret             
    // 0xbbc584: r0 = StateError()
    //     0xbbc584: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbbc588: mov             x1, x0
    // 0xbbc58c: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbbc58c: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbbc590: StoreField: r1->field_b = r0
    //     0xbbc590: stur            w0, [x1, #0xb]
    // 0xbbc594: mov             x0, x1
    // 0xbbc598: r0 = Throw()
    //     0xbbc598: bl              #0x13ddb2c  ; ThrowStub
    // 0xbbc59c: brk             #0
    // 0xbbc5a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbbc5a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbbc5a4: b               #0xbbc3e0
    // 0xbbc5a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbc5a8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ paint(/* No info */) {
    // ** addr: 0xc1fdfc, size: 0x2c4
    // 0xc1fdfc: EnterFrame
    //     0xc1fdfc: stp             fp, lr, [SP, #-0x10]!
    //     0xc1fe00: mov             fp, SP
    // 0xc1fe04: AllocStack(0x78)
    //     0xc1fe04: sub             SP, SP, #0x78
    // 0xc1fe08: SetupParameters(_RenderCupertinoTextSelectionToolbarShape this /* r1 => r2, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */, dynamic _ /* r3 => r1, fp-0x20 */)
    //     0xc1fe08: mov             x0, x2
    //     0xc1fe0c: stur            x2, [fp, #-0x18]
    //     0xc1fe10: mov             x2, x1
    //     0xc1fe14: stur            x1, [fp, #-0x10]
    //     0xc1fe18: mov             x1, x3
    //     0xc1fe1c: stur            x3, [fp, #-0x20]
    // 0xc1fe20: CheckStackOverflow
    //     0xc1fe20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc1fe24: cmp             SP, x16
    //     0xc1fe28: b.ls            #0xc200ac
    // 0xc1fe2c: LoadField: r3 = r2->field_4f
    //     0xc1fe2c: ldur            w3, [x2, #0x4f]
    // 0xc1fe30: DecompressPointer r3
    //     0xc1fe30: add             x3, x3, HEAP, lsl #32
    // 0xc1fe34: stur            x3, [fp, #-8]
    // 0xc1fe38: r1 = 1
    //     0xc1fe38: mov             x1, #1
    // 0xc1fe3c: r0 = AllocateContext()
    //     0xc1fe3c: bl              #0x13de838  ; AllocateContextStub
    // 0xc1fe40: mov             x4, x0
    // 0xc1fe44: ldur            x3, [fp, #-8]
    // 0xc1fe48: stur            x4, [fp, #-0x30]
    // 0xc1fe4c: StoreField: r4->field_f = r3
    //     0xc1fe4c: stur            w3, [x4, #0xf]
    // 0xc1fe50: cmp             w3, NULL
    // 0xc1fe54: b.ne            #0xc1fe68
    // 0xc1fe58: r0 = Null
    //     0xc1fe58: mov             x0, NULL
    // 0xc1fe5c: LeaveFrame
    //     0xc1fe5c: mov             SP, fp
    //     0xc1fe60: ldp             fp, lr, [SP], #0x10
    // 0xc1fe64: ret
    //     0xc1fe64: ret             
    // 0xc1fe68: ldur            x5, [fp, #-0x10]
    // 0xc1fe6c: LoadField: r6 = r3->field_7
    //     0xc1fe6c: ldur            w6, [x3, #7]
    // 0xc1fe70: DecompressPointer r6
    //     0xc1fe70: add             x6, x6, HEAP, lsl #32
    // 0xc1fe74: stur            x6, [fp, #-0x28]
    // 0xc1fe78: cmp             w6, NULL
    // 0xc1fe7c: b.eq            #0xc200b4
    // 0xc1fe80: mov             x0, x6
    // 0xc1fe84: r2 = Null
    //     0xc1fe84: mov             x2, NULL
    // 0xc1fe88: r1 = Null
    //     0xc1fe88: mov             x1, NULL
    // 0xc1fe8c: r4 = LoadClassIdInstr(r0)
    //     0xc1fe8c: ldur            x4, [x0, #-1]
    //     0xc1fe90: ubfx            x4, x4, #0xc, #0x14
    // 0xc1fe94: r17 = -4190
    //     0xc1fe94: mov             x17, #-0x105e
    // 0xc1fe98: add             x4, x4, x17
    // 0xc1fe9c: cmp             x4, #0x17
    // 0xc1fea0: b.ls            #0xc1feb8
    // 0xc1fea4: r8 = BoxParentData
    //     0xc1fea4: add             x8, PP, #0x15, lsl #12  ; [pp+0x155e8] Type: BoxParentData
    //     0xc1fea8: ldr             x8, [x8, #0x5e8]
    // 0xc1feac: r3 = Null
    //     0xc1feac: add             x3, PP, #0x98, lsl #12  ; [pp+0x986b8] Null
    //     0xc1feb0: ldr             x3, [x3, #0x6b8]
    // 0xc1feb4: r0 = DefaultTypeTest()
    //     0xc1feb4: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xc1feb8: ldur            x1, [fp, #-0x10]
    // 0xc1febc: ldur            x2, [fp, #-8]
    // 0xc1fec0: r0 = _shapeRRect()
    //     0xc1fec0: bl              #0xc20a6c  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarShape::_shapeRRect
    // 0xc1fec4: ldur            x1, [fp, #-0x10]
    // 0xc1fec8: ldur            x2, [fp, #-8]
    // 0xc1fecc: mov             x3, x0
    // 0xc1fed0: stur            x0, [fp, #-0x38]
    // 0xc1fed4: r0 = _clipPath()
    //     0xc1fed4: bl              #0xc200c0  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarShape::_clipPath
    // 0xc1fed8: mov             x1, x0
    // 0xc1fedc: ldur            x0, [fp, #-0x10]
    // 0xc1fee0: stur            x1, [fp, #-0x48]
    // 0xc1fee4: LoadField: r2 = r0->field_5b
    //     0xc1fee4: ldur            w2, [x0, #0x5b]
    // 0xc1fee8: DecompressPointer r2
    //     0xc1fee8: add             x2, x2, HEAP, lsl #32
    // 0xc1feec: stur            x2, [fp, #-0x40]
    // 0xc1fef0: cmp             w2, NULL
    // 0xc1fef4: b.eq            #0xc1ffe8
    // 0xc1fef8: ldur            x4, [fp, #-0x28]
    // 0xc1fefc: ldur            x3, [fp, #-0x38]
    // 0xc1ff00: r0 = BoxShadow()
    //     0xc1ff00: bl              #0x919648  ; AllocateBoxShadowStub -> BoxShadow (size=0x24)
    // 0xc1ff04: stur            x0, [fp, #-0x50]
    // 0xc1ff08: ArrayStore: r0[0] = rZR  ; List_8
    //     0xc1ff08: stur            xzr, [x0, #0x17]
    // 0xc1ff0c: r1 = Instance_BlurStyle
    //     0xc1ff0c: add             x1, PP, #0x16, lsl #12  ; [pp+0x16ce0] Obj!BlurStyle@12c7fe1
    //     0xc1ff10: ldr             x1, [x1, #0xce0]
    // 0xc1ff14: StoreField: r0->field_1f = r1
    //     0xc1ff14: stur            w1, [x0, #0x1f]
    // 0xc1ff18: ldur            x1, [fp, #-0x40]
    // 0xc1ff1c: StoreField: r0->field_7 = r1
    //     0xc1ff1c: stur            w1, [x0, #7]
    // 0xc1ff20: r2 = Instance_Offset
    //     0xc1ff20: ldr             x2, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc1ff24: StoreField: r0->field_b = r2
    //     0xc1ff24: stur            w2, [x0, #0xb]
    // 0xc1ff28: d0 = 15.000000
    //     0xc1ff28: fmov            d0, #15.00000000
    // 0xc1ff2c: StoreField: r0->field_f = d0
    //     0xc1ff2c: stur            d0, [x0, #0xf]
    // 0xc1ff30: ldur            x1, [fp, #-0x38]
    // 0xc1ff34: LoadField: d0 = r1->field_b
    //     0xc1ff34: ldur            d0, [x1, #0xb]
    // 0xc1ff38: stur            d0, [fp, #-0x70]
    // 0xc1ff3c: LoadField: d1 = r1->field_13
    //     0xc1ff3c: ldur            d1, [x1, #0x13]
    // 0xc1ff40: stur            d1, [fp, #-0x68]
    // 0xc1ff44: LoadField: d2 = r1->field_1b
    //     0xc1ff44: ldur            d2, [x1, #0x1b]
    // 0xc1ff48: stur            d2, [fp, #-0x60]
    // 0xc1ff4c: LoadField: d3 = r1->field_23
    //     0xc1ff4c: ldur            d3, [x1, #0x23]
    // 0xc1ff50: r1 = Instance_Size
    //     0xc1ff50: add             x1, PP, #0x98, lsl #12  ; [pp+0x986b0] Obj!Size@12a7531
    //     0xc1ff54: ldr             x1, [x1, #0x6b0]
    // 0xc1ff58: LoadField: d4 = r1->field_f
    //     0xc1ff58: ldur            d4, [x1, #0xf]
    // 0xc1ff5c: fadd            d5, d3, d4
    // 0xc1ff60: stur            d5, [fp, #-0x58]
    // 0xc1ff64: r1 = <RRect>
    //     0xc1ff64: add             x1, PP, #0x85, lsl #12  ; [pp+0x85108] TypeArguments: <RRect>
    //     0xc1ff68: ldr             x1, [x1, #0x108]
    // 0xc1ff6c: r0 = RRect()
    //     0xc1ff6c: bl              #0xb6e214  ; AllocateRRectStub -> RRect (size=0x6c)
    // 0xc1ff70: mov             x1, x0
    // 0xc1ff74: ldur            d0, [fp, #-0x70]
    // 0xc1ff78: ldur            d1, [fp, #-0x68]
    // 0xc1ff7c: ldur            d2, [fp, #-0x60]
    // 0xc1ff80: ldur            d3, [fp, #-0x58]
    // 0xc1ff84: r2 = Instance_Radius
    //     0xc1ff84: add             x2, PP, #0x98, lsl #12  ; [pp+0x986c8] Obj!Radius@12a71e1
    //     0xc1ff88: ldr             x2, [x2, #0x6c8]
    // 0xc1ff8c: stur            x0, [fp, #-0x38]
    // 0xc1ff90: r0 = RRect.fromLTRBR()
    //     0xc1ff90: bl              #0xb6e1d4  ; [dart:ui] RRect::RRect.fromLTRBR
    // 0xc1ff94: ldur            x0, [fp, #-0x28]
    // 0xc1ff98: LoadField: r2 = r0->field_7
    //     0xc1ff98: ldur            w2, [x0, #7]
    // 0xc1ff9c: DecompressPointer r2
    //     0xc1ff9c: add             x2, x2, HEAP, lsl #32
    // 0xc1ffa0: ldur            x1, [fp, #-0x20]
    // 0xc1ffa4: r0 = +()
    //     0xc1ffa4: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0xc1ffa8: mov             x1, x0
    // 0xc1ffac: r2 = Instance_Offset
    //     0xc1ffac: ldr             x2, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc1ffb0: r0 = +()
    //     0xc1ffb0: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0xc1ffb4: ldur            x1, [fp, #-0x38]
    // 0xc1ffb8: mov             x2, x0
    // 0xc1ffbc: r0 = shift()
    //     0xc1ffbc: bl              #0xb6e004  ; [dart:ui] _RRectLike::shift
    // 0xc1ffc0: ldur            x1, [fp, #-0x18]
    // 0xc1ffc4: stur            x0, [fp, #-0x38]
    // 0xc1ffc8: r0 = canvas()
    //     0xc1ffc8: bl              #0xc17694  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0xc1ffcc: ldur            x1, [fp, #-0x50]
    // 0xc1ffd0: stur            x0, [fp, #-0x40]
    // 0xc1ffd4: r0 = toPaint()
    //     0xc1ffd4: bl              #0xb6da24  ; [package:flutter/src/painting/box_shadow.dart] BoxShadow::toPaint
    // 0xc1ffd8: ldur            x1, [fp, #-0x40]
    // 0xc1ffdc: ldur            x2, [fp, #-0x38]
    // 0xc1ffe0: mov             x3, x0
    // 0xc1ffe4: r0 = drawRRect()
    //     0xc1ffe4: bl              #0xb6dce0  ; [dart:ui] _NativeCanvas::drawRRect
    // 0xc1ffe8: ldur            x1, [fp, #-0x10]
    // 0xc1ffec: ldur            x0, [fp, #-0x28]
    // 0xc1fff0: LoadField: r3 = r1->field_5f
    //     0xc1fff0: ldur            w3, [x1, #0x5f]
    // 0xc1fff4: DecompressPointer r3
    //     0xc1fff4: add             x3, x3, HEAP, lsl #32
    // 0xc1fff8: stur            x3, [fp, #-0x40]
    // 0xc1fffc: LoadField: r4 = r1->field_37
    //     0xc1fffc: ldur            w4, [x1, #0x37]
    // 0xc20000: DecompressPointer r4
    //     0xc20000: add             x4, x4, HEAP, lsl #32
    // 0xc20004: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc20008: cmp             w4, w16
    // 0xc2000c: b.eq            #0xc200b8
    // 0xc20010: stur            x4, [fp, #-0x38]
    // 0xc20014: LoadField: r2 = r0->field_7
    //     0xc20014: ldur            w2, [x0, #7]
    // 0xc20018: DecompressPointer r2
    //     0xc20018: add             x2, x2, HEAP, lsl #32
    // 0xc2001c: ldur            x1, [fp, #-0x20]
    // 0xc20020: r0 = +()
    //     0xc20020: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0xc20024: ldur            x1, [fp, #-8]
    // 0xc20028: stur            x0, [fp, #-8]
    // 0xc2002c: r0 = size()
    //     0xc2002c: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc20030: mov             x2, x0
    // 0xc20034: r1 = Instance_Offset
    //     0xc20034: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc20038: r0 = &()
    //     0xc20038: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xc2003c: mov             x3, x0
    // 0xc20040: ldur            x0, [fp, #-0x40]
    // 0xc20044: stur            x3, [fp, #-0x20]
    // 0xc20048: LoadField: r4 = r0->field_b
    //     0xc20048: ldur            w4, [x0, #0xb]
    // 0xc2004c: DecompressPointer r4
    //     0xc2004c: add             x4, x4, HEAP, lsl #32
    // 0xc20050: ldur            x2, [fp, #-0x30]
    // 0xc20054: stur            x4, [fp, #-0x10]
    // 0xc20058: r1 = Function '<anonymous closure>':.
    //     0xc20058: add             x1, PP, #0x98, lsl #12  ; [pp+0x986d0] AnonymousClosure: (0xc20b44), in [package:flutter/src/widgets/widget_span.dart] _RenderScaledInlineWidget::paint (0xc21188)
    //     0xc2005c: ldr             x1, [x1, #0x6d0]
    // 0xc20060: r0 = AllocateClosure()
    //     0xc20060: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc20064: ldur            x16, [fp, #-0x10]
    // 0xc20068: str             x16, [SP]
    // 0xc2006c: ldur            x1, [fp, #-0x18]
    // 0xc20070: ldur            x2, [fp, #-0x38]
    // 0xc20074: ldur            x3, [fp, #-8]
    // 0xc20078: ldur            x5, [fp, #-0x20]
    // 0xc2007c: ldur            x6, [fp, #-0x48]
    // 0xc20080: mov             x7, x0
    // 0xc20084: r4 = const [0, 0x7, 0x1, 0x7, null]
    //     0xc20084: add             x4, PP, #0x20, lsl #12  ; [pp+0x20fd0] List(5) [0, 0x7, 0x1, 0x7, Null]
    //     0xc20088: ldr             x4, [x4, #0xfd0]
    // 0xc2008c: r0 = pushClipPath()
    //     0xc2008c: bl              #0xc1a8a8  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushClipPath
    // 0xc20090: ldur            x1, [fp, #-0x40]
    // 0xc20094: mov             x2, x0
    // 0xc20098: r0 = layer=()
    //     0xc20098: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc2009c: r0 = Null
    //     0xc2009c: mov             x0, NULL
    // 0xc200a0: LeaveFrame
    //     0xc200a0: mov             SP, fp
    //     0xc200a4: ldp             fp, lr, [SP], #0x10
    // 0xc200a8: ret
    //     0xc200a8: ret             
    // 0xc200ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc200ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc200b0: b               #0xc1fe2c
    // 0xc200b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc200b4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc200b8: r9 = _needsCompositing
    //     0xc200b8: ldr             x9, [PP, #0x2dd0]  ; [pp+0x2dd0] Field <RenderObject._needsCompositing@30266271>: late (offset: 0x38)
    // 0xc200bc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc200bc: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _clipPath(/* No info */) {
    // ** addr: 0xc200c0, size: 0x574
    // 0xc200c0: EnterFrame
    //     0xc200c0: stp             fp, lr, [SP, #-0x10]!
    //     0xc200c4: mov             fp, SP
    // 0xc200c8: AllocStack(0x58)
    //     0xc200c8: sub             SP, SP, #0x58
    // 0xc200cc: SetupParameters(_RenderCupertinoTextSelectionToolbarShape this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */, dynamic _ /* r3 => r2, fp-0x18 */)
    //     0xc200cc: mov             x0, x1
    //     0xc200d0: stur            x1, [fp, #-8]
    //     0xc200d4: mov             x1, x2
    //     0xc200d8: stur            x2, [fp, #-0x10]
    //     0xc200dc: mov             x2, x3
    //     0xc200e0: stur            x3, [fp, #-0x18]
    // 0xc200e4: CheckStackOverflow
    //     0xc200e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc200e8: cmp             SP, x16
    //     0xc200ec: b.ls            #0xc2060c
    // 0xc200f0: r0 = _NativePath()
    //     0xc200f0: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0xc200f4: mov             x1, x0
    // 0xc200f8: stur            x0, [fp, #-0x20]
    // 0xc200fc: r0 = __constructor$Method$FfiNative()
    //     0xc200fc: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0xc20100: ldur            x1, [fp, #-8]
    // 0xc20104: r0 = size()
    //     0xc20104: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc20108: LoadField: d0 = r0->field_7
    //     0xc20108: ldur            d0, [x0, #7]
    // 0xc2010c: d1 = 30.000000
    //     0xc2010c: fmov            d1, #30.00000000
    // 0xc20110: fcmp            d1, d0
    // 0xc20114: b.le            #0xc2021c
    // 0xc20118: ldur            x2, [fp, #-0x18]
    // 0xc2011c: ldur            x0, [fp, #-0x20]
    // 0xc20120: LoadField: d0 = r2->field_b
    //     0xc20120: ldur            d0, [x2, #0xb]
    // 0xc20124: fcvt            s1, d0
    // 0xc20128: stur            d1, [fp, #-0x38]
    // 0xc2012c: r4 = 24
    //     0xc2012c: mov             x4, #0x18
    // 0xc20130: r0 = AllocateFloat32Array()
    //     0xc20130: bl              #0x13defe8  ; AllocateFloat32ArrayStub
    // 0xc20134: ldur            d0, [fp, #-0x38]
    // 0xc20138: stur            x0, [fp, #-0x30]
    // 0xc2013c: ArrayStore: r0[0] = d0  ; List_8
    //     0xc2013c: stur            s0, [x0, #0x17]
    // 0xc20140: ldur            x2, [fp, #-0x18]
    // 0xc20144: LoadField: d0 = r2->field_13
    //     0xc20144: ldur            d0, [x2, #0x13]
    // 0xc20148: fcvt            s1, d0
    // 0xc2014c: StoreField: r0->field_1b = d1
    //     0xc2014c: stur            s1, [x0, #0x1b]
    // 0xc20150: LoadField: d0 = r2->field_1b
    //     0xc20150: ldur            d0, [x2, #0x1b]
    // 0xc20154: fcvt            s1, d0
    // 0xc20158: StoreField: r0->field_1f = d1
    //     0xc20158: stur            s1, [x0, #0x1f]
    // 0xc2015c: LoadField: d0 = r2->field_23
    //     0xc2015c: ldur            d0, [x2, #0x23]
    // 0xc20160: fcvt            s1, d0
    // 0xc20164: StoreField: r0->field_23 = d1
    //     0xc20164: stur            s1, [x0, #0x23]
    // 0xc20168: LoadField: d0 = r2->field_2b
    //     0xc20168: ldur            d0, [x2, #0x2b]
    // 0xc2016c: fcvt            s1, d0
    // 0xc20170: StoreField: r0->field_27 = d1
    //     0xc20170: stur            s1, [x0, #0x27]
    // 0xc20174: LoadField: d0 = r2->field_33
    //     0xc20174: ldur            d0, [x2, #0x33]
    // 0xc20178: fcvt            s1, d0
    // 0xc2017c: StoreField: r0->field_2b = d1
    //     0xc2017c: stur            s1, [x0, #0x2b]
    // 0xc20180: LoadField: d0 = r2->field_3b
    //     0xc20180: ldur            d0, [x2, #0x3b]
    // 0xc20184: fcvt            s1, d0
    // 0xc20188: StoreField: r0->field_2f = d1
    //     0xc20188: stur            s1, [x0, #0x2f]
    // 0xc2018c: LoadField: d0 = r2->field_43
    //     0xc2018c: ldur            d0, [x2, #0x43]
    // 0xc20190: fcvt            s1, d0
    // 0xc20194: StoreField: r0->field_33 = d1
    //     0xc20194: stur            s1, [x0, #0x33]
    // 0xc20198: LoadField: d0 = r2->field_4b
    //     0xc20198: ldur            d0, [x2, #0x4b]
    // 0xc2019c: fcvt            s1, d0
    // 0xc201a0: StoreField: r0->field_37 = d1
    //     0xc201a0: stur            s1, [x0, #0x37]
    // 0xc201a4: LoadField: d0 = r2->field_53
    //     0xc201a4: ldur            d0, [x2, #0x53]
    // 0xc201a8: fcvt            s1, d0
    // 0xc201ac: StoreField: r0->field_3b = d1
    //     0xc201ac: stur            s1, [x0, #0x3b]
    // 0xc201b0: LoadField: d0 = r2->field_5b
    //     0xc201b0: ldur            d0, [x2, #0x5b]
    // 0xc201b4: fcvt            s1, d0
    // 0xc201b8: StoreField: r0->field_3f = d1
    //     0xc201b8: stur            s1, [x0, #0x3f]
    // 0xc201bc: LoadField: d0 = r2->field_63
    //     0xc201bc: ldur            d0, [x2, #0x63]
    // 0xc201c0: fcvt            s1, d0
    // 0xc201c4: StoreField: r0->field_43 = d1
    //     0xc201c4: stur            s1, [x0, #0x43]
    // 0xc201c8: ldur            x2, [fp, #-0x20]
    // 0xc201cc: LoadField: r1 = r2->field_7
    //     0xc201cc: ldur            w1, [x2, #7]
    // 0xc201d0: DecompressPointer r1
    //     0xc201d0: add             x1, x1, HEAP, lsl #32
    // 0xc201d4: cmp             w1, NULL
    // 0xc201d8: b.eq            #0xc20614
    // 0xc201dc: LoadField: r3 = r1->field_7
    //     0xc201dc: ldur            x3, [x1, #7]
    // 0xc201e0: ldr             x1, [x3]
    // 0xc201e4: cbz             x1, #0xc2058c
    // 0xc201e8: mov             x3, x1
    // 0xc201ec: stur            x3, [fp, #-0x28]
    // 0xc201f0: r1 = <Never>
    //     0xc201f0: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xc201f4: r0 = Pointer()
    //     0xc201f4: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xc201f8: mov             x1, x0
    // 0xc201fc: ldur            x0, [fp, #-0x28]
    // 0xc20200: StoreField: r1->field_7 = r0
    //     0xc20200: stur            x0, [x1, #7]
    // 0xc20204: ldur            x2, [fp, #-0x30]
    // 0xc20208: r0 = __addRRect$Method$FfiNative()
    //     0xc20208: bl              #0xbfd930  ; [dart:ui] _NativePath::__addRRect$Method$FfiNative
    // 0xc2020c: ldur            x0, [fp, #-0x20]
    // 0xc20210: LeaveFrame
    //     0xc20210: mov             SP, fp
    //     0xc20214: ldp             fp, lr, [SP], #0x10
    // 0xc20218: ret
    //     0xc20218: ret             
    // 0xc2021c: ldur            x2, [fp, #-0x18]
    // 0xc20220: ldur            x1, [fp, #-0x10]
    // 0xc20224: r0 = size()
    //     0xc20224: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc20228: LoadField: d0 = r0->field_f
    //     0xc20228: ldur            d0, [x0, #0xf]
    // 0xc2022c: ldur            x1, [fp, #-8]
    // 0xc20230: r0 = _isAbove()
    //     0xc20230: bl              #0xb60940  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarShape::_isAbove
    // 0xc20234: stur            x0, [fp, #-0x30]
    // 0xc20238: tbnz            w0, #4, #0xc20250
    // 0xc2023c: ldur            x3, [fp, #-8]
    // 0xc20240: LoadField: r1 = r3->field_53
    //     0xc20240: ldur            w1, [x3, #0x53]
    // 0xc20244: DecompressPointer r1
    //     0xc20244: add             x1, x1, HEAP, lsl #32
    // 0xc20248: mov             x2, x1
    // 0xc2024c: b               #0xc20260
    // 0xc20250: ldur            x3, [fp, #-8]
    // 0xc20254: LoadField: r1 = r3->field_57
    //     0xc20254: ldur            w1, [x3, #0x57]
    // 0xc20258: DecompressPointer r1
    //     0xc20258: add             x1, x1, HEAP, lsl #32
    // 0xc2025c: mov             x2, x1
    // 0xc20260: mov             x1, x3
    // 0xc20264: r0 = globalToLocal()
    //     0xc20264: bl              #0x867840  ; [package:flutter/src/rendering/box.dart] RenderBox::globalToLocal
    // 0xc20268: LoadField: d0 = r0->field_7
    //     0xc20268: ldur            d0, [x0, #7]
    // 0xc2026c: ldur            x1, [fp, #-8]
    // 0xc20270: stur            d0, [fp, #-0x38]
    // 0xc20274: r0 = size()
    //     0xc20274: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc20278: LoadField: d0 = r0->field_7
    //     0xc20278: ldur            d0, [x0, #7]
    // 0xc2027c: d1 = 7.000000
    //     0xc2027c: fmov            d1, #7.00000000
    // 0xc20280: fsub            d2, d0, d1
    // 0xc20284: r0 = Instance_Radius
    //     0xc20284: add             x0, PP, #0x98, lsl #12  ; [pp+0x986c8] Obj!Radius@12a71e1
    //     0xc20288: ldr             x0, [x0, #0x6c8]
    // 0xc2028c: LoadField: d0 = r0->field_7
    //     0xc2028c: ldur            d0, [x0, #7]
    // 0xc20290: fsub            d3, d2, d0
    // 0xc20294: ldur            d0, [fp, #-0x38]
    // 0xc20298: d2 = 15.000000
    //     0xc20298: fmov            d2, #15.00000000
    // 0xc2029c: fcmp            d2, d0
    // 0xc202a0: b.le            #0xc202ac
    // 0xc202a4: d0 = 15.000000
    //     0xc202a4: fmov            d0, #15.00000000
    // 0xc202a8: b               #0xc202c8
    // 0xc202ac: fcmp            d0, d3
    // 0xc202b0: b.le            #0xc202bc
    // 0xc202b4: mov             v0.16b, v3.16b
    // 0xc202b8: b               #0xc202c8
    // 0xc202bc: fcmp            d0, d0
    // 0xc202c0: b.vc            #0xc202c8
    // 0xc202c4: mov             v0.16b, v3.16b
    // 0xc202c8: ldur            x0, [fp, #-0x30]
    // 0xc202cc: stur            d0, [fp, #-0x38]
    // 0xc202d0: tbnz            w0, #4, #0xc20408
    // 0xc202d4: ldur            x2, [fp, #-0x20]
    // 0xc202d8: ldur            x1, [fp, #-0x10]
    // 0xc202dc: r0 = size()
    //     0xc202dc: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc202e0: LoadField: d0 = r0->field_f
    //     0xc202e0: ldur            d0, [x0, #0xf]
    // 0xc202e4: r0 = Instance_Size
    //     0xc202e4: add             x0, PP, #0x98, lsl #12  ; [pp+0x986b0] Obj!Size@12a7531
    //     0xc202e8: ldr             x0, [x0, #0x6b0]
    // 0xc202ec: LoadField: d1 = r0->field_f
    //     0xc202ec: ldur            d1, [x0, #0xf]
    // 0xc202f0: fsub            d2, d0, d1
    // 0xc202f4: ldur            x1, [fp, #-0x10]
    // 0xc202f8: stur            d2, [fp, #-0x40]
    // 0xc202fc: r0 = size()
    //     0xc202fc: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc20300: LoadField: d1 = r0->field_f
    //     0xc20300: ldur            d1, [x0, #0xf]
    // 0xc20304: ldur            d2, [fp, #-0x38]
    // 0xc20308: stur            d1, [fp, #-0x50]
    // 0xc2030c: d0 = 7.000000
    //     0xc2030c: fmov            d0, #7.00000000
    // 0xc20310: fadd            d3, d2, d0
    // 0xc20314: ldur            x0, [fp, #-0x20]
    // 0xc20318: stur            d3, [fp, #-0x48]
    // 0xc2031c: LoadField: r1 = r0->field_7
    //     0xc2031c: ldur            w1, [x0, #7]
    // 0xc20320: DecompressPointer r1
    //     0xc20320: add             x1, x1, HEAP, lsl #32
    // 0xc20324: cmp             w1, NULL
    // 0xc20328: b.eq            #0xc20618
    // 0xc2032c: LoadField: r2 = r1->field_7
    //     0xc2032c: ldur            x2, [x1, #7]
    // 0xc20330: ldr             x1, [x2]
    // 0xc20334: cbz             x1, #0xc2059c
    // 0xc20338: mov             x2, x1
    // 0xc2033c: stur            x2, [fp, #-0x28]
    // 0xc20340: r1 = <Never>
    //     0xc20340: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xc20344: r0 = Pointer()
    //     0xc20344: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xc20348: mov             x1, x0
    // 0xc2034c: ldur            x0, [fp, #-0x28]
    // 0xc20350: StoreField: r1->field_7 = r0
    //     0xc20350: stur            x0, [x1, #7]
    // 0xc20354: ldur            d0, [fp, #-0x48]
    // 0xc20358: ldur            d1, [fp, #-0x40]
    // 0xc2035c: r0 = _moveTo$Method$FfiNative()
    //     0xc2035c: bl              #0xb69c74  ; [dart:ui] _NativePath::_moveTo$Method$FfiNative
    // 0xc20360: ldur            x0, [fp, #-0x20]
    // 0xc20364: LoadField: r1 = r0->field_7
    //     0xc20364: ldur            w1, [x0, #7]
    // 0xc20368: DecompressPointer r1
    //     0xc20368: add             x1, x1, HEAP, lsl #32
    // 0xc2036c: cmp             w1, NULL
    // 0xc20370: b.eq            #0xc2061c
    // 0xc20374: LoadField: r2 = r1->field_7
    //     0xc20374: ldur            x2, [x1, #7]
    // 0xc20378: ldr             x1, [x2]
    // 0xc2037c: cbz             x1, #0xc205ac
    // 0xc20380: ldur            d0, [fp, #-0x38]
    // 0xc20384: mov             x2, x1
    // 0xc20388: stur            x2, [fp, #-0x28]
    // 0xc2038c: r1 = <Never>
    //     0xc2038c: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xc20390: r0 = Pointer()
    //     0xc20390: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xc20394: mov             x1, x0
    // 0xc20398: ldur            x0, [fp, #-0x28]
    // 0xc2039c: StoreField: r1->field_7 = r0
    //     0xc2039c: stur            x0, [x1, #7]
    // 0xc203a0: ldur            d0, [fp, #-0x38]
    // 0xc203a4: ldur            d1, [fp, #-0x50]
    // 0xc203a8: r0 = _lineTo$Method$FfiNative()
    //     0xc203a8: bl              #0xb69bd0  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0xc203ac: ldur            d1, [fp, #-0x38]
    // 0xc203b0: d0 = 7.000000
    //     0xc203b0: fmov            d0, #7.00000000
    // 0xc203b4: fsub            d2, d1, d0
    // 0xc203b8: ldur            x0, [fp, #-0x20]
    // 0xc203bc: stur            d2, [fp, #-0x48]
    // 0xc203c0: LoadField: r1 = r0->field_7
    //     0xc203c0: ldur            w1, [x0, #7]
    // 0xc203c4: DecompressPointer r1
    //     0xc203c4: add             x1, x1, HEAP, lsl #32
    // 0xc203c8: cmp             w1, NULL
    // 0xc203cc: b.eq            #0xc20620
    // 0xc203d0: LoadField: r2 = r1->field_7
    //     0xc203d0: ldur            x2, [x1, #7]
    // 0xc203d4: ldr             x1, [x2]
    // 0xc203d8: cbz             x1, #0xc205bc
    // 0xc203dc: mov             x2, x1
    // 0xc203e0: stur            x2, [fp, #-0x28]
    // 0xc203e4: r1 = <Never>
    //     0xc203e4: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xc203e8: r0 = Pointer()
    //     0xc203e8: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xc203ec: mov             x1, x0
    // 0xc203f0: ldur            x0, [fp, #-0x28]
    // 0xc203f4: StoreField: r1->field_7 = r0
    //     0xc203f4: stur            x0, [x1, #7]
    // 0xc203f8: ldur            d0, [fp, #-0x48]
    // 0xc203fc: ldur            d1, [fp, #-0x40]
    // 0xc20400: r0 = _lineTo$Method$FfiNative()
    //     0xc20400: bl              #0xb69bd0  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0xc20404: b               #0xc20514
    // 0xc20408: ldur            x2, [fp, #-0x20]
    // 0xc2040c: mov             v31.16b, v1.16b
    // 0xc20410: mov             v1.16b, v0.16b
    // 0xc20414: mov             v0.16b, v31.16b
    // 0xc20418: r0 = Instance_Size
    //     0xc20418: add             x0, PP, #0x98, lsl #12  ; [pp+0x986b0] Obj!Size@12a7531
    //     0xc2041c: ldr             x0, [x0, #0x6b0]
    // 0xc20420: LoadField: d2 = r0->field_f
    //     0xc20420: ldur            d2, [x0, #0xf]
    // 0xc20424: stur            d2, [fp, #-0x48]
    // 0xc20428: fsub            d3, d1, d0
    // 0xc2042c: stur            d3, [fp, #-0x40]
    // 0xc20430: LoadField: r0 = r2->field_7
    //     0xc20430: ldur            w0, [x2, #7]
    // 0xc20434: DecompressPointer r0
    //     0xc20434: add             x0, x0, HEAP, lsl #32
    // 0xc20438: cmp             w0, NULL
    // 0xc2043c: b.eq            #0xc20624
    // 0xc20440: LoadField: r1 = r0->field_7
    //     0xc20440: ldur            x1, [x0, #7]
    // 0xc20444: ldr             x0, [x1]
    // 0xc20448: cbz             x0, #0xc205cc
    // 0xc2044c: stur            x0, [fp, #-0x28]
    // 0xc20450: r1 = <Never>
    //     0xc20450: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xc20454: r0 = Pointer()
    //     0xc20454: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xc20458: mov             x1, x0
    // 0xc2045c: ldur            x0, [fp, #-0x28]
    // 0xc20460: StoreField: r1->field_7 = r0
    //     0xc20460: stur            x0, [x1, #7]
    // 0xc20464: ldur            d0, [fp, #-0x40]
    // 0xc20468: ldur            d1, [fp, #-0x48]
    // 0xc2046c: r0 = _moveTo$Method$FfiNative()
    //     0xc2046c: bl              #0xb69c74  ; [dart:ui] _NativePath::_moveTo$Method$FfiNative
    // 0xc20470: ldur            x0, [fp, #-0x20]
    // 0xc20474: LoadField: r1 = r0->field_7
    //     0xc20474: ldur            w1, [x0, #7]
    // 0xc20478: DecompressPointer r1
    //     0xc20478: add             x1, x1, HEAP, lsl #32
    // 0xc2047c: cmp             w1, NULL
    // 0xc20480: b.eq            #0xc20628
    // 0xc20484: LoadField: r2 = r1->field_7
    //     0xc20484: ldur            x2, [x1, #7]
    // 0xc20488: ldr             x1, [x2]
    // 0xc2048c: cbz             x1, #0xc205dc
    // 0xc20490: ldur            d0, [fp, #-0x38]
    // 0xc20494: mov             x2, x1
    // 0xc20498: stur            x2, [fp, #-0x28]
    // 0xc2049c: r1 = <Never>
    //     0xc2049c: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xc204a0: r0 = Pointer()
    //     0xc204a0: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xc204a4: mov             x1, x0
    // 0xc204a8: ldur            x0, [fp, #-0x28]
    // 0xc204ac: StoreField: r1->field_7 = r0
    //     0xc204ac: stur            x0, [x1, #7]
    // 0xc204b0: ldur            d0, [fp, #-0x38]
    // 0xc204b4: d1 = 0.000000
    //     0xc204b4: eor             v1.16b, v1.16b, v1.16b
    // 0xc204b8: r0 = _lineTo$Method$FfiNative()
    //     0xc204b8: bl              #0xb69bd0  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0xc204bc: ldur            d1, [fp, #-0x38]
    // 0xc204c0: d0 = 7.000000
    //     0xc204c0: fmov            d0, #7.00000000
    // 0xc204c4: fadd            d2, d1, d0
    // 0xc204c8: ldur            x0, [fp, #-0x20]
    // 0xc204cc: stur            d2, [fp, #-0x40]
    // 0xc204d0: LoadField: r1 = r0->field_7
    //     0xc204d0: ldur            w1, [x0, #7]
    // 0xc204d4: DecompressPointer r1
    //     0xc204d4: add             x1, x1, HEAP, lsl #32
    // 0xc204d8: cmp             w1, NULL
    // 0xc204dc: b.eq            #0xc2062c
    // 0xc204e0: LoadField: r2 = r1->field_7
    //     0xc204e0: ldur            x2, [x1, #7]
    // 0xc204e4: ldr             x1, [x2]
    // 0xc204e8: cbz             x1, #0xc205ec
    // 0xc204ec: mov             x2, x1
    // 0xc204f0: stur            x2, [fp, #-0x28]
    // 0xc204f4: r1 = <Never>
    //     0xc204f4: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xc204f8: r0 = Pointer()
    //     0xc204f8: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xc204fc: mov             x1, x0
    // 0xc20500: ldur            x0, [fp, #-0x28]
    // 0xc20504: StoreField: r1->field_7 = r0
    //     0xc20504: stur            x0, [x1, #7]
    // 0xc20508: ldur            d0, [fp, #-0x40]
    // 0xc2050c: ldur            d1, [fp, #-0x48]
    // 0xc20510: r0 = _lineTo$Method$FfiNative()
    //     0xc20510: bl              #0xb69bd0  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0xc20514: ldur            x0, [fp, #-0x30]
    // 0xc20518: tbnz            w0, #4, #0xc20528
    // 0xc2051c: d0 = 1.570796
    //     0xc2051c: add             x17, PP, #0x95, lsl #12  ; [pp+0x95ed8] IMM: double(1.5707963267948966) from 0x3ff921fb54442d18
    //     0xc20520: ldr             d0, [x17, #0xed8]
    // 0xc20524: b               #0xc20530
    // 0xc20528: d0 = -1.570796
    //     0xc20528: add             x17, PP, #0x1f, lsl #12  ; [pp+0x1f148] IMM: double(-1.5707963267948966) from 0xbff921fb54442d18
    //     0xc2052c: ldr             d0, [x17, #0x148]
    // 0xc20530: ldur            x1, [fp, #-0x20]
    // 0xc20534: ldur            x2, [fp, #-0x18]
    // 0xc20538: r0 = _addRRectToPath()
    //     0xc20538: bl              #0xc20634  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarShape::_addRRectToPath
    // 0xc2053c: stur            x0, [fp, #-8]
    // 0xc20540: LoadField: r1 = r0->field_7
    //     0xc20540: ldur            w1, [x0, #7]
    // 0xc20544: DecompressPointer r1
    //     0xc20544: add             x1, x1, HEAP, lsl #32
    // 0xc20548: cmp             w1, NULL
    // 0xc2054c: b.eq            #0xc20630
    // 0xc20550: LoadField: r2 = r1->field_7
    //     0xc20550: ldur            x2, [x1, #7]
    // 0xc20554: ldr             x1, [x2]
    // 0xc20558: cbz             x1, #0xc205fc
    // 0xc2055c: mov             x2, x1
    // 0xc20560: stur            x2, [fp, #-0x28]
    // 0xc20564: r1 = <Never>
    //     0xc20564: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xc20568: r0 = Pointer()
    //     0xc20568: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xc2056c: mov             x1, x0
    // 0xc20570: ldur            x0, [fp, #-0x28]
    // 0xc20574: StoreField: r1->field_7 = r0
    //     0xc20574: stur            x0, [x1, #7]
    // 0xc20578: r0 = _close$Method$FfiNative()
    //     0xc20578: bl              #0xb78188  ; [dart:ui] _NativePath::_close$Method$FfiNative
    // 0xc2057c: ldur            x0, [fp, #-8]
    // 0xc20580: LeaveFrame
    //     0xc20580: mov             SP, fp
    //     0xc20584: ldp             fp, lr, [SP], #0x10
    // 0xc20588: ret
    //     0xc20588: ret             
    // 0xc2058c: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xc2058c: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xc20590: str             x16, [SP]
    // 0xc20594: r0 = _throwNew()
    //     0xc20594: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xc20598: brk             #0
    // 0xc2059c: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xc2059c: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xc205a0: str             x16, [SP]
    // 0xc205a4: r0 = _throwNew()
    //     0xc205a4: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xc205a8: brk             #0
    // 0xc205ac: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xc205ac: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xc205b0: str             x16, [SP]
    // 0xc205b4: r0 = _throwNew()
    //     0xc205b4: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xc205b8: brk             #0
    // 0xc205bc: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xc205bc: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xc205c0: str             x16, [SP]
    // 0xc205c4: r0 = _throwNew()
    //     0xc205c4: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xc205c8: brk             #0
    // 0xc205cc: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xc205cc: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xc205d0: str             x16, [SP]
    // 0xc205d4: r0 = _throwNew()
    //     0xc205d4: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xc205d8: brk             #0
    // 0xc205dc: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xc205dc: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xc205e0: str             x16, [SP]
    // 0xc205e4: r0 = _throwNew()
    //     0xc205e4: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xc205e8: brk             #0
    // 0xc205ec: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xc205ec: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xc205f0: str             x16, [SP]
    // 0xc205f4: r0 = _throwNew()
    //     0xc205f4: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xc205f8: brk             #0
    // 0xc205fc: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xc205fc: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xc20600: str             x16, [SP]
    // 0xc20604: r0 = _throwNew()
    //     0xc20604: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xc20608: brk             #0
    // 0xc2060c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc2060c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc20610: b               #0xc200f0
    // 0xc20614: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc20614: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xc20618: r0 = NullErrorSharedWithFPURegs()
    //     0xc20618: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0xc2061c: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc2061c: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xc20620: r0 = NullErrorSharedWithFPURegs()
    //     0xc20620: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0xc20624: r0 = NullErrorSharedWithFPURegs()
    //     0xc20624: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0xc20628: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc20628: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xc2062c: r0 = NullErrorSharedWithFPURegs()
    //     0xc2062c: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0xc20630: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc20630: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  static _ _addRRectToPath(/* No info */) {
    // ** addr: 0xc20634, size: 0x37c
    // 0xc20634: EnterFrame
    //     0xc20634: stp             fp, lr, [SP, #-0x10]!
    //     0xc20638: mov             fp, SP
    // 0xc2063c: AllocStack(0x98)
    //     0xc2063c: sub             SP, SP, #0x98
    // 0xc20640: SetupParameters(dynamic _ /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* d0 => d0, fp-0x68 */)
    //     0xc20640: mov             x0, x2
    //     0xc20644: stur            x2, [fp, #-0x10]
    //     0xc20648: mov             x2, x1
    //     0xc2064c: stur            x1, [fp, #-8]
    //     0xc20650: stur            d0, [fp, #-0x68]
    // 0xc20654: CheckStackOverflow
    //     0xc20654: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc20658: cmp             SP, x16
    //     0xc2065c: b.ls            #0xc20978
    // 0xc20660: mov             x1, x0
    // 0xc20664: r0 = outerRect()
    //     0xc20664: bl              #0xaf8a18  ; [dart:ui] _RRectLike::outerRect
    // 0xc20668: stur            x0, [fp, #-0x18]
    // 0xc2066c: ArrayLoad: d0 = r0[0]  ; List_8
    //     0xc2066c: ldur            d0, [x0, #0x17]
    // 0xc20670: stur            d0, [fp, #-0x78]
    // 0xc20674: LoadField: d1 = r0->field_1f
    //     0xc20674: ldur            d1, [x0, #0x1f]
    // 0xc20678: stur            d1, [fp, #-0x70]
    // 0xc2067c: r0 = Offset()
    //     0xc2067c: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xc20680: ldur            d0, [fp, #-0x78]
    // 0xc20684: stur            x0, [fp, #-0x20]
    // 0xc20688: StoreField: r0->field_7 = d0
    //     0xc20688: stur            d0, [x0, #7]
    // 0xc2068c: ldur            d1, [fp, #-0x70]
    // 0xc20690: StoreField: r0->field_f = d1
    //     0xc20690: stur            d1, [x0, #0xf]
    // 0xc20694: ldur            x1, [fp, #-0x10]
    // 0xc20698: r0 = brRadius()
    //     0xc20698: bl              #0xc20a30  ; [dart:ui] _RRectLike::brRadius
    // 0xc2069c: mov             x1, x0
    // 0xc206a0: r0 = unary-()
    //     0xc206a0: bl              #0xc209ec  ; [dart:ui] Radius::unary-
    // 0xc206a4: mov             x1, x0
    // 0xc206a8: ldur            x0, [fp, #-0x18]
    // 0xc206ac: stur            x1, [fp, #-0x28]
    // 0xc206b0: LoadField: d0 = r0->field_7
    //     0xc206b0: ldur            d0, [x0, #7]
    // 0xc206b4: stur            d0, [fp, #-0x80]
    // 0xc206b8: r0 = Offset()
    //     0xc206b8: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xc206bc: ldur            d0, [fp, #-0x80]
    // 0xc206c0: stur            x0, [fp, #-0x30]
    // 0xc206c4: StoreField: r0->field_7 = d0
    //     0xc206c4: stur            d0, [x0, #7]
    // 0xc206c8: ldur            d1, [fp, #-0x70]
    // 0xc206cc: StoreField: r0->field_f = d1
    //     0xc206cc: stur            d1, [x0, #0xf]
    // 0xc206d0: ldur            x1, [fp, #-0x10]
    // 0xc206d4: LoadField: d1 = r1->field_5b
    //     0xc206d4: ldur            d1, [x1, #0x5b]
    // 0xc206d8: stur            d1, [fp, #-0x88]
    // 0xc206dc: LoadField: d2 = r1->field_63
    //     0xc206dc: ldur            d2, [x1, #0x63]
    // 0xc206e0: fneg            d3, d2
    // 0xc206e4: stur            d3, [fp, #-0x70]
    // 0xc206e8: r0 = Radius()
    //     0xc206e8: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0xc206ec: ldur            d0, [fp, #-0x88]
    // 0xc206f0: stur            x0, [fp, #-0x38]
    // 0xc206f4: StoreField: r0->field_7 = d0
    //     0xc206f4: stur            d0, [x0, #7]
    // 0xc206f8: ldur            d0, [fp, #-0x70]
    // 0xc206fc: StoreField: r0->field_f = d0
    //     0xc206fc: stur            d0, [x0, #0xf]
    // 0xc20700: ldur            x1, [fp, #-0x18]
    // 0xc20704: LoadField: d0 = r1->field_f
    //     0xc20704: ldur            d0, [x1, #0xf]
    // 0xc20708: stur            d0, [fp, #-0x70]
    // 0xc2070c: r0 = Offset()
    //     0xc2070c: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xc20710: ldur            d0, [fp, #-0x80]
    // 0xc20714: stur            x0, [fp, #-0x18]
    // 0xc20718: StoreField: r0->field_7 = d0
    //     0xc20718: stur            d0, [x0, #7]
    // 0xc2071c: ldur            d0, [fp, #-0x70]
    // 0xc20720: StoreField: r0->field_f = d0
    //     0xc20720: stur            d0, [x0, #0xf]
    // 0xc20724: ldur            x1, [fp, #-0x10]
    // 0xc20728: r0 = tlRadius()
    //     0xc20728: bl              #0xc209b0  ; [dart:ui] _RRectLike::tlRadius
    // 0xc2072c: stur            x0, [fp, #-0x40]
    // 0xc20730: r0 = Offset()
    //     0xc20730: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xc20734: ldur            d0, [fp, #-0x78]
    // 0xc20738: stur            x0, [fp, #-0x48]
    // 0xc2073c: StoreField: r0->field_7 = d0
    //     0xc2073c: stur            d0, [x0, #7]
    // 0xc20740: ldur            d0, [fp, #-0x70]
    // 0xc20744: StoreField: r0->field_f = d0
    //     0xc20744: stur            d0, [x0, #0xf]
    // 0xc20748: ldur            x1, [fp, #-0x10]
    // 0xc2074c: LoadField: d0 = r1->field_3b
    //     0xc2074c: ldur            d0, [x1, #0x3b]
    // 0xc20750: fneg            d1, d0
    // 0xc20754: stur            d1, [fp, #-0x78]
    // 0xc20758: LoadField: d0 = r1->field_43
    //     0xc20758: ldur            d0, [x1, #0x43]
    // 0xc2075c: stur            d0, [fp, #-0x70]
    // 0xc20760: r0 = Radius()
    //     0xc20760: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0xc20764: ldur            d0, [fp, #-0x78]
    // 0xc20768: stur            x0, [fp, #-0x10]
    // 0xc2076c: StoreField: r0->field_7 = d0
    //     0xc2076c: stur            d0, [x0, #7]
    // 0xc20770: ldur            d0, [fp, #-0x70]
    // 0xc20774: StoreField: r0->field_f = d0
    //     0xc20774: stur            d0, [x0, #0xf]
    // 0xc20778: ldur            x2, [fp, #-0x20]
    // 0xc2077c: ldur            x3, [fp, #-0x28]
    // 0xc20780: r0 = AllocateRecord2()
    //     0xc20780: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xc20784: r1 = Null
    //     0xc20784: mov             x1, NULL
    // 0xc20788: r2 = 8
    //     0xc20788: mov             x2, #8
    // 0xc2078c: stur            x0, [fp, #-0x20]
    // 0xc20790: r0 = AllocateArray()
    //     0xc20790: bl              #0x13df928  ; AllocateArrayStub
    // 0xc20794: mov             x1, x0
    // 0xc20798: ldur            x0, [fp, #-0x20]
    // 0xc2079c: stur            x1, [fp, #-0x28]
    // 0xc207a0: StoreField: r1->field_f = r0
    //     0xc207a0: stur            w0, [x1, #0xf]
    // 0xc207a4: ldur            x2, [fp, #-0x30]
    // 0xc207a8: ldur            x3, [fp, #-0x38]
    // 0xc207ac: r0 = AllocateRecord2()
    //     0xc207ac: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xc207b0: mov             x1, x0
    // 0xc207b4: ldur            x0, [fp, #-0x28]
    // 0xc207b8: StoreField: r0->field_13 = r1
    //     0xc207b8: stur            w1, [x0, #0x13]
    // 0xc207bc: ldur            x2, [fp, #-0x18]
    // 0xc207c0: ldur            x3, [fp, #-0x40]
    // 0xc207c4: r0 = AllocateRecord2()
    //     0xc207c4: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xc207c8: mov             x1, x0
    // 0xc207cc: ldur            x0, [fp, #-0x28]
    // 0xc207d0: ArrayStore: r0[0] = r1  ; List_4
    //     0xc207d0: stur            w1, [x0, #0x17]
    // 0xc207d4: ldur            x2, [fp, #-0x48]
    // 0xc207d8: ldur            x3, [fp, #-0x10]
    // 0xc207dc: r0 = AllocateRecord2()
    //     0xc207dc: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xc207e0: mov             x1, x0
    // 0xc207e4: ldur            x0, [fp, #-0x28]
    // 0xc207e8: StoreField: r0->field_1b = r1
    //     0xc207e8: stur            w1, [x0, #0x1b]
    // 0xc207ec: ldur            d0, [fp, #-0x68]
    // 0xc207f0: r1 = inline_Allocate_Double()
    //     0xc207f0: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xc207f4: add             x1, x1, #0x10
    //     0xc207f8: cmp             x2, x1
    //     0xc207fc: b.ls            #0xc20980
    //     0xc20800: str             x1, [THR, #0x60]  ; THR::top
    //     0xc20804: sub             x1, x1, #0xf
    //     0xc20808: mov             x2, #0xe19c
    //     0xc2080c: movk            x2, #3, lsl #16
    //     0xc20810: stur            x2, [x1, #-1]
    // 0xc20814: dmb             ishst
    // 0xc20818: StoreField: r1->field_7 = d0
    //     0xc20818: stur            d0, [x1, #7]
    // 0xc2081c: r16 = 1.570796
    //     0xc2081c: add             x16, PP, #0x95, lsl #12  ; [pp+0x95ed0] 1.5707963267948966
    //     0xc20820: ldr             x16, [x16, #0xed0]
    // 0xc20824: stp             x16, x1, [SP]
    // 0xc20828: r0 = ~/()
    //     0xc20828: bl              #0x13d8ee8  ; [dart:core] _Double::~/
    // 0xc2082c: r1 = LoadInt32Instr(r0)
    //     0xc2082c: sbfx            x1, x0, #1, #0x1f
    //     0xc20830: tbz             w0, #0, #0xc20838
    //     0xc20834: ldur            x1, [x0, #7]
    // 0xc20838: add             x0, x1, #4
    // 0xc2083c: stur            x0, [fp, #-0x60]
    // 0xc20840: mov             x5, x1
    // 0xc20844: ldur            x3, [fp, #-8]
    // 0xc20848: ldur            x2, [fp, #-0x28]
    // 0xc2084c: d0 = 2.000000
    //     0xc2084c: fmov            d0, #2.00000000
    // 0xc20850: r4 = 4
    //     0xc20850: mov             x4, #4
    // 0xc20854: d5 = 1.570796
    //     0xc20854: add             x17, PP, #0x95, lsl #12  ; [pp+0x95ed8] IMM: double(1.5707963267948966) from 0x3ff921fb54442d18
    //     0xc20858: ldr             d5, [x17, #0xed8]
    // 0xc2085c: stur            x5, [fp, #-0x58]
    // 0xc20860: CheckStackOverflow
    //     0xc20860: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc20864: cmp             SP, x16
    //     0xc20868: b.ls            #0xc2099c
    // 0xc2086c: cmp             x5, x0
    // 0xc20870: b.ge            #0xc20958
    // 0xc20874: sdiv            x6, x5, x4
    // 0xc20878: msub            x1, x6, x4, x5
    // 0xc2087c: cmp             x1, xzr
    // 0xc20880: b.lt            #0xc209a4
    // 0xc20884: ArrayLoad: r6 = r2[r1]  ; Unknown_4
    //     0xc20884: add             x16, x2, x1, lsl #2
    //     0xc20888: ldur            w6, [x16, #0xf]
    // 0xc2088c: DecompressPointer r6
    //     0xc2088c: add             x6, x6, HEAP, lsl #32
    // 0xc20890: LoadField: r1 = r6->field_f
    //     0xc20890: ldur            w1, [x6, #0xf]
    // 0xc20894: DecompressPointer r1
    //     0xc20894: add             x1, x1, HEAP, lsl #32
    // 0xc20898: LoadField: r7 = r6->field_13
    //     0xc20898: ldur            w7, [x6, #0x13]
    // 0xc2089c: DecompressPointer r7
    //     0xc2089c: add             x7, x7, HEAP, lsl #32
    // 0xc208a0: LoadField: d1 = r1->field_7
    //     0xc208a0: ldur            d1, [x1, #7]
    // 0xc208a4: LoadField: d2 = r7->field_7
    //     0xc208a4: ldur            d2, [x7, #7]
    // 0xc208a8: fmul            d3, d2, d0
    // 0xc208ac: fadd            d2, d1, d3
    // 0xc208b0: LoadField: d3 = r1->field_f
    //     0xc208b0: ldur            d3, [x1, #0xf]
    // 0xc208b4: LoadField: d4 = r7->field_f
    //     0xc208b4: ldur            d4, [x7, #0xf]
    // 0xc208b8: fmul            d6, d4, d0
    // 0xc208bc: fadd            d4, d3, d6
    // 0xc208c0: fmin            v6.2d, v1.2d, v2.2d
    // 0xc208c4: stur            d6, [fp, #-0x88]
    // 0xc208c8: fmin            v7.2d, v3.2d, v4.2d
    // 0xc208cc: stur            d7, [fp, #-0x80]
    // 0xc208d0: fmax            v8.2d, v1.2d, v2.2d
    // 0xc208d4: stur            d8, [fp, #-0x78]
    // 0xc208d8: fmax            v1.2d, v3.2d, v4.2d
    // 0xc208dc: stur            d1, [fp, #-0x70]
    // 0xc208e0: scvtf           d2, x5
    // 0xc208e4: fmul            d4, d2, d5
    // 0xc208e8: stur            d4, [fp, #-0x68]
    // 0xc208ec: LoadField: r1 = r3->field_7
    //     0xc208ec: ldur            w1, [x3, #7]
    // 0xc208f0: DecompressPointer r1
    //     0xc208f0: add             x1, x1, HEAP, lsl #32
    // 0xc208f4: cmp             w1, NULL
    // 0xc208f8: b.eq            #0xc209ac
    // 0xc208fc: LoadField: r6 = r1->field_7
    //     0xc208fc: ldur            x6, [x1, #7]
    // 0xc20900: ldr             x1, [x6]
    // 0xc20904: cbz             x1, #0xc20968
    // 0xc20908: mov             x6, x1
    // 0xc2090c: stur            x6, [fp, #-0x50]
    // 0xc20910: r1 = <Never>
    //     0xc20910: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xc20914: r0 = Pointer()
    //     0xc20914: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xc20918: mov             x1, x0
    // 0xc2091c: ldur            x0, [fp, #-0x50]
    // 0xc20920: StoreField: r1->field_7 = r0
    //     0xc20920: stur            x0, [x1, #7]
    // 0xc20924: ldur            d0, [fp, #-0x88]
    // 0xc20928: ldur            d1, [fp, #-0x80]
    // 0xc2092c: ldur            d2, [fp, #-0x78]
    // 0xc20930: ldur            d3, [fp, #-0x70]
    // 0xc20934: ldur            d4, [fp, #-0x68]
    // 0xc20938: d5 = 1.570796
    //     0xc20938: add             x17, PP, #0x95, lsl #12  ; [pp+0x95ed8] IMM: double(1.5707963267948966) from 0x3ff921fb54442d18
    //     0xc2093c: ldr             d5, [x17, #0xed8]
    // 0xc20940: r2 = false
    //     0xc20940: add             x2, NULL, #0x30  ; false
    // 0xc20944: r0 = __arcTo$Method$FfiNative()
    //     0xc20944: bl              #0xb80f88  ; [dart:ui] _NativePath::__arcTo$Method$FfiNative
    // 0xc20948: ldur            x0, [fp, #-0x58]
    // 0xc2094c: add             x5, x0, #1
    // 0xc20950: ldur            x0, [fp, #-0x60]
    // 0xc20954: b               #0xc20844
    // 0xc20958: ldur            x0, [fp, #-8]
    // 0xc2095c: LeaveFrame
    //     0xc2095c: mov             SP, fp
    //     0xc20960: ldp             fp, lr, [SP], #0x10
    // 0xc20964: ret
    //     0xc20964: ret             
    // 0xc20968: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xc20968: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xc2096c: str             x16, [SP]
    // 0xc20970: r0 = _throwNew()
    //     0xc20970: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xc20974: brk             #0
    // 0xc20978: r0 = StackOverflowSharedWithFPURegs()
    //     0xc20978: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xc2097c: b               #0xc20660
    // 0xc20980: SaveReg d0
    //     0xc20980: str             q0, [SP, #-0x10]!
    // 0xc20984: SaveReg r0
    //     0xc20984: str             x0, [SP, #-8]!
    // 0xc20988: r0 = AllocateDouble()
    //     0xc20988: bl              #0x13df878  ; AllocateDoubleStub
    // 0xc2098c: mov             x1, x0
    // 0xc20990: RestoreReg r0
    //     0xc20990: ldr             x0, [SP], #8
    // 0xc20994: RestoreReg d0
    //     0xc20994: ldr             q0, [SP], #0x10
    // 0xc20998: b               #0xc20818
    // 0xc2099c: r0 = StackOverflowSharedWithFPURegs()
    //     0xc2099c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xc209a0: b               #0xc2086c
    // 0xc209a4: add             x1, x1, x4
    // 0xc209a8: b               #0xc20884
    // 0xc209ac: r0 = NullErrorSharedWithFPURegs()
    //     0xc209ac: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
  }
  _ _shapeRRect(/* No info */) {
    // ** addr: 0xc20a6c, size: 0xd8
    // 0xc20a6c: EnterFrame
    //     0xc20a6c: stp             fp, lr, [SP, #-0x10]!
    //     0xc20a70: mov             fp, SP
    // 0xc20a74: AllocStack(0x20)
    //     0xc20a74: sub             SP, SP, #0x20
    // 0xc20a78: r0 = Instance_Size
    //     0xc20a78: add             x0, PP, #0x98, lsl #12  ; [pp+0x986b0] Obj!Size@12a7531
    //     0xc20a7c: ldr             x0, [x0, #0x6b0]
    // 0xc20a80: mov             x16, x2
    // 0xc20a84: mov             x2, x1
    // 0xc20a88: mov             x1, x16
    // 0xc20a8c: stur            x1, [fp, #-8]
    // 0xc20a90: CheckStackOverflow
    //     0xc20a90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc20a94: cmp             SP, x16
    //     0xc20a98: b.ls            #0xc20b3c
    // 0xc20a9c: LoadField: d0 = r0->field_f
    //     0xc20a9c: ldur            d0, [x0, #0xf]
    // 0xc20aa0: stur            d0, [fp, #-0x18]
    // 0xc20aa4: r0 = Offset()
    //     0xc20aa4: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xc20aa8: stur            x0, [fp, #-0x10]
    // 0xc20aac: StoreField: r0->field_7 = rZR
    //     0xc20aac: stur            xzr, [x0, #7]
    // 0xc20ab0: ldur            d0, [fp, #-0x18]
    // 0xc20ab4: StoreField: r0->field_f = d0
    //     0xc20ab4: stur            d0, [x0, #0xf]
    // 0xc20ab8: ldur            x1, [fp, #-8]
    // 0xc20abc: r0 = size()
    //     0xc20abc: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc20ac0: LoadField: d0 = r0->field_7
    //     0xc20ac0: ldur            d0, [x0, #7]
    // 0xc20ac4: ldur            x1, [fp, #-8]
    // 0xc20ac8: stur            d0, [fp, #-0x18]
    // 0xc20acc: r0 = size()
    //     0xc20acc: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc20ad0: LoadField: d0 = r0->field_f
    //     0xc20ad0: ldur            d0, [x0, #0xf]
    // 0xc20ad4: d1 = 14.000000
    //     0xc20ad4: fmov            d1, #14.00000000
    // 0xc20ad8: fsub            d2, d0, d1
    // 0xc20adc: stur            d2, [fp, #-0x20]
    // 0xc20ae0: r0 = Size()
    //     0xc20ae0: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xc20ae4: ldur            d0, [fp, #-0x18]
    // 0xc20ae8: StoreField: r0->field_7 = d0
    //     0xc20ae8: stur            d0, [x0, #7]
    // 0xc20aec: ldur            d0, [fp, #-0x20]
    // 0xc20af0: StoreField: r0->field_f = d0
    //     0xc20af0: stur            d0, [x0, #0xf]
    // 0xc20af4: ldur            x1, [fp, #-0x10]
    // 0xc20af8: mov             x2, x0
    // 0xc20afc: r0 = &()
    //     0xc20afc: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xc20b00: r1 = <RRect>
    //     0xc20b00: add             x1, PP, #0x85, lsl #12  ; [pp+0x85108] TypeArguments: <RRect>
    //     0xc20b04: ldr             x1, [x1, #0x108]
    // 0xc20b08: stur            x0, [fp, #-8]
    // 0xc20b0c: r0 = RRect()
    //     0xc20b0c: bl              #0xb6e214  ; AllocateRRectStub -> RRect (size=0x6c)
    // 0xc20b10: mov             x1, x0
    // 0xc20b14: ldur            x2, [fp, #-8]
    // 0xc20b18: r3 = Instance_Radius
    //     0xc20b18: add             x3, PP, #0x98, lsl #12  ; [pp+0x986c8] Obj!Radius@12a71e1
    //     0xc20b1c: ldr             x3, [x3, #0x6c8]
    // 0xc20b20: stur            x0, [fp, #-8]
    // 0xc20b24: r0 = RRect.fromRectAndRadius()
    //     0xc20b24: bl              #0xb6e920  ; [dart:ui] RRect::RRect.fromRectAndRadius
    // 0xc20b28: ldur            x1, [fp, #-8]
    // 0xc20b2c: r0 = scaleRadii()
    //     0xc20b2c: bl              #0xaf8eac  ; [dart:ui] _RRectLike::scaleRadii
    // 0xc20b30: LeaveFrame
    //     0xc20b30: mov             SP, fp
    //     0xc20b34: ldp             fp, lr, [SP], #0x10
    // 0xc20b38: ret
    //     0xc20b38: ret             
    // 0xc20b3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc20b3c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc20b40: b               #0xc20a9c
  }
  set _ shadowColor=(/* No info */) {
    // ** addr: 0xcf4368, size: 0xa4
    // 0xcf4368: EnterFrame
    //     0xcf4368: stp             fp, lr, [SP, #-0x10]!
    //     0xcf436c: mov             fp, SP
    // 0xcf4370: AllocStack(0x20)
    //     0xcf4370: sub             SP, SP, #0x20
    // 0xcf4374: SetupParameters(_RenderCupertinoTextSelectionToolbarShape this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xcf4374: stur            x1, [fp, #-8]
    //     0xcf4378: mov             x16, x2
    //     0xcf437c: mov             x2, x1
    //     0xcf4380: mov             x1, x16
    //     0xcf4384: stur            x1, [fp, #-0x10]
    // 0xcf4388: CheckStackOverflow
    //     0xcf4388: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf438c: cmp             SP, x16
    //     0xcf4390: b.ls            #0xcf4404
    // 0xcf4394: LoadField: r0 = r2->field_5b
    //     0xcf4394: ldur            w0, [x2, #0x5b]
    // 0xcf4398: DecompressPointer r0
    //     0xcf4398: add             x0, x0, HEAP, lsl #32
    // 0xcf439c: r3 = LoadClassIdInstr(r1)
    //     0xcf439c: ldur            x3, [x1, #-1]
    //     0xcf43a0: ubfx            x3, x3, #0xc, #0x14
    // 0xcf43a4: stp             x0, x1, [SP]
    // 0xcf43a8: mov             x0, x3
    // 0xcf43ac: mov             lr, x0
    // 0xcf43b0: ldr             lr, [x21, lr, lsl #3]
    // 0xcf43b4: blr             lr
    // 0xcf43b8: tbnz            w0, #4, #0xcf43cc
    // 0xcf43bc: r0 = Null
    //     0xcf43bc: mov             x0, NULL
    // 0xcf43c0: LeaveFrame
    //     0xcf43c0: mov             SP, fp
    //     0xcf43c4: ldp             fp, lr, [SP], #0x10
    // 0xcf43c8: ret
    //     0xcf43c8: ret             
    // 0xcf43cc: ldur            x1, [fp, #-8]
    // 0xcf43d0: ldur            x0, [fp, #-0x10]
    // 0xcf43d4: StoreField: r1->field_5b = r0
    //     0xcf43d4: stur            w0, [x1, #0x5b]
    //     0xcf43d8: ldurb           w16, [x1, #-1]
    //     0xcf43dc: ldurb           w17, [x0, #-1]
    //     0xcf43e0: and             x16, x17, x16, lsr #2
    //     0xcf43e4: tst             x16, HEAP, lsr #32
    //     0xcf43e8: b.eq            #0xcf43f0
    //     0xcf43ec: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf43f0: r0 = markNeedsPaint()
    //     0xcf43f0: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xcf43f4: r0 = Null
    //     0xcf43f4: mov             x0, NULL
    // 0xcf43f8: LeaveFrame
    //     0xcf43f8: mov             SP, fp
    //     0xcf43fc: ldp             fp, lr, [SP], #0x10
    // 0xcf4400: ret
    //     0xcf4400: ret             
    // 0xcf4404: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf4404: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf4408: b               #0xcf4394
  }
  set _ anchorBelow=(/* No info */) {
    // ** addr: 0xcf440c, size: 0x88
    // 0xcf440c: EnterFrame
    //     0xcf440c: stp             fp, lr, [SP, #-0x10]!
    //     0xcf4410: mov             fp, SP
    // 0xcf4414: AllocStack(0x20)
    //     0xcf4414: sub             SP, SP, #0x20
    // 0xcf4418: SetupParameters(_RenderCupertinoTextSelectionToolbarShape this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xcf4418: mov             x0, x2
    //     0xcf441c: stur            x1, [fp, #-8]
    //     0xcf4420: stur            x2, [fp, #-0x10]
    // 0xcf4424: CheckStackOverflow
    //     0xcf4424: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf4428: cmp             SP, x16
    //     0xcf442c: b.ls            #0xcf448c
    // 0xcf4430: LoadField: r2 = r1->field_57
    //     0xcf4430: ldur            w2, [x1, #0x57]
    // 0xcf4434: DecompressPointer r2
    //     0xcf4434: add             x2, x2, HEAP, lsl #32
    // 0xcf4438: stp             x2, x0, [SP]
    // 0xcf443c: r0 = ==()
    //     0xcf443c: bl              #0x128bd28  ; [dart:ui] Offset::==
    // 0xcf4440: tbnz            w0, #4, #0xcf4454
    // 0xcf4444: r0 = Null
    //     0xcf4444: mov             x0, NULL
    // 0xcf4448: LeaveFrame
    //     0xcf4448: mov             SP, fp
    //     0xcf444c: ldp             fp, lr, [SP], #0x10
    // 0xcf4450: ret
    //     0xcf4450: ret             
    // 0xcf4454: ldur            x1, [fp, #-8]
    // 0xcf4458: ldur            x0, [fp, #-0x10]
    // 0xcf445c: StoreField: r1->field_57 = r0
    //     0xcf445c: stur            w0, [x1, #0x57]
    //     0xcf4460: ldurb           w16, [x1, #-1]
    //     0xcf4464: ldurb           w17, [x0, #-1]
    //     0xcf4468: and             x16, x17, x16, lsr #2
    //     0xcf446c: tst             x16, HEAP, lsr #32
    //     0xcf4470: b.eq            #0xcf4478
    //     0xcf4474: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf4478: r0 = markNeedsLayout()
    //     0xcf4478: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcf447c: r0 = Null
    //     0xcf447c: mov             x0, NULL
    // 0xcf4480: LeaveFrame
    //     0xcf4480: mov             SP, fp
    //     0xcf4484: ldp             fp, lr, [SP], #0x10
    // 0xcf4488: ret
    //     0xcf4488: ret             
    // 0xcf448c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf448c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf4490: b               #0xcf4430
  }
  set _ anchorAbove=(/* No info */) {
    // ** addr: 0xcf4494, size: 0x88
    // 0xcf4494: EnterFrame
    //     0xcf4494: stp             fp, lr, [SP, #-0x10]!
    //     0xcf4498: mov             fp, SP
    // 0xcf449c: AllocStack(0x20)
    //     0xcf449c: sub             SP, SP, #0x20
    // 0xcf44a0: SetupParameters(_RenderCupertinoTextSelectionToolbarShape this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xcf44a0: mov             x0, x2
    //     0xcf44a4: stur            x1, [fp, #-8]
    //     0xcf44a8: stur            x2, [fp, #-0x10]
    // 0xcf44ac: CheckStackOverflow
    //     0xcf44ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf44b0: cmp             SP, x16
    //     0xcf44b4: b.ls            #0xcf4514
    // 0xcf44b8: LoadField: r2 = r1->field_53
    //     0xcf44b8: ldur            w2, [x1, #0x53]
    // 0xcf44bc: DecompressPointer r2
    //     0xcf44bc: add             x2, x2, HEAP, lsl #32
    // 0xcf44c0: stp             x2, x0, [SP]
    // 0xcf44c4: r0 = ==()
    //     0xcf44c4: bl              #0x128bd28  ; [dart:ui] Offset::==
    // 0xcf44c8: tbnz            w0, #4, #0xcf44dc
    // 0xcf44cc: r0 = Null
    //     0xcf44cc: mov             x0, NULL
    // 0xcf44d0: LeaveFrame
    //     0xcf44d0: mov             SP, fp
    //     0xcf44d4: ldp             fp, lr, [SP], #0x10
    // 0xcf44d8: ret
    //     0xcf44d8: ret             
    // 0xcf44dc: ldur            x1, [fp, #-8]
    // 0xcf44e0: ldur            x0, [fp, #-0x10]
    // 0xcf44e4: StoreField: r1->field_53 = r0
    //     0xcf44e4: stur            w0, [x1, #0x53]
    //     0xcf44e8: ldurb           w16, [x1, #-1]
    //     0xcf44ec: ldurb           w17, [x0, #-1]
    //     0xcf44f0: and             x16, x17, x16, lsr #2
    //     0xcf44f4: tst             x16, HEAP, lsr #32
    //     0xcf44f8: b.eq            #0xcf4500
    //     0xcf44fc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf4500: r0 = markNeedsLayout()
    //     0xcf4500: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcf4504: r0 = Null
    //     0xcf4504: mov             x0, NULL
    // 0xcf4508: LeaveFrame
    //     0xcf4508: mov             SP, fp
    //     0xcf450c: ldp             fp, lr, [SP], #0x10
    // 0xcf4510: ret
    //     0xcf4510: ret             
    // 0xcf4514: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf4514: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf4518: b               #0xcf44b8
  }
  _ hitTestChildren(/* No info */) {
    // ** addr: 0x10e98cc, size: 0x174
    // 0x10e98cc: EnterFrame
    //     0x10e98cc: stp             fp, lr, [SP, #-0x10]!
    //     0x10e98d0: mov             fp, SP
    // 0x10e98d4: AllocStack(0x48)
    //     0x10e98d4: sub             SP, SP, #0x48
    // 0x10e98d8: SetupParameters(_RenderCupertinoTextSelectionToolbarShape this /* r1 => r5, fp-0x18 */, dynamic _ /* r2 => r4, fp-0x20 */, dynamic _ /* r3 => r3, fp-0x28 */)
    //     0x10e98d8: mov             x5, x1
    //     0x10e98dc: mov             x4, x2
    //     0x10e98e0: stur            x1, [fp, #-0x18]
    //     0x10e98e4: stur            x2, [fp, #-0x20]
    //     0x10e98e8: stur            x3, [fp, #-0x28]
    // 0x10e98ec: CheckStackOverflow
    //     0x10e98ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e98f0: cmp             SP, x16
    //     0x10e98f4: b.ls            #0x10e9a34
    // 0x10e98f8: LoadField: r6 = r5->field_4f
    //     0x10e98f8: ldur            w6, [x5, #0x4f]
    // 0x10e98fc: DecompressPointer r6
    //     0x10e98fc: add             x6, x6, HEAP, lsl #32
    // 0x10e9900: stur            x6, [fp, #-0x10]
    // 0x10e9904: cmp             w6, NULL
    // 0x10e9908: b.ne            #0x10e991c
    // 0x10e990c: r0 = false
    //     0x10e990c: add             x0, NULL, #0x30  ; false
    // 0x10e9910: LeaveFrame
    //     0x10e9910: mov             SP, fp
    //     0x10e9914: ldp             fp, lr, [SP], #0x10
    // 0x10e9918: ret
    //     0x10e9918: ret             
    // 0x10e991c: LoadField: r7 = r6->field_7
    //     0x10e991c: ldur            w7, [x6, #7]
    // 0x10e9920: DecompressPointer r7
    //     0x10e9920: add             x7, x7, HEAP, lsl #32
    // 0x10e9924: stur            x7, [fp, #-8]
    // 0x10e9928: cmp             w7, NULL
    // 0x10e992c: b.eq            #0x10e9a3c
    // 0x10e9930: mov             x0, x7
    // 0x10e9934: r2 = Null
    //     0x10e9934: mov             x2, NULL
    // 0x10e9938: r1 = Null
    //     0x10e9938: mov             x1, NULL
    // 0x10e993c: r4 = LoadClassIdInstr(r0)
    //     0x10e993c: ldur            x4, [x0, #-1]
    //     0x10e9940: ubfx            x4, x4, #0xc, #0x14
    // 0x10e9944: r17 = -4190
    //     0x10e9944: mov             x17, #-0x105e
    // 0x10e9948: add             x4, x4, x17
    // 0x10e994c: cmp             x4, #0x17
    // 0x10e9950: b.ls            #0x10e9968
    // 0x10e9954: r8 = BoxParentData
    //     0x10e9954: add             x8, PP, #0x15, lsl #12  ; [pp+0x155e8] Type: BoxParentData
    //     0x10e9958: ldr             x8, [x8, #0x5e8]
    // 0x10e995c: r3 = Null
    //     0x10e995c: add             x3, PP, #0x98, lsl #12  ; [pp+0x986a0] Null
    //     0x10e9960: ldr             x3, [x3, #0x6a0]
    // 0x10e9964: r0 = DefaultTypeTest()
    //     0x10e9964: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x10e9968: ldur            x0, [fp, #-8]
    // 0x10e996c: LoadField: r1 = r0->field_7
    //     0x10e996c: ldur            w1, [x0, #7]
    // 0x10e9970: DecompressPointer r1
    //     0x10e9970: add             x1, x1, HEAP, lsl #32
    // 0x10e9974: LoadField: d0 = r1->field_7
    //     0x10e9974: ldur            d0, [x1, #7]
    // 0x10e9978: stur            d0, [fp, #-0x38]
    // 0x10e997c: LoadField: d1 = r1->field_f
    //     0x10e997c: ldur            d1, [x1, #0xf]
    // 0x10e9980: r0 = Instance_Size
    //     0x10e9980: add             x0, PP, #0x98, lsl #12  ; [pp+0x986b0] Obj!Size@12a7531
    //     0x10e9984: ldr             x0, [x0, #0x6b0]
    // 0x10e9988: LoadField: d2 = r0->field_f
    //     0x10e9988: ldur            d2, [x0, #0xf]
    // 0x10e998c: fadd            d3, d1, d2
    // 0x10e9990: ldur            x1, [fp, #-0x10]
    // 0x10e9994: stur            d3, [fp, #-0x30]
    // 0x10e9998: r0 = size()
    //     0x10e9998: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0x10e999c: LoadField: d0 = r0->field_7
    //     0x10e999c: ldur            d0, [x0, #7]
    // 0x10e99a0: ldur            x1, [fp, #-0x10]
    // 0x10e99a4: stur            d0, [fp, #-0x40]
    // 0x10e99a8: r0 = size()
    //     0x10e99a8: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0x10e99ac: LoadField: d0 = r0->field_f
    //     0x10e99ac: ldur            d0, [x0, #0xf]
    // 0x10e99b0: d1 = 14.000000
    //     0x10e99b0: fmov            d1, #14.00000000
    // 0x10e99b4: fsub            d2, d0, d1
    // 0x10e99b8: ldur            d1, [fp, #-0x38]
    // 0x10e99bc: ldur            d0, [fp, #-0x40]
    // 0x10e99c0: fadd            d3, d1, d0
    // 0x10e99c4: ldur            d0, [fp, #-0x30]
    // 0x10e99c8: stur            d3, [fp, #-0x48]
    // 0x10e99cc: fadd            d4, d0, d2
    // 0x10e99d0: stur            d4, [fp, #-0x40]
    // 0x10e99d4: r0 = Rect()
    //     0x10e99d4: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0x10e99d8: ldur            d0, [fp, #-0x38]
    // 0x10e99dc: StoreField: r0->field_7 = d0
    //     0x10e99dc: stur            d0, [x0, #7]
    // 0x10e99e0: ldur            d0, [fp, #-0x30]
    // 0x10e99e4: StoreField: r0->field_f = d0
    //     0x10e99e4: stur            d0, [x0, #0xf]
    // 0x10e99e8: ldur            d0, [fp, #-0x48]
    // 0x10e99ec: ArrayStore: r0[0] = d0  ; List_8
    //     0x10e99ec: stur            d0, [x0, #0x17]
    // 0x10e99f0: ldur            d0, [fp, #-0x40]
    // 0x10e99f4: StoreField: r0->field_1f = d0
    //     0x10e99f4: stur            d0, [x0, #0x1f]
    // 0x10e99f8: mov             x1, x0
    // 0x10e99fc: ldur            x2, [fp, #-0x28]
    // 0x10e9a00: r0 = contains()
    //     0x10e9a00: bl              #0x81cce0  ; [dart:ui] Rect::contains
    // 0x10e9a04: tbz             w0, #4, #0x10e9a18
    // 0x10e9a08: r0 = false
    //     0x10e9a08: add             x0, NULL, #0x30  ; false
    // 0x10e9a0c: LeaveFrame
    //     0x10e9a0c: mov             SP, fp
    //     0x10e9a10: ldp             fp, lr, [SP], #0x10
    // 0x10e9a14: ret
    //     0x10e9a14: ret             
    // 0x10e9a18: ldur            x1, [fp, #-0x18]
    // 0x10e9a1c: ldur            x2, [fp, #-0x20]
    // 0x10e9a20: ldur            x3, [fp, #-0x28]
    // 0x10e9a24: r0 = hitTestChildren()
    //     0x10e9a24: bl              #0x10e9a40  ; [package:flutter/src/rendering/shifted_box.dart] RenderShiftedBox::hitTestChildren
    // 0x10e9a28: LeaveFrame
    //     0x10e9a28: mov             SP, fp
    //     0x10e9a2c: ldp             fp, lr, [SP], #0x10
    // 0x10e9a30: ret
    //     0x10e9a30: ret             
    // 0x10e9a34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e9a34: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e9a38: b               #0x10e98f8
    // 0x10e9a3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10e9a3c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _RenderCupertinoTextSelectionToolbarShape(/* No info */) {
    // ** addr: 0x11cf544, size: 0x118
    // 0x11cf544: EnterFrame
    //     0x11cf544: stp             fp, lr, [SP, #-0x10]!
    //     0x11cf548: mov             fp, SP
    // 0x11cf54c: AllocStack(0x20)
    //     0x11cf54c: sub             SP, SP, #0x20
    // 0x11cf550: SetupParameters(_RenderCupertinoTextSelectionToolbarShape this /* r1 => r4, fp-0x20 */, dynamic _ /* r2 => r3, fp-0x10 */, dynamic _ /* r3 => r2, fp-0x18 */)
    //     0x11cf550: mov             x4, x1
    //     0x11cf554: stur            x2, [fp, #-0x10]
    //     0x11cf558: mov             x16, x3
    //     0x11cf55c: mov             x3, x2
    //     0x11cf560: mov             x2, x16
    //     0x11cf564: mov             x0, x5
    //     0x11cf568: stur            x1, [fp, #-8]
    //     0x11cf56c: stur            x2, [fp, #-0x18]
    //     0x11cf570: stur            x5, [fp, #-0x20]
    // 0x11cf574: CheckStackOverflow
    //     0x11cf574: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11cf578: cmp             SP, x16
    //     0x11cf57c: b.ls            #0x11cf654
    // 0x11cf580: r1 = <ClipPathLayer>
    //     0x11cf580: add             x1, PP, #0x8e, lsl #12  ; [pp+0x8e730] TypeArguments: <ClipPathLayer>
    //     0x11cf584: ldr             x1, [x1, #0x730]
    // 0x11cf588: r0 = LayerHandle()
    //     0x11cf588: bl              #0x89d118  ; AllocateLayerHandleStub -> LayerHandle<X0 bound Layer> (size=0x10)
    // 0x11cf58c: ldur            x1, [fp, #-8]
    // 0x11cf590: StoreField: r1->field_5f = r0
    //     0x11cf590: stur            w0, [x1, #0x5f]
    //     0x11cf594: ldurb           w16, [x1, #-1]
    //     0x11cf598: ldurb           w17, [x0, #-1]
    //     0x11cf59c: and             x16, x17, x16, lsr #2
    //     0x11cf5a0: tst             x16, HEAP, lsr #32
    //     0x11cf5a4: b.eq            #0x11cf5ac
    //     0x11cf5a8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11cf5ac: ldur            x0, [fp, #-0x10]
    // 0x11cf5b0: StoreField: r1->field_53 = r0
    //     0x11cf5b0: stur            w0, [x1, #0x53]
    //     0x11cf5b4: ldurb           w16, [x1, #-1]
    //     0x11cf5b8: ldurb           w17, [x0, #-1]
    //     0x11cf5bc: and             x16, x17, x16, lsr #2
    //     0x11cf5c0: tst             x16, HEAP, lsr #32
    //     0x11cf5c4: b.eq            #0x11cf5cc
    //     0x11cf5c8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11cf5cc: ldur            x0, [fp, #-0x18]
    // 0x11cf5d0: StoreField: r1->field_57 = r0
    //     0x11cf5d0: stur            w0, [x1, #0x57]
    //     0x11cf5d4: ldurb           w16, [x1, #-1]
    //     0x11cf5d8: ldurb           w17, [x0, #-1]
    //     0x11cf5dc: and             x16, x17, x16, lsr #2
    //     0x11cf5e0: tst             x16, HEAP, lsr #32
    //     0x11cf5e4: b.eq            #0x11cf5ec
    //     0x11cf5e8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11cf5ec: ldur            x0, [fp, #-0x20]
    // 0x11cf5f0: StoreField: r1->field_5b = r0
    //     0x11cf5f0: stur            w0, [x1, #0x5b]
    //     0x11cf5f4: ldurb           w16, [x1, #-1]
    //     0x11cf5f8: ldurb           w17, [x0, #-1]
    //     0x11cf5fc: and             x16, x17, x16, lsr #2
    //     0x11cf600: tst             x16, HEAP, lsr #32
    //     0x11cf604: b.eq            #0x11cf60c
    //     0x11cf608: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11cf60c: r0 = _LayoutCacheStorage()
    //     0x11cf60c: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11cf610: ldur            x2, [fp, #-8]
    // 0x11cf614: StoreField: r2->field_47 = r0
    //     0x11cf614: stur            w0, [x2, #0x47]
    //     0x11cf618: ldurb           w16, [x2, #-1]
    //     0x11cf61c: ldurb           w17, [x0, #-1]
    //     0x11cf620: and             x16, x17, x16, lsr #2
    //     0x11cf624: tst             x16, HEAP, lsr #32
    //     0x11cf628: b.eq            #0x11cf630
    //     0x11cf62c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11cf630: mov             x1, x2
    // 0x11cf634: r0 = RenderObject()
    //     0x11cf634: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11cf638: ldur            x1, [fp, #-8]
    // 0x11cf63c: r2 = Null
    //     0x11cf63c: mov             x2, NULL
    // 0x11cf640: r0 = child=()
    //     0x11cf640: bl              #0xaef33c  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::child=
    // 0x11cf644: r0 = Null
    //     0x11cf644: mov             x0, NULL
    // 0x11cf648: LeaveFrame
    //     0x11cf648: mov             SP, fp
    //     0x11cf64c: ldp             fp, lr, [SP], #0x10
    // 0x11cf650: ret
    //     0x11cf650: ret             
    // 0x11cf654: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11cf654: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11cf658: b               #0x11cf580
  }
}

// class id: 5599, size: 0x30, field offset: 0x1c
class _CupertinoTextSelectionToolbarContentState extends _MixinApplication418&State&TickerProviderStateMixin {

  late AnimationController _controller; // offset: 0x1c

  _ build(/* No info */) {
    // ** addr: 0xd7713c, size: 0x494
    // 0xd7713c: EnterFrame
    //     0xd7713c: stp             fp, lr, [SP, #-0x10]!
    //     0xd77140: mov             fp, SP
    // 0xd77144: AllocStack(0x80)
    //     0xd77144: sub             SP, SP, #0x80
    // 0xd77148: SetupParameters(_CupertinoTextSelectionToolbarContentState this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xd77148: mov             x3, x1
    //     0xd7714c: mov             x0, x2
    //     0xd77150: stur            x1, [fp, #-8]
    //     0xd77154: stur            x2, [fp, #-0x10]
    // 0xd77158: CheckStackOverflow
    //     0xd77158: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd7715c: cmp             SP, x16
    //     0xd77160: b.ls            #0xd775b4
    // 0xd77164: mov             x2, x0
    // 0xd77168: r1 = Instance_CupertinoDynamicColor
    //     0xd77168: add             x1, PP, #0x96, lsl #12  ; [pp+0x96028] Obj!CupertinoDynamicColor@12b3af1
    //     0xd7716c: ldr             x1, [x1, #0x28]
    // 0xd77170: r0 = resolveFrom()
    //     0xd77170: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0xd77174: stur            x0, [fp, #-0x18]
    // 0xd77178: r0 = _LeftCupertinoChevronPainter()
    //     0xd77178: bl              #0xd777d0  ; Allocate_LeftCupertinoChevronPainterStub -> _LeftCupertinoChevronPainter (size=0x14)
    // 0xd7717c: mov             x1, x0
    // 0xd77180: ldur            x0, [fp, #-0x18]
    // 0xd77184: stur            x1, [fp, #-0x20]
    // 0xd77188: StoreField: r1->field_b = r0
    //     0xd77188: stur            w0, [x1, #0xb]
    // 0xd7718c: r2 = true
    //     0xd7718c: add             x2, NULL, #0x20  ; true
    // 0xd77190: StoreField: r1->field_f = r2
    //     0xd77190: stur            w2, [x1, #0xf]
    // 0xd77194: r0 = CustomPaint()
    //     0xd77194: bl              #0xd0a594  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0xd77198: mov             x1, x0
    // 0xd7719c: ldur            x0, [fp, #-0x20]
    // 0xd771a0: stur            x1, [fp, #-0x28]
    // 0xd771a4: StoreField: r1->field_f = r0
    //     0xd771a4: stur            w0, [x1, #0xf]
    // 0xd771a8: r0 = Instance_Size
    //     0xd771a8: add             x0, PP, #0xa2, lsl #12  ; [pp+0xa29b8] Obj!Size@12a7791
    //     0xd771ac: ldr             x0, [x0, #0x9b8]
    // 0xd771b0: ArrayStore: r1[0] = r0  ; List_4
    //     0xd771b0: stur            w0, [x1, #0x17]
    // 0xd771b4: r2 = false
    //     0xd771b4: add             x2, NULL, #0x30  ; false
    // 0xd771b8: StoreField: r1->field_1b = r2
    //     0xd771b8: stur            w2, [x1, #0x1b]
    // 0xd771bc: StoreField: r1->field_1f = r2
    //     0xd771bc: stur            w2, [x1, #0x1f]
    // 0xd771c0: r0 = IgnorePointer()
    //     0xd771c0: bl              #0xbadc08  ; AllocateIgnorePointerStub -> IgnorePointer (size=0x18)
    // 0xd771c4: mov             x3, x0
    // 0xd771c8: r0 = true
    //     0xd771c8: add             x0, NULL, #0x20  ; true
    // 0xd771cc: stur            x3, [fp, #-0x20]
    // 0xd771d0: StoreField: r3->field_f = r0
    //     0xd771d0: stur            w0, [x3, #0xf]
    // 0xd771d4: ldur            x1, [fp, #-0x28]
    // 0xd771d8: StoreField: r3->field_b = r1
    //     0xd771d8: stur            w1, [x3, #0xb]
    // 0xd771dc: ldur            x2, [fp, #-8]
    // 0xd771e0: r1 = Function '_handlePreviousPage@298408280':.
    //     0xd771e0: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa29c0] AnonymousClosure: (0xd77d24), in [package:flutter/src/cupertino/text_selection_toolbar.dart] _CupertinoTextSelectionToolbarContentState::_handlePreviousPage (0xd77b48)
    //     0xd771e4: ldr             x1, [x1, #0x9c0]
    // 0xd771e8: r0 = AllocateClosure()
    //     0xd771e8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd771ec: stur            x0, [fp, #-0x28]
    // 0xd771f0: r0 = CupertinoTextSelectionToolbarButton()
    //     0xd771f0: bl              #0xd777a0  ; AllocateCupertinoTextSelectionToolbarButtonStub -> CupertinoTextSelectionToolbarButton (size=0x1c)
    // 0xd771f4: mov             x1, x0
    // 0xd771f8: ldur            x0, [fp, #-0x28]
    // 0xd771fc: stur            x1, [fp, #-0x30]
    // 0xd77200: ArrayStore: r1[0] = r0  ; List_4
    //     0xd77200: stur            w0, [x1, #0x17]
    // 0xd77204: ldur            x0, [fp, #-0x20]
    // 0xd77208: StoreField: r1->field_13 = r0
    //     0xd77208: stur            w0, [x1, #0x13]
    // 0xd7720c: r0 = Center()
    //     0xd7720c: bl              #0xd0c898  ; AllocateCenterStub -> Center (size=0x1c)
    // 0xd77210: mov             x1, x0
    // 0xd77214: r0 = Instance_Alignment
    //     0xd77214: add             x0, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xd77218: ldr             x0, [x0, #0xb80]
    // 0xd7721c: stur            x1, [fp, #-0x20]
    // 0xd77220: StoreField: r1->field_f = r0
    //     0xd77220: stur            w0, [x1, #0xf]
    // 0xd77224: r2 = 1.000000
    //     0xd77224: ldr             x2, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xd77228: StoreField: r1->field_13 = r2
    //     0xd77228: stur            w2, [x1, #0x13]
    // 0xd7722c: ArrayStore: r1[0] = r2  ; List_4
    //     0xd7722c: stur            w2, [x1, #0x17]
    // 0xd77230: ldur            x3, [fp, #-0x30]
    // 0xd77234: StoreField: r1->field_b = r3
    //     0xd77234: stur            w3, [x1, #0xb]
    // 0xd77238: r0 = _RightCupertinoChevronPainter()
    //     0xd77238: bl              #0xd77794  ; Allocate_RightCupertinoChevronPainterStub -> _RightCupertinoChevronPainter (size=0x14)
    // 0xd7723c: mov             x1, x0
    // 0xd77240: ldur            x0, [fp, #-0x18]
    // 0xd77244: stur            x1, [fp, #-0x28]
    // 0xd77248: StoreField: r1->field_b = r0
    //     0xd77248: stur            w0, [x1, #0xb]
    // 0xd7724c: r0 = false
    //     0xd7724c: add             x0, NULL, #0x30  ; false
    // 0xd77250: StoreField: r1->field_f = r0
    //     0xd77250: stur            w0, [x1, #0xf]
    // 0xd77254: r0 = CustomPaint()
    //     0xd77254: bl              #0xd0a594  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0xd77258: mov             x1, x0
    // 0xd7725c: ldur            x0, [fp, #-0x28]
    // 0xd77260: stur            x1, [fp, #-0x18]
    // 0xd77264: StoreField: r1->field_f = r0
    //     0xd77264: stur            w0, [x1, #0xf]
    // 0xd77268: r0 = Instance_Size
    //     0xd77268: add             x0, PP, #0xa2, lsl #12  ; [pp+0xa29b8] Obj!Size@12a7791
    //     0xd7726c: ldr             x0, [x0, #0x9b8]
    // 0xd77270: ArrayStore: r1[0] = r0  ; List_4
    //     0xd77270: stur            w0, [x1, #0x17]
    // 0xd77274: r0 = false
    //     0xd77274: add             x0, NULL, #0x30  ; false
    // 0xd77278: StoreField: r1->field_1b = r0
    //     0xd77278: stur            w0, [x1, #0x1b]
    // 0xd7727c: StoreField: r1->field_1f = r0
    //     0xd7727c: stur            w0, [x1, #0x1f]
    // 0xd77280: r0 = IgnorePointer()
    //     0xd77280: bl              #0xbadc08  ; AllocateIgnorePointerStub -> IgnorePointer (size=0x18)
    // 0xd77284: mov             x3, x0
    // 0xd77288: r0 = true
    //     0xd77288: add             x0, NULL, #0x20  ; true
    // 0xd7728c: stur            x3, [fp, #-0x28]
    // 0xd77290: StoreField: r3->field_f = r0
    //     0xd77290: stur            w0, [x3, #0xf]
    // 0xd77294: ldur            x0, [fp, #-0x18]
    // 0xd77298: StoreField: r3->field_b = r0
    //     0xd77298: stur            w0, [x3, #0xb]
    // 0xd7729c: ldur            x2, [fp, #-8]
    // 0xd772a0: r1 = Function '_handleNextPage@298408280':.
    //     0xd772a0: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa29c8] AnonymousClosure: (0xd77cec), in [package:flutter/src/cupertino/text_selection_toolbar.dart] _CupertinoTextSelectionToolbarContentState::_handleNextPage (0xd77878)
    //     0xd772a4: ldr             x1, [x1, #0x9c8]
    // 0xd772a8: r0 = AllocateClosure()
    //     0xd772a8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd772ac: stur            x0, [fp, #-0x18]
    // 0xd772b0: r0 = CupertinoTextSelectionToolbarButton()
    //     0xd772b0: bl              #0xd777a0  ; AllocateCupertinoTextSelectionToolbarButtonStub -> CupertinoTextSelectionToolbarButton (size=0x1c)
    // 0xd772b4: mov             x1, x0
    // 0xd772b8: ldur            x0, [fp, #-0x18]
    // 0xd772bc: stur            x1, [fp, #-0x30]
    // 0xd772c0: ArrayStore: r1[0] = r0  ; List_4
    //     0xd772c0: stur            w0, [x1, #0x17]
    // 0xd772c4: ldur            x0, [fp, #-0x28]
    // 0xd772c8: StoreField: r1->field_13 = r0
    //     0xd772c8: stur            w0, [x1, #0x13]
    // 0xd772cc: r0 = Center()
    //     0xd772cc: bl              #0xd0c898  ; AllocateCenterStub -> Center (size=0x1c)
    // 0xd772d0: mov             x3, x0
    // 0xd772d4: r0 = Instance_Alignment
    //     0xd772d4: add             x0, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xd772d8: ldr             x0, [x0, #0xb80]
    // 0xd772dc: stur            x3, [fp, #-0x28]
    // 0xd772e0: StoreField: r3->field_f = r0
    //     0xd772e0: stur            w0, [x3, #0xf]
    // 0xd772e4: r1 = 1.000000
    //     0xd772e4: ldr             x1, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xd772e8: StoreField: r3->field_13 = r1
    //     0xd772e8: stur            w1, [x3, #0x13]
    // 0xd772ec: ArrayStore: r3[0] = r1  ; List_4
    //     0xd772ec: stur            w1, [x3, #0x17]
    // 0xd772f0: ldur            x1, [fp, #-0x30]
    // 0xd772f4: StoreField: r3->field_b = r1
    //     0xd772f4: stur            w1, [x3, #0xb]
    // 0xd772f8: ldur            x4, [fp, #-8]
    // 0xd772fc: LoadField: r1 = r4->field_b
    //     0xd772fc: ldur            w1, [x4, #0xb]
    // 0xd77300: DecompressPointer r1
    //     0xd77300: add             x1, x1, HEAP, lsl #32
    // 0xd77304: cmp             w1, NULL
    // 0xd77308: b.eq            #0xd775bc
    // 0xd7730c: LoadField: r5 = r1->field_13
    //     0xd7730c: ldur            w5, [x1, #0x13]
    // 0xd77310: DecompressPointer r5
    //     0xd77310: add             x5, x5, HEAP, lsl #32
    // 0xd77314: stur            x5, [fp, #-0x18]
    // 0xd77318: r1 = Function '<anonymous closure>':.
    //     0xd77318: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa29d0] AnonymousClosure: (0xd77cb4), in [package:flutter/src/cupertino/text_selection_toolbar.dart] _CupertinoTextSelectionToolbarContentState::build (0xd7713c)
    //     0xd7731c: ldr             x1, [x1, #0x9d0]
    // 0xd77320: r2 = Null
    //     0xd77320: mov             x2, NULL
    // 0xd77324: r0 = AllocateClosure()
    //     0xd77324: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd77328: r16 = <Center>
    //     0xd77328: add             x16, PP, #0xa2, lsl #12  ; [pp+0xa29d8] TypeArguments: <Center>
    //     0xd7732c: ldr             x16, [x16, #0x9d8]
    // 0xd77330: ldur            lr, [fp, #-0x18]
    // 0xd77334: stp             lr, x16, [SP, #8]
    // 0xd77338: str             x0, [SP]
    // 0xd7733c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xd7733c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xd77340: r0 = map()
    //     0xd77340: bl              #0xba574c  ; [dart:collection] ListBase::map
    // 0xd77344: mov             x3, x0
    // 0xd77348: stur            x3, [fp, #-0x30]
    // 0xd7734c: LoadField: r4 = r3->field_7
    //     0xd7734c: ldur            w4, [x3, #7]
    // 0xd77350: DecompressPointer r4
    //     0xd77350: add             x4, x4, HEAP, lsl #32
    // 0xd77354: mov             x0, x3
    // 0xd77358: stur            x4, [fp, #-0x18]
    // 0xd7735c: r2 = Null
    //     0xd7735c: mov             x2, NULL
    // 0xd77360: r1 = Null
    //     0xd77360: mov             x1, NULL
    // 0xd77364: cmp             w0, NULL
    // 0xd77368: b.eq            #0xd77400
    // 0xd7736c: branchIfSmi(r0, 0xd77400)
    //     0xd7736c: tbz             w0, #0, #0xd77400
    // 0xd77370: r3 = LoadClassIdInstr(r0)
    //     0xd77370: ldur            x3, [x0, #-1]
    //     0xd77374: ubfx            x3, x3, #0xc, #0x14
    // 0xd77378: r17 = 7724
    //     0xd77378: mov             x17, #0x1e2c
    // 0xd7737c: cmp             x3, x17
    // 0xd77380: b.eq            #0xd77408
    // 0xd77384: r4 = LoadClassIdInstr(r0)
    //     0xd77384: ldur            x4, [x0, #-1]
    //     0xd77388: ubfx            x4, x4, #0xc, #0x14
    // 0xd7738c: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0xd77390: ldr             x3, [x3, #0x18]
    // 0xd77394: ldr             x3, [x3, x4, lsl #3]
    // 0xd77398: LoadField: r3 = r3->field_2b
    //     0xd77398: ldur            w3, [x3, #0x2b]
    // 0xd7739c: DecompressPointer r3
    //     0xd7739c: add             x3, x3, HEAP, lsl #32
    // 0xd773a0: cmp             w3, NULL
    // 0xd773a4: b.eq            #0xd77400
    // 0xd773a8: LoadField: r3 = r3->field_f
    //     0xd773a8: ldur            w3, [x3, #0xf]
    // 0xd773ac: lsr             x3, x3, #3
    // 0xd773b0: r17 = 7724
    //     0xd773b0: mov             x17, #0x1e2c
    // 0xd773b4: cmp             x3, x17
    // 0xd773b8: b.eq            #0xd77408
    // 0xd773bc: r3 = SubtypeTestCache
    //     0xd773bc: add             x3, PP, #0xa2, lsl #12  ; [pp+0xa29e0] SubtypeTestCache
    //     0xd773c0: ldr             x3, [x3, #0x9e0]
    // 0xd773c4: r30 = Subtype1TestCacheStub
    //     0xd773c4: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0xd773c8: LoadField: r30 = r30->field_7
    //     0xd773c8: ldur            lr, [lr, #7]
    // 0xd773cc: blr             lr
    // 0xd773d0: cmp             w7, NULL
    // 0xd773d4: b.eq            #0xd773e0
    // 0xd773d8: tbnz            w7, #4, #0xd77400
    // 0xd773dc: b               #0xd77408
    // 0xd773e0: r8 = EfficientLengthIterable
    //     0xd773e0: add             x8, PP, #0xa2, lsl #12  ; [pp+0xa29e8] Type: EfficientLengthIterable
    //     0xd773e4: ldr             x8, [x8, #0x9e8]
    // 0xd773e8: r3 = SubtypeTestCache
    //     0xd773e8: add             x3, PP, #0xa2, lsl #12  ; [pp+0xa29f0] SubtypeTestCache
    //     0xd773ec: ldr             x3, [x3, #0x9f0]
    // 0xd773f0: r30 = InstanceOfStub
    //     0xd773f0: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0xd773f4: LoadField: r30 = r30->field_7
    //     0xd773f4: ldur            lr, [lr, #7]
    // 0xd773f8: blr             lr
    // 0xd773fc: b               #0xd7740c
    // 0xd77400: r0 = false
    //     0xd77400: add             x0, NULL, #0x30  ; false
    // 0xd77404: b               #0xd7740c
    // 0xd77408: r0 = true
    //     0xd77408: add             x0, NULL, #0x20  ; true
    // 0xd7740c: tbnz            w0, #4, #0xd77424
    // 0xd77410: ldur            x1, [fp, #-0x18]
    // 0xd77414: ldur            x2, [fp, #-0x30]
    // 0xd77418: r0 = _GrowableList._ofEfficientLengthIterable()
    //     0xd77418: bl              #0x7d732c  ; [dart:core] _GrowableList::_GrowableList._ofEfficientLengthIterable
    // 0xd7741c: mov             x5, x0
    // 0xd77420: b               #0xd77434
    // 0xd77424: ldur            x1, [fp, #-0x18]
    // 0xd77428: ldur            x2, [fp, #-0x30]
    // 0xd7742c: r0 = _GrowableList._ofOther()
    //     0xd7742c: bl              #0x7d94b4  ; [dart:core] _GrowableList::_GrowableList._ofOther
    // 0xd77430: mov             x5, x0
    // 0xd77434: ldur            x3, [fp, #-8]
    // 0xd77438: ldur            x4, [fp, #-0x20]
    // 0xd7743c: ldur            x0, [fp, #-0x28]
    // 0xd77440: stur            x5, [fp, #-0x50]
    // 0xd77444: LoadField: r1 = r3->field_b
    //     0xd77444: ldur            w1, [x3, #0xb]
    // 0xd77448: DecompressPointer r1
    //     0xd77448: add             x1, x1, HEAP, lsl #32
    // 0xd7744c: cmp             w1, NULL
    // 0xd77450: b.eq            #0xd775c0
    // 0xd77454: LoadField: r6 = r1->field_b
    //     0xd77454: ldur            w6, [x1, #0xb]
    // 0xd77458: DecompressPointer r6
    //     0xd77458: add             x6, x6, HEAP, lsl #32
    // 0xd7745c: stur            x6, [fp, #-0x48]
    // 0xd77460: LoadField: r7 = r1->field_f
    //     0xd77460: ldur            w7, [x1, #0xf]
    // 0xd77464: DecompressPointer r7
    //     0xd77464: add             x7, x7, HEAP, lsl #32
    // 0xd77468: stur            x7, [fp, #-0x40]
    // 0xd7746c: LoadField: r8 = r3->field_1b
    //     0xd7746c: ldur            w8, [x3, #0x1b]
    // 0xd77470: DecompressPointer r8
    //     0xd77470: add             x8, x8, HEAP, lsl #32
    // 0xd77474: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd77478: cmp             w8, w16
    // 0xd7747c: b.eq            #0xd775c4
    // 0xd77480: stur            x8, [fp, #-0x30]
    // 0xd77484: LoadField: r9 = r3->field_2b
    //     0xd77484: ldur            w9, [x3, #0x2b]
    // 0xd77488: DecompressPointer r9
    //     0xd77488: add             x9, x9, HEAP, lsl #32
    // 0xd7748c: stur            x9, [fp, #-0x18]
    // 0xd77490: LoadField: r10 = r3->field_23
    //     0xd77490: ldur            x10, [x3, #0x23]
    // 0xd77494: ldur            x2, [fp, #-0x10]
    // 0xd77498: stur            x10, [fp, #-0x38]
    // 0xd7749c: r1 = Instance_CupertinoDynamicColor
    //     0xd7749c: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa29f8] Obj!CupertinoDynamicColor@12b3ab1
    //     0xd774a0: ldr             x1, [x1, #0x9f8]
    // 0xd774a4: r0 = resolveFrom()
    //     0xd774a4: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0xd774a8: ldur            x1, [fp, #-0x10]
    // 0xd774ac: stur            x0, [fp, #-0x58]
    // 0xd774b0: r0 = devicePixelRatioOf()
    //     0xd774b0: bl              #0xcfce5c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::devicePixelRatioOf
    // 0xd774b4: mov             v1.16b, v0.16b
    // 0xd774b8: d0 = 1.000000
    //     0xd774b8: fmov            d0, #1.00000000
    // 0xd774bc: fdiv            d2, d0, d1
    // 0xd774c0: stur            d2, [fp, #-0x68]
    // 0xd774c4: r0 = _CupertinoTextSelectionToolbarItems()
    //     0xd774c4: bl              #0xd77788  ; Allocate_CupertinoTextSelectionToolbarItemsStub -> _CupertinoTextSelectionToolbarItems (size=0x2c)
    // 0xd774c8: mov             x1, x0
    // 0xd774cc: ldur            x0, [fp, #-0x38]
    // 0xd774d0: stur            x1, [fp, #-0x60]
    // 0xd774d4: StoreField: r1->field_23 = r0
    //     0xd774d4: stur            x0, [x1, #0x23]
    // 0xd774d8: ldur            x0, [fp, #-0x50]
    // 0xd774dc: StoreField: r1->field_f = r0
    //     0xd774dc: stur            w0, [x1, #0xf]
    // 0xd774e0: ldur            x0, [fp, #-0x20]
    // 0xd774e4: StoreField: r1->field_b = r0
    //     0xd774e4: stur            w0, [x1, #0xb]
    // 0xd774e8: ldur            x0, [fp, #-0x58]
    // 0xd774ec: StoreField: r1->field_13 = r0
    //     0xd774ec: stur            w0, [x1, #0x13]
    // 0xd774f0: ldur            d0, [fp, #-0x68]
    // 0xd774f4: ArrayStore: r1[0] = d0  ; List_8
    //     0xd774f4: stur            d0, [x1, #0x17]
    // 0xd774f8: ldur            x0, [fp, #-0x28]
    // 0xd774fc: StoreField: r1->field_1f = r0
    //     0xd774fc: stur            w0, [x1, #0x1f]
    // 0xd77500: ldur            x0, [fp, #-0x18]
    // 0xd77504: StoreField: r1->field_7 = r0
    //     0xd77504: stur            w0, [x1, #7]
    // 0xd77508: r0 = GestureDetector()
    //     0xd77508: bl              #0x918e18  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0xd7750c: ldur            x2, [fp, #-8]
    // 0xd77510: r1 = Function '_onHorizontalDragEnd@298408280':.
    //     0xd77510: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2a00] AnonymousClosure: (0xd777dc), in [package:flutter/src/cupertino/text_selection_toolbar.dart] _CupertinoTextSelectionToolbarContentState::_onHorizontalDragEnd (0xd77818)
    //     0xd77514: ldr             x1, [x1, #0xa00]
    // 0xd77518: stur            x0, [fp, #-8]
    // 0xd7751c: r0 = AllocateClosure()
    //     0xd7751c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd77520: ldur            x16, [fp, #-0x60]
    // 0xd77524: stp             x16, x0, [SP]
    // 0xd77528: ldur            x1, [fp, #-8]
    // 0xd7752c: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onHorizontalDragEnd, 0x1, null]
    //     0xd7752c: add             x4, PP, #0xa2, lsl #12  ; [pp+0xa2a08] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onHorizontalDragEnd", 0x1, Null]
    //     0xd77530: ldr             x4, [x4, #0xa08]
    // 0xd77534: r0 = GestureDetector()
    //     0xd77534: bl              #0x9182dc  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0xd77538: r0 = AnimatedSize()
    //     0xd77538: bl              #0xd4aad4  ; AllocateAnimatedSizeStub -> AnimatedSize (size=0x28)
    // 0xd7753c: mov             x1, x0
    // 0xd77540: ldur            x0, [fp, #-8]
    // 0xd77544: stur            x1, [fp, #-0x18]
    // 0xd77548: StoreField: r1->field_b = r0
    //     0xd77548: stur            w0, [x1, #0xb]
    // 0xd7754c: r0 = Instance_Alignment
    //     0xd7754c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xd77550: ldr             x0, [x0, #0xb80]
    // 0xd77554: StoreField: r1->field_f = r0
    //     0xd77554: stur            w0, [x1, #0xf]
    // 0xd77558: r0 = Instance__DecelerateCurve
    //     0xd77558: ldr             x0, [PP, #0x5150]  ; [pp+0x5150] Obj!_DecelerateCurve@129f3d1
    // 0xd7755c: StoreField: r1->field_13 = r0
    //     0xd7755c: stur            w0, [x1, #0x13]
    // 0xd77560: r0 = Instance_Duration
    //     0xd77560: ldr             x0, [PP, #0x5148]  ; [pp+0x5148] Obj!Duration@12c8951
    // 0xd77564: ArrayStore: r1[0] = r0  ; List_4
    //     0xd77564: stur            w0, [x1, #0x17]
    // 0xd77568: r0 = Instance_Clip
    //     0xd77568: add             x0, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xd7756c: ldr             x0, [x0, #0x850]
    // 0xd77570: StoreField: r1->field_1f = r0
    //     0xd77570: stur            w0, [x1, #0x1f]
    // 0xd77574: r0 = FadeTransition()
    //     0xd77574: bl              #0xb28358  ; AllocateFadeTransitionStub -> FadeTransition (size=0x18)
    // 0xd77578: mov             x1, x0
    // 0xd7757c: ldur            x0, [fp, #-0x30]
    // 0xd77580: StoreField: r1->field_f = r0
    //     0xd77580: stur            w0, [x1, #0xf]
    // 0xd77584: r0 = false
    //     0xd77584: add             x0, NULL, #0x30  ; false
    // 0xd77588: StoreField: r1->field_13 = r0
    //     0xd77588: stur            w0, [x1, #0x13]
    // 0xd7758c: ldur            x0, [fp, #-0x18]
    // 0xd77590: StoreField: r1->field_b = r0
    //     0xd77590: stur            w0, [x1, #0xb]
    // 0xd77594: mov             x5, x1
    // 0xd77598: ldur            x1, [fp, #-0x10]
    // 0xd7759c: ldur            x2, [fp, #-0x48]
    // 0xd775a0: ldur            x3, [fp, #-0x40]
    // 0xd775a4: r0 = _defaultToolbarBuilder()
    //     0xd775a4: bl              #0xd7760c  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] CupertinoTextSelectionToolbar::_defaultToolbarBuilder
    // 0xd775a8: LeaveFrame
    //     0xd775a8: mov             SP, fp
    //     0xd775ac: ldp             fp, lr, [SP], #0x10
    // 0xd775b0: ret
    //     0xd775b0: ret             
    // 0xd775b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd775b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd775b8: b               #0xd77164
    // 0xd775bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd775bc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd775c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd775c0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd775c4: r9 = _controller
    //     0xd775c4: add             x9, PP, #0xa2, lsl #12  ; [pp+0xa2a10] Field <_CupertinoTextSelectionToolbarContentState@298408280._controller@298408280>: late (offset: 0x1c)
    //     0xd775c8: ldr             x9, [x9, #0xa10]
    // 0xd775cc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd775cc: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void _onHorizontalDragEnd(dynamic, DragEndDetails) {
    // ** addr: 0xd777dc, size: 0x3c
    // 0xd777dc: EnterFrame
    //     0xd777dc: stp             fp, lr, [SP, #-0x10]!
    //     0xd777e0: mov             fp, SP
    // 0xd777e4: ldr             x0, [fp, #0x18]
    // 0xd777e8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd777e8: ldur            w1, [x0, #0x17]
    // 0xd777ec: DecompressPointer r1
    //     0xd777ec: add             x1, x1, HEAP, lsl #32
    // 0xd777f0: CheckStackOverflow
    //     0xd777f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd777f4: cmp             SP, x16
    //     0xd777f8: b.ls            #0xd77810
    // 0xd777fc: ldr             x2, [fp, #0x10]
    // 0xd77800: r0 = _onHorizontalDragEnd()
    //     0xd77800: bl              #0xd77818  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _CupertinoTextSelectionToolbarContentState::_onHorizontalDragEnd
    // 0xd77804: LeaveFrame
    //     0xd77804: mov             SP, fp
    //     0xd77808: ldp             fp, lr, [SP], #0x10
    // 0xd7780c: ret
    //     0xd7780c: ret             
    // 0xd77810: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd77810: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd77814: b               #0xd777fc
  }
  _ _onHorizontalDragEnd(/* No info */) {
    // ** addr: 0xd77818, size: 0x60
    // 0xd77818: EnterFrame
    //     0xd77818: stp             fp, lr, [SP, #-0x10]!
    //     0xd7781c: mov             fp, SP
    // 0xd77820: CheckStackOverflow
    //     0xd77820: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd77824: cmp             SP, x16
    //     0xd77828: b.ls            #0xd77870
    // 0xd7782c: LoadField: r0 = r2->field_f
    //     0xd7782c: ldur            w0, [x2, #0xf]
    // 0xd77830: DecompressPointer r0
    //     0xd77830: add             x0, x0, HEAP, lsl #32
    // 0xd77834: cmp             w0, NULL
    // 0xd77838: b.eq            #0xd77860
    // 0xd7783c: d0 = 0.000000
    //     0xd7783c: eor             v0.16b, v0.16b, v0.16b
    // 0xd77840: LoadField: d1 = r0->field_7
    //     0xd77840: ldur            d1, [x0, #7]
    // 0xd77844: fcmp            d1, d0
    // 0xd77848: b.eq            #0xd77860
    // 0xd7784c: fcmp            d1, d0
    // 0xd77850: b.le            #0xd7785c
    // 0xd77854: r0 = _handlePreviousPage()
    //     0xd77854: bl              #0xd77b48  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _CupertinoTextSelectionToolbarContentState::_handlePreviousPage
    // 0xd77858: b               #0xd77860
    // 0xd7785c: r0 = _handleNextPage()
    //     0xd7785c: bl              #0xd77878  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _CupertinoTextSelectionToolbarContentState::_handleNextPage
    // 0xd77860: r0 = Null
    //     0xd77860: mov             x0, NULL
    // 0xd77864: LeaveFrame
    //     0xd77864: mov             SP, fp
    //     0xd77868: ldp             fp, lr, [SP], #0x10
    // 0xd7786c: ret
    //     0xd7786c: ret             
    // 0xd77870: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd77870: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd77874: b               #0xd7782c
  }
  _ _handleNextPage(/* No info */) {
    // ** addr: 0xd77878, size: 0x16c
    // 0xd77878: EnterFrame
    //     0xd77878: stp             fp, lr, [SP, #-0x10]!
    //     0xd7787c: mov             fp, SP
    // 0xd77880: AllocStack(0x10)
    //     0xd77880: sub             SP, SP, #0x10
    // 0xd77884: SetupParameters(_CupertinoTextSelectionToolbarContentState this /* r1 => r2, fp-0x8 */)
    //     0xd77884: mov             x2, x1
    //     0xd77888: stur            x1, [fp, #-8]
    // 0xd7788c: CheckStackOverflow
    //     0xd7788c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd77890: cmp             SP, x16
    //     0xd77894: b.ls            #0xd779c4
    // 0xd77898: LoadField: r1 = r2->field_2b
    //     0xd77898: ldur            w1, [x2, #0x2b]
    // 0xd7789c: DecompressPointer r1
    //     0xd7789c: add             x1, x1, HEAP, lsl #32
    // 0xd778a0: r0 = _currentElement()
    //     0xd778a0: bl              #0x859318  ; [package:flutter/src/widgets/framework.dart] GlobalKey::_currentElement
    // 0xd778a4: cmp             w0, NULL
    // 0xd778a8: b.ne            #0xd778b4
    // 0xd778ac: r3 = Null
    //     0xd778ac: mov             x3, NULL
    // 0xd778b0: b               #0xd778c0
    // 0xd778b4: mov             x1, x0
    // 0xd778b8: r0 = findRenderObject()
    //     0xd778b8: bl              #0x8418fc  ; [package:flutter/src/widgets/framework.dart] Element::findRenderObject
    // 0xd778bc: mov             x3, x0
    // 0xd778c0: mov             x0, x3
    // 0xd778c4: stur            x3, [fp, #-0x10]
    // 0xd778c8: r2 = Null
    //     0xd778c8: mov             x2, NULL
    // 0xd778cc: r1 = Null
    //     0xd778cc: mov             x1, NULL
    // 0xd778d0: r4 = LoadClassIdInstr(r0)
    //     0xd778d0: ldur            x4, [x0, #-1]
    //     0xd778d4: ubfx            x4, x4, #0xc, #0x14
    // 0xd778d8: r17 = -4710
    //     0xd778d8: mov             x17, #-0x1266
    // 0xd778dc: add             x4, x4, x17
    // 0xd778e0: cmp             x4, #0x109
    // 0xd778e4: b.ls            #0xd778f8
    // 0xd778e8: r8 = RenderBox?
    //     0xd778e8: ldr             x8, [PP, #0x47c8]  ; [pp+0x47c8] Type: RenderBox?
    // 0xd778ec: r3 = Null
    //     0xd778ec: add             x3, PP, #0xa2, lsl #12  ; [pp+0xa2a18] Null
    //     0xd778f0: ldr             x3, [x3, #0xa18]
    // 0xd778f4: r0 = RenderBox?()
    //     0xd778f4: bl              #0x870a94  ; IsType_RenderBox?_Stub
    // 0xd778f8: ldur            x0, [fp, #-0x10]
    // 0xd778fc: r1 = LoadClassIdInstr(r0)
    //     0xd778fc: ldur            x1, [x0, #-1]
    //     0xd77900: ubfx            x1, x1, #0xc, #0x14
    // 0xd77904: r17 = 4843
    //     0xd77904: mov             x17, #0x12eb
    // 0xd77908: cmp             x1, x17
    // 0xd7790c: b.ne            #0xd779b4
    // 0xd77910: LoadField: r1 = r0->field_63
    //     0xd77910: ldur            w1, [x0, #0x63]
    // 0xd77914: DecompressPointer r1
    //     0xd77914: add             x1, x1, HEAP, lsl #32
    // 0xd77918: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd7791c: cmp             w1, w16
    // 0xd77920: b.eq            #0xd779cc
    // 0xd77924: tbnz            w1, #4, #0xd779b4
    // 0xd77928: ldur            x2, [fp, #-8]
    // 0xd7792c: LoadField: r1 = r2->field_1b
    //     0xd7792c: ldur            w1, [x2, #0x1b]
    // 0xd77930: DecompressPointer r1
    //     0xd77930: add             x1, x1, HEAP, lsl #32
    // 0xd77934: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd77938: cmp             w1, w16
    // 0xd7793c: b.eq            #0xd779d8
    // 0xd77940: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd77940: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd77944: r0 = reverse()
    //     0xd77944: bl              #0x8c8688  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0xd77948: ldur            x0, [fp, #-8]
    // 0xd7794c: LoadField: r3 = r0->field_1b
    //     0xd7794c: ldur            w3, [x0, #0x1b]
    // 0xd77950: DecompressPointer r3
    //     0xd77950: add             x3, x3, HEAP, lsl #32
    // 0xd77954: mov             x2, x0
    // 0xd77958: stur            x3, [fp, #-0x10]
    // 0xd7795c: r1 = Function '_statusListener@298408280':.
    //     0xd7795c: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2a28] AnonymousClosure: (0xd779e4), in [package:flutter/src/cupertino/text_selection_toolbar.dart] _CupertinoTextSelectionToolbarContentState::_statusListener (0xd77a20)
    //     0xd77960: ldr             x1, [x1, #0xa28]
    // 0xd77964: r0 = AllocateClosure()
    //     0xd77964: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd77968: ldur            x1, [fp, #-0x10]
    // 0xd7796c: mov             x2, x0
    // 0xd77970: r0 = addStatusListener()
    //     0xd77970: bl              #0x1254cc0  ; [dart:mixin_deduplication] _MixinApplication456&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::addStatusListener
    // 0xd77974: ldur            x2, [fp, #-8]
    // 0xd77978: LoadField: r3 = r2->field_23
    //     0xd77978: ldur            x3, [x2, #0x23]
    // 0xd7797c: add             x4, x3, #1
    // 0xd77980: r0 = BoxInt64Instr(r4)
    //     0xd77980: sbfiz           x0, x4, #1, #0x1f
    //     0xd77984: cmp             x4, x0, asr #1
    //     0xd77988: b.eq            #0xd77994
    //     0xd7798c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xd77990: stur            x4, [x0, #7]
    // 0xd77994: StoreField: r2->field_1f = r0
    //     0xd77994: stur            w0, [x2, #0x1f]
    //     0xd77998: tbz             w0, #0, #0xd779b4
    //     0xd7799c: ldurb           w16, [x2, #-1]
    //     0xd779a0: ldurb           w17, [x0, #-1]
    //     0xd779a4: and             x16, x17, x16, lsr #2
    //     0xd779a8: tst             x16, HEAP, lsr #32
    //     0xd779ac: b.eq            #0xd779b4
    //     0xd779b0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd779b4: r0 = Null
    //     0xd779b4: mov             x0, NULL
    // 0xd779b8: LeaveFrame
    //     0xd779b8: mov             SP, fp
    //     0xd779bc: ldp             fp, lr, [SP], #0x10
    // 0xd779c0: ret
    //     0xd779c0: ret             
    // 0xd779c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd779c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd779c8: b               #0xd77898
    // 0xd779cc: r9 = hasNextPage
    //     0xd779cc: add             x9, PP, #0xa2, lsl #12  ; [pp+0xa2a30] Field <_RenderCupertinoTextSelectionToolbarItems@298408280.hasNextPage>: late (offset: 0x64)
    //     0xd779d0: ldr             x9, [x9, #0xa30]
    // 0xd779d4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd779d4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd779d8: r9 = _controller
    //     0xd779d8: add             x9, PP, #0xa2, lsl #12  ; [pp+0xa2a10] Field <_CupertinoTextSelectionToolbarContentState@298408280._controller@298408280>: late (offset: 0x1c)
    //     0xd779dc: ldr             x9, [x9, #0xa10]
    // 0xd779e0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd779e0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void _statusListener(dynamic, AnimationStatus) {
    // ** addr: 0xd779e4, size: 0x3c
    // 0xd779e4: EnterFrame
    //     0xd779e4: stp             fp, lr, [SP, #-0x10]!
    //     0xd779e8: mov             fp, SP
    // 0xd779ec: ldr             x0, [fp, #0x18]
    // 0xd779f0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd779f0: ldur            w1, [x0, #0x17]
    // 0xd779f4: DecompressPointer r1
    //     0xd779f4: add             x1, x1, HEAP, lsl #32
    // 0xd779f8: CheckStackOverflow
    //     0xd779f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd779fc: cmp             SP, x16
    //     0xd77a00: b.ls            #0xd77a18
    // 0xd77a04: ldr             x2, [fp, #0x10]
    // 0xd77a08: r0 = _statusListener()
    //     0xd77a08: bl              #0xd77a20  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _CupertinoTextSelectionToolbarContentState::_statusListener
    // 0xd77a0c: LeaveFrame
    //     0xd77a0c: mov             SP, fp
    //     0xd77a10: ldp             fp, lr, [SP], #0x10
    // 0xd77a14: ret
    //     0xd77a14: ret             
    // 0xd77a18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd77a18: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd77a1c: b               #0xd77a04
  }
  _ _statusListener(/* No info */) {
    // ** addr: 0xd77a20, size: 0xdc
    // 0xd77a20: EnterFrame
    //     0xd77a20: stp             fp, lr, [SP, #-0x10]!
    //     0xd77a24: mov             fp, SP
    // 0xd77a28: AllocStack(0x10)
    //     0xd77a28: sub             SP, SP, #0x10
    // 0xd77a2c: SetupParameters(_CupertinoTextSelectionToolbarContentState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xd77a2c: stur            x1, [fp, #-8]
    //     0xd77a30: stur            x2, [fp, #-0x10]
    // 0xd77a34: CheckStackOverflow
    //     0xd77a34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd77a38: cmp             SP, x16
    //     0xd77a3c: b.ls            #0xd77ae8
    // 0xd77a40: r1 = 1
    //     0xd77a40: mov             x1, #1
    // 0xd77a44: r0 = AllocateContext()
    //     0xd77a44: bl              #0x13de838  ; AllocateContextStub
    // 0xd77a48: mov             x1, x0
    // 0xd77a4c: ldur            x0, [fp, #-8]
    // 0xd77a50: StoreField: r1->field_f = r0
    //     0xd77a50: stur            w0, [x1, #0xf]
    // 0xd77a54: ldur            x2, [fp, #-0x10]
    // 0xd77a58: r16 = Instance_AnimationStatus
    //     0xd77a58: ldr             x16, [PP, #0x51a8]  ; [pp+0x51a8] Obj!AnimationStatus@12c61c1
    // 0xd77a5c: cmp             w2, w16
    // 0xd77a60: b.eq            #0xd77a74
    // 0xd77a64: r0 = Null
    //     0xd77a64: mov             x0, NULL
    // 0xd77a68: LeaveFrame
    //     0xd77a68: mov             SP, fp
    //     0xd77a6c: ldp             fp, lr, [SP], #0x10
    // 0xd77a70: ret
    //     0xd77a70: ret             
    // 0xd77a74: mov             x2, x1
    // 0xd77a78: r1 = Function '<anonymous closure>':.
    //     0xd77a78: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2a38] AnonymousClosure: (0xd77afc), in [package:flutter/src/cupertino/text_selection_toolbar.dart] _CupertinoTextSelectionToolbarContentState::_statusListener (0xd77a20)
    //     0xd77a7c: ldr             x1, [x1, #0xa38]
    // 0xd77a80: r0 = AllocateClosure()
    //     0xd77a80: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd77a84: ldur            x1, [fp, #-8]
    // 0xd77a88: mov             x2, x0
    // 0xd77a8c: r0 = setState()
    //     0xd77a8c: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xd77a90: ldur            x2, [fp, #-8]
    // 0xd77a94: LoadField: r1 = r2->field_1b
    //     0xd77a94: ldur            w1, [x2, #0x1b]
    // 0xd77a98: DecompressPointer r1
    //     0xd77a98: add             x1, x1, HEAP, lsl #32
    // 0xd77a9c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd77aa0: cmp             w1, w16
    // 0xd77aa4: b.eq            #0xd77af0
    // 0xd77aa8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd77aa8: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd77aac: r0 = forward()
    //     0xd77aac: bl              #0x8cd83c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0xd77ab0: ldur            x2, [fp, #-8]
    // 0xd77ab4: LoadField: r0 = r2->field_1b
    //     0xd77ab4: ldur            w0, [x2, #0x1b]
    // 0xd77ab8: DecompressPointer r0
    //     0xd77ab8: add             x0, x0, HEAP, lsl #32
    // 0xd77abc: stur            x0, [fp, #-0x10]
    // 0xd77ac0: r1 = Function '_statusListener@298408280':.
    //     0xd77ac0: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2a28] AnonymousClosure: (0xd779e4), in [package:flutter/src/cupertino/text_selection_toolbar.dart] _CupertinoTextSelectionToolbarContentState::_statusListener (0xd77a20)
    //     0xd77ac4: ldr             x1, [x1, #0xa28]
    // 0xd77ac8: r0 = AllocateClosure()
    //     0xd77ac8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd77acc: ldur            x1, [fp, #-0x10]
    // 0xd77ad0: mov             x2, x0
    // 0xd77ad4: r0 = removeStatusListener()
    //     0xd77ad4: bl              #0x12599f4  ; [dart:mixin_deduplication] _MixinApplication456&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::removeStatusListener
    // 0xd77ad8: r0 = Null
    //     0xd77ad8: mov             x0, NULL
    // 0xd77adc: LeaveFrame
    //     0xd77adc: mov             SP, fp
    //     0xd77ae0: ldp             fp, lr, [SP], #0x10
    // 0xd77ae4: ret
    //     0xd77ae4: ret             
    // 0xd77ae8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd77ae8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd77aec: b               #0xd77a40
    // 0xd77af0: r9 = _controller
    //     0xd77af0: add             x9, PP, #0xa2, lsl #12  ; [pp+0xa2a10] Field <_CupertinoTextSelectionToolbarContentState@298408280._controller@298408280>: late (offset: 0x1c)
    //     0xd77af4: ldr             x9, [x9, #0xa10]
    // 0xd77af8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd77af8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xd77afc, size: 0x4c
    // 0xd77afc: ldr             x1, [SP]
    // 0xd77b00: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xd77b00: ldur            w2, [x1, #0x17]
    // 0xd77b04: DecompressPointer r2
    //     0xd77b04: add             x2, x2, HEAP, lsl #32
    // 0xd77b08: LoadField: r1 = r2->field_f
    //     0xd77b08: ldur            w1, [x2, #0xf]
    // 0xd77b0c: DecompressPointer r1
    //     0xd77b0c: add             x1, x1, HEAP, lsl #32
    // 0xd77b10: LoadField: r2 = r1->field_1f
    //     0xd77b10: ldur            w2, [x1, #0x1f]
    // 0xd77b14: DecompressPointer r2
    //     0xd77b14: add             x2, x2, HEAP, lsl #32
    // 0xd77b18: cmp             w2, NULL
    // 0xd77b1c: b.eq            #0xd77b3c
    // 0xd77b20: r3 = LoadInt32Instr(r2)
    //     0xd77b20: sbfx            x3, x2, #1, #0x1f
    //     0xd77b24: tbz             w2, #0, #0xd77b2c
    //     0xd77b28: ldur            x3, [x2, #7]
    // 0xd77b2c: StoreField: r1->field_23 = r3
    //     0xd77b2c: stur            x3, [x1, #0x23]
    // 0xd77b30: StoreField: r1->field_1f = rNULL
    //     0xd77b30: stur            NULL, [x1, #0x1f]
    // 0xd77b34: r0 = Null
    //     0xd77b34: mov             x0, NULL
    // 0xd77b38: ret
    //     0xd77b38: ret             
    // 0xd77b3c: EnterFrame
    //     0xd77b3c: stp             fp, lr, [SP, #-0x10]!
    //     0xd77b40: mov             fp, SP
    // 0xd77b44: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd77b44: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _handlePreviousPage(/* No info */) {
    // ** addr: 0xd77b48, size: 0x16c
    // 0xd77b48: EnterFrame
    //     0xd77b48: stp             fp, lr, [SP, #-0x10]!
    //     0xd77b4c: mov             fp, SP
    // 0xd77b50: AllocStack(0x10)
    //     0xd77b50: sub             SP, SP, #0x10
    // 0xd77b54: SetupParameters(_CupertinoTextSelectionToolbarContentState this /* r1 => r2, fp-0x8 */)
    //     0xd77b54: mov             x2, x1
    //     0xd77b58: stur            x1, [fp, #-8]
    // 0xd77b5c: CheckStackOverflow
    //     0xd77b5c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd77b60: cmp             SP, x16
    //     0xd77b64: b.ls            #0xd77c94
    // 0xd77b68: LoadField: r1 = r2->field_2b
    //     0xd77b68: ldur            w1, [x2, #0x2b]
    // 0xd77b6c: DecompressPointer r1
    //     0xd77b6c: add             x1, x1, HEAP, lsl #32
    // 0xd77b70: r0 = _currentElement()
    //     0xd77b70: bl              #0x859318  ; [package:flutter/src/widgets/framework.dart] GlobalKey::_currentElement
    // 0xd77b74: cmp             w0, NULL
    // 0xd77b78: b.ne            #0xd77b84
    // 0xd77b7c: r3 = Null
    //     0xd77b7c: mov             x3, NULL
    // 0xd77b80: b               #0xd77b90
    // 0xd77b84: mov             x1, x0
    // 0xd77b88: r0 = findRenderObject()
    //     0xd77b88: bl              #0x8418fc  ; [package:flutter/src/widgets/framework.dart] Element::findRenderObject
    // 0xd77b8c: mov             x3, x0
    // 0xd77b90: mov             x0, x3
    // 0xd77b94: stur            x3, [fp, #-0x10]
    // 0xd77b98: r2 = Null
    //     0xd77b98: mov             x2, NULL
    // 0xd77b9c: r1 = Null
    //     0xd77b9c: mov             x1, NULL
    // 0xd77ba0: r4 = LoadClassIdInstr(r0)
    //     0xd77ba0: ldur            x4, [x0, #-1]
    //     0xd77ba4: ubfx            x4, x4, #0xc, #0x14
    // 0xd77ba8: r17 = -4710
    //     0xd77ba8: mov             x17, #-0x1266
    // 0xd77bac: add             x4, x4, x17
    // 0xd77bb0: cmp             x4, #0x109
    // 0xd77bb4: b.ls            #0xd77bc8
    // 0xd77bb8: r8 = RenderBox?
    //     0xd77bb8: ldr             x8, [PP, #0x47c8]  ; [pp+0x47c8] Type: RenderBox?
    // 0xd77bbc: r3 = Null
    //     0xd77bbc: add             x3, PP, #0xa2, lsl #12  ; [pp+0xa2a40] Null
    //     0xd77bc0: ldr             x3, [x3, #0xa40]
    // 0xd77bc4: r0 = RenderBox?()
    //     0xd77bc4: bl              #0x870a94  ; IsType_RenderBox?_Stub
    // 0xd77bc8: ldur            x0, [fp, #-0x10]
    // 0xd77bcc: r1 = LoadClassIdInstr(r0)
    //     0xd77bcc: ldur            x1, [x0, #-1]
    //     0xd77bd0: ubfx            x1, x1, #0xc, #0x14
    // 0xd77bd4: r17 = 4843
    //     0xd77bd4: mov             x17, #0x12eb
    // 0xd77bd8: cmp             x1, x17
    // 0xd77bdc: b.ne            #0xd77c84
    // 0xd77be0: LoadField: r1 = r0->field_67
    //     0xd77be0: ldur            w1, [x0, #0x67]
    // 0xd77be4: DecompressPointer r1
    //     0xd77be4: add             x1, x1, HEAP, lsl #32
    // 0xd77be8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd77bec: cmp             w1, w16
    // 0xd77bf0: b.eq            #0xd77c9c
    // 0xd77bf4: tbnz            w1, #4, #0xd77c84
    // 0xd77bf8: ldur            x2, [fp, #-8]
    // 0xd77bfc: LoadField: r1 = r2->field_1b
    //     0xd77bfc: ldur            w1, [x2, #0x1b]
    // 0xd77c00: DecompressPointer r1
    //     0xd77c00: add             x1, x1, HEAP, lsl #32
    // 0xd77c04: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd77c08: cmp             w1, w16
    // 0xd77c0c: b.eq            #0xd77ca8
    // 0xd77c10: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd77c10: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd77c14: r0 = reverse()
    //     0xd77c14: bl              #0x8c8688  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0xd77c18: ldur            x0, [fp, #-8]
    // 0xd77c1c: LoadField: r3 = r0->field_1b
    //     0xd77c1c: ldur            w3, [x0, #0x1b]
    // 0xd77c20: DecompressPointer r3
    //     0xd77c20: add             x3, x3, HEAP, lsl #32
    // 0xd77c24: mov             x2, x0
    // 0xd77c28: stur            x3, [fp, #-0x10]
    // 0xd77c2c: r1 = Function '_statusListener@298408280':.
    //     0xd77c2c: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2a28] AnonymousClosure: (0xd779e4), in [package:flutter/src/cupertino/text_selection_toolbar.dart] _CupertinoTextSelectionToolbarContentState::_statusListener (0xd77a20)
    //     0xd77c30: ldr             x1, [x1, #0xa28]
    // 0xd77c34: r0 = AllocateClosure()
    //     0xd77c34: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd77c38: ldur            x1, [fp, #-0x10]
    // 0xd77c3c: mov             x2, x0
    // 0xd77c40: r0 = addStatusListener()
    //     0xd77c40: bl              #0x1254cc0  ; [dart:mixin_deduplication] _MixinApplication456&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::addStatusListener
    // 0xd77c44: ldur            x2, [fp, #-8]
    // 0xd77c48: LoadField: r3 = r2->field_23
    //     0xd77c48: ldur            x3, [x2, #0x23]
    // 0xd77c4c: sub             x4, x3, #1
    // 0xd77c50: r0 = BoxInt64Instr(r4)
    //     0xd77c50: sbfiz           x0, x4, #1, #0x1f
    //     0xd77c54: cmp             x4, x0, asr #1
    //     0xd77c58: b.eq            #0xd77c64
    //     0xd77c5c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xd77c60: stur            x4, [x0, #7]
    // 0xd77c64: StoreField: r2->field_1f = r0
    //     0xd77c64: stur            w0, [x2, #0x1f]
    //     0xd77c68: tbz             w0, #0, #0xd77c84
    //     0xd77c6c: ldurb           w16, [x2, #-1]
    //     0xd77c70: ldurb           w17, [x0, #-1]
    //     0xd77c74: and             x16, x17, x16, lsr #2
    //     0xd77c78: tst             x16, HEAP, lsr #32
    //     0xd77c7c: b.eq            #0xd77c84
    //     0xd77c80: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd77c84: r0 = Null
    //     0xd77c84: mov             x0, NULL
    // 0xd77c88: LeaveFrame
    //     0xd77c88: mov             SP, fp
    //     0xd77c8c: ldp             fp, lr, [SP], #0x10
    // 0xd77c90: ret
    //     0xd77c90: ret             
    // 0xd77c94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd77c94: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd77c98: b               #0xd77b68
    // 0xd77c9c: r9 = hasPreviousPage
    //     0xd77c9c: add             x9, PP, #0xa2, lsl #12  ; [pp+0xa2a50] Field <_RenderCupertinoTextSelectionToolbarItems@298408280.hasPreviousPage>: late (offset: 0x68)
    //     0xd77ca0: ldr             x9, [x9, #0xa50]
    // 0xd77ca4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd77ca4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd77ca8: r9 = _controller
    //     0xd77ca8: add             x9, PP, #0xa2, lsl #12  ; [pp+0xa2a10] Field <_CupertinoTextSelectionToolbarContentState@298408280._controller@298408280>: late (offset: 0x1c)
    //     0xd77cac: ldr             x9, [x9, #0xa10]
    // 0xd77cb0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd77cb0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Center <anonymous closure>(dynamic, Widget) {
    // ** addr: 0xd77cb4, size: 0x38
    // 0xd77cb4: EnterFrame
    //     0xd77cb4: stp             fp, lr, [SP, #-0x10]!
    //     0xd77cb8: mov             fp, SP
    // 0xd77cbc: r0 = Center()
    //     0xd77cbc: bl              #0xd0c898  ; AllocateCenterStub -> Center (size=0x1c)
    // 0xd77cc0: r1 = Instance_Alignment
    //     0xd77cc0: add             x1, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xd77cc4: ldr             x1, [x1, #0xb80]
    // 0xd77cc8: StoreField: r0->field_f = r1
    //     0xd77cc8: stur            w1, [x0, #0xf]
    // 0xd77ccc: r1 = 1.000000
    //     0xd77ccc: ldr             x1, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xd77cd0: StoreField: r0->field_13 = r1
    //     0xd77cd0: stur            w1, [x0, #0x13]
    // 0xd77cd4: ArrayStore: r0[0] = r1  ; List_4
    //     0xd77cd4: stur            w1, [x0, #0x17]
    // 0xd77cd8: ldr             x1, [fp, #0x10]
    // 0xd77cdc: StoreField: r0->field_b = r1
    //     0xd77cdc: stur            w1, [x0, #0xb]
    // 0xd77ce0: LeaveFrame
    //     0xd77ce0: mov             SP, fp
    //     0xd77ce4: ldp             fp, lr, [SP], #0x10
    // 0xd77ce8: ret
    //     0xd77ce8: ret             
  }
  [closure] void _handleNextPage(dynamic) {
    // ** addr: 0xd77cec, size: 0x38
    // 0xd77cec: EnterFrame
    //     0xd77cec: stp             fp, lr, [SP, #-0x10]!
    //     0xd77cf0: mov             fp, SP
    // 0xd77cf4: ldr             x0, [fp, #0x10]
    // 0xd77cf8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd77cf8: ldur            w1, [x0, #0x17]
    // 0xd77cfc: DecompressPointer r1
    //     0xd77cfc: add             x1, x1, HEAP, lsl #32
    // 0xd77d00: CheckStackOverflow
    //     0xd77d00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd77d04: cmp             SP, x16
    //     0xd77d08: b.ls            #0xd77d1c
    // 0xd77d0c: r0 = _handleNextPage()
    //     0xd77d0c: bl              #0xd77878  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _CupertinoTextSelectionToolbarContentState::_handleNextPage
    // 0xd77d10: LeaveFrame
    //     0xd77d10: mov             SP, fp
    //     0xd77d14: ldp             fp, lr, [SP], #0x10
    // 0xd77d18: ret
    //     0xd77d18: ret             
    // 0xd77d1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd77d1c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd77d20: b               #0xd77d0c
  }
  [closure] void _handlePreviousPage(dynamic) {
    // ** addr: 0xd77d24, size: 0x38
    // 0xd77d24: EnterFrame
    //     0xd77d24: stp             fp, lr, [SP, #-0x10]!
    //     0xd77d28: mov             fp, SP
    // 0xd77d2c: ldr             x0, [fp, #0x10]
    // 0xd77d30: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd77d30: ldur            w1, [x0, #0x17]
    // 0xd77d34: DecompressPointer r1
    //     0xd77d34: add             x1, x1, HEAP, lsl #32
    // 0xd77d38: CheckStackOverflow
    //     0xd77d38: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd77d3c: cmp             SP, x16
    //     0xd77d40: b.ls            #0xd77d54
    // 0xd77d44: r0 = _handlePreviousPage()
    //     0xd77d44: bl              #0xd77b48  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _CupertinoTextSelectionToolbarContentState::_handlePreviousPage
    // 0xd77d48: LeaveFrame
    //     0xd77d48: mov             SP, fp
    //     0xd77d4c: ldp             fp, lr, [SP], #0x10
    // 0xd77d50: ret
    //     0xd77d50: ret             
    // 0xd77d54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd77d54: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd77d58: b               #0xd77d44
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf450f4, size: 0x144
    // 0xf450f4: EnterFrame
    //     0xf450f4: stp             fp, lr, [SP, #-0x10]!
    //     0xf450f8: mov             fp, SP
    // 0xf450fc: AllocStack(0x10)
    //     0xf450fc: sub             SP, SP, #0x10
    // 0xf45100: SetupParameters(_CupertinoTextSelectionToolbarContentState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xf45100: mov             x4, x1
    //     0xf45104: mov             x3, x2
    //     0xf45108: stur            x1, [fp, #-8]
    //     0xf4510c: stur            x2, [fp, #-0x10]
    // 0xf45110: CheckStackOverflow
    //     0xf45110: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf45114: cmp             SP, x16
    //     0xf45118: b.ls            #0xf45220
    // 0xf4511c: mov             x0, x3
    // 0xf45120: r2 = Null
    //     0xf45120: mov             x2, NULL
    // 0xf45124: r1 = Null
    //     0xf45124: mov             x1, NULL
    // 0xf45128: r4 = 60
    //     0xf45128: mov             x4, #0x3c
    // 0xf4512c: branchIfSmi(r0, 0xf45138)
    //     0xf4512c: tbz             w0, #0, #0xf45138
    // 0xf45130: r4 = LoadClassIdInstr(r0)
    //     0xf45130: ldur            x4, [x0, #-1]
    //     0xf45134: ubfx            x4, x4, #0xc, #0x14
    // 0xf45138: r17 = 6508
    //     0xf45138: mov             x17, #0x196c
    // 0xf4513c: cmp             x4, x17
    // 0xf45140: b.eq            #0xf45158
    // 0xf45144: r8 = _CupertinoTextSelectionToolbarContent
    //     0xf45144: add             x8, PP, #0xa2, lsl #12  ; [pp+0xa2a58] Type: _CupertinoTextSelectionToolbarContent
    //     0xf45148: ldr             x8, [x8, #0xa58]
    // 0xf4514c: r3 = Null
    //     0xf4514c: add             x3, PP, #0xa2, lsl #12  ; [pp+0xa2a60] Null
    //     0xf45150: ldr             x3, [x3, #0xa60]
    // 0xf45154: r0 = _CupertinoTextSelectionToolbarContent()
    //     0xf45154: bl              #0xad76a4  ; IsType__CupertinoTextSelectionToolbarContent_Stub
    // 0xf45158: ldur            x3, [fp, #-8]
    // 0xf4515c: LoadField: r2 = r3->field_7
    //     0xf4515c: ldur            w2, [x3, #7]
    // 0xf45160: DecompressPointer r2
    //     0xf45160: add             x2, x2, HEAP, lsl #32
    // 0xf45164: ldur            x0, [fp, #-0x10]
    // 0xf45168: r1 = Null
    //     0xf45168: mov             x1, NULL
    // 0xf4516c: cmp             w2, NULL
    // 0xf45170: b.eq            #0xf45194
    // 0xf45174: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf45174: ldur            w4, [x2, #0x17]
    // 0xf45178: DecompressPointer r4
    //     0xf45178: add             x4, x4, HEAP, lsl #32
    // 0xf4517c: r8 = X0 bound StatefulWidget
    //     0xf4517c: add             x8, PP, #0x12, lsl #12  ; [pp+0x12498] TypeParameter: X0 bound StatefulWidget
    //     0xf45180: ldr             x8, [x8, #0x498]
    // 0xf45184: LoadField: r9 = r4->field_7
    //     0xf45184: ldur            x9, [x4, #7]
    // 0xf45188: r3 = Null
    //     0xf45188: add             x3, PP, #0xa2, lsl #12  ; [pp+0xa2a70] Null
    //     0xf4518c: ldr             x3, [x3, #0xa70]
    // 0xf45190: blr             x9
    // 0xf45194: ldur            x2, [fp, #-8]
    // 0xf45198: LoadField: r0 = r2->field_b
    //     0xf45198: ldur            w0, [x2, #0xb]
    // 0xf4519c: DecompressPointer r0
    //     0xf4519c: add             x0, x0, HEAP, lsl #32
    // 0xf451a0: cmp             w0, NULL
    // 0xf451a4: b.eq            #0xf45228
    // 0xf451a8: LoadField: r1 = r0->field_13
    //     0xf451a8: ldur            w1, [x0, #0x13]
    // 0xf451ac: DecompressPointer r1
    //     0xf451ac: add             x1, x1, HEAP, lsl #32
    // 0xf451b0: ldur            x0, [fp, #-0x10]
    // 0xf451b4: LoadField: r3 = r0->field_13
    //     0xf451b4: ldur            w3, [x0, #0x13]
    // 0xf451b8: DecompressPointer r3
    //     0xf451b8: add             x3, x3, HEAP, lsl #32
    // 0xf451bc: cmp             w1, w3
    // 0xf451c0: b.eq            #0xf45210
    // 0xf451c4: StoreField: r2->field_23 = rZR
    //     0xf451c4: stur            xzr, [x2, #0x23]
    // 0xf451c8: StoreField: r2->field_1f = rNULL
    //     0xf451c8: stur            NULL, [x2, #0x1f]
    // 0xf451cc: LoadField: r1 = r2->field_1b
    //     0xf451cc: ldur            w1, [x2, #0x1b]
    // 0xf451d0: DecompressPointer r1
    //     0xf451d0: add             x1, x1, HEAP, lsl #32
    // 0xf451d4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf451d8: cmp             w1, w16
    // 0xf451dc: b.eq            #0xf4522c
    // 0xf451e0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xf451e0: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xf451e4: r0 = forward()
    //     0xf451e4: bl              #0x8cd83c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0xf451e8: ldur            x2, [fp, #-8]
    // 0xf451ec: LoadField: r0 = r2->field_1b
    //     0xf451ec: ldur            w0, [x2, #0x1b]
    // 0xf451f0: DecompressPointer r0
    //     0xf451f0: add             x0, x0, HEAP, lsl #32
    // 0xf451f4: stur            x0, [fp, #-0x10]
    // 0xf451f8: r1 = Function '_statusListener@298408280':.
    //     0xf451f8: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2a28] AnonymousClosure: (0xd779e4), in [package:flutter/src/cupertino/text_selection_toolbar.dart] _CupertinoTextSelectionToolbarContentState::_statusListener (0xd77a20)
    //     0xf451fc: ldr             x1, [x1, #0xa28]
    // 0xf45200: r0 = AllocateClosure()
    //     0xf45200: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf45204: ldur            x1, [fp, #-0x10]
    // 0xf45208: mov             x2, x0
    // 0xf4520c: r0 = removeStatusListener()
    //     0xf4520c: bl              #0x12599f4  ; [dart:mixin_deduplication] _MixinApplication456&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::removeStatusListener
    // 0xf45210: r0 = Null
    //     0xf45210: mov             x0, NULL
    // 0xf45214: LeaveFrame
    //     0xf45214: mov             SP, fp
    //     0xf45218: ldp             fp, lr, [SP], #0x10
    // 0xf4521c: ret
    //     0xf4521c: ret             
    // 0xf45220: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf45220: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf45224: b               #0xf4511c
    // 0xf45228: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf45228: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf4522c: r9 = _controller
    //     0xf4522c: add             x9, PP, #0xa2, lsl #12  ; [pp+0xa2a10] Field <_CupertinoTextSelectionToolbarContentState@298408280._controller@298408280>: late (offset: 0x1c)
    //     0xf45230: ldr             x9, [x9, #0xa10]
    // 0xf45234: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf45234: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0xf86e2c, size: 0x88
    // 0xf86e2c: EnterFrame
    //     0xf86e2c: stp             fp, lr, [SP, #-0x10]!
    //     0xf86e30: mov             fp, SP
    // 0xf86e34: AllocStack(0x20)
    //     0xf86e34: sub             SP, SP, #0x20
    // 0xf86e38: SetupParameters(_CupertinoTextSelectionToolbarContentState this /* r1 => r2, fp-0x8 */)
    //     0xf86e38: mov             x2, x1
    //     0xf86e3c: stur            x1, [fp, #-8]
    // 0xf86e40: CheckStackOverflow
    //     0xf86e40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf86e44: cmp             SP, x16
    //     0xf86e48: b.ls            #0xf86eac
    // 0xf86e4c: r1 = <double>
    //     0xf86e4c: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf86e50: r0 = AnimationController()
    //     0xf86e50: bl              #0x87522c  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0xf86e54: stur            x0, [fp, #-0x10]
    // 0xf86e58: r16 = 1.000000
    //     0xf86e58: ldr             x16, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xf86e5c: r30 = Instance_Duration
    //     0xf86e5c: ldr             lr, [PP, #0x5148]  ; [pp+0x5148] Obj!Duration@12c8951
    // 0xf86e60: stp             lr, x16, [SP]
    // 0xf86e64: mov             x1, x0
    // 0xf86e68: ldur            x2, [fp, #-8]
    // 0xf86e6c: r4 = const [0, 0x4, 0x2, 0x2, duration, 0x3, value, 0x2, null]
    //     0xf86e6c: add             x4, PP, #0x84, lsl #12  ; [pp+0x84ce0] List(9) [0, 0x4, 0x2, 0x2, "duration", 0x3, "value", 0x2, Null]
    //     0xf86e70: ldr             x4, [x4, #0xce0]
    // 0xf86e74: r0 = AnimationController()
    //     0xf86e74: bl              #0x874ea4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0xf86e78: ldur            x0, [fp, #-0x10]
    // 0xf86e7c: ldur            x1, [fp, #-8]
    // 0xf86e80: StoreField: r1->field_1b = r0
    //     0xf86e80: stur            w0, [x1, #0x1b]
    //     0xf86e84: ldurb           w16, [x1, #-1]
    //     0xf86e88: ldurb           w17, [x0, #-1]
    //     0xf86e8c: and             x16, x17, x16, lsr #2
    //     0xf86e90: tst             x16, HEAP, lsr #32
    //     0xf86e94: b.eq            #0xf86e9c
    //     0xf86e98: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf86e9c: r0 = Null
    //     0xf86e9c: mov             x0, NULL
    // 0xf86ea0: LeaveFrame
    //     0xf86ea0: mov             SP, fp
    //     0xf86ea4: ldp             fp, lr, [SP], #0x10
    // 0xf86ea8: ret
    //     0xf86ea8: ret             
    // 0xf86eac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf86eac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf86eb0: b               #0xf86e4c
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10e159c, size: 0x64
    // 0x10e159c: EnterFrame
    //     0x10e159c: stp             fp, lr, [SP, #-0x10]!
    //     0x10e15a0: mov             fp, SP
    // 0x10e15a4: AllocStack(0x8)
    //     0x10e15a4: sub             SP, SP, #8
    // 0x10e15a8: SetupParameters(_CupertinoTextSelectionToolbarContentState this /* r1 => r0, fp-0x8 */)
    //     0x10e15a8: mov             x0, x1
    //     0x10e15ac: stur            x1, [fp, #-8]
    // 0x10e15b0: CheckStackOverflow
    //     0x10e15b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e15b4: cmp             SP, x16
    //     0x10e15b8: b.ls            #0x10e15ec
    // 0x10e15bc: LoadField: r1 = r0->field_1b
    //     0x10e15bc: ldur            w1, [x0, #0x1b]
    // 0x10e15c0: DecompressPointer r1
    //     0x10e15c0: add             x1, x1, HEAP, lsl #32
    // 0x10e15c4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10e15c8: cmp             w1, w16
    // 0x10e15cc: b.eq            #0x10e15f4
    // 0x10e15d0: r0 = dispose()
    //     0x10e15d0: bl              #0x9164f4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x10e15d4: ldur            x1, [fp, #-8]
    // 0x10e15d8: r0 = dispose()
    //     0x10e15d8: bl              #0x10e1600  ; [dart:mixin_deduplication] _MixinApplication418&State&TickerProviderStateMixin::dispose
    // 0x10e15dc: r0 = Null
    //     0x10e15dc: mov             x0, NULL
    // 0x10e15e0: LeaveFrame
    //     0x10e15e0: mov             SP, fp
    //     0x10e15e4: ldp             fp, lr, [SP], #0x10
    // 0x10e15e8: ret
    //     0x10e15e8: ret             
    // 0x10e15ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e15ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e15f0: b               #0x10e15bc
    // 0x10e15f4: r9 = _controller
    //     0x10e15f4: add             x9, PP, #0xa2, lsl #12  ; [pp+0xa2a10] Field <_CupertinoTextSelectionToolbarContentState@298408280._controller@298408280>: late (offset: 0x1c)
    //     0x10e15f8: ldr             x9, [x9, #0xa10]
    // 0x10e15fc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x10e15fc: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 5809, size: 0x50, field offset: 0x44
class _CupertinoTextSelectionToolbarItemsElement extends RenderObjectElement {

  late List<Element> _children; // offset: 0x44

  _ mount(/* No info */) {
    // ** addr: 0xb8e59c, size: 0x200
    // 0xb8e59c: EnterFrame
    //     0xb8e59c: stp             fp, lr, [SP, #-0x10]!
    //     0xb8e5a0: mov             fp, SP
    // 0xb8e5a4: AllocStack(0x38)
    //     0xb8e5a4: sub             SP, SP, #0x38
    // 0xb8e5a8: SetupParameters(_CupertinoTextSelectionToolbarItemsElement this /* r1 => r0, fp-0x8 */)
    //     0xb8e5a8: mov             x0, x1
    //     0xb8e5ac: stur            x1, [fp, #-8]
    // 0xb8e5b0: CheckStackOverflow
    //     0xb8e5b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb8e5b4: cmp             SP, x16
    //     0xb8e5b8: b.ls            #0xb8e784
    // 0xb8e5bc: mov             x1, x0
    // 0xb8e5c0: r0 = mount()
    //     0xb8e5c0: bl              #0xb90458  ; [package:flutter/src/widgets/framework.dart] RenderObjectElement::mount
    // 0xb8e5c4: ldur            x3, [fp, #-8]
    // 0xb8e5c8: ArrayLoad: r4 = r3[0]  ; List_4
    //     0xb8e5c8: ldur            w4, [x3, #0x17]
    // 0xb8e5cc: DecompressPointer r4
    //     0xb8e5cc: add             x4, x4, HEAP, lsl #32
    // 0xb8e5d0: stur            x4, [fp, #-0x10]
    // 0xb8e5d4: cmp             w4, NULL
    // 0xb8e5d8: b.eq            #0xb8e78c
    // 0xb8e5dc: mov             x0, x4
    // 0xb8e5e0: r2 = Null
    //     0xb8e5e0: mov             x2, NULL
    // 0xb8e5e4: r1 = Null
    //     0xb8e5e4: mov             x1, NULL
    // 0xb8e5e8: r4 = LoadClassIdInstr(r0)
    //     0xb8e5e8: ldur            x4, [x0, #-1]
    //     0xb8e5ec: ubfx            x4, x4, #0xc, #0x14
    // 0xb8e5f0: r17 = 6563
    //     0xb8e5f0: mov             x17, #0x19a3
    // 0xb8e5f4: cmp             x4, x17
    // 0xb8e5f8: b.eq            #0xb8e610
    // 0xb8e5fc: r8 = _CupertinoTextSelectionToolbarItems
    //     0xb8e5fc: add             x8, PP, #0xcc, lsl #12  ; [pp+0xcc560] Type: _CupertinoTextSelectionToolbarItems
    //     0xb8e600: ldr             x8, [x8, #0x560]
    // 0xb8e604: r3 = Null
    //     0xb8e604: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcc5a0] Null
    //     0xb8e608: ldr             x3, [x3, #0x5a0]
    // 0xb8e60c: r0 = DefaultTypeTest()
    //     0xb8e60c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb8e610: ldur            x0, [fp, #-0x10]
    // 0xb8e614: LoadField: r2 = r0->field_b
    //     0xb8e614: ldur            w2, [x0, #0xb]
    // 0xb8e618: DecompressPointer r2
    //     0xb8e618: add             x2, x2, HEAP, lsl #32
    // 0xb8e61c: ldur            x1, [fp, #-8]
    // 0xb8e620: r3 = Instance__CupertinoTextSelectionToolbarItemsSlot
    //     0xb8e620: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcc588] Obj!_CupertinoTextSelectionToolbarItemsSlot@12c5fc1
    //     0xb8e624: ldr             x3, [x3, #0x588]
    // 0xb8e628: r0 = _mountChild()
    //     0xb8e628: bl              #0xb8e79c  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _CupertinoTextSelectionToolbarItemsElement::_mountChild
    // 0xb8e62c: ldur            x0, [fp, #-0x10]
    // 0xb8e630: LoadField: r2 = r0->field_1f
    //     0xb8e630: ldur            w2, [x0, #0x1f]
    // 0xb8e634: DecompressPointer r2
    //     0xb8e634: add             x2, x2, HEAP, lsl #32
    // 0xb8e638: ldur            x1, [fp, #-8]
    // 0xb8e63c: r3 = Instance__CupertinoTextSelectionToolbarItemsSlot
    //     0xb8e63c: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcc590] Obj!_CupertinoTextSelectionToolbarItemsSlot@12c5fa1
    //     0xb8e640: ldr             x3, [x3, #0x590]
    // 0xb8e644: r0 = _mountChild()
    //     0xb8e644: bl              #0xb8e79c  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _CupertinoTextSelectionToolbarItemsElement::_mountChild
    // 0xb8e648: ldur            x0, [fp, #-0x10]
    // 0xb8e64c: LoadField: r3 = r0->field_f
    //     0xb8e64c: ldur            w3, [x0, #0xf]
    // 0xb8e650: DecompressPointer r3
    //     0xb8e650: add             x3, x3, HEAP, lsl #32
    // 0xb8e654: stur            x3, [fp, #-0x18]
    // 0xb8e658: LoadField: r0 = r3->field_b
    //     0xb8e658: ldur            w0, [x3, #0xb]
    // 0xb8e65c: mov             x2, x0
    // 0xb8e660: stur            x0, [fp, #-0x10]
    // 0xb8e664: r1 = <Element>
    //     0xb8e664: ldr             x1, [PP, #0x1c38]  ; [pp+0x1c38] TypeArguments: <Element>
    // 0xb8e668: r0 = AllocateArray()
    //     0xb8e668: bl              #0x13df928  ; AllocateArrayStub
    // 0xb8e66c: mov             x2, x0
    // 0xb8e670: ldur            x0, [fp, #-0x10]
    // 0xb8e674: stur            x2, [fp, #-0x38]
    // 0xb8e678: r3 = LoadInt32Instr(r0)
    //     0xb8e678: sbfx            x3, x0, #1, #0x1f
    // 0xb8e67c: stur            x3, [fp, #-0x30]
    // 0xb8e680: r6 = 0
    //     0xb8e680: mov             x6, #0
    // 0xb8e684: r5 = Null
    //     0xb8e684: mov             x5, NULL
    // 0xb8e688: ldur            x4, [fp, #-0x18]
    // 0xb8e68c: stur            x6, [fp, #-0x20]
    // 0xb8e690: stur            x5, [fp, #-0x28]
    // 0xb8e694: CheckStackOverflow
    //     0xb8e694: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb8e698: cmp             SP, x16
    //     0xb8e69c: b.ls            #0xb8e790
    // 0xb8e6a0: cmp             x6, x3
    // 0xb8e6a4: b.ge            #0xb8e750
    // 0xb8e6a8: LoadField: r0 = r4->field_b
    //     0xb8e6a8: ldur            w0, [x4, #0xb]
    // 0xb8e6ac: r1 = LoadInt32Instr(r0)
    //     0xb8e6ac: sbfx            x1, x0, #1, #0x1f
    // 0xb8e6b0: mov             x0, x1
    // 0xb8e6b4: mov             x1, x6
    // 0xb8e6b8: cmp             x1, x0
    // 0xb8e6bc: b.hs            #0xb8e798
    // 0xb8e6c0: LoadField: r0 = r4->field_f
    //     0xb8e6c0: ldur            w0, [x4, #0xf]
    // 0xb8e6c4: DecompressPointer r0
    //     0xb8e6c4: add             x0, x0, HEAP, lsl #32
    // 0xb8e6c8: ArrayLoad: r7 = r0[r6]  ; Unknown_4
    //     0xb8e6c8: add             x16, x0, x6, lsl #2
    //     0xb8e6cc: ldur            w7, [x16, #0xf]
    // 0xb8e6d0: DecompressPointer r7
    //     0xb8e6d0: add             x7, x7, HEAP, lsl #32
    // 0xb8e6d4: stur            x7, [fp, #-0x10]
    // 0xb8e6d8: r1 = <Element?>
    //     0xb8e6d8: add             x1, PP, #0x90, lsl #12  ; [pp+0x90e10] TypeArguments: <Element?>
    //     0xb8e6dc: ldr             x1, [x1, #0xe10]
    // 0xb8e6e0: r0 = IndexedSlot()
    //     0xb8e6e0: bl              #0xb8e53c  ; AllocateIndexedSlotStub -> IndexedSlot<X0 bound Element?> (size=0x18)
    // 0xb8e6e4: mov             x1, x0
    // 0xb8e6e8: ldur            x0, [fp, #-0x20]
    // 0xb8e6ec: StoreField: r1->field_f = r0
    //     0xb8e6ec: stur            x0, [x1, #0xf]
    // 0xb8e6f0: ldur            x2, [fp, #-0x28]
    // 0xb8e6f4: StoreField: r1->field_b = r2
    //     0xb8e6f4: stur            w2, [x1, #0xb]
    // 0xb8e6f8: mov             x3, x1
    // 0xb8e6fc: ldur            x1, [fp, #-8]
    // 0xb8e700: ldur            x2, [fp, #-0x10]
    // 0xb8e704: r0 = inflateWidget()
    //     0xb8e704: bl              #0x1104b9c  ; [package:flutter/src/widgets/framework.dart] Element::inflateWidget
    // 0xb8e708: ldur            x1, [fp, #-0x38]
    // 0xb8e70c: mov             x3, x0
    // 0xb8e710: ldur            x2, [fp, #-0x20]
    // 0xb8e714: ArrayStore: r1[r2] = r0  ; List_4
    //     0xb8e714: add             x25, x1, x2, lsl #2
    //     0xb8e718: add             x25, x25, #0xf
    //     0xb8e71c: str             w0, [x25]
    //     0xb8e720: tbz             w0, #0, #0xb8e73c
    //     0xb8e724: ldurb           w16, [x1, #-1]
    //     0xb8e728: ldurb           w17, [x0, #-1]
    //     0xb8e72c: and             x16, x17, x16, lsr #2
    //     0xb8e730: tst             x16, HEAP, lsr #32
    //     0xb8e734: b.eq            #0xb8e73c
    //     0xb8e738: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xb8e73c: add             x6, x2, #1
    // 0xb8e740: mov             x5, x3
    // 0xb8e744: ldur            x2, [fp, #-0x38]
    // 0xb8e748: ldur            x3, [fp, #-0x30]
    // 0xb8e74c: b               #0xb8e688
    // 0xb8e750: ldur            x1, [fp, #-8]
    // 0xb8e754: ldur            x0, [fp, #-0x38]
    // 0xb8e758: StoreField: r1->field_43 = r0
    //     0xb8e758: stur            w0, [x1, #0x43]
    //     0xb8e75c: ldurb           w16, [x1, #-1]
    //     0xb8e760: ldurb           w17, [x0, #-1]
    //     0xb8e764: and             x16, x17, x16, lsr #2
    //     0xb8e768: tst             x16, HEAP, lsr #32
    //     0xb8e76c: b.eq            #0xb8e774
    //     0xb8e770: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb8e774: r0 = Null
    //     0xb8e774: mov             x0, NULL
    // 0xb8e778: LeaveFrame
    //     0xb8e778: mov             SP, fp
    //     0xb8e77c: ldp             fp, lr, [SP], #0x10
    // 0xb8e780: ret
    //     0xb8e780: ret             
    // 0xb8e784: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb8e784: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb8e788: b               #0xb8e5bc
    // 0xb8e78c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb8e78c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb8e790: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb8e790: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb8e794: b               #0xb8e6a0
    // 0xb8e798: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb8e798: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _mountChild(/* No info */) {
    // ** addr: 0xb8e79c, size: 0x208
    // 0xb8e79c: EnterFrame
    //     0xb8e79c: stp             fp, lr, [SP, #-0x10]!
    //     0xb8e7a0: mov             fp, SP
    // 0xb8e7a4: AllocStack(0x38)
    //     0xb8e7a4: sub             SP, SP, #0x38
    // 0xb8e7a8: SetupParameters(_CupertinoTextSelectionToolbarItemsElement this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r3, fp-0x18 */, dynamic _ /* r3 => r0, fp-0x20 */)
    //     0xb8e7a8: mov             x4, x1
    //     0xb8e7ac: mov             x0, x3
    //     0xb8e7b0: stur            x3, [fp, #-0x20]
    //     0xb8e7b4: mov             x3, x2
    //     0xb8e7b8: stur            x1, [fp, #-0x10]
    //     0xb8e7bc: stur            x2, [fp, #-0x18]
    // 0xb8e7c0: CheckStackOverflow
    //     0xb8e7c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb8e7c4: cmp             SP, x16
    //     0xb8e7c8: b.ls            #0xb8e99c
    // 0xb8e7cc: LoadField: r5 = r4->field_47
    //     0xb8e7cc: ldur            w5, [x4, #0x47]
    // 0xb8e7d0: DecompressPointer r5
    //     0xb8e7d0: add             x5, x5, HEAP, lsl #32
    // 0xb8e7d4: mov             x1, x5
    // 0xb8e7d8: mov             x2, x0
    // 0xb8e7dc: stur            x5, [fp, #-8]
    // 0xb8e7e0: r0 = _getValueOrData()
    //     0xb8e7e0: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xb8e7e4: ldur            x2, [fp, #-8]
    // 0xb8e7e8: LoadField: r1 = r2->field_f
    //     0xb8e7e8: ldur            w1, [x2, #0xf]
    // 0xb8e7ec: DecompressPointer r1
    //     0xb8e7ec: add             x1, x1, HEAP, lsl #32
    // 0xb8e7f0: cmp             w1, w0
    // 0xb8e7f4: b.ne            #0xb8e800
    // 0xb8e7f8: r3 = Null
    //     0xb8e7f8: mov             x3, NULL
    // 0xb8e7fc: b               #0xb8e804
    // 0xb8e800: mov             x3, x0
    // 0xb8e804: stur            x3, [fp, #-0x28]
    // 0xb8e808: cmp             w3, NULL
    // 0xb8e80c: b.eq            #0xb8e94c
    // 0xb8e810: ldur            x4, [fp, #-0x18]
    // 0xb8e814: r0 = LoadClassIdInstr(r3)
    //     0xb8e814: ldur            x0, [x3, #-1]
    //     0xb8e818: ubfx            x0, x0, #0xc, #0x14
    // 0xb8e81c: mov             x1, x3
    // 0xb8e820: r0 = GDT[cid_x0 + 0xb17]()
    //     0xb8e820: add             lr, x0, #0xb17
    //     0xb8e824: ldr             lr, [x21, lr, lsl #3]
    //     0xb8e828: blr             lr
    // 0xb8e82c: ldur            x2, [fp, #-0x18]
    // 0xb8e830: cmp             w0, w2
    // 0xb8e834: b.ne            #0xb8e888
    // 0xb8e838: ldur            x2, [fp, #-0x28]
    // 0xb8e83c: LoadField: r0 = r2->field_f
    //     0xb8e83c: ldur            w0, [x2, #0xf]
    // 0xb8e840: DecompressPointer r0
    //     0xb8e840: add             x0, x0, HEAP, lsl #32
    // 0xb8e844: r1 = 60
    //     0xb8e844: mov             x1, #0x3c
    // 0xb8e848: branchIfSmi(r0, 0xb8e854)
    //     0xb8e848: tbz             w0, #0, #0xb8e854
    // 0xb8e84c: r1 = LoadClassIdInstr(r0)
    //     0xb8e84c: ldur            x1, [x0, #-1]
    //     0xb8e850: ubfx            x1, x1, #0xc, #0x14
    // 0xb8e854: ldur            x16, [fp, #-0x20]
    // 0xb8e858: stp             x16, x0, [SP]
    // 0xb8e85c: mov             x0, x1
    // 0xb8e860: mov             lr, x0
    // 0xb8e864: ldr             lr, [x21, lr, lsl #3]
    // 0xb8e868: blr             lr
    // 0xb8e86c: tbz             w0, #4, #0xb8e880
    // 0xb8e870: ldur            x1, [fp, #-0x10]
    // 0xb8e874: ldur            x2, [fp, #-0x28]
    // 0xb8e878: ldur            x3, [fp, #-0x20]
    // 0xb8e87c: r0 = updateSlotForChild()
    //     0xb8e87c: bl              #0xb49b58  ; [package:flutter/src/widgets/framework.dart] Element::updateSlotForChild
    // 0xb8e880: ldur            x0, [fp, #-0x28]
    // 0xb8e884: b               #0xb8e944
    // 0xb8e888: ldur            x3, [fp, #-0x28]
    // 0xb8e88c: r0 = LoadClassIdInstr(r3)
    //     0xb8e88c: ldur            x0, [x3, #-1]
    //     0xb8e890: ubfx            x0, x0, #0xc, #0x14
    // 0xb8e894: mov             x1, x3
    // 0xb8e898: r0 = GDT[cid_x0 + 0xb17]()
    //     0xb8e898: add             lr, x0, #0xb17
    //     0xb8e89c: ldr             lr, [x21, lr, lsl #3]
    //     0xb8e8a0: blr             lr
    // 0xb8e8a4: mov             x1, x0
    // 0xb8e8a8: ldur            x2, [fp, #-0x18]
    // 0xb8e8ac: r0 = canUpdate()
    //     0xb8e8ac: bl              #0xb49ae0  ; [package:flutter/src/widgets/framework.dart] Widget::canUpdate
    // 0xb8e8b0: tbnz            w0, #4, #0xb8e928
    // 0xb8e8b4: ldur            x2, [fp, #-0x28]
    // 0xb8e8b8: LoadField: r0 = r2->field_f
    //     0xb8e8b8: ldur            w0, [x2, #0xf]
    // 0xb8e8bc: DecompressPointer r0
    //     0xb8e8bc: add             x0, x0, HEAP, lsl #32
    // 0xb8e8c0: r1 = 60
    //     0xb8e8c0: mov             x1, #0x3c
    // 0xb8e8c4: branchIfSmi(r0, 0xb8e8d0)
    //     0xb8e8c4: tbz             w0, #0, #0xb8e8d0
    // 0xb8e8c8: r1 = LoadClassIdInstr(r0)
    //     0xb8e8c8: ldur            x1, [x0, #-1]
    //     0xb8e8cc: ubfx            x1, x1, #0xc, #0x14
    // 0xb8e8d0: ldur            x16, [fp, #-0x20]
    // 0xb8e8d4: stp             x16, x0, [SP]
    // 0xb8e8d8: mov             x0, x1
    // 0xb8e8dc: mov             lr, x0
    // 0xb8e8e0: ldr             lr, [x21, lr, lsl #3]
    // 0xb8e8e4: blr             lr
    // 0xb8e8e8: tbz             w0, #4, #0xb8e8fc
    // 0xb8e8ec: ldur            x1, [fp, #-0x10]
    // 0xb8e8f0: ldur            x2, [fp, #-0x28]
    // 0xb8e8f4: ldur            x3, [fp, #-0x20]
    // 0xb8e8f8: r0 = updateSlotForChild()
    //     0xb8e8f8: bl              #0xb49b58  ; [package:flutter/src/widgets/framework.dart] Element::updateSlotForChild
    // 0xb8e8fc: ldur            x3, [fp, #-0x28]
    // 0xb8e900: r0 = LoadClassIdInstr(r3)
    //     0xb8e900: ldur            x0, [x3, #-1]
    //     0xb8e904: ubfx            x0, x0, #0xc, #0x14
    // 0xb8e908: mov             x1, x3
    // 0xb8e90c: ldur            x2, [fp, #-0x18]
    // 0xb8e910: r0 = GDT[cid_x0 + 0xab8a]()
    //     0xb8e910: mov             x17, #0xab8a
    //     0xb8e914: add             lr, x0, x17
    //     0xb8e918: ldr             lr, [x21, lr, lsl #3]
    //     0xb8e91c: blr             lr
    // 0xb8e920: ldur            x0, [fp, #-0x28]
    // 0xb8e924: b               #0xb8e944
    // 0xb8e928: ldur            x1, [fp, #-0x10]
    // 0xb8e92c: ldur            x2, [fp, #-0x28]
    // 0xb8e930: r0 = deactivateChild()
    //     0xb8e930: bl              #0xb49db8  ; [package:flutter/src/widgets/framework.dart] Element::deactivateChild
    // 0xb8e934: ldur            x1, [fp, #-0x10]
    // 0xb8e938: ldur            x2, [fp, #-0x18]
    // 0xb8e93c: ldur            x3, [fp, #-0x20]
    // 0xb8e940: r0 = inflateWidget()
    //     0xb8e940: bl              #0x1104b9c  ; [package:flutter/src/widgets/framework.dart] Element::inflateWidget
    // 0xb8e944: mov             x3, x0
    // 0xb8e948: b               #0xb8e960
    // 0xb8e94c: ldur            x1, [fp, #-0x10]
    // 0xb8e950: ldur            x2, [fp, #-0x18]
    // 0xb8e954: ldur            x3, [fp, #-0x20]
    // 0xb8e958: r0 = inflateWidget()
    //     0xb8e958: bl              #0x1104b9c  ; [package:flutter/src/widgets/framework.dart] Element::inflateWidget
    // 0xb8e95c: mov             x3, x0
    // 0xb8e960: ldur            x0, [fp, #-0x28]
    // 0xb8e964: stur            x3, [fp, #-0x10]
    // 0xb8e968: cmp             w0, NULL
    // 0xb8e96c: b.eq            #0xb8e97c
    // 0xb8e970: ldur            x1, [fp, #-8]
    // 0xb8e974: ldur            x2, [fp, #-0x20]
    // 0xb8e978: r0 = remove()
    //     0xb8e978: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xb8e97c: ldur            x1, [fp, #-8]
    // 0xb8e980: ldur            x2, [fp, #-0x20]
    // 0xb8e984: ldur            x3, [fp, #-0x10]
    // 0xb8e988: r0 = []=()
    //     0xb8e988: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xb8e98c: r0 = Null
    //     0xb8e98c: mov             x0, NULL
    // 0xb8e990: LeaveFrame
    //     0xb8e990: mov             SP, fp
    //     0xb8e994: ldp             fp, lr, [SP], #0x10
    // 0xb8e998: ret
    //     0xb8e998: ret             
    // 0xb8e99c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb8e99c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb8e9a0: b               #0xb8e7cc
  }
  _ _CupertinoTextSelectionToolbarItemsElement(/* No info */) {
    // ** addr: 0x10f23ac, size: 0x114
    // 0x10f23ac: EnterFrame
    //     0x10f23ac: stp             fp, lr, [SP, #-0x10]!
    //     0x10f23b0: mov             fp, SP
    // 0x10f23b4: AllocStack(0x28)
    //     0x10f23b4: sub             SP, SP, #0x28
    // 0x10f23b8: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x10f23bc: stur            x1, [fp, #-8]
    // 0x10f23c0: mov             x16, x2
    // 0x10f23c4: mov             x2, x1
    // 0x10f23c8: mov             x1, x16
    // 0x10f23cc: stur            x1, [fp, #-0x10]
    // 0x10f23d0: CheckStackOverflow
    //     0x10f23d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f23d4: cmp             SP, x16
    //     0x10f23d8: b.ls            #0x10f24b8
    // 0x10f23dc: StoreField: r2->field_43 = r0
    //     0x10f23dc: stur            w0, [x2, #0x43]
    // 0x10f23e0: r16 = <_CupertinoTextSelectionToolbarItemsSlot, Element>
    //     0x10f23e0: add             x16, PP, #0xac, lsl #12  ; [pp+0xacc28] TypeArguments: <_CupertinoTextSelectionToolbarItemsSlot, Element>
    //     0x10f23e4: ldr             x16, [x16, #0xc28]
    // 0x10f23e8: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x10f23ec: stp             lr, x16, [SP]
    // 0x10f23f0: r0 = Map._fromLiteral()
    //     0x10f23f0: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x10f23f4: ldur            x2, [fp, #-8]
    // 0x10f23f8: StoreField: r2->field_47 = r0
    //     0x10f23f8: stur            w0, [x2, #0x47]
    //     0x10f23fc: ldurb           w16, [x2, #-1]
    //     0x10f2400: ldurb           w17, [x0, #-1]
    //     0x10f2404: and             x16, x17, x16, lsr #2
    //     0x10f2408: tst             x16, HEAP, lsr #32
    //     0x10f240c: b.eq            #0x10f2414
    //     0x10f2410: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x10f2414: r1 = <Element>
    //     0x10f2414: ldr             x1, [PP, #0x1c38]  ; [pp+0x1c38] TypeArguments: <Element>
    // 0x10f2418: r0 = _HashSet()
    //     0x10f2418: bl              #0x89f6f0  ; Allocate_HashSetStub -> _HashSet<X0> (size=0x20)
    // 0x10f241c: stur            x0, [fp, #-0x18]
    // 0x10f2420: StoreField: r0->field_f = rZR
    //     0x10f2420: stur            xzr, [x0, #0xf]
    // 0x10f2424: ArrayStore: r0[0] = rZR  ; List_8
    //     0x10f2424: stur            xzr, [x0, #0x17]
    // 0x10f2428: r1 = <_HashSetEntry<Element>?>
    //     0x10f2428: add             x1, PP, #0x85, lsl #12  ; [pp+0x85610] TypeArguments: <_HashSetEntry<Element>?>
    //     0x10f242c: ldr             x1, [x1, #0x610]
    // 0x10f2430: r2 = 16
    //     0x10f2430: mov             x2, #0x10
    // 0x10f2434: r0 = AllocateArray()
    //     0x10f2434: bl              #0x13df928  ; AllocateArrayStub
    // 0x10f2438: mov             x1, x0
    // 0x10f243c: ldur            x0, [fp, #-0x18]
    // 0x10f2440: StoreField: r0->field_b = r1
    //     0x10f2440: stur            w1, [x0, #0xb]
    // 0x10f2444: ldur            x1, [fp, #-8]
    // 0x10f2448: StoreField: r1->field_4b = r0
    //     0x10f2448: stur            w0, [x1, #0x4b]
    //     0x10f244c: ldurb           w16, [x1, #-1]
    //     0x10f2450: ldurb           w17, [x0, #-1]
    //     0x10f2454: and             x16, x17, x16, lsr #2
    //     0x10f2458: tst             x16, HEAP, lsr #32
    //     0x10f245c: b.eq            #0x10f2464
    //     0x10f2460: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x10f2464: ldr             x2, [THR, #0x90]  ; THR::object_sentinel
    // 0x10f2468: StoreField: r1->field_13 = r2
    //     0x10f2468: stur            w2, [x1, #0x13]
    // 0x10f246c: r2 = Instance__ElementLifecycle
    //     0x10f246c: ldr             x2, [PP, #0x7ef8]  ; [pp+0x7ef8] Obj!_ElementLifecycle@12c2fc1
    // 0x10f2470: StoreField: r1->field_23 = r2
    //     0x10f2470: stur            w2, [x1, #0x23]
    // 0x10f2474: r2 = false
    //     0x10f2474: add             x2, NULL, #0x30  ; false
    // 0x10f2478: StoreField: r1->field_2f = r2
    //     0x10f2478: stur            w2, [x1, #0x2f]
    // 0x10f247c: r3 = true
    //     0x10f247c: add             x3, NULL, #0x20  ; true
    // 0x10f2480: StoreField: r1->field_33 = r3
    //     0x10f2480: stur            w3, [x1, #0x33]
    // 0x10f2484: StoreField: r1->field_37 = r2
    //     0x10f2484: stur            w2, [x1, #0x37]
    // 0x10f2488: ldur            x0, [fp, #-0x10]
    // 0x10f248c: ArrayStore: r1[0] = r0  ; List_4
    //     0x10f248c: stur            w0, [x1, #0x17]
    //     0x10f2490: ldurb           w16, [x1, #-1]
    //     0x10f2494: ldurb           w17, [x0, #-1]
    //     0x10f2498: and             x16, x17, x16, lsr #2
    //     0x10f249c: tst             x16, HEAP, lsr #32
    //     0x10f24a0: b.eq            #0x10f24a8
    //     0x10f24a4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x10f24a8: r0 = Null
    //     0x10f24a8: mov             x0, NULL
    // 0x10f24ac: LeaveFrame
    //     0x10f24ac: mov             SP, fp
    //     0x10f24b0: ldp             fp, lr, [SP], #0x10
    // 0x10f24b4: ret
    //     0x10f24b4: ret             
    // 0x10f24b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10f24b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10f24bc: b               #0x10f23dc
  }
  _ update(/* No info */) {
    // ** addr: 0x10fab30, size: 0x184
    // 0x10fab30: EnterFrame
    //     0x10fab30: stp             fp, lr, [SP, #-0x10]!
    //     0x10fab34: mov             fp, SP
    // 0x10fab38: AllocStack(0x10)
    //     0x10fab38: sub             SP, SP, #0x10
    // 0x10fab3c: SetupParameters(_CupertinoTextSelectionToolbarItemsElement this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x10fab3c: mov             x4, x1
    //     0x10fab40: mov             x3, x2
    //     0x10fab44: stur            x1, [fp, #-8]
    //     0x10fab48: stur            x2, [fp, #-0x10]
    // 0x10fab4c: CheckStackOverflow
    //     0x10fab4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10fab50: cmp             SP, x16
    //     0x10fab54: b.ls            #0x10fac9c
    // 0x10fab58: mov             x0, x3
    // 0x10fab5c: r2 = Null
    //     0x10fab5c: mov             x2, NULL
    // 0x10fab60: r1 = Null
    //     0x10fab60: mov             x1, NULL
    // 0x10fab64: r4 = 60
    //     0x10fab64: mov             x4, #0x3c
    // 0x10fab68: branchIfSmi(r0, 0x10fab74)
    //     0x10fab68: tbz             w0, #0, #0x10fab74
    // 0x10fab6c: r4 = LoadClassIdInstr(r0)
    //     0x10fab6c: ldur            x4, [x0, #-1]
    //     0x10fab70: ubfx            x4, x4, #0xc, #0x14
    // 0x10fab74: r17 = 6563
    //     0x10fab74: mov             x17, #0x19a3
    // 0x10fab78: cmp             x4, x17
    // 0x10fab7c: b.eq            #0x10fab94
    // 0x10fab80: r8 = _CupertinoTextSelectionToolbarItems
    //     0x10fab80: add             x8, PP, #0xcc, lsl #12  ; [pp+0xcc560] Type: _CupertinoTextSelectionToolbarItems
    //     0x10fab84: ldr             x8, [x8, #0x560]
    // 0x10fab88: r3 = Null
    //     0x10fab88: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcc568] Null
    //     0x10fab8c: ldr             x3, [x3, #0x568]
    // 0x10fab90: r0 = DefaultTypeTest()
    //     0x10fab90: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x10fab94: ldur            x1, [fp, #-8]
    // 0x10fab98: ldur            x2, [fp, #-0x10]
    // 0x10fab9c: r0 = update()
    //     0x10fab9c: bl              #0x10facb4  ; [package:flutter/src/widgets/framework.dart] RenderObjectElement::update
    // 0x10faba0: ldur            x3, [fp, #-8]
    // 0x10faba4: ArrayLoad: r4 = r3[0]  ; List_4
    //     0x10faba4: ldur            w4, [x3, #0x17]
    // 0x10faba8: DecompressPointer r4
    //     0x10faba8: add             x4, x4, HEAP, lsl #32
    // 0x10fabac: stur            x4, [fp, #-0x10]
    // 0x10fabb0: cmp             w4, NULL
    // 0x10fabb4: b.eq            #0x10faca4
    // 0x10fabb8: mov             x0, x4
    // 0x10fabbc: r2 = Null
    //     0x10fabbc: mov             x2, NULL
    // 0x10fabc0: r1 = Null
    //     0x10fabc0: mov             x1, NULL
    // 0x10fabc4: r4 = LoadClassIdInstr(r0)
    //     0x10fabc4: ldur            x4, [x0, #-1]
    //     0x10fabc8: ubfx            x4, x4, #0xc, #0x14
    // 0x10fabcc: r17 = 6563
    //     0x10fabcc: mov             x17, #0x19a3
    // 0x10fabd0: cmp             x4, x17
    // 0x10fabd4: b.eq            #0x10fabec
    // 0x10fabd8: r8 = _CupertinoTextSelectionToolbarItems
    //     0x10fabd8: add             x8, PP, #0xcc, lsl #12  ; [pp+0xcc560] Type: _CupertinoTextSelectionToolbarItems
    //     0x10fabdc: ldr             x8, [x8, #0x560]
    // 0x10fabe0: r3 = Null
    //     0x10fabe0: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcc578] Null
    //     0x10fabe4: ldr             x3, [x3, #0x578]
    // 0x10fabe8: r0 = DefaultTypeTest()
    //     0x10fabe8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x10fabec: ldur            x0, [fp, #-0x10]
    // 0x10fabf0: LoadField: r2 = r0->field_b
    //     0x10fabf0: ldur            w2, [x0, #0xb]
    // 0x10fabf4: DecompressPointer r2
    //     0x10fabf4: add             x2, x2, HEAP, lsl #32
    // 0x10fabf8: ldur            x1, [fp, #-8]
    // 0x10fabfc: r3 = Instance__CupertinoTextSelectionToolbarItemsSlot
    //     0x10fabfc: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcc588] Obj!_CupertinoTextSelectionToolbarItemsSlot@12c5fc1
    //     0x10fac00: ldr             x3, [x3, #0x588]
    // 0x10fac04: r0 = _mountChild()
    //     0x10fac04: bl              #0xb8e79c  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _CupertinoTextSelectionToolbarItemsElement::_mountChild
    // 0x10fac08: ldur            x0, [fp, #-0x10]
    // 0x10fac0c: LoadField: r2 = r0->field_1f
    //     0x10fac0c: ldur            w2, [x0, #0x1f]
    // 0x10fac10: DecompressPointer r2
    //     0x10fac10: add             x2, x2, HEAP, lsl #32
    // 0x10fac14: ldur            x1, [fp, #-8]
    // 0x10fac18: r3 = Instance__CupertinoTextSelectionToolbarItemsSlot
    //     0x10fac18: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcc590] Obj!_CupertinoTextSelectionToolbarItemsSlot@12c5fa1
    //     0x10fac1c: ldr             x3, [x3, #0x590]
    // 0x10fac20: r0 = _mountChild()
    //     0x10fac20: bl              #0xb8e79c  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _CupertinoTextSelectionToolbarItemsElement::_mountChild
    // 0x10fac24: ldur            x0, [fp, #-8]
    // 0x10fac28: LoadField: r2 = r0->field_43
    //     0x10fac28: ldur            w2, [x0, #0x43]
    // 0x10fac2c: DecompressPointer r2
    //     0x10fac2c: add             x2, x2, HEAP, lsl #32
    // 0x10fac30: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10fac34: cmp             w2, w16
    // 0x10fac38: b.eq            #0x10faca8
    // 0x10fac3c: ldur            x1, [fp, #-0x10]
    // 0x10fac40: LoadField: r3 = r1->field_f
    //     0x10fac40: ldur            w3, [x1, #0xf]
    // 0x10fac44: DecompressPointer r3
    //     0x10fac44: add             x3, x3, HEAP, lsl #32
    // 0x10fac48: LoadField: r4 = r0->field_4b
    //     0x10fac48: ldur            w4, [x0, #0x4b]
    // 0x10fac4c: DecompressPointer r4
    //     0x10fac4c: add             x4, x4, HEAP, lsl #32
    // 0x10fac50: mov             x1, x0
    // 0x10fac54: mov             x5, x4
    // 0x10fac58: stur            x4, [fp, #-0x10]
    // 0x10fac5c: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x10fac5c: ldr             x4, [PP, #0xff0]  ; [pp+0xff0] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x10fac60: r0 = updateChildren()
    //     0x10fac60: bl              #0xbb3cf0  ; [package:flutter/src/widgets/framework.dart] Element::updateChildren
    // 0x10fac64: ldur            x1, [fp, #-8]
    // 0x10fac68: StoreField: r1->field_43 = r0
    //     0x10fac68: stur            w0, [x1, #0x43]
    //     0x10fac6c: ldurb           w16, [x1, #-1]
    //     0x10fac70: ldurb           w17, [x0, #-1]
    //     0x10fac74: and             x16, x17, x16, lsr #2
    //     0x10fac78: tst             x16, HEAP, lsr #32
    //     0x10fac7c: b.eq            #0x10fac84
    //     0x10fac80: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x10fac84: ldur            x1, [fp, #-0x10]
    // 0x10fac88: r0 = clear()
    //     0x10fac88: bl              #0x831198  ; [dart:collection] _HashSet::clear
    // 0x10fac8c: r0 = Null
    //     0x10fac8c: mov             x0, NULL
    // 0x10fac90: LeaveFrame
    //     0x10fac90: mov             SP, fp
    //     0x10fac94: ldp             fp, lr, [SP], #0x10
    // 0x10fac98: ret
    //     0x10fac98: ret             
    // 0x10fac9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10fac9c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10faca0: b               #0x10fab58
    // 0x10faca4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10faca4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x10faca8: r9 = _children
    //     0x10faca8: add             x9, PP, #0xcc, lsl #12  ; [pp+0xcc598] Field <_CupertinoTextSelectionToolbarItemsElement@298408280._children@298408280>: late (offset: 0x44)
    //     0x10facac: ldr             x9, [x9, #0x598]
    // 0x10facb0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x10facb0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ moveRenderObjectChild(/* No info */) {
    // ** addr: 0x1109188, size: 0x174
    // 0x1109188: EnterFrame
    //     0x1109188: stp             fp, lr, [SP, #-0x10]!
    //     0x110918c: mov             fp, SP
    // 0x1109190: AllocStack(0x20)
    //     0x1109190: sub             SP, SP, #0x20
    // 0x1109194: SetupParameters(_CupertinoTextSelectionToolbarItemsElement this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r0 */, dynamic _ /* r5 => r3, fp-0x18 */)
    //     0x1109194: mov             x0, x3
    //     0x1109198: mov             x3, x5
    //     0x110919c: stur            x5, [fp, #-0x18]
    //     0x11091a0: mov             x5, x1
    //     0x11091a4: mov             x4, x2
    //     0x11091a8: stur            x1, [fp, #-8]
    //     0x11091ac: stur            x2, [fp, #-0x10]
    // 0x11091b0: CheckStackOverflow
    //     0x11091b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11091b4: cmp             SP, x16
    //     0x11091b8: b.ls            #0x11092f0
    // 0x11091bc: r2 = Null
    //     0x11091bc: mov             x2, NULL
    // 0x11091c0: r1 = Null
    //     0x11091c0: mov             x1, NULL
    // 0x11091c4: r8 = IndexedSlot<Element>
    //     0x11091c4: add             x8, PP, #0xcc, lsl #12  ; [pp+0xcc5f8] Type: IndexedSlot<Element>
    //     0x11091c8: ldr             x8, [x8, #0x5f8]
    // 0x11091cc: r3 = Null
    //     0x11091cc: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcc600] Null
    //     0x11091d0: ldr             x3, [x3, #0x600]
    // 0x11091d4: r0 = IndexedSlot<Element>()
    //     0x11091d4: bl              #0x11092fc  ; IsType_IndexedSlot<Element>_Stub
    // 0x11091d8: ldur            x0, [fp, #-0x18]
    // 0x11091dc: r2 = Null
    //     0x11091dc: mov             x2, NULL
    // 0x11091e0: r1 = Null
    //     0x11091e0: mov             x1, NULL
    // 0x11091e4: r8 = IndexedSlot<Element>
    //     0x11091e4: add             x8, PP, #0xcc, lsl #12  ; [pp+0xcc5f8] Type: IndexedSlot<Element>
    //     0x11091e8: ldr             x8, [x8, #0x5f8]
    // 0x11091ec: r3 = Null
    //     0x11091ec: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcc610] Null
    //     0x11091f0: ldr             x3, [x3, #0x610]
    // 0x11091f4: r0 = IndexedSlot<Element>()
    //     0x11091f4: bl              #0x11092fc  ; IsType_IndexedSlot<Element>_Stub
    // 0x11091f8: ldur            x0, [fp, #-8]
    // 0x11091fc: LoadField: r3 = r0->field_3b
    //     0x11091fc: ldur            w3, [x0, #0x3b]
    // 0x1109200: DecompressPointer r3
    //     0x1109200: add             x3, x3, HEAP, lsl #32
    // 0x1109204: stur            x3, [fp, #-0x20]
    // 0x1109208: cmp             w3, NULL
    // 0x110920c: b.eq            #0x11092f8
    // 0x1109210: mov             x0, x3
    // 0x1109214: r2 = Null
    //     0x1109214: mov             x2, NULL
    // 0x1109218: r1 = Null
    //     0x1109218: mov             x1, NULL
    // 0x110921c: r4 = LoadClassIdInstr(r0)
    //     0x110921c: ldur            x4, [x0, #-1]
    //     0x1109220: ubfx            x4, x4, #0xc, #0x14
    // 0x1109224: r17 = 4843
    //     0x1109224: mov             x17, #0x12eb
    // 0x1109228: cmp             x4, x17
    // 0x110922c: b.eq            #0x1109244
    // 0x1109230: r8 = _RenderCupertinoTextSelectionToolbarItems
    //     0x1109230: add             x8, PP, #0xac, lsl #12  ; [pp+0xacc30] Type: _RenderCupertinoTextSelectionToolbarItems
    //     0x1109234: ldr             x8, [x8, #0xc30]
    // 0x1109238: r3 = Null
    //     0x1109238: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcc620] Null
    //     0x110923c: ldr             x3, [x3, #0x620]
    // 0x1109240: r0 = DefaultTypeTest()
    //     0x1109240: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x1109244: ldur            x0, [fp, #-0x10]
    // 0x1109248: r2 = Null
    //     0x1109248: mov             x2, NULL
    // 0x110924c: r1 = Null
    //     0x110924c: mov             x1, NULL
    // 0x1109250: r4 = LoadClassIdInstr(r0)
    //     0x1109250: ldur            x4, [x0, #-1]
    //     0x1109254: ubfx            x4, x4, #0xc, #0x14
    // 0x1109258: r17 = -4710
    //     0x1109258: mov             x17, #-0x1266
    // 0x110925c: add             x4, x4, x17
    // 0x1109260: cmp             x4, #0x109
    // 0x1109264: b.ls            #0x1109278
    // 0x1109268: r8 = RenderBox
    //     0x1109268: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0x110926c: r3 = Null
    //     0x110926c: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcc630] Null
    //     0x1109270: ldr             x3, [x3, #0x630]
    // 0x1109274: r0 = RenderBox()
    //     0x1109274: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0x1109278: ldur            x0, [fp, #-0x18]
    // 0x110927c: LoadField: r1 = r0->field_b
    //     0x110927c: ldur            w1, [x0, #0xb]
    // 0x1109280: DecompressPointer r1
    //     0x1109280: add             x1, x1, HEAP, lsl #32
    // 0x1109284: r0 = LoadClassIdInstr(r1)
    //     0x1109284: ldur            x0, [x1, #-1]
    //     0x1109288: ubfx            x0, x0, #0xc, #0x14
    // 0x110928c: r0 = GDT[cid_x0 + 0xd63]()
    //     0x110928c: add             lr, x0, #0xd63
    //     0x1109290: ldr             lr, [x21, lr, lsl #3]
    //     0x1109294: blr             lr
    // 0x1109298: mov             x3, x0
    // 0x110929c: r2 = Null
    //     0x110929c: mov             x2, NULL
    // 0x11092a0: r1 = Null
    //     0x11092a0: mov             x1, NULL
    // 0x11092a4: stur            x3, [fp, #-8]
    // 0x11092a8: r4 = LoadClassIdInstr(r0)
    //     0x11092a8: ldur            x4, [x0, #-1]
    //     0x11092ac: ubfx            x4, x4, #0xc, #0x14
    // 0x11092b0: r17 = -4710
    //     0x11092b0: mov             x17, #-0x1266
    // 0x11092b4: add             x4, x4, x17
    // 0x11092b8: cmp             x4, #0x109
    // 0x11092bc: b.ls            #0x11092d0
    // 0x11092c0: r8 = RenderBox?
    //     0x11092c0: ldr             x8, [PP, #0x47c8]  ; [pp+0x47c8] Type: RenderBox?
    // 0x11092c4: r3 = Null
    //     0x11092c4: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcc648] Null
    //     0x11092c8: ldr             x3, [x3, #0x648]
    // 0x11092cc: r0 = RenderBox?()
    //     0x11092cc: bl              #0x870a94  ; IsType_RenderBox?_Stub
    // 0x11092d0: ldur            x1, [fp, #-0x20]
    // 0x11092d4: ldur            x2, [fp, #-0x10]
    // 0x11092d8: ldur            x3, [fp, #-8]
    // 0x11092dc: r0 = move()
    //     0x11092dc: bl              #0xa160f8  ; [dart:mixin_deduplication] _MixinApplication118&RenderBox&ContainerRenderObjectMixin::move
    // 0x11092e0: r0 = Null
    //     0x11092e0: mov             x0, NULL
    // 0x11092e4: LeaveFrame
    //     0x11092e4: mov             SP, fp
    //     0x11092e8: ldp             fp, lr, [SP], #0x10
    // 0x11092ec: ret
    //     0x11092ec: ret             
    // 0x11092f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11092f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11092f4: b               #0x11091bc
    // 0x11092f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x11092f8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ insertRenderObjectChild(/* No info */) {
    // ** addr: 0x1145f84, size: 0x1d0
    // 0x1145f84: EnterFrame
    //     0x1145f84: stp             fp, lr, [SP, #-0x10]!
    //     0x1145f88: mov             fp, SP
    // 0x1145f8c: AllocStack(0x20)
    //     0x1145f8c: sub             SP, SP, #0x20
    // 0x1145f90: SetupParameters(_CupertinoTextSelectionToolbarItemsElement this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x1145f90: mov             x5, x1
    //     0x1145f94: mov             x4, x2
    //     0x1145f98: stur            x1, [fp, #-8]
    //     0x1145f9c: stur            x2, [fp, #-0x10]
    //     0x1145fa0: stur            x3, [fp, #-0x18]
    // 0x1145fa4: CheckStackOverflow
    //     0x1145fa4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1145fa8: cmp             SP, x16
    //     0x1145fac: b.ls            #0x1146148
    // 0x1145fb0: r0 = 60
    //     0x1145fb0: mov             x0, #0x3c
    // 0x1145fb4: branchIfSmi(r3, 0x1145fc0)
    //     0x1145fb4: tbz             w3, #0, #0x1145fc0
    // 0x1145fb8: r0 = LoadClassIdInstr(r3)
    //     0x1145fb8: ldur            x0, [x3, #-1]
    //     0x1145fbc: ubfx            x0, x0, #0xc, #0x14
    // 0x1145fc0: r17 = 8317
    //     0x1145fc0: mov             x17, #0x207d
    // 0x1145fc4: cmp             x0, x17
    // 0x1145fc8: b.ne            #0x1146020
    // 0x1145fcc: mov             x0, x4
    // 0x1145fd0: r2 = Null
    //     0x1145fd0: mov             x2, NULL
    // 0x1145fd4: r1 = Null
    //     0x1145fd4: mov             x1, NULL
    // 0x1145fd8: r4 = LoadClassIdInstr(r0)
    //     0x1145fd8: ldur            x4, [x0, #-1]
    //     0x1145fdc: ubfx            x4, x4, #0xc, #0x14
    // 0x1145fe0: r17 = -4710
    //     0x1145fe0: mov             x17, #-0x1266
    // 0x1145fe4: add             x4, x4, x17
    // 0x1145fe8: cmp             x4, #0x109
    // 0x1145fec: b.ls            #0x1146000
    // 0x1145ff0: r8 = RenderBox
    //     0x1145ff0: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0x1145ff4: r3 = Null
    //     0x1145ff4: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcc658] Null
    //     0x1145ff8: ldr             x3, [x3, #0x658]
    // 0x1145ffc: r0 = RenderBox()
    //     0x1145ffc: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0x1146000: ldur            x1, [fp, #-8]
    // 0x1146004: ldur            x2, [fp, #-0x10]
    // 0x1146008: ldur            x3, [fp, #-0x18]
    // 0x114600c: r0 = _updateRenderObject()
    //     0x114600c: bl              #0x1146154  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _CupertinoTextSelectionToolbarItemsElement::_updateRenderObject
    // 0x1146010: r0 = Null
    //     0x1146010: mov             x0, NULL
    // 0x1146014: LeaveFrame
    //     0x1146014: mov             SP, fp
    //     0x1146018: ldp             fp, lr, [SP], #0x10
    // 0x114601c: ret
    //     0x114601c: ret             
    // 0x1146020: cmp             x0, #0xa7a
    // 0x1146024: b.ne            #0x1146138
    // 0x1146028: ldur            x0, [fp, #-8]
    // 0x114602c: ldur            x3, [fp, #-0x18]
    // 0x1146030: LoadField: r4 = r0->field_3b
    //     0x1146030: ldur            w4, [x0, #0x3b]
    // 0x1146034: DecompressPointer r4
    //     0x1146034: add             x4, x4, HEAP, lsl #32
    // 0x1146038: stur            x4, [fp, #-0x20]
    // 0x114603c: cmp             w4, NULL
    // 0x1146040: b.eq            #0x1146150
    // 0x1146044: mov             x0, x4
    // 0x1146048: r2 = Null
    //     0x1146048: mov             x2, NULL
    // 0x114604c: r1 = Null
    //     0x114604c: mov             x1, NULL
    // 0x1146050: r4 = LoadClassIdInstr(r0)
    //     0x1146050: ldur            x4, [x0, #-1]
    //     0x1146054: ubfx            x4, x4, #0xc, #0x14
    // 0x1146058: r17 = 4843
    //     0x1146058: mov             x17, #0x12eb
    // 0x114605c: cmp             x4, x17
    // 0x1146060: b.eq            #0x1146078
    // 0x1146064: r8 = _RenderCupertinoTextSelectionToolbarItems
    //     0x1146064: add             x8, PP, #0xac, lsl #12  ; [pp+0xacc30] Type: _RenderCupertinoTextSelectionToolbarItems
    //     0x1146068: ldr             x8, [x8, #0xc30]
    // 0x114606c: r3 = Null
    //     0x114606c: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcc668] Null
    //     0x1146070: ldr             x3, [x3, #0x668]
    // 0x1146074: r0 = DefaultTypeTest()
    //     0x1146074: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x1146078: ldur            x0, [fp, #-0x10]
    // 0x114607c: r2 = Null
    //     0x114607c: mov             x2, NULL
    // 0x1146080: r1 = Null
    //     0x1146080: mov             x1, NULL
    // 0x1146084: r4 = LoadClassIdInstr(r0)
    //     0x1146084: ldur            x4, [x0, #-1]
    //     0x1146088: ubfx            x4, x4, #0xc, #0x14
    // 0x114608c: r17 = -4710
    //     0x114608c: mov             x17, #-0x1266
    // 0x1146090: add             x4, x4, x17
    // 0x1146094: cmp             x4, #0x109
    // 0x1146098: b.ls            #0x11460ac
    // 0x114609c: r8 = RenderBox
    //     0x114609c: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0x11460a0: r3 = Null
    //     0x11460a0: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcc678] Null
    //     0x11460a4: ldr             x3, [x3, #0x678]
    // 0x11460a8: r0 = RenderBox()
    //     0x11460a8: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0x11460ac: ldur            x0, [fp, #-0x18]
    // 0x11460b0: LoadField: r1 = r0->field_b
    //     0x11460b0: ldur            w1, [x0, #0xb]
    // 0x11460b4: DecompressPointer r1
    //     0x11460b4: add             x1, x1, HEAP, lsl #32
    // 0x11460b8: cmp             w1, NULL
    // 0x11460bc: b.ne            #0x11460c8
    // 0x11460c0: r3 = Null
    //     0x11460c0: mov             x3, NULL
    // 0x11460c4: b               #0x11460e0
    // 0x11460c8: r0 = LoadClassIdInstr(r1)
    //     0x11460c8: ldur            x0, [x1, #-1]
    //     0x11460cc: ubfx            x0, x0, #0xc, #0x14
    // 0x11460d0: r0 = GDT[cid_x0 + 0xd63]()
    //     0x11460d0: add             lr, x0, #0xd63
    //     0x11460d4: ldr             lr, [x21, lr, lsl #3]
    //     0x11460d8: blr             lr
    // 0x11460dc: mov             x3, x0
    // 0x11460e0: mov             x0, x3
    // 0x11460e4: stur            x3, [fp, #-8]
    // 0x11460e8: r2 = Null
    //     0x11460e8: mov             x2, NULL
    // 0x11460ec: r1 = Null
    //     0x11460ec: mov             x1, NULL
    // 0x11460f0: r4 = LoadClassIdInstr(r0)
    //     0x11460f0: ldur            x4, [x0, #-1]
    //     0x11460f4: ubfx            x4, x4, #0xc, #0x14
    // 0x11460f8: r17 = -4710
    //     0x11460f8: mov             x17, #-0x1266
    // 0x11460fc: add             x4, x4, x17
    // 0x1146100: cmp             x4, #0x109
    // 0x1146104: b.ls            #0x1146118
    // 0x1146108: r8 = RenderBox?
    //     0x1146108: ldr             x8, [PP, #0x47c8]  ; [pp+0x47c8] Type: RenderBox?
    // 0x114610c: r3 = Null
    //     0x114610c: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcc688] Null
    //     0x1146110: ldr             x3, [x3, #0x688]
    // 0x1146114: r0 = RenderBox?()
    //     0x1146114: bl              #0x870a94  ; IsType_RenderBox?_Stub
    // 0x1146118: ldur            x1, [fp, #-0x20]
    // 0x114611c: ldur            x2, [fp, #-0x10]
    // 0x1146120: ldur            x3, [fp, #-8]
    // 0x1146124: r0 = insert()
    //     0x1146124: bl              #0xae7fd4  ; [dart:mixin_deduplication] _MixinApplication118&RenderBox&ContainerRenderObjectMixin::insert
    // 0x1146128: r0 = Null
    //     0x1146128: mov             x0, NULL
    // 0x114612c: LeaveFrame
    //     0x114612c: mov             SP, fp
    //     0x1146130: ldp             fp, lr, [SP], #0x10
    // 0x1146134: ret
    //     0x1146134: ret             
    // 0x1146138: r0 = Null
    //     0x1146138: mov             x0, NULL
    // 0x114613c: LeaveFrame
    //     0x114613c: mov             SP, fp
    //     0x1146140: ldp             fp, lr, [SP], #0x10
    // 0x1146144: ret
    //     0x1146144: ret             
    // 0x1146148: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1146148: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x114614c: b               #0x1145fb0
    // 0x1146150: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1146150: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateRenderObject(/* No info */) {
    // ** addr: 0x1146154, size: 0xf8
    // 0x1146154: EnterFrame
    //     0x1146154: stp             fp, lr, [SP, #-0x10]!
    //     0x1146158: mov             fp, SP
    // 0x114615c: AllocStack(0x10)
    //     0x114615c: sub             SP, SP, #0x10
    // 0x1146160: SetupParameters(dynamic _ /* r2 => r4, fp-0x10 */)
    //     0x1146160: mov             x4, x2
    //     0x1146164: stur            x2, [fp, #-0x10]
    // 0x1146168: CheckStackOverflow
    //     0x1146168: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x114616c: cmp             SP, x16
    //     0x1146170: b.ls            #0x114623c
    // 0x1146174: LoadField: r0 = r3->field_7
    //     0x1146174: ldur            x0, [x3, #7]
    // 0x1146178: cmp             x0, #0
    // 0x114617c: b.gt            #0x11461d8
    // 0x1146180: LoadField: r3 = r1->field_3b
    //     0x1146180: ldur            w3, [x1, #0x3b]
    // 0x1146184: DecompressPointer r3
    //     0x1146184: add             x3, x3, HEAP, lsl #32
    // 0x1146188: stur            x3, [fp, #-8]
    // 0x114618c: cmp             w3, NULL
    // 0x1146190: b.eq            #0x1146244
    // 0x1146194: mov             x0, x3
    // 0x1146198: r2 = Null
    //     0x1146198: mov             x2, NULL
    // 0x114619c: r1 = Null
    //     0x114619c: mov             x1, NULL
    // 0x11461a0: r4 = LoadClassIdInstr(r0)
    //     0x11461a0: ldur            x4, [x0, #-1]
    //     0x11461a4: ubfx            x4, x4, #0xc, #0x14
    // 0x11461a8: r17 = 4843
    //     0x11461a8: mov             x17, #0x12eb
    // 0x11461ac: cmp             x4, x17
    // 0x11461b0: b.eq            #0x11461c8
    // 0x11461b4: r8 = _RenderCupertinoTextSelectionToolbarItems
    //     0x11461b4: add             x8, PP, #0xac, lsl #12  ; [pp+0xacc30] Type: _RenderCupertinoTextSelectionToolbarItems
    //     0x11461b8: ldr             x8, [x8, #0xc30]
    // 0x11461bc: r3 = Null
    //     0x11461bc: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcc5d8] Null
    //     0x11461c0: ldr             x3, [x3, #0x5d8]
    // 0x11461c4: r0 = DefaultTypeTest()
    //     0x11461c4: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x11461c8: ldur            x1, [fp, #-8]
    // 0x11461cc: ldur            x2, [fp, #-0x10]
    // 0x11461d0: r0 = backButton=()
    //     0x11461d0: bl              #0x1146358  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarItems::backButton=
    // 0x11461d4: b               #0x114622c
    // 0x11461d8: LoadField: r3 = r1->field_3b
    //     0x11461d8: ldur            w3, [x1, #0x3b]
    // 0x11461dc: DecompressPointer r3
    //     0x11461dc: add             x3, x3, HEAP, lsl #32
    // 0x11461e0: stur            x3, [fp, #-8]
    // 0x11461e4: cmp             w3, NULL
    // 0x11461e8: b.eq            #0x1146248
    // 0x11461ec: mov             x0, x3
    // 0x11461f0: r2 = Null
    //     0x11461f0: mov             x2, NULL
    // 0x11461f4: r1 = Null
    //     0x11461f4: mov             x1, NULL
    // 0x11461f8: r4 = LoadClassIdInstr(r0)
    //     0x11461f8: ldur            x4, [x0, #-1]
    //     0x11461fc: ubfx            x4, x4, #0xc, #0x14
    // 0x1146200: r17 = 4843
    //     0x1146200: mov             x17, #0x12eb
    // 0x1146204: cmp             x4, x17
    // 0x1146208: b.eq            #0x1146220
    // 0x114620c: r8 = _RenderCupertinoTextSelectionToolbarItems
    //     0x114620c: add             x8, PP, #0xac, lsl #12  ; [pp+0xacc30] Type: _RenderCupertinoTextSelectionToolbarItems
    //     0x1146210: ldr             x8, [x8, #0xc30]
    // 0x1146214: r3 = Null
    //     0x1146214: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcc5e8] Null
    //     0x1146218: ldr             x3, [x3, #0x5e8]
    // 0x114621c: r0 = DefaultTypeTest()
    //     0x114621c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x1146220: ldur            x1, [fp, #-8]
    // 0x1146224: ldur            x2, [fp, #-0x10]
    // 0x1146228: r0 = nextButton=()
    //     0x1146228: bl              #0x114624c  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarItems::nextButton=
    // 0x114622c: r0 = Null
    //     0x114622c: mov             x0, NULL
    // 0x1146230: LeaveFrame
    //     0x1146230: mov             SP, fp
    //     0x1146234: ldp             fp, lr, [SP], #0x10
    // 0x1146238: ret
    //     0x1146238: ret             
    // 0x114623c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x114623c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1146240: b               #0x1146174
    // 0x1146244: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1146244: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x1146248: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1146248: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ forgetChild(/* No info */) {
    // ** addr: 0x116c0d8, size: 0xdc
    // 0x116c0d8: EnterFrame
    //     0x116c0d8: stp             fp, lr, [SP, #-0x10]!
    //     0x116c0dc: mov             fp, SP
    // 0x116c0e0: AllocStack(0x20)
    //     0x116c0e0: sub             SP, SP, #0x20
    // 0x116c0e4: SetupParameters(_CupertinoTextSelectionToolbarItemsElement this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */)
    //     0x116c0e4: mov             x3, x1
    //     0x116c0e8: mov             x0, x2
    //     0x116c0ec: stur            x1, [fp, #-0x10]
    //     0x116c0f0: stur            x2, [fp, #-0x18]
    // 0x116c0f4: CheckStackOverflow
    //     0x116c0f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x116c0f8: cmp             SP, x16
    //     0x116c0fc: b.ls            #0x116c1a8
    // 0x116c100: LoadField: r4 = r3->field_47
    //     0x116c100: ldur            w4, [x3, #0x47]
    // 0x116c104: DecompressPointer r4
    //     0x116c104: add             x4, x4, HEAP, lsl #32
    // 0x116c108: stur            x4, [fp, #-8]
    // 0x116c10c: LoadField: r2 = r0->field_f
    //     0x116c10c: ldur            w2, [x0, #0xf]
    // 0x116c110: DecompressPointer r2
    //     0x116c110: add             x2, x2, HEAP, lsl #32
    // 0x116c114: mov             x1, x4
    // 0x116c118: r0 = containsKey()
    //     0x116c118: bl              #0x12d5a5c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x116c11c: tbnz            w0, #4, #0x116c184
    // 0x116c120: ldur            x2, [fp, #-0x18]
    // 0x116c124: LoadField: r3 = r2->field_f
    //     0x116c124: ldur            w3, [x2, #0xf]
    // 0x116c128: DecompressPointer r3
    //     0x116c128: add             x3, x3, HEAP, lsl #32
    // 0x116c12c: stur            x3, [fp, #-0x20]
    // 0x116c130: cmp             w3, NULL
    // 0x116c134: b.eq            #0x116c1b0
    // 0x116c138: mov             x0, x3
    // 0x116c13c: r2 = Null
    //     0x116c13c: mov             x2, NULL
    // 0x116c140: r1 = Null
    //     0x116c140: mov             x1, NULL
    // 0x116c144: r4 = 60
    //     0x116c144: mov             x4, #0x3c
    // 0x116c148: branchIfSmi(r0, 0x116c154)
    //     0x116c148: tbz             w0, #0, #0x116c154
    // 0x116c14c: r4 = LoadClassIdInstr(r0)
    //     0x116c14c: ldur            x4, [x0, #-1]
    //     0x116c150: ubfx            x4, x4, #0xc, #0x14
    // 0x116c154: r17 = 8317
    //     0x116c154: mov             x17, #0x207d
    // 0x116c158: cmp             x4, x17
    // 0x116c15c: b.eq            #0x116c174
    // 0x116c160: r8 = _CupertinoTextSelectionToolbarItemsSlot
    //     0x116c160: add             x8, PP, #0xcc, lsl #12  ; [pp+0xcc5b0] Type: _CupertinoTextSelectionToolbarItemsSlot
    //     0x116c164: ldr             x8, [x8, #0x5b0]
    // 0x116c168: r3 = Null
    //     0x116c168: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcc5b8] Null
    //     0x116c16c: ldr             x3, [x3, #0x5b8]
    // 0x116c170: r0 = _CupertinoTextSelectionToolbarItemsSlot()
    //     0x116c170: bl              #0xb8e9a4  ; IsType__CupertinoTextSelectionToolbarItemsSlot_Stub
    // 0x116c174: ldur            x1, [fp, #-8]
    // 0x116c178: ldur            x2, [fp, #-0x20]
    // 0x116c17c: r0 = remove()
    //     0x116c17c: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x116c180: b               #0x116c198
    // 0x116c184: ldur            x0, [fp, #-0x10]
    // 0x116c188: ldur            x2, [fp, #-0x18]
    // 0x116c18c: LoadField: r1 = r0->field_4b
    //     0x116c18c: ldur            w1, [x0, #0x4b]
    // 0x116c190: DecompressPointer r1
    //     0x116c190: add             x1, x1, HEAP, lsl #32
    // 0x116c194: r0 = add()
    //     0x116c194: bl              #0x1259a30  ; [dart:collection] _HashSet::add
    // 0x116c198: r0 = Null
    //     0x116c198: mov             x0, NULL
    // 0x116c19c: LeaveFrame
    //     0x116c19c: mov             SP, fp
    //     0x116c1a0: ldp             fp, lr, [SP], #0x10
    // 0x116c1a4: ret
    //     0x116c1a4: ret             
    // 0x116c1a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x116c1a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x116c1ac: b               #0x116c100
    // 0x116c1b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x116c1b0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ removeRenderObjectChild(/* No info */) {
    // ** addr: 0x116c520, size: 0xb8
    // 0x116c520: EnterFrame
    //     0x116c520: stp             fp, lr, [SP, #-0x10]!
    //     0x116c524: mov             fp, SP
    // 0x116c528: AllocStack(0x10)
    //     0x116c528: sub             SP, SP, #0x10
    // 0x116c52c: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0x116c52c: mov             x0, x2
    //     0x116c530: stur            x2, [fp, #-8]
    // 0x116c534: CheckStackOverflow
    //     0x116c534: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x116c538: cmp             SP, x16
    //     0x116c53c: b.ls            #0x116c5d0
    // 0x116c540: r2 = 60
    //     0x116c540: mov             x2, #0x3c
    // 0x116c544: branchIfSmi(r3, 0x116c550)
    //     0x116c544: tbz             w3, #0, #0x116c550
    // 0x116c548: r2 = LoadClassIdInstr(r3)
    //     0x116c548: ldur            x2, [x3, #-1]
    //     0x116c54c: ubfx            x2, x2, #0xc, #0x14
    // 0x116c550: r17 = 8317
    //     0x116c550: mov             x17, #0x207d
    // 0x116c554: cmp             x2, x17
    // 0x116c558: b.ne            #0x116c574
    // 0x116c55c: r2 = Null
    //     0x116c55c: mov             x2, NULL
    // 0x116c560: r0 = _updateRenderObject()
    //     0x116c560: bl              #0x1146154  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _CupertinoTextSelectionToolbarItemsElement::_updateRenderObject
    // 0x116c564: r0 = Null
    //     0x116c564: mov             x0, NULL
    // 0x116c568: LeaveFrame
    //     0x116c568: mov             SP, fp
    //     0x116c56c: ldp             fp, lr, [SP], #0x10
    // 0x116c570: ret
    //     0x116c570: ret             
    // 0x116c574: r0 = renderObject()
    //     0x116c574: bl              #0x123ed74  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _CupertinoTextSelectionToolbarItemsElement::renderObject
    // 0x116c578: mov             x3, x0
    // 0x116c57c: ldur            x0, [fp, #-8]
    // 0x116c580: r2 = Null
    //     0x116c580: mov             x2, NULL
    // 0x116c584: r1 = Null
    //     0x116c584: mov             x1, NULL
    // 0x116c588: stur            x3, [fp, #-0x10]
    // 0x116c58c: r4 = LoadClassIdInstr(r0)
    //     0x116c58c: ldur            x4, [x0, #-1]
    //     0x116c590: ubfx            x4, x4, #0xc, #0x14
    // 0x116c594: r17 = -4710
    //     0x116c594: mov             x17, #-0x1266
    // 0x116c598: add             x4, x4, x17
    // 0x116c59c: cmp             x4, #0x109
    // 0x116c5a0: b.ls            #0x116c5b4
    // 0x116c5a4: r8 = RenderBox
    //     0x116c5a4: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0x116c5a8: r3 = Null
    //     0x116c5a8: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcc5c8] Null
    //     0x116c5ac: ldr             x3, [x3, #0x5c8]
    // 0x116c5b0: r0 = RenderBox()
    //     0x116c5b0: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0x116c5b4: ldur            x1, [fp, #-0x10]
    // 0x116c5b8: ldur            x2, [fp, #-8]
    // 0x116c5bc: r0 = remove()
    //     0x116c5bc: bl              #0xa1a4f8  ; [dart:mixin_deduplication] _MixinApplication118&RenderBox&ContainerRenderObjectMixin::remove
    // 0x116c5c0: r0 = Null
    //     0x116c5c0: mov             x0, NULL
    // 0x116c5c4: LeaveFrame
    //     0x116c5c4: mov             SP, fp
    //     0x116c5c8: ldp             fp, lr, [SP], #0x10
    // 0x116c5cc: ret
    //     0x116c5cc: ret             
    // 0x116c5d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x116c5d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x116c5d4: b               #0x116c540
  }
  _ visitChildren(/* No info */) {
    // ** addr: 0x1233cd0, size: 0x11c
    // 0x1233cd0: EnterFrame
    //     0x1233cd0: stp             fp, lr, [SP, #-0x10]!
    //     0x1233cd4: mov             fp, SP
    // 0x1233cd8: AllocStack(0x48)
    //     0x1233cd8: sub             SP, SP, #0x48
    // 0x1233cdc: SetupParameters(_CupertinoTextSelectionToolbarItemsElement this /* r1 => r0, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0x1233cdc: mov             x0, x1
    //     0x1233ce0: stur            x1, [fp, #-0x10]
    //     0x1233ce4: stur            x2, [fp, #-0x18]
    // 0x1233ce8: CheckStackOverflow
    //     0x1233ce8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1233cec: cmp             SP, x16
    //     0x1233cf0: b.ls            #0x1233dd0
    // 0x1233cf4: LoadField: r3 = r0->field_47
    //     0x1233cf4: ldur            w3, [x0, #0x47]
    // 0x1233cf8: DecompressPointer r3
    //     0x1233cf8: add             x3, x3, HEAP, lsl #32
    // 0x1233cfc: stur            x3, [fp, #-8]
    // 0x1233d00: r1 = <Element>
    //     0x1233d00: ldr             x1, [PP, #0x1c38]  ; [pp+0x1c38] TypeArguments: <Element>
    // 0x1233d04: r0 = _CompactValuesIterable()
    //     0x1233d04: bl              #0x7f3fb4  ; Allocate_CompactValuesIterableStub -> _CompactValuesIterable<X0> (size=0x10)
    // 0x1233d08: mov             x1, x0
    // 0x1233d0c: ldur            x0, [fp, #-8]
    // 0x1233d10: StoreField: r1->field_b = r0
    //     0x1233d10: stur            w0, [x1, #0xb]
    // 0x1233d14: ldur            x2, [fp, #-0x18]
    // 0x1233d18: r0 = forEach()
    //     0x1233d18: bl              #0xaffee4  ; [dart:core] Iterable::forEach
    // 0x1233d1c: ldur            x0, [fp, #-0x10]
    // 0x1233d20: LoadField: r3 = r0->field_43
    //     0x1233d20: ldur            w3, [x0, #0x43]
    // 0x1233d24: DecompressPointer r3
    //     0x1233d24: add             x3, x3, HEAP, lsl #32
    // 0x1233d28: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1233d2c: cmp             w3, w16
    // 0x1233d30: b.eq            #0x1233dd8
    // 0x1233d34: stur            x3, [fp, #-0x38]
    // 0x1233d38: LoadField: r1 = r3->field_b
    //     0x1233d38: ldur            w1, [x3, #0xb]
    // 0x1233d3c: r4 = LoadInt32Instr(r1)
    //     0x1233d3c: sbfx            x4, x1, #1, #0x1f
    // 0x1233d40: stur            x4, [fp, #-0x30]
    // 0x1233d44: LoadField: r5 = r0->field_4b
    //     0x1233d44: ldur            w5, [x0, #0x4b]
    // 0x1233d48: DecompressPointer r5
    //     0x1233d48: add             x5, x5, HEAP, lsl #32
    // 0x1233d4c: stur            x5, [fp, #-0x28]
    // 0x1233d50: r0 = 0
    //     0x1233d50: mov             x0, #0
    // 0x1233d54: CheckStackOverflow
    //     0x1233d54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1233d58: cmp             SP, x16
    //     0x1233d5c: b.ls            #0x1233de4
    // 0x1233d60: cmp             x0, x4
    // 0x1233d64: b.ge            #0x1233dc0
    // 0x1233d68: ArrayLoad: r6 = r3[r0]  ; Unknown_4
    //     0x1233d68: add             x16, x3, x0, lsl #2
    //     0x1233d6c: ldur            w6, [x16, #0xf]
    // 0x1233d70: DecompressPointer r6
    //     0x1233d70: add             x6, x6, HEAP, lsl #32
    // 0x1233d74: stur            x6, [fp, #-8]
    // 0x1233d78: add             x7, x0, #1
    // 0x1233d7c: mov             x1, x5
    // 0x1233d80: mov             x2, x6
    // 0x1233d84: stur            x7, [fp, #-0x20]
    // 0x1233d88: r0 = contains()
    //     0x1233d88: bl              #0xb06504  ; [dart:collection] _HashSet::contains
    // 0x1233d8c: tbz             w0, #4, #0x1233dac
    // 0x1233d90: ldur            x16, [fp, #-0x18]
    // 0x1233d94: ldur            lr, [fp, #-8]
    // 0x1233d98: stp             lr, x16, [SP]
    // 0x1233d9c: ldur            x0, [fp, #-0x18]
    // 0x1233da0: ClosureCall
    //     0x1233da0: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x1233da4: ldur            x2, [x0, #0x1f]
    //     0x1233da8: blr             x2
    // 0x1233dac: ldur            x0, [fp, #-0x20]
    // 0x1233db0: ldur            x5, [fp, #-0x28]
    // 0x1233db4: ldur            x3, [fp, #-0x38]
    // 0x1233db8: ldur            x4, [fp, #-0x30]
    // 0x1233dbc: b               #0x1233d54
    // 0x1233dc0: r0 = Null
    //     0x1233dc0: mov             x0, NULL
    // 0x1233dc4: LeaveFrame
    //     0x1233dc4: mov             SP, fp
    //     0x1233dc8: ldp             fp, lr, [SP], #0x10
    // 0x1233dcc: ret
    //     0x1233dcc: ret             
    // 0x1233dd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1233dd0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1233dd4: b               #0x1233cf4
    // 0x1233dd8: r9 = _children
    //     0x1233dd8: add             x9, PP, #0xcc, lsl #12  ; [pp+0xcc598] Field <_CupertinoTextSelectionToolbarItemsElement@298408280._children@298408280>: late (offset: 0x44)
    //     0x1233ddc: ldr             x9, [x9, #0x598]
    // 0x1233de0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x1233de0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x1233de4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1233de4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1233de8: b               #0x1233d60
  }
  get _ renderObject(/* No info */) {
    // ** addr: 0x123ed74, size: 0x68
    // 0x123ed74: EnterFrame
    //     0x123ed74: stp             fp, lr, [SP, #-0x10]!
    //     0x123ed78: mov             fp, SP
    // 0x123ed7c: AllocStack(0x8)
    //     0x123ed7c: sub             SP, SP, #8
    // 0x123ed80: LoadField: r3 = r1->field_3b
    //     0x123ed80: ldur            w3, [x1, #0x3b]
    // 0x123ed84: DecompressPointer r3
    //     0x123ed84: add             x3, x3, HEAP, lsl #32
    // 0x123ed88: stur            x3, [fp, #-8]
    // 0x123ed8c: cmp             w3, NULL
    // 0x123ed90: b.eq            #0x123edd8
    // 0x123ed94: mov             x0, x3
    // 0x123ed98: r2 = Null
    //     0x123ed98: mov             x2, NULL
    // 0x123ed9c: r1 = Null
    //     0x123ed9c: mov             x1, NULL
    // 0x123eda0: r4 = LoadClassIdInstr(r0)
    //     0x123eda0: ldur            x4, [x0, #-1]
    //     0x123eda4: ubfx            x4, x4, #0xc, #0x14
    // 0x123eda8: r17 = 4843
    //     0x123eda8: mov             x17, #0x12eb
    // 0x123edac: cmp             x4, x17
    // 0x123edb0: b.eq            #0x123edc8
    // 0x123edb4: r8 = _RenderCupertinoTextSelectionToolbarItems
    //     0x123edb4: add             x8, PP, #0xac, lsl #12  ; [pp+0xacc30] Type: _RenderCupertinoTextSelectionToolbarItems
    //     0x123edb8: ldr             x8, [x8, #0xc30]
    // 0x123edbc: r3 = Null
    //     0x123edbc: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcc698] Null
    //     0x123edc0: ldr             x3, [x3, #0x698]
    // 0x123edc4: r0 = DefaultTypeTest()
    //     0x123edc4: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x123edc8: ldur            x0, [fp, #-8]
    // 0x123edcc: LeaveFrame
    //     0x123edcc: mov             SP, fp
    //     0x123edd0: ldp             fp, lr, [SP], #0x10
    // 0x123edd4: ret
    //     0x123edd4: ret             
    // 0x123edd8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x123edd8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 6200, size: 0x1c, field offset: 0xc
//   const constructor, 
class CupertinoTextSelectionToolbar extends StatelessWidget {

  [closure] static Widget _defaultToolbarBuilder(dynamic, BuildContext, Offset, Offset, Widget) {
    // ** addr: 0xd775d0, size: 0x3c
    // 0xd775d0: EnterFrame
    //     0xd775d0: stp             fp, lr, [SP, #-0x10]!
    //     0xd775d4: mov             fp, SP
    // 0xd775d8: CheckStackOverflow
    //     0xd775d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd775dc: cmp             SP, x16
    //     0xd775e0: b.ls            #0xd77604
    // 0xd775e4: ldr             x1, [fp, #0x28]
    // 0xd775e8: ldr             x2, [fp, #0x20]
    // 0xd775ec: ldr             x3, [fp, #0x18]
    // 0xd775f0: ldr             x5, [fp, #0x10]
    // 0xd775f4: r0 = _defaultToolbarBuilder()
    //     0xd775f4: bl              #0xd7760c  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] CupertinoTextSelectionToolbar::_defaultToolbarBuilder
    // 0xd775f8: LeaveFrame
    //     0xd775f8: mov             SP, fp
    //     0xd775fc: ldp             fp, lr, [SP], #0x10
    // 0xd77600: ret
    //     0xd77600: ret             
    // 0xd77604: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd77604: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd77608: b               #0xd775e4
  }
  static _ _defaultToolbarBuilder(/* No info */) {
    // ** addr: 0xd7760c, size: 0xe0
    // 0xd7760c: EnterFrame
    //     0xd7760c: stp             fp, lr, [SP, #-0x10]!
    //     0xd77610: mov             fp, SP
    // 0xd77614: AllocStack(0x30)
    //     0xd77614: sub             SP, SP, #0x30
    // 0xd77618: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */)
    //     0xd77618: mov             x0, x1
    //     0xd7761c: stur            x1, [fp, #-8]
    //     0xd77620: stur            x2, [fp, #-0x10]
    //     0xd77624: stur            x3, [fp, #-0x18]
    //     0xd77628: stur            x5, [fp, #-0x20]
    // 0xd7762c: CheckStackOverflow
    //     0xd7762c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd77630: cmp             SP, x16
    //     0xd77634: b.ls            #0xd776e4
    // 0xd77638: mov             x1, x0
    // 0xd7763c: r0 = brightnessOf()
    //     0xd7763c: bl              #0xd776f8  ; [package:flutter/src/cupertino/theme.dart] CupertinoTheme::brightnessOf
    // 0xd77640: r16 = Instance_Brightness
    //     0xd77640: ldr             x16, [PP, #0x6da0]  ; [pp+0x6da0] Obj!Brightness@12c71c1
    // 0xd77644: cmp             w0, w16
    // 0xd77648: b.ne            #0xd77668
    // 0xd7764c: r1 = Instance_Color
    //     0xd7764c: add             x1, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0xd77650: ldr             x1, [x1, #0x948]
    // 0xd77654: d0 = 0.200000
    //     0xd77654: add             x17, PP, #0x13, lsl #12  ; [pp+0x13230] IMM: double(0.2) from 0x3fc999999999999a
    //     0xd77658: ldr             d0, [x17, #0x230]
    // 0xd7765c: r0 = withOpacity()
    //     0xd7765c: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xd77660: mov             x5, x0
    // 0xd77664: b               #0xd7766c
    // 0xd77668: r5 = Null
    //     0xd77668: mov             x5, NULL
    // 0xd7766c: ldur            x4, [fp, #-0x10]
    // 0xd77670: ldur            x3, [fp, #-0x18]
    // 0xd77674: ldur            x0, [fp, #-0x20]
    // 0xd77678: ldur            x2, [fp, #-8]
    // 0xd7767c: stur            x5, [fp, #-0x28]
    // 0xd77680: r1 = Instance_CupertinoDynamicColor
    //     0xd77680: add             x1, PP, #0x80, lsl #12  ; [pp+0x809e0] Obj!CupertinoDynamicColor@12b3a71
    //     0xd77684: ldr             x1, [x1, #0x9e0]
    // 0xd77688: r0 = resolveFrom()
    //     0xd77688: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0xd7768c: stur            x0, [fp, #-8]
    // 0xd77690: r0 = ColoredBox()
    //     0xd77690: bl              #0xd1a914  ; AllocateColoredBoxStub -> ColoredBox (size=0x18)
    // 0xd77694: mov             x1, x0
    // 0xd77698: ldur            x0, [fp, #-8]
    // 0xd7769c: stur            x1, [fp, #-0x30]
    // 0xd776a0: StoreField: r1->field_f = r0
    //     0xd776a0: stur            w0, [x1, #0xf]
    // 0xd776a4: r0 = true
    //     0xd776a4: add             x0, NULL, #0x20  ; true
    // 0xd776a8: StoreField: r1->field_13 = r0
    //     0xd776a8: stur            w0, [x1, #0x13]
    // 0xd776ac: ldur            x0, [fp, #-0x20]
    // 0xd776b0: StoreField: r1->field_b = r0
    //     0xd776b0: stur            w0, [x1, #0xb]
    // 0xd776b4: r0 = _CupertinoTextSelectionToolbarShape()
    //     0xd776b4: bl              #0xd776ec  ; Allocate_CupertinoTextSelectionToolbarShapeStub -> _CupertinoTextSelectionToolbarShape (size=0x1c)
    // 0xd776b8: ldur            x1, [fp, #-0x10]
    // 0xd776bc: StoreField: r0->field_f = r1
    //     0xd776bc: stur            w1, [x0, #0xf]
    // 0xd776c0: ldur            x1, [fp, #-0x18]
    // 0xd776c4: StoreField: r0->field_13 = r1
    //     0xd776c4: stur            w1, [x0, #0x13]
    // 0xd776c8: ldur            x1, [fp, #-0x28]
    // 0xd776cc: ArrayStore: r0[0] = r1  ; List_4
    //     0xd776cc: stur            w1, [x0, #0x17]
    // 0xd776d0: ldur            x1, [fp, #-0x30]
    // 0xd776d4: StoreField: r0->field_b = r1
    //     0xd776d4: stur            w1, [x0, #0xb]
    // 0xd776d8: LeaveFrame
    //     0xd776d8: mov             SP, fp
    //     0xd776dc: ldp             fp, lr, [SP], #0x10
    // 0xd776e0: ret
    //     0xd776e0: ret             
    // 0xd776e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd776e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd776e8: b               #0xd77638
  }
  _ build(/* No info */) {
    // ** addr: 0xfadae0, size: 0x230
    // 0xfadae0: EnterFrame
    //     0xfadae0: stp             fp, lr, [SP, #-0x10]!
    //     0xfadae4: mov             fp, SP
    // 0xfadae8: AllocStack(0x58)
    //     0xfadae8: sub             SP, SP, #0x58
    // 0xfadaec: SetupParameters(CupertinoTextSelectionToolbar this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xfadaec: mov             x0, x2
    //     0xfadaf0: stur            x2, [fp, #-0x10]
    //     0xfadaf4: mov             x2, x1
    //     0xfadaf8: stur            x1, [fp, #-8]
    // 0xfadafc: CheckStackOverflow
    //     0xfadafc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfadb00: cmp             SP, x16
    //     0xfadb04: b.ls            #0xfadd08
    // 0xfadb08: mov             x1, x0
    // 0xfadb0c: r0 = paddingOf()
    //     0xfadb0c: bl              #0xd1a984  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::paddingOf
    // 0xfadb10: stur            x0, [fp, #-0x18]
    // 0xfadb14: LoadField: d0 = r0->field_f
    //     0xfadb14: ldur            d0, [x0, #0xf]
    // 0xfadb18: d1 = 8.000000
    //     0xfadb18: fmov            d1, #8.00000000
    // 0xfadb1c: fadd            d2, d0, d1
    // 0xfadb20: stur            d2, [fp, #-0x40]
    // 0xfadb24: LoadField: d0 = r0->field_7
    //     0xfadb24: ldur            d0, [x0, #7]
    // 0xfadb28: d3 = 26.000000
    //     0xfadb28: fmov            d3, #26.00000000
    // 0xfadb2c: fadd            d4, d0, d3
    // 0xfadb30: ldur            x1, [fp, #-0x10]
    // 0xfadb34: stur            d4, [fp, #-0x38]
    // 0xfadb38: r0 = widthOf()
    //     0xfadb38: bl              #0xd6f80c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::widthOf
    // 0xfadb3c: ldur            x0, [fp, #-0x18]
    // 0xfadb40: ArrayLoad: d1 = r0[0]  ; List_8
    //     0xfadb40: ldur            d1, [x0, #0x17]
    // 0xfadb44: fsub            d2, d0, d1
    // 0xfadb48: d0 = 26.000000
    //     0xfadb48: fmov            d0, #26.00000000
    // 0xfadb4c: fsub            d1, d2, d0
    // 0xfadb50: ldur            x0, [fp, #-8]
    // 0xfadb54: stur            d1, [fp, #-0x58]
    // 0xfadb58: LoadField: r1 = r0->field_b
    //     0xfadb58: ldur            w1, [x0, #0xb]
    // 0xfadb5c: DecompressPointer r1
    //     0xfadb5c: add             x1, x1, HEAP, lsl #32
    // 0xfadb60: LoadField: d0 = r1->field_7
    //     0xfadb60: ldur            d0, [x1, #7]
    // 0xfadb64: ldur            d2, [fp, #-0x38]
    // 0xfadb68: fcmp            d2, d0
    // 0xfadb6c: b.le            #0xfadb78
    // 0xfadb70: mov             v4.16b, v2.16b
    // 0xfadb74: b               #0xfadb9c
    // 0xfadb78: fcmp            d0, d1
    // 0xfadb7c: b.le            #0xfadb88
    // 0xfadb80: mov             v4.16b, v1.16b
    // 0xfadb84: b               #0xfadb9c
    // 0xfadb88: fcmp            d0, d0
    // 0xfadb8c: b.vc            #0xfadb98
    // 0xfadb90: mov             v4.16b, v1.16b
    // 0xfadb94: b               #0xfadb9c
    // 0xfadb98: mov             v4.16b, v0.16b
    // 0xfadb9c: ldur            d3, [fp, #-0x40]
    // 0xfadba0: d0 = 8.000000
    //     0xfadba0: fmov            d0, #8.00000000
    // 0xfadba4: stur            d4, [fp, #-0x50]
    // 0xfadba8: LoadField: d5 = r1->field_f
    //     0xfadba8: ldur            d5, [x1, #0xf]
    // 0xfadbac: fsub            d6, d5, d0
    // 0xfadbb0: fsub            d5, d6, d3
    // 0xfadbb4: stur            d5, [fp, #-0x48]
    // 0xfadbb8: r0 = Offset()
    //     0xfadbb8: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xfadbbc: ldur            d0, [fp, #-0x50]
    // 0xfadbc0: stur            x0, [fp, #-0x10]
    // 0xfadbc4: StoreField: r0->field_7 = d0
    //     0xfadbc4: stur            d0, [x0, #7]
    // 0xfadbc8: ldur            d0, [fp, #-0x48]
    // 0xfadbcc: StoreField: r0->field_f = d0
    //     0xfadbcc: stur            d0, [x0, #0xf]
    // 0xfadbd0: ldur            x1, [fp, #-8]
    // 0xfadbd4: LoadField: r2 = r1->field_f
    //     0xfadbd4: ldur            w2, [x1, #0xf]
    // 0xfadbd8: DecompressPointer r2
    //     0xfadbd8: add             x2, x2, HEAP, lsl #32
    // 0xfadbdc: LoadField: d0 = r2->field_7
    //     0xfadbdc: ldur            d0, [x2, #7]
    // 0xfadbe0: ldur            d1, [fp, #-0x38]
    // 0xfadbe4: fcmp            d1, d0
    // 0xfadbe8: b.le            #0xfadbf4
    // 0xfadbec: mov             v2.16b, v1.16b
    // 0xfadbf0: b               #0xfadc1c
    // 0xfadbf4: ldur            d1, [fp, #-0x58]
    // 0xfadbf8: fcmp            d0, d1
    // 0xfadbfc: b.le            #0xfadc08
    // 0xfadc00: mov             v2.16b, v1.16b
    // 0xfadc04: b               #0xfadc1c
    // 0xfadc08: fcmp            d0, d0
    // 0xfadc0c: b.vc            #0xfadc18
    // 0xfadc10: mov             v2.16b, v1.16b
    // 0xfadc14: b               #0xfadc1c
    // 0xfadc18: mov             v2.16b, v0.16b
    // 0xfadc1c: ldur            d1, [fp, #-0x40]
    // 0xfadc20: d0 = 8.000000
    //     0xfadc20: fmov            d0, #8.00000000
    // 0xfadc24: stur            d2, [fp, #-0x48]
    // 0xfadc28: LoadField: d3 = r2->field_f
    //     0xfadc28: ldur            d3, [x2, #0xf]
    // 0xfadc2c: fadd            d4, d3, d0
    // 0xfadc30: fsub            d3, d4, d1
    // 0xfadc34: stur            d3, [fp, #-0x38]
    // 0xfadc38: r0 = Offset()
    //     0xfadc38: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xfadc3c: ldur            d0, [fp, #-0x48]
    // 0xfadc40: stur            x0, [fp, #-0x18]
    // 0xfadc44: StoreField: r0->field_7 = d0
    //     0xfadc44: stur            d0, [x0, #7]
    // 0xfadc48: ldur            d0, [fp, #-0x38]
    // 0xfadc4c: StoreField: r0->field_f = d0
    //     0xfadc4c: stur            d0, [x0, #0xf]
    // 0xfadc50: r0 = EdgeInsets()
    //     0xfadc50: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xfadc54: d0 = 8.000000
    //     0xfadc54: fmov            d0, #8.00000000
    // 0xfadc58: stur            x0, [fp, #-0x20]
    // 0xfadc5c: StoreField: r0->field_7 = d0
    //     0xfadc5c: stur            d0, [x0, #7]
    // 0xfadc60: ldur            d1, [fp, #-0x40]
    // 0xfadc64: StoreField: r0->field_f = d1
    //     0xfadc64: stur            d1, [x0, #0xf]
    // 0xfadc68: ArrayStore: r0[0] = d0  ; List_8
    //     0xfadc68: stur            d0, [x0, #0x17]
    // 0xfadc6c: StoreField: r0->field_1f = d0
    //     0xfadc6c: stur            d0, [x0, #0x1f]
    // 0xfadc70: r0 = TextSelectionToolbarLayoutDelegate()
    //     0xfadc70: bl              #0xfadd1c  ; AllocateTextSelectionToolbarLayoutDelegateStub -> TextSelectionToolbarLayoutDelegate (size=0x18)
    // 0xfadc74: mov             x1, x0
    // 0xfadc78: ldur            x0, [fp, #-0x10]
    // 0xfadc7c: stur            x1, [fp, #-0x30]
    // 0xfadc80: StoreField: r1->field_b = r0
    //     0xfadc80: stur            w0, [x1, #0xb]
    // 0xfadc84: ldur            x2, [fp, #-0x18]
    // 0xfadc88: StoreField: r1->field_f = r2
    //     0xfadc88: stur            w2, [x1, #0xf]
    // 0xfadc8c: ldur            x3, [fp, #-8]
    // 0xfadc90: LoadField: r4 = r3->field_13
    //     0xfadc90: ldur            w4, [x3, #0x13]
    // 0xfadc94: DecompressPointer r4
    //     0xfadc94: add             x4, x4, HEAP, lsl #32
    // 0xfadc98: stur            x4, [fp, #-0x28]
    // 0xfadc9c: r0 = _CupertinoTextSelectionToolbarContent()
    //     0xfadc9c: bl              #0xfadd10  ; Allocate_CupertinoTextSelectionToolbarContentStub -> _CupertinoTextSelectionToolbarContent (size=0x1c)
    // 0xfadca0: mov             x1, x0
    // 0xfadca4: ldur            x0, [fp, #-0x10]
    // 0xfadca8: stur            x1, [fp, #-8]
    // 0xfadcac: StoreField: r1->field_b = r0
    //     0xfadcac: stur            w0, [x1, #0xb]
    // 0xfadcb0: ldur            x0, [fp, #-0x18]
    // 0xfadcb4: StoreField: r1->field_f = r0
    //     0xfadcb4: stur            w0, [x1, #0xf]
    // 0xfadcb8: r0 = Closure: (BuildContext, Offset, Offset, Widget) => Widget from Function '_defaultToolbarBuilder@298408280': static.
    //     0xfadcb8: add             x0, PP, #0x80, lsl #12  ; [pp+0x809d8] Closure: (BuildContext, Offset, Offset, Widget) => Widget from Function '_defaultToolbarBuilder@298408280': static. (0x7f2adac5e5d0)
    //     0xfadcbc: ldr             x0, [x0, #0x9d8]
    // 0xfadcc0: ArrayStore: r1[0] = r0  ; List_4
    //     0xfadcc0: stur            w0, [x1, #0x17]
    // 0xfadcc4: ldur            x0, [fp, #-0x28]
    // 0xfadcc8: StoreField: r1->field_13 = r0
    //     0xfadcc8: stur            w0, [x1, #0x13]
    // 0xfadccc: r0 = CustomSingleChildLayout()
    //     0xfadccc: bl              #0xd70b7c  ; AllocateCustomSingleChildLayoutStub -> CustomSingleChildLayout (size=0x14)
    // 0xfadcd0: mov             x1, x0
    // 0xfadcd4: ldur            x0, [fp, #-0x30]
    // 0xfadcd8: stur            x1, [fp, #-0x10]
    // 0xfadcdc: StoreField: r1->field_f = r0
    //     0xfadcdc: stur            w0, [x1, #0xf]
    // 0xfadce0: ldur            x0, [fp, #-8]
    // 0xfadce4: StoreField: r1->field_b = r0
    //     0xfadce4: stur            w0, [x1, #0xb]
    // 0xfadce8: r0 = Padding()
    //     0xfadce8: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xfadcec: ldur            x1, [fp, #-0x20]
    // 0xfadcf0: StoreField: r0->field_f = r1
    //     0xfadcf0: stur            w1, [x0, #0xf]
    // 0xfadcf4: ldur            x1, [fp, #-0x10]
    // 0xfadcf8: StoreField: r0->field_b = r1
    //     0xfadcf8: stur            w1, [x0, #0xb]
    // 0xfadcfc: LeaveFrame
    //     0xfadcfc: mov             SP, fp
    //     0xfadd00: ldp             fp, lr, [SP], #0x10
    // 0xfadd04: ret
    //     0xfadd04: ret             
    // 0xfadd08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfadd08: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfadd0c: b               #0xfadb08
  }
}

// class id: 6508, size: 0x1c, field offset: 0xc
//   const constructor, 
class _CupertinoTextSelectionToolbarContent extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa098c, size: 0x50
    // 0xfa098c: EnterFrame
    //     0xfa098c: stp             fp, lr, [SP, #-0x10]!
    //     0xfa0990: mov             fp, SP
    // 0xfa0994: AllocStack(0x8)
    //     0xfa0994: sub             SP, SP, #8
    // 0xfa0998: SetupParameters(_CupertinoTextSelectionToolbarContent this /* r1 => r0 */)
    //     0xfa0998: mov             x0, x1
    // 0xfa099c: r1 = <_CupertinoTextSelectionToolbarContent>
    //     0xfa099c: add             x1, PP, #0x98, lsl #12  ; [pp+0x98718] TypeArguments: <_CupertinoTextSelectionToolbarContent>
    //     0xfa09a0: ldr             x1, [x1, #0x718]
    // 0xfa09a4: r0 = _CupertinoTextSelectionToolbarContentState()
    //     0xfa09a4: bl              #0xfa09dc  ; Allocate_CupertinoTextSelectionToolbarContentStateStub -> _CupertinoTextSelectionToolbarContentState (size=0x30)
    // 0xfa09a8: mov             x2, x0
    // 0xfa09ac: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa09b0: stur            x2, [fp, #-8]
    // 0xfa09b4: StoreField: r2->field_1b = r0
    //     0xfa09b4: stur            w0, [x2, #0x1b]
    // 0xfa09b8: StoreField: r2->field_23 = rZR
    //     0xfa09b8: stur            xzr, [x2, #0x23]
    // 0xfa09bc: r1 = <State<StatefulWidget>>
    //     0xfa09bc: ldr             x1, [PP, #0x4df8]  ; [pp+0x4df8] TypeArguments: <State<StatefulWidget>>
    // 0xfa09c0: r0 = LabeledGlobalKey()
    //     0xfa09c0: bl              #0x856cf8  ; AllocateLabeledGlobalKeyStub -> LabeledGlobalKey<X0 bound State> (size=0x10)
    // 0xfa09c4: mov             x1, x0
    // 0xfa09c8: ldur            x0, [fp, #-8]
    // 0xfa09cc: StoreField: r0->field_2b = r1
    //     0xfa09cc: stur            w1, [x0, #0x2b]
    // 0xfa09d0: LeaveFrame
    //     0xfa09d0: mov             SP, fp
    //     0xfa09d4: ldp             fp, lr, [SP], #0x10
    // 0xfa09d8: ret
    //     0xfa09d8: ret             
  }
}

// class id: 6563, size: 0x2c, field offset: 0xc
class _CupertinoTextSelectionToolbarItems extends RenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcfe524, size: 0xac
    // 0xcfe524: EnterFrame
    //     0xcfe524: stp             fp, lr, [SP, #-0x10]!
    //     0xcfe528: mov             fp, SP
    // 0xcfe52c: AllocStack(0x10)
    //     0xcfe52c: sub             SP, SP, #0x10
    // 0xcfe530: SetupParameters(_CupertinoTextSelectionToolbarItems this /* r1 => r4, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xcfe530: mov             x4, x1
    //     0xcfe534: stur            x1, [fp, #-8]
    //     0xcfe538: stur            x3, [fp, #-0x10]
    // 0xcfe53c: CheckStackOverflow
    //     0xcfe53c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcfe540: cmp             SP, x16
    //     0xcfe544: b.ls            #0xcfe5c8
    // 0xcfe548: mov             x0, x3
    // 0xcfe54c: r2 = Null
    //     0xcfe54c: mov             x2, NULL
    // 0xcfe550: r1 = Null
    //     0xcfe550: mov             x1, NULL
    // 0xcfe554: r4 = 60
    //     0xcfe554: mov             x4, #0x3c
    // 0xcfe558: branchIfSmi(r0, 0xcfe564)
    //     0xcfe558: tbz             w0, #0, #0xcfe564
    // 0xcfe55c: r4 = LoadClassIdInstr(r0)
    //     0xcfe55c: ldur            x4, [x0, #-1]
    //     0xcfe560: ubfx            x4, x4, #0xc, #0x14
    // 0xcfe564: r17 = 4843
    //     0xcfe564: mov             x17, #0x12eb
    // 0xcfe568: cmp             x4, x17
    // 0xcfe56c: b.eq            #0xcfe584
    // 0xcfe570: r8 = _RenderCupertinoTextSelectionToolbarItems
    //     0xcfe570: add             x8, PP, #0xac, lsl #12  ; [pp+0xacc30] Type: _RenderCupertinoTextSelectionToolbarItems
    //     0xcfe574: ldr             x8, [x8, #0xc30]
    // 0xcfe578: r3 = Null
    //     0xcfe578: add             x3, PP, #0xac, lsl #12  ; [pp+0xacc38] Null
    //     0xcfe57c: ldr             x3, [x3, #0xc38]
    // 0xcfe580: r0 = DefaultTypeTest()
    //     0xcfe580: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcfe584: ldur            x0, [fp, #-8]
    // 0xcfe588: LoadField: r2 = r0->field_23
    //     0xcfe588: ldur            x2, [x0, #0x23]
    // 0xcfe58c: ldur            x1, [fp, #-0x10]
    // 0xcfe590: r0 = page=()
    //     0xcfe590: bl              #0xcfe6a8  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarItems::page=
    // 0xcfe594: ldur            x0, [fp, #-8]
    // 0xcfe598: LoadField: r2 = r0->field_13
    //     0xcfe598: ldur            w2, [x0, #0x13]
    // 0xcfe59c: DecompressPointer r2
    //     0xcfe59c: add             x2, x2, HEAP, lsl #32
    // 0xcfe5a0: ldur            x1, [fp, #-0x10]
    // 0xcfe5a4: r0 = dividerColor=()
    //     0xcfe5a4: bl              #0xcfe620  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarItems::dividerColor=
    // 0xcfe5a8: ldur            x0, [fp, #-8]
    // 0xcfe5ac: ArrayLoad: d0 = r0[0]  ; List_8
    //     0xcfe5ac: ldur            d0, [x0, #0x17]
    // 0xcfe5b0: ldur            x1, [fp, #-0x10]
    // 0xcfe5b4: r0 = dividerWidth=()
    //     0xcfe5b4: bl              #0xcfe5d0  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarItems::dividerWidth=
    // 0xcfe5b8: r0 = Null
    //     0xcfe5b8: mov             x0, NULL
    // 0xcfe5bc: LeaveFrame
    //     0xcfe5bc: mov             SP, fp
    //     0xcfe5c0: ldp             fp, lr, [SP], #0x10
    // 0xcfe5c4: ret
    //     0xcfe5c4: ret             
    // 0xcfe5c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcfe5c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcfe5cc: b               #0xcfe548
  }
  _ createElement(/* No info */) {
    // ** addr: 0x10f2360, size: 0x4c
    // 0x10f2360: EnterFrame
    //     0x10f2360: stp             fp, lr, [SP, #-0x10]!
    //     0x10f2364: mov             fp, SP
    // 0x10f2368: AllocStack(0x8)
    //     0x10f2368: sub             SP, SP, #8
    // 0x10f236c: SetupParameters(_CupertinoTextSelectionToolbarItems this /* r1 => r2, fp-0x8 */)
    //     0x10f236c: mov             x2, x1
    //     0x10f2370: stur            x1, [fp, #-8]
    // 0x10f2374: CheckStackOverflow
    //     0x10f2374: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f2378: cmp             SP, x16
    //     0x10f237c: b.ls            #0x10f23a4
    // 0x10f2380: r0 = _CupertinoTextSelectionToolbarItemsElement()
    //     0x10f2380: bl              #0x10f24c0  ; Allocate_CupertinoTextSelectionToolbarItemsElementStub -> _CupertinoTextSelectionToolbarItemsElement (size=0x50)
    // 0x10f2384: mov             x1, x0
    // 0x10f2388: ldur            x2, [fp, #-8]
    // 0x10f238c: stur            x0, [fp, #-8]
    // 0x10f2390: r0 = _CupertinoTextSelectionToolbarItemsElement()
    //     0x10f2390: bl              #0x10f23ac  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _CupertinoTextSelectionToolbarItemsElement::_CupertinoTextSelectionToolbarItemsElement
    // 0x10f2394: ldur            x0, [fp, #-8]
    // 0x10f2398: LeaveFrame
    //     0x10f2398: mov             SP, fp
    //     0x10f239c: ldp             fp, lr, [SP], #0x10
    // 0x10f23a0: ret
    //     0x10f23a0: ret             
    // 0x10f23a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10f23a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10f23a8: b               #0x10f2380
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11d488c, size: 0x68
    // 0x11d488c: EnterFrame
    //     0x11d488c: stp             fp, lr, [SP, #-0x10]!
    //     0x11d4890: mov             fp, SP
    // 0x11d4894: AllocStack(0x18)
    //     0x11d4894: sub             SP, SP, #0x18
    // 0x11d4898: CheckStackOverflow
    //     0x11d4898: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d489c: cmp             SP, x16
    //     0x11d48a0: b.ls            #0x11d48ec
    // 0x11d48a4: LoadField: r2 = r1->field_13
    //     0x11d48a4: ldur            w2, [x1, #0x13]
    // 0x11d48a8: DecompressPointer r2
    //     0x11d48a8: add             x2, x2, HEAP, lsl #32
    // 0x11d48ac: stur            x2, [fp, #-0x10]
    // 0x11d48b0: ArrayLoad: d0 = r1[0]  ; List_8
    //     0x11d48b0: ldur            d0, [x1, #0x17]
    // 0x11d48b4: stur            d0, [fp, #-0x18]
    // 0x11d48b8: LoadField: r3 = r1->field_23
    //     0x11d48b8: ldur            x3, [x1, #0x23]
    // 0x11d48bc: stur            x3, [fp, #-8]
    // 0x11d48c0: r0 = _RenderCupertinoTextSelectionToolbarItems()
    //     0x11d48c0: bl              #0x11d49dc  ; Allocate_RenderCupertinoTextSelectionToolbarItemsStub -> _RenderCupertinoTextSelectionToolbarItems (size=0x88)
    // 0x11d48c4: mov             x1, x0
    // 0x11d48c8: ldur            x2, [fp, #-0x10]
    // 0x11d48cc: ldur            d0, [fp, #-0x18]
    // 0x11d48d0: ldur            x3, [fp, #-8]
    // 0x11d48d4: stur            x0, [fp, #-0x10]
    // 0x11d48d8: r0 = _RenderCupertinoTextSelectionToolbarItems()
    //     0x11d48d8: bl              #0x11d48f4  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarItems::_RenderCupertinoTextSelectionToolbarItems
    // 0x11d48dc: ldur            x0, [fp, #-0x10]
    // 0x11d48e0: LeaveFrame
    //     0x11d48e0: mov             SP, fp
    //     0x11d48e4: ldp             fp, lr, [SP], #0x10
    // 0x11d48e8: ret
    //     0x11d48e8: ret             
    // 0x11d48ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d48ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d48f0: b               #0x11d48a4
  }
}

// class id: 6659, size: 0x1c, field offset: 0x10
//   const constructor, 
class _CupertinoTextSelectionToolbarShape extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf42b4, size: 0xb4
    // 0xcf42b4: EnterFrame
    //     0xcf42b4: stp             fp, lr, [SP, #-0x10]!
    //     0xcf42b8: mov             fp, SP
    // 0xcf42bc: AllocStack(0x10)
    //     0xcf42bc: sub             SP, SP, #0x10
    // 0xcf42c0: SetupParameters(_CupertinoTextSelectionToolbarShape this /* r1 => r4, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xcf42c0: mov             x4, x1
    //     0xcf42c4: stur            x1, [fp, #-8]
    //     0xcf42c8: stur            x3, [fp, #-0x10]
    // 0xcf42cc: CheckStackOverflow
    //     0xcf42cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf42d0: cmp             SP, x16
    //     0xcf42d4: b.ls            #0xcf4360
    // 0xcf42d8: mov             x0, x3
    // 0xcf42dc: r2 = Null
    //     0xcf42dc: mov             x2, NULL
    // 0xcf42e0: r1 = Null
    //     0xcf42e0: mov             x1, NULL
    // 0xcf42e4: r4 = 60
    //     0xcf42e4: mov             x4, #0x3c
    // 0xcf42e8: branchIfSmi(r0, 0xcf42f4)
    //     0xcf42e8: tbz             w0, #0, #0xcf42f4
    // 0xcf42ec: r4 = LoadClassIdInstr(r0)
    //     0xcf42ec: ldur            x4, [x0, #-1]
    //     0xcf42f0: ubfx            x4, x4, #0xc, #0x14
    // 0xcf42f4: r17 = 4882
    //     0xcf42f4: mov             x17, #0x1312
    // 0xcf42f8: cmp             x4, x17
    // 0xcf42fc: b.eq            #0xcf4314
    // 0xcf4300: r8 = _RenderCupertinoTextSelectionToolbarShape
    //     0xcf4300: add             x8, PP, #0x8e, lsl #12  ; [pp+0x8e718] Type: _RenderCupertinoTextSelectionToolbarShape
    //     0xcf4304: ldr             x8, [x8, #0x718]
    // 0xcf4308: r3 = Null
    //     0xcf4308: add             x3, PP, #0x8e, lsl #12  ; [pp+0x8e720] Null
    //     0xcf430c: ldr             x3, [x3, #0x720]
    // 0xcf4310: r0 = DefaultTypeTest()
    //     0xcf4310: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf4314: ldur            x0, [fp, #-8]
    // 0xcf4318: LoadField: r2 = r0->field_f
    //     0xcf4318: ldur            w2, [x0, #0xf]
    // 0xcf431c: DecompressPointer r2
    //     0xcf431c: add             x2, x2, HEAP, lsl #32
    // 0xcf4320: ldur            x1, [fp, #-0x10]
    // 0xcf4324: r0 = anchorAbove=()
    //     0xcf4324: bl              #0xcf4494  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarShape::anchorAbove=
    // 0xcf4328: ldur            x0, [fp, #-8]
    // 0xcf432c: LoadField: r2 = r0->field_13
    //     0xcf432c: ldur            w2, [x0, #0x13]
    // 0xcf4330: DecompressPointer r2
    //     0xcf4330: add             x2, x2, HEAP, lsl #32
    // 0xcf4334: ldur            x1, [fp, #-0x10]
    // 0xcf4338: r0 = anchorBelow=()
    //     0xcf4338: bl              #0xcf440c  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarShape::anchorBelow=
    // 0xcf433c: ldur            x0, [fp, #-8]
    // 0xcf4340: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xcf4340: ldur            w2, [x0, #0x17]
    // 0xcf4344: DecompressPointer r2
    //     0xcf4344: add             x2, x2, HEAP, lsl #32
    // 0xcf4348: ldur            x1, [fp, #-0x10]
    // 0xcf434c: r0 = shadowColor=()
    //     0xcf434c: bl              #0xcf4368  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarShape::shadowColor=
    // 0xcf4350: r0 = Null
    //     0xcf4350: mov             x0, NULL
    // 0xcf4354: LeaveFrame
    //     0xcf4354: mov             SP, fp
    //     0xcf4358: ldp             fp, lr, [SP], #0x10
    // 0xcf435c: ret
    //     0xcf435c: ret             
    // 0xcf4360: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf4360: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf4364: b               #0xcf42d8
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11cf4d4, size: 0x70
    // 0x11cf4d4: EnterFrame
    //     0x11cf4d4: stp             fp, lr, [SP, #-0x10]!
    //     0x11cf4d8: mov             fp, SP
    // 0x11cf4dc: AllocStack(0x18)
    //     0x11cf4dc: sub             SP, SP, #0x18
    // 0x11cf4e0: CheckStackOverflow
    //     0x11cf4e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11cf4e4: cmp             SP, x16
    //     0x11cf4e8: b.ls            #0x11cf53c
    // 0x11cf4ec: LoadField: r2 = r1->field_f
    //     0x11cf4ec: ldur            w2, [x1, #0xf]
    // 0x11cf4f0: DecompressPointer r2
    //     0x11cf4f0: add             x2, x2, HEAP, lsl #32
    // 0x11cf4f4: stur            x2, [fp, #-0x18]
    // 0x11cf4f8: LoadField: r3 = r1->field_13
    //     0x11cf4f8: ldur            w3, [x1, #0x13]
    // 0x11cf4fc: DecompressPointer r3
    //     0x11cf4fc: add             x3, x3, HEAP, lsl #32
    // 0x11cf500: stur            x3, [fp, #-0x10]
    // 0x11cf504: ArrayLoad: r5 = r1[0]  ; List_4
    //     0x11cf504: ldur            w5, [x1, #0x17]
    // 0x11cf508: DecompressPointer r5
    //     0x11cf508: add             x5, x5, HEAP, lsl #32
    // 0x11cf50c: stur            x5, [fp, #-8]
    // 0x11cf510: r0 = _RenderCupertinoTextSelectionToolbarShape()
    //     0x11cf510: bl              #0x11cf65c  ; Allocate_RenderCupertinoTextSelectionToolbarShapeStub -> _RenderCupertinoTextSelectionToolbarShape (size=0x64)
    // 0x11cf514: mov             x1, x0
    // 0x11cf518: ldur            x2, [fp, #-0x18]
    // 0x11cf51c: ldur            x3, [fp, #-0x10]
    // 0x11cf520: ldur            x5, [fp, #-8]
    // 0x11cf524: stur            x0, [fp, #-8]
    // 0x11cf528: r0 = _RenderCupertinoTextSelectionToolbarShape()
    //     0x11cf528: bl              #0x11cf544  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarShape::_RenderCupertinoTextSelectionToolbarShape
    // 0x11cf52c: ldur            x0, [fp, #-8]
    // 0x11cf530: LeaveFrame
    //     0x11cf530: mov             SP, fp
    //     0x11cf534: ldp             fp, lr, [SP], #0x10
    // 0x11cf538: ret
    //     0x11cf538: ret             
    // 0x11cf53c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11cf53c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11cf540: b               #0x11cf4ec
  }
}

// class id: 8317, size: 0x14, field offset: 0x14
enum _CupertinoTextSelectionToolbarItemsSlot extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11a9798, size: 0x64
    // 0x11a9798: EnterFrame
    //     0x11a9798: stp             fp, lr, [SP, #-0x10]!
    //     0x11a979c: mov             fp, SP
    // 0x11a97a0: AllocStack(0x10)
    //     0x11a97a0: sub             SP, SP, #0x10
    // 0x11a97a4: SetupParameters(_CupertinoTextSelectionToolbarItemsSlot this /* r1 => r0, fp-0x8 */)
    //     0x11a97a4: mov             x0, x1
    //     0x11a97a8: stur            x1, [fp, #-8]
    // 0x11a97ac: CheckStackOverflow
    //     0x11a97ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a97b0: cmp             SP, x16
    //     0x11a97b4: b.ls            #0x11a97f4
    // 0x11a97b8: r1 = Null
    //     0x11a97b8: mov             x1, NULL
    // 0x11a97bc: r2 = 4
    //     0x11a97bc: mov             x2, #4
    // 0x11a97c0: r0 = AllocateArray()
    //     0x11a97c0: bl              #0x13df928  ; AllocateArrayStub
    // 0x11a97c4: r16 = "_CupertinoTextSelectionToolbarItemsSlot."
    //     0x11a97c4: add             x16, PP, #0xd0, lsl #12  ; [pp+0xd00d8] "_CupertinoTextSelectionToolbarItemsSlot."
    //     0x11a97c8: ldr             x16, [x16, #0xd8]
    // 0x11a97cc: StoreField: r0->field_f = r16
    //     0x11a97cc: stur            w16, [x0, #0xf]
    // 0x11a97d0: ldur            x1, [fp, #-8]
    // 0x11a97d4: LoadField: r2 = r1->field_f
    //     0x11a97d4: ldur            w2, [x1, #0xf]
    // 0x11a97d8: DecompressPointer r2
    //     0x11a97d8: add             x2, x2, HEAP, lsl #32
    // 0x11a97dc: StoreField: r0->field_13 = r2
    //     0x11a97dc: stur            w2, [x0, #0x13]
    // 0x11a97e0: str             x0, [SP]
    // 0x11a97e4: r0 = _interpolate()
    //     0x11a97e4: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11a97e8: LeaveFrame
    //     0x11a97e8: mov             SP, fp
    //     0x11a97ec: ldp             fp, lr, [SP], #0x10
    // 0x11a97f0: ret
    //     0x11a97f0: ret             
    // 0x11a97f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a97f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a97f8: b               #0x11a97b8
  }
}
