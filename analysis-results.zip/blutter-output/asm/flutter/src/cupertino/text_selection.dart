// lib: , url: package:flutter/src/cupertino/text_selection.dart

// class id: 1048786, size: 0x8
class :: {

  static late final TextSelectionControls cupertinoTextSelectionHandleControls; // offset: 0x9bc

  static TextSelectionControls cupertinoTextSelectionHandleControls() {
    // ** addr: 0xd4a71c, size: 0x18
    // 0xd4a71c: EnterFrame
    //     0xd4a71c: stp             fp, lr, [SP, #-0x10]!
    //     0xd4a720: mov             fp, SP
    // 0xd4a724: r0 = CupertinoTextSelectionHandleControls()
    //     0xd4a724: bl              #0xd4a734  ; AllocateCupertinoTextSelectionHandleControlsStub -> CupertinoTextSelectionHandleControls (size=0x8)
    // 0xd4a728: LeaveFrame
    //     0xd4a728: mov             SP, fp
    //     0xd4a72c: ldp             fp, lr, [SP], #0x10
    // 0xd4a730: ret
    //     0xd4a730: ret             
  }
}

// class id: 3278, size: 0x8, field offset: 0x8
abstract class CupertinoTextSelectionControls extends TextSelectionControls {

  _ buildHandle(/* No info */) {
    // ** addr: 0x12e3f6c, size: 0x3c4
    // 0x12e3f6c: EnterFrame
    //     0x12e3f6c: stp             fp, lr, [SP, #-0x10]!
    //     0x12e3f70: mov             fp, SP
    // 0x12e3f74: AllocStack(0x40)
    //     0x12e3f74: sub             SP, SP, #0x40
    // 0x12e3f78: SetupParameters(CupertinoTextSelectionControls this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1 */, dynamic _ /* r3 => r3, fp-0x10 */, dynamic _ /* d0 => d0, fp-0x30 */)
    //     0x12e3f78: mov             x0, x1
    //     0x12e3f7c: stur            x1, [fp, #-8]
    //     0x12e3f80: mov             x1, x2
    //     0x12e3f84: stur            x3, [fp, #-0x10]
    //     0x12e3f88: stur            d0, [fp, #-0x30]
    // 0x12e3f8c: CheckStackOverflow
    //     0x12e3f8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e3f90: cmp             SP, x16
    //     0x12e3f94: b.ls            #0x12e4288
    // 0x12e3f98: r0 = of()
    //     0x12e3f98: bl              #0xccc364  ; [package:flutter/src/cupertino/theme.dart] CupertinoTheme::of
    // 0x12e3f9c: LoadField: r1 = r0->field_27
    //     0x12e3f9c: ldur            w1, [x0, #0x27]
    // 0x12e3fa0: DecompressPointer r1
    //     0x12e3fa0: add             x1, x1, HEAP, lsl #32
    // 0x12e3fa4: LoadField: r0 = r1->field_1b
    //     0x12e3fa4: ldur            w0, [x1, #0x1b]
    // 0x12e3fa8: DecompressPointer r0
    //     0x12e3fa8: add             x0, x0, HEAP, lsl #32
    // 0x12e3fac: stur            x0, [fp, #-0x18]
    // 0x12e3fb0: r0 = _CupertinoTextSelectionHandlePainter()
    //     0x12e3fb0: bl              #0x12e4330  ; Allocate_CupertinoTextSelectionHandlePainterStub -> _CupertinoTextSelectionHandlePainter (size=0x10)
    // 0x12e3fb4: mov             x1, x0
    // 0x12e3fb8: ldur            x0, [fp, #-0x18]
    // 0x12e3fbc: stur            x1, [fp, #-0x20]
    // 0x12e3fc0: StoreField: r1->field_b = r0
    //     0x12e3fc0: stur            w0, [x1, #0xb]
    // 0x12e3fc4: r0 = CustomPaint()
    //     0x12e3fc4: bl              #0xd0a594  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0x12e3fc8: mov             x2, x0
    // 0x12e3fcc: ldur            x0, [fp, #-0x20]
    // 0x12e3fd0: stur            x2, [fp, #-0x18]
    // 0x12e3fd4: StoreField: r2->field_f = r0
    //     0x12e3fd4: stur            w0, [x2, #0xf]
    // 0x12e3fd8: r0 = Instance_Size
    //     0x12e3fd8: ldr             x0, [PP, #0x7f28]  ; [pp+0x7f28] Obj!Size@12a74d1
    // 0x12e3fdc: ArrayStore: r2[0] = r0  ; List_4
    //     0x12e3fdc: stur            w0, [x2, #0x17]
    // 0x12e3fe0: r0 = false
    //     0x12e3fe0: add             x0, NULL, #0x30  ; false
    // 0x12e3fe4: StoreField: r2->field_1b = r0
    //     0x12e3fe4: stur            w0, [x2, #0x1b]
    // 0x12e3fe8: StoreField: r2->field_1f = r0
    //     0x12e3fe8: stur            w0, [x2, #0x1f]
    // 0x12e3fec: ldur            x0, [fp, #-0x10]
    // 0x12e3ff0: LoadField: r1 = r0->field_7
    //     0x12e3ff0: ldur            x1, [x0, #7]
    // 0x12e3ff4: cmp             x1, #1
    // 0x12e3ff8: b.gt            #0x12e41f4
    // 0x12e3ffc: cmp             x1, #0
    // 0x12e4000: b.gt            #0x12e40a8
    // 0x12e4004: ldur            x1, [fp, #-8]
    // 0x12e4008: ldur            d0, [fp, #-0x30]
    // 0x12e400c: r0 = getHandleSize()
    //     0x12e400c: bl              #0x12f57e8  ; [package:flutter/src/cupertino/text_selection.dart] CupertinoTextSelectionControls::getHandleSize
    // 0x12e4010: stur            x0, [fp, #-0x20]
    // 0x12e4014: LoadField: d0 = r0->field_7
    //     0x12e4014: ldur            d0, [x0, #7]
    // 0x12e4018: r1 = inline_Allocate_Double()
    //     0x12e4018: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x12e401c: add             x1, x1, #0x10
    //     0x12e4020: cmp             x2, x1
    //     0x12e4024: b.ls            #0x12e4290
    //     0x12e4028: str             x1, [THR, #0x60]  ; THR::top
    //     0x12e402c: sub             x1, x1, #0xf
    //     0x12e4030: mov             x2, #0xe19c
    //     0x12e4034: movk            x2, #3, lsl #16
    //     0x12e4038: stur            x2, [x1, #-1]
    // 0x12e403c: dmb             ishst
    // 0x12e4040: StoreField: r1->field_7 = d0
    //     0x12e4040: stur            d0, [x1, #7]
    // 0x12e4044: stur            x1, [fp, #-0x10]
    // 0x12e4048: r0 = SizedBox()
    //     0x12e4048: bl              #0x8a7210  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x12e404c: mov             x1, x0
    // 0x12e4050: ldur            x0, [fp, #-0x10]
    // 0x12e4054: StoreField: r1->field_f = r0
    //     0x12e4054: stur            w0, [x1, #0xf]
    // 0x12e4058: ldur            x0, [fp, #-0x20]
    // 0x12e405c: LoadField: d0 = r0->field_f
    //     0x12e405c: ldur            d0, [x0, #0xf]
    // 0x12e4060: r0 = inline_Allocate_Double()
    //     0x12e4060: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x12e4064: add             x0, x0, #0x10
    //     0x12e4068: cmp             x2, x0
    //     0x12e406c: b.ls            #0x12e42ac
    //     0x12e4070: str             x0, [THR, #0x60]  ; THR::top
    //     0x12e4074: sub             x0, x0, #0xf
    //     0x12e4078: mov             x2, #0xe19c
    //     0x12e407c: movk            x2, #3, lsl #16
    //     0x12e4080: stur            x2, [x0, #-1]
    // 0x12e4084: dmb             ishst
    // 0x12e4088: StoreField: r0->field_7 = d0
    //     0x12e4088: stur            d0, [x0, #7]
    // 0x12e408c: StoreField: r1->field_13 = r0
    //     0x12e408c: stur            w0, [x1, #0x13]
    // 0x12e4090: ldur            x0, [fp, #-0x18]
    // 0x12e4094: StoreField: r1->field_b = r0
    //     0x12e4094: stur            w0, [x1, #0xb]
    // 0x12e4098: mov             x0, x1
    // 0x12e409c: LeaveFrame
    //     0x12e409c: mov             SP, fp
    //     0x12e40a0: ldp             fp, lr, [SP], #0x10
    // 0x12e40a4: ret
    //     0x12e40a4: ret             
    // 0x12e40a8: mov             x0, x2
    // 0x12e40ac: ldur            x1, [fp, #-8]
    // 0x12e40b0: ldur            d0, [fp, #-0x30]
    // 0x12e40b4: r0 = getHandleSize()
    //     0x12e40b4: bl              #0x12f57e8  ; [package:flutter/src/cupertino/text_selection.dart] CupertinoTextSelectionControls::getHandleSize
    // 0x12e40b8: stur            x0, [fp, #-0x20]
    // 0x12e40bc: LoadField: d0 = r0->field_7
    //     0x12e40bc: ldur            d0, [x0, #7]
    // 0x12e40c0: stur            d0, [fp, #-0x38]
    // 0x12e40c4: r1 = inline_Allocate_Double()
    //     0x12e40c4: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x12e40c8: add             x1, x1, #0x10
    //     0x12e40cc: cmp             x2, x1
    //     0x12e40d0: b.ls            #0x12e42c4
    //     0x12e40d4: str             x1, [THR, #0x60]  ; THR::top
    //     0x12e40d8: sub             x1, x1, #0xf
    //     0x12e40dc: mov             x2, #0xe19c
    //     0x12e40e0: movk            x2, #3, lsl #16
    //     0x12e40e4: stur            x2, [x1, #-1]
    // 0x12e40e8: dmb             ishst
    // 0x12e40ec: StoreField: r1->field_7 = d0
    //     0x12e40ec: stur            d0, [x1, #7]
    // 0x12e40f0: stur            x1, [fp, #-0x10]
    // 0x12e40f4: r0 = SizedBox()
    //     0x12e40f4: bl              #0x8a7210  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x12e40f8: mov             x1, x0
    // 0x12e40fc: ldur            x0, [fp, #-0x10]
    // 0x12e4100: stur            x1, [fp, #-0x28]
    // 0x12e4104: StoreField: r1->field_f = r0
    //     0x12e4104: stur            w0, [x1, #0xf]
    // 0x12e4108: ldur            x0, [fp, #-0x20]
    // 0x12e410c: LoadField: d0 = r0->field_f
    //     0x12e410c: ldur            d0, [x0, #0xf]
    // 0x12e4110: stur            d0, [fp, #-0x40]
    // 0x12e4114: r0 = inline_Allocate_Double()
    //     0x12e4114: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x12e4118: add             x0, x0, #0x10
    //     0x12e411c: cmp             x2, x0
    //     0x12e4120: b.ls            #0x12e42e0
    //     0x12e4124: str             x0, [THR, #0x60]  ; THR::top
    //     0x12e4128: sub             x0, x0, #0xf
    //     0x12e412c: mov             x2, #0xe19c
    //     0x12e4130: movk            x2, #3, lsl #16
    //     0x12e4134: stur            x2, [x0, #-1]
    // 0x12e4138: dmb             ishst
    // 0x12e413c: StoreField: r0->field_7 = d0
    //     0x12e413c: stur            d0, [x0, #7]
    // 0x12e4140: StoreField: r1->field_13 = r0
    //     0x12e4140: stur            w0, [x1, #0x13]
    // 0x12e4144: ldur            x0, [fp, #-0x18]
    // 0x12e4148: StoreField: r1->field_b = r0
    //     0x12e4148: stur            w0, [x1, #0xb]
    // 0x12e414c: r0 = Matrix4()
    //     0x12e414c: bl              #0x832c64  ; AllocateMatrix4Stub -> Matrix4 (size=0xc)
    // 0x12e4150: r4 = 32
    //     0x12e4150: mov             x4, #0x20
    // 0x12e4154: stur            x0, [fp, #-0x10]
    // 0x12e4158: r0 = AllocateFloat64Array()
    //     0x12e4158: bl              #0x13def28  ; AllocateFloat64ArrayStub
    // 0x12e415c: mov             x1, x0
    // 0x12e4160: ldur            x0, [fp, #-0x10]
    // 0x12e4164: StoreField: r0->field_7 = r1
    //     0x12e4164: stur            w1, [x0, #7]
    // 0x12e4168: mov             x1, x0
    // 0x12e416c: r0 = setIdentity()
    //     0x12e416c: bl              #0x836d10  ; [package:vector_math/vector_math_64.dart] Matrix4::setIdentity
    // 0x12e4170: ldur            d2, [fp, #-0x38]
    // 0x12e4174: d3 = 2.000000
    //     0x12e4174: fmov            d3, #2.00000000
    // 0x12e4178: fdiv            d0, d2, d3
    // 0x12e417c: ldur            d4, [fp, #-0x40]
    // 0x12e4180: fdiv            d1, d4, d3
    // 0x12e4184: ldur            x1, [fp, #-0x10]
    // 0x12e4188: r0 = translateByDouble()
    //     0x12e4188: bl              #0xbbded8  ; [package:vector_math/vector_math_64.dart] Matrix4::translateByDouble
    // 0x12e418c: ldur            x1, [fp, #-0x10]
    // 0x12e4190: d0 = 3.141593
    //     0x12e4190: add             x17, PP, #0x13, lsl #12  ; [pp+0x13178] IMM: double(3.141592653589793) from 0x400921fb54442d18
    //     0x12e4194: ldr             d0, [x17, #0x178]
    // 0x12e4198: r0 = rotateZ()
    //     0x12e4198: bl              #0xb75838  ; [package:vector_math/vector_math_64.dart] Matrix4::rotateZ
    // 0x12e419c: ldur            d0, [fp, #-0x38]
    // 0x12e41a0: fneg            d1, d0
    // 0x12e41a4: d0 = 2.000000
    //     0x12e41a4: fmov            d0, #2.00000000
    // 0x12e41a8: fdiv            d2, d1, d0
    // 0x12e41ac: ldur            d1, [fp, #-0x40]
    // 0x12e41b0: fneg            d3, d1
    // 0x12e41b4: fdiv            d1, d3, d0
    // 0x12e41b8: ldur            x1, [fp, #-0x10]
    // 0x12e41bc: mov             v0.16b, v2.16b
    // 0x12e41c0: r0 = translateByDouble()
    //     0x12e41c0: bl              #0xbbded8  ; [package:vector_math/vector_math_64.dart] Matrix4::translateByDouble
    // 0x12e41c4: r0 = Transform()
    //     0x12e41c4: bl              #0xd30150  ; AllocateTransformStub -> Transform (size=0x24)
    // 0x12e41c8: mov             x1, x0
    // 0x12e41cc: ldur            x0, [fp, #-0x10]
    // 0x12e41d0: StoreField: r1->field_f = r0
    //     0x12e41d0: stur            w0, [x1, #0xf]
    // 0x12e41d4: r0 = true
    //     0x12e41d4: add             x0, NULL, #0x20  ; true
    // 0x12e41d8: StoreField: r1->field_1b = r0
    //     0x12e41d8: stur            w0, [x1, #0x1b]
    // 0x12e41dc: ldur            x0, [fp, #-0x28]
    // 0x12e41e0: StoreField: r1->field_b = r0
    //     0x12e41e0: stur            w0, [x1, #0xb]
    // 0x12e41e4: mov             x0, x1
    // 0x12e41e8: LeaveFrame
    //     0x12e41e8: mov             SP, fp
    //     0x12e41ec: ldp             fp, lr, [SP], #0x10
    // 0x12e41f0: ret
    //     0x12e41f0: ret             
    // 0x12e41f4: ldur            x1, [fp, #-8]
    // 0x12e41f8: ldur            d0, [fp, #-0x30]
    // 0x12e41fc: r0 = getHandleSize()
    //     0x12e41fc: bl              #0x12f57e8  ; [package:flutter/src/cupertino/text_selection.dart] CupertinoTextSelectionControls::getHandleSize
    // 0x12e4200: stur            x0, [fp, #-0x10]
    // 0x12e4204: LoadField: d0 = r0->field_7
    //     0x12e4204: ldur            d0, [x0, #7]
    // 0x12e4208: r1 = inline_Allocate_Double()
    //     0x12e4208: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x12e420c: add             x1, x1, #0x10
    //     0x12e4210: cmp             x2, x1
    //     0x12e4214: b.ls            #0x12e42f8
    //     0x12e4218: str             x1, [THR, #0x60]  ; THR::top
    //     0x12e421c: sub             x1, x1, #0xf
    //     0x12e4220: mov             x2, #0xe19c
    //     0x12e4224: movk            x2, #3, lsl #16
    //     0x12e4228: stur            x2, [x1, #-1]
    // 0x12e422c: dmb             ishst
    // 0x12e4230: StoreField: r1->field_7 = d0
    //     0x12e4230: stur            d0, [x1, #7]
    // 0x12e4234: stur            x1, [fp, #-8]
    // 0x12e4238: r0 = SizedBox()
    //     0x12e4238: bl              #0x8a7210  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x12e423c: ldur            x1, [fp, #-8]
    // 0x12e4240: StoreField: r0->field_f = r1
    //     0x12e4240: stur            w1, [x0, #0xf]
    // 0x12e4244: ldur            x1, [fp, #-0x10]
    // 0x12e4248: LoadField: d0 = r1->field_f
    //     0x12e4248: ldur            d0, [x1, #0xf]
    // 0x12e424c: r1 = inline_Allocate_Double()
    //     0x12e424c: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x12e4250: add             x1, x1, #0x10
    //     0x12e4254: cmp             x2, x1
    //     0x12e4258: b.ls            #0x12e4314
    //     0x12e425c: str             x1, [THR, #0x60]  ; THR::top
    //     0x12e4260: sub             x1, x1, #0xf
    //     0x12e4264: mov             x2, #0xe19c
    //     0x12e4268: movk            x2, #3, lsl #16
    //     0x12e426c: stur            x2, [x1, #-1]
    // 0x12e4270: dmb             ishst
    // 0x12e4274: StoreField: r1->field_7 = d0
    //     0x12e4274: stur            d0, [x1, #7]
    // 0x12e4278: StoreField: r0->field_13 = r1
    //     0x12e4278: stur            w1, [x0, #0x13]
    // 0x12e427c: LeaveFrame
    //     0x12e427c: mov             SP, fp
    //     0x12e4280: ldp             fp, lr, [SP], #0x10
    // 0x12e4284: ret
    //     0x12e4284: ret             
    // 0x12e4288: r0 = StackOverflowSharedWithFPURegs()
    //     0x12e4288: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12e428c: b               #0x12e3f98
    // 0x12e4290: SaveReg d0
    //     0x12e4290: str             q0, [SP, #-0x10]!
    // 0x12e4294: SaveReg r0
    //     0x12e4294: str             x0, [SP, #-8]!
    // 0x12e4298: r0 = AllocateDouble()
    //     0x12e4298: bl              #0x13df878  ; AllocateDoubleStub
    // 0x12e429c: mov             x1, x0
    // 0x12e42a0: RestoreReg r0
    //     0x12e42a0: ldr             x0, [SP], #8
    // 0x12e42a4: RestoreReg d0
    //     0x12e42a4: ldr             q0, [SP], #0x10
    // 0x12e42a8: b               #0x12e4040
    // 0x12e42ac: SaveReg d0
    //     0x12e42ac: str             q0, [SP, #-0x10]!
    // 0x12e42b0: SaveReg r1
    //     0x12e42b0: str             x1, [SP, #-8]!
    // 0x12e42b4: r0 = AllocateDouble()
    //     0x12e42b4: bl              #0x13df878  ; AllocateDoubleStub
    // 0x12e42b8: RestoreReg r1
    //     0x12e42b8: ldr             x1, [SP], #8
    // 0x12e42bc: RestoreReg d0
    //     0x12e42bc: ldr             q0, [SP], #0x10
    // 0x12e42c0: b               #0x12e4088
    // 0x12e42c4: SaveReg d0
    //     0x12e42c4: str             q0, [SP, #-0x10]!
    // 0x12e42c8: SaveReg r0
    //     0x12e42c8: str             x0, [SP, #-8]!
    // 0x12e42cc: r0 = AllocateDouble()
    //     0x12e42cc: bl              #0x13df878  ; AllocateDoubleStub
    // 0x12e42d0: mov             x1, x0
    // 0x12e42d4: RestoreReg r0
    //     0x12e42d4: ldr             x0, [SP], #8
    // 0x12e42d8: RestoreReg d0
    //     0x12e42d8: ldr             q0, [SP], #0x10
    // 0x12e42dc: b               #0x12e40ec
    // 0x12e42e0: SaveReg d0
    //     0x12e42e0: str             q0, [SP, #-0x10]!
    // 0x12e42e4: SaveReg r1
    //     0x12e42e4: str             x1, [SP, #-8]!
    // 0x12e42e8: r0 = AllocateDouble()
    //     0x12e42e8: bl              #0x13df878  ; AllocateDoubleStub
    // 0x12e42ec: RestoreReg r1
    //     0x12e42ec: ldr             x1, [SP], #8
    // 0x12e42f0: RestoreReg d0
    //     0x12e42f0: ldr             q0, [SP], #0x10
    // 0x12e42f4: b               #0x12e413c
    // 0x12e42f8: SaveReg d0
    //     0x12e42f8: str             q0, [SP, #-0x10]!
    // 0x12e42fc: SaveReg r0
    //     0x12e42fc: str             x0, [SP, #-8]!
    // 0x12e4300: r0 = AllocateDouble()
    //     0x12e4300: bl              #0x13df878  ; AllocateDoubleStub
    // 0x12e4304: mov             x1, x0
    // 0x12e4308: RestoreReg r0
    //     0x12e4308: ldr             x0, [SP], #8
    // 0x12e430c: RestoreReg d0
    //     0x12e430c: ldr             q0, [SP], #0x10
    // 0x12e4310: b               #0x12e4230
    // 0x12e4314: SaveReg d0
    //     0x12e4314: str             q0, [SP, #-0x10]!
    // 0x12e4318: SaveReg r0
    //     0x12e4318: str             x0, [SP, #-8]!
    // 0x12e431c: r0 = AllocateDouble()
    //     0x12e431c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x12e4320: mov             x1, x0
    // 0x12e4324: RestoreReg r0
    //     0x12e4324: ldr             x0, [SP], #8
    // 0x12e4328: RestoreReg d0
    //     0x12e4328: ldr             q0, [SP], #0x10
    // 0x12e432c: b               #0x12e4274
  }
  _ getHandleSize(/* No info */) {
    // ** addr: 0x12f57e8, size: 0x40
    // 0x12f57e8: EnterFrame
    //     0x12f57e8: stp             fp, lr, [SP, #-0x10]!
    //     0x12f57ec: mov             fp, SP
    // 0x12f57f0: AllocStack(0x8)
    //     0x12f57f0: sub             SP, SP, #8
    // 0x12f57f4: d2 = 12.000000
    //     0x12f57f4: fmov            d2, #12.00000000
    // 0x12f57f8: d1 = 1.500000
    //     0x12f57f8: fmov            d1, #1.50000000
    // 0x12f57fc: fadd            d3, d0, d2
    // 0x12f5800: fsub            d0, d3, d1
    // 0x12f5804: stur            d0, [fp, #-8]
    // 0x12f5808: r0 = Size()
    //     0x12f5808: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x12f580c: d0 = 12.000000
    //     0x12f580c: fmov            d0, #12.00000000
    // 0x12f5810: StoreField: r0->field_7 = d0
    //     0x12f5810: stur            d0, [x0, #7]
    // 0x12f5814: ldur            d0, [fp, #-8]
    // 0x12f5818: StoreField: r0->field_f = d0
    //     0x12f5818: stur            d0, [x0, #0xf]
    // 0x12f581c: LeaveFrame
    //     0x12f581c: mov             SP, fp
    //     0x12f5820: ldp             fp, lr, [SP], #0x10
    // 0x12f5824: ret
    //     0x12f5824: ret             
  }
  _ getHandleAnchor(/* No info */) {
    // ** addr: 0x12f5828, size: 0x118
    // 0x12f5828: EnterFrame
    //     0x12f5828: stp             fp, lr, [SP, #-0x10]!
    //     0x12f582c: mov             fp, SP
    // 0x12f5830: AllocStack(0x20)
    //     0x12f5830: sub             SP, SP, #0x20
    // 0x12f5834: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* d0 => d1, fp-0x10 */)
    //     0x12f5834: mov             v1.16b, v0.16b
    //     0x12f5838: stur            x2, [fp, #-8]
    //     0x12f583c: stur            d0, [fp, #-0x10]
    // 0x12f5840: CheckStackOverflow
    //     0x12f5840: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f5844: cmp             SP, x16
    //     0x12f5848: b.ls            #0x12f5938
    // 0x12f584c: mov             v0.16b, v1.16b
    // 0x12f5850: r0 = getHandleSize()
    //     0x12f5850: bl              #0x12f57e8  ; [package:flutter/src/cupertino/text_selection.dart] CupertinoTextSelectionControls::getHandleSize
    // 0x12f5854: mov             x1, x0
    // 0x12f5858: ldur            x0, [fp, #-8]
    // 0x12f585c: LoadField: r2 = r0->field_7
    //     0x12f585c: ldur            x2, [x0, #7]
    // 0x12f5860: cmp             x2, #1
    // 0x12f5864: b.gt            #0x12f58f0
    // 0x12f5868: cmp             x2, #0
    // 0x12f586c: b.gt            #0x12f58a8
    // 0x12f5870: d0 = 2.000000
    //     0x12f5870: fmov            d0, #2.00000000
    // 0x12f5874: LoadField: d1 = r1->field_7
    //     0x12f5874: ldur            d1, [x1, #7]
    // 0x12f5878: fdiv            d2, d1, d0
    // 0x12f587c: stur            d2, [fp, #-0x20]
    // 0x12f5880: LoadField: d0 = r1->field_f
    //     0x12f5880: ldur            d0, [x1, #0xf]
    // 0x12f5884: stur            d0, [fp, #-0x18]
    // 0x12f5888: r0 = Offset()
    //     0x12f5888: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x12f588c: ldur            d0, [fp, #-0x20]
    // 0x12f5890: StoreField: r0->field_7 = d0
    //     0x12f5890: stur            d0, [x0, #7]
    // 0x12f5894: ldur            d0, [fp, #-0x18]
    // 0x12f5898: StoreField: r0->field_f = d0
    //     0x12f5898: stur            d0, [x0, #0xf]
    // 0x12f589c: LeaveFrame
    //     0x12f589c: mov             SP, fp
    //     0x12f58a0: ldp             fp, lr, [SP], #0x10
    // 0x12f58a4: ret
    //     0x12f58a4: ret             
    // 0x12f58a8: d0 = 2.000000
    //     0x12f58a8: fmov            d0, #2.00000000
    // 0x12f58ac: d2 = 12.000000
    //     0x12f58ac: fmov            d2, #12.00000000
    // 0x12f58b0: d1 = 1.500000
    //     0x12f58b0: fmov            d1, #1.50000000
    // 0x12f58b4: LoadField: d3 = r1->field_7
    //     0x12f58b4: ldur            d3, [x1, #7]
    // 0x12f58b8: fdiv            d4, d3, d0
    // 0x12f58bc: stur            d4, [fp, #-0x20]
    // 0x12f58c0: LoadField: d0 = r1->field_f
    //     0x12f58c0: ldur            d0, [x1, #0xf]
    // 0x12f58c4: fsub            d3, d0, d2
    // 0x12f58c8: fadd            d0, d3, d1
    // 0x12f58cc: stur            d0, [fp, #-0x18]
    // 0x12f58d0: r0 = Offset()
    //     0x12f58d0: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x12f58d4: ldur            d0, [fp, #-0x20]
    // 0x12f58d8: StoreField: r0->field_7 = d0
    //     0x12f58d8: stur            d0, [x0, #7]
    // 0x12f58dc: ldur            d0, [fp, #-0x18]
    // 0x12f58e0: StoreField: r0->field_f = d0
    //     0x12f58e0: stur            d0, [x0, #0xf]
    // 0x12f58e4: LeaveFrame
    //     0x12f58e4: mov             SP, fp
    //     0x12f58e8: ldp             fp, lr, [SP], #0x10
    // 0x12f58ec: ret
    //     0x12f58ec: ret             
    // 0x12f58f0: ldur            d1, [fp, #-0x10]
    // 0x12f58f4: d0 = 2.000000
    //     0x12f58f4: fmov            d0, #2.00000000
    // 0x12f58f8: LoadField: d2 = r1->field_7
    //     0x12f58f8: ldur            d2, [x1, #7]
    // 0x12f58fc: fdiv            d3, d2, d0
    // 0x12f5900: stur            d3, [fp, #-0x20]
    // 0x12f5904: LoadField: d2 = r1->field_f
    //     0x12f5904: ldur            d2, [x1, #0xf]
    // 0x12f5908: fsub            d4, d2, d1
    // 0x12f590c: fdiv            d2, d4, d0
    // 0x12f5910: fadd            d0, d1, d2
    // 0x12f5914: stur            d0, [fp, #-0x18]
    // 0x12f5918: r0 = Offset()
    //     0x12f5918: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x12f591c: ldur            d0, [fp, #-0x20]
    // 0x12f5920: StoreField: r0->field_7 = d0
    //     0x12f5920: stur            d0, [x0, #7]
    // 0x12f5924: ldur            d0, [fp, #-0x18]
    // 0x12f5928: StoreField: r0->field_f = d0
    //     0x12f5928: stur            d0, [x0, #0xf]
    // 0x12f592c: LeaveFrame
    //     0x12f592c: mov             SP, fp
    //     0x12f5930: ldp             fp, lr, [SP], #0x10
    // 0x12f5934: ret
    //     0x12f5934: ret             
    // 0x12f5938: r0 = StackOverflowSharedWithFPURegs()
    //     0x12f5938: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12f593c: b               #0x12f584c
  }
}

// class id: 3280, size: 0x8, field offset: 0x8
class CupertinoTextSelectionHandleControls extends _MixinApplication417&CupertinoTextSelectionControls&TextSelectionHandleControls {
}

// class id: 4345, size: 0x10, field offset: 0xc
//   const constructor, 
class _CupertinoTextSelectionHandlePainter extends CustomPainter {

  _ paint(/* No info */) {
    // ** addr: 0xb74b70, size: 0x2b4
    // 0xb74b70: EnterFrame
    //     0xb74b70: stp             fp, lr, [SP, #-0x10]!
    //     0xb74b74: mov             fp, SP
    // 0xb74b78: AllocStack(0x68)
    //     0xb74b78: sub             SP, SP, #0x68
    // 0xb74b7c: SetupParameters(_CupertinoTextSelectionHandlePainter this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xb74b7c: stur            x1, [fp, #-8]
    //     0xb74b80: stur            x2, [fp, #-0x10]
    //     0xb74b84: stur            x3, [fp, #-0x18]
    // 0xb74b88: CheckStackOverflow
    //     0xb74b88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb74b8c: cmp             SP, x16
    //     0xb74b90: b.ls            #0xb74e0c
    // 0xb74b94: r16 = 136
    //     0xb74b94: mov             x16, #0x88
    // 0xb74b98: stp             x16, NULL, [SP]
    // 0xb74b9c: r0 = ByteData()
    //     0xb74b9c: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xb74ba0: stur            x0, [fp, #-0x20]
    // 0xb74ba4: r0 = Paint()
    //     0xb74ba4: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xb74ba8: ldur            x5, [fp, #-0x20]
    // 0xb74bac: stur            x0, [fp, #-0x28]
    // 0xb74bb0: StoreField: r0->field_7 = r5
    //     0xb74bb0: stur            w5, [x0, #7]
    // 0xb74bb4: ldur            x1, [fp, #-8]
    // 0xb74bb8: LoadField: r2 = r1->field_b
    //     0xb74bb8: ldur            w2, [x1, #0xb]
    // 0xb74bbc: DecompressPointer r2
    //     0xb74bbc: add             x2, x2, HEAP, lsl #32
    // 0xb74bc0: mov             x1, x0
    // 0xb74bc4: r0 = color=()
    //     0xb74bc4: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xb74bc8: r0 = Rect()
    //     0xb74bc8: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0xb74bcc: mov             x1, x0
    // 0xb74bd0: r2 = Instance_Offset
    //     0xb74bd0: add             x2, PP, #0xa2, lsl #12  ; [pp+0xa2a98] Obj!Offset@12a7d91
    //     0xb74bd4: ldr             x2, [x2, #0xa98]
    // 0xb74bd8: d0 = 12.000000
    //     0xb74bd8: fmov            d0, #12.00000000
    // 0xb74bdc: d1 = 12.000000
    //     0xb74bdc: fmov            d1, #12.00000000
    // 0xb74be0: stur            x0, [fp, #-8]
    // 0xb74be4: r0 = Rect.fromCenter()
    //     0xb74be4: bl              #0x86ddc8  ; [dart:ui] Rect::Rect.fromCenter
    // 0xb74be8: ldur            x0, [fp, #-0x18]
    // 0xb74bec: LoadField: d0 = r0->field_f
    //     0xb74bec: ldur            d0, [x0, #0xf]
    // 0xb74bf0: stur            d0, [fp, #-0x40]
    // 0xb74bf4: r0 = Offset()
    //     0xb74bf4: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xb74bf8: d0 = 7.000000
    //     0xb74bf8: fmov            d0, #7.00000000
    // 0xb74bfc: stur            x0, [fp, #-0x18]
    // 0xb74c00: StoreField: r0->field_7 = d0
    //     0xb74c00: stur            d0, [x0, #7]
    // 0xb74c04: ldur            d0, [fp, #-0x40]
    // 0xb74c08: StoreField: r0->field_f = d0
    //     0xb74c08: stur            d0, [x0, #0xf]
    // 0xb74c0c: r0 = Rect()
    //     0xb74c0c: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0xb74c10: mov             x1, x0
    // 0xb74c14: ldur            x3, [fp, #-0x18]
    // 0xb74c18: r2 = Instance_Offset
    //     0xb74c18: add             x2, PP, #0xa2, lsl #12  ; [pp+0xa2aa0] Obj!Offset@12a7d71
    //     0xb74c1c: ldr             x2, [x2, #0xaa0]
    // 0xb74c20: stur            x0, [fp, #-0x18]
    // 0xb74c24: r0 = Rect.fromPoints()
    //     0xb74c24: bl              #0x858780  ; [dart:ui] Rect::Rect.fromPoints
    // 0xb74c28: r0 = _NativePath()
    //     0xb74c28: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0xb74c2c: mov             x1, x0
    // 0xb74c30: stur            x0, [fp, #-0x30]
    // 0xb74c34: r0 = __constructor$Method$FfiNative()
    //     0xb74c34: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0xb74c38: ldur            x0, [fp, #-8]
    // 0xb74c3c: LoadField: d0 = r0->field_7
    //     0xb74c3c: ldur            d0, [x0, #7]
    // 0xb74c40: stur            d0, [fp, #-0x58]
    // 0xb74c44: LoadField: d1 = r0->field_f
    //     0xb74c44: ldur            d1, [x0, #0xf]
    // 0xb74c48: stur            d1, [fp, #-0x50]
    // 0xb74c4c: ArrayLoad: d2 = r0[0]  ; List_8
    //     0xb74c4c: ldur            d2, [x0, #0x17]
    // 0xb74c50: stur            d2, [fp, #-0x48]
    // 0xb74c54: LoadField: d3 = r0->field_1f
    //     0xb74c54: ldur            d3, [x0, #0x1f]
    // 0xb74c58: ldur            x0, [fp, #-0x30]
    // 0xb74c5c: stur            d3, [fp, #-0x40]
    // 0xb74c60: LoadField: r1 = r0->field_7
    //     0xb74c60: ldur            w1, [x0, #7]
    // 0xb74c64: DecompressPointer r1
    //     0xb74c64: add             x1, x1, HEAP, lsl #32
    // 0xb74c68: cmp             w1, NULL
    // 0xb74c6c: b.eq            #0xb74e14
    // 0xb74c70: LoadField: r2 = r1->field_7
    //     0xb74c70: ldur            x2, [x1, #7]
    // 0xb74c74: ldr             x1, [x2]
    // 0xb74c78: cbz             x1, #0xb74ddc
    // 0xb74c7c: ldur            x2, [fp, #-0x18]
    // 0xb74c80: mov             x3, x1
    // 0xb74c84: stur            x3, [fp, #-0x38]
    // 0xb74c88: r1 = <Never>
    //     0xb74c88: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb74c8c: r0 = Pointer()
    //     0xb74c8c: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb74c90: mov             x1, x0
    // 0xb74c94: ldur            x0, [fp, #-0x38]
    // 0xb74c98: StoreField: r1->field_7 = r0
    //     0xb74c98: stur            x0, [x1, #7]
    // 0xb74c9c: ldur            d0, [fp, #-0x58]
    // 0xb74ca0: ldur            d1, [fp, #-0x50]
    // 0xb74ca4: ldur            d2, [fp, #-0x48]
    // 0xb74ca8: ldur            d3, [fp, #-0x40]
    // 0xb74cac: r0 = __addOval$Method$FfiNative()
    //     0xb74cac: bl              #0xb6b218  ; [dart:ui] _NativePath::__addOval$Method$FfiNative
    // 0xb74cb0: ldur            x0, [fp, #-0x18]
    // 0xb74cb4: LoadField: d0 = r0->field_7
    //     0xb74cb4: ldur            d0, [x0, #7]
    // 0xb74cb8: stur            d0, [fp, #-0x58]
    // 0xb74cbc: LoadField: d1 = r0->field_f
    //     0xb74cbc: ldur            d1, [x0, #0xf]
    // 0xb74cc0: stur            d1, [fp, #-0x50]
    // 0xb74cc4: ArrayLoad: d2 = r0[0]  ; List_8
    //     0xb74cc4: ldur            d2, [x0, #0x17]
    // 0xb74cc8: stur            d2, [fp, #-0x48]
    // 0xb74ccc: LoadField: d3 = r0->field_1f
    //     0xb74ccc: ldur            d3, [x0, #0x1f]
    // 0xb74cd0: ldur            x0, [fp, #-0x30]
    // 0xb74cd4: stur            d3, [fp, #-0x40]
    // 0xb74cd8: LoadField: r1 = r0->field_7
    //     0xb74cd8: ldur            w1, [x0, #7]
    // 0xb74cdc: DecompressPointer r1
    //     0xb74cdc: add             x1, x1, HEAP, lsl #32
    // 0xb74ce0: cmp             w1, NULL
    // 0xb74ce4: b.eq            #0xb74e18
    // 0xb74ce8: LoadField: r2 = r1->field_7
    //     0xb74ce8: ldur            x2, [x1, #7]
    // 0xb74cec: ldr             x1, [x2]
    // 0xb74cf0: cbz             x1, #0xb74dec
    // 0xb74cf4: ldur            x3, [fp, #-0x10]
    // 0xb74cf8: ldur            x2, [fp, #-0x28]
    // 0xb74cfc: mov             x4, x1
    // 0xb74d00: stur            x4, [fp, #-0x38]
    // 0xb74d04: r1 = <Never>
    //     0xb74d04: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb74d08: r0 = Pointer()
    //     0xb74d08: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb74d0c: mov             x1, x0
    // 0xb74d10: ldur            x0, [fp, #-0x38]
    // 0xb74d14: StoreField: r1->field_7 = r0
    //     0xb74d14: stur            x0, [x1, #7]
    // 0xb74d18: ldur            d0, [fp, #-0x58]
    // 0xb74d1c: ldur            d1, [fp, #-0x50]
    // 0xb74d20: ldur            d2, [fp, #-0x48]
    // 0xb74d24: ldur            d3, [fp, #-0x40]
    // 0xb74d28: r0 = __addRect$Method$FfiNative()
    //     0xb74d28: bl              #0xb74e24  ; [dart:ui] _NativePath::__addRect$Method$FfiNative
    // 0xb74d2c: ldur            x0, [fp, #-0x28]
    // 0xb74d30: LoadField: r3 = r0->field_b
    //     0xb74d30: ldur            w3, [x0, #0xb]
    // 0xb74d34: DecompressPointer r3
    //     0xb74d34: add             x3, x3, HEAP, lsl #32
    // 0xb74d38: ldur            x0, [fp, #-0x10]
    // 0xb74d3c: stur            x3, [fp, #-8]
    // 0xb74d40: LoadField: r1 = r0->field_7
    //     0xb74d40: ldur            w1, [x0, #7]
    // 0xb74d44: DecompressPointer r1
    //     0xb74d44: add             x1, x1, HEAP, lsl #32
    // 0xb74d48: cmp             w1, NULL
    // 0xb74d4c: b.eq            #0xb74e1c
    // 0xb74d50: LoadField: r2 = r1->field_7
    //     0xb74d50: ldur            x2, [x1, #7]
    // 0xb74d54: ldr             x1, [x2]
    // 0xb74d58: cbz             x1, #0xb74dfc
    // 0xb74d5c: ldur            x2, [fp, #-0x30]
    // 0xb74d60: mov             x4, x1
    // 0xb74d64: stur            x4, [fp, #-0x38]
    // 0xb74d68: r1 = <Never>
    //     0xb74d68: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb74d6c: r0 = Pointer()
    //     0xb74d6c: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb74d70: mov             x2, x0
    // 0xb74d74: ldur            x0, [fp, #-0x38]
    // 0xb74d78: stur            x2, [fp, #-0x18]
    // 0xb74d7c: StoreField: r2->field_7 = r0
    //     0xb74d7c: stur            x0, [x2, #7]
    // 0xb74d80: ldur            x0, [fp, #-0x30]
    // 0xb74d84: LoadField: r1 = r0->field_7
    //     0xb74d84: ldur            w1, [x0, #7]
    // 0xb74d88: DecompressPointer r1
    //     0xb74d88: add             x1, x1, HEAP, lsl #32
    // 0xb74d8c: cmp             w1, NULL
    // 0xb74d90: b.eq            #0xb74e20
    // 0xb74d94: LoadField: r3 = r1->field_7
    //     0xb74d94: ldur            x3, [x1, #7]
    // 0xb74d98: ldr             x1, [x3]
    // 0xb74d9c: mov             x3, x1
    // 0xb74da0: stur            x3, [fp, #-0x38]
    // 0xb74da4: r1 = <Never>
    //     0xb74da4: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xb74da8: r0 = Pointer()
    //     0xb74da8: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xb74dac: mov             x1, x0
    // 0xb74db0: ldur            x0, [fp, #-0x38]
    // 0xb74db4: StoreField: r1->field_7 = r0
    //     0xb74db4: stur            x0, [x1, #7]
    // 0xb74db8: mov             x2, x1
    // 0xb74dbc: ldur            x1, [fp, #-0x18]
    // 0xb74dc0: ldur            x3, [fp, #-8]
    // 0xb74dc4: ldur            x5, [fp, #-0x20]
    // 0xb74dc8: r0 = __drawPath$Method$FfiNative()
    //     0xb74dc8: bl              #0xb69a00  ; [dart:ui] _NativeCanvas::__drawPath$Method$FfiNative
    // 0xb74dcc: r0 = Null
    //     0xb74dcc: mov             x0, NULL
    // 0xb74dd0: LeaveFrame
    //     0xb74dd0: mov             SP, fp
    //     0xb74dd4: ldp             fp, lr, [SP], #0x10
    // 0xb74dd8: ret
    //     0xb74dd8: ret             
    // 0xb74ddc: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb74ddc: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb74de0: str             x16, [SP]
    // 0xb74de4: r0 = _throwNew()
    //     0xb74de4: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb74de8: brk             #0
    // 0xb74dec: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb74dec: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb74df0: str             x16, [SP]
    // 0xb74df4: r0 = _throwNew()
    //     0xb74df4: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb74df8: brk             #0
    // 0xb74dfc: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xb74dfc: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xb74e00: str             x16, [SP]
    // 0xb74e04: r0 = _throwNew()
    //     0xb74e04: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xb74e08: brk             #0
    // 0xb74e0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb74e0c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb74e10: b               #0xb74b94
    // 0xb74e14: r0 = NullErrorSharedWithFPURegs()
    //     0xb74e14: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0xb74e18: r0 = NullErrorSharedWithFPURegs()
    //     0xb74e18: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0xb74e1c: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb74e1c: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xb74e20: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb74e20: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ shouldRepaint(/* No info */) {
    // ** addr: 0xb92fc4, size: 0xa0
    // 0xb92fc4: EnterFrame
    //     0xb92fc4: stp             fp, lr, [SP, #-0x10]!
    //     0xb92fc8: mov             fp, SP
    // 0xb92fcc: AllocStack(0x20)
    //     0xb92fcc: sub             SP, SP, #0x20
    // 0xb92fd0: SetupParameters(_CupertinoTextSelectionHandlePainter this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xb92fd0: mov             x4, x1
    //     0xb92fd4: mov             x3, x2
    //     0xb92fd8: stur            x1, [fp, #-8]
    //     0xb92fdc: stur            x2, [fp, #-0x10]
    // 0xb92fe0: CheckStackOverflow
    //     0xb92fe0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb92fe4: cmp             SP, x16
    //     0xb92fe8: b.ls            #0xb9305c
    // 0xb92fec: mov             x0, x3
    // 0xb92ff0: r2 = Null
    //     0xb92ff0: mov             x2, NULL
    // 0xb92ff4: r1 = Null
    //     0xb92ff4: mov             x1, NULL
    // 0xb92ff8: r4 = 60
    //     0xb92ff8: mov             x4, #0x3c
    // 0xb92ffc: branchIfSmi(r0, 0xb93008)
    //     0xb92ffc: tbz             w0, #0, #0xb93008
    // 0xb93000: r4 = LoadClassIdInstr(r0)
    //     0xb93000: ldur            x4, [x0, #-1]
    //     0xb93004: ubfx            x4, x4, #0xc, #0x14
    // 0xb93008: r17 = 4345
    //     0xb93008: mov             x17, #0x10f9
    // 0xb9300c: cmp             x4, x17
    // 0xb93010: b.eq            #0xb93028
    // 0xb93014: r8 = _CupertinoTextSelectionHandlePainter
    //     0xb93014: add             x8, PP, #0xa2, lsl #12  ; [pp+0xa2a80] Type: _CupertinoTextSelectionHandlePainter
    //     0xb93018: ldr             x8, [x8, #0xa80]
    // 0xb9301c: r3 = Null
    //     0xb9301c: add             x3, PP, #0xa2, lsl #12  ; [pp+0xa2a88] Null
    //     0xb93020: ldr             x3, [x3, #0xa88]
    // 0xb93024: r0 = DefaultTypeTest()
    //     0xb93024: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb93028: ldur            x0, [fp, #-8]
    // 0xb9302c: LoadField: r1 = r0->field_b
    //     0xb9302c: ldur            w1, [x0, #0xb]
    // 0xb93030: DecompressPointer r1
    //     0xb93030: add             x1, x1, HEAP, lsl #32
    // 0xb93034: ldur            x0, [fp, #-0x10]
    // 0xb93038: LoadField: r2 = r0->field_b
    //     0xb93038: ldur            w2, [x0, #0xb]
    // 0xb9303c: DecompressPointer r2
    //     0xb9303c: add             x2, x2, HEAP, lsl #32
    // 0xb93040: stp             x2, x1, [SP]
    // 0xb93044: r0 = ==()
    //     0xb93044: bl              #0x12629d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::==
    // 0xb93048: eor             x1, x0, #0x10
    // 0xb9304c: mov             x0, x1
    // 0xb93050: LeaveFrame
    //     0xb93050: mov             SP, fp
    //     0xb93054: ldp             fp, lr, [SP], #0x10
    // 0xb93058: ret
    //     0xb93058: ret             
    // 0xb9305c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9305c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb93060: b               #0xb92fec
  }
}
