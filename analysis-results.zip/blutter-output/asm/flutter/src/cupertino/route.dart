// lib: , url: package:flutter/src/cupertino/route.dart

// class id: 1048783, size: 0x8
class :: {

  static late final Animatable<Offset> _kMiddleLeftTween; // offset: 0x750
  static late final Animatable<Offset> _kRightMiddleTween; // offset: 0x74c
  static late final Animatable<Offset> _kBottomUpTween; // offset: 0x754

  static _ showCupertinoModalPopup(/* No info */) {
    // ** addr: 0xdce924, size: 0x118
    // 0xdce924: EnterFrame
    //     0xdce924: stp             fp, lr, [SP, #-0x10]!
    //     0xdce928: mov             fp, SP
    // 0xdce92c: AllocStack(0x40)
    //     0xdce92c: sub             SP, SP, #0x40
    // 0xdce930: SetupParameters(dynamic _ /* r3, fp-0x20 */, dynamic _ /* r2, fp-0x18 */, {dynamic semanticsDismissible = false /* r5, fp-0x10 */})
    //     0xdce930: ldur            w0, [x4, #0x13]
    //     0xdce934: sub             x1, x0, #4
    //     0xdce938: add             x3, fp, w1, sxtw #2
    //     0xdce93c: ldr             x3, [x3, #0x18]
    //     0xdce940: stur            x3, [fp, #-0x20]
    //     0xdce944: add             x2, fp, w1, sxtw #2
    //     0xdce948: ldr             x2, [x2, #0x10]
    //     0xdce94c: stur            x2, [fp, #-0x18]
    //     0xdce950: ldur            w1, [x4, #0x1f]
    //     0xdce954: add             x1, x1, HEAP, lsl #32
    //     0xdce958: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e870] "semanticsDismissible"
    //     0xdce95c: ldr             x16, [x16, #0x870]
    //     0xdce960: cmp             w1, w16
    //     0xdce964: b.ne            #0xdce984
    //     0xdce968: ldur            w1, [x4, #0x23]
    //     0xdce96c: add             x1, x1, HEAP, lsl #32
    //     0xdce970: sub             w5, w0, w1
    //     0xdce974: add             x0, fp, w5, sxtw #2
    //     0xdce978: ldr             x0, [x0, #8]
    //     0xdce97c: mov             x5, x0
    //     0xdce980: b               #0xdce988
    //     0xdce984: add             x5, NULL, #0x30  ; false
    //     0xdce988: stur            x5, [fp, #-0x10]
    //     0xdce98c: ldur            w0, [x4, #0xf]
    //     0xdce990: cbnz            w0, #0xdce99c
    //     0xdce994: mov             x0, NULL
    //     0xdce998: b               #0xdce9ac
    //     0xdce99c: ldur            w0, [x4, #0x17]
    //     0xdce9a0: add             x1, fp, w0, sxtw #2
    //     0xdce9a4: ldr             x1, [x1, #0x10]
    //     0xdce9a8: mov             x0, x1
    //     0xdce9ac: stur            x0, [fp, #-8]
    // 0xdce9b0: CheckStackOverflow
    //     0xdce9b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdce9b4: cmp             SP, x16
    //     0xdce9b8: b.ls            #0xdcea34
    // 0xdce9bc: r16 = true
    //     0xdce9bc: add             x16, NULL, #0x20  ; true
    // 0xdce9c0: str             x16, [SP]
    // 0xdce9c4: mov             x1, x2
    // 0xdce9c8: r4 = const [0, 0x2, 0x1, 0x1, rootNavigator, 0x1, null]
    //     0xdce9c8: add             x4, PP, #0x15, lsl #12  ; [pp+0x150a0] List(7) [0, 0x2, 0x1, 0x1, "rootNavigator", 0x1, Null]
    //     0xdce9cc: ldr             x4, [x4, #0xa0]
    // 0xdce9d0: r0 = of()
    //     0xdce9d0: bl              #0xb35e68  ; [package:flutter/src/widgets/navigator.dart] Navigator::of
    // 0xdce9d4: ldur            x2, [fp, #-0x18]
    // 0xdce9d8: r1 = Instance_CupertinoDynamicColor
    //     0xdce9d8: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e878] Obj!CupertinoDynamicColor@12b3b31
    //     0xdce9dc: ldr             x1, [x1, #0x878]
    // 0xdce9e0: stur            x0, [fp, #-0x18]
    // 0xdce9e4: r0 = resolveFrom()
    //     0xdce9e4: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0xdce9e8: ldur            x1, [fp, #-8]
    // 0xdce9ec: stur            x0, [fp, #-0x28]
    // 0xdce9f0: r0 = CupertinoModalPopupRoute()
    //     0xdce9f0: bl              #0xdceadc  ; AllocateCupertinoModalPopupRouteStub -> CupertinoModalPopupRoute<X0> (size=0xb0)
    // 0xdce9f4: mov             x1, x0
    // 0xdce9f8: ldur            x2, [fp, #-0x28]
    // 0xdce9fc: ldur            x3, [fp, #-0x20]
    // 0xdcea00: ldur            x5, [fp, #-0x10]
    // 0xdcea04: stur            x0, [fp, #-0x10]
    // 0xdcea08: r0 = CupertinoModalPopupRoute()
    //     0xdcea08: bl              #0xdcea3c  ; [package:flutter/src/cupertino/route.dart] CupertinoModalPopupRoute::CupertinoModalPopupRoute
    // 0xdcea0c: ldur            x16, [fp, #-8]
    // 0xdcea10: ldur            lr, [fp, #-0x18]
    // 0xdcea14: stp             lr, x16, [SP, #8]
    // 0xdcea18: ldur            x16, [fp, #-0x10]
    // 0xdcea1c: str             x16, [SP]
    // 0xdcea20: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xdcea20: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xdcea24: r0 = push()
    //     0xdcea24: bl              #0x9ec7a0  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::push
    // 0xdcea28: LeaveFrame
    //     0xdcea28: mov             SP, fp
    //     0xdcea2c: ldp             fp, lr, [SP], #0x10
    // 0xdcea30: ret
    //     0xdcea30: ret             
    // 0xdcea34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdcea34: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdcea38: b               #0xdce9bc
  }
  static Animatable<Offset> _kRightMiddleTween() {
    // ** addr: 0xf6cd2c, size: 0x30
    // 0xf6cd2c: EnterFrame
    //     0xf6cd2c: stp             fp, lr, [SP, #-0x10]!
    //     0xf6cd30: mov             fp, SP
    // 0xf6cd34: r1 = <Offset>
    //     0xf6cd34: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a48] TypeArguments: <Offset>
    //     0xf6cd38: ldr             x1, [x1, #0xa48]
    // 0xf6cd3c: r0 = Tween()
    //     0xf6cd3c: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xf6cd40: r1 = Instance_Offset
    //     0xf6cd40: ldr             x1, [PP, #0x55a8]  ; [pp+0x55a8] Obj!Offset@12a7af1
    // 0xf6cd44: StoreField: r0->field_b = r1
    //     0xf6cd44: stur            w1, [x0, #0xb]
    // 0xf6cd48: r1 = Instance_Offset
    //     0xf6cd48: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xf6cd4c: StoreField: r0->field_f = r1
    //     0xf6cd4c: stur            w1, [x0, #0xf]
    // 0xf6cd50: LeaveFrame
    //     0xf6cd50: mov             SP, fp
    //     0xf6cd54: ldp             fp, lr, [SP], #0x10
    // 0xf6cd58: ret
    //     0xf6cd58: ret             
  }
  static Animatable<Offset> _kMiddleLeftTween() {
    // ** addr: 0xf6cd5c, size: 0x34
    // 0xf6cd5c: EnterFrame
    //     0xf6cd5c: stp             fp, lr, [SP, #-0x10]!
    //     0xf6cd60: mov             fp, SP
    // 0xf6cd64: r1 = <Offset>
    //     0xf6cd64: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a48] TypeArguments: <Offset>
    //     0xf6cd68: ldr             x1, [x1, #0xa48]
    // 0xf6cd6c: r0 = Tween()
    //     0xf6cd6c: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xf6cd70: r1 = Instance_Offset
    //     0xf6cd70: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xf6cd74: StoreField: r0->field_b = r1
    //     0xf6cd74: stur            w1, [x0, #0xb]
    // 0xf6cd78: r1 = Instance_Offset
    //     0xf6cd78: add             x1, PP, #0x99, lsl #12  ; [pp+0x990a8] Obj!Offset@12aa0b1
    //     0xf6cd7c: ldr             x1, [x1, #0xa8]
    // 0xf6cd80: StoreField: r0->field_f = r1
    //     0xf6cd80: stur            w1, [x0, #0xf]
    // 0xf6cd84: LeaveFrame
    //     0xf6cd84: mov             SP, fp
    //     0xf6cd88: ldp             fp, lr, [SP], #0x10
    // 0xf6cd8c: ret
    //     0xf6cd8c: ret             
  }
}

// class id: 2650, size: 0xb0, field offset: 0x98
class CupertinoModalPopupRoute<X0> extends PopupRoute<X0> {

  static late final Tween<Offset> _offsetTween; // offset: 0x744

  get _ transitionDuration(/* No info */) {
    // ** addr: 0xb2274c, size: 0xc
    // 0xb2274c: r0 = Instance_Duration
    //     0xb2274c: add             x0, PP, #0x8f, lsl #12  ; [pp+0x8fc28] Obj!Duration@12c8a21
    //     0xb22750: ldr             x0, [x0, #0xc28]
    // 0xb22754: ret
    //     0xb22754: ret             
  }
  _ buildTransitions(/* No info */) {
    // ** addr: 0xb28d94, size: 0xa8
    // 0xb28d94: EnterFrame
    //     0xb28d94: stp             fp, lr, [SP, #-0x10]!
    //     0xb28d98: mov             fp, SP
    // 0xb28d9c: AllocStack(0x18)
    //     0xb28d9c: sub             SP, SP, #0x18
    // 0xb28da0: SetupParameters(dynamic _ /* r2 => r0 */, dynamic _ /* r3 => r2, fp-0x8 */, dynamic _ /* r6 => r6, fp-0x10 */)
    //     0xb28da0: mov             x0, x2
    //     0xb28da4: mov             x2, x3
    //     0xb28da8: stur            x3, [fp, #-8]
    //     0xb28dac: stur            x6, [fp, #-0x10]
    // 0xb28db0: CheckStackOverflow
    //     0xb28db0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb28db4: cmp             SP, x16
    //     0xb28db8: b.ls            #0xb28e34
    // 0xb28dbc: r0 = LoadStaticField(0x744)
    //     0xb28dbc: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xb28dc0: ldr             x0, [x0, #0xe88]
    // 0xb28dc4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb28dc8: cmp             w0, w16
    // 0xb28dcc: b.ne            #0xb28ddc
    // 0xb28dd0: r2 = _offsetTween
    //     0xb28dd0: add             x2, PP, #0x99, lsl #12  ; [pp+0x990b0] Field <CupertinoModalPopupRoute._offsetTween@111053933>: static late final (offset: 0x744)
    //     0xb28dd4: ldr             x2, [x2, #0xb0]
    // 0xb28dd8: r0 = InitLateFinalStaticField()
    //     0xb28dd8: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xb28ddc: mov             x1, x0
    // 0xb28de0: ldur            x2, [fp, #-8]
    // 0xb28de4: r0 = evaluate()
    //     0xb28de4: bl              #0x112be60  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xb28de8: stur            x0, [fp, #-8]
    // 0xb28dec: r0 = FractionalTranslation()
    //     0xb28dec: bl              #0xb28e3c  ; AllocateFractionalTranslationStub -> FractionalTranslation (size=0x18)
    // 0xb28df0: mov             x1, x0
    // 0xb28df4: ldur            x0, [fp, #-8]
    // 0xb28df8: stur            x1, [fp, #-0x18]
    // 0xb28dfc: StoreField: r1->field_f = r0
    //     0xb28dfc: stur            w0, [x1, #0xf]
    // 0xb28e00: r0 = true
    //     0xb28e00: add             x0, NULL, #0x20  ; true
    // 0xb28e04: StoreField: r1->field_13 = r0
    //     0xb28e04: stur            w0, [x1, #0x13]
    // 0xb28e08: ldur            x0, [fp, #-0x10]
    // 0xb28e0c: StoreField: r1->field_b = r0
    //     0xb28e0c: stur            w0, [x1, #0xb]
    // 0xb28e10: r0 = Align()
    //     0xb28e10: bl              #0xb281f8  ; AllocateAlignStub -> Align (size=0x1c)
    // 0xb28e14: r1 = Instance_Alignment
    //     0xb28e14: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e1b8] Obj!Alignment@129e6f1
    //     0xb28e18: ldr             x1, [x1, #0x1b8]
    // 0xb28e1c: StoreField: r0->field_f = r1
    //     0xb28e1c: stur            w1, [x0, #0xf]
    // 0xb28e20: ldur            x1, [fp, #-0x18]
    // 0xb28e24: StoreField: r0->field_b = r1
    //     0xb28e24: stur            w1, [x0, #0xb]
    // 0xb28e28: LeaveFrame
    //     0xb28e28: mov             SP, fp
    //     0xb28e2c: ldp             fp, lr, [SP], #0x10
    // 0xb28e30: ret
    //     0xb28e30: ret             
    // 0xb28e34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb28e34: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb28e38: b               #0xb28dbc
  }
  static Tween<Offset> _offsetTween() {
    // ** addr: 0xb28e48, size: 0x30
    // 0xb28e48: EnterFrame
    //     0xb28e48: stp             fp, lr, [SP, #-0x10]!
    //     0xb28e4c: mov             fp, SP
    // 0xb28e50: r1 = <Offset>
    //     0xb28e50: add             x1, PP, #0x14, lsl #12  ; [pp+0x14a48] TypeArguments: <Offset>
    //     0xb28e54: ldr             x1, [x1, #0xa48]
    // 0xb28e58: r0 = Tween()
    //     0xb28e58: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xb28e5c: r1 = Instance_Offset
    //     0xb28e5c: ldr             x1, [PP, #0x55b0]  ; [pp+0x55b0] Obj!Offset@12a7ad1
    // 0xb28e60: StoreField: r0->field_b = r1
    //     0xb28e60: stur            w1, [x0, #0xb]
    // 0xb28e64: r1 = Instance_Offset
    //     0xb28e64: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xb28e68: StoreField: r0->field_f = r1
    //     0xb28e68: stur            w1, [x0, #0xf]
    // 0xb28e6c: LeaveFrame
    //     0xb28e6c: mov             SP, fp
    //     0xb28e70: ldp             fp, lr, [SP], #0x10
    // 0xb28e74: ret
    //     0xb28e74: ret             
  }
  _ CupertinoModalPopupRoute(/* No info */) {
    // ** addr: 0xdcea3c, size: 0xa0
    // 0xdcea3c: EnterFrame
    //     0xdcea3c: stp             fp, lr, [SP, #-0x10]!
    //     0xdcea40: mov             fp, SP
    // 0xdcea44: r6 = "Dismiss"
    //     0xdcea44: add             x6, PP, #0x1e, lsl #12  ; [pp+0x1e880] "Dismiss"
    //     0xdcea48: ldr             x6, [x6, #0x880]
    // 0xdcea4c: r4 = true
    //     0xdcea4c: add             x4, NULL, #0x20  ; true
    // 0xdcea50: mov             x16, x2
    // 0xdcea54: mov             x2, x1
    // 0xdcea58: mov             x1, x16
    // 0xdcea5c: mov             x0, x3
    // 0xdcea60: CheckStackOverflow
    //     0xdcea60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdcea64: cmp             SP, x16
    //     0xdcea68: b.ls            #0xdcead4
    // 0xdcea6c: StoreField: r2->field_97 = r0
    //     0xdcea6c: stur            w0, [x2, #0x97]
    //     0xdcea70: ldurb           w16, [x2, #-1]
    //     0xdcea74: ldurb           w17, [x0, #-1]
    //     0xdcea78: and             x16, x17, x16, lsr #2
    //     0xdcea7c: tst             x16, HEAP, lsr #32
    //     0xdcea80: b.eq            #0xdcea88
    //     0xdcea84: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xdcea88: StoreField: r2->field_a3 = r6
    //     0xdcea88: stur            w6, [x2, #0xa3]
    // 0xdcea8c: mov             x0, x1
    // 0xdcea90: StoreField: r2->field_a7 = r0
    //     0xdcea90: stur            w0, [x2, #0xa7]
    //     0xdcea94: ldurb           w16, [x2, #-1]
    //     0xdcea98: ldurb           w17, [x0, #-1]
    //     0xdcea9c: and             x16, x17, x16, lsr #2
    //     0xdceaa0: tst             x16, HEAP, lsr #32
    //     0xdceaa4: b.eq            #0xdceaac
    //     0xdceaa8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xdceaac: StoreField: r2->field_9b = r4
    //     0xdceaac: stur            w4, [x2, #0x9b]
    // 0xdceab0: StoreField: r2->field_9f = r5
    //     0xdceab0: stur            w5, [x2, #0x9f]
    // 0xdceab4: mov             x1, x2
    // 0xdceab8: r2 = Null
    //     0xdceab8: mov             x2, NULL
    // 0xdceabc: r3 = Null
    //     0xdceabc: mov             x3, NULL
    // 0xdceac0: r0 = ModalRoute()
    //     0xdceac0: bl              #0x8e04e0  ; [package:flutter/src/widgets/routes.dart] ModalRoute::ModalRoute
    // 0xdceac4: r0 = Null
    //     0xdceac4: mov             x0, NULL
    // 0xdceac8: LeaveFrame
    //     0xdceac8: mov             SP, fp
    //     0xdceacc: ldp             fp, lr, [SP], #0x10
    // 0xdcead0: ret
    //     0xdcead0: ret             
    // 0xdcead4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdcead4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdcead8: b               #0xdcea6c
  }
  _ buildPage(/* No info */) {
    // ** addr: 0x1102fd0, size: 0x64
    // 0x1102fd0: EnterFrame
    //     0x1102fd0: stp             fp, lr, [SP, #-0x10]!
    //     0x1102fd4: mov             fp, SP
    // 0x1102fd8: AllocStack(0x10)
    //     0x1102fd8: sub             SP, SP, #0x10
    // 0x1102fdc: LoadField: r0 = r1->field_97
    //     0x1102fdc: ldur            w0, [x1, #0x97]
    // 0x1102fe0: DecompressPointer r0
    //     0x1102fe0: add             x0, x0, HEAP, lsl #32
    // 0x1102fe4: stur            x0, [fp, #-8]
    // 0x1102fe8: r0 = Builder()
    //     0x1102fe8: bl              #0x858774  ; AllocateBuilderStub -> Builder (size=0x10)
    // 0x1102fec: mov             x1, x0
    // 0x1102ff0: ldur            x0, [fp, #-8]
    // 0x1102ff4: stur            x1, [fp, #-0x10]
    // 0x1102ff8: StoreField: r1->field_b = r0
    //     0x1102ff8: stur            w0, [x1, #0xb]
    // 0x1102ffc: r0 = DisplayFeatureSubScreen()
    //     0x1102ffc: bl              #0x1103034  ; AllocateDisplayFeatureSubScreenStub -> DisplayFeatureSubScreen (size=0x14)
    // 0x1103000: mov             x1, x0
    // 0x1103004: ldur            x0, [fp, #-0x10]
    // 0x1103008: stur            x1, [fp, #-8]
    // 0x110300c: StoreField: r1->field_f = r0
    //     0x110300c: stur            w0, [x1, #0xf]
    // 0x1103010: r0 = CupertinoUserInterfaceLevel()
    //     0x1103010: bl              #0xde3748  ; AllocateCupertinoUserInterfaceLevelStub -> CupertinoUserInterfaceLevel (size=0x14)
    // 0x1103014: r1 = Instance_CupertinoUserInterfaceLevelData
    //     0x1103014: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e890] Obj!CupertinoUserInterfaceLevelData@12c5fe1
    //     0x1103018: ldr             x1, [x1, #0x890]
    // 0x110301c: StoreField: r0->field_f = r1
    //     0x110301c: stur            w1, [x0, #0xf]
    // 0x1103020: ldur            x1, [fp, #-8]
    // 0x1103024: StoreField: r0->field_b = r1
    //     0x1103024: stur            w1, [x0, #0xb]
    // 0x1103028: LeaveFrame
    //     0x1103028: mov             SP, fp
    //     0x110302c: ldp             fp, lr, [SP], #0x10
    // 0x1103030: ret
    //     0x1103030: ret             
  }
  _ createSimulation(/* No info */) {
    // ** addr: 0x112bd44, size: 0xb8
    // 0x112bd44: EnterFrame
    //     0x112bd44: stp             fp, lr, [SP, #-0x10]!
    //     0x112bd48: mov             fp, SP
    // 0x112bd4c: AllocStack(0x28)
    //     0x112bd4c: sub             SP, SP, #0x28
    // 0x112bd50: CheckStackOverflow
    //     0x112bd50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x112bd54: cmp             SP, x16
    //     0x112bd58: b.ls            #0x112bde8
    // 0x112bd5c: tbnz            w2, #4, #0x112bd68
    // 0x112bd60: d1 = 1.000000
    //     0x112bd60: fmov            d1, #1.00000000
    // 0x112bd64: b               #0x112bd6c
    // 0x112bd68: d1 = 0.000000
    //     0x112bd68: eor             v1.16b, v1.16b, v1.16b
    // 0x112bd6c: stur            d1, [fp, #-0x18]
    // 0x112bd70: LoadField: r0 = r1->field_37
    //     0x112bd70: ldur            w0, [x1, #0x37]
    // 0x112bd74: DecompressPointer r0
    //     0x112bd74: add             x0, x0, HEAP, lsl #32
    // 0x112bd78: cmp             w0, NULL
    // 0x112bd7c: b.eq            #0x112bdf0
    // 0x112bd80: LoadField: r1 = r0->field_37
    //     0x112bd80: ldur            w1, [x0, #0x37]
    // 0x112bd84: DecompressPointer r1
    //     0x112bd84: add             x1, x1, HEAP, lsl #32
    // 0x112bd88: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x112bd8c: cmp             w1, w16
    // 0x112bd90: b.eq            #0x112bdf4
    // 0x112bd94: LoadField: d0 = r1->field_7
    //     0x112bd94: ldur            d0, [x1, #7]
    // 0x112bd98: stur            d0, [fp, #-0x10]
    // 0x112bd9c: r0 = SpringSimulation()
    //     0x112bd9c: bl              #0xb35bf8  ; AllocateSpringSimulationStub -> SpringSimulation (size=0x1c)
    // 0x112bda0: stur            x0, [fp, #-8]
    // 0x112bda4: r16 = Instance_Tolerance
    //     0x112bda4: add             x16, PP, #0x84, lsl #12  ; [pp+0x84970] Obj!Tolerance@129c601
    //     0x112bda8: ldr             x16, [x16, #0x970]
    // 0x112bdac: r30 = true
    //     0x112bdac: add             lr, NULL, #0x20  ; true
    // 0x112bdb0: stp             lr, x16, [SP]
    // 0x112bdb4: mov             x1, x0
    // 0x112bdb8: ldur            d0, [fp, #-0x10]
    // 0x112bdbc: ldur            d1, [fp, #-0x18]
    // 0x112bdc0: r2 = Instance_SpringDescription
    //     0x112bdc0: add             x2, PP, #0x84, lsl #12  ; [pp+0x84978] Obj!SpringDescription@129c621
    //     0x112bdc4: ldr             x2, [x2, #0x978]
    // 0x112bdc8: d2 = 0.000000
    //     0x112bdc8: eor             v2.16b, v2.16b, v2.16b
    // 0x112bdcc: r4 = const [0, 0x7, 0x2, 0x5, snapToEnd, 0x6, tolerance, 0x5, null]
    //     0x112bdcc: add             x4, PP, #0x84, lsl #12  ; [pp+0x84980] List(9) [0, 0x7, 0x2, 0x5, "snapToEnd", 0x6, "tolerance", 0x5, Null]
    //     0x112bdd0: ldr             x4, [x4, #0x980]
    // 0x112bdd4: r0 = SpringSimulation()
    //     0x112bdd4: bl              #0xb35128  ; [package:flutter/src/physics/spring_simulation.dart] SpringSimulation::SpringSimulation
    // 0x112bdd8: ldur            x0, [fp, #-8]
    // 0x112bddc: LeaveFrame
    //     0x112bddc: mov             SP, fp
    //     0x112bde0: ldp             fp, lr, [SP], #0x10
    // 0x112bde4: ret
    //     0x112bde4: ret             
    // 0x112bde8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x112bde8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x112bdec: b               #0x112bd5c
    // 0x112bdf0: r0 = NullCastErrorSharedWithFPURegs()
    //     0x112bdf0: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0x112bdf4: r9 = _value
    //     0x112bdf4: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0x112bdf8: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x112bdf8: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
  }
  get _ semanticsDismissible(/* No info */) {
    // ** addr: 0x12ea4c4, size: 0xc
    // 0x12ea4c4: LoadField: r0 = r1->field_9f
    //     0x12ea4c4: ldur            w0, [x1, #0x9f]
    // 0x12ea4c8: DecompressPointer r0
    //     0x12ea4c8: add             x0, x0, HEAP, lsl #32
    // 0x12ea4cc: ret
    //     0x12ea4cc: ret             
  }
  const get _ barrierColor(/* No info */) {
    // ** addr: 0x12f134c, size: 0xc
    // 0x12f134c: LoadField: r0 = r1->field_a7
    //     0x12f134c: ldur            w0, [x1, #0xa7]
    // 0x12f1350: DecompressPointer r0
    //     0x12f1350: add             x0, x0, HEAP, lsl #32
    // 0x12f1354: ret
    //     0x12f1354: ret             
  }
}

// class id: 3255, size: 0x8, field offset: 0x8
//   const constructor, 
class CupertinoPageTransitionsBuilder extends PageTransitionsBuilder {

  _ buildTransitions(/* No info */) {
    // ** addr: 0x119f6cc, size: 0x70
    // 0x119f6cc: EnterFrame
    //     0x119f6cc: stp             fp, lr, [SP, #-0x10]!
    //     0x119f6d0: mov             fp, SP
    // 0x119f6d4: AllocStack(0x28)
    //     0x119f6d4: sub             SP, SP, #0x28
    // 0x119f6d8: SetupParameters()
    //     0x119f6d8: ldur            w0, [x4, #0xf]
    //     0x119f6dc: cbnz            w0, #0x119f6e8
    //     0x119f6e0: mov             x0, NULL
    //     0x119f6e4: b               #0x119f6f8
    //     0x119f6e8: ldur            w0, [x4, #0x17]
    //     0x119f6ec: add             x1, fp, w0, sxtw #2
    //     0x119f6f0: ldr             x1, [x1, #0x10]
    //     0x119f6f4: mov             x0, x1
    // 0x119f6f8: CheckStackOverflow
    //     0x119f6f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x119f6fc: cmp             SP, x16
    //     0x119f700: b.ls            #0x119f734
    // 0x119f704: ldr             x16, [fp, #0x28]
    // 0x119f708: stp             x16, x0, [SP, #0x18]
    // 0x119f70c: ldr             x16, [fp, #0x20]
    // 0x119f710: ldr             lr, [fp, #0x18]
    // 0x119f714: stp             lr, x16, [SP, #8]
    // 0x119f718: ldr             x16, [fp, #0x10]
    // 0x119f71c: str             x16, [SP]
    // 0x119f720: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0x119f720: ldr             x4, [PP, #0x560]  ; [pp+0x560] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0x119f724: r0 = buildPageTransitions()
    //     0x119f724: bl              #0x119f73c  ; [package:flutter/src/cupertino/route.dart] CupertinoRouteTransitionMixin::buildPageTransitions
    // 0x119f728: LeaveFrame
    //     0x119f728: mov             SP, fp
    //     0x119f72c: ldp             fp, lr, [SP], #0x10
    // 0x119f730: ret
    //     0x119f730: ret             
    // 0x119f734: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x119f734: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x119f738: b               #0x119f704
  }
  get _ delegatedTransition(/* No info */) {
    // ** addr: 0x12b89a8, size: 0xc
    // 0x12b89a8: r0 = Closure: (BuildContext, Animation<double>, Animation<double>, bool, Widget?) => Widget? from Function 'delegatedTransition': static.
    //     0x12b89a8: add             x0, PP, #0x99, lsl #12  ; [pp+0x99088] Closure: (BuildContext, Animation<double>, Animation<double>, bool, Widget?) => Widget? from Function 'delegatedTransition': static. (0x7f2adb19f9b4)
    //     0x12b89ac: ldr             x0, [x0, #0x88]
    // 0x12b89b0: ret
    //     0x12b89b0: ret             
  }
  get _ transitionDuration(/* No info */) {
    // ** addr: 0x12f96f0, size: 0x8
    // 0x12f96f0: r0 = Instance_Duration
    //     0x12f96f0: ldr             x0, [PP, #0x5248]  ; [pp+0x5248] Obj!Duration@12c8931
    // 0x12f96f4: ret
    //     0x12f96f4: ret             
  }
}

// class id: 3260, size: 0x10, field offset: 0xc
class _CupertinoEdgeShadowPainter extends BoxPainter {

  _ paint(/* No info */) {
    // ** addr: 0x12f64e8, size: 0x49c
    // 0x12f64e8: EnterFrame
    //     0x12f64e8: stp             fp, lr, [SP, #-0x10]!
    //     0x12f64ec: mov             fp, SP
    // 0x12f64f0: AllocStack(0x98)
    //     0x12f64f0: sub             SP, SP, #0x98
    // 0x12f64f4: SetupParameters(_CupertinoEdgeShadowPainter this /* r1 => r0 */, dynamic _ /* r2 => r1, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */)
    //     0x12f64f4: mov             x0, x1
    //     0x12f64f8: mov             x1, x2
    //     0x12f64fc: stur            x2, [fp, #-0x10]
    //     0x12f6500: stur            x3, [fp, #-0x18]
    //     0x12f6504: stur            x5, [fp, #-0x20]
    // 0x12f6508: CheckStackOverflow
    //     0x12f6508: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f650c: cmp             SP, x16
    //     0x12f6510: b.ls            #0x12f68f4
    // 0x12f6514: LoadField: r2 = r0->field_b
    //     0x12f6514: ldur            w2, [x0, #0xb]
    // 0x12f6518: DecompressPointer r2
    //     0x12f6518: add             x2, x2, HEAP, lsl #32
    // 0x12f651c: LoadField: r4 = r2->field_7
    //     0x12f651c: ldur            w4, [x2, #7]
    // 0x12f6520: DecompressPointer r4
    //     0x12f6520: add             x4, x4, HEAP, lsl #32
    // 0x12f6524: stur            x4, [fp, #-8]
    // 0x12f6528: cmp             w4, NULL
    // 0x12f652c: b.ne            #0x12f6540
    // 0x12f6530: r0 = Null
    //     0x12f6530: mov             x0, NULL
    // 0x12f6534: LeaveFrame
    //     0x12f6534: mov             SP, fp
    //     0x12f6538: ldp             fp, lr, [SP], #0x10
    // 0x12f653c: ret
    //     0x12f653c: ret             
    // 0x12f6540: d0 = 0.050000
    //     0x12f6540: ldr             d0, [PP, #0x57a0]  ; [pp+0x57a0] IMM: double(0.05) from 0x3fa999999999999a
    // 0x12f6544: ArrayLoad: r0 = r5[0]  ; List_4
    //     0x12f6544: ldur            w0, [x5, #0x17]
    // 0x12f6548: DecompressPointer r0
    //     0x12f6548: add             x0, x0, HEAP, lsl #32
    // 0x12f654c: cmp             w0, NULL
    // 0x12f6550: b.eq            #0x12f68fc
    // 0x12f6554: LoadField: d1 = r0->field_7
    //     0x12f6554: ldur            d1, [x0, #7]
    // 0x12f6558: stur            d1, [fp, #-0x70]
    // 0x12f655c: fmul            d2, d1, d0
    // 0x12f6560: stur            d2, [fp, #-0x68]
    // 0x12f6564: LoadField: d0 = r0->field_f
    //     0x12f6564: ldur            d0, [x0, #0xf]
    // 0x12f6568: stur            d0, [fp, #-0x60]
    // 0x12f656c: r0 = LoadClassIdInstr(r4)
    //     0x12f656c: ldur            x0, [x4, #-1]
    //     0x12f6570: ubfx            x0, x0, #0xc, #0x14
    // 0x12f6574: str             x4, [SP]
    // 0x12f6578: r0 = GDT[cid_x0 + 0xf078]()
    //     0x12f6578: mov             x17, #0xf078
    //     0x12f657c: add             lr, x0, x17
    //     0x12f6580: ldr             lr, [x21, lr, lsl #3]
    //     0x12f6584: blr             lr
    // 0x12f6588: r1 = LoadInt32Instr(r0)
    //     0x12f6588: sbfx            x1, x0, #1, #0x1f
    // 0x12f658c: sub             x0, x1, #1
    // 0x12f6590: scvtf           d0, x0
    // 0x12f6594: ldur            d1, [fp, #-0x68]
    // 0x12f6598: fdiv            d2, d1, d0
    // 0x12f659c: ldur            x0, [fp, #-0x20]
    // 0x12f65a0: stur            d2, [fp, #-0x78]
    // 0x12f65a4: LoadField: r1 = r0->field_13
    //     0x12f65a4: ldur            w1, [x0, #0x13]
    // 0x12f65a8: DecompressPointer r1
    //     0x12f65a8: add             x1, x1, HEAP, lsl #32
    // 0x12f65ac: cmp             w1, NULL
    // 0x12f65b0: b.eq            #0x12f6900
    // 0x12f65b4: LoadField: r0 = r1->field_7
    //     0x12f65b4: ldur            x0, [x1, #7]
    // 0x12f65b8: cmp             x0, #0
    // 0x12f65bc: b.gt            #0x12f660c
    // 0x12f65c0: ldur            x0, [fp, #-0x18]
    // 0x12f65c4: ldur            d0, [fp, #-0x70]
    // 0x12f65c8: LoadField: d3 = r0->field_7
    //     0x12f65c8: ldur            d3, [x0, #7]
    // 0x12f65cc: fadd            d4, d3, d0
    // 0x12f65d0: r3 = inline_Allocate_Double()
    //     0x12f65d0: ldp             x3, x1, [THR, #0x60]  ; THR::top
    //     0x12f65d4: add             x3, x3, #0x10
    //     0x12f65d8: cmp             x1, x3
    //     0x12f65dc: b.ls            #0x12f6904
    //     0x12f65e0: str             x3, [THR, #0x60]  ; THR::top
    //     0x12f65e4: sub             x3, x3, #0xf
    //     0x12f65e8: mov             x1, #0xe19c
    //     0x12f65ec: movk            x1, #3, lsl #16
    //     0x12f65f0: stur            x1, [x3, #-1]
    // 0x12f65f4: dmb             ishst
    // 0x12f65f8: StoreField: r3->field_7 = d4
    //     0x12f65f8: stur            d4, [x3, #7]
    // 0x12f65fc: r2 = 1.000000
    //     0x12f65fc: ldr             x2, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0x12f6600: r0 = AllocateRecord2()
    //     0x12f6600: bl              #0x13de578  ; AllocateRecord2Stub
    // 0x12f6604: mov             x1, x0
    // 0x12f6608: b               #0x12f6650
    // 0x12f660c: ldur            x0, [fp, #-0x18]
    // 0x12f6610: LoadField: d0 = r0->field_7
    //     0x12f6610: ldur            d0, [x0, #7]
    // 0x12f6614: r3 = inline_Allocate_Double()
    //     0x12f6614: ldp             x3, x1, [THR, #0x60]  ; THR::top
    //     0x12f6618: add             x3, x3, #0x10
    //     0x12f661c: cmp             x1, x3
    //     0x12f6620: b.ls            #0x12f6928
    //     0x12f6624: str             x3, [THR, #0x60]  ; THR::top
    //     0x12f6628: sub             x3, x3, #0xf
    //     0x12f662c: mov             x1, #0xe19c
    //     0x12f6630: movk            x1, #3, lsl #16
    //     0x12f6634: stur            x1, [x3, #-1]
    // 0x12f6638: dmb             ishst
    // 0x12f663c: StoreField: r3->field_7 = d0
    //     0x12f663c: stur            d0, [x3, #7]
    // 0x12f6640: r2 = -1.000000
    //     0x12f6640: add             x2, PP, #0x13, lsl #12  ; [pp+0x132a8] -1
    //     0x12f6644: ldr             x2, [x2, #0x2a8]
    // 0x12f6648: r0 = AllocateRecord2()
    //     0x12f6648: bl              #0x13de578  ; AllocateRecord2Stub
    // 0x12f664c: mov             x1, x0
    // 0x12f6650: ldur            x0, [fp, #-0x18]
    // 0x12f6654: ldur            d0, [fp, #-0x78]
    // 0x12f6658: ldur            d1, [fp, #-0x60]
    // 0x12f665c: LoadField: r2 = r1->field_f
    //     0x12f665c: ldur            w2, [x1, #0xf]
    // 0x12f6660: DecompressPointer r2
    //     0x12f6660: add             x2, x2, HEAP, lsl #32
    // 0x12f6664: stur            x2, [fp, #-0x40]
    // 0x12f6668: LoadField: r3 = r1->field_13
    //     0x12f6668: ldur            w3, [x1, #0x13]
    // 0x12f666c: DecompressPointer r3
    //     0x12f666c: add             x3, x3, HEAP, lsl #32
    // 0x12f6670: stur            x3, [fp, #-0x38]
    // 0x12f6674: r4 = inline_Allocate_Double()
    //     0x12f6674: ldp             x4, x1, [THR, #0x60]  ; THR::top
    //     0x12f6678: add             x4, x4, #0x10
    //     0x12f667c: cmp             x1, x4
    //     0x12f6680: b.ls            #0x12f6944
    //     0x12f6684: str             x4, [THR, #0x60]  ; THR::top
    //     0x12f6688: sub             x4, x4, #0xf
    //     0x12f668c: mov             x1, #0xe19c
    //     0x12f6690: movk            x1, #3, lsl #16
    //     0x12f6694: stur            x1, [x4, #-1]
    // 0x12f6698: dmb             ishst
    // 0x12f669c: StoreField: r4->field_7 = d0
    //     0x12f669c: stur            d0, [x4, #7]
    // 0x12f66a0: stur            x4, [fp, #-0x20]
    // 0x12f66a4: LoadField: d2 = r0->field_f
    //     0x12f66a4: ldur            d2, [x0, #0xf]
    // 0x12f66a8: stur            d2, [fp, #-0x80]
    // 0x12f66ac: fadd            d3, d2, d1
    // 0x12f66b0: stur            d3, [fp, #-0x70]
    // 0x12f66b4: r7 = 0
    //     0x12f66b4: mov             x7, #0
    // 0x12f66b8: r6 = 0
    //     0x12f66b8: mov             x6, #0
    // 0x12f66bc: ldur            x5, [fp, #-8]
    // 0x12f66c0: ldur            d1, [fp, #-0x68]
    // 0x12f66c4: stur            x7, [fp, #-0x28]
    // 0x12f66c8: stur            x6, [fp, #-0x30]
    // 0x12f66cc: CheckStackOverflow
    //     0x12f66cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f66d0: cmp             SP, x16
    //     0x12f66d4: b.ls            #0x12f6968
    // 0x12f66d8: scvtf           d4, x6
    // 0x12f66dc: stur            d4, [fp, #-0x60]
    // 0x12f66e0: fcmp            d1, d4
    // 0x12f66e4: b.le            #0x12f68e4
    // 0x12f66e8: r0 = BoxInt64Instr(r6)
    //     0x12f66e8: sbfiz           x0, x6, #1, #0x1f
    //     0x12f66ec: cmp             x6, x0, asr #1
    //     0x12f66f0: b.eq            #0x12f66fc
    //     0x12f66f4: bl              #0x13dfc6c  ; AllocateMintSharedWithFPURegsStub
    //     0x12f66f8: stur            x6, [x0, #7]
    // 0x12f66fc: stur            x0, [fp, #-0x18]
    // 0x12f6700: stp             x4, x0, [SP]
    // 0x12f6704: r0 = ~/()
    //     0x12f6704: bl              #0x13d8f88  ; [dart:core] _IntegerImplementation::~/
    // 0x12f6708: r1 = LoadInt32Instr(r0)
    //     0x12f6708: sbfx            x1, x0, #1, #0x1f
    //     0x12f670c: tbz             w0, #0, #0x12f6714
    //     0x12f6710: ldur            x1, [x0, #7]
    // 0x12f6714: ldur            x0, [fp, #-0x28]
    // 0x12f6718: cmp             x1, x0
    // 0x12f671c: b.eq            #0x12f672c
    // 0x12f6720: add             x1, x0, #1
    // 0x12f6724: mov             x7, x1
    // 0x12f6728: b               #0x12f6730
    // 0x12f672c: mov             x7, x0
    // 0x12f6730: ldur            x2, [fp, #-8]
    // 0x12f6734: ldur            d0, [fp, #-0x78]
    // 0x12f6738: ldur            x0, [fp, #-0x40]
    // 0x12f673c: ldur            x1, [fp, #-0x38]
    // 0x12f6740: ldur            x3, [fp, #-0x30]
    // 0x12f6744: ldur            d3, [fp, #-0x60]
    // 0x12f6748: ldur            d1, [fp, #-0x80]
    // 0x12f674c: ldur            d2, [fp, #-0x70]
    // 0x12f6750: stur            x7, [fp, #-0x28]
    // 0x12f6754: r16 = 136
    //     0x12f6754: mov             x16, #0x88
    // 0x12f6758: stp             x16, NULL, [SP]
    // 0x12f675c: r0 = ByteData()
    //     0x12f675c: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0x12f6760: stur            x0, [fp, #-0x48]
    // 0x12f6764: r0 = Paint()
    //     0x12f6764: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x12f6768: mov             x2, x0
    // 0x12f676c: ldur            x0, [fp, #-0x48]
    // 0x12f6770: stur            x2, [fp, #-0x50]
    // 0x12f6774: StoreField: r2->field_7 = r0
    //     0x12f6774: stur            w0, [x2, #7]
    // 0x12f6778: ldur            x7, [fp, #-0x28]
    // 0x12f677c: r0 = BoxInt64Instr(r7)
    //     0x12f677c: sbfiz           x0, x7, #1, #0x1f
    //     0x12f6780: cmp             x7, x0, asr #1
    //     0x12f6784: b.eq            #0x12f6790
    //     0x12f6788: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12f678c: stur            x7, [x0, #7]
    // 0x12f6790: ldur            x1, [fp, #-8]
    // 0x12f6794: r3 = LoadClassIdInstr(r1)
    //     0x12f6794: ldur            x3, [x1, #-1]
    //     0x12f6798: ubfx            x3, x3, #0xc, #0x14
    // 0x12f679c: stp             x0, x1, [SP]
    // 0x12f67a0: mov             x0, x3
    // 0x12f67a4: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x12f67a4: sub             lr, x0, #0xdfd
    //     0x12f67a8: ldr             lr, [x21, lr, lsl #3]
    //     0x12f67ac: blr             lr
    // 0x12f67b0: mov             x2, x0
    // 0x12f67b4: ldur            x7, [fp, #-0x28]
    // 0x12f67b8: stur            x2, [fp, #-0x48]
    // 0x12f67bc: add             x3, x7, #1
    // 0x12f67c0: r0 = BoxInt64Instr(r3)
    //     0x12f67c0: sbfiz           x0, x3, #1, #0x1f
    //     0x12f67c4: cmp             x3, x0, asr #1
    //     0x12f67c8: b.eq            #0x12f67d4
    //     0x12f67cc: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12f67d0: stur            x3, [x0, #7]
    // 0x12f67d4: ldur            x1, [fp, #-8]
    // 0x12f67d8: r3 = LoadClassIdInstr(r1)
    //     0x12f67d8: ldur            x3, [x1, #-1]
    //     0x12f67dc: ubfx            x3, x3, #0xc, #0x14
    // 0x12f67e0: stp             x0, x1, [SP]
    // 0x12f67e4: mov             x0, x3
    // 0x12f67e8: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x12f67e8: sub             lr, x0, #0xdfd
    //     0x12f67ec: ldr             lr, [x21, lr, lsl #3]
    //     0x12f67f0: blr             lr
    // 0x12f67f4: stur            x0, [fp, #-0x58]
    // 0x12f67f8: ldur            x16, [fp, #-0x18]
    // 0x12f67fc: ldur            lr, [fp, #-0x20]
    // 0x12f6800: stp             lr, x16, [SP]
    // 0x12f6804: r0 = %()
    //     0x12f6804: bl              #0x13da690  ; [dart:core] _IntegerImplementation::%
    // 0x12f6808: LoadField: d0 = r0->field_7
    //     0x12f6808: ldur            d0, [x0, #7]
    // 0x12f680c: ldur            d1, [fp, #-0x78]
    // 0x12f6810: fdiv            d2, d0, d1
    // 0x12f6814: r3 = inline_Allocate_Double()
    //     0x12f6814: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0x12f6818: add             x3, x3, #0x10
    //     0x12f681c: cmp             x0, x3
    //     0x12f6820: b.ls            #0x12f6970
    //     0x12f6824: str             x3, [THR, #0x60]  ; THR::top
    //     0x12f6828: sub             x3, x3, #0xf
    //     0x12f682c: mov             x0, #0xe19c
    //     0x12f6830: movk            x0, #3, lsl #16
    //     0x12f6834: stur            x0, [x3, #-1]
    // 0x12f6838: dmb             ishst
    // 0x12f683c: StoreField: r3->field_7 = d2
    //     0x12f683c: stur            d2, [x3, #7]
    // 0x12f6840: ldur            x1, [fp, #-0x48]
    // 0x12f6844: ldur            x2, [fp, #-0x58]
    // 0x12f6848: r0 = lerp()
    //     0x12f6848: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x12f684c: ldur            x1, [fp, #-0x50]
    // 0x12f6850: mov             x2, x0
    // 0x12f6854: r0 = color=()
    //     0x12f6854: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0x12f6858: ldur            x0, [fp, #-0x40]
    // 0x12f685c: LoadField: d0 = r0->field_7
    //     0x12f685c: ldur            d0, [x0, #7]
    // 0x12f6860: ldur            d1, [fp, #-0x60]
    // 0x12f6864: fmul            d2, d0, d1
    // 0x12f6868: ldur            x1, [fp, #-0x38]
    // 0x12f686c: LoadField: d0 = r1->field_7
    //     0x12f686c: ldur            d0, [x1, #7]
    // 0x12f6870: fadd            d1, d0, d2
    // 0x12f6874: d0 = 1.000000
    //     0x12f6874: fmov            d0, #1.00000000
    // 0x12f6878: fsub            d2, d1, d0
    // 0x12f687c: stur            d2, [fp, #-0x88]
    // 0x12f6880: fadd            d1, d2, d0
    // 0x12f6884: stur            d1, [fp, #-0x60]
    // 0x12f6888: r0 = Rect()
    //     0x12f6888: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0x12f688c: ldur            d0, [fp, #-0x88]
    // 0x12f6890: StoreField: r0->field_7 = d0
    //     0x12f6890: stur            d0, [x0, #7]
    // 0x12f6894: ldur            d0, [fp, #-0x80]
    // 0x12f6898: StoreField: r0->field_f = d0
    //     0x12f6898: stur            d0, [x0, #0xf]
    // 0x12f689c: ldur            d1, [fp, #-0x60]
    // 0x12f68a0: ArrayStore: r0[0] = d1  ; List_8
    //     0x12f68a0: stur            d1, [x0, #0x17]
    // 0x12f68a4: ldur            d1, [fp, #-0x70]
    // 0x12f68a8: StoreField: r0->field_1f = d1
    //     0x12f68a8: stur            d1, [x0, #0x1f]
    // 0x12f68ac: ldur            x1, [fp, #-0x10]
    // 0x12f68b0: mov             x2, x0
    // 0x12f68b4: ldur            x3, [fp, #-0x50]
    // 0x12f68b8: r0 = drawRect()
    //     0x12f68b8: bl              #0xb704c8  ; [dart:ui] _NativeCanvas::drawRect
    // 0x12f68bc: ldur            x1, [fp, #-0x30]
    // 0x12f68c0: add             x6, x1, #1
    // 0x12f68c4: ldur            x7, [fp, #-0x28]
    // 0x12f68c8: ldur            d0, [fp, #-0x78]
    // 0x12f68cc: ldur            x2, [fp, #-0x40]
    // 0x12f68d0: ldur            x3, [fp, #-0x38]
    // 0x12f68d4: ldur            d2, [fp, #-0x80]
    // 0x12f68d8: ldur            d3, [fp, #-0x70]
    // 0x12f68dc: ldur            x4, [fp, #-0x20]
    // 0x12f68e0: b               #0x12f66bc
    // 0x12f68e4: r0 = Null
    //     0x12f68e4: mov             x0, NULL
    // 0x12f68e8: LeaveFrame
    //     0x12f68e8: mov             SP, fp
    //     0x12f68ec: ldp             fp, lr, [SP], #0x10
    // 0x12f68f0: ret
    //     0x12f68f0: ret             
    // 0x12f68f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f68f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f68f8: b               #0x12f6514
    // 0x12f68fc: r0 = NullCastErrorSharedWithFPURegs()
    //     0x12f68fc: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0x12f6900: r0 = NullCastErrorSharedWithFPURegs()
    //     0x12f6900: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0x12f6904: stp             q2, q4, [SP, #-0x20]!
    // 0x12f6908: SaveReg d1
    //     0x12f6908: str             q1, [SP, #-0x10]!
    // 0x12f690c: SaveReg r0
    //     0x12f690c: str             x0, [SP, #-8]!
    // 0x12f6910: r0 = AllocateDouble()
    //     0x12f6910: bl              #0x13df878  ; AllocateDoubleStub
    // 0x12f6914: mov             x3, x0
    // 0x12f6918: RestoreReg r0
    //     0x12f6918: ldr             x0, [SP], #8
    // 0x12f691c: RestoreReg d1
    //     0x12f691c: ldr             q1, [SP], #0x10
    // 0x12f6920: ldp             q2, q4, [SP], #0x20
    // 0x12f6924: b               #0x12f65f8
    // 0x12f6928: SaveReg d0
    //     0x12f6928: str             q0, [SP, #-0x10]!
    // 0x12f692c: SaveReg r0
    //     0x12f692c: str             x0, [SP, #-8]!
    // 0x12f6930: r0 = AllocateDouble()
    //     0x12f6930: bl              #0x13df878  ; AllocateDoubleStub
    // 0x12f6934: mov             x3, x0
    // 0x12f6938: RestoreReg r0
    //     0x12f6938: ldr             x0, [SP], #8
    // 0x12f693c: RestoreReg d0
    //     0x12f693c: ldr             q0, [SP], #0x10
    // 0x12f6940: b               #0x12f663c
    // 0x12f6944: stp             q0, q1, [SP, #-0x20]!
    // 0x12f6948: stp             x2, x3, [SP, #-0x10]!
    // 0x12f694c: SaveReg r0
    //     0x12f694c: str             x0, [SP, #-8]!
    // 0x12f6950: r0 = AllocateDouble()
    //     0x12f6950: bl              #0x13df878  ; AllocateDoubleStub
    // 0x12f6954: mov             x4, x0
    // 0x12f6958: RestoreReg r0
    //     0x12f6958: ldr             x0, [SP], #8
    // 0x12f695c: ldp             x2, x3, [SP], #0x10
    // 0x12f6960: ldp             q0, q1, [SP], #0x20
    // 0x12f6964: b               #0x12f669c
    // 0x12f6968: r0 = StackOverflowSharedWithFPURegs()
    //     0x12f6968: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12f696c: b               #0x12f66d8
    // 0x12f6970: stp             q1, q2, [SP, #-0x20]!
    // 0x12f6974: r0 = AllocateDouble()
    //     0x12f6974: bl              #0x13df878  ; AllocateDoubleStub
    // 0x12f6978: mov             x3, x0
    // 0x12f697c: ldp             q1, q2, [SP], #0x20
    // 0x12f6980: b               #0x12f683c
  }
}

// class id: 3261, size: 0x1c, field offset: 0x8
class _CupertinoBackGestureController<X0> extends Object {

  _ dragEnd(/* No info */) {
    // ** addr: 0xf8ebc4, size: 0x26c
    // 0xf8ebc4: EnterFrame
    //     0xf8ebc4: stp             fp, lr, [SP, #-0x10]!
    //     0xf8ebc8: mov             fp, SP
    // 0xf8ebcc: AllocStack(0x38)
    //     0xf8ebcc: sub             SP, SP, #0x38
    // 0xf8ebd0: SetupParameters(_CupertinoBackGestureController<X0> this /* r1 => r1, fp-0x8 */, dynamic _ /* d0 => d0, fp-0x28 */)
    //     0xf8ebd0: stur            x1, [fp, #-8]
    //     0xf8ebd4: stur            d0, [fp, #-0x28]
    // 0xf8ebd8: CheckStackOverflow
    //     0xf8ebd8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf8ebdc: cmp             SP, x16
    //     0xf8ebe0: b.ls            #0xf8ee20
    // 0xf8ebe4: r1 = 2
    //     0xf8ebe4: mov             x1, #2
    // 0xf8ebe8: r0 = AllocateContext()
    //     0xf8ebe8: bl              #0x13de838  ; AllocateContextStub
    // 0xf8ebec: mov             x2, x0
    // 0xf8ebf0: ldur            x1, [fp, #-8]
    // 0xf8ebf4: stur            x2, [fp, #-0x10]
    // 0xf8ebf8: StoreField: r2->field_f = r1
    //     0xf8ebf8: stur            w1, [x2, #0xf]
    // 0xf8ebfc: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xf8ebfc: ldur            w0, [x1, #0x17]
    // 0xf8ec00: DecompressPointer r0
    //     0xf8ec00: add             x0, x0, HEAP, lsl #32
    // 0xf8ec04: str             x0, [SP]
    // 0xf8ec08: ClosureCall
    //     0xf8ec08: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xf8ec0c: ldur            x2, [x0, #0x1f]
    //     0xf8ec10: blr             x2
    // 0xf8ec14: mov             x1, x0
    // 0xf8ec18: stur            x1, [fp, #-0x18]
    // 0xf8ec1c: r16 = true
    //     0xf8ec1c: add             x16, NULL, #0x20  ; true
    // 0xf8ec20: cmp             w1, w16
    // 0xf8ec24: b.eq            #0xf8ec5c
    // 0xf8ec28: ldur            x2, [fp, #-8]
    // 0xf8ec2c: LoadField: r0 = r2->field_13
    //     0xf8ec2c: ldur            w0, [x2, #0x13]
    // 0xf8ec30: DecompressPointer r0
    //     0xf8ec30: add             x0, x0, HEAP, lsl #32
    // 0xf8ec34: str             x0, [SP]
    // 0xf8ec38: ClosureCall
    //     0xf8ec38: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xf8ec3c: ldur            x2, [x0, #0x1f]
    //     0xf8ec40: blr             x2
    // 0xf8ec44: r16 = true
    //     0xf8ec44: add             x16, NULL, #0x20  ; true
    // 0xf8ec48: cmp             w0, w16
    // 0xf8ec4c: b.ne            #0xf8ed18
    // 0xf8ec50: ldur            x0, [fp, #-8]
    // 0xf8ec54: d2 = 1.000000
    //     0xf8ec54: fmov            d2, #1.00000000
    // 0xf8ec58: b               #0xf8ece0
    // 0xf8ec5c: ldur            d0, [fp, #-0x28]
    // 0xf8ec60: d1 = 0.000000
    //     0xf8ec60: eor             v1.16b, v1.16b, v1.16b
    // 0xf8ec64: fcmp            d0, d1
    // 0xf8ec68: b.ne            #0xf8ec7c
    // 0xf8ec6c: d2 = 1.000000
    //     0xf8ec6c: fmov            d2, #1.00000000
    // 0xf8ec70: fcmp            d1, d2
    // 0xf8ec74: b.lt            #0xf8ecb0
    // 0xf8ec78: b               #0xf8eca0
    // 0xf8ec7c: d2 = 1.000000
    //     0xf8ec7c: fmov            d2, #1.00000000
    // 0xf8ec80: fcmp            d1, d0
    // 0xf8ec84: b.le            #0xf8ec98
    // 0xf8ec88: fneg            d3, d0
    // 0xf8ec8c: fcmp            d3, d2
    // 0xf8ec90: b.lt            #0xf8ecb0
    // 0xf8ec94: b               #0xf8eca0
    // 0xf8ec98: fcmp            d0, d2
    // 0xf8ec9c: b.lt            #0xf8ecb0
    // 0xf8eca0: fcmp            d1, d0
    // 0xf8eca4: b.lt            #0xf8ed18
    // 0xf8eca8: ldur            x0, [fp, #-8]
    // 0xf8ecac: b               #0xf8ece0
    // 0xf8ecb0: ldur            x0, [fp, #-8]
    // 0xf8ecb4: d0 = 0.500000
    //     0xf8ecb4: fmov            d0, #0.50000000
    // 0xf8ecb8: LoadField: r1 = r0->field_b
    //     0xf8ecb8: ldur            w1, [x0, #0xb]
    // 0xf8ecbc: DecompressPointer r1
    //     0xf8ecbc: add             x1, x1, HEAP, lsl #32
    // 0xf8ecc0: LoadField: r2 = r1->field_37
    //     0xf8ecc0: ldur            w2, [x1, #0x37]
    // 0xf8ecc4: DecompressPointer r2
    //     0xf8ecc4: add             x2, x2, HEAP, lsl #32
    // 0xf8ecc8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf8eccc: cmp             w2, w16
    // 0xf8ecd0: b.eq            #0xf8ee28
    // 0xf8ecd4: LoadField: d1 = r2->field_7
    //     0xf8ecd4: ldur            d1, [x2, #7]
    // 0xf8ecd8: fcmp            d1, d0
    // 0xf8ecdc: b.le            #0xf8ed18
    // 0xf8ece0: LoadField: r2 = r0->field_b
    //     0xf8ece0: ldur            w2, [x0, #0xb]
    // 0xf8ece4: DecompressPointer r2
    //     0xf8ece4: add             x2, x2, HEAP, lsl #32
    // 0xf8ece8: stur            x2, [fp, #-0x20]
    // 0xf8ecec: r16 = Instance_Duration
    //     0xf8ecec: add             x16, PP, #0x82, lsl #12  ; [pp+0x82bb0] Obj!Duration@12c8ae1
    //     0xf8ecf0: ldr             x16, [x16, #0xbb0]
    // 0xf8ecf4: r30 = Instance_ThreePointCubic
    //     0xf8ecf4: add             lr, PP, #0xad, lsl #12  ; [pp+0xadb18] Obj!ThreePointCubic@129f401
    //     0xf8ecf8: ldr             lr, [lr, #0xb18]
    // 0xf8ecfc: stp             lr, x16, [SP]
    // 0xf8ed00: mov             x1, x2
    // 0xf8ed04: mov             v0.16b, v2.16b
    // 0xf8ed08: r4 = const [0, 0x4, 0x2, 0x2, curve, 0x3, duration, 0x2, null]
    //     0xf8ed08: ldr             x4, [PP, #0x5158]  ; [pp+0x5158] List(9) [0, 0x4, 0x2, 0x2, "curve", 0x3, "duration", 0x2, Null]
    // 0xf8ed0c: r0 = animateTo()
    //     0xf8ed0c: bl              #0x866084  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::animateTo
    // 0xf8ed10: ldur            x0, [fp, #-0x20]
    // 0xf8ed14: b               #0xf8ed90
    // 0xf8ed18: ldur            x0, [fp, #-0x18]
    // 0xf8ed1c: r16 = true
    //     0xf8ed1c: add             x16, NULL, #0x20  ; true
    // 0xf8ed20: cmp             w0, w16
    // 0xf8ed24: b.ne            #0xf8ed44
    // 0xf8ed28: ldur            x0, [fp, #-8]
    // 0xf8ed2c: LoadField: r1 = r0->field_f
    //     0xf8ed2c: ldur            w1, [x0, #0xf]
    // 0xf8ed30: DecompressPointer r1
    //     0xf8ed30: add             x1, x1, HEAP, lsl #32
    // 0xf8ed34: r16 = <Object?>
    //     0xf8ed34: ldr             x16, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0xf8ed38: stp             x1, x16, [SP]
    // 0xf8ed3c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xf8ed3c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xf8ed40: r0 = pop()
    //     0xf8ed40: bl              #0x8c87a0  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::pop
    // 0xf8ed44: ldur            x0, [fp, #-8]
    // 0xf8ed48: LoadField: r4 = r0->field_b
    //     0xf8ed48: ldur            w4, [x0, #0xb]
    // 0xf8ed4c: DecompressPointer r4
    //     0xf8ed4c: add             x4, x4, HEAP, lsl #32
    // 0xf8ed50: stur            x4, [fp, #-0x18]
    // 0xf8ed54: LoadField: r1 = r4->field_2f
    //     0xf8ed54: ldur            w1, [x4, #0x2f]
    // 0xf8ed58: DecompressPointer r1
    //     0xf8ed58: add             x1, x1, HEAP, lsl #32
    // 0xf8ed5c: cmp             w1, NULL
    // 0xf8ed60: b.eq            #0xf8ed8c
    // 0xf8ed64: LoadField: r2 = r1->field_7
    //     0xf8ed64: ldur            w2, [x1, #7]
    // 0xf8ed68: DecompressPointer r2
    //     0xf8ed68: add             x2, x2, HEAP, lsl #32
    // 0xf8ed6c: cmp             w2, NULL
    // 0xf8ed70: b.eq            #0xf8ed8c
    // 0xf8ed74: mov             x1, x4
    // 0xf8ed78: r2 = Instance_ThreePointCubic
    //     0xf8ed78: add             x2, PP, #0xad, lsl #12  ; [pp+0xadb18] Obj!ThreePointCubic@129f401
    //     0xf8ed7c: ldr             x2, [x2, #0xb18]
    // 0xf8ed80: r3 = Instance_Duration
    //     0xf8ed80: add             x3, PP, #0x82, lsl #12  ; [pp+0x82bb0] Obj!Duration@12c8ae1
    //     0xf8ed84: ldr             x3, [x3, #0xbb0]
    // 0xf8ed88: r0 = animateBack()
    //     0xf8ed88: bl              #0xf8ee30  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::animateBack
    // 0xf8ed8c: ldur            x0, [fp, #-0x18]
    // 0xf8ed90: stur            x0, [fp, #-0x18]
    // 0xf8ed94: LoadField: r1 = r0->field_2f
    //     0xf8ed94: ldur            w1, [x0, #0x2f]
    // 0xf8ed98: DecompressPointer r1
    //     0xf8ed98: add             x1, x1, HEAP, lsl #32
    // 0xf8ed9c: cmp             w1, NULL
    // 0xf8eda0: b.eq            #0xf8ee00
    // 0xf8eda4: LoadField: r2 = r1->field_7
    //     0xf8eda4: ldur            w2, [x1, #7]
    // 0xf8eda8: DecompressPointer r2
    //     0xf8eda8: add             x2, x2, HEAP, lsl #32
    // 0xf8edac: cmp             w2, NULL
    // 0xf8edb0: b.eq            #0xf8ee00
    // 0xf8edb4: ldur            x3, [fp, #-0x10]
    // 0xf8edb8: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xf8edbc: StoreField: r3->field_13 = r1
    //     0xf8edbc: stur            w1, [x3, #0x13]
    // 0xf8edc0: mov             x2, x3
    // 0xf8edc4: r1 = Function '<anonymous closure>':.
    //     0xf8edc4: add             x1, PP, #0xd1, lsl #12  ; [pp+0xd1db8] AnonymousClosure: (0xf8ee74), in [package:get/get_navigation/src/routes/get_transition_mixin.dart] CupertinoBackGestureController::dragEnd (0xf8ef14)
    //     0xf8edc8: ldr             x1, [x1, #0xdb8]
    // 0xf8edcc: r0 = AllocateClosure()
    //     0xf8edcc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf8edd0: mov             x2, x0
    // 0xf8edd4: ldur            x1, [fp, #-0x10]
    // 0xf8edd8: StoreField: r1->field_13 = r0
    //     0xf8edd8: stur            w0, [x1, #0x13]
    //     0xf8eddc: ldurb           w16, [x1, #-1]
    //     0xf8ede0: ldurb           w17, [x0, #-1]
    //     0xf8ede4: and             x16, x17, x16, lsr #2
    //     0xf8ede8: tst             x16, HEAP, lsr #32
    //     0xf8edec: b.eq            #0xf8edf4
    //     0xf8edf0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf8edf4: ldur            x1, [fp, #-0x18]
    // 0xf8edf8: r0 = addStatusListener()
    //     0xf8edf8: bl              #0x1254cc0  ; [dart:mixin_deduplication] _MixinApplication456&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::addStatusListener
    // 0xf8edfc: b               #0xf8ee10
    // 0xf8ee00: ldur            x0, [fp, #-8]
    // 0xf8ee04: LoadField: r1 = r0->field_f
    //     0xf8ee04: ldur            w1, [x0, #0xf]
    // 0xf8ee08: DecompressPointer r1
    //     0xf8ee08: add             x1, x1, HEAP, lsl #32
    // 0xf8ee0c: r0 = didStopUserGesture()
    //     0xf8ee0c: bl              #0x8c84d8  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::didStopUserGesture
    // 0xf8ee10: r0 = Null
    //     0xf8ee10: mov             x0, NULL
    // 0xf8ee14: LeaveFrame
    //     0xf8ee14: mov             SP, fp
    //     0xf8ee18: ldp             fp, lr, [SP], #0x10
    // 0xf8ee1c: ret
    //     0xf8ee1c: ret             
    // 0xf8ee20: r0 = StackOverflowSharedWithFPURegs()
    //     0xf8ee20: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xf8ee24: b               #0xf8ebe4
    // 0xf8ee28: r9 = _value
    //     0xf8ee28: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0xf8ee2c: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xf8ee2c: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
  }
  _ dragUpdate(/* No info */) {
    // ** addr: 0xf8f4c8, size: 0xa8
    // 0xf8f4c8: EnterFrame
    //     0xf8f4c8: stp             fp, lr, [SP, #-0x10]!
    //     0xf8f4cc: mov             fp, SP
    // 0xf8f4d0: CheckStackOverflow
    //     0xf8f4d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf8f4d4: cmp             SP, x16
    //     0xf8f4d8: b.ls            #0xf8f544
    // 0xf8f4dc: LoadField: r0 = r1->field_b
    //     0xf8f4dc: ldur            w0, [x1, #0xb]
    // 0xf8f4e0: DecompressPointer r0
    //     0xf8f4e0: add             x0, x0, HEAP, lsl #32
    // 0xf8f4e4: LoadField: r1 = r0->field_37
    //     0xf8f4e4: ldur            w1, [x0, #0x37]
    // 0xf8f4e8: DecompressPointer r1
    //     0xf8f4e8: add             x1, x1, HEAP, lsl #32
    // 0xf8f4ec: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf8f4f0: cmp             w1, w16
    // 0xf8f4f4: b.eq            #0xf8f54c
    // 0xf8f4f8: LoadField: d1 = r1->field_7
    //     0xf8f4f8: ldur            d1, [x1, #7]
    // 0xf8f4fc: fsub            d2, d1, d0
    // 0xf8f500: r2 = inline_Allocate_Double()
    //     0xf8f500: ldp             x2, x1, [THR, #0x60]  ; THR::top
    //     0xf8f504: add             x2, x2, #0x10
    //     0xf8f508: cmp             x1, x2
    //     0xf8f50c: b.ls            #0xf8f554
    //     0xf8f510: str             x2, [THR, #0x60]  ; THR::top
    //     0xf8f514: sub             x2, x2, #0xf
    //     0xf8f518: mov             x1, #0xe19c
    //     0xf8f51c: movk            x1, #3, lsl #16
    //     0xf8f520: stur            x1, [x2, #-1]
    // 0xf8f524: dmb             ishst
    // 0xf8f528: StoreField: r2->field_7 = d2
    //     0xf8f528: stur            d2, [x2, #7]
    // 0xf8f52c: mov             x1, x0
    // 0xf8f530: r0 = value=()
    //     0xf8f530: bl              #0x829534  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0xf8f534: r0 = Null
    //     0xf8f534: mov             x0, NULL
    // 0xf8f538: LeaveFrame
    //     0xf8f538: mov             SP, fp
    //     0xf8f53c: ldp             fp, lr, [SP], #0x10
    // 0xf8f540: ret
    //     0xf8f540: ret             
    // 0xf8f544: r0 = StackOverflowSharedWithFPURegs()
    //     0xf8f544: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xf8f548: b               #0xf8f4dc
    // 0xf8f54c: r9 = _value
    //     0xf8f54c: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0xf8f550: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xf8f550: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xf8f554: SaveReg d2
    //     0xf8f554: str             q2, [SP, #-0x10]!
    // 0xf8f558: SaveReg r0
    //     0xf8f558: str             x0, [SP, #-8]!
    // 0xf8f55c: r0 = AllocateDouble()
    //     0xf8f55c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xf8f560: mov             x2, x0
    // 0xf8f564: RestoreReg r0
    //     0xf8f564: ldr             x0, [SP], #8
    // 0xf8f568: RestoreReg d2
    //     0xf8f568: ldr             q2, [SP], #0x10
    // 0xf8f56c: b               #0xf8f528
  }
}

// class id: 3262, size: 0x8, field offset: 0x8
abstract class CupertinoRouteTransitionMixin extends Object {

  static Widget buildPageTransitions<Y0>(PageRoute<Y0>, Animation<double>, Animation<double>, Widget) {
    // ** addr: 0x119f73c, size: 0x178
    // 0x119f73c: EnterFrame
    //     0x119f73c: stp             fp, lr, [SP, #-0x10]!
    //     0x119f740: mov             fp, SP
    // 0x119f744: AllocStack(0x20)
    //     0x119f744: sub             SP, SP, #0x20
    // 0x119f748: SetupParameters([dynamic _, dynamic _, dynamic _, dynamic _ /* r1 */])
    //     0x119f748: ldur            w0, [x4, #0xf]
    //     0x119f74c: cbnz            w0, #0x119f758
    //     0x119f750: mov             x0, NULL
    //     0x119f754: b               #0x119f768
    //     0x119f758: ldur            w0, [x4, #0x17]
    //     0x119f75c: add             x1, fp, w0, sxtw #2
    //     0x119f760: ldr             x1, [x1, #0x10]
    //     0x119f764: mov             x0, x1
    //     0x119f768: ldr             x1, [fp, #0x28]
    //     0x119f76c: stur            x0, [fp, #-8]
    // 0x119f770: CheckStackOverflow
    //     0x119f770: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x119f774: cmp             SP, x16
    //     0x119f778: b.ls            #0x119f8ac
    // 0x119f77c: r1 = 1
    //     0x119f77c: mov             x1, #1
    // 0x119f780: r0 = AllocateContext()
    //     0x119f780: bl              #0x13de838  ; AllocateContextStub
    // 0x119f784: mov             x3, x0
    // 0x119f788: ldr             x2, [fp, #0x28]
    // 0x119f78c: stur            x3, [fp, #-0x10]
    // 0x119f790: StoreField: r3->field_f = r2
    //     0x119f790: stur            w2, [x3, #0xf]
    // 0x119f794: r0 = LoadClassIdInstr(r2)
    //     0x119f794: ldur            x0, [x2, #-1]
    //     0x119f798: ubfx            x0, x0, #0xc, #0x14
    // 0x119f79c: mov             x1, x2
    // 0x119f7a0: r0 = GDT[cid_x0 + -0xd25]()
    //     0x119f7a0: sub             lr, x0, #0xd25
    //     0x119f7a4: ldr             lr, [x21, lr, lsl #3]
    //     0x119f7a8: blr             lr
    // 0x119f7ac: mov             x1, x0
    // 0x119f7b0: ldr             x0, [fp, #0x28]
    // 0x119f7b4: stur            x1, [fp, #-0x18]
    // 0x119f7b8: LoadField: r2 = r0->field_97
    //     0x119f7b8: ldur            w2, [x0, #0x97]
    // 0x119f7bc: DecompressPointer r2
    //     0x119f7bc: add             x2, x2, HEAP, lsl #32
    // 0x119f7c0: tbnz            w2, #4, #0x119f808
    // 0x119f7c4: ldr             x3, [fp, #0x20]
    // 0x119f7c8: ldr             x2, [fp, #0x18]
    // 0x119f7cc: ldr             x0, [fp, #0x10]
    // 0x119f7d0: r0 = CupertinoFullscreenDialogTransition()
    //     0x119f7d0: bl              #0xb28830  ; AllocateCupertinoFullscreenDialogTransitionStub -> CupertinoFullscreenDialogTransition (size=0x1c)
    // 0x119f7d4: mov             x1, x0
    // 0x119f7d8: ldr             x0, [fp, #0x20]
    // 0x119f7dc: StoreField: r1->field_b = r0
    //     0x119f7dc: stur            w0, [x1, #0xb]
    // 0x119f7e0: ldr             x3, [fp, #0x18]
    // 0x119f7e4: StoreField: r1->field_f = r3
    //     0x119f7e4: stur            w3, [x1, #0xf]
    // 0x119f7e8: ldr             x4, [fp, #0x10]
    // 0x119f7ec: ArrayStore: r1[0] = r4  ; List_4
    //     0x119f7ec: stur            w4, [x1, #0x17]
    // 0x119f7f0: ldur            x5, [fp, #-0x18]
    // 0x119f7f4: StoreField: r1->field_13 = r5
    //     0x119f7f4: stur            w5, [x1, #0x13]
    // 0x119f7f8: mov             x0, x1
    // 0x119f7fc: LeaveFrame
    //     0x119f7fc: mov             SP, fp
    //     0x119f800: ldp             fp, lr, [SP], #0x10
    // 0x119f804: ret
    //     0x119f804: ret             
    // 0x119f808: ldr             x0, [fp, #0x20]
    // 0x119f80c: ldr             x3, [fp, #0x18]
    // 0x119f810: ldr             x4, [fp, #0x10]
    // 0x119f814: ldur            x6, [fp, #-8]
    // 0x119f818: mov             x5, x1
    // 0x119f81c: ldur            x2, [fp, #-0x10]
    // 0x119f820: r1 = Function '<anonymous closure>': static.
    //     0x119f820: add             x1, PP, #0xcd, lsl #12  ; [pp+0xcd008] AnonymousClosure: static (0x119fab0), in [package:flutter/src/cupertino/route.dart] CupertinoRouteTransitionMixin::buildPageTransitions (0x119f73c)
    //     0x119f824: ldr             x1, [x1, #8]
    // 0x119f828: r0 = AllocateClosure()
    //     0x119f828: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x119f82c: mov             x3, x0
    // 0x119f830: ldur            x0, [fp, #-8]
    // 0x119f834: stur            x3, [fp, #-0x20]
    // 0x119f838: StoreField: r3->field_b = r0
    //     0x119f838: stur            w0, [x3, #0xb]
    // 0x119f83c: ldur            x2, [fp, #-0x10]
    // 0x119f840: r1 = Function '<anonymous closure>': static.
    //     0x119f840: add             x1, PP, #0xcd, lsl #12  ; [pp+0xcd010] AnonymousClosure: static (0x119f8c0), in [package:flutter/src/cupertino/route.dart] CupertinoRouteTransitionMixin::buildPageTransitions (0x119f73c)
    //     0x119f844: ldr             x1, [x1, #0x10]
    // 0x119f848: r0 = AllocateClosure()
    //     0x119f848: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x119f84c: ldur            x1, [fp, #-8]
    // 0x119f850: stur            x0, [fp, #-0x10]
    // 0x119f854: StoreField: r0->field_b = r1
    //     0x119f854: stur            w1, [x0, #0xb]
    // 0x119f858: r0 = _CupertinoBackGestureDetector()
    //     0x119f858: bl              #0x119f8b4  ; Allocate_CupertinoBackGestureDetectorStub -> _CupertinoBackGestureDetector<X0> (size=0x1c)
    // 0x119f85c: mov             x1, x0
    // 0x119f860: ldur            x0, [fp, #-0x20]
    // 0x119f864: stur            x1, [fp, #-8]
    // 0x119f868: StoreField: r1->field_13 = r0
    //     0x119f868: stur            w0, [x1, #0x13]
    // 0x119f86c: ldur            x0, [fp, #-0x10]
    // 0x119f870: ArrayStore: r1[0] = r0  ; List_4
    //     0x119f870: stur            w0, [x1, #0x17]
    // 0x119f874: ldr             x0, [fp, #0x10]
    // 0x119f878: StoreField: r1->field_f = r0
    //     0x119f878: stur            w0, [x1, #0xf]
    // 0x119f87c: r0 = CupertinoPageTransition()
    //     0x119f87c: bl              #0xb2821c  ; AllocateCupertinoPageTransitionStub -> CupertinoPageTransition (size=0x1c)
    // 0x119f880: ldr             x1, [fp, #0x20]
    // 0x119f884: StoreField: r0->field_f = r1
    //     0x119f884: stur            w1, [x0, #0xf]
    // 0x119f888: ldr             x1, [fp, #0x18]
    // 0x119f88c: StoreField: r0->field_13 = r1
    //     0x119f88c: stur            w1, [x0, #0x13]
    // 0x119f890: ldur            x1, [fp, #-8]
    // 0x119f894: StoreField: r0->field_b = r1
    //     0x119f894: stur            w1, [x0, #0xb]
    // 0x119f898: ldur            x1, [fp, #-0x18]
    // 0x119f89c: ArrayStore: r0[0] = r1  ; List_4
    //     0x119f89c: stur            w1, [x0, #0x17]
    // 0x119f8a0: LeaveFrame
    //     0x119f8a0: mov             SP, fp
    //     0x119f8a4: ldp             fp, lr, [SP], #0x10
    // 0x119f8a8: ret
    //     0x119f8a8: ret             
    // 0x119f8ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x119f8ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x119f8b0: b               #0x119f77c
  }
  [closure] static _CupertinoBackGestureController<Y0> <anonymous closure>(dynamic) {
    // ** addr: 0x119f8c0, size: 0x54
    // 0x119f8c0: EnterFrame
    //     0x119f8c0: stp             fp, lr, [SP, #-0x10]!
    //     0x119f8c4: mov             fp, SP
    // 0x119f8c8: AllocStack(0x10)
    //     0x119f8c8: sub             SP, SP, #0x10
    // 0x119f8cc: SetupParameters([dynamic _ /* r0 */])
    //     0x119f8cc: ldr             x0, [fp, #0x10]
    //     0x119f8d0: ldur            w1, [x0, #0x17]
    //     0x119f8d4: add             x1, x1, HEAP, lsl #32
    // 0x119f8d8: CheckStackOverflow
    //     0x119f8d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x119f8dc: cmp             SP, x16
    //     0x119f8e0: b.ls            #0x119f90c
    // 0x119f8e4: LoadField: r2 = r0->field_b
    //     0x119f8e4: ldur            w2, [x0, #0xb]
    // 0x119f8e8: DecompressPointer r2
    //     0x119f8e8: add             x2, x2, HEAP, lsl #32
    // 0x119f8ec: LoadField: r0 = r1->field_f
    //     0x119f8ec: ldur            w0, [x1, #0xf]
    // 0x119f8f0: DecompressPointer r0
    //     0x119f8f0: add             x0, x0, HEAP, lsl #32
    // 0x119f8f4: stp             x0, x2, [SP]
    // 0x119f8f8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x119f8f8: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x119f8fc: r0 = _startPopGesture()
    //     0x119f8fc: bl              #0x119f914  ; [package:flutter/src/cupertino/route.dart] CupertinoRouteTransitionMixin::_startPopGesture
    // 0x119f900: LeaveFrame
    //     0x119f900: mov             SP, fp
    //     0x119f904: ldp             fp, lr, [SP], #0x10
    // 0x119f908: ret
    //     0x119f908: ret             
    // 0x119f90c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x119f90c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x119f910: b               #0x119f8e4
  }
  static _ _startPopGesture(/* No info */) {
    // ** addr: 0x119f914, size: 0x108
    // 0x119f914: EnterFrame
    //     0x119f914: stp             fp, lr, [SP, #-0x10]!
    //     0x119f918: mov             fp, SP
    // 0x119f91c: AllocStack(0x28)
    //     0x119f91c: sub             SP, SP, #0x28
    // 0x119f920: SetupParameters([dynamic _ /* r0 */])
    //     0x119f920: ldur            w0, [x4, #0xf]
    //     0x119f924: cbnz            w0, #0x119f930
    //     0x119f928: mov             x1, NULL
    //     0x119f92c: b               #0x119f93c
    //     0x119f930: ldur            w0, [x4, #0x17]
    //     0x119f934: add             x1, fp, w0, sxtw #2
    //     0x119f938: ldr             x1, [x1, #0x10]
    //     0x119f93c: ldr             x0, [fp, #0x10]
    //     0x119f940: stur            x1, [fp, #-8]
    // 0x119f944: CheckStackOverflow
    //     0x119f944: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x119f948: cmp             SP, x16
    //     0x119f94c: b.ls            #0x119fa0c
    // 0x119f950: r1 = 1
    //     0x119f950: mov             x1, #1
    // 0x119f954: r0 = AllocateContext()
    //     0x119f954: bl              #0x13de838  ; AllocateContextStub
    // 0x119f958: mov             x3, x0
    // 0x119f95c: ldr             x0, [fp, #0x10]
    // 0x119f960: stur            x3, [fp, #-0x18]
    // 0x119f964: StoreField: r3->field_f = r0
    //     0x119f964: stur            w0, [x3, #0xf]
    // 0x119f968: LoadField: r4 = r0->field_f
    //     0x119f968: ldur            w4, [x0, #0xf]
    // 0x119f96c: DecompressPointer r4
    //     0x119f96c: add             x4, x4, HEAP, lsl #32
    // 0x119f970: stur            x4, [fp, #-0x10]
    // 0x119f974: cmp             w4, NULL
    // 0x119f978: b.eq            #0x119fa14
    // 0x119f97c: mov             x2, x3
    // 0x119f980: r1 = Function '<anonymous closure>': static.
    //     0x119f980: add             x1, PP, #0xcd, lsl #12  ; [pp+0xcd018] AnonymousClosure: static (0x119fa6c), in [package:flutter/src/cupertino/route.dart] CupertinoRouteTransitionMixin::_startPopGesture (0x119f914)
    //     0x119f984: ldr             x1, [x1, #0x18]
    // 0x119f988: r0 = AllocateClosure()
    //     0x119f988: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x119f98c: mov             x3, x0
    // 0x119f990: ldur            x0, [fp, #-8]
    // 0x119f994: stur            x3, [fp, #-0x20]
    // 0x119f998: StoreField: r3->field_b = r0
    //     0x119f998: stur            w0, [x3, #0xb]
    // 0x119f99c: ldur            x2, [fp, #-0x18]
    // 0x119f9a0: r1 = Function '<anonymous closure>': static.
    //     0x119f9a0: add             x1, PP, #0xcd, lsl #12  ; [pp+0xcd020] AnonymousClosure: static (0x119fa28), in [package:flutter/src/cupertino/route.dart] CupertinoRouteTransitionMixin::_startPopGesture (0x119f914)
    //     0x119f9a4: ldr             x1, [x1, #0x20]
    // 0x119f9a8: r0 = AllocateClosure()
    //     0x119f9a8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x119f9ac: ldur            x1, [fp, #-8]
    // 0x119f9b0: stur            x0, [fp, #-0x28]
    // 0x119f9b4: StoreField: r0->field_b = r1
    //     0x119f9b4: stur            w1, [x0, #0xb]
    // 0x119f9b8: ldr             x2, [fp, #0x10]
    // 0x119f9bc: LoadField: r3 = r2->field_37
    //     0x119f9bc: ldur            w3, [x2, #0x37]
    // 0x119f9c0: DecompressPointer r3
    //     0x119f9c0: add             x3, x3, HEAP, lsl #32
    // 0x119f9c4: stur            x3, [fp, #-0x18]
    // 0x119f9c8: cmp             w3, NULL
    // 0x119f9cc: b.eq            #0x119fa18
    // 0x119f9d0: r0 = _CupertinoBackGestureController()
    //     0x119f9d0: bl              #0x119fa1c  ; Allocate_CupertinoBackGestureControllerStub -> _CupertinoBackGestureController<X0> (size=0x1c)
    // 0x119f9d4: ldur            x1, [fp, #-0x10]
    // 0x119f9d8: stur            x0, [fp, #-8]
    // 0x119f9dc: StoreField: r0->field_f = r1
    //     0x119f9dc: stur            w1, [x0, #0xf]
    // 0x119f9e0: ldur            x2, [fp, #-0x18]
    // 0x119f9e4: StoreField: r0->field_b = r2
    //     0x119f9e4: stur            w2, [x0, #0xb]
    // 0x119f9e8: ldur            x2, [fp, #-0x28]
    // 0x119f9ec: StoreField: r0->field_13 = r2
    //     0x119f9ec: stur            w2, [x0, #0x13]
    // 0x119f9f0: ldur            x2, [fp, #-0x20]
    // 0x119f9f4: ArrayStore: r0[0] = r2  ; List_4
    //     0x119f9f4: stur            w2, [x0, #0x17]
    // 0x119f9f8: r0 = didStartUserGesture()
    //     0x119f9f8: bl              #0x8cfa50  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::didStartUserGesture
    // 0x119f9fc: ldur            x0, [fp, #-8]
    // 0x119fa00: LeaveFrame
    //     0x119fa00: mov             SP, fp
    //     0x119fa04: ldp             fp, lr, [SP], #0x10
    // 0x119fa08: ret
    //     0x119fa08: ret             
    // 0x119fa0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x119fa0c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x119fa10: b               #0x119f950
    // 0x119fa14: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x119fa14: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x119fa18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x119fa18: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] static bool <anonymous closure>(dynamic) {
    // ** addr: 0x119fa28, size: 0x44
    // 0x119fa28: EnterFrame
    //     0x119fa28: stp             fp, lr, [SP, #-0x10]!
    //     0x119fa2c: mov             fp, SP
    // 0x119fa30: ldr             x0, [fp, #0x10]
    // 0x119fa34: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x119fa34: ldur            w1, [x0, #0x17]
    // 0x119fa38: DecompressPointer r1
    //     0x119fa38: add             x1, x1, HEAP, lsl #32
    // 0x119fa3c: CheckStackOverflow
    //     0x119fa3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x119fa40: cmp             SP, x16
    //     0x119fa44: b.ls            #0x119fa64
    // 0x119fa48: LoadField: r0 = r1->field_f
    //     0x119fa48: ldur            w0, [x1, #0xf]
    // 0x119fa4c: DecompressPointer r0
    //     0x119fa4c: add             x0, x0, HEAP, lsl #32
    // 0x119fa50: mov             x1, x0
    // 0x119fa54: r0 = isActive()
    //     0x119fa54: bl              #0xbae0e0  ; [package:flutter/src/widgets/navigator.dart] Route::isActive
    // 0x119fa58: LeaveFrame
    //     0x119fa58: mov             SP, fp
    //     0x119fa5c: ldp             fp, lr, [SP], #0x10
    // 0x119fa60: ret
    //     0x119fa60: ret             
    // 0x119fa64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x119fa64: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x119fa68: b               #0x119fa48
  }
  [closure] static bool <anonymous closure>(dynamic) {
    // ** addr: 0x119fa6c, size: 0x44
    // 0x119fa6c: EnterFrame
    //     0x119fa6c: stp             fp, lr, [SP, #-0x10]!
    //     0x119fa70: mov             fp, SP
    // 0x119fa74: ldr             x0, [fp, #0x10]
    // 0x119fa78: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x119fa78: ldur            w1, [x0, #0x17]
    // 0x119fa7c: DecompressPointer r1
    //     0x119fa7c: add             x1, x1, HEAP, lsl #32
    // 0x119fa80: CheckStackOverflow
    //     0x119fa80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x119fa84: cmp             SP, x16
    //     0x119fa88: b.ls            #0x119faa8
    // 0x119fa8c: LoadField: r0 = r1->field_f
    //     0x119fa8c: ldur            w0, [x1, #0xf]
    // 0x119fa90: DecompressPointer r0
    //     0x119fa90: add             x0, x0, HEAP, lsl #32
    // 0x119fa94: mov             x1, x0
    // 0x119fa98: r0 = isCurrent()
    //     0x119fa98: bl              #0x82eeb4  ; [package:flutter/src/widgets/navigator.dart] Route::isCurrent
    // 0x119fa9c: LeaveFrame
    //     0x119fa9c: mov             SP, fp
    //     0x119faa0: ldp             fp, lr, [SP], #0x10
    // 0x119faa4: ret
    //     0x119faa4: ret             
    // 0x119faa8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x119faa8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x119faac: b               #0x119fa8c
  }
  [closure] static bool <anonymous closure>(dynamic) {
    // ** addr: 0x119fab0, size: 0x64
    // 0x119fab0: EnterFrame
    //     0x119fab0: stp             fp, lr, [SP, #-0x10]!
    //     0x119fab4: mov             fp, SP
    // 0x119fab8: ldr             x0, [fp, #0x10]
    // 0x119fabc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x119fabc: ldur            w1, [x0, #0x17]
    // 0x119fac0: DecompressPointer r1
    //     0x119fac0: add             x1, x1, HEAP, lsl #32
    // 0x119fac4: CheckStackOverflow
    //     0x119fac4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x119fac8: cmp             SP, x16
    //     0x119facc: b.ls            #0x119fb0c
    // 0x119fad0: LoadField: r0 = r1->field_f
    //     0x119fad0: ldur            w0, [x1, #0xf]
    // 0x119fad4: DecompressPointer r0
    //     0x119fad4: add             x0, x0, HEAP, lsl #32
    // 0x119fad8: r1 = LoadClassIdInstr(r0)
    //     0x119fad8: ldur            x1, [x0, #-1]
    //     0x119fadc: ubfx            x1, x1, #0xc, #0x14
    // 0x119fae0: mov             x16, x0
    // 0x119fae4: mov             x0, x1
    // 0x119fae8: mov             x1, x16
    // 0x119faec: r0 = GDT[cid_x0 + 0x12db6]()
    //     0x119faec: mov             x17, #0x2db6
    //     0x119faf0: movk            x17, #1, lsl #16
    //     0x119faf4: add             lr, x0, x17
    //     0x119faf8: ldr             lr, [x21, lr, lsl #3]
    //     0x119fafc: blr             lr
    // 0x119fb00: LeaveFrame
    //     0x119fb00: mov             SP, fp
    //     0x119fb04: ldp             fp, lr, [SP], #0x10
    // 0x119fb08: ret
    //     0x119fb08: ret             
    // 0x119fb0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x119fb0c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x119fb10: b               #0x119fad0
  }
}

// class id: 5240, size: 0xc, field offset: 0x8
//   const constructor, 
class _CupertinoEdgeShadowDecoration extends Decoration {

  static late DecorationTween kTween; // offset: 0x748
  _ImmutableList<Color> field_8;

  static DecorationTween kTween() {
    // ** addr: 0xf6cce8, size: 0x38
    // 0xf6cce8: EnterFrame
    //     0xf6cce8: stp             fp, lr, [SP, #-0x10]!
    //     0xf6ccec: mov             fp, SP
    // 0xf6ccf0: r1 = <Decoration>
    //     0xf6ccf0: add             x1, PP, #0x99, lsl #12  ; [pp+0x991d0] TypeArguments: <Decoration>
    //     0xf6ccf4: ldr             x1, [x1, #0x1d0]
    // 0xf6ccf8: r0 = DecorationTween()
    //     0xf6ccf8: bl              #0xf6cd20  ; AllocateDecorationTweenStub -> DecorationTween (size=0x14)
    // 0xf6ccfc: r1 = Instance__CupertinoEdgeShadowDecoration
    //     0xf6ccfc: add             x1, PP, #0xad, lsl #12  ; [pp+0xadb30] Obj!_CupertinoEdgeShadowDecoration@12b36e1
    //     0xf6cd00: ldr             x1, [x1, #0xb30]
    // 0xf6cd04: StoreField: r0->field_b = r1
    //     0xf6cd04: stur            w1, [x0, #0xb]
    // 0xf6cd08: r1 = Instance__CupertinoEdgeShadowDecoration
    //     0xf6cd08: add             x1, PP, #0xad, lsl #12  ; [pp+0xadb38] Obj!_CupertinoEdgeShadowDecoration@12b36d1
    //     0xf6cd0c: ldr             x1, [x1, #0xb38]
    // 0xf6cd10: StoreField: r0->field_f = r1
    //     0xf6cd10: stur            w1, [x0, #0xf]
    // 0xf6cd14: LeaveFrame
    //     0xf6cd14: mov             SP, fp
    //     0xf6cd18: ldp             fp, lr, [SP], #0x10
    // 0xf6cd1c: ret
    //     0xf6cd1c: ret             
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x11631e4, size: 0x54c
    // 0x11631e4: EnterFrame
    //     0x11631e4: stp             fp, lr, [SP, #-0x10]!
    //     0x11631e8: mov             fp, SP
    // 0x11631ec: AllocStack(0x58)
    //     0x11631ec: sub             SP, SP, #0x58
    // 0x11631f0: SetupParameters(dynamic _ /* r1 => r0, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0x11631f0: mov             x0, x1
    //     0x11631f4: stur            x1, [fp, #-0x10]
    //     0x11631f8: stur            x2, [fp, #-0x18]
    // 0x11631fc: CheckStackOverflow
    //     0x11631fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1163200: cmp             SP, x16
    //     0x1163204: b.ls            #0x1163700
    // 0x1163208: r1 = inline_Allocate_Double()
    //     0x1163208: ldp             x1, x3, [THR, #0x60]  ; THR::top
    //     0x116320c: add             x1, x1, #0x10
    //     0x1163210: cmp             x3, x1
    //     0x1163214: b.ls            #0x1163708
    //     0x1163218: str             x1, [THR, #0x60]  ; THR::top
    //     0x116321c: sub             x1, x1, #0xf
    //     0x1163220: mov             x3, #0xe19c
    //     0x1163224: movk            x3, #3, lsl #16
    //     0x1163228: stur            x3, [x1, #-1]
    // 0x116322c: dmb             ishst
    // 0x1163230: StoreField: r1->field_7 = d0
    //     0x1163230: stur            d0, [x1, #7]
    // 0x1163234: stur            x1, [fp, #-8]
    // 0x1163238: r1 = 1
    //     0x1163238: mov             x1, #1
    // 0x116323c: r0 = AllocateContext()
    //     0x116323c: bl              #0x13de838  ; AllocateContextStub
    // 0x1163240: mov             x3, x0
    // 0x1163244: ldur            x0, [fp, #-8]
    // 0x1163248: stur            x3, [fp, #-0x28]
    // 0x116324c: StoreField: r3->field_f = r0
    //     0x116324c: stur            w0, [x3, #0xf]
    // 0x1163250: ldur            x4, [fp, #-0x10]
    // 0x1163254: ldur            x0, [fp, #-0x18]
    // 0x1163258: cmp             w4, w0
    // 0x116325c: b.ne            #0x1163270
    // 0x1163260: mov             x0, x4
    // 0x1163264: LeaveFrame
    //     0x1163264: mov             SP, fp
    //     0x1163268: ldp             fp, lr, [SP], #0x10
    // 0x116326c: ret
    //     0x116326c: ret             
    // 0x1163270: cmp             w4, NULL
    // 0x1163274: b.ne            #0x11633c4
    // 0x1163278: LoadField: r4 = r0->field_7
    //     0x1163278: ldur            w4, [x0, #7]
    // 0x116327c: DecompressPointer r4
    //     0x116327c: add             x4, x4, HEAP, lsl #32
    // 0x1163280: stur            x4, [fp, #-8]
    // 0x1163284: cmp             w4, NULL
    // 0x1163288: b.eq            #0x11633b8
    // 0x116328c: mov             x2, x3
    // 0x1163290: r1 = Function '<anonymous closure>': static.
    //     0x1163290: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa39d0] AnonymousClosure: (0x1162734), in [package:flutter/src/painting/gradient.dart] SweepGradient::scale (0x1305db0)
    //     0x1163294: ldr             x1, [x1, #0x9d0]
    // 0x1163298: r0 = AllocateClosure()
    //     0x1163298: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x116329c: r16 = <Color>
    //     0x116329c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x11632a0: ldr             x16, [x16, #0xa90]
    // 0x11632a4: ldur            lr, [fp, #-8]
    // 0x11632a8: stp             lr, x16, [SP, #8]
    // 0x11632ac: str             x0, [SP]
    // 0x11632b0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x11632b0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x11632b4: r0 = map()
    //     0x11632b4: bl              #0xba574c  ; [dart:collection] ListBase::map
    // 0x11632b8: mov             x3, x0
    // 0x11632bc: stur            x3, [fp, #-0x20]
    // 0x11632c0: LoadField: r4 = r3->field_7
    //     0x11632c0: ldur            w4, [x3, #7]
    // 0x11632c4: DecompressPointer r4
    //     0x11632c4: add             x4, x4, HEAP, lsl #32
    // 0x11632c8: mov             x0, x3
    // 0x11632cc: stur            x4, [fp, #-8]
    // 0x11632d0: r2 = Null
    //     0x11632d0: mov             x2, NULL
    // 0x11632d4: r1 = Null
    //     0x11632d4: mov             x1, NULL
    // 0x11632d8: cmp             w0, NULL
    // 0x11632dc: b.eq            #0x1163374
    // 0x11632e0: branchIfSmi(r0, 0x1163374)
    //     0x11632e0: tbz             w0, #0, #0x1163374
    // 0x11632e4: r3 = LoadClassIdInstr(r0)
    //     0x11632e4: ldur            x3, [x0, #-1]
    //     0x11632e8: ubfx            x3, x3, #0xc, #0x14
    // 0x11632ec: r17 = 7724
    //     0x11632ec: mov             x17, #0x1e2c
    // 0x11632f0: cmp             x3, x17
    // 0x11632f4: b.eq            #0x116337c
    // 0x11632f8: r4 = LoadClassIdInstr(r0)
    //     0x11632f8: ldur            x4, [x0, #-1]
    //     0x11632fc: ubfx            x4, x4, #0xc, #0x14
    // 0x1163300: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x1163304: ldr             x3, [x3, #0x18]
    // 0x1163308: ldr             x3, [x3, x4, lsl #3]
    // 0x116330c: LoadField: r3 = r3->field_2b
    //     0x116330c: ldur            w3, [x3, #0x2b]
    // 0x1163310: DecompressPointer r3
    //     0x1163310: add             x3, x3, HEAP, lsl #32
    // 0x1163314: cmp             w3, NULL
    // 0x1163318: b.eq            #0x1163374
    // 0x116331c: LoadField: r3 = r3->field_f
    //     0x116331c: ldur            w3, [x3, #0xf]
    // 0x1163320: lsr             x3, x3, #3
    // 0x1163324: r17 = 7724
    //     0x1163324: mov             x17, #0x1e2c
    // 0x1163328: cmp             x3, x17
    // 0x116332c: b.eq            #0x116337c
    // 0x1163330: r3 = SubtypeTestCache
    //     0x1163330: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa39d8] SubtypeTestCache
    //     0x1163334: ldr             x3, [x3, #0x9d8]
    // 0x1163338: r30 = Subtype1TestCacheStub
    //     0x1163338: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x116333c: LoadField: r30 = r30->field_7
    //     0x116333c: ldur            lr, [lr, #7]
    // 0x1163340: blr             lr
    // 0x1163344: cmp             w7, NULL
    // 0x1163348: b.eq            #0x1163354
    // 0x116334c: tbnz            w7, #4, #0x1163374
    // 0x1163350: b               #0x116337c
    // 0x1163354: r8 = EfficientLengthIterable
    //     0x1163354: add             x8, PP, #0xa3, lsl #12  ; [pp+0xa39e0] Type: EfficientLengthIterable
    //     0x1163358: ldr             x8, [x8, #0x9e0]
    // 0x116335c: r3 = SubtypeTestCache
    //     0x116335c: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa39e8] SubtypeTestCache
    //     0x1163360: ldr             x3, [x3, #0x9e8]
    // 0x1163364: r30 = InstanceOfStub
    //     0x1163364: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x1163368: LoadField: r30 = r30->field_7
    //     0x1163368: ldur            lr, [lr, #7]
    // 0x116336c: blr             lr
    // 0x1163370: b               #0x1163380
    // 0x1163374: r0 = false
    //     0x1163374: add             x0, NULL, #0x30  ; false
    // 0x1163378: b               #0x1163380
    // 0x116337c: r0 = true
    //     0x116337c: add             x0, NULL, #0x20  ; true
    // 0x1163380: tbnz            w0, #4, #0x1163394
    // 0x1163384: ldur            x1, [fp, #-8]
    // 0x1163388: ldur            x2, [fp, #-0x20]
    // 0x116338c: r0 = _GrowableList._ofEfficientLengthIterable()
    //     0x116338c: bl              #0x7d732c  ; [dart:core] _GrowableList::_GrowableList._ofEfficientLengthIterable
    // 0x1163390: b               #0x11633a0
    // 0x1163394: ldur            x1, [fp, #-8]
    // 0x1163398: ldur            x2, [fp, #-0x20]
    // 0x116339c: r0 = _GrowableList._ofOther()
    //     0x116339c: bl              #0x7d94b4  ; [dart:core] _GrowableList::_GrowableList._ofOther
    // 0x11633a0: stur            x0, [fp, #-8]
    // 0x11633a4: r0 = _CupertinoEdgeShadowDecoration()
    //     0x11633a4: bl              #0x1163730  ; Allocate_CupertinoEdgeShadowDecorationStub -> _CupertinoEdgeShadowDecoration (size=0xc)
    // 0x11633a8: mov             x1, x0
    // 0x11633ac: ldur            x0, [fp, #-8]
    // 0x11633b0: StoreField: r1->field_7 = r0
    //     0x11633b0: stur            w0, [x1, #7]
    // 0x11633b4: mov             x0, x1
    // 0x11633b8: LeaveFrame
    //     0x11633b8: mov             SP, fp
    //     0x11633bc: ldp             fp, lr, [SP], #0x10
    // 0x11633c0: ret
    //     0x11633c0: ret             
    // 0x11633c4: cmp             w0, NULL
    // 0x11633c8: b.ne            #0x1163520
    // 0x11633cc: LoadField: r0 = r4->field_7
    //     0x11633cc: ldur            w0, [x4, #7]
    // 0x11633d0: DecompressPointer r0
    //     0x11633d0: add             x0, x0, HEAP, lsl #32
    // 0x11633d4: stur            x0, [fp, #-8]
    // 0x11633d8: cmp             w0, NULL
    // 0x11633dc: b.ne            #0x11633e8
    // 0x11633e0: mov             x0, x4
    // 0x11633e4: b               #0x1163514
    // 0x11633e8: mov             x2, x3
    // 0x11633ec: r1 = Function '<anonymous closure>': static.
    //     0x11633ec: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa39f0] AnonymousClosure: static (0x116373c), in [package:flutter/src/cupertino/route.dart] _CupertinoEdgeShadowDecoration::lerp (0x11631e4)
    //     0x11633f0: ldr             x1, [x1, #0x9f0]
    // 0x11633f4: r0 = AllocateClosure()
    //     0x11633f4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11633f8: r16 = <Color>
    //     0x11633f8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x11633fc: ldr             x16, [x16, #0xa90]
    // 0x1163400: ldur            lr, [fp, #-8]
    // 0x1163404: stp             lr, x16, [SP, #8]
    // 0x1163408: str             x0, [SP]
    // 0x116340c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x116340c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x1163410: r0 = map()
    //     0x1163410: bl              #0xba574c  ; [dart:collection] ListBase::map
    // 0x1163414: mov             x3, x0
    // 0x1163418: stur            x3, [fp, #-0x20]
    // 0x116341c: LoadField: r4 = r3->field_7
    //     0x116341c: ldur            w4, [x3, #7]
    // 0x1163420: DecompressPointer r4
    //     0x1163420: add             x4, x4, HEAP, lsl #32
    // 0x1163424: mov             x0, x3
    // 0x1163428: stur            x4, [fp, #-8]
    // 0x116342c: r2 = Null
    //     0x116342c: mov             x2, NULL
    // 0x1163430: r1 = Null
    //     0x1163430: mov             x1, NULL
    // 0x1163434: cmp             w0, NULL
    // 0x1163438: b.eq            #0x11634d0
    // 0x116343c: branchIfSmi(r0, 0x11634d0)
    //     0x116343c: tbz             w0, #0, #0x11634d0
    // 0x1163440: r3 = LoadClassIdInstr(r0)
    //     0x1163440: ldur            x3, [x0, #-1]
    //     0x1163444: ubfx            x3, x3, #0xc, #0x14
    // 0x1163448: r17 = 7724
    //     0x1163448: mov             x17, #0x1e2c
    // 0x116344c: cmp             x3, x17
    // 0x1163450: b.eq            #0x11634d8
    // 0x1163454: r4 = LoadClassIdInstr(r0)
    //     0x1163454: ldur            x4, [x0, #-1]
    //     0x1163458: ubfx            x4, x4, #0xc, #0x14
    // 0x116345c: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x1163460: ldr             x3, [x3, #0x18]
    // 0x1163464: ldr             x3, [x3, x4, lsl #3]
    // 0x1163468: LoadField: r3 = r3->field_2b
    //     0x1163468: ldur            w3, [x3, #0x2b]
    // 0x116346c: DecompressPointer r3
    //     0x116346c: add             x3, x3, HEAP, lsl #32
    // 0x1163470: cmp             w3, NULL
    // 0x1163474: b.eq            #0x11634d0
    // 0x1163478: LoadField: r3 = r3->field_f
    //     0x1163478: ldur            w3, [x3, #0xf]
    // 0x116347c: lsr             x3, x3, #3
    // 0x1163480: r17 = 7724
    //     0x1163480: mov             x17, #0x1e2c
    // 0x1163484: cmp             x3, x17
    // 0x1163488: b.eq            #0x11634d8
    // 0x116348c: r3 = SubtypeTestCache
    //     0x116348c: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa39f8] SubtypeTestCache
    //     0x1163490: ldr             x3, [x3, #0x9f8]
    // 0x1163494: r30 = Subtype1TestCacheStub
    //     0x1163494: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x1163498: LoadField: r30 = r30->field_7
    //     0x1163498: ldur            lr, [lr, #7]
    // 0x116349c: blr             lr
    // 0x11634a0: cmp             w7, NULL
    // 0x11634a4: b.eq            #0x11634b0
    // 0x11634a8: tbnz            w7, #4, #0x11634d0
    // 0x11634ac: b               #0x11634d8
    // 0x11634b0: r8 = EfficientLengthIterable
    //     0x11634b0: add             x8, PP, #0xa3, lsl #12  ; [pp+0xa3a00] Type: EfficientLengthIterable
    //     0x11634b4: ldr             x8, [x8, #0xa00]
    // 0x11634b8: r3 = SubtypeTestCache
    //     0x11634b8: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa3a08] SubtypeTestCache
    //     0x11634bc: ldr             x3, [x3, #0xa08]
    // 0x11634c0: r30 = InstanceOfStub
    //     0x11634c0: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x11634c4: LoadField: r30 = r30->field_7
    //     0x11634c4: ldur            lr, [lr, #7]
    // 0x11634c8: blr             lr
    // 0x11634cc: b               #0x11634dc
    // 0x11634d0: r0 = false
    //     0x11634d0: add             x0, NULL, #0x30  ; false
    // 0x11634d4: b               #0x11634dc
    // 0x11634d8: r0 = true
    //     0x11634d8: add             x0, NULL, #0x20  ; true
    // 0x11634dc: tbnz            w0, #4, #0x11634f0
    // 0x11634e0: ldur            x1, [fp, #-8]
    // 0x11634e4: ldur            x2, [fp, #-0x20]
    // 0x11634e8: r0 = _GrowableList._ofEfficientLengthIterable()
    //     0x11634e8: bl              #0x7d732c  ; [dart:core] _GrowableList::_GrowableList._ofEfficientLengthIterable
    // 0x11634ec: b               #0x11634fc
    // 0x11634f0: ldur            x1, [fp, #-8]
    // 0x11634f4: ldur            x2, [fp, #-0x20]
    // 0x11634f8: r0 = _GrowableList._ofOther()
    //     0x11634f8: bl              #0x7d94b4  ; [dart:core] _GrowableList::_GrowableList._ofOther
    // 0x11634fc: stur            x0, [fp, #-8]
    // 0x1163500: r0 = _CupertinoEdgeShadowDecoration()
    //     0x1163500: bl              #0x1163730  ; Allocate_CupertinoEdgeShadowDecorationStub -> _CupertinoEdgeShadowDecoration (size=0xc)
    // 0x1163504: mov             x1, x0
    // 0x1163508: ldur            x0, [fp, #-8]
    // 0x116350c: StoreField: r1->field_7 = r0
    //     0x116350c: stur            w0, [x1, #7]
    // 0x1163510: mov             x0, x1
    // 0x1163514: LeaveFrame
    //     0x1163514: mov             SP, fp
    //     0x1163518: ldp             fp, lr, [SP], #0x10
    // 0x116351c: ret
    //     0x116351c: ret             
    // 0x1163520: r1 = <Color>
    //     0x1163520: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x1163524: ldr             x1, [x1, #0xa90]
    // 0x1163528: r2 = 0
    //     0x1163528: mov             x2, #0
    // 0x116352c: r0 = _GrowableList()
    //     0x116352c: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x1163530: mov             x1, x0
    // 0x1163534: ldur            x0, [fp, #-0x18]
    // 0x1163538: stur            x1, [fp, #-0x38]
    // 0x116353c: LoadField: r2 = r0->field_7
    //     0x116353c: ldur            w2, [x0, #7]
    // 0x1163540: DecompressPointer r2
    //     0x1163540: add             x2, x2, HEAP, lsl #32
    // 0x1163544: stur            x2, [fp, #-0x20]
    // 0x1163548: cmp             w2, NULL
    // 0x116354c: b.eq            #0x1163724
    // 0x1163550: ldur            x0, [fp, #-0x10]
    // 0x1163554: LoadField: r3 = r0->field_7
    //     0x1163554: ldur            w3, [x0, #7]
    // 0x1163558: DecompressPointer r3
    //     0x1163558: add             x3, x3, HEAP, lsl #32
    // 0x116355c: stur            x3, [fp, #-8]
    // 0x1163560: r5 = 0
    //     0x1163560: mov             x5, #0
    // 0x1163564: ldur            x4, [fp, #-0x28]
    // 0x1163568: stur            x5, [fp, #-0x30]
    // 0x116356c: CheckStackOverflow
    //     0x116356c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1163570: cmp             SP, x16
    //     0x1163574: b.ls            #0x1163728
    // 0x1163578: r0 = LoadClassIdInstr(r2)
    //     0x1163578: ldur            x0, [x2, #-1]
    //     0x116357c: ubfx            x0, x0, #0xc, #0x14
    // 0x1163580: str             x2, [SP]
    // 0x1163584: r0 = GDT[cid_x0 + 0xf078]()
    //     0x1163584: mov             x17, #0xf078
    //     0x1163588: add             lr, x0, x17
    //     0x116358c: ldr             lr, [x21, lr, lsl #3]
    //     0x1163590: blr             lr
    // 0x1163594: r1 = LoadInt32Instr(r0)
    //     0x1163594: sbfx            x1, x0, #1, #0x1f
    // 0x1163598: ldur            x2, [fp, #-0x30]
    // 0x116359c: cmp             x2, x1
    // 0x11635a0: b.ge            #0x11636e4
    // 0x11635a4: ldur            x3, [fp, #-8]
    // 0x11635a8: cmp             w3, NULL
    // 0x11635ac: b.ne            #0x11635b8
    // 0x11635b0: r6 = Null
    //     0x11635b0: mov             x6, NULL
    // 0x11635b4: b               #0x11635f0
    // 0x11635b8: r0 = BoxInt64Instr(r2)
    //     0x11635b8: sbfiz           x0, x2, #1, #0x1f
    //     0x11635bc: cmp             x2, x0, asr #1
    //     0x11635c0: b.eq            #0x11635cc
    //     0x11635c4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x11635c8: stur            x2, [x0, #7]
    // 0x11635cc: r1 = LoadClassIdInstr(r3)
    //     0x11635cc: ldur            x1, [x3, #-1]
    //     0x11635d0: ubfx            x1, x1, #0xc, #0x14
    // 0x11635d4: stp             x0, x3, [SP]
    // 0x11635d8: mov             x0, x1
    // 0x11635dc: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x11635dc: sub             lr, x0, #0xdfd
    //     0x11635e0: ldr             lr, [x21, lr, lsl #3]
    //     0x11635e4: blr             lr
    // 0x11635e8: mov             x6, x0
    // 0x11635ec: ldur            x2, [fp, #-0x30]
    // 0x11635f0: ldur            x5, [fp, #-0x28]
    // 0x11635f4: ldur            x3, [fp, #-0x38]
    // 0x11635f8: ldur            x4, [fp, #-0x20]
    // 0x11635fc: stur            x6, [fp, #-0x10]
    // 0x1163600: r0 = BoxInt64Instr(r2)
    //     0x1163600: sbfiz           x0, x2, #1, #0x1f
    //     0x1163604: cmp             x2, x0, asr #1
    //     0x1163608: b.eq            #0x1163614
    //     0x116360c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1163610: stur            x2, [x0, #7]
    // 0x1163614: r1 = LoadClassIdInstr(r4)
    //     0x1163614: ldur            x1, [x4, #-1]
    //     0x1163618: ubfx            x1, x1, #0xc, #0x14
    // 0x116361c: stp             x0, x4, [SP]
    // 0x1163620: mov             x0, x1
    // 0x1163624: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x1163624: sub             lr, x0, #0xdfd
    //     0x1163628: ldr             lr, [x21, lr, lsl #3]
    //     0x116362c: blr             lr
    // 0x1163630: mov             x1, x0
    // 0x1163634: ldur            x0, [fp, #-0x28]
    // 0x1163638: LoadField: r3 = r0->field_f
    //     0x1163638: ldur            w3, [x0, #0xf]
    // 0x116363c: DecompressPointer r3
    //     0x116363c: add             x3, x3, HEAP, lsl #32
    // 0x1163640: mov             x2, x1
    // 0x1163644: ldur            x1, [fp, #-0x10]
    // 0x1163648: r0 = lerp()
    //     0x1163648: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x116364c: mov             x2, x0
    // 0x1163650: ldur            x0, [fp, #-0x38]
    // 0x1163654: stur            x2, [fp, #-0x10]
    // 0x1163658: LoadField: r1 = r0->field_b
    //     0x1163658: ldur            w1, [x0, #0xb]
    // 0x116365c: LoadField: r3 = r0->field_f
    //     0x116365c: ldur            w3, [x0, #0xf]
    // 0x1163660: DecompressPointer r3
    //     0x1163660: add             x3, x3, HEAP, lsl #32
    // 0x1163664: LoadField: r4 = r3->field_b
    //     0x1163664: ldur            w4, [x3, #0xb]
    // 0x1163668: r3 = LoadInt32Instr(r1)
    //     0x1163668: sbfx            x3, x1, #1, #0x1f
    // 0x116366c: stur            x3, [fp, #-0x40]
    // 0x1163670: r1 = LoadInt32Instr(r4)
    //     0x1163670: sbfx            x1, x4, #1, #0x1f
    // 0x1163674: cmp             x3, x1
    // 0x1163678: b.ne            #0x1163684
    // 0x116367c: mov             x1, x0
    // 0x1163680: r0 = _growToNextCapacity()
    //     0x1163680: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x1163684: ldur            x2, [fp, #-0x38]
    // 0x1163688: ldur            x4, [fp, #-0x30]
    // 0x116368c: ldur            x3, [fp, #-0x40]
    // 0x1163690: add             x0, x3, #1
    // 0x1163694: lsl             x1, x0, #1
    // 0x1163698: StoreField: r2->field_b = r1
    //     0x1163698: stur            w1, [x2, #0xb]
    // 0x116369c: LoadField: r1 = r2->field_f
    //     0x116369c: ldur            w1, [x2, #0xf]
    // 0x11636a0: DecompressPointer r1
    //     0x11636a0: add             x1, x1, HEAP, lsl #32
    // 0x11636a4: ldur            x0, [fp, #-0x10]
    // 0x11636a8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x11636a8: add             x25, x1, x3, lsl #2
    //     0x11636ac: add             x25, x25, #0xf
    //     0x11636b0: str             w0, [x25]
    //     0x11636b4: tbz             w0, #0, #0x11636d0
    //     0x11636b8: ldurb           w16, [x1, #-1]
    //     0x11636bc: ldurb           w17, [x0, #-1]
    //     0x11636c0: and             x16, x17, x16, lsr #2
    //     0x11636c4: tst             x16, HEAP, lsr #32
    //     0x11636c8: b.eq            #0x11636d0
    //     0x11636cc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x11636d0: add             x5, x4, #1
    // 0x11636d4: mov             x1, x2
    // 0x11636d8: ldur            x2, [fp, #-0x20]
    // 0x11636dc: ldur            x3, [fp, #-8]
    // 0x11636e0: b               #0x1163564
    // 0x11636e4: ldur            x2, [fp, #-0x38]
    // 0x11636e8: r0 = _CupertinoEdgeShadowDecoration()
    //     0x11636e8: bl              #0x1163730  ; Allocate_CupertinoEdgeShadowDecorationStub -> _CupertinoEdgeShadowDecoration (size=0xc)
    // 0x11636ec: ldur            x1, [fp, #-0x38]
    // 0x11636f0: StoreField: r0->field_7 = r1
    //     0x11636f0: stur            w1, [x0, #7]
    // 0x11636f4: LeaveFrame
    //     0x11636f4: mov             SP, fp
    //     0x11636f8: ldp             fp, lr, [SP], #0x10
    // 0x11636fc: ret
    //     0x11636fc: ret             
    // 0x1163700: r0 = StackOverflowSharedWithFPURegs()
    //     0x1163700: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1163704: b               #0x1163208
    // 0x1163708: SaveReg d0
    //     0x1163708: str             q0, [SP, #-0x10]!
    // 0x116370c: stp             x0, x2, [SP, #-0x10]!
    // 0x1163710: r0 = AllocateDouble()
    //     0x1163710: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1163714: mov             x1, x0
    // 0x1163718: ldp             x0, x2, [SP], #0x10
    // 0x116371c: RestoreReg d0
    //     0x116371c: ldr             q0, [SP], #0x10
    // 0x1163720: b               #0x1163230
    // 0x1163724: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1163724: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x1163728: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1163728: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x116372c: b               #0x1163578
  }
  [closure] static Color <anonymous closure>(dynamic, Color) {
    // ** addr: 0x116373c, size: 0x94
    // 0x116373c: EnterFrame
    //     0x116373c: stp             fp, lr, [SP, #-0x10]!
    //     0x1163740: mov             fp, SP
    // 0x1163744: d0 = 1.000000
    //     0x1163744: fmov            d0, #1.00000000
    // 0x1163748: ldr             x0, [fp, #0x18]
    // 0x116374c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x116374c: ldur            w1, [x0, #0x17]
    // 0x1163750: DecompressPointer r1
    //     0x1163750: add             x1, x1, HEAP, lsl #32
    // 0x1163754: CheckStackOverflow
    //     0x1163754: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1163758: cmp             SP, x16
    //     0x116375c: b.ls            #0x11637b4
    // 0x1163760: LoadField: r0 = r1->field_f
    //     0x1163760: ldur            w0, [x1, #0xf]
    // 0x1163764: DecompressPointer r0
    //     0x1163764: add             x0, x0, HEAP, lsl #32
    // 0x1163768: LoadField: d1 = r0->field_7
    //     0x1163768: ldur            d1, [x0, #7]
    // 0x116376c: fsub            d2, d0, d1
    // 0x1163770: r3 = inline_Allocate_Double()
    //     0x1163770: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0x1163774: add             x3, x3, #0x10
    //     0x1163778: cmp             x0, x3
    //     0x116377c: b.ls            #0x11637bc
    //     0x1163780: str             x3, [THR, #0x60]  ; THR::top
    //     0x1163784: sub             x3, x3, #0xf
    //     0x1163788: mov             x0, #0xe19c
    //     0x116378c: movk            x0, #3, lsl #16
    //     0x1163790: stur            x0, [x3, #-1]
    // 0x1163794: dmb             ishst
    // 0x1163798: StoreField: r3->field_7 = d2
    //     0x1163798: stur            d2, [x3, #7]
    // 0x116379c: ldr             x2, [fp, #0x10]
    // 0x11637a0: r1 = Null
    //     0x11637a0: mov             x1, NULL
    // 0x11637a4: r0 = lerp()
    //     0x11637a4: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x11637a8: LeaveFrame
    //     0x11637a8: mov             SP, fp
    //     0x11637ac: ldp             fp, lr, [SP], #0x10
    // 0x11637b0: ret
    //     0x11637b0: ret             
    // 0x11637b4: r0 = StackOverflowSharedWithFPURegs()
    //     0x11637b4: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x11637b8: b               #0x1163760
    // 0x11637bc: SaveReg d2
    //     0x11637bc: str             q2, [SP, #-0x10]!
    // 0x11637c0: r0 = AllocateDouble()
    //     0x11637c0: bl              #0x13df878  ; AllocateDoubleStub
    // 0x11637c4: mov             x3, x0
    // 0x11637c8: RestoreReg d2
    //     0x11637c8: ldr             q2, [SP], #0x10
    // 0x11637cc: b               #0x1163798
  }
  _ ==(/* No info */) {
    // ** addr: 0x1262c4c, size: 0xe0
    // 0x1262c4c: EnterFrame
    //     0x1262c4c: stp             fp, lr, [SP, #-0x10]!
    //     0x1262c50: mov             fp, SP
    // 0x1262c54: AllocStack(0x10)
    //     0x1262c54: sub             SP, SP, #0x10
    // 0x1262c58: CheckStackOverflow
    //     0x1262c58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1262c5c: cmp             SP, x16
    //     0x1262c60: b.ls            #0x1262d24
    // 0x1262c64: ldr             x0, [fp, #0x10]
    // 0x1262c68: cmp             w0, NULL
    // 0x1262c6c: b.ne            #0x1262c80
    // 0x1262c70: r0 = false
    //     0x1262c70: add             x0, NULL, #0x30  ; false
    // 0x1262c74: LeaveFrame
    //     0x1262c74: mov             SP, fp
    //     0x1262c78: ldp             fp, lr, [SP], #0x10
    // 0x1262c7c: ret
    //     0x1262c7c: ret             
    // 0x1262c80: str             x0, [SP]
    // 0x1262c84: r0 = runtimeType()
    //     0x1262c84: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x1262c88: r1 = LoadClassIdInstr(r0)
    //     0x1262c88: ldur            x1, [x0, #-1]
    //     0x1262c8c: ubfx            x1, x1, #0xc, #0x14
    // 0x1262c90: r16 = _CupertinoEdgeShadowDecoration
    //     0x1262c90: add             x16, PP, #0x8d, lsl #12  ; [pp+0x8d188] Type: _CupertinoEdgeShadowDecoration
    //     0x1262c94: ldr             x16, [x16, #0x188]
    // 0x1262c98: stp             x16, x0, [SP]
    // 0x1262c9c: mov             x0, x1
    // 0x1262ca0: mov             lr, x0
    // 0x1262ca4: ldr             lr, [x21, lr, lsl #3]
    // 0x1262ca8: blr             lr
    // 0x1262cac: tbz             w0, #4, #0x1262cc0
    // 0x1262cb0: r0 = false
    //     0x1262cb0: add             x0, NULL, #0x30  ; false
    // 0x1262cb4: LeaveFrame
    //     0x1262cb4: mov             SP, fp
    //     0x1262cb8: ldp             fp, lr, [SP], #0x10
    // 0x1262cbc: ret
    //     0x1262cbc: ret             
    // 0x1262cc0: ldr             x0, [fp, #0x10]
    // 0x1262cc4: r1 = 60
    //     0x1262cc4: mov             x1, #0x3c
    // 0x1262cc8: branchIfSmi(r0, 0x1262cd4)
    //     0x1262cc8: tbz             w0, #0, #0x1262cd4
    // 0x1262ccc: r1 = LoadClassIdInstr(r0)
    //     0x1262ccc: ldur            x1, [x0, #-1]
    //     0x1262cd0: ubfx            x1, x1, #0xc, #0x14
    // 0x1262cd4: r17 = 5240
    //     0x1262cd4: mov             x17, #0x1478
    // 0x1262cd8: cmp             x1, x17
    // 0x1262cdc: b.ne            #0x1262d14
    // 0x1262ce0: ldr             x1, [fp, #0x18]
    // 0x1262ce4: LoadField: r2 = r0->field_7
    //     0x1262ce4: ldur            w2, [x0, #7]
    // 0x1262ce8: DecompressPointer r2
    //     0x1262ce8: add             x2, x2, HEAP, lsl #32
    // 0x1262cec: LoadField: r0 = r1->field_7
    //     0x1262cec: ldur            w0, [x1, #7]
    // 0x1262cf0: DecompressPointer r0
    //     0x1262cf0: add             x0, x0, HEAP, lsl #32
    // 0x1262cf4: r1 = LoadClassIdInstr(r2)
    //     0x1262cf4: ldur            x1, [x2, #-1]
    //     0x1262cf8: ubfx            x1, x1, #0xc, #0x14
    // 0x1262cfc: stp             x0, x2, [SP]
    // 0x1262d00: mov             x0, x1
    // 0x1262d04: mov             lr, x0
    // 0x1262d08: ldr             lr, [x21, lr, lsl #3]
    // 0x1262d0c: blr             lr
    // 0x1262d10: b               #0x1262d18
    // 0x1262d14: r0 = false
    //     0x1262d14: add             x0, NULL, #0x30  ; false
    // 0x1262d18: LeaveFrame
    //     0x1262d18: mov             SP, fp
    //     0x1262d1c: ldp             fp, lr, [SP], #0x10
    // 0x1262d20: ret
    //     0x1262d20: ret             
    // 0x1262d24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1262d24: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1262d28: b               #0x1262c64
  }
}

// class id: 5483, size: 0x1c, field offset: 0x14
class _CupertinoBackGestureDetectorState<C1X0> extends State<C1X0> {

  late HorizontalDragGestureRecognizer _recognizer; // offset: 0x18

  _ build(/* No info */) {
    // ** addr: 0xde702c, size: 0x16c
    // 0xde702c: EnterFrame
    //     0xde702c: stp             fp, lr, [SP, #-0x10]!
    //     0xde7030: mov             fp, SP
    // 0xde7034: AllocStack(0x20)
    //     0xde7034: sub             SP, SP, #0x20
    // 0xde7038: SetupParameters(_CupertinoBackGestureDetectorState<C1X0> this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xde7038: mov             x0, x2
    //     0xde703c: stur            x2, [fp, #-0x10]
    //     0xde7040: mov             x2, x1
    //     0xde7044: stur            x1, [fp, #-8]
    // 0xde7048: CheckStackOverflow
    //     0xde7048: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde704c: cmp             SP, x16
    //     0xde7050: b.ls            #0xde718c
    // 0xde7054: mov             x1, x0
    // 0xde7058: r0 = of()
    //     0xde7058: bl              #0x87371c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0xde705c: LoadField: r1 = r0->field_7
    //     0xde705c: ldur            x1, [x0, #7]
    // 0xde7060: cmp             x1, #0
    // 0xde7064: b.gt            #0xde707c
    // 0xde7068: ldur            x1, [fp, #-0x10]
    // 0xde706c: r0 = paddingOf()
    //     0xde706c: bl              #0xd1a984  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::paddingOf
    // 0xde7070: ArrayLoad: d0 = r0[0]  ; List_8
    //     0xde7070: ldur            d0, [x0, #0x17]
    // 0xde7074: mov             v1.16b, v0.16b
    // 0xde7078: b               #0xde708c
    // 0xde707c: ldur            x1, [fp, #-0x10]
    // 0xde7080: r0 = paddingOf()
    //     0xde7080: bl              #0xd1a984  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::paddingOf
    // 0xde7084: LoadField: d0 = r0->field_7
    //     0xde7084: ldur            d0, [x0, #7]
    // 0xde7088: mov             v1.16b, v0.16b
    // 0xde708c: ldur            x2, [fp, #-8]
    // 0xde7090: d0 = 20.000000
    //     0xde7090: fmov            d0, #20.00000000
    // 0xde7094: LoadField: r0 = r2->field_b
    //     0xde7094: ldur            w0, [x2, #0xb]
    // 0xde7098: DecompressPointer r0
    //     0xde7098: add             x0, x0, HEAP, lsl #32
    // 0xde709c: cmp             w0, NULL
    // 0xde70a0: b.eq            #0xde7194
    // 0xde70a4: LoadField: r1 = r0->field_f
    //     0xde70a4: ldur            w1, [x0, #0xf]
    // 0xde70a8: DecompressPointer r1
    //     0xde70a8: add             x1, x1, HEAP, lsl #32
    // 0xde70ac: stur            x1, [fp, #-0x10]
    // 0xde70b0: fmax            v2.2d, v1.2d, v0.2d
    // 0xde70b4: stur            d2, [fp, #-0x20]
    // 0xde70b8: r0 = Listener()
    //     0xde70b8: bl              #0xd37624  ; AllocateListenerStub -> Listener (size=0x38)
    // 0xde70bc: ldur            x2, [fp, #-8]
    // 0xde70c0: r1 = Function '_handlePointerDown@111053933':.
    //     0xde70c0: add             x1, PP, #0xd1, lsl #12  ; [pp+0xd1d70] AnonymousClosure: (0xde71a4), in [package:flutter/src/cupertino/route.dart] _CupertinoBackGestureDetectorState::_handlePointerDown (0xde71e0)
    //     0xde70c4: ldr             x1, [x1, #0xd70]
    // 0xde70c8: stur            x0, [fp, #-8]
    // 0xde70cc: r0 = AllocateClosure()
    //     0xde70cc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xde70d0: mov             x1, x0
    // 0xde70d4: ldur            x0, [fp, #-8]
    // 0xde70d8: StoreField: r0->field_f = r1
    //     0xde70d8: stur            w1, [x0, #0xf]
    // 0xde70dc: r1 = Instance_HitTestBehavior
    //     0xde70dc: add             x1, PP, #0x15, lsl #12  ; [pp+0x15508] Obj!HitTestBehavior@12c43e1
    //     0xde70e0: ldr             x1, [x1, #0x508]
    // 0xde70e4: StoreField: r0->field_33 = r1
    //     0xde70e4: stur            w1, [x0, #0x33]
    // 0xde70e8: r0 = PositionedDirectional()
    //     0xde70e8: bl              #0xde7198  ; AllocatePositionedDirectionalStub -> PositionedDirectional (size=0x38)
    // 0xde70ec: stur            x0, [fp, #-0x18]
    // 0xde70f0: StoreField: r0->field_b = rZR
    //     0xde70f0: stur            xzr, [x0, #0xb]
    // 0xde70f4: StoreField: r0->field_13 = rZR
    //     0xde70f4: stur            xzr, [x0, #0x13]
    // 0xde70f8: StoreField: r0->field_1f = rZR
    //     0xde70f8: stur            xzr, [x0, #0x1f]
    // 0xde70fc: ldur            d0, [fp, #-0x20]
    // 0xde7100: StoreField: r0->field_27 = d0
    //     0xde7100: stur            d0, [x0, #0x27]
    // 0xde7104: ldur            x1, [fp, #-8]
    // 0xde7108: StoreField: r0->field_33 = r1
    //     0xde7108: stur            w1, [x0, #0x33]
    // 0xde710c: r1 = Null
    //     0xde710c: mov             x1, NULL
    // 0xde7110: r2 = 4
    //     0xde7110: mov             x2, #4
    // 0xde7114: r0 = AllocateArray()
    //     0xde7114: bl              #0x13df928  ; AllocateArrayStub
    // 0xde7118: mov             x2, x0
    // 0xde711c: ldur            x0, [fp, #-0x10]
    // 0xde7120: stur            x2, [fp, #-8]
    // 0xde7124: StoreField: r2->field_f = r0
    //     0xde7124: stur            w0, [x2, #0xf]
    // 0xde7128: ldur            x0, [fp, #-0x18]
    // 0xde712c: StoreField: r2->field_13 = r0
    //     0xde712c: stur            w0, [x2, #0x13]
    // 0xde7130: r1 = <Widget>
    //     0xde7130: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xde7134: r0 = AllocateGrowableArray()
    //     0xde7134: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xde7138: mov             x1, x0
    // 0xde713c: ldur            x0, [fp, #-8]
    // 0xde7140: stur            x1, [fp, #-0x10]
    // 0xde7144: StoreField: r1->field_f = r0
    //     0xde7144: stur            w0, [x1, #0xf]
    // 0xde7148: r0 = 4
    //     0xde7148: mov             x0, #4
    // 0xde714c: StoreField: r1->field_b = r0
    //     0xde714c: stur            w0, [x1, #0xb]
    // 0xde7150: r0 = Stack()
    //     0xde7150: bl              #0xd1a854  ; AllocateStackStub -> Stack (size=0x20)
    // 0xde7154: r1 = Instance_AlignmentDirectional
    //     0xde7154: add             x1, PP, #0x15, lsl #12  ; [pp+0x158d8] Obj!AlignmentDirectional@129e611
    //     0xde7158: ldr             x1, [x1, #0x8d8]
    // 0xde715c: StoreField: r0->field_f = r1
    //     0xde715c: stur            w1, [x0, #0xf]
    // 0xde7160: r1 = Instance_StackFit
    //     0xde7160: add             x1, PP, #0x94, lsl #12  ; [pp+0x94de8] Obj!StackFit@12c4261
    //     0xde7164: ldr             x1, [x1, #0xde8]
    // 0xde7168: ArrayStore: r0[0] = r1  ; List_4
    //     0xde7168: stur            w1, [x0, #0x17]
    // 0xde716c: r1 = Instance_Clip
    //     0xde716c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xde7170: ldr             x1, [x1, #0x850]
    // 0xde7174: StoreField: r0->field_1b = r1
    //     0xde7174: stur            w1, [x0, #0x1b]
    // 0xde7178: ldur            x1, [fp, #-0x10]
    // 0xde717c: StoreField: r0->field_b = r1
    //     0xde717c: stur            w1, [x0, #0xb]
    // 0xde7180: LeaveFrame
    //     0xde7180: mov             SP, fp
    //     0xde7184: ldp             fp, lr, [SP], #0x10
    // 0xde7188: ret
    //     0xde7188: ret             
    // 0xde718c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde718c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde7190: b               #0xde7054
    // 0xde7194: r0 = NullCastErrorSharedWithFPURegs()
    //     0xde7194: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  [closure] void _handlePointerDown(dynamic, PointerDownEvent) {
    // ** addr: 0xde71a4, size: 0x3c
    // 0xde71a4: EnterFrame
    //     0xde71a4: stp             fp, lr, [SP, #-0x10]!
    //     0xde71a8: mov             fp, SP
    // 0xde71ac: ldr             x0, [fp, #0x18]
    // 0xde71b0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xde71b0: ldur            w1, [x0, #0x17]
    // 0xde71b4: DecompressPointer r1
    //     0xde71b4: add             x1, x1, HEAP, lsl #32
    // 0xde71b8: CheckStackOverflow
    //     0xde71b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde71bc: cmp             SP, x16
    //     0xde71c0: b.ls            #0xde71d8
    // 0xde71c4: ldr             x2, [fp, #0x10]
    // 0xde71c8: r0 = _handlePointerDown()
    //     0xde71c8: bl              #0xde71e0  ; [package:flutter/src/cupertino/route.dart] _CupertinoBackGestureDetectorState::_handlePointerDown
    // 0xde71cc: LeaveFrame
    //     0xde71cc: mov             SP, fp
    //     0xde71d0: ldp             fp, lr, [SP], #0x10
    // 0xde71d4: ret
    //     0xde71d4: ret             
    // 0xde71d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde71d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde71dc: b               #0xde71c4
  }
  _ _handlePointerDown(/* No info */) {
    // ** addr: 0xde71e0, size: 0xa0
    // 0xde71e0: EnterFrame
    //     0xde71e0: stp             fp, lr, [SP, #-0x10]!
    //     0xde71e4: mov             fp, SP
    // 0xde71e8: AllocStack(0x18)
    //     0xde71e8: sub             SP, SP, #0x18
    // 0xde71ec: SetupParameters(_CupertinoBackGestureDetectorState<C1X0> this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xde71ec: stur            x1, [fp, #-8]
    //     0xde71f0: stur            x2, [fp, #-0x10]
    // 0xde71f4: CheckStackOverflow
    //     0xde71f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde71f8: cmp             SP, x16
    //     0xde71fc: b.ls            #0xde7268
    // 0xde7200: LoadField: r0 = r1->field_b
    //     0xde7200: ldur            w0, [x1, #0xb]
    // 0xde7204: DecompressPointer r0
    //     0xde7204: add             x0, x0, HEAP, lsl #32
    // 0xde7208: cmp             w0, NULL
    // 0xde720c: b.eq            #0xde7270
    // 0xde7210: LoadField: r3 = r0->field_13
    //     0xde7210: ldur            w3, [x0, #0x13]
    // 0xde7214: DecompressPointer r3
    //     0xde7214: add             x3, x3, HEAP, lsl #32
    // 0xde7218: str             x3, [SP]
    // 0xde721c: mov             x0, x3
    // 0xde7220: ClosureCall
    //     0xde7220: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xde7224: ldur            x2, [x0, #0x1f]
    //     0xde7228: blr             x2
    // 0xde722c: r16 = true
    //     0xde722c: add             x16, NULL, #0x20  ; true
    // 0xde7230: cmp             w0, w16
    // 0xde7234: b.ne            #0xde7258
    // 0xde7238: ldur            x0, [fp, #-8]
    // 0xde723c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xde723c: ldur            w1, [x0, #0x17]
    // 0xde7240: DecompressPointer r1
    //     0xde7240: add             x1, x1, HEAP, lsl #32
    // 0xde7244: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xde7248: cmp             w1, w16
    // 0xde724c: b.eq            #0xde7274
    // 0xde7250: ldur            x2, [fp, #-0x10]
    // 0xde7254: r0 = addPointer()
    //     0xde7254: bl              #0xd04e70  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::addPointer
    // 0xde7258: r0 = Null
    //     0xde7258: mov             x0, NULL
    // 0xde725c: LeaveFrame
    //     0xde725c: mov             SP, fp
    //     0xde7260: ldp             fp, lr, [SP], #0x10
    // 0xde7264: ret
    //     0xde7264: ret             
    // 0xde7268: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde7268: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde726c: b               #0xde7200
    // 0xde7270: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde7270: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xde7274: r9 = _recognizer
    //     0xde7274: add             x9, PP, #0xd1, lsl #12  ; [pp+0xd1d78] Field <_CupertinoBackGestureDetectorState@111053933._recognizer@111053933>: late (offset: 0x18)
    //     0xde7278: ldr             x9, [x9, #0xd78]
    // 0xde727c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xde727c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0xf8e9fc, size: 0x130
    // 0xf8e9fc: EnterFrame
    //     0xf8e9fc: stp             fp, lr, [SP, #-0x10]!
    //     0xf8ea00: mov             fp, SP
    // 0xf8ea04: AllocStack(0x10)
    //     0xf8ea04: sub             SP, SP, #0x10
    // 0xf8ea08: SetupParameters(_CupertinoBackGestureDetectorState<C1X0> this /* r1 => r2, fp-0x8 */)
    //     0xf8ea08: mov             x2, x1
    //     0xf8ea0c: stur            x1, [fp, #-8]
    // 0xf8ea10: CheckStackOverflow
    //     0xf8ea10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf8ea14: cmp             SP, x16
    //     0xf8ea18: b.ls            #0xf8eb24
    // 0xf8ea1c: r0 = HorizontalDragGestureRecognizer()
    //     0xf8ea1c: bl              #0xb8d854  ; AllocateHorizontalDragGestureRecognizerStub -> HorizontalDragGestureRecognizer (size=0x90)
    // 0xf8ea20: mov             x1, x0
    // 0xf8ea24: r2 = Null
    //     0xf8ea24: mov             x2, NULL
    // 0xf8ea28: stur            x0, [fp, #-0x10]
    // 0xf8ea2c: r0 = DragGestureRecognizer()
    //     0xf8ea2c: bl              #0xb8d344  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::DragGestureRecognizer
    // 0xf8ea30: ldur            x2, [fp, #-8]
    // 0xf8ea34: r1 = Function '_handleDragStart@111053933':.
    //     0xf8ea34: add             x1, PP, #0xd1, lsl #12  ; [pp+0xd1d98] AnonymousClosure: (0xf8f570), in [package:flutter/src/cupertino/route.dart] _CupertinoBackGestureDetectorState::_handleDragStart (0xf8f5ac)
    //     0xf8ea38: ldr             x1, [x1, #0xd98]
    // 0xf8ea3c: r0 = AllocateClosure()
    //     0xf8ea3c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf8ea40: ldur            x3, [fp, #-0x10]
    // 0xf8ea44: StoreField: r3->field_2f = r0
    //     0xf8ea44: stur            w0, [x3, #0x2f]
    //     0xf8ea48: ldurb           w16, [x3, #-1]
    //     0xf8ea4c: ldurb           w17, [x0, #-1]
    //     0xf8ea50: and             x16, x17, x16, lsr #2
    //     0xf8ea54: tst             x16, HEAP, lsr #32
    //     0xf8ea58: b.eq            #0xf8ea60
    //     0xf8ea5c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xf8ea60: ldur            x2, [fp, #-8]
    // 0xf8ea64: r1 = Function '_handleDragUpdate@111053933':.
    //     0xf8ea64: add             x1, PP, #0xd1, lsl #12  ; [pp+0xd1da0] AnonymousClosure: (0xf8f3b0), in [package:flutter/src/cupertino/route.dart] _CupertinoBackGestureDetectorState::_handleDragUpdate (0xf8f3ec)
    //     0xf8ea68: ldr             x1, [x1, #0xda0]
    // 0xf8ea6c: r0 = AllocateClosure()
    //     0xf8ea6c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf8ea70: ldur            x3, [fp, #-0x10]
    // 0xf8ea74: StoreField: r3->field_33 = r0
    //     0xf8ea74: stur            w0, [x3, #0x33]
    //     0xf8ea78: ldurb           w16, [x3, #-1]
    //     0xf8ea7c: ldurb           w17, [x0, #-1]
    //     0xf8ea80: and             x16, x17, x16, lsr #2
    //     0xf8ea84: tst             x16, HEAP, lsr #32
    //     0xf8ea88: b.eq            #0xf8ea90
    //     0xf8ea8c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xf8ea90: ldur            x2, [fp, #-8]
    // 0xf8ea94: r1 = Function '_handleDragEnd@111053933':.
    //     0xf8ea94: add             x1, PP, #0xd1, lsl #12  ; [pp+0xd1da8] AnonymousClosure: (0xf8f220), in [package:flutter/src/cupertino/route.dart] _CupertinoBackGestureDetectorState::_handleDragEnd (0xf8f25c)
    //     0xf8ea98: ldr             x1, [x1, #0xda8]
    // 0xf8ea9c: r0 = AllocateClosure()
    //     0xf8ea9c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf8eaa0: ldur            x3, [fp, #-0x10]
    // 0xf8eaa4: StoreField: r3->field_37 = r0
    //     0xf8eaa4: stur            w0, [x3, #0x37]
    //     0xf8eaa8: ldurb           w16, [x3, #-1]
    //     0xf8eaac: ldurb           w17, [x0, #-1]
    //     0xf8eab0: and             x16, x17, x16, lsr #2
    //     0xf8eab4: tst             x16, HEAP, lsr #32
    //     0xf8eab8: b.eq            #0xf8eac0
    //     0xf8eabc: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xf8eac0: ldur            x2, [fp, #-8]
    // 0xf8eac4: r1 = Function '_handleDragCancel@111053933':.
    //     0xf8eac4: add             x1, PP, #0xd1, lsl #12  ; [pp+0xd1db0] AnonymousClosure: (0xf8eb2c), in [package:flutter/src/cupertino/route.dart] _CupertinoBackGestureDetectorState::_handleDragCancel (0xf8eb64)
    //     0xf8eac8: ldr             x1, [x1, #0xdb0]
    // 0xf8eacc: r0 = AllocateClosure()
    //     0xf8eacc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf8ead0: ldur            x1, [fp, #-0x10]
    // 0xf8ead4: StoreField: r1->field_3b = r0
    //     0xf8ead4: stur            w0, [x1, #0x3b]
    //     0xf8ead8: ldurb           w16, [x1, #-1]
    //     0xf8eadc: ldurb           w17, [x0, #-1]
    //     0xf8eae0: and             x16, x17, x16, lsr #2
    //     0xf8eae4: tst             x16, HEAP, lsr #32
    //     0xf8eae8: b.eq            #0xf8eaf0
    //     0xf8eaec: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf8eaf0: mov             x0, x1
    // 0xf8eaf4: ldur            x1, [fp, #-8]
    // 0xf8eaf8: ArrayStore: r1[0] = r0  ; List_4
    //     0xf8eaf8: stur            w0, [x1, #0x17]
    //     0xf8eafc: ldurb           w16, [x1, #-1]
    //     0xf8eb00: ldurb           w17, [x0, #-1]
    //     0xf8eb04: and             x16, x17, x16, lsr #2
    //     0xf8eb08: tst             x16, HEAP, lsr #32
    //     0xf8eb0c: b.eq            #0xf8eb14
    //     0xf8eb10: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf8eb14: r0 = Null
    //     0xf8eb14: mov             x0, NULL
    // 0xf8eb18: LeaveFrame
    //     0xf8eb18: mov             SP, fp
    //     0xf8eb1c: ldp             fp, lr, [SP], #0x10
    // 0xf8eb20: ret
    //     0xf8eb20: ret             
    // 0xf8eb24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf8eb24: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf8eb28: b               #0xf8ea1c
  }
  [closure] void _handleDragCancel(dynamic) {
    // ** addr: 0xf8eb2c, size: 0x38
    // 0xf8eb2c: EnterFrame
    //     0xf8eb2c: stp             fp, lr, [SP, #-0x10]!
    //     0xf8eb30: mov             fp, SP
    // 0xf8eb34: ldr             x0, [fp, #0x10]
    // 0xf8eb38: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf8eb38: ldur            w1, [x0, #0x17]
    // 0xf8eb3c: DecompressPointer r1
    //     0xf8eb3c: add             x1, x1, HEAP, lsl #32
    // 0xf8eb40: CheckStackOverflow
    //     0xf8eb40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf8eb44: cmp             SP, x16
    //     0xf8eb48: b.ls            #0xf8eb5c
    // 0xf8eb4c: r0 = _handleDragCancel()
    //     0xf8eb4c: bl              #0xf8eb64  ; [package:flutter/src/cupertino/route.dart] _CupertinoBackGestureDetectorState::_handleDragCancel
    // 0xf8eb50: LeaveFrame
    //     0xf8eb50: mov             SP, fp
    //     0xf8eb54: ldp             fp, lr, [SP], #0x10
    // 0xf8eb58: ret
    //     0xf8eb58: ret             
    // 0xf8eb5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf8eb5c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf8eb60: b               #0xf8eb4c
  }
  _ _handleDragCancel(/* No info */) {
    // ** addr: 0xf8eb64, size: 0x60
    // 0xf8eb64: EnterFrame
    //     0xf8eb64: stp             fp, lr, [SP, #-0x10]!
    //     0xf8eb68: mov             fp, SP
    // 0xf8eb6c: AllocStack(0x8)
    //     0xf8eb6c: sub             SP, SP, #8
    // 0xf8eb70: SetupParameters(_CupertinoBackGestureDetectorState<C1X0> this /* r1 => r0, fp-0x8 */)
    //     0xf8eb70: mov             x0, x1
    //     0xf8eb74: stur            x1, [fp, #-8]
    // 0xf8eb78: CheckStackOverflow
    //     0xf8eb78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf8eb7c: cmp             SP, x16
    //     0xf8eb80: b.ls            #0xf8ebbc
    // 0xf8eb84: LoadField: r1 = r0->field_13
    //     0xf8eb84: ldur            w1, [x0, #0x13]
    // 0xf8eb88: DecompressPointer r1
    //     0xf8eb88: add             x1, x1, HEAP, lsl #32
    // 0xf8eb8c: cmp             w1, NULL
    // 0xf8eb90: b.ne            #0xf8eb9c
    // 0xf8eb94: mov             x1, x0
    // 0xf8eb98: b               #0xf8eba8
    // 0xf8eb9c: d0 = 0.000000
    //     0xf8eb9c: eor             v0.16b, v0.16b, v0.16b
    // 0xf8eba0: r0 = dragEnd()
    //     0xf8eba0: bl              #0xf8ebc4  ; [package:flutter/src/cupertino/route.dart] _CupertinoBackGestureController::dragEnd
    // 0xf8eba4: ldur            x1, [fp, #-8]
    // 0xf8eba8: StoreField: r1->field_13 = rNULL
    //     0xf8eba8: stur            NULL, [x1, #0x13]
    // 0xf8ebac: r0 = Null
    //     0xf8ebac: mov             x0, NULL
    // 0xf8ebb0: LeaveFrame
    //     0xf8ebb0: mov             SP, fp
    //     0xf8ebb4: ldp             fp, lr, [SP], #0x10
    // 0xf8ebb8: ret
    //     0xf8ebb8: ret             
    // 0xf8ebbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf8ebbc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf8ebc0: b               #0xf8eb84
  }
  [closure] void _handleDragEnd(dynamic, DragEndDetails) {
    // ** addr: 0xf8f220, size: 0x3c
    // 0xf8f220: EnterFrame
    //     0xf8f220: stp             fp, lr, [SP, #-0x10]!
    //     0xf8f224: mov             fp, SP
    // 0xf8f228: ldr             x0, [fp, #0x18]
    // 0xf8f22c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf8f22c: ldur            w1, [x0, #0x17]
    // 0xf8f230: DecompressPointer r1
    //     0xf8f230: add             x1, x1, HEAP, lsl #32
    // 0xf8f234: CheckStackOverflow
    //     0xf8f234: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf8f238: cmp             SP, x16
    //     0xf8f23c: b.ls            #0xf8f254
    // 0xf8f240: ldr             x2, [fp, #0x10]
    // 0xf8f244: r0 = _handleDragEnd()
    //     0xf8f244: bl              #0xf8f25c  ; [package:flutter/src/cupertino/route.dart] _CupertinoBackGestureDetectorState::_handleDragEnd
    // 0xf8f248: LeaveFrame
    //     0xf8f248: mov             SP, fp
    //     0xf8f24c: ldp             fp, lr, [SP], #0x10
    // 0xf8f250: ret
    //     0xf8f250: ret             
    // 0xf8f254: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf8f254: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf8f258: b               #0xf8f240
  }
  _ _handleDragEnd(/* No info */) {
    // ** addr: 0xf8f25c, size: 0xe4
    // 0xf8f25c: EnterFrame
    //     0xf8f25c: stp             fp, lr, [SP, #-0x10]!
    //     0xf8f260: mov             fp, SP
    // 0xf8f264: AllocStack(0x18)
    //     0xf8f264: sub             SP, SP, #0x18
    // 0xf8f268: SetupParameters(_CupertinoBackGestureDetectorState<C1X0> this /* r1 => r0, fp-0x10 */)
    //     0xf8f268: mov             x0, x1
    //     0xf8f26c: stur            x1, [fp, #-0x10]
    // 0xf8f270: CheckStackOverflow
    //     0xf8f270: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf8f274: cmp             SP, x16
    //     0xf8f278: b.ls            #0xf8f32c
    // 0xf8f27c: LoadField: r3 = r0->field_13
    //     0xf8f27c: ldur            w3, [x0, #0x13]
    // 0xf8f280: DecompressPointer r3
    //     0xf8f280: add             x3, x3, HEAP, lsl #32
    // 0xf8f284: stur            x3, [fp, #-8]
    // 0xf8f288: cmp             w3, NULL
    // 0xf8f28c: b.eq            #0xf8f334
    // 0xf8f290: LoadField: r1 = r2->field_b
    //     0xf8f290: ldur            w1, [x2, #0xb]
    // 0xf8f294: DecompressPointer r1
    //     0xf8f294: add             x1, x1, HEAP, lsl #32
    // 0xf8f298: LoadField: r2 = r1->field_7
    //     0xf8f298: ldur            w2, [x1, #7]
    // 0xf8f29c: DecompressPointer r2
    //     0xf8f29c: add             x2, x2, HEAP, lsl #32
    // 0xf8f2a0: LoadField: d0 = r2->field_7
    //     0xf8f2a0: ldur            d0, [x2, #7]
    // 0xf8f2a4: stur            d0, [fp, #-0x18]
    // 0xf8f2a8: LoadField: r1 = r0->field_f
    //     0xf8f2a8: ldur            w1, [x0, #0xf]
    // 0xf8f2ac: DecompressPointer r1
    //     0xf8f2ac: add             x1, x1, HEAP, lsl #32
    // 0xf8f2b0: cmp             w1, NULL
    // 0xf8f2b4: b.eq            #0xf8f338
    // 0xf8f2b8: r0 = renderObject()
    //     0xf8f2b8: bl              #0x123f10c  ; [package:flutter/src/widgets/framework.dart] Element::renderObject
    // 0xf8f2bc: r1 = LoadClassIdInstr(r0)
    //     0xf8f2bc: ldur            x1, [x0, #-1]
    //     0xf8f2c0: ubfx            x1, x1, #0xc, #0x14
    // 0xf8f2c4: r17 = -4710
    //     0xf8f2c4: mov             x17, #-0x1266
    // 0xf8f2c8: add             x16, x1, x17
    // 0xf8f2cc: cmp             x16, #0x109
    // 0xf8f2d0: b.hi            #0xf8f2e4
    // 0xf8f2d4: mov             x1, x0
    // 0xf8f2d8: r0 = size()
    //     0xf8f2d8: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xf8f2dc: mov             x1, x0
    // 0xf8f2e0: b               #0xf8f2e8
    // 0xf8f2e4: r1 = Null
    //     0xf8f2e4: mov             x1, NULL
    // 0xf8f2e8: ldur            x0, [fp, #-0x10]
    // 0xf8f2ec: ldur            d0, [fp, #-0x18]
    // 0xf8f2f0: cmp             w1, NULL
    // 0xf8f2f4: b.eq            #0xf8f33c
    // 0xf8f2f8: LoadField: d1 = r1->field_7
    //     0xf8f2f8: ldur            d1, [x1, #7]
    // 0xf8f2fc: fdiv            d2, d0, d1
    // 0xf8f300: mov             x1, x0
    // 0xf8f304: mov             v0.16b, v2.16b
    // 0xf8f308: r0 = _convertToLogical()
    //     0xf8f308: bl              #0xf8f340  ; [package:flutter/src/cupertino/route.dart] _CupertinoBackGestureDetectorState::_convertToLogical
    // 0xf8f30c: ldur            x1, [fp, #-8]
    // 0xf8f310: r0 = dragEnd()
    //     0xf8f310: bl              #0xf8ebc4  ; [package:flutter/src/cupertino/route.dart] _CupertinoBackGestureController::dragEnd
    // 0xf8f314: ldur            x1, [fp, #-0x10]
    // 0xf8f318: StoreField: r1->field_13 = rNULL
    //     0xf8f318: stur            NULL, [x1, #0x13]
    // 0xf8f31c: r0 = Null
    //     0xf8f31c: mov             x0, NULL
    // 0xf8f320: LeaveFrame
    //     0xf8f320: mov             SP, fp
    //     0xf8f324: ldp             fp, lr, [SP], #0x10
    // 0xf8f328: ret
    //     0xf8f328: ret             
    // 0xf8f32c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf8f32c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf8f330: b               #0xf8f27c
    // 0xf8f334: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf8f334: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf8f338: r0 = NullCastErrorSharedWithFPURegs()
    //     0xf8f338: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xf8f33c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xf8f33c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  _ _convertToLogical(/* No info */) {
    // ** addr: 0xf8f340, size: 0x70
    // 0xf8f340: EnterFrame
    //     0xf8f340: stp             fp, lr, [SP, #-0x10]!
    //     0xf8f344: mov             fp, SP
    // 0xf8f348: AllocStack(0x8)
    //     0xf8f348: sub             SP, SP, #8
    // 0xf8f34c: SetupParameters(dynamic _ /* d0 => d0, fp-0x8 */)
    //     0xf8f34c: stur            d0, [fp, #-8]
    // 0xf8f350: CheckStackOverflow
    //     0xf8f350: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf8f354: cmp             SP, x16
    //     0xf8f358: b.ls            #0xf8f3a4
    // 0xf8f35c: LoadField: r0 = r1->field_f
    //     0xf8f35c: ldur            w0, [x1, #0xf]
    // 0xf8f360: DecompressPointer r0
    //     0xf8f360: add             x0, x0, HEAP, lsl #32
    // 0xf8f364: cmp             w0, NULL
    // 0xf8f368: b.eq            #0xf8f3ac
    // 0xf8f36c: mov             x1, x0
    // 0xf8f370: r0 = of()
    //     0xf8f370: bl              #0x87371c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0xf8f374: LoadField: r1 = r0->field_7
    //     0xf8f374: ldur            x1, [x0, #7]
    // 0xf8f378: cmp             x1, #0
    // 0xf8f37c: b.gt            #0xf8f390
    // 0xf8f380: ldur            d1, [fp, #-8]
    // 0xf8f384: fneg            d2, d1
    // 0xf8f388: mov             v0.16b, v2.16b
    // 0xf8f38c: b               #0xf8f398
    // 0xf8f390: ldur            d1, [fp, #-8]
    // 0xf8f394: mov             v0.16b, v1.16b
    // 0xf8f398: LeaveFrame
    //     0xf8f398: mov             SP, fp
    //     0xf8f39c: ldp             fp, lr, [SP], #0x10
    // 0xf8f3a0: ret
    //     0xf8f3a0: ret             
    // 0xf8f3a4: r0 = StackOverflowSharedWithFPURegs()
    //     0xf8f3a4: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xf8f3a8: b               #0xf8f35c
    // 0xf8f3ac: r0 = NullCastErrorSharedWithFPURegs()
    //     0xf8f3ac: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  [closure] void _handleDragUpdate(dynamic, DragUpdateDetails) {
    // ** addr: 0xf8f3b0, size: 0x3c
    // 0xf8f3b0: EnterFrame
    //     0xf8f3b0: stp             fp, lr, [SP, #-0x10]!
    //     0xf8f3b4: mov             fp, SP
    // 0xf8f3b8: ldr             x0, [fp, #0x18]
    // 0xf8f3bc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf8f3bc: ldur            w1, [x0, #0x17]
    // 0xf8f3c0: DecompressPointer r1
    //     0xf8f3c0: add             x1, x1, HEAP, lsl #32
    // 0xf8f3c4: CheckStackOverflow
    //     0xf8f3c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf8f3c8: cmp             SP, x16
    //     0xf8f3cc: b.ls            #0xf8f3e4
    // 0xf8f3d0: ldr             x2, [fp, #0x10]
    // 0xf8f3d4: r0 = _handleDragUpdate()
    //     0xf8f3d4: bl              #0xf8f3ec  ; [package:flutter/src/cupertino/route.dart] _CupertinoBackGestureDetectorState::_handleDragUpdate
    // 0xf8f3d8: LeaveFrame
    //     0xf8f3d8: mov             SP, fp
    //     0xf8f3dc: ldp             fp, lr, [SP], #0x10
    // 0xf8f3e0: ret
    //     0xf8f3e0: ret             
    // 0xf8f3e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf8f3e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf8f3e8: b               #0xf8f3d0
  }
  _ _handleDragUpdate(/* No info */) {
    // ** addr: 0xf8f3ec, size: 0xdc
    // 0xf8f3ec: EnterFrame
    //     0xf8f3ec: stp             fp, lr, [SP, #-0x10]!
    //     0xf8f3f0: mov             fp, SP
    // 0xf8f3f4: AllocStack(0x18)
    //     0xf8f3f4: sub             SP, SP, #0x18
    // 0xf8f3f8: SetupParameters(_CupertinoBackGestureDetectorState<C1X0> this /* r1 => r0, fp-0x18 */)
    //     0xf8f3f8: mov             x0, x1
    //     0xf8f3fc: stur            x1, [fp, #-0x18]
    // 0xf8f400: CheckStackOverflow
    //     0xf8f400: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf8f404: cmp             SP, x16
    //     0xf8f408: b.ls            #0xf8f4b0
    // 0xf8f40c: LoadField: r3 = r0->field_13
    //     0xf8f40c: ldur            w3, [x0, #0x13]
    // 0xf8f410: DecompressPointer r3
    //     0xf8f410: add             x3, x3, HEAP, lsl #32
    // 0xf8f414: stur            x3, [fp, #-0x10]
    // 0xf8f418: cmp             w3, NULL
    // 0xf8f41c: b.eq            #0xf8f4b8
    // 0xf8f420: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf8f420: ldur            w4, [x2, #0x17]
    // 0xf8f424: DecompressPointer r4
    //     0xf8f424: add             x4, x4, HEAP, lsl #32
    // 0xf8f428: stur            x4, [fp, #-8]
    // 0xf8f42c: cmp             w4, NULL
    // 0xf8f430: b.eq            #0xf8f4bc
    // 0xf8f434: LoadField: r1 = r0->field_f
    //     0xf8f434: ldur            w1, [x0, #0xf]
    // 0xf8f438: DecompressPointer r1
    //     0xf8f438: add             x1, x1, HEAP, lsl #32
    // 0xf8f43c: cmp             w1, NULL
    // 0xf8f440: b.eq            #0xf8f4c0
    // 0xf8f444: r0 = renderObject()
    //     0xf8f444: bl              #0x123f10c  ; [package:flutter/src/widgets/framework.dart] Element::renderObject
    // 0xf8f448: r1 = LoadClassIdInstr(r0)
    //     0xf8f448: ldur            x1, [x0, #-1]
    //     0xf8f44c: ubfx            x1, x1, #0xc, #0x14
    // 0xf8f450: r17 = -4710
    //     0xf8f450: mov             x17, #-0x1266
    // 0xf8f454: add             x16, x1, x17
    // 0xf8f458: cmp             x16, #0x109
    // 0xf8f45c: b.hi            #0xf8f470
    // 0xf8f460: mov             x1, x0
    // 0xf8f464: r0 = size()
    //     0xf8f464: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xf8f468: mov             x1, x0
    // 0xf8f46c: b               #0xf8f474
    // 0xf8f470: r1 = Null
    //     0xf8f470: mov             x1, NULL
    // 0xf8f474: ldur            x0, [fp, #-8]
    // 0xf8f478: cmp             w1, NULL
    // 0xf8f47c: b.eq            #0xf8f4c4
    // 0xf8f480: LoadField: d0 = r1->field_7
    //     0xf8f480: ldur            d0, [x1, #7]
    // 0xf8f484: LoadField: d1 = r0->field_7
    //     0xf8f484: ldur            d1, [x0, #7]
    // 0xf8f488: fdiv            d2, d1, d0
    // 0xf8f48c: ldur            x1, [fp, #-0x18]
    // 0xf8f490: mov             v0.16b, v2.16b
    // 0xf8f494: r0 = _convertToLogical()
    //     0xf8f494: bl              #0xf8f340  ; [package:flutter/src/cupertino/route.dart] _CupertinoBackGestureDetectorState::_convertToLogical
    // 0xf8f498: ldur            x1, [fp, #-0x10]
    // 0xf8f49c: r0 = dragUpdate()
    //     0xf8f49c: bl              #0xf8f4c8  ; [package:flutter/src/cupertino/route.dart] _CupertinoBackGestureController::dragUpdate
    // 0xf8f4a0: r0 = Null
    //     0xf8f4a0: mov             x0, NULL
    // 0xf8f4a4: LeaveFrame
    //     0xf8f4a4: mov             SP, fp
    //     0xf8f4a8: ldp             fp, lr, [SP], #0x10
    // 0xf8f4ac: ret
    //     0xf8f4ac: ret             
    // 0xf8f4b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf8f4b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf8f4b4: b               #0xf8f40c
    // 0xf8f4b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf8f4b8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf8f4bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf8f4bc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf8f4c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf8f4c0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf8f4c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf8f4c4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleDragStart(dynamic, DragStartDetails) {
    // ** addr: 0xf8f570, size: 0x3c
    // 0xf8f570: EnterFrame
    //     0xf8f570: stp             fp, lr, [SP, #-0x10]!
    //     0xf8f574: mov             fp, SP
    // 0xf8f578: ldr             x0, [fp, #0x18]
    // 0xf8f57c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf8f57c: ldur            w1, [x0, #0x17]
    // 0xf8f580: DecompressPointer r1
    //     0xf8f580: add             x1, x1, HEAP, lsl #32
    // 0xf8f584: CheckStackOverflow
    //     0xf8f584: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf8f588: cmp             SP, x16
    //     0xf8f58c: b.ls            #0xf8f5a4
    // 0xf8f590: ldr             x2, [fp, #0x10]
    // 0xf8f594: r0 = _handleDragStart()
    //     0xf8f594: bl              #0xf8f5ac  ; [package:flutter/src/cupertino/route.dart] _CupertinoBackGestureDetectorState::_handleDragStart
    // 0xf8f598: LeaveFrame
    //     0xf8f598: mov             SP, fp
    //     0xf8f59c: ldp             fp, lr, [SP], #0x10
    // 0xf8f5a0: ret
    //     0xf8f5a0: ret             
    // 0xf8f5a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf8f5a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf8f5a8: b               #0xf8f590
  }
  _ _handleDragStart(/* No info */) {
    // ** addr: 0xf8f5ac, size: 0x84
    // 0xf8f5ac: EnterFrame
    //     0xf8f5ac: stp             fp, lr, [SP, #-0x10]!
    //     0xf8f5b0: mov             fp, SP
    // 0xf8f5b4: AllocStack(0x10)
    //     0xf8f5b4: sub             SP, SP, #0x10
    // 0xf8f5b8: SetupParameters(_CupertinoBackGestureDetectorState<C1X0> this /* r1 => r1, fp-0x8 */)
    //     0xf8f5b8: stur            x1, [fp, #-8]
    // 0xf8f5bc: CheckStackOverflow
    //     0xf8f5bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf8f5c0: cmp             SP, x16
    //     0xf8f5c4: b.ls            #0xf8f624
    // 0xf8f5c8: LoadField: r0 = r1->field_b
    //     0xf8f5c8: ldur            w0, [x1, #0xb]
    // 0xf8f5cc: DecompressPointer r0
    //     0xf8f5cc: add             x0, x0, HEAP, lsl #32
    // 0xf8f5d0: cmp             w0, NULL
    // 0xf8f5d4: b.eq            #0xf8f62c
    // 0xf8f5d8: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xf8f5d8: ldur            w2, [x0, #0x17]
    // 0xf8f5dc: DecompressPointer r2
    //     0xf8f5dc: add             x2, x2, HEAP, lsl #32
    // 0xf8f5e0: str             x2, [SP]
    // 0xf8f5e4: mov             x0, x2
    // 0xf8f5e8: ClosureCall
    //     0xf8f5e8: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xf8f5ec: ldur            x2, [x0, #0x1f]
    //     0xf8f5f0: blr             x2
    // 0xf8f5f4: ldur            x1, [fp, #-8]
    // 0xf8f5f8: StoreField: r1->field_13 = r0
    //     0xf8f5f8: stur            w0, [x1, #0x13]
    //     0xf8f5fc: ldurb           w16, [x1, #-1]
    //     0xf8f600: ldurb           w17, [x0, #-1]
    //     0xf8f604: and             x16, x17, x16, lsr #2
    //     0xf8f608: tst             x16, HEAP, lsr #32
    //     0xf8f60c: b.eq            #0xf8f614
    //     0xf8f610: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf8f614: r0 = Null
    //     0xf8f614: mov             x0, NULL
    // 0xf8f618: LeaveFrame
    //     0xf8f618: mov             SP, fp
    //     0xf8f61c: ldp             fp, lr, [SP], #0x10
    // 0xf8f620: ret
    //     0xf8f620: ret             
    // 0xf8f624: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf8f624: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf8f628: b               #0xf8f5c8
    // 0xf8f62c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf8f62c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10e4958, size: 0x16c
    // 0x10e4958: EnterFrame
    //     0x10e4958: stp             fp, lr, [SP, #-0x10]!
    //     0x10e495c: mov             fp, SP
    // 0x10e4960: AllocStack(0x20)
    //     0x10e4960: sub             SP, SP, #0x20
    // 0x10e4964: SetupParameters(_CupertinoBackGestureDetectorState<C1X0> this /* r1 => r1, fp-0x8 */)
    //     0x10e4964: stur            x1, [fp, #-8]
    // 0x10e4968: CheckStackOverflow
    //     0x10e4968: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e496c: cmp             SP, x16
    //     0x10e4970: b.ls            #0x10e4aac
    // 0x10e4974: r1 = 1
    //     0x10e4974: mov             x1, #1
    // 0x10e4978: r0 = AllocateContext()
    //     0x10e4978: bl              #0x13de838  ; AllocateContextStub
    // 0x10e497c: mov             x2, x0
    // 0x10e4980: ldur            x0, [fp, #-8]
    // 0x10e4984: stur            x2, [fp, #-0x10]
    // 0x10e4988: StoreField: r2->field_f = r0
    //     0x10e4988: stur            w0, [x2, #0xf]
    // 0x10e498c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x10e498c: ldur            w1, [x0, #0x17]
    // 0x10e4990: DecompressPointer r1
    //     0x10e4990: add             x1, x1, HEAP, lsl #32
    // 0x10e4994: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10e4998: cmp             w1, w16
    // 0x10e499c: b.eq            #0x10e4ab4
    // 0x10e49a0: r0 = dispose()
    //     0x10e49a0: bl              #0xbb16bc  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::dispose
    // 0x10e49a4: ldur            x0, [fp, #-8]
    // 0x10e49a8: LoadField: r1 = r0->field_13
    //     0x10e49a8: ldur            w1, [x0, #0x13]
    // 0x10e49ac: DecompressPointer r1
    //     0x10e49ac: add             x1, x1, HEAP, lsl #32
    // 0x10e49b0: cmp             w1, NULL
    // 0x10e49b4: b.eq            #0x10e4a9c
    // 0x10e49b8: r0 = LoadStaticField(0x6a0)
    //     0x10e49b8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x10e49bc: ldr             x0, [x0, #0xd40]
    // 0x10e49c0: cmp             w0, NULL
    // 0x10e49c4: b.eq            #0x10e4ac0
    // 0x10e49c8: LoadField: r3 = r0->field_53
    //     0x10e49c8: ldur            w3, [x0, #0x53]
    // 0x10e49cc: DecompressPointer r3
    //     0x10e49cc: add             x3, x3, HEAP, lsl #32
    // 0x10e49d0: stur            x3, [fp, #-0x18]
    // 0x10e49d4: LoadField: r0 = r3->field_7
    //     0x10e49d4: ldur            w0, [x3, #7]
    // 0x10e49d8: DecompressPointer r0
    //     0x10e49d8: add             x0, x0, HEAP, lsl #32
    // 0x10e49dc: ldur            x2, [fp, #-0x10]
    // 0x10e49e0: stur            x0, [fp, #-8]
    // 0x10e49e4: r1 = Function '<anonymous closure>':.
    //     0x10e49e4: add             x1, PP, #0xd1, lsl #12  ; [pp+0xd1d80] AnonymousClosure: (0x10e4ac4), in [package:flutter/src/cupertino/route.dart] _CupertinoBackGestureDetectorState::dispose (0x10e4958)
    //     0x10e49e8: ldr             x1, [x1, #0xd80]
    // 0x10e49ec: r0 = AllocateClosure()
    //     0x10e49ec: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10e49f0: ldur            x2, [fp, #-8]
    // 0x10e49f4: mov             x3, x0
    // 0x10e49f8: r1 = Null
    //     0x10e49f8: mov             x1, NULL
    // 0x10e49fc: stur            x3, [fp, #-8]
    // 0x10e4a00: cmp             w2, NULL
    // 0x10e4a04: b.eq            #0x10e4a24
    // 0x10e4a08: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x10e4a08: ldur            w4, [x2, #0x17]
    // 0x10e4a0c: DecompressPointer r4
    //     0x10e4a0c: add             x4, x4, HEAP, lsl #32
    // 0x10e4a10: r8 = X0
    //     0x10e4a10: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x10e4a14: LoadField: r9 = r4->field_7
    //     0x10e4a14: ldur            x9, [x4, #7]
    // 0x10e4a18: r3 = Null
    //     0x10e4a18: add             x3, PP, #0xd1, lsl #12  ; [pp+0xd1d88] Null
    //     0x10e4a1c: ldr             x3, [x3, #0xd88]
    // 0x10e4a20: blr             x9
    // 0x10e4a24: ldur            x0, [fp, #-0x18]
    // 0x10e4a28: LoadField: r1 = r0->field_b
    //     0x10e4a28: ldur            w1, [x0, #0xb]
    // 0x10e4a2c: LoadField: r2 = r0->field_f
    //     0x10e4a2c: ldur            w2, [x0, #0xf]
    // 0x10e4a30: DecompressPointer r2
    //     0x10e4a30: add             x2, x2, HEAP, lsl #32
    // 0x10e4a34: LoadField: r3 = r2->field_b
    //     0x10e4a34: ldur            w3, [x2, #0xb]
    // 0x10e4a38: r2 = LoadInt32Instr(r1)
    //     0x10e4a38: sbfx            x2, x1, #1, #0x1f
    // 0x10e4a3c: stur            x2, [fp, #-0x20]
    // 0x10e4a40: r1 = LoadInt32Instr(r3)
    //     0x10e4a40: sbfx            x1, x3, #1, #0x1f
    // 0x10e4a44: cmp             x2, x1
    // 0x10e4a48: b.ne            #0x10e4a54
    // 0x10e4a4c: mov             x1, x0
    // 0x10e4a50: r0 = _growToNextCapacity()
    //     0x10e4a50: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x10e4a54: ldur            x2, [fp, #-0x18]
    // 0x10e4a58: ldur            x3, [fp, #-0x20]
    // 0x10e4a5c: add             x4, x3, #1
    // 0x10e4a60: lsl             x5, x4, #1
    // 0x10e4a64: StoreField: r2->field_b = r5
    //     0x10e4a64: stur            w5, [x2, #0xb]
    // 0x10e4a68: LoadField: r1 = r2->field_f
    //     0x10e4a68: ldur            w1, [x2, #0xf]
    // 0x10e4a6c: DecompressPointer r1
    //     0x10e4a6c: add             x1, x1, HEAP, lsl #32
    // 0x10e4a70: ldur            x0, [fp, #-8]
    // 0x10e4a74: ArrayStore: r1[r3] = r0  ; List_4
    //     0x10e4a74: add             x25, x1, x3, lsl #2
    //     0x10e4a78: add             x25, x25, #0xf
    //     0x10e4a7c: str             w0, [x25]
    //     0x10e4a80: tbz             w0, #0, #0x10e4a9c
    //     0x10e4a84: ldurb           w16, [x1, #-1]
    //     0x10e4a88: ldurb           w17, [x0, #-1]
    //     0x10e4a8c: and             x16, x17, x16, lsr #2
    //     0x10e4a90: tst             x16, HEAP, lsr #32
    //     0x10e4a94: b.eq            #0x10e4a9c
    //     0x10e4a98: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x10e4a9c: r0 = Null
    //     0x10e4a9c: mov             x0, NULL
    // 0x10e4aa0: LeaveFrame
    //     0x10e4aa0: mov             SP, fp
    //     0x10e4aa4: ldp             fp, lr, [SP], #0x10
    // 0x10e4aa8: ret
    //     0x10e4aa8: ret             
    // 0x10e4aac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e4aac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e4ab0: b               #0x10e4974
    // 0x10e4ab4: r9 = _recognizer
    //     0x10e4ab4: add             x9, PP, #0xd1, lsl #12  ; [pp+0xd1d78] Field <_CupertinoBackGestureDetectorState@111053933._recognizer@111053933>: late (offset: 0x18)
    //     0x10e4ab8: ldr             x9, [x9, #0xd78]
    // 0x10e4abc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x10e4abc: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x10e4ac0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10e4ac0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, Duration) {
    // ** addr: 0x10e4ac4, size: 0xb4
    // 0x10e4ac4: EnterFrame
    //     0x10e4ac4: stp             fp, lr, [SP, #-0x10]!
    //     0x10e4ac8: mov             fp, SP
    // 0x10e4acc: AllocStack(0x8)
    //     0x10e4acc: sub             SP, SP, #8
    // 0x10e4ad0: SetupParameters([dynamic _ /* r0 */])
    //     0x10e4ad0: ldr             x0, [fp, #0x18]
    //     0x10e4ad4: ldur            w2, [x0, #0x17]
    //     0x10e4ad8: add             x2, x2, HEAP, lsl #32
    //     0x10e4adc: stur            x2, [fp, #-8]
    // 0x10e4ae0: CheckStackOverflow
    //     0x10e4ae0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e4ae4: cmp             SP, x16
    //     0x10e4ae8: b.ls            #0x10e4b70
    // 0x10e4aec: LoadField: r0 = r2->field_f
    //     0x10e4aec: ldur            w0, [x2, #0xf]
    // 0x10e4af0: DecompressPointer r0
    //     0x10e4af0: add             x0, x0, HEAP, lsl #32
    // 0x10e4af4: LoadField: r1 = r0->field_13
    //     0x10e4af4: ldur            w1, [x0, #0x13]
    // 0x10e4af8: DecompressPointer r1
    //     0x10e4af8: add             x1, x1, HEAP, lsl #32
    // 0x10e4afc: cmp             w1, NULL
    // 0x10e4b00: b.ne            #0x10e4b0c
    // 0x10e4b04: r0 = Null
    //     0x10e4b04: mov             x0, NULL
    // 0x10e4b08: b               #0x10e4b2c
    // 0x10e4b0c: LoadField: r0 = r1->field_f
    //     0x10e4b0c: ldur            w0, [x1, #0xf]
    // 0x10e4b10: DecompressPointer r0
    //     0x10e4b10: add             x0, x0, HEAP, lsl #32
    // 0x10e4b14: LoadField: r3 = r0->field_f
    //     0x10e4b14: ldur            w3, [x0, #0xf]
    // 0x10e4b18: DecompressPointer r3
    //     0x10e4b18: add             x3, x3, HEAP, lsl #32
    // 0x10e4b1c: cmp             w3, NULL
    // 0x10e4b20: r16 = true
    //     0x10e4b20: add             x16, NULL, #0x20  ; true
    // 0x10e4b24: r17 = false
    //     0x10e4b24: add             x17, NULL, #0x30  ; false
    // 0x10e4b28: csel            x0, x16, x17, ne
    // 0x10e4b2c: cmp             w0, NULL
    // 0x10e4b30: b.eq            #0x10e4b50
    // 0x10e4b34: tbnz            w0, #4, #0x10e4b50
    // 0x10e4b38: cmp             w1, NULL
    // 0x10e4b3c: b.eq            #0x10e4b50
    // 0x10e4b40: LoadField: r0 = r1->field_f
    //     0x10e4b40: ldur            w0, [x1, #0xf]
    // 0x10e4b44: DecompressPointer r0
    //     0x10e4b44: add             x0, x0, HEAP, lsl #32
    // 0x10e4b48: mov             x1, x0
    // 0x10e4b4c: r0 = didStopUserGesture()
    //     0x10e4b4c: bl              #0x8c84d8  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::didStopUserGesture
    // 0x10e4b50: ldur            x1, [fp, #-8]
    // 0x10e4b54: LoadField: r2 = r1->field_f
    //     0x10e4b54: ldur            w2, [x1, #0xf]
    // 0x10e4b58: DecompressPointer r2
    //     0x10e4b58: add             x2, x2, HEAP, lsl #32
    // 0x10e4b5c: StoreField: r2->field_13 = rNULL
    //     0x10e4b5c: stur            NULL, [x2, #0x13]
    // 0x10e4b60: r0 = Null
    //     0x10e4b60: mov             x0, NULL
    // 0x10e4b64: LeaveFrame
    //     0x10e4b64: mov             SP, fp
    //     0x10e4b68: ldp             fp, lr, [SP], #0x10
    // 0x10e4b6c: ret
    //     0x10e4b6c: ret             
    // 0x10e4b70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e4b70: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e4b74: b               #0x10e4aec
  }
}

// class id: 5484, size: 0x24, field offset: 0x14
class _CupertinoFullscreenDialogTransitionState extends State<dynamic> {

  late Animation<Offset> _secondaryPositionAnimation; // offset: 0x18
  late Animation<Offset> _primaryPositionAnimation; // offset: 0x14

  _ build(/* No info */) {
    // ** addr: 0xde6f34, size: 0xf8
    // 0xde6f34: EnterFrame
    //     0xde6f34: stp             fp, lr, [SP, #-0x10]!
    //     0xde6f38: mov             fp, SP
    // 0xde6f3c: AllocStack(0x28)
    //     0xde6f3c: sub             SP, SP, #0x28
    // 0xde6f40: SetupParameters(_CupertinoFullscreenDialogTransitionState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1 */)
    //     0xde6f40: mov             x0, x1
    //     0xde6f44: stur            x1, [fp, #-8]
    //     0xde6f48: mov             x1, x2
    // 0xde6f4c: CheckStackOverflow
    //     0xde6f4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde6f50: cmp             SP, x16
    //     0xde6f54: b.ls            #0xde7008
    // 0xde6f58: r0 = of()
    //     0xde6f58: bl              #0x87371c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0xde6f5c: mov             x1, x0
    // 0xde6f60: ldur            x0, [fp, #-8]
    // 0xde6f64: stur            x1, [fp, #-0x20]
    // 0xde6f68: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xde6f68: ldur            w2, [x0, #0x17]
    // 0xde6f6c: DecompressPointer r2
    //     0xde6f6c: add             x2, x2, HEAP, lsl #32
    // 0xde6f70: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xde6f74: cmp             w2, w16
    // 0xde6f78: b.eq            #0xde7010
    // 0xde6f7c: stur            x2, [fp, #-0x18]
    // 0xde6f80: LoadField: r3 = r0->field_13
    //     0xde6f80: ldur            w3, [x0, #0x13]
    // 0xde6f84: DecompressPointer r3
    //     0xde6f84: add             x3, x3, HEAP, lsl #32
    // 0xde6f88: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xde6f8c: cmp             w3, w16
    // 0xde6f90: b.eq            #0xde701c
    // 0xde6f94: stur            x3, [fp, #-0x10]
    // 0xde6f98: LoadField: r4 = r0->field_b
    //     0xde6f98: ldur            w4, [x0, #0xb]
    // 0xde6f9c: DecompressPointer r4
    //     0xde6f9c: add             x4, x4, HEAP, lsl #32
    // 0xde6fa0: cmp             w4, NULL
    // 0xde6fa4: b.eq            #0xde7028
    // 0xde6fa8: ArrayLoad: r0 = r4[0]  ; List_4
    //     0xde6fa8: ldur            w0, [x4, #0x17]
    // 0xde6fac: DecompressPointer r0
    //     0xde6fac: add             x0, x0, HEAP, lsl #32
    // 0xde6fb0: stur            x0, [fp, #-8]
    // 0xde6fb4: r0 = SlideTransition()
    //     0xde6fb4: bl              #0xb28364  ; AllocateSlideTransitionStub -> SlideTransition (size=0x1c)
    // 0xde6fb8: mov             x1, x0
    // 0xde6fbc: r0 = true
    //     0xde6fbc: add             x0, NULL, #0x20  ; true
    // 0xde6fc0: stur            x1, [fp, #-0x28]
    // 0xde6fc4: StoreField: r1->field_13 = r0
    //     0xde6fc4: stur            w0, [x1, #0x13]
    // 0xde6fc8: ldur            x0, [fp, #-8]
    // 0xde6fcc: ArrayStore: r1[0] = r0  ; List_4
    //     0xde6fcc: stur            w0, [x1, #0x17]
    // 0xde6fd0: ldur            x0, [fp, #-0x10]
    // 0xde6fd4: StoreField: r1->field_b = r0
    //     0xde6fd4: stur            w0, [x1, #0xb]
    // 0xde6fd8: r0 = SlideTransition()
    //     0xde6fd8: bl              #0xb28364  ; AllocateSlideTransitionStub -> SlideTransition (size=0x1c)
    // 0xde6fdc: r1 = false
    //     0xde6fdc: add             x1, NULL, #0x30  ; false
    // 0xde6fe0: StoreField: r0->field_13 = r1
    //     0xde6fe0: stur            w1, [x0, #0x13]
    // 0xde6fe4: ldur            x1, [fp, #-0x20]
    // 0xde6fe8: StoreField: r0->field_f = r1
    //     0xde6fe8: stur            w1, [x0, #0xf]
    // 0xde6fec: ldur            x1, [fp, #-0x28]
    // 0xde6ff0: ArrayStore: r0[0] = r1  ; List_4
    //     0xde6ff0: stur            w1, [x0, #0x17]
    // 0xde6ff4: ldur            x1, [fp, #-0x18]
    // 0xde6ff8: StoreField: r0->field_b = r1
    //     0xde6ff8: stur            w1, [x0, #0xb]
    // 0xde6ffc: LeaveFrame
    //     0xde6ffc: mov             SP, fp
    //     0xde7000: ldp             fp, lr, [SP], #0x10
    // 0xde7004: ret
    //     0xde7004: ret             
    // 0xde7008: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde7008: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde700c: b               #0xde6f58
    // 0xde7010: r9 = _secondaryPositionAnimation
    //     0xde7010: add             x9, PP, #0xad, lsl #12  ; [pp+0xadb40] Field <_CupertinoFullscreenDialogTransitionState@111053933._secondaryPositionAnimation@111053933>: late (offset: 0x18)
    //     0xde7014: ldr             x9, [x9, #0xb40]
    // 0xde7018: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xde7018: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xde701c: r9 = _primaryPositionAnimation
    //     0xde701c: add             x9, PP, #0xad, lsl #12  ; [pp+0xadb48] Field <_CupertinoFullscreenDialogTransitionState@111053933._primaryPositionAnimation@111053933>: late (offset: 0x14)
    //     0xde7020: ldr             x9, [x9, #0xb48]
    // 0xde7024: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xde7024: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xde7028: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde7028: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf6ce24, size: 0x12c
    // 0xf6ce24: EnterFrame
    //     0xf6ce24: stp             fp, lr, [SP, #-0x10]!
    //     0xf6ce28: mov             fp, SP
    // 0xf6ce2c: AllocStack(0x10)
    //     0xf6ce2c: sub             SP, SP, #0x10
    // 0xf6ce30: SetupParameters(_CupertinoFullscreenDialogTransitionState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xf6ce30: mov             x4, x1
    //     0xf6ce34: mov             x3, x2
    //     0xf6ce38: stur            x1, [fp, #-8]
    //     0xf6ce3c: stur            x2, [fp, #-0x10]
    // 0xf6ce40: CheckStackOverflow
    //     0xf6ce40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6ce44: cmp             SP, x16
    //     0xf6ce48: b.ls            #0xf6cf44
    // 0xf6ce4c: mov             x0, x3
    // 0xf6ce50: r2 = Null
    //     0xf6ce50: mov             x2, NULL
    // 0xf6ce54: r1 = Null
    //     0xf6ce54: mov             x1, NULL
    // 0xf6ce58: r4 = 60
    //     0xf6ce58: mov             x4, #0x3c
    // 0xf6ce5c: branchIfSmi(r0, 0xf6ce68)
    //     0xf6ce5c: tbz             w0, #0, #0xf6ce68
    // 0xf6ce60: r4 = LoadClassIdInstr(r0)
    //     0xf6ce60: ldur            x4, [x0, #-1]
    //     0xf6ce64: ubfx            x4, x4, #0xc, #0x14
    // 0xf6ce68: r17 = 6514
    //     0xf6ce68: mov             x17, #0x1972
    // 0xf6ce6c: cmp             x4, x17
    // 0xf6ce70: b.eq            #0xf6ce88
    // 0xf6ce74: r8 = CupertinoFullscreenDialogTransition
    //     0xf6ce74: add             x8, PP, #0xad, lsl #12  ; [pp+0xadb50] Type: CupertinoFullscreenDialogTransition
    //     0xf6ce78: ldr             x8, [x8, #0xb50]
    // 0xf6ce7c: r3 = Null
    //     0xf6ce7c: add             x3, PP, #0xad, lsl #12  ; [pp+0xadb58] Null
    //     0xf6ce80: ldr             x3, [x3, #0xb58]
    // 0xf6ce84: r0 = CupertinoFullscreenDialogTransition()
    //     0xf6ce84: bl              #0xb2883c  ; IsType_CupertinoFullscreenDialogTransition_Stub
    // 0xf6ce88: ldur            x3, [fp, #-8]
    // 0xf6ce8c: LoadField: r2 = r3->field_7
    //     0xf6ce8c: ldur            w2, [x3, #7]
    // 0xf6ce90: DecompressPointer r2
    //     0xf6ce90: add             x2, x2, HEAP, lsl #32
    // 0xf6ce94: ldur            x0, [fp, #-0x10]
    // 0xf6ce98: r1 = Null
    //     0xf6ce98: mov             x1, NULL
    // 0xf6ce9c: cmp             w2, NULL
    // 0xf6cea0: b.eq            #0xf6cec4
    // 0xf6cea4: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf6cea4: ldur            w4, [x2, #0x17]
    // 0xf6cea8: DecompressPointer r4
    //     0xf6cea8: add             x4, x4, HEAP, lsl #32
    // 0xf6ceac: r8 = X0 bound StatefulWidget
    //     0xf6ceac: add             x8, PP, #0x12, lsl #12  ; [pp+0x12498] TypeParameter: X0 bound StatefulWidget
    //     0xf6ceb0: ldr             x8, [x8, #0x498]
    // 0xf6ceb4: LoadField: r9 = r4->field_7
    //     0xf6ceb4: ldur            x9, [x4, #7]
    // 0xf6ceb8: r3 = Null
    //     0xf6ceb8: add             x3, PP, #0xad, lsl #12  ; [pp+0xadb68] Null
    //     0xf6cebc: ldr             x3, [x3, #0xb68]
    // 0xf6cec0: blr             x9
    // 0xf6cec4: ldur            x0, [fp, #-0x10]
    // 0xf6cec8: LoadField: r1 = r0->field_b
    //     0xf6cec8: ldur            w1, [x0, #0xb]
    // 0xf6cecc: DecompressPointer r1
    //     0xf6cecc: add             x1, x1, HEAP, lsl #32
    // 0xf6ced0: ldur            x2, [fp, #-8]
    // 0xf6ced4: LoadField: r3 = r2->field_b
    //     0xf6ced4: ldur            w3, [x2, #0xb]
    // 0xf6ced8: DecompressPointer r3
    //     0xf6ced8: add             x3, x3, HEAP, lsl #32
    // 0xf6cedc: cmp             w3, NULL
    // 0xf6cee0: b.eq            #0xf6cf4c
    // 0xf6cee4: LoadField: r4 = r3->field_b
    //     0xf6cee4: ldur            w4, [x3, #0xb]
    // 0xf6cee8: DecompressPointer r4
    //     0xf6cee8: add             x4, x4, HEAP, lsl #32
    // 0xf6ceec: cmp             w1, w4
    // 0xf6cef0: b.ne            #0xf6cf24
    // 0xf6cef4: LoadField: r1 = r0->field_f
    //     0xf6cef4: ldur            w1, [x0, #0xf]
    // 0xf6cef8: DecompressPointer r1
    //     0xf6cef8: add             x1, x1, HEAP, lsl #32
    // 0xf6cefc: LoadField: r4 = r3->field_f
    //     0xf6cefc: ldur            w4, [x3, #0xf]
    // 0xf6cf00: DecompressPointer r4
    //     0xf6cf00: add             x4, x4, HEAP, lsl #32
    // 0xf6cf04: cmp             w1, w4
    // 0xf6cf08: b.ne            #0xf6cf24
    // 0xf6cf0c: LoadField: r1 = r0->field_13
    //     0xf6cf0c: ldur            w1, [x0, #0x13]
    // 0xf6cf10: DecompressPointer r1
    //     0xf6cf10: add             x1, x1, HEAP, lsl #32
    // 0xf6cf14: LoadField: r0 = r3->field_13
    //     0xf6cf14: ldur            w0, [x3, #0x13]
    // 0xf6cf18: DecompressPointer r0
    //     0xf6cf18: add             x0, x0, HEAP, lsl #32
    // 0xf6cf1c: cmp             w1, w0
    // 0xf6cf20: b.eq            #0xf6cf34
    // 0xf6cf24: mov             x1, x2
    // 0xf6cf28: r0 = _disposeCurve()
    //     0xf6cf28: bl              #0xf6d150  ; [package:flutter/src/cupertino/route.dart] _CupertinoFullscreenDialogTransitionState::_disposeCurve
    // 0xf6cf2c: ldur            x1, [fp, #-8]
    // 0xf6cf30: r0 = _setupAnimation()
    //     0xf6cf30: bl              #0xf6cf50  ; [package:flutter/src/cupertino/route.dart] _CupertinoFullscreenDialogTransitionState::_setupAnimation
    // 0xf6cf34: r0 = Null
    //     0xf6cf34: mov             x0, NULL
    // 0xf6cf38: LeaveFrame
    //     0xf6cf38: mov             SP, fp
    //     0xf6cf3c: ldp             fp, lr, [SP], #0x10
    // 0xf6cf40: ret
    //     0xf6cf40: ret             
    // 0xf6cf44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6cf44: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6cf48: b               #0xf6ce4c
    // 0xf6cf4c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6cf4c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _setupAnimation(/* No info */) {
    // ** addr: 0xf6cf50, size: 0x200
    // 0xf6cf50: EnterFrame
    //     0xf6cf50: stp             fp, lr, [SP, #-0x10]!
    //     0xf6cf54: mov             fp, SP
    // 0xf6cf58: AllocStack(0x28)
    //     0xf6cf58: sub             SP, SP, #0x28
    // 0xf6cf5c: SetupParameters(_CupertinoFullscreenDialogTransitionState this /* r1 => r0, fp-0x10 */)
    //     0xf6cf5c: mov             x0, x1
    //     0xf6cf60: stur            x1, [fp, #-0x10]
    // 0xf6cf64: CheckStackOverflow
    //     0xf6cf64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6cf68: cmp             SP, x16
    //     0xf6cf6c: b.ls            #0xf6d140
    // 0xf6cf70: LoadField: r1 = r0->field_b
    //     0xf6cf70: ldur            w1, [x0, #0xb]
    // 0xf6cf74: DecompressPointer r1
    //     0xf6cf74: add             x1, x1, HEAP, lsl #32
    // 0xf6cf78: cmp             w1, NULL
    // 0xf6cf7c: b.eq            #0xf6d148
    // 0xf6cf80: LoadField: r3 = r1->field_b
    //     0xf6cf80: ldur            w3, [x1, #0xb]
    // 0xf6cf84: DecompressPointer r3
    //     0xf6cf84: add             x3, x3, HEAP, lsl #32
    // 0xf6cf88: stur            x3, [fp, #-8]
    // 0xf6cf8c: r1 = <double>
    //     0xf6cf8c: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf6cf90: r0 = FlippedCurve()
    //     0xf6cf90: bl              #0xb6f814  ; AllocateFlippedCurveStub -> FlippedCurve (size=0x10)
    // 0xf6cf94: r2 = Instance_Cubic
    //     0xf6cf94: add             x2, PP, #0x99, lsl #12  ; [pp+0x99098] Obj!Cubic@129f7b1
    //     0xf6cf98: ldr             x2, [x2, #0x98]
    // 0xf6cf9c: stur            x0, [fp, #-0x18]
    // 0xf6cfa0: StoreField: r0->field_b = r2
    //     0xf6cfa0: stur            w2, [x0, #0xb]
    // 0xf6cfa4: r1 = <double>
    //     0xf6cfa4: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf6cfa8: r0 = CurvedAnimation()
    //     0xf6cfa8: bl              #0x915e4c  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0xf6cfac: stur            x0, [fp, #-0x20]
    // 0xf6cfb0: ldur            x16, [fp, #-0x18]
    // 0xf6cfb4: str             x16, [SP]
    // 0xf6cfb8: mov             x1, x0
    // 0xf6cfbc: ldur            x3, [fp, #-8]
    // 0xf6cfc0: r2 = Instance_Cubic
    //     0xf6cfc0: add             x2, PP, #0x99, lsl #12  ; [pp+0x99098] Obj!Cubic@129f7b1
    //     0xf6cfc4: ldr             x2, [x2, #0x98]
    // 0xf6cfc8: r4 = const [0, 0x4, 0x1, 0x3, reverseCurve, 0x3, null]
    //     0xf6cfc8: add             x4, PP, #0x16, lsl #12  ; [pp+0x16dc0] List(7) [0, 0x4, 0x1, 0x3, "reverseCurve", 0x3, Null]
    //     0xf6cfcc: ldr             x4, [x4, #0xdc0]
    // 0xf6cfd0: r0 = CurvedAnimation()
    //     0xf6cfd0: bl              #0x915be4  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0xf6cfd4: ldur            x0, [fp, #-0x20]
    // 0xf6cfd8: ldur            x1, [fp, #-0x10]
    // 0xf6cfdc: StoreField: r1->field_1b = r0
    //     0xf6cfdc: stur            w0, [x1, #0x1b]
    //     0xf6cfe0: ldurb           w16, [x1, #-1]
    //     0xf6cfe4: ldurb           w17, [x0, #-1]
    //     0xf6cfe8: and             x16, x17, x16, lsr #2
    //     0xf6cfec: tst             x16, HEAP, lsr #32
    //     0xf6cff0: b.eq            #0xf6cff8
    //     0xf6cff4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf6cff8: r0 = LoadStaticField(0x754)
    //     0xf6cff8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf6cffc: ldr             x0, [x0, #0xea8]
    // 0xf6d000: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf6d004: cmp             w0, w16
    // 0xf6d008: b.ne            #0xf6d018
    // 0xf6d00c: r2 = _kBottomUpTween
    //     0xf6d00c: add             x2, PP, #0xad, lsl #12  ; [pp+0xadb78] Field <::._kBottomUpTween@111053933>: static late final (offset: 0x754)
    //     0xf6d010: ldr             x2, [x2, #0xb78]
    // 0xf6d014: r0 = InitLateFinalStaticField()
    //     0xf6d014: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xf6d018: mov             x1, x0
    // 0xf6d01c: ldur            x2, [fp, #-0x20]
    // 0xf6d020: r0 = animate()
    //     0xf6d020: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xf6d024: ldur            x2, [fp, #-0x10]
    // 0xf6d028: StoreField: r2->field_13 = r0
    //     0xf6d028: stur            w0, [x2, #0x13]
    //     0xf6d02c: ldurb           w16, [x2, #-1]
    //     0xf6d030: ldurb           w17, [x0, #-1]
    //     0xf6d034: and             x16, x17, x16, lsr #2
    //     0xf6d038: tst             x16, HEAP, lsr #32
    //     0xf6d03c: b.eq            #0xf6d044
    //     0xf6d040: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf6d044: LoadField: r0 = r2->field_b
    //     0xf6d044: ldur            w0, [x2, #0xb]
    // 0xf6d048: DecompressPointer r0
    //     0xf6d048: add             x0, x0, HEAP, lsl #32
    // 0xf6d04c: cmp             w0, NULL
    // 0xf6d050: b.eq            #0xf6d14c
    // 0xf6d054: LoadField: r1 = r0->field_13
    //     0xf6d054: ldur            w1, [x0, #0x13]
    // 0xf6d058: DecompressPointer r1
    //     0xf6d058: add             x1, x1, HEAP, lsl #32
    // 0xf6d05c: tbnz            w1, #4, #0xf6d078
    // 0xf6d060: LoadField: r1 = r0->field_f
    //     0xf6d060: ldur            w1, [x0, #0xf]
    // 0xf6d064: DecompressPointer r1
    //     0xf6d064: add             x1, x1, HEAP, lsl #32
    // 0xf6d068: mov             x16, x2
    // 0xf6d06c: mov             x2, x1
    // 0xf6d070: mov             x1, x16
    // 0xf6d074: b               #0xf6d0e0
    // 0xf6d078: LoadField: r3 = r0->field_f
    //     0xf6d078: ldur            w3, [x0, #0xf]
    // 0xf6d07c: DecompressPointer r3
    //     0xf6d07c: add             x3, x3, HEAP, lsl #32
    // 0xf6d080: stur            x3, [fp, #-8]
    // 0xf6d084: r1 = <double>
    //     0xf6d084: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf6d088: r0 = CurvedAnimation()
    //     0xf6d088: bl              #0x915e4c  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0xf6d08c: stur            x0, [fp, #-0x18]
    // 0xf6d090: r16 = Instance_Cubic
    //     0xf6d090: add             x16, PP, #0x99, lsl #12  ; [pp+0x99090] Obj!Cubic@129f7e1
    //     0xf6d094: ldr             x16, [x16, #0x90]
    // 0xf6d098: str             x16, [SP]
    // 0xf6d09c: mov             x1, x0
    // 0xf6d0a0: ldur            x3, [fp, #-8]
    // 0xf6d0a4: r2 = Instance_Cubic
    //     0xf6d0a4: add             x2, PP, #0x99, lsl #12  ; [pp+0x99098] Obj!Cubic@129f7b1
    //     0xf6d0a8: ldr             x2, [x2, #0x98]
    // 0xf6d0ac: r4 = const [0, 0x4, 0x1, 0x3, reverseCurve, 0x3, null]
    //     0xf6d0ac: add             x4, PP, #0x16, lsl #12  ; [pp+0x16dc0] List(7) [0, 0x4, 0x1, 0x3, "reverseCurve", 0x3, Null]
    //     0xf6d0b0: ldr             x4, [x4, #0xdc0]
    // 0xf6d0b4: r0 = CurvedAnimation()
    //     0xf6d0b4: bl              #0x915be4  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0xf6d0b8: ldur            x0, [fp, #-0x18]
    // 0xf6d0bc: ldur            x1, [fp, #-0x10]
    // 0xf6d0c0: StoreField: r1->field_1f = r0
    //     0xf6d0c0: stur            w0, [x1, #0x1f]
    //     0xf6d0c4: ldurb           w16, [x1, #-1]
    //     0xf6d0c8: ldurb           w17, [x0, #-1]
    //     0xf6d0cc: and             x16, x17, x16, lsr #2
    //     0xf6d0d0: tst             x16, HEAP, lsr #32
    //     0xf6d0d4: b.eq            #0xf6d0dc
    //     0xf6d0d8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf6d0dc: ldur            x2, [fp, #-0x18]
    // 0xf6d0e0: stur            x2, [fp, #-8]
    // 0xf6d0e4: r0 = LoadStaticField(0x750)
    //     0xf6d0e4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf6d0e8: ldr             x0, [x0, #0xea0]
    // 0xf6d0ec: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf6d0f0: cmp             w0, w16
    // 0xf6d0f4: b.ne            #0xf6d104
    // 0xf6d0f8: r2 = _kMiddleLeftTween
    //     0xf6d0f8: add             x2, PP, #0x99, lsl #12  ; [pp+0x990a0] Field <::._kMiddleLeftTween@111053933>: static late final (offset: 0x750)
    //     0xf6d0fc: ldr             x2, [x2, #0xa0]
    // 0xf6d100: r0 = InitLateFinalStaticField()
    //     0xf6d100: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xf6d104: mov             x1, x0
    // 0xf6d108: ldur            x2, [fp, #-8]
    // 0xf6d10c: r0 = animate()
    //     0xf6d10c: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xf6d110: ldur            x1, [fp, #-0x10]
    // 0xf6d114: ArrayStore: r1[0] = r0  ; List_4
    //     0xf6d114: stur            w0, [x1, #0x17]
    //     0xf6d118: ldurb           w16, [x1, #-1]
    //     0xf6d11c: ldurb           w17, [x0, #-1]
    //     0xf6d120: and             x16, x17, x16, lsr #2
    //     0xf6d124: tst             x16, HEAP, lsr #32
    //     0xf6d128: b.eq            #0xf6d130
    //     0xf6d12c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf6d130: r0 = Null
    //     0xf6d130: mov             x0, NULL
    // 0xf6d134: LeaveFrame
    //     0xf6d134: mov             SP, fp
    //     0xf6d138: ldp             fp, lr, [SP], #0x10
    // 0xf6d13c: ret
    //     0xf6d13c: ret             
    // 0xf6d140: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6d140: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6d144: b               #0xf6cf70
    // 0xf6d148: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6d148: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6d14c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6d14c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _disposeCurve(/* No info */) {
    // ** addr: 0xf6d150, size: 0x78
    // 0xf6d150: EnterFrame
    //     0xf6d150: stp             fp, lr, [SP, #-0x10]!
    //     0xf6d154: mov             fp, SP
    // 0xf6d158: AllocStack(0x8)
    //     0xf6d158: sub             SP, SP, #8
    // 0xf6d15c: SetupParameters(_CupertinoFullscreenDialogTransitionState this /* r1 => r0, fp-0x8 */)
    //     0xf6d15c: mov             x0, x1
    //     0xf6d160: stur            x1, [fp, #-8]
    // 0xf6d164: CheckStackOverflow
    //     0xf6d164: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6d168: cmp             SP, x16
    //     0xf6d16c: b.ls            #0xf6d1c0
    // 0xf6d170: LoadField: r1 = r0->field_1b
    //     0xf6d170: ldur            w1, [x0, #0x1b]
    // 0xf6d174: DecompressPointer r1
    //     0xf6d174: add             x1, x1, HEAP, lsl #32
    // 0xf6d178: cmp             w1, NULL
    // 0xf6d17c: b.eq            #0xf6d188
    // 0xf6d180: r0 = dispose()
    //     0xf6d180: bl              #0xb29014  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::dispose
    // 0xf6d184: ldur            x0, [fp, #-8]
    // 0xf6d188: LoadField: r1 = r0->field_1f
    //     0xf6d188: ldur            w1, [x0, #0x1f]
    // 0xf6d18c: DecompressPointer r1
    //     0xf6d18c: add             x1, x1, HEAP, lsl #32
    // 0xf6d190: cmp             w1, NULL
    // 0xf6d194: b.ne            #0xf6d1a0
    // 0xf6d198: mov             x1, x0
    // 0xf6d19c: b               #0xf6d1a8
    // 0xf6d1a0: r0 = dispose()
    //     0xf6d1a0: bl              #0xb29014  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::dispose
    // 0xf6d1a4: ldur            x1, [fp, #-8]
    // 0xf6d1a8: StoreField: r1->field_1b = rNULL
    //     0xf6d1a8: stur            NULL, [x1, #0x1b]
    // 0xf6d1ac: StoreField: r1->field_1f = rNULL
    //     0xf6d1ac: stur            NULL, [x1, #0x1f]
    // 0xf6d1b0: r0 = Null
    //     0xf6d1b0: mov             x0, NULL
    // 0xf6d1b4: LeaveFrame
    //     0xf6d1b4: mov             SP, fp
    //     0xf6d1b8: ldp             fp, lr, [SP], #0x10
    // 0xf6d1bc: ret
    //     0xf6d1bc: ret             
    // 0xf6d1c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6d1c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6d1c4: b               #0xf6d170
  }
  _ initState(/* No info */) {
    // ** addr: 0xf8e9cc, size: 0x30
    // 0xf8e9cc: EnterFrame
    //     0xf8e9cc: stp             fp, lr, [SP, #-0x10]!
    //     0xf8e9d0: mov             fp, SP
    // 0xf8e9d4: CheckStackOverflow
    //     0xf8e9d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf8e9d8: cmp             SP, x16
    //     0xf8e9dc: b.ls            #0xf8e9f4
    // 0xf8e9e0: r0 = _setupAnimation()
    //     0xf8e9e0: bl              #0xf6cf50  ; [package:flutter/src/cupertino/route.dart] _CupertinoFullscreenDialogTransitionState::_setupAnimation
    // 0xf8e9e4: r0 = Null
    //     0xf8e9e4: mov             x0, NULL
    // 0xf8e9e8: LeaveFrame
    //     0xf8e9e8: mov             SP, fp
    //     0xf8e9ec: ldp             fp, lr, [SP], #0x10
    // 0xf8e9f0: ret
    //     0xf8e9f0: ret             
    // 0xf8e9f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf8e9f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf8e9f8: b               #0xf8e9e0
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10e4928, size: 0x30
    // 0x10e4928: EnterFrame
    //     0x10e4928: stp             fp, lr, [SP, #-0x10]!
    //     0x10e492c: mov             fp, SP
    // 0x10e4930: CheckStackOverflow
    //     0x10e4930: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e4934: cmp             SP, x16
    //     0x10e4938: b.ls            #0x10e4950
    // 0x10e493c: r0 = _disposeCurve()
    //     0x10e493c: bl              #0xf6d150  ; [package:flutter/src/cupertino/route.dart] _CupertinoFullscreenDialogTransitionState::_disposeCurve
    // 0x10e4940: r0 = Null
    //     0x10e4940: mov             x0, NULL
    // 0x10e4944: LeaveFrame
    //     0x10e4944: mov             SP, fp
    //     0x10e4948: ldp             fp, lr, [SP], #0x10
    // 0x10e494c: ret
    //     0x10e494c: ret             
    // 0x10e4950: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e4950: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e4954: b               #0x10e493c
  }
}

// class id: 5485, size: 0x2c, field offset: 0x14
class _CupertinoPageTransitionState extends State<dynamic> {

  late Animation<Offset> _secondaryPositionAnimation; // offset: 0x18
  late Animation<Offset> _primaryPositionAnimation; // offset: 0x14
  late Animation<Decoration> _primaryShadowAnimation; // offset: 0x1c

  _ build(/* No info */) {
    // ** addr: 0xde6dd8, size: 0x150
    // 0xde6dd8: EnterFrame
    //     0xde6dd8: stp             fp, lr, [SP, #-0x10]!
    //     0xde6ddc: mov             fp, SP
    // 0xde6de0: AllocStack(0x30)
    //     0xde6de0: sub             SP, SP, #0x30
    // 0xde6de4: SetupParameters(_CupertinoPageTransitionState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1 */)
    //     0xde6de4: mov             x0, x1
    //     0xde6de8: stur            x1, [fp, #-8]
    //     0xde6dec: mov             x1, x2
    // 0xde6df0: CheckStackOverflow
    //     0xde6df0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde6df4: cmp             SP, x16
    //     0xde6df8: b.ls            #0xde6ef8
    // 0xde6dfc: r0 = of()
    //     0xde6dfc: bl              #0x87371c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0xde6e00: mov             x1, x0
    // 0xde6e04: ldur            x0, [fp, #-8]
    // 0xde6e08: stur            x1, [fp, #-0x28]
    // 0xde6e0c: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xde6e0c: ldur            w2, [x0, #0x17]
    // 0xde6e10: DecompressPointer r2
    //     0xde6e10: add             x2, x2, HEAP, lsl #32
    // 0xde6e14: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xde6e18: cmp             w2, w16
    // 0xde6e1c: b.eq            #0xde6f00
    // 0xde6e20: stur            x2, [fp, #-0x20]
    // 0xde6e24: LoadField: r3 = r0->field_13
    //     0xde6e24: ldur            w3, [x0, #0x13]
    // 0xde6e28: DecompressPointer r3
    //     0xde6e28: add             x3, x3, HEAP, lsl #32
    // 0xde6e2c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xde6e30: cmp             w3, w16
    // 0xde6e34: b.eq            #0xde6f0c
    // 0xde6e38: stur            x3, [fp, #-0x18]
    // 0xde6e3c: LoadField: r4 = r0->field_1b
    //     0xde6e3c: ldur            w4, [x0, #0x1b]
    // 0xde6e40: DecompressPointer r4
    //     0xde6e40: add             x4, x4, HEAP, lsl #32
    // 0xde6e44: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xde6e48: cmp             w4, w16
    // 0xde6e4c: b.eq            #0xde6f18
    // 0xde6e50: stur            x4, [fp, #-0x10]
    // 0xde6e54: LoadField: r5 = r0->field_b
    //     0xde6e54: ldur            w5, [x0, #0xb]
    // 0xde6e58: DecompressPointer r5
    //     0xde6e58: add             x5, x5, HEAP, lsl #32
    // 0xde6e5c: cmp             w5, NULL
    // 0xde6e60: b.eq            #0xde6f24
    // 0xde6e64: LoadField: r0 = r5->field_b
    //     0xde6e64: ldur            w0, [x5, #0xb]
    // 0xde6e68: DecompressPointer r0
    //     0xde6e68: add             x0, x0, HEAP, lsl #32
    // 0xde6e6c: stur            x0, [fp, #-8]
    // 0xde6e70: r0 = DecoratedBoxTransition()
    //     0xde6e70: bl              #0xde6f28  ; AllocateDecoratedBoxTransitionStub -> DecoratedBoxTransition (size=0x1c)
    // 0xde6e74: mov             x1, x0
    // 0xde6e78: ldur            x0, [fp, #-0x10]
    // 0xde6e7c: stur            x1, [fp, #-0x30]
    // 0xde6e80: StoreField: r1->field_f = r0
    //     0xde6e80: stur            w0, [x1, #0xf]
    // 0xde6e84: r2 = Instance_DecorationPosition
    //     0xde6e84: add             x2, PP, #0x80, lsl #12  ; [pp+0x80ef0] Obj!DecorationPosition@12c4381
    //     0xde6e88: ldr             x2, [x2, #0xef0]
    // 0xde6e8c: StoreField: r1->field_13 = r2
    //     0xde6e8c: stur            w2, [x1, #0x13]
    // 0xde6e90: ldur            x2, [fp, #-8]
    // 0xde6e94: ArrayStore: r1[0] = r2  ; List_4
    //     0xde6e94: stur            w2, [x1, #0x17]
    // 0xde6e98: StoreField: r1->field_b = r0
    //     0xde6e98: stur            w0, [x1, #0xb]
    // 0xde6e9c: r0 = SlideTransition()
    //     0xde6e9c: bl              #0xb28364  ; AllocateSlideTransitionStub -> SlideTransition (size=0x1c)
    // 0xde6ea0: mov             x1, x0
    // 0xde6ea4: r0 = true
    //     0xde6ea4: add             x0, NULL, #0x20  ; true
    // 0xde6ea8: stur            x1, [fp, #-8]
    // 0xde6eac: StoreField: r1->field_13 = r0
    //     0xde6eac: stur            w0, [x1, #0x13]
    // 0xde6eb0: ldur            x0, [fp, #-0x28]
    // 0xde6eb4: StoreField: r1->field_f = r0
    //     0xde6eb4: stur            w0, [x1, #0xf]
    // 0xde6eb8: ldur            x2, [fp, #-0x30]
    // 0xde6ebc: ArrayStore: r1[0] = r2  ; List_4
    //     0xde6ebc: stur            w2, [x1, #0x17]
    // 0xde6ec0: ldur            x2, [fp, #-0x18]
    // 0xde6ec4: StoreField: r1->field_b = r2
    //     0xde6ec4: stur            w2, [x1, #0xb]
    // 0xde6ec8: r0 = SlideTransition()
    //     0xde6ec8: bl              #0xb28364  ; AllocateSlideTransitionStub -> SlideTransition (size=0x1c)
    // 0xde6ecc: r1 = false
    //     0xde6ecc: add             x1, NULL, #0x30  ; false
    // 0xde6ed0: StoreField: r0->field_13 = r1
    //     0xde6ed0: stur            w1, [x0, #0x13]
    // 0xde6ed4: ldur            x1, [fp, #-0x28]
    // 0xde6ed8: StoreField: r0->field_f = r1
    //     0xde6ed8: stur            w1, [x0, #0xf]
    // 0xde6edc: ldur            x1, [fp, #-8]
    // 0xde6ee0: ArrayStore: r0[0] = r1  ; List_4
    //     0xde6ee0: stur            w1, [x0, #0x17]
    // 0xde6ee4: ldur            x1, [fp, #-0x20]
    // 0xde6ee8: StoreField: r0->field_b = r1
    //     0xde6ee8: stur            w1, [x0, #0xb]
    // 0xde6eec: LeaveFrame
    //     0xde6eec: mov             SP, fp
    //     0xde6ef0: ldp             fp, lr, [SP], #0x10
    // 0xde6ef4: ret
    //     0xde6ef4: ret             
    // 0xde6ef8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde6ef8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde6efc: b               #0xde6dfc
    // 0xde6f00: r9 = _secondaryPositionAnimation
    //     0xde6f00: add             x9, PP, #0xad, lsl #12  ; [pp+0xadad8] Field <_CupertinoPageTransitionState@111053933._secondaryPositionAnimation@111053933>: late (offset: 0x18)
    //     0xde6f04: ldr             x9, [x9, #0xad8]
    // 0xde6f08: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xde6f08: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xde6f0c: r9 = _primaryPositionAnimation
    //     0xde6f0c: add             x9, PP, #0xad, lsl #12  ; [pp+0xadae0] Field <_CupertinoPageTransitionState@111053933._primaryPositionAnimation@111053933>: late (offset: 0x14)
    //     0xde6f10: ldr             x9, [x9, #0xae0]
    // 0xde6f14: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xde6f14: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xde6f18: r9 = _primaryShadowAnimation
    //     0xde6f18: add             x9, PP, #0xad, lsl #12  ; [pp+0xadae8] Field <_CupertinoPageTransitionState@111053933._primaryShadowAnimation@111053933>: late (offset: 0x1c)
    //     0xde6f1c: ldr             x9, [x9, #0xae8]
    // 0xde6f20: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xde6f20: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xde6f24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde6f24: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf6c878, size: 0x12c
    // 0xf6c878: EnterFrame
    //     0xf6c878: stp             fp, lr, [SP, #-0x10]!
    //     0xf6c87c: mov             fp, SP
    // 0xf6c880: AllocStack(0x10)
    //     0xf6c880: sub             SP, SP, #0x10
    // 0xf6c884: SetupParameters(_CupertinoPageTransitionState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xf6c884: mov             x4, x1
    //     0xf6c888: mov             x3, x2
    //     0xf6c88c: stur            x1, [fp, #-8]
    //     0xf6c890: stur            x2, [fp, #-0x10]
    // 0xf6c894: CheckStackOverflow
    //     0xf6c894: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6c898: cmp             SP, x16
    //     0xf6c89c: b.ls            #0xf6c998
    // 0xf6c8a0: mov             x0, x3
    // 0xf6c8a4: r2 = Null
    //     0xf6c8a4: mov             x2, NULL
    // 0xf6c8a8: r1 = Null
    //     0xf6c8a8: mov             x1, NULL
    // 0xf6c8ac: r4 = 60
    //     0xf6c8ac: mov             x4, #0x3c
    // 0xf6c8b0: branchIfSmi(r0, 0xf6c8bc)
    //     0xf6c8b0: tbz             w0, #0, #0xf6c8bc
    // 0xf6c8b4: r4 = LoadClassIdInstr(r0)
    //     0xf6c8b4: ldur            x4, [x0, #-1]
    //     0xf6c8b8: ubfx            x4, x4, #0xc, #0x14
    // 0xf6c8bc: r17 = 6515
    //     0xf6c8bc: mov             x17, #0x1973
    // 0xf6c8c0: cmp             x4, x17
    // 0xf6c8c4: b.eq            #0xf6c8dc
    // 0xf6c8c8: r8 = CupertinoPageTransition
    //     0xf6c8c8: add             x8, PP, #0xad, lsl #12  ; [pp+0xadaf0] Type: CupertinoPageTransition
    //     0xf6c8cc: ldr             x8, [x8, #0xaf0]
    // 0xf6c8d0: r3 = Null
    //     0xf6c8d0: add             x3, PP, #0xad, lsl #12  ; [pp+0xadaf8] Null
    //     0xf6c8d4: ldr             x3, [x3, #0xaf8]
    // 0xf6c8d8: r0 = CupertinoPageTransition()
    //     0xf6c8d8: bl              #0xb28228  ; IsType_CupertinoPageTransition_Stub
    // 0xf6c8dc: ldur            x3, [fp, #-8]
    // 0xf6c8e0: LoadField: r2 = r3->field_7
    //     0xf6c8e0: ldur            w2, [x3, #7]
    // 0xf6c8e4: DecompressPointer r2
    //     0xf6c8e4: add             x2, x2, HEAP, lsl #32
    // 0xf6c8e8: ldur            x0, [fp, #-0x10]
    // 0xf6c8ec: r1 = Null
    //     0xf6c8ec: mov             x1, NULL
    // 0xf6c8f0: cmp             w2, NULL
    // 0xf6c8f4: b.eq            #0xf6c918
    // 0xf6c8f8: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf6c8f8: ldur            w4, [x2, #0x17]
    // 0xf6c8fc: DecompressPointer r4
    //     0xf6c8fc: add             x4, x4, HEAP, lsl #32
    // 0xf6c900: r8 = X0 bound StatefulWidget
    //     0xf6c900: add             x8, PP, #0x12, lsl #12  ; [pp+0x12498] TypeParameter: X0 bound StatefulWidget
    //     0xf6c904: ldr             x8, [x8, #0x498]
    // 0xf6c908: LoadField: r9 = r4->field_7
    //     0xf6c908: ldur            x9, [x4, #7]
    // 0xf6c90c: r3 = Null
    //     0xf6c90c: add             x3, PP, #0xad, lsl #12  ; [pp+0xadb08] Null
    //     0xf6c910: ldr             x3, [x3, #0xb08]
    // 0xf6c914: blr             x9
    // 0xf6c918: ldur            x0, [fp, #-0x10]
    // 0xf6c91c: LoadField: r1 = r0->field_f
    //     0xf6c91c: ldur            w1, [x0, #0xf]
    // 0xf6c920: DecompressPointer r1
    //     0xf6c920: add             x1, x1, HEAP, lsl #32
    // 0xf6c924: ldur            x2, [fp, #-8]
    // 0xf6c928: LoadField: r3 = r2->field_b
    //     0xf6c928: ldur            w3, [x2, #0xb]
    // 0xf6c92c: DecompressPointer r3
    //     0xf6c92c: add             x3, x3, HEAP, lsl #32
    // 0xf6c930: cmp             w3, NULL
    // 0xf6c934: b.eq            #0xf6c9a0
    // 0xf6c938: LoadField: r4 = r3->field_f
    //     0xf6c938: ldur            w4, [x3, #0xf]
    // 0xf6c93c: DecompressPointer r4
    //     0xf6c93c: add             x4, x4, HEAP, lsl #32
    // 0xf6c940: cmp             w1, w4
    // 0xf6c944: b.ne            #0xf6c978
    // 0xf6c948: LoadField: r1 = r0->field_13
    //     0xf6c948: ldur            w1, [x0, #0x13]
    // 0xf6c94c: DecompressPointer r1
    //     0xf6c94c: add             x1, x1, HEAP, lsl #32
    // 0xf6c950: LoadField: r4 = r3->field_13
    //     0xf6c950: ldur            w4, [x3, #0x13]
    // 0xf6c954: DecompressPointer r4
    //     0xf6c954: add             x4, x4, HEAP, lsl #32
    // 0xf6c958: cmp             w1, w4
    // 0xf6c95c: b.ne            #0xf6c978
    // 0xf6c960: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf6c960: ldur            w1, [x0, #0x17]
    // 0xf6c964: DecompressPointer r1
    //     0xf6c964: add             x1, x1, HEAP, lsl #32
    // 0xf6c968: ArrayLoad: r0 = r3[0]  ; List_4
    //     0xf6c968: ldur            w0, [x3, #0x17]
    // 0xf6c96c: DecompressPointer r0
    //     0xf6c96c: add             x0, x0, HEAP, lsl #32
    // 0xf6c970: cmp             w1, w0
    // 0xf6c974: b.eq            #0xf6c988
    // 0xf6c978: mov             x1, x2
    // 0xf6c97c: r0 = _disposeCurve()
    //     0xf6c97c: bl              #0xf6cd90  ; [package:flutter/src/cupertino/route.dart] _CupertinoPageTransitionState::_disposeCurve
    // 0xf6c980: ldur            x1, [fp, #-8]
    // 0xf6c984: r0 = _setupAnimation()
    //     0xf6c984: bl              #0xf6c9a4  ; [package:flutter/src/cupertino/route.dart] _CupertinoPageTransitionState::_setupAnimation
    // 0xf6c988: r0 = Null
    //     0xf6c988: mov             x0, NULL
    // 0xf6c98c: LeaveFrame
    //     0xf6c98c: mov             SP, fp
    //     0xf6c990: ldp             fp, lr, [SP], #0x10
    // 0xf6c994: ret
    //     0xf6c994: ret             
    // 0xf6c998: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6c998: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6c99c: b               #0xf6c8a0
    // 0xf6c9a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6c9a0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _setupAnimation(/* No info */) {
    // ** addr: 0xf6c9a4, size: 0x344
    // 0xf6c9a4: EnterFrame
    //     0xf6c9a4: stp             fp, lr, [SP, #-0x10]!
    //     0xf6c9a8: mov             fp, SP
    // 0xf6c9ac: AllocStack(0x28)
    //     0xf6c9ac: sub             SP, SP, #0x28
    // 0xf6c9b0: SetupParameters(_CupertinoPageTransitionState this /* r1 => r0, fp-0x10 */)
    //     0xf6c9b0: mov             x0, x1
    //     0xf6c9b4: stur            x1, [fp, #-0x10]
    // 0xf6c9b8: CheckStackOverflow
    //     0xf6c9b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6c9bc: cmp             SP, x16
    //     0xf6c9c0: b.ls            #0xf6ccc8
    // 0xf6c9c4: LoadField: r1 = r0->field_b
    //     0xf6c9c4: ldur            w1, [x0, #0xb]
    // 0xf6c9c8: DecompressPointer r1
    //     0xf6c9c8: add             x1, x1, HEAP, lsl #32
    // 0xf6c9cc: cmp             w1, NULL
    // 0xf6c9d0: b.eq            #0xf6ccd0
    // 0xf6c9d4: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xf6c9d4: ldur            w2, [x1, #0x17]
    // 0xf6c9d8: DecompressPointer r2
    //     0xf6c9d8: add             x2, x2, HEAP, lsl #32
    // 0xf6c9dc: tbz             w2, #4, #0xf6cb34
    // 0xf6c9e0: LoadField: r3 = r1->field_f
    //     0xf6c9e0: ldur            w3, [x1, #0xf]
    // 0xf6c9e4: DecompressPointer r3
    //     0xf6c9e4: add             x3, x3, HEAP, lsl #32
    // 0xf6c9e8: stur            x3, [fp, #-8]
    // 0xf6c9ec: r1 = <double>
    //     0xf6c9ec: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf6c9f0: r0 = FlippedCurve()
    //     0xf6c9f0: bl              #0xb6f814  ; AllocateFlippedCurveStub -> FlippedCurve (size=0x10)
    // 0xf6c9f4: r2 = Instance_ThreePointCubic
    //     0xf6c9f4: add             x2, PP, #0xad, lsl #12  ; [pp+0xadb18] Obj!ThreePointCubic@129f401
    //     0xf6c9f8: ldr             x2, [x2, #0xb18]
    // 0xf6c9fc: stur            x0, [fp, #-0x18]
    // 0xf6ca00: StoreField: r0->field_b = r2
    //     0xf6ca00: stur            w2, [x0, #0xb]
    // 0xf6ca04: r1 = <double>
    //     0xf6ca04: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf6ca08: r0 = CurvedAnimation()
    //     0xf6ca08: bl              #0x915e4c  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0xf6ca0c: stur            x0, [fp, #-0x20]
    // 0xf6ca10: ldur            x16, [fp, #-0x18]
    // 0xf6ca14: str             x16, [SP]
    // 0xf6ca18: mov             x1, x0
    // 0xf6ca1c: ldur            x3, [fp, #-8]
    // 0xf6ca20: r2 = Instance_ThreePointCubic
    //     0xf6ca20: add             x2, PP, #0xad, lsl #12  ; [pp+0xadb18] Obj!ThreePointCubic@129f401
    //     0xf6ca24: ldr             x2, [x2, #0xb18]
    // 0xf6ca28: r4 = const [0, 0x4, 0x1, 0x3, reverseCurve, 0x3, null]
    //     0xf6ca28: add             x4, PP, #0x16, lsl #12  ; [pp+0x16dc0] List(7) [0, 0x4, 0x1, 0x3, "reverseCurve", 0x3, Null]
    //     0xf6ca2c: ldr             x4, [x4, #0xdc0]
    // 0xf6ca30: r0 = CurvedAnimation()
    //     0xf6ca30: bl              #0x915be4  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0xf6ca34: ldur            x0, [fp, #-0x20]
    // 0xf6ca38: ldur            x2, [fp, #-0x10]
    // 0xf6ca3c: StoreField: r2->field_1f = r0
    //     0xf6ca3c: stur            w0, [x2, #0x1f]
    //     0xf6ca40: ldurb           w16, [x2, #-1]
    //     0xf6ca44: ldurb           w17, [x0, #-1]
    //     0xf6ca48: and             x16, x17, x16, lsr #2
    //     0xf6ca4c: tst             x16, HEAP, lsr #32
    //     0xf6ca50: b.eq            #0xf6ca58
    //     0xf6ca54: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf6ca58: LoadField: r0 = r2->field_b
    //     0xf6ca58: ldur            w0, [x2, #0xb]
    // 0xf6ca5c: DecompressPointer r0
    //     0xf6ca5c: add             x0, x0, HEAP, lsl #32
    // 0xf6ca60: cmp             w0, NULL
    // 0xf6ca64: b.eq            #0xf6ccd4
    // 0xf6ca68: LoadField: r3 = r0->field_13
    //     0xf6ca68: ldur            w3, [x0, #0x13]
    // 0xf6ca6c: DecompressPointer r3
    //     0xf6ca6c: add             x3, x3, HEAP, lsl #32
    // 0xf6ca70: stur            x3, [fp, #-8]
    // 0xf6ca74: r1 = <double>
    //     0xf6ca74: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf6ca78: r0 = CurvedAnimation()
    //     0xf6ca78: bl              #0x915e4c  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0xf6ca7c: stur            x0, [fp, #-0x18]
    // 0xf6ca80: r16 = Instance_Cubic
    //     0xf6ca80: add             x16, PP, #0x99, lsl #12  ; [pp+0x99090] Obj!Cubic@129f7e1
    //     0xf6ca84: ldr             x16, [x16, #0x90]
    // 0xf6ca88: str             x16, [SP]
    // 0xf6ca8c: mov             x1, x0
    // 0xf6ca90: ldur            x3, [fp, #-8]
    // 0xf6ca94: r2 = Instance_Cubic
    //     0xf6ca94: add             x2, PP, #0x99, lsl #12  ; [pp+0x99098] Obj!Cubic@129f7b1
    //     0xf6ca98: ldr             x2, [x2, #0x98]
    // 0xf6ca9c: r4 = const [0, 0x4, 0x1, 0x3, reverseCurve, 0x3, null]
    //     0xf6ca9c: add             x4, PP, #0x16, lsl #12  ; [pp+0x16dc0] List(7) [0, 0x4, 0x1, 0x3, "reverseCurve", 0x3, Null]
    //     0xf6caa0: ldr             x4, [x4, #0xdc0]
    // 0xf6caa4: r0 = CurvedAnimation()
    //     0xf6caa4: bl              #0x915be4  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0xf6caa8: ldur            x0, [fp, #-0x18]
    // 0xf6caac: ldur            x2, [fp, #-0x10]
    // 0xf6cab0: StoreField: r2->field_23 = r0
    //     0xf6cab0: stur            w0, [x2, #0x23]
    //     0xf6cab4: ldurb           w16, [x2, #-1]
    //     0xf6cab8: ldurb           w17, [x0, #-1]
    //     0xf6cabc: and             x16, x17, x16, lsr #2
    //     0xf6cac0: tst             x16, HEAP, lsr #32
    //     0xf6cac4: b.eq            #0xf6cacc
    //     0xf6cac8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf6cacc: LoadField: r0 = r2->field_b
    //     0xf6cacc: ldur            w0, [x2, #0xb]
    // 0xf6cad0: DecompressPointer r0
    //     0xf6cad0: add             x0, x0, HEAP, lsl #32
    // 0xf6cad4: cmp             w0, NULL
    // 0xf6cad8: b.eq            #0xf6ccd8
    // 0xf6cadc: LoadField: r3 = r0->field_f
    //     0xf6cadc: ldur            w3, [x0, #0xf]
    // 0xf6cae0: DecompressPointer r3
    //     0xf6cae0: add             x3, x3, HEAP, lsl #32
    // 0xf6cae4: stur            x3, [fp, #-8]
    // 0xf6cae8: r1 = <double>
    //     0xf6cae8: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf6caec: r0 = CurvedAnimation()
    //     0xf6caec: bl              #0x915e4c  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0xf6caf0: mov             x1, x0
    // 0xf6caf4: ldur            x3, [fp, #-8]
    // 0xf6caf8: r2 = Instance_Cubic
    //     0xf6caf8: add             x2, PP, #0x99, lsl #12  ; [pp+0x99098] Obj!Cubic@129f7b1
    //     0xf6cafc: ldr             x2, [x2, #0x98]
    // 0xf6cb00: stur            x0, [fp, #-8]
    // 0xf6cb04: r4 = const [0, 0x3, 0, 0x3, null]
    //     0xf6cb04: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0xf6cb08: r0 = CurvedAnimation()
    //     0xf6cb08: bl              #0x915be4  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0xf6cb0c: ldur            x0, [fp, #-8]
    // 0xf6cb10: ldur            x1, [fp, #-0x10]
    // 0xf6cb14: StoreField: r1->field_27 = r0
    //     0xf6cb14: stur            w0, [x1, #0x27]
    //     0xf6cb18: ldurb           w16, [x1, #-1]
    //     0xf6cb1c: ldurb           w17, [x0, #-1]
    //     0xf6cb20: and             x16, x17, x16, lsr #2
    //     0xf6cb24: tst             x16, HEAP, lsr #32
    //     0xf6cb28: b.eq            #0xf6cb30
    //     0xf6cb2c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf6cb30: b               #0xf6cb38
    // 0xf6cb34: mov             x1, x0
    // 0xf6cb38: LoadField: r0 = r1->field_1f
    //     0xf6cb38: ldur            w0, [x1, #0x1f]
    // 0xf6cb3c: DecompressPointer r0
    //     0xf6cb3c: add             x0, x0, HEAP, lsl #32
    // 0xf6cb40: cmp             w0, NULL
    // 0xf6cb44: b.ne            #0xf6cb64
    // 0xf6cb48: LoadField: r0 = r1->field_b
    //     0xf6cb48: ldur            w0, [x1, #0xb]
    // 0xf6cb4c: DecompressPointer r0
    //     0xf6cb4c: add             x0, x0, HEAP, lsl #32
    // 0xf6cb50: cmp             w0, NULL
    // 0xf6cb54: b.eq            #0xf6ccdc
    // 0xf6cb58: LoadField: r2 = r0->field_f
    //     0xf6cb58: ldur            w2, [x0, #0xf]
    // 0xf6cb5c: DecompressPointer r2
    //     0xf6cb5c: add             x2, x2, HEAP, lsl #32
    // 0xf6cb60: b               #0xf6cb68
    // 0xf6cb64: mov             x2, x0
    // 0xf6cb68: stur            x2, [fp, #-8]
    // 0xf6cb6c: r0 = LoadStaticField(0x74c)
    //     0xf6cb6c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf6cb70: ldr             x0, [x0, #0xe98]
    // 0xf6cb74: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf6cb78: cmp             w0, w16
    // 0xf6cb7c: b.ne            #0xf6cb8c
    // 0xf6cb80: r2 = _kRightMiddleTween
    //     0xf6cb80: add             x2, PP, #0xad, lsl #12  ; [pp+0xadb20] Field <::._kRightMiddleTween@111053933>: static late final (offset: 0x74c)
    //     0xf6cb84: ldr             x2, [x2, #0xb20]
    // 0xf6cb88: r0 = InitLateFinalStaticField()
    //     0xf6cb88: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xf6cb8c: mov             x1, x0
    // 0xf6cb90: ldur            x2, [fp, #-8]
    // 0xf6cb94: r0 = animate()
    //     0xf6cb94: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xf6cb98: ldur            x1, [fp, #-0x10]
    // 0xf6cb9c: StoreField: r1->field_13 = r0
    //     0xf6cb9c: stur            w0, [x1, #0x13]
    //     0xf6cba0: ldurb           w16, [x1, #-1]
    //     0xf6cba4: ldurb           w17, [x0, #-1]
    //     0xf6cba8: and             x16, x17, x16, lsr #2
    //     0xf6cbac: tst             x16, HEAP, lsr #32
    //     0xf6cbb0: b.eq            #0xf6cbb8
    //     0xf6cbb4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf6cbb8: LoadField: r0 = r1->field_23
    //     0xf6cbb8: ldur            w0, [x1, #0x23]
    // 0xf6cbbc: DecompressPointer r0
    //     0xf6cbbc: add             x0, x0, HEAP, lsl #32
    // 0xf6cbc0: cmp             w0, NULL
    // 0xf6cbc4: b.ne            #0xf6cbe4
    // 0xf6cbc8: LoadField: r0 = r1->field_b
    //     0xf6cbc8: ldur            w0, [x1, #0xb]
    // 0xf6cbcc: DecompressPointer r0
    //     0xf6cbcc: add             x0, x0, HEAP, lsl #32
    // 0xf6cbd0: cmp             w0, NULL
    // 0xf6cbd4: b.eq            #0xf6cce0
    // 0xf6cbd8: LoadField: r2 = r0->field_13
    //     0xf6cbd8: ldur            w2, [x0, #0x13]
    // 0xf6cbdc: DecompressPointer r2
    //     0xf6cbdc: add             x2, x2, HEAP, lsl #32
    // 0xf6cbe0: b               #0xf6cbe8
    // 0xf6cbe4: mov             x2, x0
    // 0xf6cbe8: stur            x2, [fp, #-8]
    // 0xf6cbec: r0 = LoadStaticField(0x750)
    //     0xf6cbec: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf6cbf0: ldr             x0, [x0, #0xea0]
    // 0xf6cbf4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf6cbf8: cmp             w0, w16
    // 0xf6cbfc: b.ne            #0xf6cc0c
    // 0xf6cc00: r2 = _kMiddleLeftTween
    //     0xf6cc00: add             x2, PP, #0x99, lsl #12  ; [pp+0x990a0] Field <::._kMiddleLeftTween@111053933>: static late final (offset: 0x750)
    //     0xf6cc04: ldr             x2, [x2, #0xa0]
    // 0xf6cc08: r0 = InitLateFinalStaticField()
    //     0xf6cc08: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xf6cc0c: mov             x1, x0
    // 0xf6cc10: ldur            x2, [fp, #-8]
    // 0xf6cc14: r0 = animate()
    //     0xf6cc14: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xf6cc18: ldur            x1, [fp, #-0x10]
    // 0xf6cc1c: ArrayStore: r1[0] = r0  ; List_4
    //     0xf6cc1c: stur            w0, [x1, #0x17]
    //     0xf6cc20: ldurb           w16, [x1, #-1]
    //     0xf6cc24: ldurb           w17, [x0, #-1]
    //     0xf6cc28: and             x16, x17, x16, lsr #2
    //     0xf6cc2c: tst             x16, HEAP, lsr #32
    //     0xf6cc30: b.eq            #0xf6cc38
    //     0xf6cc34: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf6cc38: LoadField: r0 = r1->field_27
    //     0xf6cc38: ldur            w0, [x1, #0x27]
    // 0xf6cc3c: DecompressPointer r0
    //     0xf6cc3c: add             x0, x0, HEAP, lsl #32
    // 0xf6cc40: cmp             w0, NULL
    // 0xf6cc44: b.ne            #0xf6cc64
    // 0xf6cc48: LoadField: r0 = r1->field_b
    //     0xf6cc48: ldur            w0, [x1, #0xb]
    // 0xf6cc4c: DecompressPointer r0
    //     0xf6cc4c: add             x0, x0, HEAP, lsl #32
    // 0xf6cc50: cmp             w0, NULL
    // 0xf6cc54: b.eq            #0xf6cce4
    // 0xf6cc58: LoadField: r2 = r0->field_f
    //     0xf6cc58: ldur            w2, [x0, #0xf]
    // 0xf6cc5c: DecompressPointer r2
    //     0xf6cc5c: add             x2, x2, HEAP, lsl #32
    // 0xf6cc60: b               #0xf6cc68
    // 0xf6cc64: mov             x2, x0
    // 0xf6cc68: stur            x2, [fp, #-8]
    // 0xf6cc6c: r0 = LoadStaticField(0x748)
    //     0xf6cc6c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf6cc70: ldr             x0, [x0, #0xe90]
    // 0xf6cc74: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf6cc78: cmp             w0, w16
    // 0xf6cc7c: b.ne            #0xf6cc8c
    // 0xf6cc80: r2 = kTween
    //     0xf6cc80: add             x2, PP, #0xad, lsl #12  ; [pp+0xadb28] Field <_CupertinoEdgeShadowDecoration@111053933.kTween>: static late (offset: 0x748)
    //     0xf6cc84: ldr             x2, [x2, #0xb28]
    // 0xf6cc88: r0 = InitLateStaticField()
    //     0xf6cc88: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0xf6cc8c: mov             x1, x0
    // 0xf6cc90: ldur            x2, [fp, #-8]
    // 0xf6cc94: r0 = animate()
    //     0xf6cc94: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xf6cc98: ldur            x1, [fp, #-0x10]
    // 0xf6cc9c: StoreField: r1->field_1b = r0
    //     0xf6cc9c: stur            w0, [x1, #0x1b]
    //     0xf6cca0: ldurb           w16, [x1, #-1]
    //     0xf6cca4: ldurb           w17, [x0, #-1]
    //     0xf6cca8: and             x16, x17, x16, lsr #2
    //     0xf6ccac: tst             x16, HEAP, lsr #32
    //     0xf6ccb0: b.eq            #0xf6ccb8
    //     0xf6ccb4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf6ccb8: r0 = Null
    //     0xf6ccb8: mov             x0, NULL
    // 0xf6ccbc: LeaveFrame
    //     0xf6ccbc: mov             SP, fp
    //     0xf6ccc0: ldp             fp, lr, [SP], #0x10
    // 0xf6ccc4: ret
    //     0xf6ccc4: ret             
    // 0xf6ccc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6ccc8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6cccc: b               #0xf6c9c4
    // 0xf6ccd0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6ccd0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6ccd4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6ccd4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6ccd8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6ccd8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6ccdc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6ccdc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6cce0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6cce0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6cce4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6cce4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _disposeCurve(/* No info */) {
    // ** addr: 0xf6cd90, size: 0x94
    // 0xf6cd90: EnterFrame
    //     0xf6cd90: stp             fp, lr, [SP, #-0x10]!
    //     0xf6cd94: mov             fp, SP
    // 0xf6cd98: AllocStack(0x8)
    //     0xf6cd98: sub             SP, SP, #8
    // 0xf6cd9c: SetupParameters(_CupertinoPageTransitionState this /* r1 => r0, fp-0x8 */)
    //     0xf6cd9c: mov             x0, x1
    //     0xf6cda0: stur            x1, [fp, #-8]
    // 0xf6cda4: CheckStackOverflow
    //     0xf6cda4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6cda8: cmp             SP, x16
    //     0xf6cdac: b.ls            #0xf6ce1c
    // 0xf6cdb0: LoadField: r1 = r0->field_1f
    //     0xf6cdb0: ldur            w1, [x0, #0x1f]
    // 0xf6cdb4: DecompressPointer r1
    //     0xf6cdb4: add             x1, x1, HEAP, lsl #32
    // 0xf6cdb8: cmp             w1, NULL
    // 0xf6cdbc: b.eq            #0xf6cdc8
    // 0xf6cdc0: r0 = dispose()
    //     0xf6cdc0: bl              #0xb29014  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::dispose
    // 0xf6cdc4: ldur            x0, [fp, #-8]
    // 0xf6cdc8: LoadField: r1 = r0->field_23
    //     0xf6cdc8: ldur            w1, [x0, #0x23]
    // 0xf6cdcc: DecompressPointer r1
    //     0xf6cdcc: add             x1, x1, HEAP, lsl #32
    // 0xf6cdd0: cmp             w1, NULL
    // 0xf6cdd4: b.eq            #0xf6cde0
    // 0xf6cdd8: r0 = dispose()
    //     0xf6cdd8: bl              #0xb29014  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::dispose
    // 0xf6cddc: ldur            x0, [fp, #-8]
    // 0xf6cde0: LoadField: r1 = r0->field_27
    //     0xf6cde0: ldur            w1, [x0, #0x27]
    // 0xf6cde4: DecompressPointer r1
    //     0xf6cde4: add             x1, x1, HEAP, lsl #32
    // 0xf6cde8: cmp             w1, NULL
    // 0xf6cdec: b.ne            #0xf6cdf8
    // 0xf6cdf0: mov             x1, x0
    // 0xf6cdf4: b               #0xf6ce00
    // 0xf6cdf8: r0 = dispose()
    //     0xf6cdf8: bl              #0xb29014  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::dispose
    // 0xf6cdfc: ldur            x1, [fp, #-8]
    // 0xf6ce00: StoreField: r1->field_1f = rNULL
    //     0xf6ce00: stur            NULL, [x1, #0x1f]
    // 0xf6ce04: StoreField: r1->field_23 = rNULL
    //     0xf6ce04: stur            NULL, [x1, #0x23]
    // 0xf6ce08: StoreField: r1->field_27 = rNULL
    //     0xf6ce08: stur            NULL, [x1, #0x27]
    // 0xf6ce0c: r0 = Null
    //     0xf6ce0c: mov             x0, NULL
    // 0xf6ce10: LeaveFrame
    //     0xf6ce10: mov             SP, fp
    //     0xf6ce14: ldp             fp, lr, [SP], #0x10
    // 0xf6ce18: ret
    //     0xf6ce18: ret             
    // 0xf6ce1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6ce1c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6ce20: b               #0xf6cdb0
  }
  _ initState(/* No info */) {
    // ** addr: 0xf8e99c, size: 0x30
    // 0xf8e99c: EnterFrame
    //     0xf8e99c: stp             fp, lr, [SP, #-0x10]!
    //     0xf8e9a0: mov             fp, SP
    // 0xf8e9a4: CheckStackOverflow
    //     0xf8e9a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf8e9a8: cmp             SP, x16
    //     0xf8e9ac: b.ls            #0xf8e9c4
    // 0xf8e9b0: r0 = _setupAnimation()
    //     0xf8e9b0: bl              #0xf6c9a4  ; [package:flutter/src/cupertino/route.dart] _CupertinoPageTransitionState::_setupAnimation
    // 0xf8e9b4: r0 = Null
    //     0xf8e9b4: mov             x0, NULL
    // 0xf8e9b8: LeaveFrame
    //     0xf8e9b8: mov             SP, fp
    //     0xf8e9bc: ldp             fp, lr, [SP], #0x10
    // 0xf8e9c0: ret
    //     0xf8e9c0: ret             
    // 0xf8e9c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf8e9c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf8e9c8: b               #0xf8e9b0
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10e48f8, size: 0x30
    // 0x10e48f8: EnterFrame
    //     0x10e48f8: stp             fp, lr, [SP, #-0x10]!
    //     0x10e48fc: mov             fp, SP
    // 0x10e4900: CheckStackOverflow
    //     0x10e4900: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e4904: cmp             SP, x16
    //     0x10e4908: b.ls            #0x10e4920
    // 0x10e490c: r0 = _disposeCurve()
    //     0x10e490c: bl              #0xf6cd90  ; [package:flutter/src/cupertino/route.dart] _CupertinoPageTransitionState::_disposeCurve
    // 0x10e4910: r0 = Null
    //     0x10e4910: mov             x0, NULL
    // 0x10e4914: LeaveFrame
    //     0x10e4914: mov             SP, fp
    //     0x10e4918: ldp             fp, lr, [SP], #0x10
    // 0x10e491c: ret
    //     0x10e491c: ret             
    // 0x10e4920: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e4920: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e4924: b               #0x10e490c
  }
}

// class id: 6513, size: 0x1c, field offset: 0xc
//   const constructor, 
class _CupertinoBackGestureDetector<X0> extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa071c, size: 0x44
    // 0xfa071c: EnterFrame
    //     0xfa071c: stp             fp, lr, [SP, #-0x10]!
    //     0xfa0720: mov             fp, SP
    // 0xfa0724: LoadField: r2 = r1->field_b
    //     0xfa0724: ldur            w2, [x1, #0xb]
    // 0xfa0728: DecompressPointer r2
    //     0xfa0728: add             x2, x2, HEAP, lsl #32
    // 0xfa072c: r1 = Null
    //     0xfa072c: mov             x1, NULL
    // 0xfa0730: r3 = <_CupertinoBackGestureDetector<X0>, X0>
    //     0xfa0730: add             x3, PP, #0xd0, lsl #12  ; [pp+0xd04c0] TypeArguments: <_CupertinoBackGestureDetector<X0>, X0>
    //     0xfa0734: ldr             x3, [x3, #0x4c0]
    // 0xfa0738: r30 = InstantiateTypeArgumentsStub
    //     0xfa0738: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0xfa073c: LoadField: r30 = r30->field_7
    //     0xfa073c: ldur            lr, [lr, #7]
    // 0xfa0740: blr             lr
    // 0xfa0744: mov             x1, x0
    // 0xfa0748: r0 = _CupertinoBackGestureDetectorState()
    //     0xfa0748: bl              #0xfa0760  ; Allocate_CupertinoBackGestureDetectorStateStub -> _CupertinoBackGestureDetectorState<C1X0> (size=0x1c)
    // 0xfa074c: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa0750: ArrayStore: r0[0] = r1  ; List_4
    //     0xfa0750: stur            w1, [x0, #0x17]
    // 0xfa0754: LeaveFrame
    //     0xfa0754: mov             SP, fp
    //     0xfa0758: ldp             fp, lr, [SP], #0x10
    // 0xfa075c: ret
    //     0xfa075c: ret             
  }
}

// class id: 6514, size: 0x1c, field offset: 0xc
//   const constructor, 
class CupertinoFullscreenDialogTransition extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa06e0, size: 0x30
    // 0xfa06e0: EnterFrame
    //     0xfa06e0: stp             fp, lr, [SP, #-0x10]!
    //     0xfa06e4: mov             fp, SP
    // 0xfa06e8: mov             x0, x1
    // 0xfa06ec: r1 = <CupertinoFullscreenDialogTransition>
    //     0xfa06ec: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa38a8] TypeArguments: <CupertinoFullscreenDialogTransition>
    //     0xfa06f0: ldr             x1, [x1, #0x8a8]
    // 0xfa06f4: r0 = _CupertinoFullscreenDialogTransitionState()
    //     0xfa06f4: bl              #0xfa0710  ; Allocate_CupertinoFullscreenDialogTransitionStateStub -> _CupertinoFullscreenDialogTransitionState (size=0x24)
    // 0xfa06f8: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa06fc: StoreField: r0->field_13 = r1
    //     0xfa06fc: stur            w1, [x0, #0x13]
    // 0xfa0700: ArrayStore: r0[0] = r1  ; List_4
    //     0xfa0700: stur            w1, [x0, #0x17]
    // 0xfa0704: LeaveFrame
    //     0xfa0704: mov             SP, fp
    //     0xfa0708: ldp             fp, lr, [SP], #0x10
    // 0xfa070c: ret
    //     0xfa070c: ret             
  }
}

// class id: 6515, size: 0x1c, field offset: 0xc
//   const constructor, 
class CupertinoPageTransition extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa06a0, size: 0x34
    // 0xfa06a0: EnterFrame
    //     0xfa06a0: stp             fp, lr, [SP, #-0x10]!
    //     0xfa06a4: mov             fp, SP
    // 0xfa06a8: mov             x0, x1
    // 0xfa06ac: r1 = <CupertinoPageTransition>
    //     0xfa06ac: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa38b0] TypeArguments: <CupertinoPageTransition>
    //     0xfa06b0: ldr             x1, [x1, #0x8b0]
    // 0xfa06b4: r0 = _CupertinoPageTransitionState()
    //     0xfa06b4: bl              #0xfa06d4  ; Allocate_CupertinoPageTransitionStateStub -> _CupertinoPageTransitionState (size=0x2c)
    // 0xfa06b8: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa06bc: StoreField: r0->field_13 = r1
    //     0xfa06bc: stur            w1, [x0, #0x13]
    // 0xfa06c0: ArrayStore: r0[0] = r1  ; List_4
    //     0xfa06c0: stur            w1, [x0, #0x17]
    // 0xfa06c4: StoreField: r0->field_1b = r1
    //     0xfa06c4: stur            w1, [x0, #0x1b]
    // 0xfa06c8: LeaveFrame
    //     0xfa06c8: mov             SP, fp
    //     0xfa06cc: ldp             fp, lr, [SP], #0x10
    // 0xfa06d0: ret
    //     0xfa06d0: ret             
  }
  [closure] static Widget? delegatedTransition(dynamic, BuildContext, Animation<double>, Animation<double>, bool, Widget?) {
    // ** addr: 0x12b89b4, size: 0x40
    // 0x12b89b4: EnterFrame
    //     0x12b89b4: stp             fp, lr, [SP, #-0x10]!
    //     0x12b89b8: mov             fp, SP
    // 0x12b89bc: CheckStackOverflow
    //     0x12b89bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12b89c0: cmp             SP, x16
    //     0x12b89c4: b.ls            #0x12b89ec
    // 0x12b89c8: ldr             x1, [fp, #0x30]
    // 0x12b89cc: ldr             x2, [fp, #0x28]
    // 0x12b89d0: ldr             x3, [fp, #0x20]
    // 0x12b89d4: ldr             x5, [fp, #0x18]
    // 0x12b89d8: ldr             x6, [fp, #0x10]
    // 0x12b89dc: r0 = delegatedTransition()
    //     0x12b89dc: bl              #0x12b89f4  ; [package:flutter/src/cupertino/route.dart] CupertinoPageTransition::delegatedTransition
    // 0x12b89e0: LeaveFrame
    //     0x12b89e0: mov             SP, fp
    //     0x12b89e4: ldp             fp, lr, [SP], #0x10
    // 0x12b89e8: ret
    //     0x12b89e8: ret             
    // 0x12b89ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12b89ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12b89f0: b               #0x12b89c8
  }
  static _ delegatedTransition(/* No info */) {
    // ** addr: 0x12b89f4, size: 0xd8
    // 0x12b89f4: EnterFrame
    //     0x12b89f4: stp             fp, lr, [SP, #-0x10]!
    //     0x12b89f8: mov             fp, SP
    // 0x12b89fc: AllocStack(0x28)
    //     0x12b89fc: sub             SP, SP, #0x28
    // 0x12b8a00: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */, dynamic _ /* r6 => r6, fp-0x18 */)
    //     0x12b8a00: mov             x0, x1
    //     0x12b8a04: stur            x1, [fp, #-8]
    //     0x12b8a08: stur            x3, [fp, #-0x10]
    //     0x12b8a0c: stur            x6, [fp, #-0x18]
    // 0x12b8a10: CheckStackOverflow
    //     0x12b8a10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12b8a14: cmp             SP, x16
    //     0x12b8a18: b.ls            #0x12b8ac4
    // 0x12b8a1c: r1 = <double>
    //     0x12b8a1c: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0x12b8a20: r0 = CurvedAnimation()
    //     0x12b8a20: bl              #0x915e4c  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x12b8a24: stur            x0, [fp, #-0x20]
    // 0x12b8a28: r16 = Instance_Cubic
    //     0x12b8a28: add             x16, PP, #0x99, lsl #12  ; [pp+0x99090] Obj!Cubic@129f7e1
    //     0x12b8a2c: ldr             x16, [x16, #0x90]
    // 0x12b8a30: str             x16, [SP]
    // 0x12b8a34: mov             x1, x0
    // 0x12b8a38: ldur            x3, [fp, #-0x10]
    // 0x12b8a3c: r2 = Instance_Cubic
    //     0x12b8a3c: add             x2, PP, #0x99, lsl #12  ; [pp+0x99098] Obj!Cubic@129f7b1
    //     0x12b8a40: ldr             x2, [x2, #0x98]
    // 0x12b8a44: r4 = const [0, 0x4, 0x1, 0x3, reverseCurve, 0x3, null]
    //     0x12b8a44: add             x4, PP, #0x16, lsl #12  ; [pp+0x16dc0] List(7) [0, 0x4, 0x1, 0x3, "reverseCurve", 0x3, Null]
    //     0x12b8a48: ldr             x4, [x4, #0xdc0]
    // 0x12b8a4c: r0 = CurvedAnimation()
    //     0x12b8a4c: bl              #0x915be4  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x12b8a50: r0 = LoadStaticField(0x750)
    //     0x12b8a50: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x12b8a54: ldr             x0, [x0, #0xea0]
    // 0x12b8a58: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12b8a5c: cmp             w0, w16
    // 0x12b8a60: b.ne            #0x12b8a70
    // 0x12b8a64: r2 = _kMiddleLeftTween
    //     0x12b8a64: add             x2, PP, #0x99, lsl #12  ; [pp+0x990a0] Field <::._kMiddleLeftTween@111053933>: static late final (offset: 0x750)
    //     0x12b8a68: ldr             x2, [x2, #0xa0]
    // 0x12b8a6c: r0 = InitLateFinalStaticField()
    //     0x12b8a6c: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x12b8a70: mov             x1, x0
    // 0x12b8a74: ldur            x2, [fp, #-0x20]
    // 0x12b8a78: r0 = animate()
    //     0x12b8a78: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x12b8a7c: ldur            x1, [fp, #-0x20]
    // 0x12b8a80: stur            x0, [fp, #-0x10]
    // 0x12b8a84: r0 = dispose()
    //     0x12b8a84: bl              #0xb29014  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::dispose
    // 0x12b8a88: ldur            x1, [fp, #-8]
    // 0x12b8a8c: r0 = of()
    //     0x12b8a8c: bl              #0x87371c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0x12b8a90: stur            x0, [fp, #-8]
    // 0x12b8a94: r0 = SlideTransition()
    //     0x12b8a94: bl              #0xb28364  ; AllocateSlideTransitionStub -> SlideTransition (size=0x1c)
    // 0x12b8a98: r1 = false
    //     0x12b8a98: add             x1, NULL, #0x30  ; false
    // 0x12b8a9c: StoreField: r0->field_13 = r1
    //     0x12b8a9c: stur            w1, [x0, #0x13]
    // 0x12b8aa0: ldur            x1, [fp, #-8]
    // 0x12b8aa4: StoreField: r0->field_f = r1
    //     0x12b8aa4: stur            w1, [x0, #0xf]
    // 0x12b8aa8: ldur            x1, [fp, #-0x18]
    // 0x12b8aac: ArrayStore: r0[0] = r1  ; List_4
    //     0x12b8aac: stur            w1, [x0, #0x17]
    // 0x12b8ab0: ldur            x1, [fp, #-0x10]
    // 0x12b8ab4: StoreField: r0->field_b = r1
    //     0x12b8ab4: stur            w1, [x0, #0xb]
    // 0x12b8ab8: LeaveFrame
    //     0x12b8ab8: mov             SP, fp
    //     0x12b8abc: ldp             fp, lr, [SP], #0x10
    // 0x12b8ac0: ret
    //     0x12b8ac0: ret             
    // 0x12b8ac4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12b8ac4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12b8ac8: b               #0x12b8a1c
  }
}
