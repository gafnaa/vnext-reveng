// lib: , url: package:flutter/src/cupertino/desktop_text_selection.dart

// class id: 1048775, size: 0x8
class :: {

  static late final TextSelectionControls cupertinoDesktopTextSelectionHandleControls; // offset: 0x9b8

  static TextSelectionControls cupertinoDesktopTextSelectionHandleControls() {
    // ** addr: 0xd4a6d4, size: 0x18
    // 0xd4a6d4: EnterFrame
    //     0xd4a6d4: stp             fp, lr, [SP, #-0x10]!
    //     0xd4a6d8: mov             fp, SP
    // 0xd4a6dc: r0 = _CupertinoDesktopTextSelectionHandleControls()
    //     0xd4a6dc: bl              #0xd4a6ec  ; Allocate_CupertinoDesktopTextSelectionHandleControlsStub -> _CupertinoDesktopTextSelectionHandleControls (size=0x8)
    // 0xd4a6e0: LeaveFrame
    //     0xd4a6e0: mov             SP, fp
    //     0xd4a6e4: ldp             fp, lr, [SP], #0x10
    // 0xd4a6e8: ret
    //     0xd4a6e8: ret             
  }
}

// class id: 3281, size: 0x8, field offset: 0x8
abstract class CupertinoDesktopTextSelectionControls extends TextSelectionControls {

  _ getHandleSize(/* No info */) {
    // ** addr: 0x12f57d8, size: 0x8
    // 0x12f57d8: r0 = Instance_Size
    //     0x12f57d8: ldr             x0, [PP, #0x7f28]  ; [pp+0x7f28] Obj!Size@12a74d1
    // 0x12f57dc: ret
    //     0x12f57dc: ret             
  }
  _ getHandleAnchor(/* No info */) {
    // ** addr: 0x12f57e0, size: 0x8
    // 0x12f57e0: r0 = Instance_Offset
    //     0x12f57e0: ldr             x0, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x12f57e4: ret
    //     0x12f57e4: ret             
  }
}

// class id: 3283, size: 0x8, field offset: 0x8
class _CupertinoDesktopTextSelectionHandleControls extends _MixinApplication391&CupertinoDesktopTextSelectionControls&TextSelectionHandleControls {
}
