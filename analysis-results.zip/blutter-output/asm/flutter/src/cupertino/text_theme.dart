// lib: , url: package:flutter/src/cupertino/text_theme.dart

// class id: 1048789, size: 0x8
class :: {
}

// class id: 3249, size: 0x10, field offset: 0x8
//   const constructor, 
class _TextThemeDefaultsBuilder extends Object {

  CupertinoDynamicColor field_8;
  CupertinoDynamicColor field_c;

  _ resolveFrom(/* No info */) {
    // ** addr: 0x121f110, size: 0xc4
    // 0x121f110: EnterFrame
    //     0x121f110: stp             fp, lr, [SP, #-0x10]!
    //     0x121f114: mov             fp, SP
    // 0x121f118: AllocStack(0x30)
    //     0x121f118: sub             SP, SP, #0x30
    // 0x121f11c: SetupParameters(_TextThemeDefaultsBuilder this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */)
    //     0x121f11c: mov             x3, x1
    //     0x121f120: mov             x0, x2
    //     0x121f124: stur            x1, [fp, #-0x10]
    //     0x121f128: stur            x2, [fp, #-0x18]
    // 0x121f12c: CheckStackOverflow
    //     0x121f12c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x121f130: cmp             SP, x16
    //     0x121f134: b.ls            #0x121f1cc
    // 0x121f138: LoadField: r4 = r3->field_7
    //     0x121f138: ldur            w4, [x3, #7]
    // 0x121f13c: DecompressPointer r4
    //     0x121f13c: add             x4, x4, HEAP, lsl #32
    // 0x121f140: mov             x1, x4
    // 0x121f144: mov             x2, x0
    // 0x121f148: stur            x4, [fp, #-8]
    // 0x121f14c: r0 = resolveFrom()
    //     0x121f14c: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0x121f150: mov             x3, x0
    // 0x121f154: ldur            x0, [fp, #-0x10]
    // 0x121f158: stur            x3, [fp, #-0x20]
    // 0x121f15c: LoadField: r1 = r0->field_b
    //     0x121f15c: ldur            w1, [x0, #0xb]
    // 0x121f160: DecompressPointer r1
    //     0x121f160: add             x1, x1, HEAP, lsl #32
    // 0x121f164: ldur            x2, [fp, #-0x18]
    // 0x121f168: r0 = resolveFrom()
    //     0x121f168: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0x121f16c: stur            x0, [fp, #-0x18]
    // 0x121f170: ldur            x16, [fp, #-0x20]
    // 0x121f174: ldur            lr, [fp, #-8]
    // 0x121f178: stp             lr, x16, [SP]
    // 0x121f17c: r0 = ==()
    //     0x121f17c: bl              #0x12629d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::==
    // 0x121f180: tbnz            w0, #4, #0x121f1a4
    // 0x121f184: ldur            x16, [fp, #-0x18]
    // 0x121f188: r30 = Instance_CupertinoDynamicColor
    //     0x121f188: add             lr, PP, #0x26, lsl #12  ; [pp+0x26b50] Obj!CupertinoDynamicColor@12b36f1
    //     0x121f18c: ldr             lr, [lr, #0xb50]
    // 0x121f190: stp             lr, x16, [SP]
    // 0x121f194: r0 = ==()
    //     0x121f194: bl              #0x12629d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::==
    // 0x121f198: tbnz            w0, #4, #0x121f1a4
    // 0x121f19c: ldur            x0, [fp, #-0x10]
    // 0x121f1a0: b               #0x121f1c0
    // 0x121f1a4: ldur            x1, [fp, #-0x20]
    // 0x121f1a8: ldur            x0, [fp, #-0x18]
    // 0x121f1ac: r0 = _TextThemeDefaultsBuilder()
    //     0x121f1ac: bl              #0x121f1d4  ; Allocate_TextThemeDefaultsBuilderStub -> _TextThemeDefaultsBuilder (size=0x10)
    // 0x121f1b0: ldur            x1, [fp, #-0x20]
    // 0x121f1b4: StoreField: r0->field_7 = r1
    //     0x121f1b4: stur            w1, [x0, #7]
    // 0x121f1b8: ldur            x1, [fp, #-0x18]
    // 0x121f1bc: StoreField: r0->field_b = r1
    //     0x121f1bc: stur            w1, [x0, #0xb]
    // 0x121f1c0: LeaveFrame
    //     0x121f1c0: mov             SP, fp
    //     0x121f1c4: ldp             fp, lr, [SP], #0x10
    // 0x121f1c8: ret
    //     0x121f1c8: ret             
    // 0x121f1cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x121f1cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x121f1d0: b               #0x121f138
  }
  _ ==(/* No info */) {
    // ** addr: 0x12951c0, size: 0x108
    // 0x12951c0: EnterFrame
    //     0x12951c0: stp             fp, lr, [SP, #-0x10]!
    //     0x12951c4: mov             fp, SP
    // 0x12951c8: AllocStack(0x10)
    //     0x12951c8: sub             SP, SP, #0x10
    // 0x12951cc: CheckStackOverflow
    //     0x12951cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12951d0: cmp             SP, x16
    //     0x12951d4: b.ls            #0x12952c0
    // 0x12951d8: ldr             x0, [fp, #0x10]
    // 0x12951dc: cmp             w0, NULL
    // 0x12951e0: b.ne            #0x12951f4
    // 0x12951e4: r0 = false
    //     0x12951e4: add             x0, NULL, #0x30  ; false
    // 0x12951e8: LeaveFrame
    //     0x12951e8: mov             SP, fp
    //     0x12951ec: ldp             fp, lr, [SP], #0x10
    // 0x12951f0: ret
    //     0x12951f0: ret             
    // 0x12951f4: ldr             x1, [fp, #0x18]
    // 0x12951f8: cmp             w1, w0
    // 0x12951fc: b.ne            #0x1295210
    // 0x1295200: r0 = true
    //     0x1295200: add             x0, NULL, #0x20  ; true
    // 0x1295204: LeaveFrame
    //     0x1295204: mov             SP, fp
    //     0x1295208: ldp             fp, lr, [SP], #0x10
    // 0x129520c: ret
    //     0x129520c: ret             
    // 0x1295210: str             x0, [SP]
    // 0x1295214: r0 = runtimeType()
    //     0x1295214: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x1295218: r1 = LoadClassIdInstr(r0)
    //     0x1295218: ldur            x1, [x0, #-1]
    //     0x129521c: ubfx            x1, x1, #0xc, #0x14
    // 0x1295220: r16 = _TextThemeDefaultsBuilder
    //     0x1295220: add             x16, PP, #0x84, lsl #12  ; [pp+0x84920] Type: _TextThemeDefaultsBuilder
    //     0x1295224: ldr             x16, [x16, #0x920]
    // 0x1295228: stp             x16, x0, [SP]
    // 0x129522c: mov             x0, x1
    // 0x1295230: mov             lr, x0
    // 0x1295234: ldr             lr, [x21, lr, lsl #3]
    // 0x1295238: blr             lr
    // 0x129523c: tbz             w0, #4, #0x1295250
    // 0x1295240: r0 = false
    //     0x1295240: add             x0, NULL, #0x30  ; false
    // 0x1295244: LeaveFrame
    //     0x1295244: mov             SP, fp
    //     0x1295248: ldp             fp, lr, [SP], #0x10
    // 0x129524c: ret
    //     0x129524c: ret             
    // 0x1295250: ldr             x0, [fp, #0x10]
    // 0x1295254: r1 = 60
    //     0x1295254: mov             x1, #0x3c
    // 0x1295258: branchIfSmi(r0, 0x1295264)
    //     0x1295258: tbz             w0, #0, #0x1295264
    // 0x129525c: r1 = LoadClassIdInstr(r0)
    //     0x129525c: ldur            x1, [x0, #-1]
    //     0x1295260: ubfx            x1, x1, #0xc, #0x14
    // 0x1295264: cmp             x1, #0xcb1
    // 0x1295268: b.ne            #0x12952b0
    // 0x129526c: ldr             x1, [fp, #0x18]
    // 0x1295270: LoadField: r2 = r0->field_7
    //     0x1295270: ldur            w2, [x0, #7]
    // 0x1295274: DecompressPointer r2
    //     0x1295274: add             x2, x2, HEAP, lsl #32
    // 0x1295278: LoadField: r3 = r1->field_7
    //     0x1295278: ldur            w3, [x1, #7]
    // 0x129527c: DecompressPointer r3
    //     0x129527c: add             x3, x3, HEAP, lsl #32
    // 0x1295280: stp             x3, x2, [SP]
    // 0x1295284: r0 = ==()
    //     0x1295284: bl              #0x12629d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::==
    // 0x1295288: tbnz            w0, #4, #0x12952b0
    // 0x129528c: ldr             x1, [fp, #0x18]
    // 0x1295290: ldr             x0, [fp, #0x10]
    // 0x1295294: LoadField: r2 = r0->field_b
    //     0x1295294: ldur            w2, [x0, #0xb]
    // 0x1295298: DecompressPointer r2
    //     0x1295298: add             x2, x2, HEAP, lsl #32
    // 0x129529c: LoadField: r0 = r1->field_b
    //     0x129529c: ldur            w0, [x1, #0xb]
    // 0x12952a0: DecompressPointer r0
    //     0x12952a0: add             x0, x0, HEAP, lsl #32
    // 0x12952a4: stp             x0, x2, [SP]
    // 0x12952a8: r0 = ==()
    //     0x12952a8: bl              #0x12629d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::==
    // 0x12952ac: b               #0x12952b4
    // 0x12952b0: r0 = false
    //     0x12952b0: add             x0, NULL, #0x30  ; false
    // 0x12952b4: LeaveFrame
    //     0x12952b4: mov             SP, fp
    //     0x12952b8: ldp             fp, lr, [SP], #0x10
    // 0x12952bc: ret
    //     0x12952bc: ret             
    // 0x12952c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12952c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12952c4: b               #0x12951d8
  }
}

// class id: 5234, size: 0x34, field offset: 0x8
//   const constructor, 
class CupertinoTextThemeData extends _MixinApplication3&Object&Diagnosticable {

  get _ actionTextStyle(/* No info */) {
    // ** addr: 0xd74e58, size: 0x4c
    // 0xd74e58: EnterFrame
    //     0xd74e58: stp             fp, lr, [SP, #-0x10]!
    //     0xd74e5c: mov             fp, SP
    // 0xd74e60: AllocStack(0x8)
    //     0xd74e60: sub             SP, SP, #8
    // 0xd74e64: CheckStackOverflow
    //     0xd74e64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd74e68: cmp             SP, x16
    //     0xd74e6c: b.ls            #0xd74e9c
    // 0xd74e70: LoadField: r0 = r1->field_b
    //     0xd74e70: ldur            w0, [x1, #0xb]
    // 0xd74e74: DecompressPointer r0
    //     0xd74e74: add             x0, x0, HEAP, lsl #32
    // 0xd74e78: str             x0, [SP]
    // 0xd74e7c: r1 = Instance_TextStyle
    //     0xd74e7c: add             x1, PP, #0xac, lsl #12  ; [pp+0xacd00] Obj!TextStyle@12b0a81
    //     0xd74e80: ldr             x1, [x1, #0xd00]
    // 0xd74e84: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0xd74e84: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0xd74e88: ldr             x4, [x4, #0x7f0]
    // 0xd74e8c: r0 = copyWith()
    //     0xd74e8c: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xd74e90: LeaveFrame
    //     0xd74e90: mov             SP, fp
    //     0xd74e94: ldp             fp, lr, [SP], #0x10
    // 0xd74e98: ret
    //     0xd74e98: ret             
    // 0xd74e9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd74e9c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd74ea0: b               #0xd74e70
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x112e5d8, size: 0x78
    // 0x112e5d8: EnterFrame
    //     0x112e5d8: stp             fp, lr, [SP, #-0x10]!
    //     0x112e5dc: mov             fp, SP
    // 0x112e5e0: AllocStack(0x48)
    //     0x112e5e0: sub             SP, SP, #0x48
    // 0x112e5e4: CheckStackOverflow
    //     0x112e5e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x112e5e8: cmp             SP, x16
    //     0x112e5ec: b.ls            #0x112e648
    // 0x112e5f0: ldr             x0, [fp, #0x10]
    // 0x112e5f4: LoadField: r1 = r0->field_7
    //     0x112e5f4: ldur            w1, [x0, #7]
    // 0x112e5f8: DecompressPointer r1
    //     0x112e5f8: add             x1, x1, HEAP, lsl #32
    // 0x112e5fc: LoadField: r2 = r0->field_b
    //     0x112e5fc: ldur            w2, [x0, #0xb]
    // 0x112e600: DecompressPointer r2
    //     0x112e600: add             x2, x2, HEAP, lsl #32
    // 0x112e604: stp             NULL, NULL, [SP, #0x38]
    // 0x112e608: stp             NULL, NULL, [SP, #0x28]
    // 0x112e60c: stp             NULL, NULL, [SP, #0x18]
    // 0x112e610: stp             NULL, NULL, [SP, #8]
    // 0x112e614: str             NULL, [SP]
    // 0x112e618: r4 = const [0, 0xb, 0x9, 0xb, null]
    //     0x112e618: add             x4, PP, #0x26, lsl #12  ; [pp+0x26280] List(5) [0, 0xb, 0x9, 0xb, Null]
    //     0x112e61c: ldr             x4, [x4, #0x280]
    // 0x112e620: r0 = hash()
    //     0x112e620: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x112e624: mov             x2, x0
    // 0x112e628: r0 = BoxInt64Instr(r2)
    //     0x112e628: sbfiz           x0, x2, #1, #0x1f
    //     0x112e62c: cmp             x2, x0, asr #1
    //     0x112e630: b.eq            #0x112e63c
    //     0x112e634: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x112e638: stur            x2, [x0, #7]
    // 0x112e63c: LeaveFrame
    //     0x112e63c: mov             SP, fp
    //     0x112e640: ldp             fp, lr, [SP], #0x10
    // 0x112e644: ret
    //     0x112e644: ret             
    // 0x112e648: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x112e648: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x112e64c: b               #0x112e5f0
  }
  _ resolveFrom(/* No info */) {
    // ** addr: 0x121f084, size: 0x80
    // 0x121f084: EnterFrame
    //     0x121f084: stp             fp, lr, [SP, #-0x10]!
    //     0x121f088: mov             fp, SP
    // 0x121f08c: AllocStack(0x18)
    //     0x121f08c: sub             SP, SP, #0x18
    // 0x121f090: SetupParameters(CupertinoTextThemeData this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x121f090: mov             x3, x1
    //     0x121f094: mov             x0, x2
    //     0x121f098: stur            x1, [fp, #-8]
    //     0x121f09c: stur            x2, [fp, #-0x10]
    // 0x121f0a0: CheckStackOverflow
    //     0x121f0a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x121f0a4: cmp             SP, x16
    //     0x121f0a8: b.ls            #0x121f0fc
    // 0x121f0ac: LoadField: r1 = r3->field_7
    //     0x121f0ac: ldur            w1, [x3, #7]
    // 0x121f0b0: DecompressPointer r1
    //     0x121f0b0: add             x1, x1, HEAP, lsl #32
    // 0x121f0b4: mov             x2, x0
    // 0x121f0b8: r0 = resolveFrom()
    //     0x121f0b8: bl              #0x121f110  ; [package:flutter/src/cupertino/text_theme.dart] _TextThemeDefaultsBuilder::resolveFrom
    // 0x121f0bc: mov             x3, x0
    // 0x121f0c0: ldur            x0, [fp, #-8]
    // 0x121f0c4: stur            x3, [fp, #-0x18]
    // 0x121f0c8: LoadField: r1 = r0->field_b
    //     0x121f0c8: ldur            w1, [x0, #0xb]
    // 0x121f0cc: DecompressPointer r1
    //     0x121f0cc: add             x1, x1, HEAP, lsl #32
    // 0x121f0d0: ldur            x2, [fp, #-0x10]
    // 0x121f0d4: r0 = resolve()
    //     0x121f0d4: bl              #0xce150c  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolve
    // 0x121f0d8: stur            x0, [fp, #-8]
    // 0x121f0dc: r0 = CupertinoTextThemeData()
    //     0x121f0dc: bl              #0x121f104  ; AllocateCupertinoTextThemeDataStub -> CupertinoTextThemeData (size=0x34)
    // 0x121f0e0: ldur            x1, [fp, #-0x18]
    // 0x121f0e4: StoreField: r0->field_7 = r1
    //     0x121f0e4: stur            w1, [x0, #7]
    // 0x121f0e8: ldur            x1, [fp, #-8]
    // 0x121f0ec: StoreField: r0->field_b = r1
    //     0x121f0ec: stur            w1, [x0, #0xb]
    // 0x121f0f0: LeaveFrame
    //     0x121f0f0: mov             SP, fp
    //     0x121f0f4: ldp             fp, lr, [SP], #0x10
    // 0x121f0f8: ret
    //     0x121f0f8: ret             
    // 0x121f0fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x121f0fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x121f100: b               #0x121f0ac
  }
  _ ==(/* No info */) {
    // ** addr: 0x1263144, size: 0x108
    // 0x1263144: EnterFrame
    //     0x1263144: stp             fp, lr, [SP, #-0x10]!
    //     0x1263148: mov             fp, SP
    // 0x126314c: AllocStack(0x10)
    //     0x126314c: sub             SP, SP, #0x10
    // 0x1263150: CheckStackOverflow
    //     0x1263150: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1263154: cmp             SP, x16
    //     0x1263158: b.ls            #0x1263244
    // 0x126315c: ldr             x0, [fp, #0x10]
    // 0x1263160: cmp             w0, NULL
    // 0x1263164: b.ne            #0x1263178
    // 0x1263168: r0 = false
    //     0x1263168: add             x0, NULL, #0x30  ; false
    // 0x126316c: LeaveFrame
    //     0x126316c: mov             SP, fp
    //     0x1263170: ldp             fp, lr, [SP], #0x10
    // 0x1263174: ret
    //     0x1263174: ret             
    // 0x1263178: ldr             x1, [fp, #0x18]
    // 0x126317c: cmp             w1, w0
    // 0x1263180: b.ne            #0x1263194
    // 0x1263184: r0 = true
    //     0x1263184: add             x0, NULL, #0x20  ; true
    // 0x1263188: LeaveFrame
    //     0x1263188: mov             SP, fp
    //     0x126318c: ldp             fp, lr, [SP], #0x10
    // 0x1263190: ret
    //     0x1263190: ret             
    // 0x1263194: stp             x1, x0, [SP]
    // 0x1263198: r0 = _haveSameRuntimeType()
    //     0x1263198: bl              #0x88249c  ; [dart:core] Object::_haveSameRuntimeType
    // 0x126319c: tbz             w0, #4, #0x12631b0
    // 0x12631a0: r0 = false
    //     0x12631a0: add             x0, NULL, #0x30  ; false
    // 0x12631a4: LeaveFrame
    //     0x12631a4: mov             SP, fp
    //     0x12631a8: ldp             fp, lr, [SP], #0x10
    // 0x12631ac: ret
    //     0x12631ac: ret             
    // 0x12631b0: ldr             x0, [fp, #0x10]
    // 0x12631b4: r1 = 60
    //     0x12631b4: mov             x1, #0x3c
    // 0x12631b8: branchIfSmi(r0, 0x12631c4)
    //     0x12631b8: tbz             w0, #0, #0x12631c4
    // 0x12631bc: r1 = LoadClassIdInstr(r0)
    //     0x12631bc: ldur            x1, [x0, #-1]
    //     0x12631c0: ubfx            x1, x1, #0xc, #0x14
    // 0x12631c4: r17 = -5234
    //     0x12631c4: mov             x17, #-0x1472
    // 0x12631c8: add             x16, x1, x17
    // 0x12631cc: cmp             x16, #1
    // 0x12631d0: b.hi            #0x1263234
    // 0x12631d4: ldr             x1, [fp, #0x18]
    // 0x12631d8: LoadField: r2 = r0->field_7
    //     0x12631d8: ldur            w2, [x0, #7]
    // 0x12631dc: DecompressPointer r2
    //     0x12631dc: add             x2, x2, HEAP, lsl #32
    // 0x12631e0: LoadField: r3 = r1->field_7
    //     0x12631e0: ldur            w3, [x1, #7]
    // 0x12631e4: DecompressPointer r3
    //     0x12631e4: add             x3, x3, HEAP, lsl #32
    // 0x12631e8: stp             x3, x2, [SP]
    // 0x12631ec: r0 = ==()
    //     0x12631ec: bl              #0x12951c0  ; [package:flutter/src/cupertino/text_theme.dart] _TextThemeDefaultsBuilder::==
    // 0x12631f0: tbnz            w0, #4, #0x1263234
    // 0x12631f4: ldr             x1, [fp, #0x18]
    // 0x12631f8: ldr             x0, [fp, #0x10]
    // 0x12631fc: LoadField: r2 = r0->field_b
    //     0x12631fc: ldur            w2, [x0, #0xb]
    // 0x1263200: DecompressPointer r2
    //     0x1263200: add             x2, x2, HEAP, lsl #32
    // 0x1263204: LoadField: r0 = r1->field_b
    //     0x1263204: ldur            w0, [x1, #0xb]
    // 0x1263208: DecompressPointer r0
    //     0x1263208: add             x0, x0, HEAP, lsl #32
    // 0x126320c: r1 = LoadClassIdInstr(r2)
    //     0x126320c: ldur            x1, [x2, #-1]
    //     0x1263210: ubfx            x1, x1, #0xc, #0x14
    // 0x1263214: stp             x0, x2, [SP]
    // 0x1263218: mov             x0, x1
    // 0x126321c: mov             lr, x0
    // 0x1263220: ldr             lr, [x21, lr, lsl #3]
    // 0x1263224: blr             lr
    // 0x1263228: tbnz            w0, #4, #0x1263234
    // 0x126322c: r0 = true
    //     0x126322c: add             x0, NULL, #0x20  ; true
    // 0x1263230: b               #0x1263238
    // 0x1263234: r0 = false
    //     0x1263234: add             x0, NULL, #0x30  ; false
    // 0x1263238: LeaveFrame
    //     0x1263238: mov             SP, fp
    //     0x126323c: ldp             fp, lr, [SP], #0x10
    // 0x1263240: ret
    //     0x1263240: ret             
    // 0x1263244: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1263244: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1263248: b               #0x126315c
  }
}
