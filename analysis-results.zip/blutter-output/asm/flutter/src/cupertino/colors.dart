// lib: , url: package:flutter/src/cupertino/colors.dart

// class id: 1048773, size: 0x8
class :: {
}

// class id: 5241, size: 0x34, field offset: 0x8
//   const constructor, 
class CupertinoDynamicColor extends _MixinApplication3&Object&Diagnosticable
    implements Color {

  Color field_8;
  Color field_14;
  Color field_18;
  Color field_1c;
  Color field_20;
  Color field_24;
  Color field_28;
  Color field_2c;
  Color field_30;
  _OneByteString field_c;

  int dyn:get:value(CupertinoDynamicColor) {
    // ** addr: 0xccc418, size: 0x78
    // 0xccc418: EnterFrame
    //     0xccc418: stp             fp, lr, [SP, #-0x10]!
    //     0xccc41c: mov             fp, SP
    // 0xccc420: CheckStackOverflow
    //     0xccc420: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xccc424: cmp             SP, x16
    //     0xccc428: b.ls            #0xccc470
    // 0xccc42c: ldr             x0, [fp, #0x10]
    // 0xccc430: LoadField: r1 = r0->field_7
    //     0xccc430: ldur            w1, [x0, #7]
    // 0xccc434: DecompressPointer r1
    //     0xccc434: add             x1, x1, HEAP, lsl #32
    // 0xccc438: r0 = LoadClassIdInstr(r1)
    //     0xccc438: ldur            x0, [x1, #-1]
    //     0xccc43c: ubfx            x0, x0, #0xc, #0x14
    // 0xccc440: r0 = GDT[cid_x0 + -0xfb8]()
    //     0xccc440: sub             lr, x0, #0xfb8
    //     0xccc444: ldr             lr, [x21, lr, lsl #3]
    //     0xccc448: blr             lr
    // 0xccc44c: mov             x2, x0
    // 0xccc450: r0 = BoxInt64Instr(r2)
    //     0xccc450: sbfiz           x0, x2, #1, #0x1f
    //     0xccc454: cmp             x2, x0, asr #1
    //     0xccc458: b.eq            #0xccc464
    //     0xccc45c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xccc460: stur            x2, [x0, #7]
    // 0xccc464: LeaveFrame
    //     0xccc464: mov             SP, fp
    //     0xccc468: ldp             fp, lr, [SP], #0x10
    // 0xccc46c: ret
    //     0xccc46c: ret             
    // 0xccc470: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xccc470: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xccc474: b               #0xccc42c
  }
  static _ resolve(/* No info */) {
    // ** addr: 0xce150c, size: 0x48
    // 0xce150c: EnterFrame
    //     0xce150c: stp             fp, lr, [SP, #-0x10]!
    //     0xce1510: mov             fp, SP
    // 0xce1514: CheckStackOverflow
    //     0xce1514: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce1518: cmp             SP, x16
    //     0xce151c: b.ls            #0xce154c
    // 0xce1520: r0 = LoadClassIdInstr(r1)
    //     0xce1520: ldur            x0, [x1, #-1]
    //     0xce1524: ubfx            x0, x0, #0xc, #0x14
    // 0xce1528: r17 = 5241
    //     0xce1528: mov             x17, #0x1479
    // 0xce152c: cmp             x0, x17
    // 0xce1530: b.ne            #0xce153c
    // 0xce1534: r0 = resolveFrom()
    //     0xce1534: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0xce1538: b               #0xce1540
    // 0xce153c: mov             x0, x1
    // 0xce1540: LeaveFrame
    //     0xce1540: mov             SP, fp
    //     0xce1544: ldp             fp, lr, [SP], #0x10
    // 0xce1548: ret
    //     0xce1548: ret             
    // 0xce154c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce154c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce1550: b               #0xce1520
  }
  _ resolveFrom(/* No info */) {
    // ** addr: 0xce16d0, size: 0x970
    // 0xce16d0: EnterFrame
    //     0xce16d0: stp             fp, lr, [SP, #-0x10]!
    //     0xce16d4: mov             fp, SP
    // 0xce16d8: AllocStack(0x58)
    //     0xce16d8: sub             SP, SP, #0x58
    // 0xce16dc: SetupParameters(CupertinoDynamicColor this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xce16dc: mov             x0, x2
    //     0xce16e0: stur            x2, [fp, #-0x10]
    //     0xce16e4: mov             x2, x1
    //     0xce16e8: stur            x1, [fp, #-8]
    // 0xce16ec: CheckStackOverflow
    //     0xce16ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce16f0: cmp             SP, x16
    //     0xce16f4: b.ls            #0xce2038
    // 0xce16f8: mov             x1, x2
    // 0xce16fc: r0 = _isPlatformBrightnessDependent()
    //     0xce16fc: bl              #0xce23ac  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::_isPlatformBrightnessDependent
    // 0xce1700: tbnz            w0, #4, #0xce171c
    // 0xce1704: ldur            x1, [fp, #-0x10]
    // 0xce1708: r0 = maybeBrightnessOf()
    //     0xce1708: bl              #0xce22c0  ; [package:flutter/src/cupertino/theme.dart] CupertinoTheme::maybeBrightnessOf
    // 0xce170c: cmp             w0, NULL
    // 0xce1710: b.ne            #0xce1720
    // 0xce1714: r0 = Instance_Brightness
    //     0xce1714: ldr             x0, [PP, #0x6da0]  ; [pp+0x6da0] Obj!Brightness@12c71c1
    // 0xce1718: b               #0xce1720
    // 0xce171c: r0 = Instance_Brightness
    //     0xce171c: ldr             x0, [PP, #0x6da0]  ; [pp+0x6da0] Obj!Brightness@12c71c1
    // 0xce1720: ldur            x1, [fp, #-8]
    // 0xce1724: stur            x0, [fp, #-0x18]
    // 0xce1728: r0 = _isInterfaceElevationDependent()
    //     0xce1728: bl              #0xce21e0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::_isInterfaceElevationDependent
    // 0xce172c: tbnz            w0, #4, #0xce174c
    // 0xce1730: ldur            x1, [fp, #-0x10]
    // 0xce1734: r0 = maybeOf()
    //     0xce1734: bl              #0xce2188  ; [package:flutter/src/cupertino/interface_level.dart] CupertinoUserInterfaceLevel::maybeOf
    // 0xce1738: cmp             w0, NULL
    // 0xce173c: b.ne            #0xce1754
    // 0xce1740: r0 = Instance_CupertinoUserInterfaceLevelData
    //     0xce1740: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e888] Obj!CupertinoUserInterfaceLevelData@12c6001
    //     0xce1744: ldr             x0, [x0, #0x888]
    // 0xce1748: b               #0xce1754
    // 0xce174c: r0 = Instance_CupertinoUserInterfaceLevelData
    //     0xce174c: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e888] Obj!CupertinoUserInterfaceLevelData@12c6001
    //     0xce1750: ldr             x0, [x0, #0x888]
    // 0xce1754: ldur            x1, [fp, #-8]
    // 0xce1758: stur            x0, [fp, #-0x20]
    // 0xce175c: r0 = _isHighContrastDependent()
    //     0xce175c: bl              #0xce20a8  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::_isHighContrastDependent
    // 0xce1760: tbnz            w0, #4, #0xce1780
    // 0xce1764: ldur            x1, [fp, #-0x10]
    // 0xce1768: r0 = maybeHighContrastOf()
    //     0xce1768: bl              #0xce204c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::maybeHighContrastOf
    // 0xce176c: cmp             w0, NULL
    // 0xce1770: b.ne            #0xce1778
    // 0xce1774: r0 = false
    //     0xce1774: add             x0, NULL, #0x30  ; false
    // 0xce1778: mov             x1, x0
    // 0xce177c: b               #0xce1784
    // 0xce1780: r1 = false
    //     0xce1780: add             x1, NULL, #0x30  ; false
    // 0xce1784: ldur            x0, [fp, #-0x18]
    // 0xce1788: r16 = Instance_Brightness
    //     0xce1788: ldr             x16, [PP, #0x6da0]  ; [pp+0x6da0] Obj!Brightness@12c71c1
    // 0xce178c: cmp             w0, w16
    // 0xce1790: r16 = true
    //     0xce1790: add             x16, NULL, #0x20  ; true
    // 0xce1794: r17 = false
    //     0xce1794: add             x17, NULL, #0x30  ; false
    // 0xce1798: csel            x2, x16, x17, eq
    // 0xce179c: tbnz            w2, #4, #0xce1834
    // 0xce17a0: ldur            x3, [fp, #-0x20]
    // 0xce17a4: r16 = Instance_CupertinoUserInterfaceLevelData
    //     0xce17a4: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e888] Obj!CupertinoUserInterfaceLevelData@12c6001
    //     0xce17a8: ldr             x16, [x16, #0x888]
    // 0xce17ac: cmp             w3, w16
    // 0xce17b0: r16 = true
    //     0xce17b0: add             x16, NULL, #0x20  ; true
    // 0xce17b4: r17 = false
    //     0xce17b4: add             x17, NULL, #0x30  ; false
    // 0xce17b8: csel            x4, x16, x17, eq
    // 0xce17bc: tbnz            w4, #4, #0xce180c
    // 0xce17c0: tbnz            w1, #4, #0xce17cc
    // 0xce17c4: r5 = false
    //     0xce17c4: add             x5, NULL, #0x30  ; false
    // 0xce17c8: b               #0xce17d0
    // 0xce17cc: r5 = true
    //     0xce17cc: add             x5, NULL, #0x20  ; true
    // 0xce17d0: tbnz            w5, #4, #0xce17e4
    // 0xce17d4: ldur            x6, [fp, #-8]
    // 0xce17d8: LoadField: r0 = r6->field_13
    //     0xce17d8: ldur            w0, [x6, #0x13]
    // 0xce17dc: DecompressPointer r0
    //     0xce17dc: add             x0, x0, HEAP, lsl #32
    // 0xce17e0: b               #0xce1f68
    // 0xce17e4: ldur            x6, [fp, #-8]
    // 0xce17e8: mov             x12, x4
    // 0xce17ec: mov             x10, x3
    // 0xce17f0: mov             x8, x5
    // 0xce17f4: mov             x5, x1
    // 0xce17f8: r11 = true
    //     0xce17f8: add             x11, NULL, #0x20  ; true
    // 0xce17fc: r9 = true
    //     0xce17fc: add             x9, NULL, #0x20  ; true
    // 0xce1800: r7 = true
    //     0xce1800: add             x7, NULL, #0x20  ; true
    // 0xce1804: r4 = true
    //     0xce1804: add             x4, NULL, #0x20  ; true
    // 0xce1808: b               #0xce185c
    // 0xce180c: ldur            x6, [fp, #-8]
    // 0xce1810: mov             x12, x4
    // 0xce1814: mov             x10, x3
    // 0xce1818: r11 = true
    //     0xce1818: add             x11, NULL, #0x20  ; true
    // 0xce181c: r9 = true
    //     0xce181c: add             x9, NULL, #0x20  ; true
    // 0xce1820: r8 = Null
    //     0xce1820: mov             x8, NULL
    // 0xce1824: r7 = false
    //     0xce1824: add             x7, NULL, #0x30  ; false
    // 0xce1828: r5 = Null
    //     0xce1828: mov             x5, NULL
    // 0xce182c: r4 = false
    //     0xce182c: add             x4, NULL, #0x30  ; false
    // 0xce1830: b               #0xce185c
    // 0xce1834: ldur            x6, [fp, #-8]
    // 0xce1838: ldur            x3, [fp, #-0x20]
    // 0xce183c: r12 = Null
    //     0xce183c: mov             x12, NULL
    // 0xce1840: r11 = false
    //     0xce1840: add             x11, NULL, #0x30  ; false
    // 0xce1844: r10 = Null
    //     0xce1844: mov             x10, NULL
    // 0xce1848: r9 = false
    //     0xce1848: add             x9, NULL, #0x30  ; false
    // 0xce184c: r8 = Null
    //     0xce184c: mov             x8, NULL
    // 0xce1850: r7 = false
    //     0xce1850: add             x7, NULL, #0x30  ; false
    // 0xce1854: r5 = Null
    //     0xce1854: mov             x5, NULL
    // 0xce1858: r4 = false
    //     0xce1858: add             x4, NULL, #0x30  ; false
    // 0xce185c: tbnz            w2, #4, #0xce1938
    // 0xce1860: tbnz            w11, #4, #0xce1878
    // 0xce1864: mov             x11, x12
    // 0xce1868: mov             x16, x10
    // 0xce186c: mov             x10, x9
    // 0xce1870: mov             x9, x16
    // 0xce1874: b               #0xce18ac
    // 0xce1878: tbnz            w9, #4, #0xce1884
    // 0xce187c: mov             x9, x10
    // 0xce1880: b               #0xce188c
    // 0xce1884: mov             x10, x3
    // 0xce1888: mov             x9, x3
    // 0xce188c: r16 = Instance_CupertinoUserInterfaceLevelData
    //     0xce188c: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e888] Obj!CupertinoUserInterfaceLevelData@12c6001
    //     0xce1890: ldr             x16, [x16, #0x888]
    // 0xce1894: cmp             w10, w16
    // 0xce1898: r16 = true
    //     0xce1898: add             x16, NULL, #0x20  ; true
    // 0xce189c: r17 = false
    //     0xce189c: add             x17, NULL, #0x30  ; false
    // 0xce18a0: csel            x11, x16, x17, eq
    // 0xce18a4: mov             x12, x11
    // 0xce18a8: r10 = true
    //     0xce18a8: add             x10, NULL, #0x20  ; true
    // 0xce18ac: r16 = true
    //     0xce18ac: add             x16, NULL, #0x20  ; true
    // 0xce18b0: cmp             w12, w16
    // 0xce18b4: b.ne            #0xce1914
    // 0xce18b8: tbnz            w4, #4, #0xce18c4
    // 0xce18bc: mov             x4, x5
    // 0xce18c0: b               #0xce18cc
    // 0xce18c4: mov             x5, x1
    // 0xce18c8: mov             x4, x1
    // 0xce18cc: r16 = true
    //     0xce18cc: add             x16, NULL, #0x20  ; true
    // 0xce18d0: cmp             w5, w16
    // 0xce18d4: r16 = true
    //     0xce18d4: add             x16, NULL, #0x20  ; true
    // 0xce18d8: r17 = false
    //     0xce18d8: add             x17, NULL, #0x30  ; false
    // 0xce18dc: csel            x12, x16, x17, eq
    // 0xce18e0: tbnz            w12, #4, #0xce18f0
    // 0xce18e4: LoadField: r0 = r6->field_1b
    //     0xce18e4: ldur            w0, [x6, #0x1b]
    // 0xce18e8: DecompressPointer r0
    //     0xce18e8: add             x0, x0, HEAP, lsl #32
    // 0xce18ec: b               #0xce1f68
    // 0xce18f0: mov             x14, x11
    // 0xce18f4: mov             x5, x12
    // 0xce18f8: mov             x12, x9
    // 0xce18fc: mov             x11, x10
    // 0xce1900: mov             x10, x4
    // 0xce1904: r13 = true
    //     0xce1904: add             x13, NULL, #0x20  ; true
    // 0xce1908: r9 = true
    //     0xce1908: add             x9, NULL, #0x20  ; true
    // 0xce190c: r4 = true
    //     0xce190c: add             x4, NULL, #0x20  ; true
    // 0xce1910: b               #0xce1958
    // 0xce1914: mov             x14, x11
    // 0xce1918: mov             x12, x9
    // 0xce191c: mov             x11, x10
    // 0xce1920: mov             x10, x5
    // 0xce1924: mov             x9, x4
    // 0xce1928: r13 = true
    //     0xce1928: add             x13, NULL, #0x20  ; true
    // 0xce192c: r5 = Null
    //     0xce192c: mov             x5, NULL
    // 0xce1930: r4 = false
    //     0xce1930: add             x4, NULL, #0x30  ; false
    // 0xce1934: b               #0xce1958
    // 0xce1938: mov             x14, x12
    // 0xce193c: mov             x13, x11
    // 0xce1940: mov             x12, x10
    // 0xce1944: mov             x11, x9
    // 0xce1948: mov             x10, x5
    // 0xce194c: mov             x9, x4
    // 0xce1950: r5 = Null
    //     0xce1950: mov             x5, NULL
    // 0xce1954: r4 = false
    //     0xce1954: add             x4, NULL, #0x30  ; false
    // 0xce1958: tbnz            w2, #4, #0xce1a34
    // 0xce195c: tbnz            w11, #4, #0xce1968
    // 0xce1960: mov             x11, x12
    // 0xce1964: b               #0xce1970
    // 0xce1968: mov             x12, x3
    // 0xce196c: mov             x11, x3
    // 0xce1970: r16 = Instance_CupertinoUserInterfaceLevelData
    //     0xce1970: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e890] Obj!CupertinoUserInterfaceLevelData@12c5fe1
    //     0xce1974: ldr             x16, [x16, #0x890]
    // 0xce1978: cmp             w12, w16
    // 0xce197c: r16 = true
    //     0xce197c: add             x16, NULL, #0x20  ; true
    // 0xce1980: r17 = false
    //     0xce1980: add             x17, NULL, #0x30  ; false
    // 0xce1984: csel            x19, x16, x17, eq
    // 0xce1988: tbnz            w19, #4, #0xce1a18
    // 0xce198c: tbnz            w7, #4, #0xce19a8
    // 0xce1990: mov             x7, x10
    // 0xce1994: mov             x10, x8
    // 0xce1998: mov             x16, x9
    // 0xce199c: mov             x9, x8
    // 0xce19a0: mov             x8, x16
    // 0xce19a4: b               #0xce19dc
    // 0xce19a8: tbnz            w9, #4, #0xce19b8
    // 0xce19ac: mov             x8, x10
    // 0xce19b0: mov             x7, x10
    // 0xce19b4: b               #0xce19c0
    // 0xce19b8: mov             x8, x1
    // 0xce19bc: mov             x7, x1
    // 0xce19c0: r16 = false
    //     0xce19c0: add             x16, NULL, #0x30  ; false
    // 0xce19c4: cmp             w8, w16
    // 0xce19c8: r16 = true
    //     0xce19c8: add             x16, NULL, #0x20  ; true
    // 0xce19cc: r17 = false
    //     0xce19cc: add             x17, NULL, #0x30  ; false
    // 0xce19d0: csel            x9, x16, x17, eq
    // 0xce19d4: mov             x10, x9
    // 0xce19d8: r8 = true
    //     0xce19d8: add             x8, NULL, #0x20  ; true
    // 0xce19dc: r16 = true
    //     0xce19dc: add             x16, NULL, #0x20  ; true
    // 0xce19e0: cmp             w10, w16
    // 0xce19e4: b.ne            #0xce19f4
    // 0xce19e8: LoadField: r0 = r6->field_23
    //     0xce19e8: ldur            w0, [x6, #0x23]
    // 0xce19ec: DecompressPointer r0
    //     0xce19ec: add             x0, x0, HEAP, lsl #32
    // 0xce19f0: b               #0xce1f68
    // 0xce19f4: mov             x20, x11
    // 0xce19f8: mov             x12, x9
    // 0xce19fc: mov             x10, x7
    // 0xce1a00: mov             x9, x8
    // 0xce1a04: mov             x8, x19
    // 0xce1a08: r19 = true
    //     0xce1a08: add             x19, NULL, #0x20  ; true
    // 0xce1a0c: r11 = true
    //     0xce1a0c: add             x11, NULL, #0x20  ; true
    // 0xce1a10: r7 = true
    //     0xce1a10: add             x7, NULL, #0x20  ; true
    // 0xce1a14: b               #0xce1a4c
    // 0xce1a18: mov             x20, x11
    // 0xce1a1c: mov             x12, x8
    // 0xce1a20: mov             x11, x7
    // 0xce1a24: mov             x8, x19
    // 0xce1a28: r19 = true
    //     0xce1a28: add             x19, NULL, #0x20  ; true
    // 0xce1a2c: r7 = true
    //     0xce1a2c: add             x7, NULL, #0x20  ; true
    // 0xce1a30: b               #0xce1a4c
    // 0xce1a34: mov             x20, x12
    // 0xce1a38: mov             x19, x11
    // 0xce1a3c: mov             x12, x8
    // 0xce1a40: mov             x11, x7
    // 0xce1a44: r8 = Null
    //     0xce1a44: mov             x8, NULL
    // 0xce1a48: r7 = false
    //     0xce1a48: add             x7, NULL, #0x30  ; false
    // 0xce1a4c: tbnz            w2, #4, #0xce1b78
    // 0xce1a50: tbnz            w7, #4, #0xce1a68
    // 0xce1a54: mov             x7, x19
    // 0xce1a58: mov             x19, x8
    // 0xce1a5c: mov             x2, x8
    // 0xce1a60: mov             x8, x20
    // 0xce1a64: b               #0xce1aac
    // 0xce1a68: tbnz            w19, #4, #0xce1a78
    // 0xce1a6c: mov             x7, x20
    // 0xce1a70: mov             x2, x20
    // 0xce1a74: b               #0xce1a80
    // 0xce1a78: mov             x7, x3
    // 0xce1a7c: mov             x2, x3
    // 0xce1a80: r16 = Instance_CupertinoUserInterfaceLevelData
    //     0xce1a80: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e890] Obj!CupertinoUserInterfaceLevelData@12c5fe1
    //     0xce1a84: ldr             x16, [x16, #0x890]
    // 0xce1a88: cmp             w7, w16
    // 0xce1a8c: r16 = true
    //     0xce1a8c: add             x16, NULL, #0x20  ; true
    // 0xce1a90: r17 = false
    //     0xce1a90: add             x17, NULL, #0x30  ; false
    // 0xce1a94: csel            x8, x16, x17, eq
    // 0xce1a98: mov             x19, x8
    // 0xce1a9c: mov             x16, x8
    // 0xce1aa0: mov             x8, x2
    // 0xce1aa4: mov             x2, x16
    // 0xce1aa8: r7 = true
    //     0xce1aa8: add             x7, NULL, #0x20  ; true
    // 0xce1aac: r16 = true
    //     0xce1aac: add             x16, NULL, #0x20  ; true
    // 0xce1ab0: cmp             w19, w16
    // 0xce1ab4: b.ne            #0xce1b54
    // 0xce1ab8: tbnz            w4, #4, #0xce1adc
    // 0xce1abc: mov             x4, x5
    // 0xce1ac0: mov             x16, x9
    // 0xce1ac4: mov             x9, x5
    // 0xce1ac8: mov             x5, x16
    // 0xce1acc: mov             x16, x10
    // 0xce1ad0: mov             x10, x9
    // 0xce1ad4: mov             x9, x16
    // 0xce1ad8: b               #0xce1b1c
    // 0xce1adc: tbnz            w9, #4, #0xce1aec
    // 0xce1ae0: mov             x5, x10
    // 0xce1ae4: mov             x4, x10
    // 0xce1ae8: b               #0xce1af4
    // 0xce1aec: mov             x5, x1
    // 0xce1af0: mov             x4, x1
    // 0xce1af4: r16 = true
    //     0xce1af4: add             x16, NULL, #0x20  ; true
    // 0xce1af8: cmp             w5, w16
    // 0xce1afc: r16 = true
    //     0xce1afc: add             x16, NULL, #0x20  ; true
    // 0xce1b00: r17 = false
    //     0xce1b00: add             x17, NULL, #0x30  ; false
    // 0xce1b04: csel            x9, x16, x17, eq
    // 0xce1b08: mov             x10, x9
    // 0xce1b0c: mov             x16, x9
    // 0xce1b10: mov             x9, x4
    // 0xce1b14: mov             x4, x16
    // 0xce1b18: r5 = true
    //     0xce1b18: add             x5, NULL, #0x20  ; true
    // 0xce1b1c: r16 = true
    //     0xce1b1c: add             x16, NULL, #0x20  ; true
    // 0xce1b20: cmp             w10, w16
    // 0xce1b24: b.ne            #0xce1b34
    // 0xce1b28: LoadField: r0 = r6->field_2b
    //     0xce1b28: ldur            w0, [x6, #0x2b]
    // 0xce1b2c: DecompressPointer r0
    //     0xce1b2c: add             x0, x0, HEAP, lsl #32
    // 0xce1b30: b               #0xce1f68
    // 0xce1b34: mov             x19, x8
    // 0xce1b38: mov             x10, x7
    // 0xce1b3c: mov             x8, x5
    // 0xce1b40: mov             x7, x4
    // 0xce1b44: mov             x4, x2
    // 0xce1b48: r5 = true
    //     0xce1b48: add             x5, NULL, #0x20  ; true
    // 0xce1b4c: r2 = true
    //     0xce1b4c: add             x2, NULL, #0x20  ; true
    // 0xce1b50: b               #0xce1b98
    // 0xce1b54: mov             x19, x8
    // 0xce1b58: mov             x8, x9
    // 0xce1b5c: mov             x9, x10
    // 0xce1b60: mov             x10, x7
    // 0xce1b64: mov             x7, x5
    // 0xce1b68: mov             x5, x4
    // 0xce1b6c: mov             x4, x2
    // 0xce1b70: r2 = true
    //     0xce1b70: add             x2, NULL, #0x20  ; true
    // 0xce1b74: b               #0xce1b98
    // 0xce1b78: mov             x2, x7
    // 0xce1b7c: mov             x7, x5
    // 0xce1b80: mov             x5, x4
    // 0xce1b84: mov             x4, x8
    // 0xce1b88: mov             x8, x9
    // 0xce1b8c: mov             x9, x10
    // 0xce1b90: mov             x10, x19
    // 0xce1b94: mov             x19, x20
    // 0xce1b98: r16 = Instance_Brightness
    //     0xce1b98: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0xce1b9c: cmp             w0, w16
    // 0xce1ba0: r16 = true
    //     0xce1ba0: add             x16, NULL, #0x20  ; true
    // 0xce1ba4: r17 = false
    //     0xce1ba4: add             x17, NULL, #0x30  ; false
    // 0xce1ba8: csel            x20, x16, x17, eq
    // 0xce1bac: tbnz            w20, #4, #0xce1cd0
    // 0xce1bb0: tbnz            w13, #4, #0xce1bc0
    // 0xce1bb4: mov             x13, x14
    // 0xce1bb8: mov             x0, x19
    // 0xce1bbc: b               #0xce1bf8
    // 0xce1bc0: tbnz            w10, #4, #0xce1bd0
    // 0xce1bc4: mov             x10, x19
    // 0xce1bc8: mov             x0, x19
    // 0xce1bcc: b               #0xce1bd8
    // 0xce1bd0: mov             x10, x3
    // 0xce1bd4: mov             x0, x3
    // 0xce1bd8: r16 = Instance_CupertinoUserInterfaceLevelData
    //     0xce1bd8: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e888] Obj!CupertinoUserInterfaceLevelData@12c6001
    //     0xce1bdc: ldr             x16, [x16, #0x888]
    // 0xce1be0: cmp             w10, w16
    // 0xce1be4: r16 = true
    //     0xce1be4: add             x16, NULL, #0x20  ; true
    // 0xce1be8: r17 = false
    //     0xce1be8: add             x17, NULL, #0x30  ; false
    // 0xce1bec: csel            x13, x16, x17, eq
    // 0xce1bf0: mov             x14, x13
    // 0xce1bf4: r10 = true
    //     0xce1bf4: add             x10, NULL, #0x20  ; true
    // 0xce1bf8: r16 = true
    //     0xce1bf8: add             x16, NULL, #0x20  ; true
    // 0xce1bfc: cmp             w14, w16
    // 0xce1c00: b.ne            #0xce1c88
    // 0xce1c04: tbnz            w11, #4, #0xce1c1c
    // 0xce1c08: mov             x11, x12
    // 0xce1c0c: mov             x16, x9
    // 0xce1c10: mov             x9, x8
    // 0xce1c14: mov             x8, x16
    // 0xce1c18: b               #0xce1c4c
    // 0xce1c1c: tbnz            w8, #4, #0xce1c28
    // 0xce1c20: mov             x8, x9
    // 0xce1c24: b               #0xce1c30
    // 0xce1c28: mov             x9, x1
    // 0xce1c2c: mov             x8, x1
    // 0xce1c30: r16 = false
    //     0xce1c30: add             x16, NULL, #0x30  ; false
    // 0xce1c34: cmp             w9, w16
    // 0xce1c38: r16 = true
    //     0xce1c38: add             x16, NULL, #0x20  ; true
    // 0xce1c3c: r17 = false
    //     0xce1c3c: add             x17, NULL, #0x30  ; false
    // 0xce1c40: csel            x11, x16, x17, eq
    // 0xce1c44: mov             x12, x11
    // 0xce1c48: r9 = true
    //     0xce1c48: add             x9, NULL, #0x20  ; true
    // 0xce1c4c: r16 = true
    //     0xce1c4c: add             x16, NULL, #0x20  ; true
    // 0xce1c50: cmp             w12, w16
    // 0xce1c54: b.ne            #0xce1c64
    // 0xce1c58: ArrayLoad: r0 = r6[0]  ; List_4
    //     0xce1c58: ldur            w0, [x6, #0x17]
    // 0xce1c5c: DecompressPointer r0
    //     0xce1c5c: add             x0, x0, HEAP, lsl #32
    // 0xce1c60: b               #0xce1f68
    // 0xce1c64: mov             x14, x13
    // 0xce1c68: mov             x12, x0
    // 0xce1c6c: mov             x16, x11
    // 0xce1c70: mov             x11, x10
    // 0xce1c74: mov             x10, x16
    // 0xce1c78: mov             x0, x9
    // 0xce1c7c: r13 = true
    //     0xce1c7c: add             x13, NULL, #0x20  ; true
    // 0xce1c80: r9 = true
    //     0xce1c80: add             x9, NULL, #0x20  ; true
    // 0xce1c84: b               #0xce1ce8
    // 0xce1c88: mov             x14, x13
    // 0xce1c8c: mov             x16, x8
    // 0xce1c90: mov             x8, x0
    // 0xce1c94: mov             x0, x16
    // 0xce1c98: mov             x16, x9
    // 0xce1c9c: mov             x9, x8
    // 0xce1ca0: mov             x8, x16
    // 0xce1ca4: mov             x16, x11
    // 0xce1ca8: mov             x11, x9
    // 0xce1cac: mov             x9, x16
    // 0xce1cb0: mov             x16, x10
    // 0xce1cb4: mov             x10, x11
    // 0xce1cb8: mov             x11, x16
    // 0xce1cbc: mov             x16, x12
    // 0xce1cc0: mov             x12, x10
    // 0xce1cc4: mov             x10, x16
    // 0xce1cc8: r13 = true
    //     0xce1cc8: add             x13, NULL, #0x20  ; true
    // 0xce1ccc: b               #0xce1ce8
    // 0xce1cd0: mov             x0, x8
    // 0xce1cd4: mov             x8, x9
    // 0xce1cd8: mov             x9, x11
    // 0xce1cdc: mov             x11, x10
    // 0xce1ce0: mov             x10, x12
    // 0xce1ce4: mov             x12, x19
    // 0xce1ce8: tbnz            w20, #4, #0xce1ddc
    // 0xce1cec: tbnz            w13, #4, #0xce1cf8
    // 0xce1cf0: mov             x13, x14
    // 0xce1cf4: b               #0xce1d2c
    // 0xce1cf8: tbnz            w11, #4, #0xce1d04
    // 0xce1cfc: mov             x11, x12
    // 0xce1d00: b               #0xce1d0c
    // 0xce1d04: mov             x12, x3
    // 0xce1d08: mov             x11, x3
    // 0xce1d0c: r16 = Instance_CupertinoUserInterfaceLevelData
    //     0xce1d0c: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e888] Obj!CupertinoUserInterfaceLevelData@12c6001
    //     0xce1d10: ldr             x16, [x16, #0x888]
    // 0xce1d14: cmp             w12, w16
    // 0xce1d18: r16 = true
    //     0xce1d18: add             x16, NULL, #0x20  ; true
    // 0xce1d1c: r17 = false
    //     0xce1d1c: add             x17, NULL, #0x30  ; false
    // 0xce1d20: csel            x13, x16, x17, eq
    // 0xce1d24: mov             x12, x11
    // 0xce1d28: r11 = true
    //     0xce1d28: add             x11, NULL, #0x20  ; true
    // 0xce1d2c: r16 = true
    //     0xce1d2c: add             x16, NULL, #0x20  ; true
    // 0xce1d30: cmp             w13, w16
    // 0xce1d34: b.ne            #0xce1dc0
    // 0xce1d38: tbnz            w5, #4, #0xce1d54
    // 0xce1d3c: mov             x5, x0
    // 0xce1d40: mov             x0, x7
    // 0xce1d44: mov             x16, x8
    // 0xce1d48: mov             x8, x7
    // 0xce1d4c: mov             x7, x16
    // 0xce1d50: b               #0xce1d94
    // 0xce1d54: tbnz            w0, #4, #0xce1d64
    // 0xce1d58: mov             x5, x8
    // 0xce1d5c: mov             x0, x8
    // 0xce1d60: b               #0xce1d6c
    // 0xce1d64: mov             x5, x1
    // 0xce1d68: mov             x0, x1
    // 0xce1d6c: r16 = true
    //     0xce1d6c: add             x16, NULL, #0x20  ; true
    // 0xce1d70: cmp             w5, w16
    // 0xce1d74: r16 = true
    //     0xce1d74: add             x16, NULL, #0x20  ; true
    // 0xce1d78: r17 = false
    //     0xce1d78: add             x17, NULL, #0x30  ; false
    // 0xce1d7c: csel            x7, x16, x17, eq
    // 0xce1d80: mov             x8, x7
    // 0xce1d84: mov             x16, x7
    // 0xce1d88: mov             x7, x0
    // 0xce1d8c: mov             x0, x16
    // 0xce1d90: r5 = true
    //     0xce1d90: add             x5, NULL, #0x20  ; true
    // 0xce1d94: r16 = true
    //     0xce1d94: add             x16, NULL, #0x20  ; true
    // 0xce1d98: cmp             w8, w16
    // 0xce1d9c: b.ne            #0xce1dac
    // 0xce1da0: LoadField: r0 = r6->field_1f
    //     0xce1da0: ldur            w0, [x6, #0x1f]
    // 0xce1da4: DecompressPointer r0
    //     0xce1da4: add             x0, x0, HEAP, lsl #32
    // 0xce1da8: b               #0xce1f68
    // 0xce1dac: mov             x8, x7
    // 0xce1db0: mov             x7, x5
    // 0xce1db4: mov             x5, x0
    // 0xce1db8: r0 = true
    //     0xce1db8: add             x0, NULL, #0x20  ; true
    // 0xce1dbc: b               #0xce1df4
    // 0xce1dc0: mov             x16, x5
    // 0xce1dc4: mov             x5, x0
    // 0xce1dc8: mov             x0, x16
    // 0xce1dcc: mov             x16, x7
    // 0xce1dd0: mov             x7, x5
    // 0xce1dd4: mov             x5, x16
    // 0xce1dd8: b               #0xce1df4
    // 0xce1ddc: mov             x16, x5
    // 0xce1de0: mov             x5, x0
    // 0xce1de4: mov             x0, x16
    // 0xce1de8: mov             x16, x7
    // 0xce1dec: mov             x7, x5
    // 0xce1df0: mov             x5, x16
    // 0xce1df4: tbnz            w20, #4, #0xce1ee8
    // 0xce1df8: tbnz            w2, #4, #0xce1e1c
    // 0xce1dfc: mov             x2, x4
    // 0xce1e00: mov             x16, x11
    // 0xce1e04: mov             x11, x4
    // 0xce1e08: mov             x4, x16
    // 0xce1e0c: mov             x16, x12
    // 0xce1e10: mov             x12, x11
    // 0xce1e14: mov             x11, x16
    // 0xce1e18: b               #0xce1e60
    // 0xce1e1c: tbnz            w11, #4, #0xce1e2c
    // 0xce1e20: mov             x4, x12
    // 0xce1e24: mov             x2, x12
    // 0xce1e28: b               #0xce1e34
    // 0xce1e2c: mov             x4, x3
    // 0xce1e30: mov             x2, x3
    // 0xce1e34: r16 = Instance_CupertinoUserInterfaceLevelData
    //     0xce1e34: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e890] Obj!CupertinoUserInterfaceLevelData@12c5fe1
    //     0xce1e38: ldr             x16, [x16, #0x890]
    // 0xce1e3c: cmp             w4, w16
    // 0xce1e40: r16 = true
    //     0xce1e40: add             x16, NULL, #0x20  ; true
    // 0xce1e44: r17 = false
    //     0xce1e44: add             x17, NULL, #0x30  ; false
    // 0xce1e48: csel            x11, x16, x17, eq
    // 0xce1e4c: mov             x12, x11
    // 0xce1e50: mov             x16, x11
    // 0xce1e54: mov             x11, x2
    // 0xce1e58: mov             x2, x16
    // 0xce1e5c: r4 = true
    //     0xce1e5c: add             x4, NULL, #0x20  ; true
    // 0xce1e60: r16 = true
    //     0xce1e60: add             x16, NULL, #0x20  ; true
    // 0xce1e64: cmp             w12, w16
    // 0xce1e68: b.ne            #0xce1ed4
    // 0xce1e6c: tbnz            w9, #4, #0xce1e78
    // 0xce1e70: mov             x9, x10
    // 0xce1e74: b               #0xce1ea8
    // 0xce1e78: tbnz            w7, #4, #0xce1e84
    // 0xce1e7c: mov             x7, x8
    // 0xce1e80: b               #0xce1e8c
    // 0xce1e84: mov             x8, x1
    // 0xce1e88: mov             x7, x1
    // 0xce1e8c: r16 = false
    //     0xce1e8c: add             x16, NULL, #0x30  ; false
    // 0xce1e90: cmp             w8, w16
    // 0xce1e94: r16 = true
    //     0xce1e94: add             x16, NULL, #0x20  ; true
    // 0xce1e98: r17 = false
    //     0xce1e98: add             x17, NULL, #0x30  ; false
    // 0xce1e9c: csel            x9, x16, x17, eq
    // 0xce1ea0: mov             x8, x7
    // 0xce1ea4: r7 = true
    //     0xce1ea4: add             x7, NULL, #0x20  ; true
    // 0xce1ea8: r16 = true
    //     0xce1ea8: add             x16, NULL, #0x20  ; true
    // 0xce1eac: cmp             w9, w16
    // 0xce1eb0: b.ne            #0xce1ec0
    // 0xce1eb4: LoadField: r0 = r6->field_27
    //     0xce1eb4: ldur            w0, [x6, #0x27]
    // 0xce1eb8: DecompressPointer r0
    //     0xce1eb8: add             x0, x0, HEAP, lsl #32
    // 0xce1ebc: b               #0xce1f68
    // 0xce1ec0: mov             x10, x11
    // 0xce1ec4: mov             x9, x4
    // 0xce1ec8: mov             x4, x2
    // 0xce1ecc: r2 = true
    //     0xce1ecc: add             x2, NULL, #0x20  ; true
    // 0xce1ed0: b               #0xce1ef0
    // 0xce1ed4: mov             x10, x11
    // 0xce1ed8: mov             x9, x4
    // 0xce1edc: mov             x4, x2
    // 0xce1ee0: r2 = true
    //     0xce1ee0: add             x2, NULL, #0x20  ; true
    // 0xce1ee4: b               #0xce1ef0
    // 0xce1ee8: mov             x10, x12
    // 0xce1eec: mov             x9, x11
    // 0xce1ef0: tbnz            w20, #4, #0xce1f64
    // 0xce1ef4: tbnz            w2, #4, #0xce1f08
    // 0xce1ef8: r16 = true
    //     0xce1ef8: add             x16, NULL, #0x20  ; true
    // 0xce1efc: cmp             w4, w16
    // 0xce1f00: b.ne            #0xce1f64
    // 0xce1f04: b               #0xce1f28
    // 0xce1f08: tbnz            w9, #4, #0xce1f14
    // 0xce1f0c: mov             x2, x10
    // 0xce1f10: b               #0xce1f18
    // 0xce1f14: mov             x2, x3
    // 0xce1f18: r16 = Instance_CupertinoUserInterfaceLevelData
    //     0xce1f18: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e890] Obj!CupertinoUserInterfaceLevelData@12c5fe1
    //     0xce1f1c: ldr             x16, [x16, #0x890]
    // 0xce1f20: cmp             w2, w16
    // 0xce1f24: b.ne            #0xce1f64
    // 0xce1f28: tbnz            w0, #4, #0xce1f3c
    // 0xce1f2c: r16 = true
    //     0xce1f2c: add             x16, NULL, #0x20  ; true
    // 0xce1f30: cmp             w5, w16
    // 0xce1f34: b.ne            #0xce1f64
    // 0xce1f38: b               #0xce1f58
    // 0xce1f3c: tbnz            w7, #4, #0xce1f48
    // 0xce1f40: mov             x0, x8
    // 0xce1f44: b               #0xce1f4c
    // 0xce1f48: mov             x0, x1
    // 0xce1f4c: r16 = true
    //     0xce1f4c: add             x16, NULL, #0x20  ; true
    // 0xce1f50: cmp             w0, w16
    // 0xce1f54: b.ne            #0xce1f64
    // 0xce1f58: LoadField: r0 = r6->field_2f
    //     0xce1f58: ldur            w0, [x6, #0x2f]
    // 0xce1f5c: DecompressPointer r0
    //     0xce1f5c: add             x0, x0, HEAP, lsl #32
    // 0xce1f60: b               #0xce1f68
    // 0xce1f64: r0 = Null
    //     0xce1f64: mov             x0, NULL
    // 0xce1f68: stur            x0, [fp, #-0x58]
    // 0xce1f6c: LoadField: r1 = r6->field_13
    //     0xce1f6c: ldur            w1, [x6, #0x13]
    // 0xce1f70: DecompressPointer r1
    //     0xce1f70: add             x1, x1, HEAP, lsl #32
    // 0xce1f74: stur            x1, [fp, #-0x50]
    // 0xce1f78: ArrayLoad: r2 = r6[0]  ; List_4
    //     0xce1f78: ldur            w2, [x6, #0x17]
    // 0xce1f7c: DecompressPointer r2
    //     0xce1f7c: add             x2, x2, HEAP, lsl #32
    // 0xce1f80: stur            x2, [fp, #-0x48]
    // 0xce1f84: LoadField: r3 = r6->field_1b
    //     0xce1f84: ldur            w3, [x6, #0x1b]
    // 0xce1f88: DecompressPointer r3
    //     0xce1f88: add             x3, x3, HEAP, lsl #32
    // 0xce1f8c: stur            x3, [fp, #-0x40]
    // 0xce1f90: LoadField: r4 = r6->field_1f
    //     0xce1f90: ldur            w4, [x6, #0x1f]
    // 0xce1f94: DecompressPointer r4
    //     0xce1f94: add             x4, x4, HEAP, lsl #32
    // 0xce1f98: stur            x4, [fp, #-0x38]
    // 0xce1f9c: LoadField: r5 = r6->field_23
    //     0xce1f9c: ldur            w5, [x6, #0x23]
    // 0xce1fa0: DecompressPointer r5
    //     0xce1fa0: add             x5, x5, HEAP, lsl #32
    // 0xce1fa4: stur            x5, [fp, #-0x30]
    // 0xce1fa8: LoadField: r7 = r6->field_27
    //     0xce1fa8: ldur            w7, [x6, #0x27]
    // 0xce1fac: DecompressPointer r7
    //     0xce1fac: add             x7, x7, HEAP, lsl #32
    // 0xce1fb0: stur            x7, [fp, #-0x28]
    // 0xce1fb4: LoadField: r8 = r6->field_2b
    //     0xce1fb4: ldur            w8, [x6, #0x2b]
    // 0xce1fb8: DecompressPointer r8
    //     0xce1fb8: add             x8, x8, HEAP, lsl #32
    // 0xce1fbc: stur            x8, [fp, #-0x20]
    // 0xce1fc0: LoadField: r9 = r6->field_2f
    //     0xce1fc0: ldur            w9, [x6, #0x2f]
    // 0xce1fc4: DecompressPointer r9
    //     0xce1fc4: add             x9, x9, HEAP, lsl #32
    // 0xce1fc8: stur            x9, [fp, #-0x18]
    // 0xce1fcc: LoadField: r10 = r6->field_b
    //     0xce1fcc: ldur            w10, [x6, #0xb]
    // 0xce1fd0: DecompressPointer r10
    //     0xce1fd0: add             x10, x10, HEAP, lsl #32
    // 0xce1fd4: stur            x10, [fp, #-0x10]
    // 0xce1fd8: r0 = CupertinoDynamicColor()
    //     0xce1fd8: bl              #0xce2040  ; AllocateCupertinoDynamicColorStub -> CupertinoDynamicColor (size=0x34)
    // 0xce1fdc: ldur            x1, [fp, #-0x58]
    // 0xce1fe0: StoreField: r0->field_7 = r1
    //     0xce1fe0: stur            w1, [x0, #7]
    // 0xce1fe4: ldur            x1, [fp, #-0x50]
    // 0xce1fe8: StoreField: r0->field_13 = r1
    //     0xce1fe8: stur            w1, [x0, #0x13]
    // 0xce1fec: ldur            x1, [fp, #-0x48]
    // 0xce1ff0: ArrayStore: r0[0] = r1  ; List_4
    //     0xce1ff0: stur            w1, [x0, #0x17]
    // 0xce1ff4: ldur            x1, [fp, #-0x40]
    // 0xce1ff8: StoreField: r0->field_1b = r1
    //     0xce1ff8: stur            w1, [x0, #0x1b]
    // 0xce1ffc: ldur            x1, [fp, #-0x38]
    // 0xce2000: StoreField: r0->field_1f = r1
    //     0xce2000: stur            w1, [x0, #0x1f]
    // 0xce2004: ldur            x1, [fp, #-0x30]
    // 0xce2008: StoreField: r0->field_23 = r1
    //     0xce2008: stur            w1, [x0, #0x23]
    // 0xce200c: ldur            x1, [fp, #-0x28]
    // 0xce2010: StoreField: r0->field_27 = r1
    //     0xce2010: stur            w1, [x0, #0x27]
    // 0xce2014: ldur            x1, [fp, #-0x20]
    // 0xce2018: StoreField: r0->field_2b = r1
    //     0xce2018: stur            w1, [x0, #0x2b]
    // 0xce201c: ldur            x1, [fp, #-0x18]
    // 0xce2020: StoreField: r0->field_2f = r1
    //     0xce2020: stur            w1, [x0, #0x2f]
    // 0xce2024: ldur            x1, [fp, #-0x10]
    // 0xce2028: StoreField: r0->field_b = r1
    //     0xce2028: stur            w1, [x0, #0xb]
    // 0xce202c: LeaveFrame
    //     0xce202c: mov             SP, fp
    //     0xce2030: ldp             fp, lr, [SP], #0x10
    // 0xce2034: ret
    //     0xce2034: ret             
    // 0xce2038: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce2038: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce203c: b               #0xce16f8
  }
  get _ _isHighContrastDependent(/* No info */) {
    // ** addr: 0xce20a8, size: 0xe0
    // 0xce20a8: EnterFrame
    //     0xce20a8: stp             fp, lr, [SP, #-0x10]!
    //     0xce20ac: mov             fp, SP
    // 0xce20b0: AllocStack(0x18)
    //     0xce20b0: sub             SP, SP, #0x18
    // 0xce20b4: SetupParameters(CupertinoDynamicColor this /* r1 => r1, fp-0x8 */)
    //     0xce20b4: stur            x1, [fp, #-8]
    // 0xce20b8: CheckStackOverflow
    //     0xce20b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce20bc: cmp             SP, x16
    //     0xce20c0: b.ls            #0xce2180
    // 0xce20c4: LoadField: r0 = r1->field_13
    //     0xce20c4: ldur            w0, [x1, #0x13]
    // 0xce20c8: DecompressPointer r0
    //     0xce20c8: add             x0, x0, HEAP, lsl #32
    // 0xce20cc: LoadField: r2 = r1->field_1b
    //     0xce20cc: ldur            w2, [x1, #0x1b]
    // 0xce20d0: DecompressPointer r2
    //     0xce20d0: add             x2, x2, HEAP, lsl #32
    // 0xce20d4: r3 = LoadClassIdInstr(r0)
    //     0xce20d4: ldur            x3, [x0, #-1]
    //     0xce20d8: ubfx            x3, x3, #0xc, #0x14
    // 0xce20dc: stp             x2, x0, [SP]
    // 0xce20e0: mov             x0, x3
    // 0xce20e4: mov             lr, x0
    // 0xce20e8: ldr             lr, [x21, lr, lsl #3]
    // 0xce20ec: blr             lr
    // 0xce20f0: tbnz            w0, #4, #0xce2148
    // 0xce20f4: ldur            x0, [fp, #-8]
    // 0xce20f8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xce20f8: ldur            w1, [x0, #0x17]
    // 0xce20fc: DecompressPointer r1
    //     0xce20fc: add             x1, x1, HEAP, lsl #32
    // 0xce2100: LoadField: r2 = r0->field_1f
    //     0xce2100: ldur            w2, [x0, #0x1f]
    // 0xce2104: DecompressPointer r2
    //     0xce2104: add             x2, x2, HEAP, lsl #32
    // 0xce2108: stp             x2, x1, [SP]
    // 0xce210c: r0 = ==()
    //     0xce210c: bl              #0x128cb50  ; [dart:ui] Color::==
    // 0xce2110: tbnz            w0, #4, #0xce2148
    // 0xce2114: ldur            x1, [fp, #-8]
    // 0xce2118: LoadField: r0 = r1->field_23
    //     0xce2118: ldur            w0, [x1, #0x23]
    // 0xce211c: DecompressPointer r0
    //     0xce211c: add             x0, x0, HEAP, lsl #32
    // 0xce2120: LoadField: r2 = r1->field_2b
    //     0xce2120: ldur            w2, [x1, #0x2b]
    // 0xce2124: DecompressPointer r2
    //     0xce2124: add             x2, x2, HEAP, lsl #32
    // 0xce2128: r3 = LoadClassIdInstr(r0)
    //     0xce2128: ldur            x3, [x0, #-1]
    //     0xce212c: ubfx            x3, x3, #0xc, #0x14
    // 0xce2130: stp             x2, x0, [SP]
    // 0xce2134: mov             x0, x3
    // 0xce2138: mov             lr, x0
    // 0xce213c: ldr             lr, [x21, lr, lsl #3]
    // 0xce2140: blr             lr
    // 0xce2144: tbz             w0, #4, #0xce2150
    // 0xce2148: r0 = true
    //     0xce2148: add             x0, NULL, #0x20  ; true
    // 0xce214c: b               #0xce2174
    // 0xce2150: ldur            x0, [fp, #-8]
    // 0xce2154: LoadField: r1 = r0->field_27
    //     0xce2154: ldur            w1, [x0, #0x27]
    // 0xce2158: DecompressPointer r1
    //     0xce2158: add             x1, x1, HEAP, lsl #32
    // 0xce215c: LoadField: r2 = r0->field_2f
    //     0xce215c: ldur            w2, [x0, #0x2f]
    // 0xce2160: DecompressPointer r2
    //     0xce2160: add             x2, x2, HEAP, lsl #32
    // 0xce2164: stp             x2, x1, [SP]
    // 0xce2168: r0 = ==()
    //     0xce2168: bl              #0x128cb50  ; [dart:ui] Color::==
    // 0xce216c: eor             x1, x0, #0x10
    // 0xce2170: mov             x0, x1
    // 0xce2174: LeaveFrame
    //     0xce2174: mov             SP, fp
    //     0xce2178: ldp             fp, lr, [SP], #0x10
    // 0xce217c: ret
    //     0xce217c: ret             
    // 0xce2180: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce2180: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce2184: b               #0xce20c4
  }
  get _ _isInterfaceElevationDependent(/* No info */) {
    // ** addr: 0xce21e0, size: 0xe0
    // 0xce21e0: EnterFrame
    //     0xce21e0: stp             fp, lr, [SP, #-0x10]!
    //     0xce21e4: mov             fp, SP
    // 0xce21e8: AllocStack(0x18)
    //     0xce21e8: sub             SP, SP, #0x18
    // 0xce21ec: SetupParameters(CupertinoDynamicColor this /* r1 => r1, fp-0x8 */)
    //     0xce21ec: stur            x1, [fp, #-8]
    // 0xce21f0: CheckStackOverflow
    //     0xce21f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce21f4: cmp             SP, x16
    //     0xce21f8: b.ls            #0xce22b8
    // 0xce21fc: LoadField: r0 = r1->field_13
    //     0xce21fc: ldur            w0, [x1, #0x13]
    // 0xce2200: DecompressPointer r0
    //     0xce2200: add             x0, x0, HEAP, lsl #32
    // 0xce2204: LoadField: r2 = r1->field_23
    //     0xce2204: ldur            w2, [x1, #0x23]
    // 0xce2208: DecompressPointer r2
    //     0xce2208: add             x2, x2, HEAP, lsl #32
    // 0xce220c: r3 = LoadClassIdInstr(r0)
    //     0xce220c: ldur            x3, [x0, #-1]
    //     0xce2210: ubfx            x3, x3, #0xc, #0x14
    // 0xce2214: stp             x2, x0, [SP]
    // 0xce2218: mov             x0, x3
    // 0xce221c: mov             lr, x0
    // 0xce2220: ldr             lr, [x21, lr, lsl #3]
    // 0xce2224: blr             lr
    // 0xce2228: tbnz            w0, #4, #0xce2280
    // 0xce222c: ldur            x0, [fp, #-8]
    // 0xce2230: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xce2230: ldur            w1, [x0, #0x17]
    // 0xce2234: DecompressPointer r1
    //     0xce2234: add             x1, x1, HEAP, lsl #32
    // 0xce2238: LoadField: r2 = r0->field_27
    //     0xce2238: ldur            w2, [x0, #0x27]
    // 0xce223c: DecompressPointer r2
    //     0xce223c: add             x2, x2, HEAP, lsl #32
    // 0xce2240: stp             x2, x1, [SP]
    // 0xce2244: r0 = ==()
    //     0xce2244: bl              #0x128cb50  ; [dart:ui] Color::==
    // 0xce2248: tbnz            w0, #4, #0xce2280
    // 0xce224c: ldur            x1, [fp, #-8]
    // 0xce2250: LoadField: r0 = r1->field_1b
    //     0xce2250: ldur            w0, [x1, #0x1b]
    // 0xce2254: DecompressPointer r0
    //     0xce2254: add             x0, x0, HEAP, lsl #32
    // 0xce2258: LoadField: r2 = r1->field_2b
    //     0xce2258: ldur            w2, [x1, #0x2b]
    // 0xce225c: DecompressPointer r2
    //     0xce225c: add             x2, x2, HEAP, lsl #32
    // 0xce2260: r3 = LoadClassIdInstr(r0)
    //     0xce2260: ldur            x3, [x0, #-1]
    //     0xce2264: ubfx            x3, x3, #0xc, #0x14
    // 0xce2268: stp             x2, x0, [SP]
    // 0xce226c: mov             x0, x3
    // 0xce2270: mov             lr, x0
    // 0xce2274: ldr             lr, [x21, lr, lsl #3]
    // 0xce2278: blr             lr
    // 0xce227c: tbz             w0, #4, #0xce2288
    // 0xce2280: r0 = true
    //     0xce2280: add             x0, NULL, #0x20  ; true
    // 0xce2284: b               #0xce22ac
    // 0xce2288: ldur            x0, [fp, #-8]
    // 0xce228c: LoadField: r1 = r0->field_1f
    //     0xce228c: ldur            w1, [x0, #0x1f]
    // 0xce2290: DecompressPointer r1
    //     0xce2290: add             x1, x1, HEAP, lsl #32
    // 0xce2294: LoadField: r2 = r0->field_2f
    //     0xce2294: ldur            w2, [x0, #0x2f]
    // 0xce2298: DecompressPointer r2
    //     0xce2298: add             x2, x2, HEAP, lsl #32
    // 0xce229c: stp             x2, x1, [SP]
    // 0xce22a0: r0 = ==()
    //     0xce22a0: bl              #0x128cb50  ; [dart:ui] Color::==
    // 0xce22a4: eor             x1, x0, #0x10
    // 0xce22a8: mov             x0, x1
    // 0xce22ac: LeaveFrame
    //     0xce22ac: mov             SP, fp
    //     0xce22b0: ldp             fp, lr, [SP], #0x10
    // 0xce22b4: ret
    //     0xce22b4: ret             
    // 0xce22b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce22b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce22bc: b               #0xce21fc
  }
  get _ _isPlatformBrightnessDependent(/* No info */) {
    // ** addr: 0xce23ac, size: 0x104
    // 0xce23ac: EnterFrame
    //     0xce23ac: stp             fp, lr, [SP, #-0x10]!
    //     0xce23b0: mov             fp, SP
    // 0xce23b4: AllocStack(0x18)
    //     0xce23b4: sub             SP, SP, #0x18
    // 0xce23b8: SetupParameters(CupertinoDynamicColor this /* r1 => r1, fp-0x8 */)
    //     0xce23b8: stur            x1, [fp, #-8]
    // 0xce23bc: CheckStackOverflow
    //     0xce23bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce23c0: cmp             SP, x16
    //     0xce23c4: b.ls            #0xce24a8
    // 0xce23c8: LoadField: r0 = r1->field_13
    //     0xce23c8: ldur            w0, [x1, #0x13]
    // 0xce23cc: DecompressPointer r0
    //     0xce23cc: add             x0, x0, HEAP, lsl #32
    // 0xce23d0: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xce23d0: ldur            w2, [x1, #0x17]
    // 0xce23d4: DecompressPointer r2
    //     0xce23d4: add             x2, x2, HEAP, lsl #32
    // 0xce23d8: r3 = LoadClassIdInstr(r0)
    //     0xce23d8: ldur            x3, [x0, #-1]
    //     0xce23dc: ubfx            x3, x3, #0xc, #0x14
    // 0xce23e0: stp             x2, x0, [SP]
    // 0xce23e4: mov             x0, x3
    // 0xce23e8: mov             lr, x0
    // 0xce23ec: ldr             lr, [x21, lr, lsl #3]
    // 0xce23f0: blr             lr
    // 0xce23f4: tbnz            w0, #4, #0xce2460
    // 0xce23f8: ldur            x1, [fp, #-8]
    // 0xce23fc: LoadField: r0 = r1->field_23
    //     0xce23fc: ldur            w0, [x1, #0x23]
    // 0xce2400: DecompressPointer r0
    //     0xce2400: add             x0, x0, HEAP, lsl #32
    // 0xce2404: LoadField: r2 = r1->field_27
    //     0xce2404: ldur            w2, [x1, #0x27]
    // 0xce2408: DecompressPointer r2
    //     0xce2408: add             x2, x2, HEAP, lsl #32
    // 0xce240c: r3 = LoadClassIdInstr(r0)
    //     0xce240c: ldur            x3, [x0, #-1]
    //     0xce2410: ubfx            x3, x3, #0xc, #0x14
    // 0xce2414: stp             x2, x0, [SP]
    // 0xce2418: mov             x0, x3
    // 0xce241c: mov             lr, x0
    // 0xce2420: ldr             lr, [x21, lr, lsl #3]
    // 0xce2424: blr             lr
    // 0xce2428: tbnz            w0, #4, #0xce2460
    // 0xce242c: ldur            x1, [fp, #-8]
    // 0xce2430: LoadField: r0 = r1->field_1b
    //     0xce2430: ldur            w0, [x1, #0x1b]
    // 0xce2434: DecompressPointer r0
    //     0xce2434: add             x0, x0, HEAP, lsl #32
    // 0xce2438: LoadField: r2 = r1->field_1f
    //     0xce2438: ldur            w2, [x1, #0x1f]
    // 0xce243c: DecompressPointer r2
    //     0xce243c: add             x2, x2, HEAP, lsl #32
    // 0xce2440: r3 = LoadClassIdInstr(r0)
    //     0xce2440: ldur            x3, [x0, #-1]
    //     0xce2444: ubfx            x3, x3, #0xc, #0x14
    // 0xce2448: stp             x2, x0, [SP]
    // 0xce244c: mov             x0, x3
    // 0xce2450: mov             lr, x0
    // 0xce2454: ldr             lr, [x21, lr, lsl #3]
    // 0xce2458: blr             lr
    // 0xce245c: tbz             w0, #4, #0xce2468
    // 0xce2460: r0 = true
    //     0xce2460: add             x0, NULL, #0x20  ; true
    // 0xce2464: b               #0xce249c
    // 0xce2468: ldur            x0, [fp, #-8]
    // 0xce246c: LoadField: r1 = r0->field_2b
    //     0xce246c: ldur            w1, [x0, #0x2b]
    // 0xce2470: DecompressPointer r1
    //     0xce2470: add             x1, x1, HEAP, lsl #32
    // 0xce2474: LoadField: r2 = r0->field_2f
    //     0xce2474: ldur            w2, [x0, #0x2f]
    // 0xce2478: DecompressPointer r2
    //     0xce2478: add             x2, x2, HEAP, lsl #32
    // 0xce247c: r0 = LoadClassIdInstr(r1)
    //     0xce247c: ldur            x0, [x1, #-1]
    //     0xce2480: ubfx            x0, x0, #0xc, #0x14
    // 0xce2484: stp             x2, x1, [SP]
    // 0xce2488: mov             lr, x0
    // 0xce248c: ldr             lr, [x21, lr, lsl #3]
    // 0xce2490: blr             lr
    // 0xce2494: eor             x1, x0, #0x10
    // 0xce2498: mov             x0, x1
    // 0xce249c: LeaveFrame
    //     0xce249c: mov             SP, fp
    //     0xce24a0: ldp             fp, lr, [SP], #0x10
    // 0xce24a4: ret
    //     0xce24a4: ret             
    // 0xce24a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce24a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce24ac: b               #0xce23c8
  }
  int hashCode(CupertinoDynamicColor) {
    // ** addr: 0x112e338, size: 0xe4
    // 0x112e338: EnterFrame
    //     0x112e338: stp             fp, lr, [SP, #-0x10]!
    //     0x112e33c: mov             fp, SP
    // 0x112e340: AllocStack(0x38)
    //     0x112e340: sub             SP, SP, #0x38
    // 0x112e344: CheckStackOverflow
    //     0x112e344: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x112e348: cmp             SP, x16
    //     0x112e34c: b.ls            #0x112e414
    // 0x112e350: ldr             x2, [fp, #0x10]
    // 0x112e354: LoadField: r1 = r2->field_7
    //     0x112e354: ldur            w1, [x2, #7]
    // 0x112e358: DecompressPointer r1
    //     0x112e358: add             x1, x1, HEAP, lsl #32
    // 0x112e35c: r0 = LoadClassIdInstr(r1)
    //     0x112e35c: ldur            x0, [x1, #-1]
    //     0x112e360: ubfx            x0, x0, #0xc, #0x14
    // 0x112e364: r0 = GDT[cid_x0 + -0xfb8]()
    //     0x112e364: sub             lr, x0, #0xfb8
    //     0x112e368: ldr             lr, [x21, lr, lsl #3]
    //     0x112e36c: blr             lr
    // 0x112e370: mov             x2, x0
    // 0x112e374: ldr             x0, [fp, #0x10]
    // 0x112e378: LoadField: r3 = r0->field_13
    //     0x112e378: ldur            w3, [x0, #0x13]
    // 0x112e37c: DecompressPointer r3
    //     0x112e37c: add             x3, x3, HEAP, lsl #32
    // 0x112e380: ArrayLoad: r4 = r0[0]  ; List_4
    //     0x112e380: ldur            w4, [x0, #0x17]
    // 0x112e384: DecompressPointer r4
    //     0x112e384: add             x4, x4, HEAP, lsl #32
    // 0x112e388: LoadField: r5 = r0->field_1b
    //     0x112e388: ldur            w5, [x0, #0x1b]
    // 0x112e38c: DecompressPointer r5
    //     0x112e38c: add             x5, x5, HEAP, lsl #32
    // 0x112e390: LoadField: r6 = r0->field_23
    //     0x112e390: ldur            w6, [x0, #0x23]
    // 0x112e394: DecompressPointer r6
    //     0x112e394: add             x6, x6, HEAP, lsl #32
    // 0x112e398: LoadField: r7 = r0->field_27
    //     0x112e398: ldur            w7, [x0, #0x27]
    // 0x112e39c: DecompressPointer r7
    //     0x112e39c: add             x7, x7, HEAP, lsl #32
    // 0x112e3a0: LoadField: r8 = r0->field_1f
    //     0x112e3a0: ldur            w8, [x0, #0x1f]
    // 0x112e3a4: DecompressPointer r8
    //     0x112e3a4: add             x8, x8, HEAP, lsl #32
    // 0x112e3a8: LoadField: r9 = r0->field_2f
    //     0x112e3a8: ldur            w9, [x0, #0x2f]
    // 0x112e3ac: DecompressPointer r9
    //     0x112e3ac: add             x9, x9, HEAP, lsl #32
    // 0x112e3b0: LoadField: r10 = r0->field_2b
    //     0x112e3b0: ldur            w10, [x0, #0x2b]
    // 0x112e3b4: DecompressPointer r10
    //     0x112e3b4: add             x10, x10, HEAP, lsl #32
    // 0x112e3b8: r0 = BoxInt64Instr(r2)
    //     0x112e3b8: sbfiz           x0, x2, #1, #0x1f
    //     0x112e3bc: cmp             x2, x0, asr #1
    //     0x112e3c0: b.eq            #0x112e3cc
    //     0x112e3c4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x112e3c8: stur            x2, [x0, #7]
    // 0x112e3cc: stp             x5, x4, [SP, #0x28]
    // 0x112e3d0: stp             x7, x6, [SP, #0x18]
    // 0x112e3d4: stp             x9, x8, [SP, #8]
    // 0x112e3d8: str             x10, [SP]
    // 0x112e3dc: mov             x1, x0
    // 0x112e3e0: mov             x2, x3
    // 0x112e3e4: r4 = const [0, 0x9, 0x7, 0x9, null]
    //     0x112e3e4: add             x4, PP, #0xe, lsl #12  ; [pp+0xe278] List(5) [0, 0x9, 0x7, 0x9, Null]
    //     0x112e3e8: ldr             x4, [x4, #0x278]
    // 0x112e3ec: r0 = hash()
    //     0x112e3ec: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x112e3f0: mov             x2, x0
    // 0x112e3f4: r0 = BoxInt64Instr(r2)
    //     0x112e3f4: sbfiz           x0, x2, #1, #0x1f
    //     0x112e3f8: cmp             x2, x0, asr #1
    //     0x112e3fc: b.eq            #0x112e408
    //     0x112e400: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x112e404: stur            x2, [x0, #7]
    // 0x112e408: LeaveFrame
    //     0x112e408: mov             SP, fp
    //     0x112e40c: ldp             fp, lr, [SP], #0x10
    // 0x112e410: ret
    //     0x112e410: ret             
    // 0x112e414: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x112e414: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x112e418: b               #0x112e350
  }
  int blue(CupertinoDynamicColor) {
    // ** addr: 0x118031c, size: 0x54
    // 0x118031c: EnterFrame
    //     0x118031c: stp             fp, lr, [SP, #-0x10]!
    //     0x1180320: mov             fp, SP
    // 0x1180324: CheckStackOverflow
    //     0x1180324: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1180328: cmp             SP, x16
    //     0x118032c: b.ls            #0x1180368
    // 0x1180330: LoadField: r0 = r1->field_7
    //     0x1180330: ldur            w0, [x1, #7]
    // 0x1180334: DecompressPointer r0
    //     0x1180334: add             x0, x0, HEAP, lsl #32
    // 0x1180338: r1 = LoadClassIdInstr(r0)
    //     0x1180338: ldur            x1, [x0, #-1]
    //     0x118033c: ubfx            x1, x1, #0xc, #0x14
    // 0x1180340: mov             x16, x0
    // 0x1180344: mov             x0, x1
    // 0x1180348: mov             x1, x16
    // 0x118034c: r0 = GDT[cid_x0 + 0x362a]()
    //     0x118034c: mov             x17, #0x362a
    //     0x1180350: add             lr, x0, x17
    //     0x1180354: ldr             lr, [x21, lr, lsl #3]
    //     0x1180358: blr             lr
    // 0x118035c: LeaveFrame
    //     0x118035c: mov             SP, fp
    //     0x1180360: ldp             fp, lr, [SP], #0x10
    // 0x1180364: ret
    //     0x1180364: ret             
    // 0x1180368: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1180368: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x118036c: b               #0x1180330
  }
  int green(CupertinoDynamicColor) {
    // ** addr: 0x1181cc8, size: 0x54
    // 0x1181cc8: EnterFrame
    //     0x1181cc8: stp             fp, lr, [SP, #-0x10]!
    //     0x1181ccc: mov             fp, SP
    // 0x1181cd0: CheckStackOverflow
    //     0x1181cd0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1181cd4: cmp             SP, x16
    //     0x1181cd8: b.ls            #0x1181d14
    // 0x1181cdc: LoadField: r0 = r1->field_7
    //     0x1181cdc: ldur            w0, [x1, #7]
    // 0x1181ce0: DecompressPointer r0
    //     0x1181ce0: add             x0, x0, HEAP, lsl #32
    // 0x1181ce4: r1 = LoadClassIdInstr(r0)
    //     0x1181ce4: ldur            x1, [x0, #-1]
    //     0x1181ce8: ubfx            x1, x1, #0xc, #0x14
    // 0x1181cec: mov             x16, x0
    // 0x1181cf0: mov             x0, x1
    // 0x1181cf4: mov             x1, x16
    // 0x1181cf8: r0 = GDT[cid_x0 + 0x343f]()
    //     0x1181cf8: mov             x17, #0x343f
    //     0x1181cfc: add             lr, x0, x17
    //     0x1181d00: ldr             lr, [x21, lr, lsl #3]
    //     0x1181d04: blr             lr
    // 0x1181d08: LeaveFrame
    //     0x1181d08: mov             SP, fp
    //     0x1181d0c: ldp             fp, lr, [SP], #0x10
    // 0x1181d10: ret
    //     0x1181d10: ret             
    // 0x1181d14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1181d14: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1181d18: b               #0x1181cdc
  }
  int red(CupertinoDynamicColor) {
    // ** addr: 0x1183d48, size: 0x54
    // 0x1183d48: EnterFrame
    //     0x1183d48: stp             fp, lr, [SP, #-0x10]!
    //     0x1183d4c: mov             fp, SP
    // 0x1183d50: CheckStackOverflow
    //     0x1183d50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1183d54: cmp             SP, x16
    //     0x1183d58: b.ls            #0x1183d94
    // 0x1183d5c: LoadField: r0 = r1->field_7
    //     0x1183d5c: ldur            w0, [x1, #7]
    // 0x1183d60: DecompressPointer r0
    //     0x1183d60: add             x0, x0, HEAP, lsl #32
    // 0x1183d64: r1 = LoadClassIdInstr(r0)
    //     0x1183d64: ldur            x1, [x0, #-1]
    //     0x1183d68: ubfx            x1, x1, #0xc, #0x14
    // 0x1183d6c: mov             x16, x0
    // 0x1183d70: mov             x0, x1
    // 0x1183d74: mov             x1, x16
    // 0x1183d78: r0 = GDT[cid_x0 + 0x30c2]()
    //     0x1183d78: mov             x17, #0x30c2
    //     0x1183d7c: add             lr, x0, x17
    //     0x1183d80: ldr             lr, [x21, lr, lsl #3]
    //     0x1183d84: blr             lr
    // 0x1183d88: LeaveFrame
    //     0x1183d88: mov             SP, fp
    //     0x1183d8c: ldp             fp, lr, [SP], #0x10
    // 0x1183d90: ret
    //     0x1183d90: ret             
    // 0x1183d94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1183d94: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1183d98: b               #0x1183d5c
  }
  int toARGB32(CupertinoDynamicColor) {
    // ** addr: 0x1186010, size: 0x54
    // 0x1186010: EnterFrame
    //     0x1186010: stp             fp, lr, [SP, #-0x10]!
    //     0x1186014: mov             fp, SP
    // 0x1186018: CheckStackOverflow
    //     0x1186018: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x118601c: cmp             SP, x16
    //     0x1186020: b.ls            #0x118605c
    // 0x1186024: LoadField: r0 = r1->field_7
    //     0x1186024: ldur            w0, [x1, #7]
    // 0x1186028: DecompressPointer r0
    //     0x1186028: add             x0, x0, HEAP, lsl #32
    // 0x118602c: r1 = LoadClassIdInstr(r0)
    //     0x118602c: ldur            x1, [x0, #-1]
    //     0x1186030: ubfx            x1, x1, #0xc, #0x14
    // 0x1186034: mov             x16, x0
    // 0x1186038: mov             x0, x1
    // 0x118603c: mov             x1, x16
    // 0x1186040: r0 = GDT[cid_x0 + 0x2d19]()
    //     0x1186040: mov             x17, #0x2d19
    //     0x1186044: add             lr, x0, x17
    //     0x1186048: ldr             lr, [x21, lr, lsl #3]
    //     0x118604c: blr             lr
    // 0x1186050: LeaveFrame
    //     0x1186050: mov             SP, fp
    //     0x1186054: ldp             fp, lr, [SP], #0x10
    // 0x1186058: ret
    //     0x1186058: ret             
    // 0x118605c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x118605c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1186060: b               #0x1186024
  }
  _ computeLuminance(/* No info */) {
    // ** addr: 0x119e048, size: 0x54
    // 0x119e048: EnterFrame
    //     0x119e048: stp             fp, lr, [SP, #-0x10]!
    //     0x119e04c: mov             fp, SP
    // 0x119e050: CheckStackOverflow
    //     0x119e050: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x119e054: cmp             SP, x16
    //     0x119e058: b.ls            #0x119e094
    // 0x119e05c: LoadField: r0 = r1->field_7
    //     0x119e05c: ldur            w0, [x1, #7]
    // 0x119e060: DecompressPointer r0
    //     0x119e060: add             x0, x0, HEAP, lsl #32
    // 0x119e064: r1 = LoadClassIdInstr(r0)
    //     0x119e064: ldur            x1, [x0, #-1]
    //     0x119e068: ubfx            x1, x1, #0xc, #0x14
    // 0x119e06c: mov             x16, x0
    // 0x119e070: mov             x0, x1
    // 0x119e074: mov             x1, x16
    // 0x119e078: r0 = GDT[cid_x0 + 0x2763]()
    //     0x119e078: mov             x17, #0x2763
    //     0x119e07c: add             lr, x0, x17
    //     0x119e080: ldr             lr, [x21, lr, lsl #3]
    //     0x119e084: blr             lr
    // 0x119e088: LeaveFrame
    //     0x119e088: mov             SP, fp
    //     0x119e08c: ldp             fp, lr, [SP], #0x10
    // 0x119e090: ret
    //     0x119e090: ret             
    // 0x119e094: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x119e094: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x119e098: b               #0x119e05c
  }
  _ ==(/* No info */) {
    // ** addr: 0x12629d0, size: 0x27c
    // 0x12629d0: EnterFrame
    //     0x12629d0: stp             fp, lr, [SP, #-0x10]!
    //     0x12629d4: mov             fp, SP
    // 0x12629d8: AllocStack(0x18)
    //     0x12629d8: sub             SP, SP, #0x18
    // 0x12629dc: CheckStackOverflow
    //     0x12629dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12629e0: cmp             SP, x16
    //     0x12629e4: b.ls            #0x1262c44
    // 0x12629e8: ldr             x1, [fp, #0x10]
    // 0x12629ec: cmp             w1, NULL
    // 0x12629f0: b.ne            #0x1262a04
    // 0x12629f4: r0 = false
    //     0x12629f4: add             x0, NULL, #0x30  ; false
    // 0x12629f8: LeaveFrame
    //     0x12629f8: mov             SP, fp
    //     0x12629fc: ldp             fp, lr, [SP], #0x10
    // 0x1262a00: ret
    //     0x1262a00: ret             
    // 0x1262a04: ldr             x0, [fp, #0x18]
    // 0x1262a08: cmp             w0, w1
    // 0x1262a0c: b.ne            #0x1262a20
    // 0x1262a10: r0 = true
    //     0x1262a10: add             x0, NULL, #0x20  ; true
    // 0x1262a14: LeaveFrame
    //     0x1262a14: mov             SP, fp
    //     0x1262a18: ldp             fp, lr, [SP], #0x10
    // 0x1262a1c: ret
    //     0x1262a1c: ret             
    // 0x1262a20: str             x1, [SP]
    // 0x1262a24: r0 = runtimeType()
    //     0x1262a24: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x1262a28: r1 = LoadClassIdInstr(r0)
    //     0x1262a28: ldur            x1, [x0, #-1]
    //     0x1262a2c: ubfx            x1, x1, #0xc, #0x14
    // 0x1262a30: r16 = CupertinoDynamicColor
    //     0x1262a30: add             x16, PP, #0x26, lsl #12  ; [pp+0x26b58] Type: CupertinoDynamicColor
    //     0x1262a34: ldr             x16, [x16, #0xb58]
    // 0x1262a38: stp             x16, x0, [SP]
    // 0x1262a3c: mov             x0, x1
    // 0x1262a40: mov             lr, x0
    // 0x1262a44: ldr             lr, [x21, lr, lsl #3]
    // 0x1262a48: blr             lr
    // 0x1262a4c: tbz             w0, #4, #0x1262a60
    // 0x1262a50: r0 = false
    //     0x1262a50: add             x0, NULL, #0x30  ; false
    // 0x1262a54: LeaveFrame
    //     0x1262a54: mov             SP, fp
    //     0x1262a58: ldp             fp, lr, [SP], #0x10
    // 0x1262a5c: ret
    //     0x1262a5c: ret             
    // 0x1262a60: ldr             x0, [fp, #0x10]
    // 0x1262a64: r1 = 60
    //     0x1262a64: mov             x1, #0x3c
    // 0x1262a68: branchIfSmi(r0, 0x1262a74)
    //     0x1262a68: tbz             w0, #0, #0x1262a74
    // 0x1262a6c: r1 = LoadClassIdInstr(r0)
    //     0x1262a6c: ldur            x1, [x0, #-1]
    //     0x1262a70: ubfx            x1, x1, #0xc, #0x14
    // 0x1262a74: r17 = 5241
    //     0x1262a74: mov             x17, #0x1479
    // 0x1262a78: cmp             x1, x17
    // 0x1262a7c: b.ne            #0x1262c34
    // 0x1262a80: ldr             x2, [fp, #0x18]
    // 0x1262a84: mov             x1, x0
    // 0x1262a88: r0 = value()
    //     0x1262a88: bl              #0x12aaca0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::value
    // 0x1262a8c: mov             x3, x0
    // 0x1262a90: ldr             x2, [fp, #0x18]
    // 0x1262a94: stur            x3, [fp, #-8]
    // 0x1262a98: LoadField: r1 = r2->field_7
    //     0x1262a98: ldur            w1, [x2, #7]
    // 0x1262a9c: DecompressPointer r1
    //     0x1262a9c: add             x1, x1, HEAP, lsl #32
    // 0x1262aa0: r0 = LoadClassIdInstr(r1)
    //     0x1262aa0: ldur            x0, [x1, #-1]
    //     0x1262aa4: ubfx            x0, x0, #0xc, #0x14
    // 0x1262aa8: r0 = GDT[cid_x0 + -0xfb8]()
    //     0x1262aa8: sub             lr, x0, #0xfb8
    //     0x1262aac: ldr             lr, [x21, lr, lsl #3]
    //     0x1262ab0: blr             lr
    // 0x1262ab4: mov             x1, x0
    // 0x1262ab8: ldur            x0, [fp, #-8]
    // 0x1262abc: cmp             x0, x1
    // 0x1262ac0: b.ne            #0x1262c34
    // 0x1262ac4: ldr             x1, [fp, #0x18]
    // 0x1262ac8: ldr             x2, [fp, #0x10]
    // 0x1262acc: LoadField: r0 = r2->field_13
    //     0x1262acc: ldur            w0, [x2, #0x13]
    // 0x1262ad0: DecompressPointer r0
    //     0x1262ad0: add             x0, x0, HEAP, lsl #32
    // 0x1262ad4: LoadField: r3 = r1->field_13
    //     0x1262ad4: ldur            w3, [x1, #0x13]
    // 0x1262ad8: DecompressPointer r3
    //     0x1262ad8: add             x3, x3, HEAP, lsl #32
    // 0x1262adc: r4 = LoadClassIdInstr(r0)
    //     0x1262adc: ldur            x4, [x0, #-1]
    //     0x1262ae0: ubfx            x4, x4, #0xc, #0x14
    // 0x1262ae4: stp             x3, x0, [SP]
    // 0x1262ae8: mov             x0, x4
    // 0x1262aec: mov             lr, x0
    // 0x1262af0: ldr             lr, [x21, lr, lsl #3]
    // 0x1262af4: blr             lr
    // 0x1262af8: tbnz            w0, #4, #0x1262c34
    // 0x1262afc: ldr             x0, [fp, #0x18]
    // 0x1262b00: ldr             x1, [fp, #0x10]
    // 0x1262b04: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x1262b04: ldur            w2, [x1, #0x17]
    // 0x1262b08: DecompressPointer r2
    //     0x1262b08: add             x2, x2, HEAP, lsl #32
    // 0x1262b0c: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x1262b0c: ldur            w3, [x0, #0x17]
    // 0x1262b10: DecompressPointer r3
    //     0x1262b10: add             x3, x3, HEAP, lsl #32
    // 0x1262b14: stp             x3, x2, [SP]
    // 0x1262b18: r0 = ==()
    //     0x1262b18: bl              #0x128cb50  ; [dart:ui] Color::==
    // 0x1262b1c: tbnz            w0, #4, #0x1262c34
    // 0x1262b20: ldr             x1, [fp, #0x18]
    // 0x1262b24: ldr             x2, [fp, #0x10]
    // 0x1262b28: LoadField: r0 = r2->field_1b
    //     0x1262b28: ldur            w0, [x2, #0x1b]
    // 0x1262b2c: DecompressPointer r0
    //     0x1262b2c: add             x0, x0, HEAP, lsl #32
    // 0x1262b30: LoadField: r3 = r1->field_1b
    //     0x1262b30: ldur            w3, [x1, #0x1b]
    // 0x1262b34: DecompressPointer r3
    //     0x1262b34: add             x3, x3, HEAP, lsl #32
    // 0x1262b38: r4 = LoadClassIdInstr(r0)
    //     0x1262b38: ldur            x4, [x0, #-1]
    //     0x1262b3c: ubfx            x4, x4, #0xc, #0x14
    // 0x1262b40: stp             x3, x0, [SP]
    // 0x1262b44: mov             x0, x4
    // 0x1262b48: mov             lr, x0
    // 0x1262b4c: ldr             lr, [x21, lr, lsl #3]
    // 0x1262b50: blr             lr
    // 0x1262b54: tbnz            w0, #4, #0x1262c34
    // 0x1262b58: ldr             x0, [fp, #0x18]
    // 0x1262b5c: ldr             x1, [fp, #0x10]
    // 0x1262b60: LoadField: r2 = r1->field_1f
    //     0x1262b60: ldur            w2, [x1, #0x1f]
    // 0x1262b64: DecompressPointer r2
    //     0x1262b64: add             x2, x2, HEAP, lsl #32
    // 0x1262b68: LoadField: r3 = r0->field_1f
    //     0x1262b68: ldur            w3, [x0, #0x1f]
    // 0x1262b6c: DecompressPointer r3
    //     0x1262b6c: add             x3, x3, HEAP, lsl #32
    // 0x1262b70: stp             x3, x2, [SP]
    // 0x1262b74: r0 = ==()
    //     0x1262b74: bl              #0x128cb50  ; [dart:ui] Color::==
    // 0x1262b78: tbnz            w0, #4, #0x1262c34
    // 0x1262b7c: ldr             x1, [fp, #0x18]
    // 0x1262b80: ldr             x2, [fp, #0x10]
    // 0x1262b84: LoadField: r0 = r2->field_23
    //     0x1262b84: ldur            w0, [x2, #0x23]
    // 0x1262b88: DecompressPointer r0
    //     0x1262b88: add             x0, x0, HEAP, lsl #32
    // 0x1262b8c: LoadField: r3 = r1->field_23
    //     0x1262b8c: ldur            w3, [x1, #0x23]
    // 0x1262b90: DecompressPointer r3
    //     0x1262b90: add             x3, x3, HEAP, lsl #32
    // 0x1262b94: r4 = LoadClassIdInstr(r0)
    //     0x1262b94: ldur            x4, [x0, #-1]
    //     0x1262b98: ubfx            x4, x4, #0xc, #0x14
    // 0x1262b9c: stp             x3, x0, [SP]
    // 0x1262ba0: mov             x0, x4
    // 0x1262ba4: mov             lr, x0
    // 0x1262ba8: ldr             lr, [x21, lr, lsl #3]
    // 0x1262bac: blr             lr
    // 0x1262bb0: tbnz            w0, #4, #0x1262c34
    // 0x1262bb4: ldr             x0, [fp, #0x18]
    // 0x1262bb8: ldr             x1, [fp, #0x10]
    // 0x1262bbc: LoadField: r2 = r1->field_27
    //     0x1262bbc: ldur            w2, [x1, #0x27]
    // 0x1262bc0: DecompressPointer r2
    //     0x1262bc0: add             x2, x2, HEAP, lsl #32
    // 0x1262bc4: LoadField: r3 = r0->field_27
    //     0x1262bc4: ldur            w3, [x0, #0x27]
    // 0x1262bc8: DecompressPointer r3
    //     0x1262bc8: add             x3, x3, HEAP, lsl #32
    // 0x1262bcc: stp             x3, x2, [SP]
    // 0x1262bd0: r0 = ==()
    //     0x1262bd0: bl              #0x128cb50  ; [dart:ui] Color::==
    // 0x1262bd4: tbnz            w0, #4, #0x1262c34
    // 0x1262bd8: ldr             x1, [fp, #0x18]
    // 0x1262bdc: ldr             x2, [fp, #0x10]
    // 0x1262be0: LoadField: r0 = r2->field_2b
    //     0x1262be0: ldur            w0, [x2, #0x2b]
    // 0x1262be4: DecompressPointer r0
    //     0x1262be4: add             x0, x0, HEAP, lsl #32
    // 0x1262be8: LoadField: r3 = r1->field_2b
    //     0x1262be8: ldur            w3, [x1, #0x2b]
    // 0x1262bec: DecompressPointer r3
    //     0x1262bec: add             x3, x3, HEAP, lsl #32
    // 0x1262bf0: r4 = LoadClassIdInstr(r0)
    //     0x1262bf0: ldur            x4, [x0, #-1]
    //     0x1262bf4: ubfx            x4, x4, #0xc, #0x14
    // 0x1262bf8: stp             x3, x0, [SP]
    // 0x1262bfc: mov             x0, x4
    // 0x1262c00: mov             lr, x0
    // 0x1262c04: ldr             lr, [x21, lr, lsl #3]
    // 0x1262c08: blr             lr
    // 0x1262c0c: tbnz            w0, #4, #0x1262c34
    // 0x1262c10: ldr             x0, [fp, #0x18]
    // 0x1262c14: ldr             x1, [fp, #0x10]
    // 0x1262c18: LoadField: r2 = r1->field_2f
    //     0x1262c18: ldur            w2, [x1, #0x2f]
    // 0x1262c1c: DecompressPointer r2
    //     0x1262c1c: add             x2, x2, HEAP, lsl #32
    // 0x1262c20: LoadField: r1 = r0->field_2f
    //     0x1262c20: ldur            w1, [x0, #0x2f]
    // 0x1262c24: DecompressPointer r1
    //     0x1262c24: add             x1, x1, HEAP, lsl #32
    // 0x1262c28: stp             x1, x2, [SP]
    // 0x1262c2c: r0 = ==()
    //     0x1262c2c: bl              #0x128cb50  ; [dart:ui] Color::==
    // 0x1262c30: b               #0x1262c38
    // 0x1262c34: r0 = false
    //     0x1262c34: add             x0, NULL, #0x30  ; false
    // 0x1262c38: LeaveFrame
    //     0x1262c38: mov             SP, fp
    //     0x1262c3c: ldp             fp, lr, [SP], #0x10
    // 0x1262c40: ret
    //     0x1262c40: ret             
    // 0x1262c44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1262c44: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1262c48: b               #0x12629e8
  }
  get _ opacity(/* No info */) {
    // ** addr: 0x12aa348, size: 0x50
    // 0x12aa348: EnterFrame
    //     0x12aa348: stp             fp, lr, [SP, #-0x10]!
    //     0x12aa34c: mov             fp, SP
    // 0x12aa350: CheckStackOverflow
    //     0x12aa350: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12aa354: cmp             SP, x16
    //     0x12aa358: b.ls            #0x12aa390
    // 0x12aa35c: LoadField: r0 = r1->field_7
    //     0x12aa35c: ldur            w0, [x1, #7]
    // 0x12aa360: DecompressPointer r0
    //     0x12aa360: add             x0, x0, HEAP, lsl #32
    // 0x12aa364: r1 = LoadClassIdInstr(r0)
    //     0x12aa364: ldur            x1, [x0, #-1]
    //     0x12aa368: ubfx            x1, x1, #0xc, #0x14
    // 0x12aa36c: mov             x16, x0
    // 0x12aa370: mov             x0, x1
    // 0x12aa374: mov             x1, x16
    // 0x12aa378: r0 = GDT[cid_x0 + -0xfab]()
    //     0x12aa378: sub             lr, x0, #0xfab
    //     0x12aa37c: ldr             lr, [x21, lr, lsl #3]
    //     0x12aa380: blr             lr
    // 0x12aa384: LeaveFrame
    //     0x12aa384: mov             SP, fp
    //     0x12aa388: ldp             fp, lr, [SP], #0x10
    // 0x12aa38c: ret
    //     0x12aa38c: ret             
    // 0x12aa390: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12aa390: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12aa394: b               #0x12aa35c
  }
  get _ colorSpace(/* No info */) {
    // ** addr: 0x12aa60c, size: 0x50
    // 0x12aa60c: EnterFrame
    //     0x12aa60c: stp             fp, lr, [SP, #-0x10]!
    //     0x12aa610: mov             fp, SP
    // 0x12aa614: CheckStackOverflow
    //     0x12aa614: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12aa618: cmp             SP, x16
    //     0x12aa61c: b.ls            #0x12aa654
    // 0x12aa620: LoadField: r0 = r1->field_7
    //     0x12aa620: ldur            w0, [x1, #7]
    // 0x12aa624: DecompressPointer r0
    //     0x12aa624: add             x0, x0, HEAP, lsl #32
    // 0x12aa628: r1 = LoadClassIdInstr(r0)
    //     0x12aa628: ldur            x1, [x0, #-1]
    //     0x12aa62c: ubfx            x1, x1, #0xc, #0x14
    // 0x12aa630: mov             x16, x0
    // 0x12aa634: mov             x0, x1
    // 0x12aa638: mov             x1, x16
    // 0x12aa63c: r0 = GDT[cid_x0 + -0xfb2]()
    //     0x12aa63c: sub             lr, x0, #0xfb2
    //     0x12aa640: ldr             lr, [x21, lr, lsl #3]
    //     0x12aa644: blr             lr
    // 0x12aa648: LeaveFrame
    //     0x12aa648: mov             SP, fp
    //     0x12aa64c: ldp             fp, lr, [SP], #0x10
    // 0x12aa650: ret
    //     0x12aa650: ret             
    // 0x12aa654: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12aa654: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12aa658: b               #0x12aa620
  }
  int value(CupertinoDynamicColor) {
    // ** addr: 0x12aaca0, size: 0x50
    // 0x12aaca0: EnterFrame
    //     0x12aaca0: stp             fp, lr, [SP, #-0x10]!
    //     0x12aaca4: mov             fp, SP
    // 0x12aaca8: CheckStackOverflow
    //     0x12aaca8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12aacac: cmp             SP, x16
    //     0x12aacb0: b.ls            #0x12aace8
    // 0x12aacb4: LoadField: r0 = r1->field_7
    //     0x12aacb4: ldur            w0, [x1, #7]
    // 0x12aacb8: DecompressPointer r0
    //     0x12aacb8: add             x0, x0, HEAP, lsl #32
    // 0x12aacbc: r1 = LoadClassIdInstr(r0)
    //     0x12aacbc: ldur            x1, [x0, #-1]
    //     0x12aacc0: ubfx            x1, x1, #0xc, #0x14
    // 0x12aacc4: mov             x16, x0
    // 0x12aacc8: mov             x0, x1
    // 0x12aaccc: mov             x1, x16
    // 0x12aacd0: r0 = GDT[cid_x0 + -0xfb8]()
    //     0x12aacd0: sub             lr, x0, #0xfb8
    //     0x12aacd4: ldr             lr, [x21, lr, lsl #3]
    //     0x12aacd8: blr             lr
    // 0x12aacdc: LeaveFrame
    //     0x12aacdc: mov             SP, fp
    //     0x12aace0: ldp             fp, lr, [SP], #0x10
    // 0x12aace4: ret
    //     0x12aace4: ret             
    // 0x12aace8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12aace8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12aacec: b               #0x12aacb4
  }
  int alpha(CupertinoDynamicColor) {
    // ** addr: 0x12abe3c, size: 0x50
    // 0x12abe3c: EnterFrame
    //     0x12abe3c: stp             fp, lr, [SP, #-0x10]!
    //     0x12abe40: mov             fp, SP
    // 0x12abe44: CheckStackOverflow
    //     0x12abe44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12abe48: cmp             SP, x16
    //     0x12abe4c: b.ls            #0x12abe84
    // 0x12abe50: LoadField: r0 = r1->field_7
    //     0x12abe50: ldur            w0, [x1, #7]
    // 0x12abe54: DecompressPointer r0
    //     0x12abe54: add             x0, x0, HEAP, lsl #32
    // 0x12abe58: r1 = LoadClassIdInstr(r0)
    //     0x12abe58: ldur            x1, [x0, #-1]
    //     0x12abe5c: ubfx            x1, x1, #0xc, #0x14
    // 0x12abe60: mov             x16, x0
    // 0x12abe64: mov             x0, x1
    // 0x12abe68: mov             x1, x16
    // 0x12abe6c: r0 = GDT[cid_x0 + -0xfc0]()
    //     0x12abe6c: sub             lr, x0, #0xfc0
    //     0x12abe70: ldr             lr, [x21, lr, lsl #3]
    //     0x12abe74: blr             lr
    // 0x12abe78: LeaveFrame
    //     0x12abe78: mov             SP, fp
    //     0x12abe7c: ldp             fp, lr, [SP], #0x10
    // 0x12abe80: ret
    //     0x12abe80: ret             
    // 0x12abe84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12abe84: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12abe88: b               #0x12abe50
  }
  get _ g(/* No info */) {
    // ** addr: 0x12ac040, size: 0x50
    // 0x12ac040: EnterFrame
    //     0x12ac040: stp             fp, lr, [SP, #-0x10]!
    //     0x12ac044: mov             fp, SP
    // 0x12ac048: CheckStackOverflow
    //     0x12ac048: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12ac04c: cmp             SP, x16
    //     0x12ac050: b.ls            #0x12ac088
    // 0x12ac054: LoadField: r0 = r1->field_7
    //     0x12ac054: ldur            w0, [x1, #7]
    // 0x12ac058: DecompressPointer r0
    //     0x12ac058: add             x0, x0, HEAP, lsl #32
    // 0x12ac05c: r1 = LoadClassIdInstr(r0)
    //     0x12ac05c: ldur            x1, [x0, #-1]
    //     0x12ac060: ubfx            x1, x1, #0xc, #0x14
    // 0x12ac064: mov             x16, x0
    // 0x12ac068: mov             x0, x1
    // 0x12ac06c: mov             x1, x16
    // 0x12ac070: r0 = GDT[cid_x0 + -0xfc7]()
    //     0x12ac070: sub             lr, x0, #0xfc7
    //     0x12ac074: ldr             lr, [x21, lr, lsl #3]
    //     0x12ac078: blr             lr
    // 0x12ac07c: LeaveFrame
    //     0x12ac07c: mov             SP, fp
    //     0x12ac080: ldp             fp, lr, [SP], #0x10
    // 0x12ac084: ret
    //     0x12ac084: ret             
    // 0x12ac088: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12ac088: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12ac08c: b               #0x12ac054
  }
  get _ r(/* No info */) {
    // ** addr: 0x12ac090, size: 0x50
    // 0x12ac090: EnterFrame
    //     0x12ac090: stp             fp, lr, [SP, #-0x10]!
    //     0x12ac094: mov             fp, SP
    // 0x12ac098: CheckStackOverflow
    //     0x12ac098: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12ac09c: cmp             SP, x16
    //     0x12ac0a0: b.ls            #0x12ac0d8
    // 0x12ac0a4: LoadField: r0 = r1->field_7
    //     0x12ac0a4: ldur            w0, [x1, #7]
    // 0x12ac0a8: DecompressPointer r0
    //     0x12ac0a8: add             x0, x0, HEAP, lsl #32
    // 0x12ac0ac: r1 = LoadClassIdInstr(r0)
    //     0x12ac0ac: ldur            x1, [x0, #-1]
    //     0x12ac0b0: ubfx            x1, x1, #0xc, #0x14
    // 0x12ac0b4: mov             x16, x0
    // 0x12ac0b8: mov             x0, x1
    // 0x12ac0bc: mov             x1, x16
    // 0x12ac0c0: r0 = GDT[cid_x0 + -0xfd0]()
    //     0x12ac0c0: sub             lr, x0, #0xfd0
    //     0x12ac0c4: ldr             lr, [x21, lr, lsl #3]
    //     0x12ac0c8: blr             lr
    // 0x12ac0cc: LeaveFrame
    //     0x12ac0cc: mov             SP, fp
    //     0x12ac0d0: ldp             fp, lr, [SP], #0x10
    // 0x12ac0d4: ret
    //     0x12ac0d4: ret             
    // 0x12ac0d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12ac0d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12ac0dc: b               #0x12ac0a4
  }
  get _ b(/* No info */) {
    // ** addr: 0x12ac180, size: 0x50
    // 0x12ac180: EnterFrame
    //     0x12ac180: stp             fp, lr, [SP, #-0x10]!
    //     0x12ac184: mov             fp, SP
    // 0x12ac188: CheckStackOverflow
    //     0x12ac188: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12ac18c: cmp             SP, x16
    //     0x12ac190: b.ls            #0x12ac1c8
    // 0x12ac194: LoadField: r0 = r1->field_7
    //     0x12ac194: ldur            w0, [x1, #7]
    // 0x12ac198: DecompressPointer r0
    //     0x12ac198: add             x0, x0, HEAP, lsl #32
    // 0x12ac19c: r1 = LoadClassIdInstr(r0)
    //     0x12ac19c: ldur            x1, [x0, #-1]
    //     0x12ac1a0: ubfx            x1, x1, #0xc, #0x14
    // 0x12ac1a4: mov             x16, x0
    // 0x12ac1a8: mov             x0, x1
    // 0x12ac1ac: mov             x1, x16
    // 0x12ac1b0: r0 = GDT[cid_x0 + -0xfd7]()
    //     0x12ac1b0: sub             lr, x0, #0xfd7
    //     0x12ac1b4: ldr             lr, [x21, lr, lsl #3]
    //     0x12ac1b8: blr             lr
    // 0x12ac1bc: LeaveFrame
    //     0x12ac1bc: mov             SP, fp
    //     0x12ac1c0: ldp             fp, lr, [SP], #0x10
    // 0x12ac1c4: ret
    //     0x12ac1c4: ret             
    // 0x12ac1c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12ac1c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12ac1cc: b               #0x12ac194
  }
  get _ a(/* No info */) {
    // ** addr: 0x12ac1d0, size: 0x50
    // 0x12ac1d0: EnterFrame
    //     0x12ac1d0: stp             fp, lr, [SP, #-0x10]!
    //     0x12ac1d4: mov             fp, SP
    // 0x12ac1d8: CheckStackOverflow
    //     0x12ac1d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12ac1dc: cmp             SP, x16
    //     0x12ac1e0: b.ls            #0x12ac218
    // 0x12ac1e4: LoadField: r0 = r1->field_7
    //     0x12ac1e4: ldur            w0, [x1, #7]
    // 0x12ac1e8: DecompressPointer r0
    //     0x12ac1e8: add             x0, x0, HEAP, lsl #32
    // 0x12ac1ec: r1 = LoadClassIdInstr(r0)
    //     0x12ac1ec: ldur            x1, [x0, #-1]
    //     0x12ac1f0: ubfx            x1, x1, #0xc, #0x14
    // 0x12ac1f4: mov             x16, x0
    // 0x12ac1f8: mov             x0, x1
    // 0x12ac1fc: mov             x1, x16
    // 0x12ac200: r0 = GDT[cid_x0 + -0xfe4]()
    //     0x12ac200: sub             lr, x0, #0xfe4
    //     0x12ac204: ldr             lr, [x21, lr, lsl #3]
    //     0x12ac208: blr             lr
    // 0x12ac20c: LeaveFrame
    //     0x12ac20c: mov             SP, fp
    //     0x12ac210: ldp             fp, lr, [SP], #0x10
    // 0x12ac214: ret
    //     0x12ac214: ret             
    // 0x12ac218: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12ac218: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12ac21c: b               #0x12ac1e4
  }
  _ withAlpha(/* No info */) {
    // ** addr: 0x12ac394, size: 0x50
    // 0x12ac394: EnterFrame
    //     0x12ac394: stp             fp, lr, [SP, #-0x10]!
    //     0x12ac398: mov             fp, SP
    // 0x12ac39c: CheckStackOverflow
    //     0x12ac39c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12ac3a0: cmp             SP, x16
    //     0x12ac3a4: b.ls            #0x12ac3dc
    // 0x12ac3a8: LoadField: r0 = r1->field_7
    //     0x12ac3a8: ldur            w0, [x1, #7]
    // 0x12ac3ac: DecompressPointer r0
    //     0x12ac3ac: add             x0, x0, HEAP, lsl #32
    // 0x12ac3b0: r1 = LoadClassIdInstr(r0)
    //     0x12ac3b0: ldur            x1, [x0, #-1]
    //     0x12ac3b4: ubfx            x1, x1, #0xc, #0x14
    // 0x12ac3b8: mov             x16, x0
    // 0x12ac3bc: mov             x0, x1
    // 0x12ac3c0: mov             x1, x16
    // 0x12ac3c4: r0 = GDT[cid_x0 + -0xff4]()
    //     0x12ac3c4: sub             lr, x0, #0xff4
    //     0x12ac3c8: ldr             lr, [x21, lr, lsl #3]
    //     0x12ac3cc: blr             lr
    // 0x12ac3d0: LeaveFrame
    //     0x12ac3d0: mov             SP, fp
    //     0x12ac3d4: ldp             fp, lr, [SP], #0x10
    // 0x12ac3d8: ret
    //     0x12ac3d8: ret             
    // 0x12ac3dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12ac3dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12ac3e0: b               #0x12ac3a8
  }
  _ withValues(/* No info */) {
    // ** addr: 0x12ac478, size: 0xec
    // 0x12ac478: EnterFrame
    //     0x12ac478: stp             fp, lr, [SP, #-0x10]!
    //     0x12ac47c: mov             fp, SP
    // 0x12ac480: AllocStack(0x10)
    //     0x12ac480: sub             SP, SP, #0x10
    // 0x12ac484: SetupParameters({dynamic alpha = Null /* r3 */, dynamic colorSpace = Null /* r0 */})
    //     0x12ac484: ldur            w0, [x4, #0x13]
    //     0x12ac488: ldur            w2, [x4, #0x1f]
    //     0x12ac48c: add             x2, x2, HEAP, lsl #32
    //     0x12ac490: add             x16, PP, #0x28, lsl #12  ; [pp+0x286b0] "alpha"
    //     0x12ac494: ldr             x16, [x16, #0x6b0]
    //     0x12ac498: cmp             w2, w16
    //     0x12ac49c: b.ne            #0x12ac4c0
    //     0x12ac4a0: ldur            w2, [x4, #0x23]
    //     0x12ac4a4: add             x2, x2, HEAP, lsl #32
    //     0x12ac4a8: sub             w3, w0, w2
    //     0x12ac4ac: add             x2, fp, w3, sxtw #2
    //     0x12ac4b0: ldr             x2, [x2, #8]
    //     0x12ac4b4: mov             x3, x2
    //     0x12ac4b8: mov             x2, #1
    //     0x12ac4bc: b               #0x12ac4c8
    //     0x12ac4c0: mov             x3, NULL
    //     0x12ac4c4: mov             x2, #0
    //     0x12ac4c8: lsl             x5, x2, #1
    //     0x12ac4cc: lsl             w2, w5, #1
    //     0x12ac4d0: add             w5, w2, #8
    //     0x12ac4d4: add             x16, x4, w5, sxtw #1
    //     0x12ac4d8: ldur            w6, [x16, #0xf]
    //     0x12ac4dc: add             x6, x6, HEAP, lsl #32
    //     0x12ac4e0: add             x16, PP, #0x28, lsl #12  ; [pp+0x286b8] "colorSpace"
    //     0x12ac4e4: ldr             x16, [x16, #0x6b8]
    //     0x12ac4e8: cmp             w6, w16
    //     0x12ac4ec: b.ne            #0x12ac510
    //     0x12ac4f0: add             w5, w2, #0xa
    //     0x12ac4f4: add             x16, x4, w5, sxtw #1
    //     0x12ac4f8: ldur            w2, [x16, #0xf]
    //     0x12ac4fc: add             x2, x2, HEAP, lsl #32
    //     0x12ac500: sub             w4, w0, w2
    //     0x12ac504: add             x0, fp, w4, sxtw #2
    //     0x12ac508: ldr             x0, [x0, #8]
    //     0x12ac50c: b               #0x12ac514
    //     0x12ac510: mov             x0, NULL
    // 0x12ac514: CheckStackOverflow
    //     0x12ac514: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12ac518: cmp             SP, x16
    //     0x12ac51c: b.ls            #0x12ac55c
    // 0x12ac520: LoadField: r2 = r1->field_7
    //     0x12ac520: ldur            w2, [x1, #7]
    // 0x12ac524: DecompressPointer r2
    //     0x12ac524: add             x2, x2, HEAP, lsl #32
    // 0x12ac528: r1 = LoadClassIdInstr(r2)
    //     0x12ac528: ldur            x1, [x2, #-1]
    //     0x12ac52c: ubfx            x1, x1, #0xc, #0x14
    // 0x12ac530: stp             x0, x3, [SP]
    // 0x12ac534: mov             x0, x1
    // 0x12ac538: mov             x1, x2
    // 0x12ac53c: r4 = const [0, 0x3, 0x2, 0x1, alpha, 0x1, colorSpace, 0x2, null]
    //     0x12ac53c: add             x4, PP, #0x8c, lsl #12  ; [pp+0x8cb30] List(9) [0, 0x3, 0x2, 0x1, "alpha", 0x1, "colorSpace", 0x2, Null]
    //     0x12ac540: ldr             x4, [x4, #0xb30]
    // 0x12ac544: r0 = GDT[cid_x0 + -0xffa]()
    //     0x12ac544: sub             lr, x0, #0xffa
    //     0x12ac548: ldr             lr, [x21, lr, lsl #3]
    //     0x12ac54c: blr             lr
    // 0x12ac550: LeaveFrame
    //     0x12ac550: mov             SP, fp
    //     0x12ac554: ldp             fp, lr, [SP], #0x10
    // 0x12ac558: ret
    //     0x12ac558: ret             
    // 0x12ac55c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12ac55c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12ac560: b               #0x12ac520
  }
  _ withOpacity(/* No info */) {
    // ** addr: 0x12ac564, size: 0x50
    // 0x12ac564: EnterFrame
    //     0x12ac564: stp             fp, lr, [SP, #-0x10]!
    //     0x12ac568: mov             fp, SP
    // 0x12ac56c: CheckStackOverflow
    //     0x12ac56c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12ac570: cmp             SP, x16
    //     0x12ac574: b.ls            #0x12ac5ac
    // 0x12ac578: LoadField: r0 = r1->field_7
    //     0x12ac578: ldur            w0, [x1, #7]
    // 0x12ac57c: DecompressPointer r0
    //     0x12ac57c: add             x0, x0, HEAP, lsl #32
    // 0x12ac580: r1 = LoadClassIdInstr(r0)
    //     0x12ac580: ldur            x1, [x0, #-1]
    //     0x12ac584: ubfx            x1, x1, #0xc, #0x14
    // 0x12ac588: mov             x16, x0
    // 0x12ac58c: mov             x0, x1
    // 0x12ac590: mov             x1, x16
    // 0x12ac594: r0 = GDT[cid_x0 + -0x1000]()
    //     0x12ac594: sub             lr, x0, #1, lsl #12
    //     0x12ac598: ldr             lr, [x21, lr, lsl #3]
    //     0x12ac59c: blr             lr
    // 0x12ac5a0: LeaveFrame
    //     0x12ac5a0: mov             SP, fp
    //     0x12ac5a4: ldp             fp, lr, [SP], #0x10
    // 0x12ac5a8: ret
    //     0x12ac5a8: ret             
    // 0x12ac5ac: r0 = StackOverflowSharedWithFPURegs()
    //     0x12ac5ac: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12ac5b0: b               #0x12ac578
  }
}
