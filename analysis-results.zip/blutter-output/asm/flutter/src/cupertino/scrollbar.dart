// lib: , url: package:flutter/src/cupertino/scrollbar.dart

// class id: 1048784, size: 0x8
class :: {
}

// class id: 5706, size: 0x64, field offset: 0x58
class _CupertinoScrollbarState extends RawScrollbarState<dynamic> {

  late AnimationController _thicknessAnimationController; // offset: 0x58

  [closure] void handleTrackTapDown(dynamic, TapDownDetails) {
    // ** addr: 0xd37d24, size: 0x3c
    // 0xd37d24: EnterFrame
    //     0xd37d24: stp             fp, lr, [SP, #-0x10]!
    //     0xd37d28: mov             fp, SP
    // 0xd37d2c: ldr             x0, [fp, #0x18]
    // 0xd37d30: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd37d30: ldur            w1, [x0, #0x17]
    // 0xd37d34: DecompressPointer r1
    //     0xd37d34: add             x1, x1, HEAP, lsl #32
    // 0xd37d38: CheckStackOverflow
    //     0xd37d38: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd37d3c: cmp             SP, x16
    //     0xd37d40: b.ls            #0xd37d58
    // 0xd37d44: ldr             x2, [fp, #0x10]
    // 0xd37d48: r0 = handleTrackTapDown()
    //     0xd37d48: bl              #0xd37d60  ; [package:flutter/src/cupertino/scrollbar.dart] _CupertinoScrollbarState::handleTrackTapDown
    // 0xd37d4c: LeaveFrame
    //     0xd37d4c: mov             SP, fp
    //     0xd37d50: ldp             fp, lr, [SP], #0x10
    // 0xd37d54: ret
    //     0xd37d54: ret             
    // 0xd37d58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd37d58: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd37d5c: b               #0xd37d44
  }
  _ handleTrackTapDown(/* No info */) {
    // ** addr: 0xd37d60, size: 0x98
    // 0xd37d60: EnterFrame
    //     0xd37d60: stp             fp, lr, [SP, #-0x10]!
    //     0xd37d64: mov             fp, SP
    // 0xd37d68: AllocStack(0x10)
    //     0xd37d68: sub             SP, SP, #0x10
    // 0xd37d6c: SetupParameters(_CupertinoScrollbarState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xd37d6c: mov             x0, x1
    //     0xd37d70: stur            x1, [fp, #-8]
    //     0xd37d74: stur            x2, [fp, #-0x10]
    // 0xd37d78: CheckStackOverflow
    //     0xd37d78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd37d7c: cmp             SP, x16
    //     0xd37d80: b.ls            #0xd37de8
    // 0xd37d84: LoadField: r1 = r0->field_f
    //     0xd37d84: ldur            w1, [x0, #0xf]
    // 0xd37d88: DecompressPointer r1
    //     0xd37d88: add             x1, x1, HEAP, lsl #32
    // 0xd37d8c: cmp             w1, NULL
    // 0xd37d90: b.eq            #0xd37df0
    // 0xd37d94: r0 = of()
    //     0xd37d94: bl              #0xd3827c  ; [package:flutter/src/widgets/scroll_configuration.dart] ScrollConfiguration::of
    // 0xd37d98: ldur            x3, [fp, #-8]
    // 0xd37d9c: LoadField: r2 = r3->field_f
    //     0xd37d9c: ldur            w2, [x3, #0xf]
    // 0xd37da0: DecompressPointer r2
    //     0xd37da0: add             x2, x2, HEAP, lsl #32
    // 0xd37da4: cmp             w2, NULL
    // 0xd37da8: b.eq            #0xd37df4
    // 0xd37dac: r1 = LoadClassIdInstr(r0)
    //     0xd37dac: ldur            x1, [x0, #-1]
    //     0xd37db0: ubfx            x1, x1, #0xc, #0x14
    // 0xd37db4: mov             x16, x0
    // 0xd37db8: mov             x0, x1
    // 0xd37dbc: mov             x1, x16
    // 0xd37dc0: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd37dc0: sub             lr, x0, #1, lsl #12
    //     0xd37dc4: ldr             lr, [x21, lr, lsl #3]
    //     0xd37dc8: blr             lr
    // 0xd37dcc: ldur            x1, [fp, #-8]
    // 0xd37dd0: ldur            x2, [fp, #-0x10]
    // 0xd37dd4: r0 = handleTrackTapDown()
    //     0xd37dd4: bl              #0xd37df8  ; [package:flutter/src/widgets/scrollbar.dart] RawScrollbarState::handleTrackTapDown
    // 0xd37dd8: r0 = Null
    //     0xd37dd8: mov             x0, NULL
    // 0xd37ddc: LeaveFrame
    //     0xd37ddc: mov             SP, fp
    //     0xd37de0: ldp             fp, lr, [SP], #0x10
    // 0xd37de4: ret
    //     0xd37de4: ret             
    // 0xd37de8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd37de8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd37dec: b               #0xd37d84
    // 0xd37df0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd37df0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd37df4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd37df4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> <anonymous closure>(dynamic, void) {
    // ** addr: 0xd3996c, size: 0x2c
    // 0xd3996c: EnterFrame
    //     0xd3996c: stp             fp, lr, [SP, #-0x10]!
    //     0xd39970: mov             fp, SP
    // 0xd39974: CheckStackOverflow
    //     0xd39974: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd39978: cmp             SP, x16
    //     0xd3997c: b.ls            #0xd39990
    // 0xd39980: r0 = mediumImpact()
    //     0xd39980: bl              #0xd39998  ; [package:flutter/src/services/haptic_feedback.dart] HapticFeedback::mediumImpact
    // 0xd39984: LeaveFrame
    //     0xd39984: mov             SP, fp
    //     0xd39988: ldp             fp, lr, [SP], #0x10
    // 0xd3998c: ret
    //     0xd3998c: ret             
    // 0xd39990: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd39990: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd39994: b               #0xd39980
  }
  _ initState(/* No info */) {
    // ** addr: 0xf7b7e0, size: 0xbc
    // 0xf7b7e0: EnterFrame
    //     0xf7b7e0: stp             fp, lr, [SP, #-0x10]!
    //     0xf7b7e4: mov             fp, SP
    // 0xf7b7e8: AllocStack(0x20)
    //     0xf7b7e8: sub             SP, SP, #0x20
    // 0xf7b7ec: SetupParameters(_CupertinoScrollbarState this /* r1 => r1, fp-0x8 */)
    //     0xf7b7ec: stur            x1, [fp, #-8]
    // 0xf7b7f0: CheckStackOverflow
    //     0xf7b7f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf7b7f4: cmp             SP, x16
    //     0xf7b7f8: b.ls            #0xf7b894
    // 0xf7b7fc: r1 = 1
    //     0xf7b7fc: mov             x1, #1
    // 0xf7b800: r0 = AllocateContext()
    //     0xf7b800: bl              #0x13de838  ; AllocateContextStub
    // 0xf7b804: mov             x2, x0
    // 0xf7b808: ldur            x0, [fp, #-8]
    // 0xf7b80c: stur            x2, [fp, #-0x10]
    // 0xf7b810: StoreField: r2->field_f = r0
    //     0xf7b810: stur            w0, [x2, #0xf]
    // 0xf7b814: mov             x1, x0
    // 0xf7b818: r0 = initState()
    //     0xf7b818: bl              #0xf7b9ec  ; [package:flutter/src/widgets/scrollbar.dart] RawScrollbarState::initState
    // 0xf7b81c: r1 = <double>
    //     0xf7b81c: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf7b820: r0 = AnimationController()
    //     0xf7b820: bl              #0x87522c  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0xf7b824: stur            x0, [fp, #-0x18]
    // 0xf7b828: r16 = Instance_Duration
    //     0xf7b828: ldr             x16, [PP, #0x5668]  ; [pp+0x5668] Obj!Duration@12c8941
    // 0xf7b82c: str             x16, [SP]
    // 0xf7b830: mov             x1, x0
    // 0xf7b834: ldur            x2, [fp, #-8]
    // 0xf7b838: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0xf7b838: add             x4, PP, #0x15, lsl #12  ; [pp+0x155a0] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0xf7b83c: ldr             x4, [x4, #0x5a0]
    // 0xf7b840: r0 = AnimationController()
    //     0xf7b840: bl              #0x874ea4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0xf7b844: ldur            x0, [fp, #-0x18]
    // 0xf7b848: ldur            x1, [fp, #-8]
    // 0xf7b84c: StoreField: r1->field_57 = r0
    //     0xf7b84c: stur            w0, [x1, #0x57]
    //     0xf7b850: ldurb           w16, [x1, #-1]
    //     0xf7b854: ldurb           w17, [x0, #-1]
    //     0xf7b858: and             x16, x17, x16, lsr #2
    //     0xf7b85c: tst             x16, HEAP, lsr #32
    //     0xf7b860: b.eq            #0xf7b868
    //     0xf7b864: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf7b868: ldur            x2, [fp, #-0x10]
    // 0xf7b86c: r1 = Function '<anonymous closure>':.
    //     0xf7b86c: add             x1, PP, #0xd1, lsl #12  ; [pp+0xd1a10] AnonymousClosure: (0xf7b89c), in [package:flutter/src/cupertino/scrollbar.dart] _CupertinoScrollbarState::initState (0xf7b7e0)
    //     0xf7b870: ldr             x1, [x1, #0xa10]
    // 0xf7b874: r0 = AllocateClosure()
    //     0xf7b874: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf7b878: ldur            x1, [fp, #-0x18]
    // 0xf7b87c: mov             x2, x0
    // 0xf7b880: r0 = addListener()
    //     0xf7b880: bl              #0xd0440c  ; [dart:mixin_deduplication] _MixinApplication455&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::addListener
    // 0xf7b884: r0 = Null
    //     0xf7b884: mov             x0, NULL
    // 0xf7b888: LeaveFrame
    //     0xf7b888: mov             SP, fp
    //     0xf7b88c: ldp             fp, lr, [SP], #0x10
    // 0xf7b890: ret
    //     0xf7b890: ret             
    // 0xf7b894: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf7b894: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf7b898: b               #0xf7b7fc
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xf7b89c, size: 0x48
    // 0xf7b89c: EnterFrame
    //     0xf7b89c: stp             fp, lr, [SP, #-0x10]!
    //     0xf7b8a0: mov             fp, SP
    // 0xf7b8a4: ldr             x0, [fp, #0x10]
    // 0xf7b8a8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf7b8a8: ldur            w1, [x0, #0x17]
    // 0xf7b8ac: DecompressPointer r1
    //     0xf7b8ac: add             x1, x1, HEAP, lsl #32
    // 0xf7b8b0: CheckStackOverflow
    //     0xf7b8b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf7b8b4: cmp             SP, x16
    //     0xf7b8b8: b.ls            #0xf7b8dc
    // 0xf7b8bc: LoadField: r0 = r1->field_f
    //     0xf7b8bc: ldur            w0, [x1, #0xf]
    // 0xf7b8c0: DecompressPointer r0
    //     0xf7b8c0: add             x0, x0, HEAP, lsl #32
    // 0xf7b8c4: mov             x1, x0
    // 0xf7b8c8: r0 = updateScrollbarPainter()
    //     0xf7b8c8: bl              #0x1230010  ; [package:flutter/src/cupertino/scrollbar.dart] _CupertinoScrollbarState::updateScrollbarPainter
    // 0xf7b8cc: r0 = Null
    //     0xf7b8cc: mov             x0, NULL
    // 0xf7b8d0: LeaveFrame
    //     0xf7b8d0: mov             SP, fp
    //     0xf7b8d4: ldp             fp, lr, [SP], #0x10
    // 0xf7b8d8: ret
    //     0xf7b8d8: ret             
    // 0xf7b8dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf7b8dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf7b8e0: b               #0xf7b8bc
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10ddd78, size: 0x64
    // 0x10ddd78: EnterFrame
    //     0x10ddd78: stp             fp, lr, [SP, #-0x10]!
    //     0x10ddd7c: mov             fp, SP
    // 0x10ddd80: AllocStack(0x8)
    //     0x10ddd80: sub             SP, SP, #8
    // 0x10ddd84: SetupParameters(_CupertinoScrollbarState this /* r1 => r0, fp-0x8 */)
    //     0x10ddd84: mov             x0, x1
    //     0x10ddd88: stur            x1, [fp, #-8]
    // 0x10ddd8c: CheckStackOverflow
    //     0x10ddd8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10ddd90: cmp             SP, x16
    //     0x10ddd94: b.ls            #0x10dddc8
    // 0x10ddd98: LoadField: r1 = r0->field_57
    //     0x10ddd98: ldur            w1, [x0, #0x57]
    // 0x10ddd9c: DecompressPointer r1
    //     0x10ddd9c: add             x1, x1, HEAP, lsl #32
    // 0x10ddda0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10ddda4: cmp             w1, w16
    // 0x10ddda8: b.eq            #0x10dddd0
    // 0x10dddac: r0 = dispose()
    //     0x10dddac: bl              #0x9164f4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x10dddb0: ldur            x1, [fp, #-8]
    // 0x10dddb4: r0 = dispose()
    //     0x10dddb4: bl              #0x10dde40  ; [package:flutter/src/widgets/scrollbar.dart] RawScrollbarState::dispose
    // 0x10dddb8: r0 = Null
    //     0x10dddb8: mov             x0, NULL
    // 0x10dddbc: LeaveFrame
    //     0x10dddbc: mov             SP, fp
    //     0x10dddc0: ldp             fp, lr, [SP], #0x10
    // 0x10dddc4: ret
    //     0x10dddc4: ret             
    // 0x10dddc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10dddc8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10dddcc: b               #0x10ddd98
    // 0x10dddd0: r9 = _thicknessAnimationController
    //     0x10dddd0: add             x9, PP, #0xad, lsl #12  ; [pp+0xada40] Field <_CupertinoScrollbarState@707305104._thicknessAnimationController@707305104>: late (offset: 0x58)
    //     0x10dddd4: ldr             x9, [x9, #0xa40]
    // 0x10dddd8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x10dddd8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ updateScrollbarPainter(/* No info */) {
    // ** addr: 0x1230010, size: 0x1d0
    // 0x1230010: EnterFrame
    //     0x1230010: stp             fp, lr, [SP, #-0x10]!
    //     0x1230014: mov             fp, SP
    // 0x1230018: AllocStack(0x10)
    //     0x1230018: sub             SP, SP, #0x10
    // 0x123001c: SetupParameters(_CupertinoScrollbarState this /* r1 => r0, fp-0x10 */)
    //     0x123001c: mov             x0, x1
    //     0x1230020: stur            x1, [fp, #-0x10]
    // 0x1230024: CheckStackOverflow
    //     0x1230024: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1230028: cmp             SP, x16
    //     0x123002c: b.ls            #0x12301b8
    // 0x1230030: LoadField: r3 = r0->field_53
    //     0x1230030: ldur            w3, [x0, #0x53]
    // 0x1230034: DecompressPointer r3
    //     0x1230034: add             x3, x3, HEAP, lsl #32
    // 0x1230038: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x123003c: cmp             w3, w16
    // 0x1230040: b.eq            #0x12301c0
    // 0x1230044: stur            x3, [fp, #-8]
    // 0x1230048: LoadField: r2 = r0->field_f
    //     0x1230048: ldur            w2, [x0, #0xf]
    // 0x123004c: DecompressPointer r2
    //     0x123004c: add             x2, x2, HEAP, lsl #32
    // 0x1230050: cmp             w2, NULL
    // 0x1230054: b.eq            #0x12301cc
    // 0x1230058: r1 = Instance_CupertinoDynamicColor
    //     0x1230058: add             x1, PP, #0xd1, lsl #12  ; [pp+0xd1a08] Obj!CupertinoDynamicColor@12b3f31
    //     0x123005c: ldr             x1, [x1, #0xa08]
    // 0x1230060: r0 = resolveFrom()
    //     0x1230060: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0x1230064: ldur            x1, [fp, #-8]
    // 0x1230068: mov             x2, x0
    // 0x123006c: r0 = color=()
    //     0x123006c: bl              #0x1230674  ; [package:flutter/src/widgets/scrollbar.dart] ScrollbarPainter::color=
    // 0x1230070: ldur            x0, [fp, #-0x10]
    // 0x1230074: LoadField: r1 = r0->field_f
    //     0x1230074: ldur            w1, [x0, #0xf]
    // 0x1230078: DecompressPointer r1
    //     0x1230078: add             x1, x1, HEAP, lsl #32
    // 0x123007c: cmp             w1, NULL
    // 0x1230080: b.eq            #0x12301d0
    // 0x1230084: r0 = of()
    //     0x1230084: bl              #0x87371c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0x1230088: ldur            x1, [fp, #-8]
    // 0x123008c: mov             x2, x0
    // 0x1230090: r0 = textDirection=()
    //     0x1230090: bl              #0x12305e0  ; [package:flutter/src/widgets/scrollbar.dart] ScrollbarPainter::textDirection=
    // 0x1230094: ldur            x1, [fp, #-0x10]
    // 0x1230098: r0 = _thickness()
    //     0x1230098: bl              #0x1230550  ; [package:flutter/src/cupertino/scrollbar.dart] _CupertinoScrollbarState::_thickness
    // 0x123009c: ldur            x0, [fp, #-8]
    // 0x12300a0: LoadField: d1 = r0->field_37
    //     0x12300a0: ldur            d1, [x0, #0x37]
    // 0x12300a4: fcmp            d1, d0
    // 0x12300a8: b.eq            #0x12300bc
    // 0x12300ac: StoreField: r0->field_37 = d0
    //     0x12300ac: stur            d0, [x0, #0x37]
    // 0x12300b0: mov             x1, x0
    // 0x12300b4: r0 = notifyListeners()
    //     0x12300b4: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x12300b8: ldur            x0, [fp, #-8]
    // 0x12300bc: ldur            x2, [fp, #-0x10]
    // 0x12300c0: LoadField: r1 = r2->field_b
    //     0x12300c0: ldur            w1, [x2, #0xb]
    // 0x12300c4: DecompressPointer r1
    //     0x12300c4: add             x1, x1, HEAP, lsl #32
    // 0x12300c8: cmp             w1, NULL
    // 0x12300cc: b.eq            #0x12301d4
    // 0x12300d0: LoadField: d0 = r1->field_57
    //     0x12300d0: ldur            d0, [x1, #0x57]
    // 0x12300d4: LoadField: d1 = r0->field_43
    //     0x12300d4: ldur            d1, [x0, #0x43]
    // 0x12300d8: fcmp            d1, d0
    // 0x12300dc: b.eq            #0x12300f0
    // 0x12300e0: StoreField: r0->field_43 = d0
    //     0x12300e0: stur            d0, [x0, #0x43]
    // 0x12300e4: mov             x1, x0
    // 0x12300e8: r0 = notifyListeners()
    //     0x12300e8: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x12300ec: ldur            x0, [fp, #-8]
    // 0x12300f0: d0 = 3.000000
    //     0x12300f0: fmov            d0, #3.00000000
    // 0x12300f4: LoadField: d1 = r0->field_4b
    //     0x12300f4: ldur            d1, [x0, #0x4b]
    // 0x12300f8: fcmp            d1, d0
    // 0x12300fc: b.eq            #0x1230110
    // 0x1230100: StoreField: r0->field_4b = d0
    //     0x1230100: stur            d0, [x0, #0x4b]
    // 0x1230104: mov             x1, x0
    // 0x1230108: r0 = notifyListeners()
    //     0x1230108: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x123010c: ldur            x0, [fp, #-8]
    // 0x1230110: ldur            x2, [fp, #-0x10]
    // 0x1230114: mov             x1, x2
    // 0x1230118: r0 = _radius()
    //     0x1230118: bl              #0x12304bc  ; [package:flutter/src/cupertino/scrollbar.dart] _CupertinoScrollbarState::_radius
    // 0x123011c: ldur            x1, [fp, #-8]
    // 0x1230120: mov             x2, x0
    // 0x1230124: r0 = radius=()
    //     0x1230124: bl              #0x1230418  ; [package:flutter/src/widgets/scrollbar.dart] ScrollbarPainter::radius=
    // 0x1230128: ldur            x0, [fp, #-0x10]
    // 0x123012c: LoadField: r1 = r0->field_f
    //     0x123012c: ldur            w1, [x0, #0xf]
    // 0x1230130: DecompressPointer r1
    //     0x1230130: add             x1, x1, HEAP, lsl #32
    // 0x1230134: cmp             w1, NULL
    // 0x1230138: b.eq            #0x12301d8
    // 0x123013c: r0 = paddingOf()
    //     0x123013c: bl              #0xd1a984  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::paddingOf
    // 0x1230140: ldur            x1, [fp, #-8]
    // 0x1230144: mov             x2, x0
    // 0x1230148: r0 = padding=()
    //     0x1230148: bl              #0x1230370  ; [package:flutter/src/widgets/scrollbar.dart] ScrollbarPainter::padding=
    // 0x123014c: ldur            x0, [fp, #-8]
    // 0x1230150: LoadField: d0 = r0->field_5f
    //     0x1230150: ldur            d0, [x0, #0x5f]
    // 0x1230154: d1 = 36.000000
    //     0x1230154: add             x17, PP, #0x12, lsl #12  ; [pp+0x12ca0] IMM: double(36) from 0x4042000000000000
    //     0x1230158: ldr             d1, [x17, #0xca0]
    // 0x123015c: fcmp            d0, d1
    // 0x1230160: b.ne            #0x123016c
    // 0x1230164: mov             x1, x0
    // 0x1230168: b               #0x123017c
    // 0x123016c: StoreField: r0->field_5f = d1
    //     0x123016c: stur            d1, [x0, #0x5f]
    // 0x1230170: mov             x1, x0
    // 0x1230174: r0 = notifyListeners()
    //     0x1230174: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x1230178: ldur            x1, [fp, #-8]
    // 0x123017c: d0 = 8.000000
    //     0x123017c: fmov            d0, #8.00000000
    // 0x1230180: LoadField: d1 = r1->field_67
    //     0x1230180: ldur            d1, [x1, #0x67]
    // 0x1230184: fcmp            d1, d0
    // 0x1230188: b.eq            #0x1230194
    // 0x123018c: StoreField: r1->field_67 = d0
    //     0x123018c: stur            d0, [x1, #0x67]
    // 0x1230190: r0 = notifyListeners()
    //     0x1230190: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x1230194: ldur            x1, [fp, #-0x10]
    // 0x1230198: LoadField: r2 = r1->field_b
    //     0x1230198: ldur            w2, [x1, #0xb]
    // 0x123019c: DecompressPointer r2
    //     0x123019c: add             x2, x2, HEAP, lsl #32
    // 0x12301a0: cmp             w2, NULL
    // 0x12301a4: b.eq            #0x12301dc
    // 0x12301a8: r0 = Null
    //     0x12301a8: mov             x0, NULL
    // 0x12301ac: LeaveFrame
    //     0x12301ac: mov             SP, fp
    //     0x12301b0: ldp             fp, lr, [SP], #0x10
    // 0x12301b4: ret
    //     0x12301b4: ret             
    // 0x12301b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12301b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12301bc: b               #0x1230030
    // 0x12301c0: r9 = scrollbarPainter
    //     0x12301c0: add             x9, PP, #0xab, lsl #12  ; [pp+0xab360] Field <RawScrollbarState.scrollbarPainter>: late final (offset: 0x54)
    //     0x12301c4: ldr             x9, [x9, #0x360]
    // 0x12301c8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12301c8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12301cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12301cc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x12301d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12301d0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x12301d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12301d4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x12301d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12301d8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x12301dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12301dc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _radius(/* No info */) {
    // ** addr: 0x12304bc, size: 0x94
    // 0x12304bc: EnterFrame
    //     0x12304bc: stp             fp, lr, [SP, #-0x10]!
    //     0x12304c0: mov             fp, SP
    // 0x12304c4: CheckStackOverflow
    //     0x12304c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12304c8: cmp             SP, x16
    //     0x12304cc: b.ls            #0x1230530
    // 0x12304d0: LoadField: r0 = r1->field_b
    //     0x12304d0: ldur            w0, [x1, #0xb]
    // 0x12304d4: DecompressPointer r0
    //     0x12304d4: add             x0, x0, HEAP, lsl #32
    // 0x12304d8: cmp             w0, NULL
    // 0x12304dc: b.eq            #0x1230538
    // 0x12304e0: LoadField: r2 = r0->field_1b
    //     0x12304e0: ldur            w2, [x0, #0x1b]
    // 0x12304e4: DecompressPointer r2
    //     0x12304e4: add             x2, x2, HEAP, lsl #32
    // 0x12304e8: LoadField: r0 = r1->field_57
    //     0x12304e8: ldur            w0, [x1, #0x57]
    // 0x12304ec: DecompressPointer r0
    //     0x12304ec: add             x0, x0, HEAP, lsl #32
    // 0x12304f0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12304f4: cmp             w0, w16
    // 0x12304f8: b.eq            #0x123053c
    // 0x12304fc: LoadField: r1 = r0->field_37
    //     0x12304fc: ldur            w1, [x0, #0x37]
    // 0x1230500: DecompressPointer r1
    //     0x1230500: add             x1, x1, HEAP, lsl #32
    // 0x1230504: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1230508: cmp             w1, w16
    // 0x123050c: b.eq            #0x1230548
    // 0x1230510: LoadField: d0 = r1->field_7
    //     0x1230510: ldur            d0, [x1, #7]
    // 0x1230514: mov             x1, x2
    // 0x1230518: r2 = Instance_Radius
    //     0x1230518: add             x2, PP, #0x9d, lsl #12  ; [pp+0x9d080] Obj!Radius@12a7121
    //     0x123051c: ldr             x2, [x2, #0x80]
    // 0x1230520: r0 = lerp()
    //     0x1230520: bl              #0xbfeb78  ; [dart:ui] Radius::lerp
    // 0x1230524: LeaveFrame
    //     0x1230524: mov             SP, fp
    //     0x1230528: ldp             fp, lr, [SP], #0x10
    // 0x123052c: ret
    //     0x123052c: ret             
    // 0x1230530: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1230530: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1230534: b               #0x12304d0
    // 0x1230538: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1230538: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x123053c: r9 = _thicknessAnimationController
    //     0x123053c: add             x9, PP, #0xad, lsl #12  ; [pp+0xada40] Field <_CupertinoScrollbarState@707305104._thicknessAnimationController@707305104>: late (offset: 0x58)
    //     0x1230540: ldr             x9, [x9, #0xa40]
    // 0x1230544: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x1230544: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x1230548: r9 = _value
    //     0x1230548: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0x123054c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x123054c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  get _ _thickness(/* No info */) {
    // ** addr: 0x1230550, size: 0x90
    // 0x1230550: EnterFrame
    //     0x1230550: stp             fp, lr, [SP, #-0x10]!
    //     0x1230554: mov             fp, SP
    // 0x1230558: LoadField: r0 = r1->field_b
    //     0x1230558: ldur            w0, [x1, #0xb]
    // 0x123055c: DecompressPointer r0
    //     0x123055c: add             x0, x0, HEAP, lsl #32
    // 0x1230560: cmp             w0, NULL
    // 0x1230564: b.eq            #0x12305c4
    // 0x1230568: LoadField: r2 = r0->field_1f
    //     0x1230568: ldur            w2, [x0, #0x1f]
    // 0x123056c: DecompressPointer r2
    //     0x123056c: add             x2, x2, HEAP, lsl #32
    // 0x1230570: cmp             w2, NULL
    // 0x1230574: b.eq            #0x12305c8
    // 0x1230578: LoadField: r3 = r1->field_57
    //     0x1230578: ldur            w3, [x1, #0x57]
    // 0x123057c: DecompressPointer r3
    //     0x123057c: add             x3, x3, HEAP, lsl #32
    // 0x1230580: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1230584: cmp             w3, w16
    // 0x1230588: b.eq            #0x12305cc
    // 0x123058c: LoadField: r1 = r3->field_37
    //     0x123058c: ldur            w1, [x3, #0x37]
    // 0x1230590: DecompressPointer r1
    //     0x1230590: add             x1, x1, HEAP, lsl #32
    // 0x1230594: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1230598: cmp             w1, w16
    // 0x123059c: b.eq            #0x12305d8
    // 0x12305a0: LoadField: d1 = r0->field_6b
    //     0x12305a0: ldur            d1, [x0, #0x6b]
    // 0x12305a4: LoadField: d2 = r2->field_7
    //     0x12305a4: ldur            d2, [x2, #7]
    // 0x12305a8: fsub            d3, d1, d2
    // 0x12305ac: LoadField: d1 = r1->field_7
    //     0x12305ac: ldur            d1, [x1, #7]
    // 0x12305b0: fmul            d4, d1, d3
    // 0x12305b4: fadd            d0, d2, d4
    // 0x12305b8: LeaveFrame
    //     0x12305b8: mov             SP, fp
    //     0x12305bc: ldp             fp, lr, [SP], #0x10
    // 0x12305c0: ret
    //     0x12305c0: ret             
    // 0x12305c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12305c4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x12305c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12305c8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x12305cc: r9 = _thicknessAnimationController
    //     0x12305cc: add             x9, PP, #0xad, lsl #12  ; [pp+0xada40] Field <_CupertinoScrollbarState@707305104._thicknessAnimationController@707305104>: late (offset: 0x58)
    //     0x12305d0: ldr             x9, [x9, #0xa40]
    // 0x12305d4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12305d4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12305d8: r9 = _value
    //     0x12305d8: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0x12305dc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12305dc: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ handleThumbPressStart(/* No info */) {
    // ** addr: 0x1231c60, size: 0x94
    // 0x1231c60: EnterFrame
    //     0x1231c60: stp             fp, lr, [SP, #-0x10]!
    //     0x1231c64: mov             fp, SP
    // 0x1231c68: AllocStack(0x10)
    //     0x1231c68: sub             SP, SP, #0x10
    // 0x1231c6c: SetupParameters(_CupertinoScrollbarState this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x1231c6c: mov             x3, x1
    //     0x1231c70: mov             x0, x2
    //     0x1231c74: stur            x1, [fp, #-8]
    //     0x1231c78: stur            x2, [fp, #-0x10]
    // 0x1231c7c: CheckStackOverflow
    //     0x1231c7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1231c80: cmp             SP, x16
    //     0x1231c84: b.ls            #0x1231cec
    // 0x1231c88: mov             x1, x3
    // 0x1231c8c: mov             x2, x0
    // 0x1231c90: r0 = handleThumbPressStart()
    //     0x1231c90: bl              #0x1231d6c  ; [package:flutter/src/widgets/scrollbar.dart] RawScrollbarState::handleThumbPressStart
    // 0x1231c94: ldur            x1, [fp, #-8]
    // 0x1231c98: LoadField: r2 = r1->field_4b
    //     0x1231c98: ldur            w2, [x1, #0x4b]
    // 0x1231c9c: DecompressPointer r2
    //     0x1231c9c: add             x2, x2, HEAP, lsl #32
    // 0x1231ca0: cmp             w2, NULL
    // 0x1231ca4: b.ne            #0x1231cb8
    // 0x1231ca8: r0 = Null
    //     0x1231ca8: mov             x0, NULL
    // 0x1231cac: LeaveFrame
    //     0x1231cac: mov             SP, fp
    //     0x1231cb0: ldp             fp, lr, [SP], #0x10
    // 0x1231cb4: ret
    //     0x1231cb4: ret             
    // 0x1231cb8: LoadField: r3 = r2->field_7
    //     0x1231cb8: ldur            x3, [x2, #7]
    // 0x1231cbc: cmp             x3, #0
    // 0x1231cc0: b.gt            #0x1231cd0
    // 0x1231cc4: ldur            x2, [fp, #-0x10]
    // 0x1231cc8: LoadField: d0 = r2->field_7
    //     0x1231cc8: ldur            d0, [x2, #7]
    // 0x1231ccc: b               #0x1231cd8
    // 0x1231cd0: ldur            x2, [fp, #-0x10]
    // 0x1231cd4: LoadField: d0 = r2->field_f
    //     0x1231cd4: ldur            d0, [x2, #0xf]
    // 0x1231cd8: StoreField: r1->field_5b = d0
    //     0x1231cd8: stur            d0, [x1, #0x5b]
    // 0x1231cdc: r0 = Null
    //     0x1231cdc: mov             x0, NULL
    // 0x1231ce0: LeaveFrame
    //     0x1231ce0: mov             SP, fp
    //     0x1231ce4: ldp             fp, lr, [SP], #0x10
    // 0x1231ce8: ret
    //     0x1231ce8: ret             
    // 0x1231cec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1231cec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1231cf0: b               #0x1231c88
  }
  _ handleThumbPressEnd(/* No info */) {
    // ** addr: 0x1232230, size: 0x264
    // 0x1232230: EnterFrame
    //     0x1232230: stp             fp, lr, [SP, #-0x10]!
    //     0x1232234: mov             fp, SP
    // 0x1232238: AllocStack(0x20)
    //     0x1232238: sub             SP, SP, #0x20
    // 0x123223c: SetupParameters(_CupertinoScrollbarState this /* r1 => r0, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */)
    //     0x123223c: mov             x0, x1
    //     0x1232240: stur            x1, [fp, #-0x10]
    //     0x1232244: stur            x2, [fp, #-0x18]
    //     0x1232248: stur            x3, [fp, #-0x20]
    // 0x123224c: CheckStackOverflow
    //     0x123224c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1232250: cmp             SP, x16
    //     0x1232254: b.ls            #0x1232420
    // 0x1232258: LoadField: r4 = r0->field_4b
    //     0x1232258: ldur            w4, [x0, #0x4b]
    // 0x123225c: DecompressPointer r4
    //     0x123225c: add             x4, x4, HEAP, lsl #32
    // 0x1232260: stur            x4, [fp, #-8]
    // 0x1232264: cmp             w4, NULL
    // 0x1232268: b.ne            #0x123227c
    // 0x123226c: r0 = Null
    //     0x123226c: mov             x0, NULL
    // 0x1232270: LeaveFrame
    //     0x1232270: mov             SP, fp
    //     0x1232274: ldp             fp, lr, [SP], #0x10
    // 0x1232278: ret
    //     0x1232278: ret             
    // 0x123227c: LoadField: r1 = r0->field_57
    //     0x123227c: ldur            w1, [x0, #0x57]
    // 0x1232280: DecompressPointer r1
    //     0x1232280: add             x1, x1, HEAP, lsl #32
    // 0x1232284: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1232288: cmp             w1, w16
    // 0x123228c: b.eq            #0x1232428
    // 0x1232290: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x1232290: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x1232294: r0 = reverse()
    //     0x1232294: bl              #0x8c8688  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0x1232298: ldur            x1, [fp, #-0x10]
    // 0x123229c: ldur            x2, [fp, #-0x18]
    // 0x12322a0: ldur            x3, [fp, #-0x20]
    // 0x12322a4: r0 = handleThumbPressEnd()
    //     0x12322a4: bl              #0x1232514  ; [package:flutter/src/widgets/scrollbar.dart] RawScrollbarState::handleThumbPressEnd
    // 0x12322a8: ldur            x0, [fp, #-8]
    // 0x12322ac: LoadField: r1 = r0->field_7
    //     0x12322ac: ldur            x1, [x0, #7]
    // 0x12322b0: cmp             x1, #0
    // 0x12322b4: b.gt            #0x1232334
    // 0x12322b8: ldur            x1, [fp, #-0x18]
    // 0x12322bc: ldur            x0, [fp, #-0x20]
    // 0x12322c0: LoadField: d0 = r1->field_7
    //     0x12322c0: ldur            d0, [x1, #7]
    // 0x12322c4: LoadField: r1 = r0->field_7
    //     0x12322c4: ldur            w1, [x0, #7]
    // 0x12322c8: DecompressPointer r1
    //     0x12322c8: add             x1, x1, HEAP, lsl #32
    // 0x12322cc: LoadField: d1 = r1->field_7
    //     0x12322cc: ldur            d1, [x1, #7]
    // 0x12322d0: r2 = inline_Allocate_Double()
    //     0x12322d0: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0x12322d4: add             x2, x2, #0x10
    //     0x12322d8: cmp             x0, x2
    //     0x12322dc: b.ls            #0x1232434
    //     0x12322e0: str             x2, [THR, #0x60]  ; THR::top
    //     0x12322e4: sub             x2, x2, #0xf
    //     0x12322e8: mov             x0, #0xe19c
    //     0x12322ec: movk            x0, #3, lsl #16
    //     0x12322f0: stur            x0, [x2, #-1]
    // 0x12322f4: dmb             ishst
    // 0x12322f8: StoreField: r2->field_7 = d0
    //     0x12322f8: stur            d0, [x2, #7]
    // 0x12322fc: r3 = inline_Allocate_Double()
    //     0x12322fc: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0x1232300: add             x3, x3, #0x10
    //     0x1232304: cmp             x0, x3
    //     0x1232308: b.ls            #0x1232448
    //     0x123230c: str             x3, [THR, #0x60]  ; THR::top
    //     0x1232310: sub             x3, x3, #0xf
    //     0x1232314: mov             x0, #0xe19c
    //     0x1232318: movk            x0, #3, lsl #16
    //     0x123231c: stur            x0, [x3, #-1]
    // 0x1232320: dmb             ishst
    // 0x1232324: StoreField: r3->field_7 = d1
    //     0x1232324: stur            d1, [x3, #7]
    // 0x1232328: r0 = AllocateRecord2()
    //     0x1232328: bl              #0x13de578  ; AllocateRecord2Stub
    // 0x123232c: mov             x1, x0
    // 0x1232330: b               #0x12323ac
    // 0x1232334: ldur            x1, [fp, #-0x18]
    // 0x1232338: ldur            x0, [fp, #-0x20]
    // 0x123233c: LoadField: d0 = r1->field_f
    //     0x123233c: ldur            d0, [x1, #0xf]
    // 0x1232340: LoadField: r1 = r0->field_7
    //     0x1232340: ldur            w1, [x0, #7]
    // 0x1232344: DecompressPointer r1
    //     0x1232344: add             x1, x1, HEAP, lsl #32
    // 0x1232348: LoadField: d1 = r1->field_f
    //     0x1232348: ldur            d1, [x1, #0xf]
    // 0x123234c: r2 = inline_Allocate_Double()
    //     0x123234c: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0x1232350: add             x2, x2, #0x10
    //     0x1232354: cmp             x0, x2
    //     0x1232358: b.ls            #0x1232464
    //     0x123235c: str             x2, [THR, #0x60]  ; THR::top
    //     0x1232360: sub             x2, x2, #0xf
    //     0x1232364: mov             x0, #0xe19c
    //     0x1232368: movk            x0, #3, lsl #16
    //     0x123236c: stur            x0, [x2, #-1]
    // 0x1232370: dmb             ishst
    // 0x1232374: StoreField: r2->field_7 = d0
    //     0x1232374: stur            d0, [x2, #7]
    // 0x1232378: r3 = inline_Allocate_Double()
    //     0x1232378: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0x123237c: add             x3, x3, #0x10
    //     0x1232380: cmp             x0, x3
    //     0x1232384: b.ls            #0x1232478
    //     0x1232388: str             x3, [THR, #0x60]  ; THR::top
    //     0x123238c: sub             x3, x3, #0xf
    //     0x1232390: mov             x0, #0xe19c
    //     0x1232394: movk            x0, #3, lsl #16
    //     0x1232398: stur            x0, [x3, #-1]
    // 0x123239c: dmb             ishst
    // 0x12323a0: StoreField: r3->field_7 = d1
    //     0x12323a0: stur            d1, [x3, #7]
    // 0x12323a4: r0 = AllocateRecord2()
    //     0x12323a4: bl              #0x13de578  ; AllocateRecord2Stub
    // 0x12323a8: mov             x1, x0
    // 0x12323ac: ldur            x0, [fp, #-0x10]
    // 0x12323b0: LoadField: r2 = r1->field_f
    //     0x12323b0: ldur            w2, [x1, #0xf]
    // 0x12323b4: DecompressPointer r2
    //     0x12323b4: add             x2, x2, HEAP, lsl #32
    // 0x12323b8: LoadField: r3 = r1->field_13
    //     0x12323b8: ldur            w3, [x1, #0x13]
    // 0x12323bc: DecompressPointer r3
    //     0x12323bc: add             x3, x3, HEAP, lsl #32
    // 0x12323c0: LoadField: d0 = r0->field_5b
    //     0x12323c0: ldur            d0, [x0, #0x5b]
    // 0x12323c4: LoadField: d1 = r2->field_7
    //     0x12323c4: ldur            d1, [x2, #7]
    // 0x12323c8: fcmp            d1, d0
    // 0x12323cc: b.eq            #0x1232410
    // 0x12323d0: d0 = 0.000000
    //     0x12323d0: eor             v0.16b, v0.16b, v0.16b
    // 0x12323d4: LoadField: d1 = r3->field_7
    //     0x12323d4: ldur            d1, [x3, #7]
    // 0x12323d8: fcmp            d1, d0
    // 0x12323dc: b.ne            #0x12323e8
    // 0x12323e0: d1 = 0.000000
    //     0x12323e0: eor             v1.16b, v1.16b, v1.16b
    // 0x12323e4: b               #0x1232400
    // 0x12323e8: fcmp            d0, d1
    // 0x12323ec: b.le            #0x12323f8
    // 0x12323f0: fneg            d0, d1
    // 0x12323f4: b               #0x12323fc
    // 0x12323f8: mov             v0.16b, v1.16b
    // 0x12323fc: mov             v1.16b, v0.16b
    // 0x1232400: d0 = 10.000000
    //     0x1232400: fmov            d0, #10.00000000
    // 0x1232404: fcmp            d0, d1
    // 0x1232408: b.le            #0x1232410
    // 0x123240c: r0 = mediumImpact()
    //     0x123240c: bl              #0xd39998  ; [package:flutter/src/services/haptic_feedback.dart] HapticFeedback::mediumImpact
    // 0x1232410: r0 = Null
    //     0x1232410: mov             x0, NULL
    // 0x1232414: LeaveFrame
    //     0x1232414: mov             SP, fp
    //     0x1232418: ldp             fp, lr, [SP], #0x10
    // 0x123241c: ret
    //     0x123241c: ret             
    // 0x1232420: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1232420: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1232424: b               #0x1232258
    // 0x1232428: r9 = _thicknessAnimationController
    //     0x1232428: add             x9, PP, #0xad, lsl #12  ; [pp+0xada40] Field <_CupertinoScrollbarState@707305104._thicknessAnimationController@707305104>: late (offset: 0x58)
    //     0x123242c: ldr             x9, [x9, #0xa40]
    // 0x1232430: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x1232430: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x1232434: stp             q0, q1, [SP, #-0x20]!
    // 0x1232438: r0 = AllocateDouble()
    //     0x1232438: bl              #0x13df878  ; AllocateDoubleStub
    // 0x123243c: mov             x2, x0
    // 0x1232440: ldp             q0, q1, [SP], #0x20
    // 0x1232444: b               #0x12322f8
    // 0x1232448: SaveReg d1
    //     0x1232448: str             q1, [SP, #-0x10]!
    // 0x123244c: SaveReg r2
    //     0x123244c: str             x2, [SP, #-8]!
    // 0x1232450: r0 = AllocateDouble()
    //     0x1232450: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1232454: mov             x3, x0
    // 0x1232458: RestoreReg r2
    //     0x1232458: ldr             x2, [SP], #8
    // 0x123245c: RestoreReg d1
    //     0x123245c: ldr             q1, [SP], #0x10
    // 0x1232460: b               #0x1232324
    // 0x1232464: stp             q0, q1, [SP, #-0x20]!
    // 0x1232468: r0 = AllocateDouble()
    //     0x1232468: bl              #0x13df878  ; AllocateDoubleStub
    // 0x123246c: mov             x2, x0
    // 0x1232470: ldp             q0, q1, [SP], #0x20
    // 0x1232474: b               #0x1232374
    // 0x1232478: SaveReg d1
    //     0x1232478: str             q1, [SP, #-0x10]!
    // 0x123247c: SaveReg r2
    //     0x123247c: str             x2, [SP, #-8]!
    // 0x1232480: r0 = AllocateDouble()
    //     0x1232480: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1232484: mov             x3, x0
    // 0x1232488: RestoreReg r2
    //     0x1232488: ldr             x2, [SP], #8
    // 0x123248c: RestoreReg d1
    //     0x123248c: ldr             q1, [SP], #0x10
    // 0x1232490: b               #0x12323a0
  }
  _ handleThumbPress(/* No info */) {
    // ** addr: 0x1232db0, size: 0xb8
    // 0x1232db0: EnterFrame
    //     0x1232db0: stp             fp, lr, [SP, #-0x10]!
    //     0x1232db4: mov             fp, SP
    // 0x1232db8: AllocStack(0x20)
    //     0x1232db8: sub             SP, SP, #0x20
    // 0x1232dbc: SetupParameters(_CupertinoScrollbarState this /* r1 => r0, fp-0x8 */)
    //     0x1232dbc: mov             x0, x1
    //     0x1232dc0: stur            x1, [fp, #-8]
    // 0x1232dc4: CheckStackOverflow
    //     0x1232dc4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1232dc8: cmp             SP, x16
    //     0x1232dcc: b.ls            #0x1232e54
    // 0x1232dd0: LoadField: r1 = r0->field_4b
    //     0x1232dd0: ldur            w1, [x0, #0x4b]
    // 0x1232dd4: DecompressPointer r1
    //     0x1232dd4: add             x1, x1, HEAP, lsl #32
    // 0x1232dd8: cmp             w1, NULL
    // 0x1232ddc: b.ne            #0x1232df0
    // 0x1232de0: r0 = Null
    //     0x1232de0: mov             x0, NULL
    // 0x1232de4: LeaveFrame
    //     0x1232de4: mov             SP, fp
    //     0x1232de8: ldp             fp, lr, [SP], #0x10
    // 0x1232dec: ret
    //     0x1232dec: ret             
    // 0x1232df0: mov             x1, x0
    // 0x1232df4: r0 = handleThumbPress()
    //     0x1232df4: bl              #0x1232e68  ; [package:flutter/src/widgets/scrollbar.dart] RawScrollbarState::handleThumbPress
    // 0x1232df8: ldur            x0, [fp, #-8]
    // 0x1232dfc: LoadField: r1 = r0->field_57
    //     0x1232dfc: ldur            w1, [x0, #0x57]
    // 0x1232e00: DecompressPointer r1
    //     0x1232e00: add             x1, x1, HEAP, lsl #32
    // 0x1232e04: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1232e08: cmp             w1, w16
    // 0x1232e0c: b.eq            #0x1232e5c
    // 0x1232e10: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x1232e10: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x1232e14: r0 = forward()
    //     0x1232e14: bl              #0x8cd83c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x1232e18: r1 = Function '<anonymous closure>':.
    //     0x1232e18: add             x1, PP, #0xad, lsl #12  ; [pp+0xada38] AnonymousClosure: (0xd3996c), in [package:flutter/src/cupertino/scrollbar.dart] _CupertinoScrollbarState::handleThumbPress (0x1232db0)
    //     0x1232e1c: ldr             x1, [x1, #0xa38]
    // 0x1232e20: r2 = Null
    //     0x1232e20: mov             x2, NULL
    // 0x1232e24: stur            x0, [fp, #-8]
    // 0x1232e28: r0 = AllocateClosure()
    //     0x1232e28: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1232e2c: r16 = <void?>
    //     0x1232e2c: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x1232e30: ldur            lr, [fp, #-8]
    // 0x1232e34: stp             lr, x16, [SP, #8]
    // 0x1232e38: str             x0, [SP]
    // 0x1232e3c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x1232e3c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x1232e40: r0 = then()
    //     0x1232e40: bl              #0x13083d8  ; [package:flutter/src/scheduler/ticker.dart] TickerFuture::then
    // 0x1232e44: r0 = Null
    //     0x1232e44: mov             x0, NULL
    // 0x1232e48: LeaveFrame
    //     0x1232e48: mov             SP, fp
    //     0x1232e4c: ldp             fp, lr, [SP], #0x10
    // 0x1232e50: ret
    //     0x1232e50: ret             
    // 0x1232e54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1232e54: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1232e58: b               #0x1232dd0
    // 0x1232e5c: r9 = _thicknessAnimationController
    //     0x1232e5c: add             x9, PP, #0xad, lsl #12  ; [pp+0xada40] Field <_CupertinoScrollbarState@707305104._thicknessAnimationController@707305104>: late (offset: 0x58)
    //     0x1232e60: ldr             x9, [x9, #0xa40]
    // 0x1232e64: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x1232e64: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 6512, size: 0x78, field offset: 0x6c
//   const constructor, 
class CupertinoScrollbar extends RawScrollbar {

  _ createState(/* No info */) {
    // ** addr: 0xfa076c, size: 0x58
    // 0xfa076c: EnterFrame
    //     0xfa076c: stp             fp, lr, [SP, #-0x10]!
    //     0xfa0770: mov             fp, SP
    // 0xfa0774: AllocStack(0x8)
    //     0xfa0774: sub             SP, SP, #8
    // 0xfa0778: CheckStackOverflow
    //     0xfa0778: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa077c: cmp             SP, x16
    //     0xfa0780: b.ls            #0xfa07bc
    // 0xfa0784: r1 = <CupertinoScrollbar>
    //     0xfa0784: add             x1, PP, #0xcf, lsl #12  ; [pp+0xcf8a0] TypeArguments: <CupertinoScrollbar>
    //     0xfa0788: ldr             x1, [x1, #0x8a0]
    // 0xfa078c: r0 = _CupertinoScrollbarState()
    //     0xfa078c: bl              #0xfa0858  ; Allocate_CupertinoScrollbarStateStub -> _CupertinoScrollbarState (size=0x64)
    // 0xfa0790: mov             x2, x0
    // 0xfa0794: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa0798: stur            x2, [fp, #-8]
    // 0xfa079c: StoreField: r2->field_57 = r0
    //     0xfa079c: stur            w0, [x2, #0x57]
    // 0xfa07a0: StoreField: r2->field_5b = rZR
    //     0xfa07a0: stur            xzr, [x2, #0x5b]
    // 0xfa07a4: mov             x1, x2
    // 0xfa07a8: r0 = RawScrollbarState()
    //     0xfa07a8: bl              #0xfa07c4  ; [package:flutter/src/widgets/scrollbar.dart] RawScrollbarState::RawScrollbarState
    // 0xfa07ac: ldur            x0, [fp, #-8]
    // 0xfa07b0: LeaveFrame
    //     0xfa07b0: mov             SP, fp
    //     0xfa07b4: ldp             fp, lr, [SP], #0x10
    // 0xfa07b8: ret
    //     0xfa07b8: ret             
    // 0xfa07bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa07bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa07c0: b               #0xfa0784
  }
}
