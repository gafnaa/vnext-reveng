// lib: , url: package:flutter/src/cupertino/app.dart

// class id: 1048770, size: 0x8
class :: {
}

// class id: 6529, size: 0xc, field offset: 0xc
//   const constructor, 
abstract class CupertinoApp extends StatefulWidget {
}
