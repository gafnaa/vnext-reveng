// lib: , url: package:flutter/src/cupertino/thumb_painter.dart

// class id: 1048791, size: 0x8
class :: {
}

// class id: 3246, size: 0x10, field offset: 0x8
//   const constructor, 
class CupertinoThumbPainter extends Object {

  _ paint(/* No info */) {
    // ** addr: 0xc17464, size: 0x224
    // 0xc17464: EnterFrame
    //     0xc17464: stp             fp, lr, [SP, #-0x10]!
    //     0xc17468: mov             fp, SP
    // 0xc1746c: AllocStack(0x50)
    //     0xc1746c: sub             SP, SP, #0x50
    // 0xc17470: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r0, fp-0x10 */)
    //     0xc17470: mov             x0, x3
    //     0xc17474: stur            x2, [fp, #-8]
    //     0xc17478: stur            x3, [fp, #-0x10]
    // 0xc1747c: CheckStackOverflow
    //     0xc1747c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc17480: cmp             SP, x16
    //     0xc17484: b.ls            #0xc17678
    // 0xc17488: mov             x1, x0
    // 0xc1748c: r0 = shortestSide()
    //     0xc1748c: bl              #0xbfe320  ; [dart:ui] Rect::shortestSide
    // 0xc17490: mov             v1.16b, v0.16b
    // 0xc17494: d0 = 2.000000
    //     0xc17494: fmov            d0, #2.00000000
    // 0xc17498: fdiv            d2, d1, d0
    // 0xc1749c: stur            d2, [fp, #-0x40]
    // 0xc174a0: r0 = Radius()
    //     0xc174a0: bl              #0x8a73d4  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0xc174a4: ldur            d0, [fp, #-0x40]
    // 0xc174a8: stur            x0, [fp, #-0x18]
    // 0xc174ac: StoreField: r0->field_7 = d0
    //     0xc174ac: stur            d0, [x0, #7]
    // 0xc174b0: StoreField: r0->field_f = d0
    //     0xc174b0: stur            d0, [x0, #0xf]
    // 0xc174b4: r1 = <RRect>
    //     0xc174b4: add             x1, PP, #0x85, lsl #12  ; [pp+0x85108] TypeArguments: <RRect>
    //     0xc174b8: ldr             x1, [x1, #0x108]
    // 0xc174bc: r0 = RRect()
    //     0xc174bc: bl              #0xb6e214  ; AllocateRRectStub -> RRect (size=0x6c)
    // 0xc174c0: mov             x1, x0
    // 0xc174c4: ldur            x2, [fp, #-0x10]
    // 0xc174c8: ldur            x3, [fp, #-0x18]
    // 0xc174cc: stur            x0, [fp, #-0x10]
    // 0xc174d0: r0 = RRect.fromRectAndRadius()
    //     0xc174d0: bl              #0xb6e920  ; [dart:ui] RRect::RRect.fromRectAndRadius
    // 0xc174d4: r1 = 0
    //     0xc174d4: mov             x1, #0
    // 0xc174d8: r0 = const [Instance of 'BoxShadow', Instance of 'BoxShadow', Instance of 'BoxShadow']
    //     0xc174d8: add             x0, PP, #0xd0, lsl #12  ; [pp+0xd00f8] List<BoxShadow>(3)
    //     0xc174dc: ldr             x0, [x0, #0xf8]
    // 0xc174e0: CheckStackOverflow
    //     0xc174e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc174e4: cmp             SP, x16
    //     0xc174e8: b.ls            #0xc17680
    // 0xc174ec: cmp             x1, #3
    // 0xc174f0: b.ge            #0xc175d0
    // 0xc174f4: ArrayLoad: r3 = r0[r1]  ; Unknown_4
    //     0xc174f4: add             x16, x0, x1, lsl #2
    //     0xc174f8: ldur            w3, [x16, #0xf]
    // 0xc174fc: DecompressPointer r3
    //     0xc174fc: add             x3, x3, HEAP, lsl #32
    // 0xc17500: stur            x3, [fp, #-0x18]
    // 0xc17504: add             x4, x1, #1
    // 0xc17508: stur            x4, [fp, #-0x20]
    // 0xc1750c: LoadField: r2 = r3->field_b
    //     0xc1750c: ldur            w2, [x3, #0xb]
    // 0xc17510: DecompressPointer r2
    //     0xc17510: add             x2, x2, HEAP, lsl #32
    // 0xc17514: ldur            x1, [fp, #-0x10]
    // 0xc17518: r0 = shift()
    //     0xc17518: bl              #0xb6e004  ; [dart:ui] _RRectLike::shift
    // 0xc1751c: stur            x0, [fp, #-0x28]
    // 0xc17520: r16 = 136
    //     0xc17520: mov             x16, #0x88
    // 0xc17524: stp             x16, NULL, [SP]
    // 0xc17528: r0 = ByteData()
    //     0xc17528: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xc1752c: stur            x0, [fp, #-0x30]
    // 0xc17530: r0 = Paint()
    //     0xc17530: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xc17534: mov             x3, x0
    // 0xc17538: ldur            x0, [fp, #-0x30]
    // 0xc1753c: stur            x3, [fp, #-0x38]
    // 0xc17540: StoreField: r3->field_7 = r0
    //     0xc17540: stur            w0, [x3, #7]
    // 0xc17544: ldur            x4, [fp, #-0x18]
    // 0xc17548: LoadField: r2 = r4->field_7
    //     0xc17548: ldur            w2, [x4, #7]
    // 0xc1754c: DecompressPointer r2
    //     0xc1754c: add             x2, x2, HEAP, lsl #32
    // 0xc17550: mov             x1, x3
    // 0xc17554: r0 = color=()
    //     0xc17554: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xc17558: ldur            x0, [fp, #-0x18]
    // 0xc1755c: LoadField: d0 = r0->field_f
    //     0xc1755c: ldur            d0, [x0, #0xf]
    // 0xc17560: d1 = 0.000000
    //     0xc17560: eor             v1.16b, v1.16b, v1.16b
    // 0xc17564: fcmp            d0, d1
    // 0xc17568: b.le            #0xc17580
    // 0xc1756c: d3 = 0.500000
    //     0xc1756c: fmov            d3, #0.50000000
    // 0xc17570: d2 = 0.577350
    //     0xc17570: ldr             d2, [PP, #0x4a48]  ; [pp+0x4a48] IMM: double(0.57735) from 0x3fe279a6b50b0f28
    // 0xc17574: fmul            d4, d0, d2
    // 0xc17578: fadd            d0, d4, d3
    // 0xc1757c: b               #0xc1758c
    // 0xc17580: d3 = 0.500000
    //     0xc17580: fmov            d3, #0.50000000
    // 0xc17584: d2 = 0.577350
    //     0xc17584: ldr             d2, [PP, #0x4a48]  ; [pp+0x4a48] IMM: double(0.57735) from 0x3fe279a6b50b0f28
    // 0xc17588: d0 = 0.000000
    //     0xc17588: eor             v0.16b, v0.16b, v0.16b
    // 0xc1758c: ldur            x0, [fp, #-0x30]
    // 0xc17590: r4 = 1
    //     0xc17590: mov             x4, #1
    // 0xc17594: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xc17594: ldur            w1, [x0, #0x17]
    // 0xc17598: DecompressPointer r1
    //     0xc17598: add             x1, x1, HEAP, lsl #32
    // 0xc1759c: LoadField: r0 = r1->field_7
    //     0xc1759c: ldur            x0, [x1, #7]
    // 0xc175a0: str             w4, [x0, #0x34]
    // 0xc175a4: LoadField: r0 = r1->field_7
    //     0xc175a4: ldur            x0, [x1, #7]
    // 0xc175a8: str             wzr, [x0, #0x38]
    // 0xc175ac: fcvt            s4, d0
    // 0xc175b0: LoadField: r0 = r1->field_7
    //     0xc175b0: ldur            x0, [x1, #7]
    // 0xc175b4: str             s4, [x0, #0x3c]
    // 0xc175b8: ldur            x1, [fp, #-8]
    // 0xc175bc: ldur            x2, [fp, #-0x28]
    // 0xc175c0: ldur            x3, [fp, #-0x38]
    // 0xc175c4: r0 = drawRRect()
    //     0xc175c4: bl              #0xb6dce0  ; [dart:ui] _NativeCanvas::drawRRect
    // 0xc175c8: ldur            x1, [fp, #-0x20]
    // 0xc175cc: b               #0xc174d8
    // 0xc175d0: ldur            x1, [fp, #-0x10]
    // 0xc175d4: d0 = 0.500000
    //     0xc175d4: fmov            d0, #0.50000000
    // 0xc175d8: r0 = inflate()
    //     0xc175d8: bl              #0xb6daf4  ; [dart:ui] _RRectLike::inflate
    // 0xc175dc: stur            x0, [fp, #-0x18]
    // 0xc175e0: r16 = 136
    //     0xc175e0: mov             x16, #0x88
    // 0xc175e4: stp             x16, NULL, [SP]
    // 0xc175e8: r0 = ByteData()
    //     0xc175e8: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xc175ec: stur            x0, [fp, #-0x28]
    // 0xc175f0: r0 = Paint()
    //     0xc175f0: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xc175f4: mov             x3, x0
    // 0xc175f8: ldur            x0, [fp, #-0x28]
    // 0xc175fc: stur            x3, [fp, #-0x30]
    // 0xc17600: StoreField: r3->field_7 = r0
    //     0xc17600: stur            w0, [x3, #7]
    // 0xc17604: mov             x1, x3
    // 0xc17608: r2 = Instance_Color
    //     0xc17608: add             x2, PP, #0x26, lsl #12  ; [pp+0x26c28] Obj!Color@12a2731
    //     0xc1760c: ldr             x2, [x2, #0xc28]
    // 0xc17610: r0 = color=()
    //     0xc17610: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xc17614: ldur            x1, [fp, #-8]
    // 0xc17618: ldur            x2, [fp, #-0x18]
    // 0xc1761c: ldur            x3, [fp, #-0x30]
    // 0xc17620: r0 = drawRRect()
    //     0xc17620: bl              #0xb6dce0  ; [dart:ui] _NativeCanvas::drawRRect
    // 0xc17624: r16 = 136
    //     0xc17624: mov             x16, #0x88
    // 0xc17628: stp             x16, NULL, [SP]
    // 0xc1762c: r0 = ByteData()
    //     0xc1762c: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xc17630: stur            x0, [fp, #-0x18]
    // 0xc17634: r0 = Paint()
    //     0xc17634: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xc17638: mov             x3, x0
    // 0xc1763c: ldur            x0, [fp, #-0x18]
    // 0xc17640: stur            x3, [fp, #-0x28]
    // 0xc17644: StoreField: r3->field_7 = r0
    //     0xc17644: stur            w0, [x3, #7]
    // 0xc17648: mov             x1, x3
    // 0xc1764c: r2 = Instance_Color
    //     0xc1764c: add             x2, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0xc17650: ldr             x2, [x2, #0xc38]
    // 0xc17654: r0 = color=()
    //     0xc17654: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xc17658: ldur            x1, [fp, #-8]
    // 0xc1765c: ldur            x2, [fp, #-0x10]
    // 0xc17660: ldur            x3, [fp, #-0x28]
    // 0xc17664: r0 = drawRRect()
    //     0xc17664: bl              #0xb6dce0  ; [dart:ui] _NativeCanvas::drawRRect
    // 0xc17668: r0 = Null
    //     0xc17668: mov             x0, NULL
    // 0xc1766c: LeaveFrame
    //     0xc1766c: mov             SP, fp
    //     0xc17670: ldp             fp, lr, [SP], #0x10
    // 0xc17674: ret
    //     0xc17674: ret             
    // 0xc17678: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc17678: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1767c: b               #0xc17488
    // 0xc17680: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc17680: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc17684: b               #0xc174ec
  }
}
