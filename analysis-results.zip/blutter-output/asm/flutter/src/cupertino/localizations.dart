// lib: , url: package:flutter/src/cupertino/localizations.dart

// class id: 1048781, size: 0x8
class :: {
}

// class id: 3267, size: 0x8, field offset: 0x8
//   const constructor, 
class DefaultCupertinoLocalizations extends Object
    implements CupertinoLocalizations {

  static _ load(/* No info */) {
    // ** addr: 0x12095f4, size: 0x2c
    // 0x12095f4: EnterFrame
    //     0x12095f4: stp             fp, lr, [SP, #-0x10]!
    //     0x12095f8: mov             fp, SP
    // 0x12095fc: r1 = <CupertinoLocalizations>
    //     0x12095fc: add             x1, PP, #0x80, lsl #12  ; [pp+0x80a30] TypeArguments: <CupertinoLocalizations>
    //     0x1209600: ldr             x1, [x1, #0xa30]
    // 0x1209604: r0 = SynchronousFuture()
    //     0x1209604: bl              #0xeb3f1c  ; AllocateSynchronousFutureStub -> SynchronousFuture<X0> (size=0x10)
    // 0x1209608: r1 = Instance_DefaultCupertinoLocalizations
    //     0x1209608: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa1070] Obj!DefaultCupertinoLocalizations@129f331
    //     0x120960c: ldr             x1, [x1, #0x70]
    // 0x1209610: StoreField: r0->field_b = r1
    //     0x1209610: stur            w1, [x0, #0xb]
    // 0x1209614: LeaveFrame
    //     0x1209614: mov             SP, fp
    //     0x1209618: ldp             fp, lr, [SP], #0x10
    // 0x120961c: ret
    //     0x120961c: ret             
  }
}

// class id: 3274, size: 0xc, field offset: 0xc
//   const constructor, 
class _CupertinoLocalizationsDelegate extends LocalizationsDelegate<dynamic> {

  _ shouldReload(/* No info */) {
    // ** addr: 0x11b4690, size: 0x58
    // 0x11b4690: EnterFrame
    //     0x11b4690: stp             fp, lr, [SP, #-0x10]!
    //     0x11b4694: mov             fp, SP
    // 0x11b4698: mov             x0, x2
    // 0x11b469c: mov             x4, x1
    // 0x11b46a0: mov             x3, x2
    // 0x11b46a4: r2 = Null
    //     0x11b46a4: mov             x2, NULL
    // 0x11b46a8: r1 = Null
    //     0x11b46a8: mov             x1, NULL
    // 0x11b46ac: r4 = 60
    //     0x11b46ac: mov             x4, #0x3c
    // 0x11b46b0: branchIfSmi(r0, 0x11b46bc)
    //     0x11b46b0: tbz             w0, #0, #0x11b46bc
    // 0x11b46b4: r4 = LoadClassIdInstr(r0)
    //     0x11b46b4: ldur            x4, [x0, #-1]
    //     0x11b46b8: ubfx            x4, x4, #0xc, #0x14
    // 0x11b46bc: cmp             x4, #0xcca
    // 0x11b46c0: b.eq            #0x11b46d8
    // 0x11b46c4: r8 = _CupertinoLocalizationsDelegate
    //     0x11b46c4: add             x8, PP, #0xa1, lsl #12  ; [pp+0xa1058] Type: _CupertinoLocalizationsDelegate
    //     0x11b46c8: ldr             x8, [x8, #0x58]
    // 0x11b46cc: r3 = Null
    //     0x11b46cc: add             x3, PP, #0xa1, lsl #12  ; [pp+0xa1060] Null
    //     0x11b46d0: ldr             x3, [x3, #0x60]
    // 0x11b46d4: r0 = DefaultTypeTest()
    //     0x11b46d4: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x11b46d8: r0 = false
    //     0x11b46d8: add             x0, NULL, #0x30  ; false
    // 0x11b46dc: LeaveFrame
    //     0x11b46dc: mov             SP, fp
    //     0x11b46e0: ldp             fp, lr, [SP], #0x10
    // 0x11b46e4: ret
    //     0x11b46e4: ret             
  }
  _ load(/* No info */) {
    // ** addr: 0x12095c8, size: 0x2c
    // 0x12095c8: EnterFrame
    //     0x12095c8: stp             fp, lr, [SP, #-0x10]!
    //     0x12095cc: mov             fp, SP
    // 0x12095d0: CheckStackOverflow
    //     0x12095d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12095d4: cmp             SP, x16
    //     0x12095d8: b.ls            #0x12095ec
    // 0x12095dc: r0 = load()
    //     0x12095dc: bl              #0x12095f4  ; [package:flutter/src/cupertino/localizations.dart] DefaultCupertinoLocalizations::load
    // 0x12095e0: LeaveFrame
    //     0x12095e0: mov             SP, fp
    //     0x12095e4: ldp             fp, lr, [SP], #0x10
    // 0x12095e8: ret
    //     0x12095e8: ret             
    // 0x12095ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12095ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12095f0: b               #0x12095dc
  }
}

// class id: 3275, size: 0x8, field offset: 0x8
abstract class CupertinoLocalizations extends Object {

  static _ of(/* No info */) {
    // ** addr: 0xde37f4, size: 0x58
    // 0xde37f4: EnterFrame
    //     0xde37f4: stp             fp, lr, [SP, #-0x10]!
    //     0xde37f8: mov             fp, SP
    // 0xde37fc: AllocStack(0x18)
    //     0xde37fc: sub             SP, SP, #0x18
    // 0xde3800: CheckStackOverflow
    //     0xde3800: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde3804: cmp             SP, x16
    //     0xde3808: b.ls            #0xde3840
    // 0xde380c: r16 = <CupertinoLocalizations>
    //     0xde380c: add             x16, PP, #0x80, lsl #12  ; [pp+0x80a30] TypeArguments: <CupertinoLocalizations>
    //     0xde3810: ldr             x16, [x16, #0xa30]
    // 0xde3814: stp             x1, x16, [SP, #8]
    // 0xde3818: r16 = CupertinoLocalizations
    //     0xde3818: add             x16, PP, #0x80, lsl #12  ; [pp+0x80a38] Type: CupertinoLocalizations
    //     0xde381c: ldr             x16, [x16, #0xa38]
    // 0xde3820: str             x16, [SP]
    // 0xde3824: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xde3824: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xde3828: r0 = of()
    //     0xde3828: bl              #0x8bde0c  ; [package:flutter/src/widgets/localizations.dart] Localizations::of
    // 0xde382c: cmp             w0, NULL
    // 0xde3830: b.eq            #0xde3848
    // 0xde3834: LeaveFrame
    //     0xde3834: mov             SP, fp
    //     0xde3838: ldp             fp, lr, [SP], #0x10
    // 0xde383c: ret
    //     0xde383c: ret             
    // 0xde3840: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde3840: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde3844: b               #0xde380c
    // 0xde3848: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xde3848: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}
