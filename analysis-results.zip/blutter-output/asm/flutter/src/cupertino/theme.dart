// lib: , url: package:flutter/src/cupertino/theme.dart

// class id: 1048790, size: 0x8
class :: {
}

// class id: 3247, size: 0x10, field offset: 0x8
//   const constructor, 
class _CupertinoTextThemeDefaults extends Object {

  CupertinoDynamicColor field_8;
  CupertinoDynamicColor field_c;

  _ createDefaults(/* No info */) {
    // ** addr: 0x1143e98, size: 0x34
    // 0x1143e98: EnterFrame
    //     0x1143e98: stp             fp, lr, [SP, #-0x10]!
    //     0x1143e9c: mov             fp, SP
    // 0x1143ea0: AllocStack(0x8)
    //     0x1143ea0: sub             SP, SP, #8
    // 0x1143ea4: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x1143ea4: stur            x2, [fp, #-8]
    // 0x1143ea8: r0 = _DefaultCupertinoTextThemeData()
    //     0x1143ea8: bl              #0x1143ecc  ; Allocate_DefaultCupertinoTextThemeDataStub -> _DefaultCupertinoTextThemeData (size=0x34)
    // 0x1143eac: r1 = Instance__TextThemeDefaultsBuilder
    //     0x1143eac: add             x1, PP, #0x26, lsl #12  ; [pp+0x26b60] Obj!_TextThemeDefaultsBuilder@129f2e1
    //     0x1143eb0: ldr             x1, [x1, #0xb60]
    // 0x1143eb4: StoreField: r0->field_7 = r1
    //     0x1143eb4: stur            w1, [x0, #7]
    // 0x1143eb8: ldur            x1, [fp, #-8]
    // 0x1143ebc: StoreField: r0->field_b = r1
    //     0x1143ebc: stur            w1, [x0, #0xb]
    // 0x1143ec0: LeaveFrame
    //     0x1143ec0: mov             SP, fp
    //     0x1143ec4: ldp             fp, lr, [SP], #0x10
    // 0x1143ec8: ret
    //     0x1143ec8: ret             
  }
  _ resolveFrom(/* No info */) {
    // ** addr: 0x121eff8, size: 0x80
    // 0x121eff8: EnterFrame
    //     0x121eff8: stp             fp, lr, [SP, #-0x10]!
    //     0x121effc: mov             fp, SP
    // 0x121f000: AllocStack(0x18)
    //     0x121f000: sub             SP, SP, #0x18
    // 0x121f004: SetupParameters(_CupertinoTextThemeDefaults this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x121f004: mov             x3, x1
    //     0x121f008: mov             x0, x2
    //     0x121f00c: stur            x1, [fp, #-8]
    //     0x121f010: stur            x2, [fp, #-0x10]
    // 0x121f014: CheckStackOverflow
    //     0x121f014: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x121f018: cmp             SP, x16
    //     0x121f01c: b.ls            #0x121f070
    // 0x121f020: LoadField: r1 = r3->field_7
    //     0x121f020: ldur            w1, [x3, #7]
    // 0x121f024: DecompressPointer r1
    //     0x121f024: add             x1, x1, HEAP, lsl #32
    // 0x121f028: mov             x2, x0
    // 0x121f02c: r0 = resolveFrom()
    //     0x121f02c: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0x121f030: mov             x3, x0
    // 0x121f034: ldur            x0, [fp, #-8]
    // 0x121f038: stur            x3, [fp, #-0x18]
    // 0x121f03c: LoadField: r1 = r0->field_b
    //     0x121f03c: ldur            w1, [x0, #0xb]
    // 0x121f040: DecompressPointer r1
    //     0x121f040: add             x1, x1, HEAP, lsl #32
    // 0x121f044: ldur            x2, [fp, #-0x10]
    // 0x121f048: r0 = resolveFrom()
    //     0x121f048: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0x121f04c: stur            x0, [fp, #-8]
    // 0x121f050: r0 = _CupertinoTextThemeDefaults()
    //     0x121f050: bl              #0x121f078  ; Allocate_CupertinoTextThemeDefaultsStub -> _CupertinoTextThemeDefaults (size=0x10)
    // 0x121f054: ldur            x1, [fp, #-0x18]
    // 0x121f058: StoreField: r0->field_7 = r1
    //     0x121f058: stur            w1, [x0, #7]
    // 0x121f05c: ldur            x1, [fp, #-8]
    // 0x121f060: StoreField: r0->field_b = r1
    //     0x121f060: stur            w1, [x0, #0xb]
    // 0x121f064: LeaveFrame
    //     0x121f064: mov             SP, fp
    //     0x121f068: ldp             fp, lr, [SP], #0x10
    // 0x121f06c: ret
    //     0x121f06c: ret             
    // 0x121f070: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x121f070: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x121f074: b               #0x121f020
  }
}

// class id: 3248, size: 0x28, field offset: 0x8
//   const constructor, 
class _CupertinoThemeDefaults extends Object {

  CupertinoDynamicColor field_c;
  Color field_10;
  CupertinoDynamicColor field_14;
  CupertinoDynamicColor field_18;
  CupertinoDynamicColor field_1c;
  bool field_20;
  _CupertinoTextThemeDefaults field_24;

  _ resolveFrom(/* No info */) {
    // ** addr: 0x121eeb8, size: 0x134
    // 0x121eeb8: EnterFrame
    //     0x121eeb8: stp             fp, lr, [SP, #-0x10]!
    //     0x121eebc: mov             fp, SP
    // 0x121eec0: AllocStack(0x38)
    //     0x121eec0: sub             SP, SP, #0x38
    // 0x121eec4: SetupParameters(_CupertinoThemeDefaults this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x121eec4: mov             x4, x1
    //     0x121eec8: mov             x0, x2
    //     0x121eecc: stur            x1, [fp, #-8]
    //     0x121eed0: stur            x2, [fp, #-0x10]
    //     0x121eed4: stur            x3, [fp, #-0x18]
    // 0x121eed8: CheckStackOverflow
    //     0x121eed8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x121eedc: cmp             SP, x16
    //     0x121eee0: b.ls            #0x121efe4
    // 0x121eee4: LoadField: r1 = r4->field_b
    //     0x121eee4: ldur            w1, [x4, #0xb]
    // 0x121eee8: DecompressPointer r1
    //     0x121eee8: add             x1, x1, HEAP, lsl #32
    // 0x121eeec: mov             x2, x0
    // 0x121eef0: r0 = resolveFrom()
    //     0x121eef0: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0x121eef4: mov             x3, x0
    // 0x121eef8: ldur            x0, [fp, #-8]
    // 0x121eefc: stur            x3, [fp, #-0x20]
    // 0x121ef00: LoadField: r1 = r0->field_13
    //     0x121ef00: ldur            w1, [x0, #0x13]
    // 0x121ef04: DecompressPointer r1
    //     0x121ef04: add             x1, x1, HEAP, lsl #32
    // 0x121ef08: ldur            x2, [fp, #-0x10]
    // 0x121ef0c: r0 = resolveFrom()
    //     0x121ef0c: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0x121ef10: mov             x3, x0
    // 0x121ef14: ldur            x0, [fp, #-8]
    // 0x121ef18: stur            x3, [fp, #-0x28]
    // 0x121ef1c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x121ef1c: ldur            w1, [x0, #0x17]
    // 0x121ef20: DecompressPointer r1
    //     0x121ef20: add             x1, x1, HEAP, lsl #32
    // 0x121ef24: ldur            x2, [fp, #-0x10]
    // 0x121ef28: r0 = resolveFrom()
    //     0x121ef28: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0x121ef2c: mov             x3, x0
    // 0x121ef30: ldur            x0, [fp, #-8]
    // 0x121ef34: stur            x3, [fp, #-0x30]
    // 0x121ef38: LoadField: r1 = r0->field_1b
    //     0x121ef38: ldur            w1, [x0, #0x1b]
    // 0x121ef3c: DecompressPointer r1
    //     0x121ef3c: add             x1, x1, HEAP, lsl #32
    // 0x121ef40: ldur            x2, [fp, #-0x10]
    // 0x121ef44: r0 = resolveFrom()
    //     0x121ef44: bl              #0xce16d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0x121ef48: mov             x3, x0
    // 0x121ef4c: ldur            x0, [fp, #-0x18]
    // 0x121ef50: stur            x3, [fp, #-0x38]
    // 0x121ef54: tbnz            w0, #4, #0x121ef74
    // 0x121ef58: ldur            x0, [fp, #-8]
    // 0x121ef5c: LoadField: r1 = r0->field_23
    //     0x121ef5c: ldur            w1, [x0, #0x23]
    // 0x121ef60: DecompressPointer r1
    //     0x121ef60: add             x1, x1, HEAP, lsl #32
    // 0x121ef64: ldur            x2, [fp, #-0x10]
    // 0x121ef68: r0 = resolveFrom()
    //     0x121ef68: bl              #0x121eff8  ; [package:flutter/src/cupertino/theme.dart] _CupertinoTextThemeDefaults::resolveFrom
    // 0x121ef6c: mov             x4, x0
    // 0x121ef70: b               #0x121ef84
    // 0x121ef74: ldur            x0, [fp, #-8]
    // 0x121ef78: LoadField: r1 = r0->field_23
    //     0x121ef78: ldur            w1, [x0, #0x23]
    // 0x121ef7c: DecompressPointer r1
    //     0x121ef7c: add             x1, x1, HEAP, lsl #32
    // 0x121ef80: mov             x4, x1
    // 0x121ef84: ldur            x3, [fp, #-0x20]
    // 0x121ef88: ldur            x2, [fp, #-0x28]
    // 0x121ef8c: ldur            x1, [fp, #-0x30]
    // 0x121ef90: ldur            x0, [fp, #-0x38]
    // 0x121ef94: stur            x4, [fp, #-8]
    // 0x121ef98: r0 = _CupertinoThemeDefaults()
    //     0x121ef98: bl              #0x121efec  ; Allocate_CupertinoThemeDefaultsStub -> _CupertinoThemeDefaults (size=0x28)
    // 0x121ef9c: ldur            x1, [fp, #-0x20]
    // 0x121efa0: StoreField: r0->field_b = r1
    //     0x121efa0: stur            w1, [x0, #0xb]
    // 0x121efa4: r1 = Instance_Color
    //     0x121efa4: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0x121efa8: ldr             x1, [x1, #0xc38]
    // 0x121efac: StoreField: r0->field_f = r1
    //     0x121efac: stur            w1, [x0, #0xf]
    // 0x121efb0: ldur            x1, [fp, #-0x28]
    // 0x121efb4: StoreField: r0->field_13 = r1
    //     0x121efb4: stur            w1, [x0, #0x13]
    // 0x121efb8: ldur            x1, [fp, #-0x30]
    // 0x121efbc: ArrayStore: r0[0] = r1  ; List_4
    //     0x121efbc: stur            w1, [x0, #0x17]
    // 0x121efc0: ldur            x1, [fp, #-0x38]
    // 0x121efc4: StoreField: r0->field_1b = r1
    //     0x121efc4: stur            w1, [x0, #0x1b]
    // 0x121efc8: r1 = false
    //     0x121efc8: add             x1, NULL, #0x30  ; false
    // 0x121efcc: StoreField: r0->field_1f = r1
    //     0x121efcc: stur            w1, [x0, #0x1f]
    // 0x121efd0: ldur            x1, [fp, #-8]
    // 0x121efd4: StoreField: r0->field_23 = r1
    //     0x121efd4: stur            w1, [x0, #0x23]
    // 0x121efd8: LeaveFrame
    //     0x121efd8: mov             SP, fp
    //     0x121efdc: ldp             fp, lr, [SP], #0x10
    // 0x121efe0: ret
    //     0x121efe0: ret             
    // 0x121efe4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x121efe4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x121efe8: b               #0x121eee4
  }
}

// class id: 4615, size: 0x28, field offset: 0x8
//   const constructor, 
class NoDefaultCupertinoThemeData extends Object {

  get _ hashCode(/* No info */) {
    // ** addr: 0x1143bd0, size: 0x2c8
    // 0x1143bd0: EnterFrame
    //     0x1143bd0: stp             fp, lr, [SP, #-0x10]!
    //     0x1143bd4: mov             fp, SP
    // 0x1143bd8: AllocStack(0x48)
    //     0x1143bd8: sub             SP, SP, #0x48
    // 0x1143bdc: CheckStackOverflow
    //     0x1143bdc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1143be0: cmp             SP, x16
    //     0x1143be4: b.ls            #0x1143e90
    // 0x1143be8: ldr             x0, [fp, #0x10]
    // 0x1143bec: r3 = LoadClassIdInstr(r0)
    //     0x1143bec: ldur            x3, [x0, #-1]
    //     0x1143bf0: ubfx            x3, x3, #0xc, #0x14
    // 0x1143bf4: stur            x3, [fp, #-0x20]
    // 0x1143bf8: r17 = 4615
    //     0x1143bf8: mov             x17, #0x1207
    // 0x1143bfc: cmp             x3, x17
    // 0x1143c00: b.eq            #0x1143c10
    // 0x1143c04: r17 = 4617
    //     0x1143c04: mov             x17, #0x1209
    // 0x1143c08: cmp             x3, x17
    // 0x1143c0c: b.ne            #0x1143c20
    // 0x1143c10: LoadField: r1 = r0->field_7
    //     0x1143c10: ldur            w1, [x0, #7]
    // 0x1143c14: DecompressPointer r1
    //     0x1143c14: add             x1, x1, HEAP, lsl #32
    // 0x1143c18: mov             x4, x1
    // 0x1143c1c: b               #0x1143c3c
    // 0x1143c20: LoadField: r1 = r0->field_2b
    //     0x1143c20: ldur            w1, [x0, #0x2b]
    // 0x1143c24: DecompressPointer r1
    //     0x1143c24: add             x1, x1, HEAP, lsl #32
    // 0x1143c28: LoadField: r2 = r1->field_3f
    //     0x1143c28: ldur            w2, [x1, #0x3f]
    // 0x1143c2c: DecompressPointer r2
    //     0x1143c2c: add             x2, x2, HEAP, lsl #32
    // 0x1143c30: LoadField: r1 = r2->field_7
    //     0x1143c30: ldur            w1, [x2, #7]
    // 0x1143c34: DecompressPointer r1
    //     0x1143c34: add             x1, x1, HEAP, lsl #32
    // 0x1143c38: mov             x4, x1
    // 0x1143c3c: stur            x4, [fp, #-0x18]
    // 0x1143c40: r17 = 4615
    //     0x1143c40: mov             x17, #0x1207
    // 0x1143c44: cmp             x3, x17
    // 0x1143c48: b.ne            #0x1143c5c
    // 0x1143c4c: LoadField: r1 = r0->field_b
    //     0x1143c4c: ldur            w1, [x0, #0xb]
    // 0x1143c50: DecompressPointer r1
    //     0x1143c50: add             x1, x1, HEAP, lsl #32
    // 0x1143c54: mov             x5, x1
    // 0x1143c58: b               #0x1143c9c
    // 0x1143c5c: r17 = 4617
    //     0x1143c5c: mov             x17, #0x1209
    // 0x1143c60: cmp             x3, x17
    // 0x1143c64: b.ne            #0x1143c80
    // 0x1143c68: LoadField: r1 = r0->field_27
    //     0x1143c68: ldur            w1, [x0, #0x27]
    // 0x1143c6c: DecompressPointer r1
    //     0x1143c6c: add             x1, x1, HEAP, lsl #32
    // 0x1143c70: LoadField: r2 = r1->field_b
    //     0x1143c70: ldur            w2, [x1, #0xb]
    // 0x1143c74: DecompressPointer r2
    //     0x1143c74: add             x2, x2, HEAP, lsl #32
    // 0x1143c78: mov             x5, x2
    // 0x1143c7c: b               #0x1143c9c
    // 0x1143c80: LoadField: r1 = r0->field_2b
    //     0x1143c80: ldur            w1, [x0, #0x2b]
    // 0x1143c84: DecompressPointer r1
    //     0x1143c84: add             x1, x1, HEAP, lsl #32
    // 0x1143c88: LoadField: r2 = r1->field_3f
    //     0x1143c88: ldur            w2, [x1, #0x3f]
    // 0x1143c8c: DecompressPointer r2
    //     0x1143c8c: add             x2, x2, HEAP, lsl #32
    // 0x1143c90: LoadField: r1 = r2->field_b
    //     0x1143c90: ldur            w1, [x2, #0xb]
    // 0x1143c94: DecompressPointer r1
    //     0x1143c94: add             x1, x1, HEAP, lsl #32
    // 0x1143c98: mov             x5, x1
    // 0x1143c9c: stur            x5, [fp, #-0x10]
    // 0x1143ca0: r17 = 4615
    //     0x1143ca0: mov             x17, #0x1207
    // 0x1143ca4: cmp             x3, x17
    // 0x1143ca8: b.ne            #0x1143cbc
    // 0x1143cac: LoadField: r1 = r0->field_f
    //     0x1143cac: ldur            w1, [x0, #0xf]
    // 0x1143cb0: DecompressPointer r1
    //     0x1143cb0: add             x1, x1, HEAP, lsl #32
    // 0x1143cb4: mov             x6, x1
    // 0x1143cb8: b               #0x1143cf0
    // 0x1143cbc: r17 = 4617
    //     0x1143cbc: mov             x17, #0x1209
    // 0x1143cc0: cmp             x3, x17
    // 0x1143cc4: b.ne            #0x1143cd4
    // 0x1143cc8: r6 = Instance_Color
    //     0x1143cc8: add             x6, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0x1143ccc: ldr             x6, [x6, #0xc38]
    // 0x1143cd0: b               #0x1143cf0
    // 0x1143cd4: LoadField: r1 = r0->field_2b
    //     0x1143cd4: ldur            w1, [x0, #0x2b]
    // 0x1143cd8: DecompressPointer r1
    //     0x1143cd8: add             x1, x1, HEAP, lsl #32
    // 0x1143cdc: LoadField: r2 = r1->field_3f
    //     0x1143cdc: ldur            w2, [x1, #0x3f]
    // 0x1143ce0: DecompressPointer r2
    //     0x1143ce0: add             x2, x2, HEAP, lsl #32
    // 0x1143ce4: LoadField: r1 = r2->field_f
    //     0x1143ce4: ldur            w1, [x2, #0xf]
    // 0x1143ce8: DecompressPointer r1
    //     0x1143ce8: add             x1, x1, HEAP, lsl #32
    // 0x1143cec: mov             x6, x1
    // 0x1143cf0: stur            x6, [fp, #-8]
    // 0x1143cf4: r17 = -4617
    //     0x1143cf4: mov             x17, #-0x1209
    // 0x1143cf8: add             x16, x3, x17
    // 0x1143cfc: cmp             x16, #1
    // 0x1143d00: b.hi            #0x1143d7c
    // 0x1143d04: LoadField: r1 = r0->field_13
    //     0x1143d04: ldur            w1, [x0, #0x13]
    // 0x1143d08: DecompressPointer r1
    //     0x1143d08: add             x1, x1, HEAP, lsl #32
    // 0x1143d0c: cmp             w1, NULL
    // 0x1143d10: b.ne            #0x1143d6c
    // 0x1143d14: LoadField: r1 = r0->field_27
    //     0x1143d14: ldur            w1, [x0, #0x27]
    // 0x1143d18: DecompressPointer r1
    //     0x1143d18: add             x1, x1, HEAP, lsl #32
    // 0x1143d1c: LoadField: r2 = r1->field_23
    //     0x1143d1c: ldur            w2, [x1, #0x23]
    // 0x1143d20: DecompressPointer r2
    //     0x1143d20: add             x2, x2, HEAP, lsl #32
    // 0x1143d24: r17 = 4617
    //     0x1143d24: mov             x17, #0x1209
    // 0x1143d28: cmp             x3, x17
    // 0x1143d2c: b.ne            #0x1143d40
    // 0x1143d30: LoadField: r7 = r1->field_b
    //     0x1143d30: ldur            w7, [x1, #0xb]
    // 0x1143d34: DecompressPointer r7
    //     0x1143d34: add             x7, x7, HEAP, lsl #32
    // 0x1143d38: mov             x1, x7
    // 0x1143d3c: b               #0x1143d58
    // 0x1143d40: LoadField: r1 = r0->field_2b
    //     0x1143d40: ldur            w1, [x0, #0x2b]
    // 0x1143d44: DecompressPointer r1
    //     0x1143d44: add             x1, x1, HEAP, lsl #32
    // 0x1143d48: LoadField: r7 = r1->field_3f
    //     0x1143d48: ldur            w7, [x1, #0x3f]
    // 0x1143d4c: DecompressPointer r7
    //     0x1143d4c: add             x7, x7, HEAP, lsl #32
    // 0x1143d50: LoadField: r1 = r7->field_b
    //     0x1143d50: ldur            w1, [x7, #0xb]
    // 0x1143d54: DecompressPointer r1
    //     0x1143d54: add             x1, x1, HEAP, lsl #32
    // 0x1143d58: mov             x16, x1
    // 0x1143d5c: mov             x1, x2
    // 0x1143d60: mov             x2, x16
    // 0x1143d64: r0 = createDefaults()
    //     0x1143d64: bl              #0x1143e98  ; [package:flutter/src/cupertino/theme.dart] _CupertinoTextThemeDefaults::createDefaults
    // 0x1143d68: b               #0x1143d70
    // 0x1143d6c: mov             x0, x1
    // 0x1143d70: mov             x2, x0
    // 0x1143d74: ldr             x0, [fp, #0x10]
    // 0x1143d78: b               #0x1143d88
    // 0x1143d7c: LoadField: r1 = r0->field_13
    //     0x1143d7c: ldur            w1, [x0, #0x13]
    // 0x1143d80: DecompressPointer r1
    //     0x1143d80: add             x1, x1, HEAP, lsl #32
    // 0x1143d84: mov             x2, x1
    // 0x1143d88: ldur            x1, [fp, #-0x20]
    // 0x1143d8c: r17 = -4617
    //     0x1143d8c: mov             x17, #-0x1209
    // 0x1143d90: add             x16, x1, x17
    // 0x1143d94: cmp             x16, #1
    // 0x1143d98: b.hi            #0x1143db4
    // 0x1143d9c: LoadField: r3 = r0->field_27
    //     0x1143d9c: ldur            w3, [x0, #0x27]
    // 0x1143da0: DecompressPointer r3
    //     0x1143da0: add             x3, x3, HEAP, lsl #32
    // 0x1143da4: LoadField: r4 = r3->field_13
    //     0x1143da4: ldur            w4, [x3, #0x13]
    // 0x1143da8: DecompressPointer r4
    //     0x1143da8: add             x4, x4, HEAP, lsl #32
    // 0x1143dac: mov             x3, x4
    // 0x1143db0: b               #0x1143dbc
    // 0x1143db4: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x1143db4: ldur            w3, [x0, #0x17]
    // 0x1143db8: DecompressPointer r3
    //     0x1143db8: add             x3, x3, HEAP, lsl #32
    // 0x1143dbc: r17 = 4615
    //     0x1143dbc: mov             x17, #0x1207
    // 0x1143dc0: cmp             x1, x17
    // 0x1143dc4: b.ne            #0x1143dd4
    // 0x1143dc8: LoadField: r4 = r0->field_1b
    //     0x1143dc8: ldur            w4, [x0, #0x1b]
    // 0x1143dcc: DecompressPointer r4
    //     0x1143dcc: add             x4, x4, HEAP, lsl #32
    // 0x1143dd0: b               #0x1143e0c
    // 0x1143dd4: r17 = 4617
    //     0x1143dd4: mov             x17, #0x1209
    // 0x1143dd8: cmp             x1, x17
    // 0x1143ddc: b.ne            #0x1143df8
    // 0x1143de0: LoadField: r4 = r0->field_27
    //     0x1143de0: ldur            w4, [x0, #0x27]
    // 0x1143de4: DecompressPointer r4
    //     0x1143de4: add             x4, x4, HEAP, lsl #32
    // 0x1143de8: ArrayLoad: r5 = r4[0]  ; List_4
    //     0x1143de8: ldur            w5, [x4, #0x17]
    // 0x1143dec: DecompressPointer r5
    //     0x1143dec: add             x5, x5, HEAP, lsl #32
    // 0x1143df0: mov             x4, x5
    // 0x1143df4: b               #0x1143e0c
    // 0x1143df8: LoadField: r4 = r0->field_2b
    //     0x1143df8: ldur            w4, [x0, #0x2b]
    // 0x1143dfc: DecompressPointer r4
    //     0x1143dfc: add             x4, x4, HEAP, lsl #32
    // 0x1143e00: LoadField: r5 = r4->field_67
    //     0x1143e00: ldur            w5, [x4, #0x67]
    // 0x1143e04: DecompressPointer r5
    //     0x1143e04: add             x5, x5, HEAP, lsl #32
    // 0x1143e08: mov             x4, x5
    // 0x1143e0c: r17 = -4617
    //     0x1143e0c: mov             x17, #-0x1209
    // 0x1143e10: add             x16, x1, x17
    // 0x1143e14: cmp             x16, #1
    // 0x1143e18: b.hi            #0x1143e3c
    // 0x1143e1c: LoadField: r1 = r0->field_23
    //     0x1143e1c: ldur            w1, [x0, #0x23]
    // 0x1143e20: DecompressPointer r1
    //     0x1143e20: add             x1, x1, HEAP, lsl #32
    // 0x1143e24: cmp             w1, NULL
    // 0x1143e28: b.ne            #0x1143e34
    // 0x1143e2c: r0 = false
    //     0x1143e2c: add             x0, NULL, #0x30  ; false
    // 0x1143e30: b               #0x1143e48
    // 0x1143e34: mov             x0, x1
    // 0x1143e38: b               #0x1143e48
    // 0x1143e3c: LoadField: r1 = r0->field_23
    //     0x1143e3c: ldur            w1, [x0, #0x23]
    // 0x1143e40: DecompressPointer r1
    //     0x1143e40: add             x1, x1, HEAP, lsl #32
    // 0x1143e44: mov             x0, x1
    // 0x1143e48: ldur            x16, [fp, #-8]
    // 0x1143e4c: stp             x2, x16, [SP, #0x18]
    // 0x1143e50: stp             x4, x3, [SP, #8]
    // 0x1143e54: str             x0, [SP]
    // 0x1143e58: ldur            x1, [fp, #-0x18]
    // 0x1143e5c: ldur            x2, [fp, #-0x10]
    // 0x1143e60: r4 = const [0, 0x7, 0x5, 0x7, null]
    //     0x1143e60: add             x4, PP, #0xd, lsl #12  ; [pp+0xd8a0] List(5) [0, 0x7, 0x5, 0x7, Null]
    //     0x1143e64: ldr             x4, [x4, #0x8a0]
    // 0x1143e68: r0 = hash()
    //     0x1143e68: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x1143e6c: mov             x2, x0
    // 0x1143e70: r0 = BoxInt64Instr(r2)
    //     0x1143e70: sbfiz           x0, x2, #1, #0x1f
    //     0x1143e74: cmp             x2, x0, asr #1
    //     0x1143e78: b.eq            #0x1143e84
    //     0x1143e7c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1143e80: stur            x2, [x0, #7]
    // 0x1143e84: LeaveFrame
    //     0x1143e84: mov             SP, fp
    //     0x1143e88: ldp             fp, lr, [SP], #0x10
    // 0x1143e8c: ret
    //     0x1143e8c: ret             
    // 0x1143e90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1143e90: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1143e94: b               #0x1143be8
  }
  _ copyWith(/* No info */) {
    // ** addr: 0x121edb0, size: 0x3c
    // 0x121edb0: EnterFrame
    //     0x121edb0: stp             fp, lr, [SP, #-0x10]!
    //     0x121edb4: mov             fp, SP
    // 0x121edb8: AllocStack(0x10)
    //     0x121edb8: sub             SP, SP, #0x10
    // 0x121edbc: SetupParameters(dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x121edbc: stur            x2, [fp, #-0x10]
    // 0x121edc0: LoadField: r0 = r1->field_23
    //     0x121edc0: ldur            w0, [x1, #0x23]
    // 0x121edc4: DecompressPointer r0
    //     0x121edc4: add             x0, x0, HEAP, lsl #32
    // 0x121edc8: stur            x0, [fp, #-8]
    // 0x121edcc: r0 = NoDefaultCupertinoThemeData()
    //     0x121edcc: bl              #0xfbf188  ; AllocateNoDefaultCupertinoThemeDataStub -> NoDefaultCupertinoThemeData (size=0x28)
    // 0x121edd0: ldur            x1, [fp, #-0x10]
    // 0x121edd4: StoreField: r0->field_13 = r1
    //     0x121edd4: stur            w1, [x0, #0x13]
    // 0x121edd8: ldur            x1, [fp, #-8]
    // 0x121eddc: StoreField: r0->field_23 = r1
    //     0x121eddc: stur            w1, [x0, #0x23]
    // 0x121ede0: LeaveFrame
    //     0x121ede0: mov             SP, fp
    //     0x121ede4: ldp             fp, lr, [SP], #0x10
    // 0x121ede8: ret
    //     0x121ede8: ret             
  }
  _ resolveFrom(/* No info */) {
    // ** addr: 0x121f1e0, size: 0x7c
    // 0x121f1e0: EnterFrame
    //     0x121f1e0: stp             fp, lr, [SP, #-0x10]!
    //     0x121f1e4: mov             fp, SP
    // 0x121f1e8: AllocStack(0x18)
    //     0x121f1e8: sub             SP, SP, #0x18
    // 0x121f1ec: SetupParameters(NoDefaultCupertinoThemeData this /* r1 => r0, fp-0x8 */)
    //     0x121f1ec: mov             x0, x1
    //     0x121f1f0: stur            x1, [fp, #-8]
    // 0x121f1f4: CheckStackOverflow
    //     0x121f1f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x121f1f8: cmp             SP, x16
    //     0x121f1fc: b.ls            #0x121f254
    // 0x121f200: LoadField: r1 = r0->field_13
    //     0x121f200: ldur            w1, [x0, #0x13]
    // 0x121f204: DecompressPointer r1
    //     0x121f204: add             x1, x1, HEAP, lsl #32
    // 0x121f208: cmp             w1, NULL
    // 0x121f20c: b.ne            #0x121f218
    // 0x121f210: r1 = Null
    //     0x121f210: mov             x1, NULL
    // 0x121f214: b               #0x121f224
    // 0x121f218: r0 = resolveFrom()
    //     0x121f218: bl              #0x121f084  ; [package:flutter/src/cupertino/text_theme.dart] CupertinoTextThemeData::resolveFrom
    // 0x121f21c: mov             x1, x0
    // 0x121f220: ldur            x0, [fp, #-8]
    // 0x121f224: stur            x1, [fp, #-0x18]
    // 0x121f228: LoadField: r2 = r0->field_23
    //     0x121f228: ldur            w2, [x0, #0x23]
    // 0x121f22c: DecompressPointer r2
    //     0x121f22c: add             x2, x2, HEAP, lsl #32
    // 0x121f230: stur            x2, [fp, #-0x10]
    // 0x121f234: r0 = NoDefaultCupertinoThemeData()
    //     0x121f234: bl              #0xfbf188  ; AllocateNoDefaultCupertinoThemeDataStub -> NoDefaultCupertinoThemeData (size=0x28)
    // 0x121f238: ldur            x1, [fp, #-0x18]
    // 0x121f23c: StoreField: r0->field_13 = r1
    //     0x121f23c: stur            w1, [x0, #0x13]
    // 0x121f240: ldur            x1, [fp, #-0x10]
    // 0x121f244: StoreField: r0->field_23 = r1
    //     0x121f244: stur            w1, [x0, #0x23]
    // 0x121f248: LeaveFrame
    //     0x121f248: mov             SP, fp
    //     0x121f24c: ldp             fp, lr, [SP], #0x10
    // 0x121f250: ret
    //     0x121f250: ret             
    // 0x121f254: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x121f254: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x121f258: b               #0x121f200
  }
  _ ==(/* No info */) {
    // ** addr: 0x12831dc, size: 0x63c
    // 0x12831dc: EnterFrame
    //     0x12831dc: stp             fp, lr, [SP, #-0x10]!
    //     0x12831e0: mov             fp, SP
    // 0x12831e4: AllocStack(0x28)
    //     0x12831e4: sub             SP, SP, #0x28
    // 0x12831e8: CheckStackOverflow
    //     0x12831e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12831ec: cmp             SP, x16
    //     0x12831f0: b.ls            #0x1283810
    // 0x12831f4: ldr             x0, [fp, #0x10]
    // 0x12831f8: cmp             w0, NULL
    // 0x12831fc: b.ne            #0x1283210
    // 0x1283200: r0 = false
    //     0x1283200: add             x0, NULL, #0x30  ; false
    // 0x1283204: LeaveFrame
    //     0x1283204: mov             SP, fp
    //     0x1283208: ldp             fp, lr, [SP], #0x10
    // 0x128320c: ret
    //     0x128320c: ret             
    // 0x1283210: ldr             x1, [fp, #0x18]
    // 0x1283214: cmp             w1, w0
    // 0x1283218: b.ne            #0x128322c
    // 0x128321c: r0 = true
    //     0x128321c: add             x0, NULL, #0x20  ; true
    // 0x1283220: LeaveFrame
    //     0x1283220: mov             SP, fp
    //     0x1283224: ldp             fp, lr, [SP], #0x10
    // 0x1283228: ret
    //     0x1283228: ret             
    // 0x128322c: stp             x1, x0, [SP]
    // 0x1283230: r0 = _haveSameRuntimeType()
    //     0x1283230: bl              #0x88249c  ; [dart:core] Object::_haveSameRuntimeType
    // 0x1283234: tbz             w0, #4, #0x1283248
    // 0x1283238: r0 = false
    //     0x1283238: add             x0, NULL, #0x30  ; false
    // 0x128323c: LeaveFrame
    //     0x128323c: mov             SP, fp
    //     0x1283240: ldp             fp, lr, [SP], #0x10
    // 0x1283244: ret
    //     0x1283244: ret             
    // 0x1283248: ldr             x1, [fp, #0x10]
    // 0x128324c: r2 = 60
    //     0x128324c: mov             x2, #0x3c
    // 0x1283250: branchIfSmi(r1, 0x128325c)
    //     0x1283250: tbz             w1, #0, #0x128325c
    // 0x1283254: r2 = LoadClassIdInstr(r1)
    //     0x1283254: ldur            x2, [x1, #-1]
    //     0x1283258: ubfx            x2, x2, #0xc, #0x14
    // 0x128325c: stur            x2, [fp, #-0x10]
    // 0x1283260: r17 = -4615
    //     0x1283260: mov             x17, #-0x1207
    // 0x1283264: add             x16, x2, x17
    // 0x1283268: cmp             x16, #3
    // 0x128326c: b.hi            #0x1283800
    // 0x1283270: r17 = 4615
    //     0x1283270: mov             x17, #0x1207
    // 0x1283274: cmp             x2, x17
    // 0x1283278: b.eq            #0x1283288
    // 0x128327c: r17 = 4617
    //     0x128327c: mov             x17, #0x1209
    // 0x1283280: cmp             x2, x17
    // 0x1283284: b.ne            #0x1283294
    // 0x1283288: LoadField: r0 = r1->field_7
    //     0x1283288: ldur            w0, [x1, #7]
    // 0x128328c: DecompressPointer r0
    //     0x128328c: add             x0, x0, HEAP, lsl #32
    // 0x1283290: b               #0x12832ac
    // 0x1283294: LoadField: r0 = r1->field_2b
    //     0x1283294: ldur            w0, [x1, #0x2b]
    // 0x1283298: DecompressPointer r0
    //     0x1283298: add             x0, x0, HEAP, lsl #32
    // 0x128329c: LoadField: r3 = r0->field_3f
    //     0x128329c: ldur            w3, [x0, #0x3f]
    // 0x12832a0: DecompressPointer r3
    //     0x12832a0: add             x3, x3, HEAP, lsl #32
    // 0x12832a4: LoadField: r0 = r3->field_7
    //     0x12832a4: ldur            w0, [x3, #7]
    // 0x12832a8: DecompressPointer r0
    //     0x12832a8: add             x0, x0, HEAP, lsl #32
    // 0x12832ac: ldr             x3, [fp, #0x18]
    // 0x12832b0: r4 = LoadClassIdInstr(r3)
    //     0x12832b0: ldur            x4, [x3, #-1]
    //     0x12832b4: ubfx            x4, x4, #0xc, #0x14
    // 0x12832b8: stur            x4, [fp, #-8]
    // 0x12832bc: r17 = 4615
    //     0x12832bc: mov             x17, #0x1207
    // 0x12832c0: cmp             x4, x17
    // 0x12832c4: b.eq            #0x12832d4
    // 0x12832c8: r17 = 4617
    //     0x12832c8: mov             x17, #0x1209
    // 0x12832cc: cmp             x4, x17
    // 0x12832d0: b.ne            #0x12832e0
    // 0x12832d4: LoadField: r5 = r3->field_7
    //     0x12832d4: ldur            w5, [x3, #7]
    // 0x12832d8: DecompressPointer r5
    //     0x12832d8: add             x5, x5, HEAP, lsl #32
    // 0x12832dc: b               #0x12832f8
    // 0x12832e0: LoadField: r5 = r3->field_2b
    //     0x12832e0: ldur            w5, [x3, #0x2b]
    // 0x12832e4: DecompressPointer r5
    //     0x12832e4: add             x5, x5, HEAP, lsl #32
    // 0x12832e8: LoadField: r6 = r5->field_3f
    //     0x12832e8: ldur            w6, [x5, #0x3f]
    // 0x12832ec: DecompressPointer r6
    //     0x12832ec: add             x6, x6, HEAP, lsl #32
    // 0x12832f0: LoadField: r5 = r6->field_7
    //     0x12832f0: ldur            w5, [x6, #7]
    // 0x12832f4: DecompressPointer r5
    //     0x12832f4: add             x5, x5, HEAP, lsl #32
    // 0x12832f8: cmp             w0, w5
    // 0x12832fc: b.ne            #0x1283800
    // 0x1283300: r17 = 4615
    //     0x1283300: mov             x17, #0x1207
    // 0x1283304: cmp             x2, x17
    // 0x1283308: b.ne            #0x1283318
    // 0x128330c: LoadField: r0 = r1->field_b
    //     0x128330c: ldur            w0, [x1, #0xb]
    // 0x1283310: DecompressPointer r0
    //     0x1283310: add             x0, x0, HEAP, lsl #32
    // 0x1283314: b               #0x1283354
    // 0x1283318: r17 = 4617
    //     0x1283318: mov             x17, #0x1209
    // 0x128331c: cmp             x2, x17
    // 0x1283320: b.ne            #0x128333c
    // 0x1283324: LoadField: r0 = r1->field_27
    //     0x1283324: ldur            w0, [x1, #0x27]
    // 0x1283328: DecompressPointer r0
    //     0x1283328: add             x0, x0, HEAP, lsl #32
    // 0x128332c: LoadField: r5 = r0->field_b
    //     0x128332c: ldur            w5, [x0, #0xb]
    // 0x1283330: DecompressPointer r5
    //     0x1283330: add             x5, x5, HEAP, lsl #32
    // 0x1283334: mov             x0, x5
    // 0x1283338: b               #0x1283354
    // 0x128333c: LoadField: r0 = r1->field_2b
    //     0x128333c: ldur            w0, [x1, #0x2b]
    // 0x1283340: DecompressPointer r0
    //     0x1283340: add             x0, x0, HEAP, lsl #32
    // 0x1283344: LoadField: r5 = r0->field_3f
    //     0x1283344: ldur            w5, [x0, #0x3f]
    // 0x1283348: DecompressPointer r5
    //     0x1283348: add             x5, x5, HEAP, lsl #32
    // 0x128334c: LoadField: r0 = r5->field_b
    //     0x128334c: ldur            w0, [x5, #0xb]
    // 0x1283350: DecompressPointer r0
    //     0x1283350: add             x0, x0, HEAP, lsl #32
    // 0x1283354: r17 = 4615
    //     0x1283354: mov             x17, #0x1207
    // 0x1283358: cmp             x4, x17
    // 0x128335c: b.ne            #0x128336c
    // 0x1283360: LoadField: r5 = r3->field_b
    //     0x1283360: ldur            w5, [x3, #0xb]
    // 0x1283364: DecompressPointer r5
    //     0x1283364: add             x5, x5, HEAP, lsl #32
    // 0x1283368: b               #0x12833a8
    // 0x128336c: r17 = 4617
    //     0x128336c: mov             x17, #0x1209
    // 0x1283370: cmp             x4, x17
    // 0x1283374: b.ne            #0x1283390
    // 0x1283378: LoadField: r5 = r3->field_27
    //     0x1283378: ldur            w5, [x3, #0x27]
    // 0x128337c: DecompressPointer r5
    //     0x128337c: add             x5, x5, HEAP, lsl #32
    // 0x1283380: LoadField: r6 = r5->field_b
    //     0x1283380: ldur            w6, [x5, #0xb]
    // 0x1283384: DecompressPointer r6
    //     0x1283384: add             x6, x6, HEAP, lsl #32
    // 0x1283388: mov             x5, x6
    // 0x128338c: b               #0x12833a8
    // 0x1283390: LoadField: r5 = r3->field_2b
    //     0x1283390: ldur            w5, [x3, #0x2b]
    // 0x1283394: DecompressPointer r5
    //     0x1283394: add             x5, x5, HEAP, lsl #32
    // 0x1283398: LoadField: r6 = r5->field_3f
    //     0x1283398: ldur            w6, [x5, #0x3f]
    // 0x128339c: DecompressPointer r6
    //     0x128339c: add             x6, x6, HEAP, lsl #32
    // 0x12833a0: LoadField: r5 = r6->field_b
    //     0x12833a0: ldur            w5, [x6, #0xb]
    // 0x12833a4: DecompressPointer r5
    //     0x12833a4: add             x5, x5, HEAP, lsl #32
    // 0x12833a8: r6 = LoadClassIdInstr(r0)
    //     0x12833a8: ldur            x6, [x0, #-1]
    //     0x12833ac: ubfx            x6, x6, #0xc, #0x14
    // 0x12833b0: stp             x5, x0, [SP]
    // 0x12833b4: mov             x0, x6
    // 0x12833b8: mov             lr, x0
    // 0x12833bc: ldr             lr, [x21, lr, lsl #3]
    // 0x12833c0: blr             lr
    // 0x12833c4: tbnz            w0, #4, #0x1283800
    // 0x12833c8: ldur            x1, [fp, #-0x10]
    // 0x12833cc: r17 = 4615
    //     0x12833cc: mov             x17, #0x1207
    // 0x12833d0: cmp             x1, x17
    // 0x12833d4: b.ne            #0x12833e8
    // 0x12833d8: ldr             x2, [fp, #0x10]
    // 0x12833dc: LoadField: r0 = r2->field_f
    //     0x12833dc: ldur            w0, [x2, #0xf]
    // 0x12833e0: DecompressPointer r0
    //     0x12833e0: add             x0, x0, HEAP, lsl #32
    // 0x12833e4: b               #0x128341c
    // 0x12833e8: ldr             x2, [fp, #0x10]
    // 0x12833ec: r17 = 4617
    //     0x12833ec: mov             x17, #0x1209
    // 0x12833f0: cmp             x1, x17
    // 0x12833f4: b.ne            #0x1283404
    // 0x12833f8: r0 = Instance_Color
    //     0x12833f8: add             x0, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0x12833fc: ldr             x0, [x0, #0xc38]
    // 0x1283400: b               #0x128341c
    // 0x1283404: LoadField: r0 = r2->field_2b
    //     0x1283404: ldur            w0, [x2, #0x2b]
    // 0x1283408: DecompressPointer r0
    //     0x1283408: add             x0, x0, HEAP, lsl #32
    // 0x128340c: LoadField: r3 = r0->field_3f
    //     0x128340c: ldur            w3, [x0, #0x3f]
    // 0x1283410: DecompressPointer r3
    //     0x1283410: add             x3, x3, HEAP, lsl #32
    // 0x1283414: LoadField: r0 = r3->field_f
    //     0x1283414: ldur            w0, [x3, #0xf]
    // 0x1283418: DecompressPointer r0
    //     0x1283418: add             x0, x0, HEAP, lsl #32
    // 0x128341c: ldur            x3, [fp, #-8]
    // 0x1283420: r17 = 4615
    //     0x1283420: mov             x17, #0x1207
    // 0x1283424: cmp             x3, x17
    // 0x1283428: b.ne            #0x128343c
    // 0x128342c: ldr             x4, [fp, #0x18]
    // 0x1283430: LoadField: r5 = r4->field_f
    //     0x1283430: ldur            w5, [x4, #0xf]
    // 0x1283434: DecompressPointer r5
    //     0x1283434: add             x5, x5, HEAP, lsl #32
    // 0x1283438: b               #0x1283470
    // 0x128343c: ldr             x4, [fp, #0x18]
    // 0x1283440: r17 = 4617
    //     0x1283440: mov             x17, #0x1209
    // 0x1283444: cmp             x3, x17
    // 0x1283448: b.ne            #0x1283458
    // 0x128344c: r5 = Instance_Color
    //     0x128344c: add             x5, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0x1283450: ldr             x5, [x5, #0xc38]
    // 0x1283454: b               #0x1283470
    // 0x1283458: LoadField: r5 = r4->field_2b
    //     0x1283458: ldur            w5, [x4, #0x2b]
    // 0x128345c: DecompressPointer r5
    //     0x128345c: add             x5, x5, HEAP, lsl #32
    // 0x1283460: LoadField: r6 = r5->field_3f
    //     0x1283460: ldur            w6, [x5, #0x3f]
    // 0x1283464: DecompressPointer r6
    //     0x1283464: add             x6, x6, HEAP, lsl #32
    // 0x1283468: LoadField: r5 = r6->field_f
    //     0x1283468: ldur            w5, [x6, #0xf]
    // 0x128346c: DecompressPointer r5
    //     0x128346c: add             x5, x5, HEAP, lsl #32
    // 0x1283470: r6 = LoadClassIdInstr(r0)
    //     0x1283470: ldur            x6, [x0, #-1]
    //     0x1283474: ubfx            x6, x6, #0xc, #0x14
    // 0x1283478: stp             x5, x0, [SP]
    // 0x128347c: mov             x0, x6
    // 0x1283480: mov             lr, x0
    // 0x1283484: ldr             lr, [x21, lr, lsl #3]
    // 0x1283488: blr             lr
    // 0x128348c: tbnz            w0, #4, #0x1283800
    // 0x1283490: ldur            x0, [fp, #-0x10]
    // 0x1283494: r17 = -4617
    //     0x1283494: mov             x17, #-0x1209
    // 0x1283498: add             x16, x0, x17
    // 0x128349c: cmp             x16, #1
    // 0x12834a0: b.hi            #0x1283520
    // 0x12834a4: ldr             x3, [fp, #0x10]
    // 0x12834a8: LoadField: r1 = r3->field_13
    //     0x12834a8: ldur            w1, [x3, #0x13]
    // 0x12834ac: DecompressPointer r1
    //     0x12834ac: add             x1, x1, HEAP, lsl #32
    // 0x12834b0: cmp             w1, NULL
    // 0x12834b4: b.ne            #0x1283510
    // 0x12834b8: LoadField: r1 = r3->field_27
    //     0x12834b8: ldur            w1, [x3, #0x27]
    // 0x12834bc: DecompressPointer r1
    //     0x12834bc: add             x1, x1, HEAP, lsl #32
    // 0x12834c0: LoadField: r2 = r1->field_23
    //     0x12834c0: ldur            w2, [x1, #0x23]
    // 0x12834c4: DecompressPointer r2
    //     0x12834c4: add             x2, x2, HEAP, lsl #32
    // 0x12834c8: r17 = 4617
    //     0x12834c8: mov             x17, #0x1209
    // 0x12834cc: cmp             x0, x17
    // 0x12834d0: b.ne            #0x12834e4
    // 0x12834d4: LoadField: r4 = r1->field_b
    //     0x12834d4: ldur            w4, [x1, #0xb]
    // 0x12834d8: DecompressPointer r4
    //     0x12834d8: add             x4, x4, HEAP, lsl #32
    // 0x12834dc: mov             x1, x4
    // 0x12834e0: b               #0x12834fc
    // 0x12834e4: LoadField: r1 = r3->field_2b
    //     0x12834e4: ldur            w1, [x3, #0x2b]
    // 0x12834e8: DecompressPointer r1
    //     0x12834e8: add             x1, x1, HEAP, lsl #32
    // 0x12834ec: LoadField: r4 = r1->field_3f
    //     0x12834ec: ldur            w4, [x1, #0x3f]
    // 0x12834f0: DecompressPointer r4
    //     0x12834f0: add             x4, x4, HEAP, lsl #32
    // 0x12834f4: LoadField: r1 = r4->field_b
    //     0x12834f4: ldur            w1, [x4, #0xb]
    // 0x12834f8: DecompressPointer r1
    //     0x12834f8: add             x1, x1, HEAP, lsl #32
    // 0x12834fc: mov             x16, x1
    // 0x1283500: mov             x1, x2
    // 0x1283504: mov             x2, x16
    // 0x1283508: r0 = createDefaults()
    //     0x1283508: bl              #0x1143e98  ; [package:flutter/src/cupertino/theme.dart] _CupertinoTextThemeDefaults::createDefaults
    // 0x128350c: b               #0x1283514
    // 0x1283510: mov             x0, x1
    // 0x1283514: mov             x4, x0
    // 0x1283518: ldr             x0, [fp, #0x10]
    // 0x128351c: b               #0x1283530
    // 0x1283520: ldr             x0, [fp, #0x10]
    // 0x1283524: LoadField: r1 = r0->field_13
    //     0x1283524: ldur            w1, [x0, #0x13]
    // 0x1283528: DecompressPointer r1
    //     0x1283528: add             x1, x1, HEAP, lsl #32
    // 0x128352c: mov             x4, x1
    // 0x1283530: ldur            x3, [fp, #-8]
    // 0x1283534: stur            x4, [fp, #-0x18]
    // 0x1283538: r17 = -4617
    //     0x1283538: mov             x17, #-0x1209
    // 0x128353c: add             x16, x3, x17
    // 0x1283540: cmp             x16, #1
    // 0x1283544: b.hi            #0x12835c4
    // 0x1283548: ldr             x5, [fp, #0x18]
    // 0x128354c: LoadField: r1 = r5->field_13
    //     0x128354c: ldur            w1, [x5, #0x13]
    // 0x1283550: DecompressPointer r1
    //     0x1283550: add             x1, x1, HEAP, lsl #32
    // 0x1283554: cmp             w1, NULL
    // 0x1283558: b.ne            #0x12835b4
    // 0x128355c: LoadField: r1 = r5->field_27
    //     0x128355c: ldur            w1, [x5, #0x27]
    // 0x1283560: DecompressPointer r1
    //     0x1283560: add             x1, x1, HEAP, lsl #32
    // 0x1283564: LoadField: r2 = r1->field_23
    //     0x1283564: ldur            w2, [x1, #0x23]
    // 0x1283568: DecompressPointer r2
    //     0x1283568: add             x2, x2, HEAP, lsl #32
    // 0x128356c: r17 = 4617
    //     0x128356c: mov             x17, #0x1209
    // 0x1283570: cmp             x3, x17
    // 0x1283574: b.ne            #0x1283588
    // 0x1283578: LoadField: r6 = r1->field_b
    //     0x1283578: ldur            w6, [x1, #0xb]
    // 0x128357c: DecompressPointer r6
    //     0x128357c: add             x6, x6, HEAP, lsl #32
    // 0x1283580: mov             x1, x6
    // 0x1283584: b               #0x12835a0
    // 0x1283588: LoadField: r1 = r5->field_2b
    //     0x1283588: ldur            w1, [x5, #0x2b]
    // 0x128358c: DecompressPointer r1
    //     0x128358c: add             x1, x1, HEAP, lsl #32
    // 0x1283590: LoadField: r6 = r1->field_3f
    //     0x1283590: ldur            w6, [x1, #0x3f]
    // 0x1283594: DecompressPointer r6
    //     0x1283594: add             x6, x6, HEAP, lsl #32
    // 0x1283598: LoadField: r1 = r6->field_b
    //     0x1283598: ldur            w1, [x6, #0xb]
    // 0x128359c: DecompressPointer r1
    //     0x128359c: add             x1, x1, HEAP, lsl #32
    // 0x12835a0: mov             x16, x1
    // 0x12835a4: mov             x1, x2
    // 0x12835a8: mov             x2, x16
    // 0x12835ac: r0 = createDefaults()
    //     0x12835ac: bl              #0x1143e98  ; [package:flutter/src/cupertino/theme.dart] _CupertinoTextThemeDefaults::createDefaults
    // 0x12835b0: b               #0x12835b8
    // 0x12835b4: mov             x0, x1
    // 0x12835b8: mov             x2, x0
    // 0x12835bc: ldr             x1, [fp, #0x18]
    // 0x12835c0: b               #0x12835d4
    // 0x12835c4: ldr             x1, [fp, #0x18]
    // 0x12835c8: LoadField: r0 = r1->field_13
    //     0x12835c8: ldur            w0, [x1, #0x13]
    // 0x12835cc: DecompressPointer r0
    //     0x12835cc: add             x0, x0, HEAP, lsl #32
    // 0x12835d0: mov             x2, x0
    // 0x12835d4: ldur            x0, [fp, #-0x18]
    // 0x12835d8: r3 = LoadClassIdInstr(r0)
    //     0x12835d8: ldur            x3, [x0, #-1]
    //     0x12835dc: ubfx            x3, x3, #0xc, #0x14
    // 0x12835e0: stp             x2, x0, [SP]
    // 0x12835e4: mov             x0, x3
    // 0x12835e8: mov             lr, x0
    // 0x12835ec: ldr             lr, [x21, lr, lsl #3]
    // 0x12835f0: blr             lr
    // 0x12835f4: tbnz            w0, #4, #0x1283800
    // 0x12835f8: ldur            x1, [fp, #-0x10]
    // 0x12835fc: r17 = -4617
    //     0x12835fc: mov             x17, #-0x1209
    // 0x1283600: add             x16, x1, x17
    // 0x1283604: cmp             x16, #1
    // 0x1283608: b.hi            #0x1283628
    // 0x128360c: ldr             x2, [fp, #0x10]
    // 0x1283610: LoadField: r0 = r2->field_27
    //     0x1283610: ldur            w0, [x2, #0x27]
    // 0x1283614: DecompressPointer r0
    //     0x1283614: add             x0, x0, HEAP, lsl #32
    // 0x1283618: LoadField: r3 = r0->field_13
    //     0x1283618: ldur            w3, [x0, #0x13]
    // 0x128361c: DecompressPointer r3
    //     0x128361c: add             x3, x3, HEAP, lsl #32
    // 0x1283620: mov             x0, x3
    // 0x1283624: b               #0x1283634
    // 0x1283628: ldr             x2, [fp, #0x10]
    // 0x128362c: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x128362c: ldur            w0, [x2, #0x17]
    // 0x1283630: DecompressPointer r0
    //     0x1283630: add             x0, x0, HEAP, lsl #32
    // 0x1283634: ldur            x3, [fp, #-8]
    // 0x1283638: r17 = -4617
    //     0x1283638: mov             x17, #-0x1209
    // 0x128363c: add             x16, x3, x17
    // 0x1283640: cmp             x16, #1
    // 0x1283644: b.hi            #0x1283664
    // 0x1283648: ldr             x4, [fp, #0x18]
    // 0x128364c: LoadField: r5 = r4->field_27
    //     0x128364c: ldur            w5, [x4, #0x27]
    // 0x1283650: DecompressPointer r5
    //     0x1283650: add             x5, x5, HEAP, lsl #32
    // 0x1283654: LoadField: r6 = r5->field_13
    //     0x1283654: ldur            w6, [x5, #0x13]
    // 0x1283658: DecompressPointer r6
    //     0x1283658: add             x6, x6, HEAP, lsl #32
    // 0x128365c: mov             x5, x6
    // 0x1283660: b               #0x1283670
    // 0x1283664: ldr             x4, [fp, #0x18]
    // 0x1283668: ArrayLoad: r5 = r4[0]  ; List_4
    //     0x1283668: ldur            w5, [x4, #0x17]
    // 0x128366c: DecompressPointer r5
    //     0x128366c: add             x5, x5, HEAP, lsl #32
    // 0x1283670: r6 = LoadClassIdInstr(r0)
    //     0x1283670: ldur            x6, [x0, #-1]
    //     0x1283674: ubfx            x6, x6, #0xc, #0x14
    // 0x1283678: stp             x5, x0, [SP]
    // 0x128367c: mov             x0, x6
    // 0x1283680: mov             lr, x0
    // 0x1283684: ldr             lr, [x21, lr, lsl #3]
    // 0x1283688: blr             lr
    // 0x128368c: tbnz            w0, #4, #0x1283800
    // 0x1283690: ldur            x1, [fp, #-0x10]
    // 0x1283694: r17 = 4615
    //     0x1283694: mov             x17, #0x1207
    // 0x1283698: cmp             x1, x17
    // 0x128369c: b.ne            #0x12836b0
    // 0x12836a0: ldr             x2, [fp, #0x10]
    // 0x12836a4: LoadField: r0 = r2->field_1b
    //     0x12836a4: ldur            w0, [x2, #0x1b]
    // 0x12836a8: DecompressPointer r0
    //     0x12836a8: add             x0, x0, HEAP, lsl #32
    // 0x12836ac: b               #0x12836ec
    // 0x12836b0: ldr             x2, [fp, #0x10]
    // 0x12836b4: r17 = 4617
    //     0x12836b4: mov             x17, #0x1209
    // 0x12836b8: cmp             x1, x17
    // 0x12836bc: b.ne            #0x12836d8
    // 0x12836c0: LoadField: r0 = r2->field_27
    //     0x12836c0: ldur            w0, [x2, #0x27]
    // 0x12836c4: DecompressPointer r0
    //     0x12836c4: add             x0, x0, HEAP, lsl #32
    // 0x12836c8: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x12836c8: ldur            w3, [x0, #0x17]
    // 0x12836cc: DecompressPointer r3
    //     0x12836cc: add             x3, x3, HEAP, lsl #32
    // 0x12836d0: mov             x0, x3
    // 0x12836d4: b               #0x12836ec
    // 0x12836d8: LoadField: r0 = r2->field_2b
    //     0x12836d8: ldur            w0, [x2, #0x2b]
    // 0x12836dc: DecompressPointer r0
    //     0x12836dc: add             x0, x0, HEAP, lsl #32
    // 0x12836e0: LoadField: r3 = r0->field_67
    //     0x12836e0: ldur            w3, [x0, #0x67]
    // 0x12836e4: DecompressPointer r3
    //     0x12836e4: add             x3, x3, HEAP, lsl #32
    // 0x12836e8: mov             x0, x3
    // 0x12836ec: ldur            x3, [fp, #-8]
    // 0x12836f0: r17 = 4615
    //     0x12836f0: mov             x17, #0x1207
    // 0x12836f4: cmp             x3, x17
    // 0x12836f8: b.ne            #0x128370c
    // 0x12836fc: ldr             x4, [fp, #0x18]
    // 0x1283700: LoadField: r5 = r4->field_1b
    //     0x1283700: ldur            w5, [x4, #0x1b]
    // 0x1283704: DecompressPointer r5
    //     0x1283704: add             x5, x5, HEAP, lsl #32
    // 0x1283708: b               #0x1283748
    // 0x128370c: ldr             x4, [fp, #0x18]
    // 0x1283710: r17 = 4617
    //     0x1283710: mov             x17, #0x1209
    // 0x1283714: cmp             x3, x17
    // 0x1283718: b.ne            #0x1283734
    // 0x128371c: LoadField: r5 = r4->field_27
    //     0x128371c: ldur            w5, [x4, #0x27]
    // 0x1283720: DecompressPointer r5
    //     0x1283720: add             x5, x5, HEAP, lsl #32
    // 0x1283724: ArrayLoad: r6 = r5[0]  ; List_4
    //     0x1283724: ldur            w6, [x5, #0x17]
    // 0x1283728: DecompressPointer r6
    //     0x1283728: add             x6, x6, HEAP, lsl #32
    // 0x128372c: mov             x5, x6
    // 0x1283730: b               #0x1283748
    // 0x1283734: LoadField: r5 = r4->field_2b
    //     0x1283734: ldur            w5, [x4, #0x2b]
    // 0x1283738: DecompressPointer r5
    //     0x1283738: add             x5, x5, HEAP, lsl #32
    // 0x128373c: LoadField: r6 = r5->field_67
    //     0x128373c: ldur            w6, [x5, #0x67]
    // 0x1283740: DecompressPointer r6
    //     0x1283740: add             x6, x6, HEAP, lsl #32
    // 0x1283744: mov             x5, x6
    // 0x1283748: r6 = LoadClassIdInstr(r0)
    //     0x1283748: ldur            x6, [x0, #-1]
    //     0x128374c: ubfx            x6, x6, #0xc, #0x14
    // 0x1283750: stp             x5, x0, [SP]
    // 0x1283754: mov             x0, x6
    // 0x1283758: mov             lr, x0
    // 0x128375c: ldr             lr, [x21, lr, lsl #3]
    // 0x1283760: blr             lr
    // 0x1283764: tbnz            w0, #4, #0x1283800
    // 0x1283768: ldur            x1, [fp, #-0x10]
    // 0x128376c: r17 = -4617
    //     0x128376c: mov             x17, #-0x1209
    // 0x1283770: add             x16, x1, x17
    // 0x1283774: cmp             x16, #1
    // 0x1283778: b.hi            #0x1283798
    // 0x128377c: ldr             x1, [fp, #0x10]
    // 0x1283780: LoadField: r2 = r1->field_23
    //     0x1283780: ldur            w2, [x1, #0x23]
    // 0x1283784: DecompressPointer r2
    //     0x1283784: add             x2, x2, HEAP, lsl #32
    // 0x1283788: cmp             w2, NULL
    // 0x128378c: b.ne            #0x12837a4
    // 0x1283790: r2 = false
    //     0x1283790: add             x2, NULL, #0x30  ; false
    // 0x1283794: b               #0x12837a4
    // 0x1283798: ldr             x1, [fp, #0x10]
    // 0x128379c: LoadField: r2 = r1->field_23
    //     0x128379c: ldur            w2, [x1, #0x23]
    // 0x12837a0: DecompressPointer r2
    //     0x12837a0: add             x2, x2, HEAP, lsl #32
    // 0x12837a4: ldur            x1, [fp, #-8]
    // 0x12837a8: r17 = -4617
    //     0x12837a8: mov             x17, #-0x1209
    // 0x12837ac: add             x16, x1, x17
    // 0x12837b0: cmp             x16, #1
    // 0x12837b4: b.hi            #0x12837d8
    // 0x12837b8: ldr             x1, [fp, #0x18]
    // 0x12837bc: LoadField: r3 = r1->field_23
    //     0x12837bc: ldur            w3, [x1, #0x23]
    // 0x12837c0: DecompressPointer r3
    //     0x12837c0: add             x3, x3, HEAP, lsl #32
    // 0x12837c4: cmp             w3, NULL
    // 0x12837c8: b.ne            #0x12837d0
    // 0x12837cc: r3 = false
    //     0x12837cc: add             x3, NULL, #0x30  ; false
    // 0x12837d0: mov             x1, x3
    // 0x12837d4: b               #0x12837e8
    // 0x12837d8: ldr             x1, [fp, #0x18]
    // 0x12837dc: LoadField: r3 = r1->field_23
    //     0x12837dc: ldur            w3, [x1, #0x23]
    // 0x12837e0: DecompressPointer r3
    //     0x12837e0: add             x3, x3, HEAP, lsl #32
    // 0x12837e4: mov             x1, x3
    // 0x12837e8: cmp             w2, w1
    // 0x12837ec: r16 = true
    //     0x12837ec: add             x16, NULL, #0x20  ; true
    // 0x12837f0: r17 = false
    //     0x12837f0: add             x17, NULL, #0x30  ; false
    // 0x12837f4: csel            x3, x16, x17, eq
    // 0x12837f8: mov             x0, x3
    // 0x12837fc: b               #0x1283804
    // 0x1283800: r0 = false
    //     0x1283800: add             x0, NULL, #0x30  ; false
    // 0x1283804: LeaveFrame
    //     0x1283804: mov             SP, fp
    //     0x1283808: ldp             fp, lr, [SP], #0x10
    // 0x128380c: ret
    //     0x128380c: ret             
    // 0x1283810: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1283810: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1283814: b               #0x12831f4
  }
}

// class id: 4617, size: 0x2c, field offset: 0x28
//   const constructor, 
class CupertinoThemeData extends _MixinApplication119&NoDefaultCupertinoThemeData&Diagnosticable {

  _CupertinoThemeDefaults field_28;

  _ noDefault(/* No info */) {
    // ** addr: 0xfbf144, size: 0x44
    // 0xfbf144: EnterFrame
    //     0xfbf144: stp             fp, lr, [SP, #-0x10]!
    //     0xfbf148: mov             fp, SP
    // 0xfbf14c: AllocStack(0x10)
    //     0xfbf14c: sub             SP, SP, #0x10
    // 0xfbf150: LoadField: r0 = r1->field_13
    //     0xfbf150: ldur            w0, [x1, #0x13]
    // 0xfbf154: DecompressPointer r0
    //     0xfbf154: add             x0, x0, HEAP, lsl #32
    // 0xfbf158: stur            x0, [fp, #-0x10]
    // 0xfbf15c: LoadField: r2 = r1->field_23
    //     0xfbf15c: ldur            w2, [x1, #0x23]
    // 0xfbf160: DecompressPointer r2
    //     0xfbf160: add             x2, x2, HEAP, lsl #32
    // 0xfbf164: stur            x2, [fp, #-8]
    // 0xfbf168: r0 = NoDefaultCupertinoThemeData()
    //     0xfbf168: bl              #0xfbf188  ; AllocateNoDefaultCupertinoThemeDataStub -> NoDefaultCupertinoThemeData (size=0x28)
    // 0xfbf16c: ldur            x1, [fp, #-0x10]
    // 0xfbf170: StoreField: r0->field_13 = r1
    //     0xfbf170: stur            w1, [x0, #0x13]
    // 0xfbf174: ldur            x1, [fp, #-8]
    // 0xfbf178: StoreField: r0->field_23 = r1
    //     0xfbf178: stur            w1, [x0, #0x23]
    // 0xfbf17c: LeaveFrame
    //     0xfbf17c: mov             SP, fp
    //     0xfbf180: ldp             fp, lr, [SP], #0x10
    // 0xfbf184: ret
    //     0xfbf184: ret             
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x1143a4c, size: 0x184
    // 0x1143a4c: EnterFrame
    //     0x1143a4c: stp             fp, lr, [SP, #-0x10]!
    //     0x1143a50: mov             fp, SP
    // 0x1143a54: AllocStack(0x50)
    //     0x1143a54: sub             SP, SP, #0x50
    // 0x1143a58: CheckStackOverflow
    //     0x1143a58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1143a5c: cmp             SP, x16
    //     0x1143a60: b.ls            #0x1143bc8
    // 0x1143a64: ldr             x0, [fp, #0x10]
    // 0x1143a68: r2 = LoadClassIdInstr(r0)
    //     0x1143a68: ldur            x2, [x0, #-1]
    //     0x1143a6c: ubfx            x2, x2, #0xc, #0x14
    // 0x1143a70: stur            x2, [fp, #-0x20]
    // 0x1143a74: r17 = 4617
    //     0x1143a74: mov             x17, #0x1209
    // 0x1143a78: cmp             x2, x17
    // 0x1143a7c: b.ne            #0x1143a90
    // 0x1143a80: LoadField: r1 = r0->field_7
    //     0x1143a80: ldur            w1, [x0, #7]
    // 0x1143a84: DecompressPointer r1
    //     0x1143a84: add             x1, x1, HEAP, lsl #32
    // 0x1143a88: mov             x3, x1
    // 0x1143a8c: b               #0x1143aac
    // 0x1143a90: LoadField: r1 = r0->field_2b
    //     0x1143a90: ldur            w1, [x0, #0x2b]
    // 0x1143a94: DecompressPointer r1
    //     0x1143a94: add             x1, x1, HEAP, lsl #32
    // 0x1143a98: LoadField: r3 = r1->field_3f
    //     0x1143a98: ldur            w3, [x1, #0x3f]
    // 0x1143a9c: DecompressPointer r3
    //     0x1143a9c: add             x3, x3, HEAP, lsl #32
    // 0x1143aa0: LoadField: r1 = r3->field_7
    //     0x1143aa0: ldur            w1, [x3, #7]
    // 0x1143aa4: DecompressPointer r1
    //     0x1143aa4: add             x1, x1, HEAP, lsl #32
    // 0x1143aa8: mov             x3, x1
    // 0x1143aac: stur            x3, [fp, #-0x18]
    // 0x1143ab0: r17 = 4617
    //     0x1143ab0: mov             x17, #0x1209
    // 0x1143ab4: cmp             x2, x17
    // 0x1143ab8: b.ne            #0x1143ad0
    // 0x1143abc: LoadField: r1 = r0->field_27
    //     0x1143abc: ldur            w1, [x0, #0x27]
    // 0x1143ac0: DecompressPointer r1
    //     0x1143ac0: add             x1, x1, HEAP, lsl #32
    // 0x1143ac4: LoadField: r4 = r1->field_b
    //     0x1143ac4: ldur            w4, [x1, #0xb]
    // 0x1143ac8: DecompressPointer r4
    //     0x1143ac8: add             x4, x4, HEAP, lsl #32
    // 0x1143acc: b               #0x1143aec
    // 0x1143ad0: LoadField: r1 = r0->field_2b
    //     0x1143ad0: ldur            w1, [x0, #0x2b]
    // 0x1143ad4: DecompressPointer r1
    //     0x1143ad4: add             x1, x1, HEAP, lsl #32
    // 0x1143ad8: LoadField: r4 = r1->field_3f
    //     0x1143ad8: ldur            w4, [x1, #0x3f]
    // 0x1143adc: DecompressPointer r4
    //     0x1143adc: add             x4, x4, HEAP, lsl #32
    // 0x1143ae0: LoadField: r1 = r4->field_b
    //     0x1143ae0: ldur            w1, [x4, #0xb]
    // 0x1143ae4: DecompressPointer r1
    //     0x1143ae4: add             x1, x1, HEAP, lsl #32
    // 0x1143ae8: mov             x4, x1
    // 0x1143aec: stur            x4, [fp, #-0x10]
    // 0x1143af0: r17 = 4617
    //     0x1143af0: mov             x17, #0x1209
    // 0x1143af4: cmp             x2, x17
    // 0x1143af8: b.ne            #0x1143b08
    // 0x1143afc: r5 = Instance_Color
    //     0x1143afc: add             x5, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0x1143b00: ldr             x5, [x5, #0xc38]
    // 0x1143b04: b               #0x1143b24
    // 0x1143b08: LoadField: r1 = r0->field_2b
    //     0x1143b08: ldur            w1, [x0, #0x2b]
    // 0x1143b0c: DecompressPointer r1
    //     0x1143b0c: add             x1, x1, HEAP, lsl #32
    // 0x1143b10: LoadField: r5 = r1->field_3f
    //     0x1143b10: ldur            w5, [x1, #0x3f]
    // 0x1143b14: DecompressPointer r5
    //     0x1143b14: add             x5, x5, HEAP, lsl #32
    // 0x1143b18: LoadField: r1 = r5->field_f
    //     0x1143b18: ldur            w1, [x5, #0xf]
    // 0x1143b1c: DecompressPointer r1
    //     0x1143b1c: add             x1, x1, HEAP, lsl #32
    // 0x1143b20: mov             x5, x1
    // 0x1143b24: mov             x1, x0
    // 0x1143b28: stur            x5, [fp, #-8]
    // 0x1143b2c: r0 = textTheme()
    //     0x1143b2c: bl              #0x1282dd4  ; [package:flutter/src/cupertino/theme.dart] CupertinoThemeData::textTheme
    // 0x1143b30: mov             x1, x0
    // 0x1143b34: ldr             x0, [fp, #0x10]
    // 0x1143b38: LoadField: r2 = r0->field_27
    //     0x1143b38: ldur            w2, [x0, #0x27]
    // 0x1143b3c: DecompressPointer r2
    //     0x1143b3c: add             x2, x2, HEAP, lsl #32
    // 0x1143b40: LoadField: r3 = r2->field_13
    //     0x1143b40: ldur            w3, [x2, #0x13]
    // 0x1143b44: DecompressPointer r3
    //     0x1143b44: add             x3, x3, HEAP, lsl #32
    // 0x1143b48: ldur            x4, [fp, #-0x20]
    // 0x1143b4c: r17 = 4617
    //     0x1143b4c: mov             x17, #0x1209
    // 0x1143b50: cmp             x4, x17
    // 0x1143b54: b.ne            #0x1143b64
    // 0x1143b58: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x1143b58: ldur            w0, [x2, #0x17]
    // 0x1143b5c: DecompressPointer r0
    //     0x1143b5c: add             x0, x0, HEAP, lsl #32
    // 0x1143b60: b               #0x1143b74
    // 0x1143b64: LoadField: r4 = r0->field_2b
    //     0x1143b64: ldur            w4, [x0, #0x2b]
    // 0x1143b68: DecompressPointer r4
    //     0x1143b68: add             x4, x4, HEAP, lsl #32
    // 0x1143b6c: LoadField: r0 = r4->field_67
    //     0x1143b6c: ldur            w0, [x4, #0x67]
    // 0x1143b70: DecompressPointer r0
    //     0x1143b70: add             x0, x0, HEAP, lsl #32
    // 0x1143b74: LoadField: r4 = r2->field_1b
    //     0x1143b74: ldur            w4, [x2, #0x1b]
    // 0x1143b78: DecompressPointer r4
    //     0x1143b78: add             x4, x4, HEAP, lsl #32
    // 0x1143b7c: ldur            x16, [fp, #-8]
    // 0x1143b80: stp             x1, x16, [SP, #0x20]
    // 0x1143b84: stp             x0, x3, [SP, #0x10]
    // 0x1143b88: r16 = false
    //     0x1143b88: add             x16, NULL, #0x30  ; false
    // 0x1143b8c: stp             x16, x4, [SP]
    // 0x1143b90: ldur            x1, [fp, #-0x18]
    // 0x1143b94: ldur            x2, [fp, #-0x10]
    // 0x1143b98: r4 = const [0, 0x8, 0x6, 0x8, null]
    //     0x1143b98: add             x4, PP, #0xe, lsl #12  ; [pp+0xe090] List(5) [0, 0x8, 0x6, 0x8, Null]
    //     0x1143b9c: ldr             x4, [x4, #0x90]
    // 0x1143ba0: r0 = hash()
    //     0x1143ba0: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x1143ba4: mov             x2, x0
    // 0x1143ba8: r0 = BoxInt64Instr(r2)
    //     0x1143ba8: sbfiz           x0, x2, #1, #0x1f
    //     0x1143bac: cmp             x2, x0, asr #1
    //     0x1143bb0: b.eq            #0x1143bbc
    //     0x1143bb4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1143bb8: stur            x2, [x0, #7]
    // 0x1143bbc: LeaveFrame
    //     0x1143bbc: mov             SP, fp
    //     0x1143bc0: ldp             fp, lr, [SP], #0x10
    // 0x1143bc4: ret
    //     0x1143bc4: ret             
    // 0x1143bc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1143bc8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1143bcc: b               #0x1143a64
  }
  _ resolveFrom(/* No info */) {
    // ** addr: 0x121edec, size: 0xc0
    // 0x121edec: EnterFrame
    //     0x121edec: stp             fp, lr, [SP, #-0x10]!
    //     0x121edf0: mov             fp, SP
    // 0x121edf4: AllocStack(0x20)
    //     0x121edf4: sub             SP, SP, #0x20
    // 0x121edf8: SetupParameters(CupertinoThemeData this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */)
    //     0x121edf8: mov             x3, x1
    //     0x121edfc: mov             x0, x2
    //     0x121ee00: stur            x1, [fp, #-0x10]
    //     0x121ee04: stur            x2, [fp, #-0x18]
    // 0x121ee08: CheckStackOverflow
    //     0x121ee08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x121ee0c: cmp             SP, x16
    //     0x121ee10: b.ls            #0x121eea4
    // 0x121ee14: LoadField: r4 = r3->field_13
    //     0x121ee14: ldur            w4, [x3, #0x13]
    // 0x121ee18: DecompressPointer r4
    //     0x121ee18: add             x4, x4, HEAP, lsl #32
    // 0x121ee1c: stur            x4, [fp, #-8]
    // 0x121ee20: cmp             w4, NULL
    // 0x121ee24: b.ne            #0x121ee38
    // 0x121ee28: mov             x0, x3
    // 0x121ee2c: mov             x1, x4
    // 0x121ee30: r4 = Null
    //     0x121ee30: mov             x4, NULL
    // 0x121ee34: b               #0x121ee50
    // 0x121ee38: mov             x1, x4
    // 0x121ee3c: mov             x2, x0
    // 0x121ee40: r0 = resolveFrom()
    //     0x121ee40: bl              #0x121f084  ; [package:flutter/src/cupertino/text_theme.dart] CupertinoTextThemeData::resolveFrom
    // 0x121ee44: mov             x4, x0
    // 0x121ee48: ldur            x0, [fp, #-0x10]
    // 0x121ee4c: ldur            x1, [fp, #-8]
    // 0x121ee50: stur            x4, [fp, #-0x20]
    // 0x121ee54: LoadField: r2 = r0->field_27
    //     0x121ee54: ldur            w2, [x0, #0x27]
    // 0x121ee58: DecompressPointer r2
    //     0x121ee58: add             x2, x2, HEAP, lsl #32
    // 0x121ee5c: cmp             w1, NULL
    // 0x121ee60: r16 = true
    //     0x121ee60: add             x16, NULL, #0x20  ; true
    // 0x121ee64: r17 = false
    //     0x121ee64: add             x17, NULL, #0x30  ; false
    // 0x121ee68: csel            x3, x16, x17, eq
    // 0x121ee6c: mov             x1, x2
    // 0x121ee70: ldur            x2, [fp, #-0x18]
    // 0x121ee74: r0 = resolveFrom()
    //     0x121ee74: bl              #0x121eeb8  ; [package:flutter/src/cupertino/theme.dart] _CupertinoThemeDefaults::resolveFrom
    // 0x121ee78: stur            x0, [fp, #-8]
    // 0x121ee7c: r0 = CupertinoThemeData()
    //     0x121ee7c: bl              #0x121eeac  ; AllocateCupertinoThemeDataStub -> CupertinoThemeData (size=0x2c)
    // 0x121ee80: ldur            x1, [fp, #-8]
    // 0x121ee84: StoreField: r0->field_27 = r1
    //     0x121ee84: stur            w1, [x0, #0x27]
    // 0x121ee88: ldur            x1, [fp, #-0x20]
    // 0x121ee8c: StoreField: r0->field_13 = r1
    //     0x121ee8c: stur            w1, [x0, #0x13]
    // 0x121ee90: r1 = false
    //     0x121ee90: add             x1, NULL, #0x30  ; false
    // 0x121ee94: StoreField: r0->field_23 = r1
    //     0x121ee94: stur            w1, [x0, #0x23]
    // 0x121ee98: LeaveFrame
    //     0x121ee98: mov             SP, fp
    //     0x121ee9c: ldp             fp, lr, [SP], #0x10
    // 0x121eea0: ret
    //     0x121eea0: ret             
    // 0x121eea4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x121eea4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x121eea8: b               #0x121ee14
  }
  get _ textTheme(/* No info */) {
    // ** addr: 0x1282dd4, size: 0x90
    // 0x1282dd4: EnterFrame
    //     0x1282dd4: stp             fp, lr, [SP, #-0x10]!
    //     0x1282dd8: mov             fp, SP
    // 0x1282ddc: CheckStackOverflow
    //     0x1282ddc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1282de0: cmp             SP, x16
    //     0x1282de4: b.ls            #0x1282e5c
    // 0x1282de8: LoadField: r0 = r1->field_13
    //     0x1282de8: ldur            w0, [x1, #0x13]
    // 0x1282dec: DecompressPointer r0
    //     0x1282dec: add             x0, x0, HEAP, lsl #32
    // 0x1282df0: cmp             w0, NULL
    // 0x1282df4: b.ne            #0x1282e50
    // 0x1282df8: LoadField: r0 = r1->field_27
    //     0x1282df8: ldur            w0, [x1, #0x27]
    // 0x1282dfc: DecompressPointer r0
    //     0x1282dfc: add             x0, x0, HEAP, lsl #32
    // 0x1282e00: LoadField: r2 = r0->field_23
    //     0x1282e00: ldur            w2, [x0, #0x23]
    // 0x1282e04: DecompressPointer r2
    //     0x1282e04: add             x2, x2, HEAP, lsl #32
    // 0x1282e08: r3 = LoadClassIdInstr(r1)
    //     0x1282e08: ldur            x3, [x1, #-1]
    //     0x1282e0c: ubfx            x3, x3, #0xc, #0x14
    // 0x1282e10: r17 = 4617
    //     0x1282e10: mov             x17, #0x1209
    // 0x1282e14: cmp             x3, x17
    // 0x1282e18: b.ne            #0x1282e2c
    // 0x1282e1c: LoadField: r1 = r0->field_b
    //     0x1282e1c: ldur            w1, [x0, #0xb]
    // 0x1282e20: DecompressPointer r1
    //     0x1282e20: add             x1, x1, HEAP, lsl #32
    // 0x1282e24: mov             x0, x1
    // 0x1282e28: b               #0x1282e44
    // 0x1282e2c: LoadField: r0 = r1->field_2b
    //     0x1282e2c: ldur            w0, [x1, #0x2b]
    // 0x1282e30: DecompressPointer r0
    //     0x1282e30: add             x0, x0, HEAP, lsl #32
    // 0x1282e34: LoadField: r1 = r0->field_3f
    //     0x1282e34: ldur            w1, [x0, #0x3f]
    // 0x1282e38: DecompressPointer r1
    //     0x1282e38: add             x1, x1, HEAP, lsl #32
    // 0x1282e3c: LoadField: r0 = r1->field_b
    //     0x1282e3c: ldur            w0, [x1, #0xb]
    // 0x1282e40: DecompressPointer r0
    //     0x1282e40: add             x0, x0, HEAP, lsl #32
    // 0x1282e44: mov             x1, x2
    // 0x1282e48: mov             x2, x0
    // 0x1282e4c: r0 = createDefaults()
    //     0x1282e4c: bl              #0x1143e98  ; [package:flutter/src/cupertino/theme.dart] _CupertinoTextThemeDefaults::createDefaults
    // 0x1282e50: LeaveFrame
    //     0x1282e50: mov             SP, fp
    //     0x1282e54: ldp             fp, lr, [SP], #0x10
    // 0x1282e58: ret
    //     0x1282e58: ret             
    // 0x1282e5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1282e5c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1282e60: b               #0x1282de8
  }
  _ ==(/* No info */) {
    // ** addr: 0x1282e64, size: 0x378
    // 0x1282e64: EnterFrame
    //     0x1282e64: stp             fp, lr, [SP, #-0x10]!
    //     0x1282e68: mov             fp, SP
    // 0x1282e6c: AllocStack(0x30)
    //     0x1282e6c: sub             SP, SP, #0x30
    // 0x1282e70: CheckStackOverflow
    //     0x1282e70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1282e74: cmp             SP, x16
    //     0x1282e78: b.ls            #0x12831d4
    // 0x1282e7c: ldr             x1, [fp, #0x10]
    // 0x1282e80: cmp             w1, NULL
    // 0x1282e84: b.ne            #0x1282e98
    // 0x1282e88: r0 = false
    //     0x1282e88: add             x0, NULL, #0x30  ; false
    // 0x1282e8c: LeaveFrame
    //     0x1282e8c: mov             SP, fp
    //     0x1282e90: ldp             fp, lr, [SP], #0x10
    // 0x1282e94: ret
    //     0x1282e94: ret             
    // 0x1282e98: ldr             x0, [fp, #0x18]
    // 0x1282e9c: cmp             w0, w1
    // 0x1282ea0: b.ne            #0x1282eb4
    // 0x1282ea4: r0 = true
    //     0x1282ea4: add             x0, NULL, #0x20  ; true
    // 0x1282ea8: LeaveFrame
    //     0x1282ea8: mov             SP, fp
    //     0x1282eac: ldp             fp, lr, [SP], #0x10
    // 0x1282eb0: ret
    //     0x1282eb0: ret             
    // 0x1282eb4: stp             x0, x1, [SP]
    // 0x1282eb8: r0 = _haveSameRuntimeType()
    //     0x1282eb8: bl              #0x88249c  ; [dart:core] Object::_haveSameRuntimeType
    // 0x1282ebc: tbz             w0, #4, #0x1282ed0
    // 0x1282ec0: r0 = false
    //     0x1282ec0: add             x0, NULL, #0x30  ; false
    // 0x1282ec4: LeaveFrame
    //     0x1282ec4: mov             SP, fp
    //     0x1282ec8: ldp             fp, lr, [SP], #0x10
    // 0x1282ecc: ret
    //     0x1282ecc: ret             
    // 0x1282ed0: ldr             x1, [fp, #0x10]
    // 0x1282ed4: r2 = 60
    //     0x1282ed4: mov             x2, #0x3c
    // 0x1282ed8: branchIfSmi(r1, 0x1282ee4)
    //     0x1282ed8: tbz             w1, #0, #0x1282ee4
    // 0x1282edc: r2 = LoadClassIdInstr(r1)
    //     0x1282edc: ldur            x2, [x1, #-1]
    //     0x1282ee0: ubfx            x2, x2, #0xc, #0x14
    // 0x1282ee4: stur            x2, [fp, #-0x10]
    // 0x1282ee8: r17 = -4617
    //     0x1282ee8: mov             x17, #-0x1209
    // 0x1282eec: add             x16, x2, x17
    // 0x1282ef0: cmp             x16, #1
    // 0x1282ef4: b.hi            #0x12831c4
    // 0x1282ef8: r17 = 4617
    //     0x1282ef8: mov             x17, #0x1209
    // 0x1282efc: cmp             x2, x17
    // 0x1282f00: b.ne            #0x1282f10
    // 0x1282f04: LoadField: r0 = r1->field_7
    //     0x1282f04: ldur            w0, [x1, #7]
    // 0x1282f08: DecompressPointer r0
    //     0x1282f08: add             x0, x0, HEAP, lsl #32
    // 0x1282f0c: b               #0x1282f28
    // 0x1282f10: LoadField: r0 = r1->field_2b
    //     0x1282f10: ldur            w0, [x1, #0x2b]
    // 0x1282f14: DecompressPointer r0
    //     0x1282f14: add             x0, x0, HEAP, lsl #32
    // 0x1282f18: LoadField: r3 = r0->field_3f
    //     0x1282f18: ldur            w3, [x0, #0x3f]
    // 0x1282f1c: DecompressPointer r3
    //     0x1282f1c: add             x3, x3, HEAP, lsl #32
    // 0x1282f20: LoadField: r0 = r3->field_7
    //     0x1282f20: ldur            w0, [x3, #7]
    // 0x1282f24: DecompressPointer r0
    //     0x1282f24: add             x0, x0, HEAP, lsl #32
    // 0x1282f28: ldr             x3, [fp, #0x18]
    // 0x1282f2c: r4 = LoadClassIdInstr(r3)
    //     0x1282f2c: ldur            x4, [x3, #-1]
    //     0x1282f30: ubfx            x4, x4, #0xc, #0x14
    // 0x1282f34: stur            x4, [fp, #-8]
    // 0x1282f38: r17 = 4617
    //     0x1282f38: mov             x17, #0x1209
    // 0x1282f3c: cmp             x4, x17
    // 0x1282f40: b.ne            #0x1282f50
    // 0x1282f44: LoadField: r5 = r3->field_7
    //     0x1282f44: ldur            w5, [x3, #7]
    // 0x1282f48: DecompressPointer r5
    //     0x1282f48: add             x5, x5, HEAP, lsl #32
    // 0x1282f4c: b               #0x1282f68
    // 0x1282f50: LoadField: r5 = r3->field_2b
    //     0x1282f50: ldur            w5, [x3, #0x2b]
    // 0x1282f54: DecompressPointer r5
    //     0x1282f54: add             x5, x5, HEAP, lsl #32
    // 0x1282f58: LoadField: r6 = r5->field_3f
    //     0x1282f58: ldur            w6, [x5, #0x3f]
    // 0x1282f5c: DecompressPointer r6
    //     0x1282f5c: add             x6, x6, HEAP, lsl #32
    // 0x1282f60: LoadField: r5 = r6->field_7
    //     0x1282f60: ldur            w5, [x6, #7]
    // 0x1282f64: DecompressPointer r5
    //     0x1282f64: add             x5, x5, HEAP, lsl #32
    // 0x1282f68: cmp             w0, w5
    // 0x1282f6c: b.ne            #0x12831c4
    // 0x1282f70: r17 = 4617
    //     0x1282f70: mov             x17, #0x1209
    // 0x1282f74: cmp             x2, x17
    // 0x1282f78: b.ne            #0x1282f94
    // 0x1282f7c: LoadField: r0 = r1->field_27
    //     0x1282f7c: ldur            w0, [x1, #0x27]
    // 0x1282f80: DecompressPointer r0
    //     0x1282f80: add             x0, x0, HEAP, lsl #32
    // 0x1282f84: LoadField: r5 = r0->field_b
    //     0x1282f84: ldur            w5, [x0, #0xb]
    // 0x1282f88: DecompressPointer r5
    //     0x1282f88: add             x5, x5, HEAP, lsl #32
    // 0x1282f8c: mov             x0, x5
    // 0x1282f90: b               #0x1282fac
    // 0x1282f94: LoadField: r0 = r1->field_2b
    //     0x1282f94: ldur            w0, [x1, #0x2b]
    // 0x1282f98: DecompressPointer r0
    //     0x1282f98: add             x0, x0, HEAP, lsl #32
    // 0x1282f9c: LoadField: r5 = r0->field_3f
    //     0x1282f9c: ldur            w5, [x0, #0x3f]
    // 0x1282fa0: DecompressPointer r5
    //     0x1282fa0: add             x5, x5, HEAP, lsl #32
    // 0x1282fa4: LoadField: r0 = r5->field_b
    //     0x1282fa4: ldur            w0, [x5, #0xb]
    // 0x1282fa8: DecompressPointer r0
    //     0x1282fa8: add             x0, x0, HEAP, lsl #32
    // 0x1282fac: r17 = 4617
    //     0x1282fac: mov             x17, #0x1209
    // 0x1282fb0: cmp             x4, x17
    // 0x1282fb4: b.ne            #0x1282fd0
    // 0x1282fb8: LoadField: r5 = r3->field_27
    //     0x1282fb8: ldur            w5, [x3, #0x27]
    // 0x1282fbc: DecompressPointer r5
    //     0x1282fbc: add             x5, x5, HEAP, lsl #32
    // 0x1282fc0: LoadField: r6 = r5->field_b
    //     0x1282fc0: ldur            w6, [x5, #0xb]
    // 0x1282fc4: DecompressPointer r6
    //     0x1282fc4: add             x6, x6, HEAP, lsl #32
    // 0x1282fc8: mov             x5, x6
    // 0x1282fcc: b               #0x1282fe8
    // 0x1282fd0: LoadField: r5 = r3->field_2b
    //     0x1282fd0: ldur            w5, [x3, #0x2b]
    // 0x1282fd4: DecompressPointer r5
    //     0x1282fd4: add             x5, x5, HEAP, lsl #32
    // 0x1282fd8: LoadField: r6 = r5->field_3f
    //     0x1282fd8: ldur            w6, [x5, #0x3f]
    // 0x1282fdc: DecompressPointer r6
    //     0x1282fdc: add             x6, x6, HEAP, lsl #32
    // 0x1282fe0: LoadField: r5 = r6->field_b
    //     0x1282fe0: ldur            w5, [x6, #0xb]
    // 0x1282fe4: DecompressPointer r5
    //     0x1282fe4: add             x5, x5, HEAP, lsl #32
    // 0x1282fe8: r6 = LoadClassIdInstr(r0)
    //     0x1282fe8: ldur            x6, [x0, #-1]
    //     0x1282fec: ubfx            x6, x6, #0xc, #0x14
    // 0x1282ff0: stp             x5, x0, [SP]
    // 0x1282ff4: mov             x0, x6
    // 0x1282ff8: mov             lr, x0
    // 0x1282ffc: ldr             lr, [x21, lr, lsl #3]
    // 0x1283000: blr             lr
    // 0x1283004: tbnz            w0, #4, #0x12831c4
    // 0x1283008: ldur            x1, [fp, #-0x10]
    // 0x128300c: r17 = 4617
    //     0x128300c: mov             x17, #0x1209
    // 0x1283010: cmp             x1, x17
    // 0x1283014: b.ne            #0x1283028
    // 0x1283018: ldr             x2, [fp, #0x10]
    // 0x128301c: r0 = Instance_Color
    //     0x128301c: add             x0, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0x1283020: ldr             x0, [x0, #0xc38]
    // 0x1283024: b               #0x1283044
    // 0x1283028: ldr             x2, [fp, #0x10]
    // 0x128302c: LoadField: r0 = r2->field_2b
    //     0x128302c: ldur            w0, [x2, #0x2b]
    // 0x1283030: DecompressPointer r0
    //     0x1283030: add             x0, x0, HEAP, lsl #32
    // 0x1283034: LoadField: r3 = r0->field_3f
    //     0x1283034: ldur            w3, [x0, #0x3f]
    // 0x1283038: DecompressPointer r3
    //     0x1283038: add             x3, x3, HEAP, lsl #32
    // 0x128303c: LoadField: r0 = r3->field_f
    //     0x128303c: ldur            w0, [x3, #0xf]
    // 0x1283040: DecompressPointer r0
    //     0x1283040: add             x0, x0, HEAP, lsl #32
    // 0x1283044: ldur            x3, [fp, #-8]
    // 0x1283048: r17 = 4617
    //     0x1283048: mov             x17, #0x1209
    // 0x128304c: cmp             x3, x17
    // 0x1283050: b.ne            #0x1283064
    // 0x1283054: ldr             x4, [fp, #0x18]
    // 0x1283058: r5 = Instance_Color
    //     0x1283058: add             x5, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0x128305c: ldr             x5, [x5, #0xc38]
    // 0x1283060: b               #0x1283080
    // 0x1283064: ldr             x4, [fp, #0x18]
    // 0x1283068: LoadField: r5 = r4->field_2b
    //     0x1283068: ldur            w5, [x4, #0x2b]
    // 0x128306c: DecompressPointer r5
    //     0x128306c: add             x5, x5, HEAP, lsl #32
    // 0x1283070: LoadField: r6 = r5->field_3f
    //     0x1283070: ldur            w6, [x5, #0x3f]
    // 0x1283074: DecompressPointer r6
    //     0x1283074: add             x6, x6, HEAP, lsl #32
    // 0x1283078: LoadField: r5 = r6->field_f
    //     0x1283078: ldur            w5, [x6, #0xf]
    // 0x128307c: DecompressPointer r5
    //     0x128307c: add             x5, x5, HEAP, lsl #32
    // 0x1283080: r6 = LoadClassIdInstr(r0)
    //     0x1283080: ldur            x6, [x0, #-1]
    //     0x1283084: ubfx            x6, x6, #0xc, #0x14
    // 0x1283088: stp             x5, x0, [SP]
    // 0x128308c: mov             x0, x6
    // 0x1283090: mov             lr, x0
    // 0x1283094: ldr             lr, [x21, lr, lsl #3]
    // 0x1283098: blr             lr
    // 0x128309c: tbnz            w0, #4, #0x12831c4
    // 0x12830a0: ldr             x1, [fp, #0x10]
    // 0x12830a4: r0 = textTheme()
    //     0x12830a4: bl              #0x1282dd4  ; [package:flutter/src/cupertino/theme.dart] CupertinoThemeData::textTheme
    // 0x12830a8: ldr             x1, [fp, #0x18]
    // 0x12830ac: stur            x0, [fp, #-0x18]
    // 0x12830b0: r0 = textTheme()
    //     0x12830b0: bl              #0x1282dd4  ; [package:flutter/src/cupertino/theme.dart] CupertinoThemeData::textTheme
    // 0x12830b4: ldur            x16, [fp, #-0x18]
    // 0x12830b8: stp             x0, x16, [SP]
    // 0x12830bc: r0 = ==()
    //     0x12830bc: bl              #0x1263144  ; [package:flutter/src/cupertino/text_theme.dart] CupertinoTextThemeData::==
    // 0x12830c0: tbnz            w0, #4, #0x12831c4
    // 0x12830c4: ldr             x1, [fp, #0x18]
    // 0x12830c8: ldr             x0, [fp, #0x10]
    // 0x12830cc: LoadField: r2 = r0->field_27
    //     0x12830cc: ldur            w2, [x0, #0x27]
    // 0x12830d0: DecompressPointer r2
    //     0x12830d0: add             x2, x2, HEAP, lsl #32
    // 0x12830d4: stur            x2, [fp, #-0x20]
    // 0x12830d8: LoadField: r3 = r2->field_13
    //     0x12830d8: ldur            w3, [x2, #0x13]
    // 0x12830dc: DecompressPointer r3
    //     0x12830dc: add             x3, x3, HEAP, lsl #32
    // 0x12830e0: LoadField: r4 = r1->field_27
    //     0x12830e0: ldur            w4, [x1, #0x27]
    // 0x12830e4: DecompressPointer r4
    //     0x12830e4: add             x4, x4, HEAP, lsl #32
    // 0x12830e8: stur            x4, [fp, #-0x18]
    // 0x12830ec: LoadField: r5 = r4->field_13
    //     0x12830ec: ldur            w5, [x4, #0x13]
    // 0x12830f0: DecompressPointer r5
    //     0x12830f0: add             x5, x5, HEAP, lsl #32
    // 0x12830f4: stp             x5, x3, [SP]
    // 0x12830f8: r0 = ==()
    //     0x12830f8: bl              #0x12629d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::==
    // 0x12830fc: tbnz            w0, #4, #0x12831c4
    // 0x1283100: ldur            x0, [fp, #-0x10]
    // 0x1283104: r17 = 4617
    //     0x1283104: mov             x17, #0x1209
    // 0x1283108: cmp             x0, x17
    // 0x128310c: b.ne            #0x1283124
    // 0x1283110: ldur            x1, [fp, #-0x20]
    // 0x1283114: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x1283114: ldur            w0, [x1, #0x17]
    // 0x1283118: DecompressPointer r0
    //     0x1283118: add             x0, x0, HEAP, lsl #32
    // 0x128311c: mov             x2, x0
    // 0x1283120: b               #0x1283140
    // 0x1283124: ldr             x0, [fp, #0x10]
    // 0x1283128: ldur            x1, [fp, #-0x20]
    // 0x128312c: LoadField: r2 = r0->field_2b
    //     0x128312c: ldur            w2, [x0, #0x2b]
    // 0x1283130: DecompressPointer r2
    //     0x1283130: add             x2, x2, HEAP, lsl #32
    // 0x1283134: LoadField: r0 = r2->field_67
    //     0x1283134: ldur            w0, [x2, #0x67]
    // 0x1283138: DecompressPointer r0
    //     0x1283138: add             x0, x0, HEAP, lsl #32
    // 0x128313c: mov             x2, x0
    // 0x1283140: ldur            x0, [fp, #-8]
    // 0x1283144: r17 = 4617
    //     0x1283144: mov             x17, #0x1209
    // 0x1283148: cmp             x0, x17
    // 0x128314c: b.ne            #0x1283160
    // 0x1283150: ldur            x3, [fp, #-0x18]
    // 0x1283154: ArrayLoad: r0 = r3[0]  ; List_4
    //     0x1283154: ldur            w0, [x3, #0x17]
    // 0x1283158: DecompressPointer r0
    //     0x1283158: add             x0, x0, HEAP, lsl #32
    // 0x128315c: b               #0x1283178
    // 0x1283160: ldr             x0, [fp, #0x18]
    // 0x1283164: ldur            x3, [fp, #-0x18]
    // 0x1283168: LoadField: r4 = r0->field_2b
    //     0x1283168: ldur            w4, [x0, #0x2b]
    // 0x128316c: DecompressPointer r4
    //     0x128316c: add             x4, x4, HEAP, lsl #32
    // 0x1283170: LoadField: r0 = r4->field_67
    //     0x1283170: ldur            w0, [x4, #0x67]
    // 0x1283174: DecompressPointer r0
    //     0x1283174: add             x0, x0, HEAP, lsl #32
    // 0x1283178: r4 = LoadClassIdInstr(r2)
    //     0x1283178: ldur            x4, [x2, #-1]
    //     0x128317c: ubfx            x4, x4, #0xc, #0x14
    // 0x1283180: stp             x0, x2, [SP]
    // 0x1283184: mov             x0, x4
    // 0x1283188: mov             lr, x0
    // 0x128318c: ldr             lr, [x21, lr, lsl #3]
    // 0x1283190: blr             lr
    // 0x1283194: tbnz            w0, #4, #0x12831c4
    // 0x1283198: ldur            x0, [fp, #-0x20]
    // 0x128319c: ldur            x1, [fp, #-0x18]
    // 0x12831a0: LoadField: r2 = r0->field_1b
    //     0x12831a0: ldur            w2, [x0, #0x1b]
    // 0x12831a4: DecompressPointer r2
    //     0x12831a4: add             x2, x2, HEAP, lsl #32
    // 0x12831a8: LoadField: r0 = r1->field_1b
    //     0x12831a8: ldur            w0, [x1, #0x1b]
    // 0x12831ac: DecompressPointer r0
    //     0x12831ac: add             x0, x0, HEAP, lsl #32
    // 0x12831b0: stp             x0, x2, [SP]
    // 0x12831b4: r0 = ==()
    //     0x12831b4: bl              #0x12629d0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::==
    // 0x12831b8: tbnz            w0, #4, #0x12831c4
    // 0x12831bc: r0 = true
    //     0x12831bc: add             x0, NULL, #0x20  ; true
    // 0x12831c0: b               #0x12831c8
    // 0x12831c4: r0 = false
    //     0x12831c4: add             x0, NULL, #0x30  ; false
    // 0x12831c8: LeaveFrame
    //     0x12831c8: mov             SP, fp
    //     0x12831cc: ldp             fp, lr, [SP], #0x10
    // 0x12831d0: ret
    //     0x12831d0: ret             
    // 0x12831d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12831d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12831d8: b               #0x1282e7c
  }
  get _ primaryColor(/* No info */) {
    // ** addr: 0x12b116c, size: 0x14
    // 0x12b116c: LoadField: r2 = r1->field_27
    //     0x12b116c: ldur            w2, [x1, #0x27]
    // 0x12b1170: DecompressPointer r2
    //     0x12b1170: add             x2, x2, HEAP, lsl #32
    // 0x12b1174: LoadField: r0 = r2->field_b
    //     0x12b1174: ldur            w0, [x2, #0xb]
    // 0x12b1178: DecompressPointer r0
    //     0x12b1178: add             x0, x0, HEAP, lsl #32
    // 0x12b117c: ret
    //     0x12b117c: ret             
  }
}

// class id: 5235, size: 0x34, field offset: 0x34
//   const constructor, 
class _DefaultCupertinoTextThemeData extends CupertinoTextThemeData {
}

// class id: 6199, size: 0x14, field offset: 0xc
//   const constructor, 
class CupertinoTheme extends StatelessWidget {

  static _ of(/* No info */) {
    // ** addr: 0xccc364, size: 0x9c
    // 0xccc364: EnterFrame
    //     0xccc364: stp             fp, lr, [SP, #-0x10]!
    //     0xccc368: mov             fp, SP
    // 0xccc36c: AllocStack(0x18)
    //     0xccc36c: sub             SP, SP, #0x18
    // 0xccc370: SetupParameters(dynamic _ /* r1 => r2, fp-0x8 */)
    //     0xccc370: mov             x2, x1
    //     0xccc374: stur            x1, [fp, #-8]
    // 0xccc378: CheckStackOverflow
    //     0xccc378: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xccc37c: cmp             SP, x16
    //     0xccc380: b.ls            #0xccc3f8
    // 0xccc384: r16 = <InheritedCupertinoTheme>
    //     0xccc384: add             x16, PP, #0x12, lsl #12  ; [pp+0x128c8] TypeArguments: <InheritedCupertinoTheme>
    //     0xccc388: ldr             x16, [x16, #0x8c8]
    // 0xccc38c: stp             x2, x16, [SP]
    // 0xccc390: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xccc390: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xccc394: r0 = dependOnInheritedWidgetOfExactType()
    //     0xccc394: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xccc398: cmp             w0, NULL
    // 0xccc39c: b.ne            #0xccc3a8
    // 0xccc3a0: r0 = Null
    //     0xccc3a0: mov             x0, NULL
    // 0xccc3a4: b               #0xccc3b8
    // 0xccc3a8: LoadField: r1 = r0->field_f
    //     0xccc3a8: ldur            w1, [x0, #0xf]
    // 0xccc3ac: DecompressPointer r1
    //     0xccc3ac: add             x1, x1, HEAP, lsl #32
    // 0xccc3b0: LoadField: r0 = r1->field_b
    //     0xccc3b0: ldur            w0, [x1, #0xb]
    // 0xccc3b4: DecompressPointer r0
    //     0xccc3b4: add             x0, x0, HEAP, lsl #32
    // 0xccc3b8: cmp             w0, NULL
    // 0xccc3bc: b.ne            #0xccc3cc
    // 0xccc3c0: r1 = Instance_CupertinoThemeData
    //     0xccc3c0: add             x1, PP, #0x26, lsl #12  ; [pp+0x26b40] Obj!CupertinoThemeData@12aa501
    //     0xccc3c4: ldr             x1, [x1, #0xb40]
    // 0xccc3c8: b               #0xccc3d0
    // 0xccc3cc: mov             x1, x0
    // 0xccc3d0: r0 = LoadClassIdInstr(r1)
    //     0xccc3d0: ldur            x0, [x1, #-1]
    //     0xccc3d4: ubfx            x0, x0, #0xc, #0x14
    // 0xccc3d8: ldur            x2, [fp, #-8]
    // 0xccc3dc: r0 = GDT[cid_x0 + 0x15a5]()
    //     0xccc3dc: mov             x17, #0x15a5
    //     0xccc3e0: add             lr, x0, x17
    //     0xccc3e4: ldr             lr, [x21, lr, lsl #3]
    //     0xccc3e8: blr             lr
    // 0xccc3ec: LeaveFrame
    //     0xccc3ec: mov             SP, fp
    //     0xccc3f0: ldp             fp, lr, [SP], #0x10
    // 0xccc3f4: ret
    //     0xccc3f4: ret             
    // 0xccc3f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xccc3f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xccc3fc: b               #0xccc384
  }
  static _ maybeBrightnessOf(/* No info */) {
    // ** addr: 0xce22c0, size: 0x90
    // 0xce22c0: EnterFrame
    //     0xce22c0: stp             fp, lr, [SP, #-0x10]!
    //     0xce22c4: mov             fp, SP
    // 0xce22c8: AllocStack(0x18)
    //     0xce22c8: sub             SP, SP, #0x18
    // 0xce22cc: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0xce22cc: stur            x1, [fp, #-8]
    // 0xce22d0: CheckStackOverflow
    //     0xce22d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce22d4: cmp             SP, x16
    //     0xce22d8: b.ls            #0xce2348
    // 0xce22dc: r16 = <InheritedCupertinoTheme>
    //     0xce22dc: add             x16, PP, #0x12, lsl #12  ; [pp+0x128c8] TypeArguments: <InheritedCupertinoTheme>
    //     0xce22e0: ldr             x16, [x16, #0x8c8]
    // 0xce22e4: stp             x1, x16, [SP]
    // 0xce22e8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xce22e8: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xce22ec: r0 = dependOnInheritedWidgetOfExactType()
    //     0xce22ec: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xce22f0: cmp             w0, NULL
    // 0xce22f4: b.ne            #0xce2300
    // 0xce22f8: r0 = Null
    //     0xce22f8: mov             x0, NULL
    // 0xce22fc: b               #0xce232c
    // 0xce2300: LoadField: r1 = r0->field_f
    //     0xce2300: ldur            w1, [x0, #0xf]
    // 0xce2304: DecompressPointer r1
    //     0xce2304: add             x1, x1, HEAP, lsl #32
    // 0xce2308: LoadField: r0 = r1->field_b
    //     0xce2308: ldur            w0, [x1, #0xb]
    // 0xce230c: DecompressPointer r0
    //     0xce230c: add             x0, x0, HEAP, lsl #32
    // 0xce2310: LoadField: r1 = r0->field_2b
    //     0xce2310: ldur            w1, [x0, #0x2b]
    // 0xce2314: DecompressPointer r1
    //     0xce2314: add             x1, x1, HEAP, lsl #32
    // 0xce2318: LoadField: r0 = r1->field_3f
    //     0xce2318: ldur            w0, [x1, #0x3f]
    // 0xce231c: DecompressPointer r0
    //     0xce231c: add             x0, x0, HEAP, lsl #32
    // 0xce2320: LoadField: r1 = r0->field_7
    //     0xce2320: ldur            w1, [x0, #7]
    // 0xce2324: DecompressPointer r1
    //     0xce2324: add             x1, x1, HEAP, lsl #32
    // 0xce2328: mov             x0, x1
    // 0xce232c: cmp             w0, NULL
    // 0xce2330: b.ne            #0xce233c
    // 0xce2334: ldur            x1, [fp, #-8]
    // 0xce2338: r0 = maybePlatformBrightnessOf()
    //     0xce2338: bl              #0xce2350  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::maybePlatformBrightnessOf
    // 0xce233c: LeaveFrame
    //     0xce233c: mov             SP, fp
    //     0xce2340: ldp             fp, lr, [SP], #0x10
    // 0xce2344: ret
    //     0xce2344: ret             
    // 0xce2348: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce2348: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce234c: b               #0xce22dc
  }
  static _ brightnessOf(/* No info */) {
    // ** addr: 0xd776f8, size: 0x90
    // 0xd776f8: EnterFrame
    //     0xd776f8: stp             fp, lr, [SP, #-0x10]!
    //     0xd776fc: mov             fp, SP
    // 0xd77700: AllocStack(0x18)
    //     0xd77700: sub             SP, SP, #0x18
    // 0xd77704: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0xd77704: stur            x1, [fp, #-8]
    // 0xd77708: CheckStackOverflow
    //     0xd77708: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd7770c: cmp             SP, x16
    //     0xd77710: b.ls            #0xd77780
    // 0xd77714: r16 = <InheritedCupertinoTheme>
    //     0xd77714: add             x16, PP, #0x12, lsl #12  ; [pp+0x128c8] TypeArguments: <InheritedCupertinoTheme>
    //     0xd77718: ldr             x16, [x16, #0x8c8]
    // 0xd7771c: stp             x1, x16, [SP]
    // 0xd77720: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd77720: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd77724: r0 = dependOnInheritedWidgetOfExactType()
    //     0xd77724: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xd77728: cmp             w0, NULL
    // 0xd7772c: b.ne            #0xd77738
    // 0xd77730: r0 = Null
    //     0xd77730: mov             x0, NULL
    // 0xd77734: b               #0xd77764
    // 0xd77738: LoadField: r1 = r0->field_f
    //     0xd77738: ldur            w1, [x0, #0xf]
    // 0xd7773c: DecompressPointer r1
    //     0xd7773c: add             x1, x1, HEAP, lsl #32
    // 0xd77740: LoadField: r0 = r1->field_b
    //     0xd77740: ldur            w0, [x1, #0xb]
    // 0xd77744: DecompressPointer r0
    //     0xd77744: add             x0, x0, HEAP, lsl #32
    // 0xd77748: LoadField: r1 = r0->field_2b
    //     0xd77748: ldur            w1, [x0, #0x2b]
    // 0xd7774c: DecompressPointer r1
    //     0xd7774c: add             x1, x1, HEAP, lsl #32
    // 0xd77750: LoadField: r0 = r1->field_3f
    //     0xd77750: ldur            w0, [x1, #0x3f]
    // 0xd77754: DecompressPointer r0
    //     0xd77754: add             x0, x0, HEAP, lsl #32
    // 0xd77758: LoadField: r1 = r0->field_7
    //     0xd77758: ldur            w1, [x0, #7]
    // 0xd7775c: DecompressPointer r1
    //     0xd7775c: add             x1, x1, HEAP, lsl #32
    // 0xd77760: mov             x0, x1
    // 0xd77764: cmp             w0, NULL
    // 0xd77768: b.ne            #0xd77774
    // 0xd7776c: ldur            x1, [fp, #-8]
    // 0xd77770: r0 = platformBrightnessOf()
    //     0xd77770: bl              #0xd1e560  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::platformBrightnessOf
    // 0xd77774: LeaveFrame
    //     0xd77774: mov             SP, fp
    //     0xd77778: ldp             fp, lr, [SP], #0x10
    // 0xd7777c: ret
    //     0xd7777c: ret             
    // 0xd77780: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd77780: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd77784: b               #0xd77714
  }
  _ build(/* No info */) {
    // ** addr: 0xfadd28, size: 0x94
    // 0xfadd28: EnterFrame
    //     0xfadd28: stp             fp, lr, [SP, #-0x10]!
    //     0xfadd2c: mov             fp, SP
    // 0xfadd30: AllocStack(0x20)
    //     0xfadd30: sub             SP, SP, #0x20
    // 0xfadd34: SetupParameters(CupertinoTheme this /* r1 => r1, fp-0x10 */)
    //     0xfadd34: stur            x1, [fp, #-0x10]
    // 0xfadd38: LoadField: r0 = r1->field_b
    //     0xfadd38: ldur            w0, [x1, #0xb]
    // 0xfadd3c: DecompressPointer r0
    //     0xfadd3c: add             x0, x0, HEAP, lsl #32
    // 0xfadd40: LoadField: r2 = r0->field_2b
    //     0xfadd40: ldur            w2, [x0, #0x2b]
    // 0xfadd44: DecompressPointer r2
    //     0xfadd44: add             x2, x2, HEAP, lsl #32
    // 0xfadd48: LoadField: r0 = r2->field_3f
    //     0xfadd48: ldur            w0, [x2, #0x3f]
    // 0xfadd4c: DecompressPointer r0
    //     0xfadd4c: add             x0, x0, HEAP, lsl #32
    // 0xfadd50: LoadField: r2 = r0->field_b
    //     0xfadd50: ldur            w2, [x0, #0xb]
    // 0xfadd54: DecompressPointer r2
    //     0xfadd54: add             x2, x2, HEAP, lsl #32
    // 0xfadd58: stur            x2, [fp, #-8]
    // 0xfadd5c: r0 = CupertinoIconThemeData()
    //     0xfadd5c: bl              #0xfaddc8  ; AllocateCupertinoIconThemeDataStub -> CupertinoIconThemeData (size=0x2c)
    // 0xfadd60: mov             x1, x0
    // 0xfadd64: ldur            x0, [fp, #-8]
    // 0xfadd68: stur            x1, [fp, #-0x18]
    // 0xfadd6c: StoreField: r1->field_1b = r0
    //     0xfadd6c: stur            w0, [x1, #0x1b]
    // 0xfadd70: ldur            x0, [fp, #-0x10]
    // 0xfadd74: LoadField: r2 = r0->field_f
    //     0xfadd74: ldur            w2, [x0, #0xf]
    // 0xfadd78: DecompressPointer r2
    //     0xfadd78: add             x2, x2, HEAP, lsl #32
    // 0xfadd7c: stur            x2, [fp, #-8]
    // 0xfadd80: r0 = IconTheme()
    //     0xfadd80: bl              #0xd0c668  ; AllocateIconThemeStub -> IconTheme (size=0x14)
    // 0xfadd84: mov             x1, x0
    // 0xfadd88: ldur            x0, [fp, #-0x18]
    // 0xfadd8c: stur            x1, [fp, #-0x20]
    // 0xfadd90: StoreField: r1->field_f = r0
    //     0xfadd90: stur            w0, [x1, #0xf]
    // 0xfadd94: ldur            x0, [fp, #-8]
    // 0xfadd98: StoreField: r1->field_b = r0
    //     0xfadd98: stur            w0, [x1, #0xb]
    // 0xfadd9c: r0 = InheritedCupertinoTheme()
    //     0xfadd9c: bl              #0xfaddbc  ; AllocateInheritedCupertinoThemeStub -> InheritedCupertinoTheme (size=0x14)
    // 0xfadda0: ldur            x1, [fp, #-0x10]
    // 0xfadda4: StoreField: r0->field_f = r1
    //     0xfadda4: stur            w1, [x0, #0xf]
    // 0xfadda8: ldur            x1, [fp, #-0x20]
    // 0xfaddac: StoreField: r0->field_b = r1
    //     0xfaddac: stur            w1, [x0, #0xb]
    // 0xfaddb0: LeaveFrame
    //     0xfaddb0: mov             SP, fp
    //     0xfaddb4: ldp             fp, lr, [SP], #0x10
    // 0xfaddb8: ret
    //     0xfaddb8: ret             
  }
}

// class id: 6854, size: 0x14, field offset: 0x10
//   const constructor, 
class InheritedCupertinoTheme extends InheritedTheme {

  _ updateShouldNotify(/* No info */) {
    // ** addr: 0xc002e0, size: 0xb0
    // 0xc002e0: EnterFrame
    //     0xc002e0: stp             fp, lr, [SP, #-0x10]!
    //     0xc002e4: mov             fp, SP
    // 0xc002e8: AllocStack(0x20)
    //     0xc002e8: sub             SP, SP, #0x20
    // 0xc002ec: SetupParameters(InheritedCupertinoTheme this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xc002ec: mov             x4, x1
    //     0xc002f0: mov             x3, x2
    //     0xc002f4: stur            x1, [fp, #-8]
    //     0xc002f8: stur            x2, [fp, #-0x10]
    // 0xc002fc: CheckStackOverflow
    //     0xc002fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc00300: cmp             SP, x16
    //     0xc00304: b.ls            #0xc00388
    // 0xc00308: mov             x0, x3
    // 0xc0030c: r2 = Null
    //     0xc0030c: mov             x2, NULL
    // 0xc00310: r1 = Null
    //     0xc00310: mov             x1, NULL
    // 0xc00314: r4 = 60
    //     0xc00314: mov             x4, #0x3c
    // 0xc00318: branchIfSmi(r0, 0xc00324)
    //     0xc00318: tbz             w0, #0, #0xc00324
    // 0xc0031c: r4 = LoadClassIdInstr(r0)
    //     0xc0031c: ldur            x4, [x0, #-1]
    //     0xc00320: ubfx            x4, x4, #0xc, #0x14
    // 0xc00324: r17 = 6854
    //     0xc00324: mov             x17, #0x1ac6
    // 0xc00328: cmp             x4, x17
    // 0xc0032c: b.eq            #0xc00344
    // 0xc00330: r8 = InheritedCupertinoTheme
    //     0xc00330: add             x8, PP, #0x98, lsl #12  ; [pp+0x98e38] Type: InheritedCupertinoTheme
    //     0xc00334: ldr             x8, [x8, #0xe38]
    // 0xc00338: r3 = Null
    //     0xc00338: add             x3, PP, #0x98, lsl #12  ; [pp+0x98e40] Null
    //     0xc0033c: ldr             x3, [x3, #0xe40]
    // 0xc00340: r0 = DefaultTypeTest()
    //     0xc00340: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xc00344: ldur            x0, [fp, #-8]
    // 0xc00348: LoadField: r1 = r0->field_f
    //     0xc00348: ldur            w1, [x0, #0xf]
    // 0xc0034c: DecompressPointer r1
    //     0xc0034c: add             x1, x1, HEAP, lsl #32
    // 0xc00350: LoadField: r0 = r1->field_b
    //     0xc00350: ldur            w0, [x1, #0xb]
    // 0xc00354: DecompressPointer r0
    //     0xc00354: add             x0, x0, HEAP, lsl #32
    // 0xc00358: ldur            x1, [fp, #-0x10]
    // 0xc0035c: LoadField: r2 = r1->field_f
    //     0xc0035c: ldur            w2, [x1, #0xf]
    // 0xc00360: DecompressPointer r2
    //     0xc00360: add             x2, x2, HEAP, lsl #32
    // 0xc00364: LoadField: r1 = r2->field_b
    //     0xc00364: ldur            w1, [x2, #0xb]
    // 0xc00368: DecompressPointer r1
    //     0xc00368: add             x1, x1, HEAP, lsl #32
    // 0xc0036c: stp             x1, x0, [SP]
    // 0xc00370: r0 = ==()
    //     0xc00370: bl              #0x1282e64  ; [package:flutter/src/cupertino/theme.dart] CupertinoThemeData::==
    // 0xc00374: eor             x1, x0, #0x10
    // 0xc00378: mov             x0, x1
    // 0xc0037c: LeaveFrame
    //     0xc0037c: mov             SP, fp
    //     0xc00380: ldp             fp, lr, [SP], #0x10
    // 0xc00384: ret
    //     0xc00384: ret             
    // 0xc00388: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc00388: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc0038c: b               #0xc00308
  }
  _ wrap(/* No info */) {
    // ** addr: 0x1200ae4, size: 0x44
    // 0x1200ae4: EnterFrame
    //     0x1200ae4: stp             fp, lr, [SP, #-0x10]!
    //     0x1200ae8: mov             fp, SP
    // 0x1200aec: AllocStack(0x10)
    //     0x1200aec: sub             SP, SP, #0x10
    // 0x1200af0: SetupParameters(dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x1200af0: stur            x2, [fp, #-0x10]
    // 0x1200af4: LoadField: r0 = r1->field_f
    //     0x1200af4: ldur            w0, [x1, #0xf]
    // 0x1200af8: DecompressPointer r0
    //     0x1200af8: add             x0, x0, HEAP, lsl #32
    // 0x1200afc: LoadField: r1 = r0->field_b
    //     0x1200afc: ldur            w1, [x0, #0xb]
    // 0x1200b00: DecompressPointer r1
    //     0x1200b00: add             x1, x1, HEAP, lsl #32
    // 0x1200b04: stur            x1, [fp, #-8]
    // 0x1200b08: r0 = CupertinoTheme()
    //     0x1200b08: bl              #0xfbefa4  ; AllocateCupertinoThemeStub -> CupertinoTheme (size=0x14)
    // 0x1200b0c: ldur            x1, [fp, #-8]
    // 0x1200b10: StoreField: r0->field_b = r1
    //     0x1200b10: stur            w1, [x0, #0xb]
    // 0x1200b14: ldur            x1, [fp, #-0x10]
    // 0x1200b18: StoreField: r0->field_f = r1
    //     0x1200b18: stur            w1, [x0, #0xf]
    // 0x1200b1c: LeaveFrame
    //     0x1200b1c: mov             SP, fp
    //     0x1200b20: ldp             fp, lr, [SP], #0x10
    // 0x1200b24: ret
    //     0x1200b24: ret             
  }
}
