// lib: , url: package:flutter/src/scheduler/binding.dart

// class id: 1049058, size: 0x8
class :: {

  [closure] static bool defaultSchedulingStrategy(dynamic, {required int priority, required SchedulerBinding scheduler}) {
    // ** addr: 0x89f74c, size: 0x64
    // 0x89f74c: EnterFrame
    //     0x89f74c: stp             fp, lr, [SP, #-0x10]!
    //     0x89f750: mov             fp, SP
    // 0x89f754: AllocStack(0x10)
    //     0x89f754: sub             SP, SP, #0x10
    // 0x89f758: SetupParameters({dynamic required /* r1 */, dynamic required /* r0 */})
    //     0x89f758: ldur            w0, [x4, #0x13]
    //     0x89f75c: ldur            w1, [x4, #0x23]
    //     0x89f760: add             x1, x1, HEAP, lsl #32
    //     0x89f764: sub             w2, w0, w1
    //     0x89f768: add             x1, fp, w2, sxtw #2
    //     0x89f76c: ldr             x1, [x1, #8]
    //     0x89f770: ldur            w2, [x4, #0x2b]
    //     0x89f774: add             x2, x2, HEAP, lsl #32
    //     0x89f778: sub             w3, w0, w2
    //     0x89f77c: add             x0, fp, w3, sxtw #2
    //     0x89f780: ldr             x0, [x0, #8]
    // 0x89f784: CheckStackOverflow
    //     0x89f784: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89f788: cmp             SP, x16
    //     0x89f78c: b.ls            #0x89f7a8
    // 0x89f790: stp             x0, x1, [SP]
    // 0x89f794: r4 = const [0, 0x2, 0x2, 0, priority, 0, scheduler, 0x1, null]
    //     0x89f794: ldr             x4, [PP, #0x1840]  ; [pp+0x1840] List(9) [0, 0x2, 0x2, 0, "priority", 0, "scheduler", 0x1, Null]
    // 0x89f798: r0 = defaultSchedulingStrategy()
    //     0x89f798: bl              #0x89f7b0  ; [package:flutter/src/scheduler/binding.dart] ::defaultSchedulingStrategy
    // 0x89f79c: LeaveFrame
    //     0x89f79c: mov             SP, fp
    //     0x89f7a0: ldp             fp, lr, [SP], #0x10
    // 0x89f7a4: ret
    //     0x89f7a4: ret             
    // 0x89f7a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89f7a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89f7ac: b               #0x89f790
  }
  static bool defaultSchedulingStrategy({required int priority, required SchedulerBinding scheduler}) {
    // ** addr: 0x89f7b0, size: 0xa0
    // 0x89f7b0: EnterFrame
    //     0x89f7b0: stp             fp, lr, [SP, #-0x10]!
    //     0x89f7b4: mov             fp, SP
    // 0x89f7b8: AllocStack(0x8)
    //     0x89f7b8: sub             SP, SP, #8
    // 0x89f7bc: SetupParameters({dynamic required /* r3, fp-0x8 */, dynamic required /* r1 */})
    //     0x89f7bc: ldur            w0, [x4, #0x13]
    //     0x89f7c0: ldur            w1, [x4, #0x23]
    //     0x89f7c4: add             x1, x1, HEAP, lsl #32
    //     0x89f7c8: sub             w2, w0, w1
    //     0x89f7cc: add             x3, fp, w2, sxtw #2
    //     0x89f7d0: ldr             x3, [x3, #8]
    //     0x89f7d4: stur            x3, [fp, #-8]
    //     0x89f7d8: ldur            w1, [x4, #0x2b]
    //     0x89f7dc: add             x1, x1, HEAP, lsl #32
    //     0x89f7e0: sub             w2, w0, w1
    //     0x89f7e4: add             x1, fp, w2, sxtw #2
    //     0x89f7e8: ldr             x1, [x1, #8]
    // 0x89f7ec: CheckStackOverflow
    //     0x89f7ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89f7f0: cmp             SP, x16
    //     0x89f7f4: b.ls            #0x89f848
    // 0x89f7f8: r0 = transientCallbackCount()
    //     0x89f7f8: bl              #0x89f850  ; [dart:mixin_deduplication] _MixinApplication203&BindingBase&GestureBinding&SchedulerBinding::transientCallbackCount
    // 0x89f7fc: cmp             x0, #0
    // 0x89f800: b.le            #0x89f838
    // 0x89f804: ldur            x1, [fp, #-8]
    // 0x89f808: r2 = LoadInt32Instr(r1)
    //     0x89f808: sbfx            x2, x1, #1, #0x1f
    //     0x89f80c: tbz             w1, #0, #0x89f814
    //     0x89f810: ldur            x2, [x1, #7]
    // 0x89f814: r17 = 100000
    //     0x89f814: mov             x17, #0x86a0
    //     0x89f818: movk            x17, #1, lsl #16
    // 0x89f81c: cmp             x2, x17
    // 0x89f820: r16 = true
    //     0x89f820: add             x16, NULL, #0x20  ; true
    // 0x89f824: r17 = false
    //     0x89f824: add             x17, NULL, #0x30  ; false
    // 0x89f828: csel            x0, x16, x17, ge
    // 0x89f82c: LeaveFrame
    //     0x89f82c: mov             SP, fp
    //     0x89f830: ldp             fp, lr, [SP], #0x10
    // 0x89f834: ret
    //     0x89f834: ret             
    // 0x89f838: r0 = true
    //     0x89f838: add             x0, NULL, #0x20  ; true
    // 0x89f83c: LeaveFrame
    //     0x89f83c: mov             SP, fp
    //     0x89f840: ldp             fp, lr, [SP], #0x10
    // 0x89f844: ret
    //     0x89f844: ret             
    // 0x89f848: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89f848: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89f84c: b               #0x89f7f8
  }
}

// class id: 2835, size: 0xc, field offset: 0x8
class PerformanceModeRequestHandle extends Object {

  _ dispose(/* No info */) {
    // ** addr: 0xbae07c, size: 0x64
    // 0xbae07c: EnterFrame
    //     0xbae07c: stp             fp, lr, [SP, #-0x10]!
    //     0xbae080: mov             fp, SP
    // 0xbae084: AllocStack(0x8)
    //     0xbae084: sub             SP, SP, #8
    // 0xbae088: SetupParameters(PerformanceModeRequestHandle this /* r1 => r0, fp-0x8 */)
    //     0xbae088: mov             x0, x1
    //     0xbae08c: stur            x1, [fp, #-8]
    // 0xbae090: CheckStackOverflow
    //     0xbae090: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbae094: cmp             SP, x16
    //     0xbae098: b.ls            #0xbae0d4
    // 0xbae09c: LoadField: r1 = r0->field_7
    //     0xbae09c: ldur            w1, [x0, #7]
    // 0xbae0a0: DecompressPointer r1
    //     0xbae0a0: add             x1, x1, HEAP, lsl #32
    // 0xbae0a4: cmp             w1, NULL
    // 0xbae0a8: b.eq            #0xbae0dc
    // 0xbae0ac: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xbae0ac: ldur            w2, [x1, #0x17]
    // 0xbae0b0: DecompressPointer r2
    //     0xbae0b0: add             x2, x2, HEAP, lsl #32
    // 0xbae0b4: mov             x1, x2
    // 0xbae0b8: r0 = _disposePerformanceModeRequest()
    //     0xbae0b8: bl              #0xbadf58  ; [dart:mixin_deduplication] _MixinApplication203&BindingBase&GestureBinding&SchedulerBinding::_disposePerformanceModeRequest
    // 0xbae0bc: ldur            x1, [fp, #-8]
    // 0xbae0c0: StoreField: r1->field_7 = rNULL
    //     0xbae0c0: stur            NULL, [x1, #7]
    // 0xbae0c4: r0 = Null
    //     0xbae0c4: mov             x0, NULL
    // 0xbae0c8: LeaveFrame
    //     0xbae0c8: mov             SP, fp
    //     0xbae0cc: ldp             fp, lr, [SP], #0x10
    // 0xbae0d0: ret
    //     0xbae0d0: ret             
    // 0xbae0d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbae0d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbae0d8: b               #0xbae09c
    // 0xbae0dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbae0dc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2836, size: 0x10, field offset: 0x8
class _FrameCallbackEntry extends Object {
}

// class id: 2837, size: 0xc, field offset: 0x8
abstract class _TaskEntry<X0> extends Object {
}

// class id: 4612, size: 0x10, field offset: 0x10
abstract class SchedulerBinding extends BindingBase {

  get _ instance(/* No info */) {
    // ** addr: 0x82ede0, size: 0x20
    // 0x82ede0: r0 = LoadStaticField(0x5e4)
    //     0x82ede0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x82ede4: ldr             x0, [x0, #0xbc8]
    // 0x82ede8: cmp             w0, NULL
    // 0x82edec: b.eq            #0x82edf4
    // 0x82edf0: ret
    //     0x82edf0: ret             
    // 0x82edf4: EnterFrame
    //     0x82edf4: stp             fp, lr, [SP, #-0x10]!
    //     0x82edf8: mov             fp, SP
    // 0x82edfc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82edfc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 8213, size: 0x14, field offset: 0x14
enum SchedulerPhase extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11ab480, size: 0x64
    // 0x11ab480: EnterFrame
    //     0x11ab480: stp             fp, lr, [SP, #-0x10]!
    //     0x11ab484: mov             fp, SP
    // 0x11ab488: AllocStack(0x10)
    //     0x11ab488: sub             SP, SP, #0x10
    // 0x11ab48c: SetupParameters(SchedulerPhase this /* r1 => r0, fp-0x8 */)
    //     0x11ab48c: mov             x0, x1
    //     0x11ab490: stur            x1, [fp, #-8]
    // 0x11ab494: CheckStackOverflow
    //     0x11ab494: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11ab498: cmp             SP, x16
    //     0x11ab49c: b.ls            #0x11ab4dc
    // 0x11ab4a0: r1 = Null
    //     0x11ab4a0: mov             x1, NULL
    // 0x11ab4a4: r2 = 4
    //     0x11ab4a4: mov             x2, #4
    // 0x11ab4a8: r0 = AllocateArray()
    //     0x11ab4a8: bl              #0x13df928  ; AllocateArrayStub
    // 0x11ab4ac: r16 = "SchedulerPhase."
    //     0x11ab4ac: add             x16, PP, #0x10, lsl #12  ; [pp+0x10ed0] "SchedulerPhase."
    //     0x11ab4b0: ldr             x16, [x16, #0xed0]
    // 0x11ab4b4: StoreField: r0->field_f = r16
    //     0x11ab4b4: stur            w16, [x0, #0xf]
    // 0x11ab4b8: ldur            x1, [fp, #-8]
    // 0x11ab4bc: LoadField: r2 = r1->field_f
    //     0x11ab4bc: ldur            w2, [x1, #0xf]
    // 0x11ab4c0: DecompressPointer r2
    //     0x11ab4c0: add             x2, x2, HEAP, lsl #32
    // 0x11ab4c4: StoreField: r0->field_13 = r2
    //     0x11ab4c4: stur            w2, [x0, #0x13]
    // 0x11ab4c8: str             x0, [SP]
    // 0x11ab4cc: r0 = _interpolate()
    //     0x11ab4cc: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11ab4d0: LeaveFrame
    //     0x11ab4d0: mov             SP, fp
    //     0x11ab4d4: ldp             fp, lr, [SP], #0x10
    // 0x11ab4d8: ret
    //     0x11ab4d8: ret             
    // 0x11ab4dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11ab4dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11ab4e0: b               #0x11ab4a0
  }
}
