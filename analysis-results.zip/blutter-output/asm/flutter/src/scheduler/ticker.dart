// lib: , url: package:flutter/src/scheduler/ticker.dart

// class id: 1049060, size: 0x8
class :: {
}

// class id: 2829, size: 0xc, field offset: 0x8
//   const constructor, 
class TickerCanceled extends Object
    implements Exception {

  _ toString(/* No info */) {
    // ** addr: 0x1115c00, size: 0x80
    // 0x1115c00: EnterFrame
    //     0x1115c00: stp             fp, lr, [SP, #-0x10]!
    //     0x1115c04: mov             fp, SP
    // 0x1115c08: AllocStack(0x10)
    //     0x1115c08: sub             SP, SP, #0x10
    // 0x1115c0c: CheckStackOverflow
    //     0x1115c0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1115c10: cmp             SP, x16
    //     0x1115c14: b.ls            #0x1115c78
    // 0x1115c18: ldr             x0, [fp, #0x10]
    // 0x1115c1c: LoadField: r3 = r0->field_7
    //     0x1115c1c: ldur            w3, [x0, #7]
    // 0x1115c20: DecompressPointer r3
    //     0x1115c20: add             x3, x3, HEAP, lsl #32
    // 0x1115c24: stur            x3, [fp, #-8]
    // 0x1115c28: cmp             w3, NULL
    // 0x1115c2c: b.eq            #0x1115c64
    // 0x1115c30: r1 = Null
    //     0x1115c30: mov             x1, NULL
    // 0x1115c34: r2 = 4
    //     0x1115c34: mov             x2, #4
    // 0x1115c38: r0 = AllocateArray()
    //     0x1115c38: bl              #0x13df928  ; AllocateArrayStub
    // 0x1115c3c: r16 = "This ticker was canceled: "
    //     0x1115c3c: add             x16, PP, #0xe, lsl #12  ; [pp+0xe300] "This ticker was canceled: "
    //     0x1115c40: ldr             x16, [x16, #0x300]
    // 0x1115c44: StoreField: r0->field_f = r16
    //     0x1115c44: stur            w16, [x0, #0xf]
    // 0x1115c48: ldur            x1, [fp, #-8]
    // 0x1115c4c: StoreField: r0->field_13 = r1
    //     0x1115c4c: stur            w1, [x0, #0x13]
    // 0x1115c50: str             x0, [SP]
    // 0x1115c54: r0 = _interpolate()
    //     0x1115c54: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x1115c58: LeaveFrame
    //     0x1115c58: mov             SP, fp
    //     0x1115c5c: ldp             fp, lr, [SP], #0x10
    // 0x1115c60: ret
    //     0x1115c60: ret             
    // 0x1115c64: r0 = "The ticker was canceled before the \"orCancel\" property was first used."
    //     0x1115c64: add             x0, PP, #0xe, lsl #12  ; [pp+0xe308] "The ticker was canceled before the \"orCancel\" property was first used."
    //     0x1115c68: ldr             x0, [x0, #0x308]
    // 0x1115c6c: LeaveFrame
    //     0x1115c6c: mov             SP, fp
    //     0x1115c70: ldp             fp, lr, [SP], #0x10
    // 0x1115c74: ret
    //     0x1115c74: ret             
    // 0x1115c78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1115c78: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1115c7c: b               #0x1115c18
  }
}

// class id: 2830, size: 0x14, field offset: 0x8
class TickerFuture extends Object
    implements Future<X0> {

  _ _complete(/* No info */) {
    // ** addr: 0x82ec7c, size: 0x6c
    // 0x82ec7c: EnterFrame
    //     0x82ec7c: stp             fp, lr, [SP, #-0x10]!
    //     0x82ec80: mov             fp, SP
    // 0x82ec84: AllocStack(0x8)
    //     0x82ec84: sub             SP, SP, #8
    // 0x82ec88: r0 = true
    //     0x82ec88: add             x0, NULL, #0x20  ; true
    // 0x82ec8c: mov             x2, x1
    // 0x82ec90: stur            x1, [fp, #-8]
    // 0x82ec94: CheckStackOverflow
    //     0x82ec94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82ec98: cmp             SP, x16
    //     0x82ec9c: b.ls            #0x82ece0
    // 0x82eca0: StoreField: r2->field_f = r0
    //     0x82eca0: stur            w0, [x2, #0xf]
    // 0x82eca4: LoadField: r1 = r2->field_7
    //     0x82eca4: ldur            w1, [x2, #7]
    // 0x82eca8: DecompressPointer r1
    //     0x82eca8: add             x1, x1, HEAP, lsl #32
    // 0x82ecac: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x82ecac: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x82ecb0: r0 = complete()
    //     0x82ecb0: bl              #0x128a5ec  ; [dart:async] _AsyncCompleter::complete
    // 0x82ecb4: ldur            x0, [fp, #-8]
    // 0x82ecb8: LoadField: r1 = r0->field_b
    //     0x82ecb8: ldur            w1, [x0, #0xb]
    // 0x82ecbc: DecompressPointer r1
    //     0x82ecbc: add             x1, x1, HEAP, lsl #32
    // 0x82ecc0: cmp             w1, NULL
    // 0x82ecc4: b.eq            #0x82ecd0
    // 0x82ecc8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x82ecc8: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x82eccc: r0 = complete()
    //     0x82eccc: bl              #0x128a5ec  ; [dart:async] _AsyncCompleter::complete
    // 0x82ecd0: r0 = Null
    //     0x82ecd0: mov             x0, NULL
    // 0x82ecd4: LeaveFrame
    //     0x82ecd4: mov             SP, fp
    //     0x82ecd8: ldp             fp, lr, [SP], #0x10
    // 0x82ecdc: ret
    //     0x82ecdc: ret             
    // 0x82ece0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82ece0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82ece4: b               #0x82eca0
  }
  _ _cancel(/* No info */) {
    // ** addr: 0x82ece8, size: 0x70
    // 0x82ece8: EnterFrame
    //     0x82ece8: stp             fp, lr, [SP, #-0x10]!
    //     0x82ecec: mov             fp, SP
    // 0x82ecf0: AllocStack(0x10)
    //     0x82ecf0: sub             SP, SP, #0x10
    // 0x82ecf4: r0 = false
    //     0x82ecf4: add             x0, NULL, #0x30  ; false
    // 0x82ecf8: stur            x2, [fp, #-0x10]
    // 0x82ecfc: CheckStackOverflow
    //     0x82ecfc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82ed00: cmp             SP, x16
    //     0x82ed04: b.ls            #0x82ed50
    // 0x82ed08: StoreField: r1->field_f = r0
    //     0x82ed08: stur            w0, [x1, #0xf]
    // 0x82ed0c: LoadField: r0 = r1->field_b
    //     0x82ed0c: ldur            w0, [x1, #0xb]
    // 0x82ed10: DecompressPointer r0
    //     0x82ed10: add             x0, x0, HEAP, lsl #32
    // 0x82ed14: stur            x0, [fp, #-8]
    // 0x82ed18: cmp             w0, NULL
    // 0x82ed1c: b.eq            #0x82ed40
    // 0x82ed20: r0 = TickerCanceled()
    //     0x82ed20: bl              #0x82ed58  ; AllocateTickerCanceledStub -> TickerCanceled (size=0xc)
    // 0x82ed24: mov             x1, x0
    // 0x82ed28: ldur            x0, [fp, #-0x10]
    // 0x82ed2c: StoreField: r1->field_7 = r0
    //     0x82ed2c: stur            w0, [x1, #7]
    // 0x82ed30: mov             x2, x1
    // 0x82ed34: ldur            x1, [fp, #-8]
    // 0x82ed38: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x82ed38: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x82ed3c: r0 = completeError()
    //     0x82ed3c: bl              #0x7f6b94  ; [dart:async] _Completer::completeError
    // 0x82ed40: r0 = Null
    //     0x82ed40: mov             x0, NULL
    // 0x82ed44: LeaveFrame
    //     0x82ed44: mov             SP, fp
    //     0x82ed48: ldp             fp, lr, [SP], #0x10
    // 0x82ed4c: ret
    //     0x82ed4c: ret             
    // 0x82ed50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82ed50: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82ed54: b               #0x82ed08
  }
  _ whenCompleteOrCancel(/* No info */) {
    // ** addr: 0x8ccecc, size: 0x84
    // 0x8ccecc: EnterFrame
    //     0x8ccecc: stp             fp, lr, [SP, #-0x10]!
    //     0x8cced0: mov             fp, SP
    // 0x8cced4: AllocStack(0x30)
    //     0x8cced4: sub             SP, SP, #0x30
    // 0x8cced8: SetupParameters(TickerFuture this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x8cced8: stur            x1, [fp, #-8]
    //     0x8ccedc: stur            x2, [fp, #-0x10]
    // 0x8ccee0: CheckStackOverflow
    //     0x8ccee0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ccee4: cmp             SP, x16
    //     0x8ccee8: b.ls            #0x8ccf48
    // 0x8cceec: r1 = 1
    //     0x8cceec: mov             x1, #1
    // 0x8ccef0: r0 = AllocateContext()
    //     0x8ccef0: bl              #0x13de838  ; AllocateContextStub
    // 0x8ccef4: mov             x1, x0
    // 0x8ccef8: ldur            x0, [fp, #-0x10]
    // 0x8ccefc: StoreField: r1->field_f = r0
    //     0x8ccefc: stur            w0, [x1, #0xf]
    // 0x8ccf00: mov             x2, x1
    // 0x8ccf04: r1 = Function 'thunk':.
    //     0x8ccf04: add             x1, PP, #0x14, lsl #12  ; [pp+0x14db0] AnonymousClosure: static (0x8cd054), in [dart:async] Timer::_createTimer (0x8cd0a8)
    //     0x8ccf08: ldr             x1, [x1, #0xdb0]
    // 0x8ccf0c: r0 = AllocateClosure()
    //     0x8ccf0c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8ccf10: ldur            x1, [fp, #-8]
    // 0x8ccf14: stur            x0, [fp, #-8]
    // 0x8ccf18: r0 = orCancel()
    //     0x8ccf18: bl              #0x8ccf50  ; [package:flutter/src/scheduler/ticker.dart] TickerFuture::orCancel
    // 0x8ccf1c: r16 = <void?>
    //     0x8ccf1c: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x8ccf20: stp             x0, x16, [SP, #0x10]
    // 0x8ccf24: ldur            x16, [fp, #-8]
    // 0x8ccf28: ldur            lr, [fp, #-8]
    // 0x8ccf2c: stp             lr, x16, [SP]
    // 0x8ccf30: r4 = const [0x1, 0x3, 0x3, 0x2, onError, 0x2, null]
    //     0x8ccf30: ldr             x4, [PP, #0x538]  ; [pp+0x538] List(7) [0x1, 0x3, 0x3, 0x2, "onError", 0x2, Null]
    // 0x8ccf34: r0 = then()
    //     0x8ccf34: bl              #0x1293070  ; [dart:async] _Future::then
    // 0x8ccf38: r0 = Null
    //     0x8ccf38: mov             x0, NULL
    // 0x8ccf3c: LeaveFrame
    //     0x8ccf3c: mov             SP, fp
    //     0x8ccf40: ldp             fp, lr, [SP], #0x10
    // 0x8ccf44: ret
    //     0x8ccf44: ret             
    // 0x8ccf48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ccf48: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ccf4c: b               #0x8cceec
  }
  get _ orCancel(/* No info */) {
    // ** addr: 0x8ccf50, size: 0x104
    // 0x8ccf50: EnterFrame
    //     0x8ccf50: stp             fp, lr, [SP, #-0x10]!
    //     0x8ccf54: mov             fp, SP
    // 0x8ccf58: AllocStack(0x10)
    //     0x8ccf58: sub             SP, SP, #0x10
    // 0x8ccf5c: SetupParameters(TickerFuture this /* r1 => r0, fp-0x8 */)
    //     0x8ccf5c: mov             x0, x1
    //     0x8ccf60: stur            x1, [fp, #-8]
    // 0x8ccf64: CheckStackOverflow
    //     0x8ccf64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ccf68: cmp             SP, x16
    //     0x8ccf6c: b.ls            #0x8cd048
    // 0x8ccf70: LoadField: r1 = r0->field_b
    //     0x8ccf70: ldur            w1, [x0, #0xb]
    // 0x8ccf74: DecompressPointer r1
    //     0x8ccf74: add             x1, x1, HEAP, lsl #32
    // 0x8ccf78: cmp             w1, NULL
    // 0x8ccf7c: b.ne            #0x8cd020
    // 0x8ccf80: r1 = <void?>
    //     0x8ccf80: ldr             x1, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x8ccf84: r0 = _Future()
    //     0x8ccf84: bl              #0x7f5dd4  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0x8ccf88: stur            x0, [fp, #-0x10]
    // 0x8ccf8c: StoreField: r0->field_b = rZR
    //     0x8ccf8c: stur            xzr, [x0, #0xb]
    // 0x8ccf90: r0 = LoadStaticField(0x364)
    //     0x8ccf90: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8ccf94: ldr             x0, [x0, #0x6c8]
    // 0x8ccf98: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8ccf9c: cmp             w0, w16
    // 0x8ccfa0: b.ne            #0x8ccfac
    // 0x8ccfa4: r2 = _current
    //     0x8ccfa4: ldr             x2, [PP, #0x2c0]  ; [pp+0x2c0] Field <Zone._current@5048458>: static late (offset: 0x364)
    // 0x8ccfa8: r0 = InitLateStaticField()
    //     0x8ccfa8: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0x8ccfac: mov             x1, x0
    // 0x8ccfb0: ldur            x0, [fp, #-0x10]
    // 0x8ccfb4: StoreField: r0->field_13 = r1
    //     0x8ccfb4: stur            w1, [x0, #0x13]
    // 0x8ccfb8: r1 = <void?>
    //     0x8ccfb8: ldr             x1, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x8ccfbc: r0 = _AsyncCompleter()
    //     0x8ccfbc: bl              #0x7f5dc8  ; Allocate_AsyncCompleterStub -> _AsyncCompleter<X0> (size=0x10)
    // 0x8ccfc0: mov             x1, x0
    // 0x8ccfc4: ldur            x0, [fp, #-0x10]
    // 0x8ccfc8: StoreField: r1->field_b = r0
    //     0x8ccfc8: stur            w0, [x1, #0xb]
    // 0x8ccfcc: mov             x0, x1
    // 0x8ccfd0: ldur            x2, [fp, #-8]
    // 0x8ccfd4: StoreField: r2->field_b = r0
    //     0x8ccfd4: stur            w0, [x2, #0xb]
    //     0x8ccfd8: ldurb           w16, [x2, #-1]
    //     0x8ccfdc: ldurb           w17, [x0, #-1]
    //     0x8ccfe0: and             x16, x17, x16, lsr #2
    //     0x8ccfe4: tst             x16, HEAP, lsr #32
    //     0x8ccfe8: b.eq            #0x8ccff0
    //     0x8ccfec: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x8ccff0: LoadField: r0 = r2->field_f
    //     0x8ccff0: ldur            w0, [x2, #0xf]
    // 0x8ccff4: DecompressPointer r0
    //     0x8ccff4: add             x0, x0, HEAP, lsl #32
    // 0x8ccff8: cmp             w0, NULL
    // 0x8ccffc: b.eq            #0x8cd020
    // 0x8cd000: tbnz            w0, #4, #0x8cd010
    // 0x8cd004: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8cd004: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8cd008: r0 = complete()
    //     0x8cd008: bl              #0x128a5ec  ; [dart:async] _AsyncCompleter::complete
    // 0x8cd00c: b               #0x8cd020
    // 0x8cd010: r2 = Instance_TickerCanceled
    //     0x8cd010: add             x2, PP, #0x14, lsl #12  ; [pp+0x14db8] Obj!TickerCanceled@129c0d1
    //     0x8cd014: ldr             x2, [x2, #0xdb8]
    // 0x8cd018: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8cd018: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8cd01c: r0 = completeError()
    //     0x8cd01c: bl              #0x7f6b94  ; [dart:async] _Completer::completeError
    // 0x8cd020: ldur            x1, [fp, #-8]
    // 0x8cd024: LoadField: r2 = r1->field_b
    //     0x8cd024: ldur            w2, [x1, #0xb]
    // 0x8cd028: DecompressPointer r2
    //     0x8cd028: add             x2, x2, HEAP, lsl #32
    // 0x8cd02c: cmp             w2, NULL
    // 0x8cd030: b.eq            #0x8cd050
    // 0x8cd034: LoadField: r0 = r2->field_b
    //     0x8cd034: ldur            w0, [x2, #0xb]
    // 0x8cd038: DecompressPointer r0
    //     0x8cd038: add             x0, x0, HEAP, lsl #32
    // 0x8cd03c: LeaveFrame
    //     0x8cd03c: mov             SP, fp
    //     0x8cd040: ldp             fp, lr, [SP], #0x10
    // 0x8cd044: ret
    //     0x8cd044: ret             
    // 0x8cd048: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cd048: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cd04c: b               #0x8ccf70
    // 0x8cd050: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8cd050: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ catchError(/* No info */) {
    // ** addr: 0x1303868, size: 0x4c
    // 0x1303868: EnterFrame
    //     0x1303868: stp             fp, lr, [SP, #-0x10]!
    //     0x130386c: mov             fp, SP
    // 0x1303870: AllocStack(0x8)
    //     0x1303870: sub             SP, SP, #8
    // 0x1303874: CheckStackOverflow
    //     0x1303874: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1303878: cmp             SP, x16
    //     0x130387c: b.ls            #0x13038ac
    // 0x1303880: LoadField: r0 = r1->field_7
    //     0x1303880: ldur            w0, [x1, #7]
    // 0x1303884: DecompressPointer r0
    //     0x1303884: add             x0, x0, HEAP, lsl #32
    // 0x1303888: LoadField: r1 = r0->field_b
    //     0x1303888: ldur            w1, [x0, #0xb]
    // 0x130388c: DecompressPointer r1
    //     0x130388c: add             x1, x1, HEAP, lsl #32
    // 0x1303890: str             NULL, [SP]
    // 0x1303894: r4 = const [0, 0x3, 0x1, 0x2, test, 0x2, null]
    //     0x1303894: add             x4, PP, #0xb, lsl #12  ; [pp+0xbc70] List(7) [0, 0x3, 0x1, 0x2, "test", 0x2, Null]
    //     0x1303898: ldr             x4, [x4, #0xc70]
    // 0x130389c: r0 = catchError()
    //     0x130389c: bl              #0x1291b1c  ; [dart:async] _Future::catchError
    // 0x13038a0: LeaveFrame
    //     0x13038a0: mov             SP, fp
    //     0x13038a4: ldp             fp, lr, [SP], #0x10
    // 0x13038a8: ret
    //     0x13038a8: ret             
    // 0x13038ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13038ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13038b0: b               #0x1303880
  }
  _ whenComplete(/* No info */) {
    // ** addr: 0x1308378, size: 0x3c
    // 0x1308378: EnterFrame
    //     0x1308378: stp             fp, lr, [SP, #-0x10]!
    //     0x130837c: mov             fp, SP
    // 0x1308380: CheckStackOverflow
    //     0x1308380: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1308384: cmp             SP, x16
    //     0x1308388: b.ls            #0x13083ac
    // 0x130838c: LoadField: r0 = r1->field_7
    //     0x130838c: ldur            w0, [x1, #7]
    // 0x1308390: DecompressPointer r0
    //     0x1308390: add             x0, x0, HEAP, lsl #32
    // 0x1308394: LoadField: r1 = r0->field_b
    //     0x1308394: ldur            w1, [x0, #0xb]
    // 0x1308398: DecompressPointer r1
    //     0x1308398: add             x1, x1, HEAP, lsl #32
    // 0x130839c: r0 = whenComplete()
    //     0x130839c: bl              #0x1292f08  ; [dart:async] _Future::whenComplete
    // 0x13083a0: LeaveFrame
    //     0x13083a0: mov             SP, fp
    //     0x13083a4: ldp             fp, lr, [SP], #0x10
    // 0x13083a8: ret
    //     0x13083a8: ret             
    // 0x13083ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13083ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13083b0: b               #0x130838c
  }
  _ then(/* No info */) {
    // ** addr: 0x13083d8, size: 0xb4
    // 0x13083d8: EnterFrame
    //     0x13083d8: stp             fp, lr, [SP, #-0x10]!
    //     0x13083dc: mov             fp, SP
    // 0x13083e0: AllocStack(0x20)
    //     0x13083e0: sub             SP, SP, #0x20
    // 0x13083e4: SetupParameters(TickerFuture this /* r2 */, dynamic _ /* r3 */, {dynamic onError = Null /* r0 */})
    //     0x13083e4: ldur            w0, [x4, #0x13]
    //     0x13083e8: sub             x1, x0, #4
    //     0x13083ec: add             x2, fp, w1, sxtw #2
    //     0x13083f0: ldr             x2, [x2, #0x18]
    //     0x13083f4: add             x3, fp, w1, sxtw #2
    //     0x13083f8: ldr             x3, [x3, #0x10]
    //     0x13083fc: ldur            w1, [x4, #0x1f]
    //     0x1308400: add             x1, x1, HEAP, lsl #32
    //     0x1308404: ldr             x16, [PP, #0x1f0]  ; [pp+0x1f0] "onError"
    //     0x1308408: cmp             w1, w16
    //     0x130840c: b.ne            #0x1308428
    //     0x1308410: ldur            w1, [x4, #0x23]
    //     0x1308414: add             x1, x1, HEAP, lsl #32
    //     0x1308418: sub             w5, w0, w1
    //     0x130841c: add             x0, fp, w5, sxtw #2
    //     0x1308420: ldr             x0, [x0, #8]
    //     0x1308424: b               #0x130842c
    //     0x1308428: mov             x0, NULL
    //     0x130842c: ldur            w1, [x4, #0xf]
    //     0x1308430: cbnz            w1, #0x130843c
    //     0x1308434: mov             x1, NULL
    //     0x1308438: b               #0x130844c
    //     0x130843c: ldur            w1, [x4, #0x17]
    //     0x1308440: add             x4, fp, w1, sxtw #2
    //     0x1308444: ldr             x4, [x4, #0x10]
    //     0x1308448: mov             x1, x4
    // 0x130844c: CheckStackOverflow
    //     0x130844c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1308450: cmp             SP, x16
    //     0x1308454: b.ls            #0x1308484
    // 0x1308458: LoadField: r4 = r2->field_7
    //     0x1308458: ldur            w4, [x2, #7]
    // 0x130845c: DecompressPointer r4
    //     0x130845c: add             x4, x4, HEAP, lsl #32
    // 0x1308460: LoadField: r2 = r4->field_b
    //     0x1308460: ldur            w2, [x4, #0xb]
    // 0x1308464: DecompressPointer r2
    //     0x1308464: add             x2, x2, HEAP, lsl #32
    // 0x1308468: stp             x2, x1, [SP, #0x10]
    // 0x130846c: stp             x0, x3, [SP]
    // 0x1308470: r4 = const [0x1, 0x3, 0x3, 0x2, onError, 0x2, null]
    //     0x1308470: ldr             x4, [PP, #0x538]  ; [pp+0x538] List(7) [0x1, 0x3, 0x3, 0x2, "onError", 0x2, Null]
    // 0x1308474: r0 = then()
    //     0x1308474: bl              #0x1293070  ; [dart:async] _Future::then
    // 0x1308478: LeaveFrame
    //     0x1308478: mov             SP, fp
    //     0x130847c: ldp             fp, lr, [SP], #0x10
    // 0x1308480: ret
    //     0x1308480: ret             
    // 0x1308484: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1308484: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1308488: b               #0x1308458
  }
}

// class id: 2831, size: 0x20, field offset: 0x8
class Ticker extends Object {

  _ stop(/* No info */) {
    // ** addr: 0x82ebb4, size: 0xc8
    // 0x82ebb4: EnterFrame
    //     0x82ebb4: stp             fp, lr, [SP, #-0x10]!
    //     0x82ebb8: mov             fp, SP
    // 0x82ebbc: AllocStack(0x18)
    //     0x82ebbc: sub             SP, SP, #0x18
    // 0x82ebc0: SetupParameters(Ticker this /* r1 => r0, fp-0x18 */, {dynamic canceled = false /* r2, fp-0x10 */})
    //     0x82ebc0: mov             x0, x1
    //     0x82ebc4: stur            x1, [fp, #-0x18]
    //     0x82ebc8: ldur            w1, [x4, #0x13]
    //     0x82ebcc: ldur            w2, [x4, #0x1f]
    //     0x82ebd0: add             x2, x2, HEAP, lsl #32
    //     0x82ebd4: ldr             x16, [PP, #0x5598]  ; [pp+0x5598] "canceled"
    //     0x82ebd8: cmp             w2, w16
    //     0x82ebdc: b.ne            #0x82ebfc
    //     0x82ebe0: ldur            w2, [x4, #0x23]
    //     0x82ebe4: add             x2, x2, HEAP, lsl #32
    //     0x82ebe8: sub             w3, w1, w2
    //     0x82ebec: add             x1, fp, w3, sxtw #2
    //     0x82ebf0: ldr             x1, [x1, #8]
    //     0x82ebf4: mov             x2, x1
    //     0x82ebf8: b               #0x82ec00
    //     0x82ebfc: add             x2, NULL, #0x30  ; false
    //     0x82ec00: stur            x2, [fp, #-0x10]
    // 0x82ec04: CheckStackOverflow
    //     0x82ec04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82ec08: cmp             SP, x16
    //     0x82ec0c: b.ls            #0x82ec74
    // 0x82ec10: LoadField: r3 = r0->field_7
    //     0x82ec10: ldur            w3, [x0, #7]
    // 0x82ec14: DecompressPointer r3
    //     0x82ec14: add             x3, x3, HEAP, lsl #32
    // 0x82ec18: stur            x3, [fp, #-8]
    // 0x82ec1c: cmp             w3, NULL
    // 0x82ec20: b.ne            #0x82ec34
    // 0x82ec24: r0 = Null
    //     0x82ec24: mov             x0, NULL
    // 0x82ec28: LeaveFrame
    //     0x82ec28: mov             SP, fp
    //     0x82ec2c: ldp             fp, lr, [SP], #0x10
    // 0x82ec30: ret
    //     0x82ec30: ret             
    // 0x82ec34: StoreField: r0->field_7 = rNULL
    //     0x82ec34: stur            NULL, [x0, #7]
    // 0x82ec38: StoreField: r0->field_13 = rNULL
    //     0x82ec38: stur            NULL, [x0, #0x13]
    // 0x82ec3c: mov             x1, x0
    // 0x82ec40: r0 = unscheduleTick()
    //     0x82ec40: bl              #0x82ed64  ; [package:flutter/src/scheduler/ticker.dart] Ticker::unscheduleTick
    // 0x82ec44: ldur            x0, [fp, #-0x10]
    // 0x82ec48: tbnz            w0, #4, #0x82ec5c
    // 0x82ec4c: ldur            x1, [fp, #-8]
    // 0x82ec50: ldur            x2, [fp, #-0x18]
    // 0x82ec54: r0 = _cancel()
    //     0x82ec54: bl              #0x82ece8  ; [package:flutter/src/scheduler/ticker.dart] TickerFuture::_cancel
    // 0x82ec58: b               #0x82ec64
    // 0x82ec5c: ldur            x1, [fp, #-8]
    // 0x82ec60: r0 = _complete()
    //     0x82ec60: bl              #0x82ec7c  ; [package:flutter/src/scheduler/ticker.dart] TickerFuture::_complete
    // 0x82ec64: r0 = Null
    //     0x82ec64: mov             x0, NULL
    // 0x82ec68: LeaveFrame
    //     0x82ec68: mov             SP, fp
    //     0x82ec6c: ldp             fp, lr, [SP], #0x10
    // 0x82ec70: ret
    //     0x82ec70: ret             
    // 0x82ec74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82ec74: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82ec78: b               #0x82ec10
  }
  _ unscheduleTick(/* No info */) {
    // ** addr: 0x82ed64, size: 0x7c
    // 0x82ed64: EnterFrame
    //     0x82ed64: stp             fp, lr, [SP, #-0x10]!
    //     0x82ed68: mov             fp, SP
    // 0x82ed6c: AllocStack(0x8)
    //     0x82ed6c: sub             SP, SP, #8
    // 0x82ed70: SetupParameters(Ticker this /* r1 => r0, fp-0x8 */)
    //     0x82ed70: mov             x0, x1
    //     0x82ed74: stur            x1, [fp, #-8]
    // 0x82ed78: CheckStackOverflow
    //     0x82ed78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82ed7c: cmp             SP, x16
    //     0x82ed80: b.ls            #0x82edd4
    // 0x82ed84: LoadField: r1 = r0->field_1b
    //     0x82ed84: ldur            w1, [x0, #0x1b]
    // 0x82ed88: DecompressPointer r1
    //     0x82ed88: add             x1, x1, HEAP, lsl #32
    // 0x82ed8c: cmp             w1, NULL
    // 0x82ed90: b.eq            #0x82edc4
    // 0x82ed94: r2 = LoadStaticField(0x5e4)
    //     0x82ed94: ldr             x2, [THR, #0x78]  ; THR::field_table_values
    //     0x82ed98: ldr             x2, [x2, #0xbc8]
    // 0x82ed9c: cmp             w2, NULL
    // 0x82eda0: b.eq            #0x82eddc
    // 0x82eda4: r3 = LoadInt32Instr(r1)
    //     0x82eda4: sbfx            x3, x1, #1, #0x1f
    //     0x82eda8: tbz             w1, #0, #0x82edb0
    //     0x82edac: ldur            x3, [x1, #7]
    // 0x82edb0: mov             x1, x2
    // 0x82edb4: mov             x2, x3
    // 0x82edb8: r0 = cancelFrameCallbackWithId()
    //     0x82edb8: bl              #0x82ee00  ; [dart:mixin_deduplication] _MixinApplication203&BindingBase&GestureBinding&SchedulerBinding::cancelFrameCallbackWithId
    // 0x82edbc: ldur            x1, [fp, #-8]
    // 0x82edc0: StoreField: r1->field_1b = rNULL
    //     0x82edc0: stur            NULL, [x1, #0x1b]
    // 0x82edc4: r0 = Null
    //     0x82edc4: mov             x0, NULL
    // 0x82edc8: LeaveFrame
    //     0x82edc8: mov             SP, fp
    //     0x82edcc: ldp             fp, lr, [SP], #0x10
    // 0x82edd0: ret
    //     0x82edd0: ret             
    // 0x82edd4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82edd4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82edd8: b               #0x82ed84
    // 0x82eddc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82eddc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ start(/* No info */) {
    // ** addr: 0x866794, size: 0x154
    // 0x866794: EnterFrame
    //     0x866794: stp             fp, lr, [SP, #-0x10]!
    //     0x866798: mov             fp, SP
    // 0x86679c: AllocStack(0x18)
    //     0x86679c: sub             SP, SP, #0x18
    // 0x8667a0: SetupParameters(Ticker this /* r1 => r0, fp-0x8 */)
    //     0x8667a0: mov             x0, x1
    //     0x8667a4: stur            x1, [fp, #-8]
    // 0x8667a8: CheckStackOverflow
    //     0x8667a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8667ac: cmp             SP, x16
    //     0x8667b0: b.ls            #0x8668d4
    // 0x8667b4: r1 = <void?>
    //     0x8667b4: ldr             x1, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x8667b8: r0 = _Future()
    //     0x8667b8: bl              #0x7f5dd4  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0x8667bc: stur            x0, [fp, #-0x10]
    // 0x8667c0: StoreField: r0->field_b = rZR
    //     0x8667c0: stur            xzr, [x0, #0xb]
    // 0x8667c4: r0 = LoadStaticField(0x364)
    //     0x8667c4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8667c8: ldr             x0, [x0, #0x6c8]
    // 0x8667cc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8667d0: cmp             w0, w16
    // 0x8667d4: b.ne            #0x8667e0
    // 0x8667d8: r2 = _current
    //     0x8667d8: ldr             x2, [PP, #0x2c0]  ; [pp+0x2c0] Field <Zone._current@5048458>: static late (offset: 0x364)
    // 0x8667dc: r0 = InitLateStaticField()
    //     0x8667dc: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0x8667e0: mov             x1, x0
    // 0x8667e4: ldur            x0, [fp, #-0x10]
    // 0x8667e8: StoreField: r0->field_13 = r1
    //     0x8667e8: stur            w1, [x0, #0x13]
    // 0x8667ec: r1 = <void?>
    //     0x8667ec: ldr             x1, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x8667f0: r0 = _AsyncCompleter()
    //     0x8667f0: bl              #0x7f5dc8  ; Allocate_AsyncCompleterStub -> _AsyncCompleter<X0> (size=0x10)
    // 0x8667f4: mov             x1, x0
    // 0x8667f8: ldur            x0, [fp, #-0x10]
    // 0x8667fc: stur            x1, [fp, #-0x18]
    // 0x866800: StoreField: r1->field_b = r0
    //     0x866800: stur            w0, [x1, #0xb]
    // 0x866804: r0 = TickerFuture()
    //     0x866804: bl              #0x866cec  ; AllocateTickerFutureStub -> TickerFuture (size=0x14)
    // 0x866808: mov             x1, x0
    // 0x86680c: ldur            x0, [fp, #-0x18]
    // 0x866810: StoreField: r1->field_7 = r0
    //     0x866810: stur            w0, [x1, #7]
    // 0x866814: mov             x0, x1
    // 0x866818: ldur            x2, [fp, #-8]
    // 0x86681c: StoreField: r2->field_7 = r0
    //     0x86681c: stur            w0, [x2, #7]
    //     0x866820: ldurb           w16, [x2, #-1]
    //     0x866824: ldurb           w17, [x0, #-1]
    //     0x866828: and             x16, x17, x16, lsr #2
    //     0x86682c: tst             x16, HEAP, lsr #32
    //     0x866830: b.eq            #0x866838
    //     0x866834: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x866838: mov             x1, x2
    // 0x86683c: r0 = shouldScheduleTick()
    //     0x86683c: bl              #0x866bcc  ; [package:flutter/src/scheduler/ticker.dart] Ticker::shouldScheduleTick
    // 0x866840: tbnz            w0, #4, #0x86684c
    // 0x866844: ldur            x1, [fp, #-8]
    // 0x866848: r0 = scheduleTick()
    //     0x866848: bl              #0x8668e8  ; [package:flutter/src/scheduler/ticker.dart] Ticker::scheduleTick
    // 0x86684c: r1 = LoadStaticField(0x5e4)
    //     0x86684c: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x866850: ldr             x1, [x1, #0xbc8]
    // 0x866854: cmp             w1, NULL
    // 0x866858: b.eq            #0x8668dc
    // 0x86685c: LoadField: r2 = r1->field_5f
    //     0x86685c: ldur            w2, [x1, #0x5f]
    // 0x866860: DecompressPointer r2
    //     0x866860: add             x2, x2, HEAP, lsl #32
    // 0x866864: LoadField: r3 = r2->field_7
    //     0x866864: ldur            x3, [x2, #7]
    // 0x866868: cmp             x3, #0
    // 0x86686c: b.le            #0x8668b4
    // 0x866870: cmp             x3, #4
    // 0x866874: b.ge            #0x8668ac
    // 0x866878: ldur            x2, [fp, #-8]
    // 0x86687c: LoadField: r0 = r1->field_77
    //     0x86687c: ldur            w0, [x1, #0x77]
    // 0x866880: DecompressPointer r0
    //     0x866880: add             x0, x0, HEAP, lsl #32
    // 0x866884: cmp             w0, NULL
    // 0x866888: b.eq            #0x8668e0
    // 0x86688c: StoreField: r2->field_13 = r0
    //     0x86688c: stur            w0, [x2, #0x13]
    //     0x866890: ldurb           w16, [x2, #-1]
    //     0x866894: ldurb           w17, [x0, #-1]
    //     0x866898: and             x16, x17, x16, lsr #2
    //     0x86689c: tst             x16, HEAP, lsr #32
    //     0x8668a0: b.eq            #0x8668a8
    //     0x8668a4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x8668a8: b               #0x8668b8
    // 0x8668ac: ldur            x2, [fp, #-8]
    // 0x8668b0: b               #0x8668b8
    // 0x8668b4: ldur            x2, [fp, #-8]
    // 0x8668b8: LoadField: r0 = r2->field_7
    //     0x8668b8: ldur            w0, [x2, #7]
    // 0x8668bc: DecompressPointer r0
    //     0x8668bc: add             x0, x0, HEAP, lsl #32
    // 0x8668c0: cmp             w0, NULL
    // 0x8668c4: b.eq            #0x8668e4
    // 0x8668c8: LeaveFrame
    //     0x8668c8: mov             SP, fp
    //     0x8668cc: ldp             fp, lr, [SP], #0x10
    // 0x8668d0: ret
    //     0x8668d0: ret             
    // 0x8668d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8668d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8668d8: b               #0x8667b4
    // 0x8668dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8668dc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8668e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8668e0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8668e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8668e4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ scheduleTick(/* No info */) {
    // ** addr: 0x8668e8, size: 0xc8
    // 0x8668e8: EnterFrame
    //     0x8668e8: stp             fp, lr, [SP, #-0x10]!
    //     0x8668ec: mov             fp, SP
    // 0x8668f0: AllocStack(0x18)
    //     0x8668f0: sub             SP, SP, #0x18
    // 0x8668f4: SetupParameters(Ticker this /* r1 => r2, fp-0x8 */)
    //     0x8668f4: mov             x2, x1
    //     0x8668f8: stur            x1, [fp, #-8]
    // 0x8668fc: CheckStackOverflow
    //     0x8668fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x866900: cmp             SP, x16
    //     0x866904: b.ls            #0x8669a0
    // 0x866908: r1 = LoadStaticField(0x5e4)
    //     0x866908: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x86690c: ldr             x1, [x1, #0xbc8]
    // 0x866910: cmp             w1, NULL
    // 0x866914: b.eq            #0x8669a8
    // 0x866918: r0 = scheduleFrame()
    //     0x866918: bl              #0x830678  ; [dart:mixin_deduplication] _MixinApplication203&BindingBase&GestureBinding&SchedulerBinding::scheduleFrame
    // 0x86691c: r0 = LoadStaticField(0x5e4)
    //     0x86691c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x866920: ldr             x0, [x0, #0xbc8]
    // 0x866924: stur            x0, [fp, #-0x10]
    // 0x866928: cmp             w0, NULL
    // 0x86692c: b.eq            #0x8669ac
    // 0x866930: ldur            x2, [fp, #-8]
    // 0x866934: r1 = Function '_tick@27494659':.
    //     0x866934: ldr             x1, [PP, #0x51c8]  ; [pp+0x51c8] AnonymousClosure: (0x866ac8), in [package:flutter/src/scheduler/ticker.dart] Ticker::_tick (0x866b04)
    // 0x866938: r0 = AllocateClosure()
    //     0x866938: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x86693c: r16 = false
    //     0x86693c: add             x16, NULL, #0x30  ; false
    // 0x866940: str             x16, [SP]
    // 0x866944: ldur            x1, [fp, #-0x10]
    // 0x866948: mov             x2, x0
    // 0x86694c: r4 = const [0, 0x3, 0x1, 0x2, scheduleNewFrame, 0x2, null]
    //     0x86694c: ldr             x4, [PP, #0x51d0]  ; [pp+0x51d0] List(7) [0, 0x3, 0x1, 0x2, "scheduleNewFrame", 0x2, Null]
    // 0x866950: r0 = scheduleFrameCallback()
    //     0x866950: bl              #0x8669b0  ; [dart:mixin_deduplication] _MixinApplication203&BindingBase&GestureBinding&SchedulerBinding::scheduleFrameCallback
    // 0x866954: mov             x2, x0
    // 0x866958: r0 = BoxInt64Instr(r2)
    //     0x866958: sbfiz           x0, x2, #1, #0x1f
    //     0x86695c: cmp             x2, x0, asr #1
    //     0x866960: b.eq            #0x86696c
    //     0x866964: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x866968: stur            x2, [x0, #7]
    // 0x86696c: ldur            x1, [fp, #-8]
    // 0x866970: StoreField: r1->field_1b = r0
    //     0x866970: stur            w0, [x1, #0x1b]
    //     0x866974: tbz             w0, #0, #0x866990
    //     0x866978: ldurb           w16, [x1, #-1]
    //     0x86697c: ldurb           w17, [x0, #-1]
    //     0x866980: and             x16, x17, x16, lsr #2
    //     0x866984: tst             x16, HEAP, lsr #32
    //     0x866988: b.eq            #0x866990
    //     0x86698c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x866990: r0 = Null
    //     0x866990: mov             x0, NULL
    // 0x866994: LeaveFrame
    //     0x866994: mov             SP, fp
    //     0x866998: ldp             fp, lr, [SP], #0x10
    // 0x86699c: ret
    //     0x86699c: ret             
    // 0x8669a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8669a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8669a4: b               #0x866908
    // 0x8669a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8669a8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8669ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8669ac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _tick(dynamic, Duration) {
    // ** addr: 0x866ac8, size: 0x3c
    // 0x866ac8: EnterFrame
    //     0x866ac8: stp             fp, lr, [SP, #-0x10]!
    //     0x866acc: mov             fp, SP
    // 0x866ad0: ldr             x0, [fp, #0x18]
    // 0x866ad4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x866ad4: ldur            w1, [x0, #0x17]
    // 0x866ad8: DecompressPointer r1
    //     0x866ad8: add             x1, x1, HEAP, lsl #32
    // 0x866adc: CheckStackOverflow
    //     0x866adc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x866ae0: cmp             SP, x16
    //     0x866ae4: b.ls            #0x866afc
    // 0x866ae8: ldr             x2, [fp, #0x10]
    // 0x866aec: r0 = _tick()
    //     0x866aec: bl              #0x866b04  ; [package:flutter/src/scheduler/ticker.dart] Ticker::_tick
    // 0x866af0: LeaveFrame
    //     0x866af0: mov             SP, fp
    //     0x866af4: ldp             fp, lr, [SP], #0x10
    // 0x866af8: ret
    //     0x866af8: ret             
    // 0x866afc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x866afc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x866b00: b               #0x866ae8
  }
  _ _tick(/* No info */) {
    // ** addr: 0x866b04, size: 0xc8
    // 0x866b04: EnterFrame
    //     0x866b04: stp             fp, lr, [SP, #-0x10]!
    //     0x866b08: mov             fp, SP
    // 0x866b0c: AllocStack(0x20)
    //     0x866b0c: sub             SP, SP, #0x20
    // 0x866b10: SetupParameters(Ticker this /* r1 => r2, fp-0x10 */, dynamic _ /* r2 => r1 */)
    //     0x866b10: stur            x1, [fp, #-0x10]
    //     0x866b14: mov             x16, x2
    //     0x866b18: mov             x2, x1
    //     0x866b1c: mov             x1, x16
    // 0x866b20: CheckStackOverflow
    //     0x866b20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x866b24: cmp             SP, x16
    //     0x866b28: b.ls            #0x866bc4
    // 0x866b2c: StoreField: r2->field_1b = rNULL
    //     0x866b2c: stur            NULL, [x2, #0x1b]
    // 0x866b30: LoadField: r0 = r2->field_13
    //     0x866b30: ldur            w0, [x2, #0x13]
    // 0x866b34: DecompressPointer r0
    //     0x866b34: add             x0, x0, HEAP, lsl #32
    // 0x866b38: cmp             w0, NULL
    // 0x866b3c: b.ne            #0x866b64
    // 0x866b40: mov             x0, x1
    // 0x866b44: StoreField: r2->field_13 = r0
    //     0x866b44: stur            w0, [x2, #0x13]
    //     0x866b48: ldurb           w16, [x2, #-1]
    //     0x866b4c: ldurb           w17, [x0, #-1]
    //     0x866b50: and             x16, x17, x16, lsr #2
    //     0x866b54: tst             x16, HEAP, lsr #32
    //     0x866b58: b.eq            #0x866b60
    //     0x866b5c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x866b60: mov             x0, x1
    // 0x866b64: LoadField: r3 = r1->field_7
    //     0x866b64: ldur            x3, [x1, #7]
    // 0x866b68: LoadField: r1 = r0->field_7
    //     0x866b68: ldur            x1, [x0, #7]
    // 0x866b6c: sub             x0, x3, x1
    // 0x866b70: stur            x0, [fp, #-8]
    // 0x866b74: r0 = Duration()
    //     0x866b74: bl              #0x7dd0d0  ; AllocateDurationStub -> Duration (size=0x10)
    // 0x866b78: mov             x1, x0
    // 0x866b7c: ldur            x0, [fp, #-8]
    // 0x866b80: StoreField: r1->field_7 = r0
    //     0x866b80: stur            x0, [x1, #7]
    // 0x866b84: ldur            x2, [fp, #-0x10]
    // 0x866b88: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x866b88: ldur            w0, [x2, #0x17]
    // 0x866b8c: DecompressPointer r0
    //     0x866b8c: add             x0, x0, HEAP, lsl #32
    // 0x866b90: stp             x1, x0, [SP]
    // 0x866b94: ClosureCall
    //     0x866b94: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x866b98: ldur            x2, [x0, #0x1f]
    //     0x866b9c: blr             x2
    // 0x866ba0: ldur            x1, [fp, #-0x10]
    // 0x866ba4: r0 = shouldScheduleTick()
    //     0x866ba4: bl              #0x866bcc  ; [package:flutter/src/scheduler/ticker.dart] Ticker::shouldScheduleTick
    // 0x866ba8: tbnz            w0, #4, #0x866bb4
    // 0x866bac: ldur            x1, [fp, #-0x10]
    // 0x866bb0: r0 = scheduleTick()
    //     0x866bb0: bl              #0x8668e8  ; [package:flutter/src/scheduler/ticker.dart] Ticker::scheduleTick
    // 0x866bb4: r0 = Null
    //     0x866bb4: mov             x0, NULL
    // 0x866bb8: LeaveFrame
    //     0x866bb8: mov             SP, fp
    //     0x866bbc: ldp             fp, lr, [SP], #0x10
    // 0x866bc0: ret
    //     0x866bc0: ret             
    // 0x866bc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x866bc4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x866bc8: b               #0x866b2c
  }
  get _ shouldScheduleTick(/* No info */) {
    // ** addr: 0x866bcc, size: 0x44
    // 0x866bcc: LoadField: r2 = r1->field_f
    //     0x866bcc: ldur            w2, [x1, #0xf]
    // 0x866bd0: DecompressPointer r2
    //     0x866bd0: add             x2, x2, HEAP, lsl #32
    // 0x866bd4: tbz             w2, #4, #0x866c08
    // 0x866bd8: LoadField: r2 = r1->field_7
    //     0x866bd8: ldur            w2, [x1, #7]
    // 0x866bdc: DecompressPointer r2
    //     0x866bdc: add             x2, x2, HEAP, lsl #32
    // 0x866be0: cmp             w2, NULL
    // 0x866be4: b.eq            #0x866c08
    // 0x866be8: LoadField: r2 = r1->field_1b
    //     0x866be8: ldur            w2, [x1, #0x1b]
    // 0x866bec: DecompressPointer r2
    //     0x866bec: add             x2, x2, HEAP, lsl #32
    // 0x866bf0: cmp             w2, NULL
    // 0x866bf4: r16 = true
    //     0x866bf4: add             x16, NULL, #0x20  ; true
    // 0x866bf8: r17 = false
    //     0x866bf8: add             x17, NULL, #0x30  ; false
    // 0x866bfc: csel            x1, x16, x17, eq
    // 0x866c00: mov             x0, x1
    // 0x866c04: b               #0x866c0c
    // 0x866c08: r0 = false
    //     0x866c08: add             x0, NULL, #0x30  ; false
    // 0x866c0c: ret
    //     0x866c0c: ret             
  }
  set _ muted=(/* No info */) {
    // ** addr: 0xaccefc, size: 0x80
    // 0xaccefc: EnterFrame
    //     0xaccefc: stp             fp, lr, [SP, #-0x10]!
    //     0xaccf00: mov             fp, SP
    // 0xaccf04: AllocStack(0x8)
    //     0xaccf04: sub             SP, SP, #8
    // 0xaccf08: SetupParameters(Ticker this /* r1 => r0, fp-0x8 */)
    //     0xaccf08: mov             x0, x1
    //     0xaccf0c: stur            x1, [fp, #-8]
    // 0xaccf10: CheckStackOverflow
    //     0xaccf10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xaccf14: cmp             SP, x16
    //     0xaccf18: b.ls            #0xaccf74
    // 0xaccf1c: LoadField: r1 = r0->field_f
    //     0xaccf1c: ldur            w1, [x0, #0xf]
    // 0xaccf20: DecompressPointer r1
    //     0xaccf20: add             x1, x1, HEAP, lsl #32
    // 0xaccf24: cmp             w2, w1
    // 0xaccf28: b.ne            #0xaccf3c
    // 0xaccf2c: r0 = Null
    //     0xaccf2c: mov             x0, NULL
    // 0xaccf30: LeaveFrame
    //     0xaccf30: mov             SP, fp
    //     0xaccf34: ldp             fp, lr, [SP], #0x10
    // 0xaccf38: ret
    //     0xaccf38: ret             
    // 0xaccf3c: StoreField: r0->field_f = r2
    //     0xaccf3c: stur            w2, [x0, #0xf]
    // 0xaccf40: tbnz            w2, #4, #0xaccf50
    // 0xaccf44: mov             x1, x0
    // 0xaccf48: r0 = unscheduleTick()
    //     0xaccf48: bl              #0x82ed64  ; [package:flutter/src/scheduler/ticker.dart] Ticker::unscheduleTick
    // 0xaccf4c: b               #0xaccf64
    // 0xaccf50: mov             x1, x0
    // 0xaccf54: r0 = shouldScheduleTick()
    //     0xaccf54: bl              #0x866bcc  ; [package:flutter/src/scheduler/ticker.dart] Ticker::shouldScheduleTick
    // 0xaccf58: tbnz            w0, #4, #0xaccf64
    // 0xaccf5c: ldur            x1, [fp, #-8]
    // 0xaccf60: r0 = scheduleTick()
    //     0xaccf60: bl              #0x8668e8  ; [package:flutter/src/scheduler/ticker.dart] Ticker::scheduleTick
    // 0xaccf64: r0 = Null
    //     0xaccf64: mov             x0, NULL
    // 0xaccf68: LeaveFrame
    //     0xaccf68: mov             SP, fp
    //     0xaccf6c: ldp             fp, lr, [SP], #0x10
    // 0xaccf70: ret
    //     0xaccf70: ret             
    // 0xaccf74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaccf74: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaccf78: b               #0xaccf1c
  }
  _ absorbTicker(/* No info */) {
    // ** addr: 0xcf50a8, size: 0x128
    // 0xcf50a8: EnterFrame
    //     0xcf50a8: stp             fp, lr, [SP, #-0x10]!
    //     0xcf50ac: mov             fp, SP
    // 0xcf50b0: AllocStack(0x10)
    //     0xcf50b0: sub             SP, SP, #0x10
    // 0xcf50b4: SetupParameters(Ticker this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xcf50b4: mov             x3, x1
    //     0xcf50b8: stur            x1, [fp, #-8]
    //     0xcf50bc: stur            x2, [fp, #-0x10]
    // 0xcf50c0: CheckStackOverflow
    //     0xcf50c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf50c4: cmp             SP, x16
    //     0xcf50c8: b.ls            #0xcf51c8
    // 0xcf50cc: LoadField: r0 = r2->field_7
    //     0xcf50cc: ldur            w0, [x2, #7]
    // 0xcf50d0: DecompressPointer r0
    //     0xcf50d0: add             x0, x0, HEAP, lsl #32
    // 0xcf50d4: cmp             w0, NULL
    // 0xcf50d8: b.eq            #0xcf5140
    // 0xcf50dc: StoreField: r3->field_7 = r0
    //     0xcf50dc: stur            w0, [x3, #7]
    //     0xcf50e0: ldurb           w16, [x3, #-1]
    //     0xcf50e4: ldurb           w17, [x0, #-1]
    //     0xcf50e8: and             x16, x17, x16, lsr #2
    //     0xcf50ec: tst             x16, HEAP, lsr #32
    //     0xcf50f0: b.eq            #0xcf50f8
    //     0xcf50f4: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xcf50f8: LoadField: r0 = r2->field_13
    //     0xcf50f8: ldur            w0, [x2, #0x13]
    // 0xcf50fc: DecompressPointer r0
    //     0xcf50fc: add             x0, x0, HEAP, lsl #32
    // 0xcf5100: StoreField: r3->field_13 = r0
    //     0xcf5100: stur            w0, [x3, #0x13]
    //     0xcf5104: ldurb           w16, [x3, #-1]
    //     0xcf5108: ldurb           w17, [x0, #-1]
    //     0xcf510c: and             x16, x17, x16, lsr #2
    //     0xcf5110: tst             x16, HEAP, lsr #32
    //     0xcf5114: b.eq            #0xcf511c
    //     0xcf5118: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xcf511c: mov             x1, x3
    // 0xcf5120: r0 = shouldScheduleTick()
    //     0xcf5120: bl              #0x866bcc  ; [package:flutter/src/scheduler/ticker.dart] Ticker::shouldScheduleTick
    // 0xcf5124: tbnz            w0, #4, #0xcf5130
    // 0xcf5128: ldur            x1, [fp, #-8]
    // 0xcf512c: r0 = scheduleTick()
    //     0xcf512c: bl              #0x8668e8  ; [package:flutter/src/scheduler/ticker.dart] Ticker::scheduleTick
    // 0xcf5130: ldur            x0, [fp, #-0x10]
    // 0xcf5134: StoreField: r0->field_7 = rNULL
    //     0xcf5134: stur            NULL, [x0, #7]
    // 0xcf5138: mov             x1, x0
    // 0xcf513c: r0 = unscheduleTick()
    //     0xcf513c: bl              #0x82ed64  ; [package:flutter/src/scheduler/ticker.dart] Ticker::unscheduleTick
    // 0xcf5140: ldur            x0, [fp, #-0x10]
    // 0xcf5144: r1 = LoadClassIdInstr(r0)
    //     0xcf5144: ldur            x1, [x0, #-1]
    //     0xcf5148: ubfx            x1, x1, #0xc, #0x14
    // 0xcf514c: cmp             x1, #0xb0f
    // 0xcf5150: b.ne            #0xcf5184
    // 0xcf5154: LoadField: r2 = r0->field_7
    //     0xcf5154: ldur            w2, [x0, #7]
    // 0xcf5158: DecompressPointer r2
    //     0xcf5158: add             x2, x2, HEAP, lsl #32
    // 0xcf515c: stur            x2, [fp, #-8]
    // 0xcf5160: cmp             w2, NULL
    // 0xcf5164: b.eq            #0xcf51b8
    // 0xcf5168: StoreField: r0->field_7 = rNULL
    //     0xcf5168: stur            NULL, [x0, #7]
    // 0xcf516c: mov             x1, x0
    // 0xcf5170: r0 = unscheduleTick()
    //     0xcf5170: bl              #0x82ed64  ; [package:flutter/src/scheduler/ticker.dart] Ticker::unscheduleTick
    // 0xcf5174: ldur            x1, [fp, #-8]
    // 0xcf5178: ldur            x2, [fp, #-0x10]
    // 0xcf517c: r0 = _cancel()
    //     0xcf517c: bl              #0x82ece8  ; [package:flutter/src/scheduler/ticker.dart] TickerFuture::_cancel
    // 0xcf5180: b               #0xcf51b8
    // 0xcf5184: mov             x3, x0
    // 0xcf5188: LoadField: r1 = r3->field_1f
    //     0xcf5188: ldur            w1, [x3, #0x1f]
    // 0xcf518c: DecompressPointer r1
    //     0xcf518c: add             x1, x1, HEAP, lsl #32
    // 0xcf5190: r0 = LoadClassIdInstr(r1)
    //     0xcf5190: ldur            x0, [x1, #-1]
    //     0xcf5194: ubfx            x0, x0, #0xc, #0x14
    // 0xcf5198: mov             x2, x3
    // 0xcf519c: r0 = GDT[cid_x0 + 0x15885]()
    //     0xcf519c: mov             x17, #0x5885
    //     0xcf51a0: movk            x17, #1, lsl #16
    //     0xcf51a4: add             lr, x0, x17
    //     0xcf51a8: ldr             lr, [x21, lr, lsl #3]
    //     0xcf51ac: blr             lr
    // 0xcf51b0: ldur            x1, [fp, #-0x10]
    // 0xcf51b4: r0 = dispose()
    //     0xcf51b4: bl              #0x13084f4  ; [package:flutter/src/scheduler/ticker.dart] Ticker::dispose
    // 0xcf51b8: r0 = Null
    //     0xcf51b8: mov             x0, NULL
    // 0xcf51bc: LeaveFrame
    //     0xcf51bc: mov             SP, fp
    //     0xcf51c0: ldp             fp, lr, [SP], #0x10
    // 0xcf51c4: ret
    //     0xcf51c4: ret             
    // 0xcf51c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf51c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf51cc: b               #0xcf50cc
  }
  get _ isTicking(/* No info */) {
    // ** addr: 0xd6e330, size: 0x90
    // 0xd6e330: LoadField: r2 = r1->field_7
    //     0xd6e330: ldur            w2, [x1, #7]
    // 0xd6e334: DecompressPointer r2
    //     0xd6e334: add             x2, x2, HEAP, lsl #32
    // 0xd6e338: cmp             w2, NULL
    // 0xd6e33c: b.ne            #0xd6e348
    // 0xd6e340: r0 = false
    //     0xd6e340: add             x0, NULL, #0x30  ; false
    // 0xd6e344: ret
    //     0xd6e344: ret             
    // 0xd6e348: LoadField: r2 = r1->field_f
    //     0xd6e348: ldur            w2, [x1, #0xf]
    // 0xd6e34c: DecompressPointer r2
    //     0xd6e34c: add             x2, x2, HEAP, lsl #32
    // 0xd6e350: tbnz            w2, #4, #0xd6e35c
    // 0xd6e354: r0 = false
    //     0xd6e354: add             x0, NULL, #0x30  ; false
    // 0xd6e358: ret
    //     0xd6e358: ret             
    // 0xd6e35c: r1 = LoadStaticField(0x5e4)
    //     0xd6e35c: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0xd6e360: ldr             x1, [x1, #0xbc8]
    // 0xd6e364: cmp             w1, NULL
    // 0xd6e368: b.eq            #0xd6e3b4
    // 0xd6e36c: LoadField: r2 = r1->field_63
    //     0xd6e36c: ldur            w2, [x1, #0x63]
    // 0xd6e370: DecompressPointer r2
    //     0xd6e370: add             x2, x2, HEAP, lsl #32
    // 0xd6e374: tbnz            w2, #4, #0xd6e390
    // 0xd6e378: r17 = 263
    //     0xd6e378: mov             x17, #0x107
    // 0xd6e37c: ldr             w2, [x1, x17]
    // 0xd6e380: DecompressPointer r2
    //     0xd6e380: add             x2, x2, HEAP, lsl #32
    // 0xd6e384: tbnz            w2, #4, #0xd6e390
    // 0xd6e388: r0 = true
    //     0xd6e388: add             x0, NULL, #0x20  ; true
    // 0xd6e38c: ret
    //     0xd6e38c: ret             
    // 0xd6e390: LoadField: r2 = r1->field_5f
    //     0xd6e390: ldur            w2, [x1, #0x5f]
    // 0xd6e394: DecompressPointer r2
    //     0xd6e394: add             x2, x2, HEAP, lsl #32
    // 0xd6e398: r16 = Instance_SchedulerPhase
    //     0xd6e398: ldr             x16, [PP, #0x1800]  ; [pp+0x1800] Obj!SchedulerPhase@12c3fa1
    // 0xd6e39c: cmp             w2, w16
    // 0xd6e3a0: b.eq            #0xd6e3ac
    // 0xd6e3a4: r0 = true
    //     0xd6e3a4: add             x0, NULL, #0x20  ; true
    // 0xd6e3a8: ret
    //     0xd6e3a8: ret             
    // 0xd6e3ac: r0 = false
    //     0xd6e3ac: add             x0, NULL, #0x30  ; false
    // 0xd6e3b0: ret
    //     0xd6e3b0: ret             
    // 0xd6e3b4: EnterFrame
    //     0xd6e3b4: stp             fp, lr, [SP, #-0x10]!
    //     0xd6e3b8: mov             fp, SP
    // 0xd6e3bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd6e3bc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ toString(/* No info */) {
    // ** addr: 0x1115bbc, size: 0x44
    // 0x1115bbc: EnterFrame
    //     0x1115bbc: stp             fp, lr, [SP, #-0x10]!
    //     0x1115bc0: mov             fp, SP
    // 0x1115bc4: AllocStack(0x8)
    //     0x1115bc4: sub             SP, SP, #8
    // 0x1115bc8: SetupParameters(Ticker this /* r0 */)
    //     0x1115bc8: ldur            w0, [x4, #0x13]
    //     0x1115bcc: sub             x1, x0, #2
    //     0x1115bd0: add             x0, fp, w1, sxtw #2
    //     0x1115bd4: ldr             x0, [x0, #0x10]
    // 0x1115bd8: CheckStackOverflow
    //     0x1115bd8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1115bdc: cmp             SP, x16
    //     0x1115be0: b.ls            #0x1115bf8
    // 0x1115be4: str             x0, [SP]
    // 0x1115be8: r0 = toString()
    //     0x1115be8: bl              #0x112b118  ; [dart:core] Object::toString
    // 0x1115bec: LeaveFrame
    //     0x1115bec: mov             SP, fp
    //     0x1115bf0: ldp             fp, lr, [SP], #0x10
    // 0x1115bf4: ret
    //     0x1115bf4: ret             
    // 0x1115bf8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1115bf8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1115bfc: b               #0x1115be4
  }
  _ dispose(/* No info */) {
    // ** addr: 0x13084f4, size: 0x64
    // 0x13084f4: EnterFrame
    //     0x13084f4: stp             fp, lr, [SP, #-0x10]!
    //     0x13084f8: mov             fp, SP
    // 0x13084fc: AllocStack(0x10)
    //     0x13084fc: sub             SP, SP, #0x10
    // 0x1308500: SetupParameters(Ticker this /* r1 => r0, fp-0x10 */)
    //     0x1308500: mov             x0, x1
    //     0x1308504: stur            x1, [fp, #-0x10]
    // 0x1308508: CheckStackOverflow
    //     0x1308508: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x130850c: cmp             SP, x16
    //     0x1308510: b.ls            #0x1308550
    // 0x1308514: LoadField: r2 = r0->field_7
    //     0x1308514: ldur            w2, [x0, #7]
    // 0x1308518: DecompressPointer r2
    //     0x1308518: add             x2, x2, HEAP, lsl #32
    // 0x130851c: stur            x2, [fp, #-8]
    // 0x1308520: cmp             w2, NULL
    // 0x1308524: b.eq            #0x1308540
    // 0x1308528: StoreField: r0->field_7 = rNULL
    //     0x1308528: stur            NULL, [x0, #7]
    // 0x130852c: mov             x1, x0
    // 0x1308530: r0 = unscheduleTick()
    //     0x1308530: bl              #0x82ed64  ; [package:flutter/src/scheduler/ticker.dart] Ticker::unscheduleTick
    // 0x1308534: ldur            x1, [fp, #-8]
    // 0x1308538: ldur            x2, [fp, #-0x10]
    // 0x130853c: r0 = _cancel()
    //     0x130853c: bl              #0x82ece8  ; [package:flutter/src/scheduler/ticker.dart] TickerFuture::_cancel
    // 0x1308540: r0 = Null
    //     0x1308540: mov             x0, NULL
    // 0x1308544: LeaveFrame
    //     0x1308544: mov             SP, fp
    //     0x1308548: ldp             fp, lr, [SP], #0x10
    // 0x130854c: ret
    //     0x130854c: ret             
    // 0x1308550: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1308550: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1308554: b               #0x1308514
  }
}

// class id: 2833, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class TickerProvider extends Object {
}
