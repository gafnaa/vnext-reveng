// lib: , url: package:flutter/src/services/text_editing_delta.dart

// class id: 1049102, size: 0x8
class :: {

  static _ _replace(/* No info */) {
    // ** addr: 0x877020, size: 0x5c
    // 0x877020: EnterFrame
    //     0x877020: stp             fp, lr, [SP, #-0x10]!
    //     0x877024: mov             fp, SP
    // 0x877028: mov             x5, x2
    // 0x87702c: mov             x2, x1
    // 0x877030: CheckStackOverflow
    //     0x877030: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x877034: cmp             SP, x16
    //     0x877038: b.ls            #0x877074
    // 0x87703c: LoadField: r4 = r3->field_7
    //     0x87703c: ldur            x4, [x3, #7]
    // 0x877040: LoadField: r6 = r3->field_f
    //     0x877040: ldur            x6, [x3, #0xf]
    // 0x877044: r0 = BoxInt64Instr(r6)
    //     0x877044: sbfiz           x0, x6, #1, #0x1f
    //     0x877048: cmp             x6, x0, asr #1
    //     0x87704c: b.eq            #0x877058
    //     0x877050: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x877054: stur            x6, [x0, #7]
    // 0x877058: mov             x1, x2
    // 0x87705c: mov             x2, x4
    // 0x877060: mov             x3, x0
    // 0x877064: r0 = replaceRange()
    //     0x877064: bl              #0x7ec3e4  ; [dart:core] _StringBase::replaceRange
    // 0x877068: LeaveFrame
    //     0x877068: mov             SP, fp
    //     0x87706c: ldp             fp, lr, [SP], #0x10
    // 0x877070: ret
    //     0x877070: ret             
    // 0x877074: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x877074: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x877078: b               #0x87703c
  }
}

// class id: 5009, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class TextEditingDelta extends _MixinApplication3&Object&Diagnosticable {

  factory _ TextEditingDelta.fromJSON(/* No info */) {
    // ** addr: 0x87682c, size: 0x7a8
    // 0x87682c: EnterFrame
    //     0x87682c: stp             fp, lr, [SP, #-0x10]!
    //     0x876830: mov             fp, SP
    // 0x876834: AllocStack(0x88)
    //     0x876834: sub             SP, SP, #0x88
    // 0x876838: SetupParameters(dynamic _ /* r2 => r3, fp-0x8 */)
    //     0x876838: mov             x3, x2
    //     0x87683c: stur            x2, [fp, #-8]
    // 0x876840: CheckStackOverflow
    //     0x876840: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x876844: cmp             SP, x16
    //     0x876848: b.ls            #0x876fcc
    // 0x87684c: r0 = LoadClassIdInstr(r3)
    //     0x87684c: ldur            x0, [x3, #-1]
    //     0x876850: ubfx            x0, x0, #0xc, #0x14
    // 0x876854: mov             x1, x3
    // 0x876858: r2 = "oldText"
    //     0x876858: ldr             x2, [PP, #0x5ee0]  ; [pp+0x5ee0] "oldText"
    // 0x87685c: r0 = GDT[cid_x0 + -0xd48]()
    //     0x87685c: sub             lr, x0, #0xd48
    //     0x876860: ldr             lr, [x21, lr, lsl #3]
    //     0x876864: blr             lr
    // 0x876868: mov             x3, x0
    // 0x87686c: r2 = Null
    //     0x87686c: mov             x2, NULL
    // 0x876870: r1 = Null
    //     0x876870: mov             x1, NULL
    // 0x876874: stur            x3, [fp, #-0x10]
    // 0x876878: r4 = 60
    //     0x876878: mov             x4, #0x3c
    // 0x87687c: branchIfSmi(r0, 0x876888)
    //     0x87687c: tbz             w0, #0, #0x876888
    // 0x876880: r4 = LoadClassIdInstr(r0)
    //     0x876880: ldur            x4, [x0, #-1]
    //     0x876884: ubfx            x4, x4, #0xc, #0x14
    // 0x876888: sub             x4, x4, #0x5e
    // 0x87688c: cmp             x4, #1
    // 0x876890: b.ls            #0x8768a0
    // 0x876894: r8 = String
    //     0x876894: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x876898: r3 = Null
    //     0x876898: ldr             x3, [PP, #0x5ee8]  ; [pp+0x5ee8] Null
    // 0x87689c: r0 = String()
    //     0x87689c: bl              #0x13ee320  ; IsType_String_Stub
    // 0x8768a0: ldur            x3, [fp, #-8]
    // 0x8768a4: r0 = LoadClassIdInstr(r3)
    //     0x8768a4: ldur            x0, [x3, #-1]
    //     0x8768a8: ubfx            x0, x0, #0xc, #0x14
    // 0x8768ac: mov             x1, x3
    // 0x8768b0: r2 = "deltaStart"
    //     0x8768b0: ldr             x2, [PP, #0x5ef8]  ; [pp+0x5ef8] "deltaStart"
    // 0x8768b4: r0 = GDT[cid_x0 + -0xd48]()
    //     0x8768b4: sub             lr, x0, #0xd48
    //     0x8768b8: ldr             lr, [x21, lr, lsl #3]
    //     0x8768bc: blr             lr
    // 0x8768c0: mov             x3, x0
    // 0x8768c4: r2 = Null
    //     0x8768c4: mov             x2, NULL
    // 0x8768c8: r1 = Null
    //     0x8768c8: mov             x1, NULL
    // 0x8768cc: stur            x3, [fp, #-0x18]
    // 0x8768d0: branchIfSmi(r0, 0x8768f4)
    //     0x8768d0: tbz             w0, #0, #0x8768f4
    // 0x8768d4: r4 = LoadClassIdInstr(r0)
    //     0x8768d4: ldur            x4, [x0, #-1]
    //     0x8768d8: ubfx            x4, x4, #0xc, #0x14
    // 0x8768dc: sub             x4, x4, #0x3c
    // 0x8768e0: cmp             x4, #1
    // 0x8768e4: b.ls            #0x8768f4
    // 0x8768e8: r8 = int
    //     0x8768e8: ldr             x8, [PP, #0x390]  ; [pp+0x390] Type: int
    // 0x8768ec: r3 = Null
    //     0x8768ec: ldr             x3, [PP, #0x5f00]  ; [pp+0x5f00] Null
    // 0x8768f0: r0 = int()
    //     0x8768f0: bl              #0x13ee980  ; IsType_int_Stub
    // 0x8768f4: ldur            x3, [fp, #-8]
    // 0x8768f8: r0 = LoadClassIdInstr(r3)
    //     0x8768f8: ldur            x0, [x3, #-1]
    //     0x8768fc: ubfx            x0, x0, #0xc, #0x14
    // 0x876900: mov             x1, x3
    // 0x876904: r2 = "deltaEnd"
    //     0x876904: ldr             x2, [PP, #0x5f10]  ; [pp+0x5f10] "deltaEnd"
    // 0x876908: r0 = GDT[cid_x0 + -0xd48]()
    //     0x876908: sub             lr, x0, #0xd48
    //     0x87690c: ldr             lr, [x21, lr, lsl #3]
    //     0x876910: blr             lr
    // 0x876914: mov             x3, x0
    // 0x876918: r2 = Null
    //     0x876918: mov             x2, NULL
    // 0x87691c: r1 = Null
    //     0x87691c: mov             x1, NULL
    // 0x876920: stur            x3, [fp, #-0x20]
    // 0x876924: branchIfSmi(r0, 0x876948)
    //     0x876924: tbz             w0, #0, #0x876948
    // 0x876928: r4 = LoadClassIdInstr(r0)
    //     0x876928: ldur            x4, [x0, #-1]
    //     0x87692c: ubfx            x4, x4, #0xc, #0x14
    // 0x876930: sub             x4, x4, #0x3c
    // 0x876934: cmp             x4, #1
    // 0x876938: b.ls            #0x876948
    // 0x87693c: r8 = int
    //     0x87693c: ldr             x8, [PP, #0x390]  ; [pp+0x390] Type: int
    // 0x876940: r3 = Null
    //     0x876940: ldr             x3, [PP, #0x5f18]  ; [pp+0x5f18] Null
    // 0x876944: r0 = int()
    //     0x876944: bl              #0x13ee980  ; IsType_int_Stub
    // 0x876948: ldur            x3, [fp, #-8]
    // 0x87694c: r0 = LoadClassIdInstr(r3)
    //     0x87694c: ldur            x0, [x3, #-1]
    //     0x876950: ubfx            x0, x0, #0xc, #0x14
    // 0x876954: mov             x1, x3
    // 0x876958: r2 = "deltaText"
    //     0x876958: ldr             x2, [PP, #0x5f28]  ; [pp+0x5f28] "deltaText"
    // 0x87695c: r0 = GDT[cid_x0 + -0xd48]()
    //     0x87695c: sub             lr, x0, #0xd48
    //     0x876960: ldr             lr, [x21, lr, lsl #3]
    //     0x876964: blr             lr
    // 0x876968: mov             x3, x0
    // 0x87696c: r2 = Null
    //     0x87696c: mov             x2, NULL
    // 0x876970: r1 = Null
    //     0x876970: mov             x1, NULL
    // 0x876974: stur            x3, [fp, #-0x28]
    // 0x876978: r4 = 60
    //     0x876978: mov             x4, #0x3c
    // 0x87697c: branchIfSmi(r0, 0x876988)
    //     0x87697c: tbz             w0, #0, #0x876988
    // 0x876980: r4 = LoadClassIdInstr(r0)
    //     0x876980: ldur            x4, [x0, #-1]
    //     0x876984: ubfx            x4, x4, #0xc, #0x14
    // 0x876988: sub             x4, x4, #0x5e
    // 0x87698c: cmp             x4, #1
    // 0x876990: b.ls            #0x8769a0
    // 0x876994: r8 = String
    //     0x876994: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x876998: r3 = Null
    //     0x876998: ldr             x3, [PP, #0x5f30]  ; [pp+0x5f30] Null
    // 0x87699c: r0 = String()
    //     0x87699c: bl              #0x13ee320  ; IsType_String_Stub
    // 0x8769a0: ldur            x3, [fp, #-0x28]
    // 0x8769a4: LoadField: r4 = r3->field_7
    //     0x8769a4: ldur            w4, [x3, #7]
    // 0x8769a8: ldur            x0, [fp, #-0x18]
    // 0x8769ac: stur            x4, [fp, #-0x38]
    // 0x8769b0: r5 = LoadInt32Instr(r0)
    //     0x8769b0: sbfx            x5, x0, #1, #0x1f
    //     0x8769b4: tbz             w0, #0, #0x8769bc
    //     0x8769b8: ldur            x5, [x0, #7]
    // 0x8769bc: stur            x5, [fp, #-0x30]
    // 0x8769c0: cmn             x5, #1
    // 0x8769c4: b.ne            #0x8769f0
    // 0x8769c8: ldur            x6, [fp, #-0x20]
    // 0x8769cc: r0 = LoadInt32Instr(r6)
    //     0x8769cc: sbfx            x0, x6, #1, #0x1f
    //     0x8769d0: tbz             w6, #0, #0x8769d8
    //     0x8769d4: ldur            x0, [x6, #7]
    // 0x8769d8: cmp             x5, x0
    // 0x8769dc: r16 = true
    //     0x8769dc: add             x16, NULL, #0x20  ; true
    // 0x8769e0: r17 = false
    //     0x8769e0: add             x17, NULL, #0x30  ; false
    // 0x8769e4: csel            x1, x16, x17, eq
    // 0x8769e8: mov             x8, x1
    // 0x8769ec: b               #0x8769f8
    // 0x8769f0: ldur            x6, [fp, #-0x20]
    // 0x8769f4: r8 = false
    //     0x8769f4: add             x8, NULL, #0x30  ; false
    // 0x8769f8: ldur            x7, [fp, #-8]
    // 0x8769fc: stur            x8, [fp, #-0x18]
    // 0x876a00: r0 = LoadClassIdInstr(r7)
    //     0x876a00: ldur            x0, [x7, #-1]
    //     0x876a04: ubfx            x0, x0, #0xc, #0x14
    // 0x876a08: mov             x1, x7
    // 0x876a0c: r2 = "composingBase"
    //     0x876a0c: ldr             x2, [PP, #0x5f40]  ; [pp+0x5f40] "composingBase"
    // 0x876a10: r0 = GDT[cid_x0 + -0xd48]()
    //     0x876a10: sub             lr, x0, #0xd48
    //     0x876a14: ldr             lr, [x21, lr, lsl #3]
    //     0x876a18: blr             lr
    // 0x876a1c: mov             x3, x0
    // 0x876a20: r2 = Null
    //     0x876a20: mov             x2, NULL
    // 0x876a24: r1 = Null
    //     0x876a24: mov             x1, NULL
    // 0x876a28: stur            x3, [fp, #-0x40]
    // 0x876a2c: branchIfSmi(r0, 0x876a50)
    //     0x876a2c: tbz             w0, #0, #0x876a50
    // 0x876a30: r4 = LoadClassIdInstr(r0)
    //     0x876a30: ldur            x4, [x0, #-1]
    //     0x876a34: ubfx            x4, x4, #0xc, #0x14
    // 0x876a38: sub             x4, x4, #0x3c
    // 0x876a3c: cmp             x4, #1
    // 0x876a40: b.ls            #0x876a50
    // 0x876a44: r8 = int?
    //     0x876a44: ldr             x8, [PP, #0x3d30]  ; [pp+0x3d30] Type: int?
    // 0x876a48: r3 = Null
    //     0x876a48: ldr             x3, [PP, #0x5f48]  ; [pp+0x5f48] Null
    // 0x876a4c: r0 = int?()
    //     0x876a4c: bl              #0x13ee944  ; IsType_int?_Stub
    // 0x876a50: ldur            x0, [fp, #-0x40]
    // 0x876a54: cmp             w0, NULL
    // 0x876a58: b.eq            #0x876a5c
    // 0x876a5c: ldur            x3, [fp, #-8]
    // 0x876a60: r0 = LoadClassIdInstr(r3)
    //     0x876a60: ldur            x0, [x3, #-1]
    //     0x876a64: ubfx            x0, x0, #0xc, #0x14
    // 0x876a68: mov             x1, x3
    // 0x876a6c: r2 = "composingExtent"
    //     0x876a6c: ldr             x2, [PP, #0x5f58]  ; [pp+0x5f58] "composingExtent"
    // 0x876a70: r0 = GDT[cid_x0 + -0xd48]()
    //     0x876a70: sub             lr, x0, #0xd48
    //     0x876a74: ldr             lr, [x21, lr, lsl #3]
    //     0x876a78: blr             lr
    // 0x876a7c: mov             x3, x0
    // 0x876a80: r2 = Null
    //     0x876a80: mov             x2, NULL
    // 0x876a84: r1 = Null
    //     0x876a84: mov             x1, NULL
    // 0x876a88: stur            x3, [fp, #-0x40]
    // 0x876a8c: branchIfSmi(r0, 0x876ab0)
    //     0x876a8c: tbz             w0, #0, #0x876ab0
    // 0x876a90: r4 = LoadClassIdInstr(r0)
    //     0x876a90: ldur            x4, [x0, #-1]
    //     0x876a94: ubfx            x4, x4, #0xc, #0x14
    // 0x876a98: sub             x4, x4, #0x3c
    // 0x876a9c: cmp             x4, #1
    // 0x876aa0: b.ls            #0x876ab0
    // 0x876aa4: r8 = int?
    //     0x876aa4: ldr             x8, [PP, #0x3d30]  ; [pp+0x3d30] Type: int?
    // 0x876aa8: r3 = Null
    //     0x876aa8: ldr             x3, [PP, #0x5f60]  ; [pp+0x5f60] Null
    // 0x876aac: r0 = int?()
    //     0x876aac: bl              #0x13ee944  ; IsType_int?_Stub
    // 0x876ab0: ldur            x0, [fp, #-0x40]
    // 0x876ab4: cmp             w0, NULL
    // 0x876ab8: b.eq            #0x876abc
    // 0x876abc: ldur            x3, [fp, #-8]
    // 0x876ac0: r0 = LoadClassIdInstr(r3)
    //     0x876ac0: ldur            x0, [x3, #-1]
    //     0x876ac4: ubfx            x0, x0, #0xc, #0x14
    // 0x876ac8: mov             x1, x3
    // 0x876acc: r2 = "selectionBase"
    //     0x876acc: ldr             x2, [PP, #0x5f70]  ; [pp+0x5f70] "selectionBase"
    // 0x876ad0: r0 = GDT[cid_x0 + -0xd48]()
    //     0x876ad0: sub             lr, x0, #0xd48
    //     0x876ad4: ldr             lr, [x21, lr, lsl #3]
    //     0x876ad8: blr             lr
    // 0x876adc: mov             x3, x0
    // 0x876ae0: r2 = Null
    //     0x876ae0: mov             x2, NULL
    // 0x876ae4: r1 = Null
    //     0x876ae4: mov             x1, NULL
    // 0x876ae8: stur            x3, [fp, #-0x40]
    // 0x876aec: branchIfSmi(r0, 0x876b10)
    //     0x876aec: tbz             w0, #0, #0x876b10
    // 0x876af0: r4 = LoadClassIdInstr(r0)
    //     0x876af0: ldur            x4, [x0, #-1]
    //     0x876af4: ubfx            x4, x4, #0xc, #0x14
    // 0x876af8: sub             x4, x4, #0x3c
    // 0x876afc: cmp             x4, #1
    // 0x876b00: b.ls            #0x876b10
    // 0x876b04: r8 = int?
    //     0x876b04: ldr             x8, [PP, #0x3d30]  ; [pp+0x3d30] Type: int?
    // 0x876b08: r3 = Null
    //     0x876b08: ldr             x3, [PP, #0x5f78]  ; [pp+0x5f78] Null
    // 0x876b0c: r0 = int?()
    //     0x876b0c: bl              #0x13ee944  ; IsType_int?_Stub
    // 0x876b10: ldur            x0, [fp, #-0x40]
    // 0x876b14: cmp             w0, NULL
    // 0x876b18: b.ne            #0x876b24
    // 0x876b1c: r4 = -1
    //     0x876b1c: mov             x4, #-1
    // 0x876b20: b               #0x876b34
    // 0x876b24: r1 = LoadInt32Instr(r0)
    //     0x876b24: sbfx            x1, x0, #1, #0x1f
    //     0x876b28: tbz             w0, #0, #0x876b30
    //     0x876b2c: ldur            x1, [x0, #7]
    // 0x876b30: mov             x4, x1
    // 0x876b34: ldur            x3, [fp, #-8]
    // 0x876b38: stur            x4, [fp, #-0x48]
    // 0x876b3c: r0 = LoadClassIdInstr(r3)
    //     0x876b3c: ldur            x0, [x3, #-1]
    //     0x876b40: ubfx            x0, x0, #0xc, #0x14
    // 0x876b44: mov             x1, x3
    // 0x876b48: r2 = "selectionExtent"
    //     0x876b48: ldr             x2, [PP, #0x5f88]  ; [pp+0x5f88] "selectionExtent"
    // 0x876b4c: r0 = GDT[cid_x0 + -0xd48]()
    //     0x876b4c: sub             lr, x0, #0xd48
    //     0x876b50: ldr             lr, [x21, lr, lsl #3]
    //     0x876b54: blr             lr
    // 0x876b58: mov             x3, x0
    // 0x876b5c: r2 = Null
    //     0x876b5c: mov             x2, NULL
    // 0x876b60: r1 = Null
    //     0x876b60: mov             x1, NULL
    // 0x876b64: stur            x3, [fp, #-0x40]
    // 0x876b68: branchIfSmi(r0, 0x876b8c)
    //     0x876b68: tbz             w0, #0, #0x876b8c
    // 0x876b6c: r4 = LoadClassIdInstr(r0)
    //     0x876b6c: ldur            x4, [x0, #-1]
    //     0x876b70: ubfx            x4, x4, #0xc, #0x14
    // 0x876b74: sub             x4, x4, #0x3c
    // 0x876b78: cmp             x4, #1
    // 0x876b7c: b.ls            #0x876b8c
    // 0x876b80: r8 = int?
    //     0x876b80: ldr             x8, [PP, #0x3d30]  ; [pp+0x3d30] Type: int?
    // 0x876b84: r3 = Null
    //     0x876b84: ldr             x3, [PP, #0x5f90]  ; [pp+0x5f90] Null
    // 0x876b88: r0 = int?()
    //     0x876b88: bl              #0x13ee944  ; IsType_int?_Stub
    // 0x876b8c: ldur            x0, [fp, #-0x40]
    // 0x876b90: cmp             w0, NULL
    // 0x876b94: b.ne            #0x876ba0
    // 0x876b98: r4 = -1
    //     0x876b98: mov             x4, #-1
    // 0x876b9c: b               #0x876bb0
    // 0x876ba0: r1 = LoadInt32Instr(r0)
    //     0x876ba0: sbfx            x1, x0, #1, #0x1f
    //     0x876ba4: tbz             w0, #0, #0x876bac
    //     0x876ba8: ldur            x1, [x0, #7]
    // 0x876bac: mov             x4, x1
    // 0x876bb0: ldur            x3, [fp, #-8]
    // 0x876bb4: stur            x4, [fp, #-0x50]
    // 0x876bb8: r0 = LoadClassIdInstr(r3)
    //     0x876bb8: ldur            x0, [x3, #-1]
    //     0x876bbc: ubfx            x0, x0, #0xc, #0x14
    // 0x876bc0: mov             x1, x3
    // 0x876bc4: r2 = "selectionAffinity"
    //     0x876bc4: ldr             x2, [PP, #0x5fa0]  ; [pp+0x5fa0] "selectionAffinity"
    // 0x876bc8: r0 = GDT[cid_x0 + -0xd48]()
    //     0x876bc8: sub             lr, x0, #0xd48
    //     0x876bcc: ldr             lr, [x21, lr, lsl #3]
    //     0x876bd0: blr             lr
    // 0x876bd4: mov             x3, x0
    // 0x876bd8: r2 = Null
    //     0x876bd8: mov             x2, NULL
    // 0x876bdc: r1 = Null
    //     0x876bdc: mov             x1, NULL
    // 0x876be0: stur            x3, [fp, #-0x40]
    // 0x876be4: r4 = 60
    //     0x876be4: mov             x4, #0x3c
    // 0x876be8: branchIfSmi(r0, 0x876bf4)
    //     0x876be8: tbz             w0, #0, #0x876bf4
    // 0x876bec: r4 = LoadClassIdInstr(r0)
    //     0x876bec: ldur            x4, [x0, #-1]
    //     0x876bf0: ubfx            x4, x4, #0xc, #0x14
    // 0x876bf4: sub             x4, x4, #0x5e
    // 0x876bf8: cmp             x4, #1
    // 0x876bfc: b.ls            #0x876c0c
    // 0x876c00: r8 = String?
    //     0x876c00: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x876c04: r3 = Null
    //     0x876c04: ldr             x3, [PP, #0x5fa8]  ; [pp+0x5fa8] Null
    // 0x876c08: r0 = String?()
    //     0x876c08: bl              #0x7db310  ; IsType_String?_Stub
    // 0x876c0c: r16 = "TextAffinity.downstream"
    //     0x876c0c: ldr             x16, [PP, #0x5fb8]  ; [pp+0x5fb8] "TextAffinity.downstream"
    // 0x876c10: ldur            lr, [fp, #-0x40]
    // 0x876c14: stp             lr, x16, [SP]
    // 0x876c18: r0 = ==()
    //     0x876c18: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x876c1c: tbnz            w0, #4, #0x876c28
    // 0x876c20: r0 = Instance_TextAffinity
    //     0x876c20: ldr             x0, [PP, #0x4bb0]  ; [pp+0x4bb0] Obj!TextAffinity@12c7361
    // 0x876c24: b               #0x876c48
    // 0x876c28: r16 = "TextAffinity.upstream"
    //     0x876c28: ldr             x16, [PP, #0x5fc0]  ; [pp+0x5fc0] "TextAffinity.upstream"
    // 0x876c2c: ldur            lr, [fp, #-0x40]
    // 0x876c30: stp             lr, x16, [SP]
    // 0x876c34: r0 = ==()
    //     0x876c34: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x876c38: tbnz            w0, #4, #0x876c44
    // 0x876c3c: r0 = Instance_TextAffinity
    //     0x876c3c: ldr             x0, [PP, #0x4bb8]  ; [pp+0x4bb8] Obj!TextAffinity@12c7341
    // 0x876c40: b               #0x876c48
    // 0x876c44: r0 = Null
    //     0x876c44: mov             x0, NULL
    // 0x876c48: cmp             w0, NULL
    // 0x876c4c: b.eq            #0x876c50
    // 0x876c50: ldur            x1, [fp, #-8]
    // 0x876c54: r0 = LoadClassIdInstr(r1)
    //     0x876c54: ldur            x0, [x1, #-1]
    //     0x876c58: ubfx            x0, x0, #0xc, #0x14
    // 0x876c5c: r2 = "selectionIsDirectional"
    //     0x876c5c: ldr             x2, [PP, #0x5fc8]  ; [pp+0x5fc8] "selectionIsDirectional"
    // 0x876c60: r0 = GDT[cid_x0 + -0xd48]()
    //     0x876c60: sub             lr, x0, #0xd48
    //     0x876c64: ldr             lr, [x21, lr, lsl #3]
    //     0x876c68: blr             lr
    // 0x876c6c: mov             x3, x0
    // 0x876c70: r2 = Null
    //     0x876c70: mov             x2, NULL
    // 0x876c74: r1 = Null
    //     0x876c74: mov             x1, NULL
    // 0x876c78: stur            x3, [fp, #-8]
    // 0x876c7c: r4 = 60
    //     0x876c7c: mov             x4, #0x3c
    // 0x876c80: branchIfSmi(r0, 0x876c8c)
    //     0x876c80: tbz             w0, #0, #0x876c8c
    // 0x876c84: r4 = LoadClassIdInstr(r0)
    //     0x876c84: ldur            x4, [x0, #-1]
    //     0x876c88: ubfx            x4, x4, #0xc, #0x14
    // 0x876c8c: cmp             x4, #0x3f
    // 0x876c90: b.eq            #0x876ca0
    // 0x876c94: r8 = bool?
    //     0x876c94: ldr             x8, [PP, #0x5fd0]  ; [pp+0x5fd0] Type: bool?
    // 0x876c98: r3 = Null
    //     0x876c98: ldr             x3, [PP, #0x5fd8]  ; [pp+0x5fd8] Null
    // 0x876c9c: r0 = bool?()
    //     0x876c9c: bl              #0x7ecd2c  ; IsType_bool?_Stub
    // 0x876ca0: ldur            x0, [fp, #-8]
    // 0x876ca4: cmp             w0, NULL
    // 0x876ca8: b.eq            #0x876cac
    // 0x876cac: ldur            x1, [fp, #-0x48]
    // 0x876cb0: ldur            x0, [fp, #-0x50]
    // 0x876cb4: cmp             x1, x0
    // 0x876cb8: b.lt            #0x876cbc
    // 0x876cbc: cmp             x1, x0
    // 0x876cc0: b.lt            #0x876cc4
    // 0x876cc4: ldur            x0, [fp, #-0x18]
    // 0x876cc8: tbnz            w0, #4, #0x876cdc
    // 0x876ccc: r0 = TextEditingDeltaNonTextUpdate()
    //     0x876ccc: bl              #0x87707c  ; AllocateTextEditingDeltaNonTextUpdateStub -> TextEditingDeltaNonTextUpdate (size=0x8)
    // 0x876cd0: LeaveFrame
    //     0x876cd0: mov             SP, fp
    //     0x876cd4: ldp             fp, lr, [SP], #0x10
    // 0x876cd8: ret
    //     0x876cd8: ret             
    // 0x876cdc: ldur            x3, [fp, #-0x10]
    // 0x876ce0: ldur            x1, [fp, #-0x20]
    // 0x876ce4: ldur            x0, [fp, #-0x38]
    // 0x876ce8: ldur            x2, [fp, #-0x30]
    // 0x876cec: r0 = TextRange()
    //     0x876cec: bl              #0x83839c  ; AllocateTextRangeStub -> TextRange (size=0x18)
    // 0x876cf0: mov             x1, x0
    // 0x876cf4: ldur            x0, [fp, #-0x30]
    // 0x876cf8: StoreField: r1->field_7 = r0
    //     0x876cf8: stur            x0, [x1, #7]
    // 0x876cfc: ldur            x4, [fp, #-0x20]
    // 0x876d00: r5 = LoadInt32Instr(r4)
    //     0x876d00: sbfx            x5, x4, #1, #0x1f
    //     0x876d04: tbz             w4, #0, #0x876d0c
    //     0x876d08: ldur            x5, [x4, #7]
    // 0x876d0c: stur            x5, [fp, #-0x48]
    // 0x876d10: StoreField: r1->field_f = r5
    //     0x876d10: stur            x5, [x1, #0xf]
    // 0x876d14: mov             x3, x1
    // 0x876d18: ldur            x1, [fp, #-0x10]
    // 0x876d1c: ldur            x2, [fp, #-0x28]
    // 0x876d20: r0 = _replace()
    //     0x876d20: bl              #0x877020  ; [package:flutter/src/services/text_editing_delta.dart] ::_replace
    // 0x876d24: ldur            x1, [fp, #-0x10]
    // 0x876d28: r2 = LoadClassIdInstr(r1)
    //     0x876d28: ldur            x2, [x1, #-1]
    //     0x876d2c: ubfx            x2, x2, #0xc, #0x14
    // 0x876d30: stp             x0, x1, [SP]
    // 0x876d34: mov             x0, x2
    // 0x876d38: mov             lr, x0
    // 0x876d3c: ldr             lr, [x21, lr, lsl #3]
    // 0x876d40: blr             lr
    // 0x876d44: mov             x4, x0
    // 0x876d48: ldur            x0, [fp, #-0x30]
    // 0x876d4c: ldur            x3, [fp, #-0x48]
    // 0x876d50: stur            x4, [fp, #-0x78]
    // 0x876d54: sub             x5, x3, x0
    // 0x876d58: ldur            x1, [fp, #-0x38]
    // 0x876d5c: stur            x5, [fp, #-0x70]
    // 0x876d60: r6 = LoadInt32Instr(r1)
    //     0x876d60: sbfx            x6, x1, #1, #0x1f
    // 0x876d64: stur            x6, [fp, #-0x68]
    // 0x876d68: sub             x2, x5, x6
    // 0x876d6c: cmp             x2, #1
    // 0x876d70: r16 = true
    //     0x876d70: add             x16, NULL, #0x20  ; true
    // 0x876d74: r17 = false
    //     0x876d74: add             x17, NULL, #0x30  ; false
    // 0x876d78: csel            x7, x16, x17, gt
    // 0x876d7c: stur            x7, [fp, #-0x60]
    // 0x876d80: cbnz            w1, #0x876d9c
    // 0x876d84: cbz             x6, #0x876d90
    // 0x876d88: r2 = false
    //     0x876d88: add             x2, NULL, #0x30  ; false
    // 0x876d8c: b               #0x876d94
    // 0x876d90: r2 = true
    //     0x876d90: add             x2, NULL, #0x20  ; true
    // 0x876d94: mov             x8, x2
    // 0x876d98: b               #0x876da0
    // 0x876d9c: r8 = false
    //     0x876d9c: add             x8, NULL, #0x30  ; false
    // 0x876da0: stur            x8, [fp, #-0x58]
    // 0x876da4: tbnz            w7, #4, #0x876dc0
    // 0x876da8: cmp             x6, x5
    // 0x876dac: r16 = true
    //     0x876dac: add             x16, NULL, #0x20  ; true
    // 0x876db0: r17 = false
    //     0x876db0: add             x17, NULL, #0x30  ; false
    // 0x876db4: csel            x2, x16, x17, lt
    // 0x876db8: mov             x9, x2
    // 0x876dbc: b               #0x876dc4
    // 0x876dc0: r9 = false
    //     0x876dc0: add             x9, NULL, #0x30  ; false
    // 0x876dc4: stur            x9, [fp, #-0x40]
    // 0x876dc8: cmp             x6, x5
    // 0x876dcc: r16 = true
    //     0x876dcc: add             x16, NULL, #0x20  ; true
    // 0x876dd0: r17 = false
    //     0x876dd0: add             x17, NULL, #0x30  ; false
    // 0x876dd4: csel            x10, x16, x17, eq
    // 0x876dd8: stur            x10, [fp, #-0x18]
    // 0x876ddc: add             x11, x0, x6
    // 0x876de0: stur            x11, [fp, #-0x50]
    // 0x876de4: tbz             w9, #4, #0x876e04
    // 0x876de8: tbz             w8, #4, #0x876e04
    // 0x876dec: cmp             x11, x3
    // 0x876df0: r16 = true
    //     0x876df0: add             x16, NULL, #0x20  ; true
    // 0x876df4: r17 = false
    //     0x876df4: add             x17, NULL, #0x30  ; false
    // 0x876df8: csel            x2, x16, x17, lt
    // 0x876dfc: mov             x12, x2
    // 0x876e00: b               #0x876e08
    // 0x876e04: r12 = false
    //     0x876e04: add             x12, NULL, #0x30  ; false
    // 0x876e08: stur            x12, [fp, #-8]
    // 0x876e0c: tbz             w8, #4, #0x876e18
    // 0x876e10: tbz             w12, #4, #0x876e18
    // 0x876e14: tbnz            w9, #4, #0x876e68
    // 0x876e18: str             x1, [SP]
    // 0x876e1c: ldur            x1, [fp, #-0x28]
    // 0x876e20: r2 = 0
    //     0x876e20: mov             x2, #0
    // 0x876e24: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x876e24: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x876e28: r0 = substring()
    //     0x876e28: bl              #0x7e3f74  ; [dart:core] _StringBase::substring
    // 0x876e2c: mov             x4, x0
    // 0x876e30: ldur            x3, [fp, #-0x50]
    // 0x876e34: stur            x4, [fp, #-0x38]
    // 0x876e38: r0 = BoxInt64Instr(r3)
    //     0x876e38: sbfiz           x0, x3, #1, #0x1f
    //     0x876e3c: cmp             x3, x0, asr #1
    //     0x876e40: b.eq            #0x876e4c
    //     0x876e44: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x876e48: stur            x3, [x0, #7]
    // 0x876e4c: str             x0, [SP]
    // 0x876e50: ldur            x1, [fp, #-0x10]
    // 0x876e54: ldur            x2, [fp, #-0x30]
    // 0x876e58: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x876e58: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x876e5c: r0 = substring()
    //     0x876e5c: bl              #0x7e3f74  ; [dart:core] _StringBase::substring
    // 0x876e60: ldur            x1, [fp, #-0x38]
    // 0x876e64: b               #0x876eb4
    // 0x876e68: mov             x3, x5
    // 0x876e6c: r0 = BoxInt64Instr(r3)
    //     0x876e6c: sbfiz           x0, x3, #1, #0x1f
    //     0x876e70: cmp             x3, x0, asr #1
    //     0x876e74: b.eq            #0x876e80
    //     0x876e78: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x876e7c: stur            x3, [x0, #7]
    // 0x876e80: str             x0, [SP]
    // 0x876e84: ldur            x1, [fp, #-0x28]
    // 0x876e88: r2 = 0
    //     0x876e88: mov             x2, #0
    // 0x876e8c: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x876e8c: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x876e90: r0 = substring()
    //     0x876e90: bl              #0x7e3f74  ; [dart:core] _StringBase::substring
    // 0x876e94: stur            x0, [fp, #-0x38]
    // 0x876e98: ldur            x16, [fp, #-0x20]
    // 0x876e9c: str             x16, [SP]
    // 0x876ea0: ldur            x1, [fp, #-0x10]
    // 0x876ea4: ldur            x2, [fp, #-0x30]
    // 0x876ea8: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x876ea8: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x876eac: r0 = substring()
    //     0x876eac: bl              #0x7e3f74  ; [dart:core] _StringBase::substring
    // 0x876eb0: ldur            x1, [fp, #-0x38]
    // 0x876eb4: r2 = LoadClassIdInstr(r0)
    //     0x876eb4: ldur            x2, [x0, #-1]
    //     0x876eb8: ubfx            x2, x2, #0xc, #0x14
    // 0x876ebc: stp             x1, x0, [SP]
    // 0x876ec0: mov             x0, x2
    // 0x876ec4: mov             lr, x0
    // 0x876ec8: ldr             lr, [x21, lr, lsl #3]
    // 0x876ecc: blr             lr
    // 0x876ed0: eor             x1, x0, #0x10
    // 0x876ed4: tbnz            w1, #4, #0x876ee4
    // 0x876ed8: ldur            x2, [fp, #-0x70]
    // 0x876edc: ldur            x0, [fp, #-0x68]
    // 0x876ee0: b               #0x876efc
    // 0x876ee4: ldur            x2, [fp, #-0x70]
    // 0x876ee8: ldur            x0, [fp, #-0x68]
    // 0x876eec: cmp             x0, x2
    // 0x876ef0: b.gt            #0x876efc
    // 0x876ef4: ldur            x3, [fp, #-0x40]
    // 0x876ef8: tbnz            w3, #4, #0x876f04
    // 0x876efc: r4 = true
    //     0x876efc: add             x4, NULL, #0x20  ; true
    // 0x876f00: b               #0x876f08
    // 0x876f04: ldur            x4, [fp, #-0x18]
    // 0x876f08: ldur            x3, [fp, #-0x78]
    // 0x876f0c: tbnz            w3, #4, #0x876f20
    // 0x876f10: r0 = TextEditingDeltaNonTextUpdate()
    //     0x876f10: bl              #0x87707c  ; AllocateTextEditingDeltaNonTextUpdateStub -> TextEditingDeltaNonTextUpdate (size=0x8)
    // 0x876f14: LeaveFrame
    //     0x876f14: mov             SP, fp
    //     0x876f18: ldp             fp, lr, [SP], #0x10
    // 0x876f1c: ret
    //     0x876f1c: ret             
    // 0x876f20: ldur            x3, [fp, #-0x58]
    // 0x876f24: tbz             w3, #4, #0x876f30
    // 0x876f28: ldur            x3, [fp, #-8]
    // 0x876f2c: tbnz            w3, #4, #0x876f4c
    // 0x876f30: tbz             w1, #4, #0x876f4c
    // 0x876f34: ldur            x0, [fp, #-0x60]
    // 0x876f38: tbnz            w0, #4, #0x876f3c
    // 0x876f3c: r0 = TextEditingDeltaDeletion()
    //     0x876f3c: bl              #0x877014  ; AllocateTextEditingDeltaDeletionStub -> TextEditingDeltaDeletion (size=0x8)
    // 0x876f40: LeaveFrame
    //     0x876f40: mov             SP, fp
    //     0x876f44: ldp             fp, lr, [SP], #0x10
    // 0x876f48: ret
    //     0x876f48: ret             
    // 0x876f4c: ldur            x3, [fp, #-0x30]
    // 0x876f50: ldur            x5, [fp, #-0x48]
    // 0x876f54: cmp             x3, x5
    // 0x876f58: b.eq            #0x876f68
    // 0x876f5c: ldur            x3, [fp, #-0x50]
    // 0x876f60: cmp             x3, x5
    // 0x876f64: b.le            #0x876fa8
    // 0x876f68: tbz             w1, #4, #0x876fa8
    // 0x876f6c: sub             x1, x0, x2
    // 0x876f70: add             x3, x2, x1
    // 0x876f74: r0 = BoxInt64Instr(r3)
    //     0x876f74: sbfiz           x0, x3, #1, #0x1f
    //     0x876f78: cmp             x3, x0, asr #1
    //     0x876f7c: b.eq            #0x876f88
    //     0x876f80: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x876f84: stur            x3, [x0, #7]
    // 0x876f88: str             x0, [SP]
    // 0x876f8c: ldur            x1, [fp, #-0x28]
    // 0x876f90: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x876f90: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x876f94: r0 = substring()
    //     0x876f94: bl              #0x7e3f74  ; [dart:core] _StringBase::substring
    // 0x876f98: r0 = TextEditingDeltaInsertion()
    //     0x876f98: bl              #0x877008  ; AllocateTextEditingDeltaInsertionStub -> TextEditingDeltaInsertion (size=0x8)
    // 0x876f9c: LeaveFrame
    //     0x876f9c: mov             SP, fp
    //     0x876fa0: ldp             fp, lr, [SP], #0x10
    // 0x876fa4: ret
    //     0x876fa4: ret             
    // 0x876fa8: tbnz            w4, #4, #0x876fbc
    // 0x876fac: r0 = TextEditingDeltaReplacement()
    //     0x876fac: bl              #0x876ffc  ; AllocateTextEditingDeltaReplacementStub -> TextEditingDeltaReplacement (size=0x8)
    // 0x876fb0: LeaveFrame
    //     0x876fb0: mov             SP, fp
    //     0x876fb4: ldp             fp, lr, [SP], #0x10
    // 0x876fb8: ret
    //     0x876fb8: ret             
    // 0x876fbc: r0 = TextEditingDeltaNonTextUpdate()
    //     0x876fbc: bl              #0x87707c  ; AllocateTextEditingDeltaNonTextUpdateStub -> TextEditingDeltaNonTextUpdate (size=0x8)
    // 0x876fc0: LeaveFrame
    //     0x876fc0: mov             SP, fp
    //     0x876fc4: ldp             fp, lr, [SP], #0x10
    // 0x876fc8: ret
    //     0x876fc8: ret             
    // 0x876fcc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x876fcc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x876fd0: b               #0x87684c
  }
}

// class id: 5010, size: 0x8, field offset: 0x8
//   const constructor, 
class TextEditingDeltaNonTextUpdate extends TextEditingDelta {
}

// class id: 5011, size: 0x8, field offset: 0x8
//   const constructor, 
class TextEditingDeltaReplacement extends TextEditingDelta {
}

// class id: 5012, size: 0x8, field offset: 0x8
//   const constructor, 
class TextEditingDeltaDeletion extends TextEditingDelta {
}

// class id: 5013, size: 0x8, field offset: 0x8
//   const constructor, 
class TextEditingDeltaInsertion extends TextEditingDelta {
}
