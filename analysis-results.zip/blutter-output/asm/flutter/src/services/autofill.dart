// lib: , url: package:flutter/src/services/autofill.dart

// class id: 1049068, size: 0x8
class :: {
}

// class id: 2804, size: 0x1c, field offset: 0x8
//   const constructor, 
class AutofillConfiguration extends Object {

  bool field_8;
  _OneByteString field_c;
  _ImmutableList<String> field_10;
  TextEditingValue field_14;

  Map<String, dynamic>? toJson(AutofillConfiguration) {
    // ** addr: 0x878f24, size: 0x120
    // 0x878f24: EnterFrame
    //     0x878f24: stp             fp, lr, [SP, #-0x10]!
    //     0x878f28: mov             fp, SP
    // 0x878f2c: AllocStack(0x20)
    //     0x878f2c: sub             SP, SP, #0x20
    // 0x878f30: SetupParameters(AutofillConfiguration this /* r1 => r1, fp-0x8 */)
    //     0x878f30: stur            x1, [fp, #-8]
    // 0x878f34: CheckStackOverflow
    //     0x878f34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x878f38: cmp             SP, x16
    //     0x878f3c: b.ls            #0x87903c
    // 0x878f40: LoadField: r0 = r1->field_7
    //     0x878f40: ldur            w0, [x1, #7]
    // 0x878f44: DecompressPointer r0
    //     0x878f44: add             x0, x0, HEAP, lsl #32
    // 0x878f48: tbnz            w0, #4, #0x87902c
    // 0x878f4c: r16 = <String, dynamic>
    //     0x878f4c: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x878f50: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x878f54: stp             lr, x16, [SP]
    // 0x878f58: r0 = Map._fromLiteral()
    //     0x878f58: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x878f5c: mov             x5, x0
    // 0x878f60: ldur            x4, [fp, #-8]
    // 0x878f64: stur            x5, [fp, #-0x10]
    // 0x878f68: LoadField: r3 = r4->field_b
    //     0x878f68: ldur            w3, [x4, #0xb]
    // 0x878f6c: DecompressPointer r3
    //     0x878f6c: add             x3, x3, HEAP, lsl #32
    // 0x878f70: r0 = LoadClassIdInstr(r5)
    //     0x878f70: ldur            x0, [x5, #-1]
    //     0x878f74: ubfx            x0, x0, #0xc, #0x14
    // 0x878f78: mov             x1, x5
    // 0x878f7c: r2 = "uniqueIdentifier"
    //     0x878f7c: ldr             x2, [PP, #0x6200]  ; [pp+0x6200] "uniqueIdentifier"
    // 0x878f80: r0 = GDT[cid_x0 + -0xd50]()
    //     0x878f80: sub             lr, x0, #0xd50
    //     0x878f84: ldr             lr, [x21, lr, lsl #3]
    //     0x878f88: blr             lr
    // 0x878f8c: ldur            x4, [fp, #-8]
    // 0x878f90: LoadField: r3 = r4->field_f
    //     0x878f90: ldur            w3, [x4, #0xf]
    // 0x878f94: DecompressPointer r3
    //     0x878f94: add             x3, x3, HEAP, lsl #32
    // 0x878f98: ldur            x5, [fp, #-0x10]
    // 0x878f9c: r0 = LoadClassIdInstr(r5)
    //     0x878f9c: ldur            x0, [x5, #-1]
    //     0x878fa0: ubfx            x0, x0, #0xc, #0x14
    // 0x878fa4: mov             x1, x5
    // 0x878fa8: r2 = "hints"
    //     0x878fa8: ldr             x2, [PP, #0x6208]  ; [pp+0x6208] "hints"
    // 0x878fac: r0 = GDT[cid_x0 + -0xd50]()
    //     0x878fac: sub             lr, x0, #0xd50
    //     0x878fb0: ldr             lr, [x21, lr, lsl #3]
    //     0x878fb4: blr             lr
    // 0x878fb8: ldur            x0, [fp, #-8]
    // 0x878fbc: LoadField: r1 = r0->field_13
    //     0x878fbc: ldur            w1, [x0, #0x13]
    // 0x878fc0: DecompressPointer r1
    //     0x878fc0: add             x1, x1, HEAP, lsl #32
    // 0x878fc4: r0 = toJSON()
    //     0x878fc4: bl              #0x877d3c  ; [package:flutter/src/services/text_input.dart] TextEditingValue::toJSON
    // 0x878fc8: ldur            x4, [fp, #-0x10]
    // 0x878fcc: r1 = LoadClassIdInstr(r4)
    //     0x878fcc: ldur            x1, [x4, #-1]
    //     0x878fd0: ubfx            x1, x1, #0xc, #0x14
    // 0x878fd4: mov             x3, x0
    // 0x878fd8: mov             x0, x1
    // 0x878fdc: mov             x1, x4
    // 0x878fe0: r2 = "editingValue"
    //     0x878fe0: ldr             x2, [PP, #0x6210]  ; [pp+0x6210] "editingValue"
    // 0x878fe4: r0 = GDT[cid_x0 + -0xd50]()
    //     0x878fe4: sub             lr, x0, #0xd50
    //     0x878fe8: ldr             lr, [x21, lr, lsl #3]
    //     0x878fec: blr             lr
    // 0x878ff0: ldur            x0, [fp, #-8]
    // 0x878ff4: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x878ff4: ldur            w3, [x0, #0x17]
    // 0x878ff8: DecompressPointer r3
    //     0x878ff8: add             x3, x3, HEAP, lsl #32
    // 0x878ffc: cmp             w3, NULL
    // 0x879000: b.eq            #0x879024
    // 0x879004: ldur            x4, [fp, #-0x10]
    // 0x879008: r0 = LoadClassIdInstr(r4)
    //     0x879008: ldur            x0, [x4, #-1]
    //     0x87900c: ubfx            x0, x0, #0xc, #0x14
    // 0x879010: mov             x1, x4
    // 0x879014: r2 = "hintText"
    //     0x879014: ldr             x2, [PP, #0x6218]  ; [pp+0x6218] "hintText"
    // 0x879018: r0 = GDT[cid_x0 + -0xd50]()
    //     0x879018: sub             lr, x0, #0xd50
    //     0x87901c: ldr             lr, [x21, lr, lsl #3]
    //     0x879020: blr             lr
    // 0x879024: ldur            x0, [fp, #-0x10]
    // 0x879028: b               #0x879030
    // 0x87902c: r0 = Null
    //     0x87902c: mov             x0, NULL
    // 0x879030: LeaveFrame
    //     0x879030: mov             SP, fp
    //     0x879034: ldp             fp, lr, [SP], #0x10
    // 0x879038: ret
    //     0x879038: ret             
    // 0x87903c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87903c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x879040: b               #0x878f40
  }
  Map<String, dynamic>? toJson(AutofillConfiguration) {
    // ** addr: 0x87905c, size: 0x48
    // 0x87905c: EnterFrame
    //     0x87905c: stp             fp, lr, [SP, #-0x10]!
    //     0x879060: mov             fp, SP
    // 0x879064: CheckStackOverflow
    //     0x879064: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x879068: cmp             SP, x16
    //     0x87906c: b.ls            #0x879084
    // 0x879070: ldr             x1, [fp, #0x10]
    // 0x879074: r0 = toJson()
    //     0x879074: bl              #0x878f24  ; [package:flutter/src/services/autofill.dart] AutofillConfiguration::toJson
    // 0x879078: LeaveFrame
    //     0x879078: mov             SP, fp
    //     0x87907c: ldp             fp, lr, [SP], #0x10
    // 0x879080: ret
    //     0x879080: ret             
    // 0x879084: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x879084: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x879088: b               #0x879070
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x114cd14, size: 0xb4
    // 0x114cd14: EnterFrame
    //     0x114cd14: stp             fp, lr, [SP, #-0x10]!
    //     0x114cd18: mov             fp, SP
    // 0x114cd1c: AllocStack(0x28)
    //     0x114cd1c: sub             SP, SP, #0x28
    // 0x114cd20: CheckStackOverflow
    //     0x114cd20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x114cd24: cmp             SP, x16
    //     0x114cd28: b.ls            #0x114cdc0
    // 0x114cd2c: ldr             x0, [fp, #0x10]
    // 0x114cd30: LoadField: r2 = r0->field_7
    //     0x114cd30: ldur            w2, [x0, #7]
    // 0x114cd34: DecompressPointer r2
    //     0x114cd34: add             x2, x2, HEAP, lsl #32
    // 0x114cd38: stur            x2, [fp, #-0x10]
    // 0x114cd3c: LoadField: r3 = r0->field_b
    //     0x114cd3c: ldur            w3, [x0, #0xb]
    // 0x114cd40: DecompressPointer r3
    //     0x114cd40: add             x3, x3, HEAP, lsl #32
    // 0x114cd44: stur            x3, [fp, #-8]
    // 0x114cd48: LoadField: r1 = r0->field_f
    //     0x114cd48: ldur            w1, [x0, #0xf]
    // 0x114cd4c: DecompressPointer r1
    //     0x114cd4c: add             x1, x1, HEAP, lsl #32
    // 0x114cd50: r0 = hashAll()
    //     0x114cd50: bl              #0x112b348  ; [dart:core] Object::hashAll
    // 0x114cd54: mov             x2, x0
    // 0x114cd58: ldr             x0, [fp, #0x10]
    // 0x114cd5c: LoadField: r3 = r0->field_13
    //     0x114cd5c: ldur            w3, [x0, #0x13]
    // 0x114cd60: DecompressPointer r3
    //     0x114cd60: add             x3, x3, HEAP, lsl #32
    // 0x114cd64: ArrayLoad: r4 = r0[0]  ; List_4
    //     0x114cd64: ldur            w4, [x0, #0x17]
    // 0x114cd68: DecompressPointer r4
    //     0x114cd68: add             x4, x4, HEAP, lsl #32
    // 0x114cd6c: r0 = BoxInt64Instr(r2)
    //     0x114cd6c: sbfiz           x0, x2, #1, #0x1f
    //     0x114cd70: cmp             x2, x0, asr #1
    //     0x114cd74: b.eq            #0x114cd80
    //     0x114cd78: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x114cd7c: stur            x2, [x0, #7]
    // 0x114cd80: stp             x3, x0, [SP, #8]
    // 0x114cd84: str             x4, [SP]
    // 0x114cd88: ldur            x1, [fp, #-0x10]
    // 0x114cd8c: ldur            x2, [fp, #-8]
    // 0x114cd90: r4 = const [0, 0x5, 0x3, 0x5, null]
    //     0x114cd90: add             x4, PP, #0xd, lsl #12  ; [pp+0xdc80] List(5) [0, 0x5, 0x3, 0x5, Null]
    //     0x114cd94: ldr             x4, [x4, #0xc80]
    // 0x114cd98: r0 = hash()
    //     0x114cd98: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x114cd9c: mov             x2, x0
    // 0x114cda0: r0 = BoxInt64Instr(r2)
    //     0x114cda0: sbfiz           x0, x2, #1, #0x1f
    //     0x114cda4: cmp             x2, x0, asr #1
    //     0x114cda8: b.eq            #0x114cdb4
    //     0x114cdac: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x114cdb0: stur            x2, [x0, #7]
    // 0x114cdb4: LeaveFrame
    //     0x114cdb4: mov             SP, fp
    //     0x114cdb8: ldp             fp, lr, [SP], #0x10
    // 0x114cdbc: ret
    //     0x114cdbc: ret             
    // 0x114cdc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x114cdc0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x114cdc4: b               #0x114cd2c
  }
  _ ==(/* No info */) {
    // ** addr: 0x129a8c0, size: 0x19c
    // 0x129a8c0: EnterFrame
    //     0x129a8c0: stp             fp, lr, [SP, #-0x10]!
    //     0x129a8c4: mov             fp, SP
    // 0x129a8c8: AllocStack(0x18)
    //     0x129a8c8: sub             SP, SP, #0x18
    // 0x129a8cc: CheckStackOverflow
    //     0x129a8cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x129a8d0: cmp             SP, x16
    //     0x129a8d4: b.ls            #0x129aa54
    // 0x129a8d8: ldr             x0, [fp, #0x10]
    // 0x129a8dc: cmp             w0, NULL
    // 0x129a8e0: b.ne            #0x129a8f4
    // 0x129a8e4: r0 = false
    //     0x129a8e4: add             x0, NULL, #0x30  ; false
    // 0x129a8e8: LeaveFrame
    //     0x129a8e8: mov             SP, fp
    //     0x129a8ec: ldp             fp, lr, [SP], #0x10
    // 0x129a8f0: ret
    //     0x129a8f0: ret             
    // 0x129a8f4: ldr             x1, [fp, #0x18]
    // 0x129a8f8: cmp             w1, w0
    // 0x129a8fc: b.ne            #0x129a910
    // 0x129a900: r0 = true
    //     0x129a900: add             x0, NULL, #0x20  ; true
    // 0x129a904: LeaveFrame
    //     0x129a904: mov             SP, fp
    //     0x129a908: ldp             fp, lr, [SP], #0x10
    // 0x129a90c: ret
    //     0x129a90c: ret             
    // 0x129a910: str             x0, [SP]
    // 0x129a914: r0 = runtimeType()
    //     0x129a914: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x129a918: r1 = LoadClassIdInstr(r0)
    //     0x129a918: ldur            x1, [x0, #-1]
    //     0x129a91c: ubfx            x1, x1, #0xc, #0x14
    // 0x129a920: r16 = AutofillConfiguration
    //     0x129a920: add             x16, PP, #0x98, lsl #12  ; [pp+0x98d48] Type: AutofillConfiguration
    //     0x129a924: ldr             x16, [x16, #0xd48]
    // 0x129a928: stp             x16, x0, [SP]
    // 0x129a92c: mov             x0, x1
    // 0x129a930: mov             lr, x0
    // 0x129a934: ldr             lr, [x21, lr, lsl #3]
    // 0x129a938: blr             lr
    // 0x129a93c: tbz             w0, #4, #0x129a950
    // 0x129a940: r0 = false
    //     0x129a940: add             x0, NULL, #0x30  ; false
    // 0x129a944: LeaveFrame
    //     0x129a944: mov             SP, fp
    //     0x129a948: ldp             fp, lr, [SP], #0x10
    // 0x129a94c: ret
    //     0x129a94c: ret             
    // 0x129a950: ldr             x1, [fp, #0x10]
    // 0x129a954: r0 = 60
    //     0x129a954: mov             x0, #0x3c
    // 0x129a958: branchIfSmi(r1, 0x129a964)
    //     0x129a958: tbz             w1, #0, #0x129a964
    // 0x129a95c: r0 = LoadClassIdInstr(r1)
    //     0x129a95c: ldur            x0, [x1, #-1]
    //     0x129a960: ubfx            x0, x0, #0xc, #0x14
    // 0x129a964: cmp             x0, #0xaf4
    // 0x129a968: b.ne            #0x129aa44
    // 0x129a96c: ldr             x2, [fp, #0x18]
    // 0x129a970: LoadField: r0 = r1->field_7
    //     0x129a970: ldur            w0, [x1, #7]
    // 0x129a974: DecompressPointer r0
    //     0x129a974: add             x0, x0, HEAP, lsl #32
    // 0x129a978: LoadField: r3 = r2->field_7
    //     0x129a978: ldur            w3, [x2, #7]
    // 0x129a97c: DecompressPointer r3
    //     0x129a97c: add             x3, x3, HEAP, lsl #32
    // 0x129a980: cmp             w0, w3
    // 0x129a984: b.ne            #0x129aa44
    // 0x129a988: LoadField: r0 = r1->field_b
    //     0x129a988: ldur            w0, [x1, #0xb]
    // 0x129a98c: DecompressPointer r0
    //     0x129a98c: add             x0, x0, HEAP, lsl #32
    // 0x129a990: LoadField: r3 = r2->field_b
    //     0x129a990: ldur            w3, [x2, #0xb]
    // 0x129a994: DecompressPointer r3
    //     0x129a994: add             x3, x3, HEAP, lsl #32
    // 0x129a998: r4 = LoadClassIdInstr(r0)
    //     0x129a998: ldur            x4, [x0, #-1]
    //     0x129a99c: ubfx            x4, x4, #0xc, #0x14
    // 0x129a9a0: stp             x3, x0, [SP]
    // 0x129a9a4: mov             x0, x4
    // 0x129a9a8: mov             lr, x0
    // 0x129a9ac: ldr             lr, [x21, lr, lsl #3]
    // 0x129a9b0: blr             lr
    // 0x129a9b4: tbnz            w0, #4, #0x129aa44
    // 0x129a9b8: ldr             x1, [fp, #0x18]
    // 0x129a9bc: ldr             x0, [fp, #0x10]
    // 0x129a9c0: LoadField: r2 = r0->field_f
    //     0x129a9c0: ldur            w2, [x0, #0xf]
    // 0x129a9c4: DecompressPointer r2
    //     0x129a9c4: add             x2, x2, HEAP, lsl #32
    // 0x129a9c8: LoadField: r3 = r1->field_f
    //     0x129a9c8: ldur            w3, [x1, #0xf]
    // 0x129a9cc: DecompressPointer r3
    //     0x129a9cc: add             x3, x3, HEAP, lsl #32
    // 0x129a9d0: r16 = <String>
    //     0x129a9d0: ldr             x16, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    // 0x129a9d4: stp             x2, x16, [SP, #8]
    // 0x129a9d8: str             x3, [SP]
    // 0x129a9dc: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x129a9dc: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x129a9e0: r0 = listEquals()
    //     0x129a9e0: bl              #0x8595b0  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0x129a9e4: tbnz            w0, #4, #0x129aa44
    // 0x129a9e8: ldr             x1, [fp, #0x18]
    // 0x129a9ec: ldr             x0, [fp, #0x10]
    // 0x129a9f0: LoadField: r2 = r0->field_13
    //     0x129a9f0: ldur            w2, [x0, #0x13]
    // 0x129a9f4: DecompressPointer r2
    //     0x129a9f4: add             x2, x2, HEAP, lsl #32
    // 0x129a9f8: LoadField: r3 = r1->field_13
    //     0x129a9f8: ldur            w3, [x1, #0x13]
    // 0x129a9fc: DecompressPointer r3
    //     0x129a9fc: add             x3, x3, HEAP, lsl #32
    // 0x129aa00: stp             x3, x2, [SP]
    // 0x129aa04: r0 = ==()
    //     0x129aa04: bl              #0x129b280  ; [package:flutter/src/services/text_input.dart] TextEditingValue::==
    // 0x129aa08: tbnz            w0, #4, #0x129aa44
    // 0x129aa0c: ldr             x1, [fp, #0x18]
    // 0x129aa10: ldr             x0, [fp, #0x10]
    // 0x129aa14: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x129aa14: ldur            w2, [x0, #0x17]
    // 0x129aa18: DecompressPointer r2
    //     0x129aa18: add             x2, x2, HEAP, lsl #32
    // 0x129aa1c: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x129aa1c: ldur            w0, [x1, #0x17]
    // 0x129aa20: DecompressPointer r0
    //     0x129aa20: add             x0, x0, HEAP, lsl #32
    // 0x129aa24: r1 = LoadClassIdInstr(r2)
    //     0x129aa24: ldur            x1, [x2, #-1]
    //     0x129aa28: ubfx            x1, x1, #0xc, #0x14
    // 0x129aa2c: stp             x0, x2, [SP]
    // 0x129aa30: mov             x0, x1
    // 0x129aa34: mov             lr, x0
    // 0x129aa38: ldr             lr, [x21, lr, lsl #3]
    // 0x129aa3c: blr             lr
    // 0x129aa40: b               #0x129aa48
    // 0x129aa44: r0 = false
    //     0x129aa44: add             x0, NULL, #0x30  ; false
    // 0x129aa48: LeaveFrame
    //     0x129aa48: mov             SP, fp
    //     0x129aa4c: ldp             fp, lr, [SP], #0x10
    // 0x129aa50: ret
    //     0x129aa50: ret             
    // 0x129aa54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x129aa54: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x129aa58: b               #0x129a8d8
  }
}

// class id: 2970, size: 0x8, field offset: 0x8
abstract class AutofillClient extends Object {
}
