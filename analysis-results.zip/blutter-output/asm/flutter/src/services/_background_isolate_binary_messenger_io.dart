// lib: , url: package:flutter/src/services/_background_isolate_binary_messenger_io.dart

// class id: 1049065, size: 0x8
class :: {
}

// class id: 2812, size: 0x8, field offset: 0x8
abstract class BackgroundIsolateBinaryMessenger extends Object {

  get _ instance(/* No info */) {
    // ** addr: 0x83b020, size: 0x24
    // 0x83b020: EnterFrame
    //     0x83b020: stp             fp, lr, [SP, #-0x10]!
    //     0x83b024: mov             fp, SP
    // 0x83b028: r0 = StateError()
    //     0x83b028: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x83b02c: mov             x1, x0
    // 0x83b030: r0 = "The BackgroundIsolateBinaryMessenger.instance value is invalid until BackgroundIsolateBinaryMessenger.ensureInitialized is executed."
    //     0x83b030: ldr             x0, [PP, #0x1580]  ; [pp+0x1580] "The BackgroundIsolateBinaryMessenger.instance value is invalid until BackgroundIsolateBinaryMessenger.ensureInitialized is executed."
    // 0x83b034: StoreField: r1->field_b = r0
    //     0x83b034: stur            w0, [x1, #0xb]
    // 0x83b038: mov             x0, x1
    // 0x83b03c: r0 = Throw()
    //     0x83b03c: bl              #0x13ddb2c  ; ThrowStub
    // 0x83b040: brk             #0
  }
}
