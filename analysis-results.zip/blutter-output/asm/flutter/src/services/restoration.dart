// lib: , url: package:flutter/src/services/restoration.dart

// class id: 1049094, size: 0x8
class :: {
}

// class id: 2749, size: 0x24, field offset: 0x8
class RestorationBucket extends Object {

  _ dispose(/* No info */) {
    // ** addr: 0x850120, size: 0xb0
    // 0x850120: EnterFrame
    //     0x850120: stp             fp, lr, [SP, #-0x10]!
    //     0x850124: mov             fp, SP
    // 0x850128: AllocStack(0x10)
    //     0x850128: sub             SP, SP, #0x10
    // 0x85012c: SetupParameters(RestorationBucket this /* r1 => r0, fp-0x8 */)
    //     0x85012c: mov             x0, x1
    //     0x850130: stur            x1, [fp, #-8]
    // 0x850134: CheckStackOverflow
    //     0x850134: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x850138: cmp             SP, x16
    //     0x85013c: b.ls            #0x8501c8
    // 0x850140: mov             x2, x0
    // 0x850144: r1 = Function '_dropChild@77347053':.
    //     0x850144: ldr             x1, [PP, #0x41c8]  ; [pp+0x41c8] AnonymousClosure: (0x851130), in [package:flutter/src/services/restoration.dart] RestorationBucket::_dropChild (0x85116c)
    // 0x850148: r0 = AllocateClosure()
    //     0x850148: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x85014c: r16 = true
    //     0x85014c: add             x16, NULL, #0x20  ; true
    // 0x850150: str             x16, [SP]
    // 0x850154: ldur            x1, [fp, #-8]
    // 0x850158: mov             x2, x0
    // 0x85015c: r4 = const [0, 0x3, 0x1, 0x2, concurrentModification, 0x2, null]
    //     0x85015c: ldr             x4, [PP, #0x41d0]  ; [pp+0x41d0] List(7) [0, 0x3, 0x1, 0x2, "concurrentModification", 0x2, Null]
    // 0x850160: r0 = _visitChildren()
    //     0x850160: bl              #0x850d08  ; [package:flutter/src/services/restoration.dart] RestorationBucket::_visitChildren
    // 0x850164: ldur            x2, [fp, #-8]
    // 0x850168: ArrayLoad: r1 = r2[0]  ; List_4
    //     0x850168: ldur            w1, [x2, #0x17]
    // 0x85016c: DecompressPointer r1
    //     0x85016c: add             x1, x1, HEAP, lsl #32
    // 0x850170: r0 = clear()
    //     0x850170: bl              #0xa11274  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0x850174: ldur            x2, [fp, #-8]
    // 0x850178: LoadField: r1 = r2->field_1b
    //     0x850178: ldur            w1, [x2, #0x1b]
    // 0x85017c: DecompressPointer r1
    //     0x85017c: add             x1, x1, HEAP, lsl #32
    // 0x850180: r0 = clear()
    //     0x850180: bl              #0xa11274  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0x850184: ldur            x0, [fp, #-8]
    // 0x850188: LoadField: r1 = r0->field_f
    //     0x850188: ldur            w1, [x0, #0xf]
    // 0x85018c: DecompressPointer r1
    //     0x85018c: add             x1, x1, HEAP, lsl #32
    // 0x850190: cmp             w1, NULL
    // 0x850194: b.ne            #0x8501a0
    // 0x850198: mov             x1, x0
    // 0x85019c: b               #0x8501ac
    // 0x8501a0: mov             x2, x0
    // 0x8501a4: r0 = _removeChildData()
    //     0x8501a4: bl              #0x850864  ; [package:flutter/src/services/restoration.dart] RestorationBucket::_removeChildData
    // 0x8501a8: ldur            x1, [fp, #-8]
    // 0x8501ac: StoreField: r1->field_f = rNULL
    //     0x8501ac: stur            NULL, [x1, #0xf]
    // 0x8501b0: r2 = Null
    //     0x8501b0: mov             x2, NULL
    // 0x8501b4: r0 = _updateManager()
    //     0x8501b4: bl              #0x85037c  ; [package:flutter/src/services/restoration.dart] RestorationBucket::_updateManager
    // 0x8501b8: r0 = Null
    //     0x8501b8: mov             x0, NULL
    // 0x8501bc: LeaveFrame
    //     0x8501bc: mov             SP, fp
    //     0x8501c0: ldp             fp, lr, [SP], #0x10
    // 0x8501c4: ret
    //     0x8501c4: ret             
    // 0x8501c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8501c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8501cc: b               #0x850140
  }
  bool contains(RestorationBucket, String) {
    // ** addr: 0x8501e8, size: 0x4c
    // 0x8501e8: EnterFrame
    //     0x8501e8: stp             fp, lr, [SP, #-0x10]!
    //     0x8501ec: mov             fp, SP
    // 0x8501f0: CheckStackOverflow
    //     0x8501f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8501f4: cmp             SP, x16
    //     0x8501f8: b.ls            #0x850214
    // 0x8501fc: ldr             x1, [fp, #0x18]
    // 0x850200: ldr             x2, [fp, #0x10]
    // 0x850204: r0 = contains()
    //     0x850204: bl              #0x85021c  ; [package:flutter/src/services/restoration.dart] RestorationBucket::contains
    // 0x850208: LeaveFrame
    //     0x850208: mov             SP, fp
    //     0x85020c: ldp             fp, lr, [SP], #0x10
    // 0x850210: ret
    //     0x850210: ret             
    // 0x850214: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x850214: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x850218: b               #0x8501fc
  }
  bool contains(RestorationBucket, String) {
    // ** addr: 0x85021c, size: 0x58
    // 0x85021c: EnterFrame
    //     0x85021c: stp             fp, lr, [SP, #-0x10]!
    //     0x850220: mov             fp, SP
    // 0x850224: AllocStack(0x8)
    //     0x850224: sub             SP, SP, #8
    // 0x850228: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x850228: stur            x2, [fp, #-8]
    // 0x85022c: CheckStackOverflow
    //     0x85022c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x850230: cmp             SP, x16
    //     0x850234: b.ls            #0x85026c
    // 0x850238: r0 = _rawValues()
    //     0x850238: bl              #0x850274  ; [package:flutter/src/services/restoration.dart] RestorationBucket::_rawValues
    // 0x85023c: r1 = LoadClassIdInstr(r0)
    //     0x85023c: ldur            x1, [x0, #-1]
    //     0x850240: ubfx            x1, x1, #0xc, #0x14
    // 0x850244: mov             x16, x0
    // 0x850248: mov             x0, x1
    // 0x85024c: mov             x1, x16
    // 0x850250: ldur            x2, [fp, #-8]
    // 0x850254: r0 = GDT[cid_x0 + -0x104]()
    //     0x850254: sub             lr, x0, #0x104
    //     0x850258: ldr             lr, [x21, lr, lsl #3]
    //     0x85025c: blr             lr
    // 0x850260: LeaveFrame
    //     0x850260: mov             SP, fp
    //     0x850264: ldp             fp, lr, [SP], #0x10
    // 0x850268: ret
    //     0x850268: ret             
    // 0x85026c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85026c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x850270: b               #0x850238
  }
  get _ _rawValues(/* No info */) {
    // ** addr: 0x850274, size: 0xac
    // 0x850274: EnterFrame
    //     0x850274: stp             fp, lr, [SP, #-0x10]!
    //     0x850278: mov             fp, SP
    // 0x85027c: AllocStack(0x8)
    //     0x85027c: sub             SP, SP, #8
    // 0x850280: CheckStackOverflow
    //     0x850280: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x850284: cmp             SP, x16
    //     0x850288: b.ls            #0x850314
    // 0x85028c: LoadField: r0 = r1->field_7
    //     0x85028c: ldur            w0, [x1, #7]
    // 0x850290: DecompressPointer r0
    //     0x850290: add             x0, x0, HEAP, lsl #32
    // 0x850294: stur            x0, [fp, #-8]
    // 0x850298: r1 = Function '<anonymous closure>':.
    //     0x850298: add             x1, PP, #0x84, lsl #12  ; [pp+0x84d40] AnonymousClosure: (0x850320), of [package:flutter/src/services/restoration.dart] RestorationBucket
    //     0x85029c: ldr             x1, [x1, #0xd40]
    // 0x8502a0: r2 = Null
    //     0x8502a0: mov             x2, NULL
    // 0x8502a4: r0 = AllocateClosure()
    //     0x8502a4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8502a8: ldur            x1, [fp, #-8]
    // 0x8502ac: r2 = LoadClassIdInstr(r1)
    //     0x8502ac: ldur            x2, [x1, #-1]
    //     0x8502b0: ubfx            x2, x2, #0xc, #0x14
    // 0x8502b4: mov             x3, x0
    // 0x8502b8: mov             x0, x2
    // 0x8502bc: r2 = "v"
    //     0x8502bc: add             x2, PP, #0x10, lsl #12  ; [pp+0x10718] "v"
    //     0x8502c0: ldr             x2, [x2, #0x718]
    // 0x8502c4: r0 = GDT[cid_x0 + 0x1688c]()
    //     0x8502c4: mov             x17, #0x688c
    //     0x8502c8: movk            x17, #1, lsl #16
    //     0x8502cc: add             lr, x0, x17
    //     0x8502d0: ldr             lr, [x21, lr, lsl #3]
    //     0x8502d4: blr             lr
    // 0x8502d8: mov             x3, x0
    // 0x8502dc: stur            x3, [fp, #-8]
    // 0x8502e0: cmp             w3, NULL
    // 0x8502e4: b.eq            #0x85031c
    // 0x8502e8: mov             x0, x3
    // 0x8502ec: r2 = Null
    //     0x8502ec: mov             x2, NULL
    // 0x8502f0: r1 = Null
    //     0x8502f0: mov             x1, NULL
    // 0x8502f4: r8 = Map<Object?, Object?>
    //     0x8502f4: ldr             x8, [PP, #0x3238]  ; [pp+0x3238] Type: Map<Object?, Object?>
    // 0x8502f8: r3 = Null
    //     0x8502f8: add             x3, PP, #0x84, lsl #12  ; [pp+0x84d48] Null
    //     0x8502fc: ldr             x3, [x3, #0xd48]
    // 0x850300: r0 = Map<Object?, Object?>()
    //     0x850300: bl              #0x851560  ; IsType_Map<Object?, Object?>_Stub
    // 0x850304: ldur            x0, [fp, #-8]
    // 0x850308: LeaveFrame
    //     0x850308: mov             SP, fp
    //     0x85030c: ldp             fp, lr, [SP], #0x10
    // 0x850310: ret
    //     0x850310: ret             
    // 0x850314: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x850314: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x850318: b               #0x85028c
    // 0x85031c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x85031c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Map<Object?, Object?> <anonymous closure>(dynamic) {
    // ** addr: 0x850320, size: 0x3c
    // 0x850320: EnterFrame
    //     0x850320: stp             fp, lr, [SP, #-0x10]!
    //     0x850324: mov             fp, SP
    // 0x850328: AllocStack(0x10)
    //     0x850328: sub             SP, SP, #0x10
    // 0x85032c: CheckStackOverflow
    //     0x85032c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x850330: cmp             SP, x16
    //     0x850334: b.ls            #0x850354
    // 0x850338: r16 = <Object?, Object?>
    //     0x850338: ldr             x16, [PP, #0x4250]  ; [pp+0x4250] TypeArguments: <Object?, Object?>
    // 0x85033c: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x850340: stp             lr, x16, [SP]
    // 0x850344: r0 = Map._fromLiteral()
    //     0x850344: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x850348: LeaveFrame
    //     0x850348: mov             SP, fp
    //     0x85034c: ldp             fp, lr, [SP], #0x10
    // 0x850350: ret
    //     0x850350: ret             
    // 0x850354: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x850354: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x850358: b               #0x850338
  }
  _ _updateManager(/* No info */) {
    // ** addr: 0x85037c, size: 0xc4
    // 0x85037c: EnterFrame
    //     0x85037c: stp             fp, lr, [SP, #-0x10]!
    //     0x850380: mov             fp, SP
    // 0x850384: AllocStack(0x10)
    //     0x850384: sub             SP, SP, #0x10
    // 0x850388: SetupParameters(RestorationBucket this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x850388: mov             x3, x1
    //     0x85038c: mov             x0, x2
    //     0x850390: stur            x1, [fp, #-8]
    //     0x850394: stur            x2, [fp, #-0x10]
    // 0x850398: CheckStackOverflow
    //     0x850398: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x85039c: cmp             SP, x16
    //     0x8503a0: b.ls            #0x850438
    // 0x8503a4: LoadField: r1 = r3->field_b
    //     0x8503a4: ldur            w1, [x3, #0xb]
    // 0x8503a8: DecompressPointer r1
    //     0x8503a8: add             x1, x1, HEAP, lsl #32
    // 0x8503ac: cmp             w1, w0
    // 0x8503b0: b.ne            #0x8503c4
    // 0x8503b4: r0 = Null
    //     0x8503b4: mov             x0, NULL
    // 0x8503b8: LeaveFrame
    //     0x8503b8: mov             SP, fp
    //     0x8503bc: ldp             fp, lr, [SP], #0x10
    // 0x8503c0: ret
    //     0x8503c0: ret             
    // 0x8503c4: LoadField: r2 = r3->field_1f
    //     0x8503c4: ldur            w2, [x3, #0x1f]
    // 0x8503c8: DecompressPointer r2
    //     0x8503c8: add             x2, x2, HEAP, lsl #32
    // 0x8503cc: tbnz            w2, #4, #0x8503e0
    // 0x8503d0: cmp             w1, NULL
    // 0x8503d4: b.eq            #0x8503e0
    // 0x8503d8: mov             x2, x3
    // 0x8503dc: r0 = unscheduleSerializationFor()
    //     0x8503dc: bl              #0x850828  ; [package:flutter/src/services/restoration.dart] RestorationManager::unscheduleSerializationFor
    // 0x8503e0: ldur            x1, [fp, #-8]
    // 0x8503e4: ldur            x0, [fp, #-0x10]
    // 0x8503e8: StoreField: r1->field_b = r0
    //     0x8503e8: stur            w0, [x1, #0xb]
    //     0x8503ec: ldurb           w16, [x1, #-1]
    //     0x8503f0: ldurb           w17, [x0, #-1]
    //     0x8503f4: and             x16, x17, x16, lsr #2
    //     0x8503f8: tst             x16, HEAP, lsr #32
    //     0x8503fc: b.eq            #0x850404
    //     0x850400: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x850404: LoadField: r0 = r1->field_1f
    //     0x850404: ldur            w0, [x1, #0x1f]
    // 0x850408: DecompressPointer r0
    //     0x850408: add             x0, x0, HEAP, lsl #32
    // 0x85040c: tbnz            w0, #4, #0x850428
    // 0x850410: ldur            x0, [fp, #-0x10]
    // 0x850414: cmp             w0, NULL
    // 0x850418: b.eq            #0x850428
    // 0x85041c: r0 = false
    //     0x85041c: add             x0, NULL, #0x30  ; false
    // 0x850420: StoreField: r1->field_1f = r0
    //     0x850420: stur            w0, [x1, #0x1f]
    // 0x850424: r0 = _markNeedsSerialization()
    //     0x850424: bl              #0x850440  ; [package:flutter/src/services/restoration.dart] RestorationBucket::_markNeedsSerialization
    // 0x850428: r0 = Null
    //     0x850428: mov             x0, NULL
    // 0x85042c: LeaveFrame
    //     0x85042c: mov             SP, fp
    //     0x850430: ldp             fp, lr, [SP], #0x10
    // 0x850434: ret
    //     0x850434: ret             
    // 0x850438: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x850438: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x85043c: b               #0x8503a4
  }
  _ _markNeedsSerialization(/* No info */) {
    // ** addr: 0x850440, size: 0x58
    // 0x850440: EnterFrame
    //     0x850440: stp             fp, lr, [SP, #-0x10]!
    //     0x850444: mov             fp, SP
    // 0x850448: mov             x2, x1
    // 0x85044c: CheckStackOverflow
    //     0x85044c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x850450: cmp             SP, x16
    //     0x850454: b.ls            #0x850490
    // 0x850458: LoadField: r0 = r2->field_1f
    //     0x850458: ldur            w0, [x2, #0x1f]
    // 0x85045c: DecompressPointer r0
    //     0x85045c: add             x0, x0, HEAP, lsl #32
    // 0x850460: tbz             w0, #4, #0x850480
    // 0x850464: r0 = true
    //     0x850464: add             x0, NULL, #0x20  ; true
    // 0x850468: StoreField: r2->field_1f = r0
    //     0x850468: stur            w0, [x2, #0x1f]
    // 0x85046c: LoadField: r1 = r2->field_b
    //     0x85046c: ldur            w1, [x2, #0xb]
    // 0x850470: DecompressPointer r1
    //     0x850470: add             x1, x1, HEAP, lsl #32
    // 0x850474: cmp             w1, NULL
    // 0x850478: b.eq            #0x850480
    // 0x85047c: r0 = scheduleSerializationFor()
    //     0x85047c: bl              #0x850498  ; [package:flutter/src/services/restoration.dart] RestorationManager::scheduleSerializationFor
    // 0x850480: r0 = Null
    //     0x850480: mov             x0, NULL
    // 0x850484: LeaveFrame
    //     0x850484: mov             SP, fp
    //     0x850488: ldp             fp, lr, [SP], #0x10
    // 0x85048c: ret
    //     0x85048c: ret             
    // 0x850490: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x850490: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x850494: b               #0x850458
  }
  _ _removeChildData(/* No info */) {
    // ** addr: 0x850864, size: 0x374
    // 0x850864: EnterFrame
    //     0x850864: stp             fp, lr, [SP, #-0x10]!
    //     0x850868: mov             fp, SP
    // 0x85086c: AllocStack(0x28)
    //     0x85086c: sub             SP, SP, #0x28
    // 0x850870: SetupParameters(RestorationBucket this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x850870: mov             x3, x1
    //     0x850874: mov             x0, x2
    //     0x850878: stur            x1, [fp, #-8]
    //     0x85087c: stur            x2, [fp, #-0x10]
    // 0x850880: CheckStackOverflow
    //     0x850880: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x850884: cmp             SP, x16
    //     0x850888: b.ls            #0x850bc8
    // 0x85088c: ArrayLoad: r1 = r3[0]  ; List_4
    //     0x85088c: ldur            w1, [x3, #0x17]
    // 0x850890: DecompressPointer r1
    //     0x850890: add             x1, x1, HEAP, lsl #32
    // 0x850894: LoadField: r2 = r0->field_13
    //     0x850894: ldur            w2, [x0, #0x13]
    // 0x850898: DecompressPointer r2
    //     0x850898: add             x2, x2, HEAP, lsl #32
    // 0x85089c: r0 = remove()
    //     0x85089c: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x8508a0: mov             x1, x0
    // 0x8508a4: ldur            x0, [fp, #-0x10]
    // 0x8508a8: cmp             w1, w0
    // 0x8508ac: b.ne            #0x850ac4
    // 0x8508b0: ldur            x3, [fp, #-8]
    // 0x8508b4: LoadField: r4 = r3->field_7
    //     0x8508b4: ldur            w4, [x3, #7]
    // 0x8508b8: DecompressPointer r4
    //     0x8508b8: add             x4, x4, HEAP, lsl #32
    // 0x8508bc: stur            x4, [fp, #-0x18]
    // 0x8508c0: r1 = Function '<anonymous closure>':.
    //     0x8508c0: ldr             x1, [PP, #0x4220]  ; [pp+0x4220] AnonymousClosure: (0x850320), of [package:flutter/src/services/restoration.dart] RestorationBucket
    // 0x8508c4: r2 = Null
    //     0x8508c4: mov             x2, NULL
    // 0x8508c8: r0 = AllocateClosure()
    //     0x8508c8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8508cc: ldur            x4, [fp, #-0x18]
    // 0x8508d0: r1 = LoadClassIdInstr(r4)
    //     0x8508d0: ldur            x1, [x4, #-1]
    //     0x8508d4: ubfx            x1, x1, #0xc, #0x14
    // 0x8508d8: mov             x3, x0
    // 0x8508dc: mov             x0, x1
    // 0x8508e0: mov             x1, x4
    // 0x8508e4: r2 = "c"
    //     0x8508e4: ldr             x2, [PP, #0x4228]  ; [pp+0x4228] "c"
    // 0x8508e8: r0 = GDT[cid_x0 + 0x1688c]()
    //     0x8508e8: mov             x17, #0x688c
    //     0x8508ec: movk            x17, #1, lsl #16
    //     0x8508f0: add             lr, x0, x17
    //     0x8508f4: ldr             lr, [x21, lr, lsl #3]
    //     0x8508f8: blr             lr
    // 0x8508fc: mov             x3, x0
    // 0x850900: stur            x3, [fp, #-0x20]
    // 0x850904: cmp             w3, NULL
    // 0x850908: b.eq            #0x850bd0
    // 0x85090c: mov             x0, x3
    // 0x850910: r2 = Null
    //     0x850910: mov             x2, NULL
    // 0x850914: r1 = Null
    //     0x850914: mov             x1, NULL
    // 0x850918: r8 = Map<Object?, Object?>
    //     0x850918: ldr             x8, [PP, #0x3238]  ; [pp+0x3238] Type: Map<Object?, Object?>
    // 0x85091c: r3 = Null
    //     0x85091c: ldr             x3, [PP, #0x4230]  ; [pp+0x4230] Null
    // 0x850920: r0 = Map<Object?, Object?>()
    //     0x850920: bl              #0x851560  ; IsType_Map<Object?, Object?>_Stub
    // 0x850924: ldur            x3, [fp, #-0x10]
    // 0x850928: LoadField: r2 = r3->field_13
    //     0x850928: ldur            w2, [x3, #0x13]
    // 0x85092c: DecompressPointer r2
    //     0x85092c: add             x2, x2, HEAP, lsl #32
    // 0x850930: ldur            x1, [fp, #-0x20]
    // 0x850934: r0 = LoadClassIdInstr(r1)
    //     0x850934: ldur            x0, [x1, #-1]
    //     0x850938: ubfx            x0, x0, #0xc, #0x14
    // 0x85093c: r0 = GDT[cid_x0 + 0x129dd]()
    //     0x85093c: mov             x17, #0x29dd
    //     0x850940: movk            x17, #1, lsl #16
    //     0x850944: add             lr, x0, x17
    //     0x850948: ldr             lr, [x21, lr, lsl #3]
    //     0x85094c: blr             lr
    // 0x850950: ldur            x0, [fp, #-8]
    // 0x850954: LoadField: r3 = r0->field_1b
    //     0x850954: ldur            w3, [x0, #0x1b]
    // 0x850958: DecompressPointer r3
    //     0x850958: add             x3, x3, HEAP, lsl #32
    // 0x85095c: ldur            x4, [fp, #-0x10]
    // 0x850960: stur            x3, [fp, #-0x20]
    // 0x850964: LoadField: r2 = r4->field_13
    //     0x850964: ldur            w2, [x4, #0x13]
    // 0x850968: DecompressPointer r2
    //     0x850968: add             x2, x2, HEAP, lsl #32
    // 0x85096c: mov             x1, x3
    // 0x850970: r0 = _getValueOrData()
    //     0x850970: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x850974: ldur            x2, [fp, #-0x20]
    // 0x850978: LoadField: r1 = r2->field_f
    //     0x850978: ldur            w1, [x2, #0xf]
    // 0x85097c: DecompressPointer r1
    //     0x85097c: add             x1, x1, HEAP, lsl #32
    // 0x850980: cmp             w1, w0
    // 0x850984: b.ne            #0x850990
    // 0x850988: r3 = Null
    //     0x850988: mov             x3, NULL
    // 0x85098c: b               #0x850994
    // 0x850990: mov             x3, x0
    // 0x850994: stur            x3, [fp, #-0x28]
    // 0x850998: cmp             w3, NULL
    // 0x85099c: b.eq            #0x850a04
    // 0x8509a0: r0 = LoadClassIdInstr(r3)
    //     0x8509a0: ldur            x0, [x3, #-1]
    //     0x8509a4: ubfx            x0, x0, #0xc, #0x14
    // 0x8509a8: mov             x1, x3
    // 0x8509ac: r0 = GDT[cid_x0 + 0x17d02]()
    //     0x8509ac: mov             x17, #0x7d02
    //     0x8509b0: movk            x17, #1, lsl #16
    //     0x8509b4: add             lr, x0, x17
    //     0x8509b8: ldr             lr, [x21, lr, lsl #3]
    //     0x8509bc: blr             lr
    // 0x8509c0: ldur            x1, [fp, #-8]
    // 0x8509c4: mov             x2, x0
    // 0x8509c8: r0 = _finalizeAddChildData()
    //     0x8509c8: bl              #0x850bd8  ; [package:flutter/src/services/restoration.dart] RestorationBucket::_finalizeAddChildData
    // 0x8509cc: ldur            x1, [fp, #-0x28]
    // 0x8509d0: r0 = LoadClassIdInstr(r1)
    //     0x8509d0: ldur            x0, [x1, #-1]
    //     0x8509d4: ubfx            x0, x0, #0xc, #0x14
    // 0x8509d8: r0 = GDT[cid_x0 + 0x12b36]()
    //     0x8509d8: mov             x17, #0x2b36
    //     0x8509dc: movk            x17, #1, lsl #16
    //     0x8509e0: add             lr, x0, x17
    //     0x8509e4: ldr             lr, [x21, lr, lsl #3]
    //     0x8509e8: blr             lr
    // 0x8509ec: tbnz            w0, #4, #0x850a04
    // 0x8509f0: ldur            x0, [fp, #-0x10]
    // 0x8509f4: LoadField: r2 = r0->field_13
    //     0x8509f4: ldur            w2, [x0, #0x13]
    // 0x8509f8: DecompressPointer r2
    //     0x8509f8: add             x2, x2, HEAP, lsl #32
    // 0x8509fc: ldur            x1, [fp, #-0x20]
    // 0x850a00: r0 = remove()
    //     0x850a00: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x850a04: ldur            x0, [fp, #-0x18]
    // 0x850a08: r1 = Function '<anonymous closure>':.
    //     0x850a08: ldr             x1, [PP, #0x4220]  ; [pp+0x4220] AnonymousClosure: (0x850320), of [package:flutter/src/services/restoration.dart] RestorationBucket
    // 0x850a0c: r2 = Null
    //     0x850a0c: mov             x2, NULL
    // 0x850a10: r0 = AllocateClosure()
    //     0x850a10: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x850a14: ldur            x4, [fp, #-0x18]
    // 0x850a18: r1 = LoadClassIdInstr(r4)
    //     0x850a18: ldur            x1, [x4, #-1]
    //     0x850a1c: ubfx            x1, x1, #0xc, #0x14
    // 0x850a20: mov             x3, x0
    // 0x850a24: mov             x0, x1
    // 0x850a28: mov             x1, x4
    // 0x850a2c: r2 = "c"
    //     0x850a2c: ldr             x2, [PP, #0x4228]  ; [pp+0x4228] "c"
    // 0x850a30: r0 = GDT[cid_x0 + 0x1688c]()
    //     0x850a30: mov             x17, #0x688c
    //     0x850a34: movk            x17, #1, lsl #16
    //     0x850a38: add             lr, x0, x17
    //     0x850a3c: ldr             lr, [x21, lr, lsl #3]
    //     0x850a40: blr             lr
    // 0x850a44: mov             x3, x0
    // 0x850a48: stur            x3, [fp, #-0x20]
    // 0x850a4c: cmp             w3, NULL
    // 0x850a50: b.eq            #0x850bd4
    // 0x850a54: mov             x0, x3
    // 0x850a58: r2 = Null
    //     0x850a58: mov             x2, NULL
    // 0x850a5c: r1 = Null
    //     0x850a5c: mov             x1, NULL
    // 0x850a60: r8 = Map<Object?, Object?>
    //     0x850a60: ldr             x8, [PP, #0x3238]  ; [pp+0x3238] Type: Map<Object?, Object?>
    // 0x850a64: r3 = Null
    //     0x850a64: ldr             x3, [PP, #0x4240]  ; [pp+0x4240] Null
    // 0x850a68: r0 = Map<Object?, Object?>()
    //     0x850a68: bl              #0x851560  ; IsType_Map<Object?, Object?>_Stub
    // 0x850a6c: ldur            x1, [fp, #-0x20]
    // 0x850a70: r0 = LoadClassIdInstr(r1)
    //     0x850a70: ldur            x0, [x1, #-1]
    //     0x850a74: ubfx            x0, x0, #0xc, #0x14
    // 0x850a78: r0 = GDT[cid_x0 + 0x687]()
    //     0x850a78: add             lr, x0, #0x687
    //     0x850a7c: ldr             lr, [x21, lr, lsl #3]
    //     0x850a80: blr             lr
    // 0x850a84: tbnz            w0, #4, #0x850aac
    // 0x850a88: ldur            x1, [fp, #-0x18]
    // 0x850a8c: r0 = LoadClassIdInstr(r1)
    //     0x850a8c: ldur            x0, [x1, #-1]
    //     0x850a90: ubfx            x0, x0, #0xc, #0x14
    // 0x850a94: r2 = "c"
    //     0x850a94: ldr             x2, [PP, #0x4228]  ; [pp+0x4228] "c"
    // 0x850a98: r0 = GDT[cid_x0 + 0x129dd]()
    //     0x850a98: mov             x17, #0x29dd
    //     0x850a9c: movk            x17, #1, lsl #16
    //     0x850aa0: add             lr, x0, x17
    //     0x850aa4: ldr             lr, [x21, lr, lsl #3]
    //     0x850aa8: blr             lr
    // 0x850aac: ldur            x1, [fp, #-8]
    // 0x850ab0: r0 = _markNeedsSerialization()
    //     0x850ab0: bl              #0x850440  ; [package:flutter/src/services/restoration.dart] RestorationBucket::_markNeedsSerialization
    // 0x850ab4: r0 = Null
    //     0x850ab4: mov             x0, NULL
    // 0x850ab8: LeaveFrame
    //     0x850ab8: mov             SP, fp
    //     0x850abc: ldp             fp, lr, [SP], #0x10
    // 0x850ac0: ret
    //     0x850ac0: ret             
    // 0x850ac4: ldur            x1, [fp, #-8]
    // 0x850ac8: LoadField: r3 = r1->field_1b
    //     0x850ac8: ldur            w3, [x1, #0x1b]
    // 0x850acc: DecompressPointer r3
    //     0x850acc: add             x3, x3, HEAP, lsl #32
    // 0x850ad0: stur            x3, [fp, #-0x18]
    // 0x850ad4: LoadField: r2 = r0->field_13
    //     0x850ad4: ldur            w2, [x0, #0x13]
    // 0x850ad8: DecompressPointer r2
    //     0x850ad8: add             x2, x2, HEAP, lsl #32
    // 0x850adc: mov             x1, x3
    // 0x850ae0: r0 = _getValueOrData()
    //     0x850ae0: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x850ae4: ldur            x3, [fp, #-0x18]
    // 0x850ae8: LoadField: r1 = r3->field_f
    //     0x850ae8: ldur            w1, [x3, #0xf]
    // 0x850aec: DecompressPointer r1
    //     0x850aec: add             x1, x1, HEAP, lsl #32
    // 0x850af0: cmp             w1, w0
    // 0x850af4: b.ne            #0x850b00
    // 0x850af8: r1 = Null
    //     0x850af8: mov             x1, NULL
    // 0x850afc: b               #0x850b04
    // 0x850b00: mov             x1, x0
    // 0x850b04: cmp             w1, NULL
    // 0x850b08: b.ne            #0x850b14
    // 0x850b0c: mov             x0, x3
    // 0x850b10: b               #0x850b38
    // 0x850b14: r0 = LoadClassIdInstr(r1)
    //     0x850b14: ldur            x0, [x1, #-1]
    //     0x850b18: ubfx            x0, x0, #0xc, #0x14
    // 0x850b1c: ldur            x2, [fp, #-0x10]
    // 0x850b20: r0 = GDT[cid_x0 + 0x17972]()
    //     0x850b20: mov             x17, #0x7972
    //     0x850b24: movk            x17, #1, lsl #16
    //     0x850b28: add             lr, x0, x17
    //     0x850b2c: ldr             lr, [x21, lr, lsl #3]
    //     0x850b30: blr             lr
    // 0x850b34: ldur            x0, [fp, #-0x18]
    // 0x850b38: ldur            x3, [fp, #-0x10]
    // 0x850b3c: LoadField: r2 = r3->field_13
    //     0x850b3c: ldur            w2, [x3, #0x13]
    // 0x850b40: DecompressPointer r2
    //     0x850b40: add             x2, x2, HEAP, lsl #32
    // 0x850b44: mov             x1, x0
    // 0x850b48: r0 = _getValueOrData()
    //     0x850b48: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x850b4c: ldur            x2, [fp, #-0x18]
    // 0x850b50: LoadField: r1 = r2->field_f
    //     0x850b50: ldur            w1, [x2, #0xf]
    // 0x850b54: DecompressPointer r1
    //     0x850b54: add             x1, x1, HEAP, lsl #32
    // 0x850b58: cmp             w1, w0
    // 0x850b5c: b.ne            #0x850b68
    // 0x850b60: r1 = Null
    //     0x850b60: mov             x1, NULL
    // 0x850b64: b               #0x850b6c
    // 0x850b68: mov             x1, x0
    // 0x850b6c: cmp             w1, NULL
    // 0x850b70: b.ne            #0x850b7c
    // 0x850b74: r0 = Null
    //     0x850b74: mov             x0, NULL
    // 0x850b78: b               #0x850b98
    // 0x850b7c: r0 = LoadClassIdInstr(r1)
    //     0x850b7c: ldur            x0, [x1, #-1]
    //     0x850b80: ubfx            x0, x0, #0xc, #0x14
    // 0x850b84: r0 = GDT[cid_x0 + 0x12b36]()
    //     0x850b84: mov             x17, #0x2b36
    //     0x850b88: movk            x17, #1, lsl #16
    //     0x850b8c: add             lr, x0, x17
    //     0x850b90: ldr             lr, [x21, lr, lsl #3]
    //     0x850b94: blr             lr
    // 0x850b98: cmp             w0, NULL
    // 0x850b9c: b.eq            #0x850bb8
    // 0x850ba0: tbnz            w0, #4, #0x850bb8
    // 0x850ba4: ldur            x0, [fp, #-0x10]
    // 0x850ba8: LoadField: r2 = r0->field_13
    //     0x850ba8: ldur            w2, [x0, #0x13]
    // 0x850bac: DecompressPointer r2
    //     0x850bac: add             x2, x2, HEAP, lsl #32
    // 0x850bb0: ldur            x1, [fp, #-0x18]
    // 0x850bb4: r0 = remove()
    //     0x850bb4: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x850bb8: r0 = Null
    //     0x850bb8: mov             x0, NULL
    // 0x850bbc: LeaveFrame
    //     0x850bbc: mov             SP, fp
    //     0x850bc0: ldp             fp, lr, [SP], #0x10
    // 0x850bc4: ret
    //     0x850bc4: ret             
    // 0x850bc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x850bc8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x850bcc: b               #0x85088c
    // 0x850bd0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x850bd0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x850bd4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x850bd4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _finalizeAddChildData(/* No info */) {
    // ** addr: 0x850bd8, size: 0x130
    // 0x850bd8: EnterFrame
    //     0x850bd8: stp             fp, lr, [SP, #-0x10]!
    //     0x850bdc: mov             fp, SP
    // 0x850be0: AllocStack(0x20)
    //     0x850be0: sub             SP, SP, #0x20
    // 0x850be4: SetupParameters(RestorationBucket this /* r1 => r0, fp-0x18 */, dynamic _ /* r2 => r3, fp-0x20 */)
    //     0x850be4: mov             x0, x1
    //     0x850be8: mov             x3, x2
    //     0x850bec: stur            x1, [fp, #-0x18]
    //     0x850bf0: stur            x2, [fp, #-0x20]
    // 0x850bf4: CheckStackOverflow
    //     0x850bf4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x850bf8: cmp             SP, x16
    //     0x850bfc: b.ls            #0x850cfc
    // 0x850c00: ArrayLoad: r4 = r0[0]  ; List_4
    //     0x850c00: ldur            w4, [x0, #0x17]
    // 0x850c04: DecompressPointer r4
    //     0x850c04: add             x4, x4, HEAP, lsl #32
    // 0x850c08: stur            x4, [fp, #-0x10]
    // 0x850c0c: LoadField: r5 = r3->field_13
    //     0x850c0c: ldur            w5, [x3, #0x13]
    // 0x850c10: DecompressPointer r5
    //     0x850c10: add             x5, x5, HEAP, lsl #32
    // 0x850c14: mov             x1, x4
    // 0x850c18: mov             x2, x5
    // 0x850c1c: stur            x5, [fp, #-8]
    // 0x850c20: r0 = _hashCode()
    //     0x850c20: bl              #0x13d8cbc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0x850c24: mov             x2, x0
    // 0x850c28: r0 = BoxInt64Instr(r2)
    //     0x850c28: sbfiz           x0, x2, #1, #0x1f
    //     0x850c2c: cmp             x2, x0, asr #1
    //     0x850c30: b.eq            #0x850c3c
    //     0x850c34: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x850c38: stur            x2, [x0, #7]
    // 0x850c3c: ldur            x1, [fp, #-0x10]
    // 0x850c40: ldur            x2, [fp, #-8]
    // 0x850c44: ldur            x3, [fp, #-0x20]
    // 0x850c48: mov             x5, x0
    // 0x850c4c: r0 = _set()
    //     0x850c4c: bl              #0x13d8170  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x850c50: ldur            x0, [fp, #-0x18]
    // 0x850c54: LoadField: r3 = r0->field_7
    //     0x850c54: ldur            w3, [x0, #7]
    // 0x850c58: DecompressPointer r3
    //     0x850c58: add             x3, x3, HEAP, lsl #32
    // 0x850c5c: stur            x3, [fp, #-8]
    // 0x850c60: r1 = Function '<anonymous closure>':.
    //     0x850c60: ldr             x1, [PP, #0x4220]  ; [pp+0x4220] AnonymousClosure: (0x850320), of [package:flutter/src/services/restoration.dart] RestorationBucket
    // 0x850c64: r2 = Null
    //     0x850c64: mov             x2, NULL
    // 0x850c68: r0 = AllocateClosure()
    //     0x850c68: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x850c6c: ldur            x1, [fp, #-8]
    // 0x850c70: r2 = LoadClassIdInstr(r1)
    //     0x850c70: ldur            x2, [x1, #-1]
    //     0x850c74: ubfx            x2, x2, #0xc, #0x14
    // 0x850c78: mov             x3, x0
    // 0x850c7c: mov             x0, x2
    // 0x850c80: r2 = "c"
    //     0x850c80: ldr             x2, [PP, #0x4228]  ; [pp+0x4228] "c"
    // 0x850c84: r0 = GDT[cid_x0 + 0x1688c]()
    //     0x850c84: mov             x17, #0x688c
    //     0x850c88: movk            x17, #1, lsl #16
    //     0x850c8c: add             lr, x0, x17
    //     0x850c90: ldr             lr, [x21, lr, lsl #3]
    //     0x850c94: blr             lr
    // 0x850c98: mov             x3, x0
    // 0x850c9c: stur            x3, [fp, #-8]
    // 0x850ca0: cmp             w3, NULL
    // 0x850ca4: b.eq            #0x850d04
    // 0x850ca8: mov             x0, x3
    // 0x850cac: r2 = Null
    //     0x850cac: mov             x2, NULL
    // 0x850cb0: r1 = Null
    //     0x850cb0: mov             x1, NULL
    // 0x850cb4: r8 = Map<Object?, Object?>
    //     0x850cb4: ldr             x8, [PP, #0x3238]  ; [pp+0x3238] Type: Map<Object?, Object?>
    // 0x850cb8: r3 = Null
    //     0x850cb8: ldr             x3, [PP, #0x4258]  ; [pp+0x4258] Null
    // 0x850cbc: r0 = Map<Object?, Object?>()
    //     0x850cbc: bl              #0x851560  ; IsType_Map<Object?, Object?>_Stub
    // 0x850cc0: ldur            x0, [fp, #-0x20]
    // 0x850cc4: LoadField: r2 = r0->field_13
    //     0x850cc4: ldur            w2, [x0, #0x13]
    // 0x850cc8: DecompressPointer r2
    //     0x850cc8: add             x2, x2, HEAP, lsl #32
    // 0x850ccc: LoadField: r3 = r0->field_7
    //     0x850ccc: ldur            w3, [x0, #7]
    // 0x850cd0: DecompressPointer r3
    //     0x850cd0: add             x3, x3, HEAP, lsl #32
    // 0x850cd4: ldur            x1, [fp, #-8]
    // 0x850cd8: r0 = LoadClassIdInstr(r1)
    //     0x850cd8: ldur            x0, [x1, #-1]
    //     0x850cdc: ubfx            x0, x0, #0xc, #0x14
    // 0x850ce0: r0 = GDT[cid_x0 + -0xd50]()
    //     0x850ce0: sub             lr, x0, #0xd50
    //     0x850ce4: ldr             lr, [x21, lr, lsl #3]
    //     0x850ce8: blr             lr
    // 0x850cec: r0 = Null
    //     0x850cec: mov             x0, NULL
    // 0x850cf0: LeaveFrame
    //     0x850cf0: mov             SP, fp
    //     0x850cf4: ldp             fp, lr, [SP], #0x10
    // 0x850cf8: ret
    //     0x850cf8: ret             
    // 0x850cfc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x850cfc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x850d00: b               #0x850c00
    // 0x850d04: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x850d04: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _visitChildren(/* No info */) {
    // ** addr: 0x850d08, size: 0x138
    // 0x850d08: EnterFrame
    //     0x850d08: stp             fp, lr, [SP, #-0x10]!
    //     0x850d0c: mov             fp, SP
    // 0x850d10: AllocStack(0x40)
    //     0x850d10: sub             SP, SP, #0x40
    // 0x850d14: SetupParameters(RestorationBucket this /* r1 => r0, fp-0x18 */, dynamic _ /* r2 => r2, fp-0x20 */, {dynamic concurrentModification = false /* r3, fp-0x10 */})
    //     0x850d14: mov             x0, x1
    //     0x850d18: stur            x1, [fp, #-0x18]
    //     0x850d1c: stur            x2, [fp, #-0x20]
    //     0x850d20: ldur            w1, [x4, #0x13]
    //     0x850d24: ldur            w3, [x4, #0x1f]
    //     0x850d28: add             x3, x3, HEAP, lsl #32
    //     0x850d2c: ldr             x16, [PP, #0x4268]  ; [pp+0x4268] "concurrentModification"
    //     0x850d30: cmp             w3, w16
    //     0x850d34: b.ne            #0x850d54
    //     0x850d38: ldur            w3, [x4, #0x23]
    //     0x850d3c: add             x3, x3, HEAP, lsl #32
    //     0x850d40: sub             w4, w1, w3
    //     0x850d44: add             x1, fp, w4, sxtw #2
    //     0x850d48: ldr             x1, [x1, #8]
    //     0x850d4c: mov             x3, x1
    //     0x850d50: b               #0x850d58
    //     0x850d54: add             x3, NULL, #0x30  ; false
    //     0x850d58: stur            x3, [fp, #-0x10]
    // 0x850d5c: CheckStackOverflow
    //     0x850d5c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x850d60: cmp             SP, x16
    //     0x850d64: b.ls            #0x850e38
    // 0x850d68: ArrayLoad: r4 = r0[0]  ; List_4
    //     0x850d68: ldur            w4, [x0, #0x17]
    // 0x850d6c: DecompressPointer r4
    //     0x850d6c: add             x4, x4, HEAP, lsl #32
    // 0x850d70: stur            x4, [fp, #-8]
    // 0x850d74: r1 = <RestorationBucket>
    //     0x850d74: ldr             x1, [PP, #0x4140]  ; [pp+0x4140] TypeArguments: <RestorationBucket>
    // 0x850d78: r0 = _CompactValuesIterable()
    //     0x850d78: bl              #0x7f3fb4  ; Allocate_CompactValuesIterableStub -> _CompactValuesIterable<X0> (size=0x10)
    // 0x850d7c: mov             x2, x0
    // 0x850d80: ldur            x0, [fp, #-8]
    // 0x850d84: stur            x2, [fp, #-0x28]
    // 0x850d88: StoreField: r2->field_b = r0
    //     0x850d88: stur            w0, [x2, #0xb]
    // 0x850d8c: ldur            x0, [fp, #-0x18]
    // 0x850d90: LoadField: r3 = r0->field_1b
    //     0x850d90: ldur            w3, [x0, #0x1b]
    // 0x850d94: DecompressPointer r3
    //     0x850d94: add             x3, x3, HEAP, lsl #32
    // 0x850d98: stur            x3, [fp, #-8]
    // 0x850d9c: r1 = <List<RestorationBucket>>
    //     0x850d9c: ldr             x1, [PP, #0x4270]  ; [pp+0x4270] TypeArguments: <List<RestorationBucket>>
    // 0x850da0: r0 = _CompactValuesIterable()
    //     0x850da0: bl              #0x7f3fb4  ; Allocate_CompactValuesIterableStub -> _CompactValuesIterable<X0> (size=0x10)
    // 0x850da4: mov             x3, x0
    // 0x850da8: ldur            x0, [fp, #-8]
    // 0x850dac: stur            x3, [fp, #-0x18]
    // 0x850db0: StoreField: r3->field_b = r0
    //     0x850db0: stur            w0, [x3, #0xb]
    // 0x850db4: r1 = Function '<anonymous closure>':.
    //     0x850db4: ldr             x1, [PP, #0x4278]  ; [pp+0x4278] AnonymousClosure: (0x13dae90), in [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::_mergeSiblingGroup (0x891814)
    // 0x850db8: r2 = Null
    //     0x850db8: mov             x2, NULL
    // 0x850dbc: r0 = AllocateClosure()
    //     0x850dbc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x850dc0: r16 = <RestorationBucket>
    //     0x850dc0: ldr             x16, [PP, #0x4140]  ; [pp+0x4140] TypeArguments: <RestorationBucket>
    // 0x850dc4: ldur            lr, [fp, #-0x18]
    // 0x850dc8: stp             lr, x16, [SP, #8]
    // 0x850dcc: str             x0, [SP]
    // 0x850dd0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x850dd0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x850dd4: r0 = expand()
    //     0x850dd4: bl              #0x851010  ; [dart:core] Iterable::expand
    // 0x850dd8: ldur            x1, [fp, #-0x28]
    // 0x850ddc: mov             x2, x0
    // 0x850de0: r0 = followedBy()
    //     0x850de0: bl              #0x850e40  ; [dart:core] Iterable::followedBy
    // 0x850de4: mov             x1, x0
    // 0x850de8: ldur            x0, [fp, #-0x10]
    // 0x850dec: tbnz            w0, #4, #0x850e08
    // 0x850df0: LoadField: r0 = r1->field_7
    //     0x850df0: ldur            w0, [x1, #7]
    // 0x850df4: DecompressPointer r0
    //     0x850df4: add             x0, x0, HEAP, lsl #32
    // 0x850df8: mov             x2, x1
    // 0x850dfc: mov             x1, x0
    // 0x850e00: r0 = _List.of()
    //     0x850e00: bl              #0x7d8e04  ; [dart:core] _List::_List.of
    // 0x850e04: mov             x1, x0
    // 0x850e08: r0 = LoadClassIdInstr(r1)
    //     0x850e08: ldur            x0, [x1, #-1]
    //     0x850e0c: ubfx            x0, x0, #0xc, #0x14
    // 0x850e10: ldur            x2, [fp, #-0x20]
    // 0x850e14: r0 = GDT[cid_x0 + 0x12d45]()
    //     0x850e14: mov             x17, #0x2d45
    //     0x850e18: movk            x17, #1, lsl #16
    //     0x850e1c: add             lr, x0, x17
    //     0x850e20: ldr             lr, [x21, lr, lsl #3]
    //     0x850e24: blr             lr
    // 0x850e28: r0 = Null
    //     0x850e28: mov             x0, NULL
    // 0x850e2c: LeaveFrame
    //     0x850e2c: mov             SP, fp
    //     0x850e30: ldp             fp, lr, [SP], #0x10
    // 0x850e34: ret
    //     0x850e34: ret             
    // 0x850e38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x850e38: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x850e3c: b               #0x850d68
  }
  [closure] void _dropChild(dynamic, RestorationBucket) {
    // ** addr: 0x851130, size: 0x3c
    // 0x851130: EnterFrame
    //     0x851130: stp             fp, lr, [SP, #-0x10]!
    //     0x851134: mov             fp, SP
    // 0x851138: ldr             x0, [fp, #0x18]
    // 0x85113c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x85113c: ldur            w1, [x0, #0x17]
    // 0x851140: DecompressPointer r1
    //     0x851140: add             x1, x1, HEAP, lsl #32
    // 0x851144: CheckStackOverflow
    //     0x851144: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x851148: cmp             SP, x16
    //     0x85114c: b.ls            #0x851164
    // 0x851150: ldr             x2, [fp, #0x10]
    // 0x851154: r0 = _dropChild()
    //     0x851154: bl              #0x85116c  ; [package:flutter/src/services/restoration.dart] RestorationBucket::_dropChild
    // 0x851158: LeaveFrame
    //     0x851158: mov             SP, fp
    //     0x85115c: ldp             fp, lr, [SP], #0x10
    // 0x851160: ret
    //     0x851160: ret             
    // 0x851164: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x851164: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x851168: b               #0x851150
  }
  _ _dropChild(/* No info */) {
    // ** addr: 0x85116c, size: 0x8c
    // 0x85116c: EnterFrame
    //     0x85116c: stp             fp, lr, [SP, #-0x10]!
    //     0x851170: mov             fp, SP
    // 0x851174: AllocStack(0x10)
    //     0x851174: sub             SP, SP, #0x10
    // 0x851178: SetupParameters(RestorationBucket this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x851178: mov             x3, x1
    //     0x85117c: mov             x0, x2
    //     0x851180: stur            x1, [fp, #-8]
    //     0x851184: stur            x2, [fp, #-0x10]
    // 0x851188: CheckStackOverflow
    //     0x851188: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x85118c: cmp             SP, x16
    //     0x851190: b.ls            #0x8511f0
    // 0x851194: mov             x1, x3
    // 0x851198: mov             x2, x0
    // 0x85119c: r0 = _removeChildData()
    //     0x85119c: bl              #0x850864  ; [package:flutter/src/services/restoration.dart] RestorationBucket::_removeChildData
    // 0x8511a0: ldur            x0, [fp, #-0x10]
    // 0x8511a4: StoreField: r0->field_f = rNULL
    //     0x8511a4: stur            NULL, [x0, #0xf]
    // 0x8511a8: LoadField: r1 = r0->field_b
    //     0x8511a8: ldur            w1, [x0, #0xb]
    // 0x8511ac: DecompressPointer r1
    //     0x8511ac: add             x1, x1, HEAP, lsl #32
    // 0x8511b0: cmp             w1, NULL
    // 0x8511b4: b.eq            #0x8511e0
    // 0x8511b8: mov             x1, x0
    // 0x8511bc: r2 = Null
    //     0x8511bc: mov             x2, NULL
    // 0x8511c0: r0 = _updateManager()
    //     0x8511c0: bl              #0x85037c  ; [package:flutter/src/services/restoration.dart] RestorationBucket::_updateManager
    // 0x8511c4: ldur            x2, [fp, #-8]
    // 0x8511c8: r1 = Function '_recursivelyUpdateManager@77347053':.
    //     0x8511c8: ldr             x1, [PP, #0x41d8]  ; [pp+0x41d8] AnonymousClosure: (0x8511f8), in [package:flutter/src/services/restoration.dart] RestorationBucket::_recursivelyUpdateManager (0x851234)
    // 0x8511cc: r0 = AllocateClosure()
    //     0x8511cc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8511d0: ldur            x1, [fp, #-0x10]
    // 0x8511d4: mov             x2, x0
    // 0x8511d8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8511d8: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8511dc: r0 = _visitChildren()
    //     0x8511dc: bl              #0x850d08  ; [package:flutter/src/services/restoration.dart] RestorationBucket::_visitChildren
    // 0x8511e0: r0 = Null
    //     0x8511e0: mov             x0, NULL
    // 0x8511e4: LeaveFrame
    //     0x8511e4: mov             SP, fp
    //     0x8511e8: ldp             fp, lr, [SP], #0x10
    // 0x8511ec: ret
    //     0x8511ec: ret             
    // 0x8511f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8511f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8511f4: b               #0x851194
  }
  [closure] void _recursivelyUpdateManager(dynamic, RestorationBucket) {
    // ** addr: 0x8511f8, size: 0x3c
    // 0x8511f8: EnterFrame
    //     0x8511f8: stp             fp, lr, [SP, #-0x10]!
    //     0x8511fc: mov             fp, SP
    // 0x851200: ldr             x0, [fp, #0x18]
    // 0x851204: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x851204: ldur            w1, [x0, #0x17]
    // 0x851208: DecompressPointer r1
    //     0x851208: add             x1, x1, HEAP, lsl #32
    // 0x85120c: CheckStackOverflow
    //     0x85120c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x851210: cmp             SP, x16
    //     0x851214: b.ls            #0x85122c
    // 0x851218: ldr             x2, [fp, #0x10]
    // 0x85121c: r0 = _recursivelyUpdateManager()
    //     0x85121c: bl              #0x851234  ; [package:flutter/src/services/restoration.dart] RestorationBucket::_recursivelyUpdateManager
    // 0x851220: LeaveFrame
    //     0x851220: mov             SP, fp
    //     0x851224: ldp             fp, lr, [SP], #0x10
    // 0x851228: ret
    //     0x851228: ret             
    // 0x85122c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85122c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x851230: b               #0x851218
  }
  _ _recursivelyUpdateManager(/* No info */) {
    // ** addr: 0x851234, size: 0x6c
    // 0x851234: EnterFrame
    //     0x851234: stp             fp, lr, [SP, #-0x10]!
    //     0x851238: mov             fp, SP
    // 0x85123c: AllocStack(0x10)
    //     0x85123c: sub             SP, SP, #0x10
    // 0x851240: SetupParameters(RestorationBucket this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x851240: mov             x3, x1
    //     0x851244: mov             x0, x2
    //     0x851248: stur            x1, [fp, #-8]
    //     0x85124c: stur            x2, [fp, #-0x10]
    // 0x851250: CheckStackOverflow
    //     0x851250: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x851254: cmp             SP, x16
    //     0x851258: b.ls            #0x851298
    // 0x85125c: LoadField: r2 = r3->field_b
    //     0x85125c: ldur            w2, [x3, #0xb]
    // 0x851260: DecompressPointer r2
    //     0x851260: add             x2, x2, HEAP, lsl #32
    // 0x851264: mov             x1, x0
    // 0x851268: r0 = _updateManager()
    //     0x851268: bl              #0x85037c  ; [package:flutter/src/services/restoration.dart] RestorationBucket::_updateManager
    // 0x85126c: ldur            x2, [fp, #-8]
    // 0x851270: r1 = Function '_recursivelyUpdateManager@77347053':.
    //     0x851270: ldr             x1, [PP, #0x41d8]  ; [pp+0x41d8] AnonymousClosure: (0x8511f8), in [package:flutter/src/services/restoration.dart] RestorationBucket::_recursivelyUpdateManager (0x851234)
    // 0x851274: r0 = AllocateClosure()
    //     0x851274: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x851278: ldur            x1, [fp, #-0x10]
    // 0x85127c: mov             x2, x0
    // 0x851280: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x851280: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x851284: r0 = _visitChildren()
    //     0x851284: bl              #0x850d08  ; [package:flutter/src/services/restoration.dart] RestorationBucket::_visitChildren
    // 0x851288: r0 = Null
    //     0x851288: mov             x0, NULL
    // 0x85128c: LeaveFrame
    //     0x85128c: mov             SP, fp
    //     0x851290: ldp             fp, lr, [SP], #0x10
    // 0x851294: ret
    //     0x851294: ret             
    // 0x851298: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x851298: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x85129c: b               #0x85125c
  }
  _ RestorationBucket.root(/* No info */) {
    // ** addr: 0x8512a0, size: 0x114
    // 0x8512a0: EnterFrame
    //     0x8512a0: stp             fp, lr, [SP, #-0x10]!
    //     0x8512a4: mov             fp, SP
    // 0x8512a8: AllocStack(0x28)
    //     0x8512a8: sub             SP, SP, #0x28
    // 0x8512ac: r0 = false
    //     0x8512ac: add             x0, NULL, #0x30  ; false
    // 0x8512b0: stur            x1, [fp, #-8]
    // 0x8512b4: mov             x16, x2
    // 0x8512b8: mov             x2, x1
    // 0x8512bc: mov             x1, x16
    // 0x8512c0: stur            x1, [fp, #-0x10]
    // 0x8512c4: stur            x3, [fp, #-0x18]
    // 0x8512c8: CheckStackOverflow
    //     0x8512c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8512cc: cmp             SP, x16
    //     0x8512d0: b.ls            #0x8513ac
    // 0x8512d4: StoreField: r2->field_1f = r0
    //     0x8512d4: stur            w0, [x2, #0x1f]
    // 0x8512d8: r16 = <String, RestorationBucket>
    //     0x8512d8: ldr             x16, [PP, #0x4290]  ; [pp+0x4290] TypeArguments: <String, RestorationBucket>
    // 0x8512dc: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x8512e0: stp             lr, x16, [SP]
    // 0x8512e4: r0 = Map._fromLiteral()
    //     0x8512e4: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x8512e8: ldur            x1, [fp, #-8]
    // 0x8512ec: ArrayStore: r1[0] = r0  ; List_4
    //     0x8512ec: stur            w0, [x1, #0x17]
    //     0x8512f0: ldurb           w16, [x1, #-1]
    //     0x8512f4: ldurb           w17, [x0, #-1]
    //     0x8512f8: and             x16, x17, x16, lsr #2
    //     0x8512fc: tst             x16, HEAP, lsr #32
    //     0x851300: b.eq            #0x851308
    //     0x851304: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x851308: r16 = <String, List<RestorationBucket>>
    //     0x851308: ldr             x16, [PP, #0x4298]  ; [pp+0x4298] TypeArguments: <String, List<RestorationBucket>>
    // 0x85130c: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x851310: stp             lr, x16, [SP]
    // 0x851314: r0 = Map._fromLiteral()
    //     0x851314: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x851318: ldur            x1, [fp, #-8]
    // 0x85131c: StoreField: r1->field_1b = r0
    //     0x85131c: stur            w0, [x1, #0x1b]
    //     0x851320: ldurb           w16, [x1, #-1]
    //     0x851324: ldurb           w17, [x0, #-1]
    //     0x851328: and             x16, x17, x16, lsr #2
    //     0x85132c: tst             x16, HEAP, lsr #32
    //     0x851330: b.eq            #0x851338
    //     0x851334: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x851338: ldur            x0, [fp, #-0x10]
    // 0x85133c: StoreField: r1->field_b = r0
    //     0x85133c: stur            w0, [x1, #0xb]
    //     0x851340: ldurb           w16, [x1, #-1]
    //     0x851344: ldurb           w17, [x0, #-1]
    //     0x851348: and             x16, x17, x16, lsr #2
    //     0x85134c: tst             x16, HEAP, lsr #32
    //     0x851350: b.eq            #0x851358
    //     0x851354: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x851358: ldur            x0, [fp, #-0x18]
    // 0x85135c: cmp             w0, NULL
    // 0x851360: b.ne            #0x851374
    // 0x851364: r16 = <Object?, Object?>
    //     0x851364: ldr             x16, [PP, #0x4250]  ; [pp+0x4250] TypeArguments: <Object?, Object?>
    // 0x851368: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x85136c: stp             lr, x16, [SP]
    // 0x851370: r0 = Map._fromLiteral()
    //     0x851370: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x851374: ldur            x1, [fp, #-8]
    // 0x851378: r2 = "root"
    //     0x851378: ldr             x2, [PP, #0x42a0]  ; [pp+0x42a0] "root"
    // 0x85137c: StoreField: r1->field_7 = r0
    //     0x85137c: stur            w0, [x1, #7]
    //     0x851380: ldurb           w16, [x1, #-1]
    //     0x851384: ldurb           w17, [x0, #-1]
    //     0x851388: and             x16, x17, x16, lsr #2
    //     0x85138c: tst             x16, HEAP, lsr #32
    //     0x851390: b.eq            #0x851398
    //     0x851394: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x851398: StoreField: r1->field_13 = r2
    //     0x851398: stur            w2, [x1, #0x13]
    // 0x85139c: r0 = Null
    //     0x85139c: mov             x0, NULL
    // 0x8513a0: LeaveFrame
    //     0x8513a0: mov             SP, fp
    //     0x8513a4: ldp             fp, lr, [SP], #0x10
    // 0x8513a8: ret
    //     0x8513a8: ret             
    // 0x8513ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8513ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8513b0: b               #0x8512d4
  }
  _ adoptChild(/* No info */) {
    // ** addr: 0xef026c, size: 0xc4
    // 0xef026c: EnterFrame
    //     0xef026c: stp             fp, lr, [SP, #-0x10]!
    //     0xef0270: mov             fp, SP
    // 0xef0274: AllocStack(0x10)
    //     0xef0274: sub             SP, SP, #0x10
    // 0xef0278: SetupParameters(RestorationBucket this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xef0278: mov             x3, x1
    //     0xef027c: mov             x0, x2
    //     0xef0280: stur            x1, [fp, #-8]
    //     0xef0284: stur            x2, [fp, #-0x10]
    // 0xef0288: CheckStackOverflow
    //     0xef0288: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef028c: cmp             SP, x16
    //     0xef0290: b.ls            #0xef0328
    // 0xef0294: LoadField: r1 = r0->field_f
    //     0xef0294: ldur            w1, [x0, #0xf]
    // 0xef0298: DecompressPointer r1
    //     0xef0298: add             x1, x1, HEAP, lsl #32
    // 0xef029c: cmp             w1, w3
    // 0xef02a0: b.eq            #0xef0318
    // 0xef02a4: cmp             w1, NULL
    // 0xef02a8: b.ne            #0xef02b8
    // 0xef02ac: mov             x4, x3
    // 0xef02b0: mov             x3, x0
    // 0xef02b4: b               #0xef02c8
    // 0xef02b8: mov             x2, x0
    // 0xef02bc: r0 = _removeChildData()
    //     0xef02bc: bl              #0x850864  ; [package:flutter/src/services/restoration.dart] RestorationBucket::_removeChildData
    // 0xef02c0: ldur            x4, [fp, #-8]
    // 0xef02c4: ldur            x3, [fp, #-0x10]
    // 0xef02c8: mov             x0, x4
    // 0xef02cc: StoreField: r3->field_f = r0
    //     0xef02cc: stur            w0, [x3, #0xf]
    //     0xef02d0: ldurb           w16, [x3, #-1]
    //     0xef02d4: ldurb           w17, [x0, #-1]
    //     0xef02d8: and             x16, x17, x16, lsr #2
    //     0xef02dc: tst             x16, HEAP, lsr #32
    //     0xef02e0: b.eq            #0xef02e8
    //     0xef02e4: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xef02e8: mov             x1, x4
    // 0xef02ec: mov             x2, x3
    // 0xef02f0: r0 = _addChildData()
    //     0xef02f0: bl              #0xef0330  ; [package:flutter/src/services/restoration.dart] RestorationBucket::_addChildData
    // 0xef02f4: ldur            x2, [fp, #-0x10]
    // 0xef02f8: LoadField: r0 = r2->field_b
    //     0xef02f8: ldur            w0, [x2, #0xb]
    // 0xef02fc: DecompressPointer r0
    //     0xef02fc: add             x0, x0, HEAP, lsl #32
    // 0xef0300: ldur            x1, [fp, #-8]
    // 0xef0304: LoadField: r3 = r1->field_b
    //     0xef0304: ldur            w3, [x1, #0xb]
    // 0xef0308: DecompressPointer r3
    //     0xef0308: add             x3, x3, HEAP, lsl #32
    // 0xef030c: cmp             w0, w3
    // 0xef0310: b.eq            #0xef0318
    // 0xef0314: r0 = _recursivelyUpdateManager()
    //     0xef0314: bl              #0x851234  ; [package:flutter/src/services/restoration.dart] RestorationBucket::_recursivelyUpdateManager
    // 0xef0318: r0 = Null
    //     0xef0318: mov             x0, NULL
    // 0xef031c: LeaveFrame
    //     0xef031c: mov             SP, fp
    //     0xef0320: ldp             fp, lr, [SP], #0x10
    // 0xef0324: ret
    //     0xef0324: ret             
    // 0xef0328: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef0328: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef032c: b               #0xef0294
  }
  _ _addChildData(/* No info */) {
    // ** addr: 0xef0330, size: 0xec
    // 0xef0330: EnterFrame
    //     0xef0330: stp             fp, lr, [SP, #-0x10]!
    //     0xef0334: mov             fp, SP
    // 0xef0338: AllocStack(0x30)
    //     0xef0338: sub             SP, SP, #0x30
    // 0xef033c: SetupParameters(RestorationBucket this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xef033c: mov             x3, x1
    //     0xef0340: mov             x0, x2
    //     0xef0344: stur            x1, [fp, #-8]
    //     0xef0348: stur            x2, [fp, #-0x10]
    // 0xef034c: CheckStackOverflow
    //     0xef034c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef0350: cmp             SP, x16
    //     0xef0354: b.ls            #0xef0414
    // 0xef0358: ArrayLoad: r1 = r3[0]  ; List_4
    //     0xef0358: ldur            w1, [x3, #0x17]
    // 0xef035c: DecompressPointer r1
    //     0xef035c: add             x1, x1, HEAP, lsl #32
    // 0xef0360: LoadField: r2 = r0->field_13
    //     0xef0360: ldur            w2, [x0, #0x13]
    // 0xef0364: DecompressPointer r2
    //     0xef0364: add             x2, x2, HEAP, lsl #32
    // 0xef0368: r0 = containsKey()
    //     0xef0368: bl              #0x12d5a5c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0xef036c: tbnz            w0, #4, #0xef03f0
    // 0xef0370: ldur            x3, [fp, #-8]
    // 0xef0374: ldur            x0, [fp, #-0x10]
    // 0xef0378: LoadField: r4 = r3->field_1b
    //     0xef0378: ldur            w4, [x3, #0x1b]
    // 0xef037c: DecompressPointer r4
    //     0xef037c: add             x4, x4, HEAP, lsl #32
    // 0xef0380: stur            x4, [fp, #-0x20]
    // 0xef0384: LoadField: r5 = r0->field_13
    //     0xef0384: ldur            w5, [x0, #0x13]
    // 0xef0388: DecompressPointer r5
    //     0xef0388: add             x5, x5, HEAP, lsl #32
    // 0xef038c: stur            x5, [fp, #-0x18]
    // 0xef0390: r1 = Function '<anonymous closure>':.
    //     0xef0390: add             x1, PP, #0x9a, lsl #12  ; [pp+0x9aa40] AnonymousClosure: (0xef041c), in [package:flutter/src/services/restoration.dart] RestorationBucket::_addChildData (0xef0330)
    //     0xef0394: ldr             x1, [x1, #0xa40]
    // 0xef0398: r2 = Null
    //     0xef0398: mov             x2, NULL
    // 0xef039c: r0 = AllocateClosure()
    //     0xef039c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xef03a0: ldur            x1, [fp, #-0x20]
    // 0xef03a4: ldur            x2, [fp, #-0x18]
    // 0xef03a8: mov             x3, x0
    // 0xef03ac: r0 = putIfAbsent()
    //     0xef03ac: bl              #0xa1be20  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::putIfAbsent
    // 0xef03b0: r1 = LoadClassIdInstr(r0)
    //     0xef03b0: ldur            x1, [x0, #-1]
    //     0xef03b4: ubfx            x1, x1, #0xc, #0x14
    // 0xef03b8: ldur            x16, [fp, #-0x10]
    // 0xef03bc: stp             x16, x0, [SP]
    // 0xef03c0: mov             x0, x1
    // 0xef03c4: r0 = GDT[cid_x0 + 0x175da]()
    //     0xef03c4: mov             x17, #0x75da
    //     0xef03c8: movk            x17, #1, lsl #16
    //     0xef03cc: add             lr, x0, x17
    //     0xef03d0: ldr             lr, [x21, lr, lsl #3]
    //     0xef03d4: blr             lr
    // 0xef03d8: ldur            x1, [fp, #-8]
    // 0xef03dc: r0 = _markNeedsSerialization()
    //     0xef03dc: bl              #0x850440  ; [package:flutter/src/services/restoration.dart] RestorationBucket::_markNeedsSerialization
    // 0xef03e0: r0 = Null
    //     0xef03e0: mov             x0, NULL
    // 0xef03e4: LeaveFrame
    //     0xef03e4: mov             SP, fp
    //     0xef03e8: ldp             fp, lr, [SP], #0x10
    // 0xef03ec: ret
    //     0xef03ec: ret             
    // 0xef03f0: ldur            x1, [fp, #-8]
    // 0xef03f4: ldur            x2, [fp, #-0x10]
    // 0xef03f8: r0 = _finalizeAddChildData()
    //     0xef03f8: bl              #0x850bd8  ; [package:flutter/src/services/restoration.dart] RestorationBucket::_finalizeAddChildData
    // 0xef03fc: ldur            x1, [fp, #-8]
    // 0xef0400: r0 = _markNeedsSerialization()
    //     0xef0400: bl              #0x850440  ; [package:flutter/src/services/restoration.dart] RestorationBucket::_markNeedsSerialization
    // 0xef0404: r0 = Null
    //     0xef0404: mov             x0, NULL
    // 0xef0408: LeaveFrame
    //     0xef0408: mov             SP, fp
    //     0xef040c: ldp             fp, lr, [SP], #0x10
    // 0xef0410: ret
    //     0xef0410: ret             
    // 0xef0414: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef0414: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef0418: b               #0xef0358
  }
  [closure] List<RestorationBucket> <anonymous closure>(dynamic) {
    // ** addr: 0xef041c, size: 0x34
    // 0xef041c: EnterFrame
    //     0xef041c: stp             fp, lr, [SP, #-0x10]!
    //     0xef0420: mov             fp, SP
    // 0xef0424: CheckStackOverflow
    //     0xef0424: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef0428: cmp             SP, x16
    //     0xef042c: b.ls            #0xef0448
    // 0xef0430: r1 = <RestorationBucket>
    //     0xef0430: ldr             x1, [PP, #0x4140]  ; [pp+0x4140] TypeArguments: <RestorationBucket>
    // 0xef0434: r2 = 0
    //     0xef0434: mov             x2, #0
    // 0xef0438: r0 = _GrowableList()
    //     0xef0438: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xef043c: LeaveFrame
    //     0xef043c: mov             SP, fp
    //     0xef0440: ldp             fp, lr, [SP], #0x10
    // 0xef0444: ret
    //     0xef0444: ret             
    // 0xef0448: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef0448: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef044c: b               #0xef0430
  }
  _ rename(/* No info */) {
    // ** addr: 0xef0450, size: 0xd8
    // 0xef0450: EnterFrame
    //     0xef0450: stp             fp, lr, [SP, #-0x10]!
    //     0xef0454: mov             fp, SP
    // 0xef0458: AllocStack(0x20)
    //     0xef0458: sub             SP, SP, #0x20
    // 0xef045c: SetupParameters(RestorationBucket this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xef045c: stur            x1, [fp, #-8]
    //     0xef0460: mov             x16, x2
    //     0xef0464: mov             x2, x1
    //     0xef0468: mov             x1, x16
    //     0xef046c: stur            x1, [fp, #-0x10]
    // 0xef0470: CheckStackOverflow
    //     0xef0470: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef0474: cmp             SP, x16
    //     0xef0478: b.ls            #0xef0520
    // 0xef047c: LoadField: r0 = r2->field_13
    //     0xef047c: ldur            w0, [x2, #0x13]
    // 0xef0480: DecompressPointer r0
    //     0xef0480: add             x0, x0, HEAP, lsl #32
    // 0xef0484: r3 = LoadClassIdInstr(r1)
    //     0xef0484: ldur            x3, [x1, #-1]
    //     0xef0488: ubfx            x3, x3, #0xc, #0x14
    // 0xef048c: stp             x0, x1, [SP]
    // 0xef0490: mov             x0, x3
    // 0xef0494: mov             lr, x0
    // 0xef0498: ldr             lr, [x21, lr, lsl #3]
    // 0xef049c: blr             lr
    // 0xef04a0: tbnz            w0, #4, #0xef04b4
    // 0xef04a4: r0 = Null
    //     0xef04a4: mov             x0, NULL
    // 0xef04a8: LeaveFrame
    //     0xef04a8: mov             SP, fp
    //     0xef04ac: ldp             fp, lr, [SP], #0x10
    // 0xef04b0: ret
    //     0xef04b0: ret             
    // 0xef04b4: ldur            x0, [fp, #-8]
    // 0xef04b8: LoadField: r1 = r0->field_f
    //     0xef04b8: ldur            w1, [x0, #0xf]
    // 0xef04bc: DecompressPointer r1
    //     0xef04bc: add             x1, x1, HEAP, lsl #32
    // 0xef04c0: cmp             w1, NULL
    // 0xef04c4: b.ne            #0xef04d0
    // 0xef04c8: mov             x2, x0
    // 0xef04cc: b               #0xef04dc
    // 0xef04d0: mov             x2, x0
    // 0xef04d4: r0 = _removeChildData()
    //     0xef04d4: bl              #0x850864  ; [package:flutter/src/services/restoration.dart] RestorationBucket::_removeChildData
    // 0xef04d8: ldur            x2, [fp, #-8]
    // 0xef04dc: ldur            x0, [fp, #-0x10]
    // 0xef04e0: StoreField: r2->field_13 = r0
    //     0xef04e0: stur            w0, [x2, #0x13]
    //     0xef04e4: ldurb           w16, [x2, #-1]
    //     0xef04e8: ldurb           w17, [x0, #-1]
    //     0xef04ec: and             x16, x17, x16, lsr #2
    //     0xef04f0: tst             x16, HEAP, lsr #32
    //     0xef04f4: b.eq            #0xef04fc
    //     0xef04f8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xef04fc: LoadField: r1 = r2->field_f
    //     0xef04fc: ldur            w1, [x2, #0xf]
    // 0xef0500: DecompressPointer r1
    //     0xef0500: add             x1, x1, HEAP, lsl #32
    // 0xef0504: cmp             w1, NULL
    // 0xef0508: b.eq            #0xef0510
    // 0xef050c: r0 = _addChildData()
    //     0xef050c: bl              #0xef0330  ; [package:flutter/src/services/restoration.dart] RestorationBucket::_addChildData
    // 0xef0510: r0 = Null
    //     0xef0510: mov             x0, NULL
    // 0xef0514: LeaveFrame
    //     0xef0514: mov             SP, fp
    //     0xef0518: ldp             fp, lr, [SP], #0x10
    // 0xef051c: ret
    //     0xef051c: ret             
    // 0xef0520: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef0520: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef0524: b               #0xef047c
  }
  _ claimChild(/* No info */) {
    // ** addr: 0xef0528, size: 0x14c
    // 0xef0528: EnterFrame
    //     0xef0528: stp             fp, lr, [SP, #-0x10]!
    //     0xef052c: mov             fp, SP
    // 0xef0530: AllocStack(0x20)
    //     0xef0530: sub             SP, SP, #0x20
    // 0xef0534: SetupParameters(RestorationBucket this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */)
    //     0xef0534: mov             x3, x1
    //     0xef0538: mov             x0, x2
    //     0xef053c: stur            x1, [fp, #-0x10]
    //     0xef0540: stur            x2, [fp, #-0x18]
    // 0xef0544: CheckStackOverflow
    //     0xef0544: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef0548: cmp             SP, x16
    //     0xef054c: b.ls            #0xef0668
    // 0xef0550: ArrayLoad: r4 = r3[0]  ; List_4
    //     0xef0550: ldur            w4, [x3, #0x17]
    // 0xef0554: DecompressPointer r4
    //     0xef0554: add             x4, x4, HEAP, lsl #32
    // 0xef0558: mov             x1, x4
    // 0xef055c: mov             x2, x0
    // 0xef0560: stur            x4, [fp, #-8]
    // 0xef0564: r0 = containsKey()
    //     0xef0564: bl              #0x12d5a5c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0xef0568: tbz             w0, #4, #0xef0600
    // 0xef056c: ldur            x0, [fp, #-0x10]
    // 0xef0570: LoadField: r3 = r0->field_7
    //     0xef0570: ldur            w3, [x0, #7]
    // 0xef0574: DecompressPointer r3
    //     0xef0574: add             x3, x3, HEAP, lsl #32
    // 0xef0578: stur            x3, [fp, #-0x20]
    // 0xef057c: r1 = Function '<anonymous closure>':.
    //     0xef057c: ldr             x1, [PP, #0x4220]  ; [pp+0x4220] AnonymousClosure: (0x850320), of [package:flutter/src/services/restoration.dart] RestorationBucket
    // 0xef0580: r2 = Null
    //     0xef0580: mov             x2, NULL
    // 0xef0584: r0 = AllocateClosure()
    //     0xef0584: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xef0588: ldur            x1, [fp, #-0x20]
    // 0xef058c: r2 = LoadClassIdInstr(r1)
    //     0xef058c: ldur            x2, [x1, #-1]
    //     0xef0590: ubfx            x2, x2, #0xc, #0x14
    // 0xef0594: mov             x3, x0
    // 0xef0598: mov             x0, x2
    // 0xef059c: r2 = "c"
    //     0xef059c: ldr             x2, [PP, #0x4228]  ; [pp+0x4228] "c"
    // 0xef05a0: r0 = GDT[cid_x0 + 0x1688c]()
    //     0xef05a0: mov             x17, #0x688c
    //     0xef05a4: movk            x17, #1, lsl #16
    //     0xef05a8: add             lr, x0, x17
    //     0xef05ac: ldr             lr, [x21, lr, lsl #3]
    //     0xef05b0: blr             lr
    // 0xef05b4: mov             x3, x0
    // 0xef05b8: stur            x3, [fp, #-0x20]
    // 0xef05bc: cmp             w3, NULL
    // 0xef05c0: b.eq            #0xef0670
    // 0xef05c4: mov             x0, x3
    // 0xef05c8: r2 = Null
    //     0xef05c8: mov             x2, NULL
    // 0xef05cc: r1 = Null
    //     0xef05cc: mov             x1, NULL
    // 0xef05d0: r8 = Map<Object?, Object?>
    //     0xef05d0: ldr             x8, [PP, #0x3238]  ; [pp+0x3238] Type: Map<Object?, Object?>
    // 0xef05d4: r3 = Null
    //     0xef05d4: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9aa48] Null
    //     0xef05d8: ldr             x3, [x3, #0xa48]
    // 0xef05dc: r0 = Map<Object?, Object?>()
    //     0xef05dc: bl              #0x851560  ; IsType_Map<Object?, Object?>_Stub
    // 0xef05e0: ldur            x1, [fp, #-0x20]
    // 0xef05e4: r0 = LoadClassIdInstr(r1)
    //     0xef05e4: ldur            x0, [x1, #-1]
    //     0xef05e8: ubfx            x0, x0, #0xc, #0x14
    // 0xef05ec: ldur            x2, [fp, #-0x18]
    // 0xef05f0: r0 = GDT[cid_x0 + -0x104]()
    //     0xef05f0: sub             lr, x0, #0x104
    //     0xef05f4: ldr             lr, [x21, lr, lsl #3]
    //     0xef05f8: blr             lr
    // 0xef05fc: tbz             w0, #4, #0xef0630
    // 0xef0600: r0 = RestorationBucket()
    //     0xef0600: bl              #0x8513b4  ; AllocateRestorationBucketStub -> RestorationBucket (size=0x24)
    // 0xef0604: mov             x1, x0
    // 0xef0608: ldur            x2, [fp, #-0x18]
    // 0xef060c: stur            x0, [fp, #-0x20]
    // 0xef0610: r0 = RestorationBucket.empty()
    //     0xef0610: bl              #0xef087c  ; [package:flutter/src/services/restoration.dart] RestorationBucket::RestorationBucket.empty
    // 0xef0614: ldur            x1, [fp, #-0x10]
    // 0xef0618: ldur            x2, [fp, #-0x20]
    // 0xef061c: r0 = adoptChild()
    //     0xef061c: bl              #0xef026c  ; [package:flutter/src/services/restoration.dart] RestorationBucket::adoptChild
    // 0xef0620: ldur            x0, [fp, #-0x20]
    // 0xef0624: LeaveFrame
    //     0xef0624: mov             SP, fp
    //     0xef0628: ldp             fp, lr, [SP], #0x10
    // 0xef062c: ret
    //     0xef062c: ret             
    // 0xef0630: r0 = RestorationBucket()
    //     0xef0630: bl              #0x8513b4  ; AllocateRestorationBucketStub -> RestorationBucket (size=0x24)
    // 0xef0634: mov             x1, x0
    // 0xef0638: ldur            x2, [fp, #-0x10]
    // 0xef063c: ldur            x3, [fp, #-0x18]
    // 0xef0640: stur            x0, [fp, #-0x10]
    // 0xef0644: r0 = RestorationBucket.child()
    //     0xef0644: bl              #0xef0674  ; [package:flutter/src/services/restoration.dart] RestorationBucket::RestorationBucket.child
    // 0xef0648: ldur            x1, [fp, #-8]
    // 0xef064c: ldur            x2, [fp, #-0x18]
    // 0xef0650: ldur            x3, [fp, #-0x10]
    // 0xef0654: r0 = []=()
    //     0xef0654: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xef0658: ldur            x0, [fp, #-0x10]
    // 0xef065c: LeaveFrame
    //     0xef065c: mov             SP, fp
    //     0xef0660: ldp             fp, lr, [SP], #0x10
    // 0xef0664: ret
    //     0xef0664: ret             
    // 0xef0668: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef0668: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef066c: b               #0xef0550
    // 0xef0670: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef0670: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ RestorationBucket.child(/* No info */) {
    // ** addr: 0xef0674, size: 0x208
    // 0xef0674: EnterFrame
    //     0xef0674: stp             fp, lr, [SP, #-0x10]!
    //     0xef0678: mov             fp, SP
    // 0xef067c: AllocStack(0x30)
    //     0xef067c: sub             SP, SP, #0x30
    // 0xef0680: r0 = false
    //     0xef0680: add             x0, NULL, #0x30  ; false
    // 0xef0684: stur            x1, [fp, #-8]
    // 0xef0688: mov             x16, x2
    // 0xef068c: mov             x2, x1
    // 0xef0690: mov             x1, x16
    // 0xef0694: mov             x16, x3
    // 0xef0698: mov             x3, x2
    // 0xef069c: mov             x2, x16
    // 0xef06a0: stur            x1, [fp, #-0x10]
    // 0xef06a4: stur            x2, [fp, #-0x18]
    // 0xef06a8: CheckStackOverflow
    //     0xef06a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef06ac: cmp             SP, x16
    //     0xef06b0: b.ls            #0xef086c
    // 0xef06b4: StoreField: r3->field_1f = r0
    //     0xef06b4: stur            w0, [x3, #0x1f]
    // 0xef06b8: r16 = <String, RestorationBucket>
    //     0xef06b8: ldr             x16, [PP, #0x4290]  ; [pp+0x4290] TypeArguments: <String, RestorationBucket>
    // 0xef06bc: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0xef06c0: stp             lr, x16, [SP]
    // 0xef06c4: r0 = Map._fromLiteral()
    //     0xef06c4: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xef06c8: ldur            x1, [fp, #-8]
    // 0xef06cc: ArrayStore: r1[0] = r0  ; List_4
    //     0xef06cc: stur            w0, [x1, #0x17]
    //     0xef06d0: ldurb           w16, [x1, #-1]
    //     0xef06d4: ldurb           w17, [x0, #-1]
    //     0xef06d8: and             x16, x17, x16, lsr #2
    //     0xef06dc: tst             x16, HEAP, lsr #32
    //     0xef06e0: b.eq            #0xef06e8
    //     0xef06e4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xef06e8: r16 = <String, List<RestorationBucket>>
    //     0xef06e8: ldr             x16, [PP, #0x4298]  ; [pp+0x4298] TypeArguments: <String, List<RestorationBucket>>
    // 0xef06ec: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0xef06f0: stp             lr, x16, [SP]
    // 0xef06f4: r0 = Map._fromLiteral()
    //     0xef06f4: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xef06f8: ldur            x3, [fp, #-8]
    // 0xef06fc: StoreField: r3->field_1b = r0
    //     0xef06fc: stur            w0, [x3, #0x1b]
    //     0xef0700: ldurb           w16, [x3, #-1]
    //     0xef0704: ldurb           w17, [x0, #-1]
    //     0xef0708: and             x16, x17, x16, lsr #2
    //     0xef070c: tst             x16, HEAP, lsr #32
    //     0xef0710: b.eq            #0xef0718
    //     0xef0714: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xef0718: ldur            x1, [fp, #-0x10]
    // 0xef071c: LoadField: r0 = r1->field_b
    //     0xef071c: ldur            w0, [x1, #0xb]
    // 0xef0720: DecompressPointer r0
    //     0xef0720: add             x0, x0, HEAP, lsl #32
    // 0xef0724: StoreField: r3->field_b = r0
    //     0xef0724: stur            w0, [x3, #0xb]
    //     0xef0728: ldurb           w16, [x3, #-1]
    //     0xef072c: ldurb           w17, [x0, #-1]
    //     0xef0730: and             x16, x17, x16, lsr #2
    //     0xef0734: tst             x16, HEAP, lsr #32
    //     0xef0738: b.eq            #0xef0740
    //     0xef073c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xef0740: mov             x0, x1
    // 0xef0744: StoreField: r3->field_f = r0
    //     0xef0744: stur            w0, [x3, #0xf]
    //     0xef0748: ldurb           w16, [x3, #-1]
    //     0xef074c: ldurb           w17, [x0, #-1]
    //     0xef0750: and             x16, x17, x16, lsr #2
    //     0xef0754: tst             x16, HEAP, lsr #32
    //     0xef0758: b.eq            #0xef0760
    //     0xef075c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xef0760: LoadField: r0 = r1->field_7
    //     0xef0760: ldur            w0, [x1, #7]
    // 0xef0764: DecompressPointer r0
    //     0xef0764: add             x0, x0, HEAP, lsl #32
    // 0xef0768: stur            x0, [fp, #-0x20]
    // 0xef076c: r1 = Function '<anonymous closure>':.
    //     0xef076c: ldr             x1, [PP, #0x4220]  ; [pp+0x4220] AnonymousClosure: (0x850320), of [package:flutter/src/services/restoration.dart] RestorationBucket
    // 0xef0770: r2 = Null
    //     0xef0770: mov             x2, NULL
    // 0xef0774: r0 = AllocateClosure()
    //     0xef0774: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xef0778: ldur            x1, [fp, #-0x20]
    // 0xef077c: r2 = LoadClassIdInstr(r1)
    //     0xef077c: ldur            x2, [x1, #-1]
    //     0xef0780: ubfx            x2, x2, #0xc, #0x14
    // 0xef0784: mov             x3, x0
    // 0xef0788: mov             x0, x2
    // 0xef078c: r2 = "c"
    //     0xef078c: ldr             x2, [PP, #0x4228]  ; [pp+0x4228] "c"
    // 0xef0790: r0 = GDT[cid_x0 + 0x1688c]()
    //     0xef0790: mov             x17, #0x688c
    //     0xef0794: movk            x17, #1, lsl #16
    //     0xef0798: add             lr, x0, x17
    //     0xef079c: ldr             lr, [x21, lr, lsl #3]
    //     0xef07a0: blr             lr
    // 0xef07a4: mov             x3, x0
    // 0xef07a8: stur            x3, [fp, #-0x10]
    // 0xef07ac: cmp             w3, NULL
    // 0xef07b0: b.eq            #0xef0874
    // 0xef07b4: mov             x0, x3
    // 0xef07b8: r2 = Null
    //     0xef07b8: mov             x2, NULL
    // 0xef07bc: r1 = Null
    //     0xef07bc: mov             x1, NULL
    // 0xef07c0: r8 = Map<Object?, Object?>
    //     0xef07c0: ldr             x8, [PP, #0x3238]  ; [pp+0x3238] Type: Map<Object?, Object?>
    // 0xef07c4: r3 = Null
    //     0xef07c4: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9aa58] Null
    //     0xef07c8: ldr             x3, [x3, #0xa58]
    // 0xef07cc: r0 = Map<Object?, Object?>()
    //     0xef07cc: bl              #0x851560  ; IsType_Map<Object?, Object?>_Stub
    // 0xef07d0: ldur            x1, [fp, #-0x10]
    // 0xef07d4: r0 = LoadClassIdInstr(r1)
    //     0xef07d4: ldur            x0, [x1, #-1]
    //     0xef07d8: ubfx            x0, x0, #0xc, #0x14
    // 0xef07dc: ldur            x2, [fp, #-0x18]
    // 0xef07e0: r0 = GDT[cid_x0 + -0xd48]()
    //     0xef07e0: sub             lr, x0, #0xd48
    //     0xef07e4: ldr             lr, [x21, lr, lsl #3]
    //     0xef07e8: blr             lr
    // 0xef07ec: mov             x3, x0
    // 0xef07f0: stur            x3, [fp, #-0x10]
    // 0xef07f4: cmp             w3, NULL
    // 0xef07f8: b.eq            #0xef0878
    // 0xef07fc: mov             x0, x3
    // 0xef0800: r2 = Null
    //     0xef0800: mov             x2, NULL
    // 0xef0804: r1 = Null
    //     0xef0804: mov             x1, NULL
    // 0xef0808: r8 = Map<Object?, Object?>
    //     0xef0808: ldr             x8, [PP, #0x3238]  ; [pp+0x3238] Type: Map<Object?, Object?>
    // 0xef080c: r3 = Null
    //     0xef080c: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9aa68] Null
    //     0xef0810: ldr             x3, [x3, #0xa68]
    // 0xef0814: r0 = Map<Object?, Object?>()
    //     0xef0814: bl              #0x851560  ; IsType_Map<Object?, Object?>_Stub
    // 0xef0818: ldur            x0, [fp, #-0x10]
    // 0xef081c: ldur            x1, [fp, #-8]
    // 0xef0820: StoreField: r1->field_7 = r0
    //     0xef0820: stur            w0, [x1, #7]
    //     0xef0824: ldurb           w16, [x1, #-1]
    //     0xef0828: ldurb           w17, [x0, #-1]
    //     0xef082c: and             x16, x17, x16, lsr #2
    //     0xef0830: tst             x16, HEAP, lsr #32
    //     0xef0834: b.eq            #0xef083c
    //     0xef0838: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xef083c: ldur            x0, [fp, #-0x18]
    // 0xef0840: StoreField: r1->field_13 = r0
    //     0xef0840: stur            w0, [x1, #0x13]
    //     0xef0844: ldurb           w16, [x1, #-1]
    //     0xef0848: ldurb           w17, [x0, #-1]
    //     0xef084c: and             x16, x17, x16, lsr #2
    //     0xef0850: tst             x16, HEAP, lsr #32
    //     0xef0854: b.eq            #0xef085c
    //     0xef0858: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xef085c: r0 = Null
    //     0xef085c: mov             x0, NULL
    // 0xef0860: LeaveFrame
    //     0xef0860: mov             SP, fp
    //     0xef0864: ldp             fp, lr, [SP], #0x10
    // 0xef0868: ret
    //     0xef0868: ret             
    // 0xef086c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef086c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef0870: b               #0xef06b4
    // 0xef0874: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef0874: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef0878: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef0878: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ RestorationBucket.empty(/* No info */) {
    // ** addr: 0xef087c, size: 0x100
    // 0xef087c: EnterFrame
    //     0xef087c: stp             fp, lr, [SP, #-0x10]!
    //     0xef0880: mov             fp, SP
    // 0xef0884: AllocStack(0x20)
    //     0xef0884: sub             SP, SP, #0x20
    // 0xef0888: r0 = false
    //     0xef0888: add             x0, NULL, #0x30  ; false
    // 0xef088c: stur            x1, [fp, #-8]
    // 0xef0890: mov             x16, x2
    // 0xef0894: mov             x2, x1
    // 0xef0898: mov             x1, x16
    // 0xef089c: stur            x1, [fp, #-0x10]
    // 0xef08a0: CheckStackOverflow
    //     0xef08a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef08a4: cmp             SP, x16
    //     0xef08a8: b.ls            #0xef0974
    // 0xef08ac: StoreField: r2->field_1f = r0
    //     0xef08ac: stur            w0, [x2, #0x1f]
    // 0xef08b0: r16 = <String, RestorationBucket>
    //     0xef08b0: ldr             x16, [PP, #0x4290]  ; [pp+0x4290] TypeArguments: <String, RestorationBucket>
    // 0xef08b4: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0xef08b8: stp             lr, x16, [SP]
    // 0xef08bc: r0 = Map._fromLiteral()
    //     0xef08bc: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xef08c0: ldur            x1, [fp, #-8]
    // 0xef08c4: ArrayStore: r1[0] = r0  ; List_4
    //     0xef08c4: stur            w0, [x1, #0x17]
    //     0xef08c8: ldurb           w16, [x1, #-1]
    //     0xef08cc: ldurb           w17, [x0, #-1]
    //     0xef08d0: and             x16, x17, x16, lsr #2
    //     0xef08d4: tst             x16, HEAP, lsr #32
    //     0xef08d8: b.eq            #0xef08e0
    //     0xef08dc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xef08e0: r16 = <String, List<RestorationBucket>>
    //     0xef08e0: ldr             x16, [PP, #0x4298]  ; [pp+0x4298] TypeArguments: <String, List<RestorationBucket>>
    // 0xef08e4: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0xef08e8: stp             lr, x16, [SP]
    // 0xef08ec: r0 = Map._fromLiteral()
    //     0xef08ec: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xef08f0: ldur            x1, [fp, #-8]
    // 0xef08f4: StoreField: r1->field_1b = r0
    //     0xef08f4: stur            w0, [x1, #0x1b]
    //     0xef08f8: ldurb           w16, [x1, #-1]
    //     0xef08fc: ldurb           w17, [x0, #-1]
    //     0xef0900: and             x16, x17, x16, lsr #2
    //     0xef0904: tst             x16, HEAP, lsr #32
    //     0xef0908: b.eq            #0xef0910
    //     0xef090c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xef0910: ldur            x0, [fp, #-0x10]
    // 0xef0914: StoreField: r1->field_13 = r0
    //     0xef0914: stur            w0, [x1, #0x13]
    //     0xef0918: ldurb           w16, [x1, #-1]
    //     0xef091c: ldurb           w17, [x0, #-1]
    //     0xef0920: and             x16, x17, x16, lsr #2
    //     0xef0924: tst             x16, HEAP, lsr #32
    //     0xef0928: b.eq            #0xef0930
    //     0xef092c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xef0930: r16 = <String, Object?>
    //     0xef0930: add             x16, PP, #8, lsl #12  ; [pp+0x8128] TypeArguments: <String, Object?>
    //     0xef0934: ldr             x16, [x16, #0x128]
    // 0xef0938: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0xef093c: stp             lr, x16, [SP]
    // 0xef0940: r0 = Map._fromLiteral()
    //     0xef0940: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xef0944: ldur            x1, [fp, #-8]
    // 0xef0948: StoreField: r1->field_7 = r0
    //     0xef0948: stur            w0, [x1, #7]
    //     0xef094c: ldurb           w16, [x1, #-1]
    //     0xef0950: ldurb           w17, [x0, #-1]
    //     0xef0954: and             x16, x17, x16, lsr #2
    //     0xef0958: tst             x16, HEAP, lsr #32
    //     0xef095c: b.eq            #0xef0964
    //     0xef0960: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xef0964: r0 = Null
    //     0xef0964: mov             x0, NULL
    // 0xef0968: LeaveFrame
    //     0xef0968: mov             SP, fp
    //     0xef096c: ldp             fp, lr, [SP], #0x10
    // 0xef0970: ret
    //     0xef0970: ret             
    // 0xef0974: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef0974: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef0978: b               #0xef08ac
  }
  Y0? remove<Y0>(RestorationBucket, String) {
    // ** addr: 0xef0b90, size: 0x164
    // 0xef0b90: EnterFrame
    //     0xef0b90: stp             fp, lr, [SP, #-0x10]!
    //     0xef0b94: mov             fp, SP
    // 0xef0b98: AllocStack(0x10)
    //     0xef0b98: sub             SP, SP, #0x10
    // 0xef0b9c: SetupParameters()
    //     0xef0b9c: ldur            w0, [x4, #0xf]
    //     0xef0ba0: cbnz            w0, #0xef0bac
    //     0xef0ba4: mov             x0, NULL
    //     0xef0ba8: b               #0xef0bbc
    //     0xef0bac: ldur            w0, [x4, #0x17]
    //     0xef0bb0: add             x1, fp, w0, sxtw #2
    //     0xef0bb4: ldr             x1, [x1, #0x10]
    //     0xef0bb8: mov             x0, x1
    //     0xef0bbc: stur            x0, [fp, #-8]
    // 0xef0bc0: CheckStackOverflow
    //     0xef0bc0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef0bc4: cmp             SP, x16
    //     0xef0bc8: b.ls            #0xef0cec
    // 0xef0bcc: ldr             x1, [fp, #0x18]
    // 0xef0bd0: r0 = _rawValues()
    //     0xef0bd0: bl              #0x850274  ; [package:flutter/src/services/restoration.dart] RestorationBucket::_rawValues
    // 0xef0bd4: r1 = LoadClassIdInstr(r0)
    //     0xef0bd4: ldur            x1, [x0, #-1]
    //     0xef0bd8: ubfx            x1, x1, #0xc, #0x14
    // 0xef0bdc: mov             x16, x0
    // 0xef0be0: mov             x0, x1
    // 0xef0be4: mov             x1, x16
    // 0xef0be8: ldr             x2, [fp, #0x10]
    // 0xef0bec: r0 = GDT[cid_x0 + -0x104]()
    //     0xef0bec: sub             lr, x0, #0x104
    //     0xef0bf0: ldr             lr, [x21, lr, lsl #3]
    //     0xef0bf4: blr             lr
    // 0xef0bf8: ldr             x1, [fp, #0x18]
    // 0xef0bfc: stur            x0, [fp, #-0x10]
    // 0xef0c00: r0 = _rawValues()
    //     0xef0c00: bl              #0x850274  ; [package:flutter/src/services/restoration.dart] RestorationBucket::_rawValues
    // 0xef0c04: r1 = LoadClassIdInstr(r0)
    //     0xef0c04: ldur            x1, [x0, #-1]
    //     0xef0c08: ubfx            x1, x1, #0xc, #0x14
    // 0xef0c0c: mov             x16, x0
    // 0xef0c10: mov             x0, x1
    // 0xef0c14: mov             x1, x16
    // 0xef0c18: ldr             x2, [fp, #0x10]
    // 0xef0c1c: r0 = GDT[cid_x0 + 0x129dd]()
    //     0xef0c1c: mov             x17, #0x29dd
    //     0xef0c20: movk            x17, #1, lsl #16
    //     0xef0c24: add             lr, x0, x17
    //     0xef0c28: ldr             lr, [x21, lr, lsl #3]
    //     0xef0c2c: blr             lr
    // 0xef0c30: ldur            x1, [fp, #-8]
    // 0xef0c34: mov             x3, x0
    // 0xef0c38: r2 = Null
    //     0xef0c38: mov             x2, NULL
    // 0xef0c3c: stur            x3, [fp, #-8]
    // 0xef0c40: cmp             w0, NULL
    // 0xef0c44: b.eq            #0xef0c70
    // 0xef0c48: cmp             w1, NULL
    // 0xef0c4c: b.eq            #0xef0c70
    // 0xef0c50: ArrayLoad: r4 = r1[0]  ; List_4
    //     0xef0c50: ldur            w4, [x1, #0x17]
    // 0xef0c54: DecompressPointer r4
    //     0xef0c54: add             x4, x4, HEAP, lsl #32
    // 0xef0c58: r8 = Y0?
    //     0xef0c58: add             x8, PP, #0x9a, lsl #12  ; [pp+0x9aa80] TypeParameter: Y0?
    //     0xef0c5c: ldr             x8, [x8, #0xa80]
    // 0xef0c60: LoadField: r9 = r4->field_7
    //     0xef0c60: ldur            x9, [x4, #7]
    // 0xef0c64: r3 = Null
    //     0xef0c64: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9aa88] Null
    //     0xef0c68: ldr             x3, [x3, #0xa88]
    // 0xef0c6c: blr             x9
    // 0xef0c70: ldr             x1, [fp, #0x18]
    // 0xef0c74: r0 = _rawValues()
    //     0xef0c74: bl              #0x850274  ; [package:flutter/src/services/restoration.dart] RestorationBucket::_rawValues
    // 0xef0c78: r1 = LoadClassIdInstr(r0)
    //     0xef0c78: ldur            x1, [x0, #-1]
    //     0xef0c7c: ubfx            x1, x1, #0xc, #0x14
    // 0xef0c80: mov             x16, x0
    // 0xef0c84: mov             x0, x1
    // 0xef0c88: mov             x1, x16
    // 0xef0c8c: r0 = GDT[cid_x0 + 0x687]()
    //     0xef0c8c: add             lr, x0, #0x687
    //     0xef0c90: ldr             lr, [x21, lr, lsl #3]
    //     0xef0c94: blr             lr
    // 0xef0c98: tbnz            w0, #4, #0xef0ccc
    // 0xef0c9c: ldr             x3, [fp, #0x18]
    // 0xef0ca0: LoadField: r1 = r3->field_7
    //     0xef0ca0: ldur            w1, [x3, #7]
    // 0xef0ca4: DecompressPointer r1
    //     0xef0ca4: add             x1, x1, HEAP, lsl #32
    // 0xef0ca8: r0 = LoadClassIdInstr(r1)
    //     0xef0ca8: ldur            x0, [x1, #-1]
    //     0xef0cac: ubfx            x0, x0, #0xc, #0x14
    // 0xef0cb0: r2 = "v"
    //     0xef0cb0: add             x2, PP, #0x10, lsl #12  ; [pp+0x10718] "v"
    //     0xef0cb4: ldr             x2, [x2, #0x718]
    // 0xef0cb8: r0 = GDT[cid_x0 + 0x129dd]()
    //     0xef0cb8: mov             x17, #0x29dd
    //     0xef0cbc: movk            x17, #1, lsl #16
    //     0xef0cc0: add             lr, x0, x17
    //     0xef0cc4: ldr             lr, [x21, lr, lsl #3]
    //     0xef0cc8: blr             lr
    // 0xef0ccc: ldur            x0, [fp, #-0x10]
    // 0xef0cd0: tbnz            w0, #4, #0xef0cdc
    // 0xef0cd4: ldr             x1, [fp, #0x18]
    // 0xef0cd8: r0 = _markNeedsSerialization()
    //     0xef0cd8: bl              #0x850440  ; [package:flutter/src/services/restoration.dart] RestorationBucket::_markNeedsSerialization
    // 0xef0cdc: ldur            x0, [fp, #-8]
    // 0xef0ce0: LeaveFrame
    //     0xef0ce0: mov             SP, fp
    //     0xef0ce4: ldp             fp, lr, [SP], #0x10
    // 0xef0ce8: ret
    //     0xef0ce8: ret             
    // 0xef0cec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef0cec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef0cf0: b               #0xef0bcc
  }
  _ write(/* No info */) {
    // ** addr: 0xef0cf4, size: 0xf0
    // 0xef0cf4: EnterFrame
    //     0xef0cf4: stp             fp, lr, [SP, #-0x10]!
    //     0xef0cf8: mov             fp, SP
    // 0xef0cfc: AllocStack(0x10)
    //     0xef0cfc: sub             SP, SP, #0x10
    // 0xef0d00: CheckStackOverflow
    //     0xef0d00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef0d04: cmp             SP, x16
    //     0xef0d08: b.ls            #0xef0ddc
    // 0xef0d0c: ldr             x1, [fp, #0x20]
    // 0xef0d10: r0 = _rawValues()
    //     0xef0d10: bl              #0x850274  ; [package:flutter/src/services/restoration.dart] RestorationBucket::_rawValues
    // 0xef0d14: r1 = LoadClassIdInstr(r0)
    //     0xef0d14: ldur            x1, [x0, #-1]
    //     0xef0d18: ubfx            x1, x1, #0xc, #0x14
    // 0xef0d1c: mov             x16, x0
    // 0xef0d20: mov             x0, x1
    // 0xef0d24: mov             x1, x16
    // 0xef0d28: ldr             x2, [fp, #0x18]
    // 0xef0d2c: r0 = GDT[cid_x0 + -0xd48]()
    //     0xef0d2c: sub             lr, x0, #0xd48
    //     0xef0d30: ldr             lr, [x21, lr, lsl #3]
    //     0xef0d34: blr             lr
    // 0xef0d38: r1 = 60
    //     0xef0d38: mov             x1, #0x3c
    // 0xef0d3c: branchIfSmi(r0, 0xef0d48)
    //     0xef0d3c: tbz             w0, #0, #0xef0d48
    // 0xef0d40: r1 = LoadClassIdInstr(r0)
    //     0xef0d40: ldur            x1, [x0, #-1]
    //     0xef0d44: ubfx            x1, x1, #0xc, #0x14
    // 0xef0d48: ldr             x16, [fp, #0x10]
    // 0xef0d4c: stp             x16, x0, [SP]
    // 0xef0d50: mov             x0, x1
    // 0xef0d54: mov             lr, x0
    // 0xef0d58: ldr             lr, [x21, lr, lsl #3]
    // 0xef0d5c: blr             lr
    // 0xef0d60: tbnz            w0, #4, #0xef0d94
    // 0xef0d64: ldr             x1, [fp, #0x20]
    // 0xef0d68: r0 = _rawValues()
    //     0xef0d68: bl              #0x850274  ; [package:flutter/src/services/restoration.dart] RestorationBucket::_rawValues
    // 0xef0d6c: r1 = LoadClassIdInstr(r0)
    //     0xef0d6c: ldur            x1, [x0, #-1]
    //     0xef0d70: ubfx            x1, x1, #0xc, #0x14
    // 0xef0d74: mov             x16, x0
    // 0xef0d78: mov             x0, x1
    // 0xef0d7c: mov             x1, x16
    // 0xef0d80: ldr             x2, [fp, #0x18]
    // 0xef0d84: r0 = GDT[cid_x0 + -0x104]()
    //     0xef0d84: sub             lr, x0, #0x104
    //     0xef0d88: ldr             lr, [x21, lr, lsl #3]
    //     0xef0d8c: blr             lr
    // 0xef0d90: tbz             w0, #4, #0xef0dcc
    // 0xef0d94: ldr             x1, [fp, #0x20]
    // 0xef0d98: r0 = _rawValues()
    //     0xef0d98: bl              #0x850274  ; [package:flutter/src/services/restoration.dart] RestorationBucket::_rawValues
    // 0xef0d9c: r1 = LoadClassIdInstr(r0)
    //     0xef0d9c: ldur            x1, [x0, #-1]
    //     0xef0da0: ubfx            x1, x1, #0xc, #0x14
    // 0xef0da4: mov             x16, x0
    // 0xef0da8: mov             x0, x1
    // 0xef0dac: mov             x1, x16
    // 0xef0db0: ldr             x2, [fp, #0x18]
    // 0xef0db4: ldr             x3, [fp, #0x10]
    // 0xef0db8: r0 = GDT[cid_x0 + -0xd50]()
    //     0xef0db8: sub             lr, x0, #0xd50
    //     0xef0dbc: ldr             lr, [x21, lr, lsl #3]
    //     0xef0dc0: blr             lr
    // 0xef0dc4: ldr             x1, [fp, #0x20]
    // 0xef0dc8: r0 = _markNeedsSerialization()
    //     0xef0dc8: bl              #0x850440  ; [package:flutter/src/services/restoration.dart] RestorationBucket::_markNeedsSerialization
    // 0xef0dcc: r0 = Null
    //     0xef0dcc: mov             x0, NULL
    // 0xef0dd0: LeaveFrame
    //     0xef0dd0: mov             SP, fp
    //     0xef0dd4: ldp             fp, lr, [SP], #0x10
    // 0xef0dd8: ret
    //     0xef0dd8: ret             
    // 0xef0ddc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef0ddc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef0de0: b               #0xef0d0c
  }
  get _ isReplacing(/* No info */) {
    // ** addr: 0xef24c8, size: 0x38
    // 0xef24c8: LoadField: r2 = r1->field_b
    //     0xef24c8: ldur            w2, [x1, #0xb]
    // 0xef24cc: DecompressPointer r2
    //     0xef24cc: add             x2, x2, HEAP, lsl #32
    // 0xef24d0: cmp             w2, NULL
    // 0xef24d4: b.ne            #0xef24e0
    // 0xef24d8: r1 = Null
    //     0xef24d8: mov             x1, NULL
    // 0xef24dc: b               #0xef24e8
    // 0xef24e0: LoadField: r1 = r2->field_2f
    //     0xef24e0: ldur            w1, [x2, #0x2f]
    // 0xef24e4: DecompressPointer r1
    //     0xef24e4: add             x1, x1, HEAP, lsl #32
    // 0xef24e8: cmp             w1, NULL
    // 0xef24ec: b.ne            #0xef24f8
    // 0xef24f0: r0 = false
    //     0xef24f0: add             x0, NULL, #0x30  ; false
    // 0xef24f4: b               #0xef24fc
    // 0xef24f8: mov             x0, x1
    // 0xef24fc: ret
    //     0xef24fc: ret             
  }
  Y0? read<Y0>(RestorationBucket, String) {
    // ** addr: 0x1197884, size: 0xc0
    // 0x1197884: EnterFrame
    //     0x1197884: stp             fp, lr, [SP, #-0x10]!
    //     0x1197888: mov             fp, SP
    // 0x119788c: AllocStack(0x8)
    //     0x119788c: sub             SP, SP, #8
    // 0x1197890: SetupParameters()
    //     0x1197890: ldur            w0, [x4, #0xf]
    //     0x1197894: cbnz            w0, #0x11978a0
    //     0x1197898: mov             x0, NULL
    //     0x119789c: b               #0x11978b0
    //     0x11978a0: ldur            w0, [x4, #0x17]
    //     0x11978a4: add             x1, fp, w0, sxtw #2
    //     0x11978a8: ldr             x1, [x1, #0x10]
    //     0x11978ac: mov             x0, x1
    //     0x11978b0: stur            x0, [fp, #-8]
    // 0x11978b4: CheckStackOverflow
    //     0x11978b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11978b8: cmp             SP, x16
    //     0x11978bc: b.ls            #0x119793c
    // 0x11978c0: ldr             x1, [fp, #0x18]
    // 0x11978c4: r0 = _rawValues()
    //     0x11978c4: bl              #0x850274  ; [package:flutter/src/services/restoration.dart] RestorationBucket::_rawValues
    // 0x11978c8: r1 = LoadClassIdInstr(r0)
    //     0x11978c8: ldur            x1, [x0, #-1]
    //     0x11978cc: ubfx            x1, x1, #0xc, #0x14
    // 0x11978d0: mov             x16, x0
    // 0x11978d4: mov             x0, x1
    // 0x11978d8: mov             x1, x16
    // 0x11978dc: ldr             x2, [fp, #0x10]
    // 0x11978e0: r0 = GDT[cid_x0 + -0xd48]()
    //     0x11978e0: sub             lr, x0, #0xd48
    //     0x11978e4: ldr             lr, [x21, lr, lsl #3]
    //     0x11978e8: blr             lr
    // 0x11978ec: ldur            x1, [fp, #-8]
    // 0x11978f0: mov             x3, x0
    // 0x11978f4: r2 = Null
    //     0x11978f4: mov             x2, NULL
    // 0x11978f8: stur            x3, [fp, #-8]
    // 0x11978fc: cmp             w0, NULL
    // 0x1197900: b.eq            #0x119792c
    // 0x1197904: cmp             w1, NULL
    // 0x1197908: b.eq            #0x119792c
    // 0x119790c: ArrayLoad: r4 = r1[0]  ; List_4
    //     0x119790c: ldur            w4, [x1, #0x17]
    // 0x1197910: DecompressPointer r4
    //     0x1197910: add             x4, x4, HEAP, lsl #32
    // 0x1197914: r8 = Y0?
    //     0x1197914: add             x8, PP, #0x9a, lsl #12  ; [pp+0x9aa80] TypeParameter: Y0?
    //     0x1197918: ldr             x8, [x8, #0xa80]
    // 0x119791c: LoadField: r9 = r4->field_7
    //     0x119791c: ldur            x9, [x4, #7]
    // 0x1197920: r3 = Null
    //     0x1197920: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9ab70] Null
    //     0x1197924: ldr             x3, [x3, #0xb70]
    // 0x1197928: blr             x9
    // 0x119792c: ldur            x0, [fp, #-8]
    // 0x1197930: LeaveFrame
    //     0x1197930: mov             SP, fp
    //     0x1197934: ldp             fp, lr, [SP], #0x10
    // 0x1197938: ret
    //     0x1197938: ret             
    // 0x119793c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x119793c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1197940: b               #0x11978c0
  }
}

// class id: 4476, size: 0x3c, field offset: 0x24
class RestorationManager extends ChangeNotifier {

  _ RestorationManager(/* No info */) {
    // ** addr: 0x84fbec, size: 0xe0
    // 0x84fbec: EnterFrame
    //     0x84fbec: stp             fp, lr, [SP, #-0x10]!
    //     0x84fbf0: mov             fp, SP
    // 0x84fbf4: AllocStack(0x8)
    //     0x84fbf4: sub             SP, SP, #8
    // 0x84fbf8: r0 = false
    //     0x84fbf8: add             x0, NULL, #0x30  ; false
    // 0x84fbfc: mov             x2, x1
    // 0x84fc00: stur            x1, [fp, #-8]
    // 0x84fc04: CheckStackOverflow
    //     0x84fc04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84fc08: cmp             SP, x16
    //     0x84fc0c: b.ls            #0x84fcc4
    // 0x84fc10: StoreField: r2->field_2b = r0
    //     0x84fc10: stur            w0, [x2, #0x2b]
    // 0x84fc14: StoreField: r2->field_2f = r0
    //     0x84fc14: stur            w0, [x2, #0x2f]
    // 0x84fc18: StoreField: r2->field_33 = r0
    //     0x84fc18: stur            w0, [x2, #0x33]
    // 0x84fc1c: r1 = <RestorationBucket>
    //     0x84fc1c: ldr             x1, [PP, #0x4140]  ; [pp+0x4140] TypeArguments: <RestorationBucket>
    // 0x84fc20: r0 = _Set()
    //     0x84fc20: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x84fc24: mov             x1, x0
    // 0x84fc28: r0 = _Uint32List
    //     0x84fc28: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0x84fc2c: StoreField: r1->field_1b = r0
    //     0x84fc2c: stur            w0, [x1, #0x1b]
    // 0x84fc30: StoreField: r1->field_b = rZR
    //     0x84fc30: stur            wzr, [x1, #0xb]
    // 0x84fc34: r0 = const []
    //     0x84fc34: ldr             x0, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0x84fc38: StoreField: r1->field_f = r0
    //     0x84fc38: stur            w0, [x1, #0xf]
    // 0x84fc3c: StoreField: r1->field_13 = rZR
    //     0x84fc3c: stur            wzr, [x1, #0x13]
    // 0x84fc40: ArrayStore: r1[0] = rZR  ; List_4
    //     0x84fc40: stur            wzr, [x1, #0x17]
    // 0x84fc44: mov             x0, x1
    // 0x84fc48: ldur            x1, [fp, #-8]
    // 0x84fc4c: StoreField: r1->field_37 = r0
    //     0x84fc4c: stur            w0, [x1, #0x37]
    //     0x84fc50: ldurb           w16, [x1, #-1]
    //     0x84fc54: ldurb           w17, [x0, #-1]
    //     0x84fc58: and             x16, x17, x16, lsr #2
    //     0x84fc5c: tst             x16, HEAP, lsr #32
    //     0x84fc60: b.eq            #0x84fc68
    //     0x84fc64: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x84fc68: StoreField: r1->field_7 = rZR
    //     0x84fc68: stur            xzr, [x1, #7]
    // 0x84fc6c: StoreField: r1->field_13 = rZR
    //     0x84fc6c: stur            xzr, [x1, #0x13]
    // 0x84fc70: StoreField: r1->field_1b = rZR
    //     0x84fc70: stur            xzr, [x1, #0x1b]
    // 0x84fc74: r0 = LoadStaticField(0x45c)
    //     0x84fc74: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x84fc78: ldr             x0, [x0, #0x8b8]
    // 0x84fc7c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84fc80: cmp             w0, w16
    // 0x84fc84: b.ne            #0x84fc90
    // 0x84fc88: r2 = _emptyListeners
    //     0x84fc88: ldr             x2, [PP, #0x17f0]  ; [pp+0x17f0] Field <ChangeNotifier._emptyListeners@28329750>: static late final (offset: 0x45c)
    // 0x84fc8c: r0 = InitLateFinalStaticField()
    //     0x84fc8c: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x84fc90: ldur            x1, [fp, #-8]
    // 0x84fc94: StoreField: r1->field_f = r0
    //     0x84fc94: stur            w0, [x1, #0xf]
    //     0x84fc98: ldurb           w16, [x1, #-1]
    //     0x84fc9c: ldurb           w17, [x0, #-1]
    //     0x84fca0: and             x16, x17, x16, lsr #2
    //     0x84fca4: tst             x16, HEAP, lsr #32
    //     0x84fca8: b.eq            #0x84fcb0
    //     0x84fcac: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x84fcb0: r0 = initChannels()
    //     0x84fcb0: bl              #0x84fccc  ; [package:flutter/src/services/restoration.dart] RestorationManager::initChannels
    // 0x84fcb4: r0 = Null
    //     0x84fcb4: mov             x0, NULL
    // 0x84fcb8: LeaveFrame
    //     0x84fcb8: mov             SP, fp
    //     0x84fcbc: ldp             fp, lr, [SP], #0x10
    // 0x84fcc0: ret
    //     0x84fcc0: ret             
    // 0x84fcc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84fcc4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84fcc8: b               #0x84fc10
  }
  _ initChannels(/* No info */) {
    // ** addr: 0x84fccc, size: 0x44
    // 0x84fccc: EnterFrame
    //     0x84fccc: stp             fp, lr, [SP, #-0x10]!
    //     0x84fcd0: mov             fp, SP
    // 0x84fcd4: mov             x2, x1
    // 0x84fcd8: CheckStackOverflow
    //     0x84fcd8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84fcdc: cmp             SP, x16
    //     0x84fce0: b.ls            #0x84fd08
    // 0x84fce4: r1 = Function '_methodHandler@77347053':.
    //     0x84fce4: ldr             x1, [PP, #0x4148]  ; [pp+0x4148] AnonymousClosure: (0x84fd10), in [package:flutter/src/services/restoration.dart] RestorationManager::_methodHandler (0x84fd4c)
    // 0x84fce8: r0 = AllocateClosure()
    //     0x84fce8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x84fcec: mov             x2, x0
    // 0x84fcf0: r1 = Instance_OptionalMethodChannel
    //     0x84fcf0: ldr             x1, [PP, #0x4150]  ; [pp+0x4150] Obj!OptionalMethodChannel@129be81
    // 0x84fcf4: r0 = setMethodCallHandler()
    //     0x84fcf4: bl              #0x83aa3c  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::setMethodCallHandler
    // 0x84fcf8: r0 = Null
    //     0x84fcf8: mov             x0, NULL
    // 0x84fcfc: LeaveFrame
    //     0x84fcfc: mov             SP, fp
    //     0x84fd00: ldp             fp, lr, [SP], #0x10
    // 0x84fd04: ret
    //     0x84fd04: ret             
    // 0x84fd08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84fd08: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84fd0c: b               #0x84fce4
  }
  [closure] Future<void> _methodHandler(dynamic, MethodCall) {
    // ** addr: 0x84fd10, size: 0x3c
    // 0x84fd10: EnterFrame
    //     0x84fd10: stp             fp, lr, [SP, #-0x10]!
    //     0x84fd14: mov             fp, SP
    // 0x84fd18: ldr             x0, [fp, #0x18]
    // 0x84fd1c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x84fd1c: ldur            w1, [x0, #0x17]
    // 0x84fd20: DecompressPointer r1
    //     0x84fd20: add             x1, x1, HEAP, lsl #32
    // 0x84fd24: CheckStackOverflow
    //     0x84fd24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84fd28: cmp             SP, x16
    //     0x84fd2c: b.ls            #0x84fd44
    // 0x84fd30: ldr             x2, [fp, #0x10]
    // 0x84fd34: r0 = _methodHandler()
    //     0x84fd34: bl              #0x84fd4c  ; [package:flutter/src/services/restoration.dart] RestorationManager::_methodHandler
    // 0x84fd38: LeaveFrame
    //     0x84fd38: mov             SP, fp
    //     0x84fd3c: ldp             fp, lr, [SP], #0x10
    // 0x84fd40: ret
    //     0x84fd40: ret             
    // 0x84fd44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84fd44: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84fd48: b               #0x84fd30
  }
  _ _methodHandler(/* No info */) async {
    // ** addr: 0x84fd4c, size: 0xe4
    // 0x84fd4c: EnterFrame
    //     0x84fd4c: stp             fp, lr, [SP, #-0x10]!
    //     0x84fd50: mov             fp, SP
    // 0x84fd54: AllocStack(0x38)
    //     0x84fd54: sub             SP, SP, #0x38
    // 0x84fd58: SetupParameters(RestorationManager this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0x84fd58: stur            NULL, [fp, #-8]
    //     0x84fd5c: stur            x1, [fp, #-0x10]
    //     0x84fd60: stur            x2, [fp, #-0x18]
    // 0x84fd64: CheckStackOverflow
    //     0x84fd64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84fd68: cmp             SP, x16
    //     0x84fd6c: b.ls            #0x84fe28
    // 0x84fd70: InitAsync() -> Future<void?>
    //     0x84fd70: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0x84fd74: bl              #0x7f5e44  ; InitAsyncStub
    // 0x84fd78: ldur            x0, [fp, #-0x18]
    // 0x84fd7c: LoadField: r1 = r0->field_7
    //     0x84fd7c: ldur            w1, [x0, #7]
    // 0x84fd80: DecompressPointer r1
    //     0x84fd80: add             x1, x1, HEAP, lsl #32
    // 0x84fd84: stur            x1, [fp, #-0x20]
    // 0x84fd88: r16 = "push"
    //     0x84fd88: ldr             x16, [PP, #0x4158]  ; [pp+0x4158] "push"
    // 0x84fd8c: stp             x1, x16, [SP]
    // 0x84fd90: r0 = ==()
    //     0x84fd90: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x84fd94: tbnz            w0, #4, #0x84fdd4
    // 0x84fd98: ldur            x0, [fp, #-0x18]
    // 0x84fd9c: LoadField: r3 = r0->field_b
    //     0x84fd9c: ldur            w3, [x0, #0xb]
    // 0x84fda0: DecompressPointer r3
    //     0x84fda0: add             x3, x3, HEAP, lsl #32
    // 0x84fda4: mov             x0, x3
    // 0x84fda8: stur            x3, [fp, #-0x28]
    // 0x84fdac: r2 = Null
    //     0x84fdac: mov             x2, NULL
    // 0x84fdb0: r1 = Null
    //     0x84fdb0: mov             x1, NULL
    // 0x84fdb4: r8 = Map<Object?, Object?>
    //     0x84fdb4: ldr             x8, [PP, #0x3238]  ; [pp+0x3238] Type: Map<Object?, Object?>
    // 0x84fdb8: r3 = Null
    //     0x84fdb8: ldr             x3, [PP, #0x4160]  ; [pp+0x4160] Null
    // 0x84fdbc: r0 = Map<Object?, Object?>()
    //     0x84fdbc: bl              #0x851560  ; IsType_Map<Object?, Object?>_Stub
    // 0x84fdc0: ldur            x1, [fp, #-0x10]
    // 0x84fdc4: ldur            x2, [fp, #-0x28]
    // 0x84fdc8: r0 = _parseAndHandleRestorationUpdateFromEngine()
    //     0x84fdc8: bl              #0x84fe30  ; [package:flutter/src/services/restoration.dart] RestorationManager::_parseAndHandleRestorationUpdateFromEngine
    // 0x84fdcc: r0 = Null
    //     0x84fdcc: mov             x0, NULL
    // 0x84fdd0: r0 = ReturnAsyncNotFuture()
    //     0x84fdd0: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x84fdd4: ldur            x0, [fp, #-0x20]
    // 0x84fdd8: r1 = Null
    //     0x84fdd8: mov             x1, NULL
    // 0x84fddc: r2 = 6
    //     0x84fddc: mov             x2, #6
    // 0x84fde0: r0 = AllocateArray()
    //     0x84fde0: bl              #0x13df928  ; AllocateArrayStub
    // 0x84fde4: mov             x1, x0
    // 0x84fde8: ldur            x0, [fp, #-0x20]
    // 0x84fdec: StoreField: r1->field_f = r0
    //     0x84fdec: stur            w0, [x1, #0xf]
    // 0x84fdf0: r16 = " was invoked but isn\'t implemented by "
    //     0x84fdf0: ldr             x16, [PP, #0x4170]  ; [pp+0x4170] " was invoked but isn\'t implemented by "
    // 0x84fdf4: StoreField: r1->field_13 = r16
    //     0x84fdf4: stur            w16, [x1, #0x13]
    // 0x84fdf8: r16 = RestorationManager
    //     0x84fdf8: ldr             x16, [PP, #0x4178]  ; [pp+0x4178] Type: RestorationManager
    // 0x84fdfc: ArrayStore: r1[0] = r16  ; List_4
    //     0x84fdfc: stur            w16, [x1, #0x17]
    // 0x84fe00: str             x1, [SP]
    // 0x84fe04: r0 = _interpolate()
    //     0x84fe04: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x84fe08: stur            x0, [fp, #-0x10]
    // 0x84fe0c: r0 = UnimplementedError()
    //     0x84fe0c: bl              #0x7dd7c4  ; AllocateUnimplementedErrorStub -> UnimplementedError (size=0x10)
    // 0x84fe10: mov             x1, x0
    // 0x84fe14: ldur            x0, [fp, #-0x10]
    // 0x84fe18: StoreField: r1->field_b = r0
    //     0x84fe18: stur            w0, [x1, #0xb]
    // 0x84fe1c: mov             x0, x1
    // 0x84fe20: r0 = Throw()
    //     0x84fe20: bl              #0x13ddb2c  ; ThrowStub
    // 0x84fe24: brk             #0
    // 0x84fe28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84fe28: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84fe2c: b               #0x84fd70
  }
  _ _parseAndHandleRestorationUpdateFromEngine(/* No info */) {
    // ** addr: 0x84fe30, size: 0x104
    // 0x84fe30: EnterFrame
    //     0x84fe30: stp             fp, lr, [SP, #-0x10]!
    //     0x84fe34: mov             fp, SP
    // 0x84fe38: AllocStack(0x18)
    //     0x84fe38: sub             SP, SP, #0x18
    // 0x84fe3c: SetupParameters(RestorationManager this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x84fe3c: mov             x4, x1
    //     0x84fe40: mov             x3, x2
    //     0x84fe44: stur            x1, [fp, #-8]
    //     0x84fe48: stur            x2, [fp, #-0x10]
    // 0x84fe4c: CheckStackOverflow
    //     0x84fe4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84fe50: cmp             SP, x16
    //     0x84fe54: b.ls            #0x84ff28
    // 0x84fe58: r0 = LoadClassIdInstr(r3)
    //     0x84fe58: ldur            x0, [x3, #-1]
    //     0x84fe5c: ubfx            x0, x0, #0xc, #0x14
    // 0x84fe60: mov             x1, x3
    // 0x84fe64: r2 = "enabled"
    //     0x84fe64: ldr             x2, [PP, #0x4180]  ; [pp+0x4180] "enabled"
    // 0x84fe68: r0 = GDT[cid_x0 + -0xd48]()
    //     0x84fe68: sub             lr, x0, #0xd48
    //     0x84fe6c: ldr             lr, [x21, lr, lsl #3]
    //     0x84fe70: blr             lr
    // 0x84fe74: mov             x3, x0
    // 0x84fe78: stur            x3, [fp, #-0x18]
    // 0x84fe7c: cmp             w3, NULL
    // 0x84fe80: b.eq            #0x84ff30
    // 0x84fe84: mov             x0, x3
    // 0x84fe88: r2 = Null
    //     0x84fe88: mov             x2, NULL
    // 0x84fe8c: r1 = Null
    //     0x84fe8c: mov             x1, NULL
    // 0x84fe90: r4 = 60
    //     0x84fe90: mov             x4, #0x3c
    // 0x84fe94: branchIfSmi(r0, 0x84fea0)
    //     0x84fe94: tbz             w0, #0, #0x84fea0
    // 0x84fe98: r4 = LoadClassIdInstr(r0)
    //     0x84fe98: ldur            x4, [x0, #-1]
    //     0x84fe9c: ubfx            x4, x4, #0xc, #0x14
    // 0x84fea0: cmp             x4, #0x3f
    // 0x84fea4: b.eq            #0x84feb4
    // 0x84fea8: r8 = bool
    //     0x84fea8: ldr             x8, [PP, #0xb18]  ; [pp+0xb18] Type: bool
    // 0x84feac: r3 = Null
    //     0x84feac: ldr             x3, [PP, #0x4188]  ; [pp+0x4188] Null
    // 0x84feb0: r0 = bool()
    //     0x84feb0: bl              #0x13ee15c  ; IsType_bool_Stub
    // 0x84feb4: ldur            x1, [fp, #-0x10]
    // 0x84feb8: r0 = LoadClassIdInstr(r1)
    //     0x84feb8: ldur            x0, [x1, #-1]
    //     0x84febc: ubfx            x0, x0, #0xc, #0x14
    // 0x84fec0: r2 = "data"
    //     0x84fec0: ldr             x2, [PP, #0x1370]  ; [pp+0x1370] "data"
    // 0x84fec4: r0 = GDT[cid_x0 + -0xd48]()
    //     0x84fec4: sub             lr, x0, #0xd48
    //     0x84fec8: ldr             lr, [x21, lr, lsl #3]
    //     0x84fecc: blr             lr
    // 0x84fed0: mov             x3, x0
    // 0x84fed4: r2 = Null
    //     0x84fed4: mov             x2, NULL
    // 0x84fed8: r1 = Null
    //     0x84fed8: mov             x1, NULL
    // 0x84fedc: stur            x3, [fp, #-0x10]
    // 0x84fee0: r4 = 60
    //     0x84fee0: mov             x4, #0x3c
    // 0x84fee4: branchIfSmi(r0, 0x84fef0)
    //     0x84fee4: tbz             w0, #0, #0x84fef0
    // 0x84fee8: r4 = LoadClassIdInstr(r0)
    //     0x84fee8: ldur            x4, [x0, #-1]
    //     0x84feec: ubfx            x4, x4, #0xc, #0x14
    // 0x84fef0: sub             x4, x4, #0x74
    // 0x84fef4: cmp             x4, #3
    // 0x84fef8: b.ls            #0x84ff08
    // 0x84fefc: r8 = Uint8List?
    //     0x84fefc: ldr             x8, [PP, #0x4198]  ; [pp+0x4198] Type: Uint8List?
    // 0x84ff00: r3 = Null
    //     0x84ff00: ldr             x3, [PP, #0x41a0]  ; [pp+0x41a0] Null
    // 0x84ff04: r0 = Uint8List?()
    //     0x84ff04: bl              #0x822e74  ; IsType_Uint8List?_Stub
    // 0x84ff08: ldur            x1, [fp, #-8]
    // 0x84ff0c: ldur            x2, [fp, #-0x10]
    // 0x84ff10: ldur            x3, [fp, #-0x18]
    // 0x84ff14: r0 = handleRestorationUpdateFromEngine()
    //     0x84ff14: bl              #0x84ff34  ; [package:flutter/src/services/restoration.dart] RestorationManager::handleRestorationUpdateFromEngine
    // 0x84ff18: r0 = Null
    //     0x84ff18: mov             x0, NULL
    // 0x84ff1c: LeaveFrame
    //     0x84ff1c: mov             SP, fp
    //     0x84ff20: ldp             fp, lr, [SP], #0x10
    // 0x84ff24: ret
    //     0x84ff24: ret             
    // 0x84ff28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84ff28: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84ff2c: b               #0x84fe58
    // 0x84ff30: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84ff30: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ handleRestorationUpdateFromEngine(/* No info */) {
    // ** addr: 0x84ff34, size: 0x1ec
    // 0x84ff34: EnterFrame
    //     0x84ff34: stp             fp, lr, [SP, #-0x10]!
    //     0x84ff38: mov             fp, SP
    // 0x84ff3c: AllocStack(0x30)
    //     0x84ff3c: sub             SP, SP, #0x30
    // 0x84ff40: SetupParameters(RestorationManager this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x84ff40: stur            x1, [fp, #-8]
    //     0x84ff44: stur            x2, [fp, #-0x10]
    //     0x84ff48: stur            x3, [fp, #-0x18]
    // 0x84ff4c: CheckStackOverflow
    //     0x84ff4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84ff50: cmp             SP, x16
    //     0x84ff54: b.ls            #0x850114
    // 0x84ff58: r1 = 1
    //     0x84ff58: mov             x1, #1
    // 0x84ff5c: r0 = AllocateContext()
    //     0x84ff5c: bl              #0x13de838  ; AllocateContextStub
    // 0x84ff60: mov             x1, x0
    // 0x84ff64: ldur            x0, [fp, #-8]
    // 0x84ff68: StoreField: r1->field_f = r0
    //     0x84ff68: stur            w0, [x1, #0xf]
    // 0x84ff6c: LoadField: r2 = r0->field_2b
    //     0x84ff6c: ldur            w2, [x0, #0x2b]
    // 0x84ff70: DecompressPointer r2
    //     0x84ff70: add             x2, x2, HEAP, lsl #32
    // 0x84ff74: tbnz            w2, #4, #0x84ff80
    // 0x84ff78: ldur            x2, [fp, #-0x18]
    // 0x84ff7c: b               #0x84ff84
    // 0x84ff80: r2 = false
    //     0x84ff80: add             x2, NULL, #0x30  ; false
    // 0x84ff84: StoreField: r0->field_2f = r2
    //     0x84ff84: stur            w2, [x0, #0x2f]
    // 0x84ff88: tbnz            w2, #4, #0x850068
    // 0x84ff8c: r2 = LoadStaticField(0x5e4)
    //     0x84ff8c: ldr             x2, [THR, #0x78]  ; THR::field_table_values
    //     0x84ff90: ldr             x2, [x2, #0xbc8]
    // 0x84ff94: cmp             w2, NULL
    // 0x84ff98: b.eq            #0x85011c
    // 0x84ff9c: LoadField: r3 = r2->field_53
    //     0x84ff9c: ldur            w3, [x2, #0x53]
    // 0x84ffa0: DecompressPointer r3
    //     0x84ffa0: add             x3, x3, HEAP, lsl #32
    // 0x84ffa4: stur            x3, [fp, #-0x28]
    // 0x84ffa8: LoadField: r4 = r3->field_7
    //     0x84ffa8: ldur            w4, [x3, #7]
    // 0x84ffac: DecompressPointer r4
    //     0x84ffac: add             x4, x4, HEAP, lsl #32
    // 0x84ffb0: mov             x2, x1
    // 0x84ffb4: stur            x4, [fp, #-0x20]
    // 0x84ffb8: r1 = Function '<anonymous closure>':.
    //     0x84ffb8: ldr             x1, [PP, #0x41b0]  ; [pp+0x41b0] AnonymousClosure: (0x85153c), in [package:flutter/src/services/restoration.dart] RestorationManager::handleRestorationUpdateFromEngine (0x84ff34)
    // 0x84ffbc: r0 = AllocateClosure()
    //     0x84ffbc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x84ffc0: ldur            x2, [fp, #-0x20]
    // 0x84ffc4: mov             x3, x0
    // 0x84ffc8: r1 = Null
    //     0x84ffc8: mov             x1, NULL
    // 0x84ffcc: stur            x3, [fp, #-0x20]
    // 0x84ffd0: cmp             w2, NULL
    // 0x84ffd4: b.eq            #0x84fff0
    // 0x84ffd8: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x84ffd8: ldur            w4, [x2, #0x17]
    // 0x84ffdc: DecompressPointer r4
    //     0x84ffdc: add             x4, x4, HEAP, lsl #32
    // 0x84ffe0: r8 = X0
    //     0x84ffe0: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x84ffe4: LoadField: r9 = r4->field_7
    //     0x84ffe4: ldur            x9, [x4, #7]
    // 0x84ffe8: r3 = Null
    //     0x84ffe8: ldr             x3, [PP, #0x41b8]  ; [pp+0x41b8] Null
    // 0x84ffec: blr             x9
    // 0x84fff0: ldur            x0, [fp, #-0x28]
    // 0x84fff4: LoadField: r1 = r0->field_b
    //     0x84fff4: ldur            w1, [x0, #0xb]
    // 0x84fff8: LoadField: r2 = r0->field_f
    //     0x84fff8: ldur            w2, [x0, #0xf]
    // 0x84fffc: DecompressPointer r2
    //     0x84fffc: add             x2, x2, HEAP, lsl #32
    // 0x850000: LoadField: r3 = r2->field_b
    //     0x850000: ldur            w3, [x2, #0xb]
    // 0x850004: r2 = LoadInt32Instr(r1)
    //     0x850004: sbfx            x2, x1, #1, #0x1f
    // 0x850008: stur            x2, [fp, #-0x30]
    // 0x85000c: r1 = LoadInt32Instr(r3)
    //     0x85000c: sbfx            x1, x3, #1, #0x1f
    // 0x850010: cmp             x2, x1
    // 0x850014: b.ne            #0x850020
    // 0x850018: mov             x1, x0
    // 0x85001c: r0 = _growToNextCapacity()
    //     0x85001c: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x850020: ldur            x0, [fp, #-0x28]
    // 0x850024: ldur            x2, [fp, #-0x30]
    // 0x850028: add             x1, x2, #1
    // 0x85002c: lsl             x3, x1, #1
    // 0x850030: StoreField: r0->field_b = r3
    //     0x850030: stur            w3, [x0, #0xb]
    // 0x850034: LoadField: r1 = r0->field_f
    //     0x850034: ldur            w1, [x0, #0xf]
    // 0x850038: DecompressPointer r1
    //     0x850038: add             x1, x1, HEAP, lsl #32
    // 0x85003c: ldur            x0, [fp, #-0x20]
    // 0x850040: ArrayStore: r1[r2] = r0  ; List_4
    //     0x850040: add             x25, x1, x2, lsl #2
    //     0x850044: add             x25, x25, #0xf
    //     0x850048: str             w0, [x25]
    //     0x85004c: tbz             w0, #0, #0x850068
    //     0x850050: ldurb           w16, [x1, #-1]
    //     0x850054: ldurb           w17, [x0, #-1]
    //     0x850058: and             x16, x17, x16, lsr #2
    //     0x85005c: tst             x16, HEAP, lsr #32
    //     0x850060: b.eq            #0x850068
    //     0x850064: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x850068: ldur            x0, [fp, #-8]
    // 0x85006c: ldur            x1, [fp, #-0x18]
    // 0x850070: LoadField: r3 = r0->field_23
    //     0x850070: ldur            w3, [x0, #0x23]
    // 0x850074: DecompressPointer r3
    //     0x850074: add             x3, x3, HEAP, lsl #32
    // 0x850078: stur            x3, [fp, #-0x20]
    // 0x85007c: tbnz            w1, #4, #0x8500b0
    // 0x850080: mov             x1, x0
    // 0x850084: ldur            x2, [fp, #-0x10]
    // 0x850088: r0 = _decodeRestorationData()
    //     0x850088: bl              #0x8513c0  ; [package:flutter/src/services/restoration.dart] RestorationManager::_decodeRestorationData
    // 0x85008c: stur            x0, [fp, #-0x10]
    // 0x850090: r0 = RestorationBucket()
    //     0x850090: bl              #0x8513b4  ; AllocateRestorationBucketStub -> RestorationBucket (size=0x24)
    // 0x850094: mov             x1, x0
    // 0x850098: ldur            x2, [fp, #-8]
    // 0x85009c: ldur            x3, [fp, #-0x10]
    // 0x8500a0: stur            x0, [fp, #-0x10]
    // 0x8500a4: r0 = RestorationBucket.root()
    //     0x8500a4: bl              #0x8512a0  ; [package:flutter/src/services/restoration.dart] RestorationBucket::RestorationBucket.root
    // 0x8500a8: ldur            x4, [fp, #-0x10]
    // 0x8500ac: b               #0x8500b4
    // 0x8500b0: r4 = Null
    //     0x8500b0: mov             x4, NULL
    // 0x8500b4: ldur            x1, [fp, #-8]
    // 0x8500b8: ldur            x2, [fp, #-0x20]
    // 0x8500bc: r3 = true
    //     0x8500bc: add             x3, NULL, #0x20  ; true
    // 0x8500c0: mov             x0, x4
    // 0x8500c4: StoreField: r1->field_23 = r0
    //     0x8500c4: stur            w0, [x1, #0x23]
    //     0x8500c8: ldurb           w16, [x1, #-1]
    //     0x8500cc: ldurb           w17, [x0, #-1]
    //     0x8500d0: and             x16, x17, x16, lsr #2
    //     0x8500d4: tst             x16, HEAP, lsr #32
    //     0x8500d8: b.eq            #0x8500e0
    //     0x8500dc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8500e0: StoreField: r1->field_2b = r3
    //     0x8500e0: stur            w3, [x1, #0x2b]
    // 0x8500e4: StoreField: r1->field_27 = rNULL
    //     0x8500e4: stur            NULL, [x1, #0x27]
    // 0x8500e8: cmp             w4, w2
    // 0x8500ec: b.eq            #0x850104
    // 0x8500f0: r0 = notifyListeners()
    //     0x8500f0: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x8500f4: ldur            x1, [fp, #-0x20]
    // 0x8500f8: cmp             w1, NULL
    // 0x8500fc: b.eq            #0x850104
    // 0x850100: r0 = dispose()
    //     0x850100: bl              #0x850120  ; [package:flutter/src/services/restoration.dart] RestorationBucket::dispose
    // 0x850104: r0 = Null
    //     0x850104: mov             x0, NULL
    // 0x850108: LeaveFrame
    //     0x850108: mov             SP, fp
    //     0x85010c: ldp             fp, lr, [SP], #0x10
    // 0x850110: ret
    //     0x850110: ret             
    // 0x850114: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x850114: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x850118: b               #0x84ff58
    // 0x85011c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x85011c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ scheduleSerializationFor(/* No info */) {
    // ** addr: 0x850498, size: 0x158
    // 0x850498: EnterFrame
    //     0x850498: stp             fp, lr, [SP, #-0x10]!
    //     0x85049c: mov             fp, SP
    // 0x8504a0: AllocStack(0x20)
    //     0x8504a0: sub             SP, SP, #0x20
    // 0x8504a4: SetupParameters(RestorationManager this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x8504a4: stur            x1, [fp, #-8]
    //     0x8504a8: stur            x2, [fp, #-0x10]
    // 0x8504ac: CheckStackOverflow
    //     0x8504ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8504b0: cmp             SP, x16
    //     0x8504b4: b.ls            #0x8505e4
    // 0x8504b8: r1 = 1
    //     0x8504b8: mov             x1, #1
    // 0x8504bc: r0 = AllocateContext()
    //     0x8504bc: bl              #0x13de838  ; AllocateContextStub
    // 0x8504c0: mov             x3, x0
    // 0x8504c4: ldur            x0, [fp, #-8]
    // 0x8504c8: stur            x3, [fp, #-0x18]
    // 0x8504cc: StoreField: r3->field_f = r0
    //     0x8504cc: stur            w0, [x3, #0xf]
    // 0x8504d0: LoadField: r1 = r0->field_37
    //     0x8504d0: ldur            w1, [x0, #0x37]
    // 0x8504d4: DecompressPointer r1
    //     0x8504d4: add             x1, x1, HEAP, lsl #32
    // 0x8504d8: ldur            x2, [fp, #-0x10]
    // 0x8504dc: r0 = add()
    //     0x8504dc: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x8504e0: ldur            x0, [fp, #-8]
    // 0x8504e4: LoadField: r1 = r0->field_33
    //     0x8504e4: ldur            w1, [x0, #0x33]
    // 0x8504e8: DecompressPointer r1
    //     0x8504e8: add             x1, x1, HEAP, lsl #32
    // 0x8504ec: tbz             w1, #4, #0x8505d4
    // 0x8504f0: r1 = true
    //     0x8504f0: add             x1, NULL, #0x20  ; true
    // 0x8504f4: StoreField: r0->field_33 = r1
    //     0x8504f4: stur            w1, [x0, #0x33]
    // 0x8504f8: r0 = LoadStaticField(0x5e4)
    //     0x8504f8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8504fc: ldr             x0, [x0, #0xbc8]
    // 0x850500: cmp             w0, NULL
    // 0x850504: b.eq            #0x8505ec
    // 0x850508: LoadField: r3 = r0->field_53
    //     0x850508: ldur            w3, [x0, #0x53]
    // 0x85050c: DecompressPointer r3
    //     0x85050c: add             x3, x3, HEAP, lsl #32
    // 0x850510: stur            x3, [fp, #-0x10]
    // 0x850514: LoadField: r0 = r3->field_7
    //     0x850514: ldur            w0, [x3, #7]
    // 0x850518: DecompressPointer r0
    //     0x850518: add             x0, x0, HEAP, lsl #32
    // 0x85051c: ldur            x2, [fp, #-0x18]
    // 0x850520: stur            x0, [fp, #-8]
    // 0x850524: r1 = Function '<anonymous closure>':.
    //     0x850524: ldr             x1, [PP, #0x41e0]  ; [pp+0x41e0] AnonymousClosure: (0x8505f0), in [package:flutter/src/services/restoration.dart] RestorationManager::scheduleSerializationFor (0x850498)
    // 0x850528: r0 = AllocateClosure()
    //     0x850528: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x85052c: ldur            x2, [fp, #-8]
    // 0x850530: mov             x3, x0
    // 0x850534: r1 = Null
    //     0x850534: mov             x1, NULL
    // 0x850538: stur            x3, [fp, #-8]
    // 0x85053c: cmp             w2, NULL
    // 0x850540: b.eq            #0x85055c
    // 0x850544: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x850544: ldur            w4, [x2, #0x17]
    // 0x850548: DecompressPointer r4
    //     0x850548: add             x4, x4, HEAP, lsl #32
    // 0x85054c: r8 = X0
    //     0x85054c: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x850550: LoadField: r9 = r4->field_7
    //     0x850550: ldur            x9, [x4, #7]
    // 0x850554: r3 = Null
    //     0x850554: ldr             x3, [PP, #0x41e8]  ; [pp+0x41e8] Null
    // 0x850558: blr             x9
    // 0x85055c: ldur            x0, [fp, #-0x10]
    // 0x850560: LoadField: r1 = r0->field_b
    //     0x850560: ldur            w1, [x0, #0xb]
    // 0x850564: LoadField: r2 = r0->field_f
    //     0x850564: ldur            w2, [x0, #0xf]
    // 0x850568: DecompressPointer r2
    //     0x850568: add             x2, x2, HEAP, lsl #32
    // 0x85056c: LoadField: r3 = r2->field_b
    //     0x85056c: ldur            w3, [x2, #0xb]
    // 0x850570: r2 = LoadInt32Instr(r1)
    //     0x850570: sbfx            x2, x1, #1, #0x1f
    // 0x850574: stur            x2, [fp, #-0x20]
    // 0x850578: r1 = LoadInt32Instr(r3)
    //     0x850578: sbfx            x1, x3, #1, #0x1f
    // 0x85057c: cmp             x2, x1
    // 0x850580: b.ne            #0x85058c
    // 0x850584: mov             x1, x0
    // 0x850588: r0 = _growToNextCapacity()
    //     0x850588: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x85058c: ldur            x2, [fp, #-0x10]
    // 0x850590: ldur            x3, [fp, #-0x20]
    // 0x850594: add             x4, x3, #1
    // 0x850598: lsl             x5, x4, #1
    // 0x85059c: StoreField: r2->field_b = r5
    //     0x85059c: stur            w5, [x2, #0xb]
    // 0x8505a0: LoadField: r1 = r2->field_f
    //     0x8505a0: ldur            w1, [x2, #0xf]
    // 0x8505a4: DecompressPointer r1
    //     0x8505a4: add             x1, x1, HEAP, lsl #32
    // 0x8505a8: ldur            x0, [fp, #-8]
    // 0x8505ac: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8505ac: add             x25, x1, x3, lsl #2
    //     0x8505b0: add             x25, x25, #0xf
    //     0x8505b4: str             w0, [x25]
    //     0x8505b8: tbz             w0, #0, #0x8505d4
    //     0x8505bc: ldurb           w16, [x1, #-1]
    //     0x8505c0: ldurb           w17, [x0, #-1]
    //     0x8505c4: and             x16, x17, x16, lsr #2
    //     0x8505c8: tst             x16, HEAP, lsr #32
    //     0x8505cc: b.eq            #0x8505d4
    //     0x8505d0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x8505d4: r0 = Null
    //     0x8505d4: mov             x0, NULL
    // 0x8505d8: LeaveFrame
    //     0x8505d8: mov             SP, fp
    //     0x8505dc: ldp             fp, lr, [SP], #0x10
    // 0x8505e0: ret
    //     0x8505e0: ret             
    // 0x8505e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8505e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8505e8: b               #0x8504b8
    // 0x8505ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8505ec: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, Duration) {
    // ** addr: 0x8505f0, size: 0x48
    // 0x8505f0: EnterFrame
    //     0x8505f0: stp             fp, lr, [SP, #-0x10]!
    //     0x8505f4: mov             fp, SP
    // 0x8505f8: ldr             x0, [fp, #0x18]
    // 0x8505fc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8505fc: ldur            w1, [x0, #0x17]
    // 0x850600: DecompressPointer r1
    //     0x850600: add             x1, x1, HEAP, lsl #32
    // 0x850604: CheckStackOverflow
    //     0x850604: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x850608: cmp             SP, x16
    //     0x85060c: b.ls            #0x850630
    // 0x850610: LoadField: r0 = r1->field_f
    //     0x850610: ldur            w0, [x1, #0xf]
    // 0x850614: DecompressPointer r0
    //     0x850614: add             x0, x0, HEAP, lsl #32
    // 0x850618: mov             x1, x0
    // 0x85061c: r0 = _doSerialization()
    //     0x85061c: bl              #0x850638  ; [package:flutter/src/services/restoration.dart] RestorationManager::_doSerialization
    // 0x850620: r0 = Null
    //     0x850620: mov             x0, NULL
    // 0x850624: LeaveFrame
    //     0x850624: mov             SP, fp
    //     0x850628: ldp             fp, lr, [SP], #0x10
    // 0x85062c: ret
    //     0x85062c: ret             
    // 0x850630: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x850630: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x850634: b               #0x850610
  }
  _ _doSerialization(/* No info */) {
    // ** addr: 0x850638, size: 0x13c
    // 0x850638: EnterFrame
    //     0x850638: stp             fp, lr, [SP, #-0x10]!
    //     0x85063c: mov             fp, SP
    // 0x850640: AllocStack(0x28)
    //     0x850640: sub             SP, SP, #0x28
    // 0x850644: SetupParameters(RestorationManager this /* r1 => r0, fp-0x10 */)
    //     0x850644: mov             x0, x1
    //     0x850648: stur            x1, [fp, #-0x10]
    // 0x85064c: CheckStackOverflow
    //     0x85064c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x850650: cmp             SP, x16
    //     0x850654: b.ls            #0x850760
    // 0x850658: LoadField: r1 = r0->field_33
    //     0x850658: ldur            w1, [x0, #0x33]
    // 0x85065c: DecompressPointer r1
    //     0x85065c: add             x1, x1, HEAP, lsl #32
    // 0x850660: tbz             w1, #4, #0x850674
    // 0x850664: r0 = Null
    //     0x850664: mov             x0, NULL
    // 0x850668: LeaveFrame
    //     0x850668: mov             SP, fp
    //     0x85066c: ldp             fp, lr, [SP], #0x10
    // 0x850670: ret
    //     0x850670: ret             
    // 0x850674: r2 = false
    //     0x850674: add             x2, NULL, #0x30  ; false
    // 0x850678: StoreField: r0->field_33 = r2
    //     0x850678: stur            w2, [x0, #0x33]
    // 0x85067c: LoadField: r3 = r0->field_37
    //     0x85067c: ldur            w3, [x0, #0x37]
    // 0x850680: DecompressPointer r3
    //     0x850680: add             x3, x3, HEAP, lsl #32
    // 0x850684: mov             x1, x3
    // 0x850688: stur            x3, [fp, #-8]
    // 0x85068c: r0 = iterator()
    //     0x85068c: bl              #0xbb7c60  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0x850690: stur            x0, [fp, #-0x20]
    // 0x850694: LoadField: r2 = r0->field_7
    //     0x850694: ldur            w2, [x0, #7]
    // 0x850698: DecompressPointer r2
    //     0x850698: add             x2, x2, HEAP, lsl #32
    // 0x85069c: stur            x2, [fp, #-0x18]
    // 0x8506a0: CheckStackOverflow
    //     0x8506a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8506a4: cmp             SP, x16
    //     0x8506a8: b.ls            #0x850768
    // 0x8506ac: mov             x1, x0
    // 0x8506b0: r0 = moveNext()
    //     0x8506b0: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0x8506b4: tbnz            w0, #4, #0x850714
    // 0x8506b8: ldur            x3, [fp, #-0x20]
    // 0x8506bc: LoadField: r4 = r3->field_33
    //     0x8506bc: ldur            w4, [x3, #0x33]
    // 0x8506c0: DecompressPointer r4
    //     0x8506c0: add             x4, x4, HEAP, lsl #32
    // 0x8506c4: stur            x4, [fp, #-0x28]
    // 0x8506c8: cmp             w4, NULL
    // 0x8506cc: b.ne            #0x8506fc
    // 0x8506d0: mov             x0, x4
    // 0x8506d4: ldur            x2, [fp, #-0x18]
    // 0x8506d8: r1 = Null
    //     0x8506d8: mov             x1, NULL
    // 0x8506dc: cmp             w2, NULL
    // 0x8506e0: b.eq            #0x8506fc
    // 0x8506e4: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x8506e4: ldur            w4, [x2, #0x17]
    // 0x8506e8: DecompressPointer r4
    //     0x8506e8: add             x4, x4, HEAP, lsl #32
    // 0x8506ec: r8 = X0
    //     0x8506ec: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x8506f0: LoadField: r9 = r4->field_7
    //     0x8506f0: ldur            x9, [x4, #7]
    // 0x8506f4: r3 = Null
    //     0x8506f4: ldr             x3, [PP, #0x41f8]  ; [pp+0x41f8] Null
    // 0x8506f8: blr             x9
    // 0x8506fc: ldur            x0, [fp, #-0x28]
    // 0x850700: r1 = false
    //     0x850700: add             x1, NULL, #0x30  ; false
    // 0x850704: StoreField: r0->field_1f = r1
    //     0x850704: stur            w1, [x0, #0x1f]
    // 0x850708: ldur            x0, [fp, #-0x20]
    // 0x85070c: ldur            x2, [fp, #-0x18]
    // 0x850710: b               #0x8506a0
    // 0x850714: ldur            x0, [fp, #-0x10]
    // 0x850718: ldur            x1, [fp, #-8]
    // 0x85071c: r0 = clear()
    //     0x85071c: bl              #0x83d960  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::clear
    // 0x850720: ldur            x0, [fp, #-0x10]
    // 0x850724: LoadField: r1 = r0->field_23
    //     0x850724: ldur            w1, [x0, #0x23]
    // 0x850728: DecompressPointer r1
    //     0x850728: add             x1, x1, HEAP, lsl #32
    // 0x85072c: cmp             w1, NULL
    // 0x850730: b.eq            #0x850770
    // 0x850734: LoadField: r2 = r1->field_7
    //     0x850734: ldur            w2, [x1, #7]
    // 0x850738: DecompressPointer r2
    //     0x850738: add             x2, x2, HEAP, lsl #32
    // 0x85073c: mov             x1, x0
    // 0x850740: r0 = _encodeRestorationData()
    //     0x850740: bl              #0x8507bc  ; [package:flutter/src/services/restoration.dart] RestorationManager::_encodeRestorationData
    // 0x850744: ldur            x1, [fp, #-0x10]
    // 0x850748: mov             x2, x0
    // 0x85074c: r0 = sendToEngine()
    //     0x85074c: bl              #0x850774  ; [package:flutter/src/services/restoration.dart] RestorationManager::sendToEngine
    // 0x850750: r0 = Null
    //     0x850750: mov             x0, NULL
    // 0x850754: LeaveFrame
    //     0x850754: mov             SP, fp
    //     0x850758: ldp             fp, lr, [SP], #0x10
    // 0x85075c: ret
    //     0x85075c: ret             
    // 0x850760: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x850760: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x850764: b               #0x850658
    // 0x850768: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x850768: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x85076c: b               #0x8506ac
    // 0x850770: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x850770: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ sendToEngine(/* No info */) {
    // ** addr: 0x850774, size: 0x48
    // 0x850774: EnterFrame
    //     0x850774: stp             fp, lr, [SP, #-0x10]!
    //     0x850778: mov             fp, SP
    // 0x85077c: AllocStack(0x20)
    //     0x85077c: sub             SP, SP, #0x20
    // 0x850780: CheckStackOverflow
    //     0x850780: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x850784: cmp             SP, x16
    //     0x850788: b.ls            #0x8507b4
    // 0x85078c: r16 = <void?>
    //     0x85078c: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x850790: r30 = Instance_OptionalMethodChannel
    //     0x850790: ldr             lr, [PP, #0x4150]  ; [pp+0x4150] Obj!OptionalMethodChannel@129be81
    // 0x850794: stp             lr, x16, [SP, #0x10]
    // 0x850798: r16 = "put"
    //     0x850798: ldr             x16, [PP, #0x4208]  ; [pp+0x4208] "put"
    // 0x85079c: stp             x2, x16, [SP]
    // 0x8507a0: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x8507a0: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x8507a4: r0 = invokeMethod()
    //     0x8507a4: bl              #0x130ad0c  ; [package:flutter/src/services/platform_channel.dart] OptionalMethodChannel::invokeMethod
    // 0x8507a8: LeaveFrame
    //     0x8507a8: mov             SP, fp
    //     0x8507ac: ldp             fp, lr, [SP], #0x10
    // 0x8507b0: ret
    //     0x8507b0: ret             
    // 0x8507b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8507b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8507b8: b               #0x85078c
  }
  _ _encodeRestorationData(/* No info */) {
    // ** addr: 0x8507bc, size: 0x6c
    // 0x8507bc: EnterFrame
    //     0x8507bc: stp             fp, lr, [SP, #-0x10]!
    //     0x8507c0: mov             fp, SP
    // 0x8507c4: AllocStack(0x20)
    //     0x8507c4: sub             SP, SP, #0x20
    // 0x8507c8: CheckStackOverflow
    //     0x8507c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8507cc: cmp             SP, x16
    //     0x8507d0: b.ls            #0x850820
    // 0x8507d4: r1 = Instance_StandardMessageCodec
    //     0x8507d4: ldr             x1, [PP, #0x2f90]  ; [pp+0x2f90] Obj!StandardMessageCodec@129ff01
    // 0x8507d8: r0 = encodeMessage()
    //     0x8507d8: bl              #0xd04fc0  ; [package:flutter/src/services/message_codecs.dart] StandardMessageCodec::encodeMessage
    // 0x8507dc: stur            x0, [fp, #-0x10]
    // 0x8507e0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8507e0: ldur            w1, [x0, #0x17]
    // 0x8507e4: DecompressPointer r1
    //     0x8507e4: add             x1, x1, HEAP, lsl #32
    // 0x8507e8: stur            x1, [fp, #-8]
    // 0x8507ec: r0 = _ByteBuffer()
    //     0x8507ec: bl              #0x7e9024  ; Allocate_ByteBufferStub -> _ByteBuffer (size=0xc)
    // 0x8507f0: mov             x1, x0
    // 0x8507f4: ldur            x0, [fp, #-8]
    // 0x8507f8: StoreField: r1->field_7 = r0
    //     0x8507f8: stur            w0, [x1, #7]
    // 0x8507fc: ldur            x0, [fp, #-0x10]
    // 0x850800: LoadField: r2 = r0->field_1b
    //     0x850800: ldur            w2, [x0, #0x1b]
    // 0x850804: LoadField: r3 = r0->field_13
    //     0x850804: ldur            w3, [x0, #0x13]
    // 0x850808: stp             x3, x2, [SP]
    // 0x85080c: r4 = const [0, 0x3, 0x2, 0x3, null]
    //     0x85080c: ldr             x4, [PP, #0x3870]  ; [pp+0x3870] List(5) [0, 0x3, 0x2, 0x3, Null]
    // 0x850810: r0 = asUint8List()
    //     0x850810: bl              #0x13d9b38  ; [dart:typed_data] _ByteBuffer::asUint8List
    // 0x850814: LeaveFrame
    //     0x850814: mov             SP, fp
    //     0x850818: ldp             fp, lr, [SP], #0x10
    // 0x85081c: ret
    //     0x85081c: ret             
    // 0x850820: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x850820: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x850824: b               #0x8507d4
  }
  _ unscheduleSerializationFor(/* No info */) {
    // ** addr: 0x850828, size: 0x3c
    // 0x850828: EnterFrame
    //     0x850828: stp             fp, lr, [SP, #-0x10]!
    //     0x85082c: mov             fp, SP
    // 0x850830: CheckStackOverflow
    //     0x850830: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x850834: cmp             SP, x16
    //     0x850838: b.ls            #0x85085c
    // 0x85083c: LoadField: r0 = r1->field_37
    //     0x85083c: ldur            w0, [x1, #0x37]
    // 0x850840: DecompressPointer r0
    //     0x850840: add             x0, x0, HEAP, lsl #32
    // 0x850844: mov             x1, x0
    // 0x850848: r0 = remove()
    //     0x850848: bl              #0x115bfd0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::remove
    // 0x85084c: r0 = Null
    //     0x85084c: mov             x0, NULL
    // 0x850850: LeaveFrame
    //     0x850850: mov             SP, fp
    //     0x850854: ldp             fp, lr, [SP], #0x10
    // 0x850858: ret
    //     0x850858: ret             
    // 0x85085c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85085c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x850860: b               #0x85083c
  }
  _ _decodeRestorationData(/* No info */) {
    // ** addr: 0x8513c0, size: 0x110
    // 0x8513c0: EnterFrame
    //     0x8513c0: stp             fp, lr, [SP, #-0x10]!
    //     0x8513c4: mov             fp, SP
    // 0x8513c8: AllocStack(0x28)
    //     0x8513c8: sub             SP, SP, #0x28
    // 0x8513cc: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x8513cc: stur            x2, [fp, #-8]
    // 0x8513d0: CheckStackOverflow
    //     0x8513d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8513d4: cmp             SP, x16
    //     0x8513d8: b.ls            #0x8514c8
    // 0x8513dc: cmp             w2, NULL
    // 0x8513e0: b.ne            #0x8513f4
    // 0x8513e4: r0 = Null
    //     0x8513e4: mov             x0, NULL
    // 0x8513e8: LeaveFrame
    //     0x8513e8: mov             SP, fp
    //     0x8513ec: ldp             fp, lr, [SP], #0x10
    // 0x8513f0: ret
    //     0x8513f0: ret             
    // 0x8513f4: r0 = LoadClassIdInstr(r2)
    //     0x8513f4: ldur            x0, [x2, #-1]
    //     0x8513f8: ubfx            x0, x0, #0xc, #0x14
    // 0x8513fc: mov             x1, x2
    // 0x851400: r0 = GDT[cid_x0 + -0xfa7]()
    //     0x851400: sub             lr, x0, #0xfa7
    //     0x851404: ldr             lr, [x21, lr, lsl #3]
    //     0x851408: blr             lr
    // 0x85140c: mov             x2, x0
    // 0x851410: ldur            x1, [fp, #-8]
    // 0x851414: stur            x2, [fp, #-0x10]
    // 0x851418: r0 = LoadClassIdInstr(r1)
    //     0x851418: ldur            x0, [x1, #-1]
    //     0x85141c: ubfx            x0, x0, #0xc, #0x14
    // 0x851420: str             x1, [SP]
    // 0x851424: r0 = GDT[cid_x0 + -0xc94]()
    //     0x851424: sub             lr, x0, #0xc94
    //     0x851428: ldr             lr, [x21, lr, lsl #3]
    //     0x85142c: blr             lr
    // 0x851430: mov             x2, x0
    // 0x851434: ldur            x1, [fp, #-8]
    // 0x851438: stur            x2, [fp, #-0x18]
    // 0x85143c: r0 = LoadClassIdInstr(r1)
    //     0x85143c: ldur            x0, [x1, #-1]
    //     0x851440: ubfx            x0, x0, #0xc, #0x14
    // 0x851444: r0 = GDT[cid_x0 + -0xbdd]()
    //     0x851444: sub             lr, x0, #0xbdd
    //     0x851448: ldr             lr, [x21, lr, lsl #3]
    //     0x85144c: blr             lr
    // 0x851450: mov             x2, x0
    // 0x851454: r0 = BoxInt64Instr(r2)
    //     0x851454: sbfiz           x0, x2, #1, #0x1f
    //     0x851458: cmp             x2, x0, asr #1
    //     0x85145c: b.eq            #0x851468
    //     0x851460: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x851464: stur            x2, [x0, #7]
    // 0x851468: ldur            x1, [fp, #-0x10]
    // 0x85146c: r2 = LoadClassIdInstr(r1)
    //     0x85146c: ldur            x2, [x1, #-1]
    //     0x851470: ubfx            x2, x2, #0xc, #0x14
    // 0x851474: ldur            x16, [fp, #-0x18]
    // 0x851478: stp             x0, x16, [SP]
    // 0x85147c: mov             x0, x2
    // 0x851480: r4 = const [0, 0x3, 0x2, 0x3, null]
    //     0x851480: ldr             x4, [PP, #0x3870]  ; [pp+0x3870] List(5) [0, 0x3, 0x2, 0x3, Null]
    // 0x851484: r0 = GDT[cid_x0 + -0xffd]()
    //     0x851484: sub             lr, x0, #0xffd
    //     0x851488: ldr             lr, [x21, lr, lsl #3]
    //     0x85148c: blr             lr
    // 0x851490: mov             x2, x0
    // 0x851494: r1 = Instance_StandardMessageCodec
    //     0x851494: ldr             x1, [PP, #0x2f90]  ; [pp+0x2f90] Obj!StandardMessageCodec@129ff01
    // 0x851498: r0 = decodeMessage()
    //     0x851498: bl              #0xccec6c  ; [package:flutter/src/services/message_codecs.dart] StandardMessageCodec::decodeMessage
    // 0x85149c: mov             x3, x0
    // 0x8514a0: r2 = Null
    //     0x8514a0: mov             x2, NULL
    // 0x8514a4: r1 = Null
    //     0x8514a4: mov             x1, NULL
    // 0x8514a8: stur            x3, [fp, #-8]
    // 0x8514ac: r8 = Map<Object?, Object?>?
    //     0x8514ac: ldr             x8, [PP, #0x18c0]  ; [pp+0x18c0] Type: Map<Object?, Object?>?
    // 0x8514b0: r3 = Null
    //     0x8514b0: ldr             x3, [PP, #0x42a8]  ; [pp+0x42a8] Null
    // 0x8514b4: r0 = Map<Object?, Object?>?()
    //     0x8514b4: bl              #0x8514d0  ; IsType_Map<Object?, Object?>?_Stub
    // 0x8514b8: ldur            x0, [fp, #-8]
    // 0x8514bc: LeaveFrame
    //     0x8514bc: mov             SP, fp
    //     0x8514c0: ldp             fp, lr, [SP], #0x10
    // 0x8514c4: ret
    //     0x8514c4: ret             
    // 0x8514c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8514c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8514cc: b               #0x8513dc
  }
  [closure] void <anonymous closure>(dynamic, Duration) {
    // ** addr: 0x85153c, size: 0x24
    // 0x85153c: r1 = false
    //     0x85153c: add             x1, NULL, #0x30  ; false
    // 0x851540: ldr             x2, [SP, #8]
    // 0x851544: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x851544: ldur            w3, [x2, #0x17]
    // 0x851548: DecompressPointer r3
    //     0x851548: add             x3, x3, HEAP, lsl #32
    // 0x85154c: LoadField: r2 = r3->field_f
    //     0x85154c: ldur            w2, [x3, #0xf]
    // 0x851550: DecompressPointer r2
    //     0x851550: add             x2, x2, HEAP, lsl #32
    // 0x851554: StoreField: r2->field_2f = r1
    //     0x851554: stur            w1, [x2, #0x2f]
    // 0x851558: r0 = Null
    //     0x851558: mov             x0, NULL
    // 0x85155c: ret
    //     0x85155c: ret             
  }
  _ flushData(/* No info */) {
    // ** addr: 0x86c654, size: 0x60
    // 0x86c654: EnterFrame
    //     0x86c654: stp             fp, lr, [SP, #-0x10]!
    //     0x86c658: mov             fp, SP
    // 0x86c65c: CheckStackOverflow
    //     0x86c65c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x86c660: cmp             SP, x16
    //     0x86c664: b.ls            #0x86c6a8
    // 0x86c668: r0 = LoadStaticField(0x5e4)
    //     0x86c668: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x86c66c: ldr             x0, [x0, #0xbc8]
    // 0x86c670: cmp             w0, NULL
    // 0x86c674: b.eq            #0x86c6b0
    // 0x86c678: LoadField: r2 = r0->field_5b
    //     0x86c678: ldur            w2, [x0, #0x5b]
    // 0x86c67c: DecompressPointer r2
    //     0x86c67c: add             x2, x2, HEAP, lsl #32
    // 0x86c680: tbnz            w2, #4, #0x86c694
    // 0x86c684: r0 = Null
    //     0x86c684: mov             x0, NULL
    // 0x86c688: LeaveFrame
    //     0x86c688: mov             SP, fp
    //     0x86c68c: ldp             fp, lr, [SP], #0x10
    // 0x86c690: ret
    //     0x86c690: ret             
    // 0x86c694: r0 = _doSerialization()
    //     0x86c694: bl              #0x850638  ; [package:flutter/src/services/restoration.dart] RestorationManager::_doSerialization
    // 0x86c698: r0 = Null
    //     0x86c698: mov             x0, NULL
    // 0x86c69c: LeaveFrame
    //     0x86c69c: mov             SP, fp
    //     0x86c6a0: ldp             fp, lr, [SP], #0x10
    // 0x86c6a4: ret
    //     0x86c6a4: ret             
    // 0x86c6a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x86c6a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x86c6ac: b               #0x86c668
    // 0x86c6b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x86c6b0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}
