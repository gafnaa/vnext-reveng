// lib: , url: package:flutter/src/services/binding.dart

// class id: 1049070, size: 0x8
class :: {
}

// class id: 2802, size: 0x8, field offset: 0x8
//   const constructor, 
class _DefaultBinaryMessenger extends BinaryMessenger {

  _ setMessageHandler(/* No info */) {
    // ** addr: 0x83aaf4, size: 0xc0
    // 0x83aaf4: EnterFrame
    //     0x83aaf4: stp             fp, lr, [SP, #-0x10]!
    //     0x83aaf8: mov             fp, SP
    // 0x83aafc: AllocStack(0x18)
    //     0x83aafc: sub             SP, SP, #0x18
    // 0x83ab00: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0x83ab00: stur            x2, [fp, #-8]
    //     0x83ab04: stur            x3, [fp, #-0x10]
    // 0x83ab08: CheckStackOverflow
    //     0x83ab08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x83ab0c: cmp             SP, x16
    //     0x83ab10: b.ls            #0x83abac
    // 0x83ab14: r1 = 1
    //     0x83ab14: mov             x1, #1
    // 0x83ab18: r0 = AllocateContext()
    //     0x83ab18: bl              #0x13de838  ; AllocateContextStub
    // 0x83ab1c: mov             x1, x0
    // 0x83ab20: ldur            x0, [fp, #-0x10]
    // 0x83ab24: stur            x1, [fp, #-0x18]
    // 0x83ab28: StoreField: r1->field_f = r0
    //     0x83ab28: stur            w0, [x1, #0xf]
    // 0x83ab2c: cmp             w0, NULL
    // 0x83ab30: b.ne            #0x83ab60
    // 0x83ab34: r0 = LoadStaticField(0x5a0)
    //     0x83ab34: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x83ab38: ldr             x0, [x0, #0xb40]
    // 0x83ab3c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x83ab40: cmp             w0, w16
    // 0x83ab44: b.ne            #0x83ab50
    // 0x83ab48: r2 = channelBuffers
    //     0x83ab48: ldr             x2, [PP, #0x14c0]  ; [pp+0x14c0] Field <::.channelBuffers>: static late final (offset: 0x5a0)
    // 0x83ab4c: r0 = InitLateFinalStaticField()
    //     0x83ab4c: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x83ab50: mov             x1, x0
    // 0x83ab54: ldur            x2, [fp, #-8]
    // 0x83ab58: r0 = clearListener()
    //     0x83ab58: bl              #0x83abb4  ; [dart:ui] ChannelBuffers::clearListener
    // 0x83ab5c: b               #0x83ab9c
    // 0x83ab60: r0 = LoadStaticField(0x5a0)
    //     0x83ab60: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x83ab64: ldr             x0, [x0, #0xb40]
    // 0x83ab68: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x83ab6c: cmp             w0, w16
    // 0x83ab70: b.ne            #0x83ab7c
    // 0x83ab74: r2 = channelBuffers
    //     0x83ab74: ldr             x2, [PP, #0x14c0]  ; [pp+0x14c0] Field <::.channelBuffers>: static late final (offset: 0x5a0)
    // 0x83ab78: r0 = InitLateFinalStaticField()
    //     0x83ab78: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x83ab7c: ldur            x2, [fp, #-0x18]
    // 0x83ab80: r1 = Function '<anonymous closure>':.
    //     0x83ab80: ldr             x1, [PP, #0x14c8]  ; [pp+0x14c8] AnonymousClosure: (0x83ac38), in [package:flutter/src/services/binding.dart] _DefaultBinaryMessenger::setMessageHandler (0x83aaf4)
    // 0x83ab84: stur            x0, [fp, #-0x10]
    // 0x83ab88: r0 = AllocateClosure()
    //     0x83ab88: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x83ab8c: ldur            x1, [fp, #-0x10]
    // 0x83ab90: ldur            x2, [fp, #-8]
    // 0x83ab94: mov             x3, x0
    // 0x83ab98: r0 = setListener()
    //     0x83ab98: bl              #0x8210f0  ; [dart:ui] ChannelBuffers::setListener
    // 0x83ab9c: r0 = Null
    //     0x83ab9c: mov             x0, NULL
    // 0x83aba0: LeaveFrame
    //     0x83aba0: mov             SP, fp
    //     0x83aba4: ldp             fp, lr, [SP], #0x10
    // 0x83aba8: ret
    //     0x83aba8: ret             
    // 0x83abac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83abac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83abb0: b               #0x83ab14
  }
  [closure] Future<void> <anonymous closure>(dynamic, ByteData?, (dynamic, ByteData?) => void) async {
    // ** addr: 0x83ac38, size: 0x1bc
    // 0x83ac38: EnterFrame
    //     0x83ac38: stp             fp, lr, [SP, #-0x10]!
    //     0x83ac3c: mov             fp, SP
    // 0x83ac40: AllocStack(0xc0)
    //     0x83ac40: sub             SP, SP, #0xc0
    // 0x83ac44: SetupParameters(_DefaultBinaryMessenger this /* r1 */, dynamic _ /* r2, fp-0x98 */, dynamic _ /* r3, fp-0x90 */)
    //     0x83ac44: stur            NULL, [fp, #-8]
    //     0x83ac48: mov             x0, #0
    //     0x83ac4c: add             x1, fp, w0, sxtw #2
    //     0x83ac50: ldr             x1, [x1, #0x20]
    //     0x83ac54: add             x2, fp, w0, sxtw #2
    //     0x83ac58: ldr             x2, [x2, #0x18]
    //     0x83ac5c: stur            x2, [fp, #-0x98]
    //     0x83ac60: add             x3, fp, w0, sxtw #2
    //     0x83ac64: ldr             x3, [x3, #0x10]
    //     0x83ac68: stur            x3, [fp, #-0x90]
    //     0x83ac6c: ldur            w4, [x1, #0x17]
    //     0x83ac70: add             x4, x4, HEAP, lsl #32
    //     0x83ac74: stur            x4, [fp, #-0x88]
    // 0x83ac78: CheckStackOverflow
    //     0x83ac78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x83ac7c: cmp             SP, x16
    //     0x83ac80: b.ls            #0x83ade8
    // 0x83ac84: InitAsync() -> Future<void?>
    //     0x83ac84: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0x83ac88: bl              #0x7f5e44  ; InitAsyncStub
    // 0x83ac8c: ldur            x1, [fp, #-0x88]
    // 0x83ac90: LoadField: r2 = r1->field_f
    //     0x83ac90: ldur            w2, [x1, #0xf]
    // 0x83ac94: DecompressPointer r2
    //     0x83ac94: add             x2, x2, HEAP, lsl #32
    // 0x83ac98: stur            x2, [fp, #-0xa0]
    // 0x83ac9c: cmp             w2, NULL
    // 0x83aca0: b.eq            #0x83adf0
    // 0x83aca4: ldur            x16, [fp, #-0x98]
    // 0x83aca8: stp             x16, x2, [SP]
    // 0x83acac: mov             x0, x2
    // 0x83acb0: ClosureCall
    //     0x83acb0: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x83acb4: ldur            x2, [x0, #0x1f]
    //     0x83acb8: blr             x2
    // 0x83acbc: mov             x2, x0
    // 0x83acc0: r1 = <ByteData?>
    //     0x83acc0: ldr             x1, [PP, #0x14d0]  ; [pp+0x14d0] TypeArguments: <ByteData?>
    // 0x83acc4: stur            x2, [fp, #-0xa0]
    // 0x83acc8: r0 = AwaitWithTypeCheck()
    //     0x83acc8: bl              #0x83adf4  ; AwaitWithTypeCheckStub
    // 0x83accc: b               #0x83ad8c
    // 0x83acd0: sub             SP, fp, #0xc0
    // 0x83acd4: stur            x0, [fp, #-0x98]
    // 0x83acd8: mov             x16, x1
    // 0x83acdc: mov             x1, x0
    // 0x83ace0: mov             x0, x16
    // 0x83ace4: stur            x0, [fp, #-0xa0]
    // 0x83ace8: r0 = FlutterErrorDetails()
    //     0x83ace8: bl              #0x829be0  ; AllocateFlutterErrorDetailsStub -> FlutterErrorDetails (size=0x20)
    // 0x83acec: r1 = <List<Object>>
    //     0x83acec: ldr             x1, [PP, #0x860]  ; [pp+0x860] TypeArguments: <List<Object>>
    // 0x83acf0: stur            x0, [fp, #-0xa8]
    // 0x83acf4: r0 = ErrorDescription()
    //     0x83acf4: bl              #0x829ca4  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x2c)
    // 0x83acf8: mov             x1, x0
    // 0x83acfc: r2 = "during a platform message callback"
    //     0x83acfc: ldr             x2, [PP, #0x14d8]  ; [pp+0x14d8] "during a platform message callback"
    // 0x83ad00: r3 = Instance_DiagnosticLevel
    //     0x83ad00: ldr             x3, [PP, #0x868]  ; [pp+0x868] Obj!DiagnosticLevel@12c5f41
    // 0x83ad04: stur            x0, [fp, #-0xb0]
    // 0x83ad08: r0 = _ErrorDiagnostic()
    //     0x83ad08: bl              #0x829bec  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0x83ad0c: ldur            x0, [fp, #-0x98]
    // 0x83ad10: ldur            x1, [fp, #-0xa8]
    // 0x83ad14: StoreField: r1->field_7 = r0
    //     0x83ad14: stur            w0, [x1, #7]
    //     0x83ad18: tbz             w0, #0, #0x83ad34
    //     0x83ad1c: ldurb           w16, [x1, #-1]
    //     0x83ad20: ldurb           w17, [x0, #-1]
    //     0x83ad24: and             x16, x17, x16, lsr #2
    //     0x83ad28: tst             x16, HEAP, lsr #32
    //     0x83ad2c: b.eq            #0x83ad34
    //     0x83ad30: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x83ad34: ldur            x0, [fp, #-0xa0]
    // 0x83ad38: StoreField: r1->field_b = r0
    //     0x83ad38: stur            w0, [x1, #0xb]
    //     0x83ad3c: ldurb           w16, [x1, #-1]
    //     0x83ad40: ldurb           w17, [x0, #-1]
    //     0x83ad44: and             x16, x17, x16, lsr #2
    //     0x83ad48: tst             x16, HEAP, lsr #32
    //     0x83ad4c: b.eq            #0x83ad54
    //     0x83ad50: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x83ad54: r0 = "services library"
    //     0x83ad54: ldr             x0, [PP, #0x870]  ; [pp+0x870] "services library"
    // 0x83ad58: StoreField: r1->field_f = r0
    //     0x83ad58: stur            w0, [x1, #0xf]
    // 0x83ad5c: ldur            x0, [fp, #-0xb0]
    // 0x83ad60: StoreField: r1->field_13 = r0
    //     0x83ad60: stur            w0, [x1, #0x13]
    //     0x83ad64: ldurb           w16, [x1, #-1]
    //     0x83ad68: ldurb           w17, [x0, #-1]
    //     0x83ad6c: and             x16, x17, x16, lsr #2
    //     0x83ad70: tst             x16, HEAP, lsr #32
    //     0x83ad74: b.eq            #0x83ad7c
    //     0x83ad78: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x83ad7c: r0 = false
    //     0x83ad7c: add             x0, NULL, #0x30  ; false
    // 0x83ad80: StoreField: r1->field_1b = r0
    //     0x83ad80: stur            w0, [x1, #0x1b]
    // 0x83ad84: r0 = reportError()
    //     0x83ad84: bl              #0x829a24  ; [package:flutter/src/foundation/assertions.dart] FlutterError::reportError
    // 0x83ad88: r0 = Null
    //     0x83ad88: mov             x0, NULL
    // 0x83ad8c: ldur            x16, [fp, #-0x90]
    // 0x83ad90: stp             x0, x16, [SP]
    // 0x83ad94: ldur            x0, [fp, #-0x90]
    // 0x83ad98: ClosureCall
    //     0x83ad98: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x83ad9c: ldur            x2, [x0, #0x1f]
    //     0x83ada0: blr             x2
    // 0x83ada4: r0 = Null
    //     0x83ada4: mov             x0, NULL
    // 0x83ada8: r0 = ReturnAsyncNotFuture()
    //     0x83ada8: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x83adac: sub             SP, fp, #0xc0
    // 0x83adb0: mov             x2, x0
    // 0x83adb4: stur            x0, [fp, #-0x88]
    // 0x83adb8: stur            x1, [fp, #-0x98]
    // 0x83adbc: ldur            x16, [fp, #-0x90]
    // 0x83adc0: ldur            lr, [fp, #-0x80]
    // 0x83adc4: stp             lr, x16, [SP]
    // 0x83adc8: ldur            x0, [fp, #-0x90]
    // 0x83adcc: ClosureCall
    //     0x83adcc: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x83add0: ldur            x2, [x0, #0x1f]
    //     0x83add4: blr             x2
    // 0x83add8: ldur            x0, [fp, #-0x88]
    // 0x83addc: ldur            x1, [fp, #-0x98]
    // 0x83ade0: r0 = ReThrow()
    //     0x83ade0: bl              #0x13ddb00  ; ReThrowStub
    // 0x83ade4: brk             #0
    // 0x83ade8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83ade8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83adec: b               #0x83ac84
    // 0x83adf0: r0 = NullErrorSharedWithoutFPURegs()
    //     0x83adf0: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ send(/* No info */) {
    // ** addr: 0x8481f8, size: 0xe0
    // 0x8481f8: EnterFrame
    //     0x8481f8: stp             fp, lr, [SP, #-0x10]!
    //     0x8481fc: mov             fp, SP
    // 0x848200: AllocStack(0x28)
    //     0x848200: sub             SP, SP, #0x28
    // 0x848204: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0x848204: stur            x2, [fp, #-8]
    //     0x848208: stur            x3, [fp, #-0x10]
    // 0x84820c: CheckStackOverflow
    //     0x84820c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x848210: cmp             SP, x16
    //     0x848214: b.ls            #0x8482d0
    // 0x848218: r1 = <ByteData?>
    //     0x848218: ldr             x1, [PP, #0x14d0]  ; [pp+0x14d0] TypeArguments: <ByteData?>
    // 0x84821c: r0 = _Future()
    //     0x84821c: bl              #0x7f5dd4  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0x848220: stur            x0, [fp, #-0x18]
    // 0x848224: StoreField: r0->field_b = rZR
    //     0x848224: stur            xzr, [x0, #0xb]
    // 0x848228: r0 = LoadStaticField(0x364)
    //     0x848228: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x84822c: ldr             x0, [x0, #0x6c8]
    // 0x848230: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x848234: cmp             w0, w16
    // 0x848238: b.ne            #0x848244
    // 0x84823c: r2 = _current
    //     0x84823c: ldr             x2, [PP, #0x2c0]  ; [pp+0x2c0] Field <Zone._current@5048458>: static late (offset: 0x364)
    // 0x848240: r0 = InitLateStaticField()
    //     0x848240: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0x848244: mov             x1, x0
    // 0x848248: ldur            x0, [fp, #-0x18]
    // 0x84824c: StoreField: r0->field_13 = r1
    //     0x84824c: stur            w1, [x0, #0x13]
    // 0x848250: r1 = <ByteData?>
    //     0x848250: ldr             x1, [PP, #0x14d0]  ; [pp+0x14d0] TypeArguments: <ByteData?>
    // 0x848254: r0 = _AsyncCompleter()
    //     0x848254: bl              #0x7f5dc8  ; Allocate_AsyncCompleterStub -> _AsyncCompleter<X0> (size=0x10)
    // 0x848258: mov             x1, x0
    // 0x84825c: ldur            x0, [fp, #-0x18]
    // 0x848260: stur            x1, [fp, #-0x20]
    // 0x848264: StoreField: r1->field_b = r0
    //     0x848264: stur            w0, [x1, #0xb]
    // 0x848268: r1 = 1
    //     0x848268: mov             x1, #1
    // 0x84826c: r0 = AllocateContext()
    //     0x84826c: bl              #0x13de838  ; AllocateContextStub
    // 0x848270: mov             x1, x0
    // 0x848274: ldur            x0, [fp, #-0x20]
    // 0x848278: stur            x1, [fp, #-0x28]
    // 0x84827c: StoreField: r1->field_f = r0
    //     0x84827c: stur            w0, [x1, #0xf]
    // 0x848280: r0 = LoadStaticField(0x58c)
    //     0x848280: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x848284: ldr             x0, [x0, #0xb18]
    // 0x848288: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84828c: cmp             w0, w16
    // 0x848290: b.ne            #0x84829c
    // 0x848294: r2 = _instance
    //     0x848294: ldr             x2, [PP, #0x1750]  ; [pp+0x1750] Field <PlatformDispatcher._instance@38065589>: static late final (offset: 0x58c)
    // 0x848298: r0 = InitLateFinalStaticField()
    //     0x848298: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x84829c: ldur            x2, [fp, #-0x28]
    // 0x8482a0: r1 = Function '<anonymous closure>':.
    //     0x8482a0: ldr             x1, [PP, #0x1758]  ; [pp+0x1758] AnonymousClosure: (0x848608), in [package:flutter/src/services/binding.dart] _DefaultBinaryMessenger::send (0x8481f8)
    // 0x8482a4: stur            x0, [fp, #-0x20]
    // 0x8482a8: r0 = AllocateClosure()
    //     0x8482a8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8482ac: ldur            x1, [fp, #-0x20]
    // 0x8482b0: ldur            x2, [fp, #-8]
    // 0x8482b4: ldur            x3, [fp, #-0x10]
    // 0x8482b8: mov             x5, x0
    // 0x8482bc: r0 = sendPlatformMessage()
    //     0x8482bc: bl              #0x8482d8  ; [dart:ui] PlatformDispatcher::sendPlatformMessage
    // 0x8482c0: ldur            x0, [fp, #-0x18]
    // 0x8482c4: LeaveFrame
    //     0x8482c4: mov             SP, fp
    //     0x8482c8: ldp             fp, lr, [SP], #0x10
    // 0x8482cc: ret
    //     0x8482cc: ret             
    // 0x8482d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8482d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8482d4: b               #0x848218
  }
  [closure] void <anonymous closure>(dynamic, ByteData?) {
    // ** addr: 0x848608, size: 0xc0
    // 0x848608: EnterFrame
    //     0x848608: stp             fp, lr, [SP, #-0x10]!
    //     0x84860c: mov             fp, SP
    // 0x848610: AllocStack(0x68)
    //     0x848610: sub             SP, SP, #0x68
    // 0x848614: SetupParameters([dynamic _ /* r0 */])
    //     0x848614: ldr             x0, [fp, #0x18]
    //     0x848618: ldur            w2, [x0, #0x17]
    //     0x84861c: add             x2, x2, HEAP, lsl #32
    //     0x848620: stur            x2, [fp, #-0x50]
    // 0x848624: CheckStackOverflow
    //     0x848624: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x848628: cmp             SP, x16
    //     0x84862c: b.ls            #0x8486c0
    // 0x848630: LoadField: r1 = r2->field_f
    //     0x848630: ldur            w1, [x2, #0xf]
    // 0x848634: DecompressPointer r1
    //     0x848634: add             x1, x1, HEAP, lsl #32
    // 0x848638: ldr             x16, [fp, #0x10]
    // 0x84863c: str             x16, [SP]
    // 0x848640: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x848640: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x848644: r0 = complete()
    //     0x848644: bl              #0x128a5ec  ; [dart:async] _AsyncCompleter::complete
    // 0x848648: b               #0x8486b0
    // 0x84864c: sub             SP, fp, #0x68
    // 0x848650: mov             x2, x0
    // 0x848654: stur            x0, [fp, #-0x50]
    // 0x848658: mov             x0, x1
    // 0x84865c: stur            x1, [fp, #-0x58]
    // 0x848660: r1 = <List<Object>>
    //     0x848660: ldr             x1, [PP, #0x860]  ; [pp+0x860] TypeArguments: <List<Object>>
    // 0x848664: r0 = ErrorDescription()
    //     0x848664: bl              #0x829ca4  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x2c)
    // 0x848668: mov             x1, x0
    // 0x84866c: r2 = "during a platform message response callback"
    //     0x84866c: ldr             x2, [PP, #0x1760]  ; [pp+0x1760] "during a platform message response callback"
    // 0x848670: r3 = Instance_DiagnosticLevel
    //     0x848670: ldr             x3, [PP, #0x868]  ; [pp+0x868] Obj!DiagnosticLevel@12c5f41
    // 0x848674: stur            x0, [fp, #-0x60]
    // 0x848678: r0 = _ErrorDiagnostic()
    //     0x848678: bl              #0x829bec  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0x84867c: r0 = FlutterErrorDetails()
    //     0x84867c: bl              #0x829be0  ; AllocateFlutterErrorDetailsStub -> FlutterErrorDetails (size=0x20)
    // 0x848680: mov             x1, x0
    // 0x848684: ldur            x0, [fp, #-0x50]
    // 0x848688: StoreField: r1->field_7 = r0
    //     0x848688: stur            w0, [x1, #7]
    // 0x84868c: ldur            x0, [fp, #-0x58]
    // 0x848690: StoreField: r1->field_b = r0
    //     0x848690: stur            w0, [x1, #0xb]
    // 0x848694: r0 = "services library"
    //     0x848694: ldr             x0, [PP, #0x870]  ; [pp+0x870] "services library"
    // 0x848698: StoreField: r1->field_f = r0
    //     0x848698: stur            w0, [x1, #0xf]
    // 0x84869c: ldur            x0, [fp, #-0x60]
    // 0x8486a0: StoreField: r1->field_13 = r0
    //     0x8486a0: stur            w0, [x1, #0x13]
    // 0x8486a4: r0 = false
    //     0x8486a4: add             x0, NULL, #0x30  ; false
    // 0x8486a8: StoreField: r1->field_1b = r0
    //     0x8486a8: stur            w0, [x1, #0x1b]
    // 0x8486ac: r0 = reportError()
    //     0x8486ac: bl              #0x829a24  ; [package:flutter/src/foundation/assertions.dart] FlutterError::reportError
    // 0x8486b0: r0 = Null
    //     0x8486b0: mov             x0, NULL
    // 0x8486b4: LeaveFrame
    //     0x8486b4: mov             SP, fp
    //     0x8486b8: ldp             fp, lr, [SP], #0x10
    // 0x8486bc: ret
    //     0x8486bc: ret             
    // 0x8486c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8486c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8486c4: b               #0x848630
  }
}

// class id: 4594, size: 0x8, field offset: 0x8
abstract class SystemContextMenuClient extends Object {
}

// class id: 4614, size: 0x8, field offset: 0x8
abstract class ServicesBinding extends _MixinApplication129&BindingBase&SchedulerBinding {

  get _ instance(/* No info */) {
    // ** addr: 0x83b000, size: 0x20
    // 0x83b000: r0 = LoadStaticField(0x7bc)
    //     0x83b000: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x83b004: ldr             x0, [x0, #0xf78]
    // 0x83b008: cmp             w0, NULL
    // 0x83b00c: b.eq            #0x83b014
    // 0x83b010: ret
    //     0x83b010: ret             
    // 0x83b014: EnterFrame
    //     0x83b014: stp             fp, lr, [SP, #-0x10]!
    //     0x83b018: mov             fp, SP
    // 0x83b01c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83b01c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static _ _parseAppLifecycleMessage(/* No info */) {
    // ** addr: 0x8463ec, size: 0xbc
    // 0x8463ec: EnterFrame
    //     0x8463ec: stp             fp, lr, [SP, #-0x10]!
    //     0x8463f0: mov             fp, SP
    // 0x8463f4: AllocStack(0x18)
    //     0x8463f4: sub             SP, SP, #0x18
    // 0x8463f8: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0x8463f8: stur            x1, [fp, #-8]
    // 0x8463fc: CheckStackOverflow
    //     0x8463fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x846400: cmp             SP, x16
    //     0x846404: b.ls            #0x8464a0
    // 0x846408: r16 = "AppLifecycleState.resumed"
    //     0x846408: ldr             x16, [PP, #0x31e8]  ; [pp+0x31e8] "AppLifecycleState.resumed"
    // 0x84640c: stp             x1, x16, [SP]
    // 0x846410: r0 = ==()
    //     0x846410: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x846414: tbnz            w0, #4, #0x846420
    // 0x846418: r0 = Instance_AppLifecycleState
    //     0x846418: ldr             x0, [PP, #0x1e28]  ; [pp+0x1e28] Obj!AppLifecycleState@12c7ee1
    // 0x84641c: b               #0x846494
    // 0x846420: r16 = "AppLifecycleState.inactive"
    //     0x846420: ldr             x16, [PP, #0x31f0]  ; [pp+0x31f0] "AppLifecycleState.inactive"
    // 0x846424: ldur            lr, [fp, #-8]
    // 0x846428: stp             lr, x16, [SP]
    // 0x84642c: r0 = ==()
    //     0x84642c: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x846430: tbnz            w0, #4, #0x84643c
    // 0x846434: r0 = Instance_AppLifecycleState
    //     0x846434: ldr             x0, [PP, #0x31f8]  ; [pp+0x31f8] Obj!AppLifecycleState@12c7ea1
    // 0x846438: b               #0x846494
    // 0x84643c: r16 = "AppLifecycleState.hidden"
    //     0x84643c: ldr             x16, [PP, #0x3200]  ; [pp+0x3200] "AppLifecycleState.hidden"
    // 0x846440: ldur            lr, [fp, #-8]
    // 0x846444: stp             lr, x16, [SP]
    // 0x846448: r0 = ==()
    //     0x846448: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x84644c: tbnz            w0, #4, #0x846458
    // 0x846450: r0 = Instance_AppLifecycleState
    //     0x846450: ldr             x0, [PP, #0x3208]  ; [pp+0x3208] Obj!AppLifecycleState@12c7f01
    // 0x846454: b               #0x846494
    // 0x846458: r16 = "AppLifecycleState.paused"
    //     0x846458: ldr             x16, [PP, #0x3210]  ; [pp+0x3210] "AppLifecycleState.paused"
    // 0x84645c: ldur            lr, [fp, #-8]
    // 0x846460: stp             lr, x16, [SP]
    // 0x846464: r0 = ==()
    //     0x846464: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x846468: tbnz            w0, #4, #0x846474
    // 0x84646c: r0 = Instance_AppLifecycleState
    //     0x84646c: ldr             x0, [PP, #0x3218]  ; [pp+0x3218] Obj!AppLifecycleState@12c7ec1
    // 0x846470: b               #0x846494
    // 0x846474: r16 = "AppLifecycleState.detached"
    //     0x846474: ldr             x16, [PP, #0x3220]  ; [pp+0x3220] "AppLifecycleState.detached"
    // 0x846478: ldur            lr, [fp, #-8]
    // 0x84647c: stp             lr, x16, [SP]
    // 0x846480: r0 = ==()
    //     0x846480: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x846484: tbnz            w0, #4, #0x846490
    // 0x846488: r0 = Instance_AppLifecycleState
    //     0x846488: ldr             x0, [PP, #0x3178]  ; [pp+0x3178] Obj!AppLifecycleState@12c7f21
    // 0x84648c: b               #0x846494
    // 0x846490: r0 = Null
    //     0x846490: mov             x0, NULL
    // 0x846494: LeaveFrame
    //     0x846494: mov             SP, fp
    //     0x846498: ldp             fp, lr, [SP], #0x10
    // 0x84649c: ret
    //     0x84649c: ret             
    // 0x8464a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8464a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8464a4: b               #0x846408
  }
  [closure] static List<LicenseEntry> _parseLicenses(dynamic, String) {
    // ** addr: 0x848978, size: 0x30
    // 0x848978: EnterFrame
    //     0x848978: stp             fp, lr, [SP, #-0x10]!
    //     0x84897c: mov             fp, SP
    // 0x848980: CheckStackOverflow
    //     0x848980: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x848984: cmp             SP, x16
    //     0x848988: b.ls            #0x8489a0
    // 0x84898c: ldr             x1, [fp, #0x10]
    // 0x848990: r0 = _parseLicenses()
    //     0x848990: bl              #0x8489a8  ; [package:flutter/src/services/binding.dart] ServicesBinding::_parseLicenses
    // 0x848994: LeaveFrame
    //     0x848994: mov             SP, fp
    //     0x848998: ldp             fp, lr, [SP], #0x10
    // 0x84899c: ret
    //     0x84899c: ret             
    // 0x8489a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8489a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8489a4: b               #0x84898c
  }
  static _ _parseLicenses(/* No info */) {
    // ** addr: 0x8489a8, size: 0x33c
    // 0x8489a8: EnterFrame
    //     0x8489a8: stp             fp, lr, [SP, #-0x10]!
    //     0x8489ac: mov             fp, SP
    // 0x8489b0: AllocStack(0x48)
    //     0x8489b0: sub             SP, SP, #0x48
    // 0x8489b4: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */)
    //     0x8489b4: mov             x0, x1
    //     0x8489b8: stur            x1, [fp, #-8]
    // 0x8489bc: CheckStackOverflow
    //     0x8489bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8489c0: cmp             SP, x16
    //     0x8489c4: b.ls            #0x848cd4
    // 0x8489c8: r1 = Null
    //     0x8489c8: mov             x1, NULL
    // 0x8489cc: r2 = 6
    //     0x8489cc: mov             x2, #6
    // 0x8489d0: r0 = AllocateArray()
    //     0x8489d0: bl              #0x13df928  ; AllocateArrayStub
    // 0x8489d4: stur            x0, [fp, #-0x10]
    // 0x8489d8: r16 = "\n"
    //     0x8489d8: ldr             x16, [PP, #0x8c0]  ; [pp+0x8c0] "\n"
    // 0x8489dc: StoreField: r0->field_f = r16
    //     0x8489dc: stur            w16, [x0, #0xf]
    // 0x8489e0: r1 = "-"
    //     0x8489e0: ldr             x1, [PP, #0x24e8]  ; [pp+0x24e8] "-"
    // 0x8489e4: r2 = 80
    //     0x8489e4: mov             x2, #0x50
    // 0x8489e8: r0 = *()
    //     0x8489e8: bl              #0x13da918  ; [dart:core] _OneByteString::*
    // 0x8489ec: ldur            x1, [fp, #-0x10]
    // 0x8489f0: ArrayStore: r1[1] = r0  ; List_4
    //     0x8489f0: add             x25, x1, #0x13
    //     0x8489f4: str             w0, [x25]
    //     0x8489f8: tbz             w0, #0, #0x848a14
    //     0x8489fc: ldurb           w16, [x1, #-1]
    //     0x848a00: ldurb           w17, [x0, #-1]
    //     0x848a04: and             x16, x17, x16, lsr #2
    //     0x848a08: tst             x16, HEAP, lsr #32
    //     0x848a0c: b.eq            #0x848a14
    //     0x848a10: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x848a14: ldur            x0, [fp, #-0x10]
    // 0x848a18: r16 = "\n"
    //     0x848a18: ldr             x16, [PP, #0x8c0]  ; [pp+0x8c0] "\n"
    // 0x848a1c: ArrayStore: r0[0] = r16  ; List_4
    //     0x848a1c: stur            w16, [x0, #0x17]
    // 0x848a20: str             x0, [SP]
    // 0x848a24: r0 = _interpolate()
    //     0x848a24: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x848a28: r1 = <LicenseEntry>
    //     0x848a28: ldr             x1, [PP, #0x3560]  ; [pp+0x3560] TypeArguments: <LicenseEntry>
    // 0x848a2c: r2 = 0
    //     0x848a2c: mov             x2, #0
    // 0x848a30: stur            x0, [fp, #-0x10]
    // 0x848a34: r0 = _GrowableList()
    //     0x848a34: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x848a38: mov             x3, x0
    // 0x848a3c: ldur            x1, [fp, #-8]
    // 0x848a40: stur            x3, [fp, #-0x18]
    // 0x848a44: r0 = LoadClassIdInstr(r1)
    //     0x848a44: ldur            x0, [x1, #-1]
    //     0x848a48: ubfx            x0, x0, #0xc, #0x14
    // 0x848a4c: ldur            x2, [fp, #-0x10]
    // 0x848a50: r0 = GDT[cid_x0 + -0xffe]()
    //     0x848a50: sub             lr, x0, #0xffe
    //     0x848a54: ldr             lr, [x21, lr, lsl #3]
    //     0x848a58: blr             lr
    // 0x848a5c: mov             x3, x0
    // 0x848a60: stur            x3, [fp, #-0x10]
    // 0x848a64: LoadField: r0 = r3->field_b
    //     0x848a64: ldur            w0, [x3, #0xb]
    // 0x848a68: r4 = LoadInt32Instr(r0)
    //     0x848a68: sbfx            x4, x0, #1, #0x1f
    // 0x848a6c: stur            x4, [fp, #-0x28]
    // 0x848a70: r0 = 0
    //     0x848a70: mov             x0, #0
    // 0x848a74: ldur            x5, [fp, #-0x18]
    // 0x848a78: CheckStackOverflow
    //     0x848a78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x848a7c: cmp             SP, x16
    //     0x848a80: b.ls            #0x848cdc
    // 0x848a84: LoadField: r1 = r3->field_b
    //     0x848a84: ldur            w1, [x3, #0xb]
    // 0x848a88: r2 = LoadInt32Instr(r1)
    //     0x848a88: sbfx            x2, x1, #1, #0x1f
    // 0x848a8c: cmp             x4, x2
    // 0x848a90: b.ne            #0x848cb4
    // 0x848a94: cmp             x0, x2
    // 0x848a98: b.ge            #0x848ca4
    // 0x848a9c: LoadField: r1 = r3->field_f
    //     0x848a9c: ldur            w1, [x3, #0xf]
    // 0x848aa0: DecompressPointer r1
    //     0x848aa0: add             x1, x1, HEAP, lsl #32
    // 0x848aa4: ArrayLoad: r6 = r1[r0]  ; Unknown_4
    //     0x848aa4: add             x16, x1, x0, lsl #2
    //     0x848aa8: ldur            w6, [x16, #0xf]
    // 0x848aac: DecompressPointer r6
    //     0x848aac: add             x6, x6, HEAP, lsl #32
    // 0x848ab0: stur            x6, [fp, #-8]
    // 0x848ab4: add             x7, x0, #1
    // 0x848ab8: stur            x7, [fp, #-0x20]
    // 0x848abc: r0 = LoadClassIdInstr(r6)
    //     0x848abc: ldur            x0, [x6, #-1]
    //     0x848ac0: ubfx            x0, x0, #0xc, #0x14
    // 0x848ac4: mov             x1, x6
    // 0x848ac8: r2 = "\n\n"
    //     0x848ac8: ldr             x2, [PP, #0x3690]  ; [pp+0x3690] "\n\n"
    // 0x848acc: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x848acc: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x848ad0: r0 = GDT[cid_x0 + -0xffa]()
    //     0x848ad0: sub             lr, x0, #0xffa
    //     0x848ad4: ldr             lr, [x21, lr, lsl #3]
    //     0x848ad8: blr             lr
    // 0x848adc: mov             x4, x0
    // 0x848ae0: stur            x4, [fp, #-0x38]
    // 0x848ae4: tbnz            x4, #0x3f, #0x848c10
    // 0x848ae8: ldur            x5, [fp, #-0x18]
    // 0x848aec: ldur            x6, [fp, #-8]
    // 0x848af0: LoadField: r2 = r6->field_7
    //     0x848af0: ldur            w2, [x6, #7]
    // 0x848af4: r0 = BoxInt64Instr(r4)
    //     0x848af4: sbfiz           x0, x4, #1, #0x1f
    //     0x848af8: cmp             x4, x0, asr #1
    //     0x848afc: b.eq            #0x848b08
    //     0x848b00: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x848b04: stur            x4, [x0, #7]
    // 0x848b08: r7 = LoadInt32Instr(r2)
    //     0x848b08: sbfx            x7, x2, #1, #0x1f
    // 0x848b0c: mov             x2, x0
    // 0x848b10: mov             x3, x7
    // 0x848b14: stur            x7, [fp, #-0x30]
    // 0x848b18: r1 = 0
    //     0x848b18: mov             x1, #0
    // 0x848b1c: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x848b1c: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x848b20: r0 = checkValidRange()
    //     0x848b20: bl              #0x7db068  ; [dart:core] RangeError::checkValidRange
    // 0x848b24: ldur            x1, [fp, #-8]
    // 0x848b28: mov             x3, x0
    // 0x848b2c: r2 = 0
    //     0x848b2c: mov             x2, #0
    // 0x848b30: r0 = _substringUnchecked()
    //     0x848b30: bl              #0x7e3ff8  ; [dart:core] _StringBase::_substringUnchecked
    // 0x848b34: r1 = LoadClassIdInstr(r0)
    //     0x848b34: ldur            x1, [x0, #-1]
    //     0x848b38: ubfx            x1, x1, #0xc, #0x14
    // 0x848b3c: mov             x16, x0
    // 0x848b40: mov             x0, x1
    // 0x848b44: mov             x1, x16
    // 0x848b48: r2 = "\n"
    //     0x848b48: ldr             x2, [PP, #0x8c0]  ; [pp+0x8c0] "\n"
    // 0x848b4c: r0 = GDT[cid_x0 + -0xffe]()
    //     0x848b4c: sub             lr, x0, #0xffe
    //     0x848b50: ldr             lr, [x21, lr, lsl #3]
    //     0x848b54: blr             lr
    // 0x848b58: ldur            x0, [fp, #-0x38]
    // 0x848b5c: add             x4, x0, #2
    // 0x848b60: mov             x1, x4
    // 0x848b64: ldur            x3, [fp, #-0x30]
    // 0x848b68: stur            x4, [fp, #-0x40]
    // 0x848b6c: r2 = Null
    //     0x848b6c: mov             x2, NULL
    // 0x848b70: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x848b70: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x848b74: r0 = checkValidRange()
    //     0x848b74: bl              #0x7db068  ; [dart:core] RangeError::checkValidRange
    // 0x848b78: ldur            x1, [fp, #-8]
    // 0x848b7c: ldur            x2, [fp, #-0x40]
    // 0x848b80: mov             x3, x0
    // 0x848b84: r0 = _substringUnchecked()
    //     0x848b84: bl              #0x7e3ff8  ; [dart:core] _StringBase::_substringUnchecked
    // 0x848b88: ldur            x0, [fp, #-0x18]
    // 0x848b8c: LoadField: r1 = r0->field_b
    //     0x848b8c: ldur            w1, [x0, #0xb]
    // 0x848b90: LoadField: r2 = r0->field_f
    //     0x848b90: ldur            w2, [x0, #0xf]
    // 0x848b94: DecompressPointer r2
    //     0x848b94: add             x2, x2, HEAP, lsl #32
    // 0x848b98: LoadField: r3 = r2->field_b
    //     0x848b98: ldur            w3, [x2, #0xb]
    // 0x848b9c: r2 = LoadInt32Instr(r1)
    //     0x848b9c: sbfx            x2, x1, #1, #0x1f
    // 0x848ba0: stur            x2, [fp, #-0x30]
    // 0x848ba4: r1 = LoadInt32Instr(r3)
    //     0x848ba4: sbfx            x1, x3, #1, #0x1f
    // 0x848ba8: cmp             x2, x1
    // 0x848bac: b.ne            #0x848bb8
    // 0x848bb0: mov             x1, x0
    // 0x848bb4: r0 = _growToNextCapacity()
    //     0x848bb4: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x848bb8: ldur            x1, [fp, #-0x18]
    // 0x848bbc: ldur            x0, [fp, #-0x30]
    // 0x848bc0: add             x2, x0, #1
    // 0x848bc4: lsl             x3, x2, #1
    // 0x848bc8: StoreField: r1->field_b = r3
    //     0x848bc8: stur            w3, [x1, #0xb]
    // 0x848bcc: LoadField: r2 = r1->field_f
    //     0x848bcc: ldur            w2, [x1, #0xf]
    // 0x848bd0: DecompressPointer r2
    //     0x848bd0: add             x2, x2, HEAP, lsl #32
    // 0x848bd4: stur            x2, [fp, #-8]
    // 0x848bd8: r0 = LicenseEntryWithLineBreaks()
    //     0x848bd8: bl              #0x848ce4  ; AllocateLicenseEntryWithLineBreaksStub -> LicenseEntryWithLineBreaks (size=0x8)
    // 0x848bdc: ldur            x1, [fp, #-8]
    // 0x848be0: ldur            x2, [fp, #-0x30]
    // 0x848be4: ArrayStore: r1[r2] = r0  ; List_4
    //     0x848be4: add             x25, x1, x2, lsl #2
    //     0x848be8: add             x25, x25, #0xf
    //     0x848bec: str             w0, [x25]
    //     0x848bf0: tbz             w0, #0, #0x848c0c
    //     0x848bf4: ldurb           w16, [x1, #-1]
    //     0x848bf8: ldurb           w17, [x0, #-1]
    //     0x848bfc: and             x16, x17, x16, lsr #2
    //     0x848c00: tst             x16, HEAP, lsr #32
    //     0x848c04: b.eq            #0x848c0c
    //     0x848c08: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x848c0c: b               #0x848c94
    // 0x848c10: ldur            x0, [fp, #-0x18]
    // 0x848c14: LoadField: r1 = r0->field_b
    //     0x848c14: ldur            w1, [x0, #0xb]
    // 0x848c18: LoadField: r2 = r0->field_f
    //     0x848c18: ldur            w2, [x0, #0xf]
    // 0x848c1c: DecompressPointer r2
    //     0x848c1c: add             x2, x2, HEAP, lsl #32
    // 0x848c20: LoadField: r3 = r2->field_b
    //     0x848c20: ldur            w3, [x2, #0xb]
    // 0x848c24: r2 = LoadInt32Instr(r1)
    //     0x848c24: sbfx            x2, x1, #1, #0x1f
    // 0x848c28: stur            x2, [fp, #-0x30]
    // 0x848c2c: r1 = LoadInt32Instr(r3)
    //     0x848c2c: sbfx            x1, x3, #1, #0x1f
    // 0x848c30: cmp             x2, x1
    // 0x848c34: b.ne            #0x848c40
    // 0x848c38: mov             x1, x0
    // 0x848c3c: r0 = _growToNextCapacity()
    //     0x848c3c: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x848c40: ldur            x0, [fp, #-0x18]
    // 0x848c44: ldur            x1, [fp, #-0x30]
    // 0x848c48: add             x2, x1, #1
    // 0x848c4c: lsl             x3, x2, #1
    // 0x848c50: StoreField: r0->field_b = r3
    //     0x848c50: stur            w3, [x0, #0xb]
    // 0x848c54: LoadField: r2 = r0->field_f
    //     0x848c54: ldur            w2, [x0, #0xf]
    // 0x848c58: DecompressPointer r2
    //     0x848c58: add             x2, x2, HEAP, lsl #32
    // 0x848c5c: stur            x2, [fp, #-8]
    // 0x848c60: r0 = LicenseEntryWithLineBreaks()
    //     0x848c60: bl              #0x848ce4  ; AllocateLicenseEntryWithLineBreaksStub -> LicenseEntryWithLineBreaks (size=0x8)
    // 0x848c64: ldur            x1, [fp, #-8]
    // 0x848c68: ldur            x2, [fp, #-0x30]
    // 0x848c6c: ArrayStore: r1[r2] = r0  ; List_4
    //     0x848c6c: add             x25, x1, x2, lsl #2
    //     0x848c70: add             x25, x25, #0xf
    //     0x848c74: str             w0, [x25]
    //     0x848c78: tbz             w0, #0, #0x848c94
    //     0x848c7c: ldurb           w16, [x1, #-1]
    //     0x848c80: ldurb           w17, [x0, #-1]
    //     0x848c84: and             x16, x17, x16, lsr #2
    //     0x848c88: tst             x16, HEAP, lsr #32
    //     0x848c8c: b.eq            #0x848c94
    //     0x848c90: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x848c94: ldur            x0, [fp, #-0x20]
    // 0x848c98: ldur            x3, [fp, #-0x10]
    // 0x848c9c: ldur            x4, [fp, #-0x28]
    // 0x848ca0: b               #0x848a74
    // 0x848ca4: ldur            x0, [fp, #-0x18]
    // 0x848ca8: LeaveFrame
    //     0x848ca8: mov             SP, fp
    //     0x848cac: ldp             fp, lr, [SP], #0x10
    // 0x848cb0: ret
    //     0x848cb0: ret             
    // 0x848cb4: mov             x0, x3
    // 0x848cb8: r0 = ConcurrentModificationError()
    //     0x848cb8: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x848cbc: mov             x1, x0
    // 0x848cc0: ldur            x0, [fp, #-0x10]
    // 0x848cc4: StoreField: r1->field_b = r0
    //     0x848cc4: stur            w0, [x1, #0xb]
    // 0x848cc8: mov             x0, x1
    // 0x848ccc: r0 = Throw()
    //     0x848ccc: bl              #0x13ddb2c  ; ThrowStub
    // 0x848cd0: brk             #0
    // 0x848cd4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x848cd4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x848cd8: b               #0x8489c8
    // 0x848cdc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x848cdc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x848ce0: b               #0x848a84
  }
}
