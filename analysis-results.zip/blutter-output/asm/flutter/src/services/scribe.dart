// lib: , url: package:flutter/src/services/scribe.dart

// class id: 1049095, size: 0x8
class :: {
}

// class id: 2748, size: 0x8, field offset: 0x8
abstract class Scribe extends Object {

  static _ isFeatureAvailable(/* No info */) async {
    // ** addr: 0xba775c, size: 0x84
    // 0xba775c: EnterFrame
    //     0xba775c: stp             fp, lr, [SP, #-0x10]!
    //     0xba7760: mov             fp, SP
    // 0xba7764: AllocStack(0x28)
    //     0xba7764: sub             SP, SP, #0x28
    // 0xba7768: SetupParameters()
    //     0xba7768: stur            NULL, [fp, #-8]
    // 0xba776c: CheckStackOverflow
    //     0xba776c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba7770: cmp             SP, x16
    //     0xba7774: b.ls            #0xba77d8
    // 0xba7778: InitAsync() -> Future<bool>
    //     0xba7778: ldr             x0, [PP, #0x1918]  ; [pp+0x1918] TypeArguments: <bool>
    //     0xba777c: bl              #0x7f5e44  ; InitAsyncStub
    // 0xba7780: r16 = <bool?>
    //     0xba7780: add             x16, PP, #8, lsl #12  ; [pp+0x8178] TypeArguments: <bool?>
    //     0xba7784: ldr             x16, [x16, #0x178]
    // 0xba7788: r30 = Instance_OptionalMethodChannel
    //     0xba7788: add             lr, PP, #0x8f, lsl #12  ; [pp+0x8f838] Obj!OptionalMethodChannel@129bf41
    //     0xba778c: ldr             lr, [lr, #0x838]
    // 0xba7790: stp             lr, x16, [SP, #8]
    // 0xba7794: r16 = "Scribe.isFeatureAvailable"
    //     0xba7794: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8f848] "Scribe.isFeatureAvailable"
    //     0xba7798: ldr             x16, [x16, #0x848]
    // 0xba779c: str             x16, [SP]
    // 0xba77a0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xba77a0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xba77a4: r0 = invokeMethod()
    //     0xba77a4: bl              #0x130ad0c  ; [package:flutter/src/services/platform_channel.dart] OptionalMethodChannel::invokeMethod
    // 0xba77a8: mov             x1, x0
    // 0xba77ac: stur            x1, [fp, #-0x10]
    // 0xba77b0: r0 = Await()
    //     0xba77b0: bl              #0x7f5c00  ; AwaitStub
    // 0xba77b4: cmp             w0, NULL
    // 0xba77b8: b.eq            #0xba77c0
    // 0xba77bc: r0 = ReturnAsync()
    //     0xba77bc: b               #0x82fdf0  ; ReturnAsyncStub
    // 0xba77c0: r1 = Null
    //     0xba77c0: mov             x1, NULL
    // 0xba77c4: r2 = "MethodChannel.invokeMethod unexpectedly returned null."
    //     0xba77c4: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8f850] "MethodChannel.invokeMethod unexpectedly returned null."
    //     0xba77c8: ldr             x2, [x2, #0x850]
    // 0xba77cc: r0 = FlutterError()
    //     0xba77cc: bl              #0x84eb60  ; [package:flutter/src/foundation/assertions.dart] FlutterError::FlutterError
    // 0xba77d0: r0 = Throw()
    //     0xba77d0: bl              #0x13ddb2c  ; ThrowStub
    // 0xba77d4: brk             #0
    // 0xba77d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba77d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba77dc: b               #0xba7778
  }
  static Future<void> startStylusHandwriting() {
    // ** addr: 0xba78cc, size: 0x50
    // 0xba78cc: EnterFrame
    //     0xba78cc: stp             fp, lr, [SP, #-0x10]!
    //     0xba78d0: mov             fp, SP
    // 0xba78d4: AllocStack(0x18)
    //     0xba78d4: sub             SP, SP, #0x18
    // 0xba78d8: CheckStackOverflow
    //     0xba78d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba78dc: cmp             SP, x16
    //     0xba78e0: b.ls            #0xba7914
    // 0xba78e4: r16 = <void?>
    //     0xba78e4: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xba78e8: r30 = Instance_OptionalMethodChannel
    //     0xba78e8: add             lr, PP, #0x8f, lsl #12  ; [pp+0x8f838] Obj!OptionalMethodChannel@129bf41
    //     0xba78ec: ldr             lr, [lr, #0x838]
    // 0xba78f0: stp             lr, x16, [SP, #8]
    // 0xba78f4: r16 = "Scribe.startStylusHandwriting"
    //     0xba78f4: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8f840] "Scribe.startStylusHandwriting"
    //     0xba78f8: ldr             x16, [x16, #0x840]
    // 0xba78fc: str             x16, [SP]
    // 0xba7900: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xba7900: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xba7904: r0 = invokeMethod()
    //     0xba7904: bl              #0x130ad0c  ; [package:flutter/src/services/platform_channel.dart] OptionalMethodChannel::invokeMethod
    // 0xba7908: LeaveFrame
    //     0xba7908: mov             SP, fp
    //     0xba790c: ldp             fp, lr, [SP], #0x10
    // 0xba7910: ret
    //     0xba7910: ret             
    // 0xba7914: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba7914: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba7918: b               #0xba78e4
  }
}
