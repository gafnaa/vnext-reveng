// lib: , url: package:flutter/src/services/text_editing.dart

// class id: 1049101, size: 0x8
class :: {
}

// class id: 3726, size: 0x30, field offset: 0x18
//   const constructor, 
class TextSelection extends TextRange {

  _Mint field_8;
  _Mint field_10;
  _Mint field_18;
  _Mint field_20;
  TextAffinity field_28;
  bool field_2c;

  get _ extent(/* No info */) {
    // ** addr: 0x85fb94, size: 0x78
    // 0x85fb94: EnterFrame
    //     0x85fb94: stp             fp, lr, [SP, #-0x10]!
    //     0x85fb98: mov             fp, SP
    // 0x85fb9c: AllocStack(0x10)
    //     0x85fb9c: sub             SP, SP, #0x10
    // 0x85fba0: LoadField: r0 = r1->field_7
    //     0x85fba0: ldur            x0, [x1, #7]
    // 0x85fba4: tbnz            x0, #0x3f, #0x85fbd8
    // 0x85fba8: LoadField: r0 = r1->field_f
    //     0x85fba8: ldur            x0, [x1, #0xf]
    // 0x85fbac: tbnz            x0, #0x3f, #0x85fbd8
    // 0x85fbb0: ArrayLoad: r0 = r1[0]  ; List_8
    //     0x85fbb0: ldur            x0, [x1, #0x17]
    // 0x85fbb4: LoadField: r2 = r1->field_1f
    //     0x85fbb4: ldur            x2, [x1, #0x1f]
    // 0x85fbb8: cmp             x0, x2
    // 0x85fbbc: b.eq            #0x85fbd8
    // 0x85fbc0: cmp             x0, x2
    // 0x85fbc4: b.ge            #0x85fbd0
    // 0x85fbc8: r0 = Instance_TextAffinity
    //     0x85fbc8: ldr             x0, [PP, #0x4bb8]  ; [pp+0x4bb8] Obj!TextAffinity@12c7341
    // 0x85fbcc: b               #0x85fbe0
    // 0x85fbd0: r0 = Instance_TextAffinity
    //     0x85fbd0: ldr             x0, [PP, #0x4bb0]  ; [pp+0x4bb0] Obj!TextAffinity@12c7361
    // 0x85fbd4: b               #0x85fbe0
    // 0x85fbd8: LoadField: r0 = r1->field_27
    //     0x85fbd8: ldur            w0, [x1, #0x27]
    // 0x85fbdc: DecompressPointer r0
    //     0x85fbdc: add             x0, x0, HEAP, lsl #32
    // 0x85fbe0: stur            x0, [fp, #-0x10]
    // 0x85fbe4: LoadField: r2 = r1->field_1f
    //     0x85fbe4: ldur            x2, [x1, #0x1f]
    // 0x85fbe8: stur            x2, [fp, #-8]
    // 0x85fbec: r0 = TextPosition()
    //     0x85fbec: bl              #0x85ed74  ; AllocateTextPositionStub -> TextPosition (size=0x14)
    // 0x85fbf0: ldur            x1, [fp, #-8]
    // 0x85fbf4: StoreField: r0->field_7 = r1
    //     0x85fbf4: stur            x1, [x0, #7]
    // 0x85fbf8: ldur            x1, [fp, #-0x10]
    // 0x85fbfc: StoreField: r0->field_f = r1
    //     0x85fbfc: stur            w1, [x0, #0xf]
    // 0x85fc00: LeaveFrame
    //     0x85fc00: mov             SP, fp
    //     0x85fc04: ldp             fp, lr, [SP], #0x10
    // 0x85fc08: ret
    //     0x85fc08: ret             
  }
  get _ base(/* No info */) {
    // ** addr: 0x86de9c, size: 0x78
    // 0x86de9c: EnterFrame
    //     0x86de9c: stp             fp, lr, [SP, #-0x10]!
    //     0x86dea0: mov             fp, SP
    // 0x86dea4: AllocStack(0x10)
    //     0x86dea4: sub             SP, SP, #0x10
    // 0x86dea8: LoadField: r0 = r1->field_7
    //     0x86dea8: ldur            x0, [x1, #7]
    // 0x86deac: tbnz            x0, #0x3f, #0x86dee0
    // 0x86deb0: LoadField: r0 = r1->field_f
    //     0x86deb0: ldur            x0, [x1, #0xf]
    // 0x86deb4: tbnz            x0, #0x3f, #0x86dee0
    // 0x86deb8: ArrayLoad: r0 = r1[0]  ; List_8
    //     0x86deb8: ldur            x0, [x1, #0x17]
    // 0x86debc: LoadField: r2 = r1->field_1f
    //     0x86debc: ldur            x2, [x1, #0x1f]
    // 0x86dec0: cmp             x0, x2
    // 0x86dec4: b.eq            #0x86dee0
    // 0x86dec8: cmp             x0, x2
    // 0x86decc: b.ge            #0x86ded8
    // 0x86ded0: r0 = Instance_TextAffinity
    //     0x86ded0: ldr             x0, [PP, #0x4bb0]  ; [pp+0x4bb0] Obj!TextAffinity@12c7361
    // 0x86ded4: b               #0x86dee8
    // 0x86ded8: r0 = Instance_TextAffinity
    //     0x86ded8: ldr             x0, [PP, #0x4bb8]  ; [pp+0x4bb8] Obj!TextAffinity@12c7341
    // 0x86dedc: b               #0x86dee8
    // 0x86dee0: LoadField: r0 = r1->field_27
    //     0x86dee0: ldur            w0, [x1, #0x27]
    // 0x86dee4: DecompressPointer r0
    //     0x86dee4: add             x0, x0, HEAP, lsl #32
    // 0x86dee8: stur            x0, [fp, #-0x10]
    // 0x86deec: ArrayLoad: r2 = r1[0]  ; List_8
    //     0x86deec: ldur            x2, [x1, #0x17]
    // 0x86def0: stur            x2, [fp, #-8]
    // 0x86def4: r0 = TextPosition()
    //     0x86def4: bl              #0x85ed74  ; AllocateTextPositionStub -> TextPosition (size=0x14)
    // 0x86def8: ldur            x1, [fp, #-8]
    // 0x86defc: StoreField: r0->field_7 = r1
    //     0x86defc: stur            x1, [x0, #7]
    // 0x86df00: ldur            x1, [fp, #-0x10]
    // 0x86df04: StoreField: r0->field_f = r1
    //     0x86df04: stur            w1, [x0, #0xf]
    // 0x86df08: LeaveFrame
    //     0x86df08: mov             SP, fp
    //     0x86df0c: ldp             fp, lr, [SP], #0x10
    // 0x86df10: ret
    //     0x86df10: ret             
  }
  _ copyWith(/* No info */) {
    // ** addr: 0x877a64, size: 0x1a8
    // 0x877a64: EnterFrame
    //     0x877a64: stp             fp, lr, [SP, #-0x10]!
    //     0x877a68: mov             fp, SP
    // 0x877a6c: AllocStack(0x20)
    //     0x877a6c: sub             SP, SP, #0x20
    // 0x877a70: SetupParameters({dynamic affinity = Null /* r3 */, dynamic baseOffset = Null /* r5 */, dynamic extentOffset = Null /* r0 */})
    //     0x877a70: ldur            w0, [x4, #0x13]
    //     0x877a74: ldur            w2, [x4, #0x1f]
    //     0x877a78: add             x2, x2, HEAP, lsl #32
    //     0x877a7c: ldr             x16, [PP, #0x6020]  ; [pp+0x6020] "affinity"
    //     0x877a80: cmp             w2, w16
    //     0x877a84: b.ne            #0x877aa8
    //     0x877a88: ldur            w2, [x4, #0x23]
    //     0x877a8c: add             x2, x2, HEAP, lsl #32
    //     0x877a90: sub             w3, w0, w2
    //     0x877a94: add             x2, fp, w3, sxtw #2
    //     0x877a98: ldr             x2, [x2, #8]
    //     0x877a9c: mov             x3, x2
    //     0x877aa0: mov             x2, #1
    //     0x877aa4: b               #0x877ab0
    //     0x877aa8: mov             x3, NULL
    //     0x877aac: mov             x2, #0
    //     0x877ab0: lsl             x5, x2, #1
    //     0x877ab4: lsl             w6, w5, #1
    //     0x877ab8: add             w7, w6, #8
    //     0x877abc: add             x16, x4, w7, sxtw #1
    //     0x877ac0: ldur            w8, [x16, #0xf]
    //     0x877ac4: add             x8, x8, HEAP, lsl #32
    //     0x877ac8: ldr             x16, [PP, #0x6028]  ; [pp+0x6028] "baseOffset"
    //     0x877acc: cmp             w8, w16
    //     0x877ad0: b.ne            #0x877b04
    //     0x877ad4: add             w2, w6, #0xa
    //     0x877ad8: add             x16, x4, w2, sxtw #1
    //     0x877adc: ldur            w6, [x16, #0xf]
    //     0x877ae0: add             x6, x6, HEAP, lsl #32
    //     0x877ae4: sub             w2, w0, w6
    //     0x877ae8: add             x6, fp, w2, sxtw #2
    //     0x877aec: ldr             x6, [x6, #8]
    //     0x877af0: add             w2, w5, #2
    //     0x877af4: sbfx            x5, x2, #1, #0x1f
    //     0x877af8: mov             x2, x5
    //     0x877afc: mov             x5, x6
    //     0x877b00: b               #0x877b08
    //     0x877b04: mov             x5, NULL
    //     0x877b08: lsl             x6, x2, #1
    //     0x877b0c: lsl             w2, w6, #1
    //     0x877b10: add             w6, w2, #8
    //     0x877b14: add             x16, x4, w6, sxtw #1
    //     0x877b18: ldur            w7, [x16, #0xf]
    //     0x877b1c: add             x7, x7, HEAP, lsl #32
    //     0x877b20: ldr             x16, [PP, #0x6030]  ; [pp+0x6030] "extentOffset"
    //     0x877b24: cmp             w7, w16
    //     0x877b28: b.ne            #0x877b4c
    //     0x877b2c: add             w6, w2, #0xa
    //     0x877b30: add             x16, x4, w6, sxtw #1
    //     0x877b34: ldur            w2, [x16, #0xf]
    //     0x877b38: add             x2, x2, HEAP, lsl #32
    //     0x877b3c: sub             w4, w0, w2
    //     0x877b40: add             x0, fp, w4, sxtw #2
    //     0x877b44: ldr             x0, [x0, #8]
    //     0x877b48: b               #0x877b50
    //     0x877b4c: mov             x0, NULL
    // 0x877b50: cmp             w5, NULL
    // 0x877b54: b.ne            #0x877b60
    // 0x877b58: ArrayLoad: r2 = r1[0]  ; List_8
    //     0x877b58: ldur            x2, [x1, #0x17]
    // 0x877b5c: b               #0x877b6c
    // 0x877b60: r2 = LoadInt32Instr(r5)
    //     0x877b60: sbfx            x2, x5, #1, #0x1f
    //     0x877b64: tbz             w5, #0, #0x877b6c
    //     0x877b68: ldur            x2, [x5, #7]
    // 0x877b6c: stur            x2, [fp, #-0x20]
    // 0x877b70: cmp             w0, NULL
    // 0x877b74: b.ne            #0x877b80
    // 0x877b78: LoadField: r0 = r1->field_1f
    //     0x877b78: ldur            x0, [x1, #0x1f]
    // 0x877b7c: b               #0x877b90
    // 0x877b80: r4 = LoadInt32Instr(r0)
    //     0x877b80: sbfx            x4, x0, #1, #0x1f
    //     0x877b84: tbz             w0, #0, #0x877b8c
    //     0x877b88: ldur            x4, [x0, #7]
    // 0x877b8c: mov             x0, x4
    // 0x877b90: stur            x0, [fp, #-0x18]
    // 0x877b94: cmp             w3, NULL
    // 0x877b98: b.ne            #0x877ba4
    // 0x877b9c: LoadField: r3 = r1->field_27
    //     0x877b9c: ldur            w3, [x1, #0x27]
    // 0x877ba0: DecompressPointer r3
    //     0x877ba0: add             x3, x3, HEAP, lsl #32
    // 0x877ba4: stur            x3, [fp, #-0x10]
    // 0x877ba8: LoadField: r4 = r1->field_2b
    //     0x877ba8: ldur            w4, [x1, #0x2b]
    // 0x877bac: DecompressPointer r4
    //     0x877bac: add             x4, x4, HEAP, lsl #32
    // 0x877bb0: stur            x4, [fp, #-8]
    // 0x877bb4: r0 = TextSelection()
    //     0x877bb4: bl              #0x861260  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0x877bb8: ldur            x1, [fp, #-0x20]
    // 0x877bbc: ArrayStore: r0[0] = r1  ; List_8
    //     0x877bbc: stur            x1, [x0, #0x17]
    // 0x877bc0: ldur            x2, [fp, #-0x18]
    // 0x877bc4: StoreField: r0->field_1f = r2
    //     0x877bc4: stur            x2, [x0, #0x1f]
    // 0x877bc8: ldur            x3, [fp, #-0x10]
    // 0x877bcc: StoreField: r0->field_27 = r3
    //     0x877bcc: stur            w3, [x0, #0x27]
    // 0x877bd0: ldur            x3, [fp, #-8]
    // 0x877bd4: StoreField: r0->field_2b = r3
    //     0x877bd4: stur            w3, [x0, #0x2b]
    // 0x877bd8: cmp             x1, x2
    // 0x877bdc: b.ge            #0x877be8
    // 0x877be0: mov             x3, x1
    // 0x877be4: b               #0x877bec
    // 0x877be8: mov             x3, x2
    // 0x877bec: cmp             x1, x2
    // 0x877bf0: b.ge            #0x877bf8
    // 0x877bf4: mov             x1, x2
    // 0x877bf8: StoreField: r0->field_7 = r3
    //     0x877bf8: stur            x3, [x0, #7]
    // 0x877bfc: StoreField: r0->field_f = r1
    //     0x877bfc: stur            x1, [x0, #0xf]
    // 0x877c00: LeaveFrame
    //     0x877c00: mov             SP, fp
    //     0x877c04: ldp             fp, lr, [SP], #0x10
    // 0x877c08: ret
    //     0x877c08: ret             
  }
  _ extendTo(/* No info */) {
    // ** addr: 0xb31200, size: 0xdc
    // 0xb31200: EnterFrame
    //     0xb31200: stp             fp, lr, [SP, #-0x10]!
    //     0xb31204: mov             fp, SP
    // 0xb31208: AllocStack(0x28)
    //     0xb31208: sub             SP, SP, #0x28
    // 0xb3120c: SetupParameters(TextSelection this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xb3120c: mov             x0, x1
    //     0xb31210: stur            x1, [fp, #-8]
    //     0xb31214: stur            x2, [fp, #-0x10]
    // 0xb31218: CheckStackOverflow
    //     0xb31218: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb3121c: cmp             SP, x16
    //     0xb31220: b.ls            #0xb312d4
    // 0xb31224: mov             x1, x0
    // 0xb31228: r0 = extent()
    //     0xb31228: bl              #0x85fb94  ; [package:flutter/src/services/text_editing.dart] TextSelection::extent
    // 0xb3122c: stur            x0, [fp, #-0x18]
    // 0xb31230: r16 = TextPosition
    //     0xb31230: add             x16, PP, #0xe, lsl #12  ; [pp+0xe270] Type: TextPosition
    //     0xb31234: ldr             x16, [x16, #0x270]
    // 0xb31238: r30 = TextPosition
    //     0xb31238: add             lr, PP, #0xe, lsl #12  ; [pp+0xe270] Type: TextPosition
    //     0xb3123c: ldr             lr, [lr, #0x270]
    // 0xb31240: stp             lr, x16, [SP]
    // 0xb31244: r0 = ==()
    //     0xb31244: bl              #0x12b7fbc  ; [dart:core] _Type::==
    // 0xb31248: tbz             w0, #4, #0xb31254
    // 0xb3124c: ldur            x1, [fp, #-0x10]
    // 0xb31250: b               #0xb31294
    // 0xb31254: ldur            x1, [fp, #-0x10]
    // 0xb31258: ldur            x0, [fp, #-0x18]
    // 0xb3125c: LoadField: r2 = r1->field_7
    //     0xb3125c: ldur            x2, [x1, #7]
    // 0xb31260: LoadField: r3 = r0->field_7
    //     0xb31260: ldur            x3, [x0, #7]
    // 0xb31264: cmp             x2, x3
    // 0xb31268: b.ne            #0xb31294
    // 0xb3126c: LoadField: r2 = r1->field_f
    //     0xb3126c: ldur            w2, [x1, #0xf]
    // 0xb31270: DecompressPointer r2
    //     0xb31270: add             x2, x2, HEAP, lsl #32
    // 0xb31274: LoadField: r3 = r0->field_f
    //     0xb31274: ldur            w3, [x0, #0xf]
    // 0xb31278: DecompressPointer r3
    //     0xb31278: add             x3, x3, HEAP, lsl #32
    // 0xb3127c: cmp             w2, w3
    // 0xb31280: b.ne            #0xb31294
    // 0xb31284: ldur            x0, [fp, #-8]
    // 0xb31288: LeaveFrame
    //     0xb31288: mov             SP, fp
    //     0xb3128c: ldp             fp, lr, [SP], #0x10
    // 0xb31290: ret
    //     0xb31290: ret             
    // 0xb31294: LoadField: r2 = r1->field_7
    //     0xb31294: ldur            x2, [x1, #7]
    // 0xb31298: LoadField: r3 = r1->field_f
    //     0xb31298: ldur            w3, [x1, #0xf]
    // 0xb3129c: DecompressPointer r3
    //     0xb3129c: add             x3, x3, HEAP, lsl #32
    // 0xb312a0: r0 = BoxInt64Instr(r2)
    //     0xb312a0: sbfiz           x0, x2, #1, #0x1f
    //     0xb312a4: cmp             x2, x0, asr #1
    //     0xb312a8: b.eq            #0xb312b4
    //     0xb312ac: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb312b0: stur            x2, [x0, #7]
    // 0xb312b4: stp             x3, x0, [SP]
    // 0xb312b8: ldur            x1, [fp, #-8]
    // 0xb312bc: r4 = const [0, 0x3, 0x2, 0x1, affinity, 0x2, extentOffset, 0x1, null]
    //     0xb312bc: add             x4, PP, #0x82, lsl #12  ; [pp+0x82878] List(9) [0, 0x3, 0x2, 0x1, "affinity", 0x2, "extentOffset", 0x1, Null]
    //     0xb312c0: ldr             x4, [x4, #0x878]
    // 0xb312c4: r0 = copyWith()
    //     0xb312c4: bl              #0x877a64  ; [package:flutter/src/services/text_editing.dart] TextSelection::copyWith
    // 0xb312c8: LeaveFrame
    //     0xb312c8: mov             SP, fp
    //     0xb312cc: ldp             fp, lr, [SP], #0x10
    // 0xb312d0: ret
    //     0xb312d0: ret             
    // 0xb312d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb312d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb312d8: b               #0xb31224
  }
  _ expandTo(/* No info */) {
    // ** addr: 0xb312dc, size: 0x1fc
    // 0xb312dc: EnterFrame
    //     0xb312dc: stp             fp, lr, [SP, #-0x10]!
    //     0xb312e0: mov             fp, SP
    // 0xb312e4: AllocStack(0x18)
    //     0xb312e4: sub             SP, SP, #0x18
    // 0xb312e8: SetupParameters(TextSelection this /* r1 => r4 */)
    //     0xb312e8: mov             x4, x1
    // 0xb312ec: CheckStackOverflow
    //     0xb312ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb312f0: cmp             SP, x16
    //     0xb312f4: b.ls            #0xb314d0
    // 0xb312f8: LoadField: r5 = r2->field_7
    //     0xb312f8: ldur            x5, [x2, #7]
    // 0xb312fc: LoadField: r6 = r4->field_7
    //     0xb312fc: ldur            x6, [x4, #7]
    // 0xb31300: cmp             x5, x6
    // 0xb31304: b.lt            #0xb31324
    // 0xb31308: LoadField: r0 = r4->field_f
    //     0xb31308: ldur            x0, [x4, #0xf]
    // 0xb3130c: cmp             x5, x0
    // 0xb31310: b.gt            #0xb31324
    // 0xb31314: mov             x0, x4
    // 0xb31318: LeaveFrame
    //     0xb31318: mov             SP, fp
    //     0xb3131c: ldp             fp, lr, [SP], #0x10
    // 0xb31320: ret
    //     0xb31320: ret             
    // 0xb31324: ArrayLoad: r0 = r4[0]  ; List_8
    //     0xb31324: ldur            x0, [x4, #0x17]
    // 0xb31328: LoadField: r1 = r4->field_1f
    //     0xb31328: ldur            x1, [x4, #0x1f]
    // 0xb3132c: cmp             x0, x1
    // 0xb31330: r16 = true
    //     0xb31330: add             x16, NULL, #0x20  ; true
    // 0xb31334: r17 = false
    //     0xb31334: add             x17, NULL, #0x30  ; false
    // 0xb31338: csel            x7, x16, x17, le
    // 0xb3133c: cmp             x5, x6
    // 0xb31340: b.gt            #0xb3140c
    // 0xb31344: tbnz            w3, #4, #0xb313a4
    // 0xb31348: LoadField: r3 = r4->field_f
    //     0xb31348: ldur            x3, [x4, #0xf]
    // 0xb3134c: LoadField: r6 = r2->field_f
    //     0xb3134c: ldur            w6, [x2, #0xf]
    // 0xb31350: DecompressPointer r6
    //     0xb31350: add             x6, x6, HEAP, lsl #32
    // 0xb31354: r0 = BoxInt64Instr(r3)
    //     0xb31354: sbfiz           x0, x3, #1, #0x1f
    //     0xb31358: cmp             x3, x0, asr #1
    //     0xb3135c: b.eq            #0xb31368
    //     0xb31360: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb31364: stur            x3, [x0, #7]
    // 0xb31368: mov             x2, x0
    // 0xb3136c: r0 = BoxInt64Instr(r5)
    //     0xb3136c: sbfiz           x0, x5, #1, #0x1f
    //     0xb31370: cmp             x5, x0, asr #1
    //     0xb31374: b.eq            #0xb31380
    //     0xb31378: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb3137c: stur            x5, [x0, #7]
    // 0xb31380: stp             x0, x2, [SP, #8]
    // 0xb31384: str             x6, [SP]
    // 0xb31388: mov             x1, x4
    // 0xb3138c: r4 = const [0, 0x4, 0x3, 0x1, affinity, 0x3, baseOffset, 0x1, extentOffset, 0x2, null]
    //     0xb3138c: add             x4, PP, #0xad, lsl #12  ; [pp+0xad698] List(11) [0, 0x4, 0x3, 0x1, "affinity", 0x3, "baseOffset", 0x1, "extentOffset", 0x2, Null]
    //     0xb31390: ldr             x4, [x4, #0x698]
    // 0xb31394: r0 = copyWith()
    //     0xb31394: bl              #0x877a64  ; [package:flutter/src/services/text_editing.dart] TextSelection::copyWith
    // 0xb31398: LeaveFrame
    //     0xb31398: mov             SP, fp
    //     0xb3139c: ldp             fp, lr, [SP], #0x10
    // 0xb313a0: ret
    //     0xb313a0: ret             
    // 0xb313a4: tbnz            w7, #4, #0xb313b0
    // 0xb313a8: mov             x2, x5
    // 0xb313ac: b               #0xb313b4
    // 0xb313b0: mov             x2, x0
    // 0xb313b4: tbnz            w7, #4, #0xb313c0
    // 0xb313b8: mov             x3, x1
    // 0xb313bc: b               #0xb313c4
    // 0xb313c0: mov             x3, x5
    // 0xb313c4: r0 = BoxInt64Instr(r2)
    //     0xb313c4: sbfiz           x0, x2, #1, #0x1f
    //     0xb313c8: cmp             x2, x0, asr #1
    //     0xb313cc: b.eq            #0xb313d8
    //     0xb313d0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb313d4: stur            x2, [x0, #7]
    // 0xb313d8: mov             x2, x0
    // 0xb313dc: r0 = BoxInt64Instr(r3)
    //     0xb313dc: sbfiz           x0, x3, #1, #0x1f
    //     0xb313e0: cmp             x3, x0, asr #1
    //     0xb313e4: b.eq            #0xb313f0
    //     0xb313e8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb313ec: stur            x3, [x0, #7]
    // 0xb313f0: stp             x0, x2, [SP]
    // 0xb313f4: mov             x1, x4
    // 0xb313f8: r4 = const [0, 0x3, 0x2, 0x1, baseOffset, 0x1, extentOffset, 0x2, null]
    //     0xb313f8: ldr             x4, [PP, #0x6228]  ; [pp+0x6228] List(9) [0, 0x3, 0x2, 0x1, "baseOffset", 0x1, "extentOffset", 0x2, Null]
    // 0xb313fc: r0 = copyWith()
    //     0xb313fc: bl              #0x877a64  ; [package:flutter/src/services/text_editing.dart] TextSelection::copyWith
    // 0xb31400: LeaveFrame
    //     0xb31400: mov             SP, fp
    //     0xb31404: ldp             fp, lr, [SP], #0x10
    // 0xb31408: ret
    //     0xb31408: ret             
    // 0xb3140c: tbnz            w3, #4, #0xb31468
    // 0xb31410: LoadField: r3 = r2->field_f
    //     0xb31410: ldur            w3, [x2, #0xf]
    // 0xb31414: DecompressPointer r3
    //     0xb31414: add             x3, x3, HEAP, lsl #32
    // 0xb31418: r0 = BoxInt64Instr(r6)
    //     0xb31418: sbfiz           x0, x6, #1, #0x1f
    //     0xb3141c: cmp             x6, x0, asr #1
    //     0xb31420: b.eq            #0xb3142c
    //     0xb31424: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb31428: stur            x6, [x0, #7]
    // 0xb3142c: mov             x2, x0
    // 0xb31430: r0 = BoxInt64Instr(r5)
    //     0xb31430: sbfiz           x0, x5, #1, #0x1f
    //     0xb31434: cmp             x5, x0, asr #1
    //     0xb31438: b.eq            #0xb31444
    //     0xb3143c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb31440: stur            x5, [x0, #7]
    // 0xb31444: stp             x0, x2, [SP, #8]
    // 0xb31448: str             x3, [SP]
    // 0xb3144c: mov             x1, x4
    // 0xb31450: r4 = const [0, 0x4, 0x3, 0x1, affinity, 0x3, baseOffset, 0x1, extentOffset, 0x2, null]
    //     0xb31450: add             x4, PP, #0xad, lsl #12  ; [pp+0xad698] List(11) [0, 0x4, 0x3, 0x1, "affinity", 0x3, "baseOffset", 0x1, "extentOffset", 0x2, Null]
    //     0xb31454: ldr             x4, [x4, #0x698]
    // 0xb31458: r0 = copyWith()
    //     0xb31458: bl              #0x877a64  ; [package:flutter/src/services/text_editing.dart] TextSelection::copyWith
    // 0xb3145c: LeaveFrame
    //     0xb3145c: mov             SP, fp
    //     0xb31460: ldp             fp, lr, [SP], #0x10
    // 0xb31464: ret
    //     0xb31464: ret             
    // 0xb31468: tbnz            w7, #4, #0xb31474
    // 0xb3146c: mov             x2, x0
    // 0xb31470: b               #0xb31478
    // 0xb31474: mov             x2, x5
    // 0xb31478: tbnz            w7, #4, #0xb31484
    // 0xb3147c: mov             x3, x5
    // 0xb31480: b               #0xb31488
    // 0xb31484: mov             x3, x1
    // 0xb31488: r0 = BoxInt64Instr(r2)
    //     0xb31488: sbfiz           x0, x2, #1, #0x1f
    //     0xb3148c: cmp             x2, x0, asr #1
    //     0xb31490: b.eq            #0xb3149c
    //     0xb31494: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb31498: stur            x2, [x0, #7]
    // 0xb3149c: mov             x2, x0
    // 0xb314a0: r0 = BoxInt64Instr(r3)
    //     0xb314a0: sbfiz           x0, x3, #1, #0x1f
    //     0xb314a4: cmp             x3, x0, asr #1
    //     0xb314a8: b.eq            #0xb314b4
    //     0xb314ac: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb314b0: stur            x3, [x0, #7]
    // 0xb314b4: stp             x0, x2, [SP]
    // 0xb314b8: mov             x1, x4
    // 0xb314bc: r4 = const [0, 0x3, 0x2, 0x1, baseOffset, 0x1, extentOffset, 0x2, null]
    //     0xb314bc: ldr             x4, [PP, #0x6228]  ; [pp+0x6228] List(9) [0, 0x3, 0x2, 0x1, "baseOffset", 0x1, "extentOffset", 0x2, Null]
    // 0xb314c0: r0 = copyWith()
    //     0xb314c0: bl              #0x877a64  ; [package:flutter/src/services/text_editing.dart] TextSelection::copyWith
    // 0xb314c4: LeaveFrame
    //     0xb314c4: mov             SP, fp
    //     0xb314c8: ldp             fp, lr, [SP], #0x10
    // 0xb314cc: ret
    //     0xb314cc: ret             
    // 0xb314d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb314d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb314d4: b               #0xb312f8
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x1148844, size: 0x1f0
    // 0x1148844: EnterFrame
    //     0x1148844: stp             fp, lr, [SP, #-0x10]!
    //     0x1148848: mov             fp, SP
    // 0x114884c: AllocStack(0x20)
    //     0x114884c: sub             SP, SP, #0x20
    // 0x1148850: CheckStackOverflow
    //     0x1148850: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1148854: cmp             SP, x16
    //     0x1148858: b.ls            #0x1148a2c
    // 0x114885c: ldr             x0, [fp, #0x10]
    // 0x1148860: LoadField: r1 = r0->field_7
    //     0x1148860: ldur            x1, [x0, #7]
    // 0x1148864: tbnz            x1, #0x3f, #0x11489a0
    // 0x1148868: LoadField: r2 = r0->field_f
    //     0x1148868: ldur            x2, [x0, #0xf]
    // 0x114886c: tbnz            x2, #0x3f, #0x11489a0
    // 0x1148870: cmp             x1, x2
    // 0x1148874: b.ne            #0x1148894
    // 0x1148878: LoadField: r1 = r0->field_27
    //     0x1148878: ldur            w1, [x0, #0x27]
    // 0x114887c: DecompressPointer r1
    //     0x114887c: add             x1, x1, HEAP, lsl #32
    // 0x1148880: str             x1, [SP]
    // 0x1148884: r0 = _getHash()
    //     0x1148884: bl              #0x84c644  ; [dart:core] ::_getHash
    // 0x1148888: r1 = LoadInt32Instr(r0)
    //     0x1148888: sbfx            x1, x0, #1, #0x1f
    // 0x114888c: mov             x3, x1
    // 0x1148890: b               #0x11488a8
    // 0x1148894: r16 = Instance_TextAffinity
    //     0x1148894: ldr             x16, [PP, #0x4bb0]  ; [pp+0x4bb0] Obj!TextAffinity@12c7361
    // 0x1148898: str             x16, [SP]
    // 0x114889c: r0 = _getHash()
    //     0x114889c: bl              #0x84c644  ; [dart:core] ::_getHash
    // 0x11488a0: r1 = LoadInt32Instr(r0)
    //     0x11488a0: sbfx            x1, x0, #1, #0x1f
    // 0x11488a4: mov             x3, x1
    // 0x11488a8: ldr             x2, [fp, #0x10]
    // 0x11488ac: stur            x3, [fp, #-8]
    // 0x11488b0: ArrayLoad: r4 = r2[0]  ; List_8
    //     0x11488b0: ldur            x4, [x2, #0x17]
    // 0x11488b4: r0 = BoxInt64Instr(r4)
    //     0x11488b4: sbfiz           x0, x4, #1, #0x1f
    //     0x11488b8: cmp             x4, x0, asr #1
    //     0x11488bc: b.eq            #0x11488c8
    //     0x11488c0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x11488c4: stur            x4, [x0, #7]
    // 0x11488c8: r1 = 60
    //     0x11488c8: mov             x1, #0x3c
    // 0x11488cc: branchIfSmi(r0, 0x11488d8)
    //     0x11488cc: tbz             w0, #0, #0x11488d8
    // 0x11488d0: r1 = LoadClassIdInstr(r0)
    //     0x11488d0: ldur            x1, [x0, #-1]
    //     0x11488d4: ubfx            x1, x1, #0xc, #0x14
    // 0x11488d8: str             x0, [SP]
    // 0x11488dc: mov             x0, x1
    // 0x11488e0: r0 = GDT[cid_x0 + 0x70de]()
    //     0x11488e0: mov             x17, #0x70de
    //     0x11488e4: add             lr, x0, x17
    //     0x11488e8: ldr             lr, [x21, lr, lsl #3]
    //     0x11488ec: blr             lr
    // 0x11488f0: mov             x3, x0
    // 0x11488f4: ldr             x2, [fp, #0x10]
    // 0x11488f8: stur            x3, [fp, #-0x10]
    // 0x11488fc: LoadField: r4 = r2->field_1f
    //     0x11488fc: ldur            x4, [x2, #0x1f]
    // 0x1148900: r0 = BoxInt64Instr(r4)
    //     0x1148900: sbfiz           x0, x4, #1, #0x1f
    //     0x1148904: cmp             x4, x0, asr #1
    //     0x1148908: b.eq            #0x1148914
    //     0x114890c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1148910: stur            x4, [x0, #7]
    // 0x1148914: r1 = 60
    //     0x1148914: mov             x1, #0x3c
    // 0x1148918: branchIfSmi(r0, 0x1148924)
    //     0x1148918: tbz             w0, #0, #0x1148924
    // 0x114891c: r1 = LoadClassIdInstr(r0)
    //     0x114891c: ldur            x1, [x0, #-1]
    //     0x1148920: ubfx            x1, x1, #0xc, #0x14
    // 0x1148924: str             x0, [SP]
    // 0x1148928: mov             x0, x1
    // 0x114892c: r0 = GDT[cid_x0 + 0x70de]()
    //     0x114892c: mov             x17, #0x70de
    //     0x1148930: add             lr, x0, x17
    //     0x1148934: ldr             lr, [x21, lr, lsl #3]
    //     0x1148938: blr             lr
    // 0x114893c: mov             x1, x0
    // 0x1148940: ldr             x0, [fp, #0x10]
    // 0x1148944: LoadField: r2 = r0->field_2b
    //     0x1148944: ldur            w2, [x0, #0x2b]
    // 0x1148948: DecompressPointer r2
    //     0x1148948: add             x2, x2, HEAP, lsl #32
    // 0x114894c: tst             x2, #0x10
    // 0x1148950: csetm           x0, eq
    // 0x1148954: r16 = -12
    //     0x1148954: mov             x16, #-0xc
    // 0x1148958: and             x0, x0, x16
    // 0x114895c: add             x0, x0, #0x9aa
    // 0x1148960: ldur            x2, [fp, #-8]
    // 0x1148964: lsl             x3, x2, #1
    // 0x1148968: stp             x0, x3, [SP]
    // 0x114896c: mov             x2, x1
    // 0x1148970: ldur            x1, [fp, #-0x10]
    // 0x1148974: r4 = const [0, 0x4, 0x2, 0x4, null]
    //     0x1148974: ldr             x4, [PP, #0x1388]  ; [pp+0x1388] List(5) [0, 0x4, 0x2, 0x4, Null]
    // 0x1148978: r0 = hash()
    //     0x1148978: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x114897c: mov             x2, x0
    // 0x1148980: r0 = BoxInt64Instr(r2)
    //     0x1148980: sbfiz           x0, x2, #1, #0x1f
    //     0x1148984: cmp             x2, x0, asr #1
    //     0x1148988: b.eq            #0x1148994
    //     0x114898c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1148990: stur            x2, [x0, #7]
    // 0x1148994: LeaveFrame
    //     0x1148994: mov             SP, fp
    //     0x1148998: ldp             fp, lr, [SP], #0x10
    // 0x114899c: ret
    //     0x114899c: ret             
    // 0x11489a0: r0 = 2
    //     0x11489a0: mov             x0, #2
    // 0x11489a4: r16 = LoadInt32Instr(r0)
    //     0x11489a4: sbfx            x16, x0, #1, #0x1f
    // 0x11489a8: r17 = 11601
    //     0x11489a8: mov             x17, #0x2d51
    // 0x11489ac: mul             x1, x16, x17
    // 0x11489b0: umulh           x16, x16, x17
    // 0x11489b4: eor             x1, x1, x16
    // 0x11489b8: r1 = 0
    //     0x11489b8: eor             x1, x1, x1, lsr #32
    // 0x11489bc: ubfiz           x1, x1, #1, #0x1e
    // 0x11489c0: r0 = LoadInt32Instr(r1)
    //     0x11489c0: sbfx            x0, x1, #1, #0x1f
    // 0x11489c4: neg             x1, x0
    // 0x11489c8: stur            x1, [fp, #-8]
    // 0x11489cc: r16 = Instance_TextAffinity
    //     0x11489cc: ldr             x16, [PP, #0x4bb0]  ; [pp+0x4bb0] Obj!TextAffinity@12c7361
    // 0x11489d0: str             x16, [SP]
    // 0x11489d4: r0 = _getHash()
    //     0x11489d4: bl              #0x84c644  ; [dart:core] ::_getHash
    // 0x11489d8: mov             x3, x0
    // 0x11489dc: ldur            x2, [fp, #-8]
    // 0x11489e0: r0 = BoxInt64Instr(r2)
    //     0x11489e0: sbfiz           x0, x2, #1, #0x1f
    //     0x11489e4: cmp             x2, x0, asr #1
    //     0x11489e8: b.eq            #0x11489f4
    //     0x11489ec: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x11489f0: stur            x2, [x0, #7]
    // 0x11489f4: str             x3, [SP]
    // 0x11489f8: mov             x1, x0
    // 0x11489fc: mov             x2, x0
    // 0x1148a00: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x1148a00: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x1148a04: r0 = hash()
    //     0x1148a04: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x1148a08: mov             x2, x0
    // 0x1148a0c: r0 = BoxInt64Instr(r2)
    //     0x1148a0c: sbfiz           x0, x2, #1, #0x1f
    //     0x1148a10: cmp             x2, x0, asr #1
    //     0x1148a14: b.eq            #0x1148a20
    //     0x1148a18: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1148a1c: stur            x2, [x0, #7]
    // 0x1148a20: LeaveFrame
    //     0x1148a20: mov             SP, fp
    //     0x1148a24: ldp             fp, lr, [SP], #0x10
    // 0x1148a28: ret
    //     0x1148a28: ret             
    // 0x1148a2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1148a2c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1148a30: b               #0x114885c
  }
  _ ==(/* No info */) {
    // ** addr: 0x128f7e8, size: 0xf4
    // 0x128f7e8: ldr             x1, [SP]
    // 0x128f7ec: cmp             w1, NULL
    // 0x128f7f0: b.ne            #0x128f7fc
    // 0x128f7f4: r0 = false
    //     0x128f7f4: add             x0, NULL, #0x30  ; false
    // 0x128f7f8: ret
    //     0x128f7f8: ret             
    // 0x128f7fc: ldr             x2, [SP, #8]
    // 0x128f800: cmp             w2, w1
    // 0x128f804: b.ne            #0x128f810
    // 0x128f808: r0 = true
    //     0x128f808: add             x0, NULL, #0x20  ; true
    // 0x128f80c: ret
    //     0x128f80c: ret             
    // 0x128f810: r3 = 60
    //     0x128f810: mov             x3, #0x3c
    // 0x128f814: branchIfSmi(r1, 0x128f820)
    //     0x128f814: tbz             w1, #0, #0x128f820
    // 0x128f818: r3 = LoadClassIdInstr(r1)
    //     0x128f818: ldur            x3, [x1, #-1]
    //     0x128f81c: ubfx            x3, x3, #0xc, #0x14
    // 0x128f820: cmp             x3, #0xe8e
    // 0x128f824: b.eq            #0x128f830
    // 0x128f828: r0 = false
    //     0x128f828: add             x0, NULL, #0x30  ; false
    // 0x128f82c: ret
    //     0x128f82c: ret             
    // 0x128f830: LoadField: r3 = r2->field_7
    //     0x128f830: ldur            x3, [x2, #7]
    // 0x128f834: tbnz            x3, #0x3f, #0x128f8b0
    // 0x128f838: LoadField: r4 = r2->field_f
    //     0x128f838: ldur            x4, [x2, #0xf]
    // 0x128f83c: tbnz            x4, #0x3f, #0x128f8b0
    // 0x128f840: ArrayLoad: r5 = r1[0]  ; List_8
    //     0x128f840: ldur            x5, [x1, #0x17]
    // 0x128f844: ArrayLoad: r6 = r2[0]  ; List_8
    //     0x128f844: ldur            x6, [x2, #0x17]
    // 0x128f848: cmp             x5, x6
    // 0x128f84c: b.ne            #0x128f8a8
    // 0x128f850: LoadField: r5 = r1->field_1f
    //     0x128f850: ldur            x5, [x1, #0x1f]
    // 0x128f854: LoadField: r6 = r2->field_1f
    //     0x128f854: ldur            x6, [x2, #0x1f]
    // 0x128f858: cmp             x5, x6
    // 0x128f85c: b.ne            #0x128f8a8
    // 0x128f860: cmp             x3, x4
    // 0x128f864: b.ne            #0x128f880
    // 0x128f868: LoadField: r3 = r1->field_27
    //     0x128f868: ldur            w3, [x1, #0x27]
    // 0x128f86c: DecompressPointer r3
    //     0x128f86c: add             x3, x3, HEAP, lsl #32
    // 0x128f870: LoadField: r4 = r2->field_27
    //     0x128f870: ldur            w4, [x2, #0x27]
    // 0x128f874: DecompressPointer r4
    //     0x128f874: add             x4, x4, HEAP, lsl #32
    // 0x128f878: cmp             w3, w4
    // 0x128f87c: b.ne            #0x128f8a8
    // 0x128f880: LoadField: r3 = r1->field_2b
    //     0x128f880: ldur            w3, [x1, #0x2b]
    // 0x128f884: DecompressPointer r3
    //     0x128f884: add             x3, x3, HEAP, lsl #32
    // 0x128f888: LoadField: r4 = r2->field_2b
    //     0x128f888: ldur            w4, [x2, #0x2b]
    // 0x128f88c: DecompressPointer r4
    //     0x128f88c: add             x4, x4, HEAP, lsl #32
    // 0x128f890: cmp             w3, w4
    // 0x128f894: r16 = true
    //     0x128f894: add             x16, NULL, #0x20  ; true
    // 0x128f898: r17 = false
    //     0x128f898: add             x17, NULL, #0x30  ; false
    // 0x128f89c: csel            x2, x16, x17, eq
    // 0x128f8a0: mov             x0, x2
    // 0x128f8a4: b               #0x128f8ac
    // 0x128f8a8: r0 = false
    //     0x128f8a8: add             x0, NULL, #0x30  ; false
    // 0x128f8ac: ret
    //     0x128f8ac: ret             
    // 0x128f8b0: LoadField: r2 = r1->field_7
    //     0x128f8b0: ldur            x2, [x1, #7]
    // 0x128f8b4: tbnz            x2, #0x3f, #0x128f8d0
    // 0x128f8b8: LoadField: r2 = r1->field_f
    //     0x128f8b8: ldur            x2, [x1, #0xf]
    // 0x128f8bc: tbz             x2, #0x3f, #0x128f8c8
    // 0x128f8c0: r1 = false
    //     0x128f8c0: add             x1, NULL, #0x30  ; false
    // 0x128f8c4: b               #0x128f8cc
    // 0x128f8c8: r1 = true
    //     0x128f8c8: add             x1, NULL, #0x20  ; true
    // 0x128f8cc: b               #0x128f8d4
    // 0x128f8d0: r1 = false
    //     0x128f8d0: add             x1, NULL, #0x30  ; false
    // 0x128f8d4: eor             x0, x1, #0x10
    // 0x128f8d8: ret
    //     0x128f8d8: ret             
  }
}
