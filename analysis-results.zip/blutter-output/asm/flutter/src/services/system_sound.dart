// lib: , url: package:flutter/src/services/system_sound.dart

// class id: 1049099, size: 0x8
class :: {
}

// class id: 2740, size: 0x8, field offset: 0x8
abstract class SystemSound extends Object {

  static _ play(/* No info */) async {
    // ** addr: 0xd22b0c, size: 0x6c
    // 0xd22b0c: EnterFrame
    //     0xd22b0c: stp             fp, lr, [SP, #-0x10]!
    //     0xd22b10: mov             fp, SP
    // 0xd22b14: AllocStack(0x30)
    //     0xd22b14: sub             SP, SP, #0x30
    // 0xd22b18: SetupParameters(dynamic _ /* r1 => r1, fp-0x10 */)
    //     0xd22b18: stur            NULL, [fp, #-8]
    //     0xd22b1c: stur            x1, [fp, #-0x10]
    // 0xd22b20: CheckStackOverflow
    //     0xd22b20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd22b24: cmp             SP, x16
    //     0xd22b28: b.ls            #0xd22b70
    // 0xd22b2c: InitAsync() -> Future<void?>
    //     0xd22b2c: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0xd22b30: bl              #0x7f5e44  ; InitAsyncStub
    // 0xd22b34: ldur            x1, [fp, #-0x10]
    // 0xd22b38: r0 = _enumToString()
    //     0xd22b38: bl              #0x11ab930  ; [package:flutter/src/services/system_sound.dart] SystemSoundType::_enumToString
    // 0xd22b3c: r16 = <void?>
    //     0xd22b3c: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xd22b40: r30 = Instance_OptionalMethodChannel
    //     0xd22b40: ldr             lr, [PP, #0x1960]  ; [pp+0x1960] Obj!OptionalMethodChannel@129bec1
    // 0xd22b44: stp             lr, x16, [SP, #0x10]
    // 0xd22b48: r16 = "SystemSound.play"
    //     0xd22b48: add             x16, PP, #0x26, lsl #12  ; [pp+0x26750] "SystemSound.play"
    //     0xd22b4c: ldr             x16, [x16, #0x750]
    // 0xd22b50: stp             x0, x16, [SP]
    // 0xd22b54: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xd22b54: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xd22b58: r0 = invokeMethod()
    //     0xd22b58: bl              #0x130ad0c  ; [package:flutter/src/services/platform_channel.dart] OptionalMethodChannel::invokeMethod
    // 0xd22b5c: mov             x1, x0
    // 0xd22b60: stur            x1, [fp, #-0x10]
    // 0xd22b64: r0 = Await()
    //     0xd22b64: bl              #0x7f5c00  ; AwaitStub
    // 0xd22b68: r0 = Null
    //     0xd22b68: mov             x0, NULL
    // 0xd22b6c: r0 = ReturnAsyncNotFuture()
    //     0xd22b6c: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xd22b70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd22b70: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd22b74: b               #0xd22b2c
  }
}

// class id: 8200, size: 0x14, field offset: 0x14
enum SystemSoundType extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11ab930, size: 0x64
    // 0x11ab930: EnterFrame
    //     0x11ab930: stp             fp, lr, [SP, #-0x10]!
    //     0x11ab934: mov             fp, SP
    // 0x11ab938: AllocStack(0x10)
    //     0x11ab938: sub             SP, SP, #0x10
    // 0x11ab93c: SetupParameters(SystemSoundType this /* r1 => r0, fp-0x8 */)
    //     0x11ab93c: mov             x0, x1
    //     0x11ab940: stur            x1, [fp, #-8]
    // 0x11ab944: CheckStackOverflow
    //     0x11ab944: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11ab948: cmp             SP, x16
    //     0x11ab94c: b.ls            #0x11ab98c
    // 0x11ab950: r1 = Null
    //     0x11ab950: mov             x1, NULL
    // 0x11ab954: r2 = 4
    //     0x11ab954: mov             x2, #4
    // 0x11ab958: r0 = AllocateArray()
    //     0x11ab958: bl              #0x13df928  ; AllocateArrayStub
    // 0x11ab95c: r16 = "SystemSoundType."
    //     0x11ab95c: add             x16, PP, #0x26, lsl #12  ; [pp+0x26758] "SystemSoundType."
    //     0x11ab960: ldr             x16, [x16, #0x758]
    // 0x11ab964: StoreField: r0->field_f = r16
    //     0x11ab964: stur            w16, [x0, #0xf]
    // 0x11ab968: ldur            x1, [fp, #-8]
    // 0x11ab96c: LoadField: r2 = r1->field_f
    //     0x11ab96c: ldur            w2, [x1, #0xf]
    // 0x11ab970: DecompressPointer r2
    //     0x11ab970: add             x2, x2, HEAP, lsl #32
    // 0x11ab974: StoreField: r0->field_13 = r2
    //     0x11ab974: stur            w2, [x0, #0x13]
    // 0x11ab978: str             x0, [SP]
    // 0x11ab97c: r0 = _interpolate()
    //     0x11ab97c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11ab980: LeaveFrame
    //     0x11ab980: mov             SP, fp
    //     0x11ab984: ldp             fp, lr, [SP], #0x10
    // 0x11ab988: ret
    //     0x11ab988: ret             
    // 0x11ab98c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11ab98c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11ab990: b               #0x11ab950
  }
}
