// lib: , url: package:flutter/src/services/keyboard_key.g.dart

// class id: 1049076, size: 0x8
class :: {
}

// class id: 5026, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class KeyboardKey extends _MixinApplication3&Object&Diagnosticable {
}

// class id: 5027, size: 0x10, field offset: 0x8
//   const constructor, 
class PhysicalKeyboardKey extends KeyboardKey {

  _Mint field_8;

  static _ findKeyByCode(/* No info */) {
    // ** addr: 0x84a4b0, size: 0x4c
    // 0x84a4b0: EnterFrame
    //     0x84a4b0: stp             fp, lr, [SP, #-0x10]!
    //     0x84a4b4: mov             fp, SP
    // 0x84a4b8: mov             x2, x1
    // 0x84a4bc: CheckStackOverflow
    //     0x84a4bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84a4c0: cmp             SP, x16
    //     0x84a4c4: b.ls            #0x84a4f4
    // 0x84a4c8: r0 = BoxInt64Instr(r2)
    //     0x84a4c8: sbfiz           x0, x2, #1, #0x1f
    //     0x84a4cc: cmp             x2, x0, asr #1
    //     0x84a4d0: b.eq            #0x84a4dc
    //     0x84a4d4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x84a4d8: stur            x2, [x0, #7]
    // 0x84a4dc: mov             x2, x0
    // 0x84a4e0: r1 = _ConstMap len:269
    //     0x84a4e0: ldr             x1, [PP, #0x40e0]  ; [pp+0x40e0] Map<int, PhysicalKeyboardKey>(269)
    // 0x84a4e4: r0 = []()
    //     0x84a4e4: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x84a4e8: LeaveFrame
    //     0x84a4e8: mov             SP, fp
    //     0x84a4ec: ldp             fp, lr, [SP], #0x10
    // 0x84a4f0: ret
    //     0x84a4f0: ret             
    // 0x84a4f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84a4f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84a4f8: b               #0x84a4c8
  }
  _ ==(/* No info */) {
    // ** addr: 0x1279a00, size: 0xe8
    // 0x1279a00: EnterFrame
    //     0x1279a00: stp             fp, lr, [SP, #-0x10]!
    //     0x1279a04: mov             fp, SP
    // 0x1279a08: AllocStack(0x10)
    //     0x1279a08: sub             SP, SP, #0x10
    // 0x1279a0c: CheckStackOverflow
    //     0x1279a0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1279a10: cmp             SP, x16
    //     0x1279a14: b.ls            #0x1279ae0
    // 0x1279a18: ldr             x0, [fp, #0x10]
    // 0x1279a1c: cmp             w0, NULL
    // 0x1279a20: b.ne            #0x1279a34
    // 0x1279a24: r0 = false
    //     0x1279a24: add             x0, NULL, #0x30  ; false
    // 0x1279a28: LeaveFrame
    //     0x1279a28: mov             SP, fp
    //     0x1279a2c: ldp             fp, lr, [SP], #0x10
    // 0x1279a30: ret
    //     0x1279a30: ret             
    // 0x1279a34: ldr             x1, [fp, #0x18]
    // 0x1279a38: cmp             w1, w0
    // 0x1279a3c: b.ne            #0x1279a50
    // 0x1279a40: r0 = true
    //     0x1279a40: add             x0, NULL, #0x20  ; true
    // 0x1279a44: LeaveFrame
    //     0x1279a44: mov             SP, fp
    //     0x1279a48: ldp             fp, lr, [SP], #0x10
    // 0x1279a4c: ret
    //     0x1279a4c: ret             
    // 0x1279a50: str             x0, [SP]
    // 0x1279a54: r0 = runtimeType()
    //     0x1279a54: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x1279a58: r1 = LoadClassIdInstr(r0)
    //     0x1279a58: ldur            x1, [x0, #-1]
    //     0x1279a5c: ubfx            x1, x1, #0xc, #0x14
    // 0x1279a60: r16 = PhysicalKeyboardKey
    //     0x1279a60: ldr             x16, [PP, #0x3ab8]  ; [pp+0x3ab8] Type: PhysicalKeyboardKey
    // 0x1279a64: stp             x16, x0, [SP]
    // 0x1279a68: mov             x0, x1
    // 0x1279a6c: mov             lr, x0
    // 0x1279a70: ldr             lr, [x21, lr, lsl #3]
    // 0x1279a74: blr             lr
    // 0x1279a78: tbz             w0, #4, #0x1279a8c
    // 0x1279a7c: r0 = false
    //     0x1279a7c: add             x0, NULL, #0x30  ; false
    // 0x1279a80: LeaveFrame
    //     0x1279a80: mov             SP, fp
    //     0x1279a84: ldp             fp, lr, [SP], #0x10
    // 0x1279a88: ret
    //     0x1279a88: ret             
    // 0x1279a8c: ldr             x1, [fp, #0x10]
    // 0x1279a90: r2 = 60
    //     0x1279a90: mov             x2, #0x3c
    // 0x1279a94: branchIfSmi(r1, 0x1279aa0)
    //     0x1279a94: tbz             w1, #0, #0x1279aa0
    // 0x1279a98: r2 = LoadClassIdInstr(r1)
    //     0x1279a98: ldur            x2, [x1, #-1]
    //     0x1279a9c: ubfx            x2, x2, #0xc, #0x14
    // 0x1279aa0: r17 = 5027
    //     0x1279aa0: mov             x17, #0x13a3
    // 0x1279aa4: cmp             x2, x17
    // 0x1279aa8: b.ne            #0x1279ad0
    // 0x1279aac: ldr             x2, [fp, #0x18]
    // 0x1279ab0: LoadField: r3 = r1->field_7
    //     0x1279ab0: ldur            x3, [x1, #7]
    // 0x1279ab4: LoadField: r1 = r2->field_7
    //     0x1279ab4: ldur            x1, [x2, #7]
    // 0x1279ab8: cmp             x3, x1
    // 0x1279abc: r16 = true
    //     0x1279abc: add             x16, NULL, #0x20  ; true
    // 0x1279ac0: r17 = false
    //     0x1279ac0: add             x17, NULL, #0x30  ; false
    // 0x1279ac4: csel            x2, x16, x17, eq
    // 0x1279ac8: mov             x0, x2
    // 0x1279acc: b               #0x1279ad4
    // 0x1279ad0: r0 = false
    //     0x1279ad0: add             x0, NULL, #0x30  ; false
    // 0x1279ad4: LeaveFrame
    //     0x1279ad4: mov             SP, fp
    //     0x1279ad8: ldp             fp, lr, [SP], #0x10
    // 0x1279adc: ret
    //     0x1279adc: ret             
    // 0x1279ae0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1279ae0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1279ae4: b               #0x1279a18
  }
}

// class id: 5028, size: 0x10, field offset: 0x8
//   const constructor, 
class LogicalKeyboardKey extends KeyboardKey {

  _Mint field_8;
  static late final Map<LogicalKeyboardKey, Set<LogicalKeyboardKey>> _reverseSynonyms; // offset: 0x900

  static _ findKeyByKeyId(/* No info */) {
    // ** addr: 0x84a464, size: 0x4c
    // 0x84a464: EnterFrame
    //     0x84a464: stp             fp, lr, [SP, #-0x10]!
    //     0x84a468: mov             fp, SP
    // 0x84a46c: mov             x2, x1
    // 0x84a470: CheckStackOverflow
    //     0x84a470: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84a474: cmp             SP, x16
    //     0x84a478: b.ls            #0x84a4a8
    // 0x84a47c: r0 = BoxInt64Instr(r2)
    //     0x84a47c: sbfiz           x0, x2, #1, #0x1f
    //     0x84a480: cmp             x2, x0, asr #1
    //     0x84a484: b.eq            #0x84a490
    //     0x84a488: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x84a48c: stur            x2, [x0, #7]
    // 0x84a490: mov             x2, x0
    // 0x84a494: r1 = _ConstMap len:444
    //     0x84a494: ldr             x1, [PP, #0x40d8]  ; [pp+0x40d8] Map<int, LogicalKeyboardKey>(444)
    // 0x84a498: r0 = []()
    //     0x84a498: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x84a49c: LeaveFrame
    //     0x84a49c: mov             SP, fp
    //     0x84a4a0: ldp             fp, lr, [SP], #0x10
    // 0x84a4a4: ret
    //     0x84a4a4: ret             
    // 0x84a4a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84a4a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84a4ac: b               #0x84a47c
  }
  static _ expandSynonyms(/* No info */) {
    // ** addr: 0x1244b1c, size: 0x68
    // 0x1244b1c: EnterFrame
    //     0x1244b1c: stp             fp, lr, [SP, #-0x10]!
    //     0x1244b20: mov             fp, SP
    // 0x1244b24: AllocStack(0x20)
    //     0x1244b24: sub             SP, SP, #0x20
    // 0x1244b28: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */)
    //     0x1244b28: mov             x0, x1
    //     0x1244b2c: stur            x1, [fp, #-8]
    // 0x1244b30: CheckStackOverflow
    //     0x1244b30: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1244b34: cmp             SP, x16
    //     0x1244b38: b.ls            #0x1244b7c
    // 0x1244b3c: r1 = Function '<anonymous closure>': static.
    //     0x1244b3c: add             x1, PP, #0xac, lsl #12  ; [pp+0xacf40] AnonymousClosure: static (0x1244c04), in [package:flutter/src/services/keyboard_key.g.dart] LogicalKeyboardKey::expandSynonyms (0x1244b1c)
    //     0x1244b40: ldr             x1, [x1, #0xf40]
    // 0x1244b44: r2 = Null
    //     0x1244b44: mov             x2, NULL
    // 0x1244b48: r0 = AllocateClosure()
    //     0x1244b48: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1244b4c: r16 = <LogicalKeyboardKey>
    //     0x1244b4c: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8f858] TypeArguments: <LogicalKeyboardKey>
    //     0x1244b50: ldr             x16, [x16, #0x858]
    // 0x1244b54: ldur            lr, [fp, #-8]
    // 0x1244b58: stp             lr, x16, [SP, #8]
    // 0x1244b5c: str             x0, [SP]
    // 0x1244b60: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x1244b60: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x1244b64: r0 = expand()
    //     0x1244b64: bl              #0x1244b84  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::expand
    // 0x1244b68: mov             x1, x0
    // 0x1244b6c: r0 = toSet()
    //     0x1244b6c: bl              #0xba60e0  ; [dart:core] _GrowableList::toSet
    // 0x1244b70: LeaveFrame
    //     0x1244b70: mov             SP, fp
    //     0x1244b74: ldp             fp, lr, [SP], #0x10
    // 0x1244b78: ret
    //     0x1244b78: ret             
    // 0x1244b7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1244b7c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1244b80: b               #0x1244b3c
  }
  [closure] static Set<LogicalKeyboardKey> <anonymous closure>(dynamic, LogicalKeyboardKey) {
    // ** addr: 0x1244c04, size: 0xc8
    // 0x1244c04: EnterFrame
    //     0x1244c04: stp             fp, lr, [SP, #-0x10]!
    //     0x1244c08: mov             fp, SP
    // 0x1244c0c: AllocStack(0x8)
    //     0x1244c0c: sub             SP, SP, #8
    // 0x1244c10: CheckStackOverflow
    //     0x1244c10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1244c14: cmp             SP, x16
    //     0x1244c18: b.ls            #0x1244cc4
    // 0x1244c1c: r0 = LoadStaticField(0x900)
    //     0x1244c1c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x1244c20: ldr             x0, [x0, #0x1200]
    // 0x1244c24: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1244c28: cmp             w0, w16
    // 0x1244c2c: b.ne            #0x1244c3c
    // 0x1244c30: r2 = _reverseSynonyms
    //     0x1244c30: add             x2, PP, #0xac, lsl #12  ; [pp+0xacf48] Field <LogicalKeyboardKey._reverseSynonyms@211043485>: static late final (offset: 0x900)
    //     0x1244c34: ldr             x2, [x2, #0xf48]
    // 0x1244c38: r0 = InitLateFinalStaticField()
    //     0x1244c38: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x1244c3c: mov             x1, x0
    // 0x1244c40: ldr             x2, [fp, #0x10]
    // 0x1244c44: stur            x0, [fp, #-8]
    // 0x1244c48: r0 = _getValueOrData()
    //     0x1244c48: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x1244c4c: mov             x1, x0
    // 0x1244c50: ldur            x0, [fp, #-8]
    // 0x1244c54: LoadField: r2 = r0->field_f
    //     0x1244c54: ldur            w2, [x0, #0xf]
    // 0x1244c58: DecompressPointer r2
    //     0x1244c58: add             x2, x2, HEAP, lsl #32
    // 0x1244c5c: cmp             w2, w1
    // 0x1244c60: b.ne            #0x1244c6c
    // 0x1244c64: r0 = Null
    //     0x1244c64: mov             x0, NULL
    // 0x1244c68: b               #0x1244c70
    // 0x1244c6c: mov             x0, x1
    // 0x1244c70: cmp             w0, NULL
    // 0x1244c74: b.ne            #0x1244cb8
    // 0x1244c78: r1 = <LogicalKeyboardKey>
    //     0x1244c78: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f858] TypeArguments: <LogicalKeyboardKey>
    //     0x1244c7c: ldr             x1, [x1, #0x858]
    // 0x1244c80: r0 = _Set()
    //     0x1244c80: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x1244c84: mov             x3, x0
    // 0x1244c88: r0 = _Uint32List
    //     0x1244c88: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0x1244c8c: stur            x3, [fp, #-8]
    // 0x1244c90: StoreField: r3->field_1b = r0
    //     0x1244c90: stur            w0, [x3, #0x1b]
    // 0x1244c94: StoreField: r3->field_b = rZR
    //     0x1244c94: stur            wzr, [x3, #0xb]
    // 0x1244c98: r0 = const []
    //     0x1244c98: ldr             x0, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0x1244c9c: StoreField: r3->field_f = r0
    //     0x1244c9c: stur            w0, [x3, #0xf]
    // 0x1244ca0: StoreField: r3->field_13 = rZR
    //     0x1244ca0: stur            wzr, [x3, #0x13]
    // 0x1244ca4: ArrayStore: r3[0] = rZR  ; List_4
    //     0x1244ca4: stur            wzr, [x3, #0x17]
    // 0x1244ca8: mov             x1, x3
    // 0x1244cac: ldr             x2, [fp, #0x10]
    // 0x1244cb0: r0 = add()
    //     0x1244cb0: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x1244cb4: ldur            x0, [fp, #-8]
    // 0x1244cb8: LeaveFrame
    //     0x1244cb8: mov             SP, fp
    //     0x1244cbc: ldp             fp, lr, [SP], #0x10
    // 0x1244cc0: ret
    //     0x1244cc0: ret             
    // 0x1244cc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1244cc4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1244cc8: b               #0x1244c1c
  }
  static Map<LogicalKeyboardKey, Set<LogicalKeyboardKey>> _reverseSynonyms() {
    // ** addr: 0x1244ccc, size: 0x25c
    // 0x1244ccc: EnterFrame
    //     0x1244ccc: stp             fp, lr, [SP, #-0x10]!
    //     0x1244cd0: mov             fp, SP
    // 0x1244cd4: AllocStack(0x20)
    //     0x1244cd4: sub             SP, SP, #0x20
    // 0x1244cd8: CheckStackOverflow
    //     0x1244cd8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1244cdc: cmp             SP, x16
    //     0x1244ce0: b.ls            #0x1244f20
    // 0x1244ce4: r1 = Null
    //     0x1244ce4: mov             x1, NULL
    // 0x1244ce8: r2 = 16
    //     0x1244ce8: mov             x2, #0x10
    // 0x1244cec: r0 = AllocateArray()
    //     0x1244cec: bl              #0x13df928  ; AllocateArrayStub
    // 0x1244cf0: stur            x0, [fp, #-8]
    // 0x1244cf4: r16 = Instance_LogicalKeyboardKey
    //     0x1244cf4: add             x16, PP, #0xac, lsl #12  ; [pp+0xacf50] Obj!LogicalKeyboardKey@12abad1
    //     0x1244cf8: ldr             x16, [x16, #0xf50]
    // 0x1244cfc: StoreField: r0->field_f = r16
    //     0x1244cfc: stur            w16, [x0, #0xf]
    // 0x1244d00: r1 = <LogicalKeyboardKey>
    //     0x1244d00: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f858] TypeArguments: <LogicalKeyboardKey>
    //     0x1244d04: ldr             x1, [x1, #0x858]
    // 0x1244d08: r0 = _Set()
    //     0x1244d08: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x1244d0c: mov             x3, x0
    // 0x1244d10: r0 = _Uint32List
    //     0x1244d10: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0x1244d14: stur            x3, [fp, #-0x10]
    // 0x1244d18: StoreField: r3->field_1b = r0
    //     0x1244d18: stur            w0, [x3, #0x1b]
    // 0x1244d1c: StoreField: r3->field_b = rZR
    //     0x1244d1c: stur            wzr, [x3, #0xb]
    // 0x1244d20: r4 = const []
    //     0x1244d20: ldr             x4, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0x1244d24: StoreField: r3->field_f = r4
    //     0x1244d24: stur            w4, [x3, #0xf]
    // 0x1244d28: StoreField: r3->field_13 = rZR
    //     0x1244d28: stur            wzr, [x3, #0x13]
    // 0x1244d2c: ArrayStore: r3[0] = rZR  ; List_4
    //     0x1244d2c: stur            wzr, [x3, #0x17]
    // 0x1244d30: mov             x1, x3
    // 0x1244d34: r2 = Instance_LogicalKeyboardKey
    //     0x1244d34: ldr             x2, [PP, #0x3be8]  ; [pp+0x3be8] Obj!LogicalKeyboardKey@12abb41
    // 0x1244d38: r0 = add()
    //     0x1244d38: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x1244d3c: ldur            x1, [fp, #-0x10]
    // 0x1244d40: r2 = Instance_LogicalKeyboardKey
    //     0x1244d40: ldr             x2, [PP, #0x3bf8]  ; [pp+0x3bf8] Obj!LogicalKeyboardKey@12abb31
    // 0x1244d44: r0 = add()
    //     0x1244d44: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x1244d48: ldur            x1, [fp, #-8]
    // 0x1244d4c: ldur            x0, [fp, #-0x10]
    // 0x1244d50: ArrayStore: r1[1] = r0  ; List_4
    //     0x1244d50: add             x25, x1, #0x13
    //     0x1244d54: str             w0, [x25]
    //     0x1244d58: tbz             w0, #0, #0x1244d74
    //     0x1244d5c: ldurb           w16, [x1, #-1]
    //     0x1244d60: ldurb           w17, [x0, #-1]
    //     0x1244d64: and             x16, x17, x16, lsr #2
    //     0x1244d68: tst             x16, HEAP, lsr #32
    //     0x1244d6c: b.eq            #0x1244d74
    //     0x1244d70: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1244d74: ldur            x0, [fp, #-8]
    // 0x1244d78: r16 = Instance_LogicalKeyboardKey
    //     0x1244d78: add             x16, PP, #0xac, lsl #12  ; [pp+0xacf38] Obj!LogicalKeyboardKey@12abab1
    //     0x1244d7c: ldr             x16, [x16, #0xf38]
    // 0x1244d80: ArrayStore: r0[0] = r16  ; List_4
    //     0x1244d80: stur            w16, [x0, #0x17]
    // 0x1244d84: r1 = <LogicalKeyboardKey>
    //     0x1244d84: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f858] TypeArguments: <LogicalKeyboardKey>
    //     0x1244d88: ldr             x1, [x1, #0x858]
    // 0x1244d8c: r0 = _Set()
    //     0x1244d8c: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x1244d90: mov             x3, x0
    // 0x1244d94: r0 = _Uint32List
    //     0x1244d94: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0x1244d98: stur            x3, [fp, #-0x10]
    // 0x1244d9c: StoreField: r3->field_1b = r0
    //     0x1244d9c: stur            w0, [x3, #0x1b]
    // 0x1244da0: StoreField: r3->field_b = rZR
    //     0x1244da0: stur            wzr, [x3, #0xb]
    // 0x1244da4: r4 = const []
    //     0x1244da4: ldr             x4, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0x1244da8: StoreField: r3->field_f = r4
    //     0x1244da8: stur            w4, [x3, #0xf]
    // 0x1244dac: StoreField: r3->field_13 = rZR
    //     0x1244dac: stur            wzr, [x3, #0x13]
    // 0x1244db0: ArrayStore: r3[0] = rZR  ; List_4
    //     0x1244db0: stur            wzr, [x3, #0x17]
    // 0x1244db4: mov             x1, x3
    // 0x1244db8: r2 = Instance_LogicalKeyboardKey
    //     0x1244db8: ldr             x2, [PP, #0x3c28]  ; [pp+0x3c28] Obj!LogicalKeyboardKey@12abb01
    // 0x1244dbc: r0 = add()
    //     0x1244dbc: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x1244dc0: ldur            x1, [fp, #-0x10]
    // 0x1244dc4: r2 = Instance_LogicalKeyboardKey
    //     0x1244dc4: ldr             x2, [PP, #0x3c38]  ; [pp+0x3c38] Obj!LogicalKeyboardKey@12abaf1
    // 0x1244dc8: r0 = add()
    //     0x1244dc8: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x1244dcc: ldur            x1, [fp, #-8]
    // 0x1244dd0: ldur            x0, [fp, #-0x10]
    // 0x1244dd4: ArrayStore: r1[3] = r0  ; List_4
    //     0x1244dd4: add             x25, x1, #0x1b
    //     0x1244dd8: str             w0, [x25]
    //     0x1244ddc: tbz             w0, #0, #0x1244df8
    //     0x1244de0: ldurb           w16, [x1, #-1]
    //     0x1244de4: ldurb           w17, [x0, #-1]
    //     0x1244de8: and             x16, x17, x16, lsr #2
    //     0x1244dec: tst             x16, HEAP, lsr #32
    //     0x1244df0: b.eq            #0x1244df8
    //     0x1244df4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1244df8: ldur            x0, [fp, #-8]
    // 0x1244dfc: r16 = Instance_LogicalKeyboardKey
    //     0x1244dfc: add             x16, PP, #0xac, lsl #12  ; [pp+0xacf58] Obj!LogicalKeyboardKey@12abac1
    //     0x1244e00: ldr             x16, [x16, #0xf58]
    // 0x1244e04: StoreField: r0->field_1f = r16
    //     0x1244e04: stur            w16, [x0, #0x1f]
    // 0x1244e08: r1 = <LogicalKeyboardKey>
    //     0x1244e08: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f858] TypeArguments: <LogicalKeyboardKey>
    //     0x1244e0c: ldr             x1, [x1, #0x858]
    // 0x1244e10: r0 = _Set()
    //     0x1244e10: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x1244e14: mov             x3, x0
    // 0x1244e18: r0 = _Uint32List
    //     0x1244e18: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0x1244e1c: stur            x3, [fp, #-0x10]
    // 0x1244e20: StoreField: r3->field_1b = r0
    //     0x1244e20: stur            w0, [x3, #0x1b]
    // 0x1244e24: StoreField: r3->field_b = rZR
    //     0x1244e24: stur            wzr, [x3, #0xb]
    // 0x1244e28: r4 = const []
    //     0x1244e28: ldr             x4, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0x1244e2c: StoreField: r3->field_f = r4
    //     0x1244e2c: stur            w4, [x3, #0xf]
    // 0x1244e30: StoreField: r3->field_13 = rZR
    //     0x1244e30: stur            wzr, [x3, #0x13]
    // 0x1244e34: ArrayStore: r3[0] = rZR  ; List_4
    //     0x1244e34: stur            wzr, [x3, #0x17]
    // 0x1244e38: mov             x1, x3
    // 0x1244e3c: r2 = Instance_LogicalKeyboardKey
    //     0x1244e3c: ldr             x2, [PP, #0x3bd0]  ; [pp+0x3bd0] Obj!LogicalKeyboardKey@12abb21
    // 0x1244e40: r0 = add()
    //     0x1244e40: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x1244e44: ldur            x1, [fp, #-0x10]
    // 0x1244e48: r2 = Instance_LogicalKeyboardKey
    //     0x1244e48: ldr             x2, [PP, #0x3bd8]  ; [pp+0x3bd8] Obj!LogicalKeyboardKey@12abb11
    // 0x1244e4c: r0 = add()
    //     0x1244e4c: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x1244e50: ldur            x1, [fp, #-8]
    // 0x1244e54: ldur            x0, [fp, #-0x10]
    // 0x1244e58: ArrayStore: r1[5] = r0  ; List_4
    //     0x1244e58: add             x25, x1, #0x23
    //     0x1244e5c: str             w0, [x25]
    //     0x1244e60: tbz             w0, #0, #0x1244e7c
    //     0x1244e64: ldurb           w16, [x1, #-1]
    //     0x1244e68: ldurb           w17, [x0, #-1]
    //     0x1244e6c: and             x16, x17, x16, lsr #2
    //     0x1244e70: tst             x16, HEAP, lsr #32
    //     0x1244e74: b.eq            #0x1244e7c
    //     0x1244e78: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1244e7c: ldur            x0, [fp, #-8]
    // 0x1244e80: r16 = Instance_LogicalKeyboardKey
    //     0x1244e80: add             x16, PP, #0xac, lsl #12  ; [pp+0xacf60] Obj!LogicalKeyboardKey@12abae1
    //     0x1244e84: ldr             x16, [x16, #0xf60]
    // 0x1244e88: StoreField: r0->field_27 = r16
    //     0x1244e88: stur            w16, [x0, #0x27]
    // 0x1244e8c: r1 = <LogicalKeyboardKey>
    //     0x1244e8c: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f858] TypeArguments: <LogicalKeyboardKey>
    //     0x1244e90: ldr             x1, [x1, #0x858]
    // 0x1244e94: r0 = _Set()
    //     0x1244e94: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x1244e98: mov             x3, x0
    // 0x1244e9c: r0 = _Uint32List
    //     0x1244e9c: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0x1244ea0: stur            x3, [fp, #-0x10]
    // 0x1244ea4: StoreField: r3->field_1b = r0
    //     0x1244ea4: stur            w0, [x3, #0x1b]
    // 0x1244ea8: StoreField: r3->field_b = rZR
    //     0x1244ea8: stur            wzr, [x3, #0xb]
    // 0x1244eac: r0 = const []
    //     0x1244eac: ldr             x0, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0x1244eb0: StoreField: r3->field_f = r0
    //     0x1244eb0: stur            w0, [x3, #0xf]
    // 0x1244eb4: StoreField: r3->field_13 = rZR
    //     0x1244eb4: stur            wzr, [x3, #0x13]
    // 0x1244eb8: ArrayStore: r3[0] = rZR  ; List_4
    //     0x1244eb8: stur            wzr, [x3, #0x17]
    // 0x1244ebc: mov             x1, x3
    // 0x1244ec0: r2 = Instance_LogicalKeyboardKey
    //     0x1244ec0: ldr             x2, [PP, #0x3c08]  ; [pp+0x3c08] Obj!LogicalKeyboardKey@12abb61
    // 0x1244ec4: r0 = add()
    //     0x1244ec4: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x1244ec8: ldur            x1, [fp, #-0x10]
    // 0x1244ecc: r2 = Instance_LogicalKeyboardKey
    //     0x1244ecc: ldr             x2, [PP, #0x3c18]  ; [pp+0x3c18] Obj!LogicalKeyboardKey@12abb51
    // 0x1244ed0: r0 = add()
    //     0x1244ed0: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x1244ed4: ldur            x1, [fp, #-8]
    // 0x1244ed8: ldur            x0, [fp, #-0x10]
    // 0x1244edc: ArrayStore: r1[7] = r0  ; List_4
    //     0x1244edc: add             x25, x1, #0x2b
    //     0x1244ee0: str             w0, [x25]
    //     0x1244ee4: tbz             w0, #0, #0x1244f00
    //     0x1244ee8: ldurb           w16, [x1, #-1]
    //     0x1244eec: ldurb           w17, [x0, #-1]
    //     0x1244ef0: and             x16, x17, x16, lsr #2
    //     0x1244ef4: tst             x16, HEAP, lsr #32
    //     0x1244ef8: b.eq            #0x1244f00
    //     0x1244efc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1244f00: r16 = <LogicalKeyboardKey, Set<LogicalKeyboardKey>>
    //     0x1244f00: add             x16, PP, #0xac, lsl #12  ; [pp+0xacf68] TypeArguments: <LogicalKeyboardKey, Set<LogicalKeyboardKey>>
    //     0x1244f04: ldr             x16, [x16, #0xf68]
    // 0x1244f08: ldur            lr, [fp, #-8]
    // 0x1244f0c: stp             lr, x16, [SP]
    // 0x1244f10: r0 = Map._fromLiteral()
    //     0x1244f10: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x1244f14: LeaveFrame
    //     0x1244f14: mov             SP, fp
    //     0x1244f18: ldp             fp, lr, [SP], #0x10
    // 0x1244f1c: ret
    //     0x1244f1c: ret             
    // 0x1244f20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1244f20: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1244f24: b               #0x1244ce4
  }
  _ ==(/* No info */) {
    // ** addr: 0x1279914, size: 0xec
    // 0x1279914: EnterFrame
    //     0x1279914: stp             fp, lr, [SP, #-0x10]!
    //     0x1279918: mov             fp, SP
    // 0x127991c: AllocStack(0x10)
    //     0x127991c: sub             SP, SP, #0x10
    // 0x1279920: CheckStackOverflow
    //     0x1279920: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1279924: cmp             SP, x16
    //     0x1279928: b.ls            #0x12799f8
    // 0x127992c: ldr             x0, [fp, #0x10]
    // 0x1279930: cmp             w0, NULL
    // 0x1279934: b.ne            #0x1279948
    // 0x1279938: r0 = false
    //     0x1279938: add             x0, NULL, #0x30  ; false
    // 0x127993c: LeaveFrame
    //     0x127993c: mov             SP, fp
    //     0x1279940: ldp             fp, lr, [SP], #0x10
    // 0x1279944: ret
    //     0x1279944: ret             
    // 0x1279948: ldr             x1, [fp, #0x18]
    // 0x127994c: cmp             w1, w0
    // 0x1279950: b.ne            #0x1279964
    // 0x1279954: r0 = true
    //     0x1279954: add             x0, NULL, #0x20  ; true
    // 0x1279958: LeaveFrame
    //     0x1279958: mov             SP, fp
    //     0x127995c: ldp             fp, lr, [SP], #0x10
    // 0x1279960: ret
    //     0x1279960: ret             
    // 0x1279964: str             x0, [SP]
    // 0x1279968: r0 = runtimeType()
    //     0x1279968: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x127996c: r1 = LoadClassIdInstr(r0)
    //     0x127996c: ldur            x1, [x0, #-1]
    //     0x1279970: ubfx            x1, x1, #0xc, #0x14
    // 0x1279974: r16 = LogicalKeyboardKey
    //     0x1279974: add             x16, PP, #0xd, lsl #12  ; [pp+0xdd00] Type: LogicalKeyboardKey
    //     0x1279978: ldr             x16, [x16, #0xd00]
    // 0x127997c: stp             x16, x0, [SP]
    // 0x1279980: mov             x0, x1
    // 0x1279984: mov             lr, x0
    // 0x1279988: ldr             lr, [x21, lr, lsl #3]
    // 0x127998c: blr             lr
    // 0x1279990: tbz             w0, #4, #0x12799a4
    // 0x1279994: r0 = false
    //     0x1279994: add             x0, NULL, #0x30  ; false
    // 0x1279998: LeaveFrame
    //     0x1279998: mov             SP, fp
    //     0x127999c: ldp             fp, lr, [SP], #0x10
    // 0x12799a0: ret
    //     0x12799a0: ret             
    // 0x12799a4: ldr             x1, [fp, #0x10]
    // 0x12799a8: r2 = 60
    //     0x12799a8: mov             x2, #0x3c
    // 0x12799ac: branchIfSmi(r1, 0x12799b8)
    //     0x12799ac: tbz             w1, #0, #0x12799b8
    // 0x12799b0: r2 = LoadClassIdInstr(r1)
    //     0x12799b0: ldur            x2, [x1, #-1]
    //     0x12799b4: ubfx            x2, x2, #0xc, #0x14
    // 0x12799b8: r17 = 5028
    //     0x12799b8: mov             x17, #0x13a4
    // 0x12799bc: cmp             x2, x17
    // 0x12799c0: b.ne            #0x12799e8
    // 0x12799c4: ldr             x2, [fp, #0x18]
    // 0x12799c8: LoadField: r3 = r1->field_7
    //     0x12799c8: ldur            x3, [x1, #7]
    // 0x12799cc: LoadField: r1 = r2->field_7
    //     0x12799cc: ldur            x1, [x2, #7]
    // 0x12799d0: cmp             x3, x1
    // 0x12799d4: r16 = true
    //     0x12799d4: add             x16, NULL, #0x20  ; true
    // 0x12799d8: r17 = false
    //     0x12799d8: add             x17, NULL, #0x30  ; false
    // 0x12799dc: csel            x2, x16, x17, eq
    // 0x12799e0: mov             x0, x2
    // 0x12799e4: b               #0x12799ec
    // 0x12799e8: r0 = false
    //     0x12799e8: add             x0, NULL, #0x30  ; false
    // 0x12799ec: LeaveFrame
    //     0x12799ec: mov             SP, fp
    //     0x12799f0: ldp             fp, lr, [SP], #0x10
    // 0x12799f4: ret
    //     0x12799f4: ret             
    // 0x12799f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12799f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12799fc: b               #0x127992c
  }
}
