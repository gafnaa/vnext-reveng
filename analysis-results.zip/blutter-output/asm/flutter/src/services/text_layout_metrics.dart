// lib: , url: package:flutter/src/services/text_layout_metrics.dart

// class id: 1049105, size: 0x8
class :: {
}

// class id: 2876, size: 0x8, field offset: 0x8
abstract class TextLayoutMetrics extends Object {

  static bool isWhitespace(int) {
    // ** addr: 0xb983a4, size: 0x104
    // 0xb983a4: cmp             x1, #2, lsl #12
    // 0xb983a8: b.gt            #0xb98438
    // 0xb983ac: cmp             x1, #0x1d
    // 0xb983b0: b.gt            #0xb983f8
    // 0xb983b4: cmp             x1, #0xc
    // 0xb983b8: b.gt            #0xb983dc
    // 0xb983bc: cmp             x1, #0xa
    // 0xb983c0: b.gt            #0xb98498
    // 0xb983c4: cmp             x1, #9
    // 0xb983c8: b.gt            #0xb98498
    // 0xb983cc: lsl             x2, x1, #1
    // 0xb983d0: cmp             w2, #0x12
    // 0xb983d4: b.ne            #0xb984a0
    // 0xb983d8: b               #0xb98498
    // 0xb983dc: cmp             x1, #0x1c
    // 0xb983e0: b.gt            #0xb98498
    // 0xb983e4: cmp             x1, #0xd
    // 0xb983e8: b.le            #0xb98498
    // 0xb983ec: cmp             x1, #0x1c
    // 0xb983f0: b.lt            #0xb984a0
    // 0xb983f4: b               #0xb98498
    // 0xb983f8: cmp             x1, #0x20
    // 0xb983fc: b.le            #0xb98498
    // 0xb98400: cmp             x1, #0xa0
    // 0xb98404: b.lt            #0xb984a0
    // 0xb98408: r17 = 5760
    //     0xb98408: mov             x17, #0x1680
    // 0xb9840c: cmp             x1, x17
    // 0xb98410: b.gt            #0xb9842c
    // 0xb98414: cmp             x1, #0xa0
    // 0xb98418: b.le            #0xb98498
    // 0xb9841c: r17 = 5760
    //     0xb9841c: mov             x17, #0x1680
    // 0xb98420: cmp             x1, x17
    // 0xb98424: b.lt            #0xb984a0
    // 0xb98428: b               #0xb98498
    // 0xb9842c: cmp             x1, #2, lsl #12
    // 0xb98430: b.lt            #0xb984a0
    // 0xb98434: b               #0xb98498
    // 0xb98438: r17 = 8199
    //     0xb98438: mov             x17, #0x2007
    // 0xb9843c: cmp             x1, x17
    // 0xb98440: b.le            #0xb98498
    // 0xb98444: r17 = 8202
    //     0xb98444: mov             x17, #0x200a
    // 0xb98448: cmp             x1, x17
    // 0xb9844c: b.le            #0xb98498
    // 0xb98450: r17 = 8239
    //     0xb98450: mov             x17, #0x202f
    // 0xb98454: cmp             x1, x17
    // 0xb98458: b.lt            #0xb984a0
    // 0xb9845c: r17 = 8287
    //     0xb9845c: mov             x17, #0x205f
    // 0xb98460: cmp             x1, x17
    // 0xb98464: b.gt            #0xb98484
    // 0xb98468: r17 = 8239
    //     0xb98468: mov             x17, #0x202f
    // 0xb9846c: cmp             x1, x17
    // 0xb98470: b.le            #0xb98498
    // 0xb98474: r17 = 8287
    //     0xb98474: mov             x17, #0x205f
    // 0xb98478: cmp             x1, x17
    // 0xb9847c: b.lt            #0xb984a0
    // 0xb98480: b               #0xb98498
    // 0xb98484: cmp             x1, #3, lsl #12
    // 0xb98488: b.lt            #0xb984a0
    // 0xb9848c: lsl             x2, x1, #1
    // 0xb98490: cmp             w2, #6, lsl #12
    // 0xb98494: b.ne            #0xb984a0
    // 0xb98498: r0 = true
    //     0xb98498: add             x0, NULL, #0x20  ; true
    // 0xb9849c: ret
    //     0xb9849c: ret             
    // 0xb984a0: r0 = false
    //     0xb984a0: add             x0, NULL, #0x30  ; false
    // 0xb984a4: ret
    //     0xb984a4: ret             
  }
}
