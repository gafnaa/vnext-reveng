// lib: , url: package:flutter/src/services/system_chrome.dart

// class id: 1049097, size: 0x8
class :: {

  static _ _stringify(/* No info */) {
    // ** addr: 0xeb7154, size: 0x194
    // 0xeb7154: EnterFrame
    //     0xeb7154: stp             fp, lr, [SP, #-0x10]!
    //     0xeb7158: mov             fp, SP
    // 0xeb715c: AllocStack(0x28)
    //     0xeb715c: sub             SP, SP, #0x28
    // 0xeb7160: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */)
    //     0xeb7160: mov             x0, x1
    //     0xeb7164: stur            x1, [fp, #-8]
    // 0xeb7168: CheckStackOverflow
    //     0xeb7168: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeb716c: cmp             SP, x16
    //     0xeb7170: b.ls            #0xeb72d8
    // 0xeb7174: r1 = <String>
    //     0xeb7174: ldr             x1, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    // 0xeb7178: r2 = 0
    //     0xeb7178: mov             x2, #0
    // 0xeb717c: r0 = _GrowableList()
    //     0xeb717c: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xeb7180: mov             x2, x0
    // 0xeb7184: ldur            x1, [fp, #-8]
    // 0xeb7188: stur            x2, [fp, #-0x10]
    // 0xeb718c: r0 = LoadClassIdInstr(r1)
    //     0xeb718c: ldur            x0, [x1, #-1]
    //     0xeb7190: ubfx            x0, x0, #0xc, #0x14
    // 0xeb7194: r0 = GDT[cid_x0 + 0x12641]()
    //     0xeb7194: mov             x17, #0x2641
    //     0xeb7198: movk            x17, #1, lsl #16
    //     0xeb719c: add             lr, x0, x17
    //     0xeb71a0: ldr             lr, [x21, lr, lsl #3]
    //     0xeb71a4: blr             lr
    // 0xeb71a8: mov             x2, x0
    // 0xeb71ac: stur            x2, [fp, #-8]
    // 0xeb71b0: ldur            x3, [fp, #-0x10]
    // 0xeb71b4: CheckStackOverflow
    //     0xeb71b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeb71b8: cmp             SP, x16
    //     0xeb71bc: b.ls            #0xeb72e0
    // 0xeb71c0: r0 = LoadClassIdInstr(r2)
    //     0xeb71c0: ldur            x0, [x2, #-1]
    //     0xeb71c4: ubfx            x0, x0, #0xc, #0x14
    // 0xeb71c8: mov             x1, x2
    // 0xeb71cc: r0 = GDT[cid_x0 + 0x1845b]()
    //     0xeb71cc: mov             x17, #0x845b
    //     0xeb71d0: movk            x17, #1, lsl #16
    //     0xeb71d4: add             lr, x0, x17
    //     0xeb71d8: ldr             lr, [x21, lr, lsl #3]
    //     0xeb71dc: blr             lr
    // 0xeb71e0: tbnz            w0, #4, #0xeb72c4
    // 0xeb71e4: ldur            x3, [fp, #-0x10]
    // 0xeb71e8: ldur            x2, [fp, #-8]
    // 0xeb71ec: r0 = LoadClassIdInstr(r2)
    //     0xeb71ec: ldur            x0, [x2, #-1]
    //     0xeb71f0: ubfx            x0, x0, #0xc, #0x14
    // 0xeb71f4: mov             x1, x2
    // 0xeb71f8: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0xeb71f8: mov             x17, #0x7d4c
    //     0xeb71fc: movk            x17, #1, lsl #16
    //     0xeb7200: add             lr, x0, x17
    //     0xeb7204: ldr             lr, [x21, lr, lsl #3]
    //     0xeb7208: blr             lr
    // 0xeb720c: r1 = 60
    //     0xeb720c: mov             x1, #0x3c
    // 0xeb7210: branchIfSmi(r0, 0xeb721c)
    //     0xeb7210: tbz             w0, #0, #0xeb721c
    // 0xeb7214: r1 = LoadClassIdInstr(r0)
    //     0xeb7214: ldur            x1, [x0, #-1]
    //     0xeb7218: ubfx            x1, x1, #0xc, #0x14
    // 0xeb721c: str             x0, [SP]
    // 0xeb7220: mov             x0, x1
    // 0xeb7224: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xeb7224: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xeb7228: r0 = GDT[cid_x0 + 0x91c1]()
    //     0xeb7228: mov             x17, #0x91c1
    //     0xeb722c: add             lr, x0, x17
    //     0xeb7230: ldr             lr, [x21, lr, lsl #3]
    //     0xeb7234: blr             lr
    // 0xeb7238: mov             x2, x0
    // 0xeb723c: ldur            x0, [fp, #-0x10]
    // 0xeb7240: stur            x2, [fp, #-0x20]
    // 0xeb7244: LoadField: r1 = r0->field_b
    //     0xeb7244: ldur            w1, [x0, #0xb]
    // 0xeb7248: LoadField: r3 = r0->field_f
    //     0xeb7248: ldur            w3, [x0, #0xf]
    // 0xeb724c: DecompressPointer r3
    //     0xeb724c: add             x3, x3, HEAP, lsl #32
    // 0xeb7250: LoadField: r4 = r3->field_b
    //     0xeb7250: ldur            w4, [x3, #0xb]
    // 0xeb7254: r3 = LoadInt32Instr(r1)
    //     0xeb7254: sbfx            x3, x1, #1, #0x1f
    // 0xeb7258: stur            x3, [fp, #-0x18]
    // 0xeb725c: r1 = LoadInt32Instr(r4)
    //     0xeb725c: sbfx            x1, x4, #1, #0x1f
    // 0xeb7260: cmp             x3, x1
    // 0xeb7264: b.ne            #0xeb7270
    // 0xeb7268: mov             x1, x0
    // 0xeb726c: r0 = _growToNextCapacity()
    //     0xeb726c: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xeb7270: ldur            x2, [fp, #-0x10]
    // 0xeb7274: ldur            x3, [fp, #-0x18]
    // 0xeb7278: add             x4, x3, #1
    // 0xeb727c: lsl             x5, x4, #1
    // 0xeb7280: StoreField: r2->field_b = r5
    //     0xeb7280: stur            w5, [x2, #0xb]
    // 0xeb7284: LoadField: r1 = r2->field_f
    //     0xeb7284: ldur            w1, [x2, #0xf]
    // 0xeb7288: DecompressPointer r1
    //     0xeb7288: add             x1, x1, HEAP, lsl #32
    // 0xeb728c: ldur            x0, [fp, #-0x20]
    // 0xeb7290: ArrayStore: r1[r3] = r0  ; List_4
    //     0xeb7290: add             x25, x1, x3, lsl #2
    //     0xeb7294: add             x25, x25, #0xf
    //     0xeb7298: str             w0, [x25]
    //     0xeb729c: tbz             w0, #0, #0xeb72b8
    //     0xeb72a0: ldurb           w16, [x1, #-1]
    //     0xeb72a4: ldurb           w17, [x0, #-1]
    //     0xeb72a8: and             x16, x17, x16, lsr #2
    //     0xeb72ac: tst             x16, HEAP, lsr #32
    //     0xeb72b0: b.eq            #0xeb72b8
    //     0xeb72b4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xeb72b8: mov             x3, x2
    // 0xeb72bc: ldur            x2, [fp, #-8]
    // 0xeb72c0: b               #0xeb71b4
    // 0xeb72c4: ldur            x2, [fp, #-0x10]
    // 0xeb72c8: mov             x0, x2
    // 0xeb72cc: LeaveFrame
    //     0xeb72cc: mov             SP, fp
    //     0xeb72d0: ldp             fp, lr, [SP], #0x10
    // 0xeb72d4: ret
    //     0xeb72d4: ret             
    // 0xeb72d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeb72d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeb72dc: b               #0xeb7174
    // 0xeb72e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeb72e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeb72e4: b               #0xeb71c0
  }
}

// class id: 2742, size: 0x8, field offset: 0x8
abstract class SystemChrome extends Object {

  [closure] static void <anonymous closure>(dynamic) {
    // ** addr: 0x8464a8, size: 0x14
    // 0x8464a8: r2 = Null
    //     0x8464a8: mov             x2, NULL
    // 0x8464ac: StoreStaticField(0x830, r2)
    //     0x8464ac: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x8464b0: str             x2, [x1, #0x1060]
    // 0x8464b4: r0 = Null
    //     0x8464b4: mov             x0, NULL
    // 0x8464b8: ret
    //     0x8464b8: ret             
  }
  static _ setSystemUIOverlayStyle(/* No info */) {
    // ** addr: 0x8991e4, size: 0xa4
    // 0x8991e4: EnterFrame
    //     0x8991e4: stp             fp, lr, [SP, #-0x10]!
    //     0x8991e8: mov             fp, SP
    // 0x8991ec: AllocStack(0x18)
    //     0x8991ec: sub             SP, SP, #0x18
    // 0x8991f0: SetupParameters(dynamic _ /* r1 => r2, fp-0x8 */)
    //     0x8991f0: mov             x2, x1
    //     0x8991f4: stur            x1, [fp, #-8]
    // 0x8991f8: CheckStackOverflow
    //     0x8991f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8991fc: cmp             SP, x16
    //     0x899200: b.ls            #0x899280
    // 0x899204: r0 = LoadStaticField(0x82c)
    //     0x899204: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x899208: ldr             x0, [x0, #0x1058]
    // 0x89920c: cmp             w0, NULL
    // 0x899210: b.eq            #0x89922c
    // 0x899214: StoreStaticField(0x82c, r2)
    //     0x899214: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x899218: str             x2, [x0, #0x1058]
    // 0x89921c: r0 = Null
    //     0x89921c: mov             x0, NULL
    // 0x899220: LeaveFrame
    //     0x899220: mov             SP, fp
    //     0x899224: ldp             fp, lr, [SP], #0x10
    // 0x899228: ret
    //     0x899228: ret             
    // 0x89922c: r0 = LoadStaticField(0x830)
    //     0x89922c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x899230: ldr             x0, [x0, #0x1060]
    // 0x899234: stp             x0, x2, [SP]
    // 0x899238: r0 = ==()
    //     0x899238: bl              #0x127a3f8  ; [package:flutter/src/services/system_chrome.dart] SystemUiOverlayStyle::==
    // 0x89923c: tbnz            w0, #4, #0x899250
    // 0x899240: r0 = Null
    //     0x899240: mov             x0, NULL
    // 0x899244: LeaveFrame
    //     0x899244: mov             SP, fp
    //     0x899248: ldp             fp, lr, [SP], #0x10
    // 0x89924c: ret
    //     0x89924c: ret             
    // 0x899250: ldur            x2, [fp, #-8]
    // 0x899254: StoreStaticField(0x82c, r2)
    //     0x899254: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x899258: str             x2, [x0, #0x1058]
    // 0x89925c: r1 = Function '<anonymous closure>': static.
    //     0x89925c: ldr             x1, [PP, #0x2c10]  ; [pp+0x2c10] AnonymousClosure: static (0x899288), in [package:flutter/src/services/system_chrome.dart] SystemChrome::setSystemUIOverlayStyle (0x8991e4)
    // 0x899260: r2 = Null
    //     0x899260: mov             x2, NULL
    // 0x899264: r0 = AllocateClosure()
    //     0x899264: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x899268: str             x0, [SP]
    // 0x89926c: r0 = scheduleMicrotask()
    //     0x89926c: bl              #0x7e0298  ; [dart:async] ::scheduleMicrotask
    // 0x899270: r0 = Null
    //     0x899270: mov             x0, NULL
    // 0x899274: LeaveFrame
    //     0x899274: mov             SP, fp
    //     0x899278: ldp             fp, lr, [SP], #0x10
    // 0x89927c: ret
    //     0x89927c: ret             
    // 0x899280: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x899280: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x899284: b               #0x899204
  }
  [closure] static void <anonymous closure>(dynamic) {
    // ** addr: 0x899288, size: 0xec
    // 0x899288: EnterFrame
    //     0x899288: stp             fp, lr, [SP, #-0x10]!
    //     0x89928c: mov             fp, SP
    // 0x899290: AllocStack(0x30)
    //     0x899290: sub             SP, SP, #0x30
    // 0x899294: CheckStackOverflow
    //     0x899294: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x899298: cmp             SP, x16
    //     0x89929c: b.ls            #0x899368
    // 0x8992a0: r0 = LoadStaticField(0x82c)
    //     0x8992a0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8992a4: ldr             x0, [x0, #0x1058]
    // 0x8992a8: r1 = LoadStaticField(0x830)
    //     0x8992a8: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x8992ac: ldr             x1, [x1, #0x1060]
    // 0x8992b0: r2 = LoadClassIdInstr(r0)
    //     0x8992b0: ldur            x2, [x0, #-1]
    //     0x8992b4: ubfx            x2, x2, #0xc, #0x14
    // 0x8992b8: stp             x1, x0, [SP]
    // 0x8992bc: mov             x0, x2
    // 0x8992c0: mov             lr, x0
    // 0x8992c4: ldr             lr, [x21, lr, lsl #3]
    // 0x8992c8: blr             lr
    // 0x8992cc: tbz             w0, #4, #0x89934c
    // 0x8992d0: r1 = LoadStaticField(0x82c)
    //     0x8992d0: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x8992d4: ldr             x1, [x1, #0x1058]
    // 0x8992d8: cmp             w1, NULL
    // 0x8992dc: b.eq            #0x899370
    // 0x8992e0: r0 = _toMap()
    //     0x8992e0: bl              #0x899374  ; [package:flutter/src/services/system_chrome.dart] SystemUiOverlayStyle::_toMap
    // 0x8992e4: r16 = <void?>
    //     0x8992e4: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x8992e8: r30 = Instance_OptionalMethodChannel
    //     0x8992e8: ldr             lr, [PP, #0x1960]  ; [pp+0x1960] Obj!OptionalMethodChannel@129bec1
    // 0x8992ec: stp             lr, x16, [SP, #0x10]
    // 0x8992f0: r16 = "SystemChrome.setSystemUIOverlayStyle"
    //     0x8992f0: ldr             x16, [PP, #0x2c18]  ; [pp+0x2c18] "SystemChrome.setSystemUIOverlayStyle"
    // 0x8992f4: stp             x0, x16, [SP]
    // 0x8992f8: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x8992f8: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x8992fc: r0 = invokeMethod()
    //     0x8992fc: bl              #0x130ad0c  ; [package:flutter/src/services/platform_channel.dart] OptionalMethodChannel::invokeMethod
    // 0x899300: r1 = Function '<anonymous closure>': static.
    //     0x899300: ldr             x1, [PP, #0x2c20]  ; [pp+0x2c20] Function: [dart:ui] Shader::Shader._ (0x13cf838)
    // 0x899304: r2 = Null
    //     0x899304: mov             x2, NULL
    // 0x899308: stur            x0, [fp, #-8]
    // 0x89930c: r0 = AllocateClosure()
    //     0x89930c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x899310: r1 = Function '<anonymous closure>': static.
    //     0x899310: ldr             x1, [PP, #0x2c28]  ; [pp+0x2c28] AnonymousClosure: static (0x8996d4), in [package:flutter/src/services/system_chrome.dart] SystemChrome::setSystemUIOverlayStyle (0x8991e4)
    // 0x899314: r2 = Null
    //     0x899314: mov             x2, NULL
    // 0x899318: stur            x0, [fp, #-0x10]
    // 0x89931c: r0 = AllocateClosure()
    //     0x89931c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x899320: r16 = <Null?>
    //     0x899320: ldr             x16, [PP, #0x70]  ; [pp+0x70] TypeArguments: <Null?>
    // 0x899324: ldur            lr, [fp, #-8]
    // 0x899328: stp             lr, x16, [SP, #0x10]
    // 0x89932c: ldur            x16, [fp, #-0x10]
    // 0x899330: stp             x0, x16, [SP]
    // 0x899334: r4 = const [0x1, 0x3, 0x3, 0x2, onError, 0x2, null]
    //     0x899334: ldr             x4, [PP, #0x538]  ; [pp+0x538] List(7) [0x1, 0x3, 0x3, 0x2, "onError", 0x2, Null]
    // 0x899338: r0 = then()
    //     0x899338: bl              #0x1293070  ; [dart:async] _Future::then
    // 0x89933c: r2 = LoadStaticField(0x82c)
    //     0x89933c: ldr             x2, [THR, #0x78]  ; THR::field_table_values
    //     0x899340: ldr             x2, [x2, #0x1058]
    // 0x899344: StoreStaticField(0x830, r2)
    //     0x899344: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x899348: str             x2, [x1, #0x1060]
    // 0x89934c: r2 = Null
    //     0x89934c: mov             x2, NULL
    // 0x899350: StoreStaticField(0x82c, r2)
    //     0x899350: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x899354: str             x2, [x1, #0x1058]
    // 0x899358: r0 = Null
    //     0x899358: mov             x0, NULL
    // 0x89935c: LeaveFrame
    //     0x89935c: mov             SP, fp
    //     0x899360: ldp             fp, lr, [SP], #0x10
    // 0x899364: ret
    //     0x899364: ret             
    // 0x899368: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x899368: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89936c: b               #0x8992a0
    // 0x899370: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x899370: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] static Null <anonymous closure>(dynamic, Object, StackTrace) {
    // ** addr: 0x8996d4, size: 0x80
    // 0x8996d4: EnterFrame
    //     0x8996d4: stp             fp, lr, [SP, #-0x10]!
    //     0x8996d8: mov             fp, SP
    // 0x8996dc: AllocStack(0x8)
    //     0x8996dc: sub             SP, SP, #8
    // 0x8996e0: CheckStackOverflow
    //     0x8996e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8996e4: cmp             SP, x16
    //     0x8996e8: b.ls            #0x89974c
    // 0x8996ec: r1 = <List<Object>>
    //     0x8996ec: ldr             x1, [PP, #0x860]  ; [pp+0x860] TypeArguments: <List<Object>>
    // 0x8996f0: r0 = ErrorDescription()
    //     0x8996f0: bl              #0x829ca4  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x2c)
    // 0x8996f4: mov             x1, x0
    // 0x8996f8: r2 = "while setting the system UI overlay style"
    //     0x8996f8: ldr             x2, [PP, #0x2c30]  ; [pp+0x2c30] "while setting the system UI overlay style"
    // 0x8996fc: r3 = Instance_DiagnosticLevel
    //     0x8996fc: ldr             x3, [PP, #0x868]  ; [pp+0x868] Obj!DiagnosticLevel@12c5f41
    // 0x899700: stur            x0, [fp, #-8]
    // 0x899704: r0 = _ErrorDiagnostic()
    //     0x899704: bl              #0x829bec  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0x899708: r0 = FlutterErrorDetails()
    //     0x899708: bl              #0x829be0  ; AllocateFlutterErrorDetailsStub -> FlutterErrorDetails (size=0x20)
    // 0x89970c: mov             x1, x0
    // 0x899710: ldr             x0, [fp, #0x18]
    // 0x899714: StoreField: r1->field_7 = r0
    //     0x899714: stur            w0, [x1, #7]
    // 0x899718: ldr             x0, [fp, #0x10]
    // 0x89971c: StoreField: r1->field_b = r0
    //     0x89971c: stur            w0, [x1, #0xb]
    // 0x899720: r0 = "services library"
    //     0x899720: ldr             x0, [PP, #0x870]  ; [pp+0x870] "services library"
    // 0x899724: StoreField: r1->field_f = r0
    //     0x899724: stur            w0, [x1, #0xf]
    // 0x899728: ldur            x0, [fp, #-8]
    // 0x89972c: StoreField: r1->field_13 = r0
    //     0x89972c: stur            w0, [x1, #0x13]
    // 0x899730: r0 = false
    //     0x899730: add             x0, NULL, #0x30  ; false
    // 0x899734: StoreField: r1->field_1b = r0
    //     0x899734: stur            w0, [x1, #0x1b]
    // 0x899738: r0 = reportError()
    //     0x899738: bl              #0x829a24  ; [package:flutter/src/foundation/assertions.dart] FlutterError::reportError
    // 0x89973c: r0 = Null
    //     0x89973c: mov             x0, NULL
    // 0x899740: LeaveFrame
    //     0x899740: mov             SP, fp
    //     0x899744: ldp             fp, lr, [SP], #0x10
    // 0x899748: ret
    //     0x899748: ret             
    // 0x89974c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89974c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x899750: b               #0x8996ec
  }
  static _ setPreferredOrientations(/* No info */) async {
    // ** addr: 0xeb70e8, size: 0x6c
    // 0xeb70e8: EnterFrame
    //     0xeb70e8: stp             fp, lr, [SP, #-0x10]!
    //     0xeb70ec: mov             fp, SP
    // 0xeb70f0: AllocStack(0x30)
    //     0xeb70f0: sub             SP, SP, #0x30
    // 0xeb70f4: SetupParameters(dynamic _ /* r1 => r1, fp-0x10 */)
    //     0xeb70f4: stur            NULL, [fp, #-8]
    //     0xeb70f8: stur            x1, [fp, #-0x10]
    // 0xeb70fc: CheckStackOverflow
    //     0xeb70fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeb7100: cmp             SP, x16
    //     0xeb7104: b.ls            #0xeb714c
    // 0xeb7108: InitAsync() -> Future<void?>
    //     0xeb7108: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0xeb710c: bl              #0x7f5e44  ; InitAsyncStub
    // 0xeb7110: ldur            x1, [fp, #-0x10]
    // 0xeb7114: r0 = _stringify()
    //     0xeb7114: bl              #0xeb7154  ; [package:flutter/src/services/system_chrome.dart] ::_stringify
    // 0xeb7118: r16 = <void?>
    //     0xeb7118: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xeb711c: r30 = Instance_OptionalMethodChannel
    //     0xeb711c: ldr             lr, [PP, #0x1960]  ; [pp+0x1960] Obj!OptionalMethodChannel@129bec1
    // 0xeb7120: stp             lr, x16, [SP, #0x10]
    // 0xeb7124: r16 = "SystemChrome.setPreferredOrientations"
    //     0xeb7124: add             x16, PP, #0xb, lsl #12  ; [pp+0xb3c0] "SystemChrome.setPreferredOrientations"
    //     0xeb7128: ldr             x16, [x16, #0x3c0]
    // 0xeb712c: stp             x0, x16, [SP]
    // 0xeb7130: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xeb7130: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xeb7134: r0 = invokeMethod()
    //     0xeb7134: bl              #0x130ad0c  ; [package:flutter/src/services/platform_channel.dart] OptionalMethodChannel::invokeMethod
    // 0xeb7138: mov             x1, x0
    // 0xeb713c: stur            x1, [fp, #-0x10]
    // 0xeb7140: r0 = Await()
    //     0xeb7140: bl              #0x7f5c00  ; AwaitStub
    // 0xeb7144: r0 = Null
    //     0xeb7144: mov             x0, NULL
    // 0xeb7148: r0 = ReturnAsyncNotFuture()
    //     0xeb7148: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xeb714c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeb714c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeb7150: b               #0xeb7108
  }
  static _ setEnabledSystemUIMode(/* No info */) async {
    // ** addr: 0xf6c120, size: 0x100
    // 0xf6c120: EnterFrame
    //     0xf6c120: stp             fp, lr, [SP, #-0x10]!
    //     0xf6c124: mov             fp, SP
    // 0xf6c128: AllocStack(0x38)
    //     0xf6c128: sub             SP, SP, #0x38
    // 0xf6c12c: SetupParameters(dynamic _ /* r1 => r1, fp-0x18 */, {dynamic overlays = Null /* r2, fp-0x10 */})
    //     0xf6c12c: stur            NULL, [fp, #-8]
    //     0xf6c130: stur            x1, [fp, #-0x18]
    //     0xf6c134: ldur            w0, [x4, #0x13]
    //     0xf6c138: ldur            w2, [x4, #0x1f]
    //     0xf6c13c: add             x2, x2, HEAP, lsl #32
    //     0xf6c140: add             x16, PP, #8, lsl #12  ; [pp+0x8020] "overlays"
    //     0xf6c144: ldr             x16, [x16, #0x20]
    //     0xf6c148: cmp             w2, w16
    //     0xf6c14c: b.ne            #0xf6c16c
    //     0xf6c150: ldur            w2, [x4, #0x23]
    //     0xf6c154: add             x2, x2, HEAP, lsl #32
    //     0xf6c158: sub             w3, w0, w2
    //     0xf6c15c: add             x0, fp, w3, sxtw #2
    //     0xf6c160: ldr             x0, [x0, #8]
    //     0xf6c164: mov             x2, x0
    //     0xf6c168: b               #0xf6c170
    //     0xf6c16c: mov             x2, NULL
    //     0xf6c170: stur            x2, [fp, #-0x10]
    // 0xf6c174: CheckStackOverflow
    //     0xf6c174: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6c178: cmp             SP, x16
    //     0xf6c17c: b.ls            #0xf6c214
    // 0xf6c180: InitAsync() -> Future<void?>
    //     0xf6c180: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0xf6c184: bl              #0x7f5e44  ; InitAsyncStub
    // 0xf6c188: ldur            x1, [fp, #-0x18]
    // 0xf6c18c: r16 = Instance_SystemUiMode
    //     0xf6c18c: add             x16, PP, #8, lsl #12  ; [pp+0x8028] Obj!SystemUiMode@12c3a81
    //     0xf6c190: ldr             x16, [x16, #0x28]
    // 0xf6c194: cmp             w1, w16
    // 0xf6c198: b.eq            #0xf6c1d0
    // 0xf6c19c: r0 = _enumToString()
    //     0xf6c19c: bl              #0x11ab8cc  ; [package:flutter/src/services/system_chrome.dart] SystemUiMode::_enumToString
    // 0xf6c1a0: r16 = <void?>
    //     0xf6c1a0: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xf6c1a4: r30 = Instance_OptionalMethodChannel
    //     0xf6c1a4: ldr             lr, [PP, #0x1960]  ; [pp+0x1960] Obj!OptionalMethodChannel@129bec1
    // 0xf6c1a8: stp             lr, x16, [SP, #0x10]
    // 0xf6c1ac: r16 = "SystemChrome.setEnabledSystemUIMode"
    //     0xf6c1ac: add             x16, PP, #8, lsl #12  ; [pp+0x8030] "SystemChrome.setEnabledSystemUIMode"
    //     0xf6c1b0: ldr             x16, [x16, #0x30]
    // 0xf6c1b4: stp             x0, x16, [SP]
    // 0xf6c1b8: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xf6c1b8: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xf6c1bc: r0 = invokeMethod()
    //     0xf6c1bc: bl              #0x130ad0c  ; [package:flutter/src/services/platform_channel.dart] OptionalMethodChannel::invokeMethod
    // 0xf6c1c0: mov             x1, x0
    // 0xf6c1c4: stur            x1, [fp, #-0x18]
    // 0xf6c1c8: r0 = Await()
    //     0xf6c1c8: bl              #0x7f5c00  ; AwaitStub
    // 0xf6c1cc: b               #0xf6c20c
    // 0xf6c1d0: ldur            x1, [fp, #-0x10]
    // 0xf6c1d4: cmp             w1, NULL
    // 0xf6c1d8: b.eq            #0xf6c21c
    // 0xf6c1dc: r0 = _stringify()
    //     0xf6c1dc: bl              #0xeb7154  ; [package:flutter/src/services/system_chrome.dart] ::_stringify
    // 0xf6c1e0: r16 = <void?>
    //     0xf6c1e0: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xf6c1e4: r30 = Instance_OptionalMethodChannel
    //     0xf6c1e4: ldr             lr, [PP, #0x1960]  ; [pp+0x1960] Obj!OptionalMethodChannel@129bec1
    // 0xf6c1e8: stp             lr, x16, [SP, #0x10]
    // 0xf6c1ec: r16 = "SystemChrome.setEnabledSystemUIOverlays"
    //     0xf6c1ec: add             x16, PP, #8, lsl #12  ; [pp+0x8038] "SystemChrome.setEnabledSystemUIOverlays"
    //     0xf6c1f0: ldr             x16, [x16, #0x38]
    // 0xf6c1f4: stp             x0, x16, [SP]
    // 0xf6c1f8: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xf6c1f8: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xf6c1fc: r0 = invokeMethod()
    //     0xf6c1fc: bl              #0x130ad0c  ; [package:flutter/src/services/platform_channel.dart] OptionalMethodChannel::invokeMethod
    // 0xf6c200: mov             x1, x0
    // 0xf6c204: stur            x1, [fp, #-0x10]
    // 0xf6c208: r0 = Await()
    //     0xf6c208: bl              #0x7f5c00  ; AwaitStub
    // 0xf6c20c: r0 = Null
    //     0xf6c20c: mov             x0, NULL
    // 0xf6c210: r0 = ReturnAsyncNotFuture()
    //     0xf6c210: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xf6c214: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6c214: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6c218: b               #0xf6c180
    // 0xf6c21c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6c21c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static _ setApplicationSwitcherDescription(/* No info */) async {
    // ** addr: 0xf76388, size: 0xc4
    // 0xf76388: EnterFrame
    //     0xf76388: stp             fp, lr, [SP, #-0x10]!
    //     0xf7638c: mov             fp, SP
    // 0xf76390: AllocStack(0x30)
    //     0xf76390: sub             SP, SP, #0x30
    // 0xf76394: SetupParameters(dynamic _ /* r1 => r1, fp-0x10 */)
    //     0xf76394: stur            NULL, [fp, #-8]
    //     0xf76398: stur            x1, [fp, #-0x10]
    // 0xf7639c: CheckStackOverflow
    //     0xf7639c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf763a0: cmp             SP, x16
    //     0xf763a4: b.ls            #0xf76444
    // 0xf763a8: InitAsync() -> Future<void?>
    //     0xf763a8: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0xf763ac: bl              #0x7f5e44  ; InitAsyncStub
    // 0xf763b0: r1 = Null
    //     0xf763b0: mov             x1, NULL
    // 0xf763b4: r2 = 8
    //     0xf763b4: mov             x2, #8
    // 0xf763b8: r0 = AllocateArray()
    //     0xf763b8: bl              #0x13df928  ; AllocateArrayStub
    // 0xf763bc: mov             x2, x0
    // 0xf763c0: r16 = "label"
    //     0xf763c0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15168] "label"
    //     0xf763c4: ldr             x16, [x16, #0x168]
    // 0xf763c8: StoreField: r2->field_f = r16
    //     0xf763c8: stur            w16, [x2, #0xf]
    // 0xf763cc: ldur            x0, [fp, #-0x10]
    // 0xf763d0: LoadField: r1 = r0->field_7
    //     0xf763d0: ldur            w1, [x0, #7]
    // 0xf763d4: DecompressPointer r1
    //     0xf763d4: add             x1, x1, HEAP, lsl #32
    // 0xf763d8: StoreField: r2->field_13 = r1
    //     0xf763d8: stur            w1, [x2, #0x13]
    // 0xf763dc: r16 = "primaryColor"
    //     0xf763dc: add             x16, PP, #0x12, lsl #12  ; [pp+0x12b08] "primaryColor"
    //     0xf763e0: ldr             x16, [x16, #0xb08]
    // 0xf763e4: ArrayStore: r2[0] = r16  ; List_4
    //     0xf763e4: stur            w16, [x2, #0x17]
    // 0xf763e8: LoadField: r3 = r0->field_b
    //     0xf763e8: ldur            x3, [x0, #0xb]
    // 0xf763ec: r0 = BoxInt64Instr(r3)
    //     0xf763ec: sbfiz           x0, x3, #1, #0x1f
    //     0xf763f0: cmp             x3, x0, asr #1
    //     0xf763f4: b.eq            #0xf76400
    //     0xf763f8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xf763fc: stur            x3, [x0, #7]
    // 0xf76400: StoreField: r2->field_1b = r0
    //     0xf76400: stur            w0, [x2, #0x1b]
    // 0xf76404: r16 = <String, dynamic>
    //     0xf76404: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0xf76408: stp             x2, x16, [SP]
    // 0xf7640c: r0 = Map._fromLiteral()
    //     0xf7640c: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xf76410: r16 = <void?>
    //     0xf76410: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xf76414: r30 = Instance_OptionalMethodChannel
    //     0xf76414: ldr             lr, [PP, #0x1960]  ; [pp+0x1960] Obj!OptionalMethodChannel@129bec1
    // 0xf76418: stp             lr, x16, [SP, #0x10]
    // 0xf7641c: r16 = "SystemChrome.setApplicationSwitcherDescription"
    //     0xf7641c: add             x16, PP, #0xb0, lsl #12  ; [pp+0xb0a20] "SystemChrome.setApplicationSwitcherDescription"
    //     0xf76420: ldr             x16, [x16, #0xa20]
    // 0xf76424: stp             x0, x16, [SP]
    // 0xf76428: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xf76428: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xf7642c: r0 = invokeMethod()
    //     0xf7642c: bl              #0x130ad0c  ; [package:flutter/src/services/platform_channel.dart] OptionalMethodChannel::invokeMethod
    // 0xf76430: mov             x1, x0
    // 0xf76434: stur            x1, [fp, #-0x10]
    // 0xf76438: r0 = Await()
    //     0xf76438: bl              #0x7f5c00  ; AwaitStub
    // 0xf7643c: r0 = Null
    //     0xf7643c: mov             x0, NULL
    // 0xf76440: r0 = ReturnAsyncNotFuture()
    //     0xf76440: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xf76444: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf76444: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf76448: b               #0xf763a8
  }
}

// class id: 2743, size: 0x14, field offset: 0x8
//   const constructor, 
class ApplicationSwitcherDescription extends Object {
}

// class id: 5014, size: 0x28, field offset: 0x8
//   const constructor, 
class SystemUiOverlayStyle extends _MixinApplication3&Object&Diagnosticable {

  Color field_8;
  Color field_18;
  Brightness field_1c;
  Brightness field_20;
  Brightness field_10;

  _ _toMap(/* No info */) {
    // ** addr: 0x899374, size: 0x2d4
    // 0x899374: EnterFrame
    //     0x899374: stp             fp, lr, [SP, #-0x10]!
    //     0x899378: mov             fp, SP
    // 0x89937c: AllocStack(0x28)
    //     0x89937c: sub             SP, SP, #0x28
    // 0x899380: SetupParameters(SystemUiOverlayStyle this /* r1 => r0, fp-0x8 */)
    //     0x899380: mov             x0, x1
    //     0x899384: stur            x1, [fp, #-8]
    // 0x899388: CheckStackOverflow
    //     0x899388: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89938c: cmp             SP, x16
    //     0x899390: b.ls            #0x899640
    // 0x899394: r1 = Null
    //     0x899394: mov             x1, NULL
    // 0x899398: r2 = 32
    //     0x899398: mov             x2, #0x20
    // 0x89939c: r0 = AllocateArray()
    //     0x89939c: bl              #0x13df928  ; AllocateArrayStub
    // 0x8993a0: stur            x0, [fp, #-0x10]
    // 0x8993a4: r16 = "systemNavigationBarColor"
    //     0x8993a4: ldr             x16, [PP, #0x2c38]  ; [pp+0x2c38] "systemNavigationBarColor"
    // 0x8993a8: StoreField: r0->field_f = r16
    //     0x8993a8: stur            w16, [x0, #0xf]
    // 0x8993ac: ldur            x2, [fp, #-8]
    // 0x8993b0: LoadField: r1 = r2->field_7
    //     0x8993b0: ldur            w1, [x2, #7]
    // 0x8993b4: DecompressPointer r1
    //     0x8993b4: add             x1, x1, HEAP, lsl #32
    // 0x8993b8: cmp             w1, NULL
    // 0x8993bc: b.ne            #0x8993d0
    // 0x8993c0: mov             x3, x2
    // 0x8993c4: mov             x2, x0
    // 0x8993c8: r0 = Null
    //     0x8993c8: mov             x0, NULL
    // 0x8993cc: b               #0x8993f4
    // 0x8993d0: r0 = toARGB32()
    //     0x8993d0: bl              #0x119defc  ; [dart:ui] Color::toARGB32
    // 0x8993d4: mov             x2, x0
    // 0x8993d8: r0 = BoxInt64Instr(r2)
    //     0x8993d8: sbfiz           x0, x2, #1, #0x1f
    //     0x8993dc: cmp             x2, x0, asr #1
    //     0x8993e0: b.eq            #0x8993ec
    //     0x8993e4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8993e8: stur            x2, [x0, #7]
    // 0x8993ec: ldur            x3, [fp, #-8]
    // 0x8993f0: ldur            x2, [fp, #-0x10]
    // 0x8993f4: mov             x1, x2
    // 0x8993f8: ArrayStore: r1[1] = r0  ; List_4
    //     0x8993f8: add             x25, x1, #0x13
    //     0x8993fc: str             w0, [x25]
    //     0x899400: tbz             w0, #0, #0x89941c
    //     0x899404: ldurb           w16, [x1, #-1]
    //     0x899408: ldurb           w17, [x0, #-1]
    //     0x89940c: and             x16, x17, x16, lsr #2
    //     0x899410: tst             x16, HEAP, lsr #32
    //     0x899414: b.eq            #0x89941c
    //     0x899418: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x89941c: r16 = "systemNavigationBarDividerColor"
    //     0x89941c: ldr             x16, [PP, #0x2c40]  ; [pp+0x2c40] "systemNavigationBarDividerColor"
    // 0x899420: ArrayStore: r2[0] = r16  ; List_4
    //     0x899420: stur            w16, [x2, #0x17]
    // 0x899424: StoreField: r2->field_1b = rNULL
    //     0x899424: stur            NULL, [x2, #0x1b]
    // 0x899428: r16 = "systemStatusBarContrastEnforced"
    //     0x899428: ldr             x16, [PP, #0x2c48]  ; [pp+0x2c48] "systemStatusBarContrastEnforced"
    // 0x89942c: StoreField: r2->field_1f = r16
    //     0x89942c: stur            w16, [x2, #0x1f]
    // 0x899430: LoadField: r0 = r3->field_23
    //     0x899430: ldur            w0, [x3, #0x23]
    // 0x899434: DecompressPointer r0
    //     0x899434: add             x0, x0, HEAP, lsl #32
    // 0x899438: StoreField: r2->field_23 = r0
    //     0x899438: stur            w0, [x2, #0x23]
    // 0x89943c: r16 = "statusBarColor"
    //     0x89943c: ldr             x16, [PP, #0x2c50]  ; [pp+0x2c50] "statusBarColor"
    // 0x899440: StoreField: r2->field_27 = r16
    //     0x899440: stur            w16, [x2, #0x27]
    // 0x899444: ArrayLoad: r1 = r3[0]  ; List_4
    //     0x899444: ldur            w1, [x3, #0x17]
    // 0x899448: DecompressPointer r1
    //     0x899448: add             x1, x1, HEAP, lsl #32
    // 0x89944c: cmp             w1, NULL
    // 0x899450: b.ne            #0x899464
    // 0x899454: mov             x4, x3
    // 0x899458: mov             x3, x2
    // 0x89945c: r0 = Null
    //     0x89945c: mov             x0, NULL
    // 0x899460: b               #0x899488
    // 0x899464: r0 = toARGB32()
    //     0x899464: bl              #0x119defc  ; [dart:ui] Color::toARGB32
    // 0x899468: mov             x2, x0
    // 0x89946c: r0 = BoxInt64Instr(r2)
    //     0x89946c: sbfiz           x0, x2, #1, #0x1f
    //     0x899470: cmp             x2, x0, asr #1
    //     0x899474: b.eq            #0x899480
    //     0x899478: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x89947c: stur            x2, [x0, #7]
    // 0x899480: ldur            x4, [fp, #-8]
    // 0x899484: ldur            x3, [fp, #-0x10]
    // 0x899488: mov             x1, x3
    // 0x89948c: ArrayStore: r1[7] = r0  ; List_4
    //     0x89948c: add             x25, x1, #0x2b
    //     0x899490: str             w0, [x25]
    //     0x899494: tbz             w0, #0, #0x8994b0
    //     0x899498: ldurb           w16, [x1, #-1]
    //     0x89949c: ldurb           w17, [x0, #-1]
    //     0x8994a0: and             x16, x17, x16, lsr #2
    //     0x8994a4: tst             x16, HEAP, lsr #32
    //     0x8994a8: b.eq            #0x8994b0
    //     0x8994ac: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x8994b0: r16 = "statusBarBrightness"
    //     0x8994b0: ldr             x16, [PP, #0x2c58]  ; [pp+0x2c58] "statusBarBrightness"
    // 0x8994b4: StoreField: r3->field_2f = r16
    //     0x8994b4: stur            w16, [x3, #0x2f]
    // 0x8994b8: LoadField: r0 = r4->field_1b
    //     0x8994b8: ldur            w0, [x4, #0x1b]
    // 0x8994bc: DecompressPointer r0
    //     0x8994bc: add             x0, x0, HEAP, lsl #32
    // 0x8994c0: stur            x0, [fp, #-0x18]
    // 0x8994c4: r1 = Null
    //     0x8994c4: mov             x1, NULL
    // 0x8994c8: r2 = 4
    //     0x8994c8: mov             x2, #4
    // 0x8994cc: r0 = AllocateArray()
    //     0x8994cc: bl              #0x13df928  ; AllocateArrayStub
    // 0x8994d0: r16 = "Brightness."
    //     0x8994d0: ldr             x16, [PP, #0x2c60]  ; [pp+0x2c60] "Brightness."
    // 0x8994d4: StoreField: r0->field_f = r16
    //     0x8994d4: stur            w16, [x0, #0xf]
    // 0x8994d8: ldur            x1, [fp, #-0x18]
    // 0x8994dc: LoadField: r2 = r1->field_f
    //     0x8994dc: ldur            w2, [x1, #0xf]
    // 0x8994e0: DecompressPointer r2
    //     0x8994e0: add             x2, x2, HEAP, lsl #32
    // 0x8994e4: StoreField: r0->field_13 = r2
    //     0x8994e4: stur            w2, [x0, #0x13]
    // 0x8994e8: str             x0, [SP]
    // 0x8994ec: r0 = _interpolate()
    //     0x8994ec: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x8994f0: ldur            x1, [fp, #-0x10]
    // 0x8994f4: ArrayStore: r1[9] = r0  ; List_4
    //     0x8994f4: add             x25, x1, #0x33
    //     0x8994f8: str             w0, [x25]
    //     0x8994fc: tbz             w0, #0, #0x899518
    //     0x899500: ldurb           w16, [x1, #-1]
    //     0x899504: ldurb           w17, [x0, #-1]
    //     0x899508: and             x16, x17, x16, lsr #2
    //     0x89950c: tst             x16, HEAP, lsr #32
    //     0x899510: b.eq            #0x899518
    //     0x899514: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x899518: ldur            x0, [fp, #-0x10]
    // 0x89951c: r16 = "statusBarIconBrightness"
    //     0x89951c: ldr             x16, [PP, #0x2c68]  ; [pp+0x2c68] "statusBarIconBrightness"
    // 0x899520: StoreField: r0->field_37 = r16
    //     0x899520: stur            w16, [x0, #0x37]
    // 0x899524: ldur            x3, [fp, #-8]
    // 0x899528: LoadField: r4 = r3->field_1f
    //     0x899528: ldur            w4, [x3, #0x1f]
    // 0x89952c: DecompressPointer r4
    //     0x89952c: add             x4, x4, HEAP, lsl #32
    // 0x899530: stur            x4, [fp, #-0x18]
    // 0x899534: r1 = Null
    //     0x899534: mov             x1, NULL
    // 0x899538: r2 = 4
    //     0x899538: mov             x2, #4
    // 0x89953c: r0 = AllocateArray()
    //     0x89953c: bl              #0x13df928  ; AllocateArrayStub
    // 0x899540: r16 = "Brightness."
    //     0x899540: ldr             x16, [PP, #0x2c60]  ; [pp+0x2c60] "Brightness."
    // 0x899544: StoreField: r0->field_f = r16
    //     0x899544: stur            w16, [x0, #0xf]
    // 0x899548: ldur            x1, [fp, #-0x18]
    // 0x89954c: LoadField: r2 = r1->field_f
    //     0x89954c: ldur            w2, [x1, #0xf]
    // 0x899550: DecompressPointer r2
    //     0x899550: add             x2, x2, HEAP, lsl #32
    // 0x899554: StoreField: r0->field_13 = r2
    //     0x899554: stur            w2, [x0, #0x13]
    // 0x899558: str             x0, [SP]
    // 0x89955c: r0 = _interpolate()
    //     0x89955c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x899560: ldur            x1, [fp, #-0x10]
    // 0x899564: ArrayStore: r1[11] = r0  ; List_4
    //     0x899564: add             x25, x1, #0x3b
    //     0x899568: str             w0, [x25]
    //     0x89956c: tbz             w0, #0, #0x899588
    //     0x899570: ldurb           w16, [x1, #-1]
    //     0x899574: ldurb           w17, [x0, #-1]
    //     0x899578: and             x16, x17, x16, lsr #2
    //     0x89957c: tst             x16, HEAP, lsr #32
    //     0x899580: b.eq            #0x899588
    //     0x899584: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x899588: ldur            x0, [fp, #-0x10]
    // 0x89958c: r16 = "systemNavigationBarIconBrightness"
    //     0x89958c: ldr             x16, [PP, #0x2c70]  ; [pp+0x2c70] "systemNavigationBarIconBrightness"
    // 0x899590: StoreField: r0->field_3f = r16
    //     0x899590: stur            w16, [x0, #0x3f]
    // 0x899594: ldur            x3, [fp, #-8]
    // 0x899598: LoadField: r4 = r3->field_f
    //     0x899598: ldur            w4, [x3, #0xf]
    // 0x89959c: DecompressPointer r4
    //     0x89959c: add             x4, x4, HEAP, lsl #32
    // 0x8995a0: stur            x4, [fp, #-0x18]
    // 0x8995a4: cmp             w4, NULL
    // 0x8995a8: b.ne            #0x8995b8
    // 0x8995ac: mov             x2, x0
    // 0x8995b0: r0 = Null
    //     0x8995b0: mov             x0, NULL
    // 0x8995b4: b               #0x8995ec
    // 0x8995b8: r1 = Null
    //     0x8995b8: mov             x1, NULL
    // 0x8995bc: r2 = 4
    //     0x8995bc: mov             x2, #4
    // 0x8995c0: r0 = AllocateArray()
    //     0x8995c0: bl              #0x13df928  ; AllocateArrayStub
    // 0x8995c4: r16 = "Brightness."
    //     0x8995c4: ldr             x16, [PP, #0x2c60]  ; [pp+0x2c60] "Brightness."
    // 0x8995c8: StoreField: r0->field_f = r16
    //     0x8995c8: stur            w16, [x0, #0xf]
    // 0x8995cc: ldur            x1, [fp, #-0x18]
    // 0x8995d0: LoadField: r2 = r1->field_f
    //     0x8995d0: ldur            w2, [x1, #0xf]
    // 0x8995d4: DecompressPointer r2
    //     0x8995d4: add             x2, x2, HEAP, lsl #32
    // 0x8995d8: StoreField: r0->field_13 = r2
    //     0x8995d8: stur            w2, [x0, #0x13]
    // 0x8995dc: str             x0, [SP]
    // 0x8995e0: r0 = _interpolate()
    //     0x8995e0: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x8995e4: ldur            x3, [fp, #-8]
    // 0x8995e8: ldur            x2, [fp, #-0x10]
    // 0x8995ec: mov             x1, x2
    // 0x8995f0: ArrayStore: r1[13] = r0  ; List_4
    //     0x8995f0: add             x25, x1, #0x43
    //     0x8995f4: str             w0, [x25]
    //     0x8995f8: tbz             w0, #0, #0x899614
    //     0x8995fc: ldurb           w16, [x1, #-1]
    //     0x899600: ldurb           w17, [x0, #-1]
    //     0x899604: and             x16, x17, x16, lsr #2
    //     0x899608: tst             x16, HEAP, lsr #32
    //     0x89960c: b.eq            #0x899614
    //     0x899610: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x899614: r16 = "systemNavigationBarContrastEnforced"
    //     0x899614: ldr             x16, [PP, #0x2c78]  ; [pp+0x2c78] "systemNavigationBarContrastEnforced"
    // 0x899618: StoreField: r2->field_47 = r16
    //     0x899618: stur            w16, [x2, #0x47]
    // 0x89961c: LoadField: r0 = r3->field_13
    //     0x89961c: ldur            w0, [x3, #0x13]
    // 0x899620: DecompressPointer r0
    //     0x899620: add             x0, x0, HEAP, lsl #32
    // 0x899624: StoreField: r2->field_4b = r0
    //     0x899624: stur            w0, [x2, #0x4b]
    // 0x899628: r16 = <String, dynamic>
    //     0x899628: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x89962c: stp             x2, x16, [SP]
    // 0x899630: r0 = Map._fromLiteral()
    //     0x899630: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x899634: LeaveFrame
    //     0x899634: mov             SP, fp
    //     0x899638: ldp             fp, lr, [SP], #0x10
    // 0x89963c: ret
    //     0x89963c: ret             
    // 0x899640: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x899640: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x899644: b               #0x899394
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x113c1f0, size: 0x8c
    // 0x113c1f0: EnterFrame
    //     0x113c1f0: stp             fp, lr, [SP, #-0x10]!
    //     0x113c1f4: mov             fp, SP
    // 0x113c1f8: AllocStack(0x30)
    //     0x113c1f8: sub             SP, SP, #0x30
    // 0x113c1fc: CheckStackOverflow
    //     0x113c1fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x113c200: cmp             SP, x16
    //     0x113c204: b.ls            #0x113c274
    // 0x113c208: ldr             x0, [fp, #0x10]
    // 0x113c20c: LoadField: r1 = r0->field_7
    //     0x113c20c: ldur            w1, [x0, #7]
    // 0x113c210: DecompressPointer r1
    //     0x113c210: add             x1, x1, HEAP, lsl #32
    // 0x113c214: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x113c214: ldur            w2, [x0, #0x17]
    // 0x113c218: DecompressPointer r2
    //     0x113c218: add             x2, x2, HEAP, lsl #32
    // 0x113c21c: LoadField: r3 = r0->field_1b
    //     0x113c21c: ldur            w3, [x0, #0x1b]
    // 0x113c220: DecompressPointer r3
    //     0x113c220: add             x3, x3, HEAP, lsl #32
    // 0x113c224: LoadField: r4 = r0->field_1f
    //     0x113c224: ldur            w4, [x0, #0x1f]
    // 0x113c228: DecompressPointer r4
    //     0x113c228: add             x4, x4, HEAP, lsl #32
    // 0x113c22c: LoadField: r5 = r0->field_f
    //     0x113c22c: ldur            w5, [x0, #0xf]
    // 0x113c230: DecompressPointer r5
    //     0x113c230: add             x5, x5, HEAP, lsl #32
    // 0x113c234: stp             x2, NULL, [SP, #0x20]
    // 0x113c238: stp             x4, x3, [SP, #0x10]
    // 0x113c23c: stp             x5, NULL, [SP]
    // 0x113c240: r2 = Null
    //     0x113c240: mov             x2, NULL
    // 0x113c244: r4 = const [0, 0x8, 0x6, 0x8, null]
    //     0x113c244: add             x4, PP, #0xe, lsl #12  ; [pp+0xe090] List(5) [0, 0x8, 0x6, 0x8, Null]
    //     0x113c248: ldr             x4, [x4, #0x90]
    // 0x113c24c: r0 = hash()
    //     0x113c24c: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x113c250: mov             x2, x0
    // 0x113c254: r0 = BoxInt64Instr(r2)
    //     0x113c254: sbfiz           x0, x2, #1, #0x1f
    //     0x113c258: cmp             x2, x0, asr #1
    //     0x113c25c: b.eq            #0x113c268
    //     0x113c260: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x113c264: stur            x2, [x0, #7]
    // 0x113c268: LeaveFrame
    //     0x113c268: mov             SP, fp
    //     0x113c26c: ldp             fp, lr, [SP], #0x10
    // 0x113c270: ret
    //     0x113c270: ret             
    // 0x113c274: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x113c274: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x113c278: b               #0x113c208
  }
  _ ==(/* No info */) {
    // ** addr: 0x127a3f8, size: 0x174
    // 0x127a3f8: EnterFrame
    //     0x127a3f8: stp             fp, lr, [SP, #-0x10]!
    //     0x127a3fc: mov             fp, SP
    // 0x127a400: AllocStack(0x10)
    //     0x127a400: sub             SP, SP, #0x10
    // 0x127a404: CheckStackOverflow
    //     0x127a404: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x127a408: cmp             SP, x16
    //     0x127a40c: b.ls            #0x127a564
    // 0x127a410: ldr             x0, [fp, #0x10]
    // 0x127a414: cmp             w0, NULL
    // 0x127a418: b.ne            #0x127a42c
    // 0x127a41c: r0 = false
    //     0x127a41c: add             x0, NULL, #0x30  ; false
    // 0x127a420: LeaveFrame
    //     0x127a420: mov             SP, fp
    //     0x127a424: ldp             fp, lr, [SP], #0x10
    // 0x127a428: ret
    //     0x127a428: ret             
    // 0x127a42c: str             x0, [SP]
    // 0x127a430: r0 = runtimeType()
    //     0x127a430: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x127a434: r1 = LoadClassIdInstr(r0)
    //     0x127a434: ldur            x1, [x0, #-1]
    //     0x127a438: ubfx            x1, x1, #0xc, #0x14
    // 0x127a43c: r16 = SystemUiOverlayStyle
    //     0x127a43c: ldr             x16, [PP, #0x2c88]  ; [pp+0x2c88] Type: SystemUiOverlayStyle
    // 0x127a440: stp             x16, x0, [SP]
    // 0x127a444: mov             x0, x1
    // 0x127a448: mov             lr, x0
    // 0x127a44c: ldr             lr, [x21, lr, lsl #3]
    // 0x127a450: blr             lr
    // 0x127a454: tbz             w0, #4, #0x127a468
    // 0x127a458: r0 = false
    //     0x127a458: add             x0, NULL, #0x30  ; false
    // 0x127a45c: LeaveFrame
    //     0x127a45c: mov             SP, fp
    //     0x127a460: ldp             fp, lr, [SP], #0x10
    // 0x127a464: ret
    //     0x127a464: ret             
    // 0x127a468: ldr             x1, [fp, #0x10]
    // 0x127a46c: r0 = 60
    //     0x127a46c: mov             x0, #0x3c
    // 0x127a470: branchIfSmi(r1, 0x127a47c)
    //     0x127a470: tbz             w1, #0, #0x127a47c
    // 0x127a474: r0 = LoadClassIdInstr(r1)
    //     0x127a474: ldur            x0, [x1, #-1]
    //     0x127a478: ubfx            x0, x0, #0xc, #0x14
    // 0x127a47c: r17 = 5014
    //     0x127a47c: mov             x17, #0x1396
    // 0x127a480: cmp             x0, x17
    // 0x127a484: b.ne            #0x127a554
    // 0x127a488: ldr             x2, [fp, #0x18]
    // 0x127a48c: LoadField: r0 = r1->field_7
    //     0x127a48c: ldur            w0, [x1, #7]
    // 0x127a490: DecompressPointer r0
    //     0x127a490: add             x0, x0, HEAP, lsl #32
    // 0x127a494: LoadField: r3 = r2->field_7
    //     0x127a494: ldur            w3, [x2, #7]
    // 0x127a498: DecompressPointer r3
    //     0x127a498: add             x3, x3, HEAP, lsl #32
    // 0x127a49c: r4 = LoadClassIdInstr(r0)
    //     0x127a49c: ldur            x4, [x0, #-1]
    //     0x127a4a0: ubfx            x4, x4, #0xc, #0x14
    // 0x127a4a4: stp             x3, x0, [SP]
    // 0x127a4a8: mov             x0, x4
    // 0x127a4ac: mov             lr, x0
    // 0x127a4b0: ldr             lr, [x21, lr, lsl #3]
    // 0x127a4b4: blr             lr
    // 0x127a4b8: tbnz            w0, #4, #0x127a554
    // 0x127a4bc: ldr             x2, [fp, #0x18]
    // 0x127a4c0: ldr             x1, [fp, #0x10]
    // 0x127a4c4: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x127a4c4: ldur            w0, [x1, #0x17]
    // 0x127a4c8: DecompressPointer r0
    //     0x127a4c8: add             x0, x0, HEAP, lsl #32
    // 0x127a4cc: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x127a4cc: ldur            w3, [x2, #0x17]
    // 0x127a4d0: DecompressPointer r3
    //     0x127a4d0: add             x3, x3, HEAP, lsl #32
    // 0x127a4d4: r4 = LoadClassIdInstr(r0)
    //     0x127a4d4: ldur            x4, [x0, #-1]
    //     0x127a4d8: ubfx            x4, x4, #0xc, #0x14
    // 0x127a4dc: stp             x3, x0, [SP]
    // 0x127a4e0: mov             x0, x4
    // 0x127a4e4: mov             lr, x0
    // 0x127a4e8: ldr             lr, [x21, lr, lsl #3]
    // 0x127a4ec: blr             lr
    // 0x127a4f0: tbnz            w0, #4, #0x127a554
    // 0x127a4f4: ldr             x2, [fp, #0x18]
    // 0x127a4f8: ldr             x1, [fp, #0x10]
    // 0x127a4fc: LoadField: r3 = r1->field_1f
    //     0x127a4fc: ldur            w3, [x1, #0x1f]
    // 0x127a500: DecompressPointer r3
    //     0x127a500: add             x3, x3, HEAP, lsl #32
    // 0x127a504: LoadField: r4 = r2->field_1f
    //     0x127a504: ldur            w4, [x2, #0x1f]
    // 0x127a508: DecompressPointer r4
    //     0x127a508: add             x4, x4, HEAP, lsl #32
    // 0x127a50c: cmp             w3, w4
    // 0x127a510: b.ne            #0x127a554
    // 0x127a514: LoadField: r3 = r1->field_1b
    //     0x127a514: ldur            w3, [x1, #0x1b]
    // 0x127a518: DecompressPointer r3
    //     0x127a518: add             x3, x3, HEAP, lsl #32
    // 0x127a51c: LoadField: r4 = r2->field_1b
    //     0x127a51c: ldur            w4, [x2, #0x1b]
    // 0x127a520: DecompressPointer r4
    //     0x127a520: add             x4, x4, HEAP, lsl #32
    // 0x127a524: cmp             w3, w4
    // 0x127a528: b.ne            #0x127a554
    // 0x127a52c: LoadField: r3 = r1->field_f
    //     0x127a52c: ldur            w3, [x1, #0xf]
    // 0x127a530: DecompressPointer r3
    //     0x127a530: add             x3, x3, HEAP, lsl #32
    // 0x127a534: LoadField: r1 = r2->field_f
    //     0x127a534: ldur            w1, [x2, #0xf]
    // 0x127a538: DecompressPointer r1
    //     0x127a538: add             x1, x1, HEAP, lsl #32
    // 0x127a53c: cmp             w3, w1
    // 0x127a540: r16 = true
    //     0x127a540: add             x16, NULL, #0x20  ; true
    // 0x127a544: r17 = false
    //     0x127a544: add             x17, NULL, #0x30  ; false
    // 0x127a548: csel            x2, x16, x17, eq
    // 0x127a54c: mov             x0, x2
    // 0x127a550: b               #0x127a558
    // 0x127a554: r0 = false
    //     0x127a554: add             x0, NULL, #0x30  ; false
    // 0x127a558: LeaveFrame
    //     0x127a558: mov             SP, fp
    //     0x127a55c: ldp             fp, lr, [SP], #0x10
    // 0x127a560: ret
    //     0x127a560: ret             
    // 0x127a564: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x127a564: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x127a568: b               #0x127a410
  }
}

// class id: 8201, size: 0x14, field offset: 0x14
enum SystemUiMode extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11ab8cc, size: 0x64
    // 0x11ab8cc: EnterFrame
    //     0x11ab8cc: stp             fp, lr, [SP, #-0x10]!
    //     0x11ab8d0: mov             fp, SP
    // 0x11ab8d4: AllocStack(0x10)
    //     0x11ab8d4: sub             SP, SP, #0x10
    // 0x11ab8d8: SetupParameters(SystemUiMode this /* r1 => r0, fp-0x8 */)
    //     0x11ab8d8: mov             x0, x1
    //     0x11ab8dc: stur            x1, [fp, #-8]
    // 0x11ab8e0: CheckStackOverflow
    //     0x11ab8e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11ab8e4: cmp             SP, x16
    //     0x11ab8e8: b.ls            #0x11ab928
    // 0x11ab8ec: r1 = Null
    //     0x11ab8ec: mov             x1, NULL
    // 0x11ab8f0: r2 = 4
    //     0x11ab8f0: mov             x2, #4
    // 0x11ab8f4: r0 = AllocateArray()
    //     0x11ab8f4: bl              #0x13df928  ; AllocateArrayStub
    // 0x11ab8f8: r16 = "SystemUiMode."
    //     0x11ab8f8: add             x16, PP, #8, lsl #12  ; [pp+0x8040] "SystemUiMode."
    //     0x11ab8fc: ldr             x16, [x16, #0x40]
    // 0x11ab900: StoreField: r0->field_f = r16
    //     0x11ab900: stur            w16, [x0, #0xf]
    // 0x11ab904: ldur            x1, [fp, #-8]
    // 0x11ab908: LoadField: r2 = r1->field_f
    //     0x11ab908: ldur            w2, [x1, #0xf]
    // 0x11ab90c: DecompressPointer r2
    //     0x11ab90c: add             x2, x2, HEAP, lsl #32
    // 0x11ab910: StoreField: r0->field_13 = r2
    //     0x11ab910: stur            w2, [x0, #0x13]
    // 0x11ab914: str             x0, [SP]
    // 0x11ab918: r0 = _interpolate()
    //     0x11ab918: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11ab91c: LeaveFrame
    //     0x11ab91c: mov             SP, fp
    //     0x11ab920: ldp             fp, lr, [SP], #0x10
    // 0x11ab924: ret
    //     0x11ab924: ret             
    // 0x11ab928: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11ab928: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11ab92c: b               #0x11ab8ec
  }
}

// class id: 8202, size: 0x14, field offset: 0x14
enum SystemUiOverlay extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11ab868, size: 0x64
    // 0x11ab868: EnterFrame
    //     0x11ab868: stp             fp, lr, [SP, #-0x10]!
    //     0x11ab86c: mov             fp, SP
    // 0x11ab870: AllocStack(0x10)
    //     0x11ab870: sub             SP, SP, #0x10
    // 0x11ab874: SetupParameters(SystemUiOverlay this /* r1 => r0, fp-0x8 */)
    //     0x11ab874: mov             x0, x1
    //     0x11ab878: stur            x1, [fp, #-8]
    // 0x11ab87c: CheckStackOverflow
    //     0x11ab87c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11ab880: cmp             SP, x16
    //     0x11ab884: b.ls            #0x11ab8c4
    // 0x11ab888: r1 = Null
    //     0x11ab888: mov             x1, NULL
    // 0x11ab88c: r2 = 4
    //     0x11ab88c: mov             x2, #4
    // 0x11ab890: r0 = AllocateArray()
    //     0x11ab890: bl              #0x13df928  ; AllocateArrayStub
    // 0x11ab894: r16 = "SystemUiOverlay."
    //     0x11ab894: add             x16, PP, #0xcc, lsl #12  ; [pp+0xcccb0] "SystemUiOverlay."
    //     0x11ab898: ldr             x16, [x16, #0xcb0]
    // 0x11ab89c: StoreField: r0->field_f = r16
    //     0x11ab89c: stur            w16, [x0, #0xf]
    // 0x11ab8a0: ldur            x1, [fp, #-8]
    // 0x11ab8a4: LoadField: r2 = r1->field_f
    //     0x11ab8a4: ldur            w2, [x1, #0xf]
    // 0x11ab8a8: DecompressPointer r2
    //     0x11ab8a8: add             x2, x2, HEAP, lsl #32
    // 0x11ab8ac: StoreField: r0->field_13 = r2
    //     0x11ab8ac: stur            w2, [x0, #0x13]
    // 0x11ab8b0: str             x0, [SP]
    // 0x11ab8b4: r0 = _interpolate()
    //     0x11ab8b4: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11ab8b8: LeaveFrame
    //     0x11ab8b8: mov             SP, fp
    //     0x11ab8bc: ldp             fp, lr, [SP], #0x10
    // 0x11ab8c0: ret
    //     0x11ab8c0: ret             
    // 0x11ab8c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11ab8c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11ab8c8: b               #0x11ab888
  }
}

// class id: 8203, size: 0x14, field offset: 0x14
enum DeviceOrientation extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11ab804, size: 0x64
    // 0x11ab804: EnterFrame
    //     0x11ab804: stp             fp, lr, [SP, #-0x10]!
    //     0x11ab808: mov             fp, SP
    // 0x11ab80c: AllocStack(0x10)
    //     0x11ab80c: sub             SP, SP, #0x10
    // 0x11ab810: SetupParameters(DeviceOrientation this /* r1 => r0, fp-0x8 */)
    //     0x11ab810: mov             x0, x1
    //     0x11ab814: stur            x1, [fp, #-8]
    // 0x11ab818: CheckStackOverflow
    //     0x11ab818: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11ab81c: cmp             SP, x16
    //     0x11ab820: b.ls            #0x11ab860
    // 0x11ab824: r1 = Null
    //     0x11ab824: mov             x1, NULL
    // 0x11ab828: r2 = 4
    //     0x11ab828: mov             x2, #4
    // 0x11ab82c: r0 = AllocateArray()
    //     0x11ab82c: bl              #0x13df928  ; AllocateArrayStub
    // 0x11ab830: r16 = "DeviceOrientation."
    //     0x11ab830: add             x16, PP, #0x10, lsl #12  ; [pp+0x10de0] "DeviceOrientation."
    //     0x11ab834: ldr             x16, [x16, #0xde0]
    // 0x11ab838: StoreField: r0->field_f = r16
    //     0x11ab838: stur            w16, [x0, #0xf]
    // 0x11ab83c: ldur            x1, [fp, #-8]
    // 0x11ab840: LoadField: r2 = r1->field_f
    //     0x11ab840: ldur            w2, [x1, #0xf]
    // 0x11ab844: DecompressPointer r2
    //     0x11ab844: add             x2, x2, HEAP, lsl #32
    // 0x11ab848: StoreField: r0->field_13 = r2
    //     0x11ab848: stur            w2, [x0, #0x13]
    // 0x11ab84c: str             x0, [SP]
    // 0x11ab850: r0 = _interpolate()
    //     0x11ab850: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11ab854: LeaveFrame
    //     0x11ab854: mov             SP, fp
    //     0x11ab858: ldp             fp, lr, [SP], #0x10
    // 0x11ab85c: ret
    //     0x11ab85c: ret             
    // 0x11ab860: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11ab860: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11ab864: b               #0x11ab824
  }
}
