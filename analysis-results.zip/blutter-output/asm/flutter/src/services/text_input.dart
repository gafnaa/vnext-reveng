// lib: , url: package:flutter/src/services/text_input.dart

// class id: 1049104, size: 0x8
class :: {

  static _ _reportError(/* No info */) {
    // ** addr: 0x853090, size: 0xc8
    // 0x853090: EnterFrame
    //     0x853090: stp             fp, lr, [SP, #-0x10]!
    //     0x853094: mov             fp, SP
    // 0x853098: AllocStack(0x20)
    //     0x853098: sub             SP, SP, #0x20
    // 0x85309c: SetupParameters(dynamic _ /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */, dynamic _ /* r3 => r2, fp-0x20 */, [dynamic _ = Null /* r4, fp-0x8 */])
    //     0x85309c: mov             x0, x2
    //     0x8530a0: stur            x2, [fp, #-0x18]
    //     0x8530a4: mov             x2, x3
    //     0x8530a8: stur            x3, [fp, #-0x20]
    //     0x8530ac: mov             x3, x1
    //     0x8530b0: stur            x1, [fp, #-0x10]
    //     0x8530b4: ldur            w1, [x4, #0x13]
    //     0x8530b8: sub             x4, x1, #6
    //     0x8530bc: cmp             w4, #2
    //     0x8530c0: b.lt            #0x8530d4
    //     0x8530c4: add             x1, fp, w4, sxtw #2
    //     0x8530c8: ldr             x1, [x1, #8]
    //     0x8530cc: mov             x4, x1
    //     0x8530d0: b               #0x8530d8
    //     0x8530d4: mov             x4, NULL
    //     0x8530d8: stur            x4, [fp, #-8]
    // 0x8530dc: CheckStackOverflow
    //     0x8530dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8530e0: cmp             SP, x16
    //     0x8530e4: b.ls            #0x853150
    // 0x8530e8: r1 = <List<Object>>
    //     0x8530e8: ldr             x1, [PP, #0x860]  ; [pp+0x860] TypeArguments: <List<Object>>
    // 0x8530ec: r0 = ErrorDescription()
    //     0x8530ec: bl              #0x829ca4  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x2c)
    // 0x8530f0: mov             x1, x0
    // 0x8530f4: ldur            x2, [fp, #-0x20]
    // 0x8530f8: r3 = Instance_DiagnosticLevel
    //     0x8530f8: ldr             x3, [PP, #0x868]  ; [pp+0x868] Obj!DiagnosticLevel@12c5f41
    // 0x8530fc: stur            x0, [fp, #-0x20]
    // 0x853100: r0 = _ErrorDiagnostic()
    //     0x853100: bl              #0x829bec  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0x853104: r0 = FlutterErrorDetails()
    //     0x853104: bl              #0x829be0  ; AllocateFlutterErrorDetailsStub -> FlutterErrorDetails (size=0x20)
    // 0x853108: mov             x1, x0
    // 0x85310c: ldur            x0, [fp, #-0x10]
    // 0x853110: StoreField: r1->field_7 = r0
    //     0x853110: stur            w0, [x1, #7]
    // 0x853114: ldur            x0, [fp, #-0x18]
    // 0x853118: StoreField: r1->field_b = r0
    //     0x853118: stur            w0, [x1, #0xb]
    // 0x85311c: r0 = "services library"
    //     0x85311c: ldr             x0, [PP, #0x870]  ; [pp+0x870] "services library"
    // 0x853120: StoreField: r1->field_f = r0
    //     0x853120: stur            w0, [x1, #0xf]
    // 0x853124: ldur            x0, [fp, #-0x20]
    // 0x853128: StoreField: r1->field_13 = r0
    //     0x853128: stur            w0, [x1, #0x13]
    // 0x85312c: ldur            x0, [fp, #-8]
    // 0x853130: ArrayStore: r1[0] = r0  ; List_4
    //     0x853130: stur            w0, [x1, #0x17]
    // 0x853134: r0 = false
    //     0x853134: add             x0, NULL, #0x30  ; false
    // 0x853138: StoreField: r1->field_1b = r0
    //     0x853138: stur            w0, [x1, #0x1b]
    // 0x85313c: r0 = reportError()
    //     0x85313c: bl              #0x829a24  ; [package:flutter/src/foundation/assertions.dart] FlutterError::reportError
    // 0x853140: r0 = Null
    //     0x853140: mov             x0, NULL
    // 0x853144: LeaveFrame
    //     0x853144: mov             SP, fp
    //     0x853148: ldp             fp, lr, [SP], #0x10
    // 0x85314c: ret
    //     0x85314c: ret             
    // 0x853150: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x853150: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x853154: b               #0x8530e8
  }
  static _ _toTextPoint(/* No info */) {
    // ** addr: 0x875270, size: 0x194
    // 0x875270: EnterFrame
    //     0x875270: stp             fp, lr, [SP, #-0x10]!
    //     0x875274: mov             fp, SP
    // 0x875278: AllocStack(0x28)
    //     0x875278: sub             SP, SP, #0x28
    // 0x87527c: SetupParameters(dynamic _ /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x87527c: mov             x4, x1
    //     0x875280: mov             x3, x2
    //     0x875284: stur            x1, [fp, #-8]
    //     0x875288: stur            x2, [fp, #-0x10]
    // 0x87528c: CheckStackOverflow
    //     0x87528c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x875290: cmp             SP, x16
    //     0x875294: b.ls            #0x8753fc
    // 0x875298: r16 = Instance_FloatingCursorDragState
    //     0x875298: ldr             x16, [PP, #0x52e0]  ; [pp+0x52e0] Obj!FloatingCursorDragState@12c3781
    // 0x87529c: cmp             w4, w16
    // 0x8752a0: b.ne            #0x8753d0
    // 0x8752a4: r0 = LoadClassIdInstr(r3)
    //     0x8752a4: ldur            x0, [x3, #-1]
    //     0x8752a8: ubfx            x0, x0, #0xc, #0x14
    // 0x8752ac: mov             x1, x3
    // 0x8752b0: r2 = "X"
    //     0x8752b0: ldr             x2, [PP, #0x5b40]  ; [pp+0x5b40] "X"
    // 0x8752b4: r0 = GDT[cid_x0 + -0xd48]()
    //     0x8752b4: sub             lr, x0, #0xd48
    //     0x8752b8: ldr             lr, [x21, lr, lsl #3]
    //     0x8752bc: blr             lr
    // 0x8752c0: mov             x3, x0
    // 0x8752c4: r2 = Null
    //     0x8752c4: mov             x2, NULL
    // 0x8752c8: r1 = Null
    //     0x8752c8: mov             x1, NULL
    // 0x8752cc: stur            x3, [fp, #-0x18]
    // 0x8752d0: branchIfSmi(r0, 0x8752f4)
    //     0x8752d0: tbz             w0, #0, #0x8752f4
    // 0x8752d4: r4 = LoadClassIdInstr(r0)
    //     0x8752d4: ldur            x4, [x0, #-1]
    //     0x8752d8: ubfx            x4, x4, #0xc, #0x14
    // 0x8752dc: sub             x4, x4, #0x3c
    // 0x8752e0: cmp             x4, #2
    // 0x8752e4: b.ls            #0x8752f4
    // 0x8752e8: r8 = num
    //     0x8752e8: ldr             x8, [PP, #0x398]  ; [pp+0x398] Type: num
    // 0x8752ec: r3 = Null
    //     0x8752ec: ldr             x3, [PP, #0x5b48]  ; [pp+0x5b48] Null
    // 0x8752f0: r0 = num()
    //     0x8752f0: bl              #0x13ee9b0  ; IsType_num_Stub
    // 0x8752f4: ldur            x0, [fp, #-0x18]
    // 0x8752f8: r1 = 60
    //     0x8752f8: mov             x1, #0x3c
    // 0x8752fc: branchIfSmi(r0, 0x875308)
    //     0x8752fc: tbz             w0, #0, #0x875308
    // 0x875300: r1 = LoadClassIdInstr(r0)
    //     0x875300: ldur            x1, [x0, #-1]
    //     0x875304: ubfx            x1, x1, #0xc, #0x14
    // 0x875308: str             x0, [SP]
    // 0x87530c: mov             x0, x1
    // 0x875310: r0 = GDT[cid_x0 + -0xffd]()
    //     0x875310: sub             lr, x0, #0xffd
    //     0x875314: ldr             lr, [x21, lr, lsl #3]
    //     0x875318: blr             lr
    // 0x87531c: mov             x3, x0
    // 0x875320: ldur            x1, [fp, #-0x10]
    // 0x875324: stur            x3, [fp, #-0x18]
    // 0x875328: r0 = LoadClassIdInstr(r1)
    //     0x875328: ldur            x0, [x1, #-1]
    //     0x87532c: ubfx            x0, x0, #0xc, #0x14
    // 0x875330: r2 = "Y"
    //     0x875330: ldr             x2, [PP, #0x5b58]  ; [pp+0x5b58] "Y"
    // 0x875334: r0 = GDT[cid_x0 + -0xd48]()
    //     0x875334: sub             lr, x0, #0xd48
    //     0x875338: ldr             lr, [x21, lr, lsl #3]
    //     0x87533c: blr             lr
    // 0x875340: mov             x3, x0
    // 0x875344: r2 = Null
    //     0x875344: mov             x2, NULL
    // 0x875348: r1 = Null
    //     0x875348: mov             x1, NULL
    // 0x87534c: stur            x3, [fp, #-0x10]
    // 0x875350: branchIfSmi(r0, 0x875374)
    //     0x875350: tbz             w0, #0, #0x875374
    // 0x875354: r4 = LoadClassIdInstr(r0)
    //     0x875354: ldur            x4, [x0, #-1]
    //     0x875358: ubfx            x4, x4, #0xc, #0x14
    // 0x87535c: sub             x4, x4, #0x3c
    // 0x875360: cmp             x4, #2
    // 0x875364: b.ls            #0x875374
    // 0x875368: r8 = num
    //     0x875368: ldr             x8, [PP, #0x398]  ; [pp+0x398] Type: num
    // 0x87536c: r3 = Null
    //     0x87536c: ldr             x3, [PP, #0x5b60]  ; [pp+0x5b60] Null
    // 0x875370: r0 = num()
    //     0x875370: bl              #0x13ee9b0  ; IsType_num_Stub
    // 0x875374: ldur            x0, [fp, #-0x10]
    // 0x875378: r1 = 60
    //     0x875378: mov             x1, #0x3c
    // 0x87537c: branchIfSmi(r0, 0x875388)
    //     0x87537c: tbz             w0, #0, #0x875388
    // 0x875380: r1 = LoadClassIdInstr(r0)
    //     0x875380: ldur            x1, [x0, #-1]
    //     0x875384: ubfx            x1, x1, #0xc, #0x14
    // 0x875388: str             x0, [SP]
    // 0x87538c: mov             x0, x1
    // 0x875390: r0 = GDT[cid_x0 + -0xffd]()
    //     0x875390: sub             lr, x0, #0xffd
    //     0x875394: ldr             lr, [x21, lr, lsl #3]
    //     0x875398: blr             lr
    // 0x87539c: mov             x1, x0
    // 0x8753a0: ldur            x0, [fp, #-0x18]
    // 0x8753a4: stur            x1, [fp, #-0x10]
    // 0x8753a8: LoadField: d0 = r0->field_7
    //     0x8753a8: ldur            d0, [x0, #7]
    // 0x8753ac: stur            d0, [fp, #-0x20]
    // 0x8753b0: r0 = Offset()
    //     0x8753b0: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x8753b4: ldur            d0, [fp, #-0x20]
    // 0x8753b8: StoreField: r0->field_7 = d0
    //     0x8753b8: stur            d0, [x0, #7]
    // 0x8753bc: ldur            x1, [fp, #-0x10]
    // 0x8753c0: LoadField: d0 = r1->field_7
    //     0x8753c0: ldur            d0, [x1, #7]
    // 0x8753c4: StoreField: r0->field_f = d0
    //     0x8753c4: stur            d0, [x0, #0xf]
    // 0x8753c8: mov             x1, x0
    // 0x8753cc: b               #0x8753d4
    // 0x8753d0: r1 = Instance_Offset
    //     0x8753d0: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x8753d4: ldur            x0, [fp, #-8]
    // 0x8753d8: stur            x1, [fp, #-0x10]
    // 0x8753dc: r0 = RawFloatingCursorPoint()
    //     0x8753dc: bl              #0x875404  ; AllocateRawFloatingCursorPointStub -> RawFloatingCursorPoint (size=0x14)
    // 0x8753e0: ldur            x1, [fp, #-0x10]
    // 0x8753e4: StoreField: r0->field_7 = r1
    //     0x8753e4: stur            w1, [x0, #7]
    // 0x8753e8: ldur            x1, [fp, #-8]
    // 0x8753ec: StoreField: r0->field_f = r1
    //     0x8753ec: stur            w1, [x0, #0xf]
    // 0x8753f0: LeaveFrame
    //     0x8753f0: mov             SP, fp
    //     0x8753f4: ldp             fp, lr, [SP], #0x10
    // 0x8753f8: ret
    //     0x8753f8: ret             
    // 0x8753fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8753fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x875400: b               #0x875298
  }
  static _ _toTextCursorAction(/* No info */) {
    // ** addr: 0x875410, size: 0x11c
    // 0x875410: EnterFrame
    //     0x875410: stp             fp, lr, [SP, #-0x10]!
    //     0x875414: mov             fp, SP
    // 0x875418: AllocStack(0x20)
    //     0x875418: sub             SP, SP, #0x20
    // 0x87541c: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0x87541c: stur            x1, [fp, #-8]
    // 0x875420: CheckStackOverflow
    //     0x875420: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x875424: cmp             SP, x16
    //     0x875428: b.ls            #0x875524
    // 0x87542c: r16 = "FloatingCursorDragState.start"
    //     0x87542c: ldr             x16, [PP, #0x5b70]  ; [pp+0x5b70] "FloatingCursorDragState.start"
    // 0x875430: stp             x1, x16, [SP]
    // 0x875434: r0 = ==()
    //     0x875434: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x875438: tbnz            w0, #4, #0x875444
    // 0x87543c: r0 = Instance_FloatingCursorDragState
    //     0x87543c: ldr             x0, [PP, #0x5b78]  ; [pp+0x5b78] Obj!FloatingCursorDragState@12c37a1
    // 0x875440: b               #0x875478
    // 0x875444: r16 = "FloatingCursorDragState.update"
    //     0x875444: ldr             x16, [PP, #0x5b80]  ; [pp+0x5b80] "FloatingCursorDragState.update"
    // 0x875448: ldur            lr, [fp, #-8]
    // 0x87544c: stp             lr, x16, [SP]
    // 0x875450: r0 = ==()
    //     0x875450: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x875454: tbnz            w0, #4, #0x875460
    // 0x875458: r0 = Instance_FloatingCursorDragState
    //     0x875458: ldr             x0, [PP, #0x52e0]  ; [pp+0x52e0] Obj!FloatingCursorDragState@12c3781
    // 0x87545c: b               #0x875478
    // 0x875460: r16 = "FloatingCursorDragState.end"
    //     0x875460: ldr             x16, [PP, #0x5b88]  ; [pp+0x5b88] "FloatingCursorDragState.end"
    // 0x875464: ldur            lr, [fp, #-8]
    // 0x875468: stp             lr, x16, [SP]
    // 0x87546c: r0 = ==()
    //     0x87546c: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x875470: tbnz            w0, #4, #0x875484
    // 0x875474: r0 = Instance_FloatingCursorDragState
    //     0x875474: ldr             x0, [PP, #0x52a0]  ; [pp+0x52a0] Obj!FloatingCursorDragState@12c3761
    // 0x875478: LeaveFrame
    //     0x875478: mov             SP, fp
    //     0x87547c: ldp             fp, lr, [SP], #0x10
    // 0x875480: ret
    //     0x875480: ret             
    // 0x875484: ldur            x0, [fp, #-8]
    // 0x875488: r1 = Null
    //     0x875488: mov             x1, NULL
    // 0x87548c: r2 = 4
    //     0x87548c: mov             x2, #4
    // 0x875490: r0 = AllocateArray()
    //     0x875490: bl              #0x13df928  ; AllocateArrayStub
    // 0x875494: r16 = "Unknown text cursor action: "
    //     0x875494: ldr             x16, [PP, #0x5b90]  ; [pp+0x5b90] "Unknown text cursor action: "
    // 0x875498: StoreField: r0->field_f = r16
    //     0x875498: stur            w16, [x0, #0xf]
    // 0x87549c: ldur            x1, [fp, #-8]
    // 0x8754a0: StoreField: r0->field_13 = r1
    //     0x8754a0: stur            w1, [x0, #0x13]
    // 0x8754a4: str             x0, [SP]
    // 0x8754a8: r0 = _interpolate()
    //     0x8754a8: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x8754ac: r1 = <List<Object>>
    //     0x8754ac: ldr             x1, [PP, #0x860]  ; [pp+0x860] TypeArguments: <List<Object>>
    // 0x8754b0: stur            x0, [fp, #-8]
    // 0x8754b4: r0 = ErrorSummary()
    //     0x8754b4: bl              #0x84896c  ; AllocateErrorSummaryStub -> ErrorSummary (size=0x2c)
    // 0x8754b8: mov             x1, x0
    // 0x8754bc: ldur            x2, [fp, #-8]
    // 0x8754c0: r3 = Instance_DiagnosticLevel
    //     0x8754c0: ldr             x3, [PP, #0x22b0]  ; [pp+0x22b0] Obj!DiagnosticLevel@12c5f61
    // 0x8754c4: stur            x0, [fp, #-8]
    // 0x8754c8: r0 = _ErrorDiagnostic()
    //     0x8754c8: bl              #0x829bec  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0x8754cc: r1 = Null
    //     0x8754cc: mov             x1, NULL
    // 0x8754d0: r2 = 2
    //     0x8754d0: mov             x2, #2
    // 0x8754d4: r0 = AllocateArray()
    //     0x8754d4: bl              #0x13df928  ; AllocateArrayStub
    // 0x8754d8: mov             x2, x0
    // 0x8754dc: ldur            x0, [fp, #-8]
    // 0x8754e0: stur            x2, [fp, #-0x10]
    // 0x8754e4: StoreField: r2->field_f = r0
    //     0x8754e4: stur            w0, [x2, #0xf]
    // 0x8754e8: r1 = <DiagnosticsNode>
    //     0x8754e8: ldr             x1, [PP, #0x1ea8]  ; [pp+0x1ea8] TypeArguments: <DiagnosticsNode>
    // 0x8754ec: r0 = AllocateGrowableArray()
    //     0x8754ec: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x8754f0: mov             x1, x0
    // 0x8754f4: ldur            x0, [fp, #-0x10]
    // 0x8754f8: stur            x1, [fp, #-8]
    // 0x8754fc: StoreField: r1->field_f = r0
    //     0x8754fc: stur            w0, [x1, #0xf]
    // 0x875500: r0 = 2
    //     0x875500: mov             x0, #2
    // 0x875504: StoreField: r1->field_b = r0
    //     0x875504: stur            w0, [x1, #0xb]
    // 0x875508: r0 = FlutterError()
    //     0x875508: bl              #0x8488dc  ; AllocateFlutterErrorStub -> FlutterError (size=0x10)
    // 0x87550c: mov             x1, x0
    // 0x875510: ldur            x0, [fp, #-8]
    // 0x875514: StoreField: r1->field_b = r0
    //     0x875514: stur            w0, [x1, #0xb]
    // 0x875518: mov             x0, x1
    // 0x87551c: r0 = Throw()
    //     0x87551c: bl              #0x13ddb2c  ; ThrowStub
    // 0x875520: brk             #0
    // 0x875524: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x875524: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x875528: b               #0x87542c
  }
  static _ _toTextInputAction(/* No info */) {
    // ** addr: 0x876040, size: 0x234
    // 0x876040: EnterFrame
    //     0x876040: stp             fp, lr, [SP, #-0x10]!
    //     0x876044: mov             fp, SP
    // 0x876048: AllocStack(0x20)
    //     0x876048: sub             SP, SP, #0x20
    // 0x87604c: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0x87604c: stur            x1, [fp, #-8]
    // 0x876050: CheckStackOverflow
    //     0x876050: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x876054: cmp             SP, x16
    //     0x876058: b.ls            #0x87626c
    // 0x87605c: r16 = "TextInputAction.none"
    //     0x87605c: ldr             x16, [PP, #0x5d60]  ; [pp+0x5d60] "TextInputAction.none"
    // 0x876060: stp             x1, x16, [SP]
    // 0x876064: r0 = ==()
    //     0x876064: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x876068: tbnz            w0, #4, #0x876074
    // 0x87606c: r0 = Instance_TextInputAction
    //     0x87606c: ldr             x0, [PP, #0x5d68]  ; [pp+0x5d68] Obj!TextInputAction@12c3961
    // 0x876070: b               #0x8761c0
    // 0x876074: r16 = "TextInputAction.unspecified"
    //     0x876074: ldr             x16, [PP, #0x5d70]  ; [pp+0x5d70] "TextInputAction.unspecified"
    // 0x876078: ldur            lr, [fp, #-8]
    // 0x87607c: stp             lr, x16, [SP]
    // 0x876080: r0 = ==()
    //     0x876080: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x876084: tbnz            w0, #4, #0x876090
    // 0x876088: r0 = Instance_TextInputAction
    //     0x876088: ldr             x0, [PP, #0x5d78]  ; [pp+0x5d78] Obj!TextInputAction@12c3941
    // 0x87608c: b               #0x8761c0
    // 0x876090: r16 = "TextInputAction.go"
    //     0x876090: ldr             x16, [PP, #0x5d80]  ; [pp+0x5d80] "TextInputAction.go"
    // 0x876094: ldur            lr, [fp, #-8]
    // 0x876098: stp             lr, x16, [SP]
    // 0x87609c: r0 = ==()
    //     0x87609c: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x8760a0: tbnz            w0, #4, #0x8760ac
    // 0x8760a4: r0 = Instance_TextInputAction
    //     0x8760a4: ldr             x0, [PP, #0x5d88]  ; [pp+0x5d88] Obj!TextInputAction@12c3921
    // 0x8760a8: b               #0x8761c0
    // 0x8760ac: r16 = "TextInputAction.search"
    //     0x8760ac: ldr             x16, [PP, #0x5d90]  ; [pp+0x5d90] "TextInputAction.search"
    // 0x8760b0: ldur            lr, [fp, #-8]
    // 0x8760b4: stp             lr, x16, [SP]
    // 0x8760b8: r0 = ==()
    //     0x8760b8: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x8760bc: tbnz            w0, #4, #0x8760c8
    // 0x8760c0: r0 = Instance_TextInputAction
    //     0x8760c0: ldr             x0, [PP, #0x5d98]  ; [pp+0x5d98] Obj!TextInputAction@12c3901
    // 0x8760c4: b               #0x8761c0
    // 0x8760c8: r16 = "TextInputAction.send"
    //     0x8760c8: ldr             x16, [PP, #0x5da0]  ; [pp+0x5da0] "TextInputAction.send"
    // 0x8760cc: ldur            lr, [fp, #-8]
    // 0x8760d0: stp             lr, x16, [SP]
    // 0x8760d4: r0 = ==()
    //     0x8760d4: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x8760d8: tbnz            w0, #4, #0x8760e4
    // 0x8760dc: r0 = Instance_TextInputAction
    //     0x8760dc: ldr             x0, [PP, #0x5da8]  ; [pp+0x5da8] Obj!TextInputAction@12c38e1
    // 0x8760e0: b               #0x8761c0
    // 0x8760e4: r16 = "TextInputAction.next"
    //     0x8760e4: ldr             x16, [PP, #0x5db0]  ; [pp+0x5db0] "TextInputAction.next"
    // 0x8760e8: ldur            lr, [fp, #-8]
    // 0x8760ec: stp             lr, x16, [SP]
    // 0x8760f0: r0 = ==()
    //     0x8760f0: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x8760f4: tbnz            w0, #4, #0x876100
    // 0x8760f8: r0 = Instance_TextInputAction
    //     0x8760f8: ldr             x0, [PP, #0x5db8]  ; [pp+0x5db8] Obj!TextInputAction@12c38c1
    // 0x8760fc: b               #0x8761c0
    // 0x876100: r16 = "TextInputAction.previous"
    //     0x876100: ldr             x16, [PP, #0x5dc0]  ; [pp+0x5dc0] "TextInputAction.previous"
    // 0x876104: ldur            lr, [fp, #-8]
    // 0x876108: stp             lr, x16, [SP]
    // 0x87610c: r0 = ==()
    //     0x87610c: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x876110: tbnz            w0, #4, #0x87611c
    // 0x876114: r0 = Instance_TextInputAction
    //     0x876114: ldr             x0, [PP, #0x5dc8]  ; [pp+0x5dc8] Obj!TextInputAction@12c38a1
    // 0x876118: b               #0x8761c0
    // 0x87611c: r16 = "TextInputAction.continueAction"
    //     0x87611c: ldr             x16, [PP, #0x5dd0]  ; [pp+0x5dd0] "TextInputAction.continueAction"
    // 0x876120: ldur            lr, [fp, #-8]
    // 0x876124: stp             lr, x16, [SP]
    // 0x876128: r0 = ==()
    //     0x876128: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x87612c: tbnz            w0, #4, #0x876138
    // 0x876130: r0 = Instance_TextInputAction
    //     0x876130: ldr             x0, [PP, #0x5dd8]  ; [pp+0x5dd8] Obj!TextInputAction@12c3881
    // 0x876134: b               #0x8761c0
    // 0x876138: r16 = "TextInputAction.join"
    //     0x876138: ldr             x16, [PP, #0x5de0]  ; [pp+0x5de0] "TextInputAction.join"
    // 0x87613c: ldur            lr, [fp, #-8]
    // 0x876140: stp             lr, x16, [SP]
    // 0x876144: r0 = ==()
    //     0x876144: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x876148: tbnz            w0, #4, #0x876154
    // 0x87614c: r0 = Instance_TextInputAction
    //     0x87614c: ldr             x0, [PP, #0x5de8]  ; [pp+0x5de8] Obj!TextInputAction@12c3861
    // 0x876150: b               #0x8761c0
    // 0x876154: r16 = "TextInputAction.route"
    //     0x876154: ldr             x16, [PP, #0x5df0]  ; [pp+0x5df0] "TextInputAction.route"
    // 0x876158: ldur            lr, [fp, #-8]
    // 0x87615c: stp             lr, x16, [SP]
    // 0x876160: r0 = ==()
    //     0x876160: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x876164: tbnz            w0, #4, #0x876170
    // 0x876168: r0 = Instance_TextInputAction
    //     0x876168: ldr             x0, [PP, #0x5df8]  ; [pp+0x5df8] Obj!TextInputAction@12c3841
    // 0x87616c: b               #0x8761c0
    // 0x876170: r16 = "TextInputAction.emergencyCall"
    //     0x876170: ldr             x16, [PP, #0x5e00]  ; [pp+0x5e00] "TextInputAction.emergencyCall"
    // 0x876174: ldur            lr, [fp, #-8]
    // 0x876178: stp             lr, x16, [SP]
    // 0x87617c: r0 = ==()
    //     0x87617c: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x876180: tbnz            w0, #4, #0x87618c
    // 0x876184: r0 = Instance_TextInputAction
    //     0x876184: ldr             x0, [PP, #0x5e08]  ; [pp+0x5e08] Obj!TextInputAction@12c3821
    // 0x876188: b               #0x8761c0
    // 0x87618c: r16 = "TextInputAction.done"
    //     0x87618c: ldr             x16, [PP, #0x5e10]  ; [pp+0x5e10] "TextInputAction.done"
    // 0x876190: ldur            lr, [fp, #-8]
    // 0x876194: stp             lr, x16, [SP]
    // 0x876198: r0 = ==()
    //     0x876198: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x87619c: tbnz            w0, #4, #0x8761a8
    // 0x8761a0: r0 = Instance_TextInputAction
    //     0x8761a0: ldr             x0, [PP, #0x5e18]  ; [pp+0x5e18] Obj!TextInputAction@12c3801
    // 0x8761a4: b               #0x8761c0
    // 0x8761a8: r16 = "TextInputAction.newline"
    //     0x8761a8: ldr             x16, [PP, #0x5e20]  ; [pp+0x5e20] "TextInputAction.newline"
    // 0x8761ac: ldur            lr, [fp, #-8]
    // 0x8761b0: stp             lr, x16, [SP]
    // 0x8761b4: r0 = ==()
    //     0x8761b4: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x8761b8: tbnz            w0, #4, #0x8761cc
    // 0x8761bc: r0 = Instance_TextInputAction
    //     0x8761bc: ldr             x0, [PP, #0x5e28]  ; [pp+0x5e28] Obj!TextInputAction@12c37e1
    // 0x8761c0: LeaveFrame
    //     0x8761c0: mov             SP, fp
    //     0x8761c4: ldp             fp, lr, [SP], #0x10
    // 0x8761c8: ret
    //     0x8761c8: ret             
    // 0x8761cc: ldur            x0, [fp, #-8]
    // 0x8761d0: r1 = Null
    //     0x8761d0: mov             x1, NULL
    // 0x8761d4: r2 = 4
    //     0x8761d4: mov             x2, #4
    // 0x8761d8: r0 = AllocateArray()
    //     0x8761d8: bl              #0x13df928  ; AllocateArrayStub
    // 0x8761dc: r16 = "Unknown text input action: "
    //     0x8761dc: ldr             x16, [PP, #0x5e30]  ; [pp+0x5e30] "Unknown text input action: "
    // 0x8761e0: StoreField: r0->field_f = r16
    //     0x8761e0: stur            w16, [x0, #0xf]
    // 0x8761e4: ldur            x1, [fp, #-8]
    // 0x8761e8: StoreField: r0->field_13 = r1
    //     0x8761e8: stur            w1, [x0, #0x13]
    // 0x8761ec: str             x0, [SP]
    // 0x8761f0: r0 = _interpolate()
    //     0x8761f0: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x8761f4: r1 = <List<Object>>
    //     0x8761f4: ldr             x1, [PP, #0x860]  ; [pp+0x860] TypeArguments: <List<Object>>
    // 0x8761f8: stur            x0, [fp, #-8]
    // 0x8761fc: r0 = ErrorSummary()
    //     0x8761fc: bl              #0x84896c  ; AllocateErrorSummaryStub -> ErrorSummary (size=0x2c)
    // 0x876200: mov             x1, x0
    // 0x876204: ldur            x2, [fp, #-8]
    // 0x876208: r3 = Instance_DiagnosticLevel
    //     0x876208: ldr             x3, [PP, #0x22b0]  ; [pp+0x22b0] Obj!DiagnosticLevel@12c5f61
    // 0x87620c: stur            x0, [fp, #-8]
    // 0x876210: r0 = _ErrorDiagnostic()
    //     0x876210: bl              #0x829bec  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0x876214: r1 = Null
    //     0x876214: mov             x1, NULL
    // 0x876218: r2 = 2
    //     0x876218: mov             x2, #2
    // 0x87621c: r0 = AllocateArray()
    //     0x87621c: bl              #0x13df928  ; AllocateArrayStub
    // 0x876220: mov             x2, x0
    // 0x876224: ldur            x0, [fp, #-8]
    // 0x876228: stur            x2, [fp, #-0x10]
    // 0x87622c: StoreField: r2->field_f = r0
    //     0x87622c: stur            w0, [x2, #0xf]
    // 0x876230: r1 = <DiagnosticsNode>
    //     0x876230: ldr             x1, [PP, #0x1ea8]  ; [pp+0x1ea8] TypeArguments: <DiagnosticsNode>
    // 0x876234: r0 = AllocateGrowableArray()
    //     0x876234: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x876238: mov             x1, x0
    // 0x87623c: ldur            x0, [fp, #-0x10]
    // 0x876240: stur            x1, [fp, #-8]
    // 0x876244: StoreField: r1->field_f = r0
    //     0x876244: stur            w0, [x1, #0xf]
    // 0x876248: r0 = 2
    //     0x876248: mov             x0, #2
    // 0x87624c: StoreField: r1->field_b = r0
    //     0x87624c: stur            w0, [x1, #0xb]
    // 0x876250: r0 = FlutterError()
    //     0x876250: bl              #0x8488dc  ; AllocateFlutterErrorStub -> FlutterError (size=0x10)
    // 0x876254: mov             x1, x0
    // 0x876258: ldur            x0, [fp, #-8]
    // 0x87625c: StoreField: r1->field_b = r0
    //     0x87625c: stur            w0, [x1, #0xb]
    // 0x876260: mov             x0, x1
    // 0x876264: r0 = Throw()
    //     0x876264: bl              #0x13ddb2c  ; ThrowStub
    // 0x876268: brk             #0
    // 0x87626c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87626c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x876270: b               #0x87605c
  }
}

// class id: 2724, size: 0x2c, field offset: 0x8
class TextInput extends Object {

  static late final TextInput _instance; // offset: 0x67c
  late TextInputConfiguration _currentConfiguration; // offset: 0x18
  late MethodChannel _channel; // offset: 0x10

  static TextInput _instance() {
    // ** addr: 0x852de8, size: 0x40
    // 0x852de8: EnterFrame
    //     0x852de8: stp             fp, lr, [SP, #-0x10]!
    //     0x852dec: mov             fp, SP
    // 0x852df0: AllocStack(0x8)
    //     0x852df0: sub             SP, SP, #8
    // 0x852df4: CheckStackOverflow
    //     0x852df4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x852df8: cmp             SP, x16
    //     0x852dfc: b.ls            #0x852e20
    // 0x852e00: r0 = TextInput()
    //     0x852e00: bl              #0x87afb0  ; AllocateTextInputStub -> TextInput (size=0x2c)
    // 0x852e04: mov             x1, x0
    // 0x852e08: stur            x0, [fp, #-8]
    // 0x852e0c: r0 = TextInput._()
    //     0x852e0c: bl              #0x852e28  ; [package:flutter/src/services/text_input.dart] TextInput::TextInput._
    // 0x852e10: ldur            x0, [fp, #-8]
    // 0x852e14: LeaveFrame
    //     0x852e14: mov             SP, fp
    //     0x852e18: ldp             fp, lr, [SP], #0x10
    // 0x852e1c: ret
    //     0x852e1c: ret             
    // 0x852e20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x852e20: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x852e24: b               #0x852e00
  }
  _ TextInput._(/* No info */) {
    // ** addr: 0x852e28, size: 0x138
    // 0x852e28: EnterFrame
    //     0x852e28: stp             fp, lr, [SP, #-0x10]!
    //     0x852e2c: mov             fp, SP
    // 0x852e30: AllocStack(0x28)
    //     0x852e30: sub             SP, SP, #0x28
    // 0x852e34: ldr             x2, [THR, #0x90]  ; THR::object_sentinel
    // 0x852e38: r0 = false
    //     0x852e38: add             x0, NULL, #0x30  ; false
    // 0x852e3c: stur            x1, [fp, #-8]
    // 0x852e40: CheckStackOverflow
    //     0x852e40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x852e44: cmp             SP, x16
    //     0x852e48: b.ls            #0x852f58
    // 0x852e4c: StoreField: r1->field_f = r2
    //     0x852e4c: stur            w2, [x1, #0xf]
    // 0x852e50: ArrayStore: r1[0] = r2  ; List_4
    //     0x852e50: stur            w2, [x1, #0x17]
    // 0x852e54: StoreField: r1->field_23 = r0
    //     0x852e54: stur            w0, [x1, #0x23]
    // 0x852e58: StoreField: r1->field_27 = r0
    //     0x852e58: stur            w0, [x1, #0x27]
    // 0x852e5c: r0 = LoadStaticField(0x688)
    //     0x852e5c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x852e60: ldr             x0, [x0, #0xd10]
    // 0x852e64: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x852e68: cmp             w0, w16
    // 0x852e6c: b.ne            #0x852e78
    // 0x852e70: r2 = instance
    //     0x852e70: ldr             x2, [PP, #0x4398]  ; [pp+0x4398] Field <_PlatformTextInputControl@81206165.instance>: static late final (offset: 0x688)
    // 0x852e74: r0 = InitLateFinalStaticField()
    //     0x852e74: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x852e78: mov             x3, x0
    // 0x852e7c: ldur            x2, [fp, #-8]
    // 0x852e80: stur            x3, [fp, #-0x10]
    // 0x852e84: StoreField: r2->field_7 = r0
    //     0x852e84: stur            w0, [x2, #7]
    //     0x852e88: ldurb           w16, [x2, #-1]
    //     0x852e8c: ldurb           w17, [x0, #-1]
    //     0x852e90: and             x16, x17, x16, lsr #2
    //     0x852e94: tst             x16, HEAP, lsr #32
    //     0x852e98: b.eq            #0x852ea0
    //     0x852e9c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x852ea0: r1 = <TextInputControl>
    //     0x852ea0: ldr             x1, [PP, #0x43a0]  ; [pp+0x43a0] TypeArguments: <TextInputControl>
    // 0x852ea4: r0 = _Set()
    //     0x852ea4: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x852ea8: mov             x3, x0
    // 0x852eac: r0 = _Uint32List
    //     0x852eac: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0x852eb0: stur            x3, [fp, #-0x18]
    // 0x852eb4: StoreField: r3->field_1b = r0
    //     0x852eb4: stur            w0, [x3, #0x1b]
    // 0x852eb8: StoreField: r3->field_b = rZR
    //     0x852eb8: stur            wzr, [x3, #0xb]
    // 0x852ebc: r0 = const []
    //     0x852ebc: ldr             x0, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0x852ec0: StoreField: r3->field_f = r0
    //     0x852ec0: stur            w0, [x3, #0xf]
    // 0x852ec4: StoreField: r3->field_13 = rZR
    //     0x852ec4: stur            wzr, [x3, #0x13]
    // 0x852ec8: ArrayStore: r3[0] = rZR  ; List_4
    //     0x852ec8: stur            wzr, [x3, #0x17]
    // 0x852ecc: mov             x1, x3
    // 0x852ed0: ldur            x2, [fp, #-0x10]
    // 0x852ed4: r0 = add()
    //     0x852ed4: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x852ed8: ldur            x0, [fp, #-0x18]
    // 0x852edc: ldur            x2, [fp, #-8]
    // 0x852ee0: StoreField: r2->field_b = r0
    //     0x852ee0: stur            w0, [x2, #0xb]
    //     0x852ee4: ldurb           w16, [x2, #-1]
    //     0x852ee8: ldurb           w17, [x0, #-1]
    //     0x852eec: and             x16, x17, x16, lsr #2
    //     0x852ef0: tst             x16, HEAP, lsr #32
    //     0x852ef4: b.eq            #0x852efc
    //     0x852ef8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x852efc: r16 = <String, ScribbleClient>
    //     0x852efc: ldr             x16, [PP, #0x43a8]  ; [pp+0x43a8] TypeArguments: <String, ScribbleClient>
    // 0x852f00: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x852f04: stp             lr, x16, [SP]
    // 0x852f08: r0 = Map._fromLiteral()
    //     0x852f08: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x852f0c: ldur            x2, [fp, #-8]
    // 0x852f10: StoreField: r2->field_1f = r0
    //     0x852f10: stur            w0, [x2, #0x1f]
    //     0x852f14: ldurb           w16, [x2, #-1]
    //     0x852f18: ldurb           w17, [x0, #-1]
    //     0x852f1c: and             x16, x17, x16, lsr #2
    //     0x852f20: tst             x16, HEAP, lsr #32
    //     0x852f24: b.eq            #0x852f2c
    //     0x852f28: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x852f2c: r0 = Instance_OptionalMethodChannel
    //     0x852f2c: ldr             x0, [PP, #0x43b0]  ; [pp+0x43b0] Obj!OptionalMethodChannel@129bea1
    // 0x852f30: StoreField: r2->field_f = r0
    //     0x852f30: stur            w0, [x2, #0xf]
    // 0x852f34: r1 = Function '_loudlyHandleTextInputInvocation@81206165':.
    //     0x852f34: ldr             x1, [PP, #0x43b8]  ; [pp+0x43b8] AnonymousClosure: (0x852f60), in [package:flutter/src/services/text_input.dart] TextInput::_loudlyHandleTextInputInvocation (0x852f9c)
    // 0x852f38: r0 = AllocateClosure()
    //     0x852f38: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x852f3c: mov             x2, x0
    // 0x852f40: r1 = Instance_OptionalMethodChannel
    //     0x852f40: ldr             x1, [PP, #0x43b0]  ; [pp+0x43b0] Obj!OptionalMethodChannel@129bea1
    // 0x852f44: r0 = setMethodCallHandler()
    //     0x852f44: bl              #0x83aa3c  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::setMethodCallHandler
    // 0x852f48: r0 = Null
    //     0x852f48: mov             x0, NULL
    // 0x852f4c: LeaveFrame
    //     0x852f4c: mov             SP, fp
    //     0x852f50: ldp             fp, lr, [SP], #0x10
    // 0x852f54: ret
    //     0x852f54: ret             
    // 0x852f58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x852f58: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x852f5c: b               #0x852e4c
  }
  [closure] Future<dynamic> _loudlyHandleTextInputInvocation(dynamic, MethodCall) {
    // ** addr: 0x852f60, size: 0x3c
    // 0x852f60: EnterFrame
    //     0x852f60: stp             fp, lr, [SP, #-0x10]!
    //     0x852f64: mov             fp, SP
    // 0x852f68: ldr             x0, [fp, #0x18]
    // 0x852f6c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x852f6c: ldur            w1, [x0, #0x17]
    // 0x852f70: DecompressPointer r1
    //     0x852f70: add             x1, x1, HEAP, lsl #32
    // 0x852f74: CheckStackOverflow
    //     0x852f74: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x852f78: cmp             SP, x16
    //     0x852f7c: b.ls            #0x852f94
    // 0x852f80: ldr             x2, [fp, #0x10]
    // 0x852f84: r0 = _loudlyHandleTextInputInvocation()
    //     0x852f84: bl              #0x852f9c  ; [package:flutter/src/services/text_input.dart] TextInput::_loudlyHandleTextInputInvocation
    // 0x852f88: LeaveFrame
    //     0x852f88: mov             SP, fp
    //     0x852f8c: ldp             fp, lr, [SP], #0x10
    // 0x852f90: ret
    //     0x852f90: ret             
    // 0x852f94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x852f94: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x852f98: b               #0x852f80
  }
  _ _loudlyHandleTextInputInvocation(/* No info */) async {
    // ** addr: 0x852f9c, size: 0xf4
    // 0x852f9c: EnterFrame
    //     0x852f9c: stp             fp, lr, [SP, #-0x10]!
    //     0x852fa0: mov             fp, SP
    // 0x852fa4: AllocStack(0x88)
    //     0x852fa4: sub             SP, SP, #0x88
    // 0x852fa8: SetupParameters(TextInput this /* r1 => r1, fp-0x70 */, dynamic _ /* r2 => r2, fp-0x78 */)
    //     0x852fa8: stur            NULL, [fp, #-8]
    //     0x852fac: stur            x1, [fp, #-0x70]
    //     0x852fb0: stur            x2, [fp, #-0x78]
    // 0x852fb4: CheckStackOverflow
    //     0x852fb4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x852fb8: cmp             SP, x16
    //     0x852fbc: b.ls            #0x853088
    // 0x852fc0: r1 = 1
    //     0x852fc0: mov             x1, #1
    // 0x852fc4: r0 = AllocateContext()
    //     0x852fc4: bl              #0x13de838  ; AllocateContextStub
    // 0x852fc8: mov             x1, x0
    // 0x852fcc: ldur            x0, [fp, #-0x78]
    // 0x852fd0: stur            x1, [fp, #-0x80]
    // 0x852fd4: StoreField: r1->field_f = r0
    //     0x852fd4: stur            w0, [x1, #0xf]
    // 0x852fd8: InitAsync() -> Future
    //     0x852fd8: mov             x0, NULL
    //     0x852fdc: bl              #0x7f5e44  ; InitAsyncStub
    // 0x852fe0: ldur            x0, [fp, #-0x80]
    // 0x852fe4: LoadField: r2 = r0->field_f
    //     0x852fe4: ldur            w2, [x0, #0xf]
    // 0x852fe8: DecompressPointer r2
    //     0x852fe8: add             x2, x2, HEAP, lsl #32
    // 0x852fec: ldur            x1, [fp, #-0x70]
    // 0x852ff0: r0 = _handleTextInputInvocation()
    //     0x852ff0: bl              #0x853158  ; [package:flutter/src/services/text_input.dart] TextInput::_handleTextInputInvocation
    // 0x852ff4: mov             x1, x0
    // 0x852ff8: stur            x1, [fp, #-0x78]
    // 0x852ffc: r0 = Await()
    //     0x852ffc: bl              #0x7f5c00  ; AwaitStub
    // 0x853000: r0 = ReturnAsync()
    //     0x853000: b               #0x82fdf0  ; ReturnAsyncStub
    // 0x853004: sub             SP, fp, #0x88
    // 0x853008: ldur            x3, [fp, #-0x80]
    // 0x85300c: mov             x4, x0
    // 0x853010: stur            x0, [fp, #-0x70]
    // 0x853014: mov             x0, x1
    // 0x853018: stur            x1, [fp, #-0x78]
    // 0x85301c: r1 = Null
    //     0x85301c: mov             x1, NULL
    // 0x853020: r2 = 4
    //     0x853020: mov             x2, #4
    // 0x853024: r0 = AllocateArray()
    //     0x853024: bl              #0x13df928  ; AllocateArrayStub
    // 0x853028: r16 = "during method call "
    //     0x853028: ldr             x16, [PP, #0x43c0]  ; [pp+0x43c0] "during method call "
    // 0x85302c: StoreField: r0->field_f = r16
    //     0x85302c: stur            w16, [x0, #0xf]
    // 0x853030: ldur            x2, [fp, #-0x80]
    // 0x853034: LoadField: r1 = r2->field_f
    //     0x853034: ldur            w1, [x2, #0xf]
    // 0x853038: DecompressPointer r1
    //     0x853038: add             x1, x1, HEAP, lsl #32
    // 0x85303c: LoadField: r3 = r1->field_7
    //     0x85303c: ldur            w3, [x1, #7]
    // 0x853040: DecompressPointer r3
    //     0x853040: add             x3, x3, HEAP, lsl #32
    // 0x853044: StoreField: r0->field_13 = r3
    //     0x853044: stur            w3, [x0, #0x13]
    // 0x853048: str             x0, [SP]
    // 0x85304c: r0 = _interpolate()
    //     0x85304c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x853050: ldur            x2, [fp, #-0x80]
    // 0x853054: r1 = Function '<anonymous closure>':.
    //     0x853054: ldr             x1, [PP, #0x43c8]  ; [pp+0x43c8] AnonymousClosure: (0x87aef0), in [package:flutter/src/services/text_input.dart] TextInput::_loudlyHandleTextInputInvocation (0x852f9c)
    // 0x853058: stur            x0, [fp, #-0x80]
    // 0x85305c: r0 = AllocateClosure()
    //     0x85305c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x853060: str             x0, [SP]
    // 0x853064: ldur            x1, [fp, #-0x70]
    // 0x853068: ldur            x2, [fp, #-0x78]
    // 0x85306c: ldur            x3, [fp, #-0x80]
    // 0x853070: r4 = const [0, 0x4, 0x1, 0x4, null]
    //     0x853070: ldr             x4, [PP, #0x43d0]  ; [pp+0x43d0] List(5) [0, 0x4, 0x1, 0x4, Null]
    // 0x853074: r0 = _reportError()
    //     0x853074: bl              #0x853090  ; [package:flutter/src/services/text_input.dart] ::_reportError
    // 0x853078: ldur            x0, [fp, #-0x70]
    // 0x85307c: ldur            x1, [fp, #-0x78]
    // 0x853080: r0 = ReThrow()
    //     0x853080: bl              #0x13ddb00  ; ReThrowStub
    // 0x853084: brk             #0
    // 0x853088: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x853088: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x85308c: b               #0x852fc0
  }
  _ _handleTextInputInvocation(/* No info */) async {
    // ** addr: 0x853158, size: 0x1470
    // 0x853158: EnterFrame
    //     0x853158: stp             fp, lr, [SP, #-0x10]!
    //     0x85315c: mov             fp, SP
    // 0x853160: AllocStack(0x68)
    //     0x853160: sub             SP, SP, #0x68
    // 0x853164: SetupParameters(TextInput this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0x853164: stur            NULL, [fp, #-8]
    //     0x853168: stur            x1, [fp, #-0x10]
    //     0x85316c: stur            x2, [fp, #-0x18]
    // 0x853170: CheckStackOverflow
    //     0x853170: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x853174: cmp             SP, x16
    //     0x853178: b.ls            #0x854564
    // 0x85317c: r1 = 2
    //     0x85317c: mov             x1, #2
    // 0x853180: r0 = AllocateContext()
    //     0x853180: bl              #0x13de838  ; AllocateContextStub
    // 0x853184: mov             x2, x0
    // 0x853188: ldur            x1, [fp, #-0x10]
    // 0x85318c: stur            x2, [fp, #-0x20]
    // 0x853190: StoreField: r2->field_f = r1
    //     0x853190: stur            w1, [x2, #0xf]
    // 0x853194: InitAsync() -> Future
    //     0x853194: mov             x0, NULL
    //     0x853198: bl              #0x7f5e44  ; InitAsyncStub
    // 0x85319c: ldur            x0, [fp, #-0x18]
    // 0x8531a0: LoadField: r1 = r0->field_7
    //     0x8531a0: ldur            w1, [x0, #7]
    // 0x8531a4: DecompressPointer r1
    //     0x8531a4: add             x1, x1, HEAP, lsl #32
    // 0x8531a8: stur            x1, [fp, #-0x28]
    // 0x8531ac: r16 = "TextInputClient.focusElement"
    //     0x8531ac: ldr             x16, [PP, #0x43e0]  ; [pp+0x43e0] "TextInputClient.focusElement"
    // 0x8531b0: stp             x1, x16, [SP]
    // 0x8531b4: r0 = ==()
    //     0x8531b4: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x8531b8: tbnz            w0, #4, #0x8533a8
    // 0x8531bc: ldur            x3, [fp, #-0x10]
    // 0x8531c0: ldur            x0, [fp, #-0x18]
    // 0x8531c4: LoadField: r4 = r0->field_b
    //     0x8531c4: ldur            w4, [x0, #0xb]
    // 0x8531c8: DecompressPointer r4
    //     0x8531c8: add             x4, x4, HEAP, lsl #32
    // 0x8531cc: mov             x0, x4
    // 0x8531d0: stur            x4, [fp, #-0x30]
    // 0x8531d4: r2 = Null
    //     0x8531d4: mov             x2, NULL
    // 0x8531d8: r1 = Null
    //     0x8531d8: mov             x1, NULL
    // 0x8531dc: r4 = 60
    //     0x8531dc: mov             x4, #0x3c
    // 0x8531e0: branchIfSmi(r0, 0x8531ec)
    //     0x8531e0: tbz             w0, #0, #0x8531ec
    // 0x8531e4: r4 = LoadClassIdInstr(r0)
    //     0x8531e4: ldur            x4, [x0, #-1]
    //     0x8531e8: ubfx            x4, x4, #0xc, #0x14
    // 0x8531ec: sub             x4, x4, #0x5a
    // 0x8531f0: cmp             x4, #2
    // 0x8531f4: b.ls            #0x853204
    // 0x8531f8: r8 = List
    //     0x8531f8: ldr             x8, [PP, #0x30e8]  ; [pp+0x30e8] Type: List
    // 0x8531fc: r3 = Null
    //     0x8531fc: ldr             x3, [PP, #0x43e8]  ; [pp+0x43e8] Null
    // 0x853200: r0 = List()
    //     0x853200: bl              #0x13efaa0  ; IsType_List_Stub
    // 0x853204: ldur            x1, [fp, #-0x10]
    // 0x853208: LoadField: r2 = r1->field_1f
    //     0x853208: ldur            w2, [x1, #0x1f]
    // 0x85320c: DecompressPointer r2
    //     0x85320c: add             x2, x2, HEAP, lsl #32
    // 0x853210: ldur            x1, [fp, #-0x30]
    // 0x853214: stur            x2, [fp, #-0x38]
    // 0x853218: r0 = LoadClassIdInstr(r1)
    //     0x853218: ldur            x0, [x1, #-1]
    //     0x85321c: ubfx            x0, x0, #0xc, #0x14
    // 0x853220: stp             xzr, x1, [SP]
    // 0x853224: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x853224: sub             lr, x0, #0xdfd
    //     0x853228: ldr             lr, [x21, lr, lsl #3]
    //     0x85322c: blr             lr
    // 0x853230: ldur            x1, [fp, #-0x38]
    // 0x853234: mov             x2, x0
    // 0x853238: r0 = _getValueOrData()
    //     0x853238: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x85323c: mov             x1, x0
    // 0x853240: ldur            x0, [fp, #-0x38]
    // 0x853244: LoadField: r2 = r0->field_f
    //     0x853244: ldur            w2, [x0, #0xf]
    // 0x853248: DecompressPointer r2
    //     0x853248: add             x2, x2, HEAP, lsl #32
    // 0x85324c: cmp             w2, w1
    // 0x853250: b.ne            #0x853258
    // 0x853254: r1 = Null
    //     0x853254: mov             x1, NULL
    // 0x853258: stur            x1, [fp, #-0x38]
    // 0x85325c: cmp             w1, NULL
    // 0x853260: b.eq            #0x8533a0
    // 0x853264: ldur            x2, [fp, #-0x30]
    // 0x853268: r0 = LoadClassIdInstr(r2)
    //     0x853268: ldur            x0, [x2, #-1]
    //     0x85326c: ubfx            x0, x0, #0xc, #0x14
    // 0x853270: r16 = 2
    //     0x853270: mov             x16, #2
    // 0x853274: stp             x16, x2, [SP]
    // 0x853278: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x853278: sub             lr, x0, #0xdfd
    //     0x85327c: ldr             lr, [x21, lr, lsl #3]
    //     0x853280: blr             lr
    // 0x853284: mov             x3, x0
    // 0x853288: r2 = Null
    //     0x853288: mov             x2, NULL
    // 0x85328c: r1 = Null
    //     0x85328c: mov             x1, NULL
    // 0x853290: stur            x3, [fp, #-0x40]
    // 0x853294: branchIfSmi(r0, 0x8532b8)
    //     0x853294: tbz             w0, #0, #0x8532b8
    // 0x853298: r4 = LoadClassIdInstr(r0)
    //     0x853298: ldur            x4, [x0, #-1]
    //     0x85329c: ubfx            x4, x4, #0xc, #0x14
    // 0x8532a0: sub             x4, x4, #0x3c
    // 0x8532a4: cmp             x4, #2
    // 0x8532a8: b.ls            #0x8532b8
    // 0x8532ac: r8 = num
    //     0x8532ac: ldr             x8, [PP, #0x398]  ; [pp+0x398] Type: num
    // 0x8532b0: r3 = Null
    //     0x8532b0: ldr             x3, [PP, #0x43f8]  ; [pp+0x43f8] Null
    // 0x8532b4: r0 = num()
    //     0x8532b4: bl              #0x13ee9b0  ; IsType_num_Stub
    // 0x8532b8: ldur            x0, [fp, #-0x40]
    // 0x8532bc: r1 = 60
    //     0x8532bc: mov             x1, #0x3c
    // 0x8532c0: branchIfSmi(r0, 0x8532cc)
    //     0x8532c0: tbz             w0, #0, #0x8532cc
    // 0x8532c4: r1 = LoadClassIdInstr(r0)
    //     0x8532c4: ldur            x1, [x0, #-1]
    //     0x8532c8: ubfx            x1, x1, #0xc, #0x14
    // 0x8532cc: str             x0, [SP]
    // 0x8532d0: mov             x0, x1
    // 0x8532d4: r0 = GDT[cid_x0 + -0xffd]()
    //     0x8532d4: sub             lr, x0, #0xffd
    //     0x8532d8: ldr             lr, [x21, lr, lsl #3]
    //     0x8532dc: blr             lr
    // 0x8532e0: mov             x1, x0
    // 0x8532e4: ldur            x0, [fp, #-0x30]
    // 0x8532e8: stur            x1, [fp, #-0x40]
    // 0x8532ec: r2 = LoadClassIdInstr(r0)
    //     0x8532ec: ldur            x2, [x0, #-1]
    //     0x8532f0: ubfx            x2, x2, #0xc, #0x14
    // 0x8532f4: r16 = 4
    //     0x8532f4: mov             x16, #4
    // 0x8532f8: stp             x16, x0, [SP]
    // 0x8532fc: mov             x0, x2
    // 0x853300: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x853300: sub             lr, x0, #0xdfd
    //     0x853304: ldr             lr, [x21, lr, lsl #3]
    //     0x853308: blr             lr
    // 0x85330c: mov             x3, x0
    // 0x853310: r2 = Null
    //     0x853310: mov             x2, NULL
    // 0x853314: r1 = Null
    //     0x853314: mov             x1, NULL
    // 0x853318: stur            x3, [fp, #-0x30]
    // 0x85331c: branchIfSmi(r0, 0x853340)
    //     0x85331c: tbz             w0, #0, #0x853340
    // 0x853320: r4 = LoadClassIdInstr(r0)
    //     0x853320: ldur            x4, [x0, #-1]
    //     0x853324: ubfx            x4, x4, #0xc, #0x14
    // 0x853328: sub             x4, x4, #0x3c
    // 0x85332c: cmp             x4, #2
    // 0x853330: b.ls            #0x853340
    // 0x853334: r8 = num
    //     0x853334: ldr             x8, [PP, #0x398]  ; [pp+0x398] Type: num
    // 0x853338: r3 = Null
    //     0x853338: ldr             x3, [PP, #0x4408]  ; [pp+0x4408] Null
    // 0x85333c: r0 = num()
    //     0x85333c: bl              #0x13ee9b0  ; IsType_num_Stub
    // 0x853340: ldur            x0, [fp, #-0x30]
    // 0x853344: r1 = 60
    //     0x853344: mov             x1, #0x3c
    // 0x853348: branchIfSmi(r0, 0x853354)
    //     0x853348: tbz             w0, #0, #0x853354
    // 0x85334c: r1 = LoadClassIdInstr(r0)
    //     0x85334c: ldur            x1, [x0, #-1]
    //     0x853350: ubfx            x1, x1, #0xc, #0x14
    // 0x853354: str             x0, [SP]
    // 0x853358: mov             x0, x1
    // 0x85335c: r0 = GDT[cid_x0 + -0xffd]()
    //     0x85335c: sub             lr, x0, #0xffd
    //     0x853360: ldr             lr, [x21, lr, lsl #3]
    //     0x853364: blr             lr
    // 0x853368: mov             x1, x0
    // 0x85336c: ldur            x0, [fp, #-0x40]
    // 0x853370: stur            x1, [fp, #-0x30]
    // 0x853374: LoadField: d0 = r0->field_7
    //     0x853374: ldur            d0, [x0, #7]
    // 0x853378: stur            d0, [fp, #-0x50]
    // 0x85337c: r0 = Offset()
    //     0x85337c: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x853380: ldur            d0, [fp, #-0x50]
    // 0x853384: StoreField: r0->field_7 = d0
    //     0x853384: stur            d0, [x0, #7]
    // 0x853388: ldur            x1, [fp, #-0x30]
    // 0x85338c: LoadField: d0 = r1->field_7
    //     0x85338c: ldur            d0, [x1, #7]
    // 0x853390: StoreField: r0->field_f = d0
    //     0x853390: stur            d0, [x0, #0xf]
    // 0x853394: ldur            x1, [fp, #-0x38]
    // 0x853398: mov             x2, x0
    // 0x85339c: r0 = onScribbleFocus()
    //     0x85339c: bl              #0x87929c  ; [package:flutter/src/widgets/editable_text.dart] _ScribbleFocusableState::onScribbleFocus
    // 0x8533a0: r0 = Null
    //     0x8533a0: mov             x0, NULL
    // 0x8533a4: r0 = ReturnAsyncNotFuture()
    //     0x8533a4: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x8533a8: ldur            x1, [fp, #-0x10]
    // 0x8533ac: ldur            x0, [fp, #-0x18]
    // 0x8533b0: r16 = "TextInputClient.requestElementsInRect"
    //     0x8533b0: ldr             x16, [PP, #0x4418]  ; [pp+0x4418] "TextInputClient.requestElementsInRect"
    // 0x8533b4: ldur            lr, [fp, #-0x28]
    // 0x8533b8: stp             lr, x16, [SP]
    // 0x8533bc: r0 = ==()
    //     0x8533bc: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x8533c0: tbnz            w0, #4, #0x8535f4
    // 0x8533c4: ldur            x0, [fp, #-0x18]
    // 0x8533c8: LoadField: r3 = r0->field_b
    //     0x8533c8: ldur            w3, [x0, #0xb]
    // 0x8533cc: DecompressPointer r3
    //     0x8533cc: add             x3, x3, HEAP, lsl #32
    // 0x8533d0: mov             x0, x3
    // 0x8533d4: stur            x3, [fp, #-0x30]
    // 0x8533d8: r2 = Null
    //     0x8533d8: mov             x2, NULL
    // 0x8533dc: r1 = Null
    //     0x8533dc: mov             x1, NULL
    // 0x8533e0: r4 = 60
    //     0x8533e0: mov             x4, #0x3c
    // 0x8533e4: branchIfSmi(r0, 0x8533f0)
    //     0x8533e4: tbz             w0, #0, #0x8533f0
    // 0x8533e8: r4 = LoadClassIdInstr(r0)
    //     0x8533e8: ldur            x4, [x0, #-1]
    //     0x8533ec: ubfx            x4, x4, #0xc, #0x14
    // 0x8533f0: sub             x4, x4, #0x5a
    // 0x8533f4: cmp             x4, #2
    // 0x8533f8: b.ls            #0x853408
    // 0x8533fc: r8 = List
    //     0x8533fc: ldr             x8, [PP, #0x30e8]  ; [pp+0x30e8] Type: List
    // 0x853400: r3 = Null
    //     0x853400: ldr             x3, [PP, #0x4420]  ; [pp+0x4420] Null
    // 0x853404: r0 = List()
    //     0x853404: bl              #0x13efaa0  ; IsType_List_Stub
    // 0x853408: ldur            x0, [fp, #-0x30]
    // 0x85340c: r1 = LoadClassIdInstr(r0)
    //     0x85340c: ldur            x1, [x0, #-1]
    //     0x853410: ubfx            x1, x1, #0xc, #0x14
    // 0x853414: r16 = <num>
    //     0x853414: ldr             x16, [PP, #0x4430]  ; [pp+0x4430] TypeArguments: <num>
    // 0x853418: stp             x0, x16, [SP]
    // 0x85341c: mov             x0, x1
    // 0x853420: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x853420: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x853424: r0 = GDT[cid_x0 + 0x13106]()
    //     0x853424: mov             x17, #0x3106
    //     0x853428: movk            x17, #1, lsl #16
    //     0x85342c: add             lr, x0, x17
    //     0x853430: ldr             lr, [x21, lr, lsl #3]
    //     0x853434: blr             lr
    // 0x853438: r1 = Function '<anonymous closure>':.
    //     0x853438: ldr             x1, [PP, #0x4438]  ; [pp+0x4438] AnonymousClosure: (0x87ae9c), in [package:flutter/src/services/text_input.dart] TextInput::_handleTextInputInvocation (0x853158)
    // 0x85343c: r2 = Null
    //     0x85343c: mov             x2, NULL
    // 0x853440: stur            x0, [fp, #-0x30]
    // 0x853444: r0 = AllocateClosure()
    //     0x853444: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x853448: mov             x1, x0
    // 0x85344c: ldur            x0, [fp, #-0x30]
    // 0x853450: r2 = LoadClassIdInstr(r0)
    //     0x853450: ldur            x2, [x0, #-1]
    //     0x853454: ubfx            x2, x2, #0xc, #0x14
    // 0x853458: r16 = <double>
    //     0x853458: ldr             x16, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0x85345c: stp             x0, x16, [SP, #8]
    // 0x853460: str             x1, [SP]
    // 0x853464: mov             x0, x2
    // 0x853468: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x853468: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x85346c: r0 = GDT[cid_x0 + 0x12caa]()
    //     0x85346c: mov             x17, #0x2caa
    //     0x853470: movk            x17, #1, lsl #16
    //     0x853474: add             lr, x0, x17
    //     0x853478: ldr             lr, [x21, lr, lsl #3]
    //     0x85347c: blr             lr
    // 0x853480: mov             x3, x0
    // 0x853484: stur            x3, [fp, #-0x38]
    // 0x853488: LoadField: r4 = r3->field_7
    //     0x853488: ldur            w4, [x3, #7]
    // 0x85348c: DecompressPointer r4
    //     0x85348c: add             x4, x4, HEAP, lsl #32
    // 0x853490: mov             x0, x3
    // 0x853494: stur            x4, [fp, #-0x30]
    // 0x853498: r2 = Null
    //     0x853498: mov             x2, NULL
    // 0x85349c: r1 = Null
    //     0x85349c: mov             x1, NULL
    // 0x8534a0: cmp             w0, NULL
    // 0x8534a4: b.eq            #0x853530
    // 0x8534a8: branchIfSmi(r0, 0x853530)
    //     0x8534a8: tbz             w0, #0, #0x853530
    // 0x8534ac: r3 = LoadClassIdInstr(r0)
    //     0x8534ac: ldur            x3, [x0, #-1]
    //     0x8534b0: ubfx            x3, x3, #0xc, #0x14
    // 0x8534b4: r17 = 7724
    //     0x8534b4: mov             x17, #0x1e2c
    // 0x8534b8: cmp             x3, x17
    // 0x8534bc: b.eq            #0x853538
    // 0x8534c0: r4 = LoadClassIdInstr(r0)
    //     0x8534c0: ldur            x4, [x0, #-1]
    //     0x8534c4: ubfx            x4, x4, #0xc, #0x14
    // 0x8534c8: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x8534cc: ldr             x3, [x3, #0x18]
    // 0x8534d0: ldr             x3, [x3, x4, lsl #3]
    // 0x8534d4: LoadField: r3 = r3->field_2b
    //     0x8534d4: ldur            w3, [x3, #0x2b]
    // 0x8534d8: DecompressPointer r3
    //     0x8534d8: add             x3, x3, HEAP, lsl #32
    // 0x8534dc: cmp             w3, NULL
    // 0x8534e0: b.eq            #0x853530
    // 0x8534e4: LoadField: r3 = r3->field_f
    //     0x8534e4: ldur            w3, [x3, #0xf]
    // 0x8534e8: lsr             x3, x3, #3
    // 0x8534ec: r17 = 7724
    //     0x8534ec: mov             x17, #0x1e2c
    // 0x8534f0: cmp             x3, x17
    // 0x8534f4: b.eq            #0x853538
    // 0x8534f8: r3 = SubtypeTestCache
    //     0x8534f8: ldr             x3, [PP, #0x4448]  ; [pp+0x4448] SubtypeTestCache
    // 0x8534fc: r30 = Subtype1TestCacheStub
    //     0x8534fc: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x853500: LoadField: r30 = r30->field_7
    //     0x853500: ldur            lr, [lr, #7]
    // 0x853504: blr             lr
    // 0x853508: cmp             w7, NULL
    // 0x85350c: b.eq            #0x853518
    // 0x853510: tbnz            w7, #4, #0x853530
    // 0x853514: b               #0x853538
    // 0x853518: r8 = EfficientLengthIterable
    //     0x853518: ldr             x8, [PP, #0x4450]  ; [pp+0x4450] Type: EfficientLengthIterable
    // 0x85351c: r3 = SubtypeTestCache
    //     0x85351c: ldr             x3, [PP, #0x4458]  ; [pp+0x4458] SubtypeTestCache
    // 0x853520: r30 = InstanceOfStub
    //     0x853520: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x853524: LoadField: r30 = r30->field_7
    //     0x853524: ldur            lr, [lr, #7]
    // 0x853528: blr             lr
    // 0x85352c: b               #0x85353c
    // 0x853530: r0 = false
    //     0x853530: add             x0, NULL, #0x30  ; false
    // 0x853534: b               #0x85353c
    // 0x853538: r0 = true
    //     0x853538: add             x0, NULL, #0x20  ; true
    // 0x85353c: tbnz            w0, #4, #0x853550
    // 0x853540: ldur            x1, [fp, #-0x30]
    // 0x853544: ldur            x2, [fp, #-0x38]
    // 0x853548: r0 = _GrowableList._ofEfficientLengthIterable()
    //     0x853548: bl              #0x7d732c  ; [dart:core] _GrowableList::_GrowableList._ofEfficientLengthIterable
    // 0x85354c: b               #0x85355c
    // 0x853550: ldur            x1, [fp, #-0x30]
    // 0x853554: ldur            x2, [fp, #-0x38]
    // 0x853558: r0 = _GrowableList._ofOther()
    //     0x853558: bl              #0x7d94b4  ; [dart:core] _GrowableList::_GrowableList._ofOther
    // 0x85355c: ldur            x1, [fp, #-0x10]
    // 0x853560: ldur            x2, [fp, #-0x20]
    // 0x853564: StoreField: r2->field_13 = r0
    //     0x853564: stur            w0, [x2, #0x13]
    //     0x853568: ldurb           w16, [x2, #-1]
    //     0x85356c: ldurb           w17, [x0, #-1]
    //     0x853570: and             x16, x17, x16, lsr #2
    //     0x853574: tst             x16, HEAP, lsr #32
    //     0x853578: b.eq            #0x853580
    //     0x85357c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x853580: LoadField: r0 = r1->field_1f
    //     0x853580: ldur            w0, [x1, #0x1f]
    // 0x853584: DecompressPointer r0
    //     0x853584: add             x0, x0, HEAP, lsl #32
    // 0x853588: stur            x0, [fp, #-0x30]
    // 0x85358c: r1 = <String, ScribbleClient>
    //     0x85358c: ldr             x1, [PP, #0x43a8]  ; [pp+0x43a8] TypeArguments: <String, ScribbleClient>
    // 0x853590: r0 = _CompactKeysIterable()
    //     0x853590: bl              #0x8353d0  ; Allocate_CompactKeysIterableStub -> _CompactKeysIterable<X0> (size=0x10)
    // 0x853594: mov             x3, x0
    // 0x853598: ldur            x0, [fp, #-0x30]
    // 0x85359c: stur            x3, [fp, #-0x38]
    // 0x8535a0: StoreField: r3->field_b = r0
    //     0x8535a0: stur            w0, [x3, #0xb]
    // 0x8535a4: ldur            x2, [fp, #-0x20]
    // 0x8535a8: r1 = Function '<anonymous closure>':.
    //     0x8535a8: ldr             x1, [PP, #0x4460]  ; [pp+0x4460] AnonymousClosure: (0x87a8cc), in [package:flutter/src/services/text_input.dart] TextInput::_handleTextInputInvocation (0x853158)
    // 0x8535ac: r0 = AllocateClosure()
    //     0x8535ac: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8535b0: ldur            x1, [fp, #-0x38]
    // 0x8535b4: mov             x2, x0
    // 0x8535b8: r0 = where()
    //     0x8535b8: bl              #0xb92e4c  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::where
    // 0x8535bc: ldur            x2, [fp, #-0x20]
    // 0x8535c0: r1 = Function '<anonymous closure>':.
    //     0x8535c0: ldr             x1, [PP, #0x4468]  ; [pp+0x4468] AnonymousClosure: (0x87a534), in [package:flutter/src/services/text_input.dart] TextInput::_handleTextInputInvocation (0x853158)
    // 0x8535c4: stur            x0, [fp, #-0x20]
    // 0x8535c8: r0 = AllocateClosure()
    //     0x8535c8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8535cc: r16 = <List>
    //     0x8535cc: ldr             x16, [PP, #0x4470]  ; [pp+0x4470] TypeArguments: <List>
    // 0x8535d0: ldur            lr, [fp, #-0x20]
    // 0x8535d4: stp             lr, x16, [SP, #8]
    // 0x8535d8: str             x0, [SP]
    // 0x8535dc: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8535dc: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8535e0: r0 = map()
    //     0x8535e0: bl              #0xb00654  ; [dart:_internal] WhereIterable::map
    // 0x8535e4: mov             x1, x0
    // 0x8535e8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x8535e8: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x8535ec: r0 = toList()
    //     0x8535ec: bl              #0xb08ca4  ; [dart:core] Iterable::toList
    // 0x8535f0: r0 = ReturnAsyncNotFuture()
    //     0x8535f0: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x8535f4: ldur            x1, [fp, #-0x10]
    // 0x8535f8: ldur            x0, [fp, #-0x18]
    // 0x8535fc: r16 = "TextInputClient.scribbleInteractionBegan"
    //     0x8535fc: ldr             x16, [PP, #0x4478]  ; [pp+0x4478] "TextInputClient.scribbleInteractionBegan"
    // 0x853600: ldur            lr, [fp, #-0x28]
    // 0x853604: stp             lr, x16, [SP]
    // 0x853608: r0 = ==()
    //     0x853608: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x85360c: tbnz            w0, #4, #0x853624
    // 0x853610: ldur            x1, [fp, #-0x10]
    // 0x853614: r0 = true
    //     0x853614: add             x0, NULL, #0x20  ; true
    // 0x853618: StoreField: r1->field_23 = r0
    //     0x853618: stur            w0, [x1, #0x23]
    // 0x85361c: r0 = Null
    //     0x85361c: mov             x0, NULL
    // 0x853620: r0 = ReturnAsyncNotFuture()
    //     0x853620: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x853624: ldur            x1, [fp, #-0x10]
    // 0x853628: r16 = "TextInputClient.scribbleInteractionFinished"
    //     0x853628: ldr             x16, [PP, #0x4480]  ; [pp+0x4480] "TextInputClient.scribbleInteractionFinished"
    // 0x85362c: ldur            lr, [fp, #-0x28]
    // 0x853630: stp             lr, x16, [SP]
    // 0x853634: r0 = ==()
    //     0x853634: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x853638: tbnz            w0, #4, #0x853650
    // 0x85363c: ldur            x1, [fp, #-0x10]
    // 0x853640: r0 = false
    //     0x853640: add             x0, NULL, #0x30  ; false
    // 0x853644: StoreField: r1->field_23 = r0
    //     0x853644: stur            w0, [x1, #0x23]
    // 0x853648: r0 = Null
    //     0x853648: mov             x0, NULL
    // 0x85364c: r0 = ReturnAsyncNotFuture()
    //     0x85364c: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x853650: ldur            x1, [fp, #-0x10]
    // 0x853654: r0 = false
    //     0x853654: add             x0, NULL, #0x30  ; false
    // 0x853658: r16 = "TextInputClient.onFocusReceived"
    //     0x853658: ldr             x16, [PP, #0x4488]  ; [pp+0x4488] "TextInputClient.onFocusReceived"
    // 0x85365c: ldur            lr, [fp, #-0x28]
    // 0x853660: stp             lr, x16, [SP]
    // 0x853664: r0 = ==()
    //     0x853664: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x853668: tbnz            w0, #4, #0x853750
    // 0x85366c: ldur            x3, [fp, #-0x10]
    // 0x853670: ldur            x1, [fp, #-0x18]
    // 0x853674: LoadField: r4 = r1->field_b
    //     0x853674: ldur            w4, [x1, #0xb]
    // 0x853678: DecompressPointer r4
    //     0x853678: add             x4, x4, HEAP, lsl #32
    // 0x85367c: mov             x0, x4
    // 0x853680: stur            x4, [fp, #-0x20]
    // 0x853684: r2 = Null
    //     0x853684: mov             x2, NULL
    // 0x853688: r1 = Null
    //     0x853688: mov             x1, NULL
    // 0x85368c: r4 = 60
    //     0x85368c: mov             x4, #0x3c
    // 0x853690: branchIfSmi(r0, 0x85369c)
    //     0x853690: tbz             w0, #0, #0x85369c
    // 0x853694: r4 = LoadClassIdInstr(r0)
    //     0x853694: ldur            x4, [x0, #-1]
    //     0x853698: ubfx            x4, x4, #0xc, #0x14
    // 0x85369c: sub             x4, x4, #0x5a
    // 0x8536a0: cmp             x4, #2
    // 0x8536a4: b.ls            #0x8536b4
    // 0x8536a8: r8 = List
    //     0x8536a8: ldr             x8, [PP, #0x30e8]  ; [pp+0x30e8] Type: List
    // 0x8536ac: r3 = Null
    //     0x8536ac: ldr             x3, [PP, #0x4490]  ; [pp+0x4490] Null
    // 0x8536b0: r0 = List()
    //     0x8536b0: bl              #0x13efaa0  ; IsType_List_Stub
    // 0x8536b4: ldur            x0, [fp, #-0x20]
    // 0x8536b8: r1 = LoadClassIdInstr(r0)
    //     0x8536b8: ldur            x1, [x0, #-1]
    //     0x8536bc: ubfx            x1, x1, #0xc, #0x14
    // 0x8536c0: stp             xzr, x0, [SP]
    // 0x8536c4: mov             x0, x1
    // 0x8536c8: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x8536c8: sub             lr, x0, #0xdfd
    //     0x8536cc: ldr             lr, [x21, lr, lsl #3]
    //     0x8536d0: blr             lr
    // 0x8536d4: mov             x3, x0
    // 0x8536d8: r2 = Null
    //     0x8536d8: mov             x2, NULL
    // 0x8536dc: r1 = Null
    //     0x8536dc: mov             x1, NULL
    // 0x8536e0: stur            x3, [fp, #-0x20]
    // 0x8536e4: branchIfSmi(r0, 0x853708)
    //     0x8536e4: tbz             w0, #0, #0x853708
    // 0x8536e8: r4 = LoadClassIdInstr(r0)
    //     0x8536e8: ldur            x4, [x0, #-1]
    //     0x8536ec: ubfx            x4, x4, #0xc, #0x14
    // 0x8536f0: sub             x4, x4, #0x3c
    // 0x8536f4: cmp             x4, #1
    // 0x8536f8: b.ls            #0x853708
    // 0x8536fc: r8 = int
    //     0x8536fc: ldr             x8, [PP, #0x390]  ; [pp+0x390] Type: int
    // 0x853700: r3 = Null
    //     0x853700: ldr             x3, [PP, #0x44a0]  ; [pp+0x44a0] Null
    // 0x853704: r0 = int()
    //     0x853704: bl              #0x13ee980  ; IsType_int_Stub
    // 0x853708: ldur            x2, [fp, #-0x10]
    // 0x85370c: LoadField: r0 = r2->field_1b
    //     0x85370c: ldur            w0, [x2, #0x1b]
    // 0x853710: DecompressPointer r0
    //     0x853710: add             x0, x0, HEAP, lsl #32
    // 0x853714: cmp             w0, NULL
    // 0x853718: b.eq            #0x853748
    // 0x85371c: ldur            x1, [fp, #-0x20]
    // 0x853720: LoadField: r2 = r0->field_1b
    //     0x853720: ldur            x2, [x0, #0x1b]
    // 0x853724: r3 = LoadInt32Instr(r1)
    //     0x853724: sbfx            x3, x1, #1, #0x1f
    //     0x853728: tbz             w1, #0, #0x853730
    //     0x85372c: ldur            x3, [x1, #7]
    // 0x853730: cmp             x2, x3
    // 0x853734: b.ne            #0x853748
    // 0x853738: LoadField: r1 = r0->field_23
    //     0x853738: ldur            w1, [x0, #0x23]
    // 0x85373c: DecompressPointer r1
    //     0x85373c: add             x1, x1, HEAP, lsl #32
    // 0x853740: r0 = onFocusReceived()
    //     0x853740: bl              #0x8791c4  ; [package:flutter/src/widgets/editable_text.dart] EditableTextState::onFocusReceived
    // 0x853744: r0 = ReturnAsyncNotFuture()
    //     0x853744: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x853748: r0 = false
    //     0x853748: add             x0, NULL, #0x30  ; false
    // 0x85374c: r0 = ReturnAsyncNotFuture()
    //     0x85374c: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x853750: ldur            x2, [fp, #-0x10]
    // 0x853754: ldur            x1, [fp, #-0x18]
    // 0x853758: LoadField: r0 = r2->field_13
    //     0x853758: ldur            w0, [x2, #0x13]
    // 0x85375c: DecompressPointer r0
    //     0x85375c: add             x0, x0, HEAP, lsl #32
    // 0x853760: cmp             w0, NULL
    // 0x853764: b.ne            #0x853770
    // 0x853768: r0 = Null
    //     0x853768: mov             x0, NULL
    // 0x85376c: r0 = ReturnAsyncNotFuture()
    //     0x85376c: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x853770: ldur            x3, [fp, #-0x28]
    // 0x853774: r0 = LoadClassIdInstr(r3)
    //     0x853774: ldur            x0, [x3, #-1]
    //     0x853778: ubfx            x0, x0, #0xc, #0x14
    // 0x85377c: r16 = "TextInputClient.requestExistingInputState"
    //     0x85377c: ldr             x16, [PP, #0x44b0]  ; [pp+0x44b0] "TextInputClient.requestExistingInputState"
    // 0x853780: stp             x16, x3, [SP]
    // 0x853784: mov             lr, x0
    // 0x853788: ldr             lr, [x21, lr, lsl #3]
    // 0x85378c: blr             lr
    // 0x853790: tbnz            w0, #4, #0x8537fc
    // 0x853794: ldur            x0, [fp, #-0x10]
    // 0x853798: LoadField: r2 = r0->field_13
    //     0x853798: ldur            w2, [x0, #0x13]
    // 0x85379c: DecompressPointer r2
    //     0x85379c: add             x2, x2, HEAP, lsl #32
    // 0x8537a0: cmp             w2, NULL
    // 0x8537a4: b.eq            #0x85456c
    // 0x8537a8: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x8537a8: ldur            w3, [x0, #0x17]
    // 0x8537ac: DecompressPointer r3
    //     0x8537ac: add             x3, x3, HEAP, lsl #32
    // 0x8537b0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8537b4: cmp             w3, w16
    // 0x8537b8: b.eq            #0x854570
    // 0x8537bc: mov             x1, x0
    // 0x8537c0: r0 = _attach()
    //     0x8537c0: bl              #0x878560  ; [package:flutter/src/services/text_input.dart] TextInput::_attach
    // 0x8537c4: ldur            x0, [fp, #-0x10]
    // 0x8537c8: LoadField: r1 = r0->field_13
    //     0x8537c8: ldur            w1, [x0, #0x13]
    // 0x8537cc: DecompressPointer r1
    //     0x8537cc: add             x1, x1, HEAP, lsl #32
    // 0x8537d0: cmp             w1, NULL
    // 0x8537d4: b.eq            #0x854578
    // 0x8537d8: LoadField: r2 = r1->field_23
    //     0x8537d8: ldur            w2, [x1, #0x23]
    // 0x8537dc: DecompressPointer r2
    //     0x8537dc: add             x2, x2, HEAP, lsl #32
    // 0x8537e0: mov             x1, x2
    // 0x8537e4: r0 = _value()
    //     0x8537e4: bl              #0x878530  ; [package:flutter/src/widgets/editable_text.dart] EditableTextState::_value
    // 0x8537e8: ldur            x1, [fp, #-0x10]
    // 0x8537ec: mov             x2, x0
    // 0x8537f0: r0 = _setEditingState()
    //     0x8537f0: bl              #0x8783d8  ; [package:flutter/src/services/text_input.dart] TextInput::_setEditingState
    // 0x8537f4: r0 = Null
    //     0x8537f4: mov             x0, NULL
    // 0x8537f8: r0 = ReturnAsyncNotFuture()
    //     0x8537f8: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x8537fc: ldur            x0, [fp, #-0x18]
    // 0x853800: ldur            x3, [fp, #-0x28]
    // 0x853804: LoadField: r4 = r0->field_b
    //     0x853804: ldur            w4, [x0, #0xb]
    // 0x853808: DecompressPointer r4
    //     0x853808: add             x4, x4, HEAP, lsl #32
    // 0x85380c: mov             x0, x4
    // 0x853810: stur            x4, [fp, #-0x20]
    // 0x853814: r2 = Null
    //     0x853814: mov             x2, NULL
    // 0x853818: r1 = Null
    //     0x853818: mov             x1, NULL
    // 0x85381c: r4 = 60
    //     0x85381c: mov             x4, #0x3c
    // 0x853820: branchIfSmi(r0, 0x85382c)
    //     0x853820: tbz             w0, #0, #0x85382c
    // 0x853824: r4 = LoadClassIdInstr(r0)
    //     0x853824: ldur            x4, [x0, #-1]
    //     0x853828: ubfx            x4, x4, #0xc, #0x14
    // 0x85382c: sub             x4, x4, #0x5a
    // 0x853830: cmp             x4, #2
    // 0x853834: b.ls            #0x853844
    // 0x853838: r8 = List
    //     0x853838: ldr             x8, [PP, #0x30e8]  ; [pp+0x30e8] Type: List
    // 0x85383c: r3 = Null
    //     0x85383c: ldr             x3, [PP, #0x44b8]  ; [pp+0x44b8] Null
    // 0x853840: r0 = List()
    //     0x853840: bl              #0x13efaa0  ; IsType_List_Stub
    // 0x853844: ldur            x1, [fp, #-0x28]
    // 0x853848: r0 = LoadClassIdInstr(r1)
    //     0x853848: ldur            x0, [x1, #-1]
    //     0x85384c: ubfx            x0, x0, #0xc, #0x14
    // 0x853850: r16 = "TextInputClient.updateEditingStateWithTag"
    //     0x853850: ldr             x16, [PP, #0x44c8]  ; [pp+0x44c8] "TextInputClient.updateEditingStateWithTag"
    // 0x853854: stp             x16, x1, [SP]
    // 0x853858: mov             lr, x0
    // 0x85385c: ldr             lr, [x21, lr, lsl #3]
    // 0x853860: blr             lr
    // 0x853864: tbnz            w0, #4, #0x8539bc
    // 0x853868: ldur            x2, [fp, #-0x10]
    // 0x85386c: ldur            x1, [fp, #-0x20]
    // 0x853870: LoadField: r0 = r2->field_13
    //     0x853870: ldur            w0, [x2, #0x13]
    // 0x853874: DecompressPointer r0
    //     0x853874: add             x0, x0, HEAP, lsl #32
    // 0x853878: cmp             w0, NULL
    // 0x85387c: b.eq            #0x85457c
    // 0x853880: r0 = LoadClassIdInstr(r1)
    //     0x853880: ldur            x0, [x1, #-1]
    //     0x853884: ubfx            x0, x0, #0xc, #0x14
    // 0x853888: r16 = 2
    //     0x853888: mov             x16, #2
    // 0x85388c: stp             x16, x1, [SP]
    // 0x853890: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x853890: sub             lr, x0, #0xdfd
    //     0x853894: ldr             lr, [x21, lr, lsl #3]
    //     0x853898: blr             lr
    // 0x85389c: mov             x3, x0
    // 0x8538a0: r2 = Null
    //     0x8538a0: mov             x2, NULL
    // 0x8538a4: r1 = Null
    //     0x8538a4: mov             x1, NULL
    // 0x8538a8: stur            x3, [fp, #-0x18]
    // 0x8538ac: r8 = Map<String, dynamic>
    //     0x8538ac: ldr             x8, [PP, #0x3298]  ; [pp+0x3298] Type: Map<String, dynamic>
    // 0x8538b0: r3 = Null
    //     0x8538b0: ldr             x3, [PP, #0x44d0]  ; [pp+0x44d0] Null
    // 0x8538b4: r0 = Map<String, dynamic>()
    //     0x8538b4: bl              #0x84f9a4  ; IsType_Map<String, dynamic>_Stub
    // 0x8538b8: ldur            x2, [fp, #-0x18]
    // 0x8538bc: r0 = LoadClassIdInstr(r2)
    //     0x8538bc: ldur            x0, [x2, #-1]
    //     0x8538c0: ubfx            x0, x0, #0xc, #0x14
    // 0x8538c4: mov             x1, x2
    // 0x8538c8: r0 = GDT[cid_x0 + 0x44d]()
    //     0x8538c8: add             lr, x0, #0x44d
    //     0x8538cc: ldr             lr, [x21, lr, lsl #3]
    //     0x8538d0: blr             lr
    // 0x8538d4: r1 = LoadClassIdInstr(r0)
    //     0x8538d4: ldur            x1, [x0, #-1]
    //     0x8538d8: ubfx            x1, x1, #0xc, #0x14
    // 0x8538dc: mov             x16, x0
    // 0x8538e0: mov             x0, x1
    // 0x8538e4: mov             x1, x16
    // 0x8538e8: r0 = GDT[cid_x0 + 0x12641]()
    //     0x8538e8: mov             x17, #0x2641
    //     0x8538ec: movk            x17, #1, lsl #16
    //     0x8538f0: add             lr, x0, x17
    //     0x8538f4: ldr             lr, [x21, lr, lsl #3]
    //     0x8538f8: blr             lr
    // 0x8538fc: mov             x2, x0
    // 0x853900: stur            x2, [fp, #-0x30]
    // 0x853904: ldur            x3, [fp, #-0x18]
    // 0x853908: CheckStackOverflow
    //     0x853908: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x85390c: cmp             SP, x16
    //     0x853910: b.ls            #0x854580
    // 0x853914: r0 = LoadClassIdInstr(r2)
    //     0x853914: ldur            x0, [x2, #-1]
    //     0x853918: ubfx            x0, x0, #0xc, #0x14
    // 0x85391c: mov             x1, x2
    // 0x853920: r0 = GDT[cid_x0 + 0x1845b]()
    //     0x853920: mov             x17, #0x845b
    //     0x853924: movk            x17, #1, lsl #16
    //     0x853928: add             lr, x0, x17
    //     0x85392c: ldr             lr, [x21, lr, lsl #3]
    //     0x853930: blr             lr
    // 0x853934: tbnz            w0, #4, #0x8539b4
    // 0x853938: ldur            x3, [fp, #-0x18]
    // 0x85393c: ldur            x2, [fp, #-0x30]
    // 0x853940: r0 = LoadClassIdInstr(r2)
    //     0x853940: ldur            x0, [x2, #-1]
    //     0x853944: ubfx            x0, x0, #0xc, #0x14
    // 0x853948: mov             x1, x2
    // 0x85394c: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0x85394c: mov             x17, #0x7d4c
    //     0x853950: movk            x17, #1, lsl #16
    //     0x853954: add             lr, x0, x17
    //     0x853958: ldr             lr, [x21, lr, lsl #3]
    //     0x85395c: blr             lr
    // 0x853960: ldur            x3, [fp, #-0x18]
    // 0x853964: r1 = LoadClassIdInstr(r3)
    //     0x853964: ldur            x1, [x3, #-1]
    //     0x853968: ubfx            x1, x1, #0xc, #0x14
    // 0x85396c: mov             x2, x0
    // 0x853970: mov             x0, x1
    // 0x853974: mov             x1, x3
    // 0x853978: r0 = GDT[cid_x0 + -0xd48]()
    //     0x853978: sub             lr, x0, #0xd48
    //     0x85397c: ldr             lr, [x21, lr, lsl #3]
    //     0x853980: blr             lr
    // 0x853984: mov             x3, x0
    // 0x853988: r2 = Null
    //     0x853988: mov             x2, NULL
    // 0x85398c: r1 = Null
    //     0x85398c: mov             x1, NULL
    // 0x853990: stur            x3, [fp, #-0x38]
    // 0x853994: r8 = Map<String, dynamic>
    //     0x853994: ldr             x8, [PP, #0x3298]  ; [pp+0x3298] Type: Map<String, dynamic>
    // 0x853998: r3 = Null
    //     0x853998: ldr             x3, [PP, #0x44e0]  ; [pp+0x44e0] Null
    // 0x85399c: r0 = Map<String, dynamic>()
    //     0x85399c: bl              #0x84f9a4  ; IsType_Map<String, dynamic>_Stub
    // 0x8539a0: ldur            x2, [fp, #-0x38]
    // 0x8539a4: r1 = Null
    //     0x8539a4: mov             x1, NULL
    // 0x8539a8: r0 = TextEditingValue.fromJSON()
    //     0x8539a8: bl              #0x877fa4  ; [package:flutter/src/services/text_input.dart] TextEditingValue::TextEditingValue.fromJSON
    // 0x8539ac: ldur            x2, [fp, #-0x30]
    // 0x8539b0: b               #0x853904
    // 0x8539b4: r0 = Null
    //     0x8539b4: mov             x0, NULL
    // 0x8539b8: r0 = ReturnAsyncNotFuture()
    //     0x8539b8: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x8539bc: ldur            x2, [fp, #-0x10]
    // 0x8539c0: ldur            x1, [fp, #-0x20]
    // 0x8539c4: r0 = LoadClassIdInstr(r1)
    //     0x8539c4: ldur            x0, [x1, #-1]
    //     0x8539c8: ubfx            x0, x0, #0xc, #0x14
    // 0x8539cc: stp             xzr, x1, [SP]
    // 0x8539d0: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x8539d0: sub             lr, x0, #0xdfd
    //     0x8539d4: ldr             lr, [x21, lr, lsl #3]
    //     0x8539d8: blr             lr
    // 0x8539dc: mov             x3, x0
    // 0x8539e0: r2 = Null
    //     0x8539e0: mov             x2, NULL
    // 0x8539e4: r1 = Null
    //     0x8539e4: mov             x1, NULL
    // 0x8539e8: stur            x3, [fp, #-0x18]
    // 0x8539ec: branchIfSmi(r0, 0x853a10)
    //     0x8539ec: tbz             w0, #0, #0x853a10
    // 0x8539f0: r4 = LoadClassIdInstr(r0)
    //     0x8539f0: ldur            x4, [x0, #-1]
    //     0x8539f4: ubfx            x4, x4, #0xc, #0x14
    // 0x8539f8: sub             x4, x4, #0x3c
    // 0x8539fc: cmp             x4, #1
    // 0x853a00: b.ls            #0x853a10
    // 0x853a04: r8 = int
    //     0x853a04: ldr             x8, [PP, #0x390]  ; [pp+0x390] Type: int
    // 0x853a08: r3 = Null
    //     0x853a08: ldr             x3, [PP, #0x44f0]  ; [pp+0x44f0] Null
    // 0x853a0c: r0 = int()
    //     0x853a0c: bl              #0x13ee980  ; IsType_int_Stub
    // 0x853a10: ldur            x0, [fp, #-0x10]
    // 0x853a14: LoadField: r1 = r0->field_13
    //     0x853a14: ldur            w1, [x0, #0x13]
    // 0x853a18: DecompressPointer r1
    //     0x853a18: add             x1, x1, HEAP, lsl #32
    // 0x853a1c: cmp             w1, NULL
    // 0x853a20: b.eq            #0x854588
    // 0x853a24: LoadField: r2 = r1->field_1b
    //     0x853a24: ldur            x2, [x1, #0x1b]
    // 0x853a28: ldur            x1, [fp, #-0x18]
    // 0x853a2c: r3 = LoadInt32Instr(r1)
    //     0x853a2c: sbfx            x3, x1, #1, #0x1f
    //     0x853a30: tbz             w1, #0, #0x853a38
    //     0x853a34: ldur            x3, [x1, #7]
    // 0x853a38: cmp             x3, x2
    // 0x853a3c: b.eq            #0x853a48
    // 0x853a40: r0 = Null
    //     0x853a40: mov             x0, NULL
    // 0x853a44: r0 = ReturnAsyncNotFuture()
    //     0x853a44: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x853a48: r16 = "TextInputClient.updateEditingState"
    //     0x853a48: ldr             x16, [PP, #0x4500]  ; [pp+0x4500] "TextInputClient.updateEditingState"
    // 0x853a4c: ldur            lr, [fp, #-0x28]
    // 0x853a50: stp             lr, x16, [SP]
    // 0x853a54: r0 = ==()
    //     0x853a54: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x853a58: tbnz            w0, #4, #0x853afc
    // 0x853a5c: ldur            x0, [fp, #-0x20]
    // 0x853a60: r1 = LoadClassIdInstr(r0)
    //     0x853a60: ldur            x1, [x0, #-1]
    //     0x853a64: ubfx            x1, x1, #0xc, #0x14
    // 0x853a68: r16 = 2
    //     0x853a68: mov             x16, #2
    // 0x853a6c: stp             x16, x0, [SP]
    // 0x853a70: mov             x0, x1
    // 0x853a74: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x853a74: sub             lr, x0, #0xdfd
    //     0x853a78: ldr             lr, [x21, lr, lsl #3]
    //     0x853a7c: blr             lr
    // 0x853a80: mov             x3, x0
    // 0x853a84: r2 = Null
    //     0x853a84: mov             x2, NULL
    // 0x853a88: r1 = Null
    //     0x853a88: mov             x1, NULL
    // 0x853a8c: stur            x3, [fp, #-0x18]
    // 0x853a90: r8 = Map<String, dynamic>
    //     0x853a90: ldr             x8, [PP, #0x3298]  ; [pp+0x3298] Type: Map<String, dynamic>
    // 0x853a94: r3 = Null
    //     0x853a94: ldr             x3, [PP, #0x4508]  ; [pp+0x4508] Null
    // 0x853a98: r0 = Map<String, dynamic>()
    //     0x853a98: bl              #0x84f9a4  ; IsType_Map<String, dynamic>_Stub
    // 0x853a9c: ldur            x2, [fp, #-0x18]
    // 0x853aa0: r1 = Null
    //     0x853aa0: mov             x1, NULL
    // 0x853aa4: r0 = TextEditingValue.fromJSON()
    //     0x853aa4: bl              #0x877fa4  ; [package:flutter/src/services/text_input.dart] TextEditingValue::TextEditingValue.fromJSON
    // 0x853aa8: stur            x0, [fp, #-0x18]
    // 0x853aac: r0 = LoadStaticField(0x67c)
    //     0x853aac: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x853ab0: ldr             x0, [x0, #0xcf8]
    // 0x853ab4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x853ab8: cmp             w0, w16
    // 0x853abc: b.ne            #0x853ac8
    // 0x853ac0: r2 = _instance
    //     0x853ac0: ldr             x2, [PP, #0x30b0]  ; [pp+0x30b0] Field <TextInput._instance@81206165>: static late final (offset: 0x67c)
    // 0x853ac4: r0 = InitLateFinalStaticField()
    //     0x853ac4: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x853ac8: stur            x0, [fp, #-0x30]
    // 0x853acc: r0 = LoadStaticField(0x688)
    //     0x853acc: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x853ad0: ldr             x0, [x0, #0xd10]
    // 0x853ad4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x853ad8: cmp             w0, w16
    // 0x853adc: b.ne            #0x853ae8
    // 0x853ae0: r2 = instance
    //     0x853ae0: ldr             x2, [PP, #0x4398]  ; [pp+0x4398] Field <_PlatformTextInputControl@81206165.instance>: static late final (offset: 0x688)
    // 0x853ae4: r0 = InitLateFinalStaticField()
    //     0x853ae4: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x853ae8: ldur            x1, [fp, #-0x30]
    // 0x853aec: ldur            x2, [fp, #-0x18]
    // 0x853af0: mov             x3, x0
    // 0x853af4: r0 = _updateEditingValue()
    //     0x853af4: bl              #0x877088  ; [package:flutter/src/services/text_input.dart] TextInput::_updateEditingValue
    // 0x853af8: b               #0x85450c
    // 0x853afc: ldur            x0, [fp, #-0x20]
    // 0x853b00: r16 = "TextInputClient.updateEditingStateWithDeltas"
    //     0x853b00: ldr             x16, [PP, #0x4518]  ; [pp+0x4518] "TextInputClient.updateEditingStateWithDeltas"
    // 0x853b04: ldur            lr, [fp, #-0x28]
    // 0x853b08: stp             lr, x16, [SP]
    // 0x853b0c: r0 = ==()
    //     0x853b0c: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x853b10: tbnz            w0, #4, #0x853cf4
    // 0x853b14: ldur            x0, [fp, #-0x20]
    // 0x853b18: r1 = LoadClassIdInstr(r0)
    //     0x853b18: ldur            x1, [x0, #-1]
    //     0x853b1c: ubfx            x1, x1, #0xc, #0x14
    // 0x853b20: r16 = 2
    //     0x853b20: mov             x16, #2
    // 0x853b24: stp             x16, x0, [SP]
    // 0x853b28: mov             x0, x1
    // 0x853b2c: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x853b2c: sub             lr, x0, #0xdfd
    //     0x853b30: ldr             lr, [x21, lr, lsl #3]
    //     0x853b34: blr             lr
    // 0x853b38: mov             x3, x0
    // 0x853b3c: r2 = Null
    //     0x853b3c: mov             x2, NULL
    // 0x853b40: r1 = Null
    //     0x853b40: mov             x1, NULL
    // 0x853b44: stur            x3, [fp, #-0x18]
    // 0x853b48: r8 = Map<String, dynamic>
    //     0x853b48: ldr             x8, [PP, #0x3298]  ; [pp+0x3298] Type: Map<String, dynamic>
    // 0x853b4c: r3 = Null
    //     0x853b4c: ldr             x3, [PP, #0x4520]  ; [pp+0x4520] Null
    // 0x853b50: r0 = Map<String, dynamic>()
    //     0x853b50: bl              #0x84f9a4  ; IsType_Map<String, dynamic>_Stub
    // 0x853b54: r1 = <TextEditingDelta>
    //     0x853b54: ldr             x1, [PP, #0x4530]  ; [pp+0x4530] TypeArguments: <TextEditingDelta>
    // 0x853b58: r2 = 0
    //     0x853b58: mov             x2, #0
    // 0x853b5c: r0 = _GrowableList()
    //     0x853b5c: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x853b60: mov             x3, x0
    // 0x853b64: ldur            x1, [fp, #-0x18]
    // 0x853b68: stur            x3, [fp, #-0x30]
    // 0x853b6c: r0 = LoadClassIdInstr(r1)
    //     0x853b6c: ldur            x0, [x1, #-1]
    //     0x853b70: ubfx            x0, x0, #0xc, #0x14
    // 0x853b74: r2 = "deltas"
    //     0x853b74: ldr             x2, [PP, #0x4538]  ; [pp+0x4538] "deltas"
    // 0x853b78: r0 = GDT[cid_x0 + -0xd48]()
    //     0x853b78: sub             lr, x0, #0xd48
    //     0x853b7c: ldr             lr, [x21, lr, lsl #3]
    //     0x853b80: blr             lr
    // 0x853b84: mov             x3, x0
    // 0x853b88: r2 = Null
    //     0x853b88: mov             x2, NULL
    // 0x853b8c: r1 = Null
    //     0x853b8c: mov             x1, NULL
    // 0x853b90: stur            x3, [fp, #-0x18]
    // 0x853b94: r4 = 60
    //     0x853b94: mov             x4, #0x3c
    // 0x853b98: branchIfSmi(r0, 0x853ba4)
    //     0x853b98: tbz             w0, #0, #0x853ba4
    // 0x853b9c: r4 = LoadClassIdInstr(r0)
    //     0x853b9c: ldur            x4, [x0, #-1]
    //     0x853ba0: ubfx            x4, x4, #0xc, #0x14
    // 0x853ba4: sub             x4, x4, #0x5a
    // 0x853ba8: cmp             x4, #2
    // 0x853bac: b.ls            #0x853bbc
    // 0x853bb0: r8 = List
    //     0x853bb0: ldr             x8, [PP, #0x30e8]  ; [pp+0x30e8] Type: List
    // 0x853bb4: r3 = Null
    //     0x853bb4: ldr             x3, [PP, #0x4540]  ; [pp+0x4540] Null
    // 0x853bb8: r0 = List()
    //     0x853bb8: bl              #0x13efaa0  ; IsType_List_Stub
    // 0x853bbc: ldur            x1, [fp, #-0x18]
    // 0x853bc0: r0 = LoadClassIdInstr(r1)
    //     0x853bc0: ldur            x0, [x1, #-1]
    //     0x853bc4: ubfx            x0, x0, #0xc, #0x14
    // 0x853bc8: r0 = GDT[cid_x0 + 0x12641]()
    //     0x853bc8: mov             x17, #0x2641
    //     0x853bcc: movk            x17, #1, lsl #16
    //     0x853bd0: add             lr, x0, x17
    //     0x853bd4: ldr             lr, [x21, lr, lsl #3]
    //     0x853bd8: blr             lr
    // 0x853bdc: mov             x2, x0
    // 0x853be0: stur            x2, [fp, #-0x18]
    // 0x853be4: ldur            x3, [fp, #-0x30]
    // 0x853be8: CheckStackOverflow
    //     0x853be8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x853bec: cmp             SP, x16
    //     0x853bf0: b.ls            #0x85458c
    // 0x853bf4: r0 = LoadClassIdInstr(r2)
    //     0x853bf4: ldur            x0, [x2, #-1]
    //     0x853bf8: ubfx            x0, x0, #0xc, #0x14
    // 0x853bfc: mov             x1, x2
    // 0x853c00: r0 = GDT[cid_x0 + 0x1845b]()
    //     0x853c00: mov             x17, #0x845b
    //     0x853c04: movk            x17, #1, lsl #16
    //     0x853c08: add             lr, x0, x17
    //     0x853c0c: ldr             lr, [x21, lr, lsl #3]
    //     0x853c10: blr             lr
    // 0x853c14: tbnz            w0, #4, #0x854514
    // 0x853c18: ldur            x3, [fp, #-0x30]
    // 0x853c1c: ldur            x2, [fp, #-0x18]
    // 0x853c20: r0 = LoadClassIdInstr(r2)
    //     0x853c20: ldur            x0, [x2, #-1]
    //     0x853c24: ubfx            x0, x0, #0xc, #0x14
    // 0x853c28: mov             x1, x2
    // 0x853c2c: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0x853c2c: mov             x17, #0x7d4c
    //     0x853c30: movk            x17, #1, lsl #16
    //     0x853c34: add             lr, x0, x17
    //     0x853c38: ldr             lr, [x21, lr, lsl #3]
    //     0x853c3c: blr             lr
    // 0x853c40: mov             x3, x0
    // 0x853c44: r2 = Null
    //     0x853c44: mov             x2, NULL
    // 0x853c48: r1 = Null
    //     0x853c48: mov             x1, NULL
    // 0x853c4c: stur            x3, [fp, #-0x38]
    // 0x853c50: r8 = Map<String, dynamic>
    //     0x853c50: ldr             x8, [PP, #0x3298]  ; [pp+0x3298] Type: Map<String, dynamic>
    // 0x853c54: r3 = Null
    //     0x853c54: ldr             x3, [PP, #0x4550]  ; [pp+0x4550] Null
    // 0x853c58: r0 = Map<String, dynamic>()
    //     0x853c58: bl              #0x84f9a4  ; IsType_Map<String, dynamic>_Stub
    // 0x853c5c: ldur            x2, [fp, #-0x38]
    // 0x853c60: r1 = Null
    //     0x853c60: mov             x1, NULL
    // 0x853c64: r0 = TextEditingDelta.fromJSON()
    //     0x853c64: bl              #0x87682c  ; [package:flutter/src/services/text_editing_delta.dart] TextEditingDelta::TextEditingDelta.fromJSON
    // 0x853c68: mov             x2, x0
    // 0x853c6c: ldur            x0, [fp, #-0x30]
    // 0x853c70: stur            x2, [fp, #-0x38]
    // 0x853c74: LoadField: r1 = r0->field_b
    //     0x853c74: ldur            w1, [x0, #0xb]
    // 0x853c78: LoadField: r3 = r0->field_f
    //     0x853c78: ldur            w3, [x0, #0xf]
    // 0x853c7c: DecompressPointer r3
    //     0x853c7c: add             x3, x3, HEAP, lsl #32
    // 0x853c80: LoadField: r4 = r3->field_b
    //     0x853c80: ldur            w4, [x3, #0xb]
    // 0x853c84: r3 = LoadInt32Instr(r1)
    //     0x853c84: sbfx            x3, x1, #1, #0x1f
    // 0x853c88: stur            x3, [fp, #-0x48]
    // 0x853c8c: r1 = LoadInt32Instr(r4)
    //     0x853c8c: sbfx            x1, x4, #1, #0x1f
    // 0x853c90: cmp             x3, x1
    // 0x853c94: b.ne            #0x853ca0
    // 0x853c98: mov             x1, x0
    // 0x853c9c: r0 = _growToNextCapacity()
    //     0x853c9c: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x853ca0: ldur            x2, [fp, #-0x30]
    // 0x853ca4: ldur            x3, [fp, #-0x48]
    // 0x853ca8: add             x0, x3, #1
    // 0x853cac: lsl             x1, x0, #1
    // 0x853cb0: StoreField: r2->field_b = r1
    //     0x853cb0: stur            w1, [x2, #0xb]
    // 0x853cb4: LoadField: r1 = r2->field_f
    //     0x853cb4: ldur            w1, [x2, #0xf]
    // 0x853cb8: DecompressPointer r1
    //     0x853cb8: add             x1, x1, HEAP, lsl #32
    // 0x853cbc: ldur            x0, [fp, #-0x38]
    // 0x853cc0: ArrayStore: r1[r3] = r0  ; List_4
    //     0x853cc0: add             x25, x1, x3, lsl #2
    //     0x853cc4: add             x25, x25, #0xf
    //     0x853cc8: str             w0, [x25]
    //     0x853ccc: tbz             w0, #0, #0x853ce8
    //     0x853cd0: ldurb           w16, [x1, #-1]
    //     0x853cd4: ldurb           w17, [x0, #-1]
    //     0x853cd8: and             x16, x17, x16, lsr #2
    //     0x853cdc: tst             x16, HEAP, lsr #32
    //     0x853ce0: b.eq            #0x853ce8
    //     0x853ce4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x853ce8: mov             x3, x2
    // 0x853cec: ldur            x2, [fp, #-0x18]
    // 0x853cf0: b               #0x853be8
    // 0x853cf4: ldur            x0, [fp, #-0x20]
    // 0x853cf8: r16 = "TextInputClient.performAction"
    //     0x853cf8: ldr             x16, [PP, #0x4560]  ; [pp+0x4560] "TextInputClient.performAction"
    // 0x853cfc: ldur            lr, [fp, #-0x28]
    // 0x853d00: stp             lr, x16, [SP]
    // 0x853d04: r0 = ==()
    //     0x853d04: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x853d08: tbnz            w0, #4, #0x853ea4
    // 0x853d0c: ldur            x1, [fp, #-0x20]
    // 0x853d10: r0 = LoadClassIdInstr(r1)
    //     0x853d10: ldur            x0, [x1, #-1]
    //     0x853d14: ubfx            x0, x0, #0xc, #0x14
    // 0x853d18: r16 = 2
    //     0x853d18: mov             x16, #2
    // 0x853d1c: stp             x16, x1, [SP]
    // 0x853d20: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x853d20: sub             lr, x0, #0xdfd
    //     0x853d24: ldr             lr, [x21, lr, lsl #3]
    //     0x853d28: blr             lr
    // 0x853d2c: mov             x3, x0
    // 0x853d30: r2 = Null
    //     0x853d30: mov             x2, NULL
    // 0x853d34: r1 = Null
    //     0x853d34: mov             x1, NULL
    // 0x853d38: stur            x3, [fp, #-0x18]
    // 0x853d3c: r4 = 60
    //     0x853d3c: mov             x4, #0x3c
    // 0x853d40: branchIfSmi(r0, 0x853d4c)
    //     0x853d40: tbz             w0, #0, #0x853d4c
    // 0x853d44: r4 = LoadClassIdInstr(r0)
    //     0x853d44: ldur            x4, [x0, #-1]
    //     0x853d48: ubfx            x4, x4, #0xc, #0x14
    // 0x853d4c: sub             x4, x4, #0x5e
    // 0x853d50: cmp             x4, #1
    // 0x853d54: b.ls            #0x853d64
    // 0x853d58: r8 = String
    //     0x853d58: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x853d5c: r3 = Null
    //     0x853d5c: ldr             x3, [PP, #0x4568]  ; [pp+0x4568] Null
    // 0x853d60: r0 = String()
    //     0x853d60: bl              #0x13ee320  ; IsType_String_Stub
    // 0x853d64: ldur            x0, [fp, #-0x18]
    // 0x853d68: r1 = LoadClassIdInstr(r0)
    //     0x853d68: ldur            x1, [x0, #-1]
    //     0x853d6c: ubfx            x1, x1, #0xc, #0x14
    // 0x853d70: r16 = "TextInputAction.commitContent"
    //     0x853d70: ldr             x16, [PP, #0x4578]  ; [pp+0x4578] "TextInputAction.commitContent"
    // 0x853d74: stp             x16, x0, [SP]
    // 0x853d78: mov             x0, x1
    // 0x853d7c: mov             lr, x0
    // 0x853d80: ldr             lr, [x21, lr, lsl #3]
    // 0x853d84: blr             lr
    // 0x853d88: tbnz            w0, #4, #0x853e10
    // 0x853d8c: ldur            x1, [fp, #-0x10]
    // 0x853d90: ldur            x0, [fp, #-0x20]
    // 0x853d94: r2 = LoadClassIdInstr(r0)
    //     0x853d94: ldur            x2, [x0, #-1]
    //     0x853d98: ubfx            x2, x2, #0xc, #0x14
    // 0x853d9c: r16 = 4
    //     0x853d9c: mov             x16, #4
    // 0x853da0: stp             x16, x0, [SP]
    // 0x853da4: mov             x0, x2
    // 0x853da8: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x853da8: sub             lr, x0, #0xdfd
    //     0x853dac: ldr             lr, [x21, lr, lsl #3]
    //     0x853db0: blr             lr
    // 0x853db4: mov             x3, x0
    // 0x853db8: r2 = Null
    //     0x853db8: mov             x2, NULL
    // 0x853dbc: r1 = Null
    //     0x853dbc: mov             x1, NULL
    // 0x853dc0: stur            x3, [fp, #-0x18]
    // 0x853dc4: r8 = Map<String, dynamic>
    //     0x853dc4: ldr             x8, [PP, #0x3298]  ; [pp+0x3298] Type: Map<String, dynamic>
    // 0x853dc8: r3 = Null
    //     0x853dc8: ldr             x3, [PP, #0x4580]  ; [pp+0x4580] Null
    // 0x853dcc: r0 = Map<String, dynamic>()
    //     0x853dcc: bl              #0x84f9a4  ; IsType_Map<String, dynamic>_Stub
    // 0x853dd0: r0 = KeyboardInsertedContent()
    //     0x853dd0: bl              #0x876820  ; AllocateKeyboardInsertedContentStub -> KeyboardInsertedContent (size=0x14)
    // 0x853dd4: mov             x1, x0
    // 0x853dd8: ldur            x2, [fp, #-0x18]
    // 0x853ddc: r0 = KeyboardInsertedContent.fromJson()
    //     0x853ddc: bl              #0x876274  ; [package:flutter/src/services/keyboard_inserted_content.dart] KeyboardInsertedContent::KeyboardInsertedContent.fromJson
    // 0x853de0: ldur            x1, [fp, #-0x10]
    // 0x853de4: LoadField: r0 = r1->field_13
    //     0x853de4: ldur            w0, [x1, #0x13]
    // 0x853de8: DecompressPointer r0
    //     0x853de8: add             x0, x0, HEAP, lsl #32
    // 0x853dec: cmp             w0, NULL
    // 0x853df0: b.eq            #0x854594
    // 0x853df4: LoadField: r1 = r0->field_23
    //     0x853df4: ldur            w1, [x0, #0x23]
    // 0x853df8: DecompressPointer r1
    //     0x853df8: add             x1, x1, HEAP, lsl #32
    // 0x853dfc: LoadField: r0 = r1->field_b
    //     0x853dfc: ldur            w0, [x1, #0xb]
    // 0x853e00: DecompressPointer r0
    //     0x853e00: add             x0, x0, HEAP, lsl #32
    // 0x853e04: cmp             w0, NULL
    // 0x853e08: b.eq            #0x854598
    // 0x853e0c: b               #0x85450c
    // 0x853e10: ldur            x1, [fp, #-0x10]
    // 0x853e14: ldur            x0, [fp, #-0x20]
    // 0x853e18: LoadField: r2 = r1->field_13
    //     0x853e18: ldur            w2, [x1, #0x13]
    // 0x853e1c: DecompressPointer r2
    //     0x853e1c: add             x2, x2, HEAP, lsl #32
    // 0x853e20: cmp             w2, NULL
    // 0x853e24: b.eq            #0x85459c
    // 0x853e28: LoadField: r1 = r2->field_23
    //     0x853e28: ldur            w1, [x2, #0x23]
    // 0x853e2c: DecompressPointer r1
    //     0x853e2c: add             x1, x1, HEAP, lsl #32
    // 0x853e30: stur            x1, [fp, #-0x18]
    // 0x853e34: r2 = LoadClassIdInstr(r0)
    //     0x853e34: ldur            x2, [x0, #-1]
    //     0x853e38: ubfx            x2, x2, #0xc, #0x14
    // 0x853e3c: r16 = 2
    //     0x853e3c: mov             x16, #2
    // 0x853e40: stp             x16, x0, [SP]
    // 0x853e44: mov             x0, x2
    // 0x853e48: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x853e48: sub             lr, x0, #0xdfd
    //     0x853e4c: ldr             lr, [x21, lr, lsl #3]
    //     0x853e50: blr             lr
    // 0x853e54: mov             x3, x0
    // 0x853e58: r2 = Null
    //     0x853e58: mov             x2, NULL
    // 0x853e5c: r1 = Null
    //     0x853e5c: mov             x1, NULL
    // 0x853e60: stur            x3, [fp, #-0x30]
    // 0x853e64: r4 = 60
    //     0x853e64: mov             x4, #0x3c
    // 0x853e68: branchIfSmi(r0, 0x853e74)
    //     0x853e68: tbz             w0, #0, #0x853e74
    // 0x853e6c: r4 = LoadClassIdInstr(r0)
    //     0x853e6c: ldur            x4, [x0, #-1]
    //     0x853e70: ubfx            x4, x4, #0xc, #0x14
    // 0x853e74: sub             x4, x4, #0x5e
    // 0x853e78: cmp             x4, #1
    // 0x853e7c: b.ls            #0x853e8c
    // 0x853e80: r8 = String
    //     0x853e80: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x853e84: r3 = Null
    //     0x853e84: ldr             x3, [PP, #0x4590]  ; [pp+0x4590] Null
    // 0x853e88: r0 = String()
    //     0x853e88: bl              #0x13ee320  ; IsType_String_Stub
    // 0x853e8c: ldur            x1, [fp, #-0x30]
    // 0x853e90: r0 = _toTextInputAction()
    //     0x853e90: bl              #0x876040  ; [package:flutter/src/services/text_input.dart] ::_toTextInputAction
    // 0x853e94: ldur            x1, [fp, #-0x18]
    // 0x853e98: mov             x2, x0
    // 0x853e9c: r0 = performAction()
    //     0x853e9c: bl              #0x87552c  ; [package:flutter/src/widgets/editable_text.dart] EditableTextState::performAction
    // 0x853ea0: b               #0x85450c
    // 0x853ea4: ldur            x1, [fp, #-0x10]
    // 0x853ea8: ldur            x0, [fp, #-0x20]
    // 0x853eac: r16 = "TextInputClient.performSelectors"
    //     0x853eac: ldr             x16, [PP, #0x45a0]  ; [pp+0x45a0] "TextInputClient.performSelectors"
    // 0x853eb0: ldur            lr, [fp, #-0x28]
    // 0x853eb4: stp             lr, x16, [SP]
    // 0x853eb8: r0 = ==()
    //     0x853eb8: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x853ebc: tbnz            w0, #4, #0x853fac
    // 0x853ec0: ldur            x1, [fp, #-0x10]
    // 0x853ec4: ldur            x0, [fp, #-0x20]
    // 0x853ec8: r2 = LoadClassIdInstr(r0)
    //     0x853ec8: ldur            x2, [x0, #-1]
    //     0x853ecc: ubfx            x2, x2, #0xc, #0x14
    // 0x853ed0: r16 = 2
    //     0x853ed0: mov             x16, #2
    // 0x853ed4: stp             x16, x0, [SP]
    // 0x853ed8: mov             x0, x2
    // 0x853edc: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x853edc: sub             lr, x0, #0xdfd
    //     0x853ee0: ldr             lr, [x21, lr, lsl #3]
    //     0x853ee4: blr             lr
    // 0x853ee8: mov             x3, x0
    // 0x853eec: r2 = Null
    //     0x853eec: mov             x2, NULL
    // 0x853ef0: r1 = Null
    //     0x853ef0: mov             x1, NULL
    // 0x853ef4: stur            x3, [fp, #-0x18]
    // 0x853ef8: r4 = 60
    //     0x853ef8: mov             x4, #0x3c
    // 0x853efc: branchIfSmi(r0, 0x853f08)
    //     0x853efc: tbz             w0, #0, #0x853f08
    // 0x853f00: r4 = LoadClassIdInstr(r0)
    //     0x853f00: ldur            x4, [x0, #-1]
    //     0x853f04: ubfx            x4, x4, #0xc, #0x14
    // 0x853f08: sub             x4, x4, #0x5a
    // 0x853f0c: cmp             x4, #2
    // 0x853f10: b.ls            #0x853f20
    // 0x853f14: r8 = List
    //     0x853f14: ldr             x8, [PP, #0x30e8]  ; [pp+0x30e8] Type: List
    // 0x853f18: r3 = Null
    //     0x853f18: ldr             x3, [PP, #0x45a8]  ; [pp+0x45a8] Null
    // 0x853f1c: r0 = List()
    //     0x853f1c: bl              #0x13efaa0  ; IsType_List_Stub
    // 0x853f20: ldur            x0, [fp, #-0x18]
    // 0x853f24: r1 = LoadClassIdInstr(r0)
    //     0x853f24: ldur            x1, [x0, #-1]
    //     0x853f28: ubfx            x1, x1, #0xc, #0x14
    // 0x853f2c: r16 = <String>
    //     0x853f2c: ldr             x16, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    // 0x853f30: stp             x0, x16, [SP]
    // 0x853f34: mov             x0, x1
    // 0x853f38: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x853f38: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x853f3c: r0 = GDT[cid_x0 + 0x13106]()
    //     0x853f3c: mov             x17, #0x3106
    //     0x853f40: movk            x17, #1, lsl #16
    //     0x853f44: add             lr, x0, x17
    //     0x853f48: ldr             lr, [x21, lr, lsl #3]
    //     0x853f4c: blr             lr
    // 0x853f50: ldur            x1, [fp, #-0x10]
    // 0x853f54: stur            x0, [fp, #-0x18]
    // 0x853f58: LoadField: r2 = r1->field_13
    //     0x853f58: ldur            w2, [x1, #0x13]
    // 0x853f5c: DecompressPointer r2
    //     0x853f5c: add             x2, x2, HEAP, lsl #32
    // 0x853f60: cmp             w2, NULL
    // 0x853f64: b.eq            #0x8545a0
    // 0x853f68: LoadField: r1 = r2->field_23
    //     0x853f68: ldur            w1, [x2, #0x23]
    // 0x853f6c: DecompressPointer r1
    //     0x853f6c: add             x1, x1, HEAP, lsl #32
    // 0x853f70: mov             x2, x1
    // 0x853f74: r1 = Function 'performSelector':.
    //     0x853f74: ldr             x1, [PP, #0x45b8]  ; [pp+0x45b8] AnonymousClosure: (0x87978c), in [package:flutter/src/widgets/editable_text.dart] EditableTextState::performSelector (0x8797c8)
    // 0x853f78: r0 = AllocateClosure()
    //     0x853f78: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x853f7c: ldur            x1, [fp, #-0x18]
    // 0x853f80: r2 = LoadClassIdInstr(r1)
    //     0x853f80: ldur            x2, [x1, #-1]
    //     0x853f84: ubfx            x2, x2, #0xc, #0x14
    // 0x853f88: mov             x16, x0
    // 0x853f8c: mov             x0, x2
    // 0x853f90: mov             x2, x16
    // 0x853f94: r0 = GDT[cid_x0 + 0x12d45]()
    //     0x853f94: mov             x17, #0x2d45
    //     0x853f98: movk            x17, #1, lsl #16
    //     0x853f9c: add             lr, x0, x17
    //     0x853fa0: ldr             lr, [x21, lr, lsl #3]
    //     0x853fa4: blr             lr
    // 0x853fa8: b               #0x85450c
    // 0x853fac: ldur            x1, [fp, #-0x10]
    // 0x853fb0: ldur            x0, [fp, #-0x20]
    // 0x853fb4: r16 = "TextInputClient.performPrivateCommand"
    //     0x853fb4: ldr             x16, [PP, #0x45c0]  ; [pp+0x45c0] "TextInputClient.performPrivateCommand"
    // 0x853fb8: ldur            lr, [fp, #-0x28]
    // 0x853fbc: stp             lr, x16, [SP]
    // 0x853fc0: r0 = ==()
    //     0x853fc0: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x853fc4: tbnz            w0, #4, #0x854100
    // 0x853fc8: ldur            x1, [fp, #-0x10]
    // 0x853fcc: ldur            x0, [fp, #-0x20]
    // 0x853fd0: r2 = LoadClassIdInstr(r0)
    //     0x853fd0: ldur            x2, [x0, #-1]
    //     0x853fd4: ubfx            x2, x2, #0xc, #0x14
    // 0x853fd8: r16 = 2
    //     0x853fd8: mov             x16, #2
    // 0x853fdc: stp             x16, x0, [SP]
    // 0x853fe0: mov             x0, x2
    // 0x853fe4: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x853fe4: sub             lr, x0, #0xdfd
    //     0x853fe8: ldr             lr, [x21, lr, lsl #3]
    //     0x853fec: blr             lr
    // 0x853ff0: mov             x3, x0
    // 0x853ff4: r2 = Null
    //     0x853ff4: mov             x2, NULL
    // 0x853ff8: r1 = Null
    //     0x853ff8: mov             x1, NULL
    // 0x853ffc: stur            x3, [fp, #-0x18]
    // 0x854000: r8 = Map<String, dynamic>
    //     0x854000: ldr             x8, [PP, #0x3298]  ; [pp+0x3298] Type: Map<String, dynamic>
    // 0x854004: r3 = Null
    //     0x854004: ldr             x3, [PP, #0x45c8]  ; [pp+0x45c8] Null
    // 0x854008: r0 = Map<String, dynamic>()
    //     0x854008: bl              #0x84f9a4  ; IsType_Map<String, dynamic>_Stub
    // 0x85400c: ldur            x1, [fp, #-0x10]
    // 0x854010: LoadField: r0 = r1->field_13
    //     0x854010: ldur            w0, [x1, #0x13]
    // 0x854014: DecompressPointer r0
    //     0x854014: add             x0, x0, HEAP, lsl #32
    // 0x854018: cmp             w0, NULL
    // 0x85401c: b.eq            #0x8545a4
    // 0x854020: LoadField: r3 = r0->field_23
    //     0x854020: ldur            w3, [x0, #0x23]
    // 0x854024: DecompressPointer r3
    //     0x854024: add             x3, x3, HEAP, lsl #32
    // 0x854028: ldur            x4, [fp, #-0x18]
    // 0x85402c: stur            x3, [fp, #-0x30]
    // 0x854030: r0 = LoadClassIdInstr(r4)
    //     0x854030: ldur            x0, [x4, #-1]
    //     0x854034: ubfx            x0, x0, #0xc, #0x14
    // 0x854038: mov             x1, x4
    // 0x85403c: r2 = "action"
    //     0x85403c: ldr             x2, [PP, #0x45d8]  ; [pp+0x45d8] "action"
    // 0x854040: r0 = GDT[cid_x0 + -0xd48]()
    //     0x854040: sub             lr, x0, #0xd48
    //     0x854044: ldr             lr, [x21, lr, lsl #3]
    //     0x854048: blr             lr
    // 0x85404c: r2 = Null
    //     0x85404c: mov             x2, NULL
    // 0x854050: r1 = Null
    //     0x854050: mov             x1, NULL
    // 0x854054: r4 = 60
    //     0x854054: mov             x4, #0x3c
    // 0x854058: branchIfSmi(r0, 0x854064)
    //     0x854058: tbz             w0, #0, #0x854064
    // 0x85405c: r4 = LoadClassIdInstr(r0)
    //     0x85405c: ldur            x4, [x0, #-1]
    //     0x854060: ubfx            x4, x4, #0xc, #0x14
    // 0x854064: sub             x4, x4, #0x5e
    // 0x854068: cmp             x4, #1
    // 0x85406c: b.ls            #0x85407c
    // 0x854070: r8 = String
    //     0x854070: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x854074: r3 = Null
    //     0x854074: ldr             x3, [PP, #0x45e0]  ; [pp+0x45e0] Null
    // 0x854078: r0 = String()
    //     0x854078: bl              #0x13ee320  ; IsType_String_Stub
    // 0x85407c: ldur            x3, [fp, #-0x18]
    // 0x854080: r0 = LoadClassIdInstr(r3)
    //     0x854080: ldur            x0, [x3, #-1]
    //     0x854084: ubfx            x0, x0, #0xc, #0x14
    // 0x854088: mov             x1, x3
    // 0x85408c: r2 = "data"
    //     0x85408c: ldr             x2, [PP, #0x1370]  ; [pp+0x1370] "data"
    // 0x854090: r0 = GDT[cid_x0 + -0xd48]()
    //     0x854090: sub             lr, x0, #0xd48
    //     0x854094: ldr             lr, [x21, lr, lsl #3]
    //     0x854098: blr             lr
    // 0x85409c: cmp             w0, NULL
    // 0x8540a0: b.ne            #0x8540b8
    // 0x8540a4: r16 = <String, dynamic>
    //     0x8540a4: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x8540a8: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x8540ac: stp             lr, x16, [SP]
    // 0x8540b0: r0 = Map._fromLiteral()
    //     0x8540b0: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x8540b4: b               #0x8540e8
    // 0x8540b8: ldur            x1, [fp, #-0x18]
    // 0x8540bc: r0 = LoadClassIdInstr(r1)
    //     0x8540bc: ldur            x0, [x1, #-1]
    //     0x8540c0: ubfx            x0, x0, #0xc, #0x14
    // 0x8540c4: r2 = "data"
    //     0x8540c4: ldr             x2, [PP, #0x1370]  ; [pp+0x1370] "data"
    // 0x8540c8: r0 = GDT[cid_x0 + -0xd48]()
    //     0x8540c8: sub             lr, x0, #0xd48
    //     0x8540cc: ldr             lr, [x21, lr, lsl #3]
    //     0x8540d0: blr             lr
    // 0x8540d4: r2 = Null
    //     0x8540d4: mov             x2, NULL
    // 0x8540d8: r1 = Null
    //     0x8540d8: mov             x1, NULL
    // 0x8540dc: r8 = Map<String, dynamic>
    //     0x8540dc: ldr             x8, [PP, #0x3298]  ; [pp+0x3298] Type: Map<String, dynamic>
    // 0x8540e0: r3 = Null
    //     0x8540e0: ldr             x3, [PP, #0x45f0]  ; [pp+0x45f0] Null
    // 0x8540e4: r0 = Map<String, dynamic>()
    //     0x8540e4: bl              #0x84f9a4  ; IsType_Map<String, dynamic>_Stub
    // 0x8540e8: ldur            x0, [fp, #-0x30]
    // 0x8540ec: LoadField: r1 = r0->field_b
    //     0x8540ec: ldur            w1, [x0, #0xb]
    // 0x8540f0: DecompressPointer r1
    //     0x8540f0: add             x1, x1, HEAP, lsl #32
    // 0x8540f4: cmp             w1, NULL
    // 0x8540f8: b.eq            #0x8545a8
    // 0x8540fc: b               #0x85450c
    // 0x854100: ldur            x1, [fp, #-0x10]
    // 0x854104: ldur            x0, [fp, #-0x20]
    // 0x854108: r16 = "TextInputClient.updateFloatingCursor"
    //     0x854108: ldr             x16, [PP, #0x4600]  ; [pp+0x4600] "TextInputClient.updateFloatingCursor"
    // 0x85410c: ldur            lr, [fp, #-0x28]
    // 0x854110: stp             lr, x16, [SP]
    // 0x854114: r0 = ==()
    //     0x854114: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x854118: tbnz            w0, #4, #0x8541fc
    // 0x85411c: ldur            x0, [fp, #-0x10]
    // 0x854120: ldur            x1, [fp, #-0x20]
    // 0x854124: LoadField: r2 = r0->field_13
    //     0x854124: ldur            w2, [x0, #0x13]
    // 0x854128: DecompressPointer r2
    //     0x854128: add             x2, x2, HEAP, lsl #32
    // 0x85412c: cmp             w2, NULL
    // 0x854130: b.eq            #0x8545ac
    // 0x854134: LoadField: r3 = r2->field_23
    //     0x854134: ldur            w3, [x2, #0x23]
    // 0x854138: DecompressPointer r3
    //     0x854138: add             x3, x3, HEAP, lsl #32
    // 0x85413c: stur            x3, [fp, #-0x18]
    // 0x854140: r0 = LoadClassIdInstr(r1)
    //     0x854140: ldur            x0, [x1, #-1]
    //     0x854144: ubfx            x0, x0, #0xc, #0x14
    // 0x854148: r16 = 2
    //     0x854148: mov             x16, #2
    // 0x85414c: stp             x16, x1, [SP]
    // 0x854150: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x854150: sub             lr, x0, #0xdfd
    //     0x854154: ldr             lr, [x21, lr, lsl #3]
    //     0x854158: blr             lr
    // 0x85415c: mov             x3, x0
    // 0x854160: r2 = Null
    //     0x854160: mov             x2, NULL
    // 0x854164: r1 = Null
    //     0x854164: mov             x1, NULL
    // 0x854168: stur            x3, [fp, #-0x30]
    // 0x85416c: r4 = 60
    //     0x85416c: mov             x4, #0x3c
    // 0x854170: branchIfSmi(r0, 0x85417c)
    //     0x854170: tbz             w0, #0, #0x85417c
    // 0x854174: r4 = LoadClassIdInstr(r0)
    //     0x854174: ldur            x4, [x0, #-1]
    //     0x854178: ubfx            x4, x4, #0xc, #0x14
    // 0x85417c: sub             x4, x4, #0x5e
    // 0x854180: cmp             x4, #1
    // 0x854184: b.ls            #0x854194
    // 0x854188: r8 = String
    //     0x854188: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x85418c: r3 = Null
    //     0x85418c: ldr             x3, [PP, #0x4608]  ; [pp+0x4608] Null
    // 0x854190: r0 = String()
    //     0x854190: bl              #0x13ee320  ; IsType_String_Stub
    // 0x854194: ldur            x1, [fp, #-0x30]
    // 0x854198: r0 = _toTextCursorAction()
    //     0x854198: bl              #0x875410  ; [package:flutter/src/services/text_input.dart] ::_toTextCursorAction
    // 0x85419c: mov             x2, x0
    // 0x8541a0: ldur            x1, [fp, #-0x20]
    // 0x8541a4: stur            x2, [fp, #-0x30]
    // 0x8541a8: r0 = LoadClassIdInstr(r1)
    //     0x8541a8: ldur            x0, [x1, #-1]
    //     0x8541ac: ubfx            x0, x0, #0xc, #0x14
    // 0x8541b0: r16 = 4
    //     0x8541b0: mov             x16, #4
    // 0x8541b4: stp             x16, x1, [SP]
    // 0x8541b8: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x8541b8: sub             lr, x0, #0xdfd
    //     0x8541bc: ldr             lr, [x21, lr, lsl #3]
    //     0x8541c0: blr             lr
    // 0x8541c4: mov             x3, x0
    // 0x8541c8: r2 = Null
    //     0x8541c8: mov             x2, NULL
    // 0x8541cc: r1 = Null
    //     0x8541cc: mov             x1, NULL
    // 0x8541d0: stur            x3, [fp, #-0x38]
    // 0x8541d4: r8 = Map<String, dynamic>
    //     0x8541d4: ldr             x8, [PP, #0x3298]  ; [pp+0x3298] Type: Map<String, dynamic>
    // 0x8541d8: r3 = Null
    //     0x8541d8: ldr             x3, [PP, #0x4618]  ; [pp+0x4618] Null
    // 0x8541dc: r0 = Map<String, dynamic>()
    //     0x8541dc: bl              #0x84f9a4  ; IsType_Map<String, dynamic>_Stub
    // 0x8541e0: ldur            x1, [fp, #-0x30]
    // 0x8541e4: ldur            x2, [fp, #-0x38]
    // 0x8541e8: r0 = _toTextPoint()
    //     0x8541e8: bl              #0x875270  ; [package:flutter/src/services/text_input.dart] ::_toTextPoint
    // 0x8541ec: ldur            x1, [fp, #-0x18]
    // 0x8541f0: mov             x2, x0
    // 0x8541f4: r0 = updateFloatingCursor()
    //     0x8541f4: bl              #0x865c00  ; [package:flutter/src/widgets/editable_text.dart] EditableTextState::updateFloatingCursor
    // 0x8541f8: b               #0x85450c
    // 0x8541fc: ldur            x0, [fp, #-0x10]
    // 0x854200: ldur            x1, [fp, #-0x20]
    // 0x854204: r16 = "TextInputClient.onConnectionClosed"
    //     0x854204: ldr             x16, [PP, #0x4628]  ; [pp+0x4628] "TextInputClient.onConnectionClosed"
    // 0x854208: ldur            lr, [fp, #-0x28]
    // 0x85420c: stp             lr, x16, [SP]
    // 0x854210: r0 = ==()
    //     0x854210: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x854214: tbnz            w0, #4, #0x854240
    // 0x854218: ldur            x0, [fp, #-0x10]
    // 0x85421c: LoadField: r1 = r0->field_13
    //     0x85421c: ldur            w1, [x0, #0x13]
    // 0x854220: DecompressPointer r1
    //     0x854220: add             x1, x1, HEAP, lsl #32
    // 0x854224: cmp             w1, NULL
    // 0x854228: b.eq            #0x8545b0
    // 0x85422c: LoadField: r0 = r1->field_23
    //     0x85422c: ldur            w0, [x1, #0x23]
    // 0x854230: DecompressPointer r0
    //     0x854230: add             x0, x0, HEAP, lsl #32
    // 0x854234: mov             x1, x0
    // 0x854238: r0 = connectionClosed()
    //     0x854238: bl              #0x865a58  ; [package:flutter/src/widgets/editable_text.dart] EditableTextState::connectionClosed
    // 0x85423c: b               #0x85450c
    // 0x854240: ldur            x0, [fp, #-0x10]
    // 0x854244: r16 = "TextInputClient.showAutocorrectionPromptRect"
    //     0x854244: ldr             x16, [PP, #0x4630]  ; [pp+0x4630] "TextInputClient.showAutocorrectionPromptRect"
    // 0x854248: ldur            lr, [fp, #-0x28]
    // 0x85424c: stp             lr, x16, [SP]
    // 0x854250: r0 = ==()
    //     0x854250: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x854254: tbnz            w0, #4, #0x85434c
    // 0x854258: ldur            x0, [fp, #-0x10]
    // 0x85425c: ldur            x1, [fp, #-0x20]
    // 0x854260: LoadField: r2 = r0->field_13
    //     0x854260: ldur            w2, [x0, #0x13]
    // 0x854264: DecompressPointer r2
    //     0x854264: add             x2, x2, HEAP, lsl #32
    // 0x854268: cmp             w2, NULL
    // 0x85426c: b.eq            #0x8545b4
    // 0x854270: LoadField: r3 = r2->field_23
    //     0x854270: ldur            w3, [x2, #0x23]
    // 0x854274: DecompressPointer r3
    //     0x854274: add             x3, x3, HEAP, lsl #32
    // 0x854278: stur            x3, [fp, #-0x18]
    // 0x85427c: r0 = LoadClassIdInstr(r1)
    //     0x85427c: ldur            x0, [x1, #-1]
    //     0x854280: ubfx            x0, x0, #0xc, #0x14
    // 0x854284: r16 = 2
    //     0x854284: mov             x16, #2
    // 0x854288: stp             x16, x1, [SP]
    // 0x85428c: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x85428c: sub             lr, x0, #0xdfd
    //     0x854290: ldr             lr, [x21, lr, lsl #3]
    //     0x854294: blr             lr
    // 0x854298: mov             x3, x0
    // 0x85429c: r2 = Null
    //     0x85429c: mov             x2, NULL
    // 0x8542a0: r1 = Null
    //     0x8542a0: mov             x1, NULL
    // 0x8542a4: stur            x3, [fp, #-0x30]
    // 0x8542a8: branchIfSmi(r0, 0x8542cc)
    //     0x8542a8: tbz             w0, #0, #0x8542cc
    // 0x8542ac: r4 = LoadClassIdInstr(r0)
    //     0x8542ac: ldur            x4, [x0, #-1]
    //     0x8542b0: ubfx            x4, x4, #0xc, #0x14
    // 0x8542b4: sub             x4, x4, #0x3c
    // 0x8542b8: cmp             x4, #1
    // 0x8542bc: b.ls            #0x8542cc
    // 0x8542c0: r8 = int
    //     0x8542c0: ldr             x8, [PP, #0x390]  ; [pp+0x390] Type: int
    // 0x8542c4: r3 = Null
    //     0x8542c4: ldr             x3, [PP, #0x4638]  ; [pp+0x4638] Null
    // 0x8542c8: r0 = int()
    //     0x8542c8: bl              #0x13ee980  ; IsType_int_Stub
    // 0x8542cc: ldur            x1, [fp, #-0x20]
    // 0x8542d0: r0 = LoadClassIdInstr(r1)
    //     0x8542d0: ldur            x0, [x1, #-1]
    //     0x8542d4: ubfx            x0, x0, #0xc, #0x14
    // 0x8542d8: r16 = 4
    //     0x8542d8: mov             x16, #4
    // 0x8542dc: stp             x16, x1, [SP]
    // 0x8542e0: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x8542e0: sub             lr, x0, #0xdfd
    //     0x8542e4: ldr             lr, [x21, lr, lsl #3]
    //     0x8542e8: blr             lr
    // 0x8542ec: mov             x3, x0
    // 0x8542f0: r2 = Null
    //     0x8542f0: mov             x2, NULL
    // 0x8542f4: r1 = Null
    //     0x8542f4: mov             x1, NULL
    // 0x8542f8: stur            x3, [fp, #-0x38]
    // 0x8542fc: branchIfSmi(r0, 0x854320)
    //     0x8542fc: tbz             w0, #0, #0x854320
    // 0x854300: r4 = LoadClassIdInstr(r0)
    //     0x854300: ldur            x4, [x0, #-1]
    //     0x854304: ubfx            x4, x4, #0xc, #0x14
    // 0x854308: sub             x4, x4, #0x3c
    // 0x85430c: cmp             x4, #1
    // 0x854310: b.ls            #0x854320
    // 0x854314: r8 = int
    //     0x854314: ldr             x8, [PP, #0x390]  ; [pp+0x390] Type: int
    // 0x854318: r3 = Null
    //     0x854318: ldr             x3, [PP, #0x4648]  ; [pp+0x4648] Null
    // 0x85431c: r0 = int()
    //     0x85431c: bl              #0x13ee980  ; IsType_int_Stub
    // 0x854320: ldur            x0, [fp, #-0x30]
    // 0x854324: r2 = LoadInt32Instr(r0)
    //     0x854324: sbfx            x2, x0, #1, #0x1f
    //     0x854328: tbz             w0, #0, #0x854330
    //     0x85432c: ldur            x2, [x0, #7]
    // 0x854330: ldur            x0, [fp, #-0x38]
    // 0x854334: r3 = LoadInt32Instr(r0)
    //     0x854334: sbfx            x3, x0, #1, #0x1f
    //     0x854338: tbz             w0, #0, #0x854340
    //     0x85433c: ldur            x3, [x0, #7]
    // 0x854340: ldur            x1, [fp, #-0x18]
    // 0x854344: r0 = showAutocorrectionPromptRect()
    //     0x854344: bl              #0x865924  ; [package:flutter/src/widgets/editable_text.dart] EditableTextState::showAutocorrectionPromptRect
    // 0x854348: b               #0x85450c
    // 0x85434c: ldur            x0, [fp, #-0x10]
    // 0x854350: ldur            x1, [fp, #-0x20]
    // 0x854354: r16 = "TextInputClient.showToolbar"
    //     0x854354: ldr             x16, [PP, #0x4658]  ; [pp+0x4658] "TextInputClient.showToolbar"
    // 0x854358: ldur            lr, [fp, #-0x28]
    // 0x85435c: stp             lr, x16, [SP]
    // 0x854360: r0 = ==()
    //     0x854360: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x854364: tbnz            w0, #4, #0x854390
    // 0x854368: ldur            x0, [fp, #-0x10]
    // 0x85436c: LoadField: r1 = r0->field_13
    //     0x85436c: ldur            w1, [x0, #0x13]
    // 0x854370: DecompressPointer r1
    //     0x854370: add             x1, x1, HEAP, lsl #32
    // 0x854374: cmp             w1, NULL
    // 0x854378: b.eq            #0x8545b8
    // 0x85437c: LoadField: r0 = r1->field_23
    //     0x85437c: ldur            w0, [x1, #0x23]
    // 0x854380: DecompressPointer r0
    //     0x854380: add             x0, x0, HEAP, lsl #32
    // 0x854384: mov             x1, x0
    // 0x854388: r0 = showToolbar()
    //     0x854388: bl              #0x8547bc  ; [package:flutter/src/widgets/editable_text.dart] EditableTextState::showToolbar
    // 0x85438c: b               #0x85450c
    // 0x854390: ldur            x0, [fp, #-0x10]
    // 0x854394: r16 = "TextInputClient.insertTextPlaceholder"
    //     0x854394: ldr             x16, [PP, #0x4660]  ; [pp+0x4660] "TextInputClient.insertTextPlaceholder"
    // 0x854398: ldur            lr, [fp, #-0x28]
    // 0x85439c: stp             lr, x16, [SP]
    // 0x8543a0: r0 = ==()
    //     0x8543a0: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x8543a4: tbnz            w0, #4, #0x8544d0
    // 0x8543a8: ldur            x0, [fp, #-0x10]
    // 0x8543ac: ldur            x1, [fp, #-0x20]
    // 0x8543b0: LoadField: r2 = r0->field_13
    //     0x8543b0: ldur            w2, [x0, #0x13]
    // 0x8543b4: DecompressPointer r2
    //     0x8543b4: add             x2, x2, HEAP, lsl #32
    // 0x8543b8: cmp             w2, NULL
    // 0x8543bc: b.eq            #0x8545bc
    // 0x8543c0: LoadField: r3 = r2->field_23
    //     0x8543c0: ldur            w3, [x2, #0x23]
    // 0x8543c4: DecompressPointer r3
    //     0x8543c4: add             x3, x3, HEAP, lsl #32
    // 0x8543c8: stur            x3, [fp, #-0x18]
    // 0x8543cc: r0 = LoadClassIdInstr(r1)
    //     0x8543cc: ldur            x0, [x1, #-1]
    //     0x8543d0: ubfx            x0, x0, #0xc, #0x14
    // 0x8543d4: r16 = 2
    //     0x8543d4: mov             x16, #2
    // 0x8543d8: stp             x16, x1, [SP]
    // 0x8543dc: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x8543dc: sub             lr, x0, #0xdfd
    //     0x8543e0: ldr             lr, [x21, lr, lsl #3]
    //     0x8543e4: blr             lr
    // 0x8543e8: mov             x3, x0
    // 0x8543ec: r2 = Null
    //     0x8543ec: mov             x2, NULL
    // 0x8543f0: r1 = Null
    //     0x8543f0: mov             x1, NULL
    // 0x8543f4: stur            x3, [fp, #-0x30]
    // 0x8543f8: branchIfSmi(r0, 0x85441c)
    //     0x8543f8: tbz             w0, #0, #0x85441c
    // 0x8543fc: r4 = LoadClassIdInstr(r0)
    //     0x8543fc: ldur            x4, [x0, #-1]
    //     0x854400: ubfx            x4, x4, #0xc, #0x14
    // 0x854404: sub             x4, x4, #0x3c
    // 0x854408: cmp             x4, #2
    // 0x85440c: b.ls            #0x85441c
    // 0x854410: r8 = num
    //     0x854410: ldr             x8, [PP, #0x398]  ; [pp+0x398] Type: num
    // 0x854414: r3 = Null
    //     0x854414: ldr             x3, [PP, #0x4668]  ; [pp+0x4668] Null
    // 0x854418: r0 = num()
    //     0x854418: bl              #0x13ee9b0  ; IsType_num_Stub
    // 0x85441c: ldur            x0, [fp, #-0x30]
    // 0x854420: r1 = 60
    //     0x854420: mov             x1, #0x3c
    // 0x854424: branchIfSmi(r0, 0x854430)
    //     0x854424: tbz             w0, #0, #0x854430
    // 0x854428: r1 = LoadClassIdInstr(r0)
    //     0x854428: ldur            x1, [x0, #-1]
    //     0x85442c: ubfx            x1, x1, #0xc, #0x14
    // 0x854430: str             x0, [SP]
    // 0x854434: mov             x0, x1
    // 0x854438: r0 = GDT[cid_x0 + -0xffd]()
    //     0x854438: sub             lr, x0, #0xffd
    //     0x85443c: ldr             lr, [x21, lr, lsl #3]
    //     0x854440: blr             lr
    // 0x854444: ldur            x0, [fp, #-0x20]
    // 0x854448: r1 = LoadClassIdInstr(r0)
    //     0x854448: ldur            x1, [x0, #-1]
    //     0x85444c: ubfx            x1, x1, #0xc, #0x14
    // 0x854450: r16 = 4
    //     0x854450: mov             x16, #4
    // 0x854454: stp             x16, x0, [SP]
    // 0x854458: mov             x0, x1
    // 0x85445c: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x85445c: sub             lr, x0, #0xdfd
    //     0x854460: ldr             lr, [x21, lr, lsl #3]
    //     0x854464: blr             lr
    // 0x854468: mov             x3, x0
    // 0x85446c: r2 = Null
    //     0x85446c: mov             x2, NULL
    // 0x854470: r1 = Null
    //     0x854470: mov             x1, NULL
    // 0x854474: stur            x3, [fp, #-0x20]
    // 0x854478: branchIfSmi(r0, 0x85449c)
    //     0x854478: tbz             w0, #0, #0x85449c
    // 0x85447c: r4 = LoadClassIdInstr(r0)
    //     0x85447c: ldur            x4, [x0, #-1]
    //     0x854480: ubfx            x4, x4, #0xc, #0x14
    // 0x854484: sub             x4, x4, #0x3c
    // 0x854488: cmp             x4, #2
    // 0x85448c: b.ls            #0x85449c
    // 0x854490: r8 = num
    //     0x854490: ldr             x8, [PP, #0x398]  ; [pp+0x398] Type: num
    // 0x854494: r3 = Null
    //     0x854494: ldr             x3, [PP, #0x4678]  ; [pp+0x4678] Null
    // 0x854498: r0 = num()
    //     0x854498: bl              #0x13ee9b0  ; IsType_num_Stub
    // 0x85449c: ldur            x0, [fp, #-0x20]
    // 0x8544a0: r1 = 60
    //     0x8544a0: mov             x1, #0x3c
    // 0x8544a4: branchIfSmi(r0, 0x8544b0)
    //     0x8544a4: tbz             w0, #0, #0x8544b0
    // 0x8544a8: r1 = LoadClassIdInstr(r0)
    //     0x8544a8: ldur            x1, [x0, #-1]
    //     0x8544ac: ubfx            x1, x1, #0xc, #0x14
    // 0x8544b0: str             x0, [SP]
    // 0x8544b4: mov             x0, x1
    // 0x8544b8: r0 = GDT[cid_x0 + -0xffd]()
    //     0x8544b8: sub             lr, x0, #0xffd
    //     0x8544bc: ldr             lr, [x21, lr, lsl #3]
    //     0x8544c0: blr             lr
    // 0x8544c4: ldur            x1, [fp, #-0x18]
    // 0x8544c8: r0 = insertTextPlaceholder()
    //     0x8544c8: bl              #0x8546a8  ; [package:flutter/src/widgets/editable_text.dart] EditableTextState::insertTextPlaceholder
    // 0x8544cc: b               #0x85450c
    // 0x8544d0: ldur            x0, [fp, #-0x10]
    // 0x8544d4: r16 = "TextInputClient.removeTextPlaceholder"
    //     0x8544d4: ldr             x16, [PP, #0x4688]  ; [pp+0x4688] "TextInputClient.removeTextPlaceholder"
    // 0x8544d8: ldur            lr, [fp, #-0x28]
    // 0x8544dc: stp             lr, x16, [SP]
    // 0x8544e0: r0 = ==()
    //     0x8544e0: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x8544e4: tbnz            w0, #4, #0x854558
    // 0x8544e8: ldur            x0, [fp, #-0x10]
    // 0x8544ec: LoadField: r1 = r0->field_13
    //     0x8544ec: ldur            w1, [x0, #0x13]
    // 0x8544f0: DecompressPointer r1
    //     0x8544f0: add             x1, x1, HEAP, lsl #32
    // 0x8544f4: cmp             w1, NULL
    // 0x8544f8: b.eq            #0x8545c0
    // 0x8544fc: LoadField: r0 = r1->field_23
    //     0x8544fc: ldur            w0, [x1, #0x23]
    // 0x854500: DecompressPointer r0
    //     0x854500: add             x0, x0, HEAP, lsl #32
    // 0x854504: mov             x1, x0
    // 0x854508: r0 = removeTextPlaceholder()
    //     0x854508: bl              #0x8545f8  ; [package:flutter/src/widgets/editable_text.dart] EditableTextState::removeTextPlaceholder
    // 0x85450c: r0 = Null
    //     0x85450c: mov             x0, NULL
    // 0x854510: r0 = ReturnAsyncNotFuture()
    //     0x854510: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x854514: ldur            x0, [fp, #-0x10]
    // 0x854518: LoadField: r1 = r0->field_13
    //     0x854518: ldur            w1, [x0, #0x13]
    // 0x85451c: DecompressPointer r1
    //     0x85451c: add             x1, x1, HEAP, lsl #32
    // 0x854520: cmp             w1, NULL
    // 0x854524: b.eq            #0x8545c4
    // 0x854528: LoadField: r0 = r1->field_23
    //     0x854528: ldur            w0, [x1, #0x23]
    // 0x85452c: DecompressPointer r0
    //     0x85452c: add             x0, x0, HEAP, lsl #32
    // 0x854530: r2 = Null
    //     0x854530: mov             x2, NULL
    // 0x854534: r1 = Null
    //     0x854534: mov             x1, NULL
    // 0x854538: r4 = LoadClassIdInstr(r0)
    //     0x854538: ldur            x4, [x0, #-1]
    //     0x85453c: ubfx            x4, x4, #0xc, #0x14
    // 0x854540: r8 = DeltaTextInputClient
    //     0x854540: ldr             x8, [PP, #0x4690]  ; [pp+0x4690] Type: DeltaTextInputClient
    // 0x854544: r3 = Null
    //     0x854544: ldr             x3, [PP, #0x4698]  ; [pp+0x4698] Null
    // 0x854548: r0 = DefaultTypeTest()
    //     0x854548: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x85454c: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x85454c: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x854550: r0 = Throw()
    //     0x854550: bl              #0x13ddb2c  ; ThrowStub
    // 0x854554: brk             #0
    // 0x854558: r0 = MissingPluginException()
    //     0x854558: bl              #0x8545ec  ; AllocateMissingPluginExceptionStub -> MissingPluginException (size=0xc)
    // 0x85455c: r0 = Throw()
    //     0x85455c: bl              #0x13ddb2c  ; ThrowStub
    // 0x854560: brk             #0
    // 0x854564: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x854564: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x854568: b               #0x85317c
    // 0x85456c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x85456c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x854570: r9 = _currentConfiguration
    //     0x854570: ldr             x9, [PP, #0x46a8]  ; [pp+0x46a8] Field <TextInput._currentConfiguration@81206165>: late (offset: 0x18)
    // 0x854574: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x854574: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x854578: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x854578: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x85457c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x85457c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x854580: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x854580: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x854584: b               #0x853914
    // 0x854588: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x854588: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x85458c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85458c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x854590: b               #0x853bf4
    // 0x854594: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x854594: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x854598: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x854598: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x85459c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x85459c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8545a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8545a0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8545a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8545a4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8545a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8545a8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8545ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8545ac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8545b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8545b0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8545b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8545b4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8545b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8545b8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8545bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8545bc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8545c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8545c0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8545c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8545c4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _requestAutofill(/* No info */) {
    // ** addr: 0x872c18, size: 0x120
    // 0x872c18: EnterFrame
    //     0x872c18: stp             fp, lr, [SP, #-0x10]!
    //     0x872c1c: mov             fp, SP
    // 0x872c20: AllocStack(0x40)
    //     0x872c20: sub             SP, SP, #0x40
    // 0x872c24: CheckStackOverflow
    //     0x872c24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x872c28: cmp             SP, x16
    //     0x872c2c: b.ls            #0x872d28
    // 0x872c30: LoadField: r0 = r1->field_b
    //     0x872c30: ldur            w0, [x1, #0xb]
    // 0x872c34: DecompressPointer r0
    //     0x872c34: add             x0, x0, HEAP, lsl #32
    // 0x872c38: mov             x1, x0
    // 0x872c3c: r0 = iterator()
    //     0x872c3c: bl              #0xbb7c60  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0x872c40: stur            x0, [fp, #-0x10]
    // 0x872c44: LoadField: r2 = r0->field_7
    //     0x872c44: ldur            w2, [x0, #7]
    // 0x872c48: DecompressPointer r2
    //     0x872c48: add             x2, x2, HEAP, lsl #32
    // 0x872c4c: stur            x2, [fp, #-8]
    // 0x872c50: CheckStackOverflow
    //     0x872c50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x872c54: cmp             SP, x16
    //     0x872c58: b.ls            #0x872d30
    // 0x872c5c: mov             x1, x0
    // 0x872c60: r0 = moveNext()
    //     0x872c60: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0x872c64: tbnz            w0, #4, #0x872d18
    // 0x872c68: ldur            x3, [fp, #-0x10]
    // 0x872c6c: LoadField: r4 = r3->field_33
    //     0x872c6c: ldur            w4, [x3, #0x33]
    // 0x872c70: DecompressPointer r4
    //     0x872c70: add             x4, x4, HEAP, lsl #32
    // 0x872c74: stur            x4, [fp, #-0x18]
    // 0x872c78: cmp             w4, NULL
    // 0x872c7c: b.ne            #0x872cac
    // 0x872c80: mov             x0, x4
    // 0x872c84: ldur            x2, [fp, #-8]
    // 0x872c88: r1 = Null
    //     0x872c88: mov             x1, NULL
    // 0x872c8c: cmp             w2, NULL
    // 0x872c90: b.eq            #0x872cac
    // 0x872c94: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x872c94: ldur            w4, [x2, #0x17]
    // 0x872c98: DecompressPointer r4
    //     0x872c98: add             x4, x4, HEAP, lsl #32
    // 0x872c9c: r8 = X0
    //     0x872c9c: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x872ca0: LoadField: r9 = r4->field_7
    //     0x872ca0: ldur            x9, [x4, #7]
    // 0x872ca4: r3 = Null
    //     0x872ca4: ldr             x3, [PP, #0x5938]  ; [pp+0x5938] Null
    // 0x872ca8: blr             x9
    // 0x872cac: ldur            x1, [fp, #-0x18]
    // 0x872cb0: r0 = _channel()
    //     0x872cb0: bl              #0x872d5c  ; [package:flutter/src/services/text_input.dart] _PlatformTextInputControl::_channel
    // 0x872cb4: r16 = <void?>
    //     0x872cb4: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x872cb8: r30 = Instance_OptionalMethodChannel
    //     0x872cb8: ldr             lr, [PP, #0x43b0]  ; [pp+0x43b0] Obj!OptionalMethodChannel@129bea1
    // 0x872cbc: stp             lr, x16, [SP, #8]
    // 0x872cc0: r16 = "TextInput.requestAutofill"
    //     0x872cc0: ldr             x16, [PP, #0x5948]  ; [pp+0x5948] "TextInput.requestAutofill"
    // 0x872cc4: str             x16, [SP]
    // 0x872cc8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x872cc8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x872ccc: r0 = invokeMethod()
    //     0x872ccc: bl              #0x130ad0c  ; [package:flutter/src/services/platform_channel.dart] OptionalMethodChannel::invokeMethod
    // 0x872cd0: r1 = Function '<anonymous closure>':.
    //     0x872cd0: ldr             x1, [PP, #0x5950]  ; [pp+0x5950] Function: [dart:ui] Shader::Shader._ (0x13cf838)
    // 0x872cd4: r2 = Null
    //     0x872cd4: mov             x2, NULL
    // 0x872cd8: stur            x0, [fp, #-0x18]
    // 0x872cdc: r0 = AllocateClosure()
    //     0x872cdc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x872ce0: r1 = Function '<anonymous closure>':.
    //     0x872ce0: ldr             x1, [PP, #0x5958]  ; [pp+0x5958] AnonymousClosure: (0x872dc0), of [package:flutter/src/services/text_input.dart] _PlatformTextInputControl
    // 0x872ce4: r2 = Null
    //     0x872ce4: mov             x2, NULL
    // 0x872ce8: stur            x0, [fp, #-0x20]
    // 0x872cec: r0 = AllocateClosure()
    //     0x872cec: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x872cf0: r16 = <Null?>
    //     0x872cf0: ldr             x16, [PP, #0x70]  ; [pp+0x70] TypeArguments: <Null?>
    // 0x872cf4: ldur            lr, [fp, #-0x18]
    // 0x872cf8: stp             lr, x16, [SP, #0x10]
    // 0x872cfc: ldur            x16, [fp, #-0x20]
    // 0x872d00: stp             x0, x16, [SP]
    // 0x872d04: r4 = const [0x1, 0x3, 0x3, 0x2, onError, 0x2, null]
    //     0x872d04: ldr             x4, [PP, #0x538]  ; [pp+0x538] List(7) [0x1, 0x3, 0x3, 0x2, "onError", 0x2, Null]
    // 0x872d08: r0 = then()
    //     0x872d08: bl              #0x1293070  ; [dart:async] _Future::then
    // 0x872d0c: ldur            x0, [fp, #-0x10]
    // 0x872d10: ldur            x2, [fp, #-8]
    // 0x872d14: b               #0x872c50
    // 0x872d18: r0 = Null
    //     0x872d18: mov             x0, NULL
    // 0x872d1c: LeaveFrame
    //     0x872d1c: mov             SP, fp
    //     0x872d20: ldp             fp, lr, [SP], #0x10
    // 0x872d24: ret
    //     0x872d24: ret             
    // 0x872d28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x872d28: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x872d2c: b               #0x872c30
    // 0x872d30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x872d30: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x872d34: b               #0x872c5c
  }
  _ _show(/* No info */) {
    // ** addr: 0x872ec8, size: 0x148
    // 0x872ec8: EnterFrame
    //     0x872ec8: stp             fp, lr, [SP, #-0x10]!
    //     0x872ecc: mov             fp, SP
    // 0x872ed0: AllocStack(0x40)
    //     0x872ed0: sub             SP, SP, #0x40
    // 0x872ed4: CheckStackOverflow
    //     0x872ed4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x872ed8: cmp             SP, x16
    //     0x872edc: b.ls            #0x872ff8
    // 0x872ee0: LoadField: r0 = r1->field_b
    //     0x872ee0: ldur            w0, [x1, #0xb]
    // 0x872ee4: DecompressPointer r0
    //     0x872ee4: add             x0, x0, HEAP, lsl #32
    // 0x872ee8: mov             x1, x0
    // 0x872eec: r0 = iterator()
    //     0x872eec: bl              #0xbb7c60  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0x872ef0: stur            x0, [fp, #-0x10]
    // 0x872ef4: LoadField: r2 = r0->field_7
    //     0x872ef4: ldur            w2, [x0, #7]
    // 0x872ef8: DecompressPointer r2
    //     0x872ef8: add             x2, x2, HEAP, lsl #32
    // 0x872efc: stur            x2, [fp, #-8]
    // 0x872f00: CheckStackOverflow
    //     0x872f00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x872f04: cmp             SP, x16
    //     0x872f08: b.ls            #0x873000
    // 0x872f0c: mov             x1, x0
    // 0x872f10: r0 = moveNext()
    //     0x872f10: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0x872f14: tbnz            w0, #4, #0x872fe8
    // 0x872f18: ldur            x3, [fp, #-0x10]
    // 0x872f1c: LoadField: r0 = r3->field_33
    //     0x872f1c: ldur            w0, [x3, #0x33]
    // 0x872f20: DecompressPointer r0
    //     0x872f20: add             x0, x0, HEAP, lsl #32
    // 0x872f24: cmp             w0, NULL
    // 0x872f28: b.ne            #0x872f54
    // 0x872f2c: ldur            x2, [fp, #-8]
    // 0x872f30: r1 = Null
    //     0x872f30: mov             x1, NULL
    // 0x872f34: cmp             w2, NULL
    // 0x872f38: b.eq            #0x872f54
    // 0x872f3c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x872f3c: ldur            w4, [x2, #0x17]
    // 0x872f40: DecompressPointer r4
    //     0x872f40: add             x4, x4, HEAP, lsl #32
    // 0x872f44: r8 = X0
    //     0x872f44: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x872f48: LoadField: r9 = r4->field_7
    //     0x872f48: ldur            x9, [x4, #7]
    // 0x872f4c: r3 = Null
    //     0x872f4c: ldr             x3, [PP, #0x5970]  ; [pp+0x5970] Null
    // 0x872f50: blr             x9
    // 0x872f54: r0 = LoadStaticField(0x67c)
    //     0x872f54: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x872f58: ldr             x0, [x0, #0xcf8]
    // 0x872f5c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x872f60: cmp             w0, w16
    // 0x872f64: b.ne            #0x872f70
    // 0x872f68: r2 = _instance
    //     0x872f68: ldr             x2, [PP, #0x30b0]  ; [pp+0x30b0] Field <TextInput._instance@81206165>: static late final (offset: 0x67c)
    // 0x872f6c: r0 = InitLateFinalStaticField()
    //     0x872f6c: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x872f70: LoadField: r1 = r0->field_f
    //     0x872f70: ldur            w1, [x0, #0xf]
    // 0x872f74: DecompressPointer r1
    //     0x872f74: add             x1, x1, HEAP, lsl #32
    // 0x872f78: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x872f7c: cmp             w1, w16
    // 0x872f80: b.eq            #0x873008
    // 0x872f84: r16 = <void?>
    //     0x872f84: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x872f88: r30 = Instance_OptionalMethodChannel
    //     0x872f88: ldr             lr, [PP, #0x43b0]  ; [pp+0x43b0] Obj!OptionalMethodChannel@129bea1
    // 0x872f8c: stp             lr, x16, [SP, #8]
    // 0x872f90: r16 = "TextInput.show"
    //     0x872f90: ldr             x16, [PP, #0x5980]  ; [pp+0x5980] "TextInput.show"
    // 0x872f94: str             x16, [SP]
    // 0x872f98: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x872f98: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x872f9c: r0 = invokeMethod()
    //     0x872f9c: bl              #0x130ad0c  ; [package:flutter/src/services/platform_channel.dart] OptionalMethodChannel::invokeMethod
    // 0x872fa0: r1 = Function '<anonymous closure>':.
    //     0x872fa0: ldr             x1, [PP, #0x5988]  ; [pp+0x5988] Function: [dart:ui] Shader::Shader._ (0x13cf838)
    // 0x872fa4: r2 = Null
    //     0x872fa4: mov             x2, NULL
    // 0x872fa8: stur            x0, [fp, #-0x18]
    // 0x872fac: r0 = AllocateClosure()
    //     0x872fac: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x872fb0: r1 = Function '<anonymous closure>':.
    //     0x872fb0: ldr             x1, [PP, #0x5990]  ; [pp+0x5990] AnonymousClosure: (0x873010), of [package:flutter/src/services/text_input.dart] _PlatformTextInputControl
    // 0x872fb4: r2 = Null
    //     0x872fb4: mov             x2, NULL
    // 0x872fb8: stur            x0, [fp, #-0x20]
    // 0x872fbc: r0 = AllocateClosure()
    //     0x872fbc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x872fc0: r16 = <Null?>
    //     0x872fc0: ldr             x16, [PP, #0x70]  ; [pp+0x70] TypeArguments: <Null?>
    // 0x872fc4: ldur            lr, [fp, #-0x18]
    // 0x872fc8: stp             lr, x16, [SP, #0x10]
    // 0x872fcc: ldur            x16, [fp, #-0x20]
    // 0x872fd0: stp             x0, x16, [SP]
    // 0x872fd4: r4 = const [0x1, 0x3, 0x3, 0x2, onError, 0x2, null]
    //     0x872fd4: ldr             x4, [PP, #0x538]  ; [pp+0x538] List(7) [0x1, 0x3, 0x3, 0x2, "onError", 0x2, Null]
    // 0x872fd8: r0 = then()
    //     0x872fd8: bl              #0x1293070  ; [dart:async] _Future::then
    // 0x872fdc: ldur            x0, [fp, #-0x10]
    // 0x872fe0: ldur            x2, [fp, #-8]
    // 0x872fe4: b               #0x872f00
    // 0x872fe8: r0 = Null
    //     0x872fe8: mov             x0, NULL
    // 0x872fec: LeaveFrame
    //     0x872fec: mov             SP, fp
    //     0x872ff0: ldp             fp, lr, [SP], #0x10
    // 0x872ff4: ret
    //     0x872ff4: ret             
    // 0x872ff8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x872ff8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x872ffc: b               #0x872ee0
    // 0x873000: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x873000: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x873004: b               #0x872f0c
    // 0x873008: r9 = _channel
    //     0x873008: ldr             x9, [PP, #0x5968]  ; [pp+0x5968] Field <TextInput._channel@81206165>: late (offset: 0x10)
    // 0x87300c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x87300c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _updateStyle(/* No info */) {
    // ** addr: 0x8730ac, size: 0x158
    // 0x8730ac: EnterFrame
    //     0x8730ac: stp             fp, lr, [SP, #-0x10]!
    //     0x8730b0: mov             fp, SP
    // 0x8730b4: AllocStack(0x48)
    //     0x8730b4: sub             SP, SP, #0x48
    // 0x8730b8: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0x8730b8: mov             x0, x2
    //     0x8730bc: stur            x2, [fp, #-8]
    // 0x8730c0: CheckStackOverflow
    //     0x8730c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8730c4: cmp             SP, x16
    //     0x8730c8: b.ls            #0x8731ec
    // 0x8730cc: LoadField: r2 = r1->field_b
    //     0x8730cc: ldur            w2, [x1, #0xb]
    // 0x8730d0: DecompressPointer r2
    //     0x8730d0: add             x2, x2, HEAP, lsl #32
    // 0x8730d4: mov             x1, x2
    // 0x8730d8: r0 = iterator()
    //     0x8730d8: bl              #0xbb7c60  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0x8730dc: stur            x0, [fp, #-0x18]
    // 0x8730e0: LoadField: r2 = r0->field_7
    //     0x8730e0: ldur            w2, [x0, #7]
    // 0x8730e4: DecompressPointer r2
    //     0x8730e4: add             x2, x2, HEAP, lsl #32
    // 0x8730e8: stur            x2, [fp, #-0x10]
    // 0x8730ec: CheckStackOverflow
    //     0x8730ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8730f0: cmp             SP, x16
    //     0x8730f4: b.ls            #0x8731f4
    // 0x8730f8: mov             x1, x0
    // 0x8730fc: r0 = moveNext()
    //     0x8730fc: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0x873100: tbnz            w0, #4, #0x8731dc
    // 0x873104: ldur            x3, [fp, #-0x18]
    // 0x873108: LoadField: r0 = r3->field_33
    //     0x873108: ldur            w0, [x3, #0x33]
    // 0x87310c: DecompressPointer r0
    //     0x87310c: add             x0, x0, HEAP, lsl #32
    // 0x873110: cmp             w0, NULL
    // 0x873114: b.ne            #0x873140
    // 0x873118: ldur            x2, [fp, #-0x10]
    // 0x87311c: r1 = Null
    //     0x87311c: mov             x1, NULL
    // 0x873120: cmp             w2, NULL
    // 0x873124: b.eq            #0x873140
    // 0x873128: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x873128: ldur            w4, [x2, #0x17]
    // 0x87312c: DecompressPointer r4
    //     0x87312c: add             x4, x4, HEAP, lsl #32
    // 0x873130: r8 = X0
    //     0x873130: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x873134: LoadField: r9 = r4->field_7
    //     0x873134: ldur            x9, [x4, #7]
    // 0x873138: r3 = Null
    //     0x873138: ldr             x3, [PP, #0x59a0]  ; [pp+0x59a0] Null
    // 0x87313c: blr             x9
    // 0x873140: r0 = LoadStaticField(0x67c)
    //     0x873140: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x873144: ldr             x0, [x0, #0xcf8]
    // 0x873148: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x87314c: cmp             w0, w16
    // 0x873150: b.ne            #0x87315c
    // 0x873154: r2 = _instance
    //     0x873154: ldr             x2, [PP, #0x30b0]  ; [pp+0x30b0] Field <TextInput._instance@81206165>: static late final (offset: 0x67c)
    // 0x873158: r0 = InitLateFinalStaticField()
    //     0x873158: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x87315c: LoadField: r1 = r0->field_f
    //     0x87315c: ldur            w1, [x0, #0xf]
    // 0x873160: DecompressPointer r1
    //     0x873160: add             x1, x1, HEAP, lsl #32
    // 0x873164: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x873168: cmp             w1, w16
    // 0x87316c: b.eq            #0x8731fc
    // 0x873170: ldur            x1, [fp, #-8]
    // 0x873174: r0 = toJson()
    //     0x873174: bl              #0x873204  ; [package:flutter/src/services/text_input.dart] TextInputStyle::toJson
    // 0x873178: r16 = <void?>
    //     0x873178: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x87317c: r30 = Instance_OptionalMethodChannel
    //     0x87317c: ldr             lr, [PP, #0x43b0]  ; [pp+0x43b0] Obj!OptionalMethodChannel@129bea1
    // 0x873180: stp             lr, x16, [SP, #0x10]
    // 0x873184: r16 = "TextInput.setStyle"
    //     0x873184: ldr             x16, [PP, #0x59b0]  ; [pp+0x59b0] "TextInput.setStyle"
    // 0x873188: stp             x0, x16, [SP]
    // 0x87318c: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x87318c: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x873190: r0 = invokeMethod()
    //     0x873190: bl              #0x130ad0c  ; [package:flutter/src/services/platform_channel.dart] OptionalMethodChannel::invokeMethod
    // 0x873194: r1 = Function '<anonymous closure>':.
    //     0x873194: ldr             x1, [PP, #0x59b8]  ; [pp+0x59b8] Function: [dart:ui] Shader::Shader._ (0x13cf838)
    // 0x873198: r2 = Null
    //     0x873198: mov             x2, NULL
    // 0x87319c: stur            x0, [fp, #-0x20]
    // 0x8731a0: r0 = AllocateClosure()
    //     0x8731a0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8731a4: r1 = Function '<anonymous closure>':.
    //     0x8731a4: ldr             x1, [PP, #0x59c0]  ; [pp+0x59c0] AnonymousClosure: (0x873528), of [package:flutter/src/services/text_input.dart] _PlatformTextInputControl
    // 0x8731a8: r2 = Null
    //     0x8731a8: mov             x2, NULL
    // 0x8731ac: stur            x0, [fp, #-0x28]
    // 0x8731b0: r0 = AllocateClosure()
    //     0x8731b0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8731b4: r16 = <Null?>
    //     0x8731b4: ldr             x16, [PP, #0x70]  ; [pp+0x70] TypeArguments: <Null?>
    // 0x8731b8: ldur            lr, [fp, #-0x20]
    // 0x8731bc: stp             lr, x16, [SP, #0x10]
    // 0x8731c0: ldur            x16, [fp, #-0x28]
    // 0x8731c4: stp             x0, x16, [SP]
    // 0x8731c8: r4 = const [0x1, 0x3, 0x3, 0x2, onError, 0x2, null]
    //     0x8731c8: ldr             x4, [PP, #0x538]  ; [pp+0x538] List(7) [0x1, 0x3, 0x3, 0x2, "onError", 0x2, Null]
    // 0x8731cc: r0 = then()
    //     0x8731cc: bl              #0x1293070  ; [dart:async] _Future::then
    // 0x8731d0: ldur            x0, [fp, #-0x18]
    // 0x8731d4: ldur            x2, [fp, #-0x10]
    // 0x8731d8: b               #0x8730ec
    // 0x8731dc: r0 = Null
    //     0x8731dc: mov             x0, NULL
    // 0x8731e0: LeaveFrame
    //     0x8731e0: mov             SP, fp
    //     0x8731e4: ldp             fp, lr, [SP], #0x10
    // 0x8731e8: ret
    //     0x8731e8: ret             
    // 0x8731ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8731ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8731f0: b               #0x8730cc
    // 0x8731f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8731f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8731f8: b               #0x8730f8
    // 0x8731fc: r9 = _channel
    //     0x8731fc: ldr             x9, [PP, #0x5968]  ; [pp+0x5968] Field <TextInput._channel@81206165>: late (offset: 0x10)
    // 0x873200: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x873200: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _setCaretRect(/* No info */) {
    // ** addr: 0x873c08, size: 0xd0
    // 0x873c08: EnterFrame
    //     0x873c08: stp             fp, lr, [SP, #-0x10]!
    //     0x873c0c: mov             fp, SP
    // 0x873c10: AllocStack(0x20)
    //     0x873c10: sub             SP, SP, #0x20
    // 0x873c14: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x873c14: stur            x2, [fp, #-8]
    // 0x873c18: CheckStackOverflow
    //     0x873c18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x873c1c: cmp             SP, x16
    //     0x873c20: b.ls            #0x873cc8
    // 0x873c24: LoadField: r0 = r1->field_b
    //     0x873c24: ldur            w0, [x1, #0xb]
    // 0x873c28: DecompressPointer r0
    //     0x873c28: add             x0, x0, HEAP, lsl #32
    // 0x873c2c: mov             x1, x0
    // 0x873c30: r0 = iterator()
    //     0x873c30: bl              #0xbb7c60  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0x873c34: stur            x0, [fp, #-0x18]
    // 0x873c38: LoadField: r2 = r0->field_7
    //     0x873c38: ldur            w2, [x0, #7]
    // 0x873c3c: DecompressPointer r2
    //     0x873c3c: add             x2, x2, HEAP, lsl #32
    // 0x873c40: stur            x2, [fp, #-0x10]
    // 0x873c44: CheckStackOverflow
    //     0x873c44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x873c48: cmp             SP, x16
    //     0x873c4c: b.ls            #0x873cd0
    // 0x873c50: mov             x1, x0
    // 0x873c54: r0 = moveNext()
    //     0x873c54: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0x873c58: tbnz            w0, #4, #0x873cb8
    // 0x873c5c: ldur            x3, [fp, #-0x18]
    // 0x873c60: LoadField: r4 = r3->field_33
    //     0x873c60: ldur            w4, [x3, #0x33]
    // 0x873c64: DecompressPointer r4
    //     0x873c64: add             x4, x4, HEAP, lsl #32
    // 0x873c68: stur            x4, [fp, #-0x20]
    // 0x873c6c: cmp             w4, NULL
    // 0x873c70: b.ne            #0x873ca0
    // 0x873c74: mov             x0, x4
    // 0x873c78: ldur            x2, [fp, #-0x10]
    // 0x873c7c: r1 = Null
    //     0x873c7c: mov             x1, NULL
    // 0x873c80: cmp             w2, NULL
    // 0x873c84: b.eq            #0x873ca0
    // 0x873c88: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x873c88: ldur            w4, [x2, #0x17]
    // 0x873c8c: DecompressPointer r4
    //     0x873c8c: add             x4, x4, HEAP, lsl #32
    // 0x873c90: r8 = X0
    //     0x873c90: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x873c94: LoadField: r9 = r4->field_7
    //     0x873c94: ldur            x9, [x4, #7]
    // 0x873c98: r3 = Null
    //     0x873c98: ldr             x3, [PP, #0x5a30]  ; [pp+0x5a30] Null
    // 0x873c9c: blr             x9
    // 0x873ca0: ldur            x1, [fp, #-0x20]
    // 0x873ca4: ldur            x2, [fp, #-8]
    // 0x873ca8: r0 = setCaretRect()
    //     0x873ca8: bl              #0x873cd8  ; [package:flutter/src/services/text_input.dart] _PlatformTextInputControl::setCaretRect
    // 0x873cac: ldur            x0, [fp, #-0x18]
    // 0x873cb0: ldur            x2, [fp, #-0x10]
    // 0x873cb4: b               #0x873c44
    // 0x873cb8: r0 = Null
    //     0x873cb8: mov             x0, NULL
    // 0x873cbc: LeaveFrame
    //     0x873cbc: mov             SP, fp
    //     0x873cc0: ldp             fp, lr, [SP], #0x10
    // 0x873cc4: ret
    //     0x873cc4: ret             
    // 0x873cc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x873cc8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x873ccc: b               #0x873c24
    // 0x873cd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x873cd0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x873cd4: b               #0x873c50
  }
  _ _setComposingTextRect(/* No info */) {
    // ** addr: 0x874268, size: 0xd0
    // 0x874268: EnterFrame
    //     0x874268: stp             fp, lr, [SP, #-0x10]!
    //     0x87426c: mov             fp, SP
    // 0x874270: AllocStack(0x20)
    //     0x874270: sub             SP, SP, #0x20
    // 0x874274: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x874274: stur            x2, [fp, #-8]
    // 0x874278: CheckStackOverflow
    //     0x874278: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87427c: cmp             SP, x16
    //     0x874280: b.ls            #0x874328
    // 0x874284: LoadField: r0 = r1->field_b
    //     0x874284: ldur            w0, [x1, #0xb]
    // 0x874288: DecompressPointer r0
    //     0x874288: add             x0, x0, HEAP, lsl #32
    // 0x87428c: mov             x1, x0
    // 0x874290: r0 = iterator()
    //     0x874290: bl              #0xbb7c60  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0x874294: stur            x0, [fp, #-0x18]
    // 0x874298: LoadField: r2 = r0->field_7
    //     0x874298: ldur            w2, [x0, #7]
    // 0x87429c: DecompressPointer r2
    //     0x87429c: add             x2, x2, HEAP, lsl #32
    // 0x8742a0: stur            x2, [fp, #-0x10]
    // 0x8742a4: CheckStackOverflow
    //     0x8742a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8742a8: cmp             SP, x16
    //     0x8742ac: b.ls            #0x874330
    // 0x8742b0: mov             x1, x0
    // 0x8742b4: r0 = moveNext()
    //     0x8742b4: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0x8742b8: tbnz            w0, #4, #0x874318
    // 0x8742bc: ldur            x3, [fp, #-0x18]
    // 0x8742c0: LoadField: r4 = r3->field_33
    //     0x8742c0: ldur            w4, [x3, #0x33]
    // 0x8742c4: DecompressPointer r4
    //     0x8742c4: add             x4, x4, HEAP, lsl #32
    // 0x8742c8: stur            x4, [fp, #-0x20]
    // 0x8742cc: cmp             w4, NULL
    // 0x8742d0: b.ne            #0x874300
    // 0x8742d4: mov             x0, x4
    // 0x8742d8: ldur            x2, [fp, #-0x10]
    // 0x8742dc: r1 = Null
    //     0x8742dc: mov             x1, NULL
    // 0x8742e0: cmp             w2, NULL
    // 0x8742e4: b.eq            #0x874300
    // 0x8742e8: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x8742e8: ldur            w4, [x2, #0x17]
    // 0x8742ec: DecompressPointer r4
    //     0x8742ec: add             x4, x4, HEAP, lsl #32
    // 0x8742f0: r8 = X0
    //     0x8742f0: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x8742f4: LoadField: r9 = r4->field_7
    //     0x8742f4: ldur            x9, [x4, #7]
    // 0x8742f8: r3 = Null
    //     0x8742f8: ldr             x3, [PP, #0x5a78]  ; [pp+0x5a78] Null
    // 0x8742fc: blr             x9
    // 0x874300: ldur            x1, [fp, #-0x20]
    // 0x874304: ldur            x2, [fp, #-8]
    // 0x874308: r0 = setComposingRect()
    //     0x874308: bl              #0x874338  ; [package:flutter/src/services/text_input.dart] _PlatformTextInputControl::setComposingRect
    // 0x87430c: ldur            x0, [fp, #-0x18]
    // 0x874310: ldur            x2, [fp, #-0x10]
    // 0x874314: b               #0x8742a4
    // 0x874318: r0 = Null
    //     0x874318: mov             x0, NULL
    // 0x87431c: LeaveFrame
    //     0x87431c: mov             SP, fp
    //     0x874320: ldp             fp, lr, [SP], #0x10
    // 0x874324: ret
    //     0x874324: ret             
    // 0x874328: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x874328: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87432c: b               #0x874284
    // 0x874330: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x874330: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x874334: b               #0x8742b0
  }
  _ _setEditableSizeAndTransform(/* No info */) {
    // ** addr: 0x87480c, size: 0xd8
    // 0x87480c: EnterFrame
    //     0x87480c: stp             fp, lr, [SP, #-0x10]!
    //     0x874810: mov             fp, SP
    // 0x874814: AllocStack(0x28)
    //     0x874814: sub             SP, SP, #0x28
    // 0x874818: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0x874818: stur            x2, [fp, #-8]
    //     0x87481c: stur            x3, [fp, #-0x10]
    // 0x874820: CheckStackOverflow
    //     0x874820: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x874824: cmp             SP, x16
    //     0x874828: b.ls            #0x8748d4
    // 0x87482c: LoadField: r0 = r1->field_b
    //     0x87482c: ldur            w0, [x1, #0xb]
    // 0x874830: DecompressPointer r0
    //     0x874830: add             x0, x0, HEAP, lsl #32
    // 0x874834: mov             x1, x0
    // 0x874838: r0 = iterator()
    //     0x874838: bl              #0xbb7c60  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0x87483c: stur            x0, [fp, #-0x20]
    // 0x874840: LoadField: r2 = r0->field_7
    //     0x874840: ldur            w2, [x0, #7]
    // 0x874844: DecompressPointer r2
    //     0x874844: add             x2, x2, HEAP, lsl #32
    // 0x874848: stur            x2, [fp, #-0x18]
    // 0x87484c: CheckStackOverflow
    //     0x87484c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x874850: cmp             SP, x16
    //     0x874854: b.ls            #0x8748dc
    // 0x874858: mov             x1, x0
    // 0x87485c: r0 = moveNext()
    //     0x87485c: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0x874860: tbnz            w0, #4, #0x8748c4
    // 0x874864: ldur            x3, [fp, #-0x20]
    // 0x874868: LoadField: r4 = r3->field_33
    //     0x874868: ldur            w4, [x3, #0x33]
    // 0x87486c: DecompressPointer r4
    //     0x87486c: add             x4, x4, HEAP, lsl #32
    // 0x874870: stur            x4, [fp, #-0x28]
    // 0x874874: cmp             w4, NULL
    // 0x874878: b.ne            #0x8748a8
    // 0x87487c: mov             x0, x4
    // 0x874880: ldur            x2, [fp, #-0x18]
    // 0x874884: r1 = Null
    //     0x874884: mov             x1, NULL
    // 0x874888: cmp             w2, NULL
    // 0x87488c: b.eq            #0x8748a8
    // 0x874890: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x874890: ldur            w4, [x2, #0x17]
    // 0x874894: DecompressPointer r4
    //     0x874894: add             x4, x4, HEAP, lsl #32
    // 0x874898: r8 = X0
    //     0x874898: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x87489c: LoadField: r9 = r4->field_7
    //     0x87489c: ldur            x9, [x4, #7]
    // 0x8748a0: r3 = Null
    //     0x8748a0: ldr             x3, [PP, #0x5aa8]  ; [pp+0x5aa8] Null
    // 0x8748a4: blr             x9
    // 0x8748a8: ldur            x1, [fp, #-0x28]
    // 0x8748ac: ldur            x2, [fp, #-8]
    // 0x8748b0: ldur            x3, [fp, #-0x10]
    // 0x8748b4: r0 = setEditableSizeAndTransform()
    //     0x8748b4: bl              #0x8748e4  ; [package:flutter/src/services/text_input.dart] _PlatformTextInputControl::setEditableSizeAndTransform
    // 0x8748b8: ldur            x0, [fp, #-0x20]
    // 0x8748bc: ldur            x2, [fp, #-0x18]
    // 0x8748c0: b               #0x87484c
    // 0x8748c4: r0 = Null
    //     0x8748c4: mov             x0, NULL
    // 0x8748c8: LeaveFrame
    //     0x8748c8: mov             SP, fp
    //     0x8748cc: ldp             fp, lr, [SP], #0x10
    // 0x8748d0: ret
    //     0x8748d0: ret             
    // 0x8748d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8748d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8748d8: b               #0x87482c
    // 0x8748dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8748dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8748e0: b               #0x874858
  }
  static _ attach(/* No info */) {
    // ** addr: 0x874ad0, size: 0x80
    // 0x874ad0: EnterFrame
    //     0x874ad0: stp             fp, lr, [SP, #-0x10]!
    //     0x874ad4: mov             fp, SP
    // 0x874ad8: AllocStack(0x10)
    //     0x874ad8: sub             SP, SP, #0x10
    // 0x874adc: SetupParameters(dynamic _ /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x874adc: mov             x3, x2
    //     0x874ae0: stur            x2, [fp, #-0x10]
    //     0x874ae4: mov             x2, x1
    //     0x874ae8: stur            x1, [fp, #-8]
    // 0x874aec: CheckStackOverflow
    //     0x874aec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x874af0: cmp             SP, x16
    //     0x874af4: b.ls            #0x874b48
    // 0x874af8: r0 = TextInputConnection()
    //     0x874af8: bl              #0x874c38  ; AllocateTextInputConnectionStub -> TextInputConnection (size=0x28)
    // 0x874afc: mov             x1, x0
    // 0x874b00: ldur            x2, [fp, #-8]
    // 0x874b04: stur            x0, [fp, #-8]
    // 0x874b08: r0 = TextInputConnection._()
    //     0x874b08: bl              #0x874b50  ; [package:flutter/src/services/text_input.dart] TextInputConnection::TextInputConnection._
    // 0x874b0c: r0 = LoadStaticField(0x67c)
    //     0x874b0c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x874b10: ldr             x0, [x0, #0xcf8]
    // 0x874b14: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x874b18: cmp             w0, w16
    // 0x874b1c: b.ne            #0x874b28
    // 0x874b20: r2 = _instance
    //     0x874b20: ldr             x2, [PP, #0x30b0]  ; [pp+0x30b0] Field <TextInput._instance@81206165>: static late final (offset: 0x67c)
    // 0x874b24: r0 = InitLateFinalStaticField()
    //     0x874b24: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x874b28: mov             x1, x0
    // 0x874b2c: ldur            x2, [fp, #-8]
    // 0x874b30: ldur            x3, [fp, #-0x10]
    // 0x874b34: r0 = _attach()
    //     0x874b34: bl              #0x878560  ; [package:flutter/src/services/text_input.dart] TextInput::_attach
    // 0x874b38: ldur            x0, [fp, #-8]
    // 0x874b3c: LeaveFrame
    //     0x874b3c: mov             SP, fp
    //     0x874b40: ldp             fp, lr, [SP], #0x10
    // 0x874b44: ret
    //     0x874b44: ret             
    // 0x874b48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x874b48: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x874b4c: b               #0x874af8
  }
  _ _clearClient(/* No info */) {
    // ** addr: 0x875bd4, size: 0x16c
    // 0x875bd4: EnterFrame
    //     0x875bd4: stp             fp, lr, [SP, #-0x10]!
    //     0x875bd8: mov             fp, SP
    // 0x875bdc: AllocStack(0x48)
    //     0x875bdc: sub             SP, SP, #0x48
    // 0x875be0: SetupParameters(TextInput this /* r1 => r0, fp-0x8 */)
    //     0x875be0: mov             x0, x1
    //     0x875be4: stur            x1, [fp, #-8]
    // 0x875be8: CheckStackOverflow
    //     0x875be8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x875bec: cmp             SP, x16
    //     0x875bf0: b.ls            #0x875d24
    // 0x875bf4: LoadField: r1 = r0->field_13
    //     0x875bf4: ldur            w1, [x0, #0x13]
    // 0x875bf8: DecompressPointer r1
    //     0x875bf8: add             x1, x1, HEAP, lsl #32
    // 0x875bfc: cmp             w1, NULL
    // 0x875c00: b.eq            #0x875d2c
    // 0x875c04: LoadField: r1 = r0->field_b
    //     0x875c04: ldur            w1, [x0, #0xb]
    // 0x875c08: DecompressPointer r1
    //     0x875c08: add             x1, x1, HEAP, lsl #32
    // 0x875c0c: r0 = iterator()
    //     0x875c0c: bl              #0xbb7c60  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0x875c10: stur            x0, [fp, #-0x18]
    // 0x875c14: LoadField: r2 = r0->field_7
    //     0x875c14: ldur            w2, [x0, #7]
    // 0x875c18: DecompressPointer r2
    //     0x875c18: add             x2, x2, HEAP, lsl #32
    // 0x875c1c: stur            x2, [fp, #-0x10]
    // 0x875c20: CheckStackOverflow
    //     0x875c20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x875c24: cmp             SP, x16
    //     0x875c28: b.ls            #0x875d30
    // 0x875c2c: mov             x1, x0
    // 0x875c30: r0 = moveNext()
    //     0x875c30: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0x875c34: tbnz            w0, #4, #0x875d08
    // 0x875c38: ldur            x3, [fp, #-0x18]
    // 0x875c3c: LoadField: r0 = r3->field_33
    //     0x875c3c: ldur            w0, [x3, #0x33]
    // 0x875c40: DecompressPointer r0
    //     0x875c40: add             x0, x0, HEAP, lsl #32
    // 0x875c44: cmp             w0, NULL
    // 0x875c48: b.ne            #0x875c74
    // 0x875c4c: ldur            x2, [fp, #-0x10]
    // 0x875c50: r1 = Null
    //     0x875c50: mov             x1, NULL
    // 0x875c54: cmp             w2, NULL
    // 0x875c58: b.eq            #0x875c74
    // 0x875c5c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x875c5c: ldur            w4, [x2, #0x17]
    // 0x875c60: DecompressPointer r4
    //     0x875c60: add             x4, x4, HEAP, lsl #32
    // 0x875c64: r8 = X0
    //     0x875c64: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x875c68: LoadField: r9 = r4->field_7
    //     0x875c68: ldur            x9, [x4, #7]
    // 0x875c6c: r3 = Null
    //     0x875c6c: ldr             x3, [PP, #0x5bb0]  ; [pp+0x5bb0] Null
    // 0x875c70: blr             x9
    // 0x875c74: r0 = LoadStaticField(0x67c)
    //     0x875c74: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x875c78: ldr             x0, [x0, #0xcf8]
    // 0x875c7c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x875c80: cmp             w0, w16
    // 0x875c84: b.ne            #0x875c90
    // 0x875c88: r2 = _instance
    //     0x875c88: ldr             x2, [PP, #0x30b0]  ; [pp+0x30b0] Field <TextInput._instance@81206165>: static late final (offset: 0x67c)
    // 0x875c8c: r0 = InitLateFinalStaticField()
    //     0x875c8c: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x875c90: LoadField: r1 = r0->field_f
    //     0x875c90: ldur            w1, [x0, #0xf]
    // 0x875c94: DecompressPointer r1
    //     0x875c94: add             x1, x1, HEAP, lsl #32
    // 0x875c98: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x875c9c: cmp             w1, w16
    // 0x875ca0: b.eq            #0x875d38
    // 0x875ca4: r16 = <void?>
    //     0x875ca4: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x875ca8: r30 = Instance_OptionalMethodChannel
    //     0x875ca8: ldr             lr, [PP, #0x43b0]  ; [pp+0x43b0] Obj!OptionalMethodChannel@129bea1
    // 0x875cac: stp             lr, x16, [SP, #8]
    // 0x875cb0: r16 = "TextInput.clearClient"
    //     0x875cb0: ldr             x16, [PP, #0x5bc0]  ; [pp+0x5bc0] "TextInput.clearClient"
    // 0x875cb4: str             x16, [SP]
    // 0x875cb8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x875cb8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x875cbc: r0 = invokeMethod()
    //     0x875cbc: bl              #0x130ad0c  ; [package:flutter/src/services/platform_channel.dart] OptionalMethodChannel::invokeMethod
    // 0x875cc0: r1 = Function '<anonymous closure>':.
    //     0x875cc0: ldr             x1, [PP, #0x5bc8]  ; [pp+0x5bc8] Function: [dart:ui] Shader::Shader._ (0x13cf838)
    // 0x875cc4: r2 = Null
    //     0x875cc4: mov             x2, NULL
    // 0x875cc8: stur            x0, [fp, #-0x20]
    // 0x875ccc: r0 = AllocateClosure()
    //     0x875ccc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x875cd0: r1 = Function '<anonymous closure>':.
    //     0x875cd0: ldr             x1, [PP, #0x5bd0]  ; [pp+0x5bd0] AnonymousClosure: (0x875fa4), of [package:flutter/src/services/text_input.dart] _PlatformTextInputControl
    // 0x875cd4: r2 = Null
    //     0x875cd4: mov             x2, NULL
    // 0x875cd8: stur            x0, [fp, #-0x28]
    // 0x875cdc: r0 = AllocateClosure()
    //     0x875cdc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x875ce0: r16 = <Null?>
    //     0x875ce0: ldr             x16, [PP, #0x70]  ; [pp+0x70] TypeArguments: <Null?>
    // 0x875ce4: ldur            lr, [fp, #-0x20]
    // 0x875ce8: stp             lr, x16, [SP, #0x10]
    // 0x875cec: ldur            x16, [fp, #-0x28]
    // 0x875cf0: stp             x0, x16, [SP]
    // 0x875cf4: r4 = const [0x1, 0x3, 0x3, 0x2, onError, 0x2, null]
    //     0x875cf4: ldr             x4, [PP, #0x538]  ; [pp+0x538] List(7) [0x1, 0x3, 0x3, 0x2, "onError", 0x2, Null]
    // 0x875cf8: r0 = then()
    //     0x875cf8: bl              #0x1293070  ; [dart:async] _Future::then
    // 0x875cfc: ldur            x0, [fp, #-0x18]
    // 0x875d00: ldur            x2, [fp, #-0x10]
    // 0x875d04: b               #0x875c20
    // 0x875d08: ldur            x1, [fp, #-8]
    // 0x875d0c: StoreField: r1->field_13 = rNULL
    //     0x875d0c: stur            NULL, [x1, #0x13]
    // 0x875d10: r0 = _scheduleHide()
    //     0x875d10: bl              #0x875d40  ; [package:flutter/src/services/text_input.dart] TextInput::_scheduleHide
    // 0x875d14: r0 = Null
    //     0x875d14: mov             x0, NULL
    // 0x875d18: LeaveFrame
    //     0x875d18: mov             SP, fp
    //     0x875d1c: ldp             fp, lr, [SP], #0x10
    // 0x875d20: ret
    //     0x875d20: ret             
    // 0x875d24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x875d24: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x875d28: b               #0x875bf4
    // 0x875d2c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x875d2c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x875d30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x875d30: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x875d34: b               #0x875c2c
    // 0x875d38: r9 = _channel
    //     0x875d38: ldr             x9, [PP, #0x5968]  ; [pp+0x5968] Field <TextInput._channel@81206165>: late (offset: 0x10)
    // 0x875d3c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x875d3c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _scheduleHide(/* No info */) {
    // ** addr: 0x875d40, size: 0x80
    // 0x875d40: EnterFrame
    //     0x875d40: stp             fp, lr, [SP, #-0x10]!
    //     0x875d44: mov             fp, SP
    // 0x875d48: AllocStack(0x10)
    //     0x875d48: sub             SP, SP, #0x10
    // 0x875d4c: SetupParameters(TextInput this /* r1 => r1, fp-0x8 */)
    //     0x875d4c: stur            x1, [fp, #-8]
    // 0x875d50: CheckStackOverflow
    //     0x875d50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x875d54: cmp             SP, x16
    //     0x875d58: b.ls            #0x875db8
    // 0x875d5c: r1 = 1
    //     0x875d5c: mov             x1, #1
    // 0x875d60: r0 = AllocateContext()
    //     0x875d60: bl              #0x13de838  ; AllocateContextStub
    // 0x875d64: mov             x1, x0
    // 0x875d68: ldur            x0, [fp, #-8]
    // 0x875d6c: StoreField: r1->field_f = r0
    //     0x875d6c: stur            w0, [x1, #0xf]
    // 0x875d70: LoadField: r2 = r0->field_27
    //     0x875d70: ldur            w2, [x0, #0x27]
    // 0x875d74: DecompressPointer r2
    //     0x875d74: add             x2, x2, HEAP, lsl #32
    // 0x875d78: tbnz            w2, #4, #0x875d8c
    // 0x875d7c: r0 = Null
    //     0x875d7c: mov             x0, NULL
    // 0x875d80: LeaveFrame
    //     0x875d80: mov             SP, fp
    //     0x875d84: ldp             fp, lr, [SP], #0x10
    // 0x875d88: ret
    //     0x875d88: ret             
    // 0x875d8c: r2 = true
    //     0x875d8c: add             x2, NULL, #0x20  ; true
    // 0x875d90: StoreField: r0->field_27 = r2
    //     0x875d90: stur            w2, [x0, #0x27]
    // 0x875d94: mov             x2, x1
    // 0x875d98: r1 = Function '<anonymous closure>':.
    //     0x875d98: ldr             x1, [PP, #0x5be0]  ; [pp+0x5be0] AnonymousClosure: (0x875dc0), in [package:flutter/src/services/text_input.dart] TextInput::_scheduleHide (0x875d40)
    // 0x875d9c: r0 = AllocateClosure()
    //     0x875d9c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x875da0: str             x0, [SP]
    // 0x875da4: r0 = scheduleMicrotask()
    //     0x875da4: bl              #0x7e0298  ; [dart:async] ::scheduleMicrotask
    // 0x875da8: r0 = Null
    //     0x875da8: mov             x0, NULL
    // 0x875dac: LeaveFrame
    //     0x875dac: mov             SP, fp
    //     0x875db0: ldp             fp, lr, [SP], #0x10
    // 0x875db4: ret
    //     0x875db4: ret             
    // 0x875db8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x875db8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x875dbc: b               #0x875d5c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x875dc0, size: 0x5c
    // 0x875dc0: EnterFrame
    //     0x875dc0: stp             fp, lr, [SP, #-0x10]!
    //     0x875dc4: mov             fp, SP
    // 0x875dc8: r0 = false
    //     0x875dc8: add             x0, NULL, #0x30  ; false
    // 0x875dcc: ldr             x1, [fp, #0x10]
    // 0x875dd0: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x875dd0: ldur            w2, [x1, #0x17]
    // 0x875dd4: DecompressPointer r2
    //     0x875dd4: add             x2, x2, HEAP, lsl #32
    // 0x875dd8: CheckStackOverflow
    //     0x875dd8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x875ddc: cmp             SP, x16
    //     0x875de0: b.ls            #0x875e14
    // 0x875de4: LoadField: r1 = r2->field_f
    //     0x875de4: ldur            w1, [x2, #0xf]
    // 0x875de8: DecompressPointer r1
    //     0x875de8: add             x1, x1, HEAP, lsl #32
    // 0x875dec: StoreField: r1->field_27 = r0
    //     0x875dec: stur            w0, [x1, #0x27]
    // 0x875df0: LoadField: r0 = r1->field_13
    //     0x875df0: ldur            w0, [x1, #0x13]
    // 0x875df4: DecompressPointer r0
    //     0x875df4: add             x0, x0, HEAP, lsl #32
    // 0x875df8: cmp             w0, NULL
    // 0x875dfc: b.ne            #0x875e04
    // 0x875e00: r0 = _hide()
    //     0x875e00: bl              #0x875e1c  ; [package:flutter/src/services/text_input.dart] TextInput::_hide
    // 0x875e04: r0 = Null
    //     0x875e04: mov             x0, NULL
    // 0x875e08: LeaveFrame
    //     0x875e08: mov             SP, fp
    //     0x875e0c: ldp             fp, lr, [SP], #0x10
    // 0x875e10: ret
    //     0x875e10: ret             
    // 0x875e14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x875e14: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x875e18: b               #0x875de4
  }
  _ _hide(/* No info */) {
    // ** addr: 0x875e1c, size: 0x148
    // 0x875e1c: EnterFrame
    //     0x875e1c: stp             fp, lr, [SP, #-0x10]!
    //     0x875e20: mov             fp, SP
    // 0x875e24: AllocStack(0x40)
    //     0x875e24: sub             SP, SP, #0x40
    // 0x875e28: CheckStackOverflow
    //     0x875e28: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x875e2c: cmp             SP, x16
    //     0x875e30: b.ls            #0x875f4c
    // 0x875e34: LoadField: r0 = r1->field_b
    //     0x875e34: ldur            w0, [x1, #0xb]
    // 0x875e38: DecompressPointer r0
    //     0x875e38: add             x0, x0, HEAP, lsl #32
    // 0x875e3c: mov             x1, x0
    // 0x875e40: r0 = iterator()
    //     0x875e40: bl              #0xbb7c60  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0x875e44: stur            x0, [fp, #-0x10]
    // 0x875e48: LoadField: r2 = r0->field_7
    //     0x875e48: ldur            w2, [x0, #7]
    // 0x875e4c: DecompressPointer r2
    //     0x875e4c: add             x2, x2, HEAP, lsl #32
    // 0x875e50: stur            x2, [fp, #-8]
    // 0x875e54: CheckStackOverflow
    //     0x875e54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x875e58: cmp             SP, x16
    //     0x875e5c: b.ls            #0x875f54
    // 0x875e60: mov             x1, x0
    // 0x875e64: r0 = moveNext()
    //     0x875e64: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0x875e68: tbnz            w0, #4, #0x875f3c
    // 0x875e6c: ldur            x3, [fp, #-0x10]
    // 0x875e70: LoadField: r0 = r3->field_33
    //     0x875e70: ldur            w0, [x3, #0x33]
    // 0x875e74: DecompressPointer r0
    //     0x875e74: add             x0, x0, HEAP, lsl #32
    // 0x875e78: cmp             w0, NULL
    // 0x875e7c: b.ne            #0x875ea8
    // 0x875e80: ldur            x2, [fp, #-8]
    // 0x875e84: r1 = Null
    //     0x875e84: mov             x1, NULL
    // 0x875e88: cmp             w2, NULL
    // 0x875e8c: b.eq            #0x875ea8
    // 0x875e90: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x875e90: ldur            w4, [x2, #0x17]
    // 0x875e94: DecompressPointer r4
    //     0x875e94: add             x4, x4, HEAP, lsl #32
    // 0x875e98: r8 = X0
    //     0x875e98: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x875e9c: LoadField: r9 = r4->field_7
    //     0x875e9c: ldur            x9, [x4, #7]
    // 0x875ea0: r3 = Null
    //     0x875ea0: ldr             x3, [PP, #0x5be8]  ; [pp+0x5be8] Null
    // 0x875ea4: blr             x9
    // 0x875ea8: r0 = LoadStaticField(0x67c)
    //     0x875ea8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x875eac: ldr             x0, [x0, #0xcf8]
    // 0x875eb0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x875eb4: cmp             w0, w16
    // 0x875eb8: b.ne            #0x875ec4
    // 0x875ebc: r2 = _instance
    //     0x875ebc: ldr             x2, [PP, #0x30b0]  ; [pp+0x30b0] Field <TextInput._instance@81206165>: static late final (offset: 0x67c)
    // 0x875ec0: r0 = InitLateFinalStaticField()
    //     0x875ec0: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x875ec4: LoadField: r1 = r0->field_f
    //     0x875ec4: ldur            w1, [x0, #0xf]
    // 0x875ec8: DecompressPointer r1
    //     0x875ec8: add             x1, x1, HEAP, lsl #32
    // 0x875ecc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x875ed0: cmp             w1, w16
    // 0x875ed4: b.eq            #0x875f5c
    // 0x875ed8: r16 = <void?>
    //     0x875ed8: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x875edc: r30 = Instance_OptionalMethodChannel
    //     0x875edc: ldr             lr, [PP, #0x43b0]  ; [pp+0x43b0] Obj!OptionalMethodChannel@129bea1
    // 0x875ee0: stp             lr, x16, [SP, #8]
    // 0x875ee4: r16 = "TextInput.hide"
    //     0x875ee4: ldr             x16, [PP, #0x5bf8]  ; [pp+0x5bf8] "TextInput.hide"
    // 0x875ee8: str             x16, [SP]
    // 0x875eec: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x875eec: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x875ef0: r0 = invokeMethod()
    //     0x875ef0: bl              #0x130ad0c  ; [package:flutter/src/services/platform_channel.dart] OptionalMethodChannel::invokeMethod
    // 0x875ef4: r1 = Function '<anonymous closure>':.
    //     0x875ef4: ldr             x1, [PP, #0x5c00]  ; [pp+0x5c00] Function: [dart:ui] Shader::Shader._ (0x13cf838)
    // 0x875ef8: r2 = Null
    //     0x875ef8: mov             x2, NULL
    // 0x875efc: stur            x0, [fp, #-0x18]
    // 0x875f00: r0 = AllocateClosure()
    //     0x875f00: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x875f04: r1 = Function '<anonymous closure>':.
    //     0x875f04: ldr             x1, [PP, #0x5c08]  ; [pp+0x5c08] AnonymousClosure: (0x875f64), of [package:flutter/src/services/text_input.dart] _PlatformTextInputControl
    // 0x875f08: r2 = Null
    //     0x875f08: mov             x2, NULL
    // 0x875f0c: stur            x0, [fp, #-0x20]
    // 0x875f10: r0 = AllocateClosure()
    //     0x875f10: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x875f14: r16 = <Null?>
    //     0x875f14: ldr             x16, [PP, #0x70]  ; [pp+0x70] TypeArguments: <Null?>
    // 0x875f18: ldur            lr, [fp, #-0x18]
    // 0x875f1c: stp             lr, x16, [SP, #0x10]
    // 0x875f20: ldur            x16, [fp, #-0x20]
    // 0x875f24: stp             x0, x16, [SP]
    // 0x875f28: r4 = const [0x1, 0x3, 0x3, 0x2, onError, 0x2, null]
    //     0x875f28: ldr             x4, [PP, #0x538]  ; [pp+0x538] List(7) [0x1, 0x3, 0x3, 0x2, "onError", 0x2, Null]
    // 0x875f2c: r0 = then()
    //     0x875f2c: bl              #0x1293070  ; [dart:async] _Future::then
    // 0x875f30: ldur            x0, [fp, #-0x10]
    // 0x875f34: ldur            x2, [fp, #-8]
    // 0x875f38: b               #0x875e54
    // 0x875f3c: r0 = Null
    //     0x875f3c: mov             x0, NULL
    // 0x875f40: LeaveFrame
    //     0x875f40: mov             SP, fp
    //     0x875f44: ldp             fp, lr, [SP], #0x10
    // 0x875f48: ret
    //     0x875f48: ret             
    // 0x875f4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x875f4c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x875f50: b               #0x875e34
    // 0x875f54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x875f54: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x875f58: b               #0x875e60
    // 0x875f5c: r9 = _channel
    //     0x875f5c: ldr             x9, [PP, #0x5968]  ; [pp+0x5968] Field <TextInput._channel@81206165>: late (offset: 0x10)
    // 0x875f60: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x875f60: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _updateEditingValue(/* No info */) {
    // ** addr: 0x877088, size: 0x1d0
    // 0x877088: EnterFrame
    //     0x877088: stp             fp, lr, [SP, #-0x10]!
    //     0x87708c: mov             fp, SP
    // 0x877090: AllocStack(0x58)
    //     0x877090: sub             SP, SP, #0x58
    // 0x877094: SetupParameters(TextInput this /* r1 => r0 */, dynamic _ /* r2 => r1, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0x877094: mov             x0, x1
    //     0x877098: mov             x1, x2
    //     0x87709c: stur            x2, [fp, #-8]
    //     0x8770a0: stur            x3, [fp, #-0x10]
    // 0x8770a4: CheckStackOverflow
    //     0x8770a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8770a8: cmp             SP, x16
    //     0x8770ac: b.ls            #0x87723c
    // 0x8770b0: LoadField: r2 = r0->field_13
    //     0x8770b0: ldur            w2, [x0, #0x13]
    // 0x8770b4: DecompressPointer r2
    //     0x8770b4: add             x2, x2, HEAP, lsl #32
    // 0x8770b8: cmp             w2, NULL
    // 0x8770bc: b.ne            #0x8770d0
    // 0x8770c0: r0 = Null
    //     0x8770c0: mov             x0, NULL
    // 0x8770c4: LeaveFrame
    //     0x8770c4: mov             SP, fp
    //     0x8770c8: ldp             fp, lr, [SP], #0x10
    // 0x8770cc: ret
    //     0x8770cc: ret             
    // 0x8770d0: r0 = LoadStaticField(0x67c)
    //     0x8770d0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8770d4: ldr             x0, [x0, #0xcf8]
    // 0x8770d8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8770dc: cmp             w0, w16
    // 0x8770e0: b.ne            #0x8770ec
    // 0x8770e4: r2 = _instance
    //     0x8770e4: ldr             x2, [PP, #0x30b0]  ; [pp+0x30b0] Field <TextInput._instance@81206165>: static late final (offset: 0x67c)
    // 0x8770e8: r0 = InitLateFinalStaticField()
    //     0x8770e8: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8770ec: stur            x0, [fp, #-0x18]
    // 0x8770f0: LoadField: r1 = r0->field_b
    //     0x8770f0: ldur            w1, [x0, #0xb]
    // 0x8770f4: DecompressPointer r1
    //     0x8770f4: add             x1, x1, HEAP, lsl #32
    // 0x8770f8: r0 = iterator()
    //     0x8770f8: bl              #0xbb7c60  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0x8770fc: stur            x0, [fp, #-0x28]
    // 0x877100: LoadField: r2 = r0->field_7
    //     0x877100: ldur            w2, [x0, #7]
    // 0x877104: DecompressPointer r2
    //     0x877104: add             x2, x2, HEAP, lsl #32
    // 0x877108: stur            x2, [fp, #-0x20]
    // 0x87710c: ldur            x4, [fp, #-0x10]
    // 0x877110: ldur            x3, [fp, #-0x18]
    // 0x877114: CheckStackOverflow
    //     0x877114: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x877118: cmp             SP, x16
    //     0x87711c: b.ls            #0x877244
    // 0x877120: mov             x1, x0
    // 0x877124: r0 = moveNext()
    //     0x877124: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0x877128: tbnz            w0, #4, #0x877204
    // 0x87712c: ldur            x3, [fp, #-0x28]
    // 0x877130: LoadField: r4 = r3->field_33
    //     0x877130: ldur            w4, [x3, #0x33]
    // 0x877134: DecompressPointer r4
    //     0x877134: add             x4, x4, HEAP, lsl #32
    // 0x877138: stur            x4, [fp, #-0x30]
    // 0x87713c: cmp             w4, NULL
    // 0x877140: b.ne            #0x877170
    // 0x877144: mov             x0, x4
    // 0x877148: ldur            x2, [fp, #-0x20]
    // 0x87714c: r1 = Null
    //     0x87714c: mov             x1, NULL
    // 0x877150: cmp             w2, NULL
    // 0x877154: b.eq            #0x877170
    // 0x877158: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x877158: ldur            w4, [x2, #0x17]
    // 0x87715c: DecompressPointer r4
    //     0x87715c: add             x4, x4, HEAP, lsl #32
    // 0x877160: r8 = X0
    //     0x877160: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x877164: LoadField: r9 = r4->field_7
    //     0x877164: ldur            x9, [x4, #7]
    // 0x877168: r3 = Null
    //     0x877168: ldr             x3, [PP, #0x5fe8]  ; [pp+0x5fe8] Null
    // 0x87716c: blr             x9
    // 0x877170: ldur            x2, [fp, #-0x10]
    // 0x877174: ldur            x0, [fp, #-0x30]
    // 0x877178: cmp             w0, w2
    // 0x87717c: b.eq            #0x8771f8
    // 0x877180: ldur            x0, [fp, #-0x18]
    // 0x877184: LoadField: r1 = r0->field_f
    //     0x877184: ldur            w1, [x0, #0xf]
    // 0x877188: DecompressPointer r1
    //     0x877188: add             x1, x1, HEAP, lsl #32
    // 0x87718c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x877190: cmp             w1, w16
    // 0x877194: b.eq            #0x87724c
    // 0x877198: ldur            x1, [fp, #-8]
    // 0x87719c: r0 = toJSON()
    //     0x87719c: bl              #0x877d3c  ; [package:flutter/src/services/text_input.dart] TextEditingValue::toJSON
    // 0x8771a0: r16 = <void?>
    //     0x8771a0: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x8771a4: r30 = Instance_OptionalMethodChannel
    //     0x8771a4: ldr             lr, [PP, #0x43b0]  ; [pp+0x43b0] Obj!OptionalMethodChannel@129bea1
    // 0x8771a8: stp             lr, x16, [SP, #0x10]
    // 0x8771ac: r16 = "TextInput.setEditingState"
    //     0x8771ac: ldr             x16, [PP, #0x5ff8]  ; [pp+0x5ff8] "TextInput.setEditingState"
    // 0x8771b0: stp             x0, x16, [SP]
    // 0x8771b4: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x8771b4: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x8771b8: r0 = invokeMethod()
    //     0x8771b8: bl              #0x130ad0c  ; [package:flutter/src/services/platform_channel.dart] OptionalMethodChannel::invokeMethod
    // 0x8771bc: r1 = Function '<anonymous closure>':.
    //     0x8771bc: ldr             x1, [PP, #0x6000]  ; [pp+0x6000] Function: [dart:ui] Shader::Shader._ (0x13cf838)
    // 0x8771c0: r2 = Null
    //     0x8771c0: mov             x2, NULL
    // 0x8771c4: stur            x0, [fp, #-0x30]
    // 0x8771c8: r0 = AllocateClosure()
    //     0x8771c8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8771cc: r1 = Function '<anonymous closure>':.
    //     0x8771cc: ldr             x1, [PP, #0x6008]  ; [pp+0x6008] AnonymousClosure: (0x877f64), of [package:flutter/src/services/text_input.dart] _PlatformTextInputControl
    // 0x8771d0: r2 = Null
    //     0x8771d0: mov             x2, NULL
    // 0x8771d4: stur            x0, [fp, #-0x38]
    // 0x8771d8: r0 = AllocateClosure()
    //     0x8771d8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8771dc: r16 = <Null?>
    //     0x8771dc: ldr             x16, [PP, #0x70]  ; [pp+0x70] TypeArguments: <Null?>
    // 0x8771e0: ldur            lr, [fp, #-0x30]
    // 0x8771e4: stp             lr, x16, [SP, #0x10]
    // 0x8771e8: ldur            x16, [fp, #-0x38]
    // 0x8771ec: stp             x0, x16, [SP]
    // 0x8771f0: r4 = const [0x1, 0x3, 0x3, 0x2, onError, 0x2, null]
    //     0x8771f0: ldr             x4, [PP, #0x538]  ; [pp+0x538] List(7) [0x1, 0x3, 0x3, 0x2, "onError", 0x2, Null]
    // 0x8771f4: r0 = then()
    //     0x8771f4: bl              #0x1293070  ; [dart:async] _Future::then
    // 0x8771f8: ldur            x0, [fp, #-0x28]
    // 0x8771fc: ldur            x2, [fp, #-0x20]
    // 0x877200: b               #0x87710c
    // 0x877204: ldur            x0, [fp, #-0x18]
    // 0x877208: LoadField: r1 = r0->field_13
    //     0x877208: ldur            w1, [x0, #0x13]
    // 0x87720c: DecompressPointer r1
    //     0x87720c: add             x1, x1, HEAP, lsl #32
    // 0x877210: cmp             w1, NULL
    // 0x877214: b.eq            #0x877254
    // 0x877218: LoadField: r0 = r1->field_23
    //     0x877218: ldur            w0, [x1, #0x23]
    // 0x87721c: DecompressPointer r0
    //     0x87721c: add             x0, x0, HEAP, lsl #32
    // 0x877220: mov             x1, x0
    // 0x877224: ldur            x2, [fp, #-8]
    // 0x877228: r0 = updateEditingValue()
    //     0x877228: bl              #0x877258  ; [package:flutter/src/widgets/editable_text.dart] EditableTextState::updateEditingValue
    // 0x87722c: r0 = Null
    //     0x87722c: mov             x0, NULL
    // 0x877230: LeaveFrame
    //     0x877230: mov             SP, fp
    //     0x877234: ldp             fp, lr, [SP], #0x10
    // 0x877238: ret
    //     0x877238: ret             
    // 0x87723c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87723c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x877240: b               #0x8770b0
    // 0x877244: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x877244: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x877248: b               #0x877120
    // 0x87724c: r9 = _channel
    //     0x87724c: ldr             x9, [PP, #0x5968]  ; [pp+0x5968] Field <TextInput._channel@81206165>: late (offset: 0x10)
    // 0x877250: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x877250: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x877254: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x877254: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _setEditingState(/* No info */) {
    // ** addr: 0x8783d8, size: 0x158
    // 0x8783d8: EnterFrame
    //     0x8783d8: stp             fp, lr, [SP, #-0x10]!
    //     0x8783dc: mov             fp, SP
    // 0x8783e0: AllocStack(0x48)
    //     0x8783e0: sub             SP, SP, #0x48
    // 0x8783e4: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0x8783e4: mov             x0, x2
    //     0x8783e8: stur            x2, [fp, #-8]
    // 0x8783ec: CheckStackOverflow
    //     0x8783ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8783f0: cmp             SP, x16
    //     0x8783f4: b.ls            #0x878518
    // 0x8783f8: LoadField: r2 = r1->field_b
    //     0x8783f8: ldur            w2, [x1, #0xb]
    // 0x8783fc: DecompressPointer r2
    //     0x8783fc: add             x2, x2, HEAP, lsl #32
    // 0x878400: mov             x1, x2
    // 0x878404: r0 = iterator()
    //     0x878404: bl              #0xbb7c60  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0x878408: stur            x0, [fp, #-0x18]
    // 0x87840c: LoadField: r2 = r0->field_7
    //     0x87840c: ldur            w2, [x0, #7]
    // 0x878410: DecompressPointer r2
    //     0x878410: add             x2, x2, HEAP, lsl #32
    // 0x878414: stur            x2, [fp, #-0x10]
    // 0x878418: CheckStackOverflow
    //     0x878418: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87841c: cmp             SP, x16
    //     0x878420: b.ls            #0x878520
    // 0x878424: mov             x1, x0
    // 0x878428: r0 = moveNext()
    //     0x878428: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0x87842c: tbnz            w0, #4, #0x878508
    // 0x878430: ldur            x3, [fp, #-0x18]
    // 0x878434: LoadField: r0 = r3->field_33
    //     0x878434: ldur            w0, [x3, #0x33]
    // 0x878438: DecompressPointer r0
    //     0x878438: add             x0, x0, HEAP, lsl #32
    // 0x87843c: cmp             w0, NULL
    // 0x878440: b.ne            #0x87846c
    // 0x878444: ldur            x2, [fp, #-0x10]
    // 0x878448: r1 = Null
    //     0x878448: mov             x1, NULL
    // 0x87844c: cmp             w2, NULL
    // 0x878450: b.eq            #0x87846c
    // 0x878454: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x878454: ldur            w4, [x2, #0x17]
    // 0x878458: DecompressPointer r4
    //     0x878458: add             x4, x4, HEAP, lsl #32
    // 0x87845c: r8 = X0
    //     0x87845c: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x878460: LoadField: r9 = r4->field_7
    //     0x878460: ldur            x9, [x4, #7]
    // 0x878464: r3 = Null
    //     0x878464: ldr             x3, [PP, #0x60b0]  ; [pp+0x60b0] Null
    // 0x878468: blr             x9
    // 0x87846c: r0 = LoadStaticField(0x67c)
    //     0x87846c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x878470: ldr             x0, [x0, #0xcf8]
    // 0x878474: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x878478: cmp             w0, w16
    // 0x87847c: b.ne            #0x878488
    // 0x878480: r2 = _instance
    //     0x878480: ldr             x2, [PP, #0x30b0]  ; [pp+0x30b0] Field <TextInput._instance@81206165>: static late final (offset: 0x67c)
    // 0x878484: r0 = InitLateFinalStaticField()
    //     0x878484: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x878488: LoadField: r1 = r0->field_f
    //     0x878488: ldur            w1, [x0, #0xf]
    // 0x87848c: DecompressPointer r1
    //     0x87848c: add             x1, x1, HEAP, lsl #32
    // 0x878490: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x878494: cmp             w1, w16
    // 0x878498: b.eq            #0x878528
    // 0x87849c: ldur            x1, [fp, #-8]
    // 0x8784a0: r0 = toJSON()
    //     0x8784a0: bl              #0x877d3c  ; [package:flutter/src/services/text_input.dart] TextEditingValue::toJSON
    // 0x8784a4: r16 = <void?>
    //     0x8784a4: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x8784a8: r30 = Instance_OptionalMethodChannel
    //     0x8784a8: ldr             lr, [PP, #0x43b0]  ; [pp+0x43b0] Obj!OptionalMethodChannel@129bea1
    // 0x8784ac: stp             lr, x16, [SP, #0x10]
    // 0x8784b0: r16 = "TextInput.setEditingState"
    //     0x8784b0: ldr             x16, [PP, #0x5ff8]  ; [pp+0x5ff8] "TextInput.setEditingState"
    // 0x8784b4: stp             x0, x16, [SP]
    // 0x8784b8: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x8784b8: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x8784bc: r0 = invokeMethod()
    //     0x8784bc: bl              #0x130ad0c  ; [package:flutter/src/services/platform_channel.dart] OptionalMethodChannel::invokeMethod
    // 0x8784c0: r1 = Function '<anonymous closure>':.
    //     0x8784c0: ldr             x1, [PP, #0x6000]  ; [pp+0x6000] Function: [dart:ui] Shader::Shader._ (0x13cf838)
    // 0x8784c4: r2 = Null
    //     0x8784c4: mov             x2, NULL
    // 0x8784c8: stur            x0, [fp, #-0x20]
    // 0x8784cc: r0 = AllocateClosure()
    //     0x8784cc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8784d0: r1 = Function '<anonymous closure>':.
    //     0x8784d0: ldr             x1, [PP, #0x6008]  ; [pp+0x6008] AnonymousClosure: (0x877f64), of [package:flutter/src/services/text_input.dart] _PlatformTextInputControl
    // 0x8784d4: r2 = Null
    //     0x8784d4: mov             x2, NULL
    // 0x8784d8: stur            x0, [fp, #-0x28]
    // 0x8784dc: r0 = AllocateClosure()
    //     0x8784dc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8784e0: r16 = <Null?>
    //     0x8784e0: ldr             x16, [PP, #0x70]  ; [pp+0x70] TypeArguments: <Null?>
    // 0x8784e4: ldur            lr, [fp, #-0x20]
    // 0x8784e8: stp             lr, x16, [SP, #0x10]
    // 0x8784ec: ldur            x16, [fp, #-0x28]
    // 0x8784f0: stp             x0, x16, [SP]
    // 0x8784f4: r4 = const [0x1, 0x3, 0x3, 0x2, onError, 0x2, null]
    //     0x8784f4: ldr             x4, [PP, #0x538]  ; [pp+0x538] List(7) [0x1, 0x3, 0x3, 0x2, "onError", 0x2, Null]
    // 0x8784f8: r0 = then()
    //     0x8784f8: bl              #0x1293070  ; [dart:async] _Future::then
    // 0x8784fc: ldur            x0, [fp, #-0x18]
    // 0x878500: ldur            x2, [fp, #-0x10]
    // 0x878504: b               #0x878418
    // 0x878508: r0 = Null
    //     0x878508: mov             x0, NULL
    // 0x87850c: LeaveFrame
    //     0x87850c: mov             SP, fp
    //     0x878510: ldp             fp, lr, [SP], #0x10
    // 0x878514: ret
    //     0x878514: ret             
    // 0x878518: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x878518: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87851c: b               #0x8783f8
    // 0x878520: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x878520: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x878524: b               #0x878424
    // 0x878528: r9 = _channel
    //     0x878528: ldr             x9, [PP, #0x5968]  ; [pp+0x5968] Field <TextInput._channel@81206165>: late (offset: 0x10)
    // 0x87852c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x87852c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _attach(/* No info */) {
    // ** addr: 0x878560, size: 0xa4
    // 0x878560: EnterFrame
    //     0x878560: stp             fp, lr, [SP, #-0x10]!
    //     0x878564: mov             fp, SP
    // 0x878568: mov             x16, x3
    // 0x87856c: mov             x3, x1
    // 0x878570: mov             x1, x16
    // 0x878574: CheckStackOverflow
    //     0x878574: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x878578: cmp             SP, x16
    //     0x87857c: b.ls            #0x8785fc
    // 0x878580: mov             x0, x2
    // 0x878584: StoreField: r3->field_13 = r0
    //     0x878584: stur            w0, [x3, #0x13]
    //     0x878588: ldurb           w16, [x3, #-1]
    //     0x87858c: ldurb           w17, [x0, #-1]
    //     0x878590: and             x16, x17, x16, lsr #2
    //     0x878594: tst             x16, HEAP, lsr #32
    //     0x878598: b.eq            #0x8785a0
    //     0x87859c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x8785a0: mov             x0, x1
    // 0x8785a4: ArrayStore: r3[0] = r0  ; List_4
    //     0x8785a4: stur            w0, [x3, #0x17]
    //     0x8785a8: ldurb           w16, [x3, #-1]
    //     0x8785ac: ldurb           w17, [x0, #-1]
    //     0x8785b0: and             x16, x17, x16, lsr #2
    //     0x8785b4: tst             x16, HEAP, lsr #32
    //     0x8785b8: b.eq            #0x8785c0
    //     0x8785bc: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x8785c0: mov             x0, x2
    // 0x8785c4: StoreField: r3->field_1b = r0
    //     0x8785c4: stur            w0, [x3, #0x1b]
    //     0x8785c8: ldurb           w16, [x3, #-1]
    //     0x8785cc: ldurb           w17, [x0, #-1]
    //     0x8785d0: and             x16, x17, x16, lsr #2
    //     0x8785d4: tst             x16, HEAP, lsr #32
    //     0x8785d8: b.eq            #0x8785e0
    //     0x8785dc: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x8785e0: mov             x2, x1
    // 0x8785e4: mov             x1, x3
    // 0x8785e8: r0 = _setClient()
    //     0x8785e8: bl              #0x878604  ; [package:flutter/src/services/text_input.dart] TextInput::_setClient
    // 0x8785ec: r0 = Null
    //     0x8785ec: mov             x0, NULL
    // 0x8785f0: LeaveFrame
    //     0x8785f0: mov             SP, fp
    //     0x8785f4: ldp             fp, lr, [SP], #0x10
    // 0x8785f8: ret
    //     0x8785f8: ret             
    // 0x8785fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8785fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x878600: b               #0x878580
  }
  _ _setClient(/* No info */) {
    // ** addr: 0x878604, size: 0xd0
    // 0x878604: EnterFrame
    //     0x878604: stp             fp, lr, [SP, #-0x10]!
    //     0x878608: mov             fp, SP
    // 0x87860c: AllocStack(0x20)
    //     0x87860c: sub             SP, SP, #0x20
    // 0x878610: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x878610: stur            x2, [fp, #-8]
    // 0x878614: CheckStackOverflow
    //     0x878614: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x878618: cmp             SP, x16
    //     0x87861c: b.ls            #0x8786c4
    // 0x878620: LoadField: r0 = r1->field_b
    //     0x878620: ldur            w0, [x1, #0xb]
    // 0x878624: DecompressPointer r0
    //     0x878624: add             x0, x0, HEAP, lsl #32
    // 0x878628: mov             x1, x0
    // 0x87862c: r0 = iterator()
    //     0x87862c: bl              #0xbb7c60  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0x878630: stur            x0, [fp, #-0x18]
    // 0x878634: LoadField: r2 = r0->field_7
    //     0x878634: ldur            w2, [x0, #7]
    // 0x878638: DecompressPointer r2
    //     0x878638: add             x2, x2, HEAP, lsl #32
    // 0x87863c: stur            x2, [fp, #-0x10]
    // 0x878640: CheckStackOverflow
    //     0x878640: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x878644: cmp             SP, x16
    //     0x878648: b.ls            #0x8786cc
    // 0x87864c: mov             x1, x0
    // 0x878650: r0 = moveNext()
    //     0x878650: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0x878654: tbnz            w0, #4, #0x8786b4
    // 0x878658: ldur            x3, [fp, #-0x18]
    // 0x87865c: LoadField: r4 = r3->field_33
    //     0x87865c: ldur            w4, [x3, #0x33]
    // 0x878660: DecompressPointer r4
    //     0x878660: add             x4, x4, HEAP, lsl #32
    // 0x878664: stur            x4, [fp, #-0x20]
    // 0x878668: cmp             w4, NULL
    // 0x87866c: b.ne            #0x87869c
    // 0x878670: mov             x0, x4
    // 0x878674: ldur            x2, [fp, #-0x10]
    // 0x878678: r1 = Null
    //     0x878678: mov             x1, NULL
    // 0x87867c: cmp             w2, NULL
    // 0x878680: b.eq            #0x87869c
    // 0x878684: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x878684: ldur            w4, [x2, #0x17]
    // 0x878688: DecompressPointer r4
    //     0x878688: add             x4, x4, HEAP, lsl #32
    // 0x87868c: r8 = X0
    //     0x87868c: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x878690: LoadField: r9 = r4->field_7
    //     0x878690: ldur            x9, [x4, #7]
    // 0x878694: r3 = Null
    //     0x878694: ldr             x3, [PP, #0x60c0]  ; [pp+0x60c0] Null
    // 0x878698: blr             x9
    // 0x87869c: ldur            x1, [fp, #-0x20]
    // 0x8786a0: ldur            x2, [fp, #-8]
    // 0x8786a4: r0 = attach()
    //     0x8786a4: bl              #0x8786d4  ; [package:flutter/src/services/text_input.dart] _PlatformTextInputControl::attach
    // 0x8786a8: ldur            x0, [fp, #-0x18]
    // 0x8786ac: ldur            x2, [fp, #-0x10]
    // 0x8786b0: b               #0x878640
    // 0x8786b4: r0 = Null
    //     0x8786b4: mov             x0, NULL
    // 0x8786b8: LeaveFrame
    //     0x8786b8: mov             SP, fp
    //     0x8786bc: ldp             fp, lr, [SP], #0x10
    // 0x8786c0: ret
    //     0x8786c0: ret             
    // 0x8786c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8786c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8786c8: b               #0x878620
    // 0x8786cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8786cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8786d0: b               #0x87864c
  }
  [closure] List<dynamic> <anonymous closure>(dynamic, String) {
    // ** addr: 0x87a534, size: 0x26c
    // 0x87a534: EnterFrame
    //     0x87a534: stp             fp, lr, [SP, #-0x10]!
    //     0x87a538: mov             fp, SP
    // 0x87a53c: AllocStack(0x30)
    //     0x87a53c: sub             SP, SP, #0x30
    // 0x87a540: SetupParameters([dynamic _ /* r0 */])
    //     0x87a540: ldr             x0, [fp, #0x18]
    //     0x87a544: ldur            w1, [x0, #0x17]
    //     0x87a548: add             x1, x1, HEAP, lsl #32
    // 0x87a54c: CheckStackOverflow
    //     0x87a54c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87a550: cmp             SP, x16
    //     0x87a554: b.ls            #0x87a72c
    // 0x87a558: LoadField: r0 = r1->field_f
    //     0x87a558: ldur            w0, [x1, #0xf]
    // 0x87a55c: DecompressPointer r0
    //     0x87a55c: add             x0, x0, HEAP, lsl #32
    // 0x87a560: LoadField: r3 = r0->field_1f
    //     0x87a560: ldur            w3, [x0, #0x1f]
    // 0x87a564: DecompressPointer r3
    //     0x87a564: add             x3, x3, HEAP, lsl #32
    // 0x87a568: mov             x1, x3
    // 0x87a56c: ldr             x2, [fp, #0x10]
    // 0x87a570: stur            x3, [fp, #-8]
    // 0x87a574: r0 = _getValueOrData()
    //     0x87a574: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x87a578: mov             x1, x0
    // 0x87a57c: ldur            x0, [fp, #-8]
    // 0x87a580: LoadField: r2 = r0->field_f
    //     0x87a580: ldur            w2, [x0, #0xf]
    // 0x87a584: DecompressPointer r2
    //     0x87a584: add             x2, x2, HEAP, lsl #32
    // 0x87a588: cmp             w2, w1
    // 0x87a58c: b.ne            #0x87a594
    // 0x87a590: r1 = Null
    //     0x87a590: mov             x1, NULL
    // 0x87a594: ldr             x0, [fp, #0x10]
    // 0x87a598: cmp             w1, NULL
    // 0x87a59c: b.eq            #0x87a734
    // 0x87a5a0: r0 = bounds()
    //     0x87a5a0: bl              #0x87a7a0  ; [package:flutter/src/widgets/editable_text.dart] _ScribbleFocusableState::bounds
    // 0x87a5a4: r1 = Null
    //     0x87a5a4: mov             x1, NULL
    // 0x87a5a8: r2 = 2
    //     0x87a5a8: mov             x2, #2
    // 0x87a5ac: stur            x0, [fp, #-8]
    // 0x87a5b0: r0 = AllocateArray()
    //     0x87a5b0: bl              #0x13df928  ; AllocateArrayStub
    // 0x87a5b4: mov             x2, x0
    // 0x87a5b8: ldr             x0, [fp, #0x10]
    // 0x87a5bc: stur            x2, [fp, #-0x10]
    // 0x87a5c0: StoreField: r2->field_f = r0
    //     0x87a5c0: stur            w0, [x2, #0xf]
    // 0x87a5c4: r1 = Null
    //     0x87a5c4: mov             x1, NULL
    // 0x87a5c8: r0 = AllocateGrowableArray()
    //     0x87a5c8: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x87a5cc: mov             x3, x0
    // 0x87a5d0: ldur            x0, [fp, #-0x10]
    // 0x87a5d4: stur            x3, [fp, #-0x18]
    // 0x87a5d8: StoreField: r3->field_f = r0
    //     0x87a5d8: stur            w0, [x3, #0xf]
    // 0x87a5dc: r0 = 2
    //     0x87a5dc: mov             x0, #2
    // 0x87a5e0: StoreField: r3->field_b = r0
    //     0x87a5e0: stur            w0, [x3, #0xb]
    // 0x87a5e4: ldur            x0, [fp, #-8]
    // 0x87a5e8: LoadField: d0 = r0->field_7
    //     0x87a5e8: ldur            d0, [x0, #7]
    // 0x87a5ec: LoadField: d1 = r0->field_f
    //     0x87a5ec: ldur            d1, [x0, #0xf]
    // 0x87a5f0: stur            d1, [fp, #-0x30]
    // 0x87a5f4: ArrayLoad: d2 = r0[0]  ; List_8
    //     0x87a5f4: ldur            d2, [x0, #0x17]
    // 0x87a5f8: fsub            d3, d2, d0
    // 0x87a5fc: stur            d3, [fp, #-0x28]
    // 0x87a600: LoadField: d2 = r0->field_1f
    //     0x87a600: ldur            d2, [x0, #0x1f]
    // 0x87a604: fsub            d4, d2, d1
    // 0x87a608: stur            d4, [fp, #-0x20]
    // 0x87a60c: r0 = inline_Allocate_Double()
    //     0x87a60c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x87a610: add             x0, x0, #0x10
    //     0x87a614: cmp             x1, x0
    //     0x87a618: b.ls            #0x87a738
    //     0x87a61c: str             x0, [THR, #0x60]  ; THR::top
    //     0x87a620: sub             x0, x0, #0xf
    //     0x87a624: mov             x1, #0xe19c
    //     0x87a628: movk            x1, #3, lsl #16
    //     0x87a62c: stur            x1, [x0, #-1]
    // 0x87a630: dmb             ishst
    // 0x87a634: StoreField: r0->field_7 = d0
    //     0x87a634: stur            d0, [x0, #7]
    // 0x87a638: stur            x0, [fp, #-8]
    // 0x87a63c: r1 = Null
    //     0x87a63c: mov             x1, NULL
    // 0x87a640: r2 = 8
    //     0x87a640: mov             x2, #8
    // 0x87a644: r0 = AllocateArray()
    //     0x87a644: bl              #0x13df928  ; AllocateArrayStub
    // 0x87a648: mov             x2, x0
    // 0x87a64c: ldur            x0, [fp, #-8]
    // 0x87a650: stur            x2, [fp, #-0x10]
    // 0x87a654: StoreField: r2->field_f = r0
    //     0x87a654: stur            w0, [x2, #0xf]
    // 0x87a658: ldur            d0, [fp, #-0x30]
    // 0x87a65c: r0 = inline_Allocate_Double()
    //     0x87a65c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x87a660: add             x0, x0, #0x10
    //     0x87a664: cmp             x1, x0
    //     0x87a668: b.ls            #0x87a758
    //     0x87a66c: str             x0, [THR, #0x60]  ; THR::top
    //     0x87a670: sub             x0, x0, #0xf
    //     0x87a674: mov             x1, #0xe19c
    //     0x87a678: movk            x1, #3, lsl #16
    //     0x87a67c: stur            x1, [x0, #-1]
    // 0x87a680: dmb             ishst
    // 0x87a684: StoreField: r0->field_7 = d0
    //     0x87a684: stur            d0, [x0, #7]
    // 0x87a688: StoreField: r2->field_13 = r0
    //     0x87a688: stur            w0, [x2, #0x13]
    // 0x87a68c: ldur            d0, [fp, #-0x28]
    // 0x87a690: r0 = inline_Allocate_Double()
    //     0x87a690: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x87a694: add             x0, x0, #0x10
    //     0x87a698: cmp             x1, x0
    //     0x87a69c: b.ls            #0x87a770
    //     0x87a6a0: str             x0, [THR, #0x60]  ; THR::top
    //     0x87a6a4: sub             x0, x0, #0xf
    //     0x87a6a8: mov             x1, #0xe19c
    //     0x87a6ac: movk            x1, #3, lsl #16
    //     0x87a6b0: stur            x1, [x0, #-1]
    // 0x87a6b4: dmb             ishst
    // 0x87a6b8: StoreField: r0->field_7 = d0
    //     0x87a6b8: stur            d0, [x0, #7]
    // 0x87a6bc: ArrayStore: r2[0] = r0  ; List_4
    //     0x87a6bc: stur            w0, [x2, #0x17]
    // 0x87a6c0: ldur            d0, [fp, #-0x20]
    // 0x87a6c4: r0 = inline_Allocate_Double()
    //     0x87a6c4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x87a6c8: add             x0, x0, #0x10
    //     0x87a6cc: cmp             x1, x0
    //     0x87a6d0: b.ls            #0x87a788
    //     0x87a6d4: str             x0, [THR, #0x60]  ; THR::top
    //     0x87a6d8: sub             x0, x0, #0xf
    //     0x87a6dc: mov             x1, #0xe19c
    //     0x87a6e0: movk            x1, #3, lsl #16
    //     0x87a6e4: stur            x1, [x0, #-1]
    // 0x87a6e8: dmb             ishst
    // 0x87a6ec: StoreField: r0->field_7 = d0
    //     0x87a6ec: stur            d0, [x0, #7]
    // 0x87a6f0: StoreField: r2->field_1b = r0
    //     0x87a6f0: stur            w0, [x2, #0x1b]
    // 0x87a6f4: r1 = Null
    //     0x87a6f4: mov             x1, NULL
    // 0x87a6f8: r0 = AllocateGrowableArray()
    //     0x87a6f8: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x87a6fc: mov             x1, x0
    // 0x87a700: ldur            x0, [fp, #-0x10]
    // 0x87a704: StoreField: r1->field_f = r0
    //     0x87a704: stur            w0, [x1, #0xf]
    // 0x87a708: r0 = 8
    //     0x87a708: mov             x0, #8
    // 0x87a70c: StoreField: r1->field_b = r0
    //     0x87a70c: stur            w0, [x1, #0xb]
    // 0x87a710: mov             x2, x1
    // 0x87a714: ldur            x1, [fp, #-0x18]
    // 0x87a718: r0 = addAll()
    //     0x87a718: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0x87a71c: ldur            x0, [fp, #-0x18]
    // 0x87a720: LeaveFrame
    //     0x87a720: mov             SP, fp
    //     0x87a724: ldp             fp, lr, [SP], #0x10
    // 0x87a728: ret
    //     0x87a728: ret             
    // 0x87a72c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87a72c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87a730: b               #0x87a558
    // 0x87a734: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x87a734: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x87a738: stp             q3, q4, [SP, #-0x20]!
    // 0x87a73c: stp             q0, q1, [SP, #-0x20]!
    // 0x87a740: SaveReg r3
    //     0x87a740: str             x3, [SP, #-8]!
    // 0x87a744: r0 = AllocateDouble()
    //     0x87a744: bl              #0x13df878  ; AllocateDoubleStub
    // 0x87a748: RestoreReg r3
    //     0x87a748: ldr             x3, [SP], #8
    // 0x87a74c: ldp             q0, q1, [SP], #0x20
    // 0x87a750: ldp             q3, q4, [SP], #0x20
    // 0x87a754: b               #0x87a634
    // 0x87a758: SaveReg d0
    //     0x87a758: str             q0, [SP, #-0x10]!
    // 0x87a75c: SaveReg r2
    //     0x87a75c: str             x2, [SP, #-8]!
    // 0x87a760: r0 = AllocateDouble()
    //     0x87a760: bl              #0x13df878  ; AllocateDoubleStub
    // 0x87a764: RestoreReg r2
    //     0x87a764: ldr             x2, [SP], #8
    // 0x87a768: RestoreReg d0
    //     0x87a768: ldr             q0, [SP], #0x10
    // 0x87a76c: b               #0x87a684
    // 0x87a770: SaveReg d0
    //     0x87a770: str             q0, [SP, #-0x10]!
    // 0x87a774: SaveReg r2
    //     0x87a774: str             x2, [SP, #-8]!
    // 0x87a778: r0 = AllocateDouble()
    //     0x87a778: bl              #0x13df878  ; AllocateDoubleStub
    // 0x87a77c: RestoreReg r2
    //     0x87a77c: ldr             x2, [SP], #8
    // 0x87a780: RestoreReg d0
    //     0x87a780: ldr             q0, [SP], #0x10
    // 0x87a784: b               #0x87a6b8
    // 0x87a788: SaveReg d0
    //     0x87a788: str             q0, [SP, #-0x10]!
    // 0x87a78c: SaveReg r2
    //     0x87a78c: str             x2, [SP, #-8]!
    // 0x87a790: r0 = AllocateDouble()
    //     0x87a790: bl              #0x13df878  ; AllocateDoubleStub
    // 0x87a794: RestoreReg r2
    //     0x87a794: ldr             x2, [SP], #8
    // 0x87a798: RestoreReg d0
    //     0x87a798: ldr             q0, [SP], #0x10
    // 0x87a79c: b               #0x87a6ec
  }
  [closure] bool <anonymous closure>(dynamic, String) {
    // ** addr: 0x87a8cc, size: 0x2cc
    // 0x87a8cc: EnterFrame
    //     0x87a8cc: stp             fp, lr, [SP, #-0x10]!
    //     0x87a8d0: mov             fp, SP
    // 0x87a8d4: AllocStack(0x48)
    //     0x87a8d4: sub             SP, SP, #0x48
    // 0x87a8d8: SetupParameters([dynamic _ /* r0 */])
    //     0x87a8d8: ldr             x0, [fp, #0x18]
    //     0x87a8dc: ldur            w2, [x0, #0x17]
    //     0x87a8e0: add             x2, x2, HEAP, lsl #32
    //     0x87a8e4: stur            x2, [fp, #-8]
    // 0x87a8e8: CheckStackOverflow
    //     0x87a8e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87a8ec: cmp             SP, x16
    //     0x87a8f0: b.ls            #0x87ab80
    // 0x87a8f4: LoadField: r3 = r2->field_13
    //     0x87a8f4: ldur            w3, [x2, #0x13]
    // 0x87a8f8: DecompressPointer r3
    //     0x87a8f8: add             x3, x3, HEAP, lsl #32
    // 0x87a8fc: LoadField: r0 = r3->field_b
    //     0x87a8fc: ldur            w0, [x3, #0xb]
    // 0x87a900: r4 = LoadInt32Instr(r0)
    //     0x87a900: sbfx            x4, x0, #1, #0x1f
    // 0x87a904: mov             x0, x4
    // 0x87a908: r1 = 0
    //     0x87a908: mov             x1, #0
    // 0x87a90c: cmp             x1, x0
    // 0x87a910: b.hs            #0x87ab88
    // 0x87a914: LoadField: r5 = r3->field_f
    //     0x87a914: ldur            w5, [x3, #0xf]
    // 0x87a918: DecompressPointer r5
    //     0x87a918: add             x5, x5, HEAP, lsl #32
    // 0x87a91c: LoadField: r3 = r5->field_f
    //     0x87a91c: ldur            w3, [x5, #0xf]
    // 0x87a920: DecompressPointer r3
    //     0x87a920: add             x3, x3, HEAP, lsl #32
    // 0x87a924: mov             x0, x4
    // 0x87a928: r1 = 1
    //     0x87a928: mov             x1, #1
    // 0x87a92c: cmp             x1, x0
    // 0x87a930: b.hs            #0x87ab8c
    // 0x87a934: LoadField: r6 = r5->field_13
    //     0x87a934: ldur            w6, [x5, #0x13]
    // 0x87a938: DecompressPointer r6
    //     0x87a938: add             x6, x6, HEAP, lsl #32
    // 0x87a93c: mov             x0, x4
    // 0x87a940: r1 = 2
    //     0x87a940: mov             x1, #2
    // 0x87a944: cmp             x1, x0
    // 0x87a948: b.hs            #0x87ab90
    // 0x87a94c: ArrayLoad: r7 = r5[0]  ; List_4
    //     0x87a94c: ldur            w7, [x5, #0x17]
    // 0x87a950: DecompressPointer r7
    //     0x87a950: add             x7, x7, HEAP, lsl #32
    // 0x87a954: mov             x0, x4
    // 0x87a958: r1 = 3
    //     0x87a958: mov             x1, #3
    // 0x87a95c: cmp             x1, x0
    // 0x87a960: b.hs            #0x87ab94
    // 0x87a964: LoadField: r0 = r5->field_1b
    //     0x87a964: ldur            w0, [x5, #0x1b]
    // 0x87a968: DecompressPointer r0
    //     0x87a968: add             x0, x0, HEAP, lsl #32
    // 0x87a96c: LoadField: d0 = r3->field_7
    //     0x87a96c: ldur            d0, [x3, #7]
    // 0x87a970: stur            d0, [fp, #-0x38]
    // 0x87a974: LoadField: d1 = r7->field_7
    //     0x87a974: ldur            d1, [x7, #7]
    // 0x87a978: fadd            d2, d0, d1
    // 0x87a97c: stur            d2, [fp, #-0x30]
    // 0x87a980: LoadField: d1 = r6->field_7
    //     0x87a980: ldur            d1, [x6, #7]
    // 0x87a984: stur            d1, [fp, #-0x28]
    // 0x87a988: LoadField: d3 = r0->field_7
    //     0x87a988: ldur            d3, [x0, #7]
    // 0x87a98c: fadd            d4, d1, d3
    // 0x87a990: stur            d4, [fp, #-0x20]
    // 0x87a994: r0 = Rect()
    //     0x87a994: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0x87a998: ldur            d0, [fp, #-0x38]
    // 0x87a99c: stur            x0, [fp, #-0x18]
    // 0x87a9a0: StoreField: r0->field_7 = d0
    //     0x87a9a0: stur            d0, [x0, #7]
    // 0x87a9a4: ldur            d0, [fp, #-0x28]
    // 0x87a9a8: StoreField: r0->field_f = d0
    //     0x87a9a8: stur            d0, [x0, #0xf]
    // 0x87a9ac: ldur            d0, [fp, #-0x30]
    // 0x87a9b0: ArrayStore: r0[0] = d0  ; List_8
    //     0x87a9b0: stur            d0, [x0, #0x17]
    // 0x87a9b4: ldur            d0, [fp, #-0x20]
    // 0x87a9b8: StoreField: r0->field_1f = d0
    //     0x87a9b8: stur            d0, [x0, #0x1f]
    // 0x87a9bc: ldur            x3, [fp, #-8]
    // 0x87a9c0: LoadField: r1 = r3->field_f
    //     0x87a9c0: ldur            w1, [x3, #0xf]
    // 0x87a9c4: DecompressPointer r1
    //     0x87a9c4: add             x1, x1, HEAP, lsl #32
    // 0x87a9c8: LoadField: r4 = r1->field_1f
    //     0x87a9c8: ldur            w4, [x1, #0x1f]
    // 0x87a9cc: DecompressPointer r4
    //     0x87a9cc: add             x4, x4, HEAP, lsl #32
    // 0x87a9d0: mov             x1, x4
    // 0x87a9d4: ldr             x2, [fp, #0x10]
    // 0x87a9d8: stur            x4, [fp, #-0x10]
    // 0x87a9dc: r0 = _getValueOrData()
    //     0x87a9dc: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x87a9e0: mov             x1, x0
    // 0x87a9e4: ldur            x0, [fp, #-0x10]
    // 0x87a9e8: LoadField: r2 = r0->field_f
    //     0x87a9e8: ldur            w2, [x0, #0xf]
    // 0x87a9ec: DecompressPointer r2
    //     0x87a9ec: add             x2, x2, HEAP, lsl #32
    // 0x87a9f0: cmp             w2, w1
    // 0x87a9f4: b.ne            #0x87a9fc
    // 0x87a9f8: r1 = Null
    //     0x87a9f8: mov             x1, NULL
    // 0x87a9fc: cmp             w1, NULL
    // 0x87aa00: b.ne            #0x87aa0c
    // 0x87aa04: r0 = Null
    //     0x87aa04: mov             x0, NULL
    // 0x87aa08: b               #0x87aa14
    // 0x87aa0c: ldur            x2, [fp, #-0x18]
    // 0x87aa10: r0 = isInScribbleRect()
    //     0x87aa10: bl              #0x87ab98  ; [package:flutter/src/widgets/editable_text.dart] _ScribbleFocusableState::isInScribbleRect
    // 0x87aa14: cmp             w0, NULL
    // 0x87aa18: b.eq            #0x87aa20
    // 0x87aa1c: tbz             w0, #4, #0x87aa30
    // 0x87aa20: r0 = false
    //     0x87aa20: add             x0, NULL, #0x30  ; false
    // 0x87aa24: LeaveFrame
    //     0x87aa24: mov             SP, fp
    //     0x87aa28: ldp             fp, lr, [SP], #0x10
    // 0x87aa2c: ret
    //     0x87aa2c: ret             
    // 0x87aa30: ldur            x0, [fp, #-8]
    // 0x87aa34: LoadField: r1 = r0->field_f
    //     0x87aa34: ldur            w1, [x0, #0xf]
    // 0x87aa38: DecompressPointer r1
    //     0x87aa38: add             x1, x1, HEAP, lsl #32
    // 0x87aa3c: LoadField: r0 = r1->field_1f
    //     0x87aa3c: ldur            w0, [x1, #0x1f]
    // 0x87aa40: DecompressPointer r0
    //     0x87aa40: add             x0, x0, HEAP, lsl #32
    // 0x87aa44: mov             x1, x0
    // 0x87aa48: ldr             x2, [fp, #0x10]
    // 0x87aa4c: stur            x0, [fp, #-8]
    // 0x87aa50: r0 = _getValueOrData()
    //     0x87aa50: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x87aa54: mov             x1, x0
    // 0x87aa58: ldur            x0, [fp, #-8]
    // 0x87aa5c: LoadField: r2 = r0->field_f
    //     0x87aa5c: ldur            w2, [x0, #0xf]
    // 0x87aa60: DecompressPointer r2
    //     0x87aa60: add             x2, x2, HEAP, lsl #32
    // 0x87aa64: cmp             w2, w1
    // 0x87aa68: b.ne            #0x87aa70
    // 0x87aa6c: r1 = Null
    //     0x87aa6c: mov             x1, NULL
    // 0x87aa70: cmp             w1, NULL
    // 0x87aa74: b.ne            #0x87aa80
    // 0x87aa78: r0 = Null
    //     0x87aa78: mov             x0, NULL
    // 0x87aa7c: b               #0x87aa84
    // 0x87aa80: r0 = bounds()
    //     0x87aa80: bl              #0x87a7a0  ; [package:flutter/src/widgets/editable_text.dart] _ScribbleFocusableState::bounds
    // 0x87aa84: cmp             w0, NULL
    // 0x87aa88: b.ne            #0x87aa90
    // 0x87aa8c: r0 = Instance_Rect
    //     0x87aa8c: ldr             x0, [PP, #0x2a60]  ; [pp+0x2a60] Obj!Rect@12a73c1
    // 0x87aa90: stur            x0, [fp, #-8]
    // 0x87aa94: r16 = Instance_Rect
    //     0x87aa94: ldr             x16, [PP, #0x2a60]  ; [pp+0x2a60] Obj!Rect@12a73c1
    // 0x87aa98: cmp             w0, w16
    // 0x87aa9c: b.eq            #0x87ab34
    // 0x87aaa0: r16 = Rect
    //     0x87aaa0: ldr             x16, [PP, #0x2a28]  ; [pp+0x2a28] Type: Rect
    // 0x87aaa4: r30 = Rect
    //     0x87aaa4: ldr             lr, [PP, #0x2a28]  ; [pp+0x2a28] Type: Rect
    // 0x87aaa8: stp             lr, x16, [SP]
    // 0x87aaac: r0 = ==()
    //     0x87aaac: bl              #0x12b7fbc  ; [dart:core] _Type::==
    // 0x87aab0: tbz             w0, #4, #0x87aabc
    // 0x87aab4: ldur            x1, [fp, #-8]
    // 0x87aab8: b               #0x87ab04
    // 0x87aabc: ldur            x1, [fp, #-8]
    // 0x87aac0: r2 = Instance_Rect
    //     0x87aac0: ldr             x2, [PP, #0x2a60]  ; [pp+0x2a60] Obj!Rect@12a73c1
    // 0x87aac4: LoadField: d0 = r2->field_7
    //     0x87aac4: ldur            d0, [x2, #7]
    // 0x87aac8: LoadField: d1 = r1->field_7
    //     0x87aac8: ldur            d1, [x1, #7]
    // 0x87aacc: fcmp            d0, d1
    // 0x87aad0: b.ne            #0x87ab04
    // 0x87aad4: LoadField: d0 = r2->field_f
    //     0x87aad4: ldur            d0, [x2, #0xf]
    // 0x87aad8: LoadField: d1 = r1->field_f
    //     0x87aad8: ldur            d1, [x1, #0xf]
    // 0x87aadc: fcmp            d0, d1
    // 0x87aae0: b.ne            #0x87ab04
    // 0x87aae4: ArrayLoad: d0 = r2[0]  ; List_8
    //     0x87aae4: ldur            d0, [x2, #0x17]
    // 0x87aae8: ArrayLoad: d1 = r1[0]  ; List_8
    //     0x87aae8: ldur            d1, [x1, #0x17]
    // 0x87aaec: fcmp            d0, d1
    // 0x87aaf0: b.ne            #0x87ab04
    // 0x87aaf4: LoadField: d0 = r2->field_1f
    //     0x87aaf4: ldur            d0, [x2, #0x1f]
    // 0x87aaf8: LoadField: d1 = r1->field_1f
    //     0x87aaf8: ldur            d1, [x1, #0x1f]
    // 0x87aafc: fcmp            d0, d1
    // 0x87ab00: b.eq            #0x87ab34
    // 0x87ab04: LoadField: d0 = r1->field_7
    //     0x87ab04: ldur            d0, [x1, #7]
    // 0x87ab08: fcmp            d0, d0
    // 0x87ab0c: b.vs            #0x87ab34
    // 0x87ab10: LoadField: d1 = r1->field_f
    //     0x87ab10: ldur            d1, [x1, #0xf]
    // 0x87ab14: fcmp            d1, d1
    // 0x87ab18: b.vs            #0x87ab34
    // 0x87ab1c: ArrayLoad: d2 = r1[0]  ; List_8
    //     0x87ab1c: ldur            d2, [x1, #0x17]
    // 0x87ab20: fcmp            d2, d2
    // 0x87ab24: b.vs            #0x87ab34
    // 0x87ab28: LoadField: d3 = r1->field_1f
    //     0x87ab28: ldur            d3, [x1, #0x1f]
    // 0x87ab2c: fcmp            d3, d3
    // 0x87ab30: b.vc            #0x87ab3c
    // 0x87ab34: r1 = true
    //     0x87ab34: add             x1, NULL, #0x20  ; true
    // 0x87ab38: b               #0x87ab70
    // 0x87ab3c: d4 = inf
    //     0x87ab3c: ldr             d4, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0x87ab40: fcmp            d0, d4
    // 0x87ab44: b.ge            #0x87ab58
    // 0x87ab48: fcmp            d1, d4
    // 0x87ab4c: b.ge            #0x87ab58
    // 0x87ab50: fcmp            d2, d4
    // 0x87ab54: b.lt            #0x87ab60
    // 0x87ab58: r1 = true
    //     0x87ab58: add             x1, NULL, #0x20  ; true
    // 0x87ab5c: b               #0x87ab70
    // 0x87ab60: fcmp            d3, d4
    // 0x87ab64: r16 = true
    //     0x87ab64: add             x16, NULL, #0x20  ; true
    // 0x87ab68: r17 = false
    //     0x87ab68: add             x17, NULL, #0x30  ; false
    // 0x87ab6c: csel            x1, x16, x17, ge
    // 0x87ab70: eor             x0, x1, #0x10
    // 0x87ab74: LeaveFrame
    //     0x87ab74: mov             SP, fp
    //     0x87ab78: ldp             fp, lr, [SP], #0x10
    // 0x87ab7c: ret
    //     0x87ab7c: ret             
    // 0x87ab80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87ab80: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87ab84: b               #0x87a8f4
    // 0x87ab88: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x87ab88: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x87ab8c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x87ab8c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x87ab90: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x87ab90: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x87ab94: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x87ab94: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] double <anonymous closure>(dynamic, num) {
    // ** addr: 0x87ae9c, size: 0x54
    // 0x87ae9c: EnterFrame
    //     0x87ae9c: stp             fp, lr, [SP, #-0x10]!
    //     0x87aea0: mov             fp, SP
    // 0x87aea4: AllocStack(0x8)
    //     0x87aea4: sub             SP, SP, #8
    // 0x87aea8: CheckStackOverflow
    //     0x87aea8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87aeac: cmp             SP, x16
    //     0x87aeb0: b.ls            #0x87aee8
    // 0x87aeb4: ldr             x0, [fp, #0x10]
    // 0x87aeb8: r1 = 60
    //     0x87aeb8: mov             x1, #0x3c
    // 0x87aebc: branchIfSmi(r0, 0x87aec8)
    //     0x87aebc: tbz             w0, #0, #0x87aec8
    // 0x87aec0: r1 = LoadClassIdInstr(r0)
    //     0x87aec0: ldur            x1, [x0, #-1]
    //     0x87aec4: ubfx            x1, x1, #0xc, #0x14
    // 0x87aec8: str             x0, [SP]
    // 0x87aecc: mov             x0, x1
    // 0x87aed0: r0 = GDT[cid_x0 + -0xffd]()
    //     0x87aed0: sub             lr, x0, #0xffd
    //     0x87aed4: ldr             lr, [x21, lr, lsl #3]
    //     0x87aed8: blr             lr
    // 0x87aedc: LeaveFrame
    //     0x87aedc: mov             SP, fp
    //     0x87aee0: ldp             fp, lr, [SP], #0x10
    // 0x87aee4: ret
    //     0x87aee4: ret             
    // 0x87aee8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87aee8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87aeec: b               #0x87aeb4
  }
  [closure] List<DiagnosticsNode> <anonymous closure>(dynamic) {
    // ** addr: 0x87aef0, size: 0x9c
    // 0x87aef0: EnterFrame
    //     0x87aef0: stp             fp, lr, [SP, #-0x10]!
    //     0x87aef4: mov             fp, SP
    // 0x87aef8: AllocStack(0x10)
    //     0x87aef8: sub             SP, SP, #0x10
    // 0x87aefc: SetupParameters([dynamic _ /* r0 */])
    //     0x87aefc: ldr             x0, [fp, #0x10]
    //     0x87af00: ldur            w1, [x0, #0x17]
    //     0x87af04: add             x1, x1, HEAP, lsl #32
    // 0x87af08: LoadField: r0 = r1->field_f
    //     0x87af08: ldur            w0, [x1, #0xf]
    // 0x87af0c: DecompressPointer r0
    //     0x87af0c: add             x0, x0, HEAP, lsl #32
    // 0x87af10: stur            x0, [fp, #-8]
    // 0x87af14: r1 = <MethodCall>
    //     0x87af14: ldr             x1, [PP, #0x43d8]  ; [pp+0x43d8] TypeArguments: <MethodCall>
    // 0x87af18: r0 = DiagnosticsProperty()
    //     0x87af18: bl              #0x82bc68  ; AllocateDiagnosticsPropertyStub -> DiagnosticsProperty<X0> (size=0x2c)
    // 0x87af1c: mov             x3, x0
    // 0x87af20: r0 = Instance__NoDefaultValue
    //     0x87af20: ldr             x0, [PP, #0xca0]  ; [pp+0xca0] Obj!_NoDefaultValue@129f291
    // 0x87af24: stur            x3, [fp, #-0x10]
    // 0x87af28: StoreField: r3->field_23 = r0
    //     0x87af28: stur            w0, [x3, #0x23]
    // 0x87af2c: r0 = false
    //     0x87af2c: add             x0, NULL, #0x30  ; false
    // 0x87af30: StoreField: r3->field_13 = r0
    //     0x87af30: stur            w0, [x3, #0x13]
    // 0x87af34: r0 = true
    //     0x87af34: add             x0, NULL, #0x20  ; true
    // 0x87af38: StoreField: r3->field_1b = r0
    //     0x87af38: stur            w0, [x3, #0x1b]
    // 0x87af3c: ldur            x0, [fp, #-8]
    // 0x87af40: ArrayStore: r3[0] = r0  ; List_4
    //     0x87af40: stur            w0, [x3, #0x17]
    // 0x87af44: r0 = Instance_DiagnosticLevel
    //     0x87af44: ldr             x0, [PP, #0x868]  ; [pp+0x868] Obj!DiagnosticLevel@12c5f41
    // 0x87af48: StoreField: r3->field_27 = r0
    //     0x87af48: stur            w0, [x3, #0x27]
    // 0x87af4c: r1 = Null
    //     0x87af4c: mov             x1, NULL
    // 0x87af50: r2 = 2
    //     0x87af50: mov             x2, #2
    // 0x87af54: r0 = AllocateArray()
    //     0x87af54: bl              #0x13df928  ; AllocateArrayStub
    // 0x87af58: mov             x2, x0
    // 0x87af5c: ldur            x0, [fp, #-0x10]
    // 0x87af60: stur            x2, [fp, #-8]
    // 0x87af64: StoreField: r2->field_f = r0
    //     0x87af64: stur            w0, [x2, #0xf]
    // 0x87af68: r1 = <DiagnosticsNode>
    //     0x87af68: ldr             x1, [PP, #0x1ea8]  ; [pp+0x1ea8] TypeArguments: <DiagnosticsNode>
    // 0x87af6c: r0 = AllocateGrowableArray()
    //     0x87af6c: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x87af70: ldur            x1, [fp, #-8]
    // 0x87af74: StoreField: r0->field_f = r1
    //     0x87af74: stur            w1, [x0, #0xf]
    // 0x87af78: r1 = 2
    //     0x87af78: mov             x1, #2
    // 0x87af7c: StoreField: r0->field_b = r1
    //     0x87af7c: stur            w1, [x0, #0xb]
    // 0x87af80: LeaveFrame
    //     0x87af80: mov             SP, fp
    //     0x87af84: ldp             fp, lr, [SP], #0x10
    // 0x87af88: ret
    //     0x87af88: ret             
  }
  _ _updateConfig(/* No info */) {
    // ** addr: 0xeef7b8, size: 0x170
    // 0xeef7b8: EnterFrame
    //     0xeef7b8: stp             fp, lr, [SP, #-0x10]!
    //     0xeef7bc: mov             fp, SP
    // 0xeef7c0: AllocStack(0x48)
    //     0xeef7c0: sub             SP, SP, #0x48
    // 0xeef7c4: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0xeef7c4: stur            x2, [fp, #-8]
    // 0xeef7c8: CheckStackOverflow
    //     0xeef7c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeef7cc: cmp             SP, x16
    //     0xeef7d0: b.ls            #0xeef910
    // 0xeef7d4: LoadField: r0 = r1->field_b
    //     0xeef7d4: ldur            w0, [x1, #0xb]
    // 0xeef7d8: DecompressPointer r0
    //     0xeef7d8: add             x0, x0, HEAP, lsl #32
    // 0xeef7dc: mov             x1, x0
    // 0xeef7e0: r0 = iterator()
    //     0xeef7e0: bl              #0xbb7c60  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0xeef7e4: stur            x0, [fp, #-0x18]
    // 0xeef7e8: LoadField: r2 = r0->field_7
    //     0xeef7e8: ldur            w2, [x0, #7]
    // 0xeef7ec: DecompressPointer r2
    //     0xeef7ec: add             x2, x2, HEAP, lsl #32
    // 0xeef7f0: stur            x2, [fp, #-0x10]
    // 0xeef7f4: CheckStackOverflow
    //     0xeef7f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeef7f8: cmp             SP, x16
    //     0xeef7fc: b.ls            #0xeef918
    // 0xeef800: mov             x1, x0
    // 0xeef804: r0 = moveNext()
    //     0xeef804: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0xeef808: tbnz            w0, #4, #0xeef900
    // 0xeef80c: ldur            x3, [fp, #-0x18]
    // 0xeef810: LoadField: r4 = r3->field_33
    //     0xeef810: ldur            w4, [x3, #0x33]
    // 0xeef814: DecompressPointer r4
    //     0xeef814: add             x4, x4, HEAP, lsl #32
    // 0xeef818: stur            x4, [fp, #-0x20]
    // 0xeef81c: cmp             w4, NULL
    // 0xeef820: b.ne            #0xeef854
    // 0xeef824: mov             x0, x4
    // 0xeef828: ldur            x2, [fp, #-0x10]
    // 0xeef82c: r1 = Null
    //     0xeef82c: mov             x1, NULL
    // 0xeef830: cmp             w2, NULL
    // 0xeef834: b.eq            #0xeef854
    // 0xeef838: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xeef838: ldur            w4, [x2, #0x17]
    // 0xeef83c: DecompressPointer r4
    //     0xeef83c: add             x4, x4, HEAP, lsl #32
    // 0xeef840: r8 = X0
    //     0xeef840: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xeef844: LoadField: r9 = r4->field_7
    //     0xeef844: ldur            x9, [x4, #7]
    // 0xeef848: r3 = Null
    //     0xeef848: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa3280] Null
    //     0xeef84c: ldr             x3, [x3, #0x280]
    // 0xeef850: blr             x9
    // 0xeef854: r0 = LoadStaticField(0x67c)
    //     0xeef854: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xeef858: ldr             x0, [x0, #0xcf8]
    // 0xeef85c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xeef860: cmp             w0, w16
    // 0xeef864: b.ne            #0xeef870
    // 0xeef868: r2 = _instance
    //     0xeef868: ldr             x2, [PP, #0x30b0]  ; [pp+0x30b0] Field <TextInput._instance@81206165>: static late final (offset: 0x67c)
    // 0xeef86c: r0 = InitLateFinalStaticField()
    //     0xeef86c: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xeef870: LoadField: r1 = r0->field_f
    //     0xeef870: ldur            w1, [x0, #0xf]
    // 0xeef874: DecompressPointer r1
    //     0xeef874: add             x1, x1, HEAP, lsl #32
    // 0xeef878: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xeef87c: cmp             w1, w16
    // 0xeef880: b.eq            #0xeef920
    // 0xeef884: ldur            x1, [fp, #-0x20]
    // 0xeef888: ldur            x2, [fp, #-8]
    // 0xeef88c: r0 = _configurationToJson()
    //     0xeef88c: bl              #0x878828  ; [package:flutter/src/services/text_input.dart] _PlatformTextInputControl::_configurationToJson
    // 0xeef890: r16 = <void?>
    //     0xeef890: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xeef894: r30 = Instance_OptionalMethodChannel
    //     0xeef894: ldr             lr, [PP, #0x43b0]  ; [pp+0x43b0] Obj!OptionalMethodChannel@129bea1
    // 0xeef898: stp             lr, x16, [SP, #0x10]
    // 0xeef89c: r16 = "TextInput.updateConfig"
    //     0xeef89c: add             x16, PP, #0xa3, lsl #12  ; [pp+0xa3290] "TextInput.updateConfig"
    //     0xeef8a0: ldr             x16, [x16, #0x290]
    // 0xeef8a4: stp             x0, x16, [SP]
    // 0xeef8a8: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xeef8a8: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xeef8ac: r0 = invokeMethod()
    //     0xeef8ac: bl              #0x130ad0c  ; [package:flutter/src/services/platform_channel.dart] OptionalMethodChannel::invokeMethod
    // 0xeef8b0: r1 = Function '<anonymous closure>':.
    //     0xeef8b0: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3298] Function: [dart:ui] Shader::Shader._ (0x13cf838)
    //     0xeef8b4: ldr             x1, [x1, #0x298]
    // 0xeef8b8: r2 = Null
    //     0xeef8b8: mov             x2, NULL
    // 0xeef8bc: stur            x0, [fp, #-0x20]
    // 0xeef8c0: r0 = AllocateClosure()
    //     0xeef8c0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xeef8c4: r1 = Function '<anonymous closure>':.
    //     0xeef8c4: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa32a0] AnonymousClosure: (0xeef928), of [package:flutter/src/services/text_input.dart] _PlatformTextInputControl
    //     0xeef8c8: ldr             x1, [x1, #0x2a0]
    // 0xeef8cc: r2 = Null
    //     0xeef8cc: mov             x2, NULL
    // 0xeef8d0: stur            x0, [fp, #-0x28]
    // 0xeef8d4: r0 = AllocateClosure()
    //     0xeef8d4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xeef8d8: r16 = <Null?>
    //     0xeef8d8: ldr             x16, [PP, #0x70]  ; [pp+0x70] TypeArguments: <Null?>
    // 0xeef8dc: ldur            lr, [fp, #-0x20]
    // 0xeef8e0: stp             lr, x16, [SP, #0x10]
    // 0xeef8e4: ldur            x16, [fp, #-0x28]
    // 0xeef8e8: stp             x0, x16, [SP]
    // 0xeef8ec: r4 = const [0x1, 0x3, 0x3, 0x2, onError, 0x2, null]
    //     0xeef8ec: ldr             x4, [PP, #0x538]  ; [pp+0x538] List(7) [0x1, 0x3, 0x3, 0x2, "onError", 0x2, Null]
    // 0xeef8f0: r0 = then()
    //     0xeef8f0: bl              #0x1293070  ; [dart:async] _Future::then
    // 0xeef8f4: ldur            x0, [fp, #-0x18]
    // 0xeef8f8: ldur            x2, [fp, #-0x10]
    // 0xeef8fc: b               #0xeef7f4
    // 0xeef900: r0 = Null
    //     0xeef900: mov             x0, NULL
    // 0xeef904: LeaveFrame
    //     0xeef904: mov             SP, fp
    //     0xeef908: ldp             fp, lr, [SP], #0x10
    // 0xeef90c: ret
    //     0xeef90c: ret             
    // 0xeef910: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeef910: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeef914: b               #0xeef7d4
    // 0xeef918: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeef918: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeef91c: b               #0xeef800
    // 0xeef920: r9 = _channel
    //     0xeef920: ldr             x9, [PP, #0x5968]  ; [pp+0x5968] Field <TextInput._channel@81206165>: late (offset: 0x10)
    // 0xeef924: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xeef924: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  static _ registerScribbleElement(/* No info */) {
    // ** addr: 0xf920c4, size: 0x70
    // 0xf920c4: EnterFrame
    //     0xf920c4: stp             fp, lr, [SP, #-0x10]!
    //     0xf920c8: mov             fp, SP
    // 0xf920cc: AllocStack(0x10)
    //     0xf920cc: sub             SP, SP, #0x10
    // 0xf920d0: SetupParameters(dynamic _ /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xf920d0: mov             x3, x2
    //     0xf920d4: stur            x2, [fp, #-0x10]
    //     0xf920d8: mov             x2, x1
    //     0xf920dc: stur            x1, [fp, #-8]
    // 0xf920e0: CheckStackOverflow
    //     0xf920e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf920e4: cmp             SP, x16
    //     0xf920e8: b.ls            #0xf9212c
    // 0xf920ec: r0 = LoadStaticField(0x67c)
    //     0xf920ec: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf920f0: ldr             x0, [x0, #0xcf8]
    // 0xf920f4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf920f8: cmp             w0, w16
    // 0xf920fc: b.ne            #0xf92108
    // 0xf92100: r2 = _instance
    //     0xf92100: ldr             x2, [PP, #0x30b0]  ; [pp+0x30b0] Field <TextInput._instance@81206165>: static late final (offset: 0x67c)
    // 0xf92104: r0 = InitLateFinalStaticField()
    //     0xf92104: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xf92108: LoadField: r1 = r0->field_1f
    //     0xf92108: ldur            w1, [x0, #0x1f]
    // 0xf9210c: DecompressPointer r1
    //     0xf9210c: add             x1, x1, HEAP, lsl #32
    // 0xf92110: ldur            x2, [fp, #-8]
    // 0xf92114: ldur            x3, [fp, #-0x10]
    // 0xf92118: r0 = []=()
    //     0xf92118: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xf9211c: r0 = Null
    //     0xf9211c: mov             x0, NULL
    // 0xf92120: LeaveFrame
    //     0xf92120: mov             SP, fp
    //     0xf92124: ldp             fp, lr, [SP], #0x10
    // 0xf92128: ret
    //     0xf92128: ret             
    // 0xf9212c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf9212c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf92130: b               #0xf920ec
  }
  static void unregisterScribbleElement(String) {
    // ** addr: 0x10e67c8, size: 0x64
    // 0x10e67c8: EnterFrame
    //     0x10e67c8: stp             fp, lr, [SP, #-0x10]!
    //     0x10e67cc: mov             fp, SP
    // 0x10e67d0: AllocStack(0x8)
    //     0x10e67d0: sub             SP, SP, #8
    // 0x10e67d4: SetupParameters(dynamic _ /* r1 => r2, fp-0x8 */)
    //     0x10e67d4: mov             x2, x1
    //     0x10e67d8: stur            x1, [fp, #-8]
    // 0x10e67dc: CheckStackOverflow
    //     0x10e67dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e67e0: cmp             SP, x16
    //     0x10e67e4: b.ls            #0x10e6824
    // 0x10e67e8: r0 = LoadStaticField(0x67c)
    //     0x10e67e8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x10e67ec: ldr             x0, [x0, #0xcf8]
    // 0x10e67f0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10e67f4: cmp             w0, w16
    // 0x10e67f8: b.ne            #0x10e6804
    // 0x10e67fc: r2 = _instance
    //     0x10e67fc: ldr             x2, [PP, #0x30b0]  ; [pp+0x30b0] Field <TextInput._instance@81206165>: static late final (offset: 0x67c)
    // 0x10e6800: r0 = InitLateFinalStaticField()
    //     0x10e6800: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x10e6804: LoadField: r1 = r0->field_1f
    //     0x10e6804: ldur            w1, [x0, #0x1f]
    // 0x10e6808: DecompressPointer r1
    //     0x10e6808: add             x1, x1, HEAP, lsl #32
    // 0x10e680c: ldur            x2, [fp, #-8]
    // 0x10e6810: r0 = remove()
    //     0x10e6810: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x10e6814: r0 = Null
    //     0x10e6814: mov             x0, NULL
    // 0x10e6818: LeaveFrame
    //     0x10e6818: mov             SP, fp
    //     0x10e681c: ldp             fp, lr, [SP], #0x10
    // 0x10e6820: ret
    //     0x10e6820: ret             
    // 0x10e6824: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e6824: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e6828: b               #0x10e67e8
  }
}

// class id: 2725, size: 0x28, field offset: 0x8
class TextInputConnection extends Object {

  _ connectionClosedReceived(/* No info */) {
    // ** addr: 0x865aec, size: 0x4c
    // 0x865aec: EnterFrame
    //     0x865aec: stp             fp, lr, [SP, #-0x10]!
    //     0x865af0: mov             fp, SP
    // 0x865af4: CheckStackOverflow
    //     0x865af4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x865af8: cmp             SP, x16
    //     0x865afc: b.ls            #0x865b30
    // 0x865b00: r0 = LoadStaticField(0x67c)
    //     0x865b00: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x865b04: ldr             x0, [x0, #0xcf8]
    // 0x865b08: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x865b0c: cmp             w0, w16
    // 0x865b10: b.ne            #0x865b1c
    // 0x865b14: r2 = _instance
    //     0x865b14: ldr             x2, [PP, #0x30b0]  ; [pp+0x30b0] Field <TextInput._instance@81206165>: static late final (offset: 0x67c)
    // 0x865b18: r0 = InitLateFinalStaticField()
    //     0x865b18: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x865b1c: StoreField: r0->field_13 = rNULL
    //     0x865b1c: stur            NULL, [x0, #0x13]
    // 0x865b20: r0 = Null
    //     0x865b20: mov             x0, NULL
    // 0x865b24: LeaveFrame
    //     0x865b24: mov             SP, fp
    //     0x865b28: ldp             fp, lr, [SP], #0x10
    // 0x865b2c: ret
    //     0x865b2c: ret             
    // 0x865b30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x865b30: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x865b34: b               #0x865b00
  }
  get _ attached(/* No info */) {
    // ** addr: 0x865b98, size: 0x68
    // 0x865b98: EnterFrame
    //     0x865b98: stp             fp, lr, [SP, #-0x10]!
    //     0x865b9c: mov             fp, SP
    // 0x865ba0: AllocStack(0x8)
    //     0x865ba0: sub             SP, SP, #8
    // 0x865ba4: SetupParameters(TextInputConnection this /* r1 => r1, fp-0x8 */)
    //     0x865ba4: stur            x1, [fp, #-8]
    // 0x865ba8: CheckStackOverflow
    //     0x865ba8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x865bac: cmp             SP, x16
    //     0x865bb0: b.ls            #0x865bf8
    // 0x865bb4: r0 = LoadStaticField(0x67c)
    //     0x865bb4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x865bb8: ldr             x0, [x0, #0xcf8]
    // 0x865bbc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x865bc0: cmp             w0, w16
    // 0x865bc4: b.ne            #0x865bd0
    // 0x865bc8: r2 = _instance
    //     0x865bc8: ldr             x2, [PP, #0x30b0]  ; [pp+0x30b0] Field <TextInput._instance@81206165>: static late final (offset: 0x67c)
    // 0x865bcc: r0 = InitLateFinalStaticField()
    //     0x865bcc: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x865bd0: LoadField: r1 = r0->field_13
    //     0x865bd0: ldur            w1, [x0, #0x13]
    // 0x865bd4: DecompressPointer r1
    //     0x865bd4: add             x1, x1, HEAP, lsl #32
    // 0x865bd8: ldur            x2, [fp, #-8]
    // 0x865bdc: cmp             w1, w2
    // 0x865be0: r16 = true
    //     0x865be0: add             x16, NULL, #0x20  ; true
    // 0x865be4: r17 = false
    //     0x865be4: add             x17, NULL, #0x30  ; false
    // 0x865be8: csel            x0, x16, x17, eq
    // 0x865bec: LeaveFrame
    //     0x865bec: mov             SP, fp
    //     0x865bf0: ldp             fp, lr, [SP], #0x10
    // 0x865bf4: ret
    //     0x865bf4: ret             
    // 0x865bf8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x865bf8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x865bfc: b               #0x865bb4
  }
  _ setEditingState(/* No info */) {
    // ** addr: 0x86b798, size: 0x5c
    // 0x86b798: EnterFrame
    //     0x86b798: stp             fp, lr, [SP, #-0x10]!
    //     0x86b79c: mov             fp, SP
    // 0x86b7a0: AllocStack(0x8)
    //     0x86b7a0: sub             SP, SP, #8
    // 0x86b7a4: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x86b7a4: stur            x2, [fp, #-8]
    // 0x86b7a8: CheckStackOverflow
    //     0x86b7a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x86b7ac: cmp             SP, x16
    //     0x86b7b0: b.ls            #0x86b7ec
    // 0x86b7b4: r0 = LoadStaticField(0x67c)
    //     0x86b7b4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x86b7b8: ldr             x0, [x0, #0xcf8]
    // 0x86b7bc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x86b7c0: cmp             w0, w16
    // 0x86b7c4: b.ne            #0x86b7d0
    // 0x86b7c8: r2 = _instance
    //     0x86b7c8: ldr             x2, [PP, #0x30b0]  ; [pp+0x30b0] Field <TextInput._instance@81206165>: static late final (offset: 0x67c)
    // 0x86b7cc: r0 = InitLateFinalStaticField()
    //     0x86b7cc: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x86b7d0: mov             x1, x0
    // 0x86b7d4: ldur            x2, [fp, #-8]
    // 0x86b7d8: r0 = _setEditingState()
    //     0x86b7d8: bl              #0x8783d8  ; [package:flutter/src/services/text_input.dart] TextInput::_setEditingState
    // 0x86b7dc: r0 = Null
    //     0x86b7dc: mov             x0, NULL
    // 0x86b7e0: LeaveFrame
    //     0x86b7e0: mov             SP, fp
    //     0x86b7e4: ldp             fp, lr, [SP], #0x10
    // 0x86b7e8: ret
    //     0x86b7e8: ret             
    // 0x86b7ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x86b7ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x86b7f0: b               #0x86b7b4
  }
  _ requestAutofill(/* No info */) {
    // ** addr: 0x872bc8, size: 0x50
    // 0x872bc8: EnterFrame
    //     0x872bc8: stp             fp, lr, [SP, #-0x10]!
    //     0x872bcc: mov             fp, SP
    // 0x872bd0: CheckStackOverflow
    //     0x872bd0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x872bd4: cmp             SP, x16
    //     0x872bd8: b.ls            #0x872c10
    // 0x872bdc: r0 = LoadStaticField(0x67c)
    //     0x872bdc: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x872be0: ldr             x0, [x0, #0xcf8]
    // 0x872be4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x872be8: cmp             w0, w16
    // 0x872bec: b.ne            #0x872bf8
    // 0x872bf0: r2 = _instance
    //     0x872bf0: ldr             x2, [PP, #0x30b0]  ; [pp+0x30b0] Field <TextInput._instance@81206165>: static late final (offset: 0x67c)
    // 0x872bf4: r0 = InitLateFinalStaticField()
    //     0x872bf4: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x872bf8: mov             x1, x0
    // 0x872bfc: r0 = _requestAutofill()
    //     0x872bfc: bl              #0x872c18  ; [package:flutter/src/services/text_input.dart] TextInput::_requestAutofill
    // 0x872c00: r0 = Null
    //     0x872c00: mov             x0, NULL
    // 0x872c04: LeaveFrame
    //     0x872c04: mov             SP, fp
    //     0x872c08: ldp             fp, lr, [SP], #0x10
    // 0x872c0c: ret
    //     0x872c0c: ret             
    // 0x872c10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x872c10: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x872c14: b               #0x872bdc
  }
  _ show(/* No info */) {
    // ** addr: 0x872e78, size: 0x50
    // 0x872e78: EnterFrame
    //     0x872e78: stp             fp, lr, [SP, #-0x10]!
    //     0x872e7c: mov             fp, SP
    // 0x872e80: CheckStackOverflow
    //     0x872e80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x872e84: cmp             SP, x16
    //     0x872e88: b.ls            #0x872ec0
    // 0x872e8c: r0 = LoadStaticField(0x67c)
    //     0x872e8c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x872e90: ldr             x0, [x0, #0xcf8]
    // 0x872e94: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x872e98: cmp             w0, w16
    // 0x872e9c: b.ne            #0x872ea8
    // 0x872ea0: r2 = _instance
    //     0x872ea0: ldr             x2, [PP, #0x30b0]  ; [pp+0x30b0] Field <TextInput._instance@81206165>: static late final (offset: 0x67c)
    // 0x872ea4: r0 = InitLateFinalStaticField()
    //     0x872ea4: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x872ea8: mov             x1, x0
    // 0x872eac: r0 = _show()
    //     0x872eac: bl              #0x872ec8  ; [package:flutter/src/services/text_input.dart] TextInput::_show
    // 0x872eb0: r0 = Null
    //     0x872eb0: mov             x0, NULL
    // 0x872eb4: LeaveFrame
    //     0x872eb4: mov             SP, fp
    //     0x872eb8: ldp             fp, lr, [SP], #0x10
    // 0x872ebc: ret
    //     0x872ebc: ret             
    // 0x872ec0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x872ec0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x872ec4: b               #0x872e8c
  }
  _ updateStyle(/* No info */) {
    // ** addr: 0x873050, size: 0x5c
    // 0x873050: EnterFrame
    //     0x873050: stp             fp, lr, [SP, #-0x10]!
    //     0x873054: mov             fp, SP
    // 0x873058: AllocStack(0x8)
    //     0x873058: sub             SP, SP, #8
    // 0x87305c: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x87305c: stur            x2, [fp, #-8]
    // 0x873060: CheckStackOverflow
    //     0x873060: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x873064: cmp             SP, x16
    //     0x873068: b.ls            #0x8730a4
    // 0x87306c: r0 = LoadStaticField(0x67c)
    //     0x87306c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x873070: ldr             x0, [x0, #0xcf8]
    // 0x873074: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x873078: cmp             w0, w16
    // 0x87307c: b.ne            #0x873088
    // 0x873080: r2 = _instance
    //     0x873080: ldr             x2, [PP, #0x30b0]  ; [pp+0x30b0] Field <TextInput._instance@81206165>: static late final (offset: 0x67c)
    // 0x873084: r0 = InitLateFinalStaticField()
    //     0x873084: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x873088: mov             x1, x0
    // 0x87308c: ldur            x2, [fp, #-8]
    // 0x873090: r0 = _updateStyle()
    //     0x873090: bl              #0x8730ac  ; [package:flutter/src/services/text_input.dart] TextInput::_updateStyle
    // 0x873094: r0 = Null
    //     0x873094: mov             x0, NULL
    // 0x873098: LeaveFrame
    //     0x873098: mov             SP, fp
    //     0x87309c: ldp             fp, lr, [SP], #0x10
    // 0x8730a0: ret
    //     0x8730a0: ret             
    // 0x8730a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8730a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8730a8: b               #0x87306c
  }
  _ setCaretRect(/* No info */) {
    // ** addr: 0x873abc, size: 0x14c
    // 0x873abc: EnterFrame
    //     0x873abc: stp             fp, lr, [SP, #-0x10]!
    //     0x873ac0: mov             fp, SP
    // 0x873ac4: AllocStack(0x28)
    //     0x873ac4: sub             SP, SP, #0x28
    // 0x873ac8: SetupParameters(TextInputConnection this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */)
    //     0x873ac8: mov             x0, x2
    //     0x873acc: stur            x1, [fp, #-0x10]
    //     0x873ad0: stur            x2, [fp, #-0x18]
    // 0x873ad4: CheckStackOverflow
    //     0x873ad4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x873ad8: cmp             SP, x16
    //     0x873adc: b.ls            #0x873c00
    // 0x873ae0: LoadField: r2 = r1->field_13
    //     0x873ae0: ldur            w2, [x1, #0x13]
    // 0x873ae4: DecompressPointer r2
    //     0x873ae4: add             x2, x2, HEAP, lsl #32
    // 0x873ae8: stur            x2, [fp, #-8]
    // 0x873aec: cmp             w2, NULL
    // 0x873af0: b.ne            #0x873afc
    // 0x873af4: mov             x2, x0
    // 0x873af8: b               #0x873b80
    // 0x873afc: cmp             w0, w2
    // 0x873b00: b.eq            #0x873b6c
    // 0x873b04: r16 = Rect
    //     0x873b04: ldr             x16, [PP, #0x2a28]  ; [pp+0x2a28] Type: Rect
    // 0x873b08: r30 = Rect
    //     0x873b08: ldr             lr, [PP, #0x2a28]  ; [pp+0x2a28] Type: Rect
    // 0x873b0c: stp             lr, x16, [SP]
    // 0x873b10: r0 = ==()
    //     0x873b10: bl              #0x12b7fbc  ; [dart:core] _Type::==
    // 0x873b14: tbz             w0, #4, #0x873b24
    // 0x873b18: ldur            x1, [fp, #-0x10]
    // 0x873b1c: ldur            x2, [fp, #-0x18]
    // 0x873b20: b               #0x873b80
    // 0x873b24: ldur            x2, [fp, #-0x18]
    // 0x873b28: ldur            x0, [fp, #-8]
    // 0x873b2c: LoadField: d0 = r0->field_7
    //     0x873b2c: ldur            d0, [x0, #7]
    // 0x873b30: LoadField: d1 = r2->field_7
    //     0x873b30: ldur            d1, [x2, #7]
    // 0x873b34: fcmp            d0, d1
    // 0x873b38: b.ne            #0x873b7c
    // 0x873b3c: LoadField: d0 = r0->field_f
    //     0x873b3c: ldur            d0, [x0, #0xf]
    // 0x873b40: LoadField: d1 = r2->field_f
    //     0x873b40: ldur            d1, [x2, #0xf]
    // 0x873b44: fcmp            d0, d1
    // 0x873b48: b.ne            #0x873b7c
    // 0x873b4c: ArrayLoad: d0 = r0[0]  ; List_8
    //     0x873b4c: ldur            d0, [x0, #0x17]
    // 0x873b50: ArrayLoad: d1 = r2[0]  ; List_8
    //     0x873b50: ldur            d1, [x2, #0x17]
    // 0x873b54: fcmp            d0, d1
    // 0x873b58: b.ne            #0x873b7c
    // 0x873b5c: LoadField: d0 = r0->field_1f
    //     0x873b5c: ldur            d0, [x0, #0x1f]
    // 0x873b60: LoadField: d1 = r2->field_1f
    //     0x873b60: ldur            d1, [x2, #0x1f]
    // 0x873b64: fcmp            d0, d1
    // 0x873b68: b.ne            #0x873b7c
    // 0x873b6c: r0 = Null
    //     0x873b6c: mov             x0, NULL
    // 0x873b70: LeaveFrame
    //     0x873b70: mov             SP, fp
    //     0x873b74: ldp             fp, lr, [SP], #0x10
    // 0x873b78: ret
    //     0x873b78: ret             
    // 0x873b7c: ldur            x1, [fp, #-0x10]
    // 0x873b80: mov             x0, x2
    // 0x873b84: StoreField: r1->field_13 = r0
    //     0x873b84: stur            w0, [x1, #0x13]
    //     0x873b88: ldurb           w16, [x1, #-1]
    //     0x873b8c: ldurb           w17, [x0, #-1]
    //     0x873b90: and             x16, x17, x16, lsr #2
    //     0x873b94: tst             x16, HEAP, lsr #32
    //     0x873b98: b.eq            #0x873ba0
    //     0x873b9c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x873ba0: mov             x1, x2
    // 0x873ba4: r0 = isFinite()
    //     0x873ba4: bl              #0x873f68  ; [dart:ui] Rect::isFinite
    // 0x873ba8: tbnz            w0, #4, #0x873bb4
    // 0x873bac: ldur            x2, [fp, #-0x18]
    // 0x873bb0: b               #0x873bc4
    // 0x873bb4: r1 = Instance_Offset
    //     0x873bb4: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x873bb8: r2 = Instance_Size
    //     0x873bb8: ldr             x2, [PP, #0x5a28]  ; [pp+0x5a28] Obj!Size@12a74b1
    // 0x873bbc: r0 = &()
    //     0x873bbc: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0x873bc0: mov             x2, x0
    // 0x873bc4: stur            x2, [fp, #-8]
    // 0x873bc8: r0 = LoadStaticField(0x67c)
    //     0x873bc8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x873bcc: ldr             x0, [x0, #0xcf8]
    // 0x873bd0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x873bd4: cmp             w0, w16
    // 0x873bd8: b.ne            #0x873be4
    // 0x873bdc: r2 = _instance
    //     0x873bdc: ldr             x2, [PP, #0x30b0]  ; [pp+0x30b0] Field <TextInput._instance@81206165>: static late final (offset: 0x67c)
    // 0x873be0: r0 = InitLateFinalStaticField()
    //     0x873be0: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x873be4: mov             x1, x0
    // 0x873be8: ldur            x2, [fp, #-8]
    // 0x873bec: r0 = _setCaretRect()
    //     0x873bec: bl              #0x873c08  ; [package:flutter/src/services/text_input.dart] TextInput::_setCaretRect
    // 0x873bf0: r0 = Null
    //     0x873bf0: mov             x0, NULL
    // 0x873bf4: LeaveFrame
    //     0x873bf4: mov             SP, fp
    //     0x873bf8: ldp             fp, lr, [SP], #0x10
    // 0x873bfc: ret
    //     0x873bfc: ret             
    // 0x873c00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x873c00: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x873c04: b               #0x873ae0
  }
  _ setComposingRect(/* No info */) {
    // ** addr: 0x87411c, size: 0x14c
    // 0x87411c: EnterFrame
    //     0x87411c: stp             fp, lr, [SP, #-0x10]!
    //     0x874120: mov             fp, SP
    // 0x874124: AllocStack(0x28)
    //     0x874124: sub             SP, SP, #0x28
    // 0x874128: SetupParameters(TextInputConnection this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */)
    //     0x874128: mov             x0, x2
    //     0x87412c: stur            x1, [fp, #-0x10]
    //     0x874130: stur            x2, [fp, #-0x18]
    // 0x874134: CheckStackOverflow
    //     0x874134: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x874138: cmp             SP, x16
    //     0x87413c: b.ls            #0x874260
    // 0x874140: LoadField: r2 = r1->field_f
    //     0x874140: ldur            w2, [x1, #0xf]
    // 0x874144: DecompressPointer r2
    //     0x874144: add             x2, x2, HEAP, lsl #32
    // 0x874148: stur            x2, [fp, #-8]
    // 0x87414c: cmp             w2, NULL
    // 0x874150: b.ne            #0x87415c
    // 0x874154: mov             x2, x0
    // 0x874158: b               #0x8741e0
    // 0x87415c: cmp             w0, w2
    // 0x874160: b.eq            #0x8741cc
    // 0x874164: r16 = Rect
    //     0x874164: ldr             x16, [PP, #0x2a28]  ; [pp+0x2a28] Type: Rect
    // 0x874168: r30 = Rect
    //     0x874168: ldr             lr, [PP, #0x2a28]  ; [pp+0x2a28] Type: Rect
    // 0x87416c: stp             lr, x16, [SP]
    // 0x874170: r0 = ==()
    //     0x874170: bl              #0x12b7fbc  ; [dart:core] _Type::==
    // 0x874174: tbz             w0, #4, #0x874184
    // 0x874178: ldur            x1, [fp, #-0x10]
    // 0x87417c: ldur            x2, [fp, #-0x18]
    // 0x874180: b               #0x8741e0
    // 0x874184: ldur            x2, [fp, #-0x18]
    // 0x874188: ldur            x0, [fp, #-8]
    // 0x87418c: LoadField: d0 = r0->field_7
    //     0x87418c: ldur            d0, [x0, #7]
    // 0x874190: LoadField: d1 = r2->field_7
    //     0x874190: ldur            d1, [x2, #7]
    // 0x874194: fcmp            d0, d1
    // 0x874198: b.ne            #0x8741dc
    // 0x87419c: LoadField: d0 = r0->field_f
    //     0x87419c: ldur            d0, [x0, #0xf]
    // 0x8741a0: LoadField: d1 = r2->field_f
    //     0x8741a0: ldur            d1, [x2, #0xf]
    // 0x8741a4: fcmp            d0, d1
    // 0x8741a8: b.ne            #0x8741dc
    // 0x8741ac: ArrayLoad: d0 = r0[0]  ; List_8
    //     0x8741ac: ldur            d0, [x0, #0x17]
    // 0x8741b0: ArrayLoad: d1 = r2[0]  ; List_8
    //     0x8741b0: ldur            d1, [x2, #0x17]
    // 0x8741b4: fcmp            d0, d1
    // 0x8741b8: b.ne            #0x8741dc
    // 0x8741bc: LoadField: d0 = r0->field_1f
    //     0x8741bc: ldur            d0, [x0, #0x1f]
    // 0x8741c0: LoadField: d1 = r2->field_1f
    //     0x8741c0: ldur            d1, [x2, #0x1f]
    // 0x8741c4: fcmp            d0, d1
    // 0x8741c8: b.ne            #0x8741dc
    // 0x8741cc: r0 = Null
    //     0x8741cc: mov             x0, NULL
    // 0x8741d0: LeaveFrame
    //     0x8741d0: mov             SP, fp
    //     0x8741d4: ldp             fp, lr, [SP], #0x10
    // 0x8741d8: ret
    //     0x8741d8: ret             
    // 0x8741dc: ldur            x1, [fp, #-0x10]
    // 0x8741e0: mov             x0, x2
    // 0x8741e4: StoreField: r1->field_f = r0
    //     0x8741e4: stur            w0, [x1, #0xf]
    //     0x8741e8: ldurb           w16, [x1, #-1]
    //     0x8741ec: ldurb           w17, [x0, #-1]
    //     0x8741f0: and             x16, x17, x16, lsr #2
    //     0x8741f4: tst             x16, HEAP, lsr #32
    //     0x8741f8: b.eq            #0x874200
    //     0x8741fc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x874200: mov             x1, x2
    // 0x874204: r0 = isFinite()
    //     0x874204: bl              #0x873f68  ; [dart:ui] Rect::isFinite
    // 0x874208: tbnz            w0, #4, #0x874214
    // 0x87420c: ldur            x2, [fp, #-0x18]
    // 0x874210: b               #0x874224
    // 0x874214: r1 = Instance_Offset
    //     0x874214: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x874218: r2 = Instance_Size
    //     0x874218: ldr             x2, [PP, #0x5a28]  ; [pp+0x5a28] Obj!Size@12a74b1
    // 0x87421c: r0 = &()
    //     0x87421c: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0x874220: mov             x2, x0
    // 0x874224: stur            x2, [fp, #-8]
    // 0x874228: r0 = LoadStaticField(0x67c)
    //     0x874228: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87422c: ldr             x0, [x0, #0xcf8]
    // 0x874230: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x874234: cmp             w0, w16
    // 0x874238: b.ne            #0x874244
    // 0x87423c: r2 = _instance
    //     0x87423c: ldr             x2, [PP, #0x30b0]  ; [pp+0x30b0] Field <TextInput._instance@81206165>: static late final (offset: 0x67c)
    // 0x874240: r0 = InitLateFinalStaticField()
    //     0x874240: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x874244: mov             x1, x0
    // 0x874248: ldur            x2, [fp, #-8]
    // 0x87424c: r0 = _setComposingTextRect()
    //     0x87424c: bl              #0x874268  ; [package:flutter/src/services/text_input.dart] TextInput::_setComposingTextRect
    // 0x874250: r0 = Null
    //     0x874250: mov             x0, NULL
    // 0x874254: LeaveFrame
    //     0x874254: mov             SP, fp
    //     0x874258: ldp             fp, lr, [SP], #0x10
    // 0x87425c: ret
    //     0x87425c: ret             
    // 0x874260: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x874260: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x874264: b               #0x874140
  }
  _ setEditableSizeAndTransform(/* No info */) {
    // ** addr: 0x87470c, size: 0x100
    // 0x87470c: EnterFrame
    //     0x87470c: stp             fp, lr, [SP, #-0x10]!
    //     0x874710: mov             fp, SP
    // 0x874714: AllocStack(0x28)
    //     0x874714: sub             SP, SP, #0x28
    // 0x874718: SetupParameters(TextInputConnection this /* r1 => r2, fp-0x18 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0x874718: stur            x1, [fp, #-8]
    //     0x87471c: mov             x16, x2
    //     0x874720: mov             x2, x1
    //     0x874724: mov             x1, x16
    //     0x874728: mov             x0, x3
    //     0x87472c: stur            x1, [fp, #-0x10]
    //     0x874730: stur            x3, [fp, #-0x18]
    // 0x874734: CheckStackOverflow
    //     0x874734: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x874738: cmp             SP, x16
    //     0x87473c: b.ls            #0x874804
    // 0x874740: LoadField: r3 = r2->field_7
    //     0x874740: ldur            w3, [x2, #7]
    // 0x874744: DecompressPointer r3
    //     0x874744: add             x3, x3, HEAP, lsl #32
    // 0x874748: cmp             w3, NULL
    // 0x87474c: b.eq            #0x874784
    // 0x874750: LoadField: d0 = r3->field_7
    //     0x874750: ldur            d0, [x3, #7]
    // 0x874754: LoadField: d1 = r1->field_7
    //     0x874754: ldur            d1, [x1, #7]
    // 0x874758: fcmp            d0, d1
    // 0x87475c: b.ne            #0x874784
    // 0x874760: LoadField: d0 = r3->field_f
    //     0x874760: ldur            d0, [x3, #0xf]
    // 0x874764: LoadField: d1 = r1->field_f
    //     0x874764: ldur            d1, [x1, #0xf]
    // 0x874768: fcmp            d0, d1
    // 0x87476c: b.ne            #0x874784
    // 0x874770: LoadField: r3 = r2->field_b
    //     0x874770: ldur            w3, [x2, #0xb]
    // 0x874774: DecompressPointer r3
    //     0x874774: add             x3, x3, HEAP, lsl #32
    // 0x874778: stp             x3, x0, [SP]
    // 0x87477c: r0 = ==()
    //     0x87477c: bl              #0x12842b8  ; [package:vector_math/vector_math_64.dart] Matrix4::==
    // 0x874780: tbz             w0, #4, #0x8747f4
    // 0x874784: ldur            x1, [fp, #-8]
    // 0x874788: ldur            x0, [fp, #-0x10]
    // 0x87478c: StoreField: r1->field_7 = r0
    //     0x87478c: stur            w0, [x1, #7]
    //     0x874790: ldurb           w16, [x1, #-1]
    //     0x874794: ldurb           w17, [x0, #-1]
    //     0x874798: and             x16, x17, x16, lsr #2
    //     0x87479c: tst             x16, HEAP, lsr #32
    //     0x8747a0: b.eq            #0x8747a8
    //     0x8747a4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8747a8: ldur            x0, [fp, #-0x18]
    // 0x8747ac: StoreField: r1->field_b = r0
    //     0x8747ac: stur            w0, [x1, #0xb]
    //     0x8747b0: ldurb           w16, [x1, #-1]
    //     0x8747b4: ldurb           w17, [x0, #-1]
    //     0x8747b8: and             x16, x17, x16, lsr #2
    //     0x8747bc: tst             x16, HEAP, lsr #32
    //     0x8747c0: b.eq            #0x8747c8
    //     0x8747c4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8747c8: r0 = LoadStaticField(0x67c)
    //     0x8747c8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8747cc: ldr             x0, [x0, #0xcf8]
    // 0x8747d0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8747d4: cmp             w0, w16
    // 0x8747d8: b.ne            #0x8747e4
    // 0x8747dc: r2 = _instance
    //     0x8747dc: ldr             x2, [PP, #0x30b0]  ; [pp+0x30b0] Field <TextInput._instance@81206165>: static late final (offset: 0x67c)
    // 0x8747e0: r0 = InitLateFinalStaticField()
    //     0x8747e0: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8747e4: mov             x1, x0
    // 0x8747e8: ldur            x2, [fp, #-0x10]
    // 0x8747ec: ldur            x3, [fp, #-0x18]
    // 0x8747f0: r0 = _setEditableSizeAndTransform()
    //     0x8747f0: bl              #0x87480c  ; [package:flutter/src/services/text_input.dart] TextInput::_setEditableSizeAndTransform
    // 0x8747f4: r0 = Null
    //     0x8747f4: mov             x0, NULL
    // 0x8747f8: LeaveFrame
    //     0x8747f8: mov             SP, fp
    //     0x8747fc: ldp             fp, lr, [SP], #0x10
    // 0x874800: ret
    //     0x874800: ret             
    // 0x874804: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x874804: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x874808: b               #0x874740
  }
  _ TextInputConnection._(/* No info */) {
    // ** addr: 0x874b50, size: 0xc8
    // 0x874b50: EnterFrame
    //     0x874b50: stp             fp, lr, [SP, #-0x10]!
    //     0x874b54: mov             fp, SP
    // 0x874b58: AllocStack(0x10)
    //     0x874b58: sub             SP, SP, #0x10
    // 0x874b5c: SetupParameters(TextInputConnection this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x874b5c: mov             x3, x1
    //     0x874b60: mov             x0, x2
    //     0x874b64: stur            x1, [fp, #-8]
    //     0x874b68: stur            x2, [fp, #-0x10]
    // 0x874b6c: CheckStackOverflow
    //     0x874b6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x874b70: cmp             SP, x16
    //     0x874b74: b.ls            #0x874c10
    // 0x874b78: r1 = <SelectionRect>
    //     0x874b78: ldr             x1, [PP, #0x5ae0]  ; [pp+0x5ae0] TypeArguments: <SelectionRect>
    // 0x874b7c: r2 = 0
    //     0x874b7c: mov             x2, #0
    // 0x874b80: r0 = _GrowableList()
    //     0x874b80: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x874b84: ldur            x3, [fp, #-8]
    // 0x874b88: ArrayStore: r3[0] = r0  ; List_4
    //     0x874b88: stur            w0, [x3, #0x17]
    //     0x874b8c: ldurb           w16, [x3, #-1]
    //     0x874b90: ldurb           w17, [x0, #-1]
    //     0x874b94: and             x16, x17, x16, lsr #2
    //     0x874b98: tst             x16, HEAP, lsr #32
    //     0x874b9c: b.eq            #0x874ba4
    //     0x874ba0: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x874ba4: ldur            x0, [fp, #-0x10]
    // 0x874ba8: StoreField: r3->field_23 = r0
    //     0x874ba8: stur            w0, [x3, #0x23]
    //     0x874bac: ldurb           w16, [x3, #-1]
    //     0x874bb0: ldurb           w17, [x0, #-1]
    //     0x874bb4: and             x16, x17, x16, lsr #2
    //     0x874bb8: tst             x16, HEAP, lsr #32
    //     0x874bbc: b.eq            #0x874bc4
    //     0x874bc0: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x874bc4: r4 = LoadStaticField(0x698)
    //     0x874bc4: ldr             x4, [THR, #0x78]  ; THR::field_table_values
    //     0x874bc8: ldr             x4, [x4, #0xd30]
    // 0x874bcc: r5 = LoadInt32Instr(r4)
    //     0x874bcc: sbfx            x5, x4, #1, #0x1f
    //     0x874bd0: tbz             w4, #0, #0x874bd8
    //     0x874bd4: ldur            x5, [x4, #7]
    // 0x874bd8: add             x4, x5, #1
    // 0x874bdc: r0 = BoxInt64Instr(r4)
    //     0x874bdc: sbfiz           x0, x4, #1, #0x1f
    //     0x874be0: cmp             x4, x0, asr #1
    //     0x874be4: b.eq            #0x874bf0
    //     0x874be8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x874bec: stur            x4, [x0, #7]
    // 0x874bf0: mov             x2, x0
    // 0x874bf4: StoreStaticField(0x698, r2)
    //     0x874bf4: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x874bf8: str             x2, [x1, #0xd30]
    // 0x874bfc: StoreField: r3->field_1b = r5
    //     0x874bfc: stur            x5, [x3, #0x1b]
    // 0x874c00: r0 = Null
    //     0x874c00: mov             x0, NULL
    // 0x874c04: LeaveFrame
    //     0x874c04: mov             SP, fp
    //     0x874c08: ldp             fp, lr, [SP], #0x10
    // 0x874c0c: ret
    //     0x874c0c: ret             
    // 0x874c10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x874c10: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x874c14: b               #0x874b78
  }
  _ close(/* No info */) {
    // ** addr: 0x875b68, size: 0x6c
    // 0x875b68: EnterFrame
    //     0x875b68: stp             fp, lr, [SP, #-0x10]!
    //     0x875b6c: mov             fp, SP
    // 0x875b70: AllocStack(0x8)
    //     0x875b70: sub             SP, SP, #8
    // 0x875b74: SetupParameters(TextInputConnection this /* r1 => r1, fp-0x8 */)
    //     0x875b74: stur            x1, [fp, #-8]
    // 0x875b78: CheckStackOverflow
    //     0x875b78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x875b7c: cmp             SP, x16
    //     0x875b80: b.ls            #0x875bcc
    // 0x875b84: r0 = LoadStaticField(0x67c)
    //     0x875b84: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x875b88: ldr             x0, [x0, #0xcf8]
    // 0x875b8c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x875b90: cmp             w0, w16
    // 0x875b94: b.ne            #0x875ba0
    // 0x875b98: r2 = _instance
    //     0x875b98: ldr             x2, [PP, #0x30b0]  ; [pp+0x30b0] Field <TextInput._instance@81206165>: static late final (offset: 0x67c)
    // 0x875b9c: r0 = InitLateFinalStaticField()
    //     0x875b9c: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x875ba0: LoadField: r1 = r0->field_13
    //     0x875ba0: ldur            w1, [x0, #0x13]
    // 0x875ba4: DecompressPointer r1
    //     0x875ba4: add             x1, x1, HEAP, lsl #32
    // 0x875ba8: ldur            x2, [fp, #-8]
    // 0x875bac: cmp             w1, w2
    // 0x875bb0: b.ne            #0x875bbc
    // 0x875bb4: mov             x1, x0
    // 0x875bb8: r0 = _clearClient()
    //     0x875bb8: bl              #0x875bd4  ; [package:flutter/src/services/text_input.dart] TextInput::_clearClient
    // 0x875bbc: r0 = Null
    //     0x875bbc: mov             x0, NULL
    // 0x875bc0: LeaveFrame
    //     0x875bc0: mov             SP, fp
    //     0x875bc4: ldp             fp, lr, [SP], #0x10
    // 0x875bc8: ret
    //     0x875bc8: ret             
    // 0x875bcc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x875bcc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x875bd0: b               #0x875b84
  }
  get _ scribbleInProgress(/* No info */) {
    // ** addr: 0x877a14, size: 0x50
    // 0x877a14: EnterFrame
    //     0x877a14: stp             fp, lr, [SP, #-0x10]!
    //     0x877a18: mov             fp, SP
    // 0x877a1c: CheckStackOverflow
    //     0x877a1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x877a20: cmp             SP, x16
    //     0x877a24: b.ls            #0x877a5c
    // 0x877a28: r0 = LoadStaticField(0x67c)
    //     0x877a28: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x877a2c: ldr             x0, [x0, #0xcf8]
    // 0x877a30: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x877a34: cmp             w0, w16
    // 0x877a38: b.ne            #0x877a44
    // 0x877a3c: r2 = _instance
    //     0x877a3c: ldr             x2, [PP, #0x30b0]  ; [pp+0x30b0] Field <TextInput._instance@81206165>: static late final (offset: 0x67c)
    // 0x877a40: r0 = InitLateFinalStaticField()
    //     0x877a40: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x877a44: LoadField: r1 = r0->field_23
    //     0x877a44: ldur            w1, [x0, #0x23]
    // 0x877a48: DecompressPointer r1
    //     0x877a48: add             x1, x1, HEAP, lsl #32
    // 0x877a4c: mov             x0, x1
    // 0x877a50: LeaveFrame
    //     0x877a50: mov             SP, fp
    //     0x877a54: ldp             fp, lr, [SP], #0x10
    // 0x877a58: ret
    //     0x877a58: ret             
    // 0x877a5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x877a5c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x877a60: b               #0x877a28
  }
  _ updateConfig(/* No info */) {
    // ** addr: 0xeef75c, size: 0x5c
    // 0xeef75c: EnterFrame
    //     0xeef75c: stp             fp, lr, [SP, #-0x10]!
    //     0xeef760: mov             fp, SP
    // 0xeef764: AllocStack(0x8)
    //     0xeef764: sub             SP, SP, #8
    // 0xeef768: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0xeef768: stur            x2, [fp, #-8]
    // 0xeef76c: CheckStackOverflow
    //     0xeef76c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeef770: cmp             SP, x16
    //     0xeef774: b.ls            #0xeef7b0
    // 0xeef778: r0 = LoadStaticField(0x67c)
    //     0xeef778: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xeef77c: ldr             x0, [x0, #0xcf8]
    // 0xeef780: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xeef784: cmp             w0, w16
    // 0xeef788: b.ne            #0xeef794
    // 0xeef78c: r2 = _instance
    //     0xeef78c: ldr             x2, [PP, #0x30b0]  ; [pp+0x30b0] Field <TextInput._instance@81206165>: static late final (offset: 0x67c)
    // 0xeef790: r0 = InitLateFinalStaticField()
    //     0xeef790: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xeef794: mov             x1, x0
    // 0xeef798: ldur            x2, [fp, #-8]
    // 0xeef79c: r0 = _updateConfig()
    //     0xeef79c: bl              #0xeef7b8  ; [package:flutter/src/services/text_input.dart] TextInput::_updateConfig
    // 0xeef7a0: r0 = Null
    //     0xeef7a0: mov             x0, NULL
    // 0xeef7a4: LeaveFrame
    //     0xeef7a4: mov             SP, fp
    //     0xeef7a8: ldp             fp, lr, [SP], #0x10
    // 0xeef7ac: ret
    //     0xeef7ac: ret             
    // 0xeef7b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeef7b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeef7b4: b               #0xeef778
  }
}

// class id: 2726, size: 0x8, field offset: 0x8
abstract class DeltaTextInputClient extends Object
    implements TextInputClient {
}

// class id: 2727, size: 0x18, field offset: 0x8
//   const constructor, 
class SelectionRect extends Object {
}

// class id: 2728, size: 0x8, field offset: 0x8
abstract class ScribbleClient extends Object {
}

// class id: 2729, size: 0x14, field offset: 0x8
//   const constructor, 
class TextEditingValue extends Object {

  _OneByteString field_8;
  TextSelection field_c;
  TextRange field_10;

  _ copyWith(/* No info */) {
    // ** addr: 0x86ff64, size: 0x164
    // 0x86ff64: EnterFrame
    //     0x86ff64: stp             fp, lr, [SP, #-0x10]!
    //     0x86ff68: mov             fp, SP
    // 0x86ff6c: AllocStack(0x18)
    //     0x86ff6c: sub             SP, SP, #0x18
    // 0x86ff70: SetupParameters({dynamic composing = Null /* r3 */, dynamic selection = Null /* r5 */, dynamic text = Null /* r0 */})
    //     0x86ff70: ldur            w0, [x4, #0x13]
    //     0x86ff74: ldur            w2, [x4, #0x1f]
    //     0x86ff78: add             x2, x2, HEAP, lsl #32
    //     0x86ff7c: ldr             x16, [PP, #0x57d8]  ; [pp+0x57d8] "composing"
    //     0x86ff80: cmp             w2, w16
    //     0x86ff84: b.ne            #0x86ffa8
    //     0x86ff88: ldur            w2, [x4, #0x23]
    //     0x86ff8c: add             x2, x2, HEAP, lsl #32
    //     0x86ff90: sub             w3, w0, w2
    //     0x86ff94: add             x2, fp, w3, sxtw #2
    //     0x86ff98: ldr             x2, [x2, #8]
    //     0x86ff9c: mov             x3, x2
    //     0x86ffa0: mov             x2, #1
    //     0x86ffa4: b               #0x86ffb0
    //     0x86ffa8: mov             x3, NULL
    //     0x86ffac: mov             x2, #0
    //     0x86ffb0: lsl             x5, x2, #1
    //     0x86ffb4: lsl             w6, w5, #1
    //     0x86ffb8: add             w7, w6, #8
    //     0x86ffbc: add             x16, x4, w7, sxtw #1
    //     0x86ffc0: ldur            w8, [x16, #0xf]
    //     0x86ffc4: add             x8, x8, HEAP, lsl #32
    //     0x86ffc8: ldr             x16, [PP, #0x57e0]  ; [pp+0x57e0] "selection"
    //     0x86ffcc: cmp             w8, w16
    //     0x86ffd0: b.ne            #0x870004
    //     0x86ffd4: add             w2, w6, #0xa
    //     0x86ffd8: add             x16, x4, w2, sxtw #1
    //     0x86ffdc: ldur            w6, [x16, #0xf]
    //     0x86ffe0: add             x6, x6, HEAP, lsl #32
    //     0x86ffe4: sub             w2, w0, w6
    //     0x86ffe8: add             x6, fp, w2, sxtw #2
    //     0x86ffec: ldr             x6, [x6, #8]
    //     0x86fff0: add             w2, w5, #2
    //     0x86fff4: sbfx            x5, x2, #1, #0x1f
    //     0x86fff8: mov             x2, x5
    //     0x86fffc: mov             x5, x6
    //     0x870000: b               #0x870008
    //     0x870004: mov             x5, NULL
    //     0x870008: lsl             x6, x2, #1
    //     0x87000c: lsl             w2, w6, #1
    //     0x870010: add             w6, w2, #8
    //     0x870014: add             x16, x4, w6, sxtw #1
    //     0x870018: ldur            w7, [x16, #0xf]
    //     0x87001c: add             x7, x7, HEAP, lsl #32
    //     0x870020: ldr             x16, [PP, #0x57e8]  ; [pp+0x57e8] "text"
    //     0x870024: cmp             w7, w16
    //     0x870028: b.ne            #0x87004c
    //     0x87002c: add             w6, w2, #0xa
    //     0x870030: add             x16, x4, w6, sxtw #1
    //     0x870034: ldur            w2, [x16, #0xf]
    //     0x870038: add             x2, x2, HEAP, lsl #32
    //     0x87003c: sub             w4, w0, w2
    //     0x870040: add             x0, fp, w4, sxtw #2
    //     0x870044: ldr             x0, [x0, #8]
    //     0x870048: b               #0x870050
    //     0x87004c: mov             x0, NULL
    // 0x870050: cmp             w0, NULL
    // 0x870054: b.ne            #0x870060
    // 0x870058: LoadField: r0 = r1->field_7
    //     0x870058: ldur            w0, [x1, #7]
    // 0x87005c: DecompressPointer r0
    //     0x87005c: add             x0, x0, HEAP, lsl #32
    // 0x870060: stur            x0, [fp, #-0x18]
    // 0x870064: cmp             w5, NULL
    // 0x870068: b.ne            #0x870078
    // 0x87006c: LoadField: r2 = r1->field_b
    //     0x87006c: ldur            w2, [x1, #0xb]
    // 0x870070: DecompressPointer r2
    //     0x870070: add             x2, x2, HEAP, lsl #32
    // 0x870074: b               #0x87007c
    // 0x870078: mov             x2, x5
    // 0x87007c: stur            x2, [fp, #-0x10]
    // 0x870080: cmp             w3, NULL
    // 0x870084: b.ne            #0x870098
    // 0x870088: LoadField: r3 = r1->field_f
    //     0x870088: ldur            w3, [x1, #0xf]
    // 0x87008c: DecompressPointer r3
    //     0x87008c: add             x3, x3, HEAP, lsl #32
    // 0x870090: mov             x1, x3
    // 0x870094: b               #0x87009c
    // 0x870098: mov             x1, x3
    // 0x87009c: stur            x1, [fp, #-8]
    // 0x8700a0: r0 = TextEditingValue()
    //     0x8700a0: bl              #0x86e1d4  ; AllocateTextEditingValueStub -> TextEditingValue (size=0x14)
    // 0x8700a4: ldur            x1, [fp, #-0x18]
    // 0x8700a8: StoreField: r0->field_7 = r1
    //     0x8700a8: stur            w1, [x0, #7]
    // 0x8700ac: ldur            x1, [fp, #-0x10]
    // 0x8700b0: StoreField: r0->field_b = r1
    //     0x8700b0: stur            w1, [x0, #0xb]
    // 0x8700b4: ldur            x1, [fp, #-8]
    // 0x8700b8: StoreField: r0->field_f = r1
    //     0x8700b8: stur            w1, [x0, #0xf]
    // 0x8700bc: LeaveFrame
    //     0x8700bc: mov             SP, fp
    //     0x8700c0: ldp             fp, lr, [SP], #0x10
    // 0x8700c4: ret
    //     0x8700c4: ret             
  }
  _ toJSON(/* No info */) {
    // ** addr: 0x877d3c, size: 0x228
    // 0x877d3c: EnterFrame
    //     0x877d3c: stp             fp, lr, [SP, #-0x10]!
    //     0x877d40: mov             fp, SP
    // 0x877d44: AllocStack(0x30)
    //     0x877d44: sub             SP, SP, #0x30
    // 0x877d48: SetupParameters(TextEditingValue this /* r1 => r0, fp-0x8 */)
    //     0x877d48: mov             x0, x1
    //     0x877d4c: stur            x1, [fp, #-8]
    // 0x877d50: CheckStackOverflow
    //     0x877d50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x877d54: cmp             SP, x16
    //     0x877d58: b.ls            #0x877f5c
    // 0x877d5c: r1 = Null
    //     0x877d5c: mov             x1, NULL
    // 0x877d60: r2 = 28
    //     0x877d60: mov             x2, #0x1c
    // 0x877d64: r0 = AllocateArray()
    //     0x877d64: bl              #0x13df928  ; AllocateArrayStub
    // 0x877d68: mov             x3, x0
    // 0x877d6c: stur            x3, [fp, #-0x20]
    // 0x877d70: r16 = "text"
    //     0x877d70: ldr             x16, [PP, #0x57e8]  ; [pp+0x57e8] "text"
    // 0x877d74: StoreField: r3->field_f = r16
    //     0x877d74: stur            w16, [x3, #0xf]
    // 0x877d78: ldur            x4, [fp, #-8]
    // 0x877d7c: LoadField: r0 = r4->field_7
    //     0x877d7c: ldur            w0, [x4, #7]
    // 0x877d80: DecompressPointer r0
    //     0x877d80: add             x0, x0, HEAP, lsl #32
    // 0x877d84: StoreField: r3->field_13 = r0
    //     0x877d84: stur            w0, [x3, #0x13]
    // 0x877d88: r16 = "selectionBase"
    //     0x877d88: ldr             x16, [PP, #0x5f70]  ; [pp+0x5f70] "selectionBase"
    // 0x877d8c: ArrayStore: r3[0] = r16  ; List_4
    //     0x877d8c: stur            w16, [x3, #0x17]
    // 0x877d90: LoadField: r5 = r4->field_b
    //     0x877d90: ldur            w5, [x4, #0xb]
    // 0x877d94: DecompressPointer r5
    //     0x877d94: add             x5, x5, HEAP, lsl #32
    // 0x877d98: stur            x5, [fp, #-0x18]
    // 0x877d9c: ArrayLoad: r2 = r5[0]  ; List_8
    //     0x877d9c: ldur            x2, [x5, #0x17]
    // 0x877da0: r0 = BoxInt64Instr(r2)
    //     0x877da0: sbfiz           x0, x2, #1, #0x1f
    //     0x877da4: cmp             x2, x0, asr #1
    //     0x877da8: b.eq            #0x877db4
    //     0x877dac: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x877db0: stur            x2, [x0, #7]
    // 0x877db4: mov             x1, x3
    // 0x877db8: ArrayStore: r1[3] = r0  ; List_4
    //     0x877db8: add             x25, x1, #0x1b
    //     0x877dbc: str             w0, [x25]
    //     0x877dc0: tbz             w0, #0, #0x877ddc
    //     0x877dc4: ldurb           w16, [x1, #-1]
    //     0x877dc8: ldurb           w17, [x0, #-1]
    //     0x877dcc: and             x16, x17, x16, lsr #2
    //     0x877dd0: tst             x16, HEAP, lsr #32
    //     0x877dd4: b.eq            #0x877ddc
    //     0x877dd8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x877ddc: r16 = "selectionExtent"
    //     0x877ddc: ldr             x16, [PP, #0x5f88]  ; [pp+0x5f88] "selectionExtent"
    // 0x877de0: StoreField: r3->field_1f = r16
    //     0x877de0: stur            w16, [x3, #0x1f]
    // 0x877de4: LoadField: r2 = r5->field_1f
    //     0x877de4: ldur            x2, [x5, #0x1f]
    // 0x877de8: r0 = BoxInt64Instr(r2)
    //     0x877de8: sbfiz           x0, x2, #1, #0x1f
    //     0x877dec: cmp             x2, x0, asr #1
    //     0x877df0: b.eq            #0x877dfc
    //     0x877df4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x877df8: stur            x2, [x0, #7]
    // 0x877dfc: mov             x1, x3
    // 0x877e00: ArrayStore: r1[5] = r0  ; List_4
    //     0x877e00: add             x25, x1, #0x23
    //     0x877e04: str             w0, [x25]
    //     0x877e08: tbz             w0, #0, #0x877e24
    //     0x877e0c: ldurb           w16, [x1, #-1]
    //     0x877e10: ldurb           w17, [x0, #-1]
    //     0x877e14: and             x16, x17, x16, lsr #2
    //     0x877e18: tst             x16, HEAP, lsr #32
    //     0x877e1c: b.eq            #0x877e24
    //     0x877e20: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x877e24: r16 = "selectionAffinity"
    //     0x877e24: ldr             x16, [PP, #0x5fa0]  ; [pp+0x5fa0] "selectionAffinity"
    // 0x877e28: StoreField: r3->field_27 = r16
    //     0x877e28: stur            w16, [x3, #0x27]
    // 0x877e2c: LoadField: r0 = r5->field_27
    //     0x877e2c: ldur            w0, [x5, #0x27]
    // 0x877e30: DecompressPointer r0
    //     0x877e30: add             x0, x0, HEAP, lsl #32
    // 0x877e34: stur            x0, [fp, #-0x10]
    // 0x877e38: r1 = Null
    //     0x877e38: mov             x1, NULL
    // 0x877e3c: r2 = 4
    //     0x877e3c: mov             x2, #4
    // 0x877e40: r0 = AllocateArray()
    //     0x877e40: bl              #0x13df928  ; AllocateArrayStub
    // 0x877e44: r16 = "TextAffinity."
    //     0x877e44: ldr             x16, [PP, #0x6038]  ; [pp+0x6038] "TextAffinity."
    // 0x877e48: StoreField: r0->field_f = r16
    //     0x877e48: stur            w16, [x0, #0xf]
    // 0x877e4c: ldur            x1, [fp, #-0x10]
    // 0x877e50: LoadField: r2 = r1->field_f
    //     0x877e50: ldur            w2, [x1, #0xf]
    // 0x877e54: DecompressPointer r2
    //     0x877e54: add             x2, x2, HEAP, lsl #32
    // 0x877e58: StoreField: r0->field_13 = r2
    //     0x877e58: stur            w2, [x0, #0x13]
    // 0x877e5c: str             x0, [SP]
    // 0x877e60: r0 = _interpolate()
    //     0x877e60: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x877e64: ldur            x1, [fp, #-0x20]
    // 0x877e68: ArrayStore: r1[7] = r0  ; List_4
    //     0x877e68: add             x25, x1, #0x2b
    //     0x877e6c: str             w0, [x25]
    //     0x877e70: tbz             w0, #0, #0x877e8c
    //     0x877e74: ldurb           w16, [x1, #-1]
    //     0x877e78: ldurb           w17, [x0, #-1]
    //     0x877e7c: and             x16, x17, x16, lsr #2
    //     0x877e80: tst             x16, HEAP, lsr #32
    //     0x877e84: b.eq            #0x877e8c
    //     0x877e88: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x877e8c: ldur            x2, [fp, #-0x20]
    // 0x877e90: r16 = "selectionIsDirectional"
    //     0x877e90: ldr             x16, [PP, #0x5fc8]  ; [pp+0x5fc8] "selectionIsDirectional"
    // 0x877e94: StoreField: r2->field_2f = r16
    //     0x877e94: stur            w16, [x2, #0x2f]
    // 0x877e98: ldur            x0, [fp, #-0x18]
    // 0x877e9c: LoadField: r1 = r0->field_2b
    //     0x877e9c: ldur            w1, [x0, #0x2b]
    // 0x877ea0: DecompressPointer r1
    //     0x877ea0: add             x1, x1, HEAP, lsl #32
    // 0x877ea4: StoreField: r2->field_33 = r1
    //     0x877ea4: stur            w1, [x2, #0x33]
    // 0x877ea8: r16 = "composingBase"
    //     0x877ea8: ldr             x16, [PP, #0x5f40]  ; [pp+0x5f40] "composingBase"
    // 0x877eac: StoreField: r2->field_37 = r16
    //     0x877eac: stur            w16, [x2, #0x37]
    // 0x877eb0: ldur            x0, [fp, #-8]
    // 0x877eb4: LoadField: r3 = r0->field_f
    //     0x877eb4: ldur            w3, [x0, #0xf]
    // 0x877eb8: DecompressPointer r3
    //     0x877eb8: add             x3, x3, HEAP, lsl #32
    // 0x877ebc: LoadField: r4 = r3->field_7
    //     0x877ebc: ldur            x4, [x3, #7]
    // 0x877ec0: r0 = BoxInt64Instr(r4)
    //     0x877ec0: sbfiz           x0, x4, #1, #0x1f
    //     0x877ec4: cmp             x4, x0, asr #1
    //     0x877ec8: b.eq            #0x877ed4
    //     0x877ecc: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x877ed0: stur            x4, [x0, #7]
    // 0x877ed4: mov             x1, x2
    // 0x877ed8: ArrayStore: r1[11] = r0  ; List_4
    //     0x877ed8: add             x25, x1, #0x3b
    //     0x877edc: str             w0, [x25]
    //     0x877ee0: tbz             w0, #0, #0x877efc
    //     0x877ee4: ldurb           w16, [x1, #-1]
    //     0x877ee8: ldurb           w17, [x0, #-1]
    //     0x877eec: and             x16, x17, x16, lsr #2
    //     0x877ef0: tst             x16, HEAP, lsr #32
    //     0x877ef4: b.eq            #0x877efc
    //     0x877ef8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x877efc: r16 = "composingExtent"
    //     0x877efc: ldr             x16, [PP, #0x5f58]  ; [pp+0x5f58] "composingExtent"
    // 0x877f00: StoreField: r2->field_3f = r16
    //     0x877f00: stur            w16, [x2, #0x3f]
    // 0x877f04: LoadField: r4 = r3->field_f
    //     0x877f04: ldur            x4, [x3, #0xf]
    // 0x877f08: r0 = BoxInt64Instr(r4)
    //     0x877f08: sbfiz           x0, x4, #1, #0x1f
    //     0x877f0c: cmp             x4, x0, asr #1
    //     0x877f10: b.eq            #0x877f1c
    //     0x877f14: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x877f18: stur            x4, [x0, #7]
    // 0x877f1c: mov             x1, x2
    // 0x877f20: ArrayStore: r1[13] = r0  ; List_4
    //     0x877f20: add             x25, x1, #0x43
    //     0x877f24: str             w0, [x25]
    //     0x877f28: tbz             w0, #0, #0x877f44
    //     0x877f2c: ldurb           w16, [x1, #-1]
    //     0x877f30: ldurb           w17, [x0, #-1]
    //     0x877f34: and             x16, x17, x16, lsr #2
    //     0x877f38: tst             x16, HEAP, lsr #32
    //     0x877f3c: b.eq            #0x877f44
    //     0x877f40: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x877f44: r16 = <String, dynamic>
    //     0x877f44: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x877f48: stp             x2, x16, [SP]
    // 0x877f4c: r0 = Map._fromLiteral()
    //     0x877f4c: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x877f50: LeaveFrame
    //     0x877f50: mov             SP, fp
    //     0x877f54: ldp             fp, lr, [SP], #0x10
    // 0x877f58: ret
    //     0x877f58: ret             
    // 0x877f5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x877f5c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x877f60: b               #0x877d5c
  }
  factory _ TextEditingValue.fromJSON(/* No info */) {
    // ** addr: 0x877fa4, size: 0x434
    // 0x877fa4: EnterFrame
    //     0x877fa4: stp             fp, lr, [SP, #-0x10]!
    //     0x877fa8: mov             fp, SP
    // 0x877fac: AllocStack(0x48)
    //     0x877fac: sub             SP, SP, #0x48
    // 0x877fb0: SetupParameters(dynamic _ /* r2 => r3, fp-0x8 */)
    //     0x877fb0: mov             x3, x2
    //     0x877fb4: stur            x2, [fp, #-8]
    // 0x877fb8: CheckStackOverflow
    //     0x877fb8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x877fbc: cmp             SP, x16
    //     0x877fc0: b.ls            #0x8783d0
    // 0x877fc4: r0 = LoadClassIdInstr(r3)
    //     0x877fc4: ldur            x0, [x3, #-1]
    //     0x877fc8: ubfx            x0, x0, #0xc, #0x14
    // 0x877fcc: mov             x1, x3
    // 0x877fd0: r2 = "text"
    //     0x877fd0: ldr             x2, [PP, #0x57e8]  ; [pp+0x57e8] "text"
    // 0x877fd4: r0 = GDT[cid_x0 + -0xd48]()
    //     0x877fd4: sub             lr, x0, #0xd48
    //     0x877fd8: ldr             lr, [x21, lr, lsl #3]
    //     0x877fdc: blr             lr
    // 0x877fe0: mov             x3, x0
    // 0x877fe4: r2 = Null
    //     0x877fe4: mov             x2, NULL
    // 0x877fe8: r1 = Null
    //     0x877fe8: mov             x1, NULL
    // 0x877fec: stur            x3, [fp, #-0x10]
    // 0x877ff0: r4 = 60
    //     0x877ff0: mov             x4, #0x3c
    // 0x877ff4: branchIfSmi(r0, 0x878000)
    //     0x877ff4: tbz             w0, #0, #0x878000
    // 0x877ff8: r4 = LoadClassIdInstr(r0)
    //     0x877ff8: ldur            x4, [x0, #-1]
    //     0x877ffc: ubfx            x4, x4, #0xc, #0x14
    // 0x878000: sub             x4, x4, #0x5e
    // 0x878004: cmp             x4, #1
    // 0x878008: b.ls            #0x878018
    // 0x87800c: r8 = String
    //     0x87800c: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x878010: r3 = Null
    //     0x878010: ldr             x3, [PP, #0x6040]  ; [pp+0x6040] Null
    // 0x878014: r0 = String()
    //     0x878014: bl              #0x13ee320  ; IsType_String_Stub
    // 0x878018: ldur            x3, [fp, #-8]
    // 0x87801c: r0 = LoadClassIdInstr(r3)
    //     0x87801c: ldur            x0, [x3, #-1]
    //     0x878020: ubfx            x0, x0, #0xc, #0x14
    // 0x878024: mov             x1, x3
    // 0x878028: r2 = "selectionBase"
    //     0x878028: ldr             x2, [PP, #0x5f70]  ; [pp+0x5f70] "selectionBase"
    // 0x87802c: r0 = GDT[cid_x0 + -0xd48]()
    //     0x87802c: sub             lr, x0, #0xd48
    //     0x878030: ldr             lr, [x21, lr, lsl #3]
    //     0x878034: blr             lr
    // 0x878038: mov             x3, x0
    // 0x87803c: r2 = Null
    //     0x87803c: mov             x2, NULL
    // 0x878040: r1 = Null
    //     0x878040: mov             x1, NULL
    // 0x878044: stur            x3, [fp, #-0x18]
    // 0x878048: branchIfSmi(r0, 0x87806c)
    //     0x878048: tbz             w0, #0, #0x87806c
    // 0x87804c: r4 = LoadClassIdInstr(r0)
    //     0x87804c: ldur            x4, [x0, #-1]
    //     0x878050: ubfx            x4, x4, #0xc, #0x14
    // 0x878054: sub             x4, x4, #0x3c
    // 0x878058: cmp             x4, #1
    // 0x87805c: b.ls            #0x87806c
    // 0x878060: r8 = int?
    //     0x878060: ldr             x8, [PP, #0x3d30]  ; [pp+0x3d30] Type: int?
    // 0x878064: r3 = Null
    //     0x878064: ldr             x3, [PP, #0x6050]  ; [pp+0x6050] Null
    // 0x878068: r0 = int?()
    //     0x878068: bl              #0x13ee944  ; IsType_int?_Stub
    // 0x87806c: ldur            x0, [fp, #-0x18]
    // 0x878070: cmp             w0, NULL
    // 0x878074: b.ne            #0x878080
    // 0x878078: r4 = -1
    //     0x878078: mov             x4, #-1
    // 0x87807c: b               #0x878090
    // 0x878080: r1 = LoadInt32Instr(r0)
    //     0x878080: sbfx            x1, x0, #1, #0x1f
    //     0x878084: tbz             w0, #0, #0x87808c
    //     0x878088: ldur            x1, [x0, #7]
    // 0x87808c: mov             x4, x1
    // 0x878090: ldur            x3, [fp, #-8]
    // 0x878094: stur            x4, [fp, #-0x20]
    // 0x878098: r0 = LoadClassIdInstr(r3)
    //     0x878098: ldur            x0, [x3, #-1]
    //     0x87809c: ubfx            x0, x0, #0xc, #0x14
    // 0x8780a0: mov             x1, x3
    // 0x8780a4: r2 = "selectionExtent"
    //     0x8780a4: ldr             x2, [PP, #0x5f88]  ; [pp+0x5f88] "selectionExtent"
    // 0x8780a8: r0 = GDT[cid_x0 + -0xd48]()
    //     0x8780a8: sub             lr, x0, #0xd48
    //     0x8780ac: ldr             lr, [x21, lr, lsl #3]
    //     0x8780b0: blr             lr
    // 0x8780b4: mov             x3, x0
    // 0x8780b8: r2 = Null
    //     0x8780b8: mov             x2, NULL
    // 0x8780bc: r1 = Null
    //     0x8780bc: mov             x1, NULL
    // 0x8780c0: stur            x3, [fp, #-0x18]
    // 0x8780c4: branchIfSmi(r0, 0x8780e8)
    //     0x8780c4: tbz             w0, #0, #0x8780e8
    // 0x8780c8: r4 = LoadClassIdInstr(r0)
    //     0x8780c8: ldur            x4, [x0, #-1]
    //     0x8780cc: ubfx            x4, x4, #0xc, #0x14
    // 0x8780d0: sub             x4, x4, #0x3c
    // 0x8780d4: cmp             x4, #1
    // 0x8780d8: b.ls            #0x8780e8
    // 0x8780dc: r8 = int?
    //     0x8780dc: ldr             x8, [PP, #0x3d30]  ; [pp+0x3d30] Type: int?
    // 0x8780e0: r3 = Null
    //     0x8780e0: ldr             x3, [PP, #0x6060]  ; [pp+0x6060] Null
    // 0x8780e4: r0 = int?()
    //     0x8780e4: bl              #0x13ee944  ; IsType_int?_Stub
    // 0x8780e8: ldur            x0, [fp, #-0x18]
    // 0x8780ec: cmp             w0, NULL
    // 0x8780f0: b.ne            #0x8780fc
    // 0x8780f4: r4 = -1
    //     0x8780f4: mov             x4, #-1
    // 0x8780f8: b               #0x87810c
    // 0x8780fc: r1 = LoadInt32Instr(r0)
    //     0x8780fc: sbfx            x1, x0, #1, #0x1f
    //     0x878100: tbz             w0, #0, #0x878108
    //     0x878104: ldur            x1, [x0, #7]
    // 0x878108: mov             x4, x1
    // 0x87810c: ldur            x3, [fp, #-8]
    // 0x878110: stur            x4, [fp, #-0x28]
    // 0x878114: r0 = LoadClassIdInstr(r3)
    //     0x878114: ldur            x0, [x3, #-1]
    //     0x878118: ubfx            x0, x0, #0xc, #0x14
    // 0x87811c: mov             x1, x3
    // 0x878120: r2 = "selectionAffinity"
    //     0x878120: ldr             x2, [PP, #0x5fa0]  ; [pp+0x5fa0] "selectionAffinity"
    // 0x878124: r0 = GDT[cid_x0 + -0xd48]()
    //     0x878124: sub             lr, x0, #0xd48
    //     0x878128: ldr             lr, [x21, lr, lsl #3]
    //     0x87812c: blr             lr
    // 0x878130: mov             x3, x0
    // 0x878134: r2 = Null
    //     0x878134: mov             x2, NULL
    // 0x878138: r1 = Null
    //     0x878138: mov             x1, NULL
    // 0x87813c: stur            x3, [fp, #-0x18]
    // 0x878140: r4 = 60
    //     0x878140: mov             x4, #0x3c
    // 0x878144: branchIfSmi(r0, 0x878150)
    //     0x878144: tbz             w0, #0, #0x878150
    // 0x878148: r4 = LoadClassIdInstr(r0)
    //     0x878148: ldur            x4, [x0, #-1]
    //     0x87814c: ubfx            x4, x4, #0xc, #0x14
    // 0x878150: sub             x4, x4, #0x5e
    // 0x878154: cmp             x4, #1
    // 0x878158: b.ls            #0x878168
    // 0x87815c: r8 = String?
    //     0x87815c: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x878160: r3 = Null
    //     0x878160: ldr             x3, [PP, #0x6070]  ; [pp+0x6070] Null
    // 0x878164: r0 = String?()
    //     0x878164: bl              #0x7db310  ; IsType_String?_Stub
    // 0x878168: r16 = "TextAffinity.downstream"
    //     0x878168: ldr             x16, [PP, #0x5fb8]  ; [pp+0x5fb8] "TextAffinity.downstream"
    // 0x87816c: ldur            lr, [fp, #-0x18]
    // 0x878170: stp             lr, x16, [SP]
    // 0x878174: r0 = ==()
    //     0x878174: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x878178: tbnz            w0, #4, #0x878184
    // 0x87817c: r0 = Instance_TextAffinity
    //     0x87817c: ldr             x0, [PP, #0x4bb0]  ; [pp+0x4bb0] Obj!TextAffinity@12c7361
    // 0x878180: b               #0x8781a4
    // 0x878184: r16 = "TextAffinity.upstream"
    //     0x878184: ldr             x16, [PP, #0x5fc0]  ; [pp+0x5fc0] "TextAffinity.upstream"
    // 0x878188: ldur            lr, [fp, #-0x18]
    // 0x87818c: stp             lr, x16, [SP]
    // 0x878190: r0 = ==()
    //     0x878190: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x878194: tbnz            w0, #4, #0x8781a0
    // 0x878198: r0 = Instance_TextAffinity
    //     0x878198: ldr             x0, [PP, #0x4bb8]  ; [pp+0x4bb8] Obj!TextAffinity@12c7341
    // 0x87819c: b               #0x8781a4
    // 0x8781a0: r0 = Null
    //     0x8781a0: mov             x0, NULL
    // 0x8781a4: cmp             w0, NULL
    // 0x8781a8: b.ne            #0x8781b4
    // 0x8781ac: r4 = Instance_TextAffinity
    //     0x8781ac: ldr             x4, [PP, #0x4bb0]  ; [pp+0x4bb0] Obj!TextAffinity@12c7361
    // 0x8781b0: b               #0x8781b8
    // 0x8781b4: mov             x4, x0
    // 0x8781b8: ldur            x3, [fp, #-8]
    // 0x8781bc: stur            x4, [fp, #-0x18]
    // 0x8781c0: r0 = LoadClassIdInstr(r3)
    //     0x8781c0: ldur            x0, [x3, #-1]
    //     0x8781c4: ubfx            x0, x0, #0xc, #0x14
    // 0x8781c8: mov             x1, x3
    // 0x8781cc: r2 = "selectionIsDirectional"
    //     0x8781cc: ldr             x2, [PP, #0x5fc8]  ; [pp+0x5fc8] "selectionIsDirectional"
    // 0x8781d0: r0 = GDT[cid_x0 + -0xd48]()
    //     0x8781d0: sub             lr, x0, #0xd48
    //     0x8781d4: ldr             lr, [x21, lr, lsl #3]
    //     0x8781d8: blr             lr
    // 0x8781dc: mov             x3, x0
    // 0x8781e0: r2 = Null
    //     0x8781e0: mov             x2, NULL
    // 0x8781e4: r1 = Null
    //     0x8781e4: mov             x1, NULL
    // 0x8781e8: stur            x3, [fp, #-0x30]
    // 0x8781ec: r4 = 60
    //     0x8781ec: mov             x4, #0x3c
    // 0x8781f0: branchIfSmi(r0, 0x8781fc)
    //     0x8781f0: tbz             w0, #0, #0x8781fc
    // 0x8781f4: r4 = LoadClassIdInstr(r0)
    //     0x8781f4: ldur            x4, [x0, #-1]
    //     0x8781f8: ubfx            x4, x4, #0xc, #0x14
    // 0x8781fc: cmp             x4, #0x3f
    // 0x878200: b.eq            #0x878210
    // 0x878204: r8 = bool?
    //     0x878204: ldr             x8, [PP, #0x5fd0]  ; [pp+0x5fd0] Type: bool?
    // 0x878208: r3 = Null
    //     0x878208: ldr             x3, [PP, #0x6080]  ; [pp+0x6080] Null
    // 0x87820c: r0 = bool?()
    //     0x87820c: bl              #0x7ecd2c  ; IsType_bool?_Stub
    // 0x878210: ldur            x0, [fp, #-0x30]
    // 0x878214: cmp             w0, NULL
    // 0x878218: b.ne            #0x878224
    // 0x87821c: r3 = false
    //     0x87821c: add             x3, NULL, #0x30  ; false
    // 0x878220: b               #0x878228
    // 0x878224: mov             x3, x0
    // 0x878228: ldur            x2, [fp, #-0x20]
    // 0x87822c: ldur            x1, [fp, #-0x28]
    // 0x878230: ldur            x0, [fp, #-0x18]
    // 0x878234: stur            x3, [fp, #-0x30]
    // 0x878238: r0 = TextSelection()
    //     0x878238: bl              #0x861260  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0x87823c: mov             x3, x0
    // 0x878240: ldur            x0, [fp, #-0x20]
    // 0x878244: stur            x3, [fp, #-0x38]
    // 0x878248: ArrayStore: r3[0] = r0  ; List_8
    //     0x878248: stur            x0, [x3, #0x17]
    // 0x87824c: ldur            x1, [fp, #-0x28]
    // 0x878250: StoreField: r3->field_1f = r1
    //     0x878250: stur            x1, [x3, #0x1f]
    // 0x878254: ldur            x2, [fp, #-0x18]
    // 0x878258: StoreField: r3->field_27 = r2
    //     0x878258: stur            w2, [x3, #0x27]
    // 0x87825c: ldur            x2, [fp, #-0x30]
    // 0x878260: StoreField: r3->field_2b = r2
    //     0x878260: stur            w2, [x3, #0x2b]
    // 0x878264: cmp             x0, x1
    // 0x878268: b.ge            #0x878274
    // 0x87826c: mov             x2, x0
    // 0x878270: b               #0x878278
    // 0x878274: mov             x2, x1
    // 0x878278: cmp             x0, x1
    // 0x87827c: b.ge            #0x878284
    // 0x878280: mov             x0, x1
    // 0x878284: ldur            x4, [fp, #-8]
    // 0x878288: StoreField: r3->field_7 = r2
    //     0x878288: stur            x2, [x3, #7]
    // 0x87828c: StoreField: r3->field_f = r0
    //     0x87828c: stur            x0, [x3, #0xf]
    // 0x878290: r0 = LoadClassIdInstr(r4)
    //     0x878290: ldur            x0, [x4, #-1]
    //     0x878294: ubfx            x0, x0, #0xc, #0x14
    // 0x878298: mov             x1, x4
    // 0x87829c: r2 = "composingBase"
    //     0x87829c: ldr             x2, [PP, #0x5f40]  ; [pp+0x5f40] "composingBase"
    // 0x8782a0: r0 = GDT[cid_x0 + -0xd48]()
    //     0x8782a0: sub             lr, x0, #0xd48
    //     0x8782a4: ldr             lr, [x21, lr, lsl #3]
    //     0x8782a8: blr             lr
    // 0x8782ac: mov             x3, x0
    // 0x8782b0: r2 = Null
    //     0x8782b0: mov             x2, NULL
    // 0x8782b4: r1 = Null
    //     0x8782b4: mov             x1, NULL
    // 0x8782b8: stur            x3, [fp, #-0x18]
    // 0x8782bc: branchIfSmi(r0, 0x8782e0)
    //     0x8782bc: tbz             w0, #0, #0x8782e0
    // 0x8782c0: r4 = LoadClassIdInstr(r0)
    //     0x8782c0: ldur            x4, [x0, #-1]
    //     0x8782c4: ubfx            x4, x4, #0xc, #0x14
    // 0x8782c8: sub             x4, x4, #0x3c
    // 0x8782cc: cmp             x4, #1
    // 0x8782d0: b.ls            #0x8782e0
    // 0x8782d4: r8 = int?
    //     0x8782d4: ldr             x8, [PP, #0x3d30]  ; [pp+0x3d30] Type: int?
    // 0x8782d8: r3 = Null
    //     0x8782d8: ldr             x3, [PP, #0x6090]  ; [pp+0x6090] Null
    // 0x8782dc: r0 = int?()
    //     0x8782dc: bl              #0x13ee944  ; IsType_int?_Stub
    // 0x8782e0: ldur            x0, [fp, #-0x18]
    // 0x8782e4: cmp             w0, NULL
    // 0x8782e8: b.ne            #0x8782f4
    // 0x8782ec: r3 = -1
    //     0x8782ec: mov             x3, #-1
    // 0x8782f0: b               #0x878304
    // 0x8782f4: r1 = LoadInt32Instr(r0)
    //     0x8782f4: sbfx            x1, x0, #1, #0x1f
    //     0x8782f8: tbz             w0, #0, #0x878300
    //     0x8782fc: ldur            x1, [x0, #7]
    // 0x878300: mov             x3, x1
    // 0x878304: ldur            x1, [fp, #-8]
    // 0x878308: stur            x3, [fp, #-0x20]
    // 0x87830c: r0 = LoadClassIdInstr(r1)
    //     0x87830c: ldur            x0, [x1, #-1]
    //     0x878310: ubfx            x0, x0, #0xc, #0x14
    // 0x878314: r2 = "composingExtent"
    //     0x878314: ldr             x2, [PP, #0x5f58]  ; [pp+0x5f58] "composingExtent"
    // 0x878318: r0 = GDT[cid_x0 + -0xd48]()
    //     0x878318: sub             lr, x0, #0xd48
    //     0x87831c: ldr             lr, [x21, lr, lsl #3]
    //     0x878320: blr             lr
    // 0x878324: mov             x3, x0
    // 0x878328: r2 = Null
    //     0x878328: mov             x2, NULL
    // 0x87832c: r1 = Null
    //     0x87832c: mov             x1, NULL
    // 0x878330: stur            x3, [fp, #-8]
    // 0x878334: branchIfSmi(r0, 0x878358)
    //     0x878334: tbz             w0, #0, #0x878358
    // 0x878338: r4 = LoadClassIdInstr(r0)
    //     0x878338: ldur            x4, [x0, #-1]
    //     0x87833c: ubfx            x4, x4, #0xc, #0x14
    // 0x878340: sub             x4, x4, #0x3c
    // 0x878344: cmp             x4, #1
    // 0x878348: b.ls            #0x878358
    // 0x87834c: r8 = int?
    //     0x87834c: ldr             x8, [PP, #0x3d30]  ; [pp+0x3d30] Type: int?
    // 0x878350: r3 = Null
    //     0x878350: ldr             x3, [PP, #0x60a0]  ; [pp+0x60a0] Null
    // 0x878354: r0 = int?()
    //     0x878354: bl              #0x13ee944  ; IsType_int?_Stub
    // 0x878358: ldur            x0, [fp, #-8]
    // 0x87835c: cmp             w0, NULL
    // 0x878360: b.ne            #0x87836c
    // 0x878364: r3 = -1
    //     0x878364: mov             x3, #-1
    // 0x878368: b               #0x87837c
    // 0x87836c: r1 = LoadInt32Instr(r0)
    //     0x87836c: sbfx            x1, x0, #1, #0x1f
    //     0x878370: tbz             w0, #0, #0x878378
    //     0x878374: ldur            x1, [x0, #7]
    // 0x878378: mov             x3, x1
    // 0x87837c: ldur            x2, [fp, #-0x10]
    // 0x878380: ldur            x1, [fp, #-0x38]
    // 0x878384: ldur            x0, [fp, #-0x20]
    // 0x878388: stur            x3, [fp, #-0x28]
    // 0x87838c: r0 = TextRange()
    //     0x87838c: bl              #0x83839c  ; AllocateTextRangeStub -> TextRange (size=0x18)
    // 0x878390: mov             x1, x0
    // 0x878394: ldur            x0, [fp, #-0x20]
    // 0x878398: stur            x1, [fp, #-8]
    // 0x87839c: StoreField: r1->field_7 = r0
    //     0x87839c: stur            x0, [x1, #7]
    // 0x8783a0: ldur            x0, [fp, #-0x28]
    // 0x8783a4: StoreField: r1->field_f = r0
    //     0x8783a4: stur            x0, [x1, #0xf]
    // 0x8783a8: r0 = TextEditingValue()
    //     0x8783a8: bl              #0x86e1d4  ; AllocateTextEditingValueStub -> TextEditingValue (size=0x14)
    // 0x8783ac: ldur            x1, [fp, #-0x10]
    // 0x8783b0: StoreField: r0->field_7 = r1
    //     0x8783b0: stur            w1, [x0, #7]
    // 0x8783b4: ldur            x1, [fp, #-0x38]
    // 0x8783b8: StoreField: r0->field_b = r1
    //     0x8783b8: stur            w1, [x0, #0xb]
    // 0x8783bc: ldur            x1, [fp, #-8]
    // 0x8783c0: StoreField: r0->field_f = r1
    //     0x8783c0: stur            w1, [x0, #0xf]
    // 0x8783c4: LeaveFrame
    //     0x8783c4: mov             SP, fp
    //     0x8783c8: ldp             fp, lr, [SP], #0x10
    // 0x8783cc: ret
    //     0x8783cc: ret             
    // 0x8783d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8783d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8783d4: b               #0x877fc4
  }
  _ replaced(/* No info */) {
    // ** addr: 0xb3077c, size: 0x2f8
    // 0xb3077c: EnterFrame
    //     0xb3077c: stp             fp, lr, [SP, #-0x10]!
    //     0xb30780: mov             fp, SP
    // 0xb30784: AllocStack(0x48)
    //     0xb30784: sub             SP, SP, #0x48
    // 0xb30788: SetupParameters(TextEditingValue this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r5, fp-0x18 */)
    //     0xb30788: mov             x5, x3
    //     0xb3078c: stur            x1, [fp, #-8]
    //     0xb30790: stur            x2, [fp, #-0x10]
    //     0xb30794: stur            x3, [fp, #-0x18]
    // 0xb30798: CheckStackOverflow
    //     0xb30798: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb3079c: cmp             SP, x16
    //     0xb307a0: b.ls            #0xb30a6c
    // 0xb307a4: r1 = 2
    //     0xb307a4: mov             x1, #2
    // 0xb307a8: r0 = AllocateContext()
    //     0xb307a8: bl              #0x13de838  ; AllocateContextStub
    // 0xb307ac: mov             x4, x0
    // 0xb307b0: ldur            x0, [fp, #-0x10]
    // 0xb307b4: stur            x4, [fp, #-0x20]
    // 0xb307b8: StoreField: r4->field_f = r0
    //     0xb307b8: stur            w0, [x4, #0xf]
    // 0xb307bc: ldur            x5, [fp, #-0x18]
    // 0xb307c0: StoreField: r4->field_13 = r5
    //     0xb307c0: stur            w5, [x4, #0x13]
    // 0xb307c4: LoadField: r2 = r0->field_7
    //     0xb307c4: ldur            x2, [x0, #7]
    // 0xb307c8: tbnz            x2, #0x3f, #0xb30a5c
    // 0xb307cc: LoadField: r3 = r0->field_f
    //     0xb307cc: ldur            x3, [x0, #0xf]
    // 0xb307d0: tbz             x3, #0x3f, #0xb307dc
    // 0xb307d4: ldur            x0, [fp, #-8]
    // 0xb307d8: b               #0xb30a60
    // 0xb307dc: ldur            x6, [fp, #-8]
    // 0xb307e0: LoadField: r7 = r6->field_7
    //     0xb307e0: ldur            w7, [x6, #7]
    // 0xb307e4: DecompressPointer r7
    //     0xb307e4: add             x7, x7, HEAP, lsl #32
    // 0xb307e8: r0 = BoxInt64Instr(r3)
    //     0xb307e8: sbfiz           x0, x3, #1, #0x1f
    //     0xb307ec: cmp             x3, x0, asr #1
    //     0xb307f0: b.eq            #0xb307fc
    //     0xb307f4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb307f8: stur            x3, [x0, #7]
    // 0xb307fc: mov             x1, x7
    // 0xb30800: mov             x3, x0
    // 0xb30804: r0 = replaceRange()
    //     0xb30804: bl              #0x7ec3e4  ; [dart:core] _StringBase::replaceRange
    // 0xb30808: ldur            x2, [fp, #-0x20]
    // 0xb3080c: stur            x0, [fp, #-0x10]
    // 0xb30810: LoadField: r1 = r2->field_f
    //     0xb30810: ldur            w1, [x2, #0xf]
    // 0xb30814: DecompressPointer r1
    //     0xb30814: add             x1, x1, HEAP, lsl #32
    // 0xb30818: LoadField: r3 = r1->field_f
    //     0xb30818: ldur            x3, [x1, #0xf]
    // 0xb3081c: LoadField: r4 = r1->field_7
    //     0xb3081c: ldur            x4, [x1, #7]
    // 0xb30820: sub             x1, x3, x4
    // 0xb30824: LoadField: r3 = r2->field_13
    //     0xb30824: ldur            w3, [x2, #0x13]
    // 0xb30828: DecompressPointer r3
    //     0xb30828: add             x3, x3, HEAP, lsl #32
    // 0xb3082c: LoadField: r4 = r3->field_7
    //     0xb3082c: ldur            w4, [x3, #7]
    // 0xb30830: r3 = LoadInt32Instr(r4)
    //     0xb30830: sbfx            x3, x4, #1, #0x1f
    // 0xb30834: cmp             x1, x3
    // 0xb30838: b.ne            #0xb3085c
    // 0xb3083c: str             x0, [SP]
    // 0xb30840: ldur            x1, [fp, #-8]
    // 0xb30844: r4 = const [0, 0x2, 0x1, 0x1, text, 0x1, null]
    //     0xb30844: add             x4, PP, #0x1a, lsl #12  ; [pp+0x1a728] List(7) [0, 0x2, 0x1, 0x1, "text", 0x1, Null]
    //     0xb30848: ldr             x4, [x4, #0x728]
    // 0xb3084c: r0 = copyWith()
    //     0xb3084c: bl              #0x86ff64  ; [package:flutter/src/services/text_input.dart] TextEditingValue::copyWith
    // 0xb30850: LeaveFrame
    //     0xb30850: mov             SP, fp
    //     0xb30854: ldp             fp, lr, [SP], #0x10
    // 0xb30858: ret
    //     0xb30858: ret             
    // 0xb3085c: ldur            x3, [fp, #-8]
    // 0xb30860: r1 = Function 'adjustIndex':.
    //     0xb30860: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a730] AnonymousClosure: (0xb30a74), in [package:flutter/src/services/text_input.dart] TextEditingValue::replaced (0xb3077c)
    //     0xb30864: ldr             x1, [x1, #0x730]
    // 0xb30868: r0 = AllocateClosure()
    //     0xb30868: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb3086c: mov             x3, x0
    // 0xb30870: ldur            x2, [fp, #-8]
    // 0xb30874: stur            x3, [fp, #-0x20]
    // 0xb30878: LoadField: r4 = r2->field_b
    //     0xb30878: ldur            w4, [x2, #0xb]
    // 0xb3087c: DecompressPointer r4
    //     0xb3087c: add             x4, x4, HEAP, lsl #32
    // 0xb30880: stur            x4, [fp, #-0x18]
    // 0xb30884: ArrayLoad: r5 = r4[0]  ; List_8
    //     0xb30884: ldur            x5, [x4, #0x17]
    // 0xb30888: r0 = BoxInt64Instr(r5)
    //     0xb30888: sbfiz           x0, x5, #1, #0x1f
    //     0xb3088c: cmp             x5, x0, asr #1
    //     0xb30890: b.eq            #0xb3089c
    //     0xb30894: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb30898: stur            x5, [x0, #7]
    // 0xb3089c: stp             x0, x3, [SP]
    // 0xb308a0: mov             x0, x3
    // 0xb308a4: ClosureCall
    //     0xb308a4: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xb308a8: ldur            x2, [x0, #0x1f]
    //     0xb308ac: blr             x2
    // 0xb308b0: mov             x2, x0
    // 0xb308b4: ldur            x0, [fp, #-0x18]
    // 0xb308b8: stur            x2, [fp, #-0x28]
    // 0xb308bc: LoadField: r3 = r0->field_1f
    //     0xb308bc: ldur            x3, [x0, #0x1f]
    // 0xb308c0: r0 = BoxInt64Instr(r3)
    //     0xb308c0: sbfiz           x0, x3, #1, #0x1f
    //     0xb308c4: cmp             x3, x0, asr #1
    //     0xb308c8: b.eq            #0xb308d4
    //     0xb308cc: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb308d0: stur            x3, [x0, #7]
    // 0xb308d4: ldur            x16, [fp, #-0x20]
    // 0xb308d8: stp             x0, x16, [SP]
    // 0xb308dc: ldur            x0, [fp, #-0x20]
    // 0xb308e0: ClosureCall
    //     0xb308e0: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xb308e4: ldur            x2, [x0, #0x1f]
    //     0xb308e8: blr             x2
    // 0xb308ec: mov             x1, x0
    // 0xb308f0: ldur            x0, [fp, #-0x28]
    // 0xb308f4: stur            x1, [fp, #-0x18]
    // 0xb308f8: r2 = LoadInt32Instr(r0)
    //     0xb308f8: sbfx            x2, x0, #1, #0x1f
    //     0xb308fc: tbz             w0, #0, #0xb30904
    //     0xb30900: ldur            x2, [x0, #7]
    // 0xb30904: stur            x2, [fp, #-0x30]
    // 0xb30908: r0 = TextSelection()
    //     0xb30908: bl              #0x861260  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0xb3090c: mov             x2, x0
    // 0xb30910: ldur            x0, [fp, #-0x30]
    // 0xb30914: stur            x2, [fp, #-0x28]
    // 0xb30918: ArrayStore: r2[0] = r0  ; List_8
    //     0xb30918: stur            x0, [x2, #0x17]
    // 0xb3091c: ldur            x1, [fp, #-0x18]
    // 0xb30920: r3 = LoadInt32Instr(r1)
    //     0xb30920: sbfx            x3, x1, #1, #0x1f
    //     0xb30924: tbz             w1, #0, #0xb3092c
    //     0xb30928: ldur            x3, [x1, #7]
    // 0xb3092c: StoreField: r2->field_1f = r3
    //     0xb3092c: stur            x3, [x2, #0x1f]
    // 0xb30930: r1 = Instance_TextAffinity
    //     0xb30930: ldr             x1, [PP, #0x4bb0]  ; [pp+0x4bb0] Obj!TextAffinity@12c7361
    // 0xb30934: StoreField: r2->field_27 = r1
    //     0xb30934: stur            w1, [x2, #0x27]
    // 0xb30938: r1 = false
    //     0xb30938: add             x1, NULL, #0x30  ; false
    // 0xb3093c: StoreField: r2->field_2b = r1
    //     0xb3093c: stur            w1, [x2, #0x2b]
    // 0xb30940: cmp             x0, x3
    // 0xb30944: b.ge            #0xb30950
    // 0xb30948: mov             x1, x0
    // 0xb3094c: b               #0xb30954
    // 0xb30950: mov             x1, x3
    // 0xb30954: cmp             x0, x3
    // 0xb30958: b.ge            #0xb30964
    // 0xb3095c: mov             x4, x3
    // 0xb30960: b               #0xb30968
    // 0xb30964: mov             x4, x0
    // 0xb30968: ldur            x0, [fp, #-8]
    // 0xb3096c: ldur            x3, [fp, #-0x10]
    // 0xb30970: StoreField: r2->field_7 = r1
    //     0xb30970: stur            x1, [x2, #7]
    // 0xb30974: StoreField: r2->field_f = r4
    //     0xb30974: stur            x4, [x2, #0xf]
    // 0xb30978: LoadField: r4 = r0->field_f
    //     0xb30978: ldur            w4, [x0, #0xf]
    // 0xb3097c: DecompressPointer r4
    //     0xb3097c: add             x4, x4, HEAP, lsl #32
    // 0xb30980: stur            x4, [fp, #-0x18]
    // 0xb30984: LoadField: r5 = r4->field_7
    //     0xb30984: ldur            x5, [x4, #7]
    // 0xb30988: r0 = BoxInt64Instr(r5)
    //     0xb30988: sbfiz           x0, x5, #1, #0x1f
    //     0xb3098c: cmp             x5, x0, asr #1
    //     0xb30990: b.eq            #0xb3099c
    //     0xb30994: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb30998: stur            x5, [x0, #7]
    // 0xb3099c: ldur            x16, [fp, #-0x20]
    // 0xb309a0: stp             x0, x16, [SP]
    // 0xb309a4: ldur            x0, [fp, #-0x20]
    // 0xb309a8: ClosureCall
    //     0xb309a8: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xb309ac: ldur            x2, [x0, #0x1f]
    //     0xb309b0: blr             x2
    // 0xb309b4: mov             x2, x0
    // 0xb309b8: ldur            x0, [fp, #-0x18]
    // 0xb309bc: stur            x2, [fp, #-0x38]
    // 0xb309c0: LoadField: r3 = r0->field_f
    //     0xb309c0: ldur            x3, [x0, #0xf]
    // 0xb309c4: r0 = BoxInt64Instr(r3)
    //     0xb309c4: sbfiz           x0, x3, #1, #0x1f
    //     0xb309c8: cmp             x3, x0, asr #1
    //     0xb309cc: b.eq            #0xb309d8
    //     0xb309d0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb309d4: stur            x3, [x0, #7]
    // 0xb309d8: ldur            x16, [fp, #-0x20]
    // 0xb309dc: stp             x0, x16, [SP]
    // 0xb309e0: ldur            x0, [fp, #-0x20]
    // 0xb309e4: ClosureCall
    //     0xb309e4: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xb309e8: ldur            x2, [x0, #0x1f]
    //     0xb309ec: blr             x2
    // 0xb309f0: mov             x1, x0
    // 0xb309f4: ldur            x0, [fp, #-0x38]
    // 0xb309f8: stur            x1, [fp, #-0x18]
    // 0xb309fc: r2 = LoadInt32Instr(r0)
    //     0xb309fc: sbfx            x2, x0, #1, #0x1f
    //     0xb30a00: tbz             w0, #0, #0xb30a08
    //     0xb30a04: ldur            x2, [x0, #7]
    // 0xb30a08: stur            x2, [fp, #-0x30]
    // 0xb30a0c: r0 = TextRange()
    //     0xb30a0c: bl              #0x83839c  ; AllocateTextRangeStub -> TextRange (size=0x18)
    // 0xb30a10: mov             x1, x0
    // 0xb30a14: ldur            x0, [fp, #-0x30]
    // 0xb30a18: stur            x1, [fp, #-0x20]
    // 0xb30a1c: StoreField: r1->field_7 = r0
    //     0xb30a1c: stur            x0, [x1, #7]
    // 0xb30a20: ldur            x0, [fp, #-0x18]
    // 0xb30a24: r2 = LoadInt32Instr(r0)
    //     0xb30a24: sbfx            x2, x0, #1, #0x1f
    //     0xb30a28: tbz             w0, #0, #0xb30a30
    //     0xb30a2c: ldur            x2, [x0, #7]
    // 0xb30a30: StoreField: r1->field_f = r2
    //     0xb30a30: stur            x2, [x1, #0xf]
    // 0xb30a34: r0 = TextEditingValue()
    //     0xb30a34: bl              #0x86e1d4  ; AllocateTextEditingValueStub -> TextEditingValue (size=0x14)
    // 0xb30a38: ldur            x1, [fp, #-0x10]
    // 0xb30a3c: StoreField: r0->field_7 = r1
    //     0xb30a3c: stur            w1, [x0, #7]
    // 0xb30a40: ldur            x1, [fp, #-0x28]
    // 0xb30a44: StoreField: r0->field_b = r1
    //     0xb30a44: stur            w1, [x0, #0xb]
    // 0xb30a48: ldur            x1, [fp, #-0x20]
    // 0xb30a4c: StoreField: r0->field_f = r1
    //     0xb30a4c: stur            w1, [x0, #0xf]
    // 0xb30a50: LeaveFrame
    //     0xb30a50: mov             SP, fp
    //     0xb30a54: ldp             fp, lr, [SP], #0x10
    // 0xb30a58: ret
    //     0xb30a58: ret             
    // 0xb30a5c: ldur            x0, [fp, #-8]
    // 0xb30a60: LeaveFrame
    //     0xb30a60: mov             SP, fp
    //     0xb30a64: ldp             fp, lr, [SP], #0x10
    // 0xb30a68: ret
    //     0xb30a68: ret             
    // 0xb30a6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb30a6c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb30a70: b               #0xb307a4
  }
  [closure] int adjustIndex(dynamic, int) {
    // ** addr: 0xb30a74, size: 0x110
    // 0xb30a74: EnterFrame
    //     0xb30a74: stp             fp, lr, [SP, #-0x10]!
    //     0xb30a78: mov             fp, SP
    // 0xb30a7c: AllocStack(0x18)
    //     0xb30a7c: sub             SP, SP, #0x18
    // 0xb30a80: SetupParameters([dynamic _ /* r0 */])
    //     0xb30a80: ldr             x0, [fp, #0x18]
    //     0xb30a84: ldur            w4, [x0, #0x17]
    //     0xb30a88: add             x4, x4, HEAP, lsl #32
    //     0xb30a8c: stur            x4, [fp, #-0x18]
    // 0xb30a90: CheckStackOverflow
    //     0xb30a90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb30a94: cmp             SP, x16
    //     0xb30a98: b.ls            #0xb30b7c
    // 0xb30a9c: LoadField: r0 = r4->field_f
    //     0xb30a9c: ldur            w0, [x4, #0xf]
    // 0xb30aa0: DecompressPointer r0
    //     0xb30aa0: add             x0, x0, HEAP, lsl #32
    // 0xb30aa4: LoadField: r2 = r0->field_7
    //     0xb30aa4: ldur            x2, [x0, #7]
    // 0xb30aa8: ldr             x3, [fp, #0x10]
    // 0xb30aac: r5 = LoadInt32Instr(r3)
    //     0xb30aac: sbfx            x5, x3, #1, #0x1f
    //     0xb30ab0: tbz             w3, #0, #0xb30ab8
    //     0xb30ab4: ldur            x5, [x3, #7]
    // 0xb30ab8: stur            x5, [fp, #-0x10]
    // 0xb30abc: cmp             x5, x2
    // 0xb30ac0: b.gt            #0xb30ad8
    // 0xb30ac4: LoadField: r1 = r0->field_f
    //     0xb30ac4: ldur            x1, [x0, #0xf]
    // 0xb30ac8: cmp             x5, x1
    // 0xb30acc: b.ge            #0xb30ad8
    // 0xb30ad0: r6 = 0
    //     0xb30ad0: mov             x6, #0
    // 0xb30ad4: b               #0xb30aec
    // 0xb30ad8: LoadField: r1 = r4->field_13
    //     0xb30ad8: ldur            w1, [x4, #0x13]
    // 0xb30adc: DecompressPointer r1
    //     0xb30adc: add             x1, x1, HEAP, lsl #32
    // 0xb30ae0: LoadField: r6 = r1->field_7
    //     0xb30ae0: ldur            w6, [x1, #7]
    // 0xb30ae4: r1 = LoadInt32Instr(r6)
    //     0xb30ae4: sbfx            x1, x6, #1, #0x1f
    // 0xb30ae8: mov             x6, x1
    // 0xb30aec: stur            x6, [fp, #-8]
    // 0xb30af0: LoadField: r7 = r0->field_f
    //     0xb30af0: ldur            x7, [x0, #0xf]
    // 0xb30af4: r0 = BoxInt64Instr(r2)
    //     0xb30af4: sbfiz           x0, x2, #1, #0x1f
    //     0xb30af8: cmp             x2, x0, asr #1
    //     0xb30afc: b.eq            #0xb30b08
    //     0xb30b00: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb30b04: stur            x2, [x0, #7]
    // 0xb30b08: mov             x2, x0
    // 0xb30b0c: r0 = BoxInt64Instr(r7)
    //     0xb30b0c: sbfiz           x0, x7, #1, #0x1f
    //     0xb30b10: cmp             x7, x0, asr #1
    //     0xb30b14: b.eq            #0xb30b20
    //     0xb30b18: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb30b1c: stur            x7, [x0, #7]
    // 0xb30b20: mov             x1, x3
    // 0xb30b24: mov             x3, x0
    // 0xb30b28: r0 = clamp()
    //     0xb30b28: bl              #0x13db4a0  ; [dart:core] _IntegerImplementation::clamp
    // 0xb30b2c: ldur            x2, [fp, #-0x18]
    // 0xb30b30: LoadField: r3 = r2->field_f
    //     0xb30b30: ldur            w3, [x2, #0xf]
    // 0xb30b34: DecompressPointer r3
    //     0xb30b34: add             x3, x3, HEAP, lsl #32
    // 0xb30b38: LoadField: r2 = r3->field_7
    //     0xb30b38: ldur            x2, [x3, #7]
    // 0xb30b3c: r3 = LoadInt32Instr(r0)
    //     0xb30b3c: sbfx            x3, x0, #1, #0x1f
    //     0xb30b40: tbz             w0, #0, #0xb30b48
    //     0xb30b44: ldur            x3, [x0, #7]
    // 0xb30b48: sub             x4, x3, x2
    // 0xb30b4c: ldur            x3, [fp, #-8]
    // 0xb30b50: ldur            x2, [fp, #-0x10]
    // 0xb30b54: add             x5, x2, x3
    // 0xb30b58: sub             x2, x5, x4
    // 0xb30b5c: r0 = BoxInt64Instr(r2)
    //     0xb30b5c: sbfiz           x0, x2, #1, #0x1f
    //     0xb30b60: cmp             x2, x0, asr #1
    //     0xb30b64: b.eq            #0xb30b70
    //     0xb30b68: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb30b6c: stur            x2, [x0, #7]
    // 0xb30b70: LeaveFrame
    //     0xb30b70: mov             SP, fp
    //     0xb30b74: ldp             fp, lr, [SP], #0x10
    // 0xb30b78: ret
    //     0xb30b78: ret             
    // 0xb30b7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb30b7c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb30b80: b               #0xb30a9c
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x114d04c, size: 0xbc
    // 0x114d04c: EnterFrame
    //     0x114d04c: stp             fp, lr, [SP, #-0x10]!
    //     0x114d050: mov             fp, SP
    // 0x114d054: AllocStack(0x18)
    //     0x114d054: sub             SP, SP, #0x18
    // 0x114d058: CheckStackOverflow
    //     0x114d058: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x114d05c: cmp             SP, x16
    //     0x114d060: b.ls            #0x114d100
    // 0x114d064: ldr             x1, [fp, #0x10]
    // 0x114d068: LoadField: r0 = r1->field_7
    //     0x114d068: ldur            w0, [x1, #7]
    // 0x114d06c: DecompressPointer r0
    //     0x114d06c: add             x0, x0, HEAP, lsl #32
    // 0x114d070: r2 = LoadClassIdInstr(r0)
    //     0x114d070: ldur            x2, [x0, #-1]
    //     0x114d074: ubfx            x2, x2, #0xc, #0x14
    // 0x114d078: str             x0, [SP]
    // 0x114d07c: mov             x0, x2
    // 0x114d080: r0 = GDT[cid_x0 + 0x70de]()
    //     0x114d080: mov             x17, #0x70de
    //     0x114d084: add             lr, x0, x17
    //     0x114d088: ldr             lr, [x21, lr, lsl #3]
    //     0x114d08c: blr             lr
    // 0x114d090: mov             x1, x0
    // 0x114d094: ldr             x0, [fp, #0x10]
    // 0x114d098: stur            x1, [fp, #-8]
    // 0x114d09c: LoadField: r2 = r0->field_b
    //     0x114d09c: ldur            w2, [x0, #0xb]
    // 0x114d0a0: DecompressPointer r2
    //     0x114d0a0: add             x2, x2, HEAP, lsl #32
    // 0x114d0a4: str             x2, [SP]
    // 0x114d0a8: r0 = hashCode()
    //     0x114d0a8: bl              #0x1148844  ; [package:flutter/src/services/text_editing.dart] TextSelection::hashCode
    // 0x114d0ac: mov             x1, x0
    // 0x114d0b0: ldr             x0, [fp, #0x10]
    // 0x114d0b4: stur            x1, [fp, #-0x10]
    // 0x114d0b8: LoadField: r2 = r0->field_f
    //     0x114d0b8: ldur            w2, [x0, #0xf]
    // 0x114d0bc: DecompressPointer r2
    //     0x114d0bc: add             x2, x2, HEAP, lsl #32
    // 0x114d0c0: str             x2, [SP]
    // 0x114d0c4: r0 = hashCode()
    //     0x114d0c4: bl              #0x1148a34  ; [dart:ui] TextRange::hashCode
    // 0x114d0c8: str             x0, [SP]
    // 0x114d0cc: ldur            x1, [fp, #-8]
    // 0x114d0d0: ldur            x2, [fp, #-0x10]
    // 0x114d0d4: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x114d0d4: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x114d0d8: r0 = hash()
    //     0x114d0d8: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x114d0dc: mov             x2, x0
    // 0x114d0e0: r0 = BoxInt64Instr(r2)
    //     0x114d0e0: sbfiz           x0, x2, #1, #0x1f
    //     0x114d0e4: cmp             x2, x0, asr #1
    //     0x114d0e8: b.eq            #0x114d0f4
    //     0x114d0ec: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x114d0f0: stur            x2, [x0, #7]
    // 0x114d0f4: LeaveFrame
    //     0x114d0f4: mov             SP, fp
    //     0x114d0f8: ldp             fp, lr, [SP], #0x10
    // 0x114d0fc: ret
    //     0x114d0fc: ret             
    // 0x114d100: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x114d100: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x114d104: b               #0x114d064
  }
  get _ isComposingRangeValid(/* No info */) {
    // ** addr: 0x1233a00, size: 0x50
    // 0x1233a00: LoadField: r2 = r1->field_f
    //     0x1233a00: ldur            w2, [x1, #0xf]
    // 0x1233a04: DecompressPointer r2
    //     0x1233a04: add             x2, x2, HEAP, lsl #32
    // 0x1233a08: LoadField: r3 = r2->field_7
    //     0x1233a08: ldur            x3, [x2, #7]
    // 0x1233a0c: tbnz            x3, #0x3f, #0x1233a48
    // 0x1233a10: LoadField: r4 = r2->field_f
    //     0x1233a10: ldur            x4, [x2, #0xf]
    // 0x1233a14: tbnz            x4, #0x3f, #0x1233a48
    // 0x1233a18: cmp             x4, x3
    // 0x1233a1c: b.lt            #0x1233a48
    // 0x1233a20: LoadField: r2 = r1->field_7
    //     0x1233a20: ldur            w2, [x1, #7]
    // 0x1233a24: DecompressPointer r2
    //     0x1233a24: add             x2, x2, HEAP, lsl #32
    // 0x1233a28: LoadField: r1 = r2->field_7
    //     0x1233a28: ldur            w1, [x2, #7]
    // 0x1233a2c: r2 = LoadInt32Instr(r1)
    //     0x1233a2c: sbfx            x2, x1, #1, #0x1f
    // 0x1233a30: cmp             x4, x2
    // 0x1233a34: r16 = true
    //     0x1233a34: add             x16, NULL, #0x20  ; true
    // 0x1233a38: r17 = false
    //     0x1233a38: add             x17, NULL, #0x30  ; false
    // 0x1233a3c: csel            x1, x16, x17, le
    // 0x1233a40: mov             x0, x1
    // 0x1233a44: b               #0x1233a4c
    // 0x1233a48: r0 = false
    //     0x1233a48: add             x0, NULL, #0x30  ; false
    // 0x1233a4c: ret
    //     0x1233a4c: ret             
  }
  _ ==(/* No info */) {
    // ** addr: 0x129b280, size: 0x138
    // 0x129b280: EnterFrame
    //     0x129b280: stp             fp, lr, [SP, #-0x10]!
    //     0x129b284: mov             fp, SP
    // 0x129b288: AllocStack(0x10)
    //     0x129b288: sub             SP, SP, #0x10
    // 0x129b28c: CheckStackOverflow
    //     0x129b28c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x129b290: cmp             SP, x16
    //     0x129b294: b.ls            #0x129b3b0
    // 0x129b298: ldr             x1, [fp, #0x10]
    // 0x129b29c: cmp             w1, NULL
    // 0x129b2a0: b.ne            #0x129b2b4
    // 0x129b2a4: r0 = false
    //     0x129b2a4: add             x0, NULL, #0x30  ; false
    // 0x129b2a8: LeaveFrame
    //     0x129b2a8: mov             SP, fp
    //     0x129b2ac: ldp             fp, lr, [SP], #0x10
    // 0x129b2b0: ret
    //     0x129b2b0: ret             
    // 0x129b2b4: ldr             x2, [fp, #0x18]
    // 0x129b2b8: cmp             w2, w1
    // 0x129b2bc: b.ne            #0x129b2d0
    // 0x129b2c0: r0 = true
    //     0x129b2c0: add             x0, NULL, #0x20  ; true
    // 0x129b2c4: LeaveFrame
    //     0x129b2c4: mov             SP, fp
    //     0x129b2c8: ldp             fp, lr, [SP], #0x10
    // 0x129b2cc: ret
    //     0x129b2cc: ret             
    // 0x129b2d0: r0 = 60
    //     0x129b2d0: mov             x0, #0x3c
    // 0x129b2d4: branchIfSmi(r1, 0x129b2e0)
    //     0x129b2d4: tbz             w1, #0, #0x129b2e0
    // 0x129b2d8: r0 = LoadClassIdInstr(r1)
    //     0x129b2d8: ldur            x0, [x1, #-1]
    //     0x129b2dc: ubfx            x0, x0, #0xc, #0x14
    // 0x129b2e0: cmp             x0, #0xaa9
    // 0x129b2e4: b.ne            #0x129b3a0
    // 0x129b2e8: LoadField: r0 = r1->field_7
    //     0x129b2e8: ldur            w0, [x1, #7]
    // 0x129b2ec: DecompressPointer r0
    //     0x129b2ec: add             x0, x0, HEAP, lsl #32
    // 0x129b2f0: LoadField: r3 = r2->field_7
    //     0x129b2f0: ldur            w3, [x2, #7]
    // 0x129b2f4: DecompressPointer r3
    //     0x129b2f4: add             x3, x3, HEAP, lsl #32
    // 0x129b2f8: r4 = LoadClassIdInstr(r0)
    //     0x129b2f8: ldur            x4, [x0, #-1]
    //     0x129b2fc: ubfx            x4, x4, #0xc, #0x14
    // 0x129b300: stp             x3, x0, [SP]
    // 0x129b304: mov             x0, x4
    // 0x129b308: mov             lr, x0
    // 0x129b30c: ldr             lr, [x21, lr, lsl #3]
    // 0x129b310: blr             lr
    // 0x129b314: tbnz            w0, #4, #0x129b3a0
    // 0x129b318: ldr             x1, [fp, #0x18]
    // 0x129b31c: ldr             x0, [fp, #0x10]
    // 0x129b320: LoadField: r2 = r0->field_b
    //     0x129b320: ldur            w2, [x0, #0xb]
    // 0x129b324: DecompressPointer r2
    //     0x129b324: add             x2, x2, HEAP, lsl #32
    // 0x129b328: LoadField: r3 = r1->field_b
    //     0x129b328: ldur            w3, [x1, #0xb]
    // 0x129b32c: DecompressPointer r3
    //     0x129b32c: add             x3, x3, HEAP, lsl #32
    // 0x129b330: stp             x3, x2, [SP]
    // 0x129b334: r0 = ==()
    //     0x129b334: bl              #0x128f7e8  ; [package:flutter/src/services/text_editing.dart] TextSelection::==
    // 0x129b338: tbnz            w0, #4, #0x129b3a0
    // 0x129b33c: ldr             x2, [fp, #0x18]
    // 0x129b340: ldr             x1, [fp, #0x10]
    // 0x129b344: LoadField: r3 = r1->field_f
    //     0x129b344: ldur            w3, [x1, #0xf]
    // 0x129b348: DecompressPointer r3
    //     0x129b348: add             x3, x3, HEAP, lsl #32
    // 0x129b34c: LoadField: r1 = r2->field_f
    //     0x129b34c: ldur            w1, [x2, #0xf]
    // 0x129b350: DecompressPointer r1
    //     0x129b350: add             x1, x1, HEAP, lsl #32
    // 0x129b354: cmp             w3, w1
    // 0x129b358: b.ne            #0x129b364
    // 0x129b35c: r1 = true
    //     0x129b35c: add             x1, NULL, #0x20  ; true
    // 0x129b360: b               #0x129b398
    // 0x129b364: LoadField: r2 = r1->field_7
    //     0x129b364: ldur            x2, [x1, #7]
    // 0x129b368: LoadField: r4 = r3->field_7
    //     0x129b368: ldur            x4, [x3, #7]
    // 0x129b36c: cmp             x2, x4
    // 0x129b370: b.ne            #0x129b394
    // 0x129b374: LoadField: r2 = r1->field_f
    //     0x129b374: ldur            x2, [x1, #0xf]
    // 0x129b378: LoadField: r1 = r3->field_f
    //     0x129b378: ldur            x1, [x3, #0xf]
    // 0x129b37c: cmp             x2, x1
    // 0x129b380: r16 = true
    //     0x129b380: add             x16, NULL, #0x20  ; true
    // 0x129b384: r17 = false
    //     0x129b384: add             x17, NULL, #0x30  ; false
    // 0x129b388: csel            x3, x16, x17, eq
    // 0x129b38c: mov             x1, x3
    // 0x129b390: b               #0x129b398
    // 0x129b394: r1 = false
    //     0x129b394: add             x1, NULL, #0x30  ; false
    // 0x129b398: mov             x0, x1
    // 0x129b39c: b               #0x129b3a4
    // 0x129b3a0: r0 = false
    //     0x129b3a0: add             x0, NULL, #0x30  ; false
    // 0x129b3a4: LeaveFrame
    //     0x129b3a4: mov             SP, fp
    //     0x129b3a8: ldp             fp, lr, [SP], #0x10
    // 0x129b3ac: ret
    //     0x129b3ac: ret             
    // 0x129b3b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x129b3b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x129b3b4: b               #0x129b298
  }
}

// class id: 2730, size: 0x14, field offset: 0x8
class RawFloatingCursorPoint extends Object {
}

// class id: 2731, size: 0x54, field offset: 0x8
//   const constructor, 
class TextInputConfiguration extends Object {

  Map<String, dynamic> toJson(TextInputConfiguration) {
    // ** addr: 0x878ab8, size: 0x424
    // 0x878ab8: EnterFrame
    //     0x878ab8: stp             fp, lr, [SP, #-0x10]!
    //     0x878abc: mov             fp, SP
    // 0x878ac0: AllocStack(0x30)
    //     0x878ac0: sub             SP, SP, #0x30
    // 0x878ac4: SetupParameters(TextInputConfiguration this /* r1 => r0, fp-0x8 */)
    //     0x878ac4: mov             x0, x1
    //     0x878ac8: stur            x1, [fp, #-8]
    // 0x878acc: CheckStackOverflow
    //     0x878acc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x878ad0: cmp             SP, x16
    //     0x878ad4: b.ls            #0x878ed4
    // 0x878ad8: LoadField: r1 = r0->field_1b
    //     0x878ad8: ldur            w1, [x0, #0x1b]
    // 0x878adc: DecompressPointer r1
    //     0x878adc: add             x1, x1, HEAP, lsl #32
    // 0x878ae0: r0 = toJson()
    //     0x878ae0: bl              #0x878f24  ; [package:flutter/src/services/autofill.dart] AutofillConfiguration::toJson
    // 0x878ae4: stur            x0, [fp, #-0x10]
    // 0x878ae8: r16 = <String, dynamic>
    //     0x878ae8: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x878aec: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x878af0: stp             lr, x16, [SP]
    // 0x878af4: r0 = Map._fromLiteral()
    //     0x878af4: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x878af8: mov             x5, x0
    // 0x878afc: ldur            x4, [fp, #-8]
    // 0x878b00: stur            x5, [fp, #-0x18]
    // 0x878b04: LoadField: r3 = r4->field_7
    //     0x878b04: ldur            w3, [x4, #7]
    // 0x878b08: DecompressPointer r3
    //     0x878b08: add             x3, x3, HEAP, lsl #32
    // 0x878b0c: r0 = LoadClassIdInstr(r5)
    //     0x878b0c: ldur            x0, [x5, #-1]
    //     0x878b10: ubfx            x0, x0, #0xc, #0x14
    // 0x878b14: mov             x1, x5
    // 0x878b18: r2 = "viewId"
    //     0x878b18: ldr             x2, [PP, #0x6148]  ; [pp+0x6148] "viewId"
    // 0x878b1c: r0 = GDT[cid_x0 + -0xd50]()
    //     0x878b1c: sub             lr, x0, #0xd50
    //     0x878b20: ldr             lr, [x21, lr, lsl #3]
    //     0x878b24: blr             lr
    // 0x878b28: ldur            x0, [fp, #-8]
    // 0x878b2c: LoadField: r1 = r0->field_b
    //     0x878b2c: ldur            w1, [x0, #0xb]
    // 0x878b30: DecompressPointer r1
    //     0x878b30: add             x1, x1, HEAP, lsl #32
    // 0x878b34: r0 = toJson()
    //     0x878b34: bl              #0x878970  ; [package:flutter/src/services/text_input.dart] TextInputType::toJson
    // 0x878b38: ldur            x4, [fp, #-0x18]
    // 0x878b3c: r1 = LoadClassIdInstr(r4)
    //     0x878b3c: ldur            x1, [x4, #-1]
    //     0x878b40: ubfx            x1, x1, #0xc, #0x14
    // 0x878b44: mov             x3, x0
    // 0x878b48: mov             x0, x1
    // 0x878b4c: mov             x1, x4
    // 0x878b50: r2 = "inputType"
    //     0x878b50: ldr             x2, [PP, #0x60f8]  ; [pp+0x60f8] "inputType"
    // 0x878b54: r0 = GDT[cid_x0 + -0xd50]()
    //     0x878b54: sub             lr, x0, #0xd50
    //     0x878b58: ldr             lr, [x21, lr, lsl #3]
    //     0x878b5c: blr             lr
    // 0x878b60: ldur            x4, [fp, #-8]
    // 0x878b64: LoadField: r3 = r4->field_f
    //     0x878b64: ldur            w3, [x4, #0xf]
    // 0x878b68: DecompressPointer r3
    //     0x878b68: add             x3, x3, HEAP, lsl #32
    // 0x878b6c: ldur            x5, [fp, #-0x18]
    // 0x878b70: r0 = LoadClassIdInstr(r5)
    //     0x878b70: ldur            x0, [x5, #-1]
    //     0x878b74: ubfx            x0, x0, #0xc, #0x14
    // 0x878b78: mov             x1, x5
    // 0x878b7c: r2 = "readOnly"
    //     0x878b7c: ldr             x2, [PP, #0x6150]  ; [pp+0x6150] "readOnly"
    // 0x878b80: r0 = GDT[cid_x0 + -0xd50]()
    //     0x878b80: sub             lr, x0, #0xd50
    //     0x878b84: ldr             lr, [x21, lr, lsl #3]
    //     0x878b88: blr             lr
    // 0x878b8c: ldur            x4, [fp, #-8]
    // 0x878b90: LoadField: r3 = r4->field_13
    //     0x878b90: ldur            w3, [x4, #0x13]
    // 0x878b94: DecompressPointer r3
    //     0x878b94: add             x3, x3, HEAP, lsl #32
    // 0x878b98: ldur            x5, [fp, #-0x18]
    // 0x878b9c: r0 = LoadClassIdInstr(r5)
    //     0x878b9c: ldur            x0, [x5, #-1]
    //     0x878ba0: ubfx            x0, x0, #0xc, #0x14
    // 0x878ba4: mov             x1, x5
    // 0x878ba8: r2 = "obscureText"
    //     0x878ba8: ldr             x2, [PP, #0x6158]  ; [pp+0x6158] "obscureText"
    // 0x878bac: r0 = GDT[cid_x0 + -0xd50]()
    //     0x878bac: sub             lr, x0, #0xd50
    //     0x878bb0: ldr             lr, [x21, lr, lsl #3]
    //     0x878bb4: blr             lr
    // 0x878bb8: ldur            x4, [fp, #-0x18]
    // 0x878bbc: r0 = LoadClassIdInstr(r4)
    //     0x878bbc: ldur            x0, [x4, #-1]
    //     0x878bc0: ubfx            x0, x0, #0xc, #0x14
    // 0x878bc4: mov             x1, x4
    // 0x878bc8: r2 = "autocorrect"
    //     0x878bc8: ldr             x2, [PP, #0x6160]  ; [pp+0x6160] "autocorrect"
    // 0x878bcc: r3 = true
    //     0x878bcc: add             x3, NULL, #0x20  ; true
    // 0x878bd0: r0 = GDT[cid_x0 + -0xd50]()
    //     0x878bd0: sub             lr, x0, #0xd50
    //     0x878bd4: ldr             lr, [x21, lr, lsl #3]
    //     0x878bd8: blr             lr
    // 0x878bdc: ldur            x2, [fp, #-8]
    // 0x878be0: LoadField: r0 = r2->field_1f
    //     0x878be0: ldur            w0, [x2, #0x1f]
    // 0x878be4: DecompressPointer r0
    //     0x878be4: add             x0, x0, HEAP, lsl #32
    // 0x878be8: LoadField: r3 = r0->field_7
    //     0x878be8: ldur            x3, [x0, #7]
    // 0x878bec: r0 = BoxInt64Instr(r3)
    //     0x878bec: sbfiz           x0, x3, #1, #0x1f
    //     0x878bf0: cmp             x3, x0, asr #1
    //     0x878bf4: b.eq            #0x878c00
    //     0x878bf8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x878bfc: stur            x3, [x0, #7]
    // 0x878c00: str             x0, [SP]
    // 0x878c04: r0 = toString()
    //     0x878c04: bl              #0x112aa28  ; [dart:core] _Smi::toString
    // 0x878c08: ldur            x4, [fp, #-0x18]
    // 0x878c0c: r1 = LoadClassIdInstr(r4)
    //     0x878c0c: ldur            x1, [x4, #-1]
    //     0x878c10: ubfx            x1, x1, #0xc, #0x14
    // 0x878c14: mov             x3, x0
    // 0x878c18: mov             x0, x1
    // 0x878c1c: mov             x1, x4
    // 0x878c20: r2 = "smartDashesType"
    //     0x878c20: ldr             x2, [PP, #0x6168]  ; [pp+0x6168] "smartDashesType"
    // 0x878c24: r0 = GDT[cid_x0 + -0xd50]()
    //     0x878c24: sub             lr, x0, #0xd50
    //     0x878c28: ldr             lr, [x21, lr, lsl #3]
    //     0x878c2c: blr             lr
    // 0x878c30: ldur            x2, [fp, #-8]
    // 0x878c34: LoadField: r0 = r2->field_23
    //     0x878c34: ldur            w0, [x2, #0x23]
    // 0x878c38: DecompressPointer r0
    //     0x878c38: add             x0, x0, HEAP, lsl #32
    // 0x878c3c: LoadField: r3 = r0->field_7
    //     0x878c3c: ldur            x3, [x0, #7]
    // 0x878c40: r0 = BoxInt64Instr(r3)
    //     0x878c40: sbfiz           x0, x3, #1, #0x1f
    //     0x878c44: cmp             x3, x0, asr #1
    //     0x878c48: b.eq            #0x878c54
    //     0x878c4c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x878c50: stur            x3, [x0, #7]
    // 0x878c54: str             x0, [SP]
    // 0x878c58: r0 = toString()
    //     0x878c58: bl              #0x112aa28  ; [dart:core] _Smi::toString
    // 0x878c5c: ldur            x4, [fp, #-0x18]
    // 0x878c60: r1 = LoadClassIdInstr(r4)
    //     0x878c60: ldur            x1, [x4, #-1]
    //     0x878c64: ubfx            x1, x1, #0xc, #0x14
    // 0x878c68: mov             x3, x0
    // 0x878c6c: mov             x0, x1
    // 0x878c70: mov             x1, x4
    // 0x878c74: r2 = "smartQuotesType"
    //     0x878c74: ldr             x2, [PP, #0x6170]  ; [pp+0x6170] "smartQuotesType"
    // 0x878c78: r0 = GDT[cid_x0 + -0xd50]()
    //     0x878c78: sub             lr, x0, #0xd50
    //     0x878c7c: ldr             lr, [x21, lr, lsl #3]
    //     0x878c80: blr             lr
    // 0x878c84: ldur            x4, [fp, #-0x18]
    // 0x878c88: r0 = LoadClassIdInstr(r4)
    //     0x878c88: ldur            x0, [x4, #-1]
    //     0x878c8c: ubfx            x0, x0, #0xc, #0x14
    // 0x878c90: mov             x1, x4
    // 0x878c94: r2 = "enableSuggestions"
    //     0x878c94: ldr             x2, [PP, #0x6178]  ; [pp+0x6178] "enableSuggestions"
    // 0x878c98: r3 = true
    //     0x878c98: add             x3, NULL, #0x20  ; true
    // 0x878c9c: r0 = GDT[cid_x0 + -0xd50]()
    //     0x878c9c: sub             lr, x0, #0xd50
    //     0x878ca0: ldr             lr, [x21, lr, lsl #3]
    //     0x878ca4: blr             lr
    // 0x878ca8: ldur            x4, [fp, #-8]
    // 0x878cac: LoadField: r3 = r4->field_2b
    //     0x878cac: ldur            w3, [x4, #0x2b]
    // 0x878cb0: DecompressPointer r3
    //     0x878cb0: add             x3, x3, HEAP, lsl #32
    // 0x878cb4: ldur            x5, [fp, #-0x18]
    // 0x878cb8: r0 = LoadClassIdInstr(r5)
    //     0x878cb8: ldur            x0, [x5, #-1]
    //     0x878cbc: ubfx            x0, x0, #0xc, #0x14
    // 0x878cc0: mov             x1, x5
    // 0x878cc4: r2 = "enableInteractiveSelection"
    //     0x878cc4: ldr             x2, [PP, #0x6180]  ; [pp+0x6180] "enableInteractiveSelection"
    // 0x878cc8: r0 = GDT[cid_x0 + -0xd50]()
    //     0x878cc8: sub             lr, x0, #0xd50
    //     0x878ccc: ldr             lr, [x21, lr, lsl #3]
    //     0x878cd0: blr             lr
    // 0x878cd4: ldur            x4, [fp, #-0x18]
    // 0x878cd8: r0 = LoadClassIdInstr(r4)
    //     0x878cd8: ldur            x0, [x4, #-1]
    //     0x878cdc: ubfx            x0, x0, #0xc, #0x14
    // 0x878ce0: mov             x1, x4
    // 0x878ce4: r2 = "actionLabel"
    //     0x878ce4: ldr             x2, [PP, #0x6188]  ; [pp+0x6188] "actionLabel"
    // 0x878ce8: r3 = Null
    //     0x878ce8: mov             x3, NULL
    // 0x878cec: r0 = GDT[cid_x0 + -0xd50]()
    //     0x878cec: sub             lr, x0, #0xd50
    //     0x878cf0: ldr             lr, [x21, lr, lsl #3]
    //     0x878cf4: blr             lr
    // 0x878cf8: ldur            x0, [fp, #-8]
    // 0x878cfc: LoadField: r3 = r0->field_33
    //     0x878cfc: ldur            w3, [x0, #0x33]
    // 0x878d00: DecompressPointer r3
    //     0x878d00: add             x3, x3, HEAP, lsl #32
    // 0x878d04: stur            x3, [fp, #-0x20]
    // 0x878d08: r1 = Null
    //     0x878d08: mov             x1, NULL
    // 0x878d0c: r2 = 4
    //     0x878d0c: mov             x2, #4
    // 0x878d10: r0 = AllocateArray()
    //     0x878d10: bl              #0x13df928  ; AllocateArrayStub
    // 0x878d14: r16 = "TextInputAction."
    //     0x878d14: ldr             x16, [PP, #0x6190]  ; [pp+0x6190] "TextInputAction."
    // 0x878d18: StoreField: r0->field_f = r16
    //     0x878d18: stur            w16, [x0, #0xf]
    // 0x878d1c: ldur            x1, [fp, #-0x20]
    // 0x878d20: LoadField: r2 = r1->field_f
    //     0x878d20: ldur            w2, [x1, #0xf]
    // 0x878d24: DecompressPointer r2
    //     0x878d24: add             x2, x2, HEAP, lsl #32
    // 0x878d28: StoreField: r0->field_13 = r2
    //     0x878d28: stur            w2, [x0, #0x13]
    // 0x878d2c: str             x0, [SP]
    // 0x878d30: r0 = _interpolate()
    //     0x878d30: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x878d34: ldur            x4, [fp, #-0x18]
    // 0x878d38: r1 = LoadClassIdInstr(r4)
    //     0x878d38: ldur            x1, [x4, #-1]
    //     0x878d3c: ubfx            x1, x1, #0xc, #0x14
    // 0x878d40: mov             x3, x0
    // 0x878d44: mov             x0, x1
    // 0x878d48: mov             x1, x4
    // 0x878d4c: r2 = "inputAction"
    //     0x878d4c: ldr             x2, [PP, #0x6198]  ; [pp+0x6198] "inputAction"
    // 0x878d50: r0 = GDT[cid_x0 + -0xd50]()
    //     0x878d50: sub             lr, x0, #0xd50
    //     0x878d54: ldr             lr, [x21, lr, lsl #3]
    //     0x878d58: blr             lr
    // 0x878d5c: ldur            x4, [fp, #-0x18]
    // 0x878d60: r0 = LoadClassIdInstr(r4)
    //     0x878d60: ldur            x0, [x4, #-1]
    //     0x878d64: ubfx            x0, x0, #0xc, #0x14
    // 0x878d68: mov             x1, x4
    // 0x878d6c: r2 = "textCapitalization"
    //     0x878d6c: ldr             x2, [PP, #0x61a0]  ; [pp+0x61a0] "textCapitalization"
    // 0x878d70: r3 = "TextCapitalization.none"
    //     0x878d70: ldr             x3, [PP, #0x61a8]  ; [pp+0x61a8] "TextCapitalization.none"
    // 0x878d74: r0 = GDT[cid_x0 + -0xd50]()
    //     0x878d74: sub             lr, x0, #0xd50
    //     0x878d78: ldr             lr, [x21, lr, lsl #3]
    //     0x878d7c: blr             lr
    // 0x878d80: ldur            x0, [fp, #-8]
    // 0x878d84: LoadField: r3 = r0->field_3b
    //     0x878d84: ldur            w3, [x0, #0x3b]
    // 0x878d88: DecompressPointer r3
    //     0x878d88: add             x3, x3, HEAP, lsl #32
    // 0x878d8c: stur            x3, [fp, #-0x20]
    // 0x878d90: r1 = Null
    //     0x878d90: mov             x1, NULL
    // 0x878d94: r2 = 4
    //     0x878d94: mov             x2, #4
    // 0x878d98: r0 = AllocateArray()
    //     0x878d98: bl              #0x13df928  ; AllocateArrayStub
    // 0x878d9c: r16 = "Brightness."
    //     0x878d9c: ldr             x16, [PP, #0x2c60]  ; [pp+0x2c60] "Brightness."
    // 0x878da0: StoreField: r0->field_f = r16
    //     0x878da0: stur            w16, [x0, #0xf]
    // 0x878da4: ldur            x1, [fp, #-0x20]
    // 0x878da8: LoadField: r2 = r1->field_f
    //     0x878da8: ldur            w2, [x1, #0xf]
    // 0x878dac: DecompressPointer r2
    //     0x878dac: add             x2, x2, HEAP, lsl #32
    // 0x878db0: StoreField: r0->field_13 = r2
    //     0x878db0: stur            w2, [x0, #0x13]
    // 0x878db4: str             x0, [SP]
    // 0x878db8: r0 = _interpolate()
    //     0x878db8: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x878dbc: ldur            x4, [fp, #-0x18]
    // 0x878dc0: r1 = LoadClassIdInstr(r4)
    //     0x878dc0: ldur            x1, [x4, #-1]
    //     0x878dc4: ubfx            x1, x1, #0xc, #0x14
    // 0x878dc8: mov             x3, x0
    // 0x878dcc: mov             x0, x1
    // 0x878dd0: mov             x1, x4
    // 0x878dd4: r2 = "keyboardAppearance"
    //     0x878dd4: ldr             x2, [PP, #0x61b0]  ; [pp+0x61b0] "keyboardAppearance"
    // 0x878dd8: r0 = GDT[cid_x0 + -0xd50]()
    //     0x878dd8: sub             lr, x0, #0xd50
    //     0x878ddc: ldr             lr, [x21, lr, lsl #3]
    //     0x878de0: blr             lr
    // 0x878de4: ldur            x4, [fp, #-0x18]
    // 0x878de8: r0 = LoadClassIdInstr(r4)
    //     0x878de8: ldur            x0, [x4, #-1]
    //     0x878dec: ubfx            x0, x0, #0xc, #0x14
    // 0x878df0: mov             x1, x4
    // 0x878df4: r2 = "enableIMEPersonalizedLearning"
    //     0x878df4: ldr             x2, [PP, #0x61b8]  ; [pp+0x61b8] "enableIMEPersonalizedLearning"
    // 0x878df8: r3 = true
    //     0x878df8: add             x3, NULL, #0x20  ; true
    // 0x878dfc: r0 = GDT[cid_x0 + -0xd50]()
    //     0x878dfc: sub             lr, x0, #0xd50
    //     0x878e00: ldr             lr, [x21, lr, lsl #3]
    //     0x878e04: blr             lr
    // 0x878e08: ldur            x4, [fp, #-0x18]
    // 0x878e0c: r0 = LoadClassIdInstr(r4)
    //     0x878e0c: ldur            x0, [x4, #-1]
    //     0x878e10: ubfx            x0, x0, #0xc, #0x14
    // 0x878e14: mov             x1, x4
    // 0x878e18: r2 = "contentCommitMimeTypes"
    //     0x878e18: ldr             x2, [PP, #0x61c0]  ; [pp+0x61c0] "contentCommitMimeTypes"
    // 0x878e1c: r3 = const []
    //     0x878e1c: ldr             x3, [PP, #0x61c8]  ; [pp+0x61c8] List<String>(0)
    // 0x878e20: r0 = GDT[cid_x0 + -0xd50]()
    //     0x878e20: sub             lr, x0, #0xd50
    //     0x878e24: ldr             lr, [x21, lr, lsl #3]
    //     0x878e28: blr             lr
    // 0x878e2c: ldur            x3, [fp, #-0x10]
    // 0x878e30: cmp             w3, NULL
    // 0x878e34: b.eq            #0x878e58
    // 0x878e38: ldur            x4, [fp, #-0x18]
    // 0x878e3c: r0 = LoadClassIdInstr(r4)
    //     0x878e3c: ldur            x0, [x4, #-1]
    //     0x878e40: ubfx            x0, x0, #0xc, #0x14
    // 0x878e44: mov             x1, x4
    // 0x878e48: r2 = "autofill"
    //     0x878e48: ldr             x2, [PP, #0x61d0]  ; [pp+0x61d0] "autofill"
    // 0x878e4c: r0 = GDT[cid_x0 + -0xd50]()
    //     0x878e4c: sub             lr, x0, #0xd50
    //     0x878e50: ldr             lr, [x21, lr, lsl #3]
    //     0x878e54: blr             lr
    // 0x878e58: ldur            x4, [fp, #-0x18]
    // 0x878e5c: r0 = LoadClassIdInstr(r4)
    //     0x878e5c: ldur            x0, [x4, #-1]
    //     0x878e60: ubfx            x0, x0, #0xc, #0x14
    // 0x878e64: mov             x1, x4
    // 0x878e68: r2 = "enableDeltaModel"
    //     0x878e68: ldr             x2, [PP, #0x61d8]  ; [pp+0x61d8] "enableDeltaModel"
    // 0x878e6c: r3 = false
    //     0x878e6c: add             x3, NULL, #0x30  ; false
    // 0x878e70: r0 = GDT[cid_x0 + -0xd50]()
    //     0x878e70: sub             lr, x0, #0xd50
    //     0x878e74: ldr             lr, [x21, lr, lsl #3]
    //     0x878e78: blr             lr
    // 0x878e7c: ldur            x4, [fp, #-0x18]
    // 0x878e80: r0 = LoadClassIdInstr(r4)
    //     0x878e80: ldur            x0, [x4, #-1]
    //     0x878e84: ubfx            x0, x0, #0xc, #0x14
    // 0x878e88: mov             x1, x4
    // 0x878e8c: r2 = "hintLocales"
    //     0x878e8c: ldr             x2, [PP, #0x61e0]  ; [pp+0x61e0] "hintLocales"
    // 0x878e90: r3 = Null
    //     0x878e90: mov             x3, NULL
    // 0x878e94: r0 = GDT[cid_x0 + -0xd50]()
    //     0x878e94: sub             lr, x0, #0xd50
    //     0x878e98: ldr             lr, [x21, lr, lsl #3]
    //     0x878e9c: blr             lr
    // 0x878ea0: ldur            x4, [fp, #-0x18]
    // 0x878ea4: r0 = LoadClassIdInstr(r4)
    //     0x878ea4: ldur            x0, [x4, #-1]
    //     0x878ea8: ubfx            x0, x0, #0xc, #0x14
    // 0x878eac: mov             x1, x4
    // 0x878eb0: r2 = "enableInlinePrediction"
    //     0x878eb0: ldr             x2, [PP, #0x61e8]  ; [pp+0x61e8] "enableInlinePrediction"
    // 0x878eb4: r3 = Null
    //     0x878eb4: mov             x3, NULL
    // 0x878eb8: r0 = GDT[cid_x0 + -0xd50]()
    //     0x878eb8: sub             lr, x0, #0xd50
    //     0x878ebc: ldr             lr, [x21, lr, lsl #3]
    //     0x878ec0: blr             lr
    // 0x878ec4: ldur            x0, [fp, #-0x18]
    // 0x878ec8: LeaveFrame
    //     0x878ec8: mov             SP, fp
    //     0x878ecc: ldp             fp, lr, [SP], #0x10
    // 0x878ed0: ret
    //     0x878ed0: ret             
    // 0x878ed4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x878ed4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x878ed8: b               #0x878ad8
  }
  Map<String, dynamic> toJson(TextInputConfiguration) {
    // ** addr: 0x878ef4, size: 0x48
    // 0x878ef4: EnterFrame
    //     0x878ef4: stp             fp, lr, [SP, #-0x10]!
    //     0x878ef8: mov             fp, SP
    // 0x878efc: CheckStackOverflow
    //     0x878efc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x878f00: cmp             SP, x16
    //     0x878f04: b.ls            #0x878f1c
    // 0x878f08: ldr             x1, [fp, #0x10]
    // 0x878f0c: r0 = toJson()
    //     0x878f0c: bl              #0x878ab8  ; [package:flutter/src/services/text_input.dart] TextInputConfiguration::toJson
    // 0x878f10: LeaveFrame
    //     0x878f10: mov             SP, fp
    //     0x878f14: ldp             fp, lr, [SP], #0x10
    // 0x878f18: ret
    //     0x878f18: ret             
    // 0x878f1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x878f1c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x878f20: b               #0x878f08
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x114cefc, size: 0x150
    // 0x114cefc: EnterFrame
    //     0x114cefc: stp             fp, lr, [SP, #-0x10]!
    //     0x114cf00: mov             fp, SP
    // 0x114cf04: AllocStack(0xd8)
    //     0x114cf04: sub             SP, SP, #0xd8
    // 0x114cf08: CheckStackOverflow
    //     0x114cf08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x114cf0c: cmp             SP, x16
    //     0x114cf10: b.ls            #0x114d044
    // 0x114cf14: ldr             x0, [fp, #0x10]
    // 0x114cf18: LoadField: r2 = r0->field_7
    //     0x114cf18: ldur            w2, [x0, #7]
    // 0x114cf1c: DecompressPointer r2
    //     0x114cf1c: add             x2, x2, HEAP, lsl #32
    // 0x114cf20: stur            x2, [fp, #-0x50]
    // 0x114cf24: LoadField: r3 = r0->field_b
    //     0x114cf24: ldur            w3, [x0, #0xb]
    // 0x114cf28: DecompressPointer r3
    //     0x114cf28: add             x3, x3, HEAP, lsl #32
    // 0x114cf2c: stur            x3, [fp, #-0x48]
    // 0x114cf30: LoadField: r4 = r0->field_f
    //     0x114cf30: ldur            w4, [x0, #0xf]
    // 0x114cf34: DecompressPointer r4
    //     0x114cf34: add             x4, x4, HEAP, lsl #32
    // 0x114cf38: stur            x4, [fp, #-0x40]
    // 0x114cf3c: LoadField: r5 = r0->field_13
    //     0x114cf3c: ldur            w5, [x0, #0x13]
    // 0x114cf40: DecompressPointer r5
    //     0x114cf40: add             x5, x5, HEAP, lsl #32
    // 0x114cf44: stur            x5, [fp, #-0x38]
    // 0x114cf48: LoadField: r6 = r0->field_1f
    //     0x114cf48: ldur            w6, [x0, #0x1f]
    // 0x114cf4c: DecompressPointer r6
    //     0x114cf4c: add             x6, x6, HEAP, lsl #32
    // 0x114cf50: stur            x6, [fp, #-0x30]
    // 0x114cf54: LoadField: r7 = r0->field_23
    //     0x114cf54: ldur            w7, [x0, #0x23]
    // 0x114cf58: DecompressPointer r7
    //     0x114cf58: add             x7, x7, HEAP, lsl #32
    // 0x114cf5c: stur            x7, [fp, #-0x28]
    // 0x114cf60: LoadField: r8 = r0->field_2b
    //     0x114cf60: ldur            w8, [x0, #0x2b]
    // 0x114cf64: DecompressPointer r8
    //     0x114cf64: add             x8, x8, HEAP, lsl #32
    // 0x114cf68: stur            x8, [fp, #-0x20]
    // 0x114cf6c: LoadField: r9 = r0->field_33
    //     0x114cf6c: ldur            w9, [x0, #0x33]
    // 0x114cf70: DecompressPointer r9
    //     0x114cf70: add             x9, x9, HEAP, lsl #32
    // 0x114cf74: stur            x9, [fp, #-0x18]
    // 0x114cf78: LoadField: r10 = r0->field_3b
    //     0x114cf78: ldur            w10, [x0, #0x3b]
    // 0x114cf7c: DecompressPointer r10
    //     0x114cf7c: add             x10, x10, HEAP, lsl #32
    // 0x114cf80: stur            x10, [fp, #-0x10]
    // 0x114cf84: LoadField: r11 = r0->field_1b
    //     0x114cf84: ldur            w11, [x0, #0x1b]
    // 0x114cf88: DecompressPointer r11
    //     0x114cf88: add             x11, x11, HEAP, lsl #32
    // 0x114cf8c: stur            x11, [fp, #-8]
    // 0x114cf90: r1 = const []
    //     0x114cf90: ldr             x1, [PP, #0x61c8]  ; [pp+0x61c8] List<String>(0)
    // 0x114cf94: r0 = hashAll()
    //     0x114cf94: bl              #0x112b348  ; [dart:core] Object::hashAll
    // 0x114cf98: mov             x2, x0
    // 0x114cf9c: r0 = BoxInt64Instr(r2)
    //     0x114cf9c: sbfiz           x0, x2, #1, #0x1f
    //     0x114cfa0: cmp             x2, x0, asr #1
    //     0x114cfa4: b.eq            #0x114cfb0
    //     0x114cfa8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x114cfac: stur            x2, [x0, #7]
    // 0x114cfb0: ldur            x16, [fp, #-0x40]
    // 0x114cfb4: ldur            lr, [fp, #-0x38]
    // 0x114cfb8: stp             lr, x16, [SP, #0x78]
    // 0x114cfbc: r16 = true
    //     0x114cfbc: add             x16, NULL, #0x20  ; true
    // 0x114cfc0: ldur            lr, [fp, #-0x30]
    // 0x114cfc4: stp             lr, x16, [SP, #0x68]
    // 0x114cfc8: ldur            x16, [fp, #-0x28]
    // 0x114cfcc: r30 = true
    //     0x114cfcc: add             lr, NULL, #0x20  ; true
    // 0x114cfd0: stp             lr, x16, [SP, #0x58]
    // 0x114cfd4: ldur            x16, [fp, #-0x20]
    // 0x114cfd8: stp             NULL, x16, [SP, #0x48]
    // 0x114cfdc: ldur            x16, [fp, #-0x18]
    // 0x114cfe0: ldur            lr, [fp, #-0x10]
    // 0x114cfe4: stp             lr, x16, [SP, #0x38]
    // 0x114cfe8: r16 = Instance_TextCapitalization
    //     0x114cfe8: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a650] Obj!TextCapitalization@12c37c1
    //     0x114cfec: ldr             x16, [x16, #0x650]
    // 0x114cff0: ldur            lr, [fp, #-8]
    // 0x114cff4: stp             lr, x16, [SP, #0x28]
    // 0x114cff8: r16 = true
    //     0x114cff8: add             x16, NULL, #0x20  ; true
    // 0x114cffc: stp             x0, x16, [SP, #0x18]
    // 0x114d000: r16 = false
    //     0x114d000: add             x16, NULL, #0x30  ; false
    // 0x114d004: stp             NULL, x16, [SP, #8]
    // 0x114d008: str             NULL, [SP]
    // 0x114d00c: ldur            x1, [fp, #-0x50]
    // 0x114d010: ldur            x2, [fp, #-0x48]
    // 0x114d014: r4 = const [0, 0x13, 0x11, 0x13, null]
    //     0x114d014: add             x4, PP, #0x26, lsl #12  ; [pp+0x267f0] List(5) [0, 0x13, 0x11, 0x13, Null]
    //     0x114d018: ldr             x4, [x4, #0x7f0]
    // 0x114d01c: r0 = hash()
    //     0x114d01c: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x114d020: mov             x2, x0
    // 0x114d024: r0 = BoxInt64Instr(r2)
    //     0x114d024: sbfiz           x0, x2, #1, #0x1f
    //     0x114d028: cmp             x2, x0, asr #1
    //     0x114d02c: b.eq            #0x114d038
    //     0x114d030: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x114d034: stur            x2, [x0, #7]
    // 0x114d038: LeaveFrame
    //     0x114d038: mov             SP, fp
    //     0x114d03c: ldp             fp, lr, [SP], #0x10
    // 0x114d040: ret
    //     0x114d040: ret             
    // 0x114d044: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x114d044: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x114d048: b               #0x114cf14
  }
  _ ==(/* No info */) {
    // ** addr: 0x129b02c, size: 0x254
    // 0x129b02c: EnterFrame
    //     0x129b02c: stp             fp, lr, [SP, #-0x10]!
    //     0x129b030: mov             fp, SP
    // 0x129b034: AllocStack(0x18)
    //     0x129b034: sub             SP, SP, #0x18
    // 0x129b038: CheckStackOverflow
    //     0x129b038: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x129b03c: cmp             SP, x16
    //     0x129b040: b.ls            #0x129b278
    // 0x129b044: ldr             x0, [fp, #0x10]
    // 0x129b048: cmp             w0, NULL
    // 0x129b04c: b.ne            #0x129b060
    // 0x129b050: r0 = false
    //     0x129b050: add             x0, NULL, #0x30  ; false
    // 0x129b054: LeaveFrame
    //     0x129b054: mov             SP, fp
    //     0x129b058: ldp             fp, lr, [SP], #0x10
    // 0x129b05c: ret
    //     0x129b05c: ret             
    // 0x129b060: ldr             x1, [fp, #0x18]
    // 0x129b064: cmp             w1, w0
    // 0x129b068: b.ne            #0x129b07c
    // 0x129b06c: r0 = true
    //     0x129b06c: add             x0, NULL, #0x20  ; true
    // 0x129b070: LeaveFrame
    //     0x129b070: mov             SP, fp
    //     0x129b074: ldp             fp, lr, [SP], #0x10
    // 0x129b078: ret
    //     0x129b078: ret             
    // 0x129b07c: str             x0, [SP]
    // 0x129b080: r0 = runtimeType()
    //     0x129b080: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x129b084: r1 = LoadClassIdInstr(r0)
    //     0x129b084: ldur            x1, [x0, #-1]
    //     0x129b088: ubfx            x1, x1, #0xc, #0x14
    // 0x129b08c: r16 = TextInputConfiguration
    //     0x129b08c: add             x16, PP, #0x99, lsl #12  ; [pp+0x99b78] Type: TextInputConfiguration
    //     0x129b090: ldr             x16, [x16, #0xb78]
    // 0x129b094: stp             x16, x0, [SP]
    // 0x129b098: mov             x0, x1
    // 0x129b09c: mov             lr, x0
    // 0x129b0a0: ldr             lr, [x21, lr, lsl #3]
    // 0x129b0a4: blr             lr
    // 0x129b0a8: tbz             w0, #4, #0x129b0bc
    // 0x129b0ac: r0 = false
    //     0x129b0ac: add             x0, NULL, #0x30  ; false
    // 0x129b0b0: LeaveFrame
    //     0x129b0b0: mov             SP, fp
    //     0x129b0b4: ldp             fp, lr, [SP], #0x10
    // 0x129b0b8: ret
    //     0x129b0b8: ret             
    // 0x129b0bc: ldr             x0, [fp, #0x10]
    // 0x129b0c0: r1 = 60
    //     0x129b0c0: mov             x1, #0x3c
    // 0x129b0c4: branchIfSmi(r0, 0x129b0d0)
    //     0x129b0c4: tbz             w0, #0, #0x129b0d0
    // 0x129b0c8: r1 = LoadClassIdInstr(r0)
    //     0x129b0c8: ldur            x1, [x0, #-1]
    //     0x129b0cc: ubfx            x1, x1, #0xc, #0x14
    // 0x129b0d0: cmp             x1, #0xaab
    // 0x129b0d4: b.ne            #0x129b268
    // 0x129b0d8: ldr             x1, [fp, #0x18]
    // 0x129b0dc: LoadField: r2 = r0->field_7
    //     0x129b0dc: ldur            w2, [x0, #7]
    // 0x129b0e0: DecompressPointer r2
    //     0x129b0e0: add             x2, x2, HEAP, lsl #32
    // 0x129b0e4: LoadField: r3 = r1->field_7
    //     0x129b0e4: ldur            w3, [x1, #7]
    // 0x129b0e8: DecompressPointer r3
    //     0x129b0e8: add             x3, x3, HEAP, lsl #32
    // 0x129b0ec: cmp             w2, w3
    // 0x129b0f0: b.eq            #0x129b12c
    // 0x129b0f4: and             w16, w2, w3
    // 0x129b0f8: branchIfSmi(r16, 0x129b268)
    //     0x129b0f8: tbz             w16, #0, #0x129b268
    // 0x129b0fc: r16 = LoadClassIdInstr(r2)
    //     0x129b0fc: ldur            x16, [x2, #-1]
    //     0x129b100: ubfx            x16, x16, #0xc, #0x14
    // 0x129b104: cmp             x16, #0x3d
    // 0x129b108: b.ne            #0x129b268
    // 0x129b10c: r16 = LoadClassIdInstr(r3)
    //     0x129b10c: ldur            x16, [x3, #-1]
    //     0x129b110: ubfx            x16, x16, #0xc, #0x14
    // 0x129b114: cmp             x16, #0x3d
    // 0x129b118: b.ne            #0x129b268
    // 0x129b11c: LoadField: r16 = r2->field_7
    //     0x129b11c: ldur            x16, [x2, #7]
    // 0x129b120: LoadField: r17 = r3->field_7
    //     0x129b120: ldur            x17, [x3, #7]
    // 0x129b124: cmp             x16, x17
    // 0x129b128: b.ne            #0x129b268
    // 0x129b12c: LoadField: r2 = r0->field_b
    //     0x129b12c: ldur            w2, [x0, #0xb]
    // 0x129b130: DecompressPointer r2
    //     0x129b130: add             x2, x2, HEAP, lsl #32
    // 0x129b134: LoadField: r3 = r1->field_b
    //     0x129b134: ldur            w3, [x1, #0xb]
    // 0x129b138: DecompressPointer r3
    //     0x129b138: add             x3, x3, HEAP, lsl #32
    // 0x129b13c: LoadField: r4 = r3->field_7
    //     0x129b13c: ldur            x4, [x3, #7]
    // 0x129b140: LoadField: r5 = r2->field_7
    //     0x129b140: ldur            x5, [x2, #7]
    // 0x129b144: cmp             x4, x5
    // 0x129b148: b.ne            #0x129b268
    // 0x129b14c: LoadField: r4 = r3->field_f
    //     0x129b14c: ldur            w4, [x3, #0xf]
    // 0x129b150: DecompressPointer r4
    //     0x129b150: add             x4, x4, HEAP, lsl #32
    // 0x129b154: LoadField: r5 = r2->field_f
    //     0x129b154: ldur            w5, [x2, #0xf]
    // 0x129b158: DecompressPointer r5
    //     0x129b158: add             x5, x5, HEAP, lsl #32
    // 0x129b15c: cmp             w4, w5
    // 0x129b160: b.ne            #0x129b268
    // 0x129b164: LoadField: r4 = r3->field_13
    //     0x129b164: ldur            w4, [x3, #0x13]
    // 0x129b168: DecompressPointer r4
    //     0x129b168: add             x4, x4, HEAP, lsl #32
    // 0x129b16c: LoadField: r3 = r2->field_13
    //     0x129b16c: ldur            w3, [x2, #0x13]
    // 0x129b170: DecompressPointer r3
    //     0x129b170: add             x3, x3, HEAP, lsl #32
    // 0x129b174: cmp             w4, w3
    // 0x129b178: b.ne            #0x129b268
    // 0x129b17c: LoadField: r2 = r0->field_f
    //     0x129b17c: ldur            w2, [x0, #0xf]
    // 0x129b180: DecompressPointer r2
    //     0x129b180: add             x2, x2, HEAP, lsl #32
    // 0x129b184: LoadField: r3 = r1->field_f
    //     0x129b184: ldur            w3, [x1, #0xf]
    // 0x129b188: DecompressPointer r3
    //     0x129b188: add             x3, x3, HEAP, lsl #32
    // 0x129b18c: cmp             w2, w3
    // 0x129b190: b.ne            #0x129b268
    // 0x129b194: LoadField: r2 = r0->field_13
    //     0x129b194: ldur            w2, [x0, #0x13]
    // 0x129b198: DecompressPointer r2
    //     0x129b198: add             x2, x2, HEAP, lsl #32
    // 0x129b19c: LoadField: r3 = r1->field_13
    //     0x129b19c: ldur            w3, [x1, #0x13]
    // 0x129b1a0: DecompressPointer r3
    //     0x129b1a0: add             x3, x3, HEAP, lsl #32
    // 0x129b1a4: cmp             w2, w3
    // 0x129b1a8: b.ne            #0x129b268
    // 0x129b1ac: LoadField: r2 = r0->field_1f
    //     0x129b1ac: ldur            w2, [x0, #0x1f]
    // 0x129b1b0: DecompressPointer r2
    //     0x129b1b0: add             x2, x2, HEAP, lsl #32
    // 0x129b1b4: LoadField: r3 = r1->field_1f
    //     0x129b1b4: ldur            w3, [x1, #0x1f]
    // 0x129b1b8: DecompressPointer r3
    //     0x129b1b8: add             x3, x3, HEAP, lsl #32
    // 0x129b1bc: cmp             w2, w3
    // 0x129b1c0: b.ne            #0x129b268
    // 0x129b1c4: LoadField: r2 = r0->field_23
    //     0x129b1c4: ldur            w2, [x0, #0x23]
    // 0x129b1c8: DecompressPointer r2
    //     0x129b1c8: add             x2, x2, HEAP, lsl #32
    // 0x129b1cc: LoadField: r3 = r1->field_23
    //     0x129b1cc: ldur            w3, [x1, #0x23]
    // 0x129b1d0: DecompressPointer r3
    //     0x129b1d0: add             x3, x3, HEAP, lsl #32
    // 0x129b1d4: cmp             w2, w3
    // 0x129b1d8: b.ne            #0x129b268
    // 0x129b1dc: LoadField: r2 = r0->field_2b
    //     0x129b1dc: ldur            w2, [x0, #0x2b]
    // 0x129b1e0: DecompressPointer r2
    //     0x129b1e0: add             x2, x2, HEAP, lsl #32
    // 0x129b1e4: LoadField: r3 = r1->field_2b
    //     0x129b1e4: ldur            w3, [x1, #0x2b]
    // 0x129b1e8: DecompressPointer r3
    //     0x129b1e8: add             x3, x3, HEAP, lsl #32
    // 0x129b1ec: cmp             w2, w3
    // 0x129b1f0: b.ne            #0x129b268
    // 0x129b1f4: LoadField: r2 = r0->field_33
    //     0x129b1f4: ldur            w2, [x0, #0x33]
    // 0x129b1f8: DecompressPointer r2
    //     0x129b1f8: add             x2, x2, HEAP, lsl #32
    // 0x129b1fc: LoadField: r3 = r1->field_33
    //     0x129b1fc: ldur            w3, [x1, #0x33]
    // 0x129b200: DecompressPointer r3
    //     0x129b200: add             x3, x3, HEAP, lsl #32
    // 0x129b204: cmp             w2, w3
    // 0x129b208: b.ne            #0x129b268
    // 0x129b20c: LoadField: r2 = r0->field_3b
    //     0x129b20c: ldur            w2, [x0, #0x3b]
    // 0x129b210: DecompressPointer r2
    //     0x129b210: add             x2, x2, HEAP, lsl #32
    // 0x129b214: LoadField: r3 = r1->field_3b
    //     0x129b214: ldur            w3, [x1, #0x3b]
    // 0x129b218: DecompressPointer r3
    //     0x129b218: add             x3, x3, HEAP, lsl #32
    // 0x129b21c: cmp             w2, w3
    // 0x129b220: b.ne            #0x129b268
    // 0x129b224: LoadField: r2 = r0->field_1b
    //     0x129b224: ldur            w2, [x0, #0x1b]
    // 0x129b228: DecompressPointer r2
    //     0x129b228: add             x2, x2, HEAP, lsl #32
    // 0x129b22c: LoadField: r0 = r1->field_1b
    //     0x129b22c: ldur            w0, [x1, #0x1b]
    // 0x129b230: DecompressPointer r0
    //     0x129b230: add             x0, x0, HEAP, lsl #32
    // 0x129b234: stp             x0, x2, [SP]
    // 0x129b238: r0 = ==()
    //     0x129b238: bl              #0x129a8c0  ; [package:flutter/src/services/autofill.dart] AutofillConfiguration::==
    // 0x129b23c: tbnz            w0, #4, #0x129b268
    // 0x129b240: r16 = <String>
    //     0x129b240: ldr             x16, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    // 0x129b244: r30 = const []
    //     0x129b244: ldr             lr, [PP, #0x61c8]  ; [pp+0x61c8] List<String>(0)
    // 0x129b248: stp             lr, x16, [SP, #8]
    // 0x129b24c: r16 = const []
    //     0x129b24c: ldr             x16, [PP, #0x61c8]  ; [pp+0x61c8] List<String>(0)
    // 0x129b250: str             x16, [SP]
    // 0x129b254: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x129b254: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x129b258: r0 = listEquals()
    //     0x129b258: bl              #0x8595b0  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0x129b25c: tbnz            w0, #4, #0x129b268
    // 0x129b260: r0 = true
    //     0x129b260: add             x0, NULL, #0x20  ; true
    // 0x129b264: b               #0x129b26c
    // 0x129b268: r0 = false
    //     0x129b268: add             x0, NULL, #0x30  ; false
    // 0x129b26c: LeaveFrame
    //     0x129b26c: mov             SP, fp
    //     0x129b270: ldp             fp, lr, [SP], #0x10
    // 0x129b274: ret
    //     0x129b274: ret             
    // 0x129b278: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x129b278: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x129b27c: b               #0x129b044
  }
  _ copyWith(/* No info */) {
    // ** addr: 0x12a1c60, size: 0x108
    // 0x12a1c60: EnterFrame
    //     0x12a1c60: stp             fp, lr, [SP, #-0x10]!
    //     0x12a1c64: mov             fp, SP
    // 0x12a1c68: AllocStack(0x50)
    //     0x12a1c68: sub             SP, SP, #0x50
    // 0x12a1c6c: SetupParameters(dynamic _ /* r2 => r2, fp-0x50 */)
    //     0x12a1c6c: stur            x2, [fp, #-0x50]
    // 0x12a1c70: LoadField: r0 = r1->field_7
    //     0x12a1c70: ldur            w0, [x1, #7]
    // 0x12a1c74: DecompressPointer r0
    //     0x12a1c74: add             x0, x0, HEAP, lsl #32
    // 0x12a1c78: stur            x0, [fp, #-0x48]
    // 0x12a1c7c: LoadField: r3 = r1->field_b
    //     0x12a1c7c: ldur            w3, [x1, #0xb]
    // 0x12a1c80: DecompressPointer r3
    //     0x12a1c80: add             x3, x3, HEAP, lsl #32
    // 0x12a1c84: stur            x3, [fp, #-0x40]
    // 0x12a1c88: LoadField: r4 = r1->field_f
    //     0x12a1c88: ldur            w4, [x1, #0xf]
    // 0x12a1c8c: DecompressPointer r4
    //     0x12a1c8c: add             x4, x4, HEAP, lsl #32
    // 0x12a1c90: stur            x4, [fp, #-0x38]
    // 0x12a1c94: LoadField: r5 = r1->field_13
    //     0x12a1c94: ldur            w5, [x1, #0x13]
    // 0x12a1c98: DecompressPointer r5
    //     0x12a1c98: add             x5, x5, HEAP, lsl #32
    // 0x12a1c9c: stur            x5, [fp, #-0x30]
    // 0x12a1ca0: LoadField: r6 = r1->field_1f
    //     0x12a1ca0: ldur            w6, [x1, #0x1f]
    // 0x12a1ca4: DecompressPointer r6
    //     0x12a1ca4: add             x6, x6, HEAP, lsl #32
    // 0x12a1ca8: stur            x6, [fp, #-0x28]
    // 0x12a1cac: LoadField: r7 = r1->field_23
    //     0x12a1cac: ldur            w7, [x1, #0x23]
    // 0x12a1cb0: DecompressPointer r7
    //     0x12a1cb0: add             x7, x7, HEAP, lsl #32
    // 0x12a1cb4: stur            x7, [fp, #-0x20]
    // 0x12a1cb8: LoadField: r8 = r1->field_2b
    //     0x12a1cb8: ldur            w8, [x1, #0x2b]
    // 0x12a1cbc: DecompressPointer r8
    //     0x12a1cbc: add             x8, x8, HEAP, lsl #32
    // 0x12a1cc0: stur            x8, [fp, #-0x18]
    // 0x12a1cc4: LoadField: r9 = r1->field_33
    //     0x12a1cc4: ldur            w9, [x1, #0x33]
    // 0x12a1cc8: DecompressPointer r9
    //     0x12a1cc8: add             x9, x9, HEAP, lsl #32
    // 0x12a1ccc: stur            x9, [fp, #-0x10]
    // 0x12a1cd0: LoadField: r10 = r1->field_3b
    //     0x12a1cd0: ldur            w10, [x1, #0x3b]
    // 0x12a1cd4: DecompressPointer r10
    //     0x12a1cd4: add             x10, x10, HEAP, lsl #32
    // 0x12a1cd8: stur            x10, [fp, #-8]
    // 0x12a1cdc: r0 = TextInputConfiguration()
    //     0x12a1cdc: bl              #0x12a1d68  ; AllocateTextInputConfigurationStub -> TextInputConfiguration (size=0x54)
    // 0x12a1ce0: ldur            x1, [fp, #-0x48]
    // 0x12a1ce4: StoreField: r0->field_7 = r1
    //     0x12a1ce4: stur            w1, [x0, #7]
    // 0x12a1ce8: ldur            x1, [fp, #-0x40]
    // 0x12a1cec: StoreField: r0->field_b = r1
    //     0x12a1cec: stur            w1, [x0, #0xb]
    // 0x12a1cf0: ldur            x1, [fp, #-0x38]
    // 0x12a1cf4: StoreField: r0->field_f = r1
    //     0x12a1cf4: stur            w1, [x0, #0xf]
    // 0x12a1cf8: ldur            x1, [fp, #-0x30]
    // 0x12a1cfc: StoreField: r0->field_13 = r1
    //     0x12a1cfc: stur            w1, [x0, #0x13]
    // 0x12a1d00: r1 = true
    //     0x12a1d00: add             x1, NULL, #0x20  ; true
    // 0x12a1d04: ArrayStore: r0[0] = r1  ; List_4
    //     0x12a1d04: stur            w1, [x0, #0x17]
    // 0x12a1d08: StoreField: r0->field_27 = r1
    //     0x12a1d08: stur            w1, [x0, #0x27]
    // 0x12a1d0c: ldur            x2, [fp, #-0x18]
    // 0x12a1d10: StoreField: r0->field_2b = r2
    //     0x12a1d10: stur            w2, [x0, #0x2b]
    // 0x12a1d14: ldur            x2, [fp, #-0x10]
    // 0x12a1d18: StoreField: r0->field_33 = r2
    //     0x12a1d18: stur            w2, [x0, #0x33]
    // 0x12a1d1c: ldur            x2, [fp, #-8]
    // 0x12a1d20: StoreField: r0->field_3b = r2
    //     0x12a1d20: stur            w2, [x0, #0x3b]
    // 0x12a1d24: r2 = Instance_TextCapitalization
    //     0x12a1d24: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1a650] Obj!TextCapitalization@12c37c1
    //     0x12a1d28: ldr             x2, [x2, #0x650]
    // 0x12a1d2c: StoreField: r0->field_37 = r2
    //     0x12a1d2c: stur            w2, [x0, #0x37]
    // 0x12a1d30: ldur            x2, [fp, #-0x50]
    // 0x12a1d34: StoreField: r0->field_1b = r2
    //     0x12a1d34: stur            w2, [x0, #0x1b]
    // 0x12a1d38: StoreField: r0->field_3f = r1
    //     0x12a1d38: stur            w1, [x0, #0x3f]
    // 0x12a1d3c: r1 = const []
    //     0x12a1d3c: ldr             x1, [PP, #0x61c8]  ; [pp+0x61c8] List<String>(0)
    // 0x12a1d40: StoreField: r0->field_43 = r1
    //     0x12a1d40: stur            w1, [x0, #0x43]
    // 0x12a1d44: r1 = false
    //     0x12a1d44: add             x1, NULL, #0x30  ; false
    // 0x12a1d48: StoreField: r0->field_4f = r1
    //     0x12a1d48: stur            w1, [x0, #0x4f]
    // 0x12a1d4c: ldur            x1, [fp, #-0x28]
    // 0x12a1d50: StoreField: r0->field_1f = r1
    //     0x12a1d50: stur            w1, [x0, #0x1f]
    // 0x12a1d54: ldur            x1, [fp, #-0x20]
    // 0x12a1d58: StoreField: r0->field_23 = r1
    //     0x12a1d58: stur            w1, [x0, #0x23]
    // 0x12a1d5c: LeaveFrame
    //     0x12a1d5c: mov             SP, fp
    //     0x12a1d60: ldp             fp, lr, [SP], #0x10
    // 0x12a1d64: ret
    //     0x12a1d64: ret             
  }
}

// class id: 2732, size: 0x18, field offset: 0x8
//   const constructor, 
class TextInputType extends Object {

  _Mint field_8;
  bool field_10;
  bool field_14;

  Map<String, dynamic> toJson(TextInputType) {
    // ** addr: 0x878970, size: 0x100
    // 0x878970: EnterFrame
    //     0x878970: stp             fp, lr, [SP, #-0x10]!
    //     0x878974: mov             fp, SP
    // 0x878978: AllocStack(0x20)
    //     0x878978: sub             SP, SP, #0x20
    // 0x87897c: SetupParameters(TextInputType this /* r1 => r0, fp-0x8 */)
    //     0x87897c: mov             x0, x1
    //     0x878980: stur            x1, [fp, #-8]
    // 0x878984: CheckStackOverflow
    //     0x878984: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x878988: cmp             SP, x16
    //     0x87898c: b.ls            #0x878a64
    // 0x878990: r1 = Null
    //     0x878990: mov             x1, NULL
    // 0x878994: r2 = 12
    //     0x878994: mov             x2, #0xc
    // 0x878998: r0 = AllocateArray()
    //     0x878998: bl              #0x13df928  ; AllocateArrayStub
    // 0x87899c: stur            x0, [fp, #-0x10]
    // 0x8789a0: r16 = "name"
    //     0x8789a0: ldr             x16, [PP, #0x6120]  ; [pp+0x6120] "name"
    // 0x8789a4: StoreField: r0->field_f = r16
    //     0x8789a4: stur            w16, [x0, #0xf]
    // 0x8789a8: r1 = Null
    //     0x8789a8: mov             x1, NULL
    // 0x8789ac: r2 = 4
    //     0x8789ac: mov             x2, #4
    // 0x8789b0: r0 = AllocateArray()
    //     0x8789b0: bl              #0x13df928  ; AllocateArrayStub
    // 0x8789b4: mov             x2, x0
    // 0x8789b8: r16 = "TextInputType."
    //     0x8789b8: ldr             x16, [PP, #0x6128]  ; [pp+0x6128] "TextInputType."
    // 0x8789bc: StoreField: r2->field_f = r16
    //     0x8789bc: stur            w16, [x2, #0xf]
    // 0x8789c0: ldur            x3, [fp, #-8]
    // 0x8789c4: LoadField: r4 = r3->field_7
    //     0x8789c4: ldur            x4, [x3, #7]
    // 0x8789c8: mov             x1, x4
    // 0x8789cc: r0 = 13
    //     0x8789cc: mov             x0, #0xd
    // 0x8789d0: cmp             x1, x0
    // 0x8789d4: b.hs            #0x878a6c
    // 0x8789d8: r0 = const [text, multiline, number, phone, datetime, emailAddress, url, visiblePassword, name, address, none, webSearch, twitter]
    //     0x8789d8: ldr             x0, [PP, #0x6130]  ; [pp+0x6130] List<String>(13)
    // 0x8789dc: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0x8789dc: add             x16, x0, x4, lsl #2
    //     0x8789e0: ldur            w1, [x16, #0xf]
    // 0x8789e4: DecompressPointer r1
    //     0x8789e4: add             x1, x1, HEAP, lsl #32
    // 0x8789e8: StoreField: r2->field_13 = r1
    //     0x8789e8: stur            w1, [x2, #0x13]
    // 0x8789ec: str             x2, [SP]
    // 0x8789f0: r0 = _interpolate()
    //     0x8789f0: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x8789f4: ldur            x1, [fp, #-0x10]
    // 0x8789f8: ArrayStore: r1[1] = r0  ; List_4
    //     0x8789f8: add             x25, x1, #0x13
    //     0x8789fc: str             w0, [x25]
    //     0x878a00: tbz             w0, #0, #0x878a1c
    //     0x878a04: ldurb           w16, [x1, #-1]
    //     0x878a08: ldurb           w17, [x0, #-1]
    //     0x878a0c: and             x16, x17, x16, lsr #2
    //     0x878a10: tst             x16, HEAP, lsr #32
    //     0x878a14: b.eq            #0x878a1c
    //     0x878a18: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x878a1c: ldur            x0, [fp, #-0x10]
    // 0x878a20: r16 = "signed"
    //     0x878a20: ldr             x16, [PP, #0x6138]  ; [pp+0x6138] "signed"
    // 0x878a24: ArrayStore: r0[0] = r16  ; List_4
    //     0x878a24: stur            w16, [x0, #0x17]
    // 0x878a28: ldur            x1, [fp, #-8]
    // 0x878a2c: LoadField: r2 = r1->field_f
    //     0x878a2c: ldur            w2, [x1, #0xf]
    // 0x878a30: DecompressPointer r2
    //     0x878a30: add             x2, x2, HEAP, lsl #32
    // 0x878a34: StoreField: r0->field_1b = r2
    //     0x878a34: stur            w2, [x0, #0x1b]
    // 0x878a38: r16 = "decimal"
    //     0x878a38: ldr             x16, [PP, #0x6140]  ; [pp+0x6140] "decimal"
    // 0x878a3c: StoreField: r0->field_1f = r16
    //     0x878a3c: stur            w16, [x0, #0x1f]
    // 0x878a40: LoadField: r2 = r1->field_13
    //     0x878a40: ldur            w2, [x1, #0x13]
    // 0x878a44: DecompressPointer r2
    //     0x878a44: add             x2, x2, HEAP, lsl #32
    // 0x878a48: StoreField: r0->field_23 = r2
    //     0x878a48: stur            w2, [x0, #0x23]
    // 0x878a4c: r16 = <String, dynamic>
    //     0x878a4c: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x878a50: stp             x0, x16, [SP]
    // 0x878a54: r0 = Map._fromLiteral()
    //     0x878a54: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x878a58: LeaveFrame
    //     0x878a58: mov             SP, fp
    //     0x878a5c: ldp             fp, lr, [SP], #0x10
    // 0x878a60: ret
    //     0x878a60: ret             
    // 0x878a64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x878a64: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x878a68: b               #0x878990
    // 0x878a6c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x878a6c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  Map<String, dynamic> toJson(TextInputType) {
    // ** addr: 0x878a88, size: 0x48
    // 0x878a88: EnterFrame
    //     0x878a88: stp             fp, lr, [SP, #-0x10]!
    //     0x878a8c: mov             fp, SP
    // 0x878a90: CheckStackOverflow
    //     0x878a90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x878a94: cmp             SP, x16
    //     0x878a98: b.ls            #0x878ab0
    // 0x878a9c: ldr             x1, [fp, #0x10]
    // 0x878aa0: r0 = toJson()
    //     0x878aa0: bl              #0x878970  ; [package:flutter/src/services/text_input.dart] TextInputType::toJson
    // 0x878aa4: LeaveFrame
    //     0x878aa4: mov             SP, fp
    //     0x878aa8: ldp             fp, lr, [SP], #0x10
    // 0x878aac: ret
    //     0x878aac: ret             
    // 0x878ab0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x878ab0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x878ab4: b               #0x878a9c
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x114ce78, size: 0x84
    // 0x114ce78: EnterFrame
    //     0x114ce78: stp             fp, lr, [SP, #-0x10]!
    //     0x114ce7c: mov             fp, SP
    // 0x114ce80: AllocStack(0x8)
    //     0x114ce80: sub             SP, SP, #8
    // 0x114ce84: CheckStackOverflow
    //     0x114ce84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x114ce88: cmp             SP, x16
    //     0x114ce8c: b.ls            #0x114cef4
    // 0x114ce90: ldr             x0, [fp, #0x10]
    // 0x114ce94: LoadField: r2 = r0->field_7
    //     0x114ce94: ldur            x2, [x0, #7]
    // 0x114ce98: LoadField: r3 = r0->field_f
    //     0x114ce98: ldur            w3, [x0, #0xf]
    // 0x114ce9c: DecompressPointer r3
    //     0x114ce9c: add             x3, x3, HEAP, lsl #32
    // 0x114cea0: LoadField: r4 = r0->field_13
    //     0x114cea0: ldur            w4, [x0, #0x13]
    // 0x114cea4: DecompressPointer r4
    //     0x114cea4: add             x4, x4, HEAP, lsl #32
    // 0x114cea8: r0 = BoxInt64Instr(r2)
    //     0x114cea8: sbfiz           x0, x2, #1, #0x1f
    //     0x114ceac: cmp             x2, x0, asr #1
    //     0x114ceb0: b.eq            #0x114cebc
    //     0x114ceb4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x114ceb8: stur            x2, [x0, #7]
    // 0x114cebc: str             x4, [SP]
    // 0x114cec0: mov             x1, x0
    // 0x114cec4: mov             x2, x3
    // 0x114cec8: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x114cec8: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x114cecc: r0 = hash()
    //     0x114cecc: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x114ced0: mov             x2, x0
    // 0x114ced4: r0 = BoxInt64Instr(r2)
    //     0x114ced4: sbfiz           x0, x2, #1, #0x1f
    //     0x114ced8: cmp             x2, x0, asr #1
    //     0x114cedc: b.eq            #0x114cee8
    //     0x114cee0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x114cee4: stur            x2, [x0, #7]
    // 0x114cee8: LeaveFrame
    //     0x114cee8: mov             SP, fp
    //     0x114ceec: ldp             fp, lr, [SP], #0x10
    // 0x114cef0: ret
    //     0x114cef0: ret             
    // 0x114cef4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x114cef4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x114cef8: b               #0x114ce90
  }
  _ ==(/* No info */) {
    // ** addr: 0x129afa4, size: 0x88
    // 0x129afa4: ldr             x1, [SP]
    // 0x129afa8: cmp             w1, NULL
    // 0x129afac: b.ne            #0x129afb8
    // 0x129afb0: r0 = false
    //     0x129afb0: add             x0, NULL, #0x30  ; false
    // 0x129afb4: ret
    //     0x129afb4: ret             
    // 0x129afb8: r2 = 60
    //     0x129afb8: mov             x2, #0x3c
    // 0x129afbc: branchIfSmi(r1, 0x129afc8)
    //     0x129afbc: tbz             w1, #0, #0x129afc8
    // 0x129afc0: r2 = LoadClassIdInstr(r1)
    //     0x129afc0: ldur            x2, [x1, #-1]
    //     0x129afc4: ubfx            x2, x2, #0xc, #0x14
    // 0x129afc8: cmp             x2, #0xaac
    // 0x129afcc: b.ne            #0x129b024
    // 0x129afd0: ldr             x2, [SP, #8]
    // 0x129afd4: LoadField: r3 = r1->field_7
    //     0x129afd4: ldur            x3, [x1, #7]
    // 0x129afd8: LoadField: r4 = r2->field_7
    //     0x129afd8: ldur            x4, [x2, #7]
    // 0x129afdc: cmp             x3, x4
    // 0x129afe0: b.ne            #0x129b024
    // 0x129afe4: LoadField: r3 = r1->field_f
    //     0x129afe4: ldur            w3, [x1, #0xf]
    // 0x129afe8: DecompressPointer r3
    //     0x129afe8: add             x3, x3, HEAP, lsl #32
    // 0x129afec: LoadField: r4 = r2->field_f
    //     0x129afec: ldur            w4, [x2, #0xf]
    // 0x129aff0: DecompressPointer r4
    //     0x129aff0: add             x4, x4, HEAP, lsl #32
    // 0x129aff4: cmp             w3, w4
    // 0x129aff8: b.ne            #0x129b024
    // 0x129affc: LoadField: r3 = r1->field_13
    //     0x129affc: ldur            w3, [x1, #0x13]
    // 0x129b000: DecompressPointer r3
    //     0x129b000: add             x3, x3, HEAP, lsl #32
    // 0x129b004: LoadField: r1 = r2->field_13
    //     0x129b004: ldur            w1, [x2, #0x13]
    // 0x129b008: DecompressPointer r1
    //     0x129b008: add             x1, x1, HEAP, lsl #32
    // 0x129b00c: cmp             w3, w1
    // 0x129b010: r16 = true
    //     0x129b010: add             x16, NULL, #0x20  ; true
    // 0x129b014: r17 = false
    //     0x129b014: add             x17, NULL, #0x30  ; false
    // 0x129b018: csel            x2, x16, x17, eq
    // 0x129b01c: mov             x0, x2
    // 0x129b020: b               #0x129b028
    // 0x129b024: r0 = false
    //     0x129b024: add             x0, NULL, #0x30  ; false
    // 0x129b028: ret
    //     0x129b028: ret             
  }
}

// class id: 4544, size: 0x8, field offset: 0x8
abstract class TextInputClient extends Object {
}

// class id: 4545, size: 0x8, field offset: 0x8
abstract class TextSelectionDelegate extends Object {
}

// class id: 4584, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class IOSSystemContextMenuItemData extends Object {

  get _ _json(/* No info */) {
    // ** addr: 0xe0f7a8, size: 0x118
    // 0xe0f7a8: EnterFrame
    //     0xe0f7a8: stp             fp, lr, [SP, #-0x10]!
    //     0xe0f7ac: mov             fp, SP
    // 0xe0f7b0: AllocStack(0x20)
    //     0xe0f7b0: sub             SP, SP, #0x20
    // 0xe0f7b4: SetupParameters(IOSSystemContextMenuItemData this /* r1 => r1, fp-0x8 */)
    //     0xe0f7b4: stur            x1, [fp, #-8]
    // 0xe0f7b8: CheckStackOverflow
    //     0xe0f7b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe0f7bc: cmp             SP, x16
    //     0xe0f7c0: b.ls            #0xe0f8b8
    // 0xe0f7c4: r16 = <String, dynamic>
    //     0xe0f7c4: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0xe0f7c8: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0xe0f7cc: stp             lr, x16, [SP]
    // 0xe0f7d0: r0 = Map._fromLiteral()
    //     0xe0f7d0: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xe0f7d4: stur            x0, [fp, #-0x10]
    // 0xe0f7d8: ldur            x16, [fp, #-8]
    // 0xe0f7dc: str             x16, [SP]
    // 0xe0f7e0: r0 = hashCode()
    //     0xe0f7e0: bl              #0x11447d4  ; [package:flutter/src/services/text_input.dart] IOSSystemContextMenuItemData::hashCode
    // 0xe0f7e4: ldur            x4, [fp, #-0x10]
    // 0xe0f7e8: r1 = LoadClassIdInstr(r4)
    //     0xe0f7e8: ldur            x1, [x4, #-1]
    //     0xe0f7ec: ubfx            x1, x1, #0xc, #0x14
    // 0xe0f7f0: mov             x3, x0
    // 0xe0f7f4: mov             x0, x1
    // 0xe0f7f8: mov             x1, x4
    // 0xe0f7fc: r2 = "callbackId"
    //     0xe0f7fc: add             x2, PP, #0x8e, lsl #12  ; [pp+0x8eef8] "callbackId"
    //     0xe0f800: ldr             x2, [x2, #0xef8]
    // 0xe0f804: r0 = GDT[cid_x0 + -0xd50]()
    //     0xe0f804: sub             lr, x0, #0xd50
    //     0xe0f808: ldr             lr, [x21, lr, lsl #3]
    //     0xe0f80c: blr             lr
    // 0xe0f810: ldur            x2, [fp, #-8]
    // 0xe0f814: r0 = LoadClassIdInstr(r2)
    //     0xe0f814: ldur            x0, [x2, #-1]
    //     0xe0f818: ubfx            x0, x0, #0xc, #0x14
    // 0xe0f81c: mov             x1, x2
    // 0xe0f820: r0 = GDT[cid_x0 + 0x49c6]()
    //     0xe0f820: mov             x17, #0x49c6
    //     0xe0f824: add             lr, x0, x17
    //     0xe0f828: ldr             lr, [x21, lr, lsl #3]
    //     0xe0f82c: blr             lr
    // 0xe0f830: cmp             w0, NULL
    // 0xe0f834: b.eq            #0xe0f860
    // 0xe0f838: ldur            x4, [fp, #-0x10]
    // 0xe0f83c: r1 = LoadClassIdInstr(r4)
    //     0xe0f83c: ldur            x1, [x4, #-1]
    //     0xe0f840: ubfx            x1, x1, #0xc, #0x14
    // 0xe0f844: mov             x3, x0
    // 0xe0f848: mov             x0, x1
    // 0xe0f84c: mov             x1, x4
    // 0xe0f850: r2 = "title"
    //     0xe0f850: ldr             x2, [PP, #0x6470]  ; [pp+0x6470] "title"
    // 0xe0f854: r0 = GDT[cid_x0 + -0xd50]()
    //     0xe0f854: sub             lr, x0, #0xd50
    //     0xe0f858: ldr             lr, [x21, lr, lsl #3]
    //     0xe0f85c: blr             lr
    // 0xe0f860: ldur            x1, [fp, #-8]
    // 0xe0f864: ldur            x2, [fp, #-0x10]
    // 0xe0f868: r0 = LoadClassIdInstr(r1)
    //     0xe0f868: ldur            x0, [x1, #-1]
    //     0xe0f86c: ubfx            x0, x0, #0xc, #0x14
    // 0xe0f870: r0 = GDT[cid_x0 + 0x7386]()
    //     0xe0f870: mov             x17, #0x7386
    //     0xe0f874: add             lr, x0, x17
    //     0xe0f878: ldr             lr, [x21, lr, lsl #3]
    //     0xe0f87c: blr             lr
    // 0xe0f880: ldur            x4, [fp, #-0x10]
    // 0xe0f884: r1 = LoadClassIdInstr(r4)
    //     0xe0f884: ldur            x1, [x4, #-1]
    //     0xe0f888: ubfx            x1, x1, #0xc, #0x14
    // 0xe0f88c: mov             x3, x0
    // 0xe0f890: mov             x0, x1
    // 0xe0f894: mov             x1, x4
    // 0xe0f898: r2 = "type"
    //     0xe0f898: ldr             x2, [PP, #0x3250]  ; [pp+0x3250] "type"
    // 0xe0f89c: r0 = GDT[cid_x0 + -0xd50]()
    //     0xe0f89c: sub             lr, x0, #0xd50
    //     0xe0f8a0: ldr             lr, [x21, lr, lsl #3]
    //     0xe0f8a4: blr             lr
    // 0xe0f8a8: ldur            x0, [fp, #-0x10]
    // 0xe0f8ac: LeaveFrame
    //     0xe0f8ac: mov             SP, fp
    //     0xe0f8b0: ldp             fp, lr, [SP], #0x10
    // 0xe0f8b4: ret
    //     0xe0f8b4: ret             
    // 0xe0f8b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe0f8b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe0f8bc: b               #0xe0f7c4
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x11447d4, size: 0x68
    // 0x11447d4: EnterFrame
    //     0x11447d4: stp             fp, lr, [SP, #-0x10]!
    //     0x11447d8: mov             fp, SP
    // 0x11447dc: AllocStack(0x8)
    //     0x11447dc: sub             SP, SP, #8
    // 0x11447e0: CheckStackOverflow
    //     0x11447e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11447e4: cmp             SP, x16
    //     0x11447e8: b.ls            #0x1144834
    // 0x11447ec: ldr             x1, [fp, #0x10]
    // 0x11447f0: r0 = LoadClassIdInstr(r1)
    //     0x11447f0: ldur            x0, [x1, #-1]
    //     0x11447f4: ubfx            x0, x0, #0xc, #0x14
    // 0x11447f8: r0 = GDT[cid_x0 + 0x49c6]()
    //     0x11447f8: mov             x17, #0x49c6
    //     0x11447fc: add             lr, x0, x17
    //     0x1144800: ldr             lr, [x21, lr, lsl #3]
    //     0x1144804: blr             lr
    // 0x1144808: r1 = LoadClassIdInstr(r0)
    //     0x1144808: ldur            x1, [x0, #-1]
    //     0x114480c: ubfx            x1, x1, #0xc, #0x14
    // 0x1144810: str             x0, [SP]
    // 0x1144814: mov             x0, x1
    // 0x1144818: r0 = GDT[cid_x0 + 0x70de]()
    //     0x1144818: mov             x17, #0x70de
    //     0x114481c: add             lr, x0, x17
    //     0x1144820: ldr             lr, [x21, lr, lsl #3]
    //     0x1144824: blr             lr
    // 0x1144828: LeaveFrame
    //     0x1144828: mov             SP, fp
    //     0x114482c: ldp             fp, lr, [SP], #0x10
    // 0x1144830: ret
    //     0x1144830: ret             
    // 0x1144834: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1144834: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1144838: b               #0x11447ec
  }
  _ ==(/* No info */) {
    // ** addr: 0x12838e0, size: 0x110
    // 0x12838e0: EnterFrame
    //     0x12838e0: stp             fp, lr, [SP, #-0x10]!
    //     0x12838e4: mov             fp, SP
    // 0x12838e8: AllocStack(0x18)
    //     0x12838e8: sub             SP, SP, #0x18
    // 0x12838ec: CheckStackOverflow
    //     0x12838ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12838f0: cmp             SP, x16
    //     0x12838f4: b.ls            #0x12839e8
    // 0x12838f8: ldr             x1, [fp, #0x10]
    // 0x12838fc: cmp             w1, NULL
    // 0x1283900: b.ne            #0x1283914
    // 0x1283904: r0 = false
    //     0x1283904: add             x0, NULL, #0x30  ; false
    // 0x1283908: LeaveFrame
    //     0x1283908: mov             SP, fp
    //     0x128390c: ldp             fp, lr, [SP], #0x10
    // 0x1283910: ret
    //     0x1283910: ret             
    // 0x1283914: ldr             x0, [fp, #0x18]
    // 0x1283918: cmp             w0, w1
    // 0x128391c: b.ne            #0x1283930
    // 0x1283920: r0 = true
    //     0x1283920: add             x0, NULL, #0x20  ; true
    // 0x1283924: LeaveFrame
    //     0x1283924: mov             SP, fp
    //     0x1283928: ldp             fp, lr, [SP], #0x10
    // 0x128392c: ret
    //     0x128392c: ret             
    // 0x1283930: stp             x0, x1, [SP]
    // 0x1283934: r0 = _haveSameRuntimeType()
    //     0x1283934: bl              #0x88249c  ; [dart:core] Object::_haveSameRuntimeType
    // 0x1283938: tbz             w0, #4, #0x128394c
    // 0x128393c: r0 = false
    //     0x128393c: add             x0, NULL, #0x30  ; false
    // 0x1283940: LeaveFrame
    //     0x1283940: mov             SP, fp
    //     0x1283944: ldp             fp, lr, [SP], #0x10
    // 0x1283948: ret
    //     0x1283948: ret             
    // 0x128394c: ldr             x1, [fp, #0x10]
    // 0x1283950: r0 = 60
    //     0x1283950: mov             x0, #0x3c
    // 0x1283954: branchIfSmi(r1, 0x1283960)
    //     0x1283954: tbz             w1, #0, #0x1283960
    // 0x1283958: r0 = LoadClassIdInstr(r1)
    //     0x1283958: ldur            x0, [x1, #-1]
    //     0x128395c: ubfx            x0, x0, #0xc, #0x14
    // 0x1283960: r17 = -4585
    //     0x1283960: mov             x17, #-0x11e9
    // 0x1283964: add             x16, x0, x17
    // 0x1283968: cmp             x16, #8
    // 0x128396c: b.hi            #0x12839d8
    // 0x1283970: ldr             x2, [fp, #0x18]
    // 0x1283974: r0 = LoadClassIdInstr(r1)
    //     0x1283974: ldur            x0, [x1, #-1]
    //     0x1283978: ubfx            x0, x0, #0xc, #0x14
    // 0x128397c: r0 = GDT[cid_x0 + 0x49c6]()
    //     0x128397c: mov             x17, #0x49c6
    //     0x1283980: add             lr, x0, x17
    //     0x1283984: ldr             lr, [x21, lr, lsl #3]
    //     0x1283988: blr             lr
    // 0x128398c: mov             x2, x0
    // 0x1283990: ldr             x1, [fp, #0x18]
    // 0x1283994: stur            x2, [fp, #-8]
    // 0x1283998: r0 = LoadClassIdInstr(r1)
    //     0x1283998: ldur            x0, [x1, #-1]
    //     0x128399c: ubfx            x0, x0, #0xc, #0x14
    // 0x12839a0: r0 = GDT[cid_x0 + 0x49c6]()
    //     0x12839a0: mov             x17, #0x49c6
    //     0x12839a4: add             lr, x0, x17
    //     0x12839a8: ldr             lr, [x21, lr, lsl #3]
    //     0x12839ac: blr             lr
    // 0x12839b0: mov             x1, x0
    // 0x12839b4: ldur            x0, [fp, #-8]
    // 0x12839b8: r2 = LoadClassIdInstr(r0)
    //     0x12839b8: ldur            x2, [x0, #-1]
    //     0x12839bc: ubfx            x2, x2, #0xc, #0x14
    // 0x12839c0: stp             x1, x0, [SP]
    // 0x12839c4: mov             x0, x2
    // 0x12839c8: mov             lr, x0
    // 0x12839cc: ldr             lr, [x21, lr, lsl #3]
    // 0x12839d0: blr             lr
    // 0x12839d4: b               #0x12839dc
    // 0x12839d8: r0 = false
    //     0x12839d8: add             x0, NULL, #0x30  ; false
    // 0x12839dc: LeaveFrame
    //     0x12839dc: mov             SP, fp
    //     0x12839e0: ldp             fp, lr, [SP], #0x10
    // 0x12839e4: ret
    //     0x12839e4: ret             
    // 0x12839e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12839e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12839ec: b               #0x12838f8
  }
}

// class id: 4585, size: 0x8, field offset: 0x8
//   const constructor, 
class IOSSystemContextMenuItemDataLiveText extends IOSSystemContextMenuItemData {

  get _ _jsonType(/* No info */) {
    // ** addr: 0x112e2e8, size: 0xc
    // 0x112e2e8: r0 = "captureTextFromCamera"
    //     0x112e2e8: add             x0, PP, #0xa3, lsl #12  ; [pp+0xa3d90] "captureTextFromCamera"
    //     0x112e2ec: ldr             x0, [x0, #0xd90]
    // 0x112e2f0: ret
    //     0x112e2f0: ret             
  }
}

// class id: 4586, size: 0x8, field offset: 0x8
//   const constructor, 
class IOSSystemContextMenuItemDataSelectAll extends IOSSystemContextMenuItemData {

  get _ _jsonType(/* No info */) {
    // ** addr: 0x112e2dc, size: 0xc
    // 0x112e2dc: r0 = "selectAll"
    //     0x112e2dc: add             x0, PP, #0xa3, lsl #12  ; [pp+0xa3d70] "selectAll"
    //     0x112e2e0: ldr             x0, [x0, #0xd70]
    // 0x112e2e4: ret
    //     0x112e2e4: ret             
  }
}

// class id: 4587, size: 0x8, field offset: 0x8
//   const constructor, 
class IOSSystemContextMenuItemDataPaste extends IOSSystemContextMenuItemData {

  get _ _jsonType(/* No info */) {
    // ** addr: 0x112e2d0, size: 0xc
    // 0x112e2d0: r0 = "paste"
    //     0x112e2d0: add             x0, PP, #0xa3, lsl #12  ; [pp+0xa3d80] "paste"
    //     0x112e2d4: ldr             x0, [x0, #0xd80]
    // 0x112e2d8: ret
    //     0x112e2d8: ret             
  }
}

// class id: 4588, size: 0x8, field offset: 0x8
//   const constructor, 
class IOSSystemContextMenuItemDataCut extends IOSSystemContextMenuItemData {

  get _ _jsonType(/* No info */) {
    // ** addr: 0x112e2c4, size: 0xc
    // 0x112e2c4: r0 = "cut"
    //     0x112e2c4: add             x0, PP, #0xa3, lsl #12  ; [pp+0xa3d78] "cut"
    //     0x112e2c8: ldr             x0, [x0, #0xd78]
    // 0x112e2cc: ret
    //     0x112e2cc: ret             
  }
}

// class id: 4589, size: 0x8, field offset: 0x8
//   const constructor, 
class IOSSystemContextMenuItemDataCopy extends IOSSystemContextMenuItemData {

  get _ _jsonType(/* No info */) {
    // ** addr: 0x112e2b8, size: 0xc
    // 0x112e2b8: r0 = "copy"
    //     0x112e2b8: add             x0, PP, #0x85, lsl #12  ; [pp+0x85a30] "copy"
    //     0x112e2bc: ldr             x0, [x0, #0xa30]
    // 0x112e2c0: ret
    //     0x112e2c0: ret             
  }
}

// class id: 4591, size: 0xc, field offset: 0x8
//   const constructor, 
class IOSSystemContextMenuItemDataShare extends _MixinApplication133&IOSSystemContextMenuItemData&Diagnosticable {

  get _ _jsonType(/* No info */) {
    // ** addr: 0x112e2ac, size: 0xc
    // 0x112e2ac: r0 = "share"
    //     0x112e2ac: add             x0, PP, #0x92, lsl #12  ; [pp+0x92ae8] "share"
    //     0x112e2b0: ldr             x0, [x0, #0xae8]
    // 0x112e2b4: ret
    //     0x112e2b4: ret             
  }
}

// class id: 4592, size: 0xc, field offset: 0x8
//   const constructor, 
class IOSSystemContextMenuItemDataSearchWeb extends _MixinApplication133&IOSSystemContextMenuItemData&Diagnosticable {

  get _ _jsonType(/* No info */) {
    // ** addr: 0x112e2a0, size: 0xc
    // 0x112e2a0: r0 = "searchWeb"
    //     0x112e2a0: add             x0, PP, #0xa3, lsl #12  ; [pp+0xa3d88] "searchWeb"
    //     0x112e2a4: ldr             x0, [x0, #0xd88]
    // 0x112e2a8: ret
    //     0x112e2a8: ret             
  }
}

// class id: 4593, size: 0xc, field offset: 0x8
//   const constructor, 
class IOSSystemContextMenuItemDataLookUp extends _MixinApplication133&IOSSystemContextMenuItemData&Diagnosticable {

  get _ _jsonType(/* No info */) {
    // ** addr: 0x112e294, size: 0xc
    // 0x112e294: r0 = "lookUp"
    //     0x112e294: add             x0, PP, #0xa3, lsl #12  ; [pp+0xa3d68] "lookUp"
    //     0x112e298: ldr             x0, [x0, #0xd68]
    // 0x112e29c: ret
    //     0x112e29c: ret             
  }
}

// class id: 4597, size: 0x20, field offset: 0x8
class SystemContextMenuController extends _MixinApplication132&Object&SystemContextMenuClient&Diagnosticable {

  _ handleCustomContextMenuAction(/* No info */) {
    // ** addr: 0x87b800, size: 0x80
    // 0x87b800: EnterFrame
    //     0x87b800: stp             fp, lr, [SP, #-0x10]!
    //     0x87b804: mov             fp, SP
    // 0x87b808: AllocStack(0x10)
    //     0x87b808: sub             SP, SP, #0x10
    // 0x87b80c: CheckStackOverflow
    //     0x87b80c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87b810: cmp             SP, x16
    //     0x87b814: b.ls            #0x87b878
    // 0x87b818: LoadField: r0 = r1->field_b
    //     0x87b818: ldur            w0, [x1, #0xb]
    // 0x87b81c: DecompressPointer r0
    //     0x87b81c: add             x0, x0, HEAP, lsl #32
    // 0x87b820: mov             x1, x0
    // 0x87b824: stur            x0, [fp, #-8]
    // 0x87b828: r0 = _getValueOrData()
    //     0x87b828: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x87b82c: mov             x1, x0
    // 0x87b830: ldur            x0, [fp, #-8]
    // 0x87b834: LoadField: r2 = r0->field_f
    //     0x87b834: ldur            w2, [x0, #0xf]
    // 0x87b838: DecompressPointer r2
    //     0x87b838: add             x2, x2, HEAP, lsl #32
    // 0x87b83c: cmp             w2, w1
    // 0x87b840: b.ne            #0x87b84c
    // 0x87b844: r0 = Null
    //     0x87b844: mov             x0, NULL
    // 0x87b848: b               #0x87b850
    // 0x87b84c: mov             x0, x1
    // 0x87b850: cmp             w0, NULL
    // 0x87b854: b.eq            #0x87b868
    // 0x87b858: str             x0, [SP]
    // 0x87b85c: ClosureCall
    //     0x87b85c: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x87b860: ldur            x2, [x0, #0x1f]
    //     0x87b864: blr             x2
    // 0x87b868: r0 = Null
    //     0x87b868: mov             x0, NULL
    // 0x87b86c: LeaveFrame
    //     0x87b86c: mov             SP, fp
    //     0x87b870: ldp             fp, lr, [SP], #0x10
    // 0x87b874: ret
    //     0x87b874: ret             
    // 0x87b878: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87b878: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87b87c: b               #0x87b818
  }
  _ handleSystemHide(/* No info */) {
    // ** addr: 0x87b880, size: 0xc8
    // 0x87b880: EnterFrame
    //     0x87b880: stp             fp, lr, [SP, #-0x10]!
    //     0x87b884: mov             fp, SP
    // 0x87b888: AllocStack(0x10)
    //     0x87b888: sub             SP, SP, #0x10
    // 0x87b88c: SetupParameters(SystemContextMenuController this /* r1 => r0, fp-0x8 */)
    //     0x87b88c: mov             x0, x1
    //     0x87b890: stur            x1, [fp, #-8]
    // 0x87b894: CheckStackOverflow
    //     0x87b894: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87b898: cmp             SP, x16
    //     0x87b89c: b.ls            #0x87b93c
    // 0x87b8a0: LoadField: r1 = r0->field_1b
    //     0x87b8a0: ldur            w1, [x0, #0x1b]
    // 0x87b8a4: DecompressPointer r1
    //     0x87b8a4: add             x1, x1, HEAP, lsl #32
    // 0x87b8a8: tbz             w1, #4, #0x87b92c
    // 0x87b8ac: r1 = LoadStaticField(0x680)
    //     0x87b8ac: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x87b8b0: ldr             x1, [x1, #0xd00]
    // 0x87b8b4: cmp             w0, w1
    // 0x87b8b8: b.ne            #0x87b92c
    // 0x87b8bc: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x87b8bc: ldur            w2, [x0, #0x17]
    // 0x87b8c0: DecompressPointer r2
    //     0x87b8c0: add             x2, x2, HEAP, lsl #32
    // 0x87b8c4: eor             x3, x2, #0x10
    // 0x87b8c8: tbnz            w3, #4, #0x87b92c
    // 0x87b8cc: cmp             w1, w0
    // 0x87b8d0: b.ne            #0x87b8e0
    // 0x87b8d4: r2 = Null
    //     0x87b8d4: mov             x2, NULL
    // 0x87b8d8: StoreStaticField(0x680, r2)
    //     0x87b8d8: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x87b8dc: str             x2, [x1, #0xd00]
    // 0x87b8e0: r1 = true
    //     0x87b8e0: add             x1, NULL, #0x20  ; true
    // 0x87b8e4: ArrayStore: r0[0] = r1  ; List_4
    //     0x87b8e4: stur            w1, [x0, #0x17]
    // 0x87b8e8: LoadField: r1 = r0->field_b
    //     0x87b8e8: ldur            w1, [x0, #0xb]
    // 0x87b8ec: DecompressPointer r1
    //     0x87b8ec: add             x1, x1, HEAP, lsl #32
    // 0x87b8f0: r0 = clear()
    //     0x87b8f0: bl              #0xa11274  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0x87b8f4: ldur            x0, [fp, #-8]
    // 0x87b8f8: LoadField: r1 = r0->field_7
    //     0x87b8f8: ldur            w1, [x0, #7]
    // 0x87b8fc: DecompressPointer r1
    //     0x87b8fc: add             x1, x1, HEAP, lsl #32
    // 0x87b900: cmp             w1, NULL
    // 0x87b904: b.eq            #0x87b944
    // 0x87b908: str             x1, [SP]
    // 0x87b90c: mov             x0, x1
    // 0x87b910: ClosureCall
    //     0x87b910: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x87b914: ldur            x2, [x0, #0x1f]
    //     0x87b918: blr             x2
    // 0x87b91c: r0 = Null
    //     0x87b91c: mov             x0, NULL
    // 0x87b920: LeaveFrame
    //     0x87b920: mov             SP, fp
    //     0x87b924: ldp             fp, lr, [SP], #0x10
    // 0x87b928: ret
    //     0x87b928: ret             
    // 0x87b92c: r0 = Null
    //     0x87b92c: mov             x0, NULL
    // 0x87b930: LeaveFrame
    //     0x87b930: mov             SP, fp
    //     0x87b934: ldp             fp, lr, [SP], #0x10
    // 0x87b938: ret
    //     0x87b938: ret             
    // 0x87b93c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87b93c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87b940: b               #0x87b8a0
    // 0x87b944: r0 = NullErrorSharedWithoutFPURegs()
    //     0x87b944: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ showWithItems(/* No info */) {
    // ** addr: 0xe0f234, size: 0x544
    // 0xe0f234: EnterFrame
    //     0xe0f234: stp             fp, lr, [SP, #-0x10]!
    //     0xe0f238: mov             fp, SP
    // 0xe0f23c: AllocStack(0x48)
    //     0xe0f23c: sub             SP, SP, #0x48
    // 0xe0f240: SetupParameters(SystemContextMenuController this /* r1 => r3, fp-0x10 */, dynamic _ /* r3 => r1, fp-0x18 */)
    //     0xe0f240: stur            x1, [fp, #-8]
    //     0xe0f244: mov             x16, x3
    //     0xe0f248: mov             x3, x1
    //     0xe0f24c: mov             x1, x16
    //     0xe0f250: stur            x2, [fp, #-0x10]
    //     0xe0f254: stur            x1, [fp, #-0x18]
    // 0xe0f258: CheckStackOverflow
    //     0xe0f258: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe0f25c: cmp             SP, x16
    //     0xe0f260: b.ls            #0xe0f6f0
    // 0xe0f264: r0 = LoadStaticField(0x680)
    //     0xe0f264: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xe0f268: ldr             x0, [x0, #0xd00]
    // 0xe0f26c: cmp             w0, NULL
    // 0xe0f270: b.eq            #0xe0f334
    // 0xe0f274: ArrayLoad: r4 = r0[0]  ; List_4
    //     0xe0f274: ldur            w4, [x0, #0x17]
    // 0xe0f278: DecompressPointer r4
    //     0xe0f278: add             x4, x4, HEAP, lsl #32
    // 0xe0f27c: eor             x5, x4, #0x10
    // 0xe0f280: tbnz            w5, #4, #0xe0f334
    // 0xe0f284: LoadField: r4 = r0->field_f
    //     0xe0f284: ldur            w4, [x0, #0xf]
    // 0xe0f288: DecompressPointer r4
    //     0xe0f288: add             x4, x4, HEAP, lsl #32
    // 0xe0f28c: r0 = LoadClassIdInstr(r4)
    //     0xe0f28c: ldur            x0, [x4, #-1]
    //     0xe0f290: ubfx            x0, x0, #0xc, #0x14
    // 0xe0f294: stp             x2, x4, [SP]
    // 0xe0f298: mov             lr, x0
    // 0xe0f29c: ldr             lr, [x21, lr, lsl #3]
    // 0xe0f2a0: blr             lr
    // 0xe0f2a4: tbnz            w0, #4, #0xe0f334
    // 0xe0f2a8: r0 = LoadStaticField(0x680)
    //     0xe0f2a8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xe0f2ac: ldr             x0, [x0, #0xd00]
    // 0xe0f2b0: cmp             w0, NULL
    // 0xe0f2b4: b.eq            #0xe0f6f8
    // 0xe0f2b8: LoadField: r1 = r0->field_13
    //     0xe0f2b8: ldur            w1, [x0, #0x13]
    // 0xe0f2bc: DecompressPointer r1
    //     0xe0f2bc: add             x1, x1, HEAP, lsl #32
    // 0xe0f2c0: r16 = <IOSSystemContextMenuItemData>
    //     0xe0f2c0: add             x16, PP, #0x8e, lsl #12  ; [pp+0x8eea0] TypeArguments: <IOSSystemContextMenuItemData>
    //     0xe0f2c4: ldr             x16, [x16, #0xea0]
    // 0xe0f2c8: stp             x1, x16, [SP, #8]
    // 0xe0f2cc: ldur            x16, [fp, #-0x18]
    // 0xe0f2d0: str             x16, [SP]
    // 0xe0f2d4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xe0f2d4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xe0f2d8: r0 = listEquals()
    //     0xe0f2d8: bl              #0x8595b0  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0xe0f2dc: tbnz            w0, #4, #0xe0f334
    // 0xe0f2e0: r1 = <void?>
    //     0xe0f2e0: ldr             x1, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xe0f2e4: r0 = _Future()
    //     0xe0f2e4: bl              #0x7f5dd4  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0xe0f2e8: stur            x0, [fp, #-0x20]
    // 0xe0f2ec: StoreField: r0->field_b = rZR
    //     0xe0f2ec: stur            xzr, [x0, #0xb]
    // 0xe0f2f0: r0 = LoadStaticField(0x364)
    //     0xe0f2f0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xe0f2f4: ldr             x0, [x0, #0x6c8]
    // 0xe0f2f8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xe0f2fc: cmp             w0, w16
    // 0xe0f300: b.ne            #0xe0f30c
    // 0xe0f304: r2 = _current
    //     0xe0f304: ldr             x2, [PP, #0x2c0]  ; [pp+0x2c0] Field <Zone._current@5048458>: static late (offset: 0x364)
    // 0xe0f308: r0 = InitLateStaticField()
    //     0xe0f308: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0xe0f30c: mov             x1, x0
    // 0xe0f310: ldur            x0, [fp, #-0x20]
    // 0xe0f314: StoreField: r0->field_13 = r1
    //     0xe0f314: stur            w1, [x0, #0x13]
    // 0xe0f318: mov             x1, x0
    // 0xe0f31c: r2 = Null
    //     0xe0f31c: mov             x2, NULL
    // 0xe0f320: r0 = _asyncComplete()
    //     0xe0f320: bl              #0x7eee44  ; [dart:async] _Future::_asyncComplete
    // 0xe0f324: ldur            x0, [fp, #-0x20]
    // 0xe0f328: LeaveFrame
    //     0xe0f328: mov             SP, fp
    //     0xe0f32c: ldp             fp, lr, [SP], #0x10
    // 0xe0f330: ret
    //     0xe0f330: ret             
    // 0xe0f334: ldur            x3, [fp, #-8]
    // 0xe0f338: ldur            x2, [fp, #-0x18]
    // 0xe0f33c: r1 = LoadStaticField(0x7bc)
    //     0xe0f33c: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0xe0f340: ldr             x1, [x1, #0xf78]
    // 0xe0f344: cmp             w1, NULL
    // 0xe0f348: b.eq            #0xe0f6fc
    // 0xe0f34c: mov             x0, x3
    // 0xe0f350: StoreField: r1->field_a7 = r0
    //     0xe0f350: stur            w0, [x1, #0xa7]
    //     0xe0f354: ldurb           w16, [x1, #-1]
    //     0xe0f358: ldurb           w17, [x0, #-1]
    //     0xe0f35c: and             x16, x17, x16, lsr #2
    //     0xe0f360: tst             x16, HEAP, lsr #32
    //     0xe0f364: b.eq            #0xe0f36c
    //     0xe0f368: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xe0f36c: LoadField: r1 = r3->field_b
    //     0xe0f36c: ldur            w1, [x3, #0xb]
    // 0xe0f370: DecompressPointer r1
    //     0xe0f370: add             x1, x1, HEAP, lsl #32
    // 0xe0f374: r0 = clear()
    //     0xe0f374: bl              #0xa11274  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0xe0f378: ldur            x0, [fp, #-0x18]
    // 0xe0f37c: LoadField: r1 = r0->field_b
    //     0xe0f37c: ldur            w1, [x0, #0xb]
    // 0xe0f380: r2 = LoadInt32Instr(r1)
    //     0xe0f380: sbfx            x2, x1, #1, #0x1f
    // 0xe0f384: r1 = 0
    //     0xe0f384: mov             x1, #0
    // 0xe0f388: CheckStackOverflow
    //     0xe0f388: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe0f38c: cmp             SP, x16
    //     0xe0f390: b.ls            #0xe0f700
    // 0xe0f394: cmp             x1, x2
    // 0xe0f398: b.ge            #0xe0f3a8
    // 0xe0f39c: add             x3, x1, #1
    // 0xe0f3a0: mov             x1, x3
    // 0xe0f3a4: b               #0xe0f388
    // 0xe0f3a8: r1 = Function '<anonymous closure>':.
    //     0xe0f3a8: add             x1, PP, #0x8e, lsl #12  ; [pp+0x8eec8] AnonymousClosure: (0xe0f778), in [package:flutter/src/services/text_input.dart] SystemContextMenuController::showWithItems (0xe0f234)
    //     0xe0f3ac: ldr             x1, [x1, #0xec8]
    // 0xe0f3b0: r2 = Null
    //     0xe0f3b0: mov             x2, NULL
    // 0xe0f3b4: r0 = AllocateClosure()
    //     0xe0f3b4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xe0f3b8: r16 = <Map<String, dynamic>>
    //     0xe0f3b8: ldr             x16, [PP, #0xb0]  ; [pp+0xb0] TypeArguments: <Map<String, dynamic>>
    // 0xe0f3bc: ldur            lr, [fp, #-0x18]
    // 0xe0f3c0: stp             lr, x16, [SP, #8]
    // 0xe0f3c4: str             x0, [SP]
    // 0xe0f3c8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xe0f3c8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xe0f3cc: r0 = map()
    //     0xe0f3cc: bl              #0xba574c  ; [dart:collection] ListBase::map
    // 0xe0f3d0: mov             x3, x0
    // 0xe0f3d4: stur            x3, [fp, #-0x28]
    // 0xe0f3d8: LoadField: r4 = r3->field_7
    //     0xe0f3d8: ldur            w4, [x3, #7]
    // 0xe0f3dc: DecompressPointer r4
    //     0xe0f3dc: add             x4, x4, HEAP, lsl #32
    // 0xe0f3e0: mov             x0, x3
    // 0xe0f3e4: stur            x4, [fp, #-0x20]
    // 0xe0f3e8: r2 = Null
    //     0xe0f3e8: mov             x2, NULL
    // 0xe0f3ec: r1 = Null
    //     0xe0f3ec: mov             x1, NULL
    // 0xe0f3f0: cmp             w0, NULL
    // 0xe0f3f4: b.eq            #0xe0f48c
    // 0xe0f3f8: branchIfSmi(r0, 0xe0f48c)
    //     0xe0f3f8: tbz             w0, #0, #0xe0f48c
    // 0xe0f3fc: r3 = LoadClassIdInstr(r0)
    //     0xe0f3fc: ldur            x3, [x0, #-1]
    //     0xe0f400: ubfx            x3, x3, #0xc, #0x14
    // 0xe0f404: r17 = 7724
    //     0xe0f404: mov             x17, #0x1e2c
    // 0xe0f408: cmp             x3, x17
    // 0xe0f40c: b.eq            #0xe0f494
    // 0xe0f410: r4 = LoadClassIdInstr(r0)
    //     0xe0f410: ldur            x4, [x0, #-1]
    //     0xe0f414: ubfx            x4, x4, #0xc, #0x14
    // 0xe0f418: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0xe0f41c: ldr             x3, [x3, #0x18]
    // 0xe0f420: ldr             x3, [x3, x4, lsl #3]
    // 0xe0f424: LoadField: r3 = r3->field_2b
    //     0xe0f424: ldur            w3, [x3, #0x2b]
    // 0xe0f428: DecompressPointer r3
    //     0xe0f428: add             x3, x3, HEAP, lsl #32
    // 0xe0f42c: cmp             w3, NULL
    // 0xe0f430: b.eq            #0xe0f48c
    // 0xe0f434: LoadField: r3 = r3->field_f
    //     0xe0f434: ldur            w3, [x3, #0xf]
    // 0xe0f438: lsr             x3, x3, #3
    // 0xe0f43c: r17 = 7724
    //     0xe0f43c: mov             x17, #0x1e2c
    // 0xe0f440: cmp             x3, x17
    // 0xe0f444: b.eq            #0xe0f494
    // 0xe0f448: r3 = SubtypeTestCache
    //     0xe0f448: add             x3, PP, #0x8e, lsl #12  ; [pp+0x8eed0] SubtypeTestCache
    //     0xe0f44c: ldr             x3, [x3, #0xed0]
    // 0xe0f450: r30 = Subtype1TestCacheStub
    //     0xe0f450: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0xe0f454: LoadField: r30 = r30->field_7
    //     0xe0f454: ldur            lr, [lr, #7]
    // 0xe0f458: blr             lr
    // 0xe0f45c: cmp             w7, NULL
    // 0xe0f460: b.eq            #0xe0f46c
    // 0xe0f464: tbnz            w7, #4, #0xe0f48c
    // 0xe0f468: b               #0xe0f494
    // 0xe0f46c: r8 = EfficientLengthIterable
    //     0xe0f46c: add             x8, PP, #0x8e, lsl #12  ; [pp+0x8eed8] Type: EfficientLengthIterable
    //     0xe0f470: ldr             x8, [x8, #0xed8]
    // 0xe0f474: r3 = SubtypeTestCache
    //     0xe0f474: add             x3, PP, #0x8e, lsl #12  ; [pp+0x8eee0] SubtypeTestCache
    //     0xe0f478: ldr             x3, [x3, #0xee0]
    // 0xe0f47c: r30 = InstanceOfStub
    //     0xe0f47c: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0xe0f480: LoadField: r30 = r30->field_7
    //     0xe0f480: ldur            lr, [lr, #7]
    // 0xe0f484: blr             lr
    // 0xe0f488: b               #0xe0f498
    // 0xe0f48c: r0 = false
    //     0xe0f48c: add             x0, NULL, #0x30  ; false
    // 0xe0f490: b               #0xe0f498
    // 0xe0f494: r0 = true
    //     0xe0f494: add             x0, NULL, #0x20  ; true
    // 0xe0f498: tbnz            w0, #4, #0xe0f4b0
    // 0xe0f49c: ldur            x1, [fp, #-0x20]
    // 0xe0f4a0: ldur            x2, [fp, #-0x28]
    // 0xe0f4a4: r0 = _GrowableList._ofEfficientLengthIterable()
    //     0xe0f4a4: bl              #0x7d732c  ; [dart:core] _GrowableList::_GrowableList._ofEfficientLengthIterable
    // 0xe0f4a8: mov             x5, x0
    // 0xe0f4ac: b               #0xe0f4c0
    // 0xe0f4b0: ldur            x1, [fp, #-0x20]
    // 0xe0f4b4: ldur            x2, [fp, #-0x28]
    // 0xe0f4b8: r0 = _GrowableList._ofOther()
    //     0xe0f4b8: bl              #0x7d94b4  ; [dart:core] _GrowableList::_GrowableList._ofOther
    // 0xe0f4bc: mov             x5, x0
    // 0xe0f4c0: ldur            x1, [fp, #-8]
    // 0xe0f4c4: ldur            x3, [fp, #-0x10]
    // 0xe0f4c8: r4 = false
    //     0xe0f4c8: add             x4, NULL, #0x30  ; false
    // 0xe0f4cc: mov             x0, x3
    // 0xe0f4d0: stur            x5, [fp, #-0x20]
    // 0xe0f4d4: StoreField: r1->field_f = r0
    //     0xe0f4d4: stur            w0, [x1, #0xf]
    //     0xe0f4d8: ldurb           w16, [x1, #-1]
    //     0xe0f4dc: ldurb           w17, [x0, #-1]
    //     0xe0f4e0: and             x16, x17, x16, lsr #2
    //     0xe0f4e4: tst             x16, HEAP, lsr #32
    //     0xe0f4e8: b.eq            #0xe0f4f0
    //     0xe0f4ec: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xe0f4f0: ldur            x0, [fp, #-0x18]
    // 0xe0f4f4: StoreField: r1->field_13 = r0
    //     0xe0f4f4: stur            w0, [x1, #0x13]
    //     0xe0f4f8: ldurb           w16, [x1, #-1]
    //     0xe0f4fc: ldurb           w17, [x0, #-1]
    //     0xe0f500: and             x16, x17, x16, lsr #2
    //     0xe0f504: tst             x16, HEAP, lsr #32
    //     0xe0f508: b.eq            #0xe0f510
    //     0xe0f50c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xe0f510: mov             x2, x1
    // 0xe0f514: StoreStaticField(0x680, r2)
    //     0xe0f514: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xe0f518: str             x2, [x0, #0xd00]
    // 0xe0f51c: ArrayStore: r1[0] = r4  ; List_4
    //     0xe0f51c: stur            w4, [x1, #0x17]
    // 0xe0f520: r1 = Null
    //     0xe0f520: mov             x1, NULL
    // 0xe0f524: r2 = 8
    //     0xe0f524: mov             x2, #8
    // 0xe0f528: r0 = AllocateArray()
    //     0xe0f528: bl              #0x13df928  ; AllocateArrayStub
    // 0xe0f52c: stur            x0, [fp, #-8]
    // 0xe0f530: r16 = "targetRect"
    //     0xe0f530: add             x16, PP, #0x8e, lsl #12  ; [pp+0x8eee8] "targetRect"
    //     0xe0f534: ldr             x16, [x16, #0xee8]
    // 0xe0f538: StoreField: r0->field_f = r16
    //     0xe0f538: stur            w16, [x0, #0xf]
    // 0xe0f53c: r1 = Null
    //     0xe0f53c: mov             x1, NULL
    // 0xe0f540: r2 = 16
    //     0xe0f540: mov             x2, #0x10
    // 0xe0f544: r0 = AllocateArray()
    //     0xe0f544: bl              #0x13df928  ; AllocateArrayStub
    // 0xe0f548: r16 = "x"
    //     0xe0f548: ldr             x16, [PP, #0x5a48]  ; [pp+0x5a48] "x"
    // 0xe0f54c: StoreField: r0->field_f = r16
    //     0xe0f54c: stur            w16, [x0, #0xf]
    // 0xe0f550: ldur            x1, [fp, #-0x10]
    // 0xe0f554: LoadField: d0 = r1->field_7
    //     0xe0f554: ldur            d0, [x1, #7]
    // 0xe0f558: r2 = inline_Allocate_Double()
    //     0xe0f558: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xe0f55c: add             x2, x2, #0x10
    //     0xe0f560: cmp             x3, x2
    //     0xe0f564: b.ls            #0xe0f708
    //     0xe0f568: str             x2, [THR, #0x60]  ; THR::top
    //     0xe0f56c: sub             x2, x2, #0xf
    //     0xe0f570: mov             x3, #0xe19c
    //     0xe0f574: movk            x3, #3, lsl #16
    //     0xe0f578: stur            x3, [x2, #-1]
    // 0xe0f57c: dmb             ishst
    // 0xe0f580: StoreField: r2->field_7 = d0
    //     0xe0f580: stur            d0, [x2, #7]
    // 0xe0f584: StoreField: r0->field_13 = r2
    //     0xe0f584: stur            w2, [x0, #0x13]
    // 0xe0f588: r16 = "y"
    //     0xe0f588: ldr             x16, [PP, #0x5a50]  ; [pp+0x5a50] "y"
    // 0xe0f58c: ArrayStore: r0[0] = r16  ; List_4
    //     0xe0f58c: stur            w16, [x0, #0x17]
    // 0xe0f590: LoadField: d1 = r1->field_f
    //     0xe0f590: ldur            d1, [x1, #0xf]
    // 0xe0f594: r2 = inline_Allocate_Double()
    //     0xe0f594: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xe0f598: add             x2, x2, #0x10
    //     0xe0f59c: cmp             x3, x2
    //     0xe0f5a0: b.ls            #0xe0f724
    //     0xe0f5a4: str             x2, [THR, #0x60]  ; THR::top
    //     0xe0f5a8: sub             x2, x2, #0xf
    //     0xe0f5ac: mov             x3, #0xe19c
    //     0xe0f5b0: movk            x3, #3, lsl #16
    //     0xe0f5b4: stur            x3, [x2, #-1]
    // 0xe0f5b8: dmb             ishst
    // 0xe0f5bc: StoreField: r2->field_7 = d1
    //     0xe0f5bc: stur            d1, [x2, #7]
    // 0xe0f5c0: StoreField: r0->field_1b = r2
    //     0xe0f5c0: stur            w2, [x0, #0x1b]
    // 0xe0f5c4: r16 = "width"
    //     0xe0f5c4: ldr             x16, [PP, #0x5a40]  ; [pp+0x5a40] "width"
    // 0xe0f5c8: StoreField: r0->field_1f = r16
    //     0xe0f5c8: stur            w16, [x0, #0x1f]
    // 0xe0f5cc: ArrayLoad: d2 = r1[0]  ; List_8
    //     0xe0f5cc: ldur            d2, [x1, #0x17]
    // 0xe0f5d0: fsub            d3, d2, d0
    // 0xe0f5d4: r2 = inline_Allocate_Double()
    //     0xe0f5d4: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xe0f5d8: add             x2, x2, #0x10
    //     0xe0f5dc: cmp             x3, x2
    //     0xe0f5e0: b.ls            #0xe0f740
    //     0xe0f5e4: str             x2, [THR, #0x60]  ; THR::top
    //     0xe0f5e8: sub             x2, x2, #0xf
    //     0xe0f5ec: mov             x3, #0xe19c
    //     0xe0f5f0: movk            x3, #3, lsl #16
    //     0xe0f5f4: stur            x3, [x2, #-1]
    // 0xe0f5f8: dmb             ishst
    // 0xe0f5fc: StoreField: r2->field_7 = d3
    //     0xe0f5fc: stur            d3, [x2, #7]
    // 0xe0f600: StoreField: r0->field_23 = r2
    //     0xe0f600: stur            w2, [x0, #0x23]
    // 0xe0f604: r16 = "height"
    //     0xe0f604: ldr             x16, [PP, #0x4ac8]  ; [pp+0x4ac8] "height"
    // 0xe0f608: StoreField: r0->field_27 = r16
    //     0xe0f608: stur            w16, [x0, #0x27]
    // 0xe0f60c: LoadField: d0 = r1->field_1f
    //     0xe0f60c: ldur            d0, [x1, #0x1f]
    // 0xe0f610: fsub            d2, d0, d1
    // 0xe0f614: r1 = inline_Allocate_Double()
    //     0xe0f614: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xe0f618: add             x1, x1, #0x10
    //     0xe0f61c: cmp             x2, x1
    //     0xe0f620: b.ls            #0xe0f75c
    //     0xe0f624: str             x1, [THR, #0x60]  ; THR::top
    //     0xe0f628: sub             x1, x1, #0xf
    //     0xe0f62c: mov             x2, #0xe19c
    //     0xe0f630: movk            x2, #3, lsl #16
    //     0xe0f634: stur            x2, [x1, #-1]
    // 0xe0f638: dmb             ishst
    // 0xe0f63c: StoreField: r1->field_7 = d2
    //     0xe0f63c: stur            d2, [x1, #7]
    // 0xe0f640: StoreField: r0->field_2b = r1
    //     0xe0f640: stur            w1, [x0, #0x2b]
    // 0xe0f644: r16 = <String, double>
    //     0xe0f644: add             x16, PP, #0x7d, lsl #12  ; [pp+0x7d660] TypeArguments: <String, double>
    //     0xe0f648: ldr             x16, [x16, #0x660]
    // 0xe0f64c: stp             x0, x16, [SP]
    // 0xe0f650: r0 = Map._fromLiteral()
    //     0xe0f650: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xe0f654: ldur            x1, [fp, #-8]
    // 0xe0f658: ArrayStore: r1[1] = r0  ; List_4
    //     0xe0f658: add             x25, x1, #0x13
    //     0xe0f65c: str             w0, [x25]
    //     0xe0f660: tbz             w0, #0, #0xe0f67c
    //     0xe0f664: ldurb           w16, [x1, #-1]
    //     0xe0f668: ldurb           w17, [x0, #-1]
    //     0xe0f66c: and             x16, x17, x16, lsr #2
    //     0xe0f670: tst             x16, HEAP, lsr #32
    //     0xe0f674: b.eq            #0xe0f67c
    //     0xe0f678: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xe0f67c: ldur            x2, [fp, #-8]
    // 0xe0f680: r16 = "items"
    //     0xe0f680: add             x16, PP, #0x8a, lsl #12  ; [pp+0x8aac8] "items"
    //     0xe0f684: ldr             x16, [x16, #0xac8]
    // 0xe0f688: ArrayStore: r2[0] = r16  ; List_4
    //     0xe0f688: stur            w16, [x2, #0x17]
    // 0xe0f68c: mov             x1, x2
    // 0xe0f690: ldur            x0, [fp, #-0x20]
    // 0xe0f694: ArrayStore: r1[3] = r0  ; List_4
    //     0xe0f694: add             x25, x1, #0x1b
    //     0xe0f698: str             w0, [x25]
    //     0xe0f69c: tbz             w0, #0, #0xe0f6b8
    //     0xe0f6a0: ldurb           w16, [x1, #-1]
    //     0xe0f6a4: ldurb           w17, [x0, #-1]
    //     0xe0f6a8: and             x16, x17, x16, lsr #2
    //     0xe0f6ac: tst             x16, HEAP, lsr #32
    //     0xe0f6b0: b.eq            #0xe0f6b8
    //     0xe0f6b4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xe0f6b8: r16 = <String, dynamic>
    //     0xe0f6b8: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0xe0f6bc: stp             x2, x16, [SP]
    // 0xe0f6c0: r0 = Map._fromLiteral()
    //     0xe0f6c0: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xe0f6c4: r16 = <void?>
    //     0xe0f6c4: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xe0f6c8: r30 = Instance_OptionalMethodChannel
    //     0xe0f6c8: ldr             lr, [PP, #0x1960]  ; [pp+0x1960] Obj!OptionalMethodChannel@129bec1
    // 0xe0f6cc: stp             lr, x16, [SP, #0x10]
    // 0xe0f6d0: r16 = "ContextMenu.showSystemContextMenu"
    //     0xe0f6d0: add             x16, PP, #0x8e, lsl #12  ; [pp+0x8eef0] "ContextMenu.showSystemContextMenu"
    //     0xe0f6d4: ldr             x16, [x16, #0xef0]
    // 0xe0f6d8: stp             x0, x16, [SP]
    // 0xe0f6dc: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xe0f6dc: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xe0f6e0: r0 = invokeMethod()
    //     0xe0f6e0: bl              #0x130ad0c  ; [package:flutter/src/services/platform_channel.dart] OptionalMethodChannel::invokeMethod
    // 0xe0f6e4: LeaveFrame
    //     0xe0f6e4: mov             SP, fp
    //     0xe0f6e8: ldp             fp, lr, [SP], #0x10
    // 0xe0f6ec: ret
    //     0xe0f6ec: ret             
    // 0xe0f6f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe0f6f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe0f6f4: b               #0xe0f264
    // 0xe0f6f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe0f6f8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xe0f6fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe0f6fc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xe0f700: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe0f700: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe0f704: b               #0xe0f394
    // 0xe0f708: SaveReg d0
    //     0xe0f708: str             q0, [SP, #-0x10]!
    // 0xe0f70c: stp             x0, x1, [SP, #-0x10]!
    // 0xe0f710: r0 = AllocateDouble()
    //     0xe0f710: bl              #0x13df878  ; AllocateDoubleStub
    // 0xe0f714: mov             x2, x0
    // 0xe0f718: ldp             x0, x1, [SP], #0x10
    // 0xe0f71c: RestoreReg d0
    //     0xe0f71c: ldr             q0, [SP], #0x10
    // 0xe0f720: b               #0xe0f580
    // 0xe0f724: stp             q0, q1, [SP, #-0x20]!
    // 0xe0f728: stp             x0, x1, [SP, #-0x10]!
    // 0xe0f72c: r0 = AllocateDouble()
    //     0xe0f72c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xe0f730: mov             x2, x0
    // 0xe0f734: ldp             x0, x1, [SP], #0x10
    // 0xe0f738: ldp             q0, q1, [SP], #0x20
    // 0xe0f73c: b               #0xe0f5bc
    // 0xe0f740: stp             q1, q3, [SP, #-0x20]!
    // 0xe0f744: stp             x0, x1, [SP, #-0x10]!
    // 0xe0f748: r0 = AllocateDouble()
    //     0xe0f748: bl              #0x13df878  ; AllocateDoubleStub
    // 0xe0f74c: mov             x2, x0
    // 0xe0f750: ldp             x0, x1, [SP], #0x10
    // 0xe0f754: ldp             q1, q3, [SP], #0x20
    // 0xe0f758: b               #0xe0f5fc
    // 0xe0f75c: SaveReg d2
    //     0xe0f75c: str             q2, [SP, #-0x10]!
    // 0xe0f760: SaveReg r0
    //     0xe0f760: str             x0, [SP, #-8]!
    // 0xe0f764: r0 = AllocateDouble()
    //     0xe0f764: bl              #0x13df878  ; AllocateDoubleStub
    // 0xe0f768: mov             x1, x0
    // 0xe0f76c: RestoreReg r0
    //     0xe0f76c: ldr             x0, [SP], #8
    // 0xe0f770: RestoreReg d2
    //     0xe0f770: ldr             q2, [SP], #0x10
    // 0xe0f774: b               #0xe0f63c
  }
  [closure] Map<String, dynamic> <anonymous closure>(dynamic, IOSSystemContextMenuItemData) {
    // ** addr: 0xe0f778, size: 0x30
    // 0xe0f778: EnterFrame
    //     0xe0f778: stp             fp, lr, [SP, #-0x10]!
    //     0xe0f77c: mov             fp, SP
    // 0xe0f780: CheckStackOverflow
    //     0xe0f780: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe0f784: cmp             SP, x16
    //     0xe0f788: b.ls            #0xe0f7a0
    // 0xe0f78c: ldr             x1, [fp, #0x10]
    // 0xe0f790: r0 = _json()
    //     0xe0f790: bl              #0xe0f7a8  ; [package:flutter/src/services/text_input.dart] IOSSystemContextMenuItemData::_json
    // 0xe0f794: LeaveFrame
    //     0xe0f794: mov             SP, fp
    //     0xe0f798: ldp             fp, lr, [SP], #0x10
    // 0xe0f79c: ret
    //     0xe0f79c: ret             
    // 0xe0f7a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe0f7a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe0f7a4: b               #0xe0f78c
  }
  _ SystemContextMenuController(/* No info */) {
    // ** addr: 0xf92dac, size: 0xd8
    // 0xf92dac: EnterFrame
    //     0xf92dac: stp             fp, lr, [SP, #-0x10]!
    //     0xf92db0: mov             fp, SP
    // 0xf92db4: AllocStack(0x20)
    //     0xf92db4: sub             SP, SP, #0x20
    // 0xf92db8: r0 = false
    //     0xf92db8: add             x0, NULL, #0x30  ; false
    // 0xf92dbc: stur            x1, [fp, #-8]
    // 0xf92dc0: mov             x16, x2
    // 0xf92dc4: mov             x2, x1
    // 0xf92dc8: mov             x1, x16
    // 0xf92dcc: stur            x1, [fp, #-0x10]
    // 0xf92dd0: CheckStackOverflow
    //     0xf92dd0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf92dd4: cmp             SP, x16
    //     0xf92dd8: b.ls            #0xf92e78
    // 0xf92ddc: ArrayStore: r2[0] = r0  ; List_4
    //     0xf92ddc: stur            w0, [x2, #0x17]
    // 0xf92de0: StoreField: r2->field_1b = r0
    //     0xf92de0: stur            w0, [x2, #0x1b]
    // 0xf92de4: r16 = <String, (dynamic this) => void?>
    //     0xf92de4: add             x16, PP, #0x8e, lsl #12  ; [pp+0x8ef20] TypeArguments: <String, (dynamic this) => void?>
    //     0xf92de8: ldr             x16, [x16, #0xf20]
    // 0xf92dec: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0xf92df0: stp             lr, x16, [SP]
    // 0xf92df4: r0 = Map._fromLiteral()
    //     0xf92df4: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xf92df8: ldur            x1, [fp, #-8]
    // 0xf92dfc: StoreField: r1->field_b = r0
    //     0xf92dfc: stur            w0, [x1, #0xb]
    //     0xf92e00: ldurb           w16, [x1, #-1]
    //     0xf92e04: ldurb           w17, [x0, #-1]
    //     0xf92e08: and             x16, x17, x16, lsr #2
    //     0xf92e0c: tst             x16, HEAP, lsr #32
    //     0xf92e10: b.eq            #0xf92e18
    //     0xf92e14: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf92e18: ldur            x0, [fp, #-0x10]
    // 0xf92e1c: StoreField: r1->field_7 = r0
    //     0xf92e1c: stur            w0, [x1, #7]
    //     0xf92e20: ldurb           w16, [x1, #-1]
    //     0xf92e24: ldurb           w17, [x0, #-1]
    //     0xf92e28: and             x16, x17, x16, lsr #2
    //     0xf92e2c: tst             x16, HEAP, lsr #32
    //     0xf92e30: b.eq            #0xf92e38
    //     0xf92e34: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf92e38: r2 = LoadStaticField(0x7bc)
    //     0xf92e38: ldr             x2, [THR, #0x78]  ; THR::field_table_values
    //     0xf92e3c: ldr             x2, [x2, #0xf78]
    // 0xf92e40: cmp             w2, NULL
    // 0xf92e44: b.eq            #0xf92e80
    // 0xf92e48: mov             x0, x1
    // 0xf92e4c: StoreField: r2->field_a7 = r0
    //     0xf92e4c: stur            w0, [x2, #0xa7]
    //     0xf92e50: ldurb           w16, [x2, #-1]
    //     0xf92e54: ldurb           w17, [x0, #-1]
    //     0xf92e58: and             x16, x17, x16, lsr #2
    //     0xf92e5c: tst             x16, HEAP, lsr #32
    //     0xf92e60: b.eq            #0xf92e68
    //     0xf92e64: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf92e68: r0 = Null
    //     0xf92e68: mov             x0, NULL
    // 0xf92e6c: LeaveFrame
    //     0xf92e6c: mov             SP, fp
    //     0xf92e70: ldp             fp, lr, [SP], #0x10
    // 0xf92e74: ret
    //     0xf92e74: ret             
    // 0xf92e78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf92e78: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf92e7c: b               #0xf92ddc
    // 0xf92e80: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf92e80: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10e70c4, size: 0x4c
    // 0x10e70c4: EnterFrame
    //     0x10e70c4: stp             fp, lr, [SP, #-0x10]!
    //     0x10e70c8: mov             fp, SP
    // 0x10e70cc: AllocStack(0x8)
    //     0x10e70cc: sub             SP, SP, #8
    // 0x10e70d0: SetupParameters(SystemContextMenuController this /* r1 => r0, fp-0x8 */)
    //     0x10e70d0: mov             x0, x1
    //     0x10e70d4: stur            x1, [fp, #-8]
    // 0x10e70d8: CheckStackOverflow
    //     0x10e70d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e70dc: cmp             SP, x16
    //     0x10e70e0: b.ls            #0x10e7108
    // 0x10e70e4: mov             x1, x0
    // 0x10e70e8: r0 = hide()
    //     0x10e70e8: bl              #0x10e7110  ; [package:flutter/src/services/text_input.dart] SystemContextMenuController::hide
    // 0x10e70ec: ldur            x2, [fp, #-8]
    // 0x10e70f0: r1 = true
    //     0x10e70f0: add             x1, NULL, #0x20  ; true
    // 0x10e70f4: StoreField: r2->field_1b = r1
    //     0x10e70f4: stur            w1, [x2, #0x1b]
    // 0x10e70f8: r0 = Null
    //     0x10e70f8: mov             x0, NULL
    // 0x10e70fc: LeaveFrame
    //     0x10e70fc: mov             SP, fp
    //     0x10e7100: ldp             fp, lr, [SP], #0x10
    // 0x10e7104: ret
    //     0x10e7104: ret             
    // 0x10e7108: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e7108: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e710c: b               #0x10e70e4
  }
  _ hide(/* No info */) async {
    // ** addr: 0x10e7110, size: 0xa4
    // 0x10e7110: EnterFrame
    //     0x10e7110: stp             fp, lr, [SP, #-0x10]!
    //     0x10e7114: mov             fp, SP
    // 0x10e7118: AllocStack(0x28)
    //     0x10e7118: sub             SP, SP, #0x28
    // 0x10e711c: SetupParameters(SystemContextMenuController this /* r1 => r1, fp-0x10 */)
    //     0x10e711c: stur            NULL, [fp, #-8]
    //     0x10e7120: stur            x1, [fp, #-0x10]
    // 0x10e7124: CheckStackOverflow
    //     0x10e7124: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e7128: cmp             SP, x16
    //     0x10e712c: b.ls            #0x10e71a8
    // 0x10e7130: InitAsync() -> Future<void?>
    //     0x10e7130: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0x10e7134: bl              #0x7f5e44  ; InitAsyncStub
    // 0x10e7138: r0 = LoadStaticField(0x680)
    //     0x10e7138: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x10e713c: ldr             x0, [x0, #0xd00]
    // 0x10e7140: ldur            x1, [fp, #-0x10]
    // 0x10e7144: cmp             w1, w0
    // 0x10e7148: b.eq            #0x10e7154
    // 0x10e714c: r0 = Null
    //     0x10e714c: mov             x0, NULL
    // 0x10e7150: r0 = ReturnAsyncNotFuture()
    //     0x10e7150: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x10e7154: r2 = Null
    //     0x10e7154: mov             x2, NULL
    // 0x10e7158: StoreStaticField(0x680, r2)
    //     0x10e7158: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x10e715c: str             x2, [x0, #0xd00]
    // 0x10e7160: r0 = LoadStaticField(0x7bc)
    //     0x10e7160: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x10e7164: ldr             x0, [x0, #0xf78]
    // 0x10e7168: cmp             w0, NULL
    // 0x10e716c: b.eq            #0x10e71b0
    // 0x10e7170: StoreField: r0->field_a7 = rNULL
    //     0x10e7170: stur            NULL, [x0, #0xa7]
    // 0x10e7174: LoadField: r0 = r1->field_b
    //     0x10e7174: ldur            w0, [x1, #0xb]
    // 0x10e7178: DecompressPointer r0
    //     0x10e7178: add             x0, x0, HEAP, lsl #32
    // 0x10e717c: mov             x1, x0
    // 0x10e7180: r0 = clear()
    //     0x10e7180: bl              #0xa11274  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0x10e7184: r16 = <void?>
    //     0x10e7184: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x10e7188: r30 = Instance_OptionalMethodChannel
    //     0x10e7188: ldr             lr, [PP, #0x1960]  ; [pp+0x1960] Obj!OptionalMethodChannel@129bec1
    // 0x10e718c: stp             lr, x16, [SP, #8]
    // 0x10e7190: r16 = "ContextMenu.hideSystemContextMenu"
    //     0x10e7190: add             x16, PP, #0x8e, lsl #12  ; [pp+0x8ef10] "ContextMenu.hideSystemContextMenu"
    //     0x10e7194: ldr             x16, [x16, #0xf10]
    // 0x10e7198: str             x16, [SP]
    // 0x10e719c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x10e719c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x10e71a0: r0 = invokeMethod()
    //     0x10e71a0: bl              #0x130ad0c  ; [package:flutter/src/services/platform_channel.dart] OptionalMethodChannel::invokeMethod
    // 0x10e71a4: r0 = ReturnAsync()
    //     0x10e71a4: b               #0x82fdf0  ; ReturnAsyncStub
    // 0x10e71a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e71a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e71ac: b               #0x10e7130
    // 0x10e71b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10e71b0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4598, size: 0x8, field offset: 0x8
abstract class TextInputControl extends Object {
}

// class id: 4600, size: 0x8, field offset: 0x8
class _PlatformTextInputControl extends _MixinApplication130&Object&TextInputControl {

  static late final _PlatformTextInputControl instance; // offset: 0x688

  get _ _channel(/* No info */) {
    // ** addr: 0x872d5c, size: 0x64
    // 0x872d5c: EnterFrame
    //     0x872d5c: stp             fp, lr, [SP, #-0x10]!
    //     0x872d60: mov             fp, SP
    // 0x872d64: CheckStackOverflow
    //     0x872d64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x872d68: cmp             SP, x16
    //     0x872d6c: b.ls            #0x872db0
    // 0x872d70: r0 = LoadStaticField(0x67c)
    //     0x872d70: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x872d74: ldr             x0, [x0, #0xcf8]
    // 0x872d78: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x872d7c: cmp             w0, w16
    // 0x872d80: b.ne            #0x872d8c
    // 0x872d84: r2 = _instance
    //     0x872d84: ldr             x2, [PP, #0x30b0]  ; [pp+0x30b0] Field <TextInput._instance@81206165>: static late final (offset: 0x67c)
    // 0x872d88: r0 = InitLateFinalStaticField()
    //     0x872d88: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x872d8c: LoadField: r1 = r0->field_f
    //     0x872d8c: ldur            w1, [x0, #0xf]
    // 0x872d90: DecompressPointer r1
    //     0x872d90: add             x1, x1, HEAP, lsl #32
    // 0x872d94: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x872d98: cmp             w1, w16
    // 0x872d9c: b.eq            #0x872db8
    // 0x872da0: r0 = Instance_OptionalMethodChannel
    //     0x872da0: ldr             x0, [PP, #0x43b0]  ; [pp+0x43b0] Obj!OptionalMethodChannel@129bea1
    // 0x872da4: LeaveFrame
    //     0x872da4: mov             SP, fp
    //     0x872da8: ldp             fp, lr, [SP], #0x10
    // 0x872dac: ret
    //     0x872dac: ret             
    // 0x872db0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x872db0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x872db4: b               #0x872d70
    // 0x872db8: r9 = _channel
    //     0x872db8: ldr             x9, [PP, #0x5968]  ; [pp+0x5968] Field <TextInput._channel@81206165>: late (offset: 0x10)
    // 0x872dbc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x872dbc: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, Object, StackTrace) {
    // ** addr: 0x872dc0, size: 0x40
    // 0x872dc0: EnterFrame
    //     0x872dc0: stp             fp, lr, [SP, #-0x10]!
    //     0x872dc4: mov             fp, SP
    // 0x872dc8: CheckStackOverflow
    //     0x872dc8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x872dcc: cmp             SP, x16
    //     0x872dd0: b.ls            #0x872df8
    // 0x872dd4: ldr             x1, [fp, #0x18]
    // 0x872dd8: ldr             x2, [fp, #0x10]
    // 0x872ddc: r3 = "while requesting autofill"
    //     0x872ddc: ldr             x3, [PP, #0x5960]  ; [pp+0x5960] "while requesting autofill"
    // 0x872de0: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x872de0: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x872de4: r0 = _reportError()
    //     0x872de4: bl              #0x853090  ; [package:flutter/src/services/text_input.dart] ::_reportError
    // 0x872de8: r0 = Null
    //     0x872de8: mov             x0, NULL
    // 0x872dec: LeaveFrame
    //     0x872dec: mov             SP, fp
    //     0x872df0: ldp             fp, lr, [SP], #0x10
    // 0x872df4: ret
    //     0x872df4: ret             
    // 0x872df8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x872df8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x872dfc: b               #0x872dd4
  }
  [closure] void <anonymous closure>(dynamic, Object, StackTrace) {
    // ** addr: 0x873010, size: 0x40
    // 0x873010: EnterFrame
    //     0x873010: stp             fp, lr, [SP, #-0x10]!
    //     0x873014: mov             fp, SP
    // 0x873018: CheckStackOverflow
    //     0x873018: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87301c: cmp             SP, x16
    //     0x873020: b.ls            #0x873048
    // 0x873024: ldr             x1, [fp, #0x18]
    // 0x873028: ldr             x2, [fp, #0x10]
    // 0x87302c: r3 = "while showing the text input client"
    //     0x87302c: ldr             x3, [PP, #0x5998]  ; [pp+0x5998] "while showing the text input client"
    // 0x873030: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x873030: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x873034: r0 = _reportError()
    //     0x873034: bl              #0x853090  ; [package:flutter/src/services/text_input.dart] ::_reportError
    // 0x873038: r0 = Null
    //     0x873038: mov             x0, NULL
    // 0x87303c: LeaveFrame
    //     0x87303c: mov             SP, fp
    //     0x873040: ldp             fp, lr, [SP], #0x10
    // 0x873044: ret
    //     0x873044: ret             
    // 0x873048: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x873048: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87304c: b               #0x873024
  }
  [closure] void <anonymous closure>(dynamic, Object, StackTrace) {
    // ** addr: 0x873528, size: 0x40
    // 0x873528: EnterFrame
    //     0x873528: stp             fp, lr, [SP, #-0x10]!
    //     0x87352c: mov             fp, SP
    // 0x873530: CheckStackOverflow
    //     0x873530: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x873534: cmp             SP, x16
    //     0x873538: b.ls            #0x873560
    // 0x87353c: ldr             x1, [fp, #0x18]
    // 0x873540: ldr             x2, [fp, #0x10]
    // 0x873544: r3 = "while updating text input style"
    //     0x873544: ldr             x3, [PP, #0x59c8]  ; [pp+0x59c8] "while updating text input style"
    // 0x873548: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x873548: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x87354c: r0 = _reportError()
    //     0x87354c: bl              #0x853090  ; [package:flutter/src/services/text_input.dart] ::_reportError
    // 0x873550: r0 = Null
    //     0x873550: mov             x0, NULL
    // 0x873554: LeaveFrame
    //     0x873554: mov             SP, fp
    //     0x873558: ldp             fp, lr, [SP], #0x10
    // 0x87355c: ret
    //     0x87355c: ret             
    // 0x873560: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x873560: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x873564: b               #0x87353c
  }
  _ setCaretRect(/* No info */) {
    // ** addr: 0x873cd8, size: 0x250
    // 0x873cd8: EnterFrame
    //     0x873cd8: stp             fp, lr, [SP, #-0x10]!
    //     0x873cdc: mov             fp, SP
    // 0x873ce0: AllocStack(0x30)
    //     0x873ce0: sub             SP, SP, #0x30
    // 0x873ce4: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x873ce4: stur            x2, [fp, #-8]
    // 0x873ce8: CheckStackOverflow
    //     0x873ce8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x873cec: cmp             SP, x16
    //     0x873cf0: b.ls            #0x873ea0
    // 0x873cf4: r0 = LoadStaticField(0x67c)
    //     0x873cf4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x873cf8: ldr             x0, [x0, #0xcf8]
    // 0x873cfc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x873d00: cmp             w0, w16
    // 0x873d04: b.ne            #0x873d10
    // 0x873d08: r2 = _instance
    //     0x873d08: ldr             x2, [PP, #0x30b0]  ; [pp+0x30b0] Field <TextInput._instance@81206165>: static late final (offset: 0x67c)
    // 0x873d0c: r0 = InitLateFinalStaticField()
    //     0x873d0c: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x873d10: LoadField: r1 = r0->field_f
    //     0x873d10: ldur            w1, [x0, #0xf]
    // 0x873d14: DecompressPointer r1
    //     0x873d14: add             x1, x1, HEAP, lsl #32
    // 0x873d18: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x873d1c: cmp             w1, w16
    // 0x873d20: b.eq            #0x873ea8
    // 0x873d24: r1 = Null
    //     0x873d24: mov             x1, NULL
    // 0x873d28: r2 = 16
    //     0x873d28: mov             x2, #0x10
    // 0x873d2c: r0 = AllocateArray()
    //     0x873d2c: bl              #0x13df928  ; AllocateArrayStub
    // 0x873d30: r16 = "width"
    //     0x873d30: ldr             x16, [PP, #0x5a40]  ; [pp+0x5a40] "width"
    // 0x873d34: StoreField: r0->field_f = r16
    //     0x873d34: stur            w16, [x0, #0xf]
    // 0x873d38: ldur            x1, [fp, #-8]
    // 0x873d3c: ArrayLoad: d0 = r1[0]  ; List_8
    //     0x873d3c: ldur            d0, [x1, #0x17]
    // 0x873d40: LoadField: d1 = r1->field_7
    //     0x873d40: ldur            d1, [x1, #7]
    // 0x873d44: fsub            d2, d0, d1
    // 0x873d48: r2 = inline_Allocate_Double()
    //     0x873d48: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x873d4c: add             x2, x2, #0x10
    //     0x873d50: cmp             x3, x2
    //     0x873d54: b.ls            #0x873eb0
    //     0x873d58: str             x2, [THR, #0x60]  ; THR::top
    //     0x873d5c: sub             x2, x2, #0xf
    //     0x873d60: mov             x3, #0xe19c
    //     0x873d64: movk            x3, #3, lsl #16
    //     0x873d68: stur            x3, [x2, #-1]
    // 0x873d6c: dmb             ishst
    // 0x873d70: StoreField: r2->field_7 = d2
    //     0x873d70: stur            d2, [x2, #7]
    // 0x873d74: StoreField: r0->field_13 = r2
    //     0x873d74: stur            w2, [x0, #0x13]
    // 0x873d78: r16 = "height"
    //     0x873d78: ldr             x16, [PP, #0x4ac8]  ; [pp+0x4ac8] "height"
    // 0x873d7c: ArrayStore: r0[0] = r16  ; List_4
    //     0x873d7c: stur            w16, [x0, #0x17]
    // 0x873d80: LoadField: d0 = r1->field_1f
    //     0x873d80: ldur            d0, [x1, #0x1f]
    // 0x873d84: LoadField: d2 = r1->field_f
    //     0x873d84: ldur            d2, [x1, #0xf]
    // 0x873d88: fsub            d3, d0, d2
    // 0x873d8c: r1 = inline_Allocate_Double()
    //     0x873d8c: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x873d90: add             x1, x1, #0x10
    //     0x873d94: cmp             x2, x1
    //     0x873d98: b.ls            #0x873ecc
    //     0x873d9c: str             x1, [THR, #0x60]  ; THR::top
    //     0x873da0: sub             x1, x1, #0xf
    //     0x873da4: mov             x2, #0xe19c
    //     0x873da8: movk            x2, #3, lsl #16
    //     0x873dac: stur            x2, [x1, #-1]
    // 0x873db0: dmb             ishst
    // 0x873db4: StoreField: r1->field_7 = d3
    //     0x873db4: stur            d3, [x1, #7]
    // 0x873db8: StoreField: r0->field_1b = r1
    //     0x873db8: stur            w1, [x0, #0x1b]
    // 0x873dbc: r16 = "x"
    //     0x873dbc: ldr             x16, [PP, #0x5a48]  ; [pp+0x5a48] "x"
    // 0x873dc0: StoreField: r0->field_1f = r16
    //     0x873dc0: stur            w16, [x0, #0x1f]
    // 0x873dc4: r1 = inline_Allocate_Double()
    //     0x873dc4: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x873dc8: add             x1, x1, #0x10
    //     0x873dcc: cmp             x2, x1
    //     0x873dd0: b.ls            #0x873ef0
    //     0x873dd4: str             x1, [THR, #0x60]  ; THR::top
    //     0x873dd8: sub             x1, x1, #0xf
    //     0x873ddc: mov             x2, #0xe19c
    //     0x873de0: movk            x2, #3, lsl #16
    //     0x873de4: stur            x2, [x1, #-1]
    // 0x873de8: dmb             ishst
    // 0x873dec: StoreField: r1->field_7 = d1
    //     0x873dec: stur            d1, [x1, #7]
    // 0x873df0: StoreField: r0->field_23 = r1
    //     0x873df0: stur            w1, [x0, #0x23]
    // 0x873df4: r16 = "y"
    //     0x873df4: ldr             x16, [PP, #0x5a50]  ; [pp+0x5a50] "y"
    // 0x873df8: StoreField: r0->field_27 = r16
    //     0x873df8: stur            w16, [x0, #0x27]
    // 0x873dfc: r1 = inline_Allocate_Double()
    //     0x873dfc: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x873e00: add             x1, x1, #0x10
    //     0x873e04: cmp             x2, x1
    //     0x873e08: b.ls            #0x873f0c
    //     0x873e0c: str             x1, [THR, #0x60]  ; THR::top
    //     0x873e10: sub             x1, x1, #0xf
    //     0x873e14: mov             x2, #0xe19c
    //     0x873e18: movk            x2, #3, lsl #16
    //     0x873e1c: stur            x2, [x1, #-1]
    // 0x873e20: dmb             ishst
    // 0x873e24: StoreField: r1->field_7 = d2
    //     0x873e24: stur            d2, [x1, #7]
    // 0x873e28: StoreField: r0->field_2b = r1
    //     0x873e28: stur            w1, [x0, #0x2b]
    // 0x873e2c: r16 = <String, dynamic>
    //     0x873e2c: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x873e30: stp             x0, x16, [SP]
    // 0x873e34: r0 = Map._fromLiteral()
    //     0x873e34: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x873e38: r16 = <void?>
    //     0x873e38: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x873e3c: r30 = Instance_OptionalMethodChannel
    //     0x873e3c: ldr             lr, [PP, #0x43b0]  ; [pp+0x43b0] Obj!OptionalMethodChannel@129bea1
    // 0x873e40: stp             lr, x16, [SP, #0x10]
    // 0x873e44: r16 = "TextInput.setCaretRect"
    //     0x873e44: ldr             x16, [PP, #0x5a58]  ; [pp+0x5a58] "TextInput.setCaretRect"
    // 0x873e48: stp             x0, x16, [SP]
    // 0x873e4c: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x873e4c: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x873e50: r0 = invokeMethod()
    //     0x873e50: bl              #0x130ad0c  ; [package:flutter/src/services/platform_channel.dart] OptionalMethodChannel::invokeMethod
    // 0x873e54: r1 = Function '<anonymous closure>':.
    //     0x873e54: ldr             x1, [PP, #0x5a60]  ; [pp+0x5a60] Function: [dart:ui] Shader::Shader._ (0x13cf838)
    // 0x873e58: r2 = Null
    //     0x873e58: mov             x2, NULL
    // 0x873e5c: stur            x0, [fp, #-8]
    // 0x873e60: r0 = AllocateClosure()
    //     0x873e60: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x873e64: r1 = Function '<anonymous closure>':.
    //     0x873e64: ldr             x1, [PP, #0x5a68]  ; [pp+0x5a68] AnonymousClosure: (0x873f28), in [package:flutter/src/services/text_input.dart] _PlatformTextInputControl::setCaretRect (0x873cd8)
    // 0x873e68: r2 = Null
    //     0x873e68: mov             x2, NULL
    // 0x873e6c: stur            x0, [fp, #-0x10]
    // 0x873e70: r0 = AllocateClosure()
    //     0x873e70: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x873e74: r16 = <Null?>
    //     0x873e74: ldr             x16, [PP, #0x70]  ; [pp+0x70] TypeArguments: <Null?>
    // 0x873e78: ldur            lr, [fp, #-8]
    // 0x873e7c: stp             lr, x16, [SP, #0x10]
    // 0x873e80: ldur            x16, [fp, #-0x10]
    // 0x873e84: stp             x0, x16, [SP]
    // 0x873e88: r4 = const [0x1, 0x3, 0x3, 0x2, onError, 0x2, null]
    //     0x873e88: ldr             x4, [PP, #0x538]  ; [pp+0x538] List(7) [0x1, 0x3, 0x3, 0x2, "onError", 0x2, Null]
    // 0x873e8c: r0 = then()
    //     0x873e8c: bl              #0x1293070  ; [dart:async] _Future::then
    // 0x873e90: r0 = Null
    //     0x873e90: mov             x0, NULL
    // 0x873e94: LeaveFrame
    //     0x873e94: mov             SP, fp
    //     0x873e98: ldp             fp, lr, [SP], #0x10
    // 0x873e9c: ret
    //     0x873e9c: ret             
    // 0x873ea0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x873ea0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x873ea4: b               #0x873cf4
    // 0x873ea8: r9 = _channel
    //     0x873ea8: ldr             x9, [PP, #0x5968]  ; [pp+0x5968] Field <TextInput._channel@81206165>: late (offset: 0x10)
    // 0x873eac: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x873eac: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x873eb0: stp             q1, q2, [SP, #-0x20]!
    // 0x873eb4: stp             x0, x1, [SP, #-0x10]!
    // 0x873eb8: r0 = AllocateDouble()
    //     0x873eb8: bl              #0x13df878  ; AllocateDoubleStub
    // 0x873ebc: mov             x2, x0
    // 0x873ec0: ldp             x0, x1, [SP], #0x10
    // 0x873ec4: ldp             q1, q2, [SP], #0x20
    // 0x873ec8: b               #0x873d70
    // 0x873ecc: stp             q2, q3, [SP, #-0x20]!
    // 0x873ed0: SaveReg d1
    //     0x873ed0: str             q1, [SP, #-0x10]!
    // 0x873ed4: SaveReg r0
    //     0x873ed4: str             x0, [SP, #-8]!
    // 0x873ed8: r0 = AllocateDouble()
    //     0x873ed8: bl              #0x13df878  ; AllocateDoubleStub
    // 0x873edc: mov             x1, x0
    // 0x873ee0: RestoreReg r0
    //     0x873ee0: ldr             x0, [SP], #8
    // 0x873ee4: RestoreReg d1
    //     0x873ee4: ldr             q1, [SP], #0x10
    // 0x873ee8: ldp             q2, q3, [SP], #0x20
    // 0x873eec: b               #0x873db4
    // 0x873ef0: stp             q1, q2, [SP, #-0x20]!
    // 0x873ef4: SaveReg r0
    //     0x873ef4: str             x0, [SP, #-8]!
    // 0x873ef8: r0 = AllocateDouble()
    //     0x873ef8: bl              #0x13df878  ; AllocateDoubleStub
    // 0x873efc: mov             x1, x0
    // 0x873f00: RestoreReg r0
    //     0x873f00: ldr             x0, [SP], #8
    // 0x873f04: ldp             q1, q2, [SP], #0x20
    // 0x873f08: b               #0x873dec
    // 0x873f0c: SaveReg d2
    //     0x873f0c: str             q2, [SP, #-0x10]!
    // 0x873f10: SaveReg r0
    //     0x873f10: str             x0, [SP, #-8]!
    // 0x873f14: r0 = AllocateDouble()
    //     0x873f14: bl              #0x13df878  ; AllocateDoubleStub
    // 0x873f18: mov             x1, x0
    // 0x873f1c: RestoreReg r0
    //     0x873f1c: ldr             x0, [SP], #8
    // 0x873f20: RestoreReg d2
    //     0x873f20: ldr             q2, [SP], #0x10
    // 0x873f24: b               #0x873e24
  }
  [closure] void <anonymous closure>(dynamic, Object, StackTrace) {
    // ** addr: 0x873f28, size: 0x40
    // 0x873f28: EnterFrame
    //     0x873f28: stp             fp, lr, [SP, #-0x10]!
    //     0x873f2c: mov             fp, SP
    // 0x873f30: CheckStackOverflow
    //     0x873f30: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x873f34: cmp             SP, x16
    //     0x873f38: b.ls            #0x873f60
    // 0x873f3c: ldr             x1, [fp, #0x18]
    // 0x873f40: ldr             x2, [fp, #0x10]
    // 0x873f44: r3 = "while setting text input caret rect"
    //     0x873f44: ldr             x3, [PP, #0x5a70]  ; [pp+0x5a70] "while setting text input caret rect"
    // 0x873f48: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x873f48: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x873f4c: r0 = _reportError()
    //     0x873f4c: bl              #0x853090  ; [package:flutter/src/services/text_input.dart] ::_reportError
    // 0x873f50: r0 = Null
    //     0x873f50: mov             x0, NULL
    // 0x873f54: LeaveFrame
    //     0x873f54: mov             SP, fp
    //     0x873f58: ldp             fp, lr, [SP], #0x10
    // 0x873f5c: ret
    //     0x873f5c: ret             
    // 0x873f60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x873f60: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x873f64: b               #0x873f3c
  }
  _ setComposingRect(/* No info */) {
    // ** addr: 0x874338, size: 0x250
    // 0x874338: EnterFrame
    //     0x874338: stp             fp, lr, [SP, #-0x10]!
    //     0x87433c: mov             fp, SP
    // 0x874340: AllocStack(0x30)
    //     0x874340: sub             SP, SP, #0x30
    // 0x874344: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x874344: stur            x2, [fp, #-8]
    // 0x874348: CheckStackOverflow
    //     0x874348: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87434c: cmp             SP, x16
    //     0x874350: b.ls            #0x874500
    // 0x874354: r0 = LoadStaticField(0x67c)
    //     0x874354: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x874358: ldr             x0, [x0, #0xcf8]
    // 0x87435c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x874360: cmp             w0, w16
    // 0x874364: b.ne            #0x874370
    // 0x874368: r2 = _instance
    //     0x874368: ldr             x2, [PP, #0x30b0]  ; [pp+0x30b0] Field <TextInput._instance@81206165>: static late final (offset: 0x67c)
    // 0x87436c: r0 = InitLateFinalStaticField()
    //     0x87436c: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x874370: LoadField: r1 = r0->field_f
    //     0x874370: ldur            w1, [x0, #0xf]
    // 0x874374: DecompressPointer r1
    //     0x874374: add             x1, x1, HEAP, lsl #32
    // 0x874378: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x87437c: cmp             w1, w16
    // 0x874380: b.eq            #0x874508
    // 0x874384: r1 = Null
    //     0x874384: mov             x1, NULL
    // 0x874388: r2 = 16
    //     0x874388: mov             x2, #0x10
    // 0x87438c: r0 = AllocateArray()
    //     0x87438c: bl              #0x13df928  ; AllocateArrayStub
    // 0x874390: r16 = "width"
    //     0x874390: ldr             x16, [PP, #0x5a40]  ; [pp+0x5a40] "width"
    // 0x874394: StoreField: r0->field_f = r16
    //     0x874394: stur            w16, [x0, #0xf]
    // 0x874398: ldur            x1, [fp, #-8]
    // 0x87439c: ArrayLoad: d0 = r1[0]  ; List_8
    //     0x87439c: ldur            d0, [x1, #0x17]
    // 0x8743a0: LoadField: d1 = r1->field_7
    //     0x8743a0: ldur            d1, [x1, #7]
    // 0x8743a4: fsub            d2, d0, d1
    // 0x8743a8: r2 = inline_Allocate_Double()
    //     0x8743a8: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x8743ac: add             x2, x2, #0x10
    //     0x8743b0: cmp             x3, x2
    //     0x8743b4: b.ls            #0x874510
    //     0x8743b8: str             x2, [THR, #0x60]  ; THR::top
    //     0x8743bc: sub             x2, x2, #0xf
    //     0x8743c0: mov             x3, #0xe19c
    //     0x8743c4: movk            x3, #3, lsl #16
    //     0x8743c8: stur            x3, [x2, #-1]
    // 0x8743cc: dmb             ishst
    // 0x8743d0: StoreField: r2->field_7 = d2
    //     0x8743d0: stur            d2, [x2, #7]
    // 0x8743d4: StoreField: r0->field_13 = r2
    //     0x8743d4: stur            w2, [x0, #0x13]
    // 0x8743d8: r16 = "height"
    //     0x8743d8: ldr             x16, [PP, #0x4ac8]  ; [pp+0x4ac8] "height"
    // 0x8743dc: ArrayStore: r0[0] = r16  ; List_4
    //     0x8743dc: stur            w16, [x0, #0x17]
    // 0x8743e0: LoadField: d0 = r1->field_1f
    //     0x8743e0: ldur            d0, [x1, #0x1f]
    // 0x8743e4: LoadField: d2 = r1->field_f
    //     0x8743e4: ldur            d2, [x1, #0xf]
    // 0x8743e8: fsub            d3, d0, d2
    // 0x8743ec: r1 = inline_Allocate_Double()
    //     0x8743ec: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x8743f0: add             x1, x1, #0x10
    //     0x8743f4: cmp             x2, x1
    //     0x8743f8: b.ls            #0x87452c
    //     0x8743fc: str             x1, [THR, #0x60]  ; THR::top
    //     0x874400: sub             x1, x1, #0xf
    //     0x874404: mov             x2, #0xe19c
    //     0x874408: movk            x2, #3, lsl #16
    //     0x87440c: stur            x2, [x1, #-1]
    // 0x874410: dmb             ishst
    // 0x874414: StoreField: r1->field_7 = d3
    //     0x874414: stur            d3, [x1, #7]
    // 0x874418: StoreField: r0->field_1b = r1
    //     0x874418: stur            w1, [x0, #0x1b]
    // 0x87441c: r16 = "x"
    //     0x87441c: ldr             x16, [PP, #0x5a48]  ; [pp+0x5a48] "x"
    // 0x874420: StoreField: r0->field_1f = r16
    //     0x874420: stur            w16, [x0, #0x1f]
    // 0x874424: r1 = inline_Allocate_Double()
    //     0x874424: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x874428: add             x1, x1, #0x10
    //     0x87442c: cmp             x2, x1
    //     0x874430: b.ls            #0x874550
    //     0x874434: str             x1, [THR, #0x60]  ; THR::top
    //     0x874438: sub             x1, x1, #0xf
    //     0x87443c: mov             x2, #0xe19c
    //     0x874440: movk            x2, #3, lsl #16
    //     0x874444: stur            x2, [x1, #-1]
    // 0x874448: dmb             ishst
    // 0x87444c: StoreField: r1->field_7 = d1
    //     0x87444c: stur            d1, [x1, #7]
    // 0x874450: StoreField: r0->field_23 = r1
    //     0x874450: stur            w1, [x0, #0x23]
    // 0x874454: r16 = "y"
    //     0x874454: ldr             x16, [PP, #0x5a50]  ; [pp+0x5a50] "y"
    // 0x874458: StoreField: r0->field_27 = r16
    //     0x874458: stur            w16, [x0, #0x27]
    // 0x87445c: r1 = inline_Allocate_Double()
    //     0x87445c: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x874460: add             x1, x1, #0x10
    //     0x874464: cmp             x2, x1
    //     0x874468: b.ls            #0x87456c
    //     0x87446c: str             x1, [THR, #0x60]  ; THR::top
    //     0x874470: sub             x1, x1, #0xf
    //     0x874474: mov             x2, #0xe19c
    //     0x874478: movk            x2, #3, lsl #16
    //     0x87447c: stur            x2, [x1, #-1]
    // 0x874480: dmb             ishst
    // 0x874484: StoreField: r1->field_7 = d2
    //     0x874484: stur            d2, [x1, #7]
    // 0x874488: StoreField: r0->field_2b = r1
    //     0x874488: stur            w1, [x0, #0x2b]
    // 0x87448c: r16 = <String, dynamic>
    //     0x87448c: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x874490: stp             x0, x16, [SP]
    // 0x874494: r0 = Map._fromLiteral()
    //     0x874494: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x874498: r16 = <void?>
    //     0x874498: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x87449c: r30 = Instance_OptionalMethodChannel
    //     0x87449c: ldr             lr, [PP, #0x43b0]  ; [pp+0x43b0] Obj!OptionalMethodChannel@129bea1
    // 0x8744a0: stp             lr, x16, [SP, #0x10]
    // 0x8744a4: r16 = "TextInput.setMarkedTextRect"
    //     0x8744a4: ldr             x16, [PP, #0x5a88]  ; [pp+0x5a88] "TextInput.setMarkedTextRect"
    // 0x8744a8: stp             x0, x16, [SP]
    // 0x8744ac: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x8744ac: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x8744b0: r0 = invokeMethod()
    //     0x8744b0: bl              #0x130ad0c  ; [package:flutter/src/services/platform_channel.dart] OptionalMethodChannel::invokeMethod
    // 0x8744b4: r1 = Function '<anonymous closure>':.
    //     0x8744b4: ldr             x1, [PP, #0x5a90]  ; [pp+0x5a90] Function: [dart:ui] Shader::Shader._ (0x13cf838)
    // 0x8744b8: r2 = Null
    //     0x8744b8: mov             x2, NULL
    // 0x8744bc: stur            x0, [fp, #-8]
    // 0x8744c0: r0 = AllocateClosure()
    //     0x8744c0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8744c4: r1 = Function '<anonymous closure>':.
    //     0x8744c4: ldr             x1, [PP, #0x5a98]  ; [pp+0x5a98] AnonymousClosure: (0x874588), in [package:flutter/src/services/text_input.dart] _PlatformTextInputControl::setComposingRect (0x874338)
    // 0x8744c8: r2 = Null
    //     0x8744c8: mov             x2, NULL
    // 0x8744cc: stur            x0, [fp, #-0x10]
    // 0x8744d0: r0 = AllocateClosure()
    //     0x8744d0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8744d4: r16 = <Null?>
    //     0x8744d4: ldr             x16, [PP, #0x70]  ; [pp+0x70] TypeArguments: <Null?>
    // 0x8744d8: ldur            lr, [fp, #-8]
    // 0x8744dc: stp             lr, x16, [SP, #0x10]
    // 0x8744e0: ldur            x16, [fp, #-0x10]
    // 0x8744e4: stp             x0, x16, [SP]
    // 0x8744e8: r4 = const [0x1, 0x3, 0x3, 0x2, onError, 0x2, null]
    //     0x8744e8: ldr             x4, [PP, #0x538]  ; [pp+0x538] List(7) [0x1, 0x3, 0x3, 0x2, "onError", 0x2, Null]
    // 0x8744ec: r0 = then()
    //     0x8744ec: bl              #0x1293070  ; [dart:async] _Future::then
    // 0x8744f0: r0 = Null
    //     0x8744f0: mov             x0, NULL
    // 0x8744f4: LeaveFrame
    //     0x8744f4: mov             SP, fp
    //     0x8744f8: ldp             fp, lr, [SP], #0x10
    // 0x8744fc: ret
    //     0x8744fc: ret             
    // 0x874500: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x874500: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x874504: b               #0x874354
    // 0x874508: r9 = _channel
    //     0x874508: ldr             x9, [PP, #0x5968]  ; [pp+0x5968] Field <TextInput._channel@81206165>: late (offset: 0x10)
    // 0x87450c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x87450c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x874510: stp             q1, q2, [SP, #-0x20]!
    // 0x874514: stp             x0, x1, [SP, #-0x10]!
    // 0x874518: r0 = AllocateDouble()
    //     0x874518: bl              #0x13df878  ; AllocateDoubleStub
    // 0x87451c: mov             x2, x0
    // 0x874520: ldp             x0, x1, [SP], #0x10
    // 0x874524: ldp             q1, q2, [SP], #0x20
    // 0x874528: b               #0x8743d0
    // 0x87452c: stp             q2, q3, [SP, #-0x20]!
    // 0x874530: SaveReg d1
    //     0x874530: str             q1, [SP, #-0x10]!
    // 0x874534: SaveReg r0
    //     0x874534: str             x0, [SP, #-8]!
    // 0x874538: r0 = AllocateDouble()
    //     0x874538: bl              #0x13df878  ; AllocateDoubleStub
    // 0x87453c: mov             x1, x0
    // 0x874540: RestoreReg r0
    //     0x874540: ldr             x0, [SP], #8
    // 0x874544: RestoreReg d1
    //     0x874544: ldr             q1, [SP], #0x10
    // 0x874548: ldp             q2, q3, [SP], #0x20
    // 0x87454c: b               #0x874414
    // 0x874550: stp             q1, q2, [SP, #-0x20]!
    // 0x874554: SaveReg r0
    //     0x874554: str             x0, [SP, #-8]!
    // 0x874558: r0 = AllocateDouble()
    //     0x874558: bl              #0x13df878  ; AllocateDoubleStub
    // 0x87455c: mov             x1, x0
    // 0x874560: RestoreReg r0
    //     0x874560: ldr             x0, [SP], #8
    // 0x874564: ldp             q1, q2, [SP], #0x20
    // 0x874568: b               #0x87444c
    // 0x87456c: SaveReg d2
    //     0x87456c: str             q2, [SP, #-0x10]!
    // 0x874570: SaveReg r0
    //     0x874570: str             x0, [SP, #-8]!
    // 0x874574: r0 = AllocateDouble()
    //     0x874574: bl              #0x13df878  ; AllocateDoubleStub
    // 0x874578: mov             x1, x0
    // 0x87457c: RestoreReg r0
    //     0x87457c: ldr             x0, [SP], #8
    // 0x874580: RestoreReg d2
    //     0x874580: ldr             q2, [SP], #0x10
    // 0x874584: b               #0x874484
  }
  [closure] void <anonymous closure>(dynamic, Object, StackTrace) {
    // ** addr: 0x874588, size: 0x40
    // 0x874588: EnterFrame
    //     0x874588: stp             fp, lr, [SP, #-0x10]!
    //     0x87458c: mov             fp, SP
    // 0x874590: CheckStackOverflow
    //     0x874590: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x874594: cmp             SP, x16
    //     0x874598: b.ls            #0x8745c0
    // 0x87459c: ldr             x1, [fp, #0x18]
    // 0x8745a0: ldr             x2, [fp, #0x10]
    // 0x8745a4: r3 = "while setting text input composing rect"
    //     0x8745a4: ldr             x3, [PP, #0x5aa0]  ; [pp+0x5aa0] "while setting text input composing rect"
    // 0x8745a8: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x8745a8: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x8745ac: r0 = _reportError()
    //     0x8745ac: bl              #0x853090  ; [package:flutter/src/services/text_input.dart] ::_reportError
    // 0x8745b0: r0 = Null
    //     0x8745b0: mov             x0, NULL
    // 0x8745b4: LeaveFrame
    //     0x8745b4: mov             SP, fp
    //     0x8745b8: ldp             fp, lr, [SP], #0x10
    // 0x8745bc: ret
    //     0x8745bc: ret             
    // 0x8745c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8745c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8745c4: b               #0x87459c
  }
  _ setEditableSizeAndTransform(/* No info */) {
    // ** addr: 0x8748e4, size: 0x1ac
    // 0x8748e4: EnterFrame
    //     0x8748e4: stp             fp, lr, [SP, #-0x10]!
    //     0x8748e8: mov             fp, SP
    // 0x8748ec: AllocStack(0x30)
    //     0x8748ec: sub             SP, SP, #0x30
    // 0x8748f0: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0x8748f0: stur            x2, [fp, #-8]
    //     0x8748f4: stur            x3, [fp, #-0x10]
    // 0x8748f8: CheckStackOverflow
    //     0x8748f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8748fc: cmp             SP, x16
    //     0x874900: b.ls            #0x874a48
    // 0x874904: r0 = LoadStaticField(0x67c)
    //     0x874904: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x874908: ldr             x0, [x0, #0xcf8]
    // 0x87490c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x874910: cmp             w0, w16
    // 0x874914: b.ne            #0x874920
    // 0x874918: r2 = _instance
    //     0x874918: ldr             x2, [PP, #0x30b0]  ; [pp+0x30b0] Field <TextInput._instance@81206165>: static late final (offset: 0x67c)
    // 0x87491c: r0 = InitLateFinalStaticField()
    //     0x87491c: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x874920: LoadField: r1 = r0->field_f
    //     0x874920: ldur            w1, [x0, #0xf]
    // 0x874924: DecompressPointer r1
    //     0x874924: add             x1, x1, HEAP, lsl #32
    // 0x874928: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x87492c: cmp             w1, w16
    // 0x874930: b.eq            #0x874a50
    // 0x874934: r1 = Null
    //     0x874934: mov             x1, NULL
    // 0x874938: r2 = 12
    //     0x874938: mov             x2, #0xc
    // 0x87493c: r0 = AllocateArray()
    //     0x87493c: bl              #0x13df928  ; AllocateArrayStub
    // 0x874940: r16 = "width"
    //     0x874940: ldr             x16, [PP, #0x5a40]  ; [pp+0x5a40] "width"
    // 0x874944: StoreField: r0->field_f = r16
    //     0x874944: stur            w16, [x0, #0xf]
    // 0x874948: ldur            x1, [fp, #-8]
    // 0x87494c: LoadField: d0 = r1->field_7
    //     0x87494c: ldur            d0, [x1, #7]
    // 0x874950: r2 = inline_Allocate_Double()
    //     0x874950: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x874954: add             x2, x2, #0x10
    //     0x874958: cmp             x3, x2
    //     0x87495c: b.ls            #0x874a58
    //     0x874960: str             x2, [THR, #0x60]  ; THR::top
    //     0x874964: sub             x2, x2, #0xf
    //     0x874968: mov             x3, #0xe19c
    //     0x87496c: movk            x3, #3, lsl #16
    //     0x874970: stur            x3, [x2, #-1]
    // 0x874974: dmb             ishst
    // 0x874978: StoreField: r2->field_7 = d0
    //     0x874978: stur            d0, [x2, #7]
    // 0x87497c: StoreField: r0->field_13 = r2
    //     0x87497c: stur            w2, [x0, #0x13]
    // 0x874980: r16 = "height"
    //     0x874980: ldr             x16, [PP, #0x4ac8]  ; [pp+0x4ac8] "height"
    // 0x874984: ArrayStore: r0[0] = r16  ; List_4
    //     0x874984: stur            w16, [x0, #0x17]
    // 0x874988: LoadField: d0 = r1->field_f
    //     0x874988: ldur            d0, [x1, #0xf]
    // 0x87498c: r1 = inline_Allocate_Double()
    //     0x87498c: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x874990: add             x1, x1, #0x10
    //     0x874994: cmp             x2, x1
    //     0x874998: b.ls            #0x874a74
    //     0x87499c: str             x1, [THR, #0x60]  ; THR::top
    //     0x8749a0: sub             x1, x1, #0xf
    //     0x8749a4: mov             x2, #0xe19c
    //     0x8749a8: movk            x2, #3, lsl #16
    //     0x8749ac: stur            x2, [x1, #-1]
    // 0x8749b0: dmb             ishst
    // 0x8749b4: StoreField: r1->field_7 = d0
    //     0x8749b4: stur            d0, [x1, #7]
    // 0x8749b8: StoreField: r0->field_1b = r1
    //     0x8749b8: stur            w1, [x0, #0x1b]
    // 0x8749bc: r16 = "transform"
    //     0x8749bc: ldr             x16, [PP, #0x5ab8]  ; [pp+0x5ab8] "transform"
    // 0x8749c0: StoreField: r0->field_1f = r16
    //     0x8749c0: stur            w16, [x0, #0x1f]
    // 0x8749c4: ldur            x1, [fp, #-0x10]
    // 0x8749c8: LoadField: r2 = r1->field_7
    //     0x8749c8: ldur            w2, [x1, #7]
    // 0x8749cc: DecompressPointer r2
    //     0x8749cc: add             x2, x2, HEAP, lsl #32
    // 0x8749d0: StoreField: r0->field_23 = r2
    //     0x8749d0: stur            w2, [x0, #0x23]
    // 0x8749d4: r16 = <String, dynamic>
    //     0x8749d4: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x8749d8: stp             x0, x16, [SP]
    // 0x8749dc: r0 = Map._fromLiteral()
    //     0x8749dc: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x8749e0: r16 = <void?>
    //     0x8749e0: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x8749e4: r30 = Instance_OptionalMethodChannel
    //     0x8749e4: ldr             lr, [PP, #0x43b0]  ; [pp+0x43b0] Obj!OptionalMethodChannel@129bea1
    // 0x8749e8: stp             lr, x16, [SP, #0x10]
    // 0x8749ec: r16 = "TextInput.setEditableSizeAndTransform"
    //     0x8749ec: ldr             x16, [PP, #0x5ac0]  ; [pp+0x5ac0] "TextInput.setEditableSizeAndTransform"
    // 0x8749f0: stp             x0, x16, [SP]
    // 0x8749f4: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x8749f4: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x8749f8: r0 = invokeMethod()
    //     0x8749f8: bl              #0x130ad0c  ; [package:flutter/src/services/platform_channel.dart] OptionalMethodChannel::invokeMethod
    // 0x8749fc: r1 = Function '<anonymous closure>':.
    //     0x8749fc: ldr             x1, [PP, #0x5ac8]  ; [pp+0x5ac8] Function: [dart:ui] Shader::Shader._ (0x13cf838)
    // 0x874a00: r2 = Null
    //     0x874a00: mov             x2, NULL
    // 0x874a04: stur            x0, [fp, #-8]
    // 0x874a08: r0 = AllocateClosure()
    //     0x874a08: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x874a0c: r1 = Function '<anonymous closure>':.
    //     0x874a0c: ldr             x1, [PP, #0x5ad0]  ; [pp+0x5ad0] AnonymousClosure: (0x874a90), in [package:flutter/src/services/text_input.dart] _PlatformTextInputControl::setEditableSizeAndTransform (0x8748e4)
    // 0x874a10: r2 = Null
    //     0x874a10: mov             x2, NULL
    // 0x874a14: stur            x0, [fp, #-0x10]
    // 0x874a18: r0 = AllocateClosure()
    //     0x874a18: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x874a1c: r16 = <Null?>
    //     0x874a1c: ldr             x16, [PP, #0x70]  ; [pp+0x70] TypeArguments: <Null?>
    // 0x874a20: ldur            lr, [fp, #-8]
    // 0x874a24: stp             lr, x16, [SP, #0x10]
    // 0x874a28: ldur            x16, [fp, #-0x10]
    // 0x874a2c: stp             x0, x16, [SP]
    // 0x874a30: r4 = const [0x1, 0x3, 0x3, 0x2, onError, 0x2, null]
    //     0x874a30: ldr             x4, [PP, #0x538]  ; [pp+0x538] List(7) [0x1, 0x3, 0x3, 0x2, "onError", 0x2, Null]
    // 0x874a34: r0 = then()
    //     0x874a34: bl              #0x1293070  ; [dart:async] _Future::then
    // 0x874a38: r0 = Null
    //     0x874a38: mov             x0, NULL
    // 0x874a3c: LeaveFrame
    //     0x874a3c: mov             SP, fp
    //     0x874a40: ldp             fp, lr, [SP], #0x10
    // 0x874a44: ret
    //     0x874a44: ret             
    // 0x874a48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x874a48: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x874a4c: b               #0x874904
    // 0x874a50: r9 = _channel
    //     0x874a50: ldr             x9, [PP, #0x5968]  ; [pp+0x5968] Field <TextInput._channel@81206165>: late (offset: 0x10)
    // 0x874a54: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x874a54: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x874a58: SaveReg d0
    //     0x874a58: str             q0, [SP, #-0x10]!
    // 0x874a5c: stp             x0, x1, [SP, #-0x10]!
    // 0x874a60: r0 = AllocateDouble()
    //     0x874a60: bl              #0x13df878  ; AllocateDoubleStub
    // 0x874a64: mov             x2, x0
    // 0x874a68: ldp             x0, x1, [SP], #0x10
    // 0x874a6c: RestoreReg d0
    //     0x874a6c: ldr             q0, [SP], #0x10
    // 0x874a70: b               #0x874978
    // 0x874a74: SaveReg d0
    //     0x874a74: str             q0, [SP, #-0x10]!
    // 0x874a78: SaveReg r0
    //     0x874a78: str             x0, [SP, #-8]!
    // 0x874a7c: r0 = AllocateDouble()
    //     0x874a7c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x874a80: mov             x1, x0
    // 0x874a84: RestoreReg r0
    //     0x874a84: ldr             x0, [SP], #8
    // 0x874a88: RestoreReg d0
    //     0x874a88: ldr             q0, [SP], #0x10
    // 0x874a8c: b               #0x8749b4
  }
  [closure] void <anonymous closure>(dynamic, Object, StackTrace) {
    // ** addr: 0x874a90, size: 0x40
    // 0x874a90: EnterFrame
    //     0x874a90: stp             fp, lr, [SP, #-0x10]!
    //     0x874a94: mov             fp, SP
    // 0x874a98: CheckStackOverflow
    //     0x874a98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x874a9c: cmp             SP, x16
    //     0x874aa0: b.ls            #0x874ac8
    // 0x874aa4: ldr             x1, [fp, #0x18]
    // 0x874aa8: ldr             x2, [fp, #0x10]
    // 0x874aac: r3 = "while setting text input size and transform"
    //     0x874aac: ldr             x3, [PP, #0x5ad8]  ; [pp+0x5ad8] "while setting text input size and transform"
    // 0x874ab0: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x874ab0: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x874ab4: r0 = _reportError()
    //     0x874ab4: bl              #0x853090  ; [package:flutter/src/services/text_input.dart] ::_reportError
    // 0x874ab8: r0 = Null
    //     0x874ab8: mov             x0, NULL
    // 0x874abc: LeaveFrame
    //     0x874abc: mov             SP, fp
    //     0x874ac0: ldp             fp, lr, [SP], #0x10
    // 0x874ac4: ret
    //     0x874ac4: ret             
    // 0x874ac8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x874ac8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x874acc: b               #0x874aa4
  }
  [closure] void <anonymous closure>(dynamic, Object, StackTrace) {
    // ** addr: 0x875f64, size: 0x40
    // 0x875f64: EnterFrame
    //     0x875f64: stp             fp, lr, [SP, #-0x10]!
    //     0x875f68: mov             fp, SP
    // 0x875f6c: CheckStackOverflow
    //     0x875f6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x875f70: cmp             SP, x16
    //     0x875f74: b.ls            #0x875f9c
    // 0x875f78: ldr             x1, [fp, #0x18]
    // 0x875f7c: ldr             x2, [fp, #0x10]
    // 0x875f80: r3 = "while hiding the text input client"
    //     0x875f80: ldr             x3, [PP, #0x5c10]  ; [pp+0x5c10] "while hiding the text input client"
    // 0x875f84: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x875f84: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x875f88: r0 = _reportError()
    //     0x875f88: bl              #0x853090  ; [package:flutter/src/services/text_input.dart] ::_reportError
    // 0x875f8c: r0 = Null
    //     0x875f8c: mov             x0, NULL
    // 0x875f90: LeaveFrame
    //     0x875f90: mov             SP, fp
    //     0x875f94: ldp             fp, lr, [SP], #0x10
    // 0x875f98: ret
    //     0x875f98: ret             
    // 0x875f9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x875f9c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x875fa0: b               #0x875f78
  }
  [closure] void <anonymous closure>(dynamic, Object, StackTrace) {
    // ** addr: 0x875fa4, size: 0x40
    // 0x875fa4: EnterFrame
    //     0x875fa4: stp             fp, lr, [SP, #-0x10]!
    //     0x875fa8: mov             fp, SP
    // 0x875fac: CheckStackOverflow
    //     0x875fac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x875fb0: cmp             SP, x16
    //     0x875fb4: b.ls            #0x875fdc
    // 0x875fb8: ldr             x1, [fp, #0x18]
    // 0x875fbc: ldr             x2, [fp, #0x10]
    // 0x875fc0: r3 = "while detaching the text input client"
    //     0x875fc0: ldr             x3, [PP, #0x5bd8]  ; [pp+0x5bd8] "while detaching the text input client"
    // 0x875fc4: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x875fc4: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x875fc8: r0 = _reportError()
    //     0x875fc8: bl              #0x853090  ; [package:flutter/src/services/text_input.dart] ::_reportError
    // 0x875fcc: r0 = Null
    //     0x875fcc: mov             x0, NULL
    // 0x875fd0: LeaveFrame
    //     0x875fd0: mov             SP, fp
    //     0x875fd4: ldp             fp, lr, [SP], #0x10
    // 0x875fd8: ret
    //     0x875fd8: ret             
    // 0x875fdc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x875fdc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x875fe0: b               #0x875fb8
  }
  [closure] void <anonymous closure>(dynamic, Object, StackTrace) {
    // ** addr: 0x877f64, size: 0x40
    // 0x877f64: EnterFrame
    //     0x877f64: stp             fp, lr, [SP, #-0x10]!
    //     0x877f68: mov             fp, SP
    // 0x877f6c: CheckStackOverflow
    //     0x877f6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x877f70: cmp             SP, x16
    //     0x877f74: b.ls            #0x877f9c
    // 0x877f78: ldr             x1, [fp, #0x18]
    // 0x877f7c: ldr             x2, [fp, #0x10]
    // 0x877f80: r3 = "while setting text input editing state"
    //     0x877f80: ldr             x3, [PP, #0x6010]  ; [pp+0x6010] "while setting text input editing state"
    // 0x877f84: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x877f84: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x877f88: r0 = _reportError()
    //     0x877f88: bl              #0x853090  ; [package:flutter/src/services/text_input.dart] ::_reportError
    // 0x877f8c: r0 = Null
    //     0x877f8c: mov             x0, NULL
    // 0x877f90: LeaveFrame
    //     0x877f90: mov             SP, fp
    //     0x877f94: ldp             fp, lr, [SP], #0x10
    // 0x877f98: ret
    //     0x877f98: ret             
    // 0x877f9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x877f9c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x877fa0: b               #0x877f78
  }
  _ attach(/* No info */) {
    // ** addr: 0x8786d4, size: 0x154
    // 0x8786d4: EnterFrame
    //     0x8786d4: stp             fp, lr, [SP, #-0x10]!
    //     0x8786d8: mov             fp, SP
    // 0x8786dc: AllocStack(0x40)
    //     0x8786dc: sub             SP, SP, #0x40
    // 0x8786e0: SetupParameters(_PlatformTextInputControl this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x8786e0: stur            x1, [fp, #-8]
    //     0x8786e4: stur            x2, [fp, #-0x10]
    // 0x8786e8: CheckStackOverflow
    //     0x8786e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8786ec: cmp             SP, x16
    //     0x8786f0: b.ls            #0x878814
    // 0x8786f4: r0 = LoadStaticField(0x67c)
    //     0x8786f4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8786f8: ldr             x0, [x0, #0xcf8]
    // 0x8786fc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x878700: cmp             w0, w16
    // 0x878704: b.ne            #0x878710
    // 0x878708: r2 = _instance
    //     0x878708: ldr             x2, [PP, #0x30b0]  ; [pp+0x30b0] Field <TextInput._instance@81206165>: static late final (offset: 0x67c)
    // 0x87870c: r0 = InitLateFinalStaticField()
    //     0x87870c: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x878710: LoadField: r1 = r0->field_f
    //     0x878710: ldur            w1, [x0, #0xf]
    // 0x878714: DecompressPointer r1
    //     0x878714: add             x1, x1, HEAP, lsl #32
    // 0x878718: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x87871c: cmp             w1, w16
    // 0x878720: b.eq            #0x87881c
    // 0x878724: LoadField: r1 = r0->field_13
    //     0x878724: ldur            w1, [x0, #0x13]
    // 0x878728: DecompressPointer r1
    //     0x878728: add             x1, x1, HEAP, lsl #32
    // 0x87872c: cmp             w1, NULL
    // 0x878730: b.eq            #0x878824
    // 0x878734: LoadField: r0 = r1->field_1b
    //     0x878734: ldur            x0, [x1, #0x1b]
    // 0x878738: ldur            x1, [fp, #-8]
    // 0x87873c: ldur            x2, [fp, #-0x10]
    // 0x878740: stur            x0, [fp, #-0x18]
    // 0x878744: r0 = _configurationToJson()
    //     0x878744: bl              #0x878828  ; [package:flutter/src/services/text_input.dart] _PlatformTextInputControl::_configurationToJson
    // 0x878748: mov             x3, x0
    // 0x87874c: ldur            x2, [fp, #-0x18]
    // 0x878750: stur            x3, [fp, #-0x10]
    // 0x878754: r0 = BoxInt64Instr(r2)
    //     0x878754: sbfiz           x0, x2, #1, #0x1f
    //     0x878758: cmp             x2, x0, asr #1
    //     0x87875c: b.eq            #0x878768
    //     0x878760: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x878764: stur            x2, [x0, #7]
    // 0x878768: r1 = Null
    //     0x878768: mov             x1, NULL
    // 0x87876c: r2 = 4
    //     0x87876c: mov             x2, #4
    // 0x878770: stur            x0, [fp, #-8]
    // 0x878774: r0 = AllocateArray()
    //     0x878774: bl              #0x13df928  ; AllocateArrayStub
    // 0x878778: mov             x2, x0
    // 0x87877c: ldur            x0, [fp, #-8]
    // 0x878780: stur            x2, [fp, #-0x20]
    // 0x878784: StoreField: r2->field_f = r0
    //     0x878784: stur            w0, [x2, #0xf]
    // 0x878788: ldur            x0, [fp, #-0x10]
    // 0x87878c: StoreField: r2->field_13 = r0
    //     0x87878c: stur            w0, [x2, #0x13]
    // 0x878790: r1 = <Object>
    //     0x878790: ldr             x1, [PP, #0x720]  ; [pp+0x720] TypeArguments: <Object>
    // 0x878794: r0 = AllocateGrowableArray()
    //     0x878794: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x878798: mov             x1, x0
    // 0x87879c: ldur            x0, [fp, #-0x20]
    // 0x8787a0: StoreField: r1->field_f = r0
    //     0x8787a0: stur            w0, [x1, #0xf]
    // 0x8787a4: r0 = 4
    //     0x8787a4: mov             x0, #4
    // 0x8787a8: StoreField: r1->field_b = r0
    //     0x8787a8: stur            w0, [x1, #0xb]
    // 0x8787ac: r16 = <void?>
    //     0x8787ac: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x8787b0: r30 = Instance_OptionalMethodChannel
    //     0x8787b0: ldr             lr, [PP, #0x43b0]  ; [pp+0x43b0] Obj!OptionalMethodChannel@129bea1
    // 0x8787b4: stp             lr, x16, [SP, #0x10]
    // 0x8787b8: r16 = "TextInput.setClient"
    //     0x8787b8: ldr             x16, [PP, #0x60d0]  ; [pp+0x60d0] "TextInput.setClient"
    // 0x8787bc: stp             x1, x16, [SP]
    // 0x8787c0: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x8787c0: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x8787c4: r0 = invokeMethod()
    //     0x8787c4: bl              #0x130ad0c  ; [package:flutter/src/services/platform_channel.dart] OptionalMethodChannel::invokeMethod
    // 0x8787c8: r1 = Function '<anonymous closure>':.
    //     0x8787c8: ldr             x1, [PP, #0x60d8]  ; [pp+0x60d8] Function: [dart:ui] Shader::Shader._ (0x13cf838)
    // 0x8787cc: r2 = Null
    //     0x8787cc: mov             x2, NULL
    // 0x8787d0: stur            x0, [fp, #-8]
    // 0x8787d4: r0 = AllocateClosure()
    //     0x8787d4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8787d8: r1 = Function '<anonymous closure>':.
    //     0x8787d8: ldr             x1, [PP, #0x60e0]  ; [pp+0x60e0] AnonymousClosure: (0x879184), in [package:flutter/src/services/text_input.dart] _PlatformTextInputControl::attach (0x8786d4)
    // 0x8787dc: r2 = Null
    //     0x8787dc: mov             x2, NULL
    // 0x8787e0: stur            x0, [fp, #-0x10]
    // 0x8787e4: r0 = AllocateClosure()
    //     0x8787e4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8787e8: r16 = <Null?>
    //     0x8787e8: ldr             x16, [PP, #0x70]  ; [pp+0x70] TypeArguments: <Null?>
    // 0x8787ec: ldur            lr, [fp, #-8]
    // 0x8787f0: stp             lr, x16, [SP, #0x10]
    // 0x8787f4: ldur            x16, [fp, #-0x10]
    // 0x8787f8: stp             x0, x16, [SP]
    // 0x8787fc: r4 = const [0x1, 0x3, 0x3, 0x2, onError, 0x2, null]
    //     0x8787fc: ldr             x4, [PP, #0x538]  ; [pp+0x538] List(7) [0x1, 0x3, 0x3, 0x2, "onError", 0x2, Null]
    // 0x878800: r0 = then()
    //     0x878800: bl              #0x1293070  ; [dart:async] _Future::then
    // 0x878804: r0 = Null
    //     0x878804: mov             x0, NULL
    // 0x878808: LeaveFrame
    //     0x878808: mov             SP, fp
    //     0x87880c: ldp             fp, lr, [SP], #0x10
    // 0x878810: ret
    //     0x878810: ret             
    // 0x878814: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x878814: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x878818: b               #0x8786f4
    // 0x87881c: r9 = _channel
    //     0x87881c: ldr             x9, [PP, #0x5968]  ; [pp+0x5968] Field <TextInput._channel@81206165>: late (offset: 0x10)
    // 0x878820: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x878820: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x878824: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x878824: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _configurationToJson(/* No info */) {
    // ** addr: 0x878828, size: 0x148
    // 0x878828: EnterFrame
    //     0x878828: stp             fp, lr, [SP, #-0x10]!
    //     0x87882c: mov             fp, SP
    // 0x878830: AllocStack(0x18)
    //     0x878830: sub             SP, SP, #0x18
    // 0x878834: SetupParameters(_PlatformTextInputControl this /* r1 => r0 */, dynamic _ /* r2 => r1 */)
    //     0x878834: mov             x0, x1
    //     0x878838: mov             x1, x2
    // 0x87883c: CheckStackOverflow
    //     0x87883c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x878840: cmp             SP, x16
    //     0x878844: b.ls            #0x878968
    // 0x878848: r0 = toJson()
    //     0x878848: bl              #0x878ab8  ; [package:flutter/src/services/text_input.dart] TextInputConfiguration::toJson
    // 0x87884c: stur            x0, [fp, #-8]
    // 0x878850: r0 = LoadStaticField(0x67c)
    //     0x878850: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x878854: ldr             x0, [x0, #0xcf8]
    // 0x878858: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x87885c: cmp             w0, w16
    // 0x878860: b.ne            #0x87886c
    // 0x878864: r2 = _instance
    //     0x878864: ldr             x2, [PP, #0x30b0]  ; [pp+0x30b0] Field <TextInput._instance@81206165>: static late final (offset: 0x67c)
    // 0x878868: r0 = InitLateFinalStaticField()
    //     0x878868: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x87886c: LoadField: r1 = r0->field_7
    //     0x87886c: ldur            w1, [x0, #7]
    // 0x878870: DecompressPointer r1
    //     0x878870: add             x1, x1, HEAP, lsl #32
    // 0x878874: stur            x1, [fp, #-0x10]
    // 0x878878: r0 = LoadStaticField(0x688)
    //     0x878878: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87887c: ldr             x0, [x0, #0xd10]
    // 0x878880: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x878884: cmp             w0, w16
    // 0x878888: b.ne            #0x878894
    // 0x87888c: r2 = instance
    //     0x87888c: ldr             x2, [PP, #0x4398]  ; [pp+0x4398] Field <_PlatformTextInputControl@81206165.instance>: static late final (offset: 0x688)
    // 0x878890: r0 = InitLateFinalStaticField()
    //     0x878890: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x878894: mov             x1, x0
    // 0x878898: ldur            x0, [fp, #-0x10]
    // 0x87889c: cmp             w0, w1
    // 0x8788a0: b.eq            #0x878958
    // 0x8788a4: ldur            x0, [fp, #-8]
    // 0x8788a8: r1 = Instance_TextInputType
    //     0x8788a8: ldr             x1, [PP, #0x60f0]  ; [pp+0x60f0] Obj!TextInputType@129b801
    // 0x8788ac: r0 = toJson()
    //     0x8788ac: bl              #0x878970  ; [package:flutter/src/services/text_input.dart] TextInputType::toJson
    // 0x8788b0: mov             x4, x0
    // 0x8788b4: ldur            x3, [fp, #-8]
    // 0x8788b8: stur            x4, [fp, #-0x18]
    // 0x8788bc: LoadField: r5 = r3->field_7
    //     0x8788bc: ldur            w5, [x3, #7]
    // 0x8788c0: DecompressPointer r5
    //     0x8788c0: add             x5, x5, HEAP, lsl #32
    // 0x8788c4: mov             x2, x5
    // 0x8788c8: stur            x5, [fp, #-0x10]
    // 0x8788cc: r0 = "inputType"
    //     0x8788cc: ldr             x0, [PP, #0x60f8]  ; [pp+0x60f8] "inputType"
    // 0x8788d0: r1 = Null
    //     0x8788d0: mov             x1, NULL
    // 0x8788d4: cmp             w2, NULL
    // 0x8788d8: b.eq            #0x8788f4
    // 0x8788dc: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x8788dc: ldur            w4, [x2, #0x17]
    // 0x8788e0: DecompressPointer r4
    //     0x8788e0: add             x4, x4, HEAP, lsl #32
    // 0x8788e4: r8 = X0
    //     0x8788e4: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x8788e8: LoadField: r9 = r4->field_7
    //     0x8788e8: ldur            x9, [x4, #7]
    // 0x8788ec: r3 = Null
    //     0x8788ec: ldr             x3, [PP, #0x6100]  ; [pp+0x6100] Null
    // 0x8788f0: blr             x9
    // 0x8788f4: ldur            x0, [fp, #-0x18]
    // 0x8788f8: ldur            x2, [fp, #-0x10]
    // 0x8788fc: r1 = Null
    //     0x8788fc: mov             x1, NULL
    // 0x878900: cmp             w2, NULL
    // 0x878904: b.eq            #0x878920
    // 0x878908: LoadField: r4 = r2->field_1b
    //     0x878908: ldur            w4, [x2, #0x1b]
    // 0x87890c: DecompressPointer r4
    //     0x87890c: add             x4, x4, HEAP, lsl #32
    // 0x878910: r8 = X1
    //     0x878910: ldr             x8, [PP, #0xf00]  ; [pp+0xf00] TypeParameter: X1
    // 0x878914: LoadField: r9 = r4->field_7
    //     0x878914: ldur            x9, [x4, #7]
    // 0x878918: r3 = Null
    //     0x878918: ldr             x3, [PP, #0x6110]  ; [pp+0x6110] Null
    // 0x87891c: blr             x9
    // 0x878920: ldur            x1, [fp, #-8]
    // 0x878924: r2 = "inputType"
    //     0x878924: ldr             x2, [PP, #0x60f8]  ; [pp+0x60f8] "inputType"
    // 0x878928: r0 = _hashCode()
    //     0x878928: bl              #0x13d8cbc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0x87892c: mov             x2, x0
    // 0x878930: r0 = BoxInt64Instr(r2)
    //     0x878930: sbfiz           x0, x2, #1, #0x1f
    //     0x878934: cmp             x2, x0, asr #1
    //     0x878938: b.eq            #0x878944
    //     0x87893c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x878940: stur            x2, [x0, #7]
    // 0x878944: ldur            x1, [fp, #-8]
    // 0x878948: ldur            x3, [fp, #-0x18]
    // 0x87894c: mov             x5, x0
    // 0x878950: r2 = "inputType"
    //     0x878950: ldr             x2, [PP, #0x60f8]  ; [pp+0x60f8] "inputType"
    // 0x878954: r0 = _set()
    //     0x878954: bl              #0x13d8170  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x878958: ldur            x0, [fp, #-8]
    // 0x87895c: LeaveFrame
    //     0x87895c: mov             SP, fp
    //     0x878960: ldp             fp, lr, [SP], #0x10
    // 0x878964: ret
    //     0x878964: ret             
    // 0x878968: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x878968: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87896c: b               #0x878848
  }
  [closure] void <anonymous closure>(dynamic, Object, StackTrace) {
    // ** addr: 0x879184, size: 0x40
    // 0x879184: EnterFrame
    //     0x879184: stp             fp, lr, [SP, #-0x10]!
    //     0x879188: mov             fp, SP
    // 0x87918c: CheckStackOverflow
    //     0x87918c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x879190: cmp             SP, x16
    //     0x879194: b.ls            #0x8791bc
    // 0x879198: ldr             x1, [fp, #0x18]
    // 0x87919c: ldr             x2, [fp, #0x10]
    // 0x8791a0: r3 = "while attaching the text input client"
    //     0x8791a0: ldr             x3, [PP, #0x60e8]  ; [pp+0x60e8] "while attaching the text input client"
    // 0x8791a4: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x8791a4: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x8791a8: r0 = _reportError()
    //     0x8791a8: bl              #0x853090  ; [package:flutter/src/services/text_input.dart] ::_reportError
    // 0x8791ac: r0 = Null
    //     0x8791ac: mov             x0, NULL
    // 0x8791b0: LeaveFrame
    //     0x8791b0: mov             SP, fp
    //     0x8791b4: ldp             fp, lr, [SP], #0x10
    // 0x8791b8: ret
    //     0x8791b8: ret             
    // 0x8791bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8791bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8791c0: b               #0x879198
  }
  static _PlatformTextInputControl instance() {
    // ** addr: 0x87af8c, size: 0x18
    // 0x87af8c: EnterFrame
    //     0x87af8c: stp             fp, lr, [SP, #-0x10]!
    //     0x87af90: mov             fp, SP
    // 0x87af94: r0 = _PlatformTextInputControl()
    //     0x87af94: bl              #0x87afa4  ; Allocate_PlatformTextInputControlStub -> _PlatformTextInputControl (size=0x8)
    // 0x87af98: LeaveFrame
    //     0x87af98: mov             SP, fp
    //     0x87af9c: ldp             fp, lr, [SP], #0x10
    // 0x87afa0: ret
    //     0x87afa0: ret             
  }
  [closure] void <anonymous closure>(dynamic, Object, StackTrace) {
    // ** addr: 0xeef928, size: 0x44
    // 0xeef928: EnterFrame
    //     0xeef928: stp             fp, lr, [SP, #-0x10]!
    //     0xeef92c: mov             fp, SP
    // 0xeef930: CheckStackOverflow
    //     0xeef930: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeef934: cmp             SP, x16
    //     0xeef938: b.ls            #0xeef964
    // 0xeef93c: ldr             x1, [fp, #0x18]
    // 0xeef940: ldr             x2, [fp, #0x10]
    // 0xeef944: r3 = "while updating text input configuration"
    //     0xeef944: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa32a8] "while updating text input configuration"
    //     0xeef948: ldr             x3, [x3, #0x2a8]
    // 0xeef94c: r4 = const [0, 0x3, 0, 0x3, null]
    //     0xeef94c: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0xeef950: r0 = _reportError()
    //     0xeef950: bl              #0x853090  ; [package:flutter/src/services/text_input.dart] ::_reportError
    // 0xeef954: r0 = Null
    //     0xeef954: mov             x0, NULL
    // 0xeef958: LeaveFrame
    //     0xeef958: mov             SP, fp
    //     0xeef95c: ldp             fp, lr, [SP], #0x10
    // 0xeef960: ret
    //     0xeef960: ret             
    // 0xeef964: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeef964: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeef968: b               #0xeef93c
  }
}

// class id: 5008, size: 0x2c, field offset: 0x8
//   const constructor, 
class TextInputStyle extends _MixinApplication3&Object&Diagnosticable {

  Map<String, dynamic> toJson(TextInputStyle) {
    // ** addr: 0x873204, size: 0x278
    // 0x873204: EnterFrame
    //     0x873204: stp             fp, lr, [SP, #-0x10]!
    //     0x873208: mov             fp, SP
    // 0x87320c: AllocStack(0x20)
    //     0x87320c: sub             SP, SP, #0x20
    // 0x873210: SetupParameters(TextInputStyle this /* r1 => r0, fp-0x8 */)
    //     0x873210: mov             x0, x1
    //     0x873214: stur            x1, [fp, #-8]
    // 0x873218: CheckStackOverflow
    //     0x873218: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87321c: cmp             SP, x16
    //     0x873220: b.ls            #0x87345c
    // 0x873224: r1 = Null
    //     0x873224: mov             x1, NULL
    // 0x873228: r2 = 32
    //     0x873228: mov             x2, #0x20
    // 0x87322c: r0 = AllocateArray()
    //     0x87322c: bl              #0x13df928  ; AllocateArrayStub
    // 0x873230: stur            x0, [fp, #-0x10]
    // 0x873234: r16 = "fontFamily"
    //     0x873234: ldr             x16, [PP, #0x4b58]  ; [pp+0x4b58] "fontFamily"
    // 0x873238: StoreField: r0->field_f = r16
    //     0x873238: stur            w16, [x0, #0xf]
    // 0x87323c: ldur            x2, [fp, #-8]
    // 0x873240: LoadField: r1 = r2->field_7
    //     0x873240: ldur            w1, [x2, #7]
    // 0x873244: DecompressPointer r1
    //     0x873244: add             x1, x1, HEAP, lsl #32
    // 0x873248: StoreField: r0->field_13 = r1
    //     0x873248: stur            w1, [x0, #0x13]
    // 0x87324c: r16 = "fontSize"
    //     0x87324c: ldr             x16, [PP, #0x4b60]  ; [pp+0x4b60] "fontSize"
    // 0x873250: ArrayStore: r0[0] = r16  ; List_4
    //     0x873250: stur            w16, [x0, #0x17]
    // 0x873254: LoadField: r1 = r2->field_b
    //     0x873254: ldur            w1, [x2, #0xb]
    // 0x873258: DecompressPointer r1
    //     0x873258: add             x1, x1, HEAP, lsl #32
    // 0x87325c: StoreField: r0->field_1b = r1
    //     0x87325c: stur            w1, [x0, #0x1b]
    // 0x873260: r16 = "fontWeightIndex"
    //     0x873260: ldr             x16, [PP, #0x59d0]  ; [pp+0x59d0] "fontWeightIndex"
    // 0x873264: StoreField: r0->field_1f = r16
    //     0x873264: stur            w16, [x0, #0x1f]
    // 0x873268: LoadField: r1 = r2->field_f
    //     0x873268: ldur            w1, [x2, #0xf]
    // 0x87326c: DecompressPointer r1
    //     0x87326c: add             x1, x1, HEAP, lsl #32
    // 0x873270: cmp             w1, NULL
    // 0x873274: b.ne            #0x873288
    // 0x873278: mov             x3, x2
    // 0x87327c: mov             x2, x0
    // 0x873280: r0 = Null
    //     0x873280: mov             x0, NULL
    // 0x873284: b               #0x8732ac
    // 0x873288: r0 = index()
    //     0x873288: bl              #0x8734c4  ; [dart:ui] FontWeight::index
    // 0x87328c: mov             x2, x0
    // 0x873290: r0 = BoxInt64Instr(r2)
    //     0x873290: sbfiz           x0, x2, #1, #0x1f
    //     0x873294: cmp             x2, x0, asr #1
    //     0x873298: b.eq            #0x8732a4
    //     0x87329c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8732a0: stur            x2, [x0, #7]
    // 0x8732a4: ldur            x3, [fp, #-8]
    // 0x8732a8: ldur            x2, [fp, #-0x10]
    // 0x8732ac: mov             x1, x2
    // 0x8732b0: ArrayStore: r1[5] = r0  ; List_4
    //     0x8732b0: add             x25, x1, #0x23
    //     0x8732b4: str             w0, [x25]
    //     0x8732b8: tbz             w0, #0, #0x8732d4
    //     0x8732bc: ldurb           w16, [x1, #-1]
    //     0x8732c0: ldurb           w17, [x0, #-1]
    //     0x8732c4: and             x16, x17, x16, lsr #2
    //     0x8732c8: tst             x16, HEAP, lsr #32
    //     0x8732cc: b.eq            #0x8732d4
    //     0x8732d0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x8732d4: r16 = "textAlignIndex"
    //     0x8732d4: ldr             x16, [PP, #0x59d8]  ; [pp+0x59d8] "textAlignIndex"
    // 0x8732d8: StoreField: r2->field_27 = r16
    //     0x8732d8: stur            w16, [x2, #0x27]
    // 0x8732dc: ArrayLoad: r0 = r3[0]  ; List_4
    //     0x8732dc: ldur            w0, [x3, #0x17]
    // 0x8732e0: DecompressPointer r0
    //     0x8732e0: add             x0, x0, HEAP, lsl #32
    // 0x8732e4: LoadField: r4 = r0->field_7
    //     0x8732e4: ldur            x4, [x0, #7]
    // 0x8732e8: r0 = BoxInt64Instr(r4)
    //     0x8732e8: sbfiz           x0, x4, #1, #0x1f
    //     0x8732ec: cmp             x4, x0, asr #1
    //     0x8732f0: b.eq            #0x8732fc
    //     0x8732f4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8732f8: stur            x4, [x0, #7]
    // 0x8732fc: mov             x1, x2
    // 0x873300: ArrayStore: r1[7] = r0  ; List_4
    //     0x873300: add             x25, x1, #0x2b
    //     0x873304: str             w0, [x25]
    //     0x873308: tbz             w0, #0, #0x873324
    //     0x87330c: ldurb           w16, [x1, #-1]
    //     0x873310: ldurb           w17, [x0, #-1]
    //     0x873314: and             x16, x17, x16, lsr #2
    //     0x873318: tst             x16, HEAP, lsr #32
    //     0x87331c: b.eq            #0x873324
    //     0x873320: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x873324: r16 = "textDirectionIndex"
    //     0x873324: ldr             x16, [PP, #0x59e0]  ; [pp+0x59e0] "textDirectionIndex"
    // 0x873328: StoreField: r2->field_2f = r16
    //     0x873328: stur            w16, [x2, #0x2f]
    // 0x87332c: LoadField: r0 = r3->field_13
    //     0x87332c: ldur            w0, [x3, #0x13]
    // 0x873330: DecompressPointer r0
    //     0x873330: add             x0, x0, HEAP, lsl #32
    // 0x873334: LoadField: r4 = r0->field_7
    //     0x873334: ldur            x4, [x0, #7]
    // 0x873338: r0 = BoxInt64Instr(r4)
    //     0x873338: sbfiz           x0, x4, #1, #0x1f
    //     0x87333c: cmp             x4, x0, asr #1
    //     0x873340: b.eq            #0x87334c
    //     0x873344: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x873348: stur            x4, [x0, #7]
    // 0x87334c: mov             x1, x2
    // 0x873350: ArrayStore: r1[9] = r0  ; List_4
    //     0x873350: add             x25, x1, #0x33
    //     0x873354: str             w0, [x25]
    //     0x873358: tbz             w0, #0, #0x873374
    //     0x87335c: ldurb           w16, [x1, #-1]
    //     0x873360: ldurb           w17, [x0, #-1]
    //     0x873364: and             x16, x17, x16, lsr #2
    //     0x873368: tst             x16, HEAP, lsr #32
    //     0x87336c: b.eq            #0x873374
    //     0x873370: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x873374: r16 = "letterSpacing"
    //     0x873374: ldr             x16, [PP, #0x4ad8]  ; [pp+0x4ad8] "letterSpacing"
    // 0x873378: StoreField: r2->field_37 = r16
    //     0x873378: stur            w16, [x2, #0x37]
    // 0x87337c: LoadField: r0 = r3->field_1b
    //     0x87337c: ldur            w0, [x3, #0x1b]
    // 0x873380: DecompressPointer r0
    //     0x873380: add             x0, x0, HEAP, lsl #32
    // 0x873384: mov             x1, x2
    // 0x873388: ArrayStore: r1[11] = r0  ; List_4
    //     0x873388: add             x25, x1, #0x3b
    //     0x87338c: str             w0, [x25]
    //     0x873390: tbz             w0, #0, #0x8733ac
    //     0x873394: ldurb           w16, [x1, #-1]
    //     0x873398: ldurb           w17, [x0, #-1]
    //     0x87339c: and             x16, x17, x16, lsr #2
    //     0x8733a0: tst             x16, HEAP, lsr #32
    //     0x8733a4: b.eq            #0x8733ac
    //     0x8733a8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x8733ac: r16 = "wordSpacing"
    //     0x8733ac: ldr             x16, [PP, #0x4af8]  ; [pp+0x4af8] "wordSpacing"
    // 0x8733b0: StoreField: r2->field_3f = r16
    //     0x8733b0: stur            w16, [x2, #0x3f]
    // 0x8733b4: LoadField: r0 = r3->field_1f
    //     0x8733b4: ldur            w0, [x3, #0x1f]
    // 0x8733b8: DecompressPointer r0
    //     0x8733b8: add             x0, x0, HEAP, lsl #32
    // 0x8733bc: mov             x1, x2
    // 0x8733c0: ArrayStore: r1[13] = r0  ; List_4
    //     0x8733c0: add             x25, x1, #0x43
    //     0x8733c4: str             w0, [x25]
    //     0x8733c8: tbz             w0, #0, #0x8733e4
    //     0x8733cc: ldurb           w16, [x1, #-1]
    //     0x8733d0: ldurb           w17, [x0, #-1]
    //     0x8733d4: and             x16, x17, x16, lsr #2
    //     0x8733d8: tst             x16, HEAP, lsr #32
    //     0x8733dc: b.eq            #0x8733e4
    //     0x8733e0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x8733e4: r16 = "lineHeight"
    //     0x8733e4: ldr             x16, [PP, #0x59e8]  ; [pp+0x59e8] "lineHeight"
    // 0x8733e8: StoreField: r2->field_47 = r16
    //     0x8733e8: stur            w16, [x2, #0x47]
    // 0x8733ec: LoadField: d0 = r3->field_23
    //     0x8733ec: ldur            d0, [x3, #0x23]
    // 0x8733f0: r0 = inline_Allocate_Double()
    //     0x8733f0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x8733f4: add             x0, x0, #0x10
    //     0x8733f8: cmp             x1, x0
    //     0x8733fc: b.ls            #0x873464
    //     0x873400: str             x0, [THR, #0x60]  ; THR::top
    //     0x873404: sub             x0, x0, #0xf
    //     0x873408: mov             x1, #0xe19c
    //     0x87340c: movk            x1, #3, lsl #16
    //     0x873410: stur            x1, [x0, #-1]
    // 0x873414: dmb             ishst
    // 0x873418: StoreField: r0->field_7 = d0
    //     0x873418: stur            d0, [x0, #7]
    // 0x87341c: mov             x1, x2
    // 0x873420: ArrayStore: r1[15] = r0  ; List_4
    //     0x873420: add             x25, x1, #0x4b
    //     0x873424: str             w0, [x25]
    //     0x873428: tbz             w0, #0, #0x873444
    //     0x87342c: ldurb           w16, [x1, #-1]
    //     0x873430: ldurb           w17, [x0, #-1]
    //     0x873434: and             x16, x17, x16, lsr #2
    //     0x873438: tst             x16, HEAP, lsr #32
    //     0x87343c: b.eq            #0x873444
    //     0x873440: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x873444: r16 = <String, dynamic>
    //     0x873444: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x873448: stp             x2, x16, [SP]
    // 0x87344c: r0 = Map._fromLiteral()
    //     0x87344c: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x873450: LeaveFrame
    //     0x873450: mov             SP, fp
    //     0x873454: ldp             fp, lr, [SP], #0x10
    // 0x873458: ret
    //     0x873458: ret             
    // 0x87345c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87345c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x873460: b               #0x873224
    // 0x873464: SaveReg d0
    //     0x873464: str             q0, [SP, #-0x10]!
    // 0x873468: SaveReg r2
    //     0x873468: str             x2, [SP, #-8]!
    // 0x87346c: r0 = AllocateDouble()
    //     0x87346c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x873470: RestoreReg r2
    //     0x873470: ldr             x2, [SP], #8
    // 0x873474: RestoreReg d0
    //     0x873474: ldr             q0, [SP], #0x10
    // 0x873478: b               #0x873418
  }
  Map<String, dynamic> toJson(TextInputStyle) {
    // ** addr: 0x873494, size: 0x48
    // 0x873494: EnterFrame
    //     0x873494: stp             fp, lr, [SP, #-0x10]!
    //     0x873498: mov             fp, SP
    // 0x87349c: CheckStackOverflow
    //     0x87349c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8734a0: cmp             SP, x16
    //     0x8734a4: b.ls            #0x8734bc
    // 0x8734a8: ldr             x1, [fp, #0x10]
    // 0x8734ac: r0 = toJson()
    //     0x8734ac: bl              #0x873204  ; [package:flutter/src/services/text_input.dart] TextInputStyle::toJson
    // 0x8734b0: LeaveFrame
    //     0x8734b0: mov             SP, fp
    //     0x8734b4: ldp             fp, lr, [SP], #0x10
    // 0x8734b8: ret
    //     0x8734b8: ret             
    // 0x8734bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8734bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8734c0: b               #0x8734a8
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x113c27c, size: 0xf8
    // 0x113c27c: EnterFrame
    //     0x113c27c: stp             fp, lr, [SP, #-0x10]!
    //     0x113c280: mov             fp, SP
    // 0x113c284: AllocStack(0x30)
    //     0x113c284: sub             SP, SP, #0x30
    // 0x113c288: CheckStackOverflow
    //     0x113c288: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x113c28c: cmp             SP, x16
    //     0x113c290: b.ls            #0x113c33c
    // 0x113c294: ldr             x0, [fp, #0x10]
    // 0x113c298: LoadField: r1 = r0->field_7
    //     0x113c298: ldur            w1, [x0, #7]
    // 0x113c29c: DecompressPointer r1
    //     0x113c29c: add             x1, x1, HEAP, lsl #32
    // 0x113c2a0: LoadField: r2 = r0->field_b
    //     0x113c2a0: ldur            w2, [x0, #0xb]
    // 0x113c2a4: DecompressPointer r2
    //     0x113c2a4: add             x2, x2, HEAP, lsl #32
    // 0x113c2a8: LoadField: r3 = r0->field_f
    //     0x113c2a8: ldur            w3, [x0, #0xf]
    // 0x113c2ac: DecompressPointer r3
    //     0x113c2ac: add             x3, x3, HEAP, lsl #32
    // 0x113c2b0: LoadField: r4 = r0->field_13
    //     0x113c2b0: ldur            w4, [x0, #0x13]
    // 0x113c2b4: DecompressPointer r4
    //     0x113c2b4: add             x4, x4, HEAP, lsl #32
    // 0x113c2b8: ArrayLoad: r5 = r0[0]  ; List_4
    //     0x113c2b8: ldur            w5, [x0, #0x17]
    // 0x113c2bc: DecompressPointer r5
    //     0x113c2bc: add             x5, x5, HEAP, lsl #32
    // 0x113c2c0: LoadField: r6 = r0->field_1b
    //     0x113c2c0: ldur            w6, [x0, #0x1b]
    // 0x113c2c4: DecompressPointer r6
    //     0x113c2c4: add             x6, x6, HEAP, lsl #32
    // 0x113c2c8: LoadField: r7 = r0->field_1f
    //     0x113c2c8: ldur            w7, [x0, #0x1f]
    // 0x113c2cc: DecompressPointer r7
    //     0x113c2cc: add             x7, x7, HEAP, lsl #32
    // 0x113c2d0: LoadField: d0 = r0->field_23
    //     0x113c2d0: ldur            d0, [x0, #0x23]
    // 0x113c2d4: r0 = inline_Allocate_Double()
    //     0x113c2d4: ldp             x0, x8, [THR, #0x60]  ; THR::top
    //     0x113c2d8: add             x0, x0, #0x10
    //     0x113c2dc: cmp             x8, x0
    //     0x113c2e0: b.ls            #0x113c344
    //     0x113c2e4: str             x0, [THR, #0x60]  ; THR::top
    //     0x113c2e8: sub             x0, x0, #0xf
    //     0x113c2ec: mov             x8, #0xe19c
    //     0x113c2f0: movk            x8, #3, lsl #16
    //     0x113c2f4: stur            x8, [x0, #-1]
    // 0x113c2f8: dmb             ishst
    // 0x113c2fc: StoreField: r0->field_7 = d0
    //     0x113c2fc: stur            d0, [x0, #7]
    // 0x113c300: stp             x4, x3, [SP, #0x20]
    // 0x113c304: stp             x6, x5, [SP, #0x10]
    // 0x113c308: stp             x0, x7, [SP]
    // 0x113c30c: r4 = const [0, 0x8, 0x6, 0x8, null]
    //     0x113c30c: add             x4, PP, #0xe, lsl #12  ; [pp+0xe090] List(5) [0, 0x8, 0x6, 0x8, Null]
    //     0x113c310: ldr             x4, [x4, #0x90]
    // 0x113c314: r0 = hash()
    //     0x113c314: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x113c318: mov             x2, x0
    // 0x113c31c: r0 = BoxInt64Instr(r2)
    //     0x113c31c: sbfiz           x0, x2, #1, #0x1f
    //     0x113c320: cmp             x2, x0, asr #1
    //     0x113c324: b.eq            #0x113c330
    //     0x113c328: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x113c32c: stur            x2, [x0, #7]
    // 0x113c330: LeaveFrame
    //     0x113c330: mov             SP, fp
    //     0x113c334: ldp             fp, lr, [SP], #0x10
    // 0x113c338: ret
    //     0x113c338: ret             
    // 0x113c33c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x113c33c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x113c340: b               #0x113c294
    // 0x113c344: SaveReg d0
    //     0x113c344: str             q0, [SP, #-0x10]!
    // 0x113c348: stp             x6, x7, [SP, #-0x10]!
    // 0x113c34c: stp             x4, x5, [SP, #-0x10]!
    // 0x113c350: stp             x2, x3, [SP, #-0x10]!
    // 0x113c354: SaveReg r1
    //     0x113c354: str             x1, [SP, #-8]!
    // 0x113c358: r0 = AllocateDouble()
    //     0x113c358: bl              #0x13df878  ; AllocateDoubleStub
    // 0x113c35c: RestoreReg r1
    //     0x113c35c: ldr             x1, [SP], #8
    // 0x113c360: ldp             x2, x3, [SP], #0x10
    // 0x113c364: ldp             x4, x5, [SP], #0x10
    // 0x113c368: ldp             x6, x7, [SP], #0x10
    // 0x113c36c: RestoreReg d0
    //     0x113c36c: ldr             q0, [SP], #0x10
    // 0x113c370: b               #0x113c2fc
  }
  _ ==(/* No info */) {
    // ** addr: 0x127a56c, size: 0x234
    // 0x127a56c: EnterFrame
    //     0x127a56c: stp             fp, lr, [SP, #-0x10]!
    //     0x127a570: mov             fp, SP
    // 0x127a574: AllocStack(0x10)
    //     0x127a574: sub             SP, SP, #0x10
    // 0x127a578: CheckStackOverflow
    //     0x127a578: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x127a57c: cmp             SP, x16
    //     0x127a580: b.ls            #0x127a798
    // 0x127a584: ldr             x0, [fp, #0x10]
    // 0x127a588: cmp             w0, NULL
    // 0x127a58c: b.ne            #0x127a5a0
    // 0x127a590: r0 = false
    //     0x127a590: add             x0, NULL, #0x30  ; false
    // 0x127a594: LeaveFrame
    //     0x127a594: mov             SP, fp
    //     0x127a598: ldp             fp, lr, [SP], #0x10
    // 0x127a59c: ret
    //     0x127a59c: ret             
    // 0x127a5a0: ldr             x1, [fp, #0x18]
    // 0x127a5a4: cmp             w1, w0
    // 0x127a5a8: b.ne            #0x127a5bc
    // 0x127a5ac: r0 = true
    //     0x127a5ac: add             x0, NULL, #0x20  ; true
    // 0x127a5b0: LeaveFrame
    //     0x127a5b0: mov             SP, fp
    //     0x127a5b4: ldp             fp, lr, [SP], #0x10
    // 0x127a5b8: ret
    //     0x127a5b8: ret             
    // 0x127a5bc: str             x0, [SP]
    // 0x127a5c0: r0 = runtimeType()
    //     0x127a5c0: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x127a5c4: r1 = LoadClassIdInstr(r0)
    //     0x127a5c4: ldur            x1, [x0, #-1]
    //     0x127a5c8: ubfx            x1, x1, #0xc, #0x14
    // 0x127a5cc: r16 = TextInputStyle
    //     0x127a5cc: add             x16, PP, #0xe, lsl #12  ; [pp+0xe1d8] Type: TextInputStyle
    //     0x127a5d0: ldr             x16, [x16, #0x1d8]
    // 0x127a5d4: stp             x16, x0, [SP]
    // 0x127a5d8: mov             x0, x1
    // 0x127a5dc: mov             lr, x0
    // 0x127a5e0: ldr             lr, [x21, lr, lsl #3]
    // 0x127a5e4: blr             lr
    // 0x127a5e8: tbz             w0, #4, #0x127a5fc
    // 0x127a5ec: r0 = false
    //     0x127a5ec: add             x0, NULL, #0x30  ; false
    // 0x127a5f0: LeaveFrame
    //     0x127a5f0: mov             SP, fp
    //     0x127a5f4: ldp             fp, lr, [SP], #0x10
    // 0x127a5f8: ret
    //     0x127a5f8: ret             
    // 0x127a5fc: ldr             x1, [fp, #0x10]
    // 0x127a600: r0 = 60
    //     0x127a600: mov             x0, #0x3c
    // 0x127a604: branchIfSmi(r1, 0x127a610)
    //     0x127a604: tbz             w1, #0, #0x127a610
    // 0x127a608: r0 = LoadClassIdInstr(r1)
    //     0x127a608: ldur            x0, [x1, #-1]
    //     0x127a60c: ubfx            x0, x0, #0xc, #0x14
    // 0x127a610: r17 = 5008
    //     0x127a610: mov             x17, #0x1390
    // 0x127a614: cmp             x0, x17
    // 0x127a618: b.ne            #0x127a788
    // 0x127a61c: ldr             x2, [fp, #0x18]
    // 0x127a620: LoadField: r0 = r1->field_7
    //     0x127a620: ldur            w0, [x1, #7]
    // 0x127a624: DecompressPointer r0
    //     0x127a624: add             x0, x0, HEAP, lsl #32
    // 0x127a628: LoadField: r3 = r2->field_7
    //     0x127a628: ldur            w3, [x2, #7]
    // 0x127a62c: DecompressPointer r3
    //     0x127a62c: add             x3, x3, HEAP, lsl #32
    // 0x127a630: r4 = LoadClassIdInstr(r0)
    //     0x127a630: ldur            x4, [x0, #-1]
    //     0x127a634: ubfx            x4, x4, #0xc, #0x14
    // 0x127a638: stp             x3, x0, [SP]
    // 0x127a63c: mov             x0, x4
    // 0x127a640: mov             lr, x0
    // 0x127a644: ldr             lr, [x21, lr, lsl #3]
    // 0x127a648: blr             lr
    // 0x127a64c: tbnz            w0, #4, #0x127a788
    // 0x127a650: ldr             x2, [fp, #0x18]
    // 0x127a654: ldr             x1, [fp, #0x10]
    // 0x127a658: LoadField: r0 = r1->field_b
    //     0x127a658: ldur            w0, [x1, #0xb]
    // 0x127a65c: DecompressPointer r0
    //     0x127a65c: add             x0, x0, HEAP, lsl #32
    // 0x127a660: LoadField: r3 = r2->field_b
    //     0x127a660: ldur            w3, [x2, #0xb]
    // 0x127a664: DecompressPointer r3
    //     0x127a664: add             x3, x3, HEAP, lsl #32
    // 0x127a668: r4 = LoadClassIdInstr(r0)
    //     0x127a668: ldur            x4, [x0, #-1]
    //     0x127a66c: ubfx            x4, x4, #0xc, #0x14
    // 0x127a670: stp             x3, x0, [SP]
    // 0x127a674: mov             x0, x4
    // 0x127a678: mov             lr, x0
    // 0x127a67c: ldr             lr, [x21, lr, lsl #3]
    // 0x127a680: blr             lr
    // 0x127a684: tbnz            w0, #4, #0x127a788
    // 0x127a688: ldr             x2, [fp, #0x18]
    // 0x127a68c: ldr             x1, [fp, #0x10]
    // 0x127a690: LoadField: r0 = r1->field_f
    //     0x127a690: ldur            w0, [x1, #0xf]
    // 0x127a694: DecompressPointer r0
    //     0x127a694: add             x0, x0, HEAP, lsl #32
    // 0x127a698: LoadField: r3 = r2->field_f
    //     0x127a698: ldur            w3, [x2, #0xf]
    // 0x127a69c: DecompressPointer r3
    //     0x127a69c: add             x3, x3, HEAP, lsl #32
    // 0x127a6a0: r4 = LoadClassIdInstr(r0)
    //     0x127a6a0: ldur            x4, [x0, #-1]
    //     0x127a6a4: ubfx            x4, x4, #0xc, #0x14
    // 0x127a6a8: stp             x3, x0, [SP]
    // 0x127a6ac: mov             x0, x4
    // 0x127a6b0: mov             lr, x0
    // 0x127a6b4: ldr             lr, [x21, lr, lsl #3]
    // 0x127a6b8: blr             lr
    // 0x127a6bc: tbnz            w0, #4, #0x127a788
    // 0x127a6c0: ldr             x2, [fp, #0x18]
    // 0x127a6c4: ldr             x1, [fp, #0x10]
    // 0x127a6c8: LoadField: r0 = r1->field_13
    //     0x127a6c8: ldur            w0, [x1, #0x13]
    // 0x127a6cc: DecompressPointer r0
    //     0x127a6cc: add             x0, x0, HEAP, lsl #32
    // 0x127a6d0: LoadField: r3 = r2->field_13
    //     0x127a6d0: ldur            w3, [x2, #0x13]
    // 0x127a6d4: DecompressPointer r3
    //     0x127a6d4: add             x3, x3, HEAP, lsl #32
    // 0x127a6d8: cmp             w0, w3
    // 0x127a6dc: b.ne            #0x127a788
    // 0x127a6e0: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x127a6e0: ldur            w0, [x1, #0x17]
    // 0x127a6e4: DecompressPointer r0
    //     0x127a6e4: add             x0, x0, HEAP, lsl #32
    // 0x127a6e8: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x127a6e8: ldur            w3, [x2, #0x17]
    // 0x127a6ec: DecompressPointer r3
    //     0x127a6ec: add             x3, x3, HEAP, lsl #32
    // 0x127a6f0: cmp             w0, w3
    // 0x127a6f4: b.ne            #0x127a788
    // 0x127a6f8: LoadField: r0 = r1->field_1b
    //     0x127a6f8: ldur            w0, [x1, #0x1b]
    // 0x127a6fc: DecompressPointer r0
    //     0x127a6fc: add             x0, x0, HEAP, lsl #32
    // 0x127a700: LoadField: r3 = r2->field_1b
    //     0x127a700: ldur            w3, [x2, #0x1b]
    // 0x127a704: DecompressPointer r3
    //     0x127a704: add             x3, x3, HEAP, lsl #32
    // 0x127a708: r4 = LoadClassIdInstr(r0)
    //     0x127a708: ldur            x4, [x0, #-1]
    //     0x127a70c: ubfx            x4, x4, #0xc, #0x14
    // 0x127a710: stp             x3, x0, [SP]
    // 0x127a714: mov             x0, x4
    // 0x127a718: mov             lr, x0
    // 0x127a71c: ldr             lr, [x21, lr, lsl #3]
    // 0x127a720: blr             lr
    // 0x127a724: tbnz            w0, #4, #0x127a788
    // 0x127a728: ldr             x2, [fp, #0x18]
    // 0x127a72c: ldr             x1, [fp, #0x10]
    // 0x127a730: LoadField: r0 = r1->field_1f
    //     0x127a730: ldur            w0, [x1, #0x1f]
    // 0x127a734: DecompressPointer r0
    //     0x127a734: add             x0, x0, HEAP, lsl #32
    // 0x127a738: LoadField: r3 = r2->field_1f
    //     0x127a738: ldur            w3, [x2, #0x1f]
    // 0x127a73c: DecompressPointer r3
    //     0x127a73c: add             x3, x3, HEAP, lsl #32
    // 0x127a740: r4 = LoadClassIdInstr(r0)
    //     0x127a740: ldur            x4, [x0, #-1]
    //     0x127a744: ubfx            x4, x4, #0xc, #0x14
    // 0x127a748: stp             x3, x0, [SP]
    // 0x127a74c: mov             x0, x4
    // 0x127a750: mov             lr, x0
    // 0x127a754: ldr             lr, [x21, lr, lsl #3]
    // 0x127a758: blr             lr
    // 0x127a75c: tbnz            w0, #4, #0x127a788
    // 0x127a760: ldr             x2, [fp, #0x18]
    // 0x127a764: ldr             x1, [fp, #0x10]
    // 0x127a768: LoadField: d0 = r1->field_23
    //     0x127a768: ldur            d0, [x1, #0x23]
    // 0x127a76c: LoadField: d1 = r2->field_23
    //     0x127a76c: ldur            d1, [x2, #0x23]
    // 0x127a770: fcmp            d0, d1
    // 0x127a774: r16 = true
    //     0x127a774: add             x16, NULL, #0x20  ; true
    // 0x127a778: r17 = false
    //     0x127a778: add             x17, NULL, #0x30  ; false
    // 0x127a77c: csel            x1, x16, x17, eq
    // 0x127a780: mov             x0, x1
    // 0x127a784: b               #0x127a78c
    // 0x127a788: r0 = false
    //     0x127a788: add             x0, NULL, #0x30  ; false
    // 0x127a78c: LeaveFrame
    //     0x127a78c: mov             SP, fp
    //     0x127a790: ldp             fp, lr, [SP], #0x10
    // 0x127a794: ret
    //     0x127a794: ret             
    // 0x127a798: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x127a798: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x127a79c: b               #0x127a584
  }
}

// class id: 8193, size: 0x14, field offset: 0x14
enum SelectionChangedCause extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11abbe8, size: 0x64
    // 0x11abbe8: EnterFrame
    //     0x11abbe8: stp             fp, lr, [SP, #-0x10]!
    //     0x11abbec: mov             fp, SP
    // 0x11abbf0: AllocStack(0x10)
    //     0x11abbf0: sub             SP, SP, #0x10
    // 0x11abbf4: SetupParameters(SelectionChangedCause this /* r1 => r0, fp-0x8 */)
    //     0x11abbf4: mov             x0, x1
    //     0x11abbf8: stur            x1, [fp, #-8]
    // 0x11abbfc: CheckStackOverflow
    //     0x11abbfc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11abc00: cmp             SP, x16
    //     0x11abc04: b.ls            #0x11abc44
    // 0x11abc08: r1 = Null
    //     0x11abc08: mov             x1, NULL
    // 0x11abc0c: r2 = 4
    //     0x11abc0c: mov             x2, #4
    // 0x11abc10: r0 = AllocateArray()
    //     0x11abc10: bl              #0x13df928  ; AllocateArrayStub
    // 0x11abc14: r16 = "SelectionChangedCause."
    //     0x11abc14: add             x16, PP, #0x10, lsl #12  ; [pp+0x10e40] "SelectionChangedCause."
    //     0x11abc18: ldr             x16, [x16, #0xe40]
    // 0x11abc1c: StoreField: r0->field_f = r16
    //     0x11abc1c: stur            w16, [x0, #0xf]
    // 0x11abc20: ldur            x1, [fp, #-8]
    // 0x11abc24: LoadField: r2 = r1->field_f
    //     0x11abc24: ldur            w2, [x1, #0xf]
    // 0x11abc28: DecompressPointer r2
    //     0x11abc28: add             x2, x2, HEAP, lsl #32
    // 0x11abc2c: StoreField: r0->field_13 = r2
    //     0x11abc2c: stur            w2, [x0, #0x13]
    // 0x11abc30: str             x0, [SP]
    // 0x11abc34: r0 = _interpolate()
    //     0x11abc34: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11abc38: LeaveFrame
    //     0x11abc38: mov             SP, fp
    //     0x11abc3c: ldp             fp, lr, [SP], #0x10
    // 0x11abc40: ret
    //     0x11abc40: ret             
    // 0x11abc44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11abc44: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11abc48: b               #0x11abc08
  }
}

// class id: 8194, size: 0x14, field offset: 0x14
enum FloatingCursorDragState extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11abb84, size: 0x64
    // 0x11abb84: EnterFrame
    //     0x11abb84: stp             fp, lr, [SP, #-0x10]!
    //     0x11abb88: mov             fp, SP
    // 0x11abb8c: AllocStack(0x10)
    //     0x11abb8c: sub             SP, SP, #0x10
    // 0x11abb90: SetupParameters(FloatingCursorDragState this /* r1 => r0, fp-0x8 */)
    //     0x11abb90: mov             x0, x1
    //     0x11abb94: stur            x1, [fp, #-8]
    // 0x11abb98: CheckStackOverflow
    //     0x11abb98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11abb9c: cmp             SP, x16
    //     0x11abba0: b.ls            #0x11abbe0
    // 0x11abba4: r1 = Null
    //     0x11abba4: mov             x1, NULL
    // 0x11abba8: r2 = 4
    //     0x11abba8: mov             x2, #4
    // 0x11abbac: r0 = AllocateArray()
    //     0x11abbac: bl              #0x13df928  ; AllocateArrayStub
    // 0x11abbb0: r16 = "FloatingCursorDragState."
    //     0x11abbb0: add             x16, PP, #0x10, lsl #12  ; [pp+0x10e38] "FloatingCursorDragState."
    //     0x11abbb4: ldr             x16, [x16, #0xe38]
    // 0x11abbb8: StoreField: r0->field_f = r16
    //     0x11abbb8: stur            w16, [x0, #0xf]
    // 0x11abbbc: ldur            x1, [fp, #-8]
    // 0x11abbc0: LoadField: r2 = r1->field_f
    //     0x11abbc0: ldur            w2, [x1, #0xf]
    // 0x11abbc4: DecompressPointer r2
    //     0x11abbc4: add             x2, x2, HEAP, lsl #32
    // 0x11abbc8: StoreField: r0->field_13 = r2
    //     0x11abbc8: stur            w2, [x0, #0x13]
    // 0x11abbcc: str             x0, [SP]
    // 0x11abbd0: r0 = _interpolate()
    //     0x11abbd0: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11abbd4: LeaveFrame
    //     0x11abbd4: mov             SP, fp
    //     0x11abbd8: ldp             fp, lr, [SP], #0x10
    // 0x11abbdc: ret
    //     0x11abbdc: ret             
    // 0x11abbe0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11abbe0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11abbe4: b               #0x11abba4
  }
}

// class id: 8195, size: 0x14, field offset: 0x14
enum TextCapitalization extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11abb20, size: 0x64
    // 0x11abb20: EnterFrame
    //     0x11abb20: stp             fp, lr, [SP, #-0x10]!
    //     0x11abb24: mov             fp, SP
    // 0x11abb28: AllocStack(0x10)
    //     0x11abb28: sub             SP, SP, #0x10
    // 0x11abb2c: SetupParameters(TextCapitalization this /* r1 => r0, fp-0x8 */)
    //     0x11abb2c: mov             x0, x1
    //     0x11abb30: stur            x1, [fp, #-8]
    // 0x11abb34: CheckStackOverflow
    //     0x11abb34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11abb38: cmp             SP, x16
    //     0x11abb3c: b.ls            #0x11abb7c
    // 0x11abb40: r1 = Null
    //     0x11abb40: mov             x1, NULL
    // 0x11abb44: r2 = 4
    //     0x11abb44: mov             x2, #4
    // 0x11abb48: r0 = AllocateArray()
    //     0x11abb48: bl              #0x13df928  ; AllocateArrayStub
    // 0x11abb4c: r16 = "TextCapitalization."
    //     0x11abb4c: add             x16, PP, #0x84, lsl #12  ; [pp+0x84d28] "TextCapitalization."
    //     0x11abb50: ldr             x16, [x16, #0xd28]
    // 0x11abb54: StoreField: r0->field_f = r16
    //     0x11abb54: stur            w16, [x0, #0xf]
    // 0x11abb58: ldur            x1, [fp, #-8]
    // 0x11abb5c: LoadField: r2 = r1->field_f
    //     0x11abb5c: ldur            w2, [x1, #0xf]
    // 0x11abb60: DecompressPointer r2
    //     0x11abb60: add             x2, x2, HEAP, lsl #32
    // 0x11abb64: StoreField: r0->field_13 = r2
    //     0x11abb64: stur            w2, [x0, #0x13]
    // 0x11abb68: str             x0, [SP]
    // 0x11abb6c: r0 = _interpolate()
    //     0x11abb6c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11abb70: LeaveFrame
    //     0x11abb70: mov             SP, fp
    //     0x11abb74: ldp             fp, lr, [SP], #0x10
    // 0x11abb78: ret
    //     0x11abb78: ret             
    // 0x11abb7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11abb7c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11abb80: b               #0x11abb40
  }
}

// class id: 8196, size: 0x14, field offset: 0x14
enum TextInputAction extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11abac0, size: 0x60
    // 0x11abac0: EnterFrame
    //     0x11abac0: stp             fp, lr, [SP, #-0x10]!
    //     0x11abac4: mov             fp, SP
    // 0x11abac8: AllocStack(0x10)
    //     0x11abac8: sub             SP, SP, #0x10
    // 0x11abacc: SetupParameters(TextInputAction this /* r1 => r0, fp-0x8 */)
    //     0x11abacc: mov             x0, x1
    //     0x11abad0: stur            x1, [fp, #-8]
    // 0x11abad4: CheckStackOverflow
    //     0x11abad4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11abad8: cmp             SP, x16
    //     0x11abadc: b.ls            #0x11abb18
    // 0x11abae0: r1 = Null
    //     0x11abae0: mov             x1, NULL
    // 0x11abae4: r2 = 4
    //     0x11abae4: mov             x2, #4
    // 0x11abae8: r0 = AllocateArray()
    //     0x11abae8: bl              #0x13df928  ; AllocateArrayStub
    // 0x11abaec: r16 = "TextInputAction."
    //     0x11abaec: ldr             x16, [PP, #0x6190]  ; [pp+0x6190] "TextInputAction."
    // 0x11abaf0: StoreField: r0->field_f = r16
    //     0x11abaf0: stur            w16, [x0, #0xf]
    // 0x11abaf4: ldur            x1, [fp, #-8]
    // 0x11abaf8: LoadField: r2 = r1->field_f
    //     0x11abaf8: ldur            w2, [x1, #0xf]
    // 0x11abafc: DecompressPointer r2
    //     0x11abafc: add             x2, x2, HEAP, lsl #32
    // 0x11abb00: StoreField: r0->field_13 = r2
    //     0x11abb00: stur            w2, [x0, #0x13]
    // 0x11abb04: str             x0, [SP]
    // 0x11abb08: r0 = _interpolate()
    //     0x11abb08: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11abb0c: LeaveFrame
    //     0x11abb0c: mov             SP, fp
    //     0x11abb10: ldp             fp, lr, [SP], #0x10
    // 0x11abb14: ret
    //     0x11abb14: ret             
    // 0x11abb18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11abb18: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11abb1c: b               #0x11abae0
  }
}

// class id: 8197, size: 0x14, field offset: 0x14
enum SmartQuotesType extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11aba5c, size: 0x64
    // 0x11aba5c: EnterFrame
    //     0x11aba5c: stp             fp, lr, [SP, #-0x10]!
    //     0x11aba60: mov             fp, SP
    // 0x11aba64: AllocStack(0x10)
    //     0x11aba64: sub             SP, SP, #0x10
    // 0x11aba68: SetupParameters(SmartQuotesType this /* r1 => r0, fp-0x8 */)
    //     0x11aba68: mov             x0, x1
    //     0x11aba6c: stur            x1, [fp, #-8]
    // 0x11aba70: CheckStackOverflow
    //     0x11aba70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11aba74: cmp             SP, x16
    //     0x11aba78: b.ls            #0x11abab8
    // 0x11aba7c: r1 = Null
    //     0x11aba7c: mov             x1, NULL
    // 0x11aba80: r2 = 4
    //     0x11aba80: mov             x2, #4
    // 0x11aba84: r0 = AllocateArray()
    //     0x11aba84: bl              #0x13df928  ; AllocateArrayStub
    // 0x11aba88: r16 = "SmartQuotesType."
    //     0x11aba88: add             x16, PP, #0x84, lsl #12  ; [pp+0x84d30] "SmartQuotesType."
    //     0x11aba8c: ldr             x16, [x16, #0xd30]
    // 0x11aba90: StoreField: r0->field_f = r16
    //     0x11aba90: stur            w16, [x0, #0xf]
    // 0x11aba94: ldur            x1, [fp, #-8]
    // 0x11aba98: LoadField: r2 = r1->field_f
    //     0x11aba98: ldur            w2, [x1, #0xf]
    // 0x11aba9c: DecompressPointer r2
    //     0x11aba9c: add             x2, x2, HEAP, lsl #32
    // 0x11abaa0: StoreField: r0->field_13 = r2
    //     0x11abaa0: stur            w2, [x0, #0x13]
    // 0x11abaa4: str             x0, [SP]
    // 0x11abaa8: r0 = _interpolate()
    //     0x11abaa8: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11abaac: LeaveFrame
    //     0x11abaac: mov             SP, fp
    //     0x11abab0: ldp             fp, lr, [SP], #0x10
    // 0x11abab4: ret
    //     0x11abab4: ret             
    // 0x11abab8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11abab8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11ababc: b               #0x11aba7c
  }
}

// class id: 8198, size: 0x14, field offset: 0x14
enum SmartDashesType extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11ab9f8, size: 0x64
    // 0x11ab9f8: EnterFrame
    //     0x11ab9f8: stp             fp, lr, [SP, #-0x10]!
    //     0x11ab9fc: mov             fp, SP
    // 0x11aba00: AllocStack(0x10)
    //     0x11aba00: sub             SP, SP, #0x10
    // 0x11aba04: SetupParameters(SmartDashesType this /* r1 => r0, fp-0x8 */)
    //     0x11aba04: mov             x0, x1
    //     0x11aba08: stur            x1, [fp, #-8]
    // 0x11aba0c: CheckStackOverflow
    //     0x11aba0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11aba10: cmp             SP, x16
    //     0x11aba14: b.ls            #0x11aba54
    // 0x11aba18: r1 = Null
    //     0x11aba18: mov             x1, NULL
    // 0x11aba1c: r2 = 4
    //     0x11aba1c: mov             x2, #4
    // 0x11aba20: r0 = AllocateArray()
    //     0x11aba20: bl              #0x13df928  ; AllocateArrayStub
    // 0x11aba24: r16 = "SmartDashesType."
    //     0x11aba24: add             x16, PP, #0x84, lsl #12  ; [pp+0x84d38] "SmartDashesType."
    //     0x11aba28: ldr             x16, [x16, #0xd38]
    // 0x11aba2c: StoreField: r0->field_f = r16
    //     0x11aba2c: stur            w16, [x0, #0xf]
    // 0x11aba30: ldur            x1, [fp, #-8]
    // 0x11aba34: LoadField: r2 = r1->field_f
    //     0x11aba34: ldur            w2, [x1, #0xf]
    // 0x11aba38: DecompressPointer r2
    //     0x11aba38: add             x2, x2, HEAP, lsl #32
    // 0x11aba3c: StoreField: r0->field_13 = r2
    //     0x11aba3c: stur            w2, [x0, #0x13]
    // 0x11aba40: str             x0, [SP]
    // 0x11aba44: r0 = _interpolate()
    //     0x11aba44: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11aba48: LeaveFrame
    //     0x11aba48: mov             SP, fp
    //     0x11aba4c: ldp             fp, lr, [SP], #0x10
    // 0x11aba50: ret
    //     0x11aba50: ret             
    // 0x11aba54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11aba54: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11aba58: b               #0x11aba18
  }
}
