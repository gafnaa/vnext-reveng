// lib: , url: package:flutter/src/services/predictive_back_event.dart

// class id: 1049084, size: 0x8
class :: {
}

// class id: 2758, size: 0x18, field offset: 0x8
//   const constructor, 
class PredictiveBackEvent extends Object {

  factory _ PredictiveBackEvent.fromMap(/* No info */) {
    // ** addr: 0x89e2b4, size: 0x338
    // 0x89e2b4: EnterFrame
    //     0x89e2b4: stp             fp, lr, [SP, #-0x10]!
    //     0x89e2b8: mov             fp, SP
    // 0x89e2bc: AllocStack(0x30)
    //     0x89e2bc: sub             SP, SP, #0x30
    // 0x89e2c0: SetupParameters(dynamic _ /* r2 => r3, fp-0x8 */)
    //     0x89e2c0: mov             x3, x2
    //     0x89e2c4: stur            x2, [fp, #-8]
    // 0x89e2c8: CheckStackOverflow
    //     0x89e2c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89e2cc: cmp             SP, x16
    //     0x89e2d0: b.ls            #0x89e5d0
    // 0x89e2d4: r0 = LoadClassIdInstr(r3)
    //     0x89e2d4: ldur            x0, [x3, #-1]
    //     0x89e2d8: ubfx            x0, x0, #0xc, #0x14
    // 0x89e2dc: mov             x1, x3
    // 0x89e2e0: r2 = "touchOffset"
    //     0x89e2e0: ldr             x2, [PP, #0x1980]  ; [pp+0x1980] "touchOffset"
    // 0x89e2e4: r0 = GDT[cid_x0 + -0xd48]()
    //     0x89e2e4: sub             lr, x0, #0xd48
    //     0x89e2e8: ldr             lr, [x21, lr, lsl #3]
    //     0x89e2ec: blr             lr
    // 0x89e2f0: mov             x3, x0
    // 0x89e2f4: r2 = Null
    //     0x89e2f4: mov             x2, NULL
    // 0x89e2f8: r1 = Null
    //     0x89e2f8: mov             x1, NULL
    // 0x89e2fc: stur            x3, [fp, #-0x10]
    // 0x89e300: r4 = 60
    //     0x89e300: mov             x4, #0x3c
    // 0x89e304: branchIfSmi(r0, 0x89e310)
    //     0x89e304: tbz             w0, #0, #0x89e310
    // 0x89e308: r4 = LoadClassIdInstr(r0)
    //     0x89e308: ldur            x4, [x0, #-1]
    //     0x89e30c: ubfx            x4, x4, #0xc, #0x14
    // 0x89e310: sub             x4, x4, #0x5a
    // 0x89e314: cmp             x4, #2
    // 0x89e318: b.ls            #0x89e328
    // 0x89e31c: r8 = List<Object?>?
    //     0x89e31c: ldr             x8, [PP, #0x1988]  ; [pp+0x1988] Type: List<Object?>?
    // 0x89e320: r3 = Null
    //     0x89e320: ldr             x3, [PP, #0x1990]  ; [pp+0x1990] Null
    // 0x89e324: r0 = List<Object?>?()
    //     0x89e324: bl              #0x823c84  ; IsType_List<Object?>?_Stub
    // 0x89e328: ldur            x1, [fp, #-0x10]
    // 0x89e32c: cmp             w1, NULL
    // 0x89e330: b.ne            #0x89e33c
    // 0x89e334: r4 = Null
    //     0x89e334: mov             x4, NULL
    // 0x89e338: b               #0x89e480
    // 0x89e33c: r0 = LoadClassIdInstr(r1)
    //     0x89e33c: ldur            x0, [x1, #-1]
    //     0x89e340: ubfx            x0, x0, #0xc, #0x14
    // 0x89e344: stp             xzr, x1, [SP]
    // 0x89e348: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x89e348: sub             lr, x0, #0xdfd
    //     0x89e34c: ldr             lr, [x21, lr, lsl #3]
    //     0x89e350: blr             lr
    // 0x89e354: mov             x3, x0
    // 0x89e358: stur            x3, [fp, #-0x18]
    // 0x89e35c: cmp             w3, NULL
    // 0x89e360: b.eq            #0x89e5d8
    // 0x89e364: r3 as num
    //     0x89e364: mov             x0, x3
    //     0x89e368: mov             x2, NULL
    //     0x89e36c: mov             x1, NULL
    //     0x89e370: tbz             w0, #0, #0x89e394
    //     0x89e374: ldur            x4, [x0, #-1]
    //     0x89e378: ubfx            x4, x4, #0xc, #0x14
    //     0x89e37c: sub             x4, x4, #0x3c
    //     0x89e380: cmp             x4, #2
    //     0x89e384: b.ls            #0x89e394
    //     0x89e388: ldr             x8, [PP, #0x398]  ; [pp+0x398] Type: num
    //     0x89e38c: ldr             x3, [PP, #0x19a0]  ; [pp+0x19a0] Null
    //     0x89e390: bl              #0x13ee9b0  ; IsType_num_Stub
    // 0x89e394: ldur            x0, [fp, #-0x18]
    // 0x89e398: r1 = 60
    //     0x89e398: mov             x1, #0x3c
    // 0x89e39c: branchIfSmi(r0, 0x89e3a8)
    //     0x89e39c: tbz             w0, #0, #0x89e3a8
    // 0x89e3a0: r1 = LoadClassIdInstr(r0)
    //     0x89e3a0: ldur            x1, [x0, #-1]
    //     0x89e3a4: ubfx            x1, x1, #0xc, #0x14
    // 0x89e3a8: str             x0, [SP]
    // 0x89e3ac: mov             x0, x1
    // 0x89e3b0: r0 = GDT[cid_x0 + -0xffd]()
    //     0x89e3b0: sub             lr, x0, #0xffd
    //     0x89e3b4: ldr             lr, [x21, lr, lsl #3]
    //     0x89e3b8: blr             lr
    // 0x89e3bc: mov             x1, x0
    // 0x89e3c0: ldur            x0, [fp, #-0x10]
    // 0x89e3c4: stur            x1, [fp, #-0x18]
    // 0x89e3c8: r2 = LoadClassIdInstr(r0)
    //     0x89e3c8: ldur            x2, [x0, #-1]
    //     0x89e3cc: ubfx            x2, x2, #0xc, #0x14
    // 0x89e3d0: r16 = 2
    //     0x89e3d0: mov             x16, #2
    // 0x89e3d4: stp             x16, x0, [SP]
    // 0x89e3d8: mov             x0, x2
    // 0x89e3dc: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x89e3dc: sub             lr, x0, #0xdfd
    //     0x89e3e0: ldr             lr, [x21, lr, lsl #3]
    //     0x89e3e4: blr             lr
    // 0x89e3e8: mov             x3, x0
    // 0x89e3ec: stur            x3, [fp, #-0x10]
    // 0x89e3f0: cmp             w3, NULL
    // 0x89e3f4: b.eq            #0x89e5dc
    // 0x89e3f8: r3 as num
    //     0x89e3f8: mov             x0, x3
    //     0x89e3fc: mov             x2, NULL
    //     0x89e400: mov             x1, NULL
    //     0x89e404: tbz             w0, #0, #0x89e428
    //     0x89e408: ldur            x4, [x0, #-1]
    //     0x89e40c: ubfx            x4, x4, #0xc, #0x14
    //     0x89e410: sub             x4, x4, #0x3c
    //     0x89e414: cmp             x4, #2
    //     0x89e418: b.ls            #0x89e428
    //     0x89e41c: ldr             x8, [PP, #0x398]  ; [pp+0x398] Type: num
    //     0x89e420: ldr             x3, [PP, #0x19b0]  ; [pp+0x19b0] Null
    //     0x89e424: bl              #0x13ee9b0  ; IsType_num_Stub
    // 0x89e428: ldur            x0, [fp, #-0x10]
    // 0x89e42c: r1 = 60
    //     0x89e42c: mov             x1, #0x3c
    // 0x89e430: branchIfSmi(r0, 0x89e43c)
    //     0x89e430: tbz             w0, #0, #0x89e43c
    // 0x89e434: r1 = LoadClassIdInstr(r0)
    //     0x89e434: ldur            x1, [x0, #-1]
    //     0x89e438: ubfx            x1, x1, #0xc, #0x14
    // 0x89e43c: str             x0, [SP]
    // 0x89e440: mov             x0, x1
    // 0x89e444: r0 = GDT[cid_x0 + -0xffd]()
    //     0x89e444: sub             lr, x0, #0xffd
    //     0x89e448: ldr             lr, [x21, lr, lsl #3]
    //     0x89e44c: blr             lr
    // 0x89e450: mov             x1, x0
    // 0x89e454: ldur            x0, [fp, #-0x18]
    // 0x89e458: stur            x1, [fp, #-0x10]
    // 0x89e45c: LoadField: d0 = r0->field_7
    //     0x89e45c: ldur            d0, [x0, #7]
    // 0x89e460: stur            d0, [fp, #-0x20]
    // 0x89e464: r0 = Offset()
    //     0x89e464: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x89e468: ldur            d0, [fp, #-0x20]
    // 0x89e46c: StoreField: r0->field_7 = d0
    //     0x89e46c: stur            d0, [x0, #7]
    // 0x89e470: ldur            x1, [fp, #-0x10]
    // 0x89e474: LoadField: d0 = r1->field_7
    //     0x89e474: ldur            d0, [x1, #7]
    // 0x89e478: StoreField: r0->field_f = d0
    //     0x89e478: stur            d0, [x0, #0xf]
    // 0x89e47c: mov             x4, x0
    // 0x89e480: ldur            x3, [fp, #-8]
    // 0x89e484: stur            x4, [fp, #-0x10]
    // 0x89e488: r0 = LoadClassIdInstr(r3)
    //     0x89e488: ldur            x0, [x3, #-1]
    //     0x89e48c: ubfx            x0, x0, #0xc, #0x14
    // 0x89e490: mov             x1, x3
    // 0x89e494: r2 = "progress"
    //     0x89e494: ldr             x2, [PP, #0x19c0]  ; [pp+0x19c0] "progress"
    // 0x89e498: r0 = GDT[cid_x0 + -0xd48]()
    //     0x89e498: sub             lr, x0, #0xd48
    //     0x89e49c: ldr             lr, [x21, lr, lsl #3]
    //     0x89e4a0: blr             lr
    // 0x89e4a4: mov             x3, x0
    // 0x89e4a8: stur            x3, [fp, #-0x18]
    // 0x89e4ac: cmp             w3, NULL
    // 0x89e4b0: b.eq            #0x89e5e0
    // 0x89e4b4: r3 as num
    //     0x89e4b4: mov             x0, x3
    //     0x89e4b8: mov             x2, NULL
    //     0x89e4bc: mov             x1, NULL
    //     0x89e4c0: tbz             w0, #0, #0x89e4e4
    //     0x89e4c4: ldur            x4, [x0, #-1]
    //     0x89e4c8: ubfx            x4, x4, #0xc, #0x14
    //     0x89e4cc: sub             x4, x4, #0x3c
    //     0x89e4d0: cmp             x4, #2
    //     0x89e4d4: b.ls            #0x89e4e4
    //     0x89e4d8: ldr             x8, [PP, #0x398]  ; [pp+0x398] Type: num
    //     0x89e4dc: ldr             x3, [PP, #0x19c8]  ; [pp+0x19c8] Null
    //     0x89e4e0: bl              #0x13ee9b0  ; IsType_num_Stub
    // 0x89e4e4: ldur            x0, [fp, #-0x18]
    // 0x89e4e8: r1 = 60
    //     0x89e4e8: mov             x1, #0x3c
    // 0x89e4ec: branchIfSmi(r0, 0x89e4f8)
    //     0x89e4ec: tbz             w0, #0, #0x89e4f8
    // 0x89e4f0: r1 = LoadClassIdInstr(r0)
    //     0x89e4f0: ldur            x1, [x0, #-1]
    //     0x89e4f4: ubfx            x1, x1, #0xc, #0x14
    // 0x89e4f8: str             x0, [SP]
    // 0x89e4fc: mov             x0, x1
    // 0x89e500: r0 = GDT[cid_x0 + -0xffd]()
    //     0x89e500: sub             lr, x0, #0xffd
    //     0x89e504: ldr             lr, [x21, lr, lsl #3]
    //     0x89e508: blr             lr
    // 0x89e50c: mov             x3, x0
    // 0x89e510: ldur            x1, [fp, #-8]
    // 0x89e514: stur            x3, [fp, #-0x18]
    // 0x89e518: r0 = LoadClassIdInstr(r1)
    //     0x89e518: ldur            x0, [x1, #-1]
    //     0x89e51c: ubfx            x0, x0, #0xc, #0x14
    // 0x89e520: r2 = "swipeEdge"
    //     0x89e520: ldr             x2, [PP, #0x19d8]  ; [pp+0x19d8] "swipeEdge"
    // 0x89e524: r0 = GDT[cid_x0 + -0xd48]()
    //     0x89e524: sub             lr, x0, #0xd48
    //     0x89e528: ldr             lr, [x21, lr, lsl #3]
    //     0x89e52c: blr             lr
    // 0x89e530: mov             x3, x0
    // 0x89e534: stur            x3, [fp, #-8]
    // 0x89e538: cmp             w3, NULL
    // 0x89e53c: b.eq            #0x89e5e4
    // 0x89e540: r3 as int
    //     0x89e540: mov             x0, x3
    //     0x89e544: mov             x2, NULL
    //     0x89e548: mov             x1, NULL
    //     0x89e54c: tbz             w0, #0, #0x89e570
    //     0x89e550: ldur            x4, [x0, #-1]
    //     0x89e554: ubfx            x4, x4, #0xc, #0x14
    //     0x89e558: sub             x4, x4, #0x3c
    //     0x89e55c: cmp             x4, #1
    //     0x89e560: b.ls            #0x89e570
    //     0x89e564: ldr             x8, [PP, #0x390]  ; [pp+0x390] Type: int
    //     0x89e568: ldr             x3, [PP, #0x19e0]  ; [pp+0x19e0] Null
    //     0x89e56c: bl              #0x13ee980  ; IsType_int_Stub
    // 0x89e570: ldur            x0, [fp, #-8]
    // 0x89e574: r2 = LoadInt32Instr(r0)
    //     0x89e574: sbfx            x2, x0, #1, #0x1f
    //     0x89e578: tbz             w0, #0, #0x89e580
    //     0x89e57c: ldur            x2, [x0, #7]
    // 0x89e580: mov             x1, x2
    // 0x89e584: r0 = 2
    //     0x89e584: mov             x0, #2
    // 0x89e588: cmp             x1, x0
    // 0x89e58c: b.hs            #0x89e5e8
    // 0x89e590: r0 = const [Instance of 'SwipeEdge', Instance of 'SwipeEdge']
    //     0x89e590: ldr             x0, [PP, #0x19f0]  ; [pp+0x19f0] List<SwipeEdge>(2)
    // 0x89e594: ArrayLoad: r1 = r0[r2]  ; Unknown_4
    //     0x89e594: add             x16, x0, x2, lsl #2
    //     0x89e598: ldur            w1, [x16, #0xf]
    // 0x89e59c: DecompressPointer r1
    //     0x89e59c: add             x1, x1, HEAP, lsl #32
    // 0x89e5a0: stur            x1, [fp, #-8]
    // 0x89e5a4: r0 = PredictiveBackEvent()
    //     0x89e5a4: bl              #0x89e5ec  ; AllocatePredictiveBackEventStub -> PredictiveBackEvent (size=0x18)
    // 0x89e5a8: ldur            x1, [fp, #-0x10]
    // 0x89e5ac: StoreField: r0->field_7 = r1
    //     0x89e5ac: stur            w1, [x0, #7]
    // 0x89e5b0: ldur            x1, [fp, #-0x18]
    // 0x89e5b4: LoadField: d0 = r1->field_7
    //     0x89e5b4: ldur            d0, [x1, #7]
    // 0x89e5b8: StoreField: r0->field_b = d0
    //     0x89e5b8: stur            d0, [x0, #0xb]
    // 0x89e5bc: ldur            x1, [fp, #-8]
    // 0x89e5c0: StoreField: r0->field_13 = r1
    //     0x89e5c0: stur            w1, [x0, #0x13]
    // 0x89e5c4: LeaveFrame
    //     0x89e5c4: mov             SP, fp
    //     0x89e5c8: ldp             fp, lr, [SP], #0x10
    // 0x89e5cc: ret
    //     0x89e5cc: ret             
    // 0x89e5d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89e5d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89e5d4: b               #0x89e2d4
    // 0x89e5d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x89e5d8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x89e5dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x89e5dc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x89e5e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x89e5e0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x89e5e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x89e5e4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x89e5e8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x89e5e8: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  get _ isButtonEvent(/* No info */) {
    // ** addr: 0x8cfd10, size: 0x68
    // 0x8cfd10: EnterFrame
    //     0x8cfd10: stp             fp, lr, [SP, #-0x10]!
    //     0x8cfd14: mov             fp, SP
    // 0x8cfd18: AllocStack(0x10)
    //     0x8cfd18: sub             SP, SP, #0x10
    // 0x8cfd1c: CheckStackOverflow
    //     0x8cfd1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8cfd20: cmp             SP, x16
    //     0x8cfd24: b.ls            #0x8cfd70
    // 0x8cfd28: LoadField: r0 = r1->field_7
    //     0x8cfd28: ldur            w0, [x1, #7]
    // 0x8cfd2c: DecompressPointer r0
    //     0x8cfd2c: add             x0, x0, HEAP, lsl #32
    // 0x8cfd30: cmp             w0, NULL
    // 0x8cfd34: b.ne            #0x8cfd40
    // 0x8cfd38: r0 = true
    //     0x8cfd38: add             x0, NULL, #0x20  ; true
    // 0x8cfd3c: b               #0x8cfd64
    // 0x8cfd40: d0 = 0.000000
    //     0x8cfd40: eor             v0.16b, v0.16b, v0.16b
    // 0x8cfd44: LoadField: d1 = r1->field_b
    //     0x8cfd44: ldur            d1, [x1, #0xb]
    // 0x8cfd48: fcmp            d1, d0
    // 0x8cfd4c: b.ne            #0x8cfd60
    // 0x8cfd50: r16 = Instance_Offset
    //     0x8cfd50: ldr             x16, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x8cfd54: stp             x16, x0, [SP]
    // 0x8cfd58: r0 = ==()
    //     0x8cfd58: bl              #0x128bd28  ; [dart:ui] Offset::==
    // 0x8cfd5c: b               #0x8cfd64
    // 0x8cfd60: r0 = false
    //     0x8cfd60: add             x0, NULL, #0x30  ; false
    // 0x8cfd64: LeaveFrame
    //     0x8cfd64: mov             SP, fp
    //     0x8cfd68: ldp             fp, lr, [SP], #0x10
    // 0x8cfd6c: ret
    //     0x8cfd6c: ret             
    // 0x8cfd70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cfd70: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cfd74: b               #0x8cfd28
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x114cdc8, size: 0xb0
    // 0x114cdc8: EnterFrame
    //     0x114cdc8: stp             fp, lr, [SP, #-0x10]!
    //     0x114cdcc: mov             fp, SP
    // 0x114cdd0: AllocStack(0x8)
    //     0x114cdd0: sub             SP, SP, #8
    // 0x114cdd4: CheckStackOverflow
    //     0x114cdd4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x114cdd8: cmp             SP, x16
    //     0x114cddc: b.ls            #0x114ce58
    // 0x114cde0: ldr             x0, [fp, #0x10]
    // 0x114cde4: LoadField: r1 = r0->field_7
    //     0x114cde4: ldur            w1, [x0, #7]
    // 0x114cde8: DecompressPointer r1
    //     0x114cde8: add             x1, x1, HEAP, lsl #32
    // 0x114cdec: LoadField: d0 = r0->field_b
    //     0x114cdec: ldur            d0, [x0, #0xb]
    // 0x114cdf0: LoadField: r2 = r0->field_13
    //     0x114cdf0: ldur            w2, [x0, #0x13]
    // 0x114cdf4: DecompressPointer r2
    //     0x114cdf4: add             x2, x2, HEAP, lsl #32
    // 0x114cdf8: r0 = inline_Allocate_Double()
    //     0x114cdf8: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0x114cdfc: add             x0, x0, #0x10
    //     0x114ce00: cmp             x3, x0
    //     0x114ce04: b.ls            #0x114ce60
    //     0x114ce08: str             x0, [THR, #0x60]  ; THR::top
    //     0x114ce0c: sub             x0, x0, #0xf
    //     0x114ce10: mov             x3, #0xe19c
    //     0x114ce14: movk            x3, #3, lsl #16
    //     0x114ce18: stur            x3, [x0, #-1]
    // 0x114ce1c: dmb             ishst
    // 0x114ce20: StoreField: r0->field_7 = d0
    //     0x114ce20: stur            d0, [x0, #7]
    // 0x114ce24: str             x2, [SP]
    // 0x114ce28: mov             x2, x0
    // 0x114ce2c: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x114ce2c: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x114ce30: r0 = hash()
    //     0x114ce30: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x114ce34: mov             x2, x0
    // 0x114ce38: r0 = BoxInt64Instr(r2)
    //     0x114ce38: sbfiz           x0, x2, #1, #0x1f
    //     0x114ce3c: cmp             x2, x0, asr #1
    //     0x114ce40: b.eq            #0x114ce4c
    //     0x114ce44: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x114ce48: stur            x2, [x0, #7]
    // 0x114ce4c: LeaveFrame
    //     0x114ce4c: mov             SP, fp
    //     0x114ce50: ldp             fp, lr, [SP], #0x10
    // 0x114ce54: ret
    //     0x114ce54: ret             
    // 0x114ce58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x114ce58: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x114ce5c: b               #0x114cde0
    // 0x114ce60: SaveReg d0
    //     0x114ce60: str             q0, [SP, #-0x10]!
    // 0x114ce64: stp             x1, x2, [SP, #-0x10]!
    // 0x114ce68: r0 = AllocateDouble()
    //     0x114ce68: bl              #0x13df878  ; AllocateDoubleStub
    // 0x114ce6c: ldp             x1, x2, [SP], #0x10
    // 0x114ce70: RestoreReg d0
    //     0x114ce70: ldr             q0, [SP], #0x10
    // 0x114ce74: b               #0x114ce20
  }
  _ ==(/* No info */) {
    // ** addr: 0x129ac98, size: 0x138
    // 0x129ac98: EnterFrame
    //     0x129ac98: stp             fp, lr, [SP, #-0x10]!
    //     0x129ac9c: mov             fp, SP
    // 0x129aca0: AllocStack(0x10)
    //     0x129aca0: sub             SP, SP, #0x10
    // 0x129aca4: CheckStackOverflow
    //     0x129aca4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x129aca8: cmp             SP, x16
    //     0x129acac: b.ls            #0x129adc8
    // 0x129acb0: ldr             x0, [fp, #0x10]
    // 0x129acb4: cmp             w0, NULL
    // 0x129acb8: b.ne            #0x129accc
    // 0x129acbc: r0 = false
    //     0x129acbc: add             x0, NULL, #0x30  ; false
    // 0x129acc0: LeaveFrame
    //     0x129acc0: mov             SP, fp
    //     0x129acc4: ldp             fp, lr, [SP], #0x10
    // 0x129acc8: ret
    //     0x129acc8: ret             
    // 0x129accc: ldr             x1, [fp, #0x18]
    // 0x129acd0: cmp             w1, w0
    // 0x129acd4: b.ne            #0x129ace8
    // 0x129acd8: r0 = true
    //     0x129acd8: add             x0, NULL, #0x20  ; true
    // 0x129acdc: LeaveFrame
    //     0x129acdc: mov             SP, fp
    //     0x129ace0: ldp             fp, lr, [SP], #0x10
    // 0x129ace4: ret
    //     0x129ace4: ret             
    // 0x129ace8: str             x0, [SP]
    // 0x129acec: r0 = runtimeType()
    //     0x129acec: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x129acf0: r1 = LoadClassIdInstr(r0)
    //     0x129acf0: ldur            x1, [x0, #-1]
    //     0x129acf4: ubfx            x1, x1, #0xc, #0x14
    // 0x129acf8: r16 = PredictiveBackEvent
    //     0x129acf8: add             x16, PP, #0xe, lsl #12  ; [pp+0xe1b0] Type: PredictiveBackEvent
    //     0x129acfc: ldr             x16, [x16, #0x1b0]
    // 0x129ad00: stp             x16, x0, [SP]
    // 0x129ad04: mov             x0, x1
    // 0x129ad08: mov             lr, x0
    // 0x129ad0c: ldr             lr, [x21, lr, lsl #3]
    // 0x129ad10: blr             lr
    // 0x129ad14: tbz             w0, #4, #0x129ad28
    // 0x129ad18: r0 = false
    //     0x129ad18: add             x0, NULL, #0x30  ; false
    // 0x129ad1c: LeaveFrame
    //     0x129ad1c: mov             SP, fp
    //     0x129ad20: ldp             fp, lr, [SP], #0x10
    // 0x129ad24: ret
    //     0x129ad24: ret             
    // 0x129ad28: ldr             x1, [fp, #0x10]
    // 0x129ad2c: r0 = 60
    //     0x129ad2c: mov             x0, #0x3c
    // 0x129ad30: branchIfSmi(r1, 0x129ad3c)
    //     0x129ad30: tbz             w1, #0, #0x129ad3c
    // 0x129ad34: r0 = LoadClassIdInstr(r1)
    //     0x129ad34: ldur            x0, [x1, #-1]
    //     0x129ad38: ubfx            x0, x0, #0xc, #0x14
    // 0x129ad3c: cmp             x0, #0xac6
    // 0x129ad40: b.ne            #0x129adb8
    // 0x129ad44: ldr             x2, [fp, #0x18]
    // 0x129ad48: LoadField: r0 = r2->field_7
    //     0x129ad48: ldur            w0, [x2, #7]
    // 0x129ad4c: DecompressPointer r0
    //     0x129ad4c: add             x0, x0, HEAP, lsl #32
    // 0x129ad50: LoadField: r3 = r1->field_7
    //     0x129ad50: ldur            w3, [x1, #7]
    // 0x129ad54: DecompressPointer r3
    //     0x129ad54: add             x3, x3, HEAP, lsl #32
    // 0x129ad58: r4 = LoadClassIdInstr(r0)
    //     0x129ad58: ldur            x4, [x0, #-1]
    //     0x129ad5c: ubfx            x4, x4, #0xc, #0x14
    // 0x129ad60: stp             x3, x0, [SP]
    // 0x129ad64: mov             x0, x4
    // 0x129ad68: mov             lr, x0
    // 0x129ad6c: ldr             lr, [x21, lr, lsl #3]
    // 0x129ad70: blr             lr
    // 0x129ad74: tbnz            w0, #4, #0x129adb8
    // 0x129ad78: ldr             x2, [fp, #0x18]
    // 0x129ad7c: ldr             x1, [fp, #0x10]
    // 0x129ad80: LoadField: d0 = r2->field_b
    //     0x129ad80: ldur            d0, [x2, #0xb]
    // 0x129ad84: LoadField: d1 = r1->field_b
    //     0x129ad84: ldur            d1, [x1, #0xb]
    // 0x129ad88: fcmp            d0, d1
    // 0x129ad8c: b.ne            #0x129adb8
    // 0x129ad90: LoadField: r3 = r2->field_13
    //     0x129ad90: ldur            w3, [x2, #0x13]
    // 0x129ad94: DecompressPointer r3
    //     0x129ad94: add             x3, x3, HEAP, lsl #32
    // 0x129ad98: LoadField: r2 = r1->field_13
    //     0x129ad98: ldur            w2, [x1, #0x13]
    // 0x129ad9c: DecompressPointer r2
    //     0x129ad9c: add             x2, x2, HEAP, lsl #32
    // 0x129ada0: cmp             w3, w2
    // 0x129ada4: r16 = true
    //     0x129ada4: add             x16, NULL, #0x20  ; true
    // 0x129ada8: r17 = false
    //     0x129ada8: add             x17, NULL, #0x30  ; false
    // 0x129adac: csel            x1, x16, x17, eq
    // 0x129adb0: mov             x0, x1
    // 0x129adb4: b               #0x129adbc
    // 0x129adb8: r0 = false
    //     0x129adb8: add             x0, NULL, #0x30  ; false
    // 0x129adbc: LeaveFrame
    //     0x129adbc: mov             SP, fp
    //     0x129adc0: ldp             fp, lr, [SP], #0x10
    // 0x129adc4: ret
    //     0x129adc4: ret             
    // 0x129adc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x129adc8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x129adcc: b               #0x129acb0
  }
}

// class id: 8206, size: 0x14, field offset: 0x14
enum SwipeEdge extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11ab6d8, size: 0x64
    // 0x11ab6d8: EnterFrame
    //     0x11ab6d8: stp             fp, lr, [SP, #-0x10]!
    //     0x11ab6dc: mov             fp, SP
    // 0x11ab6e0: AllocStack(0x10)
    //     0x11ab6e0: sub             SP, SP, #0x10
    // 0x11ab6e4: SetupParameters(SwipeEdge this /* r1 => r0, fp-0x8 */)
    //     0x11ab6e4: mov             x0, x1
    //     0x11ab6e8: stur            x1, [fp, #-8]
    // 0x11ab6ec: CheckStackOverflow
    //     0x11ab6ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11ab6f0: cmp             SP, x16
    //     0x11ab6f4: b.ls            #0x11ab734
    // 0x11ab6f8: r1 = Null
    //     0x11ab6f8: mov             x1, NULL
    // 0x11ab6fc: r2 = 4
    //     0x11ab6fc: mov             x2, #4
    // 0x11ab700: r0 = AllocateArray()
    //     0x11ab700: bl              #0x13df928  ; AllocateArrayStub
    // 0x11ab704: r16 = "SwipeEdge."
    //     0x11ab704: add             x16, PP, #0x10, lsl #12  ; [pp+0x10e30] "SwipeEdge."
    //     0x11ab708: ldr             x16, [x16, #0xe30]
    // 0x11ab70c: StoreField: r0->field_f = r16
    //     0x11ab70c: stur            w16, [x0, #0xf]
    // 0x11ab710: ldur            x1, [fp, #-8]
    // 0x11ab714: LoadField: r2 = r1->field_f
    //     0x11ab714: ldur            w2, [x1, #0xf]
    // 0x11ab718: DecompressPointer r2
    //     0x11ab718: add             x2, x2, HEAP, lsl #32
    // 0x11ab71c: StoreField: r0->field_13 = r2
    //     0x11ab71c: stur            w2, [x0, #0x13]
    // 0x11ab720: str             x0, [SP]
    // 0x11ab724: r0 = _interpolate()
    //     0x11ab724: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11ab728: LeaveFrame
    //     0x11ab728: mov             SP, fp
    //     0x11ab72c: ldp             fp, lr, [SP], #0x10
    // 0x11ab730: ret
    //     0x11ab730: ret             
    // 0x11ab734: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11ab734: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11ab738: b               #0x11ab6f8
  }
}
