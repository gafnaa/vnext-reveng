// lib: , url: package:flutter/src/services/raw_keyboard_ios.dart

// class id: 1049089, size: 0x8
class :: {
}

// class id: 5023, size: 0x20, field offset: 0x8
//   const constructor, 
class RawKeyEventDataIos extends RawKeyEventData {

  get _ logicalKey(/* No info */) {
    // ** addr: 0x114277c, size: 0x264
    // 0x114277c: EnterFrame
    //     0x114277c: stp             fp, lr, [SP, #-0x10]!
    //     0x1142780: mov             fp, SP
    // 0x1142784: AllocStack(0x28)
    //     0x1142784: sub             SP, SP, #0x28
    // 0x1142788: SetupParameters(RawKeyEventDataIos this /* r1 => r3, fp-0x18 */)
    //     0x1142788: mov             x3, x1
    //     0x114278c: stur            x1, [fp, #-0x18]
    // 0x1142790: CheckStackOverflow
    //     0x1142790: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1142794: cmp             SP, x16
    //     0x1142798: b.ls            #0x11429c8
    // 0x114279c: LoadField: r4 = r3->field_f
    //     0x114279c: ldur            x4, [x3, #0xf]
    // 0x11427a0: stur            x4, [fp, #-0x10]
    // 0x11427a4: r0 = BoxInt64Instr(r4)
    //     0x11427a4: sbfiz           x0, x4, #1, #0x1f
    //     0x11427a8: cmp             x4, x0, asr #1
    //     0x11427ac: b.eq            #0x11427b8
    //     0x11427b0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x11427b4: stur            x4, [x0, #7]
    // 0x11427b8: mov             x2, x0
    // 0x11427bc: r1 = _ConstMap len:19
    //     0x11427bc: add             x1, PP, #0xd, lsl #12  ; [pp+0xdd48] Map<int, LogicalKeyboardKey>(19)
    //     0x11427c0: ldr             x1, [x1, #0xd48]
    // 0x11427c4: stur            x0, [fp, #-8]
    // 0x11427c8: r0 = []()
    //     0x11427c8: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x11427cc: cmp             w0, NULL
    // 0x11427d0: b.eq            #0x11427e0
    // 0x11427d4: LeaveFrame
    //     0x11427d4: mov             SP, fp
    //     0x11427d8: ldp             fp, lr, [SP], #0x10
    // 0x11427dc: ret
    //     0x11427dc: ret             
    // 0x11427e0: ldur            x0, [fp, #-0x18]
    // 0x11427e4: LoadField: r3 = r0->field_b
    //     0x11427e4: ldur            w3, [x0, #0xb]
    // 0x11427e8: DecompressPointer r3
    //     0x11427e8: add             x3, x3, HEAP, lsl #32
    // 0x11427ec: mov             x2, x3
    // 0x11427f0: stur            x3, [fp, #-0x20]
    // 0x11427f4: r1 = _ConstMap len:21
    //     0x11427f4: add             x1, PP, #0xd, lsl #12  ; [pp+0xdd50] Map<String, LogicalKeyboardKey>(21)
    //     0x11427f8: ldr             x1, [x1, #0xd50]
    // 0x11427fc: r0 = []()
    //     0x11427fc: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x1142800: cmp             w0, NULL
    // 0x1142804: b.eq            #0x1142814
    // 0x1142808: LeaveFrame
    //     0x1142808: mov             SP, fp
    //     0x114280c: ldp             fp, lr, [SP], #0x10
    // 0x1142810: ret
    //     0x1142810: ret             
    // 0x1142814: ldur            x2, [fp, #-8]
    // 0x1142818: r1 = _ConstMap len:73
    //     0x1142818: add             x1, PP, #0xd, lsl #12  ; [pp+0xdd58] Map<int, LogicalKeyboardKey>(73)
    //     0x114281c: ldr             x1, [x1, #0xd58]
    // 0x1142820: r0 = []()
    //     0x1142820: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x1142824: cmp             w0, NULL
    // 0x1142828: b.eq            #0x1142838
    // 0x114282c: LeaveFrame
    //     0x114282c: mov             SP, fp
    //     0x1142830: ldp             fp, lr, [SP], #0x10
    // 0x1142834: ret
    //     0x1142834: ret             
    // 0x1142838: ldur            x2, [fp, #-0x20]
    // 0x114283c: LoadField: r0 = r2->field_7
    //     0x114283c: ldur            w0, [x2, #7]
    // 0x1142840: cbz             w0, #0x114299c
    // 0x1142844: r3 = LoadInt32Instr(r0)
    //     0x1142844: sbfx            x3, x0, #1, #0x1f
    // 0x1142848: cmp             x3, #1
    // 0x114284c: b.ne            #0x114289c
    // 0x1142850: mov             x0, x3
    // 0x1142854: r1 = 0
    //     0x1142854: mov             x1, #0
    // 0x1142858: cmp             x1, x0
    // 0x114285c: b.hs            #0x11429d0
    // 0x1142860: r0 = LoadClassIdInstr(r2)
    //     0x1142860: ldur            x0, [x2, #-1]
    //     0x1142864: ubfx            x0, x0, #0xc, #0x14
    // 0x1142868: lsl             x0, x0, #1
    // 0x114286c: cmp             w0, #0xbc
    // 0x1142870: b.ne            #0x114287c
    // 0x1142874: ArrayLoad: r0 = r2[-8]  ; TypedUnsigned_1
    //     0x1142874: ldrb            w0, [x2, #0xf]
    // 0x1142878: b               #0x1142880
    // 0x114287c: ldurh           w0, [x2, #0xf]
    // 0x1142880: cmp             x0, #0x1f
    // 0x1142884: b.gt            #0x114288c
    // 0x1142888: tbz             x0, #0x3f, #0x114299c
    // 0x114288c: cmp             x0, #0x7f
    // 0x1142890: b.lt            #0x114289c
    // 0x1142894: cmp             x0, #0x9f
    // 0x1142898: b.le            #0x114299c
    // 0x114289c: cmp             x3, #1
    // 0x11428a0: b.ne            #0x11428ec
    // 0x11428a4: mov             x0, x3
    // 0x11428a8: r1 = 0
    //     0x11428a8: mov             x1, #0
    // 0x11428ac: cmp             x1, x0
    // 0x11428b0: b.hs            #0x11429d4
    // 0x11428b4: r0 = LoadClassIdInstr(r2)
    //     0x11428b4: ldur            x0, [x2, #-1]
    //     0x11428b8: ubfx            x0, x0, #0xc, #0x14
    // 0x11428bc: lsl             x0, x0, #1
    // 0x11428c0: cmp             w0, #0xbc
    // 0x11428c4: b.ne            #0x11428d0
    // 0x11428c8: ArrayLoad: r0 = r2[-8]  ; TypedUnsigned_1
    //     0x11428c8: ldrb            w0, [x2, #0xf]
    // 0x11428cc: b               #0x11428d4
    // 0x11428d0: ldurh           w0, [x2, #0xf]
    // 0x11428d4: r17 = 63232
    //     0x11428d4: mov             x17, #0xf700
    // 0x11428d8: cmp             x0, x17
    // 0x11428dc: b.lt            #0x11428ec
    // 0x11428e0: r17 = 63743
    //     0x11428e0: mov             x17, #0xf8ff
    // 0x11428e4: cmp             x0, x17
    // 0x11428e8: b.le            #0x114299c
    // 0x11428ec: mov             x0, x3
    // 0x11428f0: r1 = 0
    //     0x11428f0: mov             x1, #0
    // 0x11428f4: cmp             x1, x0
    // 0x11428f8: b.hs            #0x11429d8
    // 0x11428fc: r4 = LoadClassIdInstr(r2)
    //     0x11428fc: ldur            x4, [x2, #-1]
    //     0x1142900: ubfx            x4, x4, #0xc, #0x14
    // 0x1142904: lsl             x4, x4, #1
    // 0x1142908: cmp             w4, #0xbc
    // 0x114290c: b.ne            #0x114291c
    // 0x1142910: ArrayLoad: r0 = r2[-8]  ; TypedUnsigned_1
    //     0x1142910: ldrb            w0, [x2, #0xf]
    // 0x1142914: mov             x5, x0
    // 0x1142918: b               #0x1142924
    // 0x114291c: ldurh           w0, [x2, #0xf]
    // 0x1142920: mov             x5, x0
    // 0x1142924: cmp             x3, #2
    // 0x1142928: b.ne            #0x1142960
    // 0x114292c: mov             x0, x3
    // 0x1142930: r1 = 1
    //     0x1142930: mov             x1, #1
    // 0x1142934: cmp             x1, x0
    // 0x1142938: b.hs            #0x11429dc
    // 0x114293c: cmp             w4, #0xbc
    // 0x1142940: b.ne            #0x114294c
    // 0x1142944: ArrayLoad: r0 = r2[-7]  ; TypedUnsigned_1
    //     0x1142944: ldrb            w0, [x2, #0x10]
    // 0x1142948: b               #0x1142950
    // 0x114294c: ldurh           w0, [x2, #0x11]
    // 0x1142950: lsl             x1, x5, #0x10
    // 0x1142954: orr             x2, x1, x0
    // 0x1142958: mov             x0, x2
    // 0x114295c: b               #0x1142964
    // 0x1142960: mov             x0, x5
    // 0x1142964: mov             x1, x0
    // 0x1142968: stur            x0, [fp, #-0x28]
    // 0x114296c: r0 = findKeyByKeyId()
    //     0x114296c: bl              #0x84a464  ; [package:flutter/src/services/keyboard_key.g.dart] LogicalKeyboardKey::findKeyByKeyId
    // 0x1142970: cmp             w0, NULL
    // 0x1142974: b.ne            #0x1142990
    // 0x1142978: ldur            x0, [fp, #-0x28]
    // 0x114297c: r0 = LogicalKeyboardKey()
    //     0x114297c: bl              #0x849274  ; AllocateLogicalKeyboardKeyStub -> LogicalKeyboardKey (size=0x10)
    // 0x1142980: mov             x1, x0
    // 0x1142984: ldur            x0, [fp, #-0x28]
    // 0x1142988: StoreField: r1->field_7 = r0
    //     0x1142988: stur            x0, [x1, #7]
    // 0x114298c: mov             x0, x1
    // 0x1142990: LeaveFrame
    //     0x1142990: mov             SP, fp
    //     0x1142994: ldp             fp, lr, [SP], #0x10
    // 0x1142998: ret
    //     0x1142998: ret             
    // 0x114299c: ldur            x0, [fp, #-0x10]
    // 0x11429a0: r16 = 81604378624
    //     0x11429a0: add             x16, PP, #0xd, lsl #12  ; [pp+0xdd60] IMM: 0x1300000000
    //     0x11429a4: ldr             x16, [x16, #0xd60]
    // 0x11429a8: orr             x1, x0, x16
    // 0x11429ac: stur            x1, [fp, #-0x28]
    // 0x11429b0: r0 = LogicalKeyboardKey()
    //     0x11429b0: bl              #0x849274  ; AllocateLogicalKeyboardKeyStub -> LogicalKeyboardKey (size=0x10)
    // 0x11429b4: ldur            x1, [fp, #-0x28]
    // 0x11429b8: StoreField: r0->field_7 = r1
    //     0x11429b8: stur            x1, [x0, #7]
    // 0x11429bc: LeaveFrame
    //     0x11429bc: mov             SP, fp
    //     0x11429c0: ldp             fp, lr, [SP], #0x10
    // 0x11429c4: ret
    //     0x11429c4: ret             
    // 0x11429c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11429c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11429cc: b               #0x114279c
    // 0x11429d0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x11429d0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x11429d4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x11429d4: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x11429d8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x11429d8: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x11429dc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x11429dc: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  get _ physicalKey(/* No info */) {
    // ** addr: 0x114761c, size: 0x80
    // 0x114761c: EnterFrame
    //     0x114761c: stp             fp, lr, [SP, #-0x10]!
    //     0x1147620: mov             fp, SP
    // 0x1147624: AllocStack(0x10)
    //     0x1147624: sub             SP, SP, #0x10
    // 0x1147628: CheckStackOverflow
    //     0x1147628: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x114762c: cmp             SP, x16
    //     0x1147630: b.ls            #0x1147694
    // 0x1147634: LoadField: r3 = r1->field_f
    //     0x1147634: ldur            x3, [x1, #0xf]
    // 0x1147638: stur            x3, [fp, #-8]
    // 0x114763c: r0 = BoxInt64Instr(r3)
    //     0x114763c: sbfiz           x0, x3, #1, #0x1f
    //     0x1147640: cmp             x3, x0, asr #1
    //     0x1147644: b.eq            #0x1147650
    //     0x1147648: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x114764c: stur            x3, [x0, #7]
    // 0x1147650: mov             x2, x0
    // 0x1147654: r1 = _ConstMap len:159
    //     0x1147654: add             x1, PP, #0xd, lsl #12  ; [pp+0xdd68] Map<int, PhysicalKeyboardKey>(159)
    //     0x1147658: ldr             x1, [x1, #0xd68]
    // 0x114765c: r0 = []()
    //     0x114765c: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x1147660: cmp             w0, NULL
    // 0x1147664: b.ne            #0x1147688
    // 0x1147668: ldur            x0, [fp, #-8]
    // 0x114766c: r17 = 81604378624
    //     0x114766c: add             x17, PP, #0xd, lsl #12  ; [pp+0xdd60] IMM: 0x1300000000
    //     0x1147670: ldr             x17, [x17, #0xd60]
    // 0x1147674: add             x1, x0, x17
    // 0x1147678: stur            x1, [fp, #-0x10]
    // 0x114767c: r0 = PhysicalKeyboardKey()
    //     0x114767c: bl              #0x8492a4  ; AllocatePhysicalKeyboardKeyStub -> PhysicalKeyboardKey (size=0x10)
    // 0x1147680: ldur            x1, [fp, #-0x10]
    // 0x1147684: StoreField: r0->field_7 = r1
    //     0x1147684: stur            x1, [x0, #7]
    // 0x1147688: LeaveFrame
    //     0x1147688: mov             SP, fp
    //     0x114768c: ldp             fp, lr, [SP], #0x10
    // 0x1147690: ret
    //     0x1147690: ret             
    // 0x1147694: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1147694: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1147698: b               #0x1147634
  }
  _ ==(/* No info */) {
    // ** addr: 0x1279d30, size: 0x16c
    // 0x1279d30: EnterFrame
    //     0x1279d30: stp             fp, lr, [SP, #-0x10]!
    //     0x1279d34: mov             fp, SP
    // 0x1279d38: AllocStack(0x10)
    //     0x1279d38: sub             SP, SP, #0x10
    // 0x1279d3c: CheckStackOverflow
    //     0x1279d3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1279d40: cmp             SP, x16
    //     0x1279d44: b.ls            #0x1279e94
    // 0x1279d48: ldr             x0, [fp, #0x10]
    // 0x1279d4c: cmp             w0, NULL
    // 0x1279d50: b.ne            #0x1279d64
    // 0x1279d54: r0 = false
    //     0x1279d54: add             x0, NULL, #0x30  ; false
    // 0x1279d58: LeaveFrame
    //     0x1279d58: mov             SP, fp
    //     0x1279d5c: ldp             fp, lr, [SP], #0x10
    // 0x1279d60: ret
    //     0x1279d60: ret             
    // 0x1279d64: ldr             x1, [fp, #0x18]
    // 0x1279d68: cmp             w1, w0
    // 0x1279d6c: b.ne            #0x1279d80
    // 0x1279d70: r0 = true
    //     0x1279d70: add             x0, NULL, #0x20  ; true
    // 0x1279d74: LeaveFrame
    //     0x1279d74: mov             SP, fp
    //     0x1279d78: ldp             fp, lr, [SP], #0x10
    // 0x1279d7c: ret
    //     0x1279d7c: ret             
    // 0x1279d80: str             x0, [SP]
    // 0x1279d84: r0 = runtimeType()
    //     0x1279d84: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x1279d88: r1 = LoadClassIdInstr(r0)
    //     0x1279d88: ldur            x1, [x0, #-1]
    //     0x1279d8c: ubfx            x1, x1, #0xc, #0x14
    // 0x1279d90: r16 = RawKeyEventDataIos
    //     0x1279d90: add             x16, PP, #0xd, lsl #12  ; [pp+0xdd40] Type: RawKeyEventDataIos
    //     0x1279d94: ldr             x16, [x16, #0xd40]
    // 0x1279d98: stp             x16, x0, [SP]
    // 0x1279d9c: mov             x0, x1
    // 0x1279da0: mov             lr, x0
    // 0x1279da4: ldr             lr, [x21, lr, lsl #3]
    // 0x1279da8: blr             lr
    // 0x1279dac: tbz             w0, #4, #0x1279dc0
    // 0x1279db0: r0 = false
    //     0x1279db0: add             x0, NULL, #0x30  ; false
    // 0x1279db4: LeaveFrame
    //     0x1279db4: mov             SP, fp
    //     0x1279db8: ldp             fp, lr, [SP], #0x10
    // 0x1279dbc: ret
    //     0x1279dbc: ret             
    // 0x1279dc0: ldr             x1, [fp, #0x10]
    // 0x1279dc4: r0 = 60
    //     0x1279dc4: mov             x0, #0x3c
    // 0x1279dc8: branchIfSmi(r1, 0x1279dd4)
    //     0x1279dc8: tbz             w1, #0, #0x1279dd4
    // 0x1279dcc: r0 = LoadClassIdInstr(r1)
    //     0x1279dcc: ldur            x0, [x1, #-1]
    //     0x1279dd0: ubfx            x0, x0, #0xc, #0x14
    // 0x1279dd4: r17 = 5023
    //     0x1279dd4: mov             x17, #0x139f
    // 0x1279dd8: cmp             x0, x17
    // 0x1279ddc: b.ne            #0x1279e84
    // 0x1279de0: ldr             x2, [fp, #0x18]
    // 0x1279de4: LoadField: r0 = r1->field_7
    //     0x1279de4: ldur            w0, [x1, #7]
    // 0x1279de8: DecompressPointer r0
    //     0x1279de8: add             x0, x0, HEAP, lsl #32
    // 0x1279dec: LoadField: r3 = r2->field_7
    //     0x1279dec: ldur            w3, [x2, #7]
    // 0x1279df0: DecompressPointer r3
    //     0x1279df0: add             x3, x3, HEAP, lsl #32
    // 0x1279df4: r4 = LoadClassIdInstr(r0)
    //     0x1279df4: ldur            x4, [x0, #-1]
    //     0x1279df8: ubfx            x4, x4, #0xc, #0x14
    // 0x1279dfc: stp             x3, x0, [SP]
    // 0x1279e00: mov             x0, x4
    // 0x1279e04: mov             lr, x0
    // 0x1279e08: ldr             lr, [x21, lr, lsl #3]
    // 0x1279e0c: blr             lr
    // 0x1279e10: tbnz            w0, #4, #0x1279e84
    // 0x1279e14: ldr             x2, [fp, #0x18]
    // 0x1279e18: ldr             x1, [fp, #0x10]
    // 0x1279e1c: LoadField: r0 = r1->field_b
    //     0x1279e1c: ldur            w0, [x1, #0xb]
    // 0x1279e20: DecompressPointer r0
    //     0x1279e20: add             x0, x0, HEAP, lsl #32
    // 0x1279e24: LoadField: r3 = r2->field_b
    //     0x1279e24: ldur            w3, [x2, #0xb]
    // 0x1279e28: DecompressPointer r3
    //     0x1279e28: add             x3, x3, HEAP, lsl #32
    // 0x1279e2c: r4 = LoadClassIdInstr(r0)
    //     0x1279e2c: ldur            x4, [x0, #-1]
    //     0x1279e30: ubfx            x4, x4, #0xc, #0x14
    // 0x1279e34: stp             x3, x0, [SP]
    // 0x1279e38: mov             x0, x4
    // 0x1279e3c: mov             lr, x0
    // 0x1279e40: ldr             lr, [x21, lr, lsl #3]
    // 0x1279e44: blr             lr
    // 0x1279e48: tbnz            w0, #4, #0x1279e84
    // 0x1279e4c: ldr             x2, [fp, #0x18]
    // 0x1279e50: ldr             x1, [fp, #0x10]
    // 0x1279e54: LoadField: r3 = r1->field_f
    //     0x1279e54: ldur            x3, [x1, #0xf]
    // 0x1279e58: LoadField: r4 = r2->field_f
    //     0x1279e58: ldur            x4, [x2, #0xf]
    // 0x1279e5c: cmp             x3, x4
    // 0x1279e60: b.ne            #0x1279e84
    // 0x1279e64: ArrayLoad: r3 = r1[0]  ; List_8
    //     0x1279e64: ldur            x3, [x1, #0x17]
    // 0x1279e68: ArrayLoad: r1 = r2[0]  ; List_8
    //     0x1279e68: ldur            x1, [x2, #0x17]
    // 0x1279e6c: cmp             x3, x1
    // 0x1279e70: r16 = true
    //     0x1279e70: add             x16, NULL, #0x20  ; true
    // 0x1279e74: r17 = false
    //     0x1279e74: add             x17, NULL, #0x30  ; false
    // 0x1279e78: csel            x2, x16, x17, eq
    // 0x1279e7c: mov             x0, x2
    // 0x1279e80: b               #0x1279e88
    // 0x1279e84: r0 = false
    //     0x1279e84: add             x0, NULL, #0x30  ; false
    // 0x1279e88: LeaveFrame
    //     0x1279e88: mov             SP, fp
    //     0x1279e8c: ldp             fp, lr, [SP], #0x10
    // 0x1279e90: ret
    //     0x1279e90: ret             
    // 0x1279e94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1279e94: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1279e98: b               #0x1279d48
  }
}
