// lib: , url: package:flutter/src/services/message_codec.dart

// class id: 1049078, size: 0x8
class :: {
}

// class id: 2787, size: 0xc, field offset: 0x8
class MissingPluginException extends Object
    implements Exception {

  _ toString(/* No info */) {
    // ** addr: 0x1115d20, size: 0x64
    // 0x1115d20: EnterFrame
    //     0x1115d20: stp             fp, lr, [SP, #-0x10]!
    //     0x1115d24: mov             fp, SP
    // 0x1115d28: AllocStack(0x8)
    //     0x1115d28: sub             SP, SP, #8
    // 0x1115d2c: CheckStackOverflow
    //     0x1115d2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1115d30: cmp             SP, x16
    //     0x1115d34: b.ls            #0x1115d7c
    // 0x1115d38: r1 = Null
    //     0x1115d38: mov             x1, NULL
    // 0x1115d3c: r2 = 6
    //     0x1115d3c: mov             x2, #6
    // 0x1115d40: r0 = AllocateArray()
    //     0x1115d40: bl              #0x13df928  ; AllocateArrayStub
    // 0x1115d44: r16 = "MissingPluginException("
    //     0x1115d44: add             x16, PP, #0xe, lsl #12  ; [pp+0xe0a8] "MissingPluginException("
    //     0x1115d48: ldr             x16, [x16, #0xa8]
    // 0x1115d4c: StoreField: r0->field_f = r16
    //     0x1115d4c: stur            w16, [x0, #0xf]
    // 0x1115d50: ldr             x1, [fp, #0x10]
    // 0x1115d54: LoadField: r2 = r1->field_7
    //     0x1115d54: ldur            w2, [x1, #7]
    // 0x1115d58: DecompressPointer r2
    //     0x1115d58: add             x2, x2, HEAP, lsl #32
    // 0x1115d5c: StoreField: r0->field_13 = r2
    //     0x1115d5c: stur            w2, [x0, #0x13]
    // 0x1115d60: r16 = ")"
    //     0x1115d60: ldr             x16, [PP, #0xe60]  ; [pp+0xe60] ")"
    // 0x1115d64: ArrayStore: r0[0] = r16  ; List_4
    //     0x1115d64: stur            w16, [x0, #0x17]
    // 0x1115d68: str             x0, [SP]
    // 0x1115d6c: r0 = _interpolate()
    //     0x1115d6c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x1115d70: LeaveFrame
    //     0x1115d70: mov             SP, fp
    //     0x1115d74: ldp             fp, lr, [SP], #0x10
    // 0x1115d78: ret
    //     0x1115d78: ret             
    // 0x1115d7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1115d7c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1115d80: b               #0x1115d38
  }
}

// class id: 2788, size: 0x18, field offset: 0x8
class PlatformException extends Object
    implements Exception {

  _ toString(/* No info */) {
    // ** addr: 0x1115c80, size: 0xa0
    // 0x1115c80: EnterFrame
    //     0x1115c80: stp             fp, lr, [SP, #-0x10]!
    //     0x1115c84: mov             fp, SP
    // 0x1115c88: AllocStack(0x8)
    //     0x1115c88: sub             SP, SP, #8
    // 0x1115c8c: CheckStackOverflow
    //     0x1115c8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1115c90: cmp             SP, x16
    //     0x1115c94: b.ls            #0x1115d18
    // 0x1115c98: r1 = Null
    //     0x1115c98: mov             x1, NULL
    // 0x1115c9c: r2 = 18
    //     0x1115c9c: mov             x2, #0x12
    // 0x1115ca0: r0 = AllocateArray()
    //     0x1115ca0: bl              #0x13df928  ; AllocateArrayStub
    // 0x1115ca4: r16 = "PlatformException("
    //     0x1115ca4: add             x16, PP, #0xe, lsl #12  ; [pp+0xe0a0] "PlatformException("
    //     0x1115ca8: ldr             x16, [x16, #0xa0]
    // 0x1115cac: StoreField: r0->field_f = r16
    //     0x1115cac: stur            w16, [x0, #0xf]
    // 0x1115cb0: ldr             x1, [fp, #0x10]
    // 0x1115cb4: LoadField: r2 = r1->field_7
    //     0x1115cb4: ldur            w2, [x1, #7]
    // 0x1115cb8: DecompressPointer r2
    //     0x1115cb8: add             x2, x2, HEAP, lsl #32
    // 0x1115cbc: StoreField: r0->field_13 = r2
    //     0x1115cbc: stur            w2, [x0, #0x13]
    // 0x1115cc0: r16 = ", "
    //     0x1115cc0: ldr             x16, [PP, #0xe80]  ; [pp+0xe80] ", "
    // 0x1115cc4: ArrayStore: r0[0] = r16  ; List_4
    //     0x1115cc4: stur            w16, [x0, #0x17]
    // 0x1115cc8: LoadField: r2 = r1->field_b
    //     0x1115cc8: ldur            w2, [x1, #0xb]
    // 0x1115ccc: DecompressPointer r2
    //     0x1115ccc: add             x2, x2, HEAP, lsl #32
    // 0x1115cd0: StoreField: r0->field_1b = r2
    //     0x1115cd0: stur            w2, [x0, #0x1b]
    // 0x1115cd4: r16 = ", "
    //     0x1115cd4: ldr             x16, [PP, #0xe80]  ; [pp+0xe80] ", "
    // 0x1115cd8: StoreField: r0->field_1f = r16
    //     0x1115cd8: stur            w16, [x0, #0x1f]
    // 0x1115cdc: LoadField: r2 = r1->field_f
    //     0x1115cdc: ldur            w2, [x1, #0xf]
    // 0x1115ce0: DecompressPointer r2
    //     0x1115ce0: add             x2, x2, HEAP, lsl #32
    // 0x1115ce4: StoreField: r0->field_23 = r2
    //     0x1115ce4: stur            w2, [x0, #0x23]
    // 0x1115ce8: r16 = ", "
    //     0x1115ce8: ldr             x16, [PP, #0xe80]  ; [pp+0xe80] ", "
    // 0x1115cec: StoreField: r0->field_27 = r16
    //     0x1115cec: stur            w16, [x0, #0x27]
    // 0x1115cf0: LoadField: r2 = r1->field_13
    //     0x1115cf0: ldur            w2, [x1, #0x13]
    // 0x1115cf4: DecompressPointer r2
    //     0x1115cf4: add             x2, x2, HEAP, lsl #32
    // 0x1115cf8: StoreField: r0->field_2b = r2
    //     0x1115cf8: stur            w2, [x0, #0x2b]
    // 0x1115cfc: r16 = ")"
    //     0x1115cfc: ldr             x16, [PP, #0xe60]  ; [pp+0xe60] ")"
    // 0x1115d00: StoreField: r0->field_2f = r16
    //     0x1115d00: stur            w16, [x0, #0x2f]
    // 0x1115d04: str             x0, [SP]
    // 0x1115d08: r0 = _interpolate()
    //     0x1115d08: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x1115d0c: LeaveFrame
    //     0x1115d0c: mov             SP, fp
    //     0x1115d10: ldp             fp, lr, [SP], #0x10
    // 0x1115d14: ret
    //     0x1115d14: ret             
    // 0x1115d18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1115d18: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1115d1c: b               #0x1115c98
  }
}

// class id: 2789, size: 0x8, field offset: 0x8
abstract class MethodCodec extends Object {
}

// class id: 2790, size: 0x10, field offset: 0x8
//   const constructor, 
class MethodCall extends Object {
}

// class id: 2791, size: 0xc, field offset: 0x8
abstract class MessageCodec<X0> extends Object {
}
