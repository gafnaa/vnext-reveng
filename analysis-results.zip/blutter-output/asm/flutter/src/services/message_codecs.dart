// lib: , url: package:flutter/src/services/message_codecs.dart

// class id: 1049079, size: 0x8
class :: {
}

// class id: 2783, size: 0xc, field offset: 0x8
//   const constructor, 
class StandardMethodCodec extends Object
    implements MethodCodec {

  StandardMessageCodec field_8;

  _ encodeMethodCall(/* No info */) {
    // ** addr: 0x1309658, size: 0xb0
    // 0x1309658: EnterFrame
    //     0x1309658: stp             fp, lr, [SP, #-0x10]!
    //     0x130965c: mov             fp, SP
    // 0x1309660: AllocStack(0x20)
    //     0x1309660: sub             SP, SP, #0x20
    // 0x1309664: SetupParameters(StandardMethodCodec this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x1309664: mov             x0, x1
    //     0x1309668: stur            x1, [fp, #-8]
    //     0x130966c: stur            x2, [fp, #-0x10]
    // 0x1309670: CheckStackOverflow
    //     0x1309670: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1309674: cmp             SP, x16
    //     0x1309678: b.ls            #0x1309700
    // 0x130967c: r1 = Null
    //     0x130967c: mov             x1, NULL
    // 0x1309680: r0 = WriteBuffer()
    //     0x1309680: bl              #0xd05154  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::WriteBuffer
    // 0x1309684: mov             x4, x0
    // 0x1309688: ldur            x0, [fp, #-8]
    // 0x130968c: stur            x4, [fp, #-0x20]
    // 0x1309690: LoadField: r5 = r0->field_7
    //     0x1309690: ldur            w5, [x0, #7]
    // 0x1309694: DecompressPointer r5
    //     0x1309694: add             x5, x5, HEAP, lsl #32
    // 0x1309698: ldur            x6, [fp, #-0x10]
    // 0x130969c: stur            x5, [fp, #-0x18]
    // 0x13096a0: LoadField: r3 = r6->field_7
    //     0x13096a0: ldur            w3, [x6, #7]
    // 0x13096a4: DecompressPointer r3
    //     0x13096a4: add             x3, x3, HEAP, lsl #32
    // 0x13096a8: r0 = LoadClassIdInstr(r5)
    //     0x13096a8: ldur            x0, [x5, #-1]
    //     0x13096ac: ubfx            x0, x0, #0xc, #0x14
    // 0x13096b0: mov             x1, x5
    // 0x13096b4: mov             x2, x4
    // 0x13096b8: r0 = GDT[cid_x0 + -0x1000]()
    //     0x13096b8: sub             lr, x0, #1, lsl #12
    //     0x13096bc: ldr             lr, [x21, lr, lsl #3]
    //     0x13096c0: blr             lr
    // 0x13096c4: ldur            x0, [fp, #-0x10]
    // 0x13096c8: LoadField: r3 = r0->field_b
    //     0x13096c8: ldur            w3, [x0, #0xb]
    // 0x13096cc: DecompressPointer r3
    //     0x13096cc: add             x3, x3, HEAP, lsl #32
    // 0x13096d0: ldur            x1, [fp, #-0x18]
    // 0x13096d4: r0 = LoadClassIdInstr(r1)
    //     0x13096d4: ldur            x0, [x1, #-1]
    //     0x13096d8: ubfx            x0, x0, #0xc, #0x14
    // 0x13096dc: ldur            x2, [fp, #-0x20]
    // 0x13096e0: r0 = GDT[cid_x0 + -0x1000]()
    //     0x13096e0: sub             lr, x0, #1, lsl #12
    //     0x13096e4: ldr             lr, [x21, lr, lsl #3]
    //     0x13096e8: blr             lr
    // 0x13096ec: ldur            x1, [fp, #-0x20]
    // 0x13096f0: r0 = done()
    //     0x13096f0: bl              #0xd0504c  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::done
    // 0x13096f4: LeaveFrame
    //     0x13096f4: mov             SP, fp
    //     0x13096f8: ldp             fp, lr, [SP], #0x10
    // 0x13096fc: ret
    //     0x13096fc: ret             
    // 0x1309700: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1309700: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1309704: b               #0x130967c
  }
  _ decodeMethodCall(/* No info */) {
    // ** addr: 0x1309968, size: 0xf0
    // 0x1309968: EnterFrame
    //     0x1309968: stp             fp, lr, [SP, #-0x10]!
    //     0x130996c: mov             fp, SP
    // 0x1309970: AllocStack(0x20)
    //     0x1309970: sub             SP, SP, #0x20
    // 0x1309974: SetupParameters(StandardMethodCodec this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x1309974: stur            x1, [fp, #-8]
    //     0x1309978: stur            x2, [fp, #-0x10]
    // 0x130997c: CheckStackOverflow
    //     0x130997c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1309980: cmp             SP, x16
    //     0x1309984: b.ls            #0x1309a4c
    // 0x1309988: cmp             w2, NULL
    // 0x130998c: b.eq            #0x1309a54
    // 0x1309990: r0 = ReadBuffer()
    //     0x1309990: bl              #0xccee0c  ; AllocateReadBufferStub -> ReadBuffer (size=0x14)
    // 0x1309994: stur            x0, [fp, #-0x20]
    // 0x1309998: StoreField: r0->field_b = rZR
    //     0x1309998: stur            xzr, [x0, #0xb]
    // 0x130999c: ldur            x3, [fp, #-0x10]
    // 0x13099a0: StoreField: r0->field_7 = r3
    //     0x13099a0: stur            w3, [x0, #7]
    // 0x13099a4: ldur            x1, [fp, #-8]
    // 0x13099a8: LoadField: r4 = r1->field_7
    //     0x13099a8: ldur            w4, [x1, #7]
    // 0x13099ac: DecompressPointer r4
    //     0x13099ac: add             x4, x4, HEAP, lsl #32
    // 0x13099b0: mov             x1, x4
    // 0x13099b4: mov             x2, x0
    // 0x13099b8: stur            x4, [fp, #-0x18]
    // 0x13099bc: r0 = readValue()
    //     0x13099bc: bl              #0xcced20  ; [package:flutter/src/services/message_codecs.dart] StandardMessageCodec::readValue
    // 0x13099c0: ldur            x1, [fp, #-0x18]
    // 0x13099c4: ldur            x2, [fp, #-0x20]
    // 0x13099c8: stur            x0, [fp, #-8]
    // 0x13099cc: r0 = readValue()
    //     0x13099cc: bl              #0xcced20  ; [package:flutter/src/services/message_codecs.dart] StandardMessageCodec::readValue
    // 0x13099d0: mov             x1, x0
    // 0x13099d4: ldur            x0, [fp, #-8]
    // 0x13099d8: stur            x1, [fp, #-0x18]
    // 0x13099dc: r2 = 60
    //     0x13099dc: mov             x2, #0x3c
    // 0x13099e0: branchIfSmi(r0, 0x13099ec)
    //     0x13099e0: tbz             w0, #0, #0x13099ec
    // 0x13099e4: r2 = LoadClassIdInstr(r0)
    //     0x13099e4: ldur            x2, [x0, #-1]
    //     0x13099e8: ubfx            x2, x2, #0xc, #0x14
    // 0x13099ec: sub             x16, x2, #0x5e
    // 0x13099f0: cmp             x16, #1
    // 0x13099f4: b.hi            #0x1309a3c
    // 0x13099f8: ldur            x3, [fp, #-0x10]
    // 0x13099fc: ldur            x2, [fp, #-0x20]
    // 0x1309a00: LoadField: r4 = r2->field_b
    //     0x1309a00: ldur            x4, [x2, #0xb]
    // 0x1309a04: LoadField: r2 = r3->field_13
    //     0x1309a04: ldur            w2, [x3, #0x13]
    // 0x1309a08: r3 = LoadInt32Instr(r2)
    //     0x1309a08: sbfx            x3, x2, #1, #0x1f
    // 0x1309a0c: cmp             x4, x3
    // 0x1309a10: b.lt            #0x1309a3c
    // 0x1309a14: r0 = MethodCall()
    //     0x1309a14: bl              #0x130995c  ; AllocateMethodCallStub -> MethodCall (size=0x10)
    // 0x1309a18: mov             x1, x0
    // 0x1309a1c: ldur            x0, [fp, #-8]
    // 0x1309a20: StoreField: r1->field_7 = r0
    //     0x1309a20: stur            w0, [x1, #7]
    // 0x1309a24: ldur            x0, [fp, #-0x18]
    // 0x1309a28: StoreField: r1->field_b = r0
    //     0x1309a28: stur            w0, [x1, #0xb]
    // 0x1309a2c: mov             x0, x1
    // 0x1309a30: LeaveFrame
    //     0x1309a30: mov             SP, fp
    //     0x1309a34: ldp             fp, lr, [SP], #0x10
    // 0x1309a38: ret
    //     0x1309a38: ret             
    // 0x1309a3c: r0 = Instance_FormatException
    //     0x1309a3c: add             x0, PP, #0xd, lsl #12  ; [pp+0xdf80] Obj!FormatException@12b8311
    //     0x1309a40: ldr             x0, [x0, #0xf80]
    // 0x1309a44: r0 = Throw()
    //     0x1309a44: bl              #0x13ddb2c  ; ThrowStub
    // 0x1309a48: brk             #0
    // 0x1309a4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1309a4c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1309a50: b               #0x1309988
    // 0x1309a54: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1309a54: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ encodeSuccessEnvelope(/* No info */) {
    // ** addr: 0x1309c48, size: 0x84
    // 0x1309c48: EnterFrame
    //     0x1309c48: stp             fp, lr, [SP, #-0x10]!
    //     0x1309c4c: mov             fp, SP
    // 0x1309c50: AllocStack(0x18)
    //     0x1309c50: sub             SP, SP, #0x18
    // 0x1309c54: SetupParameters(StandardMethodCodec this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x1309c54: mov             x0, x1
    //     0x1309c58: mov             x3, x2
    //     0x1309c5c: stur            x1, [fp, #-8]
    //     0x1309c60: stur            x2, [fp, #-0x10]
    // 0x1309c64: CheckStackOverflow
    //     0x1309c64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1309c68: cmp             SP, x16
    //     0x1309c6c: b.ls            #0x1309cc4
    // 0x1309c70: r1 = Null
    //     0x1309c70: mov             x1, NULL
    // 0x1309c74: r0 = WriteBuffer()
    //     0x1309c74: bl              #0xd05154  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::WriteBuffer
    // 0x1309c78: mov             x1, x0
    // 0x1309c7c: r2 = 0
    //     0x1309c7c: mov             x2, #0
    // 0x1309c80: stur            x0, [fp, #-0x18]
    // 0x1309c84: r0 = _add()
    //     0x1309c84: bl              #0x12f289c  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_add
    // 0x1309c88: ldur            x0, [fp, #-8]
    // 0x1309c8c: LoadField: r1 = r0->field_7
    //     0x1309c8c: ldur            w1, [x0, #7]
    // 0x1309c90: DecompressPointer r1
    //     0x1309c90: add             x1, x1, HEAP, lsl #32
    // 0x1309c94: r0 = LoadClassIdInstr(r1)
    //     0x1309c94: ldur            x0, [x1, #-1]
    //     0x1309c98: ubfx            x0, x0, #0xc, #0x14
    // 0x1309c9c: ldur            x2, [fp, #-0x18]
    // 0x1309ca0: ldur            x3, [fp, #-0x10]
    // 0x1309ca4: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1309ca4: sub             lr, x0, #1, lsl #12
    //     0x1309ca8: ldr             lr, [x21, lr, lsl #3]
    //     0x1309cac: blr             lr
    // 0x1309cb0: ldur            x1, [fp, #-0x18]
    // 0x1309cb4: r0 = done()
    //     0x1309cb4: bl              #0xd0504c  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::done
    // 0x1309cb8: LeaveFrame
    //     0x1309cb8: mov             SP, fp
    //     0x1309cbc: ldp             fp, lr, [SP], #0x10
    // 0x1309cc0: ret
    //     0x1309cc0: ret             
    // 0x1309cc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1309cc4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1309cc8: b               #0x1309c70
  }
  _ decodeEnvelope(/* No info */) {
    // ** addr: 0x130a334, size: 0x1e4
    // 0x130a334: EnterFrame
    //     0x130a334: stp             fp, lr, [SP, #-0x10]!
    //     0x130a338: mov             fp, SP
    // 0x130a33c: AllocStack(0x30)
    //     0x130a33c: sub             SP, SP, #0x30
    // 0x130a340: SetupParameters(StandardMethodCodec this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0x130a340: stur            x1, [fp, #-0x10]
    //     0x130a344: stur            x2, [fp, #-0x18]
    // 0x130a348: CheckStackOverflow
    //     0x130a348: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x130a34c: cmp             SP, x16
    //     0x130a350: b.ls            #0x130a510
    // 0x130a354: LoadField: r0 = r2->field_13
    //     0x130a354: ldur            w0, [x2, #0x13]
    // 0x130a358: r3 = LoadInt32Instr(r0)
    //     0x130a358: sbfx            x3, x0, #1, #0x1f
    // 0x130a35c: stur            x3, [fp, #-8]
    // 0x130a360: cbz             x3, #0x130a3a4
    // 0x130a364: r0 = ReadBuffer()
    //     0x130a364: bl              #0xccee0c  ; AllocateReadBufferStub -> ReadBuffer (size=0x14)
    // 0x130a368: stur            x0, [fp, #-0x20]
    // 0x130a36c: StoreField: r0->field_b = rZR
    //     0x130a36c: stur            xzr, [x0, #0xb]
    // 0x130a370: ldur            x1, [fp, #-0x18]
    // 0x130a374: StoreField: r0->field_7 = r1
    //     0x130a374: stur            w1, [x0, #7]
    // 0x130a378: mov             x1, x0
    // 0x130a37c: r0 = getUint8()
    //     0x130a37c: bl              #0xccedb8  ; [package:flutter/src/foundation/serialization.dart] ReadBuffer::getUint8
    // 0x130a380: cbnz            x0, #0x130a3b4
    // 0x130a384: ldur            x0, [fp, #-0x10]
    // 0x130a388: LoadField: r1 = r0->field_7
    //     0x130a388: ldur            w1, [x0, #7]
    // 0x130a38c: DecompressPointer r1
    //     0x130a38c: add             x1, x1, HEAP, lsl #32
    // 0x130a390: ldur            x2, [fp, #-0x20]
    // 0x130a394: r0 = readValue()
    //     0x130a394: bl              #0xcced20  ; [package:flutter/src/services/message_codecs.dart] StandardMessageCodec::readValue
    // 0x130a398: LeaveFrame
    //     0x130a398: mov             SP, fp
    //     0x130a39c: ldp             fp, lr, [SP], #0x10
    // 0x130a3a0: ret
    //     0x130a3a0: ret             
    // 0x130a3a4: r0 = Instance_FormatException
    //     0x130a3a4: add             x0, PP, #0xd, lsl #12  ; [pp+0xdf58] Obj!FormatException@12b8351
    //     0x130a3a8: ldr             x0, [x0, #0xf58]
    // 0x130a3ac: r0 = Throw()
    //     0x130a3ac: bl              #0x13ddb2c  ; ThrowStub
    // 0x130a3b0: brk             #0
    // 0x130a3b4: ldur            x0, [fp, #-0x10]
    // 0x130a3b8: ldur            x3, [fp, #-0x20]
    // 0x130a3bc: ldur            x4, [fp, #-8]
    // 0x130a3c0: LoadField: r5 = r0->field_7
    //     0x130a3c0: ldur            w5, [x0, #7]
    // 0x130a3c4: DecompressPointer r5
    //     0x130a3c4: add             x5, x5, HEAP, lsl #32
    // 0x130a3c8: mov             x1, x5
    // 0x130a3cc: mov             x2, x3
    // 0x130a3d0: stur            x5, [fp, #-0x18]
    // 0x130a3d4: r0 = readValue()
    //     0x130a3d4: bl              #0xcced20  ; [package:flutter/src/services/message_codecs.dart] StandardMessageCodec::readValue
    // 0x130a3d8: ldur            x1, [fp, #-0x18]
    // 0x130a3dc: ldur            x2, [fp, #-0x20]
    // 0x130a3e0: stur            x0, [fp, #-0x10]
    // 0x130a3e4: r0 = readValue()
    //     0x130a3e4: bl              #0xcced20  ; [package:flutter/src/services/message_codecs.dart] StandardMessageCodec::readValue
    // 0x130a3e8: ldur            x1, [fp, #-0x18]
    // 0x130a3ec: ldur            x2, [fp, #-0x20]
    // 0x130a3f0: stur            x0, [fp, #-0x28]
    // 0x130a3f4: r0 = readValue()
    //     0x130a3f4: bl              #0xcced20  ; [package:flutter/src/services/message_codecs.dart] StandardMessageCodec::readValue
    // 0x130a3f8: mov             x3, x0
    // 0x130a3fc: ldur            x0, [fp, #-0x20]
    // 0x130a400: stur            x3, [fp, #-0x30]
    // 0x130a404: LoadField: r1 = r0->field_b
    //     0x130a404: ldur            x1, [x0, #0xb]
    // 0x130a408: ldur            x4, [fp, #-8]
    // 0x130a40c: cmp             x1, x4
    // 0x130a410: b.ge            #0x130a464
    // 0x130a414: ldur            x1, [fp, #-0x18]
    // 0x130a418: mov             x2, x0
    // 0x130a41c: r0 = readValue()
    //     0x130a41c: bl              #0xcced20  ; [package:flutter/src/services/message_codecs.dart] StandardMessageCodec::readValue
    // 0x130a420: mov             x3, x0
    // 0x130a424: r2 = Null
    //     0x130a424: mov             x2, NULL
    // 0x130a428: r1 = Null
    //     0x130a428: mov             x1, NULL
    // 0x130a42c: stur            x3, [fp, #-0x18]
    // 0x130a430: r4 = 60
    //     0x130a430: mov             x4, #0x3c
    // 0x130a434: branchIfSmi(r0, 0x130a440)
    //     0x130a434: tbz             w0, #0, #0x130a440
    // 0x130a438: r4 = LoadClassIdInstr(r0)
    //     0x130a438: ldur            x4, [x0, #-1]
    //     0x130a43c: ubfx            x4, x4, #0xc, #0x14
    // 0x130a440: sub             x4, x4, #0x5e
    // 0x130a444: cmp             x4, #1
    // 0x130a448: b.ls            #0x130a45c
    // 0x130a44c: r8 = String?
    //     0x130a44c: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x130a450: r3 = Null
    //     0x130a450: add             x3, PP, #0xd, lsl #12  ; [pp+0xdf60] Null
    //     0x130a454: ldr             x3, [x3, #0xf60]
    // 0x130a458: r0 = String?()
    //     0x130a458: bl              #0x7db310  ; IsType_String?_Stub
    // 0x130a45c: ldur            x1, [fp, #-0x18]
    // 0x130a460: b               #0x130a468
    // 0x130a464: r1 = Null
    //     0x130a464: mov             x1, NULL
    // 0x130a468: ldur            x0, [fp, #-0x10]
    // 0x130a46c: stur            x1, [fp, #-0x18]
    // 0x130a470: r2 = 60
    //     0x130a470: mov             x2, #0x3c
    // 0x130a474: branchIfSmi(r0, 0x130a480)
    //     0x130a474: tbz             w0, #0, #0x130a480
    // 0x130a478: r2 = LoadClassIdInstr(r0)
    //     0x130a478: ldur            x2, [x0, #-1]
    //     0x130a47c: ubfx            x2, x2, #0xc, #0x14
    // 0x130a480: sub             x16, x2, #0x5e
    // 0x130a484: cmp             x16, #1
    // 0x130a488: b.hi            #0x130a500
    // 0x130a48c: ldur            x2, [fp, #-0x28]
    // 0x130a490: cmp             w2, NULL
    // 0x130a494: b.eq            #0x130a4b4
    // 0x130a498: r3 = 60
    //     0x130a498: mov             x3, #0x3c
    // 0x130a49c: branchIfSmi(r2, 0x130a4a8)
    //     0x130a49c: tbz             w2, #0, #0x130a4a8
    // 0x130a4a0: r3 = LoadClassIdInstr(r2)
    //     0x130a4a0: ldur            x3, [x2, #-1]
    //     0x130a4a4: ubfx            x3, x3, #0xc, #0x14
    // 0x130a4a8: sub             x16, x3, #0x5e
    // 0x130a4ac: cmp             x16, #1
    // 0x130a4b0: b.hi            #0x130a500
    // 0x130a4b4: ldur            x3, [fp, #-0x20]
    // 0x130a4b8: ldur            x4, [fp, #-8]
    // 0x130a4bc: LoadField: r5 = r3->field_b
    //     0x130a4bc: ldur            x5, [x3, #0xb]
    // 0x130a4c0: cmp             x5, x4
    // 0x130a4c4: b.lt            #0x130a500
    // 0x130a4c8: ldur            x3, [fp, #-0x30]
    // 0x130a4cc: r0 = PlatformException()
    //     0x130a4cc: bl              #0x8bf90c  ; AllocatePlatformExceptionStub -> PlatformException (size=0x18)
    // 0x130a4d0: mov             x1, x0
    // 0x130a4d4: ldur            x0, [fp, #-0x10]
    // 0x130a4d8: StoreField: r1->field_7 = r0
    //     0x130a4d8: stur            w0, [x1, #7]
    // 0x130a4dc: ldur            x0, [fp, #-0x28]
    // 0x130a4e0: StoreField: r1->field_b = r0
    //     0x130a4e0: stur            w0, [x1, #0xb]
    // 0x130a4e4: ldur            x0, [fp, #-0x30]
    // 0x130a4e8: StoreField: r1->field_f = r0
    //     0x130a4e8: stur            w0, [x1, #0xf]
    // 0x130a4ec: ldur            x0, [fp, #-0x18]
    // 0x130a4f0: StoreField: r1->field_13 = r0
    //     0x130a4f0: stur            w0, [x1, #0x13]
    // 0x130a4f4: mov             x0, x1
    // 0x130a4f8: r0 = Throw()
    //     0x130a4f8: bl              #0x13ddb2c  ; ThrowStub
    // 0x130a4fc: brk             #0
    // 0x130a500: r0 = Instance_FormatException
    //     0x130a500: add             x0, PP, #0xd, lsl #12  ; [pp+0xdf70] Obj!FormatException@12b8331
    //     0x130a504: ldr             x0, [x0, #0xf70]
    // 0x130a508: r0 = Throw()
    //     0x130a508: bl              #0x13ddb2c  ; ThrowStub
    // 0x130a50c: brk             #0
    // 0x130a510: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x130a510: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x130a514: b               #0x130a354
  }
  _ encodeErrorEnvelope(/* No info */) {
    // ** addr: 0x130a5ec, size: 0x114
    // 0x130a5ec: EnterFrame
    //     0x130a5ec: stp             fp, lr, [SP, #-0x10]!
    //     0x130a5f0: mov             fp, SP
    // 0x130a5f4: AllocStack(0x30)
    //     0x130a5f4: sub             SP, SP, #0x30
    // 0x130a5f8: SetupParameters(StandardMethodCodec this /* r1 => r2, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */, {dynamic details = Null /* r4, fp-0x8 */})
    //     0x130a5f8: mov             x0, x2
    //     0x130a5fc: stur            x2, [fp, #-0x18]
    //     0x130a600: mov             x2, x1
    //     0x130a604: stur            x1, [fp, #-0x10]
    //     0x130a608: stur            x3, [fp, #-0x20]
    //     0x130a60c: ldur            w1, [x4, #0x13]
    //     0x130a610: ldur            w5, [x4, #0x1f]
    //     0x130a614: add             x5, x5, HEAP, lsl #32
    //     0x130a618: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf78] "details"
    //     0x130a61c: ldr             x16, [x16, #0xf78]
    //     0x130a620: cmp             w5, w16
    //     0x130a624: b.ne            #0x130a644
    //     0x130a628: ldur            w5, [x4, #0x23]
    //     0x130a62c: add             x5, x5, HEAP, lsl #32
    //     0x130a630: sub             w4, w1, w5
    //     0x130a634: add             x1, fp, w4, sxtw #2
    //     0x130a638: ldr             x1, [x1, #8]
    //     0x130a63c: mov             x4, x1
    //     0x130a640: b               #0x130a648
    //     0x130a644: mov             x4, NULL
    //     0x130a648: stur            x4, [fp, #-8]
    // 0x130a64c: CheckStackOverflow
    //     0x130a64c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x130a650: cmp             SP, x16
    //     0x130a654: b.ls            #0x130a6f8
    // 0x130a658: r1 = Null
    //     0x130a658: mov             x1, NULL
    // 0x130a65c: r0 = WriteBuffer()
    //     0x130a65c: bl              #0xd05154  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::WriteBuffer
    // 0x130a660: mov             x1, x0
    // 0x130a664: r2 = 1
    //     0x130a664: mov             x2, #1
    // 0x130a668: stur            x0, [fp, #-0x28]
    // 0x130a66c: r0 = _add()
    //     0x130a66c: bl              #0x12f289c  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_add
    // 0x130a670: ldur            x0, [fp, #-0x10]
    // 0x130a674: LoadField: r4 = r0->field_7
    //     0x130a674: ldur            w4, [x0, #7]
    // 0x130a678: DecompressPointer r4
    //     0x130a678: add             x4, x4, HEAP, lsl #32
    // 0x130a67c: stur            x4, [fp, #-0x30]
    // 0x130a680: r0 = LoadClassIdInstr(r4)
    //     0x130a680: ldur            x0, [x4, #-1]
    //     0x130a684: ubfx            x0, x0, #0xc, #0x14
    // 0x130a688: mov             x1, x4
    // 0x130a68c: ldur            x2, [fp, #-0x28]
    // 0x130a690: ldur            x3, [fp, #-0x18]
    // 0x130a694: r0 = GDT[cid_x0 + -0x1000]()
    //     0x130a694: sub             lr, x0, #1, lsl #12
    //     0x130a698: ldr             lr, [x21, lr, lsl #3]
    //     0x130a69c: blr             lr
    // 0x130a6a0: ldur            x4, [fp, #-0x30]
    // 0x130a6a4: r0 = LoadClassIdInstr(r4)
    //     0x130a6a4: ldur            x0, [x4, #-1]
    //     0x130a6a8: ubfx            x0, x0, #0xc, #0x14
    // 0x130a6ac: mov             x1, x4
    // 0x130a6b0: ldur            x2, [fp, #-0x28]
    // 0x130a6b4: ldur            x3, [fp, #-0x20]
    // 0x130a6b8: r0 = GDT[cid_x0 + -0x1000]()
    //     0x130a6b8: sub             lr, x0, #1, lsl #12
    //     0x130a6bc: ldr             lr, [x21, lr, lsl #3]
    //     0x130a6c0: blr             lr
    // 0x130a6c4: ldur            x1, [fp, #-0x30]
    // 0x130a6c8: r0 = LoadClassIdInstr(r1)
    //     0x130a6c8: ldur            x0, [x1, #-1]
    //     0x130a6cc: ubfx            x0, x0, #0xc, #0x14
    // 0x130a6d0: ldur            x2, [fp, #-0x28]
    // 0x130a6d4: ldur            x3, [fp, #-8]
    // 0x130a6d8: r0 = GDT[cid_x0 + -0x1000]()
    //     0x130a6d8: sub             lr, x0, #1, lsl #12
    //     0x130a6dc: ldr             lr, [x21, lr, lsl #3]
    //     0x130a6e0: blr             lr
    // 0x130a6e4: ldur            x1, [fp, #-0x28]
    // 0x130a6e8: r0 = done()
    //     0x130a6e8: bl              #0xd0504c  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::done
    // 0x130a6ec: LeaveFrame
    //     0x130a6ec: mov             SP, fp
    //     0x130a6f0: ldp             fp, lr, [SP], #0x10
    // 0x130a6f4: ret
    //     0x130a6f4: ret             
    // 0x130a6f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x130a6f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x130a6fc: b               #0x130a658
  }
}

// class id: 2784, size: 0x8, field offset: 0x8
//   const constructor, 
class JSONMethodCodec extends Object
    implements MethodCodec {

  _ encodeMethodCall(/* No info */) {
    // ** addr: 0x13095c8, size: 0x90
    // 0x13095c8: EnterFrame
    //     0x13095c8: stp             fp, lr, [SP, #-0x10]!
    //     0x13095cc: mov             fp, SP
    // 0x13095d0: AllocStack(0x18)
    //     0x13095d0: sub             SP, SP, #0x18
    // 0x13095d4: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0x13095d4: mov             x0, x2
    //     0x13095d8: stur            x2, [fp, #-8]
    // 0x13095dc: CheckStackOverflow
    //     0x13095dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13095e0: cmp             SP, x16
    //     0x13095e4: b.ls            #0x1309650
    // 0x13095e8: r1 = Null
    //     0x13095e8: mov             x1, NULL
    // 0x13095ec: r2 = 8
    //     0x13095ec: mov             x2, #8
    // 0x13095f0: r0 = AllocateArray()
    //     0x13095f0: bl              #0x13df928  ; AllocateArrayStub
    // 0x13095f4: r16 = "method"
    //     0x13095f4: ldr             x16, [PP, #0x7c80]  ; [pp+0x7c80] "method"
    // 0x13095f8: StoreField: r0->field_f = r16
    //     0x13095f8: stur            w16, [x0, #0xf]
    // 0x13095fc: ldur            x1, [fp, #-8]
    // 0x1309600: LoadField: r2 = r1->field_7
    //     0x1309600: ldur            w2, [x1, #7]
    // 0x1309604: DecompressPointer r2
    //     0x1309604: add             x2, x2, HEAP, lsl #32
    // 0x1309608: StoreField: r0->field_13 = r2
    //     0x1309608: stur            w2, [x0, #0x13]
    // 0x130960c: r16 = "args"
    //     0x130960c: add             x16, PP, #0xe, lsl #12  ; [pp+0xe070] "args"
    //     0x1309610: ldr             x16, [x16, #0x70]
    // 0x1309614: ArrayStore: r0[0] = r16  ; List_4
    //     0x1309614: stur            w16, [x0, #0x17]
    // 0x1309618: LoadField: r2 = r1->field_b
    //     0x1309618: ldur            w2, [x1, #0xb]
    // 0x130961c: DecompressPointer r2
    //     0x130961c: add             x2, x2, HEAP, lsl #32
    // 0x1309620: StoreField: r0->field_1b = r2
    //     0x1309620: stur            w2, [x0, #0x1b]
    // 0x1309624: r16 = <String, Object?>
    //     0x1309624: add             x16, PP, #8, lsl #12  ; [pp+0x8128] TypeArguments: <String, Object?>
    //     0x1309628: ldr             x16, [x16, #0x128]
    // 0x130962c: stp             x0, x16, [SP]
    // 0x1309630: r0 = Map._fromLiteral()
    //     0x1309630: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x1309634: mov             x2, x0
    // 0x1309638: r1 = Instance_JSONMessageCodec
    //     0x1309638: add             x1, PP, #0xd, lsl #12  ; [pp+0xdfd8] Obj!JSONMessageCodec@129c051
    //     0x130963c: ldr             x1, [x1, #0xfd8]
    // 0x1309640: r0 = encodeMessage()
    //     0x1309640: bl              #0xd0797c  ; [package:flutter/src/services/message_codecs.dart] JSONMessageCodec::encodeMessage
    // 0x1309644: LeaveFrame
    //     0x1309644: mov             SP, fp
    //     0x1309648: ldp             fp, lr, [SP], #0x10
    // 0x130964c: ret
    //     0x130964c: ret             
    // 0x1309650: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1309650: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1309654: b               #0x13095e8
  }
  _ decodeMethodCall(/* No info */) {
    // ** addr: 0x1309708, size: 0x254
    // 0x1309708: EnterFrame
    //     0x1309708: stp             fp, lr, [SP, #-0x10]!
    //     0x130970c: mov             fp, SP
    // 0x1309710: AllocStack(0x20)
    //     0x1309710: sub             SP, SP, #0x20
    // 0x1309714: CheckStackOverflow
    //     0x1309714: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1309718: cmp             SP, x16
    //     0x130971c: b.ls            #0x1309954
    // 0x1309720: r1 = Instance_JSONMessageCodec
    //     0x1309720: add             x1, PP, #0xd, lsl #12  ; [pp+0xdfd8] Obj!JSONMessageCodec@129c051
    //     0x1309724: ldr             x1, [x1, #0xfd8]
    // 0x1309728: r0 = decodeMessage()
    //     0x1309728: bl              #0xcd004c  ; [package:flutter/src/services/message_codecs.dart] JSONMessageCodec::decodeMessage
    // 0x130972c: mov             x3, x0
    // 0x1309730: r2 = Null
    //     0x1309730: mov             x2, NULL
    // 0x1309734: r1 = Null
    //     0x1309734: mov             x1, NULL
    // 0x1309738: stur            x3, [fp, #-8]
    // 0x130973c: cmp             w0, NULL
    // 0x1309740: b.eq            #0x13097d8
    // 0x1309744: branchIfSmi(r0, 0x13097d8)
    //     0x1309744: tbz             w0, #0, #0x13097d8
    // 0x1309748: r3 = LoadClassIdInstr(r0)
    //     0x1309748: ldur            x3, [x0, #-1]
    //     0x130974c: ubfx            x3, x3, #0xc, #0x14
    // 0x1309750: r17 = 7630
    //     0x1309750: mov             x17, #0x1dce
    // 0x1309754: cmp             x3, x17
    // 0x1309758: b.eq            #0x13097e0
    // 0x130975c: r4 = LoadClassIdInstr(r0)
    //     0x130975c: ldur            x4, [x0, #-1]
    //     0x1309760: ubfx            x4, x4, #0xc, #0x14
    // 0x1309764: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x1309768: ldr             x3, [x3, #0x18]
    // 0x130976c: ldr             x3, [x3, x4, lsl #3]
    // 0x1309770: LoadField: r3 = r3->field_2b
    //     0x1309770: ldur            w3, [x3, #0x2b]
    // 0x1309774: DecompressPointer r3
    //     0x1309774: add             x3, x3, HEAP, lsl #32
    // 0x1309778: cmp             w3, NULL
    // 0x130977c: b.eq            #0x13097d8
    // 0x1309780: LoadField: r3 = r3->field_f
    //     0x1309780: ldur            w3, [x3, #0xf]
    // 0x1309784: lsr             x3, x3, #3
    // 0x1309788: r17 = 7630
    //     0x1309788: mov             x17, #0x1dce
    // 0x130978c: cmp             x3, x17
    // 0x1309790: b.eq            #0x13097e0
    // 0x1309794: r3 = SubtypeTestCache
    //     0x1309794: add             x3, PP, #0xe, lsl #12  ; [pp+0xe058] SubtypeTestCache
    //     0x1309798: ldr             x3, [x3, #0x58]
    // 0x130979c: r30 = Subtype1TestCacheStub
    //     0x130979c: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x13097a0: LoadField: r30 = r30->field_7
    //     0x13097a0: ldur            lr, [lr, #7]
    // 0x13097a4: blr             lr
    // 0x13097a8: cmp             w7, NULL
    // 0x13097ac: b.eq            #0x13097b8
    // 0x13097b0: tbnz            w7, #4, #0x13097d8
    // 0x13097b4: b               #0x13097e0
    // 0x13097b8: r8 = Map
    //     0x13097b8: add             x8, PP, #0xe, lsl #12  ; [pp+0xe060] Type: Map
    //     0x13097bc: ldr             x8, [x8, #0x60]
    // 0x13097c0: r3 = SubtypeTestCache
    //     0x13097c0: add             x3, PP, #0xe, lsl #12  ; [pp+0xe068] SubtypeTestCache
    //     0x13097c4: ldr             x3, [x3, #0x68]
    // 0x13097c8: r30 = InstanceOfStub
    //     0x13097c8: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x13097cc: LoadField: r30 = r30->field_7
    //     0x13097cc: ldur            lr, [lr, #7]
    // 0x13097d0: blr             lr
    // 0x13097d4: b               #0x13097e4
    // 0x13097d8: r0 = false
    //     0x13097d8: add             x0, NULL, #0x30  ; false
    // 0x13097dc: b               #0x13097e4
    // 0x13097e0: r0 = true
    //     0x13097e0: add             x0, NULL, #0x20  ; true
    // 0x13097e4: tbnz            w0, #4, #0x13098b4
    // 0x13097e8: ldur            x3, [fp, #-8]
    // 0x13097ec: r0 = LoadClassIdInstr(r3)
    //     0x13097ec: ldur            x0, [x3, #-1]
    //     0x13097f0: ubfx            x0, x0, #0xc, #0x14
    // 0x13097f4: mov             x1, x3
    // 0x13097f8: r2 = "method"
    //     0x13097f8: ldr             x2, [PP, #0x7c80]  ; [pp+0x7c80] "method"
    // 0x13097fc: r0 = GDT[cid_x0 + -0xd48]()
    //     0x13097fc: sub             lr, x0, #0xd48
    //     0x1309800: ldr             lr, [x21, lr, lsl #3]
    //     0x1309804: blr             lr
    // 0x1309808: mov             x3, x0
    // 0x130980c: stur            x3, [fp, #-0x10]
    // 0x1309810: cmp             w3, NULL
    // 0x1309814: b.ne            #0x1309840
    // 0x1309818: ldur            x4, [fp, #-8]
    // 0x130981c: r0 = LoadClassIdInstr(r4)
    //     0x130981c: ldur            x0, [x4, #-1]
    //     0x1309820: ubfx            x0, x0, #0xc, #0x14
    // 0x1309824: mov             x1, x4
    // 0x1309828: r2 = "method"
    //     0x1309828: ldr             x2, [PP, #0x7c80]  ; [pp+0x7c80] "method"
    // 0x130982c: r0 = GDT[cid_x0 + -0x104]()
    //     0x130982c: sub             lr, x0, #0x104
    //     0x1309830: ldr             lr, [x21, lr, lsl #3]
    //     0x1309834: blr             lr
    // 0x1309838: tbnz            w0, #4, #0x1309908
    // 0x130983c: ldur            x3, [fp, #-0x10]
    // 0x1309840: r0 = 60
    //     0x1309840: mov             x0, #0x3c
    // 0x1309844: branchIfSmi(r3, 0x1309850)
    //     0x1309844: tbz             w3, #0, #0x1309850
    // 0x1309848: r0 = LoadClassIdInstr(r3)
    //     0x1309848: ldur            x0, [x3, #-1]
    //     0x130984c: ubfx            x0, x0, #0xc, #0x14
    // 0x1309850: sub             x16, x0, #0x5e
    // 0x1309854: cmp             x16, #1
    // 0x1309858: b.hi            #0x1309900
    // 0x130985c: ldur            x0, [fp, #-8]
    // 0x1309860: r1 = LoadClassIdInstr(r0)
    //     0x1309860: ldur            x1, [x0, #-1]
    //     0x1309864: ubfx            x1, x1, #0xc, #0x14
    // 0x1309868: mov             x16, x0
    // 0x130986c: mov             x0, x1
    // 0x1309870: mov             x1, x16
    // 0x1309874: r2 = "args"
    //     0x1309874: add             x2, PP, #0xe, lsl #12  ; [pp+0xe070] "args"
    //     0x1309878: ldr             x2, [x2, #0x70]
    // 0x130987c: r0 = GDT[cid_x0 + -0xd48]()
    //     0x130987c: sub             lr, x0, #0xd48
    //     0x1309880: ldr             lr, [x21, lr, lsl #3]
    //     0x1309884: blr             lr
    // 0x1309888: stur            x0, [fp, #-0x18]
    // 0x130988c: r0 = MethodCall()
    //     0x130988c: bl              #0x130995c  ; AllocateMethodCallStub -> MethodCall (size=0x10)
    // 0x1309890: mov             x1, x0
    // 0x1309894: ldur            x0, [fp, #-0x10]
    // 0x1309898: StoreField: r1->field_7 = r0
    //     0x1309898: stur            w0, [x1, #7]
    // 0x130989c: ldur            x0, [fp, #-0x18]
    // 0x13098a0: StoreField: r1->field_b = r0
    //     0x13098a0: stur            w0, [x1, #0xb]
    // 0x13098a4: mov             x0, x1
    // 0x13098a8: LeaveFrame
    //     0x13098a8: mov             SP, fp
    //     0x13098ac: ldp             fp, lr, [SP], #0x10
    // 0x13098b0: ret
    //     0x13098b0: ret             
    // 0x13098b4: ldur            x0, [fp, #-8]
    // 0x13098b8: r1 = Null
    //     0x13098b8: mov             x1, NULL
    // 0x13098bc: r2 = 4
    //     0x13098bc: mov             x2, #4
    // 0x13098c0: r0 = AllocateArray()
    //     0x13098c0: bl              #0x13df928  ; AllocateArrayStub
    // 0x13098c4: r16 = "Expected method call Map, got "
    //     0x13098c4: add             x16, PP, #0xe, lsl #12  ; [pp+0xe078] "Expected method call Map, got "
    //     0x13098c8: ldr             x16, [x16, #0x78]
    // 0x13098cc: StoreField: r0->field_f = r16
    //     0x13098cc: stur            w16, [x0, #0xf]
    // 0x13098d0: ldur            x3, [fp, #-8]
    // 0x13098d4: StoreField: r0->field_13 = r3
    //     0x13098d4: stur            w3, [x0, #0x13]
    // 0x13098d8: str             x0, [SP]
    // 0x13098dc: r0 = _interpolate()
    //     0x13098dc: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x13098e0: stur            x0, [fp, #-0x10]
    // 0x13098e4: r0 = FormatException()
    //     0x13098e4: bl              #0x7e4b0c  ; AllocateFormatExceptionStub -> FormatException (size=0x14)
    // 0x13098e8: mov             x1, x0
    // 0x13098ec: ldur            x0, [fp, #-0x10]
    // 0x13098f0: StoreField: r1->field_7 = r0
    //     0x13098f0: stur            w0, [x1, #7]
    // 0x13098f4: mov             x0, x1
    // 0x13098f8: r0 = Throw()
    //     0x13098f8: bl              #0x13ddb2c  ; ThrowStub
    // 0x13098fc: brk             #0
    // 0x1309900: ldur            x3, [fp, #-8]
    // 0x1309904: b               #0x130990c
    // 0x1309908: ldur            x3, [fp, #-8]
    // 0x130990c: r1 = Null
    //     0x130990c: mov             x1, NULL
    // 0x1309910: r2 = 4
    //     0x1309910: mov             x2, #4
    // 0x1309914: r0 = AllocateArray()
    //     0x1309914: bl              #0x13df928  ; AllocateArrayStub
    // 0x1309918: r16 = "Invalid method call: "
    //     0x1309918: add             x16, PP, #0xe, lsl #12  ; [pp+0xe080] "Invalid method call: "
    //     0x130991c: ldr             x16, [x16, #0x80]
    // 0x1309920: StoreField: r0->field_f = r16
    //     0x1309920: stur            w16, [x0, #0xf]
    // 0x1309924: ldur            x1, [fp, #-8]
    // 0x1309928: StoreField: r0->field_13 = r1
    //     0x1309928: stur            w1, [x0, #0x13]
    // 0x130992c: str             x0, [SP]
    // 0x1309930: r0 = _interpolate()
    //     0x1309930: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x1309934: stur            x0, [fp, #-8]
    // 0x1309938: r0 = FormatException()
    //     0x1309938: bl              #0x7e4b0c  ; AllocateFormatExceptionStub -> FormatException (size=0x14)
    // 0x130993c: mov             x1, x0
    // 0x1309940: ldur            x0, [fp, #-8]
    // 0x1309944: StoreField: r1->field_7 = r0
    //     0x1309944: stur            w0, [x1, #7]
    // 0x1309948: mov             x0, x1
    // 0x130994c: r0 = Throw()
    //     0x130994c: bl              #0x13ddb2c  ; ThrowStub
    // 0x1309950: brk             #0
    // 0x1309954: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1309954: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1309958: b               #0x1309720
  }
  _ encodeSuccessEnvelope(/* No info */) {
    // ** addr: 0x1309bc8, size: 0x80
    // 0x1309bc8: EnterFrame
    //     0x1309bc8: stp             fp, lr, [SP, #-0x10]!
    //     0x1309bcc: mov             fp, SP
    // 0x1309bd0: AllocStack(0x10)
    //     0x1309bd0: sub             SP, SP, #0x10
    // 0x1309bd4: r0 = 2
    //     0x1309bd4: mov             x0, #2
    // 0x1309bd8: mov             x3, x2
    // 0x1309bdc: stur            x2, [fp, #-8]
    // 0x1309be0: CheckStackOverflow
    //     0x1309be0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1309be4: cmp             SP, x16
    //     0x1309be8: b.ls            #0x1309c40
    // 0x1309bec: mov             x2, x0
    // 0x1309bf0: r1 = Null
    //     0x1309bf0: mov             x1, NULL
    // 0x1309bf4: r0 = AllocateArray()
    //     0x1309bf4: bl              #0x13df928  ; AllocateArrayStub
    // 0x1309bf8: mov             x2, x0
    // 0x1309bfc: ldur            x0, [fp, #-8]
    // 0x1309c00: stur            x2, [fp, #-0x10]
    // 0x1309c04: StoreField: r2->field_f = r0
    //     0x1309c04: stur            w0, [x2, #0xf]
    // 0x1309c08: r1 = <Object?>
    //     0x1309c08: ldr             x1, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0x1309c0c: r0 = AllocateGrowableArray()
    //     0x1309c0c: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x1309c10: mov             x1, x0
    // 0x1309c14: ldur            x0, [fp, #-0x10]
    // 0x1309c18: StoreField: r1->field_f = r0
    //     0x1309c18: stur            w0, [x1, #0xf]
    // 0x1309c1c: r0 = 2
    //     0x1309c1c: mov             x0, #2
    // 0x1309c20: StoreField: r1->field_b = r0
    //     0x1309c20: stur            w0, [x1, #0xb]
    // 0x1309c24: mov             x2, x1
    // 0x1309c28: r1 = Instance_JSONMessageCodec
    //     0x1309c28: add             x1, PP, #0xd, lsl #12  ; [pp+0xdfd8] Obj!JSONMessageCodec@129c051
    //     0x1309c2c: ldr             x1, [x1, #0xfd8]
    // 0x1309c30: r0 = encodeMessage()
    //     0x1309c30: bl              #0xd0797c  ; [package:flutter/src/services/message_codecs.dart] JSONMessageCodec::encodeMessage
    // 0x1309c34: LeaveFrame
    //     0x1309c34: mov             SP, fp
    //     0x1309c38: ldp             fp, lr, [SP], #0x10
    // 0x1309c3c: ret
    //     0x1309c3c: ret             
    // 0x1309c40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1309c40: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1309c44: b               #0x1309bec
  }
  _ decodeEnvelope(/* No info */) {
    // ** addr: 0x1309ccc, size: 0x668
    // 0x1309ccc: EnterFrame
    //     0x1309ccc: stp             fp, lr, [SP, #-0x10]!
    //     0x1309cd0: mov             fp, SP
    // 0x1309cd4: AllocStack(0x38)
    //     0x1309cd4: sub             SP, SP, #0x38
    // 0x1309cd8: CheckStackOverflow
    //     0x1309cd8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1309cdc: cmp             SP, x16
    //     0x1309ce0: b.ls            #0x130a32c
    // 0x1309ce4: r1 = Instance_JSONMessageCodec
    //     0x1309ce4: add             x1, PP, #0xd, lsl #12  ; [pp+0xdfd8] Obj!JSONMessageCodec@129c051
    //     0x1309ce8: ldr             x1, [x1, #0xfd8]
    // 0x1309cec: r0 = decodeMessage()
    //     0x1309cec: bl              #0xcd004c  ; [package:flutter/src/services/message_codecs.dart] JSONMessageCodec::decodeMessage
    // 0x1309cf0: mov             x3, x0
    // 0x1309cf4: r2 = Null
    //     0x1309cf4: mov             x2, NULL
    // 0x1309cf8: r1 = Null
    //     0x1309cf8: mov             x1, NULL
    // 0x1309cfc: stur            x3, [fp, #-8]
    // 0x1309d00: cmp             w0, NULL
    // 0x1309d04: b.eq            #0x1309da8
    // 0x1309d08: branchIfSmi(r0, 0x1309da8)
    //     0x1309d08: tbz             w0, #0, #0x1309da8
    // 0x1309d0c: r3 = LoadClassIdInstr(r0)
    //     0x1309d0c: ldur            x3, [x0, #-1]
    //     0x1309d10: ubfx            x3, x3, #0xc, #0x14
    // 0x1309d14: r17 = 7631
    //     0x1309d14: mov             x17, #0x1dcf
    // 0x1309d18: cmp             x3, x17
    // 0x1309d1c: b.eq            #0x1309db0
    // 0x1309d20: sub             x3, x3, #0x5a
    // 0x1309d24: cmp             x3, #2
    // 0x1309d28: b.ls            #0x1309db0
    // 0x1309d2c: r4 = LoadClassIdInstr(r0)
    //     0x1309d2c: ldur            x4, [x0, #-1]
    //     0x1309d30: ubfx            x4, x4, #0xc, #0x14
    // 0x1309d34: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x1309d38: ldr             x3, [x3, #0x18]
    // 0x1309d3c: ldr             x3, [x3, x4, lsl #3]
    // 0x1309d40: LoadField: r3 = r3->field_2b
    //     0x1309d40: ldur            w3, [x3, #0x2b]
    // 0x1309d44: DecompressPointer r3
    //     0x1309d44: add             x3, x3, HEAP, lsl #32
    // 0x1309d48: cmp             w3, NULL
    // 0x1309d4c: b.eq            #0x1309da8
    // 0x1309d50: LoadField: r3 = r3->field_f
    //     0x1309d50: ldur            w3, [x3, #0xf]
    // 0x1309d54: lsr             x3, x3, #3
    // 0x1309d58: r17 = 7631
    //     0x1309d58: mov             x17, #0x1dcf
    // 0x1309d5c: cmp             x3, x17
    // 0x1309d60: b.eq            #0x1309db0
    // 0x1309d64: r3 = SubtypeTestCache
    //     0x1309d64: add             x3, PP, #0xd, lsl #12  ; [pp+0xdfe0] SubtypeTestCache
    //     0x1309d68: ldr             x3, [x3, #0xfe0]
    // 0x1309d6c: r30 = Subtype1TestCacheStub
    //     0x1309d6c: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x1309d70: LoadField: r30 = r30->field_7
    //     0x1309d70: ldur            lr, [lr, #7]
    // 0x1309d74: blr             lr
    // 0x1309d78: cmp             w7, NULL
    // 0x1309d7c: b.eq            #0x1309d88
    // 0x1309d80: tbnz            w7, #4, #0x1309da8
    // 0x1309d84: b               #0x1309db0
    // 0x1309d88: r8 = List
    //     0x1309d88: add             x8, PP, #0xd, lsl #12  ; [pp+0xdfe8] Type: List
    //     0x1309d8c: ldr             x8, [x8, #0xfe8]
    // 0x1309d90: r3 = SubtypeTestCache
    //     0x1309d90: add             x3, PP, #0xd, lsl #12  ; [pp+0xdff0] SubtypeTestCache
    //     0x1309d94: ldr             x3, [x3, #0xff0]
    // 0x1309d98: r30 = InstanceOfStub
    //     0x1309d98: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x1309d9c: LoadField: r30 = r30->field_7
    //     0x1309d9c: ldur            lr, [lr, #7]
    // 0x1309da0: blr             lr
    // 0x1309da4: b               #0x1309db4
    // 0x1309da8: r0 = false
    //     0x1309da8: add             x0, NULL, #0x30  ; false
    // 0x1309dac: b               #0x1309db4
    // 0x1309db0: r0 = true
    //     0x1309db0: add             x0, NULL, #0x20  ; true
    // 0x1309db4: tbnz            w0, #4, #0x1309e0c
    // 0x1309db8: ldur            x1, [fp, #-8]
    // 0x1309dbc: r0 = LoadClassIdInstr(r1)
    //     0x1309dbc: ldur            x0, [x1, #-1]
    //     0x1309dc0: ubfx            x0, x0, #0xc, #0x14
    // 0x1309dc4: str             x1, [SP]
    // 0x1309dc8: r0 = GDT[cid_x0 + 0xf078]()
    //     0x1309dc8: mov             x17, #0xf078
    //     0x1309dcc: add             lr, x0, x17
    //     0x1309dd0: ldr             lr, [x21, lr, lsl #3]
    //     0x1309dd4: blr             lr
    // 0x1309dd8: cmp             w0, #2
    // 0x1309ddc: b.ne            #0x1309e58
    // 0x1309de0: ldur            x0, [fp, #-8]
    // 0x1309de4: r1 = LoadClassIdInstr(r0)
    //     0x1309de4: ldur            x1, [x0, #-1]
    //     0x1309de8: ubfx            x1, x1, #0xc, #0x14
    // 0x1309dec: stp             xzr, x0, [SP]
    // 0x1309df0: mov             x0, x1
    // 0x1309df4: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x1309df4: sub             lr, x0, #0xdfd
    //     0x1309df8: ldr             lr, [x21, lr, lsl #3]
    //     0x1309dfc: blr             lr
    // 0x1309e00: LeaveFrame
    //     0x1309e00: mov             SP, fp
    //     0x1309e04: ldp             fp, lr, [SP], #0x10
    // 0x1309e08: ret
    //     0x1309e08: ret             
    // 0x1309e0c: ldur            x0, [fp, #-8]
    // 0x1309e10: r1 = Null
    //     0x1309e10: mov             x1, NULL
    // 0x1309e14: r2 = 4
    //     0x1309e14: mov             x2, #4
    // 0x1309e18: r0 = AllocateArray()
    //     0x1309e18: bl              #0x13df928  ; AllocateArrayStub
    // 0x1309e1c: r16 = "Expected envelope List, got "
    //     0x1309e1c: add             x16, PP, #0xd, lsl #12  ; [pp+0xdff8] "Expected envelope List, got "
    //     0x1309e20: ldr             x16, [x16, #0xff8]
    // 0x1309e24: StoreField: r0->field_f = r16
    //     0x1309e24: stur            w16, [x0, #0xf]
    // 0x1309e28: ldur            x1, [fp, #-8]
    // 0x1309e2c: StoreField: r0->field_13 = r1
    //     0x1309e2c: stur            w1, [x0, #0x13]
    // 0x1309e30: str             x0, [SP]
    // 0x1309e34: r0 = _interpolate()
    //     0x1309e34: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x1309e38: stur            x0, [fp, #-0x10]
    // 0x1309e3c: r0 = FormatException()
    //     0x1309e3c: bl              #0x7e4b0c  ; AllocateFormatExceptionStub -> FormatException (size=0x14)
    // 0x1309e40: mov             x1, x0
    // 0x1309e44: ldur            x0, [fp, #-0x10]
    // 0x1309e48: StoreField: r1->field_7 = r0
    //     0x1309e48: stur            w0, [x1, #7]
    // 0x1309e4c: mov             x0, x1
    // 0x1309e50: r0 = Throw()
    //     0x1309e50: bl              #0x13ddb2c  ; ThrowStub
    // 0x1309e54: brk             #0
    // 0x1309e58: ldur            x1, [fp, #-8]
    // 0x1309e5c: r0 = LoadClassIdInstr(r1)
    //     0x1309e5c: ldur            x0, [x1, #-1]
    //     0x1309e60: ubfx            x0, x0, #0xc, #0x14
    // 0x1309e64: str             x1, [SP]
    // 0x1309e68: r0 = GDT[cid_x0 + 0xf078]()
    //     0x1309e68: mov             x17, #0xf078
    //     0x1309e6c: add             lr, x0, x17
    //     0x1309e70: ldr             lr, [x21, lr, lsl #3]
    //     0x1309e74: blr             lr
    // 0x1309e78: cmp             w0, #6
    // 0x1309e7c: b.ne            #0x130a030
    // 0x1309e80: ldur            x1, [fp, #-8]
    // 0x1309e84: r0 = LoadClassIdInstr(r1)
    //     0x1309e84: ldur            x0, [x1, #-1]
    //     0x1309e88: ubfx            x0, x0, #0xc, #0x14
    // 0x1309e8c: stp             xzr, x1, [SP]
    // 0x1309e90: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x1309e90: sub             lr, x0, #0xdfd
    //     0x1309e94: ldr             lr, [x21, lr, lsl #3]
    //     0x1309e98: blr             lr
    // 0x1309e9c: r1 = 60
    //     0x1309e9c: mov             x1, #0x3c
    // 0x1309ea0: branchIfSmi(r0, 0x1309eac)
    //     0x1309ea0: tbz             w0, #0, #0x1309eac
    // 0x1309ea4: r1 = LoadClassIdInstr(r0)
    //     0x1309ea4: ldur            x1, [x0, #-1]
    //     0x1309ea8: ubfx            x1, x1, #0xc, #0x14
    // 0x1309eac: sub             x16, x1, #0x5e
    // 0x1309eb0: cmp             x16, #1
    // 0x1309eb4: b.hi            #0x130a028
    // 0x1309eb8: ldur            x1, [fp, #-8]
    // 0x1309ebc: r0 = LoadClassIdInstr(r1)
    //     0x1309ebc: ldur            x0, [x1, #-1]
    //     0x1309ec0: ubfx            x0, x0, #0xc, #0x14
    // 0x1309ec4: r16 = 2
    //     0x1309ec4: mov             x16, #2
    // 0x1309ec8: stp             x16, x1, [SP]
    // 0x1309ecc: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x1309ecc: sub             lr, x0, #0xdfd
    //     0x1309ed0: ldr             lr, [x21, lr, lsl #3]
    //     0x1309ed4: blr             lr
    // 0x1309ed8: cmp             w0, NULL
    // 0x1309edc: b.eq            #0x1309f1c
    // 0x1309ee0: ldur            x1, [fp, #-8]
    // 0x1309ee4: r0 = LoadClassIdInstr(r1)
    //     0x1309ee4: ldur            x0, [x1, #-1]
    //     0x1309ee8: ubfx            x0, x0, #0xc, #0x14
    // 0x1309eec: r16 = 2
    //     0x1309eec: mov             x16, #2
    // 0x1309ef0: stp             x16, x1, [SP]
    // 0x1309ef4: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x1309ef4: sub             lr, x0, #0xdfd
    //     0x1309ef8: ldr             lr, [x21, lr, lsl #3]
    //     0x1309efc: blr             lr
    // 0x1309f00: r1 = 60
    //     0x1309f00: mov             x1, #0x3c
    // 0x1309f04: branchIfSmi(r0, 0x1309f10)
    //     0x1309f04: tbz             w0, #0, #0x1309f10
    // 0x1309f08: r1 = LoadClassIdInstr(r0)
    //     0x1309f08: ldur            x1, [x0, #-1]
    //     0x1309f0c: ubfx            x1, x1, #0xc, #0x14
    // 0x1309f10: sub             x16, x1, #0x5e
    // 0x1309f14: cmp             x16, #1
    // 0x1309f18: b.hi            #0x130a020
    // 0x1309f1c: ldur            x1, [fp, #-8]
    // 0x1309f20: r0 = LoadClassIdInstr(r1)
    //     0x1309f20: ldur            x0, [x1, #-1]
    //     0x1309f24: ubfx            x0, x0, #0xc, #0x14
    // 0x1309f28: stp             xzr, x1, [SP]
    // 0x1309f2c: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x1309f2c: sub             lr, x0, #0xdfd
    //     0x1309f30: ldr             lr, [x21, lr, lsl #3]
    //     0x1309f34: blr             lr
    // 0x1309f38: mov             x3, x0
    // 0x1309f3c: r2 = Null
    //     0x1309f3c: mov             x2, NULL
    // 0x1309f40: r1 = Null
    //     0x1309f40: mov             x1, NULL
    // 0x1309f44: stur            x3, [fp, #-0x10]
    // 0x1309f48: r4 = 60
    //     0x1309f48: mov             x4, #0x3c
    // 0x1309f4c: branchIfSmi(r0, 0x1309f58)
    //     0x1309f4c: tbz             w0, #0, #0x1309f58
    // 0x1309f50: r4 = LoadClassIdInstr(r0)
    //     0x1309f50: ldur            x4, [x0, #-1]
    //     0x1309f54: ubfx            x4, x4, #0xc, #0x14
    // 0x1309f58: sub             x4, x4, #0x5e
    // 0x1309f5c: cmp             x4, #1
    // 0x1309f60: b.ls            #0x1309f74
    // 0x1309f64: r8 = String
    //     0x1309f64: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x1309f68: r3 = Null
    //     0x1309f68: add             x3, PP, #0xe, lsl #12  ; [pp+0xe000] Null
    //     0x1309f6c: ldr             x3, [x3]
    // 0x1309f70: r0 = String()
    //     0x1309f70: bl              #0x13ee320  ; IsType_String_Stub
    // 0x1309f74: ldur            x1, [fp, #-8]
    // 0x1309f78: r0 = LoadClassIdInstr(r1)
    //     0x1309f78: ldur            x0, [x1, #-1]
    //     0x1309f7c: ubfx            x0, x0, #0xc, #0x14
    // 0x1309f80: r16 = 2
    //     0x1309f80: mov             x16, #2
    // 0x1309f84: stp             x16, x1, [SP]
    // 0x1309f88: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x1309f88: sub             lr, x0, #0xdfd
    //     0x1309f8c: ldr             lr, [x21, lr, lsl #3]
    //     0x1309f90: blr             lr
    // 0x1309f94: mov             x3, x0
    // 0x1309f98: r2 = Null
    //     0x1309f98: mov             x2, NULL
    // 0x1309f9c: r1 = Null
    //     0x1309f9c: mov             x1, NULL
    // 0x1309fa0: stur            x3, [fp, #-0x18]
    // 0x1309fa4: r4 = 60
    //     0x1309fa4: mov             x4, #0x3c
    // 0x1309fa8: branchIfSmi(r0, 0x1309fb4)
    //     0x1309fa8: tbz             w0, #0, #0x1309fb4
    // 0x1309fac: r4 = LoadClassIdInstr(r0)
    //     0x1309fac: ldur            x4, [x0, #-1]
    //     0x1309fb0: ubfx            x4, x4, #0xc, #0x14
    // 0x1309fb4: sub             x4, x4, #0x5e
    // 0x1309fb8: cmp             x4, #1
    // 0x1309fbc: b.ls            #0x1309fd0
    // 0x1309fc0: r8 = String?
    //     0x1309fc0: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x1309fc4: r3 = Null
    //     0x1309fc4: add             x3, PP, #0xe, lsl #12  ; [pp+0xe010] Null
    //     0x1309fc8: ldr             x3, [x3, #0x10]
    // 0x1309fcc: r0 = String?()
    //     0x1309fcc: bl              #0x7db310  ; IsType_String?_Stub
    // 0x1309fd0: ldur            x1, [fp, #-8]
    // 0x1309fd4: r0 = LoadClassIdInstr(r1)
    //     0x1309fd4: ldur            x0, [x1, #-1]
    //     0x1309fd8: ubfx            x0, x0, #0xc, #0x14
    // 0x1309fdc: r16 = 4
    //     0x1309fdc: mov             x16, #4
    // 0x1309fe0: stp             x16, x1, [SP]
    // 0x1309fe4: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x1309fe4: sub             lr, x0, #0xdfd
    //     0x1309fe8: ldr             lr, [x21, lr, lsl #3]
    //     0x1309fec: blr             lr
    // 0x1309ff0: stur            x0, [fp, #-0x20]
    // 0x1309ff4: r0 = PlatformException()
    //     0x1309ff4: bl              #0x8bf90c  ; AllocatePlatformExceptionStub -> PlatformException (size=0x18)
    // 0x1309ff8: mov             x1, x0
    // 0x1309ffc: ldur            x0, [fp, #-0x10]
    // 0x130a000: StoreField: r1->field_7 = r0
    //     0x130a000: stur            w0, [x1, #7]
    // 0x130a004: ldur            x0, [fp, #-0x18]
    // 0x130a008: StoreField: r1->field_b = r0
    //     0x130a008: stur            w0, [x1, #0xb]
    // 0x130a00c: ldur            x0, [fp, #-0x20]
    // 0x130a010: StoreField: r1->field_f = r0
    //     0x130a010: stur            w0, [x1, #0xf]
    // 0x130a014: mov             x0, x1
    // 0x130a018: r0 = Throw()
    //     0x130a018: bl              #0x13ddb2c  ; ThrowStub
    // 0x130a01c: brk             #0
    // 0x130a020: ldur            x1, [fp, #-8]
    // 0x130a024: b               #0x130a034
    // 0x130a028: ldur            x1, [fp, #-8]
    // 0x130a02c: b               #0x130a034
    // 0x130a030: ldur            x1, [fp, #-8]
    // 0x130a034: r0 = LoadClassIdInstr(r1)
    //     0x130a034: ldur            x0, [x1, #-1]
    //     0x130a038: ubfx            x0, x0, #0xc, #0x14
    // 0x130a03c: str             x1, [SP]
    // 0x130a040: r0 = GDT[cid_x0 + 0xf078]()
    //     0x130a040: mov             x17, #0xf078
    //     0x130a044: add             lr, x0, x17
    //     0x130a048: ldr             lr, [x21, lr, lsl #3]
    //     0x130a04c: blr             lr
    // 0x130a050: cmp             w0, #8
    // 0x130a054: b.ne            #0x130a2e0
    // 0x130a058: ldur            x1, [fp, #-8]
    // 0x130a05c: r0 = LoadClassIdInstr(r1)
    //     0x130a05c: ldur            x0, [x1, #-1]
    //     0x130a060: ubfx            x0, x0, #0xc, #0x14
    // 0x130a064: stp             xzr, x1, [SP]
    // 0x130a068: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x130a068: sub             lr, x0, #0xdfd
    //     0x130a06c: ldr             lr, [x21, lr, lsl #3]
    //     0x130a070: blr             lr
    // 0x130a074: r1 = 60
    //     0x130a074: mov             x1, #0x3c
    // 0x130a078: branchIfSmi(r0, 0x130a084)
    //     0x130a078: tbz             w0, #0, #0x130a084
    // 0x130a07c: r1 = LoadClassIdInstr(r0)
    //     0x130a07c: ldur            x1, [x0, #-1]
    //     0x130a080: ubfx            x1, x1, #0xc, #0x14
    // 0x130a084: sub             x16, x1, #0x5e
    // 0x130a088: cmp             x16, #1
    // 0x130a08c: b.hi            #0x130a2d8
    // 0x130a090: ldur            x1, [fp, #-8]
    // 0x130a094: r0 = LoadClassIdInstr(r1)
    //     0x130a094: ldur            x0, [x1, #-1]
    //     0x130a098: ubfx            x0, x0, #0xc, #0x14
    // 0x130a09c: r16 = 2
    //     0x130a09c: mov             x16, #2
    // 0x130a0a0: stp             x16, x1, [SP]
    // 0x130a0a4: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x130a0a4: sub             lr, x0, #0xdfd
    //     0x130a0a8: ldr             lr, [x21, lr, lsl #3]
    //     0x130a0ac: blr             lr
    // 0x130a0b0: cmp             w0, NULL
    // 0x130a0b4: b.eq            #0x130a0f4
    // 0x130a0b8: ldur            x1, [fp, #-8]
    // 0x130a0bc: r0 = LoadClassIdInstr(r1)
    //     0x130a0bc: ldur            x0, [x1, #-1]
    //     0x130a0c0: ubfx            x0, x0, #0xc, #0x14
    // 0x130a0c4: r16 = 2
    //     0x130a0c4: mov             x16, #2
    // 0x130a0c8: stp             x16, x1, [SP]
    // 0x130a0cc: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x130a0cc: sub             lr, x0, #0xdfd
    //     0x130a0d0: ldr             lr, [x21, lr, lsl #3]
    //     0x130a0d4: blr             lr
    // 0x130a0d8: r1 = 60
    //     0x130a0d8: mov             x1, #0x3c
    // 0x130a0dc: branchIfSmi(r0, 0x130a0e8)
    //     0x130a0dc: tbz             w0, #0, #0x130a0e8
    // 0x130a0e0: r1 = LoadClassIdInstr(r0)
    //     0x130a0e0: ldur            x1, [x0, #-1]
    //     0x130a0e4: ubfx            x1, x1, #0xc, #0x14
    // 0x130a0e8: sub             x16, x1, #0x5e
    // 0x130a0ec: cmp             x16, #1
    // 0x130a0f0: b.hi            #0x130a2d0
    // 0x130a0f4: ldur            x1, [fp, #-8]
    // 0x130a0f8: r0 = LoadClassIdInstr(r1)
    //     0x130a0f8: ldur            x0, [x1, #-1]
    //     0x130a0fc: ubfx            x0, x0, #0xc, #0x14
    // 0x130a100: r16 = 6
    //     0x130a100: mov             x16, #6
    // 0x130a104: stp             x16, x1, [SP]
    // 0x130a108: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x130a108: sub             lr, x0, #0xdfd
    //     0x130a10c: ldr             lr, [x21, lr, lsl #3]
    //     0x130a110: blr             lr
    // 0x130a114: cmp             w0, NULL
    // 0x130a118: b.eq            #0x130a158
    // 0x130a11c: ldur            x1, [fp, #-8]
    // 0x130a120: r0 = LoadClassIdInstr(r1)
    //     0x130a120: ldur            x0, [x1, #-1]
    //     0x130a124: ubfx            x0, x0, #0xc, #0x14
    // 0x130a128: r16 = 6
    //     0x130a128: mov             x16, #6
    // 0x130a12c: stp             x16, x1, [SP]
    // 0x130a130: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x130a130: sub             lr, x0, #0xdfd
    //     0x130a134: ldr             lr, [x21, lr, lsl #3]
    //     0x130a138: blr             lr
    // 0x130a13c: r1 = 60
    //     0x130a13c: mov             x1, #0x3c
    // 0x130a140: branchIfSmi(r0, 0x130a14c)
    //     0x130a140: tbz             w0, #0, #0x130a14c
    // 0x130a144: r1 = LoadClassIdInstr(r0)
    //     0x130a144: ldur            x1, [x0, #-1]
    //     0x130a148: ubfx            x1, x1, #0xc, #0x14
    // 0x130a14c: sub             x16, x1, #0x5e
    // 0x130a150: cmp             x16, #1
    // 0x130a154: b.hi            #0x130a2c8
    // 0x130a158: ldur            x1, [fp, #-8]
    // 0x130a15c: r0 = LoadClassIdInstr(r1)
    //     0x130a15c: ldur            x0, [x1, #-1]
    //     0x130a160: ubfx            x0, x0, #0xc, #0x14
    // 0x130a164: stp             xzr, x1, [SP]
    // 0x130a168: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x130a168: sub             lr, x0, #0xdfd
    //     0x130a16c: ldr             lr, [x21, lr, lsl #3]
    //     0x130a170: blr             lr
    // 0x130a174: mov             x3, x0
    // 0x130a178: r2 = Null
    //     0x130a178: mov             x2, NULL
    // 0x130a17c: r1 = Null
    //     0x130a17c: mov             x1, NULL
    // 0x130a180: stur            x3, [fp, #-0x10]
    // 0x130a184: r4 = 60
    //     0x130a184: mov             x4, #0x3c
    // 0x130a188: branchIfSmi(r0, 0x130a194)
    //     0x130a188: tbz             w0, #0, #0x130a194
    // 0x130a18c: r4 = LoadClassIdInstr(r0)
    //     0x130a18c: ldur            x4, [x0, #-1]
    //     0x130a190: ubfx            x4, x4, #0xc, #0x14
    // 0x130a194: sub             x4, x4, #0x5e
    // 0x130a198: cmp             x4, #1
    // 0x130a19c: b.ls            #0x130a1b0
    // 0x130a1a0: r8 = String
    //     0x130a1a0: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x130a1a4: r3 = Null
    //     0x130a1a4: add             x3, PP, #0xe, lsl #12  ; [pp+0xe020] Null
    //     0x130a1a8: ldr             x3, [x3, #0x20]
    // 0x130a1ac: r0 = String()
    //     0x130a1ac: bl              #0x13ee320  ; IsType_String_Stub
    // 0x130a1b0: ldur            x1, [fp, #-8]
    // 0x130a1b4: r0 = LoadClassIdInstr(r1)
    //     0x130a1b4: ldur            x0, [x1, #-1]
    //     0x130a1b8: ubfx            x0, x0, #0xc, #0x14
    // 0x130a1bc: r16 = 2
    //     0x130a1bc: mov             x16, #2
    // 0x130a1c0: stp             x16, x1, [SP]
    // 0x130a1c4: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x130a1c4: sub             lr, x0, #0xdfd
    //     0x130a1c8: ldr             lr, [x21, lr, lsl #3]
    //     0x130a1cc: blr             lr
    // 0x130a1d0: mov             x3, x0
    // 0x130a1d4: r2 = Null
    //     0x130a1d4: mov             x2, NULL
    // 0x130a1d8: r1 = Null
    //     0x130a1d8: mov             x1, NULL
    // 0x130a1dc: stur            x3, [fp, #-0x18]
    // 0x130a1e0: r4 = 60
    //     0x130a1e0: mov             x4, #0x3c
    // 0x130a1e4: branchIfSmi(r0, 0x130a1f0)
    //     0x130a1e4: tbz             w0, #0, #0x130a1f0
    // 0x130a1e8: r4 = LoadClassIdInstr(r0)
    //     0x130a1e8: ldur            x4, [x0, #-1]
    //     0x130a1ec: ubfx            x4, x4, #0xc, #0x14
    // 0x130a1f0: sub             x4, x4, #0x5e
    // 0x130a1f4: cmp             x4, #1
    // 0x130a1f8: b.ls            #0x130a20c
    // 0x130a1fc: r8 = String?
    //     0x130a1fc: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x130a200: r3 = Null
    //     0x130a200: add             x3, PP, #0xe, lsl #12  ; [pp+0xe030] Null
    //     0x130a204: ldr             x3, [x3, #0x30]
    // 0x130a208: r0 = String?()
    //     0x130a208: bl              #0x7db310  ; IsType_String?_Stub
    // 0x130a20c: ldur            x1, [fp, #-8]
    // 0x130a210: r0 = LoadClassIdInstr(r1)
    //     0x130a210: ldur            x0, [x1, #-1]
    //     0x130a214: ubfx            x0, x0, #0xc, #0x14
    // 0x130a218: r16 = 4
    //     0x130a218: mov             x16, #4
    // 0x130a21c: stp             x16, x1, [SP]
    // 0x130a220: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x130a220: sub             lr, x0, #0xdfd
    //     0x130a224: ldr             lr, [x21, lr, lsl #3]
    //     0x130a228: blr             lr
    // 0x130a22c: mov             x1, x0
    // 0x130a230: ldur            x0, [fp, #-8]
    // 0x130a234: stur            x1, [fp, #-0x20]
    // 0x130a238: r2 = LoadClassIdInstr(r0)
    //     0x130a238: ldur            x2, [x0, #-1]
    //     0x130a23c: ubfx            x2, x2, #0xc, #0x14
    // 0x130a240: r16 = 6
    //     0x130a240: mov             x16, #6
    // 0x130a244: stp             x16, x0, [SP]
    // 0x130a248: mov             x0, x2
    // 0x130a24c: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x130a24c: sub             lr, x0, #0xdfd
    //     0x130a250: ldr             lr, [x21, lr, lsl #3]
    //     0x130a254: blr             lr
    // 0x130a258: mov             x3, x0
    // 0x130a25c: r2 = Null
    //     0x130a25c: mov             x2, NULL
    // 0x130a260: r1 = Null
    //     0x130a260: mov             x1, NULL
    // 0x130a264: stur            x3, [fp, #-0x28]
    // 0x130a268: r4 = 60
    //     0x130a268: mov             x4, #0x3c
    // 0x130a26c: branchIfSmi(r0, 0x130a278)
    //     0x130a26c: tbz             w0, #0, #0x130a278
    // 0x130a270: r4 = LoadClassIdInstr(r0)
    //     0x130a270: ldur            x4, [x0, #-1]
    //     0x130a274: ubfx            x4, x4, #0xc, #0x14
    // 0x130a278: sub             x4, x4, #0x5e
    // 0x130a27c: cmp             x4, #1
    // 0x130a280: b.ls            #0x130a294
    // 0x130a284: r8 = String?
    //     0x130a284: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x130a288: r3 = Null
    //     0x130a288: add             x3, PP, #0xe, lsl #12  ; [pp+0xe040] Null
    //     0x130a28c: ldr             x3, [x3, #0x40]
    // 0x130a290: r0 = String?()
    //     0x130a290: bl              #0x7db310  ; IsType_String?_Stub
    // 0x130a294: r0 = PlatformException()
    //     0x130a294: bl              #0x8bf90c  ; AllocatePlatformExceptionStub -> PlatformException (size=0x18)
    // 0x130a298: mov             x1, x0
    // 0x130a29c: ldur            x0, [fp, #-0x10]
    // 0x130a2a0: StoreField: r1->field_7 = r0
    //     0x130a2a0: stur            w0, [x1, #7]
    // 0x130a2a4: ldur            x0, [fp, #-0x18]
    // 0x130a2a8: StoreField: r1->field_b = r0
    //     0x130a2a8: stur            w0, [x1, #0xb]
    // 0x130a2ac: ldur            x0, [fp, #-0x20]
    // 0x130a2b0: StoreField: r1->field_f = r0
    //     0x130a2b0: stur            w0, [x1, #0xf]
    // 0x130a2b4: ldur            x0, [fp, #-0x28]
    // 0x130a2b8: StoreField: r1->field_13 = r0
    //     0x130a2b8: stur            w0, [x1, #0x13]
    // 0x130a2bc: mov             x0, x1
    // 0x130a2c0: r0 = Throw()
    //     0x130a2c0: bl              #0x13ddb2c  ; ThrowStub
    // 0x130a2c4: brk             #0
    // 0x130a2c8: ldur            x0, [fp, #-8]
    // 0x130a2cc: b               #0x130a2e4
    // 0x130a2d0: ldur            x0, [fp, #-8]
    // 0x130a2d4: b               #0x130a2e4
    // 0x130a2d8: ldur            x0, [fp, #-8]
    // 0x130a2dc: b               #0x130a2e4
    // 0x130a2e0: ldur            x0, [fp, #-8]
    // 0x130a2e4: r1 = Null
    //     0x130a2e4: mov             x1, NULL
    // 0x130a2e8: r2 = 4
    //     0x130a2e8: mov             x2, #4
    // 0x130a2ec: r0 = AllocateArray()
    //     0x130a2ec: bl              #0x13df928  ; AllocateArrayStub
    // 0x130a2f0: r16 = "Invalid envelope: "
    //     0x130a2f0: add             x16, PP, #0xe, lsl #12  ; [pp+0xe050] "Invalid envelope: "
    //     0x130a2f4: ldr             x16, [x16, #0x50]
    // 0x130a2f8: StoreField: r0->field_f = r16
    //     0x130a2f8: stur            w16, [x0, #0xf]
    // 0x130a2fc: ldur            x1, [fp, #-8]
    // 0x130a300: StoreField: r0->field_13 = r1
    //     0x130a300: stur            w1, [x0, #0x13]
    // 0x130a304: str             x0, [SP]
    // 0x130a308: r0 = _interpolate()
    //     0x130a308: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x130a30c: stur            x0, [fp, #-8]
    // 0x130a310: r0 = FormatException()
    //     0x130a310: bl              #0x7e4b0c  ; AllocateFormatExceptionStub -> FormatException (size=0x14)
    // 0x130a314: mov             x1, x0
    // 0x130a318: ldur            x0, [fp, #-8]
    // 0x130a31c: StoreField: r1->field_7 = r0
    //     0x130a31c: stur            w0, [x1, #7]
    // 0x130a320: mov             x0, x1
    // 0x130a324: r0 = Throw()
    //     0x130a324: bl              #0x13ddb2c  ; ThrowStub
    // 0x130a328: brk             #0
    // 0x130a32c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x130a32c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x130a330: b               #0x1309ce4
  }
  _ encodeErrorEnvelope(/* No info */) {
    // ** addr: 0x130a518, size: 0xd4
    // 0x130a518: EnterFrame
    //     0x130a518: stp             fp, lr, [SP, #-0x10]!
    //     0x130a51c: mov             fp, SP
    // 0x130a520: AllocStack(0x20)
    //     0x130a520: sub             SP, SP, #0x20
    // 0x130a524: SetupParameters(dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, {dynamic details = Null /* r5, fp-0x8 */})
    //     0x130a524: mov             x0, x2
    //     0x130a528: stur            x2, [fp, #-0x10]
    //     0x130a52c: stur            x3, [fp, #-0x18]
    //     0x130a530: ldur            w1, [x4, #0x13]
    //     0x130a534: ldur            w2, [x4, #0x1f]
    //     0x130a538: add             x2, x2, HEAP, lsl #32
    //     0x130a53c: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf78] "details"
    //     0x130a540: ldr             x16, [x16, #0xf78]
    //     0x130a544: cmp             w2, w16
    //     0x130a548: b.ne            #0x130a568
    //     0x130a54c: ldur            w2, [x4, #0x23]
    //     0x130a550: add             x2, x2, HEAP, lsl #32
    //     0x130a554: sub             w4, w1, w2
    //     0x130a558: add             x1, fp, w4, sxtw #2
    //     0x130a55c: ldr             x1, [x1, #8]
    //     0x130a560: mov             x5, x1
    //     0x130a564: b               #0x130a56c
    //     0x130a568: mov             x5, NULL
    //     0x130a56c: mov             x4, #6
    //     0x130a570: stur            x5, [fp, #-8]
    // 0x130a56c: r4 = 6
    // 0x130a574: CheckStackOverflow
    //     0x130a574: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x130a578: cmp             SP, x16
    //     0x130a57c: b.ls            #0x130a5e4
    // 0x130a580: mov             x2, x4
    // 0x130a584: r1 = Null
    //     0x130a584: mov             x1, NULL
    // 0x130a588: r0 = AllocateArray()
    //     0x130a588: bl              #0x13df928  ; AllocateArrayStub
    // 0x130a58c: mov             x2, x0
    // 0x130a590: ldur            x0, [fp, #-0x10]
    // 0x130a594: stur            x2, [fp, #-0x20]
    // 0x130a598: StoreField: r2->field_f = r0
    //     0x130a598: stur            w0, [x2, #0xf]
    // 0x130a59c: ldur            x0, [fp, #-0x18]
    // 0x130a5a0: StoreField: r2->field_13 = r0
    //     0x130a5a0: stur            w0, [x2, #0x13]
    // 0x130a5a4: ldur            x0, [fp, #-8]
    // 0x130a5a8: ArrayStore: r2[0] = r0  ; List_4
    //     0x130a5a8: stur            w0, [x2, #0x17]
    // 0x130a5ac: r1 = <Object?>
    //     0x130a5ac: ldr             x1, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0x130a5b0: r0 = AllocateGrowableArray()
    //     0x130a5b0: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x130a5b4: mov             x1, x0
    // 0x130a5b8: ldur            x0, [fp, #-0x20]
    // 0x130a5bc: StoreField: r1->field_f = r0
    //     0x130a5bc: stur            w0, [x1, #0xf]
    // 0x130a5c0: r0 = 6
    //     0x130a5c0: mov             x0, #6
    // 0x130a5c4: StoreField: r1->field_b = r0
    //     0x130a5c4: stur            w0, [x1, #0xb]
    // 0x130a5c8: mov             x2, x1
    // 0x130a5cc: r1 = Instance_JSONMessageCodec
    //     0x130a5cc: add             x1, PP, #0xd, lsl #12  ; [pp+0xdfd8] Obj!JSONMessageCodec@129c051
    //     0x130a5d0: ldr             x1, [x1, #0xfd8]
    // 0x130a5d4: r0 = encodeMessage()
    //     0x130a5d4: bl              #0xd0797c  ; [package:flutter/src/services/message_codecs.dart] JSONMessageCodec::encodeMessage
    // 0x130a5d8: LeaveFrame
    //     0x130a5d8: mov             SP, fp
    //     0x130a5dc: ldp             fp, lr, [SP], #0x10
    // 0x130a5e0: ret
    //     0x130a5e0: ret             
    // 0x130a5e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x130a5e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x130a5e8: b               #0x130a580
  }
}

// class id: 2785, size: 0x8, field offset: 0x8
//   const constructor, 
class JSONMessageCodec extends Object
    implements MessageCodec<X0> {

  _ decodeMessage(/* No info */) {
    // ** addr: 0xcd004c, size: 0x60
    // 0xcd004c: EnterFrame
    //     0xcd004c: stp             fp, lr, [SP, #-0x10]!
    //     0xcd0050: mov             fp, SP
    // 0xcd0054: mov             x0, x2
    // 0xcd0058: CheckStackOverflow
    //     0xcd0058: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcd005c: cmp             SP, x16
    //     0xcd0060: b.ls            #0xcd00a4
    // 0xcd0064: cmp             w0, NULL
    // 0xcd0068: b.ne            #0xcd0078
    // 0xcd006c: LeaveFrame
    //     0xcd006c: mov             SP, fp
    //     0xcd0070: ldp             fp, lr, [SP], #0x10
    // 0xcd0074: ret
    //     0xcd0074: ret             
    // 0xcd0078: mov             x2, x0
    // 0xcd007c: r1 = Instance_StringCodec
    //     0xcd007c: add             x1, PP, #0xe, lsl #12  ; [pp+0xe088] Obj!StringCodec@129c061
    //     0xcd0080: ldr             x1, [x1, #0x88]
    // 0xcd0084: r0 = decodeMessage()
    //     0xcd0084: bl              #0xccfec4  ; [package:flutter/src/services/message_codecs.dart] StringCodec::decodeMessage
    // 0xcd0088: mov             x2, x0
    // 0xcd008c: r1 = Instance_JsonCodec
    //     0xcd008c: ldr             x1, [PP, #0x6d00]  ; [pp+0x6d00] Obj!JsonCodec@12b7e21
    // 0xcd0090: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xcd0090: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xcd0094: r0 = decode()
    //     0xcd0094: bl              #0x121a17c  ; [dart:convert] JsonCodec::decode
    // 0xcd0098: LeaveFrame
    //     0xcd0098: mov             SP, fp
    //     0xcd009c: ldp             fp, lr, [SP], #0x10
    // 0xcd00a0: ret
    //     0xcd00a0: ret             
    // 0xcd00a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd00a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd00a8: b               #0xcd0064
  }
  _ encodeMessage(/* No info */) {
    // ** addr: 0xd0797c, size: 0x5c
    // 0xd0797c: EnterFrame
    //     0xd0797c: stp             fp, lr, [SP, #-0x10]!
    //     0xd07980: mov             fp, SP
    // 0xd07984: CheckStackOverflow
    //     0xd07984: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd07988: cmp             SP, x16
    //     0xd0798c: b.ls            #0xd079d0
    // 0xd07990: cmp             w2, NULL
    // 0xd07994: b.ne            #0xd079a8
    // 0xd07998: r0 = Null
    //     0xd07998: mov             x0, NULL
    // 0xd0799c: LeaveFrame
    //     0xd0799c: mov             SP, fp
    //     0xd079a0: ldp             fp, lr, [SP], #0x10
    // 0xd079a4: ret
    //     0xd079a4: ret             
    // 0xd079a8: r1 = Instance_JsonCodec
    //     0xd079a8: ldr             x1, [PP, #0x6d00]  ; [pp+0x6d00] Obj!JsonCodec@12b7e21
    // 0xd079ac: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xd079ac: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xd079b0: r0 = encode()
    //     0xd079b0: bl              #0x12372ac  ; [dart:convert] JsonCodec::encode
    // 0xd079b4: mov             x2, x0
    // 0xd079b8: r1 = Instance_StringCodec
    //     0xd079b8: add             x1, PP, #0xe, lsl #12  ; [pp+0xe088] Obj!StringCodec@129c061
    //     0xd079bc: ldr             x1, [x1, #0x88]
    // 0xd079c0: r0 = encodeMessage()
    //     0xd079c0: bl              #0xd078d8  ; [package:flutter/src/services/message_codecs.dart] StringCodec::encodeMessage
    // 0xd079c4: LeaveFrame
    //     0xd079c4: mov             SP, fp
    //     0xd079c8: ldp             fp, lr, [SP], #0x10
    // 0xd079cc: ret
    //     0xd079cc: ret             
    // 0xd079d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd079d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd079d4: b               #0xd07990
  }
}

// class id: 2786, size: 0x8, field offset: 0x8
//   const constructor, 
class StringCodec extends Object
    implements MessageCodec<X0> {

  _ decodeMessage(/* No info */) {
    // ** addr: 0xccfec4, size: 0x5c
    // 0xccfec4: EnterFrame
    //     0xccfec4: stp             fp, lr, [SP, #-0x10]!
    //     0xccfec8: mov             fp, SP
    // 0xccfecc: CheckStackOverflow
    //     0xccfecc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xccfed0: cmp             SP, x16
    //     0xccfed4: b.ls            #0xccff18
    // 0xccfed8: cmp             w2, NULL
    // 0xccfedc: b.ne            #0xccfef0
    // 0xccfee0: r0 = Null
    //     0xccfee0: mov             x0, NULL
    // 0xccfee4: LeaveFrame
    //     0xccfee4: mov             SP, fp
    //     0xccfee8: ldp             fp, lr, [SP], #0x10
    // 0xccfeec: ret
    //     0xccfeec: ret             
    // 0xccfef0: r1 = Null
    //     0xccfef0: mov             x1, NULL
    // 0xccfef4: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xccfef4: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xccfef8: r0 = Uint8List.sublistView()
    //     0xccfef8: bl              #0xccff20  ; [dart:typed_data] Uint8List::Uint8List.sublistView
    // 0xccfefc: mov             x2, x0
    // 0xccff00: r1 = Instance_Utf8Codec
    //     0xccff00: ldr             x1, [PP, #0x11e0]  ; [pp+0x11e0] Obj!Utf8Codec@12b7e61
    // 0xccff04: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xccff04: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xccff08: r0 = decode()
    //     0xccff08: bl              #0x121a094  ; [dart:convert] Utf8Codec::decode
    // 0xccff0c: LeaveFrame
    //     0xccff0c: mov             SP, fp
    //     0xccff10: ldp             fp, lr, [SP], #0x10
    // 0xccff14: ret
    //     0xccff14: ret             
    // 0xccff18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xccff18: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xccff1c: b               #0xccfed8
  }
  _ encodeMessage(/* No info */) {
    // ** addr: 0xd078d8, size: 0xa4
    // 0xd078d8: EnterFrame
    //     0xd078d8: stp             fp, lr, [SP, #-0x10]!
    //     0xd078dc: mov             fp, SP
    // 0xd078e0: AllocStack(0x8)
    //     0xd078e0: sub             SP, SP, #8
    // 0xd078e4: SetupParameters(dynamic _ /* r2 => r3, fp-0x8 */)
    //     0xd078e4: mov             x3, x2
    //     0xd078e8: stur            x2, [fp, #-8]
    // 0xd078ec: CheckStackOverflow
    //     0xd078ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd078f0: cmp             SP, x16
    //     0xd078f4: b.ls            #0xd07974
    // 0xd078f8: mov             x0, x3
    // 0xd078fc: r2 = Null
    //     0xd078fc: mov             x2, NULL
    // 0xd07900: r1 = Null
    //     0xd07900: mov             x1, NULL
    // 0xd07904: r4 = 60
    //     0xd07904: mov             x4, #0x3c
    // 0xd07908: branchIfSmi(r0, 0xd07914)
    //     0xd07908: tbz             w0, #0, #0xd07914
    // 0xd0790c: r4 = LoadClassIdInstr(r0)
    //     0xd0790c: ldur            x4, [x0, #-1]
    //     0xd07910: ubfx            x4, x4, #0xc, #0x14
    // 0xd07914: sub             x4, x4, #0x5e
    // 0xd07918: cmp             x4, #1
    // 0xd0791c: b.ls            #0xd07930
    // 0xd07920: r8 = String?
    //     0xd07920: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0xd07924: r3 = Null
    //     0xd07924: add             x3, PP, #0xd, lsl #12  ; [pp+0xdf88] Null
    //     0xd07928: ldr             x3, [x3, #0xf88]
    // 0xd0792c: r0 = String?()
    //     0xd0792c: bl              #0x7db310  ; IsType_String?_Stub
    // 0xd07930: ldur            x2, [fp, #-8]
    // 0xd07934: cmp             w2, NULL
    // 0xd07938: b.ne            #0xd0794c
    // 0xd0793c: r0 = Null
    //     0xd0793c: mov             x0, NULL
    // 0xd07940: LeaveFrame
    //     0xd07940: mov             SP, fp
    //     0xd07944: ldp             fp, lr, [SP], #0x10
    // 0xd07948: ret
    //     0xd07948: ret             
    // 0xd0794c: r1 = Instance_Utf8Encoder
    //     0xd0794c: ldr             x1, [PP, #0x11f8]  ; [pp+0x11f8] Obj!Utf8Encoder@12b7f11
    // 0xd07950: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xd07950: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xd07954: r0 = convert()
    //     0xd07954: bl              #0x122268c  ; [dart:convert] Utf8Encoder::convert
    // 0xd07958: mov             x2, x0
    // 0xd0795c: r1 = Null
    //     0xd0795c: mov             x1, NULL
    // 0xd07960: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xd07960: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xd07964: r0 = ByteData.sublistView()
    //     0xd07964: bl              #0x8486c8  ; [dart:typed_data] ByteData::ByteData.sublistView
    // 0xd07968: LeaveFrame
    //     0xd07968: mov             SP, fp
    //     0xd0796c: ldp             fp, lr, [SP], #0x10
    // 0xd07970: ret
    //     0xd07970: ret             
    // 0xd07974: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd07974: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd07978: b               #0xd078f8
  }
}

// class id: 3354, size: 0x8, field offset: 0x8
//   const constructor, 
class StandardMessageCodec extends Object
    implements MessageCodec<X0> {

  _ decodeMessage(/* No info */) {
    // ** addr: 0xccec6c, size: 0x8c
    // 0xccec6c: EnterFrame
    //     0xccec6c: stp             fp, lr, [SP, #-0x10]!
    //     0xccec70: mov             fp, SP
    // 0xccec74: AllocStack(0x18)
    //     0xccec74: sub             SP, SP, #0x18
    // 0xccec78: SetupParameters(StandardMessageCodec this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xccec78: stur            x1, [fp, #-8]
    //     0xccec7c: stur            x2, [fp, #-0x10]
    // 0xccec80: CheckStackOverflow
    //     0xccec80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xccec84: cmp             SP, x16
    //     0xccec88: b.ls            #0xccecf0
    // 0xccec8c: cmp             w2, NULL
    // 0xccec90: b.ne            #0xcceca4
    // 0xccec94: r0 = Null
    //     0xccec94: mov             x0, NULL
    // 0xccec98: LeaveFrame
    //     0xccec98: mov             SP, fp
    //     0xccec9c: ldp             fp, lr, [SP], #0x10
    // 0xcceca0: ret
    //     0xcceca0: ret             
    // 0xcceca4: r0 = ReadBuffer()
    //     0xcceca4: bl              #0xccee0c  ; AllocateReadBufferStub -> ReadBuffer (size=0x14)
    // 0xcceca8: stur            x0, [fp, #-0x18]
    // 0xccecac: StoreField: r0->field_b = rZR
    //     0xccecac: stur            xzr, [x0, #0xb]
    // 0xccecb0: ldur            x1, [fp, #-0x10]
    // 0xccecb4: StoreField: r0->field_7 = r1
    //     0xccecb4: stur            w1, [x0, #7]
    // 0xccecb8: ldur            x1, [fp, #-8]
    // 0xccecbc: mov             x2, x0
    // 0xccecc0: r0 = readValue()
    //     0xccecc0: bl              #0xcced20  ; [package:flutter/src/services/message_codecs.dart] StandardMessageCodec::readValue
    // 0xccecc4: ldur            x1, [fp, #-0x18]
    // 0xccecc8: stur            x0, [fp, #-8]
    // 0xcceccc: r0 = hasRemaining()
    //     0xcceccc: bl              #0xccecf8  ; [package:flutter/src/foundation/serialization.dart] ReadBuffer::hasRemaining
    // 0xccecd0: tbz             w0, #4, #0xccece4
    // 0xccecd4: ldur            x0, [fp, #-8]
    // 0xccecd8: LeaveFrame
    //     0xccecd8: mov             SP, fp
    //     0xccecdc: ldp             fp, lr, [SP], #0x10
    // 0xccece0: ret
    //     0xccece0: ret             
    // 0xccece4: r0 = Instance_FormatException
    //     0xccece4: ldr             x0, [PP, #0x3028]  ; [pp+0x3028] Obj!FormatException@12b82d1
    // 0xccece8: r0 = Throw()
    //     0xccece8: bl              #0x13ddb2c  ; ThrowStub
    // 0xccecec: brk             #0
    // 0xccecf0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xccecf0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xccecf4: b               #0xccec8c
  }
  _ readValue(/* No info */) {
    // ** addr: 0xcced20, size: 0x98
    // 0xcced20: EnterFrame
    //     0xcced20: stp             fp, lr, [SP, #-0x10]!
    //     0xcced24: mov             fp, SP
    // 0xcced28: AllocStack(0x10)
    //     0xcced28: sub             SP, SP, #0x10
    // 0xcced2c: SetupParameters(StandardMessageCodec this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xcced2c: mov             x0, x2
    //     0xcced30: stur            x2, [fp, #-0x10]
    //     0xcced34: mov             x2, x1
    //     0xcced38: stur            x1, [fp, #-8]
    // 0xcced3c: CheckStackOverflow
    //     0xcced3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcced40: cmp             SP, x16
    //     0xcced44: b.ls            #0xccedb0
    // 0xcced48: LoadField: r1 = r0->field_b
    //     0xcced48: ldur            x1, [x0, #0xb]
    // 0xcced4c: LoadField: r3 = r0->field_7
    //     0xcced4c: ldur            w3, [x0, #7]
    // 0xcced50: DecompressPointer r3
    //     0xcced50: add             x3, x3, HEAP, lsl #32
    // 0xcced54: LoadField: r4 = r3->field_13
    //     0xcced54: ldur            w4, [x3, #0x13]
    // 0xcced58: r3 = LoadInt32Instr(r4)
    //     0xcced58: sbfx            x3, x4, #1, #0x1f
    // 0xcced5c: cmp             x1, x3
    // 0xcced60: b.ge            #0xcceda4
    // 0xcced64: mov             x1, x0
    // 0xcced68: r0 = getUint8()
    //     0xcced68: bl              #0xccedb8  ; [package:flutter/src/foundation/serialization.dart] ReadBuffer::getUint8
    // 0xcced6c: ldur            x1, [fp, #-8]
    // 0xcced70: r2 = LoadClassIdInstr(r1)
    //     0xcced70: ldur            x2, [x1, #-1]
    //     0xcced74: ubfx            x2, x2, #0xc, #0x14
    // 0xcced78: mov             x16, x0
    // 0xcced7c: mov             x0, x2
    // 0xcced80: mov             x2, x16
    // 0xcced84: ldur            x3, [fp, #-0x10]
    // 0xcced88: r0 = GDT[cid_x0 + 0xb5a7]()
    //     0xcced88: mov             x17, #0xb5a7
    //     0xcced8c: add             lr, x0, x17
    //     0xcced90: ldr             lr, [x21, lr, lsl #3]
    //     0xcced94: blr             lr
    // 0xcced98: LeaveFrame
    //     0xcced98: mov             SP, fp
    //     0xcced9c: ldp             fp, lr, [SP], #0x10
    // 0xcceda0: ret
    //     0xcceda0: ret             
    // 0xcceda4: r0 = Instance_FormatException
    //     0xcceda4: ldr             x0, [PP, #0x3028]  ; [pp+0x3028] Obj!FormatException@12b82d1
    // 0xcceda8: r0 = Throw()
    //     0xcceda8: bl              #0x13ddb2c  ; ThrowStub
    // 0xccedac: brk             #0
    // 0xccedb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xccedb0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xccedb4: b               #0xcced48
  }
  _ encodeMessage(/* No info */) {
    // ** addr: 0xd04fc0, size: 0x8c
    // 0xd04fc0: EnterFrame
    //     0xd04fc0: stp             fp, lr, [SP, #-0x10]!
    //     0xd04fc4: mov             fp, SP
    // 0xd04fc8: AllocStack(0x18)
    //     0xd04fc8: sub             SP, SP, #0x18
    // 0xd04fcc: SetupParameters(StandardMessageCodec this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xd04fcc: mov             x0, x1
    //     0xd04fd0: mov             x3, x2
    //     0xd04fd4: stur            x1, [fp, #-8]
    //     0xd04fd8: stur            x2, [fp, #-0x10]
    // 0xd04fdc: CheckStackOverflow
    //     0xd04fdc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd04fe0: cmp             SP, x16
    //     0xd04fe4: b.ls            #0xd05044
    // 0xd04fe8: cmp             w3, NULL
    // 0xd04fec: b.ne            #0xd05000
    // 0xd04ff0: r0 = Null
    //     0xd04ff0: mov             x0, NULL
    // 0xd04ff4: LeaveFrame
    //     0xd04ff4: mov             SP, fp
    //     0xd04ff8: ldp             fp, lr, [SP], #0x10
    // 0xd04ffc: ret
    //     0xd04ffc: ret             
    // 0xd05000: r1 = Null
    //     0xd05000: mov             x1, NULL
    // 0xd05004: r0 = WriteBuffer()
    //     0xd05004: bl              #0xd05154  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::WriteBuffer
    // 0xd05008: mov             x4, x0
    // 0xd0500c: ldur            x1, [fp, #-8]
    // 0xd05010: stur            x4, [fp, #-0x18]
    // 0xd05014: r0 = LoadClassIdInstr(r1)
    //     0xd05014: ldur            x0, [x1, #-1]
    //     0xd05018: ubfx            x0, x0, #0xc, #0x14
    // 0xd0501c: mov             x2, x4
    // 0xd05020: ldur            x3, [fp, #-0x10]
    // 0xd05024: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd05024: sub             lr, x0, #1, lsl #12
    //     0xd05028: ldr             lr, [x21, lr, lsl #3]
    //     0xd0502c: blr             lr
    // 0xd05030: ldur            x1, [fp, #-0x18]
    // 0xd05034: r0 = done()
    //     0xd05034: bl              #0xd0504c  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::done
    // 0xd05038: LeaveFrame
    //     0xd05038: mov             SP, fp
    //     0xd0503c: ldp             fp, lr, [SP], #0x10
    // 0xd05040: ret
    //     0xd05040: ret             
    // 0xd05044: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd05044: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd05048: b               #0xd04fe8
  }
  _ readValueOfType(/* No info */) {
    // ** addr: 0x10f7eb8, size: 0x528
    // 0x10f7eb8: EnterFrame
    //     0x10f7eb8: stp             fp, lr, [SP, #-0x10]!
    //     0x10f7ebc: mov             fp, SP
    // 0x10f7ec0: AllocStack(0x50)
    //     0x10f7ec0: sub             SP, SP, #0x50
    // 0x10f7ec4: SetupParameters(StandardMessageCodec this /* r1 => r3, fp-0x10 */, dynamic _ /* r3 => r0, fp-0x8 */)
    //     0x10f7ec4: mov             x0, x3
    //     0x10f7ec8: stur            x3, [fp, #-8]
    //     0x10f7ecc: mov             x3, x1
    //     0x10f7ed0: stur            x1, [fp, #-0x10]
    // 0x10f7ed4: CheckStackOverflow
    //     0x10f7ed4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f7ed8: cmp             SP, x16
    //     0x10f7edc: b.ls            #0x10f83b8
    // 0x10f7ee0: cmp             x2, #7
    // 0x10f7ee4: b.gt            #0x10f8024
    // 0x10f7ee8: cmp             x2, #3
    // 0x10f7eec: b.gt            #0x10f7f6c
    // 0x10f7ef0: cmp             x2, #1
    // 0x10f7ef4: b.gt            #0x10f7f28
    // 0x10f7ef8: cmp             x2, #0
    // 0x10f7efc: b.gt            #0x10f7f18
    // 0x10f7f00: lsl             x0, x2, #1
    // 0x10f7f04: cbnz            w0, #0x10f83ac
    // 0x10f7f08: r0 = Null
    //     0x10f7f08: mov             x0, NULL
    // 0x10f7f0c: LeaveFrame
    //     0x10f7f0c: mov             SP, fp
    //     0x10f7f10: ldp             fp, lr, [SP], #0x10
    // 0x10f7f14: ret
    //     0x10f7f14: ret             
    // 0x10f7f18: r0 = true
    //     0x10f7f18: add             x0, NULL, #0x20  ; true
    // 0x10f7f1c: LeaveFrame
    //     0x10f7f1c: mov             SP, fp
    //     0x10f7f20: ldp             fp, lr, [SP], #0x10
    // 0x10f7f24: ret
    //     0x10f7f24: ret             
    // 0x10f7f28: cmp             x2, #2
    // 0x10f7f2c: b.gt            #0x10f7f40
    // 0x10f7f30: r0 = false
    //     0x10f7f30: add             x0, NULL, #0x30  ; false
    // 0x10f7f34: LeaveFrame
    //     0x10f7f34: mov             SP, fp
    //     0x10f7f38: ldp             fp, lr, [SP], #0x10
    // 0x10f7f3c: ret
    //     0x10f7f3c: ret             
    // 0x10f7f40: mov             x1, x0
    // 0x10f7f44: r0 = getInt32()
    //     0x10f7f44: bl              #0x10f88b8  ; [package:flutter/src/foundation/serialization.dart] ReadBuffer::getInt32
    // 0x10f7f48: mov             x2, x0
    // 0x10f7f4c: r0 = BoxInt64Instr(r2)
    //     0x10f7f4c: sbfiz           x0, x2, #1, #0x1f
    //     0x10f7f50: cmp             x2, x0, asr #1
    //     0x10f7f54: b.eq            #0x10f7f60
    //     0x10f7f58: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x10f7f5c: stur            x2, [x0, #7]
    // 0x10f7f60: LeaveFrame
    //     0x10f7f60: mov             SP, fp
    //     0x10f7f64: ldp             fp, lr, [SP], #0x10
    // 0x10f7f68: ret
    //     0x10f7f68: ret             
    // 0x10f7f6c: cmp             x2, #5
    // 0x10f7f70: b.gt            #0x10f7fa8
    // 0x10f7f74: cmp             x2, #4
    // 0x10f7f78: b.gt            #0x10f7ff0
    // 0x10f7f7c: mov             x1, x0
    // 0x10f7f80: r0 = getInt64()
    //     0x10f7f80: bl              #0x10f8840  ; [package:flutter/src/foundation/serialization.dart] ReadBuffer::getInt64
    // 0x10f7f84: mov             x2, x0
    // 0x10f7f88: r0 = BoxInt64Instr(r2)
    //     0x10f7f88: sbfiz           x0, x2, #1, #0x1f
    //     0x10f7f8c: cmp             x2, x0, asr #1
    //     0x10f7f90: b.eq            #0x10f7f9c
    //     0x10f7f94: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x10f7f98: stur            x2, [x0, #7]
    // 0x10f7f9c: LeaveFrame
    //     0x10f7f9c: mov             SP, fp
    //     0x10f7fa0: ldp             fp, lr, [SP], #0x10
    // 0x10f7fa4: ret
    //     0x10f7fa4: ret             
    // 0x10f7fa8: cmp             x2, #6
    // 0x10f7fac: b.gt            #0x10f7ff0
    // 0x10f7fb0: mov             x1, x0
    // 0x10f7fb4: r0 = getFloat64()
    //     0x10f7fb4: bl              #0x10f879c  ; [package:flutter/src/foundation/serialization.dart] ReadBuffer::getFloat64
    // 0x10f7fb8: r0 = inline_Allocate_Double()
    //     0x10f7fb8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x10f7fbc: add             x0, x0, #0x10
    //     0x10f7fc0: cmp             x1, x0
    //     0x10f7fc4: b.ls            #0x10f83c0
    //     0x10f7fc8: str             x0, [THR, #0x60]  ; THR::top
    //     0x10f7fcc: sub             x0, x0, #0xf
    //     0x10f7fd0: mov             x1, #0xe19c
    //     0x10f7fd4: movk            x1, #3, lsl #16
    //     0x10f7fd8: stur            x1, [x0, #-1]
    // 0x10f7fdc: dmb             ishst
    // 0x10f7fe0: StoreField: r0->field_7 = d0
    //     0x10f7fe0: stur            d0, [x0, #7]
    // 0x10f7fe4: LeaveFrame
    //     0x10f7fe4: mov             SP, fp
    //     0x10f7fe8: ldp             fp, lr, [SP], #0x10
    // 0x10f7fec: ret
    //     0x10f7fec: ret             
    // 0x10f7ff0: mov             x1, x3
    // 0x10f7ff4: mov             x2, x0
    // 0x10f7ff8: r0 = readSize()
    //     0x10f7ff8: bl              #0x10f873c  ; [package:flutter/src/services/message_codecs.dart] StandardMessageCodec::readSize
    // 0x10f7ffc: ldur            x1, [fp, #-8]
    // 0x10f8000: mov             x2, x0
    // 0x10f8004: r0 = getUint8List()
    //     0x10f8004: bl              #0xf30f40  ; [package:flutter/src/foundation/serialization.dart] ReadBuffer::getUint8List
    // 0x10f8008: mov             x2, x0
    // 0x10f800c: r1 = Instance_Utf8Decoder
    //     0x10f800c: ldr             x1, [PP, #0x36c0]  ; [pp+0x36c0] Obj!Utf8Decoder@12b7f01
    // 0x10f8010: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x10f8010: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x10f8014: r0 = convert()
    //     0x10f8014: bl              #0x1222e18  ; [dart:convert] Utf8Decoder::convert
    // 0x10f8018: LeaveFrame
    //     0x10f8018: mov             SP, fp
    //     0x10f801c: ldp             fp, lr, [SP], #0x10
    // 0x10f8020: ret
    //     0x10f8020: ret             
    // 0x10f8024: cmp             x2, #0xb
    // 0x10f8028: b.gt            #0x10f80d4
    // 0x10f802c: cmp             x2, #9
    // 0x10f8030: b.gt            #0x10f8084
    // 0x10f8034: cmp             x2, #8
    // 0x10f8038: b.gt            #0x10f8060
    // 0x10f803c: mov             x1, x3
    // 0x10f8040: ldur            x2, [fp, #-8]
    // 0x10f8044: r0 = readSize()
    //     0x10f8044: bl              #0x10f873c  ; [package:flutter/src/services/message_codecs.dart] StandardMessageCodec::readSize
    // 0x10f8048: ldur            x1, [fp, #-8]
    // 0x10f804c: mov             x2, x0
    // 0x10f8050: r0 = getUint8List()
    //     0x10f8050: bl              #0xf30f40  ; [package:flutter/src/foundation/serialization.dart] ReadBuffer::getUint8List
    // 0x10f8054: LeaveFrame
    //     0x10f8054: mov             SP, fp
    //     0x10f8058: ldp             fp, lr, [SP], #0x10
    // 0x10f805c: ret
    //     0x10f805c: ret             
    // 0x10f8060: mov             x1, x3
    // 0x10f8064: ldur            x2, [fp, #-8]
    // 0x10f8068: r0 = readSize()
    //     0x10f8068: bl              #0x10f873c  ; [package:flutter/src/services/message_codecs.dart] StandardMessageCodec::readSize
    // 0x10f806c: ldur            x1, [fp, #-8]
    // 0x10f8070: mov             x2, x0
    // 0x10f8074: r0 = getInt32List()
    //     0x10f8074: bl              #0x10f865c  ; [package:flutter/src/foundation/serialization.dart] ReadBuffer::getInt32List
    // 0x10f8078: LeaveFrame
    //     0x10f8078: mov             SP, fp
    //     0x10f807c: ldp             fp, lr, [SP], #0x10
    // 0x10f8080: ret
    //     0x10f8080: ret             
    // 0x10f8084: cmp             x2, #0xa
    // 0x10f8088: b.gt            #0x10f80b0
    // 0x10f808c: mov             x1, x3
    // 0x10f8090: ldur            x2, [fp, #-8]
    // 0x10f8094: r0 = readSize()
    //     0x10f8094: bl              #0x10f873c  ; [package:flutter/src/services/message_codecs.dart] StandardMessageCodec::readSize
    // 0x10f8098: ldur            x1, [fp, #-8]
    // 0x10f809c: mov             x2, x0
    // 0x10f80a0: r0 = getInt64List()
    //     0x10f80a0: bl              #0x10f85a0  ; [package:flutter/src/foundation/serialization.dart] ReadBuffer::getInt64List
    // 0x10f80a4: LeaveFrame
    //     0x10f80a4: mov             SP, fp
    //     0x10f80a8: ldp             fp, lr, [SP], #0x10
    // 0x10f80ac: ret
    //     0x10f80ac: ret             
    // 0x10f80b0: mov             x1, x3
    // 0x10f80b4: ldur            x2, [fp, #-8]
    // 0x10f80b8: r0 = readSize()
    //     0x10f80b8: bl              #0x10f873c  ; [package:flutter/src/services/message_codecs.dart] StandardMessageCodec::readSize
    // 0x10f80bc: ldur            x1, [fp, #-8]
    // 0x10f80c0: mov             x2, x0
    // 0x10f80c4: r0 = getFloat64List()
    //     0x10f80c4: bl              #0x10f84c0  ; [package:flutter/src/foundation/serialization.dart] ReadBuffer::getFloat64List
    // 0x10f80c8: LeaveFrame
    //     0x10f80c8: mov             SP, fp
    //     0x10f80cc: ldp             fp, lr, [SP], #0x10
    // 0x10f80d0: ret
    //     0x10f80d0: ret             
    // 0x10f80d4: cmp             x2, #0xd
    // 0x10f80d8: b.gt            #0x10f8358
    // 0x10f80dc: cmp             x2, #0xc
    // 0x10f80e0: b.gt            #0x10f81f4
    // 0x10f80e4: ldur            x0, [fp, #-8]
    // 0x10f80e8: mov             x1, x3
    // 0x10f80ec: mov             x2, x0
    // 0x10f80f0: r0 = readSize()
    //     0x10f80f0: bl              #0x10f873c  ; [package:flutter/src/services/message_codecs.dart] StandardMessageCodec::readSize
    // 0x10f80f4: mov             x3, x0
    // 0x10f80f8: stur            x3, [fp, #-0x18]
    // 0x10f80fc: r0 = BoxInt64Instr(r3)
    //     0x10f80fc: sbfiz           x0, x3, #1, #0x1f
    //     0x10f8100: cmp             x3, x0, asr #1
    //     0x10f8104: b.eq            #0x10f8110
    //     0x10f8108: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x10f810c: stur            x3, [x0, #7]
    // 0x10f8110: mov             x2, x0
    // 0x10f8114: r1 = <Object?>
    //     0x10f8114: ldr             x1, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0x10f8118: r0 = AllocateArray()
    //     0x10f8118: bl              #0x13df928  ; AllocateArrayStub
    // 0x10f811c: mov             x2, x0
    // 0x10f8120: ldur            x0, [fp, #-8]
    // 0x10f8124: stur            x2, [fp, #-0x30]
    // 0x10f8128: LoadField: r1 = r0->field_7
    //     0x10f8128: ldur            w1, [x0, #7]
    // 0x10f812c: DecompressPointer r1
    //     0x10f812c: add             x1, x1, HEAP, lsl #32
    // 0x10f8130: LoadField: r3 = r1->field_13
    //     0x10f8130: ldur            w3, [x1, #0x13]
    // 0x10f8134: r4 = LoadInt32Instr(r3)
    //     0x10f8134: sbfx            x4, x3, #1, #0x1f
    // 0x10f8138: stur            x4, [fp, #-0x28]
    // 0x10f813c: r6 = 0
    //     0x10f813c: mov             x6, #0
    // 0x10f8140: ldur            x5, [fp, #-0x10]
    // 0x10f8144: ldur            x3, [fp, #-0x18]
    // 0x10f8148: stur            x6, [fp, #-0x20]
    // 0x10f814c: CheckStackOverflow
    //     0x10f814c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f8150: cmp             SP, x16
    //     0x10f8154: b.ls            #0x10f83d0
    // 0x10f8158: cmp             x6, x3
    // 0x10f815c: b.ge            #0x10f81e4
    // 0x10f8160: LoadField: r1 = r0->field_b
    //     0x10f8160: ldur            x1, [x0, #0xb]
    // 0x10f8164: cmp             x1, x4
    // 0x10f8168: b.ge            #0x10f8388
    // 0x10f816c: mov             x1, x0
    // 0x10f8170: r0 = getUint8()
    //     0x10f8170: bl              #0xccedb8  ; [package:flutter/src/foundation/serialization.dart] ReadBuffer::getUint8
    // 0x10f8174: ldur            x4, [fp, #-0x10]
    // 0x10f8178: r1 = LoadClassIdInstr(r4)
    //     0x10f8178: ldur            x1, [x4, #-1]
    //     0x10f817c: ubfx            x1, x1, #0xc, #0x14
    // 0x10f8180: mov             x2, x0
    // 0x10f8184: mov             x0, x1
    // 0x10f8188: mov             x1, x4
    // 0x10f818c: ldur            x3, [fp, #-8]
    // 0x10f8190: r0 = GDT[cid_x0 + 0xb5a7]()
    //     0x10f8190: mov             x17, #0xb5a7
    //     0x10f8194: add             lr, x0, x17
    //     0x10f8198: ldr             lr, [x21, lr, lsl #3]
    //     0x10f819c: blr             lr
    // 0x10f81a0: ldur            x1, [fp, #-0x30]
    // 0x10f81a4: ldur            x2, [fp, #-0x20]
    // 0x10f81a8: ArrayStore: r1[r2] = r0  ; List_4
    //     0x10f81a8: add             x25, x1, x2, lsl #2
    //     0x10f81ac: add             x25, x25, #0xf
    //     0x10f81b0: str             w0, [x25]
    //     0x10f81b4: tbz             w0, #0, #0x10f81d0
    //     0x10f81b8: ldurb           w16, [x1, #-1]
    //     0x10f81bc: ldurb           w17, [x0, #-1]
    //     0x10f81c0: and             x16, x17, x16, lsr #2
    //     0x10f81c4: tst             x16, HEAP, lsr #32
    //     0x10f81c8: b.eq            #0x10f81d0
    //     0x10f81cc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x10f81d0: add             x6, x2, #1
    // 0x10f81d4: ldur            x0, [fp, #-8]
    // 0x10f81d8: ldur            x2, [fp, #-0x30]
    // 0x10f81dc: ldur            x4, [fp, #-0x28]
    // 0x10f81e0: b               #0x10f8140
    // 0x10f81e4: ldur            x0, [fp, #-0x30]
    // 0x10f81e8: LeaveFrame
    //     0x10f81e8: mov             SP, fp
    //     0x10f81ec: ldp             fp, lr, [SP], #0x10
    // 0x10f81f0: ret
    //     0x10f81f0: ret             
    // 0x10f81f4: ldur            x0, [fp, #-8]
    // 0x10f81f8: ldur            x1, [fp, #-0x10]
    // 0x10f81fc: mov             x2, x0
    // 0x10f8200: r0 = readSize()
    //     0x10f8200: bl              #0x10f873c  ; [package:flutter/src/services/message_codecs.dart] StandardMessageCodec::readSize
    // 0x10f8204: stur            x0, [fp, #-0x18]
    // 0x10f8208: r16 = <Object?, Object?>
    //     0x10f8208: ldr             x16, [PP, #0x4250]  ; [pp+0x4250] TypeArguments: <Object?, Object?>
    // 0x10f820c: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x10f8210: stp             lr, x16, [SP]
    // 0x10f8214: r0 = Map._fromLiteral()
    //     0x10f8214: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x10f8218: mov             x2, x0
    // 0x10f821c: ldur            x0, [fp, #-8]
    // 0x10f8220: stur            x2, [fp, #-0x30]
    // 0x10f8224: LoadField: r1 = r0->field_7
    //     0x10f8224: ldur            w1, [x0, #7]
    // 0x10f8228: DecompressPointer r1
    //     0x10f8228: add             x1, x1, HEAP, lsl #32
    // 0x10f822c: LoadField: r3 = r1->field_13
    //     0x10f822c: ldur            w3, [x1, #0x13]
    // 0x10f8230: r4 = LoadInt32Instr(r3)
    //     0x10f8230: sbfx            x4, x3, #1, #0x1f
    // 0x10f8234: stur            x4, [fp, #-0x28]
    // 0x10f8238: r6 = 0
    //     0x10f8238: mov             x6, #0
    // 0x10f823c: ldur            x5, [fp, #-0x10]
    // 0x10f8240: ldur            x3, [fp, #-0x18]
    // 0x10f8244: stur            x6, [fp, #-0x20]
    // 0x10f8248: CheckStackOverflow
    //     0x10f8248: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f824c: cmp             SP, x16
    //     0x10f8250: b.ls            #0x10f83d8
    // 0x10f8254: cmp             x6, x3
    // 0x10f8258: b.ge            #0x10f8348
    // 0x10f825c: LoadField: r1 = r0->field_b
    //     0x10f825c: ldur            x1, [x0, #0xb]
    // 0x10f8260: cmp             x1, x4
    // 0x10f8264: b.ge            #0x10f83a0
    // 0x10f8268: mov             x1, x0
    // 0x10f826c: r0 = getUint8()
    //     0x10f826c: bl              #0xccedb8  ; [package:flutter/src/foundation/serialization.dart] ReadBuffer::getUint8
    // 0x10f8270: ldur            x4, [fp, #-0x10]
    // 0x10f8274: r1 = LoadClassIdInstr(r4)
    //     0x10f8274: ldur            x1, [x4, #-1]
    //     0x10f8278: ubfx            x1, x1, #0xc, #0x14
    // 0x10f827c: mov             x2, x0
    // 0x10f8280: mov             x0, x1
    // 0x10f8284: mov             x1, x4
    // 0x10f8288: ldur            x3, [fp, #-8]
    // 0x10f828c: r0 = GDT[cid_x0 + 0xb5a7]()
    //     0x10f828c: mov             x17, #0xb5a7
    //     0x10f8290: add             lr, x0, x17
    //     0x10f8294: ldr             lr, [x21, lr, lsl #3]
    //     0x10f8298: blr             lr
    // 0x10f829c: mov             x2, x0
    // 0x10f82a0: ldur            x0, [fp, #-8]
    // 0x10f82a4: stur            x2, [fp, #-0x38]
    // 0x10f82a8: LoadField: r1 = r0->field_b
    //     0x10f82a8: ldur            x1, [x0, #0xb]
    // 0x10f82ac: ldur            x3, [fp, #-0x28]
    // 0x10f82b0: cmp             x1, x3
    // 0x10f82b4: b.ge            #0x10f8394
    // 0x10f82b8: ldur            x4, [fp, #-0x10]
    // 0x10f82bc: ldur            x5, [fp, #-0x20]
    // 0x10f82c0: mov             x1, x0
    // 0x10f82c4: r0 = getUint8()
    //     0x10f82c4: bl              #0xccedb8  ; [package:flutter/src/foundation/serialization.dart] ReadBuffer::getUint8
    // 0x10f82c8: ldur            x4, [fp, #-0x10]
    // 0x10f82cc: r1 = LoadClassIdInstr(r4)
    //     0x10f82cc: ldur            x1, [x4, #-1]
    //     0x10f82d0: ubfx            x1, x1, #0xc, #0x14
    // 0x10f82d4: mov             x2, x0
    // 0x10f82d8: mov             x0, x1
    // 0x10f82dc: mov             x1, x4
    // 0x10f82e0: ldur            x3, [fp, #-8]
    // 0x10f82e4: r0 = GDT[cid_x0 + 0xb5a7]()
    //     0x10f82e4: mov             x17, #0xb5a7
    //     0x10f82e8: add             lr, x0, x17
    //     0x10f82ec: ldr             lr, [x21, lr, lsl #3]
    //     0x10f82f0: blr             lr
    // 0x10f82f4: ldur            x1, [fp, #-0x30]
    // 0x10f82f8: ldur            x2, [fp, #-0x38]
    // 0x10f82fc: stur            x0, [fp, #-0x40]
    // 0x10f8300: r0 = _hashCode()
    //     0x10f8300: bl              #0x13d8cbc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0x10f8304: mov             x2, x0
    // 0x10f8308: r0 = BoxInt64Instr(r2)
    //     0x10f8308: sbfiz           x0, x2, #1, #0x1f
    //     0x10f830c: cmp             x2, x0, asr #1
    //     0x10f8310: b.eq            #0x10f831c
    //     0x10f8314: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x10f8318: stur            x2, [x0, #7]
    // 0x10f831c: ldur            x1, [fp, #-0x30]
    // 0x10f8320: ldur            x2, [fp, #-0x38]
    // 0x10f8324: ldur            x3, [fp, #-0x40]
    // 0x10f8328: mov             x5, x0
    // 0x10f832c: r0 = _set()
    //     0x10f832c: bl              #0x13d8170  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x10f8330: ldur            x0, [fp, #-0x20]
    // 0x10f8334: add             x6, x0, #1
    // 0x10f8338: ldur            x0, [fp, #-8]
    // 0x10f833c: ldur            x2, [fp, #-0x30]
    // 0x10f8340: ldur            x4, [fp, #-0x28]
    // 0x10f8344: b               #0x10f823c
    // 0x10f8348: ldur            x0, [fp, #-0x30]
    // 0x10f834c: LeaveFrame
    //     0x10f834c: mov             SP, fp
    //     0x10f8350: ldp             fp, lr, [SP], #0x10
    // 0x10f8354: ret
    //     0x10f8354: ret             
    // 0x10f8358: lsl             x0, x2, #1
    // 0x10f835c: cmp             w0, #0x1c
    // 0x10f8360: b.ne            #0x10f83ac
    // 0x10f8364: ldur            x1, [fp, #-0x10]
    // 0x10f8368: ldur            x2, [fp, #-8]
    // 0x10f836c: r0 = readSize()
    //     0x10f836c: bl              #0x10f873c  ; [package:flutter/src/services/message_codecs.dart] StandardMessageCodec::readSize
    // 0x10f8370: ldur            x1, [fp, #-8]
    // 0x10f8374: mov             x2, x0
    // 0x10f8378: r0 = getFloat32List()
    //     0x10f8378: bl              #0x10f83e0  ; [package:flutter/src/foundation/serialization.dart] ReadBuffer::getFloat32List
    // 0x10f837c: LeaveFrame
    //     0x10f837c: mov             SP, fp
    //     0x10f8380: ldp             fp, lr, [SP], #0x10
    // 0x10f8384: ret
    //     0x10f8384: ret             
    // 0x10f8388: r0 = Instance_FormatException
    //     0x10f8388: ldr             x0, [PP, #0x3028]  ; [pp+0x3028] Obj!FormatException@12b82d1
    // 0x10f838c: r0 = Throw()
    //     0x10f838c: bl              #0x13ddb2c  ; ThrowStub
    // 0x10f8390: brk             #0
    // 0x10f8394: r0 = Instance_FormatException
    //     0x10f8394: ldr             x0, [PP, #0x3028]  ; [pp+0x3028] Obj!FormatException@12b82d1
    // 0x10f8398: r0 = Throw()
    //     0x10f8398: bl              #0x13ddb2c  ; ThrowStub
    // 0x10f839c: brk             #0
    // 0x10f83a0: r0 = Instance_FormatException
    //     0x10f83a0: ldr             x0, [PP, #0x3028]  ; [pp+0x3028] Obj!FormatException@12b82d1
    // 0x10f83a4: r0 = Throw()
    //     0x10f83a4: bl              #0x13ddb2c  ; ThrowStub
    // 0x10f83a8: brk             #0
    // 0x10f83ac: r0 = Instance_FormatException
    //     0x10f83ac: ldr             x0, [PP, #0x3028]  ; [pp+0x3028] Obj!FormatException@12b82d1
    // 0x10f83b0: r0 = Throw()
    //     0x10f83b0: bl              #0x13ddb2c  ; ThrowStub
    // 0x10f83b4: brk             #0
    // 0x10f83b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10f83b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10f83bc: b               #0x10f7ee0
    // 0x10f83c0: SaveReg d0
    //     0x10f83c0: str             q0, [SP, #-0x10]!
    // 0x10f83c4: r0 = AllocateDouble()
    //     0x10f83c4: bl              #0x13df878  ; AllocateDoubleStub
    // 0x10f83c8: RestoreReg d0
    //     0x10f83c8: ldr             q0, [SP], #0x10
    // 0x10f83cc: b               #0x10f7fe0
    // 0x10f83d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10f83d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10f83d4: b               #0x10f8158
    // 0x10f83d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10f83d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10f83dc: b               #0x10f8254
  }
  _ readSize(/* No info */) {
    // ** addr: 0x10f873c, size: 0x60
    // 0x10f873c: EnterFrame
    //     0x10f873c: stp             fp, lr, [SP, #-0x10]!
    //     0x10f8740: mov             fp, SP
    // 0x10f8744: AllocStack(0x8)
    //     0x10f8744: sub             SP, SP, #8
    // 0x10f8748: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0x10f8748: mov             x0, x2
    //     0x10f874c: stur            x2, [fp, #-8]
    // 0x10f8750: CheckStackOverflow
    //     0x10f8750: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f8754: cmp             SP, x16
    //     0x10f8758: b.ls            #0x10f8794
    // 0x10f875c: mov             x1, x0
    // 0x10f8760: r0 = getUint8()
    //     0x10f8760: bl              #0xccedb8  ; [package:flutter/src/foundation/serialization.dart] ReadBuffer::getUint8
    // 0x10f8764: cmp             x0, #0xfe
    // 0x10f8768: b.ne            #0x10f8778
    // 0x10f876c: ldur            x1, [fp, #-8]
    // 0x10f8770: r0 = getUint16()
    //     0x10f8770: bl              #0xf350b8  ; [package:flutter/src/foundation/serialization.dart] ReadBuffer::getUint16
    // 0x10f8774: b               #0x10f8788
    // 0x10f8778: cmp             x0, #0xff
    // 0x10f877c: b.ne            #0x10f8788
    // 0x10f8780: ldur            x1, [fp, #-8]
    // 0x10f8784: r0 = getUint32()
    //     0x10f8784: bl              #0xf35f28  ; [package:flutter/src/foundation/serialization.dart] ReadBuffer::getUint32
    // 0x10f8788: LeaveFrame
    //     0x10f8788: mov             SP, fp
    //     0x10f878c: ldp             fp, lr, [SP], #0x10
    // 0x10f8790: ret
    //     0x10f8790: ret             
    // 0x10f8794: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10f8794: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10f8798: b               #0x10f875c
  }
  _ writeValue(/* No info */) {
    // ** addr: 0x12f3424, size: 0x818
    // 0x12f3424: EnterFrame
    //     0x12f3424: stp             fp, lr, [SP, #-0x10]!
    //     0x12f3428: mov             fp, SP
    // 0x12f342c: AllocStack(0x50)
    //     0x12f342c: sub             SP, SP, #0x50
    // 0x12f3430: SetupParameters(StandardMessageCodec this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r1, fp-0x18 */)
    //     0x12f3430: mov             x0, x2
    //     0x12f3434: stur            x2, [fp, #-0x10]
    //     0x12f3438: mov             x2, x1
    //     0x12f343c: stur            x1, [fp, #-8]
    //     0x12f3440: mov             x1, x3
    //     0x12f3444: stur            x3, [fp, #-0x18]
    // 0x12f3448: CheckStackOverflow
    //     0x12f3448: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f344c: cmp             SP, x16
    //     0x12f3450: b.ls            #0x12f3c24
    // 0x12f3454: r1 = 2
    //     0x12f3454: mov             x1, #2
    // 0x12f3458: r0 = AllocateContext()
    //     0x12f3458: bl              #0x13de838  ; AllocateContextStub
    // 0x12f345c: mov             x3, x0
    // 0x12f3460: ldur            x0, [fp, #-8]
    // 0x12f3464: stur            x3, [fp, #-0x20]
    // 0x12f3468: StoreField: r3->field_f = r0
    //     0x12f3468: stur            w0, [x3, #0xf]
    // 0x12f346c: ldur            x4, [fp, #-0x10]
    // 0x12f3470: StoreField: r3->field_13 = r4
    //     0x12f3470: stur            w4, [x3, #0x13]
    // 0x12f3474: ldur            x5, [fp, #-0x18]
    // 0x12f3478: cmp             w5, NULL
    // 0x12f347c: b.ne            #0x12f3490
    // 0x12f3480: mov             x1, x4
    // 0x12f3484: r2 = 0
    //     0x12f3484: mov             x2, #0
    // 0x12f3488: r0 = _add()
    //     0x12f3488: bl              #0x12f289c  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_add
    // 0x12f348c: b               #0x12f3bec
    // 0x12f3490: r1 = 60
    //     0x12f3490: mov             x1, #0x3c
    // 0x12f3494: branchIfSmi(r5, 0x12f34a0)
    //     0x12f3494: tbz             w5, #0, #0x12f34a0
    // 0x12f3498: r1 = LoadClassIdInstr(r5)
    //     0x12f3498: ldur            x1, [x5, #-1]
    //     0x12f349c: ubfx            x1, x1, #0xc, #0x14
    // 0x12f34a0: cmp             x1, #0x3f
    // 0x12f34a4: b.ne            #0x12f34c8
    // 0x12f34a8: tst             x5, #0x10
    // 0x12f34ac: csetm           x0, eq
    // 0x12f34b0: and             x0, x0, #0xfffffffffffffffe
    // 0x12f34b4: add             x0, x0, #4
    // 0x12f34b8: r2 = LoadInt32Instr(r0)
    //     0x12f34b8: sbfx            x2, x0, #1, #0x1f
    // 0x12f34bc: mov             x1, x4
    // 0x12f34c0: r0 = _add()
    //     0x12f34c0: bl              #0x12f289c  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_add
    // 0x12f34c4: b               #0x12f3bec
    // 0x12f34c8: cmp             x1, #0x3e
    // 0x12f34cc: b.ne            #0x12f34f8
    // 0x12f34d0: mov             x1, x4
    // 0x12f34d4: r2 = 6
    //     0x12f34d4: mov             x2, #6
    // 0x12f34d8: r0 = _add()
    //     0x12f34d8: bl              #0x12f289c  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_add
    // 0x12f34dc: ldur            x3, [fp, #-0x20]
    // 0x12f34e0: LoadField: r1 = r3->field_13
    //     0x12f34e0: ldur            w1, [x3, #0x13]
    // 0x12f34e4: DecompressPointer r1
    //     0x12f34e4: add             x1, x1, HEAP, lsl #32
    // 0x12f34e8: ldur            x5, [fp, #-0x18]
    // 0x12f34ec: LoadField: d0 = r5->field_7
    //     0x12f34ec: ldur            d0, [x5, #7]
    // 0x12f34f0: r0 = putFloat64()
    //     0x12f34f0: bl              #0x12f4454  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::putFloat64
    // 0x12f34f4: b               #0x12f3bec
    // 0x12f34f8: sub             x16, x1, #0x3c
    // 0x12f34fc: cmp             x16, #1
    // 0x12f3500: b.hi            #0x12f3580
    // 0x12f3504: r0 = LoadInt32Instr(r5)
    //     0x12f3504: sbfx            x0, x5, #1, #0x1f
    //     0x12f3508: tbz             w5, #0, #0x12f3510
    //     0x12f350c: ldur            x0, [x5, #7]
    // 0x12f3510: stur            x0, [fp, #-0x28]
    // 0x12f3514: r17 = -2147483648
    //     0x12f3514: mov             x17, #-0x80000000
    // 0x12f3518: cmp             x0, x17
    // 0x12f351c: b.lt            #0x12f3558
    // 0x12f3520: r17 = 2147483647
    //     0x12f3520: mov             x17, #0x7fffffff
    // 0x12f3524: cmp             x0, x17
    // 0x12f3528: b.gt            #0x12f3550
    // 0x12f352c: mov             x1, x4
    // 0x12f3530: r2 = 3
    //     0x12f3530: mov             x2, #3
    // 0x12f3534: r0 = _add()
    //     0x12f3534: bl              #0x12f289c  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_add
    // 0x12f3538: ldur            x0, [fp, #-0x20]
    // 0x12f353c: LoadField: r1 = r0->field_13
    //     0x12f353c: ldur            w1, [x0, #0x13]
    // 0x12f3540: DecompressPointer r1
    //     0x12f3540: add             x1, x1, HEAP, lsl #32
    // 0x12f3544: ldur            x2, [fp, #-0x28]
    // 0x12f3548: r0 = putInt32()
    //     0x12f3548: bl              #0x12f43c0  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::putInt32
    // 0x12f354c: b               #0x12f3bec
    // 0x12f3550: mov             x0, x3
    // 0x12f3554: b               #0x12f355c
    // 0x12f3558: mov             x0, x3
    // 0x12f355c: mov             x1, x4
    // 0x12f3560: r2 = 4
    //     0x12f3560: mov             x2, #4
    // 0x12f3564: r0 = _add()
    //     0x12f3564: bl              #0x12f289c  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_add
    // 0x12f3568: ldur            x3, [fp, #-0x20]
    // 0x12f356c: LoadField: r1 = r3->field_13
    //     0x12f356c: ldur            w1, [x3, #0x13]
    // 0x12f3570: DecompressPointer r1
    //     0x12f3570: add             x1, x1, HEAP, lsl #32
    // 0x12f3574: ldur            x2, [fp, #-0x28]
    // 0x12f3578: r0 = putInt64()
    //     0x12f3578: bl              #0x12f2260  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::putInt64
    // 0x12f357c: b               #0x12f3bec
    // 0x12f3580: sub             x16, x1, #0x5e
    // 0x12f3584: cmp             x16, #1
    // 0x12f3588: b.hi            #0x12f370c
    // 0x12f358c: mov             x1, x4
    // 0x12f3590: r2 = 7
    //     0x12f3590: mov             x2, #7
    // 0x12f3594: r0 = _add()
    //     0x12f3594: bl              #0x12f289c  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_add
    // 0x12f3598: ldur            x1, [fp, #-0x18]
    // 0x12f359c: LoadField: r0 = r1->field_7
    //     0x12f359c: ldur            w0, [x1, #7]
    // 0x12f35a0: mov             x4, x0
    // 0x12f35a4: stur            x0, [fp, #-0x30]
    // 0x12f35a8: r0 = AllocateUint8Array()
    //     0x12f35a8: bl              #0x13df5f0  ; AllocateUint8ArrayStub
    // 0x12f35ac: mov             x3, x0
    // 0x12f35b0: ldur            x0, [fp, #-0x30]
    // 0x12f35b4: stur            x3, [fp, #-0x40]
    // 0x12f35b8: r4 = LoadInt32Instr(r0)
    //     0x12f35b8: sbfx            x4, x0, #1, #0x1f
    // 0x12f35bc: ldur            x0, [fp, #-0x18]
    // 0x12f35c0: stur            x4, [fp, #-0x38]
    // 0x12f35c4: r1 = LoadClassIdInstr(r0)
    //     0x12f35c4: ldur            x1, [x0, #-1]
    //     0x12f35c8: ubfx            x1, x1, #0xc, #0x14
    // 0x12f35cc: lsl             x1, x1, #1
    // 0x12f35d0: r5 = 0
    //     0x12f35d0: mov             x5, #0
    // 0x12f35d4: stur            x5, [fp, #-0x28]
    // 0x12f35d8: CheckStackOverflow
    //     0x12f35d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f35dc: cmp             SP, x16
    //     0x12f35e0: b.ls            #0x12f3c2c
    // 0x12f35e4: cmp             x5, x4
    // 0x12f35e8: b.ge            #0x12f3650
    // 0x12f35ec: cmp             w1, #0xbc
    // 0x12f35f0: b.ne            #0x12f3600
    // 0x12f35f4: ArrayLoad: r2 = r0[r5]  ; TypedUnsigned_1
    //     0x12f35f4: add             x16, x0, x5
    //     0x12f35f8: ldrb            w2, [x16, #0xf]
    // 0x12f35fc: b               #0x12f3608
    // 0x12f3600: add             x16, x0, x5, lsl #1
    // 0x12f3604: ldurh           w2, [x16, #0xf]
    // 0x12f3608: cmp             x2, #0x7f
    // 0x12f360c: b.gt            #0x12f3624
    // 0x12f3610: ArrayStore: r3[r5] = r2  ; TypeUnknown_1
    //     0x12f3610: add             x6, x3, x5
    //     0x12f3614: strb            w2, [x6, #0x17]
    // 0x12f3618: add             x2, x5, #1
    // 0x12f361c: mov             x5, x2
    // 0x12f3620: b               #0x12f35d4
    // 0x12f3624: mov             x1, x0
    // 0x12f3628: mov             x2, x5
    // 0x12f362c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x12f362c: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x12f3630: r0 = substring()
    //     0x12f3630: bl              #0x7e3f74  ; [dart:core] _StringBase::substring
    // 0x12f3634: mov             x2, x0
    // 0x12f3638: r1 = Instance_Utf8Encoder
    //     0x12f3638: ldr             x1, [PP, #0x11f8]  ; [pp+0x11f8] Obj!Utf8Encoder@12b7f11
    // 0x12f363c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x12f363c: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x12f3640: r0 = convert()
    //     0x12f3640: bl              #0x122268c  ; [dart:convert] Utf8Encoder::convert
    // 0x12f3644: mov             x4, x0
    // 0x12f3648: ldur            x0, [fp, #-0x28]
    // 0x12f364c: b               #0x12f3658
    // 0x12f3650: r4 = Null
    //     0x12f3650: mov             x4, NULL
    // 0x12f3654: r0 = 0
    //     0x12f3654: mov             x0, #0
    // 0x12f3658: stur            x4, [fp, #-0x30]
    // 0x12f365c: stur            x0, [fp, #-0x28]
    // 0x12f3660: cmp             w4, NULL
    // 0x12f3664: b.eq            #0x12f36dc
    // 0x12f3668: ldur            x5, [fp, #-0x20]
    // 0x12f366c: LoadField: r2 = r5->field_13
    //     0x12f366c: ldur            w2, [x5, #0x13]
    // 0x12f3670: DecompressPointer r2
    //     0x12f3670: add             x2, x2, HEAP, lsl #32
    // 0x12f3674: LoadField: r1 = r4->field_13
    //     0x12f3674: ldur            w1, [x4, #0x13]
    // 0x12f3678: r3 = LoadInt32Instr(r1)
    //     0x12f3678: sbfx            x3, x1, #1, #0x1f
    // 0x12f367c: add             x1, x0, x3
    // 0x12f3680: mov             x3, x1
    // 0x12f3684: ldur            x1, [fp, #-8]
    // 0x12f3688: r0 = writeSize()
    //     0x12f3688: bl              #0x12f4204  ; [package:flutter/src/services/message_codecs.dart] StandardMessageCodec::writeSize
    // 0x12f368c: ldur            x0, [fp, #-0x20]
    // 0x12f3690: LoadField: r3 = r0->field_13
    //     0x12f3690: ldur            w3, [x0, #0x13]
    // 0x12f3694: DecompressPointer r3
    //     0x12f3694: add             x3, x3, HEAP, lsl #32
    // 0x12f3698: ldur            x1, [fp, #-0x28]
    // 0x12f369c: stur            x3, [fp, #-0x48]
    // 0x12f36a0: lsl             x2, x1, #1
    // 0x12f36a4: str             x2, [SP]
    // 0x12f36a8: ldur            x2, [fp, #-0x40]
    // 0x12f36ac: r1 = Null
    //     0x12f36ac: mov             x1, NULL
    // 0x12f36b0: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x12f36b0: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x12f36b4: r0 = Uint8List.sublistView()
    //     0x12f36b4: bl              #0xccff20  ; [dart:typed_data] Uint8List::Uint8List.sublistView
    // 0x12f36b8: ldur            x1, [fp, #-0x48]
    // 0x12f36bc: mov             x2, x0
    // 0x12f36c0: r0 = _append()
    //     0x12f36c0: bl              #0x12f3ee0  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_append
    // 0x12f36c4: ldur            x0, [fp, #-0x20]
    // 0x12f36c8: LoadField: r1 = r0->field_13
    //     0x12f36c8: ldur            w1, [x0, #0x13]
    // 0x12f36cc: DecompressPointer r1
    //     0x12f36cc: add             x1, x1, HEAP, lsl #32
    // 0x12f36d0: ldur            x2, [fp, #-0x30]
    // 0x12f36d4: r0 = _append()
    //     0x12f36d4: bl              #0x12f3ee0  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_append
    // 0x12f36d8: b               #0x12f3bec
    // 0x12f36dc: ldur            x0, [fp, #-0x20]
    // 0x12f36e0: LoadField: r2 = r0->field_13
    //     0x12f36e0: ldur            w2, [x0, #0x13]
    // 0x12f36e4: DecompressPointer r2
    //     0x12f36e4: add             x2, x2, HEAP, lsl #32
    // 0x12f36e8: ldur            x1, [fp, #-8]
    // 0x12f36ec: ldur            x3, [fp, #-0x38]
    // 0x12f36f0: r0 = writeSize()
    //     0x12f36f0: bl              #0x12f4204  ; [package:flutter/src/services/message_codecs.dart] StandardMessageCodec::writeSize
    // 0x12f36f4: ldur            x3, [fp, #-0x20]
    // 0x12f36f8: LoadField: r1 = r3->field_13
    //     0x12f36f8: ldur            w1, [x3, #0x13]
    // 0x12f36fc: DecompressPointer r1
    //     0x12f36fc: add             x1, x1, HEAP, lsl #32
    // 0x12f3700: ldur            x2, [fp, #-0x40]
    // 0x12f3704: r0 = _append()
    //     0x12f3704: bl              #0x12f3ee0  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_append
    // 0x12f3708: b               #0x12f3bec
    // 0x12f370c: mov             x0, x5
    // 0x12f3710: sub             x16, x1, #0x74
    // 0x12f3714: cmp             x16, #3
    // 0x12f3718: b.hi            #0x12f3760
    // 0x12f371c: mov             x1, x4
    // 0x12f3720: r2 = 8
    //     0x12f3720: mov             x2, #8
    // 0x12f3724: r0 = _add()
    //     0x12f3724: bl              #0x12f289c  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_add
    // 0x12f3728: ldur            x0, [fp, #-0x20]
    // 0x12f372c: LoadField: r2 = r0->field_13
    //     0x12f372c: ldur            w2, [x0, #0x13]
    // 0x12f3730: DecompressPointer r2
    //     0x12f3730: add             x2, x2, HEAP, lsl #32
    // 0x12f3734: ldur            x4, [fp, #-0x18]
    // 0x12f3738: LoadField: r1 = r4->field_13
    //     0x12f3738: ldur            w1, [x4, #0x13]
    // 0x12f373c: r3 = LoadInt32Instr(r1)
    //     0x12f373c: sbfx            x3, x1, #1, #0x1f
    // 0x12f3740: ldur            x1, [fp, #-8]
    // 0x12f3744: r0 = writeSize()
    //     0x12f3744: bl              #0x12f4204  ; [package:flutter/src/services/message_codecs.dart] StandardMessageCodec::writeSize
    // 0x12f3748: ldur            x0, [fp, #-0x20]
    // 0x12f374c: LoadField: r1 = r0->field_13
    //     0x12f374c: ldur            w1, [x0, #0x13]
    // 0x12f3750: DecompressPointer r1
    //     0x12f3750: add             x1, x1, HEAP, lsl #32
    // 0x12f3754: ldur            x2, [fp, #-0x18]
    // 0x12f3758: r0 = _append()
    //     0x12f3758: bl              #0x12f3ee0  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_append
    // 0x12f375c: b               #0x12f3bec
    // 0x12f3760: mov             x0, x3
    // 0x12f3764: sub             x16, x1, #0x84
    // 0x12f3768: cmp             x16, #3
    // 0x12f376c: b.hi            #0x12f37b8
    // 0x12f3770: ldur            x3, [fp, #-0x18]
    // 0x12f3774: mov             x1, x4
    // 0x12f3778: r2 = 9
    //     0x12f3778: mov             x2, #9
    // 0x12f377c: r0 = _add()
    //     0x12f377c: bl              #0x12f289c  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_add
    // 0x12f3780: ldur            x0, [fp, #-0x20]
    // 0x12f3784: LoadField: r2 = r0->field_13
    //     0x12f3784: ldur            w2, [x0, #0x13]
    // 0x12f3788: DecompressPointer r2
    //     0x12f3788: add             x2, x2, HEAP, lsl #32
    // 0x12f378c: ldur            x4, [fp, #-0x18]
    // 0x12f3790: LoadField: r1 = r4->field_13
    //     0x12f3790: ldur            w1, [x4, #0x13]
    // 0x12f3794: r3 = LoadInt32Instr(r1)
    //     0x12f3794: sbfx            x3, x1, #1, #0x1f
    // 0x12f3798: ldur            x1, [fp, #-8]
    // 0x12f379c: r0 = writeSize()
    //     0x12f379c: bl              #0x12f4204  ; [package:flutter/src/services/message_codecs.dart] StandardMessageCodec::writeSize
    // 0x12f37a0: ldur            x0, [fp, #-0x20]
    // 0x12f37a4: LoadField: r1 = r0->field_13
    //     0x12f37a4: ldur            w1, [x0, #0x13]
    // 0x12f37a8: DecompressPointer r1
    //     0x12f37a8: add             x1, x1, HEAP, lsl #32
    // 0x12f37ac: ldur            x2, [fp, #-0x18]
    // 0x12f37b0: r0 = putInt32List()
    //     0x12f37b0: bl              #0x12f3dfc  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::putInt32List
    // 0x12f37b4: b               #0x12f3bec
    // 0x12f37b8: sub             x16, x1, #0x8c
    // 0x12f37bc: cmp             x16, #3
    // 0x12f37c0: b.hi            #0x12f380c
    // 0x12f37c4: ldur            x3, [fp, #-0x18]
    // 0x12f37c8: mov             x1, x4
    // 0x12f37cc: r2 = 10
    //     0x12f37cc: mov             x2, #0xa
    // 0x12f37d0: r0 = _add()
    //     0x12f37d0: bl              #0x12f289c  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_add
    // 0x12f37d4: ldur            x0, [fp, #-0x20]
    // 0x12f37d8: LoadField: r2 = r0->field_13
    //     0x12f37d8: ldur            w2, [x0, #0x13]
    // 0x12f37dc: DecompressPointer r2
    //     0x12f37dc: add             x2, x2, HEAP, lsl #32
    // 0x12f37e0: ldur            x4, [fp, #-0x18]
    // 0x12f37e4: LoadField: r1 = r4->field_13
    //     0x12f37e4: ldur            w1, [x4, #0x13]
    // 0x12f37e8: r3 = LoadInt32Instr(r1)
    //     0x12f37e8: sbfx            x3, x1, #1, #0x1f
    // 0x12f37ec: ldur            x1, [fp, #-8]
    // 0x12f37f0: r0 = writeSize()
    //     0x12f37f0: bl              #0x12f4204  ; [package:flutter/src/services/message_codecs.dart] StandardMessageCodec::writeSize
    // 0x12f37f4: ldur            x0, [fp, #-0x20]
    // 0x12f37f8: LoadField: r1 = r0->field_13
    //     0x12f37f8: ldur            w1, [x0, #0x13]
    // 0x12f37fc: DecompressPointer r1
    //     0x12f37fc: add             x1, x1, HEAP, lsl #32
    // 0x12f3800: ldur            x2, [fp, #-0x18]
    // 0x12f3804: r0 = putInt64List()
    //     0x12f3804: bl              #0x12f3c3c  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::putInt64List
    // 0x12f3808: b               #0x12f3bec
    // 0x12f380c: sub             x16, x1, #0x94
    // 0x12f3810: cmp             x16, #3
    // 0x12f3814: b.hi            #0x12f3860
    // 0x12f3818: ldur            x3, [fp, #-0x18]
    // 0x12f381c: mov             x1, x4
    // 0x12f3820: r2 = 14
    //     0x12f3820: mov             x2, #0xe
    // 0x12f3824: r0 = _add()
    //     0x12f3824: bl              #0x12f289c  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_add
    // 0x12f3828: ldur            x0, [fp, #-0x20]
    // 0x12f382c: LoadField: r2 = r0->field_13
    //     0x12f382c: ldur            w2, [x0, #0x13]
    // 0x12f3830: DecompressPointer r2
    //     0x12f3830: add             x2, x2, HEAP, lsl #32
    // 0x12f3834: ldur            x4, [fp, #-0x18]
    // 0x12f3838: LoadField: r1 = r4->field_13
    //     0x12f3838: ldur            w1, [x4, #0x13]
    // 0x12f383c: r3 = LoadInt32Instr(r1)
    //     0x12f383c: sbfx            x3, x1, #1, #0x1f
    // 0x12f3840: ldur            x1, [fp, #-8]
    // 0x12f3844: r0 = writeSize()
    //     0x12f3844: bl              #0x12f4204  ; [package:flutter/src/services/message_codecs.dart] StandardMessageCodec::writeSize
    // 0x12f3848: ldur            x0, [fp, #-0x20]
    // 0x12f384c: LoadField: r1 = r0->field_13
    //     0x12f384c: ldur            w1, [x0, #0x13]
    // 0x12f3850: DecompressPointer r1
    //     0x12f3850: add             x1, x1, HEAP, lsl #32
    // 0x12f3854: ldur            x2, [fp, #-0x18]
    // 0x12f3858: r0 = putInt32List()
    //     0x12f3858: bl              #0x12f3dfc  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::putInt32List
    // 0x12f385c: b               #0x12f3bec
    // 0x12f3860: sub             x16, x1, #0x98
    // 0x12f3864: cmp             x16, #3
    // 0x12f3868: b.hi            #0x12f38b4
    // 0x12f386c: ldur            x3, [fp, #-0x18]
    // 0x12f3870: mov             x1, x4
    // 0x12f3874: r2 = 11
    //     0x12f3874: mov             x2, #0xb
    // 0x12f3878: r0 = _add()
    //     0x12f3878: bl              #0x12f289c  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_add
    // 0x12f387c: ldur            x0, [fp, #-0x20]
    // 0x12f3880: LoadField: r2 = r0->field_13
    //     0x12f3880: ldur            w2, [x0, #0x13]
    // 0x12f3884: DecompressPointer r2
    //     0x12f3884: add             x2, x2, HEAP, lsl #32
    // 0x12f3888: ldur            x4, [fp, #-0x18]
    // 0x12f388c: LoadField: r1 = r4->field_13
    //     0x12f388c: ldur            w1, [x4, #0x13]
    // 0x12f3890: r3 = LoadInt32Instr(r1)
    //     0x12f3890: sbfx            x3, x1, #1, #0x1f
    // 0x12f3894: ldur            x1, [fp, #-8]
    // 0x12f3898: r0 = writeSize()
    //     0x12f3898: bl              #0x12f4204  ; [package:flutter/src/services/message_codecs.dart] StandardMessageCodec::writeSize
    // 0x12f389c: ldur            x3, [fp, #-0x20]
    // 0x12f38a0: LoadField: r1 = r3->field_13
    //     0x12f38a0: ldur            w1, [x3, #0x13]
    // 0x12f38a4: DecompressPointer r1
    //     0x12f38a4: add             x1, x1, HEAP, lsl #32
    // 0x12f38a8: ldur            x2, [fp, #-0x18]
    // 0x12f38ac: r0 = putInt64List()
    //     0x12f38ac: bl              #0x12f3c3c  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::putInt64List
    // 0x12f38b0: b               #0x12f3bec
    // 0x12f38b4: mov             x3, x0
    // 0x12f38b8: ldur            x0, [fp, #-0x18]
    // 0x12f38bc: r2 = Null
    //     0x12f38bc: mov             x2, NULL
    // 0x12f38c0: r1 = Null
    //     0x12f38c0: mov             x1, NULL
    // 0x12f38c4: cmp             w0, NULL
    // 0x12f38c8: b.eq            #0x12f396c
    // 0x12f38cc: branchIfSmi(r0, 0x12f396c)
    //     0x12f38cc: tbz             w0, #0, #0x12f396c
    // 0x12f38d0: r3 = LoadClassIdInstr(r0)
    //     0x12f38d0: ldur            x3, [x0, #-1]
    //     0x12f38d4: ubfx            x3, x3, #0xc, #0x14
    // 0x12f38d8: r17 = 7631
    //     0x12f38d8: mov             x17, #0x1dcf
    // 0x12f38dc: cmp             x3, x17
    // 0x12f38e0: b.eq            #0x12f3974
    // 0x12f38e4: sub             x3, x3, #0x5a
    // 0x12f38e8: cmp             x3, #2
    // 0x12f38ec: b.ls            #0x12f3974
    // 0x12f38f0: r4 = LoadClassIdInstr(r0)
    //     0x12f38f0: ldur            x4, [x0, #-1]
    //     0x12f38f4: ubfx            x4, x4, #0xc, #0x14
    // 0x12f38f8: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x12f38fc: ldr             x3, [x3, #0x18]
    // 0x12f3900: ldr             x3, [x3, x4, lsl #3]
    // 0x12f3904: LoadField: r3 = r3->field_2b
    //     0x12f3904: ldur            w3, [x3, #0x2b]
    // 0x12f3908: DecompressPointer r3
    //     0x12f3908: add             x3, x3, HEAP, lsl #32
    // 0x12f390c: cmp             w3, NULL
    // 0x12f3910: b.eq            #0x12f396c
    // 0x12f3914: LoadField: r3 = r3->field_f
    //     0x12f3914: ldur            w3, [x3, #0xf]
    // 0x12f3918: lsr             x3, x3, #3
    // 0x12f391c: r17 = 7631
    //     0x12f391c: mov             x17, #0x1dcf
    // 0x12f3920: cmp             x3, x17
    // 0x12f3924: b.eq            #0x12f3974
    // 0x12f3928: r3 = SubtypeTestCache
    //     0x12f3928: add             x3, PP, #0xd, lsl #12  ; [pp+0xdf98] SubtypeTestCache
    //     0x12f392c: ldr             x3, [x3, #0xf98]
    // 0x12f3930: r30 = Subtype1TestCacheStub
    //     0x12f3930: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x12f3934: LoadField: r30 = r30->field_7
    //     0x12f3934: ldur            lr, [lr, #7]
    // 0x12f3938: blr             lr
    // 0x12f393c: cmp             w7, NULL
    // 0x12f3940: b.eq            #0x12f394c
    // 0x12f3944: tbnz            w7, #4, #0x12f396c
    // 0x12f3948: b               #0x12f3974
    // 0x12f394c: r8 = List
    //     0x12f394c: add             x8, PP, #0xd, lsl #12  ; [pp+0xdfa0] Type: List
    //     0x12f3950: ldr             x8, [x8, #0xfa0]
    // 0x12f3954: r3 = SubtypeTestCache
    //     0x12f3954: add             x3, PP, #0xd, lsl #12  ; [pp+0xdfa8] SubtypeTestCache
    //     0x12f3958: ldr             x3, [x3, #0xfa8]
    // 0x12f395c: r30 = InstanceOfStub
    //     0x12f395c: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x12f3960: LoadField: r30 = r30->field_7
    //     0x12f3960: ldur            lr, [lr, #7]
    // 0x12f3964: blr             lr
    // 0x12f3968: b               #0x12f3978
    // 0x12f396c: r0 = false
    //     0x12f396c: add             x0, NULL, #0x30  ; false
    // 0x12f3970: b               #0x12f3978
    // 0x12f3974: r0 = true
    //     0x12f3974: add             x0, NULL, #0x20  ; true
    // 0x12f3978: tbnz            w0, #4, #0x12f3aa0
    // 0x12f397c: ldur            x3, [fp, #-0x18]
    // 0x12f3980: ldur            x0, [fp, #-0x20]
    // 0x12f3984: ldur            x1, [fp, #-0x10]
    // 0x12f3988: r2 = 12
    //     0x12f3988: mov             x2, #0xc
    // 0x12f398c: r0 = _add()
    //     0x12f398c: bl              #0x12f289c  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_add
    // 0x12f3990: ldur            x2, [fp, #-0x20]
    // 0x12f3994: LoadField: r1 = r2->field_13
    //     0x12f3994: ldur            w1, [x2, #0x13]
    // 0x12f3998: DecompressPointer r1
    //     0x12f3998: add             x1, x1, HEAP, lsl #32
    // 0x12f399c: ldur            x3, [fp, #-0x18]
    // 0x12f39a0: stur            x1, [fp, #-0x30]
    // 0x12f39a4: r0 = LoadClassIdInstr(r3)
    //     0x12f39a4: ldur            x0, [x3, #-1]
    //     0x12f39a8: ubfx            x0, x0, #0xc, #0x14
    // 0x12f39ac: str             x3, [SP]
    // 0x12f39b0: r0 = GDT[cid_x0 + 0xf078]()
    //     0x12f39b0: mov             x17, #0xf078
    //     0x12f39b4: add             lr, x0, x17
    //     0x12f39b8: ldr             lr, [x21, lr, lsl #3]
    //     0x12f39bc: blr             lr
    // 0x12f39c0: r3 = LoadInt32Instr(r0)
    //     0x12f39c0: sbfx            x3, x0, #1, #0x1f
    //     0x12f39c4: tbz             w0, #0, #0x12f39cc
    //     0x12f39c8: ldur            x3, [x0, #7]
    // 0x12f39cc: ldur            x1, [fp, #-8]
    // 0x12f39d0: ldur            x2, [fp, #-0x30]
    // 0x12f39d4: r0 = writeSize()
    //     0x12f39d4: bl              #0x12f4204  ; [package:flutter/src/services/message_codecs.dart] StandardMessageCodec::writeSize
    // 0x12f39d8: ldur            x3, [fp, #-0x18]
    // 0x12f39dc: r0 = LoadClassIdInstr(r3)
    //     0x12f39dc: ldur            x0, [x3, #-1]
    //     0x12f39e0: ubfx            x0, x0, #0xc, #0x14
    // 0x12f39e4: mov             x1, x3
    // 0x12f39e8: r0 = GDT[cid_x0 + 0x12641]()
    //     0x12f39e8: mov             x17, #0x2641
    //     0x12f39ec: movk            x17, #1, lsl #16
    //     0x12f39f0: add             lr, x0, x17
    //     0x12f39f4: ldr             lr, [x21, lr, lsl #3]
    //     0x12f39f8: blr             lr
    // 0x12f39fc: mov             x2, x0
    // 0x12f3a00: stur            x2, [fp, #-0x30]
    // 0x12f3a04: ldur            x4, [fp, #-8]
    // 0x12f3a08: ldur            x3, [fp, #-0x20]
    // 0x12f3a0c: CheckStackOverflow
    //     0x12f3a0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f3a10: cmp             SP, x16
    //     0x12f3a14: b.ls            #0x12f3c34
    // 0x12f3a18: r0 = LoadClassIdInstr(r2)
    //     0x12f3a18: ldur            x0, [x2, #-1]
    //     0x12f3a1c: ubfx            x0, x0, #0xc, #0x14
    // 0x12f3a20: mov             x1, x2
    // 0x12f3a24: r0 = GDT[cid_x0 + 0x1845b]()
    //     0x12f3a24: mov             x17, #0x845b
    //     0x12f3a28: movk            x17, #1, lsl #16
    //     0x12f3a2c: add             lr, x0, x17
    //     0x12f3a30: ldr             lr, [x21, lr, lsl #3]
    //     0x12f3a34: blr             lr
    // 0x12f3a38: tbnz            w0, #4, #0x12f3bec
    // 0x12f3a3c: ldur            x4, [fp, #-8]
    // 0x12f3a40: ldur            x3, [fp, #-0x20]
    // 0x12f3a44: ldur            x2, [fp, #-0x30]
    // 0x12f3a48: r0 = LoadClassIdInstr(r2)
    //     0x12f3a48: ldur            x0, [x2, #-1]
    //     0x12f3a4c: ubfx            x0, x0, #0xc, #0x14
    // 0x12f3a50: mov             x1, x2
    // 0x12f3a54: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0x12f3a54: mov             x17, #0x7d4c
    //     0x12f3a58: movk            x17, #1, lsl #16
    //     0x12f3a5c: add             lr, x0, x17
    //     0x12f3a60: ldr             lr, [x21, lr, lsl #3]
    //     0x12f3a64: blr             lr
    // 0x12f3a68: ldur            x4, [fp, #-0x20]
    // 0x12f3a6c: LoadField: r2 = r4->field_13
    //     0x12f3a6c: ldur            w2, [x4, #0x13]
    // 0x12f3a70: DecompressPointer r2
    //     0x12f3a70: add             x2, x2, HEAP, lsl #32
    // 0x12f3a74: ldur            x5, [fp, #-8]
    // 0x12f3a78: r1 = LoadClassIdInstr(r5)
    //     0x12f3a78: ldur            x1, [x5, #-1]
    //     0x12f3a7c: ubfx            x1, x1, #0xc, #0x14
    // 0x12f3a80: mov             x3, x0
    // 0x12f3a84: mov             x0, x1
    // 0x12f3a88: mov             x1, x5
    // 0x12f3a8c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x12f3a8c: sub             lr, x0, #1, lsl #12
    //     0x12f3a90: ldr             lr, [x21, lr, lsl #3]
    //     0x12f3a94: blr             lr
    // 0x12f3a98: ldur            x2, [fp, #-0x30]
    // 0x12f3a9c: b               #0x12f3a04
    // 0x12f3aa0: ldur            x3, [fp, #-0x18]
    // 0x12f3aa4: mov             x0, x3
    // 0x12f3aa8: r2 = Null
    //     0x12f3aa8: mov             x2, NULL
    // 0x12f3aac: r1 = Null
    //     0x12f3aac: mov             x1, NULL
    // 0x12f3ab0: cmp             w0, NULL
    // 0x12f3ab4: b.eq            #0x12f3b4c
    // 0x12f3ab8: branchIfSmi(r0, 0x12f3b4c)
    //     0x12f3ab8: tbz             w0, #0, #0x12f3b4c
    // 0x12f3abc: r3 = LoadClassIdInstr(r0)
    //     0x12f3abc: ldur            x3, [x0, #-1]
    //     0x12f3ac0: ubfx            x3, x3, #0xc, #0x14
    // 0x12f3ac4: r17 = 7630
    //     0x12f3ac4: mov             x17, #0x1dce
    // 0x12f3ac8: cmp             x3, x17
    // 0x12f3acc: b.eq            #0x12f3b54
    // 0x12f3ad0: r4 = LoadClassIdInstr(r0)
    //     0x12f3ad0: ldur            x4, [x0, #-1]
    //     0x12f3ad4: ubfx            x4, x4, #0xc, #0x14
    // 0x12f3ad8: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x12f3adc: ldr             x3, [x3, #0x18]
    // 0x12f3ae0: ldr             x3, [x3, x4, lsl #3]
    // 0x12f3ae4: LoadField: r3 = r3->field_2b
    //     0x12f3ae4: ldur            w3, [x3, #0x2b]
    // 0x12f3ae8: DecompressPointer r3
    //     0x12f3ae8: add             x3, x3, HEAP, lsl #32
    // 0x12f3aec: cmp             w3, NULL
    // 0x12f3af0: b.eq            #0x12f3b4c
    // 0x12f3af4: LoadField: r3 = r3->field_f
    //     0x12f3af4: ldur            w3, [x3, #0xf]
    // 0x12f3af8: lsr             x3, x3, #3
    // 0x12f3afc: r17 = 7630
    //     0x12f3afc: mov             x17, #0x1dce
    // 0x12f3b00: cmp             x3, x17
    // 0x12f3b04: b.eq            #0x12f3b54
    // 0x12f3b08: r3 = SubtypeTestCache
    //     0x12f3b08: add             x3, PP, #0xd, lsl #12  ; [pp+0xdfb0] SubtypeTestCache
    //     0x12f3b0c: ldr             x3, [x3, #0xfb0]
    // 0x12f3b10: r30 = Subtype1TestCacheStub
    //     0x12f3b10: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x12f3b14: LoadField: r30 = r30->field_7
    //     0x12f3b14: ldur            lr, [lr, #7]
    // 0x12f3b18: blr             lr
    // 0x12f3b1c: cmp             w7, NULL
    // 0x12f3b20: b.eq            #0x12f3b2c
    // 0x12f3b24: tbnz            w7, #4, #0x12f3b4c
    // 0x12f3b28: b               #0x12f3b54
    // 0x12f3b2c: r8 = Map
    //     0x12f3b2c: add             x8, PP, #0xd, lsl #12  ; [pp+0xdfb8] Type: Map
    //     0x12f3b30: ldr             x8, [x8, #0xfb8]
    // 0x12f3b34: r3 = SubtypeTestCache
    //     0x12f3b34: add             x3, PP, #0xd, lsl #12  ; [pp+0xdfc0] SubtypeTestCache
    //     0x12f3b38: ldr             x3, [x3, #0xfc0]
    // 0x12f3b3c: r30 = InstanceOfStub
    //     0x12f3b3c: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x12f3b40: LoadField: r30 = r30->field_7
    //     0x12f3b40: ldur            lr, [lr, #7]
    // 0x12f3b44: blr             lr
    // 0x12f3b48: b               #0x12f3b58
    // 0x12f3b4c: r0 = false
    //     0x12f3b4c: add             x0, NULL, #0x30  ; false
    // 0x12f3b50: b               #0x12f3b58
    // 0x12f3b54: r0 = true
    //     0x12f3b54: add             x0, NULL, #0x20  ; true
    // 0x12f3b58: tbnz            w0, #4, #0x12f3bfc
    // 0x12f3b5c: ldur            x0, [fp, #-0x18]
    // 0x12f3b60: ldur            x3, [fp, #-0x20]
    // 0x12f3b64: ldur            x1, [fp, #-0x10]
    // 0x12f3b68: r2 = 13
    //     0x12f3b68: mov             x2, #0xd
    // 0x12f3b6c: r0 = _add()
    //     0x12f3b6c: bl              #0x12f289c  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_add
    // 0x12f3b70: ldur            x2, [fp, #-0x20]
    // 0x12f3b74: LoadField: r1 = r2->field_13
    //     0x12f3b74: ldur            w1, [x2, #0x13]
    // 0x12f3b78: DecompressPointer r1
    //     0x12f3b78: add             x1, x1, HEAP, lsl #32
    // 0x12f3b7c: ldur            x3, [fp, #-0x18]
    // 0x12f3b80: stur            x1, [fp, #-0x10]
    // 0x12f3b84: r0 = LoadClassIdInstr(r3)
    //     0x12f3b84: ldur            x0, [x3, #-1]
    //     0x12f3b88: ubfx            x0, x0, #0xc, #0x14
    // 0x12f3b8c: str             x3, [SP]
    // 0x12f3b90: r0 = GDT[cid_x0 + 0xf078]()
    //     0x12f3b90: mov             x17, #0xf078
    //     0x12f3b94: add             lr, x0, x17
    //     0x12f3b98: ldr             lr, [x21, lr, lsl #3]
    //     0x12f3b9c: blr             lr
    // 0x12f3ba0: r3 = LoadInt32Instr(r0)
    //     0x12f3ba0: sbfx            x3, x0, #1, #0x1f
    //     0x12f3ba4: tbz             w0, #0, #0x12f3bac
    //     0x12f3ba8: ldur            x3, [x0, #7]
    // 0x12f3bac: ldur            x1, [fp, #-8]
    // 0x12f3bb0: ldur            x2, [fp, #-0x10]
    // 0x12f3bb4: r0 = writeSize()
    //     0x12f3bb4: bl              #0x12f4204  ; [package:flutter/src/services/message_codecs.dart] StandardMessageCodec::writeSize
    // 0x12f3bb8: ldur            x2, [fp, #-0x20]
    // 0x12f3bbc: r1 = Function '<anonymous closure>':.
    //     0x12f3bbc: add             x1, PP, #0xd, lsl #12  ; [pp+0xdfc8] AnonymousClosure: (0x12f44fc), in [package:flutter/src/services/message_codecs.dart] StandardMessageCodec::writeValue (0x12f3424)
    //     0x12f3bc0: ldr             x1, [x1, #0xfc8]
    // 0x12f3bc4: r0 = AllocateClosure()
    //     0x12f3bc4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x12f3bc8: ldur            x1, [fp, #-0x18]
    // 0x12f3bcc: r2 = LoadClassIdInstr(r1)
    //     0x12f3bcc: ldur            x2, [x1, #-1]
    //     0x12f3bd0: ubfx            x2, x2, #0xc, #0x14
    // 0x12f3bd4: mov             x16, x0
    // 0x12f3bd8: mov             x0, x2
    // 0x12f3bdc: mov             x2, x16
    // 0x12f3be0: r0 = GDT[cid_x0 + 0x6c5]()
    //     0x12f3be0: add             lr, x0, #0x6c5
    //     0x12f3be4: ldr             lr, [x21, lr, lsl #3]
    //     0x12f3be8: blr             lr
    // 0x12f3bec: r0 = Null
    //     0x12f3bec: mov             x0, NULL
    // 0x12f3bf0: LeaveFrame
    //     0x12f3bf0: mov             SP, fp
    //     0x12f3bf4: ldp             fp, lr, [SP], #0x10
    // 0x12f3bf8: ret
    //     0x12f3bf8: ret             
    // 0x12f3bfc: ldur            x1, [fp, #-0x18]
    // 0x12f3c00: r0 = ArgumentError()
    //     0x12f3c00: bl              #0x7dcb60  ; AllocateArgumentErrorStub -> ArgumentError (size=0x1c)
    // 0x12f3c04: mov             x1, x0
    // 0x12f3c08: ldur            x0, [fp, #-0x18]
    // 0x12f3c0c: StoreField: r1->field_f = r0
    //     0x12f3c0c: stur            w0, [x1, #0xf]
    // 0x12f3c10: r0 = true
    //     0x12f3c10: add             x0, NULL, #0x20  ; true
    // 0x12f3c14: StoreField: r1->field_b = r0
    //     0x12f3c14: stur            w0, [x1, #0xb]
    // 0x12f3c18: mov             x0, x1
    // 0x12f3c1c: r0 = Throw()
    //     0x12f3c1c: bl              #0x13ddb2c  ; ThrowStub
    // 0x12f3c20: brk             #0
    // 0x12f3c24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f3c24: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f3c28: b               #0x12f3454
    // 0x12f3c2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f3c2c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f3c30: b               #0x12f35e4
    // 0x12f3c34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f3c34: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f3c38: b               #0x12f3a18
  }
  _ writeSize(/* No info */) {
    // ** addr: 0x12f4204, size: 0x98
    // 0x12f4204: EnterFrame
    //     0x12f4204: stp             fp, lr, [SP, #-0x10]!
    //     0x12f4208: mov             fp, SP
    // 0x12f420c: AllocStack(0x10)
    //     0x12f420c: sub             SP, SP, #0x10
    // 0x12f4210: SetupParameters(dynamic _ /* r2 => r3, fp-0x8 */, dynamic _ /* r3 => r0, fp-0x10 */)
    //     0x12f4210: mov             x0, x3
    //     0x12f4214: stur            x3, [fp, #-0x10]
    //     0x12f4218: mov             x3, x2
    //     0x12f421c: stur            x2, [fp, #-8]
    // 0x12f4220: CheckStackOverflow
    //     0x12f4220: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f4224: cmp             SP, x16
    //     0x12f4228: b.ls            #0x12f4294
    // 0x12f422c: cmp             x0, #0xfe
    // 0x12f4230: b.ge            #0x12f4244
    // 0x12f4234: mov             x1, x3
    // 0x12f4238: mov             x2, x0
    // 0x12f423c: r0 = _add()
    //     0x12f423c: bl              #0x12f289c  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_add
    // 0x12f4240: b               #0x12f4284
    // 0x12f4244: r17 = 65535
    //     0x12f4244: mov             x17, #0xffff
    // 0x12f4248: cmp             x0, x17
    // 0x12f424c: b.gt            #0x12f426c
    // 0x12f4250: mov             x1, x3
    // 0x12f4254: r2 = 254
    //     0x12f4254: mov             x2, #0xfe
    // 0x12f4258: r0 = _add()
    //     0x12f4258: bl              #0x12f289c  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_add
    // 0x12f425c: ldur            x1, [fp, #-8]
    // 0x12f4260: ldur            x2, [fp, #-0x10]
    // 0x12f4264: r0 = putUint16()
    //     0x12f4264: bl              #0x12f4330  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::putUint16
    // 0x12f4268: b               #0x12f4284
    // 0x12f426c: ldur            x1, [fp, #-8]
    // 0x12f4270: r2 = 255
    //     0x12f4270: mov             x2, #0xff
    // 0x12f4274: r0 = _add()
    //     0x12f4274: bl              #0x12f289c  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::_add
    // 0x12f4278: ldur            x1, [fp, #-8]
    // 0x12f427c: ldur            x2, [fp, #-0x10]
    // 0x12f4280: r0 = putUint32()
    //     0x12f4280: bl              #0x12f429c  ; [package:flutter/src/foundation/serialization.dart] WriteBuffer::putUint32
    // 0x12f4284: r0 = Null
    //     0x12f4284: mov             x0, NULL
    // 0x12f4288: LeaveFrame
    //     0x12f4288: mov             SP, fp
    //     0x12f428c: ldp             fp, lr, [SP], #0x10
    // 0x12f4290: ret
    //     0x12f4290: ret             
    // 0x12f4294: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f4294: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f4298: b               #0x12f422c
  }
  [closure] void <anonymous closure>(dynamic, Object?, Object?) {
    // ** addr: 0x12f44fc, size: 0x94
    // 0x12f44fc: EnterFrame
    //     0x12f44fc: stp             fp, lr, [SP, #-0x10]!
    //     0x12f4500: mov             fp, SP
    // 0x12f4504: AllocStack(0x8)
    //     0x12f4504: sub             SP, SP, #8
    // 0x12f4508: SetupParameters([dynamic _ /* r0 */])
    //     0x12f4508: ldr             x0, [fp, #0x20]
    //     0x12f450c: ldur            w4, [x0, #0x17]
    //     0x12f4510: add             x4, x4, HEAP, lsl #32
    //     0x12f4514: stur            x4, [fp, #-8]
    // 0x12f4518: CheckStackOverflow
    //     0x12f4518: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f451c: cmp             SP, x16
    //     0x12f4520: b.ls            #0x12f4588
    // 0x12f4524: LoadField: r1 = r4->field_f
    //     0x12f4524: ldur            w1, [x4, #0xf]
    // 0x12f4528: DecompressPointer r1
    //     0x12f4528: add             x1, x1, HEAP, lsl #32
    // 0x12f452c: LoadField: r2 = r4->field_13
    //     0x12f452c: ldur            w2, [x4, #0x13]
    // 0x12f4530: DecompressPointer r2
    //     0x12f4530: add             x2, x2, HEAP, lsl #32
    // 0x12f4534: r0 = LoadClassIdInstr(r1)
    //     0x12f4534: ldur            x0, [x1, #-1]
    //     0x12f4538: ubfx            x0, x0, #0xc, #0x14
    // 0x12f453c: ldr             x3, [fp, #0x18]
    // 0x12f4540: r0 = GDT[cid_x0 + -0x1000]()
    //     0x12f4540: sub             lr, x0, #1, lsl #12
    //     0x12f4544: ldr             lr, [x21, lr, lsl #3]
    //     0x12f4548: blr             lr
    // 0x12f454c: ldur            x0, [fp, #-8]
    // 0x12f4550: LoadField: r1 = r0->field_f
    //     0x12f4550: ldur            w1, [x0, #0xf]
    // 0x12f4554: DecompressPointer r1
    //     0x12f4554: add             x1, x1, HEAP, lsl #32
    // 0x12f4558: LoadField: r2 = r0->field_13
    //     0x12f4558: ldur            w2, [x0, #0x13]
    // 0x12f455c: DecompressPointer r2
    //     0x12f455c: add             x2, x2, HEAP, lsl #32
    // 0x12f4560: r0 = LoadClassIdInstr(r1)
    //     0x12f4560: ldur            x0, [x1, #-1]
    //     0x12f4564: ubfx            x0, x0, #0xc, #0x14
    // 0x12f4568: ldr             x3, [fp, #0x10]
    // 0x12f456c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x12f456c: sub             lr, x0, #1, lsl #12
    //     0x12f4570: ldr             lr, [x21, lr, lsl #3]
    //     0x12f4574: blr             lr
    // 0x12f4578: r0 = Null
    //     0x12f4578: mov             x0, NULL
    // 0x12f457c: LeaveFrame
    //     0x12f457c: mov             SP, fp
    //     0x12f4580: ldp             fp, lr, [SP], #0x10
    // 0x12f4584: ret
    //     0x12f4584: ret             
    // 0x12f4588: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f4588: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f458c: b               #0x12f4524
  }
}
