// lib: , url: package:flutter/src/services/keyboard_inserted_content.dart

// class id: 1049075, size: 0x8
class :: {
}

// class id: 2793, size: 0x14, field offset: 0x8
//   const constructor, 
class KeyboardInsertedContent extends Object {

  _ KeyboardInsertedContent.fromJson(/* No info */) {
    // ** addr: 0x876274, size: 0x220
    // 0x876274: EnterFrame
    //     0x876274: stp             fp, lr, [SP, #-0x10]!
    //     0x876278: mov             fp, SP
    // 0x87627c: AllocStack(0x20)
    //     0x87627c: sub             SP, SP, #0x20
    // 0x876280: SetupParameters(KeyboardInsertedContent this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x876280: mov             x4, x1
    //     0x876284: mov             x3, x2
    //     0x876288: stur            x1, [fp, #-8]
    //     0x87628c: stur            x2, [fp, #-0x10]
    // 0x876290: CheckStackOverflow
    //     0x876290: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x876294: cmp             SP, x16
    //     0x876298: b.ls            #0x87648c
    // 0x87629c: r0 = LoadClassIdInstr(r3)
    //     0x87629c: ldur            x0, [x3, #-1]
    //     0x8762a0: ubfx            x0, x0, #0xc, #0x14
    // 0x8762a4: mov             x1, x3
    // 0x8762a8: r2 = "mimeType"
    //     0x8762a8: ldr             x2, [PP, #0x5e38]  ; [pp+0x5e38] "mimeType"
    // 0x8762ac: r0 = GDT[cid_x0 + -0xd48]()
    //     0x8762ac: sub             lr, x0, #0xd48
    //     0x8762b0: ldr             lr, [x21, lr, lsl #3]
    //     0x8762b4: blr             lr
    // 0x8762b8: mov             x3, x0
    // 0x8762bc: r2 = Null
    //     0x8762bc: mov             x2, NULL
    // 0x8762c0: r1 = Null
    //     0x8762c0: mov             x1, NULL
    // 0x8762c4: stur            x3, [fp, #-0x18]
    // 0x8762c8: r4 = 60
    //     0x8762c8: mov             x4, #0x3c
    // 0x8762cc: branchIfSmi(r0, 0x8762d8)
    //     0x8762cc: tbz             w0, #0, #0x8762d8
    // 0x8762d0: r4 = LoadClassIdInstr(r0)
    //     0x8762d0: ldur            x4, [x0, #-1]
    //     0x8762d4: ubfx            x4, x4, #0xc, #0x14
    // 0x8762d8: sub             x4, x4, #0x5e
    // 0x8762dc: cmp             x4, #1
    // 0x8762e0: b.ls            #0x8762f0
    // 0x8762e4: r8 = String
    //     0x8762e4: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x8762e8: r3 = Null
    //     0x8762e8: ldr             x3, [PP, #0x5e40]  ; [pp+0x5e40] Null
    // 0x8762ec: r0 = String()
    //     0x8762ec: bl              #0x13ee320  ; IsType_String_Stub
    // 0x8762f0: ldur            x0, [fp, #-0x18]
    // 0x8762f4: ldur            x3, [fp, #-8]
    // 0x8762f8: StoreField: r3->field_7 = r0
    //     0x8762f8: stur            w0, [x3, #7]
    //     0x8762fc: ldurb           w16, [x3, #-1]
    //     0x876300: ldurb           w17, [x0, #-1]
    //     0x876304: and             x16, x17, x16, lsr #2
    //     0x876308: tst             x16, HEAP, lsr #32
    //     0x87630c: b.eq            #0x876314
    //     0x876310: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x876314: ldur            x4, [fp, #-0x10]
    // 0x876318: r0 = LoadClassIdInstr(r4)
    //     0x876318: ldur            x0, [x4, #-1]
    //     0x87631c: ubfx            x0, x0, #0xc, #0x14
    // 0x876320: mov             x1, x4
    // 0x876324: r2 = "uri"
    //     0x876324: ldr             x2, [PP, #0x5e50]  ; [pp+0x5e50] "uri"
    // 0x876328: r0 = GDT[cid_x0 + -0xd48]()
    //     0x876328: sub             lr, x0, #0xd48
    //     0x87632c: ldr             lr, [x21, lr, lsl #3]
    //     0x876330: blr             lr
    // 0x876334: mov             x3, x0
    // 0x876338: r2 = Null
    //     0x876338: mov             x2, NULL
    // 0x87633c: r1 = Null
    //     0x87633c: mov             x1, NULL
    // 0x876340: stur            x3, [fp, #-0x18]
    // 0x876344: r4 = 60
    //     0x876344: mov             x4, #0x3c
    // 0x876348: branchIfSmi(r0, 0x876354)
    //     0x876348: tbz             w0, #0, #0x876354
    // 0x87634c: r4 = LoadClassIdInstr(r0)
    //     0x87634c: ldur            x4, [x0, #-1]
    //     0x876350: ubfx            x4, x4, #0xc, #0x14
    // 0x876354: sub             x4, x4, #0x5e
    // 0x876358: cmp             x4, #1
    // 0x87635c: b.ls            #0x87636c
    // 0x876360: r8 = String
    //     0x876360: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x876364: r3 = Null
    //     0x876364: ldr             x3, [PP, #0x5e58]  ; [pp+0x5e58] Null
    // 0x876368: r0 = String()
    //     0x876368: bl              #0x13ee320  ; IsType_String_Stub
    // 0x87636c: ldur            x0, [fp, #-0x18]
    // 0x876370: ldur            x3, [fp, #-8]
    // 0x876374: StoreField: r3->field_b = r0
    //     0x876374: stur            w0, [x3, #0xb]
    //     0x876378: ldurb           w16, [x3, #-1]
    //     0x87637c: ldurb           w17, [x0, #-1]
    //     0x876380: and             x16, x17, x16, lsr #2
    //     0x876384: tst             x16, HEAP, lsr #32
    //     0x876388: b.eq            #0x876390
    //     0x87638c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x876390: ldur            x4, [fp, #-0x10]
    // 0x876394: r0 = LoadClassIdInstr(r4)
    //     0x876394: ldur            x0, [x4, #-1]
    //     0x876398: ubfx            x0, x0, #0xc, #0x14
    // 0x87639c: mov             x1, x4
    // 0x8763a0: r2 = "data"
    //     0x8763a0: ldr             x2, [PP, #0x1370]  ; [pp+0x1370] "data"
    // 0x8763a4: r0 = GDT[cid_x0 + -0xd48]()
    //     0x8763a4: sub             lr, x0, #0xd48
    //     0x8763a8: ldr             lr, [x21, lr, lsl #3]
    //     0x8763ac: blr             lr
    // 0x8763b0: cmp             w0, NULL
    // 0x8763b4: b.eq            #0x876458
    // 0x8763b8: ldur            x1, [fp, #-0x10]
    // 0x8763bc: r0 = LoadClassIdInstr(r1)
    //     0x8763bc: ldur            x0, [x1, #-1]
    //     0x8763c0: ubfx            x0, x0, #0xc, #0x14
    // 0x8763c4: r2 = "data"
    //     0x8763c4: ldr             x2, [PP, #0x1370]  ; [pp+0x1370] "data"
    // 0x8763c8: r0 = GDT[cid_x0 + -0xd48]()
    //     0x8763c8: sub             lr, x0, #0xd48
    //     0x8763cc: ldr             lr, [x21, lr, lsl #3]
    //     0x8763d0: blr             lr
    // 0x8763d4: mov             x3, x0
    // 0x8763d8: r2 = Null
    //     0x8763d8: mov             x2, NULL
    // 0x8763dc: r1 = Null
    //     0x8763dc: mov             x1, NULL
    // 0x8763e0: stur            x3, [fp, #-0x10]
    // 0x8763e4: r8 = Iterable
    //     0x8763e4: ldr             x8, [PP, #0x11a0]  ; [pp+0x11a0] Type: Iterable
    // 0x8763e8: r3 = Null
    //     0x8763e8: ldr             x3, [PP, #0x5e68]  ; [pp+0x5e68] Null
    // 0x8763ec: r0 = Iterable()
    //     0x8763ec: bl              #0x7e7350  ; IsType_Iterable_Stub
    // 0x8763f0: ldur            x2, [fp, #-0x10]
    // 0x8763f4: r1 = <int>
    //     0x8763f4: ldr             x1, [PP, #0x50]  ; [pp+0x50] TypeArguments: <int>
    // 0x8763f8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8763f8: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8763fc: r0 = List.from()
    //     0x8763fc: bl              #0x876494  ; [dart:core] List::List.from
    // 0x876400: stur            x0, [fp, #-0x18]
    // 0x876404: LoadField: r4 = r0->field_b
    //     0x876404: ldur            w4, [x0, #0xb]
    // 0x876408: stur            x4, [fp, #-0x10]
    // 0x87640c: r5 = LoadInt32Instr(r4)
    //     0x87640c: sbfx            x5, x4, #1, #0x1f
    // 0x876410: stur            x5, [fp, #-0x20]
    // 0x876414: tbz             x5, #0x3f, #0x87642c
    // 0x876418: mov             x2, x4
    // 0x87641c: mov             x3, x5
    // 0x876420: r1 = 0
    //     0x876420: mov             x1, #0
    // 0x876424: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x876424: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x876428: r0 = checkValidRange()
    //     0x876428: bl              #0x7db068  ; [dart:core] RangeError::checkValidRange
    // 0x87642c: ldur            x4, [fp, #-0x10]
    // 0x876430: r0 = AllocateUint8Array()
    //     0x876430: bl              #0x13df5f0  ; AllocateUint8ArrayStub
    // 0x876434: mov             x1, x0
    // 0x876438: ldur            x3, [fp, #-0x20]
    // 0x87643c: ldur            x5, [fp, #-0x18]
    // 0x876440: r2 = 0
    //     0x876440: mov             x2, #0
    // 0x876444: r6 = 0
    //     0x876444: mov             x6, #0
    // 0x876448: stur            x0, [fp, #-0x10]
    // 0x87644c: r0 = _slowSetRange()
    //     0x87644c: bl              #0x117e940  ; [dart:typed_data] __Uint8List&_TypedList&_IntListMixin&_TypedIntListMixin::_slowSetRange
    // 0x876450: ldur            x0, [fp, #-0x10]
    // 0x876454: b               #0x87645c
    // 0x876458: r0 = Null
    //     0x876458: mov             x0, NULL
    // 0x87645c: ldur            x1, [fp, #-8]
    // 0x876460: StoreField: r1->field_f = r0
    //     0x876460: stur            w0, [x1, #0xf]
    //     0x876464: ldurb           w16, [x1, #-1]
    //     0x876468: ldurb           w17, [x0, #-1]
    //     0x87646c: and             x16, x17, x16, lsr #2
    //     0x876470: tst             x16, HEAP, lsr #32
    //     0x876474: b.eq            #0x87647c
    //     0x876478: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x87647c: r0 = Null
    //     0x87647c: mov             x0, NULL
    // 0x876480: LeaveFrame
    //     0x876480: mov             SP, fp
    //     0x876484: ldp             fp, lr, [SP], #0x10
    // 0x876488: ret
    //     0x876488: ret             
    // 0x87648c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87648c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x876490: b               #0x87629c
  }
  _ ==(/* No info */) {
    // ** addr: 0x129ab00, size: 0x144
    // 0x129ab00: EnterFrame
    //     0x129ab00: stp             fp, lr, [SP, #-0x10]!
    //     0x129ab04: mov             fp, SP
    // 0x129ab08: AllocStack(0x10)
    //     0x129ab08: sub             SP, SP, #0x10
    // 0x129ab0c: CheckStackOverflow
    //     0x129ab0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x129ab10: cmp             SP, x16
    //     0x129ab14: b.ls            #0x129ac3c
    // 0x129ab18: ldr             x0, [fp, #0x10]
    // 0x129ab1c: cmp             w0, NULL
    // 0x129ab20: b.ne            #0x129ab34
    // 0x129ab24: r0 = false
    //     0x129ab24: add             x0, NULL, #0x30  ; false
    // 0x129ab28: LeaveFrame
    //     0x129ab28: mov             SP, fp
    //     0x129ab2c: ldp             fp, lr, [SP], #0x10
    // 0x129ab30: ret
    //     0x129ab30: ret             
    // 0x129ab34: str             x0, [SP]
    // 0x129ab38: r0 = runtimeType()
    //     0x129ab38: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x129ab3c: r1 = LoadClassIdInstr(r0)
    //     0x129ab3c: ldur            x1, [x0, #-1]
    //     0x129ab40: ubfx            x1, x1, #0xc, #0x14
    // 0x129ab44: r16 = KeyboardInsertedContent
    //     0x129ab44: add             x16, PP, #0xd, lsl #12  ; [pp+0xde98] Type: KeyboardInsertedContent
    //     0x129ab48: ldr             x16, [x16, #0xe98]
    // 0x129ab4c: stp             x16, x0, [SP]
    // 0x129ab50: mov             x0, x1
    // 0x129ab54: mov             lr, x0
    // 0x129ab58: ldr             lr, [x21, lr, lsl #3]
    // 0x129ab5c: blr             lr
    // 0x129ab60: tbz             w0, #4, #0x129ab74
    // 0x129ab64: r0 = false
    //     0x129ab64: add             x0, NULL, #0x30  ; false
    // 0x129ab68: LeaveFrame
    //     0x129ab68: mov             SP, fp
    //     0x129ab6c: ldp             fp, lr, [SP], #0x10
    // 0x129ab70: ret
    //     0x129ab70: ret             
    // 0x129ab74: ldr             x1, [fp, #0x10]
    // 0x129ab78: r0 = 60
    //     0x129ab78: mov             x0, #0x3c
    // 0x129ab7c: branchIfSmi(r1, 0x129ab88)
    //     0x129ab7c: tbz             w1, #0, #0x129ab88
    // 0x129ab80: r0 = LoadClassIdInstr(r1)
    //     0x129ab80: ldur            x0, [x1, #-1]
    //     0x129ab84: ubfx            x0, x0, #0xc, #0x14
    // 0x129ab88: cmp             x0, #0xae9
    // 0x129ab8c: b.ne            #0x129ac2c
    // 0x129ab90: ldr             x2, [fp, #0x18]
    // 0x129ab94: LoadField: r0 = r1->field_7
    //     0x129ab94: ldur            w0, [x1, #7]
    // 0x129ab98: DecompressPointer r0
    //     0x129ab98: add             x0, x0, HEAP, lsl #32
    // 0x129ab9c: LoadField: r3 = r2->field_7
    //     0x129ab9c: ldur            w3, [x2, #7]
    // 0x129aba0: DecompressPointer r3
    //     0x129aba0: add             x3, x3, HEAP, lsl #32
    // 0x129aba4: r4 = LoadClassIdInstr(r0)
    //     0x129aba4: ldur            x4, [x0, #-1]
    //     0x129aba8: ubfx            x4, x4, #0xc, #0x14
    // 0x129abac: stp             x3, x0, [SP]
    // 0x129abb0: mov             x0, x4
    // 0x129abb4: mov             lr, x0
    // 0x129abb8: ldr             lr, [x21, lr, lsl #3]
    // 0x129abbc: blr             lr
    // 0x129abc0: tbnz            w0, #4, #0x129ac2c
    // 0x129abc4: ldr             x2, [fp, #0x18]
    // 0x129abc8: ldr             x1, [fp, #0x10]
    // 0x129abcc: LoadField: r0 = r1->field_b
    //     0x129abcc: ldur            w0, [x1, #0xb]
    // 0x129abd0: DecompressPointer r0
    //     0x129abd0: add             x0, x0, HEAP, lsl #32
    // 0x129abd4: LoadField: r3 = r2->field_b
    //     0x129abd4: ldur            w3, [x2, #0xb]
    // 0x129abd8: DecompressPointer r3
    //     0x129abd8: add             x3, x3, HEAP, lsl #32
    // 0x129abdc: r4 = LoadClassIdInstr(r0)
    //     0x129abdc: ldur            x4, [x0, #-1]
    //     0x129abe0: ubfx            x4, x4, #0xc, #0x14
    // 0x129abe4: stp             x3, x0, [SP]
    // 0x129abe8: mov             x0, x4
    // 0x129abec: mov             lr, x0
    // 0x129abf0: ldr             lr, [x21, lr, lsl #3]
    // 0x129abf4: blr             lr
    // 0x129abf8: tbnz            w0, #4, #0x129ac2c
    // 0x129abfc: ldr             x2, [fp, #0x18]
    // 0x129ac00: ldr             x1, [fp, #0x10]
    // 0x129ac04: LoadField: r3 = r1->field_f
    //     0x129ac04: ldur            w3, [x1, #0xf]
    // 0x129ac08: DecompressPointer r3
    //     0x129ac08: add             x3, x3, HEAP, lsl #32
    // 0x129ac0c: LoadField: r1 = r2->field_f
    //     0x129ac0c: ldur            w1, [x2, #0xf]
    // 0x129ac10: DecompressPointer r1
    //     0x129ac10: add             x1, x1, HEAP, lsl #32
    // 0x129ac14: cmp             w3, w1
    // 0x129ac18: r16 = true
    //     0x129ac18: add             x16, NULL, #0x20  ; true
    // 0x129ac1c: r17 = false
    //     0x129ac1c: add             x17, NULL, #0x30  ; false
    // 0x129ac20: csel            x2, x16, x17, eq
    // 0x129ac24: mov             x0, x2
    // 0x129ac28: b               #0x129ac30
    // 0x129ac2c: r0 = false
    //     0x129ac2c: add             x0, NULL, #0x30  ; false
    // 0x129ac30: LeaveFrame
    //     0x129ac30: mov             SP, fp
    //     0x129ac34: ldp             fp, lr, [SP], #0x10
    // 0x129ac38: ret
    //     0x129ac38: ret             
    // 0x129ac3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x129ac3c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x129ac40: b               #0x129ab18
  }
}
