// lib: , url: package:flutter/src/services/clipboard.dart

// class id: 1049071, size: 0x8
class :: {
}

// class id: 2799, size: 0x8, field offset: 0x8
abstract class Clipboard extends Object {

  static _ hasStrings(/* No info */) async {
    // ** addr: 0x862190, size: 0xc8
    // 0x862190: EnterFrame
    //     0x862190: stp             fp, lr, [SP, #-0x10]!
    //     0x862194: mov             fp, SP
    // 0x862198: AllocStack(0x30)
    //     0x862198: sub             SP, SP, #0x30
    // 0x86219c: SetupParameters()
    //     0x86219c: stur            NULL, [fp, #-8]
    // 0x8621a0: CheckStackOverflow
    //     0x8621a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8621a4: cmp             SP, x16
    //     0x8621a8: b.ls            #0x862250
    // 0x8621ac: InitAsync() -> Future<bool>
    //     0x8621ac: ldr             x0, [PP, #0x1918]  ; [pp+0x1918] TypeArguments: <bool>
    //     0x8621b0: bl              #0x7f5e44  ; InitAsyncStub
    // 0x8621b4: r16 = <Map<String, dynamic>>
    //     0x8621b4: ldr             x16, [PP, #0xb0]  ; [pp+0xb0] TypeArguments: <Map<String, dynamic>>
    // 0x8621b8: r30 = Instance_OptionalMethodChannel
    //     0x8621b8: ldr             lr, [PP, #0x1960]  ; [pp+0x1960] Obj!OptionalMethodChannel@129bec1
    // 0x8621bc: stp             lr, x16, [SP, #0x10]
    // 0x8621c0: r16 = "Clipboard.hasStrings"
    //     0x8621c0: ldr             x16, [PP, #0x50b8]  ; [pp+0x50b8] "Clipboard.hasStrings"
    // 0x8621c4: r30 = "text/plain"
    //     0x8621c4: ldr             lr, [PP, #0x50c0]  ; [pp+0x50c0] "text/plain"
    // 0x8621c8: stp             lr, x16, [SP]
    // 0x8621cc: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x8621cc: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x8621d0: r0 = invokeMethod()
    //     0x8621d0: bl              #0x130ad0c  ; [package:flutter/src/services/platform_channel.dart] OptionalMethodChannel::invokeMethod
    // 0x8621d4: mov             x1, x0
    // 0x8621d8: stur            x1, [fp, #-0x10]
    // 0x8621dc: r0 = Await()
    //     0x8621dc: bl              #0x7f5c00  ; AwaitStub
    // 0x8621e0: cmp             w0, NULL
    // 0x8621e4: b.ne            #0x8621f0
    // 0x8621e8: r0 = false
    //     0x8621e8: add             x0, NULL, #0x30  ; false
    // 0x8621ec: r0 = ReturnAsyncNotFuture()
    //     0x8621ec: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x8621f0: r1 = LoadClassIdInstr(r0)
    //     0x8621f0: ldur            x1, [x0, #-1]
    //     0x8621f4: ubfx            x1, x1, #0xc, #0x14
    // 0x8621f8: mov             x16, x0
    // 0x8621fc: mov             x0, x1
    // 0x862200: mov             x1, x16
    // 0x862204: r2 = "value"
    //     0x862204: ldr             x2, [PP, #0x50c8]  ; [pp+0x50c8] "value"
    // 0x862208: r0 = GDT[cid_x0 + -0xd48]()
    //     0x862208: sub             lr, x0, #0xd48
    //     0x86220c: ldr             lr, [x21, lr, lsl #3]
    //     0x862210: blr             lr
    // 0x862214: mov             x3, x0
    // 0x862218: r2 = Null
    //     0x862218: mov             x2, NULL
    // 0x86221c: r1 = Null
    //     0x86221c: mov             x1, NULL
    // 0x862220: stur            x3, [fp, #-0x10]
    // 0x862224: r4 = 60
    //     0x862224: mov             x4, #0x3c
    // 0x862228: branchIfSmi(r0, 0x862234)
    //     0x862228: tbz             w0, #0, #0x862234
    // 0x86222c: r4 = LoadClassIdInstr(r0)
    //     0x86222c: ldur            x4, [x0, #-1]
    //     0x862230: ubfx            x4, x4, #0xc, #0x14
    // 0x862234: cmp             x4, #0x3f
    // 0x862238: b.eq            #0x862248
    // 0x86223c: r8 = bool
    //     0x86223c: ldr             x8, [PP, #0xb18]  ; [pp+0xb18] Type: bool
    // 0x862240: r3 = Null
    //     0x862240: ldr             x3, [PP, #0x50d0]  ; [pp+0x50d0] Null
    // 0x862244: r0 = bool()
    //     0x862244: bl              #0x13ee15c  ; IsType_bool_Stub
    // 0x862248: ldur            x0, [fp, #-0x10]
    // 0x86224c: r0 = ReturnAsyncNotFuture()
    //     0x86224c: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x862250: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x862250: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x862254: b               #0x8621ac
  }
  static _ setData(/* No info */) async {
    // ** addr: 0xb331e0, size: 0x94
    // 0xb331e0: EnterFrame
    //     0xb331e0: stp             fp, lr, [SP, #-0x10]!
    //     0xb331e4: mov             fp, SP
    // 0xb331e8: AllocStack(0x30)
    //     0xb331e8: sub             SP, SP, #0x30
    // 0xb331ec: SetupParameters(dynamic _ /* r1 => r1, fp-0x10 */)
    //     0xb331ec: stur            NULL, [fp, #-8]
    //     0xb331f0: stur            x1, [fp, #-0x10]
    // 0xb331f4: CheckStackOverflow
    //     0xb331f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb331f8: cmp             SP, x16
    //     0xb331fc: b.ls            #0xb3326c
    // 0xb33200: InitAsync() -> Future<void?>
    //     0xb33200: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0xb33204: bl              #0x7f5e44  ; InitAsyncStub
    // 0xb33208: r1 = Null
    //     0xb33208: mov             x1, NULL
    // 0xb3320c: r2 = 4
    //     0xb3320c: mov             x2, #4
    // 0xb33210: r0 = AllocateArray()
    //     0xb33210: bl              #0x13df928  ; AllocateArrayStub
    // 0xb33214: r16 = "text"
    //     0xb33214: ldr             x16, [PP, #0x57e8]  ; [pp+0x57e8] "text"
    // 0xb33218: StoreField: r0->field_f = r16
    //     0xb33218: stur            w16, [x0, #0xf]
    // 0xb3321c: ldur            x1, [fp, #-0x10]
    // 0xb33220: LoadField: r2 = r1->field_7
    //     0xb33220: ldur            w2, [x1, #7]
    // 0xb33224: DecompressPointer r2
    //     0xb33224: add             x2, x2, HEAP, lsl #32
    // 0xb33228: StoreField: r0->field_13 = r2
    //     0xb33228: stur            w2, [x0, #0x13]
    // 0xb3322c: r16 = <String, dynamic>
    //     0xb3322c: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0xb33230: stp             x0, x16, [SP]
    // 0xb33234: r0 = Map._fromLiteral()
    //     0xb33234: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xb33238: r16 = <void?>
    //     0xb33238: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xb3323c: r30 = Instance_OptionalMethodChannel
    //     0xb3323c: ldr             lr, [PP, #0x1960]  ; [pp+0x1960] Obj!OptionalMethodChannel@129bec1
    // 0xb33240: stp             lr, x16, [SP, #0x10]
    // 0xb33244: r16 = "Clipboard.setData"
    //     0xb33244: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a7a8] "Clipboard.setData"
    //     0xb33248: ldr             x16, [x16, #0x7a8]
    // 0xb3324c: stp             x0, x16, [SP]
    // 0xb33250: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xb33250: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xb33254: r0 = invokeMethod()
    //     0xb33254: bl              #0x130ad0c  ; [package:flutter/src/services/platform_channel.dart] OptionalMethodChannel::invokeMethod
    // 0xb33258: mov             x1, x0
    // 0xb3325c: stur            x1, [fp, #-0x10]
    // 0xb33260: r0 = Await()
    //     0xb33260: bl              #0x7f5c00  ; AwaitStub
    // 0xb33264: r0 = Null
    //     0xb33264: mov             x0, NULL
    // 0xb33268: r0 = ReturnAsyncNotFuture()
    //     0xb33268: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xb3326c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb3326c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb33270: b               #0xb33200
  }
  static _ getData(/* No info */) async {
    // ** addr: 0xb34268, size: 0xe0
    // 0xb34268: EnterFrame
    //     0xb34268: stp             fp, lr, [SP, #-0x10]!
    //     0xb3426c: mov             fp, SP
    // 0xb34270: AllocStack(0x30)
    //     0xb34270: sub             SP, SP, #0x30
    // 0xb34274: SetupParameters()
    //     0xb34274: stur            NULL, [fp, #-8]
    // 0xb34278: CheckStackOverflow
    //     0xb34278: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb3427c: cmp             SP, x16
    //     0xb34280: b.ls            #0xb34340
    // 0xb34284: InitAsync() -> Future<ClipboardData?>
    //     0xb34284: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a738] TypeArguments: <ClipboardData?>
    //     0xb34288: ldr             x0, [x0, #0x738]
    //     0xb3428c: bl              #0x7f5e44  ; InitAsyncStub
    // 0xb34290: r16 = <Map<String, dynamic>>
    //     0xb34290: ldr             x16, [PP, #0xb0]  ; [pp+0xb0] TypeArguments: <Map<String, dynamic>>
    // 0xb34294: r30 = Instance_OptionalMethodChannel
    //     0xb34294: ldr             lr, [PP, #0x1960]  ; [pp+0x1960] Obj!OptionalMethodChannel@129bec1
    // 0xb34298: stp             lr, x16, [SP, #0x10]
    // 0xb3429c: r16 = "Clipboard.getData"
    //     0xb3429c: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a740] "Clipboard.getData"
    //     0xb342a0: ldr             x16, [x16, #0x740]
    // 0xb342a4: r30 = "text/plain"
    //     0xb342a4: ldr             lr, [PP, #0x50c0]  ; [pp+0x50c0] "text/plain"
    // 0xb342a8: stp             lr, x16, [SP]
    // 0xb342ac: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xb342ac: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xb342b0: r0 = invokeMethod()
    //     0xb342b0: bl              #0x130ad0c  ; [package:flutter/src/services/platform_channel.dart] OptionalMethodChannel::invokeMethod
    // 0xb342b4: mov             x1, x0
    // 0xb342b8: stur            x1, [fp, #-0x10]
    // 0xb342bc: r0 = Await()
    //     0xb342bc: bl              #0x7f5c00  ; AwaitStub
    // 0xb342c0: cmp             w0, NULL
    // 0xb342c4: b.ne            #0xb342d0
    // 0xb342c8: r0 = Null
    //     0xb342c8: mov             x0, NULL
    // 0xb342cc: r0 = ReturnAsyncNotFuture()
    //     0xb342cc: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xb342d0: r1 = LoadClassIdInstr(r0)
    //     0xb342d0: ldur            x1, [x0, #-1]
    //     0xb342d4: ubfx            x1, x1, #0xc, #0x14
    // 0xb342d8: mov             x16, x0
    // 0xb342dc: mov             x0, x1
    // 0xb342e0: mov             x1, x16
    // 0xb342e4: r2 = "text"
    //     0xb342e4: ldr             x2, [PP, #0x57e8]  ; [pp+0x57e8] "text"
    // 0xb342e8: r0 = GDT[cid_x0 + -0xd48]()
    //     0xb342e8: sub             lr, x0, #0xd48
    //     0xb342ec: ldr             lr, [x21, lr, lsl #3]
    //     0xb342f0: blr             lr
    // 0xb342f4: mov             x3, x0
    // 0xb342f8: r2 = Null
    //     0xb342f8: mov             x2, NULL
    // 0xb342fc: r1 = Null
    //     0xb342fc: mov             x1, NULL
    // 0xb34300: stur            x3, [fp, #-0x10]
    // 0xb34304: r4 = 60
    //     0xb34304: mov             x4, #0x3c
    // 0xb34308: branchIfSmi(r0, 0xb34314)
    //     0xb34308: tbz             w0, #0, #0xb34314
    // 0xb3430c: r4 = LoadClassIdInstr(r0)
    //     0xb3430c: ldur            x4, [x0, #-1]
    //     0xb34310: ubfx            x4, x4, #0xc, #0x14
    // 0xb34314: sub             x4, x4, #0x5e
    // 0xb34318: cmp             x4, #1
    // 0xb3431c: b.ls            #0xb34330
    // 0xb34320: r8 = String
    //     0xb34320: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0xb34324: r3 = Null
    //     0xb34324: add             x3, PP, #0x1a, lsl #12  ; [pp+0x1a748] Null
    //     0xb34328: ldr             x3, [x3, #0x748]
    // 0xb3432c: r0 = String()
    //     0xb3432c: bl              #0x13ee320  ; IsType_String_Stub
    // 0xb34330: r0 = ClipboardData()
    //     0xb34330: bl              #0xb33274  ; AllocateClipboardDataStub -> ClipboardData (size=0xc)
    // 0xb34334: ldur            x1, [fp, #-0x10]
    // 0xb34338: StoreField: r0->field_7 = r1
    //     0xb34338: stur            w1, [x0, #7]
    // 0xb3433c: r0 = ReturnAsyncNotFuture()
    //     0xb3433c: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xb34340: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb34340: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb34344: b               #0xb34284
  }
}

// class id: 2800, size: 0xc, field offset: 0x8
//   const constructor, 
class ClipboardData extends Object {
}
