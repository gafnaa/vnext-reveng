// lib: , url: package:flutter/src/services/font_loader.dart

// class id: 1049072, size: 0x8
class :: {
}

// class id: 2798, size: 0x14, field offset: 0x8
class FontLoader extends Object {

  _ load(/* No info */) async {
    // ** addr: 0xeb2e1c, size: 0x13c
    // 0xeb2e1c: EnterFrame
    //     0xeb2e1c: stp             fp, lr, [SP, #-0x10]!
    //     0xeb2e20: mov             fp, SP
    // 0xeb2e24: AllocStack(0x40)
    //     0xeb2e24: sub             SP, SP, #0x40
    // 0xeb2e28: SetupParameters(FontLoader this /* r1 => r1, fp-0x10 */)
    //     0xeb2e28: stur            NULL, [fp, #-8]
    //     0xeb2e2c: stur            x1, [fp, #-0x10]
    // 0xeb2e30: CheckStackOverflow
    //     0xeb2e30: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeb2e34: cmp             SP, x16
    //     0xeb2e38: b.ls            #0xeb2f48
    // 0xeb2e3c: InitAsync() -> Future<void?>
    //     0xeb2e3c: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0xeb2e40: bl              #0x7f5e44  ; InitAsyncStub
    // 0xeb2e44: ldur            x1, [fp, #-0x10]
    // 0xeb2e48: LoadField: r0 = r1->field_b
    //     0xeb2e48: ldur            w0, [x1, #0xb]
    // 0xeb2e4c: DecompressPointer r0
    //     0xeb2e4c: add             x0, x0, HEAP, lsl #32
    // 0xeb2e50: tbz             w0, #4, #0xeb2f08
    // 0xeb2e54: r0 = true
    //     0xeb2e54: add             x0, NULL, #0x20  ; true
    // 0xeb2e58: StoreField: r1->field_b = r0
    //     0xeb2e58: stur            w0, [x1, #0xb]
    // 0xeb2e5c: LoadField: r2 = r1->field_f
    //     0xeb2e5c: ldur            w2, [x1, #0xf]
    // 0xeb2e60: DecompressPointer r2
    //     0xeb2e60: add             x2, x2, HEAP, lsl #32
    // 0xeb2e64: stur            x2, [fp, #-0x38]
    // 0xeb2e68: LoadField: r0 = r2->field_b
    //     0xeb2e68: ldur            w0, [x2, #0xb]
    // 0xeb2e6c: r3 = LoadInt32Instr(r0)
    //     0xeb2e6c: sbfx            x3, x0, #1, #0x1f
    // 0xeb2e70: stur            x3, [fp, #-0x30]
    // 0xeb2e74: LoadField: r4 = r1->field_7
    //     0xeb2e74: ldur            w4, [x1, #7]
    // 0xeb2e78: DecompressPointer r4
    //     0xeb2e78: add             x4, x4, HEAP, lsl #32
    // 0xeb2e7c: stur            x4, [fp, #-0x28]
    // 0xeb2e80: r0 = 0
    //     0xeb2e80: mov             x0, #0
    // 0xeb2e84: CheckStackOverflow
    //     0xeb2e84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeb2e88: cmp             SP, x16
    //     0xeb2e8c: b.ls            #0xeb2f50
    // 0xeb2e90: LoadField: r5 = r2->field_b
    //     0xeb2e90: ldur            w5, [x2, #0xb]
    // 0xeb2e94: r6 = LoadInt32Instr(r5)
    //     0xeb2e94: sbfx            x6, x5, #1, #0x1f
    // 0xeb2e98: cmp             x3, x6
    // 0xeb2e9c: b.ne            #0xeb2f28
    // 0xeb2ea0: cmp             x0, x6
    // 0xeb2ea4: b.ge            #0xeb2f00
    // 0xeb2ea8: LoadField: r5 = r2->field_f
    //     0xeb2ea8: ldur            w5, [x2, #0xf]
    // 0xeb2eac: DecompressPointer r5
    //     0xeb2eac: add             x5, x5, HEAP, lsl #32
    // 0xeb2eb0: ArrayLoad: r6 = r5[r0]  ; Unknown_4
    //     0xeb2eb0: add             x16, x5, x0, lsl #2
    //     0xeb2eb4: ldur            w6, [x16, #0xf]
    // 0xeb2eb8: DecompressPointer r6
    //     0xeb2eb8: add             x6, x6, HEAP, lsl #32
    // 0xeb2ebc: stur            x6, [fp, #-0x20]
    // 0xeb2ec0: add             x5, x0, #1
    // 0xeb2ec4: mov             x0, x6
    // 0xeb2ec8: stur            x5, [fp, #-0x18]
    // 0xeb2ecc: r0 = Await()
    //     0xeb2ecc: bl              #0x7f5c00  ; AwaitStub
    // 0xeb2ed0: mov             x1, x0
    // 0xeb2ed4: ldur            x2, [fp, #-0x28]
    // 0xeb2ed8: r0 = loadFontFromList()
    //     0xeb2ed8: bl              #0xeb2f58  ; [dart:ui] ::loadFontFromList
    // 0xeb2edc: mov             x1, x0
    // 0xeb2ee0: stur            x1, [fp, #-0x40]
    // 0xeb2ee4: r0 = Await()
    //     0xeb2ee4: bl              #0x7f5c00  ; AwaitStub
    // 0xeb2ee8: ldur            x0, [fp, #-0x18]
    // 0xeb2eec: ldur            x1, [fp, #-0x10]
    // 0xeb2ef0: ldur            x2, [fp, #-0x38]
    // 0xeb2ef4: ldur            x4, [fp, #-0x28]
    // 0xeb2ef8: ldur            x3, [fp, #-0x30]
    // 0xeb2efc: b               #0xeb2e84
    // 0xeb2f00: r0 = Null
    //     0xeb2f00: mov             x0, NULL
    // 0xeb2f04: r0 = ReturnAsyncNotFuture()
    //     0xeb2f04: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xeb2f08: r0 = StateError()
    //     0xeb2f08: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xeb2f0c: mov             x1, x0
    // 0xeb2f10: r0 = "FontLoader is already loaded"
    //     0xeb2f10: add             x0, PP, #0x14, lsl #12  ; [pp+0x14028] "FontLoader is already loaded"
    //     0xeb2f14: ldr             x0, [x0, #0x28]
    // 0xeb2f18: StoreField: r1->field_b = r0
    //     0xeb2f18: stur            w0, [x1, #0xb]
    // 0xeb2f1c: mov             x0, x1
    // 0xeb2f20: r0 = Throw()
    //     0xeb2f20: bl              #0x13ddb2c  ; ThrowStub
    // 0xeb2f24: brk             #0
    // 0xeb2f28: mov             x0, x2
    // 0xeb2f2c: r0 = ConcurrentModificationError()
    //     0xeb2f2c: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xeb2f30: mov             x1, x0
    // 0xeb2f34: ldur            x0, [fp, #-0x38]
    // 0xeb2f38: StoreField: r1->field_b = r0
    //     0xeb2f38: stur            w0, [x1, #0xb]
    // 0xeb2f3c: mov             x0, x1
    // 0xeb2f40: r0 = Throw()
    //     0xeb2f40: bl              #0x13ddb2c  ; ThrowStub
    // 0xeb2f44: brk             #0
    // 0xeb2f48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeb2f48: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeb2f4c: b               #0xeb2e3c
    // 0xeb2f50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeb2f50: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeb2f54: b               #0xeb2e90
  }
  _ addFont(/* No info */) {
    // ** addr: 0xeb3370, size: 0x138
    // 0xeb3370: EnterFrame
    //     0xeb3370: stp             fp, lr, [SP, #-0x10]!
    //     0xeb3374: mov             fp, SP
    // 0xeb3378: AllocStack(0x30)
    //     0xeb3378: sub             SP, SP, #0x30
    // 0xeb337c: SetupParameters(dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xeb337c: mov             x0, x2
    //     0xeb3380: stur            x2, [fp, #-0x10]
    // 0xeb3384: CheckStackOverflow
    //     0xeb3384: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeb3388: cmp             SP, x16
    //     0xeb338c: b.ls            #0xeb34a0
    // 0xeb3390: LoadField: r2 = r1->field_b
    //     0xeb3390: ldur            w2, [x1, #0xb]
    // 0xeb3394: DecompressPointer r2
    //     0xeb3394: add             x2, x2, HEAP, lsl #32
    // 0xeb3398: tbz             w2, #4, #0xeb3480
    // 0xeb339c: LoadField: r3 = r1->field_f
    //     0xeb339c: ldur            w3, [x1, #0xf]
    // 0xeb33a0: DecompressPointer r3
    //     0xeb33a0: add             x3, x3, HEAP, lsl #32
    // 0xeb33a4: stur            x3, [fp, #-8]
    // 0xeb33a8: r1 = Function '<anonymous closure>':.
    //     0xeb33a8: add             x1, PP, #0x14, lsl #12  ; [pp+0x14078] AnonymousClosure: (0xeb3534), in [package:flutter/src/services/font_loader.dart] FontLoader::addFont (0xeb3370)
    //     0xeb33ac: ldr             x1, [x1, #0x78]
    // 0xeb33b0: r2 = Null
    //     0xeb33b0: mov             x2, NULL
    // 0xeb33b4: r0 = AllocateClosure()
    //     0xeb33b4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xeb33b8: r16 = <Uint8List>
    //     0xeb33b8: add             x16, PP, #8, lsl #12  ; [pp+0x8548] TypeArguments: <Uint8List>
    //     0xeb33bc: ldr             x16, [x16, #0x548]
    // 0xeb33c0: ldur            lr, [fp, #-0x10]
    // 0xeb33c4: stp             lr, x16, [SP, #8]
    // 0xeb33c8: str             x0, [SP]
    // 0xeb33cc: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xeb33cc: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xeb33d0: r0 = then()
    //     0xeb33d0: bl              #0x1293070  ; [dart:async] _Future::then
    // 0xeb33d4: mov             x3, x0
    // 0xeb33d8: r2 = Null
    //     0xeb33d8: mov             x2, NULL
    // 0xeb33dc: r1 = Null
    //     0xeb33dc: mov             x1, NULL
    // 0xeb33e0: stur            x3, [fp, #-0x10]
    // 0xeb33e4: r8 = Future<Uint8List>
    //     0xeb33e4: add             x8, PP, #0x14, lsl #12  ; [pp+0x14080] Type: Future<Uint8List>
    //     0xeb33e8: ldr             x8, [x8, #0x80]
    // 0xeb33ec: r3 = Null
    //     0xeb33ec: add             x3, PP, #0x14, lsl #12  ; [pp+0x14088] Null
    //     0xeb33f0: ldr             x3, [x3, #0x88]
    // 0xeb33f4: r0 = Future<Uint8List>()
    //     0xeb33f4: bl              #0xeb34a8  ; IsType_Future<Uint8List>_Stub
    // 0xeb33f8: ldur            x0, [fp, #-8]
    // 0xeb33fc: LoadField: r1 = r0->field_b
    //     0xeb33fc: ldur            w1, [x0, #0xb]
    // 0xeb3400: LoadField: r2 = r0->field_f
    //     0xeb3400: ldur            w2, [x0, #0xf]
    // 0xeb3404: DecompressPointer r2
    //     0xeb3404: add             x2, x2, HEAP, lsl #32
    // 0xeb3408: LoadField: r3 = r2->field_b
    //     0xeb3408: ldur            w3, [x2, #0xb]
    // 0xeb340c: r2 = LoadInt32Instr(r1)
    //     0xeb340c: sbfx            x2, x1, #1, #0x1f
    // 0xeb3410: stur            x2, [fp, #-0x18]
    // 0xeb3414: r1 = LoadInt32Instr(r3)
    //     0xeb3414: sbfx            x1, x3, #1, #0x1f
    // 0xeb3418: cmp             x2, x1
    // 0xeb341c: b.ne            #0xeb3428
    // 0xeb3420: mov             x1, x0
    // 0xeb3424: r0 = _growToNextCapacity()
    //     0xeb3424: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xeb3428: ldur            x0, [fp, #-8]
    // 0xeb342c: ldur            x2, [fp, #-0x18]
    // 0xeb3430: add             x1, x2, #1
    // 0xeb3434: lsl             x3, x1, #1
    // 0xeb3438: StoreField: r0->field_b = r3
    //     0xeb3438: stur            w3, [x0, #0xb]
    // 0xeb343c: LoadField: r1 = r0->field_f
    //     0xeb343c: ldur            w1, [x0, #0xf]
    // 0xeb3440: DecompressPointer r1
    //     0xeb3440: add             x1, x1, HEAP, lsl #32
    // 0xeb3444: ldur            x0, [fp, #-0x10]
    // 0xeb3448: ArrayStore: r1[r2] = r0  ; List_4
    //     0xeb3448: add             x25, x1, x2, lsl #2
    //     0xeb344c: add             x25, x25, #0xf
    //     0xeb3450: str             w0, [x25]
    //     0xeb3454: tbz             w0, #0, #0xeb3470
    //     0xeb3458: ldurb           w16, [x1, #-1]
    //     0xeb345c: ldurb           w17, [x0, #-1]
    //     0xeb3460: and             x16, x17, x16, lsr #2
    //     0xeb3464: tst             x16, HEAP, lsr #32
    //     0xeb3468: b.eq            #0xeb3470
    //     0xeb346c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xeb3470: r0 = Null
    //     0xeb3470: mov             x0, NULL
    // 0xeb3474: LeaveFrame
    //     0xeb3474: mov             SP, fp
    //     0xeb3478: ldp             fp, lr, [SP], #0x10
    // 0xeb347c: ret
    //     0xeb347c: ret             
    // 0xeb3480: r0 = StateError()
    //     0xeb3480: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xeb3484: mov             x1, x0
    // 0xeb3488: r0 = "FontLoader is already loaded"
    //     0xeb3488: add             x0, PP, #0x14, lsl #12  ; [pp+0x14028] "FontLoader is already loaded"
    //     0xeb348c: ldr             x0, [x0, #0x28]
    // 0xeb3490: StoreField: r1->field_b = r0
    //     0xeb3490: stur            w0, [x1, #0xb]
    // 0xeb3494: mov             x0, x1
    // 0xeb3498: r0 = Throw()
    //     0xeb3498: bl              #0x13ddb2c  ; ThrowStub
    // 0xeb349c: brk             #0
    // 0xeb34a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeb34a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeb34a4: b               #0xeb3390
  }
  [closure] Uint8List <anonymous closure>(dynamic, ByteData) {
    // ** addr: 0xeb3534, size: 0x74
    // 0xeb3534: EnterFrame
    //     0xeb3534: stp             fp, lr, [SP, #-0x10]!
    //     0xeb3538: mov             fp, SP
    // 0xeb353c: AllocStack(0x10)
    //     0xeb353c: sub             SP, SP, #0x10
    // 0xeb3540: CheckStackOverflow
    //     0xeb3540: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeb3544: cmp             SP, x16
    //     0xeb3548: b.ls            #0xeb35a0
    // 0xeb354c: ldr             x2, [fp, #0x10]
    // 0xeb3550: r0 = LoadClassIdInstr(r2)
    //     0xeb3550: ldur            x0, [x2, #-1]
    //     0xeb3554: ubfx            x0, x0, #0xc, #0x14
    // 0xeb3558: mov             x1, x2
    // 0xeb355c: r0 = GDT[cid_x0 + -0xfa7]()
    //     0xeb355c: sub             lr, x0, #0xfa7
    //     0xeb3560: ldr             lr, [x21, lr, lsl #3]
    //     0xeb3564: blr             lr
    // 0xeb3568: mov             x1, x0
    // 0xeb356c: ldr             x0, [fp, #0x10]
    // 0xeb3570: LoadField: r2 = r0->field_1b
    //     0xeb3570: ldur            w2, [x0, #0x1b]
    // 0xeb3574: LoadField: r3 = r0->field_13
    //     0xeb3574: ldur            w3, [x0, #0x13]
    // 0xeb3578: r0 = LoadClassIdInstr(r1)
    //     0xeb3578: ldur            x0, [x1, #-1]
    //     0xeb357c: ubfx            x0, x0, #0xc, #0x14
    // 0xeb3580: stp             x3, x2, [SP]
    // 0xeb3584: r4 = const [0, 0x3, 0x2, 0x3, null]
    //     0xeb3584: ldr             x4, [PP, #0x3870]  ; [pp+0x3870] List(5) [0, 0x3, 0x2, 0x3, Null]
    // 0xeb3588: r0 = GDT[cid_x0 + -0x1000]()
    //     0xeb3588: sub             lr, x0, #1, lsl #12
    //     0xeb358c: ldr             lr, [x21, lr, lsl #3]
    //     0xeb3590: blr             lr
    // 0xeb3594: LeaveFrame
    //     0xeb3594: mov             SP, fp
    //     0xeb3598: ldp             fp, lr, [SP], #0x10
    // 0xeb359c: ret
    //     0xeb359c: ret             
    // 0xeb35a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeb35a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeb35a4: b               #0xeb354c
  }
}
