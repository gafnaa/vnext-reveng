// lib: , url: package:flutter/src/services/undo_manager.dart

// class id: 1049106, size: 0x8
class :: {
}

// class id: 2723, size: 0x10, field offset: 0x8
class UndoManager extends Object {

  static late final UndoManager _instance; // offset: 0x908

  set _ client=(/* No info */) {
    // ** addr: 0xf444c4, size: 0x7c
    // 0xf444c4: EnterFrame
    //     0xf444c4: stp             fp, lr, [SP, #-0x10]!
    //     0xf444c8: mov             fp, SP
    // 0xf444cc: AllocStack(0x8)
    //     0xf444cc: sub             SP, SP, #8
    // 0xf444d0: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */)
    //     0xf444d0: mov             x0, x1
    //     0xf444d4: stur            x1, [fp, #-8]
    // 0xf444d8: CheckStackOverflow
    //     0xf444d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf444dc: cmp             SP, x16
    //     0xf444e0: b.ls            #0xf44538
    // 0xf444e4: r0 = LoadStaticField(0x908)
    //     0xf444e4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf444e8: ldr             x0, [x0, #0x1210]
    // 0xf444ec: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf444f0: cmp             w0, w16
    // 0xf444f4: b.ne            #0xf44504
    // 0xf444f8: r2 = _instance
    //     0xf444f8: add             x2, PP, #0xcc, lsl #12  ; [pp+0xcc908] Field <UndoManager._instance@214137573>: static late final (offset: 0x908)
    //     0xf444fc: ldr             x2, [x2, #0x908]
    // 0xf44500: r0 = InitLateFinalStaticField()
    //     0xf44500: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xf44504: mov             x1, x0
    // 0xf44508: ldur            x0, [fp, #-8]
    // 0xf4450c: StoreField: r1->field_b = r0
    //     0xf4450c: stur            w0, [x1, #0xb]
    //     0xf44510: ldurb           w16, [x1, #-1]
    //     0xf44514: ldurb           w17, [x0, #-1]
    //     0xf44518: and             x16, x17, x16, lsr #2
    //     0xf4451c: tst             x16, HEAP, lsr #32
    //     0xf44520: b.eq            #0xf44528
    //     0xf44524: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf44528: r0 = Null
    //     0xf44528: mov             x0, NULL
    // 0xf4452c: LeaveFrame
    //     0xf4452c: mov             SP, fp
    //     0xf44530: ldp             fp, lr, [SP], #0x10
    // 0xf44534: ret
    //     0xf44534: ret             
    // 0xf44538: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf44538: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf4453c: b               #0xf444e4
  }
  static UndoManager _instance() {
    // ** addr: 0xf44540, size: 0x68
    // 0xf44540: EnterFrame
    //     0xf44540: stp             fp, lr, [SP, #-0x10]!
    //     0xf44544: mov             fp, SP
    // 0xf44548: AllocStack(0x8)
    //     0xf44548: sub             SP, SP, #8
    // 0xf4454c: CheckStackOverflow
    //     0xf4454c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf44550: cmp             SP, x16
    //     0xf44554: b.ls            #0xf445a0
    // 0xf44558: r0 = UndoManager()
    //     0xf44558: bl              #0xf445a8  ; AllocateUndoManagerStub -> UndoManager (size=0x10)
    // 0xf4455c: mov             x3, x0
    // 0xf44560: r0 = Instance_OptionalMethodChannel
    //     0xf44560: add             x0, PP, #0xcc, lsl #12  ; [pp+0xcc968] Obj!OptionalMethodChannel@129bf81
    //     0xf44564: ldr             x0, [x0, #0x968]
    // 0xf44568: stur            x3, [fp, #-8]
    // 0xf4456c: StoreField: r3->field_7 = r0
    //     0xf4456c: stur            w0, [x3, #7]
    // 0xf44570: mov             x2, x3
    // 0xf44574: r1 = Function '_handleUndoManagerInvocation@214137573':.
    //     0xf44574: add             x1, PP, #0xcc, lsl #12  ; [pp+0xcc970] AnonymousClosure: (0xf445b4), in [package:flutter/src/services/undo_manager.dart] UndoManager::_handleUndoManagerInvocation (0xf445f0)
    //     0xf44578: ldr             x1, [x1, #0x970]
    // 0xf4457c: r0 = AllocateClosure()
    //     0xf4457c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf44580: mov             x2, x0
    // 0xf44584: r1 = Instance_OptionalMethodChannel
    //     0xf44584: add             x1, PP, #0xcc, lsl #12  ; [pp+0xcc968] Obj!OptionalMethodChannel@129bf81
    //     0xf44588: ldr             x1, [x1, #0x968]
    // 0xf4458c: r0 = setMethodCallHandler()
    //     0xf4458c: bl              #0x83aa3c  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::setMethodCallHandler
    // 0xf44590: ldur            x0, [fp, #-8]
    // 0xf44594: LeaveFrame
    //     0xf44594: mov             SP, fp
    //     0xf44598: ldp             fp, lr, [SP], #0x10
    // 0xf4459c: ret
    //     0xf4459c: ret             
    // 0xf445a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf445a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf445a4: b               #0xf44558
  }
  [closure] Future<dynamic> _handleUndoManagerInvocation(dynamic, MethodCall) {
    // ** addr: 0xf445b4, size: 0x3c
    // 0xf445b4: EnterFrame
    //     0xf445b4: stp             fp, lr, [SP, #-0x10]!
    //     0xf445b8: mov             fp, SP
    // 0xf445bc: ldr             x0, [fp, #0x18]
    // 0xf445c0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf445c0: ldur            w1, [x0, #0x17]
    // 0xf445c4: DecompressPointer r1
    //     0xf445c4: add             x1, x1, HEAP, lsl #32
    // 0xf445c8: CheckStackOverflow
    //     0xf445c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf445cc: cmp             SP, x16
    //     0xf445d0: b.ls            #0xf445e8
    // 0xf445d4: ldr             x2, [fp, #0x10]
    // 0xf445d8: r0 = _handleUndoManagerInvocation()
    //     0xf445d8: bl              #0xf445f0  ; [package:flutter/src/services/undo_manager.dart] UndoManager::_handleUndoManagerInvocation
    // 0xf445dc: LeaveFrame
    //     0xf445dc: mov             SP, fp
    //     0xf445e0: ldp             fp, lr, [SP], #0x10
    // 0xf445e4: ret
    //     0xf445e4: ret             
    // 0xf445e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf445e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf445ec: b               #0xf445d4
  }
  _ _handleUndoManagerInvocation(/* No info */) async {
    // ** addr: 0xf445f0, size: 0x158
    // 0xf445f0: EnterFrame
    //     0xf445f0: stp             fp, lr, [SP, #-0x10]!
    //     0xf445f4: mov             fp, SP
    // 0xf445f8: AllocStack(0x38)
    //     0xf445f8: sub             SP, SP, #0x38
    // 0xf445fc: SetupParameters(UndoManager this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0xf445fc: stur            NULL, [fp, #-8]
    //     0xf44600: stur            x1, [fp, #-0x10]
    //     0xf44604: stur            x2, [fp, #-0x18]
    // 0xf44608: CheckStackOverflow
    //     0xf44608: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf4460c: cmp             SP, x16
    //     0xf44610: b.ls            #0xf4473c
    // 0xf44614: InitAsync() -> Future
    //     0xf44614: mov             x0, NULL
    //     0xf44618: bl              #0x7f5e44  ; InitAsyncStub
    // 0xf4461c: ldur            x0, [fp, #-0x18]
    // 0xf44620: LoadField: r3 = r0->field_7
    //     0xf44620: ldur            w3, [x0, #7]
    // 0xf44624: DecompressPointer r3
    //     0xf44624: add             x3, x3, HEAP, lsl #32
    // 0xf44628: stur            x3, [fp, #-0x28]
    // 0xf4462c: LoadField: r4 = r0->field_b
    //     0xf4462c: ldur            w4, [x0, #0xb]
    // 0xf44630: DecompressPointer r4
    //     0xf44630: add             x4, x4, HEAP, lsl #32
    // 0xf44634: mov             x0, x4
    // 0xf44638: stur            x4, [fp, #-0x20]
    // 0xf4463c: r2 = Null
    //     0xf4463c: mov             x2, NULL
    // 0xf44640: r1 = Null
    //     0xf44640: mov             x1, NULL
    // 0xf44644: r4 = 60
    //     0xf44644: mov             x4, #0x3c
    // 0xf44648: branchIfSmi(r0, 0xf44654)
    //     0xf44648: tbz             w0, #0, #0xf44654
    // 0xf4464c: r4 = LoadClassIdInstr(r0)
    //     0xf4464c: ldur            x4, [x0, #-1]
    //     0xf44650: ubfx            x4, x4, #0xc, #0x14
    // 0xf44654: sub             x4, x4, #0x5a
    // 0xf44658: cmp             x4, #2
    // 0xf4465c: b.ls            #0xf44670
    // 0xf44660: r8 = List
    //     0xf44660: ldr             x8, [PP, #0x30e8]  ; [pp+0x30e8] Type: List
    // 0xf44664: r3 = Null
    //     0xf44664: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcc978] Null
    //     0xf44668: ldr             x3, [x3, #0x978]
    // 0xf4466c: r0 = List()
    //     0xf4466c: bl              #0x13efaa0  ; IsType_List_Stub
    // 0xf44670: ldur            x0, [fp, #-0x28]
    // 0xf44674: r1 = LoadClassIdInstr(r0)
    //     0xf44674: ldur            x1, [x0, #-1]
    //     0xf44678: ubfx            x1, x1, #0xc, #0x14
    // 0xf4467c: r16 = "UndoManagerClient.handleUndo"
    //     0xf4467c: add             x16, PP, #0xcc, lsl #12  ; [pp+0xcc988] "UndoManagerClient.handleUndo"
    //     0xf44680: ldr             x16, [x16, #0x988]
    // 0xf44684: stp             x16, x0, [SP]
    // 0xf44688: mov             x0, x1
    // 0xf4468c: mov             lr, x0
    // 0xf44690: ldr             lr, [x21, lr, lsl #3]
    // 0xf44694: blr             lr
    // 0xf44698: tbnz            w0, #4, #0xf44730
    // 0xf4469c: ldur            x1, [fp, #-0x10]
    // 0xf446a0: ldur            x0, [fp, #-0x20]
    // 0xf446a4: LoadField: r2 = r1->field_b
    //     0xf446a4: ldur            w2, [x1, #0xb]
    // 0xf446a8: DecompressPointer r2
    //     0xf446a8: add             x2, x2, HEAP, lsl #32
    // 0xf446ac: stur            x2, [fp, #-0x18]
    // 0xf446b0: cmp             w2, NULL
    // 0xf446b4: b.eq            #0xf44744
    // 0xf446b8: r3 = LoadClassIdInstr(r0)
    //     0xf446b8: ldur            x3, [x0, #-1]
    //     0xf446bc: ubfx            x3, x3, #0xc, #0x14
    // 0xf446c0: stp             xzr, x0, [SP]
    // 0xf446c4: mov             x0, x3
    // 0xf446c8: r0 = GDT[cid_x0 + -0xdfd]()
    //     0xf446c8: sub             lr, x0, #0xdfd
    //     0xf446cc: ldr             lr, [x21, lr, lsl #3]
    //     0xf446d0: blr             lr
    // 0xf446d4: mov             x3, x0
    // 0xf446d8: r2 = Null
    //     0xf446d8: mov             x2, NULL
    // 0xf446dc: r1 = Null
    //     0xf446dc: mov             x1, NULL
    // 0xf446e0: stur            x3, [fp, #-0x20]
    // 0xf446e4: r4 = 60
    //     0xf446e4: mov             x4, #0x3c
    // 0xf446e8: branchIfSmi(r0, 0xf446f4)
    //     0xf446e8: tbz             w0, #0, #0xf446f4
    // 0xf446ec: r4 = LoadClassIdInstr(r0)
    //     0xf446ec: ldur            x4, [x0, #-1]
    //     0xf446f0: ubfx            x4, x4, #0xc, #0x14
    // 0xf446f4: sub             x4, x4, #0x5e
    // 0xf446f8: cmp             x4, #1
    // 0xf446fc: b.ls            #0xf44710
    // 0xf44700: r8 = String
    //     0xf44700: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0xf44704: r3 = Null
    //     0xf44704: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcc990] Null
    //     0xf44708: ldr             x3, [x3, #0x990]
    // 0xf4470c: r0 = String()
    //     0xf4470c: bl              #0x13ee320  ; IsType_String_Stub
    // 0xf44710: ldur            x1, [fp, #-0x10]
    // 0xf44714: ldur            x2, [fp, #-0x20]
    // 0xf44718: r0 = _toUndoDirection()
    //     0xf44718: bl              #0xf4478c  ; [package:flutter/src/services/undo_manager.dart] UndoManager::_toUndoDirection
    // 0xf4471c: ldur            x1, [fp, #-0x18]
    // 0xf44720: mov             x2, x0
    // 0xf44724: r0 = handlePlatformUndo()
    //     0xf44724: bl              #0xf44748  ; [package:flutter/src/widgets/undo_history.dart] UndoHistoryState::handlePlatformUndo
    // 0xf44728: r0 = Null
    //     0xf44728: mov             x0, NULL
    // 0xf4472c: r0 = ReturnAsyncNotFuture()
    //     0xf4472c: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xf44730: r0 = MissingPluginException()
    //     0xf44730: bl              #0x8545ec  ; AllocateMissingPluginExceptionStub -> MissingPluginException (size=0xc)
    // 0xf44734: r0 = Throw()
    //     0xf44734: bl              #0x13ddb2c  ; ThrowStub
    // 0xf44738: brk             #0
    // 0xf4473c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf4473c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf44740: b               #0xf44614
    // 0xf44744: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf44744: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _toUndoDirection(/* No info */) {
    // ** addr: 0xf4478c, size: 0x114
    // 0xf4478c: EnterFrame
    //     0xf4478c: stp             fp, lr, [SP, #-0x10]!
    //     0xf44790: mov             fp, SP
    // 0xf44794: AllocStack(0x20)
    //     0xf44794: sub             SP, SP, #0x20
    // 0xf44798: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0xf44798: stur            x2, [fp, #-8]
    // 0xf4479c: CheckStackOverflow
    //     0xf4479c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf447a0: cmp             SP, x16
    //     0xf447a4: b.ls            #0xf44898
    // 0xf447a8: r16 = "undo"
    //     0xf447a8: add             x16, PP, #0xcc, lsl #12  ; [pp+0xcc9a0] "undo"
    //     0xf447ac: ldr             x16, [x16, #0x9a0]
    // 0xf447b0: stp             x2, x16, [SP]
    // 0xf447b4: r0 = ==()
    //     0xf447b4: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0xf447b8: tbnz            w0, #4, #0xf447c8
    // 0xf447bc: r0 = Instance_UndoDirection
    //     0xf447bc: add             x0, PP, #0xcc, lsl #12  ; [pp+0xcc9a8] Obj!UndoDirection@12c3641
    //     0xf447c0: ldr             x0, [x0, #0x9a8]
    // 0xf447c4: b               #0xf447e8
    // 0xf447c8: r16 = "redo"
    //     0xf447c8: add             x16, PP, #0xcc, lsl #12  ; [pp+0xcc9b0] "redo"
    //     0xf447cc: ldr             x16, [x16, #0x9b0]
    // 0xf447d0: ldur            lr, [fp, #-8]
    // 0xf447d4: stp             lr, x16, [SP]
    // 0xf447d8: r0 = ==()
    //     0xf447d8: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0xf447dc: tbnz            w0, #4, #0xf447f4
    // 0xf447e0: r0 = Instance_UndoDirection
    //     0xf447e0: add             x0, PP, #0xcc, lsl #12  ; [pp+0xcc9b8] Obj!UndoDirection@12c3621
    //     0xf447e4: ldr             x0, [x0, #0x9b8]
    // 0xf447e8: LeaveFrame
    //     0xf447e8: mov             SP, fp
    //     0xf447ec: ldp             fp, lr, [SP], #0x10
    // 0xf447f0: ret
    //     0xf447f0: ret             
    // 0xf447f4: ldur            x0, [fp, #-8]
    // 0xf447f8: r1 = Null
    //     0xf447f8: mov             x1, NULL
    // 0xf447fc: r2 = 4
    //     0xf447fc: mov             x2, #4
    // 0xf44800: r0 = AllocateArray()
    //     0xf44800: bl              #0x13df928  ; AllocateArrayStub
    // 0xf44804: r16 = "Unknown undo direction: "
    //     0xf44804: add             x16, PP, #0xcc, lsl #12  ; [pp+0xcc9c0] "Unknown undo direction: "
    //     0xf44808: ldr             x16, [x16, #0x9c0]
    // 0xf4480c: StoreField: r0->field_f = r16
    //     0xf4480c: stur            w16, [x0, #0xf]
    // 0xf44810: ldur            x1, [fp, #-8]
    // 0xf44814: StoreField: r0->field_13 = r1
    //     0xf44814: stur            w1, [x0, #0x13]
    // 0xf44818: str             x0, [SP]
    // 0xf4481c: r0 = _interpolate()
    //     0xf4481c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xf44820: r1 = <List<Object>>
    //     0xf44820: ldr             x1, [PP, #0x860]  ; [pp+0x860] TypeArguments: <List<Object>>
    // 0xf44824: stur            x0, [fp, #-8]
    // 0xf44828: r0 = ErrorSummary()
    //     0xf44828: bl              #0x84896c  ; AllocateErrorSummaryStub -> ErrorSummary (size=0x2c)
    // 0xf4482c: mov             x1, x0
    // 0xf44830: ldur            x2, [fp, #-8]
    // 0xf44834: r3 = Instance_DiagnosticLevel
    //     0xf44834: ldr             x3, [PP, #0x22b0]  ; [pp+0x22b0] Obj!DiagnosticLevel@12c5f61
    // 0xf44838: stur            x0, [fp, #-8]
    // 0xf4483c: r0 = _ErrorDiagnostic()
    //     0xf4483c: bl              #0x829bec  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0xf44840: r1 = Null
    //     0xf44840: mov             x1, NULL
    // 0xf44844: r2 = 2
    //     0xf44844: mov             x2, #2
    // 0xf44848: r0 = AllocateArray()
    //     0xf44848: bl              #0x13df928  ; AllocateArrayStub
    // 0xf4484c: mov             x2, x0
    // 0xf44850: ldur            x0, [fp, #-8]
    // 0xf44854: stur            x2, [fp, #-0x10]
    // 0xf44858: StoreField: r2->field_f = r0
    //     0xf44858: stur            w0, [x2, #0xf]
    // 0xf4485c: r1 = <DiagnosticsNode>
    //     0xf4485c: ldr             x1, [PP, #0x1ea8]  ; [pp+0x1ea8] TypeArguments: <DiagnosticsNode>
    // 0xf44860: r0 = AllocateGrowableArray()
    //     0xf44860: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xf44864: mov             x1, x0
    // 0xf44868: ldur            x0, [fp, #-0x10]
    // 0xf4486c: stur            x1, [fp, #-8]
    // 0xf44870: StoreField: r1->field_f = r0
    //     0xf44870: stur            w0, [x1, #0xf]
    // 0xf44874: r0 = 2
    //     0xf44874: mov             x0, #2
    // 0xf44878: StoreField: r1->field_b = r0
    //     0xf44878: stur            w0, [x1, #0xb]
    // 0xf4487c: r0 = FlutterError()
    //     0xf4487c: bl              #0x8488dc  ; AllocateFlutterErrorStub -> FlutterError (size=0x10)
    // 0xf44880: mov             x1, x0
    // 0xf44884: ldur            x0, [fp, #-8]
    // 0xf44888: StoreField: r1->field_b = r0
    //     0xf44888: stur            w0, [x1, #0xb]
    // 0xf4488c: mov             x0, x1
    // 0xf44890: r0 = Throw()
    //     0xf44890: bl              #0x13ddb2c  ; ThrowStub
    // 0xf44894: brk             #0
    // 0xf44898: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf44898: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf4489c: b               #0xf447a8
  }
}

// class id: 4393, size: 0x8, field offset: 0x8
abstract class UndoManagerClient extends Object {
}

// class id: 8192, size: 0x14, field offset: 0x14
enum UndoDirection extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11abc4c, size: 0x64
    // 0x11abc4c: EnterFrame
    //     0x11abc4c: stp             fp, lr, [SP, #-0x10]!
    //     0x11abc50: mov             fp, SP
    // 0x11abc54: AllocStack(0x10)
    //     0x11abc54: sub             SP, SP, #0x10
    // 0x11abc58: SetupParameters(UndoDirection this /* r1 => r0, fp-0x8 */)
    //     0x11abc58: mov             x0, x1
    //     0x11abc5c: stur            x1, [fp, #-8]
    // 0x11abc60: CheckStackOverflow
    //     0x11abc60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11abc64: cmp             SP, x16
    //     0x11abc68: b.ls            #0x11abca8
    // 0x11abc6c: r1 = Null
    //     0x11abc6c: mov             x1, NULL
    // 0x11abc70: r2 = 4
    //     0x11abc70: mov             x2, #4
    // 0x11abc74: r0 = AllocateArray()
    //     0x11abc74: bl              #0x13df928  ; AllocateArrayStub
    // 0x11abc78: r16 = "UndoDirection."
    //     0x11abc78: add             x16, PP, #0xd0, lsl #12  ; [pp+0xd0130] "UndoDirection."
    //     0x11abc7c: ldr             x16, [x16, #0x130]
    // 0x11abc80: StoreField: r0->field_f = r16
    //     0x11abc80: stur            w16, [x0, #0xf]
    // 0x11abc84: ldur            x1, [fp, #-8]
    // 0x11abc88: LoadField: r2 = r1->field_f
    //     0x11abc88: ldur            w2, [x1, #0xf]
    // 0x11abc8c: DecompressPointer r2
    //     0x11abc8c: add             x2, x2, HEAP, lsl #32
    // 0x11abc90: StoreField: r0->field_13 = r2
    //     0x11abc90: stur            w2, [x0, #0x13]
    // 0x11abc94: str             x0, [SP]
    // 0x11abc98: r0 = _interpolate()
    //     0x11abc98: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11abc9c: LeaveFrame
    //     0x11abc9c: mov             SP, fp
    //     0x11abca0: ldp             fp, lr, [SP], #0x10
    // 0x11abca4: ret
    //     0x11abca4: ret             
    // 0x11abca8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11abca8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11abcac: b               #0x11abc6c
  }
}
