// lib: , url: package:flutter/src/services/mouse_tracking.dart

// class id: 1049081, size: 0x8
class :: {
}

// class id: 5300, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class MouseTrackerAnnotation extends _MixinApplication3&Object&Diagnosticable {
}
