// lib: , url: package:flutter/src/services/raw_keyboard_macos.dart

// class id: 1049091, size: 0x8
class :: {

  static int runeToLowerCase(int) {
    // ** addr: 0x1142ee8, size: 0xb4
    // 0x1142ee8: EnterFrame
    //     0x1142ee8: stp             fp, lr, [SP, #-0x10]!
    //     0x1142eec: mov             fp, SP
    // 0x1142ef0: AllocStack(0x8)
    //     0x1142ef0: sub             SP, SP, #8
    // 0x1142ef4: SetupParameters(dynamic _ /* r1 => r0 */)
    //     0x1142ef4: mov             x0, x1
    // 0x1142ef8: CheckStackOverflow
    //     0x1142ef8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1142efc: cmp             SP, x16
    //     0x1142f00: b.ls            #0x1142f90
    // 0x1142f04: r17 = 55295
    //     0x1142f04: mov             x17, #0xd7ff
    // 0x1142f08: cmp             x0, x17
    // 0x1142f0c: b.le            #0x1142f1c
    // 0x1142f10: LeaveFrame
    //     0x1142f10: mov             SP, fp
    //     0x1142f14: ldp             fp, lr, [SP], #0x10
    // 0x1142f18: ret
    //     0x1142f18: ret             
    // 0x1142f1c: mov             x2, x0
    // 0x1142f20: r1 = Null
    //     0x1142f20: mov             x1, NULL
    // 0x1142f24: r0 = String.fromCharCode()
    //     0x1142f24: bl              #0x7e6340  ; [dart:core] String::String.fromCharCode
    // 0x1142f28: r1 = LoadClassIdInstr(r0)
    //     0x1142f28: ldur            x1, [x0, #-1]
    //     0x1142f2c: ubfx            x1, x1, #0xc, #0x14
    // 0x1142f30: str             x0, [SP]
    // 0x1142f34: mov             x0, x1
    // 0x1142f38: r0 = GDT[cid_x0 + -0xffc]()
    //     0x1142f38: sub             lr, x0, #0xffc
    //     0x1142f3c: ldr             lr, [x21, lr, lsl #3]
    //     0x1142f40: blr             lr
    // 0x1142f44: mov             x2, x0
    // 0x1142f48: LoadField: r3 = r2->field_7
    //     0x1142f48: ldur            w3, [x2, #7]
    // 0x1142f4c: r0 = LoadInt32Instr(r3)
    //     0x1142f4c: sbfx            x0, x3, #1, #0x1f
    // 0x1142f50: r1 = 0
    //     0x1142f50: mov             x1, #0
    // 0x1142f54: cmp             x1, x0
    // 0x1142f58: b.hs            #0x1142f98
    // 0x1142f5c: r1 = LoadClassIdInstr(r2)
    //     0x1142f5c: ldur            x1, [x2, #-1]
    //     0x1142f60: ubfx            x1, x1, #0xc, #0x14
    // 0x1142f64: lsl             x1, x1, #1
    // 0x1142f68: cmp             w1, #0xbc
    // 0x1142f6c: b.ne            #0x1142f7c
    // 0x1142f70: ArrayLoad: r1 = r2[-8]  ; TypedUnsigned_1
    //     0x1142f70: ldrb            w1, [x2, #0xf]
    // 0x1142f74: mov             x0, x1
    // 0x1142f78: b               #0x1142f84
    // 0x1142f7c: ldurh           w1, [x2, #0xf]
    // 0x1142f80: mov             x0, x1
    // 0x1142f84: LeaveFrame
    //     0x1142f84: mov             SP, fp
    //     0x1142f88: ldp             fp, lr, [SP], #0x10
    // 0x1142f8c: ret
    //     0x1142f8c: ret             
    // 0x1142f90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1142f90: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1142f94: b               #0x1142f04
    // 0x1142f98: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x1142f98: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
}

// class id: 5021, size: 0x24, field offset: 0x8
//   const constructor, 
class RawKeyEventDataMacOs extends RawKeyEventData {

  _ shouldDispatchEvent(/* No info */) {
    // ** addr: 0x112df74, size: 0x90
    // 0x112df74: EnterFrame
    //     0x112df74: stp             fp, lr, [SP, #-0x10]!
    //     0x112df78: mov             fp, SP
    // 0x112df7c: AllocStack(0x18)
    //     0x112df7c: sub             SP, SP, #0x18
    // 0x112df80: CheckStackOverflow
    //     0x112df80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x112df84: cmp             SP, x16
    //     0x112df88: b.ls            #0x112dffc
    // 0x112df8c: r0 = logicalKey()
    //     0x112df8c: bl              #0x1142c2c  ; [package:flutter/src/services/raw_keyboard_macos.dart] RawKeyEventDataMacOs::logicalKey
    // 0x112df90: stur            x0, [fp, #-8]
    // 0x112df94: r16 = Instance_LogicalKeyboardKey
    //     0x112df94: ldr             x16, [PP, #0x3c50]  ; [pp+0x3c50] Obj!LogicalKeyboardKey@12ace31
    // 0x112df98: cmp             w0, w16
    // 0x112df9c: b.ne            #0x112dfa8
    // 0x112dfa0: r1 = true
    //     0x112dfa0: add             x1, NULL, #0x20  ; true
    // 0x112dfa4: b               #0x112dfec
    // 0x112dfa8: r16 = LogicalKeyboardKey
    //     0x112dfa8: add             x16, PP, #0xd, lsl #12  ; [pp+0xdd00] Type: LogicalKeyboardKey
    //     0x112dfac: ldr             x16, [x16, #0xd00]
    // 0x112dfb0: r30 = LogicalKeyboardKey
    //     0x112dfb0: add             lr, PP, #0xd, lsl #12  ; [pp+0xdd00] Type: LogicalKeyboardKey
    //     0x112dfb4: ldr             lr, [lr, #0xd00]
    // 0x112dfb8: stp             lr, x16, [SP]
    // 0x112dfbc: r0 = ==()
    //     0x112dfbc: bl              #0x12b7fbc  ; [dart:core] _Type::==
    // 0x112dfc0: tbz             w0, #4, #0x112dfcc
    // 0x112dfc4: r1 = false
    //     0x112dfc4: add             x1, NULL, #0x30  ; false
    // 0x112dfc8: b               #0x112dfec
    // 0x112dfcc: ldur            x1, [fp, #-8]
    // 0x112dfd0: r2 = Instance_LogicalKeyboardKey
    //     0x112dfd0: ldr             x2, [PP, #0x3c50]  ; [pp+0x3c50] Obj!LogicalKeyboardKey@12ace31
    // 0x112dfd4: LoadField: r3 = r2->field_7
    //     0x112dfd4: ldur            x3, [x2, #7]
    // 0x112dfd8: LoadField: r2 = r1->field_7
    //     0x112dfd8: ldur            x2, [x1, #7]
    // 0x112dfdc: cmp             x3, x2
    // 0x112dfe0: r16 = true
    //     0x112dfe0: add             x16, NULL, #0x20  ; true
    // 0x112dfe4: r17 = false
    //     0x112dfe4: add             x17, NULL, #0x30  ; false
    // 0x112dfe8: csel            x1, x16, x17, eq
    // 0x112dfec: eor             x0, x1, #0x10
    // 0x112dff0: LeaveFrame
    //     0x112dff0: mov             SP, fp
    //     0x112dff4: ldp             fp, lr, [SP], #0x10
    // 0x112dff8: ret
    //     0x112dff8: ret             
    // 0x112dffc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x112dffc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x112e000: b               #0x112df8c
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x113bfc4, size: 0xa0
    // 0x113bfc4: EnterFrame
    //     0x113bfc4: stp             fp, lr, [SP, #-0x10]!
    //     0x113bfc8: mov             fp, SP
    // 0x113bfcc: AllocStack(0x10)
    //     0x113bfcc: sub             SP, SP, #0x10
    // 0x113bfd0: CheckStackOverflow
    //     0x113bfd0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x113bfd4: cmp             SP, x16
    //     0x113bfd8: b.ls            #0x113c05c
    // 0x113bfdc: ldr             x0, [fp, #0x10]
    // 0x113bfe0: LoadField: r2 = r0->field_7
    //     0x113bfe0: ldur            w2, [x0, #7]
    // 0x113bfe4: DecompressPointer r2
    //     0x113bfe4: add             x2, x2, HEAP, lsl #32
    // 0x113bfe8: LoadField: r3 = r0->field_b
    //     0x113bfe8: ldur            w3, [x0, #0xb]
    // 0x113bfec: DecompressPointer r3
    //     0x113bfec: add             x3, x3, HEAP, lsl #32
    // 0x113bff0: LoadField: r4 = r0->field_f
    //     0x113bff0: ldur            x4, [x0, #0xf]
    // 0x113bff4: ArrayLoad: r5 = r0[0]  ; List_8
    //     0x113bff4: ldur            x5, [x0, #0x17]
    // 0x113bff8: r0 = BoxInt64Instr(r4)
    //     0x113bff8: sbfiz           x0, x4, #1, #0x1f
    //     0x113bffc: cmp             x4, x0, asr #1
    //     0x113c000: b.eq            #0x113c00c
    //     0x113c004: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x113c008: stur            x4, [x0, #7]
    // 0x113c00c: mov             x4, x0
    // 0x113c010: r0 = BoxInt64Instr(r5)
    //     0x113c010: sbfiz           x0, x5, #1, #0x1f
    //     0x113c014: cmp             x5, x0, asr #1
    //     0x113c018: b.eq            #0x113c024
    //     0x113c01c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x113c020: stur            x5, [x0, #7]
    // 0x113c024: stp             x0, x4, [SP]
    // 0x113c028: mov             x1, x2
    // 0x113c02c: mov             x2, x3
    // 0x113c030: r4 = const [0, 0x4, 0x2, 0x4, null]
    //     0x113c030: ldr             x4, [PP, #0x1388]  ; [pp+0x1388] List(5) [0, 0x4, 0x2, 0x4, Null]
    // 0x113c034: r0 = hash()
    //     0x113c034: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x113c038: mov             x2, x0
    // 0x113c03c: r0 = BoxInt64Instr(r2)
    //     0x113c03c: sbfiz           x0, x2, #1, #0x1f
    //     0x113c040: cmp             x2, x0, asr #1
    //     0x113c044: b.eq            #0x113c050
    //     0x113c048: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x113c04c: stur            x2, [x0, #7]
    // 0x113c050: LeaveFrame
    //     0x113c050: mov             SP, fp
    //     0x113c054: ldp             fp, lr, [SP], #0x10
    // 0x113c058: ret
    //     0x113c058: ret             
    // 0x113c05c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x113c05c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x113c060: b               #0x113bfdc
  }
  get _ logicalKey(/* No info */) {
    // ** addr: 0x1142c2c, size: 0x2bc
    // 0x1142c2c: EnterFrame
    //     0x1142c2c: stp             fp, lr, [SP, #-0x10]!
    //     0x1142c30: mov             fp, SP
    // 0x1142c34: AllocStack(0x28)
    //     0x1142c34: sub             SP, SP, #0x28
    // 0x1142c38: SetupParameters(RawKeyEventDataMacOs this /* r1 => r3, fp-0x18 */)
    //     0x1142c38: mov             x3, x1
    //     0x1142c3c: stur            x1, [fp, #-0x18]
    // 0x1142c40: CheckStackOverflow
    //     0x1142c40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1142c44: cmp             SP, x16
    //     0x1142c48: b.ls            #0x1142ed4
    // 0x1142c4c: LoadField: r0 = r3->field_1f
    //     0x1142c4c: ldur            w0, [x3, #0x1f]
    // 0x1142c50: DecompressPointer r0
    //     0x1142c50: add             x0, x0, HEAP, lsl #32
    // 0x1142c54: cmp             w0, NULL
    // 0x1142c58: b.eq            #0x1142ca0
    // 0x1142c5c: r2 = LoadInt32Instr(r0)
    //     0x1142c5c: sbfx            x2, x0, #1, #0x1f
    //     0x1142c60: tbz             w0, #0, #0x1142c68
    //     0x1142c64: ldur            x2, [x0, #7]
    // 0x1142c68: mov             x1, x2
    // 0x1142c6c: stur            x2, [fp, #-8]
    // 0x1142c70: r0 = findKeyByKeyId()
    //     0x1142c70: bl              #0x84a464  ; [package:flutter/src/services/keyboard_key.g.dart] LogicalKeyboardKey::findKeyByKeyId
    // 0x1142c74: cmp             w0, NULL
    // 0x1142c78: b.ne            #0x1142c94
    // 0x1142c7c: ldur            x0, [fp, #-8]
    // 0x1142c80: r0 = LogicalKeyboardKey()
    //     0x1142c80: bl              #0x849274  ; AllocateLogicalKeyboardKeyStub -> LogicalKeyboardKey (size=0x10)
    // 0x1142c84: mov             x1, x0
    // 0x1142c88: ldur            x0, [fp, #-8]
    // 0x1142c8c: StoreField: r1->field_7 = r0
    //     0x1142c8c: stur            x0, [x1, #7]
    // 0x1142c90: mov             x0, x1
    // 0x1142c94: LeaveFrame
    //     0x1142c94: mov             SP, fp
    //     0x1142c98: ldp             fp, lr, [SP], #0x10
    // 0x1142c9c: ret
    //     0x1142c9c: ret             
    // 0x1142ca0: LoadField: r4 = r3->field_f
    //     0x1142ca0: ldur            x4, [x3, #0xf]
    // 0x1142ca4: stur            x4, [fp, #-8]
    // 0x1142ca8: r0 = BoxInt64Instr(r4)
    //     0x1142ca8: sbfiz           x0, x4, #1, #0x1f
    //     0x1142cac: cmp             x4, x0, asr #1
    //     0x1142cb0: b.eq            #0x1142cbc
    //     0x1142cb4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1142cb8: stur            x4, [x0, #7]
    // 0x1142cbc: mov             x2, x0
    // 0x1142cc0: r1 = _ConstMap len:17
    //     0x1142cc0: add             x1, PP, #0xd, lsl #12  ; [pp+0xdd08] Map<int, LogicalKeyboardKey>(17)
    //     0x1142cc4: ldr             x1, [x1, #0xd08]
    // 0x1142cc8: stur            x0, [fp, #-0x10]
    // 0x1142ccc: r0 = []()
    //     0x1142ccc: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x1142cd0: cmp             w0, NULL
    // 0x1142cd4: b.eq            #0x1142ce4
    // 0x1142cd8: LeaveFrame
    //     0x1142cd8: mov             SP, fp
    //     0x1142cdc: ldp             fp, lr, [SP], #0x10
    // 0x1142ce0: ret
    //     0x1142ce0: ret             
    // 0x1142ce4: ldur            x2, [fp, #-0x10]
    // 0x1142ce8: r1 = _ConstMap len:71
    //     0x1142ce8: add             x1, PP, #0xd, lsl #12  ; [pp+0xdd10] Map<int, LogicalKeyboardKey>(71)
    //     0x1142cec: ldr             x1, [x1, #0xd10]
    // 0x1142cf0: r0 = []()
    //     0x1142cf0: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x1142cf4: cmp             w0, NULL
    // 0x1142cf8: b.eq            #0x1142d08
    // 0x1142cfc: LeaveFrame
    //     0x1142cfc: mov             SP, fp
    //     0x1142d00: ldp             fp, lr, [SP], #0x10
    // 0x1142d04: ret
    //     0x1142d04: ret             
    // 0x1142d08: ldur            x0, [fp, #-0x18]
    // 0x1142d0c: LoadField: r2 = r0->field_b
    //     0x1142d0c: ldur            w2, [x0, #0xb]
    // 0x1142d10: DecompressPointer r2
    //     0x1142d10: add             x2, x2, HEAP, lsl #32
    // 0x1142d14: stur            x2, [fp, #-0x20]
    // 0x1142d18: LoadField: r0 = r2->field_7
    //     0x1142d18: ldur            w0, [x2, #7]
    // 0x1142d1c: stur            x0, [fp, #-0x10]
    // 0x1142d20: cbz             w0, #0x1142e5c
    // 0x1142d24: mov             x1, x2
    // 0x1142d28: r0 = runes()
    //     0x1142d28: bl              #0xb0dcc8  ; [dart:core] _StringBase::runes
    // 0x1142d2c: mov             x1, x0
    // 0x1142d30: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x1142d30: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x1142d34: r0 = toList()
    //     0x1142d34: bl              #0xb08ca4  ; [dart:core] Iterable::toList
    // 0x1142d38: mov             x2, x0
    // 0x1142d3c: LoadField: r0 = r2->field_b
    //     0x1142d3c: ldur            w0, [x2, #0xb]
    // 0x1142d40: r3 = LoadInt32Instr(r0)
    //     0x1142d40: sbfx            x3, x0, #1, #0x1f
    // 0x1142d44: cmp             x3, #1
    // 0x1142d48: b.ne            #0x1142e54
    // 0x1142d4c: ldur            x0, [fp, #-0x10]
    // 0x1142d50: r4 = LoadInt32Instr(r0)
    //     0x1142d50: sbfx            x4, x0, #1, #0x1f
    // 0x1142d54: cmp             x4, #1
    // 0x1142d58: b.eq            #0x1142d64
    // 0x1142d5c: ldur            x5, [fp, #-0x20]
    // 0x1142d60: b               #0x1142db4
    // 0x1142d64: ldur            x5, [fp, #-0x20]
    // 0x1142d68: mov             x0, x4
    // 0x1142d6c: r1 = 0
    //     0x1142d6c: mov             x1, #0
    // 0x1142d70: cmp             x1, x0
    // 0x1142d74: b.hs            #0x1142edc
    // 0x1142d78: r0 = LoadClassIdInstr(r5)
    //     0x1142d78: ldur            x0, [x5, #-1]
    //     0x1142d7c: ubfx            x0, x0, #0xc, #0x14
    // 0x1142d80: lsl             x0, x0, #1
    // 0x1142d84: cmp             w0, #0xbc
    // 0x1142d88: b.ne            #0x1142d94
    // 0x1142d8c: ArrayLoad: r0 = r5[-8]  ; TypedUnsigned_1
    //     0x1142d8c: ldrb            w0, [x5, #0xf]
    // 0x1142d90: b               #0x1142d98
    // 0x1142d94: ldurh           w0, [x5, #0xf]
    // 0x1142d98: cmp             x0, #0x1f
    // 0x1142d9c: b.gt            #0x1142da4
    // 0x1142da0: tbz             x0, #0x3f, #0x1142e54
    // 0x1142da4: cmp             x0, #0x7f
    // 0x1142da8: b.lt            #0x1142db4
    // 0x1142dac: cmp             x0, #0x9f
    // 0x1142db0: b.le            #0x1142e54
    // 0x1142db4: cmp             x4, #1
    // 0x1142db8: b.ne            #0x1142e04
    // 0x1142dbc: mov             x0, x4
    // 0x1142dc0: r1 = 0
    //     0x1142dc0: mov             x1, #0
    // 0x1142dc4: cmp             x1, x0
    // 0x1142dc8: b.hs            #0x1142ee0
    // 0x1142dcc: r0 = LoadClassIdInstr(r5)
    //     0x1142dcc: ldur            x0, [x5, #-1]
    //     0x1142dd0: ubfx            x0, x0, #0xc, #0x14
    // 0x1142dd4: lsl             x0, x0, #1
    // 0x1142dd8: cmp             w0, #0xbc
    // 0x1142ddc: b.ne            #0x1142de8
    // 0x1142de0: ArrayLoad: r0 = r5[-8]  ; TypedUnsigned_1
    //     0x1142de0: ldrb            w0, [x5, #0xf]
    // 0x1142de4: b               #0x1142dec
    // 0x1142de8: ldurh           w0, [x5, #0xf]
    // 0x1142dec: r17 = 63232
    //     0x1142dec: mov             x17, #0xf700
    // 0x1142df0: cmp             x0, x17
    // 0x1142df4: b.lt            #0x1142e04
    // 0x1142df8: r17 = 63743
    //     0x1142df8: mov             x17, #0xf8ff
    // 0x1142dfc: cmp             x0, x17
    // 0x1142e00: b.le            #0x1142e54
    // 0x1142e04: mov             x0, x3
    // 0x1142e08: r1 = 0
    //     0x1142e08: mov             x1, #0
    // 0x1142e0c: cmp             x1, x0
    // 0x1142e10: b.hs            #0x1142ee4
    // 0x1142e14: LoadField: r0 = r2->field_f
    //     0x1142e14: ldur            w0, [x2, #0xf]
    // 0x1142e18: DecompressPointer r0
    //     0x1142e18: add             x0, x0, HEAP, lsl #32
    // 0x1142e1c: LoadField: r1 = r0->field_f
    //     0x1142e1c: ldur            w1, [x0, #0xf]
    // 0x1142e20: DecompressPointer r1
    //     0x1142e20: add             x1, x1, HEAP, lsl #32
    // 0x1142e24: r0 = LoadInt32Instr(r1)
    //     0x1142e24: sbfx            x0, x1, #1, #0x1f
    //     0x1142e28: tbz             w1, #0, #0x1142e30
    //     0x1142e2c: ldur            x0, [x1, #7]
    // 0x1142e30: mov             x1, x0
    // 0x1142e34: r0 = runeToLowerCase()
    //     0x1142e34: bl              #0x1142ee8  ; [package:flutter/src/services/raw_keyboard_macos.dart] ::runeToLowerCase
    // 0x1142e38: mov             x2, x0
    // 0x1142e3c: r0 = BoxInt64Instr(r2)
    //     0x1142e3c: sbfiz           x0, x2, #1, #0x1f
    //     0x1142e40: cmp             x2, x0, asr #1
    //     0x1142e44: b.eq            #0x1142e50
    //     0x1142e48: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1142e4c: stur            x2, [x0, #7]
    // 0x1142e50: b               #0x1142e60
    // 0x1142e54: r0 = Null
    //     0x1142e54: mov             x0, NULL
    // 0x1142e58: b               #0x1142e60
    // 0x1142e5c: r0 = Null
    //     0x1142e5c: mov             x0, NULL
    // 0x1142e60: cmp             w0, NULL
    // 0x1142e64: b.eq            #0x1142ea8
    // 0x1142e68: r2 = LoadInt32Instr(r0)
    //     0x1142e68: sbfx            x2, x0, #1, #0x1f
    //     0x1142e6c: tbz             w0, #0, #0x1142e74
    //     0x1142e70: ldur            x2, [x0, #7]
    // 0x1142e74: stur            x2, [fp, #-0x28]
    // 0x1142e78: mov             x1, x2
    // 0x1142e7c: ubfx            x1, x1, #0, #0x20
    // 0x1142e80: r0 = findKeyByKeyId()
    //     0x1142e80: bl              #0x84a464  ; [package:flutter/src/services/keyboard_key.g.dart] LogicalKeyboardKey::findKeyByKeyId
    // 0x1142e84: cmp             w0, NULL
    // 0x1142e88: b.ne            #0x1142e9c
    // 0x1142e8c: r0 = LogicalKeyboardKey()
    //     0x1142e8c: bl              #0x849274  ; AllocateLogicalKeyboardKeyStub -> LogicalKeyboardKey (size=0x10)
    // 0x1142e90: ldur            x1, [fp, #-0x28]
    // 0x1142e94: ubfx            x1, x1, #0, #0x20
    // 0x1142e98: StoreField: r0->field_7 = r1
    //     0x1142e98: stur            x1, [x0, #7]
    // 0x1142e9c: LeaveFrame
    //     0x1142e9c: mov             SP, fp
    //     0x1142ea0: ldp             fp, lr, [SP], #0x10
    // 0x1142ea4: ret
    //     0x1142ea4: ret             
    // 0x1142ea8: ldur            x0, [fp, #-8]
    // 0x1142eac: r16 = 85899345920
    //     0x1142eac: add             x16, PP, #0xd, lsl #12  ; [pp+0xdd18] IMM: 0x1400000000
    //     0x1142eb0: ldr             x16, [x16, #0xd18]
    // 0x1142eb4: orr             x1, x0, x16
    // 0x1142eb8: stur            x1, [fp, #-0x28]
    // 0x1142ebc: r0 = LogicalKeyboardKey()
    //     0x1142ebc: bl              #0x849274  ; AllocateLogicalKeyboardKeyStub -> LogicalKeyboardKey (size=0x10)
    // 0x1142ec0: ldur            x1, [fp, #-0x28]
    // 0x1142ec4: StoreField: r0->field_7 = r1
    //     0x1142ec4: stur            x1, [x0, #7]
    // 0x1142ec8: LeaveFrame
    //     0x1142ec8: mov             SP, fp
    //     0x1142ecc: ldp             fp, lr, [SP], #0x10
    // 0x1142ed0: ret
    //     0x1142ed0: ret             
    // 0x1142ed4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1142ed4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1142ed8: b               #0x1142c4c
    // 0x1142edc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x1142edc: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x1142ee0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x1142ee0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x1142ee4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x1142ee4: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ getModifierSide(/* No info */) {
    // ** addr: 0x11436bc, size: 0x1dc
    // 0x11436bc: LoadField: r3 = r2->field_7
    //     0x11436bc: ldur            x3, [x2, #7]
    // 0x11436c0: cmp             x3, #4
    // 0x11436c4: b.gt            #0x1143890
    // 0x11436c8: cmp             x3, #2
    // 0x11436cc: b.gt            #0x1143820
    // 0x11436d0: cmp             x3, #1
    // 0x11436d4: b.gt            #0x11437b8
    // 0x11436d8: cmp             x3, #0
    // 0x11436dc: b.gt            #0x1143750
    // 0x11436e0: ArrayLoad: r2 = r1[0]  ; List_8
    //     0x11436e0: ldur            x2, [x1, #0x17]
    // 0x11436e4: mov             x4, x2
    // 0x11436e8: ubfx            x4, x4, #0, #0x20
    // 0x11436ec: r16 = 8193
    //     0x11436ec: mov             x16, #0x2001
    // 0x11436f0: and             w5, w4, w16
    // 0x11436f4: cmp             w5, #1
    // 0x11436f8: b.ne            #0x1143708
    // 0x11436fc: r0 = Instance_KeyboardSide
    //     0x11436fc: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc50] Obj!KeyboardSide@12c3d01
    //     0x1143700: ldr             x0, [x0, #0xc50]
    // 0x1143704: b               #0x114374c
    // 0x1143708: cmp             w5, #2, lsl #12
    // 0x114370c: b.ne            #0x114371c
    // 0x1143710: r0 = Instance_KeyboardSide
    //     0x1143710: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc58] Obj!KeyboardSide@12c3ce1
    //     0x1143714: ldr             x0, [x0, #0xc58]
    // 0x1143718: b               #0x114374c
    // 0x114371c: r17 = 8193
    //     0x114371c: mov             x17, #0x2001
    // 0x1143720: cmp             w5, w17
    // 0x1143724: b.eq            #0x1143740
    // 0x1143728: ubfx            x2, x2, #0, #0x20
    // 0x114372c: r16 = 270337
    //     0x114372c: mov             x16, #0x2001
    //     0x1143730: movk            x16, #4, lsl #16
    // 0x1143734: and             w4, w2, w16
    // 0x1143738: cmp             w4, #0x40, lsl #12
    // 0x114373c: b.ne            #0x1143748
    // 0x1143740: r0 = Instance_KeyboardSide
    //     0x1143740: ldr             x0, [PP, #0x3b60]  ; [pp+0x3b60] Obj!KeyboardSide@12c3cc1
    // 0x1143744: b               #0x114374c
    // 0x1143748: r0 = Null
    //     0x1143748: mov             x0, NULL
    // 0x114374c: ret
    //     0x114374c: ret             
    // 0x1143750: ArrayLoad: r2 = r1[0]  ; List_8
    //     0x1143750: ldur            x2, [x1, #0x17]
    // 0x1143754: mov             x4, x2
    // 0x1143758: ubfx            x4, x4, #0, #0x20
    // 0x114375c: and             w5, w4, #6
    // 0x1143760: cmp             w5, #2
    // 0x1143764: b.ne            #0x1143774
    // 0x1143768: r0 = Instance_KeyboardSide
    //     0x1143768: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc50] Obj!KeyboardSide@12c3d01
    //     0x114376c: ldr             x0, [x0, #0xc50]
    // 0x1143770: b               #0x11437b4
    // 0x1143774: cmp             w5, #4
    // 0x1143778: b.ne            #0x1143788
    // 0x114377c: r0 = Instance_KeyboardSide
    //     0x114377c: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc58] Obj!KeyboardSide@12c3ce1
    //     0x1143780: ldr             x0, [x0, #0xc58]
    // 0x1143784: b               #0x11437b4
    // 0x1143788: cmp             w5, #6
    // 0x114378c: b.eq            #0x11437a8
    // 0x1143790: ubfx            x2, x2, #0, #0x20
    // 0x1143794: r16 = 131078
    //     0x1143794: mov             x16, #6
    //     0x1143798: movk            x16, #2, lsl #16
    // 0x114379c: and             w4, w2, w16
    // 0x11437a0: cmp             w4, #0x20, lsl #12
    // 0x11437a4: b.ne            #0x11437b0
    // 0x11437a8: r0 = Instance_KeyboardSide
    //     0x11437a8: ldr             x0, [PP, #0x3b60]  ; [pp+0x3b60] Obj!KeyboardSide@12c3cc1
    // 0x11437ac: b               #0x11437b4
    // 0x11437b0: r0 = Null
    //     0x11437b0: mov             x0, NULL
    // 0x11437b4: ret
    //     0x11437b4: ret             
    // 0x11437b8: ArrayLoad: r2 = r1[0]  ; List_8
    //     0x11437b8: ldur            x2, [x1, #0x17]
    // 0x11437bc: mov             x4, x2
    // 0x11437c0: ubfx            x4, x4, #0, #0x20
    // 0x11437c4: and             w5, w4, #0x60
    // 0x11437c8: cmp             w5, #0x20
    // 0x11437cc: b.ne            #0x11437dc
    // 0x11437d0: r0 = Instance_KeyboardSide
    //     0x11437d0: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc50] Obj!KeyboardSide@12c3d01
    //     0x11437d4: ldr             x0, [x0, #0xc50]
    // 0x11437d8: b               #0x114381c
    // 0x11437dc: cmp             w5, #0x40
    // 0x11437e0: b.ne            #0x11437f0
    // 0x11437e4: r0 = Instance_KeyboardSide
    //     0x11437e4: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc58] Obj!KeyboardSide@12c3ce1
    //     0x11437e8: ldr             x0, [x0, #0xc58]
    // 0x11437ec: b               #0x114381c
    // 0x11437f0: cmp             w5, #0x60
    // 0x11437f4: b.eq            #0x1143810
    // 0x11437f8: ubfx            x2, x2, #0, #0x20
    // 0x11437fc: r16 = 524384
    //     0x11437fc: mov             x16, #0x60
    //     0x1143800: movk            x16, #8, lsl #16
    // 0x1143804: and             w4, w2, w16
    // 0x1143808: cmp             w4, #0x80, lsl #12
    // 0x114380c: b.ne            #0x1143818
    // 0x1143810: r0 = Instance_KeyboardSide
    //     0x1143810: ldr             x0, [PP, #0x3b60]  ; [pp+0x3b60] Obj!KeyboardSide@12c3cc1
    // 0x1143814: b               #0x114381c
    // 0x1143818: r0 = Null
    //     0x1143818: mov             x0, NULL
    // 0x114381c: ret
    //     0x114381c: ret             
    // 0x1143820: cmp             x3, #3
    // 0x1143824: b.gt            #0x1143890
    // 0x1143828: ArrayLoad: r2 = r1[0]  ; List_8
    //     0x1143828: ldur            x2, [x1, #0x17]
    // 0x114382c: mov             x1, x2
    // 0x1143830: ubfx            x1, x1, #0, #0x20
    // 0x1143834: and             w3, w1, #0x18
    // 0x1143838: cmp             w3, #8
    // 0x114383c: b.ne            #0x114384c
    // 0x1143840: r0 = Instance_KeyboardSide
    //     0x1143840: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc50] Obj!KeyboardSide@12c3d01
    //     0x1143844: ldr             x0, [x0, #0xc50]
    // 0x1143848: b               #0x114388c
    // 0x114384c: cmp             w3, #0x10
    // 0x1143850: b.ne            #0x1143860
    // 0x1143854: r0 = Instance_KeyboardSide
    //     0x1143854: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc58] Obj!KeyboardSide@12c3ce1
    //     0x1143858: ldr             x0, [x0, #0xc58]
    // 0x114385c: b               #0x114388c
    // 0x1143860: cmp             w3, #0x18
    // 0x1143864: b.eq            #0x1143880
    // 0x1143868: ubfx            x2, x2, #0, #0x20
    // 0x114386c: r16 = 1048600
    //     0x114386c: mov             x16, #0x18
    //     0x1143870: movk            x16, #0x10, lsl #16
    // 0x1143874: and             w1, w2, w16
    // 0x1143878: cmp             w1, #0x100, lsl #12
    // 0x114387c: b.ne            #0x1143888
    // 0x1143880: r0 = Instance_KeyboardSide
    //     0x1143880: ldr             x0, [PP, #0x3b60]  ; [pp+0x3b60] Obj!KeyboardSide@12c3cc1
    // 0x1143884: b               #0x114388c
    // 0x1143888: r0 = Null
    //     0x1143888: mov             x0, NULL
    // 0x114388c: ret
    //     0x114388c: ret             
    // 0x1143890: r0 = Instance_KeyboardSide
    //     0x1143890: ldr             x0, [PP, #0x3b60]  ; [pp+0x3b60] Obj!KeyboardSide@12c3cc1
    // 0x1143894: ret
    //     0x1143894: ret             
  }
  get _ physicalKey(/* No info */) {
    // ** addr: 0x114771c, size: 0x80
    // 0x114771c: EnterFrame
    //     0x114771c: stp             fp, lr, [SP, #-0x10]!
    //     0x1147720: mov             fp, SP
    // 0x1147724: AllocStack(0x10)
    //     0x1147724: sub             SP, SP, #0x10
    // 0x1147728: CheckStackOverflow
    //     0x1147728: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x114772c: cmp             SP, x16
    //     0x1147730: b.ls            #0x1147794
    // 0x1147734: LoadField: r3 = r1->field_f
    //     0x1147734: ldur            x3, [x1, #0xf]
    // 0x1147738: stur            x3, [fp, #-8]
    // 0x114773c: r0 = BoxInt64Instr(r3)
    //     0x114773c: sbfiz           x0, x3, #1, #0x1f
    //     0x1147740: cmp             x3, x0, asr #1
    //     0x1147744: b.eq            #0x1147750
    //     0x1147748: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x114774c: stur            x3, [x0, #7]
    // 0x1147750: mov             x2, x0
    // 0x1147754: r1 = _ConstMap len:120
    //     0x1147754: add             x1, PP, #0xd, lsl #12  ; [pp+0xdd20] Map<int, PhysicalKeyboardKey>(120)
    //     0x1147758: ldr             x1, [x1, #0xd20]
    // 0x114775c: r0 = []()
    //     0x114775c: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x1147760: cmp             w0, NULL
    // 0x1147764: b.ne            #0x1147788
    // 0x1147768: ldur            x0, [fp, #-8]
    // 0x114776c: r17 = 94489280512
    //     0x114776c: add             x17, PP, #0xd, lsl #12  ; [pp+0xdc70] IMM: 0x1600000000
    //     0x1147770: ldr             x17, [x17, #0xc70]
    // 0x1147774: add             x1, x0, x17
    // 0x1147778: stur            x1, [fp, #-0x10]
    // 0x114777c: r0 = PhysicalKeyboardKey()
    //     0x114777c: bl              #0x8492a4  ; AllocatePhysicalKeyboardKeyStub -> PhysicalKeyboardKey (size=0x10)
    // 0x1147780: ldur            x1, [fp, #-0x10]
    // 0x1147784: StoreField: r0->field_7 = r1
    //     0x1147784: stur            x1, [x0, #7]
    // 0x1147788: LeaveFrame
    //     0x1147788: mov             SP, fp
    //     0x114778c: ldp             fp, lr, [SP], #0x10
    // 0x1147790: ret
    //     0x1147790: ret             
    // 0x1147794: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1147794: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1147798: b               #0x1147734
  }
  _ isModifierPressed(/* No info */) {
    // ** addr: 0x116ee64, size: 0x180
    // 0x116ee64: ArrayLoad: r3 = r1[0]  ; List_8
    //     0x116ee64: ldur            x3, [x1, #0x17]
    // 0x116ee68: mov             x1, x3
    // 0x116ee6c: ubfx            x1, x1, #0, #0x20
    // 0x116ee70: and             w4, w1, #0xffff0000
    // 0x116ee74: LoadField: r1 = r2->field_7
    //     0x116ee74: ldur            x1, [x2, #7]
    // 0x116ee78: cmp             x1, #4
    // 0x116ee7c: b.gt            #0x116efdc
    // 0x116ee80: cmp             x1, #2
    // 0x116ee84: b.gt            #0x116ef74
    // 0x116ee88: cmp             x1, #1
    // 0x116ee8c: b.gt            #0x116ef2c
    // 0x116ee90: cmp             x1, #0
    // 0x116ee94: b.gt            #0x116eee4
    // 0x116ee98: and             w2, w4, #0x40000
    // 0x116ee9c: mov             x5, x2
    // 0x116eea0: ubfx            x5, x5, #0, #0x20
    // 0x116eea4: tst             x3, x5
    // 0x116eea8: b.ne            #0x116eeb4
    // 0x116eeac: r2 = false
    //     0x116eeac: add             x2, NULL, #0x30  ; false
    // 0x116eeb0: b               #0x116eedc
    // 0x116eeb4: r16 = 8193
    //     0x116eeb4: mov             x16, #0x2001
    // 0x116eeb8: orr             w5, w2, w16
    // 0x116eebc: mov             x6, x3
    // 0x116eec0: ubfx            x6, x6, #0, #0x20
    // 0x116eec4: and             x7, x6, x5
    // 0x116eec8: cmp             w7, w2
    // 0x116eecc: b.ne            #0x116eed8
    // 0x116eed0: r2 = true
    //     0x116eed0: add             x2, NULL, #0x20  ; true
    // 0x116eed4: b               #0x116eedc
    // 0x116eed8: r2 = true
    //     0x116eed8: add             x2, NULL, #0x20  ; true
    // 0x116eedc: mov             x0, x2
    // 0x116eee0: b               #0x116efe0
    // 0x116eee4: and             w2, w4, #0x20000
    // 0x116eee8: mov             x5, x2
    // 0x116eeec: ubfx            x5, x5, #0, #0x20
    // 0x116eef0: tst             x3, x5
    // 0x116eef4: b.ne            #0x116ef00
    // 0x116eef8: r2 = false
    //     0x116eef8: add             x2, NULL, #0x30  ; false
    // 0x116eefc: b               #0x116ef24
    // 0x116ef00: orr             w5, w2, #6
    // 0x116ef04: mov             x6, x3
    // 0x116ef08: ubfx            x6, x6, #0, #0x20
    // 0x116ef0c: and             x7, x6, x5
    // 0x116ef10: cmp             w7, w2
    // 0x116ef14: b.ne            #0x116ef20
    // 0x116ef18: r2 = true
    //     0x116ef18: add             x2, NULL, #0x20  ; true
    // 0x116ef1c: b               #0x116ef24
    // 0x116ef20: r2 = true
    //     0x116ef20: add             x2, NULL, #0x20  ; true
    // 0x116ef24: mov             x0, x2
    // 0x116ef28: b               #0x116efe0
    // 0x116ef2c: and             w2, w4, #0x80000
    // 0x116ef30: mov             x5, x2
    // 0x116ef34: ubfx            x5, x5, #0, #0x20
    // 0x116ef38: tst             x3, x5
    // 0x116ef3c: b.ne            #0x116ef48
    // 0x116ef40: r2 = false
    //     0x116ef40: add             x2, NULL, #0x30  ; false
    // 0x116ef44: b               #0x116ef6c
    // 0x116ef48: orr             w5, w2, #0x60
    // 0x116ef4c: mov             x6, x3
    // 0x116ef50: ubfx            x6, x6, #0, #0x20
    // 0x116ef54: and             x7, x6, x5
    // 0x116ef58: cmp             w7, w2
    // 0x116ef5c: b.ne            #0x116ef68
    // 0x116ef60: r2 = true
    //     0x116ef60: add             x2, NULL, #0x20  ; true
    // 0x116ef64: b               #0x116ef6c
    // 0x116ef68: r2 = true
    //     0x116ef68: add             x2, NULL, #0x20  ; true
    // 0x116ef6c: mov             x0, x2
    // 0x116ef70: b               #0x116efe0
    // 0x116ef74: cmp             x1, #3
    // 0x116ef78: b.gt            #0x116efc0
    // 0x116ef7c: and             w1, w4, #0x100000
    // 0x116ef80: mov             x2, x1
    // 0x116ef84: ubfx            x2, x2, #0, #0x20
    // 0x116ef88: tst             x3, x2
    // 0x116ef8c: b.ne            #0x116ef98
    // 0x116ef90: r1 = false
    //     0x116ef90: add             x1, NULL, #0x30  ; false
    // 0x116ef94: b               #0x116efb8
    // 0x116ef98: orr             w2, w1, #0x18
    // 0x116ef9c: ubfx            x3, x3, #0, #0x20
    // 0x116efa0: and             x5, x3, x2
    // 0x116efa4: cmp             w5, w1
    // 0x116efa8: b.ne            #0x116efb4
    // 0x116efac: r1 = true
    //     0x116efac: add             x1, NULL, #0x20  ; true
    // 0x116efb0: b               #0x116efb8
    // 0x116efb4: r1 = true
    //     0x116efb4: add             x1, NULL, #0x20  ; true
    // 0x116efb8: mov             x0, x1
    // 0x116efbc: b               #0x116efe0
    // 0x116efc0: and             w1, w4, #0x10000
    // 0x116efc4: cbnz            w1, #0x116efd0
    // 0x116efc8: r2 = false
    //     0x116efc8: add             x2, NULL, #0x30  ; false
    // 0x116efcc: b               #0x116efd4
    // 0x116efd0: r2 = true
    //     0x116efd0: add             x2, NULL, #0x20  ; true
    // 0x116efd4: mov             x0, x2
    // 0x116efd8: b               #0x116efe0
    // 0x116efdc: r0 = false
    //     0x116efdc: add             x0, NULL, #0x30  ; false
    // 0x116efe0: ret
    //     0x116efe0: ret             
  }
  _ ==(/* No info */) {
    // ** addr: 0x1279ff4, size: 0x16c
    // 0x1279ff4: EnterFrame
    //     0x1279ff4: stp             fp, lr, [SP, #-0x10]!
    //     0x1279ff8: mov             fp, SP
    // 0x1279ffc: AllocStack(0x10)
    //     0x1279ffc: sub             SP, SP, #0x10
    // 0x127a000: CheckStackOverflow
    //     0x127a000: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x127a004: cmp             SP, x16
    //     0x127a008: b.ls            #0x127a158
    // 0x127a00c: ldr             x0, [fp, #0x10]
    // 0x127a010: cmp             w0, NULL
    // 0x127a014: b.ne            #0x127a028
    // 0x127a018: r0 = false
    //     0x127a018: add             x0, NULL, #0x30  ; false
    // 0x127a01c: LeaveFrame
    //     0x127a01c: mov             SP, fp
    //     0x127a020: ldp             fp, lr, [SP], #0x10
    // 0x127a024: ret
    //     0x127a024: ret             
    // 0x127a028: ldr             x1, [fp, #0x18]
    // 0x127a02c: cmp             w1, w0
    // 0x127a030: b.ne            #0x127a044
    // 0x127a034: r0 = true
    //     0x127a034: add             x0, NULL, #0x20  ; true
    // 0x127a038: LeaveFrame
    //     0x127a038: mov             SP, fp
    //     0x127a03c: ldp             fp, lr, [SP], #0x10
    // 0x127a040: ret
    //     0x127a040: ret             
    // 0x127a044: str             x0, [SP]
    // 0x127a048: r0 = runtimeType()
    //     0x127a048: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x127a04c: r1 = LoadClassIdInstr(r0)
    //     0x127a04c: ldur            x1, [x0, #-1]
    //     0x127a050: ubfx            x1, x1, #0xc, #0x14
    // 0x127a054: r16 = RawKeyEventDataMacOs
    //     0x127a054: add             x16, PP, #0xd, lsl #12  ; [pp+0xdcf8] Type: RawKeyEventDataMacOs
    //     0x127a058: ldr             x16, [x16, #0xcf8]
    // 0x127a05c: stp             x16, x0, [SP]
    // 0x127a060: mov             x0, x1
    // 0x127a064: mov             lr, x0
    // 0x127a068: ldr             lr, [x21, lr, lsl #3]
    // 0x127a06c: blr             lr
    // 0x127a070: tbz             w0, #4, #0x127a084
    // 0x127a074: r0 = false
    //     0x127a074: add             x0, NULL, #0x30  ; false
    // 0x127a078: LeaveFrame
    //     0x127a078: mov             SP, fp
    //     0x127a07c: ldp             fp, lr, [SP], #0x10
    // 0x127a080: ret
    //     0x127a080: ret             
    // 0x127a084: ldr             x1, [fp, #0x10]
    // 0x127a088: r0 = 60
    //     0x127a088: mov             x0, #0x3c
    // 0x127a08c: branchIfSmi(r1, 0x127a098)
    //     0x127a08c: tbz             w1, #0, #0x127a098
    // 0x127a090: r0 = LoadClassIdInstr(r1)
    //     0x127a090: ldur            x0, [x1, #-1]
    //     0x127a094: ubfx            x0, x0, #0xc, #0x14
    // 0x127a098: r17 = 5021
    //     0x127a098: mov             x17, #0x139d
    // 0x127a09c: cmp             x0, x17
    // 0x127a0a0: b.ne            #0x127a148
    // 0x127a0a4: ldr             x2, [fp, #0x18]
    // 0x127a0a8: LoadField: r0 = r1->field_7
    //     0x127a0a8: ldur            w0, [x1, #7]
    // 0x127a0ac: DecompressPointer r0
    //     0x127a0ac: add             x0, x0, HEAP, lsl #32
    // 0x127a0b0: LoadField: r3 = r2->field_7
    //     0x127a0b0: ldur            w3, [x2, #7]
    // 0x127a0b4: DecompressPointer r3
    //     0x127a0b4: add             x3, x3, HEAP, lsl #32
    // 0x127a0b8: r4 = LoadClassIdInstr(r0)
    //     0x127a0b8: ldur            x4, [x0, #-1]
    //     0x127a0bc: ubfx            x4, x4, #0xc, #0x14
    // 0x127a0c0: stp             x3, x0, [SP]
    // 0x127a0c4: mov             x0, x4
    // 0x127a0c8: mov             lr, x0
    // 0x127a0cc: ldr             lr, [x21, lr, lsl #3]
    // 0x127a0d0: blr             lr
    // 0x127a0d4: tbnz            w0, #4, #0x127a148
    // 0x127a0d8: ldr             x2, [fp, #0x18]
    // 0x127a0dc: ldr             x1, [fp, #0x10]
    // 0x127a0e0: LoadField: r0 = r1->field_b
    //     0x127a0e0: ldur            w0, [x1, #0xb]
    // 0x127a0e4: DecompressPointer r0
    //     0x127a0e4: add             x0, x0, HEAP, lsl #32
    // 0x127a0e8: LoadField: r3 = r2->field_b
    //     0x127a0e8: ldur            w3, [x2, #0xb]
    // 0x127a0ec: DecompressPointer r3
    //     0x127a0ec: add             x3, x3, HEAP, lsl #32
    // 0x127a0f0: r4 = LoadClassIdInstr(r0)
    //     0x127a0f0: ldur            x4, [x0, #-1]
    //     0x127a0f4: ubfx            x4, x4, #0xc, #0x14
    // 0x127a0f8: stp             x3, x0, [SP]
    // 0x127a0fc: mov             x0, x4
    // 0x127a100: mov             lr, x0
    // 0x127a104: ldr             lr, [x21, lr, lsl #3]
    // 0x127a108: blr             lr
    // 0x127a10c: tbnz            w0, #4, #0x127a148
    // 0x127a110: ldr             x2, [fp, #0x18]
    // 0x127a114: ldr             x1, [fp, #0x10]
    // 0x127a118: LoadField: r3 = r1->field_f
    //     0x127a118: ldur            x3, [x1, #0xf]
    // 0x127a11c: LoadField: r4 = r2->field_f
    //     0x127a11c: ldur            x4, [x2, #0xf]
    // 0x127a120: cmp             x3, x4
    // 0x127a124: b.ne            #0x127a148
    // 0x127a128: ArrayLoad: r3 = r1[0]  ; List_8
    //     0x127a128: ldur            x3, [x1, #0x17]
    // 0x127a12c: ArrayLoad: r1 = r2[0]  ; List_8
    //     0x127a12c: ldur            x1, [x2, #0x17]
    // 0x127a130: cmp             x3, x1
    // 0x127a134: r16 = true
    //     0x127a134: add             x16, NULL, #0x20  ; true
    // 0x127a138: r17 = false
    //     0x127a138: add             x17, NULL, #0x30  ; false
    // 0x127a13c: csel            x2, x16, x17, eq
    // 0x127a140: mov             x0, x2
    // 0x127a144: b               #0x127a14c
    // 0x127a148: r0 = false
    //     0x127a148: add             x0, NULL, #0x30  ; false
    // 0x127a14c: LeaveFrame
    //     0x127a14c: mov             SP, fp
    //     0x127a150: ldp             fp, lr, [SP], #0x10
    // 0x127a154: ret
    //     0x127a154: ret             
    // 0x127a158: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x127a158: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x127a15c: b               #0x127a00c
  }
}
