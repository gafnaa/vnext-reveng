// lib: , url: package:flutter/src/services/raw_keyboard_web.dart

// class id: 1049092, size: 0x8
class :: {
}

// class id: 5020, size: 0x28, field offset: 0x8
//   const constructor, 
class RawKeyEventDataWeb extends RawKeyEventData {

  get _ hashCode(/* No info */) {
    // ** addr: 0x113c064, size: 0xc4
    // 0x113c064: EnterFrame
    //     0x113c064: stp             fp, lr, [SP, #-0x10]!
    //     0x113c068: mov             fp, SP
    // 0x113c06c: AllocStack(0x18)
    //     0x113c06c: sub             SP, SP, #0x18
    // 0x113c070: CheckStackOverflow
    //     0x113c070: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x113c074: cmp             SP, x16
    //     0x113c078: b.ls            #0x113c120
    // 0x113c07c: ldr             x0, [fp, #0x10]
    // 0x113c080: LoadField: r2 = r0->field_7
    //     0x113c080: ldur            w2, [x0, #7]
    // 0x113c084: DecompressPointer r2
    //     0x113c084: add             x2, x2, HEAP, lsl #32
    // 0x113c088: LoadField: r3 = r0->field_b
    //     0x113c088: ldur            w3, [x0, #0xb]
    // 0x113c08c: DecompressPointer r3
    //     0x113c08c: add             x3, x3, HEAP, lsl #32
    // 0x113c090: LoadField: r4 = r0->field_f
    //     0x113c090: ldur            x4, [x0, #0xf]
    // 0x113c094: ArrayLoad: r5 = r0[0]  ; List_8
    //     0x113c094: ldur            x5, [x0, #0x17]
    // 0x113c098: LoadField: r6 = r0->field_1f
    //     0x113c098: ldur            x6, [x0, #0x1f]
    // 0x113c09c: r0 = BoxInt64Instr(r4)
    //     0x113c09c: sbfiz           x0, x4, #1, #0x1f
    //     0x113c0a0: cmp             x4, x0, asr #1
    //     0x113c0a4: b.eq            #0x113c0b0
    //     0x113c0a8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x113c0ac: stur            x4, [x0, #7]
    // 0x113c0b0: mov             x4, x0
    // 0x113c0b4: r0 = BoxInt64Instr(r5)
    //     0x113c0b4: sbfiz           x0, x5, #1, #0x1f
    //     0x113c0b8: cmp             x5, x0, asr #1
    //     0x113c0bc: b.eq            #0x113c0c8
    //     0x113c0c0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x113c0c4: stur            x5, [x0, #7]
    // 0x113c0c8: mov             x5, x0
    // 0x113c0cc: r0 = BoxInt64Instr(r6)
    //     0x113c0cc: sbfiz           x0, x6, #1, #0x1f
    //     0x113c0d0: cmp             x6, x0, asr #1
    //     0x113c0d4: b.eq            #0x113c0e0
    //     0x113c0d8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x113c0dc: stur            x6, [x0, #7]
    // 0x113c0e0: stp             x5, x4, [SP, #8]
    // 0x113c0e4: str             x0, [SP]
    // 0x113c0e8: mov             x1, x2
    // 0x113c0ec: mov             x2, x3
    // 0x113c0f0: r4 = const [0, 0x5, 0x3, 0x5, null]
    //     0x113c0f0: add             x4, PP, #0xd, lsl #12  ; [pp+0xdc80] List(5) [0, 0x5, 0x3, 0x5, Null]
    //     0x113c0f4: ldr             x4, [x4, #0xc80]
    // 0x113c0f8: r0 = hash()
    //     0x113c0f8: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x113c0fc: mov             x2, x0
    // 0x113c100: r0 = BoxInt64Instr(r2)
    //     0x113c100: sbfiz           x0, x2, #1, #0x1f
    //     0x113c104: cmp             x2, x0, asr #1
    //     0x113c108: b.eq            #0x113c114
    //     0x113c10c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x113c110: stur            x2, [x0, #7]
    // 0x113c114: LeaveFrame
    //     0x113c114: mov             SP, fp
    //     0x113c118: ldp             fp, lr, [SP], #0x10
    // 0x113c11c: ret
    //     0x113c11c: ret             
    // 0x113c120: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x113c120: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x113c124: b               #0x113c07c
  }
  get _ logicalKey(/* No info */) {
    // ** addr: 0x1142f9c, size: 0x1ac
    // 0x1142f9c: EnterFrame
    //     0x1142f9c: stp             fp, lr, [SP, #-0x10]!
    //     0x1142fa0: mov             fp, SP
    // 0x1142fa4: AllocStack(0x28)
    //     0x1142fa4: sub             SP, SP, #0x28
    // 0x1142fa8: SetupParameters(RawKeyEventDataWeb this /* r1 => r0, fp-0x10 */)
    //     0x1142fa8: mov             x0, x1
    //     0x1142fac: stur            x1, [fp, #-0x10]
    // 0x1142fb0: CheckStackOverflow
    //     0x1142fb0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1142fb4: cmp             SP, x16
    //     0x1142fb8: b.ls            #0x114313c
    // 0x1142fbc: LoadField: r3 = r0->field_b
    //     0x1142fbc: ldur            w3, [x0, #0xb]
    // 0x1142fc0: DecompressPointer r3
    //     0x1142fc0: add             x3, x3, HEAP, lsl #32
    // 0x1142fc4: mov             x2, x3
    // 0x1142fc8: stur            x3, [fp, #-8]
    // 0x1142fcc: r1 = _ConstMap len:32
    //     0x1142fcc: add             x1, PP, #0xd, lsl #12  ; [pp+0xdcd8] Map<String, List<LogicalKeyboardKey?>>(32)
    //     0x1142fd0: ldr             x1, [x1, #0xcd8]
    // 0x1142fd4: r0 = []()
    //     0x1142fd4: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x1142fd8: mov             x2, x0
    // 0x1142fdc: cmp             w2, NULL
    // 0x1142fe0: b.ne            #0x1142fec
    // 0x1142fe4: r0 = Null
    //     0x1142fe4: mov             x0, NULL
    // 0x1142fe8: b               #0x1143024
    // 0x1142fec: ldur            x3, [fp, #-0x10]
    // 0x1142ff0: LoadField: r4 = r3->field_f
    //     0x1142ff0: ldur            x4, [x3, #0xf]
    // 0x1142ff4: r0 = BoxInt64Instr(r4)
    //     0x1142ff4: sbfiz           x0, x4, #1, #0x1f
    //     0x1142ff8: cmp             x4, x0, asr #1
    //     0x1142ffc: b.eq            #0x1143008
    //     0x1143000: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1143004: stur            x4, [x0, #7]
    // 0x1143008: r1 = LoadClassIdInstr(r2)
    //     0x1143008: ldur            x1, [x2, #-1]
    //     0x114300c: ubfx            x1, x1, #0xc, #0x14
    // 0x1143010: stp             x0, x2, [SP]
    // 0x1143014: mov             x0, x1
    // 0x1143018: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x1143018: sub             lr, x0, #0xdfd
    //     0x114301c: ldr             lr, [x21, lr, lsl #3]
    //     0x1143020: blr             lr
    // 0x1143024: cmp             w0, NULL
    // 0x1143028: b.eq            #0x1143038
    // 0x114302c: LeaveFrame
    //     0x114302c: mov             SP, fp
    //     0x1143030: ldp             fp, lr, [SP], #0x10
    // 0x1143034: ret
    //     0x1143034: ret             
    // 0x1143038: ldur            x2, [fp, #-8]
    // 0x114303c: r1 = _ConstMap len:301
    //     0x114303c: add             x1, PP, #0xd, lsl #12  ; [pp+0xdce0] Map<String, LogicalKeyboardKey>(301)
    //     0x1143040: ldr             x1, [x1, #0xce0]
    // 0x1143044: r0 = []()
    //     0x1143044: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x1143048: cmp             w0, NULL
    // 0x114304c: b.eq            #0x114305c
    // 0x1143050: LeaveFrame
    //     0x1143050: mov             SP, fp
    //     0x1143054: ldp             fp, lr, [SP], #0x10
    // 0x1143058: ret
    //     0x1143058: ret             
    // 0x114305c: ldur            x0, [fp, #-8]
    // 0x1143060: LoadField: r1 = r0->field_7
    //     0x1143060: ldur            w1, [x0, #7]
    // 0x1143064: cmp             w1, #2
    // 0x1143068: b.ne            #0x11430e8
    // 0x114306c: r1 = LoadClassIdInstr(r0)
    //     0x114306c: ldur            x1, [x0, #-1]
    //     0x1143070: ubfx            x1, x1, #0xc, #0x14
    // 0x1143074: str             x0, [SP]
    // 0x1143078: mov             x0, x1
    // 0x114307c: r0 = GDT[cid_x0 + -0xffc]()
    //     0x114307c: sub             lr, x0, #0xffc
    //     0x1143080: ldr             lr, [x21, lr, lsl #3]
    //     0x1143084: blr             lr
    // 0x1143088: mov             x2, x0
    // 0x114308c: LoadField: r0 = r2->field_7
    //     0x114308c: ldur            w0, [x2, #7]
    // 0x1143090: r1 = LoadInt32Instr(r0)
    //     0x1143090: sbfx            x1, x0, #1, #0x1f
    // 0x1143094: mov             x0, x1
    // 0x1143098: r1 = 0
    //     0x1143098: mov             x1, #0
    // 0x114309c: cmp             x1, x0
    // 0x11430a0: b.hs            #0x1143144
    // 0x11430a4: r0 = LoadClassIdInstr(r2)
    //     0x11430a4: ldur            x0, [x2, #-1]
    //     0x11430a8: ubfx            x0, x0, #0xc, #0x14
    // 0x11430ac: lsl             x0, x0, #1
    // 0x11430b0: cmp             w0, #0xbc
    // 0x11430b4: b.ne            #0x11430c0
    // 0x11430b8: ArrayLoad: r0 = r2[-8]  ; TypedUnsigned_1
    //     0x11430b8: ldrb            w0, [x2, #0xf]
    // 0x11430bc: b               #0x11430c4
    // 0x11430c0: ldurh           w0, [x2, #0xf]
    // 0x11430c4: stur            x0, [fp, #-0x18]
    // 0x11430c8: r0 = LogicalKeyboardKey()
    //     0x11430c8: bl              #0x849274  ; AllocateLogicalKeyboardKeyStub -> LogicalKeyboardKey (size=0x10)
    // 0x11430cc: mov             x1, x0
    // 0x11430d0: ldur            x0, [fp, #-0x18]
    // 0x11430d4: StoreField: r1->field_7 = r0
    //     0x11430d4: stur            x0, [x1, #7]
    // 0x11430d8: mov             x0, x1
    // 0x11430dc: LeaveFrame
    //     0x11430dc: mov             SP, fp
    //     0x11430e0: ldp             fp, lr, [SP], #0x10
    // 0x11430e4: ret
    //     0x11430e4: ret             
    // 0x11430e8: ldur            x0, [fp, #-0x10]
    // 0x11430ec: LoadField: r1 = r0->field_7
    //     0x11430ec: ldur            w1, [x0, #7]
    // 0x11430f0: DecompressPointer r1
    //     0x11430f0: add             x1, x1, HEAP, lsl #32
    // 0x11430f4: r0 = LoadClassIdInstr(r1)
    //     0x11430f4: ldur            x0, [x1, #-1]
    //     0x11430f8: ubfx            x0, x0, #0xc, #0x14
    // 0x11430fc: str             x1, [SP]
    // 0x1143100: r0 = GDT[cid_x0 + 0x70de]()
    //     0x1143100: mov             x17, #0x70de
    //     0x1143104: add             lr, x0, x17
    //     0x1143108: ldr             lr, [x21, lr, lsl #3]
    //     0x114310c: blr             lr
    // 0x1143110: r1 = LoadInt32Instr(r0)
    //     0x1143110: sbfx            x1, x0, #1, #0x1f
    // 0x1143114: r17 = 98784247808
    //     0x1143114: add             x17, PP, #0xd, lsl #12  ; [pp+0xdce8] IMM: 0x1700000000
    //     0x1143118: ldr             x17, [x17, #0xce8]
    // 0x114311c: add             x0, x1, x17
    // 0x1143120: stur            x0, [fp, #-0x18]
    // 0x1143124: r0 = LogicalKeyboardKey()
    //     0x1143124: bl              #0x849274  ; AllocateLogicalKeyboardKeyStub -> LogicalKeyboardKey (size=0x10)
    // 0x1143128: ldur            x1, [fp, #-0x18]
    // 0x114312c: StoreField: r0->field_7 = r1
    //     0x114312c: stur            x1, [x0, #7]
    // 0x1143130: LeaveFrame
    //     0x1143130: mov             SP, fp
    //     0x1143134: ldp             fp, lr, [SP], #0x10
    // 0x1143138: ret
    //     0x1143138: ret             
    // 0x114313c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x114313c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1143140: b               #0x1142fbc
    // 0x1143144: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x1143144: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ getModifierSide(/* No info */) {
    // ** addr: 0x1143898, size: 0x8
    // 0x1143898: r0 = Instance_KeyboardSide
    //     0x1143898: ldr             x0, [PP, #0x3b68]  ; [pp+0x3b68] Obj!KeyboardSide@12c3ca1
    // 0x114389c: ret
    //     0x114389c: ret             
  }
  get _ physicalKey(/* No info */) {
    // ** addr: 0x114779c, size: 0x94
    // 0x114779c: EnterFrame
    //     0x114779c: stp             fp, lr, [SP, #-0x10]!
    //     0x11477a0: mov             fp, SP
    // 0x11477a4: AllocStack(0x18)
    //     0x11477a4: sub             SP, SP, #0x18
    // 0x11477a8: CheckStackOverflow
    //     0x11477a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11477ac: cmp             SP, x16
    //     0x11477b0: b.ls            #0x1147828
    // 0x11477b4: LoadField: r0 = r1->field_7
    //     0x11477b4: ldur            w0, [x1, #7]
    // 0x11477b8: DecompressPointer r0
    //     0x11477b8: add             x0, x0, HEAP, lsl #32
    // 0x11477bc: mov             x2, x0
    // 0x11477c0: stur            x0, [fp, #-8]
    // 0x11477c4: r1 = _ConstMap len:231
    //     0x11477c4: add             x1, PP, #0xd, lsl #12  ; [pp+0xdcf0] Map<String, PhysicalKeyboardKey>(231)
    //     0x11477c8: ldr             x1, [x1, #0xcf0]
    // 0x11477cc: r0 = []()
    //     0x11477cc: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x11477d0: cmp             w0, NULL
    // 0x11477d4: b.ne            #0x114781c
    // 0x11477d8: ldur            x0, [fp, #-8]
    // 0x11477dc: r1 = LoadClassIdInstr(r0)
    //     0x11477dc: ldur            x1, [x0, #-1]
    //     0x11477e0: ubfx            x1, x1, #0xc, #0x14
    // 0x11477e4: str             x0, [SP]
    // 0x11477e8: mov             x0, x1
    // 0x11477ec: r0 = GDT[cid_x0 + 0x70de]()
    //     0x11477ec: mov             x17, #0x70de
    //     0x11477f0: add             lr, x0, x17
    //     0x11477f4: ldr             lr, [x21, lr, lsl #3]
    //     0x11477f8: blr             lr
    // 0x11477fc: r1 = LoadInt32Instr(r0)
    //     0x11477fc: sbfx            x1, x0, #1, #0x1f
    // 0x1147800: r17 = 98784247808
    //     0x1147800: add             x17, PP, #0xd, lsl #12  ; [pp+0xdce8] IMM: 0x1700000000
    //     0x1147804: ldr             x17, [x17, #0xce8]
    // 0x1147808: add             x0, x1, x17
    // 0x114780c: stur            x0, [fp, #-0x10]
    // 0x1147810: r0 = PhysicalKeyboardKey()
    //     0x1147810: bl              #0x8492a4  ; AllocatePhysicalKeyboardKeyStub -> PhysicalKeyboardKey (size=0x10)
    // 0x1147814: ldur            x1, [fp, #-0x10]
    // 0x1147818: StoreField: r0->field_7 = r1
    //     0x1147818: stur            x1, [x0, #7]
    // 0x114781c: LeaveFrame
    //     0x114781c: mov             SP, fp
    //     0x1147820: ldp             fp, lr, [SP], #0x10
    // 0x1147824: ret
    //     0x1147824: ret             
    // 0x1147828: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1147828: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x114782c: b               #0x11477b4
  }
  _ isModifierPressed(/* No info */) {
    // ** addr: 0x116efe4, size: 0x19c
    // 0x116efe4: r16 = Instance_ModifierKey
    //     0x116efe4: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc90] Obj!ModifierKey@12c3c21
    //     0x116efe8: ldr             x16, [x16, #0xc90]
    // 0x116efec: cmp             w2, w16
    // 0x116eff0: b.ne            #0x116f018
    // 0x116eff4: ArrayLoad: r3 = r1[0]  ; List_8
    //     0x116eff4: ldur            x3, [x1, #0x17]
    // 0x116eff8: ubfx            x3, x3, #0, #0x20
    // 0x116effc: and             w4, w3, #4
    // 0x116f000: cbnz            w4, #0x116f00c
    // 0x116f004: r3 = false
    //     0x116f004: add             x3, NULL, #0x30  ; false
    // 0x116f008: b               #0x116f010
    // 0x116f00c: r3 = true
    //     0x116f00c: add             x3, NULL, #0x20  ; true
    // 0x116f010: mov             x0, x3
    // 0x116f014: b               #0x116f17c
    // 0x116f018: r16 = Instance_ModifierKey
    //     0x116f018: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc98] Obj!ModifierKey@12c3c41
    //     0x116f01c: ldr             x16, [x16, #0xc98]
    // 0x116f020: cmp             w2, w16
    // 0x116f024: b.ne            #0x116f04c
    // 0x116f028: ArrayLoad: r3 = r1[0]  ; List_8
    //     0x116f028: ldur            x3, [x1, #0x17]
    // 0x116f02c: ubfx            x3, x3, #0, #0x20
    // 0x116f030: and             w4, w3, #1
    // 0x116f034: cbnz            w4, #0x116f040
    // 0x116f038: r3 = false
    //     0x116f038: add             x3, NULL, #0x30  ; false
    // 0x116f03c: b               #0x116f044
    // 0x116f040: r3 = true
    //     0x116f040: add             x3, NULL, #0x20  ; true
    // 0x116f044: mov             x0, x3
    // 0x116f048: b               #0x116f17c
    // 0x116f04c: r16 = Instance_ModifierKey
    //     0x116f04c: add             x16, PP, #0xd, lsl #12  ; [pp+0xdca0] Obj!ModifierKey@12c3c61
    //     0x116f050: ldr             x16, [x16, #0xca0]
    // 0x116f054: cmp             w2, w16
    // 0x116f058: b.ne            #0x116f080
    // 0x116f05c: ArrayLoad: r3 = r1[0]  ; List_8
    //     0x116f05c: ldur            x3, [x1, #0x17]
    // 0x116f060: ubfx            x3, x3, #0, #0x20
    // 0x116f064: and             w4, w3, #2
    // 0x116f068: cbnz            w4, #0x116f074
    // 0x116f06c: r3 = false
    //     0x116f06c: add             x3, NULL, #0x30  ; false
    // 0x116f070: b               #0x116f078
    // 0x116f074: r3 = true
    //     0x116f074: add             x3, NULL, #0x20  ; true
    // 0x116f078: mov             x0, x3
    // 0x116f07c: b               #0x116f17c
    // 0x116f080: r16 = Instance_ModifierKey
    //     0x116f080: add             x16, PP, #0xd, lsl #12  ; [pp+0xdca8] Obj!ModifierKey@12c3c01
    //     0x116f084: ldr             x16, [x16, #0xca8]
    // 0x116f088: cmp             w2, w16
    // 0x116f08c: b.ne            #0x116f0b4
    // 0x116f090: ArrayLoad: r3 = r1[0]  ; List_8
    //     0x116f090: ldur            x3, [x1, #0x17]
    // 0x116f094: ubfx            x3, x3, #0, #0x20
    // 0x116f098: and             w4, w3, #8
    // 0x116f09c: cbnz            w4, #0x116f0a8
    // 0x116f0a0: r3 = false
    //     0x116f0a0: add             x3, NULL, #0x30  ; false
    // 0x116f0a4: b               #0x116f0ac
    // 0x116f0a8: r3 = true
    //     0x116f0a8: add             x3, NULL, #0x20  ; true
    // 0x116f0ac: mov             x0, x3
    // 0x116f0b0: b               #0x116f17c
    // 0x116f0b4: r16 = Instance_ModifierKey
    //     0x116f0b4: add             x16, PP, #0xd, lsl #12  ; [pp+0xdcb0] Obj!ModifierKey@12c3bc1
    //     0x116f0b8: ldr             x16, [x16, #0xcb0]
    // 0x116f0bc: cmp             w2, w16
    // 0x116f0c0: b.ne            #0x116f0e8
    // 0x116f0c4: ArrayLoad: r3 = r1[0]  ; List_8
    //     0x116f0c4: ldur            x3, [x1, #0x17]
    // 0x116f0c8: ubfx            x3, x3, #0, #0x20
    // 0x116f0cc: and             w4, w3, #0x10
    // 0x116f0d0: cbnz            w4, #0x116f0dc
    // 0x116f0d4: r3 = false
    //     0x116f0d4: add             x3, NULL, #0x30  ; false
    // 0x116f0d8: b               #0x116f0e0
    // 0x116f0dc: r3 = true
    //     0x116f0dc: add             x3, NULL, #0x20  ; true
    // 0x116f0e0: mov             x0, x3
    // 0x116f0e4: b               #0x116f17c
    // 0x116f0e8: r16 = Instance_ModifierKey
    //     0x116f0e8: add             x16, PP, #0xd, lsl #12  ; [pp+0xdcb8] Obj!ModifierKey@12c3be1
    //     0x116f0ec: ldr             x16, [x16, #0xcb8]
    // 0x116f0f0: cmp             w2, w16
    // 0x116f0f4: b.ne            #0x116f11c
    // 0x116f0f8: ArrayLoad: r3 = r1[0]  ; List_8
    //     0x116f0f8: ldur            x3, [x1, #0x17]
    // 0x116f0fc: ubfx            x3, x3, #0, #0x20
    // 0x116f100: and             w4, w3, #0x20
    // 0x116f104: cbnz            w4, #0x116f110
    // 0x116f108: r3 = false
    //     0x116f108: add             x3, NULL, #0x30  ; false
    // 0x116f10c: b               #0x116f114
    // 0x116f110: r3 = true
    //     0x116f110: add             x3, NULL, #0x20  ; true
    // 0x116f114: mov             x0, x3
    // 0x116f118: b               #0x116f17c
    // 0x116f11c: r16 = Instance_ModifierKey
    //     0x116f11c: add             x16, PP, #0xd, lsl #12  ; [pp+0xdcc0] Obj!ModifierKey@12c3ba1
    //     0x116f120: ldr             x16, [x16, #0xcc0]
    // 0x116f124: cmp             w2, w16
    // 0x116f128: b.ne            #0x116f150
    // 0x116f12c: ArrayLoad: r3 = r1[0]  ; List_8
    //     0x116f12c: ldur            x3, [x1, #0x17]
    // 0x116f130: ubfx            x3, x3, #0, #0x20
    // 0x116f134: and             w1, w3, #0x40
    // 0x116f138: cbnz            w1, #0x116f144
    // 0x116f13c: r3 = false
    //     0x116f13c: add             x3, NULL, #0x30  ; false
    // 0x116f140: b               #0x116f148
    // 0x116f144: r3 = true
    //     0x116f144: add             x3, NULL, #0x20  ; true
    // 0x116f148: mov             x0, x3
    // 0x116f14c: b               #0x116f17c
    // 0x116f150: r16 = Instance_ModifierKey
    //     0x116f150: add             x16, PP, #0xd, lsl #12  ; [pp+0xdcc8] Obj!ModifierKey@12c3b81
    //     0x116f154: ldr             x16, [x16, #0xcc8]
    // 0x116f158: cmp             w2, w16
    // 0x116f15c: b.eq            #0x116f170
    // 0x116f160: r16 = Instance_ModifierKey
    //     0x116f160: add             x16, PP, #0xd, lsl #12  ; [pp+0xdcd0] Obj!ModifierKey@12c3c81
    //     0x116f164: ldr             x16, [x16, #0xcd0]
    // 0x116f168: cmp             w2, w16
    // 0x116f16c: b.ne            #0x116f178
    // 0x116f170: r0 = false
    //     0x116f170: add             x0, NULL, #0x30  ; false
    // 0x116f174: b               #0x116f17c
    // 0x116f178: r0 = Null
    //     0x116f178: mov             x0, NULL
    // 0x116f17c: ret
    //     0x116f17c: ret             
  }
  _ ==(/* No info */) {
    // ** addr: 0x127a160, size: 0x17c
    // 0x127a160: EnterFrame
    //     0x127a160: stp             fp, lr, [SP, #-0x10]!
    //     0x127a164: mov             fp, SP
    // 0x127a168: AllocStack(0x10)
    //     0x127a168: sub             SP, SP, #0x10
    // 0x127a16c: CheckStackOverflow
    //     0x127a16c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x127a170: cmp             SP, x16
    //     0x127a174: b.ls            #0x127a2d4
    // 0x127a178: ldr             x0, [fp, #0x10]
    // 0x127a17c: cmp             w0, NULL
    // 0x127a180: b.ne            #0x127a194
    // 0x127a184: r0 = false
    //     0x127a184: add             x0, NULL, #0x30  ; false
    // 0x127a188: LeaveFrame
    //     0x127a188: mov             SP, fp
    //     0x127a18c: ldp             fp, lr, [SP], #0x10
    // 0x127a190: ret
    //     0x127a190: ret             
    // 0x127a194: ldr             x1, [fp, #0x18]
    // 0x127a198: cmp             w1, w0
    // 0x127a19c: b.ne            #0x127a1b0
    // 0x127a1a0: r0 = true
    //     0x127a1a0: add             x0, NULL, #0x20  ; true
    // 0x127a1a4: LeaveFrame
    //     0x127a1a4: mov             SP, fp
    //     0x127a1a8: ldp             fp, lr, [SP], #0x10
    // 0x127a1ac: ret
    //     0x127a1ac: ret             
    // 0x127a1b0: str             x0, [SP]
    // 0x127a1b4: r0 = runtimeType()
    //     0x127a1b4: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x127a1b8: r1 = LoadClassIdInstr(r0)
    //     0x127a1b8: ldur            x1, [x0, #-1]
    //     0x127a1bc: ubfx            x1, x1, #0xc, #0x14
    // 0x127a1c0: r16 = RawKeyEventDataWeb
    //     0x127a1c0: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc88] Type: RawKeyEventDataWeb
    //     0x127a1c4: ldr             x16, [x16, #0xc88]
    // 0x127a1c8: stp             x16, x0, [SP]
    // 0x127a1cc: mov             x0, x1
    // 0x127a1d0: mov             lr, x0
    // 0x127a1d4: ldr             lr, [x21, lr, lsl #3]
    // 0x127a1d8: blr             lr
    // 0x127a1dc: tbz             w0, #4, #0x127a1f0
    // 0x127a1e0: r0 = false
    //     0x127a1e0: add             x0, NULL, #0x30  ; false
    // 0x127a1e4: LeaveFrame
    //     0x127a1e4: mov             SP, fp
    //     0x127a1e8: ldp             fp, lr, [SP], #0x10
    // 0x127a1ec: ret
    //     0x127a1ec: ret             
    // 0x127a1f0: ldr             x1, [fp, #0x10]
    // 0x127a1f4: r0 = 60
    //     0x127a1f4: mov             x0, #0x3c
    // 0x127a1f8: branchIfSmi(r1, 0x127a204)
    //     0x127a1f8: tbz             w1, #0, #0x127a204
    // 0x127a1fc: r0 = LoadClassIdInstr(r1)
    //     0x127a1fc: ldur            x0, [x1, #-1]
    //     0x127a200: ubfx            x0, x0, #0xc, #0x14
    // 0x127a204: r17 = 5020
    //     0x127a204: mov             x17, #0x139c
    // 0x127a208: cmp             x0, x17
    // 0x127a20c: b.ne            #0x127a2c4
    // 0x127a210: ldr             x2, [fp, #0x18]
    // 0x127a214: LoadField: r0 = r1->field_7
    //     0x127a214: ldur            w0, [x1, #7]
    // 0x127a218: DecompressPointer r0
    //     0x127a218: add             x0, x0, HEAP, lsl #32
    // 0x127a21c: LoadField: r3 = r2->field_7
    //     0x127a21c: ldur            w3, [x2, #7]
    // 0x127a220: DecompressPointer r3
    //     0x127a220: add             x3, x3, HEAP, lsl #32
    // 0x127a224: r4 = LoadClassIdInstr(r0)
    //     0x127a224: ldur            x4, [x0, #-1]
    //     0x127a228: ubfx            x4, x4, #0xc, #0x14
    // 0x127a22c: stp             x3, x0, [SP]
    // 0x127a230: mov             x0, x4
    // 0x127a234: mov             lr, x0
    // 0x127a238: ldr             lr, [x21, lr, lsl #3]
    // 0x127a23c: blr             lr
    // 0x127a240: tbnz            w0, #4, #0x127a2c4
    // 0x127a244: ldr             x2, [fp, #0x18]
    // 0x127a248: ldr             x1, [fp, #0x10]
    // 0x127a24c: LoadField: r0 = r1->field_b
    //     0x127a24c: ldur            w0, [x1, #0xb]
    // 0x127a250: DecompressPointer r0
    //     0x127a250: add             x0, x0, HEAP, lsl #32
    // 0x127a254: LoadField: r3 = r2->field_b
    //     0x127a254: ldur            w3, [x2, #0xb]
    // 0x127a258: DecompressPointer r3
    //     0x127a258: add             x3, x3, HEAP, lsl #32
    // 0x127a25c: r4 = LoadClassIdInstr(r0)
    //     0x127a25c: ldur            x4, [x0, #-1]
    //     0x127a260: ubfx            x4, x4, #0xc, #0x14
    // 0x127a264: stp             x3, x0, [SP]
    // 0x127a268: mov             x0, x4
    // 0x127a26c: mov             lr, x0
    // 0x127a270: ldr             lr, [x21, lr, lsl #3]
    // 0x127a274: blr             lr
    // 0x127a278: tbnz            w0, #4, #0x127a2c4
    // 0x127a27c: ldr             x2, [fp, #0x18]
    // 0x127a280: ldr             x1, [fp, #0x10]
    // 0x127a284: LoadField: r3 = r1->field_f
    //     0x127a284: ldur            x3, [x1, #0xf]
    // 0x127a288: LoadField: r4 = r2->field_f
    //     0x127a288: ldur            x4, [x2, #0xf]
    // 0x127a28c: cmp             x3, x4
    // 0x127a290: b.ne            #0x127a2c4
    // 0x127a294: ArrayLoad: r3 = r1[0]  ; List_8
    //     0x127a294: ldur            x3, [x1, #0x17]
    // 0x127a298: ArrayLoad: r4 = r2[0]  ; List_8
    //     0x127a298: ldur            x4, [x2, #0x17]
    // 0x127a29c: cmp             x3, x4
    // 0x127a2a0: b.ne            #0x127a2c4
    // 0x127a2a4: LoadField: r3 = r1->field_1f
    //     0x127a2a4: ldur            x3, [x1, #0x1f]
    // 0x127a2a8: LoadField: r1 = r2->field_1f
    //     0x127a2a8: ldur            x1, [x2, #0x1f]
    // 0x127a2ac: cmp             x3, x1
    // 0x127a2b0: r16 = true
    //     0x127a2b0: add             x16, NULL, #0x20  ; true
    // 0x127a2b4: r17 = false
    //     0x127a2b4: add             x17, NULL, #0x30  ; false
    // 0x127a2b8: csel            x2, x16, x17, eq
    // 0x127a2bc: mov             x0, x2
    // 0x127a2c0: b               #0x127a2c8
    // 0x127a2c4: r0 = false
    //     0x127a2c4: add             x0, NULL, #0x30  ; false
    // 0x127a2c8: LeaveFrame
    //     0x127a2c8: mov             SP, fp
    //     0x127a2cc: ldp             fp, lr, [SP], #0x10
    // 0x127a2d0: ret
    //     0x127a2d0: ret             
    // 0x127a2d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x127a2d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x127a2d8: b               #0x127a178
  }
}
