// lib: , url: package:flutter/src/services/raw_keyboard_fuchsia.dart

// class id: 1049088, size: 0x8
class :: {
}

// class id: 5024, size: 0x20, field offset: 0x8
//   const constructor, 
class RawKeyEventDataFuchsia extends RawKeyEventData {

  get _ hashCode(/* No info */) {
    // ** addr: 0x113be28, size: 0xac
    // 0x113be28: EnterFrame
    //     0x113be28: stp             fp, lr, [SP, #-0x10]!
    //     0x113be2c: mov             fp, SP
    // 0x113be30: AllocStack(0x8)
    //     0x113be30: sub             SP, SP, #8
    // 0x113be34: CheckStackOverflow
    //     0x113be34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x113be38: cmp             SP, x16
    //     0x113be3c: b.ls            #0x113becc
    // 0x113be40: ldr             x0, [fp, #0x10]
    // 0x113be44: LoadField: r2 = r0->field_7
    //     0x113be44: ldur            x2, [x0, #7]
    // 0x113be48: LoadField: r3 = r0->field_f
    //     0x113be48: ldur            x3, [x0, #0xf]
    // 0x113be4c: ArrayLoad: r4 = r0[0]  ; List_8
    //     0x113be4c: ldur            x4, [x0, #0x17]
    // 0x113be50: r0 = BoxInt64Instr(r2)
    //     0x113be50: sbfiz           x0, x2, #1, #0x1f
    //     0x113be54: cmp             x2, x0, asr #1
    //     0x113be58: b.eq            #0x113be64
    //     0x113be5c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x113be60: stur            x2, [x0, #7]
    // 0x113be64: mov             x2, x0
    // 0x113be68: r0 = BoxInt64Instr(r3)
    //     0x113be68: sbfiz           x0, x3, #1, #0x1f
    //     0x113be6c: cmp             x3, x0, asr #1
    //     0x113be70: b.eq            #0x113be7c
    //     0x113be74: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x113be78: stur            x3, [x0, #7]
    // 0x113be7c: mov             x3, x0
    // 0x113be80: r0 = BoxInt64Instr(r4)
    //     0x113be80: sbfiz           x0, x4, #1, #0x1f
    //     0x113be84: cmp             x4, x0, asr #1
    //     0x113be88: b.eq            #0x113be94
    //     0x113be8c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x113be90: stur            x4, [x0, #7]
    // 0x113be94: str             x0, [SP]
    // 0x113be98: mov             x1, x2
    // 0x113be9c: mov             x2, x3
    // 0x113bea0: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x113bea0: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x113bea4: r0 = hash()
    //     0x113bea4: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x113bea8: mov             x2, x0
    // 0x113beac: r0 = BoxInt64Instr(r2)
    //     0x113beac: sbfiz           x0, x2, #1, #0x1f
    //     0x113beb0: cmp             x2, x0, asr #1
    //     0x113beb4: b.eq            #0x113bec0
    //     0x113beb8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x113bebc: stur            x2, [x0, #7]
    // 0x113bec0: LeaveFrame
    //     0x113bec0: mov             SP, fp
    //     0x113bec4: ldp             fp, lr, [SP], #0x10
    // 0x113bec8: ret
    //     0x113bec8: ret             
    // 0x113becc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x113becc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x113bed0: b               #0x113be40
  }
  get _ logicalKey(/* No info */) {
    // ** addr: 0x1142664, size: 0x118
    // 0x1142664: EnterFrame
    //     0x1142664: stp             fp, lr, [SP, #-0x10]!
    //     0x1142668: mov             fp, SP
    // 0x114266c: AllocStack(0x8)
    //     0x114266c: sub             SP, SP, #8
    // 0x1142670: CheckStackOverflow
    //     0x1142670: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1142674: cmp             SP, x16
    //     0x1142678: b.ls            #0x1142760
    // 0x114267c: LoadField: r0 = r1->field_f
    //     0x114267c: ldur            x0, [x1, #0xf]
    // 0x1142680: cbz             x0, #0x11426f8
    // 0x1142684: ubfx            x0, x0, #0, #0x20
    // 0x1142688: stur            x0, [fp, #-8]
    // 0x114268c: lsl             w2, w0, #1
    // 0x1142690: tst             x0, #0xc0000000
    // 0x1142694: b.eq            #0x11426c8
    // 0x1142698: r2 = inline_Allocate_Mint()
    //     0x1142698: ldp             x2, x1, [THR, #0x60]  ; THR::top
    //     0x114269c: add             x2, x2, #0x10
    //     0x11426a0: cmp             x1, x2
    //     0x11426a4: b.ls            #0x1142768
    //     0x11426a8: str             x2, [THR, #0x60]  ; THR::top
    //     0x11426ac: sub             x2, x2, #0xf
    //     0x11426b0: mov             x1, #0xd19c
    //     0x11426b4: movk            x1, #3, lsl #16
    //     0x11426b8: stur            x1, [x2, #-1]
    // 0x11426bc: dmb             ishst
    // 0x11426c0: ubfx            x1, x0, #0, #0x20
    // 0x11426c4: StoreField: r2->field_7 = r1
    //     0x11426c4: stur            x1, [x2, #7]
    // 0x11426c8: r1 = _ConstMap len:233
    //     0x11426c8: add             x1, PP, #0xd, lsl #12  ; [pp+0xdd80] Map<int, LogicalKeyboardKey>(233)
    //     0x11426cc: ldr             x1, [x1, #0xd80]
    // 0x11426d0: r0 = []()
    //     0x11426d0: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x11426d4: cmp             w0, NULL
    // 0x11426d8: b.ne            #0x11426ec
    // 0x11426dc: r0 = LogicalKeyboardKey()
    //     0x11426dc: bl              #0x849274  ; AllocateLogicalKeyboardKeyStub -> LogicalKeyboardKey (size=0x10)
    // 0x11426e0: ldur            x1, [fp, #-8]
    // 0x11426e4: ubfx            x1, x1, #0, #0x20
    // 0x11426e8: StoreField: r0->field_7 = r1
    //     0x11426e8: stur            x1, [x0, #7]
    // 0x11426ec: LeaveFrame
    //     0x11426ec: mov             SP, fp
    //     0x11426f0: ldp             fp, lr, [SP], #0x10
    // 0x11426f4: ret
    //     0x11426f4: ret             
    // 0x11426f8: LoadField: r0 = r1->field_7
    //     0x11426f8: ldur            x0, [x1, #7]
    // 0x11426fc: r16 = 77309411328
    //     0x11426fc: add             x16, PP, #0xd, lsl #12  ; [pp+0xdd78] IMM: 0x1200000000
    //     0x1142700: ldr             x16, [x16, #0xd78]
    // 0x1142704: orr             x3, x0, x16
    // 0x1142708: stur            x3, [fp, #-8]
    // 0x114270c: r0 = BoxInt64Instr(r3)
    //     0x114270c: sbfiz           x0, x3, #1, #0x1f
    //     0x1142710: cmp             x3, x0, asr #1
    //     0x1142714: b.eq            #0x1142720
    //     0x1142718: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x114271c: stur            x3, [x0, #7]
    // 0x1142720: mov             x2, x0
    // 0x1142724: r1 = _ConstMap len:233
    //     0x1142724: add             x1, PP, #0xd, lsl #12  ; [pp+0xdd80] Map<int, LogicalKeyboardKey>(233)
    //     0x1142728: ldr             x1, [x1, #0xd80]
    // 0x114272c: r0 = []()
    //     0x114272c: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x1142730: cmp             w0, NULL
    // 0x1142734: b.eq            #0x1142744
    // 0x1142738: LeaveFrame
    //     0x1142738: mov             SP, fp
    //     0x114273c: ldp             fp, lr, [SP], #0x10
    // 0x1142740: ret
    //     0x1142740: ret             
    // 0x1142744: ldur            x0, [fp, #-8]
    // 0x1142748: r0 = LogicalKeyboardKey()
    //     0x1142748: bl              #0x849274  ; AllocateLogicalKeyboardKeyStub -> LogicalKeyboardKey (size=0x10)
    // 0x114274c: ldur            x1, [fp, #-8]
    // 0x1142750: StoreField: r0->field_7 = r1
    //     0x1142750: stur            x1, [x0, #7]
    // 0x1142754: LeaveFrame
    //     0x1142754: mov             SP, fp
    //     0x1142758: ldp             fp, lr, [SP], #0x10
    // 0x114275c: ret
    //     0x114275c: ret             
    // 0x1142760: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1142760: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1142764: b               #0x114267c
    // 0x1142768: SaveReg r0
    //     0x1142768: str             x0, [SP, #-8]!
    // 0x114276c: r0 = AllocateMint()
    //     0x114276c: bl              #0x13df8d0  ; AllocateMintStub
    // 0x1142770: mov             x2, x0
    // 0x1142774: RestoreReg r0
    //     0x1142774: ldr             x0, [SP], #8
    // 0x1142778: b               #0x11426c0
  }
  _ getModifierSide(/* No info */) {
    // ** addr: 0x11434ec, size: 0x17c
    // 0x11434ec: LoadField: r3 = r2->field_7
    //     0x11434ec: ldur            x3, [x2, #7]
    // 0x11434f0: cmp             x3, #4
    // 0x11434f4: b.gt            #0x1143660
    // 0x11434f8: cmp             x3, #2
    // 0x11434fc: b.gt            #0x11435f4
    // 0x1143500: cmp             x3, #1
    // 0x1143504: b.gt            #0x11435a8
    // 0x1143508: cmp             x3, #0
    // 0x114350c: b.gt            #0x114355c
    // 0x1143510: ArrayLoad: r2 = r1[0]  ; List_8
    //     0x1143510: ldur            x2, [x1, #0x17]
    // 0x1143514: ubfx            x2, x2, #0, #0x20
    // 0x1143518: and             w4, w2, #0x18
    // 0x114351c: cmp             w4, #8
    // 0x1143520: b.ne            #0x1143530
    // 0x1143524: r0 = Instance_KeyboardSide
    //     0x1143524: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc50] Obj!KeyboardSide@12c3d01
    //     0x1143528: ldr             x0, [x0, #0xc50]
    // 0x114352c: b               #0x1143558
    // 0x1143530: cmp             w4, #0x10
    // 0x1143534: b.ne            #0x1143544
    // 0x1143538: r0 = Instance_KeyboardSide
    //     0x1143538: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc58] Obj!KeyboardSide@12c3ce1
    //     0x114353c: ldr             x0, [x0, #0xc58]
    // 0x1143540: b               #0x1143558
    // 0x1143544: cmp             w4, #0x18
    // 0x1143548: b.ne            #0x1143554
    // 0x114354c: r0 = Instance_KeyboardSide
    //     0x114354c: ldr             x0, [PP, #0x3b60]  ; [pp+0x3b60] Obj!KeyboardSide@12c3cc1
    // 0x1143550: b               #0x1143558
    // 0x1143554: r0 = Null
    //     0x1143554: mov             x0, NULL
    // 0x1143558: ret
    //     0x1143558: ret             
    // 0x114355c: ArrayLoad: r2 = r1[0]  ; List_8
    //     0x114355c: ldur            x2, [x1, #0x17]
    // 0x1143560: ubfx            x2, x2, #0, #0x20
    // 0x1143564: and             w4, w2, #6
    // 0x1143568: cmp             w4, #2
    // 0x114356c: b.ne            #0x114357c
    // 0x1143570: r0 = Instance_KeyboardSide
    //     0x1143570: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc50] Obj!KeyboardSide@12c3d01
    //     0x1143574: ldr             x0, [x0, #0xc50]
    // 0x1143578: b               #0x11435a4
    // 0x114357c: cmp             w4, #4
    // 0x1143580: b.ne            #0x1143590
    // 0x1143584: r0 = Instance_KeyboardSide
    //     0x1143584: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc58] Obj!KeyboardSide@12c3ce1
    //     0x1143588: ldr             x0, [x0, #0xc58]
    // 0x114358c: b               #0x11435a4
    // 0x1143590: cmp             w4, #6
    // 0x1143594: b.ne            #0x11435a0
    // 0x1143598: r0 = Instance_KeyboardSide
    //     0x1143598: ldr             x0, [PP, #0x3b60]  ; [pp+0x3b60] Obj!KeyboardSide@12c3cc1
    // 0x114359c: b               #0x11435a4
    // 0x11435a0: r0 = Null
    //     0x11435a0: mov             x0, NULL
    // 0x11435a4: ret
    //     0x11435a4: ret             
    // 0x11435a8: ArrayLoad: r2 = r1[0]  ; List_8
    //     0x11435a8: ldur            x2, [x1, #0x17]
    // 0x11435ac: ubfx            x2, x2, #0, #0x20
    // 0x11435b0: and             w4, w2, #0x60
    // 0x11435b4: cmp             w4, #0x20
    // 0x11435b8: b.ne            #0x11435c8
    // 0x11435bc: r0 = Instance_KeyboardSide
    //     0x11435bc: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc50] Obj!KeyboardSide@12c3d01
    //     0x11435c0: ldr             x0, [x0, #0xc50]
    // 0x11435c4: b               #0x11435f0
    // 0x11435c8: cmp             w4, #0x40
    // 0x11435cc: b.ne            #0x11435dc
    // 0x11435d0: r0 = Instance_KeyboardSide
    //     0x11435d0: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc58] Obj!KeyboardSide@12c3ce1
    //     0x11435d4: ldr             x0, [x0, #0xc58]
    // 0x11435d8: b               #0x11435f0
    // 0x11435dc: cmp             w4, #0x60
    // 0x11435e0: b.ne            #0x11435ec
    // 0x11435e4: r0 = Instance_KeyboardSide
    //     0x11435e4: ldr             x0, [PP, #0x3b60]  ; [pp+0x3b60] Obj!KeyboardSide@12c3cc1
    // 0x11435e8: b               #0x11435f0
    // 0x11435ec: r0 = Null
    //     0x11435ec: mov             x0, NULL
    // 0x11435f0: ret
    //     0x11435f0: ret             
    // 0x11435f4: cmp             x3, #3
    // 0x11435f8: b.gt            #0x1143648
    // 0x11435fc: ArrayLoad: r2 = r1[0]  ; List_8
    //     0x11435fc: ldur            x2, [x1, #0x17]
    // 0x1143600: ubfx            x2, x2, #0, #0x20
    // 0x1143604: and             w3, w2, #0x180
    // 0x1143608: cmp             w3, #0x80
    // 0x114360c: b.ne            #0x114361c
    // 0x1143610: r0 = Instance_KeyboardSide
    //     0x1143610: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc50] Obj!KeyboardSide@12c3d01
    //     0x1143614: ldr             x0, [x0, #0xc50]
    // 0x1143618: b               #0x1143644
    // 0x114361c: cmp             w3, #0x100
    // 0x1143620: b.ne            #0x1143630
    // 0x1143624: r0 = Instance_KeyboardSide
    //     0x1143624: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc58] Obj!KeyboardSide@12c3ce1
    //     0x1143628: ldr             x0, [x0, #0xc58]
    // 0x114362c: b               #0x1143644
    // 0x1143630: cmp             w3, #0x180
    // 0x1143634: b.ne            #0x1143640
    // 0x1143638: r0 = Instance_KeyboardSide
    //     0x1143638: ldr             x0, [PP, #0x3b60]  ; [pp+0x3b60] Obj!KeyboardSide@12c3cc1
    // 0x114363c: b               #0x1143644
    // 0x1143640: r0 = Null
    //     0x1143640: mov             x0, NULL
    // 0x1143644: ret
    //     0x1143644: ret             
    // 0x1143648: ArrayLoad: r2 = r1[0]  ; List_8
    //     0x1143648: ldur            x2, [x1, #0x17]
    // 0x114364c: tbnz            w2, #0, #0x1143658
    // 0x1143650: r0 = Null
    //     0x1143650: mov             x0, NULL
    // 0x1143654: b               #0x114365c
    // 0x1143658: r0 = Instance_KeyboardSide
    //     0x1143658: ldr             x0, [PP, #0x3b60]  ; [pp+0x3b60] Obj!KeyboardSide@12c3cc1
    // 0x114365c: ret
    //     0x114365c: ret             
    // 0x1143660: r0 = Null
    //     0x1143660: mov             x0, NULL
    // 0x1143664: ret
    //     0x1143664: ret             
  }
  get _ physicalKey(/* No info */) {
    // ** addr: 0x11475a0, size: 0x7c
    // 0x11475a0: EnterFrame
    //     0x11475a0: stp             fp, lr, [SP, #-0x10]!
    //     0x11475a4: mov             fp, SP
    // 0x11475a8: AllocStack(0x10)
    //     0x11475a8: sub             SP, SP, #0x10
    // 0x11475ac: CheckStackOverflow
    //     0x11475ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11475b0: cmp             SP, x16
    //     0x11475b4: b.ls            #0x1147614
    // 0x11475b8: LoadField: r3 = r1->field_7
    //     0x11475b8: ldur            x3, [x1, #7]
    // 0x11475bc: stur            x3, [fp, #-8]
    // 0x11475c0: r0 = BoxInt64Instr(r3)
    //     0x11475c0: sbfiz           x0, x3, #1, #0x1f
    //     0x11475c4: cmp             x3, x0, asr #1
    //     0x11475c8: b.eq            #0x11475d4
    //     0x11475cc: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x11475d0: stur            x3, [x0, #7]
    // 0x11475d4: mov             x2, x0
    // 0x11475d8: r1 = _ConstMap len:269
    //     0x11475d8: ldr             x1, [PP, #0x40e0]  ; [pp+0x40e0] Map<int, PhysicalKeyboardKey>(269)
    // 0x11475dc: r0 = []()
    //     0x11475dc: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x11475e0: cmp             w0, NULL
    // 0x11475e4: b.ne            #0x1147608
    // 0x11475e8: ldur            x0, [fp, #-8]
    // 0x11475ec: r17 = 77309411328
    //     0x11475ec: add             x17, PP, #0xd, lsl #12  ; [pp+0xdd78] IMM: 0x1200000000
    //     0x11475f0: ldr             x17, [x17, #0xd78]
    // 0x11475f4: add             x1, x0, x17
    // 0x11475f8: stur            x1, [fp, #-0x10]
    // 0x11475fc: r0 = PhysicalKeyboardKey()
    //     0x11475fc: bl              #0x8492a4  ; AllocatePhysicalKeyboardKeyStub -> PhysicalKeyboardKey (size=0x10)
    // 0x1147600: ldur            x1, [fp, #-0x10]
    // 0x1147604: StoreField: r0->field_7 = r1
    //     0x1147604: stur            x1, [x0, #7]
    // 0x1147608: LeaveFrame
    //     0x1147608: mov             SP, fp
    //     0x114760c: ldp             fp, lr, [SP], #0x10
    // 0x1147610: ret
    //     0x1147610: ret             
    // 0x1147614: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1147614: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1147618: b               #0x11475b8
  }
  _ isModifierPressed(/* No info */) {
    // ** addr: 0x116ed40, size: 0xc4
    // 0x116ed40: LoadField: r3 = r2->field_7
    //     0x116ed40: ldur            x3, [x2, #7]
    // 0x116ed44: cmp             x3, #4
    // 0x116ed48: b.gt            #0x116edfc
    // 0x116ed4c: cmp             x3, #2
    // 0x116ed50: b.gt            #0x116edb8
    // 0x116ed54: cmp             x3, #1
    // 0x116ed58: b.gt            #0x116ed9c
    // 0x116ed5c: cmp             x3, #0
    // 0x116ed60: b.gt            #0x116ed80
    // 0x116ed64: ArrayLoad: r2 = r1[0]  ; List_8
    //     0x116ed64: ldur            x2, [x1, #0x17]
    // 0x116ed68: tst             x2, #0x18
    // 0x116ed6c: b.ne            #0x116ed78
    // 0x116ed70: r0 = false
    //     0x116ed70: add             x0, NULL, #0x30  ; false
    // 0x116ed74: b               #0x116ed7c
    // 0x116ed78: r0 = true
    //     0x116ed78: add             x0, NULL, #0x20  ; true
    // 0x116ed7c: ret
    //     0x116ed7c: ret             
    // 0x116ed80: ArrayLoad: r2 = r1[0]  ; List_8
    //     0x116ed80: ldur            x2, [x1, #0x17]
    // 0x116ed84: tst             x2, #6
    // 0x116ed88: b.ne            #0x116ed94
    // 0x116ed8c: r0 = false
    //     0x116ed8c: add             x0, NULL, #0x30  ; false
    // 0x116ed90: b               #0x116ed98
    // 0x116ed94: r0 = true
    //     0x116ed94: add             x0, NULL, #0x20  ; true
    // 0x116ed98: ret
    //     0x116ed98: ret             
    // 0x116ed9c: ArrayLoad: r2 = r1[0]  ; List_8
    //     0x116ed9c: ldur            x2, [x1, #0x17]
    // 0x116eda0: tst             x2, #0x60
    // 0x116eda4: b.ne            #0x116edb0
    // 0x116eda8: r0 = false
    //     0x116eda8: add             x0, NULL, #0x30  ; false
    // 0x116edac: b               #0x116edb4
    // 0x116edb0: r0 = true
    //     0x116edb0: add             x0, NULL, #0x20  ; true
    // 0x116edb4: ret
    //     0x116edb4: ret             
    // 0x116edb8: cmp             x3, #3
    // 0x116edbc: b.gt            #0x116eddc
    // 0x116edc0: ArrayLoad: r2 = r1[0]  ; List_8
    //     0x116edc0: ldur            x2, [x1, #0x17]
    // 0x116edc4: tst             x2, #0x180
    // 0x116edc8: b.ne            #0x116edd4
    // 0x116edcc: r0 = false
    //     0x116edcc: add             x0, NULL, #0x30  ; false
    // 0x116edd0: b               #0x116edd8
    // 0x116edd4: r0 = true
    //     0x116edd4: add             x0, NULL, #0x20  ; true
    // 0x116edd8: ret
    //     0x116edd8: ret             
    // 0x116eddc: ArrayLoad: r2 = r1[0]  ; List_8
    //     0x116eddc: ldur            x2, [x1, #0x17]
    // 0x116ede0: ubfx            x2, x2, #0, #0x20
    // 0x116ede4: and             w1, w2, #1
    // 0x116ede8: cbnz            w1, #0x116edf4
    // 0x116edec: r0 = false
    //     0x116edec: add             x0, NULL, #0x30  ; false
    // 0x116edf0: b               #0x116edf8
    // 0x116edf4: r0 = true
    //     0x116edf4: add             x0, NULL, #0x20  ; true
    // 0x116edf8: ret
    //     0x116edf8: ret             
    // 0x116edfc: r0 = false
    //     0x116edfc: add             x0, NULL, #0x30  ; false
    // 0x116ee00: ret
    //     0x116ee00: ret             
  }
  _ ==(/* No info */) {
    // ** addr: 0x1279c24, size: 0x10c
    // 0x1279c24: EnterFrame
    //     0x1279c24: stp             fp, lr, [SP, #-0x10]!
    //     0x1279c28: mov             fp, SP
    // 0x1279c2c: AllocStack(0x10)
    //     0x1279c2c: sub             SP, SP, #0x10
    // 0x1279c30: CheckStackOverflow
    //     0x1279c30: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1279c34: cmp             SP, x16
    //     0x1279c38: b.ls            #0x1279d28
    // 0x1279c3c: ldr             x0, [fp, #0x10]
    // 0x1279c40: cmp             w0, NULL
    // 0x1279c44: b.ne            #0x1279c58
    // 0x1279c48: r0 = false
    //     0x1279c48: add             x0, NULL, #0x30  ; false
    // 0x1279c4c: LeaveFrame
    //     0x1279c4c: mov             SP, fp
    //     0x1279c50: ldp             fp, lr, [SP], #0x10
    // 0x1279c54: ret
    //     0x1279c54: ret             
    // 0x1279c58: ldr             x1, [fp, #0x18]
    // 0x1279c5c: cmp             w1, w0
    // 0x1279c60: b.ne            #0x1279c74
    // 0x1279c64: r0 = true
    //     0x1279c64: add             x0, NULL, #0x20  ; true
    // 0x1279c68: LeaveFrame
    //     0x1279c68: mov             SP, fp
    //     0x1279c6c: ldp             fp, lr, [SP], #0x10
    // 0x1279c70: ret
    //     0x1279c70: ret             
    // 0x1279c74: str             x0, [SP]
    // 0x1279c78: r0 = runtimeType()
    //     0x1279c78: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x1279c7c: r1 = LoadClassIdInstr(r0)
    //     0x1279c7c: ldur            x1, [x0, #-1]
    //     0x1279c80: ubfx            x1, x1, #0xc, #0x14
    // 0x1279c84: r16 = RawKeyEventDataFuchsia
    //     0x1279c84: add             x16, PP, #0xd, lsl #12  ; [pp+0xdd70] Type: RawKeyEventDataFuchsia
    //     0x1279c88: ldr             x16, [x16, #0xd70]
    // 0x1279c8c: stp             x16, x0, [SP]
    // 0x1279c90: mov             x0, x1
    // 0x1279c94: mov             lr, x0
    // 0x1279c98: ldr             lr, [x21, lr, lsl #3]
    // 0x1279c9c: blr             lr
    // 0x1279ca0: tbz             w0, #4, #0x1279cb4
    // 0x1279ca4: r0 = false
    //     0x1279ca4: add             x0, NULL, #0x30  ; false
    // 0x1279ca8: LeaveFrame
    //     0x1279ca8: mov             SP, fp
    //     0x1279cac: ldp             fp, lr, [SP], #0x10
    // 0x1279cb0: ret
    //     0x1279cb0: ret             
    // 0x1279cb4: ldr             x1, [fp, #0x10]
    // 0x1279cb8: r2 = 60
    //     0x1279cb8: mov             x2, #0x3c
    // 0x1279cbc: branchIfSmi(r1, 0x1279cc8)
    //     0x1279cbc: tbz             w1, #0, #0x1279cc8
    // 0x1279cc0: r2 = LoadClassIdInstr(r1)
    //     0x1279cc0: ldur            x2, [x1, #-1]
    //     0x1279cc4: ubfx            x2, x2, #0xc, #0x14
    // 0x1279cc8: r17 = 5024
    //     0x1279cc8: mov             x17, #0x13a0
    // 0x1279ccc: cmp             x2, x17
    // 0x1279cd0: b.ne            #0x1279d18
    // 0x1279cd4: ldr             x2, [fp, #0x18]
    // 0x1279cd8: LoadField: r3 = r1->field_7
    //     0x1279cd8: ldur            x3, [x1, #7]
    // 0x1279cdc: LoadField: r4 = r2->field_7
    //     0x1279cdc: ldur            x4, [x2, #7]
    // 0x1279ce0: cmp             x3, x4
    // 0x1279ce4: b.ne            #0x1279d18
    // 0x1279ce8: LoadField: r3 = r1->field_f
    //     0x1279ce8: ldur            x3, [x1, #0xf]
    // 0x1279cec: LoadField: r4 = r2->field_f
    //     0x1279cec: ldur            x4, [x2, #0xf]
    // 0x1279cf0: cmp             x3, x4
    // 0x1279cf4: b.ne            #0x1279d18
    // 0x1279cf8: ArrayLoad: r3 = r1[0]  ; List_8
    //     0x1279cf8: ldur            x3, [x1, #0x17]
    // 0x1279cfc: ArrayLoad: r1 = r2[0]  ; List_8
    //     0x1279cfc: ldur            x1, [x2, #0x17]
    // 0x1279d00: cmp             x3, x1
    // 0x1279d04: r16 = true
    //     0x1279d04: add             x16, NULL, #0x20  ; true
    // 0x1279d08: r17 = false
    //     0x1279d08: add             x17, NULL, #0x30  ; false
    // 0x1279d0c: csel            x2, x16, x17, eq
    // 0x1279d10: mov             x0, x2
    // 0x1279d14: b               #0x1279d1c
    // 0x1279d18: r0 = false
    //     0x1279d18: add             x0, NULL, #0x30  ; false
    // 0x1279d1c: LeaveFrame
    //     0x1279d1c: mov             SP, fp
    //     0x1279d20: ldp             fp, lr, [SP], #0x10
    // 0x1279d24: ret
    //     0x1279d24: ret             
    // 0x1279d28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1279d28: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1279d2c: b               #0x1279c3c
  }
}
