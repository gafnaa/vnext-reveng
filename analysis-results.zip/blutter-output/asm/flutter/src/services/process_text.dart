// lib: , url: package:flutter/src/services/process_text.dart

// class id: 1049085, size: 0x8
class :: {
}

// class id: 2755, size: 0xc, field offset: 0x8
class DefaultProcessTextService extends Object
    implements ProcessTextService {

  late MethodChannel _processTextChannel; // offset: 0x8

  _ processTextAction(/* No info */) async {
    // ** addr: 0xd92128, size: 0x118
    // 0xd92128: EnterFrame
    //     0xd92128: stp             fp, lr, [SP, #-0x10]!
    //     0xd9212c: mov             fp, SP
    // 0xd92130: AllocStack(0x48)
    //     0xd92130: sub             SP, SP, #0x48
    // 0xd92134: SetupParameters(DefaultProcessTextService this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */, dynamic _ /* r5 => r5, fp-0x28 */)
    //     0xd92134: stur            NULL, [fp, #-8]
    //     0xd92138: stur            x1, [fp, #-0x10]
    //     0xd9213c: stur            x2, [fp, #-0x18]
    //     0xd92140: stur            x3, [fp, #-0x20]
    //     0xd92144: stur            x5, [fp, #-0x28]
    // 0xd92148: CheckStackOverflow
    //     0xd92148: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd9214c: cmp             SP, x16
    //     0xd92150: b.ls            #0xd9222c
    // 0xd92154: InitAsync() -> Future<String?>
    //     0xd92154: ldr             x0, [PP, #0xe28]  ; [pp+0xe28] TypeArguments: <String?>
    //     0xd92158: bl              #0x7f5e44  ; InitAsyncStub
    // 0xd9215c: ldur            x0, [fp, #-0x10]
    // 0xd92160: LoadField: r1 = r0->field_7
    //     0xd92160: ldur            w1, [x0, #7]
    // 0xd92164: DecompressPointer r1
    //     0xd92164: add             x1, x1, HEAP, lsl #32
    // 0xd92168: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd9216c: cmp             w1, w16
    // 0xd92170: b.eq            #0xd92234
    // 0xd92174: r1 = Null
    //     0xd92174: mov             x1, NULL
    // 0xd92178: r2 = 6
    //     0xd92178: mov             x2, #6
    // 0xd9217c: r0 = AllocateArray()
    //     0xd9217c: bl              #0x13df928  ; AllocateArrayStub
    // 0xd92180: mov             x2, x0
    // 0xd92184: ldur            x0, [fp, #-0x18]
    // 0xd92188: stur            x2, [fp, #-0x10]
    // 0xd9218c: StoreField: r2->field_f = r0
    //     0xd9218c: stur            w0, [x2, #0xf]
    // 0xd92190: ldur            x0, [fp, #-0x20]
    // 0xd92194: StoreField: r2->field_13 = r0
    //     0xd92194: stur            w0, [x2, #0x13]
    // 0xd92198: ldur            x0, [fp, #-0x28]
    // 0xd9219c: ArrayStore: r2[0] = r0  ; List_4
    //     0xd9219c: stur            w0, [x2, #0x17]
    // 0xd921a0: r1 = Null
    //     0xd921a0: mov             x1, NULL
    // 0xd921a4: r0 = AllocateGrowableArray()
    //     0xd921a4: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xd921a8: mov             x1, x0
    // 0xd921ac: ldur            x0, [fp, #-0x10]
    // 0xd921b0: StoreField: r1->field_f = r0
    //     0xd921b0: stur            w0, [x1, #0xf]
    // 0xd921b4: r0 = 6
    //     0xd921b4: mov             x0, #6
    // 0xd921b8: StoreField: r1->field_b = r0
    //     0xd921b8: stur            w0, [x1, #0xb]
    // 0xd921bc: r16 = Instance_OptionalMethodChannel
    //     0xd921bc: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a7d0] Obj!OptionalMethodChannel@129bf61
    //     0xd921c0: ldr             x16, [x16, #0x7d0]
    // 0xd921c4: stp             x16, NULL, [SP, #0x10]
    // 0xd921c8: r16 = "ProcessText.processTextAction"
    //     0xd921c8: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a7d8] "ProcessText.processTextAction"
    //     0xd921cc: ldr             x16, [x16, #0x7d8]
    // 0xd921d0: stp             x1, x16, [SP]
    // 0xd921d4: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xd921d4: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xd921d8: r0 = invokeMethod()
    //     0xd921d8: bl              #0x130ad0c  ; [package:flutter/src/services/platform_channel.dart] OptionalMethodChannel::invokeMethod
    // 0xd921dc: mov             x1, x0
    // 0xd921e0: stur            x1, [fp, #-0x10]
    // 0xd921e4: r0 = Await()
    //     0xd921e4: bl              #0x7f5c00  ; AwaitStub
    // 0xd921e8: mov             x3, x0
    // 0xd921ec: r2 = Null
    //     0xd921ec: mov             x2, NULL
    // 0xd921f0: r1 = Null
    //     0xd921f0: mov             x1, NULL
    // 0xd921f4: stur            x3, [fp, #-0x10]
    // 0xd921f8: r4 = 60
    //     0xd921f8: mov             x4, #0x3c
    // 0xd921fc: branchIfSmi(r0, 0xd92208)
    //     0xd921fc: tbz             w0, #0, #0xd92208
    // 0xd92200: r4 = LoadClassIdInstr(r0)
    //     0xd92200: ldur            x4, [x0, #-1]
    //     0xd92204: ubfx            x4, x4, #0xc, #0x14
    // 0xd92208: sub             x4, x4, #0x5e
    // 0xd9220c: cmp             x4, #1
    // 0xd92210: b.ls            #0xd92224
    // 0xd92214: r8 = String?
    //     0xd92214: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0xd92218: r3 = Null
    //     0xd92218: add             x3, PP, #0x1a, lsl #12  ; [pp+0x1a7e0] Null
    //     0xd9221c: ldr             x3, [x3, #0x7e0]
    // 0xd92220: r0 = String?()
    //     0xd92220: bl              #0x7db310  ; IsType_String?_Stub
    // 0xd92224: ldur            x0, [fp, #-0x10]
    // 0xd92228: r0 = ReturnAsyncNotFuture()
    //     0xd92228: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xd9222c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd9222c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd92230: b               #0xd92154
    // 0xd92234: r9 = _processTextChannel
    //     0xd92234: add             x9, PP, #0x1a, lsl #12  ; [pp+0x1a7f0] Field <DefaultProcessTextService._processTextChannel@635387600>: late (offset: 0x8)
    //     0xd92238: ldr             x9, [x9, #0x7f0]
    // 0xd9223c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd9223c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ queryTextActions(/* No info */) async {
    // ** addr: 0xf82f54, size: 0x310
    // 0xf82f54: EnterFrame
    //     0xf82f54: stp             fp, lr, [SP, #-0x10]!
    //     0xf82f58: mov             fp, SP
    // 0xf82f5c: AllocStack(0xb8)
    //     0xf82f5c: sub             SP, SP, #0xb8
    // 0xf82f60: SetupParameters(DefaultProcessTextService this /* r1 => r1, fp-0x70 */)
    //     0xf82f60: stur            NULL, [fp, #-8]
    //     0xf82f64: stur            x1, [fp, #-0x70]
    // 0xf82f68: CheckStackOverflow
    //     0xf82f68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf82f6c: cmp             SP, x16
    //     0xf82f70: b.ls            #0xf83240
    // 0xf82f74: InitAsync() -> Future<List<ProcessTextAction>>
    //     0xf82f74: add             x0, PP, #0xa3, lsl #12  ; [pp+0xa32f8] TypeArguments: <List<ProcessTextAction>>
    //     0xf82f78: ldr             x0, [x0, #0x2f8]
    //     0xf82f7c: bl              #0x7f5e44  ; InitAsyncStub
    // 0xf82f80: ldur            x0, [fp, #-0x70]
    // 0xf82f84: LoadField: r1 = r0->field_7
    //     0xf82f84: ldur            w1, [x0, #7]
    // 0xf82f88: DecompressPointer r1
    //     0xf82f88: add             x1, x1, HEAP, lsl #32
    // 0xf82f8c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf82f90: cmp             w1, w16
    // 0xf82f94: b.eq            #0xf83248
    // 0xf82f98: r16 = Instance_OptionalMethodChannel
    //     0xf82f98: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a7d0] Obj!OptionalMethodChannel@129bf61
    //     0xf82f9c: ldr             x16, [x16, #0x7d0]
    // 0xf82fa0: stp             x16, NULL, [SP, #8]
    // 0xf82fa4: r16 = "ProcessText.queryTextActions"
    //     0xf82fa4: add             x16, PP, #0xa3, lsl #12  ; [pp+0xa3300] "ProcessText.queryTextActions"
    //     0xf82fa8: ldr             x16, [x16, #0x300]
    // 0xf82fac: str             x16, [SP]
    // 0xf82fb0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xf82fb0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xf82fb4: r0 = invokeMethod()
    //     0xf82fb4: bl              #0x130ad0c  ; [package:flutter/src/services/platform_channel.dart] OptionalMethodChannel::invokeMethod
    // 0xf82fb8: mov             x1, x0
    // 0xf82fbc: stur            x1, [fp, #-0x78]
    // 0xf82fc0: r0 = Await()
    //     0xf82fc0: bl              #0x7f5c00  ; AwaitStub
    // 0xf82fc4: mov             x3, x0
    // 0xf82fc8: r2 = Null
    //     0xf82fc8: mov             x2, NULL
    // 0xf82fcc: r1 = Null
    //     0xf82fcc: mov             x1, NULL
    // 0xf82fd0: stur            x3, [fp, #-0x78]
    // 0xf82fd4: r8 = Map<Object?, Object?>?
    //     0xf82fd4: ldr             x8, [PP, #0x18c0]  ; [pp+0x18c0] Type: Map<Object?, Object?>?
    // 0xf82fd8: r3 = Null
    //     0xf82fd8: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa3308] Null
    //     0xf82fdc: ldr             x3, [x3, #0x308]
    // 0xf82fe0: r0 = Map<Object?, Object?>?()
    //     0xf82fe0: bl              #0x8514d0  ; IsType_Map<Object?, Object?>?_Stub
    // 0xf82fe4: ldur            x0, [fp, #-0x78]
    // 0xf82fe8: cmp             w0, NULL
    // 0xf82fec: b.ne            #0xf83004
    // 0xf82ff0: r1 = <ProcessTextAction>
    //     0xf82ff0: add             x1, PP, #0x98, lsl #12  ; [pp+0x98d08] TypeArguments: <ProcessTextAction>
    //     0xf82ff4: ldr             x1, [x1, #0xd08]
    // 0xf82ff8: r2 = 0
    //     0xf82ff8: mov             x2, #0
    // 0xf82ffc: r0 = _GrowableList()
    //     0xf82ffc: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xf83000: r0 = ReturnAsyncNotFuture()
    //     0xf83000: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xf83004: r1 = <ProcessTextAction>
    //     0xf83004: add             x1, PP, #0x98, lsl #12  ; [pp+0x98d08] TypeArguments: <ProcessTextAction>
    //     0xf83008: ldr             x1, [x1, #0xd08]
    // 0xf8300c: r2 = 0
    //     0xf8300c: mov             x2, #0
    // 0xf83010: r0 = _GrowableList()
    //     0xf83010: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xf83014: mov             x3, x0
    // 0xf83018: ldur            x2, [fp, #-0x78]
    // 0xf8301c: stur            x3, [fp, #-0x70]
    // 0xf83020: r0 = LoadClassIdInstr(r2)
    //     0xf83020: ldur            x0, [x2, #-1]
    //     0xf83024: ubfx            x0, x0, #0xc, #0x14
    // 0xf83028: mov             x1, x2
    // 0xf8302c: r0 = GDT[cid_x0 + 0x44d]()
    //     0xf8302c: add             lr, x0, #0x44d
    //     0xf83030: ldr             lr, [x21, lr, lsl #3]
    //     0xf83034: blr             lr
    // 0xf83038: r1 = LoadClassIdInstr(r0)
    //     0xf83038: ldur            x1, [x0, #-1]
    //     0xf8303c: ubfx            x1, x1, #0xc, #0x14
    // 0xf83040: mov             x16, x0
    // 0xf83044: mov             x0, x1
    // 0xf83048: mov             x1, x16
    // 0xf8304c: r0 = GDT[cid_x0 + 0x12641]()
    //     0xf8304c: mov             x17, #0x2641
    //     0xf83050: movk            x17, #1, lsl #16
    //     0xf83054: add             lr, x0, x17
    //     0xf83058: ldr             lr, [x21, lr, lsl #3]
    //     0xf8305c: blr             lr
    // 0xf83060: mov             x2, x0
    // 0xf83064: stur            x2, [fp, #-0x80]
    // 0xf83068: ldur            x4, [fp, #-0x70]
    // 0xf8306c: ldur            x3, [fp, #-0x78]
    // 0xf83070: CheckStackOverflow
    //     0xf83070: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf83074: cmp             SP, x16
    //     0xf83078: b.ls            #0xf83254
    // 0xf8307c: r0 = LoadClassIdInstr(r2)
    //     0xf8307c: ldur            x0, [x2, #-1]
    //     0xf83080: ubfx            x0, x0, #0xc, #0x14
    // 0xf83084: mov             x1, x2
    // 0xf83088: r0 = GDT[cid_x0 + 0x1845b]()
    //     0xf83088: mov             x17, #0x845b
    //     0xf8308c: movk            x17, #1, lsl #16
    //     0xf83090: add             lr, x0, x17
    //     0xf83094: ldr             lr, [x21, lr, lsl #3]
    //     0xf83098: blr             lr
    // 0xf8309c: tbnz            w0, #4, #0xf8321c
    // 0xf830a0: ldur            x3, [fp, #-0x78]
    // 0xf830a4: ldur            x4, [fp, #-0x70]
    // 0xf830a8: ldur            x2, [fp, #-0x80]
    // 0xf830ac: r0 = LoadClassIdInstr(r2)
    //     0xf830ac: ldur            x0, [x2, #-1]
    //     0xf830b0: ubfx            x0, x0, #0xc, #0x14
    // 0xf830b4: mov             x1, x2
    // 0xf830b8: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0xf830b8: mov             x17, #0x7d4c
    //     0xf830bc: movk            x17, #1, lsl #16
    //     0xf830c0: add             lr, x0, x17
    //     0xf830c4: ldr             lr, [x21, lr, lsl #3]
    //     0xf830c8: blr             lr
    // 0xf830cc: mov             x3, x0
    // 0xf830d0: stur            x3, [fp, #-0x88]
    // 0xf830d4: cmp             w3, NULL
    // 0xf830d8: b.eq            #0xf8325c
    // 0xf830dc: mov             x0, x3
    // 0xf830e0: r2 = Null
    //     0xf830e0: mov             x2, NULL
    // 0xf830e4: r1 = Null
    //     0xf830e4: mov             x1, NULL
    // 0xf830e8: r4 = 60
    //     0xf830e8: mov             x4, #0x3c
    // 0xf830ec: branchIfSmi(r0, 0xf830f8)
    //     0xf830ec: tbz             w0, #0, #0xf830f8
    // 0xf830f0: r4 = LoadClassIdInstr(r0)
    //     0xf830f0: ldur            x4, [x0, #-1]
    //     0xf830f4: ubfx            x4, x4, #0xc, #0x14
    // 0xf830f8: sub             x4, x4, #0x5e
    // 0xf830fc: cmp             x4, #1
    // 0xf83100: b.ls            #0xf83114
    // 0xf83104: r8 = String
    //     0xf83104: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0xf83108: r3 = Null
    //     0xf83108: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa3318] Null
    //     0xf8310c: ldr             x3, [x3, #0x318]
    // 0xf83110: r0 = String()
    //     0xf83110: bl              #0x13ee320  ; IsType_String_Stub
    // 0xf83114: ldur            x3, [fp, #-0x78]
    // 0xf83118: r0 = LoadClassIdInstr(r3)
    //     0xf83118: ldur            x0, [x3, #-1]
    //     0xf8311c: ubfx            x0, x0, #0xc, #0x14
    // 0xf83120: mov             x1, x3
    // 0xf83124: ldur            x2, [fp, #-0x88]
    // 0xf83128: r0 = GDT[cid_x0 + -0xd48]()
    //     0xf83128: sub             lr, x0, #0xd48
    //     0xf8312c: ldr             lr, [x21, lr, lsl #3]
    //     0xf83130: blr             lr
    // 0xf83134: mov             x3, x0
    // 0xf83138: stur            x3, [fp, #-0x90]
    // 0xf8313c: cmp             w3, NULL
    // 0xf83140: b.eq            #0xf83260
    // 0xf83144: mov             x0, x3
    // 0xf83148: r2 = Null
    //     0xf83148: mov             x2, NULL
    // 0xf8314c: r1 = Null
    //     0xf8314c: mov             x1, NULL
    // 0xf83150: r4 = 60
    //     0xf83150: mov             x4, #0x3c
    // 0xf83154: branchIfSmi(r0, 0xf83160)
    //     0xf83154: tbz             w0, #0, #0xf83160
    // 0xf83158: r4 = LoadClassIdInstr(r0)
    //     0xf83158: ldur            x4, [x0, #-1]
    //     0xf8315c: ubfx            x4, x4, #0xc, #0x14
    // 0xf83160: sub             x4, x4, #0x5e
    // 0xf83164: cmp             x4, #1
    // 0xf83168: b.ls            #0xf8317c
    // 0xf8316c: r8 = String
    //     0xf8316c: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0xf83170: r3 = Null
    //     0xf83170: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa3328] Null
    //     0xf83174: ldr             x3, [x3, #0x328]
    // 0xf83178: r0 = String()
    //     0xf83178: bl              #0x13ee320  ; IsType_String_Stub
    // 0xf8317c: r0 = ProcessTextAction()
    //     0xf8317c: bl              #0xf83264  ; AllocateProcessTextActionStub -> ProcessTextAction (size=0x10)
    // 0xf83180: mov             x2, x0
    // 0xf83184: ldur            x0, [fp, #-0x88]
    // 0xf83188: stur            x2, [fp, #-0xa0]
    // 0xf8318c: StoreField: r2->field_7 = r0
    //     0xf8318c: stur            w0, [x2, #7]
    // 0xf83190: ldur            x0, [fp, #-0x90]
    // 0xf83194: StoreField: r2->field_b = r0
    //     0xf83194: stur            w0, [x2, #0xb]
    // 0xf83198: ldur            x0, [fp, #-0x70]
    // 0xf8319c: LoadField: r1 = r0->field_b
    //     0xf8319c: ldur            w1, [x0, #0xb]
    // 0xf831a0: LoadField: r3 = r0->field_f
    //     0xf831a0: ldur            w3, [x0, #0xf]
    // 0xf831a4: DecompressPointer r3
    //     0xf831a4: add             x3, x3, HEAP, lsl #32
    // 0xf831a8: LoadField: r4 = r3->field_b
    //     0xf831a8: ldur            w4, [x3, #0xb]
    // 0xf831ac: r3 = LoadInt32Instr(r1)
    //     0xf831ac: sbfx            x3, x1, #1, #0x1f
    // 0xf831b0: stur            x3, [fp, #-0x98]
    // 0xf831b4: r1 = LoadInt32Instr(r4)
    //     0xf831b4: sbfx            x1, x4, #1, #0x1f
    // 0xf831b8: cmp             x3, x1
    // 0xf831bc: b.ne            #0xf831c8
    // 0xf831c0: mov             x1, x0
    // 0xf831c4: r0 = _growToNextCapacity()
    //     0xf831c4: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xf831c8: ldur            x2, [fp, #-0x70]
    // 0xf831cc: ldur            x3, [fp, #-0x98]
    // 0xf831d0: add             x0, x3, #1
    // 0xf831d4: lsl             x1, x0, #1
    // 0xf831d8: StoreField: r2->field_b = r1
    //     0xf831d8: stur            w1, [x2, #0xb]
    // 0xf831dc: LoadField: r1 = r2->field_f
    //     0xf831dc: ldur            w1, [x2, #0xf]
    // 0xf831e0: DecompressPointer r1
    //     0xf831e0: add             x1, x1, HEAP, lsl #32
    // 0xf831e4: ldur            x0, [fp, #-0xa0]
    // 0xf831e8: ArrayStore: r1[r3] = r0  ; List_4
    //     0xf831e8: add             x25, x1, x3, lsl #2
    //     0xf831ec: add             x25, x25, #0xf
    //     0xf831f0: str             w0, [x25]
    //     0xf831f4: tbz             w0, #0, #0xf83210
    //     0xf831f8: ldurb           w16, [x1, #-1]
    //     0xf831fc: ldurb           w17, [x0, #-1]
    //     0xf83200: and             x16, x17, x16, lsr #2
    //     0xf83204: tst             x16, HEAP, lsr #32
    //     0xf83208: b.eq            #0xf83210
    //     0xf8320c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xf83210: mov             x4, x2
    // 0xf83214: ldur            x2, [fp, #-0x80]
    // 0xf83218: b               #0xf8306c
    // 0xf8321c: ldur            x2, [fp, #-0x70]
    // 0xf83220: mov             x0, x2
    // 0xf83224: r0 = ReturnAsyncNotFuture()
    //     0xf83224: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xf83228: sub             SP, fp, #0xb8
    // 0xf8322c: r1 = <ProcessTextAction>
    //     0xf8322c: add             x1, PP, #0x98, lsl #12  ; [pp+0x98d08] TypeArguments: <ProcessTextAction>
    //     0xf83230: ldr             x1, [x1, #0xd08]
    // 0xf83234: r2 = 0
    //     0xf83234: mov             x2, #0
    // 0xf83238: r0 = _GrowableList()
    //     0xf83238: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xf8323c: r0 = ReturnAsyncNotFuture()
    //     0xf8323c: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xf83240: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf83240: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf83244: b               #0xf82f74
    // 0xf83248: r9 = _processTextChannel
    //     0xf83248: add             x9, PP, #0x1a, lsl #12  ; [pp+0x1a7f0] Field <DefaultProcessTextService._processTextChannel@635387600>: late (offset: 0x8)
    //     0xf8324c: ldr             x9, [x9, #0x7f0]
    // 0xf83250: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf83250: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xf83254: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf83254: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf83258: b               #0xf8307c
    // 0xf8325c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf8325c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf83260: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf83260: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2756, size: 0x8, field offset: 0x8
abstract class ProcessTextService extends Object {
}

// class id: 2757, size: 0x10, field offset: 0x8
//   const constructor, 
class ProcessTextAction extends Object {

  _ ==(/* No info */) {
    // ** addr: 0x129add0, size: 0xe8
    // 0x129add0: EnterFrame
    //     0x129add0: stp             fp, lr, [SP, #-0x10]!
    //     0x129add4: mov             fp, SP
    // 0x129add8: AllocStack(0x10)
    //     0x129add8: sub             SP, SP, #0x10
    // 0x129addc: CheckStackOverflow
    //     0x129addc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x129ade0: cmp             SP, x16
    //     0x129ade4: b.ls            #0x129aeb0
    // 0x129ade8: ldr             x1, [fp, #0x10]
    // 0x129adec: cmp             w1, NULL
    // 0x129adf0: b.ne            #0x129ae04
    // 0x129adf4: r0 = false
    //     0x129adf4: add             x0, NULL, #0x30  ; false
    // 0x129adf8: LeaveFrame
    //     0x129adf8: mov             SP, fp
    //     0x129adfc: ldp             fp, lr, [SP], #0x10
    // 0x129ae00: ret
    //     0x129ae00: ret             
    // 0x129ae04: ldr             x2, [fp, #0x18]
    // 0x129ae08: cmp             w2, w1
    // 0x129ae0c: b.ne            #0x129ae20
    // 0x129ae10: r0 = true
    //     0x129ae10: add             x0, NULL, #0x20  ; true
    // 0x129ae14: LeaveFrame
    //     0x129ae14: mov             SP, fp
    //     0x129ae18: ldp             fp, lr, [SP], #0x10
    // 0x129ae1c: ret
    //     0x129ae1c: ret             
    // 0x129ae20: r0 = 60
    //     0x129ae20: mov             x0, #0x3c
    // 0x129ae24: branchIfSmi(r1, 0x129ae30)
    //     0x129ae24: tbz             w1, #0, #0x129ae30
    // 0x129ae28: r0 = LoadClassIdInstr(r1)
    //     0x129ae28: ldur            x0, [x1, #-1]
    //     0x129ae2c: ubfx            x0, x0, #0xc, #0x14
    // 0x129ae30: cmp             x0, #0xac5
    // 0x129ae34: b.ne            #0x129aea0
    // 0x129ae38: LoadField: r0 = r1->field_7
    //     0x129ae38: ldur            w0, [x1, #7]
    // 0x129ae3c: DecompressPointer r0
    //     0x129ae3c: add             x0, x0, HEAP, lsl #32
    // 0x129ae40: LoadField: r3 = r2->field_7
    //     0x129ae40: ldur            w3, [x2, #7]
    // 0x129ae44: DecompressPointer r3
    //     0x129ae44: add             x3, x3, HEAP, lsl #32
    // 0x129ae48: r4 = LoadClassIdInstr(r0)
    //     0x129ae48: ldur            x4, [x0, #-1]
    //     0x129ae4c: ubfx            x4, x4, #0xc, #0x14
    // 0x129ae50: stp             x3, x0, [SP]
    // 0x129ae54: mov             x0, x4
    // 0x129ae58: mov             lr, x0
    // 0x129ae5c: ldr             lr, [x21, lr, lsl #3]
    // 0x129ae60: blr             lr
    // 0x129ae64: tbnz            w0, #4, #0x129aea0
    // 0x129ae68: ldr             x1, [fp, #0x18]
    // 0x129ae6c: ldr             x0, [fp, #0x10]
    // 0x129ae70: LoadField: r2 = r0->field_b
    //     0x129ae70: ldur            w2, [x0, #0xb]
    // 0x129ae74: DecompressPointer r2
    //     0x129ae74: add             x2, x2, HEAP, lsl #32
    // 0x129ae78: LoadField: r0 = r1->field_b
    //     0x129ae78: ldur            w0, [x1, #0xb]
    // 0x129ae7c: DecompressPointer r0
    //     0x129ae7c: add             x0, x0, HEAP, lsl #32
    // 0x129ae80: r1 = LoadClassIdInstr(r2)
    //     0x129ae80: ldur            x1, [x2, #-1]
    //     0x129ae84: ubfx            x1, x1, #0xc, #0x14
    // 0x129ae88: stp             x0, x2, [SP]
    // 0x129ae8c: mov             x0, x1
    // 0x129ae90: mov             lr, x0
    // 0x129ae94: ldr             lr, [x21, lr, lsl #3]
    // 0x129ae98: blr             lr
    // 0x129ae9c: b               #0x129aea4
    // 0x129aea0: r0 = false
    //     0x129aea0: add             x0, NULL, #0x30  ; false
    // 0x129aea4: LeaveFrame
    //     0x129aea4: mov             SP, fp
    //     0x129aea8: ldp             fp, lr, [SP], #0x10
    // 0x129aeac: ret
    //     0x129aeac: ret             
    // 0x129aeb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x129aeb0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x129aeb4: b               #0x129ade8
  }
}
