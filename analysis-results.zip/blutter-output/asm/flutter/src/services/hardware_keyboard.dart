// lib: , url: package:flutter/src/services/hardware_keyboard.dart

// class id: 1049074, size: 0x8
class :: {
}

// class id: 2794, size: 0x20, field offset: 0x8
class KeyEventManager extends Object {

  _ KeyEventManager(/* No info */) {
    // ** addr: 0x8493d4, size: 0xf8
    // 0x8493d4: EnterFrame
    //     0x8493d4: stp             fp, lr, [SP, #-0x10]!
    //     0x8493d8: mov             fp, SP
    // 0x8493dc: AllocStack(0x18)
    //     0x8493dc: sub             SP, SP, #0x18
    // 0x8493e0: SetupParameters(KeyEventManager this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */, dynamic _ /* r3 => r0, fp-0x18 */)
    //     0x8493e0: mov             x4, x1
    //     0x8493e4: mov             x0, x3
    //     0x8493e8: stur            x3, [fp, #-0x18]
    //     0x8493ec: mov             x3, x2
    //     0x8493f0: stur            x1, [fp, #-8]
    //     0x8493f4: stur            x2, [fp, #-0x10]
    // 0x8493f8: CheckStackOverflow
    //     0x8493f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8493fc: cmp             SP, x16
    //     0x849400: b.ls            #0x8494c4
    // 0x849404: r1 = <KeyEvent>
    //     0x849404: ldr             x1, [PP, #0x3a98]  ; [pp+0x3a98] TypeArguments: <KeyEvent>
    // 0x849408: r2 = 0
    //     0x849408: mov             x2, #0
    // 0x84940c: r0 = _GrowableList()
    //     0x84940c: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x849410: ldur            x2, [fp, #-8]
    // 0x849414: ArrayStore: r2[0] = r0  ; List_4
    //     0x849414: stur            w0, [x2, #0x17]
    //     0x849418: ldurb           w16, [x2, #-1]
    //     0x84941c: ldurb           w17, [x0, #-1]
    //     0x849420: and             x16, x17, x16, lsr #2
    //     0x849424: tst             x16, HEAP, lsr #32
    //     0x849428: b.eq            #0x849430
    //     0x84942c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x849430: r1 = <PhysicalKeyboardKey>
    //     0x849430: ldr             x1, [PP, #0x3b40]  ; [pp+0x3b40] TypeArguments: <PhysicalKeyboardKey>
    // 0x849434: r0 = _Set()
    //     0x849434: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x849438: r1 = _Uint32List
    //     0x849438: ldr             x1, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0x84943c: StoreField: r0->field_1b = r1
    //     0x84943c: stur            w1, [x0, #0x1b]
    // 0x849440: StoreField: r0->field_b = rZR
    //     0x849440: stur            wzr, [x0, #0xb]
    // 0x849444: r1 = const []
    //     0x849444: ldr             x1, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0x849448: StoreField: r0->field_f = r1
    //     0x849448: stur            w1, [x0, #0xf]
    // 0x84944c: StoreField: r0->field_13 = rZR
    //     0x84944c: stur            wzr, [x0, #0x13]
    // 0x849450: ArrayStore: r0[0] = rZR  ; List_4
    //     0x849450: stur            wzr, [x0, #0x17]
    // 0x849454: ldur            x1, [fp, #-8]
    // 0x849458: StoreField: r1->field_1b = r0
    //     0x849458: stur            w0, [x1, #0x1b]
    //     0x84945c: ldurb           w16, [x1, #-1]
    //     0x849460: ldurb           w17, [x0, #-1]
    //     0x849464: and             x16, x17, x16, lsr #2
    //     0x849468: tst             x16, HEAP, lsr #32
    //     0x84946c: b.eq            #0x849474
    //     0x849470: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x849474: ldur            x0, [fp, #-0x10]
    // 0x849478: StoreField: r1->field_b = r0
    //     0x849478: stur            w0, [x1, #0xb]
    //     0x84947c: ldurb           w16, [x1, #-1]
    //     0x849480: ldurb           w17, [x0, #-1]
    //     0x849484: and             x16, x17, x16, lsr #2
    //     0x849488: tst             x16, HEAP, lsr #32
    //     0x84948c: b.eq            #0x849494
    //     0x849490: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x849494: ldur            x0, [fp, #-0x18]
    // 0x849498: StoreField: r1->field_f = r0
    //     0x849498: stur            w0, [x1, #0xf]
    //     0x84949c: ldurb           w16, [x1, #-1]
    //     0x8494a0: ldurb           w17, [x0, #-1]
    //     0x8494a4: and             x16, x17, x16, lsr #2
    //     0x8494a8: tst             x16, HEAP, lsr #32
    //     0x8494ac: b.eq            #0x8494b4
    //     0x8494b0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8494b4: r0 = Null
    //     0x8494b4: mov             x0, NULL
    // 0x8494b8: LeaveFrame
    //     0x8494b8: mov             SP, fp
    //     0x8494bc: ldp             fp, lr, [SP], #0x10
    // 0x8494c0: ret
    //     0x8494c0: ret             
    // 0x8494c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8494c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8494c8: b               #0x849404
  }
  _ handleKeyData(/* No info */) {
    // ** addr: 0x849b2c, size: 0x1b8
    // 0x849b2c: EnterFrame
    //     0x849b2c: stp             fp, lr, [SP, #-0x10]!
    //     0x849b30: mov             fp, SP
    // 0x849b34: AllocStack(0x20)
    //     0x849b34: sub             SP, SP, #0x20
    // 0x849b38: SetupParameters(KeyEventManager this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x849b38: mov             x0, x2
    //     0x849b3c: stur            x2, [fp, #-0x10]
    //     0x849b40: mov             x2, x1
    //     0x849b44: stur            x1, [fp, #-8]
    // 0x849b48: CheckStackOverflow
    //     0x849b48: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x849b4c: cmp             SP, x16
    //     0x849b50: b.ls            #0x849cdc
    // 0x849b54: LoadField: r1 = r2->field_13
    //     0x849b54: ldur            w1, [x2, #0x13]
    // 0x849b58: DecompressPointer r1
    //     0x849b58: add             x1, x1, HEAP, lsl #32
    // 0x849b5c: cmp             w1, NULL
    // 0x849b60: b.ne            #0x849b70
    // 0x849b64: r1 = Instance_KeyDataTransitMode
    //     0x849b64: ldr             x1, [PP, #0x40d0]  ; [pp+0x40d0] Obj!KeyDataTransitMode@12c3de1
    // 0x849b68: StoreField: r2->field_13 = r1
    //     0x849b68: stur            w1, [x2, #0x13]
    // 0x849b6c: r1 = Instance_KeyDataTransitMode
    //     0x849b6c: ldr             x1, [PP, #0x40d0]  ; [pp+0x40d0] Obj!KeyDataTransitMode@12c3de1
    // 0x849b70: LoadField: r3 = r1->field_7
    //     0x849b70: ldur            x3, [x1, #7]
    // 0x849b74: cmp             x3, #0
    // 0x849b78: b.gt            #0x849b8c
    // 0x849b7c: r0 = false
    //     0x849b7c: add             x0, NULL, #0x30  ; false
    // 0x849b80: LeaveFrame
    //     0x849b80: mov             SP, fp
    //     0x849b84: ldp             fp, lr, [SP], #0x10
    // 0x849b88: ret
    //     0x849b88: ret             
    // 0x849b8c: LoadField: r1 = r0->field_13
    //     0x849b8c: ldur            x1, [x0, #0x13]
    // 0x849b90: cbnz            x1, #0x849bac
    // 0x849b94: LoadField: r1 = r0->field_1b
    //     0x849b94: ldur            x1, [x0, #0x1b]
    // 0x849b98: cbnz            x1, #0x849bac
    // 0x849b9c: r0 = false
    //     0x849b9c: add             x0, NULL, #0x30  ; false
    // 0x849ba0: LeaveFrame
    //     0x849ba0: mov             SP, fp
    //     0x849ba4: ldp             fp, lr, [SP], #0x10
    // 0x849ba8: ret
    //     0x849ba8: ret             
    // 0x849bac: mov             x1, x0
    // 0x849bb0: r0 = _eventFromData()
    //     0x849bb0: bl              #0x84a2fc  ; [package:flutter/src/services/hardware_keyboard.dart] KeyEventManager::_eventFromData
    // 0x849bb4: mov             x3, x0
    // 0x849bb8: ldur            x0, [fp, #-0x10]
    // 0x849bbc: stur            x3, [fp, #-0x18]
    // 0x849bc0: LoadField: r1 = r0->field_27
    //     0x849bc0: ldur            w1, [x0, #0x27]
    // 0x849bc4: DecompressPointer r1
    //     0x849bc4: add             x1, x1, HEAP, lsl #32
    // 0x849bc8: tbnz            w1, #4, #0x849c44
    // 0x849bcc: ldur            x0, [fp, #-8]
    // 0x849bd0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x849bd0: ldur            w1, [x0, #0x17]
    // 0x849bd4: DecompressPointer r1
    //     0x849bd4: add             x1, x1, HEAP, lsl #32
    // 0x849bd8: LoadField: r2 = r1->field_b
    //     0x849bd8: ldur            w2, [x1, #0xb]
    // 0x849bdc: cbnz            w2, #0x849c3c
    // 0x849be0: LoadField: r1 = r0->field_b
    //     0x849be0: ldur            w1, [x0, #0xb]
    // 0x849be4: DecompressPointer r1
    //     0x849be4: add             x1, x1, HEAP, lsl #32
    // 0x849be8: mov             x2, x3
    // 0x849bec: r0 = handleKeyEvent()
    //     0x849bec: bl              #0x849de8  ; [package:flutter/src/services/hardware_keyboard.dart] HardwareKeyboard::handleKeyEvent
    // 0x849bf0: r1 = Null
    //     0x849bf0: mov             x1, NULL
    // 0x849bf4: r2 = 2
    //     0x849bf4: mov             x2, #2
    // 0x849bf8: r0 = AllocateArray()
    //     0x849bf8: bl              #0x13df928  ; AllocateArrayStub
    // 0x849bfc: mov             x2, x0
    // 0x849c00: ldur            x0, [fp, #-0x18]
    // 0x849c04: stur            x2, [fp, #-0x10]
    // 0x849c08: StoreField: r2->field_f = r0
    //     0x849c08: stur            w0, [x2, #0xf]
    // 0x849c0c: r1 = <KeyEvent>
    //     0x849c0c: ldr             x1, [PP, #0x3a98]  ; [pp+0x3a98] TypeArguments: <KeyEvent>
    // 0x849c10: r0 = AllocateGrowableArray()
    //     0x849c10: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x849c14: mov             x1, x0
    // 0x849c18: ldur            x0, [fp, #-0x10]
    // 0x849c1c: StoreField: r1->field_f = r0
    //     0x849c1c: stur            w0, [x1, #0xf]
    // 0x849c20: r0 = 2
    //     0x849c20: mov             x0, #2
    // 0x849c24: StoreField: r1->field_b = r0
    //     0x849c24: stur            w0, [x1, #0xb]
    // 0x849c28: mov             x2, x1
    // 0x849c2c: ldur            x1, [fp, #-8]
    // 0x849c30: r3 = Null
    //     0x849c30: mov             x3, NULL
    // 0x849c34: r0 = _dispatchKeyMessage()
    //     0x849c34: bl              #0x849ce4  ; [package:flutter/src/services/hardware_keyboard.dart] KeyEventManager::_dispatchKeyMessage
    // 0x849c38: b               #0x849ccc
    // 0x849c3c: mov             x0, x3
    // 0x849c40: b               #0x849c48
    // 0x849c44: mov             x0, x3
    // 0x849c48: ldur            x1, [fp, #-8]
    // 0x849c4c: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x849c4c: ldur            w2, [x1, #0x17]
    // 0x849c50: DecompressPointer r2
    //     0x849c50: add             x2, x2, HEAP, lsl #32
    // 0x849c54: stur            x2, [fp, #-0x10]
    // 0x849c58: LoadField: r1 = r2->field_b
    //     0x849c58: ldur            w1, [x2, #0xb]
    // 0x849c5c: LoadField: r3 = r2->field_f
    //     0x849c5c: ldur            w3, [x2, #0xf]
    // 0x849c60: DecompressPointer r3
    //     0x849c60: add             x3, x3, HEAP, lsl #32
    // 0x849c64: LoadField: r4 = r3->field_b
    //     0x849c64: ldur            w4, [x3, #0xb]
    // 0x849c68: r3 = LoadInt32Instr(r1)
    //     0x849c68: sbfx            x3, x1, #1, #0x1f
    // 0x849c6c: stur            x3, [fp, #-0x20]
    // 0x849c70: r1 = LoadInt32Instr(r4)
    //     0x849c70: sbfx            x1, x4, #1, #0x1f
    // 0x849c74: cmp             x3, x1
    // 0x849c78: b.ne            #0x849c84
    // 0x849c7c: mov             x1, x2
    // 0x849c80: r0 = _growToNextCapacity()
    //     0x849c80: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x849c84: ldur            x2, [fp, #-0x10]
    // 0x849c88: ldur            x3, [fp, #-0x20]
    // 0x849c8c: add             x4, x3, #1
    // 0x849c90: lsl             x5, x4, #1
    // 0x849c94: StoreField: r2->field_b = r5
    //     0x849c94: stur            w5, [x2, #0xb]
    // 0x849c98: LoadField: r1 = r2->field_f
    //     0x849c98: ldur            w1, [x2, #0xf]
    // 0x849c9c: DecompressPointer r1
    //     0x849c9c: add             x1, x1, HEAP, lsl #32
    // 0x849ca0: ldur            x0, [fp, #-0x18]
    // 0x849ca4: ArrayStore: r1[r3] = r0  ; List_4
    //     0x849ca4: add             x25, x1, x3, lsl #2
    //     0x849ca8: add             x25, x25, #0xf
    //     0x849cac: str             w0, [x25]
    //     0x849cb0: tbz             w0, #0, #0x849ccc
    //     0x849cb4: ldurb           w16, [x1, #-1]
    //     0x849cb8: ldurb           w17, [x0, #-1]
    //     0x849cbc: and             x16, x17, x16, lsr #2
    //     0x849cc0: tst             x16, HEAP, lsr #32
    //     0x849cc4: b.eq            #0x849ccc
    //     0x849cc8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x849ccc: r0 = false
    //     0x849ccc: add             x0, NULL, #0x30  ; false
    // 0x849cd0: LeaveFrame
    //     0x849cd0: mov             SP, fp
    //     0x849cd4: ldp             fp, lr, [SP], #0x10
    // 0x849cd8: ret
    //     0x849cd8: ret             
    // 0x849cdc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x849cdc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x849ce0: b               #0x849b54
  }
  _ _dispatchKeyMessage(/* No info */) {
    // ** addr: 0x849ce4, size: 0xf8
    // 0x849ce4: EnterFrame
    //     0x849ce4: stp             fp, lr, [SP, #-0x10]!
    //     0x849ce8: mov             fp, SP
    // 0x849cec: AllocStack(0x80)
    //     0x849cec: sub             SP, SP, #0x80
    // 0x849cf0: SetupParameters(KeyEventManager this /* r1 => r1, fp-0x68 */, dynamic _ /* r2 => r2, fp-0x70 */, dynamic _ /* r3 => r3, fp-0x78 */)
    //     0x849cf0: stur            x1, [fp, #-0x68]
    //     0x849cf4: stur            x2, [fp, #-0x70]
    //     0x849cf8: stur            x3, [fp, #-0x78]
    // 0x849cfc: CheckStackOverflow
    //     0x849cfc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x849d00: cmp             SP, x16
    //     0x849d04: b.ls            #0x849dd4
    // 0x849d08: LoadField: r0 = r1->field_7
    //     0x849d08: ldur            w0, [x1, #7]
    // 0x849d0c: DecompressPointer r0
    //     0x849d0c: add             x0, x0, HEAP, lsl #32
    // 0x849d10: stur            x0, [fp, #-0x60]
    // 0x849d14: cmp             w0, NULL
    // 0x849d18: b.eq            #0x849dc4
    // 0x849d1c: r0 = KeyMessage()
    //     0x849d1c: bl              #0x849ddc  ; AllocateKeyMessageStub -> KeyMessage (size=0x10)
    // 0x849d20: mov             x3, x0
    // 0x849d24: ldur            x0, [fp, #-0x70]
    // 0x849d28: stur            x3, [fp, #-0x80]
    // 0x849d2c: StoreField: r3->field_7 = r0
    //     0x849d2c: stur            w0, [x3, #7]
    // 0x849d30: ldur            x0, [fp, #-0x78]
    // 0x849d34: StoreField: r3->field_b = r0
    //     0x849d34: stur            w0, [x3, #0xb]
    // 0x849d38: ldur            x0, [fp, #-0x60]
    // 0x849d3c: ArrayLoad: r4 = r0[0]  ; List_4
    //     0x849d3c: ldur            w4, [x0, #0x17]
    // 0x849d40: DecompressPointer r4
    //     0x849d40: add             x4, x4, HEAP, lsl #32
    // 0x849d44: mov             x1, x4
    // 0x849d48: mov             x2, x3
    // 0x849d4c: stur            x4, [fp, #-0x70]
    // 0x849d50: r0 = handleKeyMessage()
    //     0x849d50: bl              #0x83bea8  ; [package:flutter/src/widgets/focus_manager.dart] _HighlightModeManager::handleKeyMessage
    // 0x849d54: LeaveFrame
    //     0x849d54: mov             SP, fp
    //     0x849d58: ldp             fp, lr, [SP], #0x10
    // 0x849d5c: ret
    //     0x849d5c: ret             
    // 0x849d60: sub             SP, fp, #0x80
    // 0x849d64: mov             x2, x0
    // 0x849d68: stur            x0, [fp, #-0x60]
    // 0x849d6c: mov             x0, x1
    // 0x849d70: stur            x1, [fp, #-0x68]
    // 0x849d74: r1 = <List<Object>>
    //     0x849d74: ldr             x1, [PP, #0x860]  ; [pp+0x860] TypeArguments: <List<Object>>
    // 0x849d78: r0 = ErrorDescription()
    //     0x849d78: bl              #0x829ca4  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x2c)
    // 0x849d7c: mov             x1, x0
    // 0x849d80: r2 = "while processing the key message handler"
    //     0x849d80: ldr             x2, [PP, #0x3ad0]  ; [pp+0x3ad0] "while processing the key message handler"
    // 0x849d84: r3 = Instance_DiagnosticLevel
    //     0x849d84: ldr             x3, [PP, #0x868]  ; [pp+0x868] Obj!DiagnosticLevel@12c5f41
    // 0x849d88: stur            x0, [fp, #-0x70]
    // 0x849d8c: r0 = _ErrorDiagnostic()
    //     0x849d8c: bl              #0x829bec  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0x849d90: r0 = FlutterErrorDetails()
    //     0x849d90: bl              #0x829be0  ; AllocateFlutterErrorDetailsStub -> FlutterErrorDetails (size=0x20)
    // 0x849d94: mov             x1, x0
    // 0x849d98: ldur            x0, [fp, #-0x60]
    // 0x849d9c: StoreField: r1->field_7 = r0
    //     0x849d9c: stur            w0, [x1, #7]
    // 0x849da0: ldur            x0, [fp, #-0x68]
    // 0x849da4: StoreField: r1->field_b = r0
    //     0x849da4: stur            w0, [x1, #0xb]
    // 0x849da8: r0 = "services library"
    //     0x849da8: ldr             x0, [PP, #0x870]  ; [pp+0x870] "services library"
    // 0x849dac: StoreField: r1->field_f = r0
    //     0x849dac: stur            w0, [x1, #0xf]
    // 0x849db0: ldur            x0, [fp, #-0x70]
    // 0x849db4: StoreField: r1->field_13 = r0
    //     0x849db4: stur            w0, [x1, #0x13]
    // 0x849db8: r0 = false
    //     0x849db8: add             x0, NULL, #0x30  ; false
    // 0x849dbc: StoreField: r1->field_1b = r0
    //     0x849dbc: stur            w0, [x1, #0x1b]
    // 0x849dc0: r0 = reportError()
    //     0x849dc0: bl              #0x829a24  ; [package:flutter/src/foundation/assertions.dart] FlutterError::reportError
    // 0x849dc4: r0 = false
    //     0x849dc4: add             x0, NULL, #0x30  ; false
    // 0x849dc8: LeaveFrame
    //     0x849dc8: mov             SP, fp
    //     0x849dcc: ldp             fp, lr, [SP], #0x10
    // 0x849dd0: ret
    //     0x849dd0: ret             
    // 0x849dd4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x849dd4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x849dd8: b               #0x849d08
  }
  static _ _eventFromData(/* No info */) {
    // ** addr: 0x84a2fc, size: 0x144
    // 0x84a2fc: EnterFrame
    //     0x84a2fc: stp             fp, lr, [SP, #-0x10]!
    //     0x84a300: mov             fp, SP
    // 0x84a304: AllocStack(0x20)
    //     0x84a304: sub             SP, SP, #0x20
    // 0x84a308: SetupParameters(dynamic _ /* r1 => r0, fp-0x10 */)
    //     0x84a308: mov             x0, x1
    //     0x84a30c: stur            x1, [fp, #-0x10]
    // 0x84a310: CheckStackOverflow
    //     0x84a310: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84a314: cmp             SP, x16
    //     0x84a318: b.ls            #0x84a438
    // 0x84a31c: LoadField: r2 = r0->field_13
    //     0x84a31c: ldur            x2, [x0, #0x13]
    // 0x84a320: mov             x1, x2
    // 0x84a324: stur            x2, [fp, #-8]
    // 0x84a328: r0 = findKeyByCode()
    //     0x84a328: bl              #0x84a4b0  ; [package:flutter/src/services/keyboard_key.g.dart] PhysicalKeyboardKey::findKeyByCode
    // 0x84a32c: cmp             w0, NULL
    // 0x84a330: b.ne            #0x84a350
    // 0x84a334: ldur            x0, [fp, #-8]
    // 0x84a338: r0 = PhysicalKeyboardKey()
    //     0x84a338: bl              #0x8492a4  ; AllocatePhysicalKeyboardKeyStub -> PhysicalKeyboardKey (size=0x10)
    // 0x84a33c: mov             x1, x0
    // 0x84a340: ldur            x0, [fp, #-8]
    // 0x84a344: StoreField: r1->field_7 = r0
    //     0x84a344: stur            x0, [x1, #7]
    // 0x84a348: mov             x2, x1
    // 0x84a34c: b               #0x84a354
    // 0x84a350: mov             x2, x0
    // 0x84a354: ldur            x0, [fp, #-0x10]
    // 0x84a358: stur            x2, [fp, #-0x18]
    // 0x84a35c: LoadField: r3 = r0->field_1b
    //     0x84a35c: ldur            x3, [x0, #0x1b]
    // 0x84a360: mov             x1, x3
    // 0x84a364: stur            x3, [fp, #-8]
    // 0x84a368: r0 = findKeyByKeyId()
    //     0x84a368: bl              #0x84a464  ; [package:flutter/src/services/keyboard_key.g.dart] LogicalKeyboardKey::findKeyByKeyId
    // 0x84a36c: cmp             w0, NULL
    // 0x84a370: b.ne            #0x84a38c
    // 0x84a374: ldur            x0, [fp, #-8]
    // 0x84a378: r0 = LogicalKeyboardKey()
    //     0x84a378: bl              #0x849274  ; AllocateLogicalKeyboardKeyStub -> LogicalKeyboardKey (size=0x10)
    // 0x84a37c: mov             x1, x0
    // 0x84a380: ldur            x0, [fp, #-8]
    // 0x84a384: StoreField: r1->field_7 = r0
    //     0x84a384: stur            x0, [x1, #7]
    // 0x84a388: b               #0x84a390
    // 0x84a38c: mov             x1, x0
    // 0x84a390: ldur            x0, [fp, #-0x10]
    // 0x84a394: stur            x1, [fp, #-0x20]
    // 0x84a398: LoadField: r2 = r0->field_b
    //     0x84a398: ldur            w2, [x0, #0xb]
    // 0x84a39c: DecompressPointer r2
    //     0x84a39c: add             x2, x2, HEAP, lsl #32
    // 0x84a3a0: LoadField: r0 = r2->field_7
    //     0x84a3a0: ldur            x0, [x2, #7]
    // 0x84a3a4: cmp             x0, #1
    // 0x84a3a8: b.gt            #0x84a410
    // 0x84a3ac: cmp             x0, #0
    // 0x84a3b0: b.gt            #0x84a3e0
    // 0x84a3b4: ldur            x0, [fp, #-0x18]
    // 0x84a3b8: r0 = KeyDownEvent()
    //     0x84a3b8: bl              #0x84a458  ; AllocateKeyDownEventStub -> KeyDownEvent (size=0x10)
    // 0x84a3bc: mov             x1, x0
    // 0x84a3c0: ldur            x0, [fp, #-0x18]
    // 0x84a3c4: StoreField: r1->field_7 = r0
    //     0x84a3c4: stur            w0, [x1, #7]
    // 0x84a3c8: ldur            x2, [fp, #-0x20]
    // 0x84a3cc: StoreField: r1->field_b = r2
    //     0x84a3cc: stur            w2, [x1, #0xb]
    // 0x84a3d0: mov             x0, x1
    // 0x84a3d4: LeaveFrame
    //     0x84a3d4: mov             SP, fp
    //     0x84a3d8: ldp             fp, lr, [SP], #0x10
    // 0x84a3dc: ret
    //     0x84a3dc: ret             
    // 0x84a3e0: ldur            x0, [fp, #-0x18]
    // 0x84a3e4: mov             x2, x1
    // 0x84a3e8: r0 = KeyUpEvent()
    //     0x84a3e8: bl              #0x84a44c  ; AllocateKeyUpEventStub -> KeyUpEvent (size=0x10)
    // 0x84a3ec: mov             x1, x0
    // 0x84a3f0: ldur            x0, [fp, #-0x18]
    // 0x84a3f4: StoreField: r1->field_7 = r0
    //     0x84a3f4: stur            w0, [x1, #7]
    // 0x84a3f8: ldur            x2, [fp, #-0x20]
    // 0x84a3fc: StoreField: r1->field_b = r2
    //     0x84a3fc: stur            w2, [x1, #0xb]
    // 0x84a400: mov             x0, x1
    // 0x84a404: LeaveFrame
    //     0x84a404: mov             SP, fp
    //     0x84a408: ldp             fp, lr, [SP], #0x10
    // 0x84a40c: ret
    //     0x84a40c: ret             
    // 0x84a410: ldur            x0, [fp, #-0x18]
    // 0x84a414: mov             x2, x1
    // 0x84a418: r0 = KeyRepeatEvent()
    //     0x84a418: bl              #0x84a440  ; AllocateKeyRepeatEventStub -> KeyRepeatEvent (size=0x10)
    // 0x84a41c: ldur            x1, [fp, #-0x18]
    // 0x84a420: StoreField: r0->field_7 = r1
    //     0x84a420: stur            w1, [x0, #7]
    // 0x84a424: ldur            x1, [fp, #-0x20]
    // 0x84a428: StoreField: r0->field_b = r1
    //     0x84a428: stur            w1, [x0, #0xb]
    // 0x84a42c: LeaveFrame
    //     0x84a42c: mov             SP, fp
    //     0x84a430: ldp             fp, lr, [SP], #0x10
    // 0x84a434: ret
    //     0x84a434: ret             
    // 0x84a438: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84a438: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84a43c: b               #0x84a31c
  }
  [closure] Future<Map<String, dynamic>> handleRawKeyMessage(dynamic, dynamic) {
    // ** addr: 0x84a4fc, size: 0x3c
    // 0x84a4fc: EnterFrame
    //     0x84a4fc: stp             fp, lr, [SP, #-0x10]!
    //     0x84a500: mov             fp, SP
    // 0x84a504: ldr             x0, [fp, #0x18]
    // 0x84a508: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x84a508: ldur            w1, [x0, #0x17]
    // 0x84a50c: DecompressPointer r1
    //     0x84a50c: add             x1, x1, HEAP, lsl #32
    // 0x84a510: CheckStackOverflow
    //     0x84a510: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84a514: cmp             SP, x16
    //     0x84a518: b.ls            #0x84a530
    // 0x84a51c: ldr             x2, [fp, #0x10]
    // 0x84a520: r0 = handleRawKeyMessage()
    //     0x84a520: bl              #0x84a538  ; [package:flutter/src/services/hardware_keyboard.dart] KeyEventManager::handleRawKeyMessage
    // 0x84a524: LeaveFrame
    //     0x84a524: mov             SP, fp
    //     0x84a528: ldp             fp, lr, [SP], #0x10
    // 0x84a52c: ret
    //     0x84a52c: ret             
    // 0x84a530: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84a530: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84a534: b               #0x84a51c
  }
  _ handleRawKeyMessage(/* No info */) async {
    // ** addr: 0x84a538, size: 0x3c4
    // 0x84a538: EnterFrame
    //     0x84a538: stp             fp, lr, [SP, #-0x10]!
    //     0x84a53c: mov             fp, SP
    // 0x84a540: AllocStack(0x50)
    //     0x84a540: sub             SP, SP, #0x50
    // 0x84a544: SetupParameters(KeyEventManager this /* r1 => r2, fp-0x10 */, dynamic _ /* r2 => r1, fp-0x18 */)
    //     0x84a544: stur            NULL, [fp, #-8]
    //     0x84a548: stur            x1, [fp, #-0x10]
    //     0x84a54c: mov             x16, x2
    //     0x84a550: mov             x2, x1
    //     0x84a554: mov             x1, x16
    //     0x84a558: stur            x1, [fp, #-0x18]
    // 0x84a55c: CheckStackOverflow
    //     0x84a55c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84a560: cmp             SP, x16
    //     0x84a564: b.ls            #0x84a8ec
    // 0x84a568: InitAsync() -> Future<Map<String, dynamic>>
    //     0x84a568: ldr             x0, [PP, #0xb0]  ; [pp+0xb0] TypeArguments: <Map<String, dynamic>>
    //     0x84a56c: bl              #0x7f5e44  ; InitAsyncStub
    // 0x84a570: ldur            x0, [fp, #-0x10]
    // 0x84a574: LoadField: r1 = r0->field_13
    //     0x84a574: ldur            w1, [x0, #0x13]
    // 0x84a578: DecompressPointer r1
    //     0x84a578: add             x1, x1, HEAP, lsl #32
    // 0x84a57c: cmp             w1, NULL
    // 0x84a580: b.ne            #0x84a660
    // 0x84a584: r1 = Instance_KeyDataTransitMode
    //     0x84a584: ldr             x1, [PP, #0x3a60]  ; [pp+0x3a60] Obj!KeyDataTransitMode@12c3e01
    // 0x84a588: StoreField: r0->field_13 = r1
    //     0x84a588: stur            w1, [x0, #0x13]
    // 0x84a58c: LoadField: r1 = r0->field_f
    //     0x84a58c: ldur            w1, [x0, #0xf]
    // 0x84a590: DecompressPointer r1
    //     0x84a590: add             x1, x1, HEAP, lsl #32
    // 0x84a594: LoadField: r3 = r1->field_7
    //     0x84a594: ldur            w3, [x1, #7]
    // 0x84a598: DecompressPointer r3
    //     0x84a598: add             x3, x3, HEAP, lsl #32
    // 0x84a59c: stur            x3, [fp, #-0x28]
    // 0x84a5a0: LoadField: r4 = r3->field_7
    //     0x84a5a0: ldur            w4, [x3, #7]
    // 0x84a5a4: DecompressPointer r4
    //     0x84a5a4: add             x4, x4, HEAP, lsl #32
    // 0x84a5a8: mov             x2, x0
    // 0x84a5ac: stur            x4, [fp, #-0x20]
    // 0x84a5b0: r1 = Function '_convertRawEventAndStore@167443624':.
    //     0x84a5b0: ldr             x1, [PP, #0x3a68]  ; [pp+0x3a68] AnonymousClosure: (0x84f12c), in [package:flutter/src/services/hardware_keyboard.dart] KeyEventManager::_convertRawEventAndStore (0x84f168)
    // 0x84a5b4: r0 = AllocateClosure()
    //     0x84a5b4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x84a5b8: ldur            x2, [fp, #-0x20]
    // 0x84a5bc: mov             x3, x0
    // 0x84a5c0: r1 = Null
    //     0x84a5c0: mov             x1, NULL
    // 0x84a5c4: stur            x3, [fp, #-0x20]
    // 0x84a5c8: cmp             w2, NULL
    // 0x84a5cc: b.eq            #0x84a5e8
    // 0x84a5d0: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x84a5d0: ldur            w4, [x2, #0x17]
    // 0x84a5d4: DecompressPointer r4
    //     0x84a5d4: add             x4, x4, HEAP, lsl #32
    // 0x84a5d8: r8 = X0
    //     0x84a5d8: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x84a5dc: LoadField: r9 = r4->field_7
    //     0x84a5dc: ldur            x9, [x4, #7]
    // 0x84a5e0: r3 = Null
    //     0x84a5e0: ldr             x3, [PP, #0x3a70]  ; [pp+0x3a70] Null
    // 0x84a5e4: blr             x9
    // 0x84a5e8: ldur            x0, [fp, #-0x28]
    // 0x84a5ec: LoadField: r1 = r0->field_b
    //     0x84a5ec: ldur            w1, [x0, #0xb]
    // 0x84a5f0: LoadField: r2 = r0->field_f
    //     0x84a5f0: ldur            w2, [x0, #0xf]
    // 0x84a5f4: DecompressPointer r2
    //     0x84a5f4: add             x2, x2, HEAP, lsl #32
    // 0x84a5f8: LoadField: r3 = r2->field_b
    //     0x84a5f8: ldur            w3, [x2, #0xb]
    // 0x84a5fc: r2 = LoadInt32Instr(r1)
    //     0x84a5fc: sbfx            x2, x1, #1, #0x1f
    // 0x84a600: stur            x2, [fp, #-0x30]
    // 0x84a604: r1 = LoadInt32Instr(r3)
    //     0x84a604: sbfx            x1, x3, #1, #0x1f
    // 0x84a608: cmp             x2, x1
    // 0x84a60c: b.ne            #0x84a618
    // 0x84a610: mov             x1, x0
    // 0x84a614: r0 = _growToNextCapacity()
    //     0x84a614: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x84a618: ldur            x0, [fp, #-0x28]
    // 0x84a61c: ldur            x2, [fp, #-0x30]
    // 0x84a620: add             x1, x2, #1
    // 0x84a624: lsl             x3, x1, #1
    // 0x84a628: StoreField: r0->field_b = r3
    //     0x84a628: stur            w3, [x0, #0xb]
    // 0x84a62c: LoadField: r1 = r0->field_f
    //     0x84a62c: ldur            w1, [x0, #0xf]
    // 0x84a630: DecompressPointer r1
    //     0x84a630: add             x1, x1, HEAP, lsl #32
    // 0x84a634: ldur            x0, [fp, #-0x20]
    // 0x84a638: ArrayStore: r1[r2] = r0  ; List_4
    //     0x84a638: add             x25, x1, x2, lsl #2
    //     0x84a63c: add             x25, x25, #0xf
    //     0x84a640: str             w0, [x25]
    //     0x84a644: tbz             w0, #0, #0x84a660
    //     0x84a648: ldurb           w16, [x1, #-1]
    //     0x84a64c: ldurb           w17, [x0, #-1]
    //     0x84a650: and             x16, x17, x16, lsr #2
    //     0x84a654: tst             x16, HEAP, lsr #32
    //     0x84a658: b.eq            #0x84a660
    //     0x84a65c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x84a660: ldur            x0, [fp, #-0x18]
    // 0x84a664: r2 = Null
    //     0x84a664: mov             x2, NULL
    // 0x84a668: r1 = Null
    //     0x84a668: mov             x1, NULL
    // 0x84a66c: r8 = Map<String, dynamic>
    //     0x84a66c: ldr             x8, [PP, #0x3298]  ; [pp+0x3298] Type: Map<String, dynamic>
    // 0x84a670: r3 = Null
    //     0x84a670: ldr             x3, [PP, #0x3a80]  ; [pp+0x3a80] Null
    // 0x84a674: r0 = Map<String, dynamic>()
    //     0x84a674: bl              #0x84f9a4  ; IsType_Map<String, dynamic>_Stub
    // 0x84a678: ldur            x2, [fp, #-0x18]
    // 0x84a67c: r1 = Null
    //     0x84a67c: mov             x1, NULL
    // 0x84a680: r0 = RawKeyEvent.fromMessage()
    //     0x84a680: bl              #0x84d364  ; [package:flutter/src/services/raw_keyboard.dart] RawKeyEvent::RawKeyEvent.fromMessage
    // 0x84a684: mov             x2, x0
    // 0x84a688: stur            x2, [fp, #-0x20]
    // 0x84a68c: r0 = LoadClassIdInstr(r2)
    //     0x84a68c: ldur            x0, [x2, #-1]
    //     0x84a690: ubfx            x0, x0, #0xc, #0x14
    // 0x84a694: r17 = 5017
    //     0x84a694: mov             x17, #0x1399
    // 0x84a698: cmp             x0, x17
    // 0x84a69c: b.ne            #0x84a744
    // 0x84a6a0: LoadField: r3 = r2->field_b
    //     0x84a6a0: ldur            w3, [x2, #0xb]
    // 0x84a6a4: DecompressPointer r3
    //     0x84a6a4: add             x3, x3, HEAP, lsl #32
    // 0x84a6a8: stur            x3, [fp, #-0x18]
    // 0x84a6ac: r0 = LoadClassIdInstr(r3)
    //     0x84a6ac: ldur            x0, [x3, #-1]
    //     0x84a6b0: ubfx            x0, x0, #0xc, #0x14
    // 0x84a6b4: mov             x1, x3
    // 0x84a6b8: r0 = GDT[cid_x0 + 0x77e9]()
    //     0x84a6b8: mov             x17, #0x77e9
    //     0x84a6bc: add             lr, x0, x17
    //     0x84a6c0: ldr             lr, [x21, lr, lsl #3]
    //     0x84a6c4: blr             lr
    // 0x84a6c8: tbz             w0, #4, #0x84a708
    // 0x84a6cc: ldur            x2, [fp, #-0x10]
    // 0x84a6d0: ldur            x1, [fp, #-0x18]
    // 0x84a6d4: LoadField: r3 = r2->field_1b
    //     0x84a6d4: ldur            w3, [x2, #0x1b]
    // 0x84a6d8: DecompressPointer r3
    //     0x84a6d8: add             x3, x3, HEAP, lsl #32
    // 0x84a6dc: stur            x3, [fp, #-0x28]
    // 0x84a6e0: r0 = LoadClassIdInstr(r1)
    //     0x84a6e0: ldur            x0, [x1, #-1]
    //     0x84a6e4: ubfx            x0, x0, #0xc, #0x14
    // 0x84a6e8: r0 = GDT[cid_x0 + 0x6c3b]()
    //     0x84a6e8: mov             x17, #0x6c3b
    //     0x84a6ec: add             lr, x0, x17
    //     0x84a6f0: ldr             lr, [x21, lr, lsl #3]
    //     0x84a6f4: blr             lr
    // 0x84a6f8: ldur            x1, [fp, #-0x28]
    // 0x84a6fc: mov             x2, x0
    // 0x84a700: r0 = add()
    //     0x84a700: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x84a704: b               #0x84a7a8
    // 0x84a708: ldur            x2, [fp, #-0x10]
    // 0x84a70c: ldur            x1, [fp, #-0x18]
    // 0x84a710: LoadField: r3 = r2->field_1b
    //     0x84a710: ldur            w3, [x2, #0x1b]
    // 0x84a714: DecompressPointer r3
    //     0x84a714: add             x3, x3, HEAP, lsl #32
    // 0x84a718: stur            x3, [fp, #-0x28]
    // 0x84a71c: r0 = LoadClassIdInstr(r1)
    //     0x84a71c: ldur            x0, [x1, #-1]
    //     0x84a720: ubfx            x0, x0, #0xc, #0x14
    // 0x84a724: r0 = GDT[cid_x0 + 0x6c3b]()
    //     0x84a724: mov             x17, #0x6c3b
    //     0x84a728: add             lr, x0, x17
    //     0x84a72c: ldr             lr, [x21, lr, lsl #3]
    //     0x84a730: blr             lr
    // 0x84a734: ldur            x1, [fp, #-0x28]
    // 0x84a738: mov             x2, x0
    // 0x84a73c: r0 = remove()
    //     0x84a73c: bl              #0x115bfd0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::remove
    // 0x84a740: b               #0x84a7b0
    // 0x84a744: r17 = 5016
    //     0x84a744: mov             x17, #0x1398
    // 0x84a748: cmp             x0, x17
    // 0x84a74c: b.ne            #0x84a7b0
    // 0x84a750: ldur            x2, [fp, #-0x10]
    // 0x84a754: ldur            x3, [fp, #-0x20]
    // 0x84a758: LoadField: r4 = r2->field_1b
    //     0x84a758: ldur            w4, [x2, #0x1b]
    // 0x84a75c: DecompressPointer r4
    //     0x84a75c: add             x4, x4, HEAP, lsl #32
    // 0x84a760: stur            x4, [fp, #-0x18]
    // 0x84a764: LoadField: r1 = r3->field_b
    //     0x84a764: ldur            w1, [x3, #0xb]
    // 0x84a768: DecompressPointer r1
    //     0x84a768: add             x1, x1, HEAP, lsl #32
    // 0x84a76c: r0 = LoadClassIdInstr(r1)
    //     0x84a76c: ldur            x0, [x1, #-1]
    //     0x84a770: ubfx            x0, x0, #0xc, #0x14
    // 0x84a774: r0 = GDT[cid_x0 + 0x6c3b]()
    //     0x84a774: mov             x17, #0x6c3b
    //     0x84a778: add             lr, x0, x17
    //     0x84a77c: ldr             lr, [x21, lr, lsl #3]
    //     0x84a780: blr             lr
    // 0x84a784: ldur            x1, [fp, #-0x18]
    // 0x84a788: mov             x2, x0
    // 0x84a78c: r0 = contains()
    //     0x84a78c: bl              #0xbafbf4  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x84a790: tbnz            w0, #4, #0x84a7b0
    // 0x84a794: ldur            x1, [fp, #-0x20]
    // 0x84a798: r0 = physicalKey()
    //     0x84a798: bl              #0x84d310  ; [package:flutter/src/services/raw_keyboard.dart] RawKeyEvent::physicalKey
    // 0x84a79c: ldur            x1, [fp, #-0x18]
    // 0x84a7a0: mov             x2, x0
    // 0x84a7a4: r0 = remove()
    //     0x84a7a4: bl              #0x115bfd0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::remove
    // 0x84a7a8: r0 = true
    //     0x84a7a8: add             x0, NULL, #0x20  ; true
    // 0x84a7ac: b               #0x84a89c
    // 0x84a7b0: ldur            x0, [fp, #-0x10]
    // 0x84a7b4: LoadField: r1 = r0->field_f
    //     0x84a7b4: ldur            w1, [x0, #0xf]
    // 0x84a7b8: DecompressPointer r1
    //     0x84a7b8: add             x1, x1, HEAP, lsl #32
    // 0x84a7bc: ldur            x2, [fp, #-0x20]
    // 0x84a7c0: r0 = handleRawKeyEvent()
    //     0x84a7c0: bl              #0x84a8fc  ; [package:flutter/src/services/raw_keyboard.dart] RawKeyboard::handleRawKeyEvent
    // 0x84a7c4: ldur            x0, [fp, #-0x10]
    // 0x84a7c8: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x84a7c8: ldur            w3, [x0, #0x17]
    // 0x84a7cc: DecompressPointer r3
    //     0x84a7cc: add             x3, x3, HEAP, lsl #32
    // 0x84a7d0: stur            x3, [fp, #-0x40]
    // 0x84a7d4: LoadField: r1 = r3->field_b
    //     0x84a7d4: ldur            w1, [x3, #0xb]
    // 0x84a7d8: r4 = LoadInt32Instr(r1)
    //     0x84a7d8: sbfx            x4, x1, #1, #0x1f
    // 0x84a7dc: stur            x4, [fp, #-0x38]
    // 0x84a7e0: LoadField: r5 = r0->field_b
    //     0x84a7e0: ldur            w5, [x0, #0xb]
    // 0x84a7e4: DecompressPointer r5
    //     0x84a7e4: add             x5, x5, HEAP, lsl #32
    // 0x84a7e8: stur            x5, [fp, #-0x28]
    // 0x84a7ec: r6 = false
    //     0x84a7ec: add             x6, NULL, #0x30  ; false
    // 0x84a7f0: r1 = 0
    //     0x84a7f0: mov             x1, #0
    // 0x84a7f4: stur            x6, [fp, #-0x18]
    // 0x84a7f8: CheckStackOverflow
    //     0x84a7f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84a7fc: cmp             SP, x16
    //     0x84a800: b.ls            #0x84a8f4
    // 0x84a804: LoadField: r2 = r3->field_b
    //     0x84a804: ldur            w2, [x3, #0xb]
    // 0x84a808: r7 = LoadInt32Instr(r2)
    //     0x84a808: sbfx            x7, x2, #1, #0x1f
    // 0x84a80c: cmp             x4, x7
    // 0x84a810: b.ne            #0x84a8cc
    // 0x84a814: cmp             x1, x7
    // 0x84a818: b.ge            #0x84a86c
    // 0x84a81c: LoadField: r2 = r3->field_f
    //     0x84a81c: ldur            w2, [x3, #0xf]
    // 0x84a820: DecompressPointer r2
    //     0x84a820: add             x2, x2, HEAP, lsl #32
    // 0x84a824: ArrayLoad: r7 = r2[r1]  ; Unknown_4
    //     0x84a824: add             x16, x2, x1, lsl #2
    //     0x84a828: ldur            w7, [x16, #0xf]
    // 0x84a82c: DecompressPointer r7
    //     0x84a82c: add             x7, x7, HEAP, lsl #32
    // 0x84a830: add             x8, x1, #1
    // 0x84a834: mov             x1, x5
    // 0x84a838: mov             x2, x7
    // 0x84a83c: stur            x8, [fp, #-0x30]
    // 0x84a840: r0 = handleKeyEvent()
    //     0x84a840: bl              #0x849de8  ; [package:flutter/src/services/hardware_keyboard.dart] HardwareKeyboard::handleKeyEvent
    // 0x84a844: tbnz            w0, #4, #0x84a850
    // 0x84a848: r6 = true
    //     0x84a848: add             x6, NULL, #0x20  ; true
    // 0x84a84c: b               #0x84a854
    // 0x84a850: ldur            x6, [fp, #-0x18]
    // 0x84a854: ldur            x1, [fp, #-0x30]
    // 0x84a858: ldur            x0, [fp, #-0x10]
    // 0x84a85c: ldur            x3, [fp, #-0x40]
    // 0x84a860: ldur            x5, [fp, #-0x28]
    // 0x84a864: ldur            x4, [fp, #-0x38]
    // 0x84a868: b               #0x84a7f4
    // 0x84a86c: ldur            x1, [fp, #-0x10]
    // 0x84a870: ldur            x2, [fp, #-0x40]
    // 0x84a874: ldur            x3, [fp, #-0x20]
    // 0x84a878: r0 = _dispatchKeyMessage()
    //     0x84a878: bl              #0x849ce4  ; [package:flutter/src/services/hardware_keyboard.dart] KeyEventManager::_dispatchKeyMessage
    // 0x84a87c: tbnz            w0, #4, #0x84a888
    // 0x84a880: r0 = true
    //     0x84a880: add             x0, NULL, #0x20  ; true
    // 0x84a884: b               #0x84a88c
    // 0x84a888: ldur            x0, [fp, #-0x18]
    // 0x84a88c: ldur            x1, [fp, #-0x40]
    // 0x84a890: stur            x0, [fp, #-0x10]
    // 0x84a894: r0 = clear()
    //     0x84a894: bl              #0xa16074  ; [dart:core] _GrowableList::clear
    // 0x84a898: ldur            x0, [fp, #-0x10]
    // 0x84a89c: stur            x0, [fp, #-0x10]
    // 0x84a8a0: r1 = Null
    //     0x84a8a0: mov             x1, NULL
    // 0x84a8a4: r2 = 4
    //     0x84a8a4: mov             x2, #4
    // 0x84a8a8: r0 = AllocateArray()
    //     0x84a8a8: bl              #0x13df928  ; AllocateArrayStub
    // 0x84a8ac: r16 = "handled"
    //     0x84a8ac: ldr             x16, [PP, #0x3a90]  ; [pp+0x3a90] "handled"
    // 0x84a8b0: StoreField: r0->field_f = r16
    //     0x84a8b0: stur            w16, [x0, #0xf]
    // 0x84a8b4: ldur            x1, [fp, #-0x10]
    // 0x84a8b8: StoreField: r0->field_13 = r1
    //     0x84a8b8: stur            w1, [x0, #0x13]
    // 0x84a8bc: r16 = <String, dynamic>
    //     0x84a8bc: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x84a8c0: stp             x0, x16, [SP]
    // 0x84a8c4: r0 = Map._fromLiteral()
    //     0x84a8c4: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x84a8c8: r0 = ReturnAsyncNotFuture()
    //     0x84a8c8: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x84a8cc: mov             x0, x3
    // 0x84a8d0: r0 = ConcurrentModificationError()
    //     0x84a8d0: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x84a8d4: mov             x1, x0
    // 0x84a8d8: ldur            x0, [fp, #-0x40]
    // 0x84a8dc: StoreField: r1->field_b = r0
    //     0x84a8dc: stur            w0, [x1, #0xb]
    // 0x84a8e0: mov             x0, x1
    // 0x84a8e4: r0 = Throw()
    //     0x84a8e4: bl              #0x13ddb2c  ; ThrowStub
    // 0x84a8e8: brk             #0
    // 0x84a8ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84a8ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84a8f0: b               #0x84a568
    // 0x84a8f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84a8f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84a8f8: b               #0x84a804
  }
  [closure] void _convertRawEventAndStore(dynamic, RawKeyEvent) {
    // ** addr: 0x84f12c, size: 0x3c
    // 0x84f12c: EnterFrame
    //     0x84f12c: stp             fp, lr, [SP, #-0x10]!
    //     0x84f130: mov             fp, SP
    // 0x84f134: ldr             x0, [fp, #0x18]
    // 0x84f138: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x84f138: ldur            w1, [x0, #0x17]
    // 0x84f13c: DecompressPointer r1
    //     0x84f13c: add             x1, x1, HEAP, lsl #32
    // 0x84f140: CheckStackOverflow
    //     0x84f140: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84f144: cmp             SP, x16
    //     0x84f148: b.ls            #0x84f160
    // 0x84f14c: ldr             x2, [fp, #0x10]
    // 0x84f150: r0 = _convertRawEventAndStore()
    //     0x84f150: bl              #0x84f168  ; [package:flutter/src/services/hardware_keyboard.dart] KeyEventManager::_convertRawEventAndStore
    // 0x84f154: LeaveFrame
    //     0x84f154: mov             SP, fp
    //     0x84f158: ldp             fp, lr, [SP], #0x10
    // 0x84f15c: ret
    //     0x84f15c: ret             
    // 0x84f160: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84f160: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84f164: b               #0x84f14c
  }
  _ _convertRawEventAndStore(/* No info */) {
    // ** addr: 0x84f168, size: 0x794
    // 0x84f168: EnterFrame
    //     0x84f168: stp             fp, lr, [SP, #-0x10]!
    //     0x84f16c: mov             fp, SP
    // 0x84f170: AllocStack(0x90)
    //     0x84f170: sub             SP, SP, #0x90
    // 0x84f174: SetupParameters(KeyEventManager this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0x84f174: mov             x3, x1
    //     0x84f178: stur            x1, [fp, #-0x10]
    //     0x84f17c: stur            x2, [fp, #-0x18]
    // 0x84f180: CheckStackOverflow
    //     0x84f180: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84f184: cmp             SP, x16
    //     0x84f188: b.ls            #0x84f8d8
    // 0x84f18c: LoadField: r4 = r2->field_b
    //     0x84f18c: ldur            w4, [x2, #0xb]
    // 0x84f190: DecompressPointer r4
    //     0x84f190: add             x4, x4, HEAP, lsl #32
    // 0x84f194: stur            x4, [fp, #-8]
    // 0x84f198: r0 = LoadClassIdInstr(r4)
    //     0x84f198: ldur            x0, [x4, #-1]
    //     0x84f19c: ubfx            x0, x0, #0xc, #0x14
    // 0x84f1a0: mov             x1, x4
    // 0x84f1a4: r0 = GDT[cid_x0 + 0x6c3b]()
    //     0x84f1a4: mov             x17, #0x6c3b
    //     0x84f1a8: add             lr, x0, x17
    //     0x84f1ac: ldr             lr, [x21, lr, lsl #3]
    //     0x84f1b0: blr             lr
    // 0x84f1b4: ldur            x1, [fp, #-0x18]
    // 0x84f1b8: stur            x0, [fp, #-0x20]
    // 0x84f1bc: r0 = logicalKey()
    //     0x84f1bc: bl              #0x84ac9c  ; [package:flutter/src/services/raw_keyboard.dart] RawKeyEvent::logicalKey
    // 0x84f1c0: mov             x2, x0
    // 0x84f1c4: ldur            x0, [fp, #-0x10]
    // 0x84f1c8: stur            x2, [fp, #-0x30]
    // 0x84f1cc: LoadField: r3 = r0->field_b
    //     0x84f1cc: ldur            w3, [x0, #0xb]
    // 0x84f1d0: DecompressPointer r3
    //     0x84f1d0: add             x3, x3, HEAP, lsl #32
    // 0x84f1d4: mov             x1, x3
    // 0x84f1d8: stur            x3, [fp, #-0x28]
    // 0x84f1dc: r0 = physicalKeysPressed()
    //     0x84f1dc: bl              #0x84f954  ; [package:flutter/src/services/hardware_keyboard.dart] HardwareKeyboard::physicalKeysPressed
    // 0x84f1e0: r1 = <KeyEvent>
    //     0x84f1e0: ldr             x1, [PP, #0x3a98]  ; [pp+0x3a98] TypeArguments: <KeyEvent>
    // 0x84f1e4: r2 = 0
    //     0x84f1e4: mov             x2, #0
    // 0x84f1e8: stur            x0, [fp, #-0x38]
    // 0x84f1ec: r0 = _GrowableList()
    //     0x84f1ec: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x84f1f0: ldur            x1, [fp, #-0x28]
    // 0x84f1f4: ldur            x2, [fp, #-0x20]
    // 0x84f1f8: stur            x0, [fp, #-0x40]
    // 0x84f1fc: r0 = lookUpLayout()
    //     0x84f1fc: bl              #0x84f8fc  ; [package:flutter/src/services/hardware_keyboard.dart] HardwareKeyboard::lookUpLayout
    // 0x84f200: mov             x1, x0
    // 0x84f204: stur            x1, [fp, #-0x48]
    // 0x84f208: r0 = LoadStaticField(0x7bc)
    //     0x84f208: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x84f20c: ldr             x0, [x0, #0xf78]
    // 0x84f210: cmp             w0, NULL
    // 0x84f214: b.eq            #0x84f8e0
    // 0x84f218: ldur            x2, [fp, #-0x18]
    // 0x84f21c: LoadField: r0 = r2->field_7
    //     0x84f21c: ldur            w0, [x2, #7]
    // 0x84f220: DecompressPointer r0
    //     0x84f220: add             x0, x0, HEAP, lsl #32
    // 0x84f224: r3 = LoadClassIdInstr(r0)
    //     0x84f224: ldur            x3, [x0, #-1]
    //     0x84f228: ubfx            x3, x3, #0xc, #0x14
    // 0x84f22c: r16 = ""
    //     0x84f22c: ldr             x16, [PP, #0x900]  ; [pp+0x900] ""
    // 0x84f230: stp             x16, x0, [SP]
    // 0x84f234: mov             x0, x3
    // 0x84f238: mov             lr, x0
    // 0x84f23c: ldr             lr, [x21, lr, lsl #3]
    // 0x84f240: blr             lr
    // 0x84f244: ldur            x0, [fp, #-8]
    // 0x84f248: r1 = LoadClassIdInstr(r0)
    //     0x84f248: ldur            x1, [x0, #-1]
    //     0x84f24c: ubfx            x1, x1, #0xc, #0x14
    // 0x84f250: r17 = 5025
    //     0x84f250: mov             x17, #0x13a1
    // 0x84f254: cmp             x1, x17
    // 0x84f258: b.ne            #0x84f304
    // 0x84f25c: LoadField: r2 = r0->field_37
    //     0x84f25c: ldur            x2, [x0, #0x37]
    // 0x84f260: cmp             x2, #0x401
    // 0x84f264: b.gt            #0x84f2b0
    // 0x84f268: cmp             x2, #0x201
    // 0x84f26c: b.gt            #0x84f2a4
    // 0x84f270: cmp             x2, #0x101
    // 0x84f274: b.gt            #0x84f298
    // 0x84f278: r0 = BoxInt64Instr(r2)
    //     0x84f278: sbfiz           x0, x2, #1, #0x1f
    //     0x84f27c: cmp             x2, x0, asr #1
    //     0x84f280: b.eq            #0x84f28c
    //     0x84f284: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x84f288: stur            x2, [x0, #7]
    // 0x84f28c: cmp             w0, #0x202
    // 0x84f290: b.ne            #0x84f304
    // 0x84f294: b               #0x84f304
    // 0x84f298: cmp             x2, #0x201
    // 0x84f29c: b.lt            #0x84f304
    // 0x84f2a0: b               #0x84f304
    // 0x84f2a4: cmp             x2, #0x401
    // 0x84f2a8: b.lt            #0x84f304
    // 0x84f2ac: b               #0x84f304
    // 0x84f2b0: r17 = 16777232
    //     0x84f2b0: mov             x17, #0x10
    //     0x84f2b4: movk            x17, #0x100, lsl #16
    // 0x84f2b8: cmp             x2, x17
    // 0x84f2bc: b.lt            #0x84f304
    // 0x84f2c0: r17 = 16777232
    //     0x84f2c0: mov             x17, #0x10
    //     0x84f2c4: movk            x17, #0x100, lsl #16
    // 0x84f2c8: cmp             x2, x17
    // 0x84f2cc: b.le            #0x84f304
    // 0x84f2d0: r17 = 33554433
    //     0x84f2d0: mov             x17, #1
    //     0x84f2d4: movk            x17, #0x200, lsl #16
    // 0x84f2d8: cmp             x2, x17
    // 0x84f2dc: b.lt            #0x84f304
    // 0x84f2e0: r0 = BoxInt64Instr(r2)
    //     0x84f2e0: sbfiz           x0, x2, #1, #0x1f
    //     0x84f2e4: cmp             x2, x0, asr #1
    //     0x84f2e8: b.eq            #0x84f2f4
    //     0x84f2ec: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x84f2f0: stur            x2, [x0, #7]
    // 0x84f2f4: r17 = 67108866
    //     0x84f2f4: mov             x17, #2
    //     0x84f2f8: movk            x17, #0x400, lsl #16
    // 0x84f2fc: cmp             w0, w17
    // 0x84f300: b.eq            #0x84f304
    // 0x84f304: ldur            x0, [fp, #-0x18]
    // 0x84f308: r1 = LoadClassIdInstr(r0)
    //     0x84f308: ldur            x1, [x0, #-1]
    //     0x84f30c: ubfx            x1, x1, #0xc, #0x14
    // 0x84f310: r17 = 5017
    //     0x84f310: mov             x17, #0x1399
    // 0x84f314: cmp             x1, x17
    // 0x84f318: b.ne            #0x84f388
    // 0x84f31c: ldur            x0, [fp, #-0x48]
    // 0x84f320: cmp             w0, NULL
    // 0x84f324: b.ne            #0x84f364
    // 0x84f328: ldur            x0, [fp, #-0x30]
    // 0x84f32c: ldur            x2, [fp, #-0x20]
    // 0x84f330: r0 = KeyDownEvent()
    //     0x84f330: bl              #0x84a458  ; AllocateKeyDownEventStub -> KeyDownEvent (size=0x10)
    // 0x84f334: mov             x3, x0
    // 0x84f338: ldur            x0, [fp, #-0x20]
    // 0x84f33c: stur            x3, [fp, #-8]
    // 0x84f340: StoreField: r3->field_7 = r0
    //     0x84f340: stur            w0, [x3, #7]
    // 0x84f344: ldur            x4, [fp, #-0x30]
    // 0x84f348: StoreField: r3->field_b = r4
    //     0x84f348: stur            w4, [x3, #0xb]
    // 0x84f34c: ldur            x1, [fp, #-0x38]
    // 0x84f350: mov             x2, x0
    // 0x84f354: r0 = add()
    //     0x84f354: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x84f358: ldur            x0, [fp, #-8]
    // 0x84f35c: ldur            x2, [fp, #-0x20]
    // 0x84f360: b               #0x84f37c
    // 0x84f364: ldur            x2, [fp, #-0x20]
    // 0x84f368: r0 = KeyRepeatEvent()
    //     0x84f368: bl              #0x84a440  ; AllocateKeyRepeatEventStub -> KeyRepeatEvent (size=0x10)
    // 0x84f36c: ldur            x2, [fp, #-0x20]
    // 0x84f370: StoreField: r0->field_7 = r2
    //     0x84f370: stur            w2, [x0, #7]
    // 0x84f374: ldur            x1, [fp, #-0x48]
    // 0x84f378: StoreField: r0->field_b = r1
    //     0x84f378: stur            w1, [x0, #0xb]
    // 0x84f37c: mov             x4, x0
    // 0x84f380: mov             x0, x2
    // 0x84f384: b               #0x84f3d4
    // 0x84f388: ldur            x1, [fp, #-0x48]
    // 0x84f38c: ldur            x2, [fp, #-0x20]
    // 0x84f390: cmp             w1, NULL
    // 0x84f394: b.ne            #0x84f3a0
    // 0x84f398: r0 = Null
    //     0x84f398: mov             x0, NULL
    // 0x84f39c: b               #0x84f3cc
    // 0x84f3a0: r0 = KeyUpEvent()
    //     0x84f3a0: bl              #0x84a44c  ; AllocateKeyUpEventStub -> KeyUpEvent (size=0x10)
    // 0x84f3a4: mov             x3, x0
    // 0x84f3a8: ldur            x0, [fp, #-0x20]
    // 0x84f3ac: stur            x3, [fp, #-8]
    // 0x84f3b0: StoreField: r3->field_7 = r0
    //     0x84f3b0: stur            w0, [x3, #7]
    // 0x84f3b4: ldur            x1, [fp, #-0x48]
    // 0x84f3b8: StoreField: r3->field_b = r1
    //     0x84f3b8: stur            w1, [x3, #0xb]
    // 0x84f3bc: ldur            x1, [fp, #-0x38]
    // 0x84f3c0: mov             x2, x0
    // 0x84f3c4: r0 = remove()
    //     0x84f3c4: bl              #0x115bfd0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::remove
    // 0x84f3c8: ldur            x0, [fp, #-8]
    // 0x84f3cc: mov             x4, x0
    // 0x84f3d0: ldur            x0, [fp, #-0x20]
    // 0x84f3d4: ldur            x2, [fp, #-0x10]
    // 0x84f3d8: ldur            x3, [fp, #-0x28]
    // 0x84f3dc: stur            x4, [fp, #-0x48]
    // 0x84f3e0: LoadField: r5 = r2->field_f
    //     0x84f3e0: ldur            w5, [x2, #0xf]
    // 0x84f3e4: DecompressPointer r5
    //     0x84f3e4: add             x5, x5, HEAP, lsl #32
    // 0x84f3e8: stur            x5, [fp, #-0x18]
    // 0x84f3ec: LoadField: r6 = r5->field_b
    //     0x84f3ec: ldur            w6, [x5, #0xb]
    // 0x84f3f0: DecompressPointer r6
    //     0x84f3f0: add             x6, x6, HEAP, lsl #32
    // 0x84f3f4: stur            x6, [fp, #-8]
    // 0x84f3f8: r1 = <PhysicalKeyboardKey, LogicalKeyboardKey>
    //     0x84f3f8: ldr             x1, [PP, #0x3aa0]  ; [pp+0x3aa0] TypeArguments: <PhysicalKeyboardKey, LogicalKeyboardKey>
    // 0x84f3fc: r0 = _CompactKeysIterable()
    //     0x84f3fc: bl              #0x8353d0  ; Allocate_CompactKeysIterableStub -> _CompactKeysIterable<X0> (size=0x10)
    // 0x84f400: mov             x1, x0
    // 0x84f404: ldur            x0, [fp, #-8]
    // 0x84f408: StoreField: r1->field_b = r0
    //     0x84f408: stur            w0, [x1, #0xb]
    // 0x84f40c: r0 = toSet()
    //     0x84f40c: bl              #0xba60e0  ; [dart:core] _GrowableList::toSet
    // 0x84f410: ldur            x1, [fp, #-0x38]
    // 0x84f414: mov             x2, x0
    // 0x84f418: r0 = difference()
    //     0x84f418: bl              #0x1140a2c  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::difference
    // 0x84f41c: mov             x1, x0
    // 0x84f420: r0 = iterator()
    //     0x84f420: bl              #0xbb7c60  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0x84f424: mov             x2, x0
    // 0x84f428: ldur            x0, [fp, #-0x20]
    // 0x84f42c: stur            x2, [fp, #-0x68]
    // 0x84f430: LoadField: r3 = r0->field_7
    //     0x84f430: ldur            x3, [x0, #7]
    // 0x84f434: ldur            x1, [fp, #-0x10]
    // 0x84f438: stur            x3, [fp, #-0x60]
    // 0x84f43c: ArrayLoad: r4 = r1[0]  ; List_4
    //     0x84f43c: ldur            w4, [x1, #0x17]
    // 0x84f440: DecompressPointer r4
    //     0x84f440: add             x4, x4, HEAP, lsl #32
    // 0x84f444: ldur            x1, [fp, #-0x28]
    // 0x84f448: stur            x4, [fp, #-0x58]
    // 0x84f44c: LoadField: r5 = r1->field_7
    //     0x84f44c: ldur            w5, [x1, #7]
    // 0x84f450: DecompressPointer r5
    //     0x84f450: add             x5, x5, HEAP, lsl #32
    // 0x84f454: stur            x5, [fp, #-0x50]
    // 0x84f458: LoadField: r6 = r2->field_7
    //     0x84f458: ldur            w6, [x2, #7]
    // 0x84f45c: DecompressPointer r6
    //     0x84f45c: add             x6, x6, HEAP, lsl #32
    // 0x84f460: stur            x6, [fp, #-0x10]
    // 0x84f464: ldur            x7, [fp, #-0x30]
    // 0x84f468: ldur            x8, [fp, #-0x40]
    // 0x84f46c: CheckStackOverflow
    //     0x84f46c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84f470: cmp             SP, x16
    //     0x84f474: b.ls            #0x84f8e4
    // 0x84f478: mov             x1, x2
    // 0x84f47c: r0 = moveNext()
    //     0x84f47c: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0x84f480: tbnz            w0, #4, #0x84f6b8
    // 0x84f484: ldur            x3, [fp, #-0x68]
    // 0x84f488: LoadField: r4 = r3->field_33
    //     0x84f488: ldur            w4, [x3, #0x33]
    // 0x84f48c: DecompressPointer r4
    //     0x84f48c: add             x4, x4, HEAP, lsl #32
    // 0x84f490: stur            x4, [fp, #-0x28]
    // 0x84f494: cmp             w4, NULL
    // 0x84f498: b.ne            #0x84f4c8
    // 0x84f49c: mov             x0, x4
    // 0x84f4a0: ldur            x2, [fp, #-0x10]
    // 0x84f4a4: r1 = Null
    //     0x84f4a4: mov             x1, NULL
    // 0x84f4a8: cmp             w2, NULL
    // 0x84f4ac: b.eq            #0x84f4c8
    // 0x84f4b0: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x84f4b0: ldur            w4, [x2, #0x17]
    // 0x84f4b4: DecompressPointer r4
    //     0x84f4b4: add             x4, x4, HEAP, lsl #32
    // 0x84f4b8: r8 = X0
    //     0x84f4b8: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x84f4bc: LoadField: r9 = r4->field_7
    //     0x84f4bc: ldur            x9, [x4, #7]
    // 0x84f4c0: r3 = Null
    //     0x84f4c0: ldr             x3, [PP, #0x3aa8]  ; [pp+0x3aa8] Null
    // 0x84f4c4: blr             x9
    // 0x84f4c8: ldur            x2, [fp, #-0x28]
    // 0x84f4cc: ldur            x0, [fp, #-0x20]
    // 0x84f4d0: cmp             w2, w0
    // 0x84f4d4: b.ne            #0x84f4e0
    // 0x84f4d8: ldur            x0, [fp, #-0x60]
    // 0x84f4dc: b               #0x84f514
    // 0x84f4e0: r16 = PhysicalKeyboardKey
    //     0x84f4e0: ldr             x16, [PP, #0x3ab8]  ; [pp+0x3ab8] Type: PhysicalKeyboardKey
    // 0x84f4e4: r30 = PhysicalKeyboardKey
    //     0x84f4e4: ldr             lr, [PP, #0x3ab8]  ; [pp+0x3ab8] Type: PhysicalKeyboardKey
    // 0x84f4e8: stp             lr, x16, [SP]
    // 0x84f4ec: r0 = ==()
    //     0x84f4ec: bl              #0x12b7fbc  ; [dart:core] _Type::==
    // 0x84f4f0: tbz             w0, #4, #0x84f500
    // 0x84f4f4: ldur            x3, [fp, #-0x40]
    // 0x84f4f8: ldur            x0, [fp, #-0x28]
    // 0x84f4fc: b               #0x84f5c0
    // 0x84f500: ldur            x2, [fp, #-0x28]
    // 0x84f504: ldur            x0, [fp, #-0x60]
    // 0x84f508: LoadField: r1 = r2->field_7
    //     0x84f508: ldur            x1, [x2, #7]
    // 0x84f50c: cmp             x0, x1
    // 0x84f510: b.ne            #0x84f5b8
    // 0x84f514: ldur            x1, [fp, #-0x30]
    // 0x84f518: ldur            x3, [fp, #-0x40]
    // 0x84f51c: r0 = KeyUpEvent()
    //     0x84f51c: bl              #0x84a44c  ; AllocateKeyUpEventStub -> KeyUpEvent (size=0x10)
    // 0x84f520: mov             x2, x0
    // 0x84f524: ldur            x0, [fp, #-0x28]
    // 0x84f528: stur            x2, [fp, #-0x78]
    // 0x84f52c: StoreField: r2->field_7 = r0
    //     0x84f52c: stur            w0, [x2, #7]
    // 0x84f530: ldur            x0, [fp, #-0x30]
    // 0x84f534: StoreField: r2->field_b = r0
    //     0x84f534: stur            w0, [x2, #0xb]
    // 0x84f538: ldur            x3, [fp, #-0x40]
    // 0x84f53c: LoadField: r1 = r3->field_b
    //     0x84f53c: ldur            w1, [x3, #0xb]
    // 0x84f540: LoadField: r4 = r3->field_f
    //     0x84f540: ldur            w4, [x3, #0xf]
    // 0x84f544: DecompressPointer r4
    //     0x84f544: add             x4, x4, HEAP, lsl #32
    // 0x84f548: LoadField: r5 = r4->field_b
    //     0x84f548: ldur            w5, [x4, #0xb]
    // 0x84f54c: r4 = LoadInt32Instr(r1)
    //     0x84f54c: sbfx            x4, x1, #1, #0x1f
    // 0x84f550: stur            x4, [fp, #-0x70]
    // 0x84f554: r1 = LoadInt32Instr(r5)
    //     0x84f554: sbfx            x1, x5, #1, #0x1f
    // 0x84f558: cmp             x4, x1
    // 0x84f55c: b.ne            #0x84f568
    // 0x84f560: mov             x1, x3
    // 0x84f564: r0 = _growToNextCapacity()
    //     0x84f564: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x84f568: ldur            x3, [fp, #-0x40]
    // 0x84f56c: ldur            x2, [fp, #-0x70]
    // 0x84f570: add             x0, x2, #1
    // 0x84f574: lsl             x1, x0, #1
    // 0x84f578: StoreField: r3->field_b = r1
    //     0x84f578: stur            w1, [x3, #0xb]
    // 0x84f57c: LoadField: r1 = r3->field_f
    //     0x84f57c: ldur            w1, [x3, #0xf]
    // 0x84f580: DecompressPointer r1
    //     0x84f580: add             x1, x1, HEAP, lsl #32
    // 0x84f584: ldur            x0, [fp, #-0x78]
    // 0x84f588: ArrayStore: r1[r2] = r0  ; List_4
    //     0x84f588: add             x25, x1, x2, lsl #2
    //     0x84f58c: add             x25, x25, #0xf
    //     0x84f590: str             w0, [x25]
    //     0x84f594: tbz             w0, #0, #0x84f5b0
    //     0x84f598: ldurb           w16, [x1, #-1]
    //     0x84f59c: ldurb           w17, [x0, #-1]
    //     0x84f5a0: and             x16, x17, x16, lsr #2
    //     0x84f5a4: tst             x16, HEAP, lsr #32
    //     0x84f5a8: b.eq            #0x84f5b0
    //     0x84f5ac: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x84f5b0: ldur            x2, [fp, #-0x58]
    // 0x84f5b4: b               #0x84f69c
    // 0x84f5b8: ldur            x3, [fp, #-0x40]
    // 0x84f5bc: mov             x0, x2
    // 0x84f5c0: ldur            x4, [fp, #-0x50]
    // 0x84f5c4: mov             x1, x4
    // 0x84f5c8: mov             x2, x0
    // 0x84f5cc: r0 = _getValueOrData()
    //     0x84f5cc: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x84f5d0: mov             x1, x0
    // 0x84f5d4: ldur            x0, [fp, #-0x50]
    // 0x84f5d8: LoadField: r2 = r0->field_f
    //     0x84f5d8: ldur            w2, [x0, #0xf]
    // 0x84f5dc: DecompressPointer r2
    //     0x84f5dc: add             x2, x2, HEAP, lsl #32
    // 0x84f5e0: cmp             w2, w1
    // 0x84f5e4: b.ne            #0x84f5f0
    // 0x84f5e8: r3 = Null
    //     0x84f5e8: mov             x3, NULL
    // 0x84f5ec: b               #0x84f5f4
    // 0x84f5f0: mov             x3, x1
    // 0x84f5f4: ldur            x2, [fp, #-0x58]
    // 0x84f5f8: ldur            x1, [fp, #-0x28]
    // 0x84f5fc: stur            x3, [fp, #-0x78]
    // 0x84f600: cmp             w3, NULL
    // 0x84f604: b.eq            #0x84f8ec
    // 0x84f608: r0 = KeyUpEvent()
    //     0x84f608: bl              #0x84a44c  ; AllocateKeyUpEventStub -> KeyUpEvent (size=0x10)
    // 0x84f60c: mov             x2, x0
    // 0x84f610: ldur            x0, [fp, #-0x28]
    // 0x84f614: stur            x2, [fp, #-0x80]
    // 0x84f618: StoreField: r2->field_7 = r0
    //     0x84f618: stur            w0, [x2, #7]
    // 0x84f61c: ldur            x0, [fp, #-0x78]
    // 0x84f620: StoreField: r2->field_b = r0
    //     0x84f620: stur            w0, [x2, #0xb]
    // 0x84f624: ldur            x0, [fp, #-0x58]
    // 0x84f628: LoadField: r1 = r0->field_b
    //     0x84f628: ldur            w1, [x0, #0xb]
    // 0x84f62c: LoadField: r3 = r0->field_f
    //     0x84f62c: ldur            w3, [x0, #0xf]
    // 0x84f630: DecompressPointer r3
    //     0x84f630: add             x3, x3, HEAP, lsl #32
    // 0x84f634: LoadField: r4 = r3->field_b
    //     0x84f634: ldur            w4, [x3, #0xb]
    // 0x84f638: r3 = LoadInt32Instr(r1)
    //     0x84f638: sbfx            x3, x1, #1, #0x1f
    // 0x84f63c: stur            x3, [fp, #-0x70]
    // 0x84f640: r1 = LoadInt32Instr(r4)
    //     0x84f640: sbfx            x1, x4, #1, #0x1f
    // 0x84f644: cmp             x3, x1
    // 0x84f648: b.ne            #0x84f654
    // 0x84f64c: mov             x1, x0
    // 0x84f650: r0 = _growToNextCapacity()
    //     0x84f650: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x84f654: ldur            x2, [fp, #-0x58]
    // 0x84f658: ldur            x3, [fp, #-0x70]
    // 0x84f65c: add             x0, x3, #1
    // 0x84f660: lsl             x1, x0, #1
    // 0x84f664: StoreField: r2->field_b = r1
    //     0x84f664: stur            w1, [x2, #0xb]
    // 0x84f668: LoadField: r1 = r2->field_f
    //     0x84f668: ldur            w1, [x2, #0xf]
    // 0x84f66c: DecompressPointer r1
    //     0x84f66c: add             x1, x1, HEAP, lsl #32
    // 0x84f670: ldur            x0, [fp, #-0x80]
    // 0x84f674: ArrayStore: r1[r3] = r0  ; List_4
    //     0x84f674: add             x25, x1, x3, lsl #2
    //     0x84f678: add             x25, x25, #0xf
    //     0x84f67c: str             w0, [x25]
    //     0x84f680: tbz             w0, #0, #0x84f69c
    //     0x84f684: ldurb           w16, [x1, #-1]
    //     0x84f688: ldurb           w17, [x0, #-1]
    //     0x84f68c: and             x16, x17, x16, lsr #2
    //     0x84f690: tst             x16, HEAP, lsr #32
    //     0x84f694: b.eq            #0x84f69c
    //     0x84f698: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x84f69c: mov             x4, x2
    // 0x84f6a0: ldur            x2, [fp, #-0x68]
    // 0x84f6a4: ldur            x5, [fp, #-0x50]
    // 0x84f6a8: ldur            x6, [fp, #-0x10]
    // 0x84f6ac: ldur            x3, [fp, #-0x60]
    // 0x84f6b0: ldur            x0, [fp, #-0x20]
    // 0x84f6b4: b               #0x84f464
    // 0x84f6b8: ldur            x2, [fp, #-0x58]
    // 0x84f6bc: ldur            x1, [fp, #-0x18]
    // 0x84f6c0: r0 = physicalKeysPressed()
    //     0x84f6c0: bl              #0x84eb10  ; [package:flutter/src/services/raw_keyboard.dart] RawKeyboard::physicalKeysPressed
    // 0x84f6c4: mov             x1, x0
    // 0x84f6c8: ldur            x2, [fp, #-0x38]
    // 0x84f6cc: r0 = difference()
    //     0x84f6cc: bl              #0x1140a2c  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::difference
    // 0x84f6d0: mov             x1, x0
    // 0x84f6d4: r0 = iterator()
    //     0x84f6d4: bl              #0xbb7c60  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0x84f6d8: stur            x0, [fp, #-0x18]
    // 0x84f6dc: LoadField: r2 = r0->field_7
    //     0x84f6dc: ldur            w2, [x0, #7]
    // 0x84f6e0: DecompressPointer r2
    //     0x84f6e0: add             x2, x2, HEAP, lsl #32
    // 0x84f6e4: stur            x2, [fp, #-0x10]
    // 0x84f6e8: ldur            x3, [fp, #-0x58]
    // 0x84f6ec: ldur            x4, [fp, #-8]
    // 0x84f6f0: CheckStackOverflow
    //     0x84f6f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84f6f4: cmp             SP, x16
    //     0x84f6f8: b.ls            #0x84f8f0
    // 0x84f6fc: mov             x1, x0
    // 0x84f700: r0 = moveNext()
    //     0x84f700: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0x84f704: tbnz            w0, #4, #0x84f838
    // 0x84f708: ldur            x3, [fp, #-0x18]
    // 0x84f70c: LoadField: r4 = r3->field_33
    //     0x84f70c: ldur            w4, [x3, #0x33]
    // 0x84f710: DecompressPointer r4
    //     0x84f710: add             x4, x4, HEAP, lsl #32
    // 0x84f714: stur            x4, [fp, #-0x20]
    // 0x84f718: cmp             w4, NULL
    // 0x84f71c: b.ne            #0x84f74c
    // 0x84f720: mov             x0, x4
    // 0x84f724: ldur            x2, [fp, #-0x10]
    // 0x84f728: r1 = Null
    //     0x84f728: mov             x1, NULL
    // 0x84f72c: cmp             w2, NULL
    // 0x84f730: b.eq            #0x84f74c
    // 0x84f734: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x84f734: ldur            w4, [x2, #0x17]
    // 0x84f738: DecompressPointer r4
    //     0x84f738: add             x4, x4, HEAP, lsl #32
    // 0x84f73c: r8 = X0
    //     0x84f73c: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x84f740: LoadField: r9 = r4->field_7
    //     0x84f740: ldur            x9, [x4, #7]
    // 0x84f744: r3 = Null
    //     0x84f744: ldr             x3, [PP, #0x3ac0]  ; [pp+0x3ac0] Null
    // 0x84f748: blr             x9
    // 0x84f74c: ldur            x0, [fp, #-8]
    // 0x84f750: mov             x1, x0
    // 0x84f754: ldur            x2, [fp, #-0x20]
    // 0x84f758: r0 = _getValueOrData()
    //     0x84f758: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x84f75c: mov             x1, x0
    // 0x84f760: ldur            x0, [fp, #-8]
    // 0x84f764: LoadField: r2 = r0->field_f
    //     0x84f764: ldur            w2, [x0, #0xf]
    // 0x84f768: DecompressPointer r2
    //     0x84f768: add             x2, x2, HEAP, lsl #32
    // 0x84f76c: cmp             w2, w1
    // 0x84f770: b.ne            #0x84f77c
    // 0x84f774: r3 = Null
    //     0x84f774: mov             x3, NULL
    // 0x84f778: b               #0x84f780
    // 0x84f77c: mov             x3, x1
    // 0x84f780: ldur            x2, [fp, #-0x58]
    // 0x84f784: ldur            x1, [fp, #-0x20]
    // 0x84f788: stur            x3, [fp, #-0x28]
    // 0x84f78c: cmp             w3, NULL
    // 0x84f790: b.eq            #0x84f8f8
    // 0x84f794: r0 = KeyDownEvent()
    //     0x84f794: bl              #0x84a458  ; AllocateKeyDownEventStub -> KeyDownEvent (size=0x10)
    // 0x84f798: mov             x2, x0
    // 0x84f79c: ldur            x0, [fp, #-0x20]
    // 0x84f7a0: stur            x2, [fp, #-0x30]
    // 0x84f7a4: StoreField: r2->field_7 = r0
    //     0x84f7a4: stur            w0, [x2, #7]
    // 0x84f7a8: ldur            x0, [fp, #-0x28]
    // 0x84f7ac: StoreField: r2->field_b = r0
    //     0x84f7ac: stur            w0, [x2, #0xb]
    // 0x84f7b0: ldur            x0, [fp, #-0x58]
    // 0x84f7b4: LoadField: r1 = r0->field_b
    //     0x84f7b4: ldur            w1, [x0, #0xb]
    // 0x84f7b8: LoadField: r3 = r0->field_f
    //     0x84f7b8: ldur            w3, [x0, #0xf]
    // 0x84f7bc: DecompressPointer r3
    //     0x84f7bc: add             x3, x3, HEAP, lsl #32
    // 0x84f7c0: LoadField: r4 = r3->field_b
    //     0x84f7c0: ldur            w4, [x3, #0xb]
    // 0x84f7c4: r3 = LoadInt32Instr(r1)
    //     0x84f7c4: sbfx            x3, x1, #1, #0x1f
    // 0x84f7c8: stur            x3, [fp, #-0x60]
    // 0x84f7cc: r1 = LoadInt32Instr(r4)
    //     0x84f7cc: sbfx            x1, x4, #1, #0x1f
    // 0x84f7d0: cmp             x3, x1
    // 0x84f7d4: b.ne            #0x84f7e0
    // 0x84f7d8: mov             x1, x0
    // 0x84f7dc: r0 = _growToNextCapacity()
    //     0x84f7dc: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x84f7e0: ldur            x2, [fp, #-0x58]
    // 0x84f7e4: ldur            x3, [fp, #-0x60]
    // 0x84f7e8: add             x0, x3, #1
    // 0x84f7ec: lsl             x1, x0, #1
    // 0x84f7f0: StoreField: r2->field_b = r1
    //     0x84f7f0: stur            w1, [x2, #0xb]
    // 0x84f7f4: LoadField: r1 = r2->field_f
    //     0x84f7f4: ldur            w1, [x2, #0xf]
    // 0x84f7f8: DecompressPointer r1
    //     0x84f7f8: add             x1, x1, HEAP, lsl #32
    // 0x84f7fc: ldur            x0, [fp, #-0x30]
    // 0x84f800: ArrayStore: r1[r3] = r0  ; List_4
    //     0x84f800: add             x25, x1, x3, lsl #2
    //     0x84f804: add             x25, x25, #0xf
    //     0x84f808: str             w0, [x25]
    //     0x84f80c: tbz             w0, #0, #0x84f828
    //     0x84f810: ldurb           w16, [x1, #-1]
    //     0x84f814: ldurb           w17, [x0, #-1]
    //     0x84f818: and             x16, x17, x16, lsr #2
    //     0x84f81c: tst             x16, HEAP, lsr #32
    //     0x84f820: b.eq            #0x84f828
    //     0x84f824: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x84f828: ldur            x0, [fp, #-0x18]
    // 0x84f82c: mov             x3, x2
    // 0x84f830: ldur            x2, [fp, #-0x10]
    // 0x84f834: b               #0x84f6ec
    // 0x84f838: ldur            x0, [fp, #-0x48]
    // 0x84f83c: ldur            x2, [fp, #-0x58]
    // 0x84f840: cmp             w0, NULL
    // 0x84f844: b.eq            #0x84f8bc
    // 0x84f848: LoadField: r1 = r2->field_b
    //     0x84f848: ldur            w1, [x2, #0xb]
    // 0x84f84c: LoadField: r3 = r2->field_f
    //     0x84f84c: ldur            w3, [x2, #0xf]
    // 0x84f850: DecompressPointer r3
    //     0x84f850: add             x3, x3, HEAP, lsl #32
    // 0x84f854: LoadField: r4 = r3->field_b
    //     0x84f854: ldur            w4, [x3, #0xb]
    // 0x84f858: r3 = LoadInt32Instr(r1)
    //     0x84f858: sbfx            x3, x1, #1, #0x1f
    // 0x84f85c: stur            x3, [fp, #-0x60]
    // 0x84f860: r1 = LoadInt32Instr(r4)
    //     0x84f860: sbfx            x1, x4, #1, #0x1f
    // 0x84f864: cmp             x3, x1
    // 0x84f868: b.ne            #0x84f874
    // 0x84f86c: mov             x1, x2
    // 0x84f870: r0 = _growToNextCapacity()
    //     0x84f870: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x84f874: ldur            x2, [fp, #-0x58]
    // 0x84f878: ldur            x3, [fp, #-0x60]
    // 0x84f87c: add             x0, x3, #1
    // 0x84f880: lsl             x1, x0, #1
    // 0x84f884: StoreField: r2->field_b = r1
    //     0x84f884: stur            w1, [x2, #0xb]
    // 0x84f888: LoadField: r1 = r2->field_f
    //     0x84f888: ldur            w1, [x2, #0xf]
    // 0x84f88c: DecompressPointer r1
    //     0x84f88c: add             x1, x1, HEAP, lsl #32
    // 0x84f890: ldur            x0, [fp, #-0x48]
    // 0x84f894: ArrayStore: r1[r3] = r0  ; List_4
    //     0x84f894: add             x25, x1, x3, lsl #2
    //     0x84f898: add             x25, x25, #0xf
    //     0x84f89c: str             w0, [x25]
    //     0x84f8a0: tbz             w0, #0, #0x84f8bc
    //     0x84f8a4: ldurb           w16, [x1, #-1]
    //     0x84f8a8: ldurb           w17, [x0, #-1]
    //     0x84f8ac: and             x16, x17, x16, lsr #2
    //     0x84f8b0: tst             x16, HEAP, lsr #32
    //     0x84f8b4: b.eq            #0x84f8bc
    //     0x84f8b8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x84f8bc: mov             x1, x2
    // 0x84f8c0: ldur            x2, [fp, #-0x40]
    // 0x84f8c4: r0 = addAll()
    //     0x84f8c4: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0x84f8c8: r0 = Null
    //     0x84f8c8: mov             x0, NULL
    // 0x84f8cc: LeaveFrame
    //     0x84f8cc: mov             SP, fp
    //     0x84f8d0: ldp             fp, lr, [SP], #0x10
    // 0x84f8d4: ret
    //     0x84f8d4: ret             
    // 0x84f8d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84f8d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84f8dc: b               #0x84f18c
    // 0x84f8e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84f8e0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84f8e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84f8e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84f8e8: b               #0x84f478
    // 0x84f8ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84f8ec: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84f8f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84f8f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84f8f4: b               #0x84f6fc
    // 0x84f8f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84f8f8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] bool handleKeyData(dynamic, KeyData) {
    // ** addr: 0x84fa90, size: 0x3c
    // 0x84fa90: EnterFrame
    //     0x84fa90: stp             fp, lr, [SP, #-0x10]!
    //     0x84fa94: mov             fp, SP
    // 0x84fa98: ldr             x0, [fp, #0x18]
    // 0x84fa9c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x84fa9c: ldur            w1, [x0, #0x17]
    // 0x84faa0: DecompressPointer r1
    //     0x84faa0: add             x1, x1, HEAP, lsl #32
    // 0x84faa4: CheckStackOverflow
    //     0x84faa4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84faa8: cmp             SP, x16
    //     0x84faac: b.ls            #0x84fac4
    // 0x84fab0: ldr             x2, [fp, #0x10]
    // 0x84fab4: r0 = handleKeyData()
    //     0x84fab4: bl              #0x849b2c  ; [package:flutter/src/services/hardware_keyboard.dart] KeyEventManager::handleKeyData
    // 0x84fab8: LeaveFrame
    //     0x84fab8: mov             SP, fp
    //     0x84fabc: ldp             fp, lr, [SP], #0x10
    // 0x84fac0: ret
    //     0x84fac0: ret             
    // 0x84fac4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84fac4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84fac8: b               #0x84fab0
  }
}

// class id: 2795, size: 0x10, field offset: 0x8
//   const constructor, 
class KeyMessage extends Object {
}

// class id: 2796, size: 0x18, field offset: 0x8
class HardwareKeyboard extends Object {

  _ syncKeyboardState(/* No info */) async {
    // ** addr: 0x84905c, size: 0x1f4
    // 0x84905c: EnterFrame
    //     0x84905c: stp             fp, lr, [SP, #-0x10]!
    //     0x849060: mov             fp, SP
    // 0x849064: AllocStack(0x58)
    //     0x849064: sub             SP, SP, #0x58
    // 0x849068: SetupParameters(HardwareKeyboard this /* r1 => r1, fp-0x10 */)
    //     0x849068: stur            NULL, [fp, #-8]
    //     0x84906c: stur            x1, [fp, #-0x10]
    // 0x849070: CheckStackOverflow
    //     0x849070: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x849074: cmp             SP, x16
    //     0x849078: b.ls            #0x84923c
    // 0x84907c: InitAsync() -> Future<void?>
    //     0x84907c: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0x849080: bl              #0x7f5e44  ; InitAsyncStub
    // 0x849084: r16 = <int, int>
    //     0x849084: ldr             x16, [PP, #0x25a8]  ; [pp+0x25a8] TypeArguments: <int, int>
    // 0x849088: r30 = Instance_OptionalMethodChannel
    //     0x849088: ldr             lr, [PP, #0x4118]  ; [pp+0x4118] Obj!OptionalMethodChannel@129be61
    // 0x84908c: stp             lr, x16, [SP, #8]
    // 0x849090: r16 = "getKeyboardState"
    //     0x849090: ldr             x16, [PP, #0x4120]  ; [pp+0x4120] "getKeyboardState"
    // 0x849094: str             x16, [SP]
    // 0x849098: r4 = const [0x2, 0x2, 0x2, 0x2, null]
    //     0x849098: ldr             x4, [PP, #0x808]  ; [pp+0x808] List(5) [0x2, 0x2, 0x2, 0x2, Null]
    // 0x84909c: r0 = invokeMapMethod()
    //     0x84909c: bl              #0x8492b0  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMapMethod
    // 0x8490a0: mov             x1, x0
    // 0x8490a4: stur            x1, [fp, #-0x18]
    // 0x8490a8: r0 = Await()
    //     0x8490a8: bl              #0x7f5c00  ; AwaitStub
    // 0x8490ac: mov             x2, x0
    // 0x8490b0: stur            x2, [fp, #-0x18]
    // 0x8490b4: cmp             w2, NULL
    // 0x8490b8: b.eq            #0x849234
    // 0x8490bc: ldur            x3, [fp, #-0x10]
    // 0x8490c0: r0 = LoadClassIdInstr(r2)
    //     0x8490c0: ldur            x0, [x2, #-1]
    //     0x8490c4: ubfx            x0, x0, #0xc, #0x14
    // 0x8490c8: mov             x1, x2
    // 0x8490cc: r0 = GDT[cid_x0 + 0x44d]()
    //     0x8490cc: add             lr, x0, #0x44d
    //     0x8490d0: ldr             lr, [x21, lr, lsl #3]
    //     0x8490d4: blr             lr
    // 0x8490d8: r1 = LoadClassIdInstr(r0)
    //     0x8490d8: ldur            x1, [x0, #-1]
    //     0x8490dc: ubfx            x1, x1, #0xc, #0x14
    // 0x8490e0: mov             x16, x0
    // 0x8490e4: mov             x0, x1
    // 0x8490e8: mov             x1, x16
    // 0x8490ec: r0 = GDT[cid_x0 + 0x12641]()
    //     0x8490ec: mov             x17, #0x2641
    //     0x8490f0: movk            x17, #1, lsl #16
    //     0x8490f4: add             lr, x0, x17
    //     0x8490f8: ldr             lr, [x21, lr, lsl #3]
    //     0x8490fc: blr             lr
    // 0x849100: mov             x2, x0
    // 0x849104: ldur            x0, [fp, #-0x10]
    // 0x849108: stur            x2, [fp, #-0x28]
    // 0x84910c: LoadField: r3 = r0->field_7
    //     0x84910c: ldur            w3, [x0, #7]
    // 0x849110: DecompressPointer r3
    //     0x849110: add             x3, x3, HEAP, lsl #32
    // 0x849114: stur            x3, [fp, #-0x20]
    // 0x849118: ldur            x4, [fp, #-0x18]
    // 0x84911c: CheckStackOverflow
    //     0x84911c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x849120: cmp             SP, x16
    //     0x849124: b.ls            #0x849244
    // 0x849128: r0 = LoadClassIdInstr(r2)
    //     0x849128: ldur            x0, [x2, #-1]
    //     0x84912c: ubfx            x0, x0, #0xc, #0x14
    // 0x849130: mov             x1, x2
    // 0x849134: r0 = GDT[cid_x0 + 0x1845b]()
    //     0x849134: mov             x17, #0x845b
    //     0x849138: movk            x17, #1, lsl #16
    //     0x84913c: add             lr, x0, x17
    //     0x849140: ldr             lr, [x21, lr, lsl #3]
    //     0x849144: blr             lr
    // 0x849148: tbnz            w0, #4, #0x849234
    // 0x84914c: ldur            x3, [fp, #-0x18]
    // 0x849150: ldur            x2, [fp, #-0x28]
    // 0x849154: r0 = LoadClassIdInstr(r2)
    //     0x849154: ldur            x0, [x2, #-1]
    //     0x849158: ubfx            x0, x0, #0xc, #0x14
    // 0x84915c: mov             x1, x2
    // 0x849160: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0x849160: mov             x17, #0x7d4c
    //     0x849164: movk            x17, #1, lsl #16
    //     0x849168: add             lr, x0, x17
    //     0x84916c: ldr             lr, [x21, lr, lsl #3]
    //     0x849170: blr             lr
    // 0x849174: stur            x0, [fp, #-0x10]
    // 0x849178: r1 = LoadInt32Instr(r0)
    //     0x849178: sbfx            x1, x0, #1, #0x1f
    //     0x84917c: tbz             w0, #0, #0x849184
    //     0x849180: ldur            x1, [x0, #7]
    // 0x849184: stur            x1, [fp, #-0x30]
    // 0x849188: r0 = PhysicalKeyboardKey()
    //     0x849188: bl              #0x8492a4  ; AllocatePhysicalKeyboardKeyStub -> PhysicalKeyboardKey (size=0x10)
    // 0x84918c: mov             x3, x0
    // 0x849190: ldur            x0, [fp, #-0x30]
    // 0x849194: stur            x3, [fp, #-0x38]
    // 0x849198: StoreField: r3->field_7 = r0
    //     0x849198: stur            x0, [x3, #7]
    // 0x84919c: ldur            x4, [fp, #-0x18]
    // 0x8491a0: r0 = LoadClassIdInstr(r4)
    //     0x8491a0: ldur            x0, [x4, #-1]
    //     0x8491a4: ubfx            x0, x0, #0xc, #0x14
    // 0x8491a8: mov             x1, x4
    // 0x8491ac: ldur            x2, [fp, #-0x10]
    // 0x8491b0: r0 = GDT[cid_x0 + -0xd48]()
    //     0x8491b0: sub             lr, x0, #0xd48
    //     0x8491b4: ldr             lr, [x21, lr, lsl #3]
    //     0x8491b8: blr             lr
    // 0x8491bc: cmp             w0, NULL
    // 0x8491c0: b.eq            #0x84924c
    // 0x8491c4: r1 = LoadInt32Instr(r0)
    //     0x8491c4: sbfx            x1, x0, #1, #0x1f
    //     0x8491c8: tbz             w0, #0, #0x8491d0
    //     0x8491cc: ldur            x1, [x0, #7]
    // 0x8491d0: stur            x1, [fp, #-0x30]
    // 0x8491d4: r0 = LogicalKeyboardKey()
    //     0x8491d4: bl              #0x849274  ; AllocateLogicalKeyboardKeyStub -> LogicalKeyboardKey (size=0x10)
    // 0x8491d8: mov             x1, x0
    // 0x8491dc: ldur            x0, [fp, #-0x30]
    // 0x8491e0: stur            x1, [fp, #-0x40]
    // 0x8491e4: StoreField: r1->field_7 = r0
    //     0x8491e4: stur            x0, [x1, #7]
    // 0x8491e8: ldur            x0, [fp, #-0x10]
    // 0x8491ec: r2 = 60
    //     0x8491ec: mov             x2, #0x3c
    // 0x8491f0: branchIfSmi(r0, 0x8491fc)
    //     0x8491f0: tbz             w0, #0, #0x8491fc
    // 0x8491f4: r2 = LoadClassIdInstr(r0)
    //     0x8491f4: ldur            x2, [x0, #-1]
    //     0x8491f8: ubfx            x2, x2, #0xc, #0x14
    // 0x8491fc: str             x0, [SP]
    // 0x849200: mov             x0, x2
    // 0x849204: r0 = GDT[cid_x0 + 0x70de]()
    //     0x849204: mov             x17, #0x70de
    //     0x849208: add             lr, x0, x17
    //     0x84920c: ldr             lr, [x21, lr, lsl #3]
    //     0x849210: blr             lr
    // 0x849214: ldur            x1, [fp, #-0x20]
    // 0x849218: ldur            x2, [fp, #-0x38]
    // 0x84921c: ldur            x3, [fp, #-0x40]
    // 0x849220: mov             x5, x0
    // 0x849224: r0 = _set()
    //     0x849224: bl              #0x13d8170  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x849228: ldur            x2, [fp, #-0x28]
    // 0x84922c: ldur            x3, [fp, #-0x20]
    // 0x849230: b               #0x849118
    // 0x849234: r0 = Null
    //     0x849234: mov             x0, NULL
    // 0x849238: r0 = ReturnAsyncNotFuture()
    //     0x849238: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x84923c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84923c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x849240: b               #0x84907c
    // 0x849244: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x849244: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x849248: b               #0x849128
    // 0x84924c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84924c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ HardwareKeyboard(/* No info */) {
    // ** addr: 0x8494d8, size: 0xdc
    // 0x8494d8: EnterFrame
    //     0x8494d8: stp             fp, lr, [SP, #-0x10]!
    //     0x8494dc: mov             fp, SP
    // 0x8494e0: AllocStack(0x18)
    //     0x8494e0: sub             SP, SP, #0x18
    // 0x8494e4: SetupParameters(HardwareKeyboard this /* r1 => r1, fp-0x8 */)
    //     0x8494e4: stur            x1, [fp, #-8]
    // 0x8494e8: CheckStackOverflow
    //     0x8494e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8494ec: cmp             SP, x16
    //     0x8494f0: b.ls            #0x8495ac
    // 0x8494f4: r16 = <PhysicalKeyboardKey, LogicalKeyboardKey>
    //     0x8494f4: ldr             x16, [PP, #0x3aa0]  ; [pp+0x3aa0] TypeArguments: <PhysicalKeyboardKey, LogicalKeyboardKey>
    // 0x8494f8: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x8494fc: stp             lr, x16, [SP]
    // 0x849500: r0 = Map._fromLiteral()
    //     0x849500: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x849504: ldur            x2, [fp, #-8]
    // 0x849508: StoreField: r2->field_7 = r0
    //     0x849508: stur            w0, [x2, #7]
    //     0x84950c: ldurb           w16, [x2, #-1]
    //     0x849510: ldurb           w17, [x0, #-1]
    //     0x849514: and             x16, x17, x16, lsr #2
    //     0x849518: tst             x16, HEAP, lsr #32
    //     0x84951c: b.eq            #0x849524
    //     0x849520: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x849524: r1 = <KeyboardLockMode>
    //     0x849524: ldr             x1, [PP, #0x4130]  ; [pp+0x4130] TypeArguments: <KeyboardLockMode>
    // 0x849528: r0 = _Set()
    //     0x849528: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x84952c: mov             x1, x0
    // 0x849530: r0 = _Uint32List
    //     0x849530: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0x849534: StoreField: r1->field_1b = r0
    //     0x849534: stur            w0, [x1, #0x1b]
    // 0x849538: StoreField: r1->field_b = rZR
    //     0x849538: stur            wzr, [x1, #0xb]
    // 0x84953c: r0 = const []
    //     0x84953c: ldr             x0, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0x849540: StoreField: r1->field_f = r0
    //     0x849540: stur            w0, [x1, #0xf]
    // 0x849544: StoreField: r1->field_13 = rZR
    //     0x849544: stur            wzr, [x1, #0x13]
    // 0x849548: ArrayStore: r1[0] = rZR  ; List_4
    //     0x849548: stur            wzr, [x1, #0x17]
    // 0x84954c: mov             x0, x1
    // 0x849550: ldur            x3, [fp, #-8]
    // 0x849554: StoreField: r3->field_b = r0
    //     0x849554: stur            w0, [x3, #0xb]
    //     0x849558: ldurb           w16, [x3, #-1]
    //     0x84955c: ldurb           w17, [x0, #-1]
    //     0x849560: and             x16, x17, x16, lsr #2
    //     0x849564: tst             x16, HEAP, lsr #32
    //     0x849568: b.eq            #0x849570
    //     0x84956c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x849570: r1 = <(dynamic this, KeyEvent) => bool>
    //     0x849570: ldr             x1, [PP, #0x4138]  ; [pp+0x4138] TypeArguments: <(dynamic this, KeyEvent) => bool>
    // 0x849574: r2 = 0
    //     0x849574: mov             x2, #0
    // 0x849578: r0 = _GrowableList()
    //     0x849578: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x84957c: ldur            x1, [fp, #-8]
    // 0x849580: StoreField: r1->field_f = r0
    //     0x849580: stur            w0, [x1, #0xf]
    //     0x849584: ldurb           w16, [x1, #-1]
    //     0x849588: ldurb           w17, [x0, #-1]
    //     0x84958c: and             x16, x17, x16, lsr #2
    //     0x849590: tst             x16, HEAP, lsr #32
    //     0x849594: b.eq            #0x84959c
    //     0x849598: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x84959c: r0 = Null
    //     0x84959c: mov             x0, NULL
    // 0x8495a0: LeaveFrame
    //     0x8495a0: mov             SP, fp
    //     0x8495a4: ldp             fp, lr, [SP], #0x10
    // 0x8495a8: ret
    //     0x8495a8: ret             
    // 0x8495ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8495ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8495b0: b               #0x8494f4
  }
  _ handleKeyEvent(/* No info */) {
    // ** addr: 0x849de8, size: 0x184
    // 0x849de8: EnterFrame
    //     0x849de8: stp             fp, lr, [SP, #-0x10]!
    //     0x849dec: mov             fp, SP
    // 0x849df0: AllocStack(0x38)
    //     0x849df0: sub             SP, SP, #0x38
    // 0x849df4: SetupParameters(HardwareKeyboard this /* r1 => r3, fp-0x20 */, dynamic _ /* r2 => r2, fp-0x28 */)
    //     0x849df4: mov             x3, x1
    //     0x849df8: stur            x1, [fp, #-0x20]
    //     0x849dfc: stur            x2, [fp, #-0x28]
    // 0x849e00: CheckStackOverflow
    //     0x849e00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x849e04: cmp             SP, x16
    //     0x849e08: b.ls            #0x849f64
    // 0x849e0c: LoadField: r4 = r2->field_7
    //     0x849e0c: ldur            w4, [x2, #7]
    // 0x849e10: DecompressPointer r4
    //     0x849e10: add             x4, x4, HEAP, lsl #32
    // 0x849e14: stur            x4, [fp, #-0x18]
    // 0x849e18: LoadField: r5 = r2->field_b
    //     0x849e18: ldur            w5, [x2, #0xb]
    // 0x849e1c: DecompressPointer r5
    //     0x849e1c: add             x5, x5, HEAP, lsl #32
    // 0x849e20: stur            x5, [fp, #-0x10]
    // 0x849e24: r0 = LoadClassIdInstr(r2)
    //     0x849e24: ldur            x0, [x2, #-1]
    //     0x849e28: ubfx            x0, x0, #0xc, #0x14
    // 0x849e2c: r17 = 5032
    //     0x849e2c: mov             x17, #0x13a8
    // 0x849e30: cmp             x0, x17
    // 0x849e34: b.ne            #0x849eec
    // 0x849e38: LoadField: r6 = r3->field_7
    //     0x849e38: ldur            w6, [x3, #7]
    // 0x849e3c: DecompressPointer r6
    //     0x849e3c: add             x6, x6, HEAP, lsl #32
    // 0x849e40: stur            x6, [fp, #-8]
    // 0x849e44: LoadField: r7 = r4->field_7
    //     0x849e44: ldur            x7, [x4, #7]
    // 0x849e48: r0 = BoxInt64Instr(r7)
    //     0x849e48: sbfiz           x0, x7, #1, #0x1f
    //     0x849e4c: cmp             x7, x0, asr #1
    //     0x849e50: b.eq            #0x849e5c
    //     0x849e54: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x849e58: stur            x7, [x0, #7]
    // 0x849e5c: r1 = 60
    //     0x849e5c: mov             x1, #0x3c
    // 0x849e60: branchIfSmi(r0, 0x849e6c)
    //     0x849e60: tbz             w0, #0, #0x849e6c
    // 0x849e64: r1 = LoadClassIdInstr(r0)
    //     0x849e64: ldur            x1, [x0, #-1]
    //     0x849e68: ubfx            x1, x1, #0xc, #0x14
    // 0x849e6c: str             x0, [SP]
    // 0x849e70: mov             x0, x1
    // 0x849e74: r0 = GDT[cid_x0 + 0x70de]()
    //     0x849e74: mov             x17, #0x70de
    //     0x849e78: add             lr, x0, x17
    //     0x849e7c: ldr             lr, [x21, lr, lsl #3]
    //     0x849e80: blr             lr
    // 0x849e84: ldur            x1, [fp, #-8]
    // 0x849e88: ldur            x2, [fp, #-0x18]
    // 0x849e8c: ldur            x3, [fp, #-0x10]
    // 0x849e90: mov             x5, x0
    // 0x849e94: r0 = _set()
    //     0x849e94: bl              #0x13d8170  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x849e98: ldur            x1, [fp, #-0x10]
    // 0x849e9c: r0 = findLockByLogicalKey()
    //     0x849e9c: bl              #0x84a1a0  ; [package:flutter/src/services/hardware_keyboard.dart] KeyboardLockMode::findLockByLogicalKey
    // 0x849ea0: stur            x0, [fp, #-0x30]
    // 0x849ea4: cmp             w0, NULL
    // 0x849ea8: b.eq            #0x849f4c
    // 0x849eac: ldur            x3, [fp, #-0x20]
    // 0x849eb0: LoadField: r4 = r3->field_b
    //     0x849eb0: ldur            w4, [x3, #0xb]
    // 0x849eb4: DecompressPointer r4
    //     0x849eb4: add             x4, x4, HEAP, lsl #32
    // 0x849eb8: mov             x1, x4
    // 0x849ebc: mov             x2, x0
    // 0x849ec0: stur            x4, [fp, #-8]
    // 0x849ec4: r0 = contains()
    //     0x849ec4: bl              #0xbafbf4  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x849ec8: tbnz            w0, #4, #0x849edc
    // 0x849ecc: ldur            x1, [fp, #-8]
    // 0x849ed0: ldur            x2, [fp, #-0x30]
    // 0x849ed4: r0 = remove()
    //     0x849ed4: bl              #0x115bfd0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::remove
    // 0x849ed8: b               #0x849f4c
    // 0x849edc: ldur            x1, [fp, #-8]
    // 0x849ee0: ldur            x2, [fp, #-0x30]
    // 0x849ee4: r0 = add()
    //     0x849ee4: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x849ee8: b               #0x849f4c
    // 0x849eec: r17 = 5031
    //     0x849eec: mov             x17, #0x13a7
    // 0x849ef0: cmp             x0, x17
    // 0x849ef4: b.ne            #0x849f10
    // 0x849ef8: ldur            x0, [fp, #-0x20]
    // 0x849efc: LoadField: r1 = r0->field_7
    //     0x849efc: ldur            w1, [x0, #7]
    // 0x849f00: DecompressPointer r1
    //     0x849f00: add             x1, x1, HEAP, lsl #32
    // 0x849f04: ldur            x2, [fp, #-0x18]
    // 0x849f08: r0 = remove()
    //     0x849f08: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x849f0c: b               #0x849f4c
    // 0x849f10: r17 = 5030
    //     0x849f10: mov             x17, #0x13a6
    // 0x849f14: cmp             x0, x17
    // 0x849f18: b.ne            #0x849f4c
    // 0x849f1c: ldur            x1, [fp, #-0x20]
    // 0x849f20: LoadField: r0 = r1->field_7
    //     0x849f20: ldur            w0, [x1, #7]
    // 0x849f24: DecompressPointer r0
    //     0x849f24: add             x0, x0, HEAP, lsl #32
    // 0x849f28: stur            x0, [fp, #-8]
    // 0x849f2c: ldur            x16, [fp, #-0x18]
    // 0x849f30: str             x16, [SP]
    // 0x849f34: r0 = hashCode()
    //     0x849f34: bl              #0x114e904  ; [package:pdf/src/widgets/text_style.dart] TextDecoration::hashCode
    // 0x849f38: ldur            x1, [fp, #-8]
    // 0x849f3c: ldur            x2, [fp, #-0x18]
    // 0x849f40: ldur            x3, [fp, #-0x10]
    // 0x849f44: mov             x5, x0
    // 0x849f48: r0 = _set()
    //     0x849f48: bl              #0x13d8170  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x849f4c: ldur            x1, [fp, #-0x20]
    // 0x849f50: ldur            x2, [fp, #-0x28]
    // 0x849f54: r0 = _dispatchKeyEvent()
    //     0x849f54: bl              #0x849f6c  ; [package:flutter/src/services/hardware_keyboard.dart] HardwareKeyboard::_dispatchKeyEvent
    // 0x849f58: LeaveFrame
    //     0x849f58: mov             SP, fp
    //     0x849f5c: ldp             fp, lr, [SP], #0x10
    // 0x849f60: ret
    //     0x849f60: ret             
    // 0x849f64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x849f64: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x849f68: b               #0x849e0c
  }
  _ _dispatchKeyEvent(/* No info */) {
    // ** addr: 0x849f6c, size: 0x234
    // 0x849f6c: EnterFrame
    //     0x849f6c: stp             fp, lr, [SP, #-0x10]!
    //     0x849f70: mov             fp, SP
    // 0x849f74: AllocStack(0xd8)
    //     0x849f74: sub             SP, SP, #0xd8
    // 0x849f78: SetupParameters(HardwareKeyboard this /* r1 => r0, fp-0x88 */, dynamic _ /* r2 => r2, fp-0x90 */)
    //     0x849f78: mov             x0, x1
    //     0x849f7c: stur            x1, [fp, #-0x88]
    //     0x849f80: stur            x2, [fp, #-0x90]
    // 0x849f84: CheckStackOverflow
    //     0x849f84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x849f88: cmp             SP, x16
    //     0x849f8c: b.ls            #0x84a18c
    // 0x849f90: LoadField: r3 = r0->field_f
    //     0x849f90: ldur            w3, [x0, #0xf]
    // 0x849f94: DecompressPointer r3
    //     0x849f94: add             x3, x3, HEAP, lsl #32
    // 0x849f98: stur            x3, [fp, #-0x80]
    // 0x849f9c: LoadField: r1 = r3->field_7
    //     0x849f9c: ldur            w1, [x3, #7]
    // 0x849fa0: DecompressPointer r1
    //     0x849fa0: add             x1, x1, HEAP, lsl #32
    // 0x849fa4: r0 = ListIterator()
    //     0x849fa4: bl              #0x830f24  ; AllocateListIteratorStub -> ListIterator<X0> (size=0x24)
    // 0x849fa8: mov             x3, x0
    // 0x849fac: ldur            x2, [fp, #-0x80]
    // 0x849fb0: stur            x3, [fp, #-0xc0]
    // 0x849fb4: StoreField: r3->field_b = r2
    //     0x849fb4: stur            w2, [x3, #0xb]
    // 0x849fb8: LoadField: r0 = r2->field_b
    //     0x849fb8: ldur            w0, [x2, #0xb]
    // 0x849fbc: r4 = LoadInt32Instr(r0)
    //     0x849fbc: sbfx            x4, x0, #1, #0x1f
    // 0x849fc0: stur            x4, [fp, #-0xb8]
    // 0x849fc4: StoreField: r3->field_f = r4
    //     0x849fc4: stur            x4, [x3, #0xf]
    // 0x849fc8: ArrayStore: r3[0] = rZR  ; List_8
    //     0x849fc8: stur            xzr, [x3, #0x17]
    // 0x849fcc: r7 = false
    //     0x849fcc: add             x7, NULL, #0x30  ; false
    // 0x849fd0: r6 = Null
    //     0x849fd0: mov             x6, NULL
    // 0x849fd4: r5 = Null
    //     0x849fd4: mov             x5, NULL
    // 0x849fd8: stur            x7, [fp, #-0xa0]
    // 0x849fdc: stur            x6, [fp, #-0xa8]
    // 0x849fe0: stur            x5, [fp, #-0xb0]
    // 0x849fe4: CheckStackOverflow
    //     0x849fe4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x849fe8: cmp             SP, x16
    //     0x849fec: b.ls            #0x84a194
    // 0x849ff0: LoadField: r0 = r2->field_b
    //     0x849ff0: ldur            w0, [x2, #0xb]
    // 0x849ff4: r1 = LoadInt32Instr(r0)
    //     0x849ff4: sbfx            x1, x0, #1, #0x1f
    // 0x849ff8: cmp             x4, x1
    // 0x849ffc: b.ne            #0x84a16c
    // 0x84a000: ArrayLoad: r8 = r3[0]  ; List_8
    //     0x84a000: ldur            x8, [x3, #0x17]
    // 0x84a004: cmp             x8, x1
    // 0x84a008: b.ge            #0x84a154
    // 0x84a00c: mov             x0, x1
    // 0x84a010: mov             x1, x8
    // 0x84a014: cmp             x1, x0
    // 0x84a018: b.hs            #0x84a19c
    // 0x84a01c: LoadField: r0 = r2->field_f
    //     0x84a01c: ldur            w0, [x2, #0xf]
    // 0x84a020: DecompressPointer r0
    //     0x84a020: add             x0, x0, HEAP, lsl #32
    // 0x84a024: ArrayLoad: r1 = r0[r8]  ; Unknown_4
    //     0x84a024: add             x16, x0, x8, lsl #2
    //     0x84a028: ldur            w1, [x16, #0xf]
    // 0x84a02c: DecompressPointer r1
    //     0x84a02c: add             x1, x1, HEAP, lsl #32
    // 0x84a030: mov             x0, x1
    // 0x84a034: stur            x1, [fp, #-0x98]
    // 0x84a038: StoreField: r3->field_1f = r0
    //     0x84a038: stur            w0, [x3, #0x1f]
    //     0x84a03c: ldurb           w16, [x3, #-1]
    //     0x84a040: ldurb           w17, [x0, #-1]
    //     0x84a044: and             x16, x17, x16, lsr #2
    //     0x84a048: tst             x16, HEAP, lsr #32
    //     0x84a04c: b.eq            #0x84a054
    //     0x84a050: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x84a054: add             x0, x8, #1
    // 0x84a058: ArrayStore: r3[0] = r0  ; List_8
    //     0x84a058: stur            x0, [x3, #0x17]
    // 0x84a05c: ldur            x16, [fp, #-0x90]
    // 0x84a060: stp             x16, x1, [SP]
    // 0x84a064: mov             x0, x1
    // 0x84a068: ClosureCall
    //     0x84a068: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x84a06c: ldur            x2, [x0, #0x1f]
    //     0x84a070: blr             x2
    // 0x84a074: ldur            x2, [fp, #-0xa0]
    // 0x84a078: r16 = true
    //     0x84a078: add             x16, NULL, #0x20  ; true
    // 0x84a07c: cmp             w2, w16
    // 0x84a080: b.ne            #0x84a088
    // 0x84a084: r0 = true
    //     0x84a084: add             x0, NULL, #0x20  ; true
    // 0x84a088: mov             x7, x0
    // 0x84a08c: ldur            x6, [fp, #-0xa8]
    // 0x84a090: ldur            x5, [fp, #-0xb0]
    // 0x84a094: b               #0x84a144
    // 0x84a098: sub             SP, fp, #0xd8
    // 0x84a09c: ldur            x2, [fp, #-0xa0]
    // 0x84a0a0: mov             x3, x0
    // 0x84a0a4: stur            x0, [fp, #-0x98]
    // 0x84a0a8: mov             x0, x1
    // 0x84a0ac: stur            x1, [fp, #-0xa8]
    // 0x84a0b0: r1 = <List<Object>>
    //     0x84a0b0: ldr             x1, [PP, #0x860]  ; [pp+0x860] TypeArguments: <List<Object>>
    // 0x84a0b4: r0 = ErrorDescription()
    //     0x84a0b4: bl              #0x829ca4  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x2c)
    // 0x84a0b8: mov             x1, x0
    // 0x84a0bc: r2 = "while processing a key handler"
    //     0x84a0bc: ldr             x2, [PP, #0x3ad8]  ; [pp+0x3ad8] "while processing a key handler"
    // 0x84a0c0: r3 = Instance_DiagnosticLevel
    //     0x84a0c0: ldr             x3, [PP, #0x868]  ; [pp+0x868] Obj!DiagnosticLevel@12c5f41
    // 0x84a0c4: stur            x0, [fp, #-0xb0]
    // 0x84a0c8: r0 = _ErrorDiagnostic()
    //     0x84a0c8: bl              #0x829bec  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0x84a0cc: r0 = FlutterErrorDetails()
    //     0x84a0cc: bl              #0x829be0  ; AllocateFlutterErrorDetailsStub -> FlutterErrorDetails (size=0x20)
    // 0x84a0d0: mov             x1, x0
    // 0x84a0d4: ldur            x0, [fp, #-0x98]
    // 0x84a0d8: stur            x1, [fp, #-0xc8]
    // 0x84a0dc: StoreField: r1->field_7 = r0
    //     0x84a0dc: stur            w0, [x1, #7]
    // 0x84a0e0: ldur            x2, [fp, #-0xa8]
    // 0x84a0e4: StoreField: r1->field_b = r2
    //     0x84a0e4: stur            w2, [x1, #0xb]
    // 0x84a0e8: r3 = "services library"
    //     0x84a0e8: ldr             x3, [PP, #0x870]  ; [pp+0x870] "services library"
    // 0x84a0ec: StoreField: r1->field_f = r3
    //     0x84a0ec: stur            w3, [x1, #0xf]
    // 0x84a0f0: ldur            x4, [fp, #-0xb0]
    // 0x84a0f4: StoreField: r1->field_13 = r4
    //     0x84a0f4: stur            w4, [x1, #0x13]
    // 0x84a0f8: r4 = false
    //     0x84a0f8: add             x4, NULL, #0x30  ; false
    // 0x84a0fc: StoreField: r1->field_1b = r4
    //     0x84a0fc: stur            w4, [x1, #0x1b]
    // 0x84a100: r0 = LoadStaticField(0x46c)
    //     0x84a100: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x84a104: ldr             x0, [x0, #0x8d8]
    // 0x84a108: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84a10c: cmp             w0, w16
    // 0x84a110: b.ne            #0x84a11c
    // 0x84a114: r2 = onError
    //     0x84a114: ldr             x2, [PP, #0x878]  ; [pp+0x878] Field <FlutterError.onError>: static late (offset: 0x46c)
    // 0x84a118: r0 = InitLateStaticField()
    //     0x84a118: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0x84a11c: cmp             w0, NULL
    // 0x84a120: b.eq            #0x84a138
    // 0x84a124: ldur            x16, [fp, #-0xc8]
    // 0x84a128: stp             x16, x0, [SP]
    // 0x84a12c: ClosureCall
    //     0x84a12c: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x84a130: ldur            x2, [x0, #0x1f]
    //     0x84a134: blr             x2
    // 0x84a138: ldur            x7, [fp, #-0xa0]
    // 0x84a13c: ldur            x6, [fp, #-0x98]
    // 0x84a140: ldur            x5, [fp, #-0xa8]
    // 0x84a144: ldur            x2, [fp, #-0x80]
    // 0x84a148: ldur            x3, [fp, #-0xc0]
    // 0x84a14c: ldur            x4, [fp, #-0xb8]
    // 0x84a150: b               #0x849fd8
    // 0x84a154: mov             x0, x3
    // 0x84a158: StoreField: r0->field_1f = rNULL
    //     0x84a158: stur            NULL, [x0, #0x1f]
    // 0x84a15c: ldur            x0, [fp, #-0xa0]
    // 0x84a160: LeaveFrame
    //     0x84a160: mov             SP, fp
    //     0x84a164: ldp             fp, lr, [SP], #0x10
    // 0x84a168: ret
    //     0x84a168: ret             
    // 0x84a16c: mov             x0, x2
    // 0x84a170: r0 = ConcurrentModificationError()
    //     0x84a170: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x84a174: mov             x1, x0
    // 0x84a178: ldur            x0, [fp, #-0x80]
    // 0x84a17c: StoreField: r1->field_b = r0
    //     0x84a17c: stur            w0, [x1, #0xb]
    // 0x84a180: mov             x0, x1
    // 0x84a184: r0 = Throw()
    //     0x84a184: bl              #0x13ddb2c  ; ThrowStub
    // 0x84a188: brk             #0
    // 0x84a18c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84a18c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84a190: b               #0x849f90
    // 0x84a194: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84a194: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84a198: b               #0x849ff0
    // 0x84a19c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x84a19c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ lookUpLayout(/* No info */) {
    // ** addr: 0x84f8fc, size: 0x58
    // 0x84f8fc: EnterFrame
    //     0x84f8fc: stp             fp, lr, [SP, #-0x10]!
    //     0x84f900: mov             fp, SP
    // 0x84f904: AllocStack(0x8)
    //     0x84f904: sub             SP, SP, #8
    // 0x84f908: CheckStackOverflow
    //     0x84f908: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84f90c: cmp             SP, x16
    //     0x84f910: b.ls            #0x84f94c
    // 0x84f914: LoadField: r0 = r1->field_7
    //     0x84f914: ldur            w0, [x1, #7]
    // 0x84f918: DecompressPointer r0
    //     0x84f918: add             x0, x0, HEAP, lsl #32
    // 0x84f91c: mov             x1, x0
    // 0x84f920: stur            x0, [fp, #-8]
    // 0x84f924: r0 = _getValueOrData()
    //     0x84f924: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x84f928: ldur            x1, [fp, #-8]
    // 0x84f92c: LoadField: r2 = r1->field_f
    //     0x84f92c: ldur            w2, [x1, #0xf]
    // 0x84f930: DecompressPointer r2
    //     0x84f930: add             x2, x2, HEAP, lsl #32
    // 0x84f934: cmp             w2, w0
    // 0x84f938: b.ne            #0x84f940
    // 0x84f93c: r0 = Null
    //     0x84f93c: mov             x0, NULL
    // 0x84f940: LeaveFrame
    //     0x84f940: mov             SP, fp
    //     0x84f944: ldp             fp, lr, [SP], #0x10
    // 0x84f948: ret
    //     0x84f948: ret             
    // 0x84f94c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84f94c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84f950: b               #0x84f914
  }
  get _ physicalKeysPressed(/* No info */) {
    // ** addr: 0x84f954, size: 0x50
    // 0x84f954: EnterFrame
    //     0x84f954: stp             fp, lr, [SP, #-0x10]!
    //     0x84f958: mov             fp, SP
    // 0x84f95c: AllocStack(0x8)
    //     0x84f95c: sub             SP, SP, #8
    // 0x84f960: CheckStackOverflow
    //     0x84f960: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84f964: cmp             SP, x16
    //     0x84f968: b.ls            #0x84f99c
    // 0x84f96c: LoadField: r0 = r1->field_7
    //     0x84f96c: ldur            w0, [x1, #7]
    // 0x84f970: DecompressPointer r0
    //     0x84f970: add             x0, x0, HEAP, lsl #32
    // 0x84f974: stur            x0, [fp, #-8]
    // 0x84f978: r1 = <PhysicalKeyboardKey, LogicalKeyboardKey>
    //     0x84f978: ldr             x1, [PP, #0x3aa0]  ; [pp+0x3aa0] TypeArguments: <PhysicalKeyboardKey, LogicalKeyboardKey>
    // 0x84f97c: r0 = _CompactKeysIterable()
    //     0x84f97c: bl              #0x8353d0  ; Allocate_CompactKeysIterableStub -> _CompactKeysIterable<X0> (size=0x10)
    // 0x84f980: mov             x1, x0
    // 0x84f984: ldur            x0, [fp, #-8]
    // 0x84f988: StoreField: r1->field_b = r0
    //     0x84f988: stur            w0, [x1, #0xb]
    // 0x84f98c: r0 = toSet()
    //     0x84f98c: bl              #0xba60e0  ; [dart:core] _GrowableList::toSet
    // 0x84f990: LeaveFrame
    //     0x84f990: mov             SP, fp
    //     0x84f994: ldp             fp, lr, [SP], #0x10
    // 0x84f998: ret
    //     0x84f998: ret             
    // 0x84f99c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84f99c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84f9a0: b               #0x84f96c
  }
  get _ logicalKeysPressed(/* No info */) {
    // ** addr: 0xba68c8, size: 0x54
    // 0xba68c8: EnterFrame
    //     0xba68c8: stp             fp, lr, [SP, #-0x10]!
    //     0xba68cc: mov             fp, SP
    // 0xba68d0: AllocStack(0x8)
    //     0xba68d0: sub             SP, SP, #8
    // 0xba68d4: CheckStackOverflow
    //     0xba68d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba68d8: cmp             SP, x16
    //     0xba68dc: b.ls            #0xba6914
    // 0xba68e0: LoadField: r0 = r1->field_7
    //     0xba68e0: ldur            w0, [x1, #7]
    // 0xba68e4: DecompressPointer r0
    //     0xba68e4: add             x0, x0, HEAP, lsl #32
    // 0xba68e8: stur            x0, [fp, #-8]
    // 0xba68ec: r1 = <LogicalKeyboardKey>
    //     0xba68ec: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f858] TypeArguments: <LogicalKeyboardKey>
    //     0xba68f0: ldr             x1, [x1, #0x858]
    // 0xba68f4: r0 = _CompactValuesIterable()
    //     0xba68f4: bl              #0x7f3fb4  ; Allocate_CompactValuesIterableStub -> _CompactValuesIterable<X0> (size=0x10)
    // 0xba68f8: mov             x1, x0
    // 0xba68fc: ldur            x0, [fp, #-8]
    // 0xba6900: StoreField: r1->field_b = r0
    //     0xba6900: stur            w0, [x1, #0xb]
    // 0xba6904: r0 = toSet()
    //     0xba6904: bl              #0xba60e0  ; [dart:core] _GrowableList::toSet
    // 0xba6908: LeaveFrame
    //     0xba6908: mov             SP, fp
    //     0xba690c: ldp             fp, lr, [SP], #0x10
    // 0xba6910: ret
    //     0xba6910: ret             
    // 0xba6914: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba6914: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba6918: b               #0xba68e0
  }
  get _ instance(/* No info */) {
    // ** addr: 0xba691c, size: 0x48
    // 0xba691c: EnterFrame
    //     0xba691c: stp             fp, lr, [SP, #-0x10]!
    //     0xba6920: mov             fp, SP
    // 0xba6924: r1 = LoadStaticField(0x7bc)
    //     0xba6924: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0xba6928: ldr             x1, [x1, #0xf78]
    // 0xba692c: cmp             w1, NULL
    // 0xba6930: b.eq            #0xba6954
    // 0xba6934: LoadField: r0 = r1->field_8f
    //     0xba6934: ldur            w0, [x1, #0x8f]
    // 0xba6938: DecompressPointer r0
    //     0xba6938: add             x0, x0, HEAP, lsl #32
    // 0xba693c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xba6940: cmp             w0, w16
    // 0xba6944: b.eq            #0xba6958
    // 0xba6948: LeaveFrame
    //     0xba6948: mov             SP, fp
    //     0xba694c: ldp             fp, lr, [SP], #0x10
    // 0xba6950: ret
    //     0xba6950: ret             
    // 0xba6954: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xba6954: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xba6958: r9 = _keyboard
    //     0xba6958: add             x9, PP, #0x8f, lsl #12  ; [pp+0x8f860] Field <_MixinApplication204&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding@18353248._keyboard@137240726>: late final (offset: 0x90)
    //     0xba695c: ldr             x9, [x9, #0x860]
    // 0xba6960: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xba6960: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  get _ isMetaPressed(/* No info */) {
    // ** addr: 0xdb23ec, size: 0x58
    // 0xdb23ec: EnterFrame
    //     0xdb23ec: stp             fp, lr, [SP, #-0x10]!
    //     0xdb23f0: mov             fp, SP
    // 0xdb23f4: AllocStack(0x8)
    //     0xdb23f4: sub             SP, SP, #8
    // 0xdb23f8: SetupParameters(HardwareKeyboard this /* r1 => r0, fp-0x8 */)
    //     0xdb23f8: mov             x0, x1
    //     0xdb23fc: stur            x1, [fp, #-8]
    // 0xdb2400: CheckStackOverflow
    //     0xdb2400: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdb2404: cmp             SP, x16
    //     0xdb2408: b.ls            #0xdb243c
    // 0xdb240c: mov             x1, x0
    // 0xdb2410: r2 = Instance_LogicalKeyboardKey
    //     0xdb2410: ldr             x2, [PP, #0x3c28]  ; [pp+0x3c28] Obj!LogicalKeyboardKey@12abb01
    // 0xdb2414: r0 = isLogicalKeyPressed()
    //     0xdb2414: bl              #0xdb2444  ; [package:flutter/src/services/hardware_keyboard.dart] HardwareKeyboard::isLogicalKeyPressed
    // 0xdb2418: tbnz            w0, #4, #0xdb2424
    // 0xdb241c: r0 = true
    //     0xdb241c: add             x0, NULL, #0x20  ; true
    // 0xdb2420: b               #0xdb2430
    // 0xdb2424: ldur            x1, [fp, #-8]
    // 0xdb2428: r2 = Instance_LogicalKeyboardKey
    //     0xdb2428: ldr             x2, [PP, #0x3c38]  ; [pp+0x3c38] Obj!LogicalKeyboardKey@12abaf1
    // 0xdb242c: r0 = isLogicalKeyPressed()
    //     0xdb242c: bl              #0xdb2444  ; [package:flutter/src/services/hardware_keyboard.dart] HardwareKeyboard::isLogicalKeyPressed
    // 0xdb2430: LeaveFrame
    //     0xdb2430: mov             SP, fp
    //     0xdb2434: ldp             fp, lr, [SP], #0x10
    // 0xdb2438: ret
    //     0xdb2438: ret             
    // 0xdb243c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdb243c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdb2440: b               #0xdb240c
  }
  _ isLogicalKeyPressed(/* No info */) {
    // ** addr: 0xdb2444, size: 0x5c
    // 0xdb2444: EnterFrame
    //     0xdb2444: stp             fp, lr, [SP, #-0x10]!
    //     0xdb2448: mov             fp, SP
    // 0xdb244c: AllocStack(0x10)
    //     0xdb244c: sub             SP, SP, #0x10
    // 0xdb2450: SetupParameters(dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xdb2450: stur            x2, [fp, #-0x10]
    // 0xdb2454: CheckStackOverflow
    //     0xdb2454: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdb2458: cmp             SP, x16
    //     0xdb245c: b.ls            #0xdb2498
    // 0xdb2460: LoadField: r0 = r1->field_7
    //     0xdb2460: ldur            w0, [x1, #7]
    // 0xdb2464: DecompressPointer r0
    //     0xdb2464: add             x0, x0, HEAP, lsl #32
    // 0xdb2468: stur            x0, [fp, #-8]
    // 0xdb246c: r1 = <LogicalKeyboardKey>
    //     0xdb246c: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f858] TypeArguments: <LogicalKeyboardKey>
    //     0xdb2470: ldr             x1, [x1, #0x858]
    // 0xdb2474: r0 = _CompactValuesIterable()
    //     0xdb2474: bl              #0x7f3fb4  ; Allocate_CompactValuesIterableStub -> _CompactValuesIterable<X0> (size=0x10)
    // 0xdb2478: mov             x1, x0
    // 0xdb247c: ldur            x0, [fp, #-8]
    // 0xdb2480: StoreField: r1->field_b = r0
    //     0xdb2480: stur            w0, [x1, #0xb]
    // 0xdb2484: ldur            x2, [fp, #-0x10]
    // 0xdb2488: r0 = contains()
    //     0xdb2488: bl              #0xb040c0  ; [dart:core] Iterable::contains
    // 0xdb248c: LeaveFrame
    //     0xdb248c: mov             SP, fp
    //     0xdb2490: ldp             fp, lr, [SP], #0x10
    // 0xdb2494: ret
    //     0xdb2494: ret             
    // 0xdb2498: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdb2498: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdb249c: b               #0xdb2460
  }
  get _ isControlPressed(/* No info */) {
    // ** addr: 0xdb24a0, size: 0x58
    // 0xdb24a0: EnterFrame
    //     0xdb24a0: stp             fp, lr, [SP, #-0x10]!
    //     0xdb24a4: mov             fp, SP
    // 0xdb24a8: AllocStack(0x8)
    //     0xdb24a8: sub             SP, SP, #8
    // 0xdb24ac: SetupParameters(HardwareKeyboard this /* r1 => r0, fp-0x8 */)
    //     0xdb24ac: mov             x0, x1
    //     0xdb24b0: stur            x1, [fp, #-8]
    // 0xdb24b4: CheckStackOverflow
    //     0xdb24b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdb24b8: cmp             SP, x16
    //     0xdb24bc: b.ls            #0xdb24f0
    // 0xdb24c0: mov             x1, x0
    // 0xdb24c4: r2 = Instance_LogicalKeyboardKey
    //     0xdb24c4: ldr             x2, [PP, #0x3c08]  ; [pp+0x3c08] Obj!LogicalKeyboardKey@12abb61
    // 0xdb24c8: r0 = isLogicalKeyPressed()
    //     0xdb24c8: bl              #0xdb2444  ; [package:flutter/src/services/hardware_keyboard.dart] HardwareKeyboard::isLogicalKeyPressed
    // 0xdb24cc: tbnz            w0, #4, #0xdb24d8
    // 0xdb24d0: r0 = true
    //     0xdb24d0: add             x0, NULL, #0x20  ; true
    // 0xdb24d4: b               #0xdb24e4
    // 0xdb24d8: ldur            x1, [fp, #-8]
    // 0xdb24dc: r2 = Instance_LogicalKeyboardKey
    //     0xdb24dc: ldr             x2, [PP, #0x3c18]  ; [pp+0x3c18] Obj!LogicalKeyboardKey@12abb51
    // 0xdb24e0: r0 = isLogicalKeyPressed()
    //     0xdb24e0: bl              #0xdb2444  ; [package:flutter/src/services/hardware_keyboard.dart] HardwareKeyboard::isLogicalKeyPressed
    // 0xdb24e4: LeaveFrame
    //     0xdb24e4: mov             SP, fp
    //     0xdb24e8: ldp             fp, lr, [SP], #0x10
    // 0xdb24ec: ret
    //     0xdb24ec: ret             
    // 0xdb24f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdb24f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdb24f4: b               #0xdb24c0
  }
}

// class id: 5029, size: 0x10, field offset: 0x8
//   const constructor, 
abstract class KeyEvent extends _MixinApplication3&Object&Diagnosticable {
}

// class id: 5030, size: 0x10, field offset: 0x10
//   const constructor, 
class KeyRepeatEvent extends KeyEvent {
}

// class id: 5031, size: 0x10, field offset: 0x10
//   const constructor, 
class KeyUpEvent extends KeyEvent {
}

// class id: 5032, size: 0x10, field offset: 0x10
//   const constructor, 
class KeyDownEvent extends KeyEvent {
}

// class id: 8208, size: 0x14, field offset: 0x14
enum KeyDataTransitMode extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11ab610, size: 0x64
    // 0x11ab610: EnterFrame
    //     0x11ab610: stp             fp, lr, [SP, #-0x10]!
    //     0x11ab614: mov             fp, SP
    // 0x11ab618: AllocStack(0x10)
    //     0x11ab618: sub             SP, SP, #0x10
    // 0x11ab61c: SetupParameters(KeyDataTransitMode this /* r1 => r0, fp-0x8 */)
    //     0x11ab61c: mov             x0, x1
    //     0x11ab620: stur            x1, [fp, #-8]
    // 0x11ab624: CheckStackOverflow
    //     0x11ab624: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11ab628: cmp             SP, x16
    //     0x11ab62c: b.ls            #0x11ab66c
    // 0x11ab630: r1 = Null
    //     0x11ab630: mov             x1, NULL
    // 0x11ab634: r2 = 4
    //     0x11ab634: mov             x2, #4
    // 0x11ab638: r0 = AllocateArray()
    //     0x11ab638: bl              #0x13df928  ; AllocateArrayStub
    // 0x11ab63c: r16 = "KeyDataTransitMode."
    //     0x11ab63c: add             x16, PP, #0x10, lsl #12  ; [pp+0x10df8] "KeyDataTransitMode."
    //     0x11ab640: ldr             x16, [x16, #0xdf8]
    // 0x11ab644: StoreField: r0->field_f = r16
    //     0x11ab644: stur            w16, [x0, #0xf]
    // 0x11ab648: ldur            x1, [fp, #-8]
    // 0x11ab64c: LoadField: r2 = r1->field_f
    //     0x11ab64c: ldur            w2, [x1, #0xf]
    // 0x11ab650: DecompressPointer r2
    //     0x11ab650: add             x2, x2, HEAP, lsl #32
    // 0x11ab654: StoreField: r0->field_13 = r2
    //     0x11ab654: stur            w2, [x0, #0x13]
    // 0x11ab658: str             x0, [SP]
    // 0x11ab65c: r0 = _interpolate()
    //     0x11ab65c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11ab660: LeaveFrame
    //     0x11ab660: mov             SP, fp
    //     0x11ab664: ldp             fp, lr, [SP], #0x10
    // 0x11ab668: ret
    //     0x11ab668: ret             
    // 0x11ab66c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11ab66c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11ab670: b               #0x11ab630
  }
}

// class id: 8209, size: 0x18, field offset: 0x14
enum KeyboardLockMode extends _Enum {

  static late final Map<int, KeyboardLockMode> _knownLockModes; // offset: 0x800
  _Mint field_8;
  _OneByteString field_10;
  LogicalKeyboardKey field_14;

  static _ findLockByLogicalKey(/* No info */) {
    // ** addr: 0x84a1a0, size: 0x94
    // 0x84a1a0: EnterFrame
    //     0x84a1a0: stp             fp, lr, [SP, #-0x10]!
    //     0x84a1a4: mov             fp, SP
    // 0x84a1a8: AllocStack(0x10)
    //     0x84a1a8: sub             SP, SP, #0x10
    // 0x84a1ac: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0x84a1ac: stur            x1, [fp, #-8]
    // 0x84a1b0: CheckStackOverflow
    //     0x84a1b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84a1b4: cmp             SP, x16
    //     0x84a1b8: b.ls            #0x84a22c
    // 0x84a1bc: r0 = LoadStaticField(0x800)
    //     0x84a1bc: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x84a1c0: ldr             x0, [x0, #0x1000]
    // 0x84a1c4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84a1c8: cmp             w0, w16
    // 0x84a1cc: b.ne            #0x84a1d8
    // 0x84a1d0: r2 = _knownLockModes
    //     0x84a1d0: ldr             x2, [PP, #0x3ae0]  ; [pp+0x3ae0] Field <KeyboardLockMode._knownLockModes@167443624>: static late final (offset: 0x800)
    // 0x84a1d4: r0 = InitLateFinalStaticField()
    //     0x84a1d4: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x84a1d8: mov             x3, x0
    // 0x84a1dc: ldur            x0, [fp, #-8]
    // 0x84a1e0: stur            x3, [fp, #-0x10]
    // 0x84a1e4: LoadField: r2 = r0->field_7
    //     0x84a1e4: ldur            x2, [x0, #7]
    // 0x84a1e8: r0 = BoxInt64Instr(r2)
    //     0x84a1e8: sbfiz           x0, x2, #1, #0x1f
    //     0x84a1ec: cmp             x2, x0, asr #1
    //     0x84a1f0: b.eq            #0x84a1fc
    //     0x84a1f4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x84a1f8: stur            x2, [x0, #7]
    // 0x84a1fc: mov             x1, x3
    // 0x84a200: mov             x2, x0
    // 0x84a204: r0 = _getValueOrData()
    //     0x84a204: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x84a208: ldur            x1, [fp, #-0x10]
    // 0x84a20c: LoadField: r2 = r1->field_f
    //     0x84a20c: ldur            w2, [x1, #0xf]
    // 0x84a210: DecompressPointer r2
    //     0x84a210: add             x2, x2, HEAP, lsl #32
    // 0x84a214: cmp             w2, w0
    // 0x84a218: b.ne            #0x84a220
    // 0x84a21c: r0 = Null
    //     0x84a21c: mov             x0, NULL
    // 0x84a220: LeaveFrame
    //     0x84a220: mov             SP, fp
    //     0x84a224: ldp             fp, lr, [SP], #0x10
    // 0x84a228: ret
    //     0x84a228: ret             
    // 0x84a22c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84a22c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84a230: b               #0x84a1bc
  }
  static Map<int, KeyboardLockMode> _knownLockModes() {
    // ** addr: 0x84a234, size: 0xc8
    // 0x84a234: EnterFrame
    //     0x84a234: stp             fp, lr, [SP, #-0x10]!
    //     0x84a238: mov             fp, SP
    // 0x84a23c: AllocStack(0x18)
    //     0x84a23c: sub             SP, SP, #0x18
    // 0x84a240: r0 = Instance_LogicalKeyboardKey
    //     0x84a240: ldr             x0, [PP, #0x3ae8]  ; [pp+0x3ae8] Obj!LogicalKeyboardKey@12ab771
    // 0x84a244: CheckStackOverflow
    //     0x84a244: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84a248: cmp             SP, x16
    //     0x84a24c: b.ls            #0x84a2f4
    // 0x84a250: LoadField: r2 = r0->field_7
    //     0x84a250: ldur            x2, [x0, #7]
    // 0x84a254: r0 = BoxInt64Instr(r2)
    //     0x84a254: sbfiz           x0, x2, #1, #0x1f
    //     0x84a258: cmp             x2, x0, asr #1
    //     0x84a25c: b.eq            #0x84a268
    //     0x84a260: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x84a264: stur            x2, [x0, #7]
    // 0x84a268: r1 = Null
    //     0x84a268: mov             x1, NULL
    // 0x84a26c: r2 = 12
    //     0x84a26c: mov             x2, #0xc
    // 0x84a270: stur            x0, [fp, #-8]
    // 0x84a274: r0 = AllocateArray()
    //     0x84a274: bl              #0x13df928  ; AllocateArrayStub
    // 0x84a278: mov             x2, x0
    // 0x84a27c: ldur            x0, [fp, #-8]
    // 0x84a280: StoreField: r2->field_f = r0
    //     0x84a280: stur            w0, [x2, #0xf]
    // 0x84a284: r16 = Instance_KeyboardLockMode
    //     0x84a284: ldr             x16, [PP, #0x3af0]  ; [pp+0x3af0] Obj!KeyboardLockMode@12c3e61
    // 0x84a288: StoreField: r2->field_13 = r16
    //     0x84a288: stur            w16, [x2, #0x13]
    // 0x84a28c: r0 = Instance_LogicalKeyboardKey
    //     0x84a28c: ldr             x0, [PP, #0x3af8]  ; [pp+0x3af8] Obj!LogicalKeyboardKey@12ab761
    // 0x84a290: LoadField: r3 = r0->field_7
    //     0x84a290: ldur            x3, [x0, #7]
    // 0x84a294: r0 = BoxInt64Instr(r3)
    //     0x84a294: sbfiz           x0, x3, #1, #0x1f
    //     0x84a298: cmp             x3, x0, asr #1
    //     0x84a29c: b.eq            #0x84a2a8
    //     0x84a2a0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x84a2a4: stur            x3, [x0, #7]
    // 0x84a2a8: ArrayStore: r2[0] = r0  ; List_4
    //     0x84a2a8: stur            w0, [x2, #0x17]
    // 0x84a2ac: r16 = Instance_KeyboardLockMode
    //     0x84a2ac: ldr             x16, [PP, #0x3b00]  ; [pp+0x3b00] Obj!KeyboardLockMode@12c3e41
    // 0x84a2b0: StoreField: r2->field_1b = r16
    //     0x84a2b0: stur            w16, [x2, #0x1b]
    // 0x84a2b4: r0 = Instance_LogicalKeyboardKey
    //     0x84a2b4: ldr             x0, [PP, #0x3b08]  ; [pp+0x3b08] Obj!LogicalKeyboardKey@12ab751
    // 0x84a2b8: LoadField: r3 = r0->field_7
    //     0x84a2b8: ldur            x3, [x0, #7]
    // 0x84a2bc: r0 = BoxInt64Instr(r3)
    //     0x84a2bc: sbfiz           x0, x3, #1, #0x1f
    //     0x84a2c0: cmp             x3, x0, asr #1
    //     0x84a2c4: b.eq            #0x84a2d0
    //     0x84a2c8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x84a2cc: stur            x3, [x0, #7]
    // 0x84a2d0: StoreField: r2->field_1f = r0
    //     0x84a2d0: stur            w0, [x2, #0x1f]
    // 0x84a2d4: r16 = Instance_KeyboardLockMode
    //     0x84a2d4: ldr             x16, [PP, #0x3b10]  ; [pp+0x3b10] Obj!KeyboardLockMode@12c3e21
    // 0x84a2d8: StoreField: r2->field_23 = r16
    //     0x84a2d8: stur            w16, [x2, #0x23]
    // 0x84a2dc: r16 = <int, KeyboardLockMode>
    //     0x84a2dc: ldr             x16, [PP, #0x3b18]  ; [pp+0x3b18] TypeArguments: <int, KeyboardLockMode>
    // 0x84a2e0: stp             x2, x16, [SP]
    // 0x84a2e4: r0 = Map._fromLiteral()
    //     0x84a2e4: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x84a2e8: LeaveFrame
    //     0x84a2e8: mov             SP, fp
    //     0x84a2ec: ldp             fp, lr, [SP], #0x10
    // 0x84a2f0: ret
    //     0x84a2f0: ret             
    // 0x84a2f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84a2f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84a2f8: b               #0x84a250
  }
  _ _enumToString(/* No info */) {
    // ** addr: 0x11ab5ac, size: 0x64
    // 0x11ab5ac: EnterFrame
    //     0x11ab5ac: stp             fp, lr, [SP, #-0x10]!
    //     0x11ab5b0: mov             fp, SP
    // 0x11ab5b4: AllocStack(0x10)
    //     0x11ab5b4: sub             SP, SP, #0x10
    // 0x11ab5b8: SetupParameters(KeyboardLockMode this /* r1 => r0, fp-0x8 */)
    //     0x11ab5b8: mov             x0, x1
    //     0x11ab5bc: stur            x1, [fp, #-8]
    // 0x11ab5c0: CheckStackOverflow
    //     0x11ab5c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11ab5c4: cmp             SP, x16
    //     0x11ab5c8: b.ls            #0x11ab608
    // 0x11ab5cc: r1 = Null
    //     0x11ab5cc: mov             x1, NULL
    // 0x11ab5d0: r2 = 4
    //     0x11ab5d0: mov             x2, #4
    // 0x11ab5d4: r0 = AllocateArray()
    //     0x11ab5d4: bl              #0x13df928  ; AllocateArrayStub
    // 0x11ab5d8: r16 = "KeyboardLockMode."
    //     0x11ab5d8: add             x16, PP, #0x10, lsl #12  ; [pp+0x10e00] "KeyboardLockMode."
    //     0x11ab5dc: ldr             x16, [x16, #0xe00]
    // 0x11ab5e0: StoreField: r0->field_f = r16
    //     0x11ab5e0: stur            w16, [x0, #0xf]
    // 0x11ab5e4: ldur            x1, [fp, #-8]
    // 0x11ab5e8: LoadField: r2 = r1->field_f
    //     0x11ab5e8: ldur            w2, [x1, #0xf]
    // 0x11ab5ec: DecompressPointer r2
    //     0x11ab5ec: add             x2, x2, HEAP, lsl #32
    // 0x11ab5f0: StoreField: r0->field_13 = r2
    //     0x11ab5f0: stur            w2, [x0, #0x13]
    // 0x11ab5f4: str             x0, [SP]
    // 0x11ab5f8: r0 = _interpolate()
    //     0x11ab5f8: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11ab5fc: LeaveFrame
    //     0x11ab5fc: mov             SP, fp
    //     0x11ab600: ldp             fp, lr, [SP], #0x10
    // 0x11ab604: ret
    //     0x11ab604: ret             
    // 0x11ab608: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11ab608: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11ab60c: b               #0x11ab5cc
  }
}
