// lib: , url: package:flutter/src/services/raw_keyboard_linux.dart

// class id: 1049090, size: 0x8
class :: {
}

// class id: 2750, size: 0x8, field offset: 0x8
class GtkKeyHelper extends Object
    implements KeyHelper {

  get _ platformPlane(/* No info */) {
    // ** addr: 0x13095bc, size: 0xc
    // 0x13095bc: r0 = 90194313216
    //     0x13095bc: add             x0, PP, #0x10, lsl #12  ; [pp+0x10c98] IMM: 0x1500000000
    //     0x13095c0: ldr             x0, [x0, #0xc98]
    // 0x13095c4: ret
    //     0x13095c4: ret             
  }
  _ logicalKey(/* No info */) {
    // ** addr: 0x130b494, size: 0x4c
    // 0x130b494: EnterFrame
    //     0x130b494: stp             fp, lr, [SP, #-0x10]!
    //     0x130b498: mov             fp, SP
    // 0x130b49c: CheckStackOverflow
    //     0x130b49c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x130b4a0: cmp             SP, x16
    //     0x130b4a4: b.ls            #0x130b4d8
    // 0x130b4a8: r0 = BoxInt64Instr(r2)
    //     0x130b4a8: sbfiz           x0, x2, #1, #0x1f
    //     0x130b4ac: cmp             x2, x0, asr #1
    //     0x130b4b0: b.eq            #0x130b4bc
    //     0x130b4b4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x130b4b8: stur            x2, [x0, #7]
    // 0x130b4bc: mov             x2, x0
    // 0x130b4c0: r1 = _ConstMap len:171
    //     0x130b4c0: add             x1, PP, #0x10, lsl #12  ; [pp+0x10ca0] Map<int, LogicalKeyboardKey>(171)
    //     0x130b4c4: ldr             x1, [x1, #0xca0]
    // 0x130b4c8: r0 = []()
    //     0x130b4c8: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x130b4cc: LeaveFrame
    //     0x130b4cc: mov             SP, fp
    //     0x130b4d0: ldp             fp, lr, [SP], #0x10
    // 0x130b4d4: ret
    //     0x130b4d4: ret             
    // 0x130b4d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x130b4d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x130b4dc: b               #0x130b4a8
  }
  _ numpadKey(/* No info */) {
    // ** addr: 0x130b52c, size: 0x4c
    // 0x130b52c: EnterFrame
    //     0x130b52c: stp             fp, lr, [SP, #-0x10]!
    //     0x130b530: mov             fp, SP
    // 0x130b534: CheckStackOverflow
    //     0x130b534: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x130b538: cmp             SP, x16
    //     0x130b53c: b.ls            #0x130b570
    // 0x130b540: r0 = BoxInt64Instr(r2)
    //     0x130b540: sbfiz           x0, x2, #1, #0x1f
    //     0x130b544: cmp             x2, x0, asr #1
    //     0x130b548: b.eq            #0x130b554
    //     0x130b54c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x130b550: stur            x2, [x0, #7]
    // 0x130b554: mov             x2, x0
    // 0x130b558: r1 = _ConstMap len:25
    //     0x130b558: add             x1, PP, #0x10, lsl #12  ; [pp+0x10ca8] Map<int, LogicalKeyboardKey>(25)
    //     0x130b55c: ldr             x1, [x1, #0xca8]
    // 0x130b560: r0 = []()
    //     0x130b560: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x130b564: LeaveFrame
    //     0x130b564: mov             SP, fp
    //     0x130b568: ldp             fp, lr, [SP], #0x10
    // 0x130b56c: ret
    //     0x130b56c: ret             
    // 0x130b570: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x130b570: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x130b574: b               #0x130b540
  }
  _ getModifierSide(/* No info */) {
    // ** addr: 0x130b578, size: 0x8
    // 0x130b578: r0 = Instance_KeyboardSide
    //     0x130b578: ldr             x0, [PP, #0x3b60]  ; [pp+0x3b60] Obj!KeyboardSide@12c3cc1
    // 0x130b57c: ret
    //     0x130b57c: ret             
  }
  _ isModifierPressed(/* No info */) {
    // ** addr: 0x130b74c, size: 0x200
    // 0x130b74c: r17 = 65505
    //     0x130b74c: mov             x17, #0xffe1
    // 0x130b750: cmp             x6, x17
    // 0x130b754: b.eq            #0x130b764
    // 0x130b758: r17 = 65506
    //     0x130b758: mov             x17, #0xffe2
    // 0x130b75c: cmp             x6, x17
    // 0x130b760: b.ne            #0x130b76c
    // 0x130b764: r1 = 1
    //     0x130b764: mov             x1, #1
    // 0x130b768: b               #0x130b804
    // 0x130b76c: r17 = 65507
    //     0x130b76c: mov             x17, #0xffe3
    // 0x130b770: cmp             x6, x17
    // 0x130b774: b.eq            #0x130b784
    // 0x130b778: r17 = 65508
    //     0x130b778: mov             x17, #0xffe4
    // 0x130b77c: cmp             x6, x17
    // 0x130b780: b.ne            #0x130b78c
    // 0x130b784: r1 = 4
    //     0x130b784: mov             x1, #4
    // 0x130b788: b               #0x130b804
    // 0x130b78c: r17 = 65513
    //     0x130b78c: mov             x17, #0xffe9
    // 0x130b790: cmp             x6, x17
    // 0x130b794: b.eq            #0x130b7a4
    // 0x130b798: r17 = 65514
    //     0x130b798: mov             x17, #0xffea
    // 0x130b79c: cmp             x6, x17
    // 0x130b7a0: b.ne            #0x130b7ac
    // 0x130b7a4: r1 = 8
    //     0x130b7a4: mov             x1, #8
    // 0x130b7a8: b               #0x130b804
    // 0x130b7ac: r17 = 65515
    //     0x130b7ac: mov             x17, #0xffeb
    // 0x130b7b0: cmp             x6, x17
    // 0x130b7b4: b.eq            #0x130b7c4
    // 0x130b7b8: r17 = 65516
    //     0x130b7b8: mov             x17, #0xffec
    // 0x130b7bc: cmp             x6, x17
    // 0x130b7c0: b.ne            #0x130b7cc
    // 0x130b7c4: r1 = 67108864
    //     0x130b7c4: mov             x1, #0x4000000
    // 0x130b7c8: b               #0x130b804
    // 0x130b7cc: r17 = 65509
    //     0x130b7cc: mov             x17, #0xffe5
    // 0x130b7d0: cmp             x6, x17
    // 0x130b7d4: b.eq            #0x130b7e4
    // 0x130b7d8: r17 = 65510
    //     0x130b7d8: mov             x17, #0xffe6
    // 0x130b7dc: cmp             x6, x17
    // 0x130b7e0: b.ne            #0x130b7ec
    // 0x130b7e4: r1 = 2
    //     0x130b7e4: mov             x1, #2
    // 0x130b7e8: b               #0x130b804
    // 0x130b7ec: r17 = 65407
    //     0x130b7ec: mov             x17, #0xff7f
    // 0x130b7f0: cmp             x6, x17
    // 0x130b7f4: b.ne            #0x130b800
    // 0x130b7f8: r1 = 16
    //     0x130b7f8: mov             x1, #0x10
    // 0x130b7fc: b               #0x130b804
    // 0x130b800: r1 = 0
    //     0x130b800: mov             x1, #0
    // 0x130b804: tbnz            w5, #4, #0x130b814
    // 0x130b808: orr             x4, x3, x1
    // 0x130b80c: mov             x1, x4
    // 0x130b810: b               #0x130b81c
    // 0x130b814: mvn             x4, x1
    // 0x130b818: and             x1, x3, x4
    // 0x130b81c: LoadField: r3 = r2->field_7
    //     0x130b81c: ldur            x3, [x2, #7]
    // 0x130b820: cmp             x3, #4
    // 0x130b824: b.gt            #0x130b8fc
    // 0x130b828: cmp             x3, #2
    // 0x130b82c: b.gt            #0x130b8ac
    // 0x130b830: cmp             x3, #1
    // 0x130b834: b.gt            #0x130b888
    // 0x130b838: cmp             x3, #0
    // 0x130b83c: b.gt            #0x130b864
    // 0x130b840: mov             x2, x1
    // 0x130b844: ubfx            x2, x2, #0, #0x20
    // 0x130b848: and             w4, w2, #4
    // 0x130b84c: cbnz            w4, #0x130b858
    // 0x130b850: r2 = false
    //     0x130b850: add             x2, NULL, #0x30  ; false
    // 0x130b854: b               #0x130b85c
    // 0x130b858: r2 = true
    //     0x130b858: add             x2, NULL, #0x20  ; true
    // 0x130b85c: mov             x0, x2
    // 0x130b860: b               #0x130b948
    // 0x130b864: mov             x2, x1
    // 0x130b868: ubfx            x2, x2, #0, #0x20
    // 0x130b86c: and             w4, w2, #1
    // 0x130b870: cbnz            w4, #0x130b87c
    // 0x130b874: r2 = false
    //     0x130b874: add             x2, NULL, #0x30  ; false
    // 0x130b878: b               #0x130b880
    // 0x130b87c: r2 = true
    //     0x130b87c: add             x2, NULL, #0x20  ; true
    // 0x130b880: mov             x0, x2
    // 0x130b884: b               #0x130b948
    // 0x130b888: mov             x2, x1
    // 0x130b88c: ubfx            x2, x2, #0, #0x20
    // 0x130b890: and             w4, w2, #8
    // 0x130b894: cbnz            w4, #0x130b8a0
    // 0x130b898: r2 = false
    //     0x130b898: add             x2, NULL, #0x30  ; false
    // 0x130b89c: b               #0x130b8a4
    // 0x130b8a0: r2 = true
    //     0x130b8a0: add             x2, NULL, #0x20  ; true
    // 0x130b8a4: mov             x0, x2
    // 0x130b8a8: b               #0x130b948
    // 0x130b8ac: cmp             x3, #3
    // 0x130b8b0: b.gt            #0x130b8d8
    // 0x130b8b4: mov             x2, x1
    // 0x130b8b8: ubfx            x2, x2, #0, #0x20
    // 0x130b8bc: and             w4, w2, #0x4000000
    // 0x130b8c0: cbnz            w4, #0x130b8cc
    // 0x130b8c4: r2 = false
    //     0x130b8c4: add             x2, NULL, #0x30  ; false
    // 0x130b8c8: b               #0x130b8d0
    // 0x130b8cc: r2 = true
    //     0x130b8cc: add             x2, NULL, #0x20  ; true
    // 0x130b8d0: mov             x0, x2
    // 0x130b8d4: b               #0x130b948
    // 0x130b8d8: mov             x2, x1
    // 0x130b8dc: ubfx            x2, x2, #0, #0x20
    // 0x130b8e0: and             w4, w2, #2
    // 0x130b8e4: cbnz            w4, #0x130b8f0
    // 0x130b8e8: r2 = false
    //     0x130b8e8: add             x2, NULL, #0x30  ; false
    // 0x130b8ec: b               #0x130b8f4
    // 0x130b8f0: r2 = true
    //     0x130b8f0: add             x2, NULL, #0x20  ; true
    // 0x130b8f4: mov             x0, x2
    // 0x130b8f8: b               #0x130b948
    // 0x130b8fc: cmp             x3, #6
    // 0x130b900: b.gt            #0x130b934
    // 0x130b904: cmp             x3, #5
    // 0x130b908: b.gt            #0x130b92c
    // 0x130b90c: ubfx            x1, x1, #0, #0x20
    // 0x130b910: and             w2, w1, #0x10
    // 0x130b914: cbnz            w2, #0x130b920
    // 0x130b918: r1 = false
    //     0x130b918: add             x1, NULL, #0x30  ; false
    // 0x130b91c: b               #0x130b924
    // 0x130b920: r1 = true
    //     0x130b920: add             x1, NULL, #0x20  ; true
    // 0x130b924: mov             x0, x1
    // 0x130b928: b               #0x130b948
    // 0x130b92c: r0 = false
    //     0x130b92c: add             x0, NULL, #0x30  ; false
    // 0x130b930: b               #0x130b948
    // 0x130b934: cmp             x3, #7
    // 0x130b938: b.gt            #0x130b944
    // 0x130b93c: r0 = false
    //     0x130b93c: add             x0, NULL, #0x30  ; false
    // 0x130b940: b               #0x130b948
    // 0x130b944: r0 = false
    //     0x130b944: add             x0, NULL, #0x30  ; false
    // 0x130b948: ret
    //     0x130b948: ret             
  }
}

// class id: 2751, size: 0x8, field offset: 0x8
class GLFWKeyHelper extends Object
    implements KeyHelper {

  get _ platformPlane(/* No info */) {
    // ** addr: 0x13095b4, size: 0x8
    // 0x13095b4: r0 = 103079215104
    //     0x13095b4: mov             x0, #0x1800000000
    // 0x13095b8: ret
    //     0x13095b8: ret             
  }
  _ logicalKey(/* No info */) {
    // ** addr: 0x130b448, size: 0x4c
    // 0x130b448: EnterFrame
    //     0x130b448: stp             fp, lr, [SP, #-0x10]!
    //     0x130b44c: mov             fp, SP
    // 0x130b450: CheckStackOverflow
    //     0x130b450: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x130b454: cmp             SP, x16
    //     0x130b458: b.ls            #0x130b48c
    // 0x130b45c: r0 = BoxInt64Instr(r2)
    //     0x130b45c: sbfiz           x0, x2, #1, #0x1f
    //     0x130b460: cmp             x2, x0, asr #1
    //     0x130b464: b.eq            #0x130b470
    //     0x130b468: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x130b46c: stur            x2, [x0, #7]
    // 0x130b470: mov             x2, x0
    // 0x130b474: r1 = _ConstMap len:114
    //     0x130b474: add             x1, PP, #0x10, lsl #12  ; [pp+0x10cb0] Map<int, LogicalKeyboardKey>(114)
    //     0x130b478: ldr             x1, [x1, #0xcb0]
    // 0x130b47c: r0 = []()
    //     0x130b47c: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x130b480: LeaveFrame
    //     0x130b480: mov             SP, fp
    //     0x130b484: ldp             fp, lr, [SP], #0x10
    // 0x130b488: ret
    //     0x130b488: ret             
    // 0x130b48c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x130b48c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x130b490: b               #0x130b45c
  }
  _ numpadKey(/* No info */) {
    // ** addr: 0x130b4e0, size: 0x4c
    // 0x130b4e0: EnterFrame
    //     0x130b4e0: stp             fp, lr, [SP, #-0x10]!
    //     0x130b4e4: mov             fp, SP
    // 0x130b4e8: CheckStackOverflow
    //     0x130b4e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x130b4ec: cmp             SP, x16
    //     0x130b4f0: b.ls            #0x130b524
    // 0x130b4f4: r0 = BoxInt64Instr(r2)
    //     0x130b4f4: sbfiz           x0, x2, #1, #0x1f
    //     0x130b4f8: cmp             x2, x0, asr #1
    //     0x130b4fc: b.eq            #0x130b508
    //     0x130b500: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x130b504: stur            x2, [x0, #7]
    // 0x130b508: mov             x2, x0
    // 0x130b50c: r1 = _ConstMap len:15
    //     0x130b50c: add             x1, PP, #0x10, lsl #12  ; [pp+0x10cb8] Map<int, LogicalKeyboardKey>(15)
    //     0x130b510: ldr             x1, [x1, #0xcb8]
    // 0x130b514: r0 = []()
    //     0x130b514: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x130b518: LeaveFrame
    //     0x130b518: mov             SP, fp
    //     0x130b51c: ldp             fp, lr, [SP], #0x10
    // 0x130b520: ret
    //     0x130b520: ret             
    // 0x130b524: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x130b524: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x130b528: b               #0x130b4f4
  }
  _ isModifierPressed(/* No info */) {
    // ** addr: 0x130b580, size: 0x1cc
    // 0x130b580: cmp             x6, #0x154
    // 0x130b584: b.eq            #0x130b590
    // 0x130b588: cmp             x6, #0x158
    // 0x130b58c: b.ne            #0x130b598
    // 0x130b590: r1 = 1
    //     0x130b590: mov             x1, #1
    // 0x130b594: b               #0x130b604
    // 0x130b598: cmp             x6, #0x155
    // 0x130b59c: b.eq            #0x130b5a8
    // 0x130b5a0: cmp             x6, #0x159
    // 0x130b5a4: b.ne            #0x130b5b0
    // 0x130b5a8: r1 = 2
    //     0x130b5a8: mov             x1, #2
    // 0x130b5ac: b               #0x130b604
    // 0x130b5b0: cmp             x6, #0x156
    // 0x130b5b4: b.eq            #0x130b5c0
    // 0x130b5b8: cmp             x6, #0x15a
    // 0x130b5bc: b.ne            #0x130b5c8
    // 0x130b5c0: r1 = 4
    //     0x130b5c0: mov             x1, #4
    // 0x130b5c4: b               #0x130b604
    // 0x130b5c8: cmp             x6, #0x157
    // 0x130b5cc: b.eq            #0x130b5d8
    // 0x130b5d0: cmp             x6, #0x15b
    // 0x130b5d4: b.ne            #0x130b5e0
    // 0x130b5d8: r1 = 8
    //     0x130b5d8: mov             x1, #8
    // 0x130b5dc: b               #0x130b604
    // 0x130b5e0: cmp             x6, #0x118
    // 0x130b5e4: b.ne            #0x130b5f0
    // 0x130b5e8: r1 = 16
    //     0x130b5e8: mov             x1, #0x10
    // 0x130b5ec: b               #0x130b604
    // 0x130b5f0: cmp             x6, #0x11a
    // 0x130b5f4: b.ne            #0x130b600
    // 0x130b5f8: r1 = 32
    //     0x130b5f8: mov             x1, #0x20
    // 0x130b5fc: b               #0x130b604
    // 0x130b600: r1 = 0
    //     0x130b600: mov             x1, #0
    // 0x130b604: tbnz            w5, #4, #0x130b614
    // 0x130b608: orr             x4, x3, x1
    // 0x130b60c: mov             x1, x4
    // 0x130b610: b               #0x130b61c
    // 0x130b614: mvn             x4, x1
    // 0x130b618: and             x1, x3, x4
    // 0x130b61c: LoadField: r3 = r2->field_7
    //     0x130b61c: ldur            x3, [x2, #7]
    // 0x130b620: cmp             x3, #4
    // 0x130b624: b.gt            #0x130b6fc
    // 0x130b628: cmp             x3, #2
    // 0x130b62c: b.gt            #0x130b6ac
    // 0x130b630: cmp             x3, #1
    // 0x130b634: b.gt            #0x130b688
    // 0x130b638: cmp             x3, #0
    // 0x130b63c: b.gt            #0x130b664
    // 0x130b640: mov             x2, x1
    // 0x130b644: ubfx            x2, x2, #0, #0x20
    // 0x130b648: and             w4, w2, #2
    // 0x130b64c: cbnz            w4, #0x130b658
    // 0x130b650: r2 = false
    //     0x130b650: add             x2, NULL, #0x30  ; false
    // 0x130b654: b               #0x130b65c
    // 0x130b658: r2 = true
    //     0x130b658: add             x2, NULL, #0x20  ; true
    // 0x130b65c: mov             x0, x2
    // 0x130b660: b               #0x130b748
    // 0x130b664: mov             x2, x1
    // 0x130b668: ubfx            x2, x2, #0, #0x20
    // 0x130b66c: and             w4, w2, #1
    // 0x130b670: cbnz            w4, #0x130b67c
    // 0x130b674: r2 = false
    //     0x130b674: add             x2, NULL, #0x30  ; false
    // 0x130b678: b               #0x130b680
    // 0x130b67c: r2 = true
    //     0x130b67c: add             x2, NULL, #0x20  ; true
    // 0x130b680: mov             x0, x2
    // 0x130b684: b               #0x130b748
    // 0x130b688: mov             x2, x1
    // 0x130b68c: ubfx            x2, x2, #0, #0x20
    // 0x130b690: and             w4, w2, #4
    // 0x130b694: cbnz            w4, #0x130b6a0
    // 0x130b698: r2 = false
    //     0x130b698: add             x2, NULL, #0x30  ; false
    // 0x130b69c: b               #0x130b6a4
    // 0x130b6a0: r2 = true
    //     0x130b6a0: add             x2, NULL, #0x20  ; true
    // 0x130b6a4: mov             x0, x2
    // 0x130b6a8: b               #0x130b748
    // 0x130b6ac: cmp             x3, #3
    // 0x130b6b0: b.gt            #0x130b6d8
    // 0x130b6b4: mov             x2, x1
    // 0x130b6b8: ubfx            x2, x2, #0, #0x20
    // 0x130b6bc: and             w4, w2, #8
    // 0x130b6c0: cbnz            w4, #0x130b6cc
    // 0x130b6c4: r2 = false
    //     0x130b6c4: add             x2, NULL, #0x30  ; false
    // 0x130b6c8: b               #0x130b6d0
    // 0x130b6cc: r2 = true
    //     0x130b6cc: add             x2, NULL, #0x20  ; true
    // 0x130b6d0: mov             x0, x2
    // 0x130b6d4: b               #0x130b748
    // 0x130b6d8: mov             x2, x1
    // 0x130b6dc: ubfx            x2, x2, #0, #0x20
    // 0x130b6e0: and             w4, w2, #0x10
    // 0x130b6e4: cbnz            w4, #0x130b6f0
    // 0x130b6e8: r2 = false
    //     0x130b6e8: add             x2, NULL, #0x30  ; false
    // 0x130b6ec: b               #0x130b6f4
    // 0x130b6f0: r2 = true
    //     0x130b6f0: add             x2, NULL, #0x20  ; true
    // 0x130b6f4: mov             x0, x2
    // 0x130b6f8: b               #0x130b748
    // 0x130b6fc: cmp             x3, #6
    // 0x130b700: b.gt            #0x130b734
    // 0x130b704: cmp             x3, #5
    // 0x130b708: b.gt            #0x130b72c
    // 0x130b70c: ubfx            x1, x1, #0, #0x20
    // 0x130b710: and             w2, w1, #0x20
    // 0x130b714: cbnz            w2, #0x130b720
    // 0x130b718: r1 = false
    //     0x130b718: add             x1, NULL, #0x30  ; false
    // 0x130b71c: b               #0x130b724
    // 0x130b720: r1 = true
    //     0x130b720: add             x1, NULL, #0x20  ; true
    // 0x130b724: mov             x0, x1
    // 0x130b728: b               #0x130b748
    // 0x130b72c: r0 = false
    //     0x130b72c: add             x0, NULL, #0x30  ; false
    // 0x130b730: b               #0x130b748
    // 0x130b734: cmp             x3, #7
    // 0x130b738: b.gt            #0x130b744
    // 0x130b73c: r0 = false
    //     0x130b73c: add             x0, NULL, #0x30  ; false
    // 0x130b740: b               #0x130b748
    // 0x130b744: r0 = false
    //     0x130b744: add             x0, NULL, #0x30  ; false
    // 0x130b748: ret
    //     0x130b748: ret             
  }
}

// class id: 2752, size: 0x8, field offset: 0x8
abstract class KeyHelper extends Object {

  factory _ KeyHelper(/* No info */) {
    // ** addr: 0x84ecdc, size: 0xc4
    // 0x84ecdc: EnterFrame
    //     0x84ecdc: stp             fp, lr, [SP, #-0x10]!
    //     0x84ece0: mov             fp, SP
    // 0x84ece4: AllocStack(0x18)
    //     0x84ece4: sub             SP, SP, #0x18
    // 0x84ece8: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x84ece8: stur            x2, [fp, #-8]
    // 0x84ecec: CheckStackOverflow
    //     0x84ecec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84ecf0: cmp             SP, x16
    //     0x84ecf4: b.ls            #0x84ed98
    // 0x84ecf8: r0 = LoadClassIdInstr(r2)
    //     0x84ecf8: ldur            x0, [x2, #-1]
    //     0x84ecfc: ubfx            x0, x0, #0xc, #0x14
    // 0x84ed00: r16 = "glfw"
    //     0x84ed00: ldr             x16, [PP, #0x40b8]  ; [pp+0x40b8] "glfw"
    // 0x84ed04: stp             x16, x2, [SP]
    // 0x84ed08: mov             lr, x0
    // 0x84ed0c: ldr             lr, [x21, lr, lsl #3]
    // 0x84ed10: blr             lr
    // 0x84ed14: tbnz            w0, #4, #0x84ed28
    // 0x84ed18: r0 = GLFWKeyHelper()
    //     0x84ed18: bl              #0x84edac  ; AllocateGLFWKeyHelperStub -> GLFWKeyHelper (size=0x8)
    // 0x84ed1c: LeaveFrame
    //     0x84ed1c: mov             SP, fp
    //     0x84ed20: ldp             fp, lr, [SP], #0x10
    // 0x84ed24: ret
    //     0x84ed24: ret             
    // 0x84ed28: ldur            x1, [fp, #-8]
    // 0x84ed2c: r0 = LoadClassIdInstr(r1)
    //     0x84ed2c: ldur            x0, [x1, #-1]
    //     0x84ed30: ubfx            x0, x0, #0xc, #0x14
    // 0x84ed34: r16 = "gtk"
    //     0x84ed34: ldr             x16, [PP, #0x40c0]  ; [pp+0x40c0] "gtk"
    // 0x84ed38: stp             x16, x1, [SP]
    // 0x84ed3c: mov             lr, x0
    // 0x84ed40: ldr             lr, [x21, lr, lsl #3]
    // 0x84ed44: blr             lr
    // 0x84ed48: tbnz            w0, #4, #0x84ed5c
    // 0x84ed4c: r0 = GtkKeyHelper()
    //     0x84ed4c: bl              #0x84eda0  ; AllocateGtkKeyHelperStub -> GtkKeyHelper (size=0x8)
    // 0x84ed50: LeaveFrame
    //     0x84ed50: mov             SP, fp
    //     0x84ed54: ldp             fp, lr, [SP], #0x10
    // 0x84ed58: ret
    //     0x84ed58: ret             
    // 0x84ed5c: ldur            x0, [fp, #-8]
    // 0x84ed60: r1 = Null
    //     0x84ed60: mov             x1, NULL
    // 0x84ed64: r2 = 4
    //     0x84ed64: mov             x2, #4
    // 0x84ed68: r0 = AllocateArray()
    //     0x84ed68: bl              #0x13df928  ; AllocateArrayStub
    // 0x84ed6c: r16 = "Window toolkit not recognized: "
    //     0x84ed6c: ldr             x16, [PP, #0x40c8]  ; [pp+0x40c8] "Window toolkit not recognized: "
    // 0x84ed70: StoreField: r0->field_f = r16
    //     0x84ed70: stur            w16, [x0, #0xf]
    // 0x84ed74: ldur            x1, [fp, #-8]
    // 0x84ed78: StoreField: r0->field_13 = r1
    //     0x84ed78: stur            w1, [x0, #0x13]
    // 0x84ed7c: str             x0, [SP]
    // 0x84ed80: r0 = _interpolate()
    //     0x84ed80: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x84ed84: mov             x2, x0
    // 0x84ed88: r1 = Null
    //     0x84ed88: mov             x1, NULL
    // 0x84ed8c: r0 = FlutterError()
    //     0x84ed8c: bl              #0x84eb60  ; [package:flutter/src/foundation/assertions.dart] FlutterError::FlutterError
    // 0x84ed90: r0 = Throw()
    //     0x84ed90: bl              #0x13ddb2c  ; ThrowStub
    // 0x84ed94: brk             #0
    // 0x84ed98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84ed98: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84ed9c: b               #0x84ecf8
  }
}

// class id: 5022, size: 0x34, field offset: 0x8
//   const constructor, 
class RawKeyEventDataLinux extends RawKeyEventData {

  get _ hashCode(/* No info */) {
    // ** addr: 0x113bed4, size: 0xf0
    // 0x113bed4: EnterFrame
    //     0x113bed4: stp             fp, lr, [SP, #-0x10]!
    //     0x113bed8: mov             fp, SP
    // 0x113bedc: AllocStack(0x20)
    //     0x113bedc: sub             SP, SP, #0x20
    // 0x113bee0: CheckStackOverflow
    //     0x113bee0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x113bee4: cmp             SP, x16
    //     0x113bee8: b.ls            #0x113bfbc
    // 0x113beec: ldr             x0, [fp, #0x10]
    // 0x113bef0: LoadField: r1 = r0->field_7
    //     0x113bef0: ldur            w1, [x0, #7]
    // 0x113bef4: DecompressPointer r1
    //     0x113bef4: add             x1, x1, HEAP, lsl #32
    // 0x113bef8: str             x1, [SP]
    // 0x113befc: r0 = runtimeType()
    //     0x113befc: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x113bf00: mov             x2, x0
    // 0x113bf04: ldr             x0, [fp, #0x10]
    // 0x113bf08: LoadField: r3 = r0->field_b
    //     0x113bf08: ldur            x3, [x0, #0xb]
    // 0x113bf0c: LoadField: r4 = r0->field_13
    //     0x113bf0c: ldur            x4, [x0, #0x13]
    // 0x113bf10: LoadField: r5 = r0->field_1b
    //     0x113bf10: ldur            x5, [x0, #0x1b]
    // 0x113bf14: LoadField: r6 = r0->field_23
    //     0x113bf14: ldur            x6, [x0, #0x23]
    // 0x113bf18: LoadField: r7 = r0->field_2b
    //     0x113bf18: ldur            w7, [x0, #0x2b]
    // 0x113bf1c: DecompressPointer r7
    //     0x113bf1c: add             x7, x7, HEAP, lsl #32
    // 0x113bf20: r0 = BoxInt64Instr(r3)
    //     0x113bf20: sbfiz           x0, x3, #1, #0x1f
    //     0x113bf24: cmp             x3, x0, asr #1
    //     0x113bf28: b.eq            #0x113bf34
    //     0x113bf2c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x113bf30: stur            x3, [x0, #7]
    // 0x113bf34: mov             x3, x0
    // 0x113bf38: r0 = BoxInt64Instr(r4)
    //     0x113bf38: sbfiz           x0, x4, #1, #0x1f
    //     0x113bf3c: cmp             x4, x0, asr #1
    //     0x113bf40: b.eq            #0x113bf4c
    //     0x113bf44: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x113bf48: stur            x4, [x0, #7]
    // 0x113bf4c: mov             x4, x0
    // 0x113bf50: r0 = BoxInt64Instr(r5)
    //     0x113bf50: sbfiz           x0, x5, #1, #0x1f
    //     0x113bf54: cmp             x5, x0, asr #1
    //     0x113bf58: b.eq            #0x113bf64
    //     0x113bf5c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x113bf60: stur            x5, [x0, #7]
    // 0x113bf64: mov             x5, x0
    // 0x113bf68: r0 = BoxInt64Instr(r6)
    //     0x113bf68: sbfiz           x0, x6, #1, #0x1f
    //     0x113bf6c: cmp             x6, x0, asr #1
    //     0x113bf70: b.eq            #0x113bf7c
    //     0x113bf74: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x113bf78: stur            x6, [x0, #7]
    // 0x113bf7c: stp             x5, x4, [SP, #0x10]
    // 0x113bf80: stp             x7, x0, [SP]
    // 0x113bf84: mov             x1, x2
    // 0x113bf88: mov             x2, x3
    // 0x113bf8c: r4 = const [0, 0x6, 0x4, 0x6, null]
    //     0x113bf8c: add             x4, PP, #0xd, lsl #12  ; [pp+0xdd28] List(5) [0, 0x6, 0x4, 0x6, Null]
    //     0x113bf90: ldr             x4, [x4, #0xd28]
    // 0x113bf94: r0 = hash()
    //     0x113bf94: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x113bf98: mov             x2, x0
    // 0x113bf9c: r0 = BoxInt64Instr(r2)
    //     0x113bf9c: sbfiz           x0, x2, #1, #0x1f
    //     0x113bfa0: cmp             x2, x0, asr #1
    //     0x113bfa4: b.eq            #0x113bfb0
    //     0x113bfa8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x113bfac: stur            x2, [x0, #7]
    // 0x113bfb0: LeaveFrame
    //     0x113bfb0: mov             SP, fp
    //     0x113bfb4: ldp             fp, lr, [SP], #0x10
    // 0x113bfb8: ret
    //     0x113bfb8: ret             
    // 0x113bfbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x113bfbc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x113bfc0: b               #0x113beec
  }
  get _ logicalKey(/* No info */) {
    // ** addr: 0x11429e0, size: 0x20c
    // 0x11429e0: EnterFrame
    //     0x11429e0: stp             fp, lr, [SP, #-0x10]!
    //     0x11429e4: mov             fp, SP
    // 0x11429e8: AllocStack(0x20)
    //     0x11429e8: sub             SP, SP, #0x20
    // 0x11429ec: SetupParameters(RawKeyEventDataLinux this /* r1 => r3, fp-0x18 */)
    //     0x11429ec: mov             x3, x1
    //     0x11429f0: stur            x1, [fp, #-0x18]
    // 0x11429f4: CheckStackOverflow
    //     0x11429f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11429f8: cmp             SP, x16
    //     0x11429fc: b.ls            #0x1142be0
    // 0x1142a00: LoadField: r0 = r3->field_2f
    //     0x1142a00: ldur            w0, [x3, #0x2f]
    // 0x1142a04: DecompressPointer r0
    //     0x1142a04: add             x0, x0, HEAP, lsl #32
    // 0x1142a08: cmp             w0, NULL
    // 0x1142a0c: b.eq            #0x1142a54
    // 0x1142a10: r2 = LoadInt32Instr(r0)
    //     0x1142a10: sbfx            x2, x0, #1, #0x1f
    //     0x1142a14: tbz             w0, #0, #0x1142a1c
    //     0x1142a18: ldur            x2, [x0, #7]
    // 0x1142a1c: mov             x1, x2
    // 0x1142a20: stur            x2, [fp, #-8]
    // 0x1142a24: r0 = findKeyByKeyId()
    //     0x1142a24: bl              #0x84a464  ; [package:flutter/src/services/keyboard_key.g.dart] LogicalKeyboardKey::findKeyByKeyId
    // 0x1142a28: cmp             w0, NULL
    // 0x1142a2c: b.ne            #0x1142a48
    // 0x1142a30: ldur            x0, [fp, #-8]
    // 0x1142a34: r0 = LogicalKeyboardKey()
    //     0x1142a34: bl              #0x849274  ; AllocateLogicalKeyboardKeyStub -> LogicalKeyboardKey (size=0x10)
    // 0x1142a38: mov             x1, x0
    // 0x1142a3c: ldur            x0, [fp, #-8]
    // 0x1142a40: StoreField: r1->field_7 = r0
    //     0x1142a40: stur            x0, [x1, #7]
    // 0x1142a44: mov             x0, x1
    // 0x1142a48: LeaveFrame
    //     0x1142a48: mov             SP, fp
    //     0x1142a4c: ldp             fp, lr, [SP], #0x10
    // 0x1142a50: ret
    //     0x1142a50: ret             
    // 0x1142a54: LoadField: r4 = r3->field_7
    //     0x1142a54: ldur            w4, [x3, #7]
    // 0x1142a58: DecompressPointer r4
    //     0x1142a58: add             x4, x4, HEAP, lsl #32
    // 0x1142a5c: stur            x4, [fp, #-0x10]
    // 0x1142a60: LoadField: r5 = r3->field_1b
    //     0x1142a60: ldur            x5, [x3, #0x1b]
    // 0x1142a64: stur            x5, [fp, #-8]
    // 0x1142a68: r0 = LoadClassIdInstr(r4)
    //     0x1142a68: ldur            x0, [x4, #-1]
    //     0x1142a6c: ubfx            x0, x0, #0xc, #0x14
    // 0x1142a70: mov             x1, x4
    // 0x1142a74: mov             x2, x5
    // 0x1142a78: r0 = GDT[cid_x0 + -0xffb]()
    //     0x1142a78: sub             lr, x0, #0xffb
    //     0x1142a7c: ldr             lr, [x21, lr, lsl #3]
    //     0x1142a80: blr             lr
    // 0x1142a84: cmp             w0, NULL
    // 0x1142a88: b.eq            #0x1142a98
    // 0x1142a8c: LeaveFrame
    //     0x1142a8c: mov             SP, fp
    //     0x1142a90: ldp             fp, lr, [SP], #0x10
    // 0x1142a94: ret
    //     0x1142a94: ret             
    // 0x1142a98: ldur            x0, [fp, #-0x18]
    // 0x1142a9c: LoadField: r3 = r0->field_b
    //     0x1142a9c: ldur            x3, [x0, #0xb]
    // 0x1142aa0: stur            x3, [fp, #-0x20]
    // 0x1142aa4: cbnz            x3, #0x1142ab0
    // 0x1142aa8: r0 = ""
    //     0x1142aa8: ldr             x0, [PP, #0x900]  ; [pp+0x900] ""
    // 0x1142aac: b               #0x1142abc
    // 0x1142ab0: mov             x2, x3
    // 0x1142ab4: r1 = Null
    //     0x1142ab4: mov             x1, NULL
    // 0x1142ab8: r0 = String.fromCharCode()
    //     0x1142ab8: bl              #0x7e6340  ; [dart:core] String::String.fromCharCode
    // 0x1142abc: LoadField: r1 = r0->field_7
    //     0x1142abc: ldur            w1, [x0, #7]
    // 0x1142ac0: cbz             w1, #0x1142b68
    // 0x1142ac4: ldur            x1, [fp, #-0x18]
    // 0x1142ac8: r0 = keyLabel()
    //     0x1142ac8: bl              #0x1142bec  ; [package:flutter/src/services/raw_keyboard_linux.dart] RawKeyEventDataLinux::keyLabel
    // 0x1142acc: mov             x2, x0
    // 0x1142ad0: LoadField: r0 = r2->field_7
    //     0x1142ad0: ldur            w0, [x2, #7]
    // 0x1142ad4: r1 = LoadInt32Instr(r0)
    //     0x1142ad4: sbfx            x1, x0, #1, #0x1f
    // 0x1142ad8: cmp             x1, #1
    // 0x1142adc: b.ne            #0x1142b2c
    // 0x1142ae0: mov             x0, x1
    // 0x1142ae4: r1 = 0
    //     0x1142ae4: mov             x1, #0
    // 0x1142ae8: cmp             x1, x0
    // 0x1142aec: b.hs            #0x1142be8
    // 0x1142af0: r0 = LoadClassIdInstr(r2)
    //     0x1142af0: ldur            x0, [x2, #-1]
    //     0x1142af4: ubfx            x0, x0, #0xc, #0x14
    // 0x1142af8: lsl             x0, x0, #1
    // 0x1142afc: cmp             w0, #0xbc
    // 0x1142b00: b.ne            #0x1142b0c
    // 0x1142b04: ArrayLoad: r0 = r2[-8]  ; TypedUnsigned_1
    //     0x1142b04: ldrb            w0, [x2, #0xf]
    // 0x1142b08: b               #0x1142b10
    // 0x1142b0c: ldurh           w0, [x2, #0xf]
    // 0x1142b10: cmp             x0, #0x1f
    // 0x1142b14: b.gt            #0x1142b1c
    // 0x1142b18: tbz             x0, #0x3f, #0x1142b68
    // 0x1142b1c: cmp             x0, #0x7f
    // 0x1142b20: b.lt            #0x1142b2c
    // 0x1142b24: cmp             x0, #0x9f
    // 0x1142b28: b.le            #0x1142b68
    // 0x1142b2c: ldur            x0, [fp, #-0x20]
    // 0x1142b30: ubfx            x0, x0, #0, #0x20
    // 0x1142b34: stur            x0, [fp, #-0x20]
    // 0x1142b38: mov             x1, x0
    // 0x1142b3c: ubfx            x1, x1, #0, #0x20
    // 0x1142b40: r0 = findKeyByKeyId()
    //     0x1142b40: bl              #0x84a464  ; [package:flutter/src/services/keyboard_key.g.dart] LogicalKeyboardKey::findKeyByKeyId
    // 0x1142b44: cmp             w0, NULL
    // 0x1142b48: b.ne            #0x1142b5c
    // 0x1142b4c: r0 = LogicalKeyboardKey()
    //     0x1142b4c: bl              #0x849274  ; AllocateLogicalKeyboardKeyStub -> LogicalKeyboardKey (size=0x10)
    // 0x1142b50: ldur            x1, [fp, #-0x20]
    // 0x1142b54: ubfx            x1, x1, #0, #0x20
    // 0x1142b58: StoreField: r0->field_7 = r1
    //     0x1142b58: stur            x1, [x0, #7]
    // 0x1142b5c: LeaveFrame
    //     0x1142b5c: mov             SP, fp
    //     0x1142b60: ldp             fp, lr, [SP], #0x10
    // 0x1142b64: ret
    //     0x1142b64: ret             
    // 0x1142b68: ldur            x3, [fp, #-0x10]
    // 0x1142b6c: r0 = LoadClassIdInstr(r3)
    //     0x1142b6c: ldur            x0, [x3, #-1]
    //     0x1142b70: ubfx            x0, x0, #0xc, #0x14
    // 0x1142b74: mov             x1, x3
    // 0x1142b78: ldur            x2, [fp, #-8]
    // 0x1142b7c: r0 = GDT[cid_x0 + -0xff9]()
    //     0x1142b7c: sub             lr, x0, #0xff9
    //     0x1142b80: ldr             lr, [x21, lr, lsl #3]
    //     0x1142b84: blr             lr
    // 0x1142b88: cmp             w0, NULL
    // 0x1142b8c: b.eq            #0x1142b9c
    // 0x1142b90: LeaveFrame
    //     0x1142b90: mov             SP, fp
    //     0x1142b94: ldp             fp, lr, [SP], #0x10
    // 0x1142b98: ret
    //     0x1142b98: ret             
    // 0x1142b9c: ldur            x1, [fp, #-0x10]
    // 0x1142ba0: ldur            x2, [fp, #-8]
    // 0x1142ba4: r0 = LoadClassIdInstr(r1)
    //     0x1142ba4: ldur            x0, [x1, #-1]
    //     0x1142ba8: ubfx            x0, x0, #0xc, #0x14
    // 0x1142bac: r0 = GDT[cid_x0 + -0xfc9]()
    //     0x1142bac: sub             lr, x0, #0xfc9
    //     0x1142bb0: ldr             lr, [x21, lr, lsl #3]
    //     0x1142bb4: blr             lr
    // 0x1142bb8: mov             x1, x0
    // 0x1142bbc: ldur            x0, [fp, #-8]
    // 0x1142bc0: orr             x2, x0, x1
    // 0x1142bc4: stur            x2, [fp, #-0x20]
    // 0x1142bc8: r0 = LogicalKeyboardKey()
    //     0x1142bc8: bl              #0x849274  ; AllocateLogicalKeyboardKeyStub -> LogicalKeyboardKey (size=0x10)
    // 0x1142bcc: ldur            x1, [fp, #-0x20]
    // 0x1142bd0: StoreField: r0->field_7 = r1
    //     0x1142bd0: stur            x1, [x0, #7]
    // 0x1142bd4: LeaveFrame
    //     0x1142bd4: mov             SP, fp
    //     0x1142bd8: ldp             fp, lr, [SP], #0x10
    // 0x1142bdc: ret
    //     0x1142bdc: ret             
    // 0x1142be0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1142be0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1142be4: b               #0x1142a00
    // 0x1142be8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x1142be8: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  get _ keyLabel(/* No info */) {
    // ** addr: 0x1142bec, size: 0x40
    // 0x1142bec: EnterFrame
    //     0x1142bec: stp             fp, lr, [SP, #-0x10]!
    //     0x1142bf0: mov             fp, SP
    // 0x1142bf4: CheckStackOverflow
    //     0x1142bf4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1142bf8: cmp             SP, x16
    //     0x1142bfc: b.ls            #0x1142c24
    // 0x1142c00: LoadField: r2 = r1->field_b
    //     0x1142c00: ldur            x2, [x1, #0xb]
    // 0x1142c04: cbnz            x2, #0x1142c10
    // 0x1142c08: r0 = ""
    //     0x1142c08: ldr             x0, [PP, #0x900]  ; [pp+0x900] ""
    // 0x1142c0c: b               #0x1142c18
    // 0x1142c10: r1 = Null
    //     0x1142c10: mov             x1, NULL
    // 0x1142c14: r0 = String.fromCharCode()
    //     0x1142c14: bl              #0x7e6340  ; [dart:core] String::String.fromCharCode
    // 0x1142c18: LeaveFrame
    //     0x1142c18: mov             SP, fp
    //     0x1142c1c: ldp             fp, lr, [SP], #0x10
    // 0x1142c20: ret
    //     0x1142c20: ret             
    // 0x1142c24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1142c24: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1142c28: b               #0x1142c00
  }
  _ getModifierSide(/* No info */) {
    // ** addr: 0x1143668, size: 0x54
    // 0x1143668: EnterFrame
    //     0x1143668: stp             fp, lr, [SP, #-0x10]!
    //     0x114366c: mov             fp, SP
    // 0x1143670: CheckStackOverflow
    //     0x1143670: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1143674: cmp             SP, x16
    //     0x1143678: b.ls            #0x11436b4
    // 0x114367c: LoadField: r0 = r1->field_7
    //     0x114367c: ldur            w0, [x1, #7]
    // 0x1143680: DecompressPointer r0
    //     0x1143680: add             x0, x0, HEAP, lsl #32
    // 0x1143684: r1 = LoadClassIdInstr(r0)
    //     0x1143684: ldur            x1, [x0, #-1]
    //     0x1143688: ubfx            x1, x1, #0xc, #0x14
    // 0x114368c: mov             x16, x0
    // 0x1143690: mov             x0, x1
    // 0x1143694: mov             x1, x16
    // 0x1143698: r0 = GDT[cid_x0 + -0xffd]()
    //     0x1143698: sub             lr, x0, #0xffd
    //     0x114369c: ldr             lr, [x21, lr, lsl #3]
    //     0x11436a0: blr             lr
    // 0x11436a4: r0 = Instance_KeyboardSide
    //     0x11436a4: ldr             x0, [PP, #0x3b60]  ; [pp+0x3b60] Obj!KeyboardSide@12c3cc1
    // 0x11436a8: LeaveFrame
    //     0x11436a8: mov             SP, fp
    //     0x11436ac: ldp             fp, lr, [SP], #0x10
    // 0x11436b0: ret
    //     0x11436b0: ret             
    // 0x11436b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11436b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11436b8: b               #0x114367c
  }
  get _ physicalKey(/* No info */) {
    // ** addr: 0x114769c, size: 0x80
    // 0x114769c: EnterFrame
    //     0x114769c: stp             fp, lr, [SP, #-0x10]!
    //     0x11476a0: mov             fp, SP
    // 0x11476a4: AllocStack(0x10)
    //     0x11476a4: sub             SP, SP, #0x10
    // 0x11476a8: CheckStackOverflow
    //     0x11476a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11476ac: cmp             SP, x16
    //     0x11476b0: b.ls            #0x1147714
    // 0x11476b4: LoadField: r3 = r1->field_13
    //     0x11476b4: ldur            x3, [x1, #0x13]
    // 0x11476b8: stur            x3, [fp, #-8]
    // 0x11476bc: r0 = BoxInt64Instr(r3)
    //     0x11476bc: sbfiz           x0, x3, #1, #0x1f
    //     0x11476c0: cmp             x3, x0, asr #1
    //     0x11476c4: b.eq            #0x11476d0
    //     0x11476c8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x11476cc: stur            x3, [x0, #7]
    // 0x11476d0: mov             x2, x0
    // 0x11476d4: r1 = _ConstMap len:217
    //     0x11476d4: add             x1, PP, #0xd, lsl #12  ; [pp+0xdd38] Map<int, PhysicalKeyboardKey>(217)
    //     0x11476d8: ldr             x1, [x1, #0xd38]
    // 0x11476dc: r0 = []()
    //     0x11476dc: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x11476e0: cmp             w0, NULL
    // 0x11476e4: b.ne            #0x1147708
    // 0x11476e8: ldur            x0, [fp, #-8]
    // 0x11476ec: r17 = 98784247808
    //     0x11476ec: add             x17, PP, #0xd, lsl #12  ; [pp+0xdce8] IMM: 0x1700000000
    //     0x11476f0: ldr             x17, [x17, #0xce8]
    // 0x11476f4: add             x1, x0, x17
    // 0x11476f8: stur            x1, [fp, #-0x10]
    // 0x11476fc: r0 = PhysicalKeyboardKey()
    //     0x11476fc: bl              #0x8492a4  ; AllocatePhysicalKeyboardKeyStub -> PhysicalKeyboardKey (size=0x10)
    // 0x1147700: ldur            x1, [fp, #-0x10]
    // 0x1147704: StoreField: r0->field_7 = r1
    //     0x1147704: stur            x1, [x0, #7]
    // 0x1147708: LeaveFrame
    //     0x1147708: mov             SP, fp
    //     0x114770c: ldp             fp, lr, [SP], #0x10
    // 0x1147710: ret
    //     0x1147710: ret             
    // 0x1147714: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1147714: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1147718: b               #0x11476b4
  }
  _ isModifierPressed(/* No info */) {
    // ** addr: 0x116ee04, size: 0x60
    // 0x116ee04: EnterFrame
    //     0x116ee04: stp             fp, lr, [SP, #-0x10]!
    //     0x116ee08: mov             fp, SP
    // 0x116ee0c: CheckStackOverflow
    //     0x116ee0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x116ee10: cmp             SP, x16
    //     0x116ee14: b.ls            #0x116ee5c
    // 0x116ee18: LoadField: r0 = r1->field_7
    //     0x116ee18: ldur            w0, [x1, #7]
    // 0x116ee1c: DecompressPointer r0
    //     0x116ee1c: add             x0, x0, HEAP, lsl #32
    // 0x116ee20: LoadField: r3 = r1->field_23
    //     0x116ee20: ldur            x3, [x1, #0x23]
    // 0x116ee24: LoadField: r6 = r1->field_1b
    //     0x116ee24: ldur            x6, [x1, #0x1b]
    // 0x116ee28: LoadField: r5 = r1->field_2b
    //     0x116ee28: ldur            w5, [x1, #0x2b]
    // 0x116ee2c: DecompressPointer r5
    //     0x116ee2c: add             x5, x5, HEAP, lsl #32
    // 0x116ee30: r1 = LoadClassIdInstr(r0)
    //     0x116ee30: ldur            x1, [x0, #-1]
    //     0x116ee34: ubfx            x1, x1, #0xc, #0x14
    // 0x116ee38: mov             x16, x0
    // 0x116ee3c: mov             x0, x1
    // 0x116ee40: mov             x1, x16
    // 0x116ee44: r0 = GDT[cid_x0 + -0xfff]()
    //     0x116ee44: sub             lr, x0, #0xfff
    //     0x116ee48: ldr             lr, [x21, lr, lsl #3]
    //     0x116ee4c: blr             lr
    // 0x116ee50: LeaveFrame
    //     0x116ee50: mov             SP, fp
    //     0x116ee54: ldp             fp, lr, [SP], #0x10
    // 0x116ee58: ret
    //     0x116ee58: ret             
    // 0x116ee5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x116ee5c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x116ee60: b               #0x116ee18
  }
  _ ==(/* No info */) {
    // ** addr: 0x1279e9c, size: 0x158
    // 0x1279e9c: EnterFrame
    //     0x1279e9c: stp             fp, lr, [SP, #-0x10]!
    //     0x1279ea0: mov             fp, SP
    // 0x1279ea4: AllocStack(0x10)
    //     0x1279ea4: sub             SP, SP, #0x10
    // 0x1279ea8: CheckStackOverflow
    //     0x1279ea8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1279eac: cmp             SP, x16
    //     0x1279eb0: b.ls            #0x1279fec
    // 0x1279eb4: ldr             x0, [fp, #0x10]
    // 0x1279eb8: cmp             w0, NULL
    // 0x1279ebc: b.ne            #0x1279ed0
    // 0x1279ec0: r0 = false
    //     0x1279ec0: add             x0, NULL, #0x30  ; false
    // 0x1279ec4: LeaveFrame
    //     0x1279ec4: mov             SP, fp
    //     0x1279ec8: ldp             fp, lr, [SP], #0x10
    // 0x1279ecc: ret
    //     0x1279ecc: ret             
    // 0x1279ed0: ldr             x1, [fp, #0x18]
    // 0x1279ed4: cmp             w1, w0
    // 0x1279ed8: b.ne            #0x1279eec
    // 0x1279edc: r0 = true
    //     0x1279edc: add             x0, NULL, #0x20  ; true
    // 0x1279ee0: LeaveFrame
    //     0x1279ee0: mov             SP, fp
    //     0x1279ee4: ldp             fp, lr, [SP], #0x10
    // 0x1279ee8: ret
    //     0x1279ee8: ret             
    // 0x1279eec: str             x0, [SP]
    // 0x1279ef0: r0 = runtimeType()
    //     0x1279ef0: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x1279ef4: r1 = LoadClassIdInstr(r0)
    //     0x1279ef4: ldur            x1, [x0, #-1]
    //     0x1279ef8: ubfx            x1, x1, #0xc, #0x14
    // 0x1279efc: r16 = RawKeyEventDataLinux
    //     0x1279efc: add             x16, PP, #0xd, lsl #12  ; [pp+0xdd30] Type: RawKeyEventDataLinux
    //     0x1279f00: ldr             x16, [x16, #0xd30]
    // 0x1279f04: stp             x16, x0, [SP]
    // 0x1279f08: mov             x0, x1
    // 0x1279f0c: mov             lr, x0
    // 0x1279f10: ldr             lr, [x21, lr, lsl #3]
    // 0x1279f14: blr             lr
    // 0x1279f18: tbz             w0, #4, #0x1279f2c
    // 0x1279f1c: r0 = false
    //     0x1279f1c: add             x0, NULL, #0x30  ; false
    // 0x1279f20: LeaveFrame
    //     0x1279f20: mov             SP, fp
    //     0x1279f24: ldp             fp, lr, [SP], #0x10
    // 0x1279f28: ret
    //     0x1279f28: ret             
    // 0x1279f2c: ldr             x0, [fp, #0x10]
    // 0x1279f30: r1 = 60
    //     0x1279f30: mov             x1, #0x3c
    // 0x1279f34: branchIfSmi(r0, 0x1279f40)
    //     0x1279f34: tbz             w0, #0, #0x1279f40
    // 0x1279f38: r1 = LoadClassIdInstr(r0)
    //     0x1279f38: ldur            x1, [x0, #-1]
    //     0x1279f3c: ubfx            x1, x1, #0xc, #0x14
    // 0x1279f40: r17 = 5022
    //     0x1279f40: mov             x17, #0x139e
    // 0x1279f44: cmp             x1, x17
    // 0x1279f48: b.ne            #0x1279fdc
    // 0x1279f4c: ldr             x1, [fp, #0x18]
    // 0x1279f50: LoadField: r2 = r0->field_7
    //     0x1279f50: ldur            w2, [x0, #7]
    // 0x1279f54: DecompressPointer r2
    //     0x1279f54: add             x2, x2, HEAP, lsl #32
    // 0x1279f58: LoadField: r3 = r1->field_7
    //     0x1279f58: ldur            w3, [x1, #7]
    // 0x1279f5c: DecompressPointer r3
    //     0x1279f5c: add             x3, x3, HEAP, lsl #32
    // 0x1279f60: stp             x3, x2, [SP]
    // 0x1279f64: r0 = _haveSameRuntimeType()
    //     0x1279f64: bl              #0x88249c  ; [dart:core] Object::_haveSameRuntimeType
    // 0x1279f68: tbnz            w0, #4, #0x1279fdc
    // 0x1279f6c: ldr             x2, [fp, #0x18]
    // 0x1279f70: ldr             x1, [fp, #0x10]
    // 0x1279f74: LoadField: r3 = r1->field_b
    //     0x1279f74: ldur            x3, [x1, #0xb]
    // 0x1279f78: LoadField: r4 = r2->field_b
    //     0x1279f78: ldur            x4, [x2, #0xb]
    // 0x1279f7c: cmp             x3, x4
    // 0x1279f80: b.ne            #0x1279fdc
    // 0x1279f84: LoadField: r3 = r1->field_13
    //     0x1279f84: ldur            x3, [x1, #0x13]
    // 0x1279f88: LoadField: r4 = r2->field_13
    //     0x1279f88: ldur            x4, [x2, #0x13]
    // 0x1279f8c: cmp             x3, x4
    // 0x1279f90: b.ne            #0x1279fdc
    // 0x1279f94: LoadField: r3 = r1->field_1b
    //     0x1279f94: ldur            x3, [x1, #0x1b]
    // 0x1279f98: LoadField: r4 = r2->field_1b
    //     0x1279f98: ldur            x4, [x2, #0x1b]
    // 0x1279f9c: cmp             x3, x4
    // 0x1279fa0: b.ne            #0x1279fdc
    // 0x1279fa4: LoadField: r3 = r1->field_23
    //     0x1279fa4: ldur            x3, [x1, #0x23]
    // 0x1279fa8: LoadField: r4 = r2->field_23
    //     0x1279fa8: ldur            x4, [x2, #0x23]
    // 0x1279fac: cmp             x3, x4
    // 0x1279fb0: b.ne            #0x1279fdc
    // 0x1279fb4: LoadField: r3 = r1->field_2b
    //     0x1279fb4: ldur            w3, [x1, #0x2b]
    // 0x1279fb8: DecompressPointer r3
    //     0x1279fb8: add             x3, x3, HEAP, lsl #32
    // 0x1279fbc: LoadField: r1 = r2->field_2b
    //     0x1279fbc: ldur            w1, [x2, #0x2b]
    // 0x1279fc0: DecompressPointer r1
    //     0x1279fc0: add             x1, x1, HEAP, lsl #32
    // 0x1279fc4: cmp             w3, w1
    // 0x1279fc8: r16 = true
    //     0x1279fc8: add             x16, NULL, #0x20  ; true
    // 0x1279fcc: r17 = false
    //     0x1279fcc: add             x17, NULL, #0x30  ; false
    // 0x1279fd0: csel            x2, x16, x17, eq
    // 0x1279fd4: mov             x0, x2
    // 0x1279fd8: b               #0x1279fe0
    // 0x1279fdc: r0 = false
    //     0x1279fdc: add             x0, NULL, #0x30  ; false
    // 0x1279fe0: LeaveFrame
    //     0x1279fe0: mov             SP, fp
    //     0x1279fe4: ldp             fp, lr, [SP], #0x10
    // 0x1279fe8: ret
    //     0x1279fe8: ret             
    // 0x1279fec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1279fec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1279ff0: b               #0x1279eb4
  }
}
