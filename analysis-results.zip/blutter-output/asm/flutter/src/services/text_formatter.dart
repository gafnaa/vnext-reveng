// lib: , url: package:flutter/src/services/text_formatter.dart

// class id: 1049103, size: 0x8
class :: {
}

// class id: 2733, size: 0x18, field offset: 0x8
class _TextEditingValueAccumulator extends Object {

  _ finalize(/* No info */) {
    // ** addr: 0x1308828, size: 0x17c
    // 0x1308828: EnterFrame
    //     0x1308828: stp             fp, lr, [SP, #-0x10]!
    //     0x130882c: mov             fp, SP
    // 0x1308830: AllocStack(0x40)
    //     0x1308830: sub             SP, SP, #0x40
    // 0x1308834: SetupParameters(_TextEditingValueAccumulator this /* r1 => r1, fp-0x18 */)
    //     0x1308834: stur            x1, [fp, #-0x18]
    // 0x1308838: CheckStackOverflow
    //     0x1308838: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x130883c: cmp             SP, x16
    //     0x1308840: b.ls            #0x130899c
    // 0x1308844: LoadField: r0 = r1->field_f
    //     0x1308844: ldur            w0, [x1, #0xf]
    // 0x1308848: DecompressPointer r0
    //     0x1308848: add             x0, x0, HEAP, lsl #32
    // 0x130884c: stur            x0, [fp, #-0x10]
    // 0x1308850: LoadField: r2 = r1->field_13
    //     0x1308850: ldur            w2, [x1, #0x13]
    // 0x1308854: DecompressPointer r2
    //     0x1308854: add             x2, x2, HEAP, lsl #32
    // 0x1308858: stur            x2, [fp, #-8]
    // 0x130885c: LoadField: r3 = r1->field_b
    //     0x130885c: ldur            w3, [x1, #0xb]
    // 0x1308860: DecompressPointer r3
    //     0x1308860: add             x3, x3, HEAP, lsl #32
    // 0x1308864: str             x3, [SP]
    // 0x1308868: r0 = toString()
    //     0x1308868: bl              #0x1101d44  ; [dart:core] StringBuffer::toString
    // 0x130886c: mov             x1, x0
    // 0x1308870: ldur            x0, [fp, #-8]
    // 0x1308874: stur            x1, [fp, #-0x30]
    // 0x1308878: cmp             w0, NULL
    // 0x130887c: b.eq            #0x1308898
    // 0x1308880: LoadField: r2 = r0->field_7
    //     0x1308880: ldur            x2, [x0, #7]
    // 0x1308884: stur            x2, [fp, #-0x28]
    // 0x1308888: LoadField: r3 = r0->field_f
    //     0x1308888: ldur            x3, [x0, #0xf]
    // 0x130888c: stur            x3, [fp, #-0x20]
    // 0x1308890: cmp             x2, x3
    // 0x1308894: b.ne            #0x13088a0
    // 0x1308898: r1 = Instance_TextRange
    //     0x1308898: ldr             x1, [PP, #0x53d8]  ; [pp+0x53d8] Obj!TextRange@12a0471
    // 0x130889c: b               #0x13088b8
    // 0x13088a0: r0 = TextRange()
    //     0x13088a0: bl              #0x83839c  ; AllocateTextRangeStub -> TextRange (size=0x18)
    // 0x13088a4: mov             x1, x0
    // 0x13088a8: ldur            x0, [fp, #-0x28]
    // 0x13088ac: StoreField: r1->field_7 = r0
    //     0x13088ac: stur            x0, [x1, #7]
    // 0x13088b0: ldur            x0, [fp, #-0x20]
    // 0x13088b4: StoreField: r1->field_f = r0
    //     0x13088b4: stur            x0, [x1, #0xf]
    // 0x13088b8: ldur            x0, [fp, #-0x10]
    // 0x13088bc: stur            x1, [fp, #-0x38]
    // 0x13088c0: cmp             w0, NULL
    // 0x13088c4: b.ne            #0x13088d8
    // 0x13088c8: mov             x0, x1
    // 0x13088cc: r2 = Instance_TextSelection
    //     0x13088cc: add             x2, PP, #0x14, lsl #12  ; [pp+0x14b30] Obj!TextSelection@12a0491
    //     0x13088d0: ldr             x2, [x2, #0xb30]
    // 0x13088d4: b               #0x130896c
    // 0x13088d8: ldur            x2, [fp, #-0x18]
    // 0x13088dc: LoadField: r3 = r0->field_7
    //     0x13088dc: ldur            x3, [x0, #7]
    // 0x13088e0: stur            x3, [fp, #-0x28]
    // 0x13088e4: LoadField: r4 = r0->field_f
    //     0x13088e4: ldur            x4, [x0, #0xf]
    // 0x13088e8: stur            x4, [fp, #-0x20]
    // 0x13088ec: LoadField: r0 = r2->field_7
    //     0x13088ec: ldur            w0, [x2, #7]
    // 0x13088f0: DecompressPointer r0
    //     0x13088f0: add             x0, x0, HEAP, lsl #32
    // 0x13088f4: LoadField: r2 = r0->field_b
    //     0x13088f4: ldur            w2, [x0, #0xb]
    // 0x13088f8: DecompressPointer r2
    //     0x13088f8: add             x2, x2, HEAP, lsl #32
    // 0x13088fc: LoadField: r0 = r2->field_27
    //     0x13088fc: ldur            w0, [x2, #0x27]
    // 0x1308900: DecompressPointer r0
    //     0x1308900: add             x0, x0, HEAP, lsl #32
    // 0x1308904: stur            x0, [fp, #-0x10]
    // 0x1308908: LoadField: r5 = r2->field_2b
    //     0x1308908: ldur            w5, [x2, #0x2b]
    // 0x130890c: DecompressPointer r5
    //     0x130890c: add             x5, x5, HEAP, lsl #32
    // 0x1308910: stur            x5, [fp, #-8]
    // 0x1308914: r0 = TextSelection()
    //     0x1308914: bl              #0x861260  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0x1308918: mov             x1, x0
    // 0x130891c: ldur            x0, [fp, #-0x28]
    // 0x1308920: ArrayStore: r1[0] = r0  ; List_8
    //     0x1308920: stur            x0, [x1, #0x17]
    // 0x1308924: ldur            x2, [fp, #-0x20]
    // 0x1308928: StoreField: r1->field_1f = r2
    //     0x1308928: stur            x2, [x1, #0x1f]
    // 0x130892c: ldur            x3, [fp, #-0x10]
    // 0x1308930: StoreField: r1->field_27 = r3
    //     0x1308930: stur            w3, [x1, #0x27]
    // 0x1308934: ldur            x3, [fp, #-8]
    // 0x1308938: StoreField: r1->field_2b = r3
    //     0x1308938: stur            w3, [x1, #0x2b]
    // 0x130893c: cmp             x0, x2
    // 0x1308940: b.ge            #0x130894c
    // 0x1308944: mov             x3, x0
    // 0x1308948: b               #0x1308950
    // 0x130894c: mov             x3, x2
    // 0x1308950: cmp             x0, x2
    // 0x1308954: b.ge            #0x130895c
    // 0x1308958: mov             x0, x2
    // 0x130895c: StoreField: r1->field_7 = r3
    //     0x130895c: stur            x3, [x1, #7]
    // 0x1308960: StoreField: r1->field_f = r0
    //     0x1308960: stur            x0, [x1, #0xf]
    // 0x1308964: mov             x2, x1
    // 0x1308968: ldur            x0, [fp, #-0x38]
    // 0x130896c: ldur            x1, [fp, #-0x30]
    // 0x1308970: stur            x2, [fp, #-8]
    // 0x1308974: r0 = TextEditingValue()
    //     0x1308974: bl              #0x86e1d4  ; AllocateTextEditingValueStub -> TextEditingValue (size=0x14)
    // 0x1308978: ldur            x1, [fp, #-0x30]
    // 0x130897c: StoreField: r0->field_7 = r1
    //     0x130897c: stur            w1, [x0, #7]
    // 0x1308980: ldur            x1, [fp, #-8]
    // 0x1308984: StoreField: r0->field_b = r1
    //     0x1308984: stur            w1, [x0, #0xb]
    // 0x1308988: ldur            x1, [fp, #-0x38]
    // 0x130898c: StoreField: r0->field_f = r1
    //     0x130898c: stur            w1, [x0, #0xf]
    // 0x1308990: LeaveFrame
    //     0x1308990: mov             SP, fp
    //     0x1308994: ldp             fp, lr, [SP], #0x10
    // 0x1308998: ret
    //     0x1308998: ret             
    // 0x130899c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x130899c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13089a0: b               #0x1308844
  }
  _ _TextEditingValueAccumulator(/* No info */) {
    // ** addr: 0x1308d48, size: 0xf4
    // 0x1308d48: EnterFrame
    //     0x1308d48: stp             fp, lr, [SP, #-0x10]!
    //     0x1308d4c: mov             fp, SP
    // 0x1308d50: AllocStack(0x18)
    //     0x1308d50: sub             SP, SP, #0x18
    // 0x1308d54: SetupParameters(_TextEditingValueAccumulator this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x1308d54: mov             x0, x2
    //     0x1308d58: stur            x1, [fp, #-8]
    //     0x1308d5c: stur            x2, [fp, #-0x10]
    // 0x1308d60: CheckStackOverflow
    //     0x1308d60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1308d64: cmp             SP, x16
    //     0x1308d68: b.ls            #0x1308e34
    // 0x1308d6c: r0 = StringBuffer()
    //     0x1308d6c: bl              #0x7e51d4  ; AllocateStringBufferStub -> StringBuffer (size=0x38)
    // 0x1308d70: mov             x1, x0
    // 0x1308d74: stur            x0, [fp, #-0x18]
    // 0x1308d78: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x1308d78: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x1308d7c: r0 = StringBuffer()
    //     0x1308d7c: bl              #0x7e4a4c  ; [dart:core] StringBuffer::StringBuffer
    // 0x1308d80: ldur            x0, [fp, #-0x18]
    // 0x1308d84: ldur            x2, [fp, #-8]
    // 0x1308d88: StoreField: r2->field_b = r0
    //     0x1308d88: stur            w0, [x2, #0xb]
    //     0x1308d8c: ldurb           w16, [x2, #-1]
    //     0x1308d90: ldurb           w17, [x0, #-1]
    //     0x1308d94: and             x16, x17, x16, lsr #2
    //     0x1308d98: tst             x16, HEAP, lsr #32
    //     0x1308d9c: b.eq            #0x1308da4
    //     0x1308da0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x1308da4: ldur            x0, [fp, #-0x10]
    // 0x1308da8: StoreField: r2->field_7 = r0
    //     0x1308da8: stur            w0, [x2, #7]
    //     0x1308dac: ldurb           w16, [x2, #-1]
    //     0x1308db0: ldurb           w17, [x0, #-1]
    //     0x1308db4: and             x16, x17, x16, lsr #2
    //     0x1308db8: tst             x16, HEAP, lsr #32
    //     0x1308dbc: b.eq            #0x1308dc4
    //     0x1308dc0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x1308dc4: ldur            x0, [fp, #-0x10]
    // 0x1308dc8: LoadField: r1 = r0->field_b
    //     0x1308dc8: ldur            w1, [x0, #0xb]
    // 0x1308dcc: DecompressPointer r1
    //     0x1308dcc: add             x1, x1, HEAP, lsl #32
    // 0x1308dd0: r0 = fromTextSelection()
    //     0x1308dd0: bl              #0x1308e9c  ; [package:flutter/src/services/text_formatter.dart] _MutableTextRange::fromTextSelection
    // 0x1308dd4: ldur            x2, [fp, #-8]
    // 0x1308dd8: StoreField: r2->field_f = r0
    //     0x1308dd8: stur            w0, [x2, #0xf]
    //     0x1308ddc: ldurb           w16, [x2, #-1]
    //     0x1308de0: ldurb           w17, [x0, #-1]
    //     0x1308de4: and             x16, x17, x16, lsr #2
    //     0x1308de8: tst             x16, HEAP, lsr #32
    //     0x1308dec: b.eq            #0x1308df4
    //     0x1308df0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x1308df4: ldur            x0, [fp, #-0x10]
    // 0x1308df8: LoadField: r1 = r0->field_f
    //     0x1308df8: ldur            w1, [x0, #0xf]
    // 0x1308dfc: DecompressPointer r1
    //     0x1308dfc: add             x1, x1, HEAP, lsl #32
    // 0x1308e00: r0 = fromComposingRange()
    //     0x1308e00: bl              #0x1308e3c  ; [package:flutter/src/services/text_formatter.dart] _MutableTextRange::fromComposingRange
    // 0x1308e04: ldur            x1, [fp, #-8]
    // 0x1308e08: StoreField: r1->field_13 = r0
    //     0x1308e08: stur            w0, [x1, #0x13]
    //     0x1308e0c: ldurb           w16, [x1, #-1]
    //     0x1308e10: ldurb           w17, [x0, #-1]
    //     0x1308e14: and             x16, x17, x16, lsr #2
    //     0x1308e18: tst             x16, HEAP, lsr #32
    //     0x1308e1c: b.eq            #0x1308e24
    //     0x1308e20: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x1308e24: r0 = Null
    //     0x1308e24: mov             x0, NULL
    // 0x1308e28: LeaveFrame
    //     0x1308e28: mov             SP, fp
    //     0x1308e2c: ldp             fp, lr, [SP], #0x10
    // 0x1308e30: ret
    //     0x1308e30: ret             
    // 0x1308e34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1308e34: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1308e38: b               #0x1308d6c
  }
}

// class id: 2734, size: 0x18, field offset: 0x8
class _MutableTextRange extends Object {

  static _ fromComposingRange(/* No info */) {
    // ** addr: 0x1308e3c, size: 0x54
    // 0x1308e3c: EnterFrame
    //     0x1308e3c: stp             fp, lr, [SP, #-0x10]!
    //     0x1308e40: mov             fp, SP
    // 0x1308e44: AllocStack(0x10)
    //     0x1308e44: sub             SP, SP, #0x10
    // 0x1308e48: LoadField: r0 = r1->field_7
    //     0x1308e48: ldur            x0, [x1, #7]
    // 0x1308e4c: stur            x0, [fp, #-0x10]
    // 0x1308e50: tbnz            x0, #0x3f, #0x1308e80
    // 0x1308e54: LoadField: r2 = r1->field_f
    //     0x1308e54: ldur            x2, [x1, #0xf]
    // 0x1308e58: stur            x2, [fp, #-8]
    // 0x1308e5c: tbnz            x2, #0x3f, #0x1308e80
    // 0x1308e60: cmp             x0, x2
    // 0x1308e64: b.eq            #0x1308e80
    // 0x1308e68: r0 = _MutableTextRange()
    //     0x1308e68: bl              #0x1308e90  ; Allocate_MutableTextRangeStub -> _MutableTextRange (size=0x18)
    // 0x1308e6c: ldur            x1, [fp, #-0x10]
    // 0x1308e70: StoreField: r0->field_7 = r1
    //     0x1308e70: stur            x1, [x0, #7]
    // 0x1308e74: ldur            x1, [fp, #-8]
    // 0x1308e78: StoreField: r0->field_f = r1
    //     0x1308e78: stur            x1, [x0, #0xf]
    // 0x1308e7c: b               #0x1308e84
    // 0x1308e80: r0 = Null
    //     0x1308e80: mov             x0, NULL
    // 0x1308e84: LeaveFrame
    //     0x1308e84: mov             SP, fp
    //     0x1308e88: ldp             fp, lr, [SP], #0x10
    // 0x1308e8c: ret
    //     0x1308e8c: ret             
  }
  static _ fromTextSelection(/* No info */) {
    // ** addr: 0x1308e9c, size: 0x54
    // 0x1308e9c: EnterFrame
    //     0x1308e9c: stp             fp, lr, [SP, #-0x10]!
    //     0x1308ea0: mov             fp, SP
    // 0x1308ea4: AllocStack(0x10)
    //     0x1308ea4: sub             SP, SP, #0x10
    // 0x1308ea8: LoadField: r0 = r1->field_7
    //     0x1308ea8: ldur            x0, [x1, #7]
    // 0x1308eac: tbnz            x0, #0x3f, #0x1308ee0
    // 0x1308eb0: LoadField: r0 = r1->field_f
    //     0x1308eb0: ldur            x0, [x1, #0xf]
    // 0x1308eb4: tbnz            x0, #0x3f, #0x1308ee0
    // 0x1308eb8: ArrayLoad: r0 = r1[0]  ; List_8
    //     0x1308eb8: ldur            x0, [x1, #0x17]
    // 0x1308ebc: stur            x0, [fp, #-0x10]
    // 0x1308ec0: LoadField: r2 = r1->field_1f
    //     0x1308ec0: ldur            x2, [x1, #0x1f]
    // 0x1308ec4: stur            x2, [fp, #-8]
    // 0x1308ec8: r0 = _MutableTextRange()
    //     0x1308ec8: bl              #0x1308e90  ; Allocate_MutableTextRangeStub -> _MutableTextRange (size=0x18)
    // 0x1308ecc: ldur            x1, [fp, #-0x10]
    // 0x1308ed0: StoreField: r0->field_7 = r1
    //     0x1308ed0: stur            x1, [x0, #7]
    // 0x1308ed4: ldur            x1, [fp, #-8]
    // 0x1308ed8: StoreField: r0->field_f = r1
    //     0x1308ed8: stur            x1, [x0, #0xf]
    // 0x1308edc: b               #0x1308ee4
    // 0x1308ee0: r0 = Null
    //     0x1308ee0: mov             x0, NULL
    // 0x1308ee4: LeaveFrame
    //     0x1308ee4: mov             SP, fp
    //     0x1308ee8: ldp             fp, lr, [SP], #0x10
    // 0x1308eec: ret
    //     0x1308eec: ret             
  }
}

// class id: 2735, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class TextInputFormatter extends Object {
}

// class id: 2738, size: 0x10, field offset: 0x8
class LengthLimitingTextInputFormatter extends TextInputFormatter {

  _ formatEditUpdate(/* No info */) {
    // ** addr: 0x1308efc, size: 0x1e0
    // 0x1308efc: EnterFrame
    //     0x1308efc: stp             fp, lr, [SP, #-0x10]!
    //     0x1308f00: mov             fp, SP
    // 0x1308f04: AllocStack(0x28)
    //     0x1308f04: sub             SP, SP, #0x28
    // 0x1308f08: SetupParameters(LengthLimitingTextInputFormatter this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */, dynamic _ /* r3 => r0, fp-0x20 */)
    //     0x1308f08: mov             x0, x3
    //     0x1308f0c: stur            x3, [fp, #-0x20]
    //     0x1308f10: mov             x3, x1
    //     0x1308f14: stur            x1, [fp, #-0x10]
    //     0x1308f18: stur            x2, [fp, #-0x18]
    // 0x1308f1c: CheckStackOverflow
    //     0x1308f1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1308f20: cmp             SP, x16
    //     0x1308f24: b.ls            #0x13090d4
    // 0x1308f28: LoadField: r1 = r3->field_7
    //     0x1308f28: ldur            w1, [x3, #7]
    // 0x1308f2c: DecompressPointer r1
    //     0x1308f2c: add             x1, x1, HEAP, lsl #32
    // 0x1308f30: cmp             w1, NULL
    // 0x1308f34: b.eq            #0x1308f7c
    // 0x1308f38: r4 = LoadInt32Instr(r1)
    //     0x1308f38: sbfx            x4, x1, #1, #0x1f
    //     0x1308f3c: tbz             w1, #0, #0x1308f44
    //     0x1308f40: ldur            x4, [x1, #7]
    // 0x1308f44: stur            x4, [fp, #-8]
    // 0x1308f48: cmn             x4, #1
    // 0x1308f4c: b.eq            #0x1308f7c
    // 0x1308f50: LoadField: r1 = r0->field_7
    //     0x1308f50: ldur            w1, [x0, #7]
    // 0x1308f54: DecompressPointer r1
    //     0x1308f54: add             x1, x1, HEAP, lsl #32
    // 0x1308f58: r0 = StringCharacters.characters()
    //     0x1308f58: bl              #0x8613d0  ; [package:characters/src/extensions.dart] ::StringCharacters.characters
    // 0x1308f5c: str             x0, [SP]
    // 0x1308f60: r0 = length()
    //     0x1308f60: bl              #0xbfbeac  ; [package:characters/src/characters_impl.dart] StringCharacters::length
    // 0x1308f64: r1 = LoadInt32Instr(r0)
    //     0x1308f64: sbfx            x1, x0, #1, #0x1f
    //     0x1308f68: tbz             w0, #0, #0x1308f70
    //     0x1308f6c: ldur            x1, [x0, #7]
    // 0x1308f70: ldur            x2, [fp, #-8]
    // 0x1308f74: cmp             x1, x2
    // 0x1308f78: b.gt            #0x1308f8c
    // 0x1308f7c: ldur            x0, [fp, #-0x20]
    // 0x1308f80: LeaveFrame
    //     0x1308f80: mov             SP, fp
    //     0x1308f84: ldp             fp, lr, [SP], #0x10
    // 0x1308f88: ret
    //     0x1308f88: ret             
    // 0x1308f8c: ldur            x0, [fp, #-0x10]
    // 0x1308f90: LoadField: r1 = r0->field_b
    //     0x1308f90: ldur            w1, [x0, #0xb]
    // 0x1308f94: DecompressPointer r1
    //     0x1308f94: add             x1, x1, HEAP, lsl #32
    // 0x1308f98: cmp             w1, NULL
    // 0x1308f9c: b.ne            #0x1308fac
    // 0x1308fa0: r0 = Instance_MaxLengthEnforcement
    //     0x1308fa0: add             x0, PP, #0x8f, lsl #12  ; [pp+0x8f608] Obj!MaxLengthEnforcement@12c3a21
    //     0x1308fa4: ldr             x0, [x0, #0x608]
    // 0x1308fa8: b               #0x1308fb0
    // 0x1308fac: mov             x0, x1
    // 0x1308fb0: LoadField: r1 = r0->field_7
    //     0x1308fb0: ldur            x1, [x0, #7]
    // 0x1308fb4: cmp             x1, #1
    // 0x1308fb8: b.gt            #0x1309040
    // 0x1308fbc: cmp             x1, #0
    // 0x1308fc0: b.gt            #0x1308fd4
    // 0x1308fc4: ldur            x0, [fp, #-0x20]
    // 0x1308fc8: LeaveFrame
    //     0x1308fc8: mov             SP, fp
    //     0x1308fcc: ldp             fp, lr, [SP], #0x10
    // 0x1308fd0: ret
    //     0x1308fd0: ret             
    // 0x1308fd4: ldur            x0, [fp, #-0x18]
    // 0x1308fd8: LoadField: r1 = r0->field_7
    //     0x1308fd8: ldur            w1, [x0, #7]
    // 0x1308fdc: DecompressPointer r1
    //     0x1308fdc: add             x1, x1, HEAP, lsl #32
    // 0x1308fe0: r0 = StringCharacters.characters()
    //     0x1308fe0: bl              #0x8613d0  ; [package:characters/src/extensions.dart] ::StringCharacters.characters
    // 0x1308fe4: str             x0, [SP]
    // 0x1308fe8: r0 = length()
    //     0x1308fe8: bl              #0xbfbeac  ; [package:characters/src/characters_impl.dart] StringCharacters::length
    // 0x1308fec: r1 = LoadInt32Instr(r0)
    //     0x1308fec: sbfx            x1, x0, #1, #0x1f
    //     0x1308ff0: tbz             w0, #0, #0x1308ff8
    //     0x1308ff4: ldur            x1, [x0, #7]
    // 0x1308ff8: ldur            x2, [fp, #-8]
    // 0x1308ffc: cmp             x1, x2
    // 0x1309000: b.ne            #0x130902c
    // 0x1309004: ldur            x0, [fp, #-0x18]
    // 0x1309008: LoadField: r1 = r0->field_b
    //     0x1309008: ldur            w1, [x0, #0xb]
    // 0x130900c: DecompressPointer r1
    //     0x130900c: add             x1, x1, HEAP, lsl #32
    // 0x1309010: LoadField: r3 = r1->field_7
    //     0x1309010: ldur            x3, [x1, #7]
    // 0x1309014: LoadField: r4 = r1->field_f
    //     0x1309014: ldur            x4, [x1, #0xf]
    // 0x1309018: cmp             x3, x4
    // 0x130901c: b.ne            #0x130902c
    // 0x1309020: LeaveFrame
    //     0x1309020: mov             SP, fp
    //     0x1309024: ldp             fp, lr, [SP], #0x10
    // 0x1309028: ret
    //     0x1309028: ret             
    // 0x130902c: ldur            x1, [fp, #-0x20]
    // 0x1309030: r0 = truncate()
    //     0x1309030: bl              #0x13090dc  ; [package:flutter/src/services/text_formatter.dart] LengthLimitingTextInputFormatter::truncate
    // 0x1309034: LeaveFrame
    //     0x1309034: mov             SP, fp
    //     0x1309038: ldp             fp, lr, [SP], #0x10
    // 0x130903c: ret
    //     0x130903c: ret             
    // 0x1309040: ldur            x0, [fp, #-0x18]
    // 0x1309044: LoadField: r1 = r0->field_7
    //     0x1309044: ldur            w1, [x0, #7]
    // 0x1309048: DecompressPointer r1
    //     0x1309048: add             x1, x1, HEAP, lsl #32
    // 0x130904c: r0 = StringCharacters.characters()
    //     0x130904c: bl              #0x8613d0  ; [package:characters/src/extensions.dart] ::StringCharacters.characters
    // 0x1309050: str             x0, [SP]
    // 0x1309054: r0 = length()
    //     0x1309054: bl              #0xbfbeac  ; [package:characters/src/characters_impl.dart] StringCharacters::length
    // 0x1309058: r1 = LoadInt32Instr(r0)
    //     0x1309058: sbfx            x1, x0, #1, #0x1f
    //     0x130905c: tbz             w0, #0, #0x1309064
    //     0x1309060: ldur            x1, [x0, #7]
    // 0x1309064: ldur            x2, [fp, #-8]
    // 0x1309068: cmp             x1, x2
    // 0x130906c: b.ne            #0x1309098
    // 0x1309070: ldur            x0, [fp, #-0x18]
    // 0x1309074: LoadField: r1 = r0->field_f
    //     0x1309074: ldur            w1, [x0, #0xf]
    // 0x1309078: DecompressPointer r1
    //     0x1309078: add             x1, x1, HEAP, lsl #32
    // 0x130907c: LoadField: r3 = r1->field_7
    //     0x130907c: ldur            x3, [x1, #7]
    // 0x1309080: tbnz            x3, #0x3f, #0x130908c
    // 0x1309084: LoadField: r3 = r1->field_f
    //     0x1309084: ldur            x3, [x1, #0xf]
    // 0x1309088: tbz             x3, #0x3f, #0x1309098
    // 0x130908c: LeaveFrame
    //     0x130908c: mov             SP, fp
    //     0x1309090: ldp             fp, lr, [SP], #0x10
    // 0x1309094: ret
    //     0x1309094: ret             
    // 0x1309098: ldur            x0, [fp, #-0x20]
    // 0x130909c: LoadField: r1 = r0->field_f
    //     0x130909c: ldur            w1, [x0, #0xf]
    // 0x13090a0: DecompressPointer r1
    //     0x13090a0: add             x1, x1, HEAP, lsl #32
    // 0x13090a4: LoadField: r3 = r1->field_7
    //     0x13090a4: ldur            x3, [x1, #7]
    // 0x13090a8: tbnz            x3, #0x3f, #0x13090c0
    // 0x13090ac: LoadField: r3 = r1->field_f
    //     0x13090ac: ldur            x3, [x1, #0xf]
    // 0x13090b0: tbnz            x3, #0x3f, #0x13090c0
    // 0x13090b4: LeaveFrame
    //     0x13090b4: mov             SP, fp
    //     0x13090b8: ldp             fp, lr, [SP], #0x10
    // 0x13090bc: ret
    //     0x13090bc: ret             
    // 0x13090c0: mov             x1, x0
    // 0x13090c4: r0 = truncate()
    //     0x13090c4: bl              #0x13090dc  ; [package:flutter/src/services/text_formatter.dart] LengthLimitingTextInputFormatter::truncate
    // 0x13090c8: LeaveFrame
    //     0x13090c8: mov             SP, fp
    //     0x13090cc: ldp             fp, lr, [SP], #0x10
    // 0x13090d0: ret
    //     0x13090d0: ret             
    // 0x13090d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13090d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13090d8: b               #0x1308f28
  }
  static _ truncate(/* No info */) {
    // ** addr: 0x13090dc, size: 0x1ac
    // 0x13090dc: EnterFrame
    //     0x13090dc: stp             fp, lr, [SP, #-0x10]!
    //     0x13090e0: mov             fp, SP
    // 0x13090e4: AllocStack(0x40)
    //     0x13090e4: sub             SP, SP, #0x40
    // 0x13090e8: SetupParameters(dynamic _ /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0x13090e8: stur            x1, [fp, #-0x10]
    //     0x13090ec: stur            x2, [fp, #-0x18]
    // 0x13090f0: CheckStackOverflow
    //     0x13090f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13090f4: cmp             SP, x16
    //     0x13090f8: b.ls            #0x1309280
    // 0x13090fc: LoadField: r0 = r1->field_7
    //     0x13090fc: ldur            w0, [x1, #7]
    // 0x1309100: DecompressPointer r0
    //     0x1309100: add             x0, x0, HEAP, lsl #32
    // 0x1309104: stur            x0, [fp, #-8]
    // 0x1309108: r0 = StringCharacterRange()
    //     0x1309108: bl              #0xb0a790  ; AllocateStringCharacterRangeStub -> StringCharacterRange (size=0x20)
    // 0x130910c: ldur            x1, [fp, #-8]
    // 0x1309110: stur            x0, [fp, #-0x20]
    // 0x1309114: StoreField: r0->field_7 = r1
    //     0x1309114: stur            w1, [x0, #7]
    // 0x1309118: StoreField: r0->field_b = rZR
    //     0x1309118: stur            xzr, [x0, #0xb]
    // 0x130911c: StoreField: r0->field_13 = rZR
    //     0x130911c: stur            xzr, [x0, #0x13]
    // 0x1309120: r0 = StringCharacters.characters()
    //     0x1309120: bl              #0x8613d0  ; [package:characters/src/extensions.dart] ::StringCharacters.characters
    // 0x1309124: str             x0, [SP]
    // 0x1309128: r0 = length()
    //     0x1309128: bl              #0xbfbeac  ; [package:characters/src/characters_impl.dart] StringCharacters::length
    // 0x130912c: r1 = LoadInt32Instr(r0)
    //     0x130912c: sbfx            x1, x0, #1, #0x1f
    //     0x1309130: tbz             w0, #0, #0x1309138
    //     0x1309134: ldur            x1, [x0, #7]
    // 0x1309138: ldur            x2, [fp, #-0x18]
    // 0x130913c: cmp             x1, x2
    // 0x1309140: b.le            #0x1309168
    // 0x1309144: r0 = BoxInt64Instr(r2)
    //     0x1309144: sbfiz           x0, x2, #1, #0x1f
    //     0x1309148: cmp             x2, x0, asr #1
    //     0x130914c: b.eq            #0x1309158
    //     0x1309150: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1309154: stur            x2, [x0, #7]
    // 0x1309158: str             x0, [SP]
    // 0x130915c: ldur            x1, [fp, #-0x20]
    // 0x1309160: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x1309160: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x1309164: r0 = expandNext()
    //     0x1309164: bl              #0x129ce4c  ; [package:characters/src/characters_impl.dart] StringCharacterRange::expandNext
    // 0x1309168: ldur            x0, [fp, #-0x10]
    // 0x130916c: ldur            x1, [fp, #-0x20]
    // 0x1309170: r0 = current()
    //     0x1309170: bl              #0x9fb4e0  ; [package:characters/src/characters_impl.dart] StringCharacterRange::current
    // 0x1309174: mov             x3, x0
    // 0x1309178: ldur            x2, [fp, #-0x10]
    // 0x130917c: stur            x3, [fp, #-8]
    // 0x1309180: LoadField: r4 = r2->field_b
    //     0x1309180: ldur            w4, [x2, #0xb]
    // 0x1309184: DecompressPointer r4
    //     0x1309184: add             x4, x4, HEAP, lsl #32
    // 0x1309188: LoadField: r0 = r4->field_7
    //     0x1309188: ldur            x0, [x4, #7]
    // 0x130918c: LoadField: r1 = r3->field_7
    //     0x130918c: ldur            w1, [x3, #7]
    // 0x1309190: r5 = LoadInt32Instr(r1)
    //     0x1309190: sbfx            x5, x1, #1, #0x1f
    // 0x1309194: stur            x5, [fp, #-0x18]
    // 0x1309198: cmp             x0, x5
    // 0x130919c: csel            x6, x5, x0, gt
    // 0x13091a0: LoadField: r0 = r4->field_f
    //     0x13091a0: ldur            x0, [x4, #0xf]
    // 0x13091a4: cmp             x0, x5
    // 0x13091a8: csel            x7, x5, x0, gt
    // 0x13091ac: r0 = BoxInt64Instr(r6)
    //     0x13091ac: sbfiz           x0, x6, #1, #0x1f
    //     0x13091b0: cmp             x6, x0, asr #1
    //     0x13091b4: b.eq            #0x13091c0
    //     0x13091b8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x13091bc: stur            x6, [x0, #7]
    // 0x13091c0: mov             x6, x0
    // 0x13091c4: r0 = BoxInt64Instr(r7)
    //     0x13091c4: sbfiz           x0, x7, #1, #0x1f
    //     0x13091c8: cmp             x7, x0, asr #1
    //     0x13091cc: b.eq            #0x13091d8
    //     0x13091d0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x13091d4: stur            x7, [x0, #7]
    // 0x13091d8: stp             x0, x6, [SP]
    // 0x13091dc: mov             x1, x4
    // 0x13091e0: r4 = const [0, 0x3, 0x2, 0x1, baseOffset, 0x1, extentOffset, 0x2, null]
    //     0x13091e0: ldr             x4, [PP, #0x6228]  ; [pp+0x6228] List(9) [0, 0x3, 0x2, 0x1, "baseOffset", 0x1, "extentOffset", 0x2, Null]
    // 0x13091e4: r0 = copyWith()
    //     0x13091e4: bl              #0x877a64  ; [package:flutter/src/services/text_editing.dart] TextSelection::copyWith
    // 0x13091e8: mov             x1, x0
    // 0x13091ec: ldur            x0, [fp, #-0x10]
    // 0x13091f0: stur            x1, [fp, #-0x20]
    // 0x13091f4: LoadField: r2 = r0->field_f
    //     0x13091f4: ldur            w2, [x0, #0xf]
    // 0x13091f8: DecompressPointer r2
    //     0x13091f8: add             x2, x2, HEAP, lsl #32
    // 0x13091fc: LoadField: r0 = r2->field_7
    //     0x13091fc: ldur            x0, [x2, #7]
    // 0x1309200: stur            x0, [fp, #-0x30]
    // 0x1309204: LoadField: r3 = r2->field_f
    //     0x1309204: ldur            x3, [x2, #0xf]
    // 0x1309208: cmp             x0, x3
    // 0x130920c: b.eq            #0x1309248
    // 0x1309210: ldur            x2, [fp, #-0x18]
    // 0x1309214: cmp             x2, x0
    // 0x1309218: b.le            #0x1309248
    // 0x130921c: cmp             x3, x2
    // 0x1309220: csel            x4, x2, x3, gt
    // 0x1309224: stur            x4, [fp, #-0x28]
    // 0x1309228: r0 = TextRange()
    //     0x1309228: bl              #0x83839c  ; AllocateTextRangeStub -> TextRange (size=0x18)
    // 0x130922c: mov             x1, x0
    // 0x1309230: ldur            x0, [fp, #-0x30]
    // 0x1309234: StoreField: r1->field_7 = r0
    //     0x1309234: stur            x0, [x1, #7]
    // 0x1309238: ldur            x0, [fp, #-0x28]
    // 0x130923c: StoreField: r1->field_f = r0
    //     0x130923c: stur            x0, [x1, #0xf]
    // 0x1309240: mov             x2, x1
    // 0x1309244: b               #0x130924c
    // 0x1309248: r2 = Instance_TextRange
    //     0x1309248: ldr             x2, [PP, #0x53d8]  ; [pp+0x53d8] Obj!TextRange@12a0471
    // 0x130924c: ldur            x1, [fp, #-8]
    // 0x1309250: ldur            x0, [fp, #-0x20]
    // 0x1309254: stur            x2, [fp, #-0x10]
    // 0x1309258: r0 = TextEditingValue()
    //     0x1309258: bl              #0x86e1d4  ; AllocateTextEditingValueStub -> TextEditingValue (size=0x14)
    // 0x130925c: ldur            x1, [fp, #-8]
    // 0x1309260: StoreField: r0->field_7 = r1
    //     0x1309260: stur            w1, [x0, #7]
    // 0x1309264: ldur            x1, [fp, #-0x20]
    // 0x1309268: StoreField: r0->field_b = r1
    //     0x1309268: stur            w1, [x0, #0xb]
    // 0x130926c: ldur            x1, [fp, #-0x10]
    // 0x1309270: StoreField: r0->field_f = r1
    //     0x1309270: stur            w1, [x0, #0xf]
    // 0x1309274: LeaveFrame
    //     0x1309274: mov             SP, fp
    //     0x1309278: ldp             fp, lr, [SP], #0x10
    // 0x130927c: ret
    //     0x130927c: ret             
    // 0x1309280: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1309280: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1309284: b               #0x13090fc
  }
}

// class id: 2739, size: 0x14, field offset: 0x8
class FilteringTextInputFormatter extends TextInputFormatter {

  static late final TextInputFormatter digitsOnly; // offset: 0xc38
  static late final TextInputFormatter singleLineFormatter; // offset: 0xc34

  static TextInputFormatter singleLineFormatter() {
    // ** addr: 0xd48c2c, size: 0x30
    // 0xd48c2c: EnterFrame
    //     0xd48c2c: stp             fp, lr, [SP, #-0x10]!
    //     0xd48c30: mov             fp, SP
    // 0xd48c34: r0 = FilteringTextInputFormatter()
    //     0xd48c34: bl              #0xd48c5c  ; AllocateFilteringTextInputFormatterStub -> FilteringTextInputFormatter (size=0x14)
    // 0xd48c38: r1 = "\n"
    //     0xd48c38: ldr             x1, [PP, #0x8c0]  ; [pp+0x8c0] "\n"
    // 0xd48c3c: StoreField: r0->field_b = r1
    //     0xd48c3c: stur            w1, [x0, #0xb]
    // 0xd48c40: r1 = false
    //     0xd48c40: add             x1, NULL, #0x30  ; false
    // 0xd48c44: StoreField: r0->field_7 = r1
    //     0xd48c44: stur            w1, [x0, #7]
    // 0xd48c48: r1 = ""
    //     0xd48c48: ldr             x1, [PP, #0x900]  ; [pp+0x900] ""
    // 0xd48c4c: StoreField: r0->field_f = r1
    //     0xd48c4c: stur            w1, [x0, #0xf]
    // 0xd48c50: LeaveFrame
    //     0xd48c50: mov             SP, fp
    //     0xd48c54: ldp             fp, lr, [SP], #0x10
    // 0xd48c58: ret
    //     0xd48c58: ret             
  }
  static TextInputFormatter digitsOnly() {
    // ** addr: 0x106cb98, size: 0x78
    // 0x106cb98: EnterFrame
    //     0x106cb98: stp             fp, lr, [SP, #-0x10]!
    //     0x106cb9c: mov             fp, SP
    // 0x106cba0: AllocStack(0x38)
    //     0x106cba0: sub             SP, SP, #0x38
    // 0x106cba4: CheckStackOverflow
    //     0x106cba4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x106cba8: cmp             SP, x16
    //     0x106cbac: b.ls            #0x106cc08
    // 0x106cbb0: r16 = "[0-9]"
    //     0x106cbb0: add             x16, PP, #0x7d, lsl #12  ; [pp+0x7d1b0] "[0-9]"
    //     0x106cbb4: ldr             x16, [x16, #0x1b0]
    // 0x106cbb8: stp             x16, NULL, [SP, #0x20]
    // 0x106cbbc: r16 = false
    //     0x106cbbc: add             x16, NULL, #0x30  ; false
    // 0x106cbc0: r30 = true
    //     0x106cbc0: add             lr, NULL, #0x20  ; true
    // 0x106cbc4: stp             lr, x16, [SP, #0x10]
    // 0x106cbc8: r16 = false
    //     0x106cbc8: add             x16, NULL, #0x30  ; false
    // 0x106cbcc: r30 = false
    //     0x106cbcc: add             lr, NULL, #0x30  ; false
    // 0x106cbd0: stp             lr, x16, [SP]
    // 0x106cbd4: r4 = const [0, 0x6, 0x6, 0x2, caseSensitive, 0x3, dotAll, 0x5, multiLine, 0x2, unicode, 0x4, null]
    //     0x106cbd4: ldr             x4, [PP, #0xa48]  ; [pp+0xa48] List(13) [0, 0x6, 0x6, 0x2, "caseSensitive", 0x3, "dotAll", 0x5, "multiLine", 0x2, "unicode", 0x4, Null]
    // 0x106cbd8: r0 = _RegExp()
    //     0x106cbd8: bl              #0x7eb40c  ; [dart:core] _RegExp::_RegExp
    // 0x106cbdc: stur            x0, [fp, #-8]
    // 0x106cbe0: r0 = FilteringTextInputFormatter()
    //     0x106cbe0: bl              #0xd48c5c  ; AllocateFilteringTextInputFormatterStub -> FilteringTextInputFormatter (size=0x14)
    // 0x106cbe4: ldur            x1, [fp, #-8]
    // 0x106cbe8: StoreField: r0->field_b = r1
    //     0x106cbe8: stur            w1, [x0, #0xb]
    // 0x106cbec: r1 = true
    //     0x106cbec: add             x1, NULL, #0x20  ; true
    // 0x106cbf0: StoreField: r0->field_7 = r1
    //     0x106cbf0: stur            w1, [x0, #7]
    // 0x106cbf4: r1 = ""
    //     0x106cbf4: ldr             x1, [PP, #0x900]  ; [pp+0x900] ""
    // 0x106cbf8: StoreField: r0->field_f = r1
    //     0x106cbf8: stur            w1, [x0, #0xf]
    // 0x106cbfc: LeaveFrame
    //     0x106cbfc: mov             SP, fp
    //     0x106cc00: ldp             fp, lr, [SP], #0x10
    // 0x106cc04: ret
    //     0x106cc04: ret             
    // 0x106cc08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x106cc08: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x106cc0c: b               #0x106cbb0
  }
  _ formatEditUpdate(/* No info */) {
    // ** addr: 0x1308558, size: 0x2d0
    // 0x1308558: EnterFrame
    //     0x1308558: stp             fp, lr, [SP, #-0x10]!
    //     0x130855c: mov             fp, SP
    // 0x1308560: AllocStack(0x48)
    //     0x1308560: sub             SP, SP, #0x48
    // 0x1308564: SetupParameters(FilteringTextInputFormatter this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0 */, dynamic _ /* r3 => r2, fp-0x10 */)
    //     0x1308564: mov             x0, x2
    //     0x1308568: mov             x2, x3
    //     0x130856c: stur            x1, [fp, #-8]
    //     0x1308570: stur            x3, [fp, #-0x10]
    // 0x1308574: CheckStackOverflow
    //     0x1308574: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1308578: cmp             SP, x16
    //     0x130857c: b.ls            #0x1308818
    // 0x1308580: r0 = _TextEditingValueAccumulator()
    //     0x1308580: bl              #0x1308ef0  ; Allocate_TextEditingValueAccumulatorStub -> _TextEditingValueAccumulator (size=0x18)
    // 0x1308584: mov             x1, x0
    // 0x1308588: ldur            x2, [fp, #-0x10]
    // 0x130858c: stur            x0, [fp, #-0x18]
    // 0x1308590: r0 = _TextEditingValueAccumulator()
    //     0x1308590: bl              #0x1308d48  ; [package:flutter/src/services/text_formatter.dart] _TextEditingValueAccumulator::_TextEditingValueAccumulator
    // 0x1308594: ldur            x3, [fp, #-8]
    // 0x1308598: LoadField: r1 = r3->field_b
    //     0x1308598: ldur            w1, [x3, #0xb]
    // 0x130859c: DecompressPointer r1
    //     0x130859c: add             x1, x1, HEAP, lsl #32
    // 0x13085a0: ldur            x0, [fp, #-0x10]
    // 0x13085a4: LoadField: r4 = r0->field_7
    //     0x13085a4: ldur            w4, [x0, #7]
    // 0x13085a8: DecompressPointer r4
    //     0x13085a8: add             x4, x4, HEAP, lsl #32
    // 0x13085ac: stur            x4, [fp, #-0x20]
    // 0x13085b0: r0 = LoadClassIdInstr(r1)
    //     0x13085b0: ldur            x0, [x1, #-1]
    //     0x13085b4: ubfx            x0, x0, #0xc, #0x14
    // 0x13085b8: mov             x2, x4
    // 0x13085bc: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x13085bc: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x13085c0: r0 = GDT[cid_x0 + -0xfcf]()
    //     0x13085c0: sub             lr, x0, #0xfcf
    //     0x13085c4: ldr             lr, [x21, lr, lsl #3]
    //     0x13085c8: blr             lr
    // 0x13085cc: r1 = LoadClassIdInstr(r0)
    //     0x13085cc: ldur            x1, [x0, #-1]
    //     0x13085d0: ubfx            x1, x1, #0xc, #0x14
    // 0x13085d4: mov             x16, x0
    // 0x13085d8: mov             x0, x1
    // 0x13085dc: mov             x1, x16
    // 0x13085e0: r0 = GDT[cid_x0 + 0x12641]()
    //     0x13085e0: mov             x17, #0x2641
    //     0x13085e4: movk            x17, #1, lsl #16
    //     0x13085e8: add             lr, x0, x17
    //     0x13085ec: ldr             lr, [x21, lr, lsl #3]
    //     0x13085f0: blr             lr
    // 0x13085f4: mov             x3, x0
    // 0x13085f8: ldur            x2, [fp, #-8]
    // 0x13085fc: stur            x3, [fp, #-0x30]
    // 0x1308600: LoadField: r4 = r2->field_7
    //     0x1308600: ldur            w4, [x2, #7]
    // 0x1308604: DecompressPointer r4
    //     0x1308604: add             x4, x4, HEAP, lsl #32
    // 0x1308608: stur            x4, [fp, #-0x28]
    // 0x130860c: r5 = Null
    //     0x130860c: mov             x5, NULL
    // 0x1308610: stur            x5, [fp, #-0x10]
    // 0x1308614: CheckStackOverflow
    //     0x1308614: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1308618: cmp             SP, x16
    //     0x130861c: b.ls            #0x1308820
    // 0x1308620: r0 = LoadClassIdInstr(r3)
    //     0x1308620: ldur            x0, [x3, #-1]
    //     0x1308624: ubfx            x0, x0, #0xc, #0x14
    // 0x1308628: mov             x1, x3
    // 0x130862c: r0 = GDT[cid_x0 + 0x1845b]()
    //     0x130862c: mov             x17, #0x845b
    //     0x1308630: movk            x17, #1, lsl #16
    //     0x1308634: add             lr, x0, x17
    //     0x1308638: ldr             lr, [x21, lr, lsl #3]
    //     0x130863c: blr             lr
    // 0x1308640: tbnz            w0, #4, #0x1308788
    // 0x1308644: ldur            x2, [fp, #-0x30]
    // 0x1308648: ldur            x3, [fp, #-0x10]
    // 0x130864c: r0 = LoadClassIdInstr(r2)
    //     0x130864c: ldur            x0, [x2, #-1]
    //     0x1308650: ubfx            x0, x0, #0xc, #0x14
    // 0x1308654: mov             x1, x2
    // 0x1308658: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0x1308658: mov             x17, #0x7d4c
    //     0x130865c: movk            x17, #1, lsl #16
    //     0x1308660: add             lr, x0, x17
    //     0x1308664: ldr             lr, [x21, lr, lsl #3]
    //     0x1308668: blr             lr
    // 0x130866c: mov             x2, x0
    // 0x1308670: ldur            x1, [fp, #-0x10]
    // 0x1308674: stur            x2, [fp, #-0x38]
    // 0x1308678: cmp             w1, NULL
    // 0x130867c: b.ne            #0x1308688
    // 0x1308680: r0 = Null
    //     0x1308680: mov             x0, NULL
    // 0x1308684: b               #0x13086b4
    // 0x1308688: r0 = LoadClassIdInstr(r1)
    //     0x1308688: ldur            x0, [x1, #-1]
    //     0x130868c: ubfx            x0, x0, #0xc, #0x14
    // 0x1308690: r0 = GDT[cid_x0 + -0xfae]()
    //     0x1308690: sub             lr, x0, #0xfae
    //     0x1308694: ldr             lr, [x21, lr, lsl #3]
    //     0x1308698: blr             lr
    // 0x130869c: mov             x2, x0
    // 0x13086a0: r0 = BoxInt64Instr(r2)
    //     0x13086a0: sbfiz           x0, x2, #1, #0x1f
    //     0x13086a4: cmp             x2, x0, asr #1
    //     0x13086a8: b.eq            #0x13086b4
    //     0x13086ac: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x13086b0: stur            x2, [x0, #7]
    // 0x13086b4: cmp             w0, NULL
    // 0x13086b8: b.ne            #0x13086c4
    // 0x13086bc: r4 = 0
    //     0x13086bc: mov             x4, #0
    // 0x13086c0: b               #0x13086d4
    // 0x13086c4: r1 = LoadInt32Instr(r0)
    //     0x13086c4: sbfx            x1, x0, #1, #0x1f
    //     0x13086c8: tbz             w0, #0, #0x13086d0
    //     0x13086cc: ldur            x1, [x0, #7]
    // 0x13086d0: mov             x4, x1
    // 0x13086d4: ldur            x2, [fp, #-0x38]
    // 0x13086d8: ldur            x3, [fp, #-0x28]
    // 0x13086dc: stur            x4, [fp, #-0x40]
    // 0x13086e0: r0 = LoadClassIdInstr(r2)
    //     0x13086e0: ldur            x0, [x2, #-1]
    //     0x13086e4: ubfx            x0, x0, #0xc, #0x14
    // 0x13086e8: mov             x1, x2
    // 0x13086ec: r0 = GDT[cid_x0 + -0xfa0]()
    //     0x13086ec: sub             lr, x0, #0xfa0
    //     0x13086f0: ldr             lr, [x21, lr, lsl #3]
    //     0x13086f4: blr             lr
    // 0x13086f8: ldur            x1, [fp, #-8]
    // 0x13086fc: ldur            x2, [fp, #-0x28]
    // 0x1308700: ldur            x3, [fp, #-0x40]
    // 0x1308704: mov             x5, x0
    // 0x1308708: ldur            x6, [fp, #-0x18]
    // 0x130870c: r0 = _processRegion()
    //     0x130870c: bl              #0x13089a4  ; [package:flutter/src/services/text_formatter.dart] FilteringTextInputFormatter::_processRegion
    // 0x1308710: ldur            x2, [fp, #-0x28]
    // 0x1308714: eor             x3, x2, #0x10
    // 0x1308718: ldur            x4, [fp, #-0x38]
    // 0x130871c: stur            x3, [fp, #-0x48]
    // 0x1308720: r0 = LoadClassIdInstr(r4)
    //     0x1308720: ldur            x0, [x4, #-1]
    //     0x1308724: ubfx            x0, x0, #0xc, #0x14
    // 0x1308728: mov             x1, x4
    // 0x130872c: r0 = GDT[cid_x0 + -0xfa0]()
    //     0x130872c: sub             lr, x0, #0xfa0
    //     0x1308730: ldr             lr, [x21, lr, lsl #3]
    //     0x1308734: blr             lr
    // 0x1308738: mov             x3, x0
    // 0x130873c: ldur            x2, [fp, #-0x38]
    // 0x1308740: stur            x3, [fp, #-0x40]
    // 0x1308744: r0 = LoadClassIdInstr(r2)
    //     0x1308744: ldur            x0, [x2, #-1]
    //     0x1308748: ubfx            x0, x0, #0xc, #0x14
    // 0x130874c: mov             x1, x2
    // 0x1308750: r0 = GDT[cid_x0 + -0xfae]()
    //     0x1308750: sub             lr, x0, #0xfae
    //     0x1308754: ldr             lr, [x21, lr, lsl #3]
    //     0x1308758: blr             lr
    // 0x130875c: ldur            x1, [fp, #-8]
    // 0x1308760: ldur            x2, [fp, #-0x48]
    // 0x1308764: ldur            x3, [fp, #-0x40]
    // 0x1308768: mov             x5, x0
    // 0x130876c: ldur            x6, [fp, #-0x18]
    // 0x1308770: r0 = _processRegion()
    //     0x1308770: bl              #0x13089a4  ; [package:flutter/src/services/text_formatter.dart] FilteringTextInputFormatter::_processRegion
    // 0x1308774: ldur            x5, [fp, #-0x38]
    // 0x1308778: ldur            x2, [fp, #-8]
    // 0x130877c: ldur            x3, [fp, #-0x30]
    // 0x1308780: ldur            x4, [fp, #-0x28]
    // 0x1308784: b               #0x1308610
    // 0x1308788: ldur            x1, [fp, #-0x10]
    // 0x130878c: cmp             w1, NULL
    // 0x1308790: b.ne            #0x130879c
    // 0x1308794: r0 = Null
    //     0x1308794: mov             x0, NULL
    // 0x1308798: b               #0x13087c8
    // 0x130879c: r0 = LoadClassIdInstr(r1)
    //     0x130879c: ldur            x0, [x1, #-1]
    //     0x13087a0: ubfx            x0, x0, #0xc, #0x14
    // 0x13087a4: r0 = GDT[cid_x0 + -0xfae]()
    //     0x13087a4: sub             lr, x0, #0xfae
    //     0x13087a8: ldr             lr, [x21, lr, lsl #3]
    //     0x13087ac: blr             lr
    // 0x13087b0: mov             x2, x0
    // 0x13087b4: r0 = BoxInt64Instr(r2)
    //     0x13087b4: sbfiz           x0, x2, #1, #0x1f
    //     0x13087b8: cmp             x2, x0, asr #1
    //     0x13087bc: b.eq            #0x13087c8
    //     0x13087c0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x13087c4: stur            x2, [x0, #7]
    // 0x13087c8: cmp             w0, NULL
    // 0x13087cc: b.ne            #0x13087d8
    // 0x13087d0: r3 = 0
    //     0x13087d0: mov             x3, #0
    // 0x13087d4: b               #0x13087e8
    // 0x13087d8: r1 = LoadInt32Instr(r0)
    //     0x13087d8: sbfx            x1, x0, #1, #0x1f
    //     0x13087dc: tbz             w0, #0, #0x13087e4
    //     0x13087e0: ldur            x1, [x0, #7]
    // 0x13087e4: mov             x3, x1
    // 0x13087e8: ldur            x0, [fp, #-0x20]
    // 0x13087ec: LoadField: r1 = r0->field_7
    //     0x13087ec: ldur            w1, [x0, #7]
    // 0x13087f0: r5 = LoadInt32Instr(r1)
    //     0x13087f0: sbfx            x5, x1, #1, #0x1f
    // 0x13087f4: ldur            x1, [fp, #-8]
    // 0x13087f8: ldur            x2, [fp, #-0x28]
    // 0x13087fc: ldur            x6, [fp, #-0x18]
    // 0x1308800: r0 = _processRegion()
    //     0x1308800: bl              #0x13089a4  ; [package:flutter/src/services/text_formatter.dart] FilteringTextInputFormatter::_processRegion
    // 0x1308804: ldur            x1, [fp, #-0x18]
    // 0x1308808: r0 = finalize()
    //     0x1308808: bl              #0x1308828  ; [package:flutter/src/services/text_formatter.dart] _TextEditingValueAccumulator::finalize
    // 0x130880c: LeaveFrame
    //     0x130880c: mov             SP, fp
    //     0x1308810: ldp             fp, lr, [SP], #0x10
    // 0x1308814: ret
    //     0x1308814: ret             
    // 0x1308818: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1308818: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x130881c: b               #0x1308580
    // 0x1308820: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1308820: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1308824: b               #0x1308620
  }
  _ _processRegion(/* No info */) {
    // ** addr: 0x13089a4, size: 0x3a4
    // 0x13089a4: EnterFrame
    //     0x13089a4: stp             fp, lr, [SP, #-0x10]!
    //     0x13089a8: mov             fp, SP
    // 0x13089ac: AllocStack(0x50)
    //     0x13089ac: sub             SP, SP, #0x50
    // 0x13089b0: SetupParameters(dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */, dynamic _ /* r6 => r6, fp-0x28 */)
    //     0x13089b0: stur            x3, [fp, #-0x18]
    //     0x13089b4: stur            x5, [fp, #-0x20]
    //     0x13089b8: stur            x6, [fp, #-0x28]
    // 0x13089bc: CheckStackOverflow
    //     0x13089bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13089c0: cmp             SP, x16
    //     0x13089c4: b.ls            #0x1308d40
    // 0x13089c8: r0 = BoxInt64Instr(r3)
    //     0x13089c8: sbfiz           x0, x3, #1, #0x1f
    //     0x13089cc: cmp             x3, x0, asr #1
    //     0x13089d0: b.eq            #0x13089dc
    //     0x13089d4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x13089d8: stur            x3, [x0, #7]
    // 0x13089dc: mov             x4, x0
    // 0x13089e0: stur            x4, [fp, #-0x10]
    // 0x13089e4: r0 = BoxInt64Instr(r5)
    //     0x13089e4: sbfiz           x0, x5, #1, #0x1f
    //     0x13089e8: cmp             x5, x0, asr #1
    //     0x13089ec: b.eq            #0x13089f8
    //     0x13089f0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x13089f4: stur            x5, [x0, #7]
    // 0x13089f8: stur            x0, [fp, #-8]
    // 0x13089fc: tbnz            w2, #4, #0x1308a14
    // 0x1308a00: mov             x4, x3
    // 0x1308a04: mov             x3, x5
    // 0x1308a08: mov             x0, x6
    // 0x1308a0c: r5 = ""
    //     0x1308a0c: ldr             x5, [PP, #0x900]  ; [pp+0x900] ""
    // 0x1308a10: b               #0x1308a48
    // 0x1308a14: LoadField: r1 = r6->field_7
    //     0x1308a14: ldur            w1, [x6, #7]
    // 0x1308a18: DecompressPointer r1
    //     0x1308a18: add             x1, x1, HEAP, lsl #32
    // 0x1308a1c: LoadField: r2 = r1->field_7
    //     0x1308a1c: ldur            w2, [x1, #7]
    // 0x1308a20: DecompressPointer r2
    //     0x1308a20: add             x2, x2, HEAP, lsl #32
    // 0x1308a24: str             x0, [SP]
    // 0x1308a28: mov             x1, x2
    // 0x1308a2c: mov             x2, x3
    // 0x1308a30: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x1308a30: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x1308a34: r0 = substring()
    //     0x1308a34: bl              #0x7e3f74  ; [dart:core] _StringBase::substring
    // 0x1308a38: mov             x5, x0
    // 0x1308a3c: ldur            x4, [fp, #-0x18]
    // 0x1308a40: ldur            x3, [fp, #-0x20]
    // 0x1308a44: ldur            x0, [fp, #-0x28]
    // 0x1308a48: stur            x5, [fp, #-0x30]
    // 0x1308a4c: LoadField: r1 = r0->field_b
    //     0x1308a4c: ldur            w1, [x0, #0xb]
    // 0x1308a50: DecompressPointer r1
    //     0x1308a50: add             x1, x1, HEAP, lsl #32
    // 0x1308a54: mov             x2, x5
    // 0x1308a58: r0 = write()
    //     0x1308a58: bl              #0x7e5154  ; [dart:core] StringBuffer::write
    // 0x1308a5c: ldur            x0, [fp, #-0x30]
    // 0x1308a60: LoadField: r1 = r0->field_7
    //     0x1308a60: ldur            w1, [x0, #7]
    // 0x1308a64: ldur            x5, [fp, #-0x18]
    // 0x1308a68: ldur            x4, [fp, #-0x20]
    // 0x1308a6c: sub             x0, x4, x5
    // 0x1308a70: r6 = LoadInt32Instr(r1)
    //     0x1308a70: sbfx            x6, x1, #1, #0x1f
    // 0x1308a74: stur            x6, [fp, #-0x48]
    // 0x1308a78: cmp             x6, x0
    // 0x1308a7c: b.ne            #0x1308a90
    // 0x1308a80: r0 = Null
    //     0x1308a80: mov             x0, NULL
    // 0x1308a84: LeaveFrame
    //     0x1308a84: mov             SP, fp
    //     0x1308a88: ldp             fp, lr, [SP], #0x10
    // 0x1308a8c: ret
    //     0x1308a8c: ret             
    // 0x1308a90: ldur            x7, [fp, #-0x28]
    // 0x1308a94: LoadField: r8 = r7->field_f
    //     0x1308a94: ldur            w8, [x7, #0xf]
    // 0x1308a98: DecompressPointer r8
    //     0x1308a98: add             x8, x8, HEAP, lsl #32
    // 0x1308a9c: stur            x8, [fp, #-0x30]
    // 0x1308aa0: cmp             w8, NULL
    // 0x1308aa4: b.ne            #0x1308ab4
    // 0x1308aa8: mov             x4, x5
    // 0x1308aac: mov             x5, x8
    // 0x1308ab0: b               #0x1308b40
    // 0x1308ab4: LoadField: r9 = r8->field_7
    //     0x1308ab4: ldur            x9, [x8, #7]
    // 0x1308ab8: stur            x9, [fp, #-0x40]
    // 0x1308abc: LoadField: r0 = r7->field_7
    //     0x1308abc: ldur            w0, [x7, #7]
    // 0x1308ac0: DecompressPointer r0
    //     0x1308ac0: add             x0, x0, HEAP, lsl #32
    // 0x1308ac4: LoadField: r1 = r0->field_b
    //     0x1308ac4: ldur            w1, [x0, #0xb]
    // 0x1308ac8: DecompressPointer r1
    //     0x1308ac8: add             x1, x1, HEAP, lsl #32
    // 0x1308acc: ArrayLoad: r2 = r1[0]  ; List_8
    //     0x1308acc: ldur            x2, [x1, #0x17]
    // 0x1308ad0: cmp             x2, x5
    // 0x1308ad4: b.gt            #0x1308ae8
    // 0x1308ad8: cmp             x2, x4
    // 0x1308adc: b.ge            #0x1308ae8
    // 0x1308ae0: r10 = 0
    //     0x1308ae0: mov             x10, #0
    // 0x1308ae4: b               #0x1308aec
    // 0x1308ae8: mov             x10, x6
    // 0x1308aec: stur            x10, [fp, #-0x38]
    // 0x1308af0: r0 = BoxInt64Instr(r2)
    //     0x1308af0: sbfiz           x0, x2, #1, #0x1f
    //     0x1308af4: cmp             x2, x0, asr #1
    //     0x1308af8: b.eq            #0x1308b04
    //     0x1308afc: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1308b00: stur            x2, [x0, #7]
    // 0x1308b04: mov             x1, x0
    // 0x1308b08: ldur            x2, [fp, #-0x10]
    // 0x1308b0c: ldur            x3, [fp, #-8]
    // 0x1308b10: r0 = clamp()
    //     0x1308b10: bl              #0x13db4a0  ; [dart:core] _IntegerImplementation::clamp
    // 0x1308b14: r1 = LoadInt32Instr(r0)
    //     0x1308b14: sbfx            x1, x0, #1, #0x1f
    //     0x1308b18: tbz             w0, #0, #0x1308b20
    //     0x1308b1c: ldur            x1, [x0, #7]
    // 0x1308b20: ldur            x4, [fp, #-0x18]
    // 0x1308b24: sub             x0, x1, x4
    // 0x1308b28: ldur            x1, [fp, #-0x38]
    // 0x1308b2c: sub             x2, x1, x0
    // 0x1308b30: ldur            x0, [fp, #-0x40]
    // 0x1308b34: add             x1, x0, x2
    // 0x1308b38: ldur            x5, [fp, #-0x30]
    // 0x1308b3c: StoreField: r5->field_7 = r1
    //     0x1308b3c: stur            x1, [x5, #7]
    // 0x1308b40: cmp             w5, NULL
    // 0x1308b44: b.eq            #0x1308be0
    // 0x1308b48: ldur            x6, [fp, #-0x28]
    // 0x1308b4c: LoadField: r7 = r5->field_f
    //     0x1308b4c: ldur            x7, [x5, #0xf]
    // 0x1308b50: stur            x7, [fp, #-0x40]
    // 0x1308b54: LoadField: r0 = r6->field_7
    //     0x1308b54: ldur            w0, [x6, #7]
    // 0x1308b58: DecompressPointer r0
    //     0x1308b58: add             x0, x0, HEAP, lsl #32
    // 0x1308b5c: LoadField: r1 = r0->field_b
    //     0x1308b5c: ldur            w1, [x0, #0xb]
    // 0x1308b60: DecompressPointer r1
    //     0x1308b60: add             x1, x1, HEAP, lsl #32
    // 0x1308b64: LoadField: r2 = r1->field_1f
    //     0x1308b64: ldur            x2, [x1, #0x1f]
    // 0x1308b68: cmp             x2, x4
    // 0x1308b6c: b.gt            #0x1308b84
    // 0x1308b70: ldur            x8, [fp, #-0x20]
    // 0x1308b74: cmp             x2, x8
    // 0x1308b78: b.ge            #0x1308b88
    // 0x1308b7c: r9 = 0
    //     0x1308b7c: mov             x9, #0
    // 0x1308b80: b               #0x1308b8c
    // 0x1308b84: ldur            x8, [fp, #-0x20]
    // 0x1308b88: ldur            x9, [fp, #-0x48]
    // 0x1308b8c: stur            x9, [fp, #-0x38]
    // 0x1308b90: r0 = BoxInt64Instr(r2)
    //     0x1308b90: sbfiz           x0, x2, #1, #0x1f
    //     0x1308b94: cmp             x2, x0, asr #1
    //     0x1308b98: b.eq            #0x1308ba4
    //     0x1308b9c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1308ba0: stur            x2, [x0, #7]
    // 0x1308ba4: mov             x1, x0
    // 0x1308ba8: ldur            x2, [fp, #-0x10]
    // 0x1308bac: ldur            x3, [fp, #-8]
    // 0x1308bb0: r0 = clamp()
    //     0x1308bb0: bl              #0x13db4a0  ; [dart:core] _IntegerImplementation::clamp
    // 0x1308bb4: r1 = LoadInt32Instr(r0)
    //     0x1308bb4: sbfx            x1, x0, #1, #0x1f
    //     0x1308bb8: tbz             w0, #0, #0x1308bc0
    //     0x1308bbc: ldur            x1, [x0, #7]
    // 0x1308bc0: ldur            x4, [fp, #-0x18]
    // 0x1308bc4: sub             x0, x1, x4
    // 0x1308bc8: ldur            x1, [fp, #-0x38]
    // 0x1308bcc: sub             x2, x1, x0
    // 0x1308bd0: ldur            x0, [fp, #-0x40]
    // 0x1308bd4: add             x1, x0, x2
    // 0x1308bd8: ldur            x0, [fp, #-0x30]
    // 0x1308bdc: StoreField: r0->field_f = r1
    //     0x1308bdc: stur            x1, [x0, #0xf]
    // 0x1308be0: ldur            x5, [fp, #-0x28]
    // 0x1308be4: LoadField: r6 = r5->field_13
    //     0x1308be4: ldur            w6, [x5, #0x13]
    // 0x1308be8: DecompressPointer r6
    //     0x1308be8: add             x6, x6, HEAP, lsl #32
    // 0x1308bec: stur            x6, [fp, #-0x30]
    // 0x1308bf0: cmp             w6, NULL
    // 0x1308bf4: b.ne            #0x1308c00
    // 0x1308bf8: mov             x5, x6
    // 0x1308bfc: b               #0x1308c94
    // 0x1308c00: LoadField: r7 = r6->field_7
    //     0x1308c00: ldur            x7, [x6, #7]
    // 0x1308c04: stur            x7, [fp, #-0x40]
    // 0x1308c08: LoadField: r0 = r5->field_7
    //     0x1308c08: ldur            w0, [x5, #7]
    // 0x1308c0c: DecompressPointer r0
    //     0x1308c0c: add             x0, x0, HEAP, lsl #32
    // 0x1308c10: LoadField: r1 = r0->field_f
    //     0x1308c10: ldur            w1, [x0, #0xf]
    // 0x1308c14: DecompressPointer r1
    //     0x1308c14: add             x1, x1, HEAP, lsl #32
    // 0x1308c18: LoadField: r2 = r1->field_7
    //     0x1308c18: ldur            x2, [x1, #7]
    // 0x1308c1c: cmp             x2, x4
    // 0x1308c20: b.gt            #0x1308c38
    // 0x1308c24: ldur            x8, [fp, #-0x20]
    // 0x1308c28: cmp             x2, x8
    // 0x1308c2c: b.ge            #0x1308c3c
    // 0x1308c30: r9 = 0
    //     0x1308c30: mov             x9, #0
    // 0x1308c34: b               #0x1308c40
    // 0x1308c38: ldur            x8, [fp, #-0x20]
    // 0x1308c3c: ldur            x9, [fp, #-0x48]
    // 0x1308c40: stur            x9, [fp, #-0x38]
    // 0x1308c44: r0 = BoxInt64Instr(r2)
    //     0x1308c44: sbfiz           x0, x2, #1, #0x1f
    //     0x1308c48: cmp             x2, x0, asr #1
    //     0x1308c4c: b.eq            #0x1308c58
    //     0x1308c50: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1308c54: stur            x2, [x0, #7]
    // 0x1308c58: mov             x1, x0
    // 0x1308c5c: ldur            x2, [fp, #-0x10]
    // 0x1308c60: ldur            x3, [fp, #-8]
    // 0x1308c64: r0 = clamp()
    //     0x1308c64: bl              #0x13db4a0  ; [dart:core] _IntegerImplementation::clamp
    // 0x1308c68: r1 = LoadInt32Instr(r0)
    //     0x1308c68: sbfx            x1, x0, #1, #0x1f
    //     0x1308c6c: tbz             w0, #0, #0x1308c74
    //     0x1308c70: ldur            x1, [x0, #7]
    // 0x1308c74: ldur            x4, [fp, #-0x18]
    // 0x1308c78: sub             x0, x1, x4
    // 0x1308c7c: ldur            x1, [fp, #-0x38]
    // 0x1308c80: sub             x2, x1, x0
    // 0x1308c84: ldur            x0, [fp, #-0x40]
    // 0x1308c88: add             x1, x0, x2
    // 0x1308c8c: ldur            x5, [fp, #-0x30]
    // 0x1308c90: StoreField: r5->field_7 = r1
    //     0x1308c90: stur            x1, [x5, #7]
    // 0x1308c94: cmp             w5, NULL
    // 0x1308c98: b.eq            #0x1308d30
    // 0x1308c9c: ldur            x0, [fp, #-0x28]
    // 0x1308ca0: LoadField: r6 = r5->field_f
    //     0x1308ca0: ldur            x6, [x5, #0xf]
    // 0x1308ca4: stur            x6, [fp, #-0x38]
    // 0x1308ca8: LoadField: r1 = r0->field_7
    //     0x1308ca8: ldur            w1, [x0, #7]
    // 0x1308cac: DecompressPointer r1
    //     0x1308cac: add             x1, x1, HEAP, lsl #32
    // 0x1308cb0: LoadField: r0 = r1->field_f
    //     0x1308cb0: ldur            w0, [x1, #0xf]
    // 0x1308cb4: DecompressPointer r0
    //     0x1308cb4: add             x0, x0, HEAP, lsl #32
    // 0x1308cb8: LoadField: r2 = r0->field_f
    //     0x1308cb8: ldur            x2, [x0, #0xf]
    // 0x1308cbc: cmp             x2, x4
    // 0x1308cc0: b.gt            #0x1308cd8
    // 0x1308cc4: ldur            x0, [fp, #-0x20]
    // 0x1308cc8: cmp             x2, x0
    // 0x1308ccc: b.ge            #0x1308cd8
    // 0x1308cd0: r7 = 0
    //     0x1308cd0: mov             x7, #0
    // 0x1308cd4: b               #0x1308cdc
    // 0x1308cd8: ldur            x7, [fp, #-0x48]
    // 0x1308cdc: stur            x7, [fp, #-0x20]
    // 0x1308ce0: r0 = BoxInt64Instr(r2)
    //     0x1308ce0: sbfiz           x0, x2, #1, #0x1f
    //     0x1308ce4: cmp             x2, x0, asr #1
    //     0x1308ce8: b.eq            #0x1308cf4
    //     0x1308cec: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1308cf0: stur            x2, [x0, #7]
    // 0x1308cf4: mov             x1, x0
    // 0x1308cf8: ldur            x2, [fp, #-0x10]
    // 0x1308cfc: ldur            x3, [fp, #-8]
    // 0x1308d00: r0 = clamp()
    //     0x1308d00: bl              #0x13db4a0  ; [dart:core] _IntegerImplementation::clamp
    // 0x1308d04: r1 = LoadInt32Instr(r0)
    //     0x1308d04: sbfx            x1, x0, #1, #0x1f
    //     0x1308d08: tbz             w0, #0, #0x1308d10
    //     0x1308d0c: ldur            x1, [x0, #7]
    // 0x1308d10: ldur            x2, [fp, #-0x18]
    // 0x1308d14: sub             x3, x1, x2
    // 0x1308d18: ldur            x1, [fp, #-0x20]
    // 0x1308d1c: sub             x2, x1, x3
    // 0x1308d20: ldur            x1, [fp, #-0x38]
    // 0x1308d24: add             x3, x1, x2
    // 0x1308d28: ldur            x1, [fp, #-0x30]
    // 0x1308d2c: StoreField: r1->field_f = r3
    //     0x1308d2c: stur            x3, [x1, #0xf]
    // 0x1308d30: r0 = Null
    //     0x1308d30: mov             x0, NULL
    // 0x1308d34: LeaveFrame
    //     0x1308d34: mov             SP, fp
    //     0x1308d38: ldp             fp, lr, [SP], #0x10
    // 0x1308d3c: ret
    //     0x1308d3c: ret             
    // 0x1308d40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1308d40: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1308d44: b               #0x13089c8
  }
}

// class id: 8199, size: 0x14, field offset: 0x14
enum MaxLengthEnforcement extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11ab994, size: 0x64
    // 0x11ab994: EnterFrame
    //     0x11ab994: stp             fp, lr, [SP, #-0x10]!
    //     0x11ab998: mov             fp, SP
    // 0x11ab99c: AllocStack(0x10)
    //     0x11ab99c: sub             SP, SP, #0x10
    // 0x11ab9a0: SetupParameters(MaxLengthEnforcement this /* r1 => r0, fp-0x8 */)
    //     0x11ab9a0: mov             x0, x1
    //     0x11ab9a4: stur            x1, [fp, #-8]
    // 0x11ab9a8: CheckStackOverflow
    //     0x11ab9a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11ab9ac: cmp             SP, x16
    //     0x11ab9b0: b.ls            #0x11ab9f0
    // 0x11ab9b4: r1 = Null
    //     0x11ab9b4: mov             x1, NULL
    // 0x11ab9b8: r2 = 4
    //     0x11ab9b8: mov             x2, #4
    // 0x11ab9bc: r0 = AllocateArray()
    //     0x11ab9bc: bl              #0x13df928  ; AllocateArrayStub
    // 0x11ab9c0: r16 = "MaxLengthEnforcement."
    //     0x11ab9c0: add             x16, PP, #0x96, lsl #12  ; [pp+0x96150] "MaxLengthEnforcement."
    //     0x11ab9c4: ldr             x16, [x16, #0x150]
    // 0x11ab9c8: StoreField: r0->field_f = r16
    //     0x11ab9c8: stur            w16, [x0, #0xf]
    // 0x11ab9cc: ldur            x1, [fp, #-8]
    // 0x11ab9d0: LoadField: r2 = r1->field_f
    //     0x11ab9d0: ldur            w2, [x1, #0xf]
    // 0x11ab9d4: DecompressPointer r2
    //     0x11ab9d4: add             x2, x2, HEAP, lsl #32
    // 0x11ab9d8: StoreField: r0->field_13 = r2
    //     0x11ab9d8: stur            w2, [x0, #0x13]
    // 0x11ab9dc: str             x0, [SP]
    // 0x11ab9e0: r0 = _interpolate()
    //     0x11ab9e0: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11ab9e4: LeaveFrame
    //     0x11ab9e4: mov             SP, fp
    //     0x11ab9e8: ldp             fp, lr, [SP], #0x10
    // 0x11ab9ec: ret
    //     0x11ab9ec: ret             
    // 0x11ab9f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11ab9f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11ab9f4: b               #0x11ab9b4
  }
}
