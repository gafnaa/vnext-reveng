// lib: , url: package:flutter/src/services/text_boundary.dart

// class id: 1049100, size: 0x8
class :: {
}

// class id: 2905, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class TextBoundary extends Object {

  _ getTrailingTextBoundaryAt(/* No info */) {
    // ** addr: 0x13064a0, size: 0x70
    // 0x13064a0: EnterFrame
    //     0x13064a0: stp             fp, lr, [SP, #-0x10]!
    //     0x13064a4: mov             fp, SP
    // 0x13064a8: r0 = 0
    //     0x13064a8: mov             x0, #0
    // 0x13064ac: CheckStackOverflow
    //     0x13064ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13064b0: cmp             SP, x16
    //     0x13064b4: b.ls            #0x1306508
    // 0x13064b8: cmp             x0, x2
    // 0x13064bc: csel            x3, x2, x0, lt
    // 0x13064c0: r0 = LoadClassIdInstr(r1)
    //     0x13064c0: ldur            x0, [x1, #-1]
    //     0x13064c4: ubfx            x0, x0, #0xc, #0x14
    // 0x13064c8: mov             x2, x3
    // 0x13064cc: r0 = GDT[cid_x0 + -0xfff]()
    //     0x13064cc: sub             lr, x0, #0xfff
    //     0x13064d0: ldr             lr, [x21, lr, lsl #3]
    //     0x13064d4: blr             lr
    // 0x13064d8: LoadField: r2 = r0->field_f
    //     0x13064d8: ldur            x2, [x0, #0xf]
    // 0x13064dc: tbnz            x2, #0x3f, #0x13064f8
    // 0x13064e0: r0 = BoxInt64Instr(r2)
    //     0x13064e0: sbfiz           x0, x2, #1, #0x1f
    //     0x13064e4: cmp             x2, x0, asr #1
    //     0x13064e8: b.eq            #0x13064f4
    //     0x13064ec: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x13064f0: stur            x2, [x0, #7]
    // 0x13064f4: b               #0x13064fc
    // 0x13064f8: r0 = Null
    //     0x13064f8: mov             x0, NULL
    // 0x13064fc: LeaveFrame
    //     0x13064fc: mov             SP, fp
    //     0x1306500: ldp             fp, lr, [SP], #0x10
    // 0x1306504: ret
    //     0x1306504: ret             
    // 0x1306508: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1306508: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x130650c: b               #0x13064b8
  }
  _ getLeadingTextBoundaryAt(/* No info */) {
    // ** addr: 0x13069e8, size: 0x74
    // 0x13069e8: EnterFrame
    //     0x13069e8: stp             fp, lr, [SP, #-0x10]!
    //     0x13069ec: mov             fp, SP
    // 0x13069f0: CheckStackOverflow
    //     0x13069f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13069f4: cmp             SP, x16
    //     0x13069f8: b.ls            #0x1306a54
    // 0x13069fc: tbz             x2, #0x3f, #0x1306a10
    // 0x1306a00: r0 = Null
    //     0x1306a00: mov             x0, NULL
    // 0x1306a04: LeaveFrame
    //     0x1306a04: mov             SP, fp
    //     0x1306a08: ldp             fp, lr, [SP], #0x10
    // 0x1306a0c: ret
    //     0x1306a0c: ret             
    // 0x1306a10: r0 = LoadClassIdInstr(r1)
    //     0x1306a10: ldur            x0, [x1, #-1]
    //     0x1306a14: ubfx            x0, x0, #0xc, #0x14
    // 0x1306a18: r0 = GDT[cid_x0 + -0xfff]()
    //     0x1306a18: sub             lr, x0, #0xfff
    //     0x1306a1c: ldr             lr, [x21, lr, lsl #3]
    //     0x1306a20: blr             lr
    // 0x1306a24: LoadField: r2 = r0->field_7
    //     0x1306a24: ldur            x2, [x0, #7]
    // 0x1306a28: tbnz            x2, #0x3f, #0x1306a44
    // 0x1306a2c: r0 = BoxInt64Instr(r2)
    //     0x1306a2c: sbfiz           x0, x2, #1, #0x1f
    //     0x1306a30: cmp             x2, x0, asr #1
    //     0x1306a34: b.eq            #0x1306a40
    //     0x1306a38: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1306a3c: stur            x2, [x0, #7]
    // 0x1306a40: b               #0x1306a48
    // 0x1306a44: r0 = Null
    //     0x1306a44: mov             x0, NULL
    // 0x1306a48: LeaveFrame
    //     0x1306a48: mov             SP, fp
    //     0x1306a4c: ldp             fp, lr, [SP], #0x10
    // 0x1306a50: ret
    //     0x1306a50: ret             
    // 0x1306a54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1306a54: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1306a58: b               #0x13069fc
  }
}

// class id: 2907, size: 0xc, field offset: 0x8
//   const constructor, 
class DocumentBoundary extends TextBoundary {

  _ getTrailingTextBoundaryAt(/* No info */) {
    // ** addr: 0x13066cc, size: 0x28
    // 0x13066cc: LoadField: r3 = r1->field_7
    //     0x13066cc: ldur            w3, [x1, #7]
    // 0x13066d0: DecompressPointer r3
    //     0x13066d0: add             x3, x3, HEAP, lsl #32
    // 0x13066d4: LoadField: r1 = r3->field_7
    //     0x13066d4: ldur            w1, [x3, #7]
    // 0x13066d8: r3 = LoadInt32Instr(r1)
    //     0x13066d8: sbfx            x3, x1, #1, #0x1f
    // 0x13066dc: cmp             x2, x3
    // 0x13066e0: b.lt            #0x13066ec
    // 0x13066e4: r0 = Null
    //     0x13066e4: mov             x0, NULL
    // 0x13066e8: b               #0x13066f0
    // 0x13066ec: mov             x0, x1
    // 0x13066f0: ret
    //     0x13066f0: ret             
  }
  _ getLeadingTextBoundaryAt(/* No info */) {
    // ** addr: 0x1306d08, size: 0x14
    // 0x1306d08: tbz             x2, #0x3f, #0x1306d14
    // 0x1306d0c: r0 = Null
    //     0x1306d0c: mov             x0, NULL
    // 0x1306d10: b               #0x1306d18
    // 0x1306d14: r0 = 0
    //     0x1306d14: mov             x0, #0
    // 0x1306d18: ret
    //     0x1306d18: ret             
  }
}

// class id: 2908, size: 0xc, field offset: 0x8
//   const constructor, 
class ParagraphBoundary extends TextBoundary {

  _ getTrailingTextBoundaryAt(/* No info */) {
    // ** addr: 0x1306510, size: 0x1bc
    // 0x1306510: EnterFrame
    //     0x1306510: stp             fp, lr, [SP, #-0x10]!
    //     0x1306514: mov             fp, SP
    // 0x1306518: LoadField: r3 = r1->field_7
    //     0x1306518: ldur            w3, [x1, #7]
    // 0x130651c: DecompressPointer r3
    //     0x130651c: add             x3, x3, HEAP, lsl #32
    // 0x1306520: LoadField: r4 = r3->field_7
    //     0x1306520: ldur            w4, [x3, #7]
    // 0x1306524: r5 = LoadInt32Instr(r4)
    //     0x1306524: sbfx            x5, x4, #1, #0x1f
    // 0x1306528: cmp             x2, x5
    // 0x130652c: b.ge            #0x1306534
    // 0x1306530: cbnz            w4, #0x1306544
    // 0x1306534: r0 = Null
    //     0x1306534: mov             x0, NULL
    // 0x1306538: LeaveFrame
    //     0x1306538: mov             SP, fp
    //     0x130653c: ldp             fp, lr, [SP], #0x10
    // 0x1306540: ret
    //     0x1306540: ret             
    // 0x1306544: tbz             x2, #0x3f, #0x1306558
    // 0x1306548: r0 = 0
    //     0x1306548: mov             x0, #0
    // 0x130654c: LeaveFrame
    //     0x130654c: mov             SP, fp
    //     0x1306550: ldp             fp, lr, [SP], #0x10
    // 0x1306554: ret
    //     0x1306554: ret             
    // 0x1306558: r4 = LoadClassIdInstr(r3)
    //     0x1306558: ldur            x4, [x3, #-1]
    //     0x130655c: ubfx            x4, x4, #0xc, #0x14
    // 0x1306560: lsl             x4, x4, #1
    // 0x1306564: CheckStackOverflow
    //     0x1306564: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1306568: cmp             SP, x16
    //     0x130656c: b.ls            #0x13066bc
    // 0x1306570: mov             x0, x5
    // 0x1306574: mov             x1, x2
    // 0x1306578: cmp             x1, x0
    // 0x130657c: b.hs            #0x13066c4
    // 0x1306580: cmp             w4, #0xbc
    // 0x1306584: b.ne            #0x1306594
    // 0x1306588: ArrayLoad: r6 = r3[r2]  ; TypedUnsigned_1
    //     0x1306588: add             x16, x3, x2
    //     0x130658c: ldrb            w6, [x16, #0xf]
    // 0x1306590: b               #0x130659c
    // 0x1306594: add             x16, x3, x2, lsl #1
    // 0x1306598: ldurh           w6, [x16, #0xf]
    // 0x130659c: cmp             x6, #0xd
    // 0x13065a0: b.gt            #0x13065c4
    // 0x13065a4: cmp             x6, #0xb
    // 0x13065a8: b.gt            #0x1306600
    // 0x13065ac: cmp             x6, #0xa
    // 0x13065b0: b.gt            #0x1306600
    // 0x13065b4: lsl             x7, x6, #1
    // 0x13065b8: cmp             w7, #0x14
    // 0x13065bc: b.ne            #0x1306694
    // 0x13065c0: b               #0x1306600
    // 0x13065c4: cmp             x6, #0x85
    // 0x13065c8: b.lt            #0x1306694
    // 0x13065cc: r17 = 8232
    //     0x13065cc: mov             x17, #0x2028
    // 0x13065d0: cmp             x6, x17
    // 0x13065d4: b.gt            #0x13065f0
    // 0x13065d8: cmp             x6, #0x85
    // 0x13065dc: b.le            #0x1306600
    // 0x13065e0: r17 = 8232
    //     0x13065e0: mov             x17, #0x2028
    // 0x13065e4: cmp             x6, x17
    // 0x13065e8: b.lt            #0x1306694
    // 0x13065ec: b               #0x1306600
    // 0x13065f0: lsl             x7, x6, #1
    // 0x13065f4: r17 = 16466
    //     0x13065f4: mov             x17, #0x4052
    // 0x13065f8: cmp             w7, w17
    // 0x13065fc: b.ne            #0x1306694
    // 0x1306600: sub             x6, x5, #1
    // 0x1306604: cmp             x2, x6
    // 0x1306608: b.ge            #0x1306680
    // 0x130660c: cmp             w4, #0xbc
    // 0x1306610: b.ne            #0x1306628
    // 0x1306614: ArrayLoad: r6 = r3[r2]  ; TypedUnsigned_1
    //     0x1306614: add             x16, x3, x2
    //     0x1306618: ldrb            w6, [x16, #0xf]
    // 0x130661c: cmp             x6, #0xd
    // 0x1306620: b.ne            #0x1306680
    // 0x1306624: b               #0x1306638
    // 0x1306628: add             x16, x3, x2, lsl #1
    // 0x130662c: ldurh           w6, [x16, #0xf]
    // 0x1306630: cmp             x6, #0xd
    // 0x1306634: b.ne            #0x1306680
    // 0x1306638: add             x6, x2, #1
    // 0x130663c: mov             x0, x5
    // 0x1306640: mov             x1, x6
    // 0x1306644: cmp             x1, x0
    // 0x1306648: b.hs            #0x13066c8
    // 0x130664c: cmp             w4, #0xbc
    // 0x1306650: b.ne            #0x1306668
    // 0x1306654: ArrayLoad: r1 = r3[r6]  ; TypedUnsigned_1
    //     0x1306654: add             x16, x3, x6
    //     0x1306658: ldrb            w1, [x16, #0xf]
    // 0x130665c: cmp             x1, #0xa
    // 0x1306660: b.ne            #0x1306680
    // 0x1306664: b               #0x1306678
    // 0x1306668: add             x16, x3, x6, lsl #1
    // 0x130666c: ldurh           w1, [x16, #0xf]
    // 0x1306670: cmp             x1, #0xa
    // 0x1306674: b.ne            #0x1306680
    // 0x1306678: add             x1, x2, #2
    // 0x130667c: b               #0x1306684
    // 0x1306680: add             x1, x2, #1
    // 0x1306684: lsl             x0, x1, #1
    // 0x1306688: LeaveFrame
    //     0x1306688: mov             SP, fp
    //     0x130668c: ldp             fp, lr, [SP], #0x10
    // 0x1306690: ret
    //     0x1306690: ret             
    // 0x1306694: add             x0, x2, #1
    // 0x1306698: cmp             x0, x5
    // 0x130669c: b.eq            #0x13066a8
    // 0x13066a0: mov             x2, x0
    // 0x13066a4: b               #0x1306564
    // 0x13066a8: lsl             x1, x0, #1
    // 0x13066ac: mov             x0, x1
    // 0x13066b0: LeaveFrame
    //     0x13066b0: mov             SP, fp
    //     0x13066b4: ldp             fp, lr, [SP], #0x10
    // 0x13066b8: ret
    //     0x13066b8: ret             
    // 0x13066bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13066bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13066c0: b               #0x1306570
    // 0x13066c4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x13066c4: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x13066c8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x13066c8: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ getLeadingTextBoundaryAt(/* No info */) {
    // ** addr: 0x1306a5c, size: 0x2ac
    // 0x1306a5c: EnterFrame
    //     0x1306a5c: stp             fp, lr, [SP, #-0x10]!
    //     0x1306a60: mov             fp, SP
    // 0x1306a64: tbnz            x2, #0x3f, #0x1306a78
    // 0x1306a68: LoadField: r3 = r1->field_7
    //     0x1306a68: ldur            w3, [x1, #7]
    // 0x1306a6c: DecompressPointer r3
    //     0x1306a6c: add             x3, x3, HEAP, lsl #32
    // 0x1306a70: LoadField: r0 = r3->field_7
    //     0x1306a70: ldur            w0, [x3, #7]
    // 0x1306a74: cbnz            w0, #0x1306a88
    // 0x1306a78: r0 = Null
    //     0x1306a78: mov             x0, NULL
    // 0x1306a7c: LeaveFrame
    //     0x1306a7c: mov             SP, fp
    //     0x1306a80: ldp             fp, lr, [SP], #0x10
    // 0x1306a84: ret
    //     0x1306a84: ret             
    // 0x1306a88: r4 = LoadInt32Instr(r0)
    //     0x1306a88: sbfx            x4, x0, #1, #0x1f
    // 0x1306a8c: cmp             x2, x4
    // 0x1306a90: b.lt            #0x1306aa0
    // 0x1306a94: LeaveFrame
    //     0x1306a94: mov             SP, fp
    //     0x1306a98: ldp             fp, lr, [SP], #0x10
    // 0x1306a9c: ret
    //     0x1306a9c: ret             
    // 0x1306aa0: cbnz            x2, #0x1306ab4
    // 0x1306aa4: r0 = 0
    //     0x1306aa4: mov             x0, #0
    // 0x1306aa8: LeaveFrame
    //     0x1306aa8: mov             SP, fp
    //     0x1306aac: ldp             fp, lr, [SP], #0x10
    // 0x1306ab0: ret
    //     0x1306ab0: ret             
    // 0x1306ab4: cmp             x2, #1
    // 0x1306ab8: b.le            #0x1306b50
    // 0x1306abc: mov             x0, x4
    // 0x1306ac0: mov             x1, x2
    // 0x1306ac4: cmp             x1, x0
    // 0x1306ac8: b.hs            #0x1306cf0
    // 0x1306acc: r5 = LoadClassIdInstr(r3)
    //     0x1306acc: ldur            x5, [x3, #-1]
    //     0x1306ad0: ubfx            x5, x5, #0xc, #0x14
    // 0x1306ad4: lsl             x5, x5, #1
    // 0x1306ad8: cmp             w5, #0xbc
    // 0x1306adc: b.ne            #0x1306af4
    // 0x1306ae0: ArrayLoad: r6 = r3[r2]  ; TypedUnsigned_1
    //     0x1306ae0: add             x16, x3, x2
    //     0x1306ae4: ldrb            w6, [x16, #0xf]
    // 0x1306ae8: cmp             x6, #0xa
    // 0x1306aec: b.ne            #0x1306b50
    // 0x1306af0: b               #0x1306b04
    // 0x1306af4: add             x16, x3, x2, lsl #1
    // 0x1306af8: ldurh           w6, [x16, #0xf]
    // 0x1306afc: cmp             x6, #0xa
    // 0x1306b00: b.ne            #0x1306b50
    // 0x1306b04: sub             x6, x2, #1
    // 0x1306b08: mov             x0, x4
    // 0x1306b0c: mov             x1, x6
    // 0x1306b10: cmp             x1, x0
    // 0x1306b14: b.hs            #0x1306cf4
    // 0x1306b18: cmp             w5, #0xbc
    // 0x1306b1c: b.ne            #0x1306b34
    // 0x1306b20: ArrayLoad: r5 = r3[r6]  ; TypedUnsigned_1
    //     0x1306b20: add             x16, x3, x6
    //     0x1306b24: ldrb            w5, [x16, #0xf]
    // 0x1306b28: cmp             x5, #0xd
    // 0x1306b2c: b.ne            #0x1306b50
    // 0x1306b30: b               #0x1306b44
    // 0x1306b34: add             x16, x3, x6, lsl #1
    // 0x1306b38: ldurh           w5, [x16, #0xf]
    // 0x1306b3c: cmp             x5, #0xd
    // 0x1306b40: b.ne            #0x1306b50
    // 0x1306b44: sub             x5, x2, #2
    // 0x1306b48: mov             x2, x5
    // 0x1306b4c: b               #0x1306bf4
    // 0x1306b50: mov             x0, x4
    // 0x1306b54: mov             x1, x2
    // 0x1306b58: cmp             x1, x0
    // 0x1306b5c: b.hs            #0x1306cf8
    // 0x1306b60: r5 = LoadClassIdInstr(r3)
    //     0x1306b60: ldur            x5, [x3, #-1]
    //     0x1306b64: ubfx            x5, x5, #0xc, #0x14
    // 0x1306b68: lsl             x5, x5, #1
    // 0x1306b6c: cmp             w5, #0xbc
    // 0x1306b70: b.ne            #0x1306b80
    // 0x1306b74: ArrayLoad: r5 = r3[r2]  ; TypedUnsigned_1
    //     0x1306b74: add             x16, x3, x2
    //     0x1306b78: ldrb            w5, [x16, #0xf]
    // 0x1306b7c: b               #0x1306b88
    // 0x1306b80: add             x16, x3, x2, lsl #1
    // 0x1306b84: ldurh           w5, [x16, #0xf]
    // 0x1306b88: cmp             x5, #0xd
    // 0x1306b8c: b.gt            #0x1306bb0
    // 0x1306b90: cmp             x5, #0xb
    // 0x1306b94: b.gt            #0x1306bec
    // 0x1306b98: cmp             x5, #0xa
    // 0x1306b9c: b.gt            #0x1306bec
    // 0x1306ba0: lsl             x6, x5, #1
    // 0x1306ba4: cmp             w6, #0x14
    // 0x1306ba8: b.ne            #0x1306bf4
    // 0x1306bac: b               #0x1306bec
    // 0x1306bb0: cmp             x5, #0x85
    // 0x1306bb4: b.lt            #0x1306bf4
    // 0x1306bb8: r17 = 8232
    //     0x1306bb8: mov             x17, #0x2028
    // 0x1306bbc: cmp             x5, x17
    // 0x1306bc0: b.gt            #0x1306bdc
    // 0x1306bc4: cmp             x5, #0x85
    // 0x1306bc8: b.le            #0x1306bec
    // 0x1306bcc: r17 = 8232
    //     0x1306bcc: mov             x17, #0x2028
    // 0x1306bd0: cmp             x5, x17
    // 0x1306bd4: b.lt            #0x1306bf4
    // 0x1306bd8: b               #0x1306bec
    // 0x1306bdc: lsl             x6, x5, #1
    // 0x1306be0: r17 = 16466
    //     0x1306be0: mov             x17, #0x4052
    // 0x1306be4: cmp             w6, w17
    // 0x1306be8: b.ne            #0x1306bf4
    // 0x1306bec: sub             x5, x2, #1
    // 0x1306bf0: mov             x2, x5
    // 0x1306bf4: r5 = LoadClassIdInstr(r3)
    //     0x1306bf4: ldur            x5, [x3, #-1]
    //     0x1306bf8: ubfx            x5, x5, #0xc, #0x14
    // 0x1306bfc: lsl             x5, x5, #1
    // 0x1306c00: CheckStackOverflow
    //     0x1306c00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1306c04: cmp             SP, x16
    //     0x1306c08: b.ls            #0x1306cfc
    // 0x1306c0c: cmp             x2, #0
    // 0x1306c10: b.le            #0x1306cc4
    // 0x1306c14: mov             x0, x4
    // 0x1306c18: mov             x1, x2
    // 0x1306c1c: cmp             x1, x0
    // 0x1306c20: b.hs            #0x1306d04
    // 0x1306c24: cmp             w5, #0xbc
    // 0x1306c28: b.ne            #0x1306c38
    // 0x1306c2c: ArrayLoad: r6 = r3[r2]  ; TypedUnsigned_1
    //     0x1306c2c: add             x16, x3, x2
    //     0x1306c30: ldrb            w6, [x16, #0xf]
    // 0x1306c34: b               #0x1306c40
    // 0x1306c38: add             x16, x3, x2, lsl #1
    // 0x1306c3c: ldurh           w6, [x16, #0xf]
    // 0x1306c40: cmp             x6, #0xd
    // 0x1306c44: b.gt            #0x1306c68
    // 0x1306c48: cmp             x6, #0xb
    // 0x1306c4c: b.gt            #0x1306ca4
    // 0x1306c50: cmp             x6, #0xa
    // 0x1306c54: b.gt            #0x1306ca4
    // 0x1306c58: lsl             x7, x6, #1
    // 0x1306c5c: cmp             w7, #0x14
    // 0x1306c60: b.ne            #0x1306cb8
    // 0x1306c64: b               #0x1306ca4
    // 0x1306c68: cmp             x6, #0x85
    // 0x1306c6c: b.lt            #0x1306cb8
    // 0x1306c70: r17 = 8232
    //     0x1306c70: mov             x17, #0x2028
    // 0x1306c74: cmp             x6, x17
    // 0x1306c78: b.gt            #0x1306c94
    // 0x1306c7c: cmp             x6, #0x85
    // 0x1306c80: b.le            #0x1306ca4
    // 0x1306c84: r17 = 8232
    //     0x1306c84: mov             x17, #0x2028
    // 0x1306c88: cmp             x6, x17
    // 0x1306c8c: b.lt            #0x1306cb8
    // 0x1306c90: b               #0x1306ca4
    // 0x1306c94: lsl             x7, x6, #1
    // 0x1306c98: r17 = 16466
    //     0x1306c98: mov             x17, #0x4052
    // 0x1306c9c: cmp             w7, w17
    // 0x1306ca0: b.ne            #0x1306cb8
    // 0x1306ca4: add             x6, x2, #1
    // 0x1306ca8: lsl             x0, x6, #1
    // 0x1306cac: LeaveFrame
    //     0x1306cac: mov             SP, fp
    //     0x1306cb0: ldp             fp, lr, [SP], #0x10
    // 0x1306cb4: ret
    //     0x1306cb4: ret             
    // 0x1306cb8: sub             x0, x2, #1
    // 0x1306cbc: mov             x2, x0
    // 0x1306cc0: b               #0x1306c00
    // 0x1306cc4: r3 = 0
    //     0x1306cc4: mov             x3, #0
    // 0x1306cc8: cmp             x2, x3
    // 0x1306ccc: csel            x4, x3, x2, lt
    // 0x1306cd0: r0 = BoxInt64Instr(r4)
    //     0x1306cd0: sbfiz           x0, x4, #1, #0x1f
    //     0x1306cd4: cmp             x4, x0, asr #1
    //     0x1306cd8: b.eq            #0x1306ce4
    //     0x1306cdc: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1306ce0: stur            x4, [x0, #7]
    // 0x1306ce4: LeaveFrame
    //     0x1306ce4: mov             SP, fp
    //     0x1306ce8: ldp             fp, lr, [SP], #0x10
    // 0x1306cec: ret
    //     0x1306cec: ret             
    // 0x1306cf0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x1306cf0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x1306cf4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x1306cf4: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x1306cf8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x1306cf8: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x1306cfc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1306cfc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1306d00: b               #0x1306c0c
    // 0x1306d04: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x1306d04: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
}

// class id: 2909, size: 0xc, field offset: 0x8
//   const constructor, 
class LineBoundary extends TextBoundary {

  _ getTextBoundaryAt(/* No info */) {
    // ** addr: 0x1306e90, size: 0x6c
    // 0x1306e90: EnterFrame
    //     0x1306e90: stp             fp, lr, [SP, #-0x10]!
    //     0x1306e94: mov             fp, SP
    // 0x1306e98: AllocStack(0x10)
    //     0x1306e98: sub             SP, SP, #0x10
    // 0x1306e9c: r0 = 0
    //     0x1306e9c: mov             x0, #0
    // 0x1306ea0: CheckStackOverflow
    //     0x1306ea0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1306ea4: cmp             SP, x16
    //     0x1306ea8: b.ls            #0x1306ef4
    // 0x1306eac: LoadField: r3 = r1->field_7
    //     0x1306eac: ldur            w3, [x1, #7]
    // 0x1306eb0: DecompressPointer r3
    //     0x1306eb0: add             x3, x3, HEAP, lsl #32
    // 0x1306eb4: stur            x3, [fp, #-0x10]
    // 0x1306eb8: cmp             x2, x0
    // 0x1306ebc: csel            x1, x0, x2, lt
    // 0x1306ec0: stur            x1, [fp, #-8]
    // 0x1306ec4: r0 = TextPosition()
    //     0x1306ec4: bl              #0x85ed74  ; AllocateTextPositionStub -> TextPosition (size=0x14)
    // 0x1306ec8: mov             x1, x0
    // 0x1306ecc: ldur            x0, [fp, #-8]
    // 0x1306ed0: StoreField: r1->field_7 = r0
    //     0x1306ed0: stur            x0, [x1, #7]
    // 0x1306ed4: r0 = Instance_TextAffinity
    //     0x1306ed4: ldr             x0, [PP, #0x4bb0]  ; [pp+0x4bb0] Obj!TextAffinity@12c7361
    // 0x1306ed8: StoreField: r1->field_f = r0
    //     0x1306ed8: stur            w0, [x1, #0xf]
    // 0x1306edc: mov             x2, x1
    // 0x1306ee0: ldur            x1, [fp, #-0x10]
    // 0x1306ee4: r0 = getLineAtOffset()
    //     0x1306ee4: bl              #0x870408  ; [package:flutter/src/rendering/editable.dart] RenderEditable::getLineAtOffset
    // 0x1306ee8: LeaveFrame
    //     0x1306ee8: mov             SP, fp
    //     0x1306eec: ldp             fp, lr, [SP], #0x10
    // 0x1306ef0: ret
    //     0x1306ef0: ret             
    // 0x1306ef4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1306ef4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1306ef8: b               #0x1306eac
  }
}

// class id: 2910, size: 0xc, field offset: 0x8
//   const constructor, 
class CharacterBoundary extends TextBoundary {

  _ getTrailingTextBoundaryAt(/* No info */) {
    // ** addr: 0x13063f8, size: 0xa8
    // 0x13063f8: EnterFrame
    //     0x13063f8: stp             fp, lr, [SP, #-0x10]!
    //     0x13063fc: mov             fp, SP
    // 0x1306400: AllocStack(0x8)
    //     0x1306400: sub             SP, SP, #8
    // 0x1306404: CheckStackOverflow
    //     0x1306404: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1306408: cmp             SP, x16
    //     0x130640c: b.ls            #0x1306498
    // 0x1306410: LoadField: r0 = r1->field_7
    //     0x1306410: ldur            w0, [x1, #7]
    // 0x1306414: DecompressPointer r0
    //     0x1306414: add             x0, x0, HEAP, lsl #32
    // 0x1306418: LoadField: r1 = r0->field_7
    //     0x1306418: ldur            w1, [x0, #7]
    // 0x130641c: r3 = LoadInt32Instr(r1)
    //     0x130641c: sbfx            x3, x1, #1, #0x1f
    // 0x1306420: cmp             x2, x3
    // 0x1306424: b.lt            #0x1306438
    // 0x1306428: r0 = Null
    //     0x1306428: mov             x0, NULL
    // 0x130642c: LeaveFrame
    //     0x130642c: mov             SP, fp
    //     0x1306430: ldp             fp, lr, [SP], #0x10
    // 0x1306434: ret
    //     0x1306434: ret             
    // 0x1306438: r1 = 0
    //     0x1306438: mov             x1, #0
    // 0x130643c: add             x3, x2, #1
    // 0x1306440: cmp             x1, x3
    // 0x1306444: csel            x2, x3, x1, lt
    // 0x1306448: mov             x3, x2
    // 0x130644c: mov             x2, x0
    // 0x1306450: r1 = Null
    //     0x1306450: mov             x1, NULL
    // 0x1306454: r0 = StringCharacterRange.at()
    //     0x1306454: bl              #0x129d030  ; [package:characters/src/characters_impl.dart] StringCharacterRange::StringCharacterRange.at
    // 0x1306458: LoadField: r2 = r0->field_b
    //     0x1306458: ldur            x2, [x0, #0xb]
    // 0x130645c: mov             x1, x0
    // 0x1306460: stur            x2, [fp, #-8]
    // 0x1306464: r0 = current()
    //     0x1306464: bl              #0x9fb4e0  ; [package:characters/src/characters_impl.dart] StringCharacterRange::current
    // 0x1306468: LoadField: r2 = r0->field_7
    //     0x1306468: ldur            w2, [x0, #7]
    // 0x130646c: r3 = LoadInt32Instr(r2)
    //     0x130646c: sbfx            x3, x2, #1, #0x1f
    // 0x1306470: ldur            x2, [fp, #-8]
    // 0x1306474: add             x4, x2, x3
    // 0x1306478: r0 = BoxInt64Instr(r4)
    //     0x1306478: sbfiz           x0, x4, #1, #0x1f
    //     0x130647c: cmp             x4, x0, asr #1
    //     0x1306480: b.eq            #0x130648c
    //     0x1306484: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1306488: stur            x4, [x0, #7]
    // 0x130648c: LeaveFrame
    //     0x130648c: mov             SP, fp
    //     0x1306490: ldp             fp, lr, [SP], #0x10
    // 0x1306494: ret
    //     0x1306494: ret             
    // 0x1306498: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1306498: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x130649c: b               #0x1306410
  }
  _ getLeadingTextBoundaryAt(/* No info */) {
    // ** addr: 0x130696c, size: 0x7c
    // 0x130696c: EnterFrame
    //     0x130696c: stp             fp, lr, [SP, #-0x10]!
    //     0x1306970: mov             fp, SP
    // 0x1306974: CheckStackOverflow
    //     0x1306974: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1306978: cmp             SP, x16
    //     0x130697c: b.ls            #0x13069e0
    // 0x1306980: tbz             x2, #0x3f, #0x1306994
    // 0x1306984: r0 = Null
    //     0x1306984: mov             x0, NULL
    // 0x1306988: LeaveFrame
    //     0x1306988: mov             SP, fp
    //     0x130698c: ldp             fp, lr, [SP], #0x10
    // 0x1306990: ret
    //     0x1306990: ret             
    // 0x1306994: LoadField: r0 = r1->field_7
    //     0x1306994: ldur            w0, [x1, #7]
    // 0x1306998: DecompressPointer r0
    //     0x1306998: add             x0, x0, HEAP, lsl #32
    // 0x130699c: LoadField: r1 = r0->field_7
    //     0x130699c: ldur            w1, [x0, #7]
    // 0x13069a0: r3 = LoadInt32Instr(r1)
    //     0x13069a0: sbfx            x3, x1, #1, #0x1f
    // 0x13069a4: cmp             x2, x3
    // 0x13069a8: csel            x1, x3, x2, gt
    // 0x13069ac: mov             x2, x0
    // 0x13069b0: mov             x3, x1
    // 0x13069b4: r1 = Null
    //     0x13069b4: mov             x1, NULL
    // 0x13069b8: r0 = StringCharacterRange.at()
    //     0x13069b8: bl              #0x129d030  ; [package:characters/src/characters_impl.dart] StringCharacterRange::StringCharacterRange.at
    // 0x13069bc: LoadField: r2 = r0->field_b
    //     0x13069bc: ldur            x2, [x0, #0xb]
    // 0x13069c0: r0 = BoxInt64Instr(r2)
    //     0x13069c0: sbfiz           x0, x2, #1, #0x1f
    //     0x13069c4: cmp             x2, x0, asr #1
    //     0x13069c8: b.eq            #0x13069d4
    //     0x13069cc: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x13069d0: stur            x2, [x0, #7]
    // 0x13069d4: LeaveFrame
    //     0x13069d4: mov             SP, fp
    //     0x13069d8: ldp             fp, lr, [SP], #0x10
    // 0x13069dc: ret
    //     0x13069dc: ret             
    // 0x13069e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13069e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13069e4: b               #0x1306980
  }
}
