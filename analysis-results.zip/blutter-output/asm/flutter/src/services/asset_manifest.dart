// lib: , url: package:flutter/src/services/asset_manifest.dart

// class id: 1049067, size: 0x8
class :: {
}

// class id: 2805, size: 0x10, field offset: 0x8
//   const constructor, 
class AssetMetadata extends Object {
}

// class id: 2806, size: 0x10, field offset: 0x8
class _AssetManifestBin extends Object
    implements AssetManifest {

  _ listAssets(/* No info */) {
    // ** addr: 0xeb38a4, size: 0x1e0
    // 0xeb38a4: EnterFrame
    //     0xeb38a4: stp             fp, lr, [SP, #-0x10]!
    //     0xeb38a8: mov             fp, SP
    // 0xeb38ac: AllocStack(0x28)
    //     0xeb38ac: sub             SP, SP, #0x28
    // 0xeb38b0: SetupParameters(_AssetManifestBin this /* r1 => r2, fp-0x8 */)
    //     0xeb38b0: mov             x2, x1
    //     0xeb38b4: stur            x1, [fp, #-8]
    // 0xeb38b8: CheckStackOverflow
    //     0xeb38b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeb38bc: cmp             SP, x16
    //     0xeb38c0: b.ls            #0xeb3a7c
    // 0xeb38c4: LoadField: r1 = r2->field_7
    //     0xeb38c4: ldur            w1, [x2, #7]
    // 0xeb38c8: DecompressPointer r1
    //     0xeb38c8: add             x1, x1, HEAP, lsl #32
    // 0xeb38cc: r0 = LoadClassIdInstr(r1)
    //     0xeb38cc: ldur            x0, [x1, #-1]
    //     0xeb38d0: ubfx            x0, x0, #0xc, #0x14
    // 0xeb38d4: r0 = GDT[cid_x0 + 0x44d]()
    //     0xeb38d4: add             lr, x0, #0x44d
    //     0xeb38d8: ldr             lr, [x21, lr, lsl #3]
    //     0xeb38dc: blr             lr
    // 0xeb38e0: r1 = LoadClassIdInstr(r0)
    //     0xeb38e0: ldur            x1, [x0, #-1]
    //     0xeb38e4: ubfx            x1, x1, #0xc, #0x14
    // 0xeb38e8: r16 = <String>
    //     0xeb38e8: ldr             x16, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    // 0xeb38ec: stp             x0, x16, [SP]
    // 0xeb38f0: mov             x0, x1
    // 0xeb38f4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xeb38f4: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xeb38f8: r0 = GDT[cid_x0 + 0x13106]()
    //     0xeb38f8: mov             x17, #0x3106
    //     0xeb38fc: movk            x17, #1, lsl #16
    //     0xeb3900: add             lr, x0, x17
    //     0xeb3904: ldr             lr, [x21, lr, lsl #3]
    //     0xeb3908: blr             lr
    // 0xeb390c: mov             x3, x0
    // 0xeb3910: stur            x3, [fp, #-0x10]
    // 0xeb3914: r0 = LoadClassIdInstr(r3)
    //     0xeb3914: ldur            x0, [x3, #-1]
    //     0xeb3918: ubfx            x0, x0, #0xc, #0x14
    // 0xeb391c: cmp             x0, #0x5c
    // 0xeb3920: b.ne            #0xeb3938
    // 0xeb3924: mov             x2, x3
    // 0xeb3928: r1 = <String>
    //     0xeb3928: ldr             x1, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    // 0xeb392c: r0 = _GrowableList._ofGrowableList()
    //     0xeb392c: bl              #0x7d7558  ; [dart:core] _GrowableList::_GrowableList._ofGrowableList
    // 0xeb3930: mov             x2, x0
    // 0xeb3934: b               #0xeb3a34
    // 0xeb3938: sub             x16, x0, #0x5a
    // 0xeb393c: cmp             x16, #1
    // 0xeb3940: b.hi            #0xeb3958
    // 0xeb3944: mov             x2, x3
    // 0xeb3948: r1 = <String>
    //     0xeb3948: ldr             x1, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    // 0xeb394c: r0 = _GrowableList._ofArray()
    //     0xeb394c: bl              #0x7d7adc  ; [dart:core] _GrowableList::_GrowableList._ofArray
    // 0xeb3950: mov             x2, x0
    // 0xeb3954: b               #0xeb3a34
    // 0xeb3958: mov             x0, x3
    // 0xeb395c: r2 = Null
    //     0xeb395c: mov             x2, NULL
    // 0xeb3960: r1 = Null
    //     0xeb3960: mov             x1, NULL
    // 0xeb3964: cmp             w0, NULL
    // 0xeb3968: b.eq            #0xeb3a00
    // 0xeb396c: branchIfSmi(r0, 0xeb3a00)
    //     0xeb396c: tbz             w0, #0, #0xeb3a00
    // 0xeb3970: r3 = LoadClassIdInstr(r0)
    //     0xeb3970: ldur            x3, [x0, #-1]
    //     0xeb3974: ubfx            x3, x3, #0xc, #0x14
    // 0xeb3978: r17 = 7724
    //     0xeb3978: mov             x17, #0x1e2c
    // 0xeb397c: cmp             x3, x17
    // 0xeb3980: b.eq            #0xeb3a08
    // 0xeb3984: r4 = LoadClassIdInstr(r0)
    //     0xeb3984: ldur            x4, [x0, #-1]
    //     0xeb3988: ubfx            x4, x4, #0xc, #0x14
    // 0xeb398c: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0xeb3990: ldr             x3, [x3, #0x18]
    // 0xeb3994: ldr             x3, [x3, x4, lsl #3]
    // 0xeb3998: LoadField: r3 = r3->field_2b
    //     0xeb3998: ldur            w3, [x3, #0x2b]
    // 0xeb399c: DecompressPointer r3
    //     0xeb399c: add             x3, x3, HEAP, lsl #32
    // 0xeb39a0: cmp             w3, NULL
    // 0xeb39a4: b.eq            #0xeb3a00
    // 0xeb39a8: LoadField: r3 = r3->field_f
    //     0xeb39a8: ldur            w3, [x3, #0xf]
    // 0xeb39ac: lsr             x3, x3, #3
    // 0xeb39b0: r17 = 7724
    //     0xeb39b0: mov             x17, #0x1e2c
    // 0xeb39b4: cmp             x3, x17
    // 0xeb39b8: b.eq            #0xeb3a08
    // 0xeb39bc: r3 = SubtypeTestCache
    //     0xeb39bc: add             x3, PP, #0x14, lsl #12  ; [pp+0x140c0] SubtypeTestCache
    //     0xeb39c0: ldr             x3, [x3, #0xc0]
    // 0xeb39c4: r30 = Subtype1TestCacheStub
    //     0xeb39c4: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0xeb39c8: LoadField: r30 = r30->field_7
    //     0xeb39c8: ldur            lr, [lr, #7]
    // 0xeb39cc: blr             lr
    // 0xeb39d0: cmp             w7, NULL
    // 0xeb39d4: b.eq            #0xeb39e0
    // 0xeb39d8: tbnz            w7, #4, #0xeb3a00
    // 0xeb39dc: b               #0xeb3a08
    // 0xeb39e0: r8 = EfficientLengthIterable
    //     0xeb39e0: add             x8, PP, #0x14, lsl #12  ; [pp+0x140c8] Type: EfficientLengthIterable
    //     0xeb39e4: ldr             x8, [x8, #0xc8]
    // 0xeb39e8: r3 = SubtypeTestCache
    //     0xeb39e8: add             x3, PP, #0x14, lsl #12  ; [pp+0x140d0] SubtypeTestCache
    //     0xeb39ec: ldr             x3, [x3, #0xd0]
    // 0xeb39f0: r30 = InstanceOfStub
    //     0xeb39f0: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0xeb39f4: LoadField: r30 = r30->field_7
    //     0xeb39f4: ldur            lr, [lr, #7]
    // 0xeb39f8: blr             lr
    // 0xeb39fc: b               #0xeb3a0c
    // 0xeb3a00: r0 = false
    //     0xeb3a00: add             x0, NULL, #0x30  ; false
    // 0xeb3a04: b               #0xeb3a0c
    // 0xeb3a08: r0 = true
    //     0xeb3a08: add             x0, NULL, #0x20  ; true
    // 0xeb3a0c: tbnz            w0, #4, #0xeb3a24
    // 0xeb3a10: ldur            x2, [fp, #-0x10]
    // 0xeb3a14: r1 = <String>
    //     0xeb3a14: ldr             x1, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    // 0xeb3a18: r0 = _GrowableList._ofEfficientLengthIterable()
    //     0xeb3a18: bl              #0x7d732c  ; [dart:core] _GrowableList::_GrowableList._ofEfficientLengthIterable
    // 0xeb3a1c: mov             x2, x0
    // 0xeb3a20: b               #0xeb3a34
    // 0xeb3a24: ldur            x2, [fp, #-0x10]
    // 0xeb3a28: r1 = <String>
    //     0xeb3a28: ldr             x1, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    // 0xeb3a2c: r0 = _GrowableList._ofOther()
    //     0xeb3a2c: bl              #0x7d94b4  ; [dart:core] _GrowableList::_GrowableList._ofOther
    // 0xeb3a30: mov             x2, x0
    // 0xeb3a34: ldur            x0, [fp, #-8]
    // 0xeb3a38: stur            x2, [fp, #-0x18]
    // 0xeb3a3c: LoadField: r3 = r0->field_b
    //     0xeb3a3c: ldur            w3, [x0, #0xb]
    // 0xeb3a40: DecompressPointer r3
    //     0xeb3a40: add             x3, x3, HEAP, lsl #32
    // 0xeb3a44: stur            x3, [fp, #-0x10]
    // 0xeb3a48: r1 = <String, List<AssetMetadata>>
    //     0xeb3a48: add             x1, PP, #0x14, lsl #12  ; [pp+0x140d8] TypeArguments: <String, List<AssetMetadata>>
    //     0xeb3a4c: ldr             x1, [x1, #0xd8]
    // 0xeb3a50: r0 = _CompactKeysIterable()
    //     0xeb3a50: bl              #0x8353d0  ; Allocate_CompactKeysIterableStub -> _CompactKeysIterable<X0> (size=0x10)
    // 0xeb3a54: mov             x1, x0
    // 0xeb3a58: ldur            x0, [fp, #-0x10]
    // 0xeb3a5c: StoreField: r1->field_b = r0
    //     0xeb3a5c: stur            w0, [x1, #0xb]
    // 0xeb3a60: mov             x2, x1
    // 0xeb3a64: ldur            x1, [fp, #-0x18]
    // 0xeb3a68: r0 = addAll()
    //     0xeb3a68: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0xeb3a6c: ldur            x0, [fp, #-0x18]
    // 0xeb3a70: LeaveFrame
    //     0xeb3a70: mov             SP, fp
    //     0xeb3a74: ldp             fp, lr, [SP], #0x10
    // 0xeb3a78: ret
    //     0xeb3a78: ret             
    // 0xeb3a7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeb3a7c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeb3a80: b               #0xeb38c4
  }
  [closure] static _AssetManifestBin _AssetManifestBin.fromStandardMessageCodecMessage(dynamic, ByteData) {
    // ** addr: 0xeb4010, size: 0x34
    // 0xeb4010: EnterFrame
    //     0xeb4010: stp             fp, lr, [SP, #-0x10]!
    //     0xeb4014: mov             fp, SP
    // 0xeb4018: CheckStackOverflow
    //     0xeb4018: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeb401c: cmp             SP, x16
    //     0xeb4020: b.ls            #0xeb403c
    // 0xeb4024: ldr             x2, [fp, #0x10]
    // 0xeb4028: r1 = Null
    //     0xeb4028: mov             x1, NULL
    // 0xeb402c: r0 = _AssetManifestBin.fromStandardMessageCodecMessage()
    //     0xeb402c: bl              #0xeb4044  ; [package:flutter/src/services/asset_manifest.dart] _AssetManifestBin::_AssetManifestBin.fromStandardMessageCodecMessage
    // 0xeb4030: LeaveFrame
    //     0xeb4030: mov             SP, fp
    //     0xeb4034: ldp             fp, lr, [SP], #0x10
    // 0xeb4038: ret
    //     0xeb4038: ret             
    // 0xeb403c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeb403c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeb4040: b               #0xeb4024
  }
  factory _AssetManifestBin _AssetManifestBin.fromStandardMessageCodecMessage(dynamic, ByteData) {
    // ** addr: 0xeb4044, size: 0x80
    // 0xeb4044: EnterFrame
    //     0xeb4044: stp             fp, lr, [SP, #-0x10]!
    //     0xeb4048: mov             fp, SP
    // 0xeb404c: AllocStack(0x20)
    //     0xeb404c: sub             SP, SP, #0x20
    // 0xeb4050: CheckStackOverflow
    //     0xeb4050: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeb4054: cmp             SP, x16
    //     0xeb4058: b.ls            #0xeb40bc
    // 0xeb405c: r1 = Instance_StandardMessageCodec
    //     0xeb405c: ldr             x1, [PP, #0x2f90]  ; [pp+0x2f90] Obj!StandardMessageCodec@129ff01
    // 0xeb4060: r0 = decodeMessage()
    //     0xeb4060: bl              #0xccec6c  ; [package:flutter/src/services/message_codecs.dart] StandardMessageCodec::decodeMessage
    // 0xeb4064: mov             x3, x0
    // 0xeb4068: r2 = Null
    //     0xeb4068: mov             x2, NULL
    // 0xeb406c: r1 = Null
    //     0xeb406c: mov             x1, NULL
    // 0xeb4070: stur            x3, [fp, #-8]
    // 0xeb4074: r8 = Map<Object?, Object?>
    //     0xeb4074: ldr             x8, [PP, #0x3238]  ; [pp+0x3238] Type: Map<Object?, Object?>
    // 0xeb4078: r3 = Null
    //     0xeb4078: add             x3, PP, #0x14, lsl #12  ; [pp+0x140f8] Null
    //     0xeb407c: ldr             x3, [x3, #0xf8]
    // 0xeb4080: r0 = Map<Object?, Object?>()
    //     0xeb4080: bl              #0x851560  ; IsType_Map<Object?, Object?>_Stub
    // 0xeb4084: r16 = <String, List<AssetMetadata>>
    //     0xeb4084: add             x16, PP, #0x14, lsl #12  ; [pp+0x140d8] TypeArguments: <String, List<AssetMetadata>>
    //     0xeb4088: ldr             x16, [x16, #0xd8]
    // 0xeb408c: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0xeb4090: stp             lr, x16, [SP]
    // 0xeb4094: r0 = Map._fromLiteral()
    //     0xeb4094: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xeb4098: stur            x0, [fp, #-0x10]
    // 0xeb409c: r0 = _AssetManifestBin()
    //     0xeb409c: bl              #0xeb40c4  ; Allocate_AssetManifestBinStub -> _AssetManifestBin (size=0x10)
    // 0xeb40a0: ldur            x1, [fp, #-0x10]
    // 0xeb40a4: StoreField: r0->field_b = r1
    //     0xeb40a4: stur            w1, [x0, #0xb]
    // 0xeb40a8: ldur            x1, [fp, #-8]
    // 0xeb40ac: StoreField: r0->field_7 = r1
    //     0xeb40ac: stur            w1, [x0, #7]
    // 0xeb40b0: LeaveFrame
    //     0xeb40b0: mov             SP, fp
    //     0xeb40b4: ldp             fp, lr, [SP], #0x10
    // 0xeb40b8: ret
    //     0xeb40b8: ret             
    // 0xeb40bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeb40bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeb40c0: b               #0xeb405c
  }
  _ getAssetVariants(/* No info */) {
    // ** addr: 0x115bac0, size: 0x254
    // 0x115bac0: EnterFrame
    //     0x115bac0: stp             fp, lr, [SP, #-0x10]!
    //     0x115bac4: mov             fp, SP
    // 0x115bac8: AllocStack(0x40)
    //     0x115bac8: sub             SP, SP, #0x40
    // 0x115bacc: SetupParameters(_AssetManifestBin this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x115bacc: stur            x1, [fp, #-8]
    //     0x115bad0: stur            x2, [fp, #-0x10]
    // 0x115bad4: CheckStackOverflow
    //     0x115bad4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x115bad8: cmp             SP, x16
    //     0x115badc: b.ls            #0x115bd08
    // 0x115bae0: r1 = 1
    //     0x115bae0: mov             x1, #1
    // 0x115bae4: r0 = AllocateContext()
    //     0x115bae4: bl              #0x13de838  ; AllocateContextStub
    // 0x115bae8: ldur            x2, [fp, #-0x10]
    // 0x115baec: stur            x0, [fp, #-0x20]
    // 0x115baf0: StoreField: r0->field_f = r2
    //     0x115baf0: stur            w2, [x0, #0xf]
    // 0x115baf4: ldur            x3, [fp, #-8]
    // 0x115baf8: LoadField: r4 = r3->field_b
    //     0x115baf8: ldur            w4, [x3, #0xb]
    // 0x115bafc: DecompressPointer r4
    //     0x115bafc: add             x4, x4, HEAP, lsl #32
    // 0x115bb00: mov             x1, x4
    // 0x115bb04: stur            x4, [fp, #-0x18]
    // 0x115bb08: r0 = containsKey()
    //     0x115bb08: bl              #0x12d5a5c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x115bb0c: tbz             w0, #4, #0x115bcc4
    // 0x115bb10: ldur            x0, [fp, #-8]
    // 0x115bb14: ldur            x3, [fp, #-0x20]
    // 0x115bb18: LoadField: r4 = r0->field_7
    //     0x115bb18: ldur            w4, [x0, #7]
    // 0x115bb1c: DecompressPointer r4
    //     0x115bb1c: add             x4, x4, HEAP, lsl #32
    // 0x115bb20: stur            x4, [fp, #-0x10]
    // 0x115bb24: LoadField: r2 = r3->field_f
    //     0x115bb24: ldur            w2, [x3, #0xf]
    // 0x115bb28: DecompressPointer r2
    //     0x115bb28: add             x2, x2, HEAP, lsl #32
    // 0x115bb2c: r0 = LoadClassIdInstr(r4)
    //     0x115bb2c: ldur            x0, [x4, #-1]
    //     0x115bb30: ubfx            x0, x0, #0xc, #0x14
    // 0x115bb34: mov             x1, x4
    // 0x115bb38: r0 = GDT[cid_x0 + -0xd48]()
    //     0x115bb38: sub             lr, x0, #0xd48
    //     0x115bb3c: ldr             lr, [x21, lr, lsl #3]
    //     0x115bb40: blr             lr
    // 0x115bb44: cmp             w0, NULL
    // 0x115bb48: b.ne            #0x115bb5c
    // 0x115bb4c: r0 = Null
    //     0x115bb4c: mov             x0, NULL
    // 0x115bb50: LeaveFrame
    //     0x115bb50: mov             SP, fp
    //     0x115bb54: ldp             fp, lr, [SP], #0x10
    // 0x115bb58: ret
    //     0x115bb58: ret             
    // 0x115bb5c: ldur            x3, [fp, #-0x20]
    // 0x115bb60: ldur            x4, [fp, #-0x10]
    // 0x115bb64: LoadField: r5 = r3->field_f
    //     0x115bb64: ldur            w5, [x3, #0xf]
    // 0x115bb68: DecompressPointer r5
    //     0x115bb68: add             x5, x5, HEAP, lsl #32
    // 0x115bb6c: stur            x5, [fp, #-8]
    // 0x115bb70: r0 = LoadClassIdInstr(r4)
    //     0x115bb70: ldur            x0, [x4, #-1]
    //     0x115bb74: ubfx            x0, x0, #0xc, #0x14
    // 0x115bb78: mov             x1, x4
    // 0x115bb7c: mov             x2, x5
    // 0x115bb80: r0 = GDT[cid_x0 + -0xd48]()
    //     0x115bb80: sub             lr, x0, #0xd48
    //     0x115bb84: ldr             lr, [x21, lr, lsl #3]
    //     0x115bb88: blr             lr
    // 0x115bb8c: cmp             w0, NULL
    // 0x115bb90: b.ne            #0x115bba8
    // 0x115bb94: r1 = <Object?>
    //     0x115bb94: ldr             x1, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0x115bb98: r2 = 0
    //     0x115bb98: mov             x2, #0
    // 0x115bb9c: r0 = _GrowableList()
    //     0x115bb9c: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x115bba0: mov             x5, x0
    // 0x115bba4: b               #0x115bbac
    // 0x115bba8: mov             x5, x0
    // 0x115bbac: ldur            x3, [fp, #-0x20]
    // 0x115bbb0: ldur            x4, [fp, #-0x10]
    // 0x115bbb4: mov             x0, x5
    // 0x115bbb8: stur            x5, [fp, #-0x28]
    // 0x115bbbc: r2 = Null
    //     0x115bbbc: mov             x2, NULL
    // 0x115bbc0: r1 = Null
    //     0x115bbc0: mov             x1, NULL
    // 0x115bbc4: r8 = Iterable<Object?>
    //     0x115bbc4: add             x8, PP, #0x8c, lsl #12  ; [pp+0x8c4e8] Type: Iterable<Object?>
    //     0x115bbc8: ldr             x8, [x8, #0x4e8]
    // 0x115bbcc: r3 = Null
    //     0x115bbcc: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8c4f0] Null
    //     0x115bbd0: ldr             x3, [x3, #0x4f0]
    // 0x115bbd4: r0 = Iterable<Object?>()
    //     0x115bbd4: bl              #0x90bc04  ; IsType_Iterable<Object?>_Stub
    // 0x115bbd8: ldur            x0, [fp, #-0x28]
    // 0x115bbdc: r1 = LoadClassIdInstr(r0)
    //     0x115bbdc: ldur            x1, [x0, #-1]
    //     0x115bbe0: ubfx            x1, x1, #0xc, #0x14
    // 0x115bbe4: r16 = <Map<Object?, Object?>>
    //     0x115bbe4: add             x16, PP, #0x84, lsl #12  ; [pp+0x84100] TypeArguments: <Map<Object?, Object?>>
    //     0x115bbe8: ldr             x16, [x16, #0x100]
    // 0x115bbec: stp             x0, x16, [SP]
    // 0x115bbf0: mov             x0, x1
    // 0x115bbf4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x115bbf4: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x115bbf8: r0 = GDT[cid_x0 + 0x13106]()
    //     0x115bbf8: mov             x17, #0x3106
    //     0x115bbfc: movk            x17, #1, lsl #16
    //     0x115bc00: add             lr, x0, x17
    //     0x115bc04: ldr             lr, [x21, lr, lsl #3]
    //     0x115bc08: blr             lr
    // 0x115bc0c: ldur            x2, [fp, #-0x20]
    // 0x115bc10: r1 = Function '<anonymous closure>':.
    //     0x115bc10: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c500] AnonymousClosure: (0x115bd14), in [package:flutter/src/services/asset_manifest.dart] _AssetManifestBin::getAssetVariants (0x115bac0)
    //     0x115bc14: ldr             x1, [x1, #0x500]
    // 0x115bc18: stur            x0, [fp, #-0x28]
    // 0x115bc1c: r0 = AllocateClosure()
    //     0x115bc1c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x115bc20: mov             x1, x0
    // 0x115bc24: ldur            x0, [fp, #-0x28]
    // 0x115bc28: r2 = LoadClassIdInstr(r0)
    //     0x115bc28: ldur            x2, [x0, #-1]
    //     0x115bc2c: ubfx            x2, x2, #0xc, #0x14
    // 0x115bc30: r16 = <AssetMetadata>
    //     0x115bc30: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8c508] TypeArguments: <AssetMetadata>
    //     0x115bc34: ldr             x16, [x16, #0x508]
    // 0x115bc38: stp             x0, x16, [SP, #8]
    // 0x115bc3c: str             x1, [SP]
    // 0x115bc40: mov             x0, x2
    // 0x115bc44: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x115bc44: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x115bc48: r0 = GDT[cid_x0 + 0x12caa]()
    //     0x115bc48: mov             x17, #0x2caa
    //     0x115bc4c: movk            x17, #1, lsl #16
    //     0x115bc50: add             lr, x0, x17
    //     0x115bc54: ldr             lr, [x21, lr, lsl #3]
    //     0x115bc58: blr             lr
    // 0x115bc5c: r1 = LoadClassIdInstr(r0)
    //     0x115bc5c: ldur            x1, [x0, #-1]
    //     0x115bc60: ubfx            x1, x1, #0xc, #0x14
    // 0x115bc64: mov             x16, x0
    // 0x115bc68: mov             x0, x1
    // 0x115bc6c: mov             x1, x16
    // 0x115bc70: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x115bc70: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x115bc74: r0 = GDT[cid_x0 + 0x126dc]()
    //     0x115bc74: mov             x17, #0x26dc
    //     0x115bc78: movk            x17, #1, lsl #16
    //     0x115bc7c: add             lr, x0, x17
    //     0x115bc80: ldr             lr, [x21, lr, lsl #3]
    //     0x115bc84: blr             lr
    // 0x115bc88: ldur            x1, [fp, #-0x18]
    // 0x115bc8c: ldur            x2, [fp, #-8]
    // 0x115bc90: mov             x3, x0
    // 0x115bc94: r0 = []=()
    //     0x115bc94: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x115bc98: ldur            x3, [fp, #-0x20]
    // 0x115bc9c: LoadField: r2 = r3->field_f
    //     0x115bc9c: ldur            w2, [x3, #0xf]
    // 0x115bca0: DecompressPointer r2
    //     0x115bca0: add             x2, x2, HEAP, lsl #32
    // 0x115bca4: ldur            x1, [fp, #-0x10]
    // 0x115bca8: r0 = LoadClassIdInstr(r1)
    //     0x115bca8: ldur            x0, [x1, #-1]
    //     0x115bcac: ubfx            x0, x0, #0xc, #0x14
    // 0x115bcb0: r0 = GDT[cid_x0 + 0x129dd]()
    //     0x115bcb0: mov             x17, #0x29dd
    //     0x115bcb4: movk            x17, #1, lsl #16
    //     0x115bcb8: add             lr, x0, x17
    //     0x115bcbc: ldr             lr, [x21, lr, lsl #3]
    //     0x115bcc0: blr             lr
    // 0x115bcc4: ldur            x0, [fp, #-0x20]
    // 0x115bcc8: ldur            x3, [fp, #-0x18]
    // 0x115bccc: LoadField: r2 = r0->field_f
    //     0x115bccc: ldur            w2, [x0, #0xf]
    // 0x115bcd0: DecompressPointer r2
    //     0x115bcd0: add             x2, x2, HEAP, lsl #32
    // 0x115bcd4: mov             x1, x3
    // 0x115bcd8: r0 = _getValueOrData()
    //     0x115bcd8: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x115bcdc: ldur            x1, [fp, #-0x18]
    // 0x115bce0: LoadField: r2 = r1->field_f
    //     0x115bce0: ldur            w2, [x1, #0xf]
    // 0x115bce4: DecompressPointer r2
    //     0x115bce4: add             x2, x2, HEAP, lsl #32
    // 0x115bce8: cmp             w2, w0
    // 0x115bcec: b.ne            #0x115bcf4
    // 0x115bcf0: r0 = Null
    //     0x115bcf0: mov             x0, NULL
    // 0x115bcf4: cmp             w0, NULL
    // 0x115bcf8: b.eq            #0x115bd10
    // 0x115bcfc: LeaveFrame
    //     0x115bcfc: mov             SP, fp
    //     0x115bd00: ldp             fp, lr, [SP], #0x10
    // 0x115bd04: ret
    //     0x115bd04: ret             
    // 0x115bd08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x115bd08: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x115bd0c: b               #0x115bae0
    // 0x115bd10: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x115bd10: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] AssetMetadata <anonymous closure>(dynamic, Map<Object?, Object?>) {
    // ** addr: 0x115bd14, size: 0x1b4
    // 0x115bd14: EnterFrame
    //     0x115bd14: stp             fp, lr, [SP, #-0x10]!
    //     0x115bd18: mov             fp, SP
    // 0x115bd1c: AllocStack(0x30)
    //     0x115bd1c: sub             SP, SP, #0x30
    // 0x115bd20: SetupParameters([dynamic _ /* r0 */])
    //     0x115bd20: ldr             x0, [fp, #0x18]
    //     0x115bd24: ldur            w3, [x0, #0x17]
    //     0x115bd28: add             x3, x3, HEAP, lsl #32
    //     0x115bd2c: stur            x3, [fp, #-8]
    // 0x115bd30: CheckStackOverflow
    //     0x115bd30: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x115bd34: cmp             SP, x16
    //     0x115bd38: b.ls            #0x115beb8
    // 0x115bd3c: ldr             x4, [fp, #0x10]
    // 0x115bd40: r0 = LoadClassIdInstr(r4)
    //     0x115bd40: ldur            x0, [x4, #-1]
    //     0x115bd44: ubfx            x0, x0, #0xc, #0x14
    // 0x115bd48: mov             x1, x4
    // 0x115bd4c: r2 = "asset"
    //     0x115bd4c: add             x2, PP, #0x8c, lsl #12  ; [pp+0x8c510] "asset"
    //     0x115bd50: ldr             x2, [x2, #0x510]
    // 0x115bd54: r0 = GDT[cid_x0 + -0xd48]()
    //     0x115bd54: sub             lr, x0, #0xd48
    //     0x115bd58: ldr             lr, [x21, lr, lsl #3]
    //     0x115bd5c: blr             lr
    // 0x115bd60: mov             x3, x0
    // 0x115bd64: stur            x3, [fp, #-0x10]
    // 0x115bd68: cmp             w3, NULL
    // 0x115bd6c: b.eq            #0x115bec0
    // 0x115bd70: mov             x0, x3
    // 0x115bd74: r2 = Null
    //     0x115bd74: mov             x2, NULL
    // 0x115bd78: r1 = Null
    //     0x115bd78: mov             x1, NULL
    // 0x115bd7c: r4 = 60
    //     0x115bd7c: mov             x4, #0x3c
    // 0x115bd80: branchIfSmi(r0, 0x115bd8c)
    //     0x115bd80: tbz             w0, #0, #0x115bd8c
    // 0x115bd84: r4 = LoadClassIdInstr(r0)
    //     0x115bd84: ldur            x4, [x0, #-1]
    //     0x115bd88: ubfx            x4, x4, #0xc, #0x14
    // 0x115bd8c: sub             x4, x4, #0x5e
    // 0x115bd90: cmp             x4, #1
    // 0x115bd94: b.ls            #0x115bda8
    // 0x115bd98: r8 = String
    //     0x115bd98: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x115bd9c: r3 = Null
    //     0x115bd9c: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8c518] Null
    //     0x115bda0: ldr             x3, [x3, #0x518]
    // 0x115bda4: r0 = String()
    //     0x115bda4: bl              #0x13ee320  ; IsType_String_Stub
    // 0x115bda8: ldr             x3, [fp, #0x10]
    // 0x115bdac: r0 = LoadClassIdInstr(r3)
    //     0x115bdac: ldur            x0, [x3, #-1]
    //     0x115bdb0: ubfx            x0, x0, #0xc, #0x14
    // 0x115bdb4: mov             x1, x3
    // 0x115bdb8: r2 = "dpr"
    //     0x115bdb8: add             x2, PP, #0x8c, lsl #12  ; [pp+0x8c528] "dpr"
    //     0x115bdbc: ldr             x2, [x2, #0x528]
    // 0x115bdc0: r0 = GDT[cid_x0 + -0xd48]()
    //     0x115bdc0: sub             lr, x0, #0xd48
    //     0x115bdc4: ldr             lr, [x21, lr, lsl #3]
    //     0x115bdc8: blr             lr
    // 0x115bdcc: mov             x3, x0
    // 0x115bdd0: ldr             x1, [fp, #0x10]
    // 0x115bdd4: stur            x3, [fp, #-0x18]
    // 0x115bdd8: r0 = LoadClassIdInstr(r1)
    //     0x115bdd8: ldur            x0, [x1, #-1]
    //     0x115bddc: ubfx            x0, x0, #0xc, #0x14
    // 0x115bde0: r2 = "asset"
    //     0x115bde0: add             x2, PP, #0x8c, lsl #12  ; [pp+0x8c510] "asset"
    //     0x115bde4: ldr             x2, [x2, #0x510]
    // 0x115bde8: r0 = GDT[cid_x0 + -0xd48]()
    //     0x115bde8: sub             lr, x0, #0xd48
    //     0x115bdec: ldr             lr, [x21, lr, lsl #3]
    //     0x115bdf0: blr             lr
    // 0x115bdf4: mov             x3, x0
    // 0x115bdf8: stur            x3, [fp, #-0x20]
    // 0x115bdfc: cmp             w3, NULL
    // 0x115be00: b.eq            #0x115bec4
    // 0x115be04: mov             x0, x3
    // 0x115be08: r2 = Null
    //     0x115be08: mov             x2, NULL
    // 0x115be0c: r1 = Null
    //     0x115be0c: mov             x1, NULL
    // 0x115be10: r4 = 60
    //     0x115be10: mov             x4, #0x3c
    // 0x115be14: branchIfSmi(r0, 0x115be20)
    //     0x115be14: tbz             w0, #0, #0x115be20
    // 0x115be18: r4 = LoadClassIdInstr(r0)
    //     0x115be18: ldur            x4, [x0, #-1]
    //     0x115be1c: ubfx            x4, x4, #0xc, #0x14
    // 0x115be20: sub             x4, x4, #0x5e
    // 0x115be24: cmp             x4, #1
    // 0x115be28: b.ls            #0x115be3c
    // 0x115be2c: r8 = String
    //     0x115be2c: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x115be30: r3 = Null
    //     0x115be30: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8c530] Null
    //     0x115be34: ldr             x3, [x3, #0x530]
    // 0x115be38: r0 = String()
    //     0x115be38: bl              #0x13ee320  ; IsType_String_Stub
    // 0x115be3c: ldur            x0, [fp, #-0x18]
    // 0x115be40: r2 = Null
    //     0x115be40: mov             x2, NULL
    // 0x115be44: r1 = Null
    //     0x115be44: mov             x1, NULL
    // 0x115be48: r4 = 60
    //     0x115be48: mov             x4, #0x3c
    // 0x115be4c: branchIfSmi(r0, 0x115be58)
    //     0x115be4c: tbz             w0, #0, #0x115be58
    // 0x115be50: r4 = LoadClassIdInstr(r0)
    //     0x115be50: ldur            x4, [x0, #-1]
    //     0x115be54: ubfx            x4, x4, #0xc, #0x14
    // 0x115be58: cmp             x4, #0x3e
    // 0x115be5c: b.eq            #0x115be70
    // 0x115be60: r8 = double?
    //     0x115be60: ldr             x8, [PP, #0x6e20]  ; [pp+0x6e20] Type: double?
    // 0x115be64: r3 = Null
    //     0x115be64: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8c540] Null
    //     0x115be68: ldr             x3, [x3, #0x540]
    // 0x115be6c: r0 = double?()
    //     0x115be6c: bl              #0x13ee3a4  ; IsType_double?_Stub
    // 0x115be70: ldur            x0, [fp, #-8]
    // 0x115be74: LoadField: r1 = r0->field_f
    //     0x115be74: ldur            w1, [x0, #0xf]
    // 0x115be78: DecompressPointer r1
    //     0x115be78: add             x1, x1, HEAP, lsl #32
    // 0x115be7c: r0 = LoadClassIdInstr(r1)
    //     0x115be7c: ldur            x0, [x1, #-1]
    //     0x115be80: ubfx            x0, x0, #0xc, #0x14
    // 0x115be84: ldur            x16, [fp, #-0x10]
    // 0x115be88: stp             x16, x1, [SP]
    // 0x115be8c: mov             lr, x0
    // 0x115be90: ldr             lr, [x21, lr, lsl #3]
    // 0x115be94: blr             lr
    // 0x115be98: r0 = AssetMetadata()
    //     0x115be98: bl              #0x115b9f0  ; AllocateAssetMetadataStub -> AssetMetadata (size=0x10)
    // 0x115be9c: ldur            x1, [fp, #-0x20]
    // 0x115bea0: StoreField: r0->field_b = r1
    //     0x115bea0: stur            w1, [x0, #0xb]
    // 0x115bea4: ldur            x1, [fp, #-0x18]
    // 0x115bea8: StoreField: r0->field_7 = r1
    //     0x115bea8: stur            w1, [x0, #7]
    // 0x115beac: LeaveFrame
    //     0x115beac: mov             SP, fp
    //     0x115beb0: ldp             fp, lr, [SP], #0x10
    // 0x115beb4: ret
    //     0x115beb4: ret             
    // 0x115beb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x115beb8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x115bebc: b               #0x115bd3c
    // 0x115bec0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x115bec0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x115bec4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x115bec4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2807, size: 0x8, field offset: 0x8
abstract class AssetManifest extends Object {

  static _ loadFromAssetBundle(/* No info */) {
    // ** addr: 0xeb3b28, size: 0x54
    // 0xeb3b28: EnterFrame
    //     0xeb3b28: stp             fp, lr, [SP, #-0x10]!
    //     0xeb3b2c: mov             fp, SP
    // 0xeb3b30: AllocStack(0x20)
    //     0xeb3b30: sub             SP, SP, #0x20
    // 0xeb3b34: CheckStackOverflow
    //     0xeb3b34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeb3b38: cmp             SP, x16
    //     0xeb3b3c: b.ls            #0xeb3b74
    // 0xeb3b40: r16 = <AssetManifest>
    //     0xeb3b40: add             x16, PP, #0x14, lsl #12  ; [pp+0x140e0] TypeArguments: <AssetManifest>
    //     0xeb3b44: ldr             x16, [x16, #0xe0]
    // 0xeb3b48: stp             x1, x16, [SP, #0x10]
    // 0xeb3b4c: r16 = "AssetManifest.bin"
    //     0xeb3b4c: add             x16, PP, #0x14, lsl #12  ; [pp+0x140e8] "AssetManifest.bin"
    //     0xeb3b50: ldr             x16, [x16, #0xe8]
    // 0xeb3b54: r30 = Closure: (ByteData) => _AssetManifestBin from Function '_AssetManifestBin@628287047.fromStandardMessageCodecMessage': static.
    //     0xeb3b54: add             lr, PP, #0x14, lsl #12  ; [pp+0x140f0] Closure: (ByteData) => _AssetManifestBin from Function '_AssetManifestBin@628287047.fromStandardMessageCodecMessage': static. (0x7f2adad9b010)
    //     0xeb3b58: ldr             lr, [lr, #0xf0]
    // 0xeb3b5c: stp             lr, x16, [SP]
    // 0xeb3b60: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xeb3b60: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xeb3b64: r0 = loadStructuredBinaryData()
    //     0xeb3b64: bl              #0xeb3b7c  ; [package:flutter/src/services/asset_bundle.dart] CachingAssetBundle::loadStructuredBinaryData
    // 0xeb3b68: LeaveFrame
    //     0xeb3b68: mov             SP, fp
    //     0xeb3b6c: ldp             fp, lr, [SP], #0x10
    // 0xeb3b70: ret
    //     0xeb3b70: ret             
    // 0xeb3b74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeb3b74: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeb3b78: b               #0xeb3b40
  }
}
