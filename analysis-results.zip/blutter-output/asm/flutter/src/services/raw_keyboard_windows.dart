// lib: , url: package:flutter/src/services/raw_keyboard_windows.dart

// class id: 1049093, size: 0x8
class :: {
}

// class id: 5019, size: 0x28, field offset: 0x8
//   const constructor, 
class RawKeyEventDataWindows extends RawKeyEventData {

  _ shouldDispatchEvent(/* No info */) {
    // ** addr: 0x112e004, size: 0x18
    // 0x112e004: LoadField: r2 = r1->field_7
    //     0x112e004: ldur            x2, [x1, #7]
    // 0x112e008: cmp             x2, #0xe5
    // 0x112e00c: r16 = true
    //     0x112e00c: add             x16, NULL, #0x20  ; true
    // 0x112e010: r17 = false
    //     0x112e010: add             x17, NULL, #0x30  ; false
    // 0x112e014: csel            x0, x16, x17, ne
    // 0x112e018: ret
    //     0x112e018: ret             
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x113c128, size: 0xc8
    // 0x113c128: EnterFrame
    //     0x113c128: stp             fp, lr, [SP, #-0x10]!
    //     0x113c12c: mov             fp, SP
    // 0x113c130: AllocStack(0x10)
    //     0x113c130: sub             SP, SP, #0x10
    // 0x113c134: CheckStackOverflow
    //     0x113c134: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x113c138: cmp             SP, x16
    //     0x113c13c: b.ls            #0x113c1e8
    // 0x113c140: ldr             x0, [fp, #0x10]
    // 0x113c144: LoadField: r2 = r0->field_7
    //     0x113c144: ldur            x2, [x0, #7]
    // 0x113c148: LoadField: r3 = r0->field_f
    //     0x113c148: ldur            x3, [x0, #0xf]
    // 0x113c14c: ArrayLoad: r4 = r0[0]  ; List_8
    //     0x113c14c: ldur            x4, [x0, #0x17]
    // 0x113c150: LoadField: r5 = r0->field_1f
    //     0x113c150: ldur            x5, [x0, #0x1f]
    // 0x113c154: r0 = BoxInt64Instr(r2)
    //     0x113c154: sbfiz           x0, x2, #1, #0x1f
    //     0x113c158: cmp             x2, x0, asr #1
    //     0x113c15c: b.eq            #0x113c168
    //     0x113c160: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x113c164: stur            x2, [x0, #7]
    // 0x113c168: mov             x2, x0
    // 0x113c16c: r0 = BoxInt64Instr(r3)
    //     0x113c16c: sbfiz           x0, x3, #1, #0x1f
    //     0x113c170: cmp             x3, x0, asr #1
    //     0x113c174: b.eq            #0x113c180
    //     0x113c178: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x113c17c: stur            x3, [x0, #7]
    // 0x113c180: mov             x3, x0
    // 0x113c184: r0 = BoxInt64Instr(r4)
    //     0x113c184: sbfiz           x0, x4, #1, #0x1f
    //     0x113c188: cmp             x4, x0, asr #1
    //     0x113c18c: b.eq            #0x113c198
    //     0x113c190: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x113c194: stur            x4, [x0, #7]
    // 0x113c198: mov             x4, x0
    // 0x113c19c: r0 = BoxInt64Instr(r5)
    //     0x113c19c: sbfiz           x0, x5, #1, #0x1f
    //     0x113c1a0: cmp             x5, x0, asr #1
    //     0x113c1a4: b.eq            #0x113c1b0
    //     0x113c1a8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x113c1ac: stur            x5, [x0, #7]
    // 0x113c1b0: stp             x0, x4, [SP]
    // 0x113c1b4: mov             x1, x2
    // 0x113c1b8: mov             x2, x3
    // 0x113c1bc: r4 = const [0, 0x4, 0x2, 0x4, null]
    //     0x113c1bc: ldr             x4, [PP, #0x1388]  ; [pp+0x1388] List(5) [0, 0x4, 0x2, 0x4, Null]
    // 0x113c1c0: r0 = hash()
    //     0x113c1c0: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x113c1c4: mov             x2, x0
    // 0x113c1c8: r0 = BoxInt64Instr(r2)
    //     0x113c1c8: sbfiz           x0, x2, #1, #0x1f
    //     0x113c1cc: cmp             x2, x0, asr #1
    //     0x113c1d0: b.eq            #0x113c1dc
    //     0x113c1d4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x113c1d8: stur            x2, [x0, #7]
    // 0x113c1dc: LeaveFrame
    //     0x113c1dc: mov             SP, fp
    //     0x113c1e0: ldp             fp, lr, [SP], #0x10
    // 0x113c1e4: ret
    //     0x113c1e4: ret             
    // 0x113c1e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x113c1e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x113c1ec: b               #0x113c140
  }
  get _ logicalKey(/* No info */) {
    // ** addr: 0x1143178, size: 0x190
    // 0x1143178: EnterFrame
    //     0x1143178: stp             fp, lr, [SP, #-0x10]!
    //     0x114317c: mov             fp, SP
    // 0x1143180: AllocStack(0x20)
    //     0x1143180: sub             SP, SP, #0x20
    // 0x1143184: SetupParameters(RawKeyEventDataWindows this /* r1 => r3, fp-0x18 */)
    //     0x1143184: mov             x3, x1
    //     0x1143188: stur            x1, [fp, #-0x18]
    // 0x114318c: CheckStackOverflow
    //     0x114318c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1143190: cmp             SP, x16
    //     0x1143194: b.ls            #0x11432fc
    // 0x1143198: LoadField: r4 = r3->field_7
    //     0x1143198: ldur            x4, [x3, #7]
    // 0x114319c: stur            x4, [fp, #-0x10]
    // 0x11431a0: r0 = BoxInt64Instr(r4)
    //     0x11431a0: sbfiz           x0, x4, #1, #0x1f
    //     0x11431a4: cmp             x4, x0, asr #1
    //     0x11431a8: b.eq            #0x11431b4
    //     0x11431ac: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x11431b0: stur            x4, [x0, #7]
    // 0x11431b4: mov             x2, x0
    // 0x11431b8: r1 = _ConstMap len:17
    //     0x11431b8: add             x1, PP, #0xd, lsl #12  ; [pp+0xdc60] Map<int, LogicalKeyboardKey>(17)
    //     0x11431bc: ldr             x1, [x1, #0xc60]
    // 0x11431c0: stur            x0, [fp, #-8]
    // 0x11431c4: r0 = []()
    //     0x11431c4: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x11431c8: cmp             w0, NULL
    // 0x11431cc: b.eq            #0x11431dc
    // 0x11431d0: LeaveFrame
    //     0x11431d0: mov             SP, fp
    //     0x11431d4: ldp             fp, lr, [SP], #0x10
    // 0x11431d8: ret
    //     0x11431d8: ret             
    // 0x11431dc: ldur            x0, [fp, #-0x18]
    // 0x11431e0: ArrayLoad: r3 = r0[0]  ; List_8
    //     0x11431e0: ldur            x3, [x0, #0x17]
    // 0x11431e4: stur            x3, [fp, #-0x20]
    // 0x11431e8: cbnz            x3, #0x11431f4
    // 0x11431ec: r0 = ""
    //     0x11431ec: ldr             x0, [PP, #0x900]  ; [pp+0x900] ""
    // 0x11431f0: b               #0x1143200
    // 0x11431f4: mov             x2, x3
    // 0x11431f8: r1 = Null
    //     0x11431f8: mov             x1, NULL
    // 0x11431fc: r0 = String.fromCharCode()
    //     0x11431fc: bl              #0x7e6340  ; [dart:core] String::String.fromCharCode
    // 0x1143200: LoadField: r1 = r0->field_7
    //     0x1143200: ldur            w1, [x0, #7]
    // 0x1143204: cbz             w1, #0x11432ac
    // 0x1143208: ldur            x1, [fp, #-0x18]
    // 0x114320c: r0 = keyLabel()
    //     0x114320c: bl              #0x1143308  ; [package:flutter/src/services/raw_keyboard_windows.dart] RawKeyEventDataWindows::keyLabel
    // 0x1143210: mov             x2, x0
    // 0x1143214: LoadField: r0 = r2->field_7
    //     0x1143214: ldur            w0, [x2, #7]
    // 0x1143218: r1 = LoadInt32Instr(r0)
    //     0x1143218: sbfx            x1, x0, #1, #0x1f
    // 0x114321c: cmp             x1, #1
    // 0x1143220: b.ne            #0x1143270
    // 0x1143224: mov             x0, x1
    // 0x1143228: r1 = 0
    //     0x1143228: mov             x1, #0
    // 0x114322c: cmp             x1, x0
    // 0x1143230: b.hs            #0x1143304
    // 0x1143234: r0 = LoadClassIdInstr(r2)
    //     0x1143234: ldur            x0, [x2, #-1]
    //     0x1143238: ubfx            x0, x0, #0xc, #0x14
    // 0x114323c: lsl             x0, x0, #1
    // 0x1143240: cmp             w0, #0xbc
    // 0x1143244: b.ne            #0x1143250
    // 0x1143248: ArrayLoad: r0 = r2[-8]  ; TypedUnsigned_1
    //     0x1143248: ldrb            w0, [x2, #0xf]
    // 0x114324c: b               #0x1143254
    // 0x1143250: ldurh           w0, [x2, #0xf]
    // 0x1143254: cmp             x0, #0x1f
    // 0x1143258: b.gt            #0x1143260
    // 0x114325c: tbz             x0, #0x3f, #0x11432ac
    // 0x1143260: cmp             x0, #0x7f
    // 0x1143264: b.lt            #0x1143270
    // 0x1143268: cmp             x0, #0x9f
    // 0x114326c: b.le            #0x11432ac
    // 0x1143270: ldur            x0, [fp, #-0x20]
    // 0x1143274: ubfx            x0, x0, #0, #0x20
    // 0x1143278: stur            x0, [fp, #-0x20]
    // 0x114327c: mov             x1, x0
    // 0x1143280: ubfx            x1, x1, #0, #0x20
    // 0x1143284: r0 = findKeyByKeyId()
    //     0x1143284: bl              #0x84a464  ; [package:flutter/src/services/keyboard_key.g.dart] LogicalKeyboardKey::findKeyByKeyId
    // 0x1143288: cmp             w0, NULL
    // 0x114328c: b.ne            #0x11432a0
    // 0x1143290: r0 = LogicalKeyboardKey()
    //     0x1143290: bl              #0x849274  ; AllocateLogicalKeyboardKeyStub -> LogicalKeyboardKey (size=0x10)
    // 0x1143294: ldur            x1, [fp, #-0x20]
    // 0x1143298: ubfx            x1, x1, #0, #0x20
    // 0x114329c: StoreField: r0->field_7 = r1
    //     0x114329c: stur            x1, [x0, #7]
    // 0x11432a0: LeaveFrame
    //     0x11432a0: mov             SP, fp
    //     0x11432a4: ldp             fp, lr, [SP], #0x10
    // 0x11432a8: ret
    //     0x11432a8: ret             
    // 0x11432ac: ldur            x2, [fp, #-8]
    // 0x11432b0: r1 = _ConstMap len:157
    //     0x11432b0: add             x1, PP, #0xd, lsl #12  ; [pp+0xdc68] Map<int, LogicalKeyboardKey>(157)
    //     0x11432b4: ldr             x1, [x1, #0xc68]
    // 0x11432b8: r0 = []()
    //     0x11432b8: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x11432bc: cmp             w0, NULL
    // 0x11432c0: b.eq            #0x11432d0
    // 0x11432c4: LeaveFrame
    //     0x11432c4: mov             SP, fp
    //     0x11432c8: ldp             fp, lr, [SP], #0x10
    // 0x11432cc: ret
    //     0x11432cc: ret             
    // 0x11432d0: ldur            x0, [fp, #-0x10]
    // 0x11432d4: r16 = 94489280512
    //     0x11432d4: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc70] IMM: 0x1600000000
    //     0x11432d8: ldr             x16, [x16, #0xc70]
    // 0x11432dc: orr             x1, x0, x16
    // 0x11432e0: stur            x1, [fp, #-0x20]
    // 0x11432e4: r0 = LogicalKeyboardKey()
    //     0x11432e4: bl              #0x849274  ; AllocateLogicalKeyboardKeyStub -> LogicalKeyboardKey (size=0x10)
    // 0x11432e8: ldur            x1, [fp, #-0x20]
    // 0x11432ec: StoreField: r0->field_7 = r1
    //     0x11432ec: stur            x1, [x0, #7]
    // 0x11432f0: LeaveFrame
    //     0x11432f0: mov             SP, fp
    //     0x11432f4: ldp             fp, lr, [SP], #0x10
    // 0x11432f8: ret
    //     0x11432f8: ret             
    // 0x11432fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11432fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1143300: b               #0x1143198
    // 0x1143304: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x1143304: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  get _ keyLabel(/* No info */) {
    // ** addr: 0x1143308, size: 0x40
    // 0x1143308: EnterFrame
    //     0x1143308: stp             fp, lr, [SP, #-0x10]!
    //     0x114330c: mov             fp, SP
    // 0x1143310: CheckStackOverflow
    //     0x1143310: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1143314: cmp             SP, x16
    //     0x1143318: b.ls            #0x1143340
    // 0x114331c: ArrayLoad: r2 = r1[0]  ; List_8
    //     0x114331c: ldur            x2, [x1, #0x17]
    // 0x1143320: cbnz            x2, #0x114332c
    // 0x1143324: r0 = ""
    //     0x1143324: ldr             x0, [PP, #0x900]  ; [pp+0x900] ""
    // 0x1143328: b               #0x1143334
    // 0x114332c: r1 = Null
    //     0x114332c: mov             x1, NULL
    // 0x1143330: r0 = String.fromCharCode()
    //     0x1143330: bl              #0x7e6340  ; [dart:core] String::String.fromCharCode
    // 0x1143334: LeaveFrame
    //     0x1143334: mov             SP, fp
    //     0x1143338: ldp             fp, lr, [SP], #0x10
    // 0x114333c: ret
    //     0x114333c: ret             
    // 0x1143340: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1143340: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1143344: b               #0x114331c
  }
  _ getModifierSide(/* No info */) {
    // ** addr: 0x11438a0, size: 0x1ac
    // 0x11438a0: LoadField: r3 = r2->field_7
    //     0x11438a0: ldur            x3, [x2, #7]
    // 0x11438a4: cmp             x3, #4
    // 0x11438a8: b.gt            #0x1143a44
    // 0x11438ac: cmp             x3, #2
    // 0x11438b0: b.gt            #0x11439e4
    // 0x11438b4: cmp             x3, #1
    // 0x11438b8: b.gt            #0x1143984
    // 0x11438bc: cmp             x3, #0
    // 0x11438c0: b.gt            #0x1143924
    // 0x11438c4: LoadField: r2 = r1->field_1f
    //     0x11438c4: ldur            x2, [x1, #0x1f]
    // 0x11438c8: mov             x4, x2
    // 0x11438cc: ubfx            x4, x4, #0, #0x20
    // 0x11438d0: and             w5, w4, #0x30
    // 0x11438d4: cmp             w5, #0x10
    // 0x11438d8: b.ne            #0x11438e8
    // 0x11438dc: r0 = Instance_KeyboardSide
    //     0x11438dc: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc50] Obj!KeyboardSide@12c3d01
    //     0x11438e0: ldr             x0, [x0, #0xc50]
    // 0x11438e4: b               #0x1143920
    // 0x11438e8: cmp             w5, #0x20
    // 0x11438ec: b.ne            #0x11438fc
    // 0x11438f0: r0 = Instance_KeyboardSide
    //     0x11438f0: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc58] Obj!KeyboardSide@12c3ce1
    //     0x11438f4: ldr             x0, [x0, #0xc58]
    // 0x11438f8: b               #0x1143920
    // 0x11438fc: cmp             w5, #0x30
    // 0x1143900: b.eq            #0x1143914
    // 0x1143904: ubfx            x2, x2, #0, #0x20
    // 0x1143908: and             w4, w2, #0x38
    // 0x114390c: cmp             w4, #8
    // 0x1143910: b.ne            #0x114391c
    // 0x1143914: r0 = Instance_KeyboardSide
    //     0x1143914: ldr             x0, [PP, #0x3b60]  ; [pp+0x3b60] Obj!KeyboardSide@12c3cc1
    // 0x1143918: b               #0x1143920
    // 0x114391c: r0 = Null
    //     0x114391c: mov             x0, NULL
    // 0x1143920: ret
    //     0x1143920: ret             
    // 0x1143924: LoadField: r2 = r1->field_1f
    //     0x1143924: ldur            x2, [x1, #0x1f]
    // 0x1143928: mov             x4, x2
    // 0x114392c: ubfx            x4, x4, #0, #0x20
    // 0x1143930: and             w5, w4, #6
    // 0x1143934: cmp             w5, #2
    // 0x1143938: b.ne            #0x1143948
    // 0x114393c: r0 = Instance_KeyboardSide
    //     0x114393c: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc50] Obj!KeyboardSide@12c3d01
    //     0x1143940: ldr             x0, [x0, #0xc50]
    // 0x1143944: b               #0x1143980
    // 0x1143948: cmp             w5, #4
    // 0x114394c: b.ne            #0x114395c
    // 0x1143950: r0 = Instance_KeyboardSide
    //     0x1143950: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc58] Obj!KeyboardSide@12c3ce1
    //     0x1143954: ldr             x0, [x0, #0xc58]
    // 0x1143958: b               #0x1143980
    // 0x114395c: cmp             w5, #6
    // 0x1143960: b.eq            #0x1143974
    // 0x1143964: ubfx            x2, x2, #0, #0x20
    // 0x1143968: and             w4, w2, #7
    // 0x114396c: cmp             w4, #1
    // 0x1143970: b.ne            #0x114397c
    // 0x1143974: r0 = Instance_KeyboardSide
    //     0x1143974: ldr             x0, [PP, #0x3b60]  ; [pp+0x3b60] Obj!KeyboardSide@12c3cc1
    // 0x1143978: b               #0x1143980
    // 0x114397c: r0 = Null
    //     0x114397c: mov             x0, NULL
    // 0x1143980: ret
    //     0x1143980: ret             
    // 0x1143984: LoadField: r2 = r1->field_1f
    //     0x1143984: ldur            x2, [x1, #0x1f]
    // 0x1143988: mov             x4, x2
    // 0x114398c: ubfx            x4, x4, #0, #0x20
    // 0x1143990: and             w5, w4, #0x180
    // 0x1143994: cmp             w5, #0x80
    // 0x1143998: b.ne            #0x11439a8
    // 0x114399c: r0 = Instance_KeyboardSide
    //     0x114399c: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc50] Obj!KeyboardSide@12c3d01
    //     0x11439a0: ldr             x0, [x0, #0xc50]
    // 0x11439a4: b               #0x11439e0
    // 0x11439a8: cmp             w5, #0x100
    // 0x11439ac: b.ne            #0x11439bc
    // 0x11439b0: r0 = Instance_KeyboardSide
    //     0x11439b0: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc58] Obj!KeyboardSide@12c3ce1
    //     0x11439b4: ldr             x0, [x0, #0xc58]
    // 0x11439b8: b               #0x11439e0
    // 0x11439bc: cmp             w5, #0x180
    // 0x11439c0: b.eq            #0x11439d4
    // 0x11439c4: ubfx            x2, x2, #0, #0x20
    // 0x11439c8: and             w4, w2, #0x1c0
    // 0x11439cc: cmp             w4, #0x40
    // 0x11439d0: b.ne            #0x11439dc
    // 0x11439d4: r0 = Instance_KeyboardSide
    //     0x11439d4: ldr             x0, [PP, #0x3b60]  ; [pp+0x3b60] Obj!KeyboardSide@12c3cc1
    // 0x11439d8: b               #0x11439e0
    // 0x11439dc: r0 = Null
    //     0x11439dc: mov             x0, NULL
    // 0x11439e0: ret
    //     0x11439e0: ret             
    // 0x11439e4: cmp             x3, #3
    // 0x11439e8: b.gt            #0x1143a44
    // 0x11439ec: LoadField: r2 = r1->field_1f
    //     0x11439ec: ldur            x2, [x1, #0x1f]
    // 0x11439f0: mov             x1, x2
    // 0x11439f4: ubfx            x1, x1, #0, #0x20
    // 0x11439f8: and             w3, w1, #0x600
    // 0x11439fc: cmp             w3, #0x200
    // 0x1143a00: b.ne            #0x1143a10
    // 0x1143a04: r0 = Instance_KeyboardSide
    //     0x1143a04: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc50] Obj!KeyboardSide@12c3d01
    //     0x1143a08: ldr             x0, [x0, #0xc50]
    // 0x1143a0c: b               #0x1143a40
    // 0x1143a10: cmp             w3, #0x400
    // 0x1143a14: b.ne            #0x1143a24
    // 0x1143a18: r0 = Instance_KeyboardSide
    //     0x1143a18: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc58] Obj!KeyboardSide@12c3ce1
    //     0x1143a1c: ldr             x0, [x0, #0xc58]
    // 0x1143a20: b               #0x1143a40
    // 0x1143a24: cmp             w3, #0x600
    // 0x1143a28: b.eq            #0x1143a34
    // 0x1143a2c: tst             x2, #0x600
    // 0x1143a30: b.ne            #0x1143a3c
    // 0x1143a34: r0 = Instance_KeyboardSide
    //     0x1143a34: ldr             x0, [PP, #0x3b60]  ; [pp+0x3b60] Obj!KeyboardSide@12c3cc1
    // 0x1143a38: b               #0x1143a40
    // 0x1143a3c: r0 = Null
    //     0x1143a3c: mov             x0, NULL
    // 0x1143a40: ret
    //     0x1143a40: ret             
    // 0x1143a44: r0 = Instance_KeyboardSide
    //     0x1143a44: ldr             x0, [PP, #0x3b60]  ; [pp+0x3b60] Obj!KeyboardSide@12c3cc1
    // 0x1143a48: ret
    //     0x1143a48: ret             
  }
  get _ physicalKey(/* No info */) {
    // ** addr: 0x1147830, size: 0x80
    // 0x1147830: EnterFrame
    //     0x1147830: stp             fp, lr, [SP, #-0x10]!
    //     0x1147834: mov             fp, SP
    // 0x1147838: AllocStack(0x10)
    //     0x1147838: sub             SP, SP, #0x10
    // 0x114783c: CheckStackOverflow
    //     0x114783c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1147840: cmp             SP, x16
    //     0x1147844: b.ls            #0x11478a8
    // 0x1147848: LoadField: r3 = r1->field_f
    //     0x1147848: ldur            x3, [x1, #0xf]
    // 0x114784c: stur            x3, [fp, #-8]
    // 0x1147850: r0 = BoxInt64Instr(r3)
    //     0x1147850: sbfiz           x0, x3, #1, #0x1f
    //     0x1147854: cmp             x3, x0, asr #1
    //     0x1147858: b.eq            #0x1147864
    //     0x114785c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1147860: stur            x3, [x0, #7]
    // 0x1147864: mov             x2, x0
    // 0x1147868: r1 = _ConstMap len:157
    //     0x1147868: add             x1, PP, #0xd, lsl #12  ; [pp+0xdc78] Map<int, PhysicalKeyboardKey>(157)
    //     0x114786c: ldr             x1, [x1, #0xc78]
    // 0x1147870: r0 = []()
    //     0x1147870: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x1147874: cmp             w0, NULL
    // 0x1147878: b.ne            #0x114789c
    // 0x114787c: ldur            x0, [fp, #-8]
    // 0x1147880: r17 = 94489280512
    //     0x1147880: add             x17, PP, #0xd, lsl #12  ; [pp+0xdc70] IMM: 0x1600000000
    //     0x1147884: ldr             x17, [x17, #0xc70]
    // 0x1147888: add             x1, x0, x17
    // 0x114788c: stur            x1, [fp, #-0x10]
    // 0x1147890: r0 = PhysicalKeyboardKey()
    //     0x1147890: bl              #0x8492a4  ; AllocatePhysicalKeyboardKeyStub -> PhysicalKeyboardKey (size=0x10)
    // 0x1147894: ldur            x1, [fp, #-0x10]
    // 0x1147898: StoreField: r0->field_7 = r1
    //     0x1147898: stur            x1, [x0, #7]
    // 0x114789c: LeaveFrame
    //     0x114789c: mov             SP, fp
    //     0x11478a0: ldp             fp, lr, [SP], #0x10
    // 0x11478a4: ret
    //     0x11478a4: ret             
    // 0x11478a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11478a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11478ac: b               #0x1147848
  }
  _ isModifierPressed(/* No info */) {
    // ** addr: 0x116f180, size: 0x190
    // 0x116f180: LoadField: r3 = r2->field_7
    //     0x116f180: ldur            x3, [x2, #7]
    // 0x116f184: cmp             x3, #4
    // 0x116f188: b.gt            #0x116f2b0
    // 0x116f18c: cmp             x3, #2
    // 0x116f190: b.gt            #0x116f24c
    // 0x116f194: cmp             x3, #1
    // 0x116f198: b.gt            #0x116f214
    // 0x116f19c: cmp             x3, #0
    // 0x116f1a0: b.gt            #0x116f1dc
    // 0x116f1a4: LoadField: r2 = r1->field_1f
    //     0x116f1a4: ldur            x2, [x1, #0x1f]
    // 0x116f1a8: tst             x2, #0x38
    // 0x116f1ac: b.ne            #0x116f1b8
    // 0x116f1b0: r2 = false
    //     0x116f1b0: add             x2, NULL, #0x30  ; false
    // 0x116f1b4: b               #0x116f1d4
    // 0x116f1b8: ubfx            x2, x2, #0, #0x20
    // 0x116f1bc: and             w4, w2, #0x38
    // 0x116f1c0: cmp             w4, #8
    // 0x116f1c4: b.ne            #0x116f1d0
    // 0x116f1c8: r2 = true
    //     0x116f1c8: add             x2, NULL, #0x20  ; true
    // 0x116f1cc: b               #0x116f1d4
    // 0x116f1d0: r2 = true
    //     0x116f1d0: add             x2, NULL, #0x20  ; true
    // 0x116f1d4: mov             x0, x2
    // 0x116f1d8: b               #0x116f30c
    // 0x116f1dc: LoadField: r2 = r1->field_1f
    //     0x116f1dc: ldur            x2, [x1, #0x1f]
    // 0x116f1e0: tst             x2, #7
    // 0x116f1e4: b.ne            #0x116f1f0
    // 0x116f1e8: r2 = false
    //     0x116f1e8: add             x2, NULL, #0x30  ; false
    // 0x116f1ec: b               #0x116f20c
    // 0x116f1f0: ubfx            x2, x2, #0, #0x20
    // 0x116f1f4: and             w4, w2, #7
    // 0x116f1f8: cmp             w4, #1
    // 0x116f1fc: b.ne            #0x116f208
    // 0x116f200: r2 = true
    //     0x116f200: add             x2, NULL, #0x20  ; true
    // 0x116f204: b               #0x116f20c
    // 0x116f208: r2 = true
    //     0x116f208: add             x2, NULL, #0x20  ; true
    // 0x116f20c: mov             x0, x2
    // 0x116f210: b               #0x116f30c
    // 0x116f214: LoadField: r2 = r1->field_1f
    //     0x116f214: ldur            x2, [x1, #0x1f]
    // 0x116f218: tst             x2, #0x1c0
    // 0x116f21c: b.ne            #0x116f228
    // 0x116f220: r2 = false
    //     0x116f220: add             x2, NULL, #0x30  ; false
    // 0x116f224: b               #0x116f244
    // 0x116f228: ubfx            x2, x2, #0, #0x20
    // 0x116f22c: and             w4, w2, #0x1c0
    // 0x116f230: cmp             w4, #0x40
    // 0x116f234: b.ne            #0x116f240
    // 0x116f238: r2 = true
    //     0x116f238: add             x2, NULL, #0x20  ; true
    // 0x116f23c: b               #0x116f244
    // 0x116f240: r2 = true
    //     0x116f240: add             x2, NULL, #0x20  ; true
    // 0x116f244: mov             x0, x2
    // 0x116f248: b               #0x116f30c
    // 0x116f24c: cmp             x3, #3
    // 0x116f250: b.gt            #0x116f28c
    // 0x116f254: LoadField: r2 = r1->field_1f
    //     0x116f254: ldur            x2, [x1, #0x1f]
    // 0x116f258: tst             x2, #0x600
    // 0x116f25c: b.ne            #0x116f268
    // 0x116f260: r2 = false
    //     0x116f260: add             x2, NULL, #0x30  ; false
    // 0x116f264: b               #0x116f284
    // 0x116f268: ubfx            x2, x2, #0, #0x20
    // 0x116f26c: and             w4, w2, #0x600
    // 0x116f270: cmp             w4, #0x600
    // 0x116f274: b.ne            #0x116f280
    // 0x116f278: r2 = true
    //     0x116f278: add             x2, NULL, #0x20  ; true
    // 0x116f27c: b               #0x116f284
    // 0x116f280: r2 = true
    //     0x116f280: add             x2, NULL, #0x20  ; true
    // 0x116f284: mov             x0, x2
    // 0x116f288: b               #0x116f30c
    // 0x116f28c: LoadField: r2 = r1->field_1f
    //     0x116f28c: ldur            x2, [x1, #0x1f]
    // 0x116f290: ubfx            x2, x2, #0, #0x20
    // 0x116f294: and             w4, w2, #0x800
    // 0x116f298: cbnz            w4, #0x116f2a4
    // 0x116f29c: r2 = false
    //     0x116f29c: add             x2, NULL, #0x30  ; false
    // 0x116f2a0: b               #0x116f2a8
    // 0x116f2a4: r2 = true
    //     0x116f2a4: add             x2, NULL, #0x20  ; true
    // 0x116f2a8: mov             x0, x2
    // 0x116f2ac: b               #0x116f30c
    // 0x116f2b0: cmp             x3, #6
    // 0x116f2b4: b.gt            #0x116f308
    // 0x116f2b8: cmp             x3, #5
    // 0x116f2bc: b.gt            #0x116f2e4
    // 0x116f2c0: LoadField: r2 = r1->field_1f
    //     0x116f2c0: ldur            x2, [x1, #0x1f]
    // 0x116f2c4: ubfx            x2, x2, #0, #0x20
    // 0x116f2c8: and             w3, w2, #0x1000
    // 0x116f2cc: cbnz            w3, #0x116f2d8
    // 0x116f2d0: r2 = false
    //     0x116f2d0: add             x2, NULL, #0x30  ; false
    // 0x116f2d4: b               #0x116f2dc
    // 0x116f2d8: r2 = true
    //     0x116f2d8: add             x2, NULL, #0x20  ; true
    // 0x116f2dc: mov             x0, x2
    // 0x116f2e0: b               #0x116f30c
    // 0x116f2e4: LoadField: r2 = r1->field_1f
    //     0x116f2e4: ldur            x2, [x1, #0x1f]
    // 0x116f2e8: ubfx            x2, x2, #0, #0x20
    // 0x116f2ec: and             w1, w2, #0x2000
    // 0x116f2f0: cbnz            w1, #0x116f2fc
    // 0x116f2f4: r2 = false
    //     0x116f2f4: add             x2, NULL, #0x30  ; false
    // 0x116f2f8: b               #0x116f300
    // 0x116f2fc: r2 = true
    //     0x116f2fc: add             x2, NULL, #0x20  ; true
    // 0x116f300: mov             x0, x2
    // 0x116f304: b               #0x116f30c
    // 0x116f308: r0 = false
    //     0x116f308: add             x0, NULL, #0x30  ; false
    // 0x116f30c: ret
    //     0x116f30c: ret             
  }
  _ ==(/* No info */) {
    // ** addr: 0x127a2dc, size: 0x11c
    // 0x127a2dc: EnterFrame
    //     0x127a2dc: stp             fp, lr, [SP, #-0x10]!
    //     0x127a2e0: mov             fp, SP
    // 0x127a2e4: AllocStack(0x10)
    //     0x127a2e4: sub             SP, SP, #0x10
    // 0x127a2e8: CheckStackOverflow
    //     0x127a2e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x127a2ec: cmp             SP, x16
    //     0x127a2f0: b.ls            #0x127a3f0
    // 0x127a2f4: ldr             x0, [fp, #0x10]
    // 0x127a2f8: cmp             w0, NULL
    // 0x127a2fc: b.ne            #0x127a310
    // 0x127a300: r0 = false
    //     0x127a300: add             x0, NULL, #0x30  ; false
    // 0x127a304: LeaveFrame
    //     0x127a304: mov             SP, fp
    //     0x127a308: ldp             fp, lr, [SP], #0x10
    // 0x127a30c: ret
    //     0x127a30c: ret             
    // 0x127a310: ldr             x1, [fp, #0x18]
    // 0x127a314: cmp             w1, w0
    // 0x127a318: b.ne            #0x127a32c
    // 0x127a31c: r0 = true
    //     0x127a31c: add             x0, NULL, #0x20  ; true
    // 0x127a320: LeaveFrame
    //     0x127a320: mov             SP, fp
    //     0x127a324: ldp             fp, lr, [SP], #0x10
    // 0x127a328: ret
    //     0x127a328: ret             
    // 0x127a32c: str             x0, [SP]
    // 0x127a330: r0 = runtimeType()
    //     0x127a330: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x127a334: r1 = LoadClassIdInstr(r0)
    //     0x127a334: ldur            x1, [x0, #-1]
    //     0x127a338: ubfx            x1, x1, #0xc, #0x14
    // 0x127a33c: r16 = RawKeyEventDataWindows
    //     0x127a33c: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc48] Type: RawKeyEventDataWindows
    //     0x127a340: ldr             x16, [x16, #0xc48]
    // 0x127a344: stp             x16, x0, [SP]
    // 0x127a348: mov             x0, x1
    // 0x127a34c: mov             lr, x0
    // 0x127a350: ldr             lr, [x21, lr, lsl #3]
    // 0x127a354: blr             lr
    // 0x127a358: tbz             w0, #4, #0x127a36c
    // 0x127a35c: r0 = false
    //     0x127a35c: add             x0, NULL, #0x30  ; false
    // 0x127a360: LeaveFrame
    //     0x127a360: mov             SP, fp
    //     0x127a364: ldp             fp, lr, [SP], #0x10
    // 0x127a368: ret
    //     0x127a368: ret             
    // 0x127a36c: ldr             x1, [fp, #0x10]
    // 0x127a370: r2 = 60
    //     0x127a370: mov             x2, #0x3c
    // 0x127a374: branchIfSmi(r1, 0x127a380)
    //     0x127a374: tbz             w1, #0, #0x127a380
    // 0x127a378: r2 = LoadClassIdInstr(r1)
    //     0x127a378: ldur            x2, [x1, #-1]
    //     0x127a37c: ubfx            x2, x2, #0xc, #0x14
    // 0x127a380: r17 = 5019
    //     0x127a380: mov             x17, #0x139b
    // 0x127a384: cmp             x2, x17
    // 0x127a388: b.ne            #0x127a3e0
    // 0x127a38c: ldr             x2, [fp, #0x18]
    // 0x127a390: LoadField: r3 = r1->field_7
    //     0x127a390: ldur            x3, [x1, #7]
    // 0x127a394: LoadField: r4 = r2->field_7
    //     0x127a394: ldur            x4, [x2, #7]
    // 0x127a398: cmp             x3, x4
    // 0x127a39c: b.ne            #0x127a3e0
    // 0x127a3a0: LoadField: r3 = r1->field_f
    //     0x127a3a0: ldur            x3, [x1, #0xf]
    // 0x127a3a4: LoadField: r4 = r2->field_f
    //     0x127a3a4: ldur            x4, [x2, #0xf]
    // 0x127a3a8: cmp             x3, x4
    // 0x127a3ac: b.ne            #0x127a3e0
    // 0x127a3b0: ArrayLoad: r3 = r1[0]  ; List_8
    //     0x127a3b0: ldur            x3, [x1, #0x17]
    // 0x127a3b4: ArrayLoad: r4 = r2[0]  ; List_8
    //     0x127a3b4: ldur            x4, [x2, #0x17]
    // 0x127a3b8: cmp             x3, x4
    // 0x127a3bc: b.ne            #0x127a3e0
    // 0x127a3c0: LoadField: r3 = r1->field_1f
    //     0x127a3c0: ldur            x3, [x1, #0x1f]
    // 0x127a3c4: LoadField: r1 = r2->field_1f
    //     0x127a3c4: ldur            x1, [x2, #0x1f]
    // 0x127a3c8: cmp             x3, x1
    // 0x127a3cc: r16 = true
    //     0x127a3cc: add             x16, NULL, #0x20  ; true
    // 0x127a3d0: r17 = false
    //     0x127a3d0: add             x17, NULL, #0x30  ; false
    // 0x127a3d4: csel            x2, x16, x17, eq
    // 0x127a3d8: mov             x0, x2
    // 0x127a3dc: b               #0x127a3e4
    // 0x127a3e0: r0 = false
    //     0x127a3e0: add             x0, NULL, #0x30  ; false
    // 0x127a3e4: LeaveFrame
    //     0x127a3e4: mov             SP, fp
    //     0x127a3e8: ldp             fp, lr, [SP], #0x10
    // 0x127a3ec: ret
    //     0x127a3ec: ret             
    // 0x127a3f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x127a3f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x127a3f4: b               #0x127a2f4
  }
}
