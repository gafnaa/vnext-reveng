// lib: , url: package:flutter/src/services/platform_views.dart

// class id: 1049083, size: 0x8
class :: {

  static late final PlatformViewsRegistry platformViewsRegistry; // offset: 0xc2c

  static PlatformViewsRegistry platformViewsRegistry() {
    // ** addr: 0xf75068, size: 0x1c
    // 0xf75068: EnterFrame
    //     0xf75068: stp             fp, lr, [SP, #-0x10]!
    //     0xf7506c: mov             fp, SP
    // 0xf75070: r0 = PlatformViewsRegistry()
    //     0xf75070: bl              #0xf75084  ; AllocatePlatformViewsRegistryStub -> PlatformViewsRegistry (size=0x10)
    // 0xf75074: StoreField: r0->field_7 = rZR
    //     0xf75074: stur            xzr, [x0, #7]
    // 0xf75078: LeaveFrame
    //     0xf75078: mov             SP, fp
    //     0xf7507c: ldp             fp, lr, [SP], #0x10
    // 0xf75080: ret
    //     0xf75080: ret             
  }
}

// class id: 2759, size: 0x8, field offset: 0x8
abstract class _AndroidViewControllerInternals extends Object {

  static _ sendCreateMessage(/* No info */) {
    // ** addr: 0x130a8ec, size: 0x420
    // 0x130a8ec: EnterFrame
    //     0x130a8ec: stp             fp, lr, [SP, #-0x10]!
    //     0x130a8f0: mov             fp, SP
    // 0x130a8f4: AllocStack(0x68)
    //     0x130a8f4: sub             SP, SP, #0x68
    // 0x130a8f8: SetupParameters(dynamic _ /* r1 => r2, fp-0x28 */, dynamic _ /* r2 => r3, fp-0x40 */, [dynamic _ /* fp-0x30 */, dynamic _ /* fp-0x38 */])
    //     0x130a8f8: stur            x1, [fp, #-0x18]
    //     0x130a8fc: mov             x16, x2
    //     0x130a900: mov             x2, x1
    //     0x130a904: mov             x1, x16
    //     0x130a908: mov             x0, x3
    //     0x130a90c: stur            x3, [fp, #-0x28]
    //     0x130a910: mov             x3, x7
    //     0x130a914: stur            x1, [fp, #-0x20]
    //     0x130a918: stur            x5, [fp, #-0x30]
    //     0x130a91c: stur            x6, [fp, #-0x38]
    //     0x130a920: stur            x7, [fp, #-0x40]
    // 0x130a924: LoadField: r7 = r4->field_13
    //     0x130a924: ldur            w7, [x4, #0x13]
    // 0x130a928: LoadField: r8 = r4->field_1f
    //     0x130a928: ldur            w8, [x4, #0x1f]
    // 0x130a92c: DecompressPointer r8
    //     0x130a92c: add             x8, x8, HEAP, lsl #32
    // 0x130a930: r16 = "hybridFallback"
    //     0x130a930: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8ce18] "hybridFallback"
    //     0x130a934: ldr             x16, [x16, #0xe18]
    // 0x130a938: cmp             w8, w16
    // 0x130a93c: b.ne            #0x130a960
    // 0x130a940: LoadField: r8 = r4->field_23
    //     0x130a940: ldur            w8, [x4, #0x23]
    // 0x130a944: DecompressPointer r8
    //     0x130a944: add             x8, x8, HEAP, lsl #32
    // 0x130a948: sub             w9, w7, w8
    // 0x130a94c: add             x8, fp, w9, sxtw #2
    // 0x130a950: ldr             x8, [x8, #8]
    // 0x130a954: mov             x9, x8
    // 0x130a958: r8 = 1
    //     0x130a958: mov             x8, #1
    // 0x130a95c: b               #0x130a968
    // 0x130a960: r9 = false
    //     0x130a960: add             x9, NULL, #0x30  ; false
    // 0x130a964: r8 = 0
    //     0x130a964: mov             x8, #0
    // 0x130a968: stur            x9, [fp, #-0x10]
    // 0x130a96c: lsl             x10, x8, #1
    // 0x130a970: lsl             w8, w10, #1
    // 0x130a974: add             w10, w8, #8
    // 0x130a978: ArrayLoad: r11 = r4[r10]  ; Unknown_4
    //     0x130a978: add             x16, x4, w10, sxtw #1
    //     0x130a97c: ldur            w11, [x16, #0xf]
    // 0x130a980: DecompressPointer r11
    //     0x130a980: add             x11, x11, HEAP, lsl #32
    // 0x130a984: r16 = "size"
    //     0x130a984: add             x16, PP, #0x22, lsl #12  ; [pp+0x22310] "size"
    //     0x130a988: ldr             x16, [x16, #0x310]
    // 0x130a98c: cmp             w11, w16
    // 0x130a990: b.ne            #0x130a9b8
    // 0x130a994: add             w10, w8, #0xa
    // 0x130a998: ArrayLoad: r8 = r4[r10]  ; Unknown_4
    //     0x130a998: add             x16, x4, w10, sxtw #1
    //     0x130a99c: ldur            w8, [x16, #0xf]
    // 0x130a9a0: DecompressPointer r8
    //     0x130a9a0: add             x8, x8, HEAP, lsl #32
    // 0x130a9a4: sub             w4, w7, w8
    // 0x130a9a8: add             x7, fp, w4, sxtw #2
    // 0x130a9ac: ldr             x7, [x7, #8]
    // 0x130a9b0: mov             x4, x7
    // 0x130a9b4: b               #0x130a9bc
    // 0x130a9b8: r4 = Null
    //     0x130a9b8: mov             x4, NULL
    // 0x130a9bc: stur            x4, [fp, #-8]
    // 0x130a9c0: CheckStackOverflow
    //     0x130a9c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x130a9c4: cmp             SP, x16
    //     0x130a9c8: b.ls            #0x130acac
    // 0x130a9cc: r16 = <String, dynamic>
    //     0x130a9cc: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x130a9d0: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x130a9d4: stp             lr, x16, [SP]
    // 0x130a9d8: r0 = Map._fromLiteral()
    //     0x130a9d8: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x130a9dc: mov             x4, x0
    // 0x130a9e0: ldur            x2, [fp, #-0x38]
    // 0x130a9e4: stur            x4, [fp, #-0x48]
    // 0x130a9e8: r0 = BoxInt64Instr(r2)
    //     0x130a9e8: sbfiz           x0, x2, #1, #0x1f
    //     0x130a9ec: cmp             x2, x0, asr #1
    //     0x130a9f0: b.eq            #0x130a9fc
    //     0x130a9f4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x130a9f8: stur            x2, [x0, #7]
    // 0x130a9fc: r1 = LoadClassIdInstr(r4)
    //     0x130a9fc: ldur            x1, [x4, #-1]
    //     0x130aa00: ubfx            x1, x1, #0xc, #0x14
    // 0x130aa04: mov             x3, x0
    // 0x130aa08: mov             x0, x1
    // 0x130aa0c: mov             x1, x4
    // 0x130aa10: r2 = "id"
    //     0x130aa10: ldr             x2, [PP, #0x7f88]  ; [pp+0x7f88] "id"
    // 0x130aa14: r0 = GDT[cid_x0 + -0xd50]()
    //     0x130aa14: sub             lr, x0, #0xd50
    //     0x130aa18: ldr             lr, [x21, lr, lsl #3]
    //     0x130aa1c: blr             lr
    // 0x130aa20: ldur            x4, [fp, #-0x48]
    // 0x130aa24: r0 = LoadClassIdInstr(r4)
    //     0x130aa24: ldur            x0, [x4, #-1]
    //     0x130aa28: ubfx            x0, x0, #0xc, #0x14
    // 0x130aa2c: mov             x1, x4
    // 0x130aa30: ldur            x3, [fp, #-0x40]
    // 0x130aa34: r2 = "viewType"
    //     0x130aa34: add             x2, PP, #0x8c, lsl #12  ; [pp+0x8ce20] "viewType"
    //     0x130aa38: ldr             x2, [x2, #0xe20]
    // 0x130aa3c: r0 = GDT[cid_x0 + -0xd50]()
    //     0x130aa3c: sub             lr, x0, #0xd50
    //     0x130aa40: ldr             lr, [x21, lr, lsl #3]
    //     0x130aa44: blr             lr
    // 0x130aa48: ldur            x0, [fp, #-0x28]
    // 0x130aa4c: LoadField: r1 = r0->field_7
    //     0x130aa4c: ldur            x1, [x0, #7]
    // 0x130aa50: cmp             x1, #0
    // 0x130aa54: b.gt            #0x130aa60
    // 0x130aa58: r1 = 1
    //     0x130aa58: mov             x1, #1
    // 0x130aa5c: b               #0x130aa64
    // 0x130aa60: r1 = 0
    //     0x130aa60: mov             x1, #0
    // 0x130aa64: ldur            x0, [fp, #-0x20]
    // 0x130aa68: lsl             x3, x1, #1
    // 0x130aa6c: ldur            x1, [fp, #-0x48]
    // 0x130aa70: r2 = "direction"
    //     0x130aa70: add             x2, PP, #0x19, lsl #12  ; [pp+0x19f00] "direction"
    //     0x130aa74: ldr             x2, [x2, #0xf00]
    // 0x130aa78: r0 = []=()
    //     0x130aa78: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x130aa7c: ldur            x3, [fp, #-0x20]
    // 0x130aa80: tbnz            w3, #4, #0x130aa94
    // 0x130aa84: ldur            x1, [fp, #-0x48]
    // 0x130aa88: r2 = "hybrid"
    //     0x130aa88: add             x2, PP, #0x8c, lsl #12  ; [pp+0x8ce28] "hybrid"
    //     0x130aa8c: ldr             x2, [x2, #0xe28]
    // 0x130aa90: r0 = []=()
    //     0x130aa90: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x130aa94: ldur            x0, [fp, #-8]
    // 0x130aa98: cmp             w0, NULL
    // 0x130aa9c: b.ne            #0x130aaa8
    // 0x130aaa0: r3 = Null
    //     0x130aaa0: mov             x3, NULL
    // 0x130aaa4: b               #0x130aadc
    // 0x130aaa8: LoadField: d0 = r0->field_7
    //     0x130aaa8: ldur            d0, [x0, #7]
    // 0x130aaac: r1 = inline_Allocate_Double()
    //     0x130aaac: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x130aab0: add             x1, x1, #0x10
    //     0x130aab4: cmp             x2, x1
    //     0x130aab8: b.ls            #0x130acb4
    //     0x130aabc: str             x1, [THR, #0x60]  ; THR::top
    //     0x130aac0: sub             x1, x1, #0xf
    //     0x130aac4: mov             x2, #0xe19c
    //     0x130aac8: movk            x2, #3, lsl #16
    //     0x130aacc: stur            x2, [x1, #-1]
    // 0x130aad0: dmb             ishst
    // 0x130aad4: StoreField: r1->field_7 = d0
    //     0x130aad4: stur            d0, [x1, #7]
    // 0x130aad8: mov             x3, x1
    // 0x130aadc: cmp             w3, NULL
    // 0x130aae0: b.eq            #0x130aaf0
    // 0x130aae4: ldur            x1, [fp, #-0x48]
    // 0x130aae8: r2 = "width"
    //     0x130aae8: ldr             x2, [PP, #0x5a40]  ; [pp+0x5a40] "width"
    // 0x130aaec: r0 = []=()
    //     0x130aaec: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x130aaf0: ldur            x0, [fp, #-8]
    // 0x130aaf4: cmp             w0, NULL
    // 0x130aaf8: b.ne            #0x130ab04
    // 0x130aafc: r3 = Null
    //     0x130aafc: mov             x3, NULL
    // 0x130ab00: b               #0x130ab38
    // 0x130ab04: LoadField: d0 = r0->field_f
    //     0x130ab04: ldur            d0, [x0, #0xf]
    // 0x130ab08: r0 = inline_Allocate_Double()
    //     0x130ab08: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x130ab0c: add             x0, x0, #0x10
    //     0x130ab10: cmp             x1, x0
    //     0x130ab14: b.ls            #0x130acd0
    //     0x130ab18: str             x0, [THR, #0x60]  ; THR::top
    //     0x130ab1c: sub             x0, x0, #0xf
    //     0x130ab20: mov             x1, #0xe19c
    //     0x130ab24: movk            x1, #3, lsl #16
    //     0x130ab28: stur            x1, [x0, #-1]
    // 0x130ab2c: dmb             ishst
    // 0x130ab30: StoreField: r0->field_7 = d0
    //     0x130ab30: stur            d0, [x0, #7]
    // 0x130ab34: mov             x3, x0
    // 0x130ab38: cmp             w3, NULL
    // 0x130ab3c: b.eq            #0x130ab4c
    // 0x130ab40: ldur            x1, [fp, #-0x48]
    // 0x130ab44: r2 = "height"
    //     0x130ab44: ldr             x2, [PP, #0x4ac8]  ; [pp+0x4ac8] "height"
    // 0x130ab48: r0 = []=()
    //     0x130ab48: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x130ab4c: ldur            x3, [fp, #-0x10]
    // 0x130ab50: tbnz            w3, #4, #0x130ab64
    // 0x130ab54: ldur            x1, [fp, #-0x48]
    // 0x130ab58: r2 = "hybridFallback"
    //     0x130ab58: add             x2, PP, #0x8c, lsl #12  ; [pp+0x8ce18] "hybridFallback"
    //     0x130ab5c: ldr             x2, [x2, #0xe18]
    // 0x130ab60: r0 = []=()
    //     0x130ab60: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x130ab64: ldur            x0, [fp, #-0x30]
    // 0x130ab68: cmp             w0, NULL
    // 0x130ab6c: b.ne            #0x130ab78
    // 0x130ab70: r3 = Null
    //     0x130ab70: mov             x3, NULL
    // 0x130ab74: b               #0x130abac
    // 0x130ab78: LoadField: d0 = r0->field_7
    //     0x130ab78: ldur            d0, [x0, #7]
    // 0x130ab7c: r1 = inline_Allocate_Double()
    //     0x130ab7c: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x130ab80: add             x1, x1, #0x10
    //     0x130ab84: cmp             x2, x1
    //     0x130ab88: b.ls            #0x130ace0
    //     0x130ab8c: str             x1, [THR, #0x60]  ; THR::top
    //     0x130ab90: sub             x1, x1, #0xf
    //     0x130ab94: mov             x2, #0xe19c
    //     0x130ab98: movk            x2, #3, lsl #16
    //     0x130ab9c: stur            x2, [x1, #-1]
    // 0x130aba0: dmb             ishst
    // 0x130aba4: StoreField: r1->field_7 = d0
    //     0x130aba4: stur            d0, [x1, #7]
    // 0x130aba8: mov             x3, x1
    // 0x130abac: cmp             w3, NULL
    // 0x130abb0: b.eq            #0x130abc0
    // 0x130abb4: ldur            x1, [fp, #-0x48]
    // 0x130abb8: r2 = "left"
    //     0x130abb8: ldr             x2, [PP, #0x57c0]  ; [pp+0x57c0] "left"
    // 0x130abbc: r0 = []=()
    //     0x130abbc: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x130abc0: ldur            x0, [fp, #-0x30]
    // 0x130abc4: cmp             w0, NULL
    // 0x130abc8: b.ne            #0x130abd4
    // 0x130abcc: r3 = Null
    //     0x130abcc: mov             x3, NULL
    // 0x130abd0: b               #0x130ac08
    // 0x130abd4: LoadField: d0 = r0->field_f
    //     0x130abd4: ldur            d0, [x0, #0xf]
    // 0x130abd8: r0 = inline_Allocate_Double()
    //     0x130abd8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x130abdc: add             x0, x0, #0x10
    //     0x130abe0: cmp             x1, x0
    //     0x130abe4: b.ls            #0x130acfc
    //     0x130abe8: str             x0, [THR, #0x60]  ; THR::top
    //     0x130abec: sub             x0, x0, #0xf
    //     0x130abf0: mov             x1, #0xe19c
    //     0x130abf4: movk            x1, #3, lsl #16
    //     0x130abf8: stur            x1, [x0, #-1]
    // 0x130abfc: dmb             ishst
    // 0x130ac00: StoreField: r0->field_7 = d0
    //     0x130ac00: stur            d0, [x0, #7]
    // 0x130ac04: mov             x3, x0
    // 0x130ac08: cmp             w3, NULL
    // 0x130ac0c: b.eq            #0x130ac1c
    // 0x130ac10: ldur            x1, [fp, #-0x48]
    // 0x130ac14: r2 = "top"
    //     0x130ac14: ldr             x2, [PP, #0x57d0]  ; [pp+0x57d0] "top"
    // 0x130ac18: r0 = []=()
    //     0x130ac18: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x130ac1c: ldur            x0, [fp, #-0x18]
    // 0x130ac20: LoadField: r1 = r0->field_b
    //     0x130ac20: ldur            w1, [x0, #0xb]
    // 0x130ac24: DecompressPointer r1
    //     0x130ac24: add             x1, x1, HEAP, lsl #32
    // 0x130ac28: LoadField: r2 = r0->field_7
    //     0x130ac28: ldur            w2, [x0, #7]
    // 0x130ac2c: DecompressPointer r2
    //     0x130ac2c: add             x2, x2, HEAP, lsl #32
    // 0x130ac30: r0 = encodeMessage()
    //     0x130ac30: bl              #0xd04fc0  ; [package:flutter/src/services/message_codecs.dart] StandardMessageCodec::encodeMessage
    // 0x130ac34: stur            x0, [fp, #-0x10]
    // 0x130ac38: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x130ac38: ldur            w1, [x0, #0x17]
    // 0x130ac3c: DecompressPointer r1
    //     0x130ac3c: add             x1, x1, HEAP, lsl #32
    // 0x130ac40: stur            x1, [fp, #-8]
    // 0x130ac44: r0 = _ByteBuffer()
    //     0x130ac44: bl              #0x7e9024  ; Allocate_ByteBufferStub -> _ByteBuffer (size=0xc)
    // 0x130ac48: mov             x1, x0
    // 0x130ac4c: ldur            x0, [fp, #-8]
    // 0x130ac50: StoreField: r1->field_7 = r0
    //     0x130ac50: stur            w0, [x1, #7]
    // 0x130ac54: ldur            x0, [fp, #-0x10]
    // 0x130ac58: LoadField: r2 = r0->field_13
    //     0x130ac58: ldur            w2, [x0, #0x13]
    // 0x130ac5c: stp             x2, xzr, [SP]
    // 0x130ac60: r4 = const [0, 0x3, 0x2, 0x3, null]
    //     0x130ac60: ldr             x4, [PP, #0x3870]  ; [pp+0x3870] List(5) [0, 0x3, 0x2, 0x3, Null]
    // 0x130ac64: r0 = asUint8List()
    //     0x130ac64: bl              #0x13d9b38  ; [dart:typed_data] _ByteBuffer::asUint8List
    // 0x130ac68: ldur            x1, [fp, #-0x48]
    // 0x130ac6c: mov             x3, x0
    // 0x130ac70: r2 = "params"
    //     0x130ac70: add             x2, PP, #0x8c, lsl #12  ; [pp+0x8ce30] "params"
    //     0x130ac74: ldr             x2, [x2, #0xe30]
    // 0x130ac78: r0 = []=()
    //     0x130ac78: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x130ac7c: r16 = Instance_MethodChannel
    //     0x130ac7c: add             x16, PP, #0x7d, lsl #12  ; [pp+0x7d3e8] Obj!MethodChannel@129bbe1
    //     0x130ac80: ldr             x16, [x16, #0x3e8]
    // 0x130ac84: stp             x16, NULL, [SP, #0x10]
    // 0x130ac88: r16 = "create"
    //     0x130ac88: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8ce38] "create"
    //     0x130ac8c: ldr             x16, [x16, #0xe38]
    // 0x130ac90: ldur            lr, [fp, #-0x48]
    // 0x130ac94: stp             lr, x16, [SP]
    // 0x130ac98: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x130ac98: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x130ac9c: r0 = invokeMethod()
    //     0x130ac9c: bl              #0x130b008  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0x130aca0: LeaveFrame
    //     0x130aca0: mov             SP, fp
    //     0x130aca4: ldp             fp, lr, [SP], #0x10
    // 0x130aca8: ret
    //     0x130aca8: ret             
    // 0x130acac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x130acac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x130acb0: b               #0x130a9cc
    // 0x130acb4: SaveReg d0
    //     0x130acb4: str             q0, [SP, #-0x10]!
    // 0x130acb8: SaveReg r0
    //     0x130acb8: str             x0, [SP, #-8]!
    // 0x130acbc: r0 = AllocateDouble()
    //     0x130acbc: bl              #0x13df878  ; AllocateDoubleStub
    // 0x130acc0: mov             x1, x0
    // 0x130acc4: RestoreReg r0
    //     0x130acc4: ldr             x0, [SP], #8
    // 0x130acc8: RestoreReg d0
    //     0x130acc8: ldr             q0, [SP], #0x10
    // 0x130accc: b               #0x130aad4
    // 0x130acd0: SaveReg d0
    //     0x130acd0: str             q0, [SP, #-0x10]!
    // 0x130acd4: r0 = AllocateDouble()
    //     0x130acd4: bl              #0x13df878  ; AllocateDoubleStub
    // 0x130acd8: RestoreReg d0
    //     0x130acd8: ldr             q0, [SP], #0x10
    // 0x130acdc: b               #0x130ab30
    // 0x130ace0: SaveReg d0
    //     0x130ace0: str             q0, [SP, #-0x10]!
    // 0x130ace4: SaveReg r0
    //     0x130ace4: str             x0, [SP, #-8]!
    // 0x130ace8: r0 = AllocateDouble()
    //     0x130ace8: bl              #0x13df878  ; AllocateDoubleStub
    // 0x130acec: mov             x1, x0
    // 0x130acf0: RestoreReg r0
    //     0x130acf0: ldr             x0, [SP], #8
    // 0x130acf4: RestoreReg d0
    //     0x130acf4: ldr             q0, [SP], #0x10
    // 0x130acf8: b               #0x130aba4
    // 0x130acfc: SaveReg d0
    //     0x130acfc: str             q0, [SP, #-0x10]!
    // 0x130ad00: r0 = AllocateDouble()
    //     0x130ad00: bl              #0x13df878  ; AllocateDoubleStub
    // 0x130ad04: RestoreReg d0
    //     0x130ad04: ldr             q0, [SP], #0x10
    // 0x130ad08: b               #0x130ac00
  }
}

// class id: 2760, size: 0x8, field offset: 0x8
class _HybridAndroidViewControllerInternals extends _AndroidViewControllerInternals {

  _ setOffset(/* No info */) {
    // ** addr: 0x130b420, size: 0x28
    // 0x130b420: EnterFrame
    //     0x130b420: stp             fp, lr, [SP, #-0x10]!
    //     0x130b424: mov             fp, SP
    // 0x130b428: r0 = UnimplementedError()
    //     0x130b428: bl              #0x7dd7c4  ; AllocateUnimplementedErrorStub -> UnimplementedError (size=0x10)
    // 0x130b42c: mov             x1, x0
    // 0x130b430: r0 = "Not supported for hybrid composition."
    //     0x130b430: add             x0, PP, #0xa1, lsl #12  ; [pp+0xa1700] "Not supported for hybrid composition."
    //     0x130b434: ldr             x0, [x0, #0x700]
    // 0x130b438: StoreField: r1->field_b = r0
    //     0x130b438: stur            w0, [x1, #0xb]
    // 0x130b43c: mov             x0, x1
    // 0x130b440: r0 = Throw()
    //     0x130b440: bl              #0x13ddb2c  ; ThrowStub
    // 0x130b444: brk             #0
  }
}

// class id: 2761, size: 0x10, field offset: 0x8
class _TextureAndroidViewControllerInternals extends _AndroidViewControllerInternals {

  _ setSize(/* No info */) async {
    // ** addr: 0x1309358, size: 0x25c
    // 0x1309358: EnterFrame
    //     0x1309358: stp             fp, lr, [SP, #-0x10]!
    //     0x130935c: mov             fp, SP
    // 0x1309360: AllocStack(0x48)
    //     0x1309360: sub             SP, SP, #0x48
    // 0x1309364: SetupParameters(_TextureAndroidViewControllerInternals this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */)
    //     0x1309364: stur            NULL, [fp, #-8]
    //     0x1309368: stur            x1, [fp, #-0x10]
    //     0x130936c: stur            x2, [fp, #-0x18]
    //     0x1309370: stur            x3, [fp, #-0x20]
    // 0x1309374: CheckStackOverflow
    //     0x1309374: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1309378: cmp             SP, x16
    //     0x130937c: b.ls            #0x130956c
    // 0x1309380: InitAsync() -> Future<Size>
    //     0x1309380: add             x0, PP, #0x15, lsl #12  ; [pp+0x15aa0] TypeArguments: <Size>
    //     0x1309384: ldr             x0, [x0, #0xaa0]
    //     0x1309388: bl              #0x7f5e44  ; InitAsyncStub
    // 0x130938c: r1 = Null
    //     0x130938c: mov             x1, NULL
    // 0x1309390: r2 = 12
    //     0x1309390: mov             x2, #0xc
    // 0x1309394: r0 = AllocateArray()
    //     0x1309394: bl              #0x13df928  ; AllocateArrayStub
    // 0x1309398: mov             x2, x0
    // 0x130939c: r16 = "id"
    //     0x130939c: ldr             x16, [PP, #0x7f88]  ; [pp+0x7f88] "id"
    // 0x13093a0: StoreField: r2->field_f = r16
    //     0x13093a0: stur            w16, [x2, #0xf]
    // 0x13093a4: ldur            x3, [fp, #-0x20]
    // 0x13093a8: r0 = BoxInt64Instr(r3)
    //     0x13093a8: sbfiz           x0, x3, #1, #0x1f
    //     0x13093ac: cmp             x3, x0, asr #1
    //     0x13093b0: b.eq            #0x13093bc
    //     0x13093b4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x13093b8: stur            x3, [x0, #7]
    // 0x13093bc: StoreField: r2->field_13 = r0
    //     0x13093bc: stur            w0, [x2, #0x13]
    // 0x13093c0: r16 = "width"
    //     0x13093c0: ldr             x16, [PP, #0x5a40]  ; [pp+0x5a40] "width"
    // 0x13093c4: ArrayStore: r2[0] = r16  ; List_4
    //     0x13093c4: stur            w16, [x2, #0x17]
    // 0x13093c8: ldur            x0, [fp, #-0x18]
    // 0x13093cc: LoadField: d0 = r0->field_7
    //     0x13093cc: ldur            d0, [x0, #7]
    // 0x13093d0: r1 = inline_Allocate_Double()
    //     0x13093d0: ldp             x1, x3, [THR, #0x60]  ; THR::top
    //     0x13093d4: add             x1, x1, #0x10
    //     0x13093d8: cmp             x3, x1
    //     0x13093dc: b.ls            #0x1309574
    //     0x13093e0: str             x1, [THR, #0x60]  ; THR::top
    //     0x13093e4: sub             x1, x1, #0xf
    //     0x13093e8: mov             x3, #0xe19c
    //     0x13093ec: movk            x3, #3, lsl #16
    //     0x13093f0: stur            x3, [x1, #-1]
    // 0x13093f4: dmb             ishst
    // 0x13093f8: StoreField: r1->field_7 = d0
    //     0x13093f8: stur            d0, [x1, #7]
    // 0x13093fc: StoreField: r2->field_1b = r1
    //     0x13093fc: stur            w1, [x2, #0x1b]
    // 0x1309400: r16 = "height"
    //     0x1309400: ldr             x16, [PP, #0x4ac8]  ; [pp+0x4ac8] "height"
    // 0x1309404: StoreField: r2->field_1f = r16
    //     0x1309404: stur            w16, [x2, #0x1f]
    // 0x1309408: LoadField: d0 = r0->field_f
    //     0x1309408: ldur            d0, [x0, #0xf]
    // 0x130940c: r0 = inline_Allocate_Double()
    //     0x130940c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x1309410: add             x0, x0, #0x10
    //     0x1309414: cmp             x1, x0
    //     0x1309418: b.ls            #0x1309590
    //     0x130941c: str             x0, [THR, #0x60]  ; THR::top
    //     0x1309420: sub             x0, x0, #0xf
    //     0x1309424: mov             x1, #0xe19c
    //     0x1309428: movk            x1, #3, lsl #16
    //     0x130942c: stur            x1, [x0, #-1]
    // 0x1309430: dmb             ishst
    // 0x1309434: StoreField: r0->field_7 = d0
    //     0x1309434: stur            d0, [x0, #7]
    // 0x1309438: StoreField: r2->field_23 = r0
    //     0x1309438: stur            w0, [x2, #0x23]
    // 0x130943c: r16 = <String, dynamic>
    //     0x130943c: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x1309440: stp             x2, x16, [SP]
    // 0x1309444: r0 = Map._fromLiteral()
    //     0x1309444: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x1309448: r16 = <Object?, Object?>
    //     0x1309448: ldr             x16, [PP, #0x4250]  ; [pp+0x4250] TypeArguments: <Object?, Object?>
    // 0x130944c: r30 = Instance_MethodChannel
    //     0x130944c: add             lr, PP, #0x7d, lsl #12  ; [pp+0x7d3e8] Obj!MethodChannel@129bbe1
    //     0x1309450: ldr             lr, [lr, #0x3e8]
    // 0x1309454: stp             lr, x16, [SP, #0x10]
    // 0x1309458: r16 = "resize"
    //     0x1309458: ldr             x16, [PP, #0x6c18]  ; [pp+0x6c18] "resize"
    // 0x130945c: stp             x0, x16, [SP]
    // 0x1309460: r4 = const [0x2, 0x3, 0x3, 0x3, null]
    //     0x1309460: ldr             x4, [PP, #0x3738]  ; [pp+0x3738] List(5) [0x2, 0x3, 0x3, 0x3, Null]
    // 0x1309464: r0 = invokeMapMethod()
    //     0x1309464: bl              #0x8492b0  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMapMethod
    // 0x1309468: mov             x1, x0
    // 0x130946c: stur            x1, [fp, #-0x18]
    // 0x1309470: r0 = Await()
    //     0x1309470: bl              #0x7f5c00  ; AwaitStub
    // 0x1309474: mov             x3, x0
    // 0x1309478: stur            x3, [fp, #-0x10]
    // 0x130947c: cmp             w3, NULL
    // 0x1309480: b.eq            #0x13095a8
    // 0x1309484: r0 = LoadClassIdInstr(r3)
    //     0x1309484: ldur            x0, [x3, #-1]
    //     0x1309488: ubfx            x0, x0, #0xc, #0x14
    // 0x130948c: mov             x1, x3
    // 0x1309490: r2 = "width"
    //     0x1309490: ldr             x2, [PP, #0x5a40]  ; [pp+0x5a40] "width"
    // 0x1309494: r0 = GDT[cid_x0 + -0xd48]()
    //     0x1309494: sub             lr, x0, #0xd48
    //     0x1309498: ldr             lr, [x21, lr, lsl #3]
    //     0x130949c: blr             lr
    // 0x13094a0: mov             x3, x0
    // 0x13094a4: stur            x3, [fp, #-0x18]
    // 0x13094a8: cmp             w3, NULL
    // 0x13094ac: b.eq            #0x13095ac
    // 0x13094b0: mov             x0, x3
    // 0x13094b4: r2 = Null
    //     0x13094b4: mov             x2, NULL
    // 0x13094b8: r1 = Null
    //     0x13094b8: mov             x1, NULL
    // 0x13094bc: r4 = 60
    //     0x13094bc: mov             x4, #0x3c
    // 0x13094c0: branchIfSmi(r0, 0x13094cc)
    //     0x13094c0: tbz             w0, #0, #0x13094cc
    // 0x13094c4: r4 = LoadClassIdInstr(r0)
    //     0x13094c4: ldur            x4, [x0, #-1]
    //     0x13094c8: ubfx            x4, x4, #0xc, #0x14
    // 0x13094cc: cmp             x4, #0x3e
    // 0x13094d0: b.eq            #0x13094e4
    // 0x13094d4: r8 = double
    //     0x13094d4: ldr             x8, [PP, #0x6e90]  ; [pp+0x6e90] Type: double
    // 0x13094d8: r3 = Null
    //     0x13094d8: add             x3, PP, #0xb0, lsl #12  ; [pp+0xb09a0] Null
    //     0x13094dc: ldr             x3, [x3, #0x9a0]
    // 0x13094e0: r0 = double()
    //     0x13094e0: bl              #0x13ee3d0  ; IsType_double_Stub
    // 0x13094e4: ldur            x1, [fp, #-0x10]
    // 0x13094e8: r0 = LoadClassIdInstr(r1)
    //     0x13094e8: ldur            x0, [x1, #-1]
    //     0x13094ec: ubfx            x0, x0, #0xc, #0x14
    // 0x13094f0: r2 = "height"
    //     0x13094f0: ldr             x2, [PP, #0x4ac8]  ; [pp+0x4ac8] "height"
    // 0x13094f4: r0 = GDT[cid_x0 + -0xd48]()
    //     0x13094f4: sub             lr, x0, #0xd48
    //     0x13094f8: ldr             lr, [x21, lr, lsl #3]
    //     0x13094fc: blr             lr
    // 0x1309500: mov             x3, x0
    // 0x1309504: stur            x3, [fp, #-0x10]
    // 0x1309508: cmp             w3, NULL
    // 0x130950c: b.eq            #0x13095b0
    // 0x1309510: mov             x0, x3
    // 0x1309514: r2 = Null
    //     0x1309514: mov             x2, NULL
    // 0x1309518: r1 = Null
    //     0x1309518: mov             x1, NULL
    // 0x130951c: r4 = 60
    //     0x130951c: mov             x4, #0x3c
    // 0x1309520: branchIfSmi(r0, 0x130952c)
    //     0x1309520: tbz             w0, #0, #0x130952c
    // 0x1309524: r4 = LoadClassIdInstr(r0)
    //     0x1309524: ldur            x4, [x0, #-1]
    //     0x1309528: ubfx            x4, x4, #0xc, #0x14
    // 0x130952c: cmp             x4, #0x3e
    // 0x1309530: b.eq            #0x1309544
    // 0x1309534: r8 = double
    //     0x1309534: ldr             x8, [PP, #0x6e90]  ; [pp+0x6e90] Type: double
    // 0x1309538: r3 = Null
    //     0x1309538: add             x3, PP, #0xb0, lsl #12  ; [pp+0xb09b0] Null
    //     0x130953c: ldr             x3, [x3, #0x9b0]
    // 0x1309540: r0 = double()
    //     0x1309540: bl              #0x13ee3d0  ; IsType_double_Stub
    // 0x1309544: ldur            x0, [fp, #-0x18]
    // 0x1309548: LoadField: d0 = r0->field_7
    //     0x1309548: ldur            d0, [x0, #7]
    // 0x130954c: stur            d0, [fp, #-0x28]
    // 0x1309550: r0 = Size()
    //     0x1309550: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x1309554: ldur            d0, [fp, #-0x28]
    // 0x1309558: StoreField: r0->field_7 = d0
    //     0x1309558: stur            d0, [x0, #7]
    // 0x130955c: ldur            x1, [fp, #-0x10]
    // 0x1309560: LoadField: d0 = r1->field_7
    //     0x1309560: ldur            d0, [x1, #7]
    // 0x1309564: StoreField: r0->field_f = d0
    //     0x1309564: stur            d0, [x0, #0xf]
    // 0x1309568: r0 = ReturnAsyncNotFuture()
    //     0x1309568: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x130956c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x130956c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1309570: b               #0x1309380
    // 0x1309574: SaveReg d0
    //     0x1309574: str             q0, [SP, #-0x10]!
    // 0x1309578: stp             x0, x2, [SP, #-0x10]!
    // 0x130957c: r0 = AllocateDouble()
    //     0x130957c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1309580: mov             x1, x0
    // 0x1309584: ldp             x0, x2, [SP], #0x10
    // 0x1309588: RestoreReg d0
    //     0x1309588: ldr             q0, [SP], #0x10
    // 0x130958c: b               #0x13093f8
    // 0x1309590: SaveReg d0
    //     0x1309590: str             q0, [SP, #-0x10]!
    // 0x1309594: SaveReg r2
    //     0x1309594: str             x2, [SP, #-8]!
    // 0x1309598: r0 = AllocateDouble()
    //     0x1309598: bl              #0x13df878  ; AllocateDoubleStub
    // 0x130959c: RestoreReg r2
    //     0x130959c: ldr             x2, [SP], #8
    // 0x13095a0: RestoreReg d0
    //     0x13095a0: ldr             q0, [SP], #0x10
    // 0x13095a4: b               #0x1309434
    // 0x13095a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x13095a8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x13095ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x13095ac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x13095b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x13095b0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ setOffset(/* No info */) async {
    // ** addr: 0x130b244, size: 0x1dc
    // 0x130b244: EnterFrame
    //     0x130b244: stp             fp, lr, [SP, #-0x10]!
    //     0x130b248: mov             fp, SP
    // 0x130b24c: AllocStack(0x48)
    //     0x130b24c: sub             SP, SP, #0x48
    // 0x130b250: SetupParameters(_TextureAndroidViewControllerInternals this /* r1 => r2, fp-0x20 */, dynamic _ /* r2 => r1, fp-0x28 */)
    //     0x130b250: stur            NULL, [fp, #-8]
    //     0x130b254: stur            x1, [fp, #-0x10]
    //     0x130b258: mov             x16, x2
    //     0x130b25c: mov             x2, x1
    //     0x130b260: mov             x1, x16
    //     0x130b264: stur            x1, [fp, #-0x18]
    //     0x130b268: stur            x3, [fp, #-0x20]
    //     0x130b26c: stur            x5, [fp, #-0x28]
    // 0x130b270: CheckStackOverflow
    //     0x130b270: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x130b274: cmp             SP, x16
    //     0x130b278: b.ls            #0x130b3e4
    // 0x130b27c: InitAsync() -> Future<void?>
    //     0x130b27c: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0x130b280: bl              #0x7f5e44  ; InitAsyncStub
    // 0x130b284: ldur            x0, [fp, #-0x10]
    // 0x130b288: LoadField: r1 = r0->field_7
    //     0x130b288: ldur            w1, [x0, #7]
    // 0x130b28c: DecompressPointer r1
    //     0x130b28c: add             x1, x1, HEAP, lsl #32
    // 0x130b290: ldur            x16, [fp, #-0x18]
    // 0x130b294: stp             x1, x16, [SP]
    // 0x130b298: r0 = ==()
    //     0x130b298: bl              #0x128bd28  ; [dart:ui] Offset::==
    // 0x130b29c: tbnz            w0, #4, #0x130b2a8
    // 0x130b2a0: r0 = Null
    //     0x130b2a0: mov             x0, NULL
    // 0x130b2a4: r0 = ReturnAsyncNotFuture()
    //     0x130b2a4: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x130b2a8: ldur            x0, [fp, #-0x28]
    // 0x130b2ac: r16 = Instance__AndroidViewState
    //     0x130b2ac: add             x16, PP, #0x7d, lsl #12  ; [pp+0x7d3a8] Obj!_AndroidViewState@12c3d61
    //     0x130b2b0: ldr             x16, [x16, #0x3a8]
    // 0x130b2b4: cmp             w0, w16
    // 0x130b2b8: b.eq            #0x130b2c4
    // 0x130b2bc: r0 = Null
    //     0x130b2bc: mov             x0, NULL
    // 0x130b2c0: r0 = ReturnAsyncNotFuture()
    //     0x130b2c0: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x130b2c4: ldur            x1, [fp, #-0x10]
    // 0x130b2c8: ldur            x4, [fp, #-0x18]
    // 0x130b2cc: ldur            x3, [fp, #-0x20]
    // 0x130b2d0: mov             x0, x4
    // 0x130b2d4: StoreField: r1->field_7 = r0
    //     0x130b2d4: stur            w0, [x1, #7]
    //     0x130b2d8: ldurb           w16, [x1, #-1]
    //     0x130b2dc: ldurb           w17, [x0, #-1]
    //     0x130b2e0: and             x16, x17, x16, lsr #2
    //     0x130b2e4: tst             x16, HEAP, lsr #32
    //     0x130b2e8: b.eq            #0x130b2f0
    //     0x130b2ec: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x130b2f0: r1 = Null
    //     0x130b2f0: mov             x1, NULL
    // 0x130b2f4: r2 = 12
    //     0x130b2f4: mov             x2, #0xc
    // 0x130b2f8: r0 = AllocateArray()
    //     0x130b2f8: bl              #0x13df928  ; AllocateArrayStub
    // 0x130b2fc: mov             x2, x0
    // 0x130b300: r16 = "id"
    //     0x130b300: ldr             x16, [PP, #0x7f88]  ; [pp+0x7f88] "id"
    // 0x130b304: StoreField: r2->field_f = r16
    //     0x130b304: stur            w16, [x2, #0xf]
    // 0x130b308: ldur            x3, [fp, #-0x20]
    // 0x130b30c: r0 = BoxInt64Instr(r3)
    //     0x130b30c: sbfiz           x0, x3, #1, #0x1f
    //     0x130b310: cmp             x3, x0, asr #1
    //     0x130b314: b.eq            #0x130b320
    //     0x130b318: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x130b31c: stur            x3, [x0, #7]
    // 0x130b320: StoreField: r2->field_13 = r0
    //     0x130b320: stur            w0, [x2, #0x13]
    // 0x130b324: r16 = "top"
    //     0x130b324: ldr             x16, [PP, #0x57d0]  ; [pp+0x57d0] "top"
    // 0x130b328: ArrayStore: r2[0] = r16  ; List_4
    //     0x130b328: stur            w16, [x2, #0x17]
    // 0x130b32c: ldur            x0, [fp, #-0x18]
    // 0x130b330: LoadField: d0 = r0->field_f
    //     0x130b330: ldur            d0, [x0, #0xf]
    // 0x130b334: r1 = inline_Allocate_Double()
    //     0x130b334: ldp             x1, x3, [THR, #0x60]  ; THR::top
    //     0x130b338: add             x1, x1, #0x10
    //     0x130b33c: cmp             x3, x1
    //     0x130b340: b.ls            #0x130b3ec
    //     0x130b344: str             x1, [THR, #0x60]  ; THR::top
    //     0x130b348: sub             x1, x1, #0xf
    //     0x130b34c: mov             x3, #0xe19c
    //     0x130b350: movk            x3, #3, lsl #16
    //     0x130b354: stur            x3, [x1, #-1]
    // 0x130b358: dmb             ishst
    // 0x130b35c: StoreField: r1->field_7 = d0
    //     0x130b35c: stur            d0, [x1, #7]
    // 0x130b360: StoreField: r2->field_1b = r1
    //     0x130b360: stur            w1, [x2, #0x1b]
    // 0x130b364: r16 = "left"
    //     0x130b364: ldr             x16, [PP, #0x57c0]  ; [pp+0x57c0] "left"
    // 0x130b368: StoreField: r2->field_1f = r16
    //     0x130b368: stur            w16, [x2, #0x1f]
    // 0x130b36c: LoadField: d0 = r0->field_7
    //     0x130b36c: ldur            d0, [x0, #7]
    // 0x130b370: r0 = inline_Allocate_Double()
    //     0x130b370: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x130b374: add             x0, x0, #0x10
    //     0x130b378: cmp             x1, x0
    //     0x130b37c: b.ls            #0x130b408
    //     0x130b380: str             x0, [THR, #0x60]  ; THR::top
    //     0x130b384: sub             x0, x0, #0xf
    //     0x130b388: mov             x1, #0xe19c
    //     0x130b38c: movk            x1, #3, lsl #16
    //     0x130b390: stur            x1, [x0, #-1]
    // 0x130b394: dmb             ishst
    // 0x130b398: StoreField: r0->field_7 = d0
    //     0x130b398: stur            d0, [x0, #7]
    // 0x130b39c: StoreField: r2->field_23 = r0
    //     0x130b39c: stur            w0, [x2, #0x23]
    // 0x130b3a0: r16 = <String, dynamic>
    //     0x130b3a0: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x130b3a4: stp             x2, x16, [SP]
    // 0x130b3a8: r0 = Map._fromLiteral()
    //     0x130b3a8: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x130b3ac: r16 = <void?>
    //     0x130b3ac: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x130b3b0: r30 = Instance_MethodChannel
    //     0x130b3b0: add             lr, PP, #0x7d, lsl #12  ; [pp+0x7d3e8] Obj!MethodChannel@129bbe1
    //     0x130b3b4: ldr             lr, [lr, #0x3e8]
    // 0x130b3b8: stp             lr, x16, [SP, #0x10]
    // 0x130b3bc: r16 = "offset"
    //     0x130b3bc: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f818] "offset"
    //     0x130b3c0: ldr             x16, [x16, #0x818]
    // 0x130b3c4: stp             x0, x16, [SP]
    // 0x130b3c8: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x130b3c8: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x130b3cc: r0 = invokeMethod()
    //     0x130b3cc: bl              #0x130b008  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0x130b3d0: mov             x1, x0
    // 0x130b3d4: stur            x1, [fp, #-0x10]
    // 0x130b3d8: r0 = Await()
    //     0x130b3d8: bl              #0x7f5c00  ; AwaitStub
    // 0x130b3dc: r0 = Null
    //     0x130b3dc: mov             x0, NULL
    // 0x130b3e0: r0 = ReturnAsyncNotFuture()
    //     0x130b3e0: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x130b3e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x130b3e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x130b3e8: b               #0x130b27c
    // 0x130b3ec: SaveReg d0
    //     0x130b3ec: str             q0, [SP, #-0x10]!
    // 0x130b3f0: stp             x0, x2, [SP, #-0x10]!
    // 0x130b3f4: r0 = AllocateDouble()
    //     0x130b3f4: bl              #0x13df878  ; AllocateDoubleStub
    // 0x130b3f8: mov             x1, x0
    // 0x130b3fc: ldp             x0, x2, [SP], #0x10
    // 0x130b400: RestoreReg d0
    //     0x130b400: ldr             q0, [SP], #0x10
    // 0x130b404: b               #0x130b35c
    // 0x130b408: SaveReg d0
    //     0x130b408: str             q0, [SP, #-0x10]!
    // 0x130b40c: SaveReg r2
    //     0x130b40c: str             x2, [SP, #-8]!
    // 0x130b410: r0 = AllocateDouble()
    //     0x130b410: bl              #0x13df878  ; AllocateDoubleStub
    // 0x130b414: RestoreReg r2
    //     0x130b414: ldr             x2, [SP], #8
    // 0x130b418: RestoreReg d0
    //     0x130b418: ldr             q0, [SP], #0x10
    // 0x130b41c: b               #0x130b398
  }
}

// class id: 2762, size: 0x8, field offset: 0x8
abstract class PlatformViewController extends Object {
}

// class id: 2763, size: 0x28, field offset: 0x8
abstract class AndroidViewController extends PlatformViewController {

  [closure] Future<void> dispatchPointerEvent(dynamic, PointerEvent) {
    // ** addr: 0xba31f4, size: 0x3c
    // 0xba31f4: EnterFrame
    //     0xba31f4: stp             fp, lr, [SP, #-0x10]!
    //     0xba31f8: mov             fp, SP
    // 0xba31fc: ldr             x0, [fp, #0x18]
    // 0xba3200: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xba3200: ldur            w1, [x0, #0x17]
    // 0xba3204: DecompressPointer r1
    //     0xba3204: add             x1, x1, HEAP, lsl #32
    // 0xba3208: CheckStackOverflow
    //     0xba3208: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba320c: cmp             SP, x16
    //     0xba3210: b.ls            #0xba3228
    // 0xba3214: ldr             x2, [fp, #0x10]
    // 0xba3218: r0 = dispatchPointerEvent()
    //     0xba3218: bl              #0xba3230  ; [package:flutter/src/services/platform_views.dart] AndroidViewController::dispatchPointerEvent
    // 0xba321c: LeaveFrame
    //     0xba321c: mov             SP, fp
    //     0xba3220: ldp             fp, lr, [SP], #0x10
    // 0xba3224: ret
    //     0xba3224: ret             
    // 0xba3228: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba3228: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba322c: b               #0xba3214
  }
  _ dispatchPointerEvent(/* No info */) async {
    // ** addr: 0xba3230, size: 0x1f0
    // 0xba3230: EnterFrame
    //     0xba3230: stp             fp, lr, [SP, #-0x10]!
    //     0xba3234: mov             fp, SP
    // 0xba3238: AllocStack(0x28)
    //     0xba3238: sub             SP, SP, #0x28
    // 0xba323c: SetupParameters(AndroidViewController this /* r1 => r2, fp-0x10 */, dynamic _ /* r2 => r1, fp-0x18 */)
    //     0xba323c: stur            NULL, [fp, #-8]
    //     0xba3240: stur            x1, [fp, #-0x10]
    //     0xba3244: mov             x16, x2
    //     0xba3248: mov             x2, x1
    //     0xba324c: mov             x1, x16
    //     0xba3250: stur            x1, [fp, #-0x18]
    // 0xba3254: CheckStackOverflow
    //     0xba3254: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba3258: cmp             SP, x16
    //     0xba325c: b.ls            #0xba3418
    // 0xba3260: InitAsync() -> Future<void?>
    //     0xba3260: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0xba3264: bl              #0x7f5e44  ; InitAsyncStub
    // 0xba3268: ldur            x0, [fp, #-0x18]
    // 0xba326c: r2 = Null
    //     0xba326c: mov             x2, NULL
    // 0xba3270: r1 = Null
    //     0xba3270: mov             x1, NULL
    // 0xba3274: cmp             w0, NULL
    // 0xba3278: b.eq            #0xba32a0
    // 0xba327c: branchIfSmi(r0, 0xba32a0)
    //     0xba327c: tbz             w0, #0, #0xba32a0
    // 0xba3280: r3 = LoadClassIdInstr(r0)
    //     0xba3280: ldur            x3, [x0, #-1]
    //     0xba3284: ubfx            x3, x3, #0xc, #0x14
    // 0xba3288: r17 = 4165
    //     0xba3288: mov             x17, #0x1045
    // 0xba328c: cmp             x3, x17
    // 0xba3290: b.eq            #0xba32a8
    // 0xba3294: r17 = 5294
    //     0xba3294: mov             x17, #0x14ae
    // 0xba3298: cmp             x3, x17
    // 0xba329c: b.eq            #0xba32a8
    // 0xba32a0: r0 = false
    //     0xba32a0: add             x0, NULL, #0x30  ; false
    // 0xba32a4: b               #0xba32ac
    // 0xba32a8: r0 = true
    //     0xba32a8: add             x0, NULL, #0x20  ; true
    // 0xba32ac: tbnz            w0, #4, #0xba32b8
    // 0xba32b0: r0 = Null
    //     0xba32b0: mov             x0, NULL
    // 0xba32b4: r0 = ReturnAsyncNotFuture()
    //     0xba32b4: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xba32b8: ldur            x0, [fp, #-0x18]
    // 0xba32bc: r2 = Null
    //     0xba32bc: mov             x2, NULL
    // 0xba32c0: r1 = Null
    //     0xba32c0: mov             x1, NULL
    // 0xba32c4: cmp             w0, NULL
    // 0xba32c8: b.eq            #0xba32f0
    // 0xba32cc: branchIfSmi(r0, 0xba32f0)
    //     0xba32cc: tbz             w0, #0, #0xba32f0
    // 0xba32d0: r3 = LoadClassIdInstr(r0)
    //     0xba32d0: ldur            x3, [x0, #-1]
    //     0xba32d4: ubfx            x3, x3, #0xc, #0x14
    // 0xba32d8: r17 = 4159
    //     0xba32d8: mov             x17, #0x103f
    // 0xba32dc: cmp             x3, x17
    // 0xba32e0: b.eq            #0xba32f8
    // 0xba32e4: r17 = 5288
    //     0xba32e4: mov             x17, #0x14a8
    // 0xba32e8: cmp             x3, x17
    // 0xba32ec: b.eq            #0xba32f8
    // 0xba32f0: r0 = false
    //     0xba32f0: add             x0, NULL, #0x30  ; false
    // 0xba32f4: b               #0xba32fc
    // 0xba32f8: r0 = true
    //     0xba32f8: add             x0, NULL, #0x20  ; true
    // 0xba32fc: tbnz            w0, #4, #0xba3314
    // 0xba3300: ldur            x0, [fp, #-0x10]
    // 0xba3304: LoadField: r1 = r0->field_13
    //     0xba3304: ldur            w1, [x0, #0x13]
    // 0xba3308: DecompressPointer r1
    //     0xba3308: add             x1, x1, HEAP, lsl #32
    // 0xba330c: ldur            x2, [fp, #-0x18]
    // 0xba3310: r0 = handlePointerDownEvent()
    //     0xba3310: bl              #0xba4db0  ; [package:flutter/src/services/platform_views.dart] _AndroidMotionEventConverter::handlePointerDownEvent
    // 0xba3314: ldur            x0, [fp, #-0x10]
    // 0xba3318: LoadField: r3 = r0->field_13
    //     0xba3318: ldur            w3, [x0, #0x13]
    // 0xba331c: DecompressPointer r3
    //     0xba331c: add             x3, x3, HEAP, lsl #32
    // 0xba3320: mov             x1, x3
    // 0xba3324: ldur            x2, [fp, #-0x18]
    // 0xba3328: stur            x3, [fp, #-0x20]
    // 0xba332c: r0 = updatePointerPositions()
    //     0xba332c: bl              #0xba4b38  ; [package:flutter/src/services/platform_views.dart] _AndroidMotionEventConverter::updatePointerPositions
    // 0xba3330: ldur            x1, [fp, #-0x20]
    // 0xba3334: ldur            x2, [fp, #-0x18]
    // 0xba3338: r0 = toAndroidMotionEvent()
    //     0xba3338: bl              #0xba4228  ; [package:flutter/src/services/platform_views.dart] _AndroidMotionEventConverter::toAndroidMotionEvent
    // 0xba333c: mov             x3, x0
    // 0xba3340: ldur            x0, [fp, #-0x18]
    // 0xba3344: r2 = Null
    //     0xba3344: mov             x2, NULL
    // 0xba3348: r1 = Null
    //     0xba3348: mov             x1, NULL
    // 0xba334c: stur            x3, [fp, #-0x28]
    // 0xba3350: cmp             w0, NULL
    // 0xba3354: b.eq            #0xba337c
    // 0xba3358: branchIfSmi(r0, 0xba337c)
    //     0xba3358: tbz             w0, #0, #0xba337c
    // 0xba335c: r3 = LoadClassIdInstr(r0)
    //     0xba335c: ldur            x3, [x0, #-1]
    //     0xba3360: ubfx            x3, x3, #0xc, #0x14
    // 0xba3364: r17 = 4155
    //     0xba3364: mov             x17, #0x103b
    // 0xba3368: cmp             x3, x17
    // 0xba336c: b.eq            #0xba3384
    // 0xba3370: r17 = 5284
    //     0xba3370: mov             x17, #0x14a4
    // 0xba3374: cmp             x3, x17
    // 0xba3378: b.eq            #0xba3384
    // 0xba337c: r0 = false
    //     0xba337c: add             x0, NULL, #0x30  ; false
    // 0xba3380: b               #0xba3388
    // 0xba3384: r0 = true
    //     0xba3384: add             x0, NULL, #0x20  ; true
    // 0xba3388: tbnz            w0, #4, #0xba339c
    // 0xba338c: ldur            x1, [fp, #-0x20]
    // 0xba3390: ldur            x2, [fp, #-0x18]
    // 0xba3394: r0 = handlePointerUpEvent()
    //     0xba3394: bl              #0xba40c0  ; [package:flutter/src/services/platform_views.dart] _AndroidMotionEventConverter::handlePointerUpEvent
    // 0xba3398: b               #0xba33f0
    // 0xba339c: ldur            x0, [fp, #-0x18]
    // 0xba33a0: r2 = Null
    //     0xba33a0: mov             x2, NULL
    // 0xba33a4: r1 = Null
    //     0xba33a4: mov             x1, NULL
    // 0xba33a8: cmp             w0, NULL
    // 0xba33ac: b.eq            #0xba33d4
    // 0xba33b0: branchIfSmi(r0, 0xba33d4)
    //     0xba33b0: tbz             w0, #0, #0xba33d4
    // 0xba33b4: r3 = LoadClassIdInstr(r0)
    //     0xba33b4: ldur            x3, [x0, #-1]
    //     0xba33b8: ubfx            x3, x3, #0xc, #0x14
    // 0xba33bc: r17 = 4139
    //     0xba33bc: mov             x17, #0x102b
    // 0xba33c0: cmp             x3, x17
    // 0xba33c4: b.eq            #0xba33dc
    // 0xba33c8: r17 = 5276
    //     0xba33c8: mov             x17, #0x149c
    // 0xba33cc: cmp             x3, x17
    // 0xba33d0: b.eq            #0xba33dc
    // 0xba33d4: r0 = false
    //     0xba33d4: add             x0, NULL, #0x30  ; false
    // 0xba33d8: b               #0xba33e0
    // 0xba33dc: r0 = true
    //     0xba33dc: add             x0, NULL, #0x20  ; true
    // 0xba33e0: tbnz            w0, #4, #0xba33f0
    // 0xba33e4: ldur            x1, [fp, #-0x20]
    // 0xba33e8: ldur            x2, [fp, #-0x18]
    // 0xba33ec: r0 = handlePointerUpEvent()
    //     0xba33ec: bl              #0xba40c0  ; [package:flutter/src/services/platform_views.dart] _AndroidMotionEventConverter::handlePointerUpEvent
    // 0xba33f0: ldur            x2, [fp, #-0x28]
    // 0xba33f4: cmp             w2, NULL
    // 0xba33f8: b.eq            #0xba3410
    // 0xba33fc: ldur            x1, [fp, #-0x10]
    // 0xba3400: r0 = sendMotionEvent()
    //     0xba3400: bl              #0xba3420  ; [package:flutter/src/services/platform_views.dart] AndroidViewController::sendMotionEvent
    // 0xba3404: mov             x1, x0
    // 0xba3408: stur            x1, [fp, #-0x10]
    // 0xba340c: r0 = Await()
    //     0xba340c: bl              #0x7f5c00  ; AwaitStub
    // 0xba3410: r0 = Null
    //     0xba3410: mov             x0, NULL
    // 0xba3414: r0 = ReturnAsyncNotFuture()
    //     0xba3414: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xba3418: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba3418: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba341c: b               #0xba3260
  }
  _ sendMotionEvent(/* No info */) async {
    // ** addr: 0xba3420, size: 0x84
    // 0xba3420: EnterFrame
    //     0xba3420: stp             fp, lr, [SP, #-0x10]!
    //     0xba3424: mov             fp, SP
    // 0xba3428: AllocStack(0x38)
    //     0xba3428: sub             SP, SP, #0x38
    // 0xba342c: SetupParameters(AndroidViewController this /* r1 => r2, fp-0x10 */, dynamic _ /* r2 => r1, fp-0x18 */)
    //     0xba342c: stur            NULL, [fp, #-8]
    //     0xba3430: stur            x1, [fp, #-0x10]
    //     0xba3434: mov             x16, x2
    //     0xba3438: mov             x2, x1
    //     0xba343c: mov             x1, x16
    //     0xba3440: stur            x1, [fp, #-0x18]
    // 0xba3444: CheckStackOverflow
    //     0xba3444: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba3448: cmp             SP, x16
    //     0xba344c: b.ls            #0xba349c
    // 0xba3450: InitAsync() -> Future<void?>
    //     0xba3450: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0xba3454: bl              #0x7f5e44  ; InitAsyncStub
    // 0xba3458: ldur            x0, [fp, #-0x10]
    // 0xba345c: LoadField: r2 = r0->field_7
    //     0xba345c: ldur            x2, [x0, #7]
    // 0xba3460: ldur            x1, [fp, #-0x18]
    // 0xba3464: r0 = _asList()
    //     0xba3464: bl              #0xba34a4  ; [package:flutter/src/services/platform_views.dart] AndroidMotionEvent::_asList
    // 0xba3468: r16 = Instance_MethodChannel
    //     0xba3468: add             x16, PP, #0x7d, lsl #12  ; [pp+0x7d3e8] Obj!MethodChannel@129bbe1
    //     0xba346c: ldr             x16, [x16, #0x3e8]
    // 0xba3470: stp             x16, NULL, [SP, #0x10]
    // 0xba3474: r16 = "touch"
    //     0xba3474: add             x16, PP, #0xa1, lsl #12  ; [pp+0xa1710] "touch"
    //     0xba3478: ldr             x16, [x16, #0x710]
    // 0xba347c: stp             x0, x16, [SP]
    // 0xba3480: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xba3480: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xba3484: r0 = invokeMethod()
    //     0xba3484: bl              #0x130b008  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xba3488: mov             x1, x0
    // 0xba348c: stur            x1, [fp, #-0x10]
    // 0xba3490: r0 = Await()
    //     0xba3490: bl              #0x7f5c00  ; AwaitStub
    // 0xba3494: r0 = Null
    //     0xba3494: mov             x0, NULL
    // 0xba3498: r0 = ReturnAsyncNotFuture()
    //     0xba3498: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xba349c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba349c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba34a0: b               #0xba3450
  }
  _ removeOnPlatformViewCreatedListener(/* No info */) {
    // ** addr: 0xc036c0, size: 0x3c
    // 0xc036c0: EnterFrame
    //     0xc036c0: stp             fp, lr, [SP, #-0x10]!
    //     0xc036c4: mov             fp, SP
    // 0xc036c8: CheckStackOverflow
    //     0xc036c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc036cc: cmp             SP, x16
    //     0xc036d0: b.ls            #0xc036f4
    // 0xc036d4: LoadField: r0 = r1->field_23
    //     0xc036d4: ldur            w0, [x1, #0x23]
    // 0xc036d8: DecompressPointer r0
    //     0xc036d8: add             x0, x0, HEAP, lsl #32
    // 0xc036dc: mov             x1, x0
    // 0xc036e0: r0 = remove()
    //     0xc036e0: bl              #0xa10a64  ; [dart:core] _GrowableList::remove
    // 0xc036e4: r0 = Null
    //     0xc036e4: mov             x0, NULL
    // 0xc036e8: LeaveFrame
    //     0xc036e8: mov             SP, fp
    //     0xc036ec: ldp             fp, lr, [SP], #0x10
    // 0xc036f0: ret
    //     0xc036f0: ret             
    // 0xc036f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc036f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc036f8: b               #0xc036d4
  }
  _ setSize(/* No info */) async {
    // ** addr: 0xccf3b0, size: 0x108
    // 0xccf3b0: EnterFrame
    //     0xccf3b0: stp             fp, lr, [SP, #-0x10]!
    //     0xccf3b4: mov             fp, SP
    // 0xccf3b8: AllocStack(0x28)
    //     0xccf3b8: sub             SP, SP, #0x28
    // 0xccf3bc: SetupParameters(AndroidViewController this /* r1 => r2, fp-0x10 */, dynamic _ /* r2 => r1, fp-0x18 */)
    //     0xccf3bc: stur            NULL, [fp, #-8]
    //     0xccf3c0: stur            x1, [fp, #-0x10]
    //     0xccf3c4: mov             x16, x2
    //     0xccf3c8: mov             x2, x1
    //     0xccf3cc: mov             x1, x16
    //     0xccf3d0: stur            x1, [fp, #-0x18]
    // 0xccf3d4: CheckStackOverflow
    //     0xccf3d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xccf3d8: cmp             SP, x16
    //     0xccf3dc: b.ls            #0xccf4b0
    // 0xccf3e0: InitAsync() -> Future<Size>
    //     0xccf3e0: add             x0, PP, #0x15, lsl #12  ; [pp+0x15aa0] TypeArguments: <Size>
    //     0xccf3e4: ldr             x0, [x0, #0xaa0]
    //     0xccf3e8: bl              #0x7f5e44  ; InitAsyncStub
    // 0xccf3ec: ldur            x1, [fp, #-0x10]
    // 0xccf3f0: LoadField: r0 = r1->field_1b
    //     0xccf3f0: ldur            w0, [x1, #0x1b]
    // 0xccf3f4: DecompressPointer r0
    //     0xccf3f4: add             x0, x0, HEAP, lsl #32
    // 0xccf3f8: r16 = Instance__AndroidViewState
    //     0xccf3f8: add             x16, PP, #0x7d, lsl #12  ; [pp+0x7d3c0] Obj!_AndroidViewState@12c3da1
    //     0xccf3fc: ldr             x16, [x16, #0x3c0]
    // 0xccf400: cmp             w0, w16
    // 0xccf404: b.ne            #0xccf430
    // 0xccf408: ldur            x16, [fp, #-0x18]
    // 0xccf40c: str             x16, [SP]
    // 0xccf410: r4 = const [0, 0x2, 0x1, 0x1, size, 0x1, null]
    //     0xccf410: add             x4, PP, #0x89, lsl #12  ; [pp+0x89e60] List(7) [0, 0x2, 0x1, 0x1, "size", 0x1, Null]
    //     0xccf414: ldr             x4, [x4, #0xe60]
    // 0xccf418: r0 = create()
    //     0xccf418: bl              #0xccf4b8  ; [package:flutter/src/services/platform_views.dart] AndroidViewController::create
    // 0xccf41c: mov             x1, x0
    // 0xccf420: stur            x1, [fp, #-0x20]
    // 0xccf424: r0 = Await()
    //     0xccf424: bl              #0x7f5c00  ; AwaitStub
    // 0xccf428: ldur            x0, [fp, #-0x18]
    // 0xccf42c: r0 = ReturnAsyncNotFuture()
    //     0xccf42c: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xccf430: r0 = LoadClassIdInstr(r1)
    //     0xccf430: ldur            x0, [x1, #-1]
    //     0xccf434: ubfx            x0, x0, #0xc, #0x14
    // 0xccf438: cmp             x0, #0xacc
    // 0xccf43c: b.eq            #0xccf484
    // 0xccf440: LoadField: r0 = r1->field_27
    //     0xccf440: ldur            w0, [x1, #0x27]
    // 0xccf444: DecompressPointer r0
    //     0xccf444: add             x0, x0, HEAP, lsl #32
    // 0xccf448: LoadField: r3 = r1->field_7
    //     0xccf448: ldur            x3, [x1, #7]
    // 0xccf44c: r1 = LoadClassIdInstr(r0)
    //     0xccf44c: ldur            x1, [x0, #-1]
    //     0xccf450: ubfx            x1, x1, #0xc, #0x14
    // 0xccf454: cmp             x1, #0xac8
    // 0xccf458: b.eq            #0xccf490
    // 0xccf45c: r1 = LoadClassIdInstr(r0)
    //     0xccf45c: ldur            x1, [x0, #-1]
    //     0xccf460: ubfx            x1, x1, #0xc, #0x14
    // 0xccf464: mov             x16, x0
    // 0xccf468: mov             x0, x1
    // 0xccf46c: mov             x1, x16
    // 0xccf470: ldur            x2, [fp, #-0x18]
    // 0xccf474: r0 = GDT[cid_x0 + -0xfd1]()
    //     0xccf474: sub             lr, x0, #0xfd1
    //     0xccf478: ldr             lr, [x21, lr, lsl #3]
    //     0xccf47c: blr             lr
    // 0xccf480: r0 = ReturnAsync()
    //     0xccf480: b               #0x82fdf0  ; ReturnAsyncStub
    // 0xccf484: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xccf484: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xccf488: r0 = Throw()
    //     0xccf488: bl              #0x13ddb2c  ; ThrowStub
    // 0xccf48c: brk             #0
    // 0xccf490: r0 = UnimplementedError()
    //     0xccf490: bl              #0x7dd7c4  ; AllocateUnimplementedErrorStub -> UnimplementedError (size=0x10)
    // 0xccf494: mov             x1, x0
    // 0xccf498: r0 = "Not supported for hybrid composition."
    //     0xccf498: add             x0, PP, #0xa1, lsl #12  ; [pp+0xa1700] "Not supported for hybrid composition."
    //     0xccf49c: ldr             x0, [x0, #0x700]
    // 0xccf4a0: StoreField: r1->field_b = r0
    //     0xccf4a0: stur            w0, [x1, #0xb]
    // 0xccf4a4: mov             x0, x1
    // 0xccf4a8: r0 = Throw()
    //     0xccf4a8: bl              #0x13ddb2c  ; ThrowStub
    // 0xccf4ac: brk             #0
    // 0xccf4b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xccf4b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xccf4b4: b               #0xccf3e0
  }
  _ create(/* No info */) async {
    // ** addr: 0xccf4b8, size: 0x214
    // 0xccf4b8: EnterFrame
    //     0xccf4b8: stp             fp, lr, [SP, #-0x10]!
    //     0xccf4bc: mov             fp, SP
    // 0xccf4c0: AllocStack(0x40)
    //     0xccf4c0: sub             SP, SP, #0x40
    // 0xccf4c4: SetupParameters(AndroidViewController this /* r1 => r1, fp-0x20 */, {dynamic position = Null /* r3, fp-0x18 */, dynamic size = Null /* r2, fp-0x10 */})
    //     0xccf4c4: stur            NULL, [fp, #-8]
    //     0xccf4c8: stur            x1, [fp, #-0x20]
    //     0xccf4cc: ldur            w0, [x4, #0x13]
    //     0xccf4d0: ldur            w2, [x4, #0x1f]
    //     0xccf4d4: add             x2, x2, HEAP, lsl #32
    //     0xccf4d8: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f890] "position"
    //     0xccf4dc: ldr             x16, [x16, #0x890]
    //     0xccf4e0: cmp             w2, w16
    //     0xccf4e4: b.ne            #0xccf508
    //     0xccf4e8: ldur            w2, [x4, #0x23]
    //     0xccf4ec: add             x2, x2, HEAP, lsl #32
    //     0xccf4f0: sub             w3, w0, w2
    //     0xccf4f4: add             x2, fp, w3, sxtw #2
    //     0xccf4f8: ldr             x2, [x2, #8]
    //     0xccf4fc: mov             x3, x2
    //     0xccf500: mov             x2, #1
    //     0xccf504: b               #0xccf510
    //     0xccf508: mov             x3, NULL
    //     0xccf50c: mov             x2, #0
    //     0xccf510: stur            x3, [fp, #-0x18]
    //     0xccf514: lsl             x5, x2, #1
    //     0xccf518: lsl             w2, w5, #1
    //     0xccf51c: add             w5, w2, #8
    //     0xccf520: add             x16, x4, w5, sxtw #1
    //     0xccf524: ldur            w6, [x16, #0xf]
    //     0xccf528: add             x6, x6, HEAP, lsl #32
    //     0xccf52c: add             x16, PP, #0x22, lsl #12  ; [pp+0x22310] "size"
    //     0xccf530: ldr             x16, [x16, #0x310]
    //     0xccf534: cmp             w6, w16
    //     0xccf538: b.ne            #0xccf560
    //     0xccf53c: add             w5, w2, #0xa
    //     0xccf540: add             x16, x4, w5, sxtw #1
    //     0xccf544: ldur            w2, [x16, #0xf]
    //     0xccf548: add             x2, x2, HEAP, lsl #32
    //     0xccf54c: sub             w4, w0, w2
    //     0xccf550: add             x0, fp, w4, sxtw #2
    //     0xccf554: ldr             x0, [x0, #8]
    //     0xccf558: mov             x2, x0
    //     0xccf55c: b               #0xccf564
    //     0xccf560: mov             x2, NULL
    //     0xccf564: stur            x2, [fp, #-0x10]
    // 0xccf568: CheckStackOverflow
    //     0xccf568: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xccf56c: cmp             SP, x16
    //     0xccf570: b.ls            #0xccf6bc
    // 0xccf574: InitAsync() -> Future<void?>
    //     0xccf574: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0xccf578: bl              #0x7f5e44  ; InitAsyncStub
    // 0xccf57c: ldur            x4, [fp, #-0x20]
    // 0xccf580: r0 = LoadClassIdInstr(r4)
    //     0xccf580: ldur            x0, [x4, #-1]
    //     0xccf584: ubfx            x0, x0, #0xc, #0x14
    // 0xccf588: cmp             x0, #0xacc
    // 0xccf58c: b.ne            #0xccf598
    // 0xccf590: ldur            x3, [fp, #-0x10]
    // 0xccf594: b               #0xccf5ac
    // 0xccf598: ldur            x3, [fp, #-0x10]
    // 0xccf59c: cmp             w3, NULL
    // 0xccf5a0: b.ne            #0xccf5ac
    // 0xccf5a4: r0 = Null
    //     0xccf5a4: mov             x0, NULL
    // 0xccf5a8: r0 = ReturnAsyncNotFuture()
    //     0xccf5a8: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xccf5ac: r0 = Instance__AndroidViewState
    //     0xccf5ac: add             x0, PP, #0x7d, lsl #12  ; [pp+0x7d3a0] Obj!_AndroidViewState@12c3d81
    //     0xccf5b0: ldr             x0, [x0, #0x3a0]
    // 0xccf5b4: StoreField: r4->field_1b = r0
    //     0xccf5b4: stur            w0, [x4, #0x1b]
    // 0xccf5b8: r0 = LoadClassIdInstr(r4)
    //     0xccf5b8: ldur            x0, [x4, #-1]
    //     0xccf5bc: ubfx            x0, x0, #0xc, #0x14
    // 0xccf5c0: mov             x1, x4
    // 0xccf5c4: ldur            x2, [fp, #-0x18]
    // 0xccf5c8: r0 = GDT[cid_x0 + -0xff4]()
    //     0xccf5c8: sub             lr, x0, #0xff4
    //     0xccf5cc: ldr             lr, [x21, lr, lsl #3]
    //     0xccf5d0: blr             lr
    // 0xccf5d4: mov             x1, x0
    // 0xccf5d8: stur            x1, [fp, #-0x10]
    // 0xccf5dc: r0 = Await()
    //     0xccf5dc: bl              #0x7f5c00  ; AwaitStub
    // 0xccf5e0: ldur            x0, [fp, #-0x20]
    // 0xccf5e4: r1 = Instance__AndroidViewState
    //     0xccf5e4: add             x1, PP, #0x7d, lsl #12  ; [pp+0x7d3a8] Obj!_AndroidViewState@12c3d61
    //     0xccf5e8: ldr             x1, [x1, #0x3a8]
    // 0xccf5ec: StoreField: r0->field_1b = r1
    //     0xccf5ec: stur            w1, [x0, #0x1b]
    // 0xccf5f0: LoadField: r2 = r0->field_23
    //     0xccf5f0: ldur            w2, [x0, #0x23]
    // 0xccf5f4: DecompressPointer r2
    //     0xccf5f4: add             x2, x2, HEAP, lsl #32
    // 0xccf5f8: stur            x2, [fp, #-0x18]
    // 0xccf5fc: LoadField: r1 = r2->field_b
    //     0xccf5fc: ldur            w1, [x2, #0xb]
    // 0xccf600: r3 = LoadInt32Instr(r1)
    //     0xccf600: sbfx            x3, x1, #1, #0x1f
    // 0xccf604: stur            x3, [fp, #-0x30]
    // 0xccf608: LoadField: r4 = r0->field_7
    //     0xccf608: ldur            x4, [x0, #7]
    // 0xccf60c: r0 = BoxInt64Instr(r4)
    //     0xccf60c: sbfiz           x0, x4, #1, #0x1f
    //     0xccf610: cmp             x4, x0, asr #1
    //     0xccf614: b.eq            #0xccf620
    //     0xccf618: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xccf61c: stur            x4, [x0, #7]
    // 0xccf620: mov             x1, x0
    // 0xccf624: stur            x1, [fp, #-0x10]
    // 0xccf628: r0 = 0
    //     0xccf628: mov             x0, #0
    // 0xccf62c: CheckStackOverflow
    //     0xccf62c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xccf630: cmp             SP, x16
    //     0xccf634: b.ls            #0xccf6c4
    // 0xccf638: LoadField: r4 = r2->field_b
    //     0xccf638: ldur            w4, [x2, #0xb]
    // 0xccf63c: r5 = LoadInt32Instr(r4)
    //     0xccf63c: sbfx            x5, x4, #1, #0x1f
    // 0xccf640: cmp             x3, x5
    // 0xccf644: b.ne            #0xccf69c
    // 0xccf648: cmp             x0, x5
    // 0xccf64c: b.ge            #0xccf694
    // 0xccf650: LoadField: r4 = r2->field_f
    //     0xccf650: ldur            w4, [x2, #0xf]
    // 0xccf654: DecompressPointer r4
    //     0xccf654: add             x4, x4, HEAP, lsl #32
    // 0xccf658: ArrayLoad: r5 = r4[r0]  ; Unknown_4
    //     0xccf658: add             x16, x4, x0, lsl #2
    //     0xccf65c: ldur            w5, [x16, #0xf]
    // 0xccf660: DecompressPointer r5
    //     0xccf660: add             x5, x5, HEAP, lsl #32
    // 0xccf664: add             x4, x0, #1
    // 0xccf668: stur            x4, [fp, #-0x28]
    // 0xccf66c: stp             x1, x5, [SP]
    // 0xccf670: mov             x0, x5
    // 0xccf674: ClosureCall
    //     0xccf674: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xccf678: ldur            x2, [x0, #0x1f]
    //     0xccf67c: blr             x2
    // 0xccf680: ldur            x0, [fp, #-0x28]
    // 0xccf684: ldur            x2, [fp, #-0x18]
    // 0xccf688: ldur            x3, [fp, #-0x30]
    // 0xccf68c: ldur            x1, [fp, #-0x10]
    // 0xccf690: b               #0xccf62c
    // 0xccf694: r0 = Null
    //     0xccf694: mov             x0, NULL
    // 0xccf698: r0 = ReturnAsyncNotFuture()
    //     0xccf698: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xccf69c: mov             x0, x2
    // 0xccf6a0: r0 = ConcurrentModificationError()
    //     0xccf6a0: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xccf6a4: mov             x1, x0
    // 0xccf6a8: ldur            x0, [fp, #-0x18]
    // 0xccf6ac: StoreField: r1->field_b = r0
    //     0xccf6ac: stur            w0, [x1, #0xb]
    // 0xccf6b0: mov             x0, x1
    // 0xccf6b4: r0 = Throw()
    //     0xccf6b4: bl              #0x13ddb2c  ; ThrowStub
    // 0xccf6b8: brk             #0
    // 0xccf6bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xccf6bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xccf6c0: b               #0xccf574
    // 0xccf6c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xccf6c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xccf6c8: b               #0xccf638
  }
  _ clearFocus(/* No info */) {
    // ** addr: 0xe0c01c, size: 0xd4
    // 0xe0c01c: EnterFrame
    //     0xe0c01c: stp             fp, lr, [SP, #-0x10]!
    //     0xe0c020: mov             fp, SP
    // 0xe0c024: AllocStack(0x28)
    //     0xe0c024: sub             SP, SP, #0x28
    // 0xe0c028: CheckStackOverflow
    //     0xe0c028: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe0c02c: cmp             SP, x16
    //     0xe0c030: b.ls            #0xe0c0e8
    // 0xe0c034: LoadField: r0 = r1->field_1b
    //     0xe0c034: ldur            w0, [x1, #0x1b]
    // 0xe0c038: DecompressPointer r0
    //     0xe0c038: add             x0, x0, HEAP, lsl #32
    // 0xe0c03c: r16 = Instance__AndroidViewState
    //     0xe0c03c: add             x16, PP, #0x7d, lsl #12  ; [pp+0x7d3a8] Obj!_AndroidViewState@12c3d61
    //     0xe0c040: ldr             x16, [x16, #0x3a8]
    // 0xe0c044: cmp             w0, w16
    // 0xe0c048: b.eq            #0xe0c0a0
    // 0xe0c04c: r1 = <void?>
    //     0xe0c04c: ldr             x1, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xe0c050: r0 = _Future()
    //     0xe0c050: bl              #0x7f5dd4  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0xe0c054: stur            x0, [fp, #-8]
    // 0xe0c058: StoreField: r0->field_b = rZR
    //     0xe0c058: stur            xzr, [x0, #0xb]
    // 0xe0c05c: r0 = LoadStaticField(0x364)
    //     0xe0c05c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xe0c060: ldr             x0, [x0, #0x6c8]
    // 0xe0c064: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xe0c068: cmp             w0, w16
    // 0xe0c06c: b.ne            #0xe0c078
    // 0xe0c070: r2 = _current
    //     0xe0c070: ldr             x2, [PP, #0x2c0]  ; [pp+0x2c0] Field <Zone._current@5048458>: static late (offset: 0x364)
    // 0xe0c074: r0 = InitLateStaticField()
    //     0xe0c074: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0xe0c078: mov             x1, x0
    // 0xe0c07c: ldur            x0, [fp, #-8]
    // 0xe0c080: StoreField: r0->field_13 = r1
    //     0xe0c080: stur            w1, [x0, #0x13]
    // 0xe0c084: mov             x1, x0
    // 0xe0c088: r2 = Null
    //     0xe0c088: mov             x2, NULL
    // 0xe0c08c: r0 = _asyncComplete()
    //     0xe0c08c: bl              #0x7eee44  ; [dart:async] _Future::_asyncComplete
    // 0xe0c090: ldur            x0, [fp, #-8]
    // 0xe0c094: LeaveFrame
    //     0xe0c094: mov             SP, fp
    //     0xe0c098: ldp             fp, lr, [SP], #0x10
    // 0xe0c09c: ret
    //     0xe0c09c: ret             
    // 0xe0c0a0: LoadField: r2 = r1->field_7
    //     0xe0c0a0: ldur            x2, [x1, #7]
    // 0xe0c0a4: r0 = BoxInt64Instr(r2)
    //     0xe0c0a4: sbfiz           x0, x2, #1, #0x1f
    //     0xe0c0a8: cmp             x2, x0, asr #1
    //     0xe0c0ac: b.eq            #0xe0c0b8
    //     0xe0c0b0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xe0c0b4: stur            x2, [x0, #7]
    // 0xe0c0b8: r16 = <void?>
    //     0xe0c0b8: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xe0c0bc: r30 = Instance_MethodChannel
    //     0xe0c0bc: add             lr, PP, #0x7d, lsl #12  ; [pp+0x7d3e8] Obj!MethodChannel@129bbe1
    //     0xe0c0c0: ldr             lr, [lr, #0x3e8]
    // 0xe0c0c4: stp             lr, x16, [SP, #0x10]
    // 0xe0c0c8: r16 = "clearFocus"
    //     0xe0c0c8: add             x16, PP, #0x97, lsl #12  ; [pp+0x97270] "clearFocus"
    //     0xe0c0cc: ldr             x16, [x16, #0x270]
    // 0xe0c0d0: stp             x0, x16, [SP]
    // 0xe0c0d4: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xe0c0d4: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xe0c0d8: r0 = invokeMethod()
    //     0xe0c0d8: bl              #0x130b008  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xe0c0dc: LeaveFrame
    //     0xe0c0dc: mov             SP, fp
    //     0xe0c0e0: ldp             fp, lr, [SP], #0x10
    // 0xe0c0e4: ret
    //     0xe0c0e4: ret             
    // 0xe0c0e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe0c0e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe0c0ec: b               #0xe0c034
  }
  _ dispose(/* No info */) async {
    // ** addr: 0xf75208, size: 0x1f0
    // 0xf75208: EnterFrame
    //     0xf75208: stp             fp, lr, [SP, #-0x10]!
    //     0xf7520c: mov             fp, SP
    // 0xf75210: AllocStack(0x40)
    //     0xf75210: sub             SP, SP, #0x40
    // 0xf75214: SetupParameters(AndroidViewController this /* r1 => r1, fp-0x10 */)
    //     0xf75214: stur            NULL, [fp, #-8]
    //     0xf75218: stur            x1, [fp, #-0x10]
    // 0xf7521c: CheckStackOverflow
    //     0xf7521c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf75220: cmp             SP, x16
    //     0xf75224: b.ls            #0xf753f0
    // 0xf75228: InitAsync() -> Future<void?>
    //     0xf75228: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0xf7522c: bl              #0x7f5e44  ; InitAsyncStub
    // 0xf75230: ldur            x0, [fp, #-0x10]
    // 0xf75234: LoadField: r2 = r0->field_1b
    //     0xf75234: ldur            w2, [x0, #0x1b]
    // 0xf75238: DecompressPointer r2
    //     0xf75238: add             x2, x2, HEAP, lsl #32
    // 0xf7523c: stur            x2, [fp, #-0x18]
    // 0xf75240: r1 = Instance__AndroidViewState
    //     0xf75240: add             x1, PP, #0x97, lsl #12  ; [pp+0x971c0] Obj!_AndroidViewState@12c3dc1
    //     0xf75244: ldr             x1, [x1, #0x1c0]
    // 0xf75248: StoreField: r0->field_1b = r1
    //     0xf75248: stur            w1, [x0, #0x1b]
    // 0xf7524c: LoadField: r1 = r0->field_23
    //     0xf7524c: ldur            w1, [x0, #0x23]
    // 0xf75250: DecompressPointer r1
    //     0xf75250: add             x1, x1, HEAP, lsl #32
    // 0xf75254: r0 = clear()
    //     0xf75254: bl              #0xa16074  ; [dart:core] _GrowableList::clear
    // 0xf75258: r0 = LoadStaticField(0xc24)
    //     0xf75258: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf7525c: ldr             x0, [x0, #0x1848]
    // 0xf75260: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf75264: cmp             w0, w16
    // 0xf75268: b.ne            #0xf75278
    // 0xf7526c: r2 = _instance
    //     0xf7526c: add             x2, PP, #0x7d, lsl #12  ; [pp+0x7d3b0] Field <PlatformViewsService._instance@634227590>: static late final (offset: 0xc24)
    //     0xf75270: ldr             x2, [x2, #0x3b0]
    // 0xf75274: r0 = InitLateFinalStaticField()
    //     0xf75274: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xf75278: LoadField: r2 = r0->field_7
    //     0xf75278: ldur            w2, [x0, #7]
    // 0xf7527c: DecompressPointer r2
    //     0xf7527c: add             x2, x2, HEAP, lsl #32
    // 0xf75280: ldur            x3, [fp, #-0x10]
    // 0xf75284: LoadField: r4 = r3->field_7
    //     0xf75284: ldur            x4, [x3, #7]
    // 0xf75288: r0 = BoxInt64Instr(r4)
    //     0xf75288: sbfiz           x0, x4, #1, #0x1f
    //     0xf7528c: cmp             x4, x0, asr #1
    //     0xf75290: b.eq            #0xf7529c
    //     0xf75294: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xf75298: stur            x4, [x0, #7]
    // 0xf7529c: mov             x1, x2
    // 0xf752a0: mov             x2, x0
    // 0xf752a4: stur            x0, [fp, #-0x20]
    // 0xf752a8: r0 = remove()
    //     0xf752a8: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xf752ac: ldur            x0, [fp, #-0x18]
    // 0xf752b0: r16 = Instance__AndroidViewState
    //     0xf752b0: add             x16, PP, #0x7d, lsl #12  ; [pp+0x7d3a0] Obj!_AndroidViewState@12c3d81
    //     0xf752b4: ldr             x16, [x16, #0x3a0]
    // 0xf752b8: cmp             w0, w16
    // 0xf752bc: b.eq            #0xf752d0
    // 0xf752c0: r16 = Instance__AndroidViewState
    //     0xf752c0: add             x16, PP, #0x7d, lsl #12  ; [pp+0x7d3a8] Obj!_AndroidViewState@12c3d61
    //     0xf752c4: ldr             x16, [x16, #0x3a8]
    // 0xf752c8: cmp             w0, w16
    // 0xf752cc: b.ne            #0xf753dc
    // 0xf752d0: ldur            x0, [fp, #-0x10]
    // 0xf752d4: r1 = LoadClassIdInstr(r0)
    //     0xf752d4: ldur            x1, [x0, #-1]
    //     0xf752d8: ubfx            x1, x1, #0xc, #0x14
    // 0xf752dc: cmp             x1, #0xacc
    // 0xf752e0: b.eq            #0xf753e4
    // 0xf752e4: LoadField: r1 = r0->field_27
    //     0xf752e4: ldur            w1, [x0, #0x27]
    // 0xf752e8: DecompressPointer r1
    //     0xf752e8: add             x1, x1, HEAP, lsl #32
    // 0xf752ec: r0 = LoadClassIdInstr(r1)
    //     0xf752ec: ldur            x0, [x1, #-1]
    //     0xf752f0: ubfx            x0, x0, #0xc, #0x14
    // 0xf752f4: cmp             x0, #0xac8
    // 0xf752f8: b.ne            #0xf75368
    // 0xf752fc: ldur            x0, [fp, #-0x20]
    // 0xf75300: r1 = Null
    //     0xf75300: mov             x1, NULL
    // 0xf75304: r2 = 8
    //     0xf75304: mov             x2, #8
    // 0xf75308: r0 = AllocateArray()
    //     0xf75308: bl              #0x13df928  ; AllocateArrayStub
    // 0xf7530c: r16 = "id"
    //     0xf7530c: ldr             x16, [PP, #0x7f88]  ; [pp+0x7f88] "id"
    // 0xf75310: StoreField: r0->field_f = r16
    //     0xf75310: stur            w16, [x0, #0xf]
    // 0xf75314: ldur            x3, [fp, #-0x20]
    // 0xf75318: StoreField: r0->field_13 = r3
    //     0xf75318: stur            w3, [x0, #0x13]
    // 0xf7531c: r16 = "hybrid"
    //     0xf7531c: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8ce28] "hybrid"
    //     0xf75320: ldr             x16, [x16, #0xe28]
    // 0xf75324: ArrayStore: r0[0] = r16  ; List_4
    //     0xf75324: stur            w16, [x0, #0x17]
    // 0xf75328: r16 = true
    //     0xf75328: add             x16, NULL, #0x20  ; true
    // 0xf7532c: StoreField: r0->field_1b = r16
    //     0xf7532c: stur            w16, [x0, #0x1b]
    // 0xf75330: r16 = <String, dynamic>
    //     0xf75330: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0xf75334: stp             x0, x16, [SP]
    // 0xf75338: r0 = Map._fromLiteral()
    //     0xf75338: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xf7533c: r16 = <void?>
    //     0xf7533c: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xf75340: r30 = Instance_MethodChannel
    //     0xf75340: add             lr, PP, #0x7d, lsl #12  ; [pp+0x7d3e8] Obj!MethodChannel@129bbe1
    //     0xf75344: ldr             lr, [lr, #0x3e8]
    // 0xf75348: stp             lr, x16, [SP, #0x10]
    // 0xf7534c: r16 = "dispose"
    //     0xf7534c: add             x16, PP, #0x97, lsl #12  ; [pp+0x971c8] "dispose"
    //     0xf75350: ldr             x16, [x16, #0x1c8]
    // 0xf75354: stp             x0, x16, [SP]
    // 0xf75358: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xf75358: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xf7535c: r0 = invokeMethod()
    //     0xf7535c: bl              #0x130b008  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xf75360: mov             x1, x0
    // 0xf75364: b               #0xf753d0
    // 0xf75368: ldur            x3, [fp, #-0x20]
    // 0xf7536c: r1 = Null
    //     0xf7536c: mov             x1, NULL
    // 0xf75370: r2 = 8
    //     0xf75370: mov             x2, #8
    // 0xf75374: r0 = AllocateArray()
    //     0xf75374: bl              #0x13df928  ; AllocateArrayStub
    // 0xf75378: r16 = "id"
    //     0xf75378: ldr             x16, [PP, #0x7f88]  ; [pp+0x7f88] "id"
    // 0xf7537c: StoreField: r0->field_f = r16
    //     0xf7537c: stur            w16, [x0, #0xf]
    // 0xf75380: ldur            x1, [fp, #-0x20]
    // 0xf75384: StoreField: r0->field_13 = r1
    //     0xf75384: stur            w1, [x0, #0x13]
    // 0xf75388: r16 = "hybrid"
    //     0xf75388: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8ce28] "hybrid"
    //     0xf7538c: ldr             x16, [x16, #0xe28]
    // 0xf75390: ArrayStore: r0[0] = r16  ; List_4
    //     0xf75390: stur            w16, [x0, #0x17]
    // 0xf75394: r16 = false
    //     0xf75394: add             x16, NULL, #0x30  ; false
    // 0xf75398: StoreField: r0->field_1b = r16
    //     0xf75398: stur            w16, [x0, #0x1b]
    // 0xf7539c: r16 = <String, dynamic>
    //     0xf7539c: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0xf753a0: stp             x0, x16, [SP]
    // 0xf753a4: r0 = Map._fromLiteral()
    //     0xf753a4: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xf753a8: r16 = <void?>
    //     0xf753a8: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xf753ac: r30 = Instance_MethodChannel
    //     0xf753ac: add             lr, PP, #0x7d, lsl #12  ; [pp+0x7d3e8] Obj!MethodChannel@129bbe1
    //     0xf753b0: ldr             lr, [lr, #0x3e8]
    // 0xf753b4: stp             lr, x16, [SP, #0x10]
    // 0xf753b8: r16 = "dispose"
    //     0xf753b8: add             x16, PP, #0x97, lsl #12  ; [pp+0x971c8] "dispose"
    //     0xf753bc: ldr             x16, [x16, #0x1c8]
    // 0xf753c0: stp             x0, x16, [SP]
    // 0xf753c4: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xf753c4: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xf753c8: r0 = invokeMethod()
    //     0xf753c8: bl              #0x130b008  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xf753cc: mov             x1, x0
    // 0xf753d0: mov             x0, x1
    // 0xf753d4: stur            x1, [fp, #-0x10]
    // 0xf753d8: r0 = Await()
    //     0xf753d8: bl              #0x7f5c00  ; AwaitStub
    // 0xf753dc: r0 = Null
    //     0xf753dc: mov             x0, NULL
    // 0xf753e0: r0 = ReturnAsyncNotFuture()
    //     0xf753e0: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xf753e4: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xf753e4: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xf753e8: r0 = Throw()
    //     0xf753e8: bl              #0x13ddb2c  ; ThrowStub
    // 0xf753ec: brk             #0
    // 0xf753f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf753f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf753f4: b               #0xf75228
  }
  _ AndroidViewController._(/* No info */) {
    // ** addr: 0x10d7d94, size: 0x144
    // 0x10d7d94: EnterFrame
    //     0x10d7d94: stp             fp, lr, [SP, #-0x10]!
    //     0x10d7d98: mov             fp, SP
    // 0x10d7d9c: AllocStack(0x38)
    //     0x10d7d9c: sub             SP, SP, #0x38
    // 0x10d7da0: r0 = Instance__AndroidViewState
    //     0x10d7da0: add             x0, PP, #0x7d, lsl #12  ; [pp+0x7d3c0] Obj!_AndroidViewState@12c3da1
    //     0x10d7da4: ldr             x0, [x0, #0x3c0]
    // 0x10d7da8: mov             x4, x2
    // 0x10d7dac: stur            x2, [fp, #-0x10]
    // 0x10d7db0: mov             x2, x5
    // 0x10d7db4: stur            x5, [fp, #-0x20]
    // 0x10d7db8: mov             x5, x1
    // 0x10d7dbc: stur            x1, [fp, #-8]
    // 0x10d7dc0: mov             x1, x7
    // 0x10d7dc4: stur            x3, [fp, #-0x18]
    // 0x10d7dc8: stur            x6, [fp, #-0x28]
    // 0x10d7dcc: stur            x7, [fp, #-0x30]
    // 0x10d7dd0: CheckStackOverflow
    //     0x10d7dd0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10d7dd4: cmp             SP, x16
    //     0x10d7dd8: b.ls            #0x10d7ed0
    // 0x10d7ddc: StoreField: r5->field_1b = r0
    //     0x10d7ddc: stur            w0, [x5, #0x1b]
    // 0x10d7de0: r0 = _AndroidMotionEventConverter()
    //     0x10d7de0: bl              #0x10d7fcc  ; Allocate_AndroidMotionEventConverterStub -> _AndroidMotionEventConverter (size=0x1c)
    // 0x10d7de4: mov             x1, x0
    // 0x10d7de8: stur            x0, [fp, #-0x38]
    // 0x10d7dec: r0 = _AndroidMotionEventConverter()
    //     0x10d7dec: bl              #0x10d7ee4  ; [package:flutter/src/services/platform_views.dart] _AndroidMotionEventConverter::_AndroidMotionEventConverter
    // 0x10d7df0: ldur            x0, [fp, #-0x38]
    // 0x10d7df4: ldur            x3, [fp, #-8]
    // 0x10d7df8: StoreField: r3->field_13 = r0
    //     0x10d7df8: stur            w0, [x3, #0x13]
    //     0x10d7dfc: ldurb           w16, [x3, #-1]
    //     0x10d7e00: ldurb           w17, [x0, #-1]
    //     0x10d7e04: and             x16, x17, x16, lsr #2
    //     0x10d7e08: tst             x16, HEAP, lsr #32
    //     0x10d7e0c: b.eq            #0x10d7e14
    //     0x10d7e10: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x10d7e14: r1 = <(dynamic this, int) => void?>
    //     0x10d7e14: add             x1, PP, #0x7d, lsl #12  ; [pp+0x7d3c8] TypeArguments: <(dynamic this, int) => void?>
    //     0x10d7e18: ldr             x1, [x1, #0x3c8]
    // 0x10d7e1c: r2 = 0
    //     0x10d7e1c: mov             x2, #0
    // 0x10d7e20: r0 = _GrowableList()
    //     0x10d7e20: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x10d7e24: ldur            x1, [fp, #-8]
    // 0x10d7e28: StoreField: r1->field_23 = r0
    //     0x10d7e28: stur            w0, [x1, #0x23]
    //     0x10d7e2c: ldurb           w16, [x1, #-1]
    //     0x10d7e30: ldurb           w17, [x0, #-1]
    //     0x10d7e34: and             x16, x17, x16, lsr #2
    //     0x10d7e38: tst             x16, HEAP, lsr #32
    //     0x10d7e3c: b.eq            #0x10d7e44
    //     0x10d7e40: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x10d7e44: ldur            x0, [fp, #-0x28]
    // 0x10d7e48: StoreField: r1->field_7 = r0
    //     0x10d7e48: stur            x0, [x1, #7]
    // 0x10d7e4c: ldur            x0, [fp, #-0x30]
    // 0x10d7e50: StoreField: r1->field_f = r0
    //     0x10d7e50: stur            w0, [x1, #0xf]
    //     0x10d7e54: ldurb           w16, [x1, #-1]
    //     0x10d7e58: ldurb           w17, [x0, #-1]
    //     0x10d7e5c: and             x16, x17, x16, lsr #2
    //     0x10d7e60: tst             x16, HEAP, lsr #32
    //     0x10d7e64: b.eq            #0x10d7e6c
    //     0x10d7e68: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x10d7e6c: ldur            x0, [fp, #-0x20]
    // 0x10d7e70: ArrayStore: r1[0] = r0  ; List_4
    //     0x10d7e70: stur            w0, [x1, #0x17]
    //     0x10d7e74: ldurb           w16, [x1, #-1]
    //     0x10d7e78: ldurb           w17, [x0, #-1]
    //     0x10d7e7c: and             x16, x17, x16, lsr #2
    //     0x10d7e80: tst             x16, HEAP, lsr #32
    //     0x10d7e84: b.eq            #0x10d7e8c
    //     0x10d7e88: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x10d7e8c: r0 = _CreationParams()
    //     0x10d7e8c: bl              #0x10d7ed8  ; Allocate_CreationParamsStub -> _CreationParams (size=0x10)
    // 0x10d7e90: ldur            x1, [fp, #-0x10]
    // 0x10d7e94: StoreField: r0->field_7 = r1
    //     0x10d7e94: stur            w1, [x0, #7]
    // 0x10d7e98: ldur            x1, [fp, #-0x18]
    // 0x10d7e9c: StoreField: r0->field_b = r1
    //     0x10d7e9c: stur            w1, [x0, #0xb]
    // 0x10d7ea0: ldur            x1, [fp, #-8]
    // 0x10d7ea4: StoreField: r1->field_1f = r0
    //     0x10d7ea4: stur            w0, [x1, #0x1f]
    //     0x10d7ea8: ldurb           w16, [x1, #-1]
    //     0x10d7eac: ldurb           w17, [x0, #-1]
    //     0x10d7eb0: and             x16, x17, x16, lsr #2
    //     0x10d7eb4: tst             x16, HEAP, lsr #32
    //     0x10d7eb8: b.eq            #0x10d7ec0
    //     0x10d7ebc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x10d7ec0: r0 = Null
    //     0x10d7ec0: mov             x0, NULL
    // 0x10d7ec4: LeaveFrame
    //     0x10d7ec4: mov             SP, fp
    //     0x10d7ec8: ldp             fp, lr, [SP], #0x10
    // 0x10d7ecc: ret
    //     0x10d7ecc: ret             
    // 0x10d7ed0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10d7ed0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10d7ed4: b               #0x10d7ddc
  }
}

// class id: 2765, size: 0x2c, field offset: 0x28
class SurfaceAndroidViewController extends AndroidViewController {

  _ SurfaceAndroidViewController._(/* No info */) {
    // ** addr: 0x10d7d00, size: 0x94
    // 0x10d7d00: EnterFrame
    //     0x10d7d00: stp             fp, lr, [SP, #-0x10]!
    //     0x10d7d04: mov             fp, SP
    // 0x10d7d08: AllocStack(0x30)
    //     0x10d7d08: sub             SP, SP, #0x30
    // 0x10d7d0c: SetupParameters(SurfaceAndroidViewController this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */, dynamic _ /* r6 => r6, fp-0x28 */, dynamic _ /* r7 => r7, fp-0x30 */)
    //     0x10d7d0c: stur            x1, [fp, #-8]
    //     0x10d7d10: stur            x2, [fp, #-0x10]
    //     0x10d7d14: stur            x3, [fp, #-0x18]
    //     0x10d7d18: stur            x5, [fp, #-0x20]
    //     0x10d7d1c: stur            x6, [fp, #-0x28]
    //     0x10d7d20: stur            x7, [fp, #-0x30]
    // 0x10d7d24: CheckStackOverflow
    //     0x10d7d24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10d7d28: cmp             SP, x16
    //     0x10d7d2c: b.ls            #0x10d7d8c
    // 0x10d7d30: r0 = _TextureAndroidViewControllerInternals()
    //     0x10d7d30: bl              #0x10d7fd8  ; Allocate_TextureAndroidViewControllerInternalsStub -> _TextureAndroidViewControllerInternals (size=0x10)
    // 0x10d7d34: mov             x1, x0
    // 0x10d7d38: r0 = Instance_Offset
    //     0x10d7d38: ldr             x0, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x10d7d3c: StoreField: r1->field_7 = r0
    //     0x10d7d3c: stur            w0, [x1, #7]
    // 0x10d7d40: mov             x0, x1
    // 0x10d7d44: ldur            x1, [fp, #-8]
    // 0x10d7d48: StoreField: r1->field_27 = r0
    //     0x10d7d48: stur            w0, [x1, #0x27]
    //     0x10d7d4c: ldurb           w16, [x1, #-1]
    //     0x10d7d50: ldurb           w17, [x0, #-1]
    //     0x10d7d54: and             x16, x17, x16, lsr #2
    //     0x10d7d58: tst             x16, HEAP, lsr #32
    //     0x10d7d5c: b.eq            #0x10d7d64
    //     0x10d7d60: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x10d7d64: ldur            x2, [fp, #-0x10]
    // 0x10d7d68: ldur            x3, [fp, #-0x18]
    // 0x10d7d6c: ldur            x5, [fp, #-0x20]
    // 0x10d7d70: ldur            x6, [fp, #-0x28]
    // 0x10d7d74: ldur            x7, [fp, #-0x30]
    // 0x10d7d78: r0 = AndroidViewController._()
    //     0x10d7d78: bl              #0x10d7d94  ; [package:flutter/src/services/platform_views.dart] AndroidViewController::AndroidViewController._
    // 0x10d7d7c: r0 = Null
    //     0x10d7d7c: mov             x0, NULL
    // 0x10d7d80: LeaveFrame
    //     0x10d7d80: mov             SP, fp
    //     0x10d7d84: ldp             fp, lr, [SP], #0x10
    // 0x10d7d88: ret
    //     0x10d7d88: ret             
    // 0x10d7d8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10d7d8c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10d7d90: b               #0x10d7d30
  }
  _ _sendCreateMessage(/* No info */) async {
    // ** addr: 0x130a758, size: 0x188
    // 0x130a758: EnterFrame
    //     0x130a758: stp             fp, lr, [SP, #-0x10]!
    //     0x130a75c: mov             fp, SP
    // 0x130a760: AllocStack(0x30)
    //     0x130a760: sub             SP, SP, #0x30
    // 0x130a764: SetupParameters(SurfaceAndroidViewController this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r5, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */)
    //     0x130a764: stur            NULL, [fp, #-8]
    //     0x130a768: mov             x4, x1
    //     0x130a76c: mov             x5, x2
    //     0x130a770: stur            x1, [fp, #-0x10]
    //     0x130a774: stur            x2, [fp, #-0x18]
    //     0x130a778: stur            x3, [fp, #-0x20]
    // 0x130a77c: CheckStackOverflow
    //     0x130a77c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x130a780: cmp             SP, x16
    //     0x130a784: b.ls            #0x130a8d8
    // 0x130a788: mov             x0, x3
    // 0x130a78c: r2 = Null
    //     0x130a78c: mov             x2, NULL
    // 0x130a790: r1 = Null
    //     0x130a790: mov             x1, NULL
    // 0x130a794: r4 = 60
    //     0x130a794: mov             x4, #0x3c
    // 0x130a798: branchIfSmi(r0, 0x130a7a4)
    //     0x130a798: tbz             w0, #0, #0x130a7a4
    // 0x130a79c: r4 = LoadClassIdInstr(r0)
    //     0x130a79c: ldur            x4, [x0, #-1]
    //     0x130a7a0: ubfx            x4, x4, #0xc, #0x14
    // 0x130a7a4: sub             x4, x4, #0xeda
    // 0x130a7a8: cmp             x4, #1
    // 0x130a7ac: b.ls            #0x130a7c4
    // 0x130a7b0: r8 = Size
    //     0x130a7b0: add             x8, PP, #0x8c, lsl #12  ; [pp+0x8cde0] Type: Size
    //     0x130a7b4: ldr             x8, [x8, #0xde0]
    // 0x130a7b8: r3 = Null
    //     0x130a7b8: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8cde8] Null
    //     0x130a7bc: ldr             x3, [x3, #0xde8]
    // 0x130a7c0: r0 = Size()
    //     0x130a7c0: bl              #0x81d4e4  ; IsType_Size_Stub
    // 0x130a7c4: InitAsync() -> Future<bool>
    //     0x130a7c4: ldr             x0, [PP, #0x1918]  ; [pp+0x1918] TypeArguments: <bool>
    //     0x130a7c8: bl              #0x7f5e44  ; InitAsyncStub
    // 0x130a7cc: ldur            x0, [fp, #-0x10]
    // 0x130a7d0: LoadField: r6 = r0->field_7
    //     0x130a7d0: ldur            x6, [x0, #7]
    // 0x130a7d4: LoadField: r7 = r0->field_f
    //     0x130a7d4: ldur            w7, [x0, #0xf]
    // 0x130a7d8: DecompressPointer r7
    //     0x130a7d8: add             x7, x7, HEAP, lsl #32
    // 0x130a7dc: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x130a7dc: ldur            w3, [x0, #0x17]
    // 0x130a7e0: DecompressPointer r3
    //     0x130a7e0: add             x3, x3, HEAP, lsl #32
    // 0x130a7e4: LoadField: r1 = r0->field_1f
    //     0x130a7e4: ldur            w1, [x0, #0x1f]
    // 0x130a7e8: DecompressPointer r1
    //     0x130a7e8: add             x1, x1, HEAP, lsl #32
    // 0x130a7ec: r16 = true
    //     0x130a7ec: add             x16, NULL, #0x20  ; true
    // 0x130a7f0: ldur            lr, [fp, #-0x20]
    // 0x130a7f4: stp             lr, x16, [SP]
    // 0x130a7f8: ldur            x5, [fp, #-0x18]
    // 0x130a7fc: r2 = false
    //     0x130a7fc: add             x2, NULL, #0x30  ; false
    // 0x130a800: r4 = const [0, 0x8, 0x2, 0x6, hybridFallback, 0x6, size, 0x7, null]
    //     0x130a800: add             x4, PP, #0x8c, lsl #12  ; [pp+0x8cdf8] List(9) [0, 0x8, 0x2, 0x6, "hybridFallback", 0x6, "size", 0x7, Null]
    //     0x130a804: ldr             x4, [x4, #0xdf8]
    // 0x130a808: r0 = sendCreateMessage()
    //     0x130a808: bl              #0x130a8ec  ; [package:flutter/src/services/platform_views.dart] _AndroidViewControllerInternals::sendCreateMessage
    // 0x130a80c: mov             x1, x0
    // 0x130a810: stur            x1, [fp, #-0x18]
    // 0x130a814: r0 = Await()
    //     0x130a814: bl              #0x7f5c00  ; AwaitStub
    // 0x130a818: mov             x3, x0
    // 0x130a81c: stur            x3, [fp, #-0x20]
    // 0x130a820: r0 = 60
    //     0x130a820: mov             x0, #0x3c
    // 0x130a824: branchIfSmi(r3, 0x130a830)
    //     0x130a824: tbz             w3, #0, #0x130a830
    // 0x130a828: r0 = LoadClassIdInstr(r3)
    //     0x130a828: ldur            x0, [x3, #-1]
    //     0x130a82c: ubfx            x0, x0, #0xc, #0x14
    // 0x130a830: sub             x16, x0, #0x3c
    // 0x130a834: cmp             x16, #1
    // 0x130a838: b.hi            #0x130a8a8
    // 0x130a83c: ldur            x0, [fp, #-0x10]
    // 0x130a840: LoadField: r4 = r0->field_27
    //     0x130a840: ldur            w4, [x0, #0x27]
    // 0x130a844: DecompressPointer r4
    //     0x130a844: add             x4, x4, HEAP, lsl #32
    // 0x130a848: mov             x0, x4
    // 0x130a84c: stur            x4, [fp, #-0x18]
    // 0x130a850: r2 = Null
    //     0x130a850: mov             x2, NULL
    // 0x130a854: r1 = Null
    //     0x130a854: mov             x1, NULL
    // 0x130a858: r4 = LoadClassIdInstr(r0)
    //     0x130a858: ldur            x4, [x0, #-1]
    //     0x130a85c: ubfx            x4, x4, #0xc, #0x14
    // 0x130a860: cmp             x4, #0xac9
    // 0x130a864: b.eq            #0x130a87c
    // 0x130a868: r8 = _TextureAndroidViewControllerInternals
    //     0x130a868: add             x8, PP, #0x8c, lsl #12  ; [pp+0x8ce00] Type: _TextureAndroidViewControllerInternals
    //     0x130a86c: ldr             x8, [x8, #0xe00]
    // 0x130a870: r3 = Null
    //     0x130a870: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8ce08] Null
    //     0x130a874: ldr             x3, [x3, #0xe08]
    // 0x130a878: r0 = DefaultTypeTest()
    //     0x130a878: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x130a87c: ldur            x0, [fp, #-0x20]
    // 0x130a880: ldur            x1, [fp, #-0x18]
    // 0x130a884: StoreField: r1->field_b = r0
    //     0x130a884: stur            w0, [x1, #0xb]
    //     0x130a888: tbz             w0, #0, #0x130a8a4
    //     0x130a88c: ldurb           w16, [x1, #-1]
    //     0x130a890: ldurb           w17, [x0, #-1]
    //     0x130a894: and             x16, x17, x16, lsr #2
    //     0x130a898: tst             x16, HEAP, lsr #32
    //     0x130a89c: b.eq            #0x130a8a4
    //     0x130a8a0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x130a8a4: b               #0x130a8d0
    // 0x130a8a8: ldur            x0, [fp, #-0x10]
    // 0x130a8ac: r0 = _HybridAndroidViewControllerInternals()
    //     0x130a8ac: bl              #0x130a8e0  ; Allocate_HybridAndroidViewControllerInternalsStub -> _HybridAndroidViewControllerInternals (size=0x8)
    // 0x130a8b0: ldur            x1, [fp, #-0x10]
    // 0x130a8b4: StoreField: r1->field_27 = r0
    //     0x130a8b4: stur            w0, [x1, #0x27]
    //     0x130a8b8: ldurb           w16, [x1, #-1]
    //     0x130a8bc: ldurb           w17, [x0, #-1]
    //     0x130a8c0: and             x16, x17, x16, lsr #2
    //     0x130a8c4: tst             x16, HEAP, lsr #32
    //     0x130a8c8: b.eq            #0x130a8d0
    //     0x130a8cc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x130a8d0: r0 = true
    //     0x130a8d0: add             x0, NULL, #0x20  ; true
    // 0x130a8d4: r0 = ReturnAsyncNotFuture()
    //     0x130a8d4: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x130a8d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x130a8d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x130a8dc: b               #0x130a788
  }
}

// class id: 2766, size: 0x10, field offset: 0x8
//   const constructor, 
class _CreationParams extends Object {
}

// class id: 2767, size: 0x1c, field offset: 0x8
class _AndroidMotionEventConverter extends Object {

  late (dynamic, Offset) => Offset pointTransformer; // offset: 0x14

  _ handlePointerUpEvent(/* No info */) {
    // ** addr: 0xba40c0, size: 0x60
    // 0xba40c0: EnterFrame
    //     0xba40c0: stp             fp, lr, [SP, #-0x10]!
    //     0xba40c4: mov             fp, SP
    // 0xba40c8: AllocStack(0x8)
    //     0xba40c8: sub             SP, SP, #8
    // 0xba40cc: SetupParameters(_AndroidMotionEventConverter this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1 */)
    //     0xba40cc: stur            x1, [fp, #-8]
    //     0xba40d0: mov             x16, x2
    //     0xba40d4: mov             x2, x1
    //     0xba40d8: mov             x1, x16
    // 0xba40dc: CheckStackOverflow
    //     0xba40dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba40e0: cmp             SP, x16
    //     0xba40e4: b.ls            #0xba4118
    // 0xba40e8: r0 = LoadClassIdInstr(r1)
    //     0xba40e8: ldur            x0, [x1, #-1]
    //     0xba40ec: ubfx            x0, x0, #0xc, #0x14
    // 0xba40f0: r0 = GDT[cid_x0 + -0x1]()
    //     0xba40f0: sub             lr, x0, #1
    //     0xba40f4: ldr             lr, [x21, lr, lsl #3]
    //     0xba40f8: blr             lr
    // 0xba40fc: ldur            x1, [fp, #-8]
    // 0xba4100: mov             x2, x0
    // 0xba4104: r0 = _remove()
    //     0xba4104: bl              #0xba4120  ; [package:flutter/src/services/platform_views.dart] _AndroidMotionEventConverter::_remove
    // 0xba4108: r0 = Null
    //     0xba4108: mov             x0, NULL
    // 0xba410c: LeaveFrame
    //     0xba410c: mov             SP, fp
    //     0xba4110: ldp             fp, lr, [SP], #0x10
    // 0xba4114: ret
    //     0xba4114: ret             
    // 0xba4118: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba4118: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba411c: b               #0xba40e8
  }
  _ _remove(/* No info */) {
    // ** addr: 0xba4120, size: 0x108
    // 0xba4120: EnterFrame
    //     0xba4120: stp             fp, lr, [SP, #-0x10]!
    //     0xba4124: mov             fp, SP
    // 0xba4128: AllocStack(0x20)
    //     0xba4128: sub             SP, SP, #0x20
    // 0xba412c: SetupParameters(_AndroidMotionEventConverter this /* r1 => r3, fp-0x10 */)
    //     0xba412c: mov             x3, x1
    //     0xba4130: stur            x1, [fp, #-0x10]
    // 0xba4134: CheckStackOverflow
    //     0xba4134: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba4138: cmp             SP, x16
    //     0xba413c: b.ls            #0xba421c
    // 0xba4140: LoadField: r4 = r3->field_7
    //     0xba4140: ldur            w4, [x3, #7]
    // 0xba4144: DecompressPointer r4
    //     0xba4144: add             x4, x4, HEAP, lsl #32
    // 0xba4148: r0 = BoxInt64Instr(r2)
    //     0xba4148: sbfiz           x0, x2, #1, #0x1f
    //     0xba414c: cmp             x2, x0, asr #1
    //     0xba4150: b.eq            #0xba415c
    //     0xba4154: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba4158: stur            x2, [x0, #7]
    // 0xba415c: mov             x1, x4
    // 0xba4160: mov             x2, x0
    // 0xba4164: stur            x0, [fp, #-8]
    // 0xba4168: r0 = remove()
    //     0xba4168: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xba416c: ldur            x0, [fp, #-0x10]
    // 0xba4170: LoadField: r3 = r0->field_f
    //     0xba4170: ldur            w3, [x0, #0xf]
    // 0xba4174: DecompressPointer r3
    //     0xba4174: add             x3, x3, HEAP, lsl #32
    // 0xba4178: stur            x3, [fp, #-0x20]
    // 0xba417c: LoadField: r4 = r0->field_b
    //     0xba417c: ldur            w4, [x0, #0xb]
    // 0xba4180: DecompressPointer r4
    //     0xba4180: add             x4, x4, HEAP, lsl #32
    // 0xba4184: mov             x1, x4
    // 0xba4188: ldur            x2, [fp, #-8]
    // 0xba418c: stur            x4, [fp, #-0x18]
    // 0xba4190: r0 = _getValueOrData()
    //     0xba4190: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xba4194: ldur            x3, [fp, #-0x18]
    // 0xba4198: LoadField: r1 = r3->field_f
    //     0xba4198: ldur            w1, [x3, #0xf]
    // 0xba419c: DecompressPointer r1
    //     0xba419c: add             x1, x1, HEAP, lsl #32
    // 0xba41a0: cmp             w1, w0
    // 0xba41a4: b.ne            #0xba41ac
    // 0xba41a8: r0 = Null
    //     0xba41a8: mov             x0, NULL
    // 0xba41ac: cmp             w0, NULL
    // 0xba41b0: b.eq            #0xba4224
    // 0xba41b4: LoadField: r2 = r0->field_7
    //     0xba41b4: ldur            x2, [x0, #7]
    // 0xba41b8: r0 = BoxInt64Instr(r2)
    //     0xba41b8: sbfiz           x0, x2, #1, #0x1f
    //     0xba41bc: cmp             x2, x0, asr #1
    //     0xba41c0: b.eq            #0xba41cc
    //     0xba41c4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba41c8: stur            x2, [x0, #7]
    // 0xba41cc: ldur            x1, [fp, #-0x20]
    // 0xba41d0: mov             x2, x0
    // 0xba41d4: r0 = remove()
    //     0xba41d4: bl              #0x115bfd0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::remove
    // 0xba41d8: ldur            x1, [fp, #-0x18]
    // 0xba41dc: ldur            x2, [fp, #-8]
    // 0xba41e0: r0 = remove()
    //     0xba41e0: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xba41e4: ldur            x1, [fp, #-0x18]
    // 0xba41e8: LoadField: r2 = r1->field_13
    //     0xba41e8: ldur            w2, [x1, #0x13]
    // 0xba41ec: r3 = LoadInt32Instr(r2)
    //     0xba41ec: sbfx            x3, x2, #1, #0x1f
    // 0xba41f0: asr             x2, x3, #1
    // 0xba41f4: ArrayLoad: r3 = r1[0]  ; List_4
    //     0xba41f4: ldur            w3, [x1, #0x17]
    // 0xba41f8: r1 = LoadInt32Instr(r3)
    //     0xba41f8: sbfx            x1, x3, #1, #0x1f
    // 0xba41fc: sub             x3, x2, x1
    // 0xba4200: cbnz            x3, #0xba420c
    // 0xba4204: ldur            x1, [fp, #-0x10]
    // 0xba4208: ArrayStore: r1[0] = rNULL  ; List_4
    //     0xba4208: stur            NULL, [x1, #0x17]
    // 0xba420c: r0 = Null
    //     0xba420c: mov             x0, NULL
    // 0xba4210: LeaveFrame
    //     0xba4210: mov             SP, fp
    //     0xba4214: ldp             fp, lr, [SP], #0x10
    // 0xba4218: ret
    //     0xba4218: ret             
    // 0xba421c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba421c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba4220: b               #0xba4140
    // 0xba4224: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xba4224: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ toAndroidMotionEvent(/* No info */) {
    // ** addr: 0xba4228, size: 0x76c
    // 0xba4228: EnterFrame
    //     0xba4228: stp             fp, lr, [SP, #-0x10]!
    //     0xba422c: mov             fp, SP
    // 0xba4230: AllocStack(0x78)
    //     0xba4230: sub             SP, SP, #0x78
    // 0xba4234: SetupParameters(_AndroidMotionEventConverter this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xba4234: mov             x0, x1
    //     0xba4238: stur            x1, [fp, #-8]
    //     0xba423c: mov             x1, x2
    //     0xba4240: stur            x2, [fp, #-0x10]
    // 0xba4244: CheckStackOverflow
    //     0xba4244: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba4248: cmp             SP, x16
    //     0xba424c: b.ls            #0xba4988
    // 0xba4250: r1 = 1
    //     0xba4250: mov             x1, #1
    // 0xba4254: r0 = AllocateContext()
    //     0xba4254: bl              #0x13de838  ; AllocateContextStub
    // 0xba4258: mov             x2, x0
    // 0xba425c: ldur            x0, [fp, #-8]
    // 0xba4260: stur            x2, [fp, #-0x20]
    // 0xba4264: StoreField: r2->field_f = r0
    //     0xba4264: stur            w0, [x2, #0xf]
    // 0xba4268: LoadField: r3 = r0->field_7
    //     0xba4268: ldur            w3, [x0, #7]
    // 0xba426c: DecompressPointer r3
    //     0xba426c: add             x3, x3, HEAP, lsl #32
    // 0xba4270: stur            x3, [fp, #-0x18]
    // 0xba4274: r1 = <int, AndroidPointerCoords>
    //     0xba4274: add             x1, PP, #0x7d, lsl #12  ; [pp+0x7d3d0] TypeArguments: <int, AndroidPointerCoords>
    //     0xba4278: ldr             x1, [x1, #0x3d0]
    // 0xba427c: r0 = _CompactKeysIterable()
    //     0xba427c: bl              #0x8353d0  ; Allocate_CompactKeysIterableStub -> _CompactKeysIterable<X0> (size=0x10)
    // 0xba4280: mov             x1, x0
    // 0xba4284: ldur            x0, [fp, #-0x18]
    // 0xba4288: StoreField: r1->field_b = r0
    //     0xba4288: stur            w0, [x1, #0xb]
    // 0xba428c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xba428c: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xba4290: r0 = toList()
    //     0xba4290: bl              #0xb08ca4  ; [dart:core] Iterable::toList
    // 0xba4294: mov             x3, x0
    // 0xba4298: ldur            x2, [fp, #-0x10]
    // 0xba429c: stur            x3, [fp, #-0x28]
    // 0xba42a0: r0 = LoadClassIdInstr(r2)
    //     0xba42a0: ldur            x0, [x2, #-1]
    //     0xba42a4: ubfx            x0, x0, #0xc, #0x14
    // 0xba42a8: mov             x1, x2
    // 0xba42ac: r0 = GDT[cid_x0 + -0x1]()
    //     0xba42ac: sub             lr, x0, #1
    //     0xba42b0: ldr             lr, [x21, lr, lsl #3]
    //     0xba42b4: blr             lr
    // 0xba42b8: mov             x2, x0
    // 0xba42bc: r0 = BoxInt64Instr(r2)
    //     0xba42bc: sbfiz           x0, x2, #1, #0x1f
    //     0xba42c0: cmp             x2, x0, asr #1
    //     0xba42c4: b.eq            #0xba42d0
    //     0xba42c8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba42cc: stur            x2, [x0, #7]
    // 0xba42d0: ldur            x1, [fp, #-0x28]
    // 0xba42d4: mov             x2, x0
    // 0xba42d8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xba42d8: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xba42dc: r0 = indexOf()
    //     0xba42dc: bl              #0x9f1368  ; [dart:collection] ListBase::indexOf
    // 0xba42e0: mov             x3, x0
    // 0xba42e4: ldur            x2, [fp, #-0x28]
    // 0xba42e8: stur            x3, [fp, #-0x38]
    // 0xba42ec: LoadField: r4 = r2->field_b
    //     0xba42ec: ldur            w4, [x2, #0xb]
    // 0xba42f0: ldur            x5, [fp, #-0x10]
    // 0xba42f4: stur            x4, [fp, #-0x30]
    // 0xba42f8: r0 = LoadClassIdInstr(r5)
    //     0xba42f8: ldur            x0, [x5, #-1]
    //     0xba42fc: ubfx            x0, x0, #0xc, #0x14
    // 0xba4300: mov             x1, x5
    // 0xba4304: r0 = GDT[cid_x0 + 0x13884]()
    //     0xba4304: mov             x17, #0x3884
    //     0xba4308: movk            x17, #1, lsl #16
    //     0xba430c: add             lr, x0, x17
    //     0xba4310: ldr             lr, [x21, lr, lsl #3]
    //     0xba4314: blr             lr
    // 0xba4318: ubfx            x0, x0, #0, #0x20
    // 0xba431c: and             w1, w0, #0xff
    // 0xba4320: cmp             w1, #1
    // 0xba4324: b.ne            #0xba4338
    // 0xba4328: r0 = Null
    //     0xba4328: mov             x0, NULL
    // 0xba432c: LeaveFrame
    //     0xba432c: mov             SP, fp
    //     0xba4330: ldp             fp, lr, [SP], #0x10
    // 0xba4334: ret
    //     0xba4334: ret             
    // 0xba4338: cmp             w1, #2
    // 0xba433c: b.ne            #0xba4398
    // 0xba4340: ldur            x3, [fp, #-0x10]
    // 0xba4344: ldur            x2, [fp, #-0x38]
    // 0xba4348: r0 = LoadClassIdInstr(r3)
    //     0xba4348: ldur            x0, [x3, #-1]
    //     0xba434c: ubfx            x0, x0, #0xc, #0x14
    // 0xba4350: mov             x1, x3
    // 0xba4354: r0 = GDT[cid_x0 + 0x13884]()
    //     0xba4354: mov             x17, #0x3884
    //     0xba4358: movk            x17, #1, lsl #16
    //     0xba435c: add             lr, x0, x17
    //     0xba4360: ldr             lr, [x21, lr, lsl #3]
    //     0xba4364: blr             lr
    // 0xba4368: asr             x1, x0, #8
    // 0xba436c: sub             x0, x1, #1
    // 0xba4370: ldur            x3, [fp, #-0x38]
    // 0xba4374: r1 = LoadInt32Instr(r3)
    //     0xba4374: sbfx            x1, x3, #1, #0x1f
    //     0xba4378: tbz             w3, #0, #0xba4380
    //     0xba437c: ldur            x1, [x3, #7]
    // 0xba4380: cmp             x1, x0
    // 0xba4384: b.eq            #0xba439c
    // 0xba4388: r0 = Null
    //     0xba4388: mov             x0, NULL
    // 0xba438c: LeaveFrame
    //     0xba438c: mov             SP, fp
    //     0xba4390: ldp             fp, lr, [SP], #0x10
    // 0xba4394: ret
    //     0xba4394: ret             
    // 0xba4398: ldur            x3, [fp, #-0x38]
    // 0xba439c: ldur            x0, [fp, #-0x10]
    // 0xba43a0: r2 = Null
    //     0xba43a0: mov             x2, NULL
    // 0xba43a4: r1 = Null
    //     0xba43a4: mov             x1, NULL
    // 0xba43a8: cmp             w0, NULL
    // 0xba43ac: b.eq            #0xba43d4
    // 0xba43b0: branchIfSmi(r0, 0xba43d4)
    //     0xba43b0: tbz             w0, #0, #0xba43d4
    // 0xba43b4: r3 = LoadClassIdInstr(r0)
    //     0xba43b4: ldur            x3, [x0, #-1]
    //     0xba43b8: ubfx            x3, x3, #0xc, #0x14
    // 0xba43bc: r17 = 4159
    //     0xba43bc: mov             x17, #0x103f
    // 0xba43c0: cmp             x3, x17
    // 0xba43c4: b.eq            #0xba43dc
    // 0xba43c8: r17 = 5288
    //     0xba43c8: mov             x17, #0x14a8
    // 0xba43cc: cmp             x3, x17
    // 0xba43d0: b.eq            #0xba43dc
    // 0xba43d4: r0 = false
    //     0xba43d4: add             x0, NULL, #0x30  ; false
    // 0xba43d8: b               #0xba43e0
    // 0xba43dc: r0 = true
    //     0xba43dc: add             x0, NULL, #0x20  ; true
    // 0xba43e0: tbnz            w0, #4, #0xba43f8
    // 0xba43e4: ldur            x3, [fp, #-0x30]
    // 0xba43e8: cmp             w3, #2
    // 0xba43ec: b.ne            #0xba43fc
    // 0xba43f0: r2 = 0
    //     0xba43f0: mov             x2, #0
    // 0xba43f4: b               #0xba45ec
    // 0xba43f8: ldur            x3, [fp, #-0x30]
    // 0xba43fc: ldur            x0, [fp, #-0x10]
    // 0xba4400: r2 = Null
    //     0xba4400: mov             x2, NULL
    // 0xba4404: r1 = Null
    //     0xba4404: mov             x1, NULL
    // 0xba4408: cmp             w0, NULL
    // 0xba440c: b.eq            #0xba4434
    // 0xba4410: branchIfSmi(r0, 0xba4434)
    //     0xba4410: tbz             w0, #0, #0xba4434
    // 0xba4414: r3 = LoadClassIdInstr(r0)
    //     0xba4414: ldur            x3, [x0, #-1]
    //     0xba4418: ubfx            x3, x3, #0xc, #0x14
    // 0xba441c: r17 = 4155
    //     0xba441c: mov             x17, #0x103b
    // 0xba4420: cmp             x3, x17
    // 0xba4424: b.eq            #0xba443c
    // 0xba4428: r17 = 5284
    //     0xba4428: mov             x17, #0x14a4
    // 0xba442c: cmp             x3, x17
    // 0xba4430: b.eq            #0xba443c
    // 0xba4434: r0 = false
    //     0xba4434: add             x0, NULL, #0x30  ; false
    // 0xba4438: b               #0xba4440
    // 0xba443c: r0 = true
    //     0xba443c: add             x0, NULL, #0x20  ; true
    // 0xba4440: tbnz            w0, #4, #0xba4458
    // 0xba4444: ldur            x0, [fp, #-0x30]
    // 0xba4448: cmp             w0, #2
    // 0xba444c: b.ne            #0xba4458
    // 0xba4450: r2 = 2
    //     0xba4450: mov             x2, #2
    // 0xba4454: b               #0xba45ec
    // 0xba4458: ldur            x0, [fp, #-0x10]
    // 0xba445c: r2 = Null
    //     0xba445c: mov             x2, NULL
    // 0xba4460: r1 = Null
    //     0xba4460: mov             x1, NULL
    // 0xba4464: cmp             w0, NULL
    // 0xba4468: b.eq            #0xba4490
    // 0xba446c: branchIfSmi(r0, 0xba4490)
    //     0xba446c: tbz             w0, #0, #0xba4490
    // 0xba4470: r3 = LoadClassIdInstr(r0)
    //     0xba4470: ldur            x3, [x0, #-1]
    //     0xba4474: ubfx            x3, x3, #0xc, #0x14
    // 0xba4478: r17 = 4159
    //     0xba4478: mov             x17, #0x103f
    // 0xba447c: cmp             x3, x17
    // 0xba4480: b.eq            #0xba4498
    // 0xba4484: r17 = 5288
    //     0xba4484: mov             x17, #0x14a8
    // 0xba4488: cmp             x3, x17
    // 0xba448c: b.eq            #0xba4498
    // 0xba4490: r0 = false
    //     0xba4490: add             x0, NULL, #0x30  ; false
    // 0xba4494: b               #0xba449c
    // 0xba4498: r0 = true
    //     0xba4498: add             x0, NULL, #0x20  ; true
    // 0xba449c: tbnz            w0, #4, #0xba44d0
    // 0xba44a0: ldur            x3, [fp, #-0x38]
    // 0xba44a4: r0 = LoadInt32Instr(r3)
    //     0xba44a4: sbfx            x0, x3, #1, #0x1f
    //     0xba44a8: tbz             w3, #0, #0xba44b0
    //     0xba44ac: ldur            x0, [x3, #7]
    // 0xba44b0: lsl             w1, w0, #8
    // 0xba44b4: and             w0, w1, #0xff00
    // 0xba44b8: ubfx            x0, x0, #0, #0x20
    // 0xba44bc: r16 = 5
    //     0xba44bc: mov             x16, #5
    // 0xba44c0: orr             x1, x0, x16
    // 0xba44c4: lsl             x0, x1, #1
    // 0xba44c8: mov             x2, x0
    // 0xba44cc: b               #0xba45ec
    // 0xba44d0: ldur            x3, [fp, #-0x38]
    // 0xba44d4: ldur            x0, [fp, #-0x10]
    // 0xba44d8: r2 = Null
    //     0xba44d8: mov             x2, NULL
    // 0xba44dc: r1 = Null
    //     0xba44dc: mov             x1, NULL
    // 0xba44e0: cmp             w0, NULL
    // 0xba44e4: b.eq            #0xba450c
    // 0xba44e8: branchIfSmi(r0, 0xba450c)
    //     0xba44e8: tbz             w0, #0, #0xba450c
    // 0xba44ec: r3 = LoadClassIdInstr(r0)
    //     0xba44ec: ldur            x3, [x0, #-1]
    //     0xba44f0: ubfx            x3, x3, #0xc, #0x14
    // 0xba44f4: r17 = 4155
    //     0xba44f4: mov             x17, #0x103b
    // 0xba44f8: cmp             x3, x17
    // 0xba44fc: b.eq            #0xba4514
    // 0xba4500: r17 = 5284
    //     0xba4500: mov             x17, #0x14a4
    // 0xba4504: cmp             x3, x17
    // 0xba4508: b.eq            #0xba4514
    // 0xba450c: r0 = false
    //     0xba450c: add             x0, NULL, #0x30  ; false
    // 0xba4510: b               #0xba4518
    // 0xba4514: r0 = true
    //     0xba4514: add             x0, NULL, #0x20  ; true
    // 0xba4518: tbnz            w0, #4, #0xba4548
    // 0xba451c: ldur            x0, [fp, #-0x38]
    // 0xba4520: r1 = LoadInt32Instr(r0)
    //     0xba4520: sbfx            x1, x0, #1, #0x1f
    //     0xba4524: tbz             w0, #0, #0xba452c
    //     0xba4528: ldur            x1, [x0, #7]
    // 0xba452c: lsl             w0, w1, #8
    // 0xba4530: and             w1, w0, #0xff00
    // 0xba4534: ubfx            x1, x1, #0, #0x20
    // 0xba4538: orr             x0, x1, #6
    // 0xba453c: lsl             x1, x0, #1
    // 0xba4540: mov             x2, x1
    // 0xba4544: b               #0xba45ec
    // 0xba4548: ldur            x0, [fp, #-0x10]
    // 0xba454c: r2 = Null
    //     0xba454c: mov             x2, NULL
    // 0xba4550: r1 = Null
    //     0xba4550: mov             x1, NULL
    // 0xba4554: cmp             w0, NULL
    // 0xba4558: b.eq            #0xba4580
    // 0xba455c: branchIfSmi(r0, 0xba4580)
    //     0xba455c: tbz             w0, #0, #0xba4580
    // 0xba4560: r3 = LoadClassIdInstr(r0)
    //     0xba4560: ldur            x3, [x0, #-1]
    //     0xba4564: ubfx            x3, x3, #0xc, #0x14
    // 0xba4568: r17 = 4157
    //     0xba4568: mov             x17, #0x103d
    // 0xba456c: cmp             x3, x17
    // 0xba4570: b.eq            #0xba4588
    // 0xba4574: r17 = 5286
    //     0xba4574: mov             x17, #0x14a6
    // 0xba4578: cmp             x3, x17
    // 0xba457c: b.eq            #0xba4588
    // 0xba4580: r0 = false
    //     0xba4580: add             x0, NULL, #0x30  ; false
    // 0xba4584: b               #0xba458c
    // 0xba4588: r0 = true
    //     0xba4588: add             x0, NULL, #0x20  ; true
    // 0xba458c: tbnz            w0, #4, #0xba4598
    // 0xba4590: r2 = 4
    //     0xba4590: mov             x2, #4
    // 0xba4594: b               #0xba45ec
    // 0xba4598: ldur            x0, [fp, #-0x10]
    // 0xba459c: r2 = Null
    //     0xba459c: mov             x2, NULL
    // 0xba45a0: r1 = Null
    //     0xba45a0: mov             x1, NULL
    // 0xba45a4: cmp             w0, NULL
    // 0xba45a8: b.eq            #0xba45d0
    // 0xba45ac: branchIfSmi(r0, 0xba45d0)
    //     0xba45ac: tbz             w0, #0, #0xba45d0
    // 0xba45b0: r3 = LoadClassIdInstr(r0)
    //     0xba45b0: ldur            x3, [x0, #-1]
    //     0xba45b4: ubfx            x3, x3, #0xc, #0x14
    // 0xba45b8: r17 = 4139
    //     0xba45b8: mov             x17, #0x102b
    // 0xba45bc: cmp             x3, x17
    // 0xba45c0: b.eq            #0xba45d8
    // 0xba45c4: r17 = 5276
    //     0xba45c4: mov             x17, #0x149c
    // 0xba45c8: cmp             x3, x17
    // 0xba45cc: b.eq            #0xba45d8
    // 0xba45d0: r0 = false
    //     0xba45d0: add             x0, NULL, #0x30  ; false
    // 0xba45d4: b               #0xba45dc
    // 0xba45d8: r0 = true
    //     0xba45d8: add             x0, NULL, #0x20  ; true
    // 0xba45dc: tbnz            w0, #4, #0xba45e8
    // 0xba45e0: r2 = 6
    //     0xba45e0: mov             x2, #6
    // 0xba45e4: b               #0xba45ec
    // 0xba45e8: r2 = Null
    //     0xba45e8: mov             x2, NULL
    // 0xba45ec: stur            x2, [fp, #-0x38]
    // 0xba45f0: cmp             w2, NULL
    // 0xba45f4: b.ne            #0xba4608
    // 0xba45f8: r0 = Null
    //     0xba45f8: mov             x0, NULL
    // 0xba45fc: LeaveFrame
    //     0xba45fc: mov             SP, fp
    //     0xba4600: ldp             fp, lr, [SP], #0x10
    // 0xba4604: ret
    //     0xba4604: ret             
    // 0xba4608: ldur            x0, [fp, #-8]
    // 0xba460c: ldur            x3, [fp, #-0x10]
    // 0xba4610: ldur            x4, [fp, #-0x18]
    // 0xba4614: ArrayLoad: r5 = r0[0]  ; List_4
    //     0xba4614: ldur            w5, [x0, #0x17]
    // 0xba4618: DecompressPointer r5
    //     0xba4618: add             x5, x5, HEAP, lsl #32
    // 0xba461c: stur            x5, [fp, #-0x30]
    // 0xba4620: cmp             w5, NULL
    // 0xba4624: b.eq            #0xba4990
    // 0xba4628: r0 = LoadClassIdInstr(r3)
    //     0xba4628: ldur            x0, [x3, #-1]
    //     0xba462c: ubfx            x0, x0, #0xc, #0x14
    // 0xba4630: mov             x1, x3
    // 0xba4634: r0 = GDT[cid_x0 + 0x15eb5]()
    //     0xba4634: mov             x17, #0x5eb5
    //     0xba4638: movk            x17, #1, lsl #16
    //     0xba463c: add             lr, x0, x17
    //     0xba4640: ldr             lr, [x21, lr, lsl #3]
    //     0xba4644: blr             lr
    // 0xba4648: LoadField: r1 = r0->field_7
    //     0xba4648: ldur            x1, [x0, #7]
    // 0xba464c: r0 = 1000
    //     0xba464c: mov             x0, #0x3e8
    // 0xba4650: sdiv            x3, x1, x0
    // 0xba4654: ldur            x0, [fp, #-0x18]
    // 0xba4658: stur            x3, [fp, #-0x48]
    // 0xba465c: LoadField: r1 = r0->field_13
    //     0xba465c: ldur            w1, [x0, #0x13]
    // 0xba4660: r2 = LoadInt32Instr(r1)
    //     0xba4660: sbfx            x2, x1, #1, #0x1f
    // 0xba4664: asr             x1, x2, #1
    // 0xba4668: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xba4668: ldur            w2, [x0, #0x17]
    // 0xba466c: r0 = LoadInt32Instr(r2)
    //     0xba466c: sbfx            x0, x2, #1, #0x1f
    // 0xba4670: sub             x4, x1, x0
    // 0xba4674: ldur            x2, [fp, #-0x20]
    // 0xba4678: stur            x4, [fp, #-0x40]
    // 0xba467c: r1 = Function '<anonymous closure>':.
    //     0xba467c: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa1758] AnonymousClosure: (0xba4abc), in [package:flutter/src/services/platform_views.dart] _AndroidMotionEventConverter::toAndroidMotionEvent (0xba4228)
    //     0xba4680: ldr             x1, [x1, #0x758]
    // 0xba4684: r0 = AllocateClosure()
    //     0xba4684: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xba4688: r16 = <AndroidPointerProperties>
    //     0xba4688: add             x16, PP, #0xa1, lsl #12  ; [pp+0xa1760] TypeArguments: <AndroidPointerProperties>
    //     0xba468c: ldr             x16, [x16, #0x760]
    // 0xba4690: ldur            lr, [fp, #-0x28]
    // 0xba4694: stp             lr, x16, [SP, #8]
    // 0xba4698: str             x0, [SP]
    // 0xba469c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xba469c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xba46a0: r0 = map()
    //     0xba46a0: bl              #0xba574c  ; [dart:collection] ListBase::map
    // 0xba46a4: mov             x3, x0
    // 0xba46a8: stur            x3, [fp, #-0x18]
    // 0xba46ac: LoadField: r4 = r3->field_7
    //     0xba46ac: ldur            w4, [x3, #7]
    // 0xba46b0: DecompressPointer r4
    //     0xba46b0: add             x4, x4, HEAP, lsl #32
    // 0xba46b4: mov             x0, x3
    // 0xba46b8: stur            x4, [fp, #-8]
    // 0xba46bc: r2 = Null
    //     0xba46bc: mov             x2, NULL
    // 0xba46c0: r1 = Null
    //     0xba46c0: mov             x1, NULL
    // 0xba46c4: cmp             w0, NULL
    // 0xba46c8: b.eq            #0xba4760
    // 0xba46cc: branchIfSmi(r0, 0xba4760)
    //     0xba46cc: tbz             w0, #0, #0xba4760
    // 0xba46d0: r3 = LoadClassIdInstr(r0)
    //     0xba46d0: ldur            x3, [x0, #-1]
    //     0xba46d4: ubfx            x3, x3, #0xc, #0x14
    // 0xba46d8: r17 = 7724
    //     0xba46d8: mov             x17, #0x1e2c
    // 0xba46dc: cmp             x3, x17
    // 0xba46e0: b.eq            #0xba4768
    // 0xba46e4: r4 = LoadClassIdInstr(r0)
    //     0xba46e4: ldur            x4, [x0, #-1]
    //     0xba46e8: ubfx            x4, x4, #0xc, #0x14
    // 0xba46ec: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0xba46f0: ldr             x3, [x3, #0x18]
    // 0xba46f4: ldr             x3, [x3, x4, lsl #3]
    // 0xba46f8: LoadField: r3 = r3->field_2b
    //     0xba46f8: ldur            w3, [x3, #0x2b]
    // 0xba46fc: DecompressPointer r3
    //     0xba46fc: add             x3, x3, HEAP, lsl #32
    // 0xba4700: cmp             w3, NULL
    // 0xba4704: b.eq            #0xba4760
    // 0xba4708: LoadField: r3 = r3->field_f
    //     0xba4708: ldur            w3, [x3, #0xf]
    // 0xba470c: lsr             x3, x3, #3
    // 0xba4710: r17 = 7724
    //     0xba4710: mov             x17, #0x1e2c
    // 0xba4714: cmp             x3, x17
    // 0xba4718: b.eq            #0xba4768
    // 0xba471c: r3 = SubtypeTestCache
    //     0xba471c: add             x3, PP, #0xa1, lsl #12  ; [pp+0xa1768] SubtypeTestCache
    //     0xba4720: ldr             x3, [x3, #0x768]
    // 0xba4724: r30 = Subtype1TestCacheStub
    //     0xba4724: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0xba4728: LoadField: r30 = r30->field_7
    //     0xba4728: ldur            lr, [lr, #7]
    // 0xba472c: blr             lr
    // 0xba4730: cmp             w7, NULL
    // 0xba4734: b.eq            #0xba4740
    // 0xba4738: tbnz            w7, #4, #0xba4760
    // 0xba473c: b               #0xba4768
    // 0xba4740: r8 = EfficientLengthIterable
    //     0xba4740: add             x8, PP, #0xa1, lsl #12  ; [pp+0xa1770] Type: EfficientLengthIterable
    //     0xba4744: ldr             x8, [x8, #0x770]
    // 0xba4748: r3 = SubtypeTestCache
    //     0xba4748: add             x3, PP, #0xa1, lsl #12  ; [pp+0xa1778] SubtypeTestCache
    //     0xba474c: ldr             x3, [x3, #0x778]
    // 0xba4750: r30 = InstanceOfStub
    //     0xba4750: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0xba4754: LoadField: r30 = r30->field_7
    //     0xba4754: ldur            lr, [lr, #7]
    // 0xba4758: blr             lr
    // 0xba475c: b               #0xba476c
    // 0xba4760: r0 = false
    //     0xba4760: add             x0, NULL, #0x30  ; false
    // 0xba4764: b               #0xba476c
    // 0xba4768: r0 = true
    //     0xba4768: add             x0, NULL, #0x20  ; true
    // 0xba476c: tbnz            w0, #4, #0xba4780
    // 0xba4770: ldur            x1, [fp, #-8]
    // 0xba4774: ldur            x2, [fp, #-0x18]
    // 0xba4778: r0 = _GrowableList._ofEfficientLengthIterable()
    //     0xba4778: bl              #0x7d732c  ; [dart:core] _GrowableList::_GrowableList._ofEfficientLengthIterable
    // 0xba477c: b               #0xba478c
    // 0xba4780: ldur            x1, [fp, #-8]
    // 0xba4784: ldur            x2, [fp, #-0x18]
    // 0xba4788: r0 = _GrowableList._ofOther()
    //     0xba4788: bl              #0x7d94b4  ; [dart:core] _GrowableList::_GrowableList._ofOther
    // 0xba478c: ldur            x2, [fp, #-0x20]
    // 0xba4790: stur            x0, [fp, #-8]
    // 0xba4794: r1 = Function '<anonymous closure>':.
    //     0xba4794: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa1780] AnonymousClosure: (0xba4a40), in [package:flutter/src/services/platform_views.dart] _AndroidMotionEventConverter::toAndroidMotionEvent (0xba4228)
    //     0xba4798: ldr             x1, [x1, #0x780]
    // 0xba479c: r0 = AllocateClosure()
    //     0xba479c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xba47a0: r16 = <AndroidPointerCoords>
    //     0xba47a0: add             x16, PP, #0xa1, lsl #12  ; [pp+0xa1788] TypeArguments: <AndroidPointerCoords>
    //     0xba47a4: ldr             x16, [x16, #0x788]
    // 0xba47a8: ldur            lr, [fp, #-0x28]
    // 0xba47ac: stp             lr, x16, [SP, #8]
    // 0xba47b0: str             x0, [SP]
    // 0xba47b4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xba47b4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xba47b8: r0 = map()
    //     0xba47b8: bl              #0xba574c  ; [dart:collection] ListBase::map
    // 0xba47bc: mov             x3, x0
    // 0xba47c0: stur            x3, [fp, #-0x20]
    // 0xba47c4: LoadField: r4 = r3->field_7
    //     0xba47c4: ldur            w4, [x3, #7]
    // 0xba47c8: DecompressPointer r4
    //     0xba47c8: add             x4, x4, HEAP, lsl #32
    // 0xba47cc: mov             x0, x3
    // 0xba47d0: stur            x4, [fp, #-0x18]
    // 0xba47d4: r2 = Null
    //     0xba47d4: mov             x2, NULL
    // 0xba47d8: r1 = Null
    //     0xba47d8: mov             x1, NULL
    // 0xba47dc: cmp             w0, NULL
    // 0xba47e0: b.eq            #0xba4878
    // 0xba47e4: branchIfSmi(r0, 0xba4878)
    //     0xba47e4: tbz             w0, #0, #0xba4878
    // 0xba47e8: r3 = LoadClassIdInstr(r0)
    //     0xba47e8: ldur            x3, [x0, #-1]
    //     0xba47ec: ubfx            x3, x3, #0xc, #0x14
    // 0xba47f0: r17 = 7724
    //     0xba47f0: mov             x17, #0x1e2c
    // 0xba47f4: cmp             x3, x17
    // 0xba47f8: b.eq            #0xba4880
    // 0xba47fc: r4 = LoadClassIdInstr(r0)
    //     0xba47fc: ldur            x4, [x0, #-1]
    //     0xba4800: ubfx            x4, x4, #0xc, #0x14
    // 0xba4804: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0xba4808: ldr             x3, [x3, #0x18]
    // 0xba480c: ldr             x3, [x3, x4, lsl #3]
    // 0xba4810: LoadField: r3 = r3->field_2b
    //     0xba4810: ldur            w3, [x3, #0x2b]
    // 0xba4814: DecompressPointer r3
    //     0xba4814: add             x3, x3, HEAP, lsl #32
    // 0xba4818: cmp             w3, NULL
    // 0xba481c: b.eq            #0xba4878
    // 0xba4820: LoadField: r3 = r3->field_f
    //     0xba4820: ldur            w3, [x3, #0xf]
    // 0xba4824: lsr             x3, x3, #3
    // 0xba4828: r17 = 7724
    //     0xba4828: mov             x17, #0x1e2c
    // 0xba482c: cmp             x3, x17
    // 0xba4830: b.eq            #0xba4880
    // 0xba4834: r3 = SubtypeTestCache
    //     0xba4834: add             x3, PP, #0xa1, lsl #12  ; [pp+0xa1790] SubtypeTestCache
    //     0xba4838: ldr             x3, [x3, #0x790]
    // 0xba483c: r30 = Subtype1TestCacheStub
    //     0xba483c: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0xba4840: LoadField: r30 = r30->field_7
    //     0xba4840: ldur            lr, [lr, #7]
    // 0xba4844: blr             lr
    // 0xba4848: cmp             w7, NULL
    // 0xba484c: b.eq            #0xba4858
    // 0xba4850: tbnz            w7, #4, #0xba4878
    // 0xba4854: b               #0xba4880
    // 0xba4858: r8 = EfficientLengthIterable
    //     0xba4858: add             x8, PP, #0xa1, lsl #12  ; [pp+0xa1798] Type: EfficientLengthIterable
    //     0xba485c: ldr             x8, [x8, #0x798]
    // 0xba4860: r3 = SubtypeTestCache
    //     0xba4860: add             x3, PP, #0xa1, lsl #12  ; [pp+0xa17a0] SubtypeTestCache
    //     0xba4864: ldr             x3, [x3, #0x7a0]
    // 0xba4868: r30 = InstanceOfStub
    //     0xba4868: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0xba486c: LoadField: r30 = r30->field_7
    //     0xba486c: ldur            lr, [lr, #7]
    // 0xba4870: blr             lr
    // 0xba4874: b               #0xba4884
    // 0xba4878: r0 = false
    //     0xba4878: add             x0, NULL, #0x30  ; false
    // 0xba487c: b               #0xba4884
    // 0xba4880: r0 = true
    //     0xba4880: add             x0, NULL, #0x20  ; true
    // 0xba4884: tbnz            w0, #4, #0xba489c
    // 0xba4888: ldur            x1, [fp, #-0x18]
    // 0xba488c: ldur            x2, [fp, #-0x20]
    // 0xba4890: r0 = _GrowableList._ofEfficientLengthIterable()
    //     0xba4890: bl              #0x7d732c  ; [dart:core] _GrowableList::_GrowableList._ofEfficientLengthIterable
    // 0xba4894: mov             x7, x0
    // 0xba4898: b               #0xba48ac
    // 0xba489c: ldur            x1, [fp, #-0x18]
    // 0xba48a0: ldur            x2, [fp, #-0x20]
    // 0xba48a4: r0 = _GrowableList._ofOther()
    //     0xba48a4: bl              #0x7d94b4  ; [dart:core] _GrowableList::_GrowableList._ofOther
    // 0xba48a8: mov             x7, x0
    // 0xba48ac: ldur            x5, [fp, #-0x10]
    // 0xba48b0: ldur            x4, [fp, #-0x38]
    // 0xba48b4: ldur            x6, [fp, #-0x30]
    // 0xba48b8: ldur            x2, [fp, #-0x48]
    // 0xba48bc: ldur            x3, [fp, #-0x40]
    // 0xba48c0: ldur            x0, [fp, #-8]
    // 0xba48c4: mov             x1, x5
    // 0xba48c8: stur            x7, [fp, #-0x18]
    // 0xba48cc: r0 = sourceFor()
    //     0xba48cc: bl              #0xba49a0  ; [package:flutter/src/services/platform_views.dart] _AndroidMotionEventConverter::sourceFor
    // 0xba48d0: mov             x2, x0
    // 0xba48d4: ldur            x1, [fp, #-0x10]
    // 0xba48d8: stur            x2, [fp, #-0x50]
    // 0xba48dc: r0 = LoadClassIdInstr(r1)
    //     0xba48dc: ldur            x0, [x1, #-1]
    //     0xba48e0: ubfx            x0, x0, #0xc, #0x14
    // 0xba48e4: r0 = GDT[cid_x0 + 0x16f9d]()
    //     0xba48e4: mov             x17, #0x6f9d
    //     0xba48e8: movk            x17, #1, lsl #16
    //     0xba48ec: add             lr, x0, x17
    //     0xba48f0: ldr             lr, [x21, lr, lsl #3]
    //     0xba48f4: blr             lr
    // 0xba48f8: mov             x1, x0
    // 0xba48fc: ldur            x0, [fp, #-0x30]
    // 0xba4900: stur            x1, [fp, #-0x60]
    // 0xba4904: r2 = LoadInt32Instr(r0)
    //     0xba4904: sbfx            x2, x0, #1, #0x1f
    //     0xba4908: tbz             w0, #0, #0xba4910
    //     0xba490c: ldur            x2, [x0, #7]
    // 0xba4910: stur            x2, [fp, #-0x58]
    // 0xba4914: r0 = AndroidMotionEvent()
    //     0xba4914: bl              #0xba4994  ; AllocateAndroidMotionEventStub -> AndroidMotionEvent (size=0x78)
    // 0xba4918: ldur            x1, [fp, #-0x58]
    // 0xba491c: StoreField: r0->field_7 = r1
    //     0xba491c: stur            x1, [x0, #7]
    // 0xba4920: ldur            x1, [fp, #-0x48]
    // 0xba4924: StoreField: r0->field_f = r1
    //     0xba4924: stur            x1, [x0, #0xf]
    // 0xba4928: ldur            x1, [fp, #-0x38]
    // 0xba492c: r2 = LoadInt32Instr(r1)
    //     0xba492c: sbfx            x2, x1, #1, #0x1f
    // 0xba4930: ArrayStore: r0[0] = r2  ; List_8
    //     0xba4930: stur            x2, [x0, #0x17]
    // 0xba4934: ldur            x1, [fp, #-0x40]
    // 0xba4938: StoreField: r0->field_1f = r1
    //     0xba4938: stur            x1, [x0, #0x1f]
    // 0xba493c: ldur            x1, [fp, #-8]
    // 0xba4940: StoreField: r0->field_27 = r1
    //     0xba4940: stur            w1, [x0, #0x27]
    // 0xba4944: ldur            x1, [fp, #-0x18]
    // 0xba4948: StoreField: r0->field_2b = r1
    //     0xba4948: stur            w1, [x0, #0x2b]
    // 0xba494c: StoreField: r0->field_2f = rZR
    //     0xba494c: stur            xzr, [x0, #0x2f]
    // 0xba4950: StoreField: r0->field_37 = rZR
    //     0xba4950: stur            xzr, [x0, #0x37]
    // 0xba4954: d0 = 1.000000
    //     0xba4954: fmov            d0, #1.00000000
    // 0xba4958: StoreField: r0->field_3f = d0
    //     0xba4958: stur            d0, [x0, #0x3f]
    // 0xba495c: StoreField: r0->field_47 = d0
    //     0xba495c: stur            d0, [x0, #0x47]
    // 0xba4960: StoreField: r0->field_4f = rZR
    //     0xba4960: stur            xzr, [x0, #0x4f]
    // 0xba4964: StoreField: r0->field_57 = rZR
    //     0xba4964: stur            xzr, [x0, #0x57]
    // 0xba4968: ldur            x1, [fp, #-0x50]
    // 0xba496c: StoreField: r0->field_5f = r1
    //     0xba496c: stur            x1, [x0, #0x5f]
    // 0xba4970: StoreField: r0->field_67 = rZR
    //     0xba4970: stur            xzr, [x0, #0x67]
    // 0xba4974: ldur            x1, [fp, #-0x60]
    // 0xba4978: StoreField: r0->field_6f = r1
    //     0xba4978: stur            x1, [x0, #0x6f]
    // 0xba497c: LeaveFrame
    //     0xba497c: mov             SP, fp
    //     0xba4980: ldp             fp, lr, [SP], #0x10
    // 0xba4984: ret
    //     0xba4984: ret             
    // 0xba4988: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba4988: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba498c: b               #0xba4250
    // 0xba4990: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xba4990: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static _ sourceFor(/* No info */) {
    // ** addr: 0xba49a0, size: 0xa0
    // 0xba49a0: EnterFrame
    //     0xba49a0: stp             fp, lr, [SP, #-0x10]!
    //     0xba49a4: mov             fp, SP
    // 0xba49a8: CheckStackOverflow
    //     0xba49a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba49ac: cmp             SP, x16
    //     0xba49b0: b.ls            #0xba4a38
    // 0xba49b4: r0 = LoadClassIdInstr(r1)
    //     0xba49b4: ldur            x0, [x1, #-1]
    //     0xba49b8: ubfx            x0, x0, #0xc, #0x14
    // 0xba49bc: r0 = GDT[cid_x0 + 0x15e74]()
    //     0xba49bc: mov             x17, #0x5e74
    //     0xba49c0: movk            x17, #1, lsl #16
    //     0xba49c4: add             lr, x0, x17
    //     0xba49c8: ldr             lr, [x21, lr, lsl #3]
    //     0xba49cc: blr             lr
    // 0xba49d0: LoadField: r1 = r0->field_7
    //     0xba49d0: ldur            x1, [x0, #7]
    // 0xba49d4: cmp             x1, #2
    // 0xba49d8: b.gt            #0xba4a04
    // 0xba49dc: cmp             x1, #1
    // 0xba49e0: b.gt            #0xba49fc
    // 0xba49e4: cmp             x1, #0
    // 0xba49e8: b.gt            #0xba49f4
    // 0xba49ec: r0 = 4098
    //     0xba49ec: mov             x0, #0x1002
    // 0xba49f0: b               #0xba4a2c
    // 0xba49f4: r0 = 8194
    //     0xba49f4: mov             x0, #0x2002
    // 0xba49f8: b               #0xba4a2c
    // 0xba49fc: r0 = 16386
    //     0xba49fc: mov             x0, #0x4002
    // 0xba4a00: b               #0xba4a2c
    // 0xba4a04: cmp             x1, #4
    // 0xba4a08: b.gt            #0xba4a28
    // 0xba4a0c: cmp             x1, #3
    // 0xba4a10: b.gt            #0xba4a1c
    // 0xba4a14: r0 = 16386
    //     0xba4a14: mov             x0, #0x4002
    // 0xba4a18: b               #0xba4a2c
    // 0xba4a1c: r0 = 1048584
    //     0xba4a1c: mov             x0, #8
    //     0xba4a20: movk            x0, #0x10, lsl #16
    // 0xba4a24: b               #0xba4a2c
    // 0xba4a28: r0 = 0
    //     0xba4a28: mov             x0, #0
    // 0xba4a2c: LeaveFrame
    //     0xba4a2c: mov             SP, fp
    //     0xba4a30: ldp             fp, lr, [SP], #0x10
    // 0xba4a34: ret
    //     0xba4a34: ret             
    // 0xba4a38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba4a38: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba4a3c: b               #0xba49b4
  }
  [closure] AndroidPointerCoords <anonymous closure>(dynamic, int) {
    // ** addr: 0xba4a40, size: 0x7c
    // 0xba4a40: EnterFrame
    //     0xba4a40: stp             fp, lr, [SP, #-0x10]!
    //     0xba4a44: mov             fp, SP
    // 0xba4a48: AllocStack(0x8)
    //     0xba4a48: sub             SP, SP, #8
    // 0xba4a4c: SetupParameters([dynamic _ /* r0 */])
    //     0xba4a4c: ldr             x0, [fp, #0x18]
    //     0xba4a50: ldur            w1, [x0, #0x17]
    //     0xba4a54: add             x1, x1, HEAP, lsl #32
    // 0xba4a58: CheckStackOverflow
    //     0xba4a58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba4a5c: cmp             SP, x16
    //     0xba4a60: b.ls            #0xba4ab0
    // 0xba4a64: LoadField: r0 = r1->field_f
    //     0xba4a64: ldur            w0, [x1, #0xf]
    // 0xba4a68: DecompressPointer r0
    //     0xba4a68: add             x0, x0, HEAP, lsl #32
    // 0xba4a6c: LoadField: r3 = r0->field_7
    //     0xba4a6c: ldur            w3, [x0, #7]
    // 0xba4a70: DecompressPointer r3
    //     0xba4a70: add             x3, x3, HEAP, lsl #32
    // 0xba4a74: mov             x1, x3
    // 0xba4a78: ldr             x2, [fp, #0x10]
    // 0xba4a7c: stur            x3, [fp, #-8]
    // 0xba4a80: r0 = _getValueOrData()
    //     0xba4a80: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xba4a84: ldur            x1, [fp, #-8]
    // 0xba4a88: LoadField: r2 = r1->field_f
    //     0xba4a88: ldur            w2, [x1, #0xf]
    // 0xba4a8c: DecompressPointer r2
    //     0xba4a8c: add             x2, x2, HEAP, lsl #32
    // 0xba4a90: cmp             w2, w0
    // 0xba4a94: b.ne            #0xba4a9c
    // 0xba4a98: r0 = Null
    //     0xba4a98: mov             x0, NULL
    // 0xba4a9c: cmp             w0, NULL
    // 0xba4aa0: b.eq            #0xba4ab8
    // 0xba4aa4: LeaveFrame
    //     0xba4aa4: mov             SP, fp
    //     0xba4aa8: ldp             fp, lr, [SP], #0x10
    // 0xba4aac: ret
    //     0xba4aac: ret             
    // 0xba4ab0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba4ab0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba4ab4: b               #0xba4a64
    // 0xba4ab8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xba4ab8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] AndroidPointerProperties <anonymous closure>(dynamic, int) {
    // ** addr: 0xba4abc, size: 0x7c
    // 0xba4abc: EnterFrame
    //     0xba4abc: stp             fp, lr, [SP, #-0x10]!
    //     0xba4ac0: mov             fp, SP
    // 0xba4ac4: AllocStack(0x8)
    //     0xba4ac4: sub             SP, SP, #8
    // 0xba4ac8: SetupParameters([dynamic _ /* r0 */])
    //     0xba4ac8: ldr             x0, [fp, #0x18]
    //     0xba4acc: ldur            w1, [x0, #0x17]
    //     0xba4ad0: add             x1, x1, HEAP, lsl #32
    // 0xba4ad4: CheckStackOverflow
    //     0xba4ad4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba4ad8: cmp             SP, x16
    //     0xba4adc: b.ls            #0xba4b2c
    // 0xba4ae0: LoadField: r0 = r1->field_f
    //     0xba4ae0: ldur            w0, [x1, #0xf]
    // 0xba4ae4: DecompressPointer r0
    //     0xba4ae4: add             x0, x0, HEAP, lsl #32
    // 0xba4ae8: LoadField: r3 = r0->field_b
    //     0xba4ae8: ldur            w3, [x0, #0xb]
    // 0xba4aec: DecompressPointer r3
    //     0xba4aec: add             x3, x3, HEAP, lsl #32
    // 0xba4af0: mov             x1, x3
    // 0xba4af4: ldr             x2, [fp, #0x10]
    // 0xba4af8: stur            x3, [fp, #-8]
    // 0xba4afc: r0 = _getValueOrData()
    //     0xba4afc: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xba4b00: ldur            x1, [fp, #-8]
    // 0xba4b04: LoadField: r2 = r1->field_f
    //     0xba4b04: ldur            w2, [x1, #0xf]
    // 0xba4b08: DecompressPointer r2
    //     0xba4b08: add             x2, x2, HEAP, lsl #32
    // 0xba4b0c: cmp             w2, w0
    // 0xba4b10: b.ne            #0xba4b18
    // 0xba4b14: r0 = Null
    //     0xba4b14: mov             x0, NULL
    // 0xba4b18: cmp             w0, NULL
    // 0xba4b1c: b.eq            #0xba4b34
    // 0xba4b20: LeaveFrame
    //     0xba4b20: mov             SP, fp
    //     0xba4b24: ldp             fp, lr, [SP], #0x10
    // 0xba4b28: ret
    //     0xba4b28: ret             
    // 0xba4b2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba4b2c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba4b30: b               #0xba4ae0
    // 0xba4b34: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xba4b34: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ updatePointerPositions(/* No info */) {
    // ** addr: 0xba4b38, size: 0x26c
    // 0xba4b38: EnterFrame
    //     0xba4b38: stp             fp, lr, [SP, #-0x10]!
    //     0xba4b3c: mov             fp, SP
    // 0xba4b40: AllocStack(0x80)
    //     0xba4b40: sub             SP, SP, #0x80
    // 0xba4b44: SetupParameters(_AndroidMotionEventConverter this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xba4b44: mov             x3, x1
    //     0xba4b48: stur            x1, [fp, #-8]
    //     0xba4b4c: stur            x2, [fp, #-0x10]
    // 0xba4b50: CheckStackOverflow
    //     0xba4b50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba4b54: cmp             SP, x16
    //     0xba4b58: b.ls            #0xba4d90
    // 0xba4b5c: r0 = LoadClassIdInstr(r2)
    //     0xba4b5c: ldur            x0, [x2, #-1]
    //     0xba4b60: ubfx            x0, x0, #0xc, #0x14
    // 0xba4b64: mov             x1, x2
    // 0xba4b68: r0 = GDT[cid_x0 + 0x13f27]()
    //     0xba4b68: mov             x17, #0x3f27
    //     0xba4b6c: movk            x17, #1, lsl #16
    //     0xba4b70: add             lr, x0, x17
    //     0xba4b74: ldr             lr, [x21, lr, lsl #3]
    //     0xba4b78: blr             lr
    // 0xba4b7c: ldur            x1, [fp, #-8]
    // 0xba4b80: LoadField: r2 = r1->field_13
    //     0xba4b80: ldur            w2, [x1, #0x13]
    // 0xba4b84: DecompressPointer r2
    //     0xba4b84: add             x2, x2, HEAP, lsl #32
    // 0xba4b88: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xba4b8c: cmp             w2, w16
    // 0xba4b90: b.eq            #0xba4d98
    // 0xba4b94: stp             x0, x2, [SP]
    // 0xba4b98: mov             x0, x2
    // 0xba4b9c: ClosureCall
    //     0xba4b9c: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xba4ba0: ldur            x2, [x0, #0x1f]
    //     0xba4ba4: blr             x2
    // 0xba4ba8: mov             x2, x0
    // 0xba4bac: ldur            x0, [fp, #-8]
    // 0xba4bb0: stur            x2, [fp, #-0x20]
    // 0xba4bb4: LoadField: r3 = r0->field_7
    //     0xba4bb4: ldur            w3, [x0, #7]
    // 0xba4bb8: DecompressPointer r3
    //     0xba4bb8: add             x3, x3, HEAP, lsl #32
    // 0xba4bbc: ldur            x4, [fp, #-0x10]
    // 0xba4bc0: stur            x3, [fp, #-0x18]
    // 0xba4bc4: r0 = LoadClassIdInstr(r4)
    //     0xba4bc4: ldur            x0, [x4, #-1]
    //     0xba4bc8: ubfx            x0, x0, #0xc, #0x14
    // 0xba4bcc: mov             x1, x4
    // 0xba4bd0: r0 = GDT[cid_x0 + -0x1]()
    //     0xba4bd0: sub             lr, x0, #1
    //     0xba4bd4: ldr             lr, [x21, lr, lsl #3]
    //     0xba4bd8: blr             lr
    // 0xba4bdc: mov             x3, x0
    // 0xba4be0: ldur            x2, [fp, #-0x10]
    // 0xba4be4: stur            x3, [fp, #-0x28]
    // 0xba4be8: r0 = LoadClassIdInstr(r2)
    //     0xba4be8: ldur            x0, [x2, #-1]
    //     0xba4bec: ubfx            x0, x0, #0xc, #0x14
    // 0xba4bf0: mov             x1, x2
    // 0xba4bf4: r0 = GDT[cid_x0 + 0x1600b]()
    //     0xba4bf4: mov             x17, #0x600b
    //     0xba4bf8: movk            x17, #1, lsl #16
    //     0xba4bfc: add             lr, x0, x17
    //     0xba4c00: ldr             lr, [x21, lr, lsl #3]
    //     0xba4c04: blr             lr
    // 0xba4c08: ldur            x2, [fp, #-0x10]
    // 0xba4c0c: stur            d0, [fp, #-0x30]
    // 0xba4c10: r0 = LoadClassIdInstr(r2)
    //     0xba4c10: ldur            x0, [x2, #-1]
    //     0xba4c14: ubfx            x0, x0, #0xc, #0x14
    // 0xba4c18: mov             x1, x2
    // 0xba4c1c: r0 = GDT[cid_x0 + 0x70dd]()
    //     0xba4c1c: mov             x17, #0x70dd
    //     0xba4c20: add             lr, x0, x17
    //     0xba4c24: ldr             lr, [x21, lr, lsl #3]
    //     0xba4c28: blr             lr
    // 0xba4c2c: ldur            x2, [fp, #-0x10]
    // 0xba4c30: stur            d0, [fp, #-0x38]
    // 0xba4c34: r0 = LoadClassIdInstr(r2)
    //     0xba4c34: ldur            x0, [x2, #-1]
    //     0xba4c38: ubfx            x0, x0, #0xc, #0x14
    // 0xba4c3c: mov             x1, x2
    // 0xba4c40: r0 = GDT[cid_x0 + 0x175dc]()
    //     0xba4c40: mov             x17, #0x75dc
    //     0xba4c44: movk            x17, #1, lsl #16
    //     0xba4c48: add             lr, x0, x17
    //     0xba4c4c: ldr             lr, [x21, lr, lsl #3]
    //     0xba4c50: blr             lr
    // 0xba4c54: ldur            x2, [fp, #-0x10]
    // 0xba4c58: stur            d0, [fp, #-0x40]
    // 0xba4c5c: r0 = LoadClassIdInstr(r2)
    //     0xba4c5c: ldur            x0, [x2, #-1]
    //     0xba4c60: ubfx            x0, x0, #0xc, #0x14
    // 0xba4c64: mov             x1, x2
    // 0xba4c68: r0 = GDT[cid_x0 + 0x15e18]()
    //     0xba4c68: mov             x17, #0x5e18
    //     0xba4c6c: movk            x17, #1, lsl #16
    //     0xba4c70: add             lr, x0, x17
    //     0xba4c74: ldr             lr, [x21, lr, lsl #3]
    //     0xba4c78: blr             lr
    // 0xba4c7c: ldur            x2, [fp, #-0x10]
    // 0xba4c80: stur            d0, [fp, #-0x48]
    // 0xba4c84: r0 = LoadClassIdInstr(r2)
    //     0xba4c84: ldur            x0, [x2, #-1]
    //     0xba4c88: ubfx            x0, x0, #0xc, #0x14
    // 0xba4c8c: mov             x1, x2
    // 0xba4c90: r0 = GDT[cid_x0 + 0x13f28]()
    //     0xba4c90: mov             x17, #0x3f28
    //     0xba4c94: movk            x17, #1, lsl #16
    //     0xba4c98: add             lr, x0, x17
    //     0xba4c9c: ldr             lr, [x21, lr, lsl #3]
    //     0xba4ca0: blr             lr
    // 0xba4ca4: ldur            x2, [fp, #-0x10]
    // 0xba4ca8: stur            d0, [fp, #-0x50]
    // 0xba4cac: r0 = LoadClassIdInstr(r2)
    //     0xba4cac: ldur            x0, [x2, #-1]
    //     0xba4cb0: ubfx            x0, x0, #0xc, #0x14
    // 0xba4cb4: mov             x1, x2
    // 0xba4cb8: r0 = GDT[cid_x0 + 0x15e18]()
    //     0xba4cb8: mov             x17, #0x5e18
    //     0xba4cbc: movk            x17, #1, lsl #16
    //     0xba4cc0: add             lr, x0, x17
    //     0xba4cc4: ldr             lr, [x21, lr, lsl #3]
    //     0xba4cc8: blr             lr
    // 0xba4ccc: ldur            x1, [fp, #-0x10]
    // 0xba4cd0: stur            d0, [fp, #-0x58]
    // 0xba4cd4: r0 = LoadClassIdInstr(r1)
    //     0xba4cd4: ldur            x0, [x1, #-1]
    //     0xba4cd8: ubfx            x0, x0, #0xc, #0x14
    // 0xba4cdc: r0 = GDT[cid_x0 + 0x13f28]()
    //     0xba4cdc: mov             x17, #0x3f28
    //     0xba4ce0: movk            x17, #1, lsl #16
    //     0xba4ce4: add             lr, x0, x17
    //     0xba4ce8: ldr             lr, [x21, lr, lsl #3]
    //     0xba4cec: blr             lr
    // 0xba4cf0: ldur            x0, [fp, #-0x20]
    // 0xba4cf4: stur            d0, [fp, #-0x70]
    // 0xba4cf8: LoadField: d1 = r0->field_7
    //     0xba4cf8: ldur            d1, [x0, #7]
    // 0xba4cfc: stur            d1, [fp, #-0x68]
    // 0xba4d00: LoadField: d2 = r0->field_f
    //     0xba4d00: ldur            d2, [x0, #0xf]
    // 0xba4d04: stur            d2, [fp, #-0x60]
    // 0xba4d08: r0 = AndroidPointerCoords()
    //     0xba4d08: bl              #0xba4da4  ; AllocateAndroidPointerCoordsStub -> AndroidPointerCoords (size=0x50)
    // 0xba4d0c: mov             x2, x0
    // 0xba4d10: ldur            d0, [fp, #-0x30]
    // 0xba4d14: StoreField: r2->field_7 = d0
    //     0xba4d14: stur            d0, [x2, #7]
    // 0xba4d18: ldur            d0, [fp, #-0x38]
    // 0xba4d1c: StoreField: r2->field_f = d0
    //     0xba4d1c: stur            d0, [x2, #0xf]
    // 0xba4d20: ldur            d0, [fp, #-0x40]
    // 0xba4d24: ArrayStore: r2[0] = d0  ; List_8
    //     0xba4d24: stur            d0, [x2, #0x17]
    // 0xba4d28: ldur            d0, [fp, #-0x48]
    // 0xba4d2c: StoreField: r2->field_1f = d0
    //     0xba4d2c: stur            d0, [x2, #0x1f]
    // 0xba4d30: ldur            d0, [fp, #-0x50]
    // 0xba4d34: StoreField: r2->field_27 = d0
    //     0xba4d34: stur            d0, [x2, #0x27]
    // 0xba4d38: ldur            d0, [fp, #-0x58]
    // 0xba4d3c: StoreField: r2->field_2f = d0
    //     0xba4d3c: stur            d0, [x2, #0x2f]
    // 0xba4d40: ldur            d0, [fp, #-0x70]
    // 0xba4d44: StoreField: r2->field_37 = d0
    //     0xba4d44: stur            d0, [x2, #0x37]
    // 0xba4d48: ldur            d0, [fp, #-0x68]
    // 0xba4d4c: StoreField: r2->field_3f = d0
    //     0xba4d4c: stur            d0, [x2, #0x3f]
    // 0xba4d50: ldur            d0, [fp, #-0x60]
    // 0xba4d54: StoreField: r2->field_47 = d0
    //     0xba4d54: stur            d0, [x2, #0x47]
    // 0xba4d58: ldur            x3, [fp, #-0x28]
    // 0xba4d5c: r0 = BoxInt64Instr(r3)
    //     0xba4d5c: sbfiz           x0, x3, #1, #0x1f
    //     0xba4d60: cmp             x3, x0, asr #1
    //     0xba4d64: b.eq            #0xba4d70
    //     0xba4d68: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba4d6c: stur            x3, [x0, #7]
    // 0xba4d70: ldur            x1, [fp, #-0x18]
    // 0xba4d74: mov             x3, x2
    // 0xba4d78: mov             x2, x0
    // 0xba4d7c: r0 = []=()
    //     0xba4d7c: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xba4d80: r0 = Null
    //     0xba4d80: mov             x0, NULL
    // 0xba4d84: LeaveFrame
    //     0xba4d84: mov             SP, fp
    //     0xba4d88: ldp             fp, lr, [SP], #0x10
    // 0xba4d8c: ret
    //     0xba4d8c: ret             
    // 0xba4d90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba4d90: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba4d94: b               #0xba4b5c
    // 0xba4d98: r9 = pointTransformer
    //     0xba4d98: add             x9, PP, #0xa1, lsl #12  ; [pp+0xa17a8] Field <_AndroidMotionEventConverter@634227590.pointTransformer>: late (offset: 0x14)
    //     0xba4d9c: ldr             x9, [x9, #0x7a8]
    // 0xba4da0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xba4da0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ handlePointerDownEvent(/* No info */) {
    // ** addr: 0xba4db0, size: 0x1b0
    // 0xba4db0: EnterFrame
    //     0xba4db0: stp             fp, lr, [SP, #-0x10]!
    //     0xba4db4: mov             fp, SP
    // 0xba4db8: AllocStack(0x38)
    //     0xba4db8: sub             SP, SP, #0x38
    // 0xba4dbc: SetupParameters(_AndroidMotionEventConverter this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0xba4dbc: mov             x3, x1
    //     0xba4dc0: stur            x1, [fp, #-0x10]
    //     0xba4dc4: stur            x2, [fp, #-0x18]
    // 0xba4dc8: CheckStackOverflow
    //     0xba4dc8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba4dcc: cmp             SP, x16
    //     0xba4dd0: b.ls            #0xba4f50
    // 0xba4dd4: LoadField: r4 = r3->field_b
    //     0xba4dd4: ldur            w4, [x3, #0xb]
    // 0xba4dd8: DecompressPointer r4
    //     0xba4dd8: add             x4, x4, HEAP, lsl #32
    // 0xba4ddc: stur            x4, [fp, #-8]
    // 0xba4de0: LoadField: r0 = r4->field_13
    //     0xba4de0: ldur            w0, [x4, #0x13]
    // 0xba4de4: r1 = LoadInt32Instr(r0)
    //     0xba4de4: sbfx            x1, x0, #1, #0x1f
    // 0xba4de8: asr             x0, x1, #1
    // 0xba4dec: ArrayLoad: r1 = r4[0]  ; List_4
    //     0xba4dec: ldur            w1, [x4, #0x17]
    // 0xba4df0: r5 = LoadInt32Instr(r1)
    //     0xba4df0: sbfx            x5, x1, #1, #0x1f
    // 0xba4df4: sub             x1, x0, x5
    // 0xba4df8: cbnz            x1, #0xba4e60
    // 0xba4dfc: r0 = LoadClassIdInstr(r2)
    //     0xba4dfc: ldur            x0, [x2, #-1]
    //     0xba4e00: ubfx            x0, x0, #0xc, #0x14
    // 0xba4e04: mov             x1, x2
    // 0xba4e08: r0 = GDT[cid_x0 + 0x15eb5]()
    //     0xba4e08: mov             x17, #0x5eb5
    //     0xba4e0c: movk            x17, #1, lsl #16
    //     0xba4e10: add             lr, x0, x17
    //     0xba4e14: ldr             lr, [x21, lr, lsl #3]
    //     0xba4e18: blr             lr
    // 0xba4e1c: LoadField: r1 = r0->field_7
    //     0xba4e1c: ldur            x1, [x0, #7]
    // 0xba4e20: r0 = 1000
    //     0xba4e20: mov             x0, #0x3e8
    // 0xba4e24: sdiv            x2, x1, x0
    // 0xba4e28: r0 = BoxInt64Instr(r2)
    //     0xba4e28: sbfiz           x0, x2, #1, #0x1f
    //     0xba4e2c: cmp             x2, x0, asr #1
    //     0xba4e30: b.eq            #0xba4e3c
    //     0xba4e34: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba4e38: stur            x2, [x0, #7]
    // 0xba4e3c: ldur            x3, [fp, #-0x10]
    // 0xba4e40: ArrayStore: r3[0] = r0  ; List_4
    //     0xba4e40: stur            w0, [x3, #0x17]
    //     0xba4e44: tbz             w0, #0, #0xba4e60
    //     0xba4e48: ldurb           w16, [x3, #-1]
    //     0xba4e4c: ldurb           w17, [x0, #-1]
    //     0xba4e50: and             x16, x17, x16, lsr #2
    //     0xba4e54: tst             x16, HEAP, lsr #32
    //     0xba4e58: b.eq            #0xba4e60
    //     0xba4e5c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xba4e60: LoadField: r4 = r3->field_f
    //     0xba4e60: ldur            w4, [x3, #0xf]
    // 0xba4e64: DecompressPointer r4
    //     0xba4e64: add             x4, x4, HEAP, lsl #32
    // 0xba4e68: stur            x4, [fp, #-0x38]
    // 0xba4e6c: r5 = 0
    //     0xba4e6c: mov             x5, #0
    // 0xba4e70: stur            x5, [fp, #-0x30]
    // 0xba4e74: CheckStackOverflow
    //     0xba4e74: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba4e78: cmp             SP, x16
    //     0xba4e7c: b.ls            #0xba4f58
    // 0xba4e80: LoadField: r6 = r4->field_f
    //     0xba4e80: ldur            w6, [x4, #0xf]
    // 0xba4e84: DecompressPointer r6
    //     0xba4e84: add             x6, x6, HEAP, lsl #32
    // 0xba4e88: stur            x6, [fp, #-0x28]
    // 0xba4e8c: r0 = BoxInt64Instr(r5)
    //     0xba4e8c: sbfiz           x0, x5, #1, #0x1f
    //     0xba4e90: cmp             x5, x0, asr #1
    //     0xba4e94: b.eq            #0xba4ea0
    //     0xba4e98: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba4e9c: stur            x5, [x0, #7]
    // 0xba4ea0: mov             x1, x4
    // 0xba4ea4: mov             x2, x0
    // 0xba4ea8: stur            x0, [fp, #-0x20]
    // 0xba4eac: r0 = _getKeyOrData()
    //     0xba4eac: bl              #0x84b72c  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::_getKeyOrData
    // 0xba4eb0: mov             x1, x0
    // 0xba4eb4: ldur            x0, [fp, #-0x28]
    // 0xba4eb8: cmp             w0, w1
    // 0xba4ebc: b.eq            #0xba4ed4
    // 0xba4ec0: ldur            x3, [fp, #-0x30]
    // 0xba4ec4: add             x5, x3, #1
    // 0xba4ec8: ldur            x3, [fp, #-0x10]
    // 0xba4ecc: ldur            x4, [fp, #-0x38]
    // 0xba4ed0: b               #0xba4e70
    // 0xba4ed4: ldur            x0, [fp, #-0x18]
    // 0xba4ed8: ldur            x3, [fp, #-0x30]
    // 0xba4edc: ldur            x1, [fp, #-0x38]
    // 0xba4ee0: ldur            x2, [fp, #-0x20]
    // 0xba4ee4: r0 = add()
    //     0xba4ee4: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xba4ee8: ldur            x2, [fp, #-0x18]
    // 0xba4eec: r0 = LoadClassIdInstr(r2)
    //     0xba4eec: ldur            x0, [x2, #-1]
    //     0xba4ef0: ubfx            x0, x0, #0xc, #0x14
    // 0xba4ef4: mov             x1, x2
    // 0xba4ef8: r0 = GDT[cid_x0 + -0x1]()
    //     0xba4ef8: sub             lr, x0, #1
    //     0xba4efc: ldr             lr, [x21, lr, lsl #3]
    //     0xba4f00: blr             lr
    // 0xba4f04: ldur            x1, [fp, #-0x10]
    // 0xba4f08: ldur            x2, [fp, #-0x18]
    // 0xba4f0c: ldur            x3, [fp, #-0x30]
    // 0xba4f10: stur            x0, [fp, #-0x30]
    // 0xba4f14: r0 = propertiesFor()
    //     0xba4f14: bl              #0xba4f60  ; [package:flutter/src/services/platform_views.dart] _AndroidMotionEventConverter::propertiesFor
    // 0xba4f18: mov             x3, x0
    // 0xba4f1c: ldur            x2, [fp, #-0x30]
    // 0xba4f20: r0 = BoxInt64Instr(r2)
    //     0xba4f20: sbfiz           x0, x2, #1, #0x1f
    //     0xba4f24: cmp             x2, x0, asr #1
    //     0xba4f28: b.eq            #0xba4f34
    //     0xba4f2c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba4f30: stur            x2, [x0, #7]
    // 0xba4f34: ldur            x1, [fp, #-8]
    // 0xba4f38: mov             x2, x0
    // 0xba4f3c: r0 = []=()
    //     0xba4f3c: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xba4f40: r0 = Null
    //     0xba4f40: mov             x0, NULL
    // 0xba4f44: LeaveFrame
    //     0xba4f44: mov             SP, fp
    //     0xba4f48: ldp             fp, lr, [SP], #0x10
    // 0xba4f4c: ret
    //     0xba4f4c: ret             
    // 0xba4f50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba4f50: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba4f54: b               #0xba4dd4
    // 0xba4f58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba4f58: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba4f5c: b               #0xba4e80
  }
  _ propertiesFor(/* No info */) {
    // ** addr: 0xba4f60, size: 0xc8
    // 0xba4f60: EnterFrame
    //     0xba4f60: stp             fp, lr, [SP, #-0x10]!
    //     0xba4f64: mov             fp, SP
    // 0xba4f68: AllocStack(0x10)
    //     0xba4f68: sub             SP, SP, #0x10
    // 0xba4f6c: SetupParameters(_AndroidMotionEventConverter this /* r1 => r0 */, dynamic _ /* r2 => r1 */, dynamic _ /* r3 => r3, fp-0x8 */)
    //     0xba4f6c: mov             x0, x1
    //     0xba4f70: mov             x1, x2
    //     0xba4f74: stur            x3, [fp, #-8]
    // 0xba4f78: CheckStackOverflow
    //     0xba4f78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba4f7c: cmp             SP, x16
    //     0xba4f80: b.ls            #0xba5020
    // 0xba4f84: r0 = LoadClassIdInstr(r1)
    //     0xba4f84: ldur            x0, [x1, #-1]
    //     0xba4f88: ubfx            x0, x0, #0xc, #0x14
    // 0xba4f8c: r0 = GDT[cid_x0 + 0x15e74]()
    //     0xba4f8c: mov             x17, #0x5e74
    //     0xba4f90: movk            x17, #1, lsl #16
    //     0xba4f94: add             lr, x0, x17
    //     0xba4f98: ldr             lr, [x21, lr, lsl #3]
    //     0xba4f9c: blr             lr
    // 0xba4fa0: LoadField: r1 = r0->field_7
    //     0xba4fa0: ldur            x1, [x0, #7]
    // 0xba4fa4: cmp             x1, #2
    // 0xba4fa8: b.gt            #0xba4fd4
    // 0xba4fac: cmp             x1, #1
    // 0xba4fb0: b.gt            #0xba4fcc
    // 0xba4fb4: cmp             x1, #0
    // 0xba4fb8: b.gt            #0xba4fc4
    // 0xba4fbc: r1 = 1
    //     0xba4fbc: mov             x1, #1
    // 0xba4fc0: b               #0xba4ff8
    // 0xba4fc4: r1 = 3
    //     0xba4fc4: mov             x1, #3
    // 0xba4fc8: b               #0xba4ff8
    // 0xba4fcc: r1 = 2
    //     0xba4fcc: mov             x1, #2
    // 0xba4fd0: b               #0xba4ff8
    // 0xba4fd4: cmp             x1, #4
    // 0xba4fd8: b.gt            #0xba4ff4
    // 0xba4fdc: cmp             x1, #3
    // 0xba4fe0: b.gt            #0xba4fec
    // 0xba4fe4: r1 = 4
    //     0xba4fe4: mov             x1, #4
    // 0xba4fe8: b               #0xba4ff8
    // 0xba4fec: r1 = 1
    //     0xba4fec: mov             x1, #1
    // 0xba4ff0: b               #0xba4ff8
    // 0xba4ff4: r1 = 0
    //     0xba4ff4: mov             x1, #0
    // 0xba4ff8: ldur            x0, [fp, #-8]
    // 0xba4ffc: stur            x1, [fp, #-0x10]
    // 0xba5000: r0 = AndroidPointerProperties()
    //     0xba5000: bl              #0xba5028  ; AllocateAndroidPointerPropertiesStub -> AndroidPointerProperties (size=0x18)
    // 0xba5004: ldur            x1, [fp, #-8]
    // 0xba5008: StoreField: r0->field_7 = r1
    //     0xba5008: stur            x1, [x0, #7]
    // 0xba500c: ldur            x1, [fp, #-0x10]
    // 0xba5010: StoreField: r0->field_f = r1
    //     0xba5010: stur            x1, [x0, #0xf]
    // 0xba5014: LeaveFrame
    //     0xba5014: mov             SP, fp
    //     0xba5018: ldp             fp, lr, [SP], #0x10
    // 0xba501c: ret
    //     0xba501c: ret             
    // 0xba5020: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba5020: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba5024: b               #0xba4f84
  }
  _ _AndroidMotionEventConverter(/* No info */) {
    // ** addr: 0x10d7ee4, size: 0xe8
    // 0x10d7ee4: EnterFrame
    //     0x10d7ee4: stp             fp, lr, [SP, #-0x10]!
    //     0x10d7ee8: mov             fp, SP
    // 0x10d7eec: AllocStack(0x18)
    //     0x10d7eec: sub             SP, SP, #0x18
    // 0x10d7ef0: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x10d7ef4: stur            x1, [fp, #-8]
    // 0x10d7ef8: CheckStackOverflow
    //     0x10d7ef8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10d7efc: cmp             SP, x16
    //     0x10d7f00: b.ls            #0x10d7fc4
    // 0x10d7f04: StoreField: r1->field_13 = r0
    //     0x10d7f04: stur            w0, [x1, #0x13]
    // 0x10d7f08: r16 = <int, AndroidPointerCoords>
    //     0x10d7f08: add             x16, PP, #0x7d, lsl #12  ; [pp+0x7d3d0] TypeArguments: <int, AndroidPointerCoords>
    //     0x10d7f0c: ldr             x16, [x16, #0x3d0]
    // 0x10d7f10: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x10d7f14: stp             lr, x16, [SP]
    // 0x10d7f18: r0 = Map._fromLiteral()
    //     0x10d7f18: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x10d7f1c: ldur            x1, [fp, #-8]
    // 0x10d7f20: StoreField: r1->field_7 = r0
    //     0x10d7f20: stur            w0, [x1, #7]
    //     0x10d7f24: ldurb           w16, [x1, #-1]
    //     0x10d7f28: ldurb           w17, [x0, #-1]
    //     0x10d7f2c: and             x16, x17, x16, lsr #2
    //     0x10d7f30: tst             x16, HEAP, lsr #32
    //     0x10d7f34: b.eq            #0x10d7f3c
    //     0x10d7f38: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x10d7f3c: r16 = <int, AndroidPointerProperties>
    //     0x10d7f3c: add             x16, PP, #0x7d, lsl #12  ; [pp+0x7d3d8] TypeArguments: <int, AndroidPointerProperties>
    //     0x10d7f40: ldr             x16, [x16, #0x3d8]
    // 0x10d7f44: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x10d7f48: stp             lr, x16, [SP]
    // 0x10d7f4c: r0 = Map._fromLiteral()
    //     0x10d7f4c: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x10d7f50: ldur            x2, [fp, #-8]
    // 0x10d7f54: StoreField: r2->field_b = r0
    //     0x10d7f54: stur            w0, [x2, #0xb]
    //     0x10d7f58: ldurb           w16, [x2, #-1]
    //     0x10d7f5c: ldurb           w17, [x0, #-1]
    //     0x10d7f60: and             x16, x17, x16, lsr #2
    //     0x10d7f64: tst             x16, HEAP, lsr #32
    //     0x10d7f68: b.eq            #0x10d7f70
    //     0x10d7f6c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x10d7f70: r1 = <int>
    //     0x10d7f70: ldr             x1, [PP, #0x50]  ; [pp+0x50] TypeArguments: <int>
    // 0x10d7f74: r0 = _Set()
    //     0x10d7f74: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x10d7f78: r1 = _Uint32List
    //     0x10d7f78: ldr             x1, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0x10d7f7c: StoreField: r0->field_1b = r1
    //     0x10d7f7c: stur            w1, [x0, #0x1b]
    // 0x10d7f80: StoreField: r0->field_b = rZR
    //     0x10d7f80: stur            wzr, [x0, #0xb]
    // 0x10d7f84: r1 = const []
    //     0x10d7f84: ldr             x1, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0x10d7f88: StoreField: r0->field_f = r1
    //     0x10d7f88: stur            w1, [x0, #0xf]
    // 0x10d7f8c: StoreField: r0->field_13 = rZR
    //     0x10d7f8c: stur            wzr, [x0, #0x13]
    // 0x10d7f90: ArrayStore: r0[0] = rZR  ; List_4
    //     0x10d7f90: stur            wzr, [x0, #0x17]
    // 0x10d7f94: ldur            x1, [fp, #-8]
    // 0x10d7f98: StoreField: r1->field_f = r0
    //     0x10d7f98: stur            w0, [x1, #0xf]
    //     0x10d7f9c: ldurb           w16, [x1, #-1]
    //     0x10d7fa0: ldurb           w17, [x0, #-1]
    //     0x10d7fa4: and             x16, x17, x16, lsr #2
    //     0x10d7fa8: tst             x16, HEAP, lsr #32
    //     0x10d7fac: b.eq            #0x10d7fb4
    //     0x10d7fb0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x10d7fb4: r0 = Null
    //     0x10d7fb4: mov             x0, NULL
    // 0x10d7fb8: LeaveFrame
    //     0x10d7fb8: mov             SP, fp
    //     0x10d7fbc: ldp             fp, lr, [SP], #0x10
    // 0x10d7fc0: ret
    //     0x10d7fc0: ret             
    // 0x10d7fc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10d7fc4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10d7fc8: b               #0x10d7f04
  }
}

// class id: 2768, size: 0x78, field offset: 0x8
class AndroidMotionEvent extends Object {

  _ _asList(/* No info */) {
    // ** addr: 0xba34a4, size: 0x6c0
    // 0xba34a4: EnterFrame
    //     0xba34a4: stp             fp, lr, [SP, #-0x10]!
    //     0xba34a8: mov             fp, SP
    // 0xba34ac: AllocStack(0x38)
    //     0xba34ac: sub             SP, SP, #0x38
    // 0xba34b0: SetupParameters(AndroidMotionEvent this /* r1 => r3, fp-0x10 */)
    //     0xba34b0: mov             x3, x1
    //     0xba34b4: stur            x1, [fp, #-0x10]
    // 0xba34b8: CheckStackOverflow
    //     0xba34b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba34bc: cmp             SP, x16
    //     0xba34c0: b.ls            #0xba3b2c
    // 0xba34c4: r0 = BoxInt64Instr(r2)
    //     0xba34c4: sbfiz           x0, x2, #1, #0x1f
    //     0xba34c8: cmp             x2, x0, asr #1
    //     0xba34cc: b.eq            #0xba34d8
    //     0xba34d0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba34d4: stur            x2, [x0, #7]
    // 0xba34d8: r1 = Null
    //     0xba34d8: mov             x1, NULL
    // 0xba34dc: r2 = 32
    //     0xba34dc: mov             x2, #0x20
    // 0xba34e0: stur            x0, [fp, #-8]
    // 0xba34e4: r0 = AllocateArray()
    //     0xba34e4: bl              #0x13df928  ; AllocateArrayStub
    // 0xba34e8: mov             x3, x0
    // 0xba34ec: ldur            x0, [fp, #-8]
    // 0xba34f0: stur            x3, [fp, #-0x18]
    // 0xba34f4: StoreField: r3->field_f = r0
    //     0xba34f4: stur            w0, [x3, #0xf]
    // 0xba34f8: ldur            x4, [fp, #-0x10]
    // 0xba34fc: LoadField: r2 = r4->field_7
    //     0xba34fc: ldur            x2, [x4, #7]
    // 0xba3500: r0 = BoxInt64Instr(r2)
    //     0xba3500: sbfiz           x0, x2, #1, #0x1f
    //     0xba3504: cmp             x2, x0, asr #1
    //     0xba3508: b.eq            #0xba3514
    //     0xba350c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba3510: stur            x2, [x0, #7]
    // 0xba3514: mov             x1, x3
    // 0xba3518: ArrayStore: r1[1] = r0  ; List_4
    //     0xba3518: add             x25, x1, #0x13
    //     0xba351c: str             w0, [x25]
    //     0xba3520: tbz             w0, #0, #0xba353c
    //     0xba3524: ldurb           w16, [x1, #-1]
    //     0xba3528: ldurb           w17, [x0, #-1]
    //     0xba352c: and             x16, x17, x16, lsr #2
    //     0xba3530: tst             x16, HEAP, lsr #32
    //     0xba3534: b.eq            #0xba353c
    //     0xba3538: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xba353c: LoadField: r2 = r4->field_f
    //     0xba353c: ldur            x2, [x4, #0xf]
    // 0xba3540: r0 = BoxInt64Instr(r2)
    //     0xba3540: sbfiz           x0, x2, #1, #0x1f
    //     0xba3544: cmp             x2, x0, asr #1
    //     0xba3548: b.eq            #0xba3554
    //     0xba354c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba3550: stur            x2, [x0, #7]
    // 0xba3554: mov             x1, x3
    // 0xba3558: ArrayStore: r1[2] = r0  ; List_4
    //     0xba3558: add             x25, x1, #0x17
    //     0xba355c: str             w0, [x25]
    //     0xba3560: tbz             w0, #0, #0xba357c
    //     0xba3564: ldurb           w16, [x1, #-1]
    //     0xba3568: ldurb           w17, [x0, #-1]
    //     0xba356c: and             x16, x17, x16, lsr #2
    //     0xba3570: tst             x16, HEAP, lsr #32
    //     0xba3574: b.eq            #0xba357c
    //     0xba3578: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xba357c: ArrayLoad: r2 = r4[0]  ; List_8
    //     0xba357c: ldur            x2, [x4, #0x17]
    // 0xba3580: r0 = BoxInt64Instr(r2)
    //     0xba3580: sbfiz           x0, x2, #1, #0x1f
    //     0xba3584: cmp             x2, x0, asr #1
    //     0xba3588: b.eq            #0xba3594
    //     0xba358c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba3590: stur            x2, [x0, #7]
    // 0xba3594: mov             x1, x3
    // 0xba3598: ArrayStore: r1[3] = r0  ; List_4
    //     0xba3598: add             x25, x1, #0x1b
    //     0xba359c: str             w0, [x25]
    //     0xba35a0: tbz             w0, #0, #0xba35bc
    //     0xba35a4: ldurb           w16, [x1, #-1]
    //     0xba35a8: ldurb           w17, [x0, #-1]
    //     0xba35ac: and             x16, x17, x16, lsr #2
    //     0xba35b0: tst             x16, HEAP, lsr #32
    //     0xba35b4: b.eq            #0xba35bc
    //     0xba35b8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xba35bc: LoadField: r2 = r4->field_1f
    //     0xba35bc: ldur            x2, [x4, #0x1f]
    // 0xba35c0: r0 = BoxInt64Instr(r2)
    //     0xba35c0: sbfiz           x0, x2, #1, #0x1f
    //     0xba35c4: cmp             x2, x0, asr #1
    //     0xba35c8: b.eq            #0xba35d4
    //     0xba35cc: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba35d0: stur            x2, [x0, #7]
    // 0xba35d4: mov             x1, x3
    // 0xba35d8: ArrayStore: r1[4] = r0  ; List_4
    //     0xba35d8: add             x25, x1, #0x1f
    //     0xba35dc: str             w0, [x25]
    //     0xba35e0: tbz             w0, #0, #0xba35fc
    //     0xba35e4: ldurb           w16, [x1, #-1]
    //     0xba35e8: ldurb           w17, [x0, #-1]
    //     0xba35ec: and             x16, x17, x16, lsr #2
    //     0xba35f0: tst             x16, HEAP, lsr #32
    //     0xba35f4: b.eq            #0xba35fc
    //     0xba35f8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xba35fc: LoadField: r0 = r4->field_27
    //     0xba35fc: ldur            w0, [x4, #0x27]
    // 0xba3600: DecompressPointer r0
    //     0xba3600: add             x0, x0, HEAP, lsl #32
    // 0xba3604: stur            x0, [fp, #-8]
    // 0xba3608: r1 = Function '<anonymous closure>':.
    //     0xba3608: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa1718] AnonymousClosure: (0xba3fe0), in [package:flutter/src/services/platform_views.dart] AndroidMotionEvent::_asList (0xba34a4)
    //     0xba360c: ldr             x1, [x1, #0x718]
    // 0xba3610: r2 = Null
    //     0xba3610: mov             x2, NULL
    // 0xba3614: r0 = AllocateClosure()
    //     0xba3614: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xba3618: r16 = <List<int>>
    //     0xba3618: add             x16, PP, #0xb, lsl #12  ; [pp+0xb958] TypeArguments: <List<int>>
    //     0xba361c: ldr             x16, [x16, #0x958]
    // 0xba3620: ldur            lr, [fp, #-8]
    // 0xba3624: stp             lr, x16, [SP, #8]
    // 0xba3628: str             x0, [SP]
    // 0xba362c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xba362c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xba3630: r0 = map()
    //     0xba3630: bl              #0xba574c  ; [dart:collection] ListBase::map
    // 0xba3634: mov             x3, x0
    // 0xba3638: stur            x3, [fp, #-0x20]
    // 0xba363c: LoadField: r4 = r3->field_7
    //     0xba363c: ldur            w4, [x3, #7]
    // 0xba3640: DecompressPointer r4
    //     0xba3640: add             x4, x4, HEAP, lsl #32
    // 0xba3644: mov             x0, x3
    // 0xba3648: stur            x4, [fp, #-8]
    // 0xba364c: r2 = Null
    //     0xba364c: mov             x2, NULL
    // 0xba3650: r1 = Null
    //     0xba3650: mov             x1, NULL
    // 0xba3654: cmp             w0, NULL
    // 0xba3658: b.eq            #0xba36f0
    // 0xba365c: branchIfSmi(r0, 0xba36f0)
    //     0xba365c: tbz             w0, #0, #0xba36f0
    // 0xba3660: r3 = LoadClassIdInstr(r0)
    //     0xba3660: ldur            x3, [x0, #-1]
    //     0xba3664: ubfx            x3, x3, #0xc, #0x14
    // 0xba3668: r17 = 7724
    //     0xba3668: mov             x17, #0x1e2c
    // 0xba366c: cmp             x3, x17
    // 0xba3670: b.eq            #0xba36f8
    // 0xba3674: r4 = LoadClassIdInstr(r0)
    //     0xba3674: ldur            x4, [x0, #-1]
    //     0xba3678: ubfx            x4, x4, #0xc, #0x14
    // 0xba367c: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0xba3680: ldr             x3, [x3, #0x18]
    // 0xba3684: ldr             x3, [x3, x4, lsl #3]
    // 0xba3688: LoadField: r3 = r3->field_2b
    //     0xba3688: ldur            w3, [x3, #0x2b]
    // 0xba368c: DecompressPointer r3
    //     0xba368c: add             x3, x3, HEAP, lsl #32
    // 0xba3690: cmp             w3, NULL
    // 0xba3694: b.eq            #0xba36f0
    // 0xba3698: LoadField: r3 = r3->field_f
    //     0xba3698: ldur            w3, [x3, #0xf]
    // 0xba369c: lsr             x3, x3, #3
    // 0xba36a0: r17 = 7724
    //     0xba36a0: mov             x17, #0x1e2c
    // 0xba36a4: cmp             x3, x17
    // 0xba36a8: b.eq            #0xba36f8
    // 0xba36ac: r3 = SubtypeTestCache
    //     0xba36ac: add             x3, PP, #0xa1, lsl #12  ; [pp+0xa1720] SubtypeTestCache
    //     0xba36b0: ldr             x3, [x3, #0x720]
    // 0xba36b4: r30 = Subtype1TestCacheStub
    //     0xba36b4: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0xba36b8: LoadField: r30 = r30->field_7
    //     0xba36b8: ldur            lr, [lr, #7]
    // 0xba36bc: blr             lr
    // 0xba36c0: cmp             w7, NULL
    // 0xba36c4: b.eq            #0xba36d0
    // 0xba36c8: tbnz            w7, #4, #0xba36f0
    // 0xba36cc: b               #0xba36f8
    // 0xba36d0: r8 = EfficientLengthIterable
    //     0xba36d0: add             x8, PP, #0xa1, lsl #12  ; [pp+0xa1728] Type: EfficientLengthIterable
    //     0xba36d4: ldr             x8, [x8, #0x728]
    // 0xba36d8: r3 = SubtypeTestCache
    //     0xba36d8: add             x3, PP, #0xa1, lsl #12  ; [pp+0xa1730] SubtypeTestCache
    //     0xba36dc: ldr             x3, [x3, #0x730]
    // 0xba36e0: r30 = InstanceOfStub
    //     0xba36e0: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0xba36e4: LoadField: r30 = r30->field_7
    //     0xba36e4: ldur            lr, [lr, #7]
    // 0xba36e8: blr             lr
    // 0xba36ec: b               #0xba36fc
    // 0xba36f0: r0 = false
    //     0xba36f0: add             x0, NULL, #0x30  ; false
    // 0xba36f4: b               #0xba36fc
    // 0xba36f8: r0 = true
    //     0xba36f8: add             x0, NULL, #0x20  ; true
    // 0xba36fc: tbnz            w0, #4, #0xba3710
    // 0xba3700: ldur            x1, [fp, #-8]
    // 0xba3704: ldur            x2, [fp, #-0x20]
    // 0xba3708: r0 = _GrowableList._ofEfficientLengthIterable()
    //     0xba3708: bl              #0x7d732c  ; [dart:core] _GrowableList::_GrowableList._ofEfficientLengthIterable
    // 0xba370c: b               #0xba371c
    // 0xba3710: ldur            x1, [fp, #-8]
    // 0xba3714: ldur            x2, [fp, #-0x20]
    // 0xba3718: r0 = _GrowableList._ofOther()
    //     0xba3718: bl              #0x7d94b4  ; [dart:core] _GrowableList::_GrowableList._ofOther
    // 0xba371c: ldur            x3, [fp, #-0x10]
    // 0xba3720: ldur            x1, [fp, #-0x18]
    // 0xba3724: ArrayStore: r1[5] = r0  ; List_4
    //     0xba3724: add             x25, x1, #0x23
    //     0xba3728: str             w0, [x25]
    //     0xba372c: tbz             w0, #0, #0xba3748
    //     0xba3730: ldurb           w16, [x1, #-1]
    //     0xba3734: ldurb           w17, [x0, #-1]
    //     0xba3738: and             x16, x17, x16, lsr #2
    //     0xba373c: tst             x16, HEAP, lsr #32
    //     0xba3740: b.eq            #0xba3748
    //     0xba3744: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xba3748: LoadField: r0 = r3->field_2b
    //     0xba3748: ldur            w0, [x3, #0x2b]
    // 0xba374c: DecompressPointer r0
    //     0xba374c: add             x0, x0, HEAP, lsl #32
    // 0xba3750: stur            x0, [fp, #-8]
    // 0xba3754: r1 = Function '<anonymous closure>':.
    //     0xba3754: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa1738] AnonymousClosure: (0xba3b64), in [package:flutter/src/services/platform_views.dart] AndroidMotionEvent::_asList (0xba34a4)
    //     0xba3758: ldr             x1, [x1, #0x738]
    // 0xba375c: r2 = Null
    //     0xba375c: mov             x2, NULL
    // 0xba3760: r0 = AllocateClosure()
    //     0xba3760: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xba3764: r16 = <List<double>>
    //     0xba3764: add             x16, PP, #0x13, lsl #12  ; [pp+0x132b0] TypeArguments: <List<double>>
    //     0xba3768: ldr             x16, [x16, #0x2b0]
    // 0xba376c: ldur            lr, [fp, #-8]
    // 0xba3770: stp             lr, x16, [SP, #8]
    // 0xba3774: str             x0, [SP]
    // 0xba3778: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xba3778: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xba377c: r0 = map()
    //     0xba377c: bl              #0xba574c  ; [dart:collection] ListBase::map
    // 0xba3780: mov             x3, x0
    // 0xba3784: stur            x3, [fp, #-0x20]
    // 0xba3788: LoadField: r4 = r3->field_7
    //     0xba3788: ldur            w4, [x3, #7]
    // 0xba378c: DecompressPointer r4
    //     0xba378c: add             x4, x4, HEAP, lsl #32
    // 0xba3790: mov             x0, x3
    // 0xba3794: stur            x4, [fp, #-8]
    // 0xba3798: r2 = Null
    //     0xba3798: mov             x2, NULL
    // 0xba379c: r1 = Null
    //     0xba379c: mov             x1, NULL
    // 0xba37a0: cmp             w0, NULL
    // 0xba37a4: b.eq            #0xba383c
    // 0xba37a8: branchIfSmi(r0, 0xba383c)
    //     0xba37a8: tbz             w0, #0, #0xba383c
    // 0xba37ac: r3 = LoadClassIdInstr(r0)
    //     0xba37ac: ldur            x3, [x0, #-1]
    //     0xba37b0: ubfx            x3, x3, #0xc, #0x14
    // 0xba37b4: r17 = 7724
    //     0xba37b4: mov             x17, #0x1e2c
    // 0xba37b8: cmp             x3, x17
    // 0xba37bc: b.eq            #0xba3844
    // 0xba37c0: r4 = LoadClassIdInstr(r0)
    //     0xba37c0: ldur            x4, [x0, #-1]
    //     0xba37c4: ubfx            x4, x4, #0xc, #0x14
    // 0xba37c8: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0xba37cc: ldr             x3, [x3, #0x18]
    // 0xba37d0: ldr             x3, [x3, x4, lsl #3]
    // 0xba37d4: LoadField: r3 = r3->field_2b
    //     0xba37d4: ldur            w3, [x3, #0x2b]
    // 0xba37d8: DecompressPointer r3
    //     0xba37d8: add             x3, x3, HEAP, lsl #32
    // 0xba37dc: cmp             w3, NULL
    // 0xba37e0: b.eq            #0xba383c
    // 0xba37e4: LoadField: r3 = r3->field_f
    //     0xba37e4: ldur            w3, [x3, #0xf]
    // 0xba37e8: lsr             x3, x3, #3
    // 0xba37ec: r17 = 7724
    //     0xba37ec: mov             x17, #0x1e2c
    // 0xba37f0: cmp             x3, x17
    // 0xba37f4: b.eq            #0xba3844
    // 0xba37f8: r3 = SubtypeTestCache
    //     0xba37f8: add             x3, PP, #0xa1, lsl #12  ; [pp+0xa1740] SubtypeTestCache
    //     0xba37fc: ldr             x3, [x3, #0x740]
    // 0xba3800: r30 = Subtype1TestCacheStub
    //     0xba3800: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0xba3804: LoadField: r30 = r30->field_7
    //     0xba3804: ldur            lr, [lr, #7]
    // 0xba3808: blr             lr
    // 0xba380c: cmp             w7, NULL
    // 0xba3810: b.eq            #0xba381c
    // 0xba3814: tbnz            w7, #4, #0xba383c
    // 0xba3818: b               #0xba3844
    // 0xba381c: r8 = EfficientLengthIterable
    //     0xba381c: add             x8, PP, #0xa1, lsl #12  ; [pp+0xa1748] Type: EfficientLengthIterable
    //     0xba3820: ldr             x8, [x8, #0x748]
    // 0xba3824: r3 = SubtypeTestCache
    //     0xba3824: add             x3, PP, #0xa1, lsl #12  ; [pp+0xa1750] SubtypeTestCache
    //     0xba3828: ldr             x3, [x3, #0x750]
    // 0xba382c: r30 = InstanceOfStub
    //     0xba382c: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0xba3830: LoadField: r30 = r30->field_7
    //     0xba3830: ldur            lr, [lr, #7]
    // 0xba3834: blr             lr
    // 0xba3838: b               #0xba3848
    // 0xba383c: r0 = false
    //     0xba383c: add             x0, NULL, #0x30  ; false
    // 0xba3840: b               #0xba3848
    // 0xba3844: r0 = true
    //     0xba3844: add             x0, NULL, #0x20  ; true
    // 0xba3848: tbnz            w0, #4, #0xba385c
    // 0xba384c: ldur            x1, [fp, #-8]
    // 0xba3850: ldur            x2, [fp, #-0x20]
    // 0xba3854: r0 = _GrowableList._ofEfficientLengthIterable()
    //     0xba3854: bl              #0x7d732c  ; [dart:core] _GrowableList::_GrowableList._ofEfficientLengthIterable
    // 0xba3858: b               #0xba3868
    // 0xba385c: ldur            x1, [fp, #-8]
    // 0xba3860: ldur            x2, [fp, #-0x20]
    // 0xba3864: r0 = _GrowableList._ofOther()
    //     0xba3864: bl              #0x7d94b4  ; [dart:core] _GrowableList::_GrowableList._ofOther
    // 0xba3868: ldur            x2, [fp, #-0x10]
    // 0xba386c: ldur            x3, [fp, #-0x18]
    // 0xba3870: mov             x1, x3
    // 0xba3874: ArrayStore: r1[6] = r0  ; List_4
    //     0xba3874: add             x25, x1, #0x27
    //     0xba3878: str             w0, [x25]
    //     0xba387c: tbz             w0, #0, #0xba3898
    //     0xba3880: ldurb           w16, [x1, #-1]
    //     0xba3884: ldurb           w17, [x0, #-1]
    //     0xba3888: and             x16, x17, x16, lsr #2
    //     0xba388c: tst             x16, HEAP, lsr #32
    //     0xba3890: b.eq            #0xba3898
    //     0xba3894: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xba3898: LoadField: r4 = r2->field_2f
    //     0xba3898: ldur            x4, [x2, #0x2f]
    // 0xba389c: r0 = BoxInt64Instr(r4)
    //     0xba389c: sbfiz           x0, x4, #1, #0x1f
    //     0xba38a0: cmp             x4, x0, asr #1
    //     0xba38a4: b.eq            #0xba38b0
    //     0xba38a8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba38ac: stur            x4, [x0, #7]
    // 0xba38b0: mov             x1, x3
    // 0xba38b4: ArrayStore: r1[7] = r0  ; List_4
    //     0xba38b4: add             x25, x1, #0x2b
    //     0xba38b8: str             w0, [x25]
    //     0xba38bc: tbz             w0, #0, #0xba38d8
    //     0xba38c0: ldurb           w16, [x1, #-1]
    //     0xba38c4: ldurb           w17, [x0, #-1]
    //     0xba38c8: and             x16, x17, x16, lsr #2
    //     0xba38cc: tst             x16, HEAP, lsr #32
    //     0xba38d0: b.eq            #0xba38d8
    //     0xba38d4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xba38d8: LoadField: r4 = r2->field_37
    //     0xba38d8: ldur            x4, [x2, #0x37]
    // 0xba38dc: r0 = BoxInt64Instr(r4)
    //     0xba38dc: sbfiz           x0, x4, #1, #0x1f
    //     0xba38e0: cmp             x4, x0, asr #1
    //     0xba38e4: b.eq            #0xba38f0
    //     0xba38e8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba38ec: stur            x4, [x0, #7]
    // 0xba38f0: mov             x1, x3
    // 0xba38f4: ArrayStore: r1[8] = r0  ; List_4
    //     0xba38f4: add             x25, x1, #0x2f
    //     0xba38f8: str             w0, [x25]
    //     0xba38fc: tbz             w0, #0, #0xba3918
    //     0xba3900: ldurb           w16, [x1, #-1]
    //     0xba3904: ldurb           w17, [x0, #-1]
    //     0xba3908: and             x16, x17, x16, lsr #2
    //     0xba390c: tst             x16, HEAP, lsr #32
    //     0xba3910: b.eq            #0xba3918
    //     0xba3914: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xba3918: LoadField: d0 = r2->field_3f
    //     0xba3918: ldur            d0, [x2, #0x3f]
    // 0xba391c: r0 = inline_Allocate_Double()
    //     0xba391c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xba3920: add             x0, x0, #0x10
    //     0xba3924: cmp             x1, x0
    //     0xba3928: b.ls            #0xba3b34
    //     0xba392c: str             x0, [THR, #0x60]  ; THR::top
    //     0xba3930: sub             x0, x0, #0xf
    //     0xba3934: mov             x1, #0xe19c
    //     0xba3938: movk            x1, #3, lsl #16
    //     0xba393c: stur            x1, [x0, #-1]
    // 0xba3940: dmb             ishst
    // 0xba3944: StoreField: r0->field_7 = d0
    //     0xba3944: stur            d0, [x0, #7]
    // 0xba3948: mov             x1, x3
    // 0xba394c: ArrayStore: r1[9] = r0  ; List_4
    //     0xba394c: add             x25, x1, #0x33
    //     0xba3950: str             w0, [x25]
    //     0xba3954: tbz             w0, #0, #0xba3970
    //     0xba3958: ldurb           w16, [x1, #-1]
    //     0xba395c: ldurb           w17, [x0, #-1]
    //     0xba3960: and             x16, x17, x16, lsr #2
    //     0xba3964: tst             x16, HEAP, lsr #32
    //     0xba3968: b.eq            #0xba3970
    //     0xba396c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xba3970: LoadField: d0 = r2->field_47
    //     0xba3970: ldur            d0, [x2, #0x47]
    // 0xba3974: r0 = inline_Allocate_Double()
    //     0xba3974: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xba3978: add             x0, x0, #0x10
    //     0xba397c: cmp             x1, x0
    //     0xba3980: b.ls            #0xba3b4c
    //     0xba3984: str             x0, [THR, #0x60]  ; THR::top
    //     0xba3988: sub             x0, x0, #0xf
    //     0xba398c: mov             x1, #0xe19c
    //     0xba3990: movk            x1, #3, lsl #16
    //     0xba3994: stur            x1, [x0, #-1]
    // 0xba3998: dmb             ishst
    // 0xba399c: StoreField: r0->field_7 = d0
    //     0xba399c: stur            d0, [x0, #7]
    // 0xba39a0: mov             x1, x3
    // 0xba39a4: ArrayStore: r1[10] = r0  ; List_4
    //     0xba39a4: add             x25, x1, #0x37
    //     0xba39a8: str             w0, [x25]
    //     0xba39ac: tbz             w0, #0, #0xba39c8
    //     0xba39b0: ldurb           w16, [x1, #-1]
    //     0xba39b4: ldurb           w17, [x0, #-1]
    //     0xba39b8: and             x16, x17, x16, lsr #2
    //     0xba39bc: tst             x16, HEAP, lsr #32
    //     0xba39c0: b.eq            #0xba39c8
    //     0xba39c4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xba39c8: LoadField: r4 = r2->field_4f
    //     0xba39c8: ldur            x4, [x2, #0x4f]
    // 0xba39cc: r0 = BoxInt64Instr(r4)
    //     0xba39cc: sbfiz           x0, x4, #1, #0x1f
    //     0xba39d0: cmp             x4, x0, asr #1
    //     0xba39d4: b.eq            #0xba39e0
    //     0xba39d8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba39dc: stur            x4, [x0, #7]
    // 0xba39e0: mov             x1, x3
    // 0xba39e4: ArrayStore: r1[11] = r0  ; List_4
    //     0xba39e4: add             x25, x1, #0x3b
    //     0xba39e8: str             w0, [x25]
    //     0xba39ec: tbz             w0, #0, #0xba3a08
    //     0xba39f0: ldurb           w16, [x1, #-1]
    //     0xba39f4: ldurb           w17, [x0, #-1]
    //     0xba39f8: and             x16, x17, x16, lsr #2
    //     0xba39fc: tst             x16, HEAP, lsr #32
    //     0xba3a00: b.eq            #0xba3a08
    //     0xba3a04: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xba3a08: LoadField: r4 = r2->field_57
    //     0xba3a08: ldur            x4, [x2, #0x57]
    // 0xba3a0c: r0 = BoxInt64Instr(r4)
    //     0xba3a0c: sbfiz           x0, x4, #1, #0x1f
    //     0xba3a10: cmp             x4, x0, asr #1
    //     0xba3a14: b.eq            #0xba3a20
    //     0xba3a18: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba3a1c: stur            x4, [x0, #7]
    // 0xba3a20: mov             x1, x3
    // 0xba3a24: ArrayStore: r1[12] = r0  ; List_4
    //     0xba3a24: add             x25, x1, #0x3f
    //     0xba3a28: str             w0, [x25]
    //     0xba3a2c: tbz             w0, #0, #0xba3a48
    //     0xba3a30: ldurb           w16, [x1, #-1]
    //     0xba3a34: ldurb           w17, [x0, #-1]
    //     0xba3a38: and             x16, x17, x16, lsr #2
    //     0xba3a3c: tst             x16, HEAP, lsr #32
    //     0xba3a40: b.eq            #0xba3a48
    //     0xba3a44: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xba3a48: LoadField: r4 = r2->field_5f
    //     0xba3a48: ldur            x4, [x2, #0x5f]
    // 0xba3a4c: r0 = BoxInt64Instr(r4)
    //     0xba3a4c: sbfiz           x0, x4, #1, #0x1f
    //     0xba3a50: cmp             x4, x0, asr #1
    //     0xba3a54: b.eq            #0xba3a60
    //     0xba3a58: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba3a5c: stur            x4, [x0, #7]
    // 0xba3a60: mov             x1, x3
    // 0xba3a64: ArrayStore: r1[13] = r0  ; List_4
    //     0xba3a64: add             x25, x1, #0x43
    //     0xba3a68: str             w0, [x25]
    //     0xba3a6c: tbz             w0, #0, #0xba3a88
    //     0xba3a70: ldurb           w16, [x1, #-1]
    //     0xba3a74: ldurb           w17, [x0, #-1]
    //     0xba3a78: and             x16, x17, x16, lsr #2
    //     0xba3a7c: tst             x16, HEAP, lsr #32
    //     0xba3a80: b.eq            #0xba3a88
    //     0xba3a84: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xba3a88: LoadField: r4 = r2->field_67
    //     0xba3a88: ldur            x4, [x2, #0x67]
    // 0xba3a8c: r0 = BoxInt64Instr(r4)
    //     0xba3a8c: sbfiz           x0, x4, #1, #0x1f
    //     0xba3a90: cmp             x4, x0, asr #1
    //     0xba3a94: b.eq            #0xba3aa0
    //     0xba3a98: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba3a9c: stur            x4, [x0, #7]
    // 0xba3aa0: mov             x1, x3
    // 0xba3aa4: ArrayStore: r1[14] = r0  ; List_4
    //     0xba3aa4: add             x25, x1, #0x47
    //     0xba3aa8: str             w0, [x25]
    //     0xba3aac: tbz             w0, #0, #0xba3ac8
    //     0xba3ab0: ldurb           w16, [x1, #-1]
    //     0xba3ab4: ldurb           w17, [x0, #-1]
    //     0xba3ab8: and             x16, x17, x16, lsr #2
    //     0xba3abc: tst             x16, HEAP, lsr #32
    //     0xba3ac0: b.eq            #0xba3ac8
    //     0xba3ac4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xba3ac8: LoadField: r4 = r2->field_6f
    //     0xba3ac8: ldur            x4, [x2, #0x6f]
    // 0xba3acc: r0 = BoxInt64Instr(r4)
    //     0xba3acc: sbfiz           x0, x4, #1, #0x1f
    //     0xba3ad0: cmp             x4, x0, asr #1
    //     0xba3ad4: b.eq            #0xba3ae0
    //     0xba3ad8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba3adc: stur            x4, [x0, #7]
    // 0xba3ae0: mov             x1, x3
    // 0xba3ae4: ArrayStore: r1[15] = r0  ; List_4
    //     0xba3ae4: add             x25, x1, #0x4b
    //     0xba3ae8: str             w0, [x25]
    //     0xba3aec: tbz             w0, #0, #0xba3b08
    //     0xba3af0: ldurb           w16, [x1, #-1]
    //     0xba3af4: ldurb           w17, [x0, #-1]
    //     0xba3af8: and             x16, x17, x16, lsr #2
    //     0xba3afc: tst             x16, HEAP, lsr #32
    //     0xba3b00: b.eq            #0xba3b08
    //     0xba3b04: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xba3b08: r1 = Null
    //     0xba3b08: mov             x1, NULL
    // 0xba3b0c: r0 = AllocateGrowableArray()
    //     0xba3b0c: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xba3b10: ldur            x1, [fp, #-0x18]
    // 0xba3b14: StoreField: r0->field_f = r1
    //     0xba3b14: stur            w1, [x0, #0xf]
    // 0xba3b18: r1 = 32
    //     0xba3b18: mov             x1, #0x20
    // 0xba3b1c: StoreField: r0->field_b = r1
    //     0xba3b1c: stur            w1, [x0, #0xb]
    // 0xba3b20: LeaveFrame
    //     0xba3b20: mov             SP, fp
    //     0xba3b24: ldp             fp, lr, [SP], #0x10
    // 0xba3b28: ret
    //     0xba3b28: ret             
    // 0xba3b2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba3b2c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba3b30: b               #0xba34c4
    // 0xba3b34: SaveReg d0
    //     0xba3b34: str             q0, [SP, #-0x10]!
    // 0xba3b38: stp             x2, x3, [SP, #-0x10]!
    // 0xba3b3c: r0 = AllocateDouble()
    //     0xba3b3c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xba3b40: ldp             x2, x3, [SP], #0x10
    // 0xba3b44: RestoreReg d0
    //     0xba3b44: ldr             q0, [SP], #0x10
    // 0xba3b48: b               #0xba3944
    // 0xba3b4c: SaveReg d0
    //     0xba3b4c: str             q0, [SP, #-0x10]!
    // 0xba3b50: stp             x2, x3, [SP, #-0x10]!
    // 0xba3b54: r0 = AllocateDouble()
    //     0xba3b54: bl              #0x13df878  ; AllocateDoubleStub
    // 0xba3b58: ldp             x2, x3, [SP], #0x10
    // 0xba3b5c: RestoreReg d0
    //     0xba3b5c: ldr             q0, [SP], #0x10
    // 0xba3b60: b               #0xba399c
  }
  [closure] List<double> <anonymous closure>(dynamic, AndroidPointerCoords) {
    // ** addr: 0xba3b64, size: 0x30
    // 0xba3b64: EnterFrame
    //     0xba3b64: stp             fp, lr, [SP, #-0x10]!
    //     0xba3b68: mov             fp, SP
    // 0xba3b6c: CheckStackOverflow
    //     0xba3b6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba3b70: cmp             SP, x16
    //     0xba3b74: b.ls            #0xba3b8c
    // 0xba3b78: ldr             x1, [fp, #0x10]
    // 0xba3b7c: r0 = _asList()
    //     0xba3b7c: bl              #0xba3b94  ; [package:flutter/src/services/platform_views.dart] AndroidPointerCoords::_asList
    // 0xba3b80: LeaveFrame
    //     0xba3b80: mov             SP, fp
    //     0xba3b84: ldp             fp, lr, [SP], #0x10
    // 0xba3b88: ret
    //     0xba3b88: ret             
    // 0xba3b8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba3b8c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba3b90: b               #0xba3b78
  }
  [closure] List<int> <anonymous closure>(dynamic, AndroidPointerProperties) {
    // ** addr: 0xba3fe0, size: 0x30
    // 0xba3fe0: EnterFrame
    //     0xba3fe0: stp             fp, lr, [SP, #-0x10]!
    //     0xba3fe4: mov             fp, SP
    // 0xba3fe8: CheckStackOverflow
    //     0xba3fe8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba3fec: cmp             SP, x16
    //     0xba3ff0: b.ls            #0xba4008
    // 0xba3ff4: ldr             x1, [fp, #0x10]
    // 0xba3ff8: r0 = _asList()
    //     0xba3ff8: bl              #0xba4010  ; [package:flutter/src/services/platform_views.dart] AndroidPointerProperties::_asList
    // 0xba3ffc: LeaveFrame
    //     0xba3ffc: mov             SP, fp
    //     0xba4000: ldp             fp, lr, [SP], #0x10
    // 0xba4004: ret
    //     0xba4004: ret             
    // 0xba4008: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba4008: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba400c: b               #0xba3ff4
  }
}

// class id: 2769, size: 0x50, field offset: 0x8
//   const constructor, 
class AndroidPointerCoords extends Object {

  _ _asList(/* No info */) {
    // ** addr: 0xba3b94, size: 0x42c
    // 0xba3b94: EnterFrame
    //     0xba3b94: stp             fp, lr, [SP, #-0x10]!
    //     0xba3b98: mov             fp, SP
    // 0xba3b9c: AllocStack(0x18)
    //     0xba3b9c: sub             SP, SP, #0x18
    // 0xba3ba0: r0 = 18
    //     0xba3ba0: mov             x0, #0x12
    // 0xba3ba4: mov             x3, x1
    // 0xba3ba8: stur            x1, [fp, #-0x10]
    // 0xba3bac: LoadField: d0 = r3->field_7
    //     0xba3bac: ldur            d0, [x3, #7]
    // 0xba3bb0: r4 = inline_Allocate_Double()
    //     0xba3bb0: ldp             x4, x1, [THR, #0x60]  ; THR::top
    //     0xba3bb4: add             x4, x4, #0x10
    //     0xba3bb8: cmp             x1, x4
    //     0xba3bbc: b.ls            #0xba3ee4
    //     0xba3bc0: str             x4, [THR, #0x60]  ; THR::top
    //     0xba3bc4: sub             x4, x4, #0xf
    //     0xba3bc8: mov             x1, #0xe19c
    //     0xba3bcc: movk            x1, #3, lsl #16
    //     0xba3bd0: stur            x1, [x4, #-1]
    // 0xba3bd4: dmb             ishst
    // 0xba3bd8: StoreField: r4->field_7 = d0
    //     0xba3bd8: stur            d0, [x4, #7]
    // 0xba3bdc: mov             x2, x0
    // 0xba3be0: stur            x4, [fp, #-8]
    // 0xba3be4: r1 = <double>
    //     0xba3be4: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xba3be8: r0 = AllocateArray()
    //     0xba3be8: bl              #0x13df928  ; AllocateArrayStub
    // 0xba3bec: mov             x2, x0
    // 0xba3bf0: ldur            x0, [fp, #-8]
    // 0xba3bf4: stur            x2, [fp, #-0x18]
    // 0xba3bf8: StoreField: r2->field_f = r0
    //     0xba3bf8: stur            w0, [x2, #0xf]
    // 0xba3bfc: ldur            x3, [fp, #-0x10]
    // 0xba3c00: LoadField: d0 = r3->field_f
    //     0xba3c00: ldur            d0, [x3, #0xf]
    // 0xba3c04: r0 = inline_Allocate_Double()
    //     0xba3c04: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xba3c08: add             x0, x0, #0x10
    //     0xba3c0c: cmp             x1, x0
    //     0xba3c10: b.ls            #0xba3f00
    //     0xba3c14: str             x0, [THR, #0x60]  ; THR::top
    //     0xba3c18: sub             x0, x0, #0xf
    //     0xba3c1c: mov             x1, #0xe19c
    //     0xba3c20: movk            x1, #3, lsl #16
    //     0xba3c24: stur            x1, [x0, #-1]
    // 0xba3c28: dmb             ishst
    // 0xba3c2c: StoreField: r0->field_7 = d0
    //     0xba3c2c: stur            d0, [x0, #7]
    // 0xba3c30: mov             x1, x2
    // 0xba3c34: ArrayStore: r1[1] = r0  ; List_4
    //     0xba3c34: add             x25, x1, #0x13
    //     0xba3c38: str             w0, [x25]
    //     0xba3c3c: tbz             w0, #0, #0xba3c58
    //     0xba3c40: ldurb           w16, [x1, #-1]
    //     0xba3c44: ldurb           w17, [x0, #-1]
    //     0xba3c48: and             x16, x17, x16, lsr #2
    //     0xba3c4c: tst             x16, HEAP, lsr #32
    //     0xba3c50: b.eq            #0xba3c58
    //     0xba3c54: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xba3c58: ArrayLoad: d0 = r3[0]  ; List_8
    //     0xba3c58: ldur            d0, [x3, #0x17]
    // 0xba3c5c: r0 = inline_Allocate_Double()
    //     0xba3c5c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xba3c60: add             x0, x0, #0x10
    //     0xba3c64: cmp             x1, x0
    //     0xba3c68: b.ls            #0xba3f18
    //     0xba3c6c: str             x0, [THR, #0x60]  ; THR::top
    //     0xba3c70: sub             x0, x0, #0xf
    //     0xba3c74: mov             x1, #0xe19c
    //     0xba3c78: movk            x1, #3, lsl #16
    //     0xba3c7c: stur            x1, [x0, #-1]
    // 0xba3c80: dmb             ishst
    // 0xba3c84: StoreField: r0->field_7 = d0
    //     0xba3c84: stur            d0, [x0, #7]
    // 0xba3c88: mov             x1, x2
    // 0xba3c8c: ArrayStore: r1[2] = r0  ; List_4
    //     0xba3c8c: add             x25, x1, #0x17
    //     0xba3c90: str             w0, [x25]
    //     0xba3c94: tbz             w0, #0, #0xba3cb0
    //     0xba3c98: ldurb           w16, [x1, #-1]
    //     0xba3c9c: ldurb           w17, [x0, #-1]
    //     0xba3ca0: and             x16, x17, x16, lsr #2
    //     0xba3ca4: tst             x16, HEAP, lsr #32
    //     0xba3ca8: b.eq            #0xba3cb0
    //     0xba3cac: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xba3cb0: LoadField: d0 = r3->field_1f
    //     0xba3cb0: ldur            d0, [x3, #0x1f]
    // 0xba3cb4: r0 = inline_Allocate_Double()
    //     0xba3cb4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xba3cb8: add             x0, x0, #0x10
    //     0xba3cbc: cmp             x1, x0
    //     0xba3cc0: b.ls            #0xba3f30
    //     0xba3cc4: str             x0, [THR, #0x60]  ; THR::top
    //     0xba3cc8: sub             x0, x0, #0xf
    //     0xba3ccc: mov             x1, #0xe19c
    //     0xba3cd0: movk            x1, #3, lsl #16
    //     0xba3cd4: stur            x1, [x0, #-1]
    // 0xba3cd8: dmb             ishst
    // 0xba3cdc: StoreField: r0->field_7 = d0
    //     0xba3cdc: stur            d0, [x0, #7]
    // 0xba3ce0: mov             x1, x2
    // 0xba3ce4: ArrayStore: r1[3] = r0  ; List_4
    //     0xba3ce4: add             x25, x1, #0x1b
    //     0xba3ce8: str             w0, [x25]
    //     0xba3cec: tbz             w0, #0, #0xba3d08
    //     0xba3cf0: ldurb           w16, [x1, #-1]
    //     0xba3cf4: ldurb           w17, [x0, #-1]
    //     0xba3cf8: and             x16, x17, x16, lsr #2
    //     0xba3cfc: tst             x16, HEAP, lsr #32
    //     0xba3d00: b.eq            #0xba3d08
    //     0xba3d04: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xba3d08: LoadField: d0 = r3->field_27
    //     0xba3d08: ldur            d0, [x3, #0x27]
    // 0xba3d0c: r0 = inline_Allocate_Double()
    //     0xba3d0c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xba3d10: add             x0, x0, #0x10
    //     0xba3d14: cmp             x1, x0
    //     0xba3d18: b.ls            #0xba3f48
    //     0xba3d1c: str             x0, [THR, #0x60]  ; THR::top
    //     0xba3d20: sub             x0, x0, #0xf
    //     0xba3d24: mov             x1, #0xe19c
    //     0xba3d28: movk            x1, #3, lsl #16
    //     0xba3d2c: stur            x1, [x0, #-1]
    // 0xba3d30: dmb             ishst
    // 0xba3d34: StoreField: r0->field_7 = d0
    //     0xba3d34: stur            d0, [x0, #7]
    // 0xba3d38: mov             x1, x2
    // 0xba3d3c: ArrayStore: r1[4] = r0  ; List_4
    //     0xba3d3c: add             x25, x1, #0x1f
    //     0xba3d40: str             w0, [x25]
    //     0xba3d44: tbz             w0, #0, #0xba3d60
    //     0xba3d48: ldurb           w16, [x1, #-1]
    //     0xba3d4c: ldurb           w17, [x0, #-1]
    //     0xba3d50: and             x16, x17, x16, lsr #2
    //     0xba3d54: tst             x16, HEAP, lsr #32
    //     0xba3d58: b.eq            #0xba3d60
    //     0xba3d5c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xba3d60: LoadField: d0 = r3->field_2f
    //     0xba3d60: ldur            d0, [x3, #0x2f]
    // 0xba3d64: r0 = inline_Allocate_Double()
    //     0xba3d64: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xba3d68: add             x0, x0, #0x10
    //     0xba3d6c: cmp             x1, x0
    //     0xba3d70: b.ls            #0xba3f60
    //     0xba3d74: str             x0, [THR, #0x60]  ; THR::top
    //     0xba3d78: sub             x0, x0, #0xf
    //     0xba3d7c: mov             x1, #0xe19c
    //     0xba3d80: movk            x1, #3, lsl #16
    //     0xba3d84: stur            x1, [x0, #-1]
    // 0xba3d88: dmb             ishst
    // 0xba3d8c: StoreField: r0->field_7 = d0
    //     0xba3d8c: stur            d0, [x0, #7]
    // 0xba3d90: mov             x1, x2
    // 0xba3d94: ArrayStore: r1[5] = r0  ; List_4
    //     0xba3d94: add             x25, x1, #0x23
    //     0xba3d98: str             w0, [x25]
    //     0xba3d9c: tbz             w0, #0, #0xba3db8
    //     0xba3da0: ldurb           w16, [x1, #-1]
    //     0xba3da4: ldurb           w17, [x0, #-1]
    //     0xba3da8: and             x16, x17, x16, lsr #2
    //     0xba3dac: tst             x16, HEAP, lsr #32
    //     0xba3db0: b.eq            #0xba3db8
    //     0xba3db4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xba3db8: LoadField: d0 = r3->field_37
    //     0xba3db8: ldur            d0, [x3, #0x37]
    // 0xba3dbc: r0 = inline_Allocate_Double()
    //     0xba3dbc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xba3dc0: add             x0, x0, #0x10
    //     0xba3dc4: cmp             x1, x0
    //     0xba3dc8: b.ls            #0xba3f78
    //     0xba3dcc: str             x0, [THR, #0x60]  ; THR::top
    //     0xba3dd0: sub             x0, x0, #0xf
    //     0xba3dd4: mov             x1, #0xe19c
    //     0xba3dd8: movk            x1, #3, lsl #16
    //     0xba3ddc: stur            x1, [x0, #-1]
    // 0xba3de0: dmb             ishst
    // 0xba3de4: StoreField: r0->field_7 = d0
    //     0xba3de4: stur            d0, [x0, #7]
    // 0xba3de8: mov             x1, x2
    // 0xba3dec: ArrayStore: r1[6] = r0  ; List_4
    //     0xba3dec: add             x25, x1, #0x27
    //     0xba3df0: str             w0, [x25]
    //     0xba3df4: tbz             w0, #0, #0xba3e10
    //     0xba3df8: ldurb           w16, [x1, #-1]
    //     0xba3dfc: ldurb           w17, [x0, #-1]
    //     0xba3e00: and             x16, x17, x16, lsr #2
    //     0xba3e04: tst             x16, HEAP, lsr #32
    //     0xba3e08: b.eq            #0xba3e10
    //     0xba3e0c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xba3e10: LoadField: d0 = r3->field_3f
    //     0xba3e10: ldur            d0, [x3, #0x3f]
    // 0xba3e14: r0 = inline_Allocate_Double()
    //     0xba3e14: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xba3e18: add             x0, x0, #0x10
    //     0xba3e1c: cmp             x1, x0
    //     0xba3e20: b.ls            #0xba3f90
    //     0xba3e24: str             x0, [THR, #0x60]  ; THR::top
    //     0xba3e28: sub             x0, x0, #0xf
    //     0xba3e2c: mov             x1, #0xe19c
    //     0xba3e30: movk            x1, #3, lsl #16
    //     0xba3e34: stur            x1, [x0, #-1]
    // 0xba3e38: dmb             ishst
    // 0xba3e3c: StoreField: r0->field_7 = d0
    //     0xba3e3c: stur            d0, [x0, #7]
    // 0xba3e40: mov             x1, x2
    // 0xba3e44: ArrayStore: r1[7] = r0  ; List_4
    //     0xba3e44: add             x25, x1, #0x2b
    //     0xba3e48: str             w0, [x25]
    //     0xba3e4c: tbz             w0, #0, #0xba3e68
    //     0xba3e50: ldurb           w16, [x1, #-1]
    //     0xba3e54: ldurb           w17, [x0, #-1]
    //     0xba3e58: and             x16, x17, x16, lsr #2
    //     0xba3e5c: tst             x16, HEAP, lsr #32
    //     0xba3e60: b.eq            #0xba3e68
    //     0xba3e64: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xba3e68: LoadField: d0 = r3->field_47
    //     0xba3e68: ldur            d0, [x3, #0x47]
    // 0xba3e6c: r0 = inline_Allocate_Double()
    //     0xba3e6c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xba3e70: add             x0, x0, #0x10
    //     0xba3e74: cmp             x1, x0
    //     0xba3e78: b.ls            #0xba3fa8
    //     0xba3e7c: str             x0, [THR, #0x60]  ; THR::top
    //     0xba3e80: sub             x0, x0, #0xf
    //     0xba3e84: mov             x1, #0xe19c
    //     0xba3e88: movk            x1, #3, lsl #16
    //     0xba3e8c: stur            x1, [x0, #-1]
    // 0xba3e90: dmb             ishst
    // 0xba3e94: StoreField: r0->field_7 = d0
    //     0xba3e94: stur            d0, [x0, #7]
    // 0xba3e98: mov             x1, x2
    // 0xba3e9c: ArrayStore: r1[8] = r0  ; List_4
    //     0xba3e9c: add             x25, x1, #0x2f
    //     0xba3ea0: str             w0, [x25]
    //     0xba3ea4: tbz             w0, #0, #0xba3ec0
    //     0xba3ea8: ldurb           w16, [x1, #-1]
    //     0xba3eac: ldurb           w17, [x0, #-1]
    //     0xba3eb0: and             x16, x17, x16, lsr #2
    //     0xba3eb4: tst             x16, HEAP, lsr #32
    //     0xba3eb8: b.eq            #0xba3ec0
    //     0xba3ebc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xba3ec0: r1 = <double>
    //     0xba3ec0: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xba3ec4: r0 = AllocateGrowableArray()
    //     0xba3ec4: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xba3ec8: ldur            x1, [fp, #-0x18]
    // 0xba3ecc: StoreField: r0->field_f = r1
    //     0xba3ecc: stur            w1, [x0, #0xf]
    // 0xba3ed0: r1 = 18
    //     0xba3ed0: mov             x1, #0x12
    // 0xba3ed4: StoreField: r0->field_b = r1
    //     0xba3ed4: stur            w1, [x0, #0xb]
    // 0xba3ed8: LeaveFrame
    //     0xba3ed8: mov             SP, fp
    //     0xba3edc: ldp             fp, lr, [SP], #0x10
    // 0xba3ee0: ret
    //     0xba3ee0: ret             
    // 0xba3ee4: SaveReg d0
    //     0xba3ee4: str             q0, [SP, #-0x10]!
    // 0xba3ee8: stp             x0, x3, [SP, #-0x10]!
    // 0xba3eec: r0 = AllocateDouble()
    //     0xba3eec: bl              #0x13df878  ; AllocateDoubleStub
    // 0xba3ef0: mov             x4, x0
    // 0xba3ef4: ldp             x0, x3, [SP], #0x10
    // 0xba3ef8: RestoreReg d0
    //     0xba3ef8: ldr             q0, [SP], #0x10
    // 0xba3efc: b               #0xba3bd8
    // 0xba3f00: SaveReg d0
    //     0xba3f00: str             q0, [SP, #-0x10]!
    // 0xba3f04: stp             x2, x3, [SP, #-0x10]!
    // 0xba3f08: r0 = AllocateDouble()
    //     0xba3f08: bl              #0x13df878  ; AllocateDoubleStub
    // 0xba3f0c: ldp             x2, x3, [SP], #0x10
    // 0xba3f10: RestoreReg d0
    //     0xba3f10: ldr             q0, [SP], #0x10
    // 0xba3f14: b               #0xba3c2c
    // 0xba3f18: SaveReg d0
    //     0xba3f18: str             q0, [SP, #-0x10]!
    // 0xba3f1c: stp             x2, x3, [SP, #-0x10]!
    // 0xba3f20: r0 = AllocateDouble()
    //     0xba3f20: bl              #0x13df878  ; AllocateDoubleStub
    // 0xba3f24: ldp             x2, x3, [SP], #0x10
    // 0xba3f28: RestoreReg d0
    //     0xba3f28: ldr             q0, [SP], #0x10
    // 0xba3f2c: b               #0xba3c84
    // 0xba3f30: SaveReg d0
    //     0xba3f30: str             q0, [SP, #-0x10]!
    // 0xba3f34: stp             x2, x3, [SP, #-0x10]!
    // 0xba3f38: r0 = AllocateDouble()
    //     0xba3f38: bl              #0x13df878  ; AllocateDoubleStub
    // 0xba3f3c: ldp             x2, x3, [SP], #0x10
    // 0xba3f40: RestoreReg d0
    //     0xba3f40: ldr             q0, [SP], #0x10
    // 0xba3f44: b               #0xba3cdc
    // 0xba3f48: SaveReg d0
    //     0xba3f48: str             q0, [SP, #-0x10]!
    // 0xba3f4c: stp             x2, x3, [SP, #-0x10]!
    // 0xba3f50: r0 = AllocateDouble()
    //     0xba3f50: bl              #0x13df878  ; AllocateDoubleStub
    // 0xba3f54: ldp             x2, x3, [SP], #0x10
    // 0xba3f58: RestoreReg d0
    //     0xba3f58: ldr             q0, [SP], #0x10
    // 0xba3f5c: b               #0xba3d34
    // 0xba3f60: SaveReg d0
    //     0xba3f60: str             q0, [SP, #-0x10]!
    // 0xba3f64: stp             x2, x3, [SP, #-0x10]!
    // 0xba3f68: r0 = AllocateDouble()
    //     0xba3f68: bl              #0x13df878  ; AllocateDoubleStub
    // 0xba3f6c: ldp             x2, x3, [SP], #0x10
    // 0xba3f70: RestoreReg d0
    //     0xba3f70: ldr             q0, [SP], #0x10
    // 0xba3f74: b               #0xba3d8c
    // 0xba3f78: SaveReg d0
    //     0xba3f78: str             q0, [SP, #-0x10]!
    // 0xba3f7c: stp             x2, x3, [SP, #-0x10]!
    // 0xba3f80: r0 = AllocateDouble()
    //     0xba3f80: bl              #0x13df878  ; AllocateDoubleStub
    // 0xba3f84: ldp             x2, x3, [SP], #0x10
    // 0xba3f88: RestoreReg d0
    //     0xba3f88: ldr             q0, [SP], #0x10
    // 0xba3f8c: b               #0xba3de4
    // 0xba3f90: SaveReg d0
    //     0xba3f90: str             q0, [SP, #-0x10]!
    // 0xba3f94: stp             x2, x3, [SP, #-0x10]!
    // 0xba3f98: r0 = AllocateDouble()
    //     0xba3f98: bl              #0x13df878  ; AllocateDoubleStub
    // 0xba3f9c: ldp             x2, x3, [SP], #0x10
    // 0xba3fa0: RestoreReg d0
    //     0xba3fa0: ldr             q0, [SP], #0x10
    // 0xba3fa4: b               #0xba3e3c
    // 0xba3fa8: SaveReg d0
    //     0xba3fa8: str             q0, [SP, #-0x10]!
    // 0xba3fac: SaveReg r2
    //     0xba3fac: str             x2, [SP, #-8]!
    // 0xba3fb0: r0 = AllocateDouble()
    //     0xba3fb0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xba3fb4: RestoreReg r2
    //     0xba3fb4: ldr             x2, [SP], #8
    // 0xba3fb8: RestoreReg d0
    //     0xba3fb8: ldr             q0, [SP], #0x10
    // 0xba3fbc: b               #0xba3e94
  }
}

// class id: 2770, size: 0x18, field offset: 0x8
//   const constructor, 
class AndroidPointerProperties extends Object {

  _ _asList(/* No info */) {
    // ** addr: 0xba4010, size: 0x90
    // 0xba4010: EnterFrame
    //     0xba4010: stp             fp, lr, [SP, #-0x10]!
    //     0xba4014: mov             fp, SP
    // 0xba4018: AllocStack(0x18)
    //     0xba4018: sub             SP, SP, #0x18
    // 0xba401c: r3 = 4
    //     0xba401c: mov             x3, #4
    // 0xba4020: LoadField: r2 = r1->field_7
    //     0xba4020: ldur            x2, [x1, #7]
    // 0xba4024: LoadField: r4 = r1->field_f
    //     0xba4024: ldur            x4, [x1, #0xf]
    // 0xba4028: stur            x4, [fp, #-0x10]
    // 0xba402c: r0 = BoxInt64Instr(r2)
    //     0xba402c: sbfiz           x0, x2, #1, #0x1f
    //     0xba4030: cmp             x2, x0, asr #1
    //     0xba4034: b.eq            #0xba4040
    //     0xba4038: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba403c: stur            x2, [x0, #7]
    // 0xba4040: mov             x2, x3
    // 0xba4044: r1 = Null
    //     0xba4044: mov             x1, NULL
    // 0xba4048: stur            x0, [fp, #-8]
    // 0xba404c: r0 = AllocateArray()
    //     0xba404c: bl              #0x13df928  ; AllocateArrayStub
    // 0xba4050: mov             x2, x0
    // 0xba4054: ldur            x0, [fp, #-8]
    // 0xba4058: stur            x2, [fp, #-0x18]
    // 0xba405c: StoreField: r2->field_f = r0
    //     0xba405c: stur            w0, [x2, #0xf]
    // 0xba4060: ldur            x3, [fp, #-0x10]
    // 0xba4064: r0 = BoxInt64Instr(r3)
    //     0xba4064: sbfiz           x0, x3, #1, #0x1f
    //     0xba4068: cmp             x3, x0, asr #1
    //     0xba406c: b.eq            #0xba4078
    //     0xba4070: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba4074: stur            x3, [x0, #7]
    // 0xba4078: StoreField: r2->field_13 = r0
    //     0xba4078: stur            w0, [x2, #0x13]
    // 0xba407c: r1 = <int>
    //     0xba407c: ldr             x1, [PP, #0x50]  ; [pp+0x50] TypeArguments: <int>
    // 0xba4080: r0 = AllocateGrowableArray()
    //     0xba4080: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xba4084: ldur            x1, [fp, #-0x18]
    // 0xba4088: StoreField: r0->field_f = r1
    //     0xba4088: stur            w1, [x0, #0xf]
    // 0xba408c: r1 = 4
    //     0xba408c: mov             x1, #4
    // 0xba4090: StoreField: r0->field_b = r1
    //     0xba4090: stur            w1, [x0, #0xb]
    // 0xba4094: LeaveFrame
    //     0xba4094: mov             SP, fp
    //     0xba4098: ldp             fp, lr, [SP], #0x10
    // 0xba409c: ret
    //     0xba409c: ret             
  }
}

// class id: 2771, size: 0xc, field offset: 0x8
class PlatformViewsService extends Object {

  static late final PlatformViewsService _instance; // offset: 0xc24

  static PlatformViewsService _instance() {
    // ** addr: 0xf753f8, size: 0x40
    // 0xf753f8: EnterFrame
    //     0xf753f8: stp             fp, lr, [SP, #-0x10]!
    //     0xf753fc: mov             fp, SP
    // 0xf75400: AllocStack(0x8)
    //     0xf75400: sub             SP, SP, #8
    // 0xf75404: CheckStackOverflow
    //     0xf75404: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf75408: cmp             SP, x16
    //     0xf7540c: b.ls            #0xf75430
    // 0xf75410: r0 = PlatformViewsService()
    //     0xf75410: bl              #0xf7569c  ; AllocatePlatformViewsServiceStub -> PlatformViewsService (size=0xc)
    // 0xf75414: mov             x1, x0
    // 0xf75418: stur            x0, [fp, #-8]
    // 0xf7541c: r0 = PlatformViewsService._()
    //     0xf7541c: bl              #0xf75438  ; [package:flutter/src/services/platform_views.dart] PlatformViewsService::PlatformViewsService._
    // 0xf75420: ldur            x0, [fp, #-8]
    // 0xf75424: LeaveFrame
    //     0xf75424: mov             SP, fp
    //     0xf75428: ldp             fp, lr, [SP], #0x10
    // 0xf7542c: ret
    //     0xf7542c: ret             
    // 0xf75430: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf75430: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf75434: b               #0xf75410
  }
  _ PlatformViewsService._(/* No info */) {
    // ** addr: 0xf75438, size: 0x84
    // 0xf75438: EnterFrame
    //     0xf75438: stp             fp, lr, [SP, #-0x10]!
    //     0xf7543c: mov             fp, SP
    // 0xf75440: AllocStack(0x18)
    //     0xf75440: sub             SP, SP, #0x18
    // 0xf75444: SetupParameters(PlatformViewsService this /* r1 => r2, fp-0x8 */)
    //     0xf75444: mov             x2, x1
    //     0xf75448: stur            x1, [fp, #-8]
    // 0xf7544c: CheckStackOverflow
    //     0xf7544c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf75450: cmp             SP, x16
    //     0xf75454: b.ls            #0xf754b4
    // 0xf75458: r16 = <int, (dynamic this) => void?>
    //     0xf75458: ldr             x16, [PP, #0x2eb0]  ; [pp+0x2eb0] TypeArguments: <int, (dynamic this) => void?>
    // 0xf7545c: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0xf75460: stp             lr, x16, [SP]
    // 0xf75464: r0 = Map._fromLiteral()
    //     0xf75464: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xf75468: ldur            x2, [fp, #-8]
    // 0xf7546c: StoreField: r2->field_7 = r0
    //     0xf7546c: stur            w0, [x2, #7]
    //     0xf75470: ldurb           w16, [x2, #-1]
    //     0xf75474: ldurb           w17, [x0, #-1]
    //     0xf75478: and             x16, x17, x16, lsr #2
    //     0xf7547c: tst             x16, HEAP, lsr #32
    //     0xf75480: b.eq            #0xf75488
    //     0xf75484: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf75488: r1 = Function '_onMethodCall@634227590':.
    //     0xf75488: add             x1, PP, #0x7d, lsl #12  ; [pp+0x7d3e0] AnonymousClosure: (0xf754bc), in [package:flutter/src/services/platform_views.dart] PlatformViewsService::_onMethodCall (0xf754f8)
    //     0xf7548c: ldr             x1, [x1, #0x3e0]
    // 0xf75490: r0 = AllocateClosure()
    //     0xf75490: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf75494: mov             x2, x0
    // 0xf75498: r1 = Instance_MethodChannel
    //     0xf75498: add             x1, PP, #0x7d, lsl #12  ; [pp+0x7d3e8] Obj!MethodChannel@129bbe1
    //     0xf7549c: ldr             x1, [x1, #0x3e8]
    // 0xf754a0: r0 = setMethodCallHandler()
    //     0xf754a0: bl              #0x83aa3c  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::setMethodCallHandler
    // 0xf754a4: r0 = Null
    //     0xf754a4: mov             x0, NULL
    // 0xf754a8: LeaveFrame
    //     0xf754a8: mov             SP, fp
    //     0xf754ac: ldp             fp, lr, [SP], #0x10
    // 0xf754b0: ret
    //     0xf754b0: ret             
    // 0xf754b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf754b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf754b8: b               #0xf75458
  }
  [closure] Future<void> _onMethodCall(dynamic, MethodCall) {
    // ** addr: 0xf754bc, size: 0x3c
    // 0xf754bc: EnterFrame
    //     0xf754bc: stp             fp, lr, [SP, #-0x10]!
    //     0xf754c0: mov             fp, SP
    // 0xf754c4: ldr             x0, [fp, #0x18]
    // 0xf754c8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf754c8: ldur            w1, [x0, #0x17]
    // 0xf754cc: DecompressPointer r1
    //     0xf754cc: add             x1, x1, HEAP, lsl #32
    // 0xf754d0: CheckStackOverflow
    //     0xf754d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf754d4: cmp             SP, x16
    //     0xf754d8: b.ls            #0xf754f0
    // 0xf754dc: ldr             x2, [fp, #0x10]
    // 0xf754e0: r0 = _onMethodCall()
    //     0xf754e0: bl              #0xf754f8  ; [package:flutter/src/services/platform_views.dart] PlatformViewsService::_onMethodCall
    // 0xf754e4: LeaveFrame
    //     0xf754e4: mov             SP, fp
    //     0xf754e8: ldp             fp, lr, [SP], #0x10
    // 0xf754ec: ret
    //     0xf754ec: ret             
    // 0xf754f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf754f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf754f4: b               #0xf754dc
  }
  _ _onMethodCall(/* No info */) {
    // ** addr: 0xf754f8, size: 0x1a4
    // 0xf754f8: EnterFrame
    //     0xf754f8: stp             fp, lr, [SP, #-0x10]!
    //     0xf754fc: mov             fp, SP
    // 0xf75500: AllocStack(0x30)
    //     0xf75500: sub             SP, SP, #0x30
    // 0xf75504: SetupParameters(PlatformViewsService this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0xf75504: stur            x1, [fp, #-0x10]
    //     0xf75508: stur            x2, [fp, #-0x18]
    // 0xf7550c: CheckStackOverflow
    //     0xf7550c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf75510: cmp             SP, x16
    //     0xf75514: b.ls            #0xf75690
    // 0xf75518: LoadField: r0 = r2->field_7
    //     0xf75518: ldur            w0, [x2, #7]
    // 0xf7551c: DecompressPointer r0
    //     0xf7551c: add             x0, x0, HEAP, lsl #32
    // 0xf75520: stur            x0, [fp, #-8]
    // 0xf75524: r16 = "viewFocused"
    //     0xf75524: add             x16, PP, #0x7d, lsl #12  ; [pp+0x7d3f0] "viewFocused"
    //     0xf75528: ldr             x16, [x16, #0x3f0]
    // 0xf7552c: stp             x0, x16, [SP]
    // 0xf75530: r0 = ==()
    //     0xf75530: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0xf75534: tbnz            w0, #4, #0xf75640
    // 0xf75538: ldur            x3, [fp, #-0x10]
    // 0xf7553c: ldur            x0, [fp, #-0x18]
    // 0xf75540: LoadField: r4 = r0->field_b
    //     0xf75540: ldur            w4, [x0, #0xb]
    // 0xf75544: DecompressPointer r4
    //     0xf75544: add             x4, x4, HEAP, lsl #32
    // 0xf75548: mov             x0, x4
    // 0xf7554c: stur            x4, [fp, #-0x20]
    // 0xf75550: r2 = Null
    //     0xf75550: mov             x2, NULL
    // 0xf75554: r1 = Null
    //     0xf75554: mov             x1, NULL
    // 0xf75558: branchIfSmi(r0, 0xf75580)
    //     0xf75558: tbz             w0, #0, #0xf75580
    // 0xf7555c: r4 = LoadClassIdInstr(r0)
    //     0xf7555c: ldur            x4, [x0, #-1]
    //     0xf75560: ubfx            x4, x4, #0xc, #0x14
    // 0xf75564: sub             x4, x4, #0x3c
    // 0xf75568: cmp             x4, #1
    // 0xf7556c: b.ls            #0xf75580
    // 0xf75570: r8 = int
    //     0xf75570: ldr             x8, [PP, #0x390]  ; [pp+0x390] Type: int
    // 0xf75574: r3 = Null
    //     0xf75574: add             x3, PP, #0x7d, lsl #12  ; [pp+0x7d3f8] Null
    //     0xf75578: ldr             x3, [x3, #0x3f8]
    // 0xf7557c: r0 = int()
    //     0xf7557c: bl              #0x13ee980  ; IsType_int_Stub
    // 0xf75580: ldur            x0, [fp, #-0x10]
    // 0xf75584: LoadField: r3 = r0->field_7
    //     0xf75584: ldur            w3, [x0, #7]
    // 0xf75588: DecompressPointer r3
    //     0xf75588: add             x3, x3, HEAP, lsl #32
    // 0xf7558c: mov             x1, x3
    // 0xf75590: ldur            x2, [fp, #-0x20]
    // 0xf75594: stur            x3, [fp, #-0x18]
    // 0xf75598: r0 = containsKey()
    //     0xf75598: bl              #0x12d5a5c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0xf7559c: tbnz            w0, #4, #0xf755ec
    // 0xf755a0: ldur            x0, [fp, #-0x18]
    // 0xf755a4: mov             x1, x0
    // 0xf755a8: ldur            x2, [fp, #-0x20]
    // 0xf755ac: r0 = _getValueOrData()
    //     0xf755ac: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xf755b0: mov             x1, x0
    // 0xf755b4: ldur            x0, [fp, #-0x18]
    // 0xf755b8: LoadField: r2 = r0->field_f
    //     0xf755b8: ldur            w2, [x0, #0xf]
    // 0xf755bc: DecompressPointer r2
    //     0xf755bc: add             x2, x2, HEAP, lsl #32
    // 0xf755c0: cmp             w2, w1
    // 0xf755c4: b.ne            #0xf755d0
    // 0xf755c8: r0 = Null
    //     0xf755c8: mov             x0, NULL
    // 0xf755cc: b               #0xf755d4
    // 0xf755d0: mov             x0, x1
    // 0xf755d4: cmp             w0, NULL
    // 0xf755d8: b.eq            #0xf75698
    // 0xf755dc: str             x0, [SP]
    // 0xf755e0: ClosureCall
    //     0xf755e0: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xf755e4: ldur            x2, [x0, #0x1f]
    //     0xf755e8: blr             x2
    // 0xf755ec: r1 = <void?>
    //     0xf755ec: ldr             x1, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xf755f0: r0 = _Future()
    //     0xf755f0: bl              #0x7f5dd4  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0xf755f4: stur            x0, [fp, #-0x10]
    // 0xf755f8: StoreField: r0->field_b = rZR
    //     0xf755f8: stur            xzr, [x0, #0xb]
    // 0xf755fc: r0 = LoadStaticField(0x364)
    //     0xf755fc: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf75600: ldr             x0, [x0, #0x6c8]
    // 0xf75604: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf75608: cmp             w0, w16
    // 0xf7560c: b.ne            #0xf75618
    // 0xf75610: r2 = _current
    //     0xf75610: ldr             x2, [PP, #0x2c0]  ; [pp+0x2c0] Field <Zone._current@5048458>: static late (offset: 0x364)
    // 0xf75614: r0 = InitLateStaticField()
    //     0xf75614: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0xf75618: mov             x1, x0
    // 0xf7561c: ldur            x0, [fp, #-0x10]
    // 0xf75620: StoreField: r0->field_13 = r1
    //     0xf75620: stur            w1, [x0, #0x13]
    // 0xf75624: mov             x1, x0
    // 0xf75628: r2 = Null
    //     0xf75628: mov             x2, NULL
    // 0xf7562c: r0 = _asyncComplete()
    //     0xf7562c: bl              #0x7eee44  ; [dart:async] _Future::_asyncComplete
    // 0xf75630: ldur            x0, [fp, #-0x10]
    // 0xf75634: LeaveFrame
    //     0xf75634: mov             SP, fp
    //     0xf75638: ldp             fp, lr, [SP], #0x10
    // 0xf7563c: ret
    //     0xf7563c: ret             
    // 0xf75640: ldur            x0, [fp, #-8]
    // 0xf75644: r1 = Null
    //     0xf75644: mov             x1, NULL
    // 0xf75648: r2 = 4
    //     0xf75648: mov             x2, #4
    // 0xf7564c: r0 = AllocateArray()
    //     0xf7564c: bl              #0x13df928  ; AllocateArrayStub
    // 0xf75650: mov             x1, x0
    // 0xf75654: ldur            x0, [fp, #-8]
    // 0xf75658: StoreField: r1->field_f = r0
    //     0xf75658: stur            w0, [x1, #0xf]
    // 0xf7565c: r16 = " was invoked but isn\'t implemented by PlatformViewsService"
    //     0xf7565c: add             x16, PP, #0x7d, lsl #12  ; [pp+0x7d408] " was invoked but isn\'t implemented by PlatformViewsService"
    //     0xf75660: ldr             x16, [x16, #0x408]
    // 0xf75664: StoreField: r1->field_13 = r16
    //     0xf75664: stur            w16, [x1, #0x13]
    // 0xf75668: str             x1, [SP]
    // 0xf7566c: r0 = _interpolate()
    //     0xf7566c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xf75670: stur            x0, [fp, #-8]
    // 0xf75674: r0 = UnimplementedError()
    //     0xf75674: bl              #0x7dd7c4  ; AllocateUnimplementedErrorStub -> UnimplementedError (size=0x10)
    // 0xf75678: mov             x1, x0
    // 0xf7567c: ldur            x0, [fp, #-8]
    // 0xf75680: StoreField: r1->field_b = r0
    //     0xf75680: stur            w0, [x1, #0xb]
    // 0xf75684: mov             x0, x1
    // 0xf75688: r0 = Throw()
    //     0xf75688: bl              #0x13ddb2c  ; ThrowStub
    // 0xf7568c: brk             #0
    // 0xf75690: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf75690: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf75694: b               #0xf75518
    // 0xf75698: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf75698: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static _ initSurfaceAndroidView(/* No info */) {
    // ** addr: 0x10d7c10, size: 0xf0
    // 0x10d7c10: EnterFrame
    //     0x10d7c10: stp             fp, lr, [SP, #-0x10]!
    //     0x10d7c14: mov             fp, SP
    // 0x10d7c18: AllocStack(0x30)
    //     0x10d7c18: sub             SP, SP, #0x30
    // 0x10d7c1c: SetupParameters(dynamic _ /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */, dynamic _ /* r3 => r0, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */, dynamic _ /* r6 => r6, fp-0x28 */, dynamic _ /* r7 => r7, fp-0x30 */)
    //     0x10d7c1c: mov             x0, x3
    //     0x10d7c20: stur            x3, [fp, #-0x18]
    //     0x10d7c24: mov             x3, x2
    //     0x10d7c28: stur            x2, [fp, #-0x10]
    //     0x10d7c2c: mov             x2, x1
    //     0x10d7c30: stur            x1, [fp, #-8]
    //     0x10d7c34: stur            x5, [fp, #-0x20]
    //     0x10d7c38: stur            x6, [fp, #-0x28]
    //     0x10d7c3c: stur            x7, [fp, #-0x30]
    // 0x10d7c40: CheckStackOverflow
    //     0x10d7c40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10d7c44: cmp             SP, x16
    //     0x10d7c48: b.ls            #0x10d7cf8
    // 0x10d7c4c: r0 = SurfaceAndroidViewController()
    //     0x10d7c4c: bl              #0x10d7fe4  ; AllocateSurfaceAndroidViewControllerStub -> SurfaceAndroidViewController (size=0x2c)
    // 0x10d7c50: mov             x1, x0
    // 0x10d7c54: ldur            x2, [fp, #-8]
    // 0x10d7c58: ldur            x3, [fp, #-0x10]
    // 0x10d7c5c: ldur            x5, [fp, #-0x20]
    // 0x10d7c60: ldur            x6, [fp, #-0x18]
    // 0x10d7c64: ldur            x7, [fp, #-0x30]
    // 0x10d7c68: stur            x0, [fp, #-8]
    // 0x10d7c6c: r0 = SurfaceAndroidViewController._()
    //     0x10d7c6c: bl              #0x10d7d00  ; [package:flutter/src/services/platform_views.dart] SurfaceAndroidViewController::SurfaceAndroidViewController._
    // 0x10d7c70: r0 = LoadStaticField(0xc24)
    //     0x10d7c70: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x10d7c74: ldr             x0, [x0, #0x1848]
    // 0x10d7c78: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10d7c7c: cmp             w0, w16
    // 0x10d7c80: b.ne            #0x10d7c90
    // 0x10d7c84: r2 = _instance
    //     0x10d7c84: add             x2, PP, #0x7d, lsl #12  ; [pp+0x7d3b0] Field <PlatformViewsService._instance@634227590>: static late final (offset: 0xc24)
    //     0x10d7c88: ldr             x2, [x2, #0x3b0]
    // 0x10d7c8c: r0 = InitLateFinalStaticField()
    //     0x10d7c8c: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x10d7c90: LoadField: r3 = r0->field_7
    //     0x10d7c90: ldur            w3, [x0, #7]
    // 0x10d7c94: DecompressPointer r3
    //     0x10d7c94: add             x3, x3, HEAP, lsl #32
    // 0x10d7c98: ldur            x0, [fp, #-0x28]
    // 0x10d7c9c: stur            x3, [fp, #-0x10]
    // 0x10d7ca0: cmp             w0, NULL
    // 0x10d7ca4: b.ne            #0x10d7cc0
    // 0x10d7ca8: r1 = Function '<anonymous closure>': static.
    //     0x10d7ca8: add             x1, PP, #0x7d, lsl #12  ; [pp+0x7d3b8] Function: [dart:ui] Shader::Shader._ (0x13cf838)
    //     0x10d7cac: ldr             x1, [x1, #0x3b8]
    // 0x10d7cb0: r2 = Null
    //     0x10d7cb0: mov             x2, NULL
    // 0x10d7cb4: r0 = AllocateClosure()
    //     0x10d7cb4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10d7cb8: mov             x3, x0
    // 0x10d7cbc: b               #0x10d7cc4
    // 0x10d7cc0: mov             x3, x0
    // 0x10d7cc4: ldur            x2, [fp, #-0x18]
    // 0x10d7cc8: r0 = BoxInt64Instr(r2)
    //     0x10d7cc8: sbfiz           x0, x2, #1, #0x1f
    //     0x10d7ccc: cmp             x2, x0, asr #1
    //     0x10d7cd0: b.eq            #0x10d7cdc
    //     0x10d7cd4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x10d7cd8: stur            x2, [x0, #7]
    // 0x10d7cdc: ldur            x1, [fp, #-0x10]
    // 0x10d7ce0: mov             x2, x0
    // 0x10d7ce4: r0 = []=()
    //     0x10d7ce4: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x10d7ce8: ldur            x0, [fp, #-8]
    // 0x10d7cec: LeaveFrame
    //     0x10d7cec: mov             SP, fp
    //     0x10d7cf0: ldp             fp, lr, [SP], #0x10
    // 0x10d7cf4: ret
    //     0x10d7cf4: ret             
    // 0x10d7cf8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10d7cf8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10d7cfc: b               #0x10d7c4c
  }
}

// class id: 2772, size: 0x10, field offset: 0x8
class PlatformViewsRegistry extends Object {

  _ getNextPlatformViewId(/* No info */) {
    // ** addr: 0xf74ef8, size: 0x10
    // 0xf74ef8: LoadField: r0 = r1->field_7
    //     0xf74ef8: ldur            x0, [x1, #7]
    // 0xf74efc: add             x2, x0, #1
    // 0xf74f00: StoreField: r1->field_7 = r2
    //     0xf74f00: stur            x2, [x1, #7]
    // 0xf74f04: ret
    //     0xf74f04: ret             
  }
}

// class id: 8207, size: 0x14, field offset: 0x14
enum _AndroidViewState extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11ab674, size: 0x64
    // 0x11ab674: EnterFrame
    //     0x11ab674: stp             fp, lr, [SP, #-0x10]!
    //     0x11ab678: mov             fp, SP
    // 0x11ab67c: AllocStack(0x10)
    //     0x11ab67c: sub             SP, SP, #0x10
    // 0x11ab680: SetupParameters(_AndroidViewState this /* r1 => r0, fp-0x8 */)
    //     0x11ab680: mov             x0, x1
    //     0x11ab684: stur            x1, [fp, #-8]
    // 0x11ab688: CheckStackOverflow
    //     0x11ab688: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11ab68c: cmp             SP, x16
    //     0x11ab690: b.ls            #0x11ab6d0
    // 0x11ab694: r1 = Null
    //     0x11ab694: mov             x1, NULL
    // 0x11ab698: r2 = 4
    //     0x11ab698: mov             x2, #4
    // 0x11ab69c: r0 = AllocateArray()
    //     0x11ab69c: bl              #0x13df928  ; AllocateArrayStub
    // 0x11ab6a0: r16 = "_AndroidViewState."
    //     0x11ab6a0: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8ce40] "_AndroidViewState."
    //     0x11ab6a4: ldr             x16, [x16, #0xe40]
    // 0x11ab6a8: StoreField: r0->field_f = r16
    //     0x11ab6a8: stur            w16, [x0, #0xf]
    // 0x11ab6ac: ldur            x1, [fp, #-8]
    // 0x11ab6b0: LoadField: r2 = r1->field_f
    //     0x11ab6b0: ldur            w2, [x1, #0xf]
    // 0x11ab6b4: DecompressPointer r2
    //     0x11ab6b4: add             x2, x2, HEAP, lsl #32
    // 0x11ab6b8: StoreField: r0->field_13 = r2
    //     0x11ab6b8: stur            w2, [x0, #0x13]
    // 0x11ab6bc: str             x0, [SP]
    // 0x11ab6c0: r0 = _interpolate()
    //     0x11ab6c0: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11ab6c4: LeaveFrame
    //     0x11ab6c4: mov             SP, fp
    //     0x11ab6c8: ldp             fp, lr, [SP], #0x10
    // 0x11ab6cc: ret
    //     0x11ab6cc: ret             
    // 0x11ab6d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11ab6d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11ab6d4: b               #0x11ab694
  }
}
