// lib: , url: package:flutter/src/services/platform_channel.dart

// class id: 1049082, size: 0x8
class :: {

  static _ _findBinaryMessenger(/* No info */) {
    // ** addr: 0x83af88, size: 0x78
    // 0x83af88: EnterFrame
    //     0x83af88: stp             fp, lr, [SP, #-0x10]!
    //     0x83af8c: mov             fp, SP
    // 0x83af90: CheckStackOverflow
    //     0x83af90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x83af94: cmp             SP, x16
    //     0x83af98: b.ls            #0x83aff0
    // 0x83af9c: r0 = LoadStaticField(0x508)
    //     0x83af9c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x83afa0: ldr             x0, [x0, #0xa10]
    // 0x83afa4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x83afa8: cmp             w0, w16
    // 0x83afac: b.ne            #0x83afb8
    // 0x83afb0: r2 = instance
    //     0x83afb0: ldr             x2, [PP, #0x1570]  ; [pp+0x1570] Field <RootIsolateToken.instance>: static late final (offset: 0x508)
    // 0x83afb4: r0 = InitLateFinalStaticField()
    //     0x83afb4: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x83afb8: cmp             w0, NULL
    // 0x83afbc: b.ne            #0x83afc8
    // 0x83afc0: r0 = instance()
    //     0x83afc0: bl              #0x83b020  ; [package:flutter/src/services/_background_isolate_binary_messenger_io.dart] BackgroundIsolateBinaryMessenger::instance
    // 0x83afc4: b               #0x83afe4
    // 0x83afc8: r0 = instance()
    //     0x83afc8: bl              #0x83b000  ; [package:flutter/src/services/binding.dart] ServicesBinding::instance
    // 0x83afcc: LoadField: r1 = r0->field_97
    //     0x83afcc: ldur            w1, [x0, #0x97]
    // 0x83afd0: DecompressPointer r1
    //     0x83afd0: add             x1, x1, HEAP, lsl #32
    // 0x83afd4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x83afd8: cmp             w1, w16
    // 0x83afdc: b.eq            #0x83aff8
    // 0x83afe0: r0 = Instance__DefaultBinaryMessenger
    //     0x83afe0: ldr             x0, [PP, #0x848]  ; [pp+0x848] Obj!_DefaultBinaryMessenger@129c071
    // 0x83afe4: LeaveFrame
    //     0x83afe4: mov             SP, fp
    //     0x83afe8: ldp             fp, lr, [SP], #0x10
    // 0x83afec: ret
    //     0x83afec: ret             
    // 0x83aff0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83aff0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83aff4: b               #0x83af9c
    // 0x83aff8: r9 = _defaultBinaryMessenger
    //     0x83aff8: ldr             x9, [PP, #0x1578]  ; [pp+0x1578] Field <_MixinApplication204&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding@18353248._defaultBinaryMessenger@137240726>: late final (offset: 0x98)
    // 0x83affc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x83affc: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 2773, size: 0x14, field offset: 0x8
//   const constructor, 
class EventChannel extends Object {

  _OneByteString field_8;
  StandardMethodCodec field_c;

  _ receiveBroadcastStream(/* No info */) {
    // ** addr: 0x8c35d4, size: 0xe4
    // 0x8c35d4: EnterFrame
    //     0x8c35d4: stp             fp, lr, [SP, #-0x10]!
    //     0x8c35d8: mov             fp, SP
    // 0x8c35dc: AllocStack(0x30)
    //     0x8c35dc: sub             SP, SP, #0x30
    // 0x8c35e0: SetupParameters(EventChannel this /* r1 => r1, fp-0x8 */)
    //     0x8c35e0: stur            x1, [fp, #-8]
    // 0x8c35e4: CheckStackOverflow
    //     0x8c35e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c35e8: cmp             SP, x16
    //     0x8c35ec: b.ls            #0x8c36b0
    // 0x8c35f0: r1 = 3
    //     0x8c35f0: mov             x1, #3
    // 0x8c35f4: r0 = AllocateContext()
    //     0x8c35f4: bl              #0x13de838  ; AllocateContextStub
    // 0x8c35f8: mov             x1, x0
    // 0x8c35fc: ldur            x0, [fp, #-8]
    // 0x8c3600: stur            x1, [fp, #-0x20]
    // 0x8c3604: StoreField: r1->field_f = r0
    //     0x8c3604: stur            w0, [x1, #0xf]
    // 0x8c3608: LoadField: r2 = r0->field_7
    //     0x8c3608: ldur            w2, [x0, #7]
    // 0x8c360c: DecompressPointer r2
    //     0x8c360c: add             x2, x2, HEAP, lsl #32
    // 0x8c3610: stur            x2, [fp, #-0x18]
    // 0x8c3614: LoadField: r3 = r0->field_b
    //     0x8c3614: ldur            w3, [x0, #0xb]
    // 0x8c3618: DecompressPointer r3
    //     0x8c3618: add             x3, x3, HEAP, lsl #32
    // 0x8c361c: stur            x3, [fp, #-0x10]
    // 0x8c3620: r0 = MethodChannel()
    //     0x8c3620: bl              #0x8c37f8  ; AllocateMethodChannelStub -> MethodChannel (size=0x14)
    // 0x8c3624: mov             x1, x0
    // 0x8c3628: ldur            x0, [fp, #-0x18]
    // 0x8c362c: StoreField: r1->field_7 = r0
    //     0x8c362c: stur            w0, [x1, #7]
    // 0x8c3630: ldur            x0, [fp, #-0x10]
    // 0x8c3634: StoreField: r1->field_b = r0
    //     0x8c3634: stur            w0, [x1, #0xb]
    // 0x8c3638: ldur            x0, [fp, #-0x20]
    // 0x8c363c: StoreField: r0->field_13 = r1
    //     0x8c363c: stur            w1, [x0, #0x13]
    // 0x8c3640: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0x8c3644: ArrayStore: r0[0] = r1  ; List_4
    //     0x8c3644: stur            w1, [x0, #0x17]
    // 0x8c3648: mov             x2, x0
    // 0x8c364c: r1 = Function '<anonymous closure>':.
    //     0x8c364c: ldr             x1, [PP, #0x830]  ; [pp+0x830] AnonymousClosure: (0x8c3948), in [package:flutter/src/services/platform_channel.dart] EventChannel::receiveBroadcastStream (0x8c35d4)
    // 0x8c3650: r0 = AllocateClosure()
    //     0x8c3650: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8c3654: ldur            x2, [fp, #-0x20]
    // 0x8c3658: r1 = Function '<anonymous closure>':.
    //     0x8c3658: ldr             x1, [PP, #0x838]  ; [pp+0x838] AnonymousClosure: (0x8c3804), in [package:flutter/src/services/platform_channel.dart] EventChannel::receiveBroadcastStream (0x8c35d4)
    // 0x8c365c: stur            x0, [fp, #-8]
    // 0x8c3660: r0 = AllocateClosure()
    //     0x8c3660: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8c3664: ldur            x16, [fp, #-8]
    // 0x8c3668: stp             x0, x16, [SP]
    // 0x8c366c: r1 = Null
    //     0x8c366c: mov             x1, NULL
    // 0x8c3670: r4 = const [0, 0x3, 0x2, 0x1, onCancel, 0x2, onListen, 0x1, null]
    //     0x8c3670: ldr             x4, [PP, #0x840]  ; [pp+0x840] List(9) [0, 0x3, 0x2, 0x1, "onCancel", 0x2, "onListen", 0x1, Null]
    // 0x8c3674: r0 = StreamController.broadcast()
    //     0x8c3674: bl              #0x8c36b8  ; [dart:async] StreamController::StreamController.broadcast
    // 0x8c3678: mov             x2, x0
    // 0x8c367c: ldur            x1, [fp, #-0x20]
    // 0x8c3680: ArrayStore: r1[0] = r0  ; List_4
    //     0x8c3680: stur            w0, [x1, #0x17]
    //     0x8c3684: ldurb           w16, [x1, #-1]
    //     0x8c3688: ldurb           w17, [x0, #-1]
    //     0x8c368c: and             x16, x17, x16, lsr #2
    //     0x8c3690: tst             x16, HEAP, lsr #32
    //     0x8c3694: b.eq            #0x8c369c
    //     0x8c3698: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8c369c: mov             x1, x2
    // 0x8c36a0: r0 = stream()
    //     0x8c36a0: bl              #0x12352f8  ; [dart:async] _BroadcastStreamController::stream
    // 0x8c36a4: LeaveFrame
    //     0x8c36a4: mov             SP, fp
    //     0x8c36a8: ldp             fp, lr, [SP], #0x10
    // 0x8c36ac: ret
    //     0x8c36ac: ret             
    // 0x8c36b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c36b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c36b4: b               #0x8c35f0
  }
  [closure] Future<void> <anonymous closure>(dynamic) async {
    // ** addr: 0x8c3804, size: 0x144
    // 0x8c3804: EnterFrame
    //     0x8c3804: stp             fp, lr, [SP, #-0x10]!
    //     0x8c3808: mov             fp, SP
    // 0x8c380c: AllocStack(0x90)
    //     0x8c380c: sub             SP, SP, #0x90
    // 0x8c3810: SetupParameters(EventChannel this /* r1 */)
    //     0x8c3810: stur            NULL, [fp, #-8]
    //     0x8c3814: mov             x0, #0
    //     0x8c3818: add             x1, fp, w0, sxtw #2
    //     0x8c381c: ldr             x1, [x1, #0x10]
    //     0x8c3820: ldur            w2, [x1, #0x17]
    //     0x8c3824: add             x2, x2, HEAP, lsl #32
    //     0x8c3828: stur            x2, [fp, #-0x60]
    // 0x8c382c: CheckStackOverflow
    //     0x8c382c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c3830: cmp             SP, x16
    //     0x8c3834: b.ls            #0x8c3940
    // 0x8c3838: InitAsync() -> Future<void?>
    //     0x8c3838: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0x8c383c: bl              #0x7f5e44  ; InitAsyncStub
    // 0x8c3840: r0 = _findBinaryMessenger()
    //     0x8c3840: bl              #0x83af88  ; [package:flutter/src/services/platform_channel.dart] ::_findBinaryMessenger
    // 0x8c3844: ldur            x0, [fp, #-0x60]
    // 0x8c3848: LoadField: r1 = r0->field_f
    //     0x8c3848: ldur            w1, [x0, #0xf]
    // 0x8c384c: DecompressPointer r1
    //     0x8c384c: add             x1, x1, HEAP, lsl #32
    // 0x8c3850: LoadField: r2 = r1->field_7
    //     0x8c3850: ldur            w2, [x1, #7]
    // 0x8c3854: DecompressPointer r2
    //     0x8c3854: add             x2, x2, HEAP, lsl #32
    // 0x8c3858: r1 = Instance__DefaultBinaryMessenger
    //     0x8c3858: ldr             x1, [PP, #0x848]  ; [pp+0x848] Obj!_DefaultBinaryMessenger@129c071
    // 0x8c385c: r3 = Null
    //     0x8c385c: mov             x3, NULL
    // 0x8c3860: r0 = setMessageHandler()
    //     0x8c3860: bl              #0x83aaf4  ; [package:flutter/src/services/binding.dart] _DefaultBinaryMessenger::setMessageHandler
    // 0x8c3864: ldur            x0, [fp, #-0x60]
    // 0x8c3868: LoadField: r1 = r0->field_13
    //     0x8c3868: ldur            w1, [x0, #0x13]
    // 0x8c386c: DecompressPointer r1
    //     0x8c386c: add             x1, x1, HEAP, lsl #32
    // 0x8c3870: r16 = <void?>
    //     0x8c3870: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x8c3874: stp             x1, x16, [SP, #0x10]
    // 0x8c3878: r16 = "cancel"
    //     0x8c3878: ldr             x16, [PP, #0x850]  ; [pp+0x850] "cancel"
    // 0x8c387c: stp             NULL, x16, [SP]
    // 0x8c3880: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x8c3880: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x8c3884: r0 = invokeMethod()
    //     0x8c3884: bl              #0x130b008  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0x8c3888: mov             x1, x0
    // 0x8c388c: stur            x1, [fp, #-0x68]
    // 0x8c3890: r0 = Await()
    //     0x8c3890: bl              #0x7f5c00  ; AwaitStub
    // 0x8c3894: b               #0x8c3938
    // 0x8c3898: sub             SP, fp, #0x90
    // 0x8c389c: ldur            x3, [fp, #-0x60]
    // 0x8c38a0: mov             x4, x0
    // 0x8c38a4: stur            x0, [fp, #-0x68]
    // 0x8c38a8: mov             x0, x1
    // 0x8c38ac: stur            x1, [fp, #-0x70]
    // 0x8c38b0: r1 = Null
    //     0x8c38b0: mov             x1, NULL
    // 0x8c38b4: r2 = 4
    //     0x8c38b4: mov             x2, #4
    // 0x8c38b8: r0 = AllocateArray()
    //     0x8c38b8: bl              #0x13df928  ; AllocateArrayStub
    // 0x8c38bc: r16 = "while de-activating platform stream on channel "
    //     0x8c38bc: ldr             x16, [PP, #0x858]  ; [pp+0x858] "while de-activating platform stream on channel "
    // 0x8c38c0: StoreField: r0->field_f = r16
    //     0x8c38c0: stur            w16, [x0, #0xf]
    // 0x8c38c4: ldur            x1, [fp, #-0x60]
    // 0x8c38c8: LoadField: r2 = r1->field_f
    //     0x8c38c8: ldur            w2, [x1, #0xf]
    // 0x8c38cc: DecompressPointer r2
    //     0x8c38cc: add             x2, x2, HEAP, lsl #32
    // 0x8c38d0: LoadField: r1 = r2->field_7
    //     0x8c38d0: ldur            w1, [x2, #7]
    // 0x8c38d4: DecompressPointer r1
    //     0x8c38d4: add             x1, x1, HEAP, lsl #32
    // 0x8c38d8: StoreField: r0->field_13 = r1
    //     0x8c38d8: stur            w1, [x0, #0x13]
    // 0x8c38dc: str             x0, [SP]
    // 0x8c38e0: r0 = _interpolate()
    //     0x8c38e0: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x8c38e4: r1 = <List<Object>>
    //     0x8c38e4: ldr             x1, [PP, #0x860]  ; [pp+0x860] TypeArguments: <List<Object>>
    // 0x8c38e8: stur            x0, [fp, #-0x60]
    // 0x8c38ec: r0 = ErrorDescription()
    //     0x8c38ec: bl              #0x829ca4  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x2c)
    // 0x8c38f0: mov             x1, x0
    // 0x8c38f4: ldur            x2, [fp, #-0x60]
    // 0x8c38f8: r3 = Instance_DiagnosticLevel
    //     0x8c38f8: ldr             x3, [PP, #0x868]  ; [pp+0x868] Obj!DiagnosticLevel@12c5f41
    // 0x8c38fc: stur            x0, [fp, #-0x60]
    // 0x8c3900: r0 = _ErrorDiagnostic()
    //     0x8c3900: bl              #0x829bec  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0x8c3904: r0 = FlutterErrorDetails()
    //     0x8c3904: bl              #0x829be0  ; AllocateFlutterErrorDetailsStub -> FlutterErrorDetails (size=0x20)
    // 0x8c3908: mov             x1, x0
    // 0x8c390c: ldur            x0, [fp, #-0x68]
    // 0x8c3910: StoreField: r1->field_7 = r0
    //     0x8c3910: stur            w0, [x1, #7]
    // 0x8c3914: ldur            x0, [fp, #-0x70]
    // 0x8c3918: StoreField: r1->field_b = r0
    //     0x8c3918: stur            w0, [x1, #0xb]
    // 0x8c391c: r0 = "services library"
    //     0x8c391c: ldr             x0, [PP, #0x870]  ; [pp+0x870] "services library"
    // 0x8c3920: StoreField: r1->field_f = r0
    //     0x8c3920: stur            w0, [x1, #0xf]
    // 0x8c3924: ldur            x0, [fp, #-0x60]
    // 0x8c3928: StoreField: r1->field_13 = r0
    //     0x8c3928: stur            w0, [x1, #0x13]
    // 0x8c392c: r0 = false
    //     0x8c392c: add             x0, NULL, #0x30  ; false
    // 0x8c3930: StoreField: r1->field_1b = r0
    //     0x8c3930: stur            w0, [x1, #0x1b]
    // 0x8c3934: r0 = reportError()
    //     0x8c3934: bl              #0x829a24  ; [package:flutter/src/foundation/assertions.dart] FlutterError::reportError
    // 0x8c3938: r0 = Null
    //     0x8c3938: mov             x0, NULL
    // 0x8c393c: r0 = ReturnAsyncNotFuture()
    //     0x8c393c: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x8c3940: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c3940: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c3944: b               #0x8c3838
  }
  [closure] Future<void> <anonymous closure>(dynamic) async {
    // ** addr: 0x8c3948, size: 0x158
    // 0x8c3948: EnterFrame
    //     0x8c3948: stp             fp, lr, [SP, #-0x10]!
    //     0x8c394c: mov             fp, SP
    // 0x8c3950: AllocStack(0x90)
    //     0x8c3950: sub             SP, SP, #0x90
    // 0x8c3954: SetupParameters(EventChannel this /* r1 */)
    //     0x8c3954: stur            NULL, [fp, #-8]
    //     0x8c3958: mov             x0, #0
    //     0x8c395c: add             x1, fp, w0, sxtw #2
    //     0x8c3960: ldr             x1, [x1, #0x10]
    //     0x8c3964: ldur            w2, [x1, #0x17]
    //     0x8c3968: add             x2, x2, HEAP, lsl #32
    //     0x8c396c: stur            x2, [fp, #-0x60]
    // 0x8c3970: CheckStackOverflow
    //     0x8c3970: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c3974: cmp             SP, x16
    //     0x8c3978: b.ls            #0x8c3a98
    // 0x8c397c: InitAsync() -> Future<void?>
    //     0x8c397c: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0x8c3980: bl              #0x7f5e44  ; InitAsyncStub
    // 0x8c3984: r0 = _findBinaryMessenger()
    //     0x8c3984: bl              #0x83af88  ; [package:flutter/src/services/platform_channel.dart] ::_findBinaryMessenger
    // 0x8c3988: ldur            x0, [fp, #-0x60]
    // 0x8c398c: LoadField: r1 = r0->field_f
    //     0x8c398c: ldur            w1, [x0, #0xf]
    // 0x8c3990: DecompressPointer r1
    //     0x8c3990: add             x1, x1, HEAP, lsl #32
    // 0x8c3994: LoadField: r3 = r1->field_7
    //     0x8c3994: ldur            w3, [x1, #7]
    // 0x8c3998: DecompressPointer r3
    //     0x8c3998: add             x3, x3, HEAP, lsl #32
    // 0x8c399c: mov             x2, x0
    // 0x8c39a0: stur            x3, [fp, #-0x68]
    // 0x8c39a4: r1 = Function '<anonymous closure>':.
    //     0x8c39a4: ldr             x1, [PP, #0x1598]  ; [pp+0x1598] AnonymousClosure: (0x8c3aa0), in [package:flutter/src/services/platform_channel.dart] EventChannel::receiveBroadcastStream (0x8c35d4)
    // 0x8c39a8: r0 = AllocateClosure()
    //     0x8c39a8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8c39ac: ldur            x2, [fp, #-0x68]
    // 0x8c39b0: mov             x3, x0
    // 0x8c39b4: r1 = Instance__DefaultBinaryMessenger
    //     0x8c39b4: ldr             x1, [PP, #0x848]  ; [pp+0x848] Obj!_DefaultBinaryMessenger@129c071
    // 0x8c39b8: r0 = setMessageHandler()
    //     0x8c39b8: bl              #0x83aaf4  ; [package:flutter/src/services/binding.dart] _DefaultBinaryMessenger::setMessageHandler
    // 0x8c39bc: ldur            x0, [fp, #-0x60]
    // 0x8c39c0: LoadField: r1 = r0->field_13
    //     0x8c39c0: ldur            w1, [x0, #0x13]
    // 0x8c39c4: DecompressPointer r1
    //     0x8c39c4: add             x1, x1, HEAP, lsl #32
    // 0x8c39c8: r16 = <void?>
    //     0x8c39c8: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x8c39cc: stp             x1, x16, [SP, #0x10]
    // 0x8c39d0: r16 = "listen"
    //     0x8c39d0: ldr             x16, [PP, #0x15a0]  ; [pp+0x15a0] "listen"
    // 0x8c39d4: stp             NULL, x16, [SP]
    // 0x8c39d8: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x8c39d8: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x8c39dc: r0 = invokeMethod()
    //     0x8c39dc: bl              #0x130b008  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0x8c39e0: mov             x1, x0
    // 0x8c39e4: stur            x1, [fp, #-0x68]
    // 0x8c39e8: r0 = Await()
    //     0x8c39e8: bl              #0x7f5c00  ; AwaitStub
    // 0x8c39ec: b               #0x8c3a90
    // 0x8c39f0: sub             SP, fp, #0x90
    // 0x8c39f4: ldur            x3, [fp, #-0x60]
    // 0x8c39f8: mov             x4, x0
    // 0x8c39fc: stur            x0, [fp, #-0x68]
    // 0x8c3a00: mov             x0, x1
    // 0x8c3a04: stur            x1, [fp, #-0x70]
    // 0x8c3a08: r1 = Null
    //     0x8c3a08: mov             x1, NULL
    // 0x8c3a0c: r2 = 4
    //     0x8c3a0c: mov             x2, #4
    // 0x8c3a10: r0 = AllocateArray()
    //     0x8c3a10: bl              #0x13df928  ; AllocateArrayStub
    // 0x8c3a14: r16 = "while activating platform stream on channel "
    //     0x8c3a14: ldr             x16, [PP, #0x15a8]  ; [pp+0x15a8] "while activating platform stream on channel "
    // 0x8c3a18: StoreField: r0->field_f = r16
    //     0x8c3a18: stur            w16, [x0, #0xf]
    // 0x8c3a1c: ldur            x1, [fp, #-0x60]
    // 0x8c3a20: LoadField: r2 = r1->field_f
    //     0x8c3a20: ldur            w2, [x1, #0xf]
    // 0x8c3a24: DecompressPointer r2
    //     0x8c3a24: add             x2, x2, HEAP, lsl #32
    // 0x8c3a28: LoadField: r1 = r2->field_7
    //     0x8c3a28: ldur            w1, [x2, #7]
    // 0x8c3a2c: DecompressPointer r1
    //     0x8c3a2c: add             x1, x1, HEAP, lsl #32
    // 0x8c3a30: StoreField: r0->field_13 = r1
    //     0x8c3a30: stur            w1, [x0, #0x13]
    // 0x8c3a34: str             x0, [SP]
    // 0x8c3a38: r0 = _interpolate()
    //     0x8c3a38: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x8c3a3c: r1 = <List<Object>>
    //     0x8c3a3c: ldr             x1, [PP, #0x860]  ; [pp+0x860] TypeArguments: <List<Object>>
    // 0x8c3a40: stur            x0, [fp, #-0x60]
    // 0x8c3a44: r0 = ErrorDescription()
    //     0x8c3a44: bl              #0x829ca4  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x2c)
    // 0x8c3a48: mov             x1, x0
    // 0x8c3a4c: ldur            x2, [fp, #-0x60]
    // 0x8c3a50: r3 = Instance_DiagnosticLevel
    //     0x8c3a50: ldr             x3, [PP, #0x868]  ; [pp+0x868] Obj!DiagnosticLevel@12c5f41
    // 0x8c3a54: stur            x0, [fp, #-0x60]
    // 0x8c3a58: r0 = _ErrorDiagnostic()
    //     0x8c3a58: bl              #0x829bec  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0x8c3a5c: r0 = FlutterErrorDetails()
    //     0x8c3a5c: bl              #0x829be0  ; AllocateFlutterErrorDetailsStub -> FlutterErrorDetails (size=0x20)
    // 0x8c3a60: mov             x1, x0
    // 0x8c3a64: ldur            x0, [fp, #-0x68]
    // 0x8c3a68: StoreField: r1->field_7 = r0
    //     0x8c3a68: stur            w0, [x1, #7]
    // 0x8c3a6c: ldur            x0, [fp, #-0x70]
    // 0x8c3a70: StoreField: r1->field_b = r0
    //     0x8c3a70: stur            w0, [x1, #0xb]
    // 0x8c3a74: r0 = "services library"
    //     0x8c3a74: ldr             x0, [PP, #0x870]  ; [pp+0x870] "services library"
    // 0x8c3a78: StoreField: r1->field_f = r0
    //     0x8c3a78: stur            w0, [x1, #0xf]
    // 0x8c3a7c: ldur            x0, [fp, #-0x60]
    // 0x8c3a80: StoreField: r1->field_13 = r0
    //     0x8c3a80: stur            w0, [x1, #0x13]
    // 0x8c3a84: r0 = false
    //     0x8c3a84: add             x0, NULL, #0x30  ; false
    // 0x8c3a88: StoreField: r1->field_1b = r0
    //     0x8c3a88: stur            w0, [x1, #0x1b]
    // 0x8c3a8c: r0 = reportError()
    //     0x8c3a8c: bl              #0x829a24  ; [package:flutter/src/foundation/assertions.dart] FlutterError::reportError
    // 0x8c3a90: r0 = Null
    //     0x8c3a90: mov             x0, NULL
    // 0x8c3a94: r0 = ReturnAsyncNotFuture()
    //     0x8c3a94: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x8c3a98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c3a98: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c3a9c: b               #0x8c397c
  }
  [closure] Future<Null> <anonymous closure>(dynamic, ByteData?) async {
    // ** addr: 0x8c3aa0, size: 0x164
    // 0x8c3aa0: EnterFrame
    //     0x8c3aa0: stp             fp, lr, [SP, #-0x10]!
    //     0x8c3aa4: mov             fp, SP
    // 0x8c3aa8: AllocStack(0x78)
    //     0x8c3aa8: sub             SP, SP, #0x78
    // 0x8c3aac: SetupParameters(EventChannel this /* r1 */, dynamic _ /* r2, fp-0x68 */)
    //     0x8c3aac: stur            NULL, [fp, #-8]
    //     0x8c3ab0: mov             x0, #0
    //     0x8c3ab4: add             x1, fp, w0, sxtw #2
    //     0x8c3ab8: ldr             x1, [x1, #0x18]
    //     0x8c3abc: add             x2, fp, w0, sxtw #2
    //     0x8c3ac0: ldr             x2, [x2, #0x10]
    //     0x8c3ac4: stur            x2, [fp, #-0x68]
    //     0x8c3ac8: ldur            w3, [x1, #0x17]
    //     0x8c3acc: add             x3, x3, HEAP, lsl #32
    //     0x8c3ad0: stur            x3, [fp, #-0x60]
    // 0x8c3ad4: CheckStackOverflow
    //     0x8c3ad4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c3ad8: cmp             SP, x16
    //     0x8c3adc: b.ls            #0x8c3bfc
    // 0x8c3ae0: InitAsync() -> Future<Null?>?
    //     0x8c3ae0: ldr             x0, [PP, #0x70]  ; [pp+0x70] TypeArguments: <Null?>
    //     0x8c3ae4: bl              #0x7f5e44  ; InitAsyncStub
    // 0x8c3ae8: ldur            x3, [fp, #-0x68]
    // 0x8c3aec: cmp             w3, NULL
    // 0x8c3af0: b.ne            #0x8c3b20
    // 0x8c3af4: ldur            x0, [fp, #-0x60]
    // 0x8c3af8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8c3af8: ldur            w1, [x0, #0x17]
    // 0x8c3afc: DecompressPointer r1
    //     0x8c3afc: add             x1, x1, HEAP, lsl #32
    // 0x8c3b00: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8c3b04: cmp             w1, w16
    // 0x8c3b08: b.eq            #0x8c3bbc
    // 0x8c3b0c: r0 = close()
    //     0x8c3b0c: bl              #0x80f99c  ; [dart:async] _BroadcastStreamController::close
    // 0x8c3b10: mov             x1, x0
    // 0x8c3b14: stur            x1, [fp, #-0x70]
    // 0x8c3b18: r0 = Await()
    //     0x8c3b18: bl              #0x7f5c00  ; AwaitStub
    // 0x8c3b1c: b               #0x8c3bb4
    // 0x8c3b20: ldur            x4, [fp, #-0x60]
    // 0x8c3b24: ArrayLoad: r5 = r4[0]  ; List_4
    //     0x8c3b24: ldur            w5, [x4, #0x17]
    // 0x8c3b28: DecompressPointer r5
    //     0x8c3b28: add             x5, x5, HEAP, lsl #32
    // 0x8c3b2c: stur            x5, [fp, #-0x70]
    // 0x8c3b30: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8c3b34: cmp             w5, w16
    // 0x8c3b38: b.eq            #0x8c3bcc
    // 0x8c3b3c: LoadField: r0 = r4->field_f
    //     0x8c3b3c: ldur            w0, [x4, #0xf]
    // 0x8c3b40: DecompressPointer r0
    //     0x8c3b40: add             x0, x0, HEAP, lsl #32
    // 0x8c3b44: LoadField: r1 = r0->field_b
    //     0x8c3b44: ldur            w1, [x0, #0xb]
    // 0x8c3b48: DecompressPointer r1
    //     0x8c3b48: add             x1, x1, HEAP, lsl #32
    // 0x8c3b4c: r0 = LoadClassIdInstr(r1)
    //     0x8c3b4c: ldur            x0, [x1, #-1]
    //     0x8c3b50: ubfx            x0, x0, #0xc, #0x14
    // 0x8c3b54: mov             x2, x3
    // 0x8c3b58: r0 = GDT[cid_x0 + -0xffe]()
    //     0x8c3b58: sub             lr, x0, #0xffe
    //     0x8c3b5c: ldr             lr, [x21, lr, lsl #3]
    //     0x8c3b60: blr             lr
    // 0x8c3b64: ldur            x1, [fp, #-0x70]
    // 0x8c3b68: mov             x2, x0
    // 0x8c3b6c: r0 = add()
    //     0x8c3b6c: bl              #0x7df8d8  ; [dart:async] _BroadcastStreamController::add
    // 0x8c3b70: b               #0x8c3bb4
    // 0x8c3b74: sub             SP, fp, #0x78
    // 0x8c3b78: mov             x2, x0
    // 0x8c3b7c: r0 = 60
    //     0x8c3b7c: mov             x0, #0x3c
    // 0x8c3b80: branchIfSmi(r2, 0x8c3b8c)
    //     0x8c3b80: tbz             w2, #0, #0x8c3b8c
    // 0x8c3b84: r0 = LoadClassIdInstr(r2)
    //     0x8c3b84: ldur            x0, [x2, #-1]
    //     0x8c3b88: ubfx            x0, x0, #0xc, #0x14
    // 0x8c3b8c: cmp             x0, #0xae4
    // 0x8c3b90: b.ne            #0x8c3bf0
    // 0x8c3b94: ldur            x0, [fp, #-0x60]
    // 0x8c3b98: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8c3b98: ldur            w1, [x0, #0x17]
    // 0x8c3b9c: DecompressPointer r1
    //     0x8c3b9c: add             x1, x1, HEAP, lsl #32
    // 0x8c3ba0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8c3ba4: cmp             w1, w16
    // 0x8c3ba8: b.eq            #0x8c3be0
    // 0x8c3bac: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x8c3bac: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x8c3bb0: r0 = addError()
    //     0x8c3bb0: bl              #0x827e0c  ; [dart:async] _BroadcastStreamController::addError
    // 0x8c3bb4: r0 = Null
    //     0x8c3bb4: mov             x0, NULL
    // 0x8c3bb8: r0 = ReturnAsyncNotFuture()
    //     0x8c3bb8: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x8c3bbc: r16 = "controller"
    //     0x8c3bbc: ldr             x16, [PP, #0x15b0]  ; [pp+0x15b0] "controller"
    // 0x8c3bc0: str             x16, [SP]
    // 0x8c3bc4: r0 = _throwLocalNotInitialized()
    //     0x8c3bc4: bl              #0x82b57c  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0x8c3bc8: brk             #0
    // 0x8c3bcc: mov             x0, x4
    // 0x8c3bd0: r16 = "controller"
    //     0x8c3bd0: ldr             x16, [PP, #0x15b0]  ; [pp+0x15b0] "controller"
    // 0x8c3bd4: str             x16, [SP]
    // 0x8c3bd8: r0 = _throwLocalNotInitialized()
    //     0x8c3bd8: bl              #0x82b57c  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0x8c3bdc: brk             #0
    // 0x8c3be0: r16 = "controller"
    //     0x8c3be0: ldr             x16, [PP, #0x15b0]  ; [pp+0x15b0] "controller"
    // 0x8c3be4: str             x16, [SP]
    // 0x8c3be8: r0 = _throwLocalNotInitialized()
    //     0x8c3be8: bl              #0x82b57c  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0x8c3bec: brk             #0
    // 0x8c3bf0: mov             x0, x2
    // 0x8c3bf4: r0 = ReThrow()
    //     0x8c3bf4: bl              #0x13ddb00  ; ReThrowStub
    // 0x8c3bf8: brk             #0
    // 0x8c3bfc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c3bfc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c3c00: b               #0x8c3ae0
  }
}

// class id: 2774, size: 0x14, field offset: 0x8
//   const constructor, 
class MethodChannel extends Object {

  _OneByteString field_8;
  StandardMethodCodec field_c;

  _ setMethodCallHandler(/* No info */) {
    // ** addr: 0x83aa3c, size: 0x88
    // 0x83aa3c: EnterFrame
    //     0x83aa3c: stp             fp, lr, [SP, #-0x10]!
    //     0x83aa40: mov             fp, SP
    // 0x83aa44: AllocStack(0x18)
    //     0x83aa44: sub             SP, SP, #0x18
    // 0x83aa48: SetupParameters(MethodChannel this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x83aa48: stur            x1, [fp, #-8]
    //     0x83aa4c: stur            x2, [fp, #-0x10]
    // 0x83aa50: CheckStackOverflow
    //     0x83aa50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x83aa54: cmp             SP, x16
    //     0x83aa58: b.ls            #0x83aabc
    // 0x83aa5c: r1 = 2
    //     0x83aa5c: mov             x1, #2
    // 0x83aa60: r0 = AllocateContext()
    //     0x83aa60: bl              #0x13de838  ; AllocateContextStub
    // 0x83aa64: mov             x1, x0
    // 0x83aa68: ldur            x0, [fp, #-8]
    // 0x83aa6c: stur            x1, [fp, #-0x18]
    // 0x83aa70: StoreField: r1->field_f = r0
    //     0x83aa70: stur            w0, [x1, #0xf]
    // 0x83aa74: ldur            x2, [fp, #-0x10]
    // 0x83aa78: StoreField: r1->field_13 = r2
    //     0x83aa78: stur            w2, [x1, #0x13]
    // 0x83aa7c: r0 = _findBinaryMessenger()
    //     0x83aa7c: bl              #0x83af88  ; [package:flutter/src/services/platform_channel.dart] ::_findBinaryMessenger
    // 0x83aa80: ldur            x0, [fp, #-8]
    // 0x83aa84: LoadField: r3 = r0->field_7
    //     0x83aa84: ldur            w3, [x0, #7]
    // 0x83aa88: DecompressPointer r3
    //     0x83aa88: add             x3, x3, HEAP, lsl #32
    // 0x83aa8c: ldur            x2, [fp, #-0x18]
    // 0x83aa90: stur            x3, [fp, #-0x10]
    // 0x83aa94: r1 = Function '<anonymous closure>':.
    //     0x83aa94: ldr             x1, [PP, #0x1c20]  ; [pp+0x1c20] AnonymousClosure: (0x83b128), in [package:flutter/src/services/platform_channel.dart] MethodChannel::setMethodCallHandler (0x83aa3c)
    // 0x83aa98: r0 = AllocateClosure()
    //     0x83aa98: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x83aa9c: ldur            x2, [fp, #-0x10]
    // 0x83aaa0: mov             x3, x0
    // 0x83aaa4: r1 = Instance__DefaultBinaryMessenger
    //     0x83aaa4: ldr             x1, [PP, #0x848]  ; [pp+0x848] Obj!_DefaultBinaryMessenger@129c071
    // 0x83aaa8: r0 = setMessageHandler()
    //     0x83aaa8: bl              #0x83aaf4  ; [package:flutter/src/services/binding.dart] _DefaultBinaryMessenger::setMessageHandler
    // 0x83aaac: r0 = Null
    //     0x83aaac: mov             x0, NULL
    // 0x83aab0: LeaveFrame
    //     0x83aab0: mov             SP, fp
    //     0x83aab4: ldp             fp, lr, [SP], #0x10
    // 0x83aab8: ret
    //     0x83aab8: ret             
    // 0x83aabc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83aabc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83aac0: b               #0x83aa5c
  }
  get _ binaryMessenger(/* No info */) {
    // ** addr: 0x83aac4, size: 0x30
    // 0x83aac4: EnterFrame
    //     0x83aac4: stp             fp, lr, [SP, #-0x10]!
    //     0x83aac8: mov             fp, SP
    // 0x83aacc: CheckStackOverflow
    //     0x83aacc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x83aad0: cmp             SP, x16
    //     0x83aad4: b.ls            #0x83aaec
    // 0x83aad8: r0 = _findBinaryMessenger()
    //     0x83aad8: bl              #0x83af88  ; [package:flutter/src/services/platform_channel.dart] ::_findBinaryMessenger
    // 0x83aadc: r0 = Instance__DefaultBinaryMessenger
    //     0x83aadc: ldr             x0, [PP, #0x848]  ; [pp+0x848] Obj!_DefaultBinaryMessenger@129c071
    // 0x83aae0: LeaveFrame
    //     0x83aae0: mov             SP, fp
    //     0x83aae4: ldp             fp, lr, [SP], #0x10
    // 0x83aae8: ret
    //     0x83aae8: ret             
    // 0x83aaec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83aaec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83aaf0: b               #0x83aad8
  }
  [closure] Future<ByteData?> <anonymous closure>(dynamic, ByteData?) {
    // ** addr: 0x83b128, size: 0x50
    // 0x83b128: EnterFrame
    //     0x83b128: stp             fp, lr, [SP, #-0x10]!
    //     0x83b12c: mov             fp, SP
    // 0x83b130: ldr             x0, [fp, #0x18]
    // 0x83b134: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x83b134: ldur            w1, [x0, #0x17]
    // 0x83b138: DecompressPointer r1
    //     0x83b138: add             x1, x1, HEAP, lsl #32
    // 0x83b13c: CheckStackOverflow
    //     0x83b13c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x83b140: cmp             SP, x16
    //     0x83b144: b.ls            #0x83b170
    // 0x83b148: LoadField: r0 = r1->field_f
    //     0x83b148: ldur            w0, [x1, #0xf]
    // 0x83b14c: DecompressPointer r0
    //     0x83b14c: add             x0, x0, HEAP, lsl #32
    // 0x83b150: LoadField: r3 = r1->field_13
    //     0x83b150: ldur            w3, [x1, #0x13]
    // 0x83b154: DecompressPointer r3
    //     0x83b154: add             x3, x3, HEAP, lsl #32
    // 0x83b158: mov             x1, x0
    // 0x83b15c: ldr             x2, [fp, #0x10]
    // 0x83b160: r0 = _handleAsMethodCall()
    //     0x83b160: bl              #0x83b178  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::_handleAsMethodCall
    // 0x83b164: LeaveFrame
    //     0x83b164: mov             SP, fp
    //     0x83b168: ldp             fp, lr, [SP], #0x10
    // 0x83b16c: ret
    //     0x83b16c: ret             
    // 0x83b170: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83b170: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83b174: b               #0x83b148
  }
  _ _handleAsMethodCall(/* No info */) async {
    // ** addr: 0x83b178, size: 0x198
    // 0x83b178: EnterFrame
    //     0x83b178: stp             fp, lr, [SP, #-0x10]!
    //     0x83b17c: mov             fp, SP
    // 0x83b180: AllocStack(0xc0)
    //     0x83b180: sub             SP, SP, #0xc0
    // 0x83b184: SetupParameters(MethodChannel this /* r1 => r3, fp-0x98 */, dynamic _ /* r3 => r1, fp-0xa0 */)
    //     0x83b184: stur            NULL, [fp, #-8]
    //     0x83b188: stur            x1, [fp, #-0x90]
    //     0x83b18c: mov             x16, x3
    //     0x83b190: mov             x3, x1
    //     0x83b194: mov             x1, x16
    //     0x83b198: stur            x2, [fp, #-0x98]
    //     0x83b19c: stur            x1, [fp, #-0xa0]
    // 0x83b1a0: CheckStackOverflow
    //     0x83b1a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x83b1a4: cmp             SP, x16
    //     0x83b1a8: b.ls            #0x83b308
    // 0x83b1ac: InitAsync() -> Future<ByteData?>
    //     0x83b1ac: ldr             x0, [PP, #0x14d0]  ; [pp+0x14d0] TypeArguments: <ByteData?>
    //     0x83b1b0: bl              #0x7f5e44  ; InitAsyncStub
    // 0x83b1b4: ldur            x3, [fp, #-0x90]
    // 0x83b1b8: LoadField: r4 = r3->field_b
    //     0x83b1b8: ldur            w4, [x3, #0xb]
    // 0x83b1bc: DecompressPointer r4
    //     0x83b1bc: add             x4, x4, HEAP, lsl #32
    // 0x83b1c0: stur            x4, [fp, #-0xa8]
    // 0x83b1c4: r0 = LoadClassIdInstr(r4)
    //     0x83b1c4: ldur            x0, [x4, #-1]
    //     0x83b1c8: ubfx            x0, x0, #0xc, #0x14
    // 0x83b1cc: mov             x1, x4
    // 0x83b1d0: ldur            x2, [fp, #-0x98]
    // 0x83b1d4: r0 = GDT[cid_x0 + -0xff2]()
    //     0x83b1d4: sub             lr, x0, #0xff2
    //     0x83b1d8: ldr             lr, [x21, lr, lsl #3]
    //     0x83b1dc: blr             lr
    // 0x83b1e0: mov             x1, x0
    // 0x83b1e4: stur            x1, [fp, #-0x98]
    // 0x83b1e8: ldur            x2, [fp, #-0xa8]
    // 0x83b1ec: ldur            x16, [fp, #-0xa0]
    // 0x83b1f0: stp             x1, x16, [SP]
    // 0x83b1f4: ldur            x0, [fp, #-0xa0]
    // 0x83b1f8: ClosureCall
    //     0x83b1f8: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x83b1fc: ldur            x2, [x0, #0x1f]
    //     0x83b200: blr             x2
    // 0x83b204: mov             x1, x0
    // 0x83b208: stur            x1, [fp, #-0xb0]
    // 0x83b20c: r0 = Await()
    //     0x83b20c: bl              #0x7f5c00  ; AwaitStub
    // 0x83b210: ldur            x3, [fp, #-0xa8]
    // 0x83b214: r1 = LoadClassIdInstr(r3)
    //     0x83b214: ldur            x1, [x3, #-1]
    //     0x83b218: ubfx            x1, x1, #0xc, #0x14
    // 0x83b21c: mov             x2, x0
    // 0x83b220: mov             x0, x1
    // 0x83b224: mov             x1, x3
    // 0x83b228: r0 = GDT[cid_x0 + -0xffc]()
    //     0x83b228: sub             lr, x0, #0xffc
    //     0x83b22c: ldr             lr, [x21, lr, lsl #3]
    //     0x83b230: blr             lr
    // 0x83b234: r0 = ReturnAsyncNotFuture()
    //     0x83b234: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x83b238: sub             SP, fp, #0xc0
    // 0x83b23c: r1 = 60
    //     0x83b23c: mov             x1, #0x3c
    // 0x83b240: branchIfSmi(r0, 0x83b24c)
    //     0x83b240: tbz             w0, #0, #0x83b24c
    // 0x83b244: r1 = LoadClassIdInstr(r0)
    //     0x83b244: ldur            x1, [x0, #-1]
    //     0x83b248: ubfx            x1, x1, #0xc, #0x14
    // 0x83b24c: cmp             x1, #0xae4
    // 0x83b250: b.ne            #0x83b29c
    // 0x83b254: ldur            x2, [fp, #-0xa8]
    // 0x83b258: LoadField: r1 = r0->field_7
    //     0x83b258: ldur            w1, [x0, #7]
    // 0x83b25c: DecompressPointer r1
    //     0x83b25c: add             x1, x1, HEAP, lsl #32
    // 0x83b260: LoadField: r3 = r0->field_b
    //     0x83b260: ldur            w3, [x0, #0xb]
    // 0x83b264: DecompressPointer r3
    //     0x83b264: add             x3, x3, HEAP, lsl #32
    // 0x83b268: LoadField: r4 = r0->field_f
    //     0x83b268: ldur            w4, [x0, #0xf]
    // 0x83b26c: DecompressPointer r4
    //     0x83b26c: add             x4, x4, HEAP, lsl #32
    // 0x83b270: r0 = LoadClassIdInstr(r2)
    //     0x83b270: ldur            x0, [x2, #-1]
    //     0x83b274: ubfx            x0, x0, #0xc, #0x14
    // 0x83b278: str             x4, [SP]
    // 0x83b27c: mov             x16, x1
    // 0x83b280: mov             x1, x2
    // 0x83b284: mov             x2, x16
    // 0x83b288: r4 = const [0, 0x4, 0x1, 0x3, details, 0x3, null]
    //     0x83b288: ldr             x4, [PP, #0x1c28]  ; [pp+0x1c28] List(7) [0, 0x4, 0x1, 0x3, "details", 0x3, Null]
    // 0x83b28c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x83b28c: sub             lr, x0, #1, lsl #12
    //     0x83b290: ldr             lr, [x21, lr, lsl #3]
    //     0x83b294: blr             lr
    // 0x83b298: r0 = ReturnAsyncNotFuture()
    //     0x83b298: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x83b29c: ldur            x2, [fp, #-0xa8]
    // 0x83b2a0: cmp             x1, #0xae3
    // 0x83b2a4: b.ne            #0x83b2b0
    // 0x83b2a8: r0 = Null
    //     0x83b2a8: mov             x0, NULL
    // 0x83b2ac: r0 = ReturnAsyncNotFuture()
    //     0x83b2ac: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x83b2b0: r1 = 60
    //     0x83b2b0: mov             x1, #0x3c
    // 0x83b2b4: branchIfSmi(r0, 0x83b2c0)
    //     0x83b2b4: tbz             w0, #0, #0x83b2c0
    // 0x83b2b8: r1 = LoadClassIdInstr(r0)
    //     0x83b2b8: ldur            x1, [x0, #-1]
    //     0x83b2bc: ubfx            x1, x1, #0xc, #0x14
    // 0x83b2c0: str             x0, [SP]
    // 0x83b2c4: mov             x0, x1
    // 0x83b2c8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x83b2c8: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x83b2cc: r0 = GDT[cid_x0 + 0x91c1]()
    //     0x83b2cc: mov             x17, #0x91c1
    //     0x83b2d0: add             lr, x0, x17
    //     0x83b2d4: ldr             lr, [x21, lr, lsl #3]
    //     0x83b2d8: blr             lr
    // 0x83b2dc: ldur            x1, [fp, #-0xa8]
    // 0x83b2e0: r2 = LoadClassIdInstr(r1)
    //     0x83b2e0: ldur            x2, [x1, #-1]
    //     0x83b2e4: ubfx            x2, x2, #0xc, #0x14
    // 0x83b2e8: mov             x3, x0
    // 0x83b2ec: mov             x0, x2
    // 0x83b2f0: r2 = "error"
    //     0x83b2f0: ldr             x2, [PP, #0x1c30]  ; [pp+0x1c30] "error"
    // 0x83b2f4: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x83b2f4: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x83b2f8: r0 = GDT[cid_x0 + -0x1000]()
    //     0x83b2f8: sub             lr, x0, #1, lsl #12
    //     0x83b2fc: ldr             lr, [x21, lr, lsl #3]
    //     0x83b300: blr             lr
    // 0x83b304: r0 = ReturnAsyncNotFuture()
    //     0x83b304: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x83b308: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83b308: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83b30c: b               #0x83b1ac
  }
  Future<Map<Y0, Y1>?> invokeMapMethod<Y0, Y1>(MethodChannel, String, [dynamic]) async {
    // ** addr: 0x8492b0, size: 0x124
    // 0x8492b0: EnterFrame
    //     0x8492b0: stp             fp, lr, [SP, #-0x10]!
    //     0x8492b4: mov             fp, SP
    // 0x8492b8: AllocStack(0x50)
    //     0x8492b8: sub             SP, SP, #0x50
    // 0x8492bc: SetupParameters(MethodChannel this /* r0, fp-0x28 */, dynamic _ /* r5, fp-0x20 */, [dynamic _ = Null /* r6, fp-0x18 */])
    //     0x8492bc: stur            NULL, [fp, #-8]
    //     0x8492c0: ldur            w0, [x4, #0x13]
    //     0x8492c4: sub             x1, x0, #4
    //     0x8492c8: add             x0, fp, w1, sxtw #2
    //     0x8492cc: ldr             x0, [x0, #0x18]
    //     0x8492d0: stur            x0, [fp, #-0x28]
    //     0x8492d4: add             x5, fp, w1, sxtw #2
    //     0x8492d8: ldr             x5, [x5, #0x10]
    //     0x8492dc: stur            x5, [fp, #-0x20]
    //     0x8492e0: cmp             w1, #2
    //     0x8492e4: b.lt            #0x8492f8
    //     0x8492e8: add             x2, fp, w1, sxtw #2
    //     0x8492ec: ldr             x2, [x2, #8]
    //     0x8492f0: mov             x6, x2
    //     0x8492f4: b               #0x8492fc
    //     0x8492f8: mov             x6, NULL
    //     0x8492fc: stur            x6, [fp, #-0x18]
    //     0x849300: ldur            w1, [x4, #0xf]
    //     0x849304: cbnz            w1, #0x849310
    //     0x849308: mov             x4, NULL
    //     0x84930c: b               #0x849320
    //     0x849310: ldur            w1, [x4, #0x17]
    //     0x849314: add             x2, fp, w1, sxtw #2
    //     0x849318: ldr             x2, [x2, #0x10]
    //     0x84931c: mov             x4, x2
    //     0x849320: stur            x4, [fp, #-0x10]
    // 0x849324: CheckStackOverflow
    //     0x849324: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x849328: cmp             SP, x16
    //     0x84932c: b.ls            #0x8493cc
    // 0x849330: mov             x1, x4
    // 0x849334: r2 = Null
    //     0x849334: mov             x2, NULL
    // 0x849338: r3 = <Map<Y0, Y1>?>
    //     0x849338: ldr             x3, [PP, #0x4128]  ; [pp+0x4128] TypeArguments: <Map<Y0, Y1>?>
    // 0x84933c: r30 = InstantiateTypeArgumentsStub
    //     0x84933c: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0x849340: LoadField: r30 = r30->field_7
    //     0x849340: ldur            lr, [lr, #7]
    // 0x849344: blr             lr
    // 0x849348: mov             x1, x0
    // 0x84934c: stur            x1, [fp, #-0x30]
    // 0x849350: r0 = InitAsync()
    //     0x849350: bl              #0x7f5e44  ; InitAsyncStub
    // 0x849354: ldur            x0, [fp, #-0x28]
    // 0x849358: r1 = LoadClassIdInstr(r0)
    //     0x849358: ldur            x1, [x0, #-1]
    //     0x84935c: ubfx            x1, x1, #0xc, #0x14
    // 0x849360: r16 = <Map>
    //     0x849360: ldr             x16, [PP, #0xa0]  ; [pp+0xa0] TypeArguments: <Map>
    // 0x849364: stp             x0, x16, [SP, #0x10]
    // 0x849368: ldur            x16, [fp, #-0x20]
    // 0x84936c: ldur            lr, [fp, #-0x18]
    // 0x849370: stp             lr, x16, [SP]
    // 0x849374: mov             x0, x1
    // 0x849378: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x849378: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x84937c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x84937c: sub             lr, x0, #1, lsl #12
    //     0x849380: ldr             lr, [x21, lr, lsl #3]
    //     0x849384: blr             lr
    // 0x849388: mov             x1, x0
    // 0x84938c: stur            x1, [fp, #-0x18]
    // 0x849390: r0 = Await()
    //     0x849390: bl              #0x7f5c00  ; AwaitStub
    // 0x849394: cmp             w0, NULL
    // 0x849398: b.ne            #0x8493a4
    // 0x84939c: r0 = Null
    //     0x84939c: mov             x0, NULL
    // 0x8493a0: b               #0x8493c8
    // 0x8493a4: r1 = LoadClassIdInstr(r0)
    //     0x8493a4: ldur            x1, [x0, #-1]
    //     0x8493a8: ubfx            x1, x1, #0xc, #0x14
    // 0x8493ac: ldur            x16, [fp, #-0x10]
    // 0x8493b0: stp             x0, x16, [SP]
    // 0x8493b4: mov             x0, x1
    // 0x8493b8: r4 = const [0x2, 0x1, 0x1, 0x1, null]
    //     0x8493b8: ldr             x4, [PP, #0x18e0]  ; [pp+0x18e0] List(5) [0x2, 0x1, 0x1, 0x1, Null]
    // 0x8493bc: r0 = GDT[cid_x0 + 0xfb3]()
    //     0x8493bc: add             lr, x0, #0xfb3
    //     0x8493c0: ldr             lr, [x21, lr, lsl #3]
    //     0x8493c4: blr             lr
    // 0x8493c8: r0 = ReturnAsyncNotFuture()
    //     0x8493c8: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x8493cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8493cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8493d0: b               #0x849330
  }
  Future<List<Y0>?> invokeListMethod<Y0>(MethodChannel, String, [dynamic]) async {
    // ** addr: 0x920090, size: 0x11c
    // 0x920090: EnterFrame
    //     0x920090: stp             fp, lr, [SP, #-0x10]!
    //     0x920094: mov             fp, SP
    // 0x920098: AllocStack(0x50)
    //     0x920098: sub             SP, SP, #0x50
    // 0x92009c: SetupParameters(MethodChannel this /* r0, fp-0x28 */, dynamic _ /* r5, fp-0x20 */, [dynamic _ = Null /* r6, fp-0x18 */])
    //     0x92009c: stur            NULL, [fp, #-8]
    //     0x9200a0: ldur            w0, [x4, #0x13]
    //     0x9200a4: sub             x1, x0, #4
    //     0x9200a8: add             x0, fp, w1, sxtw #2
    //     0x9200ac: ldr             x0, [x0, #0x18]
    //     0x9200b0: stur            x0, [fp, #-0x28]
    //     0x9200b4: add             x5, fp, w1, sxtw #2
    //     0x9200b8: ldr             x5, [x5, #0x10]
    //     0x9200bc: stur            x5, [fp, #-0x20]
    //     0x9200c0: cmp             w1, #2
    //     0x9200c4: b.lt            #0x9200d8
    //     0x9200c8: add             x2, fp, w1, sxtw #2
    //     0x9200cc: ldr             x2, [x2, #8]
    //     0x9200d0: mov             x6, x2
    //     0x9200d4: b               #0x9200dc
    //     0x9200d8: mov             x6, NULL
    //     0x9200dc: stur            x6, [fp, #-0x18]
    //     0x9200e0: ldur            w1, [x4, #0xf]
    //     0x9200e4: cbnz            w1, #0x9200f0
    //     0x9200e8: mov             x4, NULL
    //     0x9200ec: b               #0x920100
    //     0x9200f0: ldur            w1, [x4, #0x17]
    //     0x9200f4: add             x2, fp, w1, sxtw #2
    //     0x9200f8: ldr             x2, [x2, #0x10]
    //     0x9200fc: mov             x4, x2
    //     0x920100: stur            x4, [fp, #-0x10]
    // 0x920104: CheckStackOverflow
    //     0x920104: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x920108: cmp             SP, x16
    //     0x92010c: b.ls            #0x9201a4
    // 0x920110: mov             x1, x4
    // 0x920114: r2 = Null
    //     0x920114: mov             x2, NULL
    // 0x920118: r3 = <List<Y0>?>
    //     0x920118: add             x3, PP, #0x15, lsl #12  ; [pp+0x15430] TypeArguments: <List<Y0>?>
    //     0x92011c: ldr             x3, [x3, #0x430]
    // 0x920120: r30 = InstantiateTypeArgumentsStub
    //     0x920120: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0x920124: LoadField: r30 = r30->field_7
    //     0x920124: ldur            lr, [lr, #7]
    // 0x920128: blr             lr
    // 0x92012c: mov             x1, x0
    // 0x920130: stur            x1, [fp, #-0x30]
    // 0x920134: r0 = InitAsync()
    //     0x920134: bl              #0x7f5e44  ; InitAsyncStub
    // 0x920138: r16 = <List>
    //     0x920138: ldr             x16, [PP, #0x4470]  ; [pp+0x4470] TypeArguments: <List>
    // 0x92013c: ldur            lr, [fp, #-0x28]
    // 0x920140: stp             lr, x16, [SP, #0x10]
    // 0x920144: ldur            x16, [fp, #-0x20]
    // 0x920148: ldur            lr, [fp, #-0x18]
    // 0x92014c: stp             lr, x16, [SP]
    // 0x920150: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x920150: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x920154: r0 = invokeMethod()
    //     0x920154: bl              #0x130b008  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0x920158: mov             x1, x0
    // 0x92015c: stur            x1, [fp, #-0x18]
    // 0x920160: r0 = Await()
    //     0x920160: bl              #0x7f5c00  ; AwaitStub
    // 0x920164: cmp             w0, NULL
    // 0x920168: b.ne            #0x920174
    // 0x92016c: r0 = Null
    //     0x92016c: mov             x0, NULL
    // 0x920170: b               #0x9201a0
    // 0x920174: r1 = LoadClassIdInstr(r0)
    //     0x920174: ldur            x1, [x0, #-1]
    //     0x920178: ubfx            x1, x1, #0xc, #0x14
    // 0x92017c: ldur            x16, [fp, #-0x10]
    // 0x920180: stp             x0, x16, [SP]
    // 0x920184: mov             x0, x1
    // 0x920188: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x920188: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x92018c: r0 = GDT[cid_x0 + 0x13106]()
    //     0x92018c: mov             x17, #0x3106
    //     0x920190: movk            x17, #1, lsl #16
    //     0x920194: add             lr, x0, x17
    //     0x920198: ldr             lr, [x21, lr, lsl #3]
    //     0x92019c: blr             lr
    // 0x9201a0: r0 = ReturnAsyncNotFuture()
    //     0x9201a0: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x9201a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9201a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9201a8: b               #0x920110
  }
  Future<Y0?> _invokeMethod<Y0>(MethodChannel, String, dynamic, bool) async {
    // ** addr: 0x130adf8, size: 0x210
    // 0x130adf8: EnterFrame
    //     0x130adf8: stp             fp, lr, [SP, #-0x10]!
    //     0x130adfc: mov             fp, SP
    // 0x130ae00: AllocStack(0x48)
    //     0x130ae00: sub             SP, SP, #0x48
    // 0x130ae04: SetupParameters(MethodChannel this /* r5, fp-0x30 */, dynamic _ /* r6, fp-0x28 */, dynamic _ /* r7, fp-0x20 */, dynamic _ /* r8, fp-0x18 */)
    //     0x130ae04: stur            NULL, [fp, #-8]
    //     0x130ae08: mov             x0, #0
    //     0x130ae0c: add             x5, fp, w0, sxtw #2
    //     0x130ae10: ldr             x5, [x5, #0x28]
    //     0x130ae14: stur            x5, [fp, #-0x30]
    //     0x130ae18: add             x6, fp, w0, sxtw #2
    //     0x130ae1c: ldr             x6, [x6, #0x20]
    //     0x130ae20: stur            x6, [fp, #-0x28]
    //     0x130ae24: add             x7, fp, w0, sxtw #2
    //     0x130ae28: ldr             x7, [x7, #0x18]
    //     0x130ae2c: stur            x7, [fp, #-0x20]
    //     0x130ae30: add             x8, fp, w0, sxtw #2
    //     0x130ae34: ldr             x8, [x8, #0x10]
    //     0x130ae38: stur            x8, [fp, #-0x18]
    // 0x130ae3c: LoadField: r0 = r4->field_f
    //     0x130ae3c: ldur            w0, [x4, #0xf]
    // 0x130ae40: cbnz            w0, #0x130ae4c
    // 0x130ae44: r0 = Null
    //     0x130ae44: mov             x0, NULL
    // 0x130ae48: b               #0x130ae5c
    // 0x130ae4c: ArrayLoad: r0 = r4[0]  ; List_4
    //     0x130ae4c: ldur            w0, [x4, #0x17]
    // 0x130ae50: add             x1, fp, w0, sxtw #2
    // 0x130ae54: ldr             x1, [x1, #0x10]
    // 0x130ae58: mov             x0, x1
    // 0x130ae5c: stur            x0, [fp, #-0x10]
    // 0x130ae60: CheckStackOverflow
    //     0x130ae60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x130ae64: cmp             SP, x16
    //     0x130ae68: b.ls            #0x130b000
    // 0x130ae6c: mov             x1, x0
    // 0x130ae70: r2 = Null
    //     0x130ae70: mov             x2, NULL
    // 0x130ae74: r3 = <Y0?>
    //     0x130ae74: ldr             x3, [PP, #0x1718]  ; [pp+0x1718] TypeArguments: <Y0?>
    // 0x130ae78: r0 = Null
    //     0x130ae78: mov             x0, NULL
    // 0x130ae7c: cmp             x2, x0
    // 0x130ae80: b.ne            #0x130ae8c
    // 0x130ae84: cmp             x1, x0
    // 0x130ae88: b.eq            #0x130ae98
    // 0x130ae8c: r30 = InstantiateTypeArgumentsMayShareFunctionTAStub
    //     0x130ae8c: ldr             lr, [PP, #0x1720]  ; [pp+0x1720] Stub: InstantiateTypeArgumentsMayShareFunctionTA (0x7c0cfc)
    // 0x130ae90: LoadField: r30 = r30->field_7
    //     0x130ae90: ldur            lr, [lr, #7]
    // 0x130ae94: blr             lr
    // 0x130ae98: mov             x1, x0
    // 0x130ae9c: stur            x1, [fp, #-0x38]
    // 0x130aea0: r0 = InitAsync()
    //     0x130aea0: bl              #0x7f5e44  ; InitAsyncStub
    // 0x130aea4: ldur            x1, [fp, #-0x30]
    // 0x130aea8: LoadField: r0 = r1->field_b
    //     0x130aea8: ldur            w0, [x1, #0xb]
    // 0x130aeac: DecompressPointer r0
    //     0x130aeac: add             x0, x0, HEAP, lsl #32
    // 0x130aeb0: stur            x0, [fp, #-0x38]
    // 0x130aeb4: r0 = MethodCall()
    //     0x130aeb4: bl              #0x130995c  ; AllocateMethodCallStub -> MethodCall (size=0x10)
    // 0x130aeb8: ldur            x3, [fp, #-0x28]
    // 0x130aebc: StoreField: r0->field_7 = r3
    //     0x130aebc: stur            w3, [x0, #7]
    // 0x130aec0: ldur            x1, [fp, #-0x20]
    // 0x130aec4: StoreField: r0->field_b = r1
    //     0x130aec4: stur            w1, [x0, #0xb]
    // 0x130aec8: ldur            x4, [fp, #-0x38]
    // 0x130aecc: r1 = LoadClassIdInstr(r4)
    //     0x130aecc: ldur            x1, [x4, #-1]
    //     0x130aed0: ubfx            x1, x1, #0xc, #0x14
    // 0x130aed4: mov             x2, x0
    // 0x130aed8: mov             x0, x1
    // 0x130aedc: mov             x1, x4
    // 0x130aee0: r0 = GDT[cid_x0 + -0xff0]()
    //     0x130aee0: sub             lr, x0, #0xff0
    //     0x130aee4: ldr             lr, [x21, lr, lsl #3]
    //     0x130aee8: blr             lr
    // 0x130aeec: ldur            x1, [fp, #-0x30]
    // 0x130aef0: stur            x0, [fp, #-0x20]
    // 0x130aef4: r0 = binaryMessenger()
    //     0x130aef4: bl              #0x83aac4  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::binaryMessenger
    // 0x130aef8: ldur            x0, [fp, #-0x30]
    // 0x130aefc: LoadField: r4 = r0->field_7
    //     0x130aefc: ldur            w4, [x0, #7]
    // 0x130af00: DecompressPointer r4
    //     0x130af00: add             x4, x4, HEAP, lsl #32
    // 0x130af04: mov             x2, x4
    // 0x130af08: ldur            x3, [fp, #-0x20]
    // 0x130af0c: stur            x4, [fp, #-0x40]
    // 0x130af10: r1 = Instance__DefaultBinaryMessenger
    //     0x130af10: ldr             x1, [PP, #0x848]  ; [pp+0x848] Obj!_DefaultBinaryMessenger@129c071
    // 0x130af14: r0 = send()
    //     0x130af14: bl              #0x8481f8  ; [package:flutter/src/services/binding.dart] _DefaultBinaryMessenger::send
    // 0x130af18: mov             x2, x0
    // 0x130af1c: r1 = <ByteData?>
    //     0x130af1c: ldr             x1, [PP, #0x14d0]  ; [pp+0x14d0] TypeArguments: <ByteData?>
    // 0x130af20: stur            x2, [fp, #-0x20]
    // 0x130af24: r0 = AwaitWithTypeCheck()
    //     0x130af24: bl              #0x83adf4  ; AwaitWithTypeCheckStub
    // 0x130af28: cmp             w0, NULL
    // 0x130af2c: b.ne            #0x130af40
    // 0x130af30: ldur            x0, [fp, #-0x18]
    // 0x130af34: tbnz            w0, #4, #0x130afa4
    // 0x130af38: r0 = Null
    //     0x130af38: mov             x0, NULL
    // 0x130af3c: r0 = ReturnAsyncNotFuture()
    //     0x130af3c: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x130af40: ldur            x1, [fp, #-0x38]
    // 0x130af44: r2 = LoadClassIdInstr(r1)
    //     0x130af44: ldur            x2, [x1, #-1]
    //     0x130af48: ubfx            x2, x2, #0xc, #0x14
    // 0x130af4c: mov             x16, x0
    // 0x130af50: mov             x0, x2
    // 0x130af54: mov             x2, x16
    // 0x130af58: r0 = GDT[cid_x0 + -0xffe]()
    //     0x130af58: sub             lr, x0, #0xffe
    //     0x130af5c: ldr             lr, [x21, lr, lsl #3]
    //     0x130af60: blr             lr
    // 0x130af64: ldur            x1, [fp, #-0x10]
    // 0x130af68: mov             x3, x0
    // 0x130af6c: r2 = Null
    //     0x130af6c: mov             x2, NULL
    // 0x130af70: stur            x3, [fp, #-0x10]
    // 0x130af74: cmp             w0, NULL
    // 0x130af78: b.eq            #0x130af9c
    // 0x130af7c: cmp             w1, NULL
    // 0x130af80: b.eq            #0x130af9c
    // 0x130af84: ArrayLoad: r4 = r1[0]  ; List_4
    //     0x130af84: ldur            w4, [x1, #0x17]
    // 0x130af88: DecompressPointer r4
    //     0x130af88: add             x4, x4, HEAP, lsl #32
    // 0x130af8c: r8 = Y0?
    //     0x130af8c: ldr             x8, [PP, #0x1728]  ; [pp+0x1728] TypeParameter: Y0?
    // 0x130af90: LoadField: r9 = r4->field_7
    //     0x130af90: ldur            x9, [x4, #7]
    // 0x130af94: r3 = Null
    //     0x130af94: ldr             x3, [PP, #0x1730]  ; [pp+0x1730] Null
    // 0x130af98: blr             x9
    // 0x130af9c: ldur            x0, [fp, #-0x10]
    // 0x130afa0: r0 = ReturnAsync()
    //     0x130afa0: b               #0x82fdf0  ; ReturnAsyncStub
    // 0x130afa4: ldur            x3, [fp, #-0x28]
    // 0x130afa8: ldur            x0, [fp, #-0x40]
    // 0x130afac: r1 = Null
    //     0x130afac: mov             x1, NULL
    // 0x130afb0: r2 = 8
    //     0x130afb0: mov             x2, #8
    // 0x130afb4: r0 = AllocateArray()
    //     0x130afb4: bl              #0x13df928  ; AllocateArrayStub
    // 0x130afb8: r16 = "No implementation found for method "
    //     0x130afb8: ldr             x16, [PP, #0x1740]  ; [pp+0x1740] "No implementation found for method "
    // 0x130afbc: StoreField: r0->field_f = r16
    //     0x130afbc: stur            w16, [x0, #0xf]
    // 0x130afc0: ldur            x1, [fp, #-0x28]
    // 0x130afc4: StoreField: r0->field_13 = r1
    //     0x130afc4: stur            w1, [x0, #0x13]
    // 0x130afc8: r16 = " on channel "
    //     0x130afc8: ldr             x16, [PP, #0x1748]  ; [pp+0x1748] " on channel "
    // 0x130afcc: ArrayStore: r0[0] = r16  ; List_4
    //     0x130afcc: stur            w16, [x0, #0x17]
    // 0x130afd0: ldur            x1, [fp, #-0x40]
    // 0x130afd4: StoreField: r0->field_1b = r1
    //     0x130afd4: stur            w1, [x0, #0x1b]
    // 0x130afd8: str             x0, [SP]
    // 0x130afdc: r0 = _interpolate()
    //     0x130afdc: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x130afe0: stur            x0, [fp, #-0x10]
    // 0x130afe4: r0 = MissingPluginException()
    //     0x130afe4: bl              #0x8545ec  ; AllocateMissingPluginExceptionStub -> MissingPluginException (size=0xc)
    // 0x130afe8: mov             x1, x0
    // 0x130afec: ldur            x0, [fp, #-0x10]
    // 0x130aff0: StoreField: r1->field_7 = r0
    //     0x130aff0: stur            w0, [x1, #7]
    // 0x130aff4: mov             x0, x1
    // 0x130aff8: r0 = Throw()
    //     0x130aff8: bl              #0x13ddb2c  ; ThrowStub
    // 0x130affc: brk             #0
    // 0x130b000: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x130b000: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x130b004: b               #0x130ae6c
  }
  _ invokeMethod(/* No info */) {
    // ** addr: 0x130b008, size: 0x98
    // 0x130b008: EnterFrame
    //     0x130b008: stp             fp, lr, [SP, #-0x10]!
    //     0x130b00c: mov             fp, SP
    // 0x130b010: AllocStack(0x28)
    //     0x130b010: sub             SP, SP, #0x28
    // 0x130b014: SetupParameters(MethodChannel this /* r0 */, dynamic _ /* r2 */, [dynamic _ = Null /* r1 */])
    //     0x130b014: ldur            w0, [x4, #0x13]
    //     0x130b018: sub             x1, x0, #4
    //     0x130b01c: add             x0, fp, w1, sxtw #2
    //     0x130b020: ldr             x0, [x0, #0x18]
    //     0x130b024: add             x2, fp, w1, sxtw #2
    //     0x130b028: ldr             x2, [x2, #0x10]
    //     0x130b02c: cmp             w1, #2
    //     0x130b030: b.lt            #0x130b044
    //     0x130b034: add             x3, fp, w1, sxtw #2
    //     0x130b038: ldr             x3, [x3, #8]
    //     0x130b03c: mov             x1, x3
    //     0x130b040: b               #0x130b048
    //     0x130b044: mov             x1, NULL
    //     0x130b048: ldur            w3, [x4, #0xf]
    //     0x130b04c: cbnz            w3, #0x130b058
    //     0x130b050: mov             x3, NULL
    //     0x130b054: b               #0x130b068
    //     0x130b058: ldur            w3, [x4, #0x17]
    //     0x130b05c: add             x4, fp, w3, sxtw #2
    //     0x130b060: ldr             x4, [x4, #0x10]
    //     0x130b064: mov             x3, x4
    // 0x130b068: CheckStackOverflow
    //     0x130b068: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x130b06c: cmp             SP, x16
    //     0x130b070: b.ls            #0x130b098
    // 0x130b074: stp             x0, x3, [SP, #0x18]
    // 0x130b078: stp             x1, x2, [SP, #8]
    // 0x130b07c: r16 = false
    //     0x130b07c: add             x16, NULL, #0x30  ; false
    // 0x130b080: str             x16, [SP]
    // 0x130b084: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0x130b084: ldr             x4, [PP, #0x560]  ; [pp+0x560] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0x130b088: r0 = _invokeMethod()
    //     0x130b088: bl              #0x130adf8  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::_invokeMethod
    // 0x130b08c: LeaveFrame
    //     0x130b08c: mov             SP, fp
    //     0x130b090: ldp             fp, lr, [SP], #0x10
    // 0x130b094: ret
    //     0x130b094: ret             
    // 0x130b098: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x130b098: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x130b09c: b               #0x130b074
  }
}

// class id: 2775, size: 0x14, field offset: 0x14
//   const constructor, 
class OptionalMethodChannel extends MethodChannel {

  _OneByteString field_8;
  JSONMethodCodec field_c;

  Future<Y0?> invokeMethod<Y0>(OptionalMethodChannel, String, [dynamic]) async {
    // ** addr: 0x130ad0c, size: 0xec
    // 0x130ad0c: EnterFrame
    //     0x130ad0c: stp             fp, lr, [SP, #-0x10]!
    //     0x130ad10: mov             fp, SP
    // 0x130ad14: AllocStack(0x58)
    //     0x130ad14: sub             SP, SP, #0x58
    // 0x130ad18: SetupParameters(OptionalMethodChannel this /* r0, fp-0x28 */, dynamic _ /* r5, fp-0x20 */, [dynamic _ = Null /* r6, fp-0x18 */])
    //     0x130ad18: stur            NULL, [fp, #-8]
    //     0x130ad1c: ldur            w0, [x4, #0x13]
    //     0x130ad20: sub             x1, x0, #4
    //     0x130ad24: add             x0, fp, w1, sxtw #2
    //     0x130ad28: ldr             x0, [x0, #0x18]
    //     0x130ad2c: stur            x0, [fp, #-0x28]
    //     0x130ad30: add             x5, fp, w1, sxtw #2
    //     0x130ad34: ldr             x5, [x5, #0x10]
    //     0x130ad38: stur            x5, [fp, #-0x20]
    //     0x130ad3c: cmp             w1, #2
    //     0x130ad40: b.lt            #0x130ad54
    //     0x130ad44: add             x2, fp, w1, sxtw #2
    //     0x130ad48: ldr             x2, [x2, #8]
    //     0x130ad4c: mov             x6, x2
    //     0x130ad50: b               #0x130ad58
    //     0x130ad54: mov             x6, NULL
    //     0x130ad58: stur            x6, [fp, #-0x18]
    //     0x130ad5c: ldur            w1, [x4, #0xf]
    //     0x130ad60: cbnz            w1, #0x130ad6c
    //     0x130ad64: mov             x4, NULL
    //     0x130ad68: b               #0x130ad7c
    //     0x130ad6c: ldur            w1, [x4, #0x17]
    //     0x130ad70: add             x2, fp, w1, sxtw #2
    //     0x130ad74: ldr             x2, [x2, #0x10]
    //     0x130ad78: mov             x4, x2
    //     0x130ad7c: stur            x4, [fp, #-0x10]
    // 0x130ad80: CheckStackOverflow
    //     0x130ad80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x130ad84: cmp             SP, x16
    //     0x130ad88: b.ls            #0x130adf0
    // 0x130ad8c: mov             x1, x4
    // 0x130ad90: r2 = Null
    //     0x130ad90: mov             x2, NULL
    // 0x130ad94: r3 = <Y0?>
    //     0x130ad94: ldr             x3, [PP, #0x1970]  ; [pp+0x1970] TypeArguments: <Y0?>
    // 0x130ad98: r0 = Null
    //     0x130ad98: mov             x0, NULL
    // 0x130ad9c: cmp             x2, x0
    // 0x130ada0: b.ne            #0x130adac
    // 0x130ada4: cmp             x1, x0
    // 0x130ada8: b.eq            #0x130adb8
    // 0x130adac: r30 = InstantiateTypeArgumentsMayShareFunctionTAStub
    //     0x130adac: ldr             lr, [PP, #0x1720]  ; [pp+0x1720] Stub: InstantiateTypeArgumentsMayShareFunctionTA (0x7c0cfc)
    // 0x130adb0: LoadField: r30 = r30->field_7
    //     0x130adb0: ldur            lr, [lr, #7]
    // 0x130adb4: blr             lr
    // 0x130adb8: mov             x1, x0
    // 0x130adbc: stur            x1, [fp, #-0x30]
    // 0x130adc0: r0 = InitAsync()
    //     0x130adc0: bl              #0x7f5e44  ; InitAsyncStub
    // 0x130adc4: ldur            x16, [fp, #-0x10]
    // 0x130adc8: ldur            lr, [fp, #-0x28]
    // 0x130adcc: stp             lr, x16, [SP, #0x18]
    // 0x130add0: ldur            x16, [fp, #-0x20]
    // 0x130add4: ldur            lr, [fp, #-0x18]
    // 0x130add8: stp             lr, x16, [SP, #8]
    // 0x130addc: r16 = true
    //     0x130addc: add             x16, NULL, #0x20  ; true
    // 0x130ade0: str             x16, [SP]
    // 0x130ade4: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0x130ade4: ldr             x4, [PP, #0x560]  ; [pp+0x560] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0x130ade8: r0 = _invokeMethod()
    //     0x130ade8: bl              #0x130adf8  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::_invokeMethod
    // 0x130adec: r0 = ReturnAsync()
    //     0x130adec: b               #0x82fdf0  ; ReturnAsyncStub
    // 0x130adf0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x130adf0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x130adf4: b               #0x130ad8c
  }
}

// class id: 2776, size: 0x18, field offset: 0x8
//   const constructor, 
class BasicMessageChannel<X0> extends Object {

  _OneByteString field_c;
  JSONMessageCodec field_10;

  _ setMessageHandler(/* No info */) {
    // ** addr: 0x84657c, size: 0xf4
    // 0x84657c: EnterFrame
    //     0x84657c: stp             fp, lr, [SP, #-0x10]!
    //     0x846580: mov             fp, SP
    // 0x846584: AllocStack(0x18)
    //     0x846584: sub             SP, SP, #0x18
    // 0x846588: SetupParameters(BasicMessageChannel<X0> this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x846588: mov             x0, x2
    //     0x84658c: stur            x1, [fp, #-8]
    //     0x846590: stur            x2, [fp, #-0x10]
    // 0x846594: CheckStackOverflow
    //     0x846594: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x846598: cmp             SP, x16
    //     0x84659c: b.ls            #0x846668
    // 0x8465a0: r1 = 2
    //     0x8465a0: mov             x1, #2
    // 0x8465a4: r0 = AllocateContext()
    //     0x8465a4: bl              #0x13de838  ; AllocateContextStub
    // 0x8465a8: mov             x4, x0
    // 0x8465ac: ldur            x3, [fp, #-8]
    // 0x8465b0: stur            x4, [fp, #-0x18]
    // 0x8465b4: StoreField: r4->field_f = r3
    //     0x8465b4: stur            w3, [x4, #0xf]
    // 0x8465b8: ldur            x5, [fp, #-0x10]
    // 0x8465bc: StoreField: r4->field_13 = r5
    //     0x8465bc: stur            w5, [x4, #0x13]
    // 0x8465c0: LoadField: r2 = r3->field_7
    //     0x8465c0: ldur            w2, [x3, #7]
    // 0x8465c4: DecompressPointer r2
    //     0x8465c4: add             x2, x2, HEAP, lsl #32
    // 0x8465c8: mov             x0, x5
    // 0x8465cc: r1 = Null
    //     0x8465cc: mov             x1, NULL
    // 0x8465d0: r8 = ((dynamic this, X0?) => Future<X0>)?
    //     0x8465d0: ldr             x8, [PP, #0x3530]  ; [pp+0x3530] FunctionType: ((dynamic this, X0?) => Future<X0>)?
    // 0x8465d4: LoadField: r9 = r8->field_7
    //     0x8465d4: ldur            x9, [x8, #7]
    // 0x8465d8: r3 = Null
    //     0x8465d8: ldr             x3, [PP, #0x3538]  ; [pp+0x3538] Null
    // 0x8465dc: blr             x9
    // 0x8465e0: ldur            x0, [fp, #-0x10]
    // 0x8465e4: cmp             w0, NULL
    // 0x8465e8: b.ne            #0x846620
    // 0x8465ec: ldur            x1, [fp, #-8]
    // 0x8465f0: LoadField: r0 = r1->field_13
    //     0x8465f0: ldur            w0, [x1, #0x13]
    // 0x8465f4: DecompressPointer r0
    //     0x8465f4: add             x0, x0, HEAP, lsl #32
    // 0x8465f8: cmp             w0, NULL
    // 0x8465fc: b.ne            #0x846604
    // 0x846600: r0 = _findBinaryMessenger()
    //     0x846600: bl              #0x83af88  ; [package:flutter/src/services/platform_channel.dart] ::_findBinaryMessenger
    // 0x846604: ldur            x0, [fp, #-8]
    // 0x846608: LoadField: r2 = r0->field_b
    //     0x846608: ldur            w2, [x0, #0xb]
    // 0x84660c: DecompressPointer r2
    //     0x84660c: add             x2, x2, HEAP, lsl #32
    // 0x846610: r1 = Instance__DefaultBinaryMessenger
    //     0x846610: ldr             x1, [PP, #0x848]  ; [pp+0x848] Obj!_DefaultBinaryMessenger@129c071
    // 0x846614: r3 = Null
    //     0x846614: mov             x3, NULL
    // 0x846618: r0 = setMessageHandler()
    //     0x846618: bl              #0x83aaf4  ; [package:flutter/src/services/binding.dart] _DefaultBinaryMessenger::setMessageHandler
    // 0x84661c: b               #0x846658
    // 0x846620: ldur            x0, [fp, #-8]
    // 0x846624: mov             x1, x0
    // 0x846628: r0 = binaryMessenger()
    //     0x846628: bl              #0x846670  ; [package:flutter/src/services/platform_channel.dart] BasicMessageChannel::binaryMessenger
    // 0x84662c: ldur            x0, [fp, #-8]
    // 0x846630: LoadField: r3 = r0->field_b
    //     0x846630: ldur            w3, [x0, #0xb]
    // 0x846634: DecompressPointer r3
    //     0x846634: add             x3, x3, HEAP, lsl #32
    // 0x846638: ldur            x2, [fp, #-0x18]
    // 0x84663c: stur            x3, [fp, #-0x10]
    // 0x846640: r1 = Function '<anonymous closure>':.
    //     0x846640: ldr             x1, [PP, #0x3548]  ; [pp+0x3548] AnonymousClosure: (0x8466b0), in [package:flutter/src/services/platform_channel.dart] BasicMessageChannel::setMessageHandler (0x84657c)
    // 0x846644: r0 = AllocateClosure()
    //     0x846644: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x846648: ldur            x2, [fp, #-0x10]
    // 0x84664c: mov             x3, x0
    // 0x846650: r1 = Instance__DefaultBinaryMessenger
    //     0x846650: ldr             x1, [PP, #0x848]  ; [pp+0x848] Obj!_DefaultBinaryMessenger@129c071
    // 0x846654: r0 = setMessageHandler()
    //     0x846654: bl              #0x83aaf4  ; [package:flutter/src/services/binding.dart] _DefaultBinaryMessenger::setMessageHandler
    // 0x846658: r0 = Null
    //     0x846658: mov             x0, NULL
    // 0x84665c: LeaveFrame
    //     0x84665c: mov             SP, fp
    //     0x846660: ldp             fp, lr, [SP], #0x10
    // 0x846664: ret
    //     0x846664: ret             
    // 0x846668: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x846668: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84666c: b               #0x8465a0
  }
  get _ binaryMessenger(/* No info */) {
    // ** addr: 0x846670, size: 0x40
    // 0x846670: EnterFrame
    //     0x846670: stp             fp, lr, [SP, #-0x10]!
    //     0x846674: mov             fp, SP
    // 0x846678: CheckStackOverflow
    //     0x846678: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84667c: cmp             SP, x16
    //     0x846680: b.ls            #0x8466a8
    // 0x846684: LoadField: r0 = r1->field_13
    //     0x846684: ldur            w0, [x1, #0x13]
    // 0x846688: DecompressPointer r0
    //     0x846688: add             x0, x0, HEAP, lsl #32
    // 0x84668c: cmp             w0, NULL
    // 0x846690: b.ne            #0x84669c
    // 0x846694: r0 = _findBinaryMessenger()
    //     0x846694: bl              #0x83af88  ; [package:flutter/src/services/platform_channel.dart] ::_findBinaryMessenger
    // 0x846698: r0 = Instance__DefaultBinaryMessenger
    //     0x846698: ldr             x0, [PP, #0x848]  ; [pp+0x848] Obj!_DefaultBinaryMessenger@129c071
    // 0x84669c: LeaveFrame
    //     0x84669c: mov             SP, fp
    //     0x8466a0: ldp             fp, lr, [SP], #0x10
    // 0x8466a4: ret
    //     0x8466a4: ret             
    // 0x8466a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8466a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8466ac: b               #0x846684
  }
  [closure] Future<ByteData?> <anonymous closure>(dynamic, ByteData?) async {
    // ** addr: 0x8466b0, size: 0xf0
    // 0x8466b0: EnterFrame
    //     0x8466b0: stp             fp, lr, [SP, #-0x10]!
    //     0x8466b4: mov             fp, SP
    // 0x8466b8: AllocStack(0x38)
    //     0x8466b8: sub             SP, SP, #0x38
    // 0x8466bc: SetupParameters(BasicMessageChannel<X0> this /* r1 */, dynamic _ /* r2, fp-0x18 */)
    //     0x8466bc: stur            NULL, [fp, #-8]
    //     0x8466c0: mov             x0, #0
    //     0x8466c4: add             x1, fp, w0, sxtw #2
    //     0x8466c8: ldr             x1, [x1, #0x18]
    //     0x8466cc: add             x2, fp, w0, sxtw #2
    //     0x8466d0: ldr             x2, [x2, #0x10]
    //     0x8466d4: stur            x2, [fp, #-0x18]
    //     0x8466d8: ldur            w3, [x1, #0x17]
    //     0x8466dc: add             x3, x3, HEAP, lsl #32
    //     0x8466e0: stur            x3, [fp, #-0x10]
    // 0x8466e4: CheckStackOverflow
    //     0x8466e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8466e8: cmp             SP, x16
    //     0x8466ec: b.ls            #0x846794
    // 0x8466f0: InitAsync() -> Future<ByteData?>
    //     0x8466f0: ldr             x0, [PP, #0x14d0]  ; [pp+0x14d0] TypeArguments: <ByteData?>
    //     0x8466f4: bl              #0x7f5e44  ; InitAsyncStub
    // 0x8466f8: ldur            x3, [fp, #-0x10]
    // 0x8466fc: LoadField: r0 = r3->field_f
    //     0x8466fc: ldur            w0, [x3, #0xf]
    // 0x846700: DecompressPointer r0
    //     0x846700: add             x0, x0, HEAP, lsl #32
    // 0x846704: LoadField: r4 = r0->field_f
    //     0x846704: ldur            w4, [x0, #0xf]
    // 0x846708: DecompressPointer r4
    //     0x846708: add             x4, x4, HEAP, lsl #32
    // 0x84670c: stur            x4, [fp, #-0x28]
    // 0x846710: LoadField: r5 = r3->field_13
    //     0x846710: ldur            w5, [x3, #0x13]
    // 0x846714: DecompressPointer r5
    //     0x846714: add             x5, x5, HEAP, lsl #32
    // 0x846718: stur            x5, [fp, #-0x20]
    // 0x84671c: r0 = LoadClassIdInstr(r4)
    //     0x84671c: ldur            x0, [x4, #-1]
    //     0x846720: ubfx            x0, x0, #0xc, #0x14
    // 0x846724: mov             x1, x4
    // 0x846728: ldur            x2, [fp, #-0x18]
    // 0x84672c: r0 = GDT[cid_x0 + 0xee99]()
    //     0x84672c: mov             x17, #0xee99
    //     0x846730: add             lr, x0, x17
    //     0x846734: ldr             lr, [x21, lr, lsl #3]
    //     0x846738: blr             lr
    // 0x84673c: mov             x1, x0
    // 0x846740: ldur            x0, [fp, #-0x20]
    // 0x846744: cmp             w0, NULL
    // 0x846748: b.eq            #0x84679c
    // 0x84674c: stp             x1, x0, [SP]
    // 0x846750: ClosureCall
    //     0x846750: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x846754: ldur            x2, [x0, #0x1f]
    //     0x846758: blr             x2
    // 0x84675c: mov             x1, x0
    // 0x846760: stur            x1, [fp, #-0x18]
    // 0x846764: r0 = Await()
    //     0x846764: bl              #0x7f5c00  ; AwaitStub
    // 0x846768: ldur            x1, [fp, #-0x28]
    // 0x84676c: r2 = LoadClassIdInstr(r1)
    //     0x84676c: ldur            x2, [x1, #-1]
    //     0x846770: ubfx            x2, x2, #0xc, #0x14
    // 0x846774: mov             x16, x0
    // 0x846778: mov             x0, x2
    // 0x84677c: mov             x2, x16
    // 0x846780: r0 = GDT[cid_x0 + 0xe3bd]()
    //     0x846780: mov             x17, #0xe3bd
    //     0x846784: add             lr, x0, x17
    //     0x846788: ldr             lr, [x21, lr, lsl #3]
    //     0x84678c: blr             lr
    // 0x846790: r0 = ReturnAsyncNotFuture()
    //     0x846790: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x846794: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x846794: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x846798: b               #0x8466f0
    // 0x84679c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x84679c: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ send(/* No info */) async {
    // ** addr: 0x8bf9c0, size: 0x144
    // 0x8bf9c0: EnterFrame
    //     0x8bf9c0: stp             fp, lr, [SP, #-0x10]!
    //     0x8bf9c4: mov             fp, SP
    // 0x8bf9c8: AllocStack(0x28)
    //     0x8bf9c8: sub             SP, SP, #0x28
    // 0x8bf9cc: SetupParameters(BasicMessageChannel<X0> this /* r1 => r4, fp-0x18 */, dynamic _ /* r2 => r3, fp-0x20 */)
    //     0x8bf9cc: stur            NULL, [fp, #-8]
    //     0x8bf9d0: mov             x4, x1
    //     0x8bf9d4: mov             x3, x2
    //     0x8bf9d8: stur            x1, [fp, #-0x18]
    //     0x8bf9dc: stur            x2, [fp, #-0x20]
    // 0x8bf9e0: CheckStackOverflow
    //     0x8bf9e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8bf9e4: cmp             SP, x16
    //     0x8bf9e8: b.ls            #0x8bfafc
    // 0x8bf9ec: LoadField: r5 = r4->field_7
    //     0x8bf9ec: ldur            w5, [x4, #7]
    // 0x8bf9f0: DecompressPointer r5
    //     0x8bf9f0: add             x5, x5, HEAP, lsl #32
    // 0x8bf9f4: mov             x0, x3
    // 0x8bf9f8: mov             x2, x5
    // 0x8bf9fc: stur            x5, [fp, #-0x10]
    // 0x8bfa00: r1 = Null
    //     0x8bfa00: mov             x1, NULL
    // 0x8bfa04: cmp             w2, NULL
    // 0x8bfa08: b.eq            #0x8bfa28
    // 0x8bfa0c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x8bfa0c: ldur            w4, [x2, #0x17]
    // 0x8bfa10: DecompressPointer r4
    //     0x8bfa10: add             x4, x4, HEAP, lsl #32
    // 0x8bfa14: r8 = X0
    //     0x8bfa14: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x8bfa18: LoadField: r9 = r4->field_7
    //     0x8bfa18: ldur            x9, [x4, #7]
    // 0x8bfa1c: r3 = Null
    //     0x8bfa1c: add             x3, PP, #8, lsl #12  ; [pp+0x8d88] Null
    //     0x8bfa20: ldr             x3, [x3, #0xd88]
    // 0x8bfa24: blr             x9
    // 0x8bfa28: ldur            x2, [fp, #-0x10]
    // 0x8bfa2c: r1 = Null
    //     0x8bfa2c: mov             x1, NULL
    // 0x8bfa30: r3 = <X0?>
    //     0x8bfa30: ldr             x3, [PP, #0xbf8]  ; [pp+0xbf8] TypeArguments: <X0?>
    // 0x8bfa34: r0 = Null
    //     0x8bfa34: mov             x0, NULL
    // 0x8bfa38: cmp             x2, x0
    // 0x8bfa3c: b.eq            #0x8bfa4c
    // 0x8bfa40: r30 = InstantiateTypeArgumentsMayShareInstantiatorTAStub
    //     0x8bfa40: ldr             lr, [PP, #0xc00]  ; [pp+0xc00] Stub: InstantiateTypeArgumentsMayShareInstantiatorTA (0x7c0e60)
    // 0x8bfa44: LoadField: r30 = r30->field_7
    //     0x8bfa44: ldur            lr, [lr, #7]
    // 0x8bfa48: blr             lr
    // 0x8bfa4c: mov             x1, x0
    // 0x8bfa50: stur            x1, [fp, #-0x10]
    // 0x8bfa54: r0 = InitAsync()
    //     0x8bfa54: bl              #0x7f5e44  ; InitAsyncStub
    // 0x8bfa58: ldur            x0, [fp, #-0x18]
    // 0x8bfa5c: LoadField: r1 = r0->field_f
    //     0x8bfa5c: ldur            w1, [x0, #0xf]
    // 0x8bfa60: DecompressPointer r1
    //     0x8bfa60: add             x1, x1, HEAP, lsl #32
    // 0x8bfa64: stur            x1, [fp, #-0x10]
    // 0x8bfa68: LoadField: r2 = r0->field_13
    //     0x8bfa68: ldur            w2, [x0, #0x13]
    // 0x8bfa6c: DecompressPointer r2
    //     0x8bfa6c: add             x2, x2, HEAP, lsl #32
    // 0x8bfa70: cmp             w2, NULL
    // 0x8bfa74: b.ne            #0x8bfa7c
    // 0x8bfa78: r0 = _findBinaryMessenger()
    //     0x8bfa78: bl              #0x83af88  ; [package:flutter/src/services/platform_channel.dart] ::_findBinaryMessenger
    // 0x8bfa7c: ldur            x0, [fp, #-0x18]
    // 0x8bfa80: ldur            x3, [fp, #-0x10]
    // 0x8bfa84: LoadField: r4 = r0->field_b
    //     0x8bfa84: ldur            w4, [x0, #0xb]
    // 0x8bfa88: DecompressPointer r4
    //     0x8bfa88: add             x4, x4, HEAP, lsl #32
    // 0x8bfa8c: stur            x4, [fp, #-0x28]
    // 0x8bfa90: r0 = LoadClassIdInstr(r3)
    //     0x8bfa90: ldur            x0, [x3, #-1]
    //     0x8bfa94: ubfx            x0, x0, #0xc, #0x14
    // 0x8bfa98: mov             x1, x3
    // 0x8bfa9c: ldur            x2, [fp, #-0x20]
    // 0x8bfaa0: r0 = GDT[cid_x0 + 0xe3bd]()
    //     0x8bfaa0: mov             x17, #0xe3bd
    //     0x8bfaa4: add             lr, x0, x17
    //     0x8bfaa8: ldr             lr, [x21, lr, lsl #3]
    //     0x8bfaac: blr             lr
    // 0x8bfab0: ldur            x2, [fp, #-0x28]
    // 0x8bfab4: mov             x3, x0
    // 0x8bfab8: r1 = Instance__DefaultBinaryMessenger
    //     0x8bfab8: ldr             x1, [PP, #0x848]  ; [pp+0x848] Obj!_DefaultBinaryMessenger@129c071
    // 0x8bfabc: r0 = send()
    //     0x8bfabc: bl              #0x8481f8  ; [package:flutter/src/services/binding.dart] _DefaultBinaryMessenger::send
    // 0x8bfac0: mov             x2, x0
    // 0x8bfac4: r1 = <ByteData?>
    //     0x8bfac4: ldr             x1, [PP, #0x14d0]  ; [pp+0x14d0] TypeArguments: <ByteData?>
    // 0x8bfac8: stur            x2, [fp, #-0x18]
    // 0x8bfacc: r0 = AwaitWithTypeCheck()
    //     0x8bfacc: bl              #0x83adf4  ; AwaitWithTypeCheckStub
    // 0x8bfad0: ldur            x1, [fp, #-0x10]
    // 0x8bfad4: r2 = LoadClassIdInstr(r1)
    //     0x8bfad4: ldur            x2, [x1, #-1]
    //     0x8bfad8: ubfx            x2, x2, #0xc, #0x14
    // 0x8bfadc: mov             x16, x0
    // 0x8bfae0: mov             x0, x2
    // 0x8bfae4: mov             x2, x16
    // 0x8bfae8: r0 = GDT[cid_x0 + 0xee99]()
    //     0x8bfae8: mov             x17, #0xee99
    //     0x8bfaec: add             lr, x0, x17
    //     0x8bfaf0: ldr             lr, [x21, lr, lsl #3]
    //     0x8bfaf4: blr             lr
    // 0x8bfaf8: r0 = ReturnAsync()
    //     0x8bfaf8: b               #0x82fdf0  ; ReturnAsyncStub
    // 0x8bfafc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8bfafc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8bfb00: b               #0x8bf9ec
  }
}
