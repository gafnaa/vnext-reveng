// lib: , url: package:flutter/src/services/asset_bundle.dart

// class id: 1049066, size: 0x8
class :: {

  static late final AssetBundle rootBundle; // offset: 0x824

  static _ _errorSummaryWithKey(/* No info */) {
    // ** addr: 0x8488e8, size: 0x84
    // 0x8488e8: EnterFrame
    //     0x8488e8: stp             fp, lr, [SP, #-0x10]!
    //     0x8488ec: mov             fp, SP
    // 0x8488f0: AllocStack(0x10)
    //     0x8488f0: sub             SP, SP, #0x10
    // 0x8488f4: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */)
    //     0x8488f4: mov             x0, x1
    //     0x8488f8: stur            x1, [fp, #-8]
    // 0x8488fc: CheckStackOverflow
    //     0x8488fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x848900: cmp             SP, x16
    //     0x848904: b.ls            #0x848964
    // 0x848908: r1 = Null
    //     0x848908: mov             x1, NULL
    // 0x84890c: r2 = 6
    //     0x84890c: mov             x2, #6
    // 0x848910: r0 = AllocateArray()
    //     0x848910: bl              #0x13df928  ; AllocateArrayStub
    // 0x848914: r16 = "Unable to load asset: \""
    //     0x848914: ldr             x16, [PP, #0x39a0]  ; [pp+0x39a0] "Unable to load asset: \""
    // 0x848918: StoreField: r0->field_f = r16
    //     0x848918: stur            w16, [x0, #0xf]
    // 0x84891c: ldur            x1, [fp, #-8]
    // 0x848920: StoreField: r0->field_13 = r1
    //     0x848920: stur            w1, [x0, #0x13]
    // 0x848924: r16 = "\"."
    //     0x848924: ldr             x16, [PP, #0x39a8]  ; [pp+0x39a8] "\"."
    // 0x848928: ArrayStore: r0[0] = r16  ; List_4
    //     0x848928: stur            w16, [x0, #0x17]
    // 0x84892c: str             x0, [SP]
    // 0x848930: r0 = _interpolate()
    //     0x848930: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x848934: r1 = <List<Object>>
    //     0x848934: ldr             x1, [PP, #0x860]  ; [pp+0x860] TypeArguments: <List<Object>>
    // 0x848938: stur            x0, [fp, #-8]
    // 0x84893c: r0 = ErrorSummary()
    //     0x84893c: bl              #0x84896c  ; AllocateErrorSummaryStub -> ErrorSummary (size=0x2c)
    // 0x848940: mov             x1, x0
    // 0x848944: ldur            x2, [fp, #-8]
    // 0x848948: r3 = Instance_DiagnosticLevel
    //     0x848948: ldr             x3, [PP, #0x22b0]  ; [pp+0x22b0] Obj!DiagnosticLevel@12c5f61
    // 0x84894c: stur            x0, [fp, #-8]
    // 0x848950: r0 = _ErrorDiagnostic()
    //     0x848950: bl              #0x829bec  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0x848954: ldur            x0, [fp, #-8]
    // 0x848958: LeaveFrame
    //     0x848958: mov             SP, fp
    //     0x84895c: ldp             fp, lr, [SP], #0x10
    // 0x848960: ret
    //     0x848960: ret             
    // 0x848964: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x848964: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x848968: b               #0x848908
  }
  static AssetBundle rootBundle() {
    // ** addr: 0x848d2c, size: 0x2c
    // 0x848d2c: EnterFrame
    //     0x848d2c: stp             fp, lr, [SP, #-0x10]!
    //     0x848d30: mov             fp, SP
    // 0x848d34: CheckStackOverflow
    //     0x848d34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x848d38: cmp             SP, x16
    //     0x848d3c: b.ls            #0x848d50
    // 0x848d40: r0 = _initRootBundle()
    //     0x848d40: bl              #0x848d58  ; [package:flutter/src/services/asset_bundle.dart] ::_initRootBundle
    // 0x848d44: LeaveFrame
    //     0x848d44: mov             SP, fp
    //     0x848d48: ldp             fp, lr, [SP], #0x10
    // 0x848d4c: ret
    //     0x848d4c: ret             
    // 0x848d50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x848d50: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x848d54: b               #0x848d40
  }
  static AssetBundle _initRootBundle() {
    // ** addr: 0x848d58, size: 0x40
    // 0x848d58: EnterFrame
    //     0x848d58: stp             fp, lr, [SP, #-0x10]!
    //     0x848d5c: mov             fp, SP
    // 0x848d60: AllocStack(0x8)
    //     0x848d60: sub             SP, SP, #8
    // 0x848d64: CheckStackOverflow
    //     0x848d64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x848d68: cmp             SP, x16
    //     0x848d6c: b.ls            #0x848d90
    // 0x848d70: r0 = PlatformAssetBundle()
    //     0x848d70: bl              #0x848ef4  ; AllocatePlatformAssetBundleStub -> PlatformAssetBundle (size=0x14)
    // 0x848d74: mov             x1, x0
    // 0x848d78: stur            x0, [fp, #-8]
    // 0x848d7c: r0 = CachingAssetBundle()
    //     0x848d7c: bl              #0x848d98  ; [package:flutter/src/services/asset_bundle.dart] CachingAssetBundle::CachingAssetBundle
    // 0x848d80: ldur            x0, [fp, #-8]
    // 0x848d84: LeaveFrame
    //     0x848d84: mov             SP, fp
    //     0x848d88: ldp             fp, lr, [SP], #0x10
    // 0x848d8c: ret
    //     0x848d8c: ret             
    // 0x848d90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x848d90: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x848d94: b               #0x848d70
  }
}

// class id: 2808, size: 0x8, field offset: 0x8
abstract class AssetBundle extends Object {

  _ loadString(/* No info */) async {
    // ** addr: 0xf8a180, size: 0xe8
    // 0xf8a180: EnterFrame
    //     0xf8a180: stp             fp, lr, [SP, #-0x10]!
    //     0xf8a184: mov             fp, SP
    // 0xf8a188: AllocStack(0x38)
    //     0xf8a188: sub             SP, SP, #0x38
    // 0xf8a18c: SetupParameters(AssetBundle this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0xf8a18c: stur            NULL, [fp, #-8]
    //     0xf8a190: stur            x1, [fp, #-0x10]
    //     0xf8a194: stur            x2, [fp, #-0x18]
    // 0xf8a198: CheckStackOverflow
    //     0xf8a198: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf8a19c: cmp             SP, x16
    //     0xf8a1a0: b.ls            #0xf8a260
    // 0xf8a1a4: InitAsync() -> Future<String>
    //     0xf8a1a4: ldr             x0, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    //     0xf8a1a8: bl              #0x7f5e44  ; InitAsyncStub
    // 0xf8a1ac: ldur            x1, [fp, #-0x10]
    // 0xf8a1b0: ldur            x2, [fp, #-0x18]
    // 0xf8a1b4: r0 = load()
    //     0xf8a1b4: bl              #0x84810c  ; [package:flutter/src/services/asset_bundle.dart] PlatformAssetBundle::load
    // 0xf8a1b8: mov             x1, x0
    // 0xf8a1bc: stur            x1, [fp, #-0x10]
    // 0xf8a1c0: r0 = Await()
    //     0xf8a1c0: bl              #0x7f5c00  ; AwaitStub
    // 0xf8a1c4: stur            x0, [fp, #-0x10]
    // 0xf8a1c8: LoadField: r1 = r0->field_13
    //     0xf8a1c8: ldur            w1, [x0, #0x13]
    // 0xf8a1cc: r2 = LoadInt32Instr(r1)
    //     0xf8a1cc: sbfx            x2, x1, #1, #0x1f
    // 0xf8a1d0: r17 = 51200
    //     0xf8a1d0: mov             x17, #0xc800
    // 0xf8a1d4: cmp             x2, x17
    // 0xf8a1d8: b.ge            #0xf8a200
    // 0xf8a1dc: mov             x2, x0
    // 0xf8a1e0: r1 = Null
    //     0xf8a1e0: mov             x1, NULL
    // 0xf8a1e4: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xf8a1e4: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xf8a1e8: r0 = Uint8List.sublistView()
    //     0xf8a1e8: bl              #0xccff20  ; [dart:typed_data] Uint8List::Uint8List.sublistView
    // 0xf8a1ec: mov             x2, x0
    // 0xf8a1f0: r1 = Instance_Utf8Codec
    //     0xf8a1f0: ldr             x1, [PP, #0x11e0]  ; [pp+0x11e0] Obj!Utf8Codec@12b7e61
    // 0xf8a1f4: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xf8a1f4: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xf8a1f8: r0 = decode()
    //     0xf8a1f8: bl              #0x121a094  ; [dart:convert] Utf8Codec::decode
    // 0xf8a1fc: r0 = ReturnAsyncNotFuture()
    //     0xf8a1fc: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xf8a200: ldur            x3, [fp, #-0x18]
    // 0xf8a204: r1 = Null
    //     0xf8a204: mov             x1, NULL
    // 0xf8a208: r2 = 6
    //     0xf8a208: mov             x2, #6
    // 0xf8a20c: r0 = AllocateArray()
    //     0xf8a20c: bl              #0x13df928  ; AllocateArrayStub
    // 0xf8a210: r16 = "UTF8 decode for \""
    //     0xf8a210: add             x16, PP, #0x28, lsl #12  ; [pp+0x28958] "UTF8 decode for \""
    //     0xf8a214: ldr             x16, [x16, #0x958]
    // 0xf8a218: StoreField: r0->field_f = r16
    //     0xf8a218: stur            w16, [x0, #0xf]
    // 0xf8a21c: ldur            x1, [fp, #-0x18]
    // 0xf8a220: StoreField: r0->field_13 = r1
    //     0xf8a220: stur            w1, [x0, #0x13]
    // 0xf8a224: r16 = "\""
    //     0xf8a224: add             x16, PP, #8, lsl #12  ; [pp+0x84a0] "\""
    //     0xf8a228: ldr             x16, [x16, #0x4a0]
    // 0xf8a22c: ArrayStore: r0[0] = r16  ; List_4
    //     0xf8a22c: stur            w16, [x0, #0x17]
    // 0xf8a230: str             x0, [SP]
    // 0xf8a234: r0 = _interpolate()
    //     0xf8a234: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xf8a238: r16 = <ByteData, String>
    //     0xf8a238: add             x16, PP, #0x28, lsl #12  ; [pp+0x28960] TypeArguments: <ByteData, String>
    //     0xf8a23c: ldr             x16, [x16, #0x960]
    // 0xf8a240: r30 = Closure: (ByteData) => String from Function '_utf8decode@169177032': static.
    //     0xf8a240: add             lr, PP, #0x28, lsl #12  ; [pp+0x28968] Closure: (ByteData) => String from Function '_utf8decode@169177032': static. (0x7f2adae71268)
    //     0xf8a244: ldr             lr, [lr, #0x968]
    // 0xf8a248: stp             lr, x16, [SP, #0x10]
    // 0xf8a24c: ldur            x16, [fp, #-0x10]
    // 0xf8a250: stp             x0, x16, [SP]
    // 0xf8a254: r4 = const [0x2, 0x3, 0x3, 0x2, debugLabel, 0x2, null]
    //     0xf8a254: ldr             x4, [PP, #0x35b0]  ; [pp+0x35b0] List(7) [0x2, 0x3, 0x3, 0x2, "debugLabel", 0x2, Null]
    // 0xf8a258: r0 = compute()
    //     0xf8a258: bl              #0x846c30  ; [package:flutter/src/foundation/isolates.dart] ::compute
    // 0xf8a25c: r0 = ReturnAsync()
    //     0xf8a25c: b               #0x82fdf0  ; ReturnAsyncStub
    // 0xf8a260: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf8a260: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf8a264: b               #0xf8a1a4
  }
  [closure] static String _utf8decode(dynamic, ByteData) {
    // ** addr: 0xf8a268, size: 0x30
    // 0xf8a268: EnterFrame
    //     0xf8a268: stp             fp, lr, [SP, #-0x10]!
    //     0xf8a26c: mov             fp, SP
    // 0xf8a270: CheckStackOverflow
    //     0xf8a270: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf8a274: cmp             SP, x16
    //     0xf8a278: b.ls            #0xf8a290
    // 0xf8a27c: ldr             x1, [fp, #0x10]
    // 0xf8a280: r0 = _utf8decode()
    //     0xf8a280: bl              #0xf8a298  ; [package:flutter/src/services/asset_bundle.dart] AssetBundle::_utf8decode
    // 0xf8a284: LeaveFrame
    //     0xf8a284: mov             SP, fp
    //     0xf8a288: ldp             fp, lr, [SP], #0x10
    // 0xf8a28c: ret
    //     0xf8a28c: ret             
    // 0xf8a290: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf8a290: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf8a294: b               #0xf8a27c
  }
  static _ _utf8decode(/* No info */) {
    // ** addr: 0xf8a298, size: 0x48
    // 0xf8a298: EnterFrame
    //     0xf8a298: stp             fp, lr, [SP, #-0x10]!
    //     0xf8a29c: mov             fp, SP
    // 0xf8a2a0: mov             x2, x1
    // 0xf8a2a4: CheckStackOverflow
    //     0xf8a2a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf8a2a8: cmp             SP, x16
    //     0xf8a2ac: b.ls            #0xf8a2d8
    // 0xf8a2b0: r1 = Null
    //     0xf8a2b0: mov             x1, NULL
    // 0xf8a2b4: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xf8a2b4: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xf8a2b8: r0 = Uint8List.sublistView()
    //     0xf8a2b8: bl              #0xccff20  ; [dart:typed_data] Uint8List::Uint8List.sublistView
    // 0xf8a2bc: mov             x2, x0
    // 0xf8a2c0: r1 = Instance_Utf8Codec
    //     0xf8a2c0: ldr             x1, [PP, #0x11e0]  ; [pp+0x11e0] Obj!Utf8Codec@12b7e61
    // 0xf8a2c4: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xf8a2c4: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xf8a2c8: r0 = decode()
    //     0xf8a2c8: bl              #0x121a094  ; [dart:convert] Utf8Codec::decode
    // 0xf8a2cc: LeaveFrame
    //     0xf8a2cc: mov             SP, fp
    //     0xf8a2d0: ldp             fp, lr, [SP], #0x10
    // 0xf8a2d4: ret
    //     0xf8a2d4: ret             
    // 0xf8a2d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf8a2d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf8a2dc: b               #0xf8a2b0
  }
}

// class id: 2809, size: 0x14, field offset: 0x8
abstract class CachingAssetBundle extends AssetBundle {

  _ CachingAssetBundle(/* No info */) {
    // ** addr: 0x848d98, size: 0xc4
    // 0x848d98: EnterFrame
    //     0x848d98: stp             fp, lr, [SP, #-0x10]!
    //     0x848d9c: mov             fp, SP
    // 0x848da0: AllocStack(0x18)
    //     0x848da0: sub             SP, SP, #0x18
    // 0x848da4: SetupParameters(CachingAssetBundle this /* r1 => r1, fp-0x8 */)
    //     0x848da4: stur            x1, [fp, #-8]
    // 0x848da8: CheckStackOverflow
    //     0x848da8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x848dac: cmp             SP, x16
    //     0x848db0: b.ls            #0x848e54
    // 0x848db4: r16 = <String, Future<String>>
    //     0x848db4: ldr             x16, [PP, #0x3510]  ; [pp+0x3510] TypeArguments: <String, Future<String>>
    // 0x848db8: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x848dbc: stp             lr, x16, [SP]
    // 0x848dc0: r0 = Map._fromLiteral()
    //     0x848dc0: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x848dc4: ldur            x1, [fp, #-8]
    // 0x848dc8: StoreField: r1->field_7 = r0
    //     0x848dc8: stur            w0, [x1, #7]
    //     0x848dcc: ldurb           w16, [x1, #-1]
    //     0x848dd0: ldurb           w17, [x0, #-1]
    //     0x848dd4: and             x16, x17, x16, lsr #2
    //     0x848dd8: tst             x16, HEAP, lsr #32
    //     0x848ddc: b.eq            #0x848de4
    //     0x848de0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x848de4: r16 = <String, Future>
    //     0x848de4: ldr             x16, [PP, #0x3518]  ; [pp+0x3518] TypeArguments: <String, Future>
    // 0x848de8: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x848dec: stp             lr, x16, [SP]
    // 0x848df0: r0 = Map._fromLiteral()
    //     0x848df0: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x848df4: ldur            x1, [fp, #-8]
    // 0x848df8: StoreField: r1->field_b = r0
    //     0x848df8: stur            w0, [x1, #0xb]
    //     0x848dfc: ldurb           w16, [x1, #-1]
    //     0x848e00: ldurb           w17, [x0, #-1]
    //     0x848e04: and             x16, x17, x16, lsr #2
    //     0x848e08: tst             x16, HEAP, lsr #32
    //     0x848e0c: b.eq            #0x848e14
    //     0x848e10: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x848e14: r16 = <String, Future>
    //     0x848e14: ldr             x16, [PP, #0x3518]  ; [pp+0x3518] TypeArguments: <String, Future>
    // 0x848e18: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x848e1c: stp             lr, x16, [SP]
    // 0x848e20: r0 = Map._fromLiteral()
    //     0x848e20: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x848e24: ldur            x1, [fp, #-8]
    // 0x848e28: StoreField: r1->field_f = r0
    //     0x848e28: stur            w0, [x1, #0xf]
    //     0x848e2c: ldurb           w16, [x1, #-1]
    //     0x848e30: ldurb           w17, [x0, #-1]
    //     0x848e34: and             x16, x17, x16, lsr #2
    //     0x848e38: tst             x16, HEAP, lsr #32
    //     0x848e3c: b.eq            #0x848e44
    //     0x848e40: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x848e44: r0 = Null
    //     0x848e44: mov             x0, NULL
    // 0x848e48: LeaveFrame
    //     0x848e48: mov             SP, fp
    //     0x848e4c: ldp             fp, lr, [SP], #0x10
    // 0x848e50: ret
    //     0x848e50: ret             
    // 0x848e54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x848e54: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x848e58: b               #0x848db4
  }
  _ clear(/* No info */) {
    // ** addr: 0x87c894, size: 0x64
    // 0x87c894: EnterFrame
    //     0x87c894: stp             fp, lr, [SP, #-0x10]!
    //     0x87c898: mov             fp, SP
    // 0x87c89c: AllocStack(0x8)
    //     0x87c89c: sub             SP, SP, #8
    // 0x87c8a0: SetupParameters(CachingAssetBundle this /* r1 => r0, fp-0x8 */)
    //     0x87c8a0: mov             x0, x1
    //     0x87c8a4: stur            x1, [fp, #-8]
    // 0x87c8a8: CheckStackOverflow
    //     0x87c8a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87c8ac: cmp             SP, x16
    //     0x87c8b0: b.ls            #0x87c8f0
    // 0x87c8b4: LoadField: r1 = r0->field_7
    //     0x87c8b4: ldur            w1, [x0, #7]
    // 0x87c8b8: DecompressPointer r1
    //     0x87c8b8: add             x1, x1, HEAP, lsl #32
    // 0x87c8bc: r0 = clear()
    //     0x87c8bc: bl              #0xa11274  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0x87c8c0: ldur            x0, [fp, #-8]
    // 0x87c8c4: LoadField: r1 = r0->field_b
    //     0x87c8c4: ldur            w1, [x0, #0xb]
    // 0x87c8c8: DecompressPointer r1
    //     0x87c8c8: add             x1, x1, HEAP, lsl #32
    // 0x87c8cc: r0 = clear()
    //     0x87c8cc: bl              #0xa11274  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0x87c8d0: ldur            x0, [fp, #-8]
    // 0x87c8d4: LoadField: r1 = r0->field_f
    //     0x87c8d4: ldur            w1, [x0, #0xf]
    // 0x87c8d8: DecompressPointer r1
    //     0x87c8d8: add             x1, x1, HEAP, lsl #32
    // 0x87c8dc: r0 = clear()
    //     0x87c8dc: bl              #0xa11274  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0x87c8e0: r0 = Null
    //     0x87c8e0: mov             x0, NULL
    // 0x87c8e4: LeaveFrame
    //     0x87c8e4: mov             SP, fp
    //     0x87c8e8: ldp             fp, lr, [SP], #0x10
    // 0x87c8ec: ret
    //     0x87c8ec: ret             
    // 0x87c8f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87c8f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87c8f4: b               #0x87c8b4
  }
  Future<Y0> loadStructuredBinaryData<Y0>(CachingAssetBundle, String, (dynamic, ByteData) => FutureOr<Y0>) {
    // ** addr: 0xeb3b7c, size: 0x250
    // 0xeb3b7c: EnterFrame
    //     0xeb3b7c: stp             fp, lr, [SP, #-0x10]!
    //     0xeb3b80: mov             fp, SP
    // 0xeb3b84: AllocStack(0x48)
    //     0xeb3b84: sub             SP, SP, #0x48
    // 0xeb3b88: SetupParameters([dynamic _, dynamic _, dynamic _ /* r1 */])
    //     0xeb3b88: ldur            w0, [x4, #0xf]
    //     0xeb3b8c: cbnz            w0, #0xeb3b98
    //     0xeb3b90: mov             x0, NULL
    //     0xeb3b94: b               #0xeb3ba8
    //     0xeb3b98: ldur            w0, [x4, #0x17]
    //     0xeb3b9c: add             x1, fp, w0, sxtw #2
    //     0xeb3ba0: ldr             x1, [x1, #0x10]
    //     0xeb3ba4: mov             x0, x1
    //     0xeb3ba8: ldr             x1, [fp, #0x20]
    //     0xeb3bac: stur            x0, [fp, #-8]
    // 0xeb3bb0: CheckStackOverflow
    //     0xeb3bb0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeb3bb4: cmp             SP, x16
    //     0xeb3bb8: b.ls            #0xeb3dc0
    // 0xeb3bbc: r1 = 4
    //     0xeb3bbc: mov             x1, #4
    // 0xeb3bc0: r0 = AllocateContext()
    //     0xeb3bc0: bl              #0x13de838  ; AllocateContextStub
    // 0xeb3bc4: mov             x3, x0
    // 0xeb3bc8: ldr             x0, [fp, #0x20]
    // 0xeb3bcc: stur            x3, [fp, #-0x18]
    // 0xeb3bd0: StoreField: r3->field_f = r0
    //     0xeb3bd0: stur            w0, [x3, #0xf]
    // 0xeb3bd4: r2 = "AssetManifest.bin"
    //     0xeb3bd4: add             x2, PP, #0x14, lsl #12  ; [pp+0x140e8] "AssetManifest.bin"
    //     0xeb3bd8: ldr             x2, [x2, #0xe8]
    // 0xeb3bdc: StoreField: r3->field_13 = r2
    //     0xeb3bdc: stur            w2, [x3, #0x13]
    // 0xeb3be0: LoadField: r4 = r0->field_f
    //     0xeb3be0: ldur            w4, [x0, #0xf]
    // 0xeb3be4: DecompressPointer r4
    //     0xeb3be4: add             x4, x4, HEAP, lsl #32
    // 0xeb3be8: mov             x1, x4
    // 0xeb3bec: stur            x4, [fp, #-0x10]
    // 0xeb3bf0: r0 = containsKey()
    //     0xeb3bf0: bl              #0x12d5a5c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0xeb3bf4: tbnz            w0, #4, #0xeb3c70
    // 0xeb3bf8: ldur            x0, [fp, #-0x18]
    // 0xeb3bfc: ldur            x3, [fp, #-0x10]
    // 0xeb3c00: LoadField: r2 = r0->field_13
    //     0xeb3c00: ldur            w2, [x0, #0x13]
    // 0xeb3c04: DecompressPointer r2
    //     0xeb3c04: add             x2, x2, HEAP, lsl #32
    // 0xeb3c08: mov             x1, x3
    // 0xeb3c0c: r0 = _getValueOrData()
    //     0xeb3c0c: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xeb3c10: ldur            x3, [fp, #-0x10]
    // 0xeb3c14: LoadField: r1 = r3->field_f
    //     0xeb3c14: ldur            w1, [x3, #0xf]
    // 0xeb3c18: DecompressPointer r1
    //     0xeb3c18: add             x1, x1, HEAP, lsl #32
    // 0xeb3c1c: cmp             w1, w0
    // 0xeb3c20: b.ne            #0xeb3c2c
    // 0xeb3c24: r3 = Null
    //     0xeb3c24: mov             x3, NULL
    // 0xeb3c28: b               #0xeb3c30
    // 0xeb3c2c: mov             x3, x0
    // 0xeb3c30: stur            x3, [fp, #-0x20]
    // 0xeb3c34: cmp             w3, NULL
    // 0xeb3c38: b.eq            #0xeb3dc8
    // 0xeb3c3c: mov             x0, x3
    // 0xeb3c40: ldur            x1, [fp, #-8]
    // 0xeb3c44: r2 = Null
    //     0xeb3c44: mov             x2, NULL
    // 0xeb3c48: r8 = Future<Y0>
    //     0xeb3c48: add             x8, PP, #0x14, lsl #12  ; [pp+0x14108] Type: Future<Y0>
    //     0xeb3c4c: ldr             x8, [x8, #0x108]
    // 0xeb3c50: LoadField: r9 = r8->field_7
    //     0xeb3c50: ldur            x9, [x8, #7]
    // 0xeb3c54: r3 = Null
    //     0xeb3c54: add             x3, PP, #0x14, lsl #12  ; [pp+0x14110] Null
    //     0xeb3c58: ldr             x3, [x3, #0x110]
    // 0xeb3c5c: blr             x9
    // 0xeb3c60: ldur            x0, [fp, #-0x20]
    // 0xeb3c64: LeaveFrame
    //     0xeb3c64: mov             SP, fp
    //     0xeb3c68: ldp             fp, lr, [SP], #0x10
    // 0xeb3c6c: ret
    //     0xeb3c6c: ret             
    // 0xeb3c70: ldur            x4, [fp, #-8]
    // 0xeb3c74: ldur            x0, [fp, #-0x18]
    // 0xeb3c78: ldur            x3, [fp, #-0x10]
    // 0xeb3c7c: ArrayStore: r0[0] = rNULL  ; List_4
    //     0xeb3c7c: stur            NULL, [x0, #0x17]
    // 0xeb3c80: StoreField: r0->field_1b = rNULL
    //     0xeb3c80: stur            NULL, [x0, #0x1b]
    // 0xeb3c84: LoadField: r2 = r0->field_13
    //     0xeb3c84: ldur            w2, [x0, #0x13]
    // 0xeb3c88: DecompressPointer r2
    //     0xeb3c88: add             x2, x2, HEAP, lsl #32
    // 0xeb3c8c: ldr             x1, [fp, #0x20]
    // 0xeb3c90: r0 = load()
    //     0xeb3c90: bl              #0x84810c  ; [package:flutter/src/services/asset_bundle.dart] PlatformAssetBundle::load
    // 0xeb3c94: ldur            x16, [fp, #-8]
    // 0xeb3c98: stp             x0, x16, [SP, #8]
    // 0xeb3c9c: r16 = Closure: (ByteData) => _AssetManifestBin from Function '_AssetManifestBin@628287047.fromStandardMessageCodecMessage': static.
    //     0xeb3c9c: add             x16, PP, #0x14, lsl #12  ; [pp+0x140f0] Closure: (ByteData) => _AssetManifestBin from Function '_AssetManifestBin@628287047.fromStandardMessageCodecMessage': static. (0x7f2adad9b010)
    //     0xeb3ca0: ldr             x16, [x16, #0xf0]
    // 0xeb3ca4: str             x16, [SP]
    // 0xeb3ca8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xeb3ca8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xeb3cac: r0 = then()
    //     0xeb3cac: bl              #0x1293070  ; [dart:async] _Future::then
    // 0xeb3cb0: ldur            x2, [fp, #-0x18]
    // 0xeb3cb4: r1 = Function '<anonymous closure>':.
    //     0xeb3cb4: add             x1, PP, #0x14, lsl #12  ; [pp+0x14120] AnonymousClosure: (0xeb3e54), in [package:flutter/src/services/asset_bundle.dart] CachingAssetBundle::loadStructuredBinaryData (0xeb3b7c)
    //     0xeb3cb8: ldr             x1, [x1, #0x120]
    // 0xeb3cbc: stur            x0, [fp, #-0x20]
    // 0xeb3cc0: r0 = AllocateClosure()
    //     0xeb3cc0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xeb3cc4: mov             x3, x0
    // 0xeb3cc8: ldur            x0, [fp, #-8]
    // 0xeb3ccc: stur            x3, [fp, #-0x28]
    // 0xeb3cd0: StoreField: r3->field_b = r0
    //     0xeb3cd0: stur            w0, [x3, #0xb]
    // 0xeb3cd4: ldur            x2, [fp, #-0x18]
    // 0xeb3cd8: r1 = Function '<anonymous closure>':.
    //     0xeb3cd8: add             x1, PP, #0x14, lsl #12  ; [pp+0x14128] AnonymousClosure: (0xeb3dcc), in [package:flutter/src/services/asset_bundle.dart] CachingAssetBundle::loadStructuredBinaryData (0xeb3b7c)
    //     0xeb3cdc: ldr             x1, [x1, #0x128]
    // 0xeb3ce0: r0 = AllocateClosure()
    //     0xeb3ce0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xeb3ce4: ldur            x1, [fp, #-8]
    // 0xeb3ce8: StoreField: r0->field_b = r1
    //     0xeb3ce8: stur            w1, [x0, #0xb]
    // 0xeb3cec: r16 = <void?>
    //     0xeb3cec: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xeb3cf0: ldur            lr, [fp, #-0x20]
    // 0xeb3cf4: stp             lr, x16, [SP, #0x10]
    // 0xeb3cf8: ldur            x16, [fp, #-0x28]
    // 0xeb3cfc: stp             x0, x16, [SP]
    // 0xeb3d00: r4 = const [0x1, 0x3, 0x3, 0x2, onError, 0x2, null]
    //     0xeb3d00: ldr             x4, [PP, #0x538]  ; [pp+0x538] List(7) [0x1, 0x3, 0x3, 0x2, "onError", 0x2, Null]
    // 0xeb3d04: r0 = then()
    //     0xeb3d04: bl              #0x1293070  ; [dart:async] _Future::then
    // 0xeb3d08: ldur            x0, [fp, #-0x18]
    // 0xeb3d0c: LoadField: r1 = r0->field_1b
    //     0xeb3d0c: ldur            w1, [x0, #0x1b]
    // 0xeb3d10: DecompressPointer r1
    //     0xeb3d10: add             x1, x1, HEAP, lsl #32
    // 0xeb3d14: cmp             w1, NULL
    // 0xeb3d18: b.eq            #0xeb3d2c
    // 0xeb3d1c: mov             x0, x1
    // 0xeb3d20: LeaveFrame
    //     0xeb3d20: mov             SP, fp
    //     0xeb3d24: ldp             fp, lr, [SP], #0x10
    // 0xeb3d28: ret
    //     0xeb3d28: ret             
    // 0xeb3d2c: ldur            x1, [fp, #-8]
    // 0xeb3d30: r0 = _Future()
    //     0xeb3d30: bl              #0x7f5dd4  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0xeb3d34: stur            x0, [fp, #-0x20]
    // 0xeb3d38: StoreField: r0->field_b = rZR
    //     0xeb3d38: stur            xzr, [x0, #0xb]
    // 0xeb3d3c: r0 = LoadStaticField(0x364)
    //     0xeb3d3c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xeb3d40: ldr             x0, [x0, #0x6c8]
    // 0xeb3d44: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xeb3d48: cmp             w0, w16
    // 0xeb3d4c: b.ne            #0xeb3d58
    // 0xeb3d50: r2 = _current
    //     0xeb3d50: ldr             x2, [PP, #0x2c0]  ; [pp+0x2c0] Field <Zone._current@5048458>: static late (offset: 0x364)
    // 0xeb3d54: r0 = InitLateStaticField()
    //     0xeb3d54: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0xeb3d58: ldur            x3, [fp, #-0x20]
    // 0xeb3d5c: StoreField: r3->field_13 = r0
    //     0xeb3d5c: stur            w0, [x3, #0x13]
    // 0xeb3d60: ldur            x1, [fp, #-8]
    // 0xeb3d64: r0 = _AsyncCompleter()
    //     0xeb3d64: bl              #0x7f5dc8  ; Allocate_AsyncCompleterStub -> _AsyncCompleter<X0> (size=0x10)
    // 0xeb3d68: ldur            x3, [fp, #-0x20]
    // 0xeb3d6c: StoreField: r0->field_b = r3
    //     0xeb3d6c: stur            w3, [x0, #0xb]
    // 0xeb3d70: ldur            x4, [fp, #-0x18]
    // 0xeb3d74: ArrayStore: r4[0] = r0  ; List_4
    //     0xeb3d74: stur            w0, [x4, #0x17]
    //     0xeb3d78: ldurb           w16, [x4, #-1]
    //     0xeb3d7c: ldurb           w17, [x0, #-1]
    //     0xeb3d80: and             x16, x17, x16, lsr #2
    //     0xeb3d84: tst             x16, HEAP, lsr #32
    //     0xeb3d88: b.eq            #0xeb3d90
    //     0xeb3d8c: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xeb3d90: LoadField: r2 = r4->field_13
    //     0xeb3d90: ldur            w2, [x4, #0x13]
    // 0xeb3d94: DecompressPointer r2
    //     0xeb3d94: add             x2, x2, HEAP, lsl #32
    // 0xeb3d98: ldur            x1, [fp, #-0x10]
    // 0xeb3d9c: r0 = []=()
    //     0xeb3d9c: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xeb3da0: ldur            x1, [fp, #-0x18]
    // 0xeb3da4: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xeb3da4: ldur            w2, [x1, #0x17]
    // 0xeb3da8: DecompressPointer r2
    //     0xeb3da8: add             x2, x2, HEAP, lsl #32
    // 0xeb3dac: LoadField: r0 = r2->field_b
    //     0xeb3dac: ldur            w0, [x2, #0xb]
    // 0xeb3db0: DecompressPointer r0
    //     0xeb3db0: add             x0, x0, HEAP, lsl #32
    // 0xeb3db4: LeaveFrame
    //     0xeb3db4: mov             SP, fp
    //     0xeb3db8: ldp             fp, lr, [SP], #0x10
    // 0xeb3dbc: ret
    //     0xeb3dbc: ret             
    // 0xeb3dc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeb3dc0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeb3dc4: b               #0xeb3bbc
    // 0xeb3dc8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xeb3dc8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Null <anonymous closure>(dynamic, Object, StackTrace) {
    // ** addr: 0xeb3dcc, size: 0x88
    // 0xeb3dcc: EnterFrame
    //     0xeb3dcc: stp             fp, lr, [SP, #-0x10]!
    //     0xeb3dd0: mov             fp, SP
    // 0xeb3dd4: AllocStack(0x10)
    //     0xeb3dd4: sub             SP, SP, #0x10
    // 0xeb3dd8: SetupParameters([dynamic _ /* r0 */])
    //     0xeb3dd8: ldr             x0, [fp, #0x20]
    //     0xeb3ddc: ldur            w3, [x0, #0x17]
    //     0xeb3de0: add             x3, x3, HEAP, lsl #32
    //     0xeb3de4: stur            x3, [fp, #-8]
    // 0xeb3de8: CheckStackOverflow
    //     0xeb3de8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeb3dec: cmp             SP, x16
    //     0xeb3df0: b.ls            #0xeb3e48
    // 0xeb3df4: LoadField: r0 = r3->field_f
    //     0xeb3df4: ldur            w0, [x3, #0xf]
    // 0xeb3df8: DecompressPointer r0
    //     0xeb3df8: add             x0, x0, HEAP, lsl #32
    // 0xeb3dfc: LoadField: r1 = r0->field_f
    //     0xeb3dfc: ldur            w1, [x0, #0xf]
    // 0xeb3e00: DecompressPointer r1
    //     0xeb3e00: add             x1, x1, HEAP, lsl #32
    // 0xeb3e04: LoadField: r2 = r3->field_13
    //     0xeb3e04: ldur            w2, [x3, #0x13]
    // 0xeb3e08: DecompressPointer r2
    //     0xeb3e08: add             x2, x2, HEAP, lsl #32
    // 0xeb3e0c: r0 = remove()
    //     0xeb3e0c: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xeb3e10: ldur            x0, [fp, #-8]
    // 0xeb3e14: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xeb3e14: ldur            w1, [x0, #0x17]
    // 0xeb3e18: DecompressPointer r1
    //     0xeb3e18: add             x1, x1, HEAP, lsl #32
    // 0xeb3e1c: cmp             w1, NULL
    // 0xeb3e20: b.eq            #0xeb3e50
    // 0xeb3e24: ldr             x16, [fp, #0x10]
    // 0xeb3e28: str             x16, [SP]
    // 0xeb3e2c: ldr             x2, [fp, #0x18]
    // 0xeb3e30: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0xeb3e30: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0xeb3e34: r0 = completeError()
    //     0xeb3e34: bl              #0x7f6b94  ; [dart:async] _Completer::completeError
    // 0xeb3e38: r0 = Null
    //     0xeb3e38: mov             x0, NULL
    // 0xeb3e3c: LeaveFrame
    //     0xeb3e3c: mov             SP, fp
    //     0xeb3e40: ldp             fp, lr, [SP], #0x10
    // 0xeb3e44: ret
    //     0xeb3e44: ret             
    // 0xeb3e48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeb3e48: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeb3e4c: b               #0xeb3df4
    // 0xeb3e50: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xeb3e50: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Null <anonymous closure>(dynamic, Y0) {
    // ** addr: 0xeb3e54, size: 0xc8
    // 0xeb3e54: EnterFrame
    //     0xeb3e54: stp             fp, lr, [SP, #-0x10]!
    //     0xeb3e58: mov             fp, SP
    // 0xeb3e5c: AllocStack(0x10)
    //     0xeb3e5c: sub             SP, SP, #0x10
    // 0xeb3e60: SetupParameters([dynamic _ /* r0 */])
    //     0xeb3e60: ldr             x0, [fp, #0x18]
    //     0xeb3e64: ldur            w2, [x0, #0x17]
    //     0xeb3e68: add             x2, x2, HEAP, lsl #32
    //     0xeb3e6c: stur            x2, [fp, #-8]
    // 0xeb3e70: CheckStackOverflow
    //     0xeb3e70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeb3e74: cmp             SP, x16
    //     0xeb3e78: b.ls            #0xeb3f14
    // 0xeb3e7c: LoadField: r1 = r0->field_b
    //     0xeb3e7c: ldur            w1, [x0, #0xb]
    // 0xeb3e80: DecompressPointer r1
    //     0xeb3e80: add             x1, x1, HEAP, lsl #32
    // 0xeb3e84: r0 = SynchronousFuture()
    //     0xeb3e84: bl              #0xeb3f1c  ; AllocateSynchronousFutureStub -> SynchronousFuture<X0> (size=0x10)
    // 0xeb3e88: mov             x1, x0
    // 0xeb3e8c: ldr             x4, [fp, #0x10]
    // 0xeb3e90: StoreField: r1->field_b = r4
    //     0xeb3e90: stur            w4, [x1, #0xb]
    // 0xeb3e94: mov             x0, x1
    // 0xeb3e98: ldur            x5, [fp, #-8]
    // 0xeb3e9c: StoreField: r5->field_1b = r0
    //     0xeb3e9c: stur            w0, [x5, #0x1b]
    //     0xeb3ea0: ldurb           w16, [x5, #-1]
    //     0xeb3ea4: ldurb           w17, [x0, #-1]
    //     0xeb3ea8: and             x16, x17, x16, lsr #2
    //     0xeb3eac: tst             x16, HEAP, lsr #32
    //     0xeb3eb0: b.eq            #0xeb3eb8
    //     0xeb3eb4: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0xeb3eb8: LoadField: r0 = r5->field_f
    //     0xeb3eb8: ldur            w0, [x5, #0xf]
    // 0xeb3ebc: DecompressPointer r0
    //     0xeb3ebc: add             x0, x0, HEAP, lsl #32
    // 0xeb3ec0: LoadField: r2 = r0->field_f
    //     0xeb3ec0: ldur            w2, [x0, #0xf]
    // 0xeb3ec4: DecompressPointer r2
    //     0xeb3ec4: add             x2, x2, HEAP, lsl #32
    // 0xeb3ec8: LoadField: r0 = r5->field_13
    //     0xeb3ec8: ldur            w0, [x5, #0x13]
    // 0xeb3ecc: DecompressPointer r0
    //     0xeb3ecc: add             x0, x0, HEAP, lsl #32
    // 0xeb3ed0: mov             x3, x1
    // 0xeb3ed4: mov             x1, x2
    // 0xeb3ed8: mov             x2, x0
    // 0xeb3edc: r0 = []=()
    //     0xeb3edc: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xeb3ee0: ldur            x0, [fp, #-8]
    // 0xeb3ee4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xeb3ee4: ldur            w1, [x0, #0x17]
    // 0xeb3ee8: DecompressPointer r1
    //     0xeb3ee8: add             x1, x1, HEAP, lsl #32
    // 0xeb3eec: cmp             w1, NULL
    // 0xeb3ef0: b.eq            #0xeb3f04
    // 0xeb3ef4: ldr             x16, [fp, #0x10]
    // 0xeb3ef8: str             x16, [SP]
    // 0xeb3efc: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0xeb3efc: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0xeb3f00: r0 = complete()
    //     0xeb3f00: bl              #0x128a5ec  ; [dart:async] _AsyncCompleter::complete
    // 0xeb3f04: r0 = Null
    //     0xeb3f04: mov             x0, NULL
    // 0xeb3f08: LeaveFrame
    //     0xeb3f08: mov             SP, fp
    //     0xeb3f0c: ldp             fp, lr, [SP], #0x10
    // 0xeb3f10: ret
    //     0xeb3f10: ret             
    // 0xeb3f14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeb3f14: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeb3f18: b               #0xeb3e7c
  }
  _ loadString(/* No info */) {
    // ** addr: 0xf8a0b8, size: 0x7c
    // 0xf8a0b8: EnterFrame
    //     0xf8a0b8: stp             fp, lr, [SP, #-0x10]!
    //     0xf8a0bc: mov             fp, SP
    // 0xf8a0c0: AllocStack(0x18)
    //     0xf8a0c0: sub             SP, SP, #0x18
    // 0xf8a0c4: SetupParameters(CachingAssetBundle this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xf8a0c4: stur            x1, [fp, #-8]
    //     0xf8a0c8: stur            x2, [fp, #-0x10]
    // 0xf8a0cc: CheckStackOverflow
    //     0xf8a0cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf8a0d0: cmp             SP, x16
    //     0xf8a0d4: b.ls            #0xf8a12c
    // 0xf8a0d8: r1 = 2
    //     0xf8a0d8: mov             x1, #2
    // 0xf8a0dc: r0 = AllocateContext()
    //     0xf8a0dc: bl              #0x13de838  ; AllocateContextStub
    // 0xf8a0e0: mov             x1, x0
    // 0xf8a0e4: ldur            x0, [fp, #-8]
    // 0xf8a0e8: StoreField: r1->field_f = r0
    //     0xf8a0e8: stur            w0, [x1, #0xf]
    // 0xf8a0ec: ldur            x3, [fp, #-0x10]
    // 0xf8a0f0: StoreField: r1->field_13 = r3
    //     0xf8a0f0: stur            w3, [x1, #0x13]
    // 0xf8a0f4: LoadField: r4 = r0->field_7
    //     0xf8a0f4: ldur            w4, [x0, #7]
    // 0xf8a0f8: DecompressPointer r4
    //     0xf8a0f8: add             x4, x4, HEAP, lsl #32
    // 0xf8a0fc: mov             x2, x1
    // 0xf8a100: stur            x4, [fp, #-0x18]
    // 0xf8a104: r1 = Function '<anonymous closure>':.
    //     0xf8a104: add             x1, PP, #0x28, lsl #12  ; [pp+0x28950] AnonymousClosure: (0xf8a134), in [package:flutter/src/services/asset_bundle.dart] CachingAssetBundle::loadString (0xf8a0b8)
    //     0xf8a108: ldr             x1, [x1, #0x950]
    // 0xf8a10c: r0 = AllocateClosure()
    //     0xf8a10c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf8a110: ldur            x1, [fp, #-0x18]
    // 0xf8a114: ldur            x2, [fp, #-0x10]
    // 0xf8a118: mov             x3, x0
    // 0xf8a11c: r0 = putIfAbsent()
    //     0xf8a11c: bl              #0xa1be20  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::putIfAbsent
    // 0xf8a120: LeaveFrame
    //     0xf8a120: mov             SP, fp
    //     0xf8a124: ldp             fp, lr, [SP], #0x10
    // 0xf8a128: ret
    //     0xf8a128: ret             
    // 0xf8a12c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf8a12c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf8a130: b               #0xf8a0d8
  }
  [closure] Future<String> <anonymous closure>(dynamic) {
    // ** addr: 0xf8a134, size: 0x4c
    // 0xf8a134: EnterFrame
    //     0xf8a134: stp             fp, lr, [SP, #-0x10]!
    //     0xf8a138: mov             fp, SP
    // 0xf8a13c: ldr             x0, [fp, #0x10]
    // 0xf8a140: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf8a140: ldur            w1, [x0, #0x17]
    // 0xf8a144: DecompressPointer r1
    //     0xf8a144: add             x1, x1, HEAP, lsl #32
    // 0xf8a148: CheckStackOverflow
    //     0xf8a148: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf8a14c: cmp             SP, x16
    //     0xf8a150: b.ls            #0xf8a178
    // 0xf8a154: LoadField: r0 = r1->field_f
    //     0xf8a154: ldur            w0, [x1, #0xf]
    // 0xf8a158: DecompressPointer r0
    //     0xf8a158: add             x0, x0, HEAP, lsl #32
    // 0xf8a15c: LoadField: r2 = r1->field_13
    //     0xf8a15c: ldur            w2, [x1, #0x13]
    // 0xf8a160: DecompressPointer r2
    //     0xf8a160: add             x2, x2, HEAP, lsl #32
    // 0xf8a164: mov             x1, x0
    // 0xf8a168: r0 = loadString()
    //     0xf8a168: bl              #0xf8a180  ; [package:flutter/src/services/asset_bundle.dart] AssetBundle::loadString
    // 0xf8a16c: LeaveFrame
    //     0xf8a16c: mov             SP, fp
    //     0xf8a170: ldp             fp, lr, [SP], #0x10
    // 0xf8a174: ret
    //     0xf8a174: ret             
    // 0xf8a178: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf8a178: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf8a17c: b               #0xf8a154
  }
}

// class id: 2810, size: 0x14, field offset: 0x14
class PlatformAssetBundle extends CachingAssetBundle {

  _ load(/* No info */) {
    // ** addr: 0x84810c, size: 0xec
    // 0x84810c: EnterFrame
    //     0x84810c: stp             fp, lr, [SP, #-0x10]!
    //     0x848110: mov             fp, SP
    // 0x848114: AllocStack(0x28)
    //     0x848114: sub             SP, SP, #0x28
    // 0x848118: SetupParameters(PlatformAssetBundle this /* r1 => r0 */, dynamic _ /* r2 => r1, fp-0x8 */)
    //     0x848118: mov             x0, x1
    //     0x84811c: mov             x1, x2
    //     0x848120: stur            x2, [fp, #-8]
    // 0x848124: CheckStackOverflow
    //     0x848124: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x848128: cmp             SP, x16
    //     0x84812c: b.ls            #0x8481e4
    // 0x848130: r1 = 1
    //     0x848130: mov             x1, #1
    // 0x848134: r0 = AllocateContext()
    //     0x848134: bl              #0x13de838  ; AllocateContextStub
    // 0x848138: ldur            x1, [fp, #-8]
    // 0x84813c: stur            x0, [fp, #-0x10]
    // 0x848140: StoreField: r0->field_f = r1
    //     0x848140: stur            w1, [x0, #0xf]
    // 0x848144: r0 = encodeFull()
    //     0x848144: bl              #0x8487cc  ; [dart:core] Uri::encodeFull
    // 0x848148: str             x0, [SP]
    // 0x84814c: r1 = Null
    //     0x84814c: mov             x1, NULL
    // 0x848150: r4 = const [0, 0x2, 0x1, 0x1, path, 0x1, null]
    //     0x848150: ldr             x4, [PP, #0x3978]  ; [pp+0x3978] List(7) [0, 0x2, 0x1, 0x1, "path", 0x1, Null]
    // 0x848154: r0 = _Uri()
    //     0x848154: bl              #0x7e2fd8  ; [dart:core] _Uri::_Uri
    // 0x848158: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x848158: ldur            w2, [x0, #0x17]
    // 0x84815c: DecompressPointer r2
    //     0x84815c: add             x2, x2, HEAP, lsl #32
    // 0x848160: r1 = Instance_Utf8Encoder
    //     0x848160: ldr             x1, [PP, #0x11f8]  ; [pp+0x11f8] Obj!Utf8Encoder@12b7f11
    // 0x848164: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x848164: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x848168: r0 = convert()
    //     0x848168: bl              #0x122268c  ; [dart:convert] Utf8Encoder::convert
    // 0x84816c: r1 = LoadStaticField(0x7bc)
    //     0x84816c: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x848170: ldr             x1, [x1, #0xf78]
    // 0x848174: cmp             w1, NULL
    // 0x848178: b.eq            #0x8481ec
    // 0x84817c: LoadField: r2 = r1->field_97
    //     0x84817c: ldur            w2, [x1, #0x97]
    // 0x848180: DecompressPointer r2
    //     0x848180: add             x2, x2, HEAP, lsl #32
    // 0x848184: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x848188: cmp             w2, w16
    // 0x84818c: b.eq            #0x8481f0
    // 0x848190: mov             x2, x0
    // 0x848194: r1 = Null
    //     0x848194: mov             x1, NULL
    // 0x848198: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x848198: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x84819c: r0 = ByteData.sublistView()
    //     0x84819c: bl              #0x8486c8  ; [dart:typed_data] ByteData::ByteData.sublistView
    // 0x8481a0: mov             x3, x0
    // 0x8481a4: r1 = Instance__DefaultBinaryMessenger
    //     0x8481a4: ldr             x1, [PP, #0x848]  ; [pp+0x848] Obj!_DefaultBinaryMessenger@129c071
    // 0x8481a8: r2 = "flutter/assets"
    //     0x8481a8: ldr             x2, [PP, #0x3980]  ; [pp+0x3980] "flutter/assets"
    // 0x8481ac: r0 = send()
    //     0x8481ac: bl              #0x8481f8  ; [package:flutter/src/services/binding.dart] _DefaultBinaryMessenger::send
    // 0x8481b0: ldur            x2, [fp, #-0x10]
    // 0x8481b4: r1 = Function '<anonymous closure>':.
    //     0x8481b4: ldr             x1, [PP, #0x3988]  ; [pp+0x3988] AnonymousClosure: (0x848808), in [package:flutter/src/services/asset_bundle.dart] PlatformAssetBundle::load (0x84810c)
    // 0x8481b8: stur            x0, [fp, #-8]
    // 0x8481bc: r0 = AllocateClosure()
    //     0x8481bc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8481c0: r16 = <ByteData>
    //     0x8481c0: ldr             x16, [PP, #0x3990]  ; [pp+0x3990] TypeArguments: <ByteData>
    // 0x8481c4: ldur            lr, [fp, #-8]
    // 0x8481c8: stp             lr, x16, [SP, #8]
    // 0x8481cc: str             x0, [SP]
    // 0x8481d0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8481d0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8481d4: r0 = then()
    //     0x8481d4: bl              #0x1293070  ; [dart:async] _Future::then
    // 0x8481d8: LeaveFrame
    //     0x8481d8: mov             SP, fp
    //     0x8481dc: ldp             fp, lr, [SP], #0x10
    // 0x8481e0: ret
    //     0x8481e0: ret             
    // 0x8481e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8481e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8481e8: b               #0x848130
    // 0x8481ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8481ec: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8481f0: r9 = _defaultBinaryMessenger
    //     0x8481f0: ldr             x9, [PP, #0x1578]  ; [pp+0x1578] Field <_MixinApplication204&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding@18353248._defaultBinaryMessenger@137240726>: late final (offset: 0x98)
    // 0x8481f4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8481f4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] ByteData <anonymous closure>(dynamic, ByteData?) {
    // ** addr: 0x848808, size: 0xd4
    // 0x848808: EnterFrame
    //     0x848808: stp             fp, lr, [SP, #-0x10]!
    //     0x84880c: mov             fp, SP
    // 0x848810: AllocStack(0x18)
    //     0x848810: sub             SP, SP, #0x18
    // 0x848814: SetupParameters([dynamic _ /* r0 */])
    //     0x848814: ldr             x0, [fp, #0x18]
    //     0x848818: ldur            w1, [x0, #0x17]
    //     0x84881c: add             x1, x1, HEAP, lsl #32
    // 0x848820: CheckStackOverflow
    //     0x848820: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x848824: cmp             SP, x16
    //     0x848828: b.ls            #0x8488d4
    // 0x84882c: ldr             x0, [fp, #0x10]
    // 0x848830: cmp             w0, NULL
    // 0x848834: b.eq            #0x848844
    // 0x848838: LeaveFrame
    //     0x848838: mov             SP, fp
    //     0x84883c: ldp             fp, lr, [SP], #0x10
    // 0x848840: ret
    //     0x848840: ret             
    // 0x848844: LoadField: r0 = r1->field_f
    //     0x848844: ldur            w0, [x1, #0xf]
    // 0x848848: DecompressPointer r0
    //     0x848848: add             x0, x0, HEAP, lsl #32
    // 0x84884c: mov             x1, x0
    // 0x848850: r0 = _errorSummaryWithKey()
    //     0x848850: bl              #0x8488e8  ; [package:flutter/src/services/asset_bundle.dart] ::_errorSummaryWithKey
    // 0x848854: r1 = <List<Object>>
    //     0x848854: ldr             x1, [PP, #0x860]  ; [pp+0x860] TypeArguments: <List<Object>>
    // 0x848858: stur            x0, [fp, #-8]
    // 0x84885c: r0 = ErrorDescription()
    //     0x84885c: bl              #0x829ca4  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x2c)
    // 0x848860: mov             x1, x0
    // 0x848864: r2 = "The asset does not exist or has empty data."
    //     0x848864: ldr             x2, [PP, #0x3998]  ; [pp+0x3998] "The asset does not exist or has empty data."
    // 0x848868: r3 = Instance_DiagnosticLevel
    //     0x848868: ldr             x3, [PP, #0x868]  ; [pp+0x868] Obj!DiagnosticLevel@12c5f41
    // 0x84886c: stur            x0, [fp, #-0x10]
    // 0x848870: r0 = _ErrorDiagnostic()
    //     0x848870: bl              #0x829bec  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0x848874: r1 = Null
    //     0x848874: mov             x1, NULL
    // 0x848878: r2 = 4
    //     0x848878: mov             x2, #4
    // 0x84887c: r0 = AllocateArray()
    //     0x84887c: bl              #0x13df928  ; AllocateArrayStub
    // 0x848880: mov             x2, x0
    // 0x848884: ldur            x0, [fp, #-8]
    // 0x848888: stur            x2, [fp, #-0x18]
    // 0x84888c: StoreField: r2->field_f = r0
    //     0x84888c: stur            w0, [x2, #0xf]
    // 0x848890: ldur            x0, [fp, #-0x10]
    // 0x848894: StoreField: r2->field_13 = r0
    //     0x848894: stur            w0, [x2, #0x13]
    // 0x848898: r1 = <DiagnosticsNode>
    //     0x848898: ldr             x1, [PP, #0x1ea8]  ; [pp+0x1ea8] TypeArguments: <DiagnosticsNode>
    // 0x84889c: r0 = AllocateGrowableArray()
    //     0x84889c: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x8488a0: mov             x1, x0
    // 0x8488a4: ldur            x0, [fp, #-0x18]
    // 0x8488a8: stur            x1, [fp, #-8]
    // 0x8488ac: StoreField: r1->field_f = r0
    //     0x8488ac: stur            w0, [x1, #0xf]
    // 0x8488b0: r0 = 4
    //     0x8488b0: mov             x0, #4
    // 0x8488b4: StoreField: r1->field_b = r0
    //     0x8488b4: stur            w0, [x1, #0xb]
    // 0x8488b8: r0 = FlutterError()
    //     0x8488b8: bl              #0x8488dc  ; AllocateFlutterErrorStub -> FlutterError (size=0x10)
    // 0x8488bc: mov             x1, x0
    // 0x8488c0: ldur            x0, [fp, #-8]
    // 0x8488c4: StoreField: r1->field_b = r0
    //     0x8488c4: stur            w0, [x1, #0xb]
    // 0x8488c8: mov             x0, x1
    // 0x8488cc: r0 = Throw()
    //     0x8488cc: bl              #0x13ddb2c  ; ThrowStub
    // 0x8488d0: brk             #0
    // 0x8488d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8488d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8488d8: b               #0x84882c
  }
  _ loadBuffer(/* No info */) async {
    // ** addr: 0x1192308, size: 0x1e4
    // 0x1192308: EnterFrame
    //     0x1192308: stp             fp, lr, [SP, #-0x10]!
    //     0x119230c: mov             fp, SP
    // 0x1192310: AllocStack(0x90)
    //     0x1192310: sub             SP, SP, #0x90
    // 0x1192314: SetupParameters(PlatformAssetBundle this /* r1 => r2, fp-0x68 */, dynamic _ /* r2 => r1, fp-0x70 */)
    //     0x1192314: stur            NULL, [fp, #-8]
    //     0x1192318: stur            x1, [fp, #-0x68]
    //     0x119231c: mov             x16, x2
    //     0x1192320: mov             x2, x1
    //     0x1192324: mov             x1, x16
    //     0x1192328: stur            x1, [fp, #-0x70]
    // 0x119232c: CheckStackOverflow
    //     0x119232c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1192330: cmp             SP, x16
    //     0x1192334: b.ls            #0x11924e4
    // 0x1192338: InitAsync() -> Future<ImmutableBuffer>
    //     0x1192338: add             x0, PP, #0x93, lsl #12  ; [pp+0x938b8] TypeArguments: <ImmutableBuffer>
    //     0x119233c: ldr             x0, [x0, #0x8b8]
    //     0x1192340: bl              #0x7f5e44  ; InitAsyncStub
    // 0x1192344: ldur            x1, [fp, #-0x70]
    // 0x1192348: r0 = fromAsset()
    //     0x1192348: bl              #0x11924ec  ; [dart:ui] ImmutableBuffer::fromAsset
    // 0x119234c: mov             x1, x0
    // 0x1192350: stur            x1, [fp, #-0x68]
    // 0x1192354: r0 = Await()
    //     0x1192354: bl              #0x7f5c00  ; AwaitStub
    // 0x1192358: r0 = ReturnAsync()
    //     0x1192358: b               #0x82fdf0  ; ReturnAsyncStub
    // 0x119235c: sub             SP, fp, #0x90
    // 0x1192360: mov             x4, x0
    // 0x1192364: mov             x3, x1
    // 0x1192368: stur            x0, [fp, #-0x68]
    // 0x119236c: stur            x1, [fp, #-0x78]
    // 0x1192370: r2 = Null
    //     0x1192370: mov             x2, NULL
    // 0x1192374: r1 = Null
    //     0x1192374: mov             x1, NULL
    // 0x1192378: cmp             w0, NULL
    // 0x119237c: b.eq            #0x1192408
    // 0x1192380: branchIfSmi(r0, 0x1192408)
    //     0x1192380: tbz             w0, #0, #0x1192408
    // 0x1192384: r3 = LoadClassIdInstr(r0)
    //     0x1192384: ldur            x3, [x0, #-1]
    //     0x1192388: ubfx            x3, x3, #0xc, #0x14
    // 0x119238c: r4 = LoadClassIdInstr(r0)
    //     0x119238c: ldur            x4, [x0, #-1]
    //     0x1192390: ubfx            x4, x4, #0xc, #0x14
    // 0x1192394: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x1192398: ldr             x3, [x3, #0x18]
    // 0x119239c: ldr             x3, [x3, x4, lsl #3]
    // 0x11923a0: LoadField: r3 = r3->field_2b
    //     0x11923a0: ldur            w3, [x3, #0x2b]
    // 0x11923a4: DecompressPointer r3
    //     0x11923a4: add             x3, x3, HEAP, lsl #32
    // 0x11923a8: cmp             w3, NULL
    // 0x11923ac: b.eq            #0x1192408
    // 0x11923b0: LoadField: r3 = r3->field_f
    //     0x11923b0: ldur            w3, [x3, #0xf]
    // 0x11923b4: lsr             x3, x3, #3
    // 0x11923b8: r17 = 7744
    //     0x11923b8: mov             x17, #0x1e40
    // 0x11923bc: cmp             x3, x17
    // 0x11923c0: b.eq            #0x1192410
    // 0x11923c4: r3 = SubtypeTestCache
    //     0x11923c4: add             x3, PP, #0x97, lsl #12  ; [pp+0x97820] SubtypeTestCache
    //     0x11923c8: ldr             x3, [x3, #0x820]
    // 0x11923cc: r30 = Subtype1TestCacheStub
    //     0x11923cc: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x11923d0: LoadField: r30 = r30->field_7
    //     0x11923d0: ldur            lr, [lr, #7]
    // 0x11923d4: blr             lr
    // 0x11923d8: cmp             w7, NULL
    // 0x11923dc: b.eq            #0x11923e8
    // 0x11923e0: tbnz            w7, #4, #0x1192408
    // 0x11923e4: b               #0x1192410
    // 0x11923e8: r8 = Exception
    //     0x11923e8: add             x8, PP, #0x97, lsl #12  ; [pp+0x97828] Type: Exception
    //     0x11923ec: ldr             x8, [x8, #0x828]
    // 0x11923f0: r3 = SubtypeTestCache
    //     0x11923f0: add             x3, PP, #0x97, lsl #12  ; [pp+0x97830] SubtypeTestCache
    //     0x11923f4: ldr             x3, [x3, #0x830]
    // 0x11923f8: r30 = InstanceOfStub
    //     0x11923f8: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x11923fc: LoadField: r30 = r30->field_7
    //     0x11923fc: ldur            lr, [lr, #7]
    // 0x1192400: blr             lr
    // 0x1192404: b               #0x1192414
    // 0x1192408: r0 = false
    //     0x1192408: add             x0, NULL, #0x30  ; false
    // 0x119240c: b               #0x1192414
    // 0x1192410: r0 = true
    //     0x1192410: add             x0, NULL, #0x20  ; true
    // 0x1192414: tbnz            w0, #4, #0x11924d4
    // 0x1192418: ldur            x0, [fp, #-0x68]
    // 0x119241c: ldur            x1, [fp, #-0x70]
    // 0x1192420: r0 = _errorSummaryWithKey()
    //     0x1192420: bl              #0x8488e8  ; [package:flutter/src/services/asset_bundle.dart] ::_errorSummaryWithKey
    // 0x1192424: mov             x1, x0
    // 0x1192428: ldur            x0, [fp, #-0x68]
    // 0x119242c: stur            x1, [fp, #-0x70]
    // 0x1192430: r2 = LoadClassIdInstr(r0)
    //     0x1192430: ldur            x2, [x0, #-1]
    //     0x1192434: ubfx            x2, x2, #0xc, #0x14
    // 0x1192438: str             x0, [SP]
    // 0x119243c: mov             x0, x2
    // 0x1192440: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x1192440: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x1192444: r0 = GDT[cid_x0 + 0x91c1]()
    //     0x1192444: mov             x17, #0x91c1
    //     0x1192448: add             lr, x0, x17
    //     0x119244c: ldr             lr, [x21, lr, lsl #3]
    //     0x1192450: blr             lr
    // 0x1192454: r1 = <List<Object>>
    //     0x1192454: ldr             x1, [PP, #0x860]  ; [pp+0x860] TypeArguments: <List<Object>>
    // 0x1192458: stur            x0, [fp, #-0x80]
    // 0x119245c: r0 = ErrorDescription()
    //     0x119245c: bl              #0x829ca4  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x2c)
    // 0x1192460: mov             x1, x0
    // 0x1192464: ldur            x2, [fp, #-0x80]
    // 0x1192468: r3 = Instance_DiagnosticLevel
    //     0x1192468: ldr             x3, [PP, #0x868]  ; [pp+0x868] Obj!DiagnosticLevel@12c5f41
    // 0x119246c: stur            x0, [fp, #-0x80]
    // 0x1192470: r0 = _ErrorDiagnostic()
    //     0x1192470: bl              #0x829bec  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0x1192474: r1 = Null
    //     0x1192474: mov             x1, NULL
    // 0x1192478: r2 = 4
    //     0x1192478: mov             x2, #4
    // 0x119247c: r0 = AllocateArray()
    //     0x119247c: bl              #0x13df928  ; AllocateArrayStub
    // 0x1192480: mov             x2, x0
    // 0x1192484: ldur            x0, [fp, #-0x70]
    // 0x1192488: stur            x2, [fp, #-0x88]
    // 0x119248c: StoreField: r2->field_f = r0
    //     0x119248c: stur            w0, [x2, #0xf]
    // 0x1192490: ldur            x0, [fp, #-0x80]
    // 0x1192494: StoreField: r2->field_13 = r0
    //     0x1192494: stur            w0, [x2, #0x13]
    // 0x1192498: r1 = <DiagnosticsNode>
    //     0x1192498: ldr             x1, [PP, #0x1ea8]  ; [pp+0x1ea8] TypeArguments: <DiagnosticsNode>
    // 0x119249c: r0 = AllocateGrowableArray()
    //     0x119249c: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x11924a0: mov             x1, x0
    // 0x11924a4: ldur            x0, [fp, #-0x88]
    // 0x11924a8: stur            x1, [fp, #-0x70]
    // 0x11924ac: StoreField: r1->field_f = r0
    //     0x11924ac: stur            w0, [x1, #0xf]
    // 0x11924b0: r0 = 4
    //     0x11924b0: mov             x0, #4
    // 0x11924b4: StoreField: r1->field_b = r0
    //     0x11924b4: stur            w0, [x1, #0xb]
    // 0x11924b8: r0 = FlutterError()
    //     0x11924b8: bl              #0x8488dc  ; AllocateFlutterErrorStub -> FlutterError (size=0x10)
    // 0x11924bc: mov             x1, x0
    // 0x11924c0: ldur            x0, [fp, #-0x70]
    // 0x11924c4: StoreField: r1->field_b = r0
    //     0x11924c4: stur            w0, [x1, #0xb]
    // 0x11924c8: mov             x0, x1
    // 0x11924cc: r0 = Throw()
    //     0x11924cc: bl              #0x13ddb2c  ; ThrowStub
    // 0x11924d0: brk             #0
    // 0x11924d4: ldur            x0, [fp, #-0x68]
    // 0x11924d8: ldur            x1, [fp, #-0x78]
    // 0x11924dc: r0 = ReThrow()
    //     0x11924dc: bl              #0x13ddb00  ; ReThrowStub
    // 0x11924e0: brk             #0
    // 0x11924e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11924e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11924e8: b               #0x1192338
  }
}

// class id: 2811, size: 0x10, field offset: 0x8
class NetworkAssetBundle extends AssetBundle {

  _ load(/* No info */) async {
    // ** addr: 0x1004948, size: 0x188
    // 0x1004948: EnterFrame
    //     0x1004948: stp             fp, lr, [SP, #-0x10]!
    //     0x100494c: mov             fp, SP
    // 0x1004950: AllocStack(0x20)
    //     0x1004950: sub             SP, SP, #0x20
    // 0x1004954: SetupParameters(NetworkAssetBundle this /* r1 => r1, fp-0x10 */)
    //     0x1004954: stur            NULL, [fp, #-8]
    //     0x1004958: stur            x1, [fp, #-0x10]
    // 0x100495c: CheckStackOverflow
    //     0x100495c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1004960: cmp             SP, x16
    //     0x1004964: b.ls            #0x1004ac0
    // 0x1004968: InitAsync() -> Future<ByteData>
    //     0x1004968: ldr             x0, [PP, #0x3990]  ; [pp+0x3990] TypeArguments: <ByteData>
    //     0x100496c: bl              #0x7f5e44  ; InitAsyncStub
    // 0x1004970: ldur            x1, [fp, #-0x10]
    // 0x1004974: LoadField: r0 = r1->field_b
    //     0x1004974: ldur            w0, [x1, #0xb]
    // 0x1004978: DecompressPointer r0
    //     0x1004978: add             x0, x0, HEAP, lsl #32
    // 0x100497c: stur            x0, [fp, #-0x18]
    // 0x1004980: r0 = _urlFromKey()
    //     0x1004980: bl              #0x100505c  ; [package:flutter/src/services/asset_bundle.dart] NetworkAssetBundle::_urlFromKey
    // 0x1004984: ldur            x1, [fp, #-0x18]
    // 0x1004988: mov             x2, x0
    // 0x100498c: r0 = getUrl()
    //     0x100498c: bl              #0x1005024  ; [dart:_http] _HttpClient::getUrl
    // 0x1004990: mov             x1, x0
    // 0x1004994: stur            x1, [fp, #-0x10]
    // 0x1004998: r0 = Await()
    //     0x1004998: bl              #0x7f5c00  ; AwaitStub
    // 0x100499c: mov             x1, x0
    // 0x10049a0: r0 = close()
    //     0x10049a0: bl              #0x814a10  ; [dart:_http] _HttpClientRequest::close
    // 0x10049a4: mov             x1, x0
    // 0x10049a8: stur            x1, [fp, #-0x10]
    // 0x10049ac: r0 = Await()
    //     0x10049ac: bl              #0x7f5c00  ; AwaitStub
    // 0x10049b0: LoadField: r2 = r0->field_b
    //     0x10049b0: ldur            w2, [x0, #0xb]
    // 0x10049b4: DecompressPointer r2
    //     0x10049b4: add             x2, x2, HEAP, lsl #32
    // 0x10049b8: stur            x2, [fp, #-0x18]
    // 0x10049bc: LoadField: r1 = r2->field_1b
    //     0x10049bc: ldur            w1, [x2, #0x1b]
    // 0x10049c0: DecompressPointer r1
    //     0x10049c0: add             x1, x1, HEAP, lsl #32
    // 0x10049c4: cmp             w1, NULL
    // 0x10049c8: b.eq            #0x1004ac8
    // 0x10049cc: cmp             w1, #0x190
    // 0x10049d0: b.ne            #0x1004a00
    // 0x10049d4: mov             x1, x0
    // 0x10049d8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x10049d8: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x10049dc: r0 = consolidateHttpClientResponseBytes()
    //     0x10049dc: bl              #0x1004adc  ; [package:flutter/src/foundation/consolidate_response.dart] ::consolidateHttpClientResponseBytes
    // 0x10049e0: mov             x1, x0
    // 0x10049e4: stur            x1, [fp, #-0x10]
    // 0x10049e8: r0 = Await()
    //     0x10049e8: bl              #0x7f5c00  ; AwaitStub
    // 0x10049ec: mov             x2, x0
    // 0x10049f0: r1 = Null
    //     0x10049f0: mov             x1, NULL
    // 0x10049f4: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x10049f4: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x10049f8: r0 = ByteData.sublistView()
    //     0x10049f8: bl              #0x8486c8  ; [dart:typed_data] ByteData::ByteData.sublistView
    // 0x10049fc: r0 = ReturnAsyncNotFuture()
    //     0x10049fc: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x1004a00: r1 = ""
    //     0x1004a00: ldr             x1, [PP, #0x900]  ; [pp+0x900] ""
    // 0x1004a04: r0 = _errorSummaryWithKey()
    //     0x1004a04: bl              #0x8488e8  ; [package:flutter/src/services/asset_bundle.dart] ::_errorSummaryWithKey
    // 0x1004a08: mov             x2, x0
    // 0x1004a0c: ldur            x0, [fp, #-0x18]
    // 0x1004a10: stur            x2, [fp, #-0x20]
    // 0x1004a14: LoadField: r3 = r0->field_1b
    //     0x1004a14: ldur            w3, [x0, #0x1b]
    // 0x1004a18: DecompressPointer r3
    //     0x1004a18: add             x3, x3, HEAP, lsl #32
    // 0x1004a1c: stur            x3, [fp, #-0x10]
    // 0x1004a20: cmp             w3, NULL
    // 0x1004a24: b.eq            #0x1004acc
    // 0x1004a28: r1 = <int>
    //     0x1004a28: ldr             x1, [PP, #0x50]  ; [pp+0x50] TypeArguments: <int>
    // 0x1004a2c: r0 = IntProperty()
    //     0x1004a2c: bl              #0x1004ad0  ; AllocateIntPropertyStub -> IntProperty (size=0x2c)
    // 0x1004a30: mov             x3, x0
    // 0x1004a34: r0 = Instance__NoDefaultValue
    //     0x1004a34: ldr             x0, [PP, #0xca0]  ; [pp+0xca0] Obj!_NoDefaultValue@129f291
    // 0x1004a38: stur            x3, [fp, #-0x18]
    // 0x1004a3c: StoreField: r3->field_23 = r0
    //     0x1004a3c: stur            w0, [x3, #0x23]
    // 0x1004a40: r0 = false
    //     0x1004a40: add             x0, NULL, #0x30  ; false
    // 0x1004a44: StoreField: r3->field_13 = r0
    //     0x1004a44: stur            w0, [x3, #0x13]
    // 0x1004a48: r0 = true
    //     0x1004a48: add             x0, NULL, #0x20  ; true
    // 0x1004a4c: StoreField: r3->field_1b = r0
    //     0x1004a4c: stur            w0, [x3, #0x1b]
    // 0x1004a50: ldur            x0, [fp, #-0x10]
    // 0x1004a54: ArrayStore: r3[0] = r0  ; List_4
    //     0x1004a54: stur            w0, [x3, #0x17]
    // 0x1004a58: r0 = Instance_DiagnosticLevel
    //     0x1004a58: ldr             x0, [PP, #0x868]  ; [pp+0x868] Obj!DiagnosticLevel@12c5f41
    // 0x1004a5c: StoreField: r3->field_27 = r0
    //     0x1004a5c: stur            w0, [x3, #0x27]
    // 0x1004a60: r1 = Null
    //     0x1004a60: mov             x1, NULL
    // 0x1004a64: r2 = 4
    //     0x1004a64: mov             x2, #4
    // 0x1004a68: r0 = AllocateArray()
    //     0x1004a68: bl              #0x13df928  ; AllocateArrayStub
    // 0x1004a6c: mov             x2, x0
    // 0x1004a70: ldur            x0, [fp, #-0x20]
    // 0x1004a74: stur            x2, [fp, #-0x10]
    // 0x1004a78: StoreField: r2->field_f = r0
    //     0x1004a78: stur            w0, [x2, #0xf]
    // 0x1004a7c: ldur            x0, [fp, #-0x18]
    // 0x1004a80: StoreField: r2->field_13 = r0
    //     0x1004a80: stur            w0, [x2, #0x13]
    // 0x1004a84: r1 = <DiagnosticsNode>
    //     0x1004a84: ldr             x1, [PP, #0x1ea8]  ; [pp+0x1ea8] TypeArguments: <DiagnosticsNode>
    // 0x1004a88: r0 = AllocateGrowableArray()
    //     0x1004a88: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x1004a8c: mov             x1, x0
    // 0x1004a90: ldur            x0, [fp, #-0x10]
    // 0x1004a94: stur            x1, [fp, #-0x18]
    // 0x1004a98: StoreField: r1->field_f = r0
    //     0x1004a98: stur            w0, [x1, #0xf]
    // 0x1004a9c: r0 = 4
    //     0x1004a9c: mov             x0, #4
    // 0x1004aa0: StoreField: r1->field_b = r0
    //     0x1004aa0: stur            w0, [x1, #0xb]
    // 0x1004aa4: r0 = FlutterError()
    //     0x1004aa4: bl              #0x8488dc  ; AllocateFlutterErrorStub -> FlutterError (size=0x10)
    // 0x1004aa8: mov             x1, x0
    // 0x1004aac: ldur            x0, [fp, #-0x18]
    // 0x1004ab0: StoreField: r1->field_b = r0
    //     0x1004ab0: stur            w0, [x1, #0xb]
    // 0x1004ab4: mov             x0, x1
    // 0x1004ab8: r0 = Throw()
    //     0x1004ab8: bl              #0x13ddb2c  ; ThrowStub
    // 0x1004abc: brk             #0
    // 0x1004ac0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1004ac0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1004ac4: b               #0x1004968
    // 0x1004ac8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1004ac8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x1004acc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1004acc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _urlFromKey(/* No info */) {
    // ** addr: 0x100505c, size: 0x54
    // 0x100505c: EnterFrame
    //     0x100505c: stp             fp, lr, [SP, #-0x10]!
    //     0x1005060: mov             fp, SP
    // 0x1005064: CheckStackOverflow
    //     0x1005064: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1005068: cmp             SP, x16
    //     0x100506c: b.ls            #0x10050a8
    // 0x1005070: LoadField: r0 = r1->field_7
    //     0x1005070: ldur            w0, [x1, #7]
    // 0x1005074: DecompressPointer r0
    //     0x1005074: add             x0, x0, HEAP, lsl #32
    // 0x1005078: r1 = LoadClassIdInstr(r0)
    //     0x1005078: ldur            x1, [x0, #-1]
    //     0x100507c: ubfx            x1, x1, #0xc, #0x14
    // 0x1005080: mov             x16, x0
    // 0x1005084: mov             x0, x1
    // 0x1005088: mov             x1, x16
    // 0x100508c: r2 = ""
    //     0x100508c: ldr             x2, [PP, #0x900]  ; [pp+0x900] ""
    // 0x1005090: r0 = GDT[cid_x0 + -0xe5c]()
    //     0x1005090: sub             lr, x0, #0xe5c
    //     0x1005094: ldr             lr, [x21, lr, lsl #3]
    //     0x1005098: blr             lr
    // 0x100509c: LeaveFrame
    //     0x100509c: mov             SP, fp
    //     0x10050a0: ldp             fp, lr, [SP], #0x10
    // 0x10050a4: ret
    //     0x10050a4: ret             
    // 0x10050a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10050a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10050ac: b               #0x1005070
  }
}
