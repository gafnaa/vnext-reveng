// lib: , url: package:flutter/src/services/raw_keyboard.dart

// class id: 1049086, size: 0x8
class :: {
}

// class id: 2753, size: 0x10, field offset: 0x8
//   const constructor, 
class _ModifierSidePair extends Object {

  ModifierKey field_8;
  KeyboardSide field_c;

  _ ==(/* No info */) {
    // ** addr: 0x129aeb8, size: 0xec
    // 0x129aeb8: EnterFrame
    //     0x129aeb8: stp             fp, lr, [SP, #-0x10]!
    //     0x129aebc: mov             fp, SP
    // 0x129aec0: AllocStack(0x10)
    //     0x129aec0: sub             SP, SP, #0x10
    // 0x129aec4: CheckStackOverflow
    //     0x129aec4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x129aec8: cmp             SP, x16
    //     0x129aecc: b.ls            #0x129af9c
    // 0x129aed0: ldr             x0, [fp, #0x10]
    // 0x129aed4: cmp             w0, NULL
    // 0x129aed8: b.ne            #0x129aeec
    // 0x129aedc: r0 = false
    //     0x129aedc: add             x0, NULL, #0x30  ; false
    // 0x129aee0: LeaveFrame
    //     0x129aee0: mov             SP, fp
    //     0x129aee4: ldp             fp, lr, [SP], #0x10
    // 0x129aee8: ret
    //     0x129aee8: ret             
    // 0x129aeec: str             x0, [SP]
    // 0x129aef0: r0 = runtimeType()
    //     0x129aef0: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x129aef4: r1 = LoadClassIdInstr(r0)
    //     0x129aef4: ldur            x1, [x0, #-1]
    //     0x129aef8: ubfx            x1, x1, #0xc, #0x14
    // 0x129aefc: r16 = _ModifierSidePair
    //     0x129aefc: add             x16, PP, #0xe, lsl #12  ; [pp+0xe098] Type: _ModifierSidePair
    //     0x129af00: ldr             x16, [x16, #0x98]
    // 0x129af04: stp             x16, x0, [SP]
    // 0x129af08: mov             x0, x1
    // 0x129af0c: mov             lr, x0
    // 0x129af10: ldr             lr, [x21, lr, lsl #3]
    // 0x129af14: blr             lr
    // 0x129af18: tbz             w0, #4, #0x129af2c
    // 0x129af1c: r0 = false
    //     0x129af1c: add             x0, NULL, #0x30  ; false
    // 0x129af20: LeaveFrame
    //     0x129af20: mov             SP, fp
    //     0x129af24: ldp             fp, lr, [SP], #0x10
    // 0x129af28: ret
    //     0x129af28: ret             
    // 0x129af2c: ldr             x1, [fp, #0x10]
    // 0x129af30: r2 = 60
    //     0x129af30: mov             x2, #0x3c
    // 0x129af34: branchIfSmi(r1, 0x129af40)
    //     0x129af34: tbz             w1, #0, #0x129af40
    // 0x129af38: r2 = LoadClassIdInstr(r1)
    //     0x129af38: ldur            x2, [x1, #-1]
    //     0x129af3c: ubfx            x2, x2, #0xc, #0x14
    // 0x129af40: cmp             x2, #0xac1
    // 0x129af44: b.ne            #0x129af8c
    // 0x129af48: ldr             x2, [fp, #0x18]
    // 0x129af4c: LoadField: r3 = r1->field_7
    //     0x129af4c: ldur            w3, [x1, #7]
    // 0x129af50: DecompressPointer r3
    //     0x129af50: add             x3, x3, HEAP, lsl #32
    // 0x129af54: LoadField: r4 = r2->field_7
    //     0x129af54: ldur            w4, [x2, #7]
    // 0x129af58: DecompressPointer r4
    //     0x129af58: add             x4, x4, HEAP, lsl #32
    // 0x129af5c: cmp             w3, w4
    // 0x129af60: b.ne            #0x129af8c
    // 0x129af64: LoadField: r3 = r1->field_b
    //     0x129af64: ldur            w3, [x1, #0xb]
    // 0x129af68: DecompressPointer r3
    //     0x129af68: add             x3, x3, HEAP, lsl #32
    // 0x129af6c: LoadField: r1 = r2->field_b
    //     0x129af6c: ldur            w1, [x2, #0xb]
    // 0x129af70: DecompressPointer r1
    //     0x129af70: add             x1, x1, HEAP, lsl #32
    // 0x129af74: cmp             w3, w1
    // 0x129af78: r16 = true
    //     0x129af78: add             x16, NULL, #0x20  ; true
    // 0x129af7c: r17 = false
    //     0x129af7c: add             x17, NULL, #0x30  ; false
    // 0x129af80: csel            x2, x16, x17, eq
    // 0x129af84: mov             x0, x2
    // 0x129af88: b               #0x129af90
    // 0x129af8c: r0 = false
    //     0x129af8c: add             x0, NULL, #0x30  ; false
    // 0x129af90: LeaveFrame
    //     0x129af90: mov             SP, fp
    //     0x129af94: ldp             fp, lr, [SP], #0x10
    // 0x129af98: ret
    //     0x129af98: ret             
    // 0x129af9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x129af9c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x129afa0: b               #0x129aed0
  }
}

// class id: 2754, size: 0x10, field offset: 0x8
class RawKeyboard extends Object {

  static late final RawKeyboard instance; // offset: 0x814
  static late final Map<_ModifierSidePair, Set<PhysicalKeyboardKey>> _modifierKeyMap; // offset: 0x818
  static late final Map<PhysicalKeyboardKey, LogicalKeyboardKey> _allModifiers; // offset: 0x820
  static late final Map<PhysicalKeyboardKey, LogicalKeyboardKey> _allModifiersExceptFn; // offset: 0x81c

  _ handleRawKeyEvent(/* No info */) {
    // ** addr: 0x84a8fc, size: 0x3a0
    // 0x84a8fc: EnterFrame
    //     0x84a8fc: stp             fp, lr, [SP, #-0x10]!
    //     0x84a900: mov             fp, SP
    // 0x84a904: AllocStack(0xd0)
    //     0x84a904: sub             SP, SP, #0xd0
    // 0x84a908: SetupParameters(RawKeyboard this /* r1 => r3, fp-0x80 */, dynamic _ /* r2 => r2, fp-0x88 */)
    //     0x84a908: mov             x3, x1
    //     0x84a90c: stur            x1, [fp, #-0x80]
    //     0x84a910: stur            x2, [fp, #-0x88]
    // 0x84a914: CheckStackOverflow
    //     0x84a914: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84a918: cmp             SP, x16
    //     0x84a91c: b.ls            #0x84ac88
    // 0x84a920: r0 = LoadClassIdInstr(r2)
    //     0x84a920: ldur            x0, [x2, #-1]
    //     0x84a924: ubfx            x0, x0, #0xc, #0x14
    // 0x84a928: r17 = 5017
    //     0x84a928: mov             x17, #0x1399
    // 0x84a92c: cmp             x0, x17
    // 0x84a930: b.ne            #0x84a9f0
    // 0x84a934: LoadField: r4 = r3->field_b
    //     0x84a934: ldur            w4, [x3, #0xb]
    // 0x84a938: DecompressPointer r4
    //     0x84a938: add             x4, x4, HEAP, lsl #32
    // 0x84a93c: stur            x4, [fp, #-0x78]
    // 0x84a940: LoadField: r5 = r2->field_b
    //     0x84a940: ldur            w5, [x2, #0xb]
    // 0x84a944: DecompressPointer r5
    //     0x84a944: add             x5, x5, HEAP, lsl #32
    // 0x84a948: stur            x5, [fp, #-0x70]
    // 0x84a94c: r0 = LoadClassIdInstr(r5)
    //     0x84a94c: ldur            x0, [x5, #-1]
    //     0x84a950: ubfx            x0, x0, #0xc, #0x14
    // 0x84a954: mov             x1, x5
    // 0x84a958: r0 = GDT[cid_x0 + 0x6c3b]()
    //     0x84a958: mov             x17, #0x6c3b
    //     0x84a95c: add             lr, x0, x17
    //     0x84a960: ldr             lr, [x21, lr, lsl #3]
    //     0x84a964: blr             lr
    // 0x84a968: mov             x2, x0
    // 0x84a96c: ldur            x1, [fp, #-0x70]
    // 0x84a970: stur            x2, [fp, #-0x90]
    // 0x84a974: r0 = LoadClassIdInstr(r1)
    //     0x84a974: ldur            x0, [x1, #-1]
    //     0x84a978: ubfx            x0, x0, #0xc, #0x14
    // 0x84a97c: r0 = GDT[cid_x0 + 0x6f8c]()
    //     0x84a97c: mov             x17, #0x6f8c
    //     0x84a980: add             lr, x0, x17
    //     0x84a984: ldr             lr, [x21, lr, lsl #3]
    //     0x84a988: blr             lr
    // 0x84a98c: mov             x3, x0
    // 0x84a990: ldur            x2, [fp, #-0x90]
    // 0x84a994: stur            x3, [fp, #-0x70]
    // 0x84a998: LoadField: r4 = r2->field_7
    //     0x84a998: ldur            x4, [x2, #7]
    // 0x84a99c: r0 = BoxInt64Instr(r4)
    //     0x84a99c: sbfiz           x0, x4, #1, #0x1f
    //     0x84a9a0: cmp             x4, x0, asr #1
    //     0x84a9a4: b.eq            #0x84a9b0
    //     0x84a9a8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x84a9ac: stur            x4, [x0, #7]
    // 0x84a9b0: r1 = 60
    //     0x84a9b0: mov             x1, #0x3c
    // 0x84a9b4: branchIfSmi(r0, 0x84a9c0)
    //     0x84a9b4: tbz             w0, #0, #0x84a9c0
    // 0x84a9b8: r1 = LoadClassIdInstr(r0)
    //     0x84a9b8: ldur            x1, [x0, #-1]
    //     0x84a9bc: ubfx            x1, x1, #0xc, #0x14
    // 0x84a9c0: str             x0, [SP]
    // 0x84a9c4: mov             x0, x1
    // 0x84a9c8: r0 = GDT[cid_x0 + 0x70de]()
    //     0x84a9c8: mov             x17, #0x70de
    //     0x84a9cc: add             lr, x0, x17
    //     0x84a9d0: ldr             lr, [x21, lr, lsl #3]
    //     0x84a9d4: blr             lr
    // 0x84a9d8: ldur            x1, [fp, #-0x78]
    // 0x84a9dc: ldur            x2, [fp, #-0x90]
    // 0x84a9e0: ldur            x3, [fp, #-0x70]
    // 0x84a9e4: mov             x5, x0
    // 0x84a9e8: r0 = _set()
    //     0x84a9e8: bl              #0x13d8170  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x84a9ec: b               #0x84aa3c
    // 0x84a9f0: r17 = 5016
    //     0x84a9f0: mov             x17, #0x1398
    // 0x84a9f4: cmp             x0, x17
    // 0x84a9f8: b.ne            #0x84aa3c
    // 0x84a9fc: ldur            x3, [fp, #-0x80]
    // 0x84aa00: ldur            x2, [fp, #-0x88]
    // 0x84aa04: LoadField: r4 = r3->field_b
    //     0x84aa04: ldur            w4, [x3, #0xb]
    // 0x84aa08: DecompressPointer r4
    //     0x84aa08: add             x4, x4, HEAP, lsl #32
    // 0x84aa0c: stur            x4, [fp, #-0x70]
    // 0x84aa10: LoadField: r1 = r2->field_b
    //     0x84aa10: ldur            w1, [x2, #0xb]
    // 0x84aa14: DecompressPointer r1
    //     0x84aa14: add             x1, x1, HEAP, lsl #32
    // 0x84aa18: r0 = LoadClassIdInstr(r1)
    //     0x84aa18: ldur            x0, [x1, #-1]
    //     0x84aa1c: ubfx            x0, x0, #0xc, #0x14
    // 0x84aa20: r0 = GDT[cid_x0 + 0x6c3b]()
    //     0x84aa20: mov             x17, #0x6c3b
    //     0x84aa24: add             lr, x0, x17
    //     0x84aa28: ldr             lr, [x21, lr, lsl #3]
    //     0x84aa2c: blr             lr
    // 0x84aa30: ldur            x1, [fp, #-0x70]
    // 0x84aa34: mov             x2, x0
    // 0x84aa38: r0 = remove()
    //     0x84aa38: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x84aa3c: ldur            x0, [fp, #-0x80]
    // 0x84aa40: mov             x1, x0
    // 0x84aa44: ldur            x2, [fp, #-0x88]
    // 0x84aa48: r0 = _synchronizeModifiers()
    //     0x84aa48: bl              #0x84acf0  ; [package:flutter/src/services/raw_keyboard.dart] RawKeyboard::_synchronizeModifiers
    // 0x84aa4c: ldur            x0, [fp, #-0x80]
    // 0x84aa50: LoadField: r3 = r0->field_7
    //     0x84aa50: ldur            w3, [x0, #7]
    // 0x84aa54: DecompressPointer r3
    //     0x84aa54: add             x3, x3, HEAP, lsl #32
    // 0x84aa58: mov             x2, x3
    // 0x84aa5c: stur            x3, [fp, #-0x70]
    // 0x84aa60: r1 = <(dynamic this, RawKeyEvent) => void?>
    //     0x84aa60: ldr             x1, [PP, #0x3b20]  ; [pp+0x3b20] TypeArguments: <(dynamic this, RawKeyEvent) => void?>
    // 0x84aa64: r0 = _GrowableList._ofGrowableList()
    //     0x84aa64: bl              #0x7d7558  ; [dart:core] _GrowableList::_GrowableList._ofGrowableList
    // 0x84aa68: stur            x0, [fp, #-0x90]
    // 0x84aa6c: LoadField: r2 = r0->field_7
    //     0x84aa6c: ldur            w2, [x0, #7]
    // 0x84aa70: DecompressPointer r2
    //     0x84aa70: add             x2, x2, HEAP, lsl #32
    // 0x84aa74: mov             x1, x2
    // 0x84aa78: stur            x2, [fp, #-0x78]
    // 0x84aa7c: r0 = ListIterator()
    //     0x84aa7c: bl              #0x830f24  ; AllocateListIteratorStub -> ListIterator<X0> (size=0x24)
    // 0x84aa80: mov             x4, x0
    // 0x84aa84: ldur            x3, [fp, #-0x90]
    // 0x84aa88: stur            x4, [fp, #-0xb8]
    // 0x84aa8c: StoreField: r4->field_b = r3
    //     0x84aa8c: stur            w3, [x4, #0xb]
    // 0x84aa90: LoadField: r0 = r3->field_b
    //     0x84aa90: ldur            w0, [x3, #0xb]
    // 0x84aa94: r5 = LoadInt32Instr(r0)
    //     0x84aa94: sbfx            x5, x0, #1, #0x1f
    // 0x84aa98: stur            x5, [fp, #-0xb0]
    // 0x84aa9c: StoreField: r4->field_f = r5
    //     0x84aa9c: stur            x5, [x4, #0xf]
    // 0x84aaa0: ArrayStore: r4[0] = rZR  ; List_8
    //     0x84aaa0: stur            xzr, [x4, #0x17]
    // 0x84aaa4: r7 = Null
    //     0x84aaa4: mov             x7, NULL
    // 0x84aaa8: r6 = Null
    //     0x84aaa8: mov             x6, NULL
    // 0x84aaac: stur            x7, [fp, #-0xa0]
    // 0x84aab0: stur            x6, [fp, #-0xa8]
    // 0x84aab4: CheckStackOverflow
    //     0x84aab4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84aab8: cmp             SP, x16
    //     0x84aabc: b.ls            #0x84ac90
    // 0x84aac0: LoadField: r0 = r3->field_b
    //     0x84aac0: ldur            w0, [x3, #0xb]
    // 0x84aac4: r1 = LoadInt32Instr(r0)
    //     0x84aac4: sbfx            x1, x0, #1, #0x1f
    // 0x84aac8: cmp             x5, x1
    // 0x84aacc: b.ne            #0x84ac68
    // 0x84aad0: ArrayLoad: r2 = r4[0]  ; List_8
    //     0x84aad0: ldur            x2, [x4, #0x17]
    // 0x84aad4: cmp             x2, x1
    // 0x84aad8: b.ge            #0x84ac50
    // 0x84aadc: mov             x0, x1
    // 0x84aae0: mov             x1, x2
    // 0x84aae4: cmp             x1, x0
    // 0x84aae8: b.hs            #0x84ac98
    // 0x84aaec: LoadField: r0 = r3->field_f
    //     0x84aaec: ldur            w0, [x3, #0xf]
    // 0x84aaf0: DecompressPointer r0
    //     0x84aaf0: add             x0, x0, HEAP, lsl #32
    // 0x84aaf4: ArrayLoad: r8 = r0[r2]  ; Unknown_4
    //     0x84aaf4: add             x16, x0, x2, lsl #2
    //     0x84aaf8: ldur            w8, [x16, #0xf]
    // 0x84aafc: DecompressPointer r8
    //     0x84aafc: add             x8, x8, HEAP, lsl #32
    // 0x84ab00: mov             x0, x8
    // 0x84ab04: stur            x8, [fp, #-0x98]
    // 0x84ab08: StoreField: r4->field_1f = r0
    //     0x84ab08: stur            w0, [x4, #0x1f]
    //     0x84ab0c: tbz             w0, #0, #0x84ab28
    //     0x84ab10: ldurb           w16, [x4, #-1]
    //     0x84ab14: ldurb           w17, [x0, #-1]
    //     0x84ab18: and             x16, x17, x16, lsr #2
    //     0x84ab1c: tst             x16, HEAP, lsr #32
    //     0x84ab20: b.eq            #0x84ab28
    //     0x84ab24: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0x84ab28: add             x0, x2, #1
    // 0x84ab2c: ArrayStore: r4[0] = r0  ; List_8
    //     0x84ab2c: stur            x0, [x4, #0x17]
    // 0x84ab30: cmp             w8, NULL
    // 0x84ab34: b.ne            #0x84ab64
    // 0x84ab38: mov             x0, x8
    // 0x84ab3c: ldur            x2, [fp, #-0x78]
    // 0x84ab40: r1 = Null
    //     0x84ab40: mov             x1, NULL
    // 0x84ab44: cmp             w2, NULL
    // 0x84ab48: b.eq            #0x84ab64
    // 0x84ab4c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x84ab4c: ldur            w4, [x2, #0x17]
    // 0x84ab50: DecompressPointer r4
    //     0x84ab50: add             x4, x4, HEAP, lsl #32
    // 0x84ab54: r8 = X0
    //     0x84ab54: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x84ab58: LoadField: r9 = r4->field_7
    //     0x84ab58: ldur            x9, [x4, #7]
    // 0x84ab5c: r3 = Null
    //     0x84ab5c: ldr             x3, [PP, #0x3b28]  ; [pp+0x3b28] Null
    // 0x84ab60: blr             x9
    // 0x84ab64: ldur            x1, [fp, #-0x70]
    // 0x84ab68: ldur            x2, [fp, #-0x98]
    // 0x84ab6c: r0 = contains()
    //     0x84ab6c: bl              #0xbaf414  ; [dart:collection] ListBase::contains
    // 0x84ab70: tbnz            w0, #4, #0x84ab90
    // 0x84ab74: ldur            x16, [fp, #-0x98]
    // 0x84ab78: ldur            lr, [fp, #-0x88]
    // 0x84ab7c: stp             lr, x16, [SP]
    // 0x84ab80: ldur            x0, [fp, #-0x98]
    // 0x84ab84: ClosureCall
    //     0x84ab84: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x84ab88: ldur            x2, [x0, #0x1f]
    //     0x84ab8c: blr             x2
    // 0x84ab90: ldur            x7, [fp, #-0xa0]
    // 0x84ab94: ldur            x6, [fp, #-0xa8]
    // 0x84ab98: b               #0x84ac40
    // 0x84ab9c: sub             SP, fp, #0xd0
    // 0x84aba0: mov             x2, x0
    // 0x84aba4: stur            x0, [fp, #-0x98]
    // 0x84aba8: mov             x0, x1
    // 0x84abac: stur            x1, [fp, #-0xa0]
    // 0x84abb0: r1 = <List<Object>>
    //     0x84abb0: ldr             x1, [PP, #0x860]  ; [pp+0x860] TypeArguments: <List<Object>>
    // 0x84abb4: r0 = ErrorDescription()
    //     0x84abb4: bl              #0x829ca4  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x2c)
    // 0x84abb8: mov             x1, x0
    // 0x84abbc: r2 = "while processing a raw key listener"
    //     0x84abbc: ldr             x2, [PP, #0x3b38]  ; [pp+0x3b38] "while processing a raw key listener"
    // 0x84abc0: r3 = Instance_DiagnosticLevel
    //     0x84abc0: ldr             x3, [PP, #0x868]  ; [pp+0x868] Obj!DiagnosticLevel@12c5f41
    // 0x84abc4: stur            x0, [fp, #-0xa8]
    // 0x84abc8: r0 = _ErrorDiagnostic()
    //     0x84abc8: bl              #0x829bec  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0x84abcc: r0 = FlutterErrorDetails()
    //     0x84abcc: bl              #0x829be0  ; AllocateFlutterErrorDetailsStub -> FlutterErrorDetails (size=0x20)
    // 0x84abd0: mov             x1, x0
    // 0x84abd4: ldur            x0, [fp, #-0x98]
    // 0x84abd8: stur            x1, [fp, #-0xc0]
    // 0x84abdc: StoreField: r1->field_7 = r0
    //     0x84abdc: stur            w0, [x1, #7]
    // 0x84abe0: ldur            x2, [fp, #-0xa0]
    // 0x84abe4: StoreField: r1->field_b = r2
    //     0x84abe4: stur            w2, [x1, #0xb]
    // 0x84abe8: r3 = "services library"
    //     0x84abe8: ldr             x3, [PP, #0x870]  ; [pp+0x870] "services library"
    // 0x84abec: StoreField: r1->field_f = r3
    //     0x84abec: stur            w3, [x1, #0xf]
    // 0x84abf0: ldur            x4, [fp, #-0xa8]
    // 0x84abf4: StoreField: r1->field_13 = r4
    //     0x84abf4: stur            w4, [x1, #0x13]
    // 0x84abf8: r4 = false
    //     0x84abf8: add             x4, NULL, #0x30  ; false
    // 0x84abfc: StoreField: r1->field_1b = r4
    //     0x84abfc: stur            w4, [x1, #0x1b]
    // 0x84ac00: r0 = LoadStaticField(0x46c)
    //     0x84ac00: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x84ac04: ldr             x0, [x0, #0x8d8]
    // 0x84ac08: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84ac0c: cmp             w0, w16
    // 0x84ac10: b.ne            #0x84ac1c
    // 0x84ac14: r2 = onError
    //     0x84ac14: ldr             x2, [PP, #0x878]  ; [pp+0x878] Field <FlutterError.onError>: static late (offset: 0x46c)
    // 0x84ac18: r0 = InitLateStaticField()
    //     0x84ac18: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0x84ac1c: cmp             w0, NULL
    // 0x84ac20: b.eq            #0x84ac38
    // 0x84ac24: ldur            x16, [fp, #-0xc0]
    // 0x84ac28: stp             x16, x0, [SP]
    // 0x84ac2c: ClosureCall
    //     0x84ac2c: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x84ac30: ldur            x2, [x0, #0x1f]
    //     0x84ac34: blr             x2
    // 0x84ac38: ldur            x7, [fp, #-0xa0]
    // 0x84ac3c: ldur            x6, [fp, #-0x98]
    // 0x84ac40: ldur            x4, [fp, #-0xb8]
    // 0x84ac44: ldur            x3, [fp, #-0x90]
    // 0x84ac48: ldur            x5, [fp, #-0xb0]
    // 0x84ac4c: b               #0x84aaac
    // 0x84ac50: mov             x0, x4
    // 0x84ac54: StoreField: r0->field_1f = rNULL
    //     0x84ac54: stur            NULL, [x0, #0x1f]
    // 0x84ac58: r0 = false
    //     0x84ac58: add             x0, NULL, #0x30  ; false
    // 0x84ac5c: LeaveFrame
    //     0x84ac5c: mov             SP, fp
    //     0x84ac60: ldp             fp, lr, [SP], #0x10
    // 0x84ac64: ret
    //     0x84ac64: ret             
    // 0x84ac68: mov             x0, x3
    // 0x84ac6c: r0 = ConcurrentModificationError()
    //     0x84ac6c: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x84ac70: mov             x1, x0
    // 0x84ac74: ldur            x0, [fp, #-0x90]
    // 0x84ac78: StoreField: r1->field_b = r0
    //     0x84ac78: stur            w0, [x1, #0xb]
    // 0x84ac7c: mov             x0, x1
    // 0x84ac80: r0 = Throw()
    //     0x84ac80: bl              #0x13ddb2c  ; ThrowStub
    // 0x84ac84: brk             #0
    // 0x84ac88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84ac88: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84ac8c: b               #0x84a920
    // 0x84ac90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84ac90: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84ac94: b               #0x84aac0
    // 0x84ac98: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x84ac98: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _synchronizeModifiers(/* No info */) {
    // ** addr: 0x84acf0, size: 0xa3c
    // 0x84acf0: EnterFrame
    //     0x84acf0: stp             fp, lr, [SP, #-0x10]!
    //     0x84acf4: mov             fp, SP
    // 0x84acf8: AllocStack(0x80)
    //     0x84acf8: sub             SP, SP, #0x80
    // 0x84acfc: SetupParameters(RawKeyboard this /* r1 => r0, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0x84acfc: mov             x0, x1
    //     0x84ad00: stur            x1, [fp, #-0x10]
    //     0x84ad04: stur            x2, [fp, #-0x18]
    // 0x84ad08: CheckStackOverflow
    //     0x84ad08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84ad0c: cmp             SP, x16
    //     0x84ad10: b.ls            #0x84b708
    // 0x84ad14: LoadField: r3 = r2->field_b
    //     0x84ad14: ldur            w3, [x2, #0xb]
    // 0x84ad18: DecompressPointer r3
    //     0x84ad18: add             x3, x3, HEAP, lsl #32
    // 0x84ad1c: mov             x1, x3
    // 0x84ad20: stur            x3, [fp, #-8]
    // 0x84ad24: r0 = modifiersPressed()
    //     0x84ad24: bl              #0x84c538  ; [package:flutter/src/services/raw_keyboard.dart] RawKeyEventData::modifiersPressed
    // 0x84ad28: stur            x0, [fp, #-0x20]
    // 0x84ad2c: r16 = <PhysicalKeyboardKey, LogicalKeyboardKey>
    //     0x84ad2c: ldr             x16, [PP, #0x3aa0]  ; [pp+0x3aa0] TypeArguments: <PhysicalKeyboardKey, LogicalKeyboardKey>
    // 0x84ad30: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x84ad34: stp             lr, x16, [SP]
    // 0x84ad38: r0 = Map._fromLiteral()
    //     0x84ad38: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x84ad3c: r1 = <PhysicalKeyboardKey>
    //     0x84ad3c: ldr             x1, [PP, #0x3b40]  ; [pp+0x3b40] TypeArguments: <PhysicalKeyboardKey>
    // 0x84ad40: stur            x0, [fp, #-0x28]
    // 0x84ad44: r0 = _Set()
    //     0x84ad44: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x84ad48: mov             x2, x0
    // 0x84ad4c: r0 = _Uint32List
    //     0x84ad4c: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0x84ad50: stur            x2, [fp, #-0x38]
    // 0x84ad54: StoreField: r2->field_1b = r0
    //     0x84ad54: stur            w0, [x2, #0x1b]
    // 0x84ad58: StoreField: r2->field_b = rZR
    //     0x84ad58: stur            wzr, [x2, #0xb]
    // 0x84ad5c: r3 = const []
    //     0x84ad5c: ldr             x3, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0x84ad60: StoreField: r2->field_f = r3
    //     0x84ad60: stur            w3, [x2, #0xf]
    // 0x84ad64: StoreField: r2->field_13 = rZR
    //     0x84ad64: stur            wzr, [x2, #0x13]
    // 0x84ad68: ArrayStore: r2[0] = rZR  ; List_4
    //     0x84ad68: stur            wzr, [x2, #0x17]
    // 0x84ad6c: ldur            x1, [fp, #-0x10]
    // 0x84ad70: LoadField: r4 = r1->field_b
    //     0x84ad70: ldur            w4, [x1, #0xb]
    // 0x84ad74: DecompressPointer r4
    //     0x84ad74: add             x4, x4, HEAP, lsl #32
    // 0x84ad78: stur            x4, [fp, #-0x30]
    // 0x84ad7c: r1 = <PhysicalKeyboardKey, LogicalKeyboardKey>
    //     0x84ad7c: ldr             x1, [PP, #0x3aa0]  ; [pp+0x3aa0] TypeArguments: <PhysicalKeyboardKey, LogicalKeyboardKey>
    // 0x84ad80: r0 = _CompactKeysIterable()
    //     0x84ad80: bl              #0x8353d0  ; Allocate_CompactKeysIterableStub -> _CompactKeysIterable<X0> (size=0x10)
    // 0x84ad84: mov             x1, x0
    // 0x84ad88: ldur            x0, [fp, #-0x30]
    // 0x84ad8c: StoreField: r1->field_b = r0
    //     0x84ad8c: stur            w0, [x1, #0xb]
    // 0x84ad90: mov             x2, x1
    // 0x84ad94: r1 = <PhysicalKeyboardKey>
    //     0x84ad94: ldr             x1, [PP, #0x3b40]  ; [pp+0x3b40] TypeArguments: <PhysicalKeyboardKey>
    // 0x84ad98: r0 = LinkedHashSet.of()
    //     0x84ad98: bl              #0x83a460  ; [dart:collection] LinkedHashSet::LinkedHashSet.of
    // 0x84ad9c: mov             x2, x0
    // 0x84ada0: ldur            x0, [fp, #-0x18]
    // 0x84ada4: stur            x2, [fp, #-0x10]
    // 0x84ada8: r3 = LoadClassIdInstr(r0)
    //     0x84ada8: ldur            x3, [x0, #-1]
    //     0x84adac: ubfx            x3, x3, #0xc, #0x14
    // 0x84adb0: stur            x3, [fp, #-0x40]
    // 0x84adb4: r17 = 5017
    //     0x84adb4: mov             x17, #0x1399
    // 0x84adb8: cmp             x3, x17
    // 0x84adbc: b.ne            #0x84adec
    // 0x84adc0: ldur            x4, [fp, #-8]
    // 0x84adc4: r0 = LoadClassIdInstr(r4)
    //     0x84adc4: ldur            x0, [x4, #-1]
    //     0x84adc8: ubfx            x0, x0, #0xc, #0x14
    // 0x84adcc: mov             x1, x4
    // 0x84add0: r0 = GDT[cid_x0 + 0x6c3b]()
    //     0x84add0: mov             x17, #0x6c3b
    //     0x84add4: add             lr, x0, x17
    //     0x84add8: ldr             lr, [x21, lr, lsl #3]
    //     0x84addc: blr             lr
    // 0x84ade0: ldur            x1, [fp, #-0x10]
    // 0x84ade4: mov             x2, x0
    // 0x84ade8: r0 = add()
    //     0x84ade8: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x84adec: ldur            x2, [fp, #-0x10]
    // 0x84adf0: r1 = Function 'contains':.
    //     0x84adf0: ldr             x1, [PP, #0x3b48]  ; [pp+0x3b48] AnonymousClosure: (0x83d9e8), in [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains (0xbafbf4)
    // 0x84adf4: r0 = AllocateClosure()
    //     0x84adf4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x84adf8: stur            x0, [fp, #-0x50]
    // 0x84adfc: r6 = Null
    //     0x84adfc: mov             x6, NULL
    // 0x84ae00: r5 = 0
    //     0x84ae00: mov             x5, #0
    // 0x84ae04: ldur            x1, [fp, #-8]
    // 0x84ae08: ldur            x3, [fp, #-0x20]
    // 0x84ae0c: ldur            x2, [fp, #-0x38]
    // 0x84ae10: r4 = const [Instance of 'ModifierKey', Instance of 'ModifierKey', Instance of 'ModifierKey', Instance of 'ModifierKey', Instance of 'ModifierKey', Instance of 'ModifierKey', Instance of 'ModifierKey', Instance of 'ModifierKey', Instance of 'ModifierKey']
    //     0x84ae10: ldr             x4, [PP, #0x3b50]  ; [pp+0x3b50] List<ModifierKey>(9)
    // 0x84ae14: stur            x6, [fp, #-0x18]
    // 0x84ae18: CheckStackOverflow
    //     0x84ae18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84ae1c: cmp             SP, x16
    //     0x84ae20: b.ls            #0x84b710
    // 0x84ae24: cmp             x5, #9
    // 0x84ae28: b.ge            #0x84b22c
    // 0x84ae2c: ArrayLoad: r7 = r4[r5]  ; Unknown_4
    //     0x84ae2c: add             x16, x4, x5, lsl #2
    //     0x84ae30: ldur            w7, [x16, #0xf]
    // 0x84ae34: DecompressPointer r7
    //     0x84ae34: add             x7, x7, HEAP, lsl #32
    // 0x84ae38: stur            x7, [fp, #-0x10]
    // 0x84ae3c: add             x8, x5, #1
    // 0x84ae40: stur            x8, [fp, #-0x48]
    // 0x84ae44: r0 = LoadStaticField(0x818)
    //     0x84ae44: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x84ae48: ldr             x0, [x0, #0x1030]
    // 0x84ae4c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84ae50: cmp             w0, w16
    // 0x84ae54: b.ne            #0x84ae60
    // 0x84ae58: r2 = _modifierKeyMap
    //     0x84ae58: ldr             x2, [PP, #0x3b58]  ; [pp+0x3b58] Field <RawKeyboard._modifierKeyMap@168461389>: static late final (offset: 0x818)
    // 0x84ae5c: r0 = InitLateFinalStaticField()
    //     0x84ae5c: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x84ae60: stur            x0, [fp, #-0x58]
    // 0x84ae64: r0 = _ModifierSidePair()
    //     0x84ae64: bl              #0x84c50c  ; Allocate_ModifierSidePairStub -> _ModifierSidePair (size=0x10)
    // 0x84ae68: mov             x1, x0
    // 0x84ae6c: ldur            x0, [fp, #-0x10]
    // 0x84ae70: StoreField: r1->field_7 = r0
    //     0x84ae70: stur            w0, [x1, #7]
    // 0x84ae74: r3 = Instance_KeyboardSide
    //     0x84ae74: ldr             x3, [PP, #0x3b60]  ; [pp+0x3b60] Obj!KeyboardSide@12c3cc1
    // 0x84ae78: StoreField: r1->field_b = r3
    //     0x84ae78: stur            w3, [x1, #0xb]
    // 0x84ae7c: mov             x2, x1
    // 0x84ae80: ldur            x1, [fp, #-0x58]
    // 0x84ae84: r0 = _getValueOrData()
    //     0x84ae84: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x84ae88: ldur            x2, [fp, #-0x58]
    // 0x84ae8c: LoadField: r1 = r2->field_f
    //     0x84ae8c: ldur            w1, [x2, #0xf]
    // 0x84ae90: DecompressPointer r1
    //     0x84ae90: add             x1, x1, HEAP, lsl #32
    // 0x84ae94: cmp             w1, w0
    // 0x84ae98: b.ne            #0x84aea4
    // 0x84ae9c: r3 = Null
    //     0x84ae9c: mov             x3, NULL
    // 0x84aea0: b               #0x84aea8
    // 0x84aea4: mov             x3, x0
    // 0x84aea8: stur            x3, [fp, #-0x60]
    // 0x84aeac: cmp             w3, NULL
    // 0x84aeb0: b.ne            #0x84aebc
    // 0x84aeb4: ldur            x6, [fp, #-0x18]
    // 0x84aeb8: b               #0x84b220
    // 0x84aebc: ldur            x4, [fp, #-8]
    // 0x84aec0: r0 = LoadClassIdInstr(r4)
    //     0x84aec0: ldur            x0, [x4, #-1]
    //     0x84aec4: ubfx            x0, x0, #0xc, #0x14
    // 0x84aec8: mov             x1, x4
    // 0x84aecc: r0 = GDT[cid_x0 + 0x6c3b]()
    //     0x84aecc: mov             x17, #0x6c3b
    //     0x84aed0: add             lr, x0, x17
    //     0x84aed4: ldr             lr, [x21, lr, lsl #3]
    //     0x84aed8: blr             lr
    // 0x84aedc: ldur            x3, [fp, #-0x60]
    // 0x84aee0: r1 = LoadClassIdInstr(r3)
    //     0x84aee0: ldur            x1, [x3, #-1]
    //     0x84aee4: ubfx            x1, x1, #0xc, #0x14
    // 0x84aee8: mov             x2, x0
    // 0x84aeec: mov             x0, x1
    // 0x84aef0: mov             x1, x3
    // 0x84aef4: r0 = GDT[cid_x0 + 0x12929]()
    //     0x84aef4: mov             x17, #0x2929
    //     0x84aef8: movk            x17, #1, lsl #16
    //     0x84aefc: add             lr, x0, x17
    //     0x84af00: ldr             lr, [x21, lr, lsl #3]
    //     0x84af04: blr             lr
    // 0x84af08: tbnz            w0, #4, #0x84af14
    // 0x84af0c: ldur            x3, [fp, #-0x10]
    // 0x84af10: b               #0x84af18
    // 0x84af14: ldur            x3, [fp, #-0x18]
    // 0x84af18: ldur            x0, [fp, #-0x20]
    // 0x84af1c: mov             x1, x0
    // 0x84af20: ldur            x2, [fp, #-0x10]
    // 0x84af24: stur            x3, [fp, #-0x68]
    // 0x84af28: r0 = _getValueOrData()
    //     0x84af28: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x84af2c: ldur            x3, [fp, #-0x20]
    // 0x84af30: LoadField: r1 = r3->field_f
    //     0x84af30: ldur            w1, [x3, #0xf]
    // 0x84af34: DecompressPointer r1
    //     0x84af34: add             x1, x1, HEAP, lsl #32
    // 0x84af38: cmp             w1, w0
    // 0x84af3c: b.eq            #0x84afe4
    // 0x84af40: r16 = Instance_KeyboardSide
    //     0x84af40: ldr             x16, [PP, #0x3b68]  ; [pp+0x3b68] Obj!KeyboardSide@12c3ca1
    // 0x84af44: cmp             w0, w16
    // 0x84af48: b.ne            #0x84afe4
    // 0x84af4c: ldur            x4, [fp, #-0x60]
    // 0x84af50: mov             x0, x4
    // 0x84af54: r2 = Null
    //     0x84af54: mov             x2, NULL
    // 0x84af58: r1 = Null
    //     0x84af58: mov             x1, NULL
    // 0x84af5c: r8 = Iterable<PhysicalKeyboardKey>
    //     0x84af5c: ldr             x8, [PP, #0x3b70]  ; [pp+0x3b70] Type: Iterable<PhysicalKeyboardKey>
    // 0x84af60: r3 = Null
    //     0x84af60: ldr             x3, [PP, #0x3b78]  ; [pp+0x3b78] Null
    // 0x84af64: r0 = Iterable<PhysicalKeyboardKey>()
    //     0x84af64: bl              #0x84c894  ; IsType_Iterable<PhysicalKeyboardKey>_Stub
    // 0x84af68: ldur            x0, [fp, #-0x60]
    // 0x84af6c: r1 = LoadClassIdInstr(r0)
    //     0x84af6c: ldur            x1, [x0, #-1]
    //     0x84af70: ubfx            x1, x1, #0xc, #0x14
    // 0x84af74: cmp             x1, #0x58
    // 0x84af78: b.ne            #0x84afa8
    // 0x84af7c: ldur            x3, [fp, #-0x38]
    // 0x84af80: LoadField: r1 = r3->field_13
    //     0x84af80: ldur            w1, [x3, #0x13]
    // 0x84af84: ArrayLoad: r2 = r3[0]  ; List_4
    //     0x84af84: ldur            w2, [x3, #0x17]
    // 0x84af88: r4 = LoadInt32Instr(r1)
    //     0x84af88: sbfx            x4, x1, #1, #0x1f
    // 0x84af8c: r1 = LoadInt32Instr(r2)
    //     0x84af8c: sbfx            x1, x2, #1, #0x1f
    // 0x84af90: sub             x2, x4, x1
    // 0x84af94: cbnz            x2, #0x84afa8
    // 0x84af98: mov             x1, x3
    // 0x84af9c: mov             x2, x0
    // 0x84afa0: r0 = _quickCopy()
    //     0x84afa0: bl              #0x84bf9c  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase::_quickCopy
    // 0x84afa4: tbz             w0, #4, #0x84afb4
    // 0x84afa8: ldur            x1, [fp, #-0x38]
    // 0x84afac: ldur            x2, [fp, #-0x60]
    // 0x84afb0: r0 = addAll()
    //     0x84afb0: bl              #0x84b954  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::addAll
    // 0x84afb4: ldur            x1, [fp, #-0x60]
    // 0x84afb8: r0 = LoadClassIdInstr(r1)
    //     0x84afb8: ldur            x0, [x1, #-1]
    //     0x84afbc: ubfx            x0, x0, #0xc, #0x14
    // 0x84afc0: ldur            x2, [fp, #-0x50]
    // 0x84afc4: r0 = GDT[cid_x0 + 0x129cb]()
    //     0x84afc4: mov             x17, #0x29cb
    //     0x84afc8: movk            x17, #1, lsl #16
    //     0x84afcc: add             lr, x0, x17
    //     0x84afd0: ldr             lr, [x21, lr, lsl #3]
    //     0x84afd4: blr             lr
    // 0x84afd8: tbnz            w0, #4, #0x84afe4
    // 0x84afdc: ldur            x6, [fp, #-0x68]
    // 0x84afe0: b               #0x84b220
    // 0x84afe4: ldur            x0, [fp, #-0x20]
    // 0x84afe8: mov             x1, x0
    // 0x84afec: ldur            x2, [fp, #-0x10]
    // 0x84aff0: r0 = _getValueOrData()
    //     0x84aff0: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x84aff4: mov             x1, x0
    // 0x84aff8: ldur            x0, [fp, #-0x20]
    // 0x84affc: LoadField: r2 = r0->field_f
    //     0x84affc: ldur            w2, [x0, #0xf]
    // 0x84b000: DecompressPointer r2
    //     0x84b000: add             x2, x2, HEAP, lsl #32
    // 0x84b004: cmp             w2, w1
    // 0x84b008: b.eq            #0x84b014
    // 0x84b00c: cmp             w1, NULL
    // 0x84b010: b.ne            #0x84b040
    // 0x84b014: r1 = <PhysicalKeyboardKey>
    //     0x84b014: ldr             x1, [PP, #0x3b40]  ; [pp+0x3b40] TypeArguments: <PhysicalKeyboardKey>
    // 0x84b018: r0 = _Set()
    //     0x84b018: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x84b01c: mov             x1, x0
    // 0x84b020: r0 = _Uint32List
    //     0x84b020: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0x84b024: StoreField: r1->field_1b = r0
    //     0x84b024: stur            w0, [x1, #0x1b]
    // 0x84b028: StoreField: r1->field_b = rZR
    //     0x84b028: stur            wzr, [x1, #0xb]
    // 0x84b02c: r3 = const []
    //     0x84b02c: ldr             x3, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0x84b030: StoreField: r1->field_f = r3
    //     0x84b030: stur            w3, [x1, #0xf]
    // 0x84b034: StoreField: r1->field_13 = rZR
    //     0x84b034: stur            wzr, [x1, #0x13]
    // 0x84b038: ArrayStore: r1[0] = rZR  ; List_4
    //     0x84b038: stur            wzr, [x1, #0x17]
    // 0x84b03c: b               #0x84b0d4
    // 0x84b040: mov             x4, x0
    // 0x84b044: r0 = _Uint32List
    //     0x84b044: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0x84b048: r3 = const []
    //     0x84b048: ldr             x3, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0x84b04c: mov             x1, x4
    // 0x84b050: ldur            x2, [fp, #-0x10]
    // 0x84b054: r0 = _getValueOrData()
    //     0x84b054: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x84b058: mov             x1, x0
    // 0x84b05c: ldur            x0, [fp, #-0x20]
    // 0x84b060: LoadField: r2 = r0->field_f
    //     0x84b060: ldur            w2, [x0, #0xf]
    // 0x84b064: DecompressPointer r2
    //     0x84b064: add             x2, x2, HEAP, lsl #32
    // 0x84b068: cmp             w2, w1
    // 0x84b06c: b.ne            #0x84b078
    // 0x84b070: r3 = Null
    //     0x84b070: mov             x3, NULL
    // 0x84b074: b               #0x84b07c
    // 0x84b078: mov             x3, x1
    // 0x84b07c: ldur            x1, [fp, #-0x58]
    // 0x84b080: ldur            x2, [fp, #-0x10]
    // 0x84b084: stur            x3, [fp, #-0x60]
    // 0x84b088: r0 = _ModifierSidePair()
    //     0x84b088: bl              #0x84c50c  ; Allocate_ModifierSidePairStub -> _ModifierSidePair (size=0x10)
    // 0x84b08c: mov             x1, x0
    // 0x84b090: ldur            x0, [fp, #-0x10]
    // 0x84b094: StoreField: r1->field_7 = r0
    //     0x84b094: stur            w0, [x1, #7]
    // 0x84b098: ldur            x0, [fp, #-0x60]
    // 0x84b09c: StoreField: r1->field_b = r0
    //     0x84b09c: stur            w0, [x1, #0xb]
    // 0x84b0a0: mov             x2, x1
    // 0x84b0a4: ldur            x1, [fp, #-0x58]
    // 0x84b0a8: r0 = _getValueOrData()
    //     0x84b0a8: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x84b0ac: mov             x1, x0
    // 0x84b0b0: ldur            x0, [fp, #-0x58]
    // 0x84b0b4: LoadField: r2 = r0->field_f
    //     0x84b0b4: ldur            w2, [x0, #0xf]
    // 0x84b0b8: DecompressPointer r2
    //     0x84b0b8: add             x2, x2, HEAP, lsl #32
    // 0x84b0bc: cmp             w2, w1
    // 0x84b0c0: b.ne            #0x84b0cc
    // 0x84b0c4: r0 = Null
    //     0x84b0c4: mov             x0, NULL
    // 0x84b0c8: b               #0x84b0d0
    // 0x84b0cc: mov             x0, x1
    // 0x84b0d0: mov             x1, x0
    // 0x84b0d4: cmp             w1, NULL
    // 0x84b0d8: b.ne            #0x84b0e4
    // 0x84b0dc: ldur            x6, [fp, #-0x68]
    // 0x84b0e0: b               #0x84b220
    // 0x84b0e4: r0 = LoadClassIdInstr(r1)
    //     0x84b0e4: ldur            x0, [x1, #-1]
    //     0x84b0e8: ubfx            x0, x0, #0xc, #0x14
    // 0x84b0ec: r0 = GDT[cid_x0 + 0x12641]()
    //     0x84b0ec: mov             x17, #0x2641
    //     0x84b0f0: movk            x17, #1, lsl #16
    //     0x84b0f4: add             lr, x0, x17
    //     0x84b0f8: ldr             lr, [x21, lr, lsl #3]
    //     0x84b0fc: blr             lr
    // 0x84b100: mov             x2, x0
    // 0x84b104: stur            x2, [fp, #-0x10]
    // 0x84b108: CheckStackOverflow
    //     0x84b108: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84b10c: cmp             SP, x16
    //     0x84b110: b.ls            #0x84b718
    // 0x84b114: r0 = LoadClassIdInstr(r2)
    //     0x84b114: ldur            x0, [x2, #-1]
    //     0x84b118: ubfx            x0, x0, #0xc, #0x14
    // 0x84b11c: mov             x1, x2
    // 0x84b120: r0 = GDT[cid_x0 + 0x1845b]()
    //     0x84b120: mov             x17, #0x845b
    //     0x84b124: movk            x17, #1, lsl #16
    //     0x84b128: add             lr, x0, x17
    //     0x84b12c: ldr             lr, [x21, lr, lsl #3]
    //     0x84b130: blr             lr
    // 0x84b134: tbnz            w0, #4, #0x84b21c
    // 0x84b138: ldur            x2, [fp, #-0x10]
    // 0x84b13c: r0 = LoadClassIdInstr(r2)
    //     0x84b13c: ldur            x0, [x2, #-1]
    //     0x84b140: ubfx            x0, x0, #0xc, #0x14
    // 0x84b144: mov             x1, x2
    // 0x84b148: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0x84b148: mov             x17, #0x7d4c
    //     0x84b14c: movk            x17, #1, lsl #16
    //     0x84b150: add             lr, x0, x17
    //     0x84b154: ldr             lr, [x21, lr, lsl #3]
    //     0x84b158: blr             lr
    // 0x84b15c: stur            x0, [fp, #-0x58]
    // 0x84b160: r0 = LoadStaticField(0x820)
    //     0x84b160: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x84b164: ldr             x0, [x0, #0x1040]
    // 0x84b168: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84b16c: cmp             w0, w16
    // 0x84b170: b.ne            #0x84b17c
    // 0x84b174: r2 = _allModifiers
    //     0x84b174: ldr             x2, [PP, #0x3b88]  ; [pp+0x3b88] Field <RawKeyboard._allModifiers@168461389>: static late final (offset: 0x820)
    // 0x84b178: r0 = InitLateFinalStaticField()
    //     0x84b178: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x84b17c: mov             x1, x0
    // 0x84b180: ldur            x2, [fp, #-0x58]
    // 0x84b184: stur            x0, [fp, #-0x60]
    // 0x84b188: r0 = _getValueOrData()
    //     0x84b188: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x84b18c: mov             x1, x0
    // 0x84b190: ldur            x0, [fp, #-0x60]
    // 0x84b194: LoadField: r2 = r0->field_f
    //     0x84b194: ldur            w2, [x0, #0xf]
    // 0x84b198: DecompressPointer r2
    //     0x84b198: add             x2, x2, HEAP, lsl #32
    // 0x84b19c: cmp             w2, w1
    // 0x84b1a0: b.ne            #0x84b1ac
    // 0x84b1a4: r3 = Null
    //     0x84b1a4: mov             x3, NULL
    // 0x84b1a8: b               #0x84b1b0
    // 0x84b1ac: mov             x3, x1
    // 0x84b1b0: ldur            x2, [fp, #-0x58]
    // 0x84b1b4: stur            x3, [fp, #-0x60]
    // 0x84b1b8: cmp             w3, NULL
    // 0x84b1bc: b.eq            #0x84b720
    // 0x84b1c0: LoadField: r4 = r2->field_7
    //     0x84b1c0: ldur            x4, [x2, #7]
    // 0x84b1c4: r0 = BoxInt64Instr(r4)
    //     0x84b1c4: sbfiz           x0, x4, #1, #0x1f
    //     0x84b1c8: cmp             x4, x0, asr #1
    //     0x84b1cc: b.eq            #0x84b1d8
    //     0x84b1d0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x84b1d4: stur            x4, [x0, #7]
    // 0x84b1d8: r1 = 60
    //     0x84b1d8: mov             x1, #0x3c
    // 0x84b1dc: branchIfSmi(r0, 0x84b1e8)
    //     0x84b1dc: tbz             w0, #0, #0x84b1e8
    // 0x84b1e0: r1 = LoadClassIdInstr(r0)
    //     0x84b1e0: ldur            x1, [x0, #-1]
    //     0x84b1e4: ubfx            x1, x1, #0xc, #0x14
    // 0x84b1e8: str             x0, [SP]
    // 0x84b1ec: mov             x0, x1
    // 0x84b1f0: r0 = GDT[cid_x0 + 0x70de]()
    //     0x84b1f0: mov             x17, #0x70de
    //     0x84b1f4: add             lr, x0, x17
    //     0x84b1f8: ldr             lr, [x21, lr, lsl #3]
    //     0x84b1fc: blr             lr
    // 0x84b200: ldur            x1, [fp, #-0x28]
    // 0x84b204: ldur            x2, [fp, #-0x58]
    // 0x84b208: ldur            x3, [fp, #-0x60]
    // 0x84b20c: mov             x5, x0
    // 0x84b210: r0 = _set()
    //     0x84b210: bl              #0x13d8170  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x84b214: ldur            x2, [fp, #-0x10]
    // 0x84b218: b               #0x84b108
    // 0x84b21c: ldur            x6, [fp, #-0x68]
    // 0x84b220: ldur            x5, [fp, #-0x48]
    // 0x84b224: ldur            x0, [fp, #-0x50]
    // 0x84b228: b               #0x84ae04
    // 0x84b22c: mov             x0, x1
    // 0x84b230: r3 = LoadClassIdInstr(r0)
    //     0x84b230: ldur            x3, [x0, #-1]
    //     0x84b234: ubfx            x3, x3, #0xc, #0x14
    // 0x84b238: stur            x3, [fp, #-0x48]
    // 0x84b23c: r17 = 5022
    //     0x84b23c: mov             x17, #0x139e
    // 0x84b240: cmp             x3, x17
    // 0x84b244: b.eq            #0x84b254
    // 0x84b248: r17 = 5020
    //     0x84b248: mov             x17, #0x139c
    // 0x84b24c: cmp             x3, x17
    // 0x84b250: b.ne            #0x84b2d4
    // 0x84b254: ldur            x4, [fp, #-0x30]
    // 0x84b258: mov             x1, x4
    // 0x84b25c: r2 = Instance_PhysicalKeyboardKey
    //     0x84b25c: ldr             x2, [PP, #0x3b90]  ; [pp+0x3b90] Obj!PhysicalKeyboardKey@12ab111
    // 0x84b260: r0 = _getValueOrData()
    //     0x84b260: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x84b264: mov             x1, x0
    // 0x84b268: ldur            x0, [fp, #-0x30]
    // 0x84b26c: LoadField: r2 = r0->field_f
    //     0x84b26c: ldur            w2, [x0, #0xf]
    // 0x84b270: DecompressPointer r2
    //     0x84b270: add             x2, x2, HEAP, lsl #32
    // 0x84b274: cmp             w2, w1
    // 0x84b278: b.eq            #0x84b2d4
    // 0x84b27c: cmp             w1, NULL
    // 0x84b280: b.eq            #0x84b2d4
    // 0x84b284: mov             x1, x0
    // 0x84b288: r2 = Instance_PhysicalKeyboardKey
    //     0x84b288: ldr             x2, [PP, #0x3b90]  ; [pp+0x3b90] Obj!PhysicalKeyboardKey@12ab111
    // 0x84b28c: r0 = _getValueOrData()
    //     0x84b28c: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x84b290: ldur            x1, [fp, #-0x30]
    // 0x84b294: LoadField: r2 = r1->field_f
    //     0x84b294: ldur            w2, [x1, #0xf]
    // 0x84b298: DecompressPointer r2
    //     0x84b298: add             x2, x2, HEAP, lsl #32
    // 0x84b29c: cmp             w2, w0
    // 0x84b2a0: b.ne            #0x84b2a8
    // 0x84b2a4: r0 = Null
    //     0x84b2a4: mov             x0, NULL
    // 0x84b2a8: r2 = LoadClassIdInstr(r0)
    //     0x84b2a8: ldur            x2, [x0, #-1]
    //     0x84b2ac: ubfx            x2, x2, #0xc, #0x14
    // 0x84b2b0: r16 = Instance_LogicalKeyboardKey
    //     0x84b2b0: ldr             x16, [PP, #0x3b08]  ; [pp+0x3b08] Obj!LogicalKeyboardKey@12ab751
    // 0x84b2b4: stp             x16, x0, [SP]
    // 0x84b2b8: mov             x0, x2
    // 0x84b2bc: mov             lr, x0
    // 0x84b2c0: ldr             lr, [x21, lr, lsl #3]
    // 0x84b2c4: blr             lr
    // 0x84b2c8: eor             x1, x0, #0x10
    // 0x84b2cc: mov             x0, x1
    // 0x84b2d0: b               #0x84b2d8
    // 0x84b2d4: r0 = false
    //     0x84b2d4: add             x0, NULL, #0x30  ; false
    // 0x84b2d8: stur            x0, [fp, #-0x10]
    // 0x84b2dc: r0 = LoadStaticField(0x81c)
    //     0x84b2dc: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x84b2e0: ldr             x0, [x0, #0x1038]
    // 0x84b2e4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84b2e8: cmp             w0, w16
    // 0x84b2ec: b.ne            #0x84b2f8
    // 0x84b2f0: r2 = _allModifiersExceptFn
    //     0x84b2f0: ldr             x2, [PP, #0x3b98]  ; [pp+0x3b98] Field <RawKeyboard._allModifiersExceptFn@168461389>: static late final (offset: 0x81c)
    // 0x84b2f4: r0 = InitLateFinalStaticField()
    //     0x84b2f4: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x84b2f8: r1 = <PhysicalKeyboardKey, LogicalKeyboardKey>
    //     0x84b2f8: ldr             x1, [PP, #0x3aa0]  ; [pp+0x3aa0] TypeArguments: <PhysicalKeyboardKey, LogicalKeyboardKey>
    // 0x84b2fc: stur            x0, [fp, #-0x20]
    // 0x84b300: r0 = _CompactKeysIterable()
    //     0x84b300: bl              #0x8353d0  ; Allocate_CompactKeysIterableStub -> _CompactKeysIterable<X0> (size=0x10)
    // 0x84b304: mov             x1, x0
    // 0x84b308: ldur            x0, [fp, #-0x20]
    // 0x84b30c: StoreField: r1->field_b = r0
    //     0x84b30c: stur            w0, [x1, #0xb]
    // 0x84b310: r0 = iterator()
    //     0x84b310: bl              #0xb09a64  ; [dart:_compact_hash] _CompactKeysIterable::iterator
    // 0x84b314: stur            x0, [fp, #-0x58]
    // 0x84b318: LoadField: r2 = r0->field_7
    //     0x84b318: ldur            w2, [x0, #7]
    // 0x84b31c: DecompressPointer r2
    //     0x84b31c: add             x2, x2, HEAP, lsl #32
    // 0x84b320: stur            x2, [fp, #-0x50]
    // 0x84b324: ldur            x4, [fp, #-0x38]
    // 0x84b328: ldur            x3, [fp, #-0x10]
    // 0x84b32c: CheckStackOverflow
    //     0x84b32c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84b330: cmp             SP, x16
    //     0x84b334: b.ls            #0x84b724
    // 0x84b338: mov             x1, x0
    // 0x84b33c: r0 = moveNext()
    //     0x84b33c: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0x84b340: tbnz            w0, #4, #0x84b450
    // 0x84b344: ldur            x3, [fp, #-0x58]
    // 0x84b348: LoadField: r4 = r3->field_33
    //     0x84b348: ldur            w4, [x3, #0x33]
    // 0x84b34c: DecompressPointer r4
    //     0x84b34c: add             x4, x4, HEAP, lsl #32
    // 0x84b350: stur            x4, [fp, #-0x60]
    // 0x84b354: cmp             w4, NULL
    // 0x84b358: b.ne            #0x84b388
    // 0x84b35c: mov             x0, x4
    // 0x84b360: ldur            x2, [fp, #-0x50]
    // 0x84b364: r1 = Null
    //     0x84b364: mov             x1, NULL
    // 0x84b368: cmp             w2, NULL
    // 0x84b36c: b.eq            #0x84b388
    // 0x84b370: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x84b370: ldur            w4, [x2, #0x17]
    // 0x84b374: DecompressPointer r4
    //     0x84b374: add             x4, x4, HEAP, lsl #32
    // 0x84b378: r8 = X0
    //     0x84b378: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x84b37c: LoadField: r9 = r4->field_7
    //     0x84b37c: ldur            x9, [x4, #7]
    // 0x84b380: r3 = Null
    //     0x84b380: ldr             x3, [PP, #0x3ba0]  ; [pp+0x3ba0] Null
    // 0x84b384: blr             x9
    // 0x84b388: ldur            x0, [fp, #-0x10]
    // 0x84b38c: tbnz            w0, #4, #0x84b3f8
    // 0x84b390: ldur            x2, [fp, #-0x60]
    // 0x84b394: r16 = Instance_PhysicalKeyboardKey
    //     0x84b394: ldr             x16, [PP, #0x3b90]  ; [pp+0x3b90] Obj!PhysicalKeyboardKey@12ab111
    // 0x84b398: cmp             w2, w16
    // 0x84b39c: b.ne            #0x84b3ac
    // 0x84b3a0: mov             x0, x2
    // 0x84b3a4: r1 = true
    //     0x84b3a4: add             x1, NULL, #0x20  ; true
    // 0x84b3a8: b               #0x84b3f0
    // 0x84b3ac: r16 = PhysicalKeyboardKey
    //     0x84b3ac: ldr             x16, [PP, #0x3ab8]  ; [pp+0x3ab8] Type: PhysicalKeyboardKey
    // 0x84b3b0: r30 = PhysicalKeyboardKey
    //     0x84b3b0: ldr             lr, [PP, #0x3ab8]  ; [pp+0x3ab8] Type: PhysicalKeyboardKey
    // 0x84b3b4: stp             lr, x16, [SP]
    // 0x84b3b8: r0 = ==()
    //     0x84b3b8: bl              #0x12b7fbc  ; [dart:core] _Type::==
    // 0x84b3bc: tbz             w0, #4, #0x84b3cc
    // 0x84b3c0: ldur            x0, [fp, #-0x60]
    // 0x84b3c4: r1 = false
    //     0x84b3c4: add             x1, NULL, #0x30  ; false
    // 0x84b3c8: b               #0x84b3f0
    // 0x84b3cc: ldur            x0, [fp, #-0x60]
    // 0x84b3d0: LoadField: r1 = r0->field_7
    //     0x84b3d0: ldur            x1, [x0, #7]
    // 0x84b3d4: r17 = 458809
    //     0x84b3d4: mov             x17, #0x39
    //     0x84b3d8: movk            x17, #7, lsl #16
    // 0x84b3dc: cmp             x1, x17
    // 0x84b3e0: r16 = true
    //     0x84b3e0: add             x16, NULL, #0x20  ; true
    // 0x84b3e4: r17 = false
    //     0x84b3e4: add             x17, NULL, #0x30  ; false
    // 0x84b3e8: csel            x2, x16, x17, eq
    // 0x84b3ec: mov             x1, x2
    // 0x84b3f0: mov             x4, x1
    // 0x84b3f4: b               #0x84b400
    // 0x84b3f8: ldur            x0, [fp, #-0x60]
    // 0x84b3fc: r4 = false
    //     0x84b3fc: add             x4, NULL, #0x30  ; false
    // 0x84b400: ldur            x3, [fp, #-0x38]
    // 0x84b404: stur            x4, [fp, #-0x70]
    // 0x84b408: LoadField: r5 = r3->field_f
    //     0x84b408: ldur            w5, [x3, #0xf]
    // 0x84b40c: DecompressPointer r5
    //     0x84b40c: add             x5, x5, HEAP, lsl #32
    // 0x84b410: mov             x1, x3
    // 0x84b414: mov             x2, x0
    // 0x84b418: stur            x5, [fp, #-0x68]
    // 0x84b41c: r0 = _getKeyOrData()
    //     0x84b41c: bl              #0x84b72c  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::_getKeyOrData
    // 0x84b420: mov             x1, x0
    // 0x84b424: ldur            x0, [fp, #-0x68]
    // 0x84b428: cmp             w0, w1
    // 0x84b42c: b.ne            #0x84b444
    // 0x84b430: ldur            x0, [fp, #-0x70]
    // 0x84b434: tbz             w0, #4, #0x84b444
    // 0x84b438: ldur            x1, [fp, #-0x30]
    // 0x84b43c: ldur            x2, [fp, #-0x60]
    // 0x84b440: r0 = remove()
    //     0x84b440: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x84b444: ldur            x0, [fp, #-0x58]
    // 0x84b448: ldur            x2, [fp, #-0x50]
    // 0x84b44c: b               #0x84b324
    // 0x84b450: ldur            x0, [fp, #-0x48]
    // 0x84b454: r17 = 5024
    //     0x84b454: mov             x17, #0x13a0
    // 0x84b458: cmp             x0, x17
    // 0x84b45c: b.eq            #0x84b478
    // 0x84b460: r17 = 5021
    //     0x84b460: mov             x17, #0x139d
    // 0x84b464: cmp             x0, x17
    // 0x84b468: b.eq            #0x84b478
    // 0x84b46c: ldur            x1, [fp, #-0x30]
    // 0x84b470: r2 = Instance_PhysicalKeyboardKey
    //     0x84b470: ldr             x2, [PP, #0x3bb0]  ; [pp+0x3bb0] Obj!PhysicalKeyboardKey@12ab721
    // 0x84b474: r0 = remove()
    //     0x84b474: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x84b478: ldur            x0, [fp, #-0x40]
    // 0x84b47c: ldur            x1, [fp, #-0x30]
    // 0x84b480: ldur            x2, [fp, #-0x28]
    // 0x84b484: r0 = addAll()
    //     0x84b484: bl              #0xbb0e58  ; [dart:_compact_hash] _Map::addAll
    // 0x84b488: ldur            x0, [fp, #-0x40]
    // 0x84b48c: r17 = 5017
    //     0x84b48c: mov             x17, #0x1399
    // 0x84b490: cmp             x0, x17
    // 0x84b494: b.ne            #0x84b6f8
    // 0x84b498: ldur            x0, [fp, #-0x18]
    // 0x84b49c: cmp             w0, NULL
    // 0x84b4a0: b.eq            #0x84b6f8
    // 0x84b4a4: ldur            x2, [fp, #-8]
    // 0x84b4a8: r0 = LoadClassIdInstr(r2)
    //     0x84b4a8: ldur            x0, [x2, #-1]
    //     0x84b4ac: ubfx            x0, x0, #0xc, #0x14
    // 0x84b4b0: mov             x1, x2
    // 0x84b4b4: r0 = GDT[cid_x0 + 0x6c3b]()
    //     0x84b4b4: mov             x17, #0x6c3b
    //     0x84b4b8: add             lr, x0, x17
    //     0x84b4bc: ldr             lr, [x21, lr, lsl #3]
    //     0x84b4c0: blr             lr
    // 0x84b4c4: ldur            x1, [fp, #-0x30]
    // 0x84b4c8: mov             x2, x0
    // 0x84b4cc: r0 = containsKey()
    //     0x84b4cc: bl              #0x12d5a5c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x84b4d0: tbz             w0, #4, #0x84b6f8
    // 0x84b4d4: ldur            x2, [fp, #-0x48]
    // 0x84b4d8: r17 = 5022
    //     0x84b4d8: mov             x17, #0x139e
    // 0x84b4dc: cmp             x2, x17
    // 0x84b4e0: b.ne            #0x84b51c
    // 0x84b4e4: ldur            x3, [fp, #-8]
    // 0x84b4e8: r0 = LoadClassIdInstr(r3)
    //     0x84b4e8: ldur            x0, [x3, #-1]
    //     0x84b4ec: ubfx            x0, x0, #0xc, #0x14
    // 0x84b4f0: mov             x1, x3
    // 0x84b4f4: r0 = GDT[cid_x0 + 0x6c3b]()
    //     0x84b4f4: mov             x17, #0x6c3b
    //     0x84b4f8: add             lr, x0, x17
    //     0x84b4fc: ldr             lr, [x21, lr, lsl #3]
    //     0x84b500: blr             lr
    // 0x84b504: r16 = Instance_PhysicalKeyboardKey
    //     0x84b504: ldr             x16, [PP, #0x3bb8]  ; [pp+0x3bb8] Obj!PhysicalKeyboardKey@12aaac1
    // 0x84b508: stp             x16, x0, [SP]
    // 0x84b50c: r0 = ==()
    //     0x84b50c: bl              #0x1279a00  ; [package:flutter/src/services/keyboard_key.g.dart] PhysicalKeyboardKey::==
    // 0x84b510: tbnz            w0, #4, #0x84b51c
    // 0x84b514: ldur            x2, [fp, #-0x48]
    // 0x84b518: b               #0x84b538
    // 0x84b51c: ldur            x2, [fp, #-0x48]
    // 0x84b520: r17 = 5023
    //     0x84b520: mov             x17, #0x139f
    // 0x84b524: cmp             x2, x17
    // 0x84b528: b.eq            #0x84b538
    // 0x84b52c: r17 = 5025
    //     0x84b52c: mov             x17, #0x13a1
    // 0x84b530: cmp             x2, x17
    // 0x84b534: b.ne            #0x84b614
    // 0x84b538: ldur            x3, [fp, #-8]
    // 0x84b53c: ldur            x4, [fp, #-0x20]
    // 0x84b540: r0 = LoadClassIdInstr(r3)
    //     0x84b540: ldur            x0, [x3, #-1]
    //     0x84b544: ubfx            x0, x0, #0xc, #0x14
    // 0x84b548: mov             x1, x3
    // 0x84b54c: r0 = GDT[cid_x0 + 0x6c3b]()
    //     0x84b54c: mov             x17, #0x6c3b
    //     0x84b550: add             lr, x0, x17
    //     0x84b554: ldr             lr, [x21, lr, lsl #3]
    //     0x84b558: blr             lr
    // 0x84b55c: ldur            x1, [fp, #-0x20]
    // 0x84b560: mov             x2, x0
    // 0x84b564: r0 = _getValueOrData()
    //     0x84b564: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x84b568: mov             x1, x0
    // 0x84b56c: ldur            x0, [fp, #-0x20]
    // 0x84b570: LoadField: r2 = r0->field_f
    //     0x84b570: ldur            w2, [x0, #0xf]
    // 0x84b574: DecompressPointer r2
    //     0x84b574: add             x2, x2, HEAP, lsl #32
    // 0x84b578: cmp             w2, w1
    // 0x84b57c: b.ne            #0x84b588
    // 0x84b580: r3 = Null
    //     0x84b580: mov             x3, NULL
    // 0x84b584: b               #0x84b58c
    // 0x84b588: mov             x3, x1
    // 0x84b58c: stur            x3, [fp, #-0x10]
    // 0x84b590: cmp             w3, NULL
    // 0x84b594: b.eq            #0x84b614
    // 0x84b598: ldur            x2, [fp, #-8]
    // 0x84b59c: r0 = LoadClassIdInstr(r2)
    //     0x84b59c: ldur            x0, [x2, #-1]
    //     0x84b5a0: ubfx            x0, x0, #0xc, #0x14
    // 0x84b5a4: mov             x1, x2
    // 0x84b5a8: r0 = GDT[cid_x0 + 0x6c3b]()
    //     0x84b5a8: mov             x17, #0x6c3b
    //     0x84b5ac: add             lr, x0, x17
    //     0x84b5b0: ldr             lr, [x21, lr, lsl #3]
    //     0x84b5b4: blr             lr
    // 0x84b5b8: mov             x2, x0
    // 0x84b5bc: stur            x2, [fp, #-0x18]
    // 0x84b5c0: LoadField: r3 = r2->field_7
    //     0x84b5c0: ldur            x3, [x2, #7]
    // 0x84b5c4: r0 = BoxInt64Instr(r3)
    //     0x84b5c4: sbfiz           x0, x3, #1, #0x1f
    //     0x84b5c8: cmp             x3, x0, asr #1
    //     0x84b5cc: b.eq            #0x84b5d8
    //     0x84b5d0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x84b5d4: stur            x3, [x0, #7]
    // 0x84b5d8: r1 = 60
    //     0x84b5d8: mov             x1, #0x3c
    // 0x84b5dc: branchIfSmi(r0, 0x84b5e8)
    //     0x84b5dc: tbz             w0, #0, #0x84b5e8
    // 0x84b5e0: r1 = LoadClassIdInstr(r0)
    //     0x84b5e0: ldur            x1, [x0, #-1]
    //     0x84b5e4: ubfx            x1, x1, #0xc, #0x14
    // 0x84b5e8: str             x0, [SP]
    // 0x84b5ec: mov             x0, x1
    // 0x84b5f0: r0 = GDT[cid_x0 + 0x70de]()
    //     0x84b5f0: mov             x17, #0x70de
    //     0x84b5f4: add             lr, x0, x17
    //     0x84b5f8: ldr             lr, [x21, lr, lsl #3]
    //     0x84b5fc: blr             lr
    // 0x84b600: ldur            x1, [fp, #-0x30]
    // 0x84b604: ldur            x2, [fp, #-0x18]
    // 0x84b608: ldur            x3, [fp, #-0x10]
    // 0x84b60c: mov             x5, x0
    // 0x84b610: r0 = _set()
    //     0x84b610: bl              #0x13d8170  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x84b614: ldur            x0, [fp, #-0x48]
    // 0x84b618: r17 = 5020
    //     0x84b618: mov             x17, #0x139c
    // 0x84b61c: cmp             x0, x17
    // 0x84b620: b.ne            #0x84b6f8
    // 0x84b624: ldur            x2, [fp, #-8]
    // 0x84b628: r0 = LoadClassIdInstr(r2)
    //     0x84b628: ldur            x0, [x2, #-1]
    //     0x84b62c: ubfx            x0, x0, #0xc, #0x14
    // 0x84b630: mov             x1, x2
    // 0x84b634: r0 = GDT[cid_x0 + 0x6c3b]()
    //     0x84b634: mov             x17, #0x6c3b
    //     0x84b638: add             lr, x0, x17
    //     0x84b63c: ldr             lr, [x21, lr, lsl #3]
    //     0x84b640: blr             lr
    // 0x84b644: r16 = Instance_PhysicalKeyboardKey
    //     0x84b644: ldr             x16, [PP, #0x3bb8]  ; [pp+0x3bb8] Obj!PhysicalKeyboardKey@12aaac1
    // 0x84b648: stp             x16, x0, [SP]
    // 0x84b64c: r0 = ==()
    //     0x84b64c: bl              #0x1279a00  ; [package:flutter/src/services/keyboard_key.g.dart] PhysicalKeyboardKey::==
    // 0x84b650: tbnz            w0, #4, #0x84b6f8
    // 0x84b654: ldur            x2, [fp, #-8]
    // 0x84b658: r0 = LoadClassIdInstr(r2)
    //     0x84b658: ldur            x0, [x2, #-1]
    //     0x84b65c: ubfx            x0, x0, #0xc, #0x14
    // 0x84b660: mov             x1, x2
    // 0x84b664: r0 = GDT[cid_x0 + 0x6c3b]()
    //     0x84b664: mov             x17, #0x6c3b
    //     0x84b668: add             lr, x0, x17
    //     0x84b66c: ldr             lr, [x21, lr, lsl #3]
    //     0x84b670: blr             lr
    // 0x84b674: mov             x2, x0
    // 0x84b678: ldur            x1, [fp, #-8]
    // 0x84b67c: stur            x2, [fp, #-0x10]
    // 0x84b680: r0 = LoadClassIdInstr(r1)
    //     0x84b680: ldur            x0, [x1, #-1]
    //     0x84b684: ubfx            x0, x0, #0xc, #0x14
    // 0x84b688: r0 = GDT[cid_x0 + 0x6f8c]()
    //     0x84b688: mov             x17, #0x6f8c
    //     0x84b68c: add             lr, x0, x17
    //     0x84b690: ldr             lr, [x21, lr, lsl #3]
    //     0x84b694: blr             lr
    // 0x84b698: mov             x3, x0
    // 0x84b69c: ldur            x2, [fp, #-0x10]
    // 0x84b6a0: stur            x3, [fp, #-8]
    // 0x84b6a4: LoadField: r4 = r2->field_7
    //     0x84b6a4: ldur            x4, [x2, #7]
    // 0x84b6a8: r0 = BoxInt64Instr(r4)
    //     0x84b6a8: sbfiz           x0, x4, #1, #0x1f
    //     0x84b6ac: cmp             x4, x0, asr #1
    //     0x84b6b0: b.eq            #0x84b6bc
    //     0x84b6b4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x84b6b8: stur            x4, [x0, #7]
    // 0x84b6bc: r1 = 60
    //     0x84b6bc: mov             x1, #0x3c
    // 0x84b6c0: branchIfSmi(r0, 0x84b6cc)
    //     0x84b6c0: tbz             w0, #0, #0x84b6cc
    // 0x84b6c4: r1 = LoadClassIdInstr(r0)
    //     0x84b6c4: ldur            x1, [x0, #-1]
    //     0x84b6c8: ubfx            x1, x1, #0xc, #0x14
    // 0x84b6cc: str             x0, [SP]
    // 0x84b6d0: mov             x0, x1
    // 0x84b6d4: r0 = GDT[cid_x0 + 0x70de]()
    //     0x84b6d4: mov             x17, #0x70de
    //     0x84b6d8: add             lr, x0, x17
    //     0x84b6dc: ldr             lr, [x21, lr, lsl #3]
    //     0x84b6e0: blr             lr
    // 0x84b6e4: ldur            x1, [fp, #-0x30]
    // 0x84b6e8: ldur            x2, [fp, #-0x10]
    // 0x84b6ec: ldur            x3, [fp, #-8]
    // 0x84b6f0: mov             x5, x0
    // 0x84b6f4: r0 = _set()
    //     0x84b6f4: bl              #0x13d8170  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x84b6f8: r0 = Null
    //     0x84b6f8: mov             x0, NULL
    // 0x84b6fc: LeaveFrame
    //     0x84b6fc: mov             SP, fp
    //     0x84b700: ldp             fp, lr, [SP], #0x10
    // 0x84b704: ret
    //     0x84b704: ret             
    // 0x84b708: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84b708: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84b70c: b               #0x84ad14
    // 0x84b710: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84b710: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84b714: b               #0x84ae24
    // 0x84b718: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84b718: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84b71c: b               #0x84b114
    // 0x84b720: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84b720: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84b724: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84b724: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84b728: b               #0x84b338
  }
  static Map<PhysicalKeyboardKey, LogicalKeyboardKey> _allModifiersExceptFn() {
    // ** addr: 0x84c700, size: 0xf4
    // 0x84c700: EnterFrame
    //     0x84c700: stp             fp, lr, [SP, #-0x10]!
    //     0x84c704: mov             fp, SP
    // 0x84c708: AllocStack(0x10)
    //     0x84c708: sub             SP, SP, #0x10
    // 0x84c70c: CheckStackOverflow
    //     0x84c70c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84c710: cmp             SP, x16
    //     0x84c714: b.ls            #0x84c7ec
    // 0x84c718: r1 = Null
    //     0x84c718: mov             x1, NULL
    // 0x84c71c: r2 = 44
    //     0x84c71c: mov             x2, #0x2c
    // 0x84c720: r0 = AllocateArray()
    //     0x84c720: bl              #0x13df928  ; AllocateArrayStub
    // 0x84c724: r16 = Instance_PhysicalKeyboardKey
    //     0x84c724: ldr             x16, [PP, #0x3bc8]  ; [pp+0x3bc8] Obj!PhysicalKeyboardKey@12aab01
    // 0x84c728: StoreField: r0->field_f = r16
    //     0x84c728: stur            w16, [x0, #0xf]
    // 0x84c72c: r16 = Instance_LogicalKeyboardKey
    //     0x84c72c: ldr             x16, [PP, #0x3bd0]  ; [pp+0x3bd0] Obj!LogicalKeyboardKey@12abb21
    // 0x84c730: StoreField: r0->field_13 = r16
    //     0x84c730: stur            w16, [x0, #0x13]
    // 0x84c734: r16 = Instance_PhysicalKeyboardKey
    //     0x84c734: ldr             x16, [PP, #0x3bb8]  ; [pp+0x3bb8] Obj!PhysicalKeyboardKey@12aaac1
    // 0x84c738: ArrayStore: r0[0] = r16  ; List_4
    //     0x84c738: stur            w16, [x0, #0x17]
    // 0x84c73c: r16 = Instance_LogicalKeyboardKey
    //     0x84c73c: ldr             x16, [PP, #0x3bd8]  ; [pp+0x3bd8] Obj!LogicalKeyboardKey@12abb11
    // 0x84c740: StoreField: r0->field_1b = r16
    //     0x84c740: stur            w16, [x0, #0x1b]
    // 0x84c744: r16 = Instance_PhysicalKeyboardKey
    //     0x84c744: ldr             x16, [PP, #0x3be0]  ; [pp+0x3be0] Obj!PhysicalKeyboardKey@12aab11
    // 0x84c748: StoreField: r0->field_1f = r16
    //     0x84c748: stur            w16, [x0, #0x1f]
    // 0x84c74c: r16 = Instance_LogicalKeyboardKey
    //     0x84c74c: ldr             x16, [PP, #0x3be8]  ; [pp+0x3be8] Obj!LogicalKeyboardKey@12abb41
    // 0x84c750: StoreField: r0->field_23 = r16
    //     0x84c750: stur            w16, [x0, #0x23]
    // 0x84c754: r16 = Instance_PhysicalKeyboardKey
    //     0x84c754: ldr             x16, [PP, #0x3bf0]  ; [pp+0x3bf0] Obj!PhysicalKeyboardKey@12aaad1
    // 0x84c758: StoreField: r0->field_27 = r16
    //     0x84c758: stur            w16, [x0, #0x27]
    // 0x84c75c: r16 = Instance_LogicalKeyboardKey
    //     0x84c75c: ldr             x16, [PP, #0x3bf8]  ; [pp+0x3bf8] Obj!LogicalKeyboardKey@12abb31
    // 0x84c760: StoreField: r0->field_2b = r16
    //     0x84c760: stur            w16, [x0, #0x2b]
    // 0x84c764: r16 = Instance_PhysicalKeyboardKey
    //     0x84c764: ldr             x16, [PP, #0x3c00]  ; [pp+0x3c00] Obj!PhysicalKeyboardKey@12aab21
    // 0x84c768: StoreField: r0->field_2f = r16
    //     0x84c768: stur            w16, [x0, #0x2f]
    // 0x84c76c: r16 = Instance_LogicalKeyboardKey
    //     0x84c76c: ldr             x16, [PP, #0x3c08]  ; [pp+0x3c08] Obj!LogicalKeyboardKey@12abb61
    // 0x84c770: StoreField: r0->field_33 = r16
    //     0x84c770: stur            w16, [x0, #0x33]
    // 0x84c774: r16 = Instance_PhysicalKeyboardKey
    //     0x84c774: ldr             x16, [PP, #0x3c10]  ; [pp+0x3c10] Obj!PhysicalKeyboardKey@12aaae1
    // 0x84c778: StoreField: r0->field_37 = r16
    //     0x84c778: stur            w16, [x0, #0x37]
    // 0x84c77c: r16 = Instance_LogicalKeyboardKey
    //     0x84c77c: ldr             x16, [PP, #0x3c18]  ; [pp+0x3c18] Obj!LogicalKeyboardKey@12abb51
    // 0x84c780: StoreField: r0->field_3b = r16
    //     0x84c780: stur            w16, [x0, #0x3b]
    // 0x84c784: r16 = Instance_PhysicalKeyboardKey
    //     0x84c784: ldr             x16, [PP, #0x3c20]  ; [pp+0x3c20] Obj!PhysicalKeyboardKey@12aaaf1
    // 0x84c788: StoreField: r0->field_3f = r16
    //     0x84c788: stur            w16, [x0, #0x3f]
    // 0x84c78c: r16 = Instance_LogicalKeyboardKey
    //     0x84c78c: ldr             x16, [PP, #0x3c28]  ; [pp+0x3c28] Obj!LogicalKeyboardKey@12abb01
    // 0x84c790: StoreField: r0->field_43 = r16
    //     0x84c790: stur            w16, [x0, #0x43]
    // 0x84c794: r16 = Instance_PhysicalKeyboardKey
    //     0x84c794: ldr             x16, [PP, #0x3c30]  ; [pp+0x3c30] Obj!PhysicalKeyboardKey@12aaab1
    // 0x84c798: StoreField: r0->field_47 = r16
    //     0x84c798: stur            w16, [x0, #0x47]
    // 0x84c79c: r16 = Instance_LogicalKeyboardKey
    //     0x84c79c: ldr             x16, [PP, #0x3c38]  ; [pp+0x3c38] Obj!LogicalKeyboardKey@12abaf1
    // 0x84c7a0: StoreField: r0->field_4b = r16
    //     0x84c7a0: stur            w16, [x0, #0x4b]
    // 0x84c7a4: r16 = Instance_PhysicalKeyboardKey
    //     0x84c7a4: ldr             x16, [PP, #0x3b90]  ; [pp+0x3b90] Obj!PhysicalKeyboardKey@12ab111
    // 0x84c7a8: StoreField: r0->field_4f = r16
    //     0x84c7a8: stur            w16, [x0, #0x4f]
    // 0x84c7ac: r16 = Instance_LogicalKeyboardKey
    //     0x84c7ac: ldr             x16, [PP, #0x3b08]  ; [pp+0x3b08] Obj!LogicalKeyboardKey@12ab751
    // 0x84c7b0: StoreField: r0->field_53 = r16
    //     0x84c7b0: stur            w16, [x0, #0x53]
    // 0x84c7b4: r16 = Instance_PhysicalKeyboardKey
    //     0x84c7b4: ldr             x16, [PP, #0x3c40]  ; [pp+0x3c40] Obj!PhysicalKeyboardKey@12aaf71
    // 0x84c7b8: StoreField: r0->field_57 = r16
    //     0x84c7b8: stur            w16, [x0, #0x57]
    // 0x84c7bc: r16 = Instance_LogicalKeyboardKey
    //     0x84c7bc: ldr             x16, [PP, #0x3ae8]  ; [pp+0x3ae8] Obj!LogicalKeyboardKey@12ab771
    // 0x84c7c0: StoreField: r0->field_5b = r16
    //     0x84c7c0: stur            w16, [x0, #0x5b]
    // 0x84c7c4: r16 = Instance_PhysicalKeyboardKey
    //     0x84c7c4: ldr             x16, [PP, #0x3c48]  ; [pp+0x3c48] Obj!PhysicalKeyboardKey@12ab031
    // 0x84c7c8: StoreField: r0->field_5f = r16
    //     0x84c7c8: stur            w16, [x0, #0x5f]
    // 0x84c7cc: r16 = Instance_LogicalKeyboardKey
    //     0x84c7cc: ldr             x16, [PP, #0x3af8]  ; [pp+0x3af8] Obj!LogicalKeyboardKey@12ab761
    // 0x84c7d0: StoreField: r0->field_63 = r16
    //     0x84c7d0: stur            w16, [x0, #0x63]
    // 0x84c7d4: r16 = <PhysicalKeyboardKey, LogicalKeyboardKey>
    //     0x84c7d4: ldr             x16, [PP, #0x3aa0]  ; [pp+0x3aa0] TypeArguments: <PhysicalKeyboardKey, LogicalKeyboardKey>
    // 0x84c7d8: stp             x0, x16, [SP]
    // 0x84c7dc: r0 = Map._fromLiteral()
    //     0x84c7dc: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x84c7e0: LeaveFrame
    //     0x84c7e0: mov             SP, fp
    //     0x84c7e4: ldp             fp, lr, [SP], #0x10
    // 0x84c7e8: ret
    //     0x84c7e8: ret             
    // 0x84c7ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84c7ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84c7f0: b               #0x84c718
  }
  static Map<PhysicalKeyboardKey, LogicalKeyboardKey> _allModifiers() {
    // ** addr: 0x84c7f4, size: 0xa0
    // 0x84c7f4: EnterFrame
    //     0x84c7f4: stp             fp, lr, [SP, #-0x10]!
    //     0x84c7f8: mov             fp, SP
    // 0x84c7fc: AllocStack(0x18)
    //     0x84c7fc: sub             SP, SP, #0x18
    // 0x84c800: CheckStackOverflow
    //     0x84c800: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84c804: cmp             SP, x16
    //     0x84c808: b.ls            #0x84c88c
    // 0x84c80c: r16 = <PhysicalKeyboardKey, LogicalKeyboardKey>
    //     0x84c80c: ldr             x16, [PP, #0x3aa0]  ; [pp+0x3aa0] TypeArguments: <PhysicalKeyboardKey, LogicalKeyboardKey>
    // 0x84c810: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x84c814: stp             lr, x16, [SP]
    // 0x84c818: r0 = Map._fromLiteral()
    //     0x84c818: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x84c81c: mov             x4, x0
    // 0x84c820: r0 = 36
    //     0x84c820: mov             x0, #0x24
    // 0x84c824: stur            x4, [fp, #-8]
    // 0x84c828: r16 = LoadInt32Instr(r0)
    //     0x84c828: sbfx            x16, x0, #1, #0x1f
    // 0x84c82c: r17 = 11601
    //     0x84c82c: mov             x17, #0x2d51
    // 0x84c830: mul             x5, x16, x17
    // 0x84c834: umulh           x16, x16, x17
    // 0x84c838: eor             x5, x5, x16
    // 0x84c83c: r5 = 0
    //     0x84c83c: eor             x5, x5, x5, lsr #32
    // 0x84c840: ubfiz           x5, x5, #1, #0x1e
    // 0x84c844: mov             x1, x4
    // 0x84c848: r2 = Instance_PhysicalKeyboardKey
    //     0x84c848: ldr             x2, [PP, #0x3bb0]  ; [pp+0x3bb0] Obj!PhysicalKeyboardKey@12ab721
    // 0x84c84c: r3 = Instance_LogicalKeyboardKey
    //     0x84c84c: ldr             x3, [PP, #0x3c50]  ; [pp+0x3c50] Obj!LogicalKeyboardKey@12ace31
    // 0x84c850: r0 = _set()
    //     0x84c850: bl              #0x13d8170  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x84c854: r0 = LoadStaticField(0x81c)
    //     0x84c854: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x84c858: ldr             x0, [x0, #0x1038]
    // 0x84c85c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84c860: cmp             w0, w16
    // 0x84c864: b.ne            #0x84c870
    // 0x84c868: r2 = _allModifiersExceptFn
    //     0x84c868: ldr             x2, [PP, #0x3b98]  ; [pp+0x3b98] Field <RawKeyboard._allModifiersExceptFn@168461389>: static late final (offset: 0x81c)
    // 0x84c86c: r0 = InitLateFinalStaticField()
    //     0x84c86c: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x84c870: ldur            x1, [fp, #-8]
    // 0x84c874: mov             x2, x0
    // 0x84c878: r0 = addAll()
    //     0x84c878: bl              #0xbb0e58  ; [dart:_compact_hash] _Map::addAll
    // 0x84c87c: ldur            x0, [fp, #-8]
    // 0x84c880: LeaveFrame
    //     0x84c880: mov             SP, fp
    //     0x84c884: ldp             fp, lr, [SP], #0x10
    // 0x84c888: ret
    //     0x84c888: ret             
    // 0x84c88c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84c88c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84c890: b               #0x84c80c
  }
  static Map<_ModifierSidePair, Set<PhysicalKeyboardKey>> _modifierKeyMap() {
    // ** addr: 0x84c950, size: 0x938
    // 0x84c950: EnterFrame
    //     0x84c950: stp             fp, lr, [SP, #-0x10]!
    //     0x84c954: mov             fp, SP
    // 0x84c958: AllocStack(0x20)
    //     0x84c958: sub             SP, SP, #0x20
    // 0x84c95c: CheckStackOverflow
    //     0x84c95c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84c960: cmp             SP, x16
    //     0x84c964: b.ls            #0x84d280
    // 0x84c968: r1 = Null
    //     0x84c968: mov             x1, NULL
    // 0x84c96c: r2 = 80
    //     0x84c96c: mov             x2, #0x50
    // 0x84c970: r0 = AllocateArray()
    //     0x84c970: bl              #0x13df928  ; AllocateArrayStub
    // 0x84c974: stur            x0, [fp, #-8]
    // 0x84c978: r16 = Instance__ModifierSidePair
    //     0x84c978: ldr             x16, [PP, #0x3c58]  ; [pp+0x3c58] Obj!_ModifierSidePair@129ba11
    // 0x84c97c: StoreField: r0->field_f = r16
    //     0x84c97c: stur            w16, [x0, #0xf]
    // 0x84c980: r1 = <PhysicalKeyboardKey>
    //     0x84c980: ldr             x1, [PP, #0x3b40]  ; [pp+0x3b40] TypeArguments: <PhysicalKeyboardKey>
    // 0x84c984: r0 = _Set()
    //     0x84c984: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x84c988: mov             x3, x0
    // 0x84c98c: r0 = _Uint32List
    //     0x84c98c: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0x84c990: stur            x3, [fp, #-0x10]
    // 0x84c994: StoreField: r3->field_1b = r0
    //     0x84c994: stur            w0, [x3, #0x1b]
    // 0x84c998: StoreField: r3->field_b = rZR
    //     0x84c998: stur            wzr, [x3, #0xb]
    // 0x84c99c: r4 = const []
    //     0x84c99c: ldr             x4, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0x84c9a0: StoreField: r3->field_f = r4
    //     0x84c9a0: stur            w4, [x3, #0xf]
    // 0x84c9a4: StoreField: r3->field_13 = rZR
    //     0x84c9a4: stur            wzr, [x3, #0x13]
    // 0x84c9a8: ArrayStore: r3[0] = rZR  ; List_4
    //     0x84c9a8: stur            wzr, [x3, #0x17]
    // 0x84c9ac: mov             x1, x3
    // 0x84c9b0: r2 = Instance_PhysicalKeyboardKey
    //     0x84c9b0: ldr             x2, [PP, #0x3bc8]  ; [pp+0x3bc8] Obj!PhysicalKeyboardKey@12aab01
    // 0x84c9b4: r0 = add()
    //     0x84c9b4: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x84c9b8: ldur            x1, [fp, #-8]
    // 0x84c9bc: ldur            x0, [fp, #-0x10]
    // 0x84c9c0: ArrayStore: r1[1] = r0  ; List_4
    //     0x84c9c0: add             x25, x1, #0x13
    //     0x84c9c4: str             w0, [x25]
    //     0x84c9c8: tbz             w0, #0, #0x84c9e4
    //     0x84c9cc: ldurb           w16, [x1, #-1]
    //     0x84c9d0: ldurb           w17, [x0, #-1]
    //     0x84c9d4: and             x16, x17, x16, lsr #2
    //     0x84c9d8: tst             x16, HEAP, lsr #32
    //     0x84c9dc: b.eq            #0x84c9e4
    //     0x84c9e0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x84c9e4: ldur            x0, [fp, #-8]
    // 0x84c9e8: r16 = Instance__ModifierSidePair
    //     0x84c9e8: ldr             x16, [PP, #0x3c60]  ; [pp+0x3c60] Obj!_ModifierSidePair@129ba01
    // 0x84c9ec: ArrayStore: r0[0] = r16  ; List_4
    //     0x84c9ec: stur            w16, [x0, #0x17]
    // 0x84c9f0: r1 = <PhysicalKeyboardKey>
    //     0x84c9f0: ldr             x1, [PP, #0x3b40]  ; [pp+0x3b40] TypeArguments: <PhysicalKeyboardKey>
    // 0x84c9f4: r0 = _Set()
    //     0x84c9f4: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x84c9f8: mov             x3, x0
    // 0x84c9fc: r0 = _Uint32List
    //     0x84c9fc: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0x84ca00: stur            x3, [fp, #-0x10]
    // 0x84ca04: StoreField: r3->field_1b = r0
    //     0x84ca04: stur            w0, [x3, #0x1b]
    // 0x84ca08: StoreField: r3->field_b = rZR
    //     0x84ca08: stur            wzr, [x3, #0xb]
    // 0x84ca0c: r4 = const []
    //     0x84ca0c: ldr             x4, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0x84ca10: StoreField: r3->field_f = r4
    //     0x84ca10: stur            w4, [x3, #0xf]
    // 0x84ca14: StoreField: r3->field_13 = rZR
    //     0x84ca14: stur            wzr, [x3, #0x13]
    // 0x84ca18: ArrayStore: r3[0] = rZR  ; List_4
    //     0x84ca18: stur            wzr, [x3, #0x17]
    // 0x84ca1c: mov             x1, x3
    // 0x84ca20: r2 = Instance_PhysicalKeyboardKey
    //     0x84ca20: ldr             x2, [PP, #0x3bb8]  ; [pp+0x3bb8] Obj!PhysicalKeyboardKey@12aaac1
    // 0x84ca24: r0 = add()
    //     0x84ca24: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x84ca28: ldur            x1, [fp, #-8]
    // 0x84ca2c: ldur            x0, [fp, #-0x10]
    // 0x84ca30: ArrayStore: r1[3] = r0  ; List_4
    //     0x84ca30: add             x25, x1, #0x1b
    //     0x84ca34: str             w0, [x25]
    //     0x84ca38: tbz             w0, #0, #0x84ca54
    //     0x84ca3c: ldurb           w16, [x1, #-1]
    //     0x84ca40: ldurb           w17, [x0, #-1]
    //     0x84ca44: and             x16, x17, x16, lsr #2
    //     0x84ca48: tst             x16, HEAP, lsr #32
    //     0x84ca4c: b.eq            #0x84ca54
    //     0x84ca50: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x84ca54: ldur            x0, [fp, #-8]
    // 0x84ca58: r16 = Instance__ModifierSidePair
    //     0x84ca58: ldr             x16, [PP, #0x3c68]  ; [pp+0x3c68] Obj!_ModifierSidePair@129b9f1
    // 0x84ca5c: StoreField: r0->field_1f = r16
    //     0x84ca5c: stur            w16, [x0, #0x1f]
    // 0x84ca60: r1 = <PhysicalKeyboardKey>
    //     0x84ca60: ldr             x1, [PP, #0x3b40]  ; [pp+0x3b40] TypeArguments: <PhysicalKeyboardKey>
    // 0x84ca64: r0 = _Set()
    //     0x84ca64: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x84ca68: mov             x3, x0
    // 0x84ca6c: r0 = _Uint32List
    //     0x84ca6c: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0x84ca70: stur            x3, [fp, #-0x10]
    // 0x84ca74: StoreField: r3->field_1b = r0
    //     0x84ca74: stur            w0, [x3, #0x1b]
    // 0x84ca78: StoreField: r3->field_b = rZR
    //     0x84ca78: stur            wzr, [x3, #0xb]
    // 0x84ca7c: r4 = const []
    //     0x84ca7c: ldr             x4, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0x84ca80: StoreField: r3->field_f = r4
    //     0x84ca80: stur            w4, [x3, #0xf]
    // 0x84ca84: StoreField: r3->field_13 = rZR
    //     0x84ca84: stur            wzr, [x3, #0x13]
    // 0x84ca88: ArrayStore: r3[0] = rZR  ; List_4
    //     0x84ca88: stur            wzr, [x3, #0x17]
    // 0x84ca8c: mov             x1, x3
    // 0x84ca90: r2 = Instance_PhysicalKeyboardKey
    //     0x84ca90: ldr             x2, [PP, #0x3bc8]  ; [pp+0x3bc8] Obj!PhysicalKeyboardKey@12aab01
    // 0x84ca94: r0 = add()
    //     0x84ca94: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x84ca98: ldur            x1, [fp, #-0x10]
    // 0x84ca9c: r2 = Instance_PhysicalKeyboardKey
    //     0x84ca9c: ldr             x2, [PP, #0x3bb8]  ; [pp+0x3bb8] Obj!PhysicalKeyboardKey@12aaac1
    // 0x84caa0: r0 = add()
    //     0x84caa0: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x84caa4: ldur            x1, [fp, #-8]
    // 0x84caa8: ldur            x0, [fp, #-0x10]
    // 0x84caac: ArrayStore: r1[5] = r0  ; List_4
    //     0x84caac: add             x25, x1, #0x23
    //     0x84cab0: str             w0, [x25]
    //     0x84cab4: tbz             w0, #0, #0x84cad0
    //     0x84cab8: ldurb           w16, [x1, #-1]
    //     0x84cabc: ldurb           w17, [x0, #-1]
    //     0x84cac0: and             x16, x17, x16, lsr #2
    //     0x84cac4: tst             x16, HEAP, lsr #32
    //     0x84cac8: b.eq            #0x84cad0
    //     0x84cacc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x84cad0: ldur            x0, [fp, #-8]
    // 0x84cad4: r16 = Instance__ModifierSidePair
    //     0x84cad4: ldr             x16, [PP, #0x3c70]  ; [pp+0x3c70] Obj!_ModifierSidePair@129b9e1
    // 0x84cad8: StoreField: r0->field_27 = r16
    //     0x84cad8: stur            w16, [x0, #0x27]
    // 0x84cadc: r1 = <PhysicalKeyboardKey>
    //     0x84cadc: ldr             x1, [PP, #0x3b40]  ; [pp+0x3b40] TypeArguments: <PhysicalKeyboardKey>
    // 0x84cae0: r0 = _Set()
    //     0x84cae0: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x84cae4: mov             x3, x0
    // 0x84cae8: r0 = _Uint32List
    //     0x84cae8: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0x84caec: stur            x3, [fp, #-0x10]
    // 0x84caf0: StoreField: r3->field_1b = r0
    //     0x84caf0: stur            w0, [x3, #0x1b]
    // 0x84caf4: StoreField: r3->field_b = rZR
    //     0x84caf4: stur            wzr, [x3, #0xb]
    // 0x84caf8: r4 = const []
    //     0x84caf8: ldr             x4, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0x84cafc: StoreField: r3->field_f = r4
    //     0x84cafc: stur            w4, [x3, #0xf]
    // 0x84cb00: StoreField: r3->field_13 = rZR
    //     0x84cb00: stur            wzr, [x3, #0x13]
    // 0x84cb04: ArrayStore: r3[0] = rZR  ; List_4
    //     0x84cb04: stur            wzr, [x3, #0x17]
    // 0x84cb08: mov             x1, x3
    // 0x84cb0c: r2 = Instance_PhysicalKeyboardKey
    //     0x84cb0c: ldr             x2, [PP, #0x3bc8]  ; [pp+0x3bc8] Obj!PhysicalKeyboardKey@12aab01
    // 0x84cb10: r0 = add()
    //     0x84cb10: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x84cb14: ldur            x1, [fp, #-8]
    // 0x84cb18: ldur            x0, [fp, #-0x10]
    // 0x84cb1c: ArrayStore: r1[7] = r0  ; List_4
    //     0x84cb1c: add             x25, x1, #0x2b
    //     0x84cb20: str             w0, [x25]
    //     0x84cb24: tbz             w0, #0, #0x84cb40
    //     0x84cb28: ldurb           w16, [x1, #-1]
    //     0x84cb2c: ldurb           w17, [x0, #-1]
    //     0x84cb30: and             x16, x17, x16, lsr #2
    //     0x84cb34: tst             x16, HEAP, lsr #32
    //     0x84cb38: b.eq            #0x84cb40
    //     0x84cb3c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x84cb40: ldur            x0, [fp, #-8]
    // 0x84cb44: r16 = Instance__ModifierSidePair
    //     0x84cb44: ldr             x16, [PP, #0x3c78]  ; [pp+0x3c78] Obj!_ModifierSidePair@129b9d1
    // 0x84cb48: StoreField: r0->field_2f = r16
    //     0x84cb48: stur            w16, [x0, #0x2f]
    // 0x84cb4c: r1 = <PhysicalKeyboardKey>
    //     0x84cb4c: ldr             x1, [PP, #0x3b40]  ; [pp+0x3b40] TypeArguments: <PhysicalKeyboardKey>
    // 0x84cb50: r0 = _Set()
    //     0x84cb50: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x84cb54: mov             x3, x0
    // 0x84cb58: r0 = _Uint32List
    //     0x84cb58: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0x84cb5c: stur            x3, [fp, #-0x10]
    // 0x84cb60: StoreField: r3->field_1b = r0
    //     0x84cb60: stur            w0, [x3, #0x1b]
    // 0x84cb64: StoreField: r3->field_b = rZR
    //     0x84cb64: stur            wzr, [x3, #0xb]
    // 0x84cb68: r4 = const []
    //     0x84cb68: ldr             x4, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0x84cb6c: StoreField: r3->field_f = r4
    //     0x84cb6c: stur            w4, [x3, #0xf]
    // 0x84cb70: StoreField: r3->field_13 = rZR
    //     0x84cb70: stur            wzr, [x3, #0x13]
    // 0x84cb74: ArrayStore: r3[0] = rZR  ; List_4
    //     0x84cb74: stur            wzr, [x3, #0x17]
    // 0x84cb78: mov             x1, x3
    // 0x84cb7c: r2 = Instance_PhysicalKeyboardKey
    //     0x84cb7c: ldr             x2, [PP, #0x3be0]  ; [pp+0x3be0] Obj!PhysicalKeyboardKey@12aab11
    // 0x84cb80: r0 = add()
    //     0x84cb80: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x84cb84: ldur            x1, [fp, #-8]
    // 0x84cb88: ldur            x0, [fp, #-0x10]
    // 0x84cb8c: ArrayStore: r1[9] = r0  ; List_4
    //     0x84cb8c: add             x25, x1, #0x33
    //     0x84cb90: str             w0, [x25]
    //     0x84cb94: tbz             w0, #0, #0x84cbb0
    //     0x84cb98: ldurb           w16, [x1, #-1]
    //     0x84cb9c: ldurb           w17, [x0, #-1]
    //     0x84cba0: and             x16, x17, x16, lsr #2
    //     0x84cba4: tst             x16, HEAP, lsr #32
    //     0x84cba8: b.eq            #0x84cbb0
    //     0x84cbac: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x84cbb0: ldur            x0, [fp, #-8]
    // 0x84cbb4: r16 = Instance__ModifierSidePair
    //     0x84cbb4: ldr             x16, [PP, #0x3c80]  ; [pp+0x3c80] Obj!_ModifierSidePair@129b9c1
    // 0x84cbb8: StoreField: r0->field_37 = r16
    //     0x84cbb8: stur            w16, [x0, #0x37]
    // 0x84cbbc: r1 = <PhysicalKeyboardKey>
    //     0x84cbbc: ldr             x1, [PP, #0x3b40]  ; [pp+0x3b40] TypeArguments: <PhysicalKeyboardKey>
    // 0x84cbc0: r0 = _Set()
    //     0x84cbc0: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x84cbc4: mov             x3, x0
    // 0x84cbc8: r0 = _Uint32List
    //     0x84cbc8: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0x84cbcc: stur            x3, [fp, #-0x10]
    // 0x84cbd0: StoreField: r3->field_1b = r0
    //     0x84cbd0: stur            w0, [x3, #0x1b]
    // 0x84cbd4: StoreField: r3->field_b = rZR
    //     0x84cbd4: stur            wzr, [x3, #0xb]
    // 0x84cbd8: r4 = const []
    //     0x84cbd8: ldr             x4, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0x84cbdc: StoreField: r3->field_f = r4
    //     0x84cbdc: stur            w4, [x3, #0xf]
    // 0x84cbe0: StoreField: r3->field_13 = rZR
    //     0x84cbe0: stur            wzr, [x3, #0x13]
    // 0x84cbe4: ArrayStore: r3[0] = rZR  ; List_4
    //     0x84cbe4: stur            wzr, [x3, #0x17]
    // 0x84cbe8: mov             x1, x3
    // 0x84cbec: r2 = Instance_PhysicalKeyboardKey
    //     0x84cbec: ldr             x2, [PP, #0x3bf0]  ; [pp+0x3bf0] Obj!PhysicalKeyboardKey@12aaad1
    // 0x84cbf0: r0 = add()
    //     0x84cbf0: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x84cbf4: ldur            x1, [fp, #-8]
    // 0x84cbf8: ldur            x0, [fp, #-0x10]
    // 0x84cbfc: ArrayStore: r1[11] = r0  ; List_4
    //     0x84cbfc: add             x25, x1, #0x3b
    //     0x84cc00: str             w0, [x25]
    //     0x84cc04: tbz             w0, #0, #0x84cc20
    //     0x84cc08: ldurb           w16, [x1, #-1]
    //     0x84cc0c: ldurb           w17, [x0, #-1]
    //     0x84cc10: and             x16, x17, x16, lsr #2
    //     0x84cc14: tst             x16, HEAP, lsr #32
    //     0x84cc18: b.eq            #0x84cc20
    //     0x84cc1c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x84cc20: ldur            x0, [fp, #-8]
    // 0x84cc24: r16 = Instance__ModifierSidePair
    //     0x84cc24: ldr             x16, [PP, #0x3c88]  ; [pp+0x3c88] Obj!_ModifierSidePair@129b9b1
    // 0x84cc28: StoreField: r0->field_3f = r16
    //     0x84cc28: stur            w16, [x0, #0x3f]
    // 0x84cc2c: r1 = <PhysicalKeyboardKey>
    //     0x84cc2c: ldr             x1, [PP, #0x3b40]  ; [pp+0x3b40] TypeArguments: <PhysicalKeyboardKey>
    // 0x84cc30: r0 = _Set()
    //     0x84cc30: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x84cc34: mov             x3, x0
    // 0x84cc38: r0 = _Uint32List
    //     0x84cc38: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0x84cc3c: stur            x3, [fp, #-0x10]
    // 0x84cc40: StoreField: r3->field_1b = r0
    //     0x84cc40: stur            w0, [x3, #0x1b]
    // 0x84cc44: StoreField: r3->field_b = rZR
    //     0x84cc44: stur            wzr, [x3, #0xb]
    // 0x84cc48: r4 = const []
    //     0x84cc48: ldr             x4, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0x84cc4c: StoreField: r3->field_f = r4
    //     0x84cc4c: stur            w4, [x3, #0xf]
    // 0x84cc50: StoreField: r3->field_13 = rZR
    //     0x84cc50: stur            wzr, [x3, #0x13]
    // 0x84cc54: ArrayStore: r3[0] = rZR  ; List_4
    //     0x84cc54: stur            wzr, [x3, #0x17]
    // 0x84cc58: mov             x1, x3
    // 0x84cc5c: r2 = Instance_PhysicalKeyboardKey
    //     0x84cc5c: ldr             x2, [PP, #0x3be0]  ; [pp+0x3be0] Obj!PhysicalKeyboardKey@12aab11
    // 0x84cc60: r0 = add()
    //     0x84cc60: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x84cc64: ldur            x1, [fp, #-0x10]
    // 0x84cc68: r2 = Instance_PhysicalKeyboardKey
    //     0x84cc68: ldr             x2, [PP, #0x3bf0]  ; [pp+0x3bf0] Obj!PhysicalKeyboardKey@12aaad1
    // 0x84cc6c: r0 = add()
    //     0x84cc6c: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x84cc70: ldur            x1, [fp, #-8]
    // 0x84cc74: ldur            x0, [fp, #-0x10]
    // 0x84cc78: ArrayStore: r1[13] = r0  ; List_4
    //     0x84cc78: add             x25, x1, #0x43
    //     0x84cc7c: str             w0, [x25]
    //     0x84cc80: tbz             w0, #0, #0x84cc9c
    //     0x84cc84: ldurb           w16, [x1, #-1]
    //     0x84cc88: ldurb           w17, [x0, #-1]
    //     0x84cc8c: and             x16, x17, x16, lsr #2
    //     0x84cc90: tst             x16, HEAP, lsr #32
    //     0x84cc94: b.eq            #0x84cc9c
    //     0x84cc98: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x84cc9c: ldur            x0, [fp, #-8]
    // 0x84cca0: r16 = Instance__ModifierSidePair
    //     0x84cca0: ldr             x16, [PP, #0x3c90]  ; [pp+0x3c90] Obj!_ModifierSidePair@129b9a1
    // 0x84cca4: StoreField: r0->field_47 = r16
    //     0x84cca4: stur            w16, [x0, #0x47]
    // 0x84cca8: r1 = <PhysicalKeyboardKey>
    //     0x84cca8: ldr             x1, [PP, #0x3b40]  ; [pp+0x3b40] TypeArguments: <PhysicalKeyboardKey>
    // 0x84ccac: r0 = _Set()
    //     0x84ccac: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x84ccb0: mov             x3, x0
    // 0x84ccb4: r0 = _Uint32List
    //     0x84ccb4: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0x84ccb8: stur            x3, [fp, #-0x10]
    // 0x84ccbc: StoreField: r3->field_1b = r0
    //     0x84ccbc: stur            w0, [x3, #0x1b]
    // 0x84ccc0: StoreField: r3->field_b = rZR
    //     0x84ccc0: stur            wzr, [x3, #0xb]
    // 0x84ccc4: r4 = const []
    //     0x84ccc4: ldr             x4, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0x84ccc8: StoreField: r3->field_f = r4
    //     0x84ccc8: stur            w4, [x3, #0xf]
    // 0x84cccc: StoreField: r3->field_13 = rZR
    //     0x84cccc: stur            wzr, [x3, #0x13]
    // 0x84ccd0: ArrayStore: r3[0] = rZR  ; List_4
    //     0x84ccd0: stur            wzr, [x3, #0x17]
    // 0x84ccd4: mov             x1, x3
    // 0x84ccd8: r2 = Instance_PhysicalKeyboardKey
    //     0x84ccd8: ldr             x2, [PP, #0x3be0]  ; [pp+0x3be0] Obj!PhysicalKeyboardKey@12aab11
    // 0x84ccdc: r0 = add()
    //     0x84ccdc: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x84cce0: ldur            x1, [fp, #-8]
    // 0x84cce4: ldur            x0, [fp, #-0x10]
    // 0x84cce8: ArrayStore: r1[15] = r0  ; List_4
    //     0x84cce8: add             x25, x1, #0x4b
    //     0x84ccec: str             w0, [x25]
    //     0x84ccf0: tbz             w0, #0, #0x84cd0c
    //     0x84ccf4: ldurb           w16, [x1, #-1]
    //     0x84ccf8: ldurb           w17, [x0, #-1]
    //     0x84ccfc: and             x16, x17, x16, lsr #2
    //     0x84cd00: tst             x16, HEAP, lsr #32
    //     0x84cd04: b.eq            #0x84cd0c
    //     0x84cd08: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x84cd0c: ldur            x0, [fp, #-8]
    // 0x84cd10: r16 = Instance__ModifierSidePair
    //     0x84cd10: ldr             x16, [PP, #0x3c98]  ; [pp+0x3c98] Obj!_ModifierSidePair@129b991
    // 0x84cd14: StoreField: r0->field_4f = r16
    //     0x84cd14: stur            w16, [x0, #0x4f]
    // 0x84cd18: r1 = <PhysicalKeyboardKey>
    //     0x84cd18: ldr             x1, [PP, #0x3b40]  ; [pp+0x3b40] TypeArguments: <PhysicalKeyboardKey>
    // 0x84cd1c: r0 = _Set()
    //     0x84cd1c: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x84cd20: mov             x3, x0
    // 0x84cd24: r0 = _Uint32List
    //     0x84cd24: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0x84cd28: stur            x3, [fp, #-0x10]
    // 0x84cd2c: StoreField: r3->field_1b = r0
    //     0x84cd2c: stur            w0, [x3, #0x1b]
    // 0x84cd30: StoreField: r3->field_b = rZR
    //     0x84cd30: stur            wzr, [x3, #0xb]
    // 0x84cd34: r4 = const []
    //     0x84cd34: ldr             x4, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0x84cd38: StoreField: r3->field_f = r4
    //     0x84cd38: stur            w4, [x3, #0xf]
    // 0x84cd3c: StoreField: r3->field_13 = rZR
    //     0x84cd3c: stur            wzr, [x3, #0x13]
    // 0x84cd40: ArrayStore: r3[0] = rZR  ; List_4
    //     0x84cd40: stur            wzr, [x3, #0x17]
    // 0x84cd44: mov             x1, x3
    // 0x84cd48: r2 = Instance_PhysicalKeyboardKey
    //     0x84cd48: ldr             x2, [PP, #0x3c00]  ; [pp+0x3c00] Obj!PhysicalKeyboardKey@12aab21
    // 0x84cd4c: r0 = add()
    //     0x84cd4c: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x84cd50: ldur            x1, [fp, #-8]
    // 0x84cd54: ldur            x0, [fp, #-0x10]
    // 0x84cd58: ArrayStore: r1[17] = r0  ; List_4
    //     0x84cd58: add             x25, x1, #0x53
    //     0x84cd5c: str             w0, [x25]
    //     0x84cd60: tbz             w0, #0, #0x84cd7c
    //     0x84cd64: ldurb           w16, [x1, #-1]
    //     0x84cd68: ldurb           w17, [x0, #-1]
    //     0x84cd6c: and             x16, x17, x16, lsr #2
    //     0x84cd70: tst             x16, HEAP, lsr #32
    //     0x84cd74: b.eq            #0x84cd7c
    //     0x84cd78: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x84cd7c: ldur            x0, [fp, #-8]
    // 0x84cd80: r16 = Instance__ModifierSidePair
    //     0x84cd80: ldr             x16, [PP, #0x3ca0]  ; [pp+0x3ca0] Obj!_ModifierSidePair@129b981
    // 0x84cd84: StoreField: r0->field_57 = r16
    //     0x84cd84: stur            w16, [x0, #0x57]
    // 0x84cd88: r1 = <PhysicalKeyboardKey>
    //     0x84cd88: ldr             x1, [PP, #0x3b40]  ; [pp+0x3b40] TypeArguments: <PhysicalKeyboardKey>
    // 0x84cd8c: r0 = _Set()
    //     0x84cd8c: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x84cd90: mov             x3, x0
    // 0x84cd94: r0 = _Uint32List
    //     0x84cd94: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0x84cd98: stur            x3, [fp, #-0x10]
    // 0x84cd9c: StoreField: r3->field_1b = r0
    //     0x84cd9c: stur            w0, [x3, #0x1b]
    // 0x84cda0: StoreField: r3->field_b = rZR
    //     0x84cda0: stur            wzr, [x3, #0xb]
    // 0x84cda4: r4 = const []
    //     0x84cda4: ldr             x4, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0x84cda8: StoreField: r3->field_f = r4
    //     0x84cda8: stur            w4, [x3, #0xf]
    // 0x84cdac: StoreField: r3->field_13 = rZR
    //     0x84cdac: stur            wzr, [x3, #0x13]
    // 0x84cdb0: ArrayStore: r3[0] = rZR  ; List_4
    //     0x84cdb0: stur            wzr, [x3, #0x17]
    // 0x84cdb4: mov             x1, x3
    // 0x84cdb8: r2 = Instance_PhysicalKeyboardKey
    //     0x84cdb8: ldr             x2, [PP, #0x3c10]  ; [pp+0x3c10] Obj!PhysicalKeyboardKey@12aaae1
    // 0x84cdbc: r0 = add()
    //     0x84cdbc: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x84cdc0: ldur            x1, [fp, #-8]
    // 0x84cdc4: ldur            x0, [fp, #-0x10]
    // 0x84cdc8: ArrayStore: r1[19] = r0  ; List_4
    //     0x84cdc8: add             x25, x1, #0x5b
    //     0x84cdcc: str             w0, [x25]
    //     0x84cdd0: tbz             w0, #0, #0x84cdec
    //     0x84cdd4: ldurb           w16, [x1, #-1]
    //     0x84cdd8: ldurb           w17, [x0, #-1]
    //     0x84cddc: and             x16, x17, x16, lsr #2
    //     0x84cde0: tst             x16, HEAP, lsr #32
    //     0x84cde4: b.eq            #0x84cdec
    //     0x84cde8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x84cdec: ldur            x0, [fp, #-8]
    // 0x84cdf0: r16 = Instance__ModifierSidePair
    //     0x84cdf0: ldr             x16, [PP, #0x3ca8]  ; [pp+0x3ca8] Obj!_ModifierSidePair@129b971
    // 0x84cdf4: StoreField: r0->field_5f = r16
    //     0x84cdf4: stur            w16, [x0, #0x5f]
    // 0x84cdf8: r1 = <PhysicalKeyboardKey>
    //     0x84cdf8: ldr             x1, [PP, #0x3b40]  ; [pp+0x3b40] TypeArguments: <PhysicalKeyboardKey>
    // 0x84cdfc: r0 = _Set()
    //     0x84cdfc: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x84ce00: mov             x3, x0
    // 0x84ce04: r0 = _Uint32List
    //     0x84ce04: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0x84ce08: stur            x3, [fp, #-0x10]
    // 0x84ce0c: StoreField: r3->field_1b = r0
    //     0x84ce0c: stur            w0, [x3, #0x1b]
    // 0x84ce10: StoreField: r3->field_b = rZR
    //     0x84ce10: stur            wzr, [x3, #0xb]
    // 0x84ce14: r4 = const []
    //     0x84ce14: ldr             x4, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0x84ce18: StoreField: r3->field_f = r4
    //     0x84ce18: stur            w4, [x3, #0xf]
    // 0x84ce1c: StoreField: r3->field_13 = rZR
    //     0x84ce1c: stur            wzr, [x3, #0x13]
    // 0x84ce20: ArrayStore: r3[0] = rZR  ; List_4
    //     0x84ce20: stur            wzr, [x3, #0x17]
    // 0x84ce24: mov             x1, x3
    // 0x84ce28: r2 = Instance_PhysicalKeyboardKey
    //     0x84ce28: ldr             x2, [PP, #0x3c00]  ; [pp+0x3c00] Obj!PhysicalKeyboardKey@12aab21
    // 0x84ce2c: r0 = add()
    //     0x84ce2c: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x84ce30: ldur            x1, [fp, #-0x10]
    // 0x84ce34: r2 = Instance_PhysicalKeyboardKey
    //     0x84ce34: ldr             x2, [PP, #0x3c10]  ; [pp+0x3c10] Obj!PhysicalKeyboardKey@12aaae1
    // 0x84ce38: r0 = add()
    //     0x84ce38: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x84ce3c: ldur            x1, [fp, #-8]
    // 0x84ce40: ldur            x0, [fp, #-0x10]
    // 0x84ce44: ArrayStore: r1[21] = r0  ; List_4
    //     0x84ce44: add             x25, x1, #0x63
    //     0x84ce48: str             w0, [x25]
    //     0x84ce4c: tbz             w0, #0, #0x84ce68
    //     0x84ce50: ldurb           w16, [x1, #-1]
    //     0x84ce54: ldurb           w17, [x0, #-1]
    //     0x84ce58: and             x16, x17, x16, lsr #2
    //     0x84ce5c: tst             x16, HEAP, lsr #32
    //     0x84ce60: b.eq            #0x84ce68
    //     0x84ce64: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x84ce68: ldur            x0, [fp, #-8]
    // 0x84ce6c: r16 = Instance__ModifierSidePair
    //     0x84ce6c: ldr             x16, [PP, #0x3cb0]  ; [pp+0x3cb0] Obj!_ModifierSidePair@129b961
    // 0x84ce70: StoreField: r0->field_67 = r16
    //     0x84ce70: stur            w16, [x0, #0x67]
    // 0x84ce74: r1 = <PhysicalKeyboardKey>
    //     0x84ce74: ldr             x1, [PP, #0x3b40]  ; [pp+0x3b40] TypeArguments: <PhysicalKeyboardKey>
    // 0x84ce78: r0 = _Set()
    //     0x84ce78: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x84ce7c: mov             x3, x0
    // 0x84ce80: r0 = _Uint32List
    //     0x84ce80: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0x84ce84: stur            x3, [fp, #-0x10]
    // 0x84ce88: StoreField: r3->field_1b = r0
    //     0x84ce88: stur            w0, [x3, #0x1b]
    // 0x84ce8c: StoreField: r3->field_b = rZR
    //     0x84ce8c: stur            wzr, [x3, #0xb]
    // 0x84ce90: r4 = const []
    //     0x84ce90: ldr             x4, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0x84ce94: StoreField: r3->field_f = r4
    //     0x84ce94: stur            w4, [x3, #0xf]
    // 0x84ce98: StoreField: r3->field_13 = rZR
    //     0x84ce98: stur            wzr, [x3, #0x13]
    // 0x84ce9c: ArrayStore: r3[0] = rZR  ; List_4
    //     0x84ce9c: stur            wzr, [x3, #0x17]
    // 0x84cea0: mov             x1, x3
    // 0x84cea4: r2 = Instance_PhysicalKeyboardKey
    //     0x84cea4: ldr             x2, [PP, #0x3c00]  ; [pp+0x3c00] Obj!PhysicalKeyboardKey@12aab21
    // 0x84cea8: r0 = add()
    //     0x84cea8: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x84ceac: ldur            x1, [fp, #-8]
    // 0x84ceb0: ldur            x0, [fp, #-0x10]
    // 0x84ceb4: ArrayStore: r1[23] = r0  ; List_4
    //     0x84ceb4: add             x25, x1, #0x6b
    //     0x84ceb8: str             w0, [x25]
    //     0x84cebc: tbz             w0, #0, #0x84ced8
    //     0x84cec0: ldurb           w16, [x1, #-1]
    //     0x84cec4: ldurb           w17, [x0, #-1]
    //     0x84cec8: and             x16, x17, x16, lsr #2
    //     0x84cecc: tst             x16, HEAP, lsr #32
    //     0x84ced0: b.eq            #0x84ced8
    //     0x84ced4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x84ced8: ldur            x0, [fp, #-8]
    // 0x84cedc: r16 = Instance__ModifierSidePair
    //     0x84cedc: ldr             x16, [PP, #0x3cb8]  ; [pp+0x3cb8] Obj!_ModifierSidePair@129b951
    // 0x84cee0: StoreField: r0->field_6f = r16
    //     0x84cee0: stur            w16, [x0, #0x6f]
    // 0x84cee4: r1 = <PhysicalKeyboardKey>
    //     0x84cee4: ldr             x1, [PP, #0x3b40]  ; [pp+0x3b40] TypeArguments: <PhysicalKeyboardKey>
    // 0x84cee8: r0 = _Set()
    //     0x84cee8: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x84ceec: mov             x3, x0
    // 0x84cef0: r0 = _Uint32List
    //     0x84cef0: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0x84cef4: stur            x3, [fp, #-0x10]
    // 0x84cef8: StoreField: r3->field_1b = r0
    //     0x84cef8: stur            w0, [x3, #0x1b]
    // 0x84cefc: StoreField: r3->field_b = rZR
    //     0x84cefc: stur            wzr, [x3, #0xb]
    // 0x84cf00: r4 = const []
    //     0x84cf00: ldr             x4, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0x84cf04: StoreField: r3->field_f = r4
    //     0x84cf04: stur            w4, [x3, #0xf]
    // 0x84cf08: StoreField: r3->field_13 = rZR
    //     0x84cf08: stur            wzr, [x3, #0x13]
    // 0x84cf0c: ArrayStore: r3[0] = rZR  ; List_4
    //     0x84cf0c: stur            wzr, [x3, #0x17]
    // 0x84cf10: mov             x1, x3
    // 0x84cf14: r2 = Instance_PhysicalKeyboardKey
    //     0x84cf14: ldr             x2, [PP, #0x3c20]  ; [pp+0x3c20] Obj!PhysicalKeyboardKey@12aaaf1
    // 0x84cf18: r0 = add()
    //     0x84cf18: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x84cf1c: ldur            x1, [fp, #-8]
    // 0x84cf20: ldur            x0, [fp, #-0x10]
    // 0x84cf24: ArrayStore: r1[25] = r0  ; List_4
    //     0x84cf24: add             x25, x1, #0x73
    //     0x84cf28: str             w0, [x25]
    //     0x84cf2c: tbz             w0, #0, #0x84cf48
    //     0x84cf30: ldurb           w16, [x1, #-1]
    //     0x84cf34: ldurb           w17, [x0, #-1]
    //     0x84cf38: and             x16, x17, x16, lsr #2
    //     0x84cf3c: tst             x16, HEAP, lsr #32
    //     0x84cf40: b.eq            #0x84cf48
    //     0x84cf44: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x84cf48: ldur            x0, [fp, #-8]
    // 0x84cf4c: r16 = Instance__ModifierSidePair
    //     0x84cf4c: ldr             x16, [PP, #0x3cc0]  ; [pp+0x3cc0] Obj!_ModifierSidePair@129b941
    // 0x84cf50: StoreField: r0->field_77 = r16
    //     0x84cf50: stur            w16, [x0, #0x77]
    // 0x84cf54: r1 = <PhysicalKeyboardKey>
    //     0x84cf54: ldr             x1, [PP, #0x3b40]  ; [pp+0x3b40] TypeArguments: <PhysicalKeyboardKey>
    // 0x84cf58: r0 = _Set()
    //     0x84cf58: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x84cf5c: mov             x3, x0
    // 0x84cf60: r0 = _Uint32List
    //     0x84cf60: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0x84cf64: stur            x3, [fp, #-0x10]
    // 0x84cf68: StoreField: r3->field_1b = r0
    //     0x84cf68: stur            w0, [x3, #0x1b]
    // 0x84cf6c: StoreField: r3->field_b = rZR
    //     0x84cf6c: stur            wzr, [x3, #0xb]
    // 0x84cf70: r4 = const []
    //     0x84cf70: ldr             x4, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0x84cf74: StoreField: r3->field_f = r4
    //     0x84cf74: stur            w4, [x3, #0xf]
    // 0x84cf78: StoreField: r3->field_13 = rZR
    //     0x84cf78: stur            wzr, [x3, #0x13]
    // 0x84cf7c: ArrayStore: r3[0] = rZR  ; List_4
    //     0x84cf7c: stur            wzr, [x3, #0x17]
    // 0x84cf80: mov             x1, x3
    // 0x84cf84: r2 = Instance_PhysicalKeyboardKey
    //     0x84cf84: ldr             x2, [PP, #0x3c30]  ; [pp+0x3c30] Obj!PhysicalKeyboardKey@12aaab1
    // 0x84cf88: r0 = add()
    //     0x84cf88: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x84cf8c: ldur            x1, [fp, #-8]
    // 0x84cf90: ldur            x0, [fp, #-0x10]
    // 0x84cf94: ArrayStore: r1[27] = r0  ; List_4
    //     0x84cf94: add             x25, x1, #0x7b
    //     0x84cf98: str             w0, [x25]
    //     0x84cf9c: tbz             w0, #0, #0x84cfb8
    //     0x84cfa0: ldurb           w16, [x1, #-1]
    //     0x84cfa4: ldurb           w17, [x0, #-1]
    //     0x84cfa8: and             x16, x17, x16, lsr #2
    //     0x84cfac: tst             x16, HEAP, lsr #32
    //     0x84cfb0: b.eq            #0x84cfb8
    //     0x84cfb4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x84cfb8: ldur            x0, [fp, #-8]
    // 0x84cfbc: r16 = Instance__ModifierSidePair
    //     0x84cfbc: ldr             x16, [PP, #0x3cc8]  ; [pp+0x3cc8] Obj!_ModifierSidePair@129b931
    // 0x84cfc0: StoreField: r0->field_7f = r16
    //     0x84cfc0: stur            w16, [x0, #0x7f]
    // 0x84cfc4: r1 = <PhysicalKeyboardKey>
    //     0x84cfc4: ldr             x1, [PP, #0x3b40]  ; [pp+0x3b40] TypeArguments: <PhysicalKeyboardKey>
    // 0x84cfc8: r0 = _Set()
    //     0x84cfc8: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x84cfcc: mov             x3, x0
    // 0x84cfd0: r0 = _Uint32List
    //     0x84cfd0: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0x84cfd4: stur            x3, [fp, #-0x10]
    // 0x84cfd8: StoreField: r3->field_1b = r0
    //     0x84cfd8: stur            w0, [x3, #0x1b]
    // 0x84cfdc: StoreField: r3->field_b = rZR
    //     0x84cfdc: stur            wzr, [x3, #0xb]
    // 0x84cfe0: r4 = const []
    //     0x84cfe0: ldr             x4, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0x84cfe4: StoreField: r3->field_f = r4
    //     0x84cfe4: stur            w4, [x3, #0xf]
    // 0x84cfe8: StoreField: r3->field_13 = rZR
    //     0x84cfe8: stur            wzr, [x3, #0x13]
    // 0x84cfec: ArrayStore: r3[0] = rZR  ; List_4
    //     0x84cfec: stur            wzr, [x3, #0x17]
    // 0x84cff0: mov             x1, x3
    // 0x84cff4: r2 = Instance_PhysicalKeyboardKey
    //     0x84cff4: ldr             x2, [PP, #0x3c20]  ; [pp+0x3c20] Obj!PhysicalKeyboardKey@12aaaf1
    // 0x84cff8: r0 = add()
    //     0x84cff8: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x84cffc: ldur            x1, [fp, #-0x10]
    // 0x84d000: r2 = Instance_PhysicalKeyboardKey
    //     0x84d000: ldr             x2, [PP, #0x3c30]  ; [pp+0x3c30] Obj!PhysicalKeyboardKey@12aaab1
    // 0x84d004: r0 = add()
    //     0x84d004: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x84d008: ldur            x1, [fp, #-8]
    // 0x84d00c: ldur            x0, [fp, #-0x10]
    // 0x84d010: ArrayStore: r1[29] = r0  ; List_4
    //     0x84d010: add             x25, x1, #0x83
    //     0x84d014: str             w0, [x25]
    //     0x84d018: tbz             w0, #0, #0x84d034
    //     0x84d01c: ldurb           w16, [x1, #-1]
    //     0x84d020: ldurb           w17, [x0, #-1]
    //     0x84d024: and             x16, x17, x16, lsr #2
    //     0x84d028: tst             x16, HEAP, lsr #32
    //     0x84d02c: b.eq            #0x84d034
    //     0x84d030: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x84d034: ldur            x0, [fp, #-8]
    // 0x84d038: r16 = Instance__ModifierSidePair
    //     0x84d038: ldr             x16, [PP, #0x3cd0]  ; [pp+0x3cd0] Obj!_ModifierSidePair@129b921
    // 0x84d03c: StoreField: r0->field_87 = r16
    //     0x84d03c: stur            w16, [x0, #0x87]
    // 0x84d040: r1 = <PhysicalKeyboardKey>
    //     0x84d040: ldr             x1, [PP, #0x3b40]  ; [pp+0x3b40] TypeArguments: <PhysicalKeyboardKey>
    // 0x84d044: r0 = _Set()
    //     0x84d044: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x84d048: mov             x3, x0
    // 0x84d04c: r0 = _Uint32List
    //     0x84d04c: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0x84d050: stur            x3, [fp, #-0x10]
    // 0x84d054: StoreField: r3->field_1b = r0
    //     0x84d054: stur            w0, [x3, #0x1b]
    // 0x84d058: StoreField: r3->field_b = rZR
    //     0x84d058: stur            wzr, [x3, #0xb]
    // 0x84d05c: r4 = const []
    //     0x84d05c: ldr             x4, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0x84d060: StoreField: r3->field_f = r4
    //     0x84d060: stur            w4, [x3, #0xf]
    // 0x84d064: StoreField: r3->field_13 = rZR
    //     0x84d064: stur            wzr, [x3, #0x13]
    // 0x84d068: ArrayStore: r3[0] = rZR  ; List_4
    //     0x84d068: stur            wzr, [x3, #0x17]
    // 0x84d06c: mov             x1, x3
    // 0x84d070: r2 = Instance_PhysicalKeyboardKey
    //     0x84d070: ldr             x2, [PP, #0x3c20]  ; [pp+0x3c20] Obj!PhysicalKeyboardKey@12aaaf1
    // 0x84d074: r0 = add()
    //     0x84d074: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x84d078: ldur            x1, [fp, #-8]
    // 0x84d07c: ldur            x0, [fp, #-0x10]
    // 0x84d080: ArrayStore: r1[31] = r0  ; List_4
    //     0x84d080: add             x25, x1, #0x8b
    //     0x84d084: str             w0, [x25]
    //     0x84d088: tbz             w0, #0, #0x84d0a4
    //     0x84d08c: ldurb           w16, [x1, #-1]
    //     0x84d090: ldurb           w17, [x0, #-1]
    //     0x84d094: and             x16, x17, x16, lsr #2
    //     0x84d098: tst             x16, HEAP, lsr #32
    //     0x84d09c: b.eq            #0x84d0a4
    //     0x84d0a0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x84d0a4: ldur            x0, [fp, #-8]
    // 0x84d0a8: r16 = Instance__ModifierSidePair
    //     0x84d0a8: ldr             x16, [PP, #0x3cd8]  ; [pp+0x3cd8] Obj!_ModifierSidePair@129b911
    // 0x84d0ac: StoreField: r0->field_8f = r16
    //     0x84d0ac: stur            w16, [x0, #0x8f]
    // 0x84d0b0: r1 = <PhysicalKeyboardKey>
    //     0x84d0b0: ldr             x1, [PP, #0x3b40]  ; [pp+0x3b40] TypeArguments: <PhysicalKeyboardKey>
    // 0x84d0b4: r0 = _Set()
    //     0x84d0b4: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x84d0b8: mov             x3, x0
    // 0x84d0bc: r0 = _Uint32List
    //     0x84d0bc: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0x84d0c0: stur            x3, [fp, #-0x10]
    // 0x84d0c4: StoreField: r3->field_1b = r0
    //     0x84d0c4: stur            w0, [x3, #0x1b]
    // 0x84d0c8: StoreField: r3->field_b = rZR
    //     0x84d0c8: stur            wzr, [x3, #0xb]
    // 0x84d0cc: r4 = const []
    //     0x84d0cc: ldr             x4, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0x84d0d0: StoreField: r3->field_f = r4
    //     0x84d0d0: stur            w4, [x3, #0xf]
    // 0x84d0d4: StoreField: r3->field_13 = rZR
    //     0x84d0d4: stur            wzr, [x3, #0x13]
    // 0x84d0d8: ArrayStore: r3[0] = rZR  ; List_4
    //     0x84d0d8: stur            wzr, [x3, #0x17]
    // 0x84d0dc: mov             x1, x3
    // 0x84d0e0: r2 = Instance_PhysicalKeyboardKey
    //     0x84d0e0: ldr             x2, [PP, #0x3b90]  ; [pp+0x3b90] Obj!PhysicalKeyboardKey@12ab111
    // 0x84d0e4: r0 = add()
    //     0x84d0e4: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x84d0e8: ldur            x1, [fp, #-8]
    // 0x84d0ec: ldur            x0, [fp, #-0x10]
    // 0x84d0f0: ArrayStore: r1[33] = r0  ; List_4
    //     0x84d0f0: add             x25, x1, #0x93
    //     0x84d0f4: str             w0, [x25]
    //     0x84d0f8: tbz             w0, #0, #0x84d114
    //     0x84d0fc: ldurb           w16, [x1, #-1]
    //     0x84d100: ldurb           w17, [x0, #-1]
    //     0x84d104: and             x16, x17, x16, lsr #2
    //     0x84d108: tst             x16, HEAP, lsr #32
    //     0x84d10c: b.eq            #0x84d114
    //     0x84d110: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x84d114: ldur            x0, [fp, #-8]
    // 0x84d118: r16 = Instance__ModifierSidePair
    //     0x84d118: ldr             x16, [PP, #0x3ce0]  ; [pp+0x3ce0] Obj!_ModifierSidePair@129b901
    // 0x84d11c: StoreField: r0->field_97 = r16
    //     0x84d11c: stur            w16, [x0, #0x97]
    // 0x84d120: r1 = <PhysicalKeyboardKey>
    //     0x84d120: ldr             x1, [PP, #0x3b40]  ; [pp+0x3b40] TypeArguments: <PhysicalKeyboardKey>
    // 0x84d124: r0 = _Set()
    //     0x84d124: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x84d128: mov             x3, x0
    // 0x84d12c: r0 = _Uint32List
    //     0x84d12c: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0x84d130: stur            x3, [fp, #-0x10]
    // 0x84d134: StoreField: r3->field_1b = r0
    //     0x84d134: stur            w0, [x3, #0x1b]
    // 0x84d138: StoreField: r3->field_b = rZR
    //     0x84d138: stur            wzr, [x3, #0xb]
    // 0x84d13c: r4 = const []
    //     0x84d13c: ldr             x4, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0x84d140: StoreField: r3->field_f = r4
    //     0x84d140: stur            w4, [x3, #0xf]
    // 0x84d144: StoreField: r3->field_13 = rZR
    //     0x84d144: stur            wzr, [x3, #0x13]
    // 0x84d148: ArrayStore: r3[0] = rZR  ; List_4
    //     0x84d148: stur            wzr, [x3, #0x17]
    // 0x84d14c: mov             x1, x3
    // 0x84d150: r2 = Instance_PhysicalKeyboardKey
    //     0x84d150: ldr             x2, [PP, #0x3c40]  ; [pp+0x3c40] Obj!PhysicalKeyboardKey@12aaf71
    // 0x84d154: r0 = add()
    //     0x84d154: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x84d158: ldur            x1, [fp, #-8]
    // 0x84d15c: ldur            x0, [fp, #-0x10]
    // 0x84d160: ArrayStore: r1[35] = r0  ; List_4
    //     0x84d160: add             x25, x1, #0x9b
    //     0x84d164: str             w0, [x25]
    //     0x84d168: tbz             w0, #0, #0x84d184
    //     0x84d16c: ldurb           w16, [x1, #-1]
    //     0x84d170: ldurb           w17, [x0, #-1]
    //     0x84d174: and             x16, x17, x16, lsr #2
    //     0x84d178: tst             x16, HEAP, lsr #32
    //     0x84d17c: b.eq            #0x84d184
    //     0x84d180: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x84d184: ldur            x0, [fp, #-8]
    // 0x84d188: r16 = Instance__ModifierSidePair
    //     0x84d188: ldr             x16, [PP, #0x3ce8]  ; [pp+0x3ce8] Obj!_ModifierSidePair@129b8f1
    // 0x84d18c: StoreField: r0->field_9f = r16
    //     0x84d18c: stur            w16, [x0, #0x9f]
    // 0x84d190: r1 = <PhysicalKeyboardKey>
    //     0x84d190: ldr             x1, [PP, #0x3b40]  ; [pp+0x3b40] TypeArguments: <PhysicalKeyboardKey>
    // 0x84d194: r0 = _Set()
    //     0x84d194: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x84d198: mov             x3, x0
    // 0x84d19c: r0 = _Uint32List
    //     0x84d19c: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0x84d1a0: stur            x3, [fp, #-0x10]
    // 0x84d1a4: StoreField: r3->field_1b = r0
    //     0x84d1a4: stur            w0, [x3, #0x1b]
    // 0x84d1a8: StoreField: r3->field_b = rZR
    //     0x84d1a8: stur            wzr, [x3, #0xb]
    // 0x84d1ac: r4 = const []
    //     0x84d1ac: ldr             x4, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0x84d1b0: StoreField: r3->field_f = r4
    //     0x84d1b0: stur            w4, [x3, #0xf]
    // 0x84d1b4: StoreField: r3->field_13 = rZR
    //     0x84d1b4: stur            wzr, [x3, #0x13]
    // 0x84d1b8: ArrayStore: r3[0] = rZR  ; List_4
    //     0x84d1b8: stur            wzr, [x3, #0x17]
    // 0x84d1bc: mov             x1, x3
    // 0x84d1c0: r2 = Instance_PhysicalKeyboardKey
    //     0x84d1c0: ldr             x2, [PP, #0x3c48]  ; [pp+0x3c48] Obj!PhysicalKeyboardKey@12ab031
    // 0x84d1c4: r0 = add()
    //     0x84d1c4: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x84d1c8: ldur            x1, [fp, #-8]
    // 0x84d1cc: ldur            x0, [fp, #-0x10]
    // 0x84d1d0: ArrayStore: r1[37] = r0  ; List_4
    //     0x84d1d0: add             x25, x1, #0xa3
    //     0x84d1d4: str             w0, [x25]
    //     0x84d1d8: tbz             w0, #0, #0x84d1f4
    //     0x84d1dc: ldurb           w16, [x1, #-1]
    //     0x84d1e0: ldurb           w17, [x0, #-1]
    //     0x84d1e4: and             x16, x17, x16, lsr #2
    //     0x84d1e8: tst             x16, HEAP, lsr #32
    //     0x84d1ec: b.eq            #0x84d1f4
    //     0x84d1f0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x84d1f4: ldur            x0, [fp, #-8]
    // 0x84d1f8: r16 = Instance__ModifierSidePair
    //     0x84d1f8: ldr             x16, [PP, #0x3cf0]  ; [pp+0x3cf0] Obj!_ModifierSidePair@129b8e1
    // 0x84d1fc: StoreField: r0->field_a7 = r16
    //     0x84d1fc: stur            w16, [x0, #0xa7]
    // 0x84d200: r1 = <PhysicalKeyboardKey>
    //     0x84d200: ldr             x1, [PP, #0x3b40]  ; [pp+0x3b40] TypeArguments: <PhysicalKeyboardKey>
    // 0x84d204: r0 = _Set()
    //     0x84d204: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x84d208: mov             x3, x0
    // 0x84d20c: r0 = _Uint32List
    //     0x84d20c: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0x84d210: stur            x3, [fp, #-0x10]
    // 0x84d214: StoreField: r3->field_1b = r0
    //     0x84d214: stur            w0, [x3, #0x1b]
    // 0x84d218: StoreField: r3->field_b = rZR
    //     0x84d218: stur            wzr, [x3, #0xb]
    // 0x84d21c: r0 = const []
    //     0x84d21c: ldr             x0, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0x84d220: StoreField: r3->field_f = r0
    //     0x84d220: stur            w0, [x3, #0xf]
    // 0x84d224: StoreField: r3->field_13 = rZR
    //     0x84d224: stur            wzr, [x3, #0x13]
    // 0x84d228: ArrayStore: r3[0] = rZR  ; List_4
    //     0x84d228: stur            wzr, [x3, #0x17]
    // 0x84d22c: mov             x1, x3
    // 0x84d230: r2 = Instance_PhysicalKeyboardKey
    //     0x84d230: ldr             x2, [PP, #0x3bb0]  ; [pp+0x3bb0] Obj!PhysicalKeyboardKey@12ab721
    // 0x84d234: r0 = add()
    //     0x84d234: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x84d238: ldur            x1, [fp, #-8]
    // 0x84d23c: ldur            x0, [fp, #-0x10]
    // 0x84d240: ArrayStore: r1[39] = r0  ; List_4
    //     0x84d240: add             x25, x1, #0xab
    //     0x84d244: str             w0, [x25]
    //     0x84d248: tbz             w0, #0, #0x84d264
    //     0x84d24c: ldurb           w16, [x1, #-1]
    //     0x84d250: ldurb           w17, [x0, #-1]
    //     0x84d254: and             x16, x17, x16, lsr #2
    //     0x84d258: tst             x16, HEAP, lsr #32
    //     0x84d25c: b.eq            #0x84d264
    //     0x84d260: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x84d264: r16 = <_ModifierSidePair, Set<PhysicalKeyboardKey>>
    //     0x84d264: ldr             x16, [PP, #0x3cf8]  ; [pp+0x3cf8] TypeArguments: <_ModifierSidePair, Set<PhysicalKeyboardKey>>
    // 0x84d268: ldur            lr, [fp, #-8]
    // 0x84d26c: stp             lr, x16, [SP]
    // 0x84d270: r0 = Map._fromLiteral()
    //     0x84d270: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x84d274: LeaveFrame
    //     0x84d274: mov             SP, fp
    //     0x84d278: ldp             fp, lr, [SP], #0x10
    // 0x84d27c: ret
    //     0x84d27c: ret             
    // 0x84d280: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84d280: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84d284: b               #0x84c968
  }
  get _ physicalKeysPressed(/* No info */) {
    // ** addr: 0x84eb10, size: 0x50
    // 0x84eb10: EnterFrame
    //     0x84eb10: stp             fp, lr, [SP, #-0x10]!
    //     0x84eb14: mov             fp, SP
    // 0x84eb18: AllocStack(0x8)
    //     0x84eb18: sub             SP, SP, #8
    // 0x84eb1c: CheckStackOverflow
    //     0x84eb1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84eb20: cmp             SP, x16
    //     0x84eb24: b.ls            #0x84eb58
    // 0x84eb28: LoadField: r0 = r1->field_b
    //     0x84eb28: ldur            w0, [x1, #0xb]
    // 0x84eb2c: DecompressPointer r0
    //     0x84eb2c: add             x0, x0, HEAP, lsl #32
    // 0x84eb30: stur            x0, [fp, #-8]
    // 0x84eb34: r1 = <PhysicalKeyboardKey, LogicalKeyboardKey>
    //     0x84eb34: ldr             x1, [PP, #0x3aa0]  ; [pp+0x3aa0] TypeArguments: <PhysicalKeyboardKey, LogicalKeyboardKey>
    // 0x84eb38: r0 = _CompactKeysIterable()
    //     0x84eb38: bl              #0x8353d0  ; Allocate_CompactKeysIterableStub -> _CompactKeysIterable<X0> (size=0x10)
    // 0x84eb3c: mov             x1, x0
    // 0x84eb40: ldur            x0, [fp, #-8]
    // 0x84eb44: StoreField: r1->field_b = r0
    //     0x84eb44: stur            w0, [x1, #0xb]
    // 0x84eb48: r0 = toSet()
    //     0x84eb48: bl              #0xba60e0  ; [dart:core] _GrowableList::toSet
    // 0x84eb4c: LeaveFrame
    //     0x84eb4c: mov             SP, fp
    //     0x84eb50: ldp             fp, lr, [SP], #0x10
    // 0x84eb54: ret
    //     0x84eb54: ret             
    // 0x84eb58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84eb58: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84eb5c: b               #0x84eb28
  }
  static RawKeyboard instance() {
    // ** addr: 0x84facc, size: 0x40
    // 0x84facc: EnterFrame
    //     0x84facc: stp             fp, lr, [SP, #-0x10]!
    //     0x84fad0: mov             fp, SP
    // 0x84fad4: AllocStack(0x8)
    //     0x84fad4: sub             SP, SP, #8
    // 0x84fad8: CheckStackOverflow
    //     0x84fad8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84fadc: cmp             SP, x16
    //     0x84fae0: b.ls            #0x84fb04
    // 0x84fae4: r0 = RawKeyboard()
    //     0x84fae4: bl              #0x84fba0  ; AllocateRawKeyboardStub -> RawKeyboard (size=0x10)
    // 0x84fae8: mov             x1, x0
    // 0x84faec: stur            x0, [fp, #-8]
    // 0x84faf0: r0 = RawKeyboard._()
    //     0x84faf0: bl              #0x84fb0c  ; [package:flutter/src/services/raw_keyboard.dart] RawKeyboard::RawKeyboard._
    // 0x84faf4: ldur            x0, [fp, #-8]
    // 0x84faf8: LeaveFrame
    //     0x84faf8: mov             SP, fp
    //     0x84fafc: ldp             fp, lr, [SP], #0x10
    // 0x84fb00: ret
    //     0x84fb00: ret             
    // 0x84fb04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84fb04: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84fb08: b               #0x84fae4
  }
  _ RawKeyboard._(/* No info */) {
    // ** addr: 0x84fb0c, size: 0x94
    // 0x84fb0c: EnterFrame
    //     0x84fb0c: stp             fp, lr, [SP, #-0x10]!
    //     0x84fb10: mov             fp, SP
    // 0x84fb14: AllocStack(0x18)
    //     0x84fb14: sub             SP, SP, #0x18
    // 0x84fb18: SetupParameters(RawKeyboard this /* r1 => r0, fp-0x8 */)
    //     0x84fb18: mov             x0, x1
    //     0x84fb1c: stur            x1, [fp, #-8]
    // 0x84fb20: CheckStackOverflow
    //     0x84fb20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84fb24: cmp             SP, x16
    //     0x84fb28: b.ls            #0x84fb98
    // 0x84fb2c: r1 = <(dynamic this, RawKeyEvent) => void?>
    //     0x84fb2c: ldr             x1, [PP, #0x3b20]  ; [pp+0x3b20] TypeArguments: <(dynamic this, RawKeyEvent) => void?>
    // 0x84fb30: r2 = 0
    //     0x84fb30: mov             x2, #0
    // 0x84fb34: r0 = _GrowableList()
    //     0x84fb34: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x84fb38: ldur            x1, [fp, #-8]
    // 0x84fb3c: StoreField: r1->field_7 = r0
    //     0x84fb3c: stur            w0, [x1, #7]
    //     0x84fb40: ldurb           w16, [x1, #-1]
    //     0x84fb44: ldurb           w17, [x0, #-1]
    //     0x84fb48: and             x16, x17, x16, lsr #2
    //     0x84fb4c: tst             x16, HEAP, lsr #32
    //     0x84fb50: b.eq            #0x84fb58
    //     0x84fb54: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x84fb58: r16 = <PhysicalKeyboardKey, LogicalKeyboardKey>
    //     0x84fb58: ldr             x16, [PP, #0x3aa0]  ; [pp+0x3aa0] TypeArguments: <PhysicalKeyboardKey, LogicalKeyboardKey>
    // 0x84fb5c: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x84fb60: stp             lr, x16, [SP]
    // 0x84fb64: r0 = Map._fromLiteral()
    //     0x84fb64: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x84fb68: ldur            x1, [fp, #-8]
    // 0x84fb6c: StoreField: r1->field_b = r0
    //     0x84fb6c: stur            w0, [x1, #0xb]
    //     0x84fb70: ldurb           w16, [x1, #-1]
    //     0x84fb74: ldurb           w17, [x0, #-1]
    //     0x84fb78: and             x16, x17, x16, lsr #2
    //     0x84fb7c: tst             x16, HEAP, lsr #32
    //     0x84fb80: b.eq            #0x84fb88
    //     0x84fb84: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x84fb88: r0 = Null
    //     0x84fb88: mov             x0, NULL
    // 0x84fb8c: LeaveFrame
    //     0x84fb8c: mov             SP, fp
    //     0x84fb90: ldp             fp, lr, [SP], #0x10
    // 0x84fb94: ret
    //     0x84fb94: ret             
    // 0x84fb98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84fb98: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84fb9c: b               #0x84fb2c
  }
}

// class id: 5015, size: 0x10, field offset: 0x8
//   const constructor, 
abstract class RawKeyEvent extends _MixinApplication3&Object&Diagnosticable {

  get _ logicalKey(/* No info */) {
    // ** addr: 0x84ac9c, size: 0x54
    // 0x84ac9c: EnterFrame
    //     0x84ac9c: stp             fp, lr, [SP, #-0x10]!
    //     0x84aca0: mov             fp, SP
    // 0x84aca4: CheckStackOverflow
    //     0x84aca4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84aca8: cmp             SP, x16
    //     0x84acac: b.ls            #0x84ace8
    // 0x84acb0: LoadField: r0 = r1->field_b
    //     0x84acb0: ldur            w0, [x1, #0xb]
    // 0x84acb4: DecompressPointer r0
    //     0x84acb4: add             x0, x0, HEAP, lsl #32
    // 0x84acb8: r1 = LoadClassIdInstr(r0)
    //     0x84acb8: ldur            x1, [x0, #-1]
    //     0x84acbc: ubfx            x1, x1, #0xc, #0x14
    // 0x84acc0: mov             x16, x0
    // 0x84acc4: mov             x0, x1
    // 0x84acc8: mov             x1, x16
    // 0x84accc: r0 = GDT[cid_x0 + 0x6f8c]()
    //     0x84accc: mov             x17, #0x6f8c
    //     0x84acd0: add             lr, x0, x17
    //     0x84acd4: ldr             lr, [x21, lr, lsl #3]
    //     0x84acd8: blr             lr
    // 0x84acdc: LeaveFrame
    //     0x84acdc: mov             SP, fp
    //     0x84ace0: ldp             fp, lr, [SP], #0x10
    // 0x84ace4: ret
    //     0x84ace4: ret             
    // 0x84ace8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84ace8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84acec: b               #0x84acb0
  }
  get _ physicalKey(/* No info */) {
    // ** addr: 0x84d310, size: 0x54
    // 0x84d310: EnterFrame
    //     0x84d310: stp             fp, lr, [SP, #-0x10]!
    //     0x84d314: mov             fp, SP
    // 0x84d318: CheckStackOverflow
    //     0x84d318: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84d31c: cmp             SP, x16
    //     0x84d320: b.ls            #0x84d35c
    // 0x84d324: LoadField: r0 = r1->field_b
    //     0x84d324: ldur            w0, [x1, #0xb]
    // 0x84d328: DecompressPointer r0
    //     0x84d328: add             x0, x0, HEAP, lsl #32
    // 0x84d32c: r1 = LoadClassIdInstr(r0)
    //     0x84d32c: ldur            x1, [x0, #-1]
    //     0x84d330: ubfx            x1, x1, #0xc, #0x14
    // 0x84d334: mov             x16, x0
    // 0x84d338: mov             x0, x1
    // 0x84d33c: mov             x1, x16
    // 0x84d340: r0 = GDT[cid_x0 + 0x6c3b]()
    //     0x84d340: mov             x17, #0x6c3b
    //     0x84d344: add             lr, x0, x17
    //     0x84d348: ldr             lr, [x21, lr, lsl #3]
    //     0x84d34c: blr             lr
    // 0x84d350: LeaveFrame
    //     0x84d350: mov             SP, fp
    //     0x84d354: ldp             fp, lr, [SP], #0x10
    // 0x84d358: ret
    //     0x84d358: ret             
    // 0x84d35c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84d35c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84d360: b               #0x84d324
  }
  factory _ RawKeyEvent.fromMessage(/* No info */) {
    // ** addr: 0x84d364, size: 0x17ac
    // 0x84d364: EnterFrame
    //     0x84d364: stp             fp, lr, [SP, #-0x10]!
    //     0x84d368: mov             fp, SP
    // 0x84d36c: AllocStack(0x88)
    //     0x84d36c: sub             SP, SP, #0x88
    // 0x84d370: SetupParameters(dynamic _ /* r1 => r0 */, dynamic _ /* r2 => r1, fp-0x8 */)
    //     0x84d370: mov             x0, x1
    //     0x84d374: mov             x1, x2
    //     0x84d378: stur            x2, [fp, #-8]
    // 0x84d37c: CheckStackOverflow
    //     0x84d37c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84d380: cmp             SP, x16
    //     0x84d384: b.ls            #0x84eb00
    // 0x84d388: r1 = 2
    //     0x84d388: mov             x1, #2
    // 0x84d38c: r0 = AllocateContext()
    //     0x84d38c: bl              #0x13de838  ; AllocateContextStub
    // 0x84d390: mov             x3, x0
    // 0x84d394: ldur            x0, [fp, #-8]
    // 0x84d398: stur            x3, [fp, #-0x10]
    // 0x84d39c: StoreField: r3->field_f = r0
    //     0x84d39c: stur            w0, [x3, #0xf]
    // 0x84d3a0: mov             x2, x3
    // 0x84d3a4: r1 = Function 'dataFromWeb': static.
    //     0x84d3a4: ldr             x1, [PP, #0x3d00]  ; [pp+0x3d00] AnonymousClosure: static (0x84ede8), in [package:flutter/src/services/raw_keyboard.dart] RawKeyEvent::RawKeyEvent.fromMessage (0x84d364)
    // 0x84d3a8: r0 = AllocateClosure()
    //     0x84d3a8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x84d3ac: mov             x3, x0
    // 0x84d3b0: ldur            x1, [fp, #-8]
    // 0x84d3b4: stur            x3, [fp, #-0x18]
    // 0x84d3b8: r0 = LoadClassIdInstr(r1)
    //     0x84d3b8: ldur            x0, [x1, #-1]
    //     0x84d3bc: ubfx            x0, x0, #0xc, #0x14
    // 0x84d3c0: r2 = "keymap"
    //     0x84d3c0: ldr             x2, [PP, #0x3d08]  ; [pp+0x3d08] "keymap"
    // 0x84d3c4: r0 = GDT[cid_x0 + -0xd48]()
    //     0x84d3c4: sub             lr, x0, #0xd48
    //     0x84d3c8: ldr             lr, [x21, lr, lsl #3]
    //     0x84d3cc: blr             lr
    // 0x84d3d0: mov             x3, x0
    // 0x84d3d4: stur            x3, [fp, #-8]
    // 0x84d3d8: cmp             w3, NULL
    // 0x84d3dc: b.eq            #0x84eb08
    // 0x84d3e0: mov             x0, x3
    // 0x84d3e4: r2 = Null
    //     0x84d3e4: mov             x2, NULL
    // 0x84d3e8: r1 = Null
    //     0x84d3e8: mov             x1, NULL
    // 0x84d3ec: r4 = 60
    //     0x84d3ec: mov             x4, #0x3c
    // 0x84d3f0: branchIfSmi(r0, 0x84d3fc)
    //     0x84d3f0: tbz             w0, #0, #0x84d3fc
    // 0x84d3f4: r4 = LoadClassIdInstr(r0)
    //     0x84d3f4: ldur            x4, [x0, #-1]
    //     0x84d3f8: ubfx            x4, x4, #0xc, #0x14
    // 0x84d3fc: sub             x4, x4, #0x5e
    // 0x84d400: cmp             x4, #1
    // 0x84d404: b.ls            #0x84d414
    // 0x84d408: r8 = String
    //     0x84d408: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x84d40c: r3 = Null
    //     0x84d40c: ldr             x3, [PP, #0x3d10]  ; [pp+0x3d10] Null
    // 0x84d410: r0 = String()
    //     0x84d410: bl              #0x13ee320  ; IsType_String_Stub
    // 0x84d414: r16 = "android"
    //     0x84d414: ldr             x16, [PP, #0x3d20]  ; [pp+0x3d20] "android"
    // 0x84d418: ldur            lr, [fp, #-8]
    // 0x84d41c: stp             lr, x16, [SP]
    // 0x84d420: r0 = ==()
    //     0x84d420: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x84d424: tbnz            w0, #4, #0x84da3c
    // 0x84d428: ldur            x3, [fp, #-0x10]
    // 0x84d42c: LoadField: r1 = r3->field_f
    //     0x84d42c: ldur            w1, [x3, #0xf]
    // 0x84d430: DecompressPointer r1
    //     0x84d430: add             x1, x1, HEAP, lsl #32
    // 0x84d434: r0 = LoadClassIdInstr(r1)
    //     0x84d434: ldur            x0, [x1, #-1]
    //     0x84d438: ubfx            x0, x0, #0xc, #0x14
    // 0x84d43c: r2 = "flags"
    //     0x84d43c: ldr             x2, [PP, #0x3d28]  ; [pp+0x3d28] "flags"
    // 0x84d440: r0 = GDT[cid_x0 + -0xd48]()
    //     0x84d440: sub             lr, x0, #0xd48
    //     0x84d444: ldr             lr, [x21, lr, lsl #3]
    //     0x84d448: blr             lr
    // 0x84d44c: mov             x3, x0
    // 0x84d450: r2 = Null
    //     0x84d450: mov             x2, NULL
    // 0x84d454: r1 = Null
    //     0x84d454: mov             x1, NULL
    // 0x84d458: stur            x3, [fp, #-0x20]
    // 0x84d45c: branchIfSmi(r0, 0x84d480)
    //     0x84d45c: tbz             w0, #0, #0x84d480
    // 0x84d460: r4 = LoadClassIdInstr(r0)
    //     0x84d460: ldur            x4, [x0, #-1]
    //     0x84d464: ubfx            x4, x4, #0xc, #0x14
    // 0x84d468: sub             x4, x4, #0x3c
    // 0x84d46c: cmp             x4, #1
    // 0x84d470: b.ls            #0x84d480
    // 0x84d474: r8 = int?
    //     0x84d474: ldr             x8, [PP, #0x3d30]  ; [pp+0x3d30] Type: int?
    // 0x84d478: r3 = Null
    //     0x84d478: ldr             x3, [PP, #0x3d38]  ; [pp+0x3d38] Null
    // 0x84d47c: r0 = int?()
    //     0x84d47c: bl              #0x13ee944  ; IsType_int?_Stub
    // 0x84d480: ldur            x0, [fp, #-0x20]
    // 0x84d484: cmp             w0, NULL
    // 0x84d488: b.ne            #0x84d494
    // 0x84d48c: r4 = 0
    //     0x84d48c: mov             x4, #0
    // 0x84d490: b               #0x84d4a4
    // 0x84d494: r1 = LoadInt32Instr(r0)
    //     0x84d494: sbfx            x1, x0, #1, #0x1f
    //     0x84d498: tbz             w0, #0, #0x84d4a0
    //     0x84d49c: ldur            x1, [x0, #7]
    // 0x84d4a0: mov             x4, x1
    // 0x84d4a4: ldur            x3, [fp, #-0x10]
    // 0x84d4a8: stur            x4, [fp, #-0x28]
    // 0x84d4ac: LoadField: r1 = r3->field_f
    //     0x84d4ac: ldur            w1, [x3, #0xf]
    // 0x84d4b0: DecompressPointer r1
    //     0x84d4b0: add             x1, x1, HEAP, lsl #32
    // 0x84d4b4: r0 = LoadClassIdInstr(r1)
    //     0x84d4b4: ldur            x0, [x1, #-1]
    //     0x84d4b8: ubfx            x0, x0, #0xc, #0x14
    // 0x84d4bc: r2 = "codePoint"
    //     0x84d4bc: ldr             x2, [PP, #0x3d48]  ; [pp+0x3d48] "codePoint"
    // 0x84d4c0: r0 = GDT[cid_x0 + -0xd48]()
    //     0x84d4c0: sub             lr, x0, #0xd48
    //     0x84d4c4: ldr             lr, [x21, lr, lsl #3]
    //     0x84d4c8: blr             lr
    // 0x84d4cc: mov             x3, x0
    // 0x84d4d0: r2 = Null
    //     0x84d4d0: mov             x2, NULL
    // 0x84d4d4: r1 = Null
    //     0x84d4d4: mov             x1, NULL
    // 0x84d4d8: stur            x3, [fp, #-0x20]
    // 0x84d4dc: branchIfSmi(r0, 0x84d500)
    //     0x84d4dc: tbz             w0, #0, #0x84d500
    // 0x84d4e0: r4 = LoadClassIdInstr(r0)
    //     0x84d4e0: ldur            x4, [x0, #-1]
    //     0x84d4e4: ubfx            x4, x4, #0xc, #0x14
    // 0x84d4e8: sub             x4, x4, #0x3c
    // 0x84d4ec: cmp             x4, #1
    // 0x84d4f0: b.ls            #0x84d500
    // 0x84d4f4: r8 = int?
    //     0x84d4f4: ldr             x8, [PP, #0x3d30]  ; [pp+0x3d30] Type: int?
    // 0x84d4f8: r3 = Null
    //     0x84d4f8: ldr             x3, [PP, #0x3d50]  ; [pp+0x3d50] Null
    // 0x84d4fc: r0 = int?()
    //     0x84d4fc: bl              #0x13ee944  ; IsType_int?_Stub
    // 0x84d500: ldur            x0, [fp, #-0x20]
    // 0x84d504: cmp             w0, NULL
    // 0x84d508: b.ne            #0x84d514
    // 0x84d50c: r4 = 0
    //     0x84d50c: mov             x4, #0
    // 0x84d510: b               #0x84d524
    // 0x84d514: r1 = LoadInt32Instr(r0)
    //     0x84d514: sbfx            x1, x0, #1, #0x1f
    //     0x84d518: tbz             w0, #0, #0x84d520
    //     0x84d51c: ldur            x1, [x0, #7]
    // 0x84d520: mov             x4, x1
    // 0x84d524: ldur            x3, [fp, #-0x10]
    // 0x84d528: stur            x4, [fp, #-0x30]
    // 0x84d52c: LoadField: r1 = r3->field_f
    //     0x84d52c: ldur            w1, [x3, #0xf]
    // 0x84d530: DecompressPointer r1
    //     0x84d530: add             x1, x1, HEAP, lsl #32
    // 0x84d534: r0 = LoadClassIdInstr(r1)
    //     0x84d534: ldur            x0, [x1, #-1]
    //     0x84d538: ubfx            x0, x0, #0xc, #0x14
    // 0x84d53c: r2 = "keyCode"
    //     0x84d53c: ldr             x2, [PP, #0x3d60]  ; [pp+0x3d60] "keyCode"
    // 0x84d540: r0 = GDT[cid_x0 + -0xd48]()
    //     0x84d540: sub             lr, x0, #0xd48
    //     0x84d544: ldr             lr, [x21, lr, lsl #3]
    //     0x84d548: blr             lr
    // 0x84d54c: mov             x3, x0
    // 0x84d550: r2 = Null
    //     0x84d550: mov             x2, NULL
    // 0x84d554: r1 = Null
    //     0x84d554: mov             x1, NULL
    // 0x84d558: stur            x3, [fp, #-0x20]
    // 0x84d55c: branchIfSmi(r0, 0x84d580)
    //     0x84d55c: tbz             w0, #0, #0x84d580
    // 0x84d560: r4 = LoadClassIdInstr(r0)
    //     0x84d560: ldur            x4, [x0, #-1]
    //     0x84d564: ubfx            x4, x4, #0xc, #0x14
    // 0x84d568: sub             x4, x4, #0x3c
    // 0x84d56c: cmp             x4, #1
    // 0x84d570: b.ls            #0x84d580
    // 0x84d574: r8 = int?
    //     0x84d574: ldr             x8, [PP, #0x3d30]  ; [pp+0x3d30] Type: int?
    // 0x84d578: r3 = Null
    //     0x84d578: ldr             x3, [PP, #0x3d68]  ; [pp+0x3d68] Null
    // 0x84d57c: r0 = int?()
    //     0x84d57c: bl              #0x13ee944  ; IsType_int?_Stub
    // 0x84d580: ldur            x0, [fp, #-0x20]
    // 0x84d584: cmp             w0, NULL
    // 0x84d588: b.ne            #0x84d594
    // 0x84d58c: r4 = 0
    //     0x84d58c: mov             x4, #0
    // 0x84d590: b               #0x84d5a4
    // 0x84d594: r1 = LoadInt32Instr(r0)
    //     0x84d594: sbfx            x1, x0, #1, #0x1f
    //     0x84d598: tbz             w0, #0, #0x84d5a0
    //     0x84d59c: ldur            x1, [x0, #7]
    // 0x84d5a0: mov             x4, x1
    // 0x84d5a4: ldur            x3, [fp, #-0x10]
    // 0x84d5a8: stur            x4, [fp, #-0x38]
    // 0x84d5ac: LoadField: r1 = r3->field_f
    //     0x84d5ac: ldur            w1, [x3, #0xf]
    // 0x84d5b0: DecompressPointer r1
    //     0x84d5b0: add             x1, x1, HEAP, lsl #32
    // 0x84d5b4: r0 = LoadClassIdInstr(r1)
    //     0x84d5b4: ldur            x0, [x1, #-1]
    //     0x84d5b8: ubfx            x0, x0, #0xc, #0x14
    // 0x84d5bc: r2 = "plainCodePoint"
    //     0x84d5bc: ldr             x2, [PP, #0x3d78]  ; [pp+0x3d78] "plainCodePoint"
    // 0x84d5c0: r0 = GDT[cid_x0 + -0xd48]()
    //     0x84d5c0: sub             lr, x0, #0xd48
    //     0x84d5c4: ldr             lr, [x21, lr, lsl #3]
    //     0x84d5c8: blr             lr
    // 0x84d5cc: mov             x3, x0
    // 0x84d5d0: r2 = Null
    //     0x84d5d0: mov             x2, NULL
    // 0x84d5d4: r1 = Null
    //     0x84d5d4: mov             x1, NULL
    // 0x84d5d8: stur            x3, [fp, #-0x20]
    // 0x84d5dc: branchIfSmi(r0, 0x84d600)
    //     0x84d5dc: tbz             w0, #0, #0x84d600
    // 0x84d5e0: r4 = LoadClassIdInstr(r0)
    //     0x84d5e0: ldur            x4, [x0, #-1]
    //     0x84d5e4: ubfx            x4, x4, #0xc, #0x14
    // 0x84d5e8: sub             x4, x4, #0x3c
    // 0x84d5ec: cmp             x4, #1
    // 0x84d5f0: b.ls            #0x84d600
    // 0x84d5f4: r8 = int?
    //     0x84d5f4: ldr             x8, [PP, #0x3d30]  ; [pp+0x3d30] Type: int?
    // 0x84d5f8: r3 = Null
    //     0x84d5f8: ldr             x3, [PP, #0x3d80]  ; [pp+0x3d80] Null
    // 0x84d5fc: r0 = int?()
    //     0x84d5fc: bl              #0x13ee944  ; IsType_int?_Stub
    // 0x84d600: ldur            x0, [fp, #-0x20]
    // 0x84d604: cmp             w0, NULL
    // 0x84d608: b.ne            #0x84d614
    // 0x84d60c: r4 = 0
    //     0x84d60c: mov             x4, #0
    // 0x84d610: b               #0x84d624
    // 0x84d614: r1 = LoadInt32Instr(r0)
    //     0x84d614: sbfx            x1, x0, #1, #0x1f
    //     0x84d618: tbz             w0, #0, #0x84d620
    //     0x84d61c: ldur            x1, [x0, #7]
    // 0x84d620: mov             x4, x1
    // 0x84d624: ldur            x3, [fp, #-0x10]
    // 0x84d628: stur            x4, [fp, #-0x40]
    // 0x84d62c: LoadField: r1 = r3->field_f
    //     0x84d62c: ldur            w1, [x3, #0xf]
    // 0x84d630: DecompressPointer r1
    //     0x84d630: add             x1, x1, HEAP, lsl #32
    // 0x84d634: r0 = LoadClassIdInstr(r1)
    //     0x84d634: ldur            x0, [x1, #-1]
    //     0x84d638: ubfx            x0, x0, #0xc, #0x14
    // 0x84d63c: r2 = "scanCode"
    //     0x84d63c: ldr             x2, [PP, #0x3d90]  ; [pp+0x3d90] "scanCode"
    // 0x84d640: r0 = GDT[cid_x0 + -0xd48]()
    //     0x84d640: sub             lr, x0, #0xd48
    //     0x84d644: ldr             lr, [x21, lr, lsl #3]
    //     0x84d648: blr             lr
    // 0x84d64c: mov             x3, x0
    // 0x84d650: r2 = Null
    //     0x84d650: mov             x2, NULL
    // 0x84d654: r1 = Null
    //     0x84d654: mov             x1, NULL
    // 0x84d658: stur            x3, [fp, #-0x20]
    // 0x84d65c: branchIfSmi(r0, 0x84d680)
    //     0x84d65c: tbz             w0, #0, #0x84d680
    // 0x84d660: r4 = LoadClassIdInstr(r0)
    //     0x84d660: ldur            x4, [x0, #-1]
    //     0x84d664: ubfx            x4, x4, #0xc, #0x14
    // 0x84d668: sub             x4, x4, #0x3c
    // 0x84d66c: cmp             x4, #1
    // 0x84d670: b.ls            #0x84d680
    // 0x84d674: r8 = int?
    //     0x84d674: ldr             x8, [PP, #0x3d30]  ; [pp+0x3d30] Type: int?
    // 0x84d678: r3 = Null
    //     0x84d678: ldr             x3, [PP, #0x3d98]  ; [pp+0x3d98] Null
    // 0x84d67c: r0 = int?()
    //     0x84d67c: bl              #0x13ee944  ; IsType_int?_Stub
    // 0x84d680: ldur            x0, [fp, #-0x20]
    // 0x84d684: cmp             w0, NULL
    // 0x84d688: b.ne            #0x84d694
    // 0x84d68c: r4 = 0
    //     0x84d68c: mov             x4, #0
    // 0x84d690: b               #0x84d6a4
    // 0x84d694: r1 = LoadInt32Instr(r0)
    //     0x84d694: sbfx            x1, x0, #1, #0x1f
    //     0x84d698: tbz             w0, #0, #0x84d6a0
    //     0x84d69c: ldur            x1, [x0, #7]
    // 0x84d6a0: mov             x4, x1
    // 0x84d6a4: ldur            x3, [fp, #-0x10]
    // 0x84d6a8: stur            x4, [fp, #-0x48]
    // 0x84d6ac: LoadField: r1 = r3->field_f
    //     0x84d6ac: ldur            w1, [x3, #0xf]
    // 0x84d6b0: DecompressPointer r1
    //     0x84d6b0: add             x1, x1, HEAP, lsl #32
    // 0x84d6b4: r0 = LoadClassIdInstr(r1)
    //     0x84d6b4: ldur            x0, [x1, #-1]
    //     0x84d6b8: ubfx            x0, x0, #0xc, #0x14
    // 0x84d6bc: r2 = "metaState"
    //     0x84d6bc: ldr             x2, [PP, #0x3da8]  ; [pp+0x3da8] "metaState"
    // 0x84d6c0: r0 = GDT[cid_x0 + -0xd48]()
    //     0x84d6c0: sub             lr, x0, #0xd48
    //     0x84d6c4: ldr             lr, [x21, lr, lsl #3]
    //     0x84d6c8: blr             lr
    // 0x84d6cc: mov             x3, x0
    // 0x84d6d0: r2 = Null
    //     0x84d6d0: mov             x2, NULL
    // 0x84d6d4: r1 = Null
    //     0x84d6d4: mov             x1, NULL
    // 0x84d6d8: stur            x3, [fp, #-0x20]
    // 0x84d6dc: branchIfSmi(r0, 0x84d700)
    //     0x84d6dc: tbz             w0, #0, #0x84d700
    // 0x84d6e0: r4 = LoadClassIdInstr(r0)
    //     0x84d6e0: ldur            x4, [x0, #-1]
    //     0x84d6e4: ubfx            x4, x4, #0xc, #0x14
    // 0x84d6e8: sub             x4, x4, #0x3c
    // 0x84d6ec: cmp             x4, #1
    // 0x84d6f0: b.ls            #0x84d700
    // 0x84d6f4: r8 = int?
    //     0x84d6f4: ldr             x8, [PP, #0x3d30]  ; [pp+0x3d30] Type: int?
    // 0x84d6f8: r3 = Null
    //     0x84d6f8: ldr             x3, [PP, #0x3db0]  ; [pp+0x3db0] Null
    // 0x84d6fc: r0 = int?()
    //     0x84d6fc: bl              #0x13ee944  ; IsType_int?_Stub
    // 0x84d700: ldur            x0, [fp, #-0x20]
    // 0x84d704: cmp             w0, NULL
    // 0x84d708: b.ne            #0x84d714
    // 0x84d70c: r4 = 0
    //     0x84d70c: mov             x4, #0
    // 0x84d710: b               #0x84d724
    // 0x84d714: r1 = LoadInt32Instr(r0)
    //     0x84d714: sbfx            x1, x0, #1, #0x1f
    //     0x84d718: tbz             w0, #0, #0x84d720
    //     0x84d71c: ldur            x1, [x0, #7]
    // 0x84d720: mov             x4, x1
    // 0x84d724: ldur            x3, [fp, #-0x10]
    // 0x84d728: stur            x4, [fp, #-0x50]
    // 0x84d72c: LoadField: r1 = r3->field_f
    //     0x84d72c: ldur            w1, [x3, #0xf]
    // 0x84d730: DecompressPointer r1
    //     0x84d730: add             x1, x1, HEAP, lsl #32
    // 0x84d734: r0 = LoadClassIdInstr(r1)
    //     0x84d734: ldur            x0, [x1, #-1]
    //     0x84d738: ubfx            x0, x0, #0xc, #0x14
    // 0x84d73c: r2 = "source"
    //     0x84d73c: ldr             x2, [PP, #0x3dc0]  ; [pp+0x3dc0] "source"
    // 0x84d740: r0 = GDT[cid_x0 + -0xd48]()
    //     0x84d740: sub             lr, x0, #0xd48
    //     0x84d744: ldr             lr, [x21, lr, lsl #3]
    //     0x84d748: blr             lr
    // 0x84d74c: mov             x3, x0
    // 0x84d750: r2 = Null
    //     0x84d750: mov             x2, NULL
    // 0x84d754: r1 = Null
    //     0x84d754: mov             x1, NULL
    // 0x84d758: stur            x3, [fp, #-0x20]
    // 0x84d75c: branchIfSmi(r0, 0x84d780)
    //     0x84d75c: tbz             w0, #0, #0x84d780
    // 0x84d760: r4 = LoadClassIdInstr(r0)
    //     0x84d760: ldur            x4, [x0, #-1]
    //     0x84d764: ubfx            x4, x4, #0xc, #0x14
    // 0x84d768: sub             x4, x4, #0x3c
    // 0x84d76c: cmp             x4, #1
    // 0x84d770: b.ls            #0x84d780
    // 0x84d774: r8 = int?
    //     0x84d774: ldr             x8, [PP, #0x3d30]  ; [pp+0x3d30] Type: int?
    // 0x84d778: r3 = Null
    //     0x84d778: ldr             x3, [PP, #0x3dc8]  ; [pp+0x3dc8] Null
    // 0x84d77c: r0 = int?()
    //     0x84d77c: bl              #0x13ee944  ; IsType_int?_Stub
    // 0x84d780: ldur            x0, [fp, #-0x20]
    // 0x84d784: cmp             w0, NULL
    // 0x84d788: b.ne            #0x84d794
    // 0x84d78c: r4 = 0
    //     0x84d78c: mov             x4, #0
    // 0x84d790: b               #0x84d7a4
    // 0x84d794: r1 = LoadInt32Instr(r0)
    //     0x84d794: sbfx            x1, x0, #1, #0x1f
    //     0x84d798: tbz             w0, #0, #0x84d7a0
    //     0x84d79c: ldur            x1, [x0, #7]
    // 0x84d7a0: mov             x4, x1
    // 0x84d7a4: ldur            x3, [fp, #-0x10]
    // 0x84d7a8: stur            x4, [fp, #-0x58]
    // 0x84d7ac: LoadField: r1 = r3->field_f
    //     0x84d7ac: ldur            w1, [x3, #0xf]
    // 0x84d7b0: DecompressPointer r1
    //     0x84d7b0: add             x1, x1, HEAP, lsl #32
    // 0x84d7b4: r0 = LoadClassIdInstr(r1)
    //     0x84d7b4: ldur            x0, [x1, #-1]
    //     0x84d7b8: ubfx            x0, x0, #0xc, #0x14
    // 0x84d7bc: r2 = "vendorId"
    //     0x84d7bc: ldr             x2, [PP, #0x3dd8]  ; [pp+0x3dd8] "vendorId"
    // 0x84d7c0: r0 = GDT[cid_x0 + -0xd48]()
    //     0x84d7c0: sub             lr, x0, #0xd48
    //     0x84d7c4: ldr             lr, [x21, lr, lsl #3]
    //     0x84d7c8: blr             lr
    // 0x84d7cc: r2 = Null
    //     0x84d7cc: mov             x2, NULL
    // 0x84d7d0: r1 = Null
    //     0x84d7d0: mov             x1, NULL
    // 0x84d7d4: branchIfSmi(r0, 0x84d7f8)
    //     0x84d7d4: tbz             w0, #0, #0x84d7f8
    // 0x84d7d8: r4 = LoadClassIdInstr(r0)
    //     0x84d7d8: ldur            x4, [x0, #-1]
    //     0x84d7dc: ubfx            x4, x4, #0xc, #0x14
    // 0x84d7e0: sub             x4, x4, #0x3c
    // 0x84d7e4: cmp             x4, #1
    // 0x84d7e8: b.ls            #0x84d7f8
    // 0x84d7ec: r8 = int?
    //     0x84d7ec: ldr             x8, [PP, #0x3d30]  ; [pp+0x3d30] Type: int?
    // 0x84d7f0: r3 = Null
    //     0x84d7f0: ldr             x3, [PP, #0x3de0]  ; [pp+0x3de0] Null
    // 0x84d7f4: r0 = int?()
    //     0x84d7f4: bl              #0x13ee944  ; IsType_int?_Stub
    // 0x84d7f8: ldur            x3, [fp, #-0x10]
    // 0x84d7fc: LoadField: r1 = r3->field_f
    //     0x84d7fc: ldur            w1, [x3, #0xf]
    // 0x84d800: DecompressPointer r1
    //     0x84d800: add             x1, x1, HEAP, lsl #32
    // 0x84d804: r0 = LoadClassIdInstr(r1)
    //     0x84d804: ldur            x0, [x1, #-1]
    //     0x84d808: ubfx            x0, x0, #0xc, #0x14
    // 0x84d80c: r2 = "productId"
    //     0x84d80c: ldr             x2, [PP, #0x3df0]  ; [pp+0x3df0] "productId"
    // 0x84d810: r0 = GDT[cid_x0 + -0xd48]()
    //     0x84d810: sub             lr, x0, #0xd48
    //     0x84d814: ldr             lr, [x21, lr, lsl #3]
    //     0x84d818: blr             lr
    // 0x84d81c: r2 = Null
    //     0x84d81c: mov             x2, NULL
    // 0x84d820: r1 = Null
    //     0x84d820: mov             x1, NULL
    // 0x84d824: branchIfSmi(r0, 0x84d848)
    //     0x84d824: tbz             w0, #0, #0x84d848
    // 0x84d828: r4 = LoadClassIdInstr(r0)
    //     0x84d828: ldur            x4, [x0, #-1]
    //     0x84d82c: ubfx            x4, x4, #0xc, #0x14
    // 0x84d830: sub             x4, x4, #0x3c
    // 0x84d834: cmp             x4, #1
    // 0x84d838: b.ls            #0x84d848
    // 0x84d83c: r8 = int?
    //     0x84d83c: ldr             x8, [PP, #0x3d30]  ; [pp+0x3d30] Type: int?
    // 0x84d840: r3 = Null
    //     0x84d840: ldr             x3, [PP, #0x3df8]  ; [pp+0x3df8] Null
    // 0x84d844: r0 = int?()
    //     0x84d844: bl              #0x13ee944  ; IsType_int?_Stub
    // 0x84d848: ldur            x3, [fp, #-0x10]
    // 0x84d84c: LoadField: r1 = r3->field_f
    //     0x84d84c: ldur            w1, [x3, #0xf]
    // 0x84d850: DecompressPointer r1
    //     0x84d850: add             x1, x1, HEAP, lsl #32
    // 0x84d854: r0 = LoadClassIdInstr(r1)
    //     0x84d854: ldur            x0, [x1, #-1]
    //     0x84d858: ubfx            x0, x0, #0xc, #0x14
    // 0x84d85c: r2 = "deviceId"
    //     0x84d85c: ldr             x2, [PP, #0x3e08]  ; [pp+0x3e08] "deviceId"
    // 0x84d860: r0 = GDT[cid_x0 + -0xd48]()
    //     0x84d860: sub             lr, x0, #0xd48
    //     0x84d864: ldr             lr, [x21, lr, lsl #3]
    //     0x84d868: blr             lr
    // 0x84d86c: mov             x3, x0
    // 0x84d870: r2 = Null
    //     0x84d870: mov             x2, NULL
    // 0x84d874: r1 = Null
    //     0x84d874: mov             x1, NULL
    // 0x84d878: stur            x3, [fp, #-0x20]
    // 0x84d87c: branchIfSmi(r0, 0x84d8a0)
    //     0x84d87c: tbz             w0, #0, #0x84d8a0
    // 0x84d880: r4 = LoadClassIdInstr(r0)
    //     0x84d880: ldur            x4, [x0, #-1]
    //     0x84d884: ubfx            x4, x4, #0xc, #0x14
    // 0x84d888: sub             x4, x4, #0x3c
    // 0x84d88c: cmp             x4, #1
    // 0x84d890: b.ls            #0x84d8a0
    // 0x84d894: r8 = int?
    //     0x84d894: ldr             x8, [PP, #0x3d30]  ; [pp+0x3d30] Type: int?
    // 0x84d898: r3 = Null
    //     0x84d898: ldr             x3, [PP, #0x3e10]  ; [pp+0x3e10] Null
    // 0x84d89c: r0 = int?()
    //     0x84d89c: bl              #0x13ee944  ; IsType_int?_Stub
    // 0x84d8a0: ldur            x0, [fp, #-0x20]
    // 0x84d8a4: cmp             w0, NULL
    // 0x84d8a8: b.ne            #0x84d8b4
    // 0x84d8ac: r11 = 0
    //     0x84d8ac: mov             x11, #0
    // 0x84d8b0: b               #0x84d8c4
    // 0x84d8b4: r1 = LoadInt32Instr(r0)
    //     0x84d8b4: sbfx            x1, x0, #1, #0x1f
    //     0x84d8b8: tbz             w0, #0, #0x84d8c0
    //     0x84d8bc: ldur            x1, [x0, #7]
    // 0x84d8c0: mov             x11, x1
    // 0x84d8c4: ldur            x3, [fp, #-0x10]
    // 0x84d8c8: ldur            x10, [fp, #-0x28]
    // 0x84d8cc: ldur            x9, [fp, #-0x30]
    // 0x84d8d0: ldur            x8, [fp, #-0x38]
    // 0x84d8d4: ldur            x7, [fp, #-0x40]
    // 0x84d8d8: ldur            x6, [fp, #-0x48]
    // 0x84d8dc: ldur            x5, [fp, #-0x50]
    // 0x84d8e0: ldur            x4, [fp, #-0x58]
    // 0x84d8e4: stur            x11, [fp, #-0x60]
    // 0x84d8e8: LoadField: r1 = r3->field_f
    //     0x84d8e8: ldur            w1, [x3, #0xf]
    // 0x84d8ec: DecompressPointer r1
    //     0x84d8ec: add             x1, x1, HEAP, lsl #32
    // 0x84d8f0: r0 = LoadClassIdInstr(r1)
    //     0x84d8f0: ldur            x0, [x1, #-1]
    //     0x84d8f4: ubfx            x0, x0, #0xc, #0x14
    // 0x84d8f8: r2 = "repeatCount"
    //     0x84d8f8: ldr             x2, [PP, #0x3e20]  ; [pp+0x3e20] "repeatCount"
    // 0x84d8fc: r0 = GDT[cid_x0 + -0xd48]()
    //     0x84d8fc: sub             lr, x0, #0xd48
    //     0x84d900: ldr             lr, [x21, lr, lsl #3]
    //     0x84d904: blr             lr
    // 0x84d908: r2 = Null
    //     0x84d908: mov             x2, NULL
    // 0x84d90c: r1 = Null
    //     0x84d90c: mov             x1, NULL
    // 0x84d910: branchIfSmi(r0, 0x84d934)
    //     0x84d910: tbz             w0, #0, #0x84d934
    // 0x84d914: r4 = LoadClassIdInstr(r0)
    //     0x84d914: ldur            x4, [x0, #-1]
    //     0x84d918: ubfx            x4, x4, #0xc, #0x14
    // 0x84d91c: sub             x4, x4, #0x3c
    // 0x84d920: cmp             x4, #1
    // 0x84d924: b.ls            #0x84d934
    // 0x84d928: r8 = int?
    //     0x84d928: ldr             x8, [PP, #0x3d30]  ; [pp+0x3d30] Type: int?
    // 0x84d92c: r3 = Null
    //     0x84d92c: ldr             x3, [PP, #0x3e28]  ; [pp+0x3e28] Null
    // 0x84d930: r0 = int?()
    //     0x84d930: bl              #0x13ee944  ; IsType_int?_Stub
    // 0x84d934: r0 = RawKeyEventDataAndroid()
    //     0x84d934: bl              #0x84eddc  ; AllocateRawKeyEventDataAndroidStub -> RawKeyEventDataAndroid (size=0x48)
    // 0x84d938: mov             x3, x0
    // 0x84d93c: ldur            x0, [fp, #-0x28]
    // 0x84d940: stur            x3, [fp, #-0x20]
    // 0x84d944: StoreField: r3->field_7 = r0
    //     0x84d944: stur            x0, [x3, #7]
    // 0x84d948: ldur            x0, [fp, #-0x30]
    // 0x84d94c: StoreField: r3->field_f = r0
    //     0x84d94c: stur            x0, [x3, #0xf]
    // 0x84d950: ldur            x0, [fp, #-0x40]
    // 0x84d954: ArrayStore: r3[0] = r0  ; List_8
    //     0x84d954: stur            x0, [x3, #0x17]
    // 0x84d958: ldur            x0, [fp, #-0x38]
    // 0x84d95c: StoreField: r3->field_1f = r0
    //     0x84d95c: stur            x0, [x3, #0x1f]
    // 0x84d960: ldur            x0, [fp, #-0x48]
    // 0x84d964: StoreField: r3->field_27 = r0
    //     0x84d964: stur            x0, [x3, #0x27]
    // 0x84d968: ldur            x0, [fp, #-0x50]
    // 0x84d96c: StoreField: r3->field_2f = r0
    //     0x84d96c: stur            x0, [x3, #0x2f]
    // 0x84d970: ldur            x0, [fp, #-0x58]
    // 0x84d974: StoreField: r3->field_37 = r0
    //     0x84d974: stur            x0, [x3, #0x37]
    // 0x84d978: ldur            x0, [fp, #-0x60]
    // 0x84d97c: StoreField: r3->field_3f = r0
    //     0x84d97c: stur            x0, [x3, #0x3f]
    // 0x84d980: ldur            x4, [fp, #-0x10]
    // 0x84d984: LoadField: r1 = r4->field_f
    //     0x84d984: ldur            w1, [x4, #0xf]
    // 0x84d988: DecompressPointer r1
    //     0x84d988: add             x1, x1, HEAP, lsl #32
    // 0x84d98c: r0 = LoadClassIdInstr(r1)
    //     0x84d98c: ldur            x0, [x1, #-1]
    //     0x84d990: ubfx            x0, x0, #0xc, #0x14
    // 0x84d994: r2 = "character"
    //     0x84d994: ldr             x2, [PP, #0x3e38]  ; [pp+0x3e38] "character"
    // 0x84d998: r0 = GDT[cid_x0 + -0x104]()
    //     0x84d998: sub             lr, x0, #0x104
    //     0x84d99c: ldr             lr, [x21, lr, lsl #3]
    //     0x84d9a0: blr             lr
    // 0x84d9a4: tbnz            w0, #4, #0x84da2c
    // 0x84d9a8: ldur            x3, [fp, #-0x10]
    // 0x84d9ac: LoadField: r1 = r3->field_f
    //     0x84d9ac: ldur            w1, [x3, #0xf]
    // 0x84d9b0: DecompressPointer r1
    //     0x84d9b0: add             x1, x1, HEAP, lsl #32
    // 0x84d9b4: r0 = LoadClassIdInstr(r1)
    //     0x84d9b4: ldur            x0, [x1, #-1]
    //     0x84d9b8: ubfx            x0, x0, #0xc, #0x14
    // 0x84d9bc: r2 = "character"
    //     0x84d9bc: ldr             x2, [PP, #0x3e38]  ; [pp+0x3e38] "character"
    // 0x84d9c0: r0 = GDT[cid_x0 + -0xd48]()
    //     0x84d9c0: sub             lr, x0, #0xd48
    //     0x84d9c4: ldr             lr, [x21, lr, lsl #3]
    //     0x84d9c8: blr             lr
    // 0x84d9cc: mov             x3, x0
    // 0x84d9d0: r2 = Null
    //     0x84d9d0: mov             x2, NULL
    // 0x84d9d4: r1 = Null
    //     0x84d9d4: mov             x1, NULL
    // 0x84d9d8: stur            x3, [fp, #-0x68]
    // 0x84d9dc: r4 = 60
    //     0x84d9dc: mov             x4, #0x3c
    // 0x84d9e0: branchIfSmi(r0, 0x84d9ec)
    //     0x84d9e0: tbz             w0, #0, #0x84d9ec
    // 0x84d9e4: r4 = LoadClassIdInstr(r0)
    //     0x84d9e4: ldur            x4, [x0, #-1]
    //     0x84d9e8: ubfx            x4, x4, #0xc, #0x14
    // 0x84d9ec: sub             x4, x4, #0x5e
    // 0x84d9f0: cmp             x4, #1
    // 0x84d9f4: b.ls            #0x84da04
    // 0x84d9f8: r8 = String?
    //     0x84d9f8: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x84d9fc: r3 = Null
    //     0x84d9fc: ldr             x3, [PP, #0x3e40]  ; [pp+0x3e40] Null
    // 0x84da00: r0 = String?()
    //     0x84da00: bl              #0x7db310  ; IsType_String?_Stub
    // 0x84da04: ldur            x0, [fp, #-0x68]
    // 0x84da08: ldur            x1, [fp, #-0x10]
    // 0x84da0c: StoreField: r1->field_13 = r0
    //     0x84da0c: stur            w0, [x1, #0x13]
    //     0x84da10: ldurb           w16, [x1, #-1]
    //     0x84da14: ldurb           w17, [x0, #-1]
    //     0x84da18: and             x16, x17, x16, lsr #2
    //     0x84da1c: tst             x16, HEAP, lsr #32
    //     0x84da20: b.eq            #0x84da28
    //     0x84da24: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x84da28: b               #0x84da30
    // 0x84da2c: ldur            x1, [fp, #-0x10]
    // 0x84da30: mov             x0, x1
    // 0x84da34: ldur            x1, [fp, #-0x20]
    // 0x84da38: b               #0x84e924
    // 0x84da3c: ldur            x1, [fp, #-0x10]
    // 0x84da40: r16 = "fuchsia"
    //     0x84da40: ldr             x16, [PP, #0x3e50]  ; [pp+0x3e50] "fuchsia"
    // 0x84da44: ldur            lr, [fp, #-8]
    // 0x84da48: stp             lr, x16, [SP]
    // 0x84da4c: r0 = ==()
    //     0x84da4c: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x84da50: tbnz            w0, #4, #0x84dc54
    // 0x84da54: ldur            x3, [fp, #-0x10]
    // 0x84da58: LoadField: r1 = r3->field_f
    //     0x84da58: ldur            w1, [x3, #0xf]
    // 0x84da5c: DecompressPointer r1
    //     0x84da5c: add             x1, x1, HEAP, lsl #32
    // 0x84da60: r0 = LoadClassIdInstr(r1)
    //     0x84da60: ldur            x0, [x1, #-1]
    //     0x84da64: ubfx            x0, x0, #0xc, #0x14
    // 0x84da68: r2 = "codePoint"
    //     0x84da68: ldr             x2, [PP, #0x3d48]  ; [pp+0x3d48] "codePoint"
    // 0x84da6c: r0 = GDT[cid_x0 + -0xd48]()
    //     0x84da6c: sub             lr, x0, #0xd48
    //     0x84da70: ldr             lr, [x21, lr, lsl #3]
    //     0x84da74: blr             lr
    // 0x84da78: mov             x3, x0
    // 0x84da7c: r2 = Null
    //     0x84da7c: mov             x2, NULL
    // 0x84da80: r1 = Null
    //     0x84da80: mov             x1, NULL
    // 0x84da84: stur            x3, [fp, #-0x20]
    // 0x84da88: branchIfSmi(r0, 0x84daac)
    //     0x84da88: tbz             w0, #0, #0x84daac
    // 0x84da8c: r4 = LoadClassIdInstr(r0)
    //     0x84da8c: ldur            x4, [x0, #-1]
    //     0x84da90: ubfx            x4, x4, #0xc, #0x14
    // 0x84da94: sub             x4, x4, #0x3c
    // 0x84da98: cmp             x4, #1
    // 0x84da9c: b.ls            #0x84daac
    // 0x84daa0: r8 = int?
    //     0x84daa0: ldr             x8, [PP, #0x3d30]  ; [pp+0x3d30] Type: int?
    // 0x84daa4: r3 = Null
    //     0x84daa4: ldr             x3, [PP, #0x3e58]  ; [pp+0x3e58] Null
    // 0x84daa8: r0 = int?()
    //     0x84daa8: bl              #0x13ee944  ; IsType_int?_Stub
    // 0x84daac: ldur            x0, [fp, #-0x20]
    // 0x84dab0: cmp             w0, NULL
    // 0x84dab4: b.ne            #0x84dac0
    // 0x84dab8: r4 = 0
    //     0x84dab8: mov             x4, #0
    // 0x84dabc: b               #0x84dad0
    // 0x84dac0: r1 = LoadInt32Instr(r0)
    //     0x84dac0: sbfx            x1, x0, #1, #0x1f
    //     0x84dac4: tbz             w0, #0, #0x84dacc
    //     0x84dac8: ldur            x1, [x0, #7]
    // 0x84dacc: mov             x4, x1
    // 0x84dad0: ldur            x3, [fp, #-0x10]
    // 0x84dad4: stur            x4, [fp, #-0x28]
    // 0x84dad8: LoadField: r1 = r3->field_f
    //     0x84dad8: ldur            w1, [x3, #0xf]
    // 0x84dadc: DecompressPointer r1
    //     0x84dadc: add             x1, x1, HEAP, lsl #32
    // 0x84dae0: r0 = LoadClassIdInstr(r1)
    //     0x84dae0: ldur            x0, [x1, #-1]
    //     0x84dae4: ubfx            x0, x0, #0xc, #0x14
    // 0x84dae8: r2 = "hidUsage"
    //     0x84dae8: ldr             x2, [PP, #0x3e68]  ; [pp+0x3e68] "hidUsage"
    // 0x84daec: r0 = GDT[cid_x0 + -0xd48]()
    //     0x84daec: sub             lr, x0, #0xd48
    //     0x84daf0: ldr             lr, [x21, lr, lsl #3]
    //     0x84daf4: blr             lr
    // 0x84daf8: mov             x3, x0
    // 0x84dafc: r2 = Null
    //     0x84dafc: mov             x2, NULL
    // 0x84db00: r1 = Null
    //     0x84db00: mov             x1, NULL
    // 0x84db04: stur            x3, [fp, #-0x20]
    // 0x84db08: branchIfSmi(r0, 0x84db2c)
    //     0x84db08: tbz             w0, #0, #0x84db2c
    // 0x84db0c: r4 = LoadClassIdInstr(r0)
    //     0x84db0c: ldur            x4, [x0, #-1]
    //     0x84db10: ubfx            x4, x4, #0xc, #0x14
    // 0x84db14: sub             x4, x4, #0x3c
    // 0x84db18: cmp             x4, #1
    // 0x84db1c: b.ls            #0x84db2c
    // 0x84db20: r8 = int?
    //     0x84db20: ldr             x8, [PP, #0x3d30]  ; [pp+0x3d30] Type: int?
    // 0x84db24: r3 = Null
    //     0x84db24: ldr             x3, [PP, #0x3e70]  ; [pp+0x3e70] Null
    // 0x84db28: r0 = int?()
    //     0x84db28: bl              #0x13ee944  ; IsType_int?_Stub
    // 0x84db2c: ldur            x0, [fp, #-0x20]
    // 0x84db30: cmp             w0, NULL
    // 0x84db34: b.ne            #0x84db40
    // 0x84db38: r4 = 0
    //     0x84db38: mov             x4, #0
    // 0x84db3c: b               #0x84db50
    // 0x84db40: r1 = LoadInt32Instr(r0)
    //     0x84db40: sbfx            x1, x0, #1, #0x1f
    //     0x84db44: tbz             w0, #0, #0x84db4c
    //     0x84db48: ldur            x1, [x0, #7]
    // 0x84db4c: mov             x4, x1
    // 0x84db50: ldur            x3, [fp, #-0x10]
    // 0x84db54: stur            x4, [fp, #-0x30]
    // 0x84db58: LoadField: r1 = r3->field_f
    //     0x84db58: ldur            w1, [x3, #0xf]
    // 0x84db5c: DecompressPointer r1
    //     0x84db5c: add             x1, x1, HEAP, lsl #32
    // 0x84db60: r0 = LoadClassIdInstr(r1)
    //     0x84db60: ldur            x0, [x1, #-1]
    //     0x84db64: ubfx            x0, x0, #0xc, #0x14
    // 0x84db68: r2 = "modifiers"
    //     0x84db68: ldr             x2, [PP, #0x3e80]  ; [pp+0x3e80] "modifiers"
    // 0x84db6c: r0 = GDT[cid_x0 + -0xd48]()
    //     0x84db6c: sub             lr, x0, #0xd48
    //     0x84db70: ldr             lr, [x21, lr, lsl #3]
    //     0x84db74: blr             lr
    // 0x84db78: mov             x3, x0
    // 0x84db7c: r2 = Null
    //     0x84db7c: mov             x2, NULL
    // 0x84db80: r1 = Null
    //     0x84db80: mov             x1, NULL
    // 0x84db84: stur            x3, [fp, #-0x20]
    // 0x84db88: branchIfSmi(r0, 0x84dbac)
    //     0x84db88: tbz             w0, #0, #0x84dbac
    // 0x84db8c: r4 = LoadClassIdInstr(r0)
    //     0x84db8c: ldur            x4, [x0, #-1]
    //     0x84db90: ubfx            x4, x4, #0xc, #0x14
    // 0x84db94: sub             x4, x4, #0x3c
    // 0x84db98: cmp             x4, #1
    // 0x84db9c: b.ls            #0x84dbac
    // 0x84dba0: r8 = int?
    //     0x84dba0: ldr             x8, [PP, #0x3d30]  ; [pp+0x3d30] Type: int?
    // 0x84dba4: r3 = Null
    //     0x84dba4: ldr             x3, [PP, #0x3e88]  ; [pp+0x3e88] Null
    // 0x84dba8: r0 = int?()
    //     0x84dba8: bl              #0x13ee944  ; IsType_int?_Stub
    // 0x84dbac: ldur            x0, [fp, #-0x20]
    // 0x84dbb0: cmp             w0, NULL
    // 0x84dbb4: b.ne            #0x84dbc0
    // 0x84dbb8: r1 = 0
    //     0x84dbb8: mov             x1, #0
    // 0x84dbbc: b               #0x84dbcc
    // 0x84dbc0: r1 = LoadInt32Instr(r0)
    //     0x84dbc0: sbfx            x1, x0, #1, #0x1f
    //     0x84dbc4: tbz             w0, #0, #0x84dbcc
    //     0x84dbc8: ldur            x1, [x0, #7]
    // 0x84dbcc: ldur            x2, [fp, #-0x28]
    // 0x84dbd0: ldur            x0, [fp, #-0x30]
    // 0x84dbd4: stur            x1, [fp, #-0x38]
    // 0x84dbd8: r0 = RawKeyEventDataFuchsia()
    //     0x84dbd8: bl              #0x84edd0  ; AllocateRawKeyEventDataFuchsiaStub -> RawKeyEventDataFuchsia (size=0x20)
    // 0x84dbdc: mov             x3, x0
    // 0x84dbe0: ldur            x0, [fp, #-0x30]
    // 0x84dbe4: stur            x3, [fp, #-0x20]
    // 0x84dbe8: StoreField: r3->field_7 = r0
    //     0x84dbe8: stur            x0, [x3, #7]
    // 0x84dbec: ldur            x2, [fp, #-0x28]
    // 0x84dbf0: StoreField: r3->field_f = r2
    //     0x84dbf0: stur            x2, [x3, #0xf]
    // 0x84dbf4: ldur            x0, [fp, #-0x38]
    // 0x84dbf8: ArrayStore: r3[0] = r0  ; List_8
    //     0x84dbf8: stur            x0, [x3, #0x17]
    // 0x84dbfc: r0 = BoxInt64Instr(r2)
    //     0x84dbfc: sbfiz           x0, x2, #1, #0x1f
    //     0x84dc00: cmp             x2, x0, asr #1
    //     0x84dc04: b.eq            #0x84dc10
    //     0x84dc08: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x84dc0c: stur            x2, [x0, #7]
    // 0x84dc10: cbz             w0, #0x84dc44
    // 0x84dc14: ldur            x0, [fp, #-0x10]
    // 0x84dc18: r1 = Null
    //     0x84dc18: mov             x1, NULL
    // 0x84dc1c: r0 = String.fromCharCode()
    //     0x84dc1c: bl              #0x7e6340  ; [dart:core] String::String.fromCharCode
    // 0x84dc20: ldur            x1, [fp, #-0x10]
    // 0x84dc24: StoreField: r1->field_13 = r0
    //     0x84dc24: stur            w0, [x1, #0x13]
    //     0x84dc28: ldurb           w16, [x1, #-1]
    //     0x84dc2c: ldurb           w17, [x0, #-1]
    //     0x84dc30: and             x16, x17, x16, lsr #2
    //     0x84dc34: tst             x16, HEAP, lsr #32
    //     0x84dc38: b.eq            #0x84dc40
    //     0x84dc3c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x84dc40: b               #0x84dc48
    // 0x84dc44: ldur            x1, [fp, #-0x10]
    // 0x84dc48: mov             x0, x1
    // 0x84dc4c: ldur            x1, [fp, #-0x20]
    // 0x84dc50: b               #0x84e924
    // 0x84dc54: ldur            x1, [fp, #-0x10]
    // 0x84dc58: r16 = "macos"
    //     0x84dc58: ldr             x16, [PP, #0x3e98]  ; [pp+0x3e98] "macos"
    // 0x84dc5c: ldur            lr, [fp, #-8]
    // 0x84dc60: stp             lr, x16, [SP]
    // 0x84dc64: r0 = ==()
    //     0x84dc64: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x84dc68: tbnz            w0, #4, #0x84df80
    // 0x84dc6c: ldur            x3, [fp, #-0x10]
    // 0x84dc70: LoadField: r1 = r3->field_f
    //     0x84dc70: ldur            w1, [x3, #0xf]
    // 0x84dc74: DecompressPointer r1
    //     0x84dc74: add             x1, x1, HEAP, lsl #32
    // 0x84dc78: r0 = LoadClassIdInstr(r1)
    //     0x84dc78: ldur            x0, [x1, #-1]
    //     0x84dc7c: ubfx            x0, x0, #0xc, #0x14
    // 0x84dc80: r2 = "characters"
    //     0x84dc80: ldr             x2, [PP, #0x3ea0]  ; [pp+0x3ea0] "characters"
    // 0x84dc84: r0 = GDT[cid_x0 + -0xd48]()
    //     0x84dc84: sub             lr, x0, #0xd48
    //     0x84dc88: ldr             lr, [x21, lr, lsl #3]
    //     0x84dc8c: blr             lr
    // 0x84dc90: mov             x3, x0
    // 0x84dc94: r2 = Null
    //     0x84dc94: mov             x2, NULL
    // 0x84dc98: r1 = Null
    //     0x84dc98: mov             x1, NULL
    // 0x84dc9c: stur            x3, [fp, #-0x20]
    // 0x84dca0: r4 = 60
    //     0x84dca0: mov             x4, #0x3c
    // 0x84dca4: branchIfSmi(r0, 0x84dcb0)
    //     0x84dca4: tbz             w0, #0, #0x84dcb0
    // 0x84dca8: r4 = LoadClassIdInstr(r0)
    //     0x84dca8: ldur            x4, [x0, #-1]
    //     0x84dcac: ubfx            x4, x4, #0xc, #0x14
    // 0x84dcb0: sub             x4, x4, #0x5e
    // 0x84dcb4: cmp             x4, #1
    // 0x84dcb8: b.ls            #0x84dcc8
    // 0x84dcbc: r8 = String?
    //     0x84dcbc: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x84dcc0: r3 = Null
    //     0x84dcc0: ldr             x3, [PP, #0x3ea8]  ; [pp+0x3ea8] Null
    // 0x84dcc4: r0 = String?()
    //     0x84dcc4: bl              #0x7db310  ; IsType_String?_Stub
    // 0x84dcc8: ldur            x0, [fp, #-0x20]
    // 0x84dccc: cmp             w0, NULL
    // 0x84dcd0: b.ne            #0x84dcdc
    // 0x84dcd4: r4 = ""
    //     0x84dcd4: ldr             x4, [PP, #0x900]  ; [pp+0x900] ""
    // 0x84dcd8: b               #0x84dce0
    // 0x84dcdc: mov             x4, x0
    // 0x84dce0: ldur            x3, [fp, #-0x10]
    // 0x84dce4: stur            x4, [fp, #-0x20]
    // 0x84dce8: LoadField: r1 = r3->field_f
    //     0x84dce8: ldur            w1, [x3, #0xf]
    // 0x84dcec: DecompressPointer r1
    //     0x84dcec: add             x1, x1, HEAP, lsl #32
    // 0x84dcf0: r0 = LoadClassIdInstr(r1)
    //     0x84dcf0: ldur            x0, [x1, #-1]
    //     0x84dcf4: ubfx            x0, x0, #0xc, #0x14
    // 0x84dcf8: r2 = "charactersIgnoringModifiers"
    //     0x84dcf8: ldr             x2, [PP, #0x3eb8]  ; [pp+0x3eb8] "charactersIgnoringModifiers"
    // 0x84dcfc: r0 = GDT[cid_x0 + -0xd48]()
    //     0x84dcfc: sub             lr, x0, #0xd48
    //     0x84dd00: ldr             lr, [x21, lr, lsl #3]
    //     0x84dd04: blr             lr
    // 0x84dd08: mov             x3, x0
    // 0x84dd0c: r2 = Null
    //     0x84dd0c: mov             x2, NULL
    // 0x84dd10: r1 = Null
    //     0x84dd10: mov             x1, NULL
    // 0x84dd14: stur            x3, [fp, #-0x68]
    // 0x84dd18: r4 = 60
    //     0x84dd18: mov             x4, #0x3c
    // 0x84dd1c: branchIfSmi(r0, 0x84dd28)
    //     0x84dd1c: tbz             w0, #0, #0x84dd28
    // 0x84dd20: r4 = LoadClassIdInstr(r0)
    //     0x84dd20: ldur            x4, [x0, #-1]
    //     0x84dd24: ubfx            x4, x4, #0xc, #0x14
    // 0x84dd28: sub             x4, x4, #0x5e
    // 0x84dd2c: cmp             x4, #1
    // 0x84dd30: b.ls            #0x84dd40
    // 0x84dd34: r8 = String?
    //     0x84dd34: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x84dd38: r3 = Null
    //     0x84dd38: ldr             x3, [PP, #0x3ec0]  ; [pp+0x3ec0] Null
    // 0x84dd3c: r0 = String?()
    //     0x84dd3c: bl              #0x7db310  ; IsType_String?_Stub
    // 0x84dd40: ldur            x0, [fp, #-0x68]
    // 0x84dd44: cmp             w0, NULL
    // 0x84dd48: b.ne            #0x84dd54
    // 0x84dd4c: r4 = ""
    //     0x84dd4c: ldr             x4, [PP, #0x900]  ; [pp+0x900] ""
    // 0x84dd50: b               #0x84dd58
    // 0x84dd54: mov             x4, x0
    // 0x84dd58: ldur            x3, [fp, #-0x10]
    // 0x84dd5c: stur            x4, [fp, #-0x68]
    // 0x84dd60: LoadField: r1 = r3->field_f
    //     0x84dd60: ldur            w1, [x3, #0xf]
    // 0x84dd64: DecompressPointer r1
    //     0x84dd64: add             x1, x1, HEAP, lsl #32
    // 0x84dd68: r0 = LoadClassIdInstr(r1)
    //     0x84dd68: ldur            x0, [x1, #-1]
    //     0x84dd6c: ubfx            x0, x0, #0xc, #0x14
    // 0x84dd70: r2 = "keyCode"
    //     0x84dd70: ldr             x2, [PP, #0x3d60]  ; [pp+0x3d60] "keyCode"
    // 0x84dd74: r0 = GDT[cid_x0 + -0xd48]()
    //     0x84dd74: sub             lr, x0, #0xd48
    //     0x84dd78: ldr             lr, [x21, lr, lsl #3]
    //     0x84dd7c: blr             lr
    // 0x84dd80: mov             x3, x0
    // 0x84dd84: r2 = Null
    //     0x84dd84: mov             x2, NULL
    // 0x84dd88: r1 = Null
    //     0x84dd88: mov             x1, NULL
    // 0x84dd8c: stur            x3, [fp, #-0x70]
    // 0x84dd90: branchIfSmi(r0, 0x84ddb4)
    //     0x84dd90: tbz             w0, #0, #0x84ddb4
    // 0x84dd94: r4 = LoadClassIdInstr(r0)
    //     0x84dd94: ldur            x4, [x0, #-1]
    //     0x84dd98: ubfx            x4, x4, #0xc, #0x14
    // 0x84dd9c: sub             x4, x4, #0x3c
    // 0x84dda0: cmp             x4, #1
    // 0x84dda4: b.ls            #0x84ddb4
    // 0x84dda8: r8 = int?
    //     0x84dda8: ldr             x8, [PP, #0x3d30]  ; [pp+0x3d30] Type: int?
    // 0x84ddac: r3 = Null
    //     0x84ddac: ldr             x3, [PP, #0x3ed0]  ; [pp+0x3ed0] Null
    // 0x84ddb0: r0 = int?()
    //     0x84ddb0: bl              #0x13ee944  ; IsType_int?_Stub
    // 0x84ddb4: ldur            x0, [fp, #-0x70]
    // 0x84ddb8: cmp             w0, NULL
    // 0x84ddbc: b.ne            #0x84ddc8
    // 0x84ddc0: r4 = 0
    //     0x84ddc0: mov             x4, #0
    // 0x84ddc4: b               #0x84ddd8
    // 0x84ddc8: r1 = LoadInt32Instr(r0)
    //     0x84ddc8: sbfx            x1, x0, #1, #0x1f
    //     0x84ddcc: tbz             w0, #0, #0x84ddd4
    //     0x84ddd0: ldur            x1, [x0, #7]
    // 0x84ddd4: mov             x4, x1
    // 0x84ddd8: ldur            x3, [fp, #-0x10]
    // 0x84dddc: stur            x4, [fp, #-0x28]
    // 0x84dde0: LoadField: r1 = r3->field_f
    //     0x84dde0: ldur            w1, [x3, #0xf]
    // 0x84dde4: DecompressPointer r1
    //     0x84dde4: add             x1, x1, HEAP, lsl #32
    // 0x84dde8: r0 = LoadClassIdInstr(r1)
    //     0x84dde8: ldur            x0, [x1, #-1]
    //     0x84ddec: ubfx            x0, x0, #0xc, #0x14
    // 0x84ddf0: r2 = "modifiers"
    //     0x84ddf0: ldr             x2, [PP, #0x3e80]  ; [pp+0x3e80] "modifiers"
    // 0x84ddf4: r0 = GDT[cid_x0 + -0xd48]()
    //     0x84ddf4: sub             lr, x0, #0xd48
    //     0x84ddf8: ldr             lr, [x21, lr, lsl #3]
    //     0x84ddfc: blr             lr
    // 0x84de00: mov             x3, x0
    // 0x84de04: r2 = Null
    //     0x84de04: mov             x2, NULL
    // 0x84de08: r1 = Null
    //     0x84de08: mov             x1, NULL
    // 0x84de0c: stur            x3, [fp, #-0x70]
    // 0x84de10: branchIfSmi(r0, 0x84de34)
    //     0x84de10: tbz             w0, #0, #0x84de34
    // 0x84de14: r4 = LoadClassIdInstr(r0)
    //     0x84de14: ldur            x4, [x0, #-1]
    //     0x84de18: ubfx            x4, x4, #0xc, #0x14
    // 0x84de1c: sub             x4, x4, #0x3c
    // 0x84de20: cmp             x4, #1
    // 0x84de24: b.ls            #0x84de34
    // 0x84de28: r8 = int?
    //     0x84de28: ldr             x8, [PP, #0x3d30]  ; [pp+0x3d30] Type: int?
    // 0x84de2c: r3 = Null
    //     0x84de2c: ldr             x3, [PP, #0x3ee0]  ; [pp+0x3ee0] Null
    // 0x84de30: r0 = int?()
    //     0x84de30: bl              #0x13ee944  ; IsType_int?_Stub
    // 0x84de34: ldur            x0, [fp, #-0x70]
    // 0x84de38: cmp             w0, NULL
    // 0x84de3c: b.ne            #0x84de48
    // 0x84de40: r7 = 0
    //     0x84de40: mov             x7, #0
    // 0x84de44: b               #0x84de58
    // 0x84de48: r1 = LoadInt32Instr(r0)
    //     0x84de48: sbfx            x1, x0, #1, #0x1f
    //     0x84de4c: tbz             w0, #0, #0x84de54
    //     0x84de50: ldur            x1, [x0, #7]
    // 0x84de54: mov             x7, x1
    // 0x84de58: ldur            x3, [fp, #-0x10]
    // 0x84de5c: ldur            x6, [fp, #-0x20]
    // 0x84de60: ldur            x5, [fp, #-0x68]
    // 0x84de64: ldur            x4, [fp, #-0x28]
    // 0x84de68: stur            x7, [fp, #-0x30]
    // 0x84de6c: LoadField: r1 = r3->field_f
    //     0x84de6c: ldur            w1, [x3, #0xf]
    // 0x84de70: DecompressPointer r1
    //     0x84de70: add             x1, x1, HEAP, lsl #32
    // 0x84de74: r0 = LoadClassIdInstr(r1)
    //     0x84de74: ldur            x0, [x1, #-1]
    //     0x84de78: ubfx            x0, x0, #0xc, #0x14
    // 0x84de7c: r2 = "specifiedLogicalKey"
    //     0x84de7c: ldr             x2, [PP, #0x3ef0]  ; [pp+0x3ef0] "specifiedLogicalKey"
    // 0x84de80: r0 = GDT[cid_x0 + -0xd48]()
    //     0x84de80: sub             lr, x0, #0xd48
    //     0x84de84: ldr             lr, [x21, lr, lsl #3]
    //     0x84de88: blr             lr
    // 0x84de8c: mov             x3, x0
    // 0x84de90: r2 = Null
    //     0x84de90: mov             x2, NULL
    // 0x84de94: r1 = Null
    //     0x84de94: mov             x1, NULL
    // 0x84de98: stur            x3, [fp, #-0x70]
    // 0x84de9c: branchIfSmi(r0, 0x84dec0)
    //     0x84de9c: tbz             w0, #0, #0x84dec0
    // 0x84dea0: r4 = LoadClassIdInstr(r0)
    //     0x84dea0: ldur            x4, [x0, #-1]
    //     0x84dea4: ubfx            x4, x4, #0xc, #0x14
    // 0x84dea8: sub             x4, x4, #0x3c
    // 0x84deac: cmp             x4, #1
    // 0x84deb0: b.ls            #0x84dec0
    // 0x84deb4: r8 = int?
    //     0x84deb4: ldr             x8, [PP, #0x3d30]  ; [pp+0x3d30] Type: int?
    // 0x84deb8: r3 = Null
    //     0x84deb8: ldr             x3, [PP, #0x3ef8]  ; [pp+0x3ef8] Null
    // 0x84debc: r0 = int?()
    //     0x84debc: bl              #0x13ee944  ; IsType_int?_Stub
    // 0x84dec0: r0 = RawKeyEventDataMacOs()
    //     0x84dec0: bl              #0x84edc4  ; AllocateRawKeyEventDataMacOsStub -> RawKeyEventDataMacOs (size=0x24)
    // 0x84dec4: mov             x3, x0
    // 0x84dec8: ldur            x0, [fp, #-0x20]
    // 0x84decc: stur            x3, [fp, #-0x78]
    // 0x84ded0: StoreField: r3->field_7 = r0
    //     0x84ded0: stur            w0, [x3, #7]
    // 0x84ded4: ldur            x0, [fp, #-0x68]
    // 0x84ded8: StoreField: r3->field_b = r0
    //     0x84ded8: stur            w0, [x3, #0xb]
    // 0x84dedc: ldur            x0, [fp, #-0x28]
    // 0x84dee0: StoreField: r3->field_f = r0
    //     0x84dee0: stur            x0, [x3, #0xf]
    // 0x84dee4: ldur            x0, [fp, #-0x30]
    // 0x84dee8: ArrayStore: r3[0] = r0  ; List_8
    //     0x84dee8: stur            x0, [x3, #0x17]
    // 0x84deec: ldur            x0, [fp, #-0x70]
    // 0x84def0: StoreField: r3->field_1f = r0
    //     0x84def0: stur            w0, [x3, #0x1f]
    // 0x84def4: ldur            x4, [fp, #-0x10]
    // 0x84def8: LoadField: r1 = r4->field_f
    //     0x84def8: ldur            w1, [x4, #0xf]
    // 0x84defc: DecompressPointer r1
    //     0x84defc: add             x1, x1, HEAP, lsl #32
    // 0x84df00: r0 = LoadClassIdInstr(r1)
    //     0x84df00: ldur            x0, [x1, #-1]
    //     0x84df04: ubfx            x0, x0, #0xc, #0x14
    // 0x84df08: r2 = "characters"
    //     0x84df08: ldr             x2, [PP, #0x3ea0]  ; [pp+0x3ea0] "characters"
    // 0x84df0c: r0 = GDT[cid_x0 + -0xd48]()
    //     0x84df0c: sub             lr, x0, #0xd48
    //     0x84df10: ldr             lr, [x21, lr, lsl #3]
    //     0x84df14: blr             lr
    // 0x84df18: mov             x3, x0
    // 0x84df1c: r2 = Null
    //     0x84df1c: mov             x2, NULL
    // 0x84df20: r1 = Null
    //     0x84df20: mov             x1, NULL
    // 0x84df24: stur            x3, [fp, #-0x20]
    // 0x84df28: r4 = 60
    //     0x84df28: mov             x4, #0x3c
    // 0x84df2c: branchIfSmi(r0, 0x84df38)
    //     0x84df2c: tbz             w0, #0, #0x84df38
    // 0x84df30: r4 = LoadClassIdInstr(r0)
    //     0x84df30: ldur            x4, [x0, #-1]
    //     0x84df34: ubfx            x4, x4, #0xc, #0x14
    // 0x84df38: sub             x4, x4, #0x5e
    // 0x84df3c: cmp             x4, #1
    // 0x84df40: b.ls            #0x84df50
    // 0x84df44: r8 = String?
    //     0x84df44: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x84df48: r3 = Null
    //     0x84df48: ldr             x3, [PP, #0x3f08]  ; [pp+0x3f08] Null
    // 0x84df4c: r0 = String?()
    //     0x84df4c: bl              #0x7db310  ; IsType_String?_Stub
    // 0x84df50: ldur            x0, [fp, #-0x20]
    // 0x84df54: ldur            x1, [fp, #-0x10]
    // 0x84df58: StoreField: r1->field_13 = r0
    //     0x84df58: stur            w0, [x1, #0x13]
    //     0x84df5c: ldurb           w16, [x1, #-1]
    //     0x84df60: ldurb           w17, [x0, #-1]
    //     0x84df64: and             x16, x17, x16, lsr #2
    //     0x84df68: tst             x16, HEAP, lsr #32
    //     0x84df6c: b.eq            #0x84df74
    //     0x84df70: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x84df74: mov             x0, x1
    // 0x84df78: ldur            x1, [fp, #-0x78]
    // 0x84df7c: b               #0x84e924
    // 0x84df80: ldur            x1, [fp, #-0x10]
    // 0x84df84: r16 = "ios"
    //     0x84df84: ldr             x16, [PP, #0x3f18]  ; [pp+0x3f18] "ios"
    // 0x84df88: ldur            lr, [fp, #-8]
    // 0x84df8c: stp             lr, x16, [SP]
    // 0x84df90: r0 = ==()
    //     0x84df90: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x84df94: tbnz            w0, #4, #0x84e24c
    // 0x84df98: ldur            x3, [fp, #-0x10]
    // 0x84df9c: LoadField: r1 = r3->field_f
    //     0x84df9c: ldur            w1, [x3, #0xf]
    // 0x84dfa0: DecompressPointer r1
    //     0x84dfa0: add             x1, x1, HEAP, lsl #32
    // 0x84dfa4: r0 = LoadClassIdInstr(r1)
    //     0x84dfa4: ldur            x0, [x1, #-1]
    //     0x84dfa8: ubfx            x0, x0, #0xc, #0x14
    // 0x84dfac: r2 = "characters"
    //     0x84dfac: ldr             x2, [PP, #0x3ea0]  ; [pp+0x3ea0] "characters"
    // 0x84dfb0: r0 = GDT[cid_x0 + -0xd48]()
    //     0x84dfb0: sub             lr, x0, #0xd48
    //     0x84dfb4: ldr             lr, [x21, lr, lsl #3]
    //     0x84dfb8: blr             lr
    // 0x84dfbc: mov             x3, x0
    // 0x84dfc0: r2 = Null
    //     0x84dfc0: mov             x2, NULL
    // 0x84dfc4: r1 = Null
    //     0x84dfc4: mov             x1, NULL
    // 0x84dfc8: stur            x3, [fp, #-0x20]
    // 0x84dfcc: r4 = 60
    //     0x84dfcc: mov             x4, #0x3c
    // 0x84dfd0: branchIfSmi(r0, 0x84dfdc)
    //     0x84dfd0: tbz             w0, #0, #0x84dfdc
    // 0x84dfd4: r4 = LoadClassIdInstr(r0)
    //     0x84dfd4: ldur            x4, [x0, #-1]
    //     0x84dfd8: ubfx            x4, x4, #0xc, #0x14
    // 0x84dfdc: sub             x4, x4, #0x5e
    // 0x84dfe0: cmp             x4, #1
    // 0x84dfe4: b.ls            #0x84dff4
    // 0x84dfe8: r8 = String?
    //     0x84dfe8: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x84dfec: r3 = Null
    //     0x84dfec: ldr             x3, [PP, #0x3f20]  ; [pp+0x3f20] Null
    // 0x84dff0: r0 = String?()
    //     0x84dff0: bl              #0x7db310  ; IsType_String?_Stub
    // 0x84dff4: ldur            x0, [fp, #-0x20]
    // 0x84dff8: cmp             w0, NULL
    // 0x84dffc: b.ne            #0x84e008
    // 0x84e000: r4 = ""
    //     0x84e000: ldr             x4, [PP, #0x900]  ; [pp+0x900] ""
    // 0x84e004: b               #0x84e00c
    // 0x84e008: mov             x4, x0
    // 0x84e00c: ldur            x3, [fp, #-0x10]
    // 0x84e010: stur            x4, [fp, #-0x20]
    // 0x84e014: LoadField: r1 = r3->field_f
    //     0x84e014: ldur            w1, [x3, #0xf]
    // 0x84e018: DecompressPointer r1
    //     0x84e018: add             x1, x1, HEAP, lsl #32
    // 0x84e01c: r0 = LoadClassIdInstr(r1)
    //     0x84e01c: ldur            x0, [x1, #-1]
    //     0x84e020: ubfx            x0, x0, #0xc, #0x14
    // 0x84e024: r2 = "charactersIgnoringModifiers"
    //     0x84e024: ldr             x2, [PP, #0x3eb8]  ; [pp+0x3eb8] "charactersIgnoringModifiers"
    // 0x84e028: r0 = GDT[cid_x0 + -0xd48]()
    //     0x84e028: sub             lr, x0, #0xd48
    //     0x84e02c: ldr             lr, [x21, lr, lsl #3]
    //     0x84e030: blr             lr
    // 0x84e034: mov             x3, x0
    // 0x84e038: r2 = Null
    //     0x84e038: mov             x2, NULL
    // 0x84e03c: r1 = Null
    //     0x84e03c: mov             x1, NULL
    // 0x84e040: stur            x3, [fp, #-0x68]
    // 0x84e044: r4 = 60
    //     0x84e044: mov             x4, #0x3c
    // 0x84e048: branchIfSmi(r0, 0x84e054)
    //     0x84e048: tbz             w0, #0, #0x84e054
    // 0x84e04c: r4 = LoadClassIdInstr(r0)
    //     0x84e04c: ldur            x4, [x0, #-1]
    //     0x84e050: ubfx            x4, x4, #0xc, #0x14
    // 0x84e054: sub             x4, x4, #0x5e
    // 0x84e058: cmp             x4, #1
    // 0x84e05c: b.ls            #0x84e06c
    // 0x84e060: r8 = String?
    //     0x84e060: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x84e064: r3 = Null
    //     0x84e064: ldr             x3, [PP, #0x3f30]  ; [pp+0x3f30] Null
    // 0x84e068: r0 = String?()
    //     0x84e068: bl              #0x7db310  ; IsType_String?_Stub
    // 0x84e06c: ldur            x0, [fp, #-0x68]
    // 0x84e070: cmp             w0, NULL
    // 0x84e074: b.ne            #0x84e080
    // 0x84e078: r4 = ""
    //     0x84e078: ldr             x4, [PP, #0x900]  ; [pp+0x900] ""
    // 0x84e07c: b               #0x84e084
    // 0x84e080: mov             x4, x0
    // 0x84e084: ldur            x3, [fp, #-0x10]
    // 0x84e088: stur            x4, [fp, #-0x68]
    // 0x84e08c: LoadField: r1 = r3->field_f
    //     0x84e08c: ldur            w1, [x3, #0xf]
    // 0x84e090: DecompressPointer r1
    //     0x84e090: add             x1, x1, HEAP, lsl #32
    // 0x84e094: r0 = LoadClassIdInstr(r1)
    //     0x84e094: ldur            x0, [x1, #-1]
    //     0x84e098: ubfx            x0, x0, #0xc, #0x14
    // 0x84e09c: r2 = "keyCode"
    //     0x84e09c: ldr             x2, [PP, #0x3d60]  ; [pp+0x3d60] "keyCode"
    // 0x84e0a0: r0 = GDT[cid_x0 + -0xd48]()
    //     0x84e0a0: sub             lr, x0, #0xd48
    //     0x84e0a4: ldr             lr, [x21, lr, lsl #3]
    //     0x84e0a8: blr             lr
    // 0x84e0ac: mov             x3, x0
    // 0x84e0b0: r2 = Null
    //     0x84e0b0: mov             x2, NULL
    // 0x84e0b4: r1 = Null
    //     0x84e0b4: mov             x1, NULL
    // 0x84e0b8: stur            x3, [fp, #-0x70]
    // 0x84e0bc: branchIfSmi(r0, 0x84e0e0)
    //     0x84e0bc: tbz             w0, #0, #0x84e0e0
    // 0x84e0c0: r4 = LoadClassIdInstr(r0)
    //     0x84e0c0: ldur            x4, [x0, #-1]
    //     0x84e0c4: ubfx            x4, x4, #0xc, #0x14
    // 0x84e0c8: sub             x4, x4, #0x3c
    // 0x84e0cc: cmp             x4, #1
    // 0x84e0d0: b.ls            #0x84e0e0
    // 0x84e0d4: r8 = int?
    //     0x84e0d4: ldr             x8, [PP, #0x3d30]  ; [pp+0x3d30] Type: int?
    // 0x84e0d8: r3 = Null
    //     0x84e0d8: ldr             x3, [PP, #0x3f40]  ; [pp+0x3f40] Null
    // 0x84e0dc: r0 = int?()
    //     0x84e0dc: bl              #0x13ee944  ; IsType_int?_Stub
    // 0x84e0e0: ldur            x0, [fp, #-0x70]
    // 0x84e0e4: cmp             w0, NULL
    // 0x84e0e8: b.ne            #0x84e0f4
    // 0x84e0ec: r4 = 0
    //     0x84e0ec: mov             x4, #0
    // 0x84e0f0: b               #0x84e104
    // 0x84e0f4: r1 = LoadInt32Instr(r0)
    //     0x84e0f4: sbfx            x1, x0, #1, #0x1f
    //     0x84e0f8: tbz             w0, #0, #0x84e100
    //     0x84e0fc: ldur            x1, [x0, #7]
    // 0x84e100: mov             x4, x1
    // 0x84e104: ldur            x3, [fp, #-0x10]
    // 0x84e108: stur            x4, [fp, #-0x28]
    // 0x84e10c: LoadField: r1 = r3->field_f
    //     0x84e10c: ldur            w1, [x3, #0xf]
    // 0x84e110: DecompressPointer r1
    //     0x84e110: add             x1, x1, HEAP, lsl #32
    // 0x84e114: r0 = LoadClassIdInstr(r1)
    //     0x84e114: ldur            x0, [x1, #-1]
    //     0x84e118: ubfx            x0, x0, #0xc, #0x14
    // 0x84e11c: r2 = "modifiers"
    //     0x84e11c: ldr             x2, [PP, #0x3e80]  ; [pp+0x3e80] "modifiers"
    // 0x84e120: r0 = GDT[cid_x0 + -0xd48]()
    //     0x84e120: sub             lr, x0, #0xd48
    //     0x84e124: ldr             lr, [x21, lr, lsl #3]
    //     0x84e128: blr             lr
    // 0x84e12c: mov             x3, x0
    // 0x84e130: r2 = Null
    //     0x84e130: mov             x2, NULL
    // 0x84e134: r1 = Null
    //     0x84e134: mov             x1, NULL
    // 0x84e138: stur            x3, [fp, #-0x70]
    // 0x84e13c: branchIfSmi(r0, 0x84e160)
    //     0x84e13c: tbz             w0, #0, #0x84e160
    // 0x84e140: r4 = LoadClassIdInstr(r0)
    //     0x84e140: ldur            x4, [x0, #-1]
    //     0x84e144: ubfx            x4, x4, #0xc, #0x14
    // 0x84e148: sub             x4, x4, #0x3c
    // 0x84e14c: cmp             x4, #1
    // 0x84e150: b.ls            #0x84e160
    // 0x84e154: r8 = int?
    //     0x84e154: ldr             x8, [PP, #0x3d30]  ; [pp+0x3d30] Type: int?
    // 0x84e158: r3 = Null
    //     0x84e158: ldr             x3, [PP, #0x3f50]  ; [pp+0x3f50] Null
    // 0x84e15c: r0 = int?()
    //     0x84e15c: bl              #0x13ee944  ; IsType_int?_Stub
    // 0x84e160: ldur            x0, [fp, #-0x70]
    // 0x84e164: cmp             w0, NULL
    // 0x84e168: b.ne            #0x84e174
    // 0x84e16c: r4 = 0
    //     0x84e16c: mov             x4, #0
    // 0x84e170: b               #0x84e184
    // 0x84e174: r1 = LoadInt32Instr(r0)
    //     0x84e174: sbfx            x1, x0, #1, #0x1f
    //     0x84e178: tbz             w0, #0, #0x84e180
    //     0x84e17c: ldur            x1, [x0, #7]
    // 0x84e180: mov             x4, x1
    // 0x84e184: ldur            x0, [fp, #-0x10]
    // 0x84e188: ldur            x3, [fp, #-0x20]
    // 0x84e18c: ldur            x2, [fp, #-0x68]
    // 0x84e190: ldur            x1, [fp, #-0x28]
    // 0x84e194: stur            x4, [fp, #-0x30]
    // 0x84e198: r0 = RawKeyEventDataIos()
    //     0x84e198: bl              #0x84edb8  ; AllocateRawKeyEventDataIosStub -> RawKeyEventDataIos (size=0x20)
    // 0x84e19c: mov             x3, x0
    // 0x84e1a0: ldur            x0, [fp, #-0x20]
    // 0x84e1a4: stur            x3, [fp, #-0x70]
    // 0x84e1a8: StoreField: r3->field_7 = r0
    //     0x84e1a8: stur            w0, [x3, #7]
    // 0x84e1ac: ldur            x0, [fp, #-0x68]
    // 0x84e1b0: StoreField: r3->field_b = r0
    //     0x84e1b0: stur            w0, [x3, #0xb]
    // 0x84e1b4: ldur            x0, [fp, #-0x28]
    // 0x84e1b8: StoreField: r3->field_f = r0
    //     0x84e1b8: stur            x0, [x3, #0xf]
    // 0x84e1bc: ldur            x0, [fp, #-0x30]
    // 0x84e1c0: ArrayStore: r3[0] = r0  ; List_8
    //     0x84e1c0: stur            x0, [x3, #0x17]
    // 0x84e1c4: ldur            x4, [fp, #-0x10]
    // 0x84e1c8: LoadField: r1 = r4->field_f
    //     0x84e1c8: ldur            w1, [x4, #0xf]
    // 0x84e1cc: DecompressPointer r1
    //     0x84e1cc: add             x1, x1, HEAP, lsl #32
    // 0x84e1d0: r0 = LoadClassIdInstr(r1)
    //     0x84e1d0: ldur            x0, [x1, #-1]
    //     0x84e1d4: ubfx            x0, x0, #0xc, #0x14
    // 0x84e1d8: r2 = "characters"
    //     0x84e1d8: ldr             x2, [PP, #0x3ea0]  ; [pp+0x3ea0] "characters"
    // 0x84e1dc: r0 = GDT[cid_x0 + -0xd48]()
    //     0x84e1dc: sub             lr, x0, #0xd48
    //     0x84e1e0: ldr             lr, [x21, lr, lsl #3]
    //     0x84e1e4: blr             lr
    // 0x84e1e8: r1 = 60
    //     0x84e1e8: mov             x1, #0x3c
    // 0x84e1ec: branchIfSmi(r0, 0x84e1f8)
    //     0x84e1ec: tbz             w0, #0, #0x84e1f8
    // 0x84e1f0: r1 = LoadClassIdInstr(r0)
    //     0x84e1f0: ldur            x1, [x0, #-1]
    //     0x84e1f4: ubfx            x1, x1, #0xc, #0x14
    // 0x84e1f8: sub             x16, x1, #0x5e
    // 0x84e1fc: cmp             x16, #1
    // 0x84e200: b.hi            #0x84e23c
    // 0x84e204: LoadField: r1 = r0->field_7
    //     0x84e204: ldur            w1, [x0, #7]
    // 0x84e208: cbz             w1, #0x84e234
    // 0x84e20c: ldur            x1, [fp, #-0x10]
    // 0x84e210: StoreField: r1->field_13 = r0
    //     0x84e210: stur            w0, [x1, #0x13]
    //     0x84e214: tbz             w0, #0, #0x84e230
    //     0x84e218: ldurb           w16, [x1, #-1]
    //     0x84e21c: ldurb           w17, [x0, #-1]
    //     0x84e220: and             x16, x17, x16, lsr #2
    //     0x84e224: tst             x16, HEAP, lsr #32
    //     0x84e228: b.eq            #0x84e230
    //     0x84e22c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x84e230: b               #0x84e240
    // 0x84e234: ldur            x1, [fp, #-0x10]
    // 0x84e238: b               #0x84e240
    // 0x84e23c: ldur            x1, [fp, #-0x10]
    // 0x84e240: mov             x0, x1
    // 0x84e244: ldur            x1, [fp, #-0x70]
    // 0x84e248: b               #0x84e924
    // 0x84e24c: ldur            x1, [fp, #-0x10]
    // 0x84e250: r16 = "linux"
    //     0x84e250: ldr             x16, [PP, #0x3f60]  ; [pp+0x3f60] "linux"
    // 0x84e254: ldur            lr, [fp, #-8]
    // 0x84e258: stp             lr, x16, [SP]
    // 0x84e25c: r0 = ==()
    //     0x84e25c: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x84e260: tbnz            w0, #4, #0x84e644
    // 0x84e264: ldur            x3, [fp, #-0x10]
    // 0x84e268: LoadField: r1 = r3->field_f
    //     0x84e268: ldur            w1, [x3, #0xf]
    // 0x84e26c: DecompressPointer r1
    //     0x84e26c: add             x1, x1, HEAP, lsl #32
    // 0x84e270: r0 = LoadClassIdInstr(r1)
    //     0x84e270: ldur            x0, [x1, #-1]
    //     0x84e274: ubfx            x0, x0, #0xc, #0x14
    // 0x84e278: r2 = "unicodeScalarValues"
    //     0x84e278: ldr             x2, [PP, #0x3f68]  ; [pp+0x3f68] "unicodeScalarValues"
    // 0x84e27c: r0 = GDT[cid_x0 + -0xd48]()
    //     0x84e27c: sub             lr, x0, #0xd48
    //     0x84e280: ldr             lr, [x21, lr, lsl #3]
    //     0x84e284: blr             lr
    // 0x84e288: mov             x3, x0
    // 0x84e28c: r2 = Null
    //     0x84e28c: mov             x2, NULL
    // 0x84e290: r1 = Null
    //     0x84e290: mov             x1, NULL
    // 0x84e294: stur            x3, [fp, #-0x20]
    // 0x84e298: branchIfSmi(r0, 0x84e2bc)
    //     0x84e298: tbz             w0, #0, #0x84e2bc
    // 0x84e29c: r4 = LoadClassIdInstr(r0)
    //     0x84e29c: ldur            x4, [x0, #-1]
    //     0x84e2a0: ubfx            x4, x4, #0xc, #0x14
    // 0x84e2a4: sub             x4, x4, #0x3c
    // 0x84e2a8: cmp             x4, #1
    // 0x84e2ac: b.ls            #0x84e2bc
    // 0x84e2b0: r8 = int?
    //     0x84e2b0: ldr             x8, [PP, #0x3d30]  ; [pp+0x3d30] Type: int?
    // 0x84e2b4: r3 = Null
    //     0x84e2b4: ldr             x3, [PP, #0x3f70]  ; [pp+0x3f70] Null
    // 0x84e2b8: r0 = int?()
    //     0x84e2b8: bl              #0x13ee944  ; IsType_int?_Stub
    // 0x84e2bc: ldur            x0, [fp, #-0x20]
    // 0x84e2c0: cmp             w0, NULL
    // 0x84e2c4: b.ne            #0x84e2d0
    // 0x84e2c8: r4 = 0
    //     0x84e2c8: mov             x4, #0
    // 0x84e2cc: b               #0x84e2e0
    // 0x84e2d0: r1 = LoadInt32Instr(r0)
    //     0x84e2d0: sbfx            x1, x0, #1, #0x1f
    //     0x84e2d4: tbz             w0, #0, #0x84e2dc
    //     0x84e2d8: ldur            x1, [x0, #7]
    // 0x84e2dc: mov             x4, x1
    // 0x84e2e0: ldur            x3, [fp, #-0x10]
    // 0x84e2e4: stur            x4, [fp, #-0x28]
    // 0x84e2e8: LoadField: r1 = r3->field_f
    //     0x84e2e8: ldur            w1, [x3, #0xf]
    // 0x84e2ec: DecompressPointer r1
    //     0x84e2ec: add             x1, x1, HEAP, lsl #32
    // 0x84e2f0: r0 = LoadClassIdInstr(r1)
    //     0x84e2f0: ldur            x0, [x1, #-1]
    //     0x84e2f4: ubfx            x0, x0, #0xc, #0x14
    // 0x84e2f8: r2 = "toolkit"
    //     0x84e2f8: ldr             x2, [PP, #0x3f80]  ; [pp+0x3f80] "toolkit"
    // 0x84e2fc: r0 = GDT[cid_x0 + -0xd48]()
    //     0x84e2fc: sub             lr, x0, #0xd48
    //     0x84e300: ldr             lr, [x21, lr, lsl #3]
    //     0x84e304: blr             lr
    // 0x84e308: mov             x3, x0
    // 0x84e30c: r2 = Null
    //     0x84e30c: mov             x2, NULL
    // 0x84e310: r1 = Null
    //     0x84e310: mov             x1, NULL
    // 0x84e314: stur            x3, [fp, #-0x20]
    // 0x84e318: r4 = 60
    //     0x84e318: mov             x4, #0x3c
    // 0x84e31c: branchIfSmi(r0, 0x84e328)
    //     0x84e31c: tbz             w0, #0, #0x84e328
    // 0x84e320: r4 = LoadClassIdInstr(r0)
    //     0x84e320: ldur            x4, [x0, #-1]
    //     0x84e324: ubfx            x4, x4, #0xc, #0x14
    // 0x84e328: sub             x4, x4, #0x5e
    // 0x84e32c: cmp             x4, #1
    // 0x84e330: b.ls            #0x84e340
    // 0x84e334: r8 = String?
    //     0x84e334: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x84e338: r3 = Null
    //     0x84e338: ldr             x3, [PP, #0x3f88]  ; [pp+0x3f88] Null
    // 0x84e33c: r0 = String?()
    //     0x84e33c: bl              #0x7db310  ; IsType_String?_Stub
    // 0x84e340: ldur            x0, [fp, #-0x20]
    // 0x84e344: cmp             w0, NULL
    // 0x84e348: b.ne            #0x84e354
    // 0x84e34c: r2 = ""
    //     0x84e34c: ldr             x2, [PP, #0x900]  ; [pp+0x900] ""
    // 0x84e350: b               #0x84e358
    // 0x84e354: mov             x2, x0
    // 0x84e358: ldur            x0, [fp, #-0x10]
    // 0x84e35c: r1 = Null
    //     0x84e35c: mov             x1, NULL
    // 0x84e360: r0 = KeyHelper()
    //     0x84e360: bl              #0x84ecdc  ; [package:flutter/src/services/raw_keyboard_linux.dart] KeyHelper::KeyHelper
    // 0x84e364: mov             x4, x0
    // 0x84e368: ldur            x3, [fp, #-0x10]
    // 0x84e36c: stur            x4, [fp, #-0x20]
    // 0x84e370: LoadField: r1 = r3->field_f
    //     0x84e370: ldur            w1, [x3, #0xf]
    // 0x84e374: DecompressPointer r1
    //     0x84e374: add             x1, x1, HEAP, lsl #32
    // 0x84e378: r0 = LoadClassIdInstr(r1)
    //     0x84e378: ldur            x0, [x1, #-1]
    //     0x84e37c: ubfx            x0, x0, #0xc, #0x14
    // 0x84e380: r2 = "keyCode"
    //     0x84e380: ldr             x2, [PP, #0x3d60]  ; [pp+0x3d60] "keyCode"
    // 0x84e384: r0 = GDT[cid_x0 + -0xd48]()
    //     0x84e384: sub             lr, x0, #0xd48
    //     0x84e388: ldr             lr, [x21, lr, lsl #3]
    //     0x84e38c: blr             lr
    // 0x84e390: mov             x3, x0
    // 0x84e394: r2 = Null
    //     0x84e394: mov             x2, NULL
    // 0x84e398: r1 = Null
    //     0x84e398: mov             x1, NULL
    // 0x84e39c: stur            x3, [fp, #-0x68]
    // 0x84e3a0: branchIfSmi(r0, 0x84e3c4)
    //     0x84e3a0: tbz             w0, #0, #0x84e3c4
    // 0x84e3a4: r4 = LoadClassIdInstr(r0)
    //     0x84e3a4: ldur            x4, [x0, #-1]
    //     0x84e3a8: ubfx            x4, x4, #0xc, #0x14
    // 0x84e3ac: sub             x4, x4, #0x3c
    // 0x84e3b0: cmp             x4, #1
    // 0x84e3b4: b.ls            #0x84e3c4
    // 0x84e3b8: r8 = int?
    //     0x84e3b8: ldr             x8, [PP, #0x3d30]  ; [pp+0x3d30] Type: int?
    // 0x84e3bc: r3 = Null
    //     0x84e3bc: ldr             x3, [PP, #0x3f98]  ; [pp+0x3f98] Null
    // 0x84e3c0: r0 = int?()
    //     0x84e3c0: bl              #0x13ee944  ; IsType_int?_Stub
    // 0x84e3c4: ldur            x0, [fp, #-0x68]
    // 0x84e3c8: cmp             w0, NULL
    // 0x84e3cc: b.ne            #0x84e3d8
    // 0x84e3d0: r4 = 0
    //     0x84e3d0: mov             x4, #0
    // 0x84e3d4: b               #0x84e3e8
    // 0x84e3d8: r1 = LoadInt32Instr(r0)
    //     0x84e3d8: sbfx            x1, x0, #1, #0x1f
    //     0x84e3dc: tbz             w0, #0, #0x84e3e4
    //     0x84e3e0: ldur            x1, [x0, #7]
    // 0x84e3e4: mov             x4, x1
    // 0x84e3e8: ldur            x3, [fp, #-0x10]
    // 0x84e3ec: stur            x4, [fp, #-0x30]
    // 0x84e3f0: LoadField: r1 = r3->field_f
    //     0x84e3f0: ldur            w1, [x3, #0xf]
    // 0x84e3f4: DecompressPointer r1
    //     0x84e3f4: add             x1, x1, HEAP, lsl #32
    // 0x84e3f8: r0 = LoadClassIdInstr(r1)
    //     0x84e3f8: ldur            x0, [x1, #-1]
    //     0x84e3fc: ubfx            x0, x0, #0xc, #0x14
    // 0x84e400: r2 = "scanCode"
    //     0x84e400: ldr             x2, [PP, #0x3d90]  ; [pp+0x3d90] "scanCode"
    // 0x84e404: r0 = GDT[cid_x0 + -0xd48]()
    //     0x84e404: sub             lr, x0, #0xd48
    //     0x84e408: ldr             lr, [x21, lr, lsl #3]
    //     0x84e40c: blr             lr
    // 0x84e410: mov             x3, x0
    // 0x84e414: r2 = Null
    //     0x84e414: mov             x2, NULL
    // 0x84e418: r1 = Null
    //     0x84e418: mov             x1, NULL
    // 0x84e41c: stur            x3, [fp, #-0x68]
    // 0x84e420: branchIfSmi(r0, 0x84e444)
    //     0x84e420: tbz             w0, #0, #0x84e444
    // 0x84e424: r4 = LoadClassIdInstr(r0)
    //     0x84e424: ldur            x4, [x0, #-1]
    //     0x84e428: ubfx            x4, x4, #0xc, #0x14
    // 0x84e42c: sub             x4, x4, #0x3c
    // 0x84e430: cmp             x4, #1
    // 0x84e434: b.ls            #0x84e444
    // 0x84e438: r8 = int?
    //     0x84e438: ldr             x8, [PP, #0x3d30]  ; [pp+0x3d30] Type: int?
    // 0x84e43c: r3 = Null
    //     0x84e43c: ldr             x3, [PP, #0x3fa8]  ; [pp+0x3fa8] Null
    // 0x84e440: r0 = int?()
    //     0x84e440: bl              #0x13ee944  ; IsType_int?_Stub
    // 0x84e444: ldur            x0, [fp, #-0x68]
    // 0x84e448: cmp             w0, NULL
    // 0x84e44c: b.ne            #0x84e458
    // 0x84e450: r4 = 0
    //     0x84e450: mov             x4, #0
    // 0x84e454: b               #0x84e468
    // 0x84e458: r1 = LoadInt32Instr(r0)
    //     0x84e458: sbfx            x1, x0, #1, #0x1f
    //     0x84e45c: tbz             w0, #0, #0x84e464
    //     0x84e460: ldur            x1, [x0, #7]
    // 0x84e464: mov             x4, x1
    // 0x84e468: ldur            x3, [fp, #-0x10]
    // 0x84e46c: stur            x4, [fp, #-0x38]
    // 0x84e470: LoadField: r1 = r3->field_f
    //     0x84e470: ldur            w1, [x3, #0xf]
    // 0x84e474: DecompressPointer r1
    //     0x84e474: add             x1, x1, HEAP, lsl #32
    // 0x84e478: r0 = LoadClassIdInstr(r1)
    //     0x84e478: ldur            x0, [x1, #-1]
    //     0x84e47c: ubfx            x0, x0, #0xc, #0x14
    // 0x84e480: r2 = "modifiers"
    //     0x84e480: ldr             x2, [PP, #0x3e80]  ; [pp+0x3e80] "modifiers"
    // 0x84e484: r0 = GDT[cid_x0 + -0xd48]()
    //     0x84e484: sub             lr, x0, #0xd48
    //     0x84e488: ldr             lr, [x21, lr, lsl #3]
    //     0x84e48c: blr             lr
    // 0x84e490: mov             x3, x0
    // 0x84e494: r2 = Null
    //     0x84e494: mov             x2, NULL
    // 0x84e498: r1 = Null
    //     0x84e498: mov             x1, NULL
    // 0x84e49c: stur            x3, [fp, #-0x68]
    // 0x84e4a0: branchIfSmi(r0, 0x84e4c4)
    //     0x84e4a0: tbz             w0, #0, #0x84e4c4
    // 0x84e4a4: r4 = LoadClassIdInstr(r0)
    //     0x84e4a4: ldur            x4, [x0, #-1]
    //     0x84e4a8: ubfx            x4, x4, #0xc, #0x14
    // 0x84e4ac: sub             x4, x4, #0x3c
    // 0x84e4b0: cmp             x4, #1
    // 0x84e4b4: b.ls            #0x84e4c4
    // 0x84e4b8: r8 = int?
    //     0x84e4b8: ldr             x8, [PP, #0x3d30]  ; [pp+0x3d30] Type: int?
    // 0x84e4bc: r3 = Null
    //     0x84e4bc: ldr             x3, [PP, #0x3fb8]  ; [pp+0x3fb8] Null
    // 0x84e4c0: r0 = int?()
    //     0x84e4c0: bl              #0x13ee944  ; IsType_int?_Stub
    // 0x84e4c4: ldur            x0, [fp, #-0x68]
    // 0x84e4c8: cmp             w0, NULL
    // 0x84e4cc: b.ne            #0x84e4d8
    // 0x84e4d0: r8 = 0
    //     0x84e4d0: mov             x8, #0
    // 0x84e4d4: b               #0x84e4e8
    // 0x84e4d8: r1 = LoadInt32Instr(r0)
    //     0x84e4d8: sbfx            x1, x0, #1, #0x1f
    //     0x84e4dc: tbz             w0, #0, #0x84e4e4
    //     0x84e4e0: ldur            x1, [x0, #7]
    // 0x84e4e4: mov             x8, x1
    // 0x84e4e8: ldur            x3, [fp, #-0x10]
    // 0x84e4ec: ldur            x7, [fp, #-0x28]
    // 0x84e4f0: ldur            x6, [fp, #-0x20]
    // 0x84e4f4: ldur            x5, [fp, #-0x30]
    // 0x84e4f8: ldur            x4, [fp, #-0x38]
    // 0x84e4fc: stur            x8, [fp, #-0x40]
    // 0x84e500: LoadField: r1 = r3->field_f
    //     0x84e500: ldur            w1, [x3, #0xf]
    // 0x84e504: DecompressPointer r1
    //     0x84e504: add             x1, x1, HEAP, lsl #32
    // 0x84e508: r0 = LoadClassIdInstr(r1)
    //     0x84e508: ldur            x0, [x1, #-1]
    //     0x84e50c: ubfx            x0, x0, #0xc, #0x14
    // 0x84e510: r2 = "type"
    //     0x84e510: ldr             x2, [PP, #0x3250]  ; [pp+0x3250] "type"
    // 0x84e514: r0 = GDT[cid_x0 + -0xd48]()
    //     0x84e514: sub             lr, x0, #0xd48
    //     0x84e518: ldr             lr, [x21, lr, lsl #3]
    //     0x84e51c: blr             lr
    // 0x84e520: r1 = 60
    //     0x84e520: mov             x1, #0x3c
    // 0x84e524: branchIfSmi(r0, 0x84e530)
    //     0x84e524: tbz             w0, #0, #0x84e530
    // 0x84e528: r1 = LoadClassIdInstr(r0)
    //     0x84e528: ldur            x1, [x0, #-1]
    //     0x84e52c: ubfx            x1, x1, #0xc, #0x14
    // 0x84e530: r16 = "keydown"
    //     0x84e530: ldr             x16, [PP, #0x3fc8]  ; [pp+0x3fc8] "keydown"
    // 0x84e534: stp             x16, x0, [SP]
    // 0x84e538: mov             x0, x1
    // 0x84e53c: mov             lr, x0
    // 0x84e540: ldr             lr, [x21, lr, lsl #3]
    // 0x84e544: blr             lr
    // 0x84e548: mov             x4, x0
    // 0x84e54c: ldur            x3, [fp, #-0x10]
    // 0x84e550: stur            x4, [fp, #-0x68]
    // 0x84e554: LoadField: r1 = r3->field_f
    //     0x84e554: ldur            w1, [x3, #0xf]
    // 0x84e558: DecompressPointer r1
    //     0x84e558: add             x1, x1, HEAP, lsl #32
    // 0x84e55c: r0 = LoadClassIdInstr(r1)
    //     0x84e55c: ldur            x0, [x1, #-1]
    //     0x84e560: ubfx            x0, x0, #0xc, #0x14
    // 0x84e564: r2 = "specifiedLogicalKey"
    //     0x84e564: ldr             x2, [PP, #0x3ef0]  ; [pp+0x3ef0] "specifiedLogicalKey"
    // 0x84e568: r0 = GDT[cid_x0 + -0xd48]()
    //     0x84e568: sub             lr, x0, #0xd48
    //     0x84e56c: ldr             lr, [x21, lr, lsl #3]
    //     0x84e570: blr             lr
    // 0x84e574: mov             x3, x0
    // 0x84e578: r2 = Null
    //     0x84e578: mov             x2, NULL
    // 0x84e57c: r1 = Null
    //     0x84e57c: mov             x1, NULL
    // 0x84e580: stur            x3, [fp, #-0x70]
    // 0x84e584: branchIfSmi(r0, 0x84e5a8)
    //     0x84e584: tbz             w0, #0, #0x84e5a8
    // 0x84e588: r4 = LoadClassIdInstr(r0)
    //     0x84e588: ldur            x4, [x0, #-1]
    //     0x84e58c: ubfx            x4, x4, #0xc, #0x14
    // 0x84e590: sub             x4, x4, #0x3c
    // 0x84e594: cmp             x4, #1
    // 0x84e598: b.ls            #0x84e5a8
    // 0x84e59c: r8 = int?
    //     0x84e59c: ldr             x8, [PP, #0x3d30]  ; [pp+0x3d30] Type: int?
    // 0x84e5a0: r3 = Null
    //     0x84e5a0: ldr             x3, [PP, #0x3fd0]  ; [pp+0x3fd0] Null
    // 0x84e5a4: r0 = int?()
    //     0x84e5a4: bl              #0x13ee944  ; IsType_int?_Stub
    // 0x84e5a8: r0 = RawKeyEventDataLinux()
    //     0x84e5a8: bl              #0x84ecd0  ; AllocateRawKeyEventDataLinuxStub -> RawKeyEventDataLinux (size=0x34)
    // 0x84e5ac: mov             x3, x0
    // 0x84e5b0: ldur            x0, [fp, #-0x20]
    // 0x84e5b4: stur            x3, [fp, #-0x78]
    // 0x84e5b8: StoreField: r3->field_7 = r0
    //     0x84e5b8: stur            w0, [x3, #7]
    // 0x84e5bc: ldur            x2, [fp, #-0x28]
    // 0x84e5c0: StoreField: r3->field_b = r2
    //     0x84e5c0: stur            x2, [x3, #0xb]
    // 0x84e5c4: ldur            x0, [fp, #-0x38]
    // 0x84e5c8: StoreField: r3->field_13 = r0
    //     0x84e5c8: stur            x0, [x3, #0x13]
    // 0x84e5cc: ldur            x0, [fp, #-0x30]
    // 0x84e5d0: StoreField: r3->field_1b = r0
    //     0x84e5d0: stur            x0, [x3, #0x1b]
    // 0x84e5d4: ldur            x0, [fp, #-0x40]
    // 0x84e5d8: StoreField: r3->field_23 = r0
    //     0x84e5d8: stur            x0, [x3, #0x23]
    // 0x84e5dc: ldur            x0, [fp, #-0x68]
    // 0x84e5e0: StoreField: r3->field_2b = r0
    //     0x84e5e0: stur            w0, [x3, #0x2b]
    // 0x84e5e4: ldur            x0, [fp, #-0x70]
    // 0x84e5e8: StoreField: r3->field_2f = r0
    //     0x84e5e8: stur            w0, [x3, #0x2f]
    // 0x84e5ec: r0 = BoxInt64Instr(r2)
    //     0x84e5ec: sbfiz           x0, x2, #1, #0x1f
    //     0x84e5f0: cmp             x2, x0, asr #1
    //     0x84e5f4: b.eq            #0x84e600
    //     0x84e5f8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x84e5fc: stur            x2, [x0, #7]
    // 0x84e600: cbz             w0, #0x84e634
    // 0x84e604: ldur            x0, [fp, #-0x10]
    // 0x84e608: r1 = Null
    //     0x84e608: mov             x1, NULL
    // 0x84e60c: r0 = String.fromCharCode()
    //     0x84e60c: bl              #0x7e6340  ; [dart:core] String::String.fromCharCode
    // 0x84e610: ldur            x1, [fp, #-0x10]
    // 0x84e614: StoreField: r1->field_13 = r0
    //     0x84e614: stur            w0, [x1, #0x13]
    //     0x84e618: ldurb           w16, [x1, #-1]
    //     0x84e61c: ldurb           w17, [x0, #-1]
    //     0x84e620: and             x16, x17, x16, lsr #2
    //     0x84e624: tst             x16, HEAP, lsr #32
    //     0x84e628: b.eq            #0x84e630
    //     0x84e62c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x84e630: b               #0x84e638
    // 0x84e634: ldur            x1, [fp, #-0x10]
    // 0x84e638: mov             x0, x1
    // 0x84e63c: ldur            x1, [fp, #-0x78]
    // 0x84e640: b               #0x84e924
    // 0x84e644: ldur            x1, [fp, #-0x10]
    // 0x84e648: r16 = "windows"
    //     0x84e648: ldr             x16, [PP, #0x3fe0]  ; [pp+0x3fe0] "windows"
    // 0x84e64c: ldur            lr, [fp, #-8]
    // 0x84e650: stp             lr, x16, [SP]
    // 0x84e654: r0 = ==()
    //     0x84e654: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x84e658: tbnz            w0, #4, #0x84e8ec
    // 0x84e65c: ldur            x3, [fp, #-0x10]
    // 0x84e660: LoadField: r1 = r3->field_f
    //     0x84e660: ldur            w1, [x3, #0xf]
    // 0x84e664: DecompressPointer r1
    //     0x84e664: add             x1, x1, HEAP, lsl #32
    // 0x84e668: r0 = LoadClassIdInstr(r1)
    //     0x84e668: ldur            x0, [x1, #-1]
    //     0x84e66c: ubfx            x0, x0, #0xc, #0x14
    // 0x84e670: r2 = "characterCodePoint"
    //     0x84e670: ldr             x2, [PP, #0x3fe8]  ; [pp+0x3fe8] "characterCodePoint"
    // 0x84e674: r0 = GDT[cid_x0 + -0xd48]()
    //     0x84e674: sub             lr, x0, #0xd48
    //     0x84e678: ldr             lr, [x21, lr, lsl #3]
    //     0x84e67c: blr             lr
    // 0x84e680: mov             x3, x0
    // 0x84e684: r2 = Null
    //     0x84e684: mov             x2, NULL
    // 0x84e688: r1 = Null
    //     0x84e688: mov             x1, NULL
    // 0x84e68c: stur            x3, [fp, #-0x20]
    // 0x84e690: branchIfSmi(r0, 0x84e6b4)
    //     0x84e690: tbz             w0, #0, #0x84e6b4
    // 0x84e694: r4 = LoadClassIdInstr(r0)
    //     0x84e694: ldur            x4, [x0, #-1]
    //     0x84e698: ubfx            x4, x4, #0xc, #0x14
    // 0x84e69c: sub             x4, x4, #0x3c
    // 0x84e6a0: cmp             x4, #1
    // 0x84e6a4: b.ls            #0x84e6b4
    // 0x84e6a8: r8 = int?
    //     0x84e6a8: ldr             x8, [PP, #0x3d30]  ; [pp+0x3d30] Type: int?
    // 0x84e6ac: r3 = Null
    //     0x84e6ac: ldr             x3, [PP, #0x3ff0]  ; [pp+0x3ff0] Null
    // 0x84e6b0: r0 = int?()
    //     0x84e6b0: bl              #0x13ee944  ; IsType_int?_Stub
    // 0x84e6b4: ldur            x0, [fp, #-0x20]
    // 0x84e6b8: cmp             w0, NULL
    // 0x84e6bc: b.ne            #0x84e6c8
    // 0x84e6c0: r4 = 0
    //     0x84e6c0: mov             x4, #0
    // 0x84e6c4: b               #0x84e6d8
    // 0x84e6c8: r1 = LoadInt32Instr(r0)
    //     0x84e6c8: sbfx            x1, x0, #1, #0x1f
    //     0x84e6cc: tbz             w0, #0, #0x84e6d4
    //     0x84e6d0: ldur            x1, [x0, #7]
    // 0x84e6d4: mov             x4, x1
    // 0x84e6d8: ldur            x3, [fp, #-0x10]
    // 0x84e6dc: stur            x4, [fp, #-0x28]
    // 0x84e6e0: LoadField: r1 = r3->field_f
    //     0x84e6e0: ldur            w1, [x3, #0xf]
    // 0x84e6e4: DecompressPointer r1
    //     0x84e6e4: add             x1, x1, HEAP, lsl #32
    // 0x84e6e8: r0 = LoadClassIdInstr(r1)
    //     0x84e6e8: ldur            x0, [x1, #-1]
    //     0x84e6ec: ubfx            x0, x0, #0xc, #0x14
    // 0x84e6f0: r2 = "keyCode"
    //     0x84e6f0: ldr             x2, [PP, #0x3d60]  ; [pp+0x3d60] "keyCode"
    // 0x84e6f4: r0 = GDT[cid_x0 + -0xd48]()
    //     0x84e6f4: sub             lr, x0, #0xd48
    //     0x84e6f8: ldr             lr, [x21, lr, lsl #3]
    //     0x84e6fc: blr             lr
    // 0x84e700: mov             x3, x0
    // 0x84e704: r2 = Null
    //     0x84e704: mov             x2, NULL
    // 0x84e708: r1 = Null
    //     0x84e708: mov             x1, NULL
    // 0x84e70c: stur            x3, [fp, #-0x20]
    // 0x84e710: branchIfSmi(r0, 0x84e734)
    //     0x84e710: tbz             w0, #0, #0x84e734
    // 0x84e714: r4 = LoadClassIdInstr(r0)
    //     0x84e714: ldur            x4, [x0, #-1]
    //     0x84e718: ubfx            x4, x4, #0xc, #0x14
    // 0x84e71c: sub             x4, x4, #0x3c
    // 0x84e720: cmp             x4, #1
    // 0x84e724: b.ls            #0x84e734
    // 0x84e728: r8 = int?
    //     0x84e728: ldr             x8, [PP, #0x3d30]  ; [pp+0x3d30] Type: int?
    // 0x84e72c: r3 = Null
    //     0x84e72c: ldr             x3, [PP, #0x4000]  ; [pp+0x4000] Null
    // 0x84e730: r0 = int?()
    //     0x84e730: bl              #0x13ee944  ; IsType_int?_Stub
    // 0x84e734: ldur            x0, [fp, #-0x20]
    // 0x84e738: cmp             w0, NULL
    // 0x84e73c: b.ne            #0x84e748
    // 0x84e740: r4 = 0
    //     0x84e740: mov             x4, #0
    // 0x84e744: b               #0x84e758
    // 0x84e748: r1 = LoadInt32Instr(r0)
    //     0x84e748: sbfx            x1, x0, #1, #0x1f
    //     0x84e74c: tbz             w0, #0, #0x84e754
    //     0x84e750: ldur            x1, [x0, #7]
    // 0x84e754: mov             x4, x1
    // 0x84e758: ldur            x3, [fp, #-0x10]
    // 0x84e75c: stur            x4, [fp, #-0x30]
    // 0x84e760: LoadField: r1 = r3->field_f
    //     0x84e760: ldur            w1, [x3, #0xf]
    // 0x84e764: DecompressPointer r1
    //     0x84e764: add             x1, x1, HEAP, lsl #32
    // 0x84e768: r0 = LoadClassIdInstr(r1)
    //     0x84e768: ldur            x0, [x1, #-1]
    //     0x84e76c: ubfx            x0, x0, #0xc, #0x14
    // 0x84e770: r2 = "scanCode"
    //     0x84e770: ldr             x2, [PP, #0x3d90]  ; [pp+0x3d90] "scanCode"
    // 0x84e774: r0 = GDT[cid_x0 + -0xd48]()
    //     0x84e774: sub             lr, x0, #0xd48
    //     0x84e778: ldr             lr, [x21, lr, lsl #3]
    //     0x84e77c: blr             lr
    // 0x84e780: mov             x3, x0
    // 0x84e784: r2 = Null
    //     0x84e784: mov             x2, NULL
    // 0x84e788: r1 = Null
    //     0x84e788: mov             x1, NULL
    // 0x84e78c: stur            x3, [fp, #-0x20]
    // 0x84e790: branchIfSmi(r0, 0x84e7b4)
    //     0x84e790: tbz             w0, #0, #0x84e7b4
    // 0x84e794: r4 = LoadClassIdInstr(r0)
    //     0x84e794: ldur            x4, [x0, #-1]
    //     0x84e798: ubfx            x4, x4, #0xc, #0x14
    // 0x84e79c: sub             x4, x4, #0x3c
    // 0x84e7a0: cmp             x4, #1
    // 0x84e7a4: b.ls            #0x84e7b4
    // 0x84e7a8: r8 = int?
    //     0x84e7a8: ldr             x8, [PP, #0x3d30]  ; [pp+0x3d30] Type: int?
    // 0x84e7ac: r3 = Null
    //     0x84e7ac: ldr             x3, [PP, #0x4010]  ; [pp+0x4010] Null
    // 0x84e7b0: r0 = int?()
    //     0x84e7b0: bl              #0x13ee944  ; IsType_int?_Stub
    // 0x84e7b4: ldur            x0, [fp, #-0x20]
    // 0x84e7b8: cmp             w0, NULL
    // 0x84e7bc: b.ne            #0x84e7c8
    // 0x84e7c0: r4 = 0
    //     0x84e7c0: mov             x4, #0
    // 0x84e7c4: b               #0x84e7d8
    // 0x84e7c8: r1 = LoadInt32Instr(r0)
    //     0x84e7c8: sbfx            x1, x0, #1, #0x1f
    //     0x84e7cc: tbz             w0, #0, #0x84e7d4
    //     0x84e7d0: ldur            x1, [x0, #7]
    // 0x84e7d4: mov             x4, x1
    // 0x84e7d8: ldur            x3, [fp, #-0x10]
    // 0x84e7dc: stur            x4, [fp, #-0x38]
    // 0x84e7e0: LoadField: r1 = r3->field_f
    //     0x84e7e0: ldur            w1, [x3, #0xf]
    // 0x84e7e4: DecompressPointer r1
    //     0x84e7e4: add             x1, x1, HEAP, lsl #32
    // 0x84e7e8: r0 = LoadClassIdInstr(r1)
    //     0x84e7e8: ldur            x0, [x1, #-1]
    //     0x84e7ec: ubfx            x0, x0, #0xc, #0x14
    // 0x84e7f0: r2 = "modifiers"
    //     0x84e7f0: ldr             x2, [PP, #0x3e80]  ; [pp+0x3e80] "modifiers"
    // 0x84e7f4: r0 = GDT[cid_x0 + -0xd48]()
    //     0x84e7f4: sub             lr, x0, #0xd48
    //     0x84e7f8: ldr             lr, [x21, lr, lsl #3]
    //     0x84e7fc: blr             lr
    // 0x84e800: mov             x3, x0
    // 0x84e804: r2 = Null
    //     0x84e804: mov             x2, NULL
    // 0x84e808: r1 = Null
    //     0x84e808: mov             x1, NULL
    // 0x84e80c: stur            x3, [fp, #-0x20]
    // 0x84e810: branchIfSmi(r0, 0x84e834)
    //     0x84e810: tbz             w0, #0, #0x84e834
    // 0x84e814: r4 = LoadClassIdInstr(r0)
    //     0x84e814: ldur            x4, [x0, #-1]
    //     0x84e818: ubfx            x4, x4, #0xc, #0x14
    // 0x84e81c: sub             x4, x4, #0x3c
    // 0x84e820: cmp             x4, #1
    // 0x84e824: b.ls            #0x84e834
    // 0x84e828: r8 = int?
    //     0x84e828: ldr             x8, [PP, #0x3d30]  ; [pp+0x3d30] Type: int?
    // 0x84e82c: r3 = Null
    //     0x84e82c: ldr             x3, [PP, #0x4020]  ; [pp+0x4020] Null
    // 0x84e830: r0 = int?()
    //     0x84e830: bl              #0x13ee944  ; IsType_int?_Stub
    // 0x84e834: ldur            x0, [fp, #-0x20]
    // 0x84e838: cmp             w0, NULL
    // 0x84e83c: b.ne            #0x84e848
    // 0x84e840: r3 = 0
    //     0x84e840: mov             x3, #0
    // 0x84e844: b               #0x84e858
    // 0x84e848: r1 = LoadInt32Instr(r0)
    //     0x84e848: sbfx            x1, x0, #1, #0x1f
    //     0x84e84c: tbz             w0, #0, #0x84e854
    //     0x84e850: ldur            x1, [x0, #7]
    // 0x84e854: mov             x3, x1
    // 0x84e858: ldur            x2, [fp, #-0x28]
    // 0x84e85c: ldur            x1, [fp, #-0x30]
    // 0x84e860: ldur            x0, [fp, #-0x38]
    // 0x84e864: stur            x3, [fp, #-0x40]
    // 0x84e868: r0 = RawKeyEventDataWindows()
    //     0x84e868: bl              #0x84ecc4  ; AllocateRawKeyEventDataWindowsStub -> RawKeyEventDataWindows (size=0x28)
    // 0x84e86c: mov             x3, x0
    // 0x84e870: ldur            x0, [fp, #-0x30]
    // 0x84e874: stur            x3, [fp, #-0x20]
    // 0x84e878: StoreField: r3->field_7 = r0
    //     0x84e878: stur            x0, [x3, #7]
    // 0x84e87c: ldur            x0, [fp, #-0x38]
    // 0x84e880: StoreField: r3->field_f = r0
    //     0x84e880: stur            x0, [x3, #0xf]
    // 0x84e884: ldur            x2, [fp, #-0x28]
    // 0x84e888: ArrayStore: r3[0] = r2  ; List_8
    //     0x84e888: stur            x2, [x3, #0x17]
    // 0x84e88c: ldur            x0, [fp, #-0x40]
    // 0x84e890: StoreField: r3->field_1f = r0
    //     0x84e890: stur            x0, [x3, #0x1f]
    // 0x84e894: r0 = BoxInt64Instr(r2)
    //     0x84e894: sbfiz           x0, x2, #1, #0x1f
    //     0x84e898: cmp             x2, x0, asr #1
    //     0x84e89c: b.eq            #0x84e8a8
    //     0x84e8a0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x84e8a4: stur            x2, [x0, #7]
    // 0x84e8a8: cbz             w0, #0x84e8dc
    // 0x84e8ac: ldur            x0, [fp, #-0x10]
    // 0x84e8b0: r1 = Null
    //     0x84e8b0: mov             x1, NULL
    // 0x84e8b4: r0 = String.fromCharCode()
    //     0x84e8b4: bl              #0x7e6340  ; [dart:core] String::String.fromCharCode
    // 0x84e8b8: ldur            x1, [fp, #-0x10]
    // 0x84e8bc: StoreField: r1->field_13 = r0
    //     0x84e8bc: stur            w0, [x1, #0x13]
    //     0x84e8c0: ldurb           w16, [x1, #-1]
    //     0x84e8c4: ldurb           w17, [x0, #-1]
    //     0x84e8c8: and             x16, x17, x16, lsr #2
    //     0x84e8cc: tst             x16, HEAP, lsr #32
    //     0x84e8d0: b.eq            #0x84e8d8
    //     0x84e8d4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x84e8d8: b               #0x84e8e0
    // 0x84e8dc: ldur            x1, [fp, #-0x10]
    // 0x84e8e0: mov             x0, x1
    // 0x84e8e4: ldur            x1, [fp, #-0x20]
    // 0x84e8e8: b               #0x84e924
    // 0x84e8ec: ldur            x1, [fp, #-0x10]
    // 0x84e8f0: r16 = "web"
    //     0x84e8f0: ldr             x16, [PP, #0x4030]  ; [pp+0x4030] "web"
    // 0x84e8f4: ldur            lr, [fp, #-8]
    // 0x84e8f8: stp             lr, x16, [SP]
    // 0x84e8fc: r0 = ==()
    //     0x84e8fc: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x84e900: tbnz            w0, #4, #0x84eac4
    // 0x84e904: ldur            x16, [fp, #-0x18]
    // 0x84e908: str             x16, [SP]
    // 0x84e90c: ldur            x0, [fp, #-0x18]
    // 0x84e910: ClosureCall
    //     0x84e910: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x84e914: ldur            x2, [x0, #0x1f]
    //     0x84e918: blr             x2
    // 0x84e91c: mov             x1, x0
    // 0x84e920: ldur            x0, [fp, #-0x10]
    // 0x84e924: stur            x1, [fp, #-0x18]
    // 0x84e928: r0 = LoadStaticField(0x814)
    //     0x84e928: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x84e92c: ldr             x0, [x0, #0x1028]
    // 0x84e930: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x84e934: cmp             w0, w16
    // 0x84e938: b.ne            #0x84e944
    // 0x84e93c: r2 = instance
    //     0x84e93c: ldr             x2, [PP, #0x3a28]  ; [pp+0x3a28] Field <RawKeyboard.instance>: static late final (offset: 0x814)
    // 0x84e940: r0 = InitLateFinalStaticField()
    //     0x84e940: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x84e944: LoadField: r2 = r0->field_b
    //     0x84e944: ldur            w2, [x0, #0xb]
    // 0x84e948: DecompressPointer r2
    //     0x84e948: add             x2, x2, HEAP, lsl #32
    // 0x84e94c: stur            x2, [fp, #-0x20]
    // 0x84e950: r1 = <PhysicalKeyboardKey, LogicalKeyboardKey>
    //     0x84e950: ldr             x1, [PP, #0x3aa0]  ; [pp+0x3aa0] TypeArguments: <PhysicalKeyboardKey, LogicalKeyboardKey>
    // 0x84e954: r0 = _CompactKeysIterable()
    //     0x84e954: bl              #0x8353d0  ; Allocate_CompactKeysIterableStub -> _CompactKeysIterable<X0> (size=0x10)
    // 0x84e958: mov             x1, x0
    // 0x84e95c: ldur            x0, [fp, #-0x20]
    // 0x84e960: StoreField: r1->field_b = r0
    //     0x84e960: stur            w0, [x1, #0xb]
    // 0x84e964: r0 = toSet()
    //     0x84e964: bl              #0xba60e0  ; [dart:core] _GrowableList::toSet
    // 0x84e968: mov             x3, x0
    // 0x84e96c: ldur            x2, [fp, #-0x18]
    // 0x84e970: stur            x3, [fp, #-0x20]
    // 0x84e974: r0 = LoadClassIdInstr(r2)
    //     0x84e974: ldur            x0, [x2, #-1]
    //     0x84e978: ubfx            x0, x0, #0xc, #0x14
    // 0x84e97c: mov             x1, x2
    // 0x84e980: r0 = GDT[cid_x0 + 0x6c3b]()
    //     0x84e980: mov             x17, #0x6c3b
    //     0x84e984: add             lr, x0, x17
    //     0x84e988: ldr             lr, [x21, lr, lsl #3]
    //     0x84e98c: blr             lr
    // 0x84e990: ldur            x1, [fp, #-0x20]
    // 0x84e994: mov             x2, x0
    // 0x84e998: r0 = contains()
    //     0x84e998: bl              #0xbafbf4  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x84e99c: ldur            x3, [fp, #-0x10]
    // 0x84e9a0: LoadField: r1 = r3->field_f
    //     0x84e9a0: ldur            w1, [x3, #0xf]
    // 0x84e9a4: DecompressPointer r1
    //     0x84e9a4: add             x1, x1, HEAP, lsl #32
    // 0x84e9a8: r0 = LoadClassIdInstr(r1)
    //     0x84e9a8: ldur            x0, [x1, #-1]
    //     0x84e9ac: ubfx            x0, x0, #0xc, #0x14
    // 0x84e9b0: r2 = "type"
    //     0x84e9b0: ldr             x2, [PP, #0x3250]  ; [pp+0x3250] "type"
    // 0x84e9b4: r0 = GDT[cid_x0 + -0xd48]()
    //     0x84e9b4: sub             lr, x0, #0xd48
    //     0x84e9b8: ldr             lr, [x21, lr, lsl #3]
    //     0x84e9bc: blr             lr
    // 0x84e9c0: mov             x3, x0
    // 0x84e9c4: stur            x3, [fp, #-0x20]
    // 0x84e9c8: cmp             w3, NULL
    // 0x84e9cc: b.eq            #0x84eb0c
    // 0x84e9d0: mov             x0, x3
    // 0x84e9d4: r2 = Null
    //     0x84e9d4: mov             x2, NULL
    // 0x84e9d8: r1 = Null
    //     0x84e9d8: mov             x1, NULL
    // 0x84e9dc: r4 = 60
    //     0x84e9dc: mov             x4, #0x3c
    // 0x84e9e0: branchIfSmi(r0, 0x84e9ec)
    //     0x84e9e0: tbz             w0, #0, #0x84e9ec
    // 0x84e9e4: r4 = LoadClassIdInstr(r0)
    //     0x84e9e4: ldur            x4, [x0, #-1]
    //     0x84e9e8: ubfx            x4, x4, #0xc, #0x14
    // 0x84e9ec: sub             x4, x4, #0x5e
    // 0x84e9f0: cmp             x4, #1
    // 0x84e9f4: b.ls            #0x84ea04
    // 0x84e9f8: r8 = String
    //     0x84e9f8: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x84e9fc: r3 = Null
    //     0x84e9fc: ldr             x3, [PP, #0x4038]  ; [pp+0x4038] Null
    // 0x84ea00: r0 = String()
    //     0x84ea00: bl              #0x13ee320  ; IsType_String_Stub
    // 0x84ea04: r16 = "keydown"
    //     0x84ea04: ldr             x16, [PP, #0x3fc8]  ; [pp+0x3fc8] "keydown"
    // 0x84ea08: ldur            lr, [fp, #-0x20]
    // 0x84ea0c: stp             lr, x16, [SP]
    // 0x84ea10: r0 = ==()
    //     0x84ea10: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x84ea14: tbnz            w0, #4, #0x84ea4c
    // 0x84ea18: ldur            x0, [fp, #-0x10]
    // 0x84ea1c: ldur            x1, [fp, #-0x18]
    // 0x84ea20: LoadField: r2 = r0->field_13
    //     0x84ea20: ldur            w2, [x0, #0x13]
    // 0x84ea24: DecompressPointer r2
    //     0x84ea24: add             x2, x2, HEAP, lsl #32
    // 0x84ea28: stur            x2, [fp, #-0x68]
    // 0x84ea2c: r0 = RawKeyDownEvent()
    //     0x84ea2c: bl              #0x84ecb8  ; AllocateRawKeyDownEventStub -> RawKeyDownEvent (size=0x10)
    // 0x84ea30: mov             x1, x0
    // 0x84ea34: ldur            x0, [fp, #-0x18]
    // 0x84ea38: StoreField: r1->field_b = r0
    //     0x84ea38: stur            w0, [x1, #0xb]
    // 0x84ea3c: ldur            x0, [fp, #-0x68]
    // 0x84ea40: StoreField: r1->field_7 = r0
    //     0x84ea40: stur            w0, [x1, #7]
    // 0x84ea44: mov             x0, x1
    // 0x84ea48: b               #0x84ea7c
    // 0x84ea4c: ldur            x0, [fp, #-0x18]
    // 0x84ea50: r16 = "keyup"
    //     0x84ea50: ldr             x16, [PP, #0x4048]  ; [pp+0x4048] "keyup"
    // 0x84ea54: ldur            lr, [fp, #-0x20]
    // 0x84ea58: stp             lr, x16, [SP]
    // 0x84ea5c: r0 = ==()
    //     0x84ea5c: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x84ea60: tbnz            w0, #4, #0x84ea88
    // 0x84ea64: ldur            x0, [fp, #-0x18]
    // 0x84ea68: r0 = RawKeyUpEvent()
    //     0x84ea68: bl              #0x84ecac  ; AllocateRawKeyUpEventStub -> RawKeyUpEvent (size=0x10)
    // 0x84ea6c: mov             x1, x0
    // 0x84ea70: ldur            x0, [fp, #-0x18]
    // 0x84ea74: StoreField: r1->field_b = r0
    //     0x84ea74: stur            w0, [x1, #0xb]
    // 0x84ea78: mov             x0, x1
    // 0x84ea7c: LeaveFrame
    //     0x84ea7c: mov             SP, fp
    //     0x84ea80: ldp             fp, lr, [SP], #0x10
    // 0x84ea84: ret
    //     0x84ea84: ret             
    // 0x84ea88: ldur            x0, [fp, #-0x20]
    // 0x84ea8c: r1 = Null
    //     0x84ea8c: mov             x1, NULL
    // 0x84ea90: r2 = 4
    //     0x84ea90: mov             x2, #4
    // 0x84ea94: r0 = AllocateArray()
    //     0x84ea94: bl              #0x13df928  ; AllocateArrayStub
    // 0x84ea98: r16 = "Unknown key event type: "
    //     0x84ea98: ldr             x16, [PP, #0x4050]  ; [pp+0x4050] "Unknown key event type: "
    // 0x84ea9c: StoreField: r0->field_f = r16
    //     0x84ea9c: stur            w16, [x0, #0xf]
    // 0x84eaa0: ldur            x1, [fp, #-0x20]
    // 0x84eaa4: StoreField: r0->field_13 = r1
    //     0x84eaa4: stur            w1, [x0, #0x13]
    // 0x84eaa8: str             x0, [SP]
    // 0x84eaac: r0 = _interpolate()
    //     0x84eaac: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x84eab0: mov             x2, x0
    // 0x84eab4: r1 = Null
    //     0x84eab4: mov             x1, NULL
    // 0x84eab8: r0 = FlutterError()
    //     0x84eab8: bl              #0x84eb60  ; [package:flutter/src/foundation/assertions.dart] FlutterError::FlutterError
    // 0x84eabc: r0 = Throw()
    //     0x84eabc: bl              #0x13ddb2c  ; ThrowStub
    // 0x84eac0: brk             #0
    // 0x84eac4: ldur            x0, [fp, #-8]
    // 0x84eac8: r1 = Null
    //     0x84eac8: mov             x1, NULL
    // 0x84eacc: r2 = 4
    //     0x84eacc: mov             x2, #4
    // 0x84ead0: r0 = AllocateArray()
    //     0x84ead0: bl              #0x13df928  ; AllocateArrayStub
    // 0x84ead4: r16 = "Unknown keymap for key events: "
    //     0x84ead4: ldr             x16, [PP, #0x4058]  ; [pp+0x4058] "Unknown keymap for key events: "
    // 0x84ead8: StoreField: r0->field_f = r16
    //     0x84ead8: stur            w16, [x0, #0xf]
    // 0x84eadc: ldur            x1, [fp, #-8]
    // 0x84eae0: StoreField: r0->field_13 = r1
    //     0x84eae0: stur            w1, [x0, #0x13]
    // 0x84eae4: str             x0, [SP]
    // 0x84eae8: r0 = _interpolate()
    //     0x84eae8: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x84eaec: mov             x2, x0
    // 0x84eaf0: r1 = Null
    //     0x84eaf0: mov             x1, NULL
    // 0x84eaf4: r0 = FlutterError()
    //     0x84eaf4: bl              #0x84eb60  ; [package:flutter/src/foundation/assertions.dart] FlutterError::FlutterError
    // 0x84eaf8: r0 = Throw()
    //     0x84eaf8: bl              #0x13ddb2c  ; ThrowStub
    // 0x84eafc: brk             #0
    // 0x84eb00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84eb00: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84eb04: b               #0x84d388
    // 0x84eb08: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84eb08: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84eb0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84eb0c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] static RawKeyEventData dataFromWeb(dynamic) {
    // ** addr: 0x84ede8, size: 0x338
    // 0x84ede8: EnterFrame
    //     0x84ede8: stp             fp, lr, [SP, #-0x10]!
    //     0x84edec: mov             fp, SP
    // 0x84edf0: AllocStack(0x38)
    //     0x84edf0: sub             SP, SP, #0x38
    // 0x84edf4: SetupParameters([dynamic _ /* r0 */])
    //     0x84edf4: ldr             x0, [fp, #0x10]
    //     0x84edf8: ldur            w3, [x0, #0x17]
    //     0x84edfc: add             x3, x3, HEAP, lsl #32
    //     0x84ee00: stur            x3, [fp, #-8]
    // 0x84ee04: CheckStackOverflow
    //     0x84ee04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84ee08: cmp             SP, x16
    //     0x84ee0c: b.ls            #0x84f118
    // 0x84ee10: LoadField: r1 = r3->field_f
    //     0x84ee10: ldur            w1, [x3, #0xf]
    // 0x84ee14: DecompressPointer r1
    //     0x84ee14: add             x1, x1, HEAP, lsl #32
    // 0x84ee18: r0 = LoadClassIdInstr(r1)
    //     0x84ee18: ldur            x0, [x1, #-1]
    //     0x84ee1c: ubfx            x0, x0, #0xc, #0x14
    // 0x84ee20: r2 = "key"
    //     0x84ee20: ldr             x2, [PP, #0xf18]  ; [pp+0xf18] "key"
    // 0x84ee24: r0 = GDT[cid_x0 + -0xd48]()
    //     0x84ee24: sub             lr, x0, #0xd48
    //     0x84ee28: ldr             lr, [x21, lr, lsl #3]
    //     0x84ee2c: blr             lr
    // 0x84ee30: mov             x3, x0
    // 0x84ee34: r2 = Null
    //     0x84ee34: mov             x2, NULL
    // 0x84ee38: r1 = Null
    //     0x84ee38: mov             x1, NULL
    // 0x84ee3c: stur            x3, [fp, #-0x10]
    // 0x84ee40: r4 = 60
    //     0x84ee40: mov             x4, #0x3c
    // 0x84ee44: branchIfSmi(r0, 0x84ee50)
    //     0x84ee44: tbz             w0, #0, #0x84ee50
    // 0x84ee48: r4 = LoadClassIdInstr(r0)
    //     0x84ee48: ldur            x4, [x0, #-1]
    //     0x84ee4c: ubfx            x4, x4, #0xc, #0x14
    // 0x84ee50: sub             x4, x4, #0x5e
    // 0x84ee54: cmp             x4, #1
    // 0x84ee58: b.ls            #0x84ee68
    // 0x84ee5c: r8 = String?
    //     0x84ee5c: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x84ee60: r3 = Null
    //     0x84ee60: ldr             x3, [PP, #0x4060]  ; [pp+0x4060] Null
    // 0x84ee64: r0 = String?()
    //     0x84ee64: bl              #0x7db310  ; IsType_String?_Stub
    // 0x84ee68: ldur            x3, [fp, #-0x10]
    // 0x84ee6c: cmp             w3, NULL
    // 0x84ee70: b.eq            #0x84eebc
    // 0x84ee74: LoadField: r0 = r3->field_7
    //     0x84ee74: ldur            w0, [x3, #7]
    // 0x84ee78: cbz             w0, #0x84eeb4
    // 0x84ee7c: cmp             w0, #2
    // 0x84ee80: b.ne            #0x84eeac
    // 0x84ee84: ldur            x4, [fp, #-8]
    // 0x84ee88: mov             x0, x3
    // 0x84ee8c: StoreField: r4->field_13 = r0
    //     0x84ee8c: stur            w0, [x4, #0x13]
    //     0x84ee90: ldurb           w16, [x4, #-1]
    //     0x84ee94: ldurb           w17, [x0, #-1]
    //     0x84ee98: and             x16, x17, x16, lsr #2
    //     0x84ee9c: tst             x16, HEAP, lsr #32
    //     0x84eea0: b.eq            #0x84eea8
    //     0x84eea4: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0x84eea8: b               #0x84eec0
    // 0x84eeac: ldur            x4, [fp, #-8]
    // 0x84eeb0: b               #0x84eec0
    // 0x84eeb4: ldur            x4, [fp, #-8]
    // 0x84eeb8: b               #0x84eec0
    // 0x84eebc: ldur            x4, [fp, #-8]
    // 0x84eec0: LoadField: r1 = r4->field_f
    //     0x84eec0: ldur            w1, [x4, #0xf]
    // 0x84eec4: DecompressPointer r1
    //     0x84eec4: add             x1, x1, HEAP, lsl #32
    // 0x84eec8: r0 = LoadClassIdInstr(r1)
    //     0x84eec8: ldur            x0, [x1, #-1]
    //     0x84eecc: ubfx            x0, x0, #0xc, #0x14
    // 0x84eed0: r2 = "code"
    //     0x84eed0: ldr             x2, [PP, #0x4070]  ; [pp+0x4070] "code"
    // 0x84eed4: r0 = GDT[cid_x0 + -0xd48]()
    //     0x84eed4: sub             lr, x0, #0xd48
    //     0x84eed8: ldr             lr, [x21, lr, lsl #3]
    //     0x84eedc: blr             lr
    // 0x84eee0: mov             x3, x0
    // 0x84eee4: r2 = Null
    //     0x84eee4: mov             x2, NULL
    // 0x84eee8: r1 = Null
    //     0x84eee8: mov             x1, NULL
    // 0x84eeec: stur            x3, [fp, #-0x18]
    // 0x84eef0: r4 = 60
    //     0x84eef0: mov             x4, #0x3c
    // 0x84eef4: branchIfSmi(r0, 0x84ef00)
    //     0x84eef4: tbz             w0, #0, #0x84ef00
    // 0x84eef8: r4 = LoadClassIdInstr(r0)
    //     0x84eef8: ldur            x4, [x0, #-1]
    //     0x84eefc: ubfx            x4, x4, #0xc, #0x14
    // 0x84ef00: sub             x4, x4, #0x5e
    // 0x84ef04: cmp             x4, #1
    // 0x84ef08: b.ls            #0x84ef18
    // 0x84ef0c: r8 = String?
    //     0x84ef0c: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x84ef10: r3 = Null
    //     0x84ef10: ldr             x3, [PP, #0x4078]  ; [pp+0x4078] Null
    // 0x84ef14: r0 = String?()
    //     0x84ef14: bl              #0x7db310  ; IsType_String?_Stub
    // 0x84ef18: ldur            x0, [fp, #-0x18]
    // 0x84ef1c: cmp             w0, NULL
    // 0x84ef20: b.ne            #0x84ef2c
    // 0x84ef24: r3 = ""
    //     0x84ef24: ldr             x3, [PP, #0x900]  ; [pp+0x900] ""
    // 0x84ef28: b               #0x84ef30
    // 0x84ef2c: mov             x3, x0
    // 0x84ef30: ldur            x0, [fp, #-0x10]
    // 0x84ef34: stur            x3, [fp, #-0x18]
    // 0x84ef38: cmp             w0, NULL
    // 0x84ef3c: b.ne            #0x84ef48
    // 0x84ef40: r5 = ""
    //     0x84ef40: ldr             x5, [PP, #0x900]  ; [pp+0x900] ""
    // 0x84ef44: b               #0x84ef4c
    // 0x84ef48: mov             x5, x0
    // 0x84ef4c: ldur            x4, [fp, #-8]
    // 0x84ef50: stur            x5, [fp, #-0x10]
    // 0x84ef54: LoadField: r1 = r4->field_f
    //     0x84ef54: ldur            w1, [x4, #0xf]
    // 0x84ef58: DecompressPointer r1
    //     0x84ef58: add             x1, x1, HEAP, lsl #32
    // 0x84ef5c: r0 = LoadClassIdInstr(r1)
    //     0x84ef5c: ldur            x0, [x1, #-1]
    //     0x84ef60: ubfx            x0, x0, #0xc, #0x14
    // 0x84ef64: r2 = "location"
    //     0x84ef64: ldr             x2, [PP, #0x1a48]  ; [pp+0x1a48] "location"
    // 0x84ef68: r0 = GDT[cid_x0 + -0xd48]()
    //     0x84ef68: sub             lr, x0, #0xd48
    //     0x84ef6c: ldr             lr, [x21, lr, lsl #3]
    //     0x84ef70: blr             lr
    // 0x84ef74: mov             x3, x0
    // 0x84ef78: r2 = Null
    //     0x84ef78: mov             x2, NULL
    // 0x84ef7c: r1 = Null
    //     0x84ef7c: mov             x1, NULL
    // 0x84ef80: stur            x3, [fp, #-0x20]
    // 0x84ef84: branchIfSmi(r0, 0x84efa8)
    //     0x84ef84: tbz             w0, #0, #0x84efa8
    // 0x84ef88: r4 = LoadClassIdInstr(r0)
    //     0x84ef88: ldur            x4, [x0, #-1]
    //     0x84ef8c: ubfx            x4, x4, #0xc, #0x14
    // 0x84ef90: sub             x4, x4, #0x3c
    // 0x84ef94: cmp             x4, #1
    // 0x84ef98: b.ls            #0x84efa8
    // 0x84ef9c: r8 = int?
    //     0x84ef9c: ldr             x8, [PP, #0x3d30]  ; [pp+0x3d30] Type: int?
    // 0x84efa0: r3 = Null
    //     0x84efa0: ldr             x3, [PP, #0x4088]  ; [pp+0x4088] Null
    // 0x84efa4: r0 = int?()
    //     0x84efa4: bl              #0x13ee944  ; IsType_int?_Stub
    // 0x84efa8: ldur            x0, [fp, #-0x20]
    // 0x84efac: cmp             w0, NULL
    // 0x84efb0: b.ne            #0x84efbc
    // 0x84efb4: r4 = 0
    //     0x84efb4: mov             x4, #0
    // 0x84efb8: b               #0x84efcc
    // 0x84efbc: r1 = LoadInt32Instr(r0)
    //     0x84efbc: sbfx            x1, x0, #1, #0x1f
    //     0x84efc0: tbz             w0, #0, #0x84efc8
    //     0x84efc4: ldur            x1, [x0, #7]
    // 0x84efc8: mov             x4, x1
    // 0x84efcc: ldur            x3, [fp, #-8]
    // 0x84efd0: stur            x4, [fp, #-0x28]
    // 0x84efd4: LoadField: r1 = r3->field_f
    //     0x84efd4: ldur            w1, [x3, #0xf]
    // 0x84efd8: DecompressPointer r1
    //     0x84efd8: add             x1, x1, HEAP, lsl #32
    // 0x84efdc: r0 = LoadClassIdInstr(r1)
    //     0x84efdc: ldur            x0, [x1, #-1]
    //     0x84efe0: ubfx            x0, x0, #0xc, #0x14
    // 0x84efe4: r2 = "metaState"
    //     0x84efe4: ldr             x2, [PP, #0x3da8]  ; [pp+0x3da8] "metaState"
    // 0x84efe8: r0 = GDT[cid_x0 + -0xd48]()
    //     0x84efe8: sub             lr, x0, #0xd48
    //     0x84efec: ldr             lr, [x21, lr, lsl #3]
    //     0x84eff0: blr             lr
    // 0x84eff4: mov             x3, x0
    // 0x84eff8: r2 = Null
    //     0x84eff8: mov             x2, NULL
    // 0x84effc: r1 = Null
    //     0x84effc: mov             x1, NULL
    // 0x84f000: stur            x3, [fp, #-0x20]
    // 0x84f004: branchIfSmi(r0, 0x84f028)
    //     0x84f004: tbz             w0, #0, #0x84f028
    // 0x84f008: r4 = LoadClassIdInstr(r0)
    //     0x84f008: ldur            x4, [x0, #-1]
    //     0x84f00c: ubfx            x4, x4, #0xc, #0x14
    // 0x84f010: sub             x4, x4, #0x3c
    // 0x84f014: cmp             x4, #1
    // 0x84f018: b.ls            #0x84f028
    // 0x84f01c: r8 = int?
    //     0x84f01c: ldr             x8, [PP, #0x3d30]  ; [pp+0x3d30] Type: int?
    // 0x84f020: r3 = Null
    //     0x84f020: ldr             x3, [PP, #0x4098]  ; [pp+0x4098] Null
    // 0x84f024: r0 = int?()
    //     0x84f024: bl              #0x13ee944  ; IsType_int?_Stub
    // 0x84f028: ldur            x0, [fp, #-0x20]
    // 0x84f02c: cmp             w0, NULL
    // 0x84f030: b.ne            #0x84f03c
    // 0x84f034: r3 = 0
    //     0x84f034: mov             x3, #0
    // 0x84f038: b               #0x84f04c
    // 0x84f03c: r1 = LoadInt32Instr(r0)
    //     0x84f03c: sbfx            x1, x0, #1, #0x1f
    //     0x84f040: tbz             w0, #0, #0x84f048
    //     0x84f044: ldur            x1, [x0, #7]
    // 0x84f048: mov             x3, x1
    // 0x84f04c: ldur            x0, [fp, #-8]
    // 0x84f050: stur            x3, [fp, #-0x30]
    // 0x84f054: LoadField: r1 = r0->field_f
    //     0x84f054: ldur            w1, [x0, #0xf]
    // 0x84f058: DecompressPointer r1
    //     0x84f058: add             x1, x1, HEAP, lsl #32
    // 0x84f05c: r0 = LoadClassIdInstr(r1)
    //     0x84f05c: ldur            x0, [x1, #-1]
    //     0x84f060: ubfx            x0, x0, #0xc, #0x14
    // 0x84f064: r2 = "keyCode"
    //     0x84f064: ldr             x2, [PP, #0x3d60]  ; [pp+0x3d60] "keyCode"
    // 0x84f068: r0 = GDT[cid_x0 + -0xd48]()
    //     0x84f068: sub             lr, x0, #0xd48
    //     0x84f06c: ldr             lr, [x21, lr, lsl #3]
    //     0x84f070: blr             lr
    // 0x84f074: mov             x3, x0
    // 0x84f078: r2 = Null
    //     0x84f078: mov             x2, NULL
    // 0x84f07c: r1 = Null
    //     0x84f07c: mov             x1, NULL
    // 0x84f080: stur            x3, [fp, #-8]
    // 0x84f084: branchIfSmi(r0, 0x84f0a8)
    //     0x84f084: tbz             w0, #0, #0x84f0a8
    // 0x84f088: r4 = LoadClassIdInstr(r0)
    //     0x84f088: ldur            x4, [x0, #-1]
    //     0x84f08c: ubfx            x4, x4, #0xc, #0x14
    // 0x84f090: sub             x4, x4, #0x3c
    // 0x84f094: cmp             x4, #1
    // 0x84f098: b.ls            #0x84f0a8
    // 0x84f09c: r8 = int?
    //     0x84f09c: ldr             x8, [PP, #0x3d30]  ; [pp+0x3d30] Type: int?
    // 0x84f0a0: r3 = Null
    //     0x84f0a0: ldr             x3, [PP, #0x40a8]  ; [pp+0x40a8] Null
    // 0x84f0a4: r0 = int?()
    //     0x84f0a4: bl              #0x13ee944  ; IsType_int?_Stub
    // 0x84f0a8: ldur            x0, [fp, #-8]
    // 0x84f0ac: cmp             w0, NULL
    // 0x84f0b0: b.ne            #0x84f0bc
    // 0x84f0b4: r4 = 0
    //     0x84f0b4: mov             x4, #0
    // 0x84f0b8: b               #0x84f0cc
    // 0x84f0bc: r1 = LoadInt32Instr(r0)
    //     0x84f0bc: sbfx            x1, x0, #1, #0x1f
    //     0x84f0c0: tbz             w0, #0, #0x84f0c8
    //     0x84f0c4: ldur            x1, [x0, #7]
    // 0x84f0c8: mov             x4, x1
    // 0x84f0cc: ldur            x2, [fp, #-0x18]
    // 0x84f0d0: ldur            x3, [fp, #-0x10]
    // 0x84f0d4: ldur            x1, [fp, #-0x28]
    // 0x84f0d8: ldur            x0, [fp, #-0x30]
    // 0x84f0dc: stur            x4, [fp, #-0x38]
    // 0x84f0e0: r0 = RawKeyEventDataWeb()
    //     0x84f0e0: bl              #0x84f120  ; AllocateRawKeyEventDataWebStub -> RawKeyEventDataWeb (size=0x28)
    // 0x84f0e4: ldur            x1, [fp, #-0x18]
    // 0x84f0e8: StoreField: r0->field_7 = r1
    //     0x84f0e8: stur            w1, [x0, #7]
    // 0x84f0ec: ldur            x1, [fp, #-0x10]
    // 0x84f0f0: StoreField: r0->field_b = r1
    //     0x84f0f0: stur            w1, [x0, #0xb]
    // 0x84f0f4: ldur            x1, [fp, #-0x28]
    // 0x84f0f8: StoreField: r0->field_f = r1
    //     0x84f0f8: stur            x1, [x0, #0xf]
    // 0x84f0fc: ldur            x1, [fp, #-0x30]
    // 0x84f100: ArrayStore: r0[0] = r1  ; List_8
    //     0x84f100: stur            x1, [x0, #0x17]
    // 0x84f104: ldur            x1, [fp, #-0x38]
    // 0x84f108: StoreField: r0->field_1f = r1
    //     0x84f108: stur            x1, [x0, #0x1f]
    // 0x84f10c: LeaveFrame
    //     0x84f10c: mov             SP, fp
    //     0x84f110: ldp             fp, lr, [SP], #0x10
    // 0x84f114: ret
    //     0x84f114: ret             
    // 0x84f118: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84f118: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84f11c: b               #0x84ee10
  }
}

// class id: 5016, size: 0x10, field offset: 0x10
//   const constructor, 
class RawKeyUpEvent extends RawKeyEvent {
}

// class id: 5017, size: 0x10, field offset: 0x10
//   const constructor, 
class RawKeyDownEvent extends RawKeyEvent {
}

// class id: 5018, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class RawKeyEventData extends _MixinApplication3&Object&Diagnosticable {

  get _ modifiersPressed(/* No info */) {
    // ** addr: 0x84c538, size: 0x10c
    // 0x84c538: EnterFrame
    //     0x84c538: stp             fp, lr, [SP, #-0x10]!
    //     0x84c53c: mov             fp, SP
    // 0x84c540: AllocStack(0x38)
    //     0x84c540: sub             SP, SP, #0x38
    // 0x84c544: SetupParameters(RawKeyEventData this /* r1 => r1, fp-0x8 */)
    //     0x84c544: stur            x1, [fp, #-8]
    // 0x84c548: CheckStackOverflow
    //     0x84c548: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84c54c: cmp             SP, x16
    //     0x84c550: b.ls            #0x84c634
    // 0x84c554: r16 = <ModifierKey, KeyboardSide>
    //     0x84c554: ldr             x16, [PP, #0x3bc0]  ; [pp+0x3bc0] TypeArguments: <ModifierKey, KeyboardSide>
    // 0x84c558: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x84c55c: stp             lr, x16, [SP]
    // 0x84c560: r0 = Map._fromLiteral()
    //     0x84c560: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x84c564: mov             x3, x0
    // 0x84c568: stur            x3, [fp, #-0x20]
    // 0x84c56c: r0 = 0
    //     0x84c56c: mov             x0, #0
    // 0x84c570: ldur            x4, [fp, #-8]
    // 0x84c574: r5 = const [Instance of 'ModifierKey', Instance of 'ModifierKey', Instance of 'ModifierKey', Instance of 'ModifierKey', Instance of 'ModifierKey', Instance of 'ModifierKey', Instance of 'ModifierKey', Instance of 'ModifierKey', Instance of 'ModifierKey']
    //     0x84c574: ldr             x5, [PP, #0x3b50]  ; [pp+0x3b50] List<ModifierKey>(9)
    // 0x84c578: CheckStackOverflow
    //     0x84c578: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84c57c: cmp             SP, x16
    //     0x84c580: b.ls            #0x84c63c
    // 0x84c584: cmp             x0, #9
    // 0x84c588: b.ge            #0x84c624
    // 0x84c58c: ArrayLoad: r6 = r5[r0]  ; Unknown_4
    //     0x84c58c: add             x16, x5, x0, lsl #2
    //     0x84c590: ldur            w6, [x16, #0xf]
    // 0x84c594: DecompressPointer r6
    //     0x84c594: add             x6, x6, HEAP, lsl #32
    // 0x84c598: stur            x6, [fp, #-0x18]
    // 0x84c59c: add             x7, x0, #1
    // 0x84c5a0: stur            x7, [fp, #-0x10]
    // 0x84c5a4: r0 = LoadClassIdInstr(r4)
    //     0x84c5a4: ldur            x0, [x4, #-1]
    //     0x84c5a8: ubfx            x0, x0, #0xc, #0x14
    // 0x84c5ac: mov             x1, x4
    // 0x84c5b0: mov             x2, x6
    // 0x84c5b4: r0 = GDT[cid_x0 + 0x3c55]()
    //     0x84c5b4: mov             x17, #0x3c55
    //     0x84c5b8: add             lr, x0, x17
    //     0x84c5bc: ldr             lr, [x21, lr, lsl #3]
    //     0x84c5c0: blr             lr
    // 0x84c5c4: tbnz            w0, #4, #0x84c618
    // 0x84c5c8: ldur            x3, [fp, #-8]
    // 0x84c5cc: r0 = LoadClassIdInstr(r3)
    //     0x84c5cc: ldur            x0, [x3, #-1]
    //     0x84c5d0: ubfx            x0, x0, #0xc, #0x14
    // 0x84c5d4: mov             x1, x3
    // 0x84c5d8: ldur            x2, [fp, #-0x18]
    // 0x84c5dc: r0 = GDT[cid_x0 + 0x6f63]()
    //     0x84c5dc: mov             x17, #0x6f63
    //     0x84c5e0: add             lr, x0, x17
    //     0x84c5e4: ldr             lr, [x21, lr, lsl #3]
    //     0x84c5e8: blr             lr
    // 0x84c5ec: stur            x0, [fp, #-0x28]
    // 0x84c5f0: cmp             w0, NULL
    // 0x84c5f4: b.eq            #0x84c618
    // 0x84c5f8: ldur            x16, [fp, #-0x18]
    // 0x84c5fc: str             x16, [SP]
    // 0x84c600: r0 = _getHash()
    //     0x84c600: bl              #0x84c644  ; [dart:core] ::_getHash
    // 0x84c604: ldur            x1, [fp, #-0x20]
    // 0x84c608: ldur            x2, [fp, #-0x18]
    // 0x84c60c: ldur            x3, [fp, #-0x28]
    // 0x84c610: mov             x5, x0
    // 0x84c614: r0 = _set()
    //     0x84c614: bl              #0x13d8170  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x84c618: ldur            x0, [fp, #-0x10]
    // 0x84c61c: ldur            x3, [fp, #-0x20]
    // 0x84c620: b               #0x84c570
    // 0x84c624: ldur            x0, [fp, #-0x20]
    // 0x84c628: LeaveFrame
    //     0x84c628: mov             SP, fp
    //     0x84c62c: ldp             fp, lr, [SP], #0x10
    // 0x84c630: ret
    //     0x84c630: ret             
    // 0x84c634: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84c634: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84c638: b               #0x84c554
    // 0x84c63c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84c63c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84c640: b               #0x84c584
  }
}

// class id: 8204, size: 0x14, field offset: 0x14
enum ModifierKey extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11ab7a0, size: 0x64
    // 0x11ab7a0: EnterFrame
    //     0x11ab7a0: stp             fp, lr, [SP, #-0x10]!
    //     0x11ab7a4: mov             fp, SP
    // 0x11ab7a8: AllocStack(0x10)
    //     0x11ab7a8: sub             SP, SP, #0x10
    // 0x11ab7ac: SetupParameters(ModifierKey this /* r1 => r0, fp-0x8 */)
    //     0x11ab7ac: mov             x0, x1
    //     0x11ab7b0: stur            x1, [fp, #-8]
    // 0x11ab7b4: CheckStackOverflow
    //     0x11ab7b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11ab7b8: cmp             SP, x16
    //     0x11ab7bc: b.ls            #0x11ab7fc
    // 0x11ab7c0: r1 = Null
    //     0x11ab7c0: mov             x1, NULL
    // 0x11ab7c4: r2 = 4
    //     0x11ab7c4: mov             x2, #4
    // 0x11ab7c8: r0 = AllocateArray()
    //     0x11ab7c8: bl              #0x13df928  ; AllocateArrayStub
    // 0x11ab7cc: r16 = "ModifierKey."
    //     0x11ab7cc: add             x16, PP, #0x10, lsl #12  ; [pp+0x10de8] "ModifierKey."
    //     0x11ab7d0: ldr             x16, [x16, #0xde8]
    // 0x11ab7d4: StoreField: r0->field_f = r16
    //     0x11ab7d4: stur            w16, [x0, #0xf]
    // 0x11ab7d8: ldur            x1, [fp, #-8]
    // 0x11ab7dc: LoadField: r2 = r1->field_f
    //     0x11ab7dc: ldur            w2, [x1, #0xf]
    // 0x11ab7e0: DecompressPointer r2
    //     0x11ab7e0: add             x2, x2, HEAP, lsl #32
    // 0x11ab7e4: StoreField: r0->field_13 = r2
    //     0x11ab7e4: stur            w2, [x0, #0x13]
    // 0x11ab7e8: str             x0, [SP]
    // 0x11ab7ec: r0 = _interpolate()
    //     0x11ab7ec: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11ab7f0: LeaveFrame
    //     0x11ab7f0: mov             SP, fp
    //     0x11ab7f4: ldp             fp, lr, [SP], #0x10
    // 0x11ab7f8: ret
    //     0x11ab7f8: ret             
    // 0x11ab7fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11ab7fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11ab800: b               #0x11ab7c0
  }
}

// class id: 8205, size: 0x14, field offset: 0x14
enum KeyboardSide extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11ab73c, size: 0x64
    // 0x11ab73c: EnterFrame
    //     0x11ab73c: stp             fp, lr, [SP, #-0x10]!
    //     0x11ab740: mov             fp, SP
    // 0x11ab744: AllocStack(0x10)
    //     0x11ab744: sub             SP, SP, #0x10
    // 0x11ab748: SetupParameters(KeyboardSide this /* r1 => r0, fp-0x8 */)
    //     0x11ab748: mov             x0, x1
    //     0x11ab74c: stur            x1, [fp, #-8]
    // 0x11ab750: CheckStackOverflow
    //     0x11ab750: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11ab754: cmp             SP, x16
    //     0x11ab758: b.ls            #0x11ab798
    // 0x11ab75c: r1 = Null
    //     0x11ab75c: mov             x1, NULL
    // 0x11ab760: r2 = 4
    //     0x11ab760: mov             x2, #4
    // 0x11ab764: r0 = AllocateArray()
    //     0x11ab764: bl              #0x13df928  ; AllocateArrayStub
    // 0x11ab768: r16 = "KeyboardSide."
    //     0x11ab768: add             x16, PP, #0x10, lsl #12  ; [pp+0x10df0] "KeyboardSide."
    //     0x11ab76c: ldr             x16, [x16, #0xdf0]
    // 0x11ab770: StoreField: r0->field_f = r16
    //     0x11ab770: stur            w16, [x0, #0xf]
    // 0x11ab774: ldur            x1, [fp, #-8]
    // 0x11ab778: LoadField: r2 = r1->field_f
    //     0x11ab778: ldur            w2, [x1, #0xf]
    // 0x11ab77c: DecompressPointer r2
    //     0x11ab77c: add             x2, x2, HEAP, lsl #32
    // 0x11ab780: StoreField: r0->field_13 = r2
    //     0x11ab780: stur            w2, [x0, #0x13]
    // 0x11ab784: str             x0, [SP]
    // 0x11ab788: r0 = _interpolate()
    //     0x11ab788: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11ab78c: LeaveFrame
    //     0x11ab78c: mov             SP, fp
    //     0x11ab790: ldp             fp, lr, [SP], #0x10
    // 0x11ab794: ret
    //     0x11ab794: ret             
    // 0x11ab798: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11ab798: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11ab79c: b               #0x11ab75c
  }
}
