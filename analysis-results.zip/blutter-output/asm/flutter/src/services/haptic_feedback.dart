// lib: , url: package:flutter/src/services/haptic_feedback.dart

// class id: 1049073, size: 0x8
class :: {
}

// class id: 2797, size: 0x8, field offset: 0x8
abstract class HapticFeedback extends Object {

  static Future<void> selectionClick() async {
    // ** addr: 0x859550, size: 0x60
    // 0x859550: EnterFrame
    //     0x859550: stp             fp, lr, [SP, #-0x10]!
    //     0x859554: mov             fp, SP
    // 0x859558: AllocStack(0x30)
    //     0x859558: sub             SP, SP, #0x30
    // 0x85955c: SetupParameters()
    //     0x85955c: stur            NULL, [fp, #-8]
    // 0x859560: CheckStackOverflow
    //     0x859560: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x859564: cmp             SP, x16
    //     0x859568: b.ls            #0x8595a8
    // 0x85956c: InitAsync() -> Future<void?>
    //     0x85956c: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0x859570: bl              #0x7f5e44  ; InitAsyncStub
    // 0x859574: r16 = <void?>
    //     0x859574: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x859578: r30 = Instance_OptionalMethodChannel
    //     0x859578: ldr             lr, [PP, #0x1960]  ; [pp+0x1960] Obj!OptionalMethodChannel@129bec1
    // 0x85957c: stp             lr, x16, [SP, #0x10]
    // 0x859580: r16 = "HapticFeedback.vibrate"
    //     0x859580: ldr             x16, [PP, #0x4da0]  ; [pp+0x4da0] "HapticFeedback.vibrate"
    // 0x859584: r30 = "HapticFeedbackType.selectionClick"
    //     0x859584: ldr             lr, [PP, #0x4da8]  ; [pp+0x4da8] "HapticFeedbackType.selectionClick"
    // 0x859588: stp             lr, x16, [SP]
    // 0x85958c: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x85958c: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x859590: r0 = invokeMethod()
    //     0x859590: bl              #0x130ad0c  ; [package:flutter/src/services/platform_channel.dart] OptionalMethodChannel::invokeMethod
    // 0x859594: mov             x1, x0
    // 0x859598: stur            x1, [fp, #-0x10]
    // 0x85959c: r0 = Await()
    //     0x85959c: bl              #0x7f5c00  ; AwaitStub
    // 0x8595a0: r0 = Null
    //     0x8595a0: mov             x0, NULL
    // 0x8595a4: r0 = ReturnAsyncNotFuture()
    //     0x8595a4: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x8595a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8595a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8595ac: b               #0x85956c
  }
  static Future<void> mediumImpact() async {
    // ** addr: 0xd39998, size: 0x64
    // 0xd39998: EnterFrame
    //     0xd39998: stp             fp, lr, [SP, #-0x10]!
    //     0xd3999c: mov             fp, SP
    // 0xd399a0: AllocStack(0x30)
    //     0xd399a0: sub             SP, SP, #0x30
    // 0xd399a4: SetupParameters()
    //     0xd399a4: stur            NULL, [fp, #-8]
    // 0xd399a8: CheckStackOverflow
    //     0xd399a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd399ac: cmp             SP, x16
    //     0xd399b0: b.ls            #0xd399f4
    // 0xd399b4: InitAsync() -> Future<void?>
    //     0xd399b4: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0xd399b8: bl              #0x7f5e44  ; InitAsyncStub
    // 0xd399bc: r16 = <void?>
    //     0xd399bc: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xd399c0: r30 = Instance_OptionalMethodChannel
    //     0xd399c0: ldr             lr, [PP, #0x1960]  ; [pp+0x1960] Obj!OptionalMethodChannel@129bec1
    // 0xd399c4: stp             lr, x16, [SP, #0x10]
    // 0xd399c8: r16 = "HapticFeedback.vibrate"
    //     0xd399c8: ldr             x16, [PP, #0x4da0]  ; [pp+0x4da0] "HapticFeedback.vibrate"
    // 0xd399cc: r30 = "HapticFeedbackType.mediumImpact"
    //     0xd399cc: add             lr, PP, #0xad, lsl #12  ; [pp+0xada48] "HapticFeedbackType.mediumImpact"
    //     0xd399d0: ldr             lr, [lr, #0xa48]
    // 0xd399d4: stp             lr, x16, [SP]
    // 0xd399d8: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xd399d8: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xd399dc: r0 = invokeMethod()
    //     0xd399dc: bl              #0x130ad0c  ; [package:flutter/src/services/platform_channel.dart] OptionalMethodChannel::invokeMethod
    // 0xd399e0: mov             x1, x0
    // 0xd399e4: stur            x1, [fp, #-0x10]
    // 0xd399e8: r0 = Await()
    //     0xd399e8: bl              #0x7f5c00  ; AwaitStub
    // 0xd399ec: r0 = Null
    //     0xd399ec: mov             x0, NULL
    // 0xd399f0: r0 = ReturnAsyncNotFuture()
    //     0xd399f0: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xd399f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd399f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd399f8: b               #0xd399b4
  }
  static Future<void> vibrate() async {
    // ** addr: 0xd4731c, size: 0x5c
    // 0xd4731c: EnterFrame
    //     0xd4731c: stp             fp, lr, [SP, #-0x10]!
    //     0xd47320: mov             fp, SP
    // 0xd47324: AllocStack(0x28)
    //     0xd47324: sub             SP, SP, #0x28
    // 0xd47328: SetupParameters()
    //     0xd47328: stur            NULL, [fp, #-8]
    // 0xd4732c: CheckStackOverflow
    //     0xd4732c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd47330: cmp             SP, x16
    //     0xd47334: b.ls            #0xd47370
    // 0xd47338: InitAsync() -> Future<void?>
    //     0xd47338: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0xd4733c: bl              #0x7f5e44  ; InitAsyncStub
    // 0xd47340: r16 = <void?>
    //     0xd47340: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xd47344: r30 = Instance_OptionalMethodChannel
    //     0xd47344: ldr             lr, [PP, #0x1960]  ; [pp+0x1960] Obj!OptionalMethodChannel@129bec1
    // 0xd47348: stp             lr, x16, [SP, #8]
    // 0xd4734c: r16 = "HapticFeedback.vibrate"
    //     0xd4734c: ldr             x16, [PP, #0x4da0]  ; [pp+0x4da0] "HapticFeedback.vibrate"
    // 0xd47350: str             x16, [SP]
    // 0xd47354: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xd47354: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xd47358: r0 = invokeMethod()
    //     0xd47358: bl              #0x130ad0c  ; [package:flutter/src/services/platform_channel.dart] OptionalMethodChannel::invokeMethod
    // 0xd4735c: mov             x1, x0
    // 0xd47360: stur            x1, [fp, #-0x10]
    // 0xd47364: r0 = Await()
    //     0xd47364: bl              #0x7f5c00  ; AwaitStub
    // 0xd47368: r0 = Null
    //     0xd47368: mov             x0, NULL
    // 0xd4736c: r0 = ReturnAsyncNotFuture()
    //     0xd4736c: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xd47370: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd47370: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd47374: b               #0xd47338
  }
}
