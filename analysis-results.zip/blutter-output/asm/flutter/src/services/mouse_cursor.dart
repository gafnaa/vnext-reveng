// lib: , url: package:flutter/src/services/mouse_cursor.dart

// class id: 1049080, size: 0x8
class :: {
}

// class id: 2779, size: 0x14, field offset: 0x8
abstract class MouseCursorSession extends Object {
}

// class id: 2780, size: 0x14, field offset: 0x14
class _SystemMouseCursorSession extends MouseCursorSession {

  _ activate(/* No info */) {
    // ** addr: 0x1309ad8, size: 0xf0
    // 0x1309ad8: EnterFrame
    //     0x1309ad8: stp             fp, lr, [SP, #-0x10]!
    //     0x1309adc: mov             fp, SP
    // 0x1309ae0: AllocStack(0x38)
    //     0x1309ae0: sub             SP, SP, #0x38
    // 0x1309ae4: SetupParameters(_SystemMouseCursorSession this /* r1 => r0, fp-0x8 */)
    //     0x1309ae4: mov             x0, x1
    //     0x1309ae8: stur            x1, [fp, #-8]
    // 0x1309aec: CheckStackOverflow
    //     0x1309aec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1309af0: cmp             SP, x16
    //     0x1309af4: b.ls            #0x1309bc0
    // 0x1309af8: r1 = Null
    //     0x1309af8: mov             x1, NULL
    // 0x1309afc: r2 = 8
    //     0x1309afc: mov             x2, #8
    // 0x1309b00: r0 = AllocateArray()
    //     0x1309b00: bl              #0x13df928  ; AllocateArrayStub
    // 0x1309b04: mov             x3, x0
    // 0x1309b08: stur            x3, [fp, #-0x18]
    // 0x1309b0c: r16 = "device"
    //     0x1309b0c: ldr             x16, [PP, #0x21b8]  ; [pp+0x21b8] "device"
    // 0x1309b10: StoreField: r3->field_f = r16
    //     0x1309b10: stur            w16, [x3, #0xf]
    // 0x1309b14: ldur            x2, [fp, #-8]
    // 0x1309b18: LoadField: r4 = r2->field_b
    //     0x1309b18: ldur            x4, [x2, #0xb]
    // 0x1309b1c: r0 = BoxInt64Instr(r4)
    //     0x1309b1c: sbfiz           x0, x4, #1, #0x1f
    //     0x1309b20: cmp             x4, x0, asr #1
    //     0x1309b24: b.eq            #0x1309b30
    //     0x1309b28: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1309b2c: stur            x4, [x0, #7]
    // 0x1309b30: StoreField: r3->field_13 = r0
    //     0x1309b30: stur            w0, [x3, #0x13]
    // 0x1309b34: r16 = "kind"
    //     0x1309b34: ldr             x16, [PP, #0x21c0]  ; [pp+0x21c0] "kind"
    // 0x1309b38: ArrayStore: r3[0] = r16  ; List_4
    //     0x1309b38: stur            w16, [x3, #0x17]
    // 0x1309b3c: LoadField: r4 = r2->field_7
    //     0x1309b3c: ldur            w4, [x2, #7]
    // 0x1309b40: DecompressPointer r4
    //     0x1309b40: add             x4, x4, HEAP, lsl #32
    // 0x1309b44: mov             x0, x4
    // 0x1309b48: stur            x4, [fp, #-0x10]
    // 0x1309b4c: r2 = Null
    //     0x1309b4c: mov             x2, NULL
    // 0x1309b50: r1 = Null
    //     0x1309b50: mov             x1, NULL
    // 0x1309b54: r4 = LoadClassIdInstr(r0)
    //     0x1309b54: ldur            x4, [x0, #-1]
    //     0x1309b58: ubfx            x4, x4, #0xc, #0x14
    // 0x1309b5c: r17 = 5184
    //     0x1309b5c: mov             x17, #0x1440
    // 0x1309b60: cmp             x4, x17
    // 0x1309b64: b.eq            #0x1309b78
    // 0x1309b68: r8 = SystemMouseCursor
    //     0x1309b68: ldr             x8, [PP, #0x21c8]  ; [pp+0x21c8] Type: SystemMouseCursor
    // 0x1309b6c: r3 = Null
    //     0x1309b6c: add             x3, PP, #0x10, lsl #12  ; [pp+0x10e68] Null
    //     0x1309b70: ldr             x3, [x3, #0xe68]
    // 0x1309b74: r0 = DefaultTypeTest()
    //     0x1309b74: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x1309b78: ldur            x0, [fp, #-0x10]
    // 0x1309b7c: LoadField: r1 = r0->field_7
    //     0x1309b7c: ldur            w1, [x0, #7]
    // 0x1309b80: DecompressPointer r1
    //     0x1309b80: add             x1, x1, HEAP, lsl #32
    // 0x1309b84: ldur            x0, [fp, #-0x18]
    // 0x1309b88: StoreField: r0->field_1b = r1
    //     0x1309b88: stur            w1, [x0, #0x1b]
    // 0x1309b8c: r16 = <String, dynamic>
    //     0x1309b8c: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x1309b90: stp             x0, x16, [SP]
    // 0x1309b94: r0 = Map._fromLiteral()
    //     0x1309b94: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x1309b98: r16 = <void?>
    //     0x1309b98: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x1309b9c: r30 = Instance_OptionalMethodChannel
    //     0x1309b9c: ldr             lr, [PP, #0x21e8]  ; [pp+0x21e8] Obj!OptionalMethodChannel@129be21
    // 0x1309ba0: stp             lr, x16, [SP, #0x10]
    // 0x1309ba4: r16 = "activateSystemCursor"
    //     0x1309ba4: ldr             x16, [PP, #0x21f0]  ; [pp+0x21f0] "activateSystemCursor"
    // 0x1309ba8: stp             x0, x16, [SP]
    // 0x1309bac: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x1309bac: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x1309bb0: r0 = invokeMethod()
    //     0x1309bb0: bl              #0x130ad0c  ; [package:flutter/src/services/platform_channel.dart] OptionalMethodChannel::invokeMethod
    // 0x1309bb4: LeaveFrame
    //     0x1309bb4: mov             SP, fp
    //     0x1309bb8: ldp             fp, lr, [SP], #0x10
    // 0x1309bbc: ret
    //     0x1309bbc: ret             
    // 0x1309bc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1309bc0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1309bc4: b               #0x1309af8
  }
  get _ cursor(/* No info */) {
    // ** addr: 0x130a700, size: 0x58
    // 0x130a700: EnterFrame
    //     0x130a700: stp             fp, lr, [SP, #-0x10]!
    //     0x130a704: mov             fp, SP
    // 0x130a708: AllocStack(0x8)
    //     0x130a708: sub             SP, SP, #8
    // 0x130a70c: LoadField: r3 = r1->field_7
    //     0x130a70c: ldur            w3, [x1, #7]
    // 0x130a710: DecompressPointer r3
    //     0x130a710: add             x3, x3, HEAP, lsl #32
    // 0x130a714: mov             x0, x3
    // 0x130a718: stur            x3, [fp, #-8]
    // 0x130a71c: r2 = Null
    //     0x130a71c: mov             x2, NULL
    // 0x130a720: r1 = Null
    //     0x130a720: mov             x1, NULL
    // 0x130a724: r4 = LoadClassIdInstr(r0)
    //     0x130a724: ldur            x4, [x0, #-1]
    //     0x130a728: ubfx            x4, x4, #0xc, #0x14
    // 0x130a72c: r17 = 5184
    //     0x130a72c: mov             x17, #0x1440
    // 0x130a730: cmp             x4, x17
    // 0x130a734: b.eq            #0x130a748
    // 0x130a738: r8 = SystemMouseCursor
    //     0x130a738: ldr             x8, [PP, #0x21c8]  ; [pp+0x21c8] Type: SystemMouseCursor
    // 0x130a73c: r3 = Null
    //     0x130a73c: add             x3, PP, #0x10, lsl #12  ; [pp+0x10e78] Null
    //     0x130a740: ldr             x3, [x3, #0xe78]
    // 0x130a744: r0 = DefaultTypeTest()
    //     0x130a744: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x130a748: ldur            x0, [fp, #-8]
    // 0x130a74c: LeaveFrame
    //     0x130a74c: mov             SP, fp
    //     0x130a750: ldp             fp, lr, [SP], #0x10
    // 0x130a754: ret
    //     0x130a754: ret             
  }
}

// class id: 2781, size: 0x14, field offset: 0x14
class _NoopMouseCursorSession extends MouseCursorSession {

  _ activate(/* No info */) async {
    // ** addr: 0x1309aa0, size: 0x38
    // 0x1309aa0: EnterFrame
    //     0x1309aa0: stp             fp, lr, [SP, #-0x10]!
    //     0x1309aa4: mov             fp, SP
    // 0x1309aa8: AllocStack(0x10)
    //     0x1309aa8: sub             SP, SP, #0x10
    // 0x1309aac: SetupParameters(_NoopMouseCursorSession this /* r1 => r1, fp-0x10 */)
    //     0x1309aac: stur            NULL, [fp, #-8]
    //     0x1309ab0: stur            x1, [fp, #-0x10]
    // 0x1309ab4: CheckStackOverflow
    //     0x1309ab4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1309ab8: cmp             SP, x16
    //     0x1309abc: b.ls            #0x1309ad0
    // 0x1309ac0: InitAsync() -> Future<void?>
    //     0x1309ac0: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0x1309ac4: bl              #0x7f5e44  ; InitAsyncStub
    // 0x1309ac8: r0 = Null
    //     0x1309ac8: mov             x0, NULL
    // 0x1309acc: r0 = ReturnAsyncNotFuture()
    //     0x1309acc: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x1309ad0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1309ad0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1309ad4: b               #0x1309ac0
  }
}

// class id: 2782, size: 0x10, field offset: 0x8
class MouseCursorManager extends Object {

  _ handleDeviceCursorUpdate(/* No info */) {
    // ** addr: 0x834f00, size: 0x31c
    // 0x834f00: EnterFrame
    //     0x834f00: stp             fp, lr, [SP, #-0x10]!
    //     0x834f04: mov             fp, SP
    // 0x834f08: AllocStack(0x48)
    //     0x834f08: sub             SP, SP, #0x48
    // 0x834f0c: SetupParameters(MouseCursorManager this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r0 */, dynamic _ /* r5 => r3, fp-0x18 */)
    //     0x834f0c: mov             x0, x3
    //     0x834f10: mov             x3, x5
    //     0x834f14: stur            x5, [fp, #-0x18]
    //     0x834f18: mov             x5, x1
    //     0x834f1c: mov             x4, x2
    //     0x834f20: stur            x1, [fp, #-8]
    //     0x834f24: stur            x2, [fp, #-0x10]
    // 0x834f28: CheckStackOverflow
    //     0x834f28: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x834f2c: cmp             SP, x16
    //     0x834f30: b.ls            #0x835214
    // 0x834f34: r2 = Null
    //     0x834f34: mov             x2, NULL
    // 0x834f38: r1 = Null
    //     0x834f38: mov             x1, NULL
    // 0x834f3c: cmp             w0, NULL
    // 0x834f40: b.eq            #0x834f68
    // 0x834f44: branchIfSmi(r0, 0x834f68)
    //     0x834f44: tbz             w0, #0, #0x834f68
    // 0x834f48: r3 = LoadClassIdInstr(r0)
    //     0x834f48: ldur            x3, [x0, #-1]
    //     0x834f4c: ubfx            x3, x3, #0xc, #0x14
    // 0x834f50: r17 = 4167
    //     0x834f50: mov             x17, #0x1047
    // 0x834f54: cmp             x3, x17
    // 0x834f58: b.eq            #0x834f70
    // 0x834f5c: r17 = 5296
    //     0x834f5c: mov             x17, #0x14b0
    // 0x834f60: cmp             x3, x17
    // 0x834f64: b.eq            #0x834f70
    // 0x834f68: r0 = false
    //     0x834f68: add             x0, NULL, #0x30  ; false
    // 0x834f6c: b               #0x834f74
    // 0x834f70: r0 = true
    //     0x834f70: add             x0, NULL, #0x20  ; true
    // 0x834f74: tbnz            w0, #4, #0x834fb8
    // 0x834f78: ldur            x0, [fp, #-8]
    // 0x834f7c: ldur            x3, [fp, #-0x10]
    // 0x834f80: LoadField: r2 = r0->field_b
    //     0x834f80: ldur            w2, [x0, #0xb]
    // 0x834f84: DecompressPointer r2
    //     0x834f84: add             x2, x2, HEAP, lsl #32
    // 0x834f88: r0 = BoxInt64Instr(r3)
    //     0x834f88: sbfiz           x0, x3, #1, #0x1f
    //     0x834f8c: cmp             x3, x0, asr #1
    //     0x834f90: b.eq            #0x834f9c
    //     0x834f94: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x834f98: stur            x3, [x0, #7]
    // 0x834f9c: mov             x1, x2
    // 0x834fa0: mov             x2, x0
    // 0x834fa4: r0 = remove()
    //     0x834fa4: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x834fa8: r0 = Null
    //     0x834fa8: mov             x0, NULL
    // 0x834fac: LeaveFrame
    //     0x834fac: mov             SP, fp
    //     0x834fb0: ldp             fp, lr, [SP], #0x10
    // 0x834fb4: ret
    //     0x834fb4: ret             
    // 0x834fb8: ldur            x0, [fp, #-8]
    // 0x834fbc: ldur            x3, [fp, #-0x10]
    // 0x834fc0: LoadField: r4 = r0->field_b
    //     0x834fc0: ldur            w4, [x0, #0xb]
    // 0x834fc4: DecompressPointer r4
    //     0x834fc4: add             x4, x4, HEAP, lsl #32
    // 0x834fc8: stur            x4, [fp, #-0x20]
    // 0x834fcc: r0 = BoxInt64Instr(r3)
    //     0x834fcc: sbfiz           x0, x3, #1, #0x1f
    //     0x834fd0: cmp             x3, x0, asr #1
    //     0x834fd4: b.eq            #0x834fe0
    //     0x834fd8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x834fdc: stur            x3, [x0, #7]
    // 0x834fe0: mov             x1, x4
    // 0x834fe4: mov             x2, x0
    // 0x834fe8: stur            x0, [fp, #-8]
    // 0x834fec: r0 = _getValueOrData()
    //     0x834fec: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x834ff0: mov             x1, x0
    // 0x834ff4: ldur            x0, [fp, #-0x20]
    // 0x834ff8: LoadField: r2 = r0->field_f
    //     0x834ff8: ldur            w2, [x0, #0xf]
    // 0x834ffc: DecompressPointer r2
    //     0x834ffc: add             x2, x2, HEAP, lsl #32
    // 0x835000: cmp             w2, w1
    // 0x835004: b.ne            #0x835010
    // 0x835008: r2 = Null
    //     0x835008: mov             x2, NULL
    // 0x83500c: b               #0x835014
    // 0x835010: mov             x2, x1
    // 0x835014: ldur            x1, [fp, #-0x18]
    // 0x835018: stur            x2, [fp, #-0x28]
    // 0x83501c: r0 = firstNonDeferred()
    //     0x83501c: bl              #0x835240  ; [package:flutter/src/services/mouse_cursor.dart] _DeferringMouseCursor::firstNonDeferred
    // 0x835020: cmp             w0, NULL
    // 0x835024: b.ne            #0x835030
    // 0x835028: r3 = Instance_SystemMouseCursor
    //     0x835028: ldr             x3, [PP, #0x21b0]  ; [pp+0x21b0] Obj!SystemMouseCursor@12b3201
    // 0x83502c: b               #0x835034
    // 0x835030: mov             x3, x0
    // 0x835034: ldur            x2, [fp, #-0x28]
    // 0x835038: stur            x3, [fp, #-0x18]
    // 0x83503c: cmp             w2, NULL
    // 0x835040: b.ne            #0x83504c
    // 0x835044: r0 = Null
    //     0x835044: mov             x0, NULL
    // 0x835048: b               #0x835064
    // 0x83504c: r0 = LoadClassIdInstr(r2)
    //     0x83504c: ldur            x0, [x2, #-1]
    //     0x835050: ubfx            x0, x0, #0xc, #0x14
    // 0x835054: mov             x1, x2
    // 0x835058: r0 = GDT[cid_x0 + -0x1000]()
    //     0x835058: sub             lr, x0, #1, lsl #12
    //     0x83505c: ldr             lr, [x21, lr, lsl #3]
    //     0x835060: blr             lr
    // 0x835064: r1 = LoadClassIdInstr(r0)
    //     0x835064: ldur            x1, [x0, #-1]
    //     0x835068: ubfx            x1, x1, #0xc, #0x14
    // 0x83506c: ldur            x16, [fp, #-0x18]
    // 0x835070: stp             x16, x0, [SP]
    // 0x835074: mov             x0, x1
    // 0x835078: mov             lr, x0
    // 0x83507c: ldr             lr, [x21, lr, lsl #3]
    // 0x835080: blr             lr
    // 0x835084: tbnz            w0, #4, #0x835098
    // 0x835088: r0 = Null
    //     0x835088: mov             x0, NULL
    // 0x83508c: LeaveFrame
    //     0x83508c: mov             SP, fp
    //     0x835090: ldp             fp, lr, [SP], #0x10
    // 0x835094: ret
    //     0x835094: ret             
    // 0x835098: ldur            x1, [fp, #-0x18]
    // 0x83509c: ldur            x3, [fp, #-0x28]
    // 0x8350a0: r0 = LoadClassIdInstr(r1)
    //     0x8350a0: ldur            x0, [x1, #-1]
    //     0x8350a4: ubfx            x0, x0, #0xc, #0x14
    // 0x8350a8: ldur            x2, [fp, #-0x10]
    // 0x8350ac: r0 = GDT[cid_x0 + 0x2bf5]()
    //     0x8350ac: mov             x17, #0x2bf5
    //     0x8350b0: add             lr, x0, x17
    //     0x8350b4: ldr             lr, [x21, lr, lsl #3]
    //     0x8350b8: blr             lr
    // 0x8350bc: ldur            x1, [fp, #-0x20]
    // 0x8350c0: ldur            x2, [fp, #-8]
    // 0x8350c4: stur            x0, [fp, #-0x18]
    // 0x8350c8: r0 = _hashCode()
    //     0x8350c8: bl              #0x13d8cbc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0x8350cc: mov             x2, x0
    // 0x8350d0: r0 = BoxInt64Instr(r2)
    //     0x8350d0: sbfiz           x0, x2, #1, #0x1f
    //     0x8350d4: cmp             x2, x0, asr #1
    //     0x8350d8: b.eq            #0x8350e4
    //     0x8350dc: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8350e0: stur            x2, [x0, #7]
    // 0x8350e4: ldur            x1, [fp, #-0x20]
    // 0x8350e8: ldur            x2, [fp, #-8]
    // 0x8350ec: ldur            x3, [fp, #-0x18]
    // 0x8350f0: mov             x5, x0
    // 0x8350f4: r0 = _set()
    //     0x8350f4: bl              #0x13d8170  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x8350f8: ldur            x1, [fp, #-0x28]
    // 0x8350fc: cmp             w1, NULL
    // 0x835100: b.eq            #0x835118
    // 0x835104: r0 = LoadClassIdInstr(r1)
    //     0x835104: ldur            x0, [x1, #-1]
    //     0x835108: ubfx            x0, x0, #0xc, #0x14
    // 0x83510c: r0 = GDT[cid_x0 + -0xff5]()
    //     0x83510c: sub             lr, x0, #0xff5
    //     0x835110: ldr             lr, [x21, lr, lsl #3]
    //     0x835114: blr             lr
    // 0x835118: ldur            x0, [fp, #-0x18]
    // 0x83511c: r1 = LoadClassIdInstr(r0)
    //     0x83511c: ldur            x1, [x0, #-1]
    //     0x835120: ubfx            x1, x1, #0xc, #0x14
    // 0x835124: cmp             x1, #0xadc
    // 0x835128: b.ne            #0x8351e8
    // 0x83512c: r1 = Null
    //     0x83512c: mov             x1, NULL
    // 0x835130: r2 = 8
    //     0x835130: mov             x2, #8
    // 0x835134: r0 = AllocateArray()
    //     0x835134: bl              #0x13df928  ; AllocateArrayStub
    // 0x835138: mov             x3, x0
    // 0x83513c: stur            x3, [fp, #-0x20]
    // 0x835140: r16 = "device"
    //     0x835140: ldr             x16, [PP, #0x21b8]  ; [pp+0x21b8] "device"
    // 0x835144: StoreField: r3->field_f = r16
    //     0x835144: stur            w16, [x3, #0xf]
    // 0x835148: ldur            x2, [fp, #-0x18]
    // 0x83514c: LoadField: r4 = r2->field_b
    //     0x83514c: ldur            x4, [x2, #0xb]
    // 0x835150: r0 = BoxInt64Instr(r4)
    //     0x835150: sbfiz           x0, x4, #1, #0x1f
    //     0x835154: cmp             x4, x0, asr #1
    //     0x835158: b.eq            #0x835164
    //     0x83515c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x835160: stur            x4, [x0, #7]
    // 0x835164: StoreField: r3->field_13 = r0
    //     0x835164: stur            w0, [x3, #0x13]
    // 0x835168: r16 = "kind"
    //     0x835168: ldr             x16, [PP, #0x21c0]  ; [pp+0x21c0] "kind"
    // 0x83516c: ArrayStore: r3[0] = r16  ; List_4
    //     0x83516c: stur            w16, [x3, #0x17]
    // 0x835170: LoadField: r4 = r2->field_7
    //     0x835170: ldur            w4, [x2, #7]
    // 0x835174: DecompressPointer r4
    //     0x835174: add             x4, x4, HEAP, lsl #32
    // 0x835178: mov             x0, x4
    // 0x83517c: stur            x4, [fp, #-8]
    // 0x835180: r2 = Null
    //     0x835180: mov             x2, NULL
    // 0x835184: r1 = Null
    //     0x835184: mov             x1, NULL
    // 0x835188: r4 = LoadClassIdInstr(r0)
    //     0x835188: ldur            x4, [x0, #-1]
    //     0x83518c: ubfx            x4, x4, #0xc, #0x14
    // 0x835190: r17 = 5184
    //     0x835190: mov             x17, #0x1440
    // 0x835194: cmp             x4, x17
    // 0x835198: b.eq            #0x8351a8
    // 0x83519c: r8 = SystemMouseCursor
    //     0x83519c: ldr             x8, [PP, #0x21c8]  ; [pp+0x21c8] Type: SystemMouseCursor
    // 0x8351a0: r3 = Null
    //     0x8351a0: ldr             x3, [PP, #0x21d0]  ; [pp+0x21d0] Null
    // 0x8351a4: r0 = DefaultTypeTest()
    //     0x8351a4: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x8351a8: ldur            x0, [fp, #-8]
    // 0x8351ac: LoadField: r1 = r0->field_7
    //     0x8351ac: ldur            w1, [x0, #7]
    // 0x8351b0: DecompressPointer r1
    //     0x8351b0: add             x1, x1, HEAP, lsl #32
    // 0x8351b4: ldur            x0, [fp, #-0x20]
    // 0x8351b8: StoreField: r0->field_1b = r1
    //     0x8351b8: stur            w1, [x0, #0x1b]
    // 0x8351bc: r16 = <String, dynamic>
    //     0x8351bc: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x8351c0: stp             x0, x16, [SP]
    // 0x8351c4: r0 = Map._fromLiteral()
    //     0x8351c4: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x8351c8: r16 = <void?>
    //     0x8351c8: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x8351cc: r30 = Instance_OptionalMethodChannel
    //     0x8351cc: ldr             lr, [PP, #0x21e8]  ; [pp+0x21e8] Obj!OptionalMethodChannel@129be21
    // 0x8351d0: stp             lr, x16, [SP, #0x10]
    // 0x8351d4: r16 = "activateSystemCursor"
    //     0x8351d4: ldr             x16, [PP, #0x21f0]  ; [pp+0x21f0] "activateSystemCursor"
    // 0x8351d8: stp             x0, x16, [SP]
    // 0x8351dc: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x8351dc: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x8351e0: r0 = invokeMethod()
    //     0x8351e0: bl              #0x130ad0c  ; [package:flutter/src/services/platform_channel.dart] OptionalMethodChannel::invokeMethod
    // 0x8351e4: b               #0x835204
    // 0x8351e8: mov             x2, x0
    // 0x8351ec: r0 = LoadClassIdInstr(r2)
    //     0x8351ec: ldur            x0, [x2, #-1]
    //     0x8351f0: ubfx            x0, x0, #0xc, #0x14
    // 0x8351f4: mov             x1, x2
    // 0x8351f8: r0 = GDT[cid_x0 + -0xff7]()
    //     0x8351f8: sub             lr, x0, #0xff7
    //     0x8351fc: ldr             lr, [x21, lr, lsl #3]
    //     0x835200: blr             lr
    // 0x835204: r0 = Null
    //     0x835204: mov             x0, NULL
    // 0x835208: LeaveFrame
    //     0x835208: mov             SP, fp
    //     0x83520c: ldp             fp, lr, [SP], #0x10
    // 0x835210: ret
    //     0x835210: ret             
    // 0x835214: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x835214: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x835218: b               #0x834f34
  }
}

// class id: 5183, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class MouseCursor extends _MixinApplication3&Object&Diagnosticable {
}

// class id: 5184, size: 0xc, field offset: 0x8
//   const constructor, 
class SystemMouseCursor extends MouseCursor {

  _OneByteString field_8;

  get _ hashCode(/* No info */) {
    // ** addr: 0x112f8b8, size: 0x40
    // 0x112f8b8: EnterFrame
    //     0x112f8b8: stp             fp, lr, [SP, #-0x10]!
    //     0x112f8bc: mov             fp, SP
    // 0x112f8c0: AllocStack(0x8)
    //     0x112f8c0: sub             SP, SP, #8
    // 0x112f8c4: CheckStackOverflow
    //     0x112f8c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x112f8c8: cmp             SP, x16
    //     0x112f8cc: b.ls            #0x112f8f0
    // 0x112f8d0: ldr             x0, [fp, #0x10]
    // 0x112f8d4: LoadField: r1 = r0->field_7
    //     0x112f8d4: ldur            w1, [x0, #7]
    // 0x112f8d8: DecompressPointer r1
    //     0x112f8d8: add             x1, x1, HEAP, lsl #32
    // 0x112f8dc: str             x1, [SP]
    // 0x112f8e0: r0 = hashCode()
    //     0x112f8e0: bl              #0x1159684  ; [dart:core] _OneByteString::hashCode
    // 0x112f8e4: LeaveFrame
    //     0x112f8e4: mov             SP, fp
    //     0x112f8e8: ldp             fp, lr, [SP], #0x10
    // 0x112f8ec: ret
    //     0x112f8ec: ret             
    // 0x112f8f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x112f8f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x112f8f4: b               #0x112f8d0
  }
  _ createSession(/* No info */) {
    // ** addr: 0x119542c, size: 0x34
    // 0x119542c: EnterFrame
    //     0x119542c: stp             fp, lr, [SP, #-0x10]!
    //     0x1195430: mov             fp, SP
    // 0x1195434: AllocStack(0x10)
    //     0x1195434: sub             SP, SP, #0x10
    // 0x1195438: SetupParameters(SystemMouseCursor this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x1195438: stur            x1, [fp, #-8]
    //     0x119543c: stur            x2, [fp, #-0x10]
    // 0x1195440: r0 = _SystemMouseCursorSession()
    //     0x1195440: bl              #0x1195460  ; Allocate_SystemMouseCursorSessionStub -> _SystemMouseCursorSession (size=0x14)
    // 0x1195444: ldur            x1, [fp, #-8]
    // 0x1195448: StoreField: r0->field_7 = r1
    //     0x1195448: stur            w1, [x0, #7]
    // 0x119544c: ldur            x1, [fp, #-0x10]
    // 0x1195450: StoreField: r0->field_b = r1
    //     0x1195450: stur            x1, [x0, #0xb]
    // 0x1195454: LeaveFrame
    //     0x1195454: mov             SP, fp
    //     0x1195458: ldp             fp, lr, [SP], #0x10
    // 0x119545c: ret
    //     0x119545c: ret             
  }
  _ ==(/* No info */) {
    // ** addr: 0x1265728, size: 0xc8
    // 0x1265728: EnterFrame
    //     0x1265728: stp             fp, lr, [SP, #-0x10]!
    //     0x126572c: mov             fp, SP
    // 0x1265730: AllocStack(0x10)
    //     0x1265730: sub             SP, SP, #0x10
    // 0x1265734: CheckStackOverflow
    //     0x1265734: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1265738: cmp             SP, x16
    //     0x126573c: b.ls            #0x12657e8
    // 0x1265740: ldr             x0, [fp, #0x10]
    // 0x1265744: cmp             w0, NULL
    // 0x1265748: b.ne            #0x126575c
    // 0x126574c: r0 = false
    //     0x126574c: add             x0, NULL, #0x30  ; false
    // 0x1265750: LeaveFrame
    //     0x1265750: mov             SP, fp
    //     0x1265754: ldp             fp, lr, [SP], #0x10
    // 0x1265758: ret
    //     0x1265758: ret             
    // 0x126575c: str             x0, [SP]
    // 0x1265760: r0 = runtimeType()
    //     0x1265760: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x1265764: r1 = LoadClassIdInstr(r0)
    //     0x1265764: ldur            x1, [x0, #-1]
    //     0x1265768: ubfx            x1, x1, #0xc, #0x14
    // 0x126576c: r16 = SystemMouseCursor
    //     0x126576c: ldr             x16, [PP, #0x21c8]  ; [pp+0x21c8] Type: SystemMouseCursor
    // 0x1265770: stp             x16, x0, [SP]
    // 0x1265774: mov             x0, x1
    // 0x1265778: mov             lr, x0
    // 0x126577c: ldr             lr, [x21, lr, lsl #3]
    // 0x1265780: blr             lr
    // 0x1265784: tbz             w0, #4, #0x1265798
    // 0x1265788: r0 = false
    //     0x1265788: add             x0, NULL, #0x30  ; false
    // 0x126578c: LeaveFrame
    //     0x126578c: mov             SP, fp
    //     0x1265790: ldp             fp, lr, [SP], #0x10
    // 0x1265794: ret
    //     0x1265794: ret             
    // 0x1265798: ldr             x0, [fp, #0x10]
    // 0x126579c: r1 = 60
    //     0x126579c: mov             x1, #0x3c
    // 0x12657a0: branchIfSmi(r0, 0x12657ac)
    //     0x12657a0: tbz             w0, #0, #0x12657ac
    // 0x12657a4: r1 = LoadClassIdInstr(r0)
    //     0x12657a4: ldur            x1, [x0, #-1]
    //     0x12657a8: ubfx            x1, x1, #0xc, #0x14
    // 0x12657ac: r17 = 5184
    //     0x12657ac: mov             x17, #0x1440
    // 0x12657b0: cmp             x1, x17
    // 0x12657b4: b.ne            #0x12657d8
    // 0x12657b8: ldr             x1, [fp, #0x18]
    // 0x12657bc: LoadField: r2 = r0->field_7
    //     0x12657bc: ldur            w2, [x0, #7]
    // 0x12657c0: DecompressPointer r2
    //     0x12657c0: add             x2, x2, HEAP, lsl #32
    // 0x12657c4: LoadField: r0 = r1->field_7
    //     0x12657c4: ldur            w0, [x1, #7]
    // 0x12657c8: DecompressPointer r0
    //     0x12657c8: add             x0, x0, HEAP, lsl #32
    // 0x12657cc: stp             x0, x2, [SP]
    // 0x12657d0: r0 = ==()
    //     0x12657d0: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0x12657d4: b               #0x12657dc
    // 0x12657d8: r0 = false
    //     0x12657d8: add             x0, NULL, #0x30  ; false
    // 0x12657dc: LeaveFrame
    //     0x12657dc: mov             SP, fp
    //     0x12657e0: ldp             fp, lr, [SP], #0x10
    // 0x12657e4: ret
    //     0x12657e4: ret             
    // 0x12657e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12657e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12657ec: b               #0x1265740
  }
}

// class id: 5185, size: 0x8, field offset: 0x8
//   const constructor, 
class _NoopMouseCursor extends MouseCursor {

  _ createSession(/* No info */) {
    // ** addr: 0x11953ec, size: 0x34
    // 0x11953ec: EnterFrame
    //     0x11953ec: stp             fp, lr, [SP, #-0x10]!
    //     0x11953f0: mov             fp, SP
    // 0x11953f4: AllocStack(0x10)
    //     0x11953f4: sub             SP, SP, #0x10
    // 0x11953f8: SetupParameters(_NoopMouseCursor this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x11953f8: stur            x1, [fp, #-8]
    //     0x11953fc: stur            x2, [fp, #-0x10]
    // 0x1195400: r0 = _NoopMouseCursorSession()
    //     0x1195400: bl              #0x1195420  ; Allocate_NoopMouseCursorSessionStub -> _NoopMouseCursorSession (size=0x14)
    // 0x1195404: ldur            x1, [fp, #-8]
    // 0x1195408: StoreField: r0->field_7 = r1
    //     0x1195408: stur            w1, [x0, #7]
    // 0x119540c: ldur            x1, [fp, #-0x10]
    // 0x1195410: StoreField: r0->field_b = r1
    //     0x1195410: stur            x1, [x0, #0xb]
    // 0x1195414: LeaveFrame
    //     0x1195414: mov             SP, fp
    //     0x1195418: ldp             fp, lr, [SP], #0x10
    // 0x119541c: ret
    //     0x119541c: ret             
  }
}

// class id: 5186, size: 0x8, field offset: 0x8
//   const constructor, 
class _DeferringMouseCursor extends MouseCursor {

  static _ firstNonDeferred(/* No info */) {
    // ** addr: 0x835240, size: 0x190
    // 0x835240: EnterFrame
    //     0x835240: stp             fp, lr, [SP, #-0x10]!
    //     0x835244: mov             fp, SP
    // 0x835248: AllocStack(0x38)
    //     0x835248: sub             SP, SP, #0x38
    // 0x83524c: CheckStackOverflow
    //     0x83524c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x835250: cmp             SP, x16
    //     0x835254: b.ls            #0x8353c0
    // 0x835258: r0 = iterator()
    //     0x835258: bl              #0xb0a03c  ; [dart:_internal] MappedIterable::iterator
    // 0x83525c: mov             x2, x0
    // 0x835260: stur            x2, [fp, #-0x20]
    // 0x835264: LoadField: r3 = r2->field_f
    //     0x835264: ldur            w3, [x2, #0xf]
    // 0x835268: DecompressPointer r3
    //     0x835268: add             x3, x3, HEAP, lsl #32
    // 0x83526c: stur            x3, [fp, #-0x18]
    // 0x835270: LoadField: r4 = r2->field_13
    //     0x835270: ldur            w4, [x2, #0x13]
    // 0x835274: DecompressPointer r4
    //     0x835274: add             x4, x4, HEAP, lsl #32
    // 0x835278: stur            x4, [fp, #-0x10]
    // 0x83527c: LoadField: r5 = r2->field_7
    //     0x83527c: ldur            w5, [x2, #7]
    // 0x835280: DecompressPointer r5
    //     0x835280: add             x5, x5, HEAP, lsl #32
    // 0x835284: stur            x5, [fp, #-8]
    // 0x835288: CheckStackOverflow
    //     0x835288: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x83528c: cmp             SP, x16
    //     0x835290: b.ls            #0x8353c8
    // 0x835294: r0 = LoadClassIdInstr(r3)
    //     0x835294: ldur            x0, [x3, #-1]
    //     0x835298: ubfx            x0, x0, #0xc, #0x14
    // 0x83529c: mov             x1, x3
    // 0x8352a0: r0 = GDT[cid_x0 + 0x1845b]()
    //     0x8352a0: mov             x17, #0x845b
    //     0x8352a4: movk            x17, #1, lsl #16
    //     0x8352a8: add             lr, x0, x17
    //     0x8352ac: ldr             lr, [x21, lr, lsl #3]
    //     0x8352b0: blr             lr
    // 0x8352b4: tbnz            w0, #4, #0x8353a8
    // 0x8352b8: ldur            x2, [fp, #-0x20]
    // 0x8352bc: ldur            x3, [fp, #-0x18]
    // 0x8352c0: r0 = LoadClassIdInstr(r3)
    //     0x8352c0: ldur            x0, [x3, #-1]
    //     0x8352c4: ubfx            x0, x0, #0xc, #0x14
    // 0x8352c8: mov             x1, x3
    // 0x8352cc: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0x8352cc: mov             x17, #0x7d4c
    //     0x8352d0: movk            x17, #1, lsl #16
    //     0x8352d4: add             lr, x0, x17
    //     0x8352d8: ldr             lr, [x21, lr, lsl #3]
    //     0x8352dc: blr             lr
    // 0x8352e0: ldur            x16, [fp, #-0x10]
    // 0x8352e4: stp             x0, x16, [SP]
    // 0x8352e8: ldur            x0, [fp, #-0x10]
    // 0x8352ec: ClosureCall
    //     0x8352ec: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x8352f0: ldur            x2, [x0, #0x1f]
    //     0x8352f4: blr             x2
    // 0x8352f8: mov             x4, x0
    // 0x8352fc: ldur            x3, [fp, #-0x20]
    // 0x835300: stur            x4, [fp, #-0x28]
    // 0x835304: StoreField: r3->field_b = r0
    //     0x835304: stur            w0, [x3, #0xb]
    //     0x835308: tbz             w0, #0, #0x835324
    //     0x83530c: ldurb           w16, [x3, #-1]
    //     0x835310: ldurb           w17, [x0, #-1]
    //     0x835314: and             x16, x17, x16, lsr #2
    //     0x835318: tst             x16, HEAP, lsr #32
    //     0x83531c: b.eq            #0x835324
    //     0x835320: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x835324: cmp             w4, NULL
    // 0x835328: b.ne            #0x835358
    // 0x83532c: mov             x0, x4
    // 0x835330: ldur            x2, [fp, #-8]
    // 0x835334: r1 = Null
    //     0x835334: mov             x1, NULL
    // 0x835338: cmp             w2, NULL
    // 0x83533c: b.eq            #0x835358
    // 0x835340: LoadField: r4 = r2->field_1b
    //     0x835340: ldur            w4, [x2, #0x1b]
    // 0x835344: DecompressPointer r4
    //     0x835344: add             x4, x4, HEAP, lsl #32
    // 0x835348: r8 = X1
    //     0x835348: ldr             x8, [PP, #0xf00]  ; [pp+0xf00] TypeParameter: X1
    // 0x83534c: LoadField: r9 = r4->field_7
    //     0x83534c: ldur            x9, [x4, #7]
    // 0x835350: r3 = Null
    //     0x835350: ldr             x3, [PP, #0x21f8]  ; [pp+0x21f8] Null
    // 0x835354: blr             x9
    // 0x835358: ldur            x1, [fp, #-0x28]
    // 0x83535c: r0 = 60
    //     0x83535c: mov             x0, #0x3c
    // 0x835360: branchIfSmi(r1, 0x83536c)
    //     0x835360: tbz             w1, #0, #0x83536c
    // 0x835364: r0 = LoadClassIdInstr(r1)
    //     0x835364: ldur            x0, [x1, #-1]
    //     0x835368: ubfx            x0, x0, #0xc, #0x14
    // 0x83536c: r16 = Instance__DeferringMouseCursor
    //     0x83536c: ldr             x16, [PP, #0x2208]  ; [pp+0x2208] Obj!_DeferringMouseCursor@12b3241
    // 0x835370: stp             x16, x1, [SP]
    // 0x835374: mov             lr, x0
    // 0x835378: ldr             lr, [x21, lr, lsl #3]
    // 0x83537c: blr             lr
    // 0x835380: tbnz            w0, #4, #0x835398
    // 0x835384: ldur            x2, [fp, #-0x20]
    // 0x835388: ldur            x5, [fp, #-8]
    // 0x83538c: ldur            x3, [fp, #-0x18]
    // 0x835390: ldur            x4, [fp, #-0x10]
    // 0x835394: b               #0x835288
    // 0x835398: ldur            x0, [fp, #-0x28]
    // 0x83539c: LeaveFrame
    //     0x83539c: mov             SP, fp
    //     0x8353a0: ldp             fp, lr, [SP], #0x10
    // 0x8353a4: ret
    //     0x8353a4: ret             
    // 0x8353a8: ldur            x1, [fp, #-0x20]
    // 0x8353ac: StoreField: r1->field_b = rNULL
    //     0x8353ac: stur            NULL, [x1, #0xb]
    // 0x8353b0: r0 = Null
    //     0x8353b0: mov             x0, NULL
    // 0x8353b4: LeaveFrame
    //     0x8353b4: mov             SP, fp
    //     0x8353b8: ldp             fp, lr, [SP], #0x10
    // 0x8353bc: ret
    //     0x8353bc: ret             
    // 0x8353c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8353c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8353c4: b               #0x835258
    // 0x8353c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8353c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8353cc: b               #0x835294
  }
}
