// lib: , url: package:flutter/src/services/live_text.dart

// class id: 1049077, size: 0x8
class :: {
}

// class id: 2792, size: 0x8, field offset: 0x8
abstract class LiveText extends Object {

  static _ isLiveTextInputAvailable(/* No info */) async {
    // ** addr: 0x8623cc, size: 0x64
    // 0x8623cc: EnterFrame
    //     0x8623cc: stp             fp, lr, [SP, #-0x10]!
    //     0x8623d0: mov             fp, SP
    // 0x8623d4: AllocStack(0x28)
    //     0x8623d4: sub             SP, SP, #0x28
    // 0x8623d8: SetupParameters()
    //     0x8623d8: stur            NULL, [fp, #-8]
    // 0x8623dc: CheckStackOverflow
    //     0x8623dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8623e0: cmp             SP, x16
    //     0x8623e4: b.ls            #0x862428
    // 0x8623e8: InitAsync() -> Future<bool>
    //     0x8623e8: ldr             x0, [PP, #0x1918]  ; [pp+0x1918] TypeArguments: <bool>
    //     0x8623ec: bl              #0x7f5e44  ; InitAsyncStub
    // 0x8623f0: r16 = <bool>
    //     0x8623f0: ldr             x16, [PP, #0x1918]  ; [pp+0x1918] TypeArguments: <bool>
    // 0x8623f4: r30 = Instance_OptionalMethodChannel
    //     0x8623f4: ldr             lr, [PP, #0x1960]  ; [pp+0x1960] Obj!OptionalMethodChannel@129bec1
    // 0x8623f8: stp             lr, x16, [SP, #8]
    // 0x8623fc: r16 = "LiveText.isLiveTextInputAvailable"
    //     0x8623fc: ldr             x16, [PP, #0x5100]  ; [pp+0x5100] "LiveText.isLiveTextInputAvailable"
    // 0x862400: str             x16, [SP]
    // 0x862404: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x862404: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x862408: r0 = invokeMethod()
    //     0x862408: bl              #0x130ad0c  ; [package:flutter/src/services/platform_channel.dart] OptionalMethodChannel::invokeMethod
    // 0x86240c: mov             x1, x0
    // 0x862410: stur            x1, [fp, #-0x10]
    // 0x862414: r0 = Await()
    //     0x862414: bl              #0x7f5c00  ; AwaitStub
    // 0x862418: cmp             w0, NULL
    // 0x86241c: b.ne            #0x862424
    // 0x862420: r0 = false
    //     0x862420: add             x0, NULL, #0x30  ; false
    // 0x862424: r0 = ReturnAsync()
    //     0x862424: b               #0x82fdf0  ; ReturnAsyncStub
    // 0x862428: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x862428: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x86242c: b               #0x8623e8
  }
  static Future<void> startLiveTextInput() async {
    // ** addr: 0xd930ac, size: 0x60
    // 0xd930ac: EnterFrame
    //     0xd930ac: stp             fp, lr, [SP, #-0x10]!
    //     0xd930b0: mov             fp, SP
    // 0xd930b4: AllocStack(0x28)
    //     0xd930b4: sub             SP, SP, #0x28
    // 0xd930b8: SetupParameters()
    //     0xd930b8: stur            NULL, [fp, #-8]
    // 0xd930bc: CheckStackOverflow
    //     0xd930bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd930c0: cmp             SP, x16
    //     0xd930c4: b.ls            #0xd93104
    // 0xd930c8: InitAsync() -> Future<void?>
    //     0xd930c8: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0xd930cc: bl              #0x7f5e44  ; InitAsyncStub
    // 0xd930d0: r16 = <void?>
    //     0xd930d0: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xd930d4: r30 = Instance_OptionalMethodChannel
    //     0xd930d4: ldr             lr, [PP, #0x43b0]  ; [pp+0x43b0] Obj!OptionalMethodChannel@129bea1
    // 0xd930d8: stp             lr, x16, [SP, #8]
    // 0xd930dc: r16 = "TextInput.startLiveTextInput"
    //     0xd930dc: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a6e8] "TextInput.startLiveTextInput"
    //     0xd930e0: ldr             x16, [x16, #0x6e8]
    // 0xd930e4: str             x16, [SP]
    // 0xd930e8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xd930e8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xd930ec: r0 = invokeMethod()
    //     0xd930ec: bl              #0x130ad0c  ; [package:flutter/src/services/platform_channel.dart] OptionalMethodChannel::invokeMethod
    // 0xd930f0: mov             x1, x0
    // 0xd930f4: stur            x1, [fp, #-0x10]
    // 0xd930f8: r0 = Await()
    //     0xd930f8: bl              #0x7f5c00  ; AwaitStub
    // 0xd930fc: r0 = Null
    //     0xd930fc: mov             x0, NULL
    // 0xd93100: r0 = ReturnAsyncNotFuture()
    //     0xd93100: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xd93104: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd93104: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd93108: b               #0xd930c8
  }
}
