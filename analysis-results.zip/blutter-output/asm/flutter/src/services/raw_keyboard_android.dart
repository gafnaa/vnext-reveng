// lib: , url: package:flutter/src/services/raw_keyboard_android.dart

// class id: 1049087, size: 0x8
class :: {
}

// class id: 5025, size: 0x48, field offset: 0x8
//   const constructor, 
class RawKeyEventDataAndroid extends RawKeyEventData {

  get _ hashCode(/* No info */) {
    // ** addr: 0x113bd20, size: 0x108
    // 0x113bd20: EnterFrame
    //     0x113bd20: stp             fp, lr, [SP, #-0x10]!
    //     0x113bd24: mov             fp, SP
    // 0x113bd28: AllocStack(0x20)
    //     0x113bd28: sub             SP, SP, #0x20
    // 0x113bd2c: CheckStackOverflow
    //     0x113bd2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x113bd30: cmp             SP, x16
    //     0x113bd34: b.ls            #0x113be20
    // 0x113bd38: ldr             x0, [fp, #0x10]
    // 0x113bd3c: LoadField: r2 = r0->field_7
    //     0x113bd3c: ldur            x2, [x0, #7]
    // 0x113bd40: LoadField: r3 = r0->field_f
    //     0x113bd40: ldur            x3, [x0, #0xf]
    // 0x113bd44: ArrayLoad: r4 = r0[0]  ; List_8
    //     0x113bd44: ldur            x4, [x0, #0x17]
    // 0x113bd48: LoadField: r5 = r0->field_1f
    //     0x113bd48: ldur            x5, [x0, #0x1f]
    // 0x113bd4c: LoadField: r6 = r0->field_27
    //     0x113bd4c: ldur            x6, [x0, #0x27]
    // 0x113bd50: LoadField: r7 = r0->field_2f
    //     0x113bd50: ldur            x7, [x0, #0x2f]
    // 0x113bd54: r0 = BoxInt64Instr(r2)
    //     0x113bd54: sbfiz           x0, x2, #1, #0x1f
    //     0x113bd58: cmp             x2, x0, asr #1
    //     0x113bd5c: b.eq            #0x113bd68
    //     0x113bd60: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x113bd64: stur            x2, [x0, #7]
    // 0x113bd68: mov             x2, x0
    // 0x113bd6c: r0 = BoxInt64Instr(r3)
    //     0x113bd6c: sbfiz           x0, x3, #1, #0x1f
    //     0x113bd70: cmp             x3, x0, asr #1
    //     0x113bd74: b.eq            #0x113bd80
    //     0x113bd78: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x113bd7c: stur            x3, [x0, #7]
    // 0x113bd80: mov             x3, x0
    // 0x113bd84: r0 = BoxInt64Instr(r4)
    //     0x113bd84: sbfiz           x0, x4, #1, #0x1f
    //     0x113bd88: cmp             x4, x0, asr #1
    //     0x113bd8c: b.eq            #0x113bd98
    //     0x113bd90: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x113bd94: stur            x4, [x0, #7]
    // 0x113bd98: mov             x4, x0
    // 0x113bd9c: r0 = BoxInt64Instr(r5)
    //     0x113bd9c: sbfiz           x0, x5, #1, #0x1f
    //     0x113bda0: cmp             x5, x0, asr #1
    //     0x113bda4: b.eq            #0x113bdb0
    //     0x113bda8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x113bdac: stur            x5, [x0, #7]
    // 0x113bdb0: mov             x5, x0
    // 0x113bdb4: r0 = BoxInt64Instr(r6)
    //     0x113bdb4: sbfiz           x0, x6, #1, #0x1f
    //     0x113bdb8: cmp             x6, x0, asr #1
    //     0x113bdbc: b.eq            #0x113bdc8
    //     0x113bdc0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x113bdc4: stur            x6, [x0, #7]
    // 0x113bdc8: mov             x6, x0
    // 0x113bdcc: r0 = BoxInt64Instr(r7)
    //     0x113bdcc: sbfiz           x0, x7, #1, #0x1f
    //     0x113bdd0: cmp             x7, x0, asr #1
    //     0x113bdd4: b.eq            #0x113bde0
    //     0x113bdd8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x113bddc: stur            x7, [x0, #7]
    // 0x113bde0: stp             x5, x4, [SP, #0x10]
    // 0x113bde4: stp             x0, x6, [SP]
    // 0x113bde8: mov             x1, x2
    // 0x113bdec: mov             x2, x3
    // 0x113bdf0: r4 = const [0, 0x6, 0x4, 0x6, null]
    //     0x113bdf0: add             x4, PP, #0xd, lsl #12  ; [pp+0xdd28] List(5) [0, 0x6, 0x4, 0x6, Null]
    //     0x113bdf4: ldr             x4, [x4, #0xd28]
    // 0x113bdf8: r0 = hash()
    //     0x113bdf8: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x113bdfc: mov             x2, x0
    // 0x113be00: r0 = BoxInt64Instr(r2)
    //     0x113be00: sbfiz           x0, x2, #1, #0x1f
    //     0x113be04: cmp             x2, x0, asr #1
    //     0x113be08: b.eq            #0x113be14
    //     0x113be0c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x113be10: stur            x2, [x0, #7]
    // 0x113be14: LeaveFrame
    //     0x113be14: mov             SP, fp
    //     0x113be18: ldp             fp, lr, [SP], #0x10
    // 0x113be1c: ret
    //     0x113be1c: ret             
    // 0x113be20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x113be20: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x113be24: b               #0x113bd38
  }
  get _ logicalKey(/* No info */) {
    // ** addr: 0x1142498, size: 0x17c
    // 0x1142498: EnterFrame
    //     0x1142498: stp             fp, lr, [SP, #-0x10]!
    //     0x114249c: mov             fp, SP
    // 0x11424a0: AllocStack(0x20)
    //     0x11424a0: sub             SP, SP, #0x20
    // 0x11424a4: SetupParameters(RawKeyEventDataAndroid this /* r1 => r3, fp-0x18 */)
    //     0x11424a4: mov             x3, x1
    //     0x11424a8: stur            x1, [fp, #-0x18]
    // 0x11424ac: CheckStackOverflow
    //     0x11424ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11424b0: cmp             SP, x16
    //     0x11424b4: b.ls            #0x1142608
    // 0x11424b8: LoadField: r4 = r3->field_1f
    //     0x11424b8: ldur            x4, [x3, #0x1f]
    // 0x11424bc: stur            x4, [fp, #-0x10]
    // 0x11424c0: r0 = BoxInt64Instr(r4)
    //     0x11424c0: sbfiz           x0, x4, #1, #0x1f
    //     0x11424c4: cmp             x4, x0, asr #1
    //     0x11424c8: b.eq            #0x11424d4
    //     0x11424cc: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x11424d0: stur            x4, [x0, #7]
    // 0x11424d4: mov             x2, x0
    // 0x11424d8: r1 = _ConstMap len:19
    //     0x11424d8: add             x1, PP, #0xd, lsl #12  ; [pp+0xdd90] Map<int, LogicalKeyboardKey>(19)
    //     0x11424dc: ldr             x1, [x1, #0xd90]
    // 0x11424e0: stur            x0, [fp, #-8]
    // 0x11424e4: r0 = []()
    //     0x11424e4: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x11424e8: cmp             w0, NULL
    // 0x11424ec: b.eq            #0x11424fc
    // 0x11424f0: LeaveFrame
    //     0x11424f0: mov             SP, fp
    //     0x11424f4: ldp             fp, lr, [SP], #0x10
    // 0x11424f8: ret
    //     0x11424f8: ret             
    // 0x11424fc: ldur            x1, [fp, #-0x18]
    // 0x1142500: r0 = keyLabel()
    //     0x1142500: bl              #0x1142614  ; [package:flutter/src/services/raw_keyboard_android.dart] RawKeyEventDataAndroid::keyLabel
    // 0x1142504: LoadField: r1 = r0->field_7
    //     0x1142504: ldur            w1, [x0, #7]
    // 0x1142508: cbz             w1, #0x11425b8
    // 0x114250c: ldur            x1, [fp, #-0x18]
    // 0x1142510: r0 = keyLabel()
    //     0x1142510: bl              #0x1142614  ; [package:flutter/src/services/raw_keyboard_android.dart] RawKeyEventDataAndroid::keyLabel
    // 0x1142514: mov             x2, x0
    // 0x1142518: LoadField: r0 = r2->field_7
    //     0x1142518: ldur            w0, [x2, #7]
    // 0x114251c: r1 = LoadInt32Instr(r0)
    //     0x114251c: sbfx            x1, x0, #1, #0x1f
    // 0x1142520: cmp             x1, #1
    // 0x1142524: b.ne            #0x1142574
    // 0x1142528: mov             x0, x1
    // 0x114252c: r1 = 0
    //     0x114252c: mov             x1, #0
    // 0x1142530: cmp             x1, x0
    // 0x1142534: b.hs            #0x1142610
    // 0x1142538: r0 = LoadClassIdInstr(r2)
    //     0x1142538: ldur            x0, [x2, #-1]
    //     0x114253c: ubfx            x0, x0, #0xc, #0x14
    // 0x1142540: lsl             x0, x0, #1
    // 0x1142544: cmp             w0, #0xbc
    // 0x1142548: b.ne            #0x1142554
    // 0x114254c: ArrayLoad: r0 = r2[-8]  ; TypedUnsigned_1
    //     0x114254c: ldrb            w0, [x2, #0xf]
    // 0x1142550: b               #0x1142558
    // 0x1142554: ldurh           w0, [x2, #0xf]
    // 0x1142558: cmp             x0, #0x1f
    // 0x114255c: b.gt            #0x1142564
    // 0x1142560: tbz             x0, #0x3f, #0x11425b8
    // 0x1142564: cmp             x0, #0x7f
    // 0x1142568: b.lt            #0x1142574
    // 0x114256c: cmp             x0, #0x9f
    // 0x1142570: b.le            #0x11425b8
    // 0x1142574: ldur            x0, [fp, #-0x18]
    // 0x1142578: ArrayLoad: r1 = r0[0]  ; List_8
    //     0x1142578: ldur            x1, [x0, #0x17]
    // 0x114257c: ubfx            x1, x1, #0, #0x20
    // 0x1142580: and             w0, w1, #0x7fffffff
    // 0x1142584: stur            x0, [fp, #-0x20]
    // 0x1142588: mov             x1, x0
    // 0x114258c: ubfx            x1, x1, #0, #0x20
    // 0x1142590: r0 = findKeyByKeyId()
    //     0x1142590: bl              #0x84a464  ; [package:flutter/src/services/keyboard_key.g.dart] LogicalKeyboardKey::findKeyByKeyId
    // 0x1142594: cmp             w0, NULL
    // 0x1142598: b.ne            #0x11425ac
    // 0x114259c: r0 = LogicalKeyboardKey()
    //     0x114259c: bl              #0x849274  ; AllocateLogicalKeyboardKeyStub -> LogicalKeyboardKey (size=0x10)
    // 0x11425a0: ldur            x1, [fp, #-0x20]
    // 0x11425a4: ubfx            x1, x1, #0, #0x20
    // 0x11425a8: StoreField: r0->field_7 = r1
    //     0x11425a8: stur            x1, [x0, #7]
    // 0x11425ac: LeaveFrame
    //     0x11425ac: mov             SP, fp
    //     0x11425b0: ldp             fp, lr, [SP], #0x10
    // 0x11425b4: ret
    //     0x11425b4: ret             
    // 0x11425b8: ldur            x2, [fp, #-8]
    // 0x11425bc: r1 = _ConstMap len:260
    //     0x11425bc: add             x1, PP, #0xd, lsl #12  ; [pp+0xdd98] Map<int, LogicalKeyboardKey>(260)
    //     0x11425c0: ldr             x1, [x1, #0xd98]
    // 0x11425c4: r0 = []()
    //     0x11425c4: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x11425c8: cmp             w0, NULL
    // 0x11425cc: b.eq            #0x11425dc
    // 0x11425d0: LeaveFrame
    //     0x11425d0: mov             SP, fp
    //     0x11425d4: ldp             fp, lr, [SP], #0x10
    // 0x11425d8: ret
    //     0x11425d8: ret             
    // 0x11425dc: ldur            x0, [fp, #-0x10]
    // 0x11425e0: r16 = 73014444032
    //     0x11425e0: add             x16, PP, #0xd, lsl #12  ; [pp+0xdda0] IMM: 0x1100000000
    //     0x11425e4: ldr             x16, [x16, #0xda0]
    // 0x11425e8: orr             x1, x0, x16
    // 0x11425ec: stur            x1, [fp, #-0x20]
    // 0x11425f0: r0 = LogicalKeyboardKey()
    //     0x11425f0: bl              #0x849274  ; AllocateLogicalKeyboardKeyStub -> LogicalKeyboardKey (size=0x10)
    // 0x11425f4: ldur            x1, [fp, #-0x20]
    // 0x11425f8: StoreField: r0->field_7 = r1
    //     0x11425f8: stur            x1, [x0, #7]
    // 0x11425fc: LeaveFrame
    //     0x11425fc: mov             SP, fp
    //     0x1142600: ldp             fp, lr, [SP], #0x10
    // 0x1142604: ret
    //     0x1142604: ret             
    // 0x1142608: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1142608: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x114260c: b               #0x11424b8
    // 0x1142610: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x1142610: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  get _ keyLabel(/* No info */) {
    // ** addr: 0x1142614, size: 0x50
    // 0x1142614: EnterFrame
    //     0x1142614: stp             fp, lr, [SP, #-0x10]!
    //     0x1142618: mov             fp, SP
    // 0x114261c: CheckStackOverflow
    //     0x114261c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1142620: cmp             SP, x16
    //     0x1142624: b.ls            #0x114265c
    // 0x1142628: ArrayLoad: r0 = r1[0]  ; List_8
    //     0x1142628: ldur            x0, [x1, #0x17]
    // 0x114262c: cbnz            x0, #0x1142638
    // 0x1142630: r0 = ""
    //     0x1142630: ldr             x0, [PP, #0x900]  ; [pp+0x900] ""
    // 0x1142634: b               #0x1142650
    // 0x1142638: ubfx            x0, x0, #0, #0x20
    // 0x114263c: and             w1, w0, #0x7fffffff
    // 0x1142640: ubfx            x1, x1, #0, #0x20
    // 0x1142644: mov             x2, x1
    // 0x1142648: r1 = Null
    //     0x1142648: mov             x1, NULL
    // 0x114264c: r0 = String.fromCharCode()
    //     0x114264c: bl              #0x7e6340  ; [dart:core] String::String.fromCharCode
    // 0x1142650: LeaveFrame
    //     0x1142650: mov             SP, fp
    //     0x1142654: ldp             fp, lr, [SP], #0x10
    // 0x1142658: ret
    //     0x1142658: ret             
    // 0x114265c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x114265c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1142660: b               #0x1142628
  }
  _ getModifierSide(/* No info */) {
    // ** addr: 0x1143348, size: 0x1a4
    // 0x1143348: LoadField: r3 = r2->field_7
    //     0x1143348: ldur            x3, [x2, #7]
    // 0x114334c: cmp             x3, #4
    // 0x1143350: b.gt            #0x11434e4
    // 0x1143354: cmp             x3, #2
    // 0x1143358: b.gt            #0x1143480
    // 0x114335c: cmp             x3, #1
    // 0x1143360: b.gt            #0x1143424
    // 0x1143364: cmp             x3, #0
    // 0x1143368: b.gt            #0x11433c8
    // 0x114336c: LoadField: r2 = r1->field_2f
    //     0x114336c: ldur            x2, [x1, #0x2f]
    // 0x1143370: mov             x4, x2
    // 0x1143374: ubfx            x4, x4, #0, #0x20
    // 0x1143378: and             w5, w4, #0x6000
    // 0x114337c: cmp             w5, #2, lsl #12
    // 0x1143380: b.ne            #0x1143390
    // 0x1143384: r0 = Instance_KeyboardSide
    //     0x1143384: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc50] Obj!KeyboardSide@12c3d01
    //     0x1143388: ldr             x0, [x0, #0xc50]
    // 0x114338c: b               #0x11433c4
    // 0x1143390: cmp             w5, #4, lsl #12
    // 0x1143394: b.ne            #0x11433a4
    // 0x1143398: r0 = Instance_KeyboardSide
    //     0x1143398: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc58] Obj!KeyboardSide@12c3ce1
    //     0x114339c: ldr             x0, [x0, #0xc58]
    // 0x11433a0: b               #0x11433c4
    // 0x11433a4: cmp             w5, #6, lsl #12
    // 0x11433a8: b.ne            #0x11433b4
    // 0x11433ac: r0 = Instance_KeyboardSide
    //     0x11433ac: ldr             x0, [PP, #0x3b60]  ; [pp+0x3b60] Obj!KeyboardSide@12c3cc1
    // 0x11433b0: b               #0x11433c4
    // 0x11433b4: tbz             w2, #0xc, #0x11433c0
    // 0x11433b8: r0 = Instance_KeyboardSide
    //     0x11433b8: ldr             x0, [PP, #0x3b60]  ; [pp+0x3b60] Obj!KeyboardSide@12c3cc1
    // 0x11433bc: b               #0x11433c4
    // 0x11433c0: r0 = Null
    //     0x11433c0: mov             x0, NULL
    // 0x11433c4: ret
    //     0x11433c4: ret             
    // 0x11433c8: LoadField: r2 = r1->field_2f
    //     0x11433c8: ldur            x2, [x1, #0x2f]
    // 0x11433cc: mov             x4, x2
    // 0x11433d0: ubfx            x4, x4, #0, #0x20
    // 0x11433d4: and             w5, w4, #0xc0
    // 0x11433d8: cmp             w5, #0x40
    // 0x11433dc: b.ne            #0x11433ec
    // 0x11433e0: r0 = Instance_KeyboardSide
    //     0x11433e0: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc50] Obj!KeyboardSide@12c3d01
    //     0x11433e4: ldr             x0, [x0, #0xc50]
    // 0x11433e8: b               #0x1143420
    // 0x11433ec: cmp             w5, #0x80
    // 0x11433f0: b.ne            #0x1143400
    // 0x11433f4: r0 = Instance_KeyboardSide
    //     0x11433f4: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc58] Obj!KeyboardSide@12c3ce1
    //     0x11433f8: ldr             x0, [x0, #0xc58]
    // 0x11433fc: b               #0x1143420
    // 0x1143400: cmp             w5, #0xc0
    // 0x1143404: b.ne            #0x1143410
    // 0x1143408: r0 = Instance_KeyboardSide
    //     0x1143408: ldr             x0, [PP, #0x3b60]  ; [pp+0x3b60] Obj!KeyboardSide@12c3cc1
    // 0x114340c: b               #0x1143420
    // 0x1143410: branchIfSmi(r2, 0x114341c)
    //     0x1143410: tbz             w2, #0, #0x114341c
    // 0x1143414: r0 = Instance_KeyboardSide
    //     0x1143414: ldr             x0, [PP, #0x3b60]  ; [pp+0x3b60] Obj!KeyboardSide@12c3cc1
    // 0x1143418: b               #0x1143420
    // 0x114341c: r0 = Null
    //     0x114341c: mov             x0, NULL
    // 0x1143420: ret
    //     0x1143420: ret             
    // 0x1143424: LoadField: r2 = r1->field_2f
    //     0x1143424: ldur            x2, [x1, #0x2f]
    // 0x1143428: mov             x4, x2
    // 0x114342c: ubfx            x4, x4, #0, #0x20
    // 0x1143430: and             w5, w4, #0x30
    // 0x1143434: cmp             w5, #0x10
    // 0x1143438: b.ne            #0x1143448
    // 0x114343c: r0 = Instance_KeyboardSide
    //     0x114343c: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc50] Obj!KeyboardSide@12c3d01
    //     0x1143440: ldr             x0, [x0, #0xc50]
    // 0x1143444: b               #0x114347c
    // 0x1143448: cmp             w5, #0x20
    // 0x114344c: b.ne            #0x114345c
    // 0x1143450: r0 = Instance_KeyboardSide
    //     0x1143450: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc58] Obj!KeyboardSide@12c3ce1
    //     0x1143454: ldr             x0, [x0, #0xc58]
    // 0x1143458: b               #0x114347c
    // 0x114345c: cmp             w5, #0x30
    // 0x1143460: b.ne            #0x114346c
    // 0x1143464: r0 = Instance_KeyboardSide
    //     0x1143464: ldr             x0, [PP, #0x3b60]  ; [pp+0x3b60] Obj!KeyboardSide@12c3cc1
    // 0x1143468: b               #0x114347c
    // 0x114346c: tbz             w2, #1, #0x1143478
    // 0x1143470: r0 = Instance_KeyboardSide
    //     0x1143470: ldr             x0, [PP, #0x3b60]  ; [pp+0x3b60] Obj!KeyboardSide@12c3cc1
    // 0x1143474: b               #0x114347c
    // 0x1143478: r0 = Null
    //     0x1143478: mov             x0, NULL
    // 0x114347c: ret
    //     0x114347c: ret             
    // 0x1143480: cmp             x3, #3
    // 0x1143484: b.gt            #0x11434e4
    // 0x1143488: LoadField: r2 = r1->field_2f
    //     0x1143488: ldur            x2, [x1, #0x2f]
    // 0x114348c: mov             x1, x2
    // 0x1143490: ubfx            x1, x1, #0, #0x20
    // 0x1143494: and             w3, w1, #0x60000
    // 0x1143498: cmp             w3, #0x20, lsl #12
    // 0x114349c: b.ne            #0x11434ac
    // 0x11434a0: r0 = Instance_KeyboardSide
    //     0x11434a0: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc50] Obj!KeyboardSide@12c3d01
    //     0x11434a4: ldr             x0, [x0, #0xc50]
    // 0x11434a8: b               #0x11434e0
    // 0x11434ac: cmp             w3, #0x40, lsl #12
    // 0x11434b0: b.ne            #0x11434c0
    // 0x11434b4: r0 = Instance_KeyboardSide
    //     0x11434b4: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc58] Obj!KeyboardSide@12c3ce1
    //     0x11434b8: ldr             x0, [x0, #0xc58]
    // 0x11434bc: b               #0x11434e0
    // 0x11434c0: cmp             w3, #0x60, lsl #12
    // 0x11434c4: b.ne            #0x11434d0
    // 0x11434c8: r0 = Instance_KeyboardSide
    //     0x11434c8: ldr             x0, [PP, #0x3b60]  ; [pp+0x3b60] Obj!KeyboardSide@12c3cc1
    // 0x11434cc: b               #0x11434e0
    // 0x11434d0: tbz             w2, #0x10, #0x11434dc
    // 0x11434d4: r0 = Instance_KeyboardSide
    //     0x11434d4: ldr             x0, [PP, #0x3b60]  ; [pp+0x3b60] Obj!KeyboardSide@12c3cc1
    // 0x11434d8: b               #0x11434e0
    // 0x11434dc: r0 = Null
    //     0x11434dc: mov             x0, NULL
    // 0x11434e0: ret
    //     0x11434e0: ret             
    // 0x11434e4: r0 = Instance_KeyboardSide
    //     0x11434e4: ldr             x0, [PP, #0x3b60]  ; [pp+0x3b60] Obj!KeyboardSide@12c3cc1
    // 0x11434e8: ret
    //     0x11434e8: ret             
  }
  get _ physicalKey(/* No info */) {
    // ** addr: 0x11473a8, size: 0x1f8
    // 0x11473a8: EnterFrame
    //     0x11473a8: stp             fp, lr, [SP, #-0x10]!
    //     0x11473ac: mov             fp, SP
    // 0x11473b0: AllocStack(0x30)
    //     0x11473b0: sub             SP, SP, #0x30
    // 0x11473b4: SetupParameters(RawKeyEventDataAndroid this /* r1 => r3, fp-0x18 */)
    //     0x11473b4: mov             x3, x1
    //     0x11473b8: stur            x1, [fp, #-0x18]
    // 0x11473bc: CheckStackOverflow
    //     0x11473bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11473c0: cmp             SP, x16
    //     0x11473c4: b.ls            #0x1147594
    // 0x11473c8: LoadField: r4 = r3->field_27
    //     0x11473c8: ldur            x4, [x3, #0x27]
    // 0x11473cc: stur            x4, [fp, #-0x10]
    // 0x11473d0: r0 = BoxInt64Instr(r4)
    //     0x11473d0: sbfiz           x0, x4, #1, #0x1f
    //     0x11473d4: cmp             x4, x0, asr #1
    //     0x11473d8: b.eq            #0x11473e4
    //     0x11473dc: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x11473e0: stur            x4, [x0, #7]
    // 0x11473e4: mov             x2, x0
    // 0x11473e8: r1 = _ConstMap len:232
    //     0x11473e8: add             x1, PP, #0xd, lsl #12  ; [pp+0xdda8] Map<int, PhysicalKeyboardKey>(232)
    //     0x11473ec: ldr             x1, [x1, #0xda8]
    // 0x11473f0: stur            x0, [fp, #-8]
    // 0x11473f4: r0 = containsKey()
    //     0x11473f4: bl              #0x12d59fc  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::containsKey
    // 0x11473f8: tbnz            w0, #4, #0x1147420
    // 0x11473fc: ldur            x2, [fp, #-8]
    // 0x1147400: r1 = _ConstMap len:232
    //     0x1147400: add             x1, PP, #0xd, lsl #12  ; [pp+0xdda8] Map<int, PhysicalKeyboardKey>(232)
    //     0x1147404: ldr             x1, [x1, #0xda8]
    // 0x1147408: r0 = []()
    //     0x1147408: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x114740c: cmp             w0, NULL
    // 0x1147410: b.eq            #0x114759c
    // 0x1147414: LeaveFrame
    //     0x1147414: mov             SP, fp
    //     0x1147418: ldp             fp, lr, [SP], #0x10
    // 0x114741c: ret
    //     0x114741c: ret             
    // 0x1147420: ldur            x0, [fp, #-0x18]
    // 0x1147424: LoadField: r1 = r0->field_37
    //     0x1147424: ldur            x1, [x0, #0x37]
    // 0x1147428: ubfx            x1, x1, #0, #0x20
    // 0x114742c: r16 = 16777232
    //     0x114742c: mov             x16, #0x10
    //     0x1147430: movk            x16, #0x100, lsl #16
    // 0x1147434: and             w2, w1, w16
    // 0x1147438: r17 = 16777232
    //     0x1147438: mov             x17, #0x10
    //     0x114743c: movk            x17, #0x100, lsl #16
    // 0x1147440: cmp             w2, w17
    // 0x1147444: b.ne            #0x1147568
    // 0x1147448: LoadField: r2 = r0->field_1f
    //     0x1147448: ldur            x2, [x0, #0x1f]
    // 0x114744c: r0 = BoxInt64Instr(r2)
    //     0x114744c: sbfiz           x0, x2, #1, #0x1f
    //     0x1147450: cmp             x2, x0, asr #1
    //     0x1147454: b.eq            #0x1147460
    //     0x1147458: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x114745c: stur            x2, [x0, #7]
    // 0x1147460: mov             x2, x0
    // 0x1147464: r1 = _ConstMap len:260
    //     0x1147464: add             x1, PP, #0xd, lsl #12  ; [pp+0xdd98] Map<int, LogicalKeyboardKey>(260)
    //     0x1147468: ldr             x1, [x1, #0xd98]
    // 0x114746c: r0 = []()
    //     0x114746c: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x1147470: mov             x1, x0
    // 0x1147474: stur            x1, [fp, #-8]
    // 0x1147478: r0 = LoadClassIdInstr(r1)
    //     0x1147478: ldur            x0, [x1, #-1]
    //     0x114747c: ubfx            x0, x0, #0xc, #0x14
    // 0x1147480: r16 = Instance_LogicalKeyboardKey
    //     0x1147480: add             x16, PP, #0xd, lsl #12  ; [pp+0xddb0] Obj!LogicalKeyboardKey@12acd91
    //     0x1147484: ldr             x16, [x16, #0xdb0]
    // 0x1147488: stp             x16, x1, [SP]
    // 0x114748c: mov             lr, x0
    // 0x1147490: ldr             lr, [x21, lr, lsl #3]
    // 0x1147494: blr             lr
    // 0x1147498: tbnz            w0, #4, #0x11474b0
    // 0x114749c: r0 = Instance_PhysicalKeyboardKey
    //     0x114749c: add             x0, PP, #0xd, lsl #12  ; [pp+0xddb8] Obj!PhysicalKeyboardKey@12aaf81
    //     0x11474a0: ldr             x0, [x0, #0xdb8]
    // 0x11474a4: LeaveFrame
    //     0x11474a4: mov             SP, fp
    //     0x11474a8: ldp             fp, lr, [SP], #0x10
    // 0x11474ac: ret
    //     0x11474ac: ret             
    // 0x11474b0: ldur            x1, [fp, #-8]
    // 0x11474b4: r0 = LoadClassIdInstr(r1)
    //     0x11474b4: ldur            x0, [x1, #-1]
    //     0x11474b8: ubfx            x0, x0, #0xc, #0x14
    // 0x11474bc: r16 = Instance_LogicalKeyboardKey
    //     0x11474bc: add             x16, PP, #0xd, lsl #12  ; [pp+0xddc0] Obj!LogicalKeyboardKey@12acdc1
    //     0x11474c0: ldr             x16, [x16, #0xdc0]
    // 0x11474c4: stp             x16, x1, [SP]
    // 0x11474c8: mov             lr, x0
    // 0x11474cc: ldr             lr, [x21, lr, lsl #3]
    // 0x11474d0: blr             lr
    // 0x11474d4: tbnz            w0, #4, #0x11474ec
    // 0x11474d8: r0 = Instance_PhysicalKeyboardKey
    //     0x11474d8: add             x0, PP, #0xd, lsl #12  ; [pp+0xddc8] Obj!PhysicalKeyboardKey@12aaf91
    //     0x11474dc: ldr             x0, [x0, #0xdc8]
    // 0x11474e0: LeaveFrame
    //     0x11474e0: mov             SP, fp
    //     0x11474e4: ldp             fp, lr, [SP], #0x10
    // 0x11474e8: ret
    //     0x11474e8: ret             
    // 0x11474ec: ldur            x1, [fp, #-8]
    // 0x11474f0: r0 = LoadClassIdInstr(r1)
    //     0x11474f0: ldur            x0, [x1, #-1]
    //     0x11474f4: ubfx            x0, x0, #0xc, #0x14
    // 0x11474f8: r16 = Instance_LogicalKeyboardKey
    //     0x11474f8: add             x16, PP, #0xd, lsl #12  ; [pp+0xddd0] Obj!LogicalKeyboardKey@12acdb1
    //     0x11474fc: ldr             x16, [x16, #0xdd0]
    // 0x1147500: stp             x16, x1, [SP]
    // 0x1147504: mov             lr, x0
    // 0x1147508: ldr             lr, [x21, lr, lsl #3]
    // 0x114750c: blr             lr
    // 0x1147510: tbnz            w0, #4, #0x1147528
    // 0x1147514: r0 = Instance_PhysicalKeyboardKey
    //     0x1147514: add             x0, PP, #0xd, lsl #12  ; [pp+0xddd8] Obj!PhysicalKeyboardKey@12aafa1
    //     0x1147518: ldr             x0, [x0, #0xdd8]
    // 0x114751c: LeaveFrame
    //     0x114751c: mov             SP, fp
    //     0x1147520: ldp             fp, lr, [SP], #0x10
    // 0x1147524: ret
    //     0x1147524: ret             
    // 0x1147528: ldur            x0, [fp, #-8]
    // 0x114752c: r1 = LoadClassIdInstr(r0)
    //     0x114752c: ldur            x1, [x0, #-1]
    //     0x1147530: ubfx            x1, x1, #0xc, #0x14
    // 0x1147534: r16 = Instance_LogicalKeyboardKey
    //     0x1147534: add             x16, PP, #0xd, lsl #12  ; [pp+0xdde0] Obj!LogicalKeyboardKey@12acda1
    //     0x1147538: ldr             x16, [x16, #0xde0]
    // 0x114753c: stp             x16, x0, [SP]
    // 0x1147540: mov             x0, x1
    // 0x1147544: mov             lr, x0
    // 0x1147548: ldr             lr, [x21, lr, lsl #3]
    // 0x114754c: blr             lr
    // 0x1147550: tbnz            w0, #4, #0x1147568
    // 0x1147554: r0 = Instance_PhysicalKeyboardKey
    //     0x1147554: add             x0, PP, #0xd, lsl #12  ; [pp+0xdde8] Obj!PhysicalKeyboardKey@12aafb1
    //     0x1147558: ldr             x0, [x0, #0xde8]
    // 0x114755c: LeaveFrame
    //     0x114755c: mov             SP, fp
    //     0x1147560: ldp             fp, lr, [SP], #0x10
    // 0x1147564: ret
    //     0x1147564: ret             
    // 0x1147568: ldur            x0, [fp, #-0x10]
    // 0x114756c: r17 = 73014444032
    //     0x114756c: add             x17, PP, #0xd, lsl #12  ; [pp+0xdda0] IMM: 0x1100000000
    //     0x1147570: ldr             x17, [x17, #0xda0]
    // 0x1147574: add             x1, x0, x17
    // 0x1147578: stur            x1, [fp, #-0x20]
    // 0x114757c: r0 = PhysicalKeyboardKey()
    //     0x114757c: bl              #0x8492a4  ; AllocatePhysicalKeyboardKeyStub -> PhysicalKeyboardKey (size=0x10)
    // 0x1147580: ldur            x1, [fp, #-0x20]
    // 0x1147584: StoreField: r0->field_7 = r1
    //     0x1147584: stur            x1, [x0, #7]
    // 0x1147588: LeaveFrame
    //     0x1147588: mov             SP, fp
    //     0x114758c: ldp             fp, lr, [SP], #0x10
    // 0x1147590: ret
    //     0x1147590: ret             
    // 0x1147594: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1147594: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1147598: b               #0x11473c8
    // 0x114759c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x114759c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ isModifierPressed(/* No info */) {
    // ** addr: 0x116ebd8, size: 0x168
    // 0x116ebd8: LoadField: r3 = r2->field_7
    //     0x116ebd8: ldur            x3, [x2, #7]
    // 0x116ebdc: cmp             x3, #4
    // 0x116ebe0: b.gt            #0x116ec98
    // 0x116ebe4: cmp             x3, #2
    // 0x116ebe8: b.gt            #0x116ec50
    // 0x116ebec: cmp             x3, #1
    // 0x116ebf0: b.gt            #0x116ec34
    // 0x116ebf4: cmp             x3, #0
    // 0x116ebf8: b.gt            #0x116ec18
    // 0x116ebfc: LoadField: r2 = r1->field_2f
    //     0x116ebfc: ldur            x2, [x1, #0x2f]
    // 0x116ec00: tbnz            w2, #0xc, #0x116ec0c
    // 0x116ec04: r2 = false
    //     0x116ec04: add             x2, NULL, #0x30  ; false
    // 0x116ec08: b               #0x116ec10
    // 0x116ec0c: r2 = true
    //     0x116ec0c: add             x2, NULL, #0x20  ; true
    // 0x116ec10: mov             x0, x2
    // 0x116ec14: b               #0x116ed3c
    // 0x116ec18: LoadField: r2 = r1->field_2f
    //     0x116ec18: ldur            x2, [x1, #0x2f]
    // 0x116ec1c: tbnz            w2, #0, #0x116ec28
    // 0x116ec20: r2 = false
    //     0x116ec20: add             x2, NULL, #0x30  ; false
    // 0x116ec24: b               #0x116ec2c
    // 0x116ec28: r2 = true
    //     0x116ec28: add             x2, NULL, #0x20  ; true
    // 0x116ec2c: mov             x0, x2
    // 0x116ec30: b               #0x116ed3c
    // 0x116ec34: LoadField: r2 = r1->field_2f
    //     0x116ec34: ldur            x2, [x1, #0x2f]
    // 0x116ec38: tbnz            w2, #1, #0x116ec44
    // 0x116ec3c: r2 = false
    //     0x116ec3c: add             x2, NULL, #0x30  ; false
    // 0x116ec40: b               #0x116ec48
    // 0x116ec44: r2 = true
    //     0x116ec44: add             x2, NULL, #0x20  ; true
    // 0x116ec48: mov             x0, x2
    // 0x116ec4c: b               #0x116ed3c
    // 0x116ec50: cmp             x3, #3
    // 0x116ec54: b.gt            #0x116ec74
    // 0x116ec58: LoadField: r2 = r1->field_2f
    //     0x116ec58: ldur            x2, [x1, #0x2f]
    // 0x116ec5c: tbnz            w2, #0x10, #0x116ec68
    // 0x116ec60: r2 = false
    //     0x116ec60: add             x2, NULL, #0x30  ; false
    // 0x116ec64: b               #0x116ec6c
    // 0x116ec68: r2 = true
    //     0x116ec68: add             x2, NULL, #0x20  ; true
    // 0x116ec6c: mov             x0, x2
    // 0x116ec70: b               #0x116ed3c
    // 0x116ec74: LoadField: r2 = r1->field_2f
    //     0x116ec74: ldur            x2, [x1, #0x2f]
    // 0x116ec78: ubfx            x2, x2, #0, #0x20
    // 0x116ec7c: and             w4, w2, #0x100000
    // 0x116ec80: cbnz            w4, #0x116ec8c
    // 0x116ec84: r2 = false
    //     0x116ec84: add             x2, NULL, #0x30  ; false
    // 0x116ec88: b               #0x116ec90
    // 0x116ec8c: r2 = true
    //     0x116ec8c: add             x2, NULL, #0x20  ; true
    // 0x116ec90: mov             x0, x2
    // 0x116ec94: b               #0x116ed3c
    // 0x116ec98: cmp             x3, #6
    // 0x116ec9c: b.gt            #0x116ecf0
    // 0x116eca0: cmp             x3, #5
    // 0x116eca4: b.gt            #0x116eccc
    // 0x116eca8: LoadField: r2 = r1->field_2f
    //     0x116eca8: ldur            x2, [x1, #0x2f]
    // 0x116ecac: ubfx            x2, x2, #0, #0x20
    // 0x116ecb0: and             w4, w2, #0x200000
    // 0x116ecb4: cbnz            w4, #0x116ecc0
    // 0x116ecb8: r2 = false
    //     0x116ecb8: add             x2, NULL, #0x30  ; false
    // 0x116ecbc: b               #0x116ecc4
    // 0x116ecc0: r2 = true
    //     0x116ecc0: add             x2, NULL, #0x20  ; true
    // 0x116ecc4: mov             x0, x2
    // 0x116ecc8: b               #0x116ed3c
    // 0x116eccc: LoadField: r2 = r1->field_2f
    //     0x116eccc: ldur            x2, [x1, #0x2f]
    // 0x116ecd0: ubfx            x2, x2, #0, #0x20
    // 0x116ecd4: and             w4, w2, #0x400000
    // 0x116ecd8: cbnz            w4, #0x116ece4
    // 0x116ecdc: r2 = false
    //     0x116ecdc: add             x2, NULL, #0x30  ; false
    // 0x116ece0: b               #0x116ece8
    // 0x116ece4: r2 = true
    //     0x116ece4: add             x2, NULL, #0x20  ; true
    // 0x116ece8: mov             x0, x2
    // 0x116ecec: b               #0x116ed3c
    // 0x116ecf0: cmp             x3, #7
    // 0x116ecf4: b.gt            #0x116ed1c
    // 0x116ecf8: LoadField: r2 = r1->field_2f
    //     0x116ecf8: ldur            x2, [x1, #0x2f]
    // 0x116ecfc: ubfx            x2, x2, #0, #0x20
    // 0x116ed00: and             w3, w2, #8
    // 0x116ed04: cbnz            w3, #0x116ed10
    // 0x116ed08: r2 = false
    //     0x116ed08: add             x2, NULL, #0x30  ; false
    // 0x116ed0c: b               #0x116ed14
    // 0x116ed10: r2 = true
    //     0x116ed10: add             x2, NULL, #0x20  ; true
    // 0x116ed14: mov             x0, x2
    // 0x116ed18: b               #0x116ed3c
    // 0x116ed1c: LoadField: r2 = r1->field_2f
    //     0x116ed1c: ldur            x2, [x1, #0x2f]
    // 0x116ed20: ubfx            x2, x2, #0, #0x20
    // 0x116ed24: and             w1, w2, #4
    // 0x116ed28: cbnz            w1, #0x116ed34
    // 0x116ed2c: r2 = false
    //     0x116ed2c: add             x2, NULL, #0x30  ; false
    // 0x116ed30: b               #0x116ed38
    // 0x116ed34: r2 = true
    //     0x116ed34: add             x2, NULL, #0x20  ; true
    // 0x116ed38: mov             x0, x2
    // 0x116ed3c: ret
    //     0x116ed3c: ret             
  }
  _ ==(/* No info */) {
    // ** addr: 0x1279ae8, size: 0x13c
    // 0x1279ae8: EnterFrame
    //     0x1279ae8: stp             fp, lr, [SP, #-0x10]!
    //     0x1279aec: mov             fp, SP
    // 0x1279af0: AllocStack(0x10)
    //     0x1279af0: sub             SP, SP, #0x10
    // 0x1279af4: CheckStackOverflow
    //     0x1279af4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1279af8: cmp             SP, x16
    //     0x1279afc: b.ls            #0x1279c1c
    // 0x1279b00: ldr             x0, [fp, #0x10]
    // 0x1279b04: cmp             w0, NULL
    // 0x1279b08: b.ne            #0x1279b1c
    // 0x1279b0c: r0 = false
    //     0x1279b0c: add             x0, NULL, #0x30  ; false
    // 0x1279b10: LeaveFrame
    //     0x1279b10: mov             SP, fp
    //     0x1279b14: ldp             fp, lr, [SP], #0x10
    // 0x1279b18: ret
    //     0x1279b18: ret             
    // 0x1279b1c: ldr             x1, [fp, #0x18]
    // 0x1279b20: cmp             w1, w0
    // 0x1279b24: b.ne            #0x1279b38
    // 0x1279b28: r0 = true
    //     0x1279b28: add             x0, NULL, #0x20  ; true
    // 0x1279b2c: LeaveFrame
    //     0x1279b2c: mov             SP, fp
    //     0x1279b30: ldp             fp, lr, [SP], #0x10
    // 0x1279b34: ret
    //     0x1279b34: ret             
    // 0x1279b38: str             x0, [SP]
    // 0x1279b3c: r0 = runtimeType()
    //     0x1279b3c: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x1279b40: r1 = LoadClassIdInstr(r0)
    //     0x1279b40: ldur            x1, [x0, #-1]
    //     0x1279b44: ubfx            x1, x1, #0xc, #0x14
    // 0x1279b48: r16 = RawKeyEventDataAndroid
    //     0x1279b48: add             x16, PP, #0xd, lsl #12  ; [pp+0xdd88] Type: RawKeyEventDataAndroid
    //     0x1279b4c: ldr             x16, [x16, #0xd88]
    // 0x1279b50: stp             x16, x0, [SP]
    // 0x1279b54: mov             x0, x1
    // 0x1279b58: mov             lr, x0
    // 0x1279b5c: ldr             lr, [x21, lr, lsl #3]
    // 0x1279b60: blr             lr
    // 0x1279b64: tbz             w0, #4, #0x1279b78
    // 0x1279b68: r0 = false
    //     0x1279b68: add             x0, NULL, #0x30  ; false
    // 0x1279b6c: LeaveFrame
    //     0x1279b6c: mov             SP, fp
    //     0x1279b70: ldp             fp, lr, [SP], #0x10
    // 0x1279b74: ret
    //     0x1279b74: ret             
    // 0x1279b78: ldr             x1, [fp, #0x10]
    // 0x1279b7c: r2 = 60
    //     0x1279b7c: mov             x2, #0x3c
    // 0x1279b80: branchIfSmi(r1, 0x1279b8c)
    //     0x1279b80: tbz             w1, #0, #0x1279b8c
    // 0x1279b84: r2 = LoadClassIdInstr(r1)
    //     0x1279b84: ldur            x2, [x1, #-1]
    //     0x1279b88: ubfx            x2, x2, #0xc, #0x14
    // 0x1279b8c: r17 = 5025
    //     0x1279b8c: mov             x17, #0x13a1
    // 0x1279b90: cmp             x2, x17
    // 0x1279b94: b.ne            #0x1279c0c
    // 0x1279b98: ldr             x2, [fp, #0x18]
    // 0x1279b9c: LoadField: r3 = r1->field_7
    //     0x1279b9c: ldur            x3, [x1, #7]
    // 0x1279ba0: LoadField: r4 = r2->field_7
    //     0x1279ba0: ldur            x4, [x2, #7]
    // 0x1279ba4: cmp             x3, x4
    // 0x1279ba8: b.ne            #0x1279c0c
    // 0x1279bac: LoadField: r3 = r1->field_f
    //     0x1279bac: ldur            x3, [x1, #0xf]
    // 0x1279bb0: LoadField: r4 = r2->field_f
    //     0x1279bb0: ldur            x4, [x2, #0xf]
    // 0x1279bb4: cmp             x3, x4
    // 0x1279bb8: b.ne            #0x1279c0c
    // 0x1279bbc: ArrayLoad: r3 = r1[0]  ; List_8
    //     0x1279bbc: ldur            x3, [x1, #0x17]
    // 0x1279bc0: ArrayLoad: r4 = r2[0]  ; List_8
    //     0x1279bc0: ldur            x4, [x2, #0x17]
    // 0x1279bc4: cmp             x3, x4
    // 0x1279bc8: b.ne            #0x1279c0c
    // 0x1279bcc: LoadField: r3 = r1->field_1f
    //     0x1279bcc: ldur            x3, [x1, #0x1f]
    // 0x1279bd0: LoadField: r4 = r2->field_1f
    //     0x1279bd0: ldur            x4, [x2, #0x1f]
    // 0x1279bd4: cmp             x3, x4
    // 0x1279bd8: b.ne            #0x1279c0c
    // 0x1279bdc: LoadField: r3 = r1->field_27
    //     0x1279bdc: ldur            x3, [x1, #0x27]
    // 0x1279be0: LoadField: r4 = r2->field_27
    //     0x1279be0: ldur            x4, [x2, #0x27]
    // 0x1279be4: cmp             x3, x4
    // 0x1279be8: b.ne            #0x1279c0c
    // 0x1279bec: LoadField: r3 = r1->field_2f
    //     0x1279bec: ldur            x3, [x1, #0x2f]
    // 0x1279bf0: LoadField: r1 = r2->field_2f
    //     0x1279bf0: ldur            x1, [x2, #0x2f]
    // 0x1279bf4: cmp             x3, x1
    // 0x1279bf8: r16 = true
    //     0x1279bf8: add             x16, NULL, #0x20  ; true
    // 0x1279bfc: r17 = false
    //     0x1279bfc: add             x17, NULL, #0x30  ; false
    // 0x1279c00: csel            x2, x16, x17, eq
    // 0x1279c04: mov             x0, x2
    // 0x1279c08: b               #0x1279c10
    // 0x1279c0c: r0 = false
    //     0x1279c0c: add             x0, NULL, #0x30  ; false
    // 0x1279c10: LeaveFrame
    //     0x1279c10: mov             SP, fp
    //     0x1279c14: ldp             fp, lr, [SP], #0x10
    // 0x1279c18: ret
    //     0x1279c18: ret             
    // 0x1279c1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1279c1c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1279c20: b               #0x1279b00
  }
}
