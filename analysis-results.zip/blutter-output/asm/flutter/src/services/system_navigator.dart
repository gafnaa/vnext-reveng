// lib: , url: package:flutter/src/services/system_navigator.dart

// class id: 1049098, size: 0x8
class :: {
}

// class id: 2741, size: 0x8, field offset: 0x8
abstract class SystemNavigator extends Object {

  static Future<void> pop() async {
    // ** addr: 0x89dfac, size: 0x5c
    // 0x89dfac: EnterFrame
    //     0x89dfac: stp             fp, lr, [SP, #-0x10]!
    //     0x89dfb0: mov             fp, SP
    // 0x89dfb4: AllocStack(0x30)
    //     0x89dfb4: sub             SP, SP, #0x30
    // 0x89dfb8: SetupParameters()
    //     0x89dfb8: stur            NULL, [fp, #-8]
    // 0x89dfbc: CheckStackOverflow
    //     0x89dfbc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89dfc0: cmp             SP, x16
    //     0x89dfc4: b.ls            #0x89e000
    // 0x89dfc8: InitAsync() -> Future<void?>
    //     0x89dfc8: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0x89dfcc: bl              #0x7f5e44  ; InitAsyncStub
    // 0x89dfd0: r16 = <void?>
    //     0x89dfd0: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x89dfd4: r30 = Instance_OptionalMethodChannel
    //     0x89dfd4: ldr             lr, [PP, #0x1960]  ; [pp+0x1960] Obj!OptionalMethodChannel@129bec1
    // 0x89dfd8: stp             lr, x16, [SP, #0x10]
    // 0x89dfdc: r16 = "SystemNavigator.pop"
    //     0x89dfdc: ldr             x16, [PP, #0x1968]  ; [pp+0x1968] "SystemNavigator.pop"
    // 0x89dfe0: stp             NULL, x16, [SP]
    // 0x89dfe4: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x89dfe4: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x89dfe8: r0 = invokeMethod()
    //     0x89dfe8: bl              #0x130ad0c  ; [package:flutter/src/services/platform_channel.dart] OptionalMethodChannel::invokeMethod
    // 0x89dfec: mov             x1, x0
    // 0x89dff0: stur            x1, [fp, #-0x10]
    // 0x89dff4: r0 = Await()
    //     0x89dff4: bl              #0x7f5c00  ; AwaitStub
    // 0x89dff8: r0 = Null
    //     0x89dff8: mov             x0, NULL
    // 0x89dffc: r0 = ReturnAsyncNotFuture()
    //     0x89dffc: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x89e000: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89e000: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89e004: b               #0x89dfc8
  }
  static _ routeInformationUpdated(/* No info */) {
    // ** addr: 0x8cb9a8, size: 0xf0
    // 0x8cb9a8: EnterFrame
    //     0x8cb9a8: stp             fp, lr, [SP, #-0x10]!
    //     0x8cb9ac: mov             fp, SP
    // 0x8cb9b0: AllocStack(0x30)
    //     0x8cb9b0: sub             SP, SP, #0x30
    // 0x8cb9b4: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */)
    //     0x8cb9b4: mov             x0, x1
    //     0x8cb9b8: stur            x1, [fp, #-8]
    // 0x8cb9bc: CheckStackOverflow
    //     0x8cb9bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8cb9c0: cmp             SP, x16
    //     0x8cb9c4: b.ls            #0x8cba90
    // 0x8cb9c8: r1 = Null
    //     0x8cb9c8: mov             x1, NULL
    // 0x8cb9cc: r2 = 12
    //     0x8cb9cc: mov             x2, #0xc
    // 0x8cb9d0: r0 = AllocateArray()
    //     0x8cb9d0: bl              #0x13df928  ; AllocateArrayStub
    // 0x8cb9d4: mov             x1, x0
    // 0x8cb9d8: stur            x1, [fp, #-0x10]
    // 0x8cb9dc: r16 = "uri"
    //     0x8cb9dc: ldr             x16, [PP, #0x5e50]  ; [pp+0x5e50] "uri"
    // 0x8cb9e0: StoreField: r1->field_f = r16
    //     0x8cb9e0: stur            w16, [x1, #0xf]
    // 0x8cb9e4: ldur            x0, [fp, #-8]
    // 0x8cb9e8: r2 = LoadClassIdInstr(r0)
    //     0x8cb9e8: ldur            x2, [x0, #-1]
    //     0x8cb9ec: ubfx            x2, x2, #0xc, #0x14
    // 0x8cb9f0: str             x0, [SP]
    // 0x8cb9f4: mov             x0, x2
    // 0x8cb9f8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8cb9f8: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8cb9fc: r0 = GDT[cid_x0 + 0x91c1]()
    //     0x8cb9fc: mov             x17, #0x91c1
    //     0x8cba00: add             lr, x0, x17
    //     0x8cba04: ldr             lr, [x21, lr, lsl #3]
    //     0x8cba08: blr             lr
    // 0x8cba0c: ldur            x1, [fp, #-0x10]
    // 0x8cba10: ArrayStore: r1[1] = r0  ; List_4
    //     0x8cba10: add             x25, x1, #0x13
    //     0x8cba14: str             w0, [x25]
    //     0x8cba18: tbz             w0, #0, #0x8cba34
    //     0x8cba1c: ldurb           w16, [x1, #-1]
    //     0x8cba20: ldurb           w17, [x0, #-1]
    //     0x8cba24: and             x16, x17, x16, lsr #2
    //     0x8cba28: tst             x16, HEAP, lsr #32
    //     0x8cba2c: b.eq            #0x8cba34
    //     0x8cba30: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x8cba34: ldur            x0, [fp, #-0x10]
    // 0x8cba38: r16 = "state"
    //     0x8cba38: ldr             x16, [PP, #0x1a60]  ; [pp+0x1a60] "state"
    // 0x8cba3c: ArrayStore: r0[0] = r16  ; List_4
    //     0x8cba3c: stur            w16, [x0, #0x17]
    // 0x8cba40: StoreField: r0->field_1b = rNULL
    //     0x8cba40: stur            NULL, [x0, #0x1b]
    // 0x8cba44: r16 = "replace"
    //     0x8cba44: add             x16, PP, #0x14, lsl #12  ; [pp+0x14cc0] "replace"
    //     0x8cba48: ldr             x16, [x16, #0xcc0]
    // 0x8cba4c: StoreField: r0->field_1f = r16
    //     0x8cba4c: stur            w16, [x0, #0x1f]
    // 0x8cba50: r16 = false
    //     0x8cba50: add             x16, NULL, #0x30  ; false
    // 0x8cba54: StoreField: r0->field_23 = r16
    //     0x8cba54: stur            w16, [x0, #0x23]
    // 0x8cba58: r16 = <String, dynamic>
    //     0x8cba58: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x8cba5c: stp             x0, x16, [SP]
    // 0x8cba60: r0 = Map._fromLiteral()
    //     0x8cba60: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x8cba64: r16 = <void?>
    //     0x8cba64: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0x8cba68: r30 = Instance_OptionalMethodChannel
    //     0x8cba68: ldr             lr, [PP, #0x1878]  ; [pp+0x1878] Obj!OptionalMethodChannel@129bf21
    // 0x8cba6c: stp             lr, x16, [SP, #0x10]
    // 0x8cba70: r16 = "routeInformationUpdated"
    //     0x8cba70: add             x16, PP, #0x14, lsl #12  ; [pp+0x14cc8] "routeInformationUpdated"
    //     0x8cba74: ldr             x16, [x16, #0xcc8]
    // 0x8cba78: stp             x0, x16, [SP]
    // 0x8cba7c: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x8cba7c: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x8cba80: r0 = invokeMethod()
    //     0x8cba80: bl              #0x130ad0c  ; [package:flutter/src/services/platform_channel.dart] OptionalMethodChannel::invokeMethod
    // 0x8cba84: LeaveFrame
    //     0x8cba84: mov             SP, fp
    //     0x8cba88: ldp             fp, lr, [SP], #0x10
    // 0x8cba8c: ret
    //     0x8cba8c: ret             
    // 0x8cba90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8cba90: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8cba94: b               #0x8cb9c8
  }
  static _ setFrameworkHandlesBack(/* No info */) async {
    // ** addr: 0xd5d13c, size: 0x58
    // 0xd5d13c: EnterFrame
    //     0xd5d13c: stp             fp, lr, [SP, #-0x10]!
    //     0xd5d140: mov             fp, SP
    // 0xd5d144: AllocStack(0x30)
    //     0xd5d144: sub             SP, SP, #0x30
    // 0xd5d148: SetupParameters(dynamic _ /* r1 => r1, fp-0x10 */)
    //     0xd5d148: stur            NULL, [fp, #-8]
    //     0xd5d14c: stur            x1, [fp, #-0x10]
    // 0xd5d150: CheckStackOverflow
    //     0xd5d150: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd5d154: cmp             SP, x16
    //     0xd5d158: b.ls            #0xd5d18c
    // 0xd5d15c: InitAsync() -> Future<void?>
    //     0xd5d15c: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0xd5d160: bl              #0x7f5e44  ; InitAsyncStub
    // 0xd5d164: r16 = <void?>
    //     0xd5d164: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xd5d168: r30 = Instance_OptionalMethodChannel
    //     0xd5d168: ldr             lr, [PP, #0x1960]  ; [pp+0x1960] Obj!OptionalMethodChannel@129bec1
    // 0xd5d16c: stp             lr, x16, [SP, #0x10]
    // 0xd5d170: r16 = "SystemNavigator.setFrameworkHandlesBack"
    //     0xd5d170: add             x16, PP, #0xa3, lsl #12  ; [pp+0xa33a8] "SystemNavigator.setFrameworkHandlesBack"
    //     0xd5d174: ldr             x16, [x16, #0x3a8]
    // 0xd5d178: ldur            lr, [fp, #-0x10]
    // 0xd5d17c: stp             lr, x16, [SP]
    // 0xd5d180: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xd5d180: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xd5d184: r0 = invokeMethod()
    //     0xd5d184: bl              #0x130ad0c  ; [package:flutter/src/services/platform_channel.dart] OptionalMethodChannel::invokeMethod
    // 0xd5d188: r0 = ReturnAsync()
    //     0xd5d188: b               #0x82fdf0  ; ReturnAsyncStub
    // 0xd5d18c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd5d18c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd5d190: b               #0xd5d15c
  }
  static Future<void> selectSingleEntryHistory() {
    // ** addr: 0xf83efc, size: 0x4c
    // 0xf83efc: EnterFrame
    //     0xf83efc: stp             fp, lr, [SP, #-0x10]!
    //     0xf83f00: mov             fp, SP
    // 0xf83f04: AllocStack(0x18)
    //     0xf83f04: sub             SP, SP, #0x18
    // 0xf83f08: CheckStackOverflow
    //     0xf83f08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf83f0c: cmp             SP, x16
    //     0xf83f10: b.ls            #0xf83f40
    // 0xf83f14: r16 = <void?>
    //     0xf83f14: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xf83f18: r30 = Instance_OptionalMethodChannel
    //     0xf83f18: ldr             lr, [PP, #0x1878]  ; [pp+0x1878] Obj!OptionalMethodChannel@129bf21
    // 0xf83f1c: stp             lr, x16, [SP, #8]
    // 0xf83f20: r16 = "selectSingleEntryHistory"
    //     0xf83f20: add             x16, PP, #0x9a, lsl #12  ; [pp+0x9a4e8] "selectSingleEntryHistory"
    //     0xf83f24: ldr             x16, [x16, #0x4e8]
    // 0xf83f28: str             x16, [SP]
    // 0xf83f2c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xf83f2c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xf83f30: r0 = invokeMethod()
    //     0xf83f30: bl              #0x130ad0c  ; [package:flutter/src/services/platform_channel.dart] OptionalMethodChannel::invokeMethod
    // 0xf83f34: LeaveFrame
    //     0xf83f34: mov             SP, fp
    //     0xf83f38: ldp             fp, lr, [SP], #0x10
    // 0xf83f3c: ret
    //     0xf83f3c: ret             
    // 0xf83f40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf83f40: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf83f44: b               #0xf83f14
  }
}
