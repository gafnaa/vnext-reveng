// lib: , url: package:flutter/src/physics/friction_simulation.dart

// class id: 1049014, size: 0x8
class :: {

  static _ _newtonsMethod(/* No info */) {
    // ** addr: 0xd6ba90, size: 0x190
    // 0xd6ba90: EnterFrame
    //     0xd6ba90: stp             fp, lr, [SP, #-0x10]!
    //     0xd6ba94: mov             fp, SP
    // 0xd6ba98: AllocStack(0x48)
    //     0xd6ba98: sub             SP, SP, #0x48
    // 0xd6ba9c: SetupParameters(dynamic _ /* r1 => r2, fp-0x30 */, dynamic _ /* r2 => r1, fp-0x20 */)
    //     0xd6ba9c: stur            x1, [fp, #-0x18]
    //     0xd6baa0: mov             x16, x2
    //     0xd6baa4: mov             x2, x1
    //     0xd6baa8: mov             x1, x16
    //     0xd6baac: stur            x1, [fp, #-0x20]
    //     0xd6bab0: stur            d0, [fp, #-0x30]
    // 0xd6bab4: CheckStackOverflow
    //     0xd6bab4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd6bab8: cmp             SP, x16
    //     0xd6babc: b.ls            #0xd6bbcc
    // 0xd6bac0: d1 = 0.000000
    //     0xd6bac0: eor             v1.16b, v1.16b, v1.16b
    // 0xd6bac4: r3 = 0
    //     0xd6bac4: mov             x3, #0
    // 0xd6bac8: stur            x3, [fp, #-0x10]
    // 0xd6bacc: stur            d1, [fp, #-0x28]
    // 0xd6bad0: CheckStackOverflow
    //     0xd6bad0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd6bad4: cmp             SP, x16
    //     0xd6bad8: b.ls            #0xd6bbd4
    // 0xd6badc: cmp             x3, #0xa
    // 0xd6bae0: b.ge            #0xd6bbbc
    // 0xd6bae4: r4 = inline_Allocate_Double()
    //     0xd6bae4: ldp             x4, x0, [THR, #0x60]  ; THR::top
    //     0xd6bae8: add             x4, x4, #0x10
    //     0xd6baec: cmp             x0, x4
    //     0xd6baf0: b.ls            #0xd6bbdc
    //     0xd6baf4: str             x4, [THR, #0x60]  ; THR::top
    //     0xd6baf8: sub             x4, x4, #0xf
    //     0xd6bafc: mov             x0, #0xe19c
    //     0xd6bb00: movk            x0, #3, lsl #16
    //     0xd6bb04: stur            x0, [x4, #-1]
    // 0xd6bb08: dmb             ishst
    // 0xd6bb0c: StoreField: r4->field_7 = d1
    //     0xd6bb0c: stur            d1, [x4, #7]
    // 0xd6bb10: stur            x4, [fp, #-8]
    // 0xd6bb14: stp             x4, x1, [SP]
    // 0xd6bb18: mov             x0, x1
    // 0xd6bb1c: ClosureCall
    //     0xd6bb1c: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xd6bb20: ldur            x2, [x0, #0x1f]
    //     0xd6bb24: blr             x2
    // 0xd6bb28: cmp             w0, NULL
    // 0xd6bb2c: b.eq            #0xd6bc00
    // 0xd6bb30: LoadField: d0 = r0->field_7
    //     0xd6bb30: ldur            d0, [x0, #7]
    // 0xd6bb34: ldur            d1, [fp, #-0x30]
    // 0xd6bb38: fsub            d2, d0, d1
    // 0xd6bb3c: stur            d2, [fp, #-0x38]
    // 0xd6bb40: ldur            x16, [fp, #-0x18]
    // 0xd6bb44: ldur            lr, [fp, #-8]
    // 0xd6bb48: stp             lr, x16, [SP]
    // 0xd6bb4c: ldur            x0, [fp, #-0x18]
    // 0xd6bb50: ClosureCall
    //     0xd6bb50: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xd6bb54: ldur            x2, [x0, #0x1f]
    //     0xd6bb58: blr             x2
    // 0xd6bb5c: ldur            d0, [fp, #-0x38]
    // 0xd6bb60: r1 = inline_Allocate_Double()
    //     0xd6bb60: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xd6bb64: add             x1, x1, #0x10
    //     0xd6bb68: cmp             x2, x1
    //     0xd6bb6c: b.ls            #0xd6bc04
    //     0xd6bb70: str             x1, [THR, #0x60]  ; THR::top
    //     0xd6bb74: sub             x1, x1, #0xf
    //     0xd6bb78: mov             x2, #0xe19c
    //     0xd6bb7c: movk            x2, #3, lsl #16
    //     0xd6bb80: stur            x2, [x1, #-1]
    // 0xd6bb84: dmb             ishst
    // 0xd6bb88: StoreField: r1->field_7 = d0
    //     0xd6bb88: stur            d0, [x1, #7]
    // 0xd6bb8c: stp             x0, x1, [SP]
    // 0xd6bb90: r0 = /()
    //     0xd6bb90: bl              #0x13dcfc8  ; [dart:core] _Double::/
    // 0xd6bb94: LoadField: d1 = r0->field_7
    //     0xd6bb94: ldur            d1, [x0, #7]
    // 0xd6bb98: ldur            d0, [fp, #-0x28]
    // 0xd6bb9c: fsub            d2, d0, d1
    // 0xd6bba0: ldur            x0, [fp, #-0x10]
    // 0xd6bba4: add             x3, x0, #1
    // 0xd6bba8: mov             v1.16b, v2.16b
    // 0xd6bbac: ldur            x2, [fp, #-0x18]
    // 0xd6bbb0: ldur            x1, [fp, #-0x20]
    // 0xd6bbb4: ldur            d0, [fp, #-0x30]
    // 0xd6bbb8: b               #0xd6bac8
    // 0xd6bbbc: mov             v0.16b, v1.16b
    // 0xd6bbc0: LeaveFrame
    //     0xd6bbc0: mov             SP, fp
    //     0xd6bbc4: ldp             fp, lr, [SP], #0x10
    // 0xd6bbc8: ret
    //     0xd6bbc8: ret             
    // 0xd6bbcc: r0 = StackOverflowSharedWithFPURegs()
    //     0xd6bbcc: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xd6bbd0: b               #0xd6bac0
    // 0xd6bbd4: r0 = StackOverflowSharedWithFPURegs()
    //     0xd6bbd4: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xd6bbd8: b               #0xd6badc
    // 0xd6bbdc: stp             q0, q1, [SP, #-0x20]!
    // 0xd6bbe0: stp             x2, x3, [SP, #-0x10]!
    // 0xd6bbe4: SaveReg r1
    //     0xd6bbe4: str             x1, [SP, #-8]!
    // 0xd6bbe8: r0 = AllocateDouble()
    //     0xd6bbe8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd6bbec: mov             x4, x0
    // 0xd6bbf0: RestoreReg r1
    //     0xd6bbf0: ldr             x1, [SP], #8
    // 0xd6bbf4: ldp             x2, x3, [SP], #0x10
    // 0xd6bbf8: ldp             q0, q1, [SP], #0x20
    // 0xd6bbfc: b               #0xd6bb0c
    // 0xd6bc00: r0 = NullErrorSharedWithoutFPURegs()
    //     0xd6bc00: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xd6bc04: SaveReg d0
    //     0xd6bc04: str             q0, [SP, #-0x10]!
    // 0xd6bc08: SaveReg r0
    //     0xd6bc08: str             x0, [SP, #-8]!
    // 0xd6bc0c: r0 = AllocateDouble()
    //     0xd6bc0c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd6bc10: mov             x1, x0
    // 0xd6bc14: RestoreReg r0
    //     0xd6bc14: ldr             x0, [SP], #8
    // 0xd6bc18: RestoreReg d0
    //     0xd6bc18: ldr             q0, [SP], #0x10
    // 0xd6bc1c: b               #0xd6bb88
  }
}

// class id: 3342, size: 0x3c, field offset: 0xc
class FrictionSimulation extends Simulation {

  dynamic dx(dynamic) {
    // ** addr: 0x1183e70, size: 0x3c
    // 0x1183e70: EnterFrame
    //     0x1183e70: stp             fp, lr, [SP, #-0x10]!
    //     0x1183e74: mov             fp, SP
    // 0x1183e78: ldr             x2, [fp, #0x10]
    // 0x1183e7c: r1 = Function 'dx':.
    //     0x1183e7c: add             x1, PP, #0xab, lsl #12  ; [pp+0xab8d8] AnonymousClosure: (0xd6b7a4), in [package:flutter/src/physics/friction_simulation.dart] FrictionSimulation::dx (0x12dc4d8)
    //     0x1183e80: ldr             x1, [x1, #0x8d8]
    // 0x1183e84: r0 = AllocateClosure()
    //     0x1183e84: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1183e88: LeaveFrame
    //     0x1183e88: mov             SP, fp
    //     0x1183e8c: ldp             fp, lr, [SP], #0x10
    // 0x1183e90: ret
    //     0x1183e90: ret             
  }
  get _ finalX(/* No info */) {
    // ** addr: 0xd6b6f4, size: 0xb0
    // 0xd6b6f4: EnterFrame
    //     0xd6b6f4: stp             fp, lr, [SP, #-0x10]!
    //     0xd6b6f8: mov             fp, SP
    // 0xd6b6fc: d0 = 0.000000
    //     0xd6b6fc: eor             v0.16b, v0.16b, v0.16b
    // 0xd6b700: CheckStackOverflow
    //     0xd6b700: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd6b704: cmp             SP, x16
    //     0xd6b708: b.ls            #0xd6b780
    // 0xd6b70c: LoadField: d1 = r1->field_2b
    //     0xd6b70c: ldur            d1, [x1, #0x2b]
    // 0xd6b710: fcmp            d1, d0
    // 0xd6b714: b.ne            #0xd6b73c
    // 0xd6b718: LoadField: d0 = r1->field_1b
    //     0xd6b718: ldur            d0, [x1, #0x1b]
    // 0xd6b71c: LoadField: d1 = r1->field_23
    //     0xd6b71c: ldur            d1, [x1, #0x23]
    // 0xd6b720: LoadField: d2 = r1->field_13
    //     0xd6b720: ldur            d2, [x1, #0x13]
    // 0xd6b724: fdiv            d3, d1, d2
    // 0xd6b728: fsub            d1, d0, d3
    // 0xd6b72c: mov             v0.16b, v1.16b
    // 0xd6b730: LeaveFrame
    //     0xd6b730: mov             SP, fp
    //     0xd6b734: ldp             fp, lr, [SP], #0x10
    // 0xd6b738: ret
    //     0xd6b738: ret             
    // 0xd6b73c: LoadField: d0 = r1->field_33
    //     0xd6b73c: ldur            d0, [x1, #0x33]
    // 0xd6b740: r2 = inline_Allocate_Double()
    //     0xd6b740: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0xd6b744: add             x2, x2, #0x10
    //     0xd6b748: cmp             x0, x2
    //     0xd6b74c: b.ls            #0xd6b788
    //     0xd6b750: str             x2, [THR, #0x60]  ; THR::top
    //     0xd6b754: sub             x2, x2, #0xf
    //     0xd6b758: mov             x0, #0xe19c
    //     0xd6b75c: movk            x0, #3, lsl #16
    //     0xd6b760: stur            x0, [x2, #-1]
    // 0xd6b764: dmb             ishst
    // 0xd6b768: StoreField: r2->field_7 = d0
    //     0xd6b768: stur            d0, [x2, #7]
    // 0xd6b76c: r0 = x()
    //     0xd6b76c: bl              #0x12f1828  ; [package:flutter/src/physics/friction_simulation.dart] FrictionSimulation::x
    // 0xd6b770: LoadField: d0 = r0->field_7
    //     0xd6b770: ldur            d0, [x0, #7]
    // 0xd6b774: LeaveFrame
    //     0xd6b774: mov             SP, fp
    //     0xd6b778: ldp             fp, lr, [SP], #0x10
    // 0xd6b77c: ret
    //     0xd6b77c: ret             
    // 0xd6b780: r0 = StackOverflowSharedWithFPURegs()
    //     0xd6b780: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xd6b784: b               #0xd6b70c
    // 0xd6b788: SaveReg d0
    //     0xd6b788: str             q0, [SP, #-0x10]!
    // 0xd6b78c: SaveReg r1
    //     0xd6b78c: str             x1, [SP, #-8]!
    // 0xd6b790: r0 = AllocateDouble()
    //     0xd6b790: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd6b794: mov             x2, x0
    // 0xd6b798: RestoreReg r1
    //     0xd6b798: ldr             x1, [SP], #8
    // 0xd6b79c: RestoreReg d0
    //     0xd6b79c: ldr             q0, [SP], #0x10
    // 0xd6b7a0: b               #0xd6b768
  }
  [closure] double dx(dynamic, double) {
    // ** addr: 0xd6b7a4, size: 0x180
    // 0xd6b7a4: EnterFrame
    //     0xd6b7a4: stp             fp, lr, [SP, #-0x10]!
    //     0xd6b7a8: mov             fp, SP
    // 0xd6b7ac: AllocStack(0x10)
    //     0xd6b7ac: sub             SP, SP, #0x10
    // 0xd6b7b0: SetupParameters([dynamic _ /* r19 */])
    //     0xd6b7b0: ldr             x19, [fp, #0x18]
    //     0xd6b7b4: ldur            w20, [x19, #0x17]
    //     0xd6b7b8: add             x20, x20, HEAP, lsl #32
    // 0xd6b7bc: LoadField: d0 = r20->field_33
    //     0xd6b7bc: ldur            d0, [x20, #0x33]
    // 0xd6b7c0: ldr             x19, [fp, #0x10]
    // 0xd6b7c4: LoadField: d2 = r19->field_7
    //     0xd6b7c4: ldur            d2, [x19, #7]
    // 0xd6b7c8: stur            d2, [fp, #-0x10]
    // 0xd6b7cc: fcmp            d2, d0
    // 0xd6b7d0: b.le            #0xd6b7dc
    // 0xd6b7d4: d0 = 0.000000
    //     0xd6b7d4: eor             v0.16b, v0.16b, v0.16b
    // 0xd6b7d8: b               #0xd6b8dc
    // 0xd6b7dc: LoadField: d3 = r20->field_23
    //     0xd6b7dc: ldur            d3, [x20, #0x23]
    // 0xd6b7e0: stur            d3, [fp, #-8]
    // 0xd6b7e4: LoadField: d0 = r20->field_b
    //     0xd6b7e4: ldur            d0, [x20, #0xb]
    // 0xd6b7e8: mov             v1.16b, v2.16b
    // 0xd6b7ec: d30 = 0.000000
    //     0xd6b7ec: fmov            d30, d0
    // 0xd6b7f0: d0 = 1.000000
    //     0xd6b7f0: fmov            d0, #1.00000000
    // 0xd6b7f4: fcmp            d1, #0.0
    // 0xd6b7f8: b.vs            #0xd6b83c
    // 0xd6b7fc: b.eq            #0xd6b8c0
    // 0xd6b800: fcmp            d1, d0
    // 0xd6b804: b.eq            #0xd6b82c
    // 0xd6b808: d31 = 2.000000
    //     0xd6b808: fmov            d31, #2.00000000
    // 0xd6b80c: fcmp            d1, d31
    // 0xd6b810: b.eq            #0xd6b834
    // 0xd6b814: d31 = 3.000000
    //     0xd6b814: fmov            d31, #3.00000000
    // 0xd6b818: fcmp            d1, d31
    // 0xd6b81c: b.ne            #0xd6b83c
    // 0xd6b820: fmul            d0, d30, d30
    // 0xd6b824: fmul            d0, d0, d30
    // 0xd6b828: b               #0xd6b8c0
    // 0xd6b82c: d0 = 0.000000
    //     0xd6b82c: fmov            d0, d30
    // 0xd6b830: b               #0xd6b8c0
    // 0xd6b834: fmul            d0, d30, d30
    // 0xd6b838: b               #0xd6b8c0
    // 0xd6b83c: fcmp            d30, d0
    // 0xd6b840: b.vs            #0xd6b850
    // 0xd6b844: b.eq            #0xd6b8c0
    // 0xd6b848: fcmp            d30, d1
    // 0xd6b84c: b.vc            #0xd6b858
    // 0xd6b850: d0 = -nan
    //     0xd6b850: ldr             d0, [PP, #0x24c0]  ; [pp+0x24c0] IMM: double(-nan) from 0xfff8000000000000
    // 0xd6b854: b               #0xd6b8c0
    // 0xd6b858: d0 = -inf
    //     0xd6b858: ldr             d0, [PP, #0x5780]  ; [pp+0x5780] IMM: double(-inf) from 0xfff0000000000000
    // 0xd6b85c: fcmp            d30, d0
    // 0xd6b860: b.eq            #0xd6b888
    // 0xd6b864: d0 = 0.500000
    //     0xd6b864: fmov            d0, #0.50000000
    // 0xd6b868: fcmp            d1, d0
    // 0xd6b86c: b.ne            #0xd6b888
    // 0xd6b870: fcmp            d30, #0.0
    // 0xd6b874: b.eq            #0xd6b880
    // 0xd6b878: fsqrt           d0, d30
    // 0xd6b87c: b               #0xd6b8c0
    // 0xd6b880: d0 = 0.000000
    //     0xd6b880: eor             v0.16b, v0.16b, v0.16b
    // 0xd6b884: b               #0xd6b8c0
    // 0xd6b888: d0 = 0.000000
    //     0xd6b888: fmov            d0, d30
    // 0xd6b88c: stp             fp, lr, [SP, #-0x10]!
    // 0xd6b890: mov             fp, SP
    // 0xd6b894: CallRuntime_LibcPow(double, double) -> double
    //     0xd6b894: and             SP, SP, #0xfffffffffffffff0
    //     0xd6b898: mov             sp, SP
    //     0xd6b89c: ldr             x16, [THR, #0x740]  ; THR::LibcPow
    //     0xd6b8a0: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xd6b8a4: blr             x16
    //     0xd6b8a8: mov             x16, #8
    //     0xd6b8ac: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xd6b8b0: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xd6b8b4: sub             sp, x16, #1, lsl #12
    //     0xd6b8b8: mov             SP, fp
    //     0xd6b8bc: ldp             fp, lr, [SP], #0x10
    // 0xd6b8c0: mov             v1.16b, v0.16b
    // 0xd6b8c4: ldur            d0, [fp, #-8]
    // 0xd6b8c8: fmul            d2, d0, d1
    // 0xd6b8cc: LoadField: d0 = r20->field_2b
    //     0xd6b8cc: ldur            d0, [x20, #0x2b]
    // 0xd6b8d0: ldur            d1, [fp, #-0x10]
    // 0xd6b8d4: fmul            d3, d0, d1
    // 0xd6b8d8: fsub            d0, d2, d3
    // 0xd6b8dc: r0 = inline_Allocate_Double()
    //     0xd6b8dc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xd6b8e0: add             x0, x0, #0x10
    //     0xd6b8e4: cmp             x1, x0
    //     0xd6b8e8: b.ls            #0xd6b914
    //     0xd6b8ec: str             x0, [THR, #0x60]  ; THR::top
    //     0xd6b8f0: sub             x0, x0, #0xf
    //     0xd6b8f4: mov             x1, #0xe19c
    //     0xd6b8f8: movk            x1, #3, lsl #16
    //     0xd6b8fc: stur            x1, [x0, #-1]
    // 0xd6b900: dmb             ishst
    // 0xd6b904: StoreField: r0->field_7 = d0
    //     0xd6b904: stur            d0, [x0, #7]
    // 0xd6b908: LeaveFrame
    //     0xd6b908: mov             SP, fp
    //     0xd6b90c: ldp             fp, lr, [SP], #0x10
    // 0xd6b910: ret
    //     0xd6b910: ret             
    // 0xd6b914: SaveReg d0
    //     0xd6b914: str             q0, [SP, #-0x10]!
    // 0xd6b918: r0 = AllocateDouble()
    //     0xd6b918: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd6b91c: RestoreReg d0
    //     0xd6b91c: ldr             q0, [SP], #0x10
    // 0xd6b920: b               #0xd6b904
  }
  _ FrictionSimulation(/* No info */) {
    // ** addr: 0xd6b924, size: 0x16c
    // 0xd6b924: EnterFrame
    //     0xd6b924: stp             fp, lr, [SP, #-0x10]!
    //     0xd6b928: mov             fp, SP
    // 0xd6b92c: AllocStack(0x30)
    //     0xd6b92c: sub             SP, SP, #0x30
    // 0xd6b930: SetupParameters(FrictionSimulation this /* r1 => r2, fp-0x8 */, dynamic _ /* d0 => d0, fp-0x20 */, dynamic _ /* d1 => d1, fp-0x28 */, dynamic _ /* d2 => d2, fp-0x30 */, {_Double constantDeceleration = 0.000000 /* d3, fp-0x18 */})
    //     0xd6b930: mov             x2, x1
    //     0xd6b934: stur            x1, [fp, #-8]
    //     0xd6b938: stur            d0, [fp, #-0x20]
    //     0xd6b93c: stur            d1, [fp, #-0x28]
    //     0xd6b940: stur            d2, [fp, #-0x30]
    //     0xd6b944: ldur            w0, [x4, #0x13]
    //     0xd6b948: ldur            w1, [x4, #0x1f]
    //     0xd6b94c: add             x1, x1, HEAP, lsl #32
    //     0xd6b950: add             x16, PP, #0xab, lsl #12  ; [pp+0xab8e0] "constantDeceleration"
    //     0xd6b954: ldr             x16, [x16, #0x8e0]
    //     0xd6b958: cmp             w1, w16
    //     0xd6b95c: b.ne            #0xd6b97c
    //     0xd6b960: ldur            w1, [x4, #0x23]
    //     0xd6b964: add             x1, x1, HEAP, lsl #32
    //     0xd6b968: sub             w3, w0, w1
    //     0xd6b96c: add             x0, fp, w3, sxtw #2
    //     0xd6b970: ldr             x0, [x0, #8]
    //     0xd6b974: ldur            d3, [x0, #7]
    //     0xd6b978: b               #0xd6b980
    //     0xd6b97c: eor             v3.16b, v3.16b, v3.16b
    //     0xd6b980: stur            d3, [fp, #-0x18]
    // 0xd6b984: CheckStackOverflow
    //     0xd6b984: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd6b988: cmp             SP, x16
    //     0xd6b98c: b.ls            #0xd6ba88
    // 0xd6b990: r1 = 1
    //     0xd6b990: mov             x1, #1
    // 0xd6b994: r0 = AllocateContext()
    //     0xd6b994: bl              #0x13de838  ; AllocateContextStub
    // 0xd6b998: mov             x20, x0
    // 0xd6b99c: ldur            x19, [fp, #-8]
    // 0xd6b9a0: stur            x20, [fp, #-0x10]
    // 0xd6b9a4: StoreField: r20->field_f = r19
    //     0xd6b9a4: stur            w19, [x20, #0xf]
    // 0xd6b9a8: d0 = inf
    //     0xd6b9a8: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xd6b9ac: StoreField: r19->field_33 = d0
    //     0xd6b9ac: stur            d0, [x19, #0x33]
    // 0xd6b9b0: ldur            d0, [fp, #-0x20]
    // 0xd6b9b4: StoreField: r19->field_b = d0
    //     0xd6b9b4: stur            d0, [x19, #0xb]
    // 0xd6b9b8: stp             fp, lr, [SP, #-0x10]!
    // 0xd6b9bc: mov             fp, SP
    // 0xd6b9c0: CallRuntime_LibcLog(double) -> double
    //     0xd6b9c0: and             SP, SP, #0xfffffffffffffff0
    //     0xd6b9c4: mov             sp, SP
    //     0xd6b9c8: ldr             x16, [THR, #0x7b8]  ; THR::LibcLog
    //     0xd6b9cc: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xd6b9d0: blr             x16
    //     0xd6b9d4: mov             x16, #8
    //     0xd6b9d8: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xd6b9dc: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xd6b9e0: sub             sp, x16, #1, lsl #12
    //     0xd6b9e4: mov             SP, fp
    //     0xd6b9e8: ldp             fp, lr, [SP], #0x10
    // 0xd6b9ec: StoreField: r19->field_13 = d0
    //     0xd6b9ec: stur            d0, [x19, #0x13]
    // 0xd6b9f0: ldur            d0, [fp, #-0x28]
    // 0xd6b9f4: StoreField: r19->field_1b = d0
    //     0xd6b9f4: stur            d0, [x19, #0x1b]
    // 0xd6b9f8: ldur            d0, [fp, #-0x30]
    // 0xd6b9fc: StoreField: r19->field_23 = d0
    //     0xd6b9fc: stur            d0, [x19, #0x23]
    // 0xd6ba00: d1 = 0.000000
    //     0xd6ba00: eor             v1.16b, v1.16b, v1.16b
    // 0xd6ba04: fcmp            d0, d1
    // 0xd6ba08: b.le            #0xd6ba14
    // 0xd6ba0c: d2 = 1.000000
    //     0xd6ba0c: fmov            d2, #1.00000000
    // 0xd6ba10: b               #0xd6ba28
    // 0xd6ba14: fcmp            d1, d0
    // 0xd6ba18: b.le            #0xd6ba24
    // 0xd6ba1c: d2 = -1.000000
    //     0xd6ba1c: fmov            d2, #-1.00000000
    // 0xd6ba20: b               #0xd6ba28
    // 0xd6ba24: mov             v2.16b, v0.16b
    // 0xd6ba28: ldur            d0, [fp, #-0x18]
    // 0xd6ba2c: r0 = Instance_Tolerance
    //     0xd6ba2c: ldr             x0, [PP, #0x51d8]  ; [pp+0x51d8] Obj!Tolerance@129c5c1
    // 0xd6ba30: fmul            d3, d0, d2
    // 0xd6ba34: StoreField: r19->field_2b = d3
    //     0xd6ba34: stur            d3, [x19, #0x2b]
    // 0xd6ba38: StoreField: r19->field_7 = r0
    //     0xd6ba38: stur            w0, [x19, #7]
    // 0xd6ba3c: mov             x2, x19
    // 0xd6ba40: r1 = Function 'dx':.
    //     0xd6ba40: add             x1, PP, #0xab, lsl #12  ; [pp+0xab8d8] AnonymousClosure: (0xd6b7a4), in [package:flutter/src/physics/friction_simulation.dart] FrictionSimulation::dx (0x12dc4d8)
    //     0xd6ba44: ldr             x1, [x1, #0x8d8]
    // 0xd6ba48: r0 = AllocateClosure()
    //     0xd6ba48: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd6ba4c: ldur            x2, [fp, #-0x10]
    // 0xd6ba50: r1 = Function '<anonymous closure>':.
    //     0xd6ba50: add             x1, PP, #0xab, lsl #12  ; [pp+0xab8e8] AnonymousClosure: (0xd6bc20), in [package:flutter/src/physics/friction_simulation.dart] FrictionSimulation::FrictionSimulation (0xd6b924)
    //     0xd6ba54: ldr             x1, [x1, #0x8e8]
    // 0xd6ba58: stur            x0, [fp, #-0x10]
    // 0xd6ba5c: r0 = AllocateClosure()
    //     0xd6ba5c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd6ba60: mov             x1, x0
    // 0xd6ba64: ldur            x2, [fp, #-0x10]
    // 0xd6ba68: d0 = 0.000000
    //     0xd6ba68: eor             v0.16b, v0.16b, v0.16b
    // 0xd6ba6c: r0 = _newtonsMethod()
    //     0xd6ba6c: bl              #0xd6ba90  ; [package:flutter/src/physics/friction_simulation.dart] ::_newtonsMethod
    // 0xd6ba70: ldur            x1, [fp, #-8]
    // 0xd6ba74: StoreField: r1->field_33 = d0
    //     0xd6ba74: stur            d0, [x1, #0x33]
    // 0xd6ba78: r0 = Null
    //     0xd6ba78: mov             x0, NULL
    // 0xd6ba7c: LeaveFrame
    //     0xd6ba7c: mov             SP, fp
    //     0xd6ba80: ldp             fp, lr, [SP], #0x10
    // 0xd6ba84: ret
    //     0xd6ba84: ret             
    // 0xd6ba88: r0 = StackOverflowSharedWithFPURegs()
    //     0xd6ba88: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xd6ba8c: b               #0xd6b990
  }
  [closure] double <anonymous closure>(dynamic, double) {
    // ** addr: 0xd6bc20, size: 0x16c
    // 0xd6bc20: EnterFrame
    //     0xd6bc20: stp             fp, lr, [SP, #-0x10]!
    //     0xd6bc24: mov             fp, SP
    // 0xd6bc28: AllocStack(0x8)
    //     0xd6bc28: sub             SP, SP, #8
    // 0xd6bc2c: SetupParameters([dynamic _ /* r19 */])
    //     0xd6bc2c: ldr             x19, [fp, #0x18]
    //     0xd6bc30: ldur            w20, [x19, #0x17]
    //     0xd6bc34: add             x20, x20, HEAP, lsl #32
    // 0xd6bc38: LoadField: r19 = r20->field_f
    //     0xd6bc38: ldur            w19, [x20, #0xf]
    // 0xd6bc3c: DecompressPointer r19
    //     0xd6bc3c: add             x19, x19, HEAP, lsl #32
    // 0xd6bc40: LoadField: d2 = r19->field_23
    //     0xd6bc40: ldur            d2, [x19, #0x23]
    // 0xd6bc44: stur            d2, [fp, #-8]
    // 0xd6bc48: LoadField: d0 = r19->field_b
    //     0xd6bc48: ldur            d0, [x19, #0xb]
    // 0xd6bc4c: ldr             x20, [fp, #0x10]
    // 0xd6bc50: LoadField: d1 = r20->field_7
    //     0xd6bc50: ldur            d1, [x20, #7]
    // 0xd6bc54: d30 = 0.000000
    //     0xd6bc54: fmov            d30, d0
    // 0xd6bc58: d0 = 1.000000
    //     0xd6bc58: fmov            d0, #1.00000000
    // 0xd6bc5c: fcmp            d1, #0.0
    // 0xd6bc60: b.vs            #0xd6bca4
    // 0xd6bc64: b.eq            #0xd6bd28
    // 0xd6bc68: fcmp            d1, d0
    // 0xd6bc6c: b.eq            #0xd6bc94
    // 0xd6bc70: d31 = 2.000000
    //     0xd6bc70: fmov            d31, #2.00000000
    // 0xd6bc74: fcmp            d1, d31
    // 0xd6bc78: b.eq            #0xd6bc9c
    // 0xd6bc7c: d31 = 3.000000
    //     0xd6bc7c: fmov            d31, #3.00000000
    // 0xd6bc80: fcmp            d1, d31
    // 0xd6bc84: b.ne            #0xd6bca4
    // 0xd6bc88: fmul            d0, d30, d30
    // 0xd6bc8c: fmul            d0, d0, d30
    // 0xd6bc90: b               #0xd6bd28
    // 0xd6bc94: d0 = 0.000000
    //     0xd6bc94: fmov            d0, d30
    // 0xd6bc98: b               #0xd6bd28
    // 0xd6bc9c: fmul            d0, d30, d30
    // 0xd6bca0: b               #0xd6bd28
    // 0xd6bca4: fcmp            d30, d0
    // 0xd6bca8: b.vs            #0xd6bcb8
    // 0xd6bcac: b.eq            #0xd6bd28
    // 0xd6bcb0: fcmp            d30, d1
    // 0xd6bcb4: b.vc            #0xd6bcc0
    // 0xd6bcb8: d0 = -nan
    //     0xd6bcb8: ldr             d0, [PP, #0x24c0]  ; [pp+0x24c0] IMM: double(-nan) from 0xfff8000000000000
    // 0xd6bcbc: b               #0xd6bd28
    // 0xd6bcc0: d0 = -inf
    //     0xd6bcc0: ldr             d0, [PP, #0x5780]  ; [pp+0x5780] IMM: double(-inf) from 0xfff0000000000000
    // 0xd6bcc4: fcmp            d30, d0
    // 0xd6bcc8: b.eq            #0xd6bcf0
    // 0xd6bccc: d0 = 0.500000
    //     0xd6bccc: fmov            d0, #0.50000000
    // 0xd6bcd0: fcmp            d1, d0
    // 0xd6bcd4: b.ne            #0xd6bcf0
    // 0xd6bcd8: fcmp            d30, #0.0
    // 0xd6bcdc: b.eq            #0xd6bce8
    // 0xd6bce0: fsqrt           d0, d30
    // 0xd6bce4: b               #0xd6bd28
    // 0xd6bce8: d0 = 0.000000
    //     0xd6bce8: eor             v0.16b, v0.16b, v0.16b
    // 0xd6bcec: b               #0xd6bd28
    // 0xd6bcf0: d0 = 0.000000
    //     0xd6bcf0: fmov            d0, d30
    // 0xd6bcf4: stp             fp, lr, [SP, #-0x10]!
    // 0xd6bcf8: mov             fp, SP
    // 0xd6bcfc: CallRuntime_LibcPow(double, double) -> double
    //     0xd6bcfc: and             SP, SP, #0xfffffffffffffff0
    //     0xd6bd00: mov             sp, SP
    //     0xd6bd04: ldr             x16, [THR, #0x740]  ; THR::LibcPow
    //     0xd6bd08: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xd6bd0c: blr             x16
    //     0xd6bd10: mov             x16, #8
    //     0xd6bd14: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xd6bd18: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xd6bd1c: sub             sp, x16, #1, lsl #12
    //     0xd6bd20: mov             SP, fp
    //     0xd6bd24: ldp             fp, lr, [SP], #0x10
    // 0xd6bd28: mov             v1.16b, v0.16b
    // 0xd6bd2c: ldur            d0, [fp, #-8]
    // 0xd6bd30: fmul            d2, d0, d1
    // 0xd6bd34: LoadField: d0 = r19->field_13
    //     0xd6bd34: ldur            d0, [x19, #0x13]
    // 0xd6bd38: fmul            d1, d2, d0
    // 0xd6bd3c: LoadField: d0 = r19->field_2b
    //     0xd6bd3c: ldur            d0, [x19, #0x2b]
    // 0xd6bd40: fsub            d2, d1, d0
    // 0xd6bd44: r0 = inline_Allocate_Double()
    //     0xd6bd44: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xd6bd48: add             x0, x0, #0x10
    //     0xd6bd4c: cmp             x1, x0
    //     0xd6bd50: b.ls            #0xd6bd7c
    //     0xd6bd54: str             x0, [THR, #0x60]  ; THR::top
    //     0xd6bd58: sub             x0, x0, #0xf
    //     0xd6bd5c: mov             x1, #0xe19c
    //     0xd6bd60: movk            x1, #3, lsl #16
    //     0xd6bd64: stur            x1, [x0, #-1]
    // 0xd6bd68: dmb             ishst
    // 0xd6bd6c: StoreField: r0->field_7 = d2
    //     0xd6bd6c: stur            d2, [x0, #7]
    // 0xd6bd70: LeaveFrame
    //     0xd6bd70: mov             SP, fp
    //     0xd6bd74: ldp             fp, lr, [SP], #0x10
    // 0xd6bd78: ret
    //     0xd6bd78: ret             
    // 0xd6bd7c: SaveReg d2
    //     0xd6bd7c: str             q2, [SP, #-0x10]!
    // 0xd6bd80: r0 = AllocateDouble()
    //     0xd6bd80: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd6bd84: RestoreReg d2
    //     0xd6bd84: ldr             q2, [SP], #0x10
    // 0xd6bd88: b               #0xd6bd6c
  }
  _ timeAtX(/* No info */) {
    // ** addr: 0x11a251c, size: 0xf4
    // 0x11a251c: EnterFrame
    //     0x11a251c: stp             fp, lr, [SP, #-0x10]!
    //     0x11a2520: mov             fp, SP
    // 0x11a2524: AllocStack(0x10)
    //     0x11a2524: sub             SP, SP, #0x10
    // 0x11a2528: SetupParameters(FrictionSimulation this /* r1 => r0, fp-0x8 */, dynamic _ /* d0 => d0, fp-0x10 */)
    //     0x11a2528: mov             x0, x1
    //     0x11a252c: stur            x1, [fp, #-8]
    //     0x11a2530: stur            d0, [fp, #-0x10]
    // 0x11a2534: CheckStackOverflow
    //     0x11a2534: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a2538: cmp             SP, x16
    //     0x11a253c: b.ls            #0x11a2608
    // 0x11a2540: LoadField: d1 = r0->field_1b
    //     0x11a2540: ldur            d1, [x0, #0x1b]
    // 0x11a2544: fcmp            d0, d1
    // 0x11a2548: b.ne            #0x11a255c
    // 0x11a254c: d0 = 0.000000
    //     0x11a254c: eor             v0.16b, v0.16b, v0.16b
    // 0x11a2550: LeaveFrame
    //     0x11a2550: mov             SP, fp
    //     0x11a2554: ldp             fp, lr, [SP], #0x10
    // 0x11a2558: ret
    //     0x11a2558: ret             
    // 0x11a255c: d2 = 0.000000
    //     0x11a255c: eor             v2.16b, v2.16b, v2.16b
    // 0x11a2560: LoadField: d3 = r0->field_23
    //     0x11a2560: ldur            d3, [x0, #0x23]
    // 0x11a2564: fcmp            d3, d2
    // 0x11a2568: b.eq            #0x11a25b8
    // 0x11a256c: fcmp            d3, d2
    // 0x11a2570: b.le            #0x11a2598
    // 0x11a2574: fcmp            d1, d0
    // 0x11a2578: b.gt            #0x11a25b8
    // 0x11a257c: mov             x1, x0
    // 0x11a2580: r0 = finalX()
    //     0x11a2580: bl              #0xd6b6f4  ; [package:flutter/src/physics/friction_simulation.dart] FrictionSimulation::finalX
    // 0x11a2584: mov             v1.16b, v0.16b
    // 0x11a2588: ldur            d0, [fp, #-0x10]
    // 0x11a258c: fcmp            d0, d1
    // 0x11a2590: b.le            #0x11a25c8
    // 0x11a2594: b               #0x11a25b8
    // 0x11a2598: fcmp            d0, d1
    // 0x11a259c: b.gt            #0x11a25b8
    // 0x11a25a0: ldur            x1, [fp, #-8]
    // 0x11a25a4: r0 = finalX()
    //     0x11a25a4: bl              #0xd6b6f4  ; [package:flutter/src/physics/friction_simulation.dart] FrictionSimulation::finalX
    // 0x11a25a8: mov             v1.16b, v0.16b
    // 0x11a25ac: ldur            d0, [fp, #-0x10]
    // 0x11a25b0: fcmp            d1, d0
    // 0x11a25b4: b.le            #0x11a25c8
    // 0x11a25b8: d0 = inf
    //     0x11a25b8: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0x11a25bc: LeaveFrame
    //     0x11a25bc: mov             SP, fp
    //     0x11a25c0: ldp             fp, lr, [SP], #0x10
    // 0x11a25c4: ret
    //     0x11a25c4: ret             
    // 0x11a25c8: ldur            x2, [fp, #-8]
    // 0x11a25cc: r1 = Function 'x':.
    //     0x11a25cc: add             x1, PP, #0xab, lsl #12  ; [pp+0xab8d0] AnonymousClosure: (0x11a2610), in [package:flutter/src/physics/friction_simulation.dart] FrictionSimulation::x (0x12f1828)
    //     0x11a25d0: ldr             x1, [x1, #0x8d0]
    // 0x11a25d4: r0 = AllocateClosure()
    //     0x11a25d4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11a25d8: ldur            x2, [fp, #-8]
    // 0x11a25dc: r1 = Function 'dx':.
    //     0x11a25dc: add             x1, PP, #0xab, lsl #12  ; [pp+0xab8d8] AnonymousClosure: (0xd6b7a4), in [package:flutter/src/physics/friction_simulation.dart] FrictionSimulation::dx (0x12dc4d8)
    //     0x11a25e0: ldr             x1, [x1, #0x8d8]
    // 0x11a25e4: stur            x0, [fp, #-8]
    // 0x11a25e8: r0 = AllocateClosure()
    //     0x11a25e8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11a25ec: mov             x1, x0
    // 0x11a25f0: ldur            x2, [fp, #-8]
    // 0x11a25f4: ldur            d0, [fp, #-0x10]
    // 0x11a25f8: r0 = _newtonsMethod()
    //     0x11a25f8: bl              #0xd6ba90  ; [package:flutter/src/physics/friction_simulation.dart] ::_newtonsMethod
    // 0x11a25fc: LeaveFrame
    //     0x11a25fc: mov             SP, fp
    //     0x11a2600: ldp             fp, lr, [SP], #0x10
    // 0x11a2604: ret
    //     0x11a2604: ret             
    // 0x11a2608: r0 = StackOverflowSharedWithFPURegs()
    //     0x11a2608: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x11a260c: b               #0x11a2540
  }
  [closure] double x(dynamic, double) {
    // ** addr: 0x11a2610, size: 0x3c
    // 0x11a2610: EnterFrame
    //     0x11a2610: stp             fp, lr, [SP, #-0x10]!
    //     0x11a2614: mov             fp, SP
    // 0x11a2618: ldr             x0, [fp, #0x18]
    // 0x11a261c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x11a261c: ldur            w1, [x0, #0x17]
    // 0x11a2620: DecompressPointer r1
    //     0x11a2620: add             x1, x1, HEAP, lsl #32
    // 0x11a2624: CheckStackOverflow
    //     0x11a2624: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a2628: cmp             SP, x16
    //     0x11a262c: b.ls            #0x11a2644
    // 0x11a2630: ldr             x2, [fp, #0x10]
    // 0x11a2634: r0 = x()
    //     0x11a2634: bl              #0x12f1828  ; [package:flutter/src/physics/friction_simulation.dart] FrictionSimulation::x
    // 0x11a2638: LeaveFrame
    //     0x11a2638: mov             SP, fp
    //     0x11a263c: ldp             fp, lr, [SP], #0x10
    // 0x11a2640: ret
    //     0x11a2640: ret             
    // 0x11a2644: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a2644: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a2648: b               #0x11a2630
  }
  _ isDone(/* No info */) {
    // ** addr: 0x12d8b30, size: 0x180
    // 0x12d8b30: EnterFrame
    //     0x12d8b30: stp             fp, lr, [SP, #-0x10]!
    //     0x12d8b34: mov             fp, SP
    // 0x12d8b38: AllocStack(0x10)
    //     0x12d8b38: sub             SP, SP, #0x10
    // 0x12d8b3c: SetupParameters(FrictionSimulation this /* r1 => r19 */, dynamic _ /* d0 => d2, fp-0x10 */)
    //     0x12d8b3c: mov             x19, x1
    //     0x12d8b40: mov             v2.16b, v0.16b
    //     0x12d8b44: stur            d0, [fp, #-0x10]
    // 0x12d8b48: LoadField: d0 = r19->field_33
    //     0x12d8b48: ldur            d0, [x19, #0x33]
    // 0x12d8b4c: fcmp            d2, d0
    // 0x12d8b50: b.le            #0x12d8b5c
    // 0x12d8b54: d1 = 0.000000
    //     0x12d8b54: eor             v1.16b, v1.16b, v1.16b
    // 0x12d8b58: b               #0x12d8c60
    // 0x12d8b5c: LoadField: d3 = r19->field_23
    //     0x12d8b5c: ldur            d3, [x19, #0x23]
    // 0x12d8b60: stur            d3, [fp, #-8]
    // 0x12d8b64: LoadField: d0 = r19->field_b
    //     0x12d8b64: ldur            d0, [x19, #0xb]
    // 0x12d8b68: mov             v1.16b, v2.16b
    // 0x12d8b6c: d30 = 0.000000
    //     0x12d8b6c: fmov            d30, d0
    // 0x12d8b70: d0 = 1.000000
    //     0x12d8b70: fmov            d0, #1.00000000
    // 0x12d8b74: fcmp            d1, #0.0
    // 0x12d8b78: b.vs            #0x12d8bbc
    // 0x12d8b7c: b.eq            #0x12d8c40
    // 0x12d8b80: fcmp            d1, d0
    // 0x12d8b84: b.eq            #0x12d8bac
    // 0x12d8b88: d31 = 2.000000
    //     0x12d8b88: fmov            d31, #2.00000000
    // 0x12d8b8c: fcmp            d1, d31
    // 0x12d8b90: b.eq            #0x12d8bb4
    // 0x12d8b94: d31 = 3.000000
    //     0x12d8b94: fmov            d31, #3.00000000
    // 0x12d8b98: fcmp            d1, d31
    // 0x12d8b9c: b.ne            #0x12d8bbc
    // 0x12d8ba0: fmul            d0, d30, d30
    // 0x12d8ba4: fmul            d0, d0, d30
    // 0x12d8ba8: b               #0x12d8c40
    // 0x12d8bac: d0 = 0.000000
    //     0x12d8bac: fmov            d0, d30
    // 0x12d8bb0: b               #0x12d8c40
    // 0x12d8bb4: fmul            d0, d30, d30
    // 0x12d8bb8: b               #0x12d8c40
    // 0x12d8bbc: fcmp            d30, d0
    // 0x12d8bc0: b.vs            #0x12d8bd0
    // 0x12d8bc4: b.eq            #0x12d8c40
    // 0x12d8bc8: fcmp            d30, d1
    // 0x12d8bcc: b.vc            #0x12d8bd8
    // 0x12d8bd0: d0 = -nan
    //     0x12d8bd0: ldr             d0, [PP, #0x24c0]  ; [pp+0x24c0] IMM: double(-nan) from 0xfff8000000000000
    // 0x12d8bd4: b               #0x12d8c40
    // 0x12d8bd8: d0 = -inf
    //     0x12d8bd8: ldr             d0, [PP, #0x5780]  ; [pp+0x5780] IMM: double(-inf) from 0xfff0000000000000
    // 0x12d8bdc: fcmp            d30, d0
    // 0x12d8be0: b.eq            #0x12d8c08
    // 0x12d8be4: d0 = 0.500000
    //     0x12d8be4: fmov            d0, #0.50000000
    // 0x12d8be8: fcmp            d1, d0
    // 0x12d8bec: b.ne            #0x12d8c08
    // 0x12d8bf0: fcmp            d30, #0.0
    // 0x12d8bf4: b.eq            #0x12d8c00
    // 0x12d8bf8: fsqrt           d0, d30
    // 0x12d8bfc: b               #0x12d8c40
    // 0x12d8c00: d0 = 0.000000
    //     0x12d8c00: eor             v0.16b, v0.16b, v0.16b
    // 0x12d8c04: b               #0x12d8c40
    // 0x12d8c08: d0 = 0.000000
    //     0x12d8c08: fmov            d0, d30
    // 0x12d8c0c: stp             fp, lr, [SP, #-0x10]!
    // 0x12d8c10: mov             fp, SP
    // 0x12d8c14: CallRuntime_LibcPow(double, double) -> double
    //     0x12d8c14: and             SP, SP, #0xfffffffffffffff0
    //     0x12d8c18: mov             sp, SP
    //     0x12d8c1c: ldr             x16, [THR, #0x740]  ; THR::LibcPow
    //     0x12d8c20: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x12d8c24: blr             x16
    //     0x12d8c28: mov             x16, #8
    //     0x12d8c2c: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x12d8c30: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x12d8c34: sub             sp, x16, #1, lsl #12
    //     0x12d8c38: mov             SP, fp
    //     0x12d8c3c: ldp             fp, lr, [SP], #0x10
    // 0x12d8c40: mov             v1.16b, v0.16b
    // 0x12d8c44: ldur            d0, [fp, #-8]
    // 0x12d8c48: fmul            d2, d0, d1
    // 0x12d8c4c: LoadField: d0 = r19->field_2b
    //     0x12d8c4c: ldur            d0, [x19, #0x2b]
    // 0x12d8c50: ldur            d1, [fp, #-0x10]
    // 0x12d8c54: fmul            d3, d0, d1
    // 0x12d8c58: fsub            d0, d2, d3
    // 0x12d8c5c: mov             v1.16b, v0.16b
    // 0x12d8c60: d0 = 0.000000
    //     0x12d8c60: eor             v0.16b, v0.16b, v0.16b
    // 0x12d8c64: fcmp            d1, d0
    // 0x12d8c68: b.ne            #0x12d8c74
    // 0x12d8c6c: d0 = 0.000000
    //     0x12d8c6c: eor             v0.16b, v0.16b, v0.16b
    // 0x12d8c70: b               #0x12d8c88
    // 0x12d8c74: fcmp            d0, d1
    // 0x12d8c78: b.le            #0x12d8c84
    // 0x12d8c7c: fneg            d0, d1
    // 0x12d8c80: b               #0x12d8c88
    // 0x12d8c84: mov             v0.16b, v1.16b
    // 0x12d8c88: LoadField: r1 = r19->field_7
    //     0x12d8c88: ldur            w1, [x19, #7]
    // 0x12d8c8c: DecompressPointer r1
    //     0x12d8c8c: add             x1, x1, HEAP, lsl #32
    // 0x12d8c90: ArrayLoad: d1 = r1[0]  ; List_8
    //     0x12d8c90: ldur            d1, [x1, #0x17]
    // 0x12d8c94: fcmp            d1, d0
    // 0x12d8c98: r16 = true
    //     0x12d8c98: add             x16, NULL, #0x20  ; true
    // 0x12d8c9c: r17 = false
    //     0x12d8c9c: add             x17, NULL, #0x30  ; false
    // 0x12d8ca0: csel            x0, x16, x17, gt
    // 0x12d8ca4: LeaveFrame
    //     0x12d8ca4: mov             SP, fp
    //     0x12d8ca8: ldp             fp, lr, [SP], #0x10
    // 0x12d8cac: ret
    //     0x12d8cac: ret             
  }
  _ dx(/* No info */) {
    // ** addr: 0x12dc4d8, size: 0x13c
    // 0x12dc4d8: EnterFrame
    //     0x12dc4d8: stp             fp, lr, [SP, #-0x10]!
    //     0x12dc4dc: mov             fp, SP
    // 0x12dc4e0: AllocStack(0x10)
    //     0x12dc4e0: sub             SP, SP, #0x10
    // 0x12dc4e4: SetupParameters(FrictionSimulation this /* r1 => r19 */)
    //     0x12dc4e4: mov             x19, x1
    // 0x12dc4e8: LoadField: d0 = r19->field_33
    //     0x12dc4e8: ldur            d0, [x19, #0x33]
    // 0x12dc4ec: LoadField: d2 = r2->field_7
    //     0x12dc4ec: ldur            d2, [x2, #7]
    // 0x12dc4f0: stur            d2, [fp, #-0x10]
    // 0x12dc4f4: fcmp            d2, d0
    // 0x12dc4f8: b.le            #0x12dc50c
    // 0x12dc4fc: d0 = 0.000000
    //     0x12dc4fc: eor             v0.16b, v0.16b, v0.16b
    // 0x12dc500: LeaveFrame
    //     0x12dc500: mov             SP, fp
    //     0x12dc504: ldp             fp, lr, [SP], #0x10
    // 0x12dc508: ret
    //     0x12dc508: ret             
    // 0x12dc50c: LoadField: d3 = r19->field_23
    //     0x12dc50c: ldur            d3, [x19, #0x23]
    // 0x12dc510: stur            d3, [fp, #-8]
    // 0x12dc514: LoadField: d0 = r19->field_b
    //     0x12dc514: ldur            d0, [x19, #0xb]
    // 0x12dc518: mov             v1.16b, v2.16b
    // 0x12dc51c: d30 = 0.000000
    //     0x12dc51c: fmov            d30, d0
    // 0x12dc520: d0 = 1.000000
    //     0x12dc520: fmov            d0, #1.00000000
    // 0x12dc524: fcmp            d1, #0.0
    // 0x12dc528: b.vs            #0x12dc56c
    // 0x12dc52c: b.eq            #0x12dc5f0
    // 0x12dc530: fcmp            d1, d0
    // 0x12dc534: b.eq            #0x12dc55c
    // 0x12dc538: d31 = 2.000000
    //     0x12dc538: fmov            d31, #2.00000000
    // 0x12dc53c: fcmp            d1, d31
    // 0x12dc540: b.eq            #0x12dc564
    // 0x12dc544: d31 = 3.000000
    //     0x12dc544: fmov            d31, #3.00000000
    // 0x12dc548: fcmp            d1, d31
    // 0x12dc54c: b.ne            #0x12dc56c
    // 0x12dc550: fmul            d0, d30, d30
    // 0x12dc554: fmul            d0, d0, d30
    // 0x12dc558: b               #0x12dc5f0
    // 0x12dc55c: d0 = 0.000000
    //     0x12dc55c: fmov            d0, d30
    // 0x12dc560: b               #0x12dc5f0
    // 0x12dc564: fmul            d0, d30, d30
    // 0x12dc568: b               #0x12dc5f0
    // 0x12dc56c: fcmp            d30, d0
    // 0x12dc570: b.vs            #0x12dc580
    // 0x12dc574: b.eq            #0x12dc5f0
    // 0x12dc578: fcmp            d30, d1
    // 0x12dc57c: b.vc            #0x12dc588
    // 0x12dc580: d0 = -nan
    //     0x12dc580: ldr             d0, [PP, #0x24c0]  ; [pp+0x24c0] IMM: double(-nan) from 0xfff8000000000000
    // 0x12dc584: b               #0x12dc5f0
    // 0x12dc588: d0 = -inf
    //     0x12dc588: ldr             d0, [PP, #0x5780]  ; [pp+0x5780] IMM: double(-inf) from 0xfff0000000000000
    // 0x12dc58c: fcmp            d30, d0
    // 0x12dc590: b.eq            #0x12dc5b8
    // 0x12dc594: d0 = 0.500000
    //     0x12dc594: fmov            d0, #0.50000000
    // 0x12dc598: fcmp            d1, d0
    // 0x12dc59c: b.ne            #0x12dc5b8
    // 0x12dc5a0: fcmp            d30, #0.0
    // 0x12dc5a4: b.eq            #0x12dc5b0
    // 0x12dc5a8: fsqrt           d0, d30
    // 0x12dc5ac: b               #0x12dc5f0
    // 0x12dc5b0: d0 = 0.000000
    //     0x12dc5b0: eor             v0.16b, v0.16b, v0.16b
    // 0x12dc5b4: b               #0x12dc5f0
    // 0x12dc5b8: d0 = 0.000000
    //     0x12dc5b8: fmov            d0, d30
    // 0x12dc5bc: stp             fp, lr, [SP, #-0x10]!
    // 0x12dc5c0: mov             fp, SP
    // 0x12dc5c4: CallRuntime_LibcPow(double, double) -> double
    //     0x12dc5c4: and             SP, SP, #0xfffffffffffffff0
    //     0x12dc5c8: mov             sp, SP
    //     0x12dc5cc: ldr             x16, [THR, #0x740]  ; THR::LibcPow
    //     0x12dc5d0: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x12dc5d4: blr             x16
    //     0x12dc5d8: mov             x16, #8
    //     0x12dc5dc: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x12dc5e0: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x12dc5e4: sub             sp, x16, #1, lsl #12
    //     0x12dc5e8: mov             SP, fp
    //     0x12dc5ec: ldp             fp, lr, [SP], #0x10
    // 0x12dc5f0: ldur            d1, [fp, #-8]
    // 0x12dc5f4: fmul            d2, d1, d0
    // 0x12dc5f8: LoadField: d1 = r19->field_2b
    //     0x12dc5f8: ldur            d1, [x19, #0x2b]
    // 0x12dc5fc: ldur            d3, [fp, #-0x10]
    // 0x12dc600: fmul            d4, d1, d3
    // 0x12dc604: fsub            d0, d2, d4
    // 0x12dc608: LeaveFrame
    //     0x12dc608: mov             SP, fp
    //     0x12dc60c: ldp             fp, lr, [SP], #0x10
    // 0x12dc610: ret
    //     0x12dc610: ret             
  }
  _ x(/* No info */) {
    // ** addr: 0x12f1828, size: 0x1fc
    // 0x12f1828: EnterFrame
    //     0x12f1828: stp             fp, lr, [SP, #-0x10]!
    //     0x12f182c: mov             fp, SP
    // 0x12f1830: AllocStack(0x18)
    //     0x12f1830: sub             SP, SP, #0x18
    // 0x12f1834: SetupParameters(FrictionSimulation this /* r1 => r19 */)
    //     0x12f1834: mov             x19, x1
    // 0x12f1838: CheckStackOverflow
    //     0x12f1838: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f183c: cmp             SP, x16
    //     0x12f1840: b.ls            #0x12f19fc
    // 0x12f1844: LoadField: d0 = r19->field_33
    //     0x12f1844: ldur            d0, [x19, #0x33]
    // 0x12f1848: LoadField: d2 = r2->field_7
    //     0x12f1848: ldur            d2, [x2, #7]
    // 0x12f184c: stur            d2, [fp, #-0x18]
    // 0x12f1850: fcmp            d2, d0
    // 0x12f1854: b.le            #0x12f1898
    // 0x12f1858: mov             x1, x19
    // 0x12f185c: r0 = finalX()
    //     0x12f185c: bl              #0xd6b6f4  ; [package:flutter/src/physics/friction_simulation.dart] FrictionSimulation::finalX
    // 0x12f1860: r0 = inline_Allocate_Double()
    //     0x12f1860: ldp             x0, x20, [THR, #0x60]  ; THR::top
    //     0x12f1864: add             x0, x0, #0x10
    //     0x12f1868: cmp             x20, x0
    //     0x12f186c: b.ls            #0x12f1a04
    //     0x12f1870: str             x0, [THR, #0x60]  ; THR::top
    //     0x12f1874: sub             x0, x0, #0xf
    //     0x12f1878: mov             x20, #0xe19c
    //     0x12f187c: movk            x20, #3, lsl #16
    //     0x12f1880: stur            x20, [x0, #-1]
    // 0x12f1884: dmb             ishst
    // 0x12f1888: StoreField: r0->field_7 = d0
    //     0x12f1888: stur            d0, [x0, #7]
    // 0x12f188c: LeaveFrame
    //     0x12f188c: mov             SP, fp
    //     0x12f1890: ldp             fp, lr, [SP], #0x10
    // 0x12f1894: ret
    //     0x12f1894: ret             
    // 0x12f1898: LoadField: d3 = r19->field_1b
    //     0x12f1898: ldur            d3, [x19, #0x1b]
    // 0x12f189c: stur            d3, [fp, #-0x10]
    // 0x12f18a0: LoadField: d4 = r19->field_23
    //     0x12f18a0: ldur            d4, [x19, #0x23]
    // 0x12f18a4: stur            d4, [fp, #-8]
    // 0x12f18a8: LoadField: d0 = r19->field_b
    //     0x12f18a8: ldur            d0, [x19, #0xb]
    // 0x12f18ac: mov             v1.16b, v2.16b
    // 0x12f18b0: d30 = 0.000000
    //     0x12f18b0: fmov            d30, d0
    // 0x12f18b4: d0 = 1.000000
    //     0x12f18b4: fmov            d0, #1.00000000
    // 0x12f18b8: fcmp            d1, #0.0
    // 0x12f18bc: b.vs            #0x12f1900
    // 0x12f18c0: b.eq            #0x12f1984
    // 0x12f18c4: fcmp            d1, d0
    // 0x12f18c8: b.eq            #0x12f18f0
    // 0x12f18cc: d31 = 2.000000
    //     0x12f18cc: fmov            d31, #2.00000000
    // 0x12f18d0: fcmp            d1, d31
    // 0x12f18d4: b.eq            #0x12f18f8
    // 0x12f18d8: d31 = 3.000000
    //     0x12f18d8: fmov            d31, #3.00000000
    // 0x12f18dc: fcmp            d1, d31
    // 0x12f18e0: b.ne            #0x12f1900
    // 0x12f18e4: fmul            d0, d30, d30
    // 0x12f18e8: fmul            d0, d0, d30
    // 0x12f18ec: b               #0x12f1984
    // 0x12f18f0: d0 = 0.000000
    //     0x12f18f0: fmov            d0, d30
    // 0x12f18f4: b               #0x12f1984
    // 0x12f18f8: fmul            d0, d30, d30
    // 0x12f18fc: b               #0x12f1984
    // 0x12f1900: fcmp            d30, d0
    // 0x12f1904: b.vs            #0x12f1914
    // 0x12f1908: b.eq            #0x12f1984
    // 0x12f190c: fcmp            d30, d1
    // 0x12f1910: b.vc            #0x12f191c
    // 0x12f1914: d0 = -nan
    //     0x12f1914: ldr             d0, [PP, #0x24c0]  ; [pp+0x24c0] IMM: double(-nan) from 0xfff8000000000000
    // 0x12f1918: b               #0x12f1984
    // 0x12f191c: d0 = -inf
    //     0x12f191c: ldr             d0, [PP, #0x5780]  ; [pp+0x5780] IMM: double(-inf) from 0xfff0000000000000
    // 0x12f1920: fcmp            d30, d0
    // 0x12f1924: b.eq            #0x12f194c
    // 0x12f1928: d0 = 0.500000
    //     0x12f1928: fmov            d0, #0.50000000
    // 0x12f192c: fcmp            d1, d0
    // 0x12f1930: b.ne            #0x12f194c
    // 0x12f1934: fcmp            d30, #0.0
    // 0x12f1938: b.eq            #0x12f1944
    // 0x12f193c: fsqrt           d0, d30
    // 0x12f1940: b               #0x12f1984
    // 0x12f1944: d0 = 0.000000
    //     0x12f1944: eor             v0.16b, v0.16b, v0.16b
    // 0x12f1948: b               #0x12f1984
    // 0x12f194c: d0 = 0.000000
    //     0x12f194c: fmov            d0, d30
    // 0x12f1950: stp             fp, lr, [SP, #-0x10]!
    // 0x12f1954: mov             fp, SP
    // 0x12f1958: CallRuntime_LibcPow(double, double) -> double
    //     0x12f1958: and             SP, SP, #0xfffffffffffffff0
    //     0x12f195c: mov             sp, SP
    //     0x12f1960: ldr             x16, [THR, #0x740]  ; THR::LibcPow
    //     0x12f1964: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x12f1968: blr             x16
    //     0x12f196c: mov             x16, #8
    //     0x12f1970: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x12f1974: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x12f1978: sub             sp, x16, #1, lsl #12
    //     0x12f197c: mov             SP, fp
    //     0x12f1980: ldp             fp, lr, [SP], #0x10
    // 0x12f1984: mov             v1.16b, v0.16b
    // 0x12f1988: ldur            d0, [fp, #-8]
    // 0x12f198c: fmul            d2, d0, d1
    // 0x12f1990: LoadField: d1 = r19->field_13
    //     0x12f1990: ldur            d1, [x19, #0x13]
    // 0x12f1994: fdiv            d3, d2, d1
    // 0x12f1998: ldur            d2, [fp, #-0x10]
    // 0x12f199c: fadd            d4, d2, d3
    // 0x12f19a0: fdiv            d2, d0, d1
    // 0x12f19a4: fsub            d0, d4, d2
    // 0x12f19a8: LoadField: d1 = r19->field_2b
    //     0x12f19a8: ldur            d1, [x19, #0x2b]
    // 0x12f19ac: d2 = 2.000000
    //     0x12f19ac: fmov            d2, #2.00000000
    // 0x12f19b0: fdiv            d3, d1, d2
    // 0x12f19b4: ldur            d1, [fp, #-0x18]
    // 0x12f19b8: fmul            d2, d3, d1
    // 0x12f19bc: fmul            d3, d2, d1
    // 0x12f19c0: fsub            d1, d0, d3
    // 0x12f19c4: r0 = inline_Allocate_Double()
    //     0x12f19c4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x12f19c8: add             x0, x0, #0x10
    //     0x12f19cc: cmp             x1, x0
    //     0x12f19d0: b.ls            #0x12f1a14
    //     0x12f19d4: str             x0, [THR, #0x60]  ; THR::top
    //     0x12f19d8: sub             x0, x0, #0xf
    //     0x12f19dc: mov             x1, #0xe19c
    //     0x12f19e0: movk            x1, #3, lsl #16
    //     0x12f19e4: stur            x1, [x0, #-1]
    // 0x12f19e8: dmb             ishst
    // 0x12f19ec: StoreField: r0->field_7 = d1
    //     0x12f19ec: stur            d1, [x0, #7]
    // 0x12f19f0: LeaveFrame
    //     0x12f19f0: mov             SP, fp
    //     0x12f19f4: ldp             fp, lr, [SP], #0x10
    // 0x12f19f8: ret
    //     0x12f19f8: ret             
    // 0x12f19fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f19fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f1a00: b               #0x12f1844
    // 0x12f1a04: SaveReg d0
    //     0x12f1a04: str             q0, [SP, #-0x10]!
    // 0x12f1a08: r0 = AllocateDouble()
    //     0x12f1a08: bl              #0x13df878  ; AllocateDoubleStub
    // 0x12f1a0c: RestoreReg d0
    //     0x12f1a0c: ldr             q0, [SP], #0x10
    // 0x12f1a10: b               #0x12f1888
    // 0x12f1a14: SaveReg d1
    //     0x12f1a14: str             q1, [SP, #-0x10]!
    // 0x12f1a18: r0 = AllocateDouble()
    //     0x12f1a18: bl              #0x13df878  ; AllocateDoubleStub
    // 0x12f1a1c: RestoreReg d1
    //     0x12f1a1c: ldr             q1, [SP], #0x10
    // 0x12f1a20: b               #0x12f19ec
  }
}
