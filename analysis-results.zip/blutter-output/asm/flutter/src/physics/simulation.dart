// lib: , url: package:flutter/src/physics/simulation.dart

// class id: 1049015, size: 0x8
class :: {
}

// class id: 3335, size: 0xc, field offset: 0x8
abstract class Simulation extends Object {
}
