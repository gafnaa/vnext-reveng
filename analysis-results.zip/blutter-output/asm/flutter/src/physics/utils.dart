// lib: , url: package:flutter/src/physics/utils.dart

// class id: 1049018, size: 0x8
class :: {

  static _ nearEqual(/* No info */) {
    // ** addr: 0x1286fdc, size: 0xd8
    // 0x1286fdc: EnterFrame
    //     0x1286fdc: stp             fp, lr, [SP, #-0x10]!
    //     0x1286fe0: mov             fp, SP
    // 0x1286fe4: AllocStack(0x10)
    //     0x1286fe4: sub             SP, SP, #0x10
    // 0x1286fe8: CheckStackOverflow
    //     0x1286fe8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1286fec: cmp             SP, x16
    //     0x1286ff0: b.ls            #0x1287094
    // 0x1286ff4: cmp             w1, NULL
    // 0x1286ff8: b.ne            #0x1287050
    // 0x1286ffc: r0 = inline_Allocate_Double()
    //     0x1286ffc: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x1287000: add             x0, x0, #0x10
    //     0x1287004: cmp             x2, x0
    //     0x1287008: b.ls            #0x128709c
    //     0x128700c: str             x0, [THR, #0x60]  ; THR::top
    //     0x1287010: sub             x0, x0, #0xf
    //     0x1287014: mov             x2, #0xe19c
    //     0x1287018: movk            x2, #3, lsl #16
    //     0x128701c: stur            x2, [x0, #-1]
    // 0x1287020: dmb             ishst
    // 0x1287024: StoreField: r0->field_7 = d0
    //     0x1287024: stur            d0, [x0, #7]
    // 0x1287028: r2 = LoadClassIdInstr(r1)
    //     0x1287028: ldur            x2, [x1, #-1]
    //     0x128702c: ubfx            x2, x2, #0xc, #0x14
    // 0x1287030: stp             x0, x1, [SP]
    // 0x1287034: mov             x0, x2
    // 0x1287038: mov             lr, x0
    // 0x128703c: ldr             lr, [x21, lr, lsl #3]
    // 0x1287040: blr             lr
    // 0x1287044: LeaveFrame
    //     0x1287044: mov             SP, fp
    //     0x1287048: ldp             fp, lr, [SP], #0x10
    // 0x128704c: ret
    //     0x128704c: ret             
    // 0x1287050: fsub            d2, d0, d1
    // 0x1287054: LoadField: d3 = r1->field_7
    //     0x1287054: ldur            d3, [x1, #7]
    // 0x1287058: fcmp            d3, d2
    // 0x128705c: b.le            #0x1287074
    // 0x1287060: fadd            d2, d0, d1
    // 0x1287064: fcmp            d2, d3
    // 0x1287068: b.le            #0x1287074
    // 0x128706c: r0 = true
    //     0x128706c: add             x0, NULL, #0x20  ; true
    // 0x1287070: b               #0x1287088
    // 0x1287074: fcmp            d3, d0
    // 0x1287078: r16 = true
    //     0x1287078: add             x16, NULL, #0x20  ; true
    // 0x128707c: r17 = false
    //     0x128707c: add             x17, NULL, #0x30  ; false
    // 0x1287080: csel            x1, x16, x17, eq
    // 0x1287084: mov             x0, x1
    // 0x1287088: LeaveFrame
    //     0x1287088: mov             SP, fp
    //     0x128708c: ldp             fp, lr, [SP], #0x10
    // 0x1287090: ret
    //     0x1287090: ret             
    // 0x1287094: r0 = StackOverflowSharedWithFPURegs()
    //     0x1287094: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1287098: b               #0x1286ff4
    // 0x128709c: SaveReg d0
    //     0x128709c: str             q0, [SP, #-0x10]!
    // 0x12870a0: SaveReg r1
    //     0x12870a0: str             x1, [SP, #-8]!
    // 0x12870a4: r0 = AllocateDouble()
    //     0x12870a4: bl              #0x13df878  ; AllocateDoubleStub
    // 0x12870a8: RestoreReg r1
    //     0x12870a8: ldr             x1, [SP], #8
    // 0x12870ac: RestoreReg d0
    //     0x12870ac: ldr             q0, [SP], #0x10
    // 0x12870b0: b               #0x1287024
  }
  static _ nearZero(/* No info */) {
    // ** addr: 0x12d8db0, size: 0x3c
    // 0x12d8db0: d2 = 0.000000
    //     0x12d8db0: eor             v2.16b, v2.16b, v2.16b
    // 0x12d8db4: fsub            d3, d2, d1
    // 0x12d8db8: fcmp            d0, d3
    // 0x12d8dbc: b.le            #0x12d8dd4
    // 0x12d8dc0: fadd            d3, d1, d2
    // 0x12d8dc4: fcmp            d3, d0
    // 0x12d8dc8: b.le            #0x12d8dd4
    // 0x12d8dcc: r0 = true
    //     0x12d8dcc: add             x0, NULL, #0x20  ; true
    // 0x12d8dd0: b               #0x12d8de8
    // 0x12d8dd4: fcmp            d0, d2
    // 0x12d8dd8: r16 = true
    //     0x12d8dd8: add             x16, NULL, #0x20  ; true
    // 0x12d8ddc: r17 = false
    //     0x12d8ddc: add             x17, NULL, #0x30  ; false
    // 0x12d8de0: csel            x1, x16, x17, eq
    // 0x12d8de4: mov             x0, x1
    // 0x12d8de8: ret
    //     0x12d8de8: ret             
  }
}
