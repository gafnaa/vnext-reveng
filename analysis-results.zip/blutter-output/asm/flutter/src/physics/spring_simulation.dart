// lib: , url: package:flutter/src/physics/spring_simulation.dart

// class id: 1049016, size: 0x8
class :: {
}

// class id: 2890, size: 0x28, field offset: 0x8
class _UnderdampedSolution extends Object
    implements _SpringSolution {

  dynamic dx(dynamic) {
    // ** addr: 0xb35634, size: 0x3c
    // 0xb35634: EnterFrame
    //     0xb35634: stp             fp, lr, [SP, #-0x10]!
    //     0xb35638: mov             fp, SP
    // 0xb3563c: ldr             x2, [fp, #0x10]
    // 0xb35640: r1 = Function 'dx':.
    //     0xb35640: add             x1, PP, #0xcf, lsl #12  ; [pp+0xcf9a0] AnonymousClosure: (0xb35658), in [package:flutter/src/physics/spring_simulation.dart] _UnderdampedSolution::dx (0x1307fd4)
    //     0xb35644: ldr             x1, [x1, #0x9a0]
    // 0xb35648: r0 = AllocateClosure()
    //     0xb35648: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb3564c: LeaveFrame
    //     0xb3564c: mov             SP, fp
    //     0xb35650: ldp             fp, lr, [SP], #0x10
    // 0xb35654: ret
    //     0xb35654: ret             
  }
  factory _ _UnderdampedSolution(/* No info */) {
    // ** addr: 0xb35588, size: 0x94
    // 0xb35588: EnterFrame
    //     0xb35588: stp             fp, lr, [SP, #-0x10]!
    //     0xb3558c: mov             fp, SP
    // 0xb35590: AllocStack(0x20)
    //     0xb35590: sub             SP, SP, #0x20
    // 0xb35594: d3 = 4.000000
    //     0xb35594: fmov            d3, #4.00000000
    // 0xb35598: d2 = 2.000000
    //     0xb35598: fmov            d2, #2.00000000
    // 0xb3559c: stur            d0, [fp, #-0x20]
    // 0xb355a0: LoadField: d4 = r2->field_7
    //     0xb355a0: ldur            d4, [x2, #7]
    // 0xb355a4: fmul            d5, d4, d3
    // 0xb355a8: LoadField: d3 = r2->field_f
    //     0xb355a8: ldur            d3, [x2, #0xf]
    // 0xb355ac: fmul            d6, d5, d3
    // 0xb355b0: ArrayLoad: d3 = r2[0]  ; List_8
    //     0xb355b0: ldur            d3, [x2, #0x17]
    // 0xb355b4: fmul            d5, d3, d3
    // 0xb355b8: fsub            d7, d6, d5
    // 0xb355bc: fsqrt           d5, d7
    // 0xb355c0: fmul            d6, d4, d2
    // 0xb355c4: fdiv            d7, d5, d6
    // 0xb355c8: stur            d7, [fp, #-0x18]
    // 0xb355cc: fdiv            d5, d3, d2
    // 0xb355d0: fdiv            d2, d5, d4
    // 0xb355d4: fneg            d3, d2
    // 0xb355d8: stur            d3, [fp, #-0x10]
    // 0xb355dc: fmul            d2, d3, d0
    // 0xb355e0: fsub            d4, d1, d2
    // 0xb355e4: fdiv            d1, d4, d7
    // 0xb355e8: stur            d1, [fp, #-8]
    // 0xb355ec: r0 = _UnderdampedSolution()
    //     0xb355ec: bl              #0xb35888  ; Allocate_UnderdampedSolutionStub -> _UnderdampedSolution (size=0x28)
    // 0xb355f0: ldur            d0, [fp, #-0x18]
    // 0xb355f4: StoreField: r0->field_7 = d0
    //     0xb355f4: stur            d0, [x0, #7]
    // 0xb355f8: ldur            d0, [fp, #-0x10]
    // 0xb355fc: StoreField: r0->field_f = d0
    //     0xb355fc: stur            d0, [x0, #0xf]
    // 0xb35600: ldur            d0, [fp, #-0x20]
    // 0xb35604: ArrayStore: r0[0] = d0  ; List_8
    //     0xb35604: stur            d0, [x0, #0x17]
    // 0xb35608: ldur            d0, [fp, #-8]
    // 0xb3560c: StoreField: r0->field_1f = d0
    //     0xb3560c: stur            d0, [x0, #0x1f]
    // 0xb35610: LeaveFrame
    //     0xb35610: mov             SP, fp
    //     0xb35614: ldp             fp, lr, [SP], #0x10
    // 0xb35618: ret
    //     0xb35618: ret             
  }
  [closure] double dx(dynamic, double) {
    // ** addr: 0xb35658, size: 0x230
    // 0xb35658: EnterFrame
    //     0xb35658: stp             fp, lr, [SP, #-0x10]!
    //     0xb3565c: mov             fp, SP
    // 0xb35660: AllocStack(0x28)
    //     0xb35660: sub             SP, SP, #0x28
    // 0xb35664: SetupParameters([dynamic _ /* r19 */])
    //     0xb35664: ldr             x19, [fp, #0x18]
    //     0xb35668: ldur            w20, [x19, #0x17]
    //     0xb3566c: add             x20, x20, HEAP, lsl #32
    // 0xb35670: LoadField: d2 = r20->field_f
    //     0xb35670: ldur            d2, [x20, #0xf]
    // 0xb35674: ldr             x19, [fp, #0x10]
    // 0xb35678: stur            d2, [fp, #-0x10]
    // 0xb3567c: LoadField: d3 = r19->field_7
    //     0xb3567c: ldur            d3, [x19, #7]
    // 0xb35680: stur            d3, [fp, #-8]
    // 0xb35684: fmul            d1, d2, d3
    // 0xb35688: d0 = 2.718282
    //     0xb35688: add             x17, PP, #0x96, lsl #12  ; [pp+0x96068] IMM: double(2.718281828459045) from 0x4005bf0a8b145769
    //     0xb3568c: ldr             d0, [x17, #0x68]
    // 0xb35690: d30 = 0.000000
    //     0xb35690: fmov            d30, d0
    // 0xb35694: d0 = 1.000000
    //     0xb35694: fmov            d0, #1.00000000
    // 0xb35698: fcmp            d1, #0.0
    // 0xb3569c: b.vs            #0xb356e0
    // 0xb356a0: b.eq            #0xb35764
    // 0xb356a4: fcmp            d1, d0
    // 0xb356a8: b.eq            #0xb356d0
    // 0xb356ac: d31 = 2.000000
    //     0xb356ac: fmov            d31, #2.00000000
    // 0xb356b0: fcmp            d1, d31
    // 0xb356b4: b.eq            #0xb356d8
    // 0xb356b8: d31 = 3.000000
    //     0xb356b8: fmov            d31, #3.00000000
    // 0xb356bc: fcmp            d1, d31
    // 0xb356c0: b.ne            #0xb356e0
    // 0xb356c4: fmul            d0, d30, d30
    // 0xb356c8: fmul            d0, d0, d30
    // 0xb356cc: b               #0xb35764
    // 0xb356d0: d0 = 0.000000
    //     0xb356d0: fmov            d0, d30
    // 0xb356d4: b               #0xb35764
    // 0xb356d8: fmul            d0, d30, d30
    // 0xb356dc: b               #0xb35764
    // 0xb356e0: fcmp            d30, d0
    // 0xb356e4: b.vs            #0xb356f4
    // 0xb356e8: b.eq            #0xb35764
    // 0xb356ec: fcmp            d30, d1
    // 0xb356f0: b.vc            #0xb356fc
    // 0xb356f4: d0 = -nan
    //     0xb356f4: ldr             d0, [PP, #0x24c0]  ; [pp+0x24c0] IMM: double(-nan) from 0xfff8000000000000
    // 0xb356f8: b               #0xb35764
    // 0xb356fc: d0 = -inf
    //     0xb356fc: ldr             d0, [PP, #0x5780]  ; [pp+0x5780] IMM: double(-inf) from 0xfff0000000000000
    // 0xb35700: fcmp            d30, d0
    // 0xb35704: b.eq            #0xb3572c
    // 0xb35708: d0 = 0.500000
    //     0xb35708: fmov            d0, #0.50000000
    // 0xb3570c: fcmp            d1, d0
    // 0xb35710: b.ne            #0xb3572c
    // 0xb35714: fcmp            d30, #0.0
    // 0xb35718: b.eq            #0xb35724
    // 0xb3571c: fsqrt           d0, d30
    // 0xb35720: b               #0xb35764
    // 0xb35724: d0 = 0.000000
    //     0xb35724: eor             v0.16b, v0.16b, v0.16b
    // 0xb35728: b               #0xb35764
    // 0xb3572c: d0 = 0.000000
    //     0xb3572c: fmov            d0, d30
    // 0xb35730: stp             fp, lr, [SP, #-0x10]!
    // 0xb35734: mov             fp, SP
    // 0xb35738: CallRuntime_LibcPow(double, double) -> double
    //     0xb35738: and             SP, SP, #0xfffffffffffffff0
    //     0xb3573c: mov             sp, SP
    //     0xb35740: ldr             x16, [THR, #0x740]  ; THR::LibcPow
    //     0xb35744: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xb35748: blr             x16
    //     0xb3574c: mov             x16, #8
    //     0xb35750: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xb35754: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xb35758: sub             sp, x16, #1, lsl #12
    //     0xb3575c: mov             SP, fp
    //     0xb35760: ldp             fp, lr, [SP], #0x10
    // 0xb35764: mov             v1.16b, v0.16b
    // 0xb35768: stur            d1, [fp, #-0x28]
    // 0xb3576c: LoadField: d2 = r20->field_7
    //     0xb3576c: ldur            d2, [x20, #7]
    // 0xb35770: ldur            d0, [fp, #-8]
    // 0xb35774: stur            d2, [fp, #-0x20]
    // 0xb35778: fmul            d3, d2, d0
    // 0xb3577c: mov             v0.16b, v3.16b
    // 0xb35780: stur            d3, [fp, #-0x18]
    // 0xb35784: stp             fp, lr, [SP, #-0x10]!
    // 0xb35788: mov             fp, SP
    // 0xb3578c: CallRuntime_LibcCos(double) -> double
    //     0xb3578c: and             SP, SP, #0xfffffffffffffff0
    //     0xb35790: mov             sp, SP
    //     0xb35794: ldr             x16, [THR, #0x778]  ; THR::LibcCos
    //     0xb35798: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xb3579c: blr             x16
    //     0xb357a0: mov             x16, #8
    //     0xb357a4: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xb357a8: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xb357ac: sub             sp, x16, #1, lsl #12
    //     0xb357b0: mov             SP, fp
    //     0xb357b4: ldp             fp, lr, [SP], #0x10
    // 0xb357b8: mov             v1.16b, v0.16b
    // 0xb357bc: ldur            d0, [fp, #-0x18]
    // 0xb357c0: stur            d1, [fp, #-8]
    // 0xb357c4: stp             fp, lr, [SP, #-0x10]!
    // 0xb357c8: mov             fp, SP
    // 0xb357cc: CallRuntime_LibcSin(double) -> double
    //     0xb357cc: and             SP, SP, #0xfffffffffffffff0
    //     0xb357d0: mov             sp, SP
    //     0xb357d4: ldr             x16, [THR, #0x780]  ; THR::LibcSin
    //     0xb357d8: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xb357dc: blr             x16
    //     0xb357e0: mov             x16, #8
    //     0xb357e4: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xb357e8: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xb357ec: sub             sp, x16, #1, lsl #12
    //     0xb357f0: mov             SP, fp
    //     0xb357f4: ldp             fp, lr, [SP], #0x10
    // 0xb357f8: LoadField: d1 = r20->field_1f
    //     0xb357f8: ldur            d1, [x20, #0x1f]
    // 0xb357fc: ldur            d2, [fp, #-0x20]
    // 0xb35800: fmul            d3, d1, d2
    // 0xb35804: ldur            d4, [fp, #-8]
    // 0xb35808: fmul            d5, d3, d4
    // 0xb3580c: ArrayLoad: d3 = r20[0]  ; List_8
    //     0xb3580c: ldur            d3, [x20, #0x17]
    // 0xb35810: fmul            d6, d3, d2
    // 0xb35814: fmul            d2, d6, d0
    // 0xb35818: fsub            d6, d5, d2
    // 0xb3581c: ldur            d2, [fp, #-0x28]
    // 0xb35820: fmul            d5, d2, d6
    // 0xb35824: ldur            d6, [fp, #-0x10]
    // 0xb35828: fmul            d7, d6, d2
    // 0xb3582c: fmul            d2, d1, d0
    // 0xb35830: fmul            d0, d3, d4
    // 0xb35834: fadd            d1, d2, d0
    // 0xb35838: fmul            d0, d7, d1
    // 0xb3583c: fadd            d1, d5, d0
    // 0xb35840: r0 = inline_Allocate_Double()
    //     0xb35840: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb35844: add             x0, x0, #0x10
    //     0xb35848: cmp             x1, x0
    //     0xb3584c: b.ls            #0xb35878
    //     0xb35850: str             x0, [THR, #0x60]  ; THR::top
    //     0xb35854: sub             x0, x0, #0xf
    //     0xb35858: mov             x1, #0xe19c
    //     0xb3585c: movk            x1, #3, lsl #16
    //     0xb35860: stur            x1, [x0, #-1]
    // 0xb35864: dmb             ishst
    // 0xb35868: StoreField: r0->field_7 = d1
    //     0xb35868: stur            d1, [x0, #7]
    // 0xb3586c: LeaveFrame
    //     0xb3586c: mov             SP, fp
    //     0xb35870: ldp             fp, lr, [SP], #0x10
    // 0xb35874: ret
    //     0xb35874: ret             
    // 0xb35878: SaveReg d1
    //     0xb35878: str             q1, [SP, #-0x10]!
    // 0xb3587c: r0 = AllocateDouble()
    //     0xb3587c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb35880: RestoreReg d1
    //     0xb35880: ldr             q1, [SP], #0x10
    // 0xb35884: b               #0xb35868
  }
  _ x(/* No info */) {
    // ** addr: 0x1307240, size: 0x1c8
    // 0x1307240: EnterFrame
    //     0x1307240: stp             fp, lr, [SP, #-0x10]!
    //     0x1307244: mov             fp, SP
    // 0x1307248: AllocStack(0x28)
    //     0x1307248: sub             SP, SP, #0x28
    // 0x130724c: SetupParameters(_UnderdampedSolution this /* r1 => r19 */, dynamic _ /* d0 => d2, fp-0x8 */)
    //     0x130724c: mov             x19, x1
    //     0x1307250: mov             v2.16b, v0.16b
    //     0x1307254: stur            d0, [fp, #-8]
    // 0x1307258: LoadField: d0 = r19->field_f
    //     0x1307258: ldur            d0, [x19, #0xf]
    // 0x130725c: fmul            d1, d0, d2
    // 0x1307260: d0 = 2.718282
    //     0x1307260: add             x17, PP, #0x96, lsl #12  ; [pp+0x96068] IMM: double(2.718281828459045) from 0x4005bf0a8b145769
    //     0x1307264: ldr             d0, [x17, #0x68]
    // 0x1307268: d30 = 0.000000
    //     0x1307268: fmov            d30, d0
    // 0x130726c: d0 = 1.000000
    //     0x130726c: fmov            d0, #1.00000000
    // 0x1307270: fcmp            d1, #0.0
    // 0x1307274: b.vs            #0x13072b8
    // 0x1307278: b.eq            #0x130733c
    // 0x130727c: fcmp            d1, d0
    // 0x1307280: b.eq            #0x13072a8
    // 0x1307284: d31 = 2.000000
    //     0x1307284: fmov            d31, #2.00000000
    // 0x1307288: fcmp            d1, d31
    // 0x130728c: b.eq            #0x13072b0
    // 0x1307290: d31 = 3.000000
    //     0x1307290: fmov            d31, #3.00000000
    // 0x1307294: fcmp            d1, d31
    // 0x1307298: b.ne            #0x13072b8
    // 0x130729c: fmul            d0, d30, d30
    // 0x13072a0: fmul            d0, d0, d30
    // 0x13072a4: b               #0x130733c
    // 0x13072a8: d0 = 0.000000
    //     0x13072a8: fmov            d0, d30
    // 0x13072ac: b               #0x130733c
    // 0x13072b0: fmul            d0, d30, d30
    // 0x13072b4: b               #0x130733c
    // 0x13072b8: fcmp            d30, d0
    // 0x13072bc: b.vs            #0x13072cc
    // 0x13072c0: b.eq            #0x130733c
    // 0x13072c4: fcmp            d30, d1
    // 0x13072c8: b.vc            #0x13072d4
    // 0x13072cc: d0 = -nan
    //     0x13072cc: ldr             d0, [PP, #0x24c0]  ; [pp+0x24c0] IMM: double(-nan) from 0xfff8000000000000
    // 0x13072d0: b               #0x130733c
    // 0x13072d4: d0 = -inf
    //     0x13072d4: ldr             d0, [PP, #0x5780]  ; [pp+0x5780] IMM: double(-inf) from 0xfff0000000000000
    // 0x13072d8: fcmp            d30, d0
    // 0x13072dc: b.eq            #0x1307304
    // 0x13072e0: d0 = 0.500000
    //     0x13072e0: fmov            d0, #0.50000000
    // 0x13072e4: fcmp            d1, d0
    // 0x13072e8: b.ne            #0x1307304
    // 0x13072ec: fcmp            d30, #0.0
    // 0x13072f0: b.eq            #0x13072fc
    // 0x13072f4: fsqrt           d0, d30
    // 0x13072f8: b               #0x130733c
    // 0x13072fc: d0 = 0.000000
    //     0x13072fc: eor             v0.16b, v0.16b, v0.16b
    // 0x1307300: b               #0x130733c
    // 0x1307304: d0 = 0.000000
    //     0x1307304: fmov            d0, d30
    // 0x1307308: stp             fp, lr, [SP, #-0x10]!
    // 0x130730c: mov             fp, SP
    // 0x1307310: CallRuntime_LibcPow(double, double) -> double
    //     0x1307310: and             SP, SP, #0xfffffffffffffff0
    //     0x1307314: mov             sp, SP
    //     0x1307318: ldr             x16, [THR, #0x740]  ; THR::LibcPow
    //     0x130731c: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x1307320: blr             x16
    //     0x1307324: mov             x16, #8
    //     0x1307328: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x130732c: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x1307330: sub             sp, x16, #1, lsl #12
    //     0x1307334: mov             SP, fp
    //     0x1307338: ldp             fp, lr, [SP], #0x10
    // 0x130733c: mov             v1.16b, v0.16b
    // 0x1307340: stur            d1, [fp, #-0x20]
    // 0x1307344: ArrayLoad: d2 = r19[0]  ; List_8
    //     0x1307344: ldur            d2, [x19, #0x17]
    // 0x1307348: stur            d2, [fp, #-0x18]
    // 0x130734c: LoadField: d0 = r19->field_7
    //     0x130734c: ldur            d0, [x19, #7]
    // 0x1307350: ldur            d3, [fp, #-8]
    // 0x1307354: fmul            d4, d0, d3
    // 0x1307358: mov             v0.16b, v4.16b
    // 0x130735c: stur            d4, [fp, #-0x10]
    // 0x1307360: stp             fp, lr, [SP, #-0x10]!
    // 0x1307364: mov             fp, SP
    // 0x1307368: CallRuntime_LibcCos(double) -> double
    //     0x1307368: and             SP, SP, #0xfffffffffffffff0
    //     0x130736c: mov             sp, SP
    //     0x1307370: ldr             x16, [THR, #0x778]  ; THR::LibcCos
    //     0x1307374: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x1307378: blr             x16
    //     0x130737c: mov             x16, #8
    //     0x1307380: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x1307384: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x1307388: sub             sp, x16, #1, lsl #12
    //     0x130738c: mov             SP, fp
    //     0x1307390: ldp             fp, lr, [SP], #0x10
    // 0x1307394: mov             v1.16b, v0.16b
    // 0x1307398: ldur            d0, [fp, #-0x18]
    // 0x130739c: fmul            d2, d0, d1
    // 0x13073a0: stur            d2, [fp, #-0x28]
    // 0x13073a4: LoadField: d1 = r19->field_1f
    //     0x13073a4: ldur            d1, [x19, #0x1f]
    // 0x13073a8: ldur            d0, [fp, #-0x10]
    // 0x13073ac: stur            d1, [fp, #-8]
    // 0x13073b0: stp             fp, lr, [SP, #-0x10]!
    // 0x13073b4: mov             fp, SP
    // 0x13073b8: CallRuntime_LibcSin(double) -> double
    //     0x13073b8: and             SP, SP, #0xfffffffffffffff0
    //     0x13073bc: mov             sp, SP
    //     0x13073c0: ldr             x16, [THR, #0x780]  ; THR::LibcSin
    //     0x13073c4: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x13073c8: blr             x16
    //     0x13073cc: mov             x16, #8
    //     0x13073d0: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x13073d4: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x13073d8: sub             sp, x16, #1, lsl #12
    //     0x13073dc: mov             SP, fp
    //     0x13073e0: ldp             fp, lr, [SP], #0x10
    // 0x13073e4: ldur            d1, [fp, #-8]
    // 0x13073e8: fmul            d2, d1, d0
    // 0x13073ec: ldur            d1, [fp, #-0x28]
    // 0x13073f0: fadd            d3, d1, d2
    // 0x13073f4: ldur            d1, [fp, #-0x20]
    // 0x13073f8: fmul            d0, d1, d3
    // 0x13073fc: LeaveFrame
    //     0x13073fc: mov             SP, fp
    //     0x1307400: ldp             fp, lr, [SP], #0x10
    // 0x1307404: ret
    //     0x1307404: ret             
  }
  _ dx(/* No info */) {
    // ** addr: 0x1307fd4, size: 0x1e8
    // 0x1307fd4: EnterFrame
    //     0x1307fd4: stp             fp, lr, [SP, #-0x10]!
    //     0x1307fd8: mov             fp, SP
    // 0x1307fdc: AllocStack(0x28)
    //     0x1307fdc: sub             SP, SP, #0x28
    // 0x1307fe0: SetupParameters(_UnderdampedSolution this /* r1 => r19 */)
    //     0x1307fe0: mov             x19, x1
    // 0x1307fe4: LoadField: d2 = r19->field_f
    //     0x1307fe4: ldur            d2, [x19, #0xf]
    // 0x1307fe8: stur            d2, [fp, #-0x10]
    // 0x1307fec: LoadField: d3 = r2->field_7
    //     0x1307fec: ldur            d3, [x2, #7]
    // 0x1307ff0: stur            d3, [fp, #-8]
    // 0x1307ff4: fmul            d1, d2, d3
    // 0x1307ff8: d0 = 2.718282
    //     0x1307ff8: add             x17, PP, #0x96, lsl #12  ; [pp+0x96068] IMM: double(2.718281828459045) from 0x4005bf0a8b145769
    //     0x1307ffc: ldr             d0, [x17, #0x68]
    // 0x1308000: d30 = 0.000000
    //     0x1308000: fmov            d30, d0
    // 0x1308004: d0 = 1.000000
    //     0x1308004: fmov            d0, #1.00000000
    // 0x1308008: fcmp            d1, #0.0
    // 0x130800c: b.vs            #0x1308050
    // 0x1308010: b.eq            #0x13080d4
    // 0x1308014: fcmp            d1, d0
    // 0x1308018: b.eq            #0x1308040
    // 0x130801c: d31 = 2.000000
    //     0x130801c: fmov            d31, #2.00000000
    // 0x1308020: fcmp            d1, d31
    // 0x1308024: b.eq            #0x1308048
    // 0x1308028: d31 = 3.000000
    //     0x1308028: fmov            d31, #3.00000000
    // 0x130802c: fcmp            d1, d31
    // 0x1308030: b.ne            #0x1308050
    // 0x1308034: fmul            d0, d30, d30
    // 0x1308038: fmul            d0, d0, d30
    // 0x130803c: b               #0x13080d4
    // 0x1308040: d0 = 0.000000
    //     0x1308040: fmov            d0, d30
    // 0x1308044: b               #0x13080d4
    // 0x1308048: fmul            d0, d30, d30
    // 0x130804c: b               #0x13080d4
    // 0x1308050: fcmp            d30, d0
    // 0x1308054: b.vs            #0x1308064
    // 0x1308058: b.eq            #0x13080d4
    // 0x130805c: fcmp            d30, d1
    // 0x1308060: b.vc            #0x130806c
    // 0x1308064: d0 = -nan
    //     0x1308064: ldr             d0, [PP, #0x24c0]  ; [pp+0x24c0] IMM: double(-nan) from 0xfff8000000000000
    // 0x1308068: b               #0x13080d4
    // 0x130806c: d0 = -inf
    //     0x130806c: ldr             d0, [PP, #0x5780]  ; [pp+0x5780] IMM: double(-inf) from 0xfff0000000000000
    // 0x1308070: fcmp            d30, d0
    // 0x1308074: b.eq            #0x130809c
    // 0x1308078: d0 = 0.500000
    //     0x1308078: fmov            d0, #0.50000000
    // 0x130807c: fcmp            d1, d0
    // 0x1308080: b.ne            #0x130809c
    // 0x1308084: fcmp            d30, #0.0
    // 0x1308088: b.eq            #0x1308094
    // 0x130808c: fsqrt           d0, d30
    // 0x1308090: b               #0x13080d4
    // 0x1308094: d0 = 0.000000
    //     0x1308094: eor             v0.16b, v0.16b, v0.16b
    // 0x1308098: b               #0x13080d4
    // 0x130809c: d0 = 0.000000
    //     0x130809c: fmov            d0, d30
    // 0x13080a0: stp             fp, lr, [SP, #-0x10]!
    // 0x13080a4: mov             fp, SP
    // 0x13080a8: CallRuntime_LibcPow(double, double) -> double
    //     0x13080a8: and             SP, SP, #0xfffffffffffffff0
    //     0x13080ac: mov             sp, SP
    //     0x13080b0: ldr             x16, [THR, #0x740]  ; THR::LibcPow
    //     0x13080b4: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x13080b8: blr             x16
    //     0x13080bc: mov             x16, #8
    //     0x13080c0: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x13080c4: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x13080c8: sub             sp, x16, #1, lsl #12
    //     0x13080cc: mov             SP, fp
    //     0x13080d0: ldp             fp, lr, [SP], #0x10
    // 0x13080d4: mov             v1.16b, v0.16b
    // 0x13080d8: stur            d1, [fp, #-0x28]
    // 0x13080dc: LoadField: d2 = r19->field_7
    //     0x13080dc: ldur            d2, [x19, #7]
    // 0x13080e0: ldur            d0, [fp, #-8]
    // 0x13080e4: stur            d2, [fp, #-0x20]
    // 0x13080e8: fmul            d3, d2, d0
    // 0x13080ec: mov             v0.16b, v3.16b
    // 0x13080f0: stur            d3, [fp, #-0x18]
    // 0x13080f4: stp             fp, lr, [SP, #-0x10]!
    // 0x13080f8: mov             fp, SP
    // 0x13080fc: CallRuntime_LibcCos(double) -> double
    //     0x13080fc: and             SP, SP, #0xfffffffffffffff0
    //     0x1308100: mov             sp, SP
    //     0x1308104: ldr             x16, [THR, #0x778]  ; THR::LibcCos
    //     0x1308108: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x130810c: blr             x16
    //     0x1308110: mov             x16, #8
    //     0x1308114: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x1308118: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x130811c: sub             sp, x16, #1, lsl #12
    //     0x1308120: mov             SP, fp
    //     0x1308124: ldp             fp, lr, [SP], #0x10
    // 0x1308128: mov             v1.16b, v0.16b
    // 0x130812c: ldur            d0, [fp, #-0x18]
    // 0x1308130: stur            d1, [fp, #-8]
    // 0x1308134: stp             fp, lr, [SP, #-0x10]!
    // 0x1308138: mov             fp, SP
    // 0x130813c: CallRuntime_LibcSin(double) -> double
    //     0x130813c: and             SP, SP, #0xfffffffffffffff0
    //     0x1308140: mov             sp, SP
    //     0x1308144: ldr             x16, [THR, #0x780]  ; THR::LibcSin
    //     0x1308148: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x130814c: blr             x16
    //     0x1308150: mov             x16, #8
    //     0x1308154: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x1308158: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x130815c: sub             sp, x16, #1, lsl #12
    //     0x1308160: mov             SP, fp
    //     0x1308164: ldp             fp, lr, [SP], #0x10
    // 0x1308168: LoadField: d1 = r19->field_1f
    //     0x1308168: ldur            d1, [x19, #0x1f]
    // 0x130816c: ldur            d2, [fp, #-0x20]
    // 0x1308170: fmul            d3, d1, d2
    // 0x1308174: ldur            d4, [fp, #-8]
    // 0x1308178: fmul            d5, d3, d4
    // 0x130817c: ArrayLoad: d3 = r19[0]  ; List_8
    //     0x130817c: ldur            d3, [x19, #0x17]
    // 0x1308180: fmul            d6, d3, d2
    // 0x1308184: fmul            d2, d6, d0
    // 0x1308188: fsub            d6, d5, d2
    // 0x130818c: ldur            d2, [fp, #-0x28]
    // 0x1308190: fmul            d5, d2, d6
    // 0x1308194: ldur            d6, [fp, #-0x10]
    // 0x1308198: fmul            d7, d6, d2
    // 0x130819c: fmul            d2, d1, d0
    // 0x13081a0: fmul            d1, d3, d4
    // 0x13081a4: fadd            d3, d2, d1
    // 0x13081a8: fmul            d1, d7, d3
    // 0x13081ac: fadd            d0, d5, d1
    // 0x13081b0: LeaveFrame
    //     0x13081b0: mov             SP, fp
    //     0x13081b4: ldp             fp, lr, [SP], #0x10
    // 0x13081b8: ret
    //     0x13081b8: ret             
  }
}

// class id: 2891, size: 0x28, field offset: 0x8
class _OverdampedSolution extends Object
    implements _SpringSolution {

  dynamic dx(dynamic) {
    // ** addr: 0xb3594c, size: 0x3c
    // 0xb3594c: EnterFrame
    //     0xb3594c: stp             fp, lr, [SP, #-0x10]!
    //     0xb35950: mov             fp, SP
    // 0xb35954: ldr             x2, [fp, #0x10]
    // 0xb35958: r1 = Function 'dx':.
    //     0xb35958: add             x1, PP, #0xcf, lsl #12  ; [pp+0xcf990] AnonymousClosure: (0xb35970), in [package:flutter/src/physics/spring_simulation.dart] _OverdampedSolution::dx (0x1307da4)
    //     0xb3595c: ldr             x1, [x1, #0x990]
    // 0xb35960: r0 = AllocateClosure()
    //     0xb35960: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb35964: LeaveFrame
    //     0xb35964: mov             SP, fp
    //     0xb35968: ldp             fp, lr, [SP], #0x10
    // 0xb3596c: ret
    //     0xb3596c: ret             
  }
  factory _ _OverdampedSolution(/* No info */) {
    // ** addr: 0xb35894, size: 0xa0
    // 0xb35894: EnterFrame
    //     0xb35894: stp             fp, lr, [SP, #-0x10]!
    //     0xb35898: mov             fp, SP
    // 0xb3589c: AllocStack(0x20)
    //     0xb3589c: sub             SP, SP, #0x20
    // 0xb358a0: d3 = 4.000000
    //     0xb358a0: fmov            d3, #4.00000000
    // 0xb358a4: d2 = 2.000000
    //     0xb358a4: fmov            d2, #2.00000000
    // 0xb358a8: ArrayLoad: d4 = r2[0]  ; List_8
    //     0xb358a8: ldur            d4, [x2, #0x17]
    // 0xb358ac: fmul            d5, d4, d4
    // 0xb358b0: LoadField: d6 = r2->field_7
    //     0xb358b0: ldur            d6, [x2, #7]
    // 0xb358b4: fmul            d7, d6, d3
    // 0xb358b8: LoadField: d3 = r2->field_f
    //     0xb358b8: ldur            d3, [x2, #0xf]
    // 0xb358bc: fmul            d8, d7, d3
    // 0xb358c0: fsub            d3, d5, d8
    // 0xb358c4: fneg            d5, d4
    // 0xb358c8: fsqrt           d4, d3
    // 0xb358cc: fsub            d3, d5, d4
    // 0xb358d0: fmul            d7, d6, d2
    // 0xb358d4: fdiv            d2, d3, d7
    // 0xb358d8: stur            d2, [fp, #-0x20]
    // 0xb358dc: fadd            d3, d5, d4
    // 0xb358e0: fdiv            d4, d3, d7
    // 0xb358e4: stur            d4, [fp, #-0x18]
    // 0xb358e8: fmul            d3, d2, d0
    // 0xb358ec: fsub            d5, d1, d3
    // 0xb358f0: fsub            d1, d4, d2
    // 0xb358f4: fdiv            d3, d5, d1
    // 0xb358f8: stur            d3, [fp, #-0x10]
    // 0xb358fc: fsub            d1, d0, d3
    // 0xb35900: stur            d1, [fp, #-8]
    // 0xb35904: r0 = _OverdampedSolution()
    //     0xb35904: bl              #0xb35bec  ; Allocate_OverdampedSolutionStub -> _OverdampedSolution (size=0x28)
    // 0xb35908: ldur            d0, [fp, #-0x20]
    // 0xb3590c: StoreField: r0->field_7 = d0
    //     0xb3590c: stur            d0, [x0, #7]
    // 0xb35910: ldur            d0, [fp, #-0x18]
    // 0xb35914: StoreField: r0->field_f = d0
    //     0xb35914: stur            d0, [x0, #0xf]
    // 0xb35918: ldur            d0, [fp, #-8]
    // 0xb3591c: ArrayStore: r0[0] = d0  ; List_8
    //     0xb3591c: stur            d0, [x0, #0x17]
    // 0xb35920: ldur            d0, [fp, #-0x10]
    // 0xb35924: StoreField: r0->field_1f = d0
    //     0xb35924: stur            d0, [x0, #0x1f]
    // 0xb35928: LeaveFrame
    //     0xb35928: mov             SP, fp
    //     0xb3592c: ldp             fp, lr, [SP], #0x10
    // 0xb35930: ret
    //     0xb35930: ret             
  }
  [closure] double dx(dynamic, double) {
    // ** addr: 0xb35970, size: 0x27c
    // 0xb35970: EnterFrame
    //     0xb35970: stp             fp, lr, [SP, #-0x10]!
    //     0xb35974: mov             fp, SP
    // 0xb35978: AllocStack(0x18)
    //     0xb35978: sub             SP, SP, #0x18
    // 0xb3597c: SetupParameters([dynamic _ /* r19 */])
    //     0xb3597c: ldr             x19, [fp, #0x18]
    //     0xb35980: ldur            w20, [x19, #0x17]
    //     0xb35984: add             x20, x20, HEAP, lsl #32
    // 0xb35988: ArrayLoad: d0 = r20[0]  ; List_8
    //     0xb35988: ldur            d0, [x20, #0x17]
    // 0xb3598c: LoadField: d1 = r20->field_7
    //     0xb3598c: ldur            d1, [x20, #7]
    // 0xb35990: fmul            d2, d0, d1
    // 0xb35994: ldr             x19, [fp, #0x10]
    // 0xb35998: stur            d2, [fp, #-0x10]
    // 0xb3599c: LoadField: d3 = r19->field_7
    //     0xb3599c: ldur            d3, [x19, #7]
    // 0xb359a0: stur            d3, [fp, #-8]
    // 0xb359a4: fmul            d0, d1, d3
    // 0xb359a8: mov             v1.16b, v0.16b
    // 0xb359ac: d0 = 2.718282
    //     0xb359ac: add             x17, PP, #0x96, lsl #12  ; [pp+0x96068] IMM: double(2.718281828459045) from 0x4005bf0a8b145769
    //     0xb359b0: ldr             d0, [x17, #0x68]
    // 0xb359b4: d30 = 0.000000
    //     0xb359b4: fmov            d30, d0
    // 0xb359b8: d0 = 1.000000
    //     0xb359b8: fmov            d0, #1.00000000
    // 0xb359bc: fcmp            d1, #0.0
    // 0xb359c0: b.vs            #0xb35a04
    // 0xb359c4: b.eq            #0xb35a88
    // 0xb359c8: fcmp            d1, d0
    // 0xb359cc: b.eq            #0xb359f4
    // 0xb359d0: d31 = 2.000000
    //     0xb359d0: fmov            d31, #2.00000000
    // 0xb359d4: fcmp            d1, d31
    // 0xb359d8: b.eq            #0xb359fc
    // 0xb359dc: d31 = 3.000000
    //     0xb359dc: fmov            d31, #3.00000000
    // 0xb359e0: fcmp            d1, d31
    // 0xb359e4: b.ne            #0xb35a04
    // 0xb359e8: fmul            d0, d30, d30
    // 0xb359ec: fmul            d0, d0, d30
    // 0xb359f0: b               #0xb35a88
    // 0xb359f4: d0 = 0.000000
    //     0xb359f4: fmov            d0, d30
    // 0xb359f8: b               #0xb35a88
    // 0xb359fc: fmul            d0, d30, d30
    // 0xb35a00: b               #0xb35a88
    // 0xb35a04: fcmp            d30, d0
    // 0xb35a08: b.vs            #0xb35a18
    // 0xb35a0c: b.eq            #0xb35a88
    // 0xb35a10: fcmp            d30, d1
    // 0xb35a14: b.vc            #0xb35a20
    // 0xb35a18: d0 = -nan
    //     0xb35a18: ldr             d0, [PP, #0x24c0]  ; [pp+0x24c0] IMM: double(-nan) from 0xfff8000000000000
    // 0xb35a1c: b               #0xb35a88
    // 0xb35a20: d0 = -inf
    //     0xb35a20: ldr             d0, [PP, #0x5780]  ; [pp+0x5780] IMM: double(-inf) from 0xfff0000000000000
    // 0xb35a24: fcmp            d30, d0
    // 0xb35a28: b.eq            #0xb35a50
    // 0xb35a2c: d0 = 0.500000
    //     0xb35a2c: fmov            d0, #0.50000000
    // 0xb35a30: fcmp            d1, d0
    // 0xb35a34: b.ne            #0xb35a50
    // 0xb35a38: fcmp            d30, #0.0
    // 0xb35a3c: b.eq            #0xb35a48
    // 0xb35a40: fsqrt           d0, d30
    // 0xb35a44: b               #0xb35a88
    // 0xb35a48: d0 = 0.000000
    //     0xb35a48: eor             v0.16b, v0.16b, v0.16b
    // 0xb35a4c: b               #0xb35a88
    // 0xb35a50: d0 = 0.000000
    //     0xb35a50: fmov            d0, d30
    // 0xb35a54: stp             fp, lr, [SP, #-0x10]!
    // 0xb35a58: mov             fp, SP
    // 0xb35a5c: CallRuntime_LibcPow(double, double) -> double
    //     0xb35a5c: and             SP, SP, #0xfffffffffffffff0
    //     0xb35a60: mov             sp, SP
    //     0xb35a64: ldr             x16, [THR, #0x740]  ; THR::LibcPow
    //     0xb35a68: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xb35a6c: blr             x16
    //     0xb35a70: mov             x16, #8
    //     0xb35a74: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xb35a78: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xb35a7c: sub             sp, x16, #1, lsl #12
    //     0xb35a80: mov             SP, fp
    //     0xb35a84: ldp             fp, lr, [SP], #0x10
    // 0xb35a88: mov             v1.16b, v0.16b
    // 0xb35a8c: ldur            d0, [fp, #-0x10]
    // 0xb35a90: fmul            d2, d0, d1
    // 0xb35a94: stur            d2, [fp, #-0x18]
    // 0xb35a98: LoadField: d0 = r20->field_1f
    //     0xb35a98: ldur            d0, [x20, #0x1f]
    // 0xb35a9c: LoadField: d1 = r20->field_f
    //     0xb35a9c: ldur            d1, [x20, #0xf]
    // 0xb35aa0: fmul            d3, d0, d1
    // 0xb35aa4: ldur            d0, [fp, #-8]
    // 0xb35aa8: stur            d3, [fp, #-0x10]
    // 0xb35aac: fmul            d4, d1, d0
    // 0xb35ab0: mov             v1.16b, v4.16b
    // 0xb35ab4: d0 = 2.718282
    //     0xb35ab4: add             x17, PP, #0x96, lsl #12  ; [pp+0x96068] IMM: double(2.718281828459045) from 0x4005bf0a8b145769
    //     0xb35ab8: ldr             d0, [x17, #0x68]
    // 0xb35abc: d30 = 0.000000
    //     0xb35abc: fmov            d30, d0
    // 0xb35ac0: d0 = 1.000000
    //     0xb35ac0: fmov            d0, #1.00000000
    // 0xb35ac4: fcmp            d1, #0.0
    // 0xb35ac8: b.vs            #0xb35b0c
    // 0xb35acc: b.eq            #0xb35b90
    // 0xb35ad0: fcmp            d1, d0
    // 0xb35ad4: b.eq            #0xb35afc
    // 0xb35ad8: d31 = 2.000000
    //     0xb35ad8: fmov            d31, #2.00000000
    // 0xb35adc: fcmp            d1, d31
    // 0xb35ae0: b.eq            #0xb35b04
    // 0xb35ae4: d31 = 3.000000
    //     0xb35ae4: fmov            d31, #3.00000000
    // 0xb35ae8: fcmp            d1, d31
    // 0xb35aec: b.ne            #0xb35b0c
    // 0xb35af0: fmul            d0, d30, d30
    // 0xb35af4: fmul            d0, d0, d30
    // 0xb35af8: b               #0xb35b90
    // 0xb35afc: d0 = 0.000000
    //     0xb35afc: fmov            d0, d30
    // 0xb35b00: b               #0xb35b90
    // 0xb35b04: fmul            d0, d30, d30
    // 0xb35b08: b               #0xb35b90
    // 0xb35b0c: fcmp            d30, d0
    // 0xb35b10: b.vs            #0xb35b20
    // 0xb35b14: b.eq            #0xb35b90
    // 0xb35b18: fcmp            d30, d1
    // 0xb35b1c: b.vc            #0xb35b28
    // 0xb35b20: d0 = -nan
    //     0xb35b20: ldr             d0, [PP, #0x24c0]  ; [pp+0x24c0] IMM: double(-nan) from 0xfff8000000000000
    // 0xb35b24: b               #0xb35b90
    // 0xb35b28: d0 = -inf
    //     0xb35b28: ldr             d0, [PP, #0x5780]  ; [pp+0x5780] IMM: double(-inf) from 0xfff0000000000000
    // 0xb35b2c: fcmp            d30, d0
    // 0xb35b30: b.eq            #0xb35b58
    // 0xb35b34: d0 = 0.500000
    //     0xb35b34: fmov            d0, #0.50000000
    // 0xb35b38: fcmp            d1, d0
    // 0xb35b3c: b.ne            #0xb35b58
    // 0xb35b40: fcmp            d30, #0.0
    // 0xb35b44: b.eq            #0xb35b50
    // 0xb35b48: fsqrt           d0, d30
    // 0xb35b4c: b               #0xb35b90
    // 0xb35b50: d0 = 0.000000
    //     0xb35b50: eor             v0.16b, v0.16b, v0.16b
    // 0xb35b54: b               #0xb35b90
    // 0xb35b58: d0 = 0.000000
    //     0xb35b58: fmov            d0, d30
    // 0xb35b5c: stp             fp, lr, [SP, #-0x10]!
    // 0xb35b60: mov             fp, SP
    // 0xb35b64: CallRuntime_LibcPow(double, double) -> double
    //     0xb35b64: and             SP, SP, #0xfffffffffffffff0
    //     0xb35b68: mov             sp, SP
    //     0xb35b6c: ldr             x16, [THR, #0x740]  ; THR::LibcPow
    //     0xb35b70: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xb35b74: blr             x16
    //     0xb35b78: mov             x16, #8
    //     0xb35b7c: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xb35b80: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xb35b84: sub             sp, x16, #1, lsl #12
    //     0xb35b88: mov             SP, fp
    //     0xb35b8c: ldp             fp, lr, [SP], #0x10
    // 0xb35b90: mov             v1.16b, v0.16b
    // 0xb35b94: ldur            d0, [fp, #-0x10]
    // 0xb35b98: fmul            d2, d0, d1
    // 0xb35b9c: ldur            d0, [fp, #-0x18]
    // 0xb35ba0: fadd            d1, d0, d2
    // 0xb35ba4: r0 = inline_Allocate_Double()
    //     0xb35ba4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb35ba8: add             x0, x0, #0x10
    //     0xb35bac: cmp             x1, x0
    //     0xb35bb0: b.ls            #0xb35bdc
    //     0xb35bb4: str             x0, [THR, #0x60]  ; THR::top
    //     0xb35bb8: sub             x0, x0, #0xf
    //     0xb35bbc: mov             x1, #0xe19c
    //     0xb35bc0: movk            x1, #3, lsl #16
    //     0xb35bc4: stur            x1, [x0, #-1]
    // 0xb35bc8: dmb             ishst
    // 0xb35bcc: StoreField: r0->field_7 = d1
    //     0xb35bcc: stur            d1, [x0, #7]
    // 0xb35bd0: LeaveFrame
    //     0xb35bd0: mov             SP, fp
    //     0xb35bd4: ldp             fp, lr, [SP], #0x10
    // 0xb35bd8: ret
    //     0xb35bd8: ret             
    // 0xb35bdc: SaveReg d1
    //     0xb35bdc: str             q1, [SP, #-0x10]!
    // 0xb35be0: r0 = AllocateDouble()
    //     0xb35be0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb35be4: RestoreReg d1
    //     0xb35be4: ldr             q1, [SP], #0x10
    // 0xb35be8: b               #0xb35bcc
  }
  _ x(/* No info */) {
    // ** addr: 0x130701c, size: 0x224
    // 0x130701c: EnterFrame
    //     0x130701c: stp             fp, lr, [SP, #-0x10]!
    //     0x1307020: mov             fp, SP
    // 0x1307024: AllocStack(0x18)
    //     0x1307024: sub             SP, SP, #0x18
    // 0x1307028: SetupParameters(_OverdampedSolution this /* r1 => r19 */, dynamic _ /* d0 => d2, fp-0x10 */)
    //     0x1307028: mov             x19, x1
    //     0x130702c: mov             v2.16b, v0.16b
    //     0x1307030: stur            d0, [fp, #-0x10]
    // 0x1307034: ArrayLoad: d3 = r19[0]  ; List_8
    //     0x1307034: ldur            d3, [x19, #0x17]
    // 0x1307038: stur            d3, [fp, #-8]
    // 0x130703c: LoadField: d0 = r19->field_7
    //     0x130703c: ldur            d0, [x19, #7]
    // 0x1307040: fmul            d1, d0, d2
    // 0x1307044: d0 = 2.718282
    //     0x1307044: add             x17, PP, #0x96, lsl #12  ; [pp+0x96068] IMM: double(2.718281828459045) from 0x4005bf0a8b145769
    //     0x1307048: ldr             d0, [x17, #0x68]
    // 0x130704c: d30 = 0.000000
    //     0x130704c: fmov            d30, d0
    // 0x1307050: d0 = 1.000000
    //     0x1307050: fmov            d0, #1.00000000
    // 0x1307054: fcmp            d1, #0.0
    // 0x1307058: b.vs            #0x130709c
    // 0x130705c: b.eq            #0x1307120
    // 0x1307060: fcmp            d1, d0
    // 0x1307064: b.eq            #0x130708c
    // 0x1307068: d31 = 2.000000
    //     0x1307068: fmov            d31, #2.00000000
    // 0x130706c: fcmp            d1, d31
    // 0x1307070: b.eq            #0x1307094
    // 0x1307074: d31 = 3.000000
    //     0x1307074: fmov            d31, #3.00000000
    // 0x1307078: fcmp            d1, d31
    // 0x130707c: b.ne            #0x130709c
    // 0x1307080: fmul            d0, d30, d30
    // 0x1307084: fmul            d0, d0, d30
    // 0x1307088: b               #0x1307120
    // 0x130708c: d0 = 0.000000
    //     0x130708c: fmov            d0, d30
    // 0x1307090: b               #0x1307120
    // 0x1307094: fmul            d0, d30, d30
    // 0x1307098: b               #0x1307120
    // 0x130709c: fcmp            d30, d0
    // 0x13070a0: b.vs            #0x13070b0
    // 0x13070a4: b.eq            #0x1307120
    // 0x13070a8: fcmp            d30, d1
    // 0x13070ac: b.vc            #0x13070b8
    // 0x13070b0: d0 = -nan
    //     0x13070b0: ldr             d0, [PP, #0x24c0]  ; [pp+0x24c0] IMM: double(-nan) from 0xfff8000000000000
    // 0x13070b4: b               #0x1307120
    // 0x13070b8: d0 = -inf
    //     0x13070b8: ldr             d0, [PP, #0x5780]  ; [pp+0x5780] IMM: double(-inf) from 0xfff0000000000000
    // 0x13070bc: fcmp            d30, d0
    // 0x13070c0: b.eq            #0x13070e8
    // 0x13070c4: d0 = 0.500000
    //     0x13070c4: fmov            d0, #0.50000000
    // 0x13070c8: fcmp            d1, d0
    // 0x13070cc: b.ne            #0x13070e8
    // 0x13070d0: fcmp            d30, #0.0
    // 0x13070d4: b.eq            #0x13070e0
    // 0x13070d8: fsqrt           d0, d30
    // 0x13070dc: b               #0x1307120
    // 0x13070e0: d0 = 0.000000
    //     0x13070e0: eor             v0.16b, v0.16b, v0.16b
    // 0x13070e4: b               #0x1307120
    // 0x13070e8: d0 = 0.000000
    //     0x13070e8: fmov            d0, d30
    // 0x13070ec: stp             fp, lr, [SP, #-0x10]!
    // 0x13070f0: mov             fp, SP
    // 0x13070f4: CallRuntime_LibcPow(double, double) -> double
    //     0x13070f4: and             SP, SP, #0xfffffffffffffff0
    //     0x13070f8: mov             sp, SP
    //     0x13070fc: ldr             x16, [THR, #0x740]  ; THR::LibcPow
    //     0x1307100: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x1307104: blr             x16
    //     0x1307108: mov             x16, #8
    //     0x130710c: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x1307110: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x1307114: sub             sp, x16, #1, lsl #12
    //     0x1307118: mov             SP, fp
    //     0x130711c: ldp             fp, lr, [SP], #0x10
    // 0x1307120: mov             v1.16b, v0.16b
    // 0x1307124: ldur            d0, [fp, #-8]
    // 0x1307128: fmul            d2, d0, d1
    // 0x130712c: stur            d2, [fp, #-0x18]
    // 0x1307130: LoadField: d3 = r19->field_1f
    //     0x1307130: ldur            d3, [x19, #0x1f]
    // 0x1307134: stur            d3, [fp, #-8]
    // 0x1307138: LoadField: d0 = r19->field_f
    //     0x1307138: ldur            d0, [x19, #0xf]
    // 0x130713c: ldur            d1, [fp, #-0x10]
    // 0x1307140: fmul            d4, d0, d1
    // 0x1307144: mov             v1.16b, v4.16b
    // 0x1307148: d0 = 2.718282
    //     0x1307148: add             x17, PP, #0x96, lsl #12  ; [pp+0x96068] IMM: double(2.718281828459045) from 0x4005bf0a8b145769
    //     0x130714c: ldr             d0, [x17, #0x68]
    // 0x1307150: d30 = 0.000000
    //     0x1307150: fmov            d30, d0
    // 0x1307154: d0 = 1.000000
    //     0x1307154: fmov            d0, #1.00000000
    // 0x1307158: fcmp            d1, #0.0
    // 0x130715c: b.vs            #0x13071a0
    // 0x1307160: b.eq            #0x1307224
    // 0x1307164: fcmp            d1, d0
    // 0x1307168: b.eq            #0x1307190
    // 0x130716c: d31 = 2.000000
    //     0x130716c: fmov            d31, #2.00000000
    // 0x1307170: fcmp            d1, d31
    // 0x1307174: b.eq            #0x1307198
    // 0x1307178: d31 = 3.000000
    //     0x1307178: fmov            d31, #3.00000000
    // 0x130717c: fcmp            d1, d31
    // 0x1307180: b.ne            #0x13071a0
    // 0x1307184: fmul            d0, d30, d30
    // 0x1307188: fmul            d0, d0, d30
    // 0x130718c: b               #0x1307224
    // 0x1307190: d0 = 0.000000
    //     0x1307190: fmov            d0, d30
    // 0x1307194: b               #0x1307224
    // 0x1307198: fmul            d0, d30, d30
    // 0x130719c: b               #0x1307224
    // 0x13071a0: fcmp            d30, d0
    // 0x13071a4: b.vs            #0x13071b4
    // 0x13071a8: b.eq            #0x1307224
    // 0x13071ac: fcmp            d30, d1
    // 0x13071b0: b.vc            #0x13071bc
    // 0x13071b4: d0 = -nan
    //     0x13071b4: ldr             d0, [PP, #0x24c0]  ; [pp+0x24c0] IMM: double(-nan) from 0xfff8000000000000
    // 0x13071b8: b               #0x1307224
    // 0x13071bc: d0 = -inf
    //     0x13071bc: ldr             d0, [PP, #0x5780]  ; [pp+0x5780] IMM: double(-inf) from 0xfff0000000000000
    // 0x13071c0: fcmp            d30, d0
    // 0x13071c4: b.eq            #0x13071ec
    // 0x13071c8: d0 = 0.500000
    //     0x13071c8: fmov            d0, #0.50000000
    // 0x13071cc: fcmp            d1, d0
    // 0x13071d0: b.ne            #0x13071ec
    // 0x13071d4: fcmp            d30, #0.0
    // 0x13071d8: b.eq            #0x13071e4
    // 0x13071dc: fsqrt           d0, d30
    // 0x13071e0: b               #0x1307224
    // 0x13071e4: d0 = 0.000000
    //     0x13071e4: eor             v0.16b, v0.16b, v0.16b
    // 0x13071e8: b               #0x1307224
    // 0x13071ec: d0 = 0.000000
    //     0x13071ec: fmov            d0, d30
    // 0x13071f0: stp             fp, lr, [SP, #-0x10]!
    // 0x13071f4: mov             fp, SP
    // 0x13071f8: CallRuntime_LibcPow(double, double) -> double
    //     0x13071f8: and             SP, SP, #0xfffffffffffffff0
    //     0x13071fc: mov             sp, SP
    //     0x1307200: ldr             x16, [THR, #0x740]  ; THR::LibcPow
    //     0x1307204: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x1307208: blr             x16
    //     0x130720c: mov             x16, #8
    //     0x1307210: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x1307214: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x1307218: sub             sp, x16, #1, lsl #12
    //     0x130721c: mov             SP, fp
    //     0x1307220: ldp             fp, lr, [SP], #0x10
    // 0x1307224: ldur            d1, [fp, #-8]
    // 0x1307228: fmul            d2, d1, d0
    // 0x130722c: ldur            d1, [fp, #-0x18]
    // 0x1307230: fadd            d0, d1, d2
    // 0x1307234: LeaveFrame
    //     0x1307234: mov             SP, fp
    //     0x1307238: ldp             fp, lr, [SP], #0x10
    // 0x130723c: ret
    //     0x130723c: ret             
  }
  _ dx(/* No info */) {
    // ** addr: 0x1307da4, size: 0x230
    // 0x1307da4: EnterFrame
    //     0x1307da4: stp             fp, lr, [SP, #-0x10]!
    //     0x1307da8: mov             fp, SP
    // 0x1307dac: AllocStack(0x18)
    //     0x1307dac: sub             SP, SP, #0x18
    // 0x1307db0: SetupParameters(_OverdampedSolution this /* r1 => r19 */)
    //     0x1307db0: mov             x19, x1
    // 0x1307db4: ArrayLoad: d0 = r19[0]  ; List_8
    //     0x1307db4: ldur            d0, [x19, #0x17]
    // 0x1307db8: LoadField: d1 = r19->field_7
    //     0x1307db8: ldur            d1, [x19, #7]
    // 0x1307dbc: fmul            d2, d0, d1
    // 0x1307dc0: stur            d2, [fp, #-0x10]
    // 0x1307dc4: LoadField: d3 = r2->field_7
    //     0x1307dc4: ldur            d3, [x2, #7]
    // 0x1307dc8: stur            d3, [fp, #-8]
    // 0x1307dcc: fmul            d0, d1, d3
    // 0x1307dd0: mov             v1.16b, v0.16b
    // 0x1307dd4: d0 = 2.718282
    //     0x1307dd4: add             x17, PP, #0x96, lsl #12  ; [pp+0x96068] IMM: double(2.718281828459045) from 0x4005bf0a8b145769
    //     0x1307dd8: ldr             d0, [x17, #0x68]
    // 0x1307ddc: d30 = 0.000000
    //     0x1307ddc: fmov            d30, d0
    // 0x1307de0: d0 = 1.000000
    //     0x1307de0: fmov            d0, #1.00000000
    // 0x1307de4: fcmp            d1, #0.0
    // 0x1307de8: b.vs            #0x1307e2c
    // 0x1307dec: b.eq            #0x1307eb0
    // 0x1307df0: fcmp            d1, d0
    // 0x1307df4: b.eq            #0x1307e1c
    // 0x1307df8: d31 = 2.000000
    //     0x1307df8: fmov            d31, #2.00000000
    // 0x1307dfc: fcmp            d1, d31
    // 0x1307e00: b.eq            #0x1307e24
    // 0x1307e04: d31 = 3.000000
    //     0x1307e04: fmov            d31, #3.00000000
    // 0x1307e08: fcmp            d1, d31
    // 0x1307e0c: b.ne            #0x1307e2c
    // 0x1307e10: fmul            d0, d30, d30
    // 0x1307e14: fmul            d0, d0, d30
    // 0x1307e18: b               #0x1307eb0
    // 0x1307e1c: d0 = 0.000000
    //     0x1307e1c: fmov            d0, d30
    // 0x1307e20: b               #0x1307eb0
    // 0x1307e24: fmul            d0, d30, d30
    // 0x1307e28: b               #0x1307eb0
    // 0x1307e2c: fcmp            d30, d0
    // 0x1307e30: b.vs            #0x1307e40
    // 0x1307e34: b.eq            #0x1307eb0
    // 0x1307e38: fcmp            d30, d1
    // 0x1307e3c: b.vc            #0x1307e48
    // 0x1307e40: d0 = -nan
    //     0x1307e40: ldr             d0, [PP, #0x24c0]  ; [pp+0x24c0] IMM: double(-nan) from 0xfff8000000000000
    // 0x1307e44: b               #0x1307eb0
    // 0x1307e48: d0 = -inf
    //     0x1307e48: ldr             d0, [PP, #0x5780]  ; [pp+0x5780] IMM: double(-inf) from 0xfff0000000000000
    // 0x1307e4c: fcmp            d30, d0
    // 0x1307e50: b.eq            #0x1307e78
    // 0x1307e54: d0 = 0.500000
    //     0x1307e54: fmov            d0, #0.50000000
    // 0x1307e58: fcmp            d1, d0
    // 0x1307e5c: b.ne            #0x1307e78
    // 0x1307e60: fcmp            d30, #0.0
    // 0x1307e64: b.eq            #0x1307e70
    // 0x1307e68: fsqrt           d0, d30
    // 0x1307e6c: b               #0x1307eb0
    // 0x1307e70: d0 = 0.000000
    //     0x1307e70: eor             v0.16b, v0.16b, v0.16b
    // 0x1307e74: b               #0x1307eb0
    // 0x1307e78: d0 = 0.000000
    //     0x1307e78: fmov            d0, d30
    // 0x1307e7c: stp             fp, lr, [SP, #-0x10]!
    // 0x1307e80: mov             fp, SP
    // 0x1307e84: CallRuntime_LibcPow(double, double) -> double
    //     0x1307e84: and             SP, SP, #0xfffffffffffffff0
    //     0x1307e88: mov             sp, SP
    //     0x1307e8c: ldr             x16, [THR, #0x740]  ; THR::LibcPow
    //     0x1307e90: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x1307e94: blr             x16
    //     0x1307e98: mov             x16, #8
    //     0x1307e9c: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x1307ea0: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x1307ea4: sub             sp, x16, #1, lsl #12
    //     0x1307ea8: mov             SP, fp
    //     0x1307eac: ldp             fp, lr, [SP], #0x10
    // 0x1307eb0: mov             v1.16b, v0.16b
    // 0x1307eb4: ldur            d0, [fp, #-0x10]
    // 0x1307eb8: fmul            d2, d0, d1
    // 0x1307ebc: stur            d2, [fp, #-0x18]
    // 0x1307ec0: LoadField: d0 = r19->field_1f
    //     0x1307ec0: ldur            d0, [x19, #0x1f]
    // 0x1307ec4: LoadField: d1 = r19->field_f
    //     0x1307ec4: ldur            d1, [x19, #0xf]
    // 0x1307ec8: fmul            d3, d0, d1
    // 0x1307ecc: ldur            d0, [fp, #-8]
    // 0x1307ed0: stur            d3, [fp, #-0x10]
    // 0x1307ed4: fmul            d4, d1, d0
    // 0x1307ed8: mov             v1.16b, v4.16b
    // 0x1307edc: d0 = 2.718282
    //     0x1307edc: add             x17, PP, #0x96, lsl #12  ; [pp+0x96068] IMM: double(2.718281828459045) from 0x4005bf0a8b145769
    //     0x1307ee0: ldr             d0, [x17, #0x68]
    // 0x1307ee4: d30 = 0.000000
    //     0x1307ee4: fmov            d30, d0
    // 0x1307ee8: d0 = 1.000000
    //     0x1307ee8: fmov            d0, #1.00000000
    // 0x1307eec: fcmp            d1, #0.0
    // 0x1307ef0: b.vs            #0x1307f34
    // 0x1307ef4: b.eq            #0x1307fb8
    // 0x1307ef8: fcmp            d1, d0
    // 0x1307efc: b.eq            #0x1307f24
    // 0x1307f00: d31 = 2.000000
    //     0x1307f00: fmov            d31, #2.00000000
    // 0x1307f04: fcmp            d1, d31
    // 0x1307f08: b.eq            #0x1307f2c
    // 0x1307f0c: d31 = 3.000000
    //     0x1307f0c: fmov            d31, #3.00000000
    // 0x1307f10: fcmp            d1, d31
    // 0x1307f14: b.ne            #0x1307f34
    // 0x1307f18: fmul            d0, d30, d30
    // 0x1307f1c: fmul            d0, d0, d30
    // 0x1307f20: b               #0x1307fb8
    // 0x1307f24: d0 = 0.000000
    //     0x1307f24: fmov            d0, d30
    // 0x1307f28: b               #0x1307fb8
    // 0x1307f2c: fmul            d0, d30, d30
    // 0x1307f30: b               #0x1307fb8
    // 0x1307f34: fcmp            d30, d0
    // 0x1307f38: b.vs            #0x1307f48
    // 0x1307f3c: b.eq            #0x1307fb8
    // 0x1307f40: fcmp            d30, d1
    // 0x1307f44: b.vc            #0x1307f50
    // 0x1307f48: d0 = -nan
    //     0x1307f48: ldr             d0, [PP, #0x24c0]  ; [pp+0x24c0] IMM: double(-nan) from 0xfff8000000000000
    // 0x1307f4c: b               #0x1307fb8
    // 0x1307f50: d0 = -inf
    //     0x1307f50: ldr             d0, [PP, #0x5780]  ; [pp+0x5780] IMM: double(-inf) from 0xfff0000000000000
    // 0x1307f54: fcmp            d30, d0
    // 0x1307f58: b.eq            #0x1307f80
    // 0x1307f5c: d0 = 0.500000
    //     0x1307f5c: fmov            d0, #0.50000000
    // 0x1307f60: fcmp            d1, d0
    // 0x1307f64: b.ne            #0x1307f80
    // 0x1307f68: fcmp            d30, #0.0
    // 0x1307f6c: b.eq            #0x1307f78
    // 0x1307f70: fsqrt           d0, d30
    // 0x1307f74: b               #0x1307fb8
    // 0x1307f78: d0 = 0.000000
    //     0x1307f78: eor             v0.16b, v0.16b, v0.16b
    // 0x1307f7c: b               #0x1307fb8
    // 0x1307f80: d0 = 0.000000
    //     0x1307f80: fmov            d0, d30
    // 0x1307f84: stp             fp, lr, [SP, #-0x10]!
    // 0x1307f88: mov             fp, SP
    // 0x1307f8c: CallRuntime_LibcPow(double, double) -> double
    //     0x1307f8c: and             SP, SP, #0xfffffffffffffff0
    //     0x1307f90: mov             sp, SP
    //     0x1307f94: ldr             x16, [THR, #0x740]  ; THR::LibcPow
    //     0x1307f98: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x1307f9c: blr             x16
    //     0x1307fa0: mov             x16, #8
    //     0x1307fa4: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x1307fa8: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x1307fac: sub             sp, x16, #1, lsl #12
    //     0x1307fb0: mov             SP, fp
    //     0x1307fb4: ldp             fp, lr, [SP], #0x10
    // 0x1307fb8: ldur            d1, [fp, #-0x10]
    // 0x1307fbc: fmul            d2, d1, d0
    // 0x1307fc0: ldur            d1, [fp, #-0x18]
    // 0x1307fc4: fadd            d0, d1, d2
    // 0x1307fc8: LeaveFrame
    //     0x1307fc8: mov             SP, fp
    //     0x1307fcc: ldp             fp, lr, [SP], #0x10
    // 0x1307fd0: ret
    //     0x1307fd0: ret             
  }
}

// class id: 2892, size: 0x20, field offset: 0x8
class _CriticalSolution extends Object
    implements _SpringSolution {

  dynamic dx(dynamic) {
    // ** addr: 0xb353dc, size: 0x3c
    // 0xb353dc: EnterFrame
    //     0xb353dc: stp             fp, lr, [SP, #-0x10]!
    //     0xb353e0: mov             fp, SP
    // 0xb353e4: ldr             x2, [fp, #0x10]
    // 0xb353e8: r1 = Function 'dx':.
    //     0xb353e8: add             x1, PP, #0xcf, lsl #12  ; [pp+0xcf998] AnonymousClosure: (0xb35400), in [package:flutter/src/physics/spring_simulation.dart] _CriticalSolution::dx (0x1307c70)
    //     0xb353ec: ldr             x1, [x1, #0x998]
    // 0xb353f0: r0 = AllocateClosure()
    //     0xb353f0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb353f4: LeaveFrame
    //     0xb353f4: mov             SP, fp
    //     0xb353f8: ldp             fp, lr, [SP], #0x10
    // 0xb353fc: ret
    //     0xb353fc: ret             
  }
  factory _ _CriticalSolution(/* No info */) {
    // ** addr: 0xb35364, size: 0x60
    // 0xb35364: EnterFrame
    //     0xb35364: stp             fp, lr, [SP, #-0x10]!
    //     0xb35368: mov             fp, SP
    // 0xb3536c: AllocStack(0x18)
    //     0xb3536c: sub             SP, SP, #0x18
    // 0xb35370: d2 = 2.000000
    //     0xb35370: fmov            d2, #2.00000000
    // 0xb35374: stur            d0, [fp, #-0x18]
    // 0xb35378: ArrayLoad: d3 = r2[0]  ; List_8
    //     0xb35378: ldur            d3, [x2, #0x17]
    // 0xb3537c: fneg            d4, d3
    // 0xb35380: LoadField: d3 = r2->field_7
    //     0xb35380: ldur            d3, [x2, #7]
    // 0xb35384: fmul            d5, d3, d2
    // 0xb35388: fdiv            d2, d4, d5
    // 0xb3538c: stur            d2, [fp, #-0x10]
    // 0xb35390: fmul            d3, d2, d0
    // 0xb35394: fsub            d4, d1, d3
    // 0xb35398: stur            d4, [fp, #-8]
    // 0xb3539c: r0 = _CriticalSolution()
    //     0xb3539c: bl              #0xb3557c  ; Allocate_CriticalSolutionStub -> _CriticalSolution (size=0x20)
    // 0xb353a0: ldur            d0, [fp, #-0x10]
    // 0xb353a4: StoreField: r0->field_7 = d0
    //     0xb353a4: stur            d0, [x0, #7]
    // 0xb353a8: ldur            d0, [fp, #-0x18]
    // 0xb353ac: StoreField: r0->field_f = d0
    //     0xb353ac: stur            d0, [x0, #0xf]
    // 0xb353b0: ldur            d0, [fp, #-8]
    // 0xb353b4: ArrayStore: r0[0] = d0  ; List_8
    //     0xb353b4: stur            d0, [x0, #0x17]
    // 0xb353b8: LeaveFrame
    //     0xb353b8: mov             SP, fp
    //     0xb353bc: ldp             fp, lr, [SP], #0x10
    // 0xb353c0: ret
    //     0xb353c0: ret             
  }
  [closure] double dx(dynamic, double) {
    // ** addr: 0xb35400, size: 0x17c
    // 0xb35400: EnterFrame
    //     0xb35400: stp             fp, lr, [SP, #-0x10]!
    //     0xb35404: mov             fp, SP
    // 0xb35408: AllocStack(0x10)
    //     0xb35408: sub             SP, SP, #0x10
    // 0xb3540c: SetupParameters([dynamic _ /* r19 */])
    //     0xb3540c: ldr             x19, [fp, #0x18]
    //     0xb35410: ldur            w20, [x19, #0x17]
    //     0xb35414: add             x20, x20, HEAP, lsl #32
    // 0xb35418: LoadField: d2 = r20->field_7
    //     0xb35418: ldur            d2, [x20, #7]
    // 0xb3541c: ldr             x19, [fp, #0x10]
    // 0xb35420: stur            d2, [fp, #-0x10]
    // 0xb35424: LoadField: d3 = r19->field_7
    //     0xb35424: ldur            d3, [x19, #7]
    // 0xb35428: stur            d3, [fp, #-8]
    // 0xb3542c: fmul            d1, d2, d3
    // 0xb35430: d0 = 2.718282
    //     0xb35430: add             x17, PP, #0x96, lsl #12  ; [pp+0x96068] IMM: double(2.718281828459045) from 0x4005bf0a8b145769
    //     0xb35434: ldr             d0, [x17, #0x68]
    // 0xb35438: d30 = 0.000000
    //     0xb35438: fmov            d30, d0
    // 0xb3543c: d0 = 1.000000
    //     0xb3543c: fmov            d0, #1.00000000
    // 0xb35440: fcmp            d1, #0.0
    // 0xb35444: b.vs            #0xb35488
    // 0xb35448: b.eq            #0xb3550c
    // 0xb3544c: fcmp            d1, d0
    // 0xb35450: b.eq            #0xb35478
    // 0xb35454: d31 = 2.000000
    //     0xb35454: fmov            d31, #2.00000000
    // 0xb35458: fcmp            d1, d31
    // 0xb3545c: b.eq            #0xb35480
    // 0xb35460: d31 = 3.000000
    //     0xb35460: fmov            d31, #3.00000000
    // 0xb35464: fcmp            d1, d31
    // 0xb35468: b.ne            #0xb35488
    // 0xb3546c: fmul            d0, d30, d30
    // 0xb35470: fmul            d0, d0, d30
    // 0xb35474: b               #0xb3550c
    // 0xb35478: d0 = 0.000000
    //     0xb35478: fmov            d0, d30
    // 0xb3547c: b               #0xb3550c
    // 0xb35480: fmul            d0, d30, d30
    // 0xb35484: b               #0xb3550c
    // 0xb35488: fcmp            d30, d0
    // 0xb3548c: b.vs            #0xb3549c
    // 0xb35490: b.eq            #0xb3550c
    // 0xb35494: fcmp            d30, d1
    // 0xb35498: b.vc            #0xb354a4
    // 0xb3549c: d0 = -nan
    //     0xb3549c: ldr             d0, [PP, #0x24c0]  ; [pp+0x24c0] IMM: double(-nan) from 0xfff8000000000000
    // 0xb354a0: b               #0xb3550c
    // 0xb354a4: d0 = -inf
    //     0xb354a4: ldr             d0, [PP, #0x5780]  ; [pp+0x5780] IMM: double(-inf) from 0xfff0000000000000
    // 0xb354a8: fcmp            d30, d0
    // 0xb354ac: b.eq            #0xb354d4
    // 0xb354b0: d0 = 0.500000
    //     0xb354b0: fmov            d0, #0.50000000
    // 0xb354b4: fcmp            d1, d0
    // 0xb354b8: b.ne            #0xb354d4
    // 0xb354bc: fcmp            d30, #0.0
    // 0xb354c0: b.eq            #0xb354cc
    // 0xb354c4: fsqrt           d0, d30
    // 0xb354c8: b               #0xb3550c
    // 0xb354cc: d0 = 0.000000
    //     0xb354cc: eor             v0.16b, v0.16b, v0.16b
    // 0xb354d0: b               #0xb3550c
    // 0xb354d4: d0 = 0.000000
    //     0xb354d4: fmov            d0, d30
    // 0xb354d8: stp             fp, lr, [SP, #-0x10]!
    // 0xb354dc: mov             fp, SP
    // 0xb354e0: CallRuntime_LibcPow(double, double) -> double
    //     0xb354e0: and             SP, SP, #0xfffffffffffffff0
    //     0xb354e4: mov             sp, SP
    //     0xb354e8: ldr             x16, [THR, #0x740]  ; THR::LibcPow
    //     0xb354ec: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xb354f0: blr             x16
    //     0xb354f4: mov             x16, #8
    //     0xb354f8: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xb354fc: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xb35500: sub             sp, x16, #1, lsl #12
    //     0xb35504: mov             SP, fp
    //     0xb35508: ldp             fp, lr, [SP], #0x10
    // 0xb3550c: LoadField: d1 = r20->field_f
    //     0xb3550c: ldur            d1, [x20, #0xf]
    // 0xb35510: ArrayLoad: d2 = r20[0]  ; List_8
    //     0xb35510: ldur            d2, [x20, #0x17]
    // 0xb35514: ldur            d3, [fp, #-8]
    // 0xb35518: fmul            d4, d2, d3
    // 0xb3551c: fadd            d3, d1, d4
    // 0xb35520: ldur            d1, [fp, #-0x10]
    // 0xb35524: fmul            d4, d1, d3
    // 0xb35528: fmul            d1, d4, d0
    // 0xb3552c: fmul            d3, d2, d0
    // 0xb35530: fadd            d0, d1, d3
    // 0xb35534: r0 = inline_Allocate_Double()
    //     0xb35534: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb35538: add             x0, x0, #0x10
    //     0xb3553c: cmp             x1, x0
    //     0xb35540: b.ls            #0xb3556c
    //     0xb35544: str             x0, [THR, #0x60]  ; THR::top
    //     0xb35548: sub             x0, x0, #0xf
    //     0xb3554c: mov             x1, #0xe19c
    //     0xb35550: movk            x1, #3, lsl #16
    //     0xb35554: stur            x1, [x0, #-1]
    // 0xb35558: dmb             ishst
    // 0xb3555c: StoreField: r0->field_7 = d0
    //     0xb3555c: stur            d0, [x0, #7]
    // 0xb35560: LeaveFrame
    //     0xb35560: mov             SP, fp
    //     0xb35564: ldp             fp, lr, [SP], #0x10
    // 0xb35568: ret
    //     0xb35568: ret             
    // 0xb3556c: SaveReg d0
    //     0xb3556c: str             q0, [SP, #-0x10]!
    // 0xb35570: r0 = AllocateDouble()
    //     0xb35570: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb35574: RestoreReg d0
    //     0xb35574: ldr             q0, [SP], #0x10
    // 0xb35578: b               #0xb3555c
  }
  _ x(/* No info */) {
    // ** addr: 0x1306efc, size: 0x120
    // 0x1306efc: EnterFrame
    //     0x1306efc: stp             fp, lr, [SP, #-0x10]!
    //     0x1306f00: mov             fp, SP
    // 0x1306f04: AllocStack(0x8)
    //     0x1306f04: sub             SP, SP, #8
    // 0x1306f08: LoadField: d1 = r1->field_f
    //     0x1306f08: ldur            d1, [x1, #0xf]
    // 0x1306f0c: ArrayLoad: d2 = r1[0]  ; List_8
    //     0x1306f0c: ldur            d2, [x1, #0x17]
    // 0x1306f10: fmul            d3, d2, d0
    // 0x1306f14: fadd            d2, d1, d3
    // 0x1306f18: stur            d2, [fp, #-8]
    // 0x1306f1c: LoadField: d1 = r1->field_7
    //     0x1306f1c: ldur            d1, [x1, #7]
    // 0x1306f20: fmul            d3, d1, d0
    // 0x1306f24: mov             v1.16b, v3.16b
    // 0x1306f28: d0 = 2.718282
    //     0x1306f28: add             x17, PP, #0x96, lsl #12  ; [pp+0x96068] IMM: double(2.718281828459045) from 0x4005bf0a8b145769
    //     0x1306f2c: ldr             d0, [x17, #0x68]
    // 0x1306f30: d30 = 0.000000
    //     0x1306f30: fmov            d30, d0
    // 0x1306f34: d0 = 1.000000
    //     0x1306f34: fmov            d0, #1.00000000
    // 0x1306f38: fcmp            d1, #0.0
    // 0x1306f3c: b.vs            #0x1306f80
    // 0x1306f40: b.eq            #0x1307004
    // 0x1306f44: fcmp            d1, d0
    // 0x1306f48: b.eq            #0x1306f70
    // 0x1306f4c: d31 = 2.000000
    //     0x1306f4c: fmov            d31, #2.00000000
    // 0x1306f50: fcmp            d1, d31
    // 0x1306f54: b.eq            #0x1306f78
    // 0x1306f58: d31 = 3.000000
    //     0x1306f58: fmov            d31, #3.00000000
    // 0x1306f5c: fcmp            d1, d31
    // 0x1306f60: b.ne            #0x1306f80
    // 0x1306f64: fmul            d0, d30, d30
    // 0x1306f68: fmul            d0, d0, d30
    // 0x1306f6c: b               #0x1307004
    // 0x1306f70: d0 = 0.000000
    //     0x1306f70: fmov            d0, d30
    // 0x1306f74: b               #0x1307004
    // 0x1306f78: fmul            d0, d30, d30
    // 0x1306f7c: b               #0x1307004
    // 0x1306f80: fcmp            d30, d0
    // 0x1306f84: b.vs            #0x1306f94
    // 0x1306f88: b.eq            #0x1307004
    // 0x1306f8c: fcmp            d30, d1
    // 0x1306f90: b.vc            #0x1306f9c
    // 0x1306f94: d0 = -nan
    //     0x1306f94: ldr             d0, [PP, #0x24c0]  ; [pp+0x24c0] IMM: double(-nan) from 0xfff8000000000000
    // 0x1306f98: b               #0x1307004
    // 0x1306f9c: d0 = -inf
    //     0x1306f9c: ldr             d0, [PP, #0x5780]  ; [pp+0x5780] IMM: double(-inf) from 0xfff0000000000000
    // 0x1306fa0: fcmp            d30, d0
    // 0x1306fa4: b.eq            #0x1306fcc
    // 0x1306fa8: d0 = 0.500000
    //     0x1306fa8: fmov            d0, #0.50000000
    // 0x1306fac: fcmp            d1, d0
    // 0x1306fb0: b.ne            #0x1306fcc
    // 0x1306fb4: fcmp            d30, #0.0
    // 0x1306fb8: b.eq            #0x1306fc4
    // 0x1306fbc: fsqrt           d0, d30
    // 0x1306fc0: b               #0x1307004
    // 0x1306fc4: d0 = 0.000000
    //     0x1306fc4: eor             v0.16b, v0.16b, v0.16b
    // 0x1306fc8: b               #0x1307004
    // 0x1306fcc: d0 = 0.000000
    //     0x1306fcc: fmov            d0, d30
    // 0x1306fd0: stp             fp, lr, [SP, #-0x10]!
    // 0x1306fd4: mov             fp, SP
    // 0x1306fd8: CallRuntime_LibcPow(double, double) -> double
    //     0x1306fd8: and             SP, SP, #0xfffffffffffffff0
    //     0x1306fdc: mov             sp, SP
    //     0x1306fe0: ldr             x16, [THR, #0x740]  ; THR::LibcPow
    //     0x1306fe4: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x1306fe8: blr             x16
    //     0x1306fec: mov             x16, #8
    //     0x1306ff0: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x1306ff4: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x1306ff8: sub             sp, x16, #1, lsl #12
    //     0x1306ffc: mov             SP, fp
    //     0x1307000: ldp             fp, lr, [SP], #0x10
    // 0x1307004: ldur            d1, [fp, #-8]
    // 0x1307008: fmul            d2, d1, d0
    // 0x130700c: mov             v0.16b, v2.16b
    // 0x1307010: LeaveFrame
    //     0x1307010: mov             SP, fp
    //     0x1307014: ldp             fp, lr, [SP], #0x10
    // 0x1307018: ret
    //     0x1307018: ret             
  }
  _ dx(/* No info */) {
    // ** addr: 0x1307c70, size: 0x134
    // 0x1307c70: EnterFrame
    //     0x1307c70: stp             fp, lr, [SP, #-0x10]!
    //     0x1307c74: mov             fp, SP
    // 0x1307c78: AllocStack(0x10)
    //     0x1307c78: sub             SP, SP, #0x10
    // 0x1307c7c: SetupParameters(_CriticalSolution this /* r1 => r19 */)
    //     0x1307c7c: mov             x19, x1
    // 0x1307c80: LoadField: d2 = r19->field_7
    //     0x1307c80: ldur            d2, [x19, #7]
    // 0x1307c84: stur            d2, [fp, #-0x10]
    // 0x1307c88: LoadField: d3 = r2->field_7
    //     0x1307c88: ldur            d3, [x2, #7]
    // 0x1307c8c: stur            d3, [fp, #-8]
    // 0x1307c90: fmul            d1, d2, d3
    // 0x1307c94: d0 = 2.718282
    //     0x1307c94: add             x17, PP, #0x96, lsl #12  ; [pp+0x96068] IMM: double(2.718281828459045) from 0x4005bf0a8b145769
    //     0x1307c98: ldr             d0, [x17, #0x68]
    // 0x1307c9c: d30 = 0.000000
    //     0x1307c9c: fmov            d30, d0
    // 0x1307ca0: d0 = 1.000000
    //     0x1307ca0: fmov            d0, #1.00000000
    // 0x1307ca4: fcmp            d1, #0.0
    // 0x1307ca8: b.vs            #0x1307cec
    // 0x1307cac: b.eq            #0x1307d70
    // 0x1307cb0: fcmp            d1, d0
    // 0x1307cb4: b.eq            #0x1307cdc
    // 0x1307cb8: d31 = 2.000000
    //     0x1307cb8: fmov            d31, #2.00000000
    // 0x1307cbc: fcmp            d1, d31
    // 0x1307cc0: b.eq            #0x1307ce4
    // 0x1307cc4: d31 = 3.000000
    //     0x1307cc4: fmov            d31, #3.00000000
    // 0x1307cc8: fcmp            d1, d31
    // 0x1307ccc: b.ne            #0x1307cec
    // 0x1307cd0: fmul            d0, d30, d30
    // 0x1307cd4: fmul            d0, d0, d30
    // 0x1307cd8: b               #0x1307d70
    // 0x1307cdc: d0 = 0.000000
    //     0x1307cdc: fmov            d0, d30
    // 0x1307ce0: b               #0x1307d70
    // 0x1307ce4: fmul            d0, d30, d30
    // 0x1307ce8: b               #0x1307d70
    // 0x1307cec: fcmp            d30, d0
    // 0x1307cf0: b.vs            #0x1307d00
    // 0x1307cf4: b.eq            #0x1307d70
    // 0x1307cf8: fcmp            d30, d1
    // 0x1307cfc: b.vc            #0x1307d08
    // 0x1307d00: d0 = -nan
    //     0x1307d00: ldr             d0, [PP, #0x24c0]  ; [pp+0x24c0] IMM: double(-nan) from 0xfff8000000000000
    // 0x1307d04: b               #0x1307d70
    // 0x1307d08: d0 = -inf
    //     0x1307d08: ldr             d0, [PP, #0x5780]  ; [pp+0x5780] IMM: double(-inf) from 0xfff0000000000000
    // 0x1307d0c: fcmp            d30, d0
    // 0x1307d10: b.eq            #0x1307d38
    // 0x1307d14: d0 = 0.500000
    //     0x1307d14: fmov            d0, #0.50000000
    // 0x1307d18: fcmp            d1, d0
    // 0x1307d1c: b.ne            #0x1307d38
    // 0x1307d20: fcmp            d30, #0.0
    // 0x1307d24: b.eq            #0x1307d30
    // 0x1307d28: fsqrt           d0, d30
    // 0x1307d2c: b               #0x1307d70
    // 0x1307d30: d0 = 0.000000
    //     0x1307d30: eor             v0.16b, v0.16b, v0.16b
    // 0x1307d34: b               #0x1307d70
    // 0x1307d38: d0 = 0.000000
    //     0x1307d38: fmov            d0, d30
    // 0x1307d3c: stp             fp, lr, [SP, #-0x10]!
    // 0x1307d40: mov             fp, SP
    // 0x1307d44: CallRuntime_LibcPow(double, double) -> double
    //     0x1307d44: and             SP, SP, #0xfffffffffffffff0
    //     0x1307d48: mov             sp, SP
    //     0x1307d4c: ldr             x16, [THR, #0x740]  ; THR::LibcPow
    //     0x1307d50: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x1307d54: blr             x16
    //     0x1307d58: mov             x16, #8
    //     0x1307d5c: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x1307d60: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x1307d64: sub             sp, x16, #1, lsl #12
    //     0x1307d68: mov             SP, fp
    //     0x1307d6c: ldp             fp, lr, [SP], #0x10
    // 0x1307d70: LoadField: d1 = r19->field_f
    //     0x1307d70: ldur            d1, [x19, #0xf]
    // 0x1307d74: ArrayLoad: d2 = r19[0]  ; List_8
    //     0x1307d74: ldur            d2, [x19, #0x17]
    // 0x1307d78: ldur            d3, [fp, #-8]
    // 0x1307d7c: fmul            d4, d2, d3
    // 0x1307d80: fadd            d3, d1, d4
    // 0x1307d84: ldur            d1, [fp, #-0x10]
    // 0x1307d88: fmul            d4, d1, d3
    // 0x1307d8c: fmul            d1, d4, d0
    // 0x1307d90: fmul            d3, d2, d0
    // 0x1307d94: fadd            d0, d1, d3
    // 0x1307d98: LeaveFrame
    //     0x1307d98: mov             SP, fp
    //     0x1307d9c: ldp             fp, lr, [SP], #0x10
    // 0x1307da0: ret
    //     0x1307da0: ret             
  }
}

// class id: 2893, size: 0x8, field offset: 0x8
abstract class _SpringSolution extends Object {

  factory _ _SpringSolution(/* No info */) {
    // ** addr: 0xb352e8, size: 0x7c
    // 0xb352e8: EnterFrame
    //     0xb352e8: stp             fp, lr, [SP, #-0x10]!
    //     0xb352ec: mov             fp, SP
    // 0xb352f0: d3 = 4.000000
    //     0xb352f0: fmov            d3, #4.00000000
    // 0xb352f4: d2 = 0.000000
    //     0xb352f4: eor             v2.16b, v2.16b, v2.16b
    // 0xb352f8: CheckStackOverflow
    //     0xb352f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb352fc: cmp             SP, x16
    //     0xb35300: b.ls            #0xb3535c
    // 0xb35304: ArrayLoad: d4 = r2[0]  ; List_8
    //     0xb35304: ldur            d4, [x2, #0x17]
    // 0xb35308: fmul            d5, d4, d4
    // 0xb3530c: LoadField: d4 = r2->field_7
    //     0xb3530c: ldur            d4, [x2, #7]
    // 0xb35310: fmul            d6, d4, d3
    // 0xb35314: LoadField: d3 = r2->field_f
    //     0xb35314: ldur            d3, [x2, #0xf]
    // 0xb35318: fmul            d4, d6, d3
    // 0xb3531c: fsub            d3, d5, d4
    // 0xb35320: fcmp            d3, d2
    // 0xb35324: b.le            #0xb35334
    // 0xb35328: r1 = Null
    //     0xb35328: mov             x1, NULL
    // 0xb3532c: r0 = _OverdampedSolution()
    //     0xb3532c: bl              #0xb35894  ; [package:flutter/src/physics/spring_simulation.dart] _OverdampedSolution::_OverdampedSolution
    // 0xb35330: b               #0xb35350
    // 0xb35334: fcmp            d2, d3
    // 0xb35338: b.le            #0xb35348
    // 0xb3533c: r1 = Null
    //     0xb3533c: mov             x1, NULL
    // 0xb35340: r0 = _UnderdampedSolution()
    //     0xb35340: bl              #0xb35588  ; [package:flutter/src/physics/spring_simulation.dart] _UnderdampedSolution::_UnderdampedSolution
    // 0xb35344: b               #0xb35350
    // 0xb35348: r1 = Null
    //     0xb35348: mov             x1, NULL
    // 0xb3534c: r0 = _CriticalSolution()
    //     0xb3534c: bl              #0xb35364  ; [package:flutter/src/physics/spring_simulation.dart] _CriticalSolution::_CriticalSolution
    // 0xb35350: LeaveFrame
    //     0xb35350: mov             SP, fp
    //     0xb35354: ldp             fp, lr, [SP], #0x10
    // 0xb35358: ret
    //     0xb35358: ret             
    // 0xb3535c: r0 = StackOverflowSharedWithFPURegs()
    //     0xb3535c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb35360: b               #0xb35304
  }
}

// class id: 2894, size: 0x20, field offset: 0x8
//   const constructor, 
class SpringDescription extends Object {

  _Double field_8;
  _Double field_10;
  _Double field_18;
}

// class id: 3340, size: 0x1c, field offset: 0xc
class SpringSimulation extends Simulation {

  dynamic dx(dynamic) {
    // ** addr: 0x1183eac, size: 0x3c
    // 0x1183eac: EnterFrame
    //     0x1183eac: stp             fp, lr, [SP, #-0x10]!
    //     0x1183eb0: mov             fp, SP
    // 0x1183eb4: ldr             x2, [fp, #0x10]
    // 0x1183eb8: r1 = Function 'dx':.
    //     0x1183eb8: add             x1, PP, #0xcf, lsl #12  ; [pp+0xcf9a8] AnonymousClosure: (0xb35270), in [package:flutter/src/physics/spring_simulation.dart] SpringSimulation::dx (0x12dc614)
    //     0x1183ebc: ldr             x1, [x1, #0x9a8]
    // 0x1183ec0: r0 = AllocateClosure()
    //     0x1183ec0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1183ec4: LeaveFrame
    //     0x1183ec4: mov             SP, fp
    //     0x1183ec8: ldp             fp, lr, [SP], #0x10
    // 0x1183ecc: ret
    //     0x1183ecc: ret             
  }
  _ SpringSimulation(/* No info */) {
    // ** addr: 0xb35128, size: 0x148
    // 0xb35128: EnterFrame
    //     0xb35128: stp             fp, lr, [SP, #-0x10]!
    //     0xb3512c: mov             fp, SP
    // 0xb35130: AllocStack(0x18)
    //     0xb35130: sub             SP, SP, #0x18
    // 0xb35134: SetupParameters(SpringSimulation this /* r1 => d1, fp-0x18 */, dynamic _ /* d0 => d2 */, dynamic _ /* d1 => d0 */)
    //     0xb35134: mov             x0, x1
    //     0xb35138: mov             v31.16b, v1.16b
    //     0xb3513c: mov             v1.16b, v0.16b
    //     0xb35140: mov             v0.16b, v31.16b
    //     0xb35144: mov             v31.16b, v2.16b
    //     0xb35148: mov             v2.16b, v1.16b
    //     0xb3514c: mov             v1.16b, v31.16b
    //     0xb35150: stur            x1, [fp, #-0x18]
    // 0xb35154: LoadField: r1 = r4->field_13
    //     0xb35154: ldur            w1, [x4, #0x13]
    // 0xb35158: LoadField: r3 = r4->field_1f
    //     0xb35158: ldur            w3, [x4, #0x1f]
    // 0xb3515c: DecompressPointer r3
    //     0xb3515c: add             x3, x3, HEAP, lsl #32
    // 0xb35160: r16 = "snapToEnd"
    //     0xb35160: add             x16, PP, #0x83, lsl #12  ; [pp+0x83800] "snapToEnd"
    //     0xb35164: ldr             x16, [x16, #0x800]
    // 0xb35168: cmp             w3, w16
    // 0xb3516c: b.ne            #0xb35190
    // 0xb35170: LoadField: r3 = r4->field_23
    //     0xb35170: ldur            w3, [x4, #0x23]
    // 0xb35174: DecompressPointer r3
    //     0xb35174: add             x3, x3, HEAP, lsl #32
    // 0xb35178: sub             w5, w1, w3
    // 0xb3517c: add             x3, fp, w5, sxtw #2
    // 0xb35180: ldr             x3, [x3, #8]
    // 0xb35184: mov             x5, x3
    // 0xb35188: r3 = 1
    //     0xb35188: mov             x3, #1
    // 0xb3518c: b               #0xb35198
    // 0xb35190: r5 = false
    //     0xb35190: add             x5, NULL, #0x30  ; false
    // 0xb35194: r3 = 0
    //     0xb35194: mov             x3, #0
    // 0xb35198: stur            x5, [fp, #-0x10]
    // 0xb3519c: lsl             x6, x3, #1
    // 0xb351a0: lsl             w3, w6, #1
    // 0xb351a4: add             w6, w3, #8
    // 0xb351a8: ArrayLoad: r7 = r4[r6]  ; Unknown_4
    //     0xb351a8: add             x16, x4, w6, sxtw #1
    //     0xb351ac: ldur            w7, [x16, #0xf]
    // 0xb351b0: DecompressPointer r7
    //     0xb351b0: add             x7, x7, HEAP, lsl #32
    // 0xb351b4: r16 = "tolerance"
    //     0xb351b4: add             x16, PP, #0x83, lsl #12  ; [pp+0x83808] "tolerance"
    //     0xb351b8: ldr             x16, [x16, #0x808]
    // 0xb351bc: cmp             w7, w16
    // 0xb351c0: b.ne            #0xb351e8
    // 0xb351c4: add             w6, w3, #0xa
    // 0xb351c8: ArrayLoad: r3 = r4[r6]  ; Unknown_4
    //     0xb351c8: add             x16, x4, w6, sxtw #1
    //     0xb351cc: ldur            w3, [x16, #0xf]
    // 0xb351d0: DecompressPointer r3
    //     0xb351d0: add             x3, x3, HEAP, lsl #32
    // 0xb351d4: sub             w4, w1, w3
    // 0xb351d8: add             x1, fp, w4, sxtw #2
    // 0xb351dc: ldr             x1, [x1, #8]
    // 0xb351e0: mov             x3, x1
    // 0xb351e4: b               #0xb351ec
    // 0xb351e8: r3 = Instance_Tolerance
    //     0xb351e8: ldr             x3, [PP, #0x51d8]  ; [pp+0x51d8] Obj!Tolerance@129c5c1
    // 0xb351ec: stur            x3, [fp, #-8]
    // 0xb351f0: CheckStackOverflow
    //     0xb351f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb351f4: cmp             SP, x16
    //     0xb351f8: b.ls            #0xb35268
    // 0xb351fc: StoreField: r0->field_b = d0
    //     0xb351fc: stur            d0, [x0, #0xb]
    // 0xb35200: fsub            d3, d2, d0
    // 0xb35204: mov             v0.16b, v3.16b
    // 0xb35208: r1 = Null
    //     0xb35208: mov             x1, NULL
    // 0xb3520c: r0 = _SpringSolution()
    //     0xb3520c: bl              #0xb352e8  ; [package:flutter/src/physics/spring_simulation.dart] _SpringSolution::_SpringSolution
    // 0xb35210: ldur            x1, [fp, #-0x18]
    // 0xb35214: StoreField: r1->field_13 = r0
    //     0xb35214: stur            w0, [x1, #0x13]
    //     0xb35218: ldurb           w16, [x1, #-1]
    //     0xb3521c: ldurb           w17, [x0, #-1]
    //     0xb35220: and             x16, x17, x16, lsr #2
    //     0xb35224: tst             x16, HEAP, lsr #32
    //     0xb35228: b.eq            #0xb35230
    //     0xb3522c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb35230: ldur            x2, [fp, #-0x10]
    // 0xb35234: ArrayStore: r1[0] = r2  ; List_4
    //     0xb35234: stur            w2, [x1, #0x17]
    // 0xb35238: ldur            x0, [fp, #-8]
    // 0xb3523c: StoreField: r1->field_7 = r0
    //     0xb3523c: stur            w0, [x1, #7]
    //     0xb35240: ldurb           w16, [x1, #-1]
    //     0xb35244: ldurb           w17, [x0, #-1]
    //     0xb35248: and             x16, x17, x16, lsr #2
    //     0xb3524c: tst             x16, HEAP, lsr #32
    //     0xb35250: b.eq            #0xb35258
    //     0xb35254: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb35258: r0 = Null
    //     0xb35258: mov             x0, NULL
    // 0xb3525c: LeaveFrame
    //     0xb3525c: mov             SP, fp
    //     0xb35260: ldp             fp, lr, [SP], #0x10
    // 0xb35264: ret
    //     0xb35264: ret             
    // 0xb35268: r0 = StackOverflowSharedWithFPURegs()
    //     0xb35268: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb3526c: b               #0xb351fc
  }
  [closure] double dx(dynamic, double) {
    // ** addr: 0xb35270, size: 0x78
    // 0xb35270: EnterFrame
    //     0xb35270: stp             fp, lr, [SP, #-0x10]!
    //     0xb35274: mov             fp, SP
    // 0xb35278: ldr             x0, [fp, #0x18]
    // 0xb3527c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb3527c: ldur            w1, [x0, #0x17]
    // 0xb35280: DecompressPointer r1
    //     0xb35280: add             x1, x1, HEAP, lsl #32
    // 0xb35284: CheckStackOverflow
    //     0xb35284: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb35288: cmp             SP, x16
    //     0xb3528c: b.ls            #0xb352d0
    // 0xb35290: ldr             x2, [fp, #0x10]
    // 0xb35294: r0 = dx()
    //     0xb35294: bl              #0x12dc614  ; [package:flutter/src/physics/spring_simulation.dart] SpringSimulation::dx
    // 0xb35298: r0 = inline_Allocate_Double()
    //     0xb35298: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb3529c: add             x0, x0, #0x10
    //     0xb352a0: cmp             x1, x0
    //     0xb352a4: b.ls            #0xb352d8
    //     0xb352a8: str             x0, [THR, #0x60]  ; THR::top
    //     0xb352ac: sub             x0, x0, #0xf
    //     0xb352b0: mov             x1, #0xe19c
    //     0xb352b4: movk            x1, #3, lsl #16
    //     0xb352b8: stur            x1, [x0, #-1]
    // 0xb352bc: dmb             ishst
    // 0xb352c0: StoreField: r0->field_7 = d0
    //     0xb352c0: stur            d0, [x0, #7]
    // 0xb352c4: LeaveFrame
    //     0xb352c4: mov             SP, fp
    //     0xb352c8: ldp             fp, lr, [SP], #0x10
    // 0xb352cc: ret
    //     0xb352cc: ret             
    // 0xb352d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb352d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb352d4: b               #0xb35290
    // 0xb352d8: SaveReg d0
    //     0xb352d8: str             q0, [SP, #-0x10]!
    // 0xb352dc: r0 = AllocateDouble()
    //     0xb352dc: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb352e0: RestoreReg d0
    //     0xb352e0: ldr             q0, [SP], #0x10
    // 0xb352e4: b               #0xb352c0
  }
  _ isDone(/* No info */) {
    // ** addr: 0x12d8cb0, size: 0x100
    // 0x12d8cb0: EnterFrame
    //     0x12d8cb0: stp             fp, lr, [SP, #-0x10]!
    //     0x12d8cb4: mov             fp, SP
    // 0x12d8cb8: AllocStack(0x18)
    //     0x12d8cb8: sub             SP, SP, #0x18
    // 0x12d8cbc: SetupParameters(SpringSimulation this /* r1 => r2, fp-0x10 */, dynamic _ /* d0 => d1, fp-0x18 */)
    //     0x12d8cbc: mov             x2, x1
    //     0x12d8cc0: mov             v1.16b, v0.16b
    //     0x12d8cc4: stur            x1, [fp, #-0x10]
    //     0x12d8cc8: stur            d0, [fp, #-0x18]
    // 0x12d8ccc: CheckStackOverflow
    //     0x12d8ccc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12d8cd0: cmp             SP, x16
    //     0x12d8cd4: b.ls            #0x12d8d8c
    // 0x12d8cd8: LoadField: r3 = r2->field_13
    //     0x12d8cd8: ldur            w3, [x2, #0x13]
    // 0x12d8cdc: DecompressPointer r3
    //     0x12d8cdc: add             x3, x3, HEAP, lsl #32
    // 0x12d8ce0: stur            x3, [fp, #-8]
    // 0x12d8ce4: r0 = LoadClassIdInstr(r3)
    //     0x12d8ce4: ldur            x0, [x3, #-1]
    //     0x12d8ce8: ubfx            x0, x0, #0xc, #0x14
    // 0x12d8cec: mov             x1, x3
    // 0x12d8cf0: mov             v0.16b, v1.16b
    // 0x12d8cf4: r0 = GDT[cid_x0 + -0xfef]()
    //     0x12d8cf4: sub             lr, x0, #0xfef
    //     0x12d8cf8: ldr             lr, [x21, lr, lsl #3]
    //     0x12d8cfc: blr             lr
    // 0x12d8d00: ldur            x0, [fp, #-0x10]
    // 0x12d8d04: LoadField: r1 = r0->field_7
    //     0x12d8d04: ldur            w1, [x0, #7]
    // 0x12d8d08: DecompressPointer r1
    //     0x12d8d08: add             x1, x1, HEAP, lsl #32
    // 0x12d8d0c: LoadField: d1 = r1->field_7
    //     0x12d8d0c: ldur            d1, [x1, #7]
    // 0x12d8d10: r0 = nearZero()
    //     0x12d8d10: bl              #0x12d8db0  ; [package:flutter/src/physics/utils.dart] ::nearZero
    // 0x12d8d14: tbnz            w0, #4, #0x12d8d7c
    // 0x12d8d18: ldur            x3, [fp, #-0x10]
    // 0x12d8d1c: ldur            d0, [fp, #-0x18]
    // 0x12d8d20: ldur            x1, [fp, #-8]
    // 0x12d8d24: r2 = inline_Allocate_Double()
    //     0x12d8d24: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0x12d8d28: add             x2, x2, #0x10
    //     0x12d8d2c: cmp             x0, x2
    //     0x12d8d30: b.ls            #0x12d8d94
    //     0x12d8d34: str             x2, [THR, #0x60]  ; THR::top
    //     0x12d8d38: sub             x2, x2, #0xf
    //     0x12d8d3c: mov             x0, #0xe19c
    //     0x12d8d40: movk            x0, #3, lsl #16
    //     0x12d8d44: stur            x0, [x2, #-1]
    // 0x12d8d48: dmb             ishst
    // 0x12d8d4c: StoreField: r2->field_7 = d0
    //     0x12d8d4c: stur            d0, [x2, #7]
    // 0x12d8d50: r0 = LoadClassIdInstr(r1)
    //     0x12d8d50: ldur            x0, [x1, #-1]
    //     0x12d8d54: ubfx            x0, x0, #0xc, #0x14
    // 0x12d8d58: r0 = GDT[cid_x0 + -0x1000]()
    //     0x12d8d58: sub             lr, x0, #1, lsl #12
    //     0x12d8d5c: ldr             lr, [x21, lr, lsl #3]
    //     0x12d8d60: blr             lr
    // 0x12d8d64: ldur            x0, [fp, #-0x10]
    // 0x12d8d68: LoadField: r1 = r0->field_7
    //     0x12d8d68: ldur            w1, [x0, #7]
    // 0x12d8d6c: DecompressPointer r1
    //     0x12d8d6c: add             x1, x1, HEAP, lsl #32
    // 0x12d8d70: ArrayLoad: d1 = r1[0]  ; List_8
    //     0x12d8d70: ldur            d1, [x1, #0x17]
    // 0x12d8d74: r0 = nearZero()
    //     0x12d8d74: bl              #0x12d8db0  ; [package:flutter/src/physics/utils.dart] ::nearZero
    // 0x12d8d78: b               #0x12d8d80
    // 0x12d8d7c: r0 = false
    //     0x12d8d7c: add             x0, NULL, #0x30  ; false
    // 0x12d8d80: LeaveFrame
    //     0x12d8d80: mov             SP, fp
    //     0x12d8d84: ldp             fp, lr, [SP], #0x10
    // 0x12d8d88: ret
    //     0x12d8d88: ret             
    // 0x12d8d8c: r0 = StackOverflowSharedWithFPURegs()
    //     0x12d8d8c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12d8d90: b               #0x12d8cd8
    // 0x12d8d94: SaveReg d0
    //     0x12d8d94: str             q0, [SP, #-0x10]!
    // 0x12d8d98: stp             x1, x3, [SP, #-0x10]!
    // 0x12d8d9c: r0 = AllocateDouble()
    //     0x12d8d9c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x12d8da0: mov             x2, x0
    // 0x12d8da4: ldp             x1, x3, [SP], #0x10
    // 0x12d8da8: RestoreReg d0
    //     0x12d8da8: ldr             q0, [SP], #0x10
    // 0x12d8dac: b               #0x12d8d4c
  }
  _ dx(/* No info */) {
    // ** addr: 0x12dc614, size: 0x88
    // 0x12dc614: EnterFrame
    //     0x12dc614: stp             fp, lr, [SP, #-0x10]!
    //     0x12dc618: mov             fp, SP
    // 0x12dc61c: AllocStack(0x10)
    //     0x12dc61c: sub             SP, SP, #0x10
    // 0x12dc620: SetupParameters(SpringSimulation this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x12dc620: mov             x0, x1
    //     0x12dc624: stur            x1, [fp, #-8]
    //     0x12dc628: stur            x2, [fp, #-0x10]
    // 0x12dc62c: CheckStackOverflow
    //     0x12dc62c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12dc630: cmp             SP, x16
    //     0x12dc634: b.ls            #0x12dc694
    // 0x12dc638: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x12dc638: ldur            w1, [x0, #0x17]
    // 0x12dc63c: DecompressPointer r1
    //     0x12dc63c: add             x1, x1, HEAP, lsl #32
    // 0x12dc640: tbnz            w1, #4, #0x12dc664
    // 0x12dc644: LoadField: d0 = r2->field_7
    //     0x12dc644: ldur            d0, [x2, #7]
    // 0x12dc648: mov             x1, x0
    // 0x12dc64c: r0 = isDone()
    //     0x12dc64c: bl              #0x12d8cb0  ; [package:flutter/src/physics/spring_simulation.dart] SpringSimulation::isDone
    // 0x12dc650: tbnz            w0, #4, #0x12dc664
    // 0x12dc654: d0 = 0.000000
    //     0x12dc654: eor             v0.16b, v0.16b, v0.16b
    // 0x12dc658: LeaveFrame
    //     0x12dc658: mov             SP, fp
    //     0x12dc65c: ldp             fp, lr, [SP], #0x10
    // 0x12dc660: ret
    //     0x12dc660: ret             
    // 0x12dc664: ldur            x0, [fp, #-8]
    // 0x12dc668: LoadField: r1 = r0->field_13
    //     0x12dc668: ldur            w1, [x0, #0x13]
    // 0x12dc66c: DecompressPointer r1
    //     0x12dc66c: add             x1, x1, HEAP, lsl #32
    // 0x12dc670: r0 = LoadClassIdInstr(r1)
    //     0x12dc670: ldur            x0, [x1, #-1]
    //     0x12dc674: ubfx            x0, x0, #0xc, #0x14
    // 0x12dc678: ldur            x2, [fp, #-0x10]
    // 0x12dc67c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x12dc67c: sub             lr, x0, #1, lsl #12
    //     0x12dc680: ldr             lr, [x21, lr, lsl #3]
    //     0x12dc684: blr             lr
    // 0x12dc688: LeaveFrame
    //     0x12dc688: mov             SP, fp
    //     0x12dc68c: ldp             fp, lr, [SP], #0x10
    // 0x12dc690: ret
    //     0x12dc690: ret             
    // 0x12dc694: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12dc694: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12dc698: b               #0x12dc638
  }
  _ x(/* No info */) {
    // ** addr: 0x12f1ac4, size: 0x120
    // 0x12f1ac4: EnterFrame
    //     0x12f1ac4: stp             fp, lr, [SP, #-0x10]!
    //     0x12f1ac8: mov             fp, SP
    // 0x12f1acc: AllocStack(0x18)
    //     0x12f1acc: sub             SP, SP, #0x18
    // 0x12f1ad0: SetupParameters(SpringSimulation this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x12f1ad0: mov             x0, x1
    //     0x12f1ad4: stur            x1, [fp, #-8]
    //     0x12f1ad8: stur            x2, [fp, #-0x10]
    // 0x12f1adc: CheckStackOverflow
    //     0x12f1adc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f1ae0: cmp             SP, x16
    //     0x12f1ae4: b.ls            #0x12f1bbc
    // 0x12f1ae8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x12f1ae8: ldur            w1, [x0, #0x17]
    // 0x12f1aec: DecompressPointer r1
    //     0x12f1aec: add             x1, x1, HEAP, lsl #32
    // 0x12f1af0: tbnz            w1, #4, #0x12f1b48
    // 0x12f1af4: LoadField: d0 = r2->field_7
    //     0x12f1af4: ldur            d0, [x2, #7]
    // 0x12f1af8: mov             x1, x0
    // 0x12f1afc: r0 = isDone()
    //     0x12f1afc: bl              #0x12d8cb0  ; [package:flutter/src/physics/spring_simulation.dart] SpringSimulation::isDone
    // 0x12f1b00: tbnz            w0, #4, #0x12f1b44
    // 0x12f1b04: ldur            x0, [fp, #-8]
    // 0x12f1b08: LoadField: d0 = r0->field_b
    //     0x12f1b08: ldur            d0, [x0, #0xb]
    // 0x12f1b0c: r0 = inline_Allocate_Double()
    //     0x12f1b0c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x12f1b10: add             x0, x0, #0x10
    //     0x12f1b14: cmp             x1, x0
    //     0x12f1b18: b.ls            #0x12f1bc4
    //     0x12f1b1c: str             x0, [THR, #0x60]  ; THR::top
    //     0x12f1b20: sub             x0, x0, #0xf
    //     0x12f1b24: mov             x1, #0xe19c
    //     0x12f1b28: movk            x1, #3, lsl #16
    //     0x12f1b2c: stur            x1, [x0, #-1]
    // 0x12f1b30: dmb             ishst
    // 0x12f1b34: StoreField: r0->field_7 = d0
    //     0x12f1b34: stur            d0, [x0, #7]
    // 0x12f1b38: LeaveFrame
    //     0x12f1b38: mov             SP, fp
    //     0x12f1b3c: ldp             fp, lr, [SP], #0x10
    // 0x12f1b40: ret
    //     0x12f1b40: ret             
    // 0x12f1b44: ldur            x0, [fp, #-8]
    // 0x12f1b48: ldur            x1, [fp, #-0x10]
    // 0x12f1b4c: LoadField: d1 = r0->field_b
    //     0x12f1b4c: ldur            d1, [x0, #0xb]
    // 0x12f1b50: stur            d1, [fp, #-0x18]
    // 0x12f1b54: LoadField: r2 = r0->field_13
    //     0x12f1b54: ldur            w2, [x0, #0x13]
    // 0x12f1b58: DecompressPointer r2
    //     0x12f1b58: add             x2, x2, HEAP, lsl #32
    // 0x12f1b5c: LoadField: d0 = r1->field_7
    //     0x12f1b5c: ldur            d0, [x1, #7]
    // 0x12f1b60: r0 = LoadClassIdInstr(r2)
    //     0x12f1b60: ldur            x0, [x2, #-1]
    //     0x12f1b64: ubfx            x0, x0, #0xc, #0x14
    // 0x12f1b68: mov             x1, x2
    // 0x12f1b6c: r0 = GDT[cid_x0 + -0xfef]()
    //     0x12f1b6c: sub             lr, x0, #0xfef
    //     0x12f1b70: ldr             lr, [x21, lr, lsl #3]
    //     0x12f1b74: blr             lr
    // 0x12f1b78: mov             v1.16b, v0.16b
    // 0x12f1b7c: ldur            d0, [fp, #-0x18]
    // 0x12f1b80: fadd            d2, d0, d1
    // 0x12f1b84: r0 = inline_Allocate_Double()
    //     0x12f1b84: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x12f1b88: add             x0, x0, #0x10
    //     0x12f1b8c: cmp             x1, x0
    //     0x12f1b90: b.ls            #0x12f1bd4
    //     0x12f1b94: str             x0, [THR, #0x60]  ; THR::top
    //     0x12f1b98: sub             x0, x0, #0xf
    //     0x12f1b9c: mov             x1, #0xe19c
    //     0x12f1ba0: movk            x1, #3, lsl #16
    //     0x12f1ba4: stur            x1, [x0, #-1]
    // 0x12f1ba8: dmb             ishst
    // 0x12f1bac: StoreField: r0->field_7 = d2
    //     0x12f1bac: stur            d2, [x0, #7]
    // 0x12f1bb0: LeaveFrame
    //     0x12f1bb0: mov             SP, fp
    //     0x12f1bb4: ldp             fp, lr, [SP], #0x10
    // 0x12f1bb8: ret
    //     0x12f1bb8: ret             
    // 0x12f1bbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f1bbc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f1bc0: b               #0x12f1ae8
    // 0x12f1bc4: SaveReg d0
    //     0x12f1bc4: str             q0, [SP, #-0x10]!
    // 0x12f1bc8: r0 = AllocateDouble()
    //     0x12f1bc8: bl              #0x13df878  ; AllocateDoubleStub
    // 0x12f1bcc: RestoreReg d0
    //     0x12f1bcc: ldr             q0, [SP], #0x10
    // 0x12f1bd0: b               #0x12f1b34
    // 0x12f1bd4: SaveReg d2
    //     0x12f1bd4: str             q2, [SP, #-0x10]!
    // 0x12f1bd8: r0 = AllocateDouble()
    //     0x12f1bd8: bl              #0x13df878  ; AllocateDoubleStub
    // 0x12f1bdc: RestoreReg d2
    //     0x12f1bdc: ldr             q2, [SP], #0x10
    // 0x12f1be0: b               #0x12f1bac
  }
}

// class id: 3341, size: 0x1c, field offset: 0x1c
class ScrollSpringSimulation extends SpringSimulation {

  _ x(/* No info */) {
    // ** addr: 0x12f1a24, size: 0xa0
    // 0x12f1a24: EnterFrame
    //     0x12f1a24: stp             fp, lr, [SP, #-0x10]!
    //     0x12f1a28: mov             fp, SP
    // 0x12f1a2c: AllocStack(0x10)
    //     0x12f1a2c: sub             SP, SP, #0x10
    // 0x12f1a30: SetupParameters(ScrollSpringSimulation this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x12f1a30: mov             x0, x1
    //     0x12f1a34: stur            x1, [fp, #-8]
    //     0x12f1a38: stur            x2, [fp, #-0x10]
    // 0x12f1a3c: CheckStackOverflow
    //     0x12f1a3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f1a40: cmp             SP, x16
    //     0x12f1a44: b.ls            #0x12f1aac
    // 0x12f1a48: LoadField: d0 = r2->field_7
    //     0x12f1a48: ldur            d0, [x2, #7]
    // 0x12f1a4c: mov             x1, x0
    // 0x12f1a50: r0 = isDone()
    //     0x12f1a50: bl              #0x12d8cb0  ; [package:flutter/src/physics/spring_simulation.dart] SpringSimulation::isDone
    // 0x12f1a54: tbnz            w0, #4, #0x12f1a64
    // 0x12f1a58: ldur            x1, [fp, #-8]
    // 0x12f1a5c: LoadField: d0 = r1->field_b
    //     0x12f1a5c: ldur            d0, [x1, #0xb]
    // 0x12f1a60: b               #0x12f1a74
    // 0x12f1a64: ldur            x1, [fp, #-8]
    // 0x12f1a68: ldur            x2, [fp, #-0x10]
    // 0x12f1a6c: r0 = x()
    //     0x12f1a6c: bl              #0x12f1ac4  ; [package:flutter/src/physics/spring_simulation.dart] SpringSimulation::x
    // 0x12f1a70: LoadField: d0 = r0->field_7
    //     0x12f1a70: ldur            d0, [x0, #7]
    // 0x12f1a74: r0 = inline_Allocate_Double()
    //     0x12f1a74: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x12f1a78: add             x0, x0, #0x10
    //     0x12f1a7c: cmp             x1, x0
    //     0x12f1a80: b.ls            #0x12f1ab4
    //     0x12f1a84: str             x0, [THR, #0x60]  ; THR::top
    //     0x12f1a88: sub             x0, x0, #0xf
    //     0x12f1a8c: mov             x1, #0xe19c
    //     0x12f1a90: movk            x1, #3, lsl #16
    //     0x12f1a94: stur            x1, [x0, #-1]
    // 0x12f1a98: dmb             ishst
    // 0x12f1a9c: StoreField: r0->field_7 = d0
    //     0x12f1a9c: stur            d0, [x0, #7]
    // 0x12f1aa0: LeaveFrame
    //     0x12f1aa0: mov             SP, fp
    //     0x12f1aa4: ldp             fp, lr, [SP], #0x10
    // 0x12f1aa8: ret
    //     0x12f1aa8: ret             
    // 0x12f1aac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f1aac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f1ab0: b               #0x12f1a48
    // 0x12f1ab4: SaveReg d0
    //     0x12f1ab4: str             q0, [SP, #-0x10]!
    // 0x12f1ab8: r0 = AllocateDouble()
    //     0x12f1ab8: bl              #0x13df878  ; AllocateDoubleStub
    // 0x12f1abc: RestoreReg d0
    //     0x12f1abc: ldr             q0, [SP], #0x10
    // 0x12f1ac0: b               #0x12f1a9c
  }
}
