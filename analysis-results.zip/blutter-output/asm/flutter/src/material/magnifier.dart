// lib: , url: package:flutter/src/material/magnifier.dart

// class id: 1048911, size: 0x8
class :: {
}

// class id: 5464, size: 0x20, field offset: 0x14
class _TextMagnifierState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0xdf7d04, size: 0x130
    // 0xdf7d04: EnterFrame
    //     0xdf7d04: stp             fp, lr, [SP, #-0x10]!
    //     0xdf7d08: mov             fp, SP
    // 0xdf7d0c: AllocStack(0x28)
    //     0xdf7d0c: sub             SP, SP, #0x28
    // 0xdf7d10: LoadField: r0 = r1->field_13
    //     0xdf7d10: ldur            w0, [x1, #0x13]
    // 0xdf7d14: DecompressPointer r0
    //     0xdf7d14: add             x0, x0, HEAP, lsl #32
    // 0xdf7d18: cmp             w0, NULL
    // 0xdf7d1c: b.eq            #0xdf7e14
    // 0xdf7d20: LoadField: d0 = r0->field_f
    //     0xdf7d20: ldur            d0, [x0, #0xf]
    // 0xdf7d24: stur            d0, [fp, #-0x28]
    // 0xdf7d28: LoadField: d1 = r0->field_7
    //     0xdf7d28: ldur            d1, [x0, #7]
    // 0xdf7d2c: stur            d1, [fp, #-0x20]
    // 0xdf7d30: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xdf7d30: ldur            w0, [x1, #0x17]
    // 0xdf7d34: DecompressPointer r0
    //     0xdf7d34: add             x0, x0, HEAP, lsl #32
    // 0xdf7d38: cmp             w0, NULL
    // 0xdf7d3c: b.eq            #0xdf7d4c
    // 0xdf7d40: r0 = Instance_Duration
    //     0xdf7d40: add             x0, PP, #0xa0, lsl #12  ; [pp+0xa0e38] Obj!Duration@12c8b41
    //     0xdf7d44: ldr             x0, [x0, #0xe38]
    // 0xdf7d48: b               #0xdf7d50
    // 0xdf7d4c: r0 = Instance_Duration
    //     0xdf7d4c: ldr             x0, [PP, #0x1808]  ; [pp+0x1808] Obj!Duration@12c8901
    // 0xdf7d50: stur            x0, [fp, #-0x10]
    // 0xdf7d54: LoadField: r2 = r1->field_1b
    //     0xdf7d54: ldur            w2, [x1, #0x1b]
    // 0xdf7d58: DecompressPointer r2
    //     0xdf7d58: add             x2, x2, HEAP, lsl #32
    // 0xdf7d5c: stur            x2, [fp, #-8]
    // 0xdf7d60: r0 = Magnifier()
    //     0xdf7d60: bl              #0xdf7e40  ; AllocateMagnifierStub -> Magnifier (size=0x24)
    // 0xdf7d64: mov             x1, x0
    // 0xdf7d68: ldur            x0, [fp, #-8]
    // 0xdf7d6c: stur            x1, [fp, #-0x18]
    // 0xdf7d70: StoreField: r1->field_b = r0
    //     0xdf7d70: stur            w0, [x1, #0xb]
    // 0xdf7d74: r0 = Instance_BorderRadius
    //     0xdf7d74: add             x0, PP, #0xa0, lsl #12  ; [pp+0xa0e40] Obj!BorderRadius@129e3d1
    //     0xdf7d78: ldr             x0, [x0, #0xe40]
    // 0xdf7d7c: StoreField: r1->field_f = r0
    //     0xdf7d7c: stur            w0, [x1, #0xf]
    // 0xdf7d80: r0 = Instance_Color
    //     0xdf7d80: add             x0, PP, #0xa0, lsl #12  ; [pp+0xa0e48] Obj!Color@12a40e1
    //     0xdf7d84: ldr             x0, [x0, #0xe48]
    // 0xdf7d88: StoreField: r1->field_13 = r0
    //     0xdf7d88: stur            w0, [x1, #0x13]
    // 0xdf7d8c: r0 = const [Instance of 'BoxShadow']
    //     0xdf7d8c: add             x0, PP, #0xa0, lsl #12  ; [pp+0xa0e50] List<BoxShadow>(1)
    //     0xdf7d90: ldr             x0, [x0, #0xe50]
    // 0xdf7d94: ArrayStore: r1[0] = r0  ; List_4
    //     0xdf7d94: stur            w0, [x1, #0x17]
    // 0xdf7d98: r0 = Instance_Clip
    //     0xdf7d98: add             x0, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xdf7d9c: ldr             x0, [x0, #0x850]
    // 0xdf7da0: StoreField: r1->field_1b = r0
    //     0xdf7da0: stur            w0, [x1, #0x1b]
    // 0xdf7da4: r0 = Instance_Size
    //     0xdf7da4: add             x0, PP, #0xa0, lsl #12  ; [pp+0xa0e58] Obj!Size@12a7831
    //     0xdf7da8: ldr             x0, [x0, #0xe58]
    // 0xdf7dac: StoreField: r1->field_1f = r0
    //     0xdf7dac: stur            w0, [x1, #0x1f]
    // 0xdf7db0: r0 = AnimatedPositioned()
    //     0xdf7db0: bl              #0xdf7e34  ; AllocateAnimatedPositionedStub -> AnimatedPositioned (size=0x38)
    // 0xdf7db4: ldur            x1, [fp, #-0x18]
    // 0xdf7db8: ArrayStore: r0[0] = r1  ; List_4
    //     0xdf7db8: stur            w1, [x0, #0x17]
    // 0xdf7dbc: ldur            d0, [fp, #-0x20]
    // 0xdf7dc0: StoreField: r0->field_1b = d0
    //     0xdf7dc0: stur            d0, [x0, #0x1b]
    // 0xdf7dc4: ldur            d0, [fp, #-0x28]
    // 0xdf7dc8: r1 = inline_Allocate_Double()
    //     0xdf7dc8: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xdf7dcc: add             x1, x1, #0x10
    //     0xdf7dd0: cmp             x2, x1
    //     0xdf7dd4: b.ls            #0xdf7e18
    //     0xdf7dd8: str             x1, [THR, #0x60]  ; THR::top
    //     0xdf7ddc: sub             x1, x1, #0xf
    //     0xdf7de0: mov             x2, #0xe19c
    //     0xdf7de4: movk            x2, #3, lsl #16
    //     0xdf7de8: stur            x2, [x1, #-1]
    // 0xdf7dec: dmb             ishst
    // 0xdf7df0: StoreField: r1->field_7 = d0
    //     0xdf7df0: stur            d0, [x1, #7]
    // 0xdf7df4: StoreField: r0->field_23 = r1
    //     0xdf7df4: stur            w1, [x0, #0x23]
    // 0xdf7df8: r1 = Instance__Linear
    //     0xdf7df8: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] Obj!_Linear@129fef1
    // 0xdf7dfc: StoreField: r0->field_b = r1
    //     0xdf7dfc: stur            w1, [x0, #0xb]
    // 0xdf7e00: ldur            x1, [fp, #-0x10]
    // 0xdf7e04: StoreField: r0->field_f = r1
    //     0xdf7e04: stur            w1, [x0, #0xf]
    // 0xdf7e08: LeaveFrame
    //     0xdf7e08: mov             SP, fp
    //     0xdf7e0c: ldp             fp, lr, [SP], #0x10
    // 0xdf7e10: ret
    //     0xdf7e10: ret             
    // 0xdf7e14: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf7e14: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf7e18: SaveReg d0
    //     0xdf7e18: str             q0, [SP, #-0x10]!
    // 0xdf7e1c: SaveReg r0
    //     0xdf7e1c: str             x0, [SP, #-8]!
    // 0xdf7e20: r0 = AllocateDouble()
    //     0xdf7e20: bl              #0x13df878  ; AllocateDoubleStub
    // 0xdf7e24: mov             x1, x0
    // 0xdf7e28: RestoreReg r0
    //     0xdf7e28: ldr             x0, [SP], #8
    // 0xdf7e2c: RestoreReg d0
    //     0xdf7e2c: ldr             q0, [SP], #0x10
    // 0xdf7e30: b               #0xdf7df0
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0xef538c, size: 0x30
    // 0xef538c: EnterFrame
    //     0xef538c: stp             fp, lr, [SP, #-0x10]!
    //     0xef5390: mov             fp, SP
    // 0xef5394: CheckStackOverflow
    //     0xef5394: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef5398: cmp             SP, x16
    //     0xef539c: b.ls            #0xef53b4
    // 0xef53a0: r0 = _determineMagnifierPositionAndFocalPoint()
    //     0xef53a0: bl              #0xef53bc  ; [package:flutter/src/material/magnifier.dart] _TextMagnifierState::_determineMagnifierPositionAndFocalPoint
    // 0xef53a4: r0 = Null
    //     0xef53a4: mov             x0, NULL
    // 0xef53a8: LeaveFrame
    //     0xef53a8: mov             SP, fp
    //     0xef53ac: ldp             fp, lr, [SP], #0x10
    // 0xef53b0: ret
    //     0xef53b0: ret             
    // 0xef53b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef53b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef53b8: b               #0xef53a0
  }
  _ _determineMagnifierPositionAndFocalPoint(/* No info */) {
    // ** addr: 0xef53bc, size: 0x37c
    // 0xef53bc: EnterFrame
    //     0xef53bc: stp             fp, lr, [SP, #-0x10]!
    //     0xef53c0: mov             fp, SP
    // 0xef53c4: AllocStack(0x40)
    //     0xef53c4: sub             SP, SP, #0x40
    // 0xef53c8: SetupParameters(_TextMagnifierState this /* r1 => r1, fp-0x8 */)
    //     0xef53c8: stur            x1, [fp, #-8]
    // 0xef53cc: CheckStackOverflow
    //     0xef53cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef53d0: cmp             SP, x16
    //     0xef53d4: b.ls            #0xef5728
    // 0xef53d8: r1 = 4
    //     0xef53d8: mov             x1, #4
    // 0xef53dc: r0 = AllocateContext()
    //     0xef53dc: bl              #0x13de838  ; AllocateContextStub
    // 0xef53e0: mov             x2, x0
    // 0xef53e4: ldur            x0, [fp, #-8]
    // 0xef53e8: stur            x2, [fp, #-0x18]
    // 0xef53ec: StoreField: r2->field_f = r0
    //     0xef53ec: stur            w0, [x2, #0xf]
    // 0xef53f0: LoadField: r1 = r0->field_b
    //     0xef53f0: ldur            w1, [x0, #0xb]
    // 0xef53f4: DecompressPointer r1
    //     0xef53f4: add             x1, x1, HEAP, lsl #32
    // 0xef53f8: cmp             w1, NULL
    // 0xef53fc: b.eq            #0xef5730
    // 0xef5400: LoadField: r3 = r1->field_b
    //     0xef5400: ldur            w3, [x1, #0xb]
    // 0xef5404: DecompressPointer r3
    //     0xef5404: add             x3, x3, HEAP, lsl #32
    // 0xef5408: LoadField: r4 = r3->field_27
    //     0xef5408: ldur            w4, [x3, #0x27]
    // 0xef540c: DecompressPointer r4
    //     0xef540c: add             x4, x4, HEAP, lsl #32
    // 0xef5410: stur            x4, [fp, #-0x10]
    // 0xef5414: LoadField: r1 = r0->field_f
    //     0xef5414: ldur            w1, [x0, #0xf]
    // 0xef5418: DecompressPointer r1
    //     0xef5418: add             x1, x1, HEAP, lsl #32
    // 0xef541c: cmp             w1, NULL
    // 0xef5420: b.eq            #0xef5734
    // 0xef5424: r0 = sizeOf()
    //     0xef5424: bl              #0x865078  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::sizeOf
    // 0xef5428: mov             x2, x0
    // 0xef542c: r1 = Instance_Offset
    //     0xef542c: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xef5430: r0 = &()
    //     0xef5430: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xef5434: stur            x0, [fp, #-0x20]
    // 0xef5438: r0 = Offset()
    //     0xef5438: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xef543c: d0 = 38.685000
    //     0xef543c: add             x17, PP, #0xa0, lsl #12  ; [pp+0xa0e90] IMM: double(38.685) from 0x404357ae147ae148
    //     0xef5440: ldr             d0, [x17, #0xe90]
    // 0xef5444: stur            x0, [fp, #-0x28]
    // 0xef5448: StoreField: r0->field_7 = d0
    //     0xef5448: stur            d0, [x0, #7]
    // 0xef544c: d0 = 59.900000
    //     0xef544c: add             x17, PP, #0xa0, lsl #12  ; [pp+0xa0e98] IMM: double(59.9) from 0x404df33333333333
    //     0xef5450: ldr             d0, [x17, #0xe98]
    // 0xef5454: StoreField: r0->field_f = d0
    //     0xef5454: stur            d0, [x0, #0xf]
    // 0xef5458: ldur            x2, [fp, #-0x10]
    // 0xef545c: LoadField: r1 = r2->field_7
    //     0xef545c: ldur            w1, [x2, #7]
    // 0xef5460: DecompressPointer r1
    //     0xef5460: add             x1, x1, HEAP, lsl #32
    // 0xef5464: LoadField: d0 = r1->field_7
    //     0xef5464: ldur            d0, [x1, #7]
    // 0xef5468: LoadField: r1 = r2->field_b
    //     0xef5468: ldur            w1, [x2, #0xb]
    // 0xef546c: DecompressPointer r1
    //     0xef546c: add             x1, x1, HEAP, lsl #32
    // 0xef5470: LoadField: d1 = r1->field_7
    //     0xef5470: ldur            d1, [x1, #7]
    // 0xef5474: ArrayLoad: d2 = r1[0]  ; List_8
    //     0xef5474: ldur            d2, [x1, #0x17]
    // 0xef5478: fcmp            d1, d0
    // 0xef547c: b.le            #0xef5488
    // 0xef5480: mov             v0.16b, v1.16b
    // 0xef5484: b               #0xef54a4
    // 0xef5488: fcmp            d0, d2
    // 0xef548c: b.le            #0xef5498
    // 0xef5490: mov             v0.16b, v2.16b
    // 0xef5494: b               #0xef54a4
    // 0xef5498: fcmp            d0, d0
    // 0xef549c: b.vc            #0xef54a4
    // 0xef54a0: mov             v0.16b, v2.16b
    // 0xef54a4: ldur            x3, [fp, #-0x18]
    // 0xef54a8: stur            d0, [fp, #-0x30]
    // 0xef54ac: LoadField: r1 = r2->field_f
    //     0xef54ac: ldur            w1, [x2, #0xf]
    // 0xef54b0: DecompressPointer r1
    //     0xef54b0: add             x1, x1, HEAP, lsl #32
    // 0xef54b4: r0 = center()
    //     0xef54b4: bl              #0x869350  ; [dart:ui] Rect::center
    // 0xef54b8: LoadField: d0 = r0->field_f
    //     0xef54b8: ldur            d0, [x0, #0xf]
    // 0xef54bc: stur            d0, [fp, #-0x38]
    // 0xef54c0: r0 = Offset()
    //     0xef54c0: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xef54c4: ldur            d0, [fp, #-0x30]
    // 0xef54c8: StoreField: r0->field_7 = d0
    //     0xef54c8: stur            d0, [x0, #7]
    // 0xef54cc: ldur            d0, [fp, #-0x38]
    // 0xef54d0: StoreField: r0->field_f = d0
    //     0xef54d0: stur            d0, [x0, #0xf]
    // 0xef54d4: mov             x1, x0
    // 0xef54d8: ldur            x2, [fp, #-0x28]
    // 0xef54dc: r0 = -()
    //     0xef54dc: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0xef54e0: mov             x1, x0
    // 0xef54e4: r2 = Instance_Size
    //     0xef54e4: add             x2, PP, #0xa0, lsl #12  ; [pp+0xa0e58] Obj!Size@12a7831
    //     0xef54e8: ldr             x2, [x2, #0xe58]
    // 0xef54ec: r0 = &()
    //     0xef54ec: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xef54f0: ldur            x1, [fp, #-0x20]
    // 0xef54f4: mov             x2, x0
    // 0xef54f8: stur            x0, [fp, #-0x20]
    // 0xef54fc: r0 = shiftWithinBounds()
    //     0xef54fc: bl              #0xef5770  ; [package:flutter/src/widgets/magnifier.dart] MagnifierController::shiftWithinBounds
    // 0xef5500: stur            x0, [fp, #-0x28]
    // 0xef5504: LoadField: d0 = r0->field_7
    //     0xef5504: ldur            d0, [x0, #7]
    // 0xef5508: stur            d0, [fp, #-0x38]
    // 0xef550c: LoadField: d1 = r0->field_f
    //     0xef550c: ldur            d1, [x0, #0xf]
    // 0xef5510: stur            d1, [fp, #-0x30]
    // 0xef5514: r0 = Offset()
    //     0xef5514: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xef5518: ldur            d0, [fp, #-0x38]
    // 0xef551c: StoreField: r0->field_7 = d0
    //     0xef551c: stur            d0, [x0, #7]
    // 0xef5520: ldur            d0, [fp, #-0x30]
    // 0xef5524: StoreField: r0->field_f = d0
    //     0xef5524: stur            d0, [x0, #0xf]
    // 0xef5528: ldur            x2, [fp, #-0x18]
    // 0xef552c: StoreField: r2->field_13 = r0
    //     0xef552c: stur            w0, [x2, #0x13]
    //     0xef5530: ldurb           w16, [x2, #-1]
    //     0xef5534: ldurb           w17, [x0, #-1]
    //     0xef5538: and             x16, x17, x16, lsr #2
    //     0xef553c: tst             x16, HEAP, lsr #32
    //     0xef5540: b.eq            #0xef5548
    //     0xef5544: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xef5548: ldur            x0, [fp, #-0x10]
    // 0xef554c: LoadField: r1 = r0->field_13
    //     0xef554c: ldur            w1, [x0, #0x13]
    // 0xef5550: DecompressPointer r1
    //     0xef5550: add             x1, x1, HEAP, lsl #32
    // 0xef5554: ArrayLoad: d1 = r1[0]  ; List_8
    //     0xef5554: ldur            d1, [x1, #0x17]
    // 0xef5558: stur            d1, [fp, #-0x40]
    // 0xef555c: LoadField: d2 = r1->field_7
    //     0xef555c: ldur            d2, [x1, #7]
    // 0xef5560: stur            d2, [fp, #-0x38]
    // 0xef5564: fsub            d3, d1, d2
    // 0xef5568: d4 = 61.896000
    //     0xef5568: add             x17, PP, #0xa0, lsl #12  ; [pp+0xa0ea0] IMM: double(61.896) from 0x404ef2b020c49ba6
    //     0xef556c: ldr             d4, [x17, #0xea0]
    // 0xef5570: fcmp            d4, d3
    // 0xef5574: b.le            #0xef5588
    // 0xef5578: r0 = center()
    //     0xef5578: bl              #0x869350  ; [dart:ui] Rect::center
    // 0xef557c: LoadField: d0 = r0->field_7
    //     0xef557c: ldur            d0, [x0, #7]
    // 0xef5580: mov             v1.16b, v0.16b
    // 0xef5584: b               #0xef55dc
    // 0xef5588: ldur            x1, [fp, #-0x28]
    // 0xef558c: r0 = center()
    //     0xef558c: bl              #0x869350  ; [dart:ui] Rect::center
    // 0xef5590: LoadField: d0 = r0->field_7
    //     0xef5590: ldur            d0, [x0, #7]
    // 0xef5594: ldur            d1, [fp, #-0x38]
    // 0xef5598: d2 = 30.948000
    //     0xef5598: add             x17, PP, #0xa0, lsl #12  ; [pp+0xa0ea8] IMM: double(30.948) from 0x403ef2b020c49ba6
    //     0xef559c: ldr             d2, [x17, #0xea8]
    // 0xef55a0: fadd            d3, d1, d2
    // 0xef55a4: ldur            d1, [fp, #-0x40]
    // 0xef55a8: fsub            d4, d1, d2
    // 0xef55ac: fcmp            d3, d0
    // 0xef55b0: b.le            #0xef55bc
    // 0xef55b4: mov             v0.16b, v3.16b
    // 0xef55b8: b               #0xef55d8
    // 0xef55bc: fcmp            d0, d4
    // 0xef55c0: b.le            #0xef55cc
    // 0xef55c4: mov             v0.16b, v4.16b
    // 0xef55c8: b               #0xef55d8
    // 0xef55cc: fcmp            d0, d0
    // 0xef55d0: b.vc            #0xef55d8
    // 0xef55d4: mov             v0.16b, v4.16b
    // 0xef55d8: mov             v1.16b, v0.16b
    // 0xef55dc: ldur            x3, [fp, #-8]
    // 0xef55e0: ldur            x2, [fp, #-0x18]
    // 0xef55e4: ldur            x0, [fp, #-0x20]
    // 0xef55e8: ldur            d0, [fp, #-0x30]
    // 0xef55ec: ldur            x1, [fp, #-0x28]
    // 0xef55f0: stur            d1, [fp, #-0x38]
    // 0xef55f4: r0 = center()
    //     0xef55f4: bl              #0x869350  ; [dart:ui] Rect::center
    // 0xef55f8: LoadField: d0 = r0->field_7
    //     0xef55f8: ldur            d0, [x0, #7]
    // 0xef55fc: ldur            d1, [fp, #-0x38]
    // 0xef5600: fsub            d2, d1, d0
    // 0xef5604: ldur            x0, [fp, #-0x20]
    // 0xef5608: stur            d2, [fp, #-0x40]
    // 0xef560c: LoadField: d0 = r0->field_f
    //     0xef560c: ldur            d0, [x0, #0xf]
    // 0xef5610: ldur            d1, [fp, #-0x30]
    // 0xef5614: fsub            d3, d0, d1
    // 0xef5618: stur            d3, [fp, #-0x38]
    // 0xef561c: r0 = Offset()
    //     0xef561c: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xef5620: ldur            d0, [fp, #-0x40]
    // 0xef5624: StoreField: r0->field_7 = d0
    //     0xef5624: stur            d0, [x0, #7]
    // 0xef5628: ldur            d0, [fp, #-0x38]
    // 0xef562c: StoreField: r0->field_f = d0
    //     0xef562c: stur            d0, [x0, #0xf]
    // 0xef5630: ldur            x2, [fp, #-0x18]
    // 0xef5634: ArrayStore: r2[0] = r0  ; List_4
    //     0xef5634: stur            w0, [x2, #0x17]
    //     0xef5638: ldurb           w16, [x2, #-1]
    //     0xef563c: ldurb           w17, [x0, #-1]
    //     0xef5640: and             x16, x17, x16, lsr #2
    //     0xef5644: tst             x16, HEAP, lsr #32
    //     0xef5648: b.eq            #0xef5650
    //     0xef564c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xef5650: ldur            x3, [fp, #-8]
    // 0xef5654: ArrayLoad: r1 = r3[0]  ; List_4
    //     0xef5654: ldur            w1, [x3, #0x17]
    // 0xef5658: DecompressPointer r1
    //     0xef5658: add             x1, x1, HEAP, lsl #32
    // 0xef565c: mov             x0, x1
    // 0xef5660: StoreField: r2->field_1b = r0
    //     0xef5660: stur            w0, [x2, #0x1b]
    //     0xef5664: ldurb           w16, [x2, #-1]
    //     0xef5668: ldurb           w17, [x0, #-1]
    //     0xef566c: and             x16, x17, x16, lsr #2
    //     0xef5670: tst             x16, HEAP, lsr #32
    //     0xef5674: b.eq            #0xef567c
    //     0xef5678: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xef567c: LoadField: r0 = r3->field_13
    //     0xef567c: ldur            w0, [x3, #0x13]
    // 0xef5680: DecompressPointer r0
    //     0xef5680: add             x0, x0, HEAP, lsl #32
    // 0xef5684: cmp             w0, NULL
    // 0xef5688: b.eq            #0xef5700
    // 0xef568c: ldur            d0, [fp, #-0x30]
    // 0xef5690: LoadField: d1 = r0->field_f
    //     0xef5690: ldur            d1, [x0, #0xf]
    // 0xef5694: fcmp            d0, d1
    // 0xef5698: b.eq            #0xef5700
    // 0xef569c: cmp             w1, NULL
    // 0xef56a0: b.eq            #0xef56b8
    // 0xef56a4: LoadField: r0 = r1->field_7
    //     0xef56a4: ldur            w0, [x1, #7]
    // 0xef56a8: DecompressPointer r0
    //     0xef56a8: add             x0, x0, HEAP, lsl #32
    // 0xef56ac: cmp             w0, NULL
    // 0xef56b0: b.eq            #0xef56b8
    // 0xef56b4: r0 = cancel()
    //     0xef56b4: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0xef56b8: ldur            x0, [fp, #-0x18]
    // 0xef56bc: mov             x2, x0
    // 0xef56c0: r1 = Function '<anonymous closure>':.
    //     0xef56c0: add             x1, PP, #0xa0, lsl #12  ; [pp+0xa0eb0] AnonymousClosure: (0xef5950), in [package:flutter/src/material/magnifier.dart] _TextMagnifierState::_determineMagnifierPositionAndFocalPoint (0xef53bc)
    //     0xef56c4: ldr             x1, [x1, #0xeb0]
    // 0xef56c8: r0 = AllocateClosure()
    //     0xef56c8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xef56cc: mov             x3, x0
    // 0xef56d0: r1 = Null
    //     0xef56d0: mov             x1, NULL
    // 0xef56d4: r2 = Instance_Duration
    //     0xef56d4: add             x2, PP, #0xa0, lsl #12  ; [pp+0xa0e38] Obj!Duration@12c8b41
    //     0xef56d8: ldr             x2, [x2, #0xe38]
    // 0xef56dc: r0 = Timer()
    //     0xef56dc: bl              #0x7eed74  ; [dart:async] Timer::Timer
    // 0xef56e0: ldur            x2, [fp, #-0x18]
    // 0xef56e4: StoreField: r2->field_1b = r0
    //     0xef56e4: stur            w0, [x2, #0x1b]
    //     0xef56e8: ldurb           w16, [x2, #-1]
    //     0xef56ec: ldurb           w17, [x0, #-1]
    //     0xef56f0: and             x16, x17, x16, lsr #2
    //     0xef56f4: tst             x16, HEAP, lsr #32
    //     0xef56f8: b.eq            #0xef5700
    //     0xef56fc: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xef5700: r1 = Function '<anonymous closure>':.
    //     0xef5700: add             x1, PP, #0xa0, lsl #12  ; [pp+0xa0eb8] AnonymousClosure: (0xef58b8), in [package:flutter/src/material/magnifier.dart] _TextMagnifierState::_determineMagnifierPositionAndFocalPoint (0xef53bc)
    //     0xef5704: ldr             x1, [x1, #0xeb8]
    // 0xef5708: r0 = AllocateClosure()
    //     0xef5708: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xef570c: ldur            x1, [fp, #-8]
    // 0xef5710: mov             x2, x0
    // 0xef5714: r0 = setState()
    //     0xef5714: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xef5718: r0 = Null
    //     0xef5718: mov             x0, NULL
    // 0xef571c: LeaveFrame
    //     0xef571c: mov             SP, fp
    //     0xef5720: ldp             fp, lr, [SP], #0x10
    // 0xef5724: ret
    //     0xef5724: ret             
    // 0xef5728: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef5728: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef572c: b               #0xef53d8
    // 0xef5730: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef5730: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef5734: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef5734: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _determineMagnifierPositionAndFocalPoint(dynamic) {
    // ** addr: 0xef5738, size: 0x38
    // 0xef5738: EnterFrame
    //     0xef5738: stp             fp, lr, [SP, #-0x10]!
    //     0xef573c: mov             fp, SP
    // 0xef5740: ldr             x0, [fp, #0x10]
    // 0xef5744: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xef5744: ldur            w1, [x0, #0x17]
    // 0xef5748: DecompressPointer r1
    //     0xef5748: add             x1, x1, HEAP, lsl #32
    // 0xef574c: CheckStackOverflow
    //     0xef574c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef5750: cmp             SP, x16
    //     0xef5754: b.ls            #0xef5768
    // 0xef5758: r0 = _determineMagnifierPositionAndFocalPoint()
    //     0xef5758: bl              #0xef53bc  ; [package:flutter/src/material/magnifier.dart] _TextMagnifierState::_determineMagnifierPositionAndFocalPoint
    // 0xef575c: LeaveFrame
    //     0xef575c: mov             SP, fp
    //     0xef5760: ldp             fp, lr, [SP], #0x10
    // 0xef5764: ret
    //     0xef5764: ret             
    // 0xef5768: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef5768: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef576c: b               #0xef5758
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xef58b8, size: 0x98
    // 0xef58b8: EnterFrame
    //     0xef58b8: stp             fp, lr, [SP, #-0x10]!
    //     0xef58bc: mov             fp, SP
    // 0xef58c0: ldr             x1, [fp, #0x10]
    // 0xef58c4: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xef58c4: ldur            w2, [x1, #0x17]
    // 0xef58c8: DecompressPointer r2
    //     0xef58c8: add             x2, x2, HEAP, lsl #32
    // 0xef58cc: LoadField: r1 = r2->field_f
    //     0xef58cc: ldur            w1, [x2, #0xf]
    // 0xef58d0: DecompressPointer r1
    //     0xef58d0: add             x1, x1, HEAP, lsl #32
    // 0xef58d4: LoadField: r0 = r2->field_13
    //     0xef58d4: ldur            w0, [x2, #0x13]
    // 0xef58d8: DecompressPointer r0
    //     0xef58d8: add             x0, x0, HEAP, lsl #32
    // 0xef58dc: StoreField: r1->field_13 = r0
    //     0xef58dc: stur            w0, [x1, #0x13]
    //     0xef58e0: ldurb           w16, [x1, #-1]
    //     0xef58e4: ldurb           w17, [x0, #-1]
    //     0xef58e8: and             x16, x17, x16, lsr #2
    //     0xef58ec: tst             x16, HEAP, lsr #32
    //     0xef58f0: b.eq            #0xef58f8
    //     0xef58f4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xef58f8: LoadField: r0 = r2->field_1b
    //     0xef58f8: ldur            w0, [x2, #0x1b]
    // 0xef58fc: DecompressPointer r0
    //     0xef58fc: add             x0, x0, HEAP, lsl #32
    // 0xef5900: ArrayStore: r1[0] = r0  ; List_4
    //     0xef5900: stur            w0, [x1, #0x17]
    //     0xef5904: ldurb           w16, [x1, #-1]
    //     0xef5908: ldurb           w17, [x0, #-1]
    //     0xef590c: and             x16, x17, x16, lsr #2
    //     0xef5910: tst             x16, HEAP, lsr #32
    //     0xef5914: b.eq            #0xef591c
    //     0xef5918: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xef591c: ArrayLoad: r0 = r2[0]  ; List_4
    //     0xef591c: ldur            w0, [x2, #0x17]
    // 0xef5920: DecompressPointer r0
    //     0xef5920: add             x0, x0, HEAP, lsl #32
    // 0xef5924: StoreField: r1->field_1b = r0
    //     0xef5924: stur            w0, [x1, #0x1b]
    //     0xef5928: ldurb           w16, [x1, #-1]
    //     0xef592c: ldurb           w17, [x0, #-1]
    //     0xef5930: and             x16, x17, x16, lsr #2
    //     0xef5934: tst             x16, HEAP, lsr #32
    //     0xef5938: b.eq            #0xef5940
    //     0xef593c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xef5940: r0 = Null
    //     0xef5940: mov             x0, NULL
    // 0xef5944: LeaveFrame
    //     0xef5944: mov             SP, fp
    //     0xef5948: ldp             fp, lr, [SP], #0x10
    // 0xef594c: ret
    //     0xef594c: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xef5950, size: 0x60
    // 0xef5950: EnterFrame
    //     0xef5950: stp             fp, lr, [SP, #-0x10]!
    //     0xef5954: mov             fp, SP
    // 0xef5958: AllocStack(0x8)
    //     0xef5958: sub             SP, SP, #8
    // 0xef595c: SetupParameters([dynamic _ /* r0 */])
    //     0xef595c: ldr             x0, [fp, #0x10]
    //     0xef5960: ldur            w2, [x0, #0x17]
    //     0xef5964: add             x2, x2, HEAP, lsl #32
    // 0xef5968: CheckStackOverflow
    //     0xef5968: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef596c: cmp             SP, x16
    //     0xef5970: b.ls            #0xef59a8
    // 0xef5974: LoadField: r0 = r2->field_f
    //     0xef5974: ldur            w0, [x2, #0xf]
    // 0xef5978: DecompressPointer r0
    //     0xef5978: add             x0, x0, HEAP, lsl #32
    // 0xef597c: stur            x0, [fp, #-8]
    // 0xef5980: r1 = Function '<anonymous closure>':.
    //     0xef5980: add             x1, PP, #0xa0, lsl #12  ; [pp+0xa0ec0] AnonymousClosure: (0xef59b0), in [package:flutter/src/material/magnifier.dart] _TextMagnifierState::_determineMagnifierPositionAndFocalPoint (0xef53bc)
    //     0xef5984: ldr             x1, [x1, #0xec0]
    // 0xef5988: r0 = AllocateClosure()
    //     0xef5988: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xef598c: ldur            x1, [fp, #-8]
    // 0xef5990: mov             x2, x0
    // 0xef5994: r0 = setState()
    //     0xef5994: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xef5998: r0 = Null
    //     0xef5998: mov             x0, NULL
    // 0xef599c: LeaveFrame
    //     0xef599c: mov             SP, fp
    //     0xef59a0: ldp             fp, lr, [SP], #0x10
    // 0xef59a4: ret
    //     0xef59a4: ret             
    // 0xef59a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef59a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef59ac: b               #0xef5974
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xef59b0, size: 0x20
    // 0xef59b0: ldr             x1, [SP]
    // 0xef59b4: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xef59b4: ldur            w2, [x1, #0x17]
    // 0xef59b8: DecompressPointer r2
    //     0xef59b8: add             x2, x2, HEAP, lsl #32
    // 0xef59bc: LoadField: r1 = r2->field_f
    //     0xef59bc: ldur            w1, [x2, #0xf]
    // 0xef59c0: DecompressPointer r1
    //     0xef59c0: add             x1, x1, HEAP, lsl #32
    // 0xef59c4: ArrayStore: r1[0] = rNULL  ; List_4
    //     0xef59c4: stur            NULL, [x1, #0x17]
    // 0xef59c8: r0 = Null
    //     0xef59c8: mov             x0, NULL
    // 0xef59cc: ret
    //     0xef59cc: ret             
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf6de88, size: 0x164
    // 0xf6de88: EnterFrame
    //     0xf6de88: stp             fp, lr, [SP, #-0x10]!
    //     0xf6de8c: mov             fp, SP
    // 0xf6de90: AllocStack(0x20)
    //     0xf6de90: sub             SP, SP, #0x20
    // 0xf6de94: SetupParameters(_TextMagnifierState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xf6de94: mov             x4, x1
    //     0xf6de98: mov             x3, x2
    //     0xf6de9c: stur            x1, [fp, #-8]
    //     0xf6dea0: stur            x2, [fp, #-0x10]
    // 0xf6dea4: CheckStackOverflow
    //     0xf6dea4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6dea8: cmp             SP, x16
    //     0xf6deac: b.ls            #0xf6dfdc
    // 0xf6deb0: mov             x0, x3
    // 0xf6deb4: r2 = Null
    //     0xf6deb4: mov             x2, NULL
    // 0xf6deb8: r1 = Null
    //     0xf6deb8: mov             x1, NULL
    // 0xf6debc: r4 = 60
    //     0xf6debc: mov             x4, #0x3c
    // 0xf6dec0: branchIfSmi(r0, 0xf6decc)
    //     0xf6dec0: tbz             w0, #0, #0xf6decc
    // 0xf6dec4: r4 = LoadClassIdInstr(r0)
    //     0xf6dec4: ldur            x4, [x0, #-1]
    //     0xf6dec8: ubfx            x4, x4, #0xc, #0x14
    // 0xf6decc: r17 = 6468
    //     0xf6decc: mov             x17, #0x1944
    // 0xf6ded0: cmp             x4, x17
    // 0xf6ded4: b.eq            #0xf6deec
    // 0xf6ded8: r8 = TextMagnifier
    //     0xf6ded8: add             x8, PP, #0xa0, lsl #12  ; [pp+0xa0e60] Type: TextMagnifier
    //     0xf6dedc: ldr             x8, [x8, #0xe60]
    // 0xf6dee0: r3 = Null
    //     0xf6dee0: add             x3, PP, #0xa0, lsl #12  ; [pp+0xa0e68] Null
    //     0xf6dee4: ldr             x3, [x3, #0xe68]
    // 0xf6dee8: r0 = TextMagnifier()
    //     0xf6dee8: bl              #0xd4a5cc  ; IsType_TextMagnifier_Stub
    // 0xf6deec: ldur            x0, [fp, #-0x10]
    // 0xf6def0: LoadField: r3 = r0->field_b
    //     0xf6def0: ldur            w3, [x0, #0xb]
    // 0xf6def4: DecompressPointer r3
    //     0xf6def4: add             x3, x3, HEAP, lsl #32
    // 0xf6def8: ldur            x4, [fp, #-8]
    // 0xf6defc: stur            x3, [fp, #-0x18]
    // 0xf6df00: LoadField: r1 = r4->field_b
    //     0xf6df00: ldur            w1, [x4, #0xb]
    // 0xf6df04: DecompressPointer r1
    //     0xf6df04: add             x1, x1, HEAP, lsl #32
    // 0xf6df08: cmp             w1, NULL
    // 0xf6df0c: b.eq            #0xf6dfe4
    // 0xf6df10: LoadField: r2 = r1->field_b
    //     0xf6df10: ldur            w2, [x1, #0xb]
    // 0xf6df14: DecompressPointer r2
    //     0xf6df14: add             x2, x2, HEAP, lsl #32
    // 0xf6df18: cmp             w3, w2
    // 0xf6df1c: b.eq            #0xf6df90
    // 0xf6df20: mov             x2, x4
    // 0xf6df24: r1 = Function '_determineMagnifierPositionAndFocalPoint@760515283':.
    //     0xf6df24: add             x1, PP, #0xa0, lsl #12  ; [pp+0xa0e78] AnonymousClosure: (0xef5738), in [package:flutter/src/material/magnifier.dart] _TextMagnifierState::_determineMagnifierPositionAndFocalPoint (0xef53bc)
    //     0xf6df28: ldr             x1, [x1, #0xe78]
    // 0xf6df2c: r0 = AllocateClosure()
    //     0xf6df2c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf6df30: mov             x3, x0
    // 0xf6df34: ldur            x1, [fp, #-0x18]
    // 0xf6df38: stur            x3, [fp, #-0x20]
    // 0xf6df3c: r0 = LoadClassIdInstr(r1)
    //     0xf6df3c: ldur            x0, [x1, #-1]
    //     0xf6df40: ubfx            x0, x0, #0xc, #0x14
    // 0xf6df44: mov             x2, x3
    // 0xf6df48: r0 = GDT[cid_x0 + 0xe2a3]()
    //     0xf6df48: mov             x17, #0xe2a3
    //     0xf6df4c: add             lr, x0, x17
    //     0xf6df50: ldr             lr, [x21, lr, lsl #3]
    //     0xf6df54: blr             lr
    // 0xf6df58: ldur            x3, [fp, #-8]
    // 0xf6df5c: LoadField: r0 = r3->field_b
    //     0xf6df5c: ldur            w0, [x3, #0xb]
    // 0xf6df60: DecompressPointer r0
    //     0xf6df60: add             x0, x0, HEAP, lsl #32
    // 0xf6df64: cmp             w0, NULL
    // 0xf6df68: b.eq            #0xf6dfe8
    // 0xf6df6c: LoadField: r1 = r0->field_b
    //     0xf6df6c: ldur            w1, [x0, #0xb]
    // 0xf6df70: DecompressPointer r1
    //     0xf6df70: add             x1, x1, HEAP, lsl #32
    // 0xf6df74: r0 = LoadClassIdInstr(r1)
    //     0xf6df74: ldur            x0, [x1, #-1]
    //     0xf6df78: ubfx            x0, x0, #0xc, #0x14
    // 0xf6df7c: ldur            x2, [fp, #-0x20]
    // 0xf6df80: r0 = GDT[cid_x0 + 0xe0ec]()
    //     0xf6df80: mov             x17, #0xe0ec
    //     0xf6df84: add             lr, x0, x17
    //     0xf6df88: ldr             lr, [x21, lr, lsl #3]
    //     0xf6df8c: blr             lr
    // 0xf6df90: ldur            x0, [fp, #-8]
    // 0xf6df94: LoadField: r2 = r0->field_7
    //     0xf6df94: ldur            w2, [x0, #7]
    // 0xf6df98: DecompressPointer r2
    //     0xf6df98: add             x2, x2, HEAP, lsl #32
    // 0xf6df9c: ldur            x0, [fp, #-0x10]
    // 0xf6dfa0: r1 = Null
    //     0xf6dfa0: mov             x1, NULL
    // 0xf6dfa4: cmp             w2, NULL
    // 0xf6dfa8: b.eq            #0xf6dfcc
    // 0xf6dfac: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf6dfac: ldur            w4, [x2, #0x17]
    // 0xf6dfb0: DecompressPointer r4
    //     0xf6dfb0: add             x4, x4, HEAP, lsl #32
    // 0xf6dfb4: r8 = X0 bound StatefulWidget
    //     0xf6dfb4: add             x8, PP, #0x12, lsl #12  ; [pp+0x12498] TypeParameter: X0 bound StatefulWidget
    //     0xf6dfb8: ldr             x8, [x8, #0x498]
    // 0xf6dfbc: LoadField: r9 = r4->field_7
    //     0xf6dfbc: ldur            x9, [x4, #7]
    // 0xf6dfc0: r3 = Null
    //     0xf6dfc0: add             x3, PP, #0xa0, lsl #12  ; [pp+0xa0e80] Null
    //     0xf6dfc4: ldr             x3, [x3, #0xe80]
    // 0xf6dfc8: blr             x9
    // 0xf6dfcc: r0 = Null
    //     0xf6dfcc: mov             x0, NULL
    // 0xf6dfd0: LeaveFrame
    //     0xf6dfd0: mov             SP, fp
    //     0xf6dfd4: ldp             fp, lr, [SP], #0x10
    // 0xf6dfd8: ret
    //     0xf6dfd8: ret             
    // 0xf6dfdc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6dfdc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6dfe0: b               #0xf6deb0
    // 0xf6dfe4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6dfe4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6dfe8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6dfe8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0xf90f54, size: 0x88
    // 0xf90f54: EnterFrame
    //     0xf90f54: stp             fp, lr, [SP, #-0x10]!
    //     0xf90f58: mov             fp, SP
    // 0xf90f5c: AllocStack(0x8)
    //     0xf90f5c: sub             SP, SP, #8
    // 0xf90f60: SetupParameters(_TextMagnifierState this /* r1 => r2 */)
    //     0xf90f60: mov             x2, x1
    // 0xf90f64: CheckStackOverflow
    //     0xf90f64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf90f68: cmp             SP, x16
    //     0xf90f6c: b.ls            #0xf90fd0
    // 0xf90f70: LoadField: r0 = r2->field_b
    //     0xf90f70: ldur            w0, [x2, #0xb]
    // 0xf90f74: DecompressPointer r0
    //     0xf90f74: add             x0, x0, HEAP, lsl #32
    // 0xf90f78: cmp             w0, NULL
    // 0xf90f7c: b.eq            #0xf90fd8
    // 0xf90f80: LoadField: r3 = r0->field_b
    //     0xf90f80: ldur            w3, [x0, #0xb]
    // 0xf90f84: DecompressPointer r3
    //     0xf90f84: add             x3, x3, HEAP, lsl #32
    // 0xf90f88: stur            x3, [fp, #-8]
    // 0xf90f8c: r1 = Function '_determineMagnifierPositionAndFocalPoint@760515283':.
    //     0xf90f8c: add             x1, PP, #0xa0, lsl #12  ; [pp+0xa0e78] AnonymousClosure: (0xef5738), in [package:flutter/src/material/magnifier.dart] _TextMagnifierState::_determineMagnifierPositionAndFocalPoint (0xef53bc)
    //     0xf90f90: ldr             x1, [x1, #0xe78]
    // 0xf90f94: r0 = AllocateClosure()
    //     0xf90f94: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf90f98: ldur            x1, [fp, #-8]
    // 0xf90f9c: r2 = LoadClassIdInstr(r1)
    //     0xf90f9c: ldur            x2, [x1, #-1]
    //     0xf90fa0: ubfx            x2, x2, #0xc, #0x14
    // 0xf90fa4: mov             x16, x0
    // 0xf90fa8: mov             x0, x2
    // 0xf90fac: mov             x2, x16
    // 0xf90fb0: r0 = GDT[cid_x0 + 0xe0ec]()
    //     0xf90fb0: mov             x17, #0xe0ec
    //     0xf90fb4: add             lr, x0, x17
    //     0xf90fb8: ldr             lr, [x21, lr, lsl #3]
    //     0xf90fbc: blr             lr
    // 0xf90fc0: r0 = Null
    //     0xf90fc0: mov             x0, NULL
    // 0xf90fc4: LeaveFrame
    //     0xf90fc4: mov             SP, fp
    //     0xf90fc8: ldp             fp, lr, [SP], #0x10
    // 0xf90fcc: ret
    //     0xf90fcc: ret             
    // 0xf90fd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf90fd0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf90fd4: b               #0xf90f70
    // 0xf90fd8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf90fd8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10e5cd4, size: 0xa8
    // 0x10e5cd4: EnterFrame
    //     0x10e5cd4: stp             fp, lr, [SP, #-0x10]!
    //     0x10e5cd8: mov             fp, SP
    // 0x10e5cdc: AllocStack(0x10)
    //     0x10e5cdc: sub             SP, SP, #0x10
    // 0x10e5ce0: SetupParameters(_TextMagnifierState this /* r1 => r0, fp-0x10 */)
    //     0x10e5ce0: mov             x0, x1
    //     0x10e5ce4: stur            x1, [fp, #-0x10]
    // 0x10e5ce8: CheckStackOverflow
    //     0x10e5ce8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e5cec: cmp             SP, x16
    //     0x10e5cf0: b.ls            #0x10e5d70
    // 0x10e5cf4: LoadField: r1 = r0->field_b
    //     0x10e5cf4: ldur            w1, [x0, #0xb]
    // 0x10e5cf8: DecompressPointer r1
    //     0x10e5cf8: add             x1, x1, HEAP, lsl #32
    // 0x10e5cfc: cmp             w1, NULL
    // 0x10e5d00: b.eq            #0x10e5d78
    // 0x10e5d04: LoadField: r3 = r1->field_b
    //     0x10e5d04: ldur            w3, [x1, #0xb]
    // 0x10e5d08: DecompressPointer r3
    //     0x10e5d08: add             x3, x3, HEAP, lsl #32
    // 0x10e5d0c: mov             x2, x0
    // 0x10e5d10: stur            x3, [fp, #-8]
    // 0x10e5d14: r1 = Function '_determineMagnifierPositionAndFocalPoint@760515283':.
    //     0x10e5d14: add             x1, PP, #0xa0, lsl #12  ; [pp+0xa0e78] AnonymousClosure: (0xef5738), in [package:flutter/src/material/magnifier.dart] _TextMagnifierState::_determineMagnifierPositionAndFocalPoint (0xef53bc)
    //     0x10e5d18: ldr             x1, [x1, #0xe78]
    // 0x10e5d1c: r0 = AllocateClosure()
    //     0x10e5d1c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10e5d20: ldur            x1, [fp, #-8]
    // 0x10e5d24: r2 = LoadClassIdInstr(r1)
    //     0x10e5d24: ldur            x2, [x1, #-1]
    //     0x10e5d28: ubfx            x2, x2, #0xc, #0x14
    // 0x10e5d2c: mov             x16, x0
    // 0x10e5d30: mov             x0, x2
    // 0x10e5d34: mov             x2, x16
    // 0x10e5d38: r0 = GDT[cid_x0 + 0xe2a3]()
    //     0x10e5d38: mov             x17, #0xe2a3
    //     0x10e5d3c: add             lr, x0, x17
    //     0x10e5d40: ldr             lr, [x21, lr, lsl #3]
    //     0x10e5d44: blr             lr
    // 0x10e5d48: ldur            x0, [fp, #-0x10]
    // 0x10e5d4c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x10e5d4c: ldur            w1, [x0, #0x17]
    // 0x10e5d50: DecompressPointer r1
    //     0x10e5d50: add             x1, x1, HEAP, lsl #32
    // 0x10e5d54: cmp             w1, NULL
    // 0x10e5d58: b.eq            #0x10e5d60
    // 0x10e5d5c: r0 = cancel()
    //     0x10e5d5c: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0x10e5d60: r0 = Null
    //     0x10e5d60: mov             x0, NULL
    // 0x10e5d64: LeaveFrame
    //     0x10e5d64: mov             SP, fp
    //     0x10e5d68: ldp             fp, lr, [SP], #0x10
    // 0x10e5d6c: ret
    //     0x10e5d6c: ret             
    // 0x10e5d70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e5d70: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e5d74: b               #0x10e5cf4
    // 0x10e5d78: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10e5d78: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 6152, size: 0x24, field offset: 0xc
//   const constructor, 
class Magnifier extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfbcd80, size: 0x108
    // 0xfbcd80: EnterFrame
    //     0xfbcd80: stp             fp, lr, [SP, #-0x10]!
    //     0xfbcd84: mov             fp, SP
    // 0xfbcd88: AllocStack(0x18)
    //     0xfbcd88: sub             SP, SP, #0x18
    // 0xfbcd8c: SetupParameters(Magnifier this /* r1 => r1, fp-0x8 */)
    //     0xfbcd8c: stur            x1, [fp, #-8]
    // 0xfbcd90: CheckStackOverflow
    //     0xfbcd90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbcd94: cmp             SP, x16
    //     0xfbcd98: b.ls            #0xfbce80
    // 0xfbcd9c: r0 = RoundedRectangleBorder()
    //     0xfbcd9c: bl              #0xd2ea90  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0xfbcda0: mov             x1, x0
    // 0xfbcda4: r0 = Instance_BorderRadius
    //     0xfbcda4: add             x0, PP, #0xa0, lsl #12  ; [pp+0xa0e40] Obj!BorderRadius@129e3d1
    //     0xfbcda8: ldr             x0, [x0, #0xe40]
    // 0xfbcdac: stur            x1, [fp, #-0x10]
    // 0xfbcdb0: StoreField: r1->field_b = r0
    //     0xfbcdb0: stur            w0, [x1, #0xb]
    // 0xfbcdb4: r0 = Instance_BorderSide
    //     0xfbcdb4: add             x0, PP, #0x18, lsl #12  ; [pp+0x18310] Obj!BorderSide@12b1b31
    //     0xfbcdb8: ldr             x0, [x0, #0x310]
    // 0xfbcdbc: StoreField: r1->field_7 = r0
    //     0xfbcdbc: stur            w0, [x1, #7]
    // 0xfbcdc0: r0 = MagnifierDecoration()
    //     0xfbcdc0: bl              #0xfbce94  ; AllocateMagnifierDecorationStub -> MagnifierDecoration (size=0x18)
    // 0xfbcdc4: d0 = 1.000000
    //     0xfbcdc4: fmov            d0, #1.00000000
    // 0xfbcdc8: stur            x0, [fp, #-0x18]
    // 0xfbcdcc: StoreField: r0->field_7 = d0
    //     0xfbcdcc: stur            d0, [x0, #7]
    // 0xfbcdd0: r1 = const [Instance of 'BoxShadow']
    //     0xfbcdd0: add             x1, PP, #0xa0, lsl #12  ; [pp+0xa0e50] List<BoxShadow>(1)
    //     0xfbcdd4: ldr             x1, [x1, #0xe50]
    // 0xfbcdd8: StoreField: r0->field_f = r1
    //     0xfbcdd8: stur            w1, [x0, #0xf]
    // 0xfbcddc: ldur            x1, [fp, #-0x10]
    // 0xfbcde0: StoreField: r0->field_13 = r1
    //     0xfbcde0: stur            w1, [x0, #0x13]
    // 0xfbcde4: ldur            x1, [fp, #-8]
    // 0xfbcde8: LoadField: r2 = r1->field_b
    //     0xfbcde8: ldur            w2, [x1, #0xb]
    // 0xfbcdec: DecompressPointer r2
    //     0xfbcdec: add             x2, x2, HEAP, lsl #32
    // 0xfbcdf0: stur            x2, [fp, #-0x10]
    // 0xfbcdf4: r0 = Offset()
    //     0xfbcdf4: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xfbcdf8: StoreField: r0->field_7 = rZR
    //     0xfbcdf8: stur            xzr, [x0, #7]
    // 0xfbcdfc: d0 = 40.950000
    //     0xfbcdfc: add             x17, PP, #0xab, lsl #12  ; [pp+0xab020] IMM: double(40.95) from 0x404479999999999a
    //     0xfbce00: ldr             d0, [x17, #0x20]
    // 0xfbce04: StoreField: r0->field_f = d0
    //     0xfbce04: stur            d0, [x0, #0xf]
    // 0xfbce08: ldur            x1, [fp, #-0x10]
    // 0xfbce0c: mov             x2, x0
    // 0xfbce10: r0 = +()
    //     0xfbce10: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0xfbce14: stur            x0, [fp, #-8]
    // 0xfbce18: r0 = ColoredBox()
    //     0xfbce18: bl              #0xd1a914  ; AllocateColoredBoxStub -> ColoredBox (size=0x18)
    // 0xfbce1c: mov             x1, x0
    // 0xfbce20: r0 = Instance_Color
    //     0xfbce20: add             x0, PP, #0xa0, lsl #12  ; [pp+0xa0e48] Obj!Color@12a40e1
    //     0xfbce24: ldr             x0, [x0, #0xe48]
    // 0xfbce28: stur            x1, [fp, #-0x10]
    // 0xfbce2c: StoreField: r1->field_f = r0
    //     0xfbce2c: stur            w0, [x1, #0xf]
    // 0xfbce30: r0 = true
    //     0xfbce30: add             x0, NULL, #0x20  ; true
    // 0xfbce34: StoreField: r1->field_13 = r0
    //     0xfbce34: stur            w0, [x1, #0x13]
    // 0xfbce38: r0 = RawMagnifier()
    //     0xfbce38: bl              #0xfbce88  ; AllocateRawMagnifierStub -> RawMagnifier (size=0x28)
    // 0xfbce3c: ldur            x1, [fp, #-0x10]
    // 0xfbce40: StoreField: r0->field_b = r1
    //     0xfbce40: stur            w1, [x0, #0xb]
    // 0xfbce44: ldur            x1, [fp, #-0x18]
    // 0xfbce48: StoreField: r0->field_f = r1
    //     0xfbce48: stur            w1, [x0, #0xf]
    // 0xfbce4c: r1 = Instance_Clip
    //     0xfbce4c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xfbce50: ldr             x1, [x1, #0x850]
    // 0xfbce54: StoreField: r0->field_13 = r1
    //     0xfbce54: stur            w1, [x0, #0x13]
    // 0xfbce58: ldur            x1, [fp, #-8]
    // 0xfbce5c: ArrayStore: r0[0] = r1  ; List_4
    //     0xfbce5c: stur            w1, [x0, #0x17]
    // 0xfbce60: d0 = 1.250000
    //     0xfbce60: fmov            d0, #1.25000000
    // 0xfbce64: StoreField: r0->field_1b = d0
    //     0xfbce64: stur            d0, [x0, #0x1b]
    // 0xfbce68: r1 = Instance_Size
    //     0xfbce68: add             x1, PP, #0xa0, lsl #12  ; [pp+0xa0e58] Obj!Size@12a7831
    //     0xfbce6c: ldr             x1, [x1, #0xe58]
    // 0xfbce70: StoreField: r0->field_23 = r1
    //     0xfbce70: stur            w1, [x0, #0x23]
    // 0xfbce74: LeaveFrame
    //     0xfbce74: mov             SP, fp
    //     0xfbce78: ldp             fp, lr, [SP], #0x10
    // 0xfbce7c: ret
    //     0xfbce7c: ret             
    // 0xfbce80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbce80: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbce84: b               #0xfbcd9c
  }
}

// class id: 6468, size: 0x10, field offset: 0xc
//   const constructor, 
class TextMagnifier extends StatefulWidget {

  static late TextMagnifierConfiguration adaptiveMagnifierConfiguration; // offset: 0xcb4

  static TextMagnifierConfiguration adaptiveMagnifierConfiguration() {
    // ** addr: 0xd4a54c, size: 0x48
    // 0xd4a54c: EnterFrame
    //     0xd4a54c: stp             fp, lr, [SP, #-0x10]!
    //     0xd4a550: mov             fp, SP
    // 0xd4a554: AllocStack(0x8)
    //     0xd4a554: sub             SP, SP, #8
    // 0xd4a558: r0 = TextMagnifierConfiguration()
    //     0xd4a558: bl              #0xd4a594  ; AllocateTextMagnifierConfigurationStub -> TextMagnifierConfiguration (size=0x10)
    // 0xd4a55c: mov             x3, x0
    // 0xd4a560: r0 = false
    //     0xd4a560: add             x0, NULL, #0x30  ; false
    // 0xd4a564: stur            x3, [fp, #-8]
    // 0xd4a568: StoreField: r3->field_b = r0
    //     0xd4a568: stur            w0, [x3, #0xb]
    // 0xd4a56c: r1 = Function '<anonymous closure>': static.
    //     0xd4a56c: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f8d0] AnonymousClosure: static (0xd4a5a0), in [package:flutter/src/material/magnifier.dart] TextMagnifier::adaptiveMagnifierConfiguration (0xd4a54c)
    //     0xd4a570: ldr             x1, [x1, #0x8d0]
    // 0xd4a574: r2 = Null
    //     0xd4a574: mov             x2, NULL
    // 0xd4a578: r0 = AllocateClosure()
    //     0xd4a578: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd4a57c: mov             x1, x0
    // 0xd4a580: ldur            x0, [fp, #-8]
    // 0xd4a584: StoreField: r0->field_7 = r1
    //     0xd4a584: stur            w1, [x0, #7]
    // 0xd4a588: LeaveFrame
    //     0xd4a588: mov             SP, fp
    //     0xd4a58c: ldp             fp, lr, [SP], #0x10
    // 0xd4a590: ret
    //     0xd4a590: ret             
  }
  [closure] static StatefulWidget? <anonymous closure>(dynamic, BuildContext, MagnifierController, ValueNotifier<MagnifierInfo>) {
    // ** addr: 0xd4a5a0, size: 0x20
    // 0xd4a5a0: EnterFrame
    //     0xd4a5a0: stp             fp, lr, [SP, #-0x10]!
    //     0xd4a5a4: mov             fp, SP
    // 0xd4a5a8: r0 = TextMagnifier()
    //     0xd4a5a8: bl              #0xd4a5c0  ; AllocateTextMagnifierStub -> TextMagnifier (size=0x10)
    // 0xd4a5ac: ldr             x1, [fp, #0x10]
    // 0xd4a5b0: StoreField: r0->field_b = r1
    //     0xd4a5b0: stur            w1, [x0, #0xb]
    // 0xd4a5b4: LeaveFrame
    //     0xd4a5b4: mov             SP, fp
    //     0xd4a5b8: ldp             fp, lr, [SP], #0x10
    // 0xd4a5bc: ret
    //     0xd4a5bc: ret             
  }
  _ createState(/* No info */) {
    // ** addr: 0xfa1dc0, size: 0x2c
    // 0xfa1dc0: EnterFrame
    //     0xfa1dc0: stp             fp, lr, [SP, #-0x10]!
    //     0xfa1dc4: mov             fp, SP
    // 0xfa1dc8: mov             x0, x1
    // 0xfa1dcc: r1 = <TextMagnifier>
    //     0xfa1dcc: add             x1, PP, #0x95, lsl #12  ; [pp+0x95c50] TypeArguments: <TextMagnifier>
    //     0xfa1dd0: ldr             x1, [x1, #0xc50]
    // 0xfa1dd4: r0 = _TextMagnifierState()
    //     0xfa1dd4: bl              #0xfa1dec  ; Allocate_TextMagnifierStateStub -> _TextMagnifierState (size=0x20)
    // 0xfa1dd8: r1 = Instance_Offset
    //     0xfa1dd8: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xfa1ddc: StoreField: r0->field_1b = r1
    //     0xfa1ddc: stur            w1, [x0, #0x1b]
    // 0xfa1de0: LeaveFrame
    //     0xfa1de0: mov             SP, fp
    //     0xfa1de4: ldp             fp, lr, [SP], #0x10
    // 0xfa1de8: ret
    //     0xfa1de8: ret             
  }
}
