// lib: , url: package:flutter/src/material/segmented_button_theme.dart

// class id: 1048943, size: 0x8
class :: {
}

// class id: 5115, size: 0x10, field offset: 0x8
//   const constructor, 
class SegmentedButtonThemeData extends _MixinApplication3&Object&Diagnosticable {

  static _ lerp(/* No info */) {
    // ** addr: 0x1165d6c, size: 0x6c
    // 0x1165d6c: EnterFrame
    //     0x1165d6c: stp             fp, lr, [SP, #-0x10]!
    //     0x1165d70: mov             fp, SP
    // 0x1165d74: AllocStack(0x8)
    //     0x1165d74: sub             SP, SP, #8
    // 0x1165d78: SetupParameters(dynamic _ /* r1 => r0 */)
    //     0x1165d78: mov             x0, x1
    // 0x1165d7c: CheckStackOverflow
    //     0x1165d7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1165d80: cmp             SP, x16
    //     0x1165d84: b.ls            #0x1165dd0
    // 0x1165d88: cmp             w0, w2
    // 0x1165d8c: b.ne            #0x1165d9c
    // 0x1165d90: LeaveFrame
    //     0x1165d90: mov             SP, fp
    //     0x1165d94: ldp             fp, lr, [SP], #0x10
    // 0x1165d98: ret
    //     0x1165d98: ret             
    // 0x1165d9c: LoadField: r1 = r0->field_7
    //     0x1165d9c: ldur            w1, [x0, #7]
    // 0x1165da0: DecompressPointer r1
    //     0x1165da0: add             x1, x1, HEAP, lsl #32
    // 0x1165da4: LoadField: r0 = r2->field_7
    //     0x1165da4: ldur            w0, [x2, #7]
    // 0x1165da8: DecompressPointer r0
    //     0x1165da8: add             x0, x0, HEAP, lsl #32
    // 0x1165dac: mov             x2, x0
    // 0x1165db0: r0 = lerp()
    //     0x1165db0: bl              #0x1164644  ; [package:flutter/src/material/button_style.dart] ButtonStyle::lerp
    // 0x1165db4: stur            x0, [fp, #-8]
    // 0x1165db8: r0 = SegmentedButtonThemeData()
    //     0x1165db8: bl              #0x1165dd8  ; AllocateSegmentedButtonThemeDataStub -> SegmentedButtonThemeData (size=0x10)
    // 0x1165dbc: ldur            x1, [fp, #-8]
    // 0x1165dc0: StoreField: r0->field_7 = r1
    //     0x1165dc0: stur            w1, [x0, #7]
    // 0x1165dc4: LeaveFrame
    //     0x1165dc4: mov             SP, fp
    //     0x1165dc8: ldp             fp, lr, [SP], #0x10
    // 0x1165dcc: ret
    //     0x1165dcc: ret             
    // 0x1165dd0: r0 = StackOverflowSharedWithFPURegs()
    //     0x1165dd0: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1165dd4: b               #0x1165d88
  }
  _ ==(/* No info */) {
    // ** addr: 0x1271a90, size: 0x104
    // 0x1271a90: EnterFrame
    //     0x1271a90: stp             fp, lr, [SP, #-0x10]!
    //     0x1271a94: mov             fp, SP
    // 0x1271a98: AllocStack(0x10)
    //     0x1271a98: sub             SP, SP, #0x10
    // 0x1271a9c: CheckStackOverflow
    //     0x1271a9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1271aa0: cmp             SP, x16
    //     0x1271aa4: b.ls            #0x1271b8c
    // 0x1271aa8: ldr             x0, [fp, #0x10]
    // 0x1271aac: cmp             w0, NULL
    // 0x1271ab0: b.ne            #0x1271ac4
    // 0x1271ab4: r0 = false
    //     0x1271ab4: add             x0, NULL, #0x30  ; false
    // 0x1271ab8: LeaveFrame
    //     0x1271ab8: mov             SP, fp
    //     0x1271abc: ldp             fp, lr, [SP], #0x10
    // 0x1271ac0: ret
    //     0x1271ac0: ret             
    // 0x1271ac4: ldr             x1, [fp, #0x18]
    // 0x1271ac8: cmp             w1, w0
    // 0x1271acc: b.ne            #0x1271ae0
    // 0x1271ad0: r0 = true
    //     0x1271ad0: add             x0, NULL, #0x20  ; true
    // 0x1271ad4: LeaveFrame
    //     0x1271ad4: mov             SP, fp
    //     0x1271ad8: ldp             fp, lr, [SP], #0x10
    // 0x1271adc: ret
    //     0x1271adc: ret             
    // 0x1271ae0: str             x0, [SP]
    // 0x1271ae4: r0 = runtimeType()
    //     0x1271ae4: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x1271ae8: r1 = LoadClassIdInstr(r0)
    //     0x1271ae8: ldur            x1, [x0, #-1]
    //     0x1271aec: ubfx            x1, x1, #0xc, #0x14
    // 0x1271af0: r16 = SegmentedButtonThemeData
    //     0x1271af0: add             x16, PP, #0x26, lsl #12  ; [pp+0x26250] Type: SegmentedButtonThemeData
    //     0x1271af4: ldr             x16, [x16, #0x250]
    // 0x1271af8: stp             x16, x0, [SP]
    // 0x1271afc: mov             x0, x1
    // 0x1271b00: mov             lr, x0
    // 0x1271b04: ldr             lr, [x21, lr, lsl #3]
    // 0x1271b08: blr             lr
    // 0x1271b0c: tbz             w0, #4, #0x1271b20
    // 0x1271b10: r0 = false
    //     0x1271b10: add             x0, NULL, #0x30  ; false
    // 0x1271b14: LeaveFrame
    //     0x1271b14: mov             SP, fp
    //     0x1271b18: ldp             fp, lr, [SP], #0x10
    // 0x1271b1c: ret
    //     0x1271b1c: ret             
    // 0x1271b20: ldr             x0, [fp, #0x10]
    // 0x1271b24: r1 = 60
    //     0x1271b24: mov             x1, #0x3c
    // 0x1271b28: branchIfSmi(r0, 0x1271b34)
    //     0x1271b28: tbz             w0, #0, #0x1271b34
    // 0x1271b2c: r1 = LoadClassIdInstr(r0)
    //     0x1271b2c: ldur            x1, [x0, #-1]
    //     0x1271b30: ubfx            x1, x1, #0xc, #0x14
    // 0x1271b34: r17 = 5115
    //     0x1271b34: mov             x17, #0x13fb
    // 0x1271b38: cmp             x1, x17
    // 0x1271b3c: b.ne            #0x1271b7c
    // 0x1271b40: ldr             x1, [fp, #0x18]
    // 0x1271b44: LoadField: r2 = r0->field_7
    //     0x1271b44: ldur            w2, [x0, #7]
    // 0x1271b48: DecompressPointer r2
    //     0x1271b48: add             x2, x2, HEAP, lsl #32
    // 0x1271b4c: LoadField: r0 = r1->field_7
    //     0x1271b4c: ldur            w0, [x1, #7]
    // 0x1271b50: DecompressPointer r0
    //     0x1271b50: add             x0, x0, HEAP, lsl #32
    // 0x1271b54: r1 = LoadClassIdInstr(r2)
    //     0x1271b54: ldur            x1, [x2, #-1]
    //     0x1271b58: ubfx            x1, x1, #0xc, #0x14
    // 0x1271b5c: stp             x0, x2, [SP]
    // 0x1271b60: mov             x0, x1
    // 0x1271b64: mov             lr, x0
    // 0x1271b68: ldr             lr, [x21, lr, lsl #3]
    // 0x1271b6c: blr             lr
    // 0x1271b70: tbnz            w0, #4, #0x1271b7c
    // 0x1271b74: r0 = true
    //     0x1271b74: add             x0, NULL, #0x20  ; true
    // 0x1271b78: b               #0x1271b80
    // 0x1271b7c: r0 = false
    //     0x1271b7c: add             x0, NULL, #0x30  ; false
    // 0x1271b80: LeaveFrame
    //     0x1271b80: mov             SP, fp
    //     0x1271b84: ldp             fp, lr, [SP], #0x10
    // 0x1271b88: ret
    //     0x1271b88: ret             
    // 0x1271b8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1271b8c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1271b90: b               #0x1271aa8
  }
}
