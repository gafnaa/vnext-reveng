// lib: , url: package:flutter/src/material/drawer_theme.dart

// class id: 1048885, size: 0x8
class :: {
}

// class id: 5157, size: 0x2c, field offset: 0x8
//   const constructor, 
class DrawerThemeData extends _MixinApplication3&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0x1132e6c, size: 0x2d4
    // 0x1132e6c: EnterFrame
    //     0x1132e6c: stp             fp, lr, [SP, #-0x10]!
    //     0x1132e70: mov             fp, SP
    // 0x1132e74: AllocStack(0x70)
    //     0x1132e74: sub             SP, SP, #0x70
    // 0x1132e78: CheckStackOverflow
    //     0x1132e78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1132e7c: cmp             SP, x16
    //     0x1132e80: b.ls            #0x1133138
    // 0x1132e84: ldr             x0, [fp, #0x10]
    // 0x1132e88: r2 = LoadClassIdInstr(r0)
    //     0x1132e88: ldur            x2, [x0, #-1]
    //     0x1132e8c: ubfx            x2, x2, #0xc, #0x14
    // 0x1132e90: stur            x2, [fp, #-8]
    // 0x1132e94: r17 = 5157
    //     0x1132e94: mov             x17, #0x1425
    // 0x1132e98: cmp             x2, x17
    // 0x1132e9c: b.eq            #0x1132ee8
    // 0x1132ea0: r17 = 5158
    //     0x1132ea0: mov             x17, #0x1426
    // 0x1132ea4: cmp             x2, x17
    // 0x1132ea8: b.ne            #0x1132ee4
    // 0x1132eac: LoadField: r1 = r0->field_2b
    //     0x1132eac: ldur            w1, [x0, #0x2b]
    // 0x1132eb0: DecompressPointer r1
    //     0x1132eb0: add             x1, x1, HEAP, lsl #32
    // 0x1132eb4: r0 = of()
    //     0x1132eb4: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x1132eb8: LoadField: r1 = r0->field_3f
    //     0x1132eb8: ldur            w1, [x0, #0x3f]
    // 0x1132ebc: DecompressPointer r1
    //     0x1132ebc: add             x1, x1, HEAP, lsl #32
    // 0x1132ec0: LoadField: r0 = r1->field_93
    //     0x1132ec0: ldur            w0, [x1, #0x93]
    // 0x1132ec4: DecompressPointer r0
    //     0x1132ec4: add             x0, x0, HEAP, lsl #32
    // 0x1132ec8: cmp             w0, NULL
    // 0x1132ecc: b.ne            #0x1132ed8
    // 0x1132ed0: LoadField: r0 = r1->field_7b
    //     0x1132ed0: ldur            w0, [x1, #0x7b]
    // 0x1132ed4: DecompressPointer r0
    //     0x1132ed4: add             x0, x0, HEAP, lsl #32
    // 0x1132ed8: mov             x3, x0
    // 0x1132edc: ldr             x0, [fp, #0x10]
    // 0x1132ee0: b               #0x1132ef4
    // 0x1132ee4: ldr             x0, [fp, #0x10]
    // 0x1132ee8: LoadField: r1 = r0->field_7
    //     0x1132ee8: ldur            w1, [x0, #7]
    // 0x1132eec: DecompressPointer r1
    //     0x1132eec: add             x1, x1, HEAP, lsl #32
    // 0x1132ef0: mov             x3, x1
    // 0x1132ef4: ldur            x2, [fp, #-8]
    // 0x1132ef8: stur            x3, [fp, #-0x18]
    // 0x1132efc: LoadField: r4 = r0->field_f
    //     0x1132efc: ldur            w4, [x0, #0xf]
    // 0x1132f00: DecompressPointer r4
    //     0x1132f00: add             x4, x4, HEAP, lsl #32
    // 0x1132f04: stur            x4, [fp, #-0x10]
    // 0x1132f08: r17 = 5157
    //     0x1132f08: mov             x17, #0x1425
    // 0x1132f0c: cmp             x2, x17
    // 0x1132f10: b.ne            #0x1132f28
    // 0x1132f14: LoadField: r1 = r0->field_13
    //     0x1132f14: ldur            w1, [x0, #0x13]
    // 0x1132f18: DecompressPointer r1
    //     0x1132f18: add             x1, x1, HEAP, lsl #32
    // 0x1132f1c: mov             x0, x2
    // 0x1132f20: mov             x2, x1
    // 0x1132f24: b               #0x1132f60
    // 0x1132f28: r17 = 5158
    //     0x1132f28: mov             x17, #0x1426
    // 0x1132f2c: cmp             x2, x17
    // 0x1132f30: b.ne            #0x1132f44
    // 0x1132f34: mov             x0, x2
    // 0x1132f38: r2 = Instance_Color
    //     0x1132f38: add             x2, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x1132f3c: ldr             x2, [x2, #0x810]
    // 0x1132f40: b               #0x1132f60
    // 0x1132f44: LoadField: r1 = r0->field_2b
    //     0x1132f44: ldur            w1, [x0, #0x2b]
    // 0x1132f48: DecompressPointer r1
    //     0x1132f48: add             x1, x1, HEAP, lsl #32
    // 0x1132f4c: r0 = of()
    //     0x1132f4c: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x1132f50: LoadField: r1 = r0->field_6f
    //     0x1132f50: ldur            w1, [x0, #0x6f]
    // 0x1132f54: DecompressPointer r1
    //     0x1132f54: add             x1, x1, HEAP, lsl #32
    // 0x1132f58: mov             x2, x1
    // 0x1132f5c: ldur            x0, [fp, #-8]
    // 0x1132f60: stur            x2, [fp, #-0x28]
    // 0x1132f64: r17 = 5157
    //     0x1132f64: mov             x17, #0x1425
    // 0x1132f68: cmp             x0, x17
    // 0x1132f6c: b.eq            #0x1132f8c
    // 0x1132f70: r17 = 5158
    //     0x1132f70: mov             x17, #0x1426
    // 0x1132f74: cmp             x0, x17
    // 0x1132f78: b.ne            #0x1132f8c
    // 0x1132f7c: ldr             x3, [fp, #0x10]
    // 0x1132f80: r4 = Instance_Color
    //     0x1132f80: add             x4, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x1132f84: ldr             x4, [x4, #0x810]
    // 0x1132f88: b               #0x1132f9c
    // 0x1132f8c: ldr             x3, [fp, #0x10]
    // 0x1132f90: ArrayLoad: r1 = r3[0]  ; List_4
    //     0x1132f90: ldur            w1, [x3, #0x17]
    // 0x1132f94: DecompressPointer r1
    //     0x1132f94: add             x1, x1, HEAP, lsl #32
    // 0x1132f98: mov             x4, x1
    // 0x1132f9c: stur            x4, [fp, #-0x20]
    // 0x1132fa0: r17 = 5157
    //     0x1132fa0: mov             x17, #0x1425
    // 0x1132fa4: cmp             x0, x17
    // 0x1132fa8: b.ne            #0x1132fbc
    // 0x1132fac: mov             x2, x3
    // 0x1132fb0: r0 = Instance_BorderSide
    //     0x1132fb0: add             x0, PP, #0x18, lsl #12  ; [pp+0x18310] Obj!BorderSide@12b1b31
    //     0x1132fb4: ldr             x0, [x0, #0x310]
    // 0x1132fb8: b               #0x1133034
    // 0x1132fbc: r17 = 5158
    //     0x1132fbc: mov             x17, #0x1426
    // 0x1132fc0: cmp             x0, x17
    // 0x1132fc4: b.ne            #0x1133028
    // 0x1132fc8: mov             x1, x3
    // 0x1132fcc: LoadField: r0 = r1->field_2f
    //     0x1132fcc: ldur            w0, [x1, #0x2f]
    // 0x1132fd0: DecompressPointer r0
    //     0x1132fd0: add             x0, x0, HEAP, lsl #32
    // 0x1132fd4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1132fd8: cmp             w0, w16
    // 0x1132fdc: b.ne            #0x1132fec
    // 0x1132fe0: r2 = direction
    //     0x1132fe0: add             x2, PP, #0x26, lsl #12  ; [pp+0x263b8] Field <_DrawerDefaultsM3@82517151.direction>: late final (offset: 0x30)
    //     0x1132fe4: ldr             x2, [x2, #0x3b8]
    // 0x1132fe8: r0 = InitLateFinalInstanceField()
    //     0x1132fe8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1132fec: mov             x2, x0
    // 0x1132ff0: r1 = Instance_BorderRadiusDirectional
    //     0x1132ff0: add             x1, PP, #0x26, lsl #12  ; [pp+0x263c0] Obj!BorderRadiusDirectional@129e2d1
    //     0x1132ff4: ldr             x1, [x1, #0x3c0]
    // 0x1132ff8: r0 = resolve()
    //     0x1132ff8: bl              #0x1304c78  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusDirectional::resolve
    // 0x1132ffc: stur            x0, [fp, #-0x30]
    // 0x1133000: r0 = RoundedRectangleBorder()
    //     0x1133000: bl              #0xd2ea90  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x1133004: mov             x1, x0
    // 0x1133008: ldur            x0, [fp, #-0x30]
    // 0x113300c: StoreField: r1->field_b = r0
    //     0x113300c: stur            w0, [x1, #0xb]
    // 0x1133010: r0 = Instance_BorderSide
    //     0x1133010: add             x0, PP, #0x18, lsl #12  ; [pp+0x18310] Obj!BorderSide@12b1b31
    //     0x1133014: ldr             x0, [x0, #0x310]
    // 0x1133018: StoreField: r1->field_7 = r0
    //     0x1133018: stur            w0, [x1, #7]
    // 0x113301c: mov             x3, x1
    // 0x1133020: ldr             x2, [fp, #0x10]
    // 0x1133024: b               #0x1133040
    // 0x1133028: r0 = Instance_BorderSide
    //     0x1133028: add             x0, PP, #0x18, lsl #12  ; [pp+0x18310] Obj!BorderSide@12b1b31
    //     0x113302c: ldr             x0, [x0, #0x310]
    // 0x1133030: ldr             x2, [fp, #0x10]
    // 0x1133034: LoadField: r1 = r2->field_1b
    //     0x1133034: ldur            w1, [x2, #0x1b]
    // 0x1133038: DecompressPointer r1
    //     0x1133038: add             x1, x1, HEAP, lsl #32
    // 0x113303c: mov             x3, x1
    // 0x1133040: ldur            x1, [fp, #-8]
    // 0x1133044: stur            x3, [fp, #-0x30]
    // 0x1133048: r17 = 5157
    //     0x1133048: mov             x17, #0x1425
    // 0x113304c: cmp             x1, x17
    // 0x1133050: b.ne            #0x113305c
    // 0x1133054: mov             x0, x2
    // 0x1133058: b               #0x11330c8
    // 0x113305c: r17 = 5158
    //     0x113305c: mov             x17, #0x1426
    // 0x1133060: cmp             x1, x17
    // 0x1133064: b.ne            #0x11330c4
    // 0x1133068: mov             x1, x2
    // 0x113306c: LoadField: r0 = r1->field_2f
    //     0x113306c: ldur            w0, [x1, #0x2f]
    // 0x1133070: DecompressPointer r0
    //     0x1133070: add             x0, x0, HEAP, lsl #32
    // 0x1133074: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1133078: cmp             w0, w16
    // 0x113307c: b.ne            #0x113308c
    // 0x1133080: r2 = direction
    //     0x1133080: add             x2, PP, #0x26, lsl #12  ; [pp+0x263b8] Field <_DrawerDefaultsM3@82517151.direction>: late final (offset: 0x30)
    //     0x1133084: ldr             x2, [x2, #0x3b8]
    // 0x1133088: r0 = InitLateFinalInstanceField()
    //     0x1133088: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x113308c: mov             x2, x0
    // 0x1133090: r1 = Instance_BorderRadiusDirectional
    //     0x1133090: add             x1, PP, #0x26, lsl #12  ; [pp+0x263c8] Obj!BorderRadiusDirectional@129e2b1
    //     0x1133094: ldr             x1, [x1, #0x3c8]
    // 0x1133098: r0 = resolve()
    //     0x1133098: bl              #0x1304c78  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusDirectional::resolve
    // 0x113309c: stur            x0, [fp, #-0x38]
    // 0x11330a0: r0 = RoundedRectangleBorder()
    //     0x11330a0: bl              #0xd2ea90  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x11330a4: mov             x1, x0
    // 0x11330a8: ldur            x0, [fp, #-0x38]
    // 0x11330ac: StoreField: r1->field_b = r0
    //     0x11330ac: stur            w0, [x1, #0xb]
    // 0x11330b0: r0 = Instance_BorderSide
    //     0x11330b0: add             x0, PP, #0x18, lsl #12  ; [pp+0x18310] Obj!BorderSide@12b1b31
    //     0x11330b4: ldr             x0, [x0, #0x310]
    // 0x11330b8: StoreField: r1->field_7 = r0
    //     0x11330b8: stur            w0, [x1, #7]
    // 0x11330bc: ldr             x0, [fp, #0x10]
    // 0x11330c0: b               #0x11330d0
    // 0x11330c4: ldr             x0, [fp, #0x10]
    // 0x11330c8: LoadField: r1 = r0->field_1f
    //     0x11330c8: ldur            w1, [x0, #0x1f]
    // 0x11330cc: DecompressPointer r1
    //     0x11330cc: add             x1, x1, HEAP, lsl #32
    // 0x11330d0: LoadField: r2 = r0->field_23
    //     0x11330d0: ldur            w2, [x0, #0x23]
    // 0x11330d4: DecompressPointer r2
    //     0x11330d4: add             x2, x2, HEAP, lsl #32
    // 0x11330d8: LoadField: r3 = r0->field_27
    //     0x11330d8: ldur            w3, [x0, #0x27]
    // 0x11330dc: DecompressPointer r3
    //     0x11330dc: add             x3, x3, HEAP, lsl #32
    // 0x11330e0: ldur            x16, [fp, #-0x10]
    // 0x11330e4: ldur            lr, [fp, #-0x28]
    // 0x11330e8: stp             lr, x16, [SP, #0x28]
    // 0x11330ec: ldur            x16, [fp, #-0x20]
    // 0x11330f0: ldur            lr, [fp, #-0x30]
    // 0x11330f4: stp             lr, x16, [SP, #0x18]
    // 0x11330f8: stp             x2, x1, [SP, #8]
    // 0x11330fc: str             x3, [SP]
    // 0x1133100: ldur            x1, [fp, #-0x18]
    // 0x1133104: r2 = Null
    //     0x1133104: mov             x2, NULL
    // 0x1133108: r4 = const [0, 0x9, 0x7, 0x9, null]
    //     0x1133108: add             x4, PP, #0xe, lsl #12  ; [pp+0xe278] List(5) [0, 0x9, 0x7, 0x9, Null]
    //     0x113310c: ldr             x4, [x4, #0x278]
    // 0x1133110: r0 = hash()
    //     0x1133110: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x1133114: mov             x2, x0
    // 0x1133118: r0 = BoxInt64Instr(r2)
    //     0x1133118: sbfiz           x0, x2, #1, #0x1f
    //     0x113311c: cmp             x2, x0, asr #1
    //     0x1133120: b.eq            #0x113312c
    //     0x1133124: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1133128: stur            x2, [x0, #7]
    // 0x113312c: LeaveFrame
    //     0x113312c: mov             SP, fp
    //     0x1133130: ldp             fp, lr, [SP], #0x10
    // 0x1133134: ret
    //     0x1133134: ret             
    // 0x1133138: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1133138: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x113313c: b               #0x1132e84
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x1167564, size: 0x19c
    // 0x1167564: EnterFrame
    //     0x1167564: stp             fp, lr, [SP, #-0x10]!
    //     0x1167568: mov             fp, SP
    // 0x116756c: AllocStack(0x30)
    //     0x116756c: sub             SP, SP, #0x30
    // 0x1167570: SetupParameters(dynamic _ /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */, dynamic _ /* d0 => d0, fp-0x30 */)
    //     0x1167570: mov             x4, x1
    //     0x1167574: mov             x0, x2
    //     0x1167578: stur            x1, [fp, #-0x10]
    //     0x116757c: stur            x2, [fp, #-0x18]
    //     0x1167580: stur            d0, [fp, #-0x30]
    // 0x1167584: CheckStackOverflow
    //     0x1167584: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1167588: cmp             SP, x16
    //     0x116758c: b.ls            #0x11676dc
    // 0x1167590: cmp             w4, w0
    // 0x1167594: b.ne            #0x11675a8
    // 0x1167598: mov             x0, x4
    // 0x116759c: LeaveFrame
    //     0x116759c: mov             SP, fp
    //     0x11675a0: ldp             fp, lr, [SP], #0x10
    // 0x11675a4: ret
    //     0x11675a4: ret             
    // 0x11675a8: r5 = inline_Allocate_Double()
    //     0x11675a8: ldp             x5, x1, [THR, #0x60]  ; THR::top
    //     0x11675ac: add             x5, x5, #0x10
    //     0x11675b0: cmp             x1, x5
    //     0x11675b4: b.ls            #0x11676e4
    //     0x11675b8: str             x5, [THR, #0x60]  ; THR::top
    //     0x11675bc: sub             x5, x5, #0xf
    //     0x11675c0: mov             x1, #0xe19c
    //     0x11675c4: movk            x1, #3, lsl #16
    //     0x11675c8: stur            x1, [x5, #-1]
    // 0x11675cc: dmb             ishst
    // 0x11675d0: StoreField: r5->field_7 = d0
    //     0x11675d0: stur            d0, [x5, #7]
    // 0x11675d4: mov             x3, x5
    // 0x11675d8: stur            x5, [fp, #-8]
    // 0x11675dc: r1 = Null
    //     0x11675dc: mov             x1, NULL
    // 0x11675e0: r2 = Null
    //     0x11675e0: mov             x2, NULL
    // 0x11675e4: r0 = lerp()
    //     0x11675e4: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x11675e8: ldur            x3, [fp, #-8]
    // 0x11675ec: r1 = Null
    //     0x11675ec: mov             x1, NULL
    // 0x11675f0: r2 = Null
    //     0x11675f0: mov             x2, NULL
    // 0x11675f4: r0 = lerp()
    //     0x11675f4: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x11675f8: ldur            x0, [fp, #-0x10]
    // 0x11675fc: LoadField: r1 = r0->field_f
    //     0x11675fc: ldur            w1, [x0, #0xf]
    // 0x1167600: DecompressPointer r1
    //     0x1167600: add             x1, x1, HEAP, lsl #32
    // 0x1167604: ldur            x4, [fp, #-0x18]
    // 0x1167608: LoadField: r2 = r4->field_f
    //     0x1167608: ldur            w2, [x4, #0xf]
    // 0x116760c: DecompressPointer r2
    //     0x116760c: add             x2, x2, HEAP, lsl #32
    // 0x1167610: ldur            x3, [fp, #-8]
    // 0x1167614: r0 = lerpDouble()
    //     0x1167614: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1167618: ldur            x3, [fp, #-8]
    // 0x116761c: r1 = Null
    //     0x116761c: mov             x1, NULL
    // 0x1167620: r2 = Null
    //     0x1167620: mov             x2, NULL
    // 0x1167624: stur            x0, [fp, #-0x20]
    // 0x1167628: r0 = lerp()
    //     0x1167628: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x116762c: ldur            x3, [fp, #-8]
    // 0x1167630: r1 = Null
    //     0x1167630: mov             x1, NULL
    // 0x1167634: r2 = Null
    //     0x1167634: mov             x2, NULL
    // 0x1167638: r0 = lerp()
    //     0x1167638: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x116763c: ldur            d0, [fp, #-0x30]
    // 0x1167640: r1 = Null
    //     0x1167640: mov             x1, NULL
    // 0x1167644: r2 = Null
    //     0x1167644: mov             x2, NULL
    // 0x1167648: r0 = lerp()
    //     0x1167648: bl              #0x115deb4  ; [package:flutter/src/painting/borders.dart] ShapeBorder::lerp
    // 0x116764c: ldur            d0, [fp, #-0x30]
    // 0x1167650: r1 = Null
    //     0x1167650: mov             x1, NULL
    // 0x1167654: r2 = Null
    //     0x1167654: mov             x2, NULL
    // 0x1167658: r0 = lerp()
    //     0x1167658: bl              #0x115deb4  ; [package:flutter/src/painting/borders.dart] ShapeBorder::lerp
    // 0x116765c: ldur            x0, [fp, #-0x10]
    // 0x1167660: LoadField: r1 = r0->field_23
    //     0x1167660: ldur            w1, [x0, #0x23]
    // 0x1167664: DecompressPointer r1
    //     0x1167664: add             x1, x1, HEAP, lsl #32
    // 0x1167668: ldur            x4, [fp, #-0x18]
    // 0x116766c: LoadField: r2 = r4->field_23
    //     0x116766c: ldur            w2, [x4, #0x23]
    // 0x1167670: DecompressPointer r2
    //     0x1167670: add             x2, x2, HEAP, lsl #32
    // 0x1167674: ldur            x3, [fp, #-8]
    // 0x1167678: r0 = lerpDouble()
    //     0x1167678: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x116767c: ldur            d0, [fp, #-0x30]
    // 0x1167680: d1 = 0.500000
    //     0x1167680: fmov            d1, #0.50000000
    // 0x1167684: stur            x0, [fp, #-0x28]
    // 0x1167688: fcmp            d1, d0
    // 0x116768c: b.le            #0x11676a0
    // 0x1167690: ldur            x1, [fp, #-0x10]
    // 0x1167694: LoadField: r2 = r1->field_27
    //     0x1167694: ldur            w2, [x1, #0x27]
    // 0x1167698: DecompressPointer r2
    //     0x1167698: add             x2, x2, HEAP, lsl #32
    // 0x116769c: b               #0x11676ac
    // 0x11676a0: ldur            x1, [fp, #-0x18]
    // 0x11676a4: LoadField: r2 = r1->field_27
    //     0x11676a4: ldur            w2, [x1, #0x27]
    // 0x11676a8: DecompressPointer r2
    //     0x11676a8: add             x2, x2, HEAP, lsl #32
    // 0x11676ac: ldur            x1, [fp, #-0x20]
    // 0x11676b0: stur            x2, [fp, #-8]
    // 0x11676b4: r0 = DrawerThemeData()
    //     0x11676b4: bl              #0x1167700  ; AllocateDrawerThemeDataStub -> DrawerThemeData (size=0x2c)
    // 0x11676b8: ldur            x1, [fp, #-0x20]
    // 0x11676bc: StoreField: r0->field_f = r1
    //     0x11676bc: stur            w1, [x0, #0xf]
    // 0x11676c0: ldur            x1, [fp, #-0x28]
    // 0x11676c4: StoreField: r0->field_23 = r1
    //     0x11676c4: stur            w1, [x0, #0x23]
    // 0x11676c8: ldur            x1, [fp, #-8]
    // 0x11676cc: StoreField: r0->field_27 = r1
    //     0x11676cc: stur            w1, [x0, #0x27]
    // 0x11676d0: LeaveFrame
    //     0x11676d0: mov             SP, fp
    //     0x11676d4: ldp             fp, lr, [SP], #0x10
    // 0x11676d8: ret
    //     0x11676d8: ret             
    // 0x11676dc: r0 = StackOverflowSharedWithFPURegs()
    //     0x11676dc: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x11676e0: b               #0x1167590
    // 0x11676e4: SaveReg d0
    //     0x11676e4: str             q0, [SP, #-0x10]!
    // 0x11676e8: stp             x0, x4, [SP, #-0x10]!
    // 0x11676ec: r0 = AllocateDouble()
    //     0x11676ec: bl              #0x13df878  ; AllocateDoubleStub
    // 0x11676f0: mov             x5, x0
    // 0x11676f4: ldp             x0, x4, [SP], #0x10
    // 0x11676f8: RestoreReg d0
    //     0x11676f8: ldr             q0, [SP], #0x10
    // 0x11676fc: b               #0x11675d0
  }
  _ ==(/* No info */) {
    // ** addr: 0x126b888, size: 0x668
    // 0x126b888: EnterFrame
    //     0x126b888: stp             fp, lr, [SP, #-0x10]!
    //     0x126b88c: mov             fp, SP
    // 0x126b890: AllocStack(0x30)
    //     0x126b890: sub             SP, SP, #0x30
    // 0x126b894: CheckStackOverflow
    //     0x126b894: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x126b898: cmp             SP, x16
    //     0x126b89c: b.ls            #0x126bee8
    // 0x126b8a0: ldr             x1, [fp, #0x10]
    // 0x126b8a4: cmp             w1, NULL
    // 0x126b8a8: b.ne            #0x126b8bc
    // 0x126b8ac: r0 = false
    //     0x126b8ac: add             x0, NULL, #0x30  ; false
    // 0x126b8b0: LeaveFrame
    //     0x126b8b0: mov             SP, fp
    //     0x126b8b4: ldp             fp, lr, [SP], #0x10
    // 0x126b8b8: ret
    //     0x126b8b8: ret             
    // 0x126b8bc: ldr             x0, [fp, #0x18]
    // 0x126b8c0: cmp             w0, w1
    // 0x126b8c4: b.ne            #0x126b8d8
    // 0x126b8c8: r0 = true
    //     0x126b8c8: add             x0, NULL, #0x20  ; true
    // 0x126b8cc: LeaveFrame
    //     0x126b8cc: mov             SP, fp
    //     0x126b8d0: ldp             fp, lr, [SP], #0x10
    // 0x126b8d4: ret
    //     0x126b8d4: ret             
    // 0x126b8d8: stp             x0, x1, [SP]
    // 0x126b8dc: r0 = _haveSameRuntimeType()
    //     0x126b8dc: bl              #0x88249c  ; [dart:core] Object::_haveSameRuntimeType
    // 0x126b8e0: tbz             w0, #4, #0x126b8f4
    // 0x126b8e4: r0 = false
    //     0x126b8e4: add             x0, NULL, #0x30  ; false
    // 0x126b8e8: LeaveFrame
    //     0x126b8e8: mov             SP, fp
    //     0x126b8ec: ldp             fp, lr, [SP], #0x10
    // 0x126b8f0: ret
    //     0x126b8f0: ret             
    // 0x126b8f4: ldr             x0, [fp, #0x10]
    // 0x126b8f8: r2 = 60
    //     0x126b8f8: mov             x2, #0x3c
    // 0x126b8fc: branchIfSmi(r0, 0x126b908)
    //     0x126b8fc: tbz             w0, #0, #0x126b908
    // 0x126b900: r2 = LoadClassIdInstr(r0)
    //     0x126b900: ldur            x2, [x0, #-1]
    //     0x126b904: ubfx            x2, x2, #0xc, #0x14
    // 0x126b908: stur            x2, [fp, #-8]
    // 0x126b90c: r17 = -5157
    //     0x126b90c: mov             x17, #-0x1425
    // 0x126b910: add             x16, x2, x17
    // 0x126b914: cmp             x16, #2
    // 0x126b918: b.hi            #0x126bed8
    // 0x126b91c: r17 = 5157
    //     0x126b91c: mov             x17, #0x1425
    // 0x126b920: cmp             x2, x17
    // 0x126b924: b.eq            #0x126b970
    // 0x126b928: r17 = 5158
    //     0x126b928: mov             x17, #0x1426
    // 0x126b92c: cmp             x2, x17
    // 0x126b930: b.ne            #0x126b96c
    // 0x126b934: LoadField: r1 = r0->field_2b
    //     0x126b934: ldur            w1, [x0, #0x2b]
    // 0x126b938: DecompressPointer r1
    //     0x126b938: add             x1, x1, HEAP, lsl #32
    // 0x126b93c: r0 = of()
    //     0x126b93c: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x126b940: LoadField: r1 = r0->field_3f
    //     0x126b940: ldur            w1, [x0, #0x3f]
    // 0x126b944: DecompressPointer r1
    //     0x126b944: add             x1, x1, HEAP, lsl #32
    // 0x126b948: LoadField: r0 = r1->field_93
    //     0x126b948: ldur            w0, [x1, #0x93]
    // 0x126b94c: DecompressPointer r0
    //     0x126b94c: add             x0, x0, HEAP, lsl #32
    // 0x126b950: cmp             w0, NULL
    // 0x126b954: b.ne            #0x126b960
    // 0x126b958: LoadField: r0 = r1->field_7b
    //     0x126b958: ldur            w0, [x1, #0x7b]
    // 0x126b95c: DecompressPointer r0
    //     0x126b95c: add             x0, x0, HEAP, lsl #32
    // 0x126b960: mov             x3, x0
    // 0x126b964: ldr             x0, [fp, #0x10]
    // 0x126b968: b               #0x126b97c
    // 0x126b96c: ldr             x0, [fp, #0x10]
    // 0x126b970: LoadField: r1 = r0->field_7
    //     0x126b970: ldur            w1, [x0, #7]
    // 0x126b974: DecompressPointer r1
    //     0x126b974: add             x1, x1, HEAP, lsl #32
    // 0x126b978: mov             x3, x1
    // 0x126b97c: ldr             x2, [fp, #0x18]
    // 0x126b980: stur            x3, [fp, #-0x18]
    // 0x126b984: r4 = LoadClassIdInstr(r2)
    //     0x126b984: ldur            x4, [x2, #-1]
    //     0x126b988: ubfx            x4, x4, #0xc, #0x14
    // 0x126b98c: stur            x4, [fp, #-0x10]
    // 0x126b990: r17 = 5157
    //     0x126b990: mov             x17, #0x1425
    // 0x126b994: cmp             x4, x17
    // 0x126b998: b.ne            #0x126b9a4
    // 0x126b99c: mov             x1, x2
    // 0x126b9a0: b               #0x126b9ec
    // 0x126b9a4: r17 = 5158
    //     0x126b9a4: mov             x17, #0x1426
    // 0x126b9a8: cmp             x4, x17
    // 0x126b9ac: b.ne            #0x126b9e8
    // 0x126b9b0: LoadField: r1 = r2->field_2b
    //     0x126b9b0: ldur            w1, [x2, #0x2b]
    // 0x126b9b4: DecompressPointer r1
    //     0x126b9b4: add             x1, x1, HEAP, lsl #32
    // 0x126b9b8: r0 = of()
    //     0x126b9b8: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x126b9bc: LoadField: r1 = r0->field_3f
    //     0x126b9bc: ldur            w1, [x0, #0x3f]
    // 0x126b9c0: DecompressPointer r1
    //     0x126b9c0: add             x1, x1, HEAP, lsl #32
    // 0x126b9c4: LoadField: r0 = r1->field_93
    //     0x126b9c4: ldur            w0, [x1, #0x93]
    // 0x126b9c8: DecompressPointer r0
    //     0x126b9c8: add             x0, x0, HEAP, lsl #32
    // 0x126b9cc: cmp             w0, NULL
    // 0x126b9d0: b.ne            #0x126b9dc
    // 0x126b9d4: LoadField: r0 = r1->field_7b
    //     0x126b9d4: ldur            w0, [x1, #0x7b]
    // 0x126b9d8: DecompressPointer r0
    //     0x126b9d8: add             x0, x0, HEAP, lsl #32
    // 0x126b9dc: mov             x2, x0
    // 0x126b9e0: ldr             x1, [fp, #0x18]
    // 0x126b9e4: b               #0x126b9f8
    // 0x126b9e8: ldr             x1, [fp, #0x18]
    // 0x126b9ec: LoadField: r0 = r1->field_7
    //     0x126b9ec: ldur            w0, [x1, #7]
    // 0x126b9f0: DecompressPointer r0
    //     0x126b9f0: add             x0, x0, HEAP, lsl #32
    // 0x126b9f4: mov             x2, x0
    // 0x126b9f8: ldur            x0, [fp, #-0x18]
    // 0x126b9fc: r3 = LoadClassIdInstr(r0)
    //     0x126b9fc: ldur            x3, [x0, #-1]
    //     0x126ba00: ubfx            x3, x3, #0xc, #0x14
    // 0x126ba04: stp             x2, x0, [SP]
    // 0x126ba08: mov             x0, x3
    // 0x126ba0c: mov             lr, x0
    // 0x126ba10: ldr             lr, [x21, lr, lsl #3]
    // 0x126ba14: blr             lr
    // 0x126ba18: tbnz            w0, #4, #0x126bed8
    // 0x126ba1c: ldr             x1, [fp, #0x18]
    // 0x126ba20: ldr             x2, [fp, #0x10]
    // 0x126ba24: LoadField: r0 = r2->field_f
    //     0x126ba24: ldur            w0, [x2, #0xf]
    // 0x126ba28: DecompressPointer r0
    //     0x126ba28: add             x0, x0, HEAP, lsl #32
    // 0x126ba2c: LoadField: r3 = r1->field_f
    //     0x126ba2c: ldur            w3, [x1, #0xf]
    // 0x126ba30: DecompressPointer r3
    //     0x126ba30: add             x3, x3, HEAP, lsl #32
    // 0x126ba34: r4 = LoadClassIdInstr(r0)
    //     0x126ba34: ldur            x4, [x0, #-1]
    //     0x126ba38: ubfx            x4, x4, #0xc, #0x14
    // 0x126ba3c: stp             x3, x0, [SP]
    // 0x126ba40: mov             x0, x4
    // 0x126ba44: mov             lr, x0
    // 0x126ba48: ldr             lr, [x21, lr, lsl #3]
    // 0x126ba4c: blr             lr
    // 0x126ba50: tbnz            w0, #4, #0x126bed8
    // 0x126ba54: ldur            x0, [fp, #-8]
    // 0x126ba58: r17 = 5157
    //     0x126ba58: mov             x17, #0x1425
    // 0x126ba5c: cmp             x0, x17
    // 0x126ba60: b.ne            #0x126ba78
    // 0x126ba64: ldr             x2, [fp, #0x10]
    // 0x126ba68: LoadField: r1 = r2->field_13
    //     0x126ba68: ldur            w1, [x2, #0x13]
    // 0x126ba6c: DecompressPointer r1
    //     0x126ba6c: add             x1, x1, HEAP, lsl #32
    // 0x126ba70: mov             x2, x1
    // 0x126ba74: b               #0x126baac
    // 0x126ba78: ldr             x2, [fp, #0x10]
    // 0x126ba7c: r17 = 5158
    //     0x126ba7c: mov             x17, #0x1426
    // 0x126ba80: cmp             x0, x17
    // 0x126ba84: b.ne            #0x126ba94
    // 0x126ba88: r2 = Instance_Color
    //     0x126ba88: add             x2, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x126ba8c: ldr             x2, [x2, #0x810]
    // 0x126ba90: b               #0x126baac
    // 0x126ba94: LoadField: r1 = r2->field_2b
    //     0x126ba94: ldur            w1, [x2, #0x2b]
    // 0x126ba98: DecompressPointer r1
    //     0x126ba98: add             x1, x1, HEAP, lsl #32
    // 0x126ba9c: r0 = of()
    //     0x126ba9c: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x126baa0: LoadField: r1 = r0->field_6f
    //     0x126baa0: ldur            w1, [x0, #0x6f]
    // 0x126baa4: DecompressPointer r1
    //     0x126baa4: add             x1, x1, HEAP, lsl #32
    // 0x126baa8: mov             x2, x1
    // 0x126baac: ldur            x0, [fp, #-0x10]
    // 0x126bab0: stur            x2, [fp, #-0x18]
    // 0x126bab4: r17 = 5157
    //     0x126bab4: mov             x17, #0x1425
    // 0x126bab8: cmp             x0, x17
    // 0x126babc: b.ne            #0x126bad4
    // 0x126bac0: ldr             x3, [fp, #0x18]
    // 0x126bac4: LoadField: r1 = r3->field_13
    //     0x126bac4: ldur            w1, [x3, #0x13]
    // 0x126bac8: DecompressPointer r1
    //     0x126bac8: add             x1, x1, HEAP, lsl #32
    // 0x126bacc: mov             x0, x2
    // 0x126bad0: b               #0x126bb0c
    // 0x126bad4: ldr             x3, [fp, #0x18]
    // 0x126bad8: r17 = 5158
    //     0x126bad8: mov             x17, #0x1426
    // 0x126badc: cmp             x0, x17
    // 0x126bae0: b.ne            #0x126baf4
    // 0x126bae4: mov             x0, x2
    // 0x126bae8: r1 = Instance_Color
    //     0x126bae8: add             x1, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x126baec: ldr             x1, [x1, #0x810]
    // 0x126baf0: b               #0x126bb0c
    // 0x126baf4: LoadField: r1 = r3->field_2b
    //     0x126baf4: ldur            w1, [x3, #0x2b]
    // 0x126baf8: DecompressPointer r1
    //     0x126baf8: add             x1, x1, HEAP, lsl #32
    // 0x126bafc: r0 = of()
    //     0x126bafc: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x126bb00: LoadField: r1 = r0->field_6f
    //     0x126bb00: ldur            w1, [x0, #0x6f]
    // 0x126bb04: DecompressPointer r1
    //     0x126bb04: add             x1, x1, HEAP, lsl #32
    // 0x126bb08: ldur            x0, [fp, #-0x18]
    // 0x126bb0c: r2 = LoadClassIdInstr(r0)
    //     0x126bb0c: ldur            x2, [x0, #-1]
    //     0x126bb10: ubfx            x2, x2, #0xc, #0x14
    // 0x126bb14: stp             x1, x0, [SP]
    // 0x126bb18: mov             x0, x2
    // 0x126bb1c: mov             lr, x0
    // 0x126bb20: ldr             lr, [x21, lr, lsl #3]
    // 0x126bb24: blr             lr
    // 0x126bb28: tbnz            w0, #4, #0x126bed8
    // 0x126bb2c: ldur            x1, [fp, #-8]
    // 0x126bb30: r17 = 5157
    //     0x126bb30: mov             x17, #0x1425
    // 0x126bb34: cmp             x1, x17
    // 0x126bb38: b.eq            #0x126bb58
    // 0x126bb3c: r17 = 5158
    //     0x126bb3c: mov             x17, #0x1426
    // 0x126bb40: cmp             x1, x17
    // 0x126bb44: b.ne            #0x126bb58
    // 0x126bb48: ldr             x2, [fp, #0x10]
    // 0x126bb4c: r0 = Instance_Color
    //     0x126bb4c: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x126bb50: ldr             x0, [x0, #0x810]
    // 0x126bb54: b               #0x126bb64
    // 0x126bb58: ldr             x2, [fp, #0x10]
    // 0x126bb5c: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x126bb5c: ldur            w0, [x2, #0x17]
    // 0x126bb60: DecompressPointer r0
    //     0x126bb60: add             x0, x0, HEAP, lsl #32
    // 0x126bb64: ldur            x3, [fp, #-0x10]
    // 0x126bb68: r17 = 5157
    //     0x126bb68: mov             x17, #0x1425
    // 0x126bb6c: cmp             x3, x17
    // 0x126bb70: b.eq            #0x126bb90
    // 0x126bb74: r17 = 5158
    //     0x126bb74: mov             x17, #0x1426
    // 0x126bb78: cmp             x3, x17
    // 0x126bb7c: b.ne            #0x126bb90
    // 0x126bb80: ldr             x4, [fp, #0x18]
    // 0x126bb84: r5 = Instance_Color
    //     0x126bb84: add             x5, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x126bb88: ldr             x5, [x5, #0x810]
    // 0x126bb8c: b               #0x126bb9c
    // 0x126bb90: ldr             x4, [fp, #0x18]
    // 0x126bb94: ArrayLoad: r5 = r4[0]  ; List_4
    //     0x126bb94: ldur            w5, [x4, #0x17]
    // 0x126bb98: DecompressPointer r5
    //     0x126bb98: add             x5, x5, HEAP, lsl #32
    // 0x126bb9c: r6 = LoadClassIdInstr(r0)
    //     0x126bb9c: ldur            x6, [x0, #-1]
    //     0x126bba0: ubfx            x6, x6, #0xc, #0x14
    // 0x126bba4: stp             x5, x0, [SP]
    // 0x126bba8: mov             x0, x6
    // 0x126bbac: mov             lr, x0
    // 0x126bbb0: ldr             lr, [x21, lr, lsl #3]
    // 0x126bbb4: blr             lr
    // 0x126bbb8: tbnz            w0, #4, #0x126bed8
    // 0x126bbbc: ldur            x0, [fp, #-8]
    // 0x126bbc0: r17 = 5157
    //     0x126bbc0: mov             x17, #0x1425
    // 0x126bbc4: cmp             x0, x17
    // 0x126bbc8: b.ne            #0x126bbd8
    // 0x126bbcc: r0 = Instance_BorderSide
    //     0x126bbcc: add             x0, PP, #0x18, lsl #12  ; [pp+0x18310] Obj!BorderSide@12b1b31
    //     0x126bbd0: ldr             x0, [x0, #0x310]
    // 0x126bbd4: b               #0x126bc4c
    // 0x126bbd8: r17 = 5158
    //     0x126bbd8: mov             x17, #0x1426
    // 0x126bbdc: cmp             x0, x17
    // 0x126bbe0: b.ne            #0x126bc44
    // 0x126bbe4: ldr             x1, [fp, #0x10]
    // 0x126bbe8: LoadField: r0 = r1->field_2f
    //     0x126bbe8: ldur            w0, [x1, #0x2f]
    // 0x126bbec: DecompressPointer r0
    //     0x126bbec: add             x0, x0, HEAP, lsl #32
    // 0x126bbf0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126bbf4: cmp             w0, w16
    // 0x126bbf8: b.ne            #0x126bc08
    // 0x126bbfc: r2 = direction
    //     0x126bbfc: add             x2, PP, #0x26, lsl #12  ; [pp+0x263b8] Field <_DrawerDefaultsM3@82517151.direction>: late final (offset: 0x30)
    //     0x126bc00: ldr             x2, [x2, #0x3b8]
    // 0x126bc04: r0 = InitLateFinalInstanceField()
    //     0x126bc04: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126bc08: mov             x2, x0
    // 0x126bc0c: r1 = Instance_BorderRadiusDirectional
    //     0x126bc0c: add             x1, PP, #0x26, lsl #12  ; [pp+0x263c0] Obj!BorderRadiusDirectional@129e2d1
    //     0x126bc10: ldr             x1, [x1, #0x3c0]
    // 0x126bc14: r0 = resolve()
    //     0x126bc14: bl              #0x1304c78  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusDirectional::resolve
    // 0x126bc18: stur            x0, [fp, #-0x18]
    // 0x126bc1c: r0 = RoundedRectangleBorder()
    //     0x126bc1c: bl              #0xd2ea90  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x126bc20: mov             x1, x0
    // 0x126bc24: ldur            x0, [fp, #-0x18]
    // 0x126bc28: StoreField: r1->field_b = r0
    //     0x126bc28: stur            w0, [x1, #0xb]
    // 0x126bc2c: r0 = Instance_BorderSide
    //     0x126bc2c: add             x0, PP, #0x18, lsl #12  ; [pp+0x18310] Obj!BorderSide@12b1b31
    //     0x126bc30: ldr             x0, [x0, #0x310]
    // 0x126bc34: StoreField: r1->field_7 = r0
    //     0x126bc34: stur            w0, [x1, #7]
    // 0x126bc38: mov             x4, x1
    // 0x126bc3c: ldr             x2, [fp, #0x10]
    // 0x126bc40: b               #0x126bc5c
    // 0x126bc44: r0 = Instance_BorderSide
    //     0x126bc44: add             x0, PP, #0x18, lsl #12  ; [pp+0x18310] Obj!BorderSide@12b1b31
    //     0x126bc48: ldr             x0, [x0, #0x310]
    // 0x126bc4c: ldr             x2, [fp, #0x10]
    // 0x126bc50: LoadField: r1 = r2->field_1b
    //     0x126bc50: ldur            w1, [x2, #0x1b]
    // 0x126bc54: DecompressPointer r1
    //     0x126bc54: add             x1, x1, HEAP, lsl #32
    // 0x126bc58: mov             x4, x1
    // 0x126bc5c: ldur            x3, [fp, #-0x10]
    // 0x126bc60: stur            x4, [fp, #-0x18]
    // 0x126bc64: r17 = 5157
    //     0x126bc64: mov             x17, #0x1425
    // 0x126bc68: cmp             x3, x17
    // 0x126bc6c: b.ne            #0x126bc78
    // 0x126bc70: mov             x2, x0
    // 0x126bc74: b               #0x126bce8
    // 0x126bc78: r17 = 5158
    //     0x126bc78: mov             x17, #0x1426
    // 0x126bc7c: cmp             x3, x17
    // 0x126bc80: b.ne            #0x126bce4
    // 0x126bc84: ldr             x1, [fp, #0x18]
    // 0x126bc88: LoadField: r0 = r1->field_2f
    //     0x126bc88: ldur            w0, [x1, #0x2f]
    // 0x126bc8c: DecompressPointer r0
    //     0x126bc8c: add             x0, x0, HEAP, lsl #32
    // 0x126bc90: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126bc94: cmp             w0, w16
    // 0x126bc98: b.ne            #0x126bca8
    // 0x126bc9c: r2 = direction
    //     0x126bc9c: add             x2, PP, #0x26, lsl #12  ; [pp+0x263b8] Field <_DrawerDefaultsM3@82517151.direction>: late final (offset: 0x30)
    //     0x126bca0: ldr             x2, [x2, #0x3b8]
    // 0x126bca4: r0 = InitLateFinalInstanceField()
    //     0x126bca4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126bca8: mov             x2, x0
    // 0x126bcac: r1 = Instance_BorderRadiusDirectional
    //     0x126bcac: add             x1, PP, #0x26, lsl #12  ; [pp+0x263c0] Obj!BorderRadiusDirectional@129e2d1
    //     0x126bcb0: ldr             x1, [x1, #0x3c0]
    // 0x126bcb4: r0 = resolve()
    //     0x126bcb4: bl              #0x1304c78  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusDirectional::resolve
    // 0x126bcb8: stur            x0, [fp, #-0x20]
    // 0x126bcbc: r0 = RoundedRectangleBorder()
    //     0x126bcbc: bl              #0xd2ea90  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x126bcc0: mov             x1, x0
    // 0x126bcc4: ldur            x0, [fp, #-0x20]
    // 0x126bcc8: StoreField: r1->field_b = r0
    //     0x126bcc8: stur            w0, [x1, #0xb]
    // 0x126bccc: r2 = Instance_BorderSide
    //     0x126bccc: add             x2, PP, #0x18, lsl #12  ; [pp+0x18310] Obj!BorderSide@12b1b31
    //     0x126bcd0: ldr             x2, [x2, #0x310]
    // 0x126bcd4: StoreField: r1->field_7 = r2
    //     0x126bcd4: stur            w2, [x1, #7]
    // 0x126bcd8: mov             x3, x1
    // 0x126bcdc: ldr             x1, [fp, #0x18]
    // 0x126bce0: b               #0x126bcf8
    // 0x126bce4: mov             x2, x0
    // 0x126bce8: ldr             x1, [fp, #0x18]
    // 0x126bcec: LoadField: r0 = r1->field_1b
    //     0x126bcec: ldur            w0, [x1, #0x1b]
    // 0x126bcf0: DecompressPointer r0
    //     0x126bcf0: add             x0, x0, HEAP, lsl #32
    // 0x126bcf4: mov             x3, x0
    // 0x126bcf8: ldur            x0, [fp, #-0x18]
    // 0x126bcfc: r4 = LoadClassIdInstr(r0)
    //     0x126bcfc: ldur            x4, [x0, #-1]
    //     0x126bd00: ubfx            x4, x4, #0xc, #0x14
    // 0x126bd04: stp             x3, x0, [SP]
    // 0x126bd08: mov             x0, x4
    // 0x126bd0c: mov             lr, x0
    // 0x126bd10: ldr             lr, [x21, lr, lsl #3]
    // 0x126bd14: blr             lr
    // 0x126bd18: tbnz            w0, #4, #0x126bed8
    // 0x126bd1c: ldur            x0, [fp, #-8]
    // 0x126bd20: r17 = 5157
    //     0x126bd20: mov             x17, #0x1425
    // 0x126bd24: cmp             x0, x17
    // 0x126bd28: b.ne            #0x126bd38
    // 0x126bd2c: r0 = Instance_BorderSide
    //     0x126bd2c: add             x0, PP, #0x18, lsl #12  ; [pp+0x18310] Obj!BorderSide@12b1b31
    //     0x126bd30: ldr             x0, [x0, #0x310]
    // 0x126bd34: b               #0x126bdac
    // 0x126bd38: r17 = 5158
    //     0x126bd38: mov             x17, #0x1426
    // 0x126bd3c: cmp             x0, x17
    // 0x126bd40: b.ne            #0x126bda4
    // 0x126bd44: ldr             x1, [fp, #0x10]
    // 0x126bd48: LoadField: r0 = r1->field_2f
    //     0x126bd48: ldur            w0, [x1, #0x2f]
    // 0x126bd4c: DecompressPointer r0
    //     0x126bd4c: add             x0, x0, HEAP, lsl #32
    // 0x126bd50: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126bd54: cmp             w0, w16
    // 0x126bd58: b.ne            #0x126bd68
    // 0x126bd5c: r2 = direction
    //     0x126bd5c: add             x2, PP, #0x26, lsl #12  ; [pp+0x263b8] Field <_DrawerDefaultsM3@82517151.direction>: late final (offset: 0x30)
    //     0x126bd60: ldr             x2, [x2, #0x3b8]
    // 0x126bd64: r0 = InitLateFinalInstanceField()
    //     0x126bd64: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126bd68: mov             x2, x0
    // 0x126bd6c: r1 = Instance_BorderRadiusDirectional
    //     0x126bd6c: add             x1, PP, #0x26, lsl #12  ; [pp+0x263c8] Obj!BorderRadiusDirectional@129e2b1
    //     0x126bd70: ldr             x1, [x1, #0x3c8]
    // 0x126bd74: r0 = resolve()
    //     0x126bd74: bl              #0x1304c78  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusDirectional::resolve
    // 0x126bd78: stur            x0, [fp, #-0x18]
    // 0x126bd7c: r0 = RoundedRectangleBorder()
    //     0x126bd7c: bl              #0xd2ea90  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x126bd80: mov             x1, x0
    // 0x126bd84: ldur            x0, [fp, #-0x18]
    // 0x126bd88: StoreField: r1->field_b = r0
    //     0x126bd88: stur            w0, [x1, #0xb]
    // 0x126bd8c: r0 = Instance_BorderSide
    //     0x126bd8c: add             x0, PP, #0x18, lsl #12  ; [pp+0x18310] Obj!BorderSide@12b1b31
    //     0x126bd90: ldr             x0, [x0, #0x310]
    // 0x126bd94: StoreField: r1->field_7 = r0
    //     0x126bd94: stur            w0, [x1, #7]
    // 0x126bd98: mov             x3, x1
    // 0x126bd9c: ldr             x2, [fp, #0x10]
    // 0x126bda0: b               #0x126bdbc
    // 0x126bda4: r0 = Instance_BorderSide
    //     0x126bda4: add             x0, PP, #0x18, lsl #12  ; [pp+0x18310] Obj!BorderSide@12b1b31
    //     0x126bda8: ldr             x0, [x0, #0x310]
    // 0x126bdac: ldr             x2, [fp, #0x10]
    // 0x126bdb0: LoadField: r1 = r2->field_1f
    //     0x126bdb0: ldur            w1, [x2, #0x1f]
    // 0x126bdb4: DecompressPointer r1
    //     0x126bdb4: add             x1, x1, HEAP, lsl #32
    // 0x126bdb8: mov             x3, x1
    // 0x126bdbc: ldur            x1, [fp, #-0x10]
    // 0x126bdc0: stur            x3, [fp, #-0x18]
    // 0x126bdc4: r17 = 5157
    //     0x126bdc4: mov             x17, #0x1425
    // 0x126bdc8: cmp             x1, x17
    // 0x126bdcc: b.eq            #0x126be3c
    // 0x126bdd0: r17 = 5158
    //     0x126bdd0: mov             x17, #0x1426
    // 0x126bdd4: cmp             x1, x17
    // 0x126bdd8: b.ne            #0x126be3c
    // 0x126bddc: ldr             x1, [fp, #0x18]
    // 0x126bde0: LoadField: r0 = r1->field_2f
    //     0x126bde0: ldur            w0, [x1, #0x2f]
    // 0x126bde4: DecompressPointer r0
    //     0x126bde4: add             x0, x0, HEAP, lsl #32
    // 0x126bde8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126bdec: cmp             w0, w16
    // 0x126bdf0: b.ne            #0x126be00
    // 0x126bdf4: r2 = direction
    //     0x126bdf4: add             x2, PP, #0x26, lsl #12  ; [pp+0x263b8] Field <_DrawerDefaultsM3@82517151.direction>: late final (offset: 0x30)
    //     0x126bdf8: ldr             x2, [x2, #0x3b8]
    // 0x126bdfc: r0 = InitLateFinalInstanceField()
    //     0x126bdfc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126be00: mov             x2, x0
    // 0x126be04: r1 = Instance_BorderRadiusDirectional
    //     0x126be04: add             x1, PP, #0x26, lsl #12  ; [pp+0x263c8] Obj!BorderRadiusDirectional@129e2b1
    //     0x126be08: ldr             x1, [x1, #0x3c8]
    // 0x126be0c: r0 = resolve()
    //     0x126be0c: bl              #0x1304c78  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusDirectional::resolve
    // 0x126be10: stur            x0, [fp, #-0x20]
    // 0x126be14: r0 = RoundedRectangleBorder()
    //     0x126be14: bl              #0xd2ea90  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x126be18: mov             x1, x0
    // 0x126be1c: ldur            x0, [fp, #-0x20]
    // 0x126be20: StoreField: r1->field_b = r0
    //     0x126be20: stur            w0, [x1, #0xb]
    // 0x126be24: r0 = Instance_BorderSide
    //     0x126be24: add             x0, PP, #0x18, lsl #12  ; [pp+0x18310] Obj!BorderSide@12b1b31
    //     0x126be28: ldr             x0, [x0, #0x310]
    // 0x126be2c: StoreField: r1->field_7 = r0
    //     0x126be2c: stur            w0, [x1, #7]
    // 0x126be30: mov             x2, x1
    // 0x126be34: ldr             x1, [fp, #0x18]
    // 0x126be38: b               #0x126be4c
    // 0x126be3c: ldr             x1, [fp, #0x18]
    // 0x126be40: LoadField: r0 = r1->field_1f
    //     0x126be40: ldur            w0, [x1, #0x1f]
    // 0x126be44: DecompressPointer r0
    //     0x126be44: add             x0, x0, HEAP, lsl #32
    // 0x126be48: mov             x2, x0
    // 0x126be4c: ldur            x0, [fp, #-0x18]
    // 0x126be50: r3 = LoadClassIdInstr(r0)
    //     0x126be50: ldur            x3, [x0, #-1]
    //     0x126be54: ubfx            x3, x3, #0xc, #0x14
    // 0x126be58: stp             x2, x0, [SP]
    // 0x126be5c: mov             x0, x3
    // 0x126be60: mov             lr, x0
    // 0x126be64: ldr             lr, [x21, lr, lsl #3]
    // 0x126be68: blr             lr
    // 0x126be6c: tbnz            w0, #4, #0x126bed8
    // 0x126be70: ldr             x1, [fp, #0x18]
    // 0x126be74: ldr             x2, [fp, #0x10]
    // 0x126be78: LoadField: r0 = r2->field_23
    //     0x126be78: ldur            w0, [x2, #0x23]
    // 0x126be7c: DecompressPointer r0
    //     0x126be7c: add             x0, x0, HEAP, lsl #32
    // 0x126be80: LoadField: r3 = r1->field_23
    //     0x126be80: ldur            w3, [x1, #0x23]
    // 0x126be84: DecompressPointer r3
    //     0x126be84: add             x3, x3, HEAP, lsl #32
    // 0x126be88: r4 = LoadClassIdInstr(r0)
    //     0x126be88: ldur            x4, [x0, #-1]
    //     0x126be8c: ubfx            x4, x4, #0xc, #0x14
    // 0x126be90: stp             x3, x0, [SP]
    // 0x126be94: mov             x0, x4
    // 0x126be98: mov             lr, x0
    // 0x126be9c: ldr             lr, [x21, lr, lsl #3]
    // 0x126bea0: blr             lr
    // 0x126bea4: tbnz            w0, #4, #0x126bed8
    // 0x126bea8: ldr             x1, [fp, #0x18]
    // 0x126beac: ldr             x2, [fp, #0x10]
    // 0x126beb0: LoadField: r3 = r2->field_27
    //     0x126beb0: ldur            w3, [x2, #0x27]
    // 0x126beb4: DecompressPointer r3
    //     0x126beb4: add             x3, x3, HEAP, lsl #32
    // 0x126beb8: LoadField: r2 = r1->field_27
    //     0x126beb8: ldur            w2, [x1, #0x27]
    // 0x126bebc: DecompressPointer r2
    //     0x126bebc: add             x2, x2, HEAP, lsl #32
    // 0x126bec0: cmp             w3, w2
    // 0x126bec4: r16 = true
    //     0x126bec4: add             x16, NULL, #0x20  ; true
    // 0x126bec8: r17 = false
    //     0x126bec8: add             x17, NULL, #0x30  ; false
    // 0x126becc: csel            x1, x16, x17, eq
    // 0x126bed0: mov             x0, x1
    // 0x126bed4: b               #0x126bedc
    // 0x126bed8: r0 = false
    //     0x126bed8: add             x0, NULL, #0x30  ; false
    // 0x126bedc: LeaveFrame
    //     0x126bedc: mov             SP, fp
    //     0x126bee0: ldp             fp, lr, [SP], #0x10
    // 0x126bee4: ret
    //     0x126bee4: ret             
    // 0x126bee8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x126bee8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x126beec: b               #0x126b8a0
  }
}

// class id: 6848, size: 0x10, field offset: 0x10
//   const constructor, 
abstract class DrawerTheme extends InheritedTheme {

  static _ of(/* No info */) {
    // ** addr: 0xd1a920, size: 0x58
    // 0xd1a920: EnterFrame
    //     0xd1a920: stp             fp, lr, [SP, #-0x10]!
    //     0xd1a924: mov             fp, SP
    // 0xd1a928: AllocStack(0x18)
    //     0xd1a928: sub             SP, SP, #0x18
    // 0xd1a92c: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0xd1a92c: stur            x1, [fp, #-8]
    // 0xd1a930: CheckStackOverflow
    //     0xd1a930: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd1a934: cmp             SP, x16
    //     0xd1a938: b.ls            #0xd1a970
    // 0xd1a93c: r16 = <DrawerTheme>
    //     0xd1a93c: add             x16, PP, #0x99, lsl #12  ; [pp+0x99b10] TypeArguments: <DrawerTheme>
    //     0xd1a940: ldr             x16, [x16, #0xb10]
    // 0xd1a944: stp             x1, x16, [SP]
    // 0xd1a948: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd1a948: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd1a94c: r0 = dependOnInheritedWidgetOfExactType()
    //     0xd1a94c: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xd1a950: ldur            x1, [fp, #-8]
    // 0xd1a954: r0 = of()
    //     0xd1a954: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd1a958: LoadField: r1 = r0->field_cf
    //     0xd1a958: ldur            w1, [x0, #0xcf]
    // 0xd1a95c: DecompressPointer r1
    //     0xd1a95c: add             x1, x1, HEAP, lsl #32
    // 0xd1a960: mov             x0, x1
    // 0xd1a964: LeaveFrame
    //     0xd1a964: mov             SP, fp
    //     0xd1a968: ldp             fp, lr, [SP], #0x10
    // 0xd1a96c: ret
    //     0xd1a96c: ret             
    // 0xd1a970: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1a970: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd1a974: b               #0xd1a93c
  }
}
