// lib: , url: package:flutter/src/material/ink_ripple.dart

// class id: 1048902, size: 0x8
class :: {

  static _ _getTargetRadius(/* No info */) {
    // ** addr: 0xd23b50, size: 0xc8
    // 0xd23b50: EnterFrame
    //     0xd23b50: stp             fp, lr, [SP, #-0x10]!
    //     0xd23b54: mov             fp, SP
    // 0xd23b58: AllocStack(0x18)
    //     0xd23b58: sub             SP, SP, #0x18
    // 0xd23b5c: SetupParameters(dynamic _ /* r2 => r0 */)
    //     0xd23b5c: mov             x0, x2
    // 0xd23b60: CheckStackOverflow
    //     0xd23b60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd23b64: cmp             SP, x16
    //     0xd23b68: b.ls            #0xd23c10
    // 0xd23b6c: cmp             w0, NULL
    // 0xd23b70: b.eq            #0xd23b90
    // 0xd23b74: str             x0, [SP]
    // 0xd23b78: ClosureCall
    //     0xd23b78: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xd23b7c: ldur            x2, [x0, #0x1f]
    //     0xd23b80: blr             x2
    // 0xd23b84: mov             x1, x0
    // 0xd23b88: r0 = size()
    //     0xd23b88: bl              #0x8632d0  ; [dart:ui] Rect::size
    // 0xd23b8c: b               #0xd23b94
    // 0xd23b90: r0 = size()
    //     0xd23b90: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xd23b94: mov             x1, x0
    // 0xd23b98: stur            x0, [fp, #-8]
    // 0xd23b9c: r0 = bottomRight()
    //     0xd23b9c: bl              #0x8587b8  ; [dart:ui] Size::bottomRight
    // 0xd23ba0: LoadField: d0 = r0->field_7
    //     0xd23ba0: ldur            d0, [x0, #7]
    // 0xd23ba4: fmul            d1, d0, d0
    // 0xd23ba8: LoadField: d0 = r0->field_f
    //     0xd23ba8: ldur            d0, [x0, #0xf]
    // 0xd23bac: fmul            d2, d0, d0
    // 0xd23bb0: fadd            d0, d1, d2
    // 0xd23bb4: fsqrt           d1, d0
    // 0xd23bb8: ldur            x1, [fp, #-8]
    // 0xd23bbc: stur            d1, [fp, #-0x10]
    // 0xd23bc0: r0 = topRight()
    //     0xd23bc0: bl              #0xd23c60  ; [dart:ui] Size::topRight
    // 0xd23bc4: ldur            x1, [fp, #-8]
    // 0xd23bc8: stur            x0, [fp, #-8]
    // 0xd23bcc: r0 = bottomLeft()
    //     0xd23bcc: bl              #0xd23c18  ; [dart:ui] Size::bottomLeft
    // 0xd23bd0: ldur            x1, [fp, #-8]
    // 0xd23bd4: mov             x2, x0
    // 0xd23bd8: r0 = -()
    //     0xd23bd8: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0xd23bdc: LoadField: d1 = r0->field_7
    //     0xd23bdc: ldur            d1, [x0, #7]
    // 0xd23be0: fmul            d2, d1, d1
    // 0xd23be4: LoadField: d1 = r0->field_f
    //     0xd23be4: ldur            d1, [x0, #0xf]
    // 0xd23be8: fmul            d3, d1, d1
    // 0xd23bec: fadd            d1, d2, d3
    // 0xd23bf0: fsqrt           d2, d1
    // 0xd23bf4: ldur            d1, [fp, #-0x10]
    // 0xd23bf8: fmax            v3.2d, v1.2d, v2.2d
    // 0xd23bfc: d1 = 2.000000
    //     0xd23bfc: fmov            d1, #2.00000000
    // 0xd23c00: fdiv            d0, d3, d1
    // 0xd23c04: LeaveFrame
    //     0xd23c04: mov             SP, fp
    //     0xd23c08: ldp             fp, lr, [SP], #0x10
    // 0xd23c0c: ret
    //     0xd23c0c: ret             
    // 0xd23c10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd23c10: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd23c14: b               #0xd23b6c
  }
  [closure] static Rect <anonymous closure>(dynamic) {
    // ** addr: 0xd23d6c, size: 0x50
    // 0xd23d6c: EnterFrame
    //     0xd23d6c: stp             fp, lr, [SP, #-0x10]!
    //     0xd23d70: mov             fp, SP
    // 0xd23d74: ldr             x0, [fp, #0x10]
    // 0xd23d78: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd23d78: ldur            w1, [x0, #0x17]
    // 0xd23d7c: DecompressPointer r1
    //     0xd23d7c: add             x1, x1, HEAP, lsl #32
    // 0xd23d80: CheckStackOverflow
    //     0xd23d80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd23d84: cmp             SP, x16
    //     0xd23d88: b.ls            #0xd23db4
    // 0xd23d8c: LoadField: r0 = r1->field_f
    //     0xd23d8c: ldur            w0, [x1, #0xf]
    // 0xd23d90: DecompressPointer r0
    //     0xd23d90: add             x0, x0, HEAP, lsl #32
    // 0xd23d94: mov             x1, x0
    // 0xd23d98: r0 = size()
    //     0xd23d98: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xd23d9c: mov             x2, x0
    // 0xd23da0: r1 = Instance_Offset
    //     0xd23da0: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xd23da4: r0 = &()
    //     0xd23da4: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xd23da8: LeaveFrame
    //     0xd23da8: mov             SP, fp
    //     0xd23dac: ldp             fp, lr, [SP], #0x10
    // 0xd23db0: ret
    //     0xd23db0: ret             
    // 0xd23db4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd23db4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd23db8: b               #0xd23d8c
  }
}

// class id: 3035, size: 0x8, field offset: 0x8
//   const constructor, 
class _InkRippleFactory extends InteractiveInkFeatureFactory {
}

// class id: 3040, size: 0x4c, field offset: 0x1c
class InkRipple extends InteractiveInkFeature {

  late AnimationController _fadeInController; // offset: 0x40
  late AnimationController _fadeOutController; // offset: 0x48
  late AnimationController _radiusController; // offset: 0x38
  static late final Animatable<double> _easeCurveTween; // offset: 0xca4
  static late final Animatable<double> _fadeOutIntervalTween; // offset: 0xca8
  late Animation<int> _fadeIn; // offset: 0x3c
  late Animation<int> _fadeOut; // offset: 0x44
  late Animation<double> _radius; // offset: 0x34

  _ InkRipple(/* No info */) {
    // ** addr: 0xd23574, size: 0x5dc
    // 0xd23574: EnterFrame
    //     0xd23574: stp             fp, lr, [SP, #-0x10]!
    //     0xd23578: mov             fp, SP
    // 0xd2357c: AllocStack(0x60)
    //     0xd2357c: sub             SP, SP, #0x60
    // 0xd23580: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xd23584: mov             x4, x6
    // 0xd23588: stur            x6, [fp, #-0x20]
    // 0xd2358c: mov             x6, x3
    // 0xd23590: stur            x3, [fp, #-0x10]
    // 0xd23594: mov             x3, x7
    // 0xd23598: stur            x7, [fp, #-0x28]
    // 0xd2359c: mov             x7, x1
    // 0xd235a0: stur            x1, [fp, #-8]
    // 0xd235a4: stur            x5, [fp, #-0x18]
    // 0xd235a8: CheckStackOverflow
    //     0xd235a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd235ac: cmp             SP, x16
    //     0xd235b0: b.ls            #0xd23b18
    // 0xd235b4: StoreField: r7->field_33 = r0
    //     0xd235b4: stur            w0, [x7, #0x33]
    // 0xd235b8: StoreField: r7->field_37 = r0
    //     0xd235b8: stur            w0, [x7, #0x37]
    // 0xd235bc: StoreField: r7->field_3b = r0
    //     0xd235bc: stur            w0, [x7, #0x3b]
    // 0xd235c0: StoreField: r7->field_3f = r0
    //     0xd235c0: stur            w0, [x7, #0x3f]
    // 0xd235c4: StoreField: r7->field_43 = r0
    //     0xd235c4: stur            w0, [x7, #0x43]
    // 0xd235c8: StoreField: r7->field_47 = r0
    //     0xd235c8: stur            w0, [x7, #0x47]
    // 0xd235cc: ldr             x0, [fp, #0x30]
    // 0xd235d0: StoreField: r7->field_1b = r0
    //     0xd235d0: stur            w0, [x7, #0x1b]
    //     0xd235d4: ldurb           w16, [x7, #-1]
    //     0xd235d8: ldurb           w17, [x0, #-1]
    //     0xd235dc: and             x16, x17, x16, lsr #2
    //     0xd235e0: tst             x16, HEAP, lsr #32
    //     0xd235e4: b.eq            #0xd235ec
    //     0xd235e8: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xd235ec: cmp             w2, NULL
    // 0xd235f0: b.ne            #0xd23600
    // 0xd235f4: r0 = Instance_BorderRadius
    //     0xd235f4: add             x0, PP, #0x99, lsl #12  ; [pp+0x99508] Obj!BorderRadius@129e311
    //     0xd235f8: ldr             x0, [x0, #0x508]
    // 0xd235fc: b               #0xd23604
    // 0xd23600: mov             x0, x2
    // 0xd23604: ldr             x1, [fp, #0x28]
    // 0xd23608: StoreField: r7->field_1f = r0
    //     0xd23608: stur            w0, [x7, #0x1f]
    //     0xd2360c: ldurb           w16, [x7, #-1]
    //     0xd23610: ldurb           w17, [x0, #-1]
    //     0xd23614: and             x16, x17, x16, lsr #2
    //     0xd23618: tst             x16, HEAP, lsr #32
    //     0xd2361c: b.eq            #0xd23624
    //     0xd23620: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xd23624: ldr             x0, [fp, #0x10]
    // 0xd23628: StoreField: r7->field_2f = r0
    //     0xd23628: stur            w0, [x7, #0x2f]
    //     0xd2362c: ldurb           w16, [x7, #-1]
    //     0xd23630: ldurb           w17, [x0, #-1]
    //     0xd23634: and             x16, x17, x16, lsr #2
    //     0xd23638: tst             x16, HEAP, lsr #32
    //     0xd2363c: b.eq            #0xd23644
    //     0xd23640: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xd23644: cmp             w1, NULL
    // 0xd23648: b.ne            #0xd2365c
    // 0xd2364c: ldr             x1, [fp, #0x18]
    // 0xd23650: ldr             x2, [fp, #0x20]
    // 0xd23654: r0 = _getTargetRadius()
    //     0xd23654: bl              #0xd23b50  ; [package:flutter/src/material/ink_ripple.dart] ::_getTargetRadius
    // 0xd23658: b               #0xd23660
    // 0xd2365c: LoadField: d0 = r1->field_7
    //     0xd2365c: ldur            d0, [x1, #7]
    // 0xd23660: ldur            x2, [fp, #-8]
    // 0xd23664: ldr             x1, [fp, #0x20]
    // 0xd23668: ldr             x0, [fp, #0x18]
    // 0xd2366c: stur            d0, [fp, #-0x50]
    // 0xd23670: StoreField: r2->field_23 = d0
    //     0xd23670: stur            d0, [x2, #0x23]
    // 0xd23674: r1 = 1
    //     0xd23674: mov             x1, #1
    // 0xd23678: r0 = AllocateContext()
    //     0xd23678: bl              #0x13de838  ; AllocateContextStub
    // 0xd2367c: mov             x1, x0
    // 0xd23680: ldr             x0, [fp, #0x18]
    // 0xd23684: StoreField: r1->field_f = r0
    //     0xd23684: stur            w0, [x1, #0xf]
    // 0xd23688: ldr             x2, [fp, #0x20]
    // 0xd2368c: cmp             w2, NULL
    // 0xd23690: b.eq            #0xd2369c
    // 0xd23694: mov             x0, x2
    // 0xd23698: b               #0xd236bc
    // 0xd2369c: ldur            x2, [fp, #-0x18]
    // 0xd236a0: tbnz            w2, #4, #0xd236b8
    // 0xd236a4: mov             x2, x1
    // 0xd236a8: r1 = Function '<anonymous closure>': static.
    //     0xd236a8: add             x1, PP, #0x99, lsl #12  ; [pp+0x995a0] AnonymousClosure: static (0xd23d6c), of [package:flutter/src/material/ink_ripple.dart] 
    //     0xd236ac: ldr             x1, [x1, #0x5a0]
    // 0xd236b0: r0 = AllocateClosure()
    //     0xd236b0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd236b4: b               #0xd236bc
    // 0xd236b8: r0 = Null
    //     0xd236b8: mov             x0, NULL
    // 0xd236bc: ldur            x2, [fp, #-8]
    // 0xd236c0: ldur            x4, [fp, #-0x10]
    // 0xd236c4: ldur            x3, [fp, #-0x20]
    // 0xd236c8: ldur            d0, [fp, #-0x50]
    // 0xd236cc: StoreField: r2->field_2b = r0
    //     0xd236cc: stur            w0, [x2, #0x2b]
    //     0xd236d0: tbz             w0, #0, #0xd236ec
    //     0xd236d4: ldurb           w16, [x2, #-1]
    //     0xd236d8: ldurb           w17, [x0, #-1]
    //     0xd236dc: and             x16, x17, x16, lsr #2
    //     0xd236e0: tst             x16, HEAP, lsr #32
    //     0xd236e4: b.eq            #0xd236ec
    //     0xd236e8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd236ec: mov             x0, x4
    // 0xd236f0: StoreField: r2->field_13 = r0
    //     0xd236f0: stur            w0, [x2, #0x13]
    //     0xd236f4: ldurb           w16, [x2, #-1]
    //     0xd236f8: ldurb           w17, [x0, #-1]
    //     0xd236fc: and             x16, x17, x16, lsr #2
    //     0xd23700: tst             x16, HEAP, lsr #32
    //     0xd23704: b.eq            #0xd2370c
    //     0xd23708: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd2370c: ldur            x0, [fp, #-0x28]
    // 0xd23710: ArrayStore: r2[0] = r0  ; List_4
    //     0xd23710: stur            w0, [x2, #0x17]
    //     0xd23714: ldurb           w16, [x2, #-1]
    //     0xd23718: ldurb           w17, [x0, #-1]
    //     0xd2371c: and             x16, x17, x16, lsr #2
    //     0xd23720: tst             x16, HEAP, lsr #32
    //     0xd23724: b.eq            #0xd2372c
    //     0xd23728: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd2372c: ldr             x0, [fp, #0x18]
    // 0xd23730: StoreField: r2->field_b = r0
    //     0xd23730: stur            w0, [x2, #0xb]
    //     0xd23734: ldurb           w16, [x2, #-1]
    //     0xd23738: ldurb           w17, [x0, #-1]
    //     0xd2373c: and             x16, x17, x16, lsr #2
    //     0xd23740: tst             x16, HEAP, lsr #32
    //     0xd23744: b.eq            #0xd2374c
    //     0xd23748: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd2374c: ldr             x0, [fp, #0x38]
    // 0xd23750: StoreField: r2->field_f = r0
    //     0xd23750: stur            w0, [x2, #0xf]
    //     0xd23754: ldurb           w16, [x2, #-1]
    //     0xd23758: ldurb           w17, [x0, #-1]
    //     0xd2375c: and             x16, x17, x16, lsr #2
    //     0xd23760: tst             x16, HEAP, lsr #32
    //     0xd23764: b.eq            #0xd2376c
    //     0xd23768: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd2376c: mov             x0, x3
    // 0xd23770: StoreField: r2->field_7 = r0
    //     0xd23770: stur            w0, [x2, #7]
    //     0xd23774: ldurb           w16, [x2, #-1]
    //     0xd23778: ldurb           w17, [x0, #-1]
    //     0xd2377c: and             x16, x17, x16, lsr #2
    //     0xd23780: tst             x16, HEAP, lsr #32
    //     0xd23784: b.eq            #0xd2378c
    //     0xd23788: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd2378c: LoadField: r0 = r3->field_53
    //     0xd2378c: ldur            w0, [x3, #0x53]
    // 0xd23790: DecompressPointer r0
    //     0xd23790: add             x0, x0, HEAP, lsl #32
    // 0xd23794: stur            x0, [fp, #-0x18]
    // 0xd23798: r1 = <double>
    //     0xd23798: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd2379c: r0 = AnimationController()
    //     0xd2379c: bl              #0x87522c  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0xd237a0: stur            x0, [fp, #-0x28]
    // 0xd237a4: r16 = Instance_Duration
    //     0xd237a4: add             x16, PP, #0x84, lsl #12  ; [pp+0x84f20] Obj!Duration@12c8a11
    //     0xd237a8: ldr             x16, [x16, #0xf20]
    // 0xd237ac: str             x16, [SP]
    // 0xd237b0: mov             x1, x0
    // 0xd237b4: ldur            x2, [fp, #-0x18]
    // 0xd237b8: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0xd237b8: add             x4, PP, #0x15, lsl #12  ; [pp+0x155a0] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0xd237bc: ldr             x4, [x4, #0x5a0]
    // 0xd237c0: r0 = AnimationController()
    //     0xd237c0: bl              #0x874ea4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0xd237c4: ldur            x2, [fp, #-0x20]
    // 0xd237c8: r1 = Function 'markNeedsPaint':.
    //     0xd237c8: add             x1, PP, #0x90, lsl #12  ; [pp+0x901f0] AnonymousClosure: (0xbf0a50), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0xbf0858)
    //     0xd237cc: ldr             x1, [x1, #0x1f0]
    // 0xd237d0: r0 = AllocateClosure()
    //     0xd237d0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd237d4: ldur            x1, [fp, #-0x28]
    // 0xd237d8: mov             x2, x0
    // 0xd237dc: stur            x0, [fp, #-0x30]
    // 0xd237e0: r0 = addListener()
    //     0xd237e0: bl              #0xd0440c  ; [dart:mixin_deduplication] _MixinApplication455&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::addListener
    // 0xd237e4: ldur            x1, [fp, #-0x28]
    // 0xd237e8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd237e8: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd237ec: r0 = forward()
    //     0xd237ec: bl              #0x8cd83c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0xd237f0: ldur            x0, [fp, #-0x28]
    // 0xd237f4: ldur            x2, [fp, #-8]
    // 0xd237f8: StoreField: r2->field_3f = r0
    //     0xd237f8: stur            w0, [x2, #0x3f]
    //     0xd237fc: ldurb           w16, [x2, #-1]
    //     0xd23800: ldurb           w17, [x0, #-1]
    //     0xd23804: and             x16, x17, x16, lsr #2
    //     0xd23808: tst             x16, HEAP, lsr #32
    //     0xd2380c: b.eq            #0xd23814
    //     0xd23810: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd23814: ldur            x3, [fp, #-0x10]
    // 0xd23818: r0 = LoadClassIdInstr(r3)
    //     0xd23818: ldur            x0, [x3, #-1]
    //     0xd2381c: ubfx            x0, x0, #0xc, #0x14
    // 0xd23820: mov             x1, x3
    // 0xd23824: r0 = GDT[cid_x0 + -0xfc0]()
    //     0xd23824: sub             lr, x0, #0xfc0
    //     0xd23828: ldr             lr, [x21, lr, lsl #3]
    //     0xd2382c: blr             lr
    // 0xd23830: r1 = <int>
    //     0xd23830: ldr             x1, [PP, #0x50]  ; [pp+0x50] TypeArguments: <int>
    // 0xd23834: stur            x0, [fp, #-0x38]
    // 0xd23838: r0 = IntTween()
    //     0xd23838: bl              #0xd21d54  ; AllocateIntTweenStub -> IntTween (size=0x14)
    // 0xd2383c: mov             x2, x0
    // 0xd23840: StoreField: r2->field_b = rZR
    //     0xd23840: stur            wzr, [x2, #0xb]
    // 0xd23844: ldur            x3, [fp, #-0x38]
    // 0xd23848: r0 = BoxInt64Instr(r3)
    //     0xd23848: sbfiz           x0, x3, #1, #0x1f
    //     0xd2384c: cmp             x3, x0, asr #1
    //     0xd23850: b.eq            #0xd2385c
    //     0xd23854: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xd23858: stur            x3, [x0, #7]
    // 0xd2385c: StoreField: r2->field_f = r0
    //     0xd2385c: stur            w0, [x2, #0xf]
    // 0xd23860: mov             x1, x2
    // 0xd23864: ldur            x2, [fp, #-0x28]
    // 0xd23868: r0 = animate()
    //     0xd23868: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xd2386c: ldur            x2, [fp, #-8]
    // 0xd23870: StoreField: r2->field_3b = r0
    //     0xd23870: stur            w0, [x2, #0x3b]
    //     0xd23874: ldurb           w16, [x2, #-1]
    //     0xd23878: ldurb           w17, [x0, #-1]
    //     0xd2387c: and             x16, x17, x16, lsr #2
    //     0xd23880: tst             x16, HEAP, lsr #32
    //     0xd23884: b.eq            #0xd2388c
    //     0xd23888: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd2388c: r1 = <double>
    //     0xd2388c: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd23890: r0 = AnimationController()
    //     0xd23890: bl              #0x87522c  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0xd23894: stur            x0, [fp, #-0x28]
    // 0xd23898: r16 = Instance_Duration
    //     0xd23898: ldr             x16, [PP, #0xa80]  ; [pp+0xa80] Obj!Duration@12c8921
    // 0xd2389c: str             x16, [SP]
    // 0xd238a0: mov             x1, x0
    // 0xd238a4: ldur            x2, [fp, #-0x18]
    // 0xd238a8: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0xd238a8: add             x4, PP, #0x15, lsl #12  ; [pp+0x155a0] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0xd238ac: ldr             x4, [x4, #0x5a0]
    // 0xd238b0: r0 = AnimationController()
    //     0xd238b0: bl              #0x874ea4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0xd238b4: ldur            x1, [fp, #-0x28]
    // 0xd238b8: ldur            x2, [fp, #-0x30]
    // 0xd238bc: r0 = addListener()
    //     0xd238bc: bl              #0xd0440c  ; [dart:mixin_deduplication] _MixinApplication455&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::addListener
    // 0xd238c0: ldur            x1, [fp, #-0x28]
    // 0xd238c4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd238c4: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd238c8: r0 = forward()
    //     0xd238c8: bl              #0x8cd83c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0xd238cc: ldur            x0, [fp, #-0x28]
    // 0xd238d0: ldur            x2, [fp, #-8]
    // 0xd238d4: StoreField: r2->field_37 = r0
    //     0xd238d4: stur            w0, [x2, #0x37]
    //     0xd238d8: ldurb           w16, [x2, #-1]
    //     0xd238dc: ldurb           w17, [x0, #-1]
    //     0xd238e0: and             x16, x17, x16, lsr #2
    //     0xd238e4: tst             x16, HEAP, lsr #32
    //     0xd238e8: b.eq            #0xd238f0
    //     0xd238ec: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd238f0: ldur            d0, [fp, #-0x50]
    // 0xd238f4: d1 = 0.300000
    //     0xd238f4: add             x17, PP, #0x13, lsl #12  ; [pp+0x13a88] IMM: double(0.3) from 0x3fd3333333333333
    //     0xd238f8: ldr             d1, [x17, #0xa88]
    // 0xd238fc: fmul            d2, d0, d1
    // 0xd23900: d1 = 5.000000
    //     0xd23900: fmov            d1, #5.00000000
    // 0xd23904: fadd            d3, d0, d1
    // 0xd23908: stur            d3, [fp, #-0x58]
    // 0xd2390c: r0 = inline_Allocate_Double()
    //     0xd2390c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xd23910: add             x0, x0, #0x10
    //     0xd23914: cmp             x1, x0
    //     0xd23918: b.ls            #0xd23b20
    //     0xd2391c: str             x0, [THR, #0x60]  ; THR::top
    //     0xd23920: sub             x0, x0, #0xf
    //     0xd23924: mov             x1, #0xe19c
    //     0xd23928: movk            x1, #3, lsl #16
    //     0xd2392c: stur            x1, [x0, #-1]
    // 0xd23930: dmb             ishst
    // 0xd23934: StoreField: r0->field_7 = d2
    //     0xd23934: stur            d2, [x0, #7]
    // 0xd23938: stur            x0, [fp, #-0x40]
    // 0xd2393c: r1 = <double>
    //     0xd2393c: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd23940: r0 = Tween()
    //     0xd23940: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xd23944: mov             x1, x0
    // 0xd23948: ldur            x0, [fp, #-0x40]
    // 0xd2394c: stur            x1, [fp, #-0x48]
    // 0xd23950: StoreField: r1->field_b = r0
    //     0xd23950: stur            w0, [x1, #0xb]
    // 0xd23954: ldur            d0, [fp, #-0x58]
    // 0xd23958: r0 = inline_Allocate_Double()
    //     0xd23958: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xd2395c: add             x0, x0, #0x10
    //     0xd23960: cmp             x2, x0
    //     0xd23964: b.ls            #0xd23b38
    //     0xd23968: str             x0, [THR, #0x60]  ; THR::top
    //     0xd2396c: sub             x0, x0, #0xf
    //     0xd23970: mov             x2, #0xe19c
    //     0xd23974: movk            x2, #3, lsl #16
    //     0xd23978: stur            x2, [x0, #-1]
    // 0xd2397c: dmb             ishst
    // 0xd23980: StoreField: r0->field_7 = d0
    //     0xd23980: stur            d0, [x0, #7]
    // 0xd23984: StoreField: r1->field_f = r0
    //     0xd23984: stur            w0, [x1, #0xf]
    // 0xd23988: r0 = LoadStaticField(0xca4)
    //     0xd23988: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xd2398c: ldr             x0, [x0, #0x1948]
    // 0xd23990: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd23994: cmp             w0, w16
    // 0xd23998: b.ne            #0xd239a8
    // 0xd2399c: r2 = _easeCurveTween
    //     0xd2399c: add             x2, PP, #0x99, lsl #12  ; [pp+0x995a8] Field <InkRipple._easeCurveTween@755110234>: static late final (offset: 0xca4)
    //     0xd239a0: ldr             x2, [x2, #0x5a8]
    // 0xd239a4: r0 = InitLateFinalStaticField()
    //     0xd239a4: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xd239a8: ldur            x1, [fp, #-0x48]
    // 0xd239ac: mov             x2, x0
    // 0xd239b0: r0 = chain()
    //     0xd239b0: bl              #0xb28080  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0xd239b4: mov             x1, x0
    // 0xd239b8: ldur            x2, [fp, #-0x28]
    // 0xd239bc: r0 = animate()
    //     0xd239bc: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xd239c0: ldur            x2, [fp, #-8]
    // 0xd239c4: StoreField: r2->field_33 = r0
    //     0xd239c4: stur            w0, [x2, #0x33]
    //     0xd239c8: ldurb           w16, [x2, #-1]
    //     0xd239cc: ldurb           w17, [x0, #-1]
    //     0xd239d0: and             x16, x17, x16, lsr #2
    //     0xd239d4: tst             x16, HEAP, lsr #32
    //     0xd239d8: b.eq            #0xd239e0
    //     0xd239dc: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd239e0: r1 = <double>
    //     0xd239e0: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd239e4: r0 = AnimationController()
    //     0xd239e4: bl              #0x87522c  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0xd239e8: stur            x0, [fp, #-0x28]
    // 0xd239ec: r16 = Instance_Duration
    //     0xd239ec: add             x16, PP, #0x99, lsl #12  ; [pp+0x99540] Obj!Duration@12c8a81
    //     0xd239f0: ldr             x16, [x16, #0x540]
    // 0xd239f4: str             x16, [SP]
    // 0xd239f8: mov             x1, x0
    // 0xd239fc: ldur            x2, [fp, #-0x18]
    // 0xd23a00: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0xd23a00: add             x4, PP, #0x15, lsl #12  ; [pp+0x155a0] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0xd23a04: ldr             x4, [x4, #0x5a0]
    // 0xd23a08: r0 = AnimationController()
    //     0xd23a08: bl              #0x874ea4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0xd23a0c: ldur            x1, [fp, #-0x28]
    // 0xd23a10: ldur            x2, [fp, #-0x30]
    // 0xd23a14: r0 = addListener()
    //     0xd23a14: bl              #0xd0440c  ; [dart:mixin_deduplication] _MixinApplication455&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::addListener
    // 0xd23a18: ldur            x2, [fp, #-8]
    // 0xd23a1c: r1 = Function '_handleAlphaStatusChanged@755110234':.
    //     0xd23a1c: add             x1, PP, #0x99, lsl #12  ; [pp+0x995b0] AnonymousClosure: (0xd23cd0), in [package:flutter/src/material/ink_ripple.dart] InkRipple::_handleAlphaStatusChanged (0xd23d0c)
    //     0xd23a20: ldr             x1, [x1, #0x5b0]
    // 0xd23a24: r0 = AllocateClosure()
    //     0xd23a24: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd23a28: ldur            x1, [fp, #-0x28]
    // 0xd23a2c: mov             x2, x0
    // 0xd23a30: r0 = addStatusListener()
    //     0xd23a30: bl              #0x1254cc0  ; [dart:mixin_deduplication] _MixinApplication456&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::addStatusListener
    // 0xd23a34: ldur            x0, [fp, #-0x28]
    // 0xd23a38: ldur            x2, [fp, #-8]
    // 0xd23a3c: StoreField: r2->field_47 = r0
    //     0xd23a3c: stur            w0, [x2, #0x47]
    //     0xd23a40: ldurb           w16, [x2, #-1]
    //     0xd23a44: ldurb           w17, [x0, #-1]
    //     0xd23a48: and             x16, x17, x16, lsr #2
    //     0xd23a4c: tst             x16, HEAP, lsr #32
    //     0xd23a50: b.eq            #0xd23a58
    //     0xd23a54: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd23a58: ldur            x1, [fp, #-0x10]
    // 0xd23a5c: r0 = LoadClassIdInstr(r1)
    //     0xd23a5c: ldur            x0, [x1, #-1]
    //     0xd23a60: ubfx            x0, x0, #0xc, #0x14
    // 0xd23a64: r0 = GDT[cid_x0 + -0xfc0]()
    //     0xd23a64: sub             lr, x0, #0xfc0
    //     0xd23a68: ldr             lr, [x21, lr, lsl #3]
    //     0xd23a6c: blr             lr
    // 0xd23a70: mov             x2, x0
    // 0xd23a74: r0 = BoxInt64Instr(r2)
    //     0xd23a74: sbfiz           x0, x2, #1, #0x1f
    //     0xd23a78: cmp             x2, x0, asr #1
    //     0xd23a7c: b.eq            #0xd23a88
    //     0xd23a80: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xd23a84: stur            x2, [x0, #7]
    // 0xd23a88: r1 = <int>
    //     0xd23a88: ldr             x1, [PP, #0x50]  ; [pp+0x50] TypeArguments: <int>
    // 0xd23a8c: stur            x0, [fp, #-0x10]
    // 0xd23a90: r0 = IntTween()
    //     0xd23a90: bl              #0xd21d54  ; AllocateIntTweenStub -> IntTween (size=0x14)
    // 0xd23a94: mov             x1, x0
    // 0xd23a98: ldur            x0, [fp, #-0x10]
    // 0xd23a9c: stur            x1, [fp, #-0x18]
    // 0xd23aa0: StoreField: r1->field_b = r0
    //     0xd23aa0: stur            w0, [x1, #0xb]
    // 0xd23aa4: StoreField: r1->field_f = rZR
    //     0xd23aa4: stur            wzr, [x1, #0xf]
    // 0xd23aa8: r0 = LoadStaticField(0xca8)
    //     0xd23aa8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xd23aac: ldr             x0, [x0, #0x1950]
    // 0xd23ab0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd23ab4: cmp             w0, w16
    // 0xd23ab8: b.ne            #0xd23ac8
    // 0xd23abc: r2 = _fadeOutIntervalTween
    //     0xd23abc: add             x2, PP, #0x99, lsl #12  ; [pp+0x995b8] Field <InkRipple._fadeOutIntervalTween@755110234>: static late final (offset: 0xca8)
    //     0xd23ac0: ldr             x2, [x2, #0x5b8]
    // 0xd23ac4: r0 = InitLateFinalStaticField()
    //     0xd23ac4: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xd23ac8: ldur            x1, [fp, #-0x18]
    // 0xd23acc: mov             x2, x0
    // 0xd23ad0: r0 = chain()
    //     0xd23ad0: bl              #0xb28080  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0xd23ad4: mov             x1, x0
    // 0xd23ad8: ldur            x2, [fp, #-0x28]
    // 0xd23adc: r0 = animate()
    //     0xd23adc: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xd23ae0: ldur            x2, [fp, #-8]
    // 0xd23ae4: StoreField: r2->field_43 = r0
    //     0xd23ae4: stur            w0, [x2, #0x43]
    //     0xd23ae8: ldurb           w16, [x2, #-1]
    //     0xd23aec: ldurb           w17, [x0, #-1]
    //     0xd23af0: and             x16, x17, x16, lsr #2
    //     0xd23af4: tst             x16, HEAP, lsr #32
    //     0xd23af8: b.eq            #0xd23b00
    //     0xd23afc: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd23b00: ldur            x1, [fp, #-0x20]
    // 0xd23b04: r0 = addInkFeature()
    //     0xd23b04: bl              #0xd21c40  ; [package:flutter/src/material/material.dart] _RenderInkFeatures::addInkFeature
    // 0xd23b08: r0 = Null
    //     0xd23b08: mov             x0, NULL
    // 0xd23b0c: LeaveFrame
    //     0xd23b0c: mov             SP, fp
    //     0xd23b10: ldp             fp, lr, [SP], #0x10
    // 0xd23b14: ret
    //     0xd23b14: ret             
    // 0xd23b18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd23b18: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd23b1c: b               #0xd235b4
    // 0xd23b20: stp             q2, q3, [SP, #-0x20]!
    // 0xd23b24: SaveReg r2
    //     0xd23b24: str             x2, [SP, #-8]!
    // 0xd23b28: r0 = AllocateDouble()
    //     0xd23b28: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd23b2c: RestoreReg r2
    //     0xd23b2c: ldr             x2, [SP], #8
    // 0xd23b30: ldp             q2, q3, [SP], #0x20
    // 0xd23b34: b               #0xd23934
    // 0xd23b38: SaveReg d0
    //     0xd23b38: str             q0, [SP, #-0x10]!
    // 0xd23b3c: SaveReg r1
    //     0xd23b3c: str             x1, [SP, #-8]!
    // 0xd23b40: r0 = AllocateDouble()
    //     0xd23b40: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd23b44: RestoreReg r1
    //     0xd23b44: ldr             x1, [SP], #8
    // 0xd23b48: RestoreReg d0
    //     0xd23b48: ldr             q0, [SP], #0x10
    // 0xd23b4c: b               #0xd23980
  }
  static Animatable<double> _fadeOutIntervalTween() {
    // ** addr: 0xd23ca8, size: 0x28
    // 0xd23ca8: EnterFrame
    //     0xd23ca8: stp             fp, lr, [SP, #-0x10]!
    //     0xd23cac: mov             fp, SP
    // 0xd23cb0: r1 = <double>
    //     0xd23cb0: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd23cb4: r0 = CurveTween()
    //     0xd23cb4: bl              #0xb280f4  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0xd23cb8: r1 = Instance_Interval
    //     0xd23cb8: add             x1, PP, #0x99, lsl #12  ; [pp+0x995c0] Obj!Interval@129f9f1
    //     0xd23cbc: ldr             x1, [x1, #0x5c0]
    // 0xd23cc0: StoreField: r0->field_b = r1
    //     0xd23cc0: stur            w1, [x0, #0xb]
    // 0xd23cc4: LeaveFrame
    //     0xd23cc4: mov             SP, fp
    //     0xd23cc8: ldp             fp, lr, [SP], #0x10
    // 0xd23ccc: ret
    //     0xd23ccc: ret             
  }
  [closure] void _handleAlphaStatusChanged(dynamic, AnimationStatus) {
    // ** addr: 0xd23cd0, size: 0x3c
    // 0xd23cd0: EnterFrame
    //     0xd23cd0: stp             fp, lr, [SP, #-0x10]!
    //     0xd23cd4: mov             fp, SP
    // 0xd23cd8: ldr             x0, [fp, #0x18]
    // 0xd23cdc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd23cdc: ldur            w1, [x0, #0x17]
    // 0xd23ce0: DecompressPointer r1
    //     0xd23ce0: add             x1, x1, HEAP, lsl #32
    // 0xd23ce4: CheckStackOverflow
    //     0xd23ce4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd23ce8: cmp             SP, x16
    //     0xd23cec: b.ls            #0xd23d04
    // 0xd23cf0: ldr             x2, [fp, #0x10]
    // 0xd23cf4: r0 = _handleAlphaStatusChanged()
    //     0xd23cf4: bl              #0xd23d0c  ; [package:flutter/src/material/ink_ripple.dart] InkRipple::_handleAlphaStatusChanged
    // 0xd23cf8: LeaveFrame
    //     0xd23cf8: mov             SP, fp
    //     0xd23cfc: ldp             fp, lr, [SP], #0x10
    // 0xd23d00: ret
    //     0xd23d00: ret             
    // 0xd23d04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd23d04: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd23d08: b               #0xd23cf0
  }
  _ _handleAlphaStatusChanged(/* No info */) {
    // ** addr: 0xd23d0c, size: 0x3c
    // 0xd23d0c: EnterFrame
    //     0xd23d0c: stp             fp, lr, [SP, #-0x10]!
    //     0xd23d10: mov             fp, SP
    // 0xd23d14: CheckStackOverflow
    //     0xd23d14: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd23d18: cmp             SP, x16
    //     0xd23d1c: b.ls            #0xd23d40
    // 0xd23d20: r16 = Instance_AnimationStatus
    //     0xd23d20: ldr             x16, [PP, #0x51a0]  ; [pp+0x51a0] Obj!AnimationStatus@12c61a1
    // 0xd23d24: cmp             w2, w16
    // 0xd23d28: b.ne            #0xd23d30
    // 0xd23d2c: r0 = dispose()
    //     0xd23d2c: bl              #0x119e7c8  ; [package:flutter/src/material/ink_ripple.dart] InkRipple::dispose
    // 0xd23d30: r0 = Null
    //     0xd23d30: mov             x0, NULL
    // 0xd23d34: LeaveFrame
    //     0xd23d34: mov             SP, fp
    //     0xd23d38: ldp             fp, lr, [SP], #0x10
    // 0xd23d3c: ret
    //     0xd23d3c: ret             
    // 0xd23d40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd23d40: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd23d44: b               #0xd23d20
  }
  static Animatable<double> _easeCurveTween() {
    // ** addr: 0xd23d48, size: 0x24
    // 0xd23d48: EnterFrame
    //     0xd23d48: stp             fp, lr, [SP, #-0x10]!
    //     0xd23d4c: mov             fp, SP
    // 0xd23d50: r1 = <double>
    //     0xd23d50: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd23d54: r0 = CurveTween()
    //     0xd23d54: bl              #0xb280f4  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0xd23d58: r1 = Instance_Cubic
    //     0xd23d58: ldr             x1, [PP, #0x53e8]  ; [pp+0x53e8] Obj!Cubic@129f421
    // 0xd23d5c: StoreField: r0->field_b = r1
    //     0xd23d5c: stur            w1, [x0, #0xb]
    // 0xd23d60: LeaveFrame
    //     0xd23d60: mov             SP, fp
    //     0xd23d64: ldp             fp, lr, [SP], #0x10
    // 0xd23d68: ret
    //     0xd23d68: ret             
  }
  _ dispose(/* No info */) {
    // ** addr: 0x119e7c8, size: 0xb4
    // 0x119e7c8: EnterFrame
    //     0x119e7c8: stp             fp, lr, [SP, #-0x10]!
    //     0x119e7cc: mov             fp, SP
    // 0x119e7d0: AllocStack(0x8)
    //     0x119e7d0: sub             SP, SP, #8
    // 0x119e7d4: SetupParameters(InkRipple this /* r1 => r0, fp-0x8 */)
    //     0x119e7d4: mov             x0, x1
    //     0x119e7d8: stur            x1, [fp, #-8]
    // 0x119e7dc: CheckStackOverflow
    //     0x119e7dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x119e7e0: cmp             SP, x16
    //     0x119e7e4: b.ls            #0x119e850
    // 0x119e7e8: LoadField: r1 = r0->field_37
    //     0x119e7e8: ldur            w1, [x0, #0x37]
    // 0x119e7ec: DecompressPointer r1
    //     0x119e7ec: add             x1, x1, HEAP, lsl #32
    // 0x119e7f0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x119e7f4: cmp             w1, w16
    // 0x119e7f8: b.eq            #0x119e858
    // 0x119e7fc: r0 = dispose()
    //     0x119e7fc: bl              #0x9164f4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x119e800: ldur            x0, [fp, #-8]
    // 0x119e804: LoadField: r1 = r0->field_3f
    //     0x119e804: ldur            w1, [x0, #0x3f]
    // 0x119e808: DecompressPointer r1
    //     0x119e808: add             x1, x1, HEAP, lsl #32
    // 0x119e80c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x119e810: cmp             w1, w16
    // 0x119e814: b.eq            #0x119e864
    // 0x119e818: r0 = dispose()
    //     0x119e818: bl              #0x9164f4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x119e81c: ldur            x0, [fp, #-8]
    // 0x119e820: LoadField: r1 = r0->field_47
    //     0x119e820: ldur            w1, [x0, #0x47]
    // 0x119e824: DecompressPointer r1
    //     0x119e824: add             x1, x1, HEAP, lsl #32
    // 0x119e828: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x119e82c: cmp             w1, w16
    // 0x119e830: b.eq            #0x119e870
    // 0x119e834: r0 = dispose()
    //     0x119e834: bl              #0x9164f4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x119e838: ldur            x1, [fp, #-8]
    // 0x119e83c: r0 = dispose()
    //     0x119e83c: bl              #0xf786a8  ; [package:flutter/src/material/material.dart] InkFeature::dispose
    // 0x119e840: r0 = Null
    //     0x119e840: mov             x0, NULL
    // 0x119e844: LeaveFrame
    //     0x119e844: mov             SP, fp
    //     0x119e848: ldp             fp, lr, [SP], #0x10
    // 0x119e84c: ret
    //     0x119e84c: ret             
    // 0x119e850: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x119e850: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x119e854: b               #0x119e7e8
    // 0x119e858: r9 = _radiusController
    //     0x119e858: add             x9, PP, #0x99, lsl #12  ; [pp+0x99550] Field <InkRipple._radiusController@755110234>: late (offset: 0x38)
    //     0x119e85c: ldr             x9, [x9, #0x550]
    // 0x119e860: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x119e860: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x119e864: r9 = _fadeInController
    //     0x119e864: add             x9, PP, #0x99, lsl #12  ; [pp+0x99528] Field <InkRipple._fadeInController@755110234>: late (offset: 0x40)
    //     0x119e868: ldr             x9, [x9, #0x528]
    // 0x119e86c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x119e86c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x119e870: r9 = _fadeOutController
    //     0x119e870: add             x9, PP, #0x99, lsl #12  ; [pp+0x99530] Field <InkRipple._fadeOutController@755110234>: late (offset: 0x48)
    //     0x119e874: ldr             x9, [x9, #0x530]
    // 0x119e878: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x119e878: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ paintFeature(/* No info */) {
    // ** addr: 0x12da8bc, size: 0x348
    // 0x12da8bc: EnterFrame
    //     0x12da8bc: stp             fp, lr, [SP, #-0x10]!
    //     0x12da8c0: mov             fp, SP
    // 0x12da8c4: AllocStack(0x58)
    //     0x12da8c4: sub             SP, SP, #0x58
    // 0x12da8c8: SetupParameters(InkRipple this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x12da8c8: mov             x5, x1
    //     0x12da8cc: mov             x4, x2
    //     0x12da8d0: stur            x1, [fp, #-8]
    //     0x12da8d4: stur            x2, [fp, #-0x10]
    //     0x12da8d8: stur            x3, [fp, #-0x18]
    // 0x12da8dc: CheckStackOverflow
    //     0x12da8dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12da8e0: cmp             SP, x16
    //     0x12da8e4: b.ls            #0x12daba4
    // 0x12da8e8: LoadField: r0 = r5->field_3f
    //     0x12da8e8: ldur            w0, [x5, #0x3f]
    // 0x12da8ec: DecompressPointer r0
    //     0x12da8ec: add             x0, x0, HEAP, lsl #32
    // 0x12da8f0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12da8f4: cmp             w0, w16
    // 0x12da8f8: b.eq            #0x12dabac
    // 0x12da8fc: LoadField: r1 = r0->field_2f
    //     0x12da8fc: ldur            w1, [x0, #0x2f]
    // 0x12da900: DecompressPointer r1
    //     0x12da900: add             x1, x1, HEAP, lsl #32
    // 0x12da904: cmp             w1, NULL
    // 0x12da908: b.eq            #0x12da96c
    // 0x12da90c: LoadField: r0 = r1->field_7
    //     0x12da90c: ldur            w0, [x1, #7]
    // 0x12da910: DecompressPointer r0
    //     0x12da910: add             x0, x0, HEAP, lsl #32
    // 0x12da914: cmp             w0, NULL
    // 0x12da918: b.eq            #0x12da96c
    // 0x12da91c: LoadField: r0 = r5->field_3b
    //     0x12da91c: ldur            w0, [x5, #0x3b]
    // 0x12da920: DecompressPointer r0
    //     0x12da920: add             x0, x0, HEAP, lsl #32
    // 0x12da924: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12da928: cmp             w0, w16
    // 0x12da92c: b.eq            #0x12dabb8
    // 0x12da930: LoadField: r1 = r0->field_f
    //     0x12da930: ldur            w1, [x0, #0xf]
    // 0x12da934: DecompressPointer r1
    //     0x12da934: add             x1, x1, HEAP, lsl #32
    // 0x12da938: LoadField: r2 = r0->field_b
    //     0x12da938: ldur            w2, [x0, #0xb]
    // 0x12da93c: DecompressPointer r2
    //     0x12da93c: add             x2, x2, HEAP, lsl #32
    // 0x12da940: r0 = LoadClassIdInstr(r1)
    //     0x12da940: ldur            x0, [x1, #-1]
    //     0x12da944: ubfx            x0, x0, #0xc, #0x14
    // 0x12da948: r0 = GDT[cid_x0 + 0x80ed]()
    //     0x12da948: mov             x17, #0x80ed
    //     0x12da94c: add             lr, x0, x17
    //     0x12da950: ldr             lr, [x21, lr, lsl #3]
    //     0x12da954: blr             lr
    // 0x12da958: r1 = LoadInt32Instr(r0)
    //     0x12da958: sbfx            x1, x0, #1, #0x1f
    //     0x12da95c: tbz             w0, #0, #0x12da964
    //     0x12da960: ldur            x1, [x0, #7]
    // 0x12da964: mov             x2, x1
    // 0x12da968: b               #0x12da9bc
    // 0x12da96c: ldur            x3, [fp, #-8]
    // 0x12da970: LoadField: r0 = r3->field_43
    //     0x12da970: ldur            w0, [x3, #0x43]
    // 0x12da974: DecompressPointer r0
    //     0x12da974: add             x0, x0, HEAP, lsl #32
    // 0x12da978: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12da97c: cmp             w0, w16
    // 0x12da980: b.eq            #0x12dabc4
    // 0x12da984: LoadField: r1 = r0->field_f
    //     0x12da984: ldur            w1, [x0, #0xf]
    // 0x12da988: DecompressPointer r1
    //     0x12da988: add             x1, x1, HEAP, lsl #32
    // 0x12da98c: LoadField: r2 = r0->field_b
    //     0x12da98c: ldur            w2, [x0, #0xb]
    // 0x12da990: DecompressPointer r2
    //     0x12da990: add             x2, x2, HEAP, lsl #32
    // 0x12da994: r0 = LoadClassIdInstr(r1)
    //     0x12da994: ldur            x0, [x1, #-1]
    //     0x12da998: ubfx            x0, x0, #0xc, #0x14
    // 0x12da99c: r0 = GDT[cid_x0 + 0x80ed]()
    //     0x12da99c: mov             x17, #0x80ed
    //     0x12da9a0: add             lr, x0, x17
    //     0x12da9a4: ldr             lr, [x21, lr, lsl #3]
    //     0x12da9a8: blr             lr
    // 0x12da9ac: r1 = LoadInt32Instr(r0)
    //     0x12da9ac: sbfx            x1, x0, #1, #0x1f
    //     0x12da9b0: tbz             w0, #0, #0x12da9b8
    //     0x12da9b4: ldur            x1, [x0, #7]
    // 0x12da9b8: mov             x2, x1
    // 0x12da9bc: ldur            x1, [fp, #-8]
    // 0x12da9c0: stur            x2, [fp, #-0x20]
    // 0x12da9c4: r16 = 136
    //     0x12da9c4: mov             x16, #0x88
    // 0x12da9c8: stp             x16, NULL, [SP]
    // 0x12da9cc: r0 = ByteData()
    //     0x12da9cc: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0x12da9d0: stur            x0, [fp, #-0x28]
    // 0x12da9d4: r0 = Paint()
    //     0x12da9d4: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x12da9d8: mov             x3, x0
    // 0x12da9dc: ldur            x0, [fp, #-0x28]
    // 0x12da9e0: stur            x3, [fp, #-0x30]
    // 0x12da9e4: StoreField: r3->field_7 = r0
    //     0x12da9e4: stur            w0, [x3, #7]
    // 0x12da9e8: ldur            x4, [fp, #-8]
    // 0x12da9ec: LoadField: r1 = r4->field_13
    //     0x12da9ec: ldur            w1, [x4, #0x13]
    // 0x12da9f0: DecompressPointer r1
    //     0x12da9f0: add             x1, x1, HEAP, lsl #32
    // 0x12da9f4: r0 = LoadClassIdInstr(r1)
    //     0x12da9f4: ldur            x0, [x1, #-1]
    //     0x12da9f8: ubfx            x0, x0, #0xc, #0x14
    // 0x12da9fc: ldur            x2, [fp, #-0x20]
    // 0x12daa00: r0 = GDT[cid_x0 + -0xff4]()
    //     0x12daa00: sub             lr, x0, #0xff4
    //     0x12daa04: ldr             lr, [x21, lr, lsl #3]
    //     0x12daa08: blr             lr
    // 0x12daa0c: ldur            x1, [fp, #-0x30]
    // 0x12daa10: mov             x2, x0
    // 0x12daa14: r0 = color=()
    //     0x12daa14: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0x12daa18: ldur            x1, [fp, #-8]
    // 0x12daa1c: LoadField: r2 = r1->field_2b
    //     0x12daa1c: ldur            w2, [x1, #0x2b]
    // 0x12daa20: DecompressPointer r2
    //     0x12daa20: add             x2, x2, HEAP, lsl #32
    // 0x12daa24: stur            x2, [fp, #-0x28]
    // 0x12daa28: cmp             w2, NULL
    // 0x12daa2c: b.ne            #0x12daa3c
    // 0x12daa30: mov             x0, x1
    // 0x12daa34: r1 = Null
    //     0x12daa34: mov             x1, NULL
    // 0x12daa38: b               #0x12daa58
    // 0x12daa3c: str             x2, [SP]
    // 0x12daa40: mov             x0, x2
    // 0x12daa44: ClosureCall
    //     0x12daa44: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x12daa48: ldur            x2, [x0, #0x1f]
    //     0x12daa4c: blr             x2
    // 0x12daa50: mov             x1, x0
    // 0x12daa54: ldur            x0, [fp, #-8]
    // 0x12daa58: LoadField: r2 = r0->field_1b
    //     0x12daa58: ldur            w2, [x0, #0x1b]
    // 0x12daa5c: DecompressPointer r2
    //     0x12daa5c: add             x2, x2, HEAP, lsl #32
    // 0x12daa60: stur            x2, [fp, #-0x38]
    // 0x12daa64: cmp             w1, NULL
    // 0x12daa68: b.eq            #0x12daa78
    // 0x12daa6c: r0 = center()
    //     0x12daa6c: bl              #0x869350  ; [dart:ui] Rect::center
    // 0x12daa70: mov             x2, x0
    // 0x12daa74: b               #0x12daa90
    // 0x12daa78: LoadField: r1 = r0->field_b
    //     0x12daa78: ldur            w1, [x0, #0xb]
    // 0x12daa7c: DecompressPointer r1
    //     0x12daa7c: add             x1, x1, HEAP, lsl #32
    // 0x12daa80: r0 = size()
    //     0x12daa80: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0x12daa84: mov             x1, x0
    // 0x12daa88: r0 = center()
    //     0x12daa88: bl              #0xaf9a1c  ; [dart:ui] Size::center
    // 0x12daa8c: mov             x2, x0
    // 0x12daa90: ldur            x0, [fp, #-8]
    // 0x12daa94: stur            x2, [fp, #-0x40]
    // 0x12daa98: LoadField: r1 = r0->field_37
    //     0x12daa98: ldur            w1, [x0, #0x37]
    // 0x12daa9c: DecompressPointer r1
    //     0x12daa9c: add             x1, x1, HEAP, lsl #32
    // 0x12daaa0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12daaa4: cmp             w1, w16
    // 0x12daaa8: b.eq            #0x12dabd0
    // 0x12daaac: LoadField: r3 = r1->field_37
    //     0x12daaac: ldur            w3, [x1, #0x37]
    // 0x12daab0: DecompressPointer r3
    //     0x12daab0: add             x3, x3, HEAP, lsl #32
    // 0x12daab4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12daab8: cmp             w3, w16
    // 0x12daabc: b.eq            #0x12dabdc
    // 0x12daac0: LoadField: d0 = r3->field_7
    //     0x12daac0: ldur            d0, [x3, #7]
    // 0x12daac4: r1 = Instance_Cubic
    //     0x12daac4: ldr             x1, [PP, #0x53e8]  ; [pp+0x53e8] Obj!Cubic@129f421
    // 0x12daac8: r0 = transform()
    //     0x12daac8: bl              #0x12f4dac  ; [package:flutter/src/animation/curves.dart] Curve::transform
    // 0x12daacc: r3 = inline_Allocate_Double()
    //     0x12daacc: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0x12daad0: add             x3, x3, #0x10
    //     0x12daad4: cmp             x0, x3
    //     0x12daad8: b.ls            #0x12dabe4
    //     0x12daadc: str             x3, [THR, #0x60]  ; THR::top
    //     0x12daae0: sub             x3, x3, #0xf
    //     0x12daae4: mov             x0, #0xe19c
    //     0x12daae8: movk            x0, #3, lsl #16
    //     0x12daaec: stur            x0, [x3, #-1]
    // 0x12daaf0: dmb             ishst
    // 0x12daaf4: StoreField: r3->field_7 = d0
    //     0x12daaf4: stur            d0, [x3, #7]
    // 0x12daaf8: ldur            x1, [fp, #-0x38]
    // 0x12daafc: ldur            x2, [fp, #-0x40]
    // 0x12dab00: r0 = lerp()
    //     0x12dab00: bl              #0xb6bc84  ; [dart:ui] Offset::lerp
    // 0x12dab04: mov             x4, x0
    // 0x12dab08: ldur            x3, [fp, #-8]
    // 0x12dab0c: stur            x4, [fp, #-0x40]
    // 0x12dab10: LoadField: r5 = r3->field_2f
    //     0x12dab10: ldur            w5, [x3, #0x2f]
    // 0x12dab14: DecompressPointer r5
    //     0x12dab14: add             x5, x5, HEAP, lsl #32
    // 0x12dab18: stur            x5, [fp, #-0x38]
    // 0x12dab1c: LoadField: r0 = r3->field_33
    //     0x12dab1c: ldur            w0, [x3, #0x33]
    // 0x12dab20: DecompressPointer r0
    //     0x12dab20: add             x0, x0, HEAP, lsl #32
    // 0x12dab24: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12dab28: cmp             w0, w16
    // 0x12dab2c: b.eq            #0x12dabf8
    // 0x12dab30: LoadField: r1 = r0->field_f
    //     0x12dab30: ldur            w1, [x0, #0xf]
    // 0x12dab34: DecompressPointer r1
    //     0x12dab34: add             x1, x1, HEAP, lsl #32
    // 0x12dab38: LoadField: r2 = r0->field_b
    //     0x12dab38: ldur            w2, [x0, #0xb]
    // 0x12dab3c: DecompressPointer r2
    //     0x12dab3c: add             x2, x2, HEAP, lsl #32
    // 0x12dab40: r0 = LoadClassIdInstr(r1)
    //     0x12dab40: ldur            x0, [x1, #-1]
    //     0x12dab44: ubfx            x0, x0, #0xc, #0x14
    // 0x12dab48: r0 = GDT[cid_x0 + 0x80ed]()
    //     0x12dab48: mov             x17, #0x80ed
    //     0x12dab4c: add             lr, x0, x17
    //     0x12dab50: ldr             lr, [x21, lr, lsl #3]
    //     0x12dab54: blr             lr
    // 0x12dab58: ldur            x1, [fp, #-8]
    // 0x12dab5c: ArrayLoad: r7 = r1[0]  ; List_4
    //     0x12dab5c: ldur            w7, [x1, #0x17]
    // 0x12dab60: DecompressPointer r7
    //     0x12dab60: add             x7, x7, HEAP, lsl #32
    // 0x12dab64: LoadField: r2 = r1->field_1f
    //     0x12dab64: ldur            w2, [x1, #0x1f]
    // 0x12dab68: DecompressPointer r2
    //     0x12dab68: add             x2, x2, HEAP, lsl #32
    // 0x12dab6c: LoadField: d0 = r0->field_7
    //     0x12dab6c: ldur            d0, [x0, #7]
    // 0x12dab70: ldur            x16, [fp, #-0x30]
    // 0x12dab74: ldur            lr, [fp, #-0x38]
    // 0x12dab78: stp             lr, x16, [SP, #8]
    // 0x12dab7c: ldur            x16, [fp, #-0x18]
    // 0x12dab80: str             x16, [SP]
    // 0x12dab84: ldur            x3, [fp, #-0x10]
    // 0x12dab88: ldur            x5, [fp, #-0x40]
    // 0x12dab8c: ldur            x6, [fp, #-0x28]
    // 0x12dab90: r0 = paintInkCircle()
    //     0x12dab90: bl              #0x12dac04  ; [package:flutter/src/material/ink_well.dart] InteractiveInkFeature::paintInkCircle
    // 0x12dab94: r0 = Null
    //     0x12dab94: mov             x0, NULL
    // 0x12dab98: LeaveFrame
    //     0x12dab98: mov             SP, fp
    //     0x12dab9c: ldp             fp, lr, [SP], #0x10
    // 0x12daba0: ret
    //     0x12daba0: ret             
    // 0x12daba4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12daba4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12daba8: b               #0x12da8e8
    // 0x12dabac: r9 = _fadeInController
    //     0x12dabac: add             x9, PP, #0x99, lsl #12  ; [pp+0x99528] Field <InkRipple._fadeInController@755110234>: late (offset: 0x40)
    //     0x12dabb0: ldr             x9, [x9, #0x528]
    // 0x12dabb4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12dabb4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12dabb8: r9 = _fadeIn
    //     0x12dabb8: add             x9, PP, #0xab, lsl #12  ; [pp+0xab168] Field <InkRipple._fadeIn@755110234>: late (offset: 0x3c)
    //     0x12dabbc: ldr             x9, [x9, #0x168]
    // 0x12dabc0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12dabc0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12dabc4: r9 = _fadeOut
    //     0x12dabc4: add             x9, PP, #0xab, lsl #12  ; [pp+0xab170] Field <InkRipple._fadeOut@755110234>: late (offset: 0x44)
    //     0x12dabc8: ldr             x9, [x9, #0x170]
    // 0x12dabcc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12dabcc: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12dabd0: r9 = _radiusController
    //     0x12dabd0: add             x9, PP, #0x99, lsl #12  ; [pp+0x99550] Field <InkRipple._radiusController@755110234>: late (offset: 0x38)
    //     0x12dabd4: ldr             x9, [x9, #0x550]
    // 0x12dabd8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12dabd8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12dabdc: r9 = _value
    //     0x12dabdc: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0x12dabe0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12dabe0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12dabe4: SaveReg d0
    //     0x12dabe4: str             q0, [SP, #-0x10]!
    // 0x12dabe8: r0 = AllocateDouble()
    //     0x12dabe8: bl              #0x13df878  ; AllocateDoubleStub
    // 0x12dabec: mov             x3, x0
    // 0x12dabf0: RestoreReg d0
    //     0x12dabf0: ldr             q0, [SP], #0x10
    // 0x12dabf4: b               #0x12daaf4
    // 0x12dabf8: r9 = _radius
    //     0x12dabf8: add             x9, PP, #0xab, lsl #12  ; [pp+0xab178] Field <InkRipple._radius@755110234>: late (offset: 0x34)
    //     0x12dabfc: ldr             x9, [x9, #0x178]
    // 0x12dac00: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12dac00: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}
