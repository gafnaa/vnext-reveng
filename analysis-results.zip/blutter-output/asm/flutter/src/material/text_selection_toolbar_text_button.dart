// lib: , url: package:flutter/src/material/text_selection_toolbar_text_button.dart

// class id: 1048966, size: 0x8
class :: {
}

// class id: 6136, size: 0x1c, field offset: 0xc
//   const constructor, 
class TextSelectionToolbarTextButton extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfbed28, size: 0xf0
    // 0xfbed28: EnterFrame
    //     0xfbed28: stp             fp, lr, [SP, #-0x10]!
    //     0xfbed2c: mov             fp, SP
    // 0xfbed30: AllocStack(0x58)
    //     0xfbed30: sub             SP, SP, #0x58
    // 0xfbed34: SetupParameters(TextSelectionToolbarTextButton this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1 */)
    //     0xfbed34: mov             x0, x1
    //     0xfbed38: stur            x1, [fp, #-8]
    //     0xfbed3c: mov             x1, x2
    // 0xfbed40: CheckStackOverflow
    //     0xfbed40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbed44: cmp             SP, x16
    //     0xfbed48: b.ls            #0xfbee10
    // 0xfbed4c: r0 = of()
    //     0xfbed4c: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfbed50: LoadField: r1 = r0->field_3f
    //     0xfbed50: ldur            w1, [x0, #0x3f]
    // 0xfbed54: DecompressPointer r1
    //     0xfbed54: add             x1, x1, HEAP, lsl #32
    // 0xfbed58: r0 = _getForegroundColor()
    //     0xfbed58: bl              #0xfbee18  ; [package:flutter/src/material/text_selection_toolbar_text_button.dart] TextSelectionToolbarTextButton::_getForegroundColor
    // 0xfbed5c: mov             x1, x0
    // 0xfbed60: ldur            x0, [fp, #-8]
    // 0xfbed64: LoadField: r2 = r0->field_13
    //     0xfbed64: ldur            w2, [x0, #0x13]
    // 0xfbed68: DecompressPointer r2
    //     0xfbed68: add             x2, x2, HEAP, lsl #32
    // 0xfbed6c: ArrayLoad: r3 = r0[0]  ; List_4
    //     0xfbed6c: ldur            w3, [x0, #0x17]
    // 0xfbed70: DecompressPointer r3
    //     0xfbed70: add             x3, x3, HEAP, lsl #32
    // 0xfbed74: r16 = Instance_Color
    //     0xfbed74: add             x16, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xfbed78: ldr             x16, [x16, #0x810]
    // 0xfbed7c: stp             x1, x16, [SP, #0x28]
    // 0xfbed80: r16 = Instance_RoundedRectangleBorder
    //     0xfbed80: add             x16, PP, #0x26, lsl #12  ; [pp+0x26600] Obj!RoundedRectangleBorder@129ec31
    //     0xfbed84: ldr             x16, [x16, #0x600]
    // 0xfbed88: r30 = Instance_Size
    //     0xfbed88: add             lr, PP, #0x8c, lsl #12  ; [pp+0x8c588] Obj!Size@12a75d1
    //     0xfbed8c: ldr             lr, [lr, #0x588]
    // 0xfbed90: stp             lr, x16, [SP, #0x18]
    // 0xfbed94: stp             x3, x2, [SP, #8]
    // 0xfbed98: r16 = Instance_TextStyle
    //     0xfbed98: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8c590] Obj!TextStyle@12b1031
    //     0xfbed9c: ldr             x16, [x16, #0x590]
    // 0xfbeda0: str             x16, [SP]
    // 0xfbeda4: r4 = const [0, 0x7, 0x7, 0, alignment, 0x5, backgroundColor, 0, foregroundColor, 0x1, minimumSize, 0x3, padding, 0x4, shape, 0x2, textStyle, 0x6, null]
    //     0xfbeda4: add             x4, PP, #0x8c, lsl #12  ; [pp+0x8c598] List(19) [0, 0x7, 0x7, 0, "alignment", 0x5, "backgroundColor", 0, "foregroundColor", 0x1, "minimumSize", 0x3, "padding", 0x4, "shape", 0x2, "textStyle", 0x6, Null]
    //     0xfbeda8: ldr             x4, [x4, #0x598]
    // 0xfbedac: r0 = styleFrom()
    //     0xfbedac: bl              #0xd16538  ; [package:flutter/src/material/text_button.dart] TextButton::styleFrom
    // 0xfbedb0: mov             x1, x0
    // 0xfbedb4: ldur            x0, [fp, #-8]
    // 0xfbedb8: stur            x1, [fp, #-0x20]
    // 0xfbedbc: LoadField: r2 = r0->field_f
    //     0xfbedbc: ldur            w2, [x0, #0xf]
    // 0xfbedc0: DecompressPointer r2
    //     0xfbedc0: add             x2, x2, HEAP, lsl #32
    // 0xfbedc4: stur            x2, [fp, #-0x18]
    // 0xfbedc8: LoadField: r3 = r0->field_b
    //     0xfbedc8: ldur            w3, [x0, #0xb]
    // 0xfbedcc: DecompressPointer r3
    //     0xfbedcc: add             x3, x3, HEAP, lsl #32
    // 0xfbedd0: stur            x3, [fp, #-0x10]
    // 0xfbedd4: r0 = TextButton()
    //     0xfbedd4: bl              #0xd1652c  ; AllocateTextButtonStub -> TextButton (size=0x40)
    // 0xfbedd8: r1 = false
    //     0xfbedd8: add             x1, NULL, #0x30  ; false
    // 0xfbeddc: StoreField: r0->field_3b = r1
    //     0xfbeddc: stur            w1, [x0, #0x3b]
    // 0xfbede0: ldur            x2, [fp, #-0x18]
    // 0xfbede4: StoreField: r0->field_b = r2
    //     0xfbede4: stur            w2, [x0, #0xb]
    // 0xfbede8: ldur            x2, [fp, #-0x20]
    // 0xfbedec: StoreField: r0->field_1b = r2
    //     0xfbedec: stur            w2, [x0, #0x1b]
    // 0xfbedf0: StoreField: r0->field_27 = r1
    //     0xfbedf0: stur            w1, [x0, #0x27]
    // 0xfbedf4: r1 = true
    //     0xfbedf4: add             x1, NULL, #0x20  ; true
    // 0xfbedf8: StoreField: r0->field_2f = r1
    //     0xfbedf8: stur            w1, [x0, #0x2f]
    // 0xfbedfc: ldur            x1, [fp, #-0x10]
    // 0xfbee00: StoreField: r0->field_37 = r1
    //     0xfbee00: stur            w1, [x0, #0x37]
    // 0xfbee04: LeaveFrame
    //     0xfbee04: mov             SP, fp
    //     0xfbee08: ldp             fp, lr, [SP], #0x10
    // 0xfbee0c: ret
    //     0xfbee0c: ret             
    // 0xfbee10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbee10: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbee14: b               #0xfbed4c
  }
  static _ _getForegroundColor(/* No info */) {
    // ** addr: 0xfbee18, size: 0xe4
    // 0xfbee18: EnterFrame
    //     0xfbee18: stp             fp, lr, [SP, #-0x10]!
    //     0xfbee1c: mov             fp, SP
    // 0xfbee20: AllocStack(0x10)
    //     0xfbee20: sub             SP, SP, #0x10
    // 0xfbee24: SetupParameters(dynamic _ /* r1 => r0, fp-0x10 */)
    //     0xfbee24: mov             x0, x1
    //     0xfbee28: stur            x1, [fp, #-0x10]
    // 0xfbee2c: CheckStackOverflow
    //     0xfbee2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbee30: cmp             SP, x16
    //     0xfbee34: b.ls            #0xfbeef4
    // 0xfbee38: LoadField: r1 = r0->field_7
    //     0xfbee38: ldur            w1, [x0, #7]
    // 0xfbee3c: DecompressPointer r1
    //     0xfbee3c: add             x1, x1, HEAP, lsl #32
    // 0xfbee40: LoadField: r2 = r1->field_7
    //     0xfbee40: ldur            x2, [x1, #7]
    // 0xfbee44: stur            x2, [fp, #-8]
    // 0xfbee48: cmp             x2, #0
    // 0xfbee4c: b.gt            #0xfbee84
    // 0xfbee50: r1 = Null
    //     0xfbee50: mov             x1, NULL
    // 0xfbee54: r0 = ThemeData.dark()
    //     0xfbee54: bl              #0xfbec20  ; [package:flutter/src/material/theme_data.dart] ThemeData::ThemeData.dark
    // 0xfbee58: LoadField: r1 = r0->field_3f
    //     0xfbee58: ldur            w1, [x0, #0x3f]
    // 0xfbee5c: DecompressPointer r1
    //     0xfbee5c: add             x1, x1, HEAP, lsl #32
    // 0xfbee60: LoadField: r0 = r1->field_7f
    //     0xfbee60: ldur            w0, [x1, #0x7f]
    // 0xfbee64: DecompressPointer r0
    //     0xfbee64: add             x0, x0, HEAP, lsl #32
    // 0xfbee68: ldur            x2, [fp, #-0x10]
    // 0xfbee6c: LoadField: r1 = r2->field_7f
    //     0xfbee6c: ldur            w1, [x2, #0x7f]
    // 0xfbee70: DecompressPointer r1
    //     0xfbee70: add             x1, x1, HEAP, lsl #32
    // 0xfbee74: cmp             w0, w1
    // 0xfbee78: b.eq            #0xfbeec8
    // 0xfbee7c: mov             x0, x1
    // 0xfbee80: b               #0xfbeebc
    // 0xfbee84: mov             x2, x0
    // 0xfbee88: r1 = Null
    //     0xfbee88: mov             x1, NULL
    // 0xfbee8c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xfbee8c: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xfbee90: r0 = ThemeData()
    //     0xfbee90: bl              #0x8a9c18  ; [package:flutter/src/material/theme_data.dart] ThemeData::ThemeData
    // 0xfbee94: LoadField: r1 = r0->field_3f
    //     0xfbee94: ldur            w1, [x0, #0x3f]
    // 0xfbee98: DecompressPointer r1
    //     0xfbee98: add             x1, x1, HEAP, lsl #32
    // 0xfbee9c: LoadField: r2 = r1->field_7f
    //     0xfbee9c: ldur            w2, [x1, #0x7f]
    // 0xfbeea0: DecompressPointer r2
    //     0xfbeea0: add             x2, x2, HEAP, lsl #32
    // 0xfbeea4: ldur            x1, [fp, #-0x10]
    // 0xfbeea8: LoadField: r3 = r1->field_7f
    //     0xfbeea8: ldur            w3, [x1, #0x7f]
    // 0xfbeeac: DecompressPointer r3
    //     0xfbeeac: add             x3, x3, HEAP, lsl #32
    // 0xfbeeb0: cmp             w2, w3
    // 0xfbeeb4: b.eq            #0xfbeec8
    // 0xfbeeb8: mov             x0, x3
    // 0xfbeebc: LeaveFrame
    //     0xfbeebc: mov             SP, fp
    //     0xfbeec0: ldp             fp, lr, [SP], #0x10
    // 0xfbeec4: ret
    //     0xfbeec4: ret             
    // 0xfbeec8: ldur            x1, [fp, #-8]
    // 0xfbeecc: cmp             x1, #0
    // 0xfbeed0: b.gt            #0xfbeee0
    // 0xfbeed4: r0 = Instance_Color
    //     0xfbeed4: add             x0, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0xfbeed8: ldr             x0, [x0, #0xc38]
    // 0xfbeedc: b               #0xfbeee8
    // 0xfbeee0: r0 = Instance_Color
    //     0xfbeee0: add             x0, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0xfbeee4: ldr             x0, [x0, #0x948]
    // 0xfbeee8: LeaveFrame
    //     0xfbeee8: mov             SP, fp
    //     0xfbeeec: ldp             fp, lr, [SP], #0x10
    // 0xfbeef0: ret
    //     0xfbeef0: ret             
    // 0xfbeef4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbeef4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbeef8: b               #0xfbee38
  }
}

// class id: 8256, size: 0x14, field offset: 0x14
enum _TextSelectionToolbarItemPosition extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11aab20, size: 0x64
    // 0x11aab20: EnterFrame
    //     0x11aab20: stp             fp, lr, [SP, #-0x10]!
    //     0x11aab24: mov             fp, SP
    // 0x11aab28: AllocStack(0x10)
    //     0x11aab28: sub             SP, SP, #0x10
    // 0x11aab2c: SetupParameters(_TextSelectionToolbarItemPosition this /* r1 => r0, fp-0x8 */)
    //     0x11aab2c: mov             x0, x1
    //     0x11aab30: stur            x1, [fp, #-8]
    // 0x11aab34: CheckStackOverflow
    //     0x11aab34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11aab38: cmp             SP, x16
    //     0x11aab3c: b.ls            #0x11aab7c
    // 0x11aab40: r1 = Null
    //     0x11aab40: mov             x1, NULL
    // 0x11aab44: r2 = 4
    //     0x11aab44: mov             x2, #4
    // 0x11aab48: r0 = AllocateArray()
    //     0x11aab48: bl              #0x13df928  ; AllocateArrayStub
    // 0x11aab4c: r16 = "_TextSelectionToolbarItemPosition."
    //     0x11aab4c: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8c5a0] "_TextSelectionToolbarItemPosition."
    //     0x11aab50: ldr             x16, [x16, #0x5a0]
    // 0x11aab54: StoreField: r0->field_f = r16
    //     0x11aab54: stur            w16, [x0, #0xf]
    // 0x11aab58: ldur            x1, [fp, #-8]
    // 0x11aab5c: LoadField: r2 = r1->field_f
    //     0x11aab5c: ldur            w2, [x1, #0xf]
    // 0x11aab60: DecompressPointer r2
    //     0x11aab60: add             x2, x2, HEAP, lsl #32
    // 0x11aab64: StoreField: r0->field_13 = r2
    //     0x11aab64: stur            w2, [x0, #0x13]
    // 0x11aab68: str             x0, [SP]
    // 0x11aab6c: r0 = _interpolate()
    //     0x11aab6c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11aab70: LeaveFrame
    //     0x11aab70: mov             SP, fp
    //     0x11aab74: ldp             fp, lr, [SP], #0x10
    // 0x11aab78: ret
    //     0x11aab78: ret             
    // 0x11aab7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11aab7c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11aab80: b               #0x11aab40
  }
}
