// lib: , url: package:flutter/src/material/date_picker_theme.dart

// class id: 1048876, size: 0x8
class :: {
}

// class id: 5167, size: 0xac, field offset: 0x8
//   const constructor, 
class DatePickerThemeData extends _MixinApplication3&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0x1130a1c, size: 0x1a34
    // 0x1130a1c: EnterFrame
    //     0x1130a1c: stp             fp, lr, [SP, #-0x10]!
    //     0x1130a20: mov             fp, SP
    // 0x1130a24: AllocStack(0x28)
    //     0x1130a24: sub             SP, SP, #0x28
    // 0x1130a28: CheckStackOverflow
    //     0x1130a28: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1130a2c: cmp             SP, x16
    //     0x1130a30: b.ls            #0x1132448
    // 0x1130a34: ldr             x0, [fp, #0x10]
    // 0x1130a38: r2 = LoadClassIdInstr(r0)
    //     0x1130a38: ldur            x2, [x0, #-1]
    //     0x1130a3c: ubfx            x2, x2, #0xc, #0x14
    // 0x1130a40: stur            x2, [fp, #-8]
    // 0x1130a44: r17 = 5167
    //     0x1130a44: mov             x17, #0x142f
    // 0x1130a48: cmp             x2, x17
    // 0x1130a4c: b.eq            #0x1130ab4
    // 0x1130a50: r17 = 5168
    //     0x1130a50: mov             x17, #0x1430
    // 0x1130a54: cmp             x2, x17
    // 0x1130a58: b.ne            #0x1130ab0
    // 0x1130a5c: mov             x1, x0
    // 0x1130a60: LoadField: r0 = r1->field_b3
    //     0x1130a60: ldur            w0, [x1, #0xb3]
    // 0x1130a64: DecompressPointer r0
    //     0x1130a64: add             x0, x0, HEAP, lsl #32
    // 0x1130a68: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1130a6c: cmp             w0, w16
    // 0x1130a70: b.ne            #0x1130a80
    // 0x1130a74: r2 = _colors
    //     0x1130a74: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x1130a78: ldr             x2, [x2, #0x400]
    // 0x1130a7c: r0 = InitLateFinalInstanceField()
    //     0x1130a7c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1130a80: LoadField: r1 = r0->field_9b
    //     0x1130a80: ldur            w1, [x0, #0x9b]
    // 0x1130a84: DecompressPointer r1
    //     0x1130a84: add             x1, x1, HEAP, lsl #32
    // 0x1130a88: cmp             w1, NULL
    // 0x1130a8c: b.ne            #0x1130aa0
    // 0x1130a90: LoadField: r1 = r0->field_7b
    //     0x1130a90: ldur            w1, [x0, #0x7b]
    // 0x1130a94: DecompressPointer r1
    //     0x1130a94: add             x1, x1, HEAP, lsl #32
    // 0x1130a98: mov             x0, x1
    // 0x1130a9c: b               #0x1130aa4
    // 0x1130aa0: mov             x0, x1
    // 0x1130aa4: mov             x4, x0
    // 0x1130aa8: ldr             x0, [fp, #0x10]
    // 0x1130aac: b               #0x1130ac0
    // 0x1130ab0: ldr             x0, [fp, #0x10]
    // 0x1130ab4: LoadField: r1 = r0->field_7
    //     0x1130ab4: ldur            w1, [x0, #7]
    // 0x1130ab8: DecompressPointer r1
    //     0x1130ab8: add             x1, x1, HEAP, lsl #32
    // 0x1130abc: mov             x4, x1
    // 0x1130ac0: ldur            x3, [fp, #-8]
    // 0x1130ac4: stur            x4, [fp, #-0x10]
    // 0x1130ac8: r1 = <Object?>
    //     0x1130ac8: ldr             x1, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0x1130acc: r2 = 82
    //     0x1130acc: mov             x2, #0x52
    // 0x1130ad0: r0 = AllocateArray()
    //     0x1130ad0: bl              #0x13df928  ; AllocateArrayStub
    // 0x1130ad4: mov             x2, x0
    // 0x1130ad8: ldur            x0, [fp, #-0x10]
    // 0x1130adc: stur            x2, [fp, #-0x18]
    // 0x1130ae0: StoreField: r2->field_f = r0
    //     0x1130ae0: stur            w0, [x2, #0xf]
    // 0x1130ae4: ldr             x0, [fp, #0x10]
    // 0x1130ae8: LoadField: r1 = r0->field_b
    //     0x1130ae8: ldur            w1, [x0, #0xb]
    // 0x1130aec: DecompressPointer r1
    //     0x1130aec: add             x1, x1, HEAP, lsl #32
    // 0x1130af0: StoreField: r2->field_13 = r1
    //     0x1130af0: stur            w1, [x2, #0x13]
    // 0x1130af4: ldur            x3, [fp, #-8]
    // 0x1130af8: r17 = 5167
    //     0x1130af8: mov             x17, #0x142f
    // 0x1130afc: cmp             x3, x17
    // 0x1130b00: b.eq            #0x1130b1c
    // 0x1130b04: r17 = 5168
    //     0x1130b04: mov             x17, #0x1430
    // 0x1130b08: cmp             x3, x17
    // 0x1130b0c: b.ne            #0x1130b1c
    // 0x1130b10: r1 = Instance_Color
    //     0x1130b10: add             x1, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x1130b14: ldr             x1, [x1, #0x810]
    // 0x1130b18: b               #0x1130b24
    // 0x1130b1c: LoadField: r1 = r0->field_f
    //     0x1130b1c: ldur            w1, [x0, #0xf]
    // 0x1130b20: DecompressPointer r1
    //     0x1130b20: add             x1, x1, HEAP, lsl #32
    // 0x1130b24: ArrayStore: r2[0] = r1  ; List_4
    //     0x1130b24: stur            w1, [x2, #0x17]
    // 0x1130b28: r17 = 5167
    //     0x1130b28: mov             x17, #0x142f
    // 0x1130b2c: cmp             x3, x17
    // 0x1130b30: b.eq            #0x1130b4c
    // 0x1130b34: r17 = 5168
    //     0x1130b34: mov             x17, #0x1430
    // 0x1130b38: cmp             x3, x17
    // 0x1130b3c: b.ne            #0x1130b4c
    // 0x1130b40: r1 = Instance_Color
    //     0x1130b40: add             x1, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x1130b44: ldr             x1, [x1, #0x810]
    // 0x1130b48: b               #0x1130b54
    // 0x1130b4c: LoadField: r1 = r0->field_13
    //     0x1130b4c: ldur            w1, [x0, #0x13]
    // 0x1130b50: DecompressPointer r1
    //     0x1130b50: add             x1, x1, HEAP, lsl #32
    // 0x1130b54: StoreField: r2->field_1b = r1
    //     0x1130b54: stur            w1, [x2, #0x1b]
    // 0x1130b58: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x1130b58: ldur            w1, [x0, #0x17]
    // 0x1130b5c: DecompressPointer r1
    //     0x1130b5c: add             x1, x1, HEAP, lsl #32
    // 0x1130b60: StoreField: r2->field_1f = r1
    //     0x1130b60: stur            w1, [x2, #0x1f]
    // 0x1130b64: r17 = 5167
    //     0x1130b64: mov             x17, #0x142f
    // 0x1130b68: cmp             x3, x17
    // 0x1130b6c: b.ne            #0x1130b84
    // 0x1130b70: LoadField: r1 = r0->field_1b
    //     0x1130b70: ldur            w1, [x0, #0x1b]
    // 0x1130b74: DecompressPointer r1
    //     0x1130b74: add             x1, x1, HEAP, lsl #32
    // 0x1130b78: mov             x0, x1
    // 0x1130b7c: mov             x2, x3
    // 0x1130b80: b               #0x1130c30
    // 0x1130b84: r17 = 5168
    //     0x1130b84: mov             x17, #0x1430
    // 0x1130b88: cmp             x3, x17
    // 0x1130b8c: b.ne            #0x1130ba0
    // 0x1130b90: mov             x2, x3
    // 0x1130b94: r0 = Instance_Color
    //     0x1130b94: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x1130b98: ldr             x0, [x0, #0x810]
    // 0x1130b9c: b               #0x1130c30
    // 0x1130ba0: mov             x1, x0
    // 0x1130ba4: LoadField: r0 = r1->field_bb
    //     0x1130ba4: ldur            w0, [x1, #0xbb]
    // 0x1130ba8: DecompressPointer r0
    //     0x1130ba8: add             x0, x0, HEAP, lsl #32
    // 0x1130bac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1130bb0: cmp             w0, w16
    // 0x1130bb4: b.ne            #0x1130bc4
    // 0x1130bb8: r2 = _isDark
    //     0x1130bb8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26408] Field <_DatePickerDefaultsM2@738353974._isDark@738353974>: late final (offset: 0xbc)
    //     0x1130bbc: ldr             x2, [x2, #0x408]
    // 0x1130bc0: r0 = InitLateFinalInstanceField()
    //     0x1130bc0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1130bc4: tbnz            w0, #4, #0x1130bfc
    // 0x1130bc8: ldr             x1, [fp, #0x10]
    // 0x1130bcc: LoadField: r0 = r1->field_b3
    //     0x1130bcc: ldur            w0, [x1, #0xb3]
    // 0x1130bd0: DecompressPointer r0
    //     0x1130bd0: add             x0, x0, HEAP, lsl #32
    // 0x1130bd4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1130bd8: cmp             w0, w16
    // 0x1130bdc: b.ne            #0x1130bec
    // 0x1130be0: r2 = _colors
    //     0x1130be0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x1130be4: ldr             x2, [x2, #0x410]
    // 0x1130be8: r0 = InitLateFinalInstanceField()
    //     0x1130be8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1130bec: LoadField: r1 = r0->field_7b
    //     0x1130bec: ldur            w1, [x0, #0x7b]
    // 0x1130bf0: DecompressPointer r1
    //     0x1130bf0: add             x1, x1, HEAP, lsl #32
    // 0x1130bf4: mov             x0, x1
    // 0x1130bf8: b               #0x1130c2c
    // 0x1130bfc: ldr             x1, [fp, #0x10]
    // 0x1130c00: LoadField: r0 = r1->field_b3
    //     0x1130c00: ldur            w0, [x1, #0xb3]
    // 0x1130c04: DecompressPointer r0
    //     0x1130c04: add             x0, x0, HEAP, lsl #32
    // 0x1130c08: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1130c0c: cmp             w0, w16
    // 0x1130c10: b.ne            #0x1130c20
    // 0x1130c14: r2 = _colors
    //     0x1130c14: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x1130c18: ldr             x2, [x2, #0x410]
    // 0x1130c1c: r0 = InitLateFinalInstanceField()
    //     0x1130c1c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1130c20: LoadField: r1 = r0->field_b
    //     0x1130c20: ldur            w1, [x0, #0xb]
    // 0x1130c24: DecompressPointer r1
    //     0x1130c24: add             x1, x1, HEAP, lsl #32
    // 0x1130c28: mov             x0, x1
    // 0x1130c2c: ldur            x2, [fp, #-8]
    // 0x1130c30: ldur            x1, [fp, #-0x18]
    // 0x1130c34: ArrayStore: r1[5] = r0  ; List_4
    //     0x1130c34: add             x25, x1, #0x23
    //     0x1130c38: str             w0, [x25]
    //     0x1130c3c: tbz             w0, #0, #0x1130c58
    //     0x1130c40: ldurb           w16, [x1, #-1]
    //     0x1130c44: ldurb           w17, [x0, #-1]
    //     0x1130c48: and             x16, x17, x16, lsr #2
    //     0x1130c4c: tst             x16, HEAP, lsr #32
    //     0x1130c50: b.eq            #0x1130c58
    //     0x1130c54: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1130c58: r17 = 5167
    //     0x1130c58: mov             x17, #0x142f
    // 0x1130c5c: cmp             x2, x17
    // 0x1130c60: b.ne            #0x1130c78
    // 0x1130c64: ldr             x0, [fp, #0x10]
    // 0x1130c68: LoadField: r1 = r0->field_1f
    //     0x1130c68: ldur            w1, [x0, #0x1f]
    // 0x1130c6c: DecompressPointer r1
    //     0x1130c6c: add             x1, x1, HEAP, lsl #32
    // 0x1130c70: mov             x0, x1
    // 0x1130c74: b               #0x1130d68
    // 0x1130c78: ldr             x0, [fp, #0x10]
    // 0x1130c7c: r17 = 5168
    //     0x1130c7c: mov             x17, #0x1430
    // 0x1130c80: cmp             x2, x17
    // 0x1130c84: b.ne            #0x1130cd8
    // 0x1130c88: mov             x1, x0
    // 0x1130c8c: LoadField: r0 = r1->field_b3
    //     0x1130c8c: ldur            w0, [x1, #0xb3]
    // 0x1130c90: DecompressPointer r0
    //     0x1130c90: add             x0, x0, HEAP, lsl #32
    // 0x1130c94: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1130c98: cmp             w0, w16
    // 0x1130c9c: b.ne            #0x1130cac
    // 0x1130ca0: r2 = _colors
    //     0x1130ca0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x1130ca4: ldr             x2, [x2, #0x400]
    // 0x1130ca8: r0 = InitLateFinalInstanceField()
    //     0x1130ca8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1130cac: LoadField: r1 = r0->field_a3
    //     0x1130cac: ldur            w1, [x0, #0xa3]
    // 0x1130cb0: DecompressPointer r1
    //     0x1130cb0: add             x1, x1, HEAP, lsl #32
    // 0x1130cb4: cmp             w1, NULL
    // 0x1130cb8: b.ne            #0x1130ccc
    // 0x1130cbc: LoadField: r1 = r0->field_7f
    //     0x1130cbc: ldur            w1, [x0, #0x7f]
    // 0x1130cc0: DecompressPointer r1
    //     0x1130cc0: add             x1, x1, HEAP, lsl #32
    // 0x1130cc4: mov             x0, x1
    // 0x1130cc8: b               #0x1130cd0
    // 0x1130ccc: mov             x0, x1
    // 0x1130cd0: ldur            x2, [fp, #-8]
    // 0x1130cd4: b               #0x1130d68
    // 0x1130cd8: ldr             x1, [fp, #0x10]
    // 0x1130cdc: LoadField: r0 = r1->field_bb
    //     0x1130cdc: ldur            w0, [x1, #0xbb]
    // 0x1130ce0: DecompressPointer r0
    //     0x1130ce0: add             x0, x0, HEAP, lsl #32
    // 0x1130ce4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1130ce8: cmp             w0, w16
    // 0x1130cec: b.ne            #0x1130cfc
    // 0x1130cf0: r2 = _isDark
    //     0x1130cf0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26408] Field <_DatePickerDefaultsM2@738353974._isDark@738353974>: late final (offset: 0xbc)
    //     0x1130cf4: ldr             x2, [x2, #0x408]
    // 0x1130cf8: r0 = InitLateFinalInstanceField()
    //     0x1130cf8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1130cfc: tbnz            w0, #4, #0x1130d34
    // 0x1130d00: ldr             x1, [fp, #0x10]
    // 0x1130d04: LoadField: r0 = r1->field_b3
    //     0x1130d04: ldur            w0, [x1, #0xb3]
    // 0x1130d08: DecompressPointer r0
    //     0x1130d08: add             x0, x0, HEAP, lsl #32
    // 0x1130d0c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1130d10: cmp             w0, w16
    // 0x1130d14: b.ne            #0x1130d24
    // 0x1130d18: r2 = _colors
    //     0x1130d18: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x1130d1c: ldr             x2, [x2, #0x410]
    // 0x1130d20: r0 = InitLateFinalInstanceField()
    //     0x1130d20: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1130d24: LoadField: r1 = r0->field_7f
    //     0x1130d24: ldur            w1, [x0, #0x7f]
    // 0x1130d28: DecompressPointer r1
    //     0x1130d28: add             x1, x1, HEAP, lsl #32
    // 0x1130d2c: mov             x0, x1
    // 0x1130d30: b               #0x1130d64
    // 0x1130d34: ldr             x1, [fp, #0x10]
    // 0x1130d38: LoadField: r0 = r1->field_b3
    //     0x1130d38: ldur            w0, [x1, #0xb3]
    // 0x1130d3c: DecompressPointer r0
    //     0x1130d3c: add             x0, x0, HEAP, lsl #32
    // 0x1130d40: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1130d44: cmp             w0, w16
    // 0x1130d48: b.ne            #0x1130d58
    // 0x1130d4c: r2 = _colors
    //     0x1130d4c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x1130d50: ldr             x2, [x2, #0x410]
    // 0x1130d54: r0 = InitLateFinalInstanceField()
    //     0x1130d54: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1130d58: LoadField: r1 = r0->field_f
    //     0x1130d58: ldur            w1, [x0, #0xf]
    // 0x1130d5c: DecompressPointer r1
    //     0x1130d5c: add             x1, x1, HEAP, lsl #32
    // 0x1130d60: mov             x0, x1
    // 0x1130d64: ldur            x2, [fp, #-8]
    // 0x1130d68: ldur            x1, [fp, #-0x18]
    // 0x1130d6c: ArrayStore: r1[6] = r0  ; List_4
    //     0x1130d6c: add             x25, x1, #0x27
    //     0x1130d70: str             w0, [x25]
    //     0x1130d74: tbz             w0, #0, #0x1130d90
    //     0x1130d78: ldurb           w16, [x1, #-1]
    //     0x1130d7c: ldurb           w17, [x0, #-1]
    //     0x1130d80: and             x16, x17, x16, lsr #2
    //     0x1130d84: tst             x16, HEAP, lsr #32
    //     0x1130d88: b.eq            #0x1130d90
    //     0x1130d8c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1130d90: r17 = 5167
    //     0x1130d90: mov             x17, #0x142f
    // 0x1130d94: cmp             x2, x17
    // 0x1130d98: b.ne            #0x1130db0
    // 0x1130d9c: ldr             x0, [fp, #0x10]
    // 0x1130da0: LoadField: r1 = r0->field_23
    //     0x1130da0: ldur            w1, [x0, #0x23]
    // 0x1130da4: DecompressPointer r1
    //     0x1130da4: add             x1, x1, HEAP, lsl #32
    // 0x1130da8: mov             x0, x1
    // 0x1130dac: b               #0x1130e2c
    // 0x1130db0: ldr             x0, [fp, #0x10]
    // 0x1130db4: r17 = 5168
    //     0x1130db4: mov             x17, #0x1430
    // 0x1130db8: cmp             x2, x17
    // 0x1130dbc: b.ne            #0x1130df8
    // 0x1130dc0: mov             x1, x0
    // 0x1130dc4: LoadField: r0 = r1->field_b7
    //     0x1130dc4: ldur            w0, [x1, #0xb7]
    // 0x1130dc8: DecompressPointer r0
    //     0x1130dc8: add             x0, x0, HEAP, lsl #32
    // 0x1130dcc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1130dd0: cmp             w0, w16
    // 0x1130dd4: b.ne            #0x1130de4
    // 0x1130dd8: r2 = _textTheme
    //     0x1130dd8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26418] Field <_DatePickerDefaultsM3@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0x1130ddc: ldr             x2, [x2, #0x418]
    // 0x1130de0: r0 = InitLateFinalInstanceField()
    //     0x1130de0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1130de4: LoadField: r1 = r0->field_13
    //     0x1130de4: ldur            w1, [x0, #0x13]
    // 0x1130de8: DecompressPointer r1
    //     0x1130de8: add             x1, x1, HEAP, lsl #32
    // 0x1130dec: mov             x0, x1
    // 0x1130df0: ldur            x2, [fp, #-8]
    // 0x1130df4: b               #0x1130e2c
    // 0x1130df8: ldr             x1, [fp, #0x10]
    // 0x1130dfc: LoadField: r0 = r1->field_b7
    //     0x1130dfc: ldur            w0, [x1, #0xb7]
    // 0x1130e00: DecompressPointer r0
    //     0x1130e00: add             x0, x0, HEAP, lsl #32
    // 0x1130e04: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1130e08: cmp             w0, w16
    // 0x1130e0c: b.ne            #0x1130e1c
    // 0x1130e10: r2 = _textTheme
    //     0x1130e10: add             x2, PP, #0x26, lsl #12  ; [pp+0x26420] Field <_DatePickerDefaultsM2@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0x1130e14: ldr             x2, [x2, #0x420]
    // 0x1130e18: r0 = InitLateFinalInstanceField()
    //     0x1130e18: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1130e1c: LoadField: r1 = r0->field_1b
    //     0x1130e1c: ldur            w1, [x0, #0x1b]
    // 0x1130e20: DecompressPointer r1
    //     0x1130e20: add             x1, x1, HEAP, lsl #32
    // 0x1130e24: mov             x0, x1
    // 0x1130e28: ldur            x2, [fp, #-8]
    // 0x1130e2c: ldur            x1, [fp, #-0x18]
    // 0x1130e30: ArrayStore: r1[7] = r0  ; List_4
    //     0x1130e30: add             x25, x1, #0x2b
    //     0x1130e34: str             w0, [x25]
    //     0x1130e38: tbz             w0, #0, #0x1130e54
    //     0x1130e3c: ldurb           w16, [x1, #-1]
    //     0x1130e40: ldurb           w17, [x0, #-1]
    //     0x1130e44: and             x16, x17, x16, lsr #2
    //     0x1130e48: tst             x16, HEAP, lsr #32
    //     0x1130e4c: b.eq            #0x1130e54
    //     0x1130e50: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1130e54: r17 = 5167
    //     0x1130e54: mov             x17, #0x142f
    // 0x1130e58: cmp             x2, x17
    // 0x1130e5c: b.ne            #0x1130e74
    // 0x1130e60: ldr             x0, [fp, #0x10]
    // 0x1130e64: LoadField: r1 = r0->field_27
    //     0x1130e64: ldur            w1, [x0, #0x27]
    // 0x1130e68: DecompressPointer r1
    //     0x1130e68: add             x1, x1, HEAP, lsl #32
    // 0x1130e6c: mov             x0, x1
    // 0x1130e70: b               #0x1130ef0
    // 0x1130e74: ldr             x0, [fp, #0x10]
    // 0x1130e78: r17 = 5168
    //     0x1130e78: mov             x17, #0x1430
    // 0x1130e7c: cmp             x2, x17
    // 0x1130e80: b.ne            #0x1130ebc
    // 0x1130e84: mov             x1, x0
    // 0x1130e88: LoadField: r0 = r1->field_b7
    //     0x1130e88: ldur            w0, [x1, #0xb7]
    // 0x1130e8c: DecompressPointer r0
    //     0x1130e8c: add             x0, x0, HEAP, lsl #32
    // 0x1130e90: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1130e94: cmp             w0, w16
    // 0x1130e98: b.ne            #0x1130ea8
    // 0x1130e9c: r2 = _textTheme
    //     0x1130e9c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26418] Field <_DatePickerDefaultsM3@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0x1130ea0: ldr             x2, [x2, #0x418]
    // 0x1130ea4: r0 = InitLateFinalInstanceField()
    //     0x1130ea4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1130ea8: LoadField: r1 = r0->field_37
    //     0x1130ea8: ldur            w1, [x0, #0x37]
    // 0x1130eac: DecompressPointer r1
    //     0x1130eac: add             x1, x1, HEAP, lsl #32
    // 0x1130eb0: mov             x0, x1
    // 0x1130eb4: ldur            x2, [fp, #-8]
    // 0x1130eb8: b               #0x1130ef0
    // 0x1130ebc: ldr             x1, [fp, #0x10]
    // 0x1130ec0: LoadField: r0 = r1->field_b7
    //     0x1130ec0: ldur            w0, [x1, #0xb7]
    // 0x1130ec4: DecompressPointer r0
    //     0x1130ec4: add             x0, x0, HEAP, lsl #32
    // 0x1130ec8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1130ecc: cmp             w0, w16
    // 0x1130ed0: b.ne            #0x1130ee0
    // 0x1130ed4: r2 = _textTheme
    //     0x1130ed4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26420] Field <_DatePickerDefaultsM2@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0x1130ed8: ldr             x2, [x2, #0x420]
    // 0x1130edc: r0 = InitLateFinalInstanceField()
    //     0x1130edc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1130ee0: LoadField: r1 = r0->field_3f
    //     0x1130ee0: ldur            w1, [x0, #0x3f]
    // 0x1130ee4: DecompressPointer r1
    //     0x1130ee4: add             x1, x1, HEAP, lsl #32
    // 0x1130ee8: mov             x0, x1
    // 0x1130eec: ldur            x2, [fp, #-8]
    // 0x1130ef0: ldur            x1, [fp, #-0x18]
    // 0x1130ef4: ArrayStore: r1[8] = r0  ; List_4
    //     0x1130ef4: add             x25, x1, #0x2f
    //     0x1130ef8: str             w0, [x25]
    //     0x1130efc: tbz             w0, #0, #0x1130f18
    //     0x1130f00: ldurb           w16, [x1, #-1]
    //     0x1130f04: ldurb           w17, [x0, #-1]
    //     0x1130f08: and             x16, x17, x16, lsr #2
    //     0x1130f0c: tst             x16, HEAP, lsr #32
    //     0x1130f10: b.eq            #0x1130f18
    //     0x1130f14: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1130f18: r17 = 5167
    //     0x1130f18: mov             x17, #0x142f
    // 0x1130f1c: cmp             x2, x17
    // 0x1130f20: b.ne            #0x1130f38
    // 0x1130f24: ldr             x0, [fp, #0x10]
    // 0x1130f28: LoadField: r1 = r0->field_2b
    //     0x1130f28: ldur            w1, [x0, #0x2b]
    // 0x1130f2c: DecompressPointer r1
    //     0x1130f2c: add             x1, x1, HEAP, lsl #32
    // 0x1130f30: mov             x0, x1
    // 0x1130f34: b               #0x1131054
    // 0x1130f38: ldr             x0, [fp, #0x10]
    // 0x1130f3c: r17 = 5168
    //     0x1130f3c: mov             x17, #0x1430
    // 0x1130f40: cmp             x2, x17
    // 0x1130f44: b.ne            #0x1130fb8
    // 0x1130f48: mov             x1, x0
    // 0x1130f4c: LoadField: r0 = r1->field_b7
    //     0x1130f4c: ldur            w0, [x1, #0xb7]
    // 0x1130f50: DecompressPointer r0
    //     0x1130f50: add             x0, x0, HEAP, lsl #32
    // 0x1130f54: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1130f58: cmp             w0, w16
    // 0x1130f5c: b.ne            #0x1130f6c
    // 0x1130f60: r2 = _textTheme
    //     0x1130f60: add             x2, PP, #0x26, lsl #12  ; [pp+0x26418] Field <_DatePickerDefaultsM3@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0x1130f64: ldr             x2, [x2, #0x418]
    // 0x1130f68: r0 = InitLateFinalInstanceField()
    //     0x1130f68: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1130f6c: LoadField: r2 = r0->field_2b
    //     0x1130f6c: ldur            w2, [x0, #0x2b]
    // 0x1130f70: DecompressPointer r2
    //     0x1130f70: add             x2, x2, HEAP, lsl #32
    // 0x1130f74: ldr             x1, [fp, #0x10]
    // 0x1130f78: stur            x2, [fp, #-0x10]
    // 0x1130f7c: LoadField: r0 = r1->field_b3
    //     0x1130f7c: ldur            w0, [x1, #0xb3]
    // 0x1130f80: DecompressPointer r0
    //     0x1130f80: add             x0, x0, HEAP, lsl #32
    // 0x1130f84: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1130f88: cmp             w0, w16
    // 0x1130f8c: b.ne            #0x1130f9c
    // 0x1130f90: r2 = _colors
    //     0x1130f90: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x1130f94: ldr             x2, [x2, #0x400]
    // 0x1130f98: r0 = InitLateFinalInstanceField()
    //     0x1130f98: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1130f9c: LoadField: r2 = r0->field_7f
    //     0x1130f9c: ldur            w2, [x0, #0x7f]
    // 0x1130fa0: DecompressPointer r2
    //     0x1130fa0: add             x2, x2, HEAP, lsl #32
    // 0x1130fa4: ldur            x1, [fp, #-0x10]
    // 0x1130fa8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x1130fa8: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x1130fac: r0 = apply()
    //     0x1130fac: bl              #0x8acf20  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0x1130fb0: ldur            x2, [fp, #-8]
    // 0x1130fb4: b               #0x1131054
    // 0x1130fb8: ldr             x1, [fp, #0x10]
    // 0x1130fbc: LoadField: r0 = r1->field_b7
    //     0x1130fbc: ldur            w0, [x1, #0xb7]
    // 0x1130fc0: DecompressPointer r0
    //     0x1130fc0: add             x0, x0, HEAP, lsl #32
    // 0x1130fc4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1130fc8: cmp             w0, w16
    // 0x1130fcc: b.ne            #0x1130fdc
    // 0x1130fd0: r2 = _textTheme
    //     0x1130fd0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26420] Field <_DatePickerDefaultsM2@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0x1130fd4: ldr             x2, [x2, #0x420]
    // 0x1130fd8: r0 = InitLateFinalInstanceField()
    //     0x1130fd8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1130fdc: LoadField: r2 = r0->field_33
    //     0x1130fdc: ldur            w2, [x0, #0x33]
    // 0x1130fe0: DecompressPointer r2
    //     0x1130fe0: add             x2, x2, HEAP, lsl #32
    // 0x1130fe4: stur            x2, [fp, #-0x10]
    // 0x1130fe8: cmp             w2, NULL
    // 0x1130fec: b.ne            #0x1130ff8
    // 0x1130ff0: r0 = Null
    //     0x1130ff0: mov             x0, NULL
    // 0x1130ff4: b               #0x1131050
    // 0x1130ff8: ldr             x1, [fp, #0x10]
    // 0x1130ffc: LoadField: r0 = r1->field_b3
    //     0x1130ffc: ldur            w0, [x1, #0xb3]
    // 0x1131000: DecompressPointer r0
    //     0x1131000: add             x0, x0, HEAP, lsl #32
    // 0x1131004: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1131008: cmp             w0, w16
    // 0x113100c: b.ne            #0x113101c
    // 0x1131010: r2 = _colors
    //     0x1131010: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x1131014: ldr             x2, [x2, #0x410]
    // 0x1131018: r0 = InitLateFinalInstanceField()
    //     0x1131018: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x113101c: LoadField: r1 = r0->field_7f
    //     0x113101c: ldur            w1, [x0, #0x7f]
    // 0x1131020: DecompressPointer r1
    //     0x1131020: add             x1, x1, HEAP, lsl #32
    // 0x1131024: r0 = LoadClassIdInstr(r1)
    //     0x1131024: ldur            x0, [x1, #-1]
    //     0x1131028: ubfx            x0, x0, #0xc, #0x14
    // 0x113102c: d0 = 0.600000
    //     0x113102c: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c88] IMM: double(0.6) from 0x3fe3333333333333
    //     0x1131030: ldr             d0, [x17, #0xc88]
    // 0x1131034: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1131034: sub             lr, x0, #1, lsl #12
    //     0x1131038: ldr             lr, [x21, lr, lsl #3]
    //     0x113103c: blr             lr
    // 0x1131040: ldur            x1, [fp, #-0x10]
    // 0x1131044: mov             x2, x0
    // 0x1131048: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x1131048: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x113104c: r0 = apply()
    //     0x113104c: bl              #0x8acf20  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0x1131050: ldur            x2, [fp, #-8]
    // 0x1131054: ldur            x1, [fp, #-0x18]
    // 0x1131058: ArrayStore: r1[9] = r0  ; List_4
    //     0x1131058: add             x25, x1, #0x33
    //     0x113105c: str             w0, [x25]
    //     0x1131060: tbz             w0, #0, #0x113107c
    //     0x1131064: ldurb           w16, [x1, #-1]
    //     0x1131068: ldurb           w17, [x0, #-1]
    //     0x113106c: and             x16, x17, x16, lsr #2
    //     0x1131070: tst             x16, HEAP, lsr #32
    //     0x1131074: b.eq            #0x113107c
    //     0x1131078: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x113107c: r17 = 5167
    //     0x113107c: mov             x17, #0x142f
    // 0x1131080: cmp             x2, x17
    // 0x1131084: b.ne            #0x113109c
    // 0x1131088: ldr             x0, [fp, #0x10]
    // 0x113108c: LoadField: r1 = r0->field_2f
    //     0x113108c: ldur            w1, [x0, #0x2f]
    // 0x1131090: DecompressPointer r1
    //     0x1131090: add             x1, x1, HEAP, lsl #32
    // 0x1131094: mov             x0, x1
    // 0x1131098: b               #0x1131118
    // 0x113109c: ldr             x0, [fp, #0x10]
    // 0x11310a0: r17 = 5168
    //     0x11310a0: mov             x17, #0x1430
    // 0x11310a4: cmp             x2, x17
    // 0x11310a8: b.ne            #0x11310e4
    // 0x11310ac: mov             x1, x0
    // 0x11310b0: LoadField: r0 = r1->field_b7
    //     0x11310b0: ldur            w0, [x1, #0xb7]
    // 0x11310b4: DecompressPointer r0
    //     0x11310b4: add             x0, x0, HEAP, lsl #32
    // 0x11310b8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11310bc: cmp             w0, w16
    // 0x11310c0: b.ne            #0x11310d0
    // 0x11310c4: r2 = _textTheme
    //     0x11310c4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26418] Field <_DatePickerDefaultsM3@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0x11310c8: ldr             x2, [x2, #0x418]
    // 0x11310cc: r0 = InitLateFinalInstanceField()
    //     0x11310cc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x11310d0: LoadField: r1 = r0->field_2b
    //     0x11310d0: ldur            w1, [x0, #0x2b]
    // 0x11310d4: DecompressPointer r1
    //     0x11310d4: add             x1, x1, HEAP, lsl #32
    // 0x11310d8: mov             x0, x1
    // 0x11310dc: ldur            x2, [fp, #-8]
    // 0x11310e0: b               #0x1131118
    // 0x11310e4: ldr             x1, [fp, #0x10]
    // 0x11310e8: LoadField: r0 = r1->field_b7
    //     0x11310e8: ldur            w0, [x1, #0xb7]
    // 0x11310ec: DecompressPointer r0
    //     0x11310ec: add             x0, x0, HEAP, lsl #32
    // 0x11310f0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11310f4: cmp             w0, w16
    // 0x11310f8: b.ne            #0x1131108
    // 0x11310fc: r2 = _textTheme
    //     0x11310fc: add             x2, PP, #0x26, lsl #12  ; [pp+0x26420] Field <_DatePickerDefaultsM2@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0x1131100: ldr             x2, [x2, #0x420]
    // 0x1131104: r0 = InitLateFinalInstanceField()
    //     0x1131104: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1131108: LoadField: r1 = r0->field_33
    //     0x1131108: ldur            w1, [x0, #0x33]
    // 0x113110c: DecompressPointer r1
    //     0x113110c: add             x1, x1, HEAP, lsl #32
    // 0x1131110: mov             x0, x1
    // 0x1131114: ldur            x2, [fp, #-8]
    // 0x1131118: ldur            x1, [fp, #-0x18]
    // 0x113111c: ArrayStore: r1[10] = r0  ; List_4
    //     0x113111c: add             x25, x1, #0x37
    //     0x1131120: str             w0, [x25]
    //     0x1131124: tbz             w0, #0, #0x1131140
    //     0x1131128: ldurb           w16, [x1, #-1]
    //     0x113112c: ldurb           w17, [x0, #-1]
    //     0x1131130: and             x16, x17, x16, lsr #2
    //     0x1131134: tst             x16, HEAP, lsr #32
    //     0x1131138: b.eq            #0x1131140
    //     0x113113c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1131140: r17 = 5167
    //     0x1131140: mov             x17, #0x142f
    // 0x1131144: cmp             x2, x17
    // 0x1131148: b.ne            #0x113115c
    // 0x113114c: ldr             x1, [fp, #0x10]
    // 0x1131150: LoadField: r0 = r1->field_33
    //     0x1131150: ldur            w0, [x1, #0x33]
    // 0x1131154: DecompressPointer r0
    //     0x1131154: add             x0, x0, HEAP, lsl #32
    // 0x1131158: b               #0x11311e8
    // 0x113115c: ldr             x1, [fp, #0x10]
    // 0x1131160: r17 = 5168
    //     0x1131160: mov             x17, #0x1430
    // 0x1131164: cmp             x2, x17
    // 0x1131168: b.ne            #0x11311ac
    // 0x113116c: r1 = 1
    //     0x113116c: mov             x1, #1
    // 0x1131170: r0 = AllocateContext()
    //     0x1131170: bl              #0x13de838  ; AllocateContextStub
    // 0x1131174: mov             x1, x0
    // 0x1131178: ldr             x0, [fp, #0x10]
    // 0x113117c: StoreField: r1->field_f = r0
    //     0x113117c: stur            w0, [x1, #0xf]
    // 0x1131180: mov             x2, x1
    // 0x1131184: r1 = Function '<anonymous closure>':.
    //     0x1131184: add             x1, PP, #0x26, lsl #12  ; [pp+0x26428] AnonymousClosure: (0xdf2fac), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM3
    //     0x1131188: ldr             x1, [x1, #0x428]
    // 0x113118c: r0 = AllocateClosure()
    //     0x113118c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1131190: r16 = <Color?>
    //     0x1131190: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1131194: ldr             x16, [x16, #0xa40]
    // 0x1131198: stp             x0, x16, [SP]
    // 0x113119c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x113119c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x11311a0: r0 = resolveWith()
    //     0x11311a0: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x11311a4: ldur            x2, [fp, #-8]
    // 0x11311a8: b               #0x11311e8
    // 0x11311ac: r1 = 1
    //     0x11311ac: mov             x1, #1
    // 0x11311b0: r0 = AllocateContext()
    //     0x11311b0: bl              #0x13de838  ; AllocateContextStub
    // 0x11311b4: mov             x1, x0
    // 0x11311b8: ldr             x0, [fp, #0x10]
    // 0x11311bc: StoreField: r1->field_f = r0
    //     0x11311bc: stur            w0, [x1, #0xf]
    // 0x11311c0: mov             x2, x1
    // 0x11311c4: r1 = Function '<anonymous closure>':.
    //     0x11311c4: add             x1, PP, #0x26, lsl #12  ; [pp+0x26430] AnonymousClosure: (0xdf2e38), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM2
    //     0x11311c8: ldr             x1, [x1, #0x430]
    // 0x11311cc: r0 = AllocateClosure()
    //     0x11311cc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11311d0: r16 = <Color?>
    //     0x11311d0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x11311d4: ldr             x16, [x16, #0xa40]
    // 0x11311d8: stp             x0, x16, [SP]
    // 0x11311dc: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x11311dc: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x11311e0: r0 = resolveWith()
    //     0x11311e0: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x11311e4: ldur            x2, [fp, #-8]
    // 0x11311e8: ldur            x1, [fp, #-0x18]
    // 0x11311ec: ArrayStore: r1[11] = r0  ; List_4
    //     0x11311ec: add             x25, x1, #0x3b
    //     0x11311f0: str             w0, [x25]
    //     0x11311f4: tbz             w0, #0, #0x1131210
    //     0x11311f8: ldurb           w16, [x1, #-1]
    //     0x11311fc: ldurb           w17, [x0, #-1]
    //     0x1131200: and             x16, x17, x16, lsr #2
    //     0x1131204: tst             x16, HEAP, lsr #32
    //     0x1131208: b.eq            #0x1131210
    //     0x113120c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1131210: r17 = 5167
    //     0x1131210: mov             x17, #0x142f
    // 0x1131214: cmp             x2, x17
    // 0x1131218: b.ne            #0x113122c
    // 0x113121c: ldr             x1, [fp, #0x10]
    // 0x1131220: LoadField: r0 = r1->field_37
    //     0x1131220: ldur            w0, [x1, #0x37]
    // 0x1131224: DecompressPointer r0
    //     0x1131224: add             x0, x0, HEAP, lsl #32
    // 0x1131228: b               #0x11312b8
    // 0x113122c: ldr             x1, [fp, #0x10]
    // 0x1131230: r17 = 5168
    //     0x1131230: mov             x17, #0x1430
    // 0x1131234: cmp             x2, x17
    // 0x1131238: b.ne            #0x113127c
    // 0x113123c: r1 = 1
    //     0x113123c: mov             x1, #1
    // 0x1131240: r0 = AllocateContext()
    //     0x1131240: bl              #0x13de838  ; AllocateContextStub
    // 0x1131244: mov             x1, x0
    // 0x1131248: ldr             x0, [fp, #0x10]
    // 0x113124c: StoreField: r1->field_f = r0
    //     0x113124c: stur            w0, [x1, #0xf]
    // 0x1131250: mov             x2, x1
    // 0x1131254: r1 = Function '<anonymous closure>':.
    //     0x1131254: add             x1, PP, #0x26, lsl #12  ; [pp+0x26438] AnonymousClosure: (0xdf2bac), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM3
    //     0x1131258: ldr             x1, [x1, #0x438]
    // 0x113125c: r0 = AllocateClosure()
    //     0x113125c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1131260: r16 = <Color?>
    //     0x1131260: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1131264: ldr             x16, [x16, #0xa40]
    // 0x1131268: stp             x0, x16, [SP]
    // 0x113126c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x113126c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1131270: r0 = resolveWith()
    //     0x1131270: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1131274: ldur            x2, [fp, #-8]
    // 0x1131278: b               #0x11312b8
    // 0x113127c: r1 = 1
    //     0x113127c: mov             x1, #1
    // 0x1131280: r0 = AllocateContext()
    //     0x1131280: bl              #0x13de838  ; AllocateContextStub
    // 0x1131284: mov             x1, x0
    // 0x1131288: ldr             x0, [fp, #0x10]
    // 0x113128c: StoreField: r1->field_f = r0
    //     0x113128c: stur            w0, [x1, #0xf]
    // 0x1131290: mov             x2, x1
    // 0x1131294: r1 = Function '<anonymous closure>':.
    //     0x1131294: add             x1, PP, #0x26, lsl #12  ; [pp+0x26440] AnonymousClosure: (0xdf2afc), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM2
    //     0x1131298: ldr             x1, [x1, #0x440]
    // 0x113129c: r0 = AllocateClosure()
    //     0x113129c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11312a0: r16 = <Color?>
    //     0x11312a0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x11312a4: ldr             x16, [x16, #0xa40]
    // 0x11312a8: stp             x0, x16, [SP]
    // 0x11312ac: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x11312ac: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x11312b0: r0 = resolveWith()
    //     0x11312b0: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x11312b4: ldur            x2, [fp, #-8]
    // 0x11312b8: ldur            x1, [fp, #-0x18]
    // 0x11312bc: ArrayStore: r1[12] = r0  ; List_4
    //     0x11312bc: add             x25, x1, #0x3f
    //     0x11312c0: str             w0, [x25]
    //     0x11312c4: tbz             w0, #0, #0x11312e0
    //     0x11312c8: ldurb           w16, [x1, #-1]
    //     0x11312cc: ldurb           w17, [x0, #-1]
    //     0x11312d0: and             x16, x17, x16, lsr #2
    //     0x11312d4: tst             x16, HEAP, lsr #32
    //     0x11312d8: b.eq            #0x11312e0
    //     0x11312dc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x11312e0: r17 = 5167
    //     0x11312e0: mov             x17, #0x142f
    // 0x11312e4: cmp             x2, x17
    // 0x11312e8: b.ne            #0x1131304
    // 0x11312ec: ldr             x1, [fp, #0x10]
    // 0x11312f0: LoadField: r0 = r1->field_3b
    //     0x11312f0: ldur            w0, [x1, #0x3b]
    // 0x11312f4: DecompressPointer r0
    //     0x11312f4: add             x0, x0, HEAP, lsl #32
    // 0x11312f8: mov             x3, x2
    // 0x11312fc: mov             x2, x1
    // 0x1131300: b               #0x1131398
    // 0x1131304: ldr             x1, [fp, #0x10]
    // 0x1131308: r17 = 5168
    //     0x1131308: mov             x17, #0x1430
    // 0x113130c: cmp             x2, x17
    // 0x1131310: b.ne            #0x1131358
    // 0x1131314: r1 = 1
    //     0x1131314: mov             x1, #1
    // 0x1131318: r0 = AllocateContext()
    //     0x1131318: bl              #0x13de838  ; AllocateContextStub
    // 0x113131c: mov             x1, x0
    // 0x1131320: ldr             x0, [fp, #0x10]
    // 0x1131324: StoreField: r1->field_f = r0
    //     0x1131324: stur            w0, [x1, #0xf]
    // 0x1131328: mov             x2, x1
    // 0x113132c: r1 = Function '<anonymous closure>':.
    //     0x113132c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26448] AnonymousClosure: (0xdf2558), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM3
    //     0x1131330: ldr             x1, [x1, #0x448]
    // 0x1131334: r0 = AllocateClosure()
    //     0x1131334: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1131338: r16 = <Color?>
    //     0x1131338: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x113133c: ldr             x16, [x16, #0xa40]
    // 0x1131340: stp             x0, x16, [SP]
    // 0x1131344: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1131344: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1131348: r0 = resolveWith()
    //     0x1131348: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x113134c: ldr             x2, [fp, #0x10]
    // 0x1131350: ldur            x3, [fp, #-8]
    // 0x1131354: b               #0x1131398
    // 0x1131358: r1 = 1
    //     0x1131358: mov             x1, #1
    // 0x113135c: r0 = AllocateContext()
    //     0x113135c: bl              #0x13de838  ; AllocateContextStub
    // 0x1131360: mov             x1, x0
    // 0x1131364: ldr             x0, [fp, #0x10]
    // 0x1131368: StoreField: r1->field_f = r0
    //     0x1131368: stur            w0, [x1, #0xf]
    // 0x113136c: mov             x2, x1
    // 0x1131370: r1 = Function '<anonymous closure>':.
    //     0x1131370: add             x1, PP, #0x26, lsl #12  ; [pp+0x26450] AnonymousClosure: (0xdf2190), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM2
    //     0x1131374: ldr             x1, [x1, #0x450]
    // 0x1131378: r0 = AllocateClosure()
    //     0x1131378: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x113137c: r16 = <Color?>
    //     0x113137c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1131380: ldr             x16, [x16, #0xa40]
    // 0x1131384: stp             x0, x16, [SP]
    // 0x1131388: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1131388: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x113138c: r0 = resolveWith()
    //     0x113138c: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1131390: ldr             x2, [fp, #0x10]
    // 0x1131394: ldur            x3, [fp, #-8]
    // 0x1131398: ldur            x1, [fp, #-0x18]
    // 0x113139c: ArrayStore: r1[13] = r0  ; List_4
    //     0x113139c: add             x25, x1, #0x43
    //     0x11313a0: str             w0, [x25]
    //     0x11313a4: tbz             w0, #0, #0x11313c0
    //     0x11313a8: ldurb           w16, [x1, #-1]
    //     0x11313ac: ldurb           w17, [x0, #-1]
    //     0x11313b0: and             x16, x17, x16, lsr #2
    //     0x11313b4: tst             x16, HEAP, lsr #32
    //     0x11313b8: b.eq            #0x11313c0
    //     0x11313bc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x11313c0: LoadField: r0 = r2->field_3f
    //     0x11313c0: ldur            w0, [x2, #0x3f]
    // 0x11313c4: DecompressPointer r0
    //     0x11313c4: add             x0, x0, HEAP, lsl #32
    // 0x11313c8: ldur            x1, [fp, #-0x18]
    // 0x11313cc: ArrayStore: r1[14] = r0  ; List_4
    //     0x11313cc: add             x25, x1, #0x47
    //     0x11313d0: str             w0, [x25]
    //     0x11313d4: tbz             w0, #0, #0x11313f0
    //     0x11313d8: ldurb           w16, [x1, #-1]
    //     0x11313dc: ldurb           w17, [x0, #-1]
    //     0x11313e0: and             x16, x17, x16, lsr #2
    //     0x11313e4: tst             x16, HEAP, lsr #32
    //     0x11313e8: b.eq            #0x11313f0
    //     0x11313ec: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x11313f0: r17 = 5167
    //     0x11313f0: mov             x17, #0x142f
    // 0x11313f4: cmp             x3, x17
    // 0x11313f8: b.ne            #0x113140c
    // 0x11313fc: LoadField: r0 = r2->field_43
    //     0x11313fc: ldur            w0, [x2, #0x43]
    // 0x1131400: DecompressPointer r0
    //     0x1131400: add             x0, x0, HEAP, lsl #32
    // 0x1131404: mov             x2, x3
    // 0x1131408: b               #0x1131498
    // 0x113140c: r17 = 5168
    //     0x113140c: mov             x17, #0x1430
    // 0x1131410: cmp             x3, x17
    // 0x1131414: b.ne            #0x1131458
    // 0x1131418: r1 = 1
    //     0x1131418: mov             x1, #1
    // 0x113141c: r0 = AllocateContext()
    //     0x113141c: bl              #0x13de838  ; AllocateContextStub
    // 0x1131420: mov             x1, x0
    // 0x1131424: ldr             x0, [fp, #0x10]
    // 0x1131428: StoreField: r1->field_f = r0
    //     0x1131428: stur            w0, [x1, #0xf]
    // 0x113142c: mov             x2, x1
    // 0x1131430: r1 = Function '<anonymous closure>':.
    //     0x1131430: add             x1, PP, #0x26, lsl #12  ; [pp+0x26458] AnonymousClosure: (0xdf3294), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM3
    //     0x1131434: ldr             x1, [x1, #0x458]
    // 0x1131438: r0 = AllocateClosure()
    //     0x1131438: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x113143c: r16 = <Color?>
    //     0x113143c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1131440: ldr             x16, [x16, #0xa40]
    // 0x1131444: stp             x0, x16, [SP]
    // 0x1131448: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1131448: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x113144c: r0 = resolveWith()
    //     0x113144c: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1131450: ldur            x2, [fp, #-8]
    // 0x1131454: b               #0x1131498
    // 0x1131458: mov             x1, x2
    // 0x113145c: r1 = 1
    //     0x113145c: mov             x1, #1
    // 0x1131460: r0 = AllocateContext()
    //     0x1131460: bl              #0x13de838  ; AllocateContextStub
    // 0x1131464: mov             x1, x0
    // 0x1131468: ldr             x0, [fp, #0x10]
    // 0x113146c: StoreField: r1->field_f = r0
    //     0x113146c: stur            w0, [x1, #0xf]
    // 0x1131470: mov             x2, x1
    // 0x1131474: r1 = Function '<anonymous closure>':.
    //     0x1131474: add             x1, PP, #0x26, lsl #12  ; [pp+0x26460] AnonymousClosure: (0xdf3120), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM2
    //     0x1131478: ldr             x1, [x1, #0x460]
    // 0x113147c: r0 = AllocateClosure()
    //     0x113147c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1131480: r16 = <Color?>
    //     0x1131480: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1131484: ldr             x16, [x16, #0xa40]
    // 0x1131488: stp             x0, x16, [SP]
    // 0x113148c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x113148c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1131490: r0 = resolveWith()
    //     0x1131490: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1131494: ldur            x2, [fp, #-8]
    // 0x1131498: ldur            x1, [fp, #-0x18]
    // 0x113149c: ArrayStore: r1[15] = r0  ; List_4
    //     0x113149c: add             x25, x1, #0x4b
    //     0x11314a0: str             w0, [x25]
    //     0x11314a4: tbz             w0, #0, #0x11314c0
    //     0x11314a8: ldurb           w16, [x1, #-1]
    //     0x11314ac: ldurb           w17, [x0, #-1]
    //     0x11314b0: and             x16, x17, x16, lsr #2
    //     0x11314b4: tst             x16, HEAP, lsr #32
    //     0x11314b8: b.eq            #0x11314c0
    //     0x11314bc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x11314c0: r17 = 5167
    //     0x11314c0: mov             x17, #0x142f
    // 0x11314c4: cmp             x2, x17
    // 0x11314c8: b.ne            #0x11314dc
    // 0x11314cc: ldr             x1, [fp, #0x10]
    // 0x11314d0: LoadField: r0 = r1->field_47
    //     0x11314d0: ldur            w0, [x1, #0x47]
    // 0x11314d4: DecompressPointer r0
    //     0x11314d4: add             x0, x0, HEAP, lsl #32
    // 0x11314d8: b               #0x1131568
    // 0x11314dc: ldr             x1, [fp, #0x10]
    // 0x11314e0: r17 = 5168
    //     0x11314e0: mov             x17, #0x1430
    // 0x11314e4: cmp             x2, x17
    // 0x11314e8: b.ne            #0x113152c
    // 0x11314ec: r1 = 1
    //     0x11314ec: mov             x1, #1
    // 0x11314f0: r0 = AllocateContext()
    //     0x11314f0: bl              #0x13de838  ; AllocateContextStub
    // 0x11314f4: mov             x1, x0
    // 0x11314f8: ldr             x0, [fp, #0x10]
    // 0x11314fc: StoreField: r1->field_f = r0
    //     0x11314fc: stur            w0, [x1, #0xf]
    // 0x1131500: mov             x2, x1
    // 0x1131504: r1 = Function '<anonymous closure>':.
    //     0x1131504: add             x1, PP, #0x26, lsl #12  ; [pp+0x26438] AnonymousClosure: (0xdf2bac), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM3
    //     0x1131508: ldr             x1, [x1, #0x438]
    // 0x113150c: r0 = AllocateClosure()
    //     0x113150c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1131510: r16 = <Color?>
    //     0x1131510: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1131514: ldr             x16, [x16, #0xa40]
    // 0x1131518: stp             x0, x16, [SP]
    // 0x113151c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x113151c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1131520: r0 = resolveWith()
    //     0x1131520: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1131524: ldur            x2, [fp, #-8]
    // 0x1131528: b               #0x1131568
    // 0x113152c: r1 = 1
    //     0x113152c: mov             x1, #1
    // 0x1131530: r0 = AllocateContext()
    //     0x1131530: bl              #0x13de838  ; AllocateContextStub
    // 0x1131534: mov             x1, x0
    // 0x1131538: ldr             x0, [fp, #0x10]
    // 0x113153c: StoreField: r1->field_f = r0
    //     0x113153c: stur            w0, [x1, #0xf]
    // 0x1131540: mov             x2, x1
    // 0x1131544: r1 = Function '<anonymous closure>':.
    //     0x1131544: add             x1, PP, #0x26, lsl #12  ; [pp+0x26440] AnonymousClosure: (0xdf2afc), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM2
    //     0x1131548: ldr             x1, [x1, #0x440]
    // 0x113154c: r0 = AllocateClosure()
    //     0x113154c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1131550: r16 = <Color?>
    //     0x1131550: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1131554: ldr             x16, [x16, #0xa40]
    // 0x1131558: stp             x0, x16, [SP]
    // 0x113155c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x113155c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1131560: r0 = resolveWith()
    //     0x1131560: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1131564: ldur            x2, [fp, #-8]
    // 0x1131568: ldur            x1, [fp, #-0x18]
    // 0x113156c: ArrayStore: r1[16] = r0  ; List_4
    //     0x113156c: add             x25, x1, #0x4f
    //     0x1131570: str             w0, [x25]
    //     0x1131574: tbz             w0, #0, #0x1131590
    //     0x1131578: ldurb           w16, [x1, #-1]
    //     0x113157c: ldurb           w17, [x0, #-1]
    //     0x1131580: and             x16, x17, x16, lsr #2
    //     0x1131584: tst             x16, HEAP, lsr #32
    //     0x1131588: b.eq            #0x1131590
    //     0x113158c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1131590: r17 = 5167
    //     0x1131590: mov             x17, #0x142f
    // 0x1131594: cmp             x2, x17
    // 0x1131598: b.ne            #0x11315b0
    // 0x113159c: ldr             x0, [fp, #0x10]
    // 0x11315a0: LoadField: r1 = r0->field_4b
    //     0x11315a0: ldur            w1, [x0, #0x4b]
    // 0x11315a4: DecompressPointer r1
    //     0x11315a4: add             x1, x1, HEAP, lsl #32
    // 0x11315a8: mov             x0, x1
    // 0x11315ac: b               #0x113169c
    // 0x11315b0: ldr             x0, [fp, #0x10]
    // 0x11315b4: r17 = 5168
    //     0x11315b4: mov             x17, #0x1430
    // 0x11315b8: cmp             x2, x17
    // 0x11315bc: b.ne            #0x1131628
    // 0x11315c0: mov             x1, x0
    // 0x11315c4: LoadField: r0 = r1->field_b3
    //     0x11315c4: ldur            w0, [x1, #0xb3]
    // 0x11315c8: DecompressPointer r0
    //     0x11315c8: add             x0, x0, HEAP, lsl #32
    // 0x11315cc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11315d0: cmp             w0, w16
    // 0x11315d4: b.ne            #0x11315e4
    // 0x11315d8: r2 = _colors
    //     0x11315d8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x11315dc: ldr             x2, [x2, #0x400]
    // 0x11315e0: r0 = InitLateFinalInstanceField()
    //     0x11315e0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x11315e4: LoadField: r1 = r0->field_b
    //     0x11315e4: ldur            w1, [x0, #0xb]
    // 0x11315e8: DecompressPointer r1
    //     0x11315e8: add             x1, x1, HEAP, lsl #32
    // 0x11315ec: stur            x1, [fp, #-0x10]
    // 0x11315f0: r0 = BorderSide()
    //     0x11315f0: bl              #0x8a73bc  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x11315f4: mov             x1, x0
    // 0x11315f8: ldur            x0, [fp, #-0x10]
    // 0x11315fc: StoreField: r1->field_7 = r0
    //     0x11315fc: stur            w0, [x1, #7]
    // 0x1131600: d0 = 1.000000
    //     0x1131600: fmov            d0, #1.00000000
    // 0x1131604: StoreField: r1->field_b = d0
    //     0x1131604: stur            d0, [x1, #0xb]
    // 0x1131608: r0 = Instance_BorderStyle
    //     0x1131608: add             x0, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0x113160c: ldr             x0, [x0, #0xdc8]
    // 0x1131610: StoreField: r1->field_13 = r0
    //     0x1131610: stur            w0, [x1, #0x13]
    // 0x1131614: d1 = -1.000000
    //     0x1131614: fmov            d1, #-1.00000000
    // 0x1131618: ArrayStore: r1[0] = d1  ; List_8
    //     0x1131618: stur            d1, [x1, #0x17]
    // 0x113161c: mov             x0, x1
    // 0x1131620: ldur            x2, [fp, #-8]
    // 0x1131624: b               #0x113169c
    // 0x1131628: r0 = Instance_BorderStyle
    //     0x1131628: add             x0, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0x113162c: ldr             x0, [x0, #0xdc8]
    // 0x1131630: d0 = 1.000000
    //     0x1131630: fmov            d0, #1.00000000
    // 0x1131634: d1 = -1.000000
    //     0x1131634: fmov            d1, #-1.00000000
    // 0x1131638: ldr             x1, [fp, #0x10]
    // 0x113163c: LoadField: r0 = r1->field_b3
    //     0x113163c: ldur            w0, [x1, #0xb3]
    // 0x1131640: DecompressPointer r0
    //     0x1131640: add             x0, x0, HEAP, lsl #32
    // 0x1131644: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1131648: cmp             w0, w16
    // 0x113164c: b.ne            #0x113165c
    // 0x1131650: r2 = _colors
    //     0x1131650: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x1131654: ldr             x2, [x2, #0x410]
    // 0x1131658: r0 = InitLateFinalInstanceField()
    //     0x1131658: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x113165c: LoadField: r1 = r0->field_b
    //     0x113165c: ldur            w1, [x0, #0xb]
    // 0x1131660: DecompressPointer r1
    //     0x1131660: add             x1, x1, HEAP, lsl #32
    // 0x1131664: stur            x1, [fp, #-0x10]
    // 0x1131668: r0 = BorderSide()
    //     0x1131668: bl              #0x8a73bc  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x113166c: mov             x1, x0
    // 0x1131670: ldur            x0, [fp, #-0x10]
    // 0x1131674: StoreField: r1->field_7 = r0
    //     0x1131674: stur            w0, [x1, #7]
    // 0x1131678: d0 = 1.000000
    //     0x1131678: fmov            d0, #1.00000000
    // 0x113167c: StoreField: r1->field_b = d0
    //     0x113167c: stur            d0, [x1, #0xb]
    // 0x1131680: r0 = Instance_BorderStyle
    //     0x1131680: add             x0, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0x1131684: ldr             x0, [x0, #0xdc8]
    // 0x1131688: StoreField: r1->field_13 = r0
    //     0x1131688: stur            w0, [x1, #0x13]
    // 0x113168c: d0 = -1.000000
    //     0x113168c: fmov            d0, #-1.00000000
    // 0x1131690: ArrayStore: r1[0] = d0  ; List_8
    //     0x1131690: stur            d0, [x1, #0x17]
    // 0x1131694: mov             x0, x1
    // 0x1131698: ldur            x2, [fp, #-8]
    // 0x113169c: ldur            x1, [fp, #-0x18]
    // 0x11316a0: ArrayStore: r1[17] = r0  ; List_4
    //     0x11316a0: add             x25, x1, #0x53
    //     0x11316a4: str             w0, [x25]
    //     0x11316a8: tbz             w0, #0, #0x11316c4
    //     0x11316ac: ldurb           w16, [x1, #-1]
    //     0x11316b0: ldurb           w17, [x0, #-1]
    //     0x11316b4: and             x16, x17, x16, lsr #2
    //     0x11316b8: tst             x16, HEAP, lsr #32
    //     0x11316bc: b.eq            #0x11316c4
    //     0x11316c0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x11316c4: r17 = 5167
    //     0x11316c4: mov             x17, #0x142f
    // 0x11316c8: cmp             x2, x17
    // 0x11316cc: b.ne            #0x11316e4
    // 0x11316d0: ldr             x0, [fp, #0x10]
    // 0x11316d4: LoadField: r1 = r0->field_4f
    //     0x11316d4: ldur            w1, [x0, #0x4f]
    // 0x11316d8: DecompressPointer r1
    //     0x11316d8: add             x1, x1, HEAP, lsl #32
    // 0x11316dc: mov             x0, x1
    // 0x11316e0: b               #0x1131760
    // 0x11316e4: ldr             x0, [fp, #0x10]
    // 0x11316e8: r17 = 5168
    //     0x11316e8: mov             x17, #0x1430
    // 0x11316ec: cmp             x2, x17
    // 0x11316f0: b.ne            #0x113172c
    // 0x11316f4: mov             x1, x0
    // 0x11316f8: LoadField: r0 = r1->field_b7
    //     0x11316f8: ldur            w0, [x1, #0xb7]
    // 0x11316fc: DecompressPointer r0
    //     0x11316fc: add             x0, x0, HEAP, lsl #32
    // 0x1131700: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1131704: cmp             w0, w16
    // 0x1131708: b.ne            #0x1131718
    // 0x113170c: r2 = _textTheme
    //     0x113170c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26418] Field <_DatePickerDefaultsM3@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0x1131710: ldr             x2, [x2, #0x418]
    // 0x1131714: r0 = InitLateFinalInstanceField()
    //     0x1131714: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1131718: LoadField: r1 = r0->field_2b
    //     0x1131718: ldur            w1, [x0, #0x2b]
    // 0x113171c: DecompressPointer r1
    //     0x113171c: add             x1, x1, HEAP, lsl #32
    // 0x1131720: mov             x0, x1
    // 0x1131724: ldur            x2, [fp, #-8]
    // 0x1131728: b               #0x1131760
    // 0x113172c: ldr             x1, [fp, #0x10]
    // 0x1131730: LoadField: r0 = r1->field_b7
    //     0x1131730: ldur            w0, [x1, #0xb7]
    // 0x1131734: DecompressPointer r0
    //     0x1131734: add             x0, x0, HEAP, lsl #32
    // 0x1131738: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x113173c: cmp             w0, w16
    // 0x1131740: b.ne            #0x1131750
    // 0x1131744: r2 = _textTheme
    //     0x1131744: add             x2, PP, #0x26, lsl #12  ; [pp+0x26420] Field <_DatePickerDefaultsM2@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0x1131748: ldr             x2, [x2, #0x420]
    // 0x113174c: r0 = InitLateFinalInstanceField()
    //     0x113174c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1131750: LoadField: r1 = r0->field_2b
    //     0x1131750: ldur            w1, [x0, #0x2b]
    // 0x1131754: DecompressPointer r1
    //     0x1131754: add             x1, x1, HEAP, lsl #32
    // 0x1131758: mov             x0, x1
    // 0x113175c: ldur            x2, [fp, #-8]
    // 0x1131760: ldur            x1, [fp, #-0x18]
    // 0x1131764: ArrayStore: r1[18] = r0  ; List_4
    //     0x1131764: add             x25, x1, #0x57
    //     0x1131768: str             w0, [x25]
    //     0x113176c: tbz             w0, #0, #0x1131788
    //     0x1131770: ldurb           w16, [x1, #-1]
    //     0x1131774: ldurb           w17, [x0, #-1]
    //     0x1131778: and             x16, x17, x16, lsr #2
    //     0x113177c: tst             x16, HEAP, lsr #32
    //     0x1131780: b.eq            #0x1131788
    //     0x1131784: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1131788: r17 = 5167
    //     0x1131788: mov             x17, #0x142f
    // 0x113178c: cmp             x2, x17
    // 0x1131790: b.eq            #0x11317e4
    // 0x1131794: r17 = 5168
    //     0x1131794: mov             x17, #0x1430
    // 0x1131798: cmp             x2, x17
    // 0x113179c: b.ne            #0x11317e4
    // 0x11317a0: ldr             x1, [fp, #0x10]
    // 0x11317a4: r1 = 1
    //     0x11317a4: mov             x1, #1
    // 0x11317a8: r0 = AllocateContext()
    //     0x11317a8: bl              #0x13de838  ; AllocateContextStub
    // 0x11317ac: mov             x1, x0
    // 0x11317b0: ldr             x0, [fp, #0x10]
    // 0x11317b4: StoreField: r1->field_f = r0
    //     0x11317b4: stur            w0, [x1, #0xf]
    // 0x11317b8: mov             x2, x1
    // 0x11317bc: r1 = Function '<anonymous closure>':.
    //     0x11317bc: add             x1, PP, #0x26, lsl #12  ; [pp+0x26468] AnonymousClosure: (0xdf490c), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM3
    //     0x11317c0: ldr             x1, [x1, #0x468]
    // 0x11317c4: r0 = AllocateClosure()
    //     0x11317c4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11317c8: r16 = <Color?>
    //     0x11317c8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x11317cc: ldr             x16, [x16, #0xa40]
    // 0x11317d0: stp             x0, x16, [SP]
    // 0x11317d4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x11317d4: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x11317d8: r0 = resolveWith()
    //     0x11317d8: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x11317dc: ldr             x2, [fp, #0x10]
    // 0x11317e0: b               #0x11317f0
    // 0x11317e4: ldr             x2, [fp, #0x10]
    // 0x11317e8: LoadField: r0 = r2->field_53
    //     0x11317e8: ldur            w0, [x2, #0x53]
    // 0x11317ec: DecompressPointer r0
    //     0x11317ec: add             x0, x0, HEAP, lsl #32
    // 0x11317f0: ldur            x3, [fp, #-8]
    // 0x11317f4: ldur            x1, [fp, #-0x18]
    // 0x11317f8: ArrayStore: r1[19] = r0  ; List_4
    //     0x11317f8: add             x25, x1, #0x5b
    //     0x11317fc: str             w0, [x25]
    //     0x1131800: tbz             w0, #0, #0x113181c
    //     0x1131804: ldurb           w16, [x1, #-1]
    //     0x1131808: ldurb           w17, [x0, #-1]
    //     0x113180c: and             x16, x17, x16, lsr #2
    //     0x1131810: tst             x16, HEAP, lsr #32
    //     0x1131814: b.eq            #0x113181c
    //     0x1131818: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x113181c: r17 = 5167
    //     0x113181c: mov             x17, #0x142f
    // 0x1131820: cmp             x3, x17
    // 0x1131824: b.eq            #0x1131878
    // 0x1131828: r17 = 5168
    //     0x1131828: mov             x17, #0x1430
    // 0x113182c: cmp             x3, x17
    // 0x1131830: b.ne            #0x1131874
    // 0x1131834: r1 = 1
    //     0x1131834: mov             x1, #1
    // 0x1131838: r0 = AllocateContext()
    //     0x1131838: bl              #0x13de838  ; AllocateContextStub
    // 0x113183c: mov             x1, x0
    // 0x1131840: ldr             x0, [fp, #0x10]
    // 0x1131844: StoreField: r1->field_f = r0
    //     0x1131844: stur            w0, [x1, #0xf]
    // 0x1131848: mov             x2, x1
    // 0x113184c: r1 = Function '<anonymous closure>':.
    //     0x113184c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26470] AnonymousClosure: (0xdf2bac), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM3
    //     0x1131850: ldr             x1, [x1, #0x470]
    // 0x1131854: r0 = AllocateClosure()
    //     0x1131854: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1131858: r16 = <Color?>
    //     0x1131858: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x113185c: ldr             x16, [x16, #0xa40]
    // 0x1131860: stp             x0, x16, [SP]
    // 0x1131864: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1131864: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1131868: r0 = resolveWith()
    //     0x1131868: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x113186c: ldr             x2, [fp, #0x10]
    // 0x1131870: b               #0x1131880
    // 0x1131874: ldr             x2, [fp, #0x10]
    // 0x1131878: LoadField: r0 = r2->field_57
    //     0x1131878: ldur            w0, [x2, #0x57]
    // 0x113187c: DecompressPointer r0
    //     0x113187c: add             x0, x0, HEAP, lsl #32
    // 0x1131880: ldur            x3, [fp, #-8]
    // 0x1131884: ldur            x1, [fp, #-0x18]
    // 0x1131888: ArrayStore: r1[20] = r0  ; List_4
    //     0x1131888: add             x25, x1, #0x5f
    //     0x113188c: str             w0, [x25]
    //     0x1131890: tbz             w0, #0, #0x11318ac
    //     0x1131894: ldurb           w16, [x1, #-1]
    //     0x1131898: ldurb           w17, [x0, #-1]
    //     0x113189c: and             x16, x17, x16, lsr #2
    //     0x11318a0: tst             x16, HEAP, lsr #32
    //     0x11318a4: b.eq            #0x11318ac
    //     0x11318a8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x11318ac: r17 = 5167
    //     0x11318ac: mov             x17, #0x142f
    // 0x11318b0: cmp             x3, x17
    // 0x11318b4: b.eq            #0x1131908
    // 0x11318b8: r17 = 5168
    //     0x11318b8: mov             x17, #0x1430
    // 0x11318bc: cmp             x3, x17
    // 0x11318c0: b.ne            #0x1131904
    // 0x11318c4: r1 = 1
    //     0x11318c4: mov             x1, #1
    // 0x11318c8: r0 = AllocateContext()
    //     0x11318c8: bl              #0x13de838  ; AllocateContextStub
    // 0x11318cc: mov             x1, x0
    // 0x11318d0: ldr             x0, [fp, #0x10]
    // 0x11318d4: StoreField: r1->field_f = r0
    //     0x11318d4: stur            w0, [x1, #0xf]
    // 0x11318d8: mov             x2, x1
    // 0x11318dc: r1 = Function '<anonymous closure>':.
    //     0x11318dc: add             x1, PP, #0x26, lsl #12  ; [pp+0x26478] AnonymousClosure: (0xdf2558), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM3
    //     0x11318e0: ldr             x1, [x1, #0x478]
    // 0x11318e4: r0 = AllocateClosure()
    //     0x11318e4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11318e8: r16 = <Color?>
    //     0x11318e8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x11318ec: ldr             x16, [x16, #0xa40]
    // 0x11318f0: stp             x0, x16, [SP]
    // 0x11318f4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x11318f4: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x11318f8: r0 = resolveWith()
    //     0x11318f8: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x11318fc: ldr             x2, [fp, #0x10]
    // 0x1131900: b               #0x1131910
    // 0x1131904: ldr             x2, [fp, #0x10]
    // 0x1131908: LoadField: r0 = r2->field_5b
    //     0x1131908: ldur            w0, [x2, #0x5b]
    // 0x113190c: DecompressPointer r0
    //     0x113190c: add             x0, x0, HEAP, lsl #32
    // 0x1131910: ldur            x3, [fp, #-8]
    // 0x1131914: ldur            x1, [fp, #-0x18]
    // 0x1131918: ArrayStore: r1[21] = r0  ; List_4
    //     0x1131918: add             x25, x1, #0x63
    //     0x113191c: str             w0, [x25]
    //     0x1131920: tbz             w0, #0, #0x113193c
    //     0x1131924: ldurb           w16, [x1, #-1]
    //     0x1131928: ldurb           w17, [x0, #-1]
    //     0x113192c: and             x16, x17, x16, lsr #2
    //     0x1131930: tst             x16, HEAP, lsr #32
    //     0x1131934: b.eq            #0x113193c
    //     0x1131938: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x113193c: LoadField: r0 = r2->field_5f
    //     0x113193c: ldur            w0, [x2, #0x5f]
    // 0x1131940: DecompressPointer r0
    //     0x1131940: add             x0, x0, HEAP, lsl #32
    // 0x1131944: ldur            x1, [fp, #-0x18]
    // 0x1131948: ArrayStore: r1[22] = r0  ; List_4
    //     0x1131948: add             x25, x1, #0x67
    //     0x113194c: str             w0, [x25]
    //     0x1131950: tbz             w0, #0, #0x113196c
    //     0x1131954: ldurb           w16, [x1, #-1]
    //     0x1131958: ldurb           w17, [x0, #-1]
    //     0x113195c: and             x16, x17, x16, lsr #2
    //     0x1131960: tst             x16, HEAP, lsr #32
    //     0x1131964: b.eq            #0x113196c
    //     0x1131968: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x113196c: r17 = -5167
    //     0x113196c: mov             x17, #-0x142f
    // 0x1131970: add             x16, x3, x17
    // 0x1131974: cmp             x16, #1
    // 0x1131978: b.hi            #0x1131988
    // 0x113197c: LoadField: r0 = r2->field_63
    //     0x113197c: ldur            w0, [x2, #0x63]
    // 0x1131980: DecompressPointer r0
    //     0x1131980: add             x0, x0, HEAP, lsl #32
    // 0x1131984: b               #0x11319c0
    // 0x1131988: mov             x1, x2
    // 0x113198c: LoadField: r0 = r1->field_b3
    //     0x113198c: ldur            w0, [x1, #0xb3]
    // 0x1131990: DecompressPointer r0
    //     0x1131990: add             x0, x0, HEAP, lsl #32
    // 0x1131994: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1131998: cmp             w0, w16
    // 0x113199c: b.ne            #0x11319ac
    // 0x11319a0: r2 = _colors
    //     0x11319a0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x11319a4: ldr             x2, [x2, #0x410]
    // 0x11319a8: r0 = InitLateFinalInstanceField()
    //     0x11319a8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x11319ac: LoadField: r1 = r0->field_7b
    //     0x11319ac: ldur            w1, [x0, #0x7b]
    // 0x11319b0: DecompressPointer r1
    //     0x11319b0: add             x1, x1, HEAP, lsl #32
    // 0x11319b4: mov             x0, x1
    // 0x11319b8: ldr             x2, [fp, #0x10]
    // 0x11319bc: ldur            x3, [fp, #-8]
    // 0x11319c0: ldur            x1, [fp, #-0x18]
    // 0x11319c4: ArrayStore: r1[23] = r0  ; List_4
    //     0x11319c4: add             x25, x1, #0x6b
    //     0x11319c8: str             w0, [x25]
    //     0x11319cc: tbz             w0, #0, #0x11319e8
    //     0x11319d0: ldurb           w16, [x1, #-1]
    //     0x11319d4: ldurb           w17, [x0, #-1]
    //     0x11319d8: and             x16, x17, x16, lsr #2
    //     0x11319dc: tst             x16, HEAP, lsr #32
    //     0x11319e0: b.eq            #0x11319e8
    //     0x11319e4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x11319e8: LoadField: r0 = r2->field_67
    //     0x11319e8: ldur            w0, [x2, #0x67]
    // 0x11319ec: DecompressPointer r0
    //     0x11319ec: add             x0, x0, HEAP, lsl #32
    // 0x11319f0: ldur            x1, [fp, #-0x18]
    // 0x11319f4: ArrayStore: r1[24] = r0  ; List_4
    //     0x11319f4: add             x25, x1, #0x6f
    //     0x11319f8: str             w0, [x25]
    //     0x11319fc: tbz             w0, #0, #0x1131a18
    //     0x1131a00: ldurb           w16, [x1, #-1]
    //     0x1131a04: ldurb           w17, [x0, #-1]
    //     0x1131a08: and             x16, x17, x16, lsr #2
    //     0x1131a0c: tst             x16, HEAP, lsr #32
    //     0x1131a10: b.eq            #0x1131a18
    //     0x1131a14: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1131a18: r17 = 5167
    //     0x1131a18: mov             x17, #0x142f
    // 0x1131a1c: cmp             x3, x17
    // 0x1131a20: b.ne            #0x1131a30
    // 0x1131a24: LoadField: r0 = r2->field_6b
    //     0x1131a24: ldur            w0, [x2, #0x6b]
    // 0x1131a28: DecompressPointer r0
    //     0x1131a28: add             x0, x0, HEAP, lsl #32
    // 0x1131a2c: b               #0x1131a50
    // 0x1131a30: r17 = 5168
    //     0x1131a30: mov             x17, #0x1430
    // 0x1131a34: cmp             x3, x17
    // 0x1131a38: b.ne            #0x1131a48
    // 0x1131a3c: r0 = Instance_Color
    //     0x1131a3c: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x1131a40: ldr             x0, [x0, #0x810]
    // 0x1131a44: b               #0x1131a50
    // 0x1131a48: r0 = Instance_Color
    //     0x1131a48: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x1131a4c: ldr             x0, [x0, #0x810]
    // 0x1131a50: ldur            x1, [fp, #-0x18]
    // 0x1131a54: ArrayStore: r1[25] = r0  ; List_4
    //     0x1131a54: add             x25, x1, #0x73
    //     0x1131a58: str             w0, [x25]
    //     0x1131a5c: tbz             w0, #0, #0x1131a78
    //     0x1131a60: ldurb           w16, [x1, #-1]
    //     0x1131a64: ldurb           w17, [x0, #-1]
    //     0x1131a68: and             x16, x17, x16, lsr #2
    //     0x1131a6c: tst             x16, HEAP, lsr #32
    //     0x1131a70: b.eq            #0x1131a78
    //     0x1131a74: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1131a78: r17 = 5167
    //     0x1131a78: mov             x17, #0x142f
    // 0x1131a7c: cmp             x3, x17
    // 0x1131a80: b.ne            #0x1131a90
    // 0x1131a84: LoadField: r0 = r2->field_6f
    //     0x1131a84: ldur            w0, [x2, #0x6f]
    // 0x1131a88: DecompressPointer r0
    //     0x1131a88: add             x0, x0, HEAP, lsl #32
    // 0x1131a8c: b               #0x1131ab0
    // 0x1131a90: r17 = 5168
    //     0x1131a90: mov             x17, #0x1430
    // 0x1131a94: cmp             x3, x17
    // 0x1131a98: b.ne            #0x1131aa8
    // 0x1131a9c: r0 = Instance_Color
    //     0x1131a9c: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x1131aa0: ldr             x0, [x0, #0x810]
    // 0x1131aa4: b               #0x1131ab0
    // 0x1131aa8: r0 = Instance_Color
    //     0x1131aa8: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x1131aac: ldr             x0, [x0, #0x810]
    // 0x1131ab0: ldur            x1, [fp, #-0x18]
    // 0x1131ab4: ArrayStore: r1[26] = r0  ; List_4
    //     0x1131ab4: add             x25, x1, #0x77
    //     0x1131ab8: str             w0, [x25]
    //     0x1131abc: tbz             w0, #0, #0x1131ad8
    //     0x1131ac0: ldurb           w16, [x1, #-1]
    //     0x1131ac4: ldurb           w17, [x0, #-1]
    //     0x1131ac8: and             x16, x17, x16, lsr #2
    //     0x1131acc: tst             x16, HEAP, lsr #32
    //     0x1131ad0: b.eq            #0x1131ad8
    //     0x1131ad4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1131ad8: LoadField: r0 = r2->field_73
    //     0x1131ad8: ldur            w0, [x2, #0x73]
    // 0x1131adc: DecompressPointer r0
    //     0x1131adc: add             x0, x0, HEAP, lsl #32
    // 0x1131ae0: ldur            x1, [fp, #-0x18]
    // 0x1131ae4: ArrayStore: r1[27] = r0  ; List_4
    //     0x1131ae4: add             x25, x1, #0x7b
    //     0x1131ae8: str             w0, [x25]
    //     0x1131aec: tbz             w0, #0, #0x1131b08
    //     0x1131af0: ldurb           w16, [x1, #-1]
    //     0x1131af4: ldurb           w17, [x0, #-1]
    //     0x1131af8: and             x16, x17, x16, lsr #2
    //     0x1131afc: tst             x16, HEAP, lsr #32
    //     0x1131b00: b.eq            #0x1131b08
    //     0x1131b04: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1131b08: r17 = 5167
    //     0x1131b08: mov             x17, #0x142f
    // 0x1131b0c: cmp             x3, x17
    // 0x1131b10: b.ne            #0x1131b24
    // 0x1131b14: LoadField: r0 = r2->field_77
    //     0x1131b14: ldur            w0, [x2, #0x77]
    // 0x1131b18: DecompressPointer r0
    //     0x1131b18: add             x0, x0, HEAP, lsl #32
    // 0x1131b1c: mov             x2, x3
    // 0x1131b20: b               #0x1131bd0
    // 0x1131b24: r17 = 5168
    //     0x1131b24: mov             x17, #0x1430
    // 0x1131b28: cmp             x3, x17
    // 0x1131b2c: b.ne            #0x1131b40
    // 0x1131b30: mov             x2, x3
    // 0x1131b34: r0 = Instance_Color
    //     0x1131b34: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x1131b38: ldr             x0, [x0, #0x810]
    // 0x1131b3c: b               #0x1131bd0
    // 0x1131b40: mov             x1, x2
    // 0x1131b44: LoadField: r0 = r1->field_bb
    //     0x1131b44: ldur            w0, [x1, #0xbb]
    // 0x1131b48: DecompressPointer r0
    //     0x1131b48: add             x0, x0, HEAP, lsl #32
    // 0x1131b4c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1131b50: cmp             w0, w16
    // 0x1131b54: b.ne            #0x1131b64
    // 0x1131b58: r2 = _isDark
    //     0x1131b58: add             x2, PP, #0x26, lsl #12  ; [pp+0x26408] Field <_DatePickerDefaultsM2@738353974._isDark@738353974>: late final (offset: 0xbc)
    //     0x1131b5c: ldr             x2, [x2, #0x408]
    // 0x1131b60: r0 = InitLateFinalInstanceField()
    //     0x1131b60: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1131b64: tbnz            w0, #4, #0x1131b9c
    // 0x1131b68: ldr             x1, [fp, #0x10]
    // 0x1131b6c: LoadField: r0 = r1->field_b3
    //     0x1131b6c: ldur            w0, [x1, #0xb3]
    // 0x1131b70: DecompressPointer r0
    //     0x1131b70: add             x0, x0, HEAP, lsl #32
    // 0x1131b74: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1131b78: cmp             w0, w16
    // 0x1131b7c: b.ne            #0x1131b8c
    // 0x1131b80: r2 = _colors
    //     0x1131b80: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x1131b84: ldr             x2, [x2, #0x410]
    // 0x1131b88: r0 = InitLateFinalInstanceField()
    //     0x1131b88: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1131b8c: LoadField: r1 = r0->field_7b
    //     0x1131b8c: ldur            w1, [x0, #0x7b]
    // 0x1131b90: DecompressPointer r1
    //     0x1131b90: add             x1, x1, HEAP, lsl #32
    // 0x1131b94: mov             x0, x1
    // 0x1131b98: b               #0x1131bcc
    // 0x1131b9c: ldr             x1, [fp, #0x10]
    // 0x1131ba0: LoadField: r0 = r1->field_b3
    //     0x1131ba0: ldur            w0, [x1, #0xb3]
    // 0x1131ba4: DecompressPointer r0
    //     0x1131ba4: add             x0, x0, HEAP, lsl #32
    // 0x1131ba8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1131bac: cmp             w0, w16
    // 0x1131bb0: b.ne            #0x1131bc0
    // 0x1131bb4: r2 = _colors
    //     0x1131bb4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x1131bb8: ldr             x2, [x2, #0x410]
    // 0x1131bbc: r0 = InitLateFinalInstanceField()
    //     0x1131bbc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1131bc0: LoadField: r1 = r0->field_b
    //     0x1131bc0: ldur            w1, [x0, #0xb]
    // 0x1131bc4: DecompressPointer r1
    //     0x1131bc4: add             x1, x1, HEAP, lsl #32
    // 0x1131bc8: mov             x0, x1
    // 0x1131bcc: ldur            x2, [fp, #-8]
    // 0x1131bd0: ldur            x1, [fp, #-0x18]
    // 0x1131bd4: ArrayStore: r1[28] = r0  ; List_4
    //     0x1131bd4: add             x25, x1, #0x7f
    //     0x1131bd8: str             w0, [x25]
    //     0x1131bdc: tbz             w0, #0, #0x1131bf8
    //     0x1131be0: ldurb           w16, [x1, #-1]
    //     0x1131be4: ldurb           w17, [x0, #-1]
    //     0x1131be8: and             x16, x17, x16, lsr #2
    //     0x1131bec: tst             x16, HEAP, lsr #32
    //     0x1131bf0: b.eq            #0x1131bf8
    //     0x1131bf4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1131bf8: r17 = 5167
    //     0x1131bf8: mov             x17, #0x142f
    // 0x1131bfc: cmp             x2, x17
    // 0x1131c00: b.ne            #0x1131c18
    // 0x1131c04: ldr             x0, [fp, #0x10]
    // 0x1131c08: LoadField: r1 = r0->field_7b
    //     0x1131c08: ldur            w1, [x0, #0x7b]
    // 0x1131c0c: DecompressPointer r1
    //     0x1131c0c: add             x1, x1, HEAP, lsl #32
    // 0x1131c10: mov             x0, x1
    // 0x1131c14: b               #0x1131d08
    // 0x1131c18: ldr             x0, [fp, #0x10]
    // 0x1131c1c: r17 = 5168
    //     0x1131c1c: mov             x17, #0x1430
    // 0x1131c20: cmp             x2, x17
    // 0x1131c24: b.ne            #0x1131c78
    // 0x1131c28: mov             x1, x0
    // 0x1131c2c: LoadField: r0 = r1->field_b3
    //     0x1131c2c: ldur            w0, [x1, #0xb3]
    // 0x1131c30: DecompressPointer r0
    //     0x1131c30: add             x0, x0, HEAP, lsl #32
    // 0x1131c34: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1131c38: cmp             w0, w16
    // 0x1131c3c: b.ne            #0x1131c4c
    // 0x1131c40: r2 = _colors
    //     0x1131c40: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x1131c44: ldr             x2, [x2, #0x400]
    // 0x1131c48: r0 = InitLateFinalInstanceField()
    //     0x1131c48: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1131c4c: LoadField: r1 = r0->field_a3
    //     0x1131c4c: ldur            w1, [x0, #0xa3]
    // 0x1131c50: DecompressPointer r1
    //     0x1131c50: add             x1, x1, HEAP, lsl #32
    // 0x1131c54: cmp             w1, NULL
    // 0x1131c58: b.ne            #0x1131c6c
    // 0x1131c5c: LoadField: r1 = r0->field_7f
    //     0x1131c5c: ldur            w1, [x0, #0x7f]
    // 0x1131c60: DecompressPointer r1
    //     0x1131c60: add             x1, x1, HEAP, lsl #32
    // 0x1131c64: mov             x0, x1
    // 0x1131c68: b               #0x1131c70
    // 0x1131c6c: mov             x0, x1
    // 0x1131c70: ldur            x2, [fp, #-8]
    // 0x1131c74: b               #0x1131d08
    // 0x1131c78: ldr             x1, [fp, #0x10]
    // 0x1131c7c: LoadField: r0 = r1->field_bb
    //     0x1131c7c: ldur            w0, [x1, #0xbb]
    // 0x1131c80: DecompressPointer r0
    //     0x1131c80: add             x0, x0, HEAP, lsl #32
    // 0x1131c84: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1131c88: cmp             w0, w16
    // 0x1131c8c: b.ne            #0x1131c9c
    // 0x1131c90: r2 = _isDark
    //     0x1131c90: add             x2, PP, #0x26, lsl #12  ; [pp+0x26408] Field <_DatePickerDefaultsM2@738353974._isDark@738353974>: late final (offset: 0xbc)
    //     0x1131c94: ldr             x2, [x2, #0x408]
    // 0x1131c98: r0 = InitLateFinalInstanceField()
    //     0x1131c98: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1131c9c: tbnz            w0, #4, #0x1131cd4
    // 0x1131ca0: ldr             x1, [fp, #0x10]
    // 0x1131ca4: LoadField: r0 = r1->field_b3
    //     0x1131ca4: ldur            w0, [x1, #0xb3]
    // 0x1131ca8: DecompressPointer r0
    //     0x1131ca8: add             x0, x0, HEAP, lsl #32
    // 0x1131cac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1131cb0: cmp             w0, w16
    // 0x1131cb4: b.ne            #0x1131cc4
    // 0x1131cb8: r2 = _colors
    //     0x1131cb8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x1131cbc: ldr             x2, [x2, #0x410]
    // 0x1131cc0: r0 = InitLateFinalInstanceField()
    //     0x1131cc0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1131cc4: LoadField: r1 = r0->field_7f
    //     0x1131cc4: ldur            w1, [x0, #0x7f]
    // 0x1131cc8: DecompressPointer r1
    //     0x1131cc8: add             x1, x1, HEAP, lsl #32
    // 0x1131ccc: mov             x0, x1
    // 0x1131cd0: b               #0x1131d04
    // 0x1131cd4: ldr             x1, [fp, #0x10]
    // 0x1131cd8: LoadField: r0 = r1->field_b3
    //     0x1131cd8: ldur            w0, [x1, #0xb3]
    // 0x1131cdc: DecompressPointer r0
    //     0x1131cdc: add             x0, x0, HEAP, lsl #32
    // 0x1131ce0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1131ce4: cmp             w0, w16
    // 0x1131ce8: b.ne            #0x1131cf8
    // 0x1131cec: r2 = _colors
    //     0x1131cec: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x1131cf0: ldr             x2, [x2, #0x410]
    // 0x1131cf4: r0 = InitLateFinalInstanceField()
    //     0x1131cf4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1131cf8: LoadField: r1 = r0->field_f
    //     0x1131cf8: ldur            w1, [x0, #0xf]
    // 0x1131cfc: DecompressPointer r1
    //     0x1131cfc: add             x1, x1, HEAP, lsl #32
    // 0x1131d00: mov             x0, x1
    // 0x1131d04: ldur            x2, [fp, #-8]
    // 0x1131d08: ldur            x1, [fp, #-0x18]
    // 0x1131d0c: ArrayStore: r1[29] = r0  ; List_4
    //     0x1131d0c: add             x25, x1, #0x83
    //     0x1131d10: str             w0, [x25]
    //     0x1131d14: tbz             w0, #0, #0x1131d30
    //     0x1131d18: ldurb           w16, [x1, #-1]
    //     0x1131d1c: ldurb           w17, [x0, #-1]
    //     0x1131d20: and             x16, x17, x16, lsr #2
    //     0x1131d24: tst             x16, HEAP, lsr #32
    //     0x1131d28: b.eq            #0x1131d30
    //     0x1131d2c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1131d30: r17 = 5167
    //     0x1131d30: mov             x17, #0x142f
    // 0x1131d34: cmp             x2, x17
    // 0x1131d38: b.ne            #0x1131d50
    // 0x1131d3c: ldr             x0, [fp, #0x10]
    // 0x1131d40: LoadField: r1 = r0->field_7f
    //     0x1131d40: ldur            w1, [x0, #0x7f]
    // 0x1131d44: DecompressPointer r1
    //     0x1131d44: add             x1, x1, HEAP, lsl #32
    // 0x1131d48: mov             x0, x1
    // 0x1131d4c: b               #0x1131dcc
    // 0x1131d50: ldr             x0, [fp, #0x10]
    // 0x1131d54: r17 = 5168
    //     0x1131d54: mov             x17, #0x1430
    // 0x1131d58: cmp             x2, x17
    // 0x1131d5c: b.ne            #0x1131d98
    // 0x1131d60: mov             x1, x0
    // 0x1131d64: LoadField: r0 = r1->field_b7
    //     0x1131d64: ldur            w0, [x1, #0xb7]
    // 0x1131d68: DecompressPointer r0
    //     0x1131d68: add             x0, x0, HEAP, lsl #32
    // 0x1131d6c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1131d70: cmp             w0, w16
    // 0x1131d74: b.ne            #0x1131d84
    // 0x1131d78: r2 = _textTheme
    //     0x1131d78: add             x2, PP, #0x26, lsl #12  ; [pp+0x26418] Field <_DatePickerDefaultsM3@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0x1131d7c: ldr             x2, [x2, #0x418]
    // 0x1131d80: r0 = InitLateFinalInstanceField()
    //     0x1131d80: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1131d84: LoadField: r1 = r0->field_1f
    //     0x1131d84: ldur            w1, [x0, #0x1f]
    // 0x1131d88: DecompressPointer r1
    //     0x1131d88: add             x1, x1, HEAP, lsl #32
    // 0x1131d8c: mov             x0, x1
    // 0x1131d90: ldur            x2, [fp, #-8]
    // 0x1131d94: b               #0x1131dcc
    // 0x1131d98: ldr             x1, [fp, #0x10]
    // 0x1131d9c: LoadField: r0 = r1->field_b7
    //     0x1131d9c: ldur            w0, [x1, #0xb7]
    // 0x1131da0: DecompressPointer r0
    //     0x1131da0: add             x0, x0, HEAP, lsl #32
    // 0x1131da4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1131da8: cmp             w0, w16
    // 0x1131dac: b.ne            #0x1131dbc
    // 0x1131db0: r2 = _textTheme
    //     0x1131db0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26420] Field <_DatePickerDefaultsM2@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0x1131db4: ldr             x2, [x2, #0x420]
    // 0x1131db8: r0 = InitLateFinalInstanceField()
    //     0x1131db8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1131dbc: LoadField: r1 = r0->field_1b
    //     0x1131dbc: ldur            w1, [x0, #0x1b]
    // 0x1131dc0: DecompressPointer r1
    //     0x1131dc0: add             x1, x1, HEAP, lsl #32
    // 0x1131dc4: mov             x0, x1
    // 0x1131dc8: ldur            x2, [fp, #-8]
    // 0x1131dcc: ldur            x1, [fp, #-0x18]
    // 0x1131dd0: ArrayStore: r1[30] = r0  ; List_4
    //     0x1131dd0: add             x25, x1, #0x87
    //     0x1131dd4: str             w0, [x25]
    //     0x1131dd8: tbz             w0, #0, #0x1131df4
    //     0x1131ddc: ldurb           w16, [x1, #-1]
    //     0x1131de0: ldurb           w17, [x0, #-1]
    //     0x1131de4: and             x16, x17, x16, lsr #2
    //     0x1131de8: tst             x16, HEAP, lsr #32
    //     0x1131dec: b.eq            #0x1131df4
    //     0x1131df0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1131df4: r17 = 5167
    //     0x1131df4: mov             x17, #0x142f
    // 0x1131df8: cmp             x2, x17
    // 0x1131dfc: b.ne            #0x1131e14
    // 0x1131e00: ldr             x0, [fp, #0x10]
    // 0x1131e04: LoadField: r1 = r0->field_83
    //     0x1131e04: ldur            w1, [x0, #0x83]
    // 0x1131e08: DecompressPointer r1
    //     0x1131e08: add             x1, x1, HEAP, lsl #32
    // 0x1131e0c: mov             x0, x1
    // 0x1131e10: b               #0x1131e90
    // 0x1131e14: ldr             x0, [fp, #0x10]
    // 0x1131e18: r17 = 5168
    //     0x1131e18: mov             x17, #0x1430
    // 0x1131e1c: cmp             x2, x17
    // 0x1131e20: b.ne            #0x1131e5c
    // 0x1131e24: mov             x1, x0
    // 0x1131e28: LoadField: r0 = r1->field_b7
    //     0x1131e28: ldur            w0, [x1, #0xb7]
    // 0x1131e2c: DecompressPointer r0
    //     0x1131e2c: add             x0, x0, HEAP, lsl #32
    // 0x1131e30: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1131e34: cmp             w0, w16
    // 0x1131e38: b.ne            #0x1131e48
    // 0x1131e3c: r2 = _textTheme
    //     0x1131e3c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26418] Field <_DatePickerDefaultsM3@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0x1131e40: ldr             x2, [x2, #0x418]
    // 0x1131e44: r0 = InitLateFinalInstanceField()
    //     0x1131e44: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1131e48: LoadField: r1 = r0->field_27
    //     0x1131e48: ldur            w1, [x0, #0x27]
    // 0x1131e4c: DecompressPointer r1
    //     0x1131e4c: add             x1, x1, HEAP, lsl #32
    // 0x1131e50: mov             x0, x1
    // 0x1131e54: ldur            x2, [fp, #-8]
    // 0x1131e58: b               #0x1131e90
    // 0x1131e5c: ldr             x1, [fp, #0x10]
    // 0x1131e60: LoadField: r0 = r1->field_b7
    //     0x1131e60: ldur            w0, [x1, #0xb7]
    // 0x1131e64: DecompressPointer r0
    //     0x1131e64: add             x0, x0, HEAP, lsl #32
    // 0x1131e68: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1131e6c: cmp             w0, w16
    // 0x1131e70: b.ne            #0x1131e80
    // 0x1131e74: r2 = _textTheme
    //     0x1131e74: add             x2, PP, #0x26, lsl #12  ; [pp+0x26420] Field <_DatePickerDefaultsM2@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0x1131e78: ldr             x2, [x2, #0x420]
    // 0x1131e7c: r0 = InitLateFinalInstanceField()
    //     0x1131e7c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1131e80: LoadField: r1 = r0->field_3f
    //     0x1131e80: ldur            w1, [x0, #0x3f]
    // 0x1131e84: DecompressPointer r1
    //     0x1131e84: add             x1, x1, HEAP, lsl #32
    // 0x1131e88: mov             x0, x1
    // 0x1131e8c: ldur            x2, [fp, #-8]
    // 0x1131e90: ldur            x1, [fp, #-0x18]
    // 0x1131e94: ArrayStore: r1[31] = r0  ; List_4
    //     0x1131e94: add             x25, x1, #0x8b
    //     0x1131e98: str             w0, [x25]
    //     0x1131e9c: tbz             w0, #0, #0x1131eb8
    //     0x1131ea0: ldurb           w16, [x1, #-1]
    //     0x1131ea4: ldurb           w17, [x0, #-1]
    //     0x1131ea8: and             x16, x17, x16, lsr #2
    //     0x1131eac: tst             x16, HEAP, lsr #32
    //     0x1131eb0: b.eq            #0x1131eb8
    //     0x1131eb4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1131eb8: r17 = 5167
    //     0x1131eb8: mov             x17, #0x142f
    // 0x1131ebc: cmp             x2, x17
    // 0x1131ec0: b.ne            #0x1131ed8
    // 0x1131ec4: ldr             x0, [fp, #0x10]
    // 0x1131ec8: LoadField: r1 = r0->field_87
    //     0x1131ec8: ldur            w1, [x0, #0x87]
    // 0x1131ecc: DecompressPointer r1
    //     0x1131ecc: add             x1, x1, HEAP, lsl #32
    // 0x1131ed0: mov             x0, x1
    // 0x1131ed4: b               #0x1131f74
    // 0x1131ed8: ldr             x0, [fp, #0x10]
    // 0x1131edc: r17 = 5168
    //     0x1131edc: mov             x17, #0x1430
    // 0x1131ee0: cmp             x2, x17
    // 0x1131ee4: b.ne            #0x1131f38
    // 0x1131ee8: mov             x1, x0
    // 0x1131eec: LoadField: r0 = r1->field_b3
    //     0x1131eec: ldur            w0, [x1, #0xb3]
    // 0x1131ef0: DecompressPointer r0
    //     0x1131ef0: add             x0, x0, HEAP, lsl #32
    // 0x1131ef4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1131ef8: cmp             w0, w16
    // 0x1131efc: b.ne            #0x1131f0c
    // 0x1131f00: r2 = _colors
    //     0x1131f00: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x1131f04: ldr             x2, [x2, #0x400]
    // 0x1131f08: r0 = InitLateFinalInstanceField()
    //     0x1131f08: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1131f0c: LoadField: r1 = r0->field_33
    //     0x1131f0c: ldur            w1, [x0, #0x33]
    // 0x1131f10: DecompressPointer r1
    //     0x1131f10: add             x1, x1, HEAP, lsl #32
    // 0x1131f14: cmp             w1, NULL
    // 0x1131f18: b.ne            #0x1131f2c
    // 0x1131f1c: LoadField: r1 = r0->field_2b
    //     0x1131f1c: ldur            w1, [x0, #0x2b]
    // 0x1131f20: DecompressPointer r1
    //     0x1131f20: add             x1, x1, HEAP, lsl #32
    // 0x1131f24: mov             x0, x1
    // 0x1131f28: b               #0x1131f30
    // 0x1131f2c: mov             x0, x1
    // 0x1131f30: ldur            x2, [fp, #-8]
    // 0x1131f34: b               #0x1131f74
    // 0x1131f38: ldr             x1, [fp, #0x10]
    // 0x1131f3c: LoadField: r0 = r1->field_b3
    //     0x1131f3c: ldur            w0, [x1, #0xb3]
    // 0x1131f40: DecompressPointer r0
    //     0x1131f40: add             x0, x0, HEAP, lsl #32
    // 0x1131f44: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1131f48: cmp             w0, w16
    // 0x1131f4c: b.ne            #0x1131f5c
    // 0x1131f50: r2 = _colors
    //     0x1131f50: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x1131f54: ldr             x2, [x2, #0x410]
    // 0x1131f58: r0 = InitLateFinalInstanceField()
    //     0x1131f58: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1131f5c: LoadField: r1 = r0->field_b
    //     0x1131f5c: ldur            w1, [x0, #0xb]
    // 0x1131f60: DecompressPointer r1
    //     0x1131f60: add             x1, x1, HEAP, lsl #32
    // 0x1131f64: d0 = 0.120000
    //     0x1131f64: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x1131f68: ldr             d0, [x17, #0xc40]
    // 0x1131f6c: r0 = withOpacity()
    //     0x1131f6c: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x1131f70: ldur            x2, [fp, #-8]
    // 0x1131f74: ldur            x1, [fp, #-0x18]
    // 0x1131f78: ArrayStore: r1[32] = r0  ; List_4
    //     0x1131f78: add             x25, x1, #0x8f
    //     0x1131f7c: str             w0, [x25]
    //     0x1131f80: tbz             w0, #0, #0x1131f9c
    //     0x1131f84: ldurb           w16, [x1, #-1]
    //     0x1131f88: ldurb           w17, [x0, #-1]
    //     0x1131f8c: and             x16, x17, x16, lsr #2
    //     0x1131f90: tst             x16, HEAP, lsr #32
    //     0x1131f94: b.eq            #0x1131f9c
    //     0x1131f98: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1131f9c: r17 = 5167
    //     0x1131f9c: mov             x17, #0x142f
    // 0x1131fa0: cmp             x2, x17
    // 0x1131fa4: b.ne            #0x1131fc0
    // 0x1131fa8: ldr             x1, [fp, #0x10]
    // 0x1131fac: LoadField: r0 = r1->field_8b
    //     0x1131fac: ldur            w0, [x1, #0x8b]
    // 0x1131fb0: DecompressPointer r0
    //     0x1131fb0: add             x0, x0, HEAP, lsl #32
    // 0x1131fb4: mov             x3, x2
    // 0x1131fb8: mov             x2, x1
    // 0x1131fbc: b               #0x1132054
    // 0x1131fc0: ldr             x1, [fp, #0x10]
    // 0x1131fc4: r17 = 5168
    //     0x1131fc4: mov             x17, #0x1430
    // 0x1131fc8: cmp             x2, x17
    // 0x1131fcc: b.ne            #0x1132014
    // 0x1131fd0: r1 = 1
    //     0x1131fd0: mov             x1, #1
    // 0x1131fd4: r0 = AllocateContext()
    //     0x1131fd4: bl              #0x13de838  ; AllocateContextStub
    // 0x1131fd8: mov             x1, x0
    // 0x1131fdc: ldr             x0, [fp, #0x10]
    // 0x1131fe0: StoreField: r1->field_f = r0
    //     0x1131fe0: stur            w0, [x1, #0xf]
    // 0x1131fe4: mov             x2, x1
    // 0x1131fe8: r1 = Function '<anonymous closure>':.
    //     0x1131fe8: add             x1, PP, #0x26, lsl #12  ; [pp+0x26480] AnonymousClosure: (0x1132450), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM3
    //     0x1131fec: ldr             x1, [x1, #0x480]
    // 0x1131ff0: r0 = AllocateClosure()
    //     0x1131ff0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1131ff4: r16 = <Color?>
    //     0x1131ff4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1131ff8: ldr             x16, [x16, #0xa40]
    // 0x1131ffc: stp             x0, x16, [SP]
    // 0x1132000: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1132000: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1132004: r0 = resolveWith()
    //     0x1132004: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1132008: ldr             x2, [fp, #0x10]
    // 0x113200c: ldur            x3, [fp, #-8]
    // 0x1132010: b               #0x1132054
    // 0x1132014: r1 = 1
    //     0x1132014: mov             x1, #1
    // 0x1132018: r0 = AllocateContext()
    //     0x1132018: bl              #0x13de838  ; AllocateContextStub
    // 0x113201c: mov             x1, x0
    // 0x1132020: ldr             x0, [fp, #0x10]
    // 0x1132024: StoreField: r1->field_f = r0
    //     0x1132024: stur            w0, [x1, #0xf]
    // 0x1132028: mov             x2, x1
    // 0x113202c: r1 = Function '<anonymous closure>':.
    //     0x113202c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26488] AnonymousClosure: (0xdf2190), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM2
    //     0x1132030: ldr             x1, [x1, #0x488]
    // 0x1132034: r0 = AllocateClosure()
    //     0x1132034: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1132038: r16 = <Color?>
    //     0x1132038: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x113203c: ldr             x16, [x16, #0xa40]
    // 0x1132040: stp             x0, x16, [SP]
    // 0x1132044: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1132044: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1132048: r0 = resolveWith()
    //     0x1132048: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x113204c: ldr             x2, [fp, #0x10]
    // 0x1132050: ldur            x3, [fp, #-8]
    // 0x1132054: ldur            x4, [fp, #-0x18]
    // 0x1132058: mov             x1, x4
    // 0x113205c: ArrayStore: r1[33] = r0  ; List_4
    //     0x113205c: add             x25, x1, #0x93
    //     0x1132060: str             w0, [x25]
    //     0x1132064: tbz             w0, #0, #0x1132080
    //     0x1132068: ldurb           w16, [x1, #-1]
    //     0x113206c: ldurb           w17, [x0, #-1]
    //     0x1132070: and             x16, x17, x16, lsr #2
    //     0x1132074: tst             x16, HEAP, lsr #32
    //     0x1132078: b.eq            #0x1132080
    //     0x113207c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1132080: LoadField: r0 = r2->field_8f
    //     0x1132080: ldur            w0, [x2, #0x8f]
    // 0x1132084: DecompressPointer r0
    //     0x1132084: add             x0, x0, HEAP, lsl #32
    // 0x1132088: StoreField: r4->field_97 = r0
    //     0x1132088: stur            w0, [x4, #0x97]
    // 0x113208c: StoreField: r4->field_9b = rNULL
    //     0x113208c: stur            NULL, [x4, #0x9b]
    // 0x1132090: r17 = 5167
    //     0x1132090: mov             x17, #0x142f
    // 0x1132094: cmp             x3, x17
    // 0x1132098: b.ne            #0x11320ac
    // 0x113209c: LoadField: r0 = r2->field_97
    //     0x113209c: ldur            w0, [x2, #0x97]
    // 0x11320a0: DecompressPointer r0
    //     0x11320a0: add             x0, x0, HEAP, lsl #32
    // 0x11320a4: mov             x2, x3
    // 0x11320a8: b               #0x11320dc
    // 0x11320ac: r17 = 5168
    //     0x11320ac: mov             x17, #0x1430
    // 0x11320b0: cmp             x3, x17
    // 0x11320b4: b.ne            #0x11320cc
    // 0x11320b8: r4 = const [0, 0, 0, 0, null]
    //     0x11320b8: add             x4, PP, #0x1e, lsl #12  ; [pp+0x1eed8] List(5) [0, 0, 0, 0, Null]
    //     0x11320bc: ldr             x4, [x4, #0xed8]
    // 0x11320c0: r0 = styleFrom()
    //     0x11320c0: bl              #0xd16538  ; [package:flutter/src/material/text_button.dart] TextButton::styleFrom
    // 0x11320c4: ldur            x2, [fp, #-8]
    // 0x11320c8: b               #0x11320dc
    // 0x11320cc: r4 = const [0, 0, 0, 0, null]
    //     0x11320cc: add             x4, PP, #0x1e, lsl #12  ; [pp+0x1eed8] List(5) [0, 0, 0, 0, Null]
    //     0x11320d0: ldr             x4, [x4, #0xed8]
    // 0x11320d4: r0 = styleFrom()
    //     0x11320d4: bl              #0xd16538  ; [package:flutter/src/material/text_button.dart] TextButton::styleFrom
    // 0x11320d8: ldur            x2, [fp, #-8]
    // 0x11320dc: ldur            x1, [fp, #-0x18]
    // 0x11320e0: ArrayStore: r1[36] = r0  ; List_4
    //     0x11320e0: add             x25, x1, #0x9f
    //     0x11320e4: str             w0, [x25]
    //     0x11320e8: tbz             w0, #0, #0x1132104
    //     0x11320ec: ldurb           w16, [x1, #-1]
    //     0x11320f0: ldurb           w17, [x0, #-1]
    //     0x11320f4: and             x16, x17, x16, lsr #2
    //     0x11320f8: tst             x16, HEAP, lsr #32
    //     0x11320fc: b.eq            #0x1132104
    //     0x1132100: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1132104: r17 = 5167
    //     0x1132104: mov             x17, #0x142f
    // 0x1132108: cmp             x2, x17
    // 0x113210c: b.ne            #0x1132124
    // 0x1132110: ldr             x1, [fp, #0x10]
    // 0x1132114: LoadField: r0 = r1->field_9b
    //     0x1132114: ldur            w0, [x1, #0x9b]
    // 0x1132118: DecompressPointer r0
    //     0x1132118: add             x0, x0, HEAP, lsl #32
    // 0x113211c: mov             x3, x1
    // 0x1132120: b               #0x1132160
    // 0x1132124: ldr             x1, [fp, #0x10]
    // 0x1132128: r17 = 5168
    //     0x1132128: mov             x17, #0x1430
    // 0x113212c: cmp             x2, x17
    // 0x1132130: b.ne            #0x113214c
    // 0x1132134: r4 = const [0, 0, 0, 0, null]
    //     0x1132134: add             x4, PP, #0x1e, lsl #12  ; [pp+0x1eed8] List(5) [0, 0, 0, 0, Null]
    //     0x1132138: ldr             x4, [x4, #0xed8]
    // 0x113213c: r0 = styleFrom()
    //     0x113213c: bl              #0xd16538  ; [package:flutter/src/material/text_button.dart] TextButton::styleFrom
    // 0x1132140: ldr             x3, [fp, #0x10]
    // 0x1132144: ldur            x2, [fp, #-8]
    // 0x1132148: b               #0x1132160
    // 0x113214c: r4 = const [0, 0, 0, 0, null]
    //     0x113214c: add             x4, PP, #0x1e, lsl #12  ; [pp+0x1eed8] List(5) [0, 0, 0, 0, Null]
    //     0x1132150: ldr             x4, [x4, #0xed8]
    // 0x1132154: r0 = styleFrom()
    //     0x1132154: bl              #0xd16538  ; [package:flutter/src/material/text_button.dart] TextButton::styleFrom
    // 0x1132158: ldr             x3, [fp, #0x10]
    // 0x113215c: ldur            x2, [fp, #-8]
    // 0x1132160: ldur            x4, [fp, #-0x18]
    // 0x1132164: mov             x1, x4
    // 0x1132168: ArrayStore: r1[37] = r0  ; List_4
    //     0x1132168: add             x25, x1, #0xa3
    //     0x113216c: str             w0, [x25]
    //     0x1132170: tbz             w0, #0, #0x113218c
    //     0x1132174: ldurb           w16, [x1, #-1]
    //     0x1132178: ldurb           w17, [x0, #-1]
    //     0x113217c: and             x16, x17, x16, lsr #2
    //     0x1132180: tst             x16, HEAP, lsr #32
    //     0x1132184: b.eq            #0x113218c
    //     0x1132188: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x113218c: LoadField: r0 = r3->field_9f
    //     0x113218c: ldur            w0, [x3, #0x9f]
    // 0x1132190: DecompressPointer r0
    //     0x1132190: add             x0, x0, HEAP, lsl #32
    // 0x1132194: StoreField: r4->field_a7 = r0
    //     0x1132194: stur            w0, [x4, #0xa7]
    // 0x1132198: r17 = 5167
    //     0x1132198: mov             x17, #0x142f
    // 0x113219c: cmp             x2, x17
    // 0x11321a0: b.ne            #0x11321b0
    // 0x11321a4: LoadField: r0 = r3->field_a3
    //     0x11321a4: ldur            w0, [x3, #0xa3]
    // 0x11321a8: DecompressPointer r0
    //     0x11321a8: add             x0, x0, HEAP, lsl #32
    // 0x11321ac: b               #0x11322f8
    // 0x11321b0: r17 = 5168
    //     0x11321b0: mov             x17, #0x1430
    // 0x11321b4: cmp             x2, x17
    // 0x11321b8: b.ne            #0x113225c
    // 0x11321bc: mov             x1, x3
    // 0x11321c0: LoadField: r0 = r1->field_b7
    //     0x11321c0: ldur            w0, [x1, #0xb7]
    // 0x11321c4: DecompressPointer r0
    //     0x11321c4: add             x0, x0, HEAP, lsl #32
    // 0x11321c8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11321cc: cmp             w0, w16
    // 0x11321d0: b.ne            #0x11321e0
    // 0x11321d4: r2 = _textTheme
    //     0x11321d4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26418] Field <_DatePickerDefaultsM3@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0x11321d8: ldr             x2, [x2, #0x418]
    // 0x11321dc: r0 = InitLateFinalInstanceField()
    //     0x11321dc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x11321e0: LoadField: r2 = r0->field_27
    //     0x11321e0: ldur            w2, [x0, #0x27]
    // 0x11321e4: DecompressPointer r2
    //     0x11321e4: add             x2, x2, HEAP, lsl #32
    // 0x11321e8: stur            x2, [fp, #-0x10]
    // 0x11321ec: cmp             w2, NULL
    // 0x11321f0: b.ne            #0x11321fc
    // 0x11321f4: r0 = Null
    //     0x11321f4: mov             x0, NULL
    // 0x11321f8: b               #0x1132254
    // 0x11321fc: ldr             x1, [fp, #0x10]
    // 0x1132200: LoadField: r0 = r1->field_b3
    //     0x1132200: ldur            w0, [x1, #0xb3]
    // 0x1132204: DecompressPointer r0
    //     0x1132204: add             x0, x0, HEAP, lsl #32
    // 0x1132208: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x113220c: cmp             w0, w16
    // 0x1132210: b.ne            #0x1132220
    // 0x1132214: r2 = _colors
    //     0x1132214: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x1132218: ldr             x2, [x2, #0x400]
    // 0x113221c: r0 = InitLateFinalInstanceField()
    //     0x113221c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1132220: LoadField: r1 = r0->field_7f
    //     0x1132220: ldur            w1, [x0, #0x7f]
    // 0x1132224: DecompressPointer r1
    //     0x1132224: add             x1, x1, HEAP, lsl #32
    // 0x1132228: r0 = LoadClassIdInstr(r1)
    //     0x1132228: ldur            x0, [x1, #-1]
    //     0x113222c: ubfx            x0, x0, #0xc, #0x14
    // 0x1132230: d0 = 0.600000
    //     0x1132230: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c88] IMM: double(0.6) from 0x3fe3333333333333
    //     0x1132234: ldr             d0, [x17, #0xc88]
    // 0x1132238: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1132238: sub             lr, x0, #1, lsl #12
    //     0x113223c: ldr             lr, [x21, lr, lsl #3]
    //     0x1132240: blr             lr
    // 0x1132244: ldur            x1, [fp, #-0x10]
    // 0x1132248: mov             x2, x0
    // 0x113224c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x113224c: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x1132250: r0 = apply()
    //     0x1132250: bl              #0x8acf20  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0x1132254: ldur            x2, [fp, #-8]
    // 0x1132258: b               #0x11322f8
    // 0x113225c: ldr             x1, [fp, #0x10]
    // 0x1132260: LoadField: r0 = r1->field_b7
    //     0x1132260: ldur            w0, [x1, #0xb7]
    // 0x1132264: DecompressPointer r0
    //     0x1132264: add             x0, x0, HEAP, lsl #32
    // 0x1132268: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x113226c: cmp             w0, w16
    // 0x1132270: b.ne            #0x1132280
    // 0x1132274: r2 = _textTheme
    //     0x1132274: add             x2, PP, #0x26, lsl #12  ; [pp+0x26420] Field <_DatePickerDefaultsM2@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0x1132278: ldr             x2, [x2, #0x420]
    // 0x113227c: r0 = InitLateFinalInstanceField()
    //     0x113227c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1132280: LoadField: r2 = r0->field_27
    //     0x1132280: ldur            w2, [x0, #0x27]
    // 0x1132284: DecompressPointer r2
    //     0x1132284: add             x2, x2, HEAP, lsl #32
    // 0x1132288: stur            x2, [fp, #-0x10]
    // 0x113228c: cmp             w2, NULL
    // 0x1132290: b.ne            #0x113229c
    // 0x1132294: r0 = Null
    //     0x1132294: mov             x0, NULL
    // 0x1132298: b               #0x11322f4
    // 0x113229c: ldr             x1, [fp, #0x10]
    // 0x11322a0: LoadField: r0 = r1->field_b3
    //     0x11322a0: ldur            w0, [x1, #0xb3]
    // 0x11322a4: DecompressPointer r0
    //     0x11322a4: add             x0, x0, HEAP, lsl #32
    // 0x11322a8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11322ac: cmp             w0, w16
    // 0x11322b0: b.ne            #0x11322c0
    // 0x11322b4: r2 = _colors
    //     0x11322b4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x11322b8: ldr             x2, [x2, #0x410]
    // 0x11322bc: r0 = InitLateFinalInstanceField()
    //     0x11322bc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x11322c0: LoadField: r1 = r0->field_7f
    //     0x11322c0: ldur            w1, [x0, #0x7f]
    // 0x11322c4: DecompressPointer r1
    //     0x11322c4: add             x1, x1, HEAP, lsl #32
    // 0x11322c8: r0 = LoadClassIdInstr(r1)
    //     0x11322c8: ldur            x0, [x1, #-1]
    //     0x11322cc: ubfx            x0, x0, #0xc, #0x14
    // 0x11322d0: d0 = 0.600000
    //     0x11322d0: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c88] IMM: double(0.6) from 0x3fe3333333333333
    //     0x11322d4: ldr             d0, [x17, #0xc88]
    // 0x11322d8: r0 = GDT[cid_x0 + -0x1000]()
    //     0x11322d8: sub             lr, x0, #1, lsl #12
    //     0x11322dc: ldr             lr, [x21, lr, lsl #3]
    //     0x11322e0: blr             lr
    // 0x11322e4: ldur            x1, [fp, #-0x10]
    // 0x11322e8: mov             x2, x0
    // 0x11322ec: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x11322ec: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x11322f0: r0 = apply()
    //     0x11322f0: bl              #0x8acf20  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0x11322f4: ldur            x2, [fp, #-8]
    // 0x11322f8: ldur            x1, [fp, #-0x18]
    // 0x11322fc: ArrayStore: r1[39] = r0  ; List_4
    //     0x11322fc: add             x25, x1, #0xab
    //     0x1132300: str             w0, [x25]
    //     0x1132304: tbz             w0, #0, #0x1132320
    //     0x1132308: ldurb           w16, [x1, #-1]
    //     0x113230c: ldurb           w17, [x0, #-1]
    //     0x1132310: and             x16, x17, x16, lsr #2
    //     0x1132314: tst             x16, HEAP, lsr #32
    //     0x1132318: b.eq            #0x1132320
    //     0x113231c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1132320: r17 = 5167
    //     0x1132320: mov             x17, #0x142f
    // 0x1132324: cmp             x2, x17
    // 0x1132328: b.ne            #0x113233c
    // 0x113232c: ldr             x1, [fp, #0x10]
    // 0x1132330: LoadField: r0 = r1->field_a7
    //     0x1132330: ldur            w0, [x1, #0xa7]
    // 0x1132334: DecompressPointer r0
    //     0x1132334: add             x0, x0, HEAP, lsl #32
    // 0x1132338: b               #0x11323d8
    // 0x113233c: ldr             x1, [fp, #0x10]
    // 0x1132340: r17 = 5168
    //     0x1132340: mov             x17, #0x1430
    // 0x1132344: cmp             x2, x17
    // 0x1132348: b.ne            #0x1132394
    // 0x113234c: LoadField: r0 = r1->field_b3
    //     0x113234c: ldur            w0, [x1, #0xb3]
    // 0x1132350: DecompressPointer r0
    //     0x1132350: add             x0, x0, HEAP, lsl #32
    // 0x1132354: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1132358: cmp             w0, w16
    // 0x113235c: b.ne            #0x113236c
    // 0x1132360: r2 = _colors
    //     0x1132360: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x1132364: ldr             x2, [x2, #0x400]
    // 0x1132368: r0 = InitLateFinalInstanceField()
    //     0x1132368: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x113236c: LoadField: r1 = r0->field_7f
    //     0x113236c: ldur            w1, [x0, #0x7f]
    // 0x1132370: DecompressPointer r1
    //     0x1132370: add             x1, x1, HEAP, lsl #32
    // 0x1132374: r0 = LoadClassIdInstr(r1)
    //     0x1132374: ldur            x0, [x1, #-1]
    //     0x1132378: ubfx            x0, x0, #0xc, #0x14
    // 0x113237c: d0 = 0.600000
    //     0x113237c: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c88] IMM: double(0.6) from 0x3fe3333333333333
    //     0x1132380: ldr             d0, [x17, #0xc88]
    // 0x1132384: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1132384: sub             lr, x0, #1, lsl #12
    //     0x1132388: ldr             lr, [x21, lr, lsl #3]
    //     0x113238c: blr             lr
    // 0x1132390: b               #0x11323d8
    // 0x1132394: LoadField: r0 = r1->field_b3
    //     0x1132394: ldur            w0, [x1, #0xb3]
    // 0x1132398: DecompressPointer r0
    //     0x1132398: add             x0, x0, HEAP, lsl #32
    // 0x113239c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11323a0: cmp             w0, w16
    // 0x11323a4: b.ne            #0x11323b4
    // 0x11323a8: r2 = _colors
    //     0x11323a8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x11323ac: ldr             x2, [x2, #0x410]
    // 0x11323b0: r0 = InitLateFinalInstanceField()
    //     0x11323b0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x11323b4: LoadField: r1 = r0->field_7f
    //     0x11323b4: ldur            w1, [x0, #0x7f]
    // 0x11323b8: DecompressPointer r1
    //     0x11323b8: add             x1, x1, HEAP, lsl #32
    // 0x11323bc: r0 = LoadClassIdInstr(r1)
    //     0x11323bc: ldur            x0, [x1, #-1]
    //     0x11323c0: ubfx            x0, x0, #0xc, #0x14
    // 0x11323c4: d0 = 0.600000
    //     0x11323c4: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c88] IMM: double(0.6) from 0x3fe3333333333333
    //     0x11323c8: ldr             d0, [x17, #0xc88]
    // 0x11323cc: r0 = GDT[cid_x0 + -0x1000]()
    //     0x11323cc: sub             lr, x0, #1, lsl #12
    //     0x11323d0: ldr             lr, [x21, lr, lsl #3]
    //     0x11323d4: blr             lr
    // 0x11323d8: ldur            x2, [fp, #-0x18]
    // 0x11323dc: mov             x1, x2
    // 0x11323e0: ArrayStore: r1[40] = r0  ; List_4
    //     0x11323e0: add             x25, x1, #0xaf
    //     0x11323e4: str             w0, [x25]
    //     0x11323e8: tbz             w0, #0, #0x1132404
    //     0x11323ec: ldurb           w16, [x1, #-1]
    //     0x11323f0: ldurb           w17, [x0, #-1]
    //     0x11323f4: and             x16, x17, x16, lsr #2
    //     0x11323f8: tst             x16, HEAP, lsr #32
    //     0x11323fc: b.eq            #0x1132404
    //     0x1132400: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1132404: r1 = <Object?>
    //     0x1132404: ldr             x1, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0x1132408: r0 = AllocateGrowableArray()
    //     0x1132408: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x113240c: mov             x1, x0
    // 0x1132410: ldur            x0, [fp, #-0x18]
    // 0x1132414: StoreField: r1->field_f = r0
    //     0x1132414: stur            w0, [x1, #0xf]
    // 0x1132418: r0 = 82
    //     0x1132418: mov             x0, #0x52
    // 0x113241c: StoreField: r1->field_b = r0
    //     0x113241c: stur            w0, [x1, #0xb]
    // 0x1132420: r0 = hashAll()
    //     0x1132420: bl              #0x112b348  ; [dart:core] Object::hashAll
    // 0x1132424: mov             x2, x0
    // 0x1132428: r0 = BoxInt64Instr(r2)
    //     0x1132428: sbfiz           x0, x2, #1, #0x1f
    //     0x113242c: cmp             x2, x0, asr #1
    //     0x1132430: b.eq            #0x113243c
    //     0x1132434: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1132438: stur            x2, [x0, #7]
    // 0x113243c: LeaveFrame
    //     0x113243c: mov             SP, fp
    //     0x1132440: ldp             fp, lr, [SP], #0x10
    // 0x1132444: ret
    //     0x1132444: ret             
    // 0x1132448: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1132448: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x113244c: b               #0x1130a34
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x1167b14, size: 0x400
    // 0x1167b14: EnterFrame
    //     0x1167b14: stp             fp, lr, [SP, #-0x10]!
    //     0x1167b18: mov             fp, SP
    // 0x1167b1c: AllocStack(0x98)
    //     0x1167b1c: sub             SP, SP, #0x98
    // 0x1167b20: SetupParameters(dynamic _ /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */, dynamic _ /* d0 => d0, fp-0x70 */)
    //     0x1167b20: mov             x4, x1
    //     0x1167b24: mov             x0, x2
    //     0x1167b28: stur            x1, [fp, #-0x10]
    //     0x1167b2c: stur            x2, [fp, #-0x18]
    //     0x1167b30: stur            d0, [fp, #-0x70]
    // 0x1167b34: CheckStackOverflow
    //     0x1167b34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1167b38: cmp             SP, x16
    //     0x1167b3c: b.ls            #0x1167ee8
    // 0x1167b40: cmp             w4, w0
    // 0x1167b44: b.ne            #0x1167b58
    // 0x1167b48: mov             x0, x4
    // 0x1167b4c: LeaveFrame
    //     0x1167b4c: mov             SP, fp
    //     0x1167b50: ldp             fp, lr, [SP], #0x10
    // 0x1167b54: ret
    //     0x1167b54: ret             
    // 0x1167b58: LoadField: r1 = r4->field_7
    //     0x1167b58: ldur            w1, [x4, #7]
    // 0x1167b5c: DecompressPointer r1
    //     0x1167b5c: add             x1, x1, HEAP, lsl #32
    // 0x1167b60: LoadField: r2 = r0->field_7
    //     0x1167b60: ldur            w2, [x0, #7]
    // 0x1167b64: DecompressPointer r2
    //     0x1167b64: add             x2, x2, HEAP, lsl #32
    // 0x1167b68: r5 = inline_Allocate_Double()
    //     0x1167b68: ldp             x5, x3, [THR, #0x60]  ; THR::top
    //     0x1167b6c: add             x5, x5, #0x10
    //     0x1167b70: cmp             x3, x5
    //     0x1167b74: b.ls            #0x1167ef0
    //     0x1167b78: str             x5, [THR, #0x60]  ; THR::top
    //     0x1167b7c: sub             x5, x5, #0xf
    //     0x1167b80: mov             x3, #0xe19c
    //     0x1167b84: movk            x3, #3, lsl #16
    //     0x1167b88: stur            x3, [x5, #-1]
    // 0x1167b8c: dmb             ishst
    // 0x1167b90: StoreField: r5->field_7 = d0
    //     0x1167b90: stur            d0, [x5, #7]
    // 0x1167b94: mov             x3, x5
    // 0x1167b98: stur            x5, [fp, #-8]
    // 0x1167b9c: r0 = lerp()
    //     0x1167b9c: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1167ba0: mov             x4, x0
    // 0x1167ba4: ldur            x0, [fp, #-0x10]
    // 0x1167ba8: stur            x4, [fp, #-0x20]
    // 0x1167bac: LoadField: r1 = r0->field_b
    //     0x1167bac: ldur            w1, [x0, #0xb]
    // 0x1167bb0: DecompressPointer r1
    //     0x1167bb0: add             x1, x1, HEAP, lsl #32
    // 0x1167bb4: ldur            x5, [fp, #-0x18]
    // 0x1167bb8: LoadField: r2 = r5->field_b
    //     0x1167bb8: ldur            w2, [x5, #0xb]
    // 0x1167bbc: DecompressPointer r2
    //     0x1167bbc: add             x2, x2, HEAP, lsl #32
    // 0x1167bc0: ldur            x3, [fp, #-8]
    // 0x1167bc4: r0 = lerpDouble()
    //     0x1167bc4: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1167bc8: ldur            x3, [fp, #-8]
    // 0x1167bcc: r1 = Null
    //     0x1167bcc: mov             x1, NULL
    // 0x1167bd0: r2 = Null
    //     0x1167bd0: mov             x2, NULL
    // 0x1167bd4: stur            x0, [fp, #-0x28]
    // 0x1167bd8: r0 = lerp()
    //     0x1167bd8: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1167bdc: ldur            x0, [fp, #-0x10]
    // 0x1167be0: LoadField: r1 = r0->field_13
    //     0x1167be0: ldur            w1, [x0, #0x13]
    // 0x1167be4: DecompressPointer r1
    //     0x1167be4: add             x1, x1, HEAP, lsl #32
    // 0x1167be8: ldur            x4, [fp, #-0x18]
    // 0x1167bec: LoadField: r2 = r4->field_13
    //     0x1167bec: ldur            w2, [x4, #0x13]
    // 0x1167bf0: DecompressPointer r2
    //     0x1167bf0: add             x2, x2, HEAP, lsl #32
    // 0x1167bf4: ldur            x3, [fp, #-8]
    // 0x1167bf8: r0 = lerp()
    //     0x1167bf8: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1167bfc: mov             x3, x0
    // 0x1167c00: ldur            x0, [fp, #-0x10]
    // 0x1167c04: stur            x3, [fp, #-0x30]
    // 0x1167c08: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x1167c08: ldur            w1, [x0, #0x17]
    // 0x1167c0c: DecompressPointer r1
    //     0x1167c0c: add             x1, x1, HEAP, lsl #32
    // 0x1167c10: ldur            x4, [fp, #-0x18]
    // 0x1167c14: ArrayLoad: r2 = r4[0]  ; List_4
    //     0x1167c14: ldur            w2, [x4, #0x17]
    // 0x1167c18: DecompressPointer r2
    //     0x1167c18: add             x2, x2, HEAP, lsl #32
    // 0x1167c1c: ldur            d0, [fp, #-0x70]
    // 0x1167c20: r0 = lerp()
    //     0x1167c20: bl              #0x115deb4  ; [package:flutter/src/painting/borders.dart] ShapeBorder::lerp
    // 0x1167c24: ldur            x3, [fp, #-8]
    // 0x1167c28: r1 = Null
    //     0x1167c28: mov             x1, NULL
    // 0x1167c2c: r2 = Null
    //     0x1167c2c: mov             x2, NULL
    // 0x1167c30: stur            x0, [fp, #-0x38]
    // 0x1167c34: r0 = lerp()
    //     0x1167c34: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1167c38: ldur            x0, [fp, #-0x10]
    // 0x1167c3c: LoadField: r1 = r0->field_1f
    //     0x1167c3c: ldur            w1, [x0, #0x1f]
    // 0x1167c40: DecompressPointer r1
    //     0x1167c40: add             x1, x1, HEAP, lsl #32
    // 0x1167c44: ldur            x4, [fp, #-0x18]
    // 0x1167c48: LoadField: r2 = r4->field_1f
    //     0x1167c48: ldur            w2, [x4, #0x1f]
    // 0x1167c4c: DecompressPointer r2
    //     0x1167c4c: add             x2, x2, HEAP, lsl #32
    // 0x1167c50: ldur            x3, [fp, #-8]
    // 0x1167c54: r0 = lerp()
    //     0x1167c54: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1167c58: ldur            x3, [fp, #-8]
    // 0x1167c5c: r1 = Null
    //     0x1167c5c: mov             x1, NULL
    // 0x1167c60: r2 = Null
    //     0x1167c60: mov             x2, NULL
    // 0x1167c64: stur            x0, [fp, #-0x40]
    // 0x1167c68: r0 = lerp()
    //     0x1167c68: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x1167c6c: ldur            x3, [fp, #-8]
    // 0x1167c70: r1 = Null
    //     0x1167c70: mov             x1, NULL
    // 0x1167c74: r2 = Null
    //     0x1167c74: mov             x2, NULL
    // 0x1167c78: r0 = lerp()
    //     0x1167c78: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x1167c7c: ldur            x3, [fp, #-8]
    // 0x1167c80: r1 = Null
    //     0x1167c80: mov             x1, NULL
    // 0x1167c84: r2 = Null
    //     0x1167c84: mov             x2, NULL
    // 0x1167c88: r0 = lerp()
    //     0x1167c88: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x1167c8c: ldur            x3, [fp, #-8]
    // 0x1167c90: r1 = Null
    //     0x1167c90: mov             x1, NULL
    // 0x1167c94: r2 = Null
    //     0x1167c94: mov             x2, NULL
    // 0x1167c98: r0 = lerp()
    //     0x1167c98: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x1167c9c: ldur            x0, [fp, #-0x10]
    // 0x1167ca0: LoadField: r1 = r0->field_3f
    //     0x1167ca0: ldur            w1, [x0, #0x3f]
    // 0x1167ca4: DecompressPointer r1
    //     0x1167ca4: add             x1, x1, HEAP, lsl #32
    // 0x1167ca8: ldur            x2, [fp, #-0x18]
    // 0x1167cac: LoadField: r3 = r2->field_3f
    //     0x1167cac: ldur            w3, [x2, #0x3f]
    // 0x1167cb0: DecompressPointer r3
    //     0x1167cb0: add             x3, x3, HEAP, lsl #32
    // 0x1167cb4: r16 = <OutlinedBorder?>
    //     0x1167cb4: add             x16, PP, #0x7d, lsl #12  ; [pp+0x7d4a8] TypeArguments: <OutlinedBorder?>
    //     0x1167cb8: ldr             x16, [x16, #0x4a8]
    // 0x1167cbc: stp             x1, x16, [SP, #0x18]
    // 0x1167cc0: str             x3, [SP, #0x10]
    // 0x1167cc4: ldur            d0, [fp, #-0x70]
    // 0x1167cc8: str             d0, [SP, #8]
    // 0x1167ccc: r16 = Closure: (OutlinedBorder?, OutlinedBorder?, double) => OutlinedBorder? from Function 'lerp': static.
    //     0x1167ccc: add             x16, PP, #0xad, lsl #12  ; [pp+0xadd18] Closure: (OutlinedBorder?, OutlinedBorder?, double) => OutlinedBorder? from Function 'lerp': static. (0x7f2adb04c118)
    //     0x1167cd0: ldr             x16, [x16, #0xd18]
    // 0x1167cd4: str             x16, [SP]
    // 0x1167cd8: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0x1167cd8: ldr             x4, [PP, #0x560]  ; [pp+0x560] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0x1167cdc: r0 = lerp()
    //     0x1167cdc: bl              #0x1165084  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::lerp
    // 0x1167ce0: ldur            x3, [fp, #-8]
    // 0x1167ce4: r1 = Null
    //     0x1167ce4: mov             x1, NULL
    // 0x1167ce8: r2 = Null
    //     0x1167ce8: mov             x2, NULL
    // 0x1167cec: stur            x0, [fp, #-0x48]
    // 0x1167cf0: r0 = lerp()
    //     0x1167cf0: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x1167cf4: ldur            x0, [fp, #-0x10]
    // 0x1167cf8: LoadField: r1 = r0->field_5f
    //     0x1167cf8: ldur            w1, [x0, #0x5f]
    // 0x1167cfc: DecompressPointer r1
    //     0x1167cfc: add             x1, x1, HEAP, lsl #32
    // 0x1167d00: ldur            x2, [fp, #-0x18]
    // 0x1167d04: LoadField: r3 = r2->field_5f
    //     0x1167d04: ldur            w3, [x2, #0x5f]
    // 0x1167d08: DecompressPointer r3
    //     0x1167d08: add             x3, x3, HEAP, lsl #32
    // 0x1167d0c: r16 = <OutlinedBorder?>
    //     0x1167d0c: add             x16, PP, #0x7d, lsl #12  ; [pp+0x7d4a8] TypeArguments: <OutlinedBorder?>
    //     0x1167d10: ldr             x16, [x16, #0x4a8]
    // 0x1167d14: stp             x1, x16, [SP, #0x18]
    // 0x1167d18: str             x3, [SP, #0x10]
    // 0x1167d1c: ldur            d0, [fp, #-0x70]
    // 0x1167d20: str             d0, [SP, #8]
    // 0x1167d24: r16 = Closure: (OutlinedBorder?, OutlinedBorder?, double) => OutlinedBorder? from Function 'lerp': static.
    //     0x1167d24: add             x16, PP, #0xad, lsl #12  ; [pp+0xadd18] Closure: (OutlinedBorder?, OutlinedBorder?, double) => OutlinedBorder? from Function 'lerp': static. (0x7f2adb04c118)
    //     0x1167d28: ldr             x16, [x16, #0xd18]
    // 0x1167d2c: str             x16, [SP]
    // 0x1167d30: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0x1167d30: ldr             x4, [PP, #0x560]  ; [pp+0x560] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0x1167d34: r0 = lerp()
    //     0x1167d34: bl              #0x1165084  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::lerp
    // 0x1167d38: ldur            x3, [fp, #-8]
    // 0x1167d3c: r1 = Null
    //     0x1167d3c: mov             x1, NULL
    // 0x1167d40: r2 = Null
    //     0x1167d40: mov             x2, NULL
    // 0x1167d44: stur            x0, [fp, #-0x50]
    // 0x1167d48: r0 = lerp()
    //     0x1167d48: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1167d4c: ldur            x0, [fp, #-0x10]
    // 0x1167d50: LoadField: r1 = r0->field_67
    //     0x1167d50: ldur            w1, [x0, #0x67]
    // 0x1167d54: DecompressPointer r1
    //     0x1167d54: add             x1, x1, HEAP, lsl #32
    // 0x1167d58: ldur            x4, [fp, #-0x18]
    // 0x1167d5c: LoadField: r2 = r4->field_67
    //     0x1167d5c: ldur            w2, [x4, #0x67]
    // 0x1167d60: DecompressPointer r2
    //     0x1167d60: add             x2, x2, HEAP, lsl #32
    // 0x1167d64: ldur            x3, [fp, #-8]
    // 0x1167d68: r0 = lerpDouble()
    //     0x1167d68: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1167d6c: ldur            x3, [fp, #-8]
    // 0x1167d70: r1 = Null
    //     0x1167d70: mov             x1, NULL
    // 0x1167d74: r2 = Null
    //     0x1167d74: mov             x2, NULL
    // 0x1167d78: stur            x0, [fp, #-0x58]
    // 0x1167d7c: r0 = lerp()
    //     0x1167d7c: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1167d80: ldur            x3, [fp, #-8]
    // 0x1167d84: r1 = Null
    //     0x1167d84: mov             x1, NULL
    // 0x1167d88: r2 = Null
    //     0x1167d88: mov             x2, NULL
    // 0x1167d8c: r0 = lerp()
    //     0x1167d8c: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1167d90: ldur            x0, [fp, #-0x10]
    // 0x1167d94: LoadField: r1 = r0->field_73
    //     0x1167d94: ldur            w1, [x0, #0x73]
    // 0x1167d98: DecompressPointer r1
    //     0x1167d98: add             x1, x1, HEAP, lsl #32
    // 0x1167d9c: ldur            x3, [fp, #-0x18]
    // 0x1167da0: LoadField: r2 = r3->field_73
    //     0x1167da0: ldur            w2, [x3, #0x73]
    // 0x1167da4: DecompressPointer r2
    //     0x1167da4: add             x2, x2, HEAP, lsl #32
    // 0x1167da8: ldur            d0, [fp, #-0x70]
    // 0x1167dac: r0 = lerp()
    //     0x1167dac: bl              #0x115deb4  ; [package:flutter/src/painting/borders.dart] ShapeBorder::lerp
    // 0x1167db0: ldur            x3, [fp, #-8]
    // 0x1167db4: r1 = Null
    //     0x1167db4: mov             x1, NULL
    // 0x1167db8: r2 = Null
    //     0x1167db8: mov             x2, NULL
    // 0x1167dbc: stur            x0, [fp, #-0x60]
    // 0x1167dc0: r0 = lerp()
    //     0x1167dc0: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1167dc4: ldur            x3, [fp, #-8]
    // 0x1167dc8: r1 = Null
    //     0x1167dc8: mov             x1, NULL
    // 0x1167dcc: r2 = Null
    //     0x1167dcc: mov             x2, NULL
    // 0x1167dd0: r0 = lerp()
    //     0x1167dd0: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1167dd4: ldur            x3, [fp, #-8]
    // 0x1167dd8: r1 = Null
    //     0x1167dd8: mov             x1, NULL
    // 0x1167ddc: r2 = Null
    //     0x1167ddc: mov             x2, NULL
    // 0x1167de0: r0 = lerp()
    //     0x1167de0: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x1167de4: ldur            x3, [fp, #-8]
    // 0x1167de8: r1 = Null
    //     0x1167de8: mov             x1, NULL
    // 0x1167dec: r2 = Null
    //     0x1167dec: mov             x2, NULL
    // 0x1167df0: r0 = lerp()
    //     0x1167df0: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x1167df4: ldur            x3, [fp, #-8]
    // 0x1167df8: r1 = Null
    //     0x1167df8: mov             x1, NULL
    // 0x1167dfc: r2 = Null
    //     0x1167dfc: mov             x2, NULL
    // 0x1167e00: r0 = lerp()
    //     0x1167e00: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1167e04: ldur            x3, [fp, #-8]
    // 0x1167e08: r1 = Null
    //     0x1167e08: mov             x1, NULL
    // 0x1167e0c: r2 = Null
    //     0x1167e0c: mov             x2, NULL
    // 0x1167e10: r0 = lerp()
    //     0x1167e10: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1167e14: ldur            x0, [fp, #-0x10]
    // 0x1167e18: LoadField: r1 = r0->field_97
    //     0x1167e18: ldur            w1, [x0, #0x97]
    // 0x1167e1c: DecompressPointer r1
    //     0x1167e1c: add             x1, x1, HEAP, lsl #32
    // 0x1167e20: ldur            x3, [fp, #-0x18]
    // 0x1167e24: LoadField: r2 = r3->field_97
    //     0x1167e24: ldur            w2, [x3, #0x97]
    // 0x1167e28: DecompressPointer r2
    //     0x1167e28: add             x2, x2, HEAP, lsl #32
    // 0x1167e2c: ldur            d0, [fp, #-0x70]
    // 0x1167e30: r0 = lerp()
    //     0x1167e30: bl              #0x1164644  ; [package:flutter/src/material/button_style.dart] ButtonStyle::lerp
    // 0x1167e34: mov             x3, x0
    // 0x1167e38: ldur            x0, [fp, #-0x10]
    // 0x1167e3c: stur            x3, [fp, #-0x68]
    // 0x1167e40: LoadField: r1 = r0->field_9b
    //     0x1167e40: ldur            w1, [x0, #0x9b]
    // 0x1167e44: DecompressPointer r1
    //     0x1167e44: add             x1, x1, HEAP, lsl #32
    // 0x1167e48: ldur            x0, [fp, #-0x18]
    // 0x1167e4c: LoadField: r2 = r0->field_9b
    //     0x1167e4c: ldur            w2, [x0, #0x9b]
    // 0x1167e50: DecompressPointer r2
    //     0x1167e50: add             x2, x2, HEAP, lsl #32
    // 0x1167e54: ldur            d0, [fp, #-0x70]
    // 0x1167e58: r0 = lerp()
    //     0x1167e58: bl              #0x1164644  ; [package:flutter/src/material/button_style.dart] ButtonStyle::lerp
    // 0x1167e5c: ldur            x3, [fp, #-8]
    // 0x1167e60: r1 = Null
    //     0x1167e60: mov             x1, NULL
    // 0x1167e64: r2 = Null
    //     0x1167e64: mov             x2, NULL
    // 0x1167e68: stur            x0, [fp, #-0x10]
    // 0x1167e6c: r0 = lerp()
    //     0x1167e6c: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x1167e70: ldur            x3, [fp, #-8]
    // 0x1167e74: r1 = Null
    //     0x1167e74: mov             x1, NULL
    // 0x1167e78: r2 = Null
    //     0x1167e78: mov             x2, NULL
    // 0x1167e7c: r0 = lerp()
    //     0x1167e7c: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1167e80: r0 = DatePickerThemeData()
    //     0x1167e80: bl              #0xe82908  ; AllocateDatePickerThemeDataStub -> DatePickerThemeData (size=0xac)
    // 0x1167e84: ldur            x1, [fp, #-0x20]
    // 0x1167e88: StoreField: r0->field_7 = r1
    //     0x1167e88: stur            w1, [x0, #7]
    // 0x1167e8c: ldur            x1, [fp, #-0x28]
    // 0x1167e90: StoreField: r0->field_b = r1
    //     0x1167e90: stur            w1, [x0, #0xb]
    // 0x1167e94: ldur            x1, [fp, #-0x30]
    // 0x1167e98: StoreField: r0->field_13 = r1
    //     0x1167e98: stur            w1, [x0, #0x13]
    // 0x1167e9c: ldur            x1, [fp, #-0x38]
    // 0x1167ea0: ArrayStore: r0[0] = r1  ; List_4
    //     0x1167ea0: stur            w1, [x0, #0x17]
    // 0x1167ea4: ldur            x1, [fp, #-0x40]
    // 0x1167ea8: StoreField: r0->field_1f = r1
    //     0x1167ea8: stur            w1, [x0, #0x1f]
    // 0x1167eac: ldur            x1, [fp, #-0x48]
    // 0x1167eb0: StoreField: r0->field_3f = r1
    //     0x1167eb0: stur            w1, [x0, #0x3f]
    // 0x1167eb4: ldur            x1, [fp, #-0x50]
    // 0x1167eb8: StoreField: r0->field_5f = r1
    //     0x1167eb8: stur            w1, [x0, #0x5f]
    // 0x1167ebc: ldur            x1, [fp, #-0x58]
    // 0x1167ec0: StoreField: r0->field_67 = r1
    //     0x1167ec0: stur            w1, [x0, #0x67]
    // 0x1167ec4: ldur            x1, [fp, #-0x60]
    // 0x1167ec8: StoreField: r0->field_73 = r1
    //     0x1167ec8: stur            w1, [x0, #0x73]
    // 0x1167ecc: ldur            x1, [fp, #-0x68]
    // 0x1167ed0: StoreField: r0->field_97 = r1
    //     0x1167ed0: stur            w1, [x0, #0x97]
    // 0x1167ed4: ldur            x1, [fp, #-0x10]
    // 0x1167ed8: StoreField: r0->field_9b = r1
    //     0x1167ed8: stur            w1, [x0, #0x9b]
    // 0x1167edc: LeaveFrame
    //     0x1167edc: mov             SP, fp
    //     0x1167ee0: ldp             fp, lr, [SP], #0x10
    // 0x1167ee4: ret
    //     0x1167ee4: ret             
    // 0x1167ee8: r0 = StackOverflowSharedWithFPURegs()
    //     0x1167ee8: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1167eec: b               #0x1167b40
    // 0x1167ef0: SaveReg d0
    //     0x1167ef0: str             q0, [SP, #-0x10]!
    // 0x1167ef4: stp             x2, x4, [SP, #-0x10]!
    // 0x1167ef8: stp             x0, x1, [SP, #-0x10]!
    // 0x1167efc: r0 = AllocateDouble()
    //     0x1167efc: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1167f00: mov             x5, x0
    // 0x1167f04: ldp             x0, x1, [SP], #0x10
    // 0x1167f08: ldp             x2, x4, [SP], #0x10
    // 0x1167f0c: RestoreReg d0
    //     0x1167f0c: ldr             q0, [SP], #0x10
    // 0x1167f10: b               #0x1167b90
  }
  _ ==(/* No info */) {
    // ** addr: 0x1267b70, size: 0x2f80
    // 0x1267b70: EnterFrame
    //     0x1267b70: stp             fp, lr, [SP, #-0x10]!
    //     0x1267b74: mov             fp, SP
    // 0x1267b78: AllocStack(0x30)
    //     0x1267b78: sub             SP, SP, #0x30
    // 0x1267b7c: CheckStackOverflow
    //     0x1267b7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1267b80: cmp             SP, x16
    //     0x1267b84: b.ls            #0x126aae8
    // 0x1267b88: ldr             x0, [fp, #0x10]
    // 0x1267b8c: cmp             w0, NULL
    // 0x1267b90: b.ne            #0x1267ba4
    // 0x1267b94: r0 = false
    //     0x1267b94: add             x0, NULL, #0x30  ; false
    // 0x1267b98: LeaveFrame
    //     0x1267b98: mov             SP, fp
    //     0x1267b9c: ldp             fp, lr, [SP], #0x10
    // 0x1267ba0: ret
    //     0x1267ba0: ret             
    // 0x1267ba4: ldr             x2, [fp, #0x18]
    // 0x1267ba8: cmp             w2, w0
    // 0x1267bac: b.ne            #0x1267bc0
    // 0x1267bb0: r0 = true
    //     0x1267bb0: add             x0, NULL, #0x20  ; true
    // 0x1267bb4: LeaveFrame
    //     0x1267bb4: mov             SP, fp
    //     0x1267bb8: ldp             fp, lr, [SP], #0x10
    // 0x1267bbc: ret
    //     0x1267bbc: ret             
    // 0x1267bc0: r3 = 60
    //     0x1267bc0: mov             x3, #0x3c
    // 0x1267bc4: branchIfSmi(r0, 0x1267bd0)
    //     0x1267bc4: tbz             w0, #0, #0x1267bd0
    // 0x1267bc8: r3 = LoadClassIdInstr(r0)
    //     0x1267bc8: ldur            x3, [x0, #-1]
    //     0x1267bcc: ubfx            x3, x3, #0xc, #0x14
    // 0x1267bd0: stur            x3, [fp, #-8]
    // 0x1267bd4: r17 = -5167
    //     0x1267bd4: mov             x17, #-0x142f
    // 0x1267bd8: add             x16, x3, x17
    // 0x1267bdc: cmp             x16, #2
    // 0x1267be0: b.hi            #0x126aad8
    // 0x1267be4: r17 = 5167
    //     0x1267be4: mov             x17, #0x142f
    // 0x1267be8: cmp             x3, x17
    // 0x1267bec: b.eq            #0x1267c54
    // 0x1267bf0: r17 = 5168
    //     0x1267bf0: mov             x17, #0x1430
    // 0x1267bf4: cmp             x3, x17
    // 0x1267bf8: b.ne            #0x1267c50
    // 0x1267bfc: mov             x1, x0
    // 0x1267c00: LoadField: r0 = r1->field_b3
    //     0x1267c00: ldur            w0, [x1, #0xb3]
    // 0x1267c04: DecompressPointer r0
    //     0x1267c04: add             x0, x0, HEAP, lsl #32
    // 0x1267c08: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1267c0c: cmp             w0, w16
    // 0x1267c10: b.ne            #0x1267c20
    // 0x1267c14: r2 = _colors
    //     0x1267c14: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x1267c18: ldr             x2, [x2, #0x400]
    // 0x1267c1c: r0 = InitLateFinalInstanceField()
    //     0x1267c1c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1267c20: LoadField: r1 = r0->field_9b
    //     0x1267c20: ldur            w1, [x0, #0x9b]
    // 0x1267c24: DecompressPointer r1
    //     0x1267c24: add             x1, x1, HEAP, lsl #32
    // 0x1267c28: cmp             w1, NULL
    // 0x1267c2c: b.ne            #0x1267c40
    // 0x1267c30: LoadField: r1 = r0->field_7b
    //     0x1267c30: ldur            w1, [x0, #0x7b]
    // 0x1267c34: DecompressPointer r1
    //     0x1267c34: add             x1, x1, HEAP, lsl #32
    // 0x1267c38: mov             x0, x1
    // 0x1267c3c: b               #0x1267c44
    // 0x1267c40: mov             x0, x1
    // 0x1267c44: mov             x3, x0
    // 0x1267c48: ldr             x0, [fp, #0x10]
    // 0x1267c4c: b               #0x1267c60
    // 0x1267c50: ldr             x0, [fp, #0x10]
    // 0x1267c54: LoadField: r1 = r0->field_7
    //     0x1267c54: ldur            w1, [x0, #7]
    // 0x1267c58: DecompressPointer r1
    //     0x1267c58: add             x1, x1, HEAP, lsl #32
    // 0x1267c5c: mov             x3, x1
    // 0x1267c60: ldr             x2, [fp, #0x18]
    // 0x1267c64: stur            x3, [fp, #-0x18]
    // 0x1267c68: r4 = LoadClassIdInstr(r2)
    //     0x1267c68: ldur            x4, [x2, #-1]
    //     0x1267c6c: ubfx            x4, x4, #0xc, #0x14
    // 0x1267c70: stur            x4, [fp, #-0x10]
    // 0x1267c74: r17 = 5167
    //     0x1267c74: mov             x17, #0x142f
    // 0x1267c78: cmp             x4, x17
    // 0x1267c7c: b.ne            #0x1267c88
    // 0x1267c80: mov             x1, x2
    // 0x1267c84: b               #0x1267cec
    // 0x1267c88: r17 = 5168
    //     0x1267c88: mov             x17, #0x1430
    // 0x1267c8c: cmp             x4, x17
    // 0x1267c90: b.ne            #0x1267ce8
    // 0x1267c94: mov             x1, x2
    // 0x1267c98: LoadField: r0 = r1->field_b3
    //     0x1267c98: ldur            w0, [x1, #0xb3]
    // 0x1267c9c: DecompressPointer r0
    //     0x1267c9c: add             x0, x0, HEAP, lsl #32
    // 0x1267ca0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1267ca4: cmp             w0, w16
    // 0x1267ca8: b.ne            #0x1267cb8
    // 0x1267cac: r2 = _colors
    //     0x1267cac: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x1267cb0: ldr             x2, [x2, #0x400]
    // 0x1267cb4: r0 = InitLateFinalInstanceField()
    //     0x1267cb4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1267cb8: LoadField: r1 = r0->field_9b
    //     0x1267cb8: ldur            w1, [x0, #0x9b]
    // 0x1267cbc: DecompressPointer r1
    //     0x1267cbc: add             x1, x1, HEAP, lsl #32
    // 0x1267cc0: cmp             w1, NULL
    // 0x1267cc4: b.ne            #0x1267cd8
    // 0x1267cc8: LoadField: r1 = r0->field_7b
    //     0x1267cc8: ldur            w1, [x0, #0x7b]
    // 0x1267ccc: DecompressPointer r1
    //     0x1267ccc: add             x1, x1, HEAP, lsl #32
    // 0x1267cd0: mov             x0, x1
    // 0x1267cd4: b               #0x1267cdc
    // 0x1267cd8: mov             x0, x1
    // 0x1267cdc: mov             x2, x0
    // 0x1267ce0: ldr             x1, [fp, #0x18]
    // 0x1267ce4: b               #0x1267cf8
    // 0x1267ce8: ldr             x1, [fp, #0x18]
    // 0x1267cec: LoadField: r0 = r1->field_7
    //     0x1267cec: ldur            w0, [x1, #7]
    // 0x1267cf0: DecompressPointer r0
    //     0x1267cf0: add             x0, x0, HEAP, lsl #32
    // 0x1267cf4: mov             x2, x0
    // 0x1267cf8: ldur            x0, [fp, #-0x18]
    // 0x1267cfc: r3 = LoadClassIdInstr(r0)
    //     0x1267cfc: ldur            x3, [x0, #-1]
    //     0x1267d00: ubfx            x3, x3, #0xc, #0x14
    // 0x1267d04: stp             x2, x0, [SP]
    // 0x1267d08: mov             x0, x3
    // 0x1267d0c: mov             lr, x0
    // 0x1267d10: ldr             lr, [x21, lr, lsl #3]
    // 0x1267d14: blr             lr
    // 0x1267d18: tbnz            w0, #4, #0x126aad8
    // 0x1267d1c: ldr             x1, [fp, #0x18]
    // 0x1267d20: ldr             x2, [fp, #0x10]
    // 0x1267d24: LoadField: r0 = r2->field_b
    //     0x1267d24: ldur            w0, [x2, #0xb]
    // 0x1267d28: DecompressPointer r0
    //     0x1267d28: add             x0, x0, HEAP, lsl #32
    // 0x1267d2c: LoadField: r3 = r1->field_b
    //     0x1267d2c: ldur            w3, [x1, #0xb]
    // 0x1267d30: DecompressPointer r3
    //     0x1267d30: add             x3, x3, HEAP, lsl #32
    // 0x1267d34: r4 = LoadClassIdInstr(r0)
    //     0x1267d34: ldur            x4, [x0, #-1]
    //     0x1267d38: ubfx            x4, x4, #0xc, #0x14
    // 0x1267d3c: stp             x3, x0, [SP]
    // 0x1267d40: mov             x0, x4
    // 0x1267d44: mov             lr, x0
    // 0x1267d48: ldr             lr, [x21, lr, lsl #3]
    // 0x1267d4c: blr             lr
    // 0x1267d50: tbnz            w0, #4, #0x126aad8
    // 0x1267d54: ldur            x1, [fp, #-8]
    // 0x1267d58: r17 = 5167
    //     0x1267d58: mov             x17, #0x142f
    // 0x1267d5c: cmp             x1, x17
    // 0x1267d60: b.eq            #0x1267d80
    // 0x1267d64: r17 = 5168
    //     0x1267d64: mov             x17, #0x1430
    // 0x1267d68: cmp             x1, x17
    // 0x1267d6c: b.ne            #0x1267d80
    // 0x1267d70: ldr             x2, [fp, #0x10]
    // 0x1267d74: r0 = Instance_Color
    //     0x1267d74: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x1267d78: ldr             x0, [x0, #0x810]
    // 0x1267d7c: b               #0x1267d8c
    // 0x1267d80: ldr             x2, [fp, #0x10]
    // 0x1267d84: LoadField: r0 = r2->field_f
    //     0x1267d84: ldur            w0, [x2, #0xf]
    // 0x1267d88: DecompressPointer r0
    //     0x1267d88: add             x0, x0, HEAP, lsl #32
    // 0x1267d8c: ldur            x3, [fp, #-0x10]
    // 0x1267d90: r17 = 5167
    //     0x1267d90: mov             x17, #0x142f
    // 0x1267d94: cmp             x3, x17
    // 0x1267d98: b.eq            #0x1267db8
    // 0x1267d9c: r17 = 5168
    //     0x1267d9c: mov             x17, #0x1430
    // 0x1267da0: cmp             x3, x17
    // 0x1267da4: b.ne            #0x1267db8
    // 0x1267da8: ldr             x4, [fp, #0x18]
    // 0x1267dac: r5 = Instance_Color
    //     0x1267dac: add             x5, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x1267db0: ldr             x5, [x5, #0x810]
    // 0x1267db4: b               #0x1267dc4
    // 0x1267db8: ldr             x4, [fp, #0x18]
    // 0x1267dbc: LoadField: r5 = r4->field_f
    //     0x1267dbc: ldur            w5, [x4, #0xf]
    // 0x1267dc0: DecompressPointer r5
    //     0x1267dc0: add             x5, x5, HEAP, lsl #32
    // 0x1267dc4: r6 = LoadClassIdInstr(r0)
    //     0x1267dc4: ldur            x6, [x0, #-1]
    //     0x1267dc8: ubfx            x6, x6, #0xc, #0x14
    // 0x1267dcc: stp             x5, x0, [SP]
    // 0x1267dd0: mov             x0, x6
    // 0x1267dd4: mov             lr, x0
    // 0x1267dd8: ldr             lr, [x21, lr, lsl #3]
    // 0x1267ddc: blr             lr
    // 0x1267de0: tbnz            w0, #4, #0x126aad8
    // 0x1267de4: ldur            x1, [fp, #-8]
    // 0x1267de8: r17 = 5167
    //     0x1267de8: mov             x17, #0x142f
    // 0x1267dec: cmp             x1, x17
    // 0x1267df0: b.eq            #0x1267e10
    // 0x1267df4: r17 = 5168
    //     0x1267df4: mov             x17, #0x1430
    // 0x1267df8: cmp             x1, x17
    // 0x1267dfc: b.ne            #0x1267e10
    // 0x1267e00: ldr             x2, [fp, #0x10]
    // 0x1267e04: r0 = Instance_Color
    //     0x1267e04: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x1267e08: ldr             x0, [x0, #0x810]
    // 0x1267e0c: b               #0x1267e1c
    // 0x1267e10: ldr             x2, [fp, #0x10]
    // 0x1267e14: LoadField: r0 = r2->field_13
    //     0x1267e14: ldur            w0, [x2, #0x13]
    // 0x1267e18: DecompressPointer r0
    //     0x1267e18: add             x0, x0, HEAP, lsl #32
    // 0x1267e1c: ldur            x3, [fp, #-0x10]
    // 0x1267e20: r17 = 5167
    //     0x1267e20: mov             x17, #0x142f
    // 0x1267e24: cmp             x3, x17
    // 0x1267e28: b.eq            #0x1267e48
    // 0x1267e2c: r17 = 5168
    //     0x1267e2c: mov             x17, #0x1430
    // 0x1267e30: cmp             x3, x17
    // 0x1267e34: b.ne            #0x1267e48
    // 0x1267e38: ldr             x4, [fp, #0x18]
    // 0x1267e3c: r5 = Instance_Color
    //     0x1267e3c: add             x5, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x1267e40: ldr             x5, [x5, #0x810]
    // 0x1267e44: b               #0x1267e54
    // 0x1267e48: ldr             x4, [fp, #0x18]
    // 0x1267e4c: LoadField: r5 = r4->field_13
    //     0x1267e4c: ldur            w5, [x4, #0x13]
    // 0x1267e50: DecompressPointer r5
    //     0x1267e50: add             x5, x5, HEAP, lsl #32
    // 0x1267e54: r6 = LoadClassIdInstr(r0)
    //     0x1267e54: ldur            x6, [x0, #-1]
    //     0x1267e58: ubfx            x6, x6, #0xc, #0x14
    // 0x1267e5c: stp             x5, x0, [SP]
    // 0x1267e60: mov             x0, x6
    // 0x1267e64: mov             lr, x0
    // 0x1267e68: ldr             lr, [x21, lr, lsl #3]
    // 0x1267e6c: blr             lr
    // 0x1267e70: tbnz            w0, #4, #0x126aad8
    // 0x1267e74: ldr             x2, [fp, #0x18]
    // 0x1267e78: ldr             x1, [fp, #0x10]
    // 0x1267e7c: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x1267e7c: ldur            w0, [x1, #0x17]
    // 0x1267e80: DecompressPointer r0
    //     0x1267e80: add             x0, x0, HEAP, lsl #32
    // 0x1267e84: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x1267e84: ldur            w3, [x2, #0x17]
    // 0x1267e88: DecompressPointer r3
    //     0x1267e88: add             x3, x3, HEAP, lsl #32
    // 0x1267e8c: r4 = LoadClassIdInstr(r0)
    //     0x1267e8c: ldur            x4, [x0, #-1]
    //     0x1267e90: ubfx            x4, x4, #0xc, #0x14
    // 0x1267e94: stp             x3, x0, [SP]
    // 0x1267e98: mov             x0, x4
    // 0x1267e9c: mov             lr, x0
    // 0x1267ea0: ldr             lr, [x21, lr, lsl #3]
    // 0x1267ea4: blr             lr
    // 0x1267ea8: tbnz            w0, #4, #0x126aad8
    // 0x1267eac: ldur            x0, [fp, #-8]
    // 0x1267eb0: r17 = 5167
    //     0x1267eb0: mov             x17, #0x142f
    // 0x1267eb4: cmp             x0, x17
    // 0x1267eb8: b.ne            #0x1267ed0
    // 0x1267ebc: ldr             x2, [fp, #0x10]
    // 0x1267ec0: LoadField: r1 = r2->field_1b
    //     0x1267ec0: ldur            w1, [x2, #0x1b]
    // 0x1267ec4: DecompressPointer r1
    //     0x1267ec4: add             x1, x1, HEAP, lsl #32
    // 0x1267ec8: mov             x2, x1
    // 0x1267ecc: b               #0x1267f7c
    // 0x1267ed0: ldr             x2, [fp, #0x10]
    // 0x1267ed4: r17 = 5168
    //     0x1267ed4: mov             x17, #0x1430
    // 0x1267ed8: cmp             x0, x17
    // 0x1267edc: b.ne            #0x1267eec
    // 0x1267ee0: r2 = Instance_Color
    //     0x1267ee0: add             x2, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x1267ee4: ldr             x2, [x2, #0x810]
    // 0x1267ee8: b               #0x1267f7c
    // 0x1267eec: mov             x1, x2
    // 0x1267ef0: LoadField: r0 = r1->field_bb
    //     0x1267ef0: ldur            w0, [x1, #0xbb]
    // 0x1267ef4: DecompressPointer r0
    //     0x1267ef4: add             x0, x0, HEAP, lsl #32
    // 0x1267ef8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1267efc: cmp             w0, w16
    // 0x1267f00: b.ne            #0x1267f10
    // 0x1267f04: r2 = _isDark
    //     0x1267f04: add             x2, PP, #0x26, lsl #12  ; [pp+0x26408] Field <_DatePickerDefaultsM2@738353974._isDark@738353974>: late final (offset: 0xbc)
    //     0x1267f08: ldr             x2, [x2, #0x408]
    // 0x1267f0c: r0 = InitLateFinalInstanceField()
    //     0x1267f0c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1267f10: tbnz            w0, #4, #0x1267f48
    // 0x1267f14: ldr             x1, [fp, #0x10]
    // 0x1267f18: LoadField: r0 = r1->field_b3
    //     0x1267f18: ldur            w0, [x1, #0xb3]
    // 0x1267f1c: DecompressPointer r0
    //     0x1267f1c: add             x0, x0, HEAP, lsl #32
    // 0x1267f20: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1267f24: cmp             w0, w16
    // 0x1267f28: b.ne            #0x1267f38
    // 0x1267f2c: r2 = _colors
    //     0x1267f2c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x1267f30: ldr             x2, [x2, #0x410]
    // 0x1267f34: r0 = InitLateFinalInstanceField()
    //     0x1267f34: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1267f38: LoadField: r1 = r0->field_7b
    //     0x1267f38: ldur            w1, [x0, #0x7b]
    // 0x1267f3c: DecompressPointer r1
    //     0x1267f3c: add             x1, x1, HEAP, lsl #32
    // 0x1267f40: mov             x0, x1
    // 0x1267f44: b               #0x1267f78
    // 0x1267f48: ldr             x1, [fp, #0x10]
    // 0x1267f4c: LoadField: r0 = r1->field_b3
    //     0x1267f4c: ldur            w0, [x1, #0xb3]
    // 0x1267f50: DecompressPointer r0
    //     0x1267f50: add             x0, x0, HEAP, lsl #32
    // 0x1267f54: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1267f58: cmp             w0, w16
    // 0x1267f5c: b.ne            #0x1267f6c
    // 0x1267f60: r2 = _colors
    //     0x1267f60: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x1267f64: ldr             x2, [x2, #0x410]
    // 0x1267f68: r0 = InitLateFinalInstanceField()
    //     0x1267f68: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1267f6c: LoadField: r1 = r0->field_b
    //     0x1267f6c: ldur            w1, [x0, #0xb]
    // 0x1267f70: DecompressPointer r1
    //     0x1267f70: add             x1, x1, HEAP, lsl #32
    // 0x1267f74: mov             x0, x1
    // 0x1267f78: mov             x2, x0
    // 0x1267f7c: ldur            x0, [fp, #-0x10]
    // 0x1267f80: stur            x2, [fp, #-0x18]
    // 0x1267f84: r17 = 5167
    //     0x1267f84: mov             x17, #0x142f
    // 0x1267f88: cmp             x0, x17
    // 0x1267f8c: b.ne            #0x1267fa4
    // 0x1267f90: ldr             x3, [fp, #0x18]
    // 0x1267f94: LoadField: r1 = r3->field_1b
    //     0x1267f94: ldur            w1, [x3, #0x1b]
    // 0x1267f98: DecompressPointer r1
    //     0x1267f98: add             x1, x1, HEAP, lsl #32
    // 0x1267f9c: mov             x0, x2
    // 0x1267fa0: b               #0x1268058
    // 0x1267fa4: ldr             x3, [fp, #0x18]
    // 0x1267fa8: r17 = 5168
    //     0x1267fa8: mov             x17, #0x1430
    // 0x1267fac: cmp             x0, x17
    // 0x1267fb0: b.ne            #0x1267fc4
    // 0x1267fb4: mov             x0, x2
    // 0x1267fb8: r1 = Instance_Color
    //     0x1267fb8: add             x1, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x1267fbc: ldr             x1, [x1, #0x810]
    // 0x1267fc0: b               #0x1268058
    // 0x1267fc4: mov             x1, x3
    // 0x1267fc8: LoadField: r0 = r1->field_bb
    //     0x1267fc8: ldur            w0, [x1, #0xbb]
    // 0x1267fcc: DecompressPointer r0
    //     0x1267fcc: add             x0, x0, HEAP, lsl #32
    // 0x1267fd0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1267fd4: cmp             w0, w16
    // 0x1267fd8: b.ne            #0x1267fe8
    // 0x1267fdc: r2 = _isDark
    //     0x1267fdc: add             x2, PP, #0x26, lsl #12  ; [pp+0x26408] Field <_DatePickerDefaultsM2@738353974._isDark@738353974>: late final (offset: 0xbc)
    //     0x1267fe0: ldr             x2, [x2, #0x408]
    // 0x1267fe4: r0 = InitLateFinalInstanceField()
    //     0x1267fe4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1267fe8: tbnz            w0, #4, #0x1268020
    // 0x1267fec: ldr             x1, [fp, #0x18]
    // 0x1267ff0: LoadField: r0 = r1->field_b3
    //     0x1267ff0: ldur            w0, [x1, #0xb3]
    // 0x1267ff4: DecompressPointer r0
    //     0x1267ff4: add             x0, x0, HEAP, lsl #32
    // 0x1267ff8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1267ffc: cmp             w0, w16
    // 0x1268000: b.ne            #0x1268010
    // 0x1268004: r2 = _colors
    //     0x1268004: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x1268008: ldr             x2, [x2, #0x410]
    // 0x126800c: r0 = InitLateFinalInstanceField()
    //     0x126800c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1268010: LoadField: r1 = r0->field_7b
    //     0x1268010: ldur            w1, [x0, #0x7b]
    // 0x1268014: DecompressPointer r1
    //     0x1268014: add             x1, x1, HEAP, lsl #32
    // 0x1268018: mov             x0, x1
    // 0x126801c: b               #0x1268050
    // 0x1268020: ldr             x1, [fp, #0x18]
    // 0x1268024: LoadField: r0 = r1->field_b3
    //     0x1268024: ldur            w0, [x1, #0xb3]
    // 0x1268028: DecompressPointer r0
    //     0x1268028: add             x0, x0, HEAP, lsl #32
    // 0x126802c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1268030: cmp             w0, w16
    // 0x1268034: b.ne            #0x1268044
    // 0x1268038: r2 = _colors
    //     0x1268038: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x126803c: ldr             x2, [x2, #0x410]
    // 0x1268040: r0 = InitLateFinalInstanceField()
    //     0x1268040: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1268044: LoadField: r1 = r0->field_b
    //     0x1268044: ldur            w1, [x0, #0xb]
    // 0x1268048: DecompressPointer r1
    //     0x1268048: add             x1, x1, HEAP, lsl #32
    // 0x126804c: mov             x0, x1
    // 0x1268050: mov             x1, x0
    // 0x1268054: ldur            x0, [fp, #-0x18]
    // 0x1268058: r2 = LoadClassIdInstr(r0)
    //     0x1268058: ldur            x2, [x0, #-1]
    //     0x126805c: ubfx            x2, x2, #0xc, #0x14
    // 0x1268060: stp             x1, x0, [SP]
    // 0x1268064: mov             x0, x2
    // 0x1268068: mov             lr, x0
    // 0x126806c: ldr             lr, [x21, lr, lsl #3]
    // 0x1268070: blr             lr
    // 0x1268074: tbnz            w0, #4, #0x126aad8
    // 0x1268078: ldur            x0, [fp, #-8]
    // 0x126807c: r17 = 5167
    //     0x126807c: mov             x17, #0x142f
    // 0x1268080: cmp             x0, x17
    // 0x1268084: b.ne            #0x126809c
    // 0x1268088: ldr             x2, [fp, #0x10]
    // 0x126808c: LoadField: r1 = r2->field_1f
    //     0x126808c: ldur            w1, [x2, #0x1f]
    // 0x1268090: DecompressPointer r1
    //     0x1268090: add             x1, x1, HEAP, lsl #32
    // 0x1268094: mov             x2, x1
    // 0x1268098: b               #0x126818c
    // 0x126809c: ldr             x2, [fp, #0x10]
    // 0x12680a0: r17 = 5168
    //     0x12680a0: mov             x17, #0x1430
    // 0x12680a4: cmp             x0, x17
    // 0x12680a8: b.ne            #0x12680fc
    // 0x12680ac: mov             x1, x2
    // 0x12680b0: LoadField: r0 = r1->field_b3
    //     0x12680b0: ldur            w0, [x1, #0xb3]
    // 0x12680b4: DecompressPointer r0
    //     0x12680b4: add             x0, x0, HEAP, lsl #32
    // 0x12680b8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12680bc: cmp             w0, w16
    // 0x12680c0: b.ne            #0x12680d0
    // 0x12680c4: r2 = _colors
    //     0x12680c4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x12680c8: ldr             x2, [x2, #0x400]
    // 0x12680cc: r0 = InitLateFinalInstanceField()
    //     0x12680cc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12680d0: LoadField: r1 = r0->field_a3
    //     0x12680d0: ldur            w1, [x0, #0xa3]
    // 0x12680d4: DecompressPointer r1
    //     0x12680d4: add             x1, x1, HEAP, lsl #32
    // 0x12680d8: cmp             w1, NULL
    // 0x12680dc: b.ne            #0x12680f0
    // 0x12680e0: LoadField: r1 = r0->field_7f
    //     0x12680e0: ldur            w1, [x0, #0x7f]
    // 0x12680e4: DecompressPointer r1
    //     0x12680e4: add             x1, x1, HEAP, lsl #32
    // 0x12680e8: mov             x0, x1
    // 0x12680ec: b               #0x12680f4
    // 0x12680f0: mov             x0, x1
    // 0x12680f4: mov             x2, x0
    // 0x12680f8: b               #0x126818c
    // 0x12680fc: ldr             x1, [fp, #0x10]
    // 0x1268100: LoadField: r0 = r1->field_bb
    //     0x1268100: ldur            w0, [x1, #0xbb]
    // 0x1268104: DecompressPointer r0
    //     0x1268104: add             x0, x0, HEAP, lsl #32
    // 0x1268108: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126810c: cmp             w0, w16
    // 0x1268110: b.ne            #0x1268120
    // 0x1268114: r2 = _isDark
    //     0x1268114: add             x2, PP, #0x26, lsl #12  ; [pp+0x26408] Field <_DatePickerDefaultsM2@738353974._isDark@738353974>: late final (offset: 0xbc)
    //     0x1268118: ldr             x2, [x2, #0x408]
    // 0x126811c: r0 = InitLateFinalInstanceField()
    //     0x126811c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1268120: tbnz            w0, #4, #0x1268158
    // 0x1268124: ldr             x1, [fp, #0x10]
    // 0x1268128: LoadField: r0 = r1->field_b3
    //     0x1268128: ldur            w0, [x1, #0xb3]
    // 0x126812c: DecompressPointer r0
    //     0x126812c: add             x0, x0, HEAP, lsl #32
    // 0x1268130: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1268134: cmp             w0, w16
    // 0x1268138: b.ne            #0x1268148
    // 0x126813c: r2 = _colors
    //     0x126813c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x1268140: ldr             x2, [x2, #0x410]
    // 0x1268144: r0 = InitLateFinalInstanceField()
    //     0x1268144: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1268148: LoadField: r1 = r0->field_7f
    //     0x1268148: ldur            w1, [x0, #0x7f]
    // 0x126814c: DecompressPointer r1
    //     0x126814c: add             x1, x1, HEAP, lsl #32
    // 0x1268150: mov             x0, x1
    // 0x1268154: b               #0x1268188
    // 0x1268158: ldr             x1, [fp, #0x10]
    // 0x126815c: LoadField: r0 = r1->field_b3
    //     0x126815c: ldur            w0, [x1, #0xb3]
    // 0x1268160: DecompressPointer r0
    //     0x1268160: add             x0, x0, HEAP, lsl #32
    // 0x1268164: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1268168: cmp             w0, w16
    // 0x126816c: b.ne            #0x126817c
    // 0x1268170: r2 = _colors
    //     0x1268170: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x1268174: ldr             x2, [x2, #0x410]
    // 0x1268178: r0 = InitLateFinalInstanceField()
    //     0x1268178: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126817c: LoadField: r1 = r0->field_f
    //     0x126817c: ldur            w1, [x0, #0xf]
    // 0x1268180: DecompressPointer r1
    //     0x1268180: add             x1, x1, HEAP, lsl #32
    // 0x1268184: mov             x0, x1
    // 0x1268188: mov             x2, x0
    // 0x126818c: ldur            x0, [fp, #-0x10]
    // 0x1268190: stur            x2, [fp, #-0x18]
    // 0x1268194: r17 = 5167
    //     0x1268194: mov             x17, #0x142f
    // 0x1268198: cmp             x0, x17
    // 0x126819c: b.ne            #0x12681b4
    // 0x12681a0: ldr             x3, [fp, #0x18]
    // 0x12681a4: LoadField: r1 = r3->field_1f
    //     0x12681a4: ldur            w1, [x3, #0x1f]
    // 0x12681a8: DecompressPointer r1
    //     0x12681a8: add             x1, x1, HEAP, lsl #32
    // 0x12681ac: mov             x0, x2
    // 0x12681b0: b               #0x12682ac
    // 0x12681b4: ldr             x3, [fp, #0x18]
    // 0x12681b8: r17 = 5168
    //     0x12681b8: mov             x17, #0x1430
    // 0x12681bc: cmp             x0, x17
    // 0x12681c0: b.ne            #0x1268218
    // 0x12681c4: mov             x1, x3
    // 0x12681c8: LoadField: r0 = r1->field_b3
    //     0x12681c8: ldur            w0, [x1, #0xb3]
    // 0x12681cc: DecompressPointer r0
    //     0x12681cc: add             x0, x0, HEAP, lsl #32
    // 0x12681d0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12681d4: cmp             w0, w16
    // 0x12681d8: b.ne            #0x12681e8
    // 0x12681dc: r2 = _colors
    //     0x12681dc: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x12681e0: ldr             x2, [x2, #0x400]
    // 0x12681e4: r0 = InitLateFinalInstanceField()
    //     0x12681e4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12681e8: LoadField: r1 = r0->field_a3
    //     0x12681e8: ldur            w1, [x0, #0xa3]
    // 0x12681ec: DecompressPointer r1
    //     0x12681ec: add             x1, x1, HEAP, lsl #32
    // 0x12681f0: cmp             w1, NULL
    // 0x12681f4: b.ne            #0x1268208
    // 0x12681f8: LoadField: r1 = r0->field_7f
    //     0x12681f8: ldur            w1, [x0, #0x7f]
    // 0x12681fc: DecompressPointer r1
    //     0x12681fc: add             x1, x1, HEAP, lsl #32
    // 0x1268200: mov             x0, x1
    // 0x1268204: b               #0x126820c
    // 0x1268208: mov             x0, x1
    // 0x126820c: mov             x1, x0
    // 0x1268210: ldur            x0, [fp, #-0x18]
    // 0x1268214: b               #0x12682ac
    // 0x1268218: ldr             x1, [fp, #0x18]
    // 0x126821c: LoadField: r0 = r1->field_bb
    //     0x126821c: ldur            w0, [x1, #0xbb]
    // 0x1268220: DecompressPointer r0
    //     0x1268220: add             x0, x0, HEAP, lsl #32
    // 0x1268224: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1268228: cmp             w0, w16
    // 0x126822c: b.ne            #0x126823c
    // 0x1268230: r2 = _isDark
    //     0x1268230: add             x2, PP, #0x26, lsl #12  ; [pp+0x26408] Field <_DatePickerDefaultsM2@738353974._isDark@738353974>: late final (offset: 0xbc)
    //     0x1268234: ldr             x2, [x2, #0x408]
    // 0x1268238: r0 = InitLateFinalInstanceField()
    //     0x1268238: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126823c: tbnz            w0, #4, #0x1268274
    // 0x1268240: ldr             x1, [fp, #0x18]
    // 0x1268244: LoadField: r0 = r1->field_b3
    //     0x1268244: ldur            w0, [x1, #0xb3]
    // 0x1268248: DecompressPointer r0
    //     0x1268248: add             x0, x0, HEAP, lsl #32
    // 0x126824c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1268250: cmp             w0, w16
    // 0x1268254: b.ne            #0x1268264
    // 0x1268258: r2 = _colors
    //     0x1268258: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x126825c: ldr             x2, [x2, #0x410]
    // 0x1268260: r0 = InitLateFinalInstanceField()
    //     0x1268260: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1268264: LoadField: r1 = r0->field_7f
    //     0x1268264: ldur            w1, [x0, #0x7f]
    // 0x1268268: DecompressPointer r1
    //     0x1268268: add             x1, x1, HEAP, lsl #32
    // 0x126826c: mov             x0, x1
    // 0x1268270: b               #0x12682a4
    // 0x1268274: ldr             x1, [fp, #0x18]
    // 0x1268278: LoadField: r0 = r1->field_b3
    //     0x1268278: ldur            w0, [x1, #0xb3]
    // 0x126827c: DecompressPointer r0
    //     0x126827c: add             x0, x0, HEAP, lsl #32
    // 0x1268280: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1268284: cmp             w0, w16
    // 0x1268288: b.ne            #0x1268298
    // 0x126828c: r2 = _colors
    //     0x126828c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x1268290: ldr             x2, [x2, #0x410]
    // 0x1268294: r0 = InitLateFinalInstanceField()
    //     0x1268294: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1268298: LoadField: r1 = r0->field_f
    //     0x1268298: ldur            w1, [x0, #0xf]
    // 0x126829c: DecompressPointer r1
    //     0x126829c: add             x1, x1, HEAP, lsl #32
    // 0x12682a0: mov             x0, x1
    // 0x12682a4: mov             x1, x0
    // 0x12682a8: ldur            x0, [fp, #-0x18]
    // 0x12682ac: r2 = LoadClassIdInstr(r0)
    //     0x12682ac: ldur            x2, [x0, #-1]
    //     0x12682b0: ubfx            x2, x2, #0xc, #0x14
    // 0x12682b4: stp             x1, x0, [SP]
    // 0x12682b8: mov             x0, x2
    // 0x12682bc: mov             lr, x0
    // 0x12682c0: ldr             lr, [x21, lr, lsl #3]
    // 0x12682c4: blr             lr
    // 0x12682c8: tbnz            w0, #4, #0x126aad8
    // 0x12682cc: ldur            x0, [fp, #-8]
    // 0x12682d0: r17 = 5167
    //     0x12682d0: mov             x17, #0x142f
    // 0x12682d4: cmp             x0, x17
    // 0x12682d8: b.ne            #0x12682f0
    // 0x12682dc: ldr             x2, [fp, #0x10]
    // 0x12682e0: LoadField: r1 = r2->field_23
    //     0x12682e0: ldur            w1, [x2, #0x23]
    // 0x12682e4: DecompressPointer r1
    //     0x12682e4: add             x1, x1, HEAP, lsl #32
    // 0x12682e8: mov             x2, x1
    // 0x12682ec: b               #0x1268364
    // 0x12682f0: ldr             x2, [fp, #0x10]
    // 0x12682f4: r17 = 5168
    //     0x12682f4: mov             x17, #0x1430
    // 0x12682f8: cmp             x0, x17
    // 0x12682fc: b.ne            #0x1268334
    // 0x1268300: mov             x1, x2
    // 0x1268304: LoadField: r0 = r1->field_b7
    //     0x1268304: ldur            w0, [x1, #0xb7]
    // 0x1268308: DecompressPointer r0
    //     0x1268308: add             x0, x0, HEAP, lsl #32
    // 0x126830c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1268310: cmp             w0, w16
    // 0x1268314: b.ne            #0x1268324
    // 0x1268318: r2 = _textTheme
    //     0x1268318: add             x2, PP, #0x26, lsl #12  ; [pp+0x26418] Field <_DatePickerDefaultsM3@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0x126831c: ldr             x2, [x2, #0x418]
    // 0x1268320: r0 = InitLateFinalInstanceField()
    //     0x1268320: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1268324: LoadField: r1 = r0->field_13
    //     0x1268324: ldur            w1, [x0, #0x13]
    // 0x1268328: DecompressPointer r1
    //     0x1268328: add             x1, x1, HEAP, lsl #32
    // 0x126832c: mov             x2, x1
    // 0x1268330: b               #0x1268364
    // 0x1268334: ldr             x1, [fp, #0x10]
    // 0x1268338: LoadField: r0 = r1->field_b7
    //     0x1268338: ldur            w0, [x1, #0xb7]
    // 0x126833c: DecompressPointer r0
    //     0x126833c: add             x0, x0, HEAP, lsl #32
    // 0x1268340: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1268344: cmp             w0, w16
    // 0x1268348: b.ne            #0x1268358
    // 0x126834c: r2 = _textTheme
    //     0x126834c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26420] Field <_DatePickerDefaultsM2@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0x1268350: ldr             x2, [x2, #0x420]
    // 0x1268354: r0 = InitLateFinalInstanceField()
    //     0x1268354: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1268358: LoadField: r1 = r0->field_1b
    //     0x1268358: ldur            w1, [x0, #0x1b]
    // 0x126835c: DecompressPointer r1
    //     0x126835c: add             x1, x1, HEAP, lsl #32
    // 0x1268360: mov             x2, x1
    // 0x1268364: ldur            x0, [fp, #-0x10]
    // 0x1268368: stur            x2, [fp, #-0x18]
    // 0x126836c: r17 = 5167
    //     0x126836c: mov             x17, #0x142f
    // 0x1268370: cmp             x0, x17
    // 0x1268374: b.ne            #0x126838c
    // 0x1268378: ldr             x3, [fp, #0x18]
    // 0x126837c: LoadField: r1 = r3->field_23
    //     0x126837c: ldur            w1, [x3, #0x23]
    // 0x1268380: DecompressPointer r1
    //     0x1268380: add             x1, x1, HEAP, lsl #32
    // 0x1268384: mov             x0, x2
    // 0x1268388: b               #0x1268400
    // 0x126838c: ldr             x3, [fp, #0x18]
    // 0x1268390: r17 = 5168
    //     0x1268390: mov             x17, #0x1430
    // 0x1268394: cmp             x0, x17
    // 0x1268398: b.ne            #0x12683d0
    // 0x126839c: mov             x1, x3
    // 0x12683a0: LoadField: r0 = r1->field_b7
    //     0x12683a0: ldur            w0, [x1, #0xb7]
    // 0x12683a4: DecompressPointer r0
    //     0x12683a4: add             x0, x0, HEAP, lsl #32
    // 0x12683a8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12683ac: cmp             w0, w16
    // 0x12683b0: b.ne            #0x12683c0
    // 0x12683b4: r2 = _textTheme
    //     0x12683b4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26418] Field <_DatePickerDefaultsM3@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0x12683b8: ldr             x2, [x2, #0x418]
    // 0x12683bc: r0 = InitLateFinalInstanceField()
    //     0x12683bc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12683c0: LoadField: r1 = r0->field_13
    //     0x12683c0: ldur            w1, [x0, #0x13]
    // 0x12683c4: DecompressPointer r1
    //     0x12683c4: add             x1, x1, HEAP, lsl #32
    // 0x12683c8: ldur            x0, [fp, #-0x18]
    // 0x12683cc: b               #0x1268400
    // 0x12683d0: ldr             x1, [fp, #0x18]
    // 0x12683d4: LoadField: r0 = r1->field_b7
    //     0x12683d4: ldur            w0, [x1, #0xb7]
    // 0x12683d8: DecompressPointer r0
    //     0x12683d8: add             x0, x0, HEAP, lsl #32
    // 0x12683dc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12683e0: cmp             w0, w16
    // 0x12683e4: b.ne            #0x12683f4
    // 0x12683e8: r2 = _textTheme
    //     0x12683e8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26420] Field <_DatePickerDefaultsM2@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0x12683ec: ldr             x2, [x2, #0x420]
    // 0x12683f0: r0 = InitLateFinalInstanceField()
    //     0x12683f0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12683f4: LoadField: r1 = r0->field_1b
    //     0x12683f4: ldur            w1, [x0, #0x1b]
    // 0x12683f8: DecompressPointer r1
    //     0x12683f8: add             x1, x1, HEAP, lsl #32
    // 0x12683fc: ldur            x0, [fp, #-0x18]
    // 0x1268400: r2 = LoadClassIdInstr(r0)
    //     0x1268400: ldur            x2, [x0, #-1]
    //     0x1268404: ubfx            x2, x2, #0xc, #0x14
    // 0x1268408: stp             x1, x0, [SP]
    // 0x126840c: mov             x0, x2
    // 0x1268410: mov             lr, x0
    // 0x1268414: ldr             lr, [x21, lr, lsl #3]
    // 0x1268418: blr             lr
    // 0x126841c: tbnz            w0, #4, #0x126aad8
    // 0x1268420: ldur            x0, [fp, #-8]
    // 0x1268424: r17 = 5167
    //     0x1268424: mov             x17, #0x142f
    // 0x1268428: cmp             x0, x17
    // 0x126842c: b.ne            #0x1268444
    // 0x1268430: ldr             x2, [fp, #0x10]
    // 0x1268434: LoadField: r1 = r2->field_27
    //     0x1268434: ldur            w1, [x2, #0x27]
    // 0x1268438: DecompressPointer r1
    //     0x1268438: add             x1, x1, HEAP, lsl #32
    // 0x126843c: mov             x2, x1
    // 0x1268440: b               #0x12684b8
    // 0x1268444: ldr             x2, [fp, #0x10]
    // 0x1268448: r17 = 5168
    //     0x1268448: mov             x17, #0x1430
    // 0x126844c: cmp             x0, x17
    // 0x1268450: b.ne            #0x1268488
    // 0x1268454: mov             x1, x2
    // 0x1268458: LoadField: r0 = r1->field_b7
    //     0x1268458: ldur            w0, [x1, #0xb7]
    // 0x126845c: DecompressPointer r0
    //     0x126845c: add             x0, x0, HEAP, lsl #32
    // 0x1268460: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1268464: cmp             w0, w16
    // 0x1268468: b.ne            #0x1268478
    // 0x126846c: r2 = _textTheme
    //     0x126846c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26418] Field <_DatePickerDefaultsM3@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0x1268470: ldr             x2, [x2, #0x418]
    // 0x1268474: r0 = InitLateFinalInstanceField()
    //     0x1268474: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1268478: LoadField: r1 = r0->field_37
    //     0x1268478: ldur            w1, [x0, #0x37]
    // 0x126847c: DecompressPointer r1
    //     0x126847c: add             x1, x1, HEAP, lsl #32
    // 0x1268480: mov             x2, x1
    // 0x1268484: b               #0x12684b8
    // 0x1268488: ldr             x1, [fp, #0x10]
    // 0x126848c: LoadField: r0 = r1->field_b7
    //     0x126848c: ldur            w0, [x1, #0xb7]
    // 0x1268490: DecompressPointer r0
    //     0x1268490: add             x0, x0, HEAP, lsl #32
    // 0x1268494: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1268498: cmp             w0, w16
    // 0x126849c: b.ne            #0x12684ac
    // 0x12684a0: r2 = _textTheme
    //     0x12684a0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26420] Field <_DatePickerDefaultsM2@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0x12684a4: ldr             x2, [x2, #0x420]
    // 0x12684a8: r0 = InitLateFinalInstanceField()
    //     0x12684a8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12684ac: LoadField: r1 = r0->field_3f
    //     0x12684ac: ldur            w1, [x0, #0x3f]
    // 0x12684b0: DecompressPointer r1
    //     0x12684b0: add             x1, x1, HEAP, lsl #32
    // 0x12684b4: mov             x2, x1
    // 0x12684b8: ldur            x0, [fp, #-0x10]
    // 0x12684bc: stur            x2, [fp, #-0x18]
    // 0x12684c0: r17 = 5167
    //     0x12684c0: mov             x17, #0x142f
    // 0x12684c4: cmp             x0, x17
    // 0x12684c8: b.ne            #0x12684e0
    // 0x12684cc: ldr             x3, [fp, #0x18]
    // 0x12684d0: LoadField: r1 = r3->field_27
    //     0x12684d0: ldur            w1, [x3, #0x27]
    // 0x12684d4: DecompressPointer r1
    //     0x12684d4: add             x1, x1, HEAP, lsl #32
    // 0x12684d8: mov             x0, x2
    // 0x12684dc: b               #0x1268554
    // 0x12684e0: ldr             x3, [fp, #0x18]
    // 0x12684e4: r17 = 5168
    //     0x12684e4: mov             x17, #0x1430
    // 0x12684e8: cmp             x0, x17
    // 0x12684ec: b.ne            #0x1268524
    // 0x12684f0: mov             x1, x3
    // 0x12684f4: LoadField: r0 = r1->field_b7
    //     0x12684f4: ldur            w0, [x1, #0xb7]
    // 0x12684f8: DecompressPointer r0
    //     0x12684f8: add             x0, x0, HEAP, lsl #32
    // 0x12684fc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1268500: cmp             w0, w16
    // 0x1268504: b.ne            #0x1268514
    // 0x1268508: r2 = _textTheme
    //     0x1268508: add             x2, PP, #0x26, lsl #12  ; [pp+0x26418] Field <_DatePickerDefaultsM3@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0x126850c: ldr             x2, [x2, #0x418]
    // 0x1268510: r0 = InitLateFinalInstanceField()
    //     0x1268510: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1268514: LoadField: r1 = r0->field_37
    //     0x1268514: ldur            w1, [x0, #0x37]
    // 0x1268518: DecompressPointer r1
    //     0x1268518: add             x1, x1, HEAP, lsl #32
    // 0x126851c: ldur            x0, [fp, #-0x18]
    // 0x1268520: b               #0x1268554
    // 0x1268524: ldr             x1, [fp, #0x18]
    // 0x1268528: LoadField: r0 = r1->field_b7
    //     0x1268528: ldur            w0, [x1, #0xb7]
    // 0x126852c: DecompressPointer r0
    //     0x126852c: add             x0, x0, HEAP, lsl #32
    // 0x1268530: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1268534: cmp             w0, w16
    // 0x1268538: b.ne            #0x1268548
    // 0x126853c: r2 = _textTheme
    //     0x126853c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26420] Field <_DatePickerDefaultsM2@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0x1268540: ldr             x2, [x2, #0x420]
    // 0x1268544: r0 = InitLateFinalInstanceField()
    //     0x1268544: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1268548: LoadField: r1 = r0->field_3f
    //     0x1268548: ldur            w1, [x0, #0x3f]
    // 0x126854c: DecompressPointer r1
    //     0x126854c: add             x1, x1, HEAP, lsl #32
    // 0x1268550: ldur            x0, [fp, #-0x18]
    // 0x1268554: r2 = LoadClassIdInstr(r0)
    //     0x1268554: ldur            x2, [x0, #-1]
    //     0x1268558: ubfx            x2, x2, #0xc, #0x14
    // 0x126855c: stp             x1, x0, [SP]
    // 0x1268560: mov             x0, x2
    // 0x1268564: mov             lr, x0
    // 0x1268568: ldr             lr, [x21, lr, lsl #3]
    // 0x126856c: blr             lr
    // 0x1268570: tbnz            w0, #4, #0x126aad8
    // 0x1268574: ldur            x0, [fp, #-8]
    // 0x1268578: r17 = 5167
    //     0x1268578: mov             x17, #0x142f
    // 0x126857c: cmp             x0, x17
    // 0x1268580: b.ne            #0x1268598
    // 0x1268584: ldr             x2, [fp, #0x10]
    // 0x1268588: LoadField: r1 = r2->field_2b
    //     0x1268588: ldur            w1, [x2, #0x2b]
    // 0x126858c: DecompressPointer r1
    //     0x126858c: add             x1, x1, HEAP, lsl #32
    // 0x1268590: mov             x2, x1
    // 0x1268594: b               #0x12686b4
    // 0x1268598: ldr             x2, [fp, #0x10]
    // 0x126859c: r17 = 5168
    //     0x126859c: mov             x17, #0x1430
    // 0x12685a0: cmp             x0, x17
    // 0x12685a4: b.ne            #0x1268618
    // 0x12685a8: mov             x1, x2
    // 0x12685ac: LoadField: r0 = r1->field_b7
    //     0x12685ac: ldur            w0, [x1, #0xb7]
    // 0x12685b0: DecompressPointer r0
    //     0x12685b0: add             x0, x0, HEAP, lsl #32
    // 0x12685b4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12685b8: cmp             w0, w16
    // 0x12685bc: b.ne            #0x12685cc
    // 0x12685c0: r2 = _textTheme
    //     0x12685c0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26418] Field <_DatePickerDefaultsM3@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0x12685c4: ldr             x2, [x2, #0x418]
    // 0x12685c8: r0 = InitLateFinalInstanceField()
    //     0x12685c8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12685cc: LoadField: r2 = r0->field_2b
    //     0x12685cc: ldur            w2, [x0, #0x2b]
    // 0x12685d0: DecompressPointer r2
    //     0x12685d0: add             x2, x2, HEAP, lsl #32
    // 0x12685d4: ldr             x1, [fp, #0x10]
    // 0x12685d8: stur            x2, [fp, #-0x18]
    // 0x12685dc: LoadField: r0 = r1->field_b3
    //     0x12685dc: ldur            w0, [x1, #0xb3]
    // 0x12685e0: DecompressPointer r0
    //     0x12685e0: add             x0, x0, HEAP, lsl #32
    // 0x12685e4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12685e8: cmp             w0, w16
    // 0x12685ec: b.ne            #0x12685fc
    // 0x12685f0: r2 = _colors
    //     0x12685f0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x12685f4: ldr             x2, [x2, #0x400]
    // 0x12685f8: r0 = InitLateFinalInstanceField()
    //     0x12685f8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12685fc: LoadField: r2 = r0->field_7f
    //     0x12685fc: ldur            w2, [x0, #0x7f]
    // 0x1268600: DecompressPointer r2
    //     0x1268600: add             x2, x2, HEAP, lsl #32
    // 0x1268604: ldur            x1, [fp, #-0x18]
    // 0x1268608: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x1268608: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x126860c: r0 = apply()
    //     0x126860c: bl              #0x8acf20  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0x1268610: mov             x2, x0
    // 0x1268614: b               #0x12686b4
    // 0x1268618: ldr             x1, [fp, #0x10]
    // 0x126861c: LoadField: r0 = r1->field_b7
    //     0x126861c: ldur            w0, [x1, #0xb7]
    // 0x1268620: DecompressPointer r0
    //     0x1268620: add             x0, x0, HEAP, lsl #32
    // 0x1268624: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1268628: cmp             w0, w16
    // 0x126862c: b.ne            #0x126863c
    // 0x1268630: r2 = _textTheme
    //     0x1268630: add             x2, PP, #0x26, lsl #12  ; [pp+0x26420] Field <_DatePickerDefaultsM2@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0x1268634: ldr             x2, [x2, #0x420]
    // 0x1268638: r0 = InitLateFinalInstanceField()
    //     0x1268638: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126863c: LoadField: r2 = r0->field_33
    //     0x126863c: ldur            w2, [x0, #0x33]
    // 0x1268640: DecompressPointer r2
    //     0x1268640: add             x2, x2, HEAP, lsl #32
    // 0x1268644: stur            x2, [fp, #-0x18]
    // 0x1268648: cmp             w2, NULL
    // 0x126864c: b.ne            #0x1268658
    // 0x1268650: r0 = Null
    //     0x1268650: mov             x0, NULL
    // 0x1268654: b               #0x12686b0
    // 0x1268658: ldr             x1, [fp, #0x10]
    // 0x126865c: LoadField: r0 = r1->field_b3
    //     0x126865c: ldur            w0, [x1, #0xb3]
    // 0x1268660: DecompressPointer r0
    //     0x1268660: add             x0, x0, HEAP, lsl #32
    // 0x1268664: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1268668: cmp             w0, w16
    // 0x126866c: b.ne            #0x126867c
    // 0x1268670: r2 = _colors
    //     0x1268670: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x1268674: ldr             x2, [x2, #0x410]
    // 0x1268678: r0 = InitLateFinalInstanceField()
    //     0x1268678: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126867c: LoadField: r1 = r0->field_7f
    //     0x126867c: ldur            w1, [x0, #0x7f]
    // 0x1268680: DecompressPointer r1
    //     0x1268680: add             x1, x1, HEAP, lsl #32
    // 0x1268684: r0 = LoadClassIdInstr(r1)
    //     0x1268684: ldur            x0, [x1, #-1]
    //     0x1268688: ubfx            x0, x0, #0xc, #0x14
    // 0x126868c: d0 = 0.600000
    //     0x126868c: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c88] IMM: double(0.6) from 0x3fe3333333333333
    //     0x1268690: ldr             d0, [x17, #0xc88]
    // 0x1268694: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1268694: sub             lr, x0, #1, lsl #12
    //     0x1268698: ldr             lr, [x21, lr, lsl #3]
    //     0x126869c: blr             lr
    // 0x12686a0: ldur            x1, [fp, #-0x18]
    // 0x12686a4: mov             x2, x0
    // 0x12686a8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x12686a8: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x12686ac: r0 = apply()
    //     0x12686ac: bl              #0x8acf20  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0x12686b0: mov             x2, x0
    // 0x12686b4: ldur            x0, [fp, #-0x10]
    // 0x12686b8: stur            x2, [fp, #-0x18]
    // 0x12686bc: r17 = 5167
    //     0x12686bc: mov             x17, #0x142f
    // 0x12686c0: cmp             x0, x17
    // 0x12686c4: b.ne            #0x12686dc
    // 0x12686c8: ldr             x3, [fp, #0x18]
    // 0x12686cc: LoadField: r1 = r3->field_2b
    //     0x12686cc: ldur            w1, [x3, #0x2b]
    // 0x12686d0: DecompressPointer r1
    //     0x12686d0: add             x1, x1, HEAP, lsl #32
    // 0x12686d4: mov             x0, x2
    // 0x12686d8: b               #0x1268800
    // 0x12686dc: ldr             x3, [fp, #0x18]
    // 0x12686e0: r17 = 5168
    //     0x12686e0: mov             x17, #0x1430
    // 0x12686e4: cmp             x0, x17
    // 0x12686e8: b.ne            #0x1268760
    // 0x12686ec: mov             x1, x3
    // 0x12686f0: LoadField: r0 = r1->field_b7
    //     0x12686f0: ldur            w0, [x1, #0xb7]
    // 0x12686f4: DecompressPointer r0
    //     0x12686f4: add             x0, x0, HEAP, lsl #32
    // 0x12686f8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12686fc: cmp             w0, w16
    // 0x1268700: b.ne            #0x1268710
    // 0x1268704: r2 = _textTheme
    //     0x1268704: add             x2, PP, #0x26, lsl #12  ; [pp+0x26418] Field <_DatePickerDefaultsM3@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0x1268708: ldr             x2, [x2, #0x418]
    // 0x126870c: r0 = InitLateFinalInstanceField()
    //     0x126870c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1268710: LoadField: r2 = r0->field_2b
    //     0x1268710: ldur            w2, [x0, #0x2b]
    // 0x1268714: DecompressPointer r2
    //     0x1268714: add             x2, x2, HEAP, lsl #32
    // 0x1268718: ldr             x1, [fp, #0x18]
    // 0x126871c: stur            x2, [fp, #-0x20]
    // 0x1268720: LoadField: r0 = r1->field_b3
    //     0x1268720: ldur            w0, [x1, #0xb3]
    // 0x1268724: DecompressPointer r0
    //     0x1268724: add             x0, x0, HEAP, lsl #32
    // 0x1268728: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126872c: cmp             w0, w16
    // 0x1268730: b.ne            #0x1268740
    // 0x1268734: r2 = _colors
    //     0x1268734: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x1268738: ldr             x2, [x2, #0x400]
    // 0x126873c: r0 = InitLateFinalInstanceField()
    //     0x126873c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1268740: LoadField: r2 = r0->field_7f
    //     0x1268740: ldur            w2, [x0, #0x7f]
    // 0x1268744: DecompressPointer r2
    //     0x1268744: add             x2, x2, HEAP, lsl #32
    // 0x1268748: ldur            x1, [fp, #-0x20]
    // 0x126874c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x126874c: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x1268750: r0 = apply()
    //     0x1268750: bl              #0x8acf20  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0x1268754: mov             x1, x0
    // 0x1268758: ldur            x0, [fp, #-0x18]
    // 0x126875c: b               #0x1268800
    // 0x1268760: ldr             x1, [fp, #0x18]
    // 0x1268764: LoadField: r0 = r1->field_b7
    //     0x1268764: ldur            w0, [x1, #0xb7]
    // 0x1268768: DecompressPointer r0
    //     0x1268768: add             x0, x0, HEAP, lsl #32
    // 0x126876c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1268770: cmp             w0, w16
    // 0x1268774: b.ne            #0x1268784
    // 0x1268778: r2 = _textTheme
    //     0x1268778: add             x2, PP, #0x26, lsl #12  ; [pp+0x26420] Field <_DatePickerDefaultsM2@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0x126877c: ldr             x2, [x2, #0x420]
    // 0x1268780: r0 = InitLateFinalInstanceField()
    //     0x1268780: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1268784: LoadField: r2 = r0->field_33
    //     0x1268784: ldur            w2, [x0, #0x33]
    // 0x1268788: DecompressPointer r2
    //     0x1268788: add             x2, x2, HEAP, lsl #32
    // 0x126878c: stur            x2, [fp, #-0x20]
    // 0x1268790: cmp             w2, NULL
    // 0x1268794: b.ne            #0x12687a0
    // 0x1268798: r0 = Null
    //     0x1268798: mov             x0, NULL
    // 0x126879c: b               #0x12687f8
    // 0x12687a0: ldr             x1, [fp, #0x18]
    // 0x12687a4: LoadField: r0 = r1->field_b3
    //     0x12687a4: ldur            w0, [x1, #0xb3]
    // 0x12687a8: DecompressPointer r0
    //     0x12687a8: add             x0, x0, HEAP, lsl #32
    // 0x12687ac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12687b0: cmp             w0, w16
    // 0x12687b4: b.ne            #0x12687c4
    // 0x12687b8: r2 = _colors
    //     0x12687b8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x12687bc: ldr             x2, [x2, #0x410]
    // 0x12687c0: r0 = InitLateFinalInstanceField()
    //     0x12687c0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12687c4: LoadField: r1 = r0->field_7f
    //     0x12687c4: ldur            w1, [x0, #0x7f]
    // 0x12687c8: DecompressPointer r1
    //     0x12687c8: add             x1, x1, HEAP, lsl #32
    // 0x12687cc: r0 = LoadClassIdInstr(r1)
    //     0x12687cc: ldur            x0, [x1, #-1]
    //     0x12687d0: ubfx            x0, x0, #0xc, #0x14
    // 0x12687d4: d0 = 0.600000
    //     0x12687d4: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c88] IMM: double(0.6) from 0x3fe3333333333333
    //     0x12687d8: ldr             d0, [x17, #0xc88]
    // 0x12687dc: r0 = GDT[cid_x0 + -0x1000]()
    //     0x12687dc: sub             lr, x0, #1, lsl #12
    //     0x12687e0: ldr             lr, [x21, lr, lsl #3]
    //     0x12687e4: blr             lr
    // 0x12687e8: ldur            x1, [fp, #-0x20]
    // 0x12687ec: mov             x2, x0
    // 0x12687f0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x12687f0: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x12687f4: r0 = apply()
    //     0x12687f4: bl              #0x8acf20  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0x12687f8: mov             x1, x0
    // 0x12687fc: ldur            x0, [fp, #-0x18]
    // 0x1268800: r2 = LoadClassIdInstr(r0)
    //     0x1268800: ldur            x2, [x0, #-1]
    //     0x1268804: ubfx            x2, x2, #0xc, #0x14
    // 0x1268808: stp             x1, x0, [SP]
    // 0x126880c: mov             x0, x2
    // 0x1268810: mov             lr, x0
    // 0x1268814: ldr             lr, [x21, lr, lsl #3]
    // 0x1268818: blr             lr
    // 0x126881c: tbnz            w0, #4, #0x126aad8
    // 0x1268820: ldur            x0, [fp, #-8]
    // 0x1268824: r17 = 5167
    //     0x1268824: mov             x17, #0x142f
    // 0x1268828: cmp             x0, x17
    // 0x126882c: b.ne            #0x1268844
    // 0x1268830: ldr             x2, [fp, #0x10]
    // 0x1268834: LoadField: r1 = r2->field_2f
    //     0x1268834: ldur            w1, [x2, #0x2f]
    // 0x1268838: DecompressPointer r1
    //     0x1268838: add             x1, x1, HEAP, lsl #32
    // 0x126883c: mov             x2, x1
    // 0x1268840: b               #0x12688b8
    // 0x1268844: ldr             x2, [fp, #0x10]
    // 0x1268848: r17 = 5168
    //     0x1268848: mov             x17, #0x1430
    // 0x126884c: cmp             x0, x17
    // 0x1268850: b.ne            #0x1268888
    // 0x1268854: mov             x1, x2
    // 0x1268858: LoadField: r0 = r1->field_b7
    //     0x1268858: ldur            w0, [x1, #0xb7]
    // 0x126885c: DecompressPointer r0
    //     0x126885c: add             x0, x0, HEAP, lsl #32
    // 0x1268860: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1268864: cmp             w0, w16
    // 0x1268868: b.ne            #0x1268878
    // 0x126886c: r2 = _textTheme
    //     0x126886c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26418] Field <_DatePickerDefaultsM3@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0x1268870: ldr             x2, [x2, #0x418]
    // 0x1268874: r0 = InitLateFinalInstanceField()
    //     0x1268874: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1268878: LoadField: r1 = r0->field_2b
    //     0x1268878: ldur            w1, [x0, #0x2b]
    // 0x126887c: DecompressPointer r1
    //     0x126887c: add             x1, x1, HEAP, lsl #32
    // 0x1268880: mov             x2, x1
    // 0x1268884: b               #0x12688b8
    // 0x1268888: ldr             x1, [fp, #0x10]
    // 0x126888c: LoadField: r0 = r1->field_b7
    //     0x126888c: ldur            w0, [x1, #0xb7]
    // 0x1268890: DecompressPointer r0
    //     0x1268890: add             x0, x0, HEAP, lsl #32
    // 0x1268894: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1268898: cmp             w0, w16
    // 0x126889c: b.ne            #0x12688ac
    // 0x12688a0: r2 = _textTheme
    //     0x12688a0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26420] Field <_DatePickerDefaultsM2@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0x12688a4: ldr             x2, [x2, #0x420]
    // 0x12688a8: r0 = InitLateFinalInstanceField()
    //     0x12688a8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12688ac: LoadField: r1 = r0->field_33
    //     0x12688ac: ldur            w1, [x0, #0x33]
    // 0x12688b0: DecompressPointer r1
    //     0x12688b0: add             x1, x1, HEAP, lsl #32
    // 0x12688b4: mov             x2, x1
    // 0x12688b8: ldur            x0, [fp, #-0x10]
    // 0x12688bc: stur            x2, [fp, #-0x18]
    // 0x12688c0: r17 = 5167
    //     0x12688c0: mov             x17, #0x142f
    // 0x12688c4: cmp             x0, x17
    // 0x12688c8: b.ne            #0x12688e0
    // 0x12688cc: ldr             x3, [fp, #0x18]
    // 0x12688d0: LoadField: r1 = r3->field_2f
    //     0x12688d0: ldur            w1, [x3, #0x2f]
    // 0x12688d4: DecompressPointer r1
    //     0x12688d4: add             x1, x1, HEAP, lsl #32
    // 0x12688d8: mov             x0, x2
    // 0x12688dc: b               #0x1268954
    // 0x12688e0: ldr             x3, [fp, #0x18]
    // 0x12688e4: r17 = 5168
    //     0x12688e4: mov             x17, #0x1430
    // 0x12688e8: cmp             x0, x17
    // 0x12688ec: b.ne            #0x1268924
    // 0x12688f0: mov             x1, x3
    // 0x12688f4: LoadField: r0 = r1->field_b7
    //     0x12688f4: ldur            w0, [x1, #0xb7]
    // 0x12688f8: DecompressPointer r0
    //     0x12688f8: add             x0, x0, HEAP, lsl #32
    // 0x12688fc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1268900: cmp             w0, w16
    // 0x1268904: b.ne            #0x1268914
    // 0x1268908: r2 = _textTheme
    //     0x1268908: add             x2, PP, #0x26, lsl #12  ; [pp+0x26418] Field <_DatePickerDefaultsM3@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0x126890c: ldr             x2, [x2, #0x418]
    // 0x1268910: r0 = InitLateFinalInstanceField()
    //     0x1268910: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1268914: LoadField: r1 = r0->field_2b
    //     0x1268914: ldur            w1, [x0, #0x2b]
    // 0x1268918: DecompressPointer r1
    //     0x1268918: add             x1, x1, HEAP, lsl #32
    // 0x126891c: ldur            x0, [fp, #-0x18]
    // 0x1268920: b               #0x1268954
    // 0x1268924: ldr             x1, [fp, #0x18]
    // 0x1268928: LoadField: r0 = r1->field_b7
    //     0x1268928: ldur            w0, [x1, #0xb7]
    // 0x126892c: DecompressPointer r0
    //     0x126892c: add             x0, x0, HEAP, lsl #32
    // 0x1268930: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1268934: cmp             w0, w16
    // 0x1268938: b.ne            #0x1268948
    // 0x126893c: r2 = _textTheme
    //     0x126893c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26420] Field <_DatePickerDefaultsM2@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0x1268940: ldr             x2, [x2, #0x420]
    // 0x1268944: r0 = InitLateFinalInstanceField()
    //     0x1268944: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1268948: LoadField: r1 = r0->field_33
    //     0x1268948: ldur            w1, [x0, #0x33]
    // 0x126894c: DecompressPointer r1
    //     0x126894c: add             x1, x1, HEAP, lsl #32
    // 0x1268950: ldur            x0, [fp, #-0x18]
    // 0x1268954: r2 = LoadClassIdInstr(r0)
    //     0x1268954: ldur            x2, [x0, #-1]
    //     0x1268958: ubfx            x2, x2, #0xc, #0x14
    // 0x126895c: stp             x1, x0, [SP]
    // 0x1268960: mov             x0, x2
    // 0x1268964: mov             lr, x0
    // 0x1268968: ldr             lr, [x21, lr, lsl #3]
    // 0x126896c: blr             lr
    // 0x1268970: tbnz            w0, #4, #0x126aad8
    // 0x1268974: ldur            x0, [fp, #-8]
    // 0x1268978: r17 = 5167
    //     0x1268978: mov             x17, #0x142f
    // 0x126897c: cmp             x0, x17
    // 0x1268980: b.ne            #0x1268998
    // 0x1268984: ldr             x1, [fp, #0x10]
    // 0x1268988: LoadField: r2 = r1->field_33
    //     0x1268988: ldur            w2, [x1, #0x33]
    // 0x126898c: DecompressPointer r2
    //     0x126898c: add             x2, x2, HEAP, lsl #32
    // 0x1268990: mov             x1, x2
    // 0x1268994: b               #0x1268a24
    // 0x1268998: ldr             x1, [fp, #0x10]
    // 0x126899c: r17 = 5168
    //     0x126899c: mov             x17, #0x1430
    // 0x12689a0: cmp             x0, x17
    // 0x12689a4: b.ne            #0x12689e8
    // 0x12689a8: r1 = 1
    //     0x12689a8: mov             x1, #1
    // 0x12689ac: r0 = AllocateContext()
    //     0x12689ac: bl              #0x13de838  ; AllocateContextStub
    // 0x12689b0: mov             x1, x0
    // 0x12689b4: ldr             x0, [fp, #0x10]
    // 0x12689b8: StoreField: r1->field_f = r0
    //     0x12689b8: stur            w0, [x1, #0xf]
    // 0x12689bc: mov             x2, x1
    // 0x12689c0: r1 = Function '<anonymous closure>':.
    //     0x12689c0: add             x1, PP, #0x26, lsl #12  ; [pp+0x26428] AnonymousClosure: (0xdf2fac), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM3
    //     0x12689c4: ldr             x1, [x1, #0x428]
    // 0x12689c8: r0 = AllocateClosure()
    //     0x12689c8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x12689cc: r16 = <Color?>
    //     0x12689cc: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x12689d0: ldr             x16, [x16, #0xa40]
    // 0x12689d4: stp             x0, x16, [SP]
    // 0x12689d8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x12689d8: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x12689dc: r0 = resolveWith()
    //     0x12689dc: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x12689e0: mov             x1, x0
    // 0x12689e4: b               #0x1268a24
    // 0x12689e8: r1 = 1
    //     0x12689e8: mov             x1, #1
    // 0x12689ec: r0 = AllocateContext()
    //     0x12689ec: bl              #0x13de838  ; AllocateContextStub
    // 0x12689f0: mov             x1, x0
    // 0x12689f4: ldr             x0, [fp, #0x10]
    // 0x12689f8: StoreField: r1->field_f = r0
    //     0x12689f8: stur            w0, [x1, #0xf]
    // 0x12689fc: mov             x2, x1
    // 0x1268a00: r1 = Function '<anonymous closure>':.
    //     0x1268a00: add             x1, PP, #0x26, lsl #12  ; [pp+0x26430] AnonymousClosure: (0xdf2e38), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM2
    //     0x1268a04: ldr             x1, [x1, #0x430]
    // 0x1268a08: r0 = AllocateClosure()
    //     0x1268a08: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1268a0c: r16 = <Color?>
    //     0x1268a0c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1268a10: ldr             x16, [x16, #0xa40]
    // 0x1268a14: stp             x0, x16, [SP]
    // 0x1268a18: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1268a18: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1268a1c: r0 = resolveWith()
    //     0x1268a1c: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1268a20: mov             x1, x0
    // 0x1268a24: ldur            x0, [fp, #-0x10]
    // 0x1268a28: stur            x1, [fp, #-0x18]
    // 0x1268a2c: r17 = 5167
    //     0x1268a2c: mov             x17, #0x142f
    // 0x1268a30: cmp             x0, x17
    // 0x1268a34: b.ne            #0x1268a50
    // 0x1268a38: ldr             x2, [fp, #0x18]
    // 0x1268a3c: LoadField: r3 = r2->field_33
    //     0x1268a3c: ldur            w3, [x2, #0x33]
    // 0x1268a40: DecompressPointer r3
    //     0x1268a40: add             x3, x3, HEAP, lsl #32
    // 0x1268a44: mov             x0, x1
    // 0x1268a48: mov             x1, x3
    // 0x1268a4c: b               #0x1268ae8
    // 0x1268a50: ldr             x2, [fp, #0x18]
    // 0x1268a54: r17 = 5168
    //     0x1268a54: mov             x17, #0x1430
    // 0x1268a58: cmp             x0, x17
    // 0x1268a5c: b.ne            #0x1268aa4
    // 0x1268a60: r1 = 1
    //     0x1268a60: mov             x1, #1
    // 0x1268a64: r0 = AllocateContext()
    //     0x1268a64: bl              #0x13de838  ; AllocateContextStub
    // 0x1268a68: mov             x1, x0
    // 0x1268a6c: ldr             x0, [fp, #0x18]
    // 0x1268a70: StoreField: r1->field_f = r0
    //     0x1268a70: stur            w0, [x1, #0xf]
    // 0x1268a74: mov             x2, x1
    // 0x1268a78: r1 = Function '<anonymous closure>':.
    //     0x1268a78: add             x1, PP, #0x26, lsl #12  ; [pp+0x26428] AnonymousClosure: (0xdf2fac), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM3
    //     0x1268a7c: ldr             x1, [x1, #0x428]
    // 0x1268a80: r0 = AllocateClosure()
    //     0x1268a80: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1268a84: r16 = <Color?>
    //     0x1268a84: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1268a88: ldr             x16, [x16, #0xa40]
    // 0x1268a8c: stp             x0, x16, [SP]
    // 0x1268a90: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1268a90: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1268a94: r0 = resolveWith()
    //     0x1268a94: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1268a98: mov             x1, x0
    // 0x1268a9c: ldur            x0, [fp, #-0x18]
    // 0x1268aa0: b               #0x1268ae8
    // 0x1268aa4: mov             x1, x2
    // 0x1268aa8: r1 = 1
    //     0x1268aa8: mov             x1, #1
    // 0x1268aac: r0 = AllocateContext()
    //     0x1268aac: bl              #0x13de838  ; AllocateContextStub
    // 0x1268ab0: mov             x1, x0
    // 0x1268ab4: ldr             x0, [fp, #0x18]
    // 0x1268ab8: StoreField: r1->field_f = r0
    //     0x1268ab8: stur            w0, [x1, #0xf]
    // 0x1268abc: mov             x2, x1
    // 0x1268ac0: r1 = Function '<anonymous closure>':.
    //     0x1268ac0: add             x1, PP, #0x26, lsl #12  ; [pp+0x26430] AnonymousClosure: (0xdf2e38), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM2
    //     0x1268ac4: ldr             x1, [x1, #0x430]
    // 0x1268ac8: r0 = AllocateClosure()
    //     0x1268ac8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1268acc: r16 = <Color?>
    //     0x1268acc: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1268ad0: ldr             x16, [x16, #0xa40]
    // 0x1268ad4: stp             x0, x16, [SP]
    // 0x1268ad8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1268ad8: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1268adc: r0 = resolveWith()
    //     0x1268adc: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1268ae0: mov             x1, x0
    // 0x1268ae4: ldur            x0, [fp, #-0x18]
    // 0x1268ae8: cmp             w0, w1
    // 0x1268aec: b.ne            #0x126aad8
    // 0x1268af0: ldur            x0, [fp, #-8]
    // 0x1268af4: r17 = 5167
    //     0x1268af4: mov             x17, #0x142f
    // 0x1268af8: cmp             x0, x17
    // 0x1268afc: b.ne            #0x1268b14
    // 0x1268b00: ldr             x1, [fp, #0x10]
    // 0x1268b04: LoadField: r2 = r1->field_37
    //     0x1268b04: ldur            w2, [x1, #0x37]
    // 0x1268b08: DecompressPointer r2
    //     0x1268b08: add             x2, x2, HEAP, lsl #32
    // 0x1268b0c: mov             x1, x2
    // 0x1268b10: b               #0x1268ba0
    // 0x1268b14: ldr             x1, [fp, #0x10]
    // 0x1268b18: r17 = 5168
    //     0x1268b18: mov             x17, #0x1430
    // 0x1268b1c: cmp             x0, x17
    // 0x1268b20: b.ne            #0x1268b64
    // 0x1268b24: r1 = 1
    //     0x1268b24: mov             x1, #1
    // 0x1268b28: r0 = AllocateContext()
    //     0x1268b28: bl              #0x13de838  ; AllocateContextStub
    // 0x1268b2c: mov             x1, x0
    // 0x1268b30: ldr             x0, [fp, #0x10]
    // 0x1268b34: StoreField: r1->field_f = r0
    //     0x1268b34: stur            w0, [x1, #0xf]
    // 0x1268b38: mov             x2, x1
    // 0x1268b3c: r1 = Function '<anonymous closure>':.
    //     0x1268b3c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26438] AnonymousClosure: (0xdf2bac), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM3
    //     0x1268b40: ldr             x1, [x1, #0x438]
    // 0x1268b44: r0 = AllocateClosure()
    //     0x1268b44: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1268b48: r16 = <Color?>
    //     0x1268b48: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1268b4c: ldr             x16, [x16, #0xa40]
    // 0x1268b50: stp             x0, x16, [SP]
    // 0x1268b54: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1268b54: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1268b58: r0 = resolveWith()
    //     0x1268b58: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1268b5c: mov             x1, x0
    // 0x1268b60: b               #0x1268ba0
    // 0x1268b64: r1 = 1
    //     0x1268b64: mov             x1, #1
    // 0x1268b68: r0 = AllocateContext()
    //     0x1268b68: bl              #0x13de838  ; AllocateContextStub
    // 0x1268b6c: mov             x1, x0
    // 0x1268b70: ldr             x0, [fp, #0x10]
    // 0x1268b74: StoreField: r1->field_f = r0
    //     0x1268b74: stur            w0, [x1, #0xf]
    // 0x1268b78: mov             x2, x1
    // 0x1268b7c: r1 = Function '<anonymous closure>':.
    //     0x1268b7c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26440] AnonymousClosure: (0xdf2afc), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM2
    //     0x1268b80: ldr             x1, [x1, #0x440]
    // 0x1268b84: r0 = AllocateClosure()
    //     0x1268b84: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1268b88: r16 = <Color?>
    //     0x1268b88: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1268b8c: ldr             x16, [x16, #0xa40]
    // 0x1268b90: stp             x0, x16, [SP]
    // 0x1268b94: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1268b94: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1268b98: r0 = resolveWith()
    //     0x1268b98: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1268b9c: mov             x1, x0
    // 0x1268ba0: ldur            x0, [fp, #-0x10]
    // 0x1268ba4: stur            x1, [fp, #-0x18]
    // 0x1268ba8: r17 = 5167
    //     0x1268ba8: mov             x17, #0x142f
    // 0x1268bac: cmp             x0, x17
    // 0x1268bb0: b.ne            #0x1268bcc
    // 0x1268bb4: ldr             x2, [fp, #0x18]
    // 0x1268bb8: LoadField: r3 = r2->field_37
    //     0x1268bb8: ldur            w3, [x2, #0x37]
    // 0x1268bbc: DecompressPointer r3
    //     0x1268bbc: add             x3, x3, HEAP, lsl #32
    // 0x1268bc0: mov             x0, x1
    // 0x1268bc4: mov             x1, x3
    // 0x1268bc8: b               #0x1268c64
    // 0x1268bcc: ldr             x2, [fp, #0x18]
    // 0x1268bd0: r17 = 5168
    //     0x1268bd0: mov             x17, #0x1430
    // 0x1268bd4: cmp             x0, x17
    // 0x1268bd8: b.ne            #0x1268c20
    // 0x1268bdc: r1 = 1
    //     0x1268bdc: mov             x1, #1
    // 0x1268be0: r0 = AllocateContext()
    //     0x1268be0: bl              #0x13de838  ; AllocateContextStub
    // 0x1268be4: mov             x1, x0
    // 0x1268be8: ldr             x0, [fp, #0x18]
    // 0x1268bec: StoreField: r1->field_f = r0
    //     0x1268bec: stur            w0, [x1, #0xf]
    // 0x1268bf0: mov             x2, x1
    // 0x1268bf4: r1 = Function '<anonymous closure>':.
    //     0x1268bf4: add             x1, PP, #0x26, lsl #12  ; [pp+0x26438] AnonymousClosure: (0xdf2bac), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM3
    //     0x1268bf8: ldr             x1, [x1, #0x438]
    // 0x1268bfc: r0 = AllocateClosure()
    //     0x1268bfc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1268c00: r16 = <Color?>
    //     0x1268c00: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1268c04: ldr             x16, [x16, #0xa40]
    // 0x1268c08: stp             x0, x16, [SP]
    // 0x1268c0c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1268c0c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1268c10: r0 = resolveWith()
    //     0x1268c10: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1268c14: mov             x1, x0
    // 0x1268c18: ldur            x0, [fp, #-0x18]
    // 0x1268c1c: b               #0x1268c64
    // 0x1268c20: mov             x1, x2
    // 0x1268c24: r1 = 1
    //     0x1268c24: mov             x1, #1
    // 0x1268c28: r0 = AllocateContext()
    //     0x1268c28: bl              #0x13de838  ; AllocateContextStub
    // 0x1268c2c: mov             x1, x0
    // 0x1268c30: ldr             x0, [fp, #0x18]
    // 0x1268c34: StoreField: r1->field_f = r0
    //     0x1268c34: stur            w0, [x1, #0xf]
    // 0x1268c38: mov             x2, x1
    // 0x1268c3c: r1 = Function '<anonymous closure>':.
    //     0x1268c3c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26440] AnonymousClosure: (0xdf2afc), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM2
    //     0x1268c40: ldr             x1, [x1, #0x440]
    // 0x1268c44: r0 = AllocateClosure()
    //     0x1268c44: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1268c48: r16 = <Color?>
    //     0x1268c48: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1268c4c: ldr             x16, [x16, #0xa40]
    // 0x1268c50: stp             x0, x16, [SP]
    // 0x1268c54: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1268c54: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1268c58: r0 = resolveWith()
    //     0x1268c58: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1268c5c: mov             x1, x0
    // 0x1268c60: ldur            x0, [fp, #-0x18]
    // 0x1268c64: cmp             w0, w1
    // 0x1268c68: b.ne            #0x126aad8
    // 0x1268c6c: ldur            x0, [fp, #-8]
    // 0x1268c70: r17 = 5167
    //     0x1268c70: mov             x17, #0x142f
    // 0x1268c74: cmp             x0, x17
    // 0x1268c78: b.ne            #0x1268c90
    // 0x1268c7c: ldr             x1, [fp, #0x10]
    // 0x1268c80: LoadField: r2 = r1->field_3b
    //     0x1268c80: ldur            w2, [x1, #0x3b]
    // 0x1268c84: DecompressPointer r2
    //     0x1268c84: add             x2, x2, HEAP, lsl #32
    // 0x1268c88: mov             x1, x2
    // 0x1268c8c: b               #0x1268d1c
    // 0x1268c90: ldr             x1, [fp, #0x10]
    // 0x1268c94: r17 = 5168
    //     0x1268c94: mov             x17, #0x1430
    // 0x1268c98: cmp             x0, x17
    // 0x1268c9c: b.ne            #0x1268ce0
    // 0x1268ca0: r1 = 1
    //     0x1268ca0: mov             x1, #1
    // 0x1268ca4: r0 = AllocateContext()
    //     0x1268ca4: bl              #0x13de838  ; AllocateContextStub
    // 0x1268ca8: mov             x1, x0
    // 0x1268cac: ldr             x0, [fp, #0x10]
    // 0x1268cb0: StoreField: r1->field_f = r0
    //     0x1268cb0: stur            w0, [x1, #0xf]
    // 0x1268cb4: mov             x2, x1
    // 0x1268cb8: r1 = Function '<anonymous closure>':.
    //     0x1268cb8: add             x1, PP, #0x26, lsl #12  ; [pp+0x26448] AnonymousClosure: (0xdf2558), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM3
    //     0x1268cbc: ldr             x1, [x1, #0x448]
    // 0x1268cc0: r0 = AllocateClosure()
    //     0x1268cc0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1268cc4: r16 = <Color?>
    //     0x1268cc4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1268cc8: ldr             x16, [x16, #0xa40]
    // 0x1268ccc: stp             x0, x16, [SP]
    // 0x1268cd0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1268cd0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1268cd4: r0 = resolveWith()
    //     0x1268cd4: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1268cd8: mov             x1, x0
    // 0x1268cdc: b               #0x1268d1c
    // 0x1268ce0: r1 = 1
    //     0x1268ce0: mov             x1, #1
    // 0x1268ce4: r0 = AllocateContext()
    //     0x1268ce4: bl              #0x13de838  ; AllocateContextStub
    // 0x1268ce8: mov             x1, x0
    // 0x1268cec: ldr             x0, [fp, #0x10]
    // 0x1268cf0: StoreField: r1->field_f = r0
    //     0x1268cf0: stur            w0, [x1, #0xf]
    // 0x1268cf4: mov             x2, x1
    // 0x1268cf8: r1 = Function '<anonymous closure>':.
    //     0x1268cf8: add             x1, PP, #0x26, lsl #12  ; [pp+0x26450] AnonymousClosure: (0xdf2190), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM2
    //     0x1268cfc: ldr             x1, [x1, #0x450]
    // 0x1268d00: r0 = AllocateClosure()
    //     0x1268d00: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1268d04: r16 = <Color?>
    //     0x1268d04: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1268d08: ldr             x16, [x16, #0xa40]
    // 0x1268d0c: stp             x0, x16, [SP]
    // 0x1268d10: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1268d10: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1268d14: r0 = resolveWith()
    //     0x1268d14: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1268d18: mov             x1, x0
    // 0x1268d1c: ldur            x0, [fp, #-0x10]
    // 0x1268d20: stur            x1, [fp, #-0x18]
    // 0x1268d24: r17 = 5167
    //     0x1268d24: mov             x17, #0x142f
    // 0x1268d28: cmp             x0, x17
    // 0x1268d2c: b.ne            #0x1268d48
    // 0x1268d30: ldr             x2, [fp, #0x18]
    // 0x1268d34: LoadField: r3 = r2->field_3b
    //     0x1268d34: ldur            w3, [x2, #0x3b]
    // 0x1268d38: DecompressPointer r3
    //     0x1268d38: add             x3, x3, HEAP, lsl #32
    // 0x1268d3c: mov             x0, x1
    // 0x1268d40: mov             x1, x3
    // 0x1268d44: b               #0x1268de0
    // 0x1268d48: ldr             x2, [fp, #0x18]
    // 0x1268d4c: r17 = 5168
    //     0x1268d4c: mov             x17, #0x1430
    // 0x1268d50: cmp             x0, x17
    // 0x1268d54: b.ne            #0x1268d9c
    // 0x1268d58: r1 = 1
    //     0x1268d58: mov             x1, #1
    // 0x1268d5c: r0 = AllocateContext()
    //     0x1268d5c: bl              #0x13de838  ; AllocateContextStub
    // 0x1268d60: mov             x1, x0
    // 0x1268d64: ldr             x0, [fp, #0x18]
    // 0x1268d68: StoreField: r1->field_f = r0
    //     0x1268d68: stur            w0, [x1, #0xf]
    // 0x1268d6c: mov             x2, x1
    // 0x1268d70: r1 = Function '<anonymous closure>':.
    //     0x1268d70: add             x1, PP, #0x26, lsl #12  ; [pp+0x26448] AnonymousClosure: (0xdf2558), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM3
    //     0x1268d74: ldr             x1, [x1, #0x448]
    // 0x1268d78: r0 = AllocateClosure()
    //     0x1268d78: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1268d7c: r16 = <Color?>
    //     0x1268d7c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1268d80: ldr             x16, [x16, #0xa40]
    // 0x1268d84: stp             x0, x16, [SP]
    // 0x1268d88: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1268d88: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1268d8c: r0 = resolveWith()
    //     0x1268d8c: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1268d90: mov             x1, x0
    // 0x1268d94: ldur            x0, [fp, #-0x18]
    // 0x1268d98: b               #0x1268de0
    // 0x1268d9c: mov             x1, x2
    // 0x1268da0: r1 = 1
    //     0x1268da0: mov             x1, #1
    // 0x1268da4: r0 = AllocateContext()
    //     0x1268da4: bl              #0x13de838  ; AllocateContextStub
    // 0x1268da8: mov             x1, x0
    // 0x1268dac: ldr             x0, [fp, #0x18]
    // 0x1268db0: StoreField: r1->field_f = r0
    //     0x1268db0: stur            w0, [x1, #0xf]
    // 0x1268db4: mov             x2, x1
    // 0x1268db8: r1 = Function '<anonymous closure>':.
    //     0x1268db8: add             x1, PP, #0x26, lsl #12  ; [pp+0x26450] AnonymousClosure: (0xdf2190), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM2
    //     0x1268dbc: ldr             x1, [x1, #0x450]
    // 0x1268dc0: r0 = AllocateClosure()
    //     0x1268dc0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1268dc4: r16 = <Color?>
    //     0x1268dc4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1268dc8: ldr             x16, [x16, #0xa40]
    // 0x1268dcc: stp             x0, x16, [SP]
    // 0x1268dd0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1268dd0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1268dd4: r0 = resolveWith()
    //     0x1268dd4: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1268dd8: mov             x1, x0
    // 0x1268ddc: ldur            x0, [fp, #-0x18]
    // 0x1268de0: cmp             w0, w1
    // 0x1268de4: b.ne            #0x126aad8
    // 0x1268de8: ldr             x1, [fp, #0x18]
    // 0x1268dec: ldr             x2, [fp, #0x10]
    // 0x1268df0: LoadField: r0 = r2->field_3f
    //     0x1268df0: ldur            w0, [x2, #0x3f]
    // 0x1268df4: DecompressPointer r0
    //     0x1268df4: add             x0, x0, HEAP, lsl #32
    // 0x1268df8: LoadField: r3 = r1->field_3f
    //     0x1268df8: ldur            w3, [x1, #0x3f]
    // 0x1268dfc: DecompressPointer r3
    //     0x1268dfc: add             x3, x3, HEAP, lsl #32
    // 0x1268e00: r4 = LoadClassIdInstr(r0)
    //     0x1268e00: ldur            x4, [x0, #-1]
    //     0x1268e04: ubfx            x4, x4, #0xc, #0x14
    // 0x1268e08: stp             x3, x0, [SP]
    // 0x1268e0c: mov             x0, x4
    // 0x1268e10: mov             lr, x0
    // 0x1268e14: ldr             lr, [x21, lr, lsl #3]
    // 0x1268e18: blr             lr
    // 0x1268e1c: tbnz            w0, #4, #0x126aad8
    // 0x1268e20: ldur            x0, [fp, #-8]
    // 0x1268e24: r17 = 5167
    //     0x1268e24: mov             x17, #0x142f
    // 0x1268e28: cmp             x0, x17
    // 0x1268e2c: b.ne            #0x1268e44
    // 0x1268e30: ldr             x1, [fp, #0x10]
    // 0x1268e34: LoadField: r2 = r1->field_43
    //     0x1268e34: ldur            w2, [x1, #0x43]
    // 0x1268e38: DecompressPointer r2
    //     0x1268e38: add             x2, x2, HEAP, lsl #32
    // 0x1268e3c: mov             x1, x2
    // 0x1268e40: b               #0x1268ed0
    // 0x1268e44: ldr             x1, [fp, #0x10]
    // 0x1268e48: r17 = 5168
    //     0x1268e48: mov             x17, #0x1430
    // 0x1268e4c: cmp             x0, x17
    // 0x1268e50: b.ne            #0x1268e94
    // 0x1268e54: r1 = 1
    //     0x1268e54: mov             x1, #1
    // 0x1268e58: r0 = AllocateContext()
    //     0x1268e58: bl              #0x13de838  ; AllocateContextStub
    // 0x1268e5c: mov             x1, x0
    // 0x1268e60: ldr             x0, [fp, #0x10]
    // 0x1268e64: StoreField: r1->field_f = r0
    //     0x1268e64: stur            w0, [x1, #0xf]
    // 0x1268e68: mov             x2, x1
    // 0x1268e6c: r1 = Function '<anonymous closure>':.
    //     0x1268e6c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26458] AnonymousClosure: (0xdf3294), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM3
    //     0x1268e70: ldr             x1, [x1, #0x458]
    // 0x1268e74: r0 = AllocateClosure()
    //     0x1268e74: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1268e78: r16 = <Color?>
    //     0x1268e78: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1268e7c: ldr             x16, [x16, #0xa40]
    // 0x1268e80: stp             x0, x16, [SP]
    // 0x1268e84: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1268e84: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1268e88: r0 = resolveWith()
    //     0x1268e88: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1268e8c: mov             x1, x0
    // 0x1268e90: b               #0x1268ed0
    // 0x1268e94: r1 = 1
    //     0x1268e94: mov             x1, #1
    // 0x1268e98: r0 = AllocateContext()
    //     0x1268e98: bl              #0x13de838  ; AllocateContextStub
    // 0x1268e9c: mov             x1, x0
    // 0x1268ea0: ldr             x0, [fp, #0x10]
    // 0x1268ea4: StoreField: r1->field_f = r0
    //     0x1268ea4: stur            w0, [x1, #0xf]
    // 0x1268ea8: mov             x2, x1
    // 0x1268eac: r1 = Function '<anonymous closure>':.
    //     0x1268eac: add             x1, PP, #0x26, lsl #12  ; [pp+0x26460] AnonymousClosure: (0xdf3120), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM2
    //     0x1268eb0: ldr             x1, [x1, #0x460]
    // 0x1268eb4: r0 = AllocateClosure()
    //     0x1268eb4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1268eb8: r16 = <Color?>
    //     0x1268eb8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1268ebc: ldr             x16, [x16, #0xa40]
    // 0x1268ec0: stp             x0, x16, [SP]
    // 0x1268ec4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1268ec4: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1268ec8: r0 = resolveWith()
    //     0x1268ec8: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1268ecc: mov             x1, x0
    // 0x1268ed0: ldur            x0, [fp, #-0x10]
    // 0x1268ed4: stur            x1, [fp, #-0x18]
    // 0x1268ed8: r17 = 5167
    //     0x1268ed8: mov             x17, #0x142f
    // 0x1268edc: cmp             x0, x17
    // 0x1268ee0: b.ne            #0x1268efc
    // 0x1268ee4: ldr             x2, [fp, #0x18]
    // 0x1268ee8: LoadField: r3 = r2->field_43
    //     0x1268ee8: ldur            w3, [x2, #0x43]
    // 0x1268eec: DecompressPointer r3
    //     0x1268eec: add             x3, x3, HEAP, lsl #32
    // 0x1268ef0: mov             x0, x1
    // 0x1268ef4: mov             x1, x3
    // 0x1268ef8: b               #0x1268f94
    // 0x1268efc: ldr             x2, [fp, #0x18]
    // 0x1268f00: r17 = 5168
    //     0x1268f00: mov             x17, #0x1430
    // 0x1268f04: cmp             x0, x17
    // 0x1268f08: b.ne            #0x1268f50
    // 0x1268f0c: r1 = 1
    //     0x1268f0c: mov             x1, #1
    // 0x1268f10: r0 = AllocateContext()
    //     0x1268f10: bl              #0x13de838  ; AllocateContextStub
    // 0x1268f14: mov             x1, x0
    // 0x1268f18: ldr             x0, [fp, #0x18]
    // 0x1268f1c: StoreField: r1->field_f = r0
    //     0x1268f1c: stur            w0, [x1, #0xf]
    // 0x1268f20: mov             x2, x1
    // 0x1268f24: r1 = Function '<anonymous closure>':.
    //     0x1268f24: add             x1, PP, #0x26, lsl #12  ; [pp+0x26458] AnonymousClosure: (0xdf3294), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM3
    //     0x1268f28: ldr             x1, [x1, #0x458]
    // 0x1268f2c: r0 = AllocateClosure()
    //     0x1268f2c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1268f30: r16 = <Color?>
    //     0x1268f30: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1268f34: ldr             x16, [x16, #0xa40]
    // 0x1268f38: stp             x0, x16, [SP]
    // 0x1268f3c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1268f3c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1268f40: r0 = resolveWith()
    //     0x1268f40: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1268f44: mov             x1, x0
    // 0x1268f48: ldur            x0, [fp, #-0x18]
    // 0x1268f4c: b               #0x1268f94
    // 0x1268f50: mov             x1, x2
    // 0x1268f54: r1 = 1
    //     0x1268f54: mov             x1, #1
    // 0x1268f58: r0 = AllocateContext()
    //     0x1268f58: bl              #0x13de838  ; AllocateContextStub
    // 0x1268f5c: mov             x1, x0
    // 0x1268f60: ldr             x0, [fp, #0x18]
    // 0x1268f64: StoreField: r1->field_f = r0
    //     0x1268f64: stur            w0, [x1, #0xf]
    // 0x1268f68: mov             x2, x1
    // 0x1268f6c: r1 = Function '<anonymous closure>':.
    //     0x1268f6c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26460] AnonymousClosure: (0xdf3120), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM2
    //     0x1268f70: ldr             x1, [x1, #0x460]
    // 0x1268f74: r0 = AllocateClosure()
    //     0x1268f74: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1268f78: r16 = <Color?>
    //     0x1268f78: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1268f7c: ldr             x16, [x16, #0xa40]
    // 0x1268f80: stp             x0, x16, [SP]
    // 0x1268f84: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1268f84: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1268f88: r0 = resolveWith()
    //     0x1268f88: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1268f8c: mov             x1, x0
    // 0x1268f90: ldur            x0, [fp, #-0x18]
    // 0x1268f94: cmp             w0, w1
    // 0x1268f98: b.ne            #0x126aad8
    // 0x1268f9c: ldur            x0, [fp, #-8]
    // 0x1268fa0: r17 = 5167
    //     0x1268fa0: mov             x17, #0x142f
    // 0x1268fa4: cmp             x0, x17
    // 0x1268fa8: b.ne            #0x1268fc0
    // 0x1268fac: ldr             x1, [fp, #0x10]
    // 0x1268fb0: LoadField: r2 = r1->field_47
    //     0x1268fb0: ldur            w2, [x1, #0x47]
    // 0x1268fb4: DecompressPointer r2
    //     0x1268fb4: add             x2, x2, HEAP, lsl #32
    // 0x1268fb8: mov             x1, x2
    // 0x1268fbc: b               #0x126904c
    // 0x1268fc0: ldr             x1, [fp, #0x10]
    // 0x1268fc4: r17 = 5168
    //     0x1268fc4: mov             x17, #0x1430
    // 0x1268fc8: cmp             x0, x17
    // 0x1268fcc: b.ne            #0x1269010
    // 0x1268fd0: r1 = 1
    //     0x1268fd0: mov             x1, #1
    // 0x1268fd4: r0 = AllocateContext()
    //     0x1268fd4: bl              #0x13de838  ; AllocateContextStub
    // 0x1268fd8: mov             x1, x0
    // 0x1268fdc: ldr             x0, [fp, #0x10]
    // 0x1268fe0: StoreField: r1->field_f = r0
    //     0x1268fe0: stur            w0, [x1, #0xf]
    // 0x1268fe4: mov             x2, x1
    // 0x1268fe8: r1 = Function '<anonymous closure>':.
    //     0x1268fe8: add             x1, PP, #0x26, lsl #12  ; [pp+0x26438] AnonymousClosure: (0xdf2bac), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM3
    //     0x1268fec: ldr             x1, [x1, #0x438]
    // 0x1268ff0: r0 = AllocateClosure()
    //     0x1268ff0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1268ff4: r16 = <Color?>
    //     0x1268ff4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1268ff8: ldr             x16, [x16, #0xa40]
    // 0x1268ffc: stp             x0, x16, [SP]
    // 0x1269000: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1269000: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1269004: r0 = resolveWith()
    //     0x1269004: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1269008: mov             x1, x0
    // 0x126900c: b               #0x126904c
    // 0x1269010: r1 = 1
    //     0x1269010: mov             x1, #1
    // 0x1269014: r0 = AllocateContext()
    //     0x1269014: bl              #0x13de838  ; AllocateContextStub
    // 0x1269018: mov             x1, x0
    // 0x126901c: ldr             x0, [fp, #0x10]
    // 0x1269020: StoreField: r1->field_f = r0
    //     0x1269020: stur            w0, [x1, #0xf]
    // 0x1269024: mov             x2, x1
    // 0x1269028: r1 = Function '<anonymous closure>':.
    //     0x1269028: add             x1, PP, #0x26, lsl #12  ; [pp+0x26440] AnonymousClosure: (0xdf2afc), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM2
    //     0x126902c: ldr             x1, [x1, #0x440]
    // 0x1269030: r0 = AllocateClosure()
    //     0x1269030: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1269034: r16 = <Color?>
    //     0x1269034: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1269038: ldr             x16, [x16, #0xa40]
    // 0x126903c: stp             x0, x16, [SP]
    // 0x1269040: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1269040: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1269044: r0 = resolveWith()
    //     0x1269044: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1269048: mov             x1, x0
    // 0x126904c: ldur            x0, [fp, #-0x10]
    // 0x1269050: stur            x1, [fp, #-0x18]
    // 0x1269054: r17 = 5167
    //     0x1269054: mov             x17, #0x142f
    // 0x1269058: cmp             x0, x17
    // 0x126905c: b.ne            #0x1269078
    // 0x1269060: ldr             x2, [fp, #0x18]
    // 0x1269064: LoadField: r3 = r2->field_47
    //     0x1269064: ldur            w3, [x2, #0x47]
    // 0x1269068: DecompressPointer r3
    //     0x1269068: add             x3, x3, HEAP, lsl #32
    // 0x126906c: mov             x0, x1
    // 0x1269070: mov             x1, x3
    // 0x1269074: b               #0x1269110
    // 0x1269078: ldr             x2, [fp, #0x18]
    // 0x126907c: r17 = 5168
    //     0x126907c: mov             x17, #0x1430
    // 0x1269080: cmp             x0, x17
    // 0x1269084: b.ne            #0x12690cc
    // 0x1269088: r1 = 1
    //     0x1269088: mov             x1, #1
    // 0x126908c: r0 = AllocateContext()
    //     0x126908c: bl              #0x13de838  ; AllocateContextStub
    // 0x1269090: mov             x1, x0
    // 0x1269094: ldr             x0, [fp, #0x18]
    // 0x1269098: StoreField: r1->field_f = r0
    //     0x1269098: stur            w0, [x1, #0xf]
    // 0x126909c: mov             x2, x1
    // 0x12690a0: r1 = Function '<anonymous closure>':.
    //     0x12690a0: add             x1, PP, #0x26, lsl #12  ; [pp+0x26438] AnonymousClosure: (0xdf2bac), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM3
    //     0x12690a4: ldr             x1, [x1, #0x438]
    // 0x12690a8: r0 = AllocateClosure()
    //     0x12690a8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x12690ac: r16 = <Color?>
    //     0x12690ac: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x12690b0: ldr             x16, [x16, #0xa40]
    // 0x12690b4: stp             x0, x16, [SP]
    // 0x12690b8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x12690b8: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x12690bc: r0 = resolveWith()
    //     0x12690bc: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x12690c0: mov             x1, x0
    // 0x12690c4: ldur            x0, [fp, #-0x18]
    // 0x12690c8: b               #0x1269110
    // 0x12690cc: mov             x1, x2
    // 0x12690d0: r1 = 1
    //     0x12690d0: mov             x1, #1
    // 0x12690d4: r0 = AllocateContext()
    //     0x12690d4: bl              #0x13de838  ; AllocateContextStub
    // 0x12690d8: mov             x1, x0
    // 0x12690dc: ldr             x0, [fp, #0x18]
    // 0x12690e0: StoreField: r1->field_f = r0
    //     0x12690e0: stur            w0, [x1, #0xf]
    // 0x12690e4: mov             x2, x1
    // 0x12690e8: r1 = Function '<anonymous closure>':.
    //     0x12690e8: add             x1, PP, #0x26, lsl #12  ; [pp+0x26440] AnonymousClosure: (0xdf2afc), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM2
    //     0x12690ec: ldr             x1, [x1, #0x440]
    // 0x12690f0: r0 = AllocateClosure()
    //     0x12690f0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x12690f4: r16 = <Color?>
    //     0x12690f4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x12690f8: ldr             x16, [x16, #0xa40]
    // 0x12690fc: stp             x0, x16, [SP]
    // 0x1269100: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1269100: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1269104: r0 = resolveWith()
    //     0x1269104: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1269108: mov             x1, x0
    // 0x126910c: ldur            x0, [fp, #-0x18]
    // 0x1269110: cmp             w0, w1
    // 0x1269114: b.ne            #0x126aad8
    // 0x1269118: ldur            x0, [fp, #-8]
    // 0x126911c: r17 = 5167
    //     0x126911c: mov             x17, #0x142f
    // 0x1269120: cmp             x0, x17
    // 0x1269124: b.ne            #0x126914c
    // 0x1269128: ldr             x2, [fp, #0x10]
    // 0x126912c: LoadField: r1 = r2->field_4b
    //     0x126912c: ldur            w1, [x2, #0x4b]
    // 0x1269130: DecompressPointer r1
    //     0x1269130: add             x1, x1, HEAP, lsl #32
    // 0x1269134: mov             x3, x1
    // 0x1269138: r0 = Instance_BorderStyle
    //     0x1269138: add             x0, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0x126913c: ldr             x0, [x0, #0xdc8]
    // 0x1269140: d0 = 1.000000
    //     0x1269140: fmov            d0, #1.00000000
    // 0x1269144: d1 = -1.000000
    //     0x1269144: fmov            d1, #-1.00000000
    // 0x1269148: b               #0x1269230
    // 0x126914c: ldr             x2, [fp, #0x10]
    // 0x1269150: r17 = 5168
    //     0x1269150: mov             x17, #0x1430
    // 0x1269154: cmp             x0, x17
    // 0x1269158: b.ne            #0x12691c0
    // 0x126915c: mov             x1, x2
    // 0x1269160: LoadField: r0 = r1->field_b3
    //     0x1269160: ldur            w0, [x1, #0xb3]
    // 0x1269164: DecompressPointer r0
    //     0x1269164: add             x0, x0, HEAP, lsl #32
    // 0x1269168: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126916c: cmp             w0, w16
    // 0x1269170: b.ne            #0x1269180
    // 0x1269174: r2 = _colors
    //     0x1269174: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x1269178: ldr             x2, [x2, #0x400]
    // 0x126917c: r0 = InitLateFinalInstanceField()
    //     0x126917c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1269180: LoadField: r1 = r0->field_b
    //     0x1269180: ldur            w1, [x0, #0xb]
    // 0x1269184: DecompressPointer r1
    //     0x1269184: add             x1, x1, HEAP, lsl #32
    // 0x1269188: stur            x1, [fp, #-0x18]
    // 0x126918c: r0 = BorderSide()
    //     0x126918c: bl              #0x8a73bc  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x1269190: mov             x1, x0
    // 0x1269194: ldur            x0, [fp, #-0x18]
    // 0x1269198: StoreField: r1->field_7 = r0
    //     0x1269198: stur            w0, [x1, #7]
    // 0x126919c: d0 = 1.000000
    //     0x126919c: fmov            d0, #1.00000000
    // 0x12691a0: StoreField: r1->field_b = d0
    //     0x12691a0: stur            d0, [x1, #0xb]
    // 0x12691a4: r0 = Instance_BorderStyle
    //     0x12691a4: add             x0, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0x12691a8: ldr             x0, [x0, #0xdc8]
    // 0x12691ac: StoreField: r1->field_13 = r0
    //     0x12691ac: stur            w0, [x1, #0x13]
    // 0x12691b0: d1 = -1.000000
    //     0x12691b0: fmov            d1, #-1.00000000
    // 0x12691b4: ArrayStore: r1[0] = d1  ; List_8
    //     0x12691b4: stur            d1, [x1, #0x17]
    // 0x12691b8: mov             x3, x1
    // 0x12691bc: b               #0x1269230
    // 0x12691c0: r0 = Instance_BorderStyle
    //     0x12691c0: add             x0, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0x12691c4: ldr             x0, [x0, #0xdc8]
    // 0x12691c8: d0 = 1.000000
    //     0x12691c8: fmov            d0, #1.00000000
    // 0x12691cc: d1 = -1.000000
    //     0x12691cc: fmov            d1, #-1.00000000
    // 0x12691d0: ldr             x1, [fp, #0x10]
    // 0x12691d4: LoadField: r0 = r1->field_b3
    //     0x12691d4: ldur            w0, [x1, #0xb3]
    // 0x12691d8: DecompressPointer r0
    //     0x12691d8: add             x0, x0, HEAP, lsl #32
    // 0x12691dc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12691e0: cmp             w0, w16
    // 0x12691e4: b.ne            #0x12691f4
    // 0x12691e8: r2 = _colors
    //     0x12691e8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x12691ec: ldr             x2, [x2, #0x410]
    // 0x12691f0: r0 = InitLateFinalInstanceField()
    //     0x12691f0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12691f4: LoadField: r1 = r0->field_b
    //     0x12691f4: ldur            w1, [x0, #0xb]
    // 0x12691f8: DecompressPointer r1
    //     0x12691f8: add             x1, x1, HEAP, lsl #32
    // 0x12691fc: stur            x1, [fp, #-0x18]
    // 0x1269200: r0 = BorderSide()
    //     0x1269200: bl              #0x8a73bc  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x1269204: mov             x1, x0
    // 0x1269208: ldur            x0, [fp, #-0x18]
    // 0x126920c: StoreField: r1->field_7 = r0
    //     0x126920c: stur            w0, [x1, #7]
    // 0x1269210: d0 = 1.000000
    //     0x1269210: fmov            d0, #1.00000000
    // 0x1269214: StoreField: r1->field_b = d0
    //     0x1269214: stur            d0, [x1, #0xb]
    // 0x1269218: r0 = Instance_BorderStyle
    //     0x1269218: add             x0, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0x126921c: ldr             x0, [x0, #0xdc8]
    // 0x1269220: StoreField: r1->field_13 = r0
    //     0x1269220: stur            w0, [x1, #0x13]
    // 0x1269224: d1 = -1.000000
    //     0x1269224: fmov            d1, #-1.00000000
    // 0x1269228: ArrayStore: r1[0] = d1  ; List_8
    //     0x1269228: stur            d1, [x1, #0x17]
    // 0x126922c: mov             x3, x1
    // 0x1269230: ldur            x2, [fp, #-0x10]
    // 0x1269234: stur            x3, [fp, #-0x18]
    // 0x1269238: r17 = 5167
    //     0x1269238: mov             x17, #0x142f
    // 0x126923c: cmp             x2, x17
    // 0x1269240: b.ne            #0x126925c
    // 0x1269244: ldr             x4, [fp, #0x18]
    // 0x1269248: LoadField: r0 = r4->field_4b
    //     0x1269248: ldur            w0, [x4, #0x4b]
    // 0x126924c: DecompressPointer r0
    //     0x126924c: add             x0, x0, HEAP, lsl #32
    // 0x1269250: mov             x1, x0
    // 0x1269254: mov             x0, x3
    // 0x1269258: b               #0x1269330
    // 0x126925c: ldr             x4, [fp, #0x18]
    // 0x1269260: r17 = 5168
    //     0x1269260: mov             x17, #0x1430
    // 0x1269264: cmp             x2, x17
    // 0x1269268: b.ne            #0x12692d0
    // 0x126926c: mov             x1, x4
    // 0x1269270: LoadField: r0 = r1->field_b3
    //     0x1269270: ldur            w0, [x1, #0xb3]
    // 0x1269274: DecompressPointer r0
    //     0x1269274: add             x0, x0, HEAP, lsl #32
    // 0x1269278: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126927c: cmp             w0, w16
    // 0x1269280: b.ne            #0x1269290
    // 0x1269284: r2 = _colors
    //     0x1269284: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x1269288: ldr             x2, [x2, #0x400]
    // 0x126928c: r0 = InitLateFinalInstanceField()
    //     0x126928c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1269290: LoadField: r1 = r0->field_b
    //     0x1269290: ldur            w1, [x0, #0xb]
    // 0x1269294: DecompressPointer r1
    //     0x1269294: add             x1, x1, HEAP, lsl #32
    // 0x1269298: stur            x1, [fp, #-0x20]
    // 0x126929c: r0 = BorderSide()
    //     0x126929c: bl              #0x8a73bc  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x12692a0: mov             x1, x0
    // 0x12692a4: ldur            x0, [fp, #-0x20]
    // 0x12692a8: StoreField: r1->field_7 = r0
    //     0x12692a8: stur            w0, [x1, #7]
    // 0x12692ac: d0 = 1.000000
    //     0x12692ac: fmov            d0, #1.00000000
    // 0x12692b0: StoreField: r1->field_b = d0
    //     0x12692b0: stur            d0, [x1, #0xb]
    // 0x12692b4: r0 = Instance_BorderStyle
    //     0x12692b4: add             x0, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0x12692b8: ldr             x0, [x0, #0xdc8]
    // 0x12692bc: StoreField: r1->field_13 = r0
    //     0x12692bc: stur            w0, [x1, #0x13]
    // 0x12692c0: d1 = -1.000000
    //     0x12692c0: fmov            d1, #-1.00000000
    // 0x12692c4: ArrayStore: r1[0] = d1  ; List_8
    //     0x12692c4: stur            d1, [x1, #0x17]
    // 0x12692c8: ldur            x0, [fp, #-0x18]
    // 0x12692cc: b               #0x1269330
    // 0x12692d0: ldr             x1, [fp, #0x18]
    // 0x12692d4: LoadField: r0 = r1->field_b3
    //     0x12692d4: ldur            w0, [x1, #0xb3]
    // 0x12692d8: DecompressPointer r0
    //     0x12692d8: add             x0, x0, HEAP, lsl #32
    // 0x12692dc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12692e0: cmp             w0, w16
    // 0x12692e4: b.ne            #0x12692f4
    // 0x12692e8: r2 = _colors
    //     0x12692e8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x12692ec: ldr             x2, [x2, #0x410]
    // 0x12692f0: r0 = InitLateFinalInstanceField()
    //     0x12692f0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12692f4: LoadField: r1 = r0->field_b
    //     0x12692f4: ldur            w1, [x0, #0xb]
    // 0x12692f8: DecompressPointer r1
    //     0x12692f8: add             x1, x1, HEAP, lsl #32
    // 0x12692fc: stur            x1, [fp, #-0x20]
    // 0x1269300: r0 = BorderSide()
    //     0x1269300: bl              #0x8a73bc  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x1269304: mov             x1, x0
    // 0x1269308: ldur            x0, [fp, #-0x20]
    // 0x126930c: StoreField: r1->field_7 = r0
    //     0x126930c: stur            w0, [x1, #7]
    // 0x1269310: d0 = 1.000000
    //     0x1269310: fmov            d0, #1.00000000
    // 0x1269314: StoreField: r1->field_b = d0
    //     0x1269314: stur            d0, [x1, #0xb]
    // 0x1269318: r0 = Instance_BorderStyle
    //     0x1269318: add             x0, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0x126931c: ldr             x0, [x0, #0xdc8]
    // 0x1269320: StoreField: r1->field_13 = r0
    //     0x1269320: stur            w0, [x1, #0x13]
    // 0x1269324: d0 = -1.000000
    //     0x1269324: fmov            d0, #-1.00000000
    // 0x1269328: ArrayStore: r1[0] = d0  ; List_8
    //     0x1269328: stur            d0, [x1, #0x17]
    // 0x126932c: ldur            x0, [fp, #-0x18]
    // 0x1269330: r2 = LoadClassIdInstr(r0)
    //     0x1269330: ldur            x2, [x0, #-1]
    //     0x1269334: ubfx            x2, x2, #0xc, #0x14
    // 0x1269338: stp             x1, x0, [SP]
    // 0x126933c: mov             x0, x2
    // 0x1269340: mov             lr, x0
    // 0x1269344: ldr             lr, [x21, lr, lsl #3]
    // 0x1269348: blr             lr
    // 0x126934c: tbnz            w0, #4, #0x126aad8
    // 0x1269350: ldur            x0, [fp, #-8]
    // 0x1269354: r17 = 5167
    //     0x1269354: mov             x17, #0x142f
    // 0x1269358: cmp             x0, x17
    // 0x126935c: b.ne            #0x1269374
    // 0x1269360: ldr             x2, [fp, #0x10]
    // 0x1269364: LoadField: r1 = r2->field_4f
    //     0x1269364: ldur            w1, [x2, #0x4f]
    // 0x1269368: DecompressPointer r1
    //     0x1269368: add             x1, x1, HEAP, lsl #32
    // 0x126936c: mov             x2, x1
    // 0x1269370: b               #0x12693e8
    // 0x1269374: ldr             x2, [fp, #0x10]
    // 0x1269378: r17 = 5168
    //     0x1269378: mov             x17, #0x1430
    // 0x126937c: cmp             x0, x17
    // 0x1269380: b.ne            #0x12693b8
    // 0x1269384: mov             x1, x2
    // 0x1269388: LoadField: r0 = r1->field_b7
    //     0x1269388: ldur            w0, [x1, #0xb7]
    // 0x126938c: DecompressPointer r0
    //     0x126938c: add             x0, x0, HEAP, lsl #32
    // 0x1269390: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1269394: cmp             w0, w16
    // 0x1269398: b.ne            #0x12693a8
    // 0x126939c: r2 = _textTheme
    //     0x126939c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26418] Field <_DatePickerDefaultsM3@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0x12693a0: ldr             x2, [x2, #0x418]
    // 0x12693a4: r0 = InitLateFinalInstanceField()
    //     0x12693a4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12693a8: LoadField: r1 = r0->field_2b
    //     0x12693a8: ldur            w1, [x0, #0x2b]
    // 0x12693ac: DecompressPointer r1
    //     0x12693ac: add             x1, x1, HEAP, lsl #32
    // 0x12693b0: mov             x2, x1
    // 0x12693b4: b               #0x12693e8
    // 0x12693b8: ldr             x1, [fp, #0x10]
    // 0x12693bc: LoadField: r0 = r1->field_b7
    //     0x12693bc: ldur            w0, [x1, #0xb7]
    // 0x12693c0: DecompressPointer r0
    //     0x12693c0: add             x0, x0, HEAP, lsl #32
    // 0x12693c4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12693c8: cmp             w0, w16
    // 0x12693cc: b.ne            #0x12693dc
    // 0x12693d0: r2 = _textTheme
    //     0x12693d0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26420] Field <_DatePickerDefaultsM2@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0x12693d4: ldr             x2, [x2, #0x420]
    // 0x12693d8: r0 = InitLateFinalInstanceField()
    //     0x12693d8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12693dc: LoadField: r1 = r0->field_2b
    //     0x12693dc: ldur            w1, [x0, #0x2b]
    // 0x12693e0: DecompressPointer r1
    //     0x12693e0: add             x1, x1, HEAP, lsl #32
    // 0x12693e4: mov             x2, x1
    // 0x12693e8: ldur            x0, [fp, #-0x10]
    // 0x12693ec: stur            x2, [fp, #-0x18]
    // 0x12693f0: r17 = 5167
    //     0x12693f0: mov             x17, #0x142f
    // 0x12693f4: cmp             x0, x17
    // 0x12693f8: b.ne            #0x1269410
    // 0x12693fc: ldr             x3, [fp, #0x18]
    // 0x1269400: LoadField: r1 = r3->field_4f
    //     0x1269400: ldur            w1, [x3, #0x4f]
    // 0x1269404: DecompressPointer r1
    //     0x1269404: add             x1, x1, HEAP, lsl #32
    // 0x1269408: mov             x0, x2
    // 0x126940c: b               #0x1269484
    // 0x1269410: ldr             x3, [fp, #0x18]
    // 0x1269414: r17 = 5168
    //     0x1269414: mov             x17, #0x1430
    // 0x1269418: cmp             x0, x17
    // 0x126941c: b.ne            #0x1269454
    // 0x1269420: mov             x1, x3
    // 0x1269424: LoadField: r0 = r1->field_b7
    //     0x1269424: ldur            w0, [x1, #0xb7]
    // 0x1269428: DecompressPointer r0
    //     0x1269428: add             x0, x0, HEAP, lsl #32
    // 0x126942c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1269430: cmp             w0, w16
    // 0x1269434: b.ne            #0x1269444
    // 0x1269438: r2 = _textTheme
    //     0x1269438: add             x2, PP, #0x26, lsl #12  ; [pp+0x26418] Field <_DatePickerDefaultsM3@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0x126943c: ldr             x2, [x2, #0x418]
    // 0x1269440: r0 = InitLateFinalInstanceField()
    //     0x1269440: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1269444: LoadField: r1 = r0->field_2b
    //     0x1269444: ldur            w1, [x0, #0x2b]
    // 0x1269448: DecompressPointer r1
    //     0x1269448: add             x1, x1, HEAP, lsl #32
    // 0x126944c: ldur            x0, [fp, #-0x18]
    // 0x1269450: b               #0x1269484
    // 0x1269454: ldr             x1, [fp, #0x18]
    // 0x1269458: LoadField: r0 = r1->field_b7
    //     0x1269458: ldur            w0, [x1, #0xb7]
    // 0x126945c: DecompressPointer r0
    //     0x126945c: add             x0, x0, HEAP, lsl #32
    // 0x1269460: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1269464: cmp             w0, w16
    // 0x1269468: b.ne            #0x1269478
    // 0x126946c: r2 = _textTheme
    //     0x126946c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26420] Field <_DatePickerDefaultsM2@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0x1269470: ldr             x2, [x2, #0x420]
    // 0x1269474: r0 = InitLateFinalInstanceField()
    //     0x1269474: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1269478: LoadField: r1 = r0->field_2b
    //     0x1269478: ldur            w1, [x0, #0x2b]
    // 0x126947c: DecompressPointer r1
    //     0x126947c: add             x1, x1, HEAP, lsl #32
    // 0x1269480: ldur            x0, [fp, #-0x18]
    // 0x1269484: r2 = LoadClassIdInstr(r0)
    //     0x1269484: ldur            x2, [x0, #-1]
    //     0x1269488: ubfx            x2, x2, #0xc, #0x14
    // 0x126948c: stp             x1, x0, [SP]
    // 0x1269490: mov             x0, x2
    // 0x1269494: mov             lr, x0
    // 0x1269498: ldr             lr, [x21, lr, lsl #3]
    // 0x126949c: blr             lr
    // 0x12694a0: tbnz            w0, #4, #0x126aad8
    // 0x12694a4: ldur            x0, [fp, #-8]
    // 0x12694a8: r17 = 5167
    //     0x12694a8: mov             x17, #0x142f
    // 0x12694ac: cmp             x0, x17
    // 0x12694b0: b.eq            #0x1269508
    // 0x12694b4: r17 = 5168
    //     0x12694b4: mov             x17, #0x1430
    // 0x12694b8: cmp             x0, x17
    // 0x12694bc: b.ne            #0x1269508
    // 0x12694c0: ldr             x1, [fp, #0x10]
    // 0x12694c4: r1 = 1
    //     0x12694c4: mov             x1, #1
    // 0x12694c8: r0 = AllocateContext()
    //     0x12694c8: bl              #0x13de838  ; AllocateContextStub
    // 0x12694cc: mov             x1, x0
    // 0x12694d0: ldr             x0, [fp, #0x10]
    // 0x12694d4: StoreField: r1->field_f = r0
    //     0x12694d4: stur            w0, [x1, #0xf]
    // 0x12694d8: mov             x2, x1
    // 0x12694dc: r1 = Function '<anonymous closure>':.
    //     0x12694dc: add             x1, PP, #0x26, lsl #12  ; [pp+0x26468] AnonymousClosure: (0xdf490c), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM3
    //     0x12694e0: ldr             x1, [x1, #0x468]
    // 0x12694e4: r0 = AllocateClosure()
    //     0x12694e4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x12694e8: r16 = <Color?>
    //     0x12694e8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x12694ec: ldr             x16, [x16, #0xa40]
    // 0x12694f0: stp             x0, x16, [SP]
    // 0x12694f4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x12694f4: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x12694f8: r0 = resolveWith()
    //     0x12694f8: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x12694fc: mov             x2, x0
    // 0x1269500: ldr             x1, [fp, #0x10]
    // 0x1269504: b               #0x1269518
    // 0x1269508: ldr             x1, [fp, #0x10]
    // 0x126950c: LoadField: r0 = r1->field_53
    //     0x126950c: ldur            w0, [x1, #0x53]
    // 0x1269510: DecompressPointer r0
    //     0x1269510: add             x0, x0, HEAP, lsl #32
    // 0x1269514: mov             x2, x0
    // 0x1269518: ldur            x0, [fp, #-0x10]
    // 0x126951c: stur            x2, [fp, #-0x18]
    // 0x1269520: r17 = 5167
    //     0x1269520: mov             x17, #0x142f
    // 0x1269524: cmp             x0, x17
    // 0x1269528: b.eq            #0x1269580
    // 0x126952c: r17 = 5168
    //     0x126952c: mov             x17, #0x1430
    // 0x1269530: cmp             x0, x17
    // 0x1269534: b.ne            #0x1269580
    // 0x1269538: ldr             x3, [fp, #0x18]
    // 0x126953c: r1 = 1
    //     0x126953c: mov             x1, #1
    // 0x1269540: r0 = AllocateContext()
    //     0x1269540: bl              #0x13de838  ; AllocateContextStub
    // 0x1269544: mov             x1, x0
    // 0x1269548: ldr             x0, [fp, #0x18]
    // 0x126954c: StoreField: r1->field_f = r0
    //     0x126954c: stur            w0, [x1, #0xf]
    // 0x1269550: mov             x2, x1
    // 0x1269554: r1 = Function '<anonymous closure>':.
    //     0x1269554: add             x1, PP, #0x26, lsl #12  ; [pp+0x26468] AnonymousClosure: (0xdf490c), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM3
    //     0x1269558: ldr             x1, [x1, #0x468]
    // 0x126955c: r0 = AllocateClosure()
    //     0x126955c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1269560: r16 = <Color?>
    //     0x1269560: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1269564: ldr             x16, [x16, #0xa40]
    // 0x1269568: stp             x0, x16, [SP]
    // 0x126956c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x126956c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1269570: r0 = resolveWith()
    //     0x1269570: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1269574: mov             x2, x0
    // 0x1269578: ldr             x1, [fp, #0x18]
    // 0x126957c: b               #0x1269590
    // 0x1269580: ldr             x1, [fp, #0x18]
    // 0x1269584: LoadField: r0 = r1->field_53
    //     0x1269584: ldur            w0, [x1, #0x53]
    // 0x1269588: DecompressPointer r0
    //     0x1269588: add             x0, x0, HEAP, lsl #32
    // 0x126958c: mov             x2, x0
    // 0x1269590: ldur            x0, [fp, #-0x18]
    // 0x1269594: cmp             w0, w2
    // 0x1269598: b.ne            #0x126aad8
    // 0x126959c: ldur            x0, [fp, #-8]
    // 0x12695a0: r17 = 5167
    //     0x12695a0: mov             x17, #0x142f
    // 0x12695a4: cmp             x0, x17
    // 0x12695a8: b.eq            #0x1269600
    // 0x12695ac: r17 = 5168
    //     0x12695ac: mov             x17, #0x1430
    // 0x12695b0: cmp             x0, x17
    // 0x12695b4: b.ne            #0x1269600
    // 0x12695b8: ldr             x2, [fp, #0x10]
    // 0x12695bc: r1 = 1
    //     0x12695bc: mov             x1, #1
    // 0x12695c0: r0 = AllocateContext()
    //     0x12695c0: bl              #0x13de838  ; AllocateContextStub
    // 0x12695c4: mov             x1, x0
    // 0x12695c8: ldr             x0, [fp, #0x10]
    // 0x12695cc: StoreField: r1->field_f = r0
    //     0x12695cc: stur            w0, [x1, #0xf]
    // 0x12695d0: mov             x2, x1
    // 0x12695d4: r1 = Function '<anonymous closure>':.
    //     0x12695d4: add             x1, PP, #0x26, lsl #12  ; [pp+0x26470] AnonymousClosure: (0xdf2bac), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM3
    //     0x12695d8: ldr             x1, [x1, #0x470]
    // 0x12695dc: r0 = AllocateClosure()
    //     0x12695dc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x12695e0: r16 = <Color?>
    //     0x12695e0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x12695e4: ldr             x16, [x16, #0xa40]
    // 0x12695e8: stp             x0, x16, [SP]
    // 0x12695ec: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x12695ec: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x12695f0: r0 = resolveWith()
    //     0x12695f0: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x12695f4: mov             x2, x0
    // 0x12695f8: ldr             x1, [fp, #0x10]
    // 0x12695fc: b               #0x1269610
    // 0x1269600: ldr             x1, [fp, #0x10]
    // 0x1269604: LoadField: r0 = r1->field_57
    //     0x1269604: ldur            w0, [x1, #0x57]
    // 0x1269608: DecompressPointer r0
    //     0x1269608: add             x0, x0, HEAP, lsl #32
    // 0x126960c: mov             x2, x0
    // 0x1269610: ldur            x0, [fp, #-0x10]
    // 0x1269614: stur            x2, [fp, #-0x18]
    // 0x1269618: r17 = 5167
    //     0x1269618: mov             x17, #0x142f
    // 0x126961c: cmp             x0, x17
    // 0x1269620: b.eq            #0x1269678
    // 0x1269624: r17 = 5168
    //     0x1269624: mov             x17, #0x1430
    // 0x1269628: cmp             x0, x17
    // 0x126962c: b.ne            #0x1269678
    // 0x1269630: ldr             x3, [fp, #0x18]
    // 0x1269634: r1 = 1
    //     0x1269634: mov             x1, #1
    // 0x1269638: r0 = AllocateContext()
    //     0x1269638: bl              #0x13de838  ; AllocateContextStub
    // 0x126963c: mov             x1, x0
    // 0x1269640: ldr             x0, [fp, #0x18]
    // 0x1269644: StoreField: r1->field_f = r0
    //     0x1269644: stur            w0, [x1, #0xf]
    // 0x1269648: mov             x2, x1
    // 0x126964c: r1 = Function '<anonymous closure>':.
    //     0x126964c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26470] AnonymousClosure: (0xdf2bac), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM3
    //     0x1269650: ldr             x1, [x1, #0x470]
    // 0x1269654: r0 = AllocateClosure()
    //     0x1269654: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1269658: r16 = <Color?>
    //     0x1269658: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x126965c: ldr             x16, [x16, #0xa40]
    // 0x1269660: stp             x0, x16, [SP]
    // 0x1269664: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1269664: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1269668: r0 = resolveWith()
    //     0x1269668: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x126966c: mov             x2, x0
    // 0x1269670: ldr             x1, [fp, #0x18]
    // 0x1269674: b               #0x1269688
    // 0x1269678: ldr             x1, [fp, #0x18]
    // 0x126967c: LoadField: r0 = r1->field_57
    //     0x126967c: ldur            w0, [x1, #0x57]
    // 0x1269680: DecompressPointer r0
    //     0x1269680: add             x0, x0, HEAP, lsl #32
    // 0x1269684: mov             x2, x0
    // 0x1269688: ldur            x0, [fp, #-0x18]
    // 0x126968c: cmp             w0, w2
    // 0x1269690: b.ne            #0x126aad8
    // 0x1269694: ldur            x0, [fp, #-8]
    // 0x1269698: r17 = 5167
    //     0x1269698: mov             x17, #0x142f
    // 0x126969c: cmp             x0, x17
    // 0x12696a0: b.eq            #0x12696f8
    // 0x12696a4: r17 = 5168
    //     0x12696a4: mov             x17, #0x1430
    // 0x12696a8: cmp             x0, x17
    // 0x12696ac: b.ne            #0x12696f8
    // 0x12696b0: ldr             x2, [fp, #0x10]
    // 0x12696b4: r1 = 1
    //     0x12696b4: mov             x1, #1
    // 0x12696b8: r0 = AllocateContext()
    //     0x12696b8: bl              #0x13de838  ; AllocateContextStub
    // 0x12696bc: mov             x1, x0
    // 0x12696c0: ldr             x0, [fp, #0x10]
    // 0x12696c4: StoreField: r1->field_f = r0
    //     0x12696c4: stur            w0, [x1, #0xf]
    // 0x12696c8: mov             x2, x1
    // 0x12696cc: r1 = Function '<anonymous closure>':.
    //     0x12696cc: add             x1, PP, #0x26, lsl #12  ; [pp+0x26478] AnonymousClosure: (0xdf2558), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM3
    //     0x12696d0: ldr             x1, [x1, #0x478]
    // 0x12696d4: r0 = AllocateClosure()
    //     0x12696d4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x12696d8: r16 = <Color?>
    //     0x12696d8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x12696dc: ldr             x16, [x16, #0xa40]
    // 0x12696e0: stp             x0, x16, [SP]
    // 0x12696e4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x12696e4: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x12696e8: r0 = resolveWith()
    //     0x12696e8: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x12696ec: mov             x2, x0
    // 0x12696f0: ldr             x1, [fp, #0x10]
    // 0x12696f4: b               #0x1269708
    // 0x12696f8: ldr             x1, [fp, #0x10]
    // 0x12696fc: LoadField: r0 = r1->field_5b
    //     0x12696fc: ldur            w0, [x1, #0x5b]
    // 0x1269700: DecompressPointer r0
    //     0x1269700: add             x0, x0, HEAP, lsl #32
    // 0x1269704: mov             x2, x0
    // 0x1269708: ldur            x0, [fp, #-0x10]
    // 0x126970c: stur            x2, [fp, #-0x18]
    // 0x1269710: r17 = 5167
    //     0x1269710: mov             x17, #0x142f
    // 0x1269714: cmp             x0, x17
    // 0x1269718: b.eq            #0x1269770
    // 0x126971c: r17 = 5168
    //     0x126971c: mov             x17, #0x1430
    // 0x1269720: cmp             x0, x17
    // 0x1269724: b.ne            #0x1269770
    // 0x1269728: ldr             x3, [fp, #0x18]
    // 0x126972c: r1 = 1
    //     0x126972c: mov             x1, #1
    // 0x1269730: r0 = AllocateContext()
    //     0x1269730: bl              #0x13de838  ; AllocateContextStub
    // 0x1269734: mov             x1, x0
    // 0x1269738: ldr             x0, [fp, #0x18]
    // 0x126973c: StoreField: r1->field_f = r0
    //     0x126973c: stur            w0, [x1, #0xf]
    // 0x1269740: mov             x2, x1
    // 0x1269744: r1 = Function '<anonymous closure>':.
    //     0x1269744: add             x1, PP, #0x26, lsl #12  ; [pp+0x26478] AnonymousClosure: (0xdf2558), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM3
    //     0x1269748: ldr             x1, [x1, #0x478]
    // 0x126974c: r0 = AllocateClosure()
    //     0x126974c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1269750: r16 = <Color?>
    //     0x1269750: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1269754: ldr             x16, [x16, #0xa40]
    // 0x1269758: stp             x0, x16, [SP]
    // 0x126975c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x126975c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1269760: r0 = resolveWith()
    //     0x1269760: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1269764: mov             x2, x0
    // 0x1269768: ldr             x1, [fp, #0x18]
    // 0x126976c: b               #0x1269780
    // 0x1269770: ldr             x1, [fp, #0x18]
    // 0x1269774: LoadField: r0 = r1->field_5b
    //     0x1269774: ldur            w0, [x1, #0x5b]
    // 0x1269778: DecompressPointer r0
    //     0x1269778: add             x0, x0, HEAP, lsl #32
    // 0x126977c: mov             x2, x0
    // 0x1269780: ldur            x0, [fp, #-0x18]
    // 0x1269784: cmp             w0, w2
    // 0x1269788: b.ne            #0x126aad8
    // 0x126978c: ldr             x2, [fp, #0x10]
    // 0x1269790: LoadField: r0 = r2->field_5f
    //     0x1269790: ldur            w0, [x2, #0x5f]
    // 0x1269794: DecompressPointer r0
    //     0x1269794: add             x0, x0, HEAP, lsl #32
    // 0x1269798: LoadField: r3 = r1->field_5f
    //     0x1269798: ldur            w3, [x1, #0x5f]
    // 0x126979c: DecompressPointer r3
    //     0x126979c: add             x3, x3, HEAP, lsl #32
    // 0x12697a0: r4 = LoadClassIdInstr(r0)
    //     0x12697a0: ldur            x4, [x0, #-1]
    //     0x12697a4: ubfx            x4, x4, #0xc, #0x14
    // 0x12697a8: stp             x3, x0, [SP]
    // 0x12697ac: mov             x0, x4
    // 0x12697b0: mov             lr, x0
    // 0x12697b4: ldr             lr, [x21, lr, lsl #3]
    // 0x12697b8: blr             lr
    // 0x12697bc: tbnz            w0, #4, #0x126aad8
    // 0x12697c0: ldur            x0, [fp, #-8]
    // 0x12697c4: r17 = -5167
    //     0x12697c4: mov             x17, #-0x142f
    // 0x12697c8: add             x16, x0, x17
    // 0x12697cc: cmp             x16, #1
    // 0x12697d0: b.hi            #0x12697e8
    // 0x12697d4: ldr             x2, [fp, #0x10]
    // 0x12697d8: LoadField: r1 = r2->field_63
    //     0x12697d8: ldur            w1, [x2, #0x63]
    // 0x12697dc: DecompressPointer r1
    //     0x12697dc: add             x1, x1, HEAP, lsl #32
    // 0x12697e0: mov             x2, x1
    // 0x12697e4: b               #0x126981c
    // 0x12697e8: ldr             x2, [fp, #0x10]
    // 0x12697ec: mov             x1, x2
    // 0x12697f0: LoadField: r0 = r1->field_b3
    //     0x12697f0: ldur            w0, [x1, #0xb3]
    // 0x12697f4: DecompressPointer r0
    //     0x12697f4: add             x0, x0, HEAP, lsl #32
    // 0x12697f8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12697fc: cmp             w0, w16
    // 0x1269800: b.ne            #0x1269810
    // 0x1269804: r2 = _colors
    //     0x1269804: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x1269808: ldr             x2, [x2, #0x410]
    // 0x126980c: r0 = InitLateFinalInstanceField()
    //     0x126980c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1269810: LoadField: r1 = r0->field_7b
    //     0x1269810: ldur            w1, [x0, #0x7b]
    // 0x1269814: DecompressPointer r1
    //     0x1269814: add             x1, x1, HEAP, lsl #32
    // 0x1269818: mov             x2, x1
    // 0x126981c: ldur            x0, [fp, #-0x10]
    // 0x1269820: stur            x2, [fp, #-0x18]
    // 0x1269824: r17 = -5167
    //     0x1269824: mov             x17, #-0x142f
    // 0x1269828: add             x16, x0, x17
    // 0x126982c: cmp             x16, #1
    // 0x1269830: b.hi            #0x1269848
    // 0x1269834: ldr             x3, [fp, #0x18]
    // 0x1269838: LoadField: r1 = r3->field_63
    //     0x1269838: ldur            w1, [x3, #0x63]
    // 0x126983c: DecompressPointer r1
    //     0x126983c: add             x1, x1, HEAP, lsl #32
    // 0x1269840: mov             x0, x2
    // 0x1269844: b               #0x126987c
    // 0x1269848: ldr             x3, [fp, #0x18]
    // 0x126984c: mov             x1, x3
    // 0x1269850: LoadField: r0 = r1->field_b3
    //     0x1269850: ldur            w0, [x1, #0xb3]
    // 0x1269854: DecompressPointer r0
    //     0x1269854: add             x0, x0, HEAP, lsl #32
    // 0x1269858: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126985c: cmp             w0, w16
    // 0x1269860: b.ne            #0x1269870
    // 0x1269864: r2 = _colors
    //     0x1269864: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x1269868: ldr             x2, [x2, #0x410]
    // 0x126986c: r0 = InitLateFinalInstanceField()
    //     0x126986c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1269870: LoadField: r1 = r0->field_7b
    //     0x1269870: ldur            w1, [x0, #0x7b]
    // 0x1269874: DecompressPointer r1
    //     0x1269874: add             x1, x1, HEAP, lsl #32
    // 0x1269878: ldur            x0, [fp, #-0x18]
    // 0x126987c: r2 = LoadClassIdInstr(r0)
    //     0x126987c: ldur            x2, [x0, #-1]
    //     0x1269880: ubfx            x2, x2, #0xc, #0x14
    // 0x1269884: stp             x1, x0, [SP]
    // 0x1269888: mov             x0, x2
    // 0x126988c: mov             lr, x0
    // 0x1269890: ldr             lr, [x21, lr, lsl #3]
    // 0x1269894: blr             lr
    // 0x1269898: tbnz            w0, #4, #0x126aad8
    // 0x126989c: ldr             x1, [fp, #0x18]
    // 0x12698a0: ldr             x2, [fp, #0x10]
    // 0x12698a4: LoadField: r0 = r2->field_67
    //     0x12698a4: ldur            w0, [x2, #0x67]
    // 0x12698a8: DecompressPointer r0
    //     0x12698a8: add             x0, x0, HEAP, lsl #32
    // 0x12698ac: LoadField: r3 = r1->field_67
    //     0x12698ac: ldur            w3, [x1, #0x67]
    // 0x12698b0: DecompressPointer r3
    //     0x12698b0: add             x3, x3, HEAP, lsl #32
    // 0x12698b4: r4 = LoadClassIdInstr(r0)
    //     0x12698b4: ldur            x4, [x0, #-1]
    //     0x12698b8: ubfx            x4, x4, #0xc, #0x14
    // 0x12698bc: stp             x3, x0, [SP]
    // 0x12698c0: mov             x0, x4
    // 0x12698c4: mov             lr, x0
    // 0x12698c8: ldr             lr, [x21, lr, lsl #3]
    // 0x12698cc: blr             lr
    // 0x12698d0: tbnz            w0, #4, #0x126aad8
    // 0x12698d4: ldur            x1, [fp, #-8]
    // 0x12698d8: r17 = 5167
    //     0x12698d8: mov             x17, #0x142f
    // 0x12698dc: cmp             x1, x17
    // 0x12698e0: b.ne            #0x12698f4
    // 0x12698e4: ldr             x2, [fp, #0x10]
    // 0x12698e8: LoadField: r0 = r2->field_6b
    //     0x12698e8: ldur            w0, [x2, #0x6b]
    // 0x12698ec: DecompressPointer r0
    //     0x12698ec: add             x0, x0, HEAP, lsl #32
    // 0x12698f0: b               #0x1269918
    // 0x12698f4: ldr             x2, [fp, #0x10]
    // 0x12698f8: r17 = 5168
    //     0x12698f8: mov             x17, #0x1430
    // 0x12698fc: cmp             x1, x17
    // 0x1269900: b.ne            #0x1269910
    // 0x1269904: r0 = Instance_Color
    //     0x1269904: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x1269908: ldr             x0, [x0, #0x810]
    // 0x126990c: b               #0x1269918
    // 0x1269910: r0 = Instance_Color
    //     0x1269910: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x1269914: ldr             x0, [x0, #0x810]
    // 0x1269918: ldur            x3, [fp, #-0x10]
    // 0x126991c: r17 = 5167
    //     0x126991c: mov             x17, #0x142f
    // 0x1269920: cmp             x3, x17
    // 0x1269924: b.ne            #0x1269938
    // 0x1269928: ldr             x4, [fp, #0x18]
    // 0x126992c: LoadField: r5 = r4->field_6b
    //     0x126992c: ldur            w5, [x4, #0x6b]
    // 0x1269930: DecompressPointer r5
    //     0x1269930: add             x5, x5, HEAP, lsl #32
    // 0x1269934: b               #0x126995c
    // 0x1269938: ldr             x4, [fp, #0x18]
    // 0x126993c: r17 = 5168
    //     0x126993c: mov             x17, #0x1430
    // 0x1269940: cmp             x3, x17
    // 0x1269944: b.ne            #0x1269954
    // 0x1269948: r5 = Instance_Color
    //     0x1269948: add             x5, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x126994c: ldr             x5, [x5, #0x810]
    // 0x1269950: b               #0x126995c
    // 0x1269954: r5 = Instance_Color
    //     0x1269954: add             x5, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x1269958: ldr             x5, [x5, #0x810]
    // 0x126995c: r6 = LoadClassIdInstr(r0)
    //     0x126995c: ldur            x6, [x0, #-1]
    //     0x1269960: ubfx            x6, x6, #0xc, #0x14
    // 0x1269964: stp             x5, x0, [SP]
    // 0x1269968: mov             x0, x6
    // 0x126996c: mov             lr, x0
    // 0x1269970: ldr             lr, [x21, lr, lsl #3]
    // 0x1269974: blr             lr
    // 0x1269978: tbnz            w0, #4, #0x126aad8
    // 0x126997c: ldur            x1, [fp, #-8]
    // 0x1269980: r17 = 5167
    //     0x1269980: mov             x17, #0x142f
    // 0x1269984: cmp             x1, x17
    // 0x1269988: b.ne            #0x126999c
    // 0x126998c: ldr             x2, [fp, #0x10]
    // 0x1269990: LoadField: r0 = r2->field_6f
    //     0x1269990: ldur            w0, [x2, #0x6f]
    // 0x1269994: DecompressPointer r0
    //     0x1269994: add             x0, x0, HEAP, lsl #32
    // 0x1269998: b               #0x12699c0
    // 0x126999c: ldr             x2, [fp, #0x10]
    // 0x12699a0: r17 = 5168
    //     0x12699a0: mov             x17, #0x1430
    // 0x12699a4: cmp             x1, x17
    // 0x12699a8: b.ne            #0x12699b8
    // 0x12699ac: r0 = Instance_Color
    //     0x12699ac: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x12699b0: ldr             x0, [x0, #0x810]
    // 0x12699b4: b               #0x12699c0
    // 0x12699b8: r0 = Instance_Color
    //     0x12699b8: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x12699bc: ldr             x0, [x0, #0x810]
    // 0x12699c0: ldur            x3, [fp, #-0x10]
    // 0x12699c4: r17 = 5167
    //     0x12699c4: mov             x17, #0x142f
    // 0x12699c8: cmp             x3, x17
    // 0x12699cc: b.ne            #0x12699e0
    // 0x12699d0: ldr             x4, [fp, #0x18]
    // 0x12699d4: LoadField: r5 = r4->field_6f
    //     0x12699d4: ldur            w5, [x4, #0x6f]
    // 0x12699d8: DecompressPointer r5
    //     0x12699d8: add             x5, x5, HEAP, lsl #32
    // 0x12699dc: b               #0x1269a04
    // 0x12699e0: ldr             x4, [fp, #0x18]
    // 0x12699e4: r17 = 5168
    //     0x12699e4: mov             x17, #0x1430
    // 0x12699e8: cmp             x3, x17
    // 0x12699ec: b.ne            #0x12699fc
    // 0x12699f0: r5 = Instance_Color
    //     0x12699f0: add             x5, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x12699f4: ldr             x5, [x5, #0x810]
    // 0x12699f8: b               #0x1269a04
    // 0x12699fc: r5 = Instance_Color
    //     0x12699fc: add             x5, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x1269a00: ldr             x5, [x5, #0x810]
    // 0x1269a04: r6 = LoadClassIdInstr(r0)
    //     0x1269a04: ldur            x6, [x0, #-1]
    //     0x1269a08: ubfx            x6, x6, #0xc, #0x14
    // 0x1269a0c: stp             x5, x0, [SP]
    // 0x1269a10: mov             x0, x6
    // 0x1269a14: mov             lr, x0
    // 0x1269a18: ldr             lr, [x21, lr, lsl #3]
    // 0x1269a1c: blr             lr
    // 0x1269a20: tbnz            w0, #4, #0x126aad8
    // 0x1269a24: ldr             x2, [fp, #0x18]
    // 0x1269a28: ldr             x1, [fp, #0x10]
    // 0x1269a2c: LoadField: r0 = r1->field_73
    //     0x1269a2c: ldur            w0, [x1, #0x73]
    // 0x1269a30: DecompressPointer r0
    //     0x1269a30: add             x0, x0, HEAP, lsl #32
    // 0x1269a34: LoadField: r3 = r2->field_73
    //     0x1269a34: ldur            w3, [x2, #0x73]
    // 0x1269a38: DecompressPointer r3
    //     0x1269a38: add             x3, x3, HEAP, lsl #32
    // 0x1269a3c: r4 = LoadClassIdInstr(r0)
    //     0x1269a3c: ldur            x4, [x0, #-1]
    //     0x1269a40: ubfx            x4, x4, #0xc, #0x14
    // 0x1269a44: stp             x3, x0, [SP]
    // 0x1269a48: mov             x0, x4
    // 0x1269a4c: mov             lr, x0
    // 0x1269a50: ldr             lr, [x21, lr, lsl #3]
    // 0x1269a54: blr             lr
    // 0x1269a58: tbnz            w0, #4, #0x126aad8
    // 0x1269a5c: ldur            x0, [fp, #-8]
    // 0x1269a60: r17 = 5167
    //     0x1269a60: mov             x17, #0x142f
    // 0x1269a64: cmp             x0, x17
    // 0x1269a68: b.ne            #0x1269a80
    // 0x1269a6c: ldr             x2, [fp, #0x10]
    // 0x1269a70: LoadField: r1 = r2->field_77
    //     0x1269a70: ldur            w1, [x2, #0x77]
    // 0x1269a74: DecompressPointer r1
    //     0x1269a74: add             x1, x1, HEAP, lsl #32
    // 0x1269a78: mov             x2, x1
    // 0x1269a7c: b               #0x1269b2c
    // 0x1269a80: ldr             x2, [fp, #0x10]
    // 0x1269a84: r17 = 5168
    //     0x1269a84: mov             x17, #0x1430
    // 0x1269a88: cmp             x0, x17
    // 0x1269a8c: b.ne            #0x1269a9c
    // 0x1269a90: r2 = Instance_Color
    //     0x1269a90: add             x2, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x1269a94: ldr             x2, [x2, #0x810]
    // 0x1269a98: b               #0x1269b2c
    // 0x1269a9c: mov             x1, x2
    // 0x1269aa0: LoadField: r0 = r1->field_bb
    //     0x1269aa0: ldur            w0, [x1, #0xbb]
    // 0x1269aa4: DecompressPointer r0
    //     0x1269aa4: add             x0, x0, HEAP, lsl #32
    // 0x1269aa8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1269aac: cmp             w0, w16
    // 0x1269ab0: b.ne            #0x1269ac0
    // 0x1269ab4: r2 = _isDark
    //     0x1269ab4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26408] Field <_DatePickerDefaultsM2@738353974._isDark@738353974>: late final (offset: 0xbc)
    //     0x1269ab8: ldr             x2, [x2, #0x408]
    // 0x1269abc: r0 = InitLateFinalInstanceField()
    //     0x1269abc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1269ac0: tbnz            w0, #4, #0x1269af8
    // 0x1269ac4: ldr             x1, [fp, #0x10]
    // 0x1269ac8: LoadField: r0 = r1->field_b3
    //     0x1269ac8: ldur            w0, [x1, #0xb3]
    // 0x1269acc: DecompressPointer r0
    //     0x1269acc: add             x0, x0, HEAP, lsl #32
    // 0x1269ad0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1269ad4: cmp             w0, w16
    // 0x1269ad8: b.ne            #0x1269ae8
    // 0x1269adc: r2 = _colors
    //     0x1269adc: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x1269ae0: ldr             x2, [x2, #0x410]
    // 0x1269ae4: r0 = InitLateFinalInstanceField()
    //     0x1269ae4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1269ae8: LoadField: r1 = r0->field_7b
    //     0x1269ae8: ldur            w1, [x0, #0x7b]
    // 0x1269aec: DecompressPointer r1
    //     0x1269aec: add             x1, x1, HEAP, lsl #32
    // 0x1269af0: mov             x0, x1
    // 0x1269af4: b               #0x1269b28
    // 0x1269af8: ldr             x1, [fp, #0x10]
    // 0x1269afc: LoadField: r0 = r1->field_b3
    //     0x1269afc: ldur            w0, [x1, #0xb3]
    // 0x1269b00: DecompressPointer r0
    //     0x1269b00: add             x0, x0, HEAP, lsl #32
    // 0x1269b04: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1269b08: cmp             w0, w16
    // 0x1269b0c: b.ne            #0x1269b1c
    // 0x1269b10: r2 = _colors
    //     0x1269b10: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x1269b14: ldr             x2, [x2, #0x410]
    // 0x1269b18: r0 = InitLateFinalInstanceField()
    //     0x1269b18: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1269b1c: LoadField: r1 = r0->field_b
    //     0x1269b1c: ldur            w1, [x0, #0xb]
    // 0x1269b20: DecompressPointer r1
    //     0x1269b20: add             x1, x1, HEAP, lsl #32
    // 0x1269b24: mov             x0, x1
    // 0x1269b28: mov             x2, x0
    // 0x1269b2c: ldur            x0, [fp, #-0x10]
    // 0x1269b30: stur            x2, [fp, #-0x18]
    // 0x1269b34: r17 = 5167
    //     0x1269b34: mov             x17, #0x142f
    // 0x1269b38: cmp             x0, x17
    // 0x1269b3c: b.ne            #0x1269b54
    // 0x1269b40: ldr             x3, [fp, #0x18]
    // 0x1269b44: LoadField: r1 = r3->field_77
    //     0x1269b44: ldur            w1, [x3, #0x77]
    // 0x1269b48: DecompressPointer r1
    //     0x1269b48: add             x1, x1, HEAP, lsl #32
    // 0x1269b4c: mov             x0, x2
    // 0x1269b50: b               #0x1269c08
    // 0x1269b54: ldr             x3, [fp, #0x18]
    // 0x1269b58: r17 = 5168
    //     0x1269b58: mov             x17, #0x1430
    // 0x1269b5c: cmp             x0, x17
    // 0x1269b60: b.ne            #0x1269b74
    // 0x1269b64: mov             x0, x2
    // 0x1269b68: r1 = Instance_Color
    //     0x1269b68: add             x1, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x1269b6c: ldr             x1, [x1, #0x810]
    // 0x1269b70: b               #0x1269c08
    // 0x1269b74: mov             x1, x3
    // 0x1269b78: LoadField: r0 = r1->field_bb
    //     0x1269b78: ldur            w0, [x1, #0xbb]
    // 0x1269b7c: DecompressPointer r0
    //     0x1269b7c: add             x0, x0, HEAP, lsl #32
    // 0x1269b80: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1269b84: cmp             w0, w16
    // 0x1269b88: b.ne            #0x1269b98
    // 0x1269b8c: r2 = _isDark
    //     0x1269b8c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26408] Field <_DatePickerDefaultsM2@738353974._isDark@738353974>: late final (offset: 0xbc)
    //     0x1269b90: ldr             x2, [x2, #0x408]
    // 0x1269b94: r0 = InitLateFinalInstanceField()
    //     0x1269b94: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1269b98: tbnz            w0, #4, #0x1269bd0
    // 0x1269b9c: ldr             x1, [fp, #0x18]
    // 0x1269ba0: LoadField: r0 = r1->field_b3
    //     0x1269ba0: ldur            w0, [x1, #0xb3]
    // 0x1269ba4: DecompressPointer r0
    //     0x1269ba4: add             x0, x0, HEAP, lsl #32
    // 0x1269ba8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1269bac: cmp             w0, w16
    // 0x1269bb0: b.ne            #0x1269bc0
    // 0x1269bb4: r2 = _colors
    //     0x1269bb4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x1269bb8: ldr             x2, [x2, #0x410]
    // 0x1269bbc: r0 = InitLateFinalInstanceField()
    //     0x1269bbc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1269bc0: LoadField: r1 = r0->field_7b
    //     0x1269bc0: ldur            w1, [x0, #0x7b]
    // 0x1269bc4: DecompressPointer r1
    //     0x1269bc4: add             x1, x1, HEAP, lsl #32
    // 0x1269bc8: mov             x0, x1
    // 0x1269bcc: b               #0x1269c00
    // 0x1269bd0: ldr             x1, [fp, #0x18]
    // 0x1269bd4: LoadField: r0 = r1->field_b3
    //     0x1269bd4: ldur            w0, [x1, #0xb3]
    // 0x1269bd8: DecompressPointer r0
    //     0x1269bd8: add             x0, x0, HEAP, lsl #32
    // 0x1269bdc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1269be0: cmp             w0, w16
    // 0x1269be4: b.ne            #0x1269bf4
    // 0x1269be8: r2 = _colors
    //     0x1269be8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x1269bec: ldr             x2, [x2, #0x410]
    // 0x1269bf0: r0 = InitLateFinalInstanceField()
    //     0x1269bf0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1269bf4: LoadField: r1 = r0->field_b
    //     0x1269bf4: ldur            w1, [x0, #0xb]
    // 0x1269bf8: DecompressPointer r1
    //     0x1269bf8: add             x1, x1, HEAP, lsl #32
    // 0x1269bfc: mov             x0, x1
    // 0x1269c00: mov             x1, x0
    // 0x1269c04: ldur            x0, [fp, #-0x18]
    // 0x1269c08: r2 = LoadClassIdInstr(r0)
    //     0x1269c08: ldur            x2, [x0, #-1]
    //     0x1269c0c: ubfx            x2, x2, #0xc, #0x14
    // 0x1269c10: stp             x1, x0, [SP]
    // 0x1269c14: mov             x0, x2
    // 0x1269c18: mov             lr, x0
    // 0x1269c1c: ldr             lr, [x21, lr, lsl #3]
    // 0x1269c20: blr             lr
    // 0x1269c24: tbnz            w0, #4, #0x126aad8
    // 0x1269c28: ldur            x0, [fp, #-8]
    // 0x1269c2c: r17 = 5167
    //     0x1269c2c: mov             x17, #0x142f
    // 0x1269c30: cmp             x0, x17
    // 0x1269c34: b.ne            #0x1269c4c
    // 0x1269c38: ldr             x2, [fp, #0x10]
    // 0x1269c3c: LoadField: r1 = r2->field_7b
    //     0x1269c3c: ldur            w1, [x2, #0x7b]
    // 0x1269c40: DecompressPointer r1
    //     0x1269c40: add             x1, x1, HEAP, lsl #32
    // 0x1269c44: mov             x2, x1
    // 0x1269c48: b               #0x1269d3c
    // 0x1269c4c: ldr             x2, [fp, #0x10]
    // 0x1269c50: r17 = 5168
    //     0x1269c50: mov             x17, #0x1430
    // 0x1269c54: cmp             x0, x17
    // 0x1269c58: b.ne            #0x1269cac
    // 0x1269c5c: mov             x1, x2
    // 0x1269c60: LoadField: r0 = r1->field_b3
    //     0x1269c60: ldur            w0, [x1, #0xb3]
    // 0x1269c64: DecompressPointer r0
    //     0x1269c64: add             x0, x0, HEAP, lsl #32
    // 0x1269c68: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1269c6c: cmp             w0, w16
    // 0x1269c70: b.ne            #0x1269c80
    // 0x1269c74: r2 = _colors
    //     0x1269c74: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x1269c78: ldr             x2, [x2, #0x400]
    // 0x1269c7c: r0 = InitLateFinalInstanceField()
    //     0x1269c7c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1269c80: LoadField: r1 = r0->field_a3
    //     0x1269c80: ldur            w1, [x0, #0xa3]
    // 0x1269c84: DecompressPointer r1
    //     0x1269c84: add             x1, x1, HEAP, lsl #32
    // 0x1269c88: cmp             w1, NULL
    // 0x1269c8c: b.ne            #0x1269ca0
    // 0x1269c90: LoadField: r1 = r0->field_7f
    //     0x1269c90: ldur            w1, [x0, #0x7f]
    // 0x1269c94: DecompressPointer r1
    //     0x1269c94: add             x1, x1, HEAP, lsl #32
    // 0x1269c98: mov             x0, x1
    // 0x1269c9c: b               #0x1269ca4
    // 0x1269ca0: mov             x0, x1
    // 0x1269ca4: mov             x2, x0
    // 0x1269ca8: b               #0x1269d3c
    // 0x1269cac: ldr             x1, [fp, #0x10]
    // 0x1269cb0: LoadField: r0 = r1->field_bb
    //     0x1269cb0: ldur            w0, [x1, #0xbb]
    // 0x1269cb4: DecompressPointer r0
    //     0x1269cb4: add             x0, x0, HEAP, lsl #32
    // 0x1269cb8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1269cbc: cmp             w0, w16
    // 0x1269cc0: b.ne            #0x1269cd0
    // 0x1269cc4: r2 = _isDark
    //     0x1269cc4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26408] Field <_DatePickerDefaultsM2@738353974._isDark@738353974>: late final (offset: 0xbc)
    //     0x1269cc8: ldr             x2, [x2, #0x408]
    // 0x1269ccc: r0 = InitLateFinalInstanceField()
    //     0x1269ccc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1269cd0: tbnz            w0, #4, #0x1269d08
    // 0x1269cd4: ldr             x1, [fp, #0x10]
    // 0x1269cd8: LoadField: r0 = r1->field_b3
    //     0x1269cd8: ldur            w0, [x1, #0xb3]
    // 0x1269cdc: DecompressPointer r0
    //     0x1269cdc: add             x0, x0, HEAP, lsl #32
    // 0x1269ce0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1269ce4: cmp             w0, w16
    // 0x1269ce8: b.ne            #0x1269cf8
    // 0x1269cec: r2 = _colors
    //     0x1269cec: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x1269cf0: ldr             x2, [x2, #0x410]
    // 0x1269cf4: r0 = InitLateFinalInstanceField()
    //     0x1269cf4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1269cf8: LoadField: r1 = r0->field_7f
    //     0x1269cf8: ldur            w1, [x0, #0x7f]
    // 0x1269cfc: DecompressPointer r1
    //     0x1269cfc: add             x1, x1, HEAP, lsl #32
    // 0x1269d00: mov             x0, x1
    // 0x1269d04: b               #0x1269d38
    // 0x1269d08: ldr             x1, [fp, #0x10]
    // 0x1269d0c: LoadField: r0 = r1->field_b3
    //     0x1269d0c: ldur            w0, [x1, #0xb3]
    // 0x1269d10: DecompressPointer r0
    //     0x1269d10: add             x0, x0, HEAP, lsl #32
    // 0x1269d14: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1269d18: cmp             w0, w16
    // 0x1269d1c: b.ne            #0x1269d2c
    // 0x1269d20: r2 = _colors
    //     0x1269d20: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x1269d24: ldr             x2, [x2, #0x410]
    // 0x1269d28: r0 = InitLateFinalInstanceField()
    //     0x1269d28: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1269d2c: LoadField: r1 = r0->field_f
    //     0x1269d2c: ldur            w1, [x0, #0xf]
    // 0x1269d30: DecompressPointer r1
    //     0x1269d30: add             x1, x1, HEAP, lsl #32
    // 0x1269d34: mov             x0, x1
    // 0x1269d38: mov             x2, x0
    // 0x1269d3c: ldur            x0, [fp, #-0x10]
    // 0x1269d40: stur            x2, [fp, #-0x18]
    // 0x1269d44: r17 = 5167
    //     0x1269d44: mov             x17, #0x142f
    // 0x1269d48: cmp             x0, x17
    // 0x1269d4c: b.ne            #0x1269d64
    // 0x1269d50: ldr             x3, [fp, #0x18]
    // 0x1269d54: LoadField: r1 = r3->field_7b
    //     0x1269d54: ldur            w1, [x3, #0x7b]
    // 0x1269d58: DecompressPointer r1
    //     0x1269d58: add             x1, x1, HEAP, lsl #32
    // 0x1269d5c: mov             x0, x2
    // 0x1269d60: b               #0x1269e5c
    // 0x1269d64: ldr             x3, [fp, #0x18]
    // 0x1269d68: r17 = 5168
    //     0x1269d68: mov             x17, #0x1430
    // 0x1269d6c: cmp             x0, x17
    // 0x1269d70: b.ne            #0x1269dc8
    // 0x1269d74: mov             x1, x3
    // 0x1269d78: LoadField: r0 = r1->field_b3
    //     0x1269d78: ldur            w0, [x1, #0xb3]
    // 0x1269d7c: DecompressPointer r0
    //     0x1269d7c: add             x0, x0, HEAP, lsl #32
    // 0x1269d80: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1269d84: cmp             w0, w16
    // 0x1269d88: b.ne            #0x1269d98
    // 0x1269d8c: r2 = _colors
    //     0x1269d8c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x1269d90: ldr             x2, [x2, #0x400]
    // 0x1269d94: r0 = InitLateFinalInstanceField()
    //     0x1269d94: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1269d98: LoadField: r1 = r0->field_a3
    //     0x1269d98: ldur            w1, [x0, #0xa3]
    // 0x1269d9c: DecompressPointer r1
    //     0x1269d9c: add             x1, x1, HEAP, lsl #32
    // 0x1269da0: cmp             w1, NULL
    // 0x1269da4: b.ne            #0x1269db8
    // 0x1269da8: LoadField: r1 = r0->field_7f
    //     0x1269da8: ldur            w1, [x0, #0x7f]
    // 0x1269dac: DecompressPointer r1
    //     0x1269dac: add             x1, x1, HEAP, lsl #32
    // 0x1269db0: mov             x0, x1
    // 0x1269db4: b               #0x1269dbc
    // 0x1269db8: mov             x0, x1
    // 0x1269dbc: mov             x1, x0
    // 0x1269dc0: ldur            x0, [fp, #-0x18]
    // 0x1269dc4: b               #0x1269e5c
    // 0x1269dc8: ldr             x1, [fp, #0x18]
    // 0x1269dcc: LoadField: r0 = r1->field_bb
    //     0x1269dcc: ldur            w0, [x1, #0xbb]
    // 0x1269dd0: DecompressPointer r0
    //     0x1269dd0: add             x0, x0, HEAP, lsl #32
    // 0x1269dd4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1269dd8: cmp             w0, w16
    // 0x1269ddc: b.ne            #0x1269dec
    // 0x1269de0: r2 = _isDark
    //     0x1269de0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26408] Field <_DatePickerDefaultsM2@738353974._isDark@738353974>: late final (offset: 0xbc)
    //     0x1269de4: ldr             x2, [x2, #0x408]
    // 0x1269de8: r0 = InitLateFinalInstanceField()
    //     0x1269de8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1269dec: tbnz            w0, #4, #0x1269e24
    // 0x1269df0: ldr             x1, [fp, #0x18]
    // 0x1269df4: LoadField: r0 = r1->field_b3
    //     0x1269df4: ldur            w0, [x1, #0xb3]
    // 0x1269df8: DecompressPointer r0
    //     0x1269df8: add             x0, x0, HEAP, lsl #32
    // 0x1269dfc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1269e00: cmp             w0, w16
    // 0x1269e04: b.ne            #0x1269e14
    // 0x1269e08: r2 = _colors
    //     0x1269e08: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x1269e0c: ldr             x2, [x2, #0x410]
    // 0x1269e10: r0 = InitLateFinalInstanceField()
    //     0x1269e10: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1269e14: LoadField: r1 = r0->field_7f
    //     0x1269e14: ldur            w1, [x0, #0x7f]
    // 0x1269e18: DecompressPointer r1
    //     0x1269e18: add             x1, x1, HEAP, lsl #32
    // 0x1269e1c: mov             x0, x1
    // 0x1269e20: b               #0x1269e54
    // 0x1269e24: ldr             x1, [fp, #0x18]
    // 0x1269e28: LoadField: r0 = r1->field_b3
    //     0x1269e28: ldur            w0, [x1, #0xb3]
    // 0x1269e2c: DecompressPointer r0
    //     0x1269e2c: add             x0, x0, HEAP, lsl #32
    // 0x1269e30: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1269e34: cmp             w0, w16
    // 0x1269e38: b.ne            #0x1269e48
    // 0x1269e3c: r2 = _colors
    //     0x1269e3c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x1269e40: ldr             x2, [x2, #0x410]
    // 0x1269e44: r0 = InitLateFinalInstanceField()
    //     0x1269e44: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1269e48: LoadField: r1 = r0->field_f
    //     0x1269e48: ldur            w1, [x0, #0xf]
    // 0x1269e4c: DecompressPointer r1
    //     0x1269e4c: add             x1, x1, HEAP, lsl #32
    // 0x1269e50: mov             x0, x1
    // 0x1269e54: mov             x1, x0
    // 0x1269e58: ldur            x0, [fp, #-0x18]
    // 0x1269e5c: r2 = LoadClassIdInstr(r0)
    //     0x1269e5c: ldur            x2, [x0, #-1]
    //     0x1269e60: ubfx            x2, x2, #0xc, #0x14
    // 0x1269e64: stp             x1, x0, [SP]
    // 0x1269e68: mov             x0, x2
    // 0x1269e6c: mov             lr, x0
    // 0x1269e70: ldr             lr, [x21, lr, lsl #3]
    // 0x1269e74: blr             lr
    // 0x1269e78: tbnz            w0, #4, #0x126aad8
    // 0x1269e7c: ldur            x0, [fp, #-8]
    // 0x1269e80: r17 = 5167
    //     0x1269e80: mov             x17, #0x142f
    // 0x1269e84: cmp             x0, x17
    // 0x1269e88: b.ne            #0x1269ea0
    // 0x1269e8c: ldr             x2, [fp, #0x10]
    // 0x1269e90: LoadField: r1 = r2->field_7f
    //     0x1269e90: ldur            w1, [x2, #0x7f]
    // 0x1269e94: DecompressPointer r1
    //     0x1269e94: add             x1, x1, HEAP, lsl #32
    // 0x1269e98: mov             x2, x1
    // 0x1269e9c: b               #0x1269f14
    // 0x1269ea0: ldr             x2, [fp, #0x10]
    // 0x1269ea4: r17 = 5168
    //     0x1269ea4: mov             x17, #0x1430
    // 0x1269ea8: cmp             x0, x17
    // 0x1269eac: b.ne            #0x1269ee4
    // 0x1269eb0: mov             x1, x2
    // 0x1269eb4: LoadField: r0 = r1->field_b7
    //     0x1269eb4: ldur            w0, [x1, #0xb7]
    // 0x1269eb8: DecompressPointer r0
    //     0x1269eb8: add             x0, x0, HEAP, lsl #32
    // 0x1269ebc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1269ec0: cmp             w0, w16
    // 0x1269ec4: b.ne            #0x1269ed4
    // 0x1269ec8: r2 = _textTheme
    //     0x1269ec8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26418] Field <_DatePickerDefaultsM3@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0x1269ecc: ldr             x2, [x2, #0x418]
    // 0x1269ed0: r0 = InitLateFinalInstanceField()
    //     0x1269ed0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1269ed4: LoadField: r1 = r0->field_1f
    //     0x1269ed4: ldur            w1, [x0, #0x1f]
    // 0x1269ed8: DecompressPointer r1
    //     0x1269ed8: add             x1, x1, HEAP, lsl #32
    // 0x1269edc: mov             x2, x1
    // 0x1269ee0: b               #0x1269f14
    // 0x1269ee4: ldr             x1, [fp, #0x10]
    // 0x1269ee8: LoadField: r0 = r1->field_b7
    //     0x1269ee8: ldur            w0, [x1, #0xb7]
    // 0x1269eec: DecompressPointer r0
    //     0x1269eec: add             x0, x0, HEAP, lsl #32
    // 0x1269ef0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1269ef4: cmp             w0, w16
    // 0x1269ef8: b.ne            #0x1269f08
    // 0x1269efc: r2 = _textTheme
    //     0x1269efc: add             x2, PP, #0x26, lsl #12  ; [pp+0x26420] Field <_DatePickerDefaultsM2@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0x1269f00: ldr             x2, [x2, #0x420]
    // 0x1269f04: r0 = InitLateFinalInstanceField()
    //     0x1269f04: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1269f08: LoadField: r1 = r0->field_1b
    //     0x1269f08: ldur            w1, [x0, #0x1b]
    // 0x1269f0c: DecompressPointer r1
    //     0x1269f0c: add             x1, x1, HEAP, lsl #32
    // 0x1269f10: mov             x2, x1
    // 0x1269f14: ldur            x0, [fp, #-0x10]
    // 0x1269f18: stur            x2, [fp, #-0x18]
    // 0x1269f1c: r17 = 5167
    //     0x1269f1c: mov             x17, #0x142f
    // 0x1269f20: cmp             x0, x17
    // 0x1269f24: b.ne            #0x1269f3c
    // 0x1269f28: ldr             x3, [fp, #0x18]
    // 0x1269f2c: LoadField: r1 = r3->field_7f
    //     0x1269f2c: ldur            w1, [x3, #0x7f]
    // 0x1269f30: DecompressPointer r1
    //     0x1269f30: add             x1, x1, HEAP, lsl #32
    // 0x1269f34: mov             x0, x2
    // 0x1269f38: b               #0x1269fb0
    // 0x1269f3c: ldr             x3, [fp, #0x18]
    // 0x1269f40: r17 = 5168
    //     0x1269f40: mov             x17, #0x1430
    // 0x1269f44: cmp             x0, x17
    // 0x1269f48: b.ne            #0x1269f80
    // 0x1269f4c: mov             x1, x3
    // 0x1269f50: LoadField: r0 = r1->field_b7
    //     0x1269f50: ldur            w0, [x1, #0xb7]
    // 0x1269f54: DecompressPointer r0
    //     0x1269f54: add             x0, x0, HEAP, lsl #32
    // 0x1269f58: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1269f5c: cmp             w0, w16
    // 0x1269f60: b.ne            #0x1269f70
    // 0x1269f64: r2 = _textTheme
    //     0x1269f64: add             x2, PP, #0x26, lsl #12  ; [pp+0x26418] Field <_DatePickerDefaultsM3@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0x1269f68: ldr             x2, [x2, #0x418]
    // 0x1269f6c: r0 = InitLateFinalInstanceField()
    //     0x1269f6c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1269f70: LoadField: r1 = r0->field_1f
    //     0x1269f70: ldur            w1, [x0, #0x1f]
    // 0x1269f74: DecompressPointer r1
    //     0x1269f74: add             x1, x1, HEAP, lsl #32
    // 0x1269f78: ldur            x0, [fp, #-0x18]
    // 0x1269f7c: b               #0x1269fb0
    // 0x1269f80: ldr             x1, [fp, #0x18]
    // 0x1269f84: LoadField: r0 = r1->field_b7
    //     0x1269f84: ldur            w0, [x1, #0xb7]
    // 0x1269f88: DecompressPointer r0
    //     0x1269f88: add             x0, x0, HEAP, lsl #32
    // 0x1269f8c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1269f90: cmp             w0, w16
    // 0x1269f94: b.ne            #0x1269fa4
    // 0x1269f98: r2 = _textTheme
    //     0x1269f98: add             x2, PP, #0x26, lsl #12  ; [pp+0x26420] Field <_DatePickerDefaultsM2@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0x1269f9c: ldr             x2, [x2, #0x420]
    // 0x1269fa0: r0 = InitLateFinalInstanceField()
    //     0x1269fa0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1269fa4: LoadField: r1 = r0->field_1b
    //     0x1269fa4: ldur            w1, [x0, #0x1b]
    // 0x1269fa8: DecompressPointer r1
    //     0x1269fa8: add             x1, x1, HEAP, lsl #32
    // 0x1269fac: ldur            x0, [fp, #-0x18]
    // 0x1269fb0: r2 = LoadClassIdInstr(r0)
    //     0x1269fb0: ldur            x2, [x0, #-1]
    //     0x1269fb4: ubfx            x2, x2, #0xc, #0x14
    // 0x1269fb8: stp             x1, x0, [SP]
    // 0x1269fbc: mov             x0, x2
    // 0x1269fc0: mov             lr, x0
    // 0x1269fc4: ldr             lr, [x21, lr, lsl #3]
    // 0x1269fc8: blr             lr
    // 0x1269fcc: tbnz            w0, #4, #0x126aad8
    // 0x1269fd0: ldur            x0, [fp, #-8]
    // 0x1269fd4: r17 = 5167
    //     0x1269fd4: mov             x17, #0x142f
    // 0x1269fd8: cmp             x0, x17
    // 0x1269fdc: b.ne            #0x1269ff4
    // 0x1269fe0: ldr             x2, [fp, #0x10]
    // 0x1269fe4: LoadField: r1 = r2->field_83
    //     0x1269fe4: ldur            w1, [x2, #0x83]
    // 0x1269fe8: DecompressPointer r1
    //     0x1269fe8: add             x1, x1, HEAP, lsl #32
    // 0x1269fec: mov             x2, x1
    // 0x1269ff0: b               #0x126a068
    // 0x1269ff4: ldr             x2, [fp, #0x10]
    // 0x1269ff8: r17 = 5168
    //     0x1269ff8: mov             x17, #0x1430
    // 0x1269ffc: cmp             x0, x17
    // 0x126a000: b.ne            #0x126a038
    // 0x126a004: mov             x1, x2
    // 0x126a008: LoadField: r0 = r1->field_b7
    //     0x126a008: ldur            w0, [x1, #0xb7]
    // 0x126a00c: DecompressPointer r0
    //     0x126a00c: add             x0, x0, HEAP, lsl #32
    // 0x126a010: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126a014: cmp             w0, w16
    // 0x126a018: b.ne            #0x126a028
    // 0x126a01c: r2 = _textTheme
    //     0x126a01c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26418] Field <_DatePickerDefaultsM3@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0x126a020: ldr             x2, [x2, #0x418]
    // 0x126a024: r0 = InitLateFinalInstanceField()
    //     0x126a024: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126a028: LoadField: r1 = r0->field_27
    //     0x126a028: ldur            w1, [x0, #0x27]
    // 0x126a02c: DecompressPointer r1
    //     0x126a02c: add             x1, x1, HEAP, lsl #32
    // 0x126a030: mov             x2, x1
    // 0x126a034: b               #0x126a068
    // 0x126a038: ldr             x1, [fp, #0x10]
    // 0x126a03c: LoadField: r0 = r1->field_b7
    //     0x126a03c: ldur            w0, [x1, #0xb7]
    // 0x126a040: DecompressPointer r0
    //     0x126a040: add             x0, x0, HEAP, lsl #32
    // 0x126a044: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126a048: cmp             w0, w16
    // 0x126a04c: b.ne            #0x126a05c
    // 0x126a050: r2 = _textTheme
    //     0x126a050: add             x2, PP, #0x26, lsl #12  ; [pp+0x26420] Field <_DatePickerDefaultsM2@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0x126a054: ldr             x2, [x2, #0x420]
    // 0x126a058: r0 = InitLateFinalInstanceField()
    //     0x126a058: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126a05c: LoadField: r1 = r0->field_3f
    //     0x126a05c: ldur            w1, [x0, #0x3f]
    // 0x126a060: DecompressPointer r1
    //     0x126a060: add             x1, x1, HEAP, lsl #32
    // 0x126a064: mov             x2, x1
    // 0x126a068: ldur            x0, [fp, #-0x10]
    // 0x126a06c: stur            x2, [fp, #-0x18]
    // 0x126a070: r17 = 5167
    //     0x126a070: mov             x17, #0x142f
    // 0x126a074: cmp             x0, x17
    // 0x126a078: b.ne            #0x126a090
    // 0x126a07c: ldr             x3, [fp, #0x18]
    // 0x126a080: LoadField: r1 = r3->field_83
    //     0x126a080: ldur            w1, [x3, #0x83]
    // 0x126a084: DecompressPointer r1
    //     0x126a084: add             x1, x1, HEAP, lsl #32
    // 0x126a088: mov             x0, x2
    // 0x126a08c: b               #0x126a104
    // 0x126a090: ldr             x3, [fp, #0x18]
    // 0x126a094: r17 = 5168
    //     0x126a094: mov             x17, #0x1430
    // 0x126a098: cmp             x0, x17
    // 0x126a09c: b.ne            #0x126a0d4
    // 0x126a0a0: mov             x1, x3
    // 0x126a0a4: LoadField: r0 = r1->field_b7
    //     0x126a0a4: ldur            w0, [x1, #0xb7]
    // 0x126a0a8: DecompressPointer r0
    //     0x126a0a8: add             x0, x0, HEAP, lsl #32
    // 0x126a0ac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126a0b0: cmp             w0, w16
    // 0x126a0b4: b.ne            #0x126a0c4
    // 0x126a0b8: r2 = _textTheme
    //     0x126a0b8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26418] Field <_DatePickerDefaultsM3@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0x126a0bc: ldr             x2, [x2, #0x418]
    // 0x126a0c0: r0 = InitLateFinalInstanceField()
    //     0x126a0c0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126a0c4: LoadField: r1 = r0->field_27
    //     0x126a0c4: ldur            w1, [x0, #0x27]
    // 0x126a0c8: DecompressPointer r1
    //     0x126a0c8: add             x1, x1, HEAP, lsl #32
    // 0x126a0cc: ldur            x0, [fp, #-0x18]
    // 0x126a0d0: b               #0x126a104
    // 0x126a0d4: ldr             x1, [fp, #0x18]
    // 0x126a0d8: LoadField: r0 = r1->field_b7
    //     0x126a0d8: ldur            w0, [x1, #0xb7]
    // 0x126a0dc: DecompressPointer r0
    //     0x126a0dc: add             x0, x0, HEAP, lsl #32
    // 0x126a0e0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126a0e4: cmp             w0, w16
    // 0x126a0e8: b.ne            #0x126a0f8
    // 0x126a0ec: r2 = _textTheme
    //     0x126a0ec: add             x2, PP, #0x26, lsl #12  ; [pp+0x26420] Field <_DatePickerDefaultsM2@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0x126a0f0: ldr             x2, [x2, #0x420]
    // 0x126a0f4: r0 = InitLateFinalInstanceField()
    //     0x126a0f4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126a0f8: LoadField: r1 = r0->field_3f
    //     0x126a0f8: ldur            w1, [x0, #0x3f]
    // 0x126a0fc: DecompressPointer r1
    //     0x126a0fc: add             x1, x1, HEAP, lsl #32
    // 0x126a100: ldur            x0, [fp, #-0x18]
    // 0x126a104: r2 = LoadClassIdInstr(r0)
    //     0x126a104: ldur            x2, [x0, #-1]
    //     0x126a108: ubfx            x2, x2, #0xc, #0x14
    // 0x126a10c: stp             x1, x0, [SP]
    // 0x126a110: mov             x0, x2
    // 0x126a114: mov             lr, x0
    // 0x126a118: ldr             lr, [x21, lr, lsl #3]
    // 0x126a11c: blr             lr
    // 0x126a120: tbnz            w0, #4, #0x126aad8
    // 0x126a124: ldur            x0, [fp, #-8]
    // 0x126a128: r17 = 5167
    //     0x126a128: mov             x17, #0x142f
    // 0x126a12c: cmp             x0, x17
    // 0x126a130: b.ne            #0x126a148
    // 0x126a134: ldr             x2, [fp, #0x10]
    // 0x126a138: LoadField: r1 = r2->field_87
    //     0x126a138: ldur            w1, [x2, #0x87]
    // 0x126a13c: DecompressPointer r1
    //     0x126a13c: add             x1, x1, HEAP, lsl #32
    // 0x126a140: mov             x2, x1
    // 0x126a144: b               #0x126a1e4
    // 0x126a148: ldr             x2, [fp, #0x10]
    // 0x126a14c: r17 = 5168
    //     0x126a14c: mov             x17, #0x1430
    // 0x126a150: cmp             x0, x17
    // 0x126a154: b.ne            #0x126a1a8
    // 0x126a158: mov             x1, x2
    // 0x126a15c: LoadField: r0 = r1->field_b3
    //     0x126a15c: ldur            w0, [x1, #0xb3]
    // 0x126a160: DecompressPointer r0
    //     0x126a160: add             x0, x0, HEAP, lsl #32
    // 0x126a164: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126a168: cmp             w0, w16
    // 0x126a16c: b.ne            #0x126a17c
    // 0x126a170: r2 = _colors
    //     0x126a170: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x126a174: ldr             x2, [x2, #0x400]
    // 0x126a178: r0 = InitLateFinalInstanceField()
    //     0x126a178: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126a17c: LoadField: r1 = r0->field_33
    //     0x126a17c: ldur            w1, [x0, #0x33]
    // 0x126a180: DecompressPointer r1
    //     0x126a180: add             x1, x1, HEAP, lsl #32
    // 0x126a184: cmp             w1, NULL
    // 0x126a188: b.ne            #0x126a19c
    // 0x126a18c: LoadField: r1 = r0->field_2b
    //     0x126a18c: ldur            w1, [x0, #0x2b]
    // 0x126a190: DecompressPointer r1
    //     0x126a190: add             x1, x1, HEAP, lsl #32
    // 0x126a194: mov             x0, x1
    // 0x126a198: b               #0x126a1a0
    // 0x126a19c: mov             x0, x1
    // 0x126a1a0: mov             x2, x0
    // 0x126a1a4: b               #0x126a1e4
    // 0x126a1a8: ldr             x1, [fp, #0x10]
    // 0x126a1ac: LoadField: r0 = r1->field_b3
    //     0x126a1ac: ldur            w0, [x1, #0xb3]
    // 0x126a1b0: DecompressPointer r0
    //     0x126a1b0: add             x0, x0, HEAP, lsl #32
    // 0x126a1b4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126a1b8: cmp             w0, w16
    // 0x126a1bc: b.ne            #0x126a1cc
    // 0x126a1c0: r2 = _colors
    //     0x126a1c0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x126a1c4: ldr             x2, [x2, #0x410]
    // 0x126a1c8: r0 = InitLateFinalInstanceField()
    //     0x126a1c8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126a1cc: LoadField: r1 = r0->field_b
    //     0x126a1cc: ldur            w1, [x0, #0xb]
    // 0x126a1d0: DecompressPointer r1
    //     0x126a1d0: add             x1, x1, HEAP, lsl #32
    // 0x126a1d4: d0 = 0.120000
    //     0x126a1d4: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x126a1d8: ldr             d0, [x17, #0xc40]
    // 0x126a1dc: r0 = withOpacity()
    //     0x126a1dc: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x126a1e0: mov             x2, x0
    // 0x126a1e4: ldur            x0, [fp, #-0x10]
    // 0x126a1e8: stur            x2, [fp, #-0x18]
    // 0x126a1ec: r17 = 5167
    //     0x126a1ec: mov             x17, #0x142f
    // 0x126a1f0: cmp             x0, x17
    // 0x126a1f4: b.ne            #0x126a20c
    // 0x126a1f8: ldr             x3, [fp, #0x18]
    // 0x126a1fc: LoadField: r1 = r3->field_87
    //     0x126a1fc: ldur            w1, [x3, #0x87]
    // 0x126a200: DecompressPointer r1
    //     0x126a200: add             x1, x1, HEAP, lsl #32
    // 0x126a204: mov             x0, x2
    // 0x126a208: b               #0x126a2b0
    // 0x126a20c: ldr             x3, [fp, #0x18]
    // 0x126a210: r17 = 5168
    //     0x126a210: mov             x17, #0x1430
    // 0x126a214: cmp             x0, x17
    // 0x126a218: b.ne            #0x126a270
    // 0x126a21c: mov             x1, x3
    // 0x126a220: LoadField: r0 = r1->field_b3
    //     0x126a220: ldur            w0, [x1, #0xb3]
    // 0x126a224: DecompressPointer r0
    //     0x126a224: add             x0, x0, HEAP, lsl #32
    // 0x126a228: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126a22c: cmp             w0, w16
    // 0x126a230: b.ne            #0x126a240
    // 0x126a234: r2 = _colors
    //     0x126a234: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x126a238: ldr             x2, [x2, #0x400]
    // 0x126a23c: r0 = InitLateFinalInstanceField()
    //     0x126a23c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126a240: LoadField: r1 = r0->field_33
    //     0x126a240: ldur            w1, [x0, #0x33]
    // 0x126a244: DecompressPointer r1
    //     0x126a244: add             x1, x1, HEAP, lsl #32
    // 0x126a248: cmp             w1, NULL
    // 0x126a24c: b.ne            #0x126a260
    // 0x126a250: LoadField: r1 = r0->field_2b
    //     0x126a250: ldur            w1, [x0, #0x2b]
    // 0x126a254: DecompressPointer r1
    //     0x126a254: add             x1, x1, HEAP, lsl #32
    // 0x126a258: mov             x0, x1
    // 0x126a25c: b               #0x126a264
    // 0x126a260: mov             x0, x1
    // 0x126a264: mov             x1, x0
    // 0x126a268: ldur            x0, [fp, #-0x18]
    // 0x126a26c: b               #0x126a2b0
    // 0x126a270: ldr             x1, [fp, #0x18]
    // 0x126a274: LoadField: r0 = r1->field_b3
    //     0x126a274: ldur            w0, [x1, #0xb3]
    // 0x126a278: DecompressPointer r0
    //     0x126a278: add             x0, x0, HEAP, lsl #32
    // 0x126a27c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126a280: cmp             w0, w16
    // 0x126a284: b.ne            #0x126a294
    // 0x126a288: r2 = _colors
    //     0x126a288: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x126a28c: ldr             x2, [x2, #0x410]
    // 0x126a290: r0 = InitLateFinalInstanceField()
    //     0x126a290: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126a294: LoadField: r1 = r0->field_b
    //     0x126a294: ldur            w1, [x0, #0xb]
    // 0x126a298: DecompressPointer r1
    //     0x126a298: add             x1, x1, HEAP, lsl #32
    // 0x126a29c: d0 = 0.120000
    //     0x126a29c: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x126a2a0: ldr             d0, [x17, #0xc40]
    // 0x126a2a4: r0 = withOpacity()
    //     0x126a2a4: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x126a2a8: mov             x1, x0
    // 0x126a2ac: ldur            x0, [fp, #-0x18]
    // 0x126a2b0: r2 = LoadClassIdInstr(r0)
    //     0x126a2b0: ldur            x2, [x0, #-1]
    //     0x126a2b4: ubfx            x2, x2, #0xc, #0x14
    // 0x126a2b8: stp             x1, x0, [SP]
    // 0x126a2bc: mov             x0, x2
    // 0x126a2c0: mov             lr, x0
    // 0x126a2c4: ldr             lr, [x21, lr, lsl #3]
    // 0x126a2c8: blr             lr
    // 0x126a2cc: tbnz            w0, #4, #0x126aad8
    // 0x126a2d0: ldur            x0, [fp, #-8]
    // 0x126a2d4: r17 = 5167
    //     0x126a2d4: mov             x17, #0x142f
    // 0x126a2d8: cmp             x0, x17
    // 0x126a2dc: b.ne            #0x126a2f4
    // 0x126a2e0: ldr             x1, [fp, #0x10]
    // 0x126a2e4: LoadField: r2 = r1->field_8b
    //     0x126a2e4: ldur            w2, [x1, #0x8b]
    // 0x126a2e8: DecompressPointer r2
    //     0x126a2e8: add             x2, x2, HEAP, lsl #32
    // 0x126a2ec: mov             x1, x2
    // 0x126a2f0: b               #0x126a380
    // 0x126a2f4: ldr             x1, [fp, #0x10]
    // 0x126a2f8: r17 = 5168
    //     0x126a2f8: mov             x17, #0x1430
    // 0x126a2fc: cmp             x0, x17
    // 0x126a300: b.ne            #0x126a344
    // 0x126a304: r1 = 1
    //     0x126a304: mov             x1, #1
    // 0x126a308: r0 = AllocateContext()
    //     0x126a308: bl              #0x13de838  ; AllocateContextStub
    // 0x126a30c: mov             x1, x0
    // 0x126a310: ldr             x0, [fp, #0x10]
    // 0x126a314: StoreField: r1->field_f = r0
    //     0x126a314: stur            w0, [x1, #0xf]
    // 0x126a318: mov             x2, x1
    // 0x126a31c: r1 = Function '<anonymous closure>':.
    //     0x126a31c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26480] AnonymousClosure: (0x1132450), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM3
    //     0x126a320: ldr             x1, [x1, #0x480]
    // 0x126a324: r0 = AllocateClosure()
    //     0x126a324: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x126a328: r16 = <Color?>
    //     0x126a328: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x126a32c: ldr             x16, [x16, #0xa40]
    // 0x126a330: stp             x0, x16, [SP]
    // 0x126a334: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x126a334: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x126a338: r0 = resolveWith()
    //     0x126a338: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x126a33c: mov             x1, x0
    // 0x126a340: b               #0x126a380
    // 0x126a344: r1 = 1
    //     0x126a344: mov             x1, #1
    // 0x126a348: r0 = AllocateContext()
    //     0x126a348: bl              #0x13de838  ; AllocateContextStub
    // 0x126a34c: mov             x1, x0
    // 0x126a350: ldr             x0, [fp, #0x10]
    // 0x126a354: StoreField: r1->field_f = r0
    //     0x126a354: stur            w0, [x1, #0xf]
    // 0x126a358: mov             x2, x1
    // 0x126a35c: r1 = Function '<anonymous closure>':.
    //     0x126a35c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26488] AnonymousClosure: (0xdf2190), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM2
    //     0x126a360: ldr             x1, [x1, #0x488]
    // 0x126a364: r0 = AllocateClosure()
    //     0x126a364: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x126a368: r16 = <Color?>
    //     0x126a368: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x126a36c: ldr             x16, [x16, #0xa40]
    // 0x126a370: stp             x0, x16, [SP]
    // 0x126a374: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x126a374: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x126a378: r0 = resolveWith()
    //     0x126a378: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x126a37c: mov             x1, x0
    // 0x126a380: ldur            x0, [fp, #-0x10]
    // 0x126a384: stur            x1, [fp, #-0x18]
    // 0x126a388: r17 = 5167
    //     0x126a388: mov             x17, #0x142f
    // 0x126a38c: cmp             x0, x17
    // 0x126a390: b.ne            #0x126a3ac
    // 0x126a394: ldr             x2, [fp, #0x18]
    // 0x126a398: LoadField: r3 = r2->field_8b
    //     0x126a398: ldur            w3, [x2, #0x8b]
    // 0x126a39c: DecompressPointer r3
    //     0x126a39c: add             x3, x3, HEAP, lsl #32
    // 0x126a3a0: mov             x0, x1
    // 0x126a3a4: mov             x1, x3
    // 0x126a3a8: b               #0x126a444
    // 0x126a3ac: ldr             x2, [fp, #0x18]
    // 0x126a3b0: r17 = 5168
    //     0x126a3b0: mov             x17, #0x1430
    // 0x126a3b4: cmp             x0, x17
    // 0x126a3b8: b.ne            #0x126a400
    // 0x126a3bc: r1 = 1
    //     0x126a3bc: mov             x1, #1
    // 0x126a3c0: r0 = AllocateContext()
    //     0x126a3c0: bl              #0x13de838  ; AllocateContextStub
    // 0x126a3c4: mov             x1, x0
    // 0x126a3c8: ldr             x0, [fp, #0x18]
    // 0x126a3cc: StoreField: r1->field_f = r0
    //     0x126a3cc: stur            w0, [x1, #0xf]
    // 0x126a3d0: mov             x2, x1
    // 0x126a3d4: r1 = Function '<anonymous closure>':.
    //     0x126a3d4: add             x1, PP, #0x26, lsl #12  ; [pp+0x26480] AnonymousClosure: (0x1132450), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM3
    //     0x126a3d8: ldr             x1, [x1, #0x480]
    // 0x126a3dc: r0 = AllocateClosure()
    //     0x126a3dc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x126a3e0: r16 = <Color?>
    //     0x126a3e0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x126a3e4: ldr             x16, [x16, #0xa40]
    // 0x126a3e8: stp             x0, x16, [SP]
    // 0x126a3ec: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x126a3ec: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x126a3f0: r0 = resolveWith()
    //     0x126a3f0: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x126a3f4: mov             x1, x0
    // 0x126a3f8: ldur            x0, [fp, #-0x18]
    // 0x126a3fc: b               #0x126a444
    // 0x126a400: mov             x1, x2
    // 0x126a404: r1 = 1
    //     0x126a404: mov             x1, #1
    // 0x126a408: r0 = AllocateContext()
    //     0x126a408: bl              #0x13de838  ; AllocateContextStub
    // 0x126a40c: mov             x1, x0
    // 0x126a410: ldr             x0, [fp, #0x18]
    // 0x126a414: StoreField: r1->field_f = r0
    //     0x126a414: stur            w0, [x1, #0xf]
    // 0x126a418: mov             x2, x1
    // 0x126a41c: r1 = Function '<anonymous closure>':.
    //     0x126a41c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26488] AnonymousClosure: (0xdf2190), of [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM2
    //     0x126a420: ldr             x1, [x1, #0x488]
    // 0x126a424: r0 = AllocateClosure()
    //     0x126a424: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x126a428: r16 = <Color?>
    //     0x126a428: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x126a42c: ldr             x16, [x16, #0xa40]
    // 0x126a430: stp             x0, x16, [SP]
    // 0x126a434: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x126a434: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x126a438: r0 = resolveWith()
    //     0x126a438: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x126a43c: mov             x1, x0
    // 0x126a440: ldur            x0, [fp, #-0x18]
    // 0x126a444: cmp             w0, w1
    // 0x126a448: b.ne            #0x126aad8
    // 0x126a44c: ldur            x0, [fp, #-8]
    // 0x126a450: r17 = 5167
    //     0x126a450: mov             x17, #0x142f
    // 0x126a454: cmp             x0, x17
    // 0x126a458: b.ne            #0x126a470
    // 0x126a45c: ldr             x1, [fp, #0x10]
    // 0x126a460: LoadField: r2 = r1->field_97
    //     0x126a460: ldur            w2, [x1, #0x97]
    // 0x126a464: DecompressPointer r2
    //     0x126a464: add             x2, x2, HEAP, lsl #32
    // 0x126a468: mov             x1, x2
    // 0x126a46c: b               #0x126a4a4
    // 0x126a470: ldr             x1, [fp, #0x10]
    // 0x126a474: r17 = 5168
    //     0x126a474: mov             x17, #0x1430
    // 0x126a478: cmp             x0, x17
    // 0x126a47c: b.ne            #0x126a494
    // 0x126a480: r4 = const [0, 0, 0, 0, null]
    //     0x126a480: add             x4, PP, #0x1e, lsl #12  ; [pp+0x1eed8] List(5) [0, 0, 0, 0, Null]
    //     0x126a484: ldr             x4, [x4, #0xed8]
    // 0x126a488: r0 = styleFrom()
    //     0x126a488: bl              #0xd16538  ; [package:flutter/src/material/text_button.dart] TextButton::styleFrom
    // 0x126a48c: mov             x1, x0
    // 0x126a490: b               #0x126a4a4
    // 0x126a494: r4 = const [0, 0, 0, 0, null]
    //     0x126a494: add             x4, PP, #0x1e, lsl #12  ; [pp+0x1eed8] List(5) [0, 0, 0, 0, Null]
    //     0x126a498: ldr             x4, [x4, #0xed8]
    // 0x126a49c: r0 = styleFrom()
    //     0x126a49c: bl              #0xd16538  ; [package:flutter/src/material/text_button.dart] TextButton::styleFrom
    // 0x126a4a0: mov             x1, x0
    // 0x126a4a4: ldur            x0, [fp, #-0x10]
    // 0x126a4a8: stur            x1, [fp, #-0x18]
    // 0x126a4ac: r17 = 5167
    //     0x126a4ac: mov             x17, #0x142f
    // 0x126a4b0: cmp             x0, x17
    // 0x126a4b4: b.ne            #0x126a4d0
    // 0x126a4b8: ldr             x2, [fp, #0x18]
    // 0x126a4bc: LoadField: r3 = r2->field_97
    //     0x126a4bc: ldur            w3, [x2, #0x97]
    // 0x126a4c0: DecompressPointer r3
    //     0x126a4c0: add             x3, x3, HEAP, lsl #32
    // 0x126a4c4: mov             x0, x1
    // 0x126a4c8: mov             x1, x3
    // 0x126a4cc: b               #0x126a50c
    // 0x126a4d0: ldr             x2, [fp, #0x18]
    // 0x126a4d4: r17 = 5168
    //     0x126a4d4: mov             x17, #0x1430
    // 0x126a4d8: cmp             x0, x17
    // 0x126a4dc: b.ne            #0x126a4f8
    // 0x126a4e0: r4 = const [0, 0, 0, 0, null]
    //     0x126a4e0: add             x4, PP, #0x1e, lsl #12  ; [pp+0x1eed8] List(5) [0, 0, 0, 0, Null]
    //     0x126a4e4: ldr             x4, [x4, #0xed8]
    // 0x126a4e8: r0 = styleFrom()
    //     0x126a4e8: bl              #0xd16538  ; [package:flutter/src/material/text_button.dart] TextButton::styleFrom
    // 0x126a4ec: mov             x1, x0
    // 0x126a4f0: ldur            x0, [fp, #-0x18]
    // 0x126a4f4: b               #0x126a50c
    // 0x126a4f8: r4 = const [0, 0, 0, 0, null]
    //     0x126a4f8: add             x4, PP, #0x1e, lsl #12  ; [pp+0x1eed8] List(5) [0, 0, 0, 0, Null]
    //     0x126a4fc: ldr             x4, [x4, #0xed8]
    // 0x126a500: r0 = styleFrom()
    //     0x126a500: bl              #0xd16538  ; [package:flutter/src/material/text_button.dart] TextButton::styleFrom
    // 0x126a504: mov             x1, x0
    // 0x126a508: ldur            x0, [fp, #-0x18]
    // 0x126a50c: r2 = LoadClassIdInstr(r0)
    //     0x126a50c: ldur            x2, [x0, #-1]
    //     0x126a510: ubfx            x2, x2, #0xc, #0x14
    // 0x126a514: stp             x1, x0, [SP]
    // 0x126a518: mov             x0, x2
    // 0x126a51c: mov             lr, x0
    // 0x126a520: ldr             lr, [x21, lr, lsl #3]
    // 0x126a524: blr             lr
    // 0x126a528: tbnz            w0, #4, #0x126aad8
    // 0x126a52c: ldur            x0, [fp, #-8]
    // 0x126a530: r17 = 5167
    //     0x126a530: mov             x17, #0x142f
    // 0x126a534: cmp             x0, x17
    // 0x126a538: b.ne            #0x126a550
    // 0x126a53c: ldr             x1, [fp, #0x10]
    // 0x126a540: LoadField: r2 = r1->field_9b
    //     0x126a540: ldur            w2, [x1, #0x9b]
    // 0x126a544: DecompressPointer r2
    //     0x126a544: add             x2, x2, HEAP, lsl #32
    // 0x126a548: mov             x1, x2
    // 0x126a54c: b               #0x126a584
    // 0x126a550: ldr             x1, [fp, #0x10]
    // 0x126a554: r17 = 5168
    //     0x126a554: mov             x17, #0x1430
    // 0x126a558: cmp             x0, x17
    // 0x126a55c: b.ne            #0x126a574
    // 0x126a560: r4 = const [0, 0, 0, 0, null]
    //     0x126a560: add             x4, PP, #0x1e, lsl #12  ; [pp+0x1eed8] List(5) [0, 0, 0, 0, Null]
    //     0x126a564: ldr             x4, [x4, #0xed8]
    // 0x126a568: r0 = styleFrom()
    //     0x126a568: bl              #0xd16538  ; [package:flutter/src/material/text_button.dart] TextButton::styleFrom
    // 0x126a56c: mov             x1, x0
    // 0x126a570: b               #0x126a584
    // 0x126a574: r4 = const [0, 0, 0, 0, null]
    //     0x126a574: add             x4, PP, #0x1e, lsl #12  ; [pp+0x1eed8] List(5) [0, 0, 0, 0, Null]
    //     0x126a578: ldr             x4, [x4, #0xed8]
    // 0x126a57c: r0 = styleFrom()
    //     0x126a57c: bl              #0xd16538  ; [package:flutter/src/material/text_button.dart] TextButton::styleFrom
    // 0x126a580: mov             x1, x0
    // 0x126a584: ldur            x0, [fp, #-0x10]
    // 0x126a588: stur            x1, [fp, #-0x18]
    // 0x126a58c: r17 = 5167
    //     0x126a58c: mov             x17, #0x142f
    // 0x126a590: cmp             x0, x17
    // 0x126a594: b.ne            #0x126a5b0
    // 0x126a598: ldr             x2, [fp, #0x18]
    // 0x126a59c: LoadField: r3 = r2->field_9b
    //     0x126a59c: ldur            w3, [x2, #0x9b]
    // 0x126a5a0: DecompressPointer r3
    //     0x126a5a0: add             x3, x3, HEAP, lsl #32
    // 0x126a5a4: mov             x0, x1
    // 0x126a5a8: mov             x1, x3
    // 0x126a5ac: b               #0x126a5ec
    // 0x126a5b0: ldr             x2, [fp, #0x18]
    // 0x126a5b4: r17 = 5168
    //     0x126a5b4: mov             x17, #0x1430
    // 0x126a5b8: cmp             x0, x17
    // 0x126a5bc: b.ne            #0x126a5d8
    // 0x126a5c0: r4 = const [0, 0, 0, 0, null]
    //     0x126a5c0: add             x4, PP, #0x1e, lsl #12  ; [pp+0x1eed8] List(5) [0, 0, 0, 0, Null]
    //     0x126a5c4: ldr             x4, [x4, #0xed8]
    // 0x126a5c8: r0 = styleFrom()
    //     0x126a5c8: bl              #0xd16538  ; [package:flutter/src/material/text_button.dart] TextButton::styleFrom
    // 0x126a5cc: mov             x1, x0
    // 0x126a5d0: ldur            x0, [fp, #-0x18]
    // 0x126a5d4: b               #0x126a5ec
    // 0x126a5d8: r4 = const [0, 0, 0, 0, null]
    //     0x126a5d8: add             x4, PP, #0x1e, lsl #12  ; [pp+0x1eed8] List(5) [0, 0, 0, 0, Null]
    //     0x126a5dc: ldr             x4, [x4, #0xed8]
    // 0x126a5e0: r0 = styleFrom()
    //     0x126a5e0: bl              #0xd16538  ; [package:flutter/src/material/text_button.dart] TextButton::styleFrom
    // 0x126a5e4: mov             x1, x0
    // 0x126a5e8: ldur            x0, [fp, #-0x18]
    // 0x126a5ec: r2 = LoadClassIdInstr(r0)
    //     0x126a5ec: ldur            x2, [x0, #-1]
    //     0x126a5f0: ubfx            x2, x2, #0xc, #0x14
    // 0x126a5f4: stp             x1, x0, [SP]
    // 0x126a5f8: mov             x0, x2
    // 0x126a5fc: mov             lr, x0
    // 0x126a600: ldr             lr, [x21, lr, lsl #3]
    // 0x126a604: blr             lr
    // 0x126a608: tbnz            w0, #4, #0x126aad8
    // 0x126a60c: ldur            x0, [fp, #-8]
    // 0x126a610: r17 = 5167
    //     0x126a610: mov             x17, #0x142f
    // 0x126a614: cmp             x0, x17
    // 0x126a618: b.ne            #0x126a630
    // 0x126a61c: ldr             x2, [fp, #0x10]
    // 0x126a620: LoadField: r1 = r2->field_a3
    //     0x126a620: ldur            w1, [x2, #0xa3]
    // 0x126a624: DecompressPointer r1
    //     0x126a624: add             x1, x1, HEAP, lsl #32
    // 0x126a628: mov             x2, x1
    // 0x126a62c: b               #0x126a77c
    // 0x126a630: ldr             x2, [fp, #0x10]
    // 0x126a634: r17 = 5168
    //     0x126a634: mov             x17, #0x1430
    // 0x126a638: cmp             x0, x17
    // 0x126a63c: b.ne            #0x126a6e0
    // 0x126a640: mov             x1, x2
    // 0x126a644: LoadField: r0 = r1->field_b7
    //     0x126a644: ldur            w0, [x1, #0xb7]
    // 0x126a648: DecompressPointer r0
    //     0x126a648: add             x0, x0, HEAP, lsl #32
    // 0x126a64c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126a650: cmp             w0, w16
    // 0x126a654: b.ne            #0x126a664
    // 0x126a658: r2 = _textTheme
    //     0x126a658: add             x2, PP, #0x26, lsl #12  ; [pp+0x26418] Field <_DatePickerDefaultsM3@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0x126a65c: ldr             x2, [x2, #0x418]
    // 0x126a660: r0 = InitLateFinalInstanceField()
    //     0x126a660: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126a664: LoadField: r2 = r0->field_27
    //     0x126a664: ldur            w2, [x0, #0x27]
    // 0x126a668: DecompressPointer r2
    //     0x126a668: add             x2, x2, HEAP, lsl #32
    // 0x126a66c: stur            x2, [fp, #-0x18]
    // 0x126a670: cmp             w2, NULL
    // 0x126a674: b.ne            #0x126a680
    // 0x126a678: r0 = Null
    //     0x126a678: mov             x0, NULL
    // 0x126a67c: b               #0x126a6d8
    // 0x126a680: ldr             x1, [fp, #0x10]
    // 0x126a684: LoadField: r0 = r1->field_b3
    //     0x126a684: ldur            w0, [x1, #0xb3]
    // 0x126a688: DecompressPointer r0
    //     0x126a688: add             x0, x0, HEAP, lsl #32
    // 0x126a68c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126a690: cmp             w0, w16
    // 0x126a694: b.ne            #0x126a6a4
    // 0x126a698: r2 = _colors
    //     0x126a698: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x126a69c: ldr             x2, [x2, #0x400]
    // 0x126a6a0: r0 = InitLateFinalInstanceField()
    //     0x126a6a0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126a6a4: LoadField: r1 = r0->field_7f
    //     0x126a6a4: ldur            w1, [x0, #0x7f]
    // 0x126a6a8: DecompressPointer r1
    //     0x126a6a8: add             x1, x1, HEAP, lsl #32
    // 0x126a6ac: r0 = LoadClassIdInstr(r1)
    //     0x126a6ac: ldur            x0, [x1, #-1]
    //     0x126a6b0: ubfx            x0, x0, #0xc, #0x14
    // 0x126a6b4: d0 = 0.600000
    //     0x126a6b4: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c88] IMM: double(0.6) from 0x3fe3333333333333
    //     0x126a6b8: ldr             d0, [x17, #0xc88]
    // 0x126a6bc: r0 = GDT[cid_x0 + -0x1000]()
    //     0x126a6bc: sub             lr, x0, #1, lsl #12
    //     0x126a6c0: ldr             lr, [x21, lr, lsl #3]
    //     0x126a6c4: blr             lr
    // 0x126a6c8: ldur            x1, [fp, #-0x18]
    // 0x126a6cc: mov             x2, x0
    // 0x126a6d0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x126a6d0: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x126a6d4: r0 = apply()
    //     0x126a6d4: bl              #0x8acf20  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0x126a6d8: mov             x2, x0
    // 0x126a6dc: b               #0x126a77c
    // 0x126a6e0: ldr             x1, [fp, #0x10]
    // 0x126a6e4: LoadField: r0 = r1->field_b7
    //     0x126a6e4: ldur            w0, [x1, #0xb7]
    // 0x126a6e8: DecompressPointer r0
    //     0x126a6e8: add             x0, x0, HEAP, lsl #32
    // 0x126a6ec: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126a6f0: cmp             w0, w16
    // 0x126a6f4: b.ne            #0x126a704
    // 0x126a6f8: r2 = _textTheme
    //     0x126a6f8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26420] Field <_DatePickerDefaultsM2@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0x126a6fc: ldr             x2, [x2, #0x420]
    // 0x126a700: r0 = InitLateFinalInstanceField()
    //     0x126a700: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126a704: LoadField: r2 = r0->field_27
    //     0x126a704: ldur            w2, [x0, #0x27]
    // 0x126a708: DecompressPointer r2
    //     0x126a708: add             x2, x2, HEAP, lsl #32
    // 0x126a70c: stur            x2, [fp, #-0x18]
    // 0x126a710: cmp             w2, NULL
    // 0x126a714: b.ne            #0x126a720
    // 0x126a718: r0 = Null
    //     0x126a718: mov             x0, NULL
    // 0x126a71c: b               #0x126a778
    // 0x126a720: ldr             x1, [fp, #0x10]
    // 0x126a724: LoadField: r0 = r1->field_b3
    //     0x126a724: ldur            w0, [x1, #0xb3]
    // 0x126a728: DecompressPointer r0
    //     0x126a728: add             x0, x0, HEAP, lsl #32
    // 0x126a72c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126a730: cmp             w0, w16
    // 0x126a734: b.ne            #0x126a744
    // 0x126a738: r2 = _colors
    //     0x126a738: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x126a73c: ldr             x2, [x2, #0x410]
    // 0x126a740: r0 = InitLateFinalInstanceField()
    //     0x126a740: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126a744: LoadField: r1 = r0->field_7f
    //     0x126a744: ldur            w1, [x0, #0x7f]
    // 0x126a748: DecompressPointer r1
    //     0x126a748: add             x1, x1, HEAP, lsl #32
    // 0x126a74c: r0 = LoadClassIdInstr(r1)
    //     0x126a74c: ldur            x0, [x1, #-1]
    //     0x126a750: ubfx            x0, x0, #0xc, #0x14
    // 0x126a754: d0 = 0.600000
    //     0x126a754: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c88] IMM: double(0.6) from 0x3fe3333333333333
    //     0x126a758: ldr             d0, [x17, #0xc88]
    // 0x126a75c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x126a75c: sub             lr, x0, #1, lsl #12
    //     0x126a760: ldr             lr, [x21, lr, lsl #3]
    //     0x126a764: blr             lr
    // 0x126a768: ldur            x1, [fp, #-0x18]
    // 0x126a76c: mov             x2, x0
    // 0x126a770: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x126a770: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x126a774: r0 = apply()
    //     0x126a774: bl              #0x8acf20  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0x126a778: mov             x2, x0
    // 0x126a77c: ldur            x0, [fp, #-0x10]
    // 0x126a780: stur            x2, [fp, #-0x18]
    // 0x126a784: r17 = 5167
    //     0x126a784: mov             x17, #0x142f
    // 0x126a788: cmp             x0, x17
    // 0x126a78c: b.ne            #0x126a7a4
    // 0x126a790: ldr             x3, [fp, #0x18]
    // 0x126a794: LoadField: r1 = r3->field_a3
    //     0x126a794: ldur            w1, [x3, #0xa3]
    // 0x126a798: DecompressPointer r1
    //     0x126a798: add             x1, x1, HEAP, lsl #32
    // 0x126a79c: mov             x0, x2
    // 0x126a7a0: b               #0x126a8f8
    // 0x126a7a4: ldr             x3, [fp, #0x18]
    // 0x126a7a8: r17 = 5168
    //     0x126a7a8: mov             x17, #0x1430
    // 0x126a7ac: cmp             x0, x17
    // 0x126a7b0: b.ne            #0x126a858
    // 0x126a7b4: mov             x1, x3
    // 0x126a7b8: LoadField: r0 = r1->field_b7
    //     0x126a7b8: ldur            w0, [x1, #0xb7]
    // 0x126a7bc: DecompressPointer r0
    //     0x126a7bc: add             x0, x0, HEAP, lsl #32
    // 0x126a7c0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126a7c4: cmp             w0, w16
    // 0x126a7c8: b.ne            #0x126a7d8
    // 0x126a7cc: r2 = _textTheme
    //     0x126a7cc: add             x2, PP, #0x26, lsl #12  ; [pp+0x26418] Field <_DatePickerDefaultsM3@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0x126a7d0: ldr             x2, [x2, #0x418]
    // 0x126a7d4: r0 = InitLateFinalInstanceField()
    //     0x126a7d4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126a7d8: LoadField: r2 = r0->field_27
    //     0x126a7d8: ldur            w2, [x0, #0x27]
    // 0x126a7dc: DecompressPointer r2
    //     0x126a7dc: add             x2, x2, HEAP, lsl #32
    // 0x126a7e0: stur            x2, [fp, #-0x20]
    // 0x126a7e4: cmp             w2, NULL
    // 0x126a7e8: b.ne            #0x126a7f4
    // 0x126a7ec: r0 = Null
    //     0x126a7ec: mov             x0, NULL
    // 0x126a7f0: b               #0x126a84c
    // 0x126a7f4: ldr             x1, [fp, #0x18]
    // 0x126a7f8: LoadField: r0 = r1->field_b3
    //     0x126a7f8: ldur            w0, [x1, #0xb3]
    // 0x126a7fc: DecompressPointer r0
    //     0x126a7fc: add             x0, x0, HEAP, lsl #32
    // 0x126a800: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126a804: cmp             w0, w16
    // 0x126a808: b.ne            #0x126a818
    // 0x126a80c: r2 = _colors
    //     0x126a80c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x126a810: ldr             x2, [x2, #0x400]
    // 0x126a814: r0 = InitLateFinalInstanceField()
    //     0x126a814: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126a818: LoadField: r1 = r0->field_7f
    //     0x126a818: ldur            w1, [x0, #0x7f]
    // 0x126a81c: DecompressPointer r1
    //     0x126a81c: add             x1, x1, HEAP, lsl #32
    // 0x126a820: r0 = LoadClassIdInstr(r1)
    //     0x126a820: ldur            x0, [x1, #-1]
    //     0x126a824: ubfx            x0, x0, #0xc, #0x14
    // 0x126a828: d0 = 0.600000
    //     0x126a828: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c88] IMM: double(0.6) from 0x3fe3333333333333
    //     0x126a82c: ldr             d0, [x17, #0xc88]
    // 0x126a830: r0 = GDT[cid_x0 + -0x1000]()
    //     0x126a830: sub             lr, x0, #1, lsl #12
    //     0x126a834: ldr             lr, [x21, lr, lsl #3]
    //     0x126a838: blr             lr
    // 0x126a83c: ldur            x1, [fp, #-0x20]
    // 0x126a840: mov             x2, x0
    // 0x126a844: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x126a844: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x126a848: r0 = apply()
    //     0x126a848: bl              #0x8acf20  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0x126a84c: mov             x1, x0
    // 0x126a850: ldur            x0, [fp, #-0x18]
    // 0x126a854: b               #0x126a8f8
    // 0x126a858: ldr             x1, [fp, #0x18]
    // 0x126a85c: LoadField: r0 = r1->field_b7
    //     0x126a85c: ldur            w0, [x1, #0xb7]
    // 0x126a860: DecompressPointer r0
    //     0x126a860: add             x0, x0, HEAP, lsl #32
    // 0x126a864: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126a868: cmp             w0, w16
    // 0x126a86c: b.ne            #0x126a87c
    // 0x126a870: r2 = _textTheme
    //     0x126a870: add             x2, PP, #0x26, lsl #12  ; [pp+0x26420] Field <_DatePickerDefaultsM2@738353974._textTheme@738353974>: late final (offset: 0xb8)
    //     0x126a874: ldr             x2, [x2, #0x420]
    // 0x126a878: r0 = InitLateFinalInstanceField()
    //     0x126a878: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126a87c: LoadField: r2 = r0->field_27
    //     0x126a87c: ldur            w2, [x0, #0x27]
    // 0x126a880: DecompressPointer r2
    //     0x126a880: add             x2, x2, HEAP, lsl #32
    // 0x126a884: stur            x2, [fp, #-0x20]
    // 0x126a888: cmp             w2, NULL
    // 0x126a88c: b.ne            #0x126a898
    // 0x126a890: r0 = Null
    //     0x126a890: mov             x0, NULL
    // 0x126a894: b               #0x126a8f0
    // 0x126a898: ldr             x1, [fp, #0x18]
    // 0x126a89c: LoadField: r0 = r1->field_b3
    //     0x126a89c: ldur            w0, [x1, #0xb3]
    // 0x126a8a0: DecompressPointer r0
    //     0x126a8a0: add             x0, x0, HEAP, lsl #32
    // 0x126a8a4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126a8a8: cmp             w0, w16
    // 0x126a8ac: b.ne            #0x126a8bc
    // 0x126a8b0: r2 = _colors
    //     0x126a8b0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x126a8b4: ldr             x2, [x2, #0x410]
    // 0x126a8b8: r0 = InitLateFinalInstanceField()
    //     0x126a8b8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126a8bc: LoadField: r1 = r0->field_7f
    //     0x126a8bc: ldur            w1, [x0, #0x7f]
    // 0x126a8c0: DecompressPointer r1
    //     0x126a8c0: add             x1, x1, HEAP, lsl #32
    // 0x126a8c4: r0 = LoadClassIdInstr(r1)
    //     0x126a8c4: ldur            x0, [x1, #-1]
    //     0x126a8c8: ubfx            x0, x0, #0xc, #0x14
    // 0x126a8cc: d0 = 0.600000
    //     0x126a8cc: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c88] IMM: double(0.6) from 0x3fe3333333333333
    //     0x126a8d0: ldr             d0, [x17, #0xc88]
    // 0x126a8d4: r0 = GDT[cid_x0 + -0x1000]()
    //     0x126a8d4: sub             lr, x0, #1, lsl #12
    //     0x126a8d8: ldr             lr, [x21, lr, lsl #3]
    //     0x126a8dc: blr             lr
    // 0x126a8e0: ldur            x1, [fp, #-0x20]
    // 0x126a8e4: mov             x2, x0
    // 0x126a8e8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x126a8e8: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x126a8ec: r0 = apply()
    //     0x126a8ec: bl              #0x8acf20  ; [package:flutter/src/painting/text_style.dart] TextStyle::apply
    // 0x126a8f0: mov             x1, x0
    // 0x126a8f4: ldur            x0, [fp, #-0x18]
    // 0x126a8f8: r2 = LoadClassIdInstr(r0)
    //     0x126a8f8: ldur            x2, [x0, #-1]
    //     0x126a8fc: ubfx            x2, x2, #0xc, #0x14
    // 0x126a900: stp             x1, x0, [SP]
    // 0x126a904: mov             x0, x2
    // 0x126a908: mov             lr, x0
    // 0x126a90c: ldr             lr, [x21, lr, lsl #3]
    // 0x126a910: blr             lr
    // 0x126a914: tbnz            w0, #4, #0x126aad8
    // 0x126a918: ldur            x0, [fp, #-8]
    // 0x126a91c: r17 = 5167
    //     0x126a91c: mov             x17, #0x142f
    // 0x126a920: cmp             x0, x17
    // 0x126a924: b.ne            #0x126a93c
    // 0x126a928: ldr             x1, [fp, #0x10]
    // 0x126a92c: LoadField: r0 = r1->field_a7
    //     0x126a92c: ldur            w0, [x1, #0xa7]
    // 0x126a930: DecompressPointer r0
    //     0x126a930: add             x0, x0, HEAP, lsl #32
    // 0x126a934: mov             x2, x0
    // 0x126a938: b               #0x126a9e0
    // 0x126a93c: ldr             x1, [fp, #0x10]
    // 0x126a940: r17 = 5168
    //     0x126a940: mov             x17, #0x1430
    // 0x126a944: cmp             x0, x17
    // 0x126a948: b.ne            #0x126a998
    // 0x126a94c: LoadField: r0 = r1->field_b3
    //     0x126a94c: ldur            w0, [x1, #0xb3]
    // 0x126a950: DecompressPointer r0
    //     0x126a950: add             x0, x0, HEAP, lsl #32
    // 0x126a954: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126a958: cmp             w0, w16
    // 0x126a95c: b.ne            #0x126a96c
    // 0x126a960: r2 = _colors
    //     0x126a960: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x126a964: ldr             x2, [x2, #0x400]
    // 0x126a968: r0 = InitLateFinalInstanceField()
    //     0x126a968: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126a96c: LoadField: r1 = r0->field_7f
    //     0x126a96c: ldur            w1, [x0, #0x7f]
    // 0x126a970: DecompressPointer r1
    //     0x126a970: add             x1, x1, HEAP, lsl #32
    // 0x126a974: r0 = LoadClassIdInstr(r1)
    //     0x126a974: ldur            x0, [x1, #-1]
    //     0x126a978: ubfx            x0, x0, #0xc, #0x14
    // 0x126a97c: d0 = 0.600000
    //     0x126a97c: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c88] IMM: double(0.6) from 0x3fe3333333333333
    //     0x126a980: ldr             d0, [x17, #0xc88]
    // 0x126a984: r0 = GDT[cid_x0 + -0x1000]()
    //     0x126a984: sub             lr, x0, #1, lsl #12
    //     0x126a988: ldr             lr, [x21, lr, lsl #3]
    //     0x126a98c: blr             lr
    // 0x126a990: mov             x2, x0
    // 0x126a994: b               #0x126a9e0
    // 0x126a998: LoadField: r0 = r1->field_b3
    //     0x126a998: ldur            w0, [x1, #0xb3]
    // 0x126a99c: DecompressPointer r0
    //     0x126a99c: add             x0, x0, HEAP, lsl #32
    // 0x126a9a0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126a9a4: cmp             w0, w16
    // 0x126a9a8: b.ne            #0x126a9b8
    // 0x126a9ac: r2 = _colors
    //     0x126a9ac: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x126a9b0: ldr             x2, [x2, #0x410]
    // 0x126a9b4: r0 = InitLateFinalInstanceField()
    //     0x126a9b4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126a9b8: LoadField: r1 = r0->field_7f
    //     0x126a9b8: ldur            w1, [x0, #0x7f]
    // 0x126a9bc: DecompressPointer r1
    //     0x126a9bc: add             x1, x1, HEAP, lsl #32
    // 0x126a9c0: r0 = LoadClassIdInstr(r1)
    //     0x126a9c0: ldur            x0, [x1, #-1]
    //     0x126a9c4: ubfx            x0, x0, #0xc, #0x14
    // 0x126a9c8: d0 = 0.600000
    //     0x126a9c8: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c88] IMM: double(0.6) from 0x3fe3333333333333
    //     0x126a9cc: ldr             d0, [x17, #0xc88]
    // 0x126a9d0: r0 = GDT[cid_x0 + -0x1000]()
    //     0x126a9d0: sub             lr, x0, #1, lsl #12
    //     0x126a9d4: ldr             lr, [x21, lr, lsl #3]
    //     0x126a9d8: blr             lr
    // 0x126a9dc: mov             x2, x0
    // 0x126a9e0: ldur            x0, [fp, #-0x10]
    // 0x126a9e4: stur            x2, [fp, #-0x18]
    // 0x126a9e8: r17 = 5167
    //     0x126a9e8: mov             x17, #0x142f
    // 0x126a9ec: cmp             x0, x17
    // 0x126a9f0: b.ne            #0x126aa0c
    // 0x126a9f4: ldr             x1, [fp, #0x18]
    // 0x126a9f8: LoadField: r0 = r1->field_a7
    //     0x126a9f8: ldur            w0, [x1, #0xa7]
    // 0x126a9fc: DecompressPointer r0
    //     0x126a9fc: add             x0, x0, HEAP, lsl #32
    // 0x126aa00: mov             x1, x0
    // 0x126aa04: mov             x0, x2
    // 0x126aa08: b               #0x126aab8
    // 0x126aa0c: ldr             x1, [fp, #0x18]
    // 0x126aa10: r17 = 5168
    //     0x126aa10: mov             x17, #0x1430
    // 0x126aa14: cmp             x0, x17
    // 0x126aa18: b.ne            #0x126aa6c
    // 0x126aa1c: LoadField: r0 = r1->field_b3
    //     0x126aa1c: ldur            w0, [x1, #0xb3]
    // 0x126aa20: DecompressPointer r0
    //     0x126aa20: add             x0, x0, HEAP, lsl #32
    // 0x126aa24: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126aa28: cmp             w0, w16
    // 0x126aa2c: b.ne            #0x126aa3c
    // 0x126aa30: r2 = _colors
    //     0x126aa30: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x126aa34: ldr             x2, [x2, #0x400]
    // 0x126aa38: r0 = InitLateFinalInstanceField()
    //     0x126aa38: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126aa3c: LoadField: r1 = r0->field_7f
    //     0x126aa3c: ldur            w1, [x0, #0x7f]
    // 0x126aa40: DecompressPointer r1
    //     0x126aa40: add             x1, x1, HEAP, lsl #32
    // 0x126aa44: r0 = LoadClassIdInstr(r1)
    //     0x126aa44: ldur            x0, [x1, #-1]
    //     0x126aa48: ubfx            x0, x0, #0xc, #0x14
    // 0x126aa4c: d0 = 0.600000
    //     0x126aa4c: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c88] IMM: double(0.6) from 0x3fe3333333333333
    //     0x126aa50: ldr             d0, [x17, #0xc88]
    // 0x126aa54: r0 = GDT[cid_x0 + -0x1000]()
    //     0x126aa54: sub             lr, x0, #1, lsl #12
    //     0x126aa58: ldr             lr, [x21, lr, lsl #3]
    //     0x126aa5c: blr             lr
    // 0x126aa60: mov             x1, x0
    // 0x126aa64: ldur            x0, [fp, #-0x18]
    // 0x126aa68: b               #0x126aab8
    // 0x126aa6c: LoadField: r0 = r1->field_b3
    //     0x126aa6c: ldur            w0, [x1, #0xb3]
    // 0x126aa70: DecompressPointer r0
    //     0x126aa70: add             x0, x0, HEAP, lsl #32
    // 0x126aa74: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126aa78: cmp             w0, w16
    // 0x126aa7c: b.ne            #0x126aa8c
    // 0x126aa80: r2 = _colors
    //     0x126aa80: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x126aa84: ldr             x2, [x2, #0x410]
    // 0x126aa88: r0 = InitLateFinalInstanceField()
    //     0x126aa88: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126aa8c: LoadField: r1 = r0->field_7f
    //     0x126aa8c: ldur            w1, [x0, #0x7f]
    // 0x126aa90: DecompressPointer r1
    //     0x126aa90: add             x1, x1, HEAP, lsl #32
    // 0x126aa94: r0 = LoadClassIdInstr(r1)
    //     0x126aa94: ldur            x0, [x1, #-1]
    //     0x126aa98: ubfx            x0, x0, #0xc, #0x14
    // 0x126aa9c: d0 = 0.600000
    //     0x126aa9c: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c88] IMM: double(0.6) from 0x3fe3333333333333
    //     0x126aaa0: ldr             d0, [x17, #0xc88]
    // 0x126aaa4: r0 = GDT[cid_x0 + -0x1000]()
    //     0x126aaa4: sub             lr, x0, #1, lsl #12
    //     0x126aaa8: ldr             lr, [x21, lr, lsl #3]
    //     0x126aaac: blr             lr
    // 0x126aab0: mov             x1, x0
    // 0x126aab4: ldur            x0, [fp, #-0x18]
    // 0x126aab8: r2 = LoadClassIdInstr(r0)
    //     0x126aab8: ldur            x2, [x0, #-1]
    //     0x126aabc: ubfx            x2, x2, #0xc, #0x14
    // 0x126aac0: stp             x1, x0, [SP]
    // 0x126aac4: mov             x0, x2
    // 0x126aac8: mov             lr, x0
    // 0x126aacc: ldr             lr, [x21, lr, lsl #3]
    // 0x126aad0: blr             lr
    // 0x126aad4: b               #0x126aadc
    // 0x126aad8: r0 = false
    //     0x126aad8: add             x0, NULL, #0x30  ; false
    // 0x126aadc: LeaveFrame
    //     0x126aadc: mov             SP, fp
    //     0x126aae0: ldp             fp, lr, [SP], #0x10
    // 0x126aae4: ret
    //     0x126aae4: ret             
    // 0x126aae8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x126aae8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x126aaec: b               #0x1267b88
  }
}

// class id: 5168, size: 0xbc, field offset: 0xac
class _DatePickerDefaultsM3 extends DatePickerThemeData {

  late final ColorScheme _colors; // offset: 0xb4
  late final TextTheme _textTheme; // offset: 0xb8
  late final ThemeData _theme; // offset: 0xb0

  _ _DatePickerDefaultsM3(/* No info */) {
    // ** addr: 0xd0fedc, size: 0x84
    // 0xd0fedc: ldr             x9, [THR, #0x90]  ; THR::object_sentinel
    // 0xd0fee0: r8 = 6.000000
    //     0xd0fee0: add             x8, PP, #0x1c, lsl #12  ; [pp+0x1c438] 6
    //     0xd0fee4: ldr             x8, [x8, #0x438]
    // 0xd0fee8: r7 = Instance_RoundedRectangleBorder
    //     0xd0fee8: add             x7, PP, #0x26, lsl #12  ; [pp+0x26370] Obj!RoundedRectangleBorder@129ec41
    //     0xd0feec: ldr             x7, [x7, #0x370]
    // 0xd0fef0: r6 = Instance_WidgetStatePropertyAll
    //     0xd0fef0: add             x6, PP, #0x99, lsl #12  ; [pp+0x99d80] Obj!WidgetStatePropertyAll<OutlinedBorder>@128a051
    //     0xd0fef4: ldr             x6, [x6, #0xd80]
    // 0xd0fef8: r5 = Instance_WidgetStatePropertyAll
    //     0xd0fef8: add             x5, PP, #0x99, lsl #12  ; [pp+0x99d88] Obj!WidgetStatePropertyAll<OutlinedBorder>@128a041
    //     0xd0fefc: ldr             x5, [x5, #0xd88]
    // 0xd0ff00: r4 = 0.000000
    //     0xd0ff00: ldr             x4, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xd0ff04: r3 = Instance_RoundedRectangleBorder
    //     0xd0ff04: add             x3, PP, #0x26, lsl #12  ; [pp+0x26600] Obj!RoundedRectangleBorder@129ec31
    //     0xd0ff08: ldr             x3, [x3, #0x600]
    // 0xd0ff0c: mov             x0, x2
    // 0xd0ff10: StoreField: r1->field_af = r9
    //     0xd0ff10: stur            w9, [x1, #0xaf]
    // 0xd0ff14: StoreField: r1->field_b3 = r9
    //     0xd0ff14: stur            w9, [x1, #0xb3]
    // 0xd0ff18: StoreField: r1->field_b7 = r9
    //     0xd0ff18: stur            w9, [x1, #0xb7]
    // 0xd0ff1c: StoreField: r1->field_ab = r0
    //     0xd0ff1c: stur            w0, [x1, #0xab]
    //     0xd0ff20: ldurb           w16, [x1, #-1]
    //     0xd0ff24: ldurb           w17, [x0, #-1]
    //     0xd0ff28: and             x16, x17, x16, lsr #2
    //     0xd0ff2c: tst             x16, HEAP, lsr #32
    //     0xd0ff30: b.eq            #0xd0ff40
    //     0xd0ff34: str             lr, [SP, #-8]!
    //     0xd0ff38: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    //     0xd0ff3c: ldr             lr, [SP], #8
    // 0xd0ff40: StoreField: r1->field_b = r8
    //     0xd0ff40: stur            w8, [x1, #0xb]
    // 0xd0ff44: ArrayStore: r1[0] = r7  ; List_4
    //     0xd0ff44: stur            w7, [x1, #0x17]
    // 0xd0ff48: StoreField: r1->field_3f = r6
    //     0xd0ff48: stur            w6, [x1, #0x3f]
    // 0xd0ff4c: StoreField: r1->field_5f = r5
    //     0xd0ff4c: stur            w5, [x1, #0x5f]
    // 0xd0ff50: StoreField: r1->field_67 = r4
    //     0xd0ff50: stur            w4, [x1, #0x67]
    // 0xd0ff54: StoreField: r1->field_73 = r3
    //     0xd0ff54: stur            w3, [x1, #0x73]
    // 0xd0ff58: r0 = Null
    //     0xd0ff58: mov             x0, NULL
    // 0xd0ff5c: ret
    //     0xd0ff5c: ret             
  }
  ColorScheme _colors(_DatePickerDefaultsM3) {
    // ** addr: 0xd10378, size: 0x58
    // 0xd10378: EnterFrame
    //     0xd10378: stp             fp, lr, [SP, #-0x10]!
    //     0xd1037c: mov             fp, SP
    // 0xd10380: CheckStackOverflow
    //     0xd10380: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd10384: cmp             SP, x16
    //     0xd10388: b.ls            #0xd103c8
    // 0xd1038c: ldr             x1, [fp, #0x10]
    // 0xd10390: LoadField: r0 = r1->field_af
    //     0xd10390: ldur            w0, [x1, #0xaf]
    // 0xd10394: DecompressPointer r0
    //     0xd10394: add             x0, x0, HEAP, lsl #32
    // 0xd10398: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd1039c: cmp             w0, w16
    // 0xd103a0: b.ne            #0xd103b0
    // 0xd103a4: r2 = _theme
    //     0xd103a4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26498] Field <_DatePickerDefaultsM3@738353974._theme@738353974>: late final (offset: 0xb0)
    //     0xd103a8: ldr             x2, [x2, #0x498]
    // 0xd103ac: r0 = InitLateFinalInstanceField()
    //     0xd103ac: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd103b0: LoadField: r1 = r0->field_3f
    //     0xd103b0: ldur            w1, [x0, #0x3f]
    // 0xd103b4: DecompressPointer r1
    //     0xd103b4: add             x1, x1, HEAP, lsl #32
    // 0xd103b8: mov             x0, x1
    // 0xd103bc: LeaveFrame
    //     0xd103bc: mov             SP, fp
    //     0xd103c0: ldp             fp, lr, [SP], #0x10
    // 0xd103c4: ret
    //     0xd103c4: ret             
    // 0xd103c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd103c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd103cc: b               #0xd1038c
  }
  TextTheme _textTheme(_DatePickerDefaultsM3) {
    // ** addr: 0xd103d0, size: 0x58
    // 0xd103d0: EnterFrame
    //     0xd103d0: stp             fp, lr, [SP, #-0x10]!
    //     0xd103d4: mov             fp, SP
    // 0xd103d8: CheckStackOverflow
    //     0xd103d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd103dc: cmp             SP, x16
    //     0xd103e0: b.ls            #0xd10420
    // 0xd103e4: ldr             x1, [fp, #0x10]
    // 0xd103e8: LoadField: r0 = r1->field_af
    //     0xd103e8: ldur            w0, [x1, #0xaf]
    // 0xd103ec: DecompressPointer r0
    //     0xd103ec: add             x0, x0, HEAP, lsl #32
    // 0xd103f0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd103f4: cmp             w0, w16
    // 0xd103f8: b.ne            #0xd10408
    // 0xd103fc: r2 = _theme
    //     0xd103fc: add             x2, PP, #0x26, lsl #12  ; [pp+0x26498] Field <_DatePickerDefaultsM3@738353974._theme@738353974>: late final (offset: 0xb0)
    //     0xd10400: ldr             x2, [x2, #0x498]
    // 0xd10404: r0 = InitLateFinalInstanceField()
    //     0xd10404: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd10408: LoadField: r1 = r0->field_87
    //     0xd10408: ldur            w1, [x0, #0x87]
    // 0xd1040c: DecompressPointer r1
    //     0xd1040c: add             x1, x1, HEAP, lsl #32
    // 0xd10410: mov             x0, x1
    // 0xd10414: LeaveFrame
    //     0xd10414: mov             SP, fp
    //     0xd10418: ldp             fp, lr, [SP], #0x10
    // 0xd1041c: ret
    //     0xd1041c: ret             
    // 0xd10420: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd10420: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd10424: b               #0xd103e4
  }
  [closure] Color? <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xdf2558, size: 0x3c8
    // 0xdf2558: EnterFrame
    //     0xdf2558: stp             fp, lr, [SP, #-0x10]!
    //     0xdf255c: mov             fp, SP
    // 0xdf2560: AllocStack(0x8)
    //     0xdf2560: sub             SP, SP, #8
    // 0xdf2564: SetupParameters([dynamic _ /* r0 */])
    //     0xdf2564: ldr             x0, [fp, #0x18]
    //     0xdf2568: ldur            w3, [x0, #0x17]
    //     0xdf256c: add             x3, x3, HEAP, lsl #32
    //     0xdf2570: stur            x3, [fp, #-8]
    // 0xdf2574: CheckStackOverflow
    //     0xdf2574: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf2578: cmp             SP, x16
    //     0xdf257c: b.ls            #0xdf2918
    // 0xdf2580: ldr             x4, [fp, #0x10]
    // 0xdf2584: r0 = LoadClassIdInstr(r4)
    //     0xdf2584: ldur            x0, [x4, #-1]
    //     0xdf2588: ubfx            x0, x0, #0xc, #0x14
    // 0xdf258c: mov             x1, x4
    // 0xdf2590: r2 = Instance_WidgetState
    //     0xdf2590: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xdf2594: ldr             x2, [x2, #0x100]
    // 0xdf2598: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdf2598: mov             x17, #0x2929
    //     0xdf259c: movk            x17, #1, lsl #16
    //     0xdf25a0: add             lr, x0, x17
    //     0xdf25a4: ldr             lr, [x21, lr, lsl #3]
    //     0xdf25a8: blr             lr
    // 0xdf25ac: tbnz            w0, #4, #0xdf272c
    // 0xdf25b0: ldr             x3, [fp, #0x10]
    // 0xdf25b4: r0 = LoadClassIdInstr(r3)
    //     0xdf25b4: ldur            x0, [x3, #-1]
    //     0xdf25b8: ubfx            x0, x0, #0xc, #0x14
    // 0xdf25bc: mov             x1, x3
    // 0xdf25c0: r2 = Instance_WidgetState
    //     0xdf25c0: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0xdf25c4: ldr             x2, [x2, #0xa48]
    // 0xdf25c8: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdf25c8: mov             x17, #0x2929
    //     0xdf25cc: movk            x17, #1, lsl #16
    //     0xdf25d0: add             lr, x0, x17
    //     0xdf25d4: ldr             lr, [x21, lr, lsl #3]
    //     0xdf25d8: blr             lr
    // 0xdf25dc: tbnz            w0, #4, #0xdf262c
    // 0xdf25e0: ldur            x3, [fp, #-8]
    // 0xdf25e4: LoadField: r1 = r3->field_f
    //     0xdf25e4: ldur            w1, [x3, #0xf]
    // 0xdf25e8: DecompressPointer r1
    //     0xdf25e8: add             x1, x1, HEAP, lsl #32
    // 0xdf25ec: LoadField: r0 = r1->field_b3
    //     0xdf25ec: ldur            w0, [x1, #0xb3]
    // 0xdf25f0: DecompressPointer r0
    //     0xdf25f0: add             x0, x0, HEAP, lsl #32
    // 0xdf25f4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf25f8: cmp             w0, w16
    // 0xdf25fc: b.ne            #0xdf260c
    // 0xdf2600: r2 = _colors
    //     0xdf2600: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xdf2604: ldr             x2, [x2, #0x400]
    // 0xdf2608: r0 = InitLateFinalInstanceField()
    //     0xdf2608: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf260c: LoadField: r1 = r0->field_f
    //     0xdf260c: ldur            w1, [x0, #0xf]
    // 0xdf2610: DecompressPointer r1
    //     0xdf2610: add             x1, x1, HEAP, lsl #32
    // 0xdf2614: d0 = 0.100000
    //     0xdf2614: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0xdf2618: ldr             d0, [x17, #0x1e0]
    // 0xdf261c: r0 = withOpacity()
    //     0xdf261c: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xdf2620: LeaveFrame
    //     0xdf2620: mov             SP, fp
    //     0xdf2624: ldp             fp, lr, [SP], #0x10
    // 0xdf2628: ret
    //     0xdf2628: ret             
    // 0xdf262c: ldr             x4, [fp, #0x10]
    // 0xdf2630: ldur            x3, [fp, #-8]
    // 0xdf2634: r0 = LoadClassIdInstr(r4)
    //     0xdf2634: ldur            x0, [x4, #-1]
    //     0xdf2638: ubfx            x0, x0, #0xc, #0x14
    // 0xdf263c: mov             x1, x4
    // 0xdf2640: r2 = Instance_WidgetState
    //     0xdf2640: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xdf2644: ldr             x2, [x2, #0xa50]
    // 0xdf2648: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdf2648: mov             x17, #0x2929
    //     0xdf264c: movk            x17, #1, lsl #16
    //     0xdf2650: add             lr, x0, x17
    //     0xdf2654: ldr             lr, [x21, lr, lsl #3]
    //     0xdf2658: blr             lr
    // 0xdf265c: tbnz            w0, #4, #0xdf26ac
    // 0xdf2660: ldur            x3, [fp, #-8]
    // 0xdf2664: LoadField: r1 = r3->field_f
    //     0xdf2664: ldur            w1, [x3, #0xf]
    // 0xdf2668: DecompressPointer r1
    //     0xdf2668: add             x1, x1, HEAP, lsl #32
    // 0xdf266c: LoadField: r0 = r1->field_b3
    //     0xdf266c: ldur            w0, [x1, #0xb3]
    // 0xdf2670: DecompressPointer r0
    //     0xdf2670: add             x0, x0, HEAP, lsl #32
    // 0xdf2674: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf2678: cmp             w0, w16
    // 0xdf267c: b.ne            #0xdf268c
    // 0xdf2680: r2 = _colors
    //     0xdf2680: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xdf2684: ldr             x2, [x2, #0x400]
    // 0xdf2688: r0 = InitLateFinalInstanceField()
    //     0xdf2688: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf268c: LoadField: r1 = r0->field_f
    //     0xdf268c: ldur            w1, [x0, #0xf]
    // 0xdf2690: DecompressPointer r1
    //     0xdf2690: add             x1, x1, HEAP, lsl #32
    // 0xdf2694: d0 = 0.080000
    //     0xdf2694: add             x17, PP, #0x15, lsl #12  ; [pp+0x15a58] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0xdf2698: ldr             d0, [x17, #0xa58]
    // 0xdf269c: r0 = withOpacity()
    //     0xdf269c: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xdf26a0: LeaveFrame
    //     0xdf26a0: mov             SP, fp
    //     0xdf26a4: ldp             fp, lr, [SP], #0x10
    // 0xdf26a8: ret
    //     0xdf26a8: ret             
    // 0xdf26ac: ldr             x4, [fp, #0x10]
    // 0xdf26b0: ldur            x3, [fp, #-8]
    // 0xdf26b4: r0 = LoadClassIdInstr(r4)
    //     0xdf26b4: ldur            x0, [x4, #-1]
    //     0xdf26b8: ubfx            x0, x0, #0xc, #0x14
    // 0xdf26bc: mov             x1, x4
    // 0xdf26c0: r2 = Instance_WidgetState
    //     0xdf26c0: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xdf26c4: ldr             x2, [x2, #0xa60]
    // 0xdf26c8: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdf26c8: mov             x17, #0x2929
    //     0xdf26cc: movk            x17, #1, lsl #16
    //     0xdf26d0: add             lr, x0, x17
    //     0xdf26d4: ldr             lr, [x21, lr, lsl #3]
    //     0xdf26d8: blr             lr
    // 0xdf26dc: tbnz            w0, #4, #0xdf2908
    // 0xdf26e0: ldur            x3, [fp, #-8]
    // 0xdf26e4: LoadField: r1 = r3->field_f
    //     0xdf26e4: ldur            w1, [x3, #0xf]
    // 0xdf26e8: DecompressPointer r1
    //     0xdf26e8: add             x1, x1, HEAP, lsl #32
    // 0xdf26ec: LoadField: r0 = r1->field_b3
    //     0xdf26ec: ldur            w0, [x1, #0xb3]
    // 0xdf26f0: DecompressPointer r0
    //     0xdf26f0: add             x0, x0, HEAP, lsl #32
    // 0xdf26f4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf26f8: cmp             w0, w16
    // 0xdf26fc: b.ne            #0xdf270c
    // 0xdf2700: r2 = _colors
    //     0xdf2700: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xdf2704: ldr             x2, [x2, #0x400]
    // 0xdf2708: r0 = InitLateFinalInstanceField()
    //     0xdf2708: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf270c: LoadField: r1 = r0->field_f
    //     0xdf270c: ldur            w1, [x0, #0xf]
    // 0xdf2710: DecompressPointer r1
    //     0xdf2710: add             x1, x1, HEAP, lsl #32
    // 0xdf2714: d0 = 0.100000
    //     0xdf2714: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0xdf2718: ldr             d0, [x17, #0x1e0]
    // 0xdf271c: r0 = withOpacity()
    //     0xdf271c: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xdf2720: LeaveFrame
    //     0xdf2720: mov             SP, fp
    //     0xdf2724: ldp             fp, lr, [SP], #0x10
    // 0xdf2728: ret
    //     0xdf2728: ret             
    // 0xdf272c: ldr             x4, [fp, #0x10]
    // 0xdf2730: ldur            x3, [fp, #-8]
    // 0xdf2734: r0 = LoadClassIdInstr(r4)
    //     0xdf2734: ldur            x0, [x4, #-1]
    //     0xdf2738: ubfx            x0, x0, #0xc, #0x14
    // 0xdf273c: mov             x1, x4
    // 0xdf2740: r2 = Instance_WidgetState
    //     0xdf2740: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0xdf2744: ldr             x2, [x2, #0xa48]
    // 0xdf2748: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdf2748: mov             x17, #0x2929
    //     0xdf274c: movk            x17, #1, lsl #16
    //     0xdf2750: add             lr, x0, x17
    //     0xdf2754: ldr             lr, [x21, lr, lsl #3]
    //     0xdf2758: blr             lr
    // 0xdf275c: tbnz            w0, #4, #0xdf27cc
    // 0xdf2760: ldur            x3, [fp, #-8]
    // 0xdf2764: LoadField: r1 = r3->field_f
    //     0xdf2764: ldur            w1, [x3, #0xf]
    // 0xdf2768: DecompressPointer r1
    //     0xdf2768: add             x1, x1, HEAP, lsl #32
    // 0xdf276c: LoadField: r0 = r1->field_b3
    //     0xdf276c: ldur            w0, [x1, #0xb3]
    // 0xdf2770: DecompressPointer r0
    //     0xdf2770: add             x0, x0, HEAP, lsl #32
    // 0xdf2774: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf2778: cmp             w0, w16
    // 0xdf277c: b.ne            #0xdf278c
    // 0xdf2780: r2 = _colors
    //     0xdf2780: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xdf2784: ldr             x2, [x2, #0x400]
    // 0xdf2788: r0 = InitLateFinalInstanceField()
    //     0xdf2788: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf278c: LoadField: r1 = r0->field_a3
    //     0xdf278c: ldur            w1, [x0, #0xa3]
    // 0xdf2790: DecompressPointer r1
    //     0xdf2790: add             x1, x1, HEAP, lsl #32
    // 0xdf2794: cmp             w1, NULL
    // 0xdf2798: b.ne            #0xdf27a4
    // 0xdf279c: LoadField: r1 = r0->field_7f
    //     0xdf279c: ldur            w1, [x0, #0x7f]
    // 0xdf27a0: DecompressPointer r1
    //     0xdf27a0: add             x1, x1, HEAP, lsl #32
    // 0xdf27a4: r0 = LoadClassIdInstr(r1)
    //     0xdf27a4: ldur            x0, [x1, #-1]
    //     0xdf27a8: ubfx            x0, x0, #0xc, #0x14
    // 0xdf27ac: d0 = 0.100000
    //     0xdf27ac: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0xdf27b0: ldr             d0, [x17, #0x1e0]
    // 0xdf27b4: r0 = GDT[cid_x0 + -0x1000]()
    //     0xdf27b4: sub             lr, x0, #1, lsl #12
    //     0xdf27b8: ldr             lr, [x21, lr, lsl #3]
    //     0xdf27bc: blr             lr
    // 0xdf27c0: LeaveFrame
    //     0xdf27c0: mov             SP, fp
    //     0xdf27c4: ldp             fp, lr, [SP], #0x10
    // 0xdf27c8: ret
    //     0xdf27c8: ret             
    // 0xdf27cc: ldr             x4, [fp, #0x10]
    // 0xdf27d0: ldur            x3, [fp, #-8]
    // 0xdf27d4: r0 = LoadClassIdInstr(r4)
    //     0xdf27d4: ldur            x0, [x4, #-1]
    //     0xdf27d8: ubfx            x0, x0, #0xc, #0x14
    // 0xdf27dc: mov             x1, x4
    // 0xdf27e0: r2 = Instance_WidgetState
    //     0xdf27e0: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xdf27e4: ldr             x2, [x2, #0xa50]
    // 0xdf27e8: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdf27e8: mov             x17, #0x2929
    //     0xdf27ec: movk            x17, #1, lsl #16
    //     0xdf27f0: add             lr, x0, x17
    //     0xdf27f4: ldr             lr, [x21, lr, lsl #3]
    //     0xdf27f8: blr             lr
    // 0xdf27fc: tbnz            w0, #4, #0xdf286c
    // 0xdf2800: ldur            x3, [fp, #-8]
    // 0xdf2804: LoadField: r1 = r3->field_f
    //     0xdf2804: ldur            w1, [x3, #0xf]
    // 0xdf2808: DecompressPointer r1
    //     0xdf2808: add             x1, x1, HEAP, lsl #32
    // 0xdf280c: LoadField: r0 = r1->field_b3
    //     0xdf280c: ldur            w0, [x1, #0xb3]
    // 0xdf2810: DecompressPointer r0
    //     0xdf2810: add             x0, x0, HEAP, lsl #32
    // 0xdf2814: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf2818: cmp             w0, w16
    // 0xdf281c: b.ne            #0xdf282c
    // 0xdf2820: r2 = _colors
    //     0xdf2820: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xdf2824: ldr             x2, [x2, #0x400]
    // 0xdf2828: r0 = InitLateFinalInstanceField()
    //     0xdf2828: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf282c: LoadField: r1 = r0->field_a3
    //     0xdf282c: ldur            w1, [x0, #0xa3]
    // 0xdf2830: DecompressPointer r1
    //     0xdf2830: add             x1, x1, HEAP, lsl #32
    // 0xdf2834: cmp             w1, NULL
    // 0xdf2838: b.ne            #0xdf2844
    // 0xdf283c: LoadField: r1 = r0->field_7f
    //     0xdf283c: ldur            w1, [x0, #0x7f]
    // 0xdf2840: DecompressPointer r1
    //     0xdf2840: add             x1, x1, HEAP, lsl #32
    // 0xdf2844: r0 = LoadClassIdInstr(r1)
    //     0xdf2844: ldur            x0, [x1, #-1]
    //     0xdf2848: ubfx            x0, x0, #0xc, #0x14
    // 0xdf284c: d0 = 0.080000
    //     0xdf284c: add             x17, PP, #0x15, lsl #12  ; [pp+0x15a58] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0xdf2850: ldr             d0, [x17, #0xa58]
    // 0xdf2854: r0 = GDT[cid_x0 + -0x1000]()
    //     0xdf2854: sub             lr, x0, #1, lsl #12
    //     0xdf2858: ldr             lr, [x21, lr, lsl #3]
    //     0xdf285c: blr             lr
    // 0xdf2860: LeaveFrame
    //     0xdf2860: mov             SP, fp
    //     0xdf2864: ldp             fp, lr, [SP], #0x10
    // 0xdf2868: ret
    //     0xdf2868: ret             
    // 0xdf286c: ldr             x1, [fp, #0x10]
    // 0xdf2870: ldur            x3, [fp, #-8]
    // 0xdf2874: r0 = LoadClassIdInstr(r1)
    //     0xdf2874: ldur            x0, [x1, #-1]
    //     0xdf2878: ubfx            x0, x0, #0xc, #0x14
    // 0xdf287c: r2 = Instance_WidgetState
    //     0xdf287c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xdf2880: ldr             x2, [x2, #0xa60]
    // 0xdf2884: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdf2884: mov             x17, #0x2929
    //     0xdf2888: movk            x17, #1, lsl #16
    //     0xdf288c: add             lr, x0, x17
    //     0xdf2890: ldr             lr, [x21, lr, lsl #3]
    //     0xdf2894: blr             lr
    // 0xdf2898: tbnz            w0, #4, #0xdf2908
    // 0xdf289c: ldur            x0, [fp, #-8]
    // 0xdf28a0: LoadField: r1 = r0->field_f
    //     0xdf28a0: ldur            w1, [x0, #0xf]
    // 0xdf28a4: DecompressPointer r1
    //     0xdf28a4: add             x1, x1, HEAP, lsl #32
    // 0xdf28a8: LoadField: r0 = r1->field_b3
    //     0xdf28a8: ldur            w0, [x1, #0xb3]
    // 0xdf28ac: DecompressPointer r0
    //     0xdf28ac: add             x0, x0, HEAP, lsl #32
    // 0xdf28b0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf28b4: cmp             w0, w16
    // 0xdf28b8: b.ne            #0xdf28c8
    // 0xdf28bc: r2 = _colors
    //     0xdf28bc: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xdf28c0: ldr             x2, [x2, #0x400]
    // 0xdf28c4: r0 = InitLateFinalInstanceField()
    //     0xdf28c4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf28c8: LoadField: r1 = r0->field_a3
    //     0xdf28c8: ldur            w1, [x0, #0xa3]
    // 0xdf28cc: DecompressPointer r1
    //     0xdf28cc: add             x1, x1, HEAP, lsl #32
    // 0xdf28d0: cmp             w1, NULL
    // 0xdf28d4: b.ne            #0xdf28e0
    // 0xdf28d8: LoadField: r1 = r0->field_7f
    //     0xdf28d8: ldur            w1, [x0, #0x7f]
    // 0xdf28dc: DecompressPointer r1
    //     0xdf28dc: add             x1, x1, HEAP, lsl #32
    // 0xdf28e0: r0 = LoadClassIdInstr(r1)
    //     0xdf28e0: ldur            x0, [x1, #-1]
    //     0xdf28e4: ubfx            x0, x0, #0xc, #0x14
    // 0xdf28e8: d0 = 0.100000
    //     0xdf28e8: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0xdf28ec: ldr             d0, [x17, #0x1e0]
    // 0xdf28f0: r0 = GDT[cid_x0 + -0x1000]()
    //     0xdf28f0: sub             lr, x0, #1, lsl #12
    //     0xdf28f4: ldr             lr, [x21, lr, lsl #3]
    //     0xdf28f8: blr             lr
    // 0xdf28fc: LeaveFrame
    //     0xdf28fc: mov             SP, fp
    //     0xdf2900: ldp             fp, lr, [SP], #0x10
    // 0xdf2904: ret
    //     0xdf2904: ret             
    // 0xdf2908: r0 = Null
    //     0xdf2908: mov             x0, NULL
    // 0xdf290c: LeaveFrame
    //     0xdf290c: mov             SP, fp
    //     0xdf2910: ldp             fp, lr, [SP], #0x10
    // 0xdf2914: ret
    //     0xdf2914: ret             
    // 0xdf2918: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf2918: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf291c: b               #0xdf2580
  }
  [closure] Color? <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xdf2bac, size: 0xb0
    // 0xdf2bac: EnterFrame
    //     0xdf2bac: stp             fp, lr, [SP, #-0x10]!
    //     0xdf2bb0: mov             fp, SP
    // 0xdf2bb4: AllocStack(0x8)
    //     0xdf2bb4: sub             SP, SP, #8
    // 0xdf2bb8: SetupParameters([dynamic _ /* r0 */])
    //     0xdf2bb8: ldr             x0, [fp, #0x18]
    //     0xdf2bbc: ldur            w3, [x0, #0x17]
    //     0xdf2bc0: add             x3, x3, HEAP, lsl #32
    //     0xdf2bc4: stur            x3, [fp, #-8]
    // 0xdf2bc8: CheckStackOverflow
    //     0xdf2bc8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf2bcc: cmp             SP, x16
    //     0xdf2bd0: b.ls            #0xdf2c54
    // 0xdf2bd4: ldr             x1, [fp, #0x10]
    // 0xdf2bd8: r0 = LoadClassIdInstr(r1)
    //     0xdf2bd8: ldur            x0, [x1, #-1]
    //     0xdf2bdc: ubfx            x0, x0, #0xc, #0x14
    // 0xdf2be0: r2 = Instance_WidgetState
    //     0xdf2be0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xdf2be4: ldr             x2, [x2, #0x100]
    // 0xdf2be8: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdf2be8: mov             x17, #0x2929
    //     0xdf2bec: movk            x17, #1, lsl #16
    //     0xdf2bf0: add             lr, x0, x17
    //     0xdf2bf4: ldr             lr, [x21, lr, lsl #3]
    //     0xdf2bf8: blr             lr
    // 0xdf2bfc: tbnz            w0, #4, #0xdf2c44
    // 0xdf2c00: ldur            x0, [fp, #-8]
    // 0xdf2c04: LoadField: r1 = r0->field_f
    //     0xdf2c04: ldur            w1, [x0, #0xf]
    // 0xdf2c08: DecompressPointer r1
    //     0xdf2c08: add             x1, x1, HEAP, lsl #32
    // 0xdf2c0c: LoadField: r0 = r1->field_b3
    //     0xdf2c0c: ldur            w0, [x1, #0xb3]
    // 0xdf2c10: DecompressPointer r0
    //     0xdf2c10: add             x0, x0, HEAP, lsl #32
    // 0xdf2c14: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf2c18: cmp             w0, w16
    // 0xdf2c1c: b.ne            #0xdf2c2c
    // 0xdf2c20: r2 = _colors
    //     0xdf2c20: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xdf2c24: ldr             x2, [x2, #0x400]
    // 0xdf2c28: r0 = InitLateFinalInstanceField()
    //     0xdf2c28: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf2c2c: LoadField: r1 = r0->field_b
    //     0xdf2c2c: ldur            w1, [x0, #0xb]
    // 0xdf2c30: DecompressPointer r1
    //     0xdf2c30: add             x1, x1, HEAP, lsl #32
    // 0xdf2c34: mov             x0, x1
    // 0xdf2c38: LeaveFrame
    //     0xdf2c38: mov             SP, fp
    //     0xdf2c3c: ldp             fp, lr, [SP], #0x10
    // 0xdf2c40: ret
    //     0xdf2c40: ret             
    // 0xdf2c44: r0 = Null
    //     0xdf2c44: mov             x0, NULL
    // 0xdf2c48: LeaveFrame
    //     0xdf2c48: mov             SP, fp
    //     0xdf2c4c: ldp             fp, lr, [SP], #0x10
    // 0xdf2c50: ret
    //     0xdf2c50: ret             
    // 0xdf2c54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf2c54: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf2c58: b               #0xdf2bd4
  }
  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xdf2fac, size: 0x174
    // 0xdf2fac: EnterFrame
    //     0xdf2fac: stp             fp, lr, [SP, #-0x10]!
    //     0xdf2fb0: mov             fp, SP
    // 0xdf2fb4: AllocStack(0x8)
    //     0xdf2fb4: sub             SP, SP, #8
    // 0xdf2fb8: SetupParameters([dynamic _ /* r0 */])
    //     0xdf2fb8: ldr             x0, [fp, #0x18]
    //     0xdf2fbc: ldur            w3, [x0, #0x17]
    //     0xdf2fc0: add             x3, x3, HEAP, lsl #32
    //     0xdf2fc4: stur            x3, [fp, #-8]
    // 0xdf2fc8: CheckStackOverflow
    //     0xdf2fc8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf2fcc: cmp             SP, x16
    //     0xdf2fd0: b.ls            #0xdf3118
    // 0xdf2fd4: ldr             x4, [fp, #0x10]
    // 0xdf2fd8: r0 = LoadClassIdInstr(r4)
    //     0xdf2fd8: ldur            x0, [x4, #-1]
    //     0xdf2fdc: ubfx            x0, x0, #0xc, #0x14
    // 0xdf2fe0: mov             x1, x4
    // 0xdf2fe4: r2 = Instance_WidgetState
    //     0xdf2fe4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xdf2fe8: ldr             x2, [x2, #0x100]
    // 0xdf2fec: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdf2fec: mov             x17, #0x2929
    //     0xdf2ff0: movk            x17, #1, lsl #16
    //     0xdf2ff4: add             lr, x0, x17
    //     0xdf2ff8: ldr             lr, [x21, lr, lsl #3]
    //     0xdf2ffc: blr             lr
    // 0xdf3000: tbnz            w0, #4, #0xdf3048
    // 0xdf3004: ldur            x3, [fp, #-8]
    // 0xdf3008: LoadField: r1 = r3->field_f
    //     0xdf3008: ldur            w1, [x3, #0xf]
    // 0xdf300c: DecompressPointer r1
    //     0xdf300c: add             x1, x1, HEAP, lsl #32
    // 0xdf3010: LoadField: r0 = r1->field_b3
    //     0xdf3010: ldur            w0, [x1, #0xb3]
    // 0xdf3014: DecompressPointer r0
    //     0xdf3014: add             x0, x0, HEAP, lsl #32
    // 0xdf3018: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf301c: cmp             w0, w16
    // 0xdf3020: b.ne            #0xdf3030
    // 0xdf3024: r2 = _colors
    //     0xdf3024: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xdf3028: ldr             x2, [x2, #0x400]
    // 0xdf302c: r0 = InitLateFinalInstanceField()
    //     0xdf302c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf3030: LoadField: r1 = r0->field_f
    //     0xdf3030: ldur            w1, [x0, #0xf]
    // 0xdf3034: DecompressPointer r1
    //     0xdf3034: add             x1, x1, HEAP, lsl #32
    // 0xdf3038: mov             x0, x1
    // 0xdf303c: LeaveFrame
    //     0xdf303c: mov             SP, fp
    //     0xdf3040: ldp             fp, lr, [SP], #0x10
    // 0xdf3044: ret
    //     0xdf3044: ret             
    // 0xdf3048: ldr             x1, [fp, #0x10]
    // 0xdf304c: ldur            x3, [fp, #-8]
    // 0xdf3050: r0 = LoadClassIdInstr(r1)
    //     0xdf3050: ldur            x0, [x1, #-1]
    //     0xdf3054: ubfx            x0, x0, #0xc, #0x14
    // 0xdf3058: r2 = Instance_WidgetState
    //     0xdf3058: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xdf305c: ldr             x2, [x2, #0xa70]
    // 0xdf3060: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdf3060: mov             x17, #0x2929
    //     0xdf3064: movk            x17, #1, lsl #16
    //     0xdf3068: add             lr, x0, x17
    //     0xdf306c: ldr             lr, [x21, lr, lsl #3]
    //     0xdf3070: blr             lr
    // 0xdf3074: tbnz            w0, #4, #0xdf30d4
    // 0xdf3078: ldur            x0, [fp, #-8]
    // 0xdf307c: LoadField: r1 = r0->field_f
    //     0xdf307c: ldur            w1, [x0, #0xf]
    // 0xdf3080: DecompressPointer r1
    //     0xdf3080: add             x1, x1, HEAP, lsl #32
    // 0xdf3084: LoadField: r0 = r1->field_b3
    //     0xdf3084: ldur            w0, [x1, #0xb3]
    // 0xdf3088: DecompressPointer r0
    //     0xdf3088: add             x0, x0, HEAP, lsl #32
    // 0xdf308c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf3090: cmp             w0, w16
    // 0xdf3094: b.ne            #0xdf30a4
    // 0xdf3098: r2 = _colors
    //     0xdf3098: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xdf309c: ldr             x2, [x2, #0x400]
    // 0xdf30a0: r0 = InitLateFinalInstanceField()
    //     0xdf30a0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf30a4: LoadField: r1 = r0->field_7f
    //     0xdf30a4: ldur            w1, [x0, #0x7f]
    // 0xdf30a8: DecompressPointer r1
    //     0xdf30a8: add             x1, x1, HEAP, lsl #32
    // 0xdf30ac: r0 = LoadClassIdInstr(r1)
    //     0xdf30ac: ldur            x0, [x1, #-1]
    //     0xdf30b0: ubfx            x0, x0, #0xc, #0x14
    // 0xdf30b4: d0 = 0.380000
    //     0xdf30b4: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xdf30b8: ldr             d0, [x17, #0x1f0]
    // 0xdf30bc: r0 = GDT[cid_x0 + -0x1000]()
    //     0xdf30bc: sub             lr, x0, #1, lsl #12
    //     0xdf30c0: ldr             lr, [x21, lr, lsl #3]
    //     0xdf30c4: blr             lr
    // 0xdf30c8: LeaveFrame
    //     0xdf30c8: mov             SP, fp
    //     0xdf30cc: ldp             fp, lr, [SP], #0x10
    // 0xdf30d0: ret
    //     0xdf30d0: ret             
    // 0xdf30d4: ldur            x0, [fp, #-8]
    // 0xdf30d8: LoadField: r1 = r0->field_f
    //     0xdf30d8: ldur            w1, [x0, #0xf]
    // 0xdf30dc: DecompressPointer r1
    //     0xdf30dc: add             x1, x1, HEAP, lsl #32
    // 0xdf30e0: LoadField: r0 = r1->field_b3
    //     0xdf30e0: ldur            w0, [x1, #0xb3]
    // 0xdf30e4: DecompressPointer r0
    //     0xdf30e4: add             x0, x0, HEAP, lsl #32
    // 0xdf30e8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf30ec: cmp             w0, w16
    // 0xdf30f0: b.ne            #0xdf3100
    // 0xdf30f4: r2 = _colors
    //     0xdf30f4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xdf30f8: ldr             x2, [x2, #0x400]
    // 0xdf30fc: r0 = InitLateFinalInstanceField()
    //     0xdf30fc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf3100: LoadField: r1 = r0->field_7f
    //     0xdf3100: ldur            w1, [x0, #0x7f]
    // 0xdf3104: DecompressPointer r1
    //     0xdf3104: add             x1, x1, HEAP, lsl #32
    // 0xdf3108: mov             x0, x1
    // 0xdf310c: LeaveFrame
    //     0xdf310c: mov             SP, fp
    //     0xdf3110: ldp             fp, lr, [SP], #0x10
    // 0xdf3114: ret
    //     0xdf3114: ret             
    // 0xdf3118: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf3118: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf311c: b               #0xdf2fd4
  }
  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xdf3294, size: 0x164
    // 0xdf3294: EnterFrame
    //     0xdf3294: stp             fp, lr, [SP, #-0x10]!
    //     0xdf3298: mov             fp, SP
    // 0xdf329c: AllocStack(0x8)
    //     0xdf329c: sub             SP, SP, #8
    // 0xdf32a0: SetupParameters([dynamic _ /* r0 */])
    //     0xdf32a0: ldr             x0, [fp, #0x18]
    //     0xdf32a4: ldur            w3, [x0, #0x17]
    //     0xdf32a8: add             x3, x3, HEAP, lsl #32
    //     0xdf32ac: stur            x3, [fp, #-8]
    // 0xdf32b0: CheckStackOverflow
    //     0xdf32b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf32b4: cmp             SP, x16
    //     0xdf32b8: b.ls            #0xdf33f0
    // 0xdf32bc: ldr             x4, [fp, #0x10]
    // 0xdf32c0: r0 = LoadClassIdInstr(r4)
    //     0xdf32c0: ldur            x0, [x4, #-1]
    //     0xdf32c4: ubfx            x0, x0, #0xc, #0x14
    // 0xdf32c8: mov             x1, x4
    // 0xdf32cc: r2 = Instance_WidgetState
    //     0xdf32cc: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xdf32d0: ldr             x2, [x2, #0x100]
    // 0xdf32d4: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdf32d4: mov             x17, #0x2929
    //     0xdf32d8: movk            x17, #1, lsl #16
    //     0xdf32dc: add             lr, x0, x17
    //     0xdf32e0: ldr             lr, [x21, lr, lsl #3]
    //     0xdf32e4: blr             lr
    // 0xdf32e8: tbnz            w0, #4, #0xdf3330
    // 0xdf32ec: ldur            x3, [fp, #-8]
    // 0xdf32f0: LoadField: r1 = r3->field_f
    //     0xdf32f0: ldur            w1, [x3, #0xf]
    // 0xdf32f4: DecompressPointer r1
    //     0xdf32f4: add             x1, x1, HEAP, lsl #32
    // 0xdf32f8: LoadField: r0 = r1->field_b3
    //     0xdf32f8: ldur            w0, [x1, #0xb3]
    // 0xdf32fc: DecompressPointer r0
    //     0xdf32fc: add             x0, x0, HEAP, lsl #32
    // 0xdf3300: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf3304: cmp             w0, w16
    // 0xdf3308: b.ne            #0xdf3318
    // 0xdf330c: r2 = _colors
    //     0xdf330c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xdf3310: ldr             x2, [x2, #0x400]
    // 0xdf3314: r0 = InitLateFinalInstanceField()
    //     0xdf3314: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf3318: LoadField: r1 = r0->field_f
    //     0xdf3318: ldur            w1, [x0, #0xf]
    // 0xdf331c: DecompressPointer r1
    //     0xdf331c: add             x1, x1, HEAP, lsl #32
    // 0xdf3320: mov             x0, x1
    // 0xdf3324: LeaveFrame
    //     0xdf3324: mov             SP, fp
    //     0xdf3328: ldp             fp, lr, [SP], #0x10
    // 0xdf332c: ret
    //     0xdf332c: ret             
    // 0xdf3330: ldr             x1, [fp, #0x10]
    // 0xdf3334: ldur            x3, [fp, #-8]
    // 0xdf3338: r0 = LoadClassIdInstr(r1)
    //     0xdf3338: ldur            x0, [x1, #-1]
    //     0xdf333c: ubfx            x0, x0, #0xc, #0x14
    // 0xdf3340: r2 = Instance_WidgetState
    //     0xdf3340: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xdf3344: ldr             x2, [x2, #0xa70]
    // 0xdf3348: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdf3348: mov             x17, #0x2929
    //     0xdf334c: movk            x17, #1, lsl #16
    //     0xdf3350: add             lr, x0, x17
    //     0xdf3354: ldr             lr, [x21, lr, lsl #3]
    //     0xdf3358: blr             lr
    // 0xdf335c: tbnz            w0, #4, #0xdf33ac
    // 0xdf3360: ldur            x0, [fp, #-8]
    // 0xdf3364: LoadField: r1 = r0->field_f
    //     0xdf3364: ldur            w1, [x0, #0xf]
    // 0xdf3368: DecompressPointer r1
    //     0xdf3368: add             x1, x1, HEAP, lsl #32
    // 0xdf336c: LoadField: r0 = r1->field_b3
    //     0xdf336c: ldur            w0, [x1, #0xb3]
    // 0xdf3370: DecompressPointer r0
    //     0xdf3370: add             x0, x0, HEAP, lsl #32
    // 0xdf3374: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf3378: cmp             w0, w16
    // 0xdf337c: b.ne            #0xdf338c
    // 0xdf3380: r2 = _colors
    //     0xdf3380: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xdf3384: ldr             x2, [x2, #0x400]
    // 0xdf3388: r0 = InitLateFinalInstanceField()
    //     0xdf3388: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf338c: LoadField: r1 = r0->field_b
    //     0xdf338c: ldur            w1, [x0, #0xb]
    // 0xdf3390: DecompressPointer r1
    //     0xdf3390: add             x1, x1, HEAP, lsl #32
    // 0xdf3394: d0 = 0.380000
    //     0xdf3394: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xdf3398: ldr             d0, [x17, #0x1f0]
    // 0xdf339c: r0 = withOpacity()
    //     0xdf339c: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xdf33a0: LeaveFrame
    //     0xdf33a0: mov             SP, fp
    //     0xdf33a4: ldp             fp, lr, [SP], #0x10
    // 0xdf33a8: ret
    //     0xdf33a8: ret             
    // 0xdf33ac: ldur            x0, [fp, #-8]
    // 0xdf33b0: LoadField: r1 = r0->field_f
    //     0xdf33b0: ldur            w1, [x0, #0xf]
    // 0xdf33b4: DecompressPointer r1
    //     0xdf33b4: add             x1, x1, HEAP, lsl #32
    // 0xdf33b8: LoadField: r0 = r1->field_b3
    //     0xdf33b8: ldur            w0, [x1, #0xb3]
    // 0xdf33bc: DecompressPointer r0
    //     0xdf33bc: add             x0, x0, HEAP, lsl #32
    // 0xdf33c0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf33c4: cmp             w0, w16
    // 0xdf33c8: b.ne            #0xdf33d8
    // 0xdf33cc: r2 = _colors
    //     0xdf33cc: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xdf33d0: ldr             x2, [x2, #0x400]
    // 0xdf33d4: r0 = InitLateFinalInstanceField()
    //     0xdf33d4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf33d8: LoadField: r1 = r0->field_b
    //     0xdf33d8: ldur            w1, [x0, #0xb]
    // 0xdf33dc: DecompressPointer r1
    //     0xdf33dc: add             x1, x1, HEAP, lsl #32
    // 0xdf33e0: mov             x0, x1
    // 0xdf33e4: LeaveFrame
    //     0xdf33e4: mov             SP, fp
    //     0xdf33e8: ldp             fp, lr, [SP], #0x10
    // 0xdf33ec: ret
    //     0xdf33ec: ret             
    // 0xdf33f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf33f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf33f4: b               #0xdf32bc
  }
  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xdf490c, size: 0x19c
    // 0xdf490c: EnterFrame
    //     0xdf490c: stp             fp, lr, [SP, #-0x10]!
    //     0xdf4910: mov             fp, SP
    // 0xdf4914: AllocStack(0x8)
    //     0xdf4914: sub             SP, SP, #8
    // 0xdf4918: SetupParameters([dynamic _ /* r0 */])
    //     0xdf4918: ldr             x0, [fp, #0x18]
    //     0xdf491c: ldur            w3, [x0, #0x17]
    //     0xdf4920: add             x3, x3, HEAP, lsl #32
    //     0xdf4924: stur            x3, [fp, #-8]
    // 0xdf4928: CheckStackOverflow
    //     0xdf4928: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf492c: cmp             SP, x16
    //     0xdf4930: b.ls            #0xdf4aa0
    // 0xdf4934: ldr             x4, [fp, #0x10]
    // 0xdf4938: r0 = LoadClassIdInstr(r4)
    //     0xdf4938: ldur            x0, [x4, #-1]
    //     0xdf493c: ubfx            x0, x0, #0xc, #0x14
    // 0xdf4940: mov             x1, x4
    // 0xdf4944: r2 = Instance_WidgetState
    //     0xdf4944: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xdf4948: ldr             x2, [x2, #0x100]
    // 0xdf494c: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdf494c: mov             x17, #0x2929
    //     0xdf4950: movk            x17, #1, lsl #16
    //     0xdf4954: add             lr, x0, x17
    //     0xdf4958: ldr             lr, [x21, lr, lsl #3]
    //     0xdf495c: blr             lr
    // 0xdf4960: tbnz            w0, #4, #0xdf49a8
    // 0xdf4964: ldur            x3, [fp, #-8]
    // 0xdf4968: LoadField: r1 = r3->field_f
    //     0xdf4968: ldur            w1, [x3, #0xf]
    // 0xdf496c: DecompressPointer r1
    //     0xdf496c: add             x1, x1, HEAP, lsl #32
    // 0xdf4970: LoadField: r0 = r1->field_b3
    //     0xdf4970: ldur            w0, [x1, #0xb3]
    // 0xdf4974: DecompressPointer r0
    //     0xdf4974: add             x0, x0, HEAP, lsl #32
    // 0xdf4978: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf497c: cmp             w0, w16
    // 0xdf4980: b.ne            #0xdf4990
    // 0xdf4984: r2 = _colors
    //     0xdf4984: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xdf4988: ldr             x2, [x2, #0x400]
    // 0xdf498c: r0 = InitLateFinalInstanceField()
    //     0xdf498c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf4990: LoadField: r1 = r0->field_f
    //     0xdf4990: ldur            w1, [x0, #0xf]
    // 0xdf4994: DecompressPointer r1
    //     0xdf4994: add             x1, x1, HEAP, lsl #32
    // 0xdf4998: mov             x0, x1
    // 0xdf499c: LeaveFrame
    //     0xdf499c: mov             SP, fp
    //     0xdf49a0: ldp             fp, lr, [SP], #0x10
    // 0xdf49a4: ret
    //     0xdf49a4: ret             
    // 0xdf49a8: ldr             x1, [fp, #0x10]
    // 0xdf49ac: ldur            x3, [fp, #-8]
    // 0xdf49b0: r0 = LoadClassIdInstr(r1)
    //     0xdf49b0: ldur            x0, [x1, #-1]
    //     0xdf49b4: ubfx            x0, x0, #0xc, #0x14
    // 0xdf49b8: r2 = Instance_WidgetState
    //     0xdf49b8: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xdf49bc: ldr             x2, [x2, #0xa70]
    // 0xdf49c0: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdf49c0: mov             x17, #0x2929
    //     0xdf49c4: movk            x17, #1, lsl #16
    //     0xdf49c8: add             lr, x0, x17
    //     0xdf49cc: ldr             lr, [x21, lr, lsl #3]
    //     0xdf49d0: blr             lr
    // 0xdf49d4: tbnz            w0, #4, #0xdf4a44
    // 0xdf49d8: ldur            x0, [fp, #-8]
    // 0xdf49dc: LoadField: r1 = r0->field_f
    //     0xdf49dc: ldur            w1, [x0, #0xf]
    // 0xdf49e0: DecompressPointer r1
    //     0xdf49e0: add             x1, x1, HEAP, lsl #32
    // 0xdf49e4: LoadField: r0 = r1->field_b3
    //     0xdf49e4: ldur            w0, [x1, #0xb3]
    // 0xdf49e8: DecompressPointer r0
    //     0xdf49e8: add             x0, x0, HEAP, lsl #32
    // 0xdf49ec: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf49f0: cmp             w0, w16
    // 0xdf49f4: b.ne            #0xdf4a04
    // 0xdf49f8: r2 = _colors
    //     0xdf49f8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xdf49fc: ldr             x2, [x2, #0x400]
    // 0xdf4a00: r0 = InitLateFinalInstanceField()
    //     0xdf4a00: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf4a04: LoadField: r1 = r0->field_a3
    //     0xdf4a04: ldur            w1, [x0, #0xa3]
    // 0xdf4a08: DecompressPointer r1
    //     0xdf4a08: add             x1, x1, HEAP, lsl #32
    // 0xdf4a0c: cmp             w1, NULL
    // 0xdf4a10: b.ne            #0xdf4a1c
    // 0xdf4a14: LoadField: r1 = r0->field_7f
    //     0xdf4a14: ldur            w1, [x0, #0x7f]
    // 0xdf4a18: DecompressPointer r1
    //     0xdf4a18: add             x1, x1, HEAP, lsl #32
    // 0xdf4a1c: r0 = LoadClassIdInstr(r1)
    //     0xdf4a1c: ldur            x0, [x1, #-1]
    //     0xdf4a20: ubfx            x0, x0, #0xc, #0x14
    // 0xdf4a24: d0 = 0.380000
    //     0xdf4a24: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xdf4a28: ldr             d0, [x17, #0x1f0]
    // 0xdf4a2c: r0 = GDT[cid_x0 + -0x1000]()
    //     0xdf4a2c: sub             lr, x0, #1, lsl #12
    //     0xdf4a30: ldr             lr, [x21, lr, lsl #3]
    //     0xdf4a34: blr             lr
    // 0xdf4a38: LeaveFrame
    //     0xdf4a38: mov             SP, fp
    //     0xdf4a3c: ldp             fp, lr, [SP], #0x10
    // 0xdf4a40: ret
    //     0xdf4a40: ret             
    // 0xdf4a44: ldur            x0, [fp, #-8]
    // 0xdf4a48: LoadField: r1 = r0->field_f
    //     0xdf4a48: ldur            w1, [x0, #0xf]
    // 0xdf4a4c: DecompressPointer r1
    //     0xdf4a4c: add             x1, x1, HEAP, lsl #32
    // 0xdf4a50: LoadField: r0 = r1->field_b3
    //     0xdf4a50: ldur            w0, [x1, #0xb3]
    // 0xdf4a54: DecompressPointer r0
    //     0xdf4a54: add             x0, x0, HEAP, lsl #32
    // 0xdf4a58: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf4a5c: cmp             w0, w16
    // 0xdf4a60: b.ne            #0xdf4a70
    // 0xdf4a64: r2 = _colors
    //     0xdf4a64: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xdf4a68: ldr             x2, [x2, #0x400]
    // 0xdf4a6c: r0 = InitLateFinalInstanceField()
    //     0xdf4a6c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf4a70: LoadField: r1 = r0->field_a3
    //     0xdf4a70: ldur            w1, [x0, #0xa3]
    // 0xdf4a74: DecompressPointer r1
    //     0xdf4a74: add             x1, x1, HEAP, lsl #32
    // 0xdf4a78: cmp             w1, NULL
    // 0xdf4a7c: b.ne            #0xdf4a90
    // 0xdf4a80: LoadField: r2 = r0->field_7f
    //     0xdf4a80: ldur            w2, [x0, #0x7f]
    // 0xdf4a84: DecompressPointer r2
    //     0xdf4a84: add             x2, x2, HEAP, lsl #32
    // 0xdf4a88: mov             x0, x2
    // 0xdf4a8c: b               #0xdf4a94
    // 0xdf4a90: mov             x0, x1
    // 0xdf4a94: LeaveFrame
    //     0xdf4a94: mov             SP, fp
    //     0xdf4a98: ldp             fp, lr, [SP], #0x10
    // 0xdf4a9c: ret
    //     0xdf4a9c: ret             
    // 0xdf4aa0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf4aa0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf4aa4: b               #0xdf4934
  }
  [closure] Color? <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0x1132450, size: 0x1e8
    // 0x1132450: EnterFrame
    //     0x1132450: stp             fp, lr, [SP, #-0x10]!
    //     0x1132454: mov             fp, SP
    // 0x1132458: AllocStack(0x8)
    //     0x1132458: sub             SP, SP, #8
    // 0x113245c: SetupParameters([dynamic _ /* r0 */])
    //     0x113245c: ldr             x0, [fp, #0x18]
    //     0x1132460: ldur            w3, [x0, #0x17]
    //     0x1132464: add             x3, x3, HEAP, lsl #32
    //     0x1132468: stur            x3, [fp, #-8]
    // 0x113246c: CheckStackOverflow
    //     0x113246c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1132470: cmp             SP, x16
    //     0x1132474: b.ls            #0x1132630
    // 0x1132478: ldr             x4, [fp, #0x10]
    // 0x113247c: r0 = LoadClassIdInstr(r4)
    //     0x113247c: ldur            x0, [x4, #-1]
    //     0x1132480: ubfx            x0, x0, #0xc, #0x14
    // 0x1132484: mov             x1, x4
    // 0x1132488: r2 = Instance_WidgetState
    //     0x1132488: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0x113248c: ldr             x2, [x2, #0xa48]
    // 0x1132490: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1132490: mov             x17, #0x2929
    //     0x1132494: movk            x17, #1, lsl #16
    //     0x1132498: add             lr, x0, x17
    //     0x113249c: ldr             lr, [x21, lr, lsl #3]
    //     0x11324a0: blr             lr
    // 0x11324a4: tbnz            w0, #4, #0x1132504
    // 0x11324a8: ldur            x3, [fp, #-8]
    // 0x11324ac: LoadField: r1 = r3->field_f
    //     0x11324ac: ldur            w1, [x3, #0xf]
    // 0x11324b0: DecompressPointer r1
    //     0x11324b0: add             x1, x1, HEAP, lsl #32
    // 0x11324b4: LoadField: r0 = r1->field_b3
    //     0x11324b4: ldur            w0, [x1, #0xb3]
    // 0x11324b8: DecompressPointer r0
    //     0x11324b8: add             x0, x0, HEAP, lsl #32
    // 0x11324bc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11324c0: cmp             w0, w16
    // 0x11324c4: b.ne            #0x11324d4
    // 0x11324c8: r2 = _colors
    //     0x11324c8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x11324cc: ldr             x2, [x2, #0x400]
    // 0x11324d0: r0 = InitLateFinalInstanceField()
    //     0x11324d0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x11324d4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x11324d4: ldur            w1, [x0, #0x17]
    // 0x11324d8: DecompressPointer r1
    //     0x11324d8: add             x1, x1, HEAP, lsl #32
    // 0x11324dc: cmp             w1, NULL
    // 0x11324e0: b.ne            #0x11324ec
    // 0x11324e4: LoadField: r1 = r0->field_f
    //     0x11324e4: ldur            w1, [x0, #0xf]
    // 0x11324e8: DecompressPointer r1
    //     0x11324e8: add             x1, x1, HEAP, lsl #32
    // 0x11324ec: d0 = 0.100000
    //     0x11324ec: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0x11324f0: ldr             d0, [x17, #0x1e0]
    // 0x11324f4: r0 = withOpacity()
    //     0x11324f4: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x11324f8: LeaveFrame
    //     0x11324f8: mov             SP, fp
    //     0x11324fc: ldp             fp, lr, [SP], #0x10
    // 0x1132500: ret
    //     0x1132500: ret             
    // 0x1132504: ldr             x4, [fp, #0x10]
    // 0x1132508: ldur            x3, [fp, #-8]
    // 0x113250c: r0 = LoadClassIdInstr(r4)
    //     0x113250c: ldur            x0, [x4, #-1]
    //     0x1132510: ubfx            x0, x0, #0xc, #0x14
    // 0x1132514: mov             x1, x4
    // 0x1132518: r2 = Instance_WidgetState
    //     0x1132518: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0x113251c: ldr             x2, [x2, #0xa50]
    // 0x1132520: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1132520: mov             x17, #0x2929
    //     0x1132524: movk            x17, #1, lsl #16
    //     0x1132528: add             lr, x0, x17
    //     0x113252c: ldr             lr, [x21, lr, lsl #3]
    //     0x1132530: blr             lr
    // 0x1132534: tbnz            w0, #4, #0x1132594
    // 0x1132538: ldur            x3, [fp, #-8]
    // 0x113253c: LoadField: r1 = r3->field_f
    //     0x113253c: ldur            w1, [x3, #0xf]
    // 0x1132540: DecompressPointer r1
    //     0x1132540: add             x1, x1, HEAP, lsl #32
    // 0x1132544: LoadField: r0 = r1->field_b3
    //     0x1132544: ldur            w0, [x1, #0xb3]
    // 0x1132548: DecompressPointer r0
    //     0x1132548: add             x0, x0, HEAP, lsl #32
    // 0x113254c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1132550: cmp             w0, w16
    // 0x1132554: b.ne            #0x1132564
    // 0x1132558: r2 = _colors
    //     0x1132558: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x113255c: ldr             x2, [x2, #0x400]
    // 0x1132560: r0 = InitLateFinalInstanceField()
    //     0x1132560: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1132564: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x1132564: ldur            w1, [x0, #0x17]
    // 0x1132568: DecompressPointer r1
    //     0x1132568: add             x1, x1, HEAP, lsl #32
    // 0x113256c: cmp             w1, NULL
    // 0x1132570: b.ne            #0x113257c
    // 0x1132574: LoadField: r1 = r0->field_f
    //     0x1132574: ldur            w1, [x0, #0xf]
    // 0x1132578: DecompressPointer r1
    //     0x1132578: add             x1, x1, HEAP, lsl #32
    // 0x113257c: d0 = 0.080000
    //     0x113257c: add             x17, PP, #0x15, lsl #12  ; [pp+0x15a58] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x1132580: ldr             d0, [x17, #0xa58]
    // 0x1132584: r0 = withOpacity()
    //     0x1132584: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x1132588: LeaveFrame
    //     0x1132588: mov             SP, fp
    //     0x113258c: ldp             fp, lr, [SP], #0x10
    // 0x1132590: ret
    //     0x1132590: ret             
    // 0x1132594: ldr             x1, [fp, #0x10]
    // 0x1132598: ldur            x3, [fp, #-8]
    // 0x113259c: r0 = LoadClassIdInstr(r1)
    //     0x113259c: ldur            x0, [x1, #-1]
    //     0x11325a0: ubfx            x0, x0, #0xc, #0x14
    // 0x11325a4: r2 = Instance_WidgetState
    //     0x11325a4: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0x11325a8: ldr             x2, [x2, #0xa60]
    // 0x11325ac: r0 = GDT[cid_x0 + 0x12929]()
    //     0x11325ac: mov             x17, #0x2929
    //     0x11325b0: movk            x17, #1, lsl #16
    //     0x11325b4: add             lr, x0, x17
    //     0x11325b8: ldr             lr, [x21, lr, lsl #3]
    //     0x11325bc: blr             lr
    // 0x11325c0: tbnz            w0, #4, #0x1132620
    // 0x11325c4: ldur            x0, [fp, #-8]
    // 0x11325c8: LoadField: r1 = r0->field_f
    //     0x11325c8: ldur            w1, [x0, #0xf]
    // 0x11325cc: DecompressPointer r1
    //     0x11325cc: add             x1, x1, HEAP, lsl #32
    // 0x11325d0: LoadField: r0 = r1->field_b3
    //     0x11325d0: ldur            w0, [x1, #0xb3]
    // 0x11325d4: DecompressPointer r0
    //     0x11325d4: add             x0, x0, HEAP, lsl #32
    // 0x11325d8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11325dc: cmp             w0, w16
    // 0x11325e0: b.ne            #0x11325f0
    // 0x11325e4: r2 = _colors
    //     0x11325e4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26400] Field <_DatePickerDefaultsM3@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0x11325e8: ldr             x2, [x2, #0x400]
    // 0x11325ec: r0 = InitLateFinalInstanceField()
    //     0x11325ec: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x11325f0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x11325f0: ldur            w1, [x0, #0x17]
    // 0x11325f4: DecompressPointer r1
    //     0x11325f4: add             x1, x1, HEAP, lsl #32
    // 0x11325f8: cmp             w1, NULL
    // 0x11325fc: b.ne            #0x1132608
    // 0x1132600: LoadField: r1 = r0->field_f
    //     0x1132600: ldur            w1, [x0, #0xf]
    // 0x1132604: DecompressPointer r1
    //     0x1132604: add             x1, x1, HEAP, lsl #32
    // 0x1132608: d0 = 0.100000
    //     0x1132608: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0x113260c: ldr             d0, [x17, #0x1e0]
    // 0x1132610: r0 = withOpacity()
    //     0x1132610: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x1132614: LeaveFrame
    //     0x1132614: mov             SP, fp
    //     0x1132618: ldp             fp, lr, [SP], #0x10
    // 0x113261c: ret
    //     0x113261c: ret             
    // 0x1132620: r0 = Null
    //     0x1132620: mov             x0, NULL
    // 0x1132624: LeaveFrame
    //     0x1132624: mov             SP, fp
    //     0x1132628: ldp             fp, lr, [SP], #0x10
    // 0x113262c: ret
    //     0x113262c: ret             
    // 0x1132630: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1132630: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1132634: b               #0x1132478
  }
}

// class id: 5169, size: 0xc0, field offset: 0xac
class _DatePickerDefaultsM2 extends DatePickerThemeData {

  late final bool _isDark; // offset: 0xbc
  late final ColorScheme _colors; // offset: 0xb4
  late final TextTheme _textTheme; // offset: 0xb8
  late final ThemeData _theme; // offset: 0xb0

  _ _DatePickerDefaultsM2(/* No info */) {
    // ** addr: 0xd0fdf0, size: 0x88
    // 0xd0fdf0: ldr             x9, [THR, #0x90]  ; THR::object_sentinel
    // 0xd0fdf4: r8 = 24.000000
    //     0xd0fdf4: add             x8, PP, #0x1e, lsl #12  ; [pp+0x1e4d0] 24
    //     0xd0fdf8: ldr             x8, [x8, #0x4d0]
    // 0xd0fdfc: r7 = Instance_RoundedRectangleBorder
    //     0xd0fdfc: add             x7, PP, #0x26, lsl #12  ; [pp+0x26218] Obj!RoundedRectangleBorder@129ec21
    //     0xd0fe00: ldr             x7, [x7, #0x218]
    // 0xd0fe04: r6 = Instance_WidgetStatePropertyAll
    //     0xd0fe04: add             x6, PP, #0x99, lsl #12  ; [pp+0x99d80] Obj!WidgetStatePropertyAll<OutlinedBorder>@128a051
    //     0xd0fe08: ldr             x6, [x6, #0xd80]
    // 0xd0fe0c: r5 = Instance_WidgetStatePropertyAll
    //     0xd0fe0c: add             x5, PP, #0x99, lsl #12  ; [pp+0x99d88] Obj!WidgetStatePropertyAll<OutlinedBorder>@128a041
    //     0xd0fe10: ldr             x5, [x5, #0xd88]
    // 0xd0fe14: r4 = 0.000000
    //     0xd0fe14: ldr             x4, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xd0fe18: r3 = Instance_RoundedRectangleBorder
    //     0xd0fe18: add             x3, PP, #0x26, lsl #12  ; [pp+0x26600] Obj!RoundedRectangleBorder@129ec31
    //     0xd0fe1c: ldr             x3, [x3, #0x600]
    // 0xd0fe20: mov             x0, x2
    // 0xd0fe24: StoreField: r1->field_af = r9
    //     0xd0fe24: stur            w9, [x1, #0xaf]
    // 0xd0fe28: StoreField: r1->field_b3 = r9
    //     0xd0fe28: stur            w9, [x1, #0xb3]
    // 0xd0fe2c: StoreField: r1->field_b7 = r9
    //     0xd0fe2c: stur            w9, [x1, #0xb7]
    // 0xd0fe30: StoreField: r1->field_bb = r9
    //     0xd0fe30: stur            w9, [x1, #0xbb]
    // 0xd0fe34: StoreField: r1->field_ab = r0
    //     0xd0fe34: stur            w0, [x1, #0xab]
    //     0xd0fe38: ldurb           w16, [x1, #-1]
    //     0xd0fe3c: ldurb           w17, [x0, #-1]
    //     0xd0fe40: and             x16, x17, x16, lsr #2
    //     0xd0fe44: tst             x16, HEAP, lsr #32
    //     0xd0fe48: b.eq            #0xd0fe58
    //     0xd0fe4c: str             lr, [SP, #-8]!
    //     0xd0fe50: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    //     0xd0fe54: ldr             lr, [SP], #8
    // 0xd0fe58: StoreField: r1->field_b = r8
    //     0xd0fe58: stur            w8, [x1, #0xb]
    // 0xd0fe5c: ArrayStore: r1[0] = r7  ; List_4
    //     0xd0fe5c: stur            w7, [x1, #0x17]
    // 0xd0fe60: StoreField: r1->field_3f = r6
    //     0xd0fe60: stur            w6, [x1, #0x3f]
    // 0xd0fe64: StoreField: r1->field_5f = r5
    //     0xd0fe64: stur            w5, [x1, #0x5f]
    // 0xd0fe68: StoreField: r1->field_67 = r4
    //     0xd0fe68: stur            w4, [x1, #0x67]
    // 0xd0fe6c: StoreField: r1->field_73 = r3
    //     0xd0fe6c: stur            w3, [x1, #0x73]
    // 0xd0fe70: r0 = Null
    //     0xd0fe70: mov             x0, NULL
    // 0xd0fe74: ret
    //     0xd0fe74: ret             
  }
  ColorScheme _colors(_DatePickerDefaultsM2) {
    // ** addr: 0xd10290, size: 0x58
    // 0xd10290: EnterFrame
    //     0xd10290: stp             fp, lr, [SP, #-0x10]!
    //     0xd10294: mov             fp, SP
    // 0xd10298: CheckStackOverflow
    //     0xd10298: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd1029c: cmp             SP, x16
    //     0xd102a0: b.ls            #0xd102e0
    // 0xd102a4: ldr             x1, [fp, #0x10]
    // 0xd102a8: LoadField: r0 = r1->field_af
    //     0xd102a8: ldur            w0, [x1, #0xaf]
    // 0xd102ac: DecompressPointer r0
    //     0xd102ac: add             x0, x0, HEAP, lsl #32
    // 0xd102b0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd102b4: cmp             w0, w16
    // 0xd102b8: b.ne            #0xd102c8
    // 0xd102bc: r2 = _theme
    //     0xd102bc: add             x2, PP, #0x26, lsl #12  ; [pp+0x26490] Field <_DatePickerDefaultsM2@738353974._theme@738353974>: late final (offset: 0xb0)
    //     0xd102c0: ldr             x2, [x2, #0x490]
    // 0xd102c4: r0 = InitLateFinalInstanceField()
    //     0xd102c4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd102c8: LoadField: r1 = r0->field_3f
    //     0xd102c8: ldur            w1, [x0, #0x3f]
    // 0xd102cc: DecompressPointer r1
    //     0xd102cc: add             x1, x1, HEAP, lsl #32
    // 0xd102d0: mov             x0, x1
    // 0xd102d4: LeaveFrame
    //     0xd102d4: mov             SP, fp
    //     0xd102d8: ldp             fp, lr, [SP], #0x10
    // 0xd102dc: ret
    //     0xd102dc: ret             
    // 0xd102e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd102e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd102e4: b               #0xd102a4
  }
  ThemeData _theme(_DatePickerDefaultsM2) {
    // ** addr: 0xd102e8, size: 0x38
    // 0xd102e8: EnterFrame
    //     0xd102e8: stp             fp, lr, [SP, #-0x10]!
    //     0xd102ec: mov             fp, SP
    // 0xd102f0: CheckStackOverflow
    //     0xd102f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd102f4: cmp             SP, x16
    //     0xd102f8: b.ls            #0xd10318
    // 0xd102fc: ldr             x0, [fp, #0x10]
    // 0xd10300: LoadField: r1 = r0->field_ab
    //     0xd10300: ldur            w1, [x0, #0xab]
    // 0xd10304: DecompressPointer r1
    //     0xd10304: add             x1, x1, HEAP, lsl #32
    // 0xd10308: r0 = of()
    //     0xd10308: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd1030c: LeaveFrame
    //     0xd1030c: mov             SP, fp
    //     0xd10310: ldp             fp, lr, [SP], #0x10
    // 0xd10314: ret
    //     0xd10314: ret             
    // 0xd10318: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd10318: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd1031c: b               #0xd102fc
  }
  TextTheme _textTheme(_DatePickerDefaultsM2) {
    // ** addr: 0xd10320, size: 0x58
    // 0xd10320: EnterFrame
    //     0xd10320: stp             fp, lr, [SP, #-0x10]!
    //     0xd10324: mov             fp, SP
    // 0xd10328: CheckStackOverflow
    //     0xd10328: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd1032c: cmp             SP, x16
    //     0xd10330: b.ls            #0xd10370
    // 0xd10334: ldr             x1, [fp, #0x10]
    // 0xd10338: LoadField: r0 = r1->field_af
    //     0xd10338: ldur            w0, [x1, #0xaf]
    // 0xd1033c: DecompressPointer r0
    //     0xd1033c: add             x0, x0, HEAP, lsl #32
    // 0xd10340: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd10344: cmp             w0, w16
    // 0xd10348: b.ne            #0xd10358
    // 0xd1034c: r2 = _theme
    //     0xd1034c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26490] Field <_DatePickerDefaultsM2@738353974._theme@738353974>: late final (offset: 0xb0)
    //     0xd10350: ldr             x2, [x2, #0x490]
    // 0xd10354: r0 = InitLateFinalInstanceField()
    //     0xd10354: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd10358: LoadField: r1 = r0->field_87
    //     0xd10358: ldur            w1, [x0, #0x87]
    // 0xd1035c: DecompressPointer r1
    //     0xd1035c: add             x1, x1, HEAP, lsl #32
    // 0xd10360: mov             x0, x1
    // 0xd10364: LeaveFrame
    //     0xd10364: mov             SP, fp
    //     0xd10368: ldp             fp, lr, [SP], #0x10
    // 0xd1036c: ret
    //     0xd1036c: ret             
    // 0xd10370: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd10370: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd10374: b               #0xd10334
  }
  bool _isDark(_DatePickerDefaultsM2) {
    // ** addr: 0xd19c5c, size: 0x68
    // 0xd19c5c: EnterFrame
    //     0xd19c5c: stp             fp, lr, [SP, #-0x10]!
    //     0xd19c60: mov             fp, SP
    // 0xd19c64: CheckStackOverflow
    //     0xd19c64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd19c68: cmp             SP, x16
    //     0xd19c6c: b.ls            #0xd19cbc
    // 0xd19c70: ldr             x1, [fp, #0x10]
    // 0xd19c74: LoadField: r0 = r1->field_b3
    //     0xd19c74: ldur            w0, [x1, #0xb3]
    // 0xd19c78: DecompressPointer r0
    //     0xd19c78: add             x0, x0, HEAP, lsl #32
    // 0xd19c7c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd19c80: cmp             w0, w16
    // 0xd19c84: b.ne            #0xd19c94
    // 0xd19c88: r2 = _colors
    //     0xd19c88: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xd19c8c: ldr             x2, [x2, #0x410]
    // 0xd19c90: r0 = InitLateFinalInstanceField()
    //     0xd19c90: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd19c94: LoadField: r1 = r0->field_7
    //     0xd19c94: ldur            w1, [x0, #7]
    // 0xd19c98: DecompressPointer r1
    //     0xd19c98: add             x1, x1, HEAP, lsl #32
    // 0xd19c9c: r16 = Instance_Brightness
    //     0xd19c9c: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0xd19ca0: cmp             w1, w16
    // 0xd19ca4: r16 = true
    //     0xd19ca4: add             x16, NULL, #0x20  ; true
    // 0xd19ca8: r17 = false
    //     0xd19ca8: add             x17, NULL, #0x30  ; false
    // 0xd19cac: csel            x0, x16, x17, eq
    // 0xd19cb0: LeaveFrame
    //     0xd19cb0: mov             SP, fp
    //     0xd19cb4: ldp             fp, lr, [SP], #0x10
    // 0xd19cb8: ret
    //     0xd19cb8: ret             
    // 0xd19cbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd19cbc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd19cc0: b               #0xd19c70
  }
  [closure] Color? <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xdf2190, size: 0x3c8
    // 0xdf2190: EnterFrame
    //     0xdf2190: stp             fp, lr, [SP, #-0x10]!
    //     0xdf2194: mov             fp, SP
    // 0xdf2198: AllocStack(0x8)
    //     0xdf2198: sub             SP, SP, #8
    // 0xdf219c: SetupParameters([dynamic _ /* r0 */])
    //     0xdf219c: ldr             x0, [fp, #0x18]
    //     0xdf21a0: ldur            w3, [x0, #0x17]
    //     0xdf21a4: add             x3, x3, HEAP, lsl #32
    //     0xdf21a8: stur            x3, [fp, #-8]
    // 0xdf21ac: CheckStackOverflow
    //     0xdf21ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf21b0: cmp             SP, x16
    //     0xdf21b4: b.ls            #0xdf2550
    // 0xdf21b8: ldr             x4, [fp, #0x10]
    // 0xdf21bc: r0 = LoadClassIdInstr(r4)
    //     0xdf21bc: ldur            x0, [x4, #-1]
    //     0xdf21c0: ubfx            x0, x0, #0xc, #0x14
    // 0xdf21c4: mov             x1, x4
    // 0xdf21c8: r2 = Instance_WidgetState
    //     0xdf21c8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xdf21cc: ldr             x2, [x2, #0x100]
    // 0xdf21d0: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdf21d0: mov             x17, #0x2929
    //     0xdf21d4: movk            x17, #1, lsl #16
    //     0xdf21d8: add             lr, x0, x17
    //     0xdf21dc: ldr             lr, [x21, lr, lsl #3]
    //     0xdf21e0: blr             lr
    // 0xdf21e4: tbnz            w0, #4, #0xdf2364
    // 0xdf21e8: ldr             x3, [fp, #0x10]
    // 0xdf21ec: r0 = LoadClassIdInstr(r3)
    //     0xdf21ec: ldur            x0, [x3, #-1]
    //     0xdf21f0: ubfx            x0, x0, #0xc, #0x14
    // 0xdf21f4: mov             x1, x3
    // 0xdf21f8: r2 = Instance_WidgetState
    //     0xdf21f8: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0xdf21fc: ldr             x2, [x2, #0xa48]
    // 0xdf2200: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdf2200: mov             x17, #0x2929
    //     0xdf2204: movk            x17, #1, lsl #16
    //     0xdf2208: add             lr, x0, x17
    //     0xdf220c: ldr             lr, [x21, lr, lsl #3]
    //     0xdf2210: blr             lr
    // 0xdf2214: tbnz            w0, #4, #0xdf2264
    // 0xdf2218: ldur            x3, [fp, #-8]
    // 0xdf221c: LoadField: r1 = r3->field_f
    //     0xdf221c: ldur            w1, [x3, #0xf]
    // 0xdf2220: DecompressPointer r1
    //     0xdf2220: add             x1, x1, HEAP, lsl #32
    // 0xdf2224: LoadField: r0 = r1->field_b3
    //     0xdf2224: ldur            w0, [x1, #0xb3]
    // 0xdf2228: DecompressPointer r0
    //     0xdf2228: add             x0, x0, HEAP, lsl #32
    // 0xdf222c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf2230: cmp             w0, w16
    // 0xdf2234: b.ne            #0xdf2244
    // 0xdf2238: r2 = _colors
    //     0xdf2238: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xdf223c: ldr             x2, [x2, #0x410]
    // 0xdf2240: r0 = InitLateFinalInstanceField()
    //     0xdf2240: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf2244: LoadField: r1 = r0->field_f
    //     0xdf2244: ldur            w1, [x0, #0xf]
    // 0xdf2248: DecompressPointer r1
    //     0xdf2248: add             x1, x1, HEAP, lsl #32
    // 0xdf224c: d0 = 0.380000
    //     0xdf224c: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xdf2250: ldr             d0, [x17, #0x1f0]
    // 0xdf2254: r0 = withOpacity()
    //     0xdf2254: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xdf2258: LeaveFrame
    //     0xdf2258: mov             SP, fp
    //     0xdf225c: ldp             fp, lr, [SP], #0x10
    // 0xdf2260: ret
    //     0xdf2260: ret             
    // 0xdf2264: ldr             x4, [fp, #0x10]
    // 0xdf2268: ldur            x3, [fp, #-8]
    // 0xdf226c: r0 = LoadClassIdInstr(r4)
    //     0xdf226c: ldur            x0, [x4, #-1]
    //     0xdf2270: ubfx            x0, x0, #0xc, #0x14
    // 0xdf2274: mov             x1, x4
    // 0xdf2278: r2 = Instance_WidgetState
    //     0xdf2278: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xdf227c: ldr             x2, [x2, #0xa50]
    // 0xdf2280: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdf2280: mov             x17, #0x2929
    //     0xdf2284: movk            x17, #1, lsl #16
    //     0xdf2288: add             lr, x0, x17
    //     0xdf228c: ldr             lr, [x21, lr, lsl #3]
    //     0xdf2290: blr             lr
    // 0xdf2294: tbnz            w0, #4, #0xdf22e4
    // 0xdf2298: ldur            x3, [fp, #-8]
    // 0xdf229c: LoadField: r1 = r3->field_f
    //     0xdf229c: ldur            w1, [x3, #0xf]
    // 0xdf22a0: DecompressPointer r1
    //     0xdf22a0: add             x1, x1, HEAP, lsl #32
    // 0xdf22a4: LoadField: r0 = r1->field_b3
    //     0xdf22a4: ldur            w0, [x1, #0xb3]
    // 0xdf22a8: DecompressPointer r0
    //     0xdf22a8: add             x0, x0, HEAP, lsl #32
    // 0xdf22ac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf22b0: cmp             w0, w16
    // 0xdf22b4: b.ne            #0xdf22c4
    // 0xdf22b8: r2 = _colors
    //     0xdf22b8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xdf22bc: ldr             x2, [x2, #0x410]
    // 0xdf22c0: r0 = InitLateFinalInstanceField()
    //     0xdf22c0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf22c4: LoadField: r1 = r0->field_f
    //     0xdf22c4: ldur            w1, [x0, #0xf]
    // 0xdf22c8: DecompressPointer r1
    //     0xdf22c8: add             x1, x1, HEAP, lsl #32
    // 0xdf22cc: d0 = 0.080000
    //     0xdf22cc: add             x17, PP, #0x15, lsl #12  ; [pp+0x15a58] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0xdf22d0: ldr             d0, [x17, #0xa58]
    // 0xdf22d4: r0 = withOpacity()
    //     0xdf22d4: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xdf22d8: LeaveFrame
    //     0xdf22d8: mov             SP, fp
    //     0xdf22dc: ldp             fp, lr, [SP], #0x10
    // 0xdf22e0: ret
    //     0xdf22e0: ret             
    // 0xdf22e4: ldr             x4, [fp, #0x10]
    // 0xdf22e8: ldur            x3, [fp, #-8]
    // 0xdf22ec: r0 = LoadClassIdInstr(r4)
    //     0xdf22ec: ldur            x0, [x4, #-1]
    //     0xdf22f0: ubfx            x0, x0, #0xc, #0x14
    // 0xdf22f4: mov             x1, x4
    // 0xdf22f8: r2 = Instance_WidgetState
    //     0xdf22f8: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xdf22fc: ldr             x2, [x2, #0xa60]
    // 0xdf2300: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdf2300: mov             x17, #0x2929
    //     0xdf2304: movk            x17, #1, lsl #16
    //     0xdf2308: add             lr, x0, x17
    //     0xdf230c: ldr             lr, [x21, lr, lsl #3]
    //     0xdf2310: blr             lr
    // 0xdf2314: tbnz            w0, #4, #0xdf2540
    // 0xdf2318: ldur            x3, [fp, #-8]
    // 0xdf231c: LoadField: r1 = r3->field_f
    //     0xdf231c: ldur            w1, [x3, #0xf]
    // 0xdf2320: DecompressPointer r1
    //     0xdf2320: add             x1, x1, HEAP, lsl #32
    // 0xdf2324: LoadField: r0 = r1->field_b3
    //     0xdf2324: ldur            w0, [x1, #0xb3]
    // 0xdf2328: DecompressPointer r0
    //     0xdf2328: add             x0, x0, HEAP, lsl #32
    // 0xdf232c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf2330: cmp             w0, w16
    // 0xdf2334: b.ne            #0xdf2344
    // 0xdf2338: r2 = _colors
    //     0xdf2338: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xdf233c: ldr             x2, [x2, #0x410]
    // 0xdf2340: r0 = InitLateFinalInstanceField()
    //     0xdf2340: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf2344: LoadField: r1 = r0->field_f
    //     0xdf2344: ldur            w1, [x0, #0xf]
    // 0xdf2348: DecompressPointer r1
    //     0xdf2348: add             x1, x1, HEAP, lsl #32
    // 0xdf234c: d0 = 0.120000
    //     0xdf234c: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xdf2350: ldr             d0, [x17, #0xc40]
    // 0xdf2354: r0 = withOpacity()
    //     0xdf2354: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xdf2358: LeaveFrame
    //     0xdf2358: mov             SP, fp
    //     0xdf235c: ldp             fp, lr, [SP], #0x10
    // 0xdf2360: ret
    //     0xdf2360: ret             
    // 0xdf2364: ldr             x4, [fp, #0x10]
    // 0xdf2368: ldur            x3, [fp, #-8]
    // 0xdf236c: r0 = LoadClassIdInstr(r4)
    //     0xdf236c: ldur            x0, [x4, #-1]
    //     0xdf2370: ubfx            x0, x0, #0xc, #0x14
    // 0xdf2374: mov             x1, x4
    // 0xdf2378: r2 = Instance_WidgetState
    //     0xdf2378: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0xdf237c: ldr             x2, [x2, #0xa48]
    // 0xdf2380: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdf2380: mov             x17, #0x2929
    //     0xdf2384: movk            x17, #1, lsl #16
    //     0xdf2388: add             lr, x0, x17
    //     0xdf238c: ldr             lr, [x21, lr, lsl #3]
    //     0xdf2390: blr             lr
    // 0xdf2394: tbnz            w0, #4, #0xdf2404
    // 0xdf2398: ldur            x3, [fp, #-8]
    // 0xdf239c: LoadField: r1 = r3->field_f
    //     0xdf239c: ldur            w1, [x3, #0xf]
    // 0xdf23a0: DecompressPointer r1
    //     0xdf23a0: add             x1, x1, HEAP, lsl #32
    // 0xdf23a4: LoadField: r0 = r1->field_b3
    //     0xdf23a4: ldur            w0, [x1, #0xb3]
    // 0xdf23a8: DecompressPointer r0
    //     0xdf23a8: add             x0, x0, HEAP, lsl #32
    // 0xdf23ac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf23b0: cmp             w0, w16
    // 0xdf23b4: b.ne            #0xdf23c4
    // 0xdf23b8: r2 = _colors
    //     0xdf23b8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xdf23bc: ldr             x2, [x2, #0x410]
    // 0xdf23c0: r0 = InitLateFinalInstanceField()
    //     0xdf23c0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf23c4: LoadField: r1 = r0->field_a3
    //     0xdf23c4: ldur            w1, [x0, #0xa3]
    // 0xdf23c8: DecompressPointer r1
    //     0xdf23c8: add             x1, x1, HEAP, lsl #32
    // 0xdf23cc: cmp             w1, NULL
    // 0xdf23d0: b.ne            #0xdf23dc
    // 0xdf23d4: LoadField: r1 = r0->field_7f
    //     0xdf23d4: ldur            w1, [x0, #0x7f]
    // 0xdf23d8: DecompressPointer r1
    //     0xdf23d8: add             x1, x1, HEAP, lsl #32
    // 0xdf23dc: r0 = LoadClassIdInstr(r1)
    //     0xdf23dc: ldur            x0, [x1, #-1]
    //     0xdf23e0: ubfx            x0, x0, #0xc, #0x14
    // 0xdf23e4: d0 = 0.120000
    //     0xdf23e4: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xdf23e8: ldr             d0, [x17, #0xc40]
    // 0xdf23ec: r0 = GDT[cid_x0 + -0x1000]()
    //     0xdf23ec: sub             lr, x0, #1, lsl #12
    //     0xdf23f0: ldr             lr, [x21, lr, lsl #3]
    //     0xdf23f4: blr             lr
    // 0xdf23f8: LeaveFrame
    //     0xdf23f8: mov             SP, fp
    //     0xdf23fc: ldp             fp, lr, [SP], #0x10
    // 0xdf2400: ret
    //     0xdf2400: ret             
    // 0xdf2404: ldr             x4, [fp, #0x10]
    // 0xdf2408: ldur            x3, [fp, #-8]
    // 0xdf240c: r0 = LoadClassIdInstr(r4)
    //     0xdf240c: ldur            x0, [x4, #-1]
    //     0xdf2410: ubfx            x0, x0, #0xc, #0x14
    // 0xdf2414: mov             x1, x4
    // 0xdf2418: r2 = Instance_WidgetState
    //     0xdf2418: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xdf241c: ldr             x2, [x2, #0xa50]
    // 0xdf2420: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdf2420: mov             x17, #0x2929
    //     0xdf2424: movk            x17, #1, lsl #16
    //     0xdf2428: add             lr, x0, x17
    //     0xdf242c: ldr             lr, [x21, lr, lsl #3]
    //     0xdf2430: blr             lr
    // 0xdf2434: tbnz            w0, #4, #0xdf24a4
    // 0xdf2438: ldur            x3, [fp, #-8]
    // 0xdf243c: LoadField: r1 = r3->field_f
    //     0xdf243c: ldur            w1, [x3, #0xf]
    // 0xdf2440: DecompressPointer r1
    //     0xdf2440: add             x1, x1, HEAP, lsl #32
    // 0xdf2444: LoadField: r0 = r1->field_b3
    //     0xdf2444: ldur            w0, [x1, #0xb3]
    // 0xdf2448: DecompressPointer r0
    //     0xdf2448: add             x0, x0, HEAP, lsl #32
    // 0xdf244c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf2450: cmp             w0, w16
    // 0xdf2454: b.ne            #0xdf2464
    // 0xdf2458: r2 = _colors
    //     0xdf2458: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xdf245c: ldr             x2, [x2, #0x410]
    // 0xdf2460: r0 = InitLateFinalInstanceField()
    //     0xdf2460: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf2464: LoadField: r1 = r0->field_a3
    //     0xdf2464: ldur            w1, [x0, #0xa3]
    // 0xdf2468: DecompressPointer r1
    //     0xdf2468: add             x1, x1, HEAP, lsl #32
    // 0xdf246c: cmp             w1, NULL
    // 0xdf2470: b.ne            #0xdf247c
    // 0xdf2474: LoadField: r1 = r0->field_7f
    //     0xdf2474: ldur            w1, [x0, #0x7f]
    // 0xdf2478: DecompressPointer r1
    //     0xdf2478: add             x1, x1, HEAP, lsl #32
    // 0xdf247c: r0 = LoadClassIdInstr(r1)
    //     0xdf247c: ldur            x0, [x1, #-1]
    //     0xdf2480: ubfx            x0, x0, #0xc, #0x14
    // 0xdf2484: d0 = 0.080000
    //     0xdf2484: add             x17, PP, #0x15, lsl #12  ; [pp+0x15a58] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0xdf2488: ldr             d0, [x17, #0xa58]
    // 0xdf248c: r0 = GDT[cid_x0 + -0x1000]()
    //     0xdf248c: sub             lr, x0, #1, lsl #12
    //     0xdf2490: ldr             lr, [x21, lr, lsl #3]
    //     0xdf2494: blr             lr
    // 0xdf2498: LeaveFrame
    //     0xdf2498: mov             SP, fp
    //     0xdf249c: ldp             fp, lr, [SP], #0x10
    // 0xdf24a0: ret
    //     0xdf24a0: ret             
    // 0xdf24a4: ldr             x1, [fp, #0x10]
    // 0xdf24a8: ldur            x3, [fp, #-8]
    // 0xdf24ac: r0 = LoadClassIdInstr(r1)
    //     0xdf24ac: ldur            x0, [x1, #-1]
    //     0xdf24b0: ubfx            x0, x0, #0xc, #0x14
    // 0xdf24b4: r2 = Instance_WidgetState
    //     0xdf24b4: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xdf24b8: ldr             x2, [x2, #0xa60]
    // 0xdf24bc: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdf24bc: mov             x17, #0x2929
    //     0xdf24c0: movk            x17, #1, lsl #16
    //     0xdf24c4: add             lr, x0, x17
    //     0xdf24c8: ldr             lr, [x21, lr, lsl #3]
    //     0xdf24cc: blr             lr
    // 0xdf24d0: tbnz            w0, #4, #0xdf2540
    // 0xdf24d4: ldur            x0, [fp, #-8]
    // 0xdf24d8: LoadField: r1 = r0->field_f
    //     0xdf24d8: ldur            w1, [x0, #0xf]
    // 0xdf24dc: DecompressPointer r1
    //     0xdf24dc: add             x1, x1, HEAP, lsl #32
    // 0xdf24e0: LoadField: r0 = r1->field_b3
    //     0xdf24e0: ldur            w0, [x1, #0xb3]
    // 0xdf24e4: DecompressPointer r0
    //     0xdf24e4: add             x0, x0, HEAP, lsl #32
    // 0xdf24e8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf24ec: cmp             w0, w16
    // 0xdf24f0: b.ne            #0xdf2500
    // 0xdf24f4: r2 = _colors
    //     0xdf24f4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xdf24f8: ldr             x2, [x2, #0x410]
    // 0xdf24fc: r0 = InitLateFinalInstanceField()
    //     0xdf24fc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf2500: LoadField: r1 = r0->field_a3
    //     0xdf2500: ldur            w1, [x0, #0xa3]
    // 0xdf2504: DecompressPointer r1
    //     0xdf2504: add             x1, x1, HEAP, lsl #32
    // 0xdf2508: cmp             w1, NULL
    // 0xdf250c: b.ne            #0xdf2518
    // 0xdf2510: LoadField: r1 = r0->field_7f
    //     0xdf2510: ldur            w1, [x0, #0x7f]
    // 0xdf2514: DecompressPointer r1
    //     0xdf2514: add             x1, x1, HEAP, lsl #32
    // 0xdf2518: r0 = LoadClassIdInstr(r1)
    //     0xdf2518: ldur            x0, [x1, #-1]
    //     0xdf251c: ubfx            x0, x0, #0xc, #0x14
    // 0xdf2520: d0 = 0.120000
    //     0xdf2520: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xdf2524: ldr             d0, [x17, #0xc40]
    // 0xdf2528: r0 = GDT[cid_x0 + -0x1000]()
    //     0xdf2528: sub             lr, x0, #1, lsl #12
    //     0xdf252c: ldr             lr, [x21, lr, lsl #3]
    //     0xdf2530: blr             lr
    // 0xdf2534: LeaveFrame
    //     0xdf2534: mov             SP, fp
    //     0xdf2538: ldp             fp, lr, [SP], #0x10
    // 0xdf253c: ret
    //     0xdf253c: ret             
    // 0xdf2540: r0 = Null
    //     0xdf2540: mov             x0, NULL
    // 0xdf2544: LeaveFrame
    //     0xdf2544: mov             SP, fp
    //     0xdf2548: ldp             fp, lr, [SP], #0x10
    // 0xdf254c: ret
    //     0xdf254c: ret             
    // 0xdf2550: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf2550: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf2554: b               #0xdf21b8
  }
  [closure] Color? <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xdf2afc, size: 0xb0
    // 0xdf2afc: EnterFrame
    //     0xdf2afc: stp             fp, lr, [SP, #-0x10]!
    //     0xdf2b00: mov             fp, SP
    // 0xdf2b04: AllocStack(0x8)
    //     0xdf2b04: sub             SP, SP, #8
    // 0xdf2b08: SetupParameters([dynamic _ /* r0 */])
    //     0xdf2b08: ldr             x0, [fp, #0x18]
    //     0xdf2b0c: ldur            w3, [x0, #0x17]
    //     0xdf2b10: add             x3, x3, HEAP, lsl #32
    //     0xdf2b14: stur            x3, [fp, #-8]
    // 0xdf2b18: CheckStackOverflow
    //     0xdf2b18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf2b1c: cmp             SP, x16
    //     0xdf2b20: b.ls            #0xdf2ba4
    // 0xdf2b24: ldr             x1, [fp, #0x10]
    // 0xdf2b28: r0 = LoadClassIdInstr(r1)
    //     0xdf2b28: ldur            x0, [x1, #-1]
    //     0xdf2b2c: ubfx            x0, x0, #0xc, #0x14
    // 0xdf2b30: r2 = Instance_WidgetState
    //     0xdf2b30: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xdf2b34: ldr             x2, [x2, #0x100]
    // 0xdf2b38: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdf2b38: mov             x17, #0x2929
    //     0xdf2b3c: movk            x17, #1, lsl #16
    //     0xdf2b40: add             lr, x0, x17
    //     0xdf2b44: ldr             lr, [x21, lr, lsl #3]
    //     0xdf2b48: blr             lr
    // 0xdf2b4c: tbnz            w0, #4, #0xdf2b94
    // 0xdf2b50: ldur            x0, [fp, #-8]
    // 0xdf2b54: LoadField: r1 = r0->field_f
    //     0xdf2b54: ldur            w1, [x0, #0xf]
    // 0xdf2b58: DecompressPointer r1
    //     0xdf2b58: add             x1, x1, HEAP, lsl #32
    // 0xdf2b5c: LoadField: r0 = r1->field_b3
    //     0xdf2b5c: ldur            w0, [x1, #0xb3]
    // 0xdf2b60: DecompressPointer r0
    //     0xdf2b60: add             x0, x0, HEAP, lsl #32
    // 0xdf2b64: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf2b68: cmp             w0, w16
    // 0xdf2b6c: b.ne            #0xdf2b7c
    // 0xdf2b70: r2 = _colors
    //     0xdf2b70: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xdf2b74: ldr             x2, [x2, #0x410]
    // 0xdf2b78: r0 = InitLateFinalInstanceField()
    //     0xdf2b78: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf2b7c: LoadField: r1 = r0->field_b
    //     0xdf2b7c: ldur            w1, [x0, #0xb]
    // 0xdf2b80: DecompressPointer r1
    //     0xdf2b80: add             x1, x1, HEAP, lsl #32
    // 0xdf2b84: mov             x0, x1
    // 0xdf2b88: LeaveFrame
    //     0xdf2b88: mov             SP, fp
    //     0xdf2b8c: ldp             fp, lr, [SP], #0x10
    // 0xdf2b90: ret
    //     0xdf2b90: ret             
    // 0xdf2b94: r0 = Null
    //     0xdf2b94: mov             x0, NULL
    // 0xdf2b98: LeaveFrame
    //     0xdf2b98: mov             SP, fp
    //     0xdf2b9c: ldp             fp, lr, [SP], #0x10
    // 0xdf2ba0: ret
    //     0xdf2ba0: ret             
    // 0xdf2ba4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf2ba4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf2ba8: b               #0xdf2b24
  }
  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xdf2e38, size: 0x174
    // 0xdf2e38: EnterFrame
    //     0xdf2e38: stp             fp, lr, [SP, #-0x10]!
    //     0xdf2e3c: mov             fp, SP
    // 0xdf2e40: AllocStack(0x8)
    //     0xdf2e40: sub             SP, SP, #8
    // 0xdf2e44: SetupParameters([dynamic _ /* r0 */])
    //     0xdf2e44: ldr             x0, [fp, #0x18]
    //     0xdf2e48: ldur            w3, [x0, #0x17]
    //     0xdf2e4c: add             x3, x3, HEAP, lsl #32
    //     0xdf2e50: stur            x3, [fp, #-8]
    // 0xdf2e54: CheckStackOverflow
    //     0xdf2e54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf2e58: cmp             SP, x16
    //     0xdf2e5c: b.ls            #0xdf2fa4
    // 0xdf2e60: ldr             x4, [fp, #0x10]
    // 0xdf2e64: r0 = LoadClassIdInstr(r4)
    //     0xdf2e64: ldur            x0, [x4, #-1]
    //     0xdf2e68: ubfx            x0, x0, #0xc, #0x14
    // 0xdf2e6c: mov             x1, x4
    // 0xdf2e70: r2 = Instance_WidgetState
    //     0xdf2e70: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xdf2e74: ldr             x2, [x2, #0x100]
    // 0xdf2e78: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdf2e78: mov             x17, #0x2929
    //     0xdf2e7c: movk            x17, #1, lsl #16
    //     0xdf2e80: add             lr, x0, x17
    //     0xdf2e84: ldr             lr, [x21, lr, lsl #3]
    //     0xdf2e88: blr             lr
    // 0xdf2e8c: tbnz            w0, #4, #0xdf2ed4
    // 0xdf2e90: ldur            x3, [fp, #-8]
    // 0xdf2e94: LoadField: r1 = r3->field_f
    //     0xdf2e94: ldur            w1, [x3, #0xf]
    // 0xdf2e98: DecompressPointer r1
    //     0xdf2e98: add             x1, x1, HEAP, lsl #32
    // 0xdf2e9c: LoadField: r0 = r1->field_b3
    //     0xdf2e9c: ldur            w0, [x1, #0xb3]
    // 0xdf2ea0: DecompressPointer r0
    //     0xdf2ea0: add             x0, x0, HEAP, lsl #32
    // 0xdf2ea4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf2ea8: cmp             w0, w16
    // 0xdf2eac: b.ne            #0xdf2ebc
    // 0xdf2eb0: r2 = _colors
    //     0xdf2eb0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xdf2eb4: ldr             x2, [x2, #0x410]
    // 0xdf2eb8: r0 = InitLateFinalInstanceField()
    //     0xdf2eb8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf2ebc: LoadField: r1 = r0->field_f
    //     0xdf2ebc: ldur            w1, [x0, #0xf]
    // 0xdf2ec0: DecompressPointer r1
    //     0xdf2ec0: add             x1, x1, HEAP, lsl #32
    // 0xdf2ec4: mov             x0, x1
    // 0xdf2ec8: LeaveFrame
    //     0xdf2ec8: mov             SP, fp
    //     0xdf2ecc: ldp             fp, lr, [SP], #0x10
    // 0xdf2ed0: ret
    //     0xdf2ed0: ret             
    // 0xdf2ed4: ldr             x1, [fp, #0x10]
    // 0xdf2ed8: ldur            x3, [fp, #-8]
    // 0xdf2edc: r0 = LoadClassIdInstr(r1)
    //     0xdf2edc: ldur            x0, [x1, #-1]
    //     0xdf2ee0: ubfx            x0, x0, #0xc, #0x14
    // 0xdf2ee4: r2 = Instance_WidgetState
    //     0xdf2ee4: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xdf2ee8: ldr             x2, [x2, #0xa70]
    // 0xdf2eec: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdf2eec: mov             x17, #0x2929
    //     0xdf2ef0: movk            x17, #1, lsl #16
    //     0xdf2ef4: add             lr, x0, x17
    //     0xdf2ef8: ldr             lr, [x21, lr, lsl #3]
    //     0xdf2efc: blr             lr
    // 0xdf2f00: tbnz            w0, #4, #0xdf2f60
    // 0xdf2f04: ldur            x0, [fp, #-8]
    // 0xdf2f08: LoadField: r1 = r0->field_f
    //     0xdf2f08: ldur            w1, [x0, #0xf]
    // 0xdf2f0c: DecompressPointer r1
    //     0xdf2f0c: add             x1, x1, HEAP, lsl #32
    // 0xdf2f10: LoadField: r0 = r1->field_b3
    //     0xdf2f10: ldur            w0, [x1, #0xb3]
    // 0xdf2f14: DecompressPointer r0
    //     0xdf2f14: add             x0, x0, HEAP, lsl #32
    // 0xdf2f18: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf2f1c: cmp             w0, w16
    // 0xdf2f20: b.ne            #0xdf2f30
    // 0xdf2f24: r2 = _colors
    //     0xdf2f24: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xdf2f28: ldr             x2, [x2, #0x410]
    // 0xdf2f2c: r0 = InitLateFinalInstanceField()
    //     0xdf2f2c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf2f30: LoadField: r1 = r0->field_7f
    //     0xdf2f30: ldur            w1, [x0, #0x7f]
    // 0xdf2f34: DecompressPointer r1
    //     0xdf2f34: add             x1, x1, HEAP, lsl #32
    // 0xdf2f38: r0 = LoadClassIdInstr(r1)
    //     0xdf2f38: ldur            x0, [x1, #-1]
    //     0xdf2f3c: ubfx            x0, x0, #0xc, #0x14
    // 0xdf2f40: d0 = 0.380000
    //     0xdf2f40: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xdf2f44: ldr             d0, [x17, #0x1f0]
    // 0xdf2f48: r0 = GDT[cid_x0 + -0x1000]()
    //     0xdf2f48: sub             lr, x0, #1, lsl #12
    //     0xdf2f4c: ldr             lr, [x21, lr, lsl #3]
    //     0xdf2f50: blr             lr
    // 0xdf2f54: LeaveFrame
    //     0xdf2f54: mov             SP, fp
    //     0xdf2f58: ldp             fp, lr, [SP], #0x10
    // 0xdf2f5c: ret
    //     0xdf2f5c: ret             
    // 0xdf2f60: ldur            x0, [fp, #-8]
    // 0xdf2f64: LoadField: r1 = r0->field_f
    //     0xdf2f64: ldur            w1, [x0, #0xf]
    // 0xdf2f68: DecompressPointer r1
    //     0xdf2f68: add             x1, x1, HEAP, lsl #32
    // 0xdf2f6c: LoadField: r0 = r1->field_b3
    //     0xdf2f6c: ldur            w0, [x1, #0xb3]
    // 0xdf2f70: DecompressPointer r0
    //     0xdf2f70: add             x0, x0, HEAP, lsl #32
    // 0xdf2f74: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf2f78: cmp             w0, w16
    // 0xdf2f7c: b.ne            #0xdf2f8c
    // 0xdf2f80: r2 = _colors
    //     0xdf2f80: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xdf2f84: ldr             x2, [x2, #0x410]
    // 0xdf2f88: r0 = InitLateFinalInstanceField()
    //     0xdf2f88: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf2f8c: LoadField: r1 = r0->field_7f
    //     0xdf2f8c: ldur            w1, [x0, #0x7f]
    // 0xdf2f90: DecompressPointer r1
    //     0xdf2f90: add             x1, x1, HEAP, lsl #32
    // 0xdf2f94: mov             x0, x1
    // 0xdf2f98: LeaveFrame
    //     0xdf2f98: mov             SP, fp
    //     0xdf2f9c: ldp             fp, lr, [SP], #0x10
    // 0xdf2fa0: ret
    //     0xdf2fa0: ret             
    // 0xdf2fa4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf2fa4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf2fa8: b               #0xdf2e60
  }
  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xdf3120, size: 0x174
    // 0xdf3120: EnterFrame
    //     0xdf3120: stp             fp, lr, [SP, #-0x10]!
    //     0xdf3124: mov             fp, SP
    // 0xdf3128: AllocStack(0x8)
    //     0xdf3128: sub             SP, SP, #8
    // 0xdf312c: SetupParameters([dynamic _ /* r0 */])
    //     0xdf312c: ldr             x0, [fp, #0x18]
    //     0xdf3130: ldur            w3, [x0, #0x17]
    //     0xdf3134: add             x3, x3, HEAP, lsl #32
    //     0xdf3138: stur            x3, [fp, #-8]
    // 0xdf313c: CheckStackOverflow
    //     0xdf313c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf3140: cmp             SP, x16
    //     0xdf3144: b.ls            #0xdf328c
    // 0xdf3148: ldr             x4, [fp, #0x10]
    // 0xdf314c: r0 = LoadClassIdInstr(r4)
    //     0xdf314c: ldur            x0, [x4, #-1]
    //     0xdf3150: ubfx            x0, x0, #0xc, #0x14
    // 0xdf3154: mov             x1, x4
    // 0xdf3158: r2 = Instance_WidgetState
    //     0xdf3158: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xdf315c: ldr             x2, [x2, #0x100]
    // 0xdf3160: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdf3160: mov             x17, #0x2929
    //     0xdf3164: movk            x17, #1, lsl #16
    //     0xdf3168: add             lr, x0, x17
    //     0xdf316c: ldr             lr, [x21, lr, lsl #3]
    //     0xdf3170: blr             lr
    // 0xdf3174: tbnz            w0, #4, #0xdf31bc
    // 0xdf3178: ldur            x3, [fp, #-8]
    // 0xdf317c: LoadField: r1 = r3->field_f
    //     0xdf317c: ldur            w1, [x3, #0xf]
    // 0xdf3180: DecompressPointer r1
    //     0xdf3180: add             x1, x1, HEAP, lsl #32
    // 0xdf3184: LoadField: r0 = r1->field_b3
    //     0xdf3184: ldur            w0, [x1, #0xb3]
    // 0xdf3188: DecompressPointer r0
    //     0xdf3188: add             x0, x0, HEAP, lsl #32
    // 0xdf318c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf3190: cmp             w0, w16
    // 0xdf3194: b.ne            #0xdf31a4
    // 0xdf3198: r2 = _colors
    //     0xdf3198: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xdf319c: ldr             x2, [x2, #0x410]
    // 0xdf31a0: r0 = InitLateFinalInstanceField()
    //     0xdf31a0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf31a4: LoadField: r1 = r0->field_f
    //     0xdf31a4: ldur            w1, [x0, #0xf]
    // 0xdf31a8: DecompressPointer r1
    //     0xdf31a8: add             x1, x1, HEAP, lsl #32
    // 0xdf31ac: mov             x0, x1
    // 0xdf31b0: LeaveFrame
    //     0xdf31b0: mov             SP, fp
    //     0xdf31b4: ldp             fp, lr, [SP], #0x10
    // 0xdf31b8: ret
    //     0xdf31b8: ret             
    // 0xdf31bc: ldr             x1, [fp, #0x10]
    // 0xdf31c0: ldur            x3, [fp, #-8]
    // 0xdf31c4: r0 = LoadClassIdInstr(r1)
    //     0xdf31c4: ldur            x0, [x1, #-1]
    //     0xdf31c8: ubfx            x0, x0, #0xc, #0x14
    // 0xdf31cc: r2 = Instance_WidgetState
    //     0xdf31cc: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xdf31d0: ldr             x2, [x2, #0xa70]
    // 0xdf31d4: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdf31d4: mov             x17, #0x2929
    //     0xdf31d8: movk            x17, #1, lsl #16
    //     0xdf31dc: add             lr, x0, x17
    //     0xdf31e0: ldr             lr, [x21, lr, lsl #3]
    //     0xdf31e4: blr             lr
    // 0xdf31e8: tbnz            w0, #4, #0xdf3248
    // 0xdf31ec: ldur            x0, [fp, #-8]
    // 0xdf31f0: LoadField: r1 = r0->field_f
    //     0xdf31f0: ldur            w1, [x0, #0xf]
    // 0xdf31f4: DecompressPointer r1
    //     0xdf31f4: add             x1, x1, HEAP, lsl #32
    // 0xdf31f8: LoadField: r0 = r1->field_b3
    //     0xdf31f8: ldur            w0, [x1, #0xb3]
    // 0xdf31fc: DecompressPointer r0
    //     0xdf31fc: add             x0, x0, HEAP, lsl #32
    // 0xdf3200: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf3204: cmp             w0, w16
    // 0xdf3208: b.ne            #0xdf3218
    // 0xdf320c: r2 = _colors
    //     0xdf320c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xdf3210: ldr             x2, [x2, #0x410]
    // 0xdf3214: r0 = InitLateFinalInstanceField()
    //     0xdf3214: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf3218: LoadField: r1 = r0->field_7f
    //     0xdf3218: ldur            w1, [x0, #0x7f]
    // 0xdf321c: DecompressPointer r1
    //     0xdf321c: add             x1, x1, HEAP, lsl #32
    // 0xdf3220: r0 = LoadClassIdInstr(r1)
    //     0xdf3220: ldur            x0, [x1, #-1]
    //     0xdf3224: ubfx            x0, x0, #0xc, #0x14
    // 0xdf3228: d0 = 0.380000
    //     0xdf3228: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xdf322c: ldr             d0, [x17, #0x1f0]
    // 0xdf3230: r0 = GDT[cid_x0 + -0x1000]()
    //     0xdf3230: sub             lr, x0, #1, lsl #12
    //     0xdf3234: ldr             lr, [x21, lr, lsl #3]
    //     0xdf3238: blr             lr
    // 0xdf323c: LeaveFrame
    //     0xdf323c: mov             SP, fp
    //     0xdf3240: ldp             fp, lr, [SP], #0x10
    // 0xdf3244: ret
    //     0xdf3244: ret             
    // 0xdf3248: ldur            x0, [fp, #-8]
    // 0xdf324c: LoadField: r1 = r0->field_f
    //     0xdf324c: ldur            w1, [x0, #0xf]
    // 0xdf3250: DecompressPointer r1
    //     0xdf3250: add             x1, x1, HEAP, lsl #32
    // 0xdf3254: LoadField: r0 = r1->field_b3
    //     0xdf3254: ldur            w0, [x1, #0xb3]
    // 0xdf3258: DecompressPointer r0
    //     0xdf3258: add             x0, x0, HEAP, lsl #32
    // 0xdf325c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf3260: cmp             w0, w16
    // 0xdf3264: b.ne            #0xdf3274
    // 0xdf3268: r2 = _colors
    //     0xdf3268: add             x2, PP, #0x26, lsl #12  ; [pp+0x26410] Field <_DatePickerDefaultsM2@738353974._colors@738353974>: late final (offset: 0xb4)
    //     0xdf326c: ldr             x2, [x2, #0x410]
    // 0xdf3270: r0 = InitLateFinalInstanceField()
    //     0xdf3270: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdf3274: LoadField: r1 = r0->field_b
    //     0xdf3274: ldur            w1, [x0, #0xb]
    // 0xdf3278: DecompressPointer r1
    //     0xdf3278: add             x1, x1, HEAP, lsl #32
    // 0xdf327c: mov             x0, x1
    // 0xdf3280: LeaveFrame
    //     0xdf3280: mov             SP, fp
    //     0xdf3284: ldp             fp, lr, [SP], #0x10
    // 0xdf3288: ret
    //     0xdf3288: ret             
    // 0xdf328c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf328c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf3290: b               #0xdf3148
  }
}

// class id: 6850, size: 0x10, field offset: 0x10
//   const constructor, 
abstract class DatePickerTheme extends InheritedTheme {

  static _ defaults(/* No info */) {
    // ** addr: 0xd0fd74, size: 0x7c
    // 0xd0fd74: EnterFrame
    //     0xd0fd74: stp             fp, lr, [SP, #-0x10]!
    //     0xd0fd78: mov             fp, SP
    // 0xd0fd7c: AllocStack(0x10)
    //     0xd0fd7c: sub             SP, SP, #0x10
    // 0xd0fd80: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */)
    //     0xd0fd80: mov             x0, x1
    //     0xd0fd84: stur            x1, [fp, #-8]
    // 0xd0fd88: CheckStackOverflow
    //     0xd0fd88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0fd8c: cmp             SP, x16
    //     0xd0fd90: b.ls            #0xd0fde8
    // 0xd0fd94: mov             x1, x0
    // 0xd0fd98: r0 = of()
    //     0xd0fd98: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd0fd9c: LoadField: r1 = r0->field_2f
    //     0xd0fd9c: ldur            w1, [x0, #0x2f]
    // 0xd0fda0: DecompressPointer r1
    //     0xd0fda0: add             x1, x1, HEAP, lsl #32
    // 0xd0fda4: tbnz            w1, #4, #0xd0fdc4
    // 0xd0fda8: r0 = _DatePickerDefaultsM3()
    //     0xd0fda8: bl              #0xd0ff60  ; Allocate_DatePickerDefaultsM3Stub -> _DatePickerDefaultsM3 (size=0xbc)
    // 0xd0fdac: mov             x1, x0
    // 0xd0fdb0: ldur            x2, [fp, #-8]
    // 0xd0fdb4: stur            x0, [fp, #-0x10]
    // 0xd0fdb8: r0 = _DatePickerDefaultsM3()
    //     0xd0fdb8: bl              #0xd0fedc  ; [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM3::_DatePickerDefaultsM3
    // 0xd0fdbc: ldur            x0, [fp, #-0x10]
    // 0xd0fdc0: b               #0xd0fddc
    // 0xd0fdc4: r0 = _DatePickerDefaultsM2()
    //     0xd0fdc4: bl              #0xd0fed0  ; Allocate_DatePickerDefaultsM2Stub -> _DatePickerDefaultsM2 (size=0xc0)
    // 0xd0fdc8: mov             x1, x0
    // 0xd0fdcc: ldur            x2, [fp, #-8]
    // 0xd0fdd0: stur            x0, [fp, #-8]
    // 0xd0fdd4: r0 = _DatePickerDefaultsM2()
    //     0xd0fdd4: bl              #0xd0fdf0  ; [package:flutter/src/material/date_picker_theme.dart] _DatePickerDefaultsM2::_DatePickerDefaultsM2
    // 0xd0fdd8: ldur            x0, [fp, #-8]
    // 0xd0fddc: LeaveFrame
    //     0xd0fddc: mov             SP, fp
    //     0xd0fde0: ldp             fp, lr, [SP], #0x10
    // 0xd0fde4: ret
    //     0xd0fde4: ret             
    // 0xd0fde8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0fde8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0fdec: b               #0xd0fd94
  }
  static _ of(/* No info */) {
    // ** addr: 0xd0ff6c, size: 0x50
    // 0xd0ff6c: EnterFrame
    //     0xd0ff6c: stp             fp, lr, [SP, #-0x10]!
    //     0xd0ff70: mov             fp, SP
    // 0xd0ff74: AllocStack(0x8)
    //     0xd0ff74: sub             SP, SP, #8
    // 0xd0ff78: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */)
    //     0xd0ff78: mov             x0, x1
    //     0xd0ff7c: stur            x1, [fp, #-8]
    // 0xd0ff80: CheckStackOverflow
    //     0xd0ff80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0ff84: cmp             SP, x16
    //     0xd0ff88: b.ls            #0xd0ffb4
    // 0xd0ff8c: mov             x1, x0
    // 0xd0ff90: r0 = maybeOf()
    //     0xd0ff90: bl              #0xd0ffbc  ; [package:flutter/src/material/date_picker_theme.dart] DatePickerTheme::maybeOf
    // 0xd0ff94: ldur            x1, [fp, #-8]
    // 0xd0ff98: r0 = of()
    //     0xd0ff98: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd0ff9c: LoadField: r1 = r0->field_c3
    //     0xd0ff9c: ldur            w1, [x0, #0xc3]
    // 0xd0ffa0: DecompressPointer r1
    //     0xd0ffa0: add             x1, x1, HEAP, lsl #32
    // 0xd0ffa4: mov             x0, x1
    // 0xd0ffa8: LeaveFrame
    //     0xd0ffa8: mov             SP, fp
    //     0xd0ffac: ldp             fp, lr, [SP], #0x10
    // 0xd0ffb0: ret
    //     0xd0ffb0: ret             
    // 0xd0ffb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0ffb4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0ffb8: b               #0xd0ff8c
  }
  static _ maybeOf(/* No info */) {
    // ** addr: 0xd0ffbc, size: 0x44
    // 0xd0ffbc: EnterFrame
    //     0xd0ffbc: stp             fp, lr, [SP, #-0x10]!
    //     0xd0ffc0: mov             fp, SP
    // 0xd0ffc4: AllocStack(0x10)
    //     0xd0ffc4: sub             SP, SP, #0x10
    // 0xd0ffc8: CheckStackOverflow
    //     0xd0ffc8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0ffcc: cmp             SP, x16
    //     0xd0ffd0: b.ls            #0xd0fff8
    // 0xd0ffd4: r16 = <DatePickerTheme>
    //     0xd0ffd4: add             x16, PP, #0x99, lsl #12  ; [pp+0x99d90] TypeArguments: <DatePickerTheme>
    //     0xd0ffd8: ldr             x16, [x16, #0xd90]
    // 0xd0ffdc: stp             x1, x16, [SP]
    // 0xd0ffe0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd0ffe0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd0ffe4: r0 = dependOnInheritedWidgetOfExactType()
    //     0xd0ffe4: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xd0ffe8: r0 = Null
    //     0xd0ffe8: mov             x0, NULL
    // 0xd0ffec: LeaveFrame
    //     0xd0ffec: mov             SP, fp
    //     0xd0fff0: ldp             fp, lr, [SP], #0x10
    // 0xd0fff4: ret
    //     0xd0fff4: ret             
    // 0xd0fff8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0fff8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0fffc: b               #0xd0ffd4
  }
}
