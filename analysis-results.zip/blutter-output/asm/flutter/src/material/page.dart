// lib: , url: package:flutter/src/material/page.dart

// class id: 1048926, size: 0x8
class :: {
}

// class id: 2658, size: 0xac, field offset: 0xa4
class MaterialPageRoute<X0> extends _MixinApplication85&PageRoute&MaterialRouteTransitionMixin<X0> {

  _ MaterialPageRoute(/* No info */) {
    // ** addr: 0xde816c, size: 0x104
    // 0xde816c: EnterFrame
    //     0xde816c: stp             fp, lr, [SP, #-0x10]!
    //     0xde8170: mov             fp, SP
    // 0xde8174: mov             x0, x2
    // 0xde8178: LoadField: r2 = r4->field_13
    //     0xde8178: ldur            w2, [x4, #0x13]
    // 0xde817c: LoadField: r3 = r4->field_1f
    //     0xde817c: ldur            w3, [x4, #0x1f]
    // 0xde8180: DecompressPointer r3
    //     0xde8180: add             x3, x3, HEAP, lsl #32
    // 0xde8184: r16 = "fullscreenDialog"
    //     0xde8184: add             x16, PP, #0x7d, lsl #12  ; [pp+0x7d450] "fullscreenDialog"
    //     0xde8188: ldr             x16, [x16, #0x450]
    // 0xde818c: cmp             w3, w16
    // 0xde8190: b.ne            #0xde81b4
    // 0xde8194: LoadField: r3 = r4->field_23
    //     0xde8194: ldur            w3, [x4, #0x23]
    // 0xde8198: DecompressPointer r3
    //     0xde8198: add             x3, x3, HEAP, lsl #32
    // 0xde819c: sub             w5, w2, w3
    // 0xde81a0: add             x3, fp, w5, sxtw #2
    // 0xde81a4: ldr             x3, [x3, #8]
    // 0xde81a8: mov             x5, x3
    // 0xde81ac: r3 = 1
    //     0xde81ac: mov             x3, #1
    // 0xde81b0: b               #0xde81bc
    // 0xde81b4: r5 = false
    //     0xde81b4: add             x5, NULL, #0x30  ; false
    // 0xde81b8: r3 = 0
    //     0xde81b8: mov             x3, #0
    // 0xde81bc: lsl             x6, x3, #1
    // 0xde81c0: lsl             w3, w6, #1
    // 0xde81c4: add             w6, w3, #8
    // 0xde81c8: ArrayLoad: r7 = r4[r6]  ; Unknown_4
    //     0xde81c8: add             x16, x4, w6, sxtw #1
    //     0xde81cc: ldur            w7, [x16, #0xf]
    // 0xde81d0: DecompressPointer r7
    //     0xde81d0: add             x7, x7, HEAP, lsl #32
    // 0xde81d4: r16 = "settings"
    //     0xde81d4: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1fb58] "settings"
    //     0xde81d8: ldr             x16, [x16, #0xb58]
    // 0xde81dc: cmp             w7, w16
    // 0xde81e0: b.ne            #0xde8208
    // 0xde81e4: add             w6, w3, #0xa
    // 0xde81e8: ArrayLoad: r3 = r4[r6]  ; Unknown_4
    //     0xde81e8: add             x16, x4, w6, sxtw #1
    //     0xde81ec: ldur            w3, [x16, #0xf]
    // 0xde81f0: DecompressPointer r3
    //     0xde81f0: add             x3, x3, HEAP, lsl #32
    // 0xde81f4: sub             w4, w2, w3
    // 0xde81f8: add             x2, fp, w4, sxtw #2
    // 0xde81fc: ldr             x2, [x2, #8]
    // 0xde8200: mov             x4, x2
    // 0xde8204: b               #0xde820c
    // 0xde8208: r4 = Null
    //     0xde8208: mov             x4, NULL
    // 0xde820c: r3 = false
    //     0xde820c: add             x3, NULL, #0x30  ; false
    // 0xde8210: r2 = true
    //     0xde8210: add             x2, NULL, #0x20  ; true
    // 0xde8214: CheckStackOverflow
    //     0xde8214: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xde8218: cmp             SP, x16
    //     0xde821c: b.ls            #0xde8268
    // 0xde8220: StoreField: r1->field_a3 = r0
    //     0xde8220: stur            w0, [x1, #0xa3]
    //     0xde8224: ldurb           w16, [x1, #-1]
    //     0xde8228: ldurb           w17, [x0, #-1]
    //     0xde822c: and             x16, x17, x16, lsr #2
    //     0xde8230: tst             x16, HEAP, lsr #32
    //     0xde8234: b.eq            #0xde823c
    //     0xde8238: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xde823c: StoreField: r1->field_a7 = r2
    //     0xde823c: stur            w2, [x1, #0xa7]
    // 0xde8240: StoreField: r1->field_97 = r5
    //     0xde8240: stur            w5, [x1, #0x97]
    // 0xde8244: StoreField: r1->field_9b = r2
    //     0xde8244: stur            w2, [x1, #0x9b]
    // 0xde8248: StoreField: r1->field_9f = r3
    //     0xde8248: stur            w3, [x1, #0x9f]
    // 0xde824c: mov             x2, x4
    // 0xde8250: r3 = Null
    //     0xde8250: mov             x3, NULL
    // 0xde8254: r0 = ModalRoute()
    //     0xde8254: bl              #0x8e04e0  ; [package:flutter/src/widgets/routes.dart] ModalRoute::ModalRoute
    // 0xde8258: r0 = Null
    //     0xde8258: mov             x0, NULL
    // 0xde825c: LeaveFrame
    //     0xde825c: mov             SP, fp
    //     0xde8260: ldp             fp, lr, [SP], #0x10
    // 0xde8264: ret
    //     0xde8264: ret             
    // 0xde8268: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xde8268: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xde826c: b               #0xde8220
  }
  _ buildContent(/* No info */) {
    // ** addr: 0x1102ccc, size: 0x44
    // 0x1102ccc: EnterFrame
    //     0x1102ccc: stp             fp, lr, [SP, #-0x10]!
    //     0x1102cd0: mov             fp, SP
    // 0x1102cd4: AllocStack(0x10)
    //     0x1102cd4: sub             SP, SP, #0x10
    // 0x1102cd8: CheckStackOverflow
    //     0x1102cd8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1102cdc: cmp             SP, x16
    //     0x1102ce0: b.ls            #0x1102d08
    // 0x1102ce4: LoadField: r0 = r1->field_a3
    //     0x1102ce4: ldur            w0, [x1, #0xa3]
    // 0x1102ce8: DecompressPointer r0
    //     0x1102ce8: add             x0, x0, HEAP, lsl #32
    // 0x1102cec: stp             x2, x0, [SP]
    // 0x1102cf0: ClosureCall
    //     0x1102cf0: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x1102cf4: ldur            x2, [x0, #0x1f]
    //     0x1102cf8: blr             x2
    // 0x1102cfc: LeaveFrame
    //     0x1102cfc: mov             SP, fp
    //     0x1102d00: ldp             fp, lr, [SP], #0x10
    // 0x1102d04: ret
    //     0x1102d04: ret             
    // 0x1102d08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1102d08: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1102d0c: b               #0x1102ce4
  }
}

// class id: 2659, size: 0xa4, field offset: 0xa4
abstract class MaterialRouteTransitionMixin<X0> extends PageRoute<X0> {

  [closure] static Widget? _delegatedTransition(dynamic, BuildContext, Animation<double>, Animation<double>, bool, Widget?) {
    // ** addr: 0xe0d628, size: 0x40
    // 0xe0d628: EnterFrame
    //     0xe0d628: stp             fp, lr, [SP, #-0x10]!
    //     0xe0d62c: mov             fp, SP
    // 0xe0d630: CheckStackOverflow
    //     0xe0d630: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe0d634: cmp             SP, x16
    //     0xe0d638: b.ls            #0xe0d660
    // 0xe0d63c: ldr             x1, [fp, #0x30]
    // 0xe0d640: ldr             x2, [fp, #0x28]
    // 0xe0d644: ldr             x3, [fp, #0x20]
    // 0xe0d648: ldr             x5, [fp, #0x18]
    // 0xe0d64c: ldr             x6, [fp, #0x10]
    // 0xe0d650: r0 = _delegatedTransition()
    //     0xe0d650: bl              #0xe0d668  ; [package:flutter/src/material/page.dart] MaterialRouteTransitionMixin::_delegatedTransition
    // 0xe0d654: LeaveFrame
    //     0xe0d654: mov             SP, fp
    //     0xe0d658: ldp             fp, lr, [SP], #0x10
    // 0xe0d65c: ret
    //     0xe0d65c: ret             
    // 0xe0d660: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe0d660: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe0d664: b               #0xe0d63c
  }
  static _ _delegatedTransition(/* No info */) {
    // ** addr: 0xe0d668, size: 0x9c
    // 0xe0d668: EnterFrame
    //     0xe0d668: stp             fp, lr, [SP, #-0x10]!
    //     0xe0d66c: mov             fp, SP
    // 0xe0d670: AllocStack(0x58)
    //     0xe0d670: sub             SP, SP, #0x58
    // 0xe0d674: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */, dynamic _ /* r6 => r6, fp-0x28 */)
    //     0xe0d674: mov             x0, x1
    //     0xe0d678: stur            x1, [fp, #-8]
    //     0xe0d67c: stur            x2, [fp, #-0x10]
    //     0xe0d680: stur            x3, [fp, #-0x18]
    //     0xe0d684: stur            x5, [fp, #-0x20]
    //     0xe0d688: stur            x6, [fp, #-0x28]
    // 0xe0d68c: CheckStackOverflow
    //     0xe0d68c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe0d690: cmp             SP, x16
    //     0xe0d694: b.ls            #0xe0d6fc
    // 0xe0d698: mov             x1, x0
    // 0xe0d69c: r0 = of()
    //     0xe0d69c: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xe0d6a0: ldur            x1, [fp, #-8]
    // 0xe0d6a4: r0 = of()
    //     0xe0d6a4: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xe0d6a8: r1 = Instance_PageTransitionsTheme
    //     0xe0d6a8: add             x1, PP, #0x12, lsl #12  ; [pp+0x12938] Obj!PageTransitionsTheme@12b2a31
    //     0xe0d6ac: ldr             x1, [x1, #0x938]
    // 0xe0d6b0: r0 = delegatedTransition()
    //     0xe0d6b0: bl              #0xe0d704  ; [package:flutter/src/material/page_transitions_theme.dart] PageTransitionsTheme::delegatedTransition
    // 0xe0d6b4: cmp             w0, NULL
    // 0xe0d6b8: b.eq            #0xe0d6ec
    // 0xe0d6bc: ldur            x16, [fp, #-8]
    // 0xe0d6c0: stp             x16, x0, [SP, #0x20]
    // 0xe0d6c4: ldur            x16, [fp, #-0x10]
    // 0xe0d6c8: ldur            lr, [fp, #-0x18]
    // 0xe0d6cc: stp             lr, x16, [SP, #0x10]
    // 0xe0d6d0: ldur            x16, [fp, #-0x20]
    // 0xe0d6d4: ldur            lr, [fp, #-0x28]
    // 0xe0d6d8: stp             lr, x16, [SP]
    // 0xe0d6dc: ClosureCall
    //     0xe0d6dc: ldr             x4, [PP, #0x1018]  ; [pp+0x1018] List(5) [0, 0x6, 0x6, 0x6, Null]
    //     0xe0d6e0: ldur            x2, [x0, #0x1f]
    //     0xe0d6e4: blr             x2
    // 0xe0d6e8: b               #0xe0d6f0
    // 0xe0d6ec: r0 = Null
    //     0xe0d6ec: mov             x0, NULL
    // 0xe0d6f0: LeaveFrame
    //     0xe0d6f0: mov             SP, fp
    //     0xe0d6f4: ldp             fp, lr, [SP], #0x10
    // 0xe0d6f8: ret
    //     0xe0d6f8: ret             
    // 0xe0d6fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe0d6fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe0d700: b               #0xe0d698
  }
}
