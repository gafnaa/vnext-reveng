// lib: , url: package:flutter/src/material/divider.dart

// class id: 1048882, size: 0x8
class :: {
}

// class id: 5161, size: 0x24, field offset: 0x20
//   const constructor, 
class _DividerDefaultsM3 extends DividerThemeData {
}

// class id: 5162, size: 0x24, field offset: 0x20
//   const constructor, 
class _DividerDefaultsM2 extends DividerThemeData {
}

// class id: 6160, size: 0x28, field offset: 0xc
//   const constructor, 
class VerticalDivider extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfb9740, size: 0x324
    // 0xfb9740: EnterFrame
    //     0xfb9740: stp             fp, lr, [SP, #-0x10]!
    //     0xfb9744: mov             fp, SP
    // 0xfb9748: AllocStack(0x60)
    //     0xfb9748: sub             SP, SP, #0x60
    // 0xfb974c: SetupParameters(VerticalDivider this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xfb974c: mov             x0, x2
    //     0xfb9750: stur            x2, [fp, #-0x10]
    //     0xfb9754: mov             x2, x1
    //     0xfb9758: stur            x1, [fp, #-8]
    // 0xfb975c: CheckStackOverflow
    //     0xfb975c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb9760: cmp             SP, x16
    //     0xfb9764: b.ls            #0xfb9a2c
    // 0xfb9768: mov             x1, x0
    // 0xfb976c: r0 = of()
    //     0xfb976c: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfb9770: ldur            x1, [fp, #-0x10]
    // 0xfb9774: stur            x0, [fp, #-0x18]
    // 0xfb9778: r0 = of()
    //     0xfb9778: bl              #0xfb5bb0  ; [package:flutter/src/material/divider_theme.dart] DividerTheme::of
    // 0xfb977c: mov             x1, x0
    // 0xfb9780: ldur            x0, [fp, #-0x18]
    // 0xfb9784: stur            x1, [fp, #-0x20]
    // 0xfb9788: LoadField: r2 = r0->field_2f
    //     0xfb9788: ldur            w2, [x0, #0x2f]
    // 0xfb978c: DecompressPointer r2
    //     0xfb978c: add             x2, x2, HEAP, lsl #32
    // 0xfb9790: tbnz            w2, #4, #0xfb97d0
    // 0xfb9794: ldur            x0, [fp, #-0x10]
    // 0xfb9798: r0 = _DividerDefaultsM3()
    //     0xfb9798: bl              #0xfb5ba4  ; Allocate_DividerDefaultsM3Stub -> _DividerDefaultsM3 (size=0x24)
    // 0xfb979c: ldur            x1, [fp, #-0x10]
    // 0xfb97a0: StoreField: r0->field_1f = r1
    //     0xfb97a0: stur            w1, [x0, #0x1f]
    // 0xfb97a4: r2 = 16.000000
    //     0xfb97a4: add             x2, PP, #0x13, lsl #12  ; [pp+0x13df8] 16
    //     0xfb97a8: ldr             x2, [x2, #0xdf8]
    // 0xfb97ac: StoreField: r0->field_b = r2
    //     0xfb97ac: stur            w2, [x0, #0xb]
    // 0xfb97b0: r2 = 1.000000
    //     0xfb97b0: ldr             x2, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xfb97b4: StoreField: r0->field_f = r2
    //     0xfb97b4: stur            w2, [x0, #0xf]
    // 0xfb97b8: r3 = 0.000000
    //     0xfb97b8: ldr             x3, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xfb97bc: StoreField: r0->field_13 = r3
    //     0xfb97bc: stur            w3, [x0, #0x13]
    // 0xfb97c0: ArrayStore: r0[0] = r3  ; List_4
    //     0xfb97c0: stur            w3, [x0, #0x17]
    // 0xfb97c4: mov             x2, x0
    // 0xfb97c8: d0 = 1.000000
    //     0xfb97c8: fmov            d0, #1.00000000
    // 0xfb97cc: b               #0xfb9810
    // 0xfb97d0: ldur            x1, [fp, #-0x10]
    // 0xfb97d4: r3 = 0.000000
    //     0xfb97d4: ldr             x3, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xfb97d8: r2 = 16.000000
    //     0xfb97d8: add             x2, PP, #0x13, lsl #12  ; [pp+0x13df8] 16
    //     0xfb97dc: ldr             x2, [x2, #0xdf8]
    // 0xfb97e0: r0 = _DividerDefaultsM2()
    //     0xfb97e0: bl              #0xfb5b98  ; Allocate_DividerDefaultsM2Stub -> _DividerDefaultsM2 (size=0x24)
    // 0xfb97e4: ldur            x1, [fp, #-0x10]
    // 0xfb97e8: StoreField: r0->field_1f = r1
    //     0xfb97e8: stur            w1, [x0, #0x1f]
    // 0xfb97ec: r2 = 16.000000
    //     0xfb97ec: add             x2, PP, #0x13, lsl #12  ; [pp+0x13df8] 16
    //     0xfb97f0: ldr             x2, [x2, #0xdf8]
    // 0xfb97f4: StoreField: r0->field_b = r2
    //     0xfb97f4: stur            w2, [x0, #0xb]
    // 0xfb97f8: r2 = 0.000000
    //     0xfb97f8: ldr             x2, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xfb97fc: StoreField: r0->field_f = r2
    //     0xfb97fc: stur            w2, [x0, #0xf]
    // 0xfb9800: StoreField: r0->field_13 = r2
    //     0xfb9800: stur            w2, [x0, #0x13]
    // 0xfb9804: ArrayStore: r0[0] = r2  ; List_4
    //     0xfb9804: stur            w2, [x0, #0x17]
    // 0xfb9808: mov             x2, x0
    // 0xfb980c: d0 = 0.000000
    //     0xfb980c: eor             v0.16b, v0.16b, v0.16b
    // 0xfb9810: ldur            x0, [fp, #-8]
    // 0xfb9814: stur            x2, [fp, #-0x18]
    // 0xfb9818: LoadField: d1 = r0->field_b
    //     0xfb9818: ldur            d1, [x0, #0xb]
    // 0xfb981c: stur            d1, [fp, #-0x48]
    // 0xfb9820: LoadField: r3 = r0->field_13
    //     0xfb9820: ldur            w3, [x0, #0x13]
    // 0xfb9824: DecompressPointer r3
    //     0xfb9824: add             x3, x3, HEAP, lsl #32
    // 0xfb9828: cmp             w3, NULL
    // 0xfb982c: b.ne            #0xfb9840
    // 0xfb9830: ldur            x4, [fp, #-0x20]
    // 0xfb9834: LoadField: r3 = r4->field_f
    //     0xfb9834: ldur            w3, [x4, #0xf]
    // 0xfb9838: DecompressPointer r3
    //     0xfb9838: add             x3, x3, HEAP, lsl #32
    // 0xfb983c: b               #0xfb9844
    // 0xfb9840: ldur            x4, [fp, #-0x20]
    // 0xfb9844: cmp             w3, NULL
    // 0xfb9848: b.eq            #0xfb9850
    // 0xfb984c: LoadField: d0 = r3->field_7
    //     0xfb984c: ldur            d0, [x3, #7]
    // 0xfb9850: stur            d0, [fp, #-0x40]
    // 0xfb9854: LoadField: r3 = r4->field_13
    //     0xfb9854: ldur            w3, [x4, #0x13]
    // 0xfb9858: DecompressPointer r3
    //     0xfb9858: add             x3, x3, HEAP, lsl #32
    // 0xfb985c: cmp             w3, NULL
    // 0xfb9860: b.ne            #0xfb986c
    // 0xfb9864: d2 = 0.000000
    //     0xfb9864: eor             v2.16b, v2.16b, v2.16b
    // 0xfb9868: b               #0xfb9870
    // 0xfb986c: LoadField: d2 = r3->field_7
    //     0xfb986c: ldur            d2, [x3, #7]
    // 0xfb9870: stur            d2, [fp, #-0x38]
    // 0xfb9874: ArrayLoad: r3 = r4[0]  ; List_4
    //     0xfb9874: ldur            w3, [x4, #0x17]
    // 0xfb9878: DecompressPointer r3
    //     0xfb9878: add             x3, x3, HEAP, lsl #32
    // 0xfb987c: cmp             w3, NULL
    // 0xfb9880: b.ne            #0xfb988c
    // 0xfb9884: d3 = 0.000000
    //     0xfb9884: eor             v3.16b, v3.16b, v3.16b
    // 0xfb9888: b               #0xfb9890
    // 0xfb988c: LoadField: d3 = r3->field_7
    //     0xfb988c: ldur            d3, [x3, #7]
    // 0xfb9890: stur            d3, [fp, #-0x30]
    // 0xfb9894: r0 = EdgeInsetsDirectional()
    //     0xfb9894: bl              #0xb50060  ; AllocateEdgeInsetsDirectionalStub -> EdgeInsetsDirectional (size=0x28)
    // 0xfb9898: stur            x0, [fp, #-0x28]
    // 0xfb989c: StoreField: r0->field_7 = rZR
    //     0xfb989c: stur            xzr, [x0, #7]
    // 0xfb98a0: ldur            d0, [fp, #-0x38]
    // 0xfb98a4: StoreField: r0->field_f = d0
    //     0xfb98a4: stur            d0, [x0, #0xf]
    // 0xfb98a8: ArrayStore: r0[0] = rZR  ; List_8
    //     0xfb98a8: stur            xzr, [x0, #0x17]
    // 0xfb98ac: ldur            d0, [fp, #-0x30]
    // 0xfb98b0: StoreField: r0->field_1f = d0
    //     0xfb98b0: stur            d0, [x0, #0x1f]
    // 0xfb98b4: ldur            x1, [fp, #-0x20]
    // 0xfb98b8: LoadField: r2 = r1->field_1b
    //     0xfb98b8: ldur            w2, [x1, #0x1b]
    // 0xfb98bc: DecompressPointer r2
    //     0xfb98bc: add             x2, x2, HEAP, lsl #32
    // 0xfb98c0: cmp             w2, NULL
    // 0xfb98c4: b.ne            #0xfb98d4
    // 0xfb98c8: ldur            x1, [fp, #-0x18]
    // 0xfb98cc: LoadField: r2 = r1->field_1b
    //     0xfb98cc: ldur            w2, [x1, #0x1b]
    // 0xfb98d0: DecompressPointer r2
    //     0xfb98d0: add             x2, x2, HEAP, lsl #32
    // 0xfb98d4: ldur            x1, [fp, #-8]
    // 0xfb98d8: ldur            d1, [fp, #-0x48]
    // 0xfb98dc: ldur            d2, [fp, #-0x40]
    // 0xfb98e0: stur            x2, [fp, #-0x18]
    // 0xfb98e4: LoadField: r3 = r1->field_1f
    //     0xfb98e4: ldur            w3, [x1, #0x1f]
    // 0xfb98e8: DecompressPointer r3
    //     0xfb98e8: add             x3, x3, HEAP, lsl #32
    // 0xfb98ec: str             x3, [SP]
    // 0xfb98f0: ldur            x1, [fp, #-0x10]
    // 0xfb98f4: mov             v0.16b, v2.16b
    // 0xfb98f8: r4 = const [0, 0x3, 0x1, 0x2, color, 0x2, null]
    //     0xfb98f8: add             x4, PP, #0x80, lsl #12  ; [pp+0x80bd0] List(7) [0, 0x3, 0x1, 0x2, "color", 0x2, Null]
    //     0xfb98fc: ldr             x4, [x4, #0xbd0]
    // 0xfb9900: r0 = createBorderSide()
    //     0xfb9900: bl              #0xfb59d0  ; [package:flutter/src/material/divider.dart] Divider::createBorderSide
    // 0xfb9904: stur            x0, [fp, #-8]
    // 0xfb9908: r0 = Border()
    //     0xfb9908: bl              #0x8a73b0  ; AllocateBorderStub -> Border (size=0x18)
    // 0xfb990c: mov             x1, x0
    // 0xfb9910: r0 = Instance_BorderSide
    //     0xfb9910: add             x0, PP, #0x18, lsl #12  ; [pp+0x18310] Obj!BorderSide@12b1b31
    //     0xfb9914: ldr             x0, [x0, #0x310]
    // 0xfb9918: stur            x1, [fp, #-0x10]
    // 0xfb991c: StoreField: r1->field_7 = r0
    //     0xfb991c: stur            w0, [x1, #7]
    // 0xfb9920: StoreField: r1->field_b = r0
    //     0xfb9920: stur            w0, [x1, #0xb]
    // 0xfb9924: StoreField: r1->field_f = r0
    //     0xfb9924: stur            w0, [x1, #0xf]
    // 0xfb9928: ldur            x0, [fp, #-8]
    // 0xfb992c: StoreField: r1->field_13 = r0
    //     0xfb992c: stur            w0, [x1, #0x13]
    // 0xfb9930: r0 = BoxDecoration()
    //     0xfb9930: bl              #0x8a721c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0xfb9934: mov             x1, x0
    // 0xfb9938: ldur            x0, [fp, #-0x10]
    // 0xfb993c: stur            x1, [fp, #-0x20]
    // 0xfb9940: StoreField: r1->field_f = r0
    //     0xfb9940: stur            w0, [x1, #0xf]
    // 0xfb9944: ldur            x0, [fp, #-0x18]
    // 0xfb9948: StoreField: r1->field_13 = r0
    //     0xfb9948: stur            w0, [x1, #0x13]
    // 0xfb994c: r0 = Instance_BoxShape
    //     0xfb994c: add             x0, PP, #0x17, lsl #12  ; [pp+0x171f8] Obj!BoxShape@12c4921
    //     0xfb9950: ldr             x0, [x0, #0x1f8]
    // 0xfb9954: StoreField: r1->field_23 = r0
    //     0xfb9954: stur            w0, [x1, #0x23]
    // 0xfb9958: ldur            d0, [fp, #-0x40]
    // 0xfb995c: r0 = inline_Allocate_Double()
    //     0xfb995c: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xfb9960: add             x0, x0, #0x10
    //     0xfb9964: cmp             x2, x0
    //     0xfb9968: b.ls            #0xfb9a34
    //     0xfb996c: str             x0, [THR, #0x60]  ; THR::top
    //     0xfb9970: sub             x0, x0, #0xf
    //     0xfb9974: mov             x2, #0xe19c
    //     0xfb9978: movk            x2, #3, lsl #16
    //     0xfb997c: stur            x2, [x0, #-1]
    // 0xfb9980: dmb             ishst
    // 0xfb9984: StoreField: r0->field_7 = d0
    //     0xfb9984: stur            d0, [x0, #7]
    // 0xfb9988: stur            x0, [fp, #-8]
    // 0xfb998c: r0 = Container()
    //     0xfb998c: bl              #0x8a5af8  ; AllocateContainerStub -> Container (size=0x38)
    // 0xfb9990: stur            x0, [fp, #-0x10]
    // 0xfb9994: ldur            x16, [fp, #-8]
    // 0xfb9998: ldur            lr, [fp, #-0x28]
    // 0xfb999c: stp             lr, x16, [SP, #8]
    // 0xfb99a0: ldur            x16, [fp, #-0x20]
    // 0xfb99a4: str             x16, [SP]
    // 0xfb99a8: mov             x1, x0
    // 0xfb99ac: r4 = const [0, 0x4, 0x3, 0x1, decoration, 0x3, margin, 0x2, width, 0x1, null]
    //     0xfb99ac: add             x4, PP, #0x80, lsl #12  ; [pp+0x80bd8] List(11) [0, 0x4, 0x3, 0x1, "decoration", 0x3, "margin", 0x2, "width", 0x1, Null]
    //     0xfb99b0: ldr             x4, [x4, #0xbd8]
    // 0xfb99b4: r0 = Container()
    //     0xfb99b4: bl              #0x8a54e0  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0xfb99b8: r0 = Center()
    //     0xfb99b8: bl              #0xd0c898  ; AllocateCenterStub -> Center (size=0x1c)
    // 0xfb99bc: mov             x1, x0
    // 0xfb99c0: r0 = Instance_Alignment
    //     0xfb99c0: add             x0, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xfb99c4: ldr             x0, [x0, #0xb80]
    // 0xfb99c8: stur            x1, [fp, #-0x18]
    // 0xfb99cc: StoreField: r1->field_f = r0
    //     0xfb99cc: stur            w0, [x1, #0xf]
    // 0xfb99d0: ldur            x0, [fp, #-0x10]
    // 0xfb99d4: StoreField: r1->field_b = r0
    //     0xfb99d4: stur            w0, [x1, #0xb]
    // 0xfb99d8: ldur            d0, [fp, #-0x48]
    // 0xfb99dc: r0 = inline_Allocate_Double()
    //     0xfb99dc: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xfb99e0: add             x0, x0, #0x10
    //     0xfb99e4: cmp             x2, x0
    //     0xfb99e8: b.ls            #0xfb9a4c
    //     0xfb99ec: str             x0, [THR, #0x60]  ; THR::top
    //     0xfb99f0: sub             x0, x0, #0xf
    //     0xfb99f4: mov             x2, #0xe19c
    //     0xfb99f8: movk            x2, #3, lsl #16
    //     0xfb99fc: stur            x2, [x0, #-1]
    // 0xfb9a00: dmb             ishst
    // 0xfb9a04: StoreField: r0->field_7 = d0
    //     0xfb9a04: stur            d0, [x0, #7]
    // 0xfb9a08: stur            x0, [fp, #-8]
    // 0xfb9a0c: r0 = SizedBox()
    //     0xfb9a0c: bl              #0x8a7210  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0xfb9a10: ldur            x1, [fp, #-8]
    // 0xfb9a14: StoreField: r0->field_f = r1
    //     0xfb9a14: stur            w1, [x0, #0xf]
    // 0xfb9a18: ldur            x1, [fp, #-0x18]
    // 0xfb9a1c: StoreField: r0->field_b = r1
    //     0xfb9a1c: stur            w1, [x0, #0xb]
    // 0xfb9a20: LeaveFrame
    //     0xfb9a20: mov             SP, fp
    //     0xfb9a24: ldp             fp, lr, [SP], #0x10
    // 0xfb9a28: ret
    //     0xfb9a28: ret             
    // 0xfb9a2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb9a2c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb9a30: b               #0xfb9768
    // 0xfb9a34: SaveReg d0
    //     0xfb9a34: str             q0, [SP, #-0x10]!
    // 0xfb9a38: SaveReg r1
    //     0xfb9a38: str             x1, [SP, #-8]!
    // 0xfb9a3c: r0 = AllocateDouble()
    //     0xfb9a3c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xfb9a40: RestoreReg r1
    //     0xfb9a40: ldr             x1, [SP], #8
    // 0xfb9a44: RestoreReg d0
    //     0xfb9a44: ldr             q0, [SP], #0x10
    // 0xfb9a48: b               #0xfb9984
    // 0xfb9a4c: SaveReg d0
    //     0xfb9a4c: str             q0, [SP, #-0x10]!
    // 0xfb9a50: SaveReg r1
    //     0xfb9a50: str             x1, [SP, #-8]!
    // 0xfb9a54: r0 = AllocateDouble()
    //     0xfb9a54: bl              #0x13df878  ; AllocateDoubleStub
    // 0xfb9a58: RestoreReg r1
    //     0xfb9a58: ldr             x1, [SP], #8
    // 0xfb9a5c: RestoreReg d0
    //     0xfb9a5c: ldr             q0, [SP], #0x10
    // 0xfb9a60: b               #0xfb9a04
  }
}

// class id: 6161, size: 0x24, field offset: 0xc
//   const constructor, 
class Divider extends StatelessWidget {

  _Double field_c;
  _Double field_10;
  _Double field_14;

  static _ createBorderSide(/* No info */) {
    // ** addr: 0xfb59d0, size: 0x1c8
    // 0xfb59d0: EnterFrame
    //     0xfb59d0: stp             fp, lr, [SP, #-0x10]!
    //     0xfb59d4: mov             fp, SP
    // 0xfb59d8: AllocStack(0x18)
    //     0xfb59d8: sub             SP, SP, #0x18
    // 0xfb59dc: SetupParameters(dynamic _ /* r1 => r0, fp-0x10 */, dynamic _ /* d0 => d0, fp-0x18 */, {dynamic color = Null /* r2, fp-0x8 */})
    //     0xfb59dc: mov             x0, x1
    //     0xfb59e0: stur            x1, [fp, #-0x10]
    //     0xfb59e4: stur            d0, [fp, #-0x18]
    //     0xfb59e8: ldur            w1, [x4, #0x13]
    //     0xfb59ec: ldur            w2, [x4, #0x1f]
    //     0xfb59f0: add             x2, x2, HEAP, lsl #32
    //     0xfb59f4: ldr             x16, [PP, #0x4a70]  ; [pp+0x4a70] "color"
    //     0xfb59f8: cmp             w2, w16
    //     0xfb59fc: b.ne            #0xfb5a1c
    //     0xfb5a00: ldur            w2, [x4, #0x23]
    //     0xfb5a04: add             x2, x2, HEAP, lsl #32
    //     0xfb5a08: sub             w3, w1, w2
    //     0xfb5a0c: add             x1, fp, w3, sxtw #2
    //     0xfb5a10: ldr             x1, [x1, #8]
    //     0xfb5a14: mov             x2, x1
    //     0xfb5a18: b               #0xfb5a20
    //     0xfb5a1c: mov             x2, NULL
    //     0xfb5a20: stur            x2, [fp, #-8]
    // 0xfb5a24: CheckStackOverflow
    //     0xfb5a24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb5a28: cmp             SP, x16
    //     0xfb5a2c: b.ls            #0xfb5b90
    // 0xfb5a30: mov             x1, x0
    // 0xfb5a34: r0 = of()
    //     0xfb5a34: bl              #0xfb5bb0  ; [package:flutter/src/material/divider_theme.dart] DividerTheme::of
    // 0xfb5a38: ldur            x1, [fp, #-0x10]
    // 0xfb5a3c: r0 = of()
    //     0xfb5a3c: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfb5a40: LoadField: r1 = r0->field_2f
    //     0xfb5a40: ldur            w1, [x0, #0x2f]
    // 0xfb5a44: DecompressPointer r1
    //     0xfb5a44: add             x1, x1, HEAP, lsl #32
    // 0xfb5a48: tbnz            w1, #4, #0xfb5a84
    // 0xfb5a4c: ldur            x0, [fp, #-0x10]
    // 0xfb5a50: r0 = _DividerDefaultsM3()
    //     0xfb5a50: bl              #0xfb5ba4  ; Allocate_DividerDefaultsM3Stub -> _DividerDefaultsM3 (size=0x24)
    // 0xfb5a54: mov             x1, x0
    // 0xfb5a58: ldur            x0, [fp, #-0x10]
    // 0xfb5a5c: StoreField: r1->field_1f = r0
    //     0xfb5a5c: stur            w0, [x1, #0x1f]
    // 0xfb5a60: r2 = 16.000000
    //     0xfb5a60: add             x2, PP, #0x13, lsl #12  ; [pp+0x13df8] 16
    //     0xfb5a64: ldr             x2, [x2, #0xdf8]
    // 0xfb5a68: StoreField: r1->field_b = r2
    //     0xfb5a68: stur            w2, [x1, #0xb]
    // 0xfb5a6c: r0 = 1.000000
    //     0xfb5a6c: ldr             x0, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xfb5a70: StoreField: r1->field_f = r0
    //     0xfb5a70: stur            w0, [x1, #0xf]
    // 0xfb5a74: r3 = 0.000000
    //     0xfb5a74: ldr             x3, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xfb5a78: StoreField: r1->field_13 = r3
    //     0xfb5a78: stur            w3, [x1, #0x13]
    // 0xfb5a7c: ArrayStore: r1[0] = r3  ; List_4
    //     0xfb5a7c: stur            w3, [x1, #0x17]
    // 0xfb5a80: b               #0xfb5ac0
    // 0xfb5a84: ldur            x0, [fp, #-0x10]
    // 0xfb5a88: r3 = 0.000000
    //     0xfb5a88: ldr             x3, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xfb5a8c: r2 = 16.000000
    //     0xfb5a8c: add             x2, PP, #0x13, lsl #12  ; [pp+0x13df8] 16
    //     0xfb5a90: ldr             x2, [x2, #0xdf8]
    // 0xfb5a94: r0 = _DividerDefaultsM2()
    //     0xfb5a94: bl              #0xfb5b98  ; Allocate_DividerDefaultsM2Stub -> _DividerDefaultsM2 (size=0x24)
    // 0xfb5a98: mov             x1, x0
    // 0xfb5a9c: ldur            x0, [fp, #-0x10]
    // 0xfb5aa0: StoreField: r1->field_1f = r0
    //     0xfb5aa0: stur            w0, [x1, #0x1f]
    // 0xfb5aa4: r0 = 16.000000
    //     0xfb5aa4: add             x0, PP, #0x13, lsl #12  ; [pp+0x13df8] 16
    //     0xfb5aa8: ldr             x0, [x0, #0xdf8]
    // 0xfb5aac: StoreField: r1->field_b = r0
    //     0xfb5aac: stur            w0, [x1, #0xb]
    // 0xfb5ab0: r0 = 0.000000
    //     0xfb5ab0: ldr             x0, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xfb5ab4: StoreField: r1->field_f = r0
    //     0xfb5ab4: stur            w0, [x1, #0xf]
    // 0xfb5ab8: StoreField: r1->field_13 = r0
    //     0xfb5ab8: stur            w0, [x1, #0x13]
    // 0xfb5abc: ArrayStore: r1[0] = r0  ; List_4
    //     0xfb5abc: stur            w0, [x1, #0x17]
    // 0xfb5ac0: ldur            x0, [fp, #-8]
    // 0xfb5ac4: cmp             w0, NULL
    // 0xfb5ac8: b.ne            #0xfb5ad0
    // 0xfb5acc: r0 = Null
    //     0xfb5acc: mov             x0, NULL
    // 0xfb5ad0: cmp             w0, NULL
    // 0xfb5ad4: b.ne            #0xfb5b54
    // 0xfb5ad8: r0 = LoadClassIdInstr(r1)
    //     0xfb5ad8: ldur            x0, [x1, #-1]
    //     0xfb5adc: ubfx            x0, x0, #0xc, #0x14
    // 0xfb5ae0: r17 = 5160
    //     0xfb5ae0: mov             x17, #0x1428
    // 0xfb5ae4: cmp             x0, x17
    // 0xfb5ae8: b.ne            #0xfb5af8
    // 0xfb5aec: LoadField: r0 = r1->field_7
    //     0xfb5aec: ldur            w0, [x1, #7]
    // 0xfb5af0: DecompressPointer r0
    //     0xfb5af0: add             x0, x0, HEAP, lsl #32
    // 0xfb5af4: b               #0xfb5b54
    // 0xfb5af8: r17 = 5161
    //     0xfb5af8: mov             x17, #0x1429
    // 0xfb5afc: cmp             x0, x17
    // 0xfb5b00: b.ne            #0xfb5b38
    // 0xfb5b04: LoadField: r0 = r1->field_1f
    //     0xfb5b04: ldur            w0, [x1, #0x1f]
    // 0xfb5b08: DecompressPointer r0
    //     0xfb5b08: add             x0, x0, HEAP, lsl #32
    // 0xfb5b0c: mov             x1, x0
    // 0xfb5b10: r0 = of()
    //     0xfb5b10: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfb5b14: LoadField: r1 = r0->field_3f
    //     0xfb5b14: ldur            w1, [x0, #0x3f]
    // 0xfb5b18: DecompressPointer r1
    //     0xfb5b18: add             x1, x1, HEAP, lsl #32
    // 0xfb5b1c: LoadField: r0 = r1->field_ab
    //     0xfb5b1c: ldur            w0, [x1, #0xab]
    // 0xfb5b20: DecompressPointer r0
    //     0xfb5b20: add             x0, x0, HEAP, lsl #32
    // 0xfb5b24: cmp             w0, NULL
    // 0xfb5b28: b.ne            #0xfb5b54
    // 0xfb5b2c: LoadField: r0 = r1->field_cb
    //     0xfb5b2c: ldur            w0, [x1, #0xcb]
    // 0xfb5b30: DecompressPointer r0
    //     0xfb5b30: add             x0, x0, HEAP, lsl #32
    // 0xfb5b34: b               #0xfb5b54
    // 0xfb5b38: LoadField: r0 = r1->field_1f
    //     0xfb5b38: ldur            w0, [x1, #0x1f]
    // 0xfb5b3c: DecompressPointer r0
    //     0xfb5b3c: add             x0, x0, HEAP, lsl #32
    // 0xfb5b40: mov             x1, x0
    // 0xfb5b44: r0 = of()
    //     0xfb5b44: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfb5b48: LoadField: r1 = r0->field_47
    //     0xfb5b48: ldur            w1, [x0, #0x47]
    // 0xfb5b4c: DecompressPointer r1
    //     0xfb5b4c: add             x1, x1, HEAP, lsl #32
    // 0xfb5b50: mov             x0, x1
    // 0xfb5b54: ldur            d0, [fp, #-0x18]
    // 0xfb5b58: stur            x0, [fp, #-8]
    // 0xfb5b5c: r0 = BorderSide()
    //     0xfb5b5c: bl              #0x8a73bc  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0xfb5b60: ldur            x1, [fp, #-8]
    // 0xfb5b64: StoreField: r0->field_7 = r1
    //     0xfb5b64: stur            w1, [x0, #7]
    // 0xfb5b68: ldur            d0, [fp, #-0x18]
    // 0xfb5b6c: StoreField: r0->field_b = d0
    //     0xfb5b6c: stur            d0, [x0, #0xb]
    // 0xfb5b70: r1 = Instance_BorderStyle
    //     0xfb5b70: add             x1, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0xfb5b74: ldr             x1, [x1, #0xdc8]
    // 0xfb5b78: StoreField: r0->field_13 = r1
    //     0xfb5b78: stur            w1, [x0, #0x13]
    // 0xfb5b7c: d0 = -1.000000
    //     0xfb5b7c: fmov            d0, #-1.00000000
    // 0xfb5b80: ArrayStore: r0[0] = d0  ; List_8
    //     0xfb5b80: stur            d0, [x0, #0x17]
    // 0xfb5b84: LeaveFrame
    //     0xfb5b84: mov             SP, fp
    //     0xfb5b88: ldp             fp, lr, [SP], #0x10
    // 0xfb5b8c: ret
    //     0xfb5b8c: ret             
    // 0xfb5b90: r0 = StackOverflowSharedWithFPURegs()
    //     0xfb5b90: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xfb5b94: b               #0xfb5a30
  }
  _ build(/* No info */) {
    // ** addr: 0xfb93e4, size: 0x35c
    // 0xfb93e4: EnterFrame
    //     0xfb93e4: stp             fp, lr, [SP, #-0x10]!
    //     0xfb93e8: mov             fp, SP
    // 0xfb93ec: AllocStack(0x60)
    //     0xfb93ec: sub             SP, SP, #0x60
    // 0xfb93f0: SetupParameters(Divider this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xfb93f0: mov             x0, x2
    //     0xfb93f4: stur            x2, [fp, #-0x10]
    //     0xfb93f8: mov             x2, x1
    //     0xfb93fc: stur            x1, [fp, #-8]
    // 0xfb9400: CheckStackOverflow
    //     0xfb9400: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb9404: cmp             SP, x16
    //     0xfb9408: b.ls            #0xfb9708
    // 0xfb940c: mov             x1, x0
    // 0xfb9410: r0 = of()
    //     0xfb9410: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfb9414: ldur            x1, [fp, #-0x10]
    // 0xfb9418: stur            x0, [fp, #-0x18]
    // 0xfb941c: r0 = of()
    //     0xfb941c: bl              #0xfb5bb0  ; [package:flutter/src/material/divider_theme.dart] DividerTheme::of
    // 0xfb9420: mov             x1, x0
    // 0xfb9424: ldur            x0, [fp, #-0x18]
    // 0xfb9428: stur            x1, [fp, #-0x20]
    // 0xfb942c: LoadField: r2 = r0->field_2f
    //     0xfb942c: ldur            w2, [x0, #0x2f]
    // 0xfb9430: DecompressPointer r2
    //     0xfb9430: add             x2, x2, HEAP, lsl #32
    // 0xfb9434: tbnz            w2, #4, #0xfb9474
    // 0xfb9438: ldur            x0, [fp, #-0x10]
    // 0xfb943c: r0 = _DividerDefaultsM3()
    //     0xfb943c: bl              #0xfb5ba4  ; Allocate_DividerDefaultsM3Stub -> _DividerDefaultsM3 (size=0x24)
    // 0xfb9440: ldur            x1, [fp, #-0x10]
    // 0xfb9444: StoreField: r0->field_1f = r1
    //     0xfb9444: stur            w1, [x0, #0x1f]
    // 0xfb9448: r2 = 16.000000
    //     0xfb9448: add             x2, PP, #0x13, lsl #12  ; [pp+0x13df8] 16
    //     0xfb944c: ldr             x2, [x2, #0xdf8]
    // 0xfb9450: StoreField: r0->field_b = r2
    //     0xfb9450: stur            w2, [x0, #0xb]
    // 0xfb9454: r2 = 1.000000
    //     0xfb9454: ldr             x2, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xfb9458: StoreField: r0->field_f = r2
    //     0xfb9458: stur            w2, [x0, #0xf]
    // 0xfb945c: r3 = 0.000000
    //     0xfb945c: ldr             x3, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xfb9460: StoreField: r0->field_13 = r3
    //     0xfb9460: stur            w3, [x0, #0x13]
    // 0xfb9464: ArrayStore: r0[0] = r3  ; List_4
    //     0xfb9464: stur            w3, [x0, #0x17]
    // 0xfb9468: mov             x2, x0
    // 0xfb946c: d0 = 1.000000
    //     0xfb946c: fmov            d0, #1.00000000
    // 0xfb9470: b               #0xfb94b4
    // 0xfb9474: ldur            x1, [fp, #-0x10]
    // 0xfb9478: r3 = 0.000000
    //     0xfb9478: ldr             x3, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xfb947c: r2 = 16.000000
    //     0xfb947c: add             x2, PP, #0x13, lsl #12  ; [pp+0x13df8] 16
    //     0xfb9480: ldr             x2, [x2, #0xdf8]
    // 0xfb9484: r0 = _DividerDefaultsM2()
    //     0xfb9484: bl              #0xfb5b98  ; Allocate_DividerDefaultsM2Stub -> _DividerDefaultsM2 (size=0x24)
    // 0xfb9488: ldur            x1, [fp, #-0x10]
    // 0xfb948c: StoreField: r0->field_1f = r1
    //     0xfb948c: stur            w1, [x0, #0x1f]
    // 0xfb9490: r2 = 16.000000
    //     0xfb9490: add             x2, PP, #0x13, lsl #12  ; [pp+0x13df8] 16
    //     0xfb9494: ldr             x2, [x2, #0xdf8]
    // 0xfb9498: StoreField: r0->field_b = r2
    //     0xfb9498: stur            w2, [x0, #0xb]
    // 0xfb949c: r2 = 0.000000
    //     0xfb949c: ldr             x2, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xfb94a0: StoreField: r0->field_f = r2
    //     0xfb94a0: stur            w2, [x0, #0xf]
    // 0xfb94a4: StoreField: r0->field_13 = r2
    //     0xfb94a4: stur            w2, [x0, #0x13]
    // 0xfb94a8: ArrayStore: r0[0] = r2  ; List_4
    //     0xfb94a8: stur            w2, [x0, #0x17]
    // 0xfb94ac: mov             x2, x0
    // 0xfb94b0: d0 = 0.000000
    //     0xfb94b0: eor             v0.16b, v0.16b, v0.16b
    // 0xfb94b4: ldur            x0, [fp, #-8]
    // 0xfb94b8: stur            x2, [fp, #-0x18]
    // 0xfb94bc: LoadField: r3 = r0->field_b
    //     0xfb94bc: ldur            w3, [x0, #0xb]
    // 0xfb94c0: DecompressPointer r3
    //     0xfb94c0: add             x3, x3, HEAP, lsl #32
    // 0xfb94c4: cmp             w3, NULL
    // 0xfb94c8: b.ne            #0xfb94dc
    // 0xfb94cc: ldur            x4, [fp, #-0x20]
    // 0xfb94d0: LoadField: r3 = r4->field_b
    //     0xfb94d0: ldur            w3, [x4, #0xb]
    // 0xfb94d4: DecompressPointer r3
    //     0xfb94d4: add             x3, x3, HEAP, lsl #32
    // 0xfb94d8: b               #0xfb94e0
    // 0xfb94dc: ldur            x4, [fp, #-0x20]
    // 0xfb94e0: cmp             w3, NULL
    // 0xfb94e4: b.ne            #0xfb94f0
    // 0xfb94e8: d1 = 16.000000
    //     0xfb94e8: fmov            d1, #16.00000000
    // 0xfb94ec: b               #0xfb94f4
    // 0xfb94f0: LoadField: d1 = r3->field_7
    //     0xfb94f0: ldur            d1, [x3, #7]
    // 0xfb94f4: stur            d1, [fp, #-0x48]
    // 0xfb94f8: LoadField: r3 = r0->field_f
    //     0xfb94f8: ldur            w3, [x0, #0xf]
    // 0xfb94fc: DecompressPointer r3
    //     0xfb94fc: add             x3, x3, HEAP, lsl #32
    // 0xfb9500: cmp             w3, NULL
    // 0xfb9504: b.ne            #0xfb9510
    // 0xfb9508: LoadField: r3 = r4->field_f
    //     0xfb9508: ldur            w3, [x4, #0xf]
    // 0xfb950c: DecompressPointer r3
    //     0xfb950c: add             x3, x3, HEAP, lsl #32
    // 0xfb9510: cmp             w3, NULL
    // 0xfb9514: b.eq            #0xfb951c
    // 0xfb9518: LoadField: d0 = r3->field_7
    //     0xfb9518: ldur            d0, [x3, #7]
    // 0xfb951c: stur            d0, [fp, #-0x40]
    // 0xfb9520: LoadField: r3 = r0->field_13
    //     0xfb9520: ldur            w3, [x0, #0x13]
    // 0xfb9524: DecompressPointer r3
    //     0xfb9524: add             x3, x3, HEAP, lsl #32
    // 0xfb9528: cmp             w3, NULL
    // 0xfb952c: b.ne            #0xfb9538
    // 0xfb9530: LoadField: r3 = r4->field_13
    //     0xfb9530: ldur            w3, [x4, #0x13]
    // 0xfb9534: DecompressPointer r3
    //     0xfb9534: add             x3, x3, HEAP, lsl #32
    // 0xfb9538: cmp             w3, NULL
    // 0xfb953c: b.ne            #0xfb9548
    // 0xfb9540: d2 = 0.000000
    //     0xfb9540: eor             v2.16b, v2.16b, v2.16b
    // 0xfb9544: b               #0xfb954c
    // 0xfb9548: LoadField: d2 = r3->field_7
    //     0xfb9548: ldur            d2, [x3, #7]
    // 0xfb954c: stur            d2, [fp, #-0x38]
    // 0xfb9550: ArrayLoad: r3 = r4[0]  ; List_4
    //     0xfb9550: ldur            w3, [x4, #0x17]
    // 0xfb9554: DecompressPointer r3
    //     0xfb9554: add             x3, x3, HEAP, lsl #32
    // 0xfb9558: cmp             w3, NULL
    // 0xfb955c: b.ne            #0xfb9568
    // 0xfb9560: d3 = 0.000000
    //     0xfb9560: eor             v3.16b, v3.16b, v3.16b
    // 0xfb9564: b               #0xfb956c
    // 0xfb9568: LoadField: d3 = r3->field_7
    //     0xfb9568: ldur            d3, [x3, #7]
    // 0xfb956c: stur            d3, [fp, #-0x30]
    // 0xfb9570: r0 = EdgeInsetsDirectional()
    //     0xfb9570: bl              #0xb50060  ; AllocateEdgeInsetsDirectionalStub -> EdgeInsetsDirectional (size=0x28)
    // 0xfb9574: ldur            d0, [fp, #-0x38]
    // 0xfb9578: stur            x0, [fp, #-0x28]
    // 0xfb957c: StoreField: r0->field_7 = d0
    //     0xfb957c: stur            d0, [x0, #7]
    // 0xfb9580: StoreField: r0->field_f = rZR
    //     0xfb9580: stur            xzr, [x0, #0xf]
    // 0xfb9584: ldur            d0, [fp, #-0x30]
    // 0xfb9588: ArrayStore: r0[0] = d0  ; List_8
    //     0xfb9588: stur            d0, [x0, #0x17]
    // 0xfb958c: StoreField: r0->field_1f = rZR
    //     0xfb958c: stur            xzr, [x0, #0x1f]
    // 0xfb9590: ldur            x1, [fp, #-0x20]
    // 0xfb9594: LoadField: r2 = r1->field_1b
    //     0xfb9594: ldur            w2, [x1, #0x1b]
    // 0xfb9598: DecompressPointer r2
    //     0xfb9598: add             x2, x2, HEAP, lsl #32
    // 0xfb959c: cmp             w2, NULL
    // 0xfb95a0: b.ne            #0xfb95b0
    // 0xfb95a4: ldur            x1, [fp, #-0x18]
    // 0xfb95a8: LoadField: r2 = r1->field_1b
    //     0xfb95a8: ldur            w2, [x1, #0x1b]
    // 0xfb95ac: DecompressPointer r2
    //     0xfb95ac: add             x2, x2, HEAP, lsl #32
    // 0xfb95b0: ldur            x1, [fp, #-8]
    // 0xfb95b4: ldur            d1, [fp, #-0x48]
    // 0xfb95b8: ldur            d2, [fp, #-0x40]
    // 0xfb95bc: stur            x2, [fp, #-0x18]
    // 0xfb95c0: LoadField: r3 = r1->field_1f
    //     0xfb95c0: ldur            w3, [x1, #0x1f]
    // 0xfb95c4: DecompressPointer r3
    //     0xfb95c4: add             x3, x3, HEAP, lsl #32
    // 0xfb95c8: str             x3, [SP]
    // 0xfb95cc: ldur            x1, [fp, #-0x10]
    // 0xfb95d0: mov             v0.16b, v2.16b
    // 0xfb95d4: r4 = const [0, 0x3, 0x1, 0x2, color, 0x2, null]
    //     0xfb95d4: add             x4, PP, #0x80, lsl #12  ; [pp+0x80bd0] List(7) [0, 0x3, 0x1, 0x2, "color", 0x2, Null]
    //     0xfb95d8: ldr             x4, [x4, #0xbd0]
    // 0xfb95dc: r0 = createBorderSide()
    //     0xfb95dc: bl              #0xfb59d0  ; [package:flutter/src/material/divider.dart] Divider::createBorderSide
    // 0xfb95e0: stur            x0, [fp, #-8]
    // 0xfb95e4: r0 = Border()
    //     0xfb95e4: bl              #0x8a73b0  ; AllocateBorderStub -> Border (size=0x18)
    // 0xfb95e8: mov             x1, x0
    // 0xfb95ec: r0 = Instance_BorderSide
    //     0xfb95ec: add             x0, PP, #0x18, lsl #12  ; [pp+0x18310] Obj!BorderSide@12b1b31
    //     0xfb95f0: ldr             x0, [x0, #0x310]
    // 0xfb95f4: stur            x1, [fp, #-0x10]
    // 0xfb95f8: StoreField: r1->field_7 = r0
    //     0xfb95f8: stur            w0, [x1, #7]
    // 0xfb95fc: StoreField: r1->field_b = r0
    //     0xfb95fc: stur            w0, [x1, #0xb]
    // 0xfb9600: ldur            x2, [fp, #-8]
    // 0xfb9604: StoreField: r1->field_f = r2
    //     0xfb9604: stur            w2, [x1, #0xf]
    // 0xfb9608: StoreField: r1->field_13 = r0
    //     0xfb9608: stur            w0, [x1, #0x13]
    // 0xfb960c: r0 = BoxDecoration()
    //     0xfb960c: bl              #0x8a721c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0xfb9610: mov             x1, x0
    // 0xfb9614: ldur            x0, [fp, #-0x10]
    // 0xfb9618: stur            x1, [fp, #-0x20]
    // 0xfb961c: StoreField: r1->field_f = r0
    //     0xfb961c: stur            w0, [x1, #0xf]
    // 0xfb9620: ldur            x0, [fp, #-0x18]
    // 0xfb9624: StoreField: r1->field_13 = r0
    //     0xfb9624: stur            w0, [x1, #0x13]
    // 0xfb9628: r0 = Instance_BoxShape
    //     0xfb9628: add             x0, PP, #0x17, lsl #12  ; [pp+0x171f8] Obj!BoxShape@12c4921
    //     0xfb962c: ldr             x0, [x0, #0x1f8]
    // 0xfb9630: StoreField: r1->field_23 = r0
    //     0xfb9630: stur            w0, [x1, #0x23]
    // 0xfb9634: ldur            d0, [fp, #-0x40]
    // 0xfb9638: r0 = inline_Allocate_Double()
    //     0xfb9638: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xfb963c: add             x0, x0, #0x10
    //     0xfb9640: cmp             x2, x0
    //     0xfb9644: b.ls            #0xfb9710
    //     0xfb9648: str             x0, [THR, #0x60]  ; THR::top
    //     0xfb964c: sub             x0, x0, #0xf
    //     0xfb9650: mov             x2, #0xe19c
    //     0xfb9654: movk            x2, #3, lsl #16
    //     0xfb9658: stur            x2, [x0, #-1]
    // 0xfb965c: dmb             ishst
    // 0xfb9660: StoreField: r0->field_7 = d0
    //     0xfb9660: stur            d0, [x0, #7]
    // 0xfb9664: stur            x0, [fp, #-8]
    // 0xfb9668: r0 = Container()
    //     0xfb9668: bl              #0x8a5af8  ; AllocateContainerStub -> Container (size=0x38)
    // 0xfb966c: stur            x0, [fp, #-0x10]
    // 0xfb9670: ldur            x16, [fp, #-8]
    // 0xfb9674: ldur            lr, [fp, #-0x28]
    // 0xfb9678: stp             lr, x16, [SP, #8]
    // 0xfb967c: ldur            x16, [fp, #-0x20]
    // 0xfb9680: str             x16, [SP]
    // 0xfb9684: mov             x1, x0
    // 0xfb9688: r4 = const [0, 0x4, 0x3, 0x1, decoration, 0x3, height, 0x1, margin, 0x2, null]
    //     0xfb9688: add             x4, PP, #0x80, lsl #12  ; [pp+0x80be8] List(11) [0, 0x4, 0x3, 0x1, "decoration", 0x3, "height", 0x1, "margin", 0x2, Null]
    //     0xfb968c: ldr             x4, [x4, #0xbe8]
    // 0xfb9690: r0 = Container()
    //     0xfb9690: bl              #0x8a54e0  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0xfb9694: r0 = Center()
    //     0xfb9694: bl              #0xd0c898  ; AllocateCenterStub -> Center (size=0x1c)
    // 0xfb9698: mov             x1, x0
    // 0xfb969c: r0 = Instance_Alignment
    //     0xfb969c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xfb96a0: ldr             x0, [x0, #0xb80]
    // 0xfb96a4: stur            x1, [fp, #-0x18]
    // 0xfb96a8: StoreField: r1->field_f = r0
    //     0xfb96a8: stur            w0, [x1, #0xf]
    // 0xfb96ac: ldur            x0, [fp, #-0x10]
    // 0xfb96b0: StoreField: r1->field_b = r0
    //     0xfb96b0: stur            w0, [x1, #0xb]
    // 0xfb96b4: ldur            d0, [fp, #-0x48]
    // 0xfb96b8: r0 = inline_Allocate_Double()
    //     0xfb96b8: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xfb96bc: add             x0, x0, #0x10
    //     0xfb96c0: cmp             x2, x0
    //     0xfb96c4: b.ls            #0xfb9728
    //     0xfb96c8: str             x0, [THR, #0x60]  ; THR::top
    //     0xfb96cc: sub             x0, x0, #0xf
    //     0xfb96d0: mov             x2, #0xe19c
    //     0xfb96d4: movk            x2, #3, lsl #16
    //     0xfb96d8: stur            x2, [x0, #-1]
    // 0xfb96dc: dmb             ishst
    // 0xfb96e0: StoreField: r0->field_7 = d0
    //     0xfb96e0: stur            d0, [x0, #7]
    // 0xfb96e4: stur            x0, [fp, #-8]
    // 0xfb96e8: r0 = SizedBox()
    //     0xfb96e8: bl              #0x8a7210  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0xfb96ec: ldur            x1, [fp, #-8]
    // 0xfb96f0: StoreField: r0->field_13 = r1
    //     0xfb96f0: stur            w1, [x0, #0x13]
    // 0xfb96f4: ldur            x1, [fp, #-0x18]
    // 0xfb96f8: StoreField: r0->field_b = r1
    //     0xfb96f8: stur            w1, [x0, #0xb]
    // 0xfb96fc: LeaveFrame
    //     0xfb96fc: mov             SP, fp
    //     0xfb9700: ldp             fp, lr, [SP], #0x10
    // 0xfb9704: ret
    //     0xfb9704: ret             
    // 0xfb9708: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb9708: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb970c: b               #0xfb940c
    // 0xfb9710: SaveReg d0
    //     0xfb9710: str             q0, [SP, #-0x10]!
    // 0xfb9714: SaveReg r1
    //     0xfb9714: str             x1, [SP, #-8]!
    // 0xfb9718: r0 = AllocateDouble()
    //     0xfb9718: bl              #0x13df878  ; AllocateDoubleStub
    // 0xfb971c: RestoreReg r1
    //     0xfb971c: ldr             x1, [SP], #8
    // 0xfb9720: RestoreReg d0
    //     0xfb9720: ldr             q0, [SP], #0x10
    // 0xfb9724: b               #0xfb9660
    // 0xfb9728: SaveReg d0
    //     0xfb9728: str             q0, [SP, #-0x10]!
    // 0xfb972c: SaveReg r1
    //     0xfb972c: str             x1, [SP, #-8]!
    // 0xfb9730: r0 = AllocateDouble()
    //     0xfb9730: bl              #0x13df878  ; AllocateDoubleStub
    // 0xfb9734: RestoreReg r1
    //     0xfb9734: ldr             x1, [SP], #8
    // 0xfb9738: RestoreReg d0
    //     0xfb9738: ldr             q0, [SP], #0x10
    // 0xfb973c: b               #0xfb96e0
  }
}
