// lib: , url: package:flutter/src/material/flexible_space_bar.dart

// class id: 1048894, size: 0x8
class :: {
}

// class id: 3103, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class FlexibleSpaceBar extends Object {

  static _ createSettings(/* No info */) {
    // ** addr: 0xd36550, size: 0x44
    // 0xd36550: EnterFrame
    //     0xd36550: stp             fp, lr, [SP, #-0x10]!
    //     0xd36554: mov             fp, SP
    // 0xd36558: AllocStack(0x10)
    //     0xd36558: sub             SP, SP, #0x10
    // 0xd3655c: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */, dynamic _ /* d0 => d0, fp-0x10 */)
    //     0xd3655c: stur            x1, [fp, #-8]
    //     0xd36560: stur            d0, [fp, #-0x10]
    // 0xd36564: r0 = FlexibleSpaceBarSettings()
    //     0xd36564: bl              #0xd36594  ; AllocateFlexibleSpaceBarSettingsStub -> FlexibleSpaceBarSettings (size=0x38)
    // 0xd36568: d0 = 1.000000
    //     0xd36568: fmov            d0, #1.00000000
    // 0xd3656c: StoreField: r0->field_f = d0
    //     0xd3656c: stur            d0, [x0, #0xf]
    // 0xd36570: ldur            d0, [fp, #-0x10]
    // 0xd36574: ArrayStore: r0[0] = d0  ; List_8
    //     0xd36574: stur            d0, [x0, #0x17]
    // 0xd36578: StoreField: r0->field_1f = d0
    //     0xd36578: stur            d0, [x0, #0x1f]
    // 0xd3657c: StoreField: r0->field_27 = d0
    //     0xd3657c: stur            d0, [x0, #0x27]
    // 0xd36580: ldur            x1, [fp, #-8]
    // 0xd36584: StoreField: r0->field_b = r1
    //     0xd36584: stur            w1, [x0, #0xb]
    // 0xd36588: LeaveFrame
    //     0xd36588: mov             SP, fp
    //     0xd3658c: ldp             fp, lr, [SP], #0x10
    // 0xd36590: ret
    //     0xd36590: ret             
  }
}

// class id: 6813, size: 0x38, field offset: 0x10
//   const constructor, 
class FlexibleSpaceBarSettings extends InheritedWidget {

  _ updateShouldNotify(/* No info */) {
    // ** addr: 0xc00f34, size: 0xb4
    // 0xc00f34: EnterFrame
    //     0xc00f34: stp             fp, lr, [SP, #-0x10]!
    //     0xc00f38: mov             fp, SP
    // 0xc00f3c: AllocStack(0x10)
    //     0xc00f3c: sub             SP, SP, #0x10
    // 0xc00f40: SetupParameters(FlexibleSpaceBarSettings this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xc00f40: mov             x0, x2
    //     0xc00f44: mov             x4, x1
    //     0xc00f48: mov             x3, x2
    //     0xc00f4c: stur            x1, [fp, #-8]
    //     0xc00f50: stur            x2, [fp, #-0x10]
    // 0xc00f54: r2 = Null
    //     0xc00f54: mov             x2, NULL
    // 0xc00f58: r1 = Null
    //     0xc00f58: mov             x1, NULL
    // 0xc00f5c: r4 = 60
    //     0xc00f5c: mov             x4, #0x3c
    // 0xc00f60: branchIfSmi(r0, 0xc00f6c)
    //     0xc00f60: tbz             w0, #0, #0xc00f6c
    // 0xc00f64: r4 = LoadClassIdInstr(r0)
    //     0xc00f64: ldur            x4, [x0, #-1]
    //     0xc00f68: ubfx            x4, x4, #0xc, #0x14
    // 0xc00f6c: r17 = 6813
    //     0xc00f6c: mov             x17, #0x1a9d
    // 0xc00f70: cmp             x4, x17
    // 0xc00f74: b.eq            #0xc00f8c
    // 0xc00f78: r8 = FlexibleSpaceBarSettings
    //     0xc00f78: add             x8, PP, #0x95, lsl #12  ; [pp+0x95c80] Type: FlexibleSpaceBarSettings
    //     0xc00f7c: ldr             x8, [x8, #0xc80]
    // 0xc00f80: r3 = Null
    //     0xc00f80: add             x3, PP, #0x95, lsl #12  ; [pp+0x95c88] Null
    //     0xc00f84: ldr             x3, [x3, #0xc88]
    // 0xc00f88: r0 = DefaultTypeTest()
    //     0xc00f88: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xc00f8c: d0 = 1.000000
    //     0xc00f8c: fmov            d0, #1.00000000
    // 0xc00f90: fcmp            d0, d0
    // 0xc00f94: b.ne            #0xc00fd0
    // 0xc00f98: ldur            x2, [fp, #-8]
    // 0xc00f9c: ldur            x1, [fp, #-0x10]
    // 0xc00fa0: ArrayLoad: d0 = r2[0]  ; List_8
    //     0xc00fa0: ldur            d0, [x2, #0x17]
    // 0xc00fa4: ArrayLoad: d1 = r1[0]  ; List_8
    //     0xc00fa4: ldur            d1, [x1, #0x17]
    // 0xc00fa8: fcmp            d0, d1
    // 0xc00fac: b.ne            #0xc00fd0
    // 0xc00fb0: LoadField: d0 = r2->field_1f
    //     0xc00fb0: ldur            d0, [x2, #0x1f]
    // 0xc00fb4: LoadField: d1 = r1->field_1f
    //     0xc00fb4: ldur            d1, [x1, #0x1f]
    // 0xc00fb8: fcmp            d0, d1
    // 0xc00fbc: b.ne            #0xc00fd0
    // 0xc00fc0: LoadField: d0 = r2->field_27
    //     0xc00fc0: ldur            d0, [x2, #0x27]
    // 0xc00fc4: LoadField: d1 = r1->field_27
    //     0xc00fc4: ldur            d1, [x1, #0x27]
    // 0xc00fc8: fcmp            d0, d1
    // 0xc00fcc: b.eq            #0xc00fd8
    // 0xc00fd0: r0 = true
    //     0xc00fd0: add             x0, NULL, #0x20  ; true
    // 0xc00fd4: b               #0xc00fdc
    // 0xc00fd8: r0 = false
    //     0xc00fd8: add             x0, NULL, #0x30  ; false
    // 0xc00fdc: LeaveFrame
    //     0xc00fdc: mov             SP, fp
    //     0xc00fe0: ldp             fp, lr, [SP], #0x10
    // 0xc00fe4: ret
    //     0xc00fe4: ret             
  }
}
