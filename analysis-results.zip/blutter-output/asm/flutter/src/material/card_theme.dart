// lib: , url: package:flutter/src/material/card_theme.dart

// class id: 1048862, size: 0x8
class :: {
}

// class id: 5177, size: 0x24, field offset: 0x8
//   const constructor, 
class CardThemeData extends _MixinApplication3&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0x112fac4, size: 0x11c
    // 0x112fac4: EnterFrame
    //     0x112fac4: stp             fp, lr, [SP, #-0x10]!
    //     0x112fac8: mov             fp, SP
    // 0x112facc: AllocStack(0x58)
    //     0x112facc: sub             SP, SP, #0x58
    // 0x112fad0: CheckStackOverflow
    //     0x112fad0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x112fad4: cmp             SP, x16
    //     0x112fad8: b.ls            #0x112fbd8
    // 0x112fadc: ldr             x2, [fp, #0x10]
    // 0x112fae0: LoadField: r3 = r2->field_7
    //     0x112fae0: ldur            w3, [x2, #7]
    // 0x112fae4: DecompressPointer r3
    //     0x112fae4: add             x3, x3, HEAP, lsl #32
    // 0x112fae8: stur            x3, [fp, #-8]
    // 0x112faec: r0 = LoadClassIdInstr(r2)
    //     0x112faec: ldur            x0, [x2, #-1]
    //     0x112faf0: ubfx            x0, x0, #0xc, #0x14
    // 0x112faf4: mov             x1, x2
    // 0x112faf8: r0 = GDT[cid_x0 + 0xe20]()
    //     0x112faf8: add             lr, x0, #0xe20
    //     0x112fafc: ldr             lr, [x21, lr, lsl #3]
    //     0x112fb00: blr             lr
    // 0x112fb04: mov             x3, x0
    // 0x112fb08: ldr             x2, [fp, #0x10]
    // 0x112fb0c: stur            x3, [fp, #-0x10]
    // 0x112fb10: r0 = LoadClassIdInstr(r2)
    //     0x112fb10: ldur            x0, [x2, #-1]
    //     0x112fb14: ubfx            x0, x0, #0xc, #0x14
    // 0x112fb18: mov             x1, x2
    // 0x112fb1c: r0 = GDT[cid_x0 + 0xe1b]()
    //     0x112fb1c: add             lr, x0, #0xe1b
    //     0x112fb20: ldr             lr, [x21, lr, lsl #3]
    //     0x112fb24: blr             lr
    // 0x112fb28: mov             x3, x0
    // 0x112fb2c: ldr             x2, [fp, #0x10]
    // 0x112fb30: stur            x3, [fp, #-0x18]
    // 0x112fb34: r0 = LoadClassIdInstr(r2)
    //     0x112fb34: ldur            x0, [x2, #-1]
    //     0x112fb38: ubfx            x0, x0, #0xc, #0x14
    // 0x112fb3c: mov             x1, x2
    // 0x112fb40: r0 = GDT[cid_x0 + 0xdfc]()
    //     0x112fb40: add             lr, x0, #0xdfc
    //     0x112fb44: ldr             lr, [x21, lr, lsl #3]
    //     0x112fb48: blr             lr
    // 0x112fb4c: mov             x2, x0
    // 0x112fb50: ldr             x1, [fp, #0x10]
    // 0x112fb54: stur            x2, [fp, #-0x30]
    // 0x112fb58: ArrayLoad: r3 = r1[0]  ; List_4
    //     0x112fb58: ldur            w3, [x1, #0x17]
    // 0x112fb5c: DecompressPointer r3
    //     0x112fb5c: add             x3, x3, HEAP, lsl #32
    // 0x112fb60: stur            x3, [fp, #-0x28]
    // 0x112fb64: LoadField: r4 = r1->field_1b
    //     0x112fb64: ldur            w4, [x1, #0x1b]
    // 0x112fb68: DecompressPointer r4
    //     0x112fb68: add             x4, x4, HEAP, lsl #32
    // 0x112fb6c: stur            x4, [fp, #-0x20]
    // 0x112fb70: r0 = LoadClassIdInstr(r1)
    //     0x112fb70: ldur            x0, [x1, #-1]
    //     0x112fb74: ubfx            x0, x0, #0xc, #0x14
    // 0x112fb78: r0 = GDT[cid_x0 + 0xe51]()
    //     0x112fb78: add             lr, x0, #0xe51
    //     0x112fb7c: ldr             lr, [x21, lr, lsl #3]
    //     0x112fb80: blr             lr
    // 0x112fb84: ldur            x16, [fp, #-0x18]
    // 0x112fb88: ldur            lr, [fp, #-0x30]
    // 0x112fb8c: stp             lr, x16, [SP, #0x18]
    // 0x112fb90: ldur            x16, [fp, #-0x28]
    // 0x112fb94: ldur            lr, [fp, #-0x20]
    // 0x112fb98: stp             lr, x16, [SP, #8]
    // 0x112fb9c: str             x0, [SP]
    // 0x112fba0: ldur            x1, [fp, #-8]
    // 0x112fba4: ldur            x2, [fp, #-0x10]
    // 0x112fba8: r4 = const [0, 0x7, 0x5, 0x7, null]
    //     0x112fba8: add             x4, PP, #0xd, lsl #12  ; [pp+0xd8a0] List(5) [0, 0x7, 0x5, 0x7, Null]
    //     0x112fbac: ldr             x4, [x4, #0x8a0]
    // 0x112fbb0: r0 = hash()
    //     0x112fbb0: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x112fbb4: mov             x2, x0
    // 0x112fbb8: r0 = BoxInt64Instr(r2)
    //     0x112fbb8: sbfiz           x0, x2, #1, #0x1f
    //     0x112fbbc: cmp             x2, x0, asr #1
    //     0x112fbc0: b.eq            #0x112fbcc
    //     0x112fbc4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x112fbc8: stur            x2, [x0, #7]
    // 0x112fbcc: LeaveFrame
    //     0x112fbcc: mov             SP, fp
    //     0x112fbd0: ldp             fp, lr, [SP], #0x10
    // 0x112fbd4: ret
    //     0x112fbd4: ret             
    // 0x112fbd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x112fbd8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x112fbdc: b               #0x112fadc
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x1168570, size: 0x1a0
    // 0x1168570: EnterFrame
    //     0x1168570: stp             fp, lr, [SP, #-0x10]!
    //     0x1168574: mov             fp, SP
    // 0x1168578: AllocStack(0x30)
    //     0x1168578: sub             SP, SP, #0x30
    // 0x116857c: SetupParameters(dynamic _ /* r1 => r4, fp-0x18 */, dynamic _ /* r2 => r0, fp-0x20 */, dynamic _ /* d0 => d0, fp-0x30 */)
    //     0x116857c: mov             x4, x1
    //     0x1168580: mov             x0, x2
    //     0x1168584: stur            x1, [fp, #-0x18]
    //     0x1168588: stur            x2, [fp, #-0x20]
    //     0x116858c: stur            d0, [fp, #-0x30]
    // 0x1168590: CheckStackOverflow
    //     0x1168590: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1168594: cmp             SP, x16
    //     0x1168598: b.ls            #0x11686e4
    // 0x116859c: cmp             w4, w0
    // 0x11685a0: b.ne            #0x11685b4
    // 0x11685a4: mov             x0, x4
    // 0x11685a8: LeaveFrame
    //     0x11685a8: mov             SP, fp
    //     0x11685ac: ldp             fp, lr, [SP], #0x10
    // 0x11685b0: ret
    //     0x11685b0: ret             
    // 0x11685b4: d1 = 0.500000
    //     0x11685b4: fmov            d1, #0.50000000
    // 0x11685b8: fcmp            d1, d0
    // 0x11685bc: b.le            #0x11685d0
    // 0x11685c0: LoadField: r1 = r4->field_7
    //     0x11685c0: ldur            w1, [x4, #7]
    // 0x11685c4: DecompressPointer r1
    //     0x11685c4: add             x1, x1, HEAP, lsl #32
    // 0x11685c8: mov             x5, x1
    // 0x11685cc: b               #0x11685dc
    // 0x11685d0: LoadField: r1 = r0->field_7
    //     0x11685d0: ldur            w1, [x0, #7]
    // 0x11685d4: DecompressPointer r1
    //     0x11685d4: add             x1, x1, HEAP, lsl #32
    // 0x11685d8: mov             x5, x1
    // 0x11685dc: stur            x5, [fp, #-0x10]
    // 0x11685e0: r6 = inline_Allocate_Double()
    //     0x11685e0: ldp             x6, x1, [THR, #0x60]  ; THR::top
    //     0x11685e4: add             x6, x6, #0x10
    //     0x11685e8: cmp             x1, x6
    //     0x11685ec: b.ls            #0x11686ec
    //     0x11685f0: str             x6, [THR, #0x60]  ; THR::top
    //     0x11685f4: sub             x6, x6, #0xf
    //     0x11685f8: mov             x1, #0xe19c
    //     0x11685fc: movk            x1, #3, lsl #16
    //     0x1168600: stur            x1, [x6, #-1]
    // 0x1168604: dmb             ishst
    // 0x1168608: StoreField: r6->field_7 = d0
    //     0x1168608: stur            d0, [x6, #7]
    // 0x116860c: mov             x3, x6
    // 0x1168610: stur            x6, [fp, #-8]
    // 0x1168614: r1 = Null
    //     0x1168614: mov             x1, NULL
    // 0x1168618: r2 = Null
    //     0x1168618: mov             x2, NULL
    // 0x116861c: r0 = lerp()
    //     0x116861c: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1168620: ldur            x3, [fp, #-8]
    // 0x1168624: r1 = Null
    //     0x1168624: mov             x1, NULL
    // 0x1168628: r2 = Null
    //     0x1168628: mov             x2, NULL
    // 0x116862c: r0 = lerp()
    //     0x116862c: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1168630: ldur            x3, [fp, #-8]
    // 0x1168634: r1 = Null
    //     0x1168634: mov             x1, NULL
    // 0x1168638: r2 = Null
    //     0x1168638: mov             x2, NULL
    // 0x116863c: r0 = lerp()
    //     0x116863c: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1168640: ldur            x0, [fp, #-0x18]
    // 0x1168644: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x1168644: ldur            w1, [x0, #0x17]
    // 0x1168648: DecompressPointer r1
    //     0x1168648: add             x1, x1, HEAP, lsl #32
    // 0x116864c: ldur            x4, [fp, #-0x20]
    // 0x1168650: ArrayLoad: r2 = r4[0]  ; List_4
    //     0x1168650: ldur            w2, [x4, #0x17]
    // 0x1168654: DecompressPointer r2
    //     0x1168654: add             x2, x2, HEAP, lsl #32
    // 0x1168658: ldur            x3, [fp, #-8]
    // 0x116865c: r0 = lerpDouble()
    //     0x116865c: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1168660: mov             x4, x0
    // 0x1168664: ldur            x0, [fp, #-0x18]
    // 0x1168668: stur            x4, [fp, #-0x28]
    // 0x116866c: LoadField: r1 = r0->field_1b
    //     0x116866c: ldur            w1, [x0, #0x1b]
    // 0x1168670: DecompressPointer r1
    //     0x1168670: add             x1, x1, HEAP, lsl #32
    // 0x1168674: ldur            x5, [fp, #-0x20]
    // 0x1168678: LoadField: r2 = r5->field_1b
    //     0x1168678: ldur            w2, [x5, #0x1b]
    // 0x116867c: DecompressPointer r2
    //     0x116867c: add             x2, x2, HEAP, lsl #32
    // 0x1168680: ldur            x3, [fp, #-8]
    // 0x1168684: r0 = lerp()
    //     0x1168684: bl              #0x1140de0  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0x1168688: mov             x3, x0
    // 0x116868c: ldur            x0, [fp, #-0x18]
    // 0x1168690: stur            x3, [fp, #-8]
    // 0x1168694: LoadField: r1 = r0->field_1f
    //     0x1168694: ldur            w1, [x0, #0x1f]
    // 0x1168698: DecompressPointer r1
    //     0x1168698: add             x1, x1, HEAP, lsl #32
    // 0x116869c: ldur            x0, [fp, #-0x20]
    // 0x11686a0: LoadField: r2 = r0->field_1f
    //     0x11686a0: ldur            w2, [x0, #0x1f]
    // 0x11686a4: DecompressPointer r2
    //     0x11686a4: add             x2, x2, HEAP, lsl #32
    // 0x11686a8: ldur            d0, [fp, #-0x30]
    // 0x11686ac: r0 = lerp()
    //     0x11686ac: bl              #0x115deb4  ; [package:flutter/src/painting/borders.dart] ShapeBorder::lerp
    // 0x11686b0: stur            x0, [fp, #-0x18]
    // 0x11686b4: r0 = CardThemeData()
    //     0x11686b4: bl              #0x1168710  ; AllocateCardThemeDataStub -> CardThemeData (size=0x24)
    // 0x11686b8: ldur            x1, [fp, #-0x10]
    // 0x11686bc: StoreField: r0->field_7 = r1
    //     0x11686bc: stur            w1, [x0, #7]
    // 0x11686c0: ldur            x1, [fp, #-0x28]
    // 0x11686c4: ArrayStore: r0[0] = r1  ; List_4
    //     0x11686c4: stur            w1, [x0, #0x17]
    // 0x11686c8: ldur            x1, [fp, #-8]
    // 0x11686cc: StoreField: r0->field_1b = r1
    //     0x11686cc: stur            w1, [x0, #0x1b]
    // 0x11686d0: ldur            x1, [fp, #-0x18]
    // 0x11686d4: StoreField: r0->field_1f = r1
    //     0x11686d4: stur            w1, [x0, #0x1f]
    // 0x11686d8: LeaveFrame
    //     0x11686d8: mov             SP, fp
    //     0x11686dc: ldp             fp, lr, [SP], #0x10
    // 0x11686e0: ret
    //     0x11686e0: ret             
    // 0x11686e4: r0 = StackOverflowSharedWithFPURegs()
    //     0x11686e4: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x11686e8: b               #0x116859c
    // 0x11686ec: SaveReg d0
    //     0x11686ec: str             q0, [SP, #-0x10]!
    // 0x11686f0: stp             x4, x5, [SP, #-0x10]!
    // 0x11686f4: SaveReg r0
    //     0x11686f4: str             x0, [SP, #-8]!
    // 0x11686f8: r0 = AllocateDouble()
    //     0x11686f8: bl              #0x13df878  ; AllocateDoubleStub
    // 0x11686fc: mov             x6, x0
    // 0x1168700: RestoreReg r0
    //     0x1168700: ldr             x0, [SP], #8
    // 0x1168704: ldp             x4, x5, [SP], #0x10
    // 0x1168708: RestoreReg d0
    //     0x1168708: ldr             q0, [SP], #0x10
    // 0x116870c: b               #0x1168608
  }
  _ ==(/* No info */) {
    // ** addr: 0x1265ac0, size: 0x2d4
    // 0x1265ac0: EnterFrame
    //     0x1265ac0: stp             fp, lr, [SP, #-0x10]!
    //     0x1265ac4: mov             fp, SP
    // 0x1265ac8: AllocStack(0x18)
    //     0x1265ac8: sub             SP, SP, #0x18
    // 0x1265acc: CheckStackOverflow
    //     0x1265acc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1265ad0: cmp             SP, x16
    //     0x1265ad4: b.ls            #0x1265d8c
    // 0x1265ad8: ldr             x1, [fp, #0x10]
    // 0x1265adc: cmp             w1, NULL
    // 0x1265ae0: b.ne            #0x1265af4
    // 0x1265ae4: r0 = false
    //     0x1265ae4: add             x0, NULL, #0x30  ; false
    // 0x1265ae8: LeaveFrame
    //     0x1265ae8: mov             SP, fp
    //     0x1265aec: ldp             fp, lr, [SP], #0x10
    // 0x1265af0: ret
    //     0x1265af0: ret             
    // 0x1265af4: ldr             x0, [fp, #0x18]
    // 0x1265af8: cmp             w0, w1
    // 0x1265afc: b.ne            #0x1265b10
    // 0x1265b00: r0 = true
    //     0x1265b00: add             x0, NULL, #0x20  ; true
    // 0x1265b04: LeaveFrame
    //     0x1265b04: mov             SP, fp
    //     0x1265b08: ldp             fp, lr, [SP], #0x10
    // 0x1265b0c: ret
    //     0x1265b0c: ret             
    // 0x1265b10: stp             x0, x1, [SP]
    // 0x1265b14: r0 = _haveSameRuntimeType()
    //     0x1265b14: bl              #0x88249c  ; [dart:core] Object::_haveSameRuntimeType
    // 0x1265b18: tbz             w0, #4, #0x1265b2c
    // 0x1265b1c: r0 = false
    //     0x1265b1c: add             x0, NULL, #0x30  ; false
    // 0x1265b20: LeaveFrame
    //     0x1265b20: mov             SP, fp
    //     0x1265b24: ldp             fp, lr, [SP], #0x10
    // 0x1265b28: ret
    //     0x1265b28: ret             
    // 0x1265b2c: ldr             x2, [fp, #0x10]
    // 0x1265b30: r0 = 60
    //     0x1265b30: mov             x0, #0x3c
    // 0x1265b34: branchIfSmi(r2, 0x1265b40)
    //     0x1265b34: tbz             w2, #0, #0x1265b40
    // 0x1265b38: r0 = LoadClassIdInstr(r2)
    //     0x1265b38: ldur            x0, [x2, #-1]
    //     0x1265b3c: ubfx            x0, x0, #0xc, #0x14
    // 0x1265b40: r17 = -5177
    //     0x1265b40: mov             x17, #-0x1439
    // 0x1265b44: add             x16, x0, x17
    // 0x1265b48: cmp             x16, #4
    // 0x1265b4c: b.hi            #0x1265d7c
    // 0x1265b50: ldr             x3, [fp, #0x18]
    // 0x1265b54: LoadField: r0 = r2->field_7
    //     0x1265b54: ldur            w0, [x2, #7]
    // 0x1265b58: DecompressPointer r0
    //     0x1265b58: add             x0, x0, HEAP, lsl #32
    // 0x1265b5c: LoadField: r1 = r3->field_7
    //     0x1265b5c: ldur            w1, [x3, #7]
    // 0x1265b60: DecompressPointer r1
    //     0x1265b60: add             x1, x1, HEAP, lsl #32
    // 0x1265b64: cmp             w0, w1
    // 0x1265b68: b.ne            #0x1265d7c
    // 0x1265b6c: r0 = LoadClassIdInstr(r2)
    //     0x1265b6c: ldur            x0, [x2, #-1]
    //     0x1265b70: ubfx            x0, x0, #0xc, #0x14
    // 0x1265b74: mov             x1, x2
    // 0x1265b78: r0 = GDT[cid_x0 + 0xe20]()
    //     0x1265b78: add             lr, x0, #0xe20
    //     0x1265b7c: ldr             lr, [x21, lr, lsl #3]
    //     0x1265b80: blr             lr
    // 0x1265b84: mov             x3, x0
    // 0x1265b88: ldr             x2, [fp, #0x18]
    // 0x1265b8c: stur            x3, [fp, #-8]
    // 0x1265b90: r0 = LoadClassIdInstr(r2)
    //     0x1265b90: ldur            x0, [x2, #-1]
    //     0x1265b94: ubfx            x0, x0, #0xc, #0x14
    // 0x1265b98: mov             x1, x2
    // 0x1265b9c: r0 = GDT[cid_x0 + 0xe20]()
    //     0x1265b9c: add             lr, x0, #0xe20
    //     0x1265ba0: ldr             lr, [x21, lr, lsl #3]
    //     0x1265ba4: blr             lr
    // 0x1265ba8: mov             x1, x0
    // 0x1265bac: ldur            x0, [fp, #-8]
    // 0x1265bb0: r2 = LoadClassIdInstr(r0)
    //     0x1265bb0: ldur            x2, [x0, #-1]
    //     0x1265bb4: ubfx            x2, x2, #0xc, #0x14
    // 0x1265bb8: stp             x1, x0, [SP]
    // 0x1265bbc: mov             x0, x2
    // 0x1265bc0: mov             lr, x0
    // 0x1265bc4: ldr             lr, [x21, lr, lsl #3]
    // 0x1265bc8: blr             lr
    // 0x1265bcc: tbnz            w0, #4, #0x1265d7c
    // 0x1265bd0: ldr             x2, [fp, #0x18]
    // 0x1265bd4: ldr             x3, [fp, #0x10]
    // 0x1265bd8: r0 = LoadClassIdInstr(r3)
    //     0x1265bd8: ldur            x0, [x3, #-1]
    //     0x1265bdc: ubfx            x0, x0, #0xc, #0x14
    // 0x1265be0: mov             x1, x3
    // 0x1265be4: r0 = GDT[cid_x0 + 0xe1b]()
    //     0x1265be4: add             lr, x0, #0xe1b
    //     0x1265be8: ldr             lr, [x21, lr, lsl #3]
    //     0x1265bec: blr             lr
    // 0x1265bf0: mov             x3, x0
    // 0x1265bf4: ldr             x2, [fp, #0x18]
    // 0x1265bf8: stur            x3, [fp, #-8]
    // 0x1265bfc: r0 = LoadClassIdInstr(r2)
    //     0x1265bfc: ldur            x0, [x2, #-1]
    //     0x1265c00: ubfx            x0, x0, #0xc, #0x14
    // 0x1265c04: mov             x1, x2
    // 0x1265c08: r0 = GDT[cid_x0 + 0xe1b]()
    //     0x1265c08: add             lr, x0, #0xe1b
    //     0x1265c0c: ldr             lr, [x21, lr, lsl #3]
    //     0x1265c10: blr             lr
    // 0x1265c14: mov             x1, x0
    // 0x1265c18: ldur            x0, [fp, #-8]
    // 0x1265c1c: r2 = LoadClassIdInstr(r0)
    //     0x1265c1c: ldur            x2, [x0, #-1]
    //     0x1265c20: ubfx            x2, x2, #0xc, #0x14
    // 0x1265c24: stp             x1, x0, [SP]
    // 0x1265c28: mov             x0, x2
    // 0x1265c2c: mov             lr, x0
    // 0x1265c30: ldr             lr, [x21, lr, lsl #3]
    // 0x1265c34: blr             lr
    // 0x1265c38: tbnz            w0, #4, #0x1265d7c
    // 0x1265c3c: ldr             x2, [fp, #0x18]
    // 0x1265c40: ldr             x3, [fp, #0x10]
    // 0x1265c44: r0 = LoadClassIdInstr(r3)
    //     0x1265c44: ldur            x0, [x3, #-1]
    //     0x1265c48: ubfx            x0, x0, #0xc, #0x14
    // 0x1265c4c: mov             x1, x3
    // 0x1265c50: r0 = GDT[cid_x0 + 0xdfc]()
    //     0x1265c50: add             lr, x0, #0xdfc
    //     0x1265c54: ldr             lr, [x21, lr, lsl #3]
    //     0x1265c58: blr             lr
    // 0x1265c5c: mov             x3, x0
    // 0x1265c60: ldr             x2, [fp, #0x18]
    // 0x1265c64: stur            x3, [fp, #-8]
    // 0x1265c68: r0 = LoadClassIdInstr(r2)
    //     0x1265c68: ldur            x0, [x2, #-1]
    //     0x1265c6c: ubfx            x0, x0, #0xc, #0x14
    // 0x1265c70: mov             x1, x2
    // 0x1265c74: r0 = GDT[cid_x0 + 0xdfc]()
    //     0x1265c74: add             lr, x0, #0xdfc
    //     0x1265c78: ldr             lr, [x21, lr, lsl #3]
    //     0x1265c7c: blr             lr
    // 0x1265c80: mov             x1, x0
    // 0x1265c84: ldur            x0, [fp, #-8]
    // 0x1265c88: r2 = LoadClassIdInstr(r0)
    //     0x1265c88: ldur            x2, [x0, #-1]
    //     0x1265c8c: ubfx            x2, x2, #0xc, #0x14
    // 0x1265c90: stp             x1, x0, [SP]
    // 0x1265c94: mov             x0, x2
    // 0x1265c98: mov             lr, x0
    // 0x1265c9c: ldr             lr, [x21, lr, lsl #3]
    // 0x1265ca0: blr             lr
    // 0x1265ca4: tbnz            w0, #4, #0x1265d7c
    // 0x1265ca8: ldr             x1, [fp, #0x18]
    // 0x1265cac: ldr             x2, [fp, #0x10]
    // 0x1265cb0: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x1265cb0: ldur            w0, [x2, #0x17]
    // 0x1265cb4: DecompressPointer r0
    //     0x1265cb4: add             x0, x0, HEAP, lsl #32
    // 0x1265cb8: ArrayLoad: r3 = r1[0]  ; List_4
    //     0x1265cb8: ldur            w3, [x1, #0x17]
    // 0x1265cbc: DecompressPointer r3
    //     0x1265cbc: add             x3, x3, HEAP, lsl #32
    // 0x1265cc0: r4 = LoadClassIdInstr(r0)
    //     0x1265cc0: ldur            x4, [x0, #-1]
    //     0x1265cc4: ubfx            x4, x4, #0xc, #0x14
    // 0x1265cc8: stp             x3, x0, [SP]
    // 0x1265ccc: mov             x0, x4
    // 0x1265cd0: mov             lr, x0
    // 0x1265cd4: ldr             lr, [x21, lr, lsl #3]
    // 0x1265cd8: blr             lr
    // 0x1265cdc: tbnz            w0, #4, #0x1265d7c
    // 0x1265ce0: ldr             x1, [fp, #0x18]
    // 0x1265ce4: ldr             x2, [fp, #0x10]
    // 0x1265ce8: LoadField: r0 = r2->field_1b
    //     0x1265ce8: ldur            w0, [x2, #0x1b]
    // 0x1265cec: DecompressPointer r0
    //     0x1265cec: add             x0, x0, HEAP, lsl #32
    // 0x1265cf0: LoadField: r3 = r1->field_1b
    //     0x1265cf0: ldur            w3, [x1, #0x1b]
    // 0x1265cf4: DecompressPointer r3
    //     0x1265cf4: add             x3, x3, HEAP, lsl #32
    // 0x1265cf8: r4 = LoadClassIdInstr(r0)
    //     0x1265cf8: ldur            x4, [x0, #-1]
    //     0x1265cfc: ubfx            x4, x4, #0xc, #0x14
    // 0x1265d00: stp             x3, x0, [SP]
    // 0x1265d04: mov             x0, x4
    // 0x1265d08: mov             lr, x0
    // 0x1265d0c: ldr             lr, [x21, lr, lsl #3]
    // 0x1265d10: blr             lr
    // 0x1265d14: tbnz            w0, #4, #0x1265d7c
    // 0x1265d18: ldr             x2, [fp, #0x18]
    // 0x1265d1c: ldr             x1, [fp, #0x10]
    // 0x1265d20: r0 = LoadClassIdInstr(r1)
    //     0x1265d20: ldur            x0, [x1, #-1]
    //     0x1265d24: ubfx            x0, x0, #0xc, #0x14
    // 0x1265d28: r0 = GDT[cid_x0 + 0xe51]()
    //     0x1265d28: add             lr, x0, #0xe51
    //     0x1265d2c: ldr             lr, [x21, lr, lsl #3]
    //     0x1265d30: blr             lr
    // 0x1265d34: mov             x2, x0
    // 0x1265d38: ldr             x1, [fp, #0x18]
    // 0x1265d3c: stur            x2, [fp, #-8]
    // 0x1265d40: r0 = LoadClassIdInstr(r1)
    //     0x1265d40: ldur            x0, [x1, #-1]
    //     0x1265d44: ubfx            x0, x0, #0xc, #0x14
    // 0x1265d48: r0 = GDT[cid_x0 + 0xe51]()
    //     0x1265d48: add             lr, x0, #0xe51
    //     0x1265d4c: ldr             lr, [x21, lr, lsl #3]
    //     0x1265d50: blr             lr
    // 0x1265d54: mov             x1, x0
    // 0x1265d58: ldur            x0, [fp, #-8]
    // 0x1265d5c: r2 = LoadClassIdInstr(r0)
    //     0x1265d5c: ldur            x2, [x0, #-1]
    //     0x1265d60: ubfx            x2, x2, #0xc, #0x14
    // 0x1265d64: stp             x1, x0, [SP]
    // 0x1265d68: mov             x0, x2
    // 0x1265d6c: mov             lr, x0
    // 0x1265d70: ldr             lr, [x21, lr, lsl #3]
    // 0x1265d74: blr             lr
    // 0x1265d78: b               #0x1265d80
    // 0x1265d7c: r0 = false
    //     0x1265d7c: add             x0, NULL, #0x30  ; false
    // 0x1265d80: LeaveFrame
    //     0x1265d80: mov             SP, fp
    //     0x1265d84: ldp             fp, lr, [SP], #0x10
    // 0x1265d88: ret
    //     0x1265d88: ret             
    // 0x1265d8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1265d8c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1265d90: b               #0x1265ad8
  }
}

// class id: 6823, size: 0x10, field offset: 0x10
//   const constructor, 
abstract class CardTheme extends _MixinApplication19&InheritedWidget&Diagnosticable {

  static _ of(/* No info */) {
    // ** addr: 0xfb3d2c, size: 0x58
    // 0xfb3d2c: EnterFrame
    //     0xfb3d2c: stp             fp, lr, [SP, #-0x10]!
    //     0xfb3d30: mov             fp, SP
    // 0xfb3d34: AllocStack(0x18)
    //     0xfb3d34: sub             SP, SP, #0x18
    // 0xfb3d38: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0xfb3d38: stur            x1, [fp, #-8]
    // 0xfb3d3c: CheckStackOverflow
    //     0xfb3d3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb3d40: cmp             SP, x16
    //     0xfb3d44: b.ls            #0xfb3d7c
    // 0xfb3d48: r16 = <CardTheme>
    //     0xfb3d48: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8c9c0] TypeArguments: <CardTheme>
    //     0xfb3d4c: ldr             x16, [x16, #0x9c0]
    // 0xfb3d50: stp             x1, x16, [SP]
    // 0xfb3d54: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xfb3d54: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xfb3d58: r0 = dependOnInheritedWidgetOfExactType()
    //     0xfb3d58: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xfb3d5c: ldur            x1, [fp, #-8]
    // 0xfb3d60: r0 = of()
    //     0xfb3d60: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfb3d64: LoadField: r1 = r0->field_af
    //     0xfb3d64: ldur            w1, [x0, #0xaf]
    // 0xfb3d68: DecompressPointer r1
    //     0xfb3d68: add             x1, x1, HEAP, lsl #32
    // 0xfb3d6c: mov             x0, x1
    // 0xfb3d70: LeaveFrame
    //     0xfb3d70: mov             SP, fp
    //     0xfb3d74: ldp             fp, lr, [SP], #0x10
    // 0xfb3d78: ret
    //     0xfb3d78: ret             
    // 0xfb3d7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb3d7c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb3d80: b               #0xfb3d48
  }
}
