// lib: , url: package:flutter/src/material/expansion_tile_theme.dart

// class id: 1048892, size: 0x8
class :: {
}

// class id: 5152, size: 0x3c, field offset: 0x8
//   const constructor, 
class ExpansionTileThemeData extends _MixinApplication3&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0x11331a4, size: 0x31c
    // 0x11331a4: EnterFrame
    //     0x11331a4: stp             fp, lr, [SP, #-0x10]!
    //     0x11331a8: mov             fp, SP
    // 0x11331ac: AllocStack(0x78)
    //     0x11331ac: sub             SP, SP, #0x78
    // 0x11331b0: CheckStackOverflow
    //     0x11331b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11331b4: cmp             SP, x16
    //     0x11331b8: b.ls            #0x11334b8
    // 0x11331bc: ldr             x0, [fp, #0x10]
    // 0x11331c0: r2 = LoadClassIdInstr(r0)
    //     0x11331c0: ldur            x2, [x0, #-1]
    //     0x11331c4: ubfx            x2, x2, #0xc, #0x14
    // 0x11331c8: stur            x2, [fp, #-8]
    // 0x11331cc: r17 = 5152
    //     0x11331cc: mov             x17, #0x1420
    // 0x11331d0: cmp             x2, x17
    // 0x11331d4: b.ne            #0x11331ec
    // 0x11331d8: LoadField: r1 = r0->field_1b
    //     0x11331d8: ldur            w1, [x0, #0x1b]
    // 0x11331dc: DecompressPointer r1
    //     0x11331dc: add             x1, x1, HEAP, lsl #32
    // 0x11331e0: mov             x0, x2
    // 0x11331e4: mov             x2, x1
    // 0x11331e8: b               #0x1133264
    // 0x11331ec: r17 = 5153
    //     0x11331ec: mov             x17, #0x1421
    // 0x11331f0: cmp             x2, x17
    // 0x11331f4: b.ne            #0x1133230
    // 0x11331f8: mov             x1, x0
    // 0x11331fc: LoadField: r0 = r1->field_43
    //     0x11331fc: ldur            w0, [x1, #0x43]
    // 0x1133200: DecompressPointer r0
    //     0x1133200: add             x0, x0, HEAP, lsl #32
    // 0x1133204: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1133208: cmp             w0, w16
    // 0x113320c: b.ne            #0x113321c
    // 0x1133210: r2 = _colors
    //     0x1133210: add             x2, PP, #0x26, lsl #12  ; [pp+0x26390] Field <_ExpansionTileDefaultsM3@747392950._colors@747392950>: late final (offset: 0x44)
    //     0x1133214: ldr             x2, [x2, #0x390]
    // 0x1133218: r0 = InitLateFinalInstanceField()
    //     0x1133218: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x113321c: LoadField: r1 = r0->field_b
    //     0x113321c: ldur            w1, [x0, #0xb]
    // 0x1133220: DecompressPointer r1
    //     0x1133220: add             x1, x1, HEAP, lsl #32
    // 0x1133224: mov             x2, x1
    // 0x1133228: ldur            x0, [fp, #-8]
    // 0x113322c: b               #0x1133264
    // 0x1133230: ldr             x1, [fp, #0x10]
    // 0x1133234: LoadField: r0 = r1->field_43
    //     0x1133234: ldur            w0, [x1, #0x43]
    // 0x1133238: DecompressPointer r0
    //     0x1133238: add             x0, x0, HEAP, lsl #32
    // 0x113323c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1133240: cmp             w0, w16
    // 0x1133244: b.ne            #0x1133254
    // 0x1133248: r2 = _colorScheme
    //     0x1133248: add             x2, PP, #0x26, lsl #12  ; [pp+0x26398] Field <_ExpansionTileDefaultsM2@747392950._colorScheme@747392950>: late final (offset: 0x44)
    //     0x113324c: ldr             x2, [x2, #0x398]
    // 0x1133250: r0 = InitLateFinalInstanceField()
    //     0x1133250: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1133254: LoadField: r1 = r0->field_b
    //     0x1133254: ldur            w1, [x0, #0xb]
    // 0x1133258: DecompressPointer r1
    //     0x1133258: add             x1, x1, HEAP, lsl #32
    // 0x113325c: mov             x2, x1
    // 0x1133260: ldur            x0, [fp, #-8]
    // 0x1133264: stur            x2, [fp, #-0x10]
    // 0x1133268: r17 = 5152
    //     0x1133268: mov             x17, #0x1420
    // 0x113326c: cmp             x0, x17
    // 0x1133270: b.ne            #0x1133288
    // 0x1133274: ldr             x3, [fp, #0x10]
    // 0x1133278: LoadField: r1 = r3->field_1f
    //     0x1133278: ldur            w1, [x3, #0x1f]
    // 0x113327c: DecompressPointer r1
    //     0x113327c: add             x1, x1, HEAP, lsl #32
    // 0x1133280: mov             x2, x1
    // 0x1133284: b               #0x1133320
    // 0x1133288: ldr             x3, [fp, #0x10]
    // 0x113328c: r17 = 5153
    //     0x113328c: mov             x17, #0x1421
    // 0x1133290: cmp             x0, x17
    // 0x1133294: b.ne            #0x11332ec
    // 0x1133298: mov             x1, x3
    // 0x113329c: LoadField: r0 = r1->field_43
    //     0x113329c: ldur            w0, [x1, #0x43]
    // 0x11332a0: DecompressPointer r0
    //     0x11332a0: add             x0, x0, HEAP, lsl #32
    // 0x11332a4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11332a8: cmp             w0, w16
    // 0x11332ac: b.ne            #0x11332bc
    // 0x11332b0: r2 = _colors
    //     0x11332b0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26390] Field <_ExpansionTileDefaultsM3@747392950._colors@747392950>: late final (offset: 0x44)
    //     0x11332b4: ldr             x2, [x2, #0x390]
    // 0x11332b8: r0 = InitLateFinalInstanceField()
    //     0x11332b8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x11332bc: LoadField: r1 = r0->field_a3
    //     0x11332bc: ldur            w1, [x0, #0xa3]
    // 0x11332c0: DecompressPointer r1
    //     0x11332c0: add             x1, x1, HEAP, lsl #32
    // 0x11332c4: cmp             w1, NULL
    // 0x11332c8: b.ne            #0x11332dc
    // 0x11332cc: LoadField: r1 = r0->field_7f
    //     0x11332cc: ldur            w1, [x0, #0x7f]
    // 0x11332d0: DecompressPointer r1
    //     0x11332d0: add             x1, x1, HEAP, lsl #32
    // 0x11332d4: mov             x0, x1
    // 0x11332d8: b               #0x11332e0
    // 0x11332dc: mov             x0, x1
    // 0x11332e0: mov             x2, x0
    // 0x11332e4: ldur            x0, [fp, #-8]
    // 0x11332e8: b               #0x1133320
    // 0x11332ec: ldr             x1, [fp, #0x10]
    // 0x11332f0: LoadField: r0 = r1->field_3f
    //     0x11332f0: ldur            w0, [x1, #0x3f]
    // 0x11332f4: DecompressPointer r0
    //     0x11332f4: add             x0, x0, HEAP, lsl #32
    // 0x11332f8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11332fc: cmp             w0, w16
    // 0x1133300: b.ne            #0x1133310
    // 0x1133304: r2 = _theme
    //     0x1133304: add             x2, PP, #0x26, lsl #12  ; [pp+0x263a0] Field <_ExpansionTileDefaultsM2@747392950._theme@747392950>: late final (offset: 0x40)
    //     0x1133308: ldr             x2, [x2, #0x3a0]
    // 0x113330c: r0 = InitLateFinalInstanceField()
    //     0x113330c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1133310: LoadField: r1 = r0->field_77
    //     0x1133310: ldur            w1, [x0, #0x77]
    // 0x1133314: DecompressPointer r1
    //     0x1133314: add             x1, x1, HEAP, lsl #32
    // 0x1133318: mov             x2, x1
    // 0x113331c: ldur            x0, [fp, #-8]
    // 0x1133320: stur            x2, [fp, #-0x18]
    // 0x1133324: r17 = 5152
    //     0x1133324: mov             x17, #0x1420
    // 0x1133328: cmp             x0, x17
    // 0x113332c: b.ne            #0x1133344
    // 0x1133330: ldr             x3, [fp, #0x10]
    // 0x1133334: LoadField: r1 = r3->field_23
    //     0x1133334: ldur            w1, [x3, #0x23]
    // 0x1133338: DecompressPointer r1
    //     0x1133338: add             x1, x1, HEAP, lsl #32
    // 0x113333c: mov             x2, x1
    // 0x1133340: b               #0x11333c0
    // 0x1133344: ldr             x3, [fp, #0x10]
    // 0x1133348: r17 = 5153
    //     0x1133348: mov             x17, #0x1421
    // 0x113334c: cmp             x0, x17
    // 0x1133350: b.ne            #0x113338c
    // 0x1133354: mov             x1, x3
    // 0x1133358: LoadField: r0 = r1->field_43
    //     0x1133358: ldur            w0, [x1, #0x43]
    // 0x113335c: DecompressPointer r0
    //     0x113335c: add             x0, x0, HEAP, lsl #32
    // 0x1133360: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1133364: cmp             w0, w16
    // 0x1133368: b.ne            #0x1133378
    // 0x113336c: r2 = _colors
    //     0x113336c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26390] Field <_ExpansionTileDefaultsM3@747392950._colors@747392950>: late final (offset: 0x44)
    //     0x1133370: ldr             x2, [x2, #0x390]
    // 0x1133374: r0 = InitLateFinalInstanceField()
    //     0x1133374: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1133378: LoadField: r1 = r0->field_7f
    //     0x1133378: ldur            w1, [x0, #0x7f]
    // 0x113337c: DecompressPointer r1
    //     0x113337c: add             x1, x1, HEAP, lsl #32
    // 0x1133380: mov             x2, x1
    // 0x1133384: ldur            x0, [fp, #-8]
    // 0x1133388: b               #0x11333c0
    // 0x113338c: ldr             x1, [fp, #0x10]
    // 0x1133390: LoadField: r0 = r1->field_43
    //     0x1133390: ldur            w0, [x1, #0x43]
    // 0x1133394: DecompressPointer r0
    //     0x1133394: add             x0, x0, HEAP, lsl #32
    // 0x1133398: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x113339c: cmp             w0, w16
    // 0x11333a0: b.ne            #0x11333b0
    // 0x11333a4: r2 = _colorScheme
    //     0x11333a4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26398] Field <_ExpansionTileDefaultsM2@747392950._colorScheme@747392950>: late final (offset: 0x44)
    //     0x11333a8: ldr             x2, [x2, #0x398]
    // 0x11333ac: r0 = InitLateFinalInstanceField()
    //     0x11333ac: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x11333b0: LoadField: r1 = r0->field_b
    //     0x11333b0: ldur            w1, [x0, #0xb]
    // 0x11333b4: DecompressPointer r1
    //     0x11333b4: add             x1, x1, HEAP, lsl #32
    // 0x11333b8: mov             x2, x1
    // 0x11333bc: ldur            x0, [fp, #-8]
    // 0x11333c0: stur            x2, [fp, #-0x20]
    // 0x11333c4: r17 = 5152
    //     0x11333c4: mov             x17, #0x1420
    // 0x11333c8: cmp             x0, x17
    // 0x11333cc: b.ne            #0x11333e0
    // 0x11333d0: ldr             x1, [fp, #0x10]
    // 0x11333d4: LoadField: r0 = r1->field_27
    //     0x11333d4: ldur            w0, [x1, #0x27]
    // 0x11333d8: DecompressPointer r0
    //     0x11333d8: add             x0, x0, HEAP, lsl #32
    // 0x11333dc: b               #0x113345c
    // 0x11333e0: ldr             x1, [fp, #0x10]
    // 0x11333e4: r17 = 5153
    //     0x11333e4: mov             x17, #0x1421
    // 0x11333e8: cmp             x0, x17
    // 0x11333ec: b.ne            #0x1133420
    // 0x11333f0: LoadField: r0 = r1->field_43
    //     0x11333f0: ldur            w0, [x1, #0x43]
    // 0x11333f4: DecompressPointer r0
    //     0x11333f4: add             x0, x0, HEAP, lsl #32
    // 0x11333f8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11333fc: cmp             w0, w16
    // 0x1133400: b.ne            #0x1133410
    // 0x1133404: r2 = _colors
    //     0x1133404: add             x2, PP, #0x26, lsl #12  ; [pp+0x26390] Field <_ExpansionTileDefaultsM3@747392950._colors@747392950>: late final (offset: 0x44)
    //     0x1133408: ldr             x2, [x2, #0x390]
    // 0x113340c: r0 = InitLateFinalInstanceField()
    //     0x113340c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1133410: LoadField: r1 = r0->field_7f
    //     0x1133410: ldur            w1, [x0, #0x7f]
    // 0x1133414: DecompressPointer r1
    //     0x1133414: add             x1, x1, HEAP, lsl #32
    // 0x1133418: mov             x0, x1
    // 0x113341c: b               #0x113345c
    // 0x1133420: LoadField: r0 = r1->field_3f
    //     0x1133420: ldur            w0, [x1, #0x3f]
    // 0x1133424: DecompressPointer r0
    //     0x1133424: add             x0, x0, HEAP, lsl #32
    // 0x1133428: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x113342c: cmp             w0, w16
    // 0x1133430: b.ne            #0x1133440
    // 0x1133434: r2 = _theme
    //     0x1133434: add             x2, PP, #0x26, lsl #12  ; [pp+0x263a0] Field <_ExpansionTileDefaultsM2@747392950._theme@747392950>: late final (offset: 0x40)
    //     0x1133438: ldr             x2, [x2, #0x3a0]
    // 0x113343c: r0 = InitLateFinalInstanceField()
    //     0x113343c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1133440: LoadField: r1 = r0->field_87
    //     0x1133440: ldur            w1, [x0, #0x87]
    // 0x1133444: DecompressPointer r1
    //     0x1133444: add             x1, x1, HEAP, lsl #32
    // 0x1133448: LoadField: r0 = r1->field_23
    //     0x1133448: ldur            w0, [x1, #0x23]
    // 0x113344c: DecompressPointer r0
    //     0x113344c: add             x0, x0, HEAP, lsl #32
    // 0x1133450: LoadField: r1 = r0->field_b
    //     0x1133450: ldur            w1, [x0, #0xb]
    // 0x1133454: DecompressPointer r1
    //     0x1133454: add             x1, x1, HEAP, lsl #32
    // 0x1133458: mov             x0, x1
    // 0x113345c: stp             NULL, NULL, [SP, #0x48]
    // 0x1133460: ldur            x16, [fp, #-0x10]
    // 0x1133464: stp             x16, NULL, [SP, #0x38]
    // 0x1133468: ldur            x16, [fp, #-0x18]
    // 0x113346c: ldur            lr, [fp, #-0x20]
    // 0x1133470: stp             lr, x16, [SP, #0x28]
    // 0x1133474: stp             NULL, x0, [SP, #0x18]
    // 0x1133478: stp             NULL, NULL, [SP, #8]
    // 0x113347c: str             NULL, [SP]
    // 0x1133480: r1 = Null
    //     0x1133480: mov             x1, NULL
    // 0x1133484: r2 = Null
    //     0x1133484: mov             x2, NULL
    // 0x1133488: r4 = const [0, 0xd, 0xb, 0xd, null]
    //     0x1133488: add             x4, PP, #0x26, lsl #12  ; [pp+0x26260] List(5) [0, 0xd, 0xb, 0xd, Null]
    //     0x113348c: ldr             x4, [x4, #0x260]
    // 0x1133490: r0 = hash()
    //     0x1133490: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x1133494: mov             x2, x0
    // 0x1133498: r0 = BoxInt64Instr(r2)
    //     0x1133498: sbfiz           x0, x2, #1, #0x1f
    //     0x113349c: cmp             x2, x0, asr #1
    //     0x11334a0: b.eq            #0x11334ac
    //     0x11334a4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x11334a8: stur            x2, [x0, #7]
    // 0x11334ac: LeaveFrame
    //     0x11334ac: mov             SP, fp
    //     0x11334b0: ldp             fp, lr, [SP], #0x10
    // 0x11334b4: ret
    //     0x11334b4: ret             
    // 0x11334b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11334b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11334bc: b               #0x11331bc
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x11672a4, size: 0x13c
    // 0x11672a4: EnterFrame
    //     0x11672a4: stp             fp, lr, [SP, #-0x10]!
    //     0x11672a8: mov             fp, SP
    // 0x11672ac: AllocStack(0x10)
    //     0x11672ac: sub             SP, SP, #0x10
    // 0x11672b0: SetupParameters(dynamic _ /* r1 => r0 */, dynamic _ /* d0 => d0, fp-0x10 */)
    //     0x11672b0: mov             x0, x1
    //     0x11672b4: stur            d0, [fp, #-0x10]
    // 0x11672b8: CheckStackOverflow
    //     0x11672b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11672bc: cmp             SP, x16
    //     0x11672c0: b.ls            #0x11673c8
    // 0x11672c4: cmp             w0, w2
    // 0x11672c8: b.ne            #0x11672d8
    // 0x11672cc: LeaveFrame
    //     0x11672cc: mov             SP, fp
    //     0x11672d0: ldp             fp, lr, [SP], #0x10
    // 0x11672d4: ret
    //     0x11672d4: ret             
    // 0x11672d8: r0 = inline_Allocate_Double()
    //     0x11672d8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x11672dc: add             x0, x0, #0x10
    //     0x11672e0: cmp             x1, x0
    //     0x11672e4: b.ls            #0x11673d0
    //     0x11672e8: str             x0, [THR, #0x60]  ; THR::top
    //     0x11672ec: sub             x0, x0, #0xf
    //     0x11672f0: mov             x1, #0xe19c
    //     0x11672f4: movk            x1, #3, lsl #16
    //     0x11672f8: stur            x1, [x0, #-1]
    // 0x11672fc: dmb             ishst
    // 0x1167300: StoreField: r0->field_7 = d0
    //     0x1167300: stur            d0, [x0, #7]
    // 0x1167304: mov             x3, x0
    // 0x1167308: stur            x0, [fp, #-8]
    // 0x116730c: r1 = Null
    //     0x116730c: mov             x1, NULL
    // 0x1167310: r2 = Null
    //     0x1167310: mov             x2, NULL
    // 0x1167314: r0 = lerp()
    //     0x1167314: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1167318: ldur            x3, [fp, #-8]
    // 0x116731c: r1 = Null
    //     0x116731c: mov             x1, NULL
    // 0x1167320: r2 = Null
    //     0x1167320: mov             x2, NULL
    // 0x1167324: r0 = lerp()
    //     0x1167324: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1167328: ldur            x3, [fp, #-8]
    // 0x116732c: r1 = Null
    //     0x116732c: mov             x1, NULL
    // 0x1167330: r2 = Null
    //     0x1167330: mov             x2, NULL
    // 0x1167334: r0 = lerp()
    //     0x1167334: bl              #0x1140de0  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0x1167338: ldur            d0, [fp, #-0x10]
    // 0x116733c: r1 = Null
    //     0x116733c: mov             x1, NULL
    // 0x1167340: r2 = Null
    //     0x1167340: mov             x2, NULL
    // 0x1167344: r0 = lerp()
    //     0x1167344: bl              #0x1160c48  ; [package:flutter/src/painting/alignment.dart] AlignmentGeometry::lerp
    // 0x1167348: ldur            x3, [fp, #-8]
    // 0x116734c: r1 = Null
    //     0x116734c: mov             x1, NULL
    // 0x1167350: r2 = Null
    //     0x1167350: mov             x2, NULL
    // 0x1167354: r0 = lerp()
    //     0x1167354: bl              #0x1140de0  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0x1167358: ldur            x3, [fp, #-8]
    // 0x116735c: r1 = Null
    //     0x116735c: mov             x1, NULL
    // 0x1167360: r2 = Null
    //     0x1167360: mov             x2, NULL
    // 0x1167364: r0 = lerp()
    //     0x1167364: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1167368: ldur            x3, [fp, #-8]
    // 0x116736c: r1 = Null
    //     0x116736c: mov             x1, NULL
    // 0x1167370: r2 = Null
    //     0x1167370: mov             x2, NULL
    // 0x1167374: r0 = lerp()
    //     0x1167374: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1167378: ldur            x3, [fp, #-8]
    // 0x116737c: r1 = Null
    //     0x116737c: mov             x1, NULL
    // 0x1167380: r2 = Null
    //     0x1167380: mov             x2, NULL
    // 0x1167384: r0 = lerp()
    //     0x1167384: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1167388: ldur            x3, [fp, #-8]
    // 0x116738c: r1 = Null
    //     0x116738c: mov             x1, NULL
    // 0x1167390: r2 = Null
    //     0x1167390: mov             x2, NULL
    // 0x1167394: r0 = lerp()
    //     0x1167394: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1167398: ldur            d0, [fp, #-0x10]
    // 0x116739c: r1 = Null
    //     0x116739c: mov             x1, NULL
    // 0x11673a0: r2 = Null
    //     0x11673a0: mov             x2, NULL
    // 0x11673a4: r0 = lerp()
    //     0x11673a4: bl              #0x115deb4  ; [package:flutter/src/painting/borders.dart] ShapeBorder::lerp
    // 0x11673a8: ldur            d0, [fp, #-0x10]
    // 0x11673ac: r1 = Null
    //     0x11673ac: mov             x1, NULL
    // 0x11673b0: r2 = Null
    //     0x11673b0: mov             x2, NULL
    // 0x11673b4: r0 = lerp()
    //     0x11673b4: bl              #0x115deb4  ; [package:flutter/src/painting/borders.dart] ShapeBorder::lerp
    // 0x11673b8: r0 = ExpansionTileThemeData()
    //     0x11673b8: bl              #0x11673e0  ; AllocateExpansionTileThemeDataStub -> ExpansionTileThemeData (size=0x3c)
    // 0x11673bc: LeaveFrame
    //     0x11673bc: mov             SP, fp
    //     0x11673c0: ldp             fp, lr, [SP], #0x10
    // 0x11673c4: ret
    //     0x11673c4: ret             
    // 0x11673c8: r0 = StackOverflowSharedWithFPURegs()
    //     0x11673c8: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x11673cc: b               #0x11672c4
    // 0x11673d0: SaveReg d0
    //     0x11673d0: str             q0, [SP, #-0x10]!
    // 0x11673d4: r0 = AllocateDouble()
    //     0x11673d4: bl              #0x13df878  ; AllocateDoubleStub
    // 0x11673d8: RestoreReg d0
    //     0x11673d8: ldr             q0, [SP], #0x10
    // 0x11673dc: b               #0x1167300
  }
  _ ==(/* No info */) {
    // ** addr: 0x126c0f0, size: 0x64c
    // 0x126c0f0: EnterFrame
    //     0x126c0f0: stp             fp, lr, [SP, #-0x10]!
    //     0x126c0f4: mov             fp, SP
    // 0x126c0f8: AllocStack(0x28)
    //     0x126c0f8: sub             SP, SP, #0x28
    // 0x126c0fc: CheckStackOverflow
    //     0x126c0fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x126c100: cmp             SP, x16
    //     0x126c104: b.ls            #0x126c734
    // 0x126c108: ldr             x1, [fp, #0x10]
    // 0x126c10c: cmp             w1, NULL
    // 0x126c110: b.ne            #0x126c124
    // 0x126c114: r0 = false
    //     0x126c114: add             x0, NULL, #0x30  ; false
    // 0x126c118: LeaveFrame
    //     0x126c118: mov             SP, fp
    //     0x126c11c: ldp             fp, lr, [SP], #0x10
    // 0x126c120: ret
    //     0x126c120: ret             
    // 0x126c124: ldr             x0, [fp, #0x18]
    // 0x126c128: cmp             w0, w1
    // 0x126c12c: b.ne            #0x126c140
    // 0x126c130: r0 = true
    //     0x126c130: add             x0, NULL, #0x20  ; true
    // 0x126c134: LeaveFrame
    //     0x126c134: mov             SP, fp
    //     0x126c138: ldp             fp, lr, [SP], #0x10
    // 0x126c13c: ret
    //     0x126c13c: ret             
    // 0x126c140: stp             x0, x1, [SP]
    // 0x126c144: r0 = _haveSameRuntimeType()
    //     0x126c144: bl              #0x88249c  ; [dart:core] Object::_haveSameRuntimeType
    // 0x126c148: tbz             w0, #4, #0x126c15c
    // 0x126c14c: r0 = false
    //     0x126c14c: add             x0, NULL, #0x30  ; false
    // 0x126c150: LeaveFrame
    //     0x126c150: mov             SP, fp
    //     0x126c154: ldp             fp, lr, [SP], #0x10
    // 0x126c158: ret
    //     0x126c158: ret             
    // 0x126c15c: ldr             x0, [fp, #0x10]
    // 0x126c160: r2 = 60
    //     0x126c160: mov             x2, #0x3c
    // 0x126c164: branchIfSmi(r0, 0x126c170)
    //     0x126c164: tbz             w0, #0, #0x126c170
    // 0x126c168: r2 = LoadClassIdInstr(r0)
    //     0x126c168: ldur            x2, [x0, #-1]
    //     0x126c16c: ubfx            x2, x2, #0xc, #0x14
    // 0x126c170: stur            x2, [fp, #-8]
    // 0x126c174: r17 = -5152
    //     0x126c174: mov             x17, #-0x1420
    // 0x126c178: add             x16, x2, x17
    // 0x126c17c: cmp             x16, #2
    // 0x126c180: b.hi            #0x126c724
    // 0x126c184: r17 = 5152
    //     0x126c184: mov             x17, #0x1420
    // 0x126c188: cmp             x2, x17
    // 0x126c18c: b.ne            #0x126c1a0
    // 0x126c190: LoadField: r1 = r0->field_1b
    //     0x126c190: ldur            w1, [x0, #0x1b]
    // 0x126c194: DecompressPointer r1
    //     0x126c194: add             x1, x1, HEAP, lsl #32
    // 0x126c198: mov             x2, x1
    // 0x126c19c: b               #0x126c210
    // 0x126c1a0: r17 = 5153
    //     0x126c1a0: mov             x17, #0x1421
    // 0x126c1a4: cmp             x2, x17
    // 0x126c1a8: b.ne            #0x126c1e0
    // 0x126c1ac: mov             x1, x0
    // 0x126c1b0: LoadField: r0 = r1->field_43
    //     0x126c1b0: ldur            w0, [x1, #0x43]
    // 0x126c1b4: DecompressPointer r0
    //     0x126c1b4: add             x0, x0, HEAP, lsl #32
    // 0x126c1b8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126c1bc: cmp             w0, w16
    // 0x126c1c0: b.ne            #0x126c1d0
    // 0x126c1c4: r2 = _colors
    //     0x126c1c4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26390] Field <_ExpansionTileDefaultsM3@747392950._colors@747392950>: late final (offset: 0x44)
    //     0x126c1c8: ldr             x2, [x2, #0x390]
    // 0x126c1cc: r0 = InitLateFinalInstanceField()
    //     0x126c1cc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126c1d0: LoadField: r1 = r0->field_b
    //     0x126c1d0: ldur            w1, [x0, #0xb]
    // 0x126c1d4: DecompressPointer r1
    //     0x126c1d4: add             x1, x1, HEAP, lsl #32
    // 0x126c1d8: mov             x2, x1
    // 0x126c1dc: b               #0x126c210
    // 0x126c1e0: ldr             x1, [fp, #0x10]
    // 0x126c1e4: LoadField: r0 = r1->field_43
    //     0x126c1e4: ldur            w0, [x1, #0x43]
    // 0x126c1e8: DecompressPointer r0
    //     0x126c1e8: add             x0, x0, HEAP, lsl #32
    // 0x126c1ec: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126c1f0: cmp             w0, w16
    // 0x126c1f4: b.ne            #0x126c204
    // 0x126c1f8: r2 = _colorScheme
    //     0x126c1f8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26398] Field <_ExpansionTileDefaultsM2@747392950._colorScheme@747392950>: late final (offset: 0x44)
    //     0x126c1fc: ldr             x2, [x2, #0x398]
    // 0x126c200: r0 = InitLateFinalInstanceField()
    //     0x126c200: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126c204: LoadField: r1 = r0->field_b
    //     0x126c204: ldur            w1, [x0, #0xb]
    // 0x126c208: DecompressPointer r1
    //     0x126c208: add             x1, x1, HEAP, lsl #32
    // 0x126c20c: mov             x2, x1
    // 0x126c210: ldr             x0, [fp, #0x18]
    // 0x126c214: stur            x2, [fp, #-0x18]
    // 0x126c218: r3 = LoadClassIdInstr(r0)
    //     0x126c218: ldur            x3, [x0, #-1]
    //     0x126c21c: ubfx            x3, x3, #0xc, #0x14
    // 0x126c220: stur            x3, [fp, #-0x10]
    // 0x126c224: r17 = 5152
    //     0x126c224: mov             x17, #0x1420
    // 0x126c228: cmp             x3, x17
    // 0x126c22c: b.ne            #0x126c240
    // 0x126c230: LoadField: r1 = r0->field_1b
    //     0x126c230: ldur            w1, [x0, #0x1b]
    // 0x126c234: DecompressPointer r1
    //     0x126c234: add             x1, x1, HEAP, lsl #32
    // 0x126c238: mov             x0, x2
    // 0x126c23c: b               #0x126c2b0
    // 0x126c240: r17 = 5153
    //     0x126c240: mov             x17, #0x1421
    // 0x126c244: cmp             x3, x17
    // 0x126c248: b.ne            #0x126c280
    // 0x126c24c: mov             x1, x0
    // 0x126c250: LoadField: r0 = r1->field_43
    //     0x126c250: ldur            w0, [x1, #0x43]
    // 0x126c254: DecompressPointer r0
    //     0x126c254: add             x0, x0, HEAP, lsl #32
    // 0x126c258: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126c25c: cmp             w0, w16
    // 0x126c260: b.ne            #0x126c270
    // 0x126c264: r2 = _colors
    //     0x126c264: add             x2, PP, #0x26, lsl #12  ; [pp+0x26390] Field <_ExpansionTileDefaultsM3@747392950._colors@747392950>: late final (offset: 0x44)
    //     0x126c268: ldr             x2, [x2, #0x390]
    // 0x126c26c: r0 = InitLateFinalInstanceField()
    //     0x126c26c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126c270: LoadField: r1 = r0->field_b
    //     0x126c270: ldur            w1, [x0, #0xb]
    // 0x126c274: DecompressPointer r1
    //     0x126c274: add             x1, x1, HEAP, lsl #32
    // 0x126c278: ldur            x0, [fp, #-0x18]
    // 0x126c27c: b               #0x126c2b0
    // 0x126c280: ldr             x1, [fp, #0x18]
    // 0x126c284: LoadField: r0 = r1->field_43
    //     0x126c284: ldur            w0, [x1, #0x43]
    // 0x126c288: DecompressPointer r0
    //     0x126c288: add             x0, x0, HEAP, lsl #32
    // 0x126c28c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126c290: cmp             w0, w16
    // 0x126c294: b.ne            #0x126c2a4
    // 0x126c298: r2 = _colorScheme
    //     0x126c298: add             x2, PP, #0x26, lsl #12  ; [pp+0x26398] Field <_ExpansionTileDefaultsM2@747392950._colorScheme@747392950>: late final (offset: 0x44)
    //     0x126c29c: ldr             x2, [x2, #0x398]
    // 0x126c2a0: r0 = InitLateFinalInstanceField()
    //     0x126c2a0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126c2a4: LoadField: r1 = r0->field_b
    //     0x126c2a4: ldur            w1, [x0, #0xb]
    // 0x126c2a8: DecompressPointer r1
    //     0x126c2a8: add             x1, x1, HEAP, lsl #32
    // 0x126c2ac: ldur            x0, [fp, #-0x18]
    // 0x126c2b0: r2 = LoadClassIdInstr(r0)
    //     0x126c2b0: ldur            x2, [x0, #-1]
    //     0x126c2b4: ubfx            x2, x2, #0xc, #0x14
    // 0x126c2b8: stp             x1, x0, [SP]
    // 0x126c2bc: mov             x0, x2
    // 0x126c2c0: mov             lr, x0
    // 0x126c2c4: ldr             lr, [x21, lr, lsl #3]
    // 0x126c2c8: blr             lr
    // 0x126c2cc: tbnz            w0, #4, #0x126c724
    // 0x126c2d0: ldur            x0, [fp, #-8]
    // 0x126c2d4: r17 = 5152
    //     0x126c2d4: mov             x17, #0x1420
    // 0x126c2d8: cmp             x0, x17
    // 0x126c2dc: b.ne            #0x126c2f4
    // 0x126c2e0: ldr             x2, [fp, #0x10]
    // 0x126c2e4: LoadField: r1 = r2->field_1f
    //     0x126c2e4: ldur            w1, [x2, #0x1f]
    // 0x126c2e8: DecompressPointer r1
    //     0x126c2e8: add             x1, x1, HEAP, lsl #32
    // 0x126c2ec: mov             x2, x1
    // 0x126c2f0: b               #0x126c384
    // 0x126c2f4: ldr             x2, [fp, #0x10]
    // 0x126c2f8: r17 = 5153
    //     0x126c2f8: mov             x17, #0x1421
    // 0x126c2fc: cmp             x0, x17
    // 0x126c300: b.ne            #0x126c354
    // 0x126c304: mov             x1, x2
    // 0x126c308: LoadField: r0 = r1->field_43
    //     0x126c308: ldur            w0, [x1, #0x43]
    // 0x126c30c: DecompressPointer r0
    //     0x126c30c: add             x0, x0, HEAP, lsl #32
    // 0x126c310: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126c314: cmp             w0, w16
    // 0x126c318: b.ne            #0x126c328
    // 0x126c31c: r2 = _colors
    //     0x126c31c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26390] Field <_ExpansionTileDefaultsM3@747392950._colors@747392950>: late final (offset: 0x44)
    //     0x126c320: ldr             x2, [x2, #0x390]
    // 0x126c324: r0 = InitLateFinalInstanceField()
    //     0x126c324: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126c328: LoadField: r1 = r0->field_a3
    //     0x126c328: ldur            w1, [x0, #0xa3]
    // 0x126c32c: DecompressPointer r1
    //     0x126c32c: add             x1, x1, HEAP, lsl #32
    // 0x126c330: cmp             w1, NULL
    // 0x126c334: b.ne            #0x126c348
    // 0x126c338: LoadField: r1 = r0->field_7f
    //     0x126c338: ldur            w1, [x0, #0x7f]
    // 0x126c33c: DecompressPointer r1
    //     0x126c33c: add             x1, x1, HEAP, lsl #32
    // 0x126c340: mov             x0, x1
    // 0x126c344: b               #0x126c34c
    // 0x126c348: mov             x0, x1
    // 0x126c34c: mov             x2, x0
    // 0x126c350: b               #0x126c384
    // 0x126c354: ldr             x1, [fp, #0x10]
    // 0x126c358: LoadField: r0 = r1->field_3f
    //     0x126c358: ldur            w0, [x1, #0x3f]
    // 0x126c35c: DecompressPointer r0
    //     0x126c35c: add             x0, x0, HEAP, lsl #32
    // 0x126c360: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126c364: cmp             w0, w16
    // 0x126c368: b.ne            #0x126c378
    // 0x126c36c: r2 = _theme
    //     0x126c36c: add             x2, PP, #0x26, lsl #12  ; [pp+0x263a0] Field <_ExpansionTileDefaultsM2@747392950._theme@747392950>: late final (offset: 0x40)
    //     0x126c370: ldr             x2, [x2, #0x3a0]
    // 0x126c374: r0 = InitLateFinalInstanceField()
    //     0x126c374: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126c378: LoadField: r1 = r0->field_77
    //     0x126c378: ldur            w1, [x0, #0x77]
    // 0x126c37c: DecompressPointer r1
    //     0x126c37c: add             x1, x1, HEAP, lsl #32
    // 0x126c380: mov             x2, x1
    // 0x126c384: ldur            x0, [fp, #-0x10]
    // 0x126c388: stur            x2, [fp, #-0x18]
    // 0x126c38c: r17 = 5152
    //     0x126c38c: mov             x17, #0x1420
    // 0x126c390: cmp             x0, x17
    // 0x126c394: b.ne            #0x126c3ac
    // 0x126c398: ldr             x3, [fp, #0x18]
    // 0x126c39c: LoadField: r1 = r3->field_1f
    //     0x126c39c: ldur            w1, [x3, #0x1f]
    // 0x126c3a0: DecompressPointer r1
    //     0x126c3a0: add             x1, x1, HEAP, lsl #32
    // 0x126c3a4: mov             x0, x2
    // 0x126c3a8: b               #0x126c440
    // 0x126c3ac: ldr             x3, [fp, #0x18]
    // 0x126c3b0: r17 = 5153
    //     0x126c3b0: mov             x17, #0x1421
    // 0x126c3b4: cmp             x0, x17
    // 0x126c3b8: b.ne            #0x126c410
    // 0x126c3bc: mov             x1, x3
    // 0x126c3c0: LoadField: r0 = r1->field_43
    //     0x126c3c0: ldur            w0, [x1, #0x43]
    // 0x126c3c4: DecompressPointer r0
    //     0x126c3c4: add             x0, x0, HEAP, lsl #32
    // 0x126c3c8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126c3cc: cmp             w0, w16
    // 0x126c3d0: b.ne            #0x126c3e0
    // 0x126c3d4: r2 = _colors
    //     0x126c3d4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26390] Field <_ExpansionTileDefaultsM3@747392950._colors@747392950>: late final (offset: 0x44)
    //     0x126c3d8: ldr             x2, [x2, #0x390]
    // 0x126c3dc: r0 = InitLateFinalInstanceField()
    //     0x126c3dc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126c3e0: LoadField: r1 = r0->field_a3
    //     0x126c3e0: ldur            w1, [x0, #0xa3]
    // 0x126c3e4: DecompressPointer r1
    //     0x126c3e4: add             x1, x1, HEAP, lsl #32
    // 0x126c3e8: cmp             w1, NULL
    // 0x126c3ec: b.ne            #0x126c400
    // 0x126c3f0: LoadField: r1 = r0->field_7f
    //     0x126c3f0: ldur            w1, [x0, #0x7f]
    // 0x126c3f4: DecompressPointer r1
    //     0x126c3f4: add             x1, x1, HEAP, lsl #32
    // 0x126c3f8: mov             x0, x1
    // 0x126c3fc: b               #0x126c404
    // 0x126c400: mov             x0, x1
    // 0x126c404: mov             x1, x0
    // 0x126c408: ldur            x0, [fp, #-0x18]
    // 0x126c40c: b               #0x126c440
    // 0x126c410: ldr             x1, [fp, #0x18]
    // 0x126c414: LoadField: r0 = r1->field_3f
    //     0x126c414: ldur            w0, [x1, #0x3f]
    // 0x126c418: DecompressPointer r0
    //     0x126c418: add             x0, x0, HEAP, lsl #32
    // 0x126c41c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126c420: cmp             w0, w16
    // 0x126c424: b.ne            #0x126c434
    // 0x126c428: r2 = _theme
    //     0x126c428: add             x2, PP, #0x26, lsl #12  ; [pp+0x263a0] Field <_ExpansionTileDefaultsM2@747392950._theme@747392950>: late final (offset: 0x40)
    //     0x126c42c: ldr             x2, [x2, #0x3a0]
    // 0x126c430: r0 = InitLateFinalInstanceField()
    //     0x126c430: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126c434: LoadField: r1 = r0->field_77
    //     0x126c434: ldur            w1, [x0, #0x77]
    // 0x126c438: DecompressPointer r1
    //     0x126c438: add             x1, x1, HEAP, lsl #32
    // 0x126c43c: ldur            x0, [fp, #-0x18]
    // 0x126c440: r2 = LoadClassIdInstr(r0)
    //     0x126c440: ldur            x2, [x0, #-1]
    //     0x126c444: ubfx            x2, x2, #0xc, #0x14
    // 0x126c448: stp             x1, x0, [SP]
    // 0x126c44c: mov             x0, x2
    // 0x126c450: mov             lr, x0
    // 0x126c454: ldr             lr, [x21, lr, lsl #3]
    // 0x126c458: blr             lr
    // 0x126c45c: tbnz            w0, #4, #0x126c724
    // 0x126c460: ldur            x0, [fp, #-8]
    // 0x126c464: r17 = 5152
    //     0x126c464: mov             x17, #0x1420
    // 0x126c468: cmp             x0, x17
    // 0x126c46c: b.ne            #0x126c484
    // 0x126c470: ldr             x2, [fp, #0x10]
    // 0x126c474: LoadField: r1 = r2->field_23
    //     0x126c474: ldur            w1, [x2, #0x23]
    // 0x126c478: DecompressPointer r1
    //     0x126c478: add             x1, x1, HEAP, lsl #32
    // 0x126c47c: mov             x2, x1
    // 0x126c480: b               #0x126c4f8
    // 0x126c484: ldr             x2, [fp, #0x10]
    // 0x126c488: r17 = 5153
    //     0x126c488: mov             x17, #0x1421
    // 0x126c48c: cmp             x0, x17
    // 0x126c490: b.ne            #0x126c4c8
    // 0x126c494: mov             x1, x2
    // 0x126c498: LoadField: r0 = r1->field_43
    //     0x126c498: ldur            w0, [x1, #0x43]
    // 0x126c49c: DecompressPointer r0
    //     0x126c49c: add             x0, x0, HEAP, lsl #32
    // 0x126c4a0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126c4a4: cmp             w0, w16
    // 0x126c4a8: b.ne            #0x126c4b8
    // 0x126c4ac: r2 = _colors
    //     0x126c4ac: add             x2, PP, #0x26, lsl #12  ; [pp+0x26390] Field <_ExpansionTileDefaultsM3@747392950._colors@747392950>: late final (offset: 0x44)
    //     0x126c4b0: ldr             x2, [x2, #0x390]
    // 0x126c4b4: r0 = InitLateFinalInstanceField()
    //     0x126c4b4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126c4b8: LoadField: r1 = r0->field_7f
    //     0x126c4b8: ldur            w1, [x0, #0x7f]
    // 0x126c4bc: DecompressPointer r1
    //     0x126c4bc: add             x1, x1, HEAP, lsl #32
    // 0x126c4c0: mov             x2, x1
    // 0x126c4c4: b               #0x126c4f8
    // 0x126c4c8: ldr             x1, [fp, #0x10]
    // 0x126c4cc: LoadField: r0 = r1->field_43
    //     0x126c4cc: ldur            w0, [x1, #0x43]
    // 0x126c4d0: DecompressPointer r0
    //     0x126c4d0: add             x0, x0, HEAP, lsl #32
    // 0x126c4d4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126c4d8: cmp             w0, w16
    // 0x126c4dc: b.ne            #0x126c4ec
    // 0x126c4e0: r2 = _colorScheme
    //     0x126c4e0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26398] Field <_ExpansionTileDefaultsM2@747392950._colorScheme@747392950>: late final (offset: 0x44)
    //     0x126c4e4: ldr             x2, [x2, #0x398]
    // 0x126c4e8: r0 = InitLateFinalInstanceField()
    //     0x126c4e8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126c4ec: LoadField: r1 = r0->field_b
    //     0x126c4ec: ldur            w1, [x0, #0xb]
    // 0x126c4f0: DecompressPointer r1
    //     0x126c4f0: add             x1, x1, HEAP, lsl #32
    // 0x126c4f4: mov             x2, x1
    // 0x126c4f8: ldur            x0, [fp, #-0x10]
    // 0x126c4fc: stur            x2, [fp, #-0x18]
    // 0x126c500: r17 = 5152
    //     0x126c500: mov             x17, #0x1420
    // 0x126c504: cmp             x0, x17
    // 0x126c508: b.ne            #0x126c520
    // 0x126c50c: ldr             x3, [fp, #0x18]
    // 0x126c510: LoadField: r1 = r3->field_23
    //     0x126c510: ldur            w1, [x3, #0x23]
    // 0x126c514: DecompressPointer r1
    //     0x126c514: add             x1, x1, HEAP, lsl #32
    // 0x126c518: mov             x0, x2
    // 0x126c51c: b               #0x126c594
    // 0x126c520: ldr             x3, [fp, #0x18]
    // 0x126c524: r17 = 5153
    //     0x126c524: mov             x17, #0x1421
    // 0x126c528: cmp             x0, x17
    // 0x126c52c: b.ne            #0x126c564
    // 0x126c530: mov             x1, x3
    // 0x126c534: LoadField: r0 = r1->field_43
    //     0x126c534: ldur            w0, [x1, #0x43]
    // 0x126c538: DecompressPointer r0
    //     0x126c538: add             x0, x0, HEAP, lsl #32
    // 0x126c53c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126c540: cmp             w0, w16
    // 0x126c544: b.ne            #0x126c554
    // 0x126c548: r2 = _colors
    //     0x126c548: add             x2, PP, #0x26, lsl #12  ; [pp+0x26390] Field <_ExpansionTileDefaultsM3@747392950._colors@747392950>: late final (offset: 0x44)
    //     0x126c54c: ldr             x2, [x2, #0x390]
    // 0x126c550: r0 = InitLateFinalInstanceField()
    //     0x126c550: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126c554: LoadField: r1 = r0->field_7f
    //     0x126c554: ldur            w1, [x0, #0x7f]
    // 0x126c558: DecompressPointer r1
    //     0x126c558: add             x1, x1, HEAP, lsl #32
    // 0x126c55c: ldur            x0, [fp, #-0x18]
    // 0x126c560: b               #0x126c594
    // 0x126c564: ldr             x1, [fp, #0x18]
    // 0x126c568: LoadField: r0 = r1->field_43
    //     0x126c568: ldur            w0, [x1, #0x43]
    // 0x126c56c: DecompressPointer r0
    //     0x126c56c: add             x0, x0, HEAP, lsl #32
    // 0x126c570: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126c574: cmp             w0, w16
    // 0x126c578: b.ne            #0x126c588
    // 0x126c57c: r2 = _colorScheme
    //     0x126c57c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26398] Field <_ExpansionTileDefaultsM2@747392950._colorScheme@747392950>: late final (offset: 0x44)
    //     0x126c580: ldr             x2, [x2, #0x398]
    // 0x126c584: r0 = InitLateFinalInstanceField()
    //     0x126c584: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126c588: LoadField: r1 = r0->field_b
    //     0x126c588: ldur            w1, [x0, #0xb]
    // 0x126c58c: DecompressPointer r1
    //     0x126c58c: add             x1, x1, HEAP, lsl #32
    // 0x126c590: ldur            x0, [fp, #-0x18]
    // 0x126c594: r2 = LoadClassIdInstr(r0)
    //     0x126c594: ldur            x2, [x0, #-1]
    //     0x126c598: ubfx            x2, x2, #0xc, #0x14
    // 0x126c59c: stp             x1, x0, [SP]
    // 0x126c5a0: mov             x0, x2
    // 0x126c5a4: mov             lr, x0
    // 0x126c5a8: ldr             lr, [x21, lr, lsl #3]
    // 0x126c5ac: blr             lr
    // 0x126c5b0: tbnz            w0, #4, #0x126c724
    // 0x126c5b4: ldur            x0, [fp, #-8]
    // 0x126c5b8: r17 = 5152
    //     0x126c5b8: mov             x17, #0x1420
    // 0x126c5bc: cmp             x0, x17
    // 0x126c5c0: b.ne            #0x126c5d8
    // 0x126c5c4: ldr             x1, [fp, #0x10]
    // 0x126c5c8: LoadField: r0 = r1->field_27
    //     0x126c5c8: ldur            w0, [x1, #0x27]
    // 0x126c5cc: DecompressPointer r0
    //     0x126c5cc: add             x0, x0, HEAP, lsl #32
    // 0x126c5d0: mov             x2, x0
    // 0x126c5d4: b               #0x126c654
    // 0x126c5d8: ldr             x1, [fp, #0x10]
    // 0x126c5dc: r17 = 5153
    //     0x126c5dc: mov             x17, #0x1421
    // 0x126c5e0: cmp             x0, x17
    // 0x126c5e4: b.ne            #0x126c618
    // 0x126c5e8: LoadField: r0 = r1->field_43
    //     0x126c5e8: ldur            w0, [x1, #0x43]
    // 0x126c5ec: DecompressPointer r0
    //     0x126c5ec: add             x0, x0, HEAP, lsl #32
    // 0x126c5f0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126c5f4: cmp             w0, w16
    // 0x126c5f8: b.ne            #0x126c608
    // 0x126c5fc: r2 = _colors
    //     0x126c5fc: add             x2, PP, #0x26, lsl #12  ; [pp+0x26390] Field <_ExpansionTileDefaultsM3@747392950._colors@747392950>: late final (offset: 0x44)
    //     0x126c600: ldr             x2, [x2, #0x390]
    // 0x126c604: r0 = InitLateFinalInstanceField()
    //     0x126c604: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126c608: LoadField: r1 = r0->field_7f
    //     0x126c608: ldur            w1, [x0, #0x7f]
    // 0x126c60c: DecompressPointer r1
    //     0x126c60c: add             x1, x1, HEAP, lsl #32
    // 0x126c610: mov             x2, x1
    // 0x126c614: b               #0x126c654
    // 0x126c618: LoadField: r0 = r1->field_3f
    //     0x126c618: ldur            w0, [x1, #0x3f]
    // 0x126c61c: DecompressPointer r0
    //     0x126c61c: add             x0, x0, HEAP, lsl #32
    // 0x126c620: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126c624: cmp             w0, w16
    // 0x126c628: b.ne            #0x126c638
    // 0x126c62c: r2 = _theme
    //     0x126c62c: add             x2, PP, #0x26, lsl #12  ; [pp+0x263a0] Field <_ExpansionTileDefaultsM2@747392950._theme@747392950>: late final (offset: 0x40)
    //     0x126c630: ldr             x2, [x2, #0x3a0]
    // 0x126c634: r0 = InitLateFinalInstanceField()
    //     0x126c634: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126c638: LoadField: r1 = r0->field_87
    //     0x126c638: ldur            w1, [x0, #0x87]
    // 0x126c63c: DecompressPointer r1
    //     0x126c63c: add             x1, x1, HEAP, lsl #32
    // 0x126c640: LoadField: r0 = r1->field_23
    //     0x126c640: ldur            w0, [x1, #0x23]
    // 0x126c644: DecompressPointer r0
    //     0x126c644: add             x0, x0, HEAP, lsl #32
    // 0x126c648: LoadField: r1 = r0->field_b
    //     0x126c648: ldur            w1, [x0, #0xb]
    // 0x126c64c: DecompressPointer r1
    //     0x126c64c: add             x1, x1, HEAP, lsl #32
    // 0x126c650: mov             x2, x1
    // 0x126c654: ldur            x0, [fp, #-0x10]
    // 0x126c658: stur            x2, [fp, #-0x18]
    // 0x126c65c: r17 = 5152
    //     0x126c65c: mov             x17, #0x1420
    // 0x126c660: cmp             x0, x17
    // 0x126c664: b.ne            #0x126c680
    // 0x126c668: ldr             x1, [fp, #0x18]
    // 0x126c66c: LoadField: r0 = r1->field_27
    //     0x126c66c: ldur            w0, [x1, #0x27]
    // 0x126c670: DecompressPointer r0
    //     0x126c670: add             x0, x0, HEAP, lsl #32
    // 0x126c674: mov             x1, x0
    // 0x126c678: mov             x0, x2
    // 0x126c67c: b               #0x126c6fc
    // 0x126c680: ldr             x1, [fp, #0x18]
    // 0x126c684: r17 = 5153
    //     0x126c684: mov             x17, #0x1421
    // 0x126c688: cmp             x0, x17
    // 0x126c68c: b.ne            #0x126c6c0
    // 0x126c690: LoadField: r0 = r1->field_43
    //     0x126c690: ldur            w0, [x1, #0x43]
    // 0x126c694: DecompressPointer r0
    //     0x126c694: add             x0, x0, HEAP, lsl #32
    // 0x126c698: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126c69c: cmp             w0, w16
    // 0x126c6a0: b.ne            #0x126c6b0
    // 0x126c6a4: r2 = _colors
    //     0x126c6a4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26390] Field <_ExpansionTileDefaultsM3@747392950._colors@747392950>: late final (offset: 0x44)
    //     0x126c6a8: ldr             x2, [x2, #0x390]
    // 0x126c6ac: r0 = InitLateFinalInstanceField()
    //     0x126c6ac: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126c6b0: LoadField: r1 = r0->field_7f
    //     0x126c6b0: ldur            w1, [x0, #0x7f]
    // 0x126c6b4: DecompressPointer r1
    //     0x126c6b4: add             x1, x1, HEAP, lsl #32
    // 0x126c6b8: ldur            x0, [fp, #-0x18]
    // 0x126c6bc: b               #0x126c6fc
    // 0x126c6c0: LoadField: r0 = r1->field_3f
    //     0x126c6c0: ldur            w0, [x1, #0x3f]
    // 0x126c6c4: DecompressPointer r0
    //     0x126c6c4: add             x0, x0, HEAP, lsl #32
    // 0x126c6c8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x126c6cc: cmp             w0, w16
    // 0x126c6d0: b.ne            #0x126c6e0
    // 0x126c6d4: r2 = _theme
    //     0x126c6d4: add             x2, PP, #0x26, lsl #12  ; [pp+0x263a0] Field <_ExpansionTileDefaultsM2@747392950._theme@747392950>: late final (offset: 0x40)
    //     0x126c6d8: ldr             x2, [x2, #0x3a0]
    // 0x126c6dc: r0 = InitLateFinalInstanceField()
    //     0x126c6dc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x126c6e0: LoadField: r1 = r0->field_87
    //     0x126c6e0: ldur            w1, [x0, #0x87]
    // 0x126c6e4: DecompressPointer r1
    //     0x126c6e4: add             x1, x1, HEAP, lsl #32
    // 0x126c6e8: LoadField: r0 = r1->field_23
    //     0x126c6e8: ldur            w0, [x1, #0x23]
    // 0x126c6ec: DecompressPointer r0
    //     0x126c6ec: add             x0, x0, HEAP, lsl #32
    // 0x126c6f0: LoadField: r1 = r0->field_b
    //     0x126c6f0: ldur            w1, [x0, #0xb]
    // 0x126c6f4: DecompressPointer r1
    //     0x126c6f4: add             x1, x1, HEAP, lsl #32
    // 0x126c6f8: ldur            x0, [fp, #-0x18]
    // 0x126c6fc: r2 = LoadClassIdInstr(r0)
    //     0x126c6fc: ldur            x2, [x0, #-1]
    //     0x126c700: ubfx            x2, x2, #0xc, #0x14
    // 0x126c704: stp             x1, x0, [SP]
    // 0x126c708: mov             x0, x2
    // 0x126c70c: mov             lr, x0
    // 0x126c710: ldr             lr, [x21, lr, lsl #3]
    // 0x126c714: blr             lr
    // 0x126c718: tbnz            w0, #4, #0x126c724
    // 0x126c71c: r0 = true
    //     0x126c71c: add             x0, NULL, #0x20  ; true
    // 0x126c720: b               #0x126c728
    // 0x126c724: r0 = false
    //     0x126c724: add             x0, NULL, #0x30  ; false
    // 0x126c728: LeaveFrame
    //     0x126c728: mov             SP, fp
    //     0x126c72c: ldp             fp, lr, [SP], #0x10
    // 0x126c730: ret
    //     0x126c730: ret             
    // 0x126c734: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x126c734: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x126c738: b               #0x126c108
  }
}

// class id: 6846, size: 0x10, field offset: 0x10
//   const constructor, 
abstract class ExpansionTileTheme extends InheritedTheme {

  static _ of(/* No info */) {
    // ** addr: 0xef50b8, size: 0x58
    // 0xef50b8: EnterFrame
    //     0xef50b8: stp             fp, lr, [SP, #-0x10]!
    //     0xef50bc: mov             fp, SP
    // 0xef50c0: AllocStack(0x18)
    //     0xef50c0: sub             SP, SP, #0x18
    // 0xef50c4: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0xef50c4: stur            x1, [fp, #-8]
    // 0xef50c8: CheckStackOverflow
    //     0xef50c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef50cc: cmp             SP, x16
    //     0xef50d0: b.ls            #0xef5108
    // 0xef50d4: r16 = <ExpansionTileTheme>
    //     0xef50d4: add             x16, PP, #0x95, lsl #12  ; [pp+0x95dc8] TypeArguments: <ExpansionTileTheme>
    //     0xef50d8: ldr             x16, [x16, #0xdc8]
    // 0xef50dc: stp             x1, x16, [SP]
    // 0xef50e0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xef50e0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xef50e4: r0 = dependOnInheritedWidgetOfExactType()
    //     0xef50e4: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xef50e8: ldur            x1, [fp, #-8]
    // 0xef50ec: r0 = of()
    //     0xef50ec: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xef50f0: LoadField: r1 = r0->field_db
    //     0xef50f0: ldur            w1, [x0, #0xdb]
    // 0xef50f4: DecompressPointer r1
    //     0xef50f4: add             x1, x1, HEAP, lsl #32
    // 0xef50f8: mov             x0, x1
    // 0xef50fc: LeaveFrame
    //     0xef50fc: mov             SP, fp
    //     0xef5100: ldp             fp, lr, [SP], #0x10
    // 0xef5104: ret
    //     0xef5104: ret             
    // 0xef5108: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef5108: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef510c: b               #0xef50d4
  }
}
