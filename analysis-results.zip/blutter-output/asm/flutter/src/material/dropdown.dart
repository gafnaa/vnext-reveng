// lib: , url: package:flutter/src/material/dropdown.dart

// class id: 1048886, size: 0x8
class :: {
}

// class id: 2645, size: 0xe4, field offset: 0x98
class _DropdownRoute<C1X0> extends PopupRoute<C1X0> {

  _ _dismiss(/* No info */) {
    // ** addr: 0xd1e944, size: 0x70
    // 0xd1e944: EnterFrame
    //     0xd1e944: stp             fp, lr, [SP, #-0x10]!
    //     0xd1e948: mov             fp, SP
    // 0xd1e94c: AllocStack(0x20)
    //     0xd1e94c: sub             SP, SP, #0x20
    // 0xd1e950: SetupParameters(_DropdownRoute<C1X0> this /* r1 => r0, fp-0x8 */)
    //     0xd1e950: mov             x0, x1
    //     0xd1e954: stur            x1, [fp, #-8]
    // 0xd1e958: CheckStackOverflow
    //     0xd1e958: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd1e95c: cmp             SP, x16
    //     0xd1e960: b.ls            #0xd1e9ac
    // 0xd1e964: mov             x1, x0
    // 0xd1e968: r0 = isActive()
    //     0xd1e968: bl              #0xbae0e0  ; [package:flutter/src/widgets/navigator.dart] Route::isActive
    // 0xd1e96c: tbnz            w0, #4, #0xd1e99c
    // 0xd1e970: ldur            x0, [fp, #-8]
    // 0xd1e974: LoadField: r1 = r0->field_f
    //     0xd1e974: ldur            w1, [x0, #0xf]
    // 0xd1e978: DecompressPointer r1
    //     0xd1e978: add             x1, x1, HEAP, lsl #32
    // 0xd1e97c: cmp             w1, NULL
    // 0xd1e980: b.eq            #0xd1e99c
    // 0xd1e984: LoadField: r2 = r0->field_7
    //     0xd1e984: ldur            w2, [x0, #7]
    // 0xd1e988: DecompressPointer r2
    //     0xd1e988: add             x2, x2, HEAP, lsl #32
    // 0xd1e98c: stp             x1, x2, [SP, #8]
    // 0xd1e990: str             x0, [SP]
    // 0xd1e994: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xd1e994: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xd1e998: r0 = removeRoute()
    //     0xd1e998: bl              #0xd1e9b4  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::removeRoute
    // 0xd1e99c: r0 = Null
    //     0xd1e99c: mov             x0, NULL
    // 0xd1e9a0: LeaveFrame
    //     0xd1e9a0: mov             SP, fp
    //     0xd1e9a4: ldp             fp, lr, [SP], #0x10
    // 0xd1e9a8: ret
    //     0xd1e9a8: ret             
    // 0xd1e9ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1e9ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd1e9b0: b               #0xd1e964
  }
  _ _DropdownRoute(/* No info */) {
    // ** addr: 0xd1f460, size: 0x294
    // 0xd1f460: EnterFrame
    //     0xd1f460: stp             fp, lr, [SP, #-0x10]!
    //     0xd1f464: mov             fp, SP
    // 0xd1f468: AllocStack(0x18)
    //     0xd1f468: sub             SP, SP, #0x18
    // 0xd1f46c: r9 = Instance_EdgeInsets
    //     0xd1f46c: add             x9, PP, #0x26, lsl #12  ; [pp+0x26510] Obj!EdgeInsets@129cdb1
    //     0xd1f470: ldr             x9, [x9, #0x510]
    // 0xd1f474: r8 = true
    //     0xd1f474: add             x8, NULL, #0x20  ; true
    // 0xd1f478: r4 = 8
    //     0xd1f478: mov             x4, #8
    // 0xd1f47c: stur            x1, [fp, #-0x10]
    // 0xd1f480: mov             x16, x7
    // 0xd1f484: mov             x7, x1
    // 0xd1f488: mov             x1, x16
    // 0xd1f48c: mov             x16, x6
    // 0xd1f490: mov             x6, x2
    // 0xd1f494: mov             x2, x16
    // 0xd1f498: mov             x16, x5
    // 0xd1f49c: mov             x5, x3
    // 0xd1f4a0: mov             x3, x16
    // 0xd1f4a4: CheckStackOverflow
    //     0xd1f4a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd1f4a8: cmp             SP, x16
    //     0xd1f4ac: b.ls            #0xd1f6c8
    // 0xd1f4b0: ldr             x0, [fp, #0x28]
    // 0xd1f4b4: StoreField: r7->field_97 = r0
    //     0xd1f4b4: stur            w0, [x7, #0x97]
    //     0xd1f4b8: ldurb           w16, [x7, #-1]
    //     0xd1f4bc: ldurb           w17, [x0, #-1]
    //     0xd1f4c0: and             x16, x17, x16, lsr #2
    //     0xd1f4c4: tst             x16, HEAP, lsr #32
    //     0xd1f4c8: b.eq            #0xd1f4d0
    //     0xd1f4cc: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xd1f4d0: StoreField: r7->field_9b = r9
    //     0xd1f4d0: stur            w9, [x7, #0x9b]
    // 0xd1f4d4: mov             x0, x5
    // 0xd1f4d8: StoreField: r7->field_9f = r0
    //     0xd1f4d8: stur            w0, [x7, #0x9f]
    //     0xd1f4dc: ldurb           w16, [x7, #-1]
    //     0xd1f4e0: ldurb           w17, [x0, #-1]
    //     0xd1f4e4: and             x16, x17, x16, lsr #2
    //     0xd1f4e8: tst             x16, HEAP, lsr #32
    //     0xd1f4ec: b.eq            #0xd1f4f4
    //     0xd1f4f0: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xd1f4f4: ldr             x0, [fp, #0x18]
    // 0xd1f4f8: StoreField: r7->field_a3 = r0
    //     0xd1f4f8: stur            x0, [x7, #0xa3]
    // 0xd1f4fc: StoreField: r7->field_ab = r4
    //     0xd1f4fc: stur            x4, [x7, #0xab]
    // 0xd1f500: mov             x0, x3
    // 0xd1f504: StoreField: r7->field_b3 = r0
    //     0xd1f504: stur            w0, [x7, #0xb3]
    //     0xd1f508: ldurb           w16, [x7, #-1]
    //     0xd1f50c: ldurb           w17, [x0, #-1]
    //     0xd1f510: and             x16, x17, x16, lsr #2
    //     0xd1f514: tst             x16, HEAP, lsr #32
    //     0xd1f518: b.eq            #0xd1f520
    //     0xd1f51c: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xd1f520: ldr             x0, [fp, #0x10]
    // 0xd1f524: StoreField: r7->field_b7 = r0
    //     0xd1f524: stur            w0, [x7, #0xb7]
    //     0xd1f528: ldurb           w16, [x7, #-1]
    //     0xd1f52c: ldurb           w17, [x0, #-1]
    //     0xd1f530: and             x16, x17, x16, lsr #2
    //     0xd1f534: tst             x16, HEAP, lsr #32
    //     0xd1f538: b.eq            #0xd1f540
    //     0xd1f53c: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xd1f540: mov             x0, x6
    // 0xd1f544: StoreField: r7->field_df = r0
    //     0xd1f544: stur            w0, [x7, #0xdf]
    //     0xd1f548: ldurb           w16, [x7, #-1]
    //     0xd1f54c: ldurb           w17, [x0, #-1]
    //     0xd1f550: and             x16, x17, x16, lsr #2
    //     0xd1f554: tst             x16, HEAP, lsr #32
    //     0xd1f558: b.eq            #0xd1f560
    //     0xd1f55c: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xd1f560: mov             x0, x1
    // 0xd1f564: StoreField: r7->field_bb = r0
    //     0xd1f564: stur            w0, [x7, #0xbb]
    //     0xd1f568: ldurb           w16, [x7, #-1]
    //     0xd1f56c: ldurb           w17, [x0, #-1]
    //     0xd1f570: and             x16, x17, x16, lsr #2
    //     0xd1f574: tst             x16, HEAP, lsr #32
    //     0xd1f578: b.eq            #0xd1f580
    //     0xd1f57c: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xd1f580: mov             x0, x2
    // 0xd1f584: StoreField: r7->field_c3 = r0
    //     0xd1f584: stur            w0, [x7, #0xc3]
    //     0xd1f588: ldurb           w16, [x7, #-1]
    //     0xd1f58c: ldurb           w17, [x0, #-1]
    //     0xd1f590: and             x16, x17, x16, lsr #2
    //     0xd1f594: tst             x16, HEAP, lsr #32
    //     0xd1f598: b.eq            #0xd1f5a0
    //     0xd1f59c: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xd1f5a0: ldr             x0, [fp, #0x20]
    // 0xd1f5a4: StoreField: r7->field_c7 = r0
    //     0xd1f5a4: stur            w0, [x7, #0xc7]
    //     0xd1f5a8: ldurb           w16, [x7, #-1]
    //     0xd1f5ac: ldurb           w17, [x0, #-1]
    //     0xd1f5b0: and             x16, x17, x16, lsr #2
    //     0xd1f5b4: tst             x16, HEAP, lsr #32
    //     0xd1f5b8: b.eq            #0xd1f5c0
    //     0xd1f5bc: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xd1f5c0: StoreField: r7->field_cb = r8
    //     0xd1f5c0: stur            w8, [x7, #0xcb]
    // 0xd1f5c4: StoreField: r7->field_db = r8
    //     0xd1f5c4: stur            w8, [x7, #0xdb]
    // 0xd1f5c8: ldr             x0, [fp, #0x28]
    // 0xd1f5cc: LoadField: r3 = r0->field_b
    //     0xd1f5cc: ldur            w3, [x0, #0xb]
    // 0xd1f5d0: stur            x3, [fp, #-8]
    // 0xd1f5d4: cmp             w1, NULL
    // 0xd1f5d8: b.ne            #0xd1f5e4
    // 0xd1f5dc: d0 = 48.000000
    //     0xd1f5dc: ldr             d0, [PP, #0x5650]  ; [pp+0x5650] IMM: double(48) from 0x4048000000000000
    // 0xd1f5e0: b               #0xd1f5e8
    // 0xd1f5e4: LoadField: d0 = r1->field_7
    //     0xd1f5e4: ldur            d0, [x1, #7]
    // 0xd1f5e8: mov             x2, x3
    // 0xd1f5ec: stur            d0, [fp, #-0x18]
    // 0xd1f5f0: r1 = <double>
    //     0xd1f5f0: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd1f5f4: r0 = AllocateArray()
    //     0xd1f5f4: bl              #0x13df928  ; AllocateArrayStub
    // 0xd1f5f8: mov             x2, x0
    // 0xd1f5fc: ldur            x0, [fp, #-8]
    // 0xd1f600: r3 = LoadInt32Instr(r0)
    //     0xd1f600: sbfx            x3, x0, #1, #0x1f
    // 0xd1f604: ldur            d0, [fp, #-0x18]
    // 0xd1f608: r4 = inline_Allocate_Double()
    //     0xd1f608: ldp             x4, x0, [THR, #0x60]  ; THR::top
    //     0xd1f60c: add             x4, x4, #0x10
    //     0xd1f610: cmp             x0, x4
    //     0xd1f614: b.ls            #0xd1f6d0
    //     0xd1f618: str             x4, [THR, #0x60]  ; THR::top
    //     0xd1f61c: sub             x4, x4, #0xf
    //     0xd1f620: mov             x0, #0xe19c
    //     0xd1f624: movk            x0, #3, lsl #16
    //     0xd1f628: stur            x0, [x4, #-1]
    // 0xd1f62c: dmb             ishst
    // 0xd1f630: StoreField: r4->field_7 = d0
    //     0xd1f630: stur            d0, [x4, #7]
    // 0xd1f634: r5 = 0
    //     0xd1f634: mov             x5, #0
    // 0xd1f638: CheckStackOverflow
    //     0xd1f638: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd1f63c: cmp             SP, x16
    //     0xd1f640: b.ls            #0xd1f6ec
    // 0xd1f644: cmp             x5, x3
    // 0xd1f648: b.ge            #0xd1f688
    // 0xd1f64c: mov             x1, x2
    // 0xd1f650: mov             x0, x4
    // 0xd1f654: ArrayStore: r1[r5] = r0  ; List_4
    //     0xd1f654: add             x25, x1, x5, lsl #2
    //     0xd1f658: add             x25, x25, #0xf
    //     0xd1f65c: str             w0, [x25]
    //     0xd1f660: tbz             w0, #0, #0xd1f67c
    //     0xd1f664: ldurb           w16, [x1, #-1]
    //     0xd1f668: ldurb           w17, [x0, #-1]
    //     0xd1f66c: and             x16, x17, x16, lsr #2
    //     0xd1f670: tst             x16, HEAP, lsr #32
    //     0xd1f674: b.eq            #0xd1f67c
    //     0xd1f678: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd1f67c: add             x0, x5, #1
    // 0xd1f680: mov             x5, x0
    // 0xd1f684: b               #0xd1f638
    // 0xd1f688: ldur            x1, [fp, #-0x10]
    // 0xd1f68c: mov             x0, x2
    // 0xd1f690: StoreField: r1->field_d7 = r0
    //     0xd1f690: stur            w0, [x1, #0xd7]
    //     0xd1f694: ldurb           w16, [x1, #-1]
    //     0xd1f698: ldurb           w17, [x0, #-1]
    //     0xd1f69c: and             x16, x17, x16, lsr #2
    //     0xd1f6a0: tst             x16, HEAP, lsr #32
    //     0xd1f6a4: b.eq            #0xd1f6ac
    //     0xd1f6a8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd1f6ac: r2 = Null
    //     0xd1f6ac: mov             x2, NULL
    // 0xd1f6b0: r3 = Null
    //     0xd1f6b0: mov             x3, NULL
    // 0xd1f6b4: r0 = ModalRoute()
    //     0xd1f6b4: bl              #0x8e04e0  ; [package:flutter/src/widgets/routes.dart] ModalRoute::ModalRoute
    // 0xd1f6b8: r0 = Null
    //     0xd1f6b8: mov             x0, NULL
    // 0xd1f6bc: LeaveFrame
    //     0xd1f6bc: mov             SP, fp
    //     0xd1f6c0: ldp             fp, lr, [SP], #0x10
    // 0xd1f6c4: ret
    //     0xd1f6c4: ret             
    // 0xd1f6c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1f6c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd1f6cc: b               #0xd1f4b0
    // 0xd1f6d0: SaveReg d0
    //     0xd1f6d0: str             q0, [SP, #-0x10]!
    // 0xd1f6d4: stp             x2, x3, [SP, #-0x10]!
    // 0xd1f6d8: r0 = AllocateDouble()
    //     0xd1f6d8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd1f6dc: mov             x4, x0
    // 0xd1f6e0: ldp             x2, x3, [SP], #0x10
    // 0xd1f6e4: RestoreReg d0
    //     0xd1f6e4: ldr             q0, [SP], #0x10
    // 0xd1f6e8: b               #0xd1f630
    // 0xd1f6ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1f6ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd1f6f0: b               #0xd1f644
  }
  _ getMenuLimits(/* No info */) {
    // ** addr: 0xdf55fc, size: 0x28c
    // 0xdf55fc: EnterFrame
    //     0xdf55fc: stp             fp, lr, [SP, #-0x10]!
    //     0xdf5600: mov             fp, SP
    // 0xdf5604: AllocStack(0x60)
    //     0xdf5604: sub             SP, SP, #0x60
    // 0xdf5608: d1 = 96.000000
    //     0xdf5608: add             x17, PP, #0x13, lsl #12  ; [pp+0x13580] IMM: double(96) from 0x4058000000000000
    //     0xdf560c: ldr             d1, [x17, #0x580]
    // 0xdf5610: mov             x0, x2
    // 0xdf5614: mov             x2, x3
    // 0xdf5618: mov             x3, x1
    // 0xdf561c: stur            x1, [fp, #-8]
    // 0xdf5620: stur            d0, [fp, #-0x40]
    // 0xdf5624: CheckStackOverflow
    //     0xdf5624: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf5628: cmp             SP, x16
    //     0xdf562c: b.ls            #0xdf587c
    // 0xdf5630: fsub            d2, d0, d1
    // 0xdf5634: LoadField: r1 = r3->field_c7
    //     0xdf5634: ldur            w1, [x3, #0xc7]
    // 0xdf5638: DecompressPointer r1
    //     0xdf5638: add             x1, x1, HEAP, lsl #32
    // 0xdf563c: cmp             w1, NULL
    // 0xdf5640: b.eq            #0xdf5654
    // 0xdf5644: LoadField: d1 = r1->field_7
    //     0xdf5644: ldur            d1, [x1, #7]
    // 0xdf5648: fmin            v3.2d, v2.2d, v1.2d
    // 0xdf564c: mov             v1.16b, v3.16b
    // 0xdf5650: b               #0xdf5658
    // 0xdf5654: mov             v1.16b, v2.16b
    // 0xdf5658: stur            d1, [fp, #-0x38]
    // 0xdf565c: LoadField: d2 = r0->field_f
    //     0xdf565c: ldur            d2, [x0, #0xf]
    // 0xdf5660: stur            d2, [fp, #-0x30]
    // 0xdf5664: LoadField: d3 = r0->field_1f
    //     0xdf5664: ldur            d3, [x0, #0x1f]
    // 0xdf5668: stur            d3, [fp, #-0x28]
    // 0xdf566c: fmin            v4.2d, v3.2d, v0.2d
    // 0xdf5670: mov             x1, x3
    // 0xdf5674: stur            d4, [fp, #-0x20]
    // 0xdf5678: r0 = getItemOffset()
    //     0xdf5678: bl              #0xdf5894  ; [package:flutter/src/material/dropdown.dart] _DropdownRoute::getItemOffset
    // 0xdf567c: mov             v2.16b, v0.16b
    // 0xdf5680: ldur            d1, [fp, #-0x30]
    // 0xdf5684: d0 = 48.000000
    //     0xdf5684: ldr             d0, [PP, #0x5650]  ; [pp+0x5650] IMM: double(48) from 0x4048000000000000
    // 0xdf5688: stur            d2, [fp, #-0x58]
    // 0xdf568c: fmin            v3.2d, v0.2d, v1.2d
    // 0xdf5690: ldur            d4, [fp, #-0x40]
    // 0xdf5694: stur            d3, [fp, #-0x50]
    // 0xdf5698: fsub            d5, d4, d0
    // 0xdf569c: ldur            d0, [fp, #-0x20]
    // 0xdf56a0: fmax            v4.2d, v5.2d, v0.2d
    // 0xdf56a4: stur            d4, [fp, #-0x48]
    // 0xdf56a8: fsub            d5, d1, d2
    // 0xdf56ac: ldur            x2, [fp, #-8]
    // 0xdf56b0: LoadField: r3 = r2->field_d7
    //     0xdf56b0: ldur            w3, [x2, #0xd7]
    // 0xdf56b4: DecompressPointer r3
    //     0xdf56b4: add             x3, x3, HEAP, lsl #32
    // 0xdf56b8: stur            x3, [fp, #-0x18]
    // 0xdf56bc: LoadField: r4 = r2->field_a3
    //     0xdf56bc: ldur            x4, [x2, #0xa3]
    // 0xdf56c0: stur            x4, [fp, #-0x10]
    // 0xdf56c4: LoadField: r0 = r3->field_b
    //     0xdf56c4: ldur            w0, [x3, #0xb]
    // 0xdf56c8: r1 = LoadInt32Instr(r0)
    //     0xdf56c8: sbfx            x1, x0, #1, #0x1f
    // 0xdf56cc: mov             x0, x1
    // 0xdf56d0: mov             x1, x4
    // 0xdf56d4: cmp             x1, x0
    // 0xdf56d8: b.hs            #0xdf5884
    // 0xdf56dc: ArrayLoad: r0 = r3[r4]  ; Unknown_4
    //     0xdf56dc: add             x16, x3, x4, lsl #2
    //     0xdf56e0: ldur            w0, [x16, #0xf]
    // 0xdf56e4: DecompressPointer r0
    //     0xdf56e4: add             x0, x0, HEAP, lsl #32
    // 0xdf56e8: ldur            d6, [fp, #-0x28]
    // 0xdf56ec: fsub            d7, d6, d1
    // 0xdf56f0: stur            d7, [fp, #-0x40]
    // 0xdf56f4: LoadField: d6 = r0->field_7
    //     0xdf56f4: ldur            d6, [x0, #7]
    // 0xdf56f8: fsub            d8, d6, d7
    // 0xdf56fc: d6 = 2.000000
    //     0xdf56fc: fmov            d6, #2.00000000
    // 0xdf5700: fdiv            d9, d8, d6
    // 0xdf5704: fsub            d8, d5, d9
    // 0xdf5708: stur            d8, [fp, #-0x28]
    // 0xdf570c: r1 = Instance_EdgeInsets
    //     0xdf570c: add             x1, PP, #0x26, lsl #12  ; [pp+0x262d8] Obj!EdgeInsets@129d5f1
    //     0xdf5710: ldr             x1, [x1, #0x2d8]
    // 0xdf5714: r0 = vertical()
    //     0xdf5714: bl              #0xb1730c  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::vertical
    // 0xdf5718: ldur            x0, [fp, #-8]
    // 0xdf571c: stur            d0, [fp, #-0x60]
    // 0xdf5720: LoadField: r1 = r0->field_97
    //     0xdf5720: ldur            w1, [x0, #0x97]
    // 0xdf5724: DecompressPointer r1
    //     0xdf5724: add             x1, x1, HEAP, lsl #32
    // 0xdf5728: LoadField: r0 = r1->field_b
    //     0xdf5728: ldur            w0, [x1, #0xb]
    // 0xdf572c: cbz             w0, #0xdf5760
    // 0xdf5730: r1 = Function '<anonymous closure>':.
    //     0xdf5730: add             x1, PP, #0xcd, lsl #12  ; [pp+0xcd570] AnonymousClosure: (0xade914), in [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_reconfigure (0xade978)
    //     0xdf5734: ldr             x1, [x1, #0x570]
    // 0xdf5738: r2 = Null
    //     0xdf5738: mov             x2, NULL
    // 0xdf573c: r0 = AllocateClosure()
    //     0xdf573c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf5740: ldur            x1, [fp, #-0x18]
    // 0xdf5744: mov             x2, x0
    // 0xdf5748: r0 = reduce()
    //     0xdf5748: bl              #0xb15d7c  ; [dart:collection] ListBase::reduce
    // 0xdf574c: LoadField: d0 = r0->field_7
    //     0xdf574c: ldur            d0, [x0, #7]
    // 0xdf5750: ldur            d1, [fp, #-0x60]
    // 0xdf5754: fadd            d2, d1, d0
    // 0xdf5758: mov             v3.16b, v2.16b
    // 0xdf575c: b               #0xdf5768
    // 0xdf5760: mov             v1.16b, v0.16b
    // 0xdf5764: mov             v3.16b, v1.16b
    // 0xdf5768: ldur            d2, [fp, #-0x38]
    // 0xdf576c: ldur            d1, [fp, #-0x28]
    // 0xdf5770: ldur            d0, [fp, #-0x50]
    // 0xdf5774: fmin            v4.2d, v2.2d, v3.2d
    // 0xdf5778: fadd            d5, d1, d4
    // 0xdf577c: fcmp            d0, d1
    // 0xdf5780: b.le            #0xdf579c
    // 0xdf5784: ldur            d6, [fp, #-0x30]
    // 0xdf5788: fmin            v1.2d, v6.2d, v0.2d
    // 0xdf578c: fadd            d0, d1, d4
    // 0xdf5790: mov             v5.16b, v1.16b
    // 0xdf5794: mov             v1.16b, v0.16b
    // 0xdf5798: b               #0xdf57ac
    // 0xdf579c: ldur            d6, [fp, #-0x30]
    // 0xdf57a0: mov             v31.16b, v5.16b
    // 0xdf57a4: mov             v5.16b, v1.16b
    // 0xdf57a8: mov             v1.16b, v31.16b
    // 0xdf57ac: ldur            d0, [fp, #-0x48]
    // 0xdf57b0: fcmp            d1, d0
    // 0xdf57b4: b.le            #0xdf57d0
    // 0xdf57b8: ldur            d7, [fp, #-0x20]
    // 0xdf57bc: fmax            v1.2d, v7.2d, v0.2d
    // 0xdf57c0: fsub            d0, d1, d4
    // 0xdf57c4: mov             v8.16b, v0.16b
    // 0xdf57c8: mov             v5.16b, v1.16b
    // 0xdf57cc: b               #0xdf57dc
    // 0xdf57d0: ldur            d7, [fp, #-0x20]
    // 0xdf57d4: mov             v8.16b, v5.16b
    // 0xdf57d8: mov             v5.16b, v1.16b
    // 0xdf57dc: ldur            x0, [fp, #-0x18]
    // 0xdf57e0: ldur            x1, [fp, #-0x10]
    // 0xdf57e4: ldur            d0, [fp, #-0x40]
    // 0xdf57e8: d1 = 2.000000
    //     0xdf57e8: fmov            d1, #2.00000000
    // 0xdf57ec: ArrayLoad: r2 = r0[r1]  ; Unknown_4
    //     0xdf57ec: add             x16, x0, x1, lsl #2
    //     0xdf57f0: ldur            w2, [x16, #0xf]
    // 0xdf57f4: DecompressPointer r2
    //     0xdf57f4: add             x2, x2, HEAP, lsl #32
    // 0xdf57f8: LoadField: d9 = r2->field_7
    //     0xdf57f8: ldur            d9, [x2, #7]
    // 0xdf57fc: fdiv            d10, d9, d1
    // 0xdf5800: fsub            d9, d5, d10
    // 0xdf5804: fdiv            d5, d0, d1
    // 0xdf5808: fsub            d0, d7, d5
    // 0xdf580c: fcmp            d0, d9
    // 0xdf5810: b.le            #0xdf5820
    // 0xdf5814: fadd            d1, d0, d10
    // 0xdf5818: fsub            d0, d1, d4
    // 0xdf581c: b               #0xdf5824
    // 0xdf5820: mov             v0.16b, v8.16b
    // 0xdf5824: stur            d0, [fp, #-0x28]
    // 0xdf5828: fcmp            d3, d2
    // 0xdf582c: b.le            #0xdf5854
    // 0xdf5830: ldur            d1, [fp, #-0x58]
    // 0xdf5834: d2 = 0.000000
    //     0xdf5834: eor             v2.16b, v2.16b, v2.16b
    // 0xdf5838: fsub            d5, d6, d0
    // 0xdf583c: fsub            d6, d1, d5
    // 0xdf5840: fmax            v1.2d, v2.2d, v6.2d
    // 0xdf5844: fsub            d2, d3, d4
    // 0xdf5848: fmin            v3.2d, v1.2d, v2.2d
    // 0xdf584c: mov             v1.16b, v3.16b
    // 0xdf5850: b               #0xdf5858
    // 0xdf5854: d1 = 0.000000
    //     0xdf5854: eor             v1.16b, v1.16b, v1.16b
    // 0xdf5858: stur            d1, [fp, #-0x20]
    // 0xdf585c: r0 = _MenuLimits()
    //     0xdf585c: bl              #0xdf5888  ; Allocate_MenuLimitsStub -> _MenuLimits (size=0x18)
    // 0xdf5860: ldur            d0, [fp, #-0x28]
    // 0xdf5864: StoreField: r0->field_7 = d0
    //     0xdf5864: stur            d0, [x0, #7]
    // 0xdf5868: ldur            d0, [fp, #-0x20]
    // 0xdf586c: StoreField: r0->field_f = d0
    //     0xdf586c: stur            d0, [x0, #0xf]
    // 0xdf5870: LeaveFrame
    //     0xdf5870: mov             SP, fp
    //     0xdf5874: ldp             fp, lr, [SP], #0x10
    // 0xdf5878: ret
    //     0xdf5878: ret             
    // 0xdf587c: r0 = StackOverflowSharedWithFPURegs()
    //     0xdf587c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xdf5880: b               #0xdf5630
    // 0xdf5884: r0 = RangeErrorSharedWithFPURegs()
    //     0xdf5884: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
  }
  _ getItemOffset(/* No info */) {
    // ** addr: 0xdf5894, size: 0xc8
    // 0xdf5894: EnterFrame
    //     0xdf5894: stp             fp, lr, [SP, #-0x10]!
    //     0xdf5898: mov             fp, SP
    // 0xdf589c: AllocStack(0x18)
    //     0xdf589c: sub             SP, SP, #0x18
    // 0xdf58a0: r0 = Instance_EdgeInsets
    //     0xdf58a0: add             x0, PP, #0x26, lsl #12  ; [pp+0x262d8] Obj!EdgeInsets@129d5f1
    //     0xdf58a4: ldr             x0, [x0, #0x2d8]
    // 0xdf58a8: CheckStackOverflow
    //     0xdf58a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf58ac: cmp             SP, x16
    //     0xdf58b0: b.ls            #0xdf5954
    // 0xdf58b4: LoadField: d0 = r0->field_f
    //     0xdf58b4: ldur            d0, [x0, #0xf]
    // 0xdf58b8: stur            d0, [fp, #-0x10]
    // 0xdf58bc: LoadField: r0 = r1->field_97
    //     0xdf58bc: ldur            w0, [x1, #0x97]
    // 0xdf58c0: DecompressPointer r0
    //     0xdf58c0: add             x0, x0, HEAP, lsl #32
    // 0xdf58c4: LoadField: r3 = r0->field_b
    //     0xdf58c4: ldur            w3, [x0, #0xb]
    // 0xdf58c8: cbz             w3, #0xdf5940
    // 0xdf58cc: cmp             x2, #0
    // 0xdf58d0: b.le            #0xdf5938
    // 0xdf58d4: LoadField: r3 = r1->field_d7
    //     0xdf58d4: ldur            w3, [x1, #0xd7]
    // 0xdf58d8: DecompressPointer r3
    //     0xdf58d8: add             x3, x3, HEAP, lsl #32
    // 0xdf58dc: r0 = BoxInt64Instr(r2)
    //     0xdf58dc: sbfiz           x0, x2, #1, #0x1f
    //     0xdf58e0: cmp             x2, x0, asr #1
    //     0xdf58e4: b.eq            #0xdf58f0
    //     0xdf58e8: bl              #0x13dfc6c  ; AllocateMintSharedWithFPURegsStub
    //     0xdf58ec: stur            x2, [x0, #7]
    // 0xdf58f0: str             x0, [SP]
    // 0xdf58f4: mov             x1, x3
    // 0xdf58f8: r2 = 0
    //     0xdf58f8: mov             x2, #0
    // 0xdf58fc: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0xdf58fc: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0xdf5900: r0 = sublist()
    //     0xdf5900: bl              #0xa01834  ; [dart:core] _List::sublist
    // 0xdf5904: r1 = Function '<anonymous closure>':.
    //     0xdf5904: add             x1, PP, #0xcd, lsl #12  ; [pp+0xcd578] AnonymousClosure: (0xade914), in [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_reconfigure (0xade978)
    //     0xdf5908: ldr             x1, [x1, #0x578]
    // 0xdf590c: r2 = Null
    //     0xdf590c: mov             x2, NULL
    // 0xdf5910: stur            x0, [fp, #-8]
    // 0xdf5914: r0 = AllocateClosure()
    //     0xdf5914: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf5918: ldur            x1, [fp, #-8]
    // 0xdf591c: mov             x2, x0
    // 0xdf5920: r0 = reduce()
    //     0xdf5920: bl              #0xb15d7c  ; [dart:collection] ListBase::reduce
    // 0xdf5924: LoadField: d1 = r0->field_7
    //     0xdf5924: ldur            d1, [x0, #7]
    // 0xdf5928: ldur            d2, [fp, #-0x10]
    // 0xdf592c: fadd            d3, d2, d1
    // 0xdf5930: mov             v0.16b, v3.16b
    // 0xdf5934: b               #0xdf5948
    // 0xdf5938: mov             v2.16b, v0.16b
    // 0xdf593c: b               #0xdf5944
    // 0xdf5940: mov             v2.16b, v0.16b
    // 0xdf5944: mov             v0.16b, v2.16b
    // 0xdf5948: LeaveFrame
    //     0xdf5948: mov             SP, fp
    //     0xdf594c: ldp             fp, lr, [SP], #0x10
    // 0xdf5950: ret
    //     0xdf5950: ret             
    // 0xdf5954: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf5954: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf5958: b               #0xdf58b4
  }
  _ buildPage(/* No info */) {
    // ** addr: 0x1103490, size: 0x60
    // 0x1103490: EnterFrame
    //     0x1103490: stp             fp, lr, [SP, #-0x10]!
    //     0x1103494: mov             fp, SP
    // 0x1103498: AllocStack(0x8)
    //     0x1103498: sub             SP, SP, #8
    // 0x110349c: SetupParameters(_DropdownRoute<C1X0> this /* r1 => r1, fp-0x8 */)
    //     0x110349c: stur            x1, [fp, #-8]
    // 0x11034a0: r1 = 1
    //     0x11034a0: mov             x1, #1
    // 0x11034a4: r0 = AllocateContext()
    //     0x11034a4: bl              #0x13de838  ; AllocateContextStub
    // 0x11034a8: mov             x1, x0
    // 0x11034ac: ldur            x0, [fp, #-8]
    // 0x11034b0: StoreField: r1->field_f = r0
    //     0x11034b0: stur            w0, [x1, #0xf]
    // 0x11034b4: LoadField: r3 = r0->field_7
    //     0x11034b4: ldur            w3, [x0, #7]
    // 0x11034b8: DecompressPointer r3
    //     0x11034b8: add             x3, x3, HEAP, lsl #32
    // 0x11034bc: mov             x2, x1
    // 0x11034c0: r1 = Function '<anonymous closure>':.
    //     0x11034c0: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3d48] AnonymousClosure: (0x11034f0), in [package:flutter/src/material/dropdown.dart] _DropdownRoute::buildPage (0x1103490)
    //     0x11034c4: ldr             x1, [x1, #0xd48]
    // 0x11034c8: r0 = AllocateClosureTA()
    //     0x11034c8: bl              #0x13dea48  ; AllocateClosureTAStub
    // 0x11034cc: r1 = <BoxConstraints>
    //     0x11034cc: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c3f0] TypeArguments: <BoxConstraints>
    //     0x11034d0: ldr             x1, [x1, #0x3f0]
    // 0x11034d4: stur            x0, [fp, #-8]
    // 0x11034d8: r0 = LayoutBuilder()
    //     0x11034d8: bl              #0xd15d50  ; AllocateLayoutBuilderStub -> LayoutBuilder (size=0x14)
    // 0x11034dc: ldur            x1, [fp, #-8]
    // 0x11034e0: StoreField: r0->field_f = r1
    //     0x11034e0: stur            w1, [x0, #0xf]
    // 0x11034e4: LeaveFrame
    //     0x11034e4: mov             SP, fp
    //     0x11034e8: ldp             fp, lr, [SP], #0x10
    // 0x11034ec: ret
    //     0x11034ec: ret             
  }
  [closure] _DropdownRoutePage<C1X0> <anonymous closure>(dynamic, BuildContext, BoxConstraints) {
    // ** addr: 0x11034f0, size: 0xd4
    // 0x11034f0: EnterFrame
    //     0x11034f0: stp             fp, lr, [SP, #-0x10]!
    //     0x11034f4: mov             fp, SP
    // 0x11034f8: AllocStack(0x28)
    //     0x11034f8: sub             SP, SP, #0x28
    // 0x11034fc: SetupParameters([dynamic _ /* r0 */])
    //     0x11034fc: ldr             x0, [fp, #0x20]
    //     0x1103500: ldur            w1, [x0, #0x17]
    //     0x1103504: add             x1, x1, HEAP, lsl #32
    // 0x1103508: LoadField: r0 = r1->field_f
    //     0x1103508: ldur            w0, [x1, #0xf]
    // 0x110350c: DecompressPointer r0
    //     0x110350c: add             x0, x0, HEAP, lsl #32
    // 0x1103510: stur            x0, [fp, #-0x28]
    // 0x1103514: LoadField: r4 = r0->field_9f
    //     0x1103514: ldur            w4, [x0, #0x9f]
    // 0x1103518: DecompressPointer r4
    //     0x1103518: add             x4, x4, HEAP, lsl #32
    // 0x110351c: stur            x4, [fp, #-0x20]
    // 0x1103520: LoadField: r5 = r0->field_a3
    //     0x1103520: ldur            x5, [x0, #0xa3]
    // 0x1103524: stur            x5, [fp, #-0x18]
    // 0x1103528: LoadField: r6 = r0->field_b3
    //     0x1103528: ldur            w6, [x0, #0xb3]
    // 0x110352c: DecompressPointer r6
    //     0x110352c: add             x6, x6, HEAP, lsl #32
    // 0x1103530: stur            x6, [fp, #-0x10]
    // 0x1103534: LoadField: r7 = r0->field_c3
    //     0x1103534: ldur            w7, [x0, #0xc3]
    // 0x1103538: DecompressPointer r7
    //     0x1103538: add             x7, x7, HEAP, lsl #32
    // 0x110353c: stur            x7, [fp, #-8]
    // 0x1103540: LoadField: r2 = r0->field_7
    //     0x1103540: ldur            w2, [x0, #7]
    // 0x1103544: DecompressPointer r2
    //     0x1103544: add             x2, x2, HEAP, lsl #32
    // 0x1103548: r1 = Null
    //     0x1103548: mov             x1, NULL
    // 0x110354c: r3 = <C1X0>
    //     0x110354c: add             x3, PP, #0x11, lsl #12  ; [pp+0x11880] TypeArguments: <C1X0>
    //     0x1103550: ldr             x3, [x3, #0x880]
    // 0x1103554: r0 = Null
    //     0x1103554: mov             x0, NULL
    // 0x1103558: cmp             x2, x0
    // 0x110355c: b.eq            #0x110356c
    // 0x1103560: r30 = InstantiateTypeArgumentsStub
    //     0x1103560: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0x1103564: LoadField: r30 = r30->field_7
    //     0x1103564: ldur            lr, [lr, #7]
    // 0x1103568: blr             lr
    // 0x110356c: mov             x1, x0
    // 0x1103570: r0 = _DropdownRoutePage()
    //     0x1103570: bl              #0x11035c4  ; Allocate_DropdownRoutePageStub -> _DropdownRoutePage<X0> (size=0x40)
    // 0x1103574: ldur            x1, [fp, #-0x28]
    // 0x1103578: StoreField: r0->field_f = r1
    //     0x1103578: stur            w1, [x0, #0xf]
    // 0x110357c: ldr             x1, [fp, #0x10]
    // 0x1103580: StoreField: r0->field_13 = r1
    //     0x1103580: stur            w1, [x0, #0x13]
    // 0x1103584: r1 = Instance_EdgeInsets
    //     0x1103584: add             x1, PP, #0x26, lsl #12  ; [pp+0x26510] Obj!EdgeInsets@129cdb1
    //     0x1103588: ldr             x1, [x1, #0x510]
    // 0x110358c: ArrayStore: r0[0] = r1  ; List_4
    //     0x110358c: stur            w1, [x0, #0x17]
    // 0x1103590: ldur            x1, [fp, #-0x20]
    // 0x1103594: StoreField: r0->field_1b = r1
    //     0x1103594: stur            w1, [x0, #0x1b]
    // 0x1103598: ldur            x1, [fp, #-0x18]
    // 0x110359c: StoreField: r0->field_1f = r1
    //     0x110359c: stur            x1, [x0, #0x1f]
    // 0x11035a0: ldur            x1, [fp, #-0x10]
    // 0x11035a4: StoreField: r0->field_27 = r1
    //     0x11035a4: stur            w1, [x0, #0x27]
    // 0x11035a8: ldur            x1, [fp, #-8]
    // 0x11035ac: StoreField: r0->field_2b = r1
    //     0x11035ac: stur            w1, [x0, #0x2b]
    // 0x11035b0: r1 = true
    //     0x11035b0: add             x1, NULL, #0x20  ; true
    // 0x11035b4: StoreField: r0->field_2f = r1
    //     0x11035b4: stur            w1, [x0, #0x2f]
    // 0x11035b8: LeaveFrame
    //     0x11035b8: mov             SP, fp
    //     0x11035bc: ldp             fp, lr, [SP], #0x10
    // 0x11035c0: ret
    //     0x11035c0: ret             
  }
  const get _ barrierDismissible(/* No info */) {
    // ** addr: 0x13083c0, size: 0xc
    // 0x13083c0: LoadField: r0 = r1->field_db
    //     0x13083c0: ldur            w0, [x1, #0xdb]
    // 0x13083c4: DecompressPointer r0
    //     0x13083c4: add             x0, x0, HEAP, lsl #32
    // 0x13083c8: ret
    //     0x13083c8: ret             
  }
}

// class id: 3106, size: 0x18, field offset: 0x8
//   const constructor, 
class _MenuLimits extends Object {
}

// class id: 3107, size: 0x10, field offset: 0x8
//   const constructor, 
class _DropdownRouteResult<X0> extends Object {

  _ ==(/* No info */) {
    // ** addr: 0x1295d2c, size: 0x100
    // 0x1295d2c: EnterFrame
    //     0x1295d2c: stp             fp, lr, [SP, #-0x10]!
    //     0x1295d30: mov             fp, SP
    // 0x1295d34: AllocStack(0x10)
    //     0x1295d34: sub             SP, SP, #0x10
    // 0x1295d38: CheckStackOverflow
    //     0x1295d38: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1295d3c: cmp             SP, x16
    //     0x1295d40: b.ls            #0x1295e24
    // 0x1295d44: ldr             x3, [fp, #0x10]
    // 0x1295d48: cmp             w3, NULL
    // 0x1295d4c: b.ne            #0x1295d60
    // 0x1295d50: r0 = false
    //     0x1295d50: add             x0, NULL, #0x30  ; false
    // 0x1295d54: LeaveFrame
    //     0x1295d54: mov             SP, fp
    //     0x1295d58: ldp             fp, lr, [SP], #0x10
    // 0x1295d5c: ret
    //     0x1295d5c: ret             
    // 0x1295d60: ldr             x4, [fp, #0x18]
    // 0x1295d64: LoadField: r2 = r4->field_7
    //     0x1295d64: ldur            w2, [x4, #7]
    // 0x1295d68: DecompressPointer r2
    //     0x1295d68: add             x2, x2, HEAP, lsl #32
    // 0x1295d6c: mov             x0, x3
    // 0x1295d70: r1 = Null
    //     0x1295d70: mov             x1, NULL
    // 0x1295d74: cmp             w0, NULL
    // 0x1295d78: b.eq            #0x1295dc4
    // 0x1295d7c: branchIfSmi(r0, 0x1295dc4)
    //     0x1295d7c: tbz             w0, #0, #0x1295dc4
    // 0x1295d80: r3 = SubtypeTestCache
    //     0x1295d80: add             x3, PP, #0xd4, lsl #12  ; [pp+0xd4210] SubtypeTestCache
    //     0x1295d84: ldr             x3, [x3, #0x210]
    // 0x1295d88: r30 = Subtype3TestCacheStub
    //     0x1295d88: ldr             lr, [PP, #0x28]  ; [pp+0x28] Stub: Subtype3TestCache (0x7d2c74)
    // 0x1295d8c: LoadField: r30 = r30->field_7
    //     0x1295d8c: ldur            lr, [lr, #7]
    // 0x1295d90: blr             lr
    // 0x1295d94: cmp             w7, NULL
    // 0x1295d98: b.eq            #0x1295da4
    // 0x1295d9c: tbnz            w7, #4, #0x1295dc4
    // 0x1295da0: b               #0x1295dcc
    // 0x1295da4: r8 = _DropdownRouteResult<X0>
    //     0x1295da4: add             x8, PP, #0xd4, lsl #12  ; [pp+0xd4218] Type: _DropdownRouteResult<X0>
    //     0x1295da8: ldr             x8, [x8, #0x218]
    // 0x1295dac: r3 = SubtypeTestCache
    //     0x1295dac: add             x3, PP, #0xd4, lsl #12  ; [pp+0xd4220] SubtypeTestCache
    //     0x1295db0: ldr             x3, [x3, #0x220]
    // 0x1295db4: r30 = InstanceOfStub
    //     0x1295db4: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x1295db8: LoadField: r30 = r30->field_7
    //     0x1295db8: ldur            lr, [lr, #7]
    // 0x1295dbc: blr             lr
    // 0x1295dc0: b               #0x1295dd0
    // 0x1295dc4: r0 = false
    //     0x1295dc4: add             x0, NULL, #0x30  ; false
    // 0x1295dc8: b               #0x1295dd0
    // 0x1295dcc: r0 = true
    //     0x1295dcc: add             x0, NULL, #0x20  ; true
    // 0x1295dd0: tbnz            w0, #4, #0x1295e14
    // 0x1295dd4: ldr             x1, [fp, #0x18]
    // 0x1295dd8: ldr             x0, [fp, #0x10]
    // 0x1295ddc: LoadField: r2 = r0->field_b
    //     0x1295ddc: ldur            w2, [x0, #0xb]
    // 0x1295de0: DecompressPointer r2
    //     0x1295de0: add             x2, x2, HEAP, lsl #32
    // 0x1295de4: LoadField: r0 = r1->field_b
    //     0x1295de4: ldur            w0, [x1, #0xb]
    // 0x1295de8: DecompressPointer r0
    //     0x1295de8: add             x0, x0, HEAP, lsl #32
    // 0x1295dec: r1 = 60
    //     0x1295dec: mov             x1, #0x3c
    // 0x1295df0: branchIfSmi(r2, 0x1295dfc)
    //     0x1295df0: tbz             w2, #0, #0x1295dfc
    // 0x1295df4: r1 = LoadClassIdInstr(r2)
    //     0x1295df4: ldur            x1, [x2, #-1]
    //     0x1295df8: ubfx            x1, x1, #0xc, #0x14
    // 0x1295dfc: stp             x0, x2, [SP]
    // 0x1295e00: mov             x0, x1
    // 0x1295e04: mov             lr, x0
    // 0x1295e08: ldr             lr, [x21, lr, lsl #3]
    // 0x1295e0c: blr             lr
    // 0x1295e10: b               #0x1295e18
    // 0x1295e14: r0 = false
    //     0x1295e14: add             x0, NULL, #0x30  ; false
    // 0x1295e18: LeaveFrame
    //     0x1295e18: mov             SP, fp
    //     0x1295e1c: ldp             fp, lr, [SP], #0x10
    // 0x1295e20: ret
    //     0x1295e20: ret             
    // 0x1295e24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1295e24: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1295e28: b               #0x1295d44
  }
}

// class id: 3133, size: 0x20, field offset: 0xc
class _DropdownMenuRouteLayout<X0> extends SingleChildLayoutDelegate {

  _ shouldRelayout(/* No info */) {
    // ** addr: 0x1141f4c, size: 0xbc
    // 0x1141f4c: EnterFrame
    //     0x1141f4c: stp             fp, lr, [SP, #-0x10]!
    //     0x1141f50: mov             fp, SP
    // 0x1141f54: AllocStack(0x20)
    //     0x1141f54: sub             SP, SP, #0x20
    // 0x1141f58: SetupParameters(_DropdownMenuRouteLayout<X0> this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x1141f58: mov             x4, x1
    //     0x1141f5c: mov             x3, x2
    //     0x1141f60: stur            x1, [fp, #-8]
    //     0x1141f64: stur            x2, [fp, #-0x10]
    // 0x1141f68: CheckStackOverflow
    //     0x1141f68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1141f6c: cmp             SP, x16
    //     0x1141f70: b.ls            #0x1142000
    // 0x1141f74: LoadField: r2 = r4->field_b
    //     0x1141f74: ldur            w2, [x4, #0xb]
    // 0x1141f78: DecompressPointer r2
    //     0x1141f78: add             x2, x2, HEAP, lsl #32
    // 0x1141f7c: mov             x0, x3
    // 0x1141f80: r1 = Null
    //     0x1141f80: mov             x1, NULL
    // 0x1141f84: r8 = _DropdownMenuRouteLayout<X0>
    //     0x1141f84: add             x8, PP, #0xd0, lsl #12  ; [pp+0xd05a8] Type: _DropdownMenuRouteLayout<X0>
    //     0x1141f88: ldr             x8, [x8, #0x5a8]
    // 0x1141f8c: LoadField: r9 = r8->field_7
    //     0x1141f8c: ldur            x9, [x8, #7]
    // 0x1141f90: r3 = Null
    //     0x1141f90: add             x3, PP, #0xd0, lsl #12  ; [pp+0xd05b0] Null
    //     0x1141f94: ldr             x3, [x3, #0x5b0]
    // 0x1141f98: blr             x9
    // 0x1141f9c: ldur            x0, [fp, #-8]
    // 0x1141fa0: LoadField: r1 = r0->field_f
    //     0x1141fa0: ldur            w1, [x0, #0xf]
    // 0x1141fa4: DecompressPointer r1
    //     0x1141fa4: add             x1, x1, HEAP, lsl #32
    // 0x1141fa8: ldur            x2, [fp, #-0x10]
    // 0x1141fac: LoadField: r3 = r2->field_f
    //     0x1141fac: ldur            w3, [x2, #0xf]
    // 0x1141fb0: DecompressPointer r3
    //     0x1141fb0: add             x3, x3, HEAP, lsl #32
    // 0x1141fb4: stp             x3, x1, [SP]
    // 0x1141fb8: r0 = ==()
    //     0x1141fb8: bl              #0x128bdfc  ; [dart:ui] Rect::==
    // 0x1141fbc: tbz             w0, #4, #0x1141fc8
    // 0x1141fc0: r0 = true
    //     0x1141fc0: add             x0, NULL, #0x20  ; true
    // 0x1141fc4: b               #0x1141ff4
    // 0x1141fc8: ldur            x1, [fp, #-8]
    // 0x1141fcc: ldur            x2, [fp, #-0x10]
    // 0x1141fd0: ArrayLoad: r3 = r1[0]  ; List_4
    //     0x1141fd0: ldur            w3, [x1, #0x17]
    // 0x1141fd4: DecompressPointer r3
    //     0x1141fd4: add             x3, x3, HEAP, lsl #32
    // 0x1141fd8: ArrayLoad: r1 = r2[0]  ; List_4
    //     0x1141fd8: ldur            w1, [x2, #0x17]
    // 0x1141fdc: DecompressPointer r1
    //     0x1141fdc: add             x1, x1, HEAP, lsl #32
    // 0x1141fe0: cmp             w3, w1
    // 0x1141fe4: r16 = true
    //     0x1141fe4: add             x16, NULL, #0x20  ; true
    // 0x1141fe8: r17 = false
    //     0x1141fe8: add             x17, NULL, #0x30  ; false
    // 0x1141fec: csel            x2, x16, x17, ne
    // 0x1141ff0: mov             x0, x2
    // 0x1141ff4: LeaveFrame
    //     0x1141ff4: mov             SP, fp
    //     0x1141ff8: ldp             fp, lr, [SP], #0x10
    // 0x1141ffc: ret
    //     0x1141ffc: ret             
    // 0x1142000: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1142000: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1142004: b               #0x1141f74
  }
  _ getConstraintsForChild(/* No info */) {
    // ** addr: 0x12dc9ac, size: 0x98
    // 0x12dc9ac: EnterFrame
    //     0x12dc9ac: stp             fp, lr, [SP, #-0x10]!
    //     0x12dc9b0: mov             fp, SP
    // 0x12dc9b4: AllocStack(0x10)
    //     0x12dc9b4: sub             SP, SP, #0x10
    // 0x12dc9b8: d1 = 96.000000
    //     0x12dc9b8: add             x17, PP, #0x13, lsl #12  ; [pp+0x13580] IMM: double(96) from 0x4058000000000000
    //     0x12dc9bc: ldr             d1, [x17, #0x580]
    // 0x12dc9c0: d0 = 0.000000
    //     0x12dc9c0: eor             v0.16b, v0.16b, v0.16b
    // 0x12dc9c4: LoadField: d2 = r2->field_1f
    //     0x12dc9c4: ldur            d2, [x2, #0x1f]
    // 0x12dc9c8: fsub            d3, d2, d1
    // 0x12dc9cc: fmax            v1.2d, v0.2d, v3.2d
    // 0x12dc9d0: LoadField: r0 = r1->field_13
    //     0x12dc9d0: ldur            w0, [x1, #0x13]
    // 0x12dc9d4: DecompressPointer r0
    //     0x12dc9d4: add             x0, x0, HEAP, lsl #32
    // 0x12dc9d8: LoadField: r3 = r0->field_c7
    //     0x12dc9d8: ldur            w3, [x0, #0xc7]
    // 0x12dc9dc: DecompressPointer r3
    //     0x12dc9dc: add             x3, x3, HEAP, lsl #32
    // 0x12dc9e0: cmp             w3, NULL
    // 0x12dc9e4: b.eq            #0x12dc9f4
    // 0x12dc9e8: LoadField: d0 = r3->field_7
    //     0x12dc9e8: ldur            d0, [x3, #7]
    // 0x12dc9ec: fcmp            d1, d0
    // 0x12dc9f0: b.ge            #0x12dc9f8
    // 0x12dc9f4: mov             v0.16b, v1.16b
    // 0x12dc9f8: stur            d0, [fp, #-0x10]
    // 0x12dc9fc: LoadField: d1 = r2->field_f
    //     0x12dc9fc: ldur            d1, [x2, #0xf]
    // 0x12dca00: LoadField: r0 = r1->field_f
    //     0x12dca00: ldur            w0, [x1, #0xf]
    // 0x12dca04: DecompressPointer r0
    //     0x12dca04: add             x0, x0, HEAP, lsl #32
    // 0x12dca08: ArrayLoad: d2 = r0[0]  ; List_8
    //     0x12dca08: ldur            d2, [x0, #0x17]
    // 0x12dca0c: LoadField: d3 = r0->field_7
    //     0x12dca0c: ldur            d3, [x0, #7]
    // 0x12dca10: fsub            d4, d2, d3
    // 0x12dca14: fmin            v2.2d, v1.2d, v4.2d
    // 0x12dca18: stur            d2, [fp, #-8]
    // 0x12dca1c: r0 = BoxConstraints()
    //     0x12dca1c: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x12dca20: ldur            d0, [fp, #-8]
    // 0x12dca24: StoreField: r0->field_7 = d0
    //     0x12dca24: stur            d0, [x0, #7]
    // 0x12dca28: StoreField: r0->field_f = d0
    //     0x12dca28: stur            d0, [x0, #0xf]
    // 0x12dca2c: ArrayStore: r0[0] = rZR  ; List_8
    //     0x12dca2c: stur            xzr, [x0, #0x17]
    // 0x12dca30: ldur            d0, [fp, #-0x10]
    // 0x12dca34: StoreField: r0->field_1f = d0
    //     0x12dca34: stur            d0, [x0, #0x1f]
    // 0x12dca38: LeaveFrame
    //     0x12dca38: mov             SP, fp
    //     0x12dca3c: ldp             fp, lr, [SP], #0x10
    // 0x12dca40: ret
    //     0x12dca40: ret             
  }
  _ getPositionForChild(/* No info */) {
    // ** addr: 0x12e4374, size: 0x160
    // 0x12e4374: EnterFrame
    //     0x12e4374: stp             fp, lr, [SP, #-0x10]!
    //     0x12e4378: mov             fp, SP
    // 0x12e437c: AllocStack(0x30)
    //     0x12e437c: sub             SP, SP, #0x30
    // 0x12e4380: SetupParameters(_DropdownMenuRouteLayout<X0> this /* r1 => r5, fp-0x10 */, dynamic _ /* r2 => r4, fp-0x18 */, dynamic _ /* r3 => r0, fp-0x20 */)
    //     0x12e4380: mov             x5, x1
    //     0x12e4384: mov             x4, x2
    //     0x12e4388: mov             x0, x3
    //     0x12e438c: stur            x1, [fp, #-0x10]
    //     0x12e4390: stur            x2, [fp, #-0x18]
    //     0x12e4394: stur            x3, [fp, #-0x20]
    // 0x12e4398: CheckStackOverflow
    //     0x12e4398: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e439c: cmp             SP, x16
    //     0x12e43a0: b.ls            #0x12e44c8
    // 0x12e43a4: LoadField: r1 = r5->field_13
    //     0x12e43a4: ldur            w1, [x5, #0x13]
    // 0x12e43a8: DecompressPointer r1
    //     0x12e43a8: add             x1, x1, HEAP, lsl #32
    // 0x12e43ac: LoadField: r6 = r5->field_f
    //     0x12e43ac: ldur            w6, [x5, #0xf]
    // 0x12e43b0: DecompressPointer r6
    //     0x12e43b0: add             x6, x6, HEAP, lsl #32
    // 0x12e43b4: stur            x6, [fp, #-8]
    // 0x12e43b8: LoadField: d0 = r4->field_f
    //     0x12e43b8: ldur            d0, [x4, #0xf]
    // 0x12e43bc: LoadField: r3 = r1->field_a3
    //     0x12e43bc: ldur            x3, [x1, #0xa3]
    // 0x12e43c0: mov             x2, x6
    // 0x12e43c4: r0 = getMenuLimits()
    //     0x12e43c4: bl              #0xdf55fc  ; [package:flutter/src/material/dropdown.dart] _DropdownRoute::getMenuLimits
    // 0x12e43c8: mov             x1, x0
    // 0x12e43cc: ldur            x0, [fp, #-0x10]
    // 0x12e43d0: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x12e43d0: ldur            w2, [x0, #0x17]
    // 0x12e43d4: DecompressPointer r2
    //     0x12e43d4: add             x2, x2, HEAP, lsl #32
    // 0x12e43d8: cmp             w2, NULL
    // 0x12e43dc: b.eq            #0x12e44d0
    // 0x12e43e0: LoadField: r0 = r2->field_7
    //     0x12e43e0: ldur            x0, [x2, #7]
    // 0x12e43e4: cmp             x0, #0
    // 0x12e43e8: b.gt            #0x12e4448
    // 0x12e43ec: ldur            x0, [fp, #-0x18]
    // 0x12e43f0: ldur            x2, [fp, #-8]
    // 0x12e43f4: d0 = 0.000000
    //     0x12e43f4: eor             v0.16b, v0.16b, v0.16b
    // 0x12e43f8: ArrayLoad: d1 = r2[0]  ; List_8
    //     0x12e43f8: ldur            d1, [x2, #0x17]
    // 0x12e43fc: LoadField: d2 = r0->field_7
    //     0x12e43fc: ldur            d2, [x0, #7]
    // 0x12e4400: fcmp            d0, d1
    // 0x12e4404: b.le            #0x12e4410
    // 0x12e4408: d0 = 0.000000
    //     0x12e4408: eor             v0.16b, v0.16b, v0.16b
    // 0x12e440c: b               #0x12e4434
    // 0x12e4410: fcmp            d1, d2
    // 0x12e4414: b.le            #0x12e4420
    // 0x12e4418: mov             v0.16b, v2.16b
    // 0x12e441c: b               #0x12e4434
    // 0x12e4420: fcmp            d1, d1
    // 0x12e4424: b.vc            #0x12e4430
    // 0x12e4428: mov             v0.16b, v2.16b
    // 0x12e442c: b               #0x12e4434
    // 0x12e4430: mov             v0.16b, v1.16b
    // 0x12e4434: ldur            x3, [fp, #-0x20]
    // 0x12e4438: LoadField: d1 = r3->field_7
    //     0x12e4438: ldur            d1, [x3, #7]
    // 0x12e443c: fsub            d2, d0, d1
    // 0x12e4440: mov             v0.16b, v2.16b
    // 0x12e4444: b               #0x12e449c
    // 0x12e4448: ldur            x0, [fp, #-0x18]
    // 0x12e444c: ldur            x3, [fp, #-0x20]
    // 0x12e4450: ldur            x2, [fp, #-8]
    // 0x12e4454: d0 = 0.000000
    //     0x12e4454: eor             v0.16b, v0.16b, v0.16b
    // 0x12e4458: LoadField: d1 = r2->field_7
    //     0x12e4458: ldur            d1, [x2, #7]
    // 0x12e445c: LoadField: d2 = r0->field_7
    //     0x12e445c: ldur            d2, [x0, #7]
    // 0x12e4460: LoadField: d3 = r3->field_7
    //     0x12e4460: ldur            d3, [x3, #7]
    // 0x12e4464: fsub            d4, d2, d3
    // 0x12e4468: fcmp            d0, d1
    // 0x12e446c: b.le            #0x12e4478
    // 0x12e4470: d0 = 0.000000
    //     0x12e4470: eor             v0.16b, v0.16b, v0.16b
    // 0x12e4474: b               #0x12e449c
    // 0x12e4478: fcmp            d1, d4
    // 0x12e447c: b.le            #0x12e4488
    // 0x12e4480: mov             v0.16b, v4.16b
    // 0x12e4484: b               #0x12e449c
    // 0x12e4488: fcmp            d1, d1
    // 0x12e448c: b.vc            #0x12e4498
    // 0x12e4490: mov             v0.16b, v4.16b
    // 0x12e4494: b               #0x12e449c
    // 0x12e4498: mov             v0.16b, v1.16b
    // 0x12e449c: stur            d0, [fp, #-0x30]
    // 0x12e44a0: LoadField: d1 = r1->field_7
    //     0x12e44a0: ldur            d1, [x1, #7]
    // 0x12e44a4: stur            d1, [fp, #-0x28]
    // 0x12e44a8: r0 = Offset()
    //     0x12e44a8: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x12e44ac: ldur            d0, [fp, #-0x30]
    // 0x12e44b0: StoreField: r0->field_7 = d0
    //     0x12e44b0: stur            d0, [x0, #7]
    // 0x12e44b4: ldur            d0, [fp, #-0x28]
    // 0x12e44b8: StoreField: r0->field_f = d0
    //     0x12e44b8: stur            d0, [x0, #0xf]
    // 0x12e44bc: LeaveFrame
    //     0x12e44bc: mov             SP, fp
    //     0x12e44c0: ldp             fp, lr, [SP], #0x10
    // 0x12e44c4: ret
    //     0x12e44c4: ret             
    // 0x12e44c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e44c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e44cc: b               #0x12e43a4
    // 0x12e44d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12e44d0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4338, size: 0x30, field offset: 0xc
class _DropdownMenuPainter extends CustomPainter {

  _ paint(/* No info */) {
    // ** addr: 0xb7641c, size: 0x2e8
    // 0xb7641c: EnterFrame
    //     0xb7641c: stp             fp, lr, [SP, #-0x10]!
    //     0xb76420: mov             fp, SP
    // 0xb76424: AllocStack(0x48)
    //     0xb76424: sub             SP, SP, #0x48
    // 0xb76428: SetupParameters(_DropdownMenuPainter this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xb76428: stur            x1, [fp, #-8]
    //     0xb7642c: stur            x2, [fp, #-0x10]
    //     0xb76430: stur            x3, [fp, #-0x18]
    // 0xb76434: CheckStackOverflow
    //     0xb76434: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb76438: cmp             SP, x16
    //     0xb7643c: b.ls            #0xb7669c
    // 0xb76440: LoadField: r0 = r1->field_27
    //     0xb76440: ldur            w0, [x1, #0x27]
    // 0xb76444: DecompressPointer r0
    //     0xb76444: add             x0, x0, HEAP, lsl #32
    // 0xb76448: str             x0, [SP]
    // 0xb7644c: ClosureCall
    //     0xb7644c: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xb76450: ldur            x2, [x0, #0x1f]
    //     0xb76454: blr             x2
    // 0xb76458: mov             x1, x0
    // 0xb7645c: ldur            x0, [fp, #-0x18]
    // 0xb76460: LoadField: d0 = r0->field_f
    //     0xb76460: ldur            d0, [x0, #0xf]
    // 0xb76464: stur            d0, [fp, #-0x40]
    // 0xb76468: d1 = 48.000000
    //     0xb76468: ldr             d1, [PP, #0x5650]  ; [pp+0x5650] IMM: double(48) from 0x4048000000000000
    // 0xb7646c: fsub            d2, d0, d1
    // 0xb76470: d3 = 0.000000
    //     0xb76470: eor             v3.16b, v3.16b, v3.16b
    // 0xb76474: fmax            v4.2d, v2.2d, v3.2d
    // 0xb76478: LoadField: d2 = r1->field_7
    //     0xb76478: ldur            d2, [x1, #7]
    // 0xb7647c: fcmp            d3, d2
    // 0xb76480: b.le            #0xb7648c
    // 0xb76484: d2 = 0.000000
    //     0xb76484: eor             v2.16b, v2.16b, v2.16b
    // 0xb76488: b               #0xb764a8
    // 0xb7648c: fcmp            d2, d4
    // 0xb76490: b.le            #0xb7649c
    // 0xb76494: mov             v2.16b, v4.16b
    // 0xb76498: b               #0xb764a8
    // 0xb7649c: fcmp            d2, d2
    // 0xb764a0: b.vc            #0xb764a8
    // 0xb764a4: mov             v2.16b, v4.16b
    // 0xb764a8: stur            d2, [fp, #-0x38]
    // 0xb764ac: r2 = inline_Allocate_Double()
    //     0xb764ac: ldp             x2, x1, [THR, #0x60]  ; THR::top
    //     0xb764b0: add             x2, x2, #0x10
    //     0xb764b4: cmp             x1, x2
    //     0xb764b8: b.ls            #0xb766a4
    //     0xb764bc: str             x2, [THR, #0x60]  ; THR::top
    //     0xb764c0: sub             x2, x2, #0xf
    //     0xb764c4: mov             x1, #0xe19c
    //     0xb764c8: movk            x1, #3, lsl #16
    //     0xb764cc: stur            x1, [x2, #-1]
    // 0xb764d0: dmb             ishst
    // 0xb764d4: StoreField: r2->field_7 = d2
    //     0xb764d4: stur            d2, [x2, #7]
    // 0xb764d8: stur            x2, [fp, #-0x20]
    // 0xb764dc: r1 = <double>
    //     0xb764dc: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xb764e0: r0 = Tween()
    //     0xb764e0: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xb764e4: mov             x2, x0
    // 0xb764e8: ldur            x0, [fp, #-0x20]
    // 0xb764ec: stur            x2, [fp, #-0x28]
    // 0xb764f0: StoreField: r2->field_b = r0
    //     0xb764f0: stur            w0, [x2, #0xb]
    // 0xb764f4: r0 = 0.000000
    //     0xb764f4: ldr             x0, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xb764f8: StoreField: r2->field_f = r0
    //     0xb764f8: stur            w0, [x2, #0xf]
    // 0xb764fc: ldur            d1, [fp, #-0x38]
    // 0xb76500: d0 = 48.000000
    //     0xb76500: ldr             d0, [PP, #0x5650]  ; [pp+0x5650] IMM: double(48) from 0x4048000000000000
    // 0xb76504: fadd            d2, d1, d0
    // 0xb76508: ldur            d1, [fp, #-0x40]
    // 0xb7650c: fmin            v3.2d, v0.2d, v1.2d
    // 0xb76510: fcmp            d3, d2
    // 0xb76514: b.le            #0xb76520
    // 0xb76518: mov             v0.16b, v3.16b
    // 0xb7651c: b               #0xb76544
    // 0xb76520: fcmp            d2, d1
    // 0xb76524: b.le            #0xb76530
    // 0xb76528: mov             v0.16b, v1.16b
    // 0xb7652c: b               #0xb76544
    // 0xb76530: fcmp            d2, d2
    // 0xb76534: b.vc            #0xb76540
    // 0xb76538: mov             v0.16b, v1.16b
    // 0xb7653c: b               #0xb76544
    // 0xb76540: mov             v0.16b, v2.16b
    // 0xb76544: ldur            x3, [fp, #-8]
    // 0xb76548: ldur            x0, [fp, #-0x18]
    // 0xb7654c: r4 = inline_Allocate_Double()
    //     0xb7654c: ldp             x4, x1, [THR, #0x60]  ; THR::top
    //     0xb76550: add             x4, x4, #0x10
    //     0xb76554: cmp             x1, x4
    //     0xb76558: b.ls            #0xb766c8
    //     0xb7655c: str             x4, [THR, #0x60]  ; THR::top
    //     0xb76560: sub             x4, x4, #0xf
    //     0xb76564: mov             x1, #0xe19c
    //     0xb76568: movk            x1, #3, lsl #16
    //     0xb7656c: stur            x1, [x4, #-1]
    // 0xb76570: dmb             ishst
    // 0xb76574: StoreField: r4->field_7 = d0
    //     0xb76574: stur            d0, [x4, #7]
    // 0xb76578: stur            x4, [fp, #-0x20]
    // 0xb7657c: r1 = <double>
    //     0xb7657c: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xb76580: r0 = Tween()
    //     0xb76580: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xb76584: mov             x3, x0
    // 0xb76588: ldur            x0, [fp, #-0x20]
    // 0xb7658c: stur            x3, [fp, #-0x30]
    // 0xb76590: StoreField: r3->field_b = r0
    //     0xb76590: stur            w0, [x3, #0xb]
    // 0xb76594: ldur            d0, [fp, #-0x40]
    // 0xb76598: r0 = inline_Allocate_Double()
    //     0xb76598: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb7659c: add             x0, x0, #0x10
    //     0xb765a0: cmp             x1, x0
    //     0xb765a4: b.ls            #0xb766ec
    //     0xb765a8: str             x0, [THR, #0x60]  ; THR::top
    //     0xb765ac: sub             x0, x0, #0xf
    //     0xb765b0: mov             x1, #0xe19c
    //     0xb765b4: movk            x1, #3, lsl #16
    //     0xb765b8: stur            x1, [x0, #-1]
    // 0xb765bc: dmb             ishst
    // 0xb765c0: StoreField: r0->field_7 = d0
    //     0xb765c0: stur            d0, [x0, #7]
    // 0xb765c4: StoreField: r3->field_f = r0
    //     0xb765c4: stur            w0, [x3, #0xf]
    // 0xb765c8: ldur            x0, [fp, #-8]
    // 0xb765cc: LoadField: r4 = r0->field_23
    //     0xb765cc: ldur            w4, [x0, #0x23]
    // 0xb765d0: DecompressPointer r4
    //     0xb765d0: add             x4, x4, HEAP, lsl #32
    // 0xb765d4: ldur            x1, [fp, #-0x28]
    // 0xb765d8: mov             x2, x4
    // 0xb765dc: stur            x4, [fp, #-0x20]
    // 0xb765e0: r0 = evaluate()
    //     0xb765e0: bl              #0x112be60  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xb765e4: mov             x3, x0
    // 0xb765e8: ldur            x0, [fp, #-0x18]
    // 0xb765ec: stur            x3, [fp, #-0x28]
    // 0xb765f0: LoadField: d0 = r0->field_7
    //     0xb765f0: ldur            d0, [x0, #7]
    // 0xb765f4: ldur            x1, [fp, #-0x30]
    // 0xb765f8: ldur            x2, [fp, #-0x20]
    // 0xb765fc: stur            d0, [fp, #-0x38]
    // 0xb76600: r0 = evaluate()
    //     0xb76600: bl              #0x112be60  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xb76604: stur            x0, [fp, #-0x18]
    // 0xb76608: r0 = Rect()
    //     0xb76608: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0xb7660c: stur            x0, [fp, #-0x20]
    // 0xb76610: StoreField: r0->field_7 = rZR
    //     0xb76610: stur            xzr, [x0, #7]
    // 0xb76614: ldur            x1, [fp, #-0x28]
    // 0xb76618: LoadField: d0 = r1->field_7
    //     0xb76618: ldur            d0, [x1, #7]
    // 0xb7661c: stur            d0, [fp, #-0x40]
    // 0xb76620: StoreField: r0->field_f = d0
    //     0xb76620: stur            d0, [x0, #0xf]
    // 0xb76624: ldur            d1, [fp, #-0x38]
    // 0xb76628: ArrayStore: r0[0] = d1  ; List_8
    //     0xb76628: stur            d1, [x0, #0x17]
    // 0xb7662c: ldur            x1, [fp, #-0x18]
    // 0xb76630: LoadField: d1 = r1->field_7
    //     0xb76630: ldur            d1, [x1, #7]
    // 0xb76634: StoreField: r0->field_1f = d1
    //     0xb76634: stur            d1, [x0, #0x1f]
    // 0xb76638: ldur            x1, [fp, #-8]
    // 0xb7663c: LoadField: r2 = r1->field_2b
    //     0xb7663c: ldur            w2, [x1, #0x2b]
    // 0xb76640: DecompressPointer r2
    //     0xb76640: add             x2, x2, HEAP, lsl #32
    // 0xb76644: stur            x2, [fp, #-0x18]
    // 0xb76648: r0 = Offset()
    //     0xb76648: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xb7664c: stur            x0, [fp, #-8]
    // 0xb76650: StoreField: r0->field_7 = rZR
    //     0xb76650: stur            xzr, [x0, #7]
    // 0xb76654: ldur            d0, [fp, #-0x40]
    // 0xb76658: StoreField: r0->field_f = d0
    //     0xb76658: stur            d0, [x0, #0xf]
    // 0xb7665c: ldur            x1, [fp, #-0x20]
    // 0xb76660: r0 = size()
    //     0xb76660: bl              #0x8632d0  ; [dart:ui] Rect::size
    // 0xb76664: stur            x0, [fp, #-0x20]
    // 0xb76668: r0 = ImageConfiguration()
    //     0xb76668: bl              #0xb6d7b4  ; AllocateImageConfigurationStub -> ImageConfiguration (size=0x20)
    // 0xb7666c: mov             x1, x0
    // 0xb76670: ldur            x0, [fp, #-0x20]
    // 0xb76674: ArrayStore: r1[0] = r0  ; List_4
    //     0xb76674: stur            w0, [x1, #0x17]
    // 0xb76678: mov             x5, x1
    // 0xb7667c: ldur            x1, [fp, #-0x18]
    // 0xb76680: ldur            x2, [fp, #-0x10]
    // 0xb76684: ldur            x3, [fp, #-8]
    // 0xb76688: r0 = paint()
    //     0xb76688: bl              #0x12f6bf4  ; [package:flutter/src/painting/box_decoration.dart] _BoxDecorationPainter::paint
    // 0xb7668c: r0 = Null
    //     0xb7668c: mov             x0, NULL
    // 0xb76690: LeaveFrame
    //     0xb76690: mov             SP, fp
    //     0xb76694: ldp             fp, lr, [SP], #0x10
    // 0xb76698: ret
    //     0xb76698: ret             
    // 0xb7669c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb7669c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb766a0: b               #0xb76440
    // 0xb766a4: stp             q1, q2, [SP, #-0x20]!
    // 0xb766a8: SaveReg d0
    //     0xb766a8: str             q0, [SP, #-0x10]!
    // 0xb766ac: SaveReg r0
    //     0xb766ac: str             x0, [SP, #-8]!
    // 0xb766b0: r0 = AllocateDouble()
    //     0xb766b0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb766b4: mov             x2, x0
    // 0xb766b8: RestoreReg r0
    //     0xb766b8: ldr             x0, [SP], #8
    // 0xb766bc: RestoreReg d0
    //     0xb766bc: ldr             q0, [SP], #0x10
    // 0xb766c0: ldp             q1, q2, [SP], #0x20
    // 0xb766c4: b               #0xb764d4
    // 0xb766c8: stp             q0, q1, [SP, #-0x20]!
    // 0xb766cc: stp             x2, x3, [SP, #-0x10]!
    // 0xb766d0: SaveReg r0
    //     0xb766d0: str             x0, [SP, #-8]!
    // 0xb766d4: r0 = AllocateDouble()
    //     0xb766d4: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb766d8: mov             x4, x0
    // 0xb766dc: RestoreReg r0
    //     0xb766dc: ldr             x0, [SP], #8
    // 0xb766e0: ldp             x2, x3, [SP], #0x10
    // 0xb766e4: ldp             q0, q1, [SP], #0x20
    // 0xb766e8: b               #0xb76574
    // 0xb766ec: SaveReg d0
    //     0xb766ec: str             q0, [SP, #-0x10]!
    // 0xb766f0: SaveReg r3
    //     0xb766f0: str             x3, [SP, #-8]!
    // 0xb766f4: r0 = AllocateDouble()
    //     0xb766f4: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb766f8: RestoreReg r3
    //     0xb766f8: ldr             x3, [SP], #8
    // 0xb766fc: RestoreReg d0
    //     0xb766fc: ldr             q0, [SP], #0x10
    // 0xb76700: b               #0xb765c0
  }
  _ shouldRepaint(/* No info */) {
    // ** addr: 0xb93474, size: 0xf4
    // 0xb93474: EnterFrame
    //     0xb93474: stp             fp, lr, [SP, #-0x10]!
    //     0xb93478: mov             fp, SP
    // 0xb9347c: AllocStack(0x20)
    //     0xb9347c: sub             SP, SP, #0x20
    // 0xb93480: SetupParameters(_DropdownMenuPainter this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xb93480: mov             x4, x1
    //     0xb93484: mov             x3, x2
    //     0xb93488: stur            x1, [fp, #-8]
    //     0xb9348c: stur            x2, [fp, #-0x10]
    // 0xb93490: CheckStackOverflow
    //     0xb93490: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb93494: cmp             SP, x16
    //     0xb93498: b.ls            #0xb93560
    // 0xb9349c: mov             x0, x3
    // 0xb934a0: r2 = Null
    //     0xb934a0: mov             x2, NULL
    // 0xb934a4: r1 = Null
    //     0xb934a4: mov             x1, NULL
    // 0xb934a8: r4 = 60
    //     0xb934a8: mov             x4, #0x3c
    // 0xb934ac: branchIfSmi(r0, 0xb934b8)
    //     0xb934ac: tbz             w0, #0, #0xb934b8
    // 0xb934b0: r4 = LoadClassIdInstr(r0)
    //     0xb934b0: ldur            x4, [x0, #-1]
    //     0xb934b4: ubfx            x4, x4, #0xc, #0x14
    // 0xb934b8: r17 = 4338
    //     0xb934b8: mov             x17, #0x10f2
    // 0xb934bc: cmp             x4, x17
    // 0xb934c0: b.eq            #0xb934d8
    // 0xb934c4: r8 = _DropdownMenuPainter
    //     0xb934c4: add             x8, PP, #0xd2, lsl #12  ; [pp+0xd28a0] Type: _DropdownMenuPainter
    //     0xb934c8: ldr             x8, [x8, #0x8a0]
    // 0xb934cc: r3 = Null
    //     0xb934cc: add             x3, PP, #0xd2, lsl #12  ; [pp+0xd28a8] Null
    //     0xb934d0: ldr             x3, [x3, #0x8a8]
    // 0xb934d4: r0 = DefaultTypeTest()
    //     0xb934d4: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb934d8: ldur            x1, [fp, #-0x10]
    // 0xb934dc: LoadField: r0 = r1->field_b
    //     0xb934dc: ldur            w0, [x1, #0xb]
    // 0xb934e0: DecompressPointer r0
    //     0xb934e0: add             x0, x0, HEAP, lsl #32
    // 0xb934e4: ldur            x2, [fp, #-8]
    // 0xb934e8: LoadField: r3 = r2->field_b
    //     0xb934e8: ldur            w3, [x2, #0xb]
    // 0xb934ec: DecompressPointer r3
    //     0xb934ec: add             x3, x3, HEAP, lsl #32
    // 0xb934f0: r4 = LoadClassIdInstr(r0)
    //     0xb934f0: ldur            x4, [x0, #-1]
    //     0xb934f4: ubfx            x4, x4, #0xc, #0x14
    // 0xb934f8: stp             x3, x0, [SP]
    // 0xb934fc: mov             x0, x4
    // 0xb93500: mov             lr, x0
    // 0xb93504: ldr             lr, [x21, lr, lsl #3]
    // 0xb93508: blr             lr
    // 0xb9350c: tbnz            w0, #4, #0xb93528
    // 0xb93510: ldur            x2, [fp, #-8]
    // 0xb93514: ldur            x1, [fp, #-0x10]
    // 0xb93518: ArrayLoad: r3 = r1[0]  ; List_8
    //     0xb93518: ldur            x3, [x1, #0x17]
    // 0xb9351c: ArrayLoad: r4 = r2[0]  ; List_8
    //     0xb9351c: ldur            x4, [x2, #0x17]
    // 0xb93520: cmp             x3, x4
    // 0xb93524: b.eq            #0xb93530
    // 0xb93528: r0 = true
    //     0xb93528: add             x0, NULL, #0x20  ; true
    // 0xb9352c: b               #0xb93554
    // 0xb93530: LoadField: r3 = r1->field_23
    //     0xb93530: ldur            w3, [x1, #0x23]
    // 0xb93534: DecompressPointer r3
    //     0xb93534: add             x3, x3, HEAP, lsl #32
    // 0xb93538: LoadField: r1 = r2->field_23
    //     0xb93538: ldur            w1, [x2, #0x23]
    // 0xb9353c: DecompressPointer r1
    //     0xb9353c: add             x1, x1, HEAP, lsl #32
    // 0xb93540: cmp             w3, w1
    // 0xb93544: r16 = true
    //     0xb93544: add             x16, NULL, #0x20  ; true
    // 0xb93548: r17 = false
    //     0xb93548: add             x17, NULL, #0x30  ; false
    // 0xb9354c: csel            x2, x16, x17, ne
    // 0xb93550: mov             x0, x2
    // 0xb93554: LeaveFrame
    //     0xb93554: mov             SP, fp
    //     0xb93558: ldp             fp, lr, [SP], #0x10
    // 0xb9355c: ret
    //     0xb9355c: ret             
    // 0xb93560: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb93560: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb93564: b               #0xb9349c
  }
  _ _DropdownMenuPainter(/* No info */) {
    // ** addr: 0xdf6364, size: 0x144
    // 0xdf6364: EnterFrame
    //     0xdf6364: stp             fp, lr, [SP, #-0x10]!
    //     0xdf6368: mov             fp, SP
    // 0xdf636c: AllocStack(0x20)
    //     0xdf636c: sub             SP, SP, #0x20
    // 0xdf6370: r4 = 8
    //     0xdf6370: mov             x4, #8
    // 0xdf6374: mov             x7, x1
    // 0xdf6378: stur            x1, [fp, #-8]
    // 0xdf637c: mov             x1, x3
    // 0xdf6380: mov             x3, x5
    // 0xdf6384: stur            x5, [fp, #-0x18]
    // 0xdf6388: mov             x5, x2
    // 0xdf638c: stur            x2, [fp, #-0x10]
    // 0xdf6390: CheckStackOverflow
    //     0xdf6390: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf6394: cmp             SP, x16
    //     0xdf6398: b.ls            #0xdf64a0
    // 0xdf639c: mov             x0, x5
    // 0xdf63a0: StoreField: r7->field_b = r0
    //     0xdf63a0: stur            w0, [x7, #0xb]
    //     0xdf63a4: ldurb           w16, [x7, #-1]
    //     0xdf63a8: ldurb           w17, [x0, #-1]
    //     0xdf63ac: and             x16, x17, x16, lsr #2
    //     0xdf63b0: tst             x16, HEAP, lsr #32
    //     0xdf63b4: b.eq            #0xdf63bc
    //     0xdf63b8: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xdf63bc: StoreField: r7->field_f = r4
    //     0xdf63bc: stur            x4, [x7, #0xf]
    // 0xdf63c0: ArrayStore: r7[0] = r6  ; List_8
    //     0xdf63c0: stur            x6, [x7, #0x17]
    // 0xdf63c4: mov             x0, x3
    // 0xdf63c8: StoreField: r7->field_23 = r0
    //     0xdf63c8: stur            w0, [x7, #0x23]
    //     0xdf63cc: ldurb           w16, [x7, #-1]
    //     0xdf63d0: ldurb           w17, [x0, #-1]
    //     0xdf63d4: and             x16, x17, x16, lsr #2
    //     0xdf63d8: tst             x16, HEAP, lsr #32
    //     0xdf63dc: b.eq            #0xdf63e4
    //     0xdf63e0: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xdf63e4: mov             x0, x1
    // 0xdf63e8: StoreField: r7->field_27 = r0
    //     0xdf63e8: stur            w0, [x7, #0x27]
    //     0xdf63ec: ldurb           w16, [x7, #-1]
    //     0xdf63f0: ldurb           w17, [x0, #-1]
    //     0xdf63f4: and             x16, x17, x16, lsr #2
    //     0xdf63f8: tst             x16, HEAP, lsr #32
    //     0xdf63fc: b.eq            #0xdf6404
    //     0xdf6400: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xdf6404: r1 = _ConstMap len:11
    //     0xdf6404: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa35c0] Map<int, List<BoxShadow>>(11)
    //     0xdf6408: ldr             x1, [x1, #0x5c0]
    // 0xdf640c: r2 = 16
    //     0xdf640c: mov             x2, #0x10
    // 0xdf6410: r0 = []()
    //     0xdf6410: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0xdf6414: stur            x0, [fp, #-0x20]
    // 0xdf6418: r0 = BoxDecoration()
    //     0xdf6418: bl              #0x8a721c  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0xdf641c: mov             x1, x0
    // 0xdf6420: ldur            x0, [fp, #-0x10]
    // 0xdf6424: StoreField: r1->field_7 = r0
    //     0xdf6424: stur            w0, [x1, #7]
    // 0xdf6428: r0 = Instance_BorderRadius
    //     0xdf6428: add             x0, PP, #0xd1, lsl #12  ; [pp+0xd1e18] Obj!BorderRadius@129e371
    //     0xdf642c: ldr             x0, [x0, #0xe18]
    // 0xdf6430: StoreField: r1->field_13 = r0
    //     0xdf6430: stur            w0, [x1, #0x13]
    // 0xdf6434: ldur            x0, [fp, #-0x20]
    // 0xdf6438: ArrayStore: r1[0] = r0  ; List_4
    //     0xdf6438: stur            w0, [x1, #0x17]
    // 0xdf643c: r0 = Instance_BoxShape
    //     0xdf643c: add             x0, PP, #0x17, lsl #12  ; [pp+0x171f8] Obj!BoxShape@12c4921
    //     0xdf6440: ldr             x0, [x0, #0x1f8]
    // 0xdf6444: StoreField: r1->field_23 = r0
    //     0xdf6444: stur            w0, [x1, #0x23]
    // 0xdf6448: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xdf6448: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xdf644c: r0 = createBoxPainter()
    //     0xdf644c: bl              #0x1254fc4  ; [package:flutter/src/painting/box_decoration.dart] BoxDecoration::createBoxPainter
    // 0xdf6450: ldur            x1, [fp, #-8]
    // 0xdf6454: StoreField: r1->field_2b = r0
    //     0xdf6454: stur            w0, [x1, #0x2b]
    //     0xdf6458: ldurb           w16, [x1, #-1]
    //     0xdf645c: ldurb           w17, [x0, #-1]
    //     0xdf6460: and             x16, x17, x16, lsr #2
    //     0xdf6464: tst             x16, HEAP, lsr #32
    //     0xdf6468: b.eq            #0xdf6470
    //     0xdf646c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdf6470: ldur            x0, [fp, #-0x18]
    // 0xdf6474: StoreField: r1->field_7 = r0
    //     0xdf6474: stur            w0, [x1, #7]
    //     0xdf6478: ldurb           w16, [x1, #-1]
    //     0xdf647c: ldurb           w17, [x0, #-1]
    //     0xdf6480: and             x16, x17, x16, lsr #2
    //     0xdf6484: tst             x16, HEAP, lsr #32
    //     0xdf6488: b.eq            #0xdf6490
    //     0xdf648c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdf6490: r0 = Null
    //     0xdf6490: mov             x0, NULL
    // 0xdf6494: LeaveFrame
    //     0xdf6494: mov             SP, fp
    //     0xdf6498: ldp             fp, lr, [SP], #0x10
    // 0xdf649c: ret
    //     0xdf649c: ret             
    // 0xdf64a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf64a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf64a4: b               #0xdf639c
  }
}

// class id: 4959, size: 0x58, field offset: 0x54
class _RenderMenuItem extends RenderProxyBox {

  _ performLayout(/* No info */) {
    // ** addr: 0xbb8cec, size: 0x6c
    // 0xbb8cec: EnterFrame
    //     0xbb8cec: stp             fp, lr, [SP, #-0x10]!
    //     0xbb8cf0: mov             fp, SP
    // 0xbb8cf4: AllocStack(0x18)
    //     0xbb8cf4: sub             SP, SP, #0x18
    // 0xbb8cf8: SetupParameters(_RenderMenuItem this /* r1 => r0, fp-0x8 */)
    //     0xbb8cf8: mov             x0, x1
    //     0xbb8cfc: stur            x1, [fp, #-8]
    // 0xbb8d00: CheckStackOverflow
    //     0xbb8d00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbb8d04: cmp             SP, x16
    //     0xbb8d08: b.ls            #0xbb8d50
    // 0xbb8d0c: mov             x1, x0
    // 0xbb8d10: r0 = performLayout()
    //     0xbb8d10: bl              #0xbba2a4  ; [dart:mixin_deduplication] _MixinApplication10&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin::performLayout
    // 0xbb8d14: ldur            x1, [fp, #-8]
    // 0xbb8d18: r0 = size()
    //     0xbb8d18: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbb8d1c: mov             x1, x0
    // 0xbb8d20: ldur            x0, [fp, #-8]
    // 0xbb8d24: LoadField: r2 = r0->field_53
    //     0xbb8d24: ldur            w2, [x0, #0x53]
    // 0xbb8d28: DecompressPointer r2
    //     0xbb8d28: add             x2, x2, HEAP, lsl #32
    // 0xbb8d2c: stp             x1, x2, [SP]
    // 0xbb8d30: mov             x0, x2
    // 0xbb8d34: ClosureCall
    //     0xbb8d34: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xbb8d38: ldur            x2, [x0, #0x1f]
    //     0xbb8d3c: blr             x2
    // 0xbb8d40: r0 = Null
    //     0xbb8d40: mov             x0, NULL
    // 0xbb8d44: LeaveFrame
    //     0xbb8d44: mov             SP, fp
    //     0xbb8d48: ldp             fp, lr, [SP], #0x10
    // 0xbb8d4c: ret
    //     0xbb8d4c: ret             
    // 0xbb8d50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbb8d50: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbb8d54: b               #0xbb8d0c
  }
}

// class id: 5469, size: 0x18, field offset: 0x14
class _DropdownRoutePageState<C1X0> extends State<C1X0> {

  late ScrollController _scrollController; // offset: 0x14

  _ build(/* No info */) {
    // ** addr: 0xdf6544, size: 0x1e8
    // 0xdf6544: EnterFrame
    //     0xdf6544: stp             fp, lr, [SP, #-0x10]!
    //     0xdf6548: mov             fp, SP
    // 0xdf654c: AllocStack(0x60)
    //     0xdf654c: sub             SP, SP, #0x60
    // 0xdf6550: SetupParameters(_DropdownRoutePageState<C1X0> this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xdf6550: mov             x0, x1
    //     0xdf6554: stur            x1, [fp, #-8]
    //     0xdf6558: mov             x1, x2
    //     0xdf655c: stur            x2, [fp, #-0x10]
    // 0xdf6560: CheckStackOverflow
    //     0xdf6560: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf6564: cmp             SP, x16
    //     0xdf6568: b.ls            #0xdf6714
    // 0xdf656c: r1 = 3
    //     0xdf656c: mov             x1, #3
    // 0xdf6570: r0 = AllocateContext()
    //     0xdf6570: bl              #0x13de838  ; AllocateContextStub
    // 0xdf6574: mov             x2, x0
    // 0xdf6578: ldur            x0, [fp, #-8]
    // 0xdf657c: stur            x2, [fp, #-0x18]
    // 0xdf6580: StoreField: r2->field_f = r0
    //     0xdf6580: stur            w0, [x2, #0xf]
    // 0xdf6584: ldur            x1, [fp, #-0x10]
    // 0xdf6588: r0 = maybeOf()
    //     0xdf6588: bl              #0xcee820  ; [package:flutter/src/widgets/basic.dart] Directionality::maybeOf
    // 0xdf658c: ldur            x4, [fp, #-0x18]
    // 0xdf6590: StoreField: r4->field_13 = r0
    //     0xdf6590: stur            w0, [x4, #0x13]
    //     0xdf6594: ldurb           w16, [x4, #-1]
    //     0xdf6598: ldurb           w17, [x0, #-1]
    //     0xdf659c: and             x16, x17, x16, lsr #2
    //     0xdf65a0: tst             x16, HEAP, lsr #32
    //     0xdf65a4: b.eq            #0xdf65ac
    //     0xdf65a8: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xdf65ac: ldur            x0, [fp, #-8]
    // 0xdf65b0: LoadField: r1 = r0->field_b
    //     0xdf65b0: ldur            w1, [x0, #0xb]
    // 0xdf65b4: DecompressPointer r1
    //     0xdf65b4: add             x1, x1, HEAP, lsl #32
    // 0xdf65b8: cmp             w1, NULL
    // 0xdf65bc: b.eq            #0xdf671c
    // 0xdf65c0: LoadField: r5 = r1->field_f
    //     0xdf65c0: ldur            w5, [x1, #0xf]
    // 0xdf65c4: DecompressPointer r5
    //     0xdf65c4: add             x5, x5, HEAP, lsl #32
    // 0xdf65c8: stur            x5, [fp, #-0x40]
    // 0xdf65cc: LoadField: r6 = r1->field_1b
    //     0xdf65cc: ldur            w6, [x1, #0x1b]
    // 0xdf65d0: DecompressPointer r6
    //     0xdf65d0: add             x6, x6, HEAP, lsl #32
    // 0xdf65d4: stur            x6, [fp, #-0x38]
    // 0xdf65d8: LoadField: r7 = r1->field_13
    //     0xdf65d8: ldur            w7, [x1, #0x13]
    // 0xdf65dc: DecompressPointer r7
    //     0xdf65dc: add             x7, x7, HEAP, lsl #32
    // 0xdf65e0: stur            x7, [fp, #-0x30]
    // 0xdf65e4: LoadField: r8 = r1->field_2b
    //     0xdf65e4: ldur            w8, [x1, #0x2b]
    // 0xdf65e8: DecompressPointer r8
    //     0xdf65e8: add             x8, x8, HEAP, lsl #32
    // 0xdf65ec: stur            x8, [fp, #-0x28]
    // 0xdf65f0: LoadField: r10 = r0->field_13
    //     0xdf65f0: ldur            w10, [x0, #0x13]
    // 0xdf65f4: DecompressPointer r10
    //     0xdf65f4: add             x10, x10, HEAP, lsl #32
    // 0xdf65f8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf65fc: cmp             w10, w16
    // 0xdf6600: b.eq            #0xdf6720
    // 0xdf6604: stur            x10, [fp, #-0x20]
    // 0xdf6608: LoadField: r2 = r0->field_7
    //     0xdf6608: ldur            w2, [x0, #7]
    // 0xdf660c: DecompressPointer r2
    //     0xdf660c: add             x2, x2, HEAP, lsl #32
    // 0xdf6610: r1 = Null
    //     0xdf6610: mov             x1, NULL
    // 0xdf6614: r3 = <C1X0>
    //     0xdf6614: add             x3, PP, #0x11, lsl #12  ; [pp+0x11880] TypeArguments: <C1X0>
    //     0xdf6618: ldr             x3, [x3, #0x880]
    // 0xdf661c: r0 = Null
    //     0xdf661c: mov             x0, NULL
    // 0xdf6620: cmp             x2, x0
    // 0xdf6624: b.eq            #0xdf6634
    // 0xdf6628: r30 = InstantiateTypeArgumentsStub
    //     0xdf6628: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0xdf662c: LoadField: r30 = r30->field_7
    //     0xdf662c: ldur            lr, [lr, #7]
    // 0xdf6630: blr             lr
    // 0xdf6634: mov             x1, x0
    // 0xdf6638: r0 = _DropdownMenu()
    //     0xdf6638: bl              #0xdf672c  ; Allocate_DropdownMenuStub -> _DropdownMenu<X0> (size=0x34)
    // 0xdf663c: mov             x1, x0
    // 0xdf6640: r0 = Instance_EdgeInsets
    //     0xdf6640: add             x0, PP, #0x26, lsl #12  ; [pp+0x26510] Obj!EdgeInsets@129cdb1
    //     0xdf6644: ldr             x0, [x0, #0x510]
    // 0xdf6648: StoreField: r1->field_13 = r0
    //     0xdf6648: stur            w0, [x1, #0x13]
    // 0xdf664c: ldur            x0, [fp, #-0x40]
    // 0xdf6650: StoreField: r1->field_f = r0
    //     0xdf6650: stur            w0, [x1, #0xf]
    // 0xdf6654: ldur            x0, [fp, #-0x38]
    // 0xdf6658: ArrayStore: r1[0] = r0  ; List_4
    //     0xdf6658: stur            w0, [x1, #0x17]
    // 0xdf665c: ldur            x0, [fp, #-0x30]
    // 0xdf6660: StoreField: r1->field_1b = r0
    //     0xdf6660: stur            w0, [x1, #0x1b]
    // 0xdf6664: ldur            x0, [fp, #-0x28]
    // 0xdf6668: StoreField: r1->field_1f = r0
    //     0xdf6668: stur            w0, [x1, #0x1f]
    // 0xdf666c: r0 = true
    //     0xdf666c: add             x0, NULL, #0x20  ; true
    // 0xdf6670: StoreField: r1->field_23 = r0
    //     0xdf6670: stur            w0, [x1, #0x23]
    // 0xdf6674: ldur            x0, [fp, #-0x20]
    // 0xdf6678: StoreField: r1->field_2b = r0
    //     0xdf6678: stur            w0, [x1, #0x2b]
    // 0xdf667c: mov             x0, x1
    // 0xdf6680: ldur            x2, [fp, #-0x18]
    // 0xdf6684: ArrayStore: r2[0] = r0  ; List_4
    //     0xdf6684: stur            w0, [x2, #0x17]
    //     0xdf6688: ldurb           w16, [x2, #-1]
    //     0xdf668c: ldurb           w17, [x0, #-1]
    //     0xdf6690: and             x16, x17, x16, lsr #2
    //     0xdf6694: tst             x16, HEAP, lsr #32
    //     0xdf6698: b.eq            #0xdf66a0
    //     0xdf669c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xdf66a0: r1 = Function '<anonymous closure>':.
    //     0xdf66a0: add             x1, PP, #0xcd, lsl #12  ; [pp+0xcd558] AnonymousClosure: (0xdf6738), in [package:flutter/src/material/dropdown.dart] _DropdownRoutePageState::build (0xdf6544)
    //     0xdf66a4: ldr             x1, [x1, #0x558]
    // 0xdf66a8: r0 = AllocateClosure()
    //     0xdf66a8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf66ac: stur            x0, [fp, #-8]
    // 0xdf66b0: r0 = Builder()
    //     0xdf66b0: bl              #0x858774  ; AllocateBuilderStub -> Builder (size=0x10)
    // 0xdf66b4: mov             x2, x0
    // 0xdf66b8: ldur            x0, [fp, #-8]
    // 0xdf66bc: stur            x2, [fp, #-0x18]
    // 0xdf66c0: StoreField: r2->field_b = r0
    //     0xdf66c0: stur            w0, [x2, #0xb]
    // 0xdf66c4: r1 = <_MediaQueryAspect>
    //     0xdf66c4: add             x1, PP, #0x12, lsl #12  ; [pp+0x12828] TypeArguments: <_MediaQueryAspect>
    //     0xdf66c8: ldr             x1, [x1, #0x828]
    // 0xdf66cc: r0 = MediaQuery()
    //     0xdf66cc: bl              #0xd0af24  ; AllocateMediaQueryStub -> MediaQuery (size=0x18)
    // 0xdf66d0: stur            x0, [fp, #-8]
    // 0xdf66d4: r16 = true
    //     0xdf66d4: add             x16, NULL, #0x20  ; true
    // 0xdf66d8: r30 = true
    //     0xdf66d8: add             lr, NULL, #0x20  ; true
    // 0xdf66dc: stp             lr, x16, [SP, #0x10]
    // 0xdf66e0: r16 = true
    //     0xdf66e0: add             x16, NULL, #0x20  ; true
    // 0xdf66e4: r30 = true
    //     0xdf66e4: add             lr, NULL, #0x20  ; true
    // 0xdf66e8: stp             lr, x16, [SP]
    // 0xdf66ec: mov             x1, x0
    // 0xdf66f0: ldur            x2, [fp, #-0x18]
    // 0xdf66f4: ldur            x3, [fp, #-0x10]
    // 0xdf66f8: r4 = const [0, 0x7, 0x4, 0x3, removeBottom, 0x4, removeLeft, 0x5, removeRight, 0x6, removeTop, 0x3, null]
    //     0xdf66f8: add             x4, PP, #0xcd, lsl #12  ; [pp+0xcd560] List(13) [0, 0x7, 0x4, 0x3, "removeBottom", 0x4, "removeLeft", 0x5, "removeRight", 0x6, "removeTop", 0x3, Null]
    //     0xdf66fc: ldr             x4, [x4, #0x560]
    // 0xdf6700: r0 = MediaQuery.removePadding()
    //     0xdf6700: bl              #0xd0a5a0  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::MediaQuery.removePadding
    // 0xdf6704: ldur            x0, [fp, #-8]
    // 0xdf6708: LeaveFrame
    //     0xdf6708: mov             SP, fp
    //     0xdf670c: ldp             fp, lr, [SP], #0x10
    // 0xdf6710: ret
    //     0xdf6710: ret             
    // 0xdf6714: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf6714: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf6718: b               #0xdf656c
    // 0xdf671c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf671c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf6720: r9 = _scrollController
    //     0xdf6720: add             x9, PP, #0xcd, lsl #12  ; [pp+0xcd550] Field <_DropdownRoutePageState@83005770._scrollController@83005770>: late (offset: 0x14)
    //     0xdf6724: ldr             x9, [x9, #0x550]
    // 0xdf6728: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdf6728: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] CustomSingleChildLayout <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0xdf6738, size: 0x10c
    // 0xdf6738: EnterFrame
    //     0xdf6738: stp             fp, lr, [SP, #-0x10]!
    //     0xdf673c: mov             fp, SP
    // 0xdf6740: AllocStack(0x30)
    //     0xdf6740: sub             SP, SP, #0x30
    // 0xdf6744: SetupParameters([dynamic _ /* r0 */])
    //     0xdf6744: ldr             x0, [fp, #0x18]
    //     0xdf6748: ldur            w4, [x0, #0x17]
    //     0xdf674c: add             x4, x4, HEAP, lsl #32
    //     0xdf6750: stur            x4, [fp, #-0x20]
    // 0xdf6754: CheckStackOverflow
    //     0xdf6754: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf6758: cmp             SP, x16
    //     0xdf675c: b.ls            #0xdf6838
    // 0xdf6760: LoadField: r0 = r4->field_f
    //     0xdf6760: ldur            w0, [x4, #0xf]
    // 0xdf6764: DecompressPointer r0
    //     0xdf6764: add             x0, x0, HEAP, lsl #32
    // 0xdf6768: LoadField: r5 = r0->field_b
    //     0xdf6768: ldur            w5, [x0, #0xb]
    // 0xdf676c: DecompressPointer r5
    //     0xdf676c: add             x5, x5, HEAP, lsl #32
    // 0xdf6770: stur            x5, [fp, #-0x18]
    // 0xdf6774: cmp             w5, NULL
    // 0xdf6778: b.eq            #0xdf6840
    // 0xdf677c: LoadField: r6 = r5->field_1b
    //     0xdf677c: ldur            w6, [x5, #0x1b]
    // 0xdf6780: DecompressPointer r6
    //     0xdf6780: add             x6, x6, HEAP, lsl #32
    // 0xdf6784: stur            x6, [fp, #-0x10]
    // 0xdf6788: LoadField: r7 = r5->field_f
    //     0xdf6788: ldur            w7, [x5, #0xf]
    // 0xdf678c: DecompressPointer r7
    //     0xdf678c: add             x7, x7, HEAP, lsl #32
    // 0xdf6790: stur            x7, [fp, #-8]
    // 0xdf6794: LoadField: r2 = r0->field_7
    //     0xdf6794: ldur            w2, [x0, #7]
    // 0xdf6798: DecompressPointer r2
    //     0xdf6798: add             x2, x2, HEAP, lsl #32
    // 0xdf679c: r1 = Null
    //     0xdf679c: mov             x1, NULL
    // 0xdf67a0: r3 = <C1X0>
    //     0xdf67a0: add             x3, PP, #0x11, lsl #12  ; [pp+0x11880] TypeArguments: <C1X0>
    //     0xdf67a4: ldr             x3, [x3, #0x880]
    // 0xdf67a8: r0 = Null
    //     0xdf67a8: mov             x0, NULL
    // 0xdf67ac: cmp             x2, x0
    // 0xdf67b0: b.eq            #0xdf67c0
    // 0xdf67b4: r30 = InstantiateTypeArgumentsStub
    //     0xdf67b4: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0xdf67b8: LoadField: r30 = r30->field_7
    //     0xdf67b8: ldur            lr, [lr, #7]
    // 0xdf67bc: blr             lr
    // 0xdf67c0: mov             x1, x0
    // 0xdf67c4: ldur            x0, [fp, #-0x20]
    // 0xdf67c8: LoadField: r2 = r0->field_13
    //     0xdf67c8: ldur            w2, [x0, #0x13]
    // 0xdf67cc: DecompressPointer r2
    //     0xdf67cc: add             x2, x2, HEAP, lsl #32
    // 0xdf67d0: stur            x2, [fp, #-0x28]
    // 0xdf67d4: r0 = _DropdownMenuRouteLayout()
    //     0xdf67d4: bl              #0xdf6844  ; Allocate_DropdownMenuRouteLayoutStub -> _DropdownMenuRouteLayout<X0> (size=0x20)
    // 0xdf67d8: mov             x3, x0
    // 0xdf67dc: ldur            x0, [fp, #-0x10]
    // 0xdf67e0: stur            x3, [fp, #-0x30]
    // 0xdf67e4: StoreField: r3->field_f = r0
    //     0xdf67e4: stur            w0, [x3, #0xf]
    // 0xdf67e8: ldur            x0, [fp, #-8]
    // 0xdf67ec: StoreField: r3->field_13 = r0
    //     0xdf67ec: stur            w0, [x3, #0x13]
    // 0xdf67f0: ldur            x0, [fp, #-0x28]
    // 0xdf67f4: ArrayStore: r3[0] = r0  ; List_4
    //     0xdf67f4: stur            w0, [x3, #0x17]
    // 0xdf67f8: ldur            x0, [fp, #-0x18]
    // 0xdf67fc: LoadField: r1 = r0->field_27
    //     0xdf67fc: ldur            w1, [x0, #0x27]
    // 0xdf6800: DecompressPointer r1
    //     0xdf6800: add             x1, x1, HEAP, lsl #32
    // 0xdf6804: ldur            x0, [fp, #-0x20]
    // 0xdf6808: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xdf6808: ldur            w2, [x0, #0x17]
    // 0xdf680c: DecompressPointer r2
    //     0xdf680c: add             x2, x2, HEAP, lsl #32
    // 0xdf6810: r0 = wrap()
    //     0xdf6810: bl              #0x856110  ; [package:flutter/src/widgets/inherited_theme.dart] CapturedThemes::wrap
    // 0xdf6814: stur            x0, [fp, #-8]
    // 0xdf6818: r0 = CustomSingleChildLayout()
    //     0xdf6818: bl              #0xd70b7c  ; AllocateCustomSingleChildLayoutStub -> CustomSingleChildLayout (size=0x14)
    // 0xdf681c: ldur            x1, [fp, #-0x30]
    // 0xdf6820: StoreField: r0->field_f = r1
    //     0xdf6820: stur            w1, [x0, #0xf]
    // 0xdf6824: ldur            x1, [fp, #-8]
    // 0xdf6828: StoreField: r0->field_b = r1
    //     0xdf6828: stur            w1, [x0, #0xb]
    // 0xdf682c: LeaveFrame
    //     0xdf682c: mov             SP, fp
    //     0xdf6830: ldp             fp, lr, [SP], #0x10
    // 0xdf6834: ret
    //     0xdf6834: ret             
    // 0xdf6838: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf6838: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf683c: b               #0xdf6760
    // 0xdf6840: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf6840: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0xf90a94, size: 0x104
    // 0xf90a94: EnterFrame
    //     0xf90a94: stp             fp, lr, [SP, #-0x10]!
    //     0xf90a98: mov             fp, SP
    // 0xf90a9c: AllocStack(0x20)
    //     0xf90a9c: sub             SP, SP, #0x20
    // 0xf90aa0: SetupParameters(_DropdownRoutePageState<C1X0> this /* r1 => r0, fp-0x8 */)
    //     0xf90aa0: mov             x0, x1
    //     0xf90aa4: stur            x1, [fp, #-8]
    // 0xf90aa8: CheckStackOverflow
    //     0xf90aa8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf90aac: cmp             SP, x16
    //     0xf90ab0: b.ls            #0xf90b7c
    // 0xf90ab4: LoadField: r1 = r0->field_b
    //     0xf90ab4: ldur            w1, [x0, #0xb]
    // 0xf90ab8: DecompressPointer r1
    //     0xf90ab8: add             x1, x1, HEAP, lsl #32
    // 0xf90abc: cmp             w1, NULL
    // 0xf90ac0: b.eq            #0xf90b84
    // 0xf90ac4: LoadField: r2 = r1->field_f
    //     0xf90ac4: ldur            w2, [x1, #0xf]
    // 0xf90ac8: DecompressPointer r2
    //     0xf90ac8: add             x2, x2, HEAP, lsl #32
    // 0xf90acc: LoadField: r3 = r1->field_1b
    //     0xf90acc: ldur            w3, [x1, #0x1b]
    // 0xf90ad0: DecompressPointer r3
    //     0xf90ad0: add             x3, x3, HEAP, lsl #32
    // 0xf90ad4: LoadField: r4 = r1->field_13
    //     0xf90ad4: ldur            w4, [x1, #0x13]
    // 0xf90ad8: DecompressPointer r4
    //     0xf90ad8: add             x4, x4, HEAP, lsl #32
    // 0xf90adc: LoadField: d0 = r4->field_1f
    //     0xf90adc: ldur            d0, [x4, #0x1f]
    // 0xf90ae0: LoadField: r4 = r1->field_1f
    //     0xf90ae0: ldur            x4, [x1, #0x1f]
    // 0xf90ae4: mov             x1, x2
    // 0xf90ae8: mov             x2, x3
    // 0xf90aec: mov             x3, x4
    // 0xf90af0: r0 = getMenuLimits()
    //     0xf90af0: bl              #0xdf55fc  ; [package:flutter/src/material/dropdown.dart] _DropdownRoute::getMenuLimits
    // 0xf90af4: LoadField: d0 = r0->field_f
    //     0xf90af4: ldur            d0, [x0, #0xf]
    // 0xf90af8: r0 = inline_Allocate_Double()
    //     0xf90af8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xf90afc: add             x0, x0, #0x10
    //     0xf90b00: cmp             x1, x0
    //     0xf90b04: b.ls            #0xf90b88
    //     0xf90b08: str             x0, [THR, #0x60]  ; THR::top
    //     0xf90b0c: sub             x0, x0, #0xf
    //     0xf90b10: mov             x1, #0xe19c
    //     0xf90b14: movk            x1, #3, lsl #16
    //     0xf90b18: stur            x1, [x0, #-1]
    // 0xf90b1c: dmb             ishst
    // 0xf90b20: StoreField: r0->field_7 = d0
    //     0xf90b20: stur            d0, [x0, #7]
    // 0xf90b24: stur            x0, [fp, #-0x10]
    // 0xf90b28: r0 = ScrollController()
    //     0xf90b28: bl              #0x86d97c  ; AllocateScrollControllerStub -> ScrollController (size=0x40)
    // 0xf90b2c: stur            x0, [fp, #-0x18]
    // 0xf90b30: ldur            x16, [fp, #-0x10]
    // 0xf90b34: str             x16, [SP]
    // 0xf90b38: mov             x1, x0
    // 0xf90b3c: r4 = const [0, 0x2, 0x1, 0x1, initialScrollOffset, 0x1, null]
    //     0xf90b3c: add             x4, PP, #0xcd, lsl #12  ; [pp+0xcd568] List(7) [0, 0x2, 0x1, 0x1, "initialScrollOffset", 0x1, Null]
    //     0xf90b40: ldr             x4, [x4, #0x568]
    // 0xf90b44: r0 = ScrollController()
    //     0xf90b44: bl              #0x86d884  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::ScrollController
    // 0xf90b48: ldur            x0, [fp, #-0x18]
    // 0xf90b4c: ldur            x1, [fp, #-8]
    // 0xf90b50: StoreField: r1->field_13 = r0
    //     0xf90b50: stur            w0, [x1, #0x13]
    //     0xf90b54: ldurb           w16, [x1, #-1]
    //     0xf90b58: ldurb           w17, [x0, #-1]
    //     0xf90b5c: and             x16, x17, x16, lsr #2
    //     0xf90b60: tst             x16, HEAP, lsr #32
    //     0xf90b64: b.eq            #0xf90b6c
    //     0xf90b68: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf90b6c: r0 = Null
    //     0xf90b6c: mov             x0, NULL
    // 0xf90b70: LeaveFrame
    //     0xf90b70: mov             SP, fp
    //     0xf90b74: ldp             fp, lr, [SP], #0x10
    // 0xf90b78: ret
    //     0xf90b78: ret             
    // 0xf90b7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf90b7c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf90b80: b               #0xf90ab4
    // 0xf90b84: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf90b84: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf90b88: SaveReg d0
    //     0xf90b88: str             q0, [SP, #-0x10]!
    // 0xf90b8c: r0 = AllocateDouble()
    //     0xf90b8c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xf90b90: RestoreReg d0
    //     0xf90b90: ldr             q0, [SP], #0x10
    // 0xf90b94: b               #0xf90b20
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10e5b78, size: 0x54
    // 0x10e5b78: EnterFrame
    //     0x10e5b78: stp             fp, lr, [SP, #-0x10]!
    //     0x10e5b7c: mov             fp, SP
    // 0x10e5b80: CheckStackOverflow
    //     0x10e5b80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e5b84: cmp             SP, x16
    //     0x10e5b88: b.ls            #0x10e5bb8
    // 0x10e5b8c: LoadField: r0 = r1->field_13
    //     0x10e5b8c: ldur            w0, [x1, #0x13]
    // 0x10e5b90: DecompressPointer r0
    //     0x10e5b90: add             x0, x0, HEAP, lsl #32
    // 0x10e5b94: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10e5b98: cmp             w0, w16
    // 0x10e5b9c: b.eq            #0x10e5bc0
    // 0x10e5ba0: mov             x1, x0
    // 0x10e5ba4: r0 = dispose()
    //     0x10e5ba4: bl              #0x10ef540  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::dispose
    // 0x10e5ba8: r0 = Null
    //     0x10e5ba8: mov             x0, NULL
    // 0x10e5bac: LeaveFrame
    //     0x10e5bac: mov             SP, fp
    //     0x10e5bb0: ldp             fp, lr, [SP], #0x10
    // 0x10e5bb4: ret
    //     0x10e5bb4: ret             
    // 0x10e5bb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e5bb8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e5bbc: b               #0x10e5b8c
    // 0x10e5bc0: r9 = _scrollController
    //     0x10e5bc0: add             x9, PP, #0xcd, lsl #12  ; [pp+0xcd550] Field <_DropdownRoutePageState@83005770._scrollController@83005770>: late (offset: 0x14)
    //     0x10e5bc4: ldr             x9, [x9, #0x550]
    // 0x10e5bc8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x10e5bc8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 5470, size: 0x1c, field offset: 0x14
class _DropdownMenuState<C1X0> extends State<C1X0> {

  late final CurvedAnimation _fadeOpacity; // offset: 0x14
  late final CurvedAnimation _resize; // offset: 0x18

  _ build(/* No info */) {
    // ** addr: 0xdf5aec, size: 0x5a4
    // 0xdf5aec: EnterFrame
    //     0xdf5aec: stp             fp, lr, [SP, #-0x10]!
    //     0xdf5af0: mov             fp, SP
    // 0xdf5af4: AllocStack(0xa8)
    //     0xdf5af4: sub             SP, SP, #0xa8
    // 0xdf5af8: SetupParameters(_DropdownMenuState<C1X0> this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xdf5af8: mov             x0, x2
    //     0xdf5afc: stur            x2, [fp, #-0x10]
    //     0xdf5b00: mov             x2, x1
    //     0xdf5b04: stur            x1, [fp, #-8]
    // 0xdf5b08: CheckStackOverflow
    //     0xdf5b08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf5b0c: cmp             SP, x16
    //     0xdf5b10: b.ls            #0xdf6050
    // 0xdf5b14: mov             x1, x0
    // 0xdf5b18: r0 = of()
    //     0xdf5b18: bl              #0xd0bbf8  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0xdf5b1c: mov             x1, x0
    // 0xdf5b20: ldur            x0, [fp, #-8]
    // 0xdf5b24: stur            x1, [fp, #-0x20]
    // 0xdf5b28: LoadField: r2 = r0->field_b
    //     0xdf5b28: ldur            w2, [x0, #0xb]
    // 0xdf5b2c: DecompressPointer r2
    //     0xdf5b2c: add             x2, x2, HEAP, lsl #32
    // 0xdf5b30: cmp             w2, NULL
    // 0xdf5b34: b.eq            #0xdf6058
    // 0xdf5b38: LoadField: r3 = r2->field_f
    //     0xdf5b38: ldur            w3, [x2, #0xf]
    // 0xdf5b3c: DecompressPointer r3
    //     0xdf5b3c: add             x3, x3, HEAP, lsl #32
    // 0xdf5b40: stur            x3, [fp, #-0x18]
    // 0xdf5b44: r1 = 1
    //     0xdf5b44: mov             x1, #1
    // 0xdf5b48: r0 = AllocateContext()
    //     0xdf5b48: bl              #0x13de838  ; AllocateContextStub
    // 0xdf5b4c: mov             x3, x0
    // 0xdf5b50: ldur            x0, [fp, #-0x18]
    // 0xdf5b54: stur            x3, [fp, #-0x28]
    // 0xdf5b58: StoreField: r3->field_f = r0
    //     0xdf5b58: stur            w0, [x3, #0xf]
    // 0xdf5b5c: r1 = <Widget>
    //     0xdf5b5c: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xdf5b60: r2 = 0
    //     0xdf5b60: mov             x2, #0
    // 0xdf5b64: r0 = _GrowableList()
    //     0xdf5b64: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xdf5b68: mov             x4, x0
    // 0xdf5b6c: ldur            x0, [fp, #-0x18]
    // 0xdf5b70: stur            x4, [fp, #-0x68]
    // 0xdf5b74: LoadField: r5 = r0->field_97
    //     0xdf5b74: ldur            w5, [x0, #0x97]
    // 0xdf5b78: DecompressPointer r5
    //     0xdf5b78: add             x5, x5, HEAP, lsl #32
    // 0xdf5b7c: ldur            x6, [fp, #-8]
    // 0xdf5b80: stur            x5, [fp, #-0x60]
    // 0xdf5b84: LoadField: r7 = r6->field_7
    //     0xdf5b84: ldur            w7, [x6, #7]
    // 0xdf5b88: DecompressPointer r7
    //     0xdf5b88: add             x7, x7, HEAP, lsl #32
    // 0xdf5b8c: stur            x7, [fp, #-0x58]
    // 0xdf5b90: r8 = 0
    //     0xdf5b90: mov             x8, #0
    // 0xdf5b94: stur            x8, [fp, #-0x50]
    // 0xdf5b98: CheckStackOverflow
    //     0xdf5b98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf5b9c: cmp             SP, x16
    //     0xdf5ba0: b.ls            #0xdf605c
    // 0xdf5ba4: LoadField: r1 = r5->field_b
    //     0xdf5ba4: ldur            w1, [x5, #0xb]
    // 0xdf5ba8: r2 = LoadInt32Instr(r1)
    //     0xdf5ba8: sbfx            x2, x1, #1, #0x1f
    // 0xdf5bac: cmp             x8, x2
    // 0xdf5bb0: b.ge            #0xdf5d00
    // 0xdf5bb4: LoadField: r1 = r6->field_b
    //     0xdf5bb4: ldur            w1, [x6, #0xb]
    // 0xdf5bb8: DecompressPointer r1
    //     0xdf5bb8: add             x1, x1, HEAP, lsl #32
    // 0xdf5bbc: cmp             w1, NULL
    // 0xdf5bc0: b.eq            #0xdf6064
    // 0xdf5bc4: LoadField: r9 = r1->field_f
    //     0xdf5bc4: ldur            w9, [x1, #0xf]
    // 0xdf5bc8: DecompressPointer r9
    //     0xdf5bc8: add             x9, x9, HEAP, lsl #32
    // 0xdf5bcc: stur            x9, [fp, #-0x48]
    // 0xdf5bd0: ArrayLoad: r10 = r1[0]  ; List_4
    //     0xdf5bd0: ldur            w10, [x1, #0x17]
    // 0xdf5bd4: DecompressPointer r10
    //     0xdf5bd4: add             x10, x10, HEAP, lsl #32
    // 0xdf5bd8: stur            x10, [fp, #-0x40]
    // 0xdf5bdc: LoadField: r11 = r1->field_1b
    //     0xdf5bdc: ldur            w11, [x1, #0x1b]
    // 0xdf5be0: DecompressPointer r11
    //     0xdf5be0: add             x11, x11, HEAP, lsl #32
    // 0xdf5be4: stur            x11, [fp, #-0x38]
    // 0xdf5be8: LoadField: r12 = r1->field_2b
    //     0xdf5be8: ldur            w12, [x1, #0x2b]
    // 0xdf5bec: DecompressPointer r12
    //     0xdf5bec: add             x12, x12, HEAP, lsl #32
    // 0xdf5bf0: mov             x2, x7
    // 0xdf5bf4: stur            x12, [fp, #-0x30]
    // 0xdf5bf8: r1 = Null
    //     0xdf5bf8: mov             x1, NULL
    // 0xdf5bfc: r3 = <C1X0>
    //     0xdf5bfc: add             x3, PP, #0x11, lsl #12  ; [pp+0x11880] TypeArguments: <C1X0>
    //     0xdf5c00: ldr             x3, [x3, #0x880]
    // 0xdf5c04: r0 = Null
    //     0xdf5c04: mov             x0, NULL
    // 0xdf5c08: cmp             x2, x0
    // 0xdf5c0c: b.eq            #0xdf5c1c
    // 0xdf5c10: r30 = InstantiateTypeArgumentsStub
    //     0xdf5c10: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0xdf5c14: LoadField: r30 = r30->field_7
    //     0xdf5c14: ldur            lr, [lr, #7]
    // 0xdf5c18: blr             lr
    // 0xdf5c1c: mov             x1, x0
    // 0xdf5c20: r0 = _DropdownMenuItemButton()
    //     0xdf5c20: bl              #0xdf64b4  ; Allocate_DropdownMenuItemButtonStub -> _DropdownMenuItemButton<X0> (size=0x34)
    // 0xdf5c24: mov             x2, x0
    // 0xdf5c28: r0 = Instance_EdgeInsets
    //     0xdf5c28: add             x0, PP, #0x26, lsl #12  ; [pp+0x26510] Obj!EdgeInsets@129cdb1
    //     0xdf5c2c: ldr             x0, [x0, #0x510]
    // 0xdf5c30: stur            x2, [fp, #-0x78]
    // 0xdf5c34: ArrayStore: r2[0] = r0  ; List_4
    //     0xdf5c34: stur            w0, [x2, #0x17]
    // 0xdf5c38: ldur            x1, [fp, #-0x48]
    // 0xdf5c3c: StoreField: r2->field_f = r1
    //     0xdf5c3c: stur            w1, [x2, #0xf]
    // 0xdf5c40: ldur            x1, [fp, #-0x40]
    // 0xdf5c44: StoreField: r2->field_1b = r1
    //     0xdf5c44: stur            w1, [x2, #0x1b]
    // 0xdf5c48: ldur            x1, [fp, #-0x38]
    // 0xdf5c4c: StoreField: r2->field_1f = r1
    //     0xdf5c4c: stur            w1, [x2, #0x1f]
    // 0xdf5c50: ldur            x3, [fp, #-0x50]
    // 0xdf5c54: StoreField: r2->field_23 = r3
    //     0xdf5c54: stur            x3, [x2, #0x23]
    // 0xdf5c58: r4 = true
    //     0xdf5c58: add             x4, NULL, #0x20  ; true
    // 0xdf5c5c: StoreField: r2->field_2b = r4
    //     0xdf5c5c: stur            w4, [x2, #0x2b]
    // 0xdf5c60: ldur            x1, [fp, #-0x30]
    // 0xdf5c64: StoreField: r2->field_13 = r1
    //     0xdf5c64: stur            w1, [x2, #0x13]
    // 0xdf5c68: ldur            x5, [fp, #-0x68]
    // 0xdf5c6c: LoadField: r1 = r5->field_b
    //     0xdf5c6c: ldur            w1, [x5, #0xb]
    // 0xdf5c70: LoadField: r6 = r5->field_f
    //     0xdf5c70: ldur            w6, [x5, #0xf]
    // 0xdf5c74: DecompressPointer r6
    //     0xdf5c74: add             x6, x6, HEAP, lsl #32
    // 0xdf5c78: LoadField: r7 = r6->field_b
    //     0xdf5c78: ldur            w7, [x6, #0xb]
    // 0xdf5c7c: r6 = LoadInt32Instr(r1)
    //     0xdf5c7c: sbfx            x6, x1, #1, #0x1f
    // 0xdf5c80: stur            x6, [fp, #-0x70]
    // 0xdf5c84: r1 = LoadInt32Instr(r7)
    //     0xdf5c84: sbfx            x1, x7, #1, #0x1f
    // 0xdf5c88: cmp             x6, x1
    // 0xdf5c8c: b.ne            #0xdf5c98
    // 0xdf5c90: mov             x1, x5
    // 0xdf5c94: r0 = _growToNextCapacity()
    //     0xdf5c94: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xdf5c98: ldur            x3, [fp, #-0x68]
    // 0xdf5c9c: ldur            x2, [fp, #-0x50]
    // 0xdf5ca0: ldur            x4, [fp, #-0x70]
    // 0xdf5ca4: add             x0, x4, #1
    // 0xdf5ca8: lsl             x1, x0, #1
    // 0xdf5cac: StoreField: r3->field_b = r1
    //     0xdf5cac: stur            w1, [x3, #0xb]
    // 0xdf5cb0: LoadField: r1 = r3->field_f
    //     0xdf5cb0: ldur            w1, [x3, #0xf]
    // 0xdf5cb4: DecompressPointer r1
    //     0xdf5cb4: add             x1, x1, HEAP, lsl #32
    // 0xdf5cb8: ldur            x0, [fp, #-0x78]
    // 0xdf5cbc: ArrayStore: r1[r4] = r0  ; List_4
    //     0xdf5cbc: add             x25, x1, x4, lsl #2
    //     0xdf5cc0: add             x25, x25, #0xf
    //     0xdf5cc4: str             w0, [x25]
    //     0xdf5cc8: tbz             w0, #0, #0xdf5ce4
    //     0xdf5ccc: ldurb           w16, [x1, #-1]
    //     0xdf5cd0: ldurb           w17, [x0, #-1]
    //     0xdf5cd4: and             x16, x17, x16, lsr #2
    //     0xdf5cd8: tst             x16, HEAP, lsr #32
    //     0xdf5cdc: b.eq            #0xdf5ce4
    //     0xdf5ce0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdf5ce4: add             x8, x2, #1
    // 0xdf5ce8: ldur            x6, [fp, #-8]
    // 0xdf5cec: ldur            x0, [fp, #-0x18]
    // 0xdf5cf0: mov             x4, x3
    // 0xdf5cf4: ldur            x5, [fp, #-0x60]
    // 0xdf5cf8: ldur            x7, [fp, #-0x58]
    // 0xdf5cfc: b               #0xdf5b94
    // 0xdf5d00: mov             x0, x6
    // 0xdf5d04: mov             x3, x4
    // 0xdf5d08: LoadField: r2 = r0->field_13
    //     0xdf5d08: ldur            w2, [x0, #0x13]
    // 0xdf5d0c: DecompressPointer r2
    //     0xdf5d0c: add             x2, x2, HEAP, lsl #32
    // 0xdf5d10: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf5d14: cmp             w2, w16
    // 0xdf5d18: b.eq            #0xdf6068
    // 0xdf5d1c: stur            x2, [fp, #-0x30]
    // 0xdf5d20: LoadField: r1 = r0->field_b
    //     0xdf5d20: ldur            w1, [x0, #0xb]
    // 0xdf5d24: DecompressPointer r1
    //     0xdf5d24: add             x1, x1, HEAP, lsl #32
    // 0xdf5d28: cmp             w1, NULL
    // 0xdf5d2c: b.eq            #0xdf6074
    // 0xdf5d30: LoadField: r4 = r1->field_1f
    //     0xdf5d30: ldur            w4, [x1, #0x1f]
    // 0xdf5d34: DecompressPointer r4
    //     0xdf5d34: add             x4, x4, HEAP, lsl #32
    // 0xdf5d38: cmp             w4, NULL
    // 0xdf5d3c: b.ne            #0xdf5d58
    // 0xdf5d40: ldur            x1, [fp, #-0x10]
    // 0xdf5d44: r0 = of()
    //     0xdf5d44: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xdf5d48: LoadField: r1 = r0->field_37
    //     0xdf5d48: ldur            w1, [x0, #0x37]
    // 0xdf5d4c: DecompressPointer r1
    //     0xdf5d4c: add             x1, x1, HEAP, lsl #32
    // 0xdf5d50: mov             x6, x1
    // 0xdf5d54: b               #0xdf5d5c
    // 0xdf5d58: mov             x6, x4
    // 0xdf5d5c: ldur            x0, [fp, #-8]
    // 0xdf5d60: ldur            x5, [fp, #-0x20]
    // 0xdf5d64: ldur            x4, [fp, #-0x18]
    // 0xdf5d68: ldur            x3, [fp, #-0x30]
    // 0xdf5d6c: stur            x6, [fp, #-0x40]
    // 0xdf5d70: LoadField: r7 = r4->field_a3
    //     0xdf5d70: ldur            x7, [x4, #0xa3]
    // 0xdf5d74: stur            x7, [fp, #-0x50]
    // 0xdf5d78: ArrayLoad: r8 = r0[0]  ; List_4
    //     0xdf5d78: ldur            w8, [x0, #0x17]
    // 0xdf5d7c: DecompressPointer r8
    //     0xdf5d7c: add             x8, x8, HEAP, lsl #32
    // 0xdf5d80: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf5d84: cmp             w8, w16
    // 0xdf5d88: b.eq            #0xdf6078
    // 0xdf5d8c: stur            x8, [fp, #-0x38]
    // 0xdf5d90: LoadField: r1 = r0->field_b
    //     0xdf5d90: ldur            w1, [x0, #0xb]
    // 0xdf5d94: DecompressPointer r1
    //     0xdf5d94: add             x1, x1, HEAP, lsl #32
    // 0xdf5d98: cmp             w1, NULL
    // 0xdf5d9c: b.eq            #0xdf6084
    // 0xdf5da0: ldur            x2, [fp, #-0x28]
    // 0xdf5da4: r1 = Function '<anonymous closure>':.
    //     0xdf5da4: add             x1, PP, #0xd1, lsl #12  ; [pp+0xd1de0] AnonymousClosure: (0xdf64c0), in [package:flutter/src/material/dropdown.dart] _DropdownMenuState::build (0xdf5aec)
    //     0xdf5da8: ldr             x1, [x1, #0xde0]
    // 0xdf5dac: r0 = AllocateClosure()
    //     0xdf5dac: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf5db0: stur            x0, [fp, #-0x28]
    // 0xdf5db4: r0 = _DropdownMenuPainter()
    //     0xdf5db4: bl              #0xdf64a8  ; Allocate_DropdownMenuPainterStub -> _DropdownMenuPainter (size=0x30)
    // 0xdf5db8: mov             x1, x0
    // 0xdf5dbc: ldur            x2, [fp, #-0x40]
    // 0xdf5dc0: ldur            x3, [fp, #-0x28]
    // 0xdf5dc4: ldur            x5, [fp, #-0x38]
    // 0xdf5dc8: ldur            x6, [fp, #-0x50]
    // 0xdf5dcc: stur            x0, [fp, #-0x28]
    // 0xdf5dd0: r0 = _DropdownMenuPainter()
    //     0xdf5dd0: bl              #0xdf6364  ; [package:flutter/src/material/dropdown.dart] _DropdownMenuPainter::_DropdownMenuPainter
    // 0xdf5dd4: ldur            x1, [fp, #-0x20]
    // 0xdf5dd8: r0 = LoadClassIdInstr(r1)
    //     0xdf5dd8: ldur            x0, [x1, #-1]
    //     0xdf5ddc: ubfx            x0, x0, #0xc, #0x14
    // 0xdf5de0: r0 = GDT[cid_x0 + 0x15d4d]()
    //     0xdf5de0: mov             x17, #0x5d4d
    //     0xdf5de4: movk            x17, #1, lsl #16
    //     0xdf5de8: add             lr, x0, x17
    //     0xdf5dec: ldr             lr, [x21, lr, lsl #3]
    //     0xdf5df0: blr             lr
    // 0xdf5df4: mov             x2, x0
    // 0xdf5df8: ldur            x0, [fp, #-8]
    // 0xdf5dfc: stur            x2, [fp, #-0x38]
    // 0xdf5e00: LoadField: r1 = r0->field_b
    //     0xdf5e00: ldur            w1, [x0, #0xb]
    // 0xdf5e04: DecompressPointer r1
    //     0xdf5e04: add             x1, x1, HEAP, lsl #32
    // 0xdf5e08: cmp             w1, NULL
    // 0xdf5e0c: b.eq            #0xdf6088
    // 0xdf5e10: ldur            x1, [fp, #-0x18]
    // 0xdf5e14: LoadField: r3 = r1->field_b7
    //     0xdf5e14: ldur            w3, [x1, #0xb7]
    // 0xdf5e18: DecompressPointer r3
    //     0xdf5e18: add             x3, x3, HEAP, lsl #32
    // 0xdf5e1c: ldur            x1, [fp, #-0x10]
    // 0xdf5e20: stur            x3, [fp, #-0x20]
    // 0xdf5e24: r0 = of()
    //     0xdf5e24: bl              #0xd3827c  ; [package:flutter/src/widgets/scroll_configuration.dart] ScrollConfiguration::of
    // 0xdf5e28: ldur            x1, [fp, #-0x10]
    // 0xdf5e2c: stur            x0, [fp, #-0x10]
    // 0xdf5e30: r0 = of()
    //     0xdf5e30: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xdf5e34: ldur            x1, [fp, #-0x10]
    // 0xdf5e38: r0 = LoadClassIdInstr(r1)
    //     0xdf5e38: ldur            x0, [x1, #-1]
    //     0xdf5e3c: ubfx            x0, x0, #0xc, #0x14
    // 0xdf5e40: r16 = false
    //     0xdf5e40: add             x16, NULL, #0x30  ; false
    // 0xdf5e44: r30 = Instance_ClampingScrollPhysics
    //     0xdf5e44: add             lr, PP, #0x8c, lsl #12  ; [pp+0x8c758] Obj!ClampingScrollPhysics@129b591
    //     0xdf5e48: ldr             lr, [lr, #0x758]
    // 0xdf5e4c: stp             lr, x16, [SP, #8]
    // 0xdf5e50: r16 = Instance_TargetPlatform
    //     0xdf5e50: add             x16, PP, #0x12, lsl #12  ; [pp+0x12940] Obj!TargetPlatform@12c5e81
    //     0xdf5e54: ldr             x16, [x16, #0x940]
    // 0xdf5e58: str             x16, [SP]
    // 0xdf5e5c: r2 = false
    //     0xdf5e5c: add             x2, NULL, #0x30  ; false
    // 0xdf5e60: r4 = const [0, 0x5, 0x3, 0x2, overscroll, 0x2, physics, 0x3, platform, 0x4, null]
    //     0xdf5e60: add             x4, PP, #0xd1, lsl #12  ; [pp+0xd1de8] List(11) [0, 0x5, 0x3, 0x2, "overscroll", 0x2, "physics", 0x3, "platform", 0x4, Null]
    //     0xdf5e64: ldr             x4, [x4, #0xde8]
    // 0xdf5e68: r0 = GDT[cid_x0 + -0xffe]()
    //     0xdf5e68: sub             lr, x0, #0xffe
    //     0xdf5e6c: ldr             lr, [x21, lr, lsl #3]
    //     0xdf5e70: blr             lr
    // 0xdf5e74: mov             x1, x0
    // 0xdf5e78: ldur            x0, [fp, #-8]
    // 0xdf5e7c: stur            x1, [fp, #-0x10]
    // 0xdf5e80: LoadField: r2 = r0->field_b
    //     0xdf5e80: ldur            w2, [x0, #0xb]
    // 0xdf5e84: DecompressPointer r2
    //     0xdf5e84: add             x2, x2, HEAP, lsl #32
    // 0xdf5e88: cmp             w2, NULL
    // 0xdf5e8c: b.eq            #0xdf608c
    // 0xdf5e90: LoadField: r0 = r2->field_2b
    //     0xdf5e90: ldur            w0, [x2, #0x2b]
    // 0xdf5e94: DecompressPointer r0
    //     0xdf5e94: add             x0, x0, HEAP, lsl #32
    // 0xdf5e98: stur            x0, [fp, #-8]
    // 0xdf5e9c: r0 = ListView()
    //     0xdf5e9c: bl              #0xd8c860  ; AllocateListViewStub -> ListView (size=0x6c)
    // 0xdf5ea0: stur            x0, [fp, #-0x18]
    // 0xdf5ea4: r16 = true
    //     0xdf5ea4: add             x16, NULL, #0x20  ; true
    // 0xdf5ea8: r30 = Instance_EdgeInsets
    //     0xdf5ea8: add             lr, PP, #0x26, lsl #12  ; [pp+0x262d8] Obj!EdgeInsets@129d5f1
    //     0xdf5eac: ldr             lr, [lr, #0x2d8]
    // 0xdf5eb0: stp             lr, x16, [SP, #8]
    // 0xdf5eb4: r16 = true
    //     0xdf5eb4: add             x16, NULL, #0x20  ; true
    // 0xdf5eb8: str             x16, [SP]
    // 0xdf5ebc: mov             x1, x0
    // 0xdf5ec0: ldur            x2, [fp, #-0x68]
    // 0xdf5ec4: r4 = const [0, 0x5, 0x3, 0x2, padding, 0x3, primary, 0x2, shrinkWrap, 0x4, null]
    //     0xdf5ec4: add             x4, PP, #0xd1, lsl #12  ; [pp+0xd1df0] List(11) [0, 0x5, 0x3, 0x2, "padding", 0x3, "primary", 0x2, "shrinkWrap", 0x4, Null]
    //     0xdf5ec8: ldr             x4, [x4, #0xdf0]
    // 0xdf5ecc: r0 = ListView()
    //     0xdf5ecc: bl              #0xdf60a8  ; [package:flutter/src/widgets/scroll_view.dart] ListView::ListView
    // 0xdf5ed0: r0 = Scrollbar()
    //     0xdf5ed0: bl              #0xdf609c  ; AllocateScrollbarStub -> Scrollbar (size=0x30)
    // 0xdf5ed4: mov             x1, x0
    // 0xdf5ed8: ldur            x0, [fp, #-0x18]
    // 0xdf5edc: stur            x1, [fp, #-0x40]
    // 0xdf5ee0: StoreField: r1->field_b = r0
    //     0xdf5ee0: stur            w0, [x1, #0xb]
    // 0xdf5ee4: r0 = true
    //     0xdf5ee4: add             x0, NULL, #0x20  ; true
    // 0xdf5ee8: StoreField: r1->field_13 = r0
    //     0xdf5ee8: stur            w0, [x1, #0x13]
    // 0xdf5eec: r0 = PrimaryScrollController()
    //     0xdf5eec: bl              #0xdf6090  ; AllocatePrimaryScrollControllerStub -> PrimaryScrollController (size=0x1c)
    // 0xdf5ef0: mov             x1, x0
    // 0xdf5ef4: ldur            x0, [fp, #-8]
    // 0xdf5ef8: stur            x1, [fp, #-0x18]
    // 0xdf5efc: StoreField: r1->field_f = r0
    //     0xdf5efc: stur            w0, [x1, #0xf]
    // 0xdf5f00: r0 = _ConstSet len:3
    //     0xdf5f00: add             x0, PP, #0x90, lsl #12  ; [pp+0x90978] Set<TargetPlatform>(3)
    //     0xdf5f04: ldr             x0, [x0, #0x978]
    // 0xdf5f08: ArrayStore: r1[0] = r0  ; List_4
    //     0xdf5f08: stur            w0, [x1, #0x17]
    // 0xdf5f0c: r0 = Instance_Axis
    //     0xdf5f0c: ldr             x0, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xdf5f10: StoreField: r1->field_13 = r0
    //     0xdf5f10: stur            w0, [x1, #0x13]
    // 0xdf5f14: ldur            x0, [fp, #-0x40]
    // 0xdf5f18: StoreField: r1->field_b = r0
    //     0xdf5f18: stur            w0, [x1, #0xb]
    // 0xdf5f1c: r0 = ScrollConfiguration()
    //     0xdf5f1c: bl              #0xde3754  ; AllocateScrollConfigurationStub -> ScrollConfiguration (size=0x14)
    // 0xdf5f20: mov             x1, x0
    // 0xdf5f24: ldur            x0, [fp, #-0x10]
    // 0xdf5f28: stur            x1, [fp, #-8]
    // 0xdf5f2c: StoreField: r1->field_f = r0
    //     0xdf5f2c: stur            w0, [x1, #0xf]
    // 0xdf5f30: ldur            x0, [fp, #-0x18]
    // 0xdf5f34: StoreField: r1->field_b = r0
    //     0xdf5f34: stur            w0, [x1, #0xb]
    // 0xdf5f38: r0 = Material()
    //     0xdf5f38: bl              #0x8a54b0  ; AllocateMaterialStub -> Material (size=0x44)
    // 0xdf5f3c: mov             x1, x0
    // 0xdf5f40: r0 = Instance_MaterialType
    //     0xdf5f40: add             x0, PP, #0x8c, lsl #12  ; [pp+0x8c618] Obj!MaterialType@12c5361
    //     0xdf5f44: ldr             x0, [x0, #0x618]
    // 0xdf5f48: stur            x1, [fp, #-0x10]
    // 0xdf5f4c: StoreField: r1->field_f = r0
    //     0xdf5f4c: stur            w0, [x1, #0xf]
    // 0xdf5f50: ArrayStore: r1[0] = rZR  ; List_8
    //     0xdf5f50: stur            xzr, [x1, #0x17]
    // 0xdf5f54: ldur            x0, [fp, #-0x20]
    // 0xdf5f58: StoreField: r1->field_2b = r0
    //     0xdf5f58: stur            w0, [x1, #0x2b]
    // 0xdf5f5c: r0 = true
    //     0xdf5f5c: add             x0, NULL, #0x20  ; true
    // 0xdf5f60: StoreField: r1->field_33 = r0
    //     0xdf5f60: stur            w0, [x1, #0x33]
    // 0xdf5f64: r0 = Instance_Clip
    //     0xdf5f64: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xdf5f68: ldr             x0, [x0, #0x840]
    // 0xdf5f6c: StoreField: r1->field_37 = r0
    //     0xdf5f6c: stur            w0, [x1, #0x37]
    // 0xdf5f70: r2 = Instance_Duration
    //     0xdf5f70: add             x2, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xdf5f74: ldr             x2, [x2, #0x318]
    // 0xdf5f78: StoreField: r1->field_3b = r2
    //     0xdf5f78: stur            w2, [x1, #0x3b]
    // 0xdf5f7c: ldur            x2, [fp, #-8]
    // 0xdf5f80: StoreField: r1->field_b = r2
    //     0xdf5f80: stur            w2, [x1, #0xb]
    // 0xdf5f84: r2 = false
    //     0xdf5f84: add             x2, NULL, #0x30  ; false
    // 0xdf5f88: StoreField: r1->field_13 = r2
    //     0xdf5f88: stur            w2, [x1, #0x13]
    // 0xdf5f8c: r0 = ClipRRect()
    //     0xdf5f8c: bl              #0xd30168  ; AllocateClipRRectStub -> ClipRRect (size=0x1c)
    // 0xdf5f90: mov             x1, x0
    // 0xdf5f94: r0 = Instance_BorderRadius
    //     0xdf5f94: add             x0, PP, #0x99, lsl #12  ; [pp+0x99508] Obj!BorderRadius@129e311
    //     0xdf5f98: ldr             x0, [x0, #0x508]
    // 0xdf5f9c: stur            x1, [fp, #-8]
    // 0xdf5fa0: StoreField: r1->field_f = r0
    //     0xdf5fa0: stur            w0, [x1, #0xf]
    // 0xdf5fa4: r0 = Instance_Clip
    //     0xdf5fa4: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xdf5fa8: ldr             x0, [x0, #0x840]
    // 0xdf5fac: ArrayStore: r1[0] = r0  ; List_4
    //     0xdf5fac: stur            w0, [x1, #0x17]
    // 0xdf5fb0: ldur            x0, [fp, #-0x10]
    // 0xdf5fb4: StoreField: r1->field_b = r0
    //     0xdf5fb4: stur            w0, [x1, #0xb]
    // 0xdf5fb8: r0 = Semantics()
    //     0xdf5fb8: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xdf5fbc: stur            x0, [fp, #-0x10]
    // 0xdf5fc0: r16 = Instance_SemanticsRole
    //     0xdf5fc0: add             x16, PP, #0xd1, lsl #12  ; [pp+0xd1df8] Obj!SemanticsRole@12c7961
    //     0xdf5fc4: ldr             x16, [x16, #0xdf8]
    // 0xdf5fc8: r30 = true
    //     0xdf5fc8: add             lr, NULL, #0x20  ; true
    // 0xdf5fcc: stp             lr, x16, [SP, #0x20]
    // 0xdf5fd0: r16 = true
    //     0xdf5fd0: add             x16, NULL, #0x20  ; true
    // 0xdf5fd4: r30 = true
    //     0xdf5fd4: add             lr, NULL, #0x20  ; true
    // 0xdf5fd8: stp             lr, x16, [SP, #0x10]
    // 0xdf5fdc: ldur            x16, [fp, #-0x38]
    // 0xdf5fe0: ldur            lr, [fp, #-8]
    // 0xdf5fe4: stp             lr, x16, [SP]
    // 0xdf5fe8: mov             x1, x0
    // 0xdf5fec: r4 = const [0, 0x7, 0x6, 0x1, child, 0x6, explicitChildNodes, 0x4, label, 0x5, namesRoute, 0x3, role, 0x1, scopesRoute, 0x2, null]
    //     0xdf5fec: add             x4, PP, #0xd1, lsl #12  ; [pp+0xd1e00] List(17) [0, 0x7, 0x6, 0x1, "child", 0x6, "explicitChildNodes", 0x4, "label", 0x5, "namesRoute", 0x3, "role", 0x1, "scopesRoute", 0x2, Null]
    //     0xdf5ff0: ldr             x4, [x4, #0xe00]
    // 0xdf5ff4: r0 = Semantics()
    //     0xdf5ff4: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xdf5ff8: r0 = CustomPaint()
    //     0xdf5ff8: bl              #0xd0a594  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0xdf5ffc: mov             x1, x0
    // 0xdf6000: ldur            x0, [fp, #-0x28]
    // 0xdf6004: stur            x1, [fp, #-8]
    // 0xdf6008: StoreField: r1->field_f = r0
    //     0xdf6008: stur            w0, [x1, #0xf]
    // 0xdf600c: r0 = Instance_Size
    //     0xdf600c: ldr             x0, [PP, #0x7f28]  ; [pp+0x7f28] Obj!Size@12a74d1
    // 0xdf6010: ArrayStore: r1[0] = r0  ; List_4
    //     0xdf6010: stur            w0, [x1, #0x17]
    // 0xdf6014: r0 = false
    //     0xdf6014: add             x0, NULL, #0x30  ; false
    // 0xdf6018: StoreField: r1->field_1b = r0
    //     0xdf6018: stur            w0, [x1, #0x1b]
    // 0xdf601c: StoreField: r1->field_1f = r0
    //     0xdf601c: stur            w0, [x1, #0x1f]
    // 0xdf6020: ldur            x2, [fp, #-0x10]
    // 0xdf6024: StoreField: r1->field_b = r2
    //     0xdf6024: stur            w2, [x1, #0xb]
    // 0xdf6028: r0 = FadeTransition()
    //     0xdf6028: bl              #0xb28358  ; AllocateFadeTransitionStub -> FadeTransition (size=0x18)
    // 0xdf602c: ldur            x1, [fp, #-0x30]
    // 0xdf6030: StoreField: r0->field_f = r1
    //     0xdf6030: stur            w1, [x0, #0xf]
    // 0xdf6034: r1 = false
    //     0xdf6034: add             x1, NULL, #0x30  ; false
    // 0xdf6038: StoreField: r0->field_13 = r1
    //     0xdf6038: stur            w1, [x0, #0x13]
    // 0xdf603c: ldur            x1, [fp, #-8]
    // 0xdf6040: StoreField: r0->field_b = r1
    //     0xdf6040: stur            w1, [x0, #0xb]
    // 0xdf6044: LeaveFrame
    //     0xdf6044: mov             SP, fp
    //     0xdf6048: ldp             fp, lr, [SP], #0x10
    // 0xdf604c: ret
    //     0xdf604c: ret             
    // 0xdf6050: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf6050: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf6054: b               #0xdf5b14
    // 0xdf6058: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf6058: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf605c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf605c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf6060: b               #0xdf5ba4
    // 0xdf6064: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf6064: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf6068: r9 = _fadeOpacity
    //     0xdf6068: add             x9, PP, #0xd1, lsl #12  ; [pp+0xd1e08] Field <_DropdownMenuState@83005770._fadeOpacity@83005770>: late final (offset: 0x14)
    //     0xdf606c: ldr             x9, [x9, #0xe08]
    // 0xdf6070: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdf6070: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdf6074: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf6074: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf6078: r9 = _resize
    //     0xdf6078: add             x9, PP, #0xd1, lsl #12  ; [pp+0xd1e10] Field <_DropdownMenuState@83005770._resize@83005770>: late final (offset: 0x18)
    //     0xdf607c: ldr             x9, [x9, #0xe10]
    // 0xdf6080: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdf6080: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdf6084: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf6084: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf6088: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf6088: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf608c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf608c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] double <anonymous closure>(dynamic) {
    // ** addr: 0xdf64c0, size: 0x84
    // 0xdf64c0: EnterFrame
    //     0xdf64c0: stp             fp, lr, [SP, #-0x10]!
    //     0xdf64c4: mov             fp, SP
    // 0xdf64c8: ldr             x0, [fp, #0x10]
    // 0xdf64cc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdf64cc: ldur            w1, [x0, #0x17]
    // 0xdf64d0: DecompressPointer r1
    //     0xdf64d0: add             x1, x1, HEAP, lsl #32
    // 0xdf64d4: CheckStackOverflow
    //     0xdf64d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf64d8: cmp             SP, x16
    //     0xdf64dc: b.ls            #0xdf652c
    // 0xdf64e0: LoadField: r0 = r1->field_f
    //     0xdf64e0: ldur            w0, [x1, #0xf]
    // 0xdf64e4: DecompressPointer r0
    //     0xdf64e4: add             x0, x0, HEAP, lsl #32
    // 0xdf64e8: LoadField: r2 = r0->field_a3
    //     0xdf64e8: ldur            x2, [x0, #0xa3]
    // 0xdf64ec: mov             x1, x0
    // 0xdf64f0: r0 = getItemOffset()
    //     0xdf64f0: bl              #0xdf5894  ; [package:flutter/src/material/dropdown.dart] _DropdownRoute::getItemOffset
    // 0xdf64f4: r0 = inline_Allocate_Double()
    //     0xdf64f4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xdf64f8: add             x0, x0, #0x10
    //     0xdf64fc: cmp             x1, x0
    //     0xdf6500: b.ls            #0xdf6534
    //     0xdf6504: str             x0, [THR, #0x60]  ; THR::top
    //     0xdf6508: sub             x0, x0, #0xf
    //     0xdf650c: mov             x1, #0xe19c
    //     0xdf6510: movk            x1, #3, lsl #16
    //     0xdf6514: stur            x1, [x0, #-1]
    // 0xdf6518: dmb             ishst
    // 0xdf651c: StoreField: r0->field_7 = d0
    //     0xdf651c: stur            d0, [x0, #7]
    // 0xdf6520: LeaveFrame
    //     0xdf6520: mov             SP, fp
    //     0xdf6524: ldp             fp, lr, [SP], #0x10
    // 0xdf6528: ret
    //     0xdf6528: ret             
    // 0xdf652c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf652c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf6530: b               #0xdf64e0
    // 0xdf6534: SaveReg d0
    //     0xdf6534: str             q0, [SP, #-0x10]!
    // 0xdf6538: r0 = AllocateDouble()
    //     0xdf6538: bl              #0x13df878  ; AllocateDoubleStub
    // 0xdf653c: RestoreReg d0
    //     0xdf653c: ldr             q0, [SP], #0x10
    // 0xdf6540: b               #0xdf651c
  }
  _ initState(/* No info */) {
    // ** addr: 0xf908f4, size: 0x1a0
    // 0xf908f4: EnterFrame
    //     0xf908f4: stp             fp, lr, [SP, #-0x10]!
    //     0xf908f8: mov             fp, SP
    // 0xf908fc: AllocStack(0x20)
    //     0xf908fc: sub             SP, SP, #0x20
    // 0xf90900: SetupParameters(_DropdownMenuState<C1X0> this /* r1 => r0, fp-0x10 */)
    //     0xf90900: mov             x0, x1
    //     0xf90904: stur            x1, [fp, #-0x10]
    // 0xf90908: CheckStackOverflow
    //     0xf90908: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf9090c: cmp             SP, x16
    //     0xf90910: b.ls            #0xf90a7c
    // 0xf90914: LoadField: r1 = r0->field_b
    //     0xf90914: ldur            w1, [x0, #0xb]
    // 0xf90918: DecompressPointer r1
    //     0xf90918: add             x1, x1, HEAP, lsl #32
    // 0xf9091c: cmp             w1, NULL
    // 0xf90920: b.eq            #0xf90a84
    // 0xf90924: LoadField: r2 = r1->field_f
    //     0xf90924: ldur            w2, [x1, #0xf]
    // 0xf90928: DecompressPointer r2
    //     0xf90928: add             x2, x2, HEAP, lsl #32
    // 0xf9092c: LoadField: r3 = r2->field_6f
    //     0xf9092c: ldur            w3, [x2, #0x6f]
    // 0xf90930: DecompressPointer r3
    //     0xf90930: add             x3, x3, HEAP, lsl #32
    // 0xf90934: stur            x3, [fp, #-8]
    // 0xf90938: cmp             w3, NULL
    // 0xf9093c: b.eq            #0xf90a88
    // 0xf90940: r1 = <double>
    //     0xf90940: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf90944: r0 = CurvedAnimation()
    //     0xf90944: bl              #0x915e4c  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0xf90948: stur            x0, [fp, #-0x18]
    // 0xf9094c: r16 = Instance_Interval
    //     0xf9094c: add             x16, PP, #0xd1, lsl #12  ; [pp+0xd1e20] Obj!Interval@129fe51
    //     0xf90950: ldr             x16, [x16, #0xe20]
    // 0xf90954: str             x16, [SP]
    // 0xf90958: mov             x1, x0
    // 0xf9095c: ldur            x3, [fp, #-8]
    // 0xf90960: r2 = Instance_Interval
    //     0xf90960: add             x2, PP, #0xd0, lsl #12  ; [pp+0xd0508] Obj!Interval@129fe71
    //     0xf90964: ldr             x2, [x2, #0x508]
    // 0xf90968: r4 = const [0, 0x4, 0x1, 0x3, reverseCurve, 0x3, null]
    //     0xf90968: add             x4, PP, #0x16, lsl #12  ; [pp+0x16dc0] List(7) [0, 0x4, 0x1, 0x3, "reverseCurve", 0x3, Null]
    //     0xf9096c: ldr             x4, [x4, #0xdc0]
    // 0xf90970: r0 = CurvedAnimation()
    //     0xf90970: bl              #0x915be4  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0xf90974: ldur            x2, [fp, #-0x10]
    // 0xf90978: LoadField: r0 = r2->field_13
    //     0xf90978: ldur            w0, [x2, #0x13]
    // 0xf9097c: DecompressPointer r0
    //     0xf9097c: add             x0, x0, HEAP, lsl #32
    // 0xf90980: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf90984: cmp             w0, w16
    // 0xf90988: b.ne            #0xf90a68
    // 0xf9098c: ldur            x0, [fp, #-0x18]
    // 0xf90990: StoreField: r2->field_13 = r0
    //     0xf90990: stur            w0, [x2, #0x13]
    //     0xf90994: ldurb           w16, [x2, #-1]
    //     0xf90998: ldurb           w17, [x0, #-1]
    //     0xf9099c: and             x16, x17, x16, lsr #2
    //     0xf909a0: tst             x16, HEAP, lsr #32
    //     0xf909a4: b.eq            #0xf909ac
    //     0xf909a8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf909ac: LoadField: r0 = r2->field_b
    //     0xf909ac: ldur            w0, [x2, #0xb]
    // 0xf909b0: DecompressPointer r0
    //     0xf909b0: add             x0, x0, HEAP, lsl #32
    // 0xf909b4: cmp             w0, NULL
    // 0xf909b8: b.eq            #0xf90a8c
    // 0xf909bc: LoadField: r1 = r0->field_f
    //     0xf909bc: ldur            w1, [x0, #0xf]
    // 0xf909c0: DecompressPointer r1
    //     0xf909c0: add             x1, x1, HEAP, lsl #32
    // 0xf909c4: LoadField: r3 = r1->field_6f
    //     0xf909c4: ldur            w3, [x1, #0x6f]
    // 0xf909c8: DecompressPointer r3
    //     0xf909c8: add             x3, x3, HEAP, lsl #32
    // 0xf909cc: stur            x3, [fp, #-8]
    // 0xf909d0: cmp             w3, NULL
    // 0xf909d4: b.eq            #0xf90a90
    // 0xf909d8: r1 = <double>
    //     0xf909d8: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf909dc: r0 = CurvedAnimation()
    //     0xf909dc: bl              #0x915e4c  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0xf909e0: stur            x0, [fp, #-0x18]
    // 0xf909e4: r16 = Instance_Threshold
    //     0xf909e4: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8c910] Obj!Threshold@129f8f1
    //     0xf909e8: ldr             x16, [x16, #0x910]
    // 0xf909ec: str             x16, [SP]
    // 0xf909f0: mov             x1, x0
    // 0xf909f4: ldur            x3, [fp, #-8]
    // 0xf909f8: r2 = Instance_Interval
    //     0xf909f8: add             x2, PP, #0xd1, lsl #12  ; [pp+0xd1e28] Obj!Interval@129fe31
    //     0xf909fc: ldr             x2, [x2, #0xe28]
    // 0xf90a00: r4 = const [0, 0x4, 0x1, 0x3, reverseCurve, 0x3, null]
    //     0xf90a00: add             x4, PP, #0x16, lsl #12  ; [pp+0x16dc0] List(7) [0, 0x4, 0x1, 0x3, "reverseCurve", 0x3, Null]
    //     0xf90a04: ldr             x4, [x4, #0xdc0]
    // 0xf90a08: r0 = CurvedAnimation()
    //     0xf90a08: bl              #0x915be4  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0xf90a0c: ldur            x1, [fp, #-0x10]
    // 0xf90a10: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xf90a10: ldur            w0, [x1, #0x17]
    // 0xf90a14: DecompressPointer r0
    //     0xf90a14: add             x0, x0, HEAP, lsl #32
    // 0xf90a18: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf90a1c: cmp             w0, w16
    // 0xf90a20: b.ne            #0xf90a54
    // 0xf90a24: ldur            x0, [fp, #-0x18]
    // 0xf90a28: ArrayStore: r1[0] = r0  ; List_4
    //     0xf90a28: stur            w0, [x1, #0x17]
    //     0xf90a2c: ldurb           w16, [x1, #-1]
    //     0xf90a30: ldurb           w17, [x0, #-1]
    //     0xf90a34: and             x16, x17, x16, lsr #2
    //     0xf90a38: tst             x16, HEAP, lsr #32
    //     0xf90a3c: b.eq            #0xf90a44
    //     0xf90a40: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf90a44: r0 = Null
    //     0xf90a44: mov             x0, NULL
    // 0xf90a48: LeaveFrame
    //     0xf90a48: mov             SP, fp
    //     0xf90a4c: ldp             fp, lr, [SP], #0x10
    // 0xf90a50: ret
    //     0xf90a50: ret             
    // 0xf90a54: r16 = "_resize@83005770"
    //     0xf90a54: add             x16, PP, #0xd1, lsl #12  ; [pp+0xd1e30] "_resize@83005770"
    //     0xf90a58: ldr             x16, [x16, #0xe30]
    // 0xf90a5c: str             x16, [SP]
    // 0xf90a60: r0 = _throwFieldAlreadyInitialized()
    //     0xf90a60: bl              #0x82b720  ; [dart:_internal] LateError::_throwFieldAlreadyInitialized
    // 0xf90a64: brk             #0
    // 0xf90a68: r16 = "_fadeOpacity@83005770"
    //     0xf90a68: add             x16, PP, #0xd1, lsl #12  ; [pp+0xd1e38] "_fadeOpacity@83005770"
    //     0xf90a6c: ldr             x16, [x16, #0xe38]
    // 0xf90a70: str             x16, [SP]
    // 0xf90a74: r0 = _throwFieldAlreadyInitialized()
    //     0xf90a74: bl              #0x82b720  ; [dart:_internal] LateError::_throwFieldAlreadyInitialized
    // 0xf90a78: brk             #0
    // 0xf90a7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf90a7c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf90a80: b               #0xf90914
    // 0xf90a84: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf90a84: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf90a88: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf90a88: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf90a8c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf90a8c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf90a90: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf90a90: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10e5af4, size: 0x84
    // 0x10e5af4: EnterFrame
    //     0x10e5af4: stp             fp, lr, [SP, #-0x10]!
    //     0x10e5af8: mov             fp, SP
    // 0x10e5afc: AllocStack(0x8)
    //     0x10e5afc: sub             SP, SP, #8
    // 0x10e5b00: SetupParameters(_DropdownMenuState<C1X0> this /* r1 => r0, fp-0x8 */)
    //     0x10e5b00: mov             x0, x1
    //     0x10e5b04: stur            x1, [fp, #-8]
    // 0x10e5b08: CheckStackOverflow
    //     0x10e5b08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e5b0c: cmp             SP, x16
    //     0x10e5b10: b.ls            #0x10e5b58
    // 0x10e5b14: LoadField: r1 = r0->field_13
    //     0x10e5b14: ldur            w1, [x0, #0x13]
    // 0x10e5b18: DecompressPointer r1
    //     0x10e5b18: add             x1, x1, HEAP, lsl #32
    // 0x10e5b1c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10e5b20: cmp             w1, w16
    // 0x10e5b24: b.eq            #0x10e5b60
    // 0x10e5b28: r0 = dispose()
    //     0x10e5b28: bl              #0xb29014  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::dispose
    // 0x10e5b2c: ldur            x0, [fp, #-8]
    // 0x10e5b30: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x10e5b30: ldur            w1, [x0, #0x17]
    // 0x10e5b34: DecompressPointer r1
    //     0x10e5b34: add             x1, x1, HEAP, lsl #32
    // 0x10e5b38: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10e5b3c: cmp             w1, w16
    // 0x10e5b40: b.eq            #0x10e5b6c
    // 0x10e5b44: r0 = dispose()
    //     0x10e5b44: bl              #0xb29014  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::dispose
    // 0x10e5b48: r0 = Null
    //     0x10e5b48: mov             x0, NULL
    // 0x10e5b4c: LeaveFrame
    //     0x10e5b4c: mov             SP, fp
    //     0x10e5b50: ldp             fp, lr, [SP], #0x10
    // 0x10e5b54: ret
    //     0x10e5b54: ret             
    // 0x10e5b58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e5b58: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e5b5c: b               #0x10e5b14
    // 0x10e5b60: r9 = _fadeOpacity
    //     0x10e5b60: add             x9, PP, #0xd1, lsl #12  ; [pp+0xd1e08] Field <_DropdownMenuState@83005770._fadeOpacity@83005770>: late final (offset: 0x14)
    //     0x10e5b64: ldr             x9, [x9, #0xe08]
    // 0x10e5b68: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x10e5b68: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x10e5b6c: r9 = _resize
    //     0x10e5b6c: add             x9, PP, #0xd1, lsl #12  ; [pp+0xd1e10] Field <_DropdownMenuState@83005770._resize@83005770>: late final (offset: 0x18)
    //     0x10e5b70: ldr             x9, [x9, #0xe10]
    // 0x10e5b74: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x10e5b74: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 5471, size: 0x18, field offset: 0x14
class _DropdownMenuItemButtonState<C1X0> extends State<C1X0> {

  late CurvedAnimation _opacityAnimation; // offset: 0x14

  _ build(/* No info */) {
    // ** addr: 0xdf50fc, size: 0x2bc
    // 0xdf50fc: EnterFrame
    //     0xdf50fc: stp             fp, lr, [SP, #-0x10]!
    //     0xdf5100: mov             fp, SP
    // 0xdf5104: AllocStack(0x48)
    //     0xdf5104: sub             SP, SP, #0x48
    // 0xdf5108: SetupParameters(_DropdownMenuItemButtonState<C1X0> this /* r1 => r3, fp-0x20 */, dynamic _ /* r2 => r2, fp-0x28 */)
    //     0xdf5108: mov             x3, x1
    //     0xdf510c: stur            x1, [fp, #-0x20]
    //     0xdf5110: stur            x2, [fp, #-0x28]
    // 0xdf5114: CheckStackOverflow
    //     0xdf5114: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf5118: cmp             SP, x16
    //     0xdf511c: b.ls            #0xdf5390
    // 0xdf5120: LoadField: r0 = r3->field_b
    //     0xdf5120: ldur            w0, [x3, #0xb]
    // 0xdf5124: DecompressPointer r0
    //     0xdf5124: add             x0, x0, HEAP, lsl #32
    // 0xdf5128: cmp             w0, NULL
    // 0xdf512c: b.eq            #0xdf5398
    // 0xdf5130: LoadField: r4 = r0->field_f
    //     0xdf5130: ldur            w4, [x0, #0xf]
    // 0xdf5134: DecompressPointer r4
    //     0xdf5134: add             x4, x4, HEAP, lsl #32
    // 0xdf5138: stur            x4, [fp, #-0x18]
    // 0xdf513c: LoadField: r5 = r4->field_97
    //     0xdf513c: ldur            w5, [x4, #0x97]
    // 0xdf5140: DecompressPointer r5
    //     0xdf5140: add             x5, x5, HEAP, lsl #32
    // 0xdf5144: LoadField: r6 = r0->field_23
    //     0xdf5144: ldur            x6, [x0, #0x23]
    // 0xdf5148: stur            x6, [fp, #-0x10]
    // 0xdf514c: LoadField: r0 = r5->field_b
    //     0xdf514c: ldur            w0, [x5, #0xb]
    // 0xdf5150: r1 = LoadInt32Instr(r0)
    //     0xdf5150: sbfx            x1, x0, #1, #0x1f
    // 0xdf5154: mov             x0, x1
    // 0xdf5158: mov             x1, x6
    // 0xdf515c: cmp             x1, x0
    // 0xdf5160: b.hs            #0xdf539c
    // 0xdf5164: LoadField: r0 = r5->field_f
    //     0xdf5164: ldur            w0, [x5, #0xf]
    // 0xdf5168: DecompressPointer r0
    //     0xdf5168: add             x0, x0, HEAP, lsl #32
    // 0xdf516c: ArrayLoad: r1 = r0[r6]  ; Unknown_4
    //     0xdf516c: add             x16, x0, x6, lsl #2
    //     0xdf5170: ldur            w1, [x16, #0xf]
    // 0xdf5174: DecompressPointer r1
    //     0xdf5174: add             x1, x1, HEAP, lsl #32
    // 0xdf5178: stur            x1, [fp, #-8]
    // 0xdf517c: r0 = Padding()
    //     0xdf517c: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xdf5180: mov             x1, x0
    // 0xdf5184: r0 = Instance_EdgeInsets
    //     0xdf5184: add             x0, PP, #0x26, lsl #12  ; [pp+0x26510] Obj!EdgeInsets@129cdb1
    //     0xdf5188: ldr             x0, [x0, #0x510]
    // 0xdf518c: stur            x1, [fp, #-0x30]
    // 0xdf5190: StoreField: r1->field_f = r0
    //     0xdf5190: stur            w0, [x1, #0xf]
    // 0xdf5194: ldur            x0, [fp, #-8]
    // 0xdf5198: StoreField: r1->field_b = r0
    //     0xdf5198: stur            w0, [x1, #0xb]
    // 0xdf519c: ldur            x0, [fp, #-0x18]
    // 0xdf51a0: LoadField: r2 = r0->field_bb
    //     0xdf51a0: ldur            w2, [x0, #0xbb]
    // 0xdf51a4: DecompressPointer r2
    //     0xdf51a4: add             x2, x2, HEAP, lsl #32
    // 0xdf51a8: stur            x2, [fp, #-8]
    // 0xdf51ac: r0 = SizedBox()
    //     0xdf51ac: bl              #0x8a7210  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0xdf51b0: mov             x2, x0
    // 0xdf51b4: ldur            x0, [fp, #-8]
    // 0xdf51b8: stur            x2, [fp, #-0x38]
    // 0xdf51bc: StoreField: r2->field_13 = r0
    //     0xdf51bc: stur            w0, [x2, #0x13]
    // 0xdf51c0: ldur            x0, [fp, #-0x30]
    // 0xdf51c4: StoreField: r2->field_b = r0
    //     0xdf51c4: stur            w0, [x2, #0xb]
    // 0xdf51c8: ldur            x0, [fp, #-0x18]
    // 0xdf51cc: LoadField: r1 = r0->field_a3
    //     0xdf51cc: ldur            x1, [x0, #0xa3]
    // 0xdf51d0: ldur            x0, [fp, #-0x10]
    // 0xdf51d4: cmp             x0, x1
    // 0xdf51d8: r16 = true
    //     0xdf51d8: add             x16, NULL, #0x20  ; true
    // 0xdf51dc: r17 = false
    //     0xdf51dc: add             x17, NULL, #0x30  ; false
    // 0xdf51e0: csel            x3, x16, x17, eq
    // 0xdf51e4: stur            x3, [fp, #-8]
    // 0xdf51e8: r0 = LoadStaticField(0x6a0)
    //     0xdf51e8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xdf51ec: ldr             x0, [x0, #0xd40]
    // 0xdf51f0: cmp             w0, NULL
    // 0xdf51f4: b.eq            #0xdf53a0
    // 0xdf51f8: LoadField: r1 = r0->field_ef
    //     0xdf51f8: ldur            w1, [x0, #0xef]
    // 0xdf51fc: DecompressPointer r1
    //     0xdf51fc: add             x1, x1, HEAP, lsl #32
    // 0xdf5200: cmp             w1, NULL
    // 0xdf5204: b.eq            #0xdf53a4
    // 0xdf5208: LoadField: r0 = r1->field_13
    //     0xdf5208: ldur            w0, [x1, #0x13]
    // 0xdf520c: DecompressPointer r0
    //     0xdf520c: add             x0, x0, HEAP, lsl #32
    // 0xdf5210: LoadField: r1 = r0->field_23
    //     0xdf5210: ldur            w1, [x0, #0x23]
    // 0xdf5214: DecompressPointer r1
    //     0xdf5214: add             x1, x1, HEAP, lsl #32
    // 0xdf5218: r0 = highlightMode()
    //     0xdf5218: bl              #0x83bde4  ; [package:flutter/src/widgets/focus_manager.dart] _HighlightModeManager::highlightMode
    // 0xdf521c: ldur            x2, [fp, #-0x20]
    // 0xdf5220: LoadField: r1 = r2->field_b
    //     0xdf5220: ldur            w1, [x2, #0xb]
    // 0xdf5224: DecompressPointer r1
    //     0xdf5224: add             x1, x1, HEAP, lsl #32
    // 0xdf5228: cmp             w1, NULL
    // 0xdf522c: b.eq            #0xdf53a8
    // 0xdf5230: r16 = Instance_FocusHighlightMode
    //     0xdf5230: ldr             x16, [PP, #0x1c68]  ; [pp+0x1c68] Obj!FocusHighlightMode@12c3221
    // 0xdf5234: cmp             w0, w16
    // 0xdf5238: b.ne            #0xdf5290
    // 0xdf523c: ldur            x0, [fp, #-8]
    // 0xdf5240: tbnz            w0, #4, #0xdf525c
    // 0xdf5244: ldur            x1, [fp, #-0x28]
    // 0xdf5248: r0 = of()
    //     0xdf5248: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xdf524c: LoadField: r1 = r0->field_4b
    //     0xdf524c: ldur            w1, [x0, #0x4b]
    // 0xdf5250: DecompressPointer r1
    //     0xdf5250: add             x1, x1, HEAP, lsl #32
    // 0xdf5254: mov             x0, x1
    // 0xdf5258: b               #0xdf5260
    // 0xdf525c: r0 = Null
    //     0xdf525c: mov             x0, NULL
    // 0xdf5260: stur            x0, [fp, #-0x18]
    // 0xdf5264: r0 = Ink()
    //     0xdf5264: bl              #0xdf1d50  ; AllocateInkStub -> Ink (size=0x20)
    // 0xdf5268: stur            x0, [fp, #-0x28]
    // 0xdf526c: ldur            x16, [fp, #-0x18]
    // 0xdf5270: str             x16, [SP]
    // 0xdf5274: mov             x1, x0
    // 0xdf5278: ldur            x2, [fp, #-0x38]
    // 0xdf527c: r4 = const [0, 0x3, 0x1, 0x2, color, 0x2, null]
    //     0xdf527c: add             x4, PP, #0x80, lsl #12  ; [pp+0x80bd0] List(7) [0, 0x3, 0x1, 0x2, "color", 0x2, Null]
    //     0xdf5280: ldr             x4, [x4, #0xbd0]
    // 0xdf5284: r0 = Ink()
    //     0xdf5284: bl              #0xdf1b7c  ; [package:flutter/src/material/ink_decoration.dart] Ink::Ink
    // 0xdf5288: ldur            x1, [fp, #-0x28]
    // 0xdf528c: b               #0xdf5294
    // 0xdf5290: ldur            x1, [fp, #-0x38]
    // 0xdf5294: ldur            x2, [fp, #-0x20]
    // 0xdf5298: ldur            x0, [fp, #-8]
    // 0xdf529c: stur            x1, [fp, #-0x18]
    // 0xdf52a0: r0 = InkWell()
    //     0xdf52a0: bl              #0xd0c57c  ; AllocateInkWellStub -> InkWell (size=0x94)
    // 0xdf52a4: mov             x3, x0
    // 0xdf52a8: ldur            x0, [fp, #-0x18]
    // 0xdf52ac: stur            x3, [fp, #-0x28]
    // 0xdf52b0: StoreField: r3->field_b = r0
    //     0xdf52b0: stur            w0, [x3, #0xb]
    // 0xdf52b4: ldur            x2, [fp, #-0x20]
    // 0xdf52b8: r1 = Function '_handleOnTap@83005770':.
    //     0xdf52b8: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3558] AnonymousClosure: (0xdf595c), in [package:flutter/src/material/dropdown.dart] _DropdownMenuItemButtonState::_handleOnTap (0xdf5994)
    //     0xdf52bc: ldr             x1, [x1, #0x558]
    // 0xdf52c0: r0 = AllocateClosure()
    //     0xdf52c0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf52c4: mov             x1, x0
    // 0xdf52c8: ldur            x0, [fp, #-0x28]
    // 0xdf52cc: StoreField: r0->field_f = r1
    //     0xdf52cc: stur            w1, [x0, #0xf]
    // 0xdf52d0: r1 = true
    //     0xdf52d0: add             x1, NULL, #0x20  ; true
    // 0xdf52d4: StoreField: r0->field_47 = r1
    //     0xdf52d4: stur            w1, [x0, #0x47]
    // 0xdf52d8: r2 = Instance_BoxShape
    //     0xdf52d8: add             x2, PP, #0x17, lsl #12  ; [pp+0x171f8] Obj!BoxShape@12c4921
    //     0xdf52dc: ldr             x2, [x2, #0x1f8]
    // 0xdf52e0: StoreField: r0->field_4b = r2
    //     0xdf52e0: stur            w2, [x0, #0x4b]
    // 0xdf52e4: StoreField: r0->field_73 = r1
    //     0xdf52e4: stur            w1, [x0, #0x73]
    // 0xdf52e8: r3 = false
    //     0xdf52e8: add             x3, NULL, #0x30  ; false
    // 0xdf52ec: StoreField: r0->field_77 = r3
    //     0xdf52ec: stur            w3, [x0, #0x77]
    // 0xdf52f0: StoreField: r0->field_87 = r1
    //     0xdf52f0: stur            w1, [x0, #0x87]
    // 0xdf52f4: ldur            x2, [fp, #-0x20]
    // 0xdf52f8: r1 = Function '_handleFocusChange@83005770':.
    //     0xdf52f8: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3560] AnonymousClosure: (0xdf549c), in [package:flutter/src/material/dropdown.dart] _DropdownMenuItemButtonState::_handleFocusChange (0xdf54d8)
    //     0xdf52fc: ldr             x1, [x1, #0x560]
    // 0xdf5300: r0 = AllocateClosure()
    //     0xdf5300: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf5304: mov             x1, x0
    // 0xdf5308: ldur            x0, [fp, #-0x28]
    // 0xdf530c: StoreField: r0->field_7b = r1
    //     0xdf530c: stur            w1, [x0, #0x7b]
    // 0xdf5310: ldur            x1, [fp, #-8]
    // 0xdf5314: StoreField: r0->field_7f = r1
    //     0xdf5314: stur            w1, [x0, #0x7f]
    // 0xdf5318: ldur            x1, [fp, #-0x20]
    // 0xdf531c: LoadField: r2 = r1->field_13
    //     0xdf531c: ldur            w2, [x1, #0x13]
    // 0xdf5320: DecompressPointer r2
    //     0xdf5320: add             x2, x2, HEAP, lsl #32
    // 0xdf5324: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf5328: cmp             w2, w16
    // 0xdf532c: b.eq            #0xdf53ac
    // 0xdf5330: stur            x2, [fp, #-8]
    // 0xdf5334: r0 = FadeTransition()
    //     0xdf5334: bl              #0xb28358  ; AllocateFadeTransitionStub -> FadeTransition (size=0x18)
    // 0xdf5338: mov             x1, x0
    // 0xdf533c: ldur            x0, [fp, #-8]
    // 0xdf5340: stur            x1, [fp, #-0x18]
    // 0xdf5344: StoreField: r1->field_f = r0
    //     0xdf5344: stur            w0, [x1, #0xf]
    // 0xdf5348: r0 = false
    //     0xdf5348: add             x0, NULL, #0x30  ; false
    // 0xdf534c: StoreField: r1->field_13 = r0
    //     0xdf534c: stur            w0, [x1, #0x13]
    // 0xdf5350: ldur            x0, [fp, #-0x28]
    // 0xdf5354: StoreField: r1->field_b = r0
    //     0xdf5354: stur            w0, [x1, #0xb]
    // 0xdf5358: r0 = Semantics()
    //     0xdf5358: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xdf535c: stur            x0, [fp, #-8]
    // 0xdf5360: r16 = Instance_SemanticsRole
    //     0xdf5360: add             x16, PP, #0xd3, lsl #12  ; [pp+0xd3568] Obj!SemanticsRole@12c7941
    //     0xdf5364: ldr             x16, [x16, #0x568]
    // 0xdf5368: ldur            lr, [fp, #-0x18]
    // 0xdf536c: stp             lr, x16, [SP]
    // 0xdf5370: mov             x1, x0
    // 0xdf5374: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, role, 0x1, null]
    //     0xdf5374: add             x4, PP, #0x8c, lsl #12  ; [pp+0x8c7f8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "role", 0x1, Null]
    //     0xdf5378: ldr             x4, [x4, #0x7f8]
    // 0xdf537c: r0 = Semantics()
    //     0xdf537c: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xdf5380: ldur            x0, [fp, #-8]
    // 0xdf5384: LeaveFrame
    //     0xdf5384: mov             SP, fp
    //     0xdf5388: ldp             fp, lr, [SP], #0x10
    // 0xdf538c: ret
    //     0xdf538c: ret             
    // 0xdf5390: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf5390: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf5394: b               #0xdf5120
    // 0xdf5398: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf5398: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf539c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdf539c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdf53a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf53a0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf53a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf53a4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf53a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf53a8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf53ac: r9 = _opacityAnimation
    //     0xdf53ac: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3570] Field <_DropdownMenuItemButtonState@83005770._opacityAnimation@83005770>: late (offset: 0x14)
    //     0xdf53b0: ldr             x9, [x9, #0x570]
    // 0xdf53b4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdf53b4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleFocusChange(dynamic, bool) {
    // ** addr: 0xdf549c, size: 0x3c
    // 0xdf549c: EnterFrame
    //     0xdf549c: stp             fp, lr, [SP, #-0x10]!
    //     0xdf54a0: mov             fp, SP
    // 0xdf54a4: ldr             x0, [fp, #0x18]
    // 0xdf54a8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdf54a8: ldur            w1, [x0, #0x17]
    // 0xdf54ac: DecompressPointer r1
    //     0xdf54ac: add             x1, x1, HEAP, lsl #32
    // 0xdf54b0: CheckStackOverflow
    //     0xdf54b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf54b4: cmp             SP, x16
    //     0xdf54b8: b.ls            #0xdf54d0
    // 0xdf54bc: ldr             x2, [fp, #0x10]
    // 0xdf54c0: r0 = _handleFocusChange()
    //     0xdf54c0: bl              #0xdf54d8  ; [package:flutter/src/material/dropdown.dart] _DropdownMenuItemButtonState::_handleFocusChange
    // 0xdf54c4: LeaveFrame
    //     0xdf54c4: mov             SP, fp
    //     0xdf54c8: ldp             fp, lr, [SP], #0x10
    // 0xdf54cc: ret
    //     0xdf54cc: ret             
    // 0xdf54d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf54d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf54d4: b               #0xdf54bc
  }
  _ _handleFocusChange(/* No info */) {
    // ** addr: 0xdf54d8, size: 0x124
    // 0xdf54d8: EnterFrame
    //     0xdf54d8: stp             fp, lr, [SP, #-0x10]!
    //     0xdf54dc: mov             fp, SP
    // 0xdf54e0: AllocStack(0x10)
    //     0xdf54e0: sub             SP, SP, #0x10
    // 0xdf54e4: SetupParameters(_DropdownMenuItemButtonState<C1X0> this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xdf54e4: mov             x0, x1
    //     0xdf54e8: stur            x1, [fp, #-8]
    //     0xdf54ec: stur            x2, [fp, #-0x10]
    // 0xdf54f0: CheckStackOverflow
    //     0xdf54f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf54f4: cmp             SP, x16
    //     0xdf54f8: b.ls            #0xdf55e4
    // 0xdf54fc: r1 = LoadStaticField(0x6a0)
    //     0xdf54fc: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0xdf5500: ldr             x1, [x1, #0xd40]
    // 0xdf5504: cmp             w1, NULL
    // 0xdf5508: b.eq            #0xdf55ec
    // 0xdf550c: LoadField: r3 = r1->field_ef
    //     0xdf550c: ldur            w3, [x1, #0xef]
    // 0xdf5510: DecompressPointer r3
    //     0xdf5510: add             x3, x3, HEAP, lsl #32
    // 0xdf5514: cmp             w3, NULL
    // 0xdf5518: b.eq            #0xdf55f0
    // 0xdf551c: LoadField: r1 = r3->field_13
    //     0xdf551c: ldur            w1, [x3, #0x13]
    // 0xdf5520: DecompressPointer r1
    //     0xdf5520: add             x1, x1, HEAP, lsl #32
    // 0xdf5524: LoadField: r3 = r1->field_23
    //     0xdf5524: ldur            w3, [x1, #0x23]
    // 0xdf5528: DecompressPointer r3
    //     0xdf5528: add             x3, x3, HEAP, lsl #32
    // 0xdf552c: mov             x1, x3
    // 0xdf5530: r0 = highlightMode()
    //     0xdf5530: bl              #0x83bde4  ; [package:flutter/src/widgets/focus_manager.dart] _HighlightModeManager::highlightMode
    // 0xdf5534: LoadField: r1 = r0->field_7
    //     0xdf5534: ldur            x1, [x0, #7]
    // 0xdf5538: cmp             x1, #0
    // 0xdf553c: b.gt            #0xdf5548
    // 0xdf5540: r1 = false
    //     0xdf5540: add             x1, NULL, #0x30  ; false
    // 0xdf5544: b               #0xdf554c
    // 0xdf5548: r1 = true
    //     0xdf5548: add             x1, NULL, #0x20  ; true
    // 0xdf554c: ldur            x0, [fp, #-0x10]
    // 0xdf5550: tbnz            w0, #4, #0xdf55d4
    // 0xdf5554: tbnz            w1, #4, #0xdf55d4
    // 0xdf5558: ldur            x0, [fp, #-8]
    // 0xdf555c: LoadField: r1 = r0->field_b
    //     0xdf555c: ldur            w1, [x0, #0xb]
    // 0xdf5560: DecompressPointer r1
    //     0xdf5560: add             x1, x1, HEAP, lsl #32
    // 0xdf5564: cmp             w1, NULL
    // 0xdf5568: b.eq            #0xdf55f4
    // 0xdf556c: LoadField: r2 = r1->field_f
    //     0xdf556c: ldur            w2, [x1, #0xf]
    // 0xdf5570: DecompressPointer r2
    //     0xdf5570: add             x2, x2, HEAP, lsl #32
    // 0xdf5574: LoadField: r3 = r1->field_1b
    //     0xdf5574: ldur            w3, [x1, #0x1b]
    // 0xdf5578: DecompressPointer r3
    //     0xdf5578: add             x3, x3, HEAP, lsl #32
    // 0xdf557c: LoadField: r4 = r1->field_1f
    //     0xdf557c: ldur            w4, [x1, #0x1f]
    // 0xdf5580: DecompressPointer r4
    //     0xdf5580: add             x4, x4, HEAP, lsl #32
    // 0xdf5584: LoadField: d0 = r4->field_1f
    //     0xdf5584: ldur            d0, [x4, #0x1f]
    // 0xdf5588: LoadField: r4 = r1->field_23
    //     0xdf5588: ldur            x4, [x1, #0x23]
    // 0xdf558c: mov             x1, x2
    // 0xdf5590: mov             x2, x3
    // 0xdf5594: mov             x3, x4
    // 0xdf5598: r0 = getMenuLimits()
    //     0xdf5598: bl              #0xdf55fc  ; [package:flutter/src/material/dropdown.dart] _DropdownRoute::getMenuLimits
    // 0xdf559c: mov             x1, x0
    // 0xdf55a0: ldur            x0, [fp, #-8]
    // 0xdf55a4: LoadField: r2 = r0->field_b
    //     0xdf55a4: ldur            w2, [x0, #0xb]
    // 0xdf55a8: DecompressPointer r2
    //     0xdf55a8: add             x2, x2, HEAP, lsl #32
    // 0xdf55ac: cmp             w2, NULL
    // 0xdf55b0: b.eq            #0xdf55f8
    // 0xdf55b4: LoadField: r0 = r2->field_13
    //     0xdf55b4: ldur            w0, [x2, #0x13]
    // 0xdf55b8: DecompressPointer r0
    //     0xdf55b8: add             x0, x0, HEAP, lsl #32
    // 0xdf55bc: LoadField: d0 = r1->field_f
    //     0xdf55bc: ldur            d0, [x1, #0xf]
    // 0xdf55c0: mov             x1, x0
    // 0xdf55c4: r2 = Instance_Cubic
    //     0xdf55c4: add             x2, PP, #0x19, lsl #12  ; [pp+0x19668] Obj!Cubic@129f511
    //     0xdf55c8: ldr             x2, [x2, #0x668]
    // 0xdf55cc: r3 = Instance_Duration
    //     0xdf55cc: ldr             x3, [PP, #0x5668]  ; [pp+0x5668] Obj!Duration@12c8941
    // 0xdf55d0: r0 = animateTo()
    //     0xdf55d0: bl              #0x86e8cc  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::animateTo
    // 0xdf55d4: r0 = Null
    //     0xdf55d4: mov             x0, NULL
    // 0xdf55d8: LeaveFrame
    //     0xdf55d8: mov             SP, fp
    //     0xdf55dc: ldp             fp, lr, [SP], #0x10
    // 0xdf55e0: ret
    //     0xdf55e0: ret             
    // 0xdf55e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf55e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf55e8: b               #0xdf54fc
    // 0xdf55ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf55ec: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf55f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf55f0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf55f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf55f4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf55f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf55f8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleOnTap(dynamic) {
    // ** addr: 0xdf595c, size: 0x38
    // 0xdf595c: EnterFrame
    //     0xdf595c: stp             fp, lr, [SP, #-0x10]!
    //     0xdf5960: mov             fp, SP
    // 0xdf5964: ldr             x0, [fp, #0x10]
    // 0xdf5968: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdf5968: ldur            w1, [x0, #0x17]
    // 0xdf596c: DecompressPointer r1
    //     0xdf596c: add             x1, x1, HEAP, lsl #32
    // 0xdf5970: CheckStackOverflow
    //     0xdf5970: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf5974: cmp             SP, x16
    //     0xdf5978: b.ls            #0xdf598c
    // 0xdf597c: r0 = _handleOnTap()
    //     0xdf597c: bl              #0xdf5994  ; [package:flutter/src/material/dropdown.dart] _DropdownMenuItemButtonState::_handleOnTap
    // 0xdf5980: LeaveFrame
    //     0xdf5980: mov             SP, fp
    //     0xdf5984: ldp             fp, lr, [SP], #0x10
    // 0xdf5988: ret
    //     0xdf5988: ret             
    // 0xdf598c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf598c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf5990: b               #0xdf597c
  }
  _ _handleOnTap(/* No info */) {
    // ** addr: 0xdf5994, size: 0x14c
    // 0xdf5994: EnterFrame
    //     0xdf5994: stp             fp, lr, [SP, #-0x10]!
    //     0xdf5998: mov             fp, SP
    // 0xdf599c: AllocStack(0x40)
    //     0xdf599c: sub             SP, SP, #0x40
    // 0xdf59a0: SetupParameters(_DropdownMenuItemButtonState<C1X0> this /* r1 => r4, fp-0x18 */)
    //     0xdf59a0: mov             x4, x1
    //     0xdf59a4: stur            x1, [fp, #-0x18]
    // 0xdf59a8: CheckStackOverflow
    //     0xdf59a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf59ac: cmp             SP, x16
    //     0xdf59b0: b.ls            #0xdf5acc
    // 0xdf59b4: LoadField: r0 = r4->field_b
    //     0xdf59b4: ldur            w0, [x4, #0xb]
    // 0xdf59b8: DecompressPointer r0
    //     0xdf59b8: add             x0, x0, HEAP, lsl #32
    // 0xdf59bc: cmp             w0, NULL
    // 0xdf59c0: b.eq            #0xdf5ad4
    // 0xdf59c4: LoadField: r1 = r0->field_f
    //     0xdf59c4: ldur            w1, [x0, #0xf]
    // 0xdf59c8: DecompressPointer r1
    //     0xdf59c8: add             x1, x1, HEAP, lsl #32
    // 0xdf59cc: LoadField: r2 = r1->field_97
    //     0xdf59cc: ldur            w2, [x1, #0x97]
    // 0xdf59d0: DecompressPointer r2
    //     0xdf59d0: add             x2, x2, HEAP, lsl #32
    // 0xdf59d4: LoadField: r3 = r0->field_23
    //     0xdf59d4: ldur            x3, [x0, #0x23]
    // 0xdf59d8: LoadField: r0 = r2->field_b
    //     0xdf59d8: ldur            w0, [x2, #0xb]
    // 0xdf59dc: r1 = LoadInt32Instr(r0)
    //     0xdf59dc: sbfx            x1, x0, #1, #0x1f
    // 0xdf59e0: mov             x0, x1
    // 0xdf59e4: mov             x1, x3
    // 0xdf59e8: cmp             x1, x0
    // 0xdf59ec: b.hs            #0xdf5ad8
    // 0xdf59f0: LoadField: r0 = r2->field_f
    //     0xdf59f0: ldur            w0, [x2, #0xf]
    // 0xdf59f4: DecompressPointer r0
    //     0xdf59f4: add             x0, x0, HEAP, lsl #32
    // 0xdf59f8: ArrayLoad: r1 = r0[r3]  ; Unknown_4
    //     0xdf59f8: add             x16, x0, x3, lsl #2
    //     0xdf59fc: ldur            w1, [x16, #0xf]
    // 0xdf5a00: DecompressPointer r1
    //     0xdf5a00: add             x1, x1, HEAP, lsl #32
    // 0xdf5a04: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xdf5a04: ldur            w0, [x1, #0x17]
    // 0xdf5a08: DecompressPointer r0
    //     0xdf5a08: add             x0, x0, HEAP, lsl #32
    // 0xdf5a0c: stur            x0, [fp, #-0x10]
    // 0xdf5a10: LoadField: r5 = r4->field_7
    //     0xdf5a10: ldur            w5, [x4, #7]
    // 0xdf5a14: DecompressPointer r5
    //     0xdf5a14: add             x5, x5, HEAP, lsl #32
    // 0xdf5a18: mov             x2, x5
    // 0xdf5a1c: stur            x5, [fp, #-8]
    // 0xdf5a20: r1 = Null
    //     0xdf5a20: mov             x1, NULL
    // 0xdf5a24: r3 = <_DropdownRouteResult<C1X0>>
    //     0xdf5a24: add             x3, PP, #0x99, lsl #12  ; [pp+0x999d0] TypeArguments: <_DropdownRouteResult<C1X0>>
    //     0xdf5a28: ldr             x3, [x3, #0x9d0]
    // 0xdf5a2c: r30 = InstantiateTypeArgumentsStub
    //     0xdf5a2c: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0xdf5a30: LoadField: r30 = r30->field_7
    //     0xdf5a30: ldur            lr, [lr, #7]
    // 0xdf5a34: blr             lr
    // 0xdf5a38: mov             x4, x0
    // 0xdf5a3c: ldur            x0, [fp, #-0x18]
    // 0xdf5a40: stur            x4, [fp, #-0x28]
    // 0xdf5a44: LoadField: r5 = r0->field_f
    //     0xdf5a44: ldur            w5, [x0, #0xf]
    // 0xdf5a48: DecompressPointer r5
    //     0xdf5a48: add             x5, x5, HEAP, lsl #32
    // 0xdf5a4c: stur            x5, [fp, #-0x20]
    // 0xdf5a50: cmp             w5, NULL
    // 0xdf5a54: b.eq            #0xdf5adc
    // 0xdf5a58: ldur            x2, [fp, #-8]
    // 0xdf5a5c: r1 = Null
    //     0xdf5a5c: mov             x1, NULL
    // 0xdf5a60: r3 = <C1X0>
    //     0xdf5a60: add             x3, PP, #0x11, lsl #12  ; [pp+0x11880] TypeArguments: <C1X0>
    //     0xdf5a64: ldr             x3, [x3, #0x880]
    // 0xdf5a68: r0 = Null
    //     0xdf5a68: mov             x0, NULL
    // 0xdf5a6c: cmp             x2, x0
    // 0xdf5a70: b.eq            #0xdf5a80
    // 0xdf5a74: r30 = InstantiateTypeArgumentsStub
    //     0xdf5a74: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0xdf5a78: LoadField: r30 = r30->field_7
    //     0xdf5a78: ldur            lr, [lr, #7]
    // 0xdf5a7c: blr             lr
    // 0xdf5a80: mov             x1, x0
    // 0xdf5a84: ldur            x0, [fp, #-0x10]
    // 0xdf5a88: LoadField: r2 = r0->field_1b
    //     0xdf5a88: ldur            w2, [x0, #0x1b]
    // 0xdf5a8c: DecompressPointer r2
    //     0xdf5a8c: add             x2, x2, HEAP, lsl #32
    // 0xdf5a90: stur            x2, [fp, #-8]
    // 0xdf5a94: r0 = _DropdownRouteResult()
    //     0xdf5a94: bl              #0xdf5ae0  ; Allocate_DropdownRouteResultStub -> _DropdownRouteResult<X0> (size=0x10)
    // 0xdf5a98: mov             x1, x0
    // 0xdf5a9c: ldur            x0, [fp, #-8]
    // 0xdf5aa0: StoreField: r1->field_b = r0
    //     0xdf5aa0: stur            w0, [x1, #0xb]
    // 0xdf5aa4: ldur            x16, [fp, #-0x28]
    // 0xdf5aa8: ldur            lr, [fp, #-0x20]
    // 0xdf5aac: stp             lr, x16, [SP, #8]
    // 0xdf5ab0: str             x1, [SP]
    // 0xdf5ab4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xdf5ab4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xdf5ab8: r0 = pop()
    //     0xdf5ab8: bl              #0xd190ec  ; [package:flutter/src/widgets/navigator.dart] Navigator::pop
    // 0xdf5abc: r0 = Null
    //     0xdf5abc: mov             x0, NULL
    // 0xdf5ac0: LeaveFrame
    //     0xdf5ac0: mov             SP, fp
    //     0xdf5ac4: ldp             fp, lr, [SP], #0x10
    // 0xdf5ac8: ret
    //     0xdf5ac8: ret             
    // 0xdf5acc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf5acc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf5ad0: b               #0xdf59b4
    // 0xdf5ad4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf5ad4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf5ad8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xdf5ad8: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xdf5adc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf5adc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf6d49c, size: 0x154
    // 0xf6d49c: EnterFrame
    //     0xf6d49c: stp             fp, lr, [SP, #-0x10]!
    //     0xf6d4a0: mov             fp, SP
    // 0xf6d4a4: AllocStack(0x18)
    //     0xf6d4a4: sub             SP, SP, #0x18
    // 0xf6d4a8: SetupParameters(_DropdownMenuItemButtonState<C1X0> this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r3, fp-0x18 */)
    //     0xf6d4a8: mov             x4, x1
    //     0xf6d4ac: mov             x3, x2
    //     0xf6d4b0: stur            x1, [fp, #-0x10]
    //     0xf6d4b4: stur            x2, [fp, #-0x18]
    // 0xf6d4b8: CheckStackOverflow
    //     0xf6d4b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6d4bc: cmp             SP, x16
    //     0xf6d4c0: b.ls            #0xf6d5d8
    // 0xf6d4c4: LoadField: r5 = r4->field_7
    //     0xf6d4c4: ldur            w5, [x4, #7]
    // 0xf6d4c8: DecompressPointer r5
    //     0xf6d4c8: add             x5, x5, HEAP, lsl #32
    // 0xf6d4cc: mov             x0, x3
    // 0xf6d4d0: mov             x2, x5
    // 0xf6d4d4: stur            x5, [fp, #-8]
    // 0xf6d4d8: r1 = Null
    //     0xf6d4d8: mov             x1, NULL
    // 0xf6d4dc: r8 = _DropdownMenuItemButton<C1X0>
    //     0xf6d4dc: add             x8, PP, #0xd3, lsl #12  ; [pp+0xd3578] Type: _DropdownMenuItemButton<C1X0>
    //     0xf6d4e0: ldr             x8, [x8, #0x578]
    // 0xf6d4e4: LoadField: r9 = r8->field_7
    //     0xf6d4e4: ldur            x9, [x8, #7]
    // 0xf6d4e8: r3 = Null
    //     0xf6d4e8: add             x3, PP, #0xd3, lsl #12  ; [pp+0xd3580] Null
    //     0xf6d4ec: ldr             x3, [x3, #0x580]
    // 0xf6d4f0: blr             x9
    // 0xf6d4f4: ldur            x0, [fp, #-0x18]
    // 0xf6d4f8: ldur            x2, [fp, #-8]
    // 0xf6d4fc: r1 = Null
    //     0xf6d4fc: mov             x1, NULL
    // 0xf6d500: cmp             w2, NULL
    // 0xf6d504: b.eq            #0xf6d528
    // 0xf6d508: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf6d508: ldur            w4, [x2, #0x17]
    // 0xf6d50c: DecompressPointer r4
    //     0xf6d50c: add             x4, x4, HEAP, lsl #32
    // 0xf6d510: r8 = X0 bound StatefulWidget
    //     0xf6d510: add             x8, PP, #0x12, lsl #12  ; [pp+0x12498] TypeParameter: X0 bound StatefulWidget
    //     0xf6d514: ldr             x8, [x8, #0x498]
    // 0xf6d518: LoadField: r9 = r4->field_7
    //     0xf6d518: ldur            x9, [x4, #7]
    // 0xf6d51c: r3 = Null
    //     0xf6d51c: add             x3, PP, #0xd3, lsl #12  ; [pp+0xd3590] Null
    //     0xf6d520: ldr             x3, [x3, #0x590]
    // 0xf6d524: blr             x9
    // 0xf6d528: ldur            x0, [fp, #-0x18]
    // 0xf6d52c: LoadField: r1 = r0->field_23
    //     0xf6d52c: ldur            x1, [x0, #0x23]
    // 0xf6d530: ldur            x2, [fp, #-0x10]
    // 0xf6d534: LoadField: r3 = r2->field_b
    //     0xf6d534: ldur            w3, [x2, #0xb]
    // 0xf6d538: DecompressPointer r3
    //     0xf6d538: add             x3, x3, HEAP, lsl #32
    // 0xf6d53c: cmp             w3, NULL
    // 0xf6d540: b.eq            #0xf6d5e0
    // 0xf6d544: LoadField: r4 = r3->field_23
    //     0xf6d544: ldur            x4, [x3, #0x23]
    // 0xf6d548: cmp             x1, x4
    // 0xf6d54c: b.ne            #0xf6d5a8
    // 0xf6d550: LoadField: r1 = r0->field_f
    //     0xf6d550: ldur            w1, [x0, #0xf]
    // 0xf6d554: DecompressPointer r1
    //     0xf6d554: add             x1, x1, HEAP, lsl #32
    // 0xf6d558: LoadField: r0 = r1->field_6f
    //     0xf6d558: ldur            w0, [x1, #0x6f]
    // 0xf6d55c: DecompressPointer r0
    //     0xf6d55c: add             x0, x0, HEAP, lsl #32
    // 0xf6d560: LoadField: r4 = r3->field_f
    //     0xf6d560: ldur            w4, [x3, #0xf]
    // 0xf6d564: DecompressPointer r4
    //     0xf6d564: add             x4, x4, HEAP, lsl #32
    // 0xf6d568: LoadField: r3 = r4->field_6f
    //     0xf6d568: ldur            w3, [x4, #0x6f]
    // 0xf6d56c: DecompressPointer r3
    //     0xf6d56c: add             x3, x3, HEAP, lsl #32
    // 0xf6d570: cmp             w0, w3
    // 0xf6d574: b.ne            #0xf6d5a8
    // 0xf6d578: LoadField: r0 = r1->field_a3
    //     0xf6d578: ldur            x0, [x1, #0xa3]
    // 0xf6d57c: LoadField: r3 = r4->field_a3
    //     0xf6d57c: ldur            x3, [x4, #0xa3]
    // 0xf6d580: cmp             x0, x3
    // 0xf6d584: b.ne            #0xf6d5a8
    // 0xf6d588: LoadField: r0 = r4->field_97
    //     0xf6d588: ldur            w0, [x4, #0x97]
    // 0xf6d58c: DecompressPointer r0
    //     0xf6d58c: add             x0, x0, HEAP, lsl #32
    // 0xf6d590: LoadField: r3 = r0->field_b
    //     0xf6d590: ldur            w3, [x0, #0xb]
    // 0xf6d594: LoadField: r0 = r1->field_97
    //     0xf6d594: ldur            w0, [x1, #0x97]
    // 0xf6d598: DecompressPointer r0
    //     0xf6d598: add             x0, x0, HEAP, lsl #32
    // 0xf6d59c: LoadField: r1 = r0->field_b
    //     0xf6d59c: ldur            w1, [x0, #0xb]
    // 0xf6d5a0: cmp             w3, w1
    // 0xf6d5a4: b.eq            #0xf6d5c8
    // 0xf6d5a8: LoadField: r1 = r2->field_13
    //     0xf6d5a8: ldur            w1, [x2, #0x13]
    // 0xf6d5ac: DecompressPointer r1
    //     0xf6d5ac: add             x1, x1, HEAP, lsl #32
    // 0xf6d5b0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf6d5b4: cmp             w1, w16
    // 0xf6d5b8: b.eq            #0xf6d5e4
    // 0xf6d5bc: r0 = dispose()
    //     0xf6d5bc: bl              #0xb29014  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::dispose
    // 0xf6d5c0: ldur            x1, [fp, #-0x10]
    // 0xf6d5c4: r0 = _setOpacityAnimation()
    //     0xf6d5c4: bl              #0xf6d5f0  ; [package:flutter/src/material/dropdown.dart] _DropdownMenuItemButtonState::_setOpacityAnimation
    // 0xf6d5c8: r0 = Null
    //     0xf6d5c8: mov             x0, NULL
    // 0xf6d5cc: LeaveFrame
    //     0xf6d5cc: mov             SP, fp
    //     0xf6d5d0: ldp             fp, lr, [SP], #0x10
    // 0xf6d5d4: ret
    //     0xf6d5d4: ret             
    // 0xf6d5d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6d5d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6d5dc: b               #0xf6d4c4
    // 0xf6d5e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6d5e0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6d5e4: r9 = _opacityAnimation
    //     0xf6d5e4: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3570] Field <_DropdownMenuItemButtonState@83005770._opacityAnimation@83005770>: late (offset: 0x14)
    //     0xf6d5e8: ldr             x9, [x9, #0x570]
    // 0xf6d5ec: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf6d5ec: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _setOpacityAnimation(/* No info */) {
    // ** addr: 0xf6d5f0, size: 0x1fc
    // 0xf6d5f0: EnterFrame
    //     0xf6d5f0: stp             fp, lr, [SP, #-0x10]!
    //     0xf6d5f4: mov             fp, SP
    // 0xf6d5f8: AllocStack(0x28)
    //     0xf6d5f8: sub             SP, SP, #0x28
    // 0xf6d5fc: d1 = 1.500000
    //     0xf6d5fc: fmov            d1, #1.50000000
    // 0xf6d600: d0 = 0.500000
    //     0xf6d600: fmov            d0, #0.50000000
    // 0xf6d604: mov             x0, x1
    // 0xf6d608: stur            x1, [fp, #-0x10]
    // 0xf6d60c: CheckStackOverflow
    //     0xf6d60c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6d610: cmp             SP, x16
    //     0xf6d614: b.ls            #0xf6d7d8
    // 0xf6d618: LoadField: r1 = r0->field_b
    //     0xf6d618: ldur            w1, [x0, #0xb]
    // 0xf6d61c: DecompressPointer r1
    //     0xf6d61c: add             x1, x1, HEAP, lsl #32
    // 0xf6d620: cmp             w1, NULL
    // 0xf6d624: b.eq            #0xf6d7e0
    // 0xf6d628: LoadField: r2 = r1->field_f
    //     0xf6d628: ldur            w2, [x1, #0xf]
    // 0xf6d62c: DecompressPointer r2
    //     0xf6d62c: add             x2, x2, HEAP, lsl #32
    // 0xf6d630: LoadField: r3 = r2->field_97
    //     0xf6d630: ldur            w3, [x2, #0x97]
    // 0xf6d634: DecompressPointer r3
    //     0xf6d634: add             x3, x3, HEAP, lsl #32
    // 0xf6d638: LoadField: r4 = r3->field_b
    //     0xf6d638: ldur            w4, [x3, #0xb]
    // 0xf6d63c: r16 = LoadInt32Instr(r4)
    //     0xf6d63c: sbfx            x16, x4, #1, #0x1f
    // 0xf6d640: scvtf           d2, w16
    // 0xf6d644: fadd            d3, d2, d1
    // 0xf6d648: fdiv            d2, d0, d3
    // 0xf6d64c: LoadField: r3 = r1->field_23
    //     0xf6d64c: ldur            x3, [x1, #0x23]
    // 0xf6d650: LoadField: r1 = r2->field_a3
    //     0xf6d650: ldur            x1, [x2, #0xa3]
    // 0xf6d654: cmp             x3, x1
    // 0xf6d658: b.ne            #0xf6d6bc
    // 0xf6d65c: LoadField: r3 = r2->field_6f
    //     0xf6d65c: ldur            w3, [x2, #0x6f]
    // 0xf6d660: DecompressPointer r3
    //     0xf6d660: add             x3, x3, HEAP, lsl #32
    // 0xf6d664: stur            x3, [fp, #-8]
    // 0xf6d668: cmp             w3, NULL
    // 0xf6d66c: b.eq            #0xf6d7e4
    // 0xf6d670: r1 = <double>
    //     0xf6d670: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf6d674: r0 = CurvedAnimation()
    //     0xf6d674: bl              #0x915e4c  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0xf6d678: mov             x1, x0
    // 0xf6d67c: ldur            x3, [fp, #-8]
    // 0xf6d680: r2 = Instance_Threshold
    //     0xf6d680: add             x2, PP, #0x8c, lsl #12  ; [pp+0x8c910] Obj!Threshold@129f8f1
    //     0xf6d684: ldr             x2, [x2, #0x910]
    // 0xf6d688: stur            x0, [fp, #-8]
    // 0xf6d68c: r4 = const [0, 0x3, 0, 0x3, null]
    //     0xf6d68c: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0xf6d690: r0 = CurvedAnimation()
    //     0xf6d690: bl              #0x915be4  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0xf6d694: ldur            x0, [fp, #-8]
    // 0xf6d698: ldur            x4, [fp, #-0x10]
    // 0xf6d69c: StoreField: r4->field_13 = r0
    //     0xf6d69c: stur            w0, [x4, #0x13]
    //     0xf6d6a0: ldurb           w16, [x4, #-1]
    //     0xf6d6a4: ldurb           w17, [x0, #-1]
    //     0xf6d6a8: and             x16, x17, x16, lsr #2
    //     0xf6d6ac: tst             x16, HEAP, lsr #32
    //     0xf6d6b0: b.eq            #0xf6d6b8
    //     0xf6d6b4: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xf6d6b8: b               #0xf6d7c8
    // 0xf6d6bc: mov             x4, x0
    // 0xf6d6c0: d3 = 0.000000
    //     0xf6d6c0: eor             v3.16b, v3.16b, v3.16b
    // 0xf6d6c4: add             x0, x3, #1
    // 0xf6d6c8: scvtf           d4, x0
    // 0xf6d6cc: fmul            d5, d4, d2
    // 0xf6d6d0: fadd            d4, d5, d0
    // 0xf6d6d4: fcmp            d3, d4
    // 0xf6d6d8: b.le            #0xf6d6e8
    // 0xf6d6dc: d4 = 0.000000
    //     0xf6d6dc: eor             v4.16b, v4.16b, v4.16b
    // 0xf6d6e0: d0 = 1.000000
    //     0xf6d6e0: fmov            d0, #1.00000000
    // 0xf6d6e4: b               #0xf6d708
    // 0xf6d6e8: d0 = 1.000000
    //     0xf6d6e8: fmov            d0, #1.00000000
    // 0xf6d6ec: fcmp            d4, d0
    // 0xf6d6f0: b.le            #0xf6d6fc
    // 0xf6d6f4: d4 = 1.000000
    //     0xf6d6f4: fmov            d4, #1.00000000
    // 0xf6d6f8: b               #0xf6d708
    // 0xf6d6fc: fcmp            d4, d4
    // 0xf6d700: b.vc            #0xf6d708
    // 0xf6d704: d4 = 1.000000
    //     0xf6d704: fmov            d4, #1.00000000
    // 0xf6d708: stur            d4, [fp, #-0x28]
    // 0xf6d70c: fmul            d5, d2, d1
    // 0xf6d710: fadd            d1, d4, d5
    // 0xf6d714: fcmp            d3, d1
    // 0xf6d718: b.le            #0xf6d724
    // 0xf6d71c: d0 = 0.000000
    //     0xf6d71c: eor             v0.16b, v0.16b, v0.16b
    // 0xf6d720: b               #0xf6d748
    // 0xf6d724: fcmp            d1, d0
    // 0xf6d728: b.le            #0xf6d734
    // 0xf6d72c: d0 = 1.000000
    //     0xf6d72c: fmov            d0, #1.00000000
    // 0xf6d730: b               #0xf6d748
    // 0xf6d734: fcmp            d1, d1
    // 0xf6d738: b.vc            #0xf6d744
    // 0xf6d73c: d0 = 1.000000
    //     0xf6d73c: fmov            d0, #1.00000000
    // 0xf6d740: b               #0xf6d748
    // 0xf6d744: mov             v0.16b, v1.16b
    // 0xf6d748: stur            d0, [fp, #-0x20]
    // 0xf6d74c: LoadField: r3 = r2->field_6f
    //     0xf6d74c: ldur            w3, [x2, #0x6f]
    // 0xf6d750: DecompressPointer r3
    //     0xf6d750: add             x3, x3, HEAP, lsl #32
    // 0xf6d754: stur            x3, [fp, #-8]
    // 0xf6d758: cmp             w3, NULL
    // 0xf6d75c: b.eq            #0xf6d7e8
    // 0xf6d760: r1 = <double>
    //     0xf6d760: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf6d764: r0 = Interval()
    //     0xf6d764: bl              #0xc0c688  ; AllocateIntervalStub -> Interval (size=0x20)
    // 0xf6d768: ldur            d0, [fp, #-0x28]
    // 0xf6d76c: stur            x0, [fp, #-0x18]
    // 0xf6d770: StoreField: r0->field_b = d0
    //     0xf6d770: stur            d0, [x0, #0xb]
    // 0xf6d774: ldur            d0, [fp, #-0x20]
    // 0xf6d778: StoreField: r0->field_13 = d0
    //     0xf6d778: stur            d0, [x0, #0x13]
    // 0xf6d77c: r1 = Instance__Linear
    //     0xf6d77c: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] Obj!_Linear@129fef1
    // 0xf6d780: StoreField: r0->field_1b = r1
    //     0xf6d780: stur            w1, [x0, #0x1b]
    // 0xf6d784: r1 = <double>
    //     0xf6d784: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf6d788: r0 = CurvedAnimation()
    //     0xf6d788: bl              #0x915e4c  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0xf6d78c: mov             x1, x0
    // 0xf6d790: ldur            x2, [fp, #-0x18]
    // 0xf6d794: ldur            x3, [fp, #-8]
    // 0xf6d798: stur            x0, [fp, #-8]
    // 0xf6d79c: r4 = const [0, 0x3, 0, 0x3, null]
    //     0xf6d79c: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0xf6d7a0: r0 = CurvedAnimation()
    //     0xf6d7a0: bl              #0x915be4  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0xf6d7a4: ldur            x0, [fp, #-8]
    // 0xf6d7a8: ldur            x1, [fp, #-0x10]
    // 0xf6d7ac: StoreField: r1->field_13 = r0
    //     0xf6d7ac: stur            w0, [x1, #0x13]
    //     0xf6d7b0: ldurb           w16, [x1, #-1]
    //     0xf6d7b4: ldurb           w17, [x0, #-1]
    //     0xf6d7b8: and             x16, x17, x16, lsr #2
    //     0xf6d7bc: tst             x16, HEAP, lsr #32
    //     0xf6d7c0: b.eq            #0xf6d7c8
    //     0xf6d7c4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf6d7c8: r0 = Null
    //     0xf6d7c8: mov             x0, NULL
    // 0xf6d7cc: LeaveFrame
    //     0xf6d7cc: mov             SP, fp
    //     0xf6d7d0: ldp             fp, lr, [SP], #0x10
    // 0xf6d7d4: ret
    //     0xf6d7d4: ret             
    // 0xf6d7d8: r0 = StackOverflowSharedWithFPURegs()
    //     0xf6d7d8: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xf6d7dc: b               #0xf6d618
    // 0xf6d7e0: r0 = NullCastErrorSharedWithFPURegs()
    //     0xf6d7e0: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xf6d7e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6d7e4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6d7e8: r0 = NullCastErrorSharedWithFPURegs()
    //     0xf6d7e8: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0xf908c4, size: 0x30
    // 0xf908c4: EnterFrame
    //     0xf908c4: stp             fp, lr, [SP, #-0x10]!
    //     0xf908c8: mov             fp, SP
    // 0xf908cc: CheckStackOverflow
    //     0xf908cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf908d0: cmp             SP, x16
    //     0xf908d4: b.ls            #0xf908ec
    // 0xf908d8: r0 = _setOpacityAnimation()
    //     0xf908d8: bl              #0xf6d5f0  ; [package:flutter/src/material/dropdown.dart] _DropdownMenuItemButtonState::_setOpacityAnimation
    // 0xf908dc: r0 = Null
    //     0xf908dc: mov             x0, NULL
    // 0xf908e0: LeaveFrame
    //     0xf908e0: mov             SP, fp
    //     0xf908e4: ldp             fp, lr, [SP], #0x10
    // 0xf908e8: ret
    //     0xf908e8: ret             
    // 0xf908ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf908ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf908f0: b               #0xf908d8
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10e5aa0, size: 0x54
    // 0x10e5aa0: EnterFrame
    //     0x10e5aa0: stp             fp, lr, [SP, #-0x10]!
    //     0x10e5aa4: mov             fp, SP
    // 0x10e5aa8: CheckStackOverflow
    //     0x10e5aa8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e5aac: cmp             SP, x16
    //     0x10e5ab0: b.ls            #0x10e5ae0
    // 0x10e5ab4: LoadField: r0 = r1->field_13
    //     0x10e5ab4: ldur            w0, [x1, #0x13]
    // 0x10e5ab8: DecompressPointer r0
    //     0x10e5ab8: add             x0, x0, HEAP, lsl #32
    // 0x10e5abc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10e5ac0: cmp             w0, w16
    // 0x10e5ac4: b.eq            #0x10e5ae8
    // 0x10e5ac8: mov             x1, x0
    // 0x10e5acc: r0 = dispose()
    //     0x10e5acc: bl              #0xb29014  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::dispose
    // 0x10e5ad0: r0 = Null
    //     0x10e5ad0: mov             x0, NULL
    // 0x10e5ad4: LeaveFrame
    //     0x10e5ad4: mov             SP, fp
    //     0x10e5ad8: ldp             fp, lr, [SP], #0x10
    // 0x10e5adc: ret
    //     0x10e5adc: ret             
    // 0x10e5ae0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e5ae0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e5ae4: b               #0x10e5ab4
    // 0x10e5ae8: r9 = _opacityAnimation
    //     0x10e5ae8: add             x9, PP, #0xd3, lsl #12  ; [pp+0xd3570] Field <_DropdownMenuItemButtonState@83005770._opacityAnimation@83005770>: late (offset: 0x14)
    //     0x10e5aec: ldr             x9, [x9, #0x570]
    // 0x10e5af0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x10e5af0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 5759, size: 0x34, field offset: 0x34
class _DropdownButtonFormFieldState<C1X0> extends FormFieldState<C1X0> {

  [closure] void didChange(dynamic, Object?) {
    // ** addr: 0xe636fc, size: 0x3c
    // 0xe636fc: EnterFrame
    //     0xe636fc: stp             fp, lr, [SP, #-0x10]!
    //     0xe63700: mov             fp, SP
    // 0xe63704: ldr             x0, [fp, #0x18]
    // 0xe63708: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xe63708: ldur            w1, [x0, #0x17]
    // 0xe6370c: DecompressPointer r1
    //     0xe6370c: add             x1, x1, HEAP, lsl #32
    // 0xe63710: CheckStackOverflow
    //     0xe63710: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe63714: cmp             SP, x16
    //     0xe63718: b.ls            #0xe63730
    // 0xe6371c: ldr             x2, [fp, #0x10]
    // 0xe63720: r0 = didChange()
    //     0xe63720: bl              #0xe63738  ; [package:flutter/src/material/dropdown.dart] _DropdownButtonFormFieldState::didChange
    // 0xe63724: LeaveFrame
    //     0xe63724: mov             SP, fp
    //     0xe63728: ldp             fp, lr, [SP], #0x10
    // 0xe6372c: ret
    //     0xe6372c: ret             
    // 0xe63730: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe63730: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe63734: b               #0xe6371c
  }
  _ didChange(/* No info */) {
    // ** addr: 0xe63738, size: 0xf0
    // 0xe63738: EnterFrame
    //     0xe63738: stp             fp, lr, [SP, #-0x10]!
    //     0xe6373c: mov             fp, SP
    // 0xe63740: AllocStack(0x28)
    //     0xe63740: sub             SP, SP, #0x28
    // 0xe63744: SetupParameters(_DropdownButtonFormFieldState<C1X0> this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r3, fp-0x18 */)
    //     0xe63744: mov             x4, x1
    //     0xe63748: mov             x3, x2
    //     0xe6374c: stur            x1, [fp, #-0x10]
    //     0xe63750: stur            x2, [fp, #-0x18]
    // 0xe63754: CheckStackOverflow
    //     0xe63754: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe63758: cmp             SP, x16
    //     0xe6375c: b.ls            #0xe6381c
    // 0xe63760: LoadField: r5 = r4->field_7
    //     0xe63760: ldur            w5, [x4, #7]
    // 0xe63764: DecompressPointer r5
    //     0xe63764: add             x5, x5, HEAP, lsl #32
    // 0xe63768: mov             x0, x3
    // 0xe6376c: mov             x2, x5
    // 0xe63770: stur            x5, [fp, #-8]
    // 0xe63774: r1 = Null
    //     0xe63774: mov             x1, NULL
    // 0xe63778: cmp             w0, NULL
    // 0xe6377c: b.eq            #0xe637a8
    // 0xe63780: cmp             w2, NULL
    // 0xe63784: b.eq            #0xe637a8
    // 0xe63788: LoadField: r4 = r2->field_1b
    //     0xe63788: ldur            w4, [x2, #0x1b]
    // 0xe6378c: DecompressPointer r4
    //     0xe6378c: add             x4, x4, HEAP, lsl #32
    // 0xe63790: r8 = C1X0?
    //     0xe63790: add             x8, PP, #0x26, lsl #12  ; [pp+0x26fd0] TypeParameter: C1X0?
    //     0xe63794: ldr             x8, [x8, #0xfd0]
    // 0xe63798: LoadField: r9 = r4->field_7
    //     0xe63798: ldur            x9, [x4, #7]
    // 0xe6379c: r3 = Null
    //     0xe6379c: add             x3, PP, #0x28, lsl #12  ; [pp+0x282f8] Null
    //     0xe637a0: ldr             x3, [x3, #0x2f8]
    // 0xe637a4: blr             x9
    // 0xe637a8: ldur            x1, [fp, #-0x10]
    // 0xe637ac: ldur            x2, [fp, #-0x18]
    // 0xe637b0: r0 = didChange()
    //     0xe637b0: bl              #0xd93d08  ; [package:flutter/src/widgets/form.dart] FormFieldState::didChange
    // 0xe637b4: ldur            x1, [fp, #-0x10]
    // 0xe637b8: r0 = _dropdownButtonFormField()
    //     0xe637b8: bl              #0xe63828  ; [package:flutter/src/material/dropdown.dart] _DropdownButtonFormFieldState::_dropdownButtonFormField
    // 0xe637bc: LoadField: r3 = r0->field_2f
    //     0xe637bc: ldur            w3, [x0, #0x2f]
    // 0xe637c0: DecompressPointer r3
    //     0xe637c0: add             x3, x3, HEAP, lsl #32
    // 0xe637c4: mov             x0, x3
    // 0xe637c8: ldur            x2, [fp, #-8]
    // 0xe637cc: stur            x3, [fp, #-0x10]
    // 0xe637d0: r1 = Null
    //     0xe637d0: mov             x1, NULL
    // 0xe637d4: r8 = ((dynamic this, C1X0?) => void?)?
    //     0xe637d4: add             x8, PP, #0x28, lsl #12  ; [pp+0x28308] FunctionType: ((dynamic this, C1X0?) => void?)?
    //     0xe637d8: ldr             x8, [x8, #0x308]
    // 0xe637dc: LoadField: r9 = r8->field_7
    //     0xe637dc: ldur            x9, [x8, #7]
    // 0xe637e0: r3 = Null
    //     0xe637e0: add             x3, PP, #0x28, lsl #12  ; [pp+0x28310] Null
    //     0xe637e4: ldr             x3, [x3, #0x310]
    // 0xe637e8: blr             x9
    // 0xe637ec: ldur            x0, [fp, #-0x10]
    // 0xe637f0: cmp             w0, NULL
    // 0xe637f4: b.eq            #0xe63824
    // 0xe637f8: ldur            x16, [fp, #-0x18]
    // 0xe637fc: stp             x16, x0, [SP]
    // 0xe63800: ClosureCall
    //     0xe63800: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xe63804: ldur            x2, [x0, #0x1f]
    //     0xe63808: blr             x2
    // 0xe6380c: r0 = Null
    //     0xe6380c: mov             x0, NULL
    // 0xe63810: LeaveFrame
    //     0xe63810: mov             SP, fp
    //     0xe63814: ldp             fp, lr, [SP], #0x10
    // 0xe63818: ret
    //     0xe63818: ret             
    // 0xe6381c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe6381c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe63820: b               #0xe63760
    // 0xe63824: r0 = NullErrorSharedWithoutFPURegs()
    //     0xe63824: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  get _ _dropdownButtonFormField(/* No info */) {
    // ** addr: 0xe63828, size: 0x5c
    // 0xe63828: EnterFrame
    //     0xe63828: stp             fp, lr, [SP, #-0x10]!
    //     0xe6382c: mov             fp, SP
    // 0xe63830: AllocStack(0x8)
    //     0xe63830: sub             SP, SP, #8
    // 0xe63834: LoadField: r3 = r1->field_b
    //     0xe63834: ldur            w3, [x1, #0xb]
    // 0xe63838: DecompressPointer r3
    //     0xe63838: add             x3, x3, HEAP, lsl #32
    // 0xe6383c: stur            x3, [fp, #-8]
    // 0xe63840: cmp             w3, NULL
    // 0xe63844: b.eq            #0xe63880
    // 0xe63848: LoadField: r2 = r1->field_7
    //     0xe63848: ldur            w2, [x1, #7]
    // 0xe6384c: DecompressPointer r2
    //     0xe6384c: add             x2, x2, HEAP, lsl #32
    // 0xe63850: mov             x0, x3
    // 0xe63854: r1 = Null
    //     0xe63854: mov             x1, NULL
    // 0xe63858: r8 = DropdownButtonFormField<C1X0>
    //     0xe63858: add             x8, PP, #0x28, lsl #12  ; [pp+0x28320] Type: DropdownButtonFormField<C1X0>
    //     0xe6385c: ldr             x8, [x8, #0x320]
    // 0xe63860: LoadField: r9 = r8->field_7
    //     0xe63860: ldur            x9, [x8, #7]
    // 0xe63864: r3 = Null
    //     0xe63864: add             x3, PP, #0x28, lsl #12  ; [pp+0x28328] Null
    //     0xe63868: ldr             x3, [x3, #0x328]
    // 0xe6386c: blr             x9
    // 0xe63870: ldur            x0, [fp, #-8]
    // 0xe63874: LeaveFrame
    //     0xe63874: mov             SP, fp
    //     0xe63878: ldp             fp, lr, [SP], #0x10
    // 0xe6387c: ret
    //     0xe6387c: ret             
    // 0xe63880: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe63880: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf383f4, size: 0x104
    // 0xf383f4: EnterFrame
    //     0xf383f4: stp             fp, lr, [SP, #-0x10]!
    //     0xf383f8: mov             fp, SP
    // 0xf383fc: AllocStack(0x20)
    //     0xf383fc: sub             SP, SP, #0x20
    // 0xf38400: SetupParameters(_DropdownButtonFormFieldState<C1X0> this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xf38400: mov             x4, x1
    //     0xf38404: mov             x3, x2
    //     0xf38408: stur            x1, [fp, #-8]
    //     0xf3840c: stur            x2, [fp, #-0x10]
    // 0xf38410: CheckStackOverflow
    //     0xf38410: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf38414: cmp             SP, x16
    //     0xf38418: b.ls            #0xf384e8
    // 0xf3841c: LoadField: r2 = r4->field_7
    //     0xf3841c: ldur            w2, [x4, #7]
    // 0xf38420: DecompressPointer r2
    //     0xf38420: add             x2, x2, HEAP, lsl #32
    // 0xf38424: mov             x0, x3
    // 0xf38428: r1 = Null
    //     0xf38428: mov             x1, NULL
    // 0xf3842c: r8 = DropdownButtonFormField<C1X0>
    //     0xf3842c: add             x8, PP, #0x28, lsl #12  ; [pp+0x28320] Type: DropdownButtonFormField<C1X0>
    //     0xf38430: ldr             x8, [x8, #0x320]
    // 0xf38434: LoadField: r9 = r8->field_7
    //     0xf38434: ldur            x9, [x8, #7]
    // 0xf38438: r3 = Null
    //     0xf38438: add             x3, PP, #0x99, lsl #12  ; [pp+0x99a80] Null
    //     0xf3843c: ldr             x3, [x3, #0xa80]
    // 0xf38440: blr             x9
    // 0xf38444: ldur            x1, [fp, #-8]
    // 0xf38448: ldur            x2, [fp, #-0x10]
    // 0xf3844c: r0 = didUpdateWidget()
    //     0xf3844c: bl              #0xf384f8  ; [package:flutter/src/widgets/form.dart] FormFieldState::didUpdateWidget
    // 0xf38450: ldur            x0, [fp, #-0x10]
    // 0xf38454: LoadField: r1 = r0->field_1f
    //     0xf38454: ldur            w1, [x0, #0x1f]
    // 0xf38458: DecompressPointer r1
    //     0xf38458: add             x1, x1, HEAP, lsl #32
    // 0xf3845c: ldur            x2, [fp, #-8]
    // 0xf38460: LoadField: r0 = r2->field_b
    //     0xf38460: ldur            w0, [x2, #0xb]
    // 0xf38464: DecompressPointer r0
    //     0xf38464: add             x0, x0, HEAP, lsl #32
    // 0xf38468: cmp             w0, NULL
    // 0xf3846c: b.eq            #0xf384f0
    // 0xf38470: LoadField: r3 = r0->field_1f
    //     0xf38470: ldur            w3, [x0, #0x1f]
    // 0xf38474: DecompressPointer r3
    //     0xf38474: add             x3, x3, HEAP, lsl #32
    // 0xf38478: r0 = 60
    //     0xf38478: mov             x0, #0x3c
    // 0xf3847c: branchIfSmi(r1, 0xf38488)
    //     0xf3847c: tbz             w1, #0, #0xf38488
    // 0xf38480: r0 = LoadClassIdInstr(r1)
    //     0xf38480: ldur            x0, [x1, #-1]
    //     0xf38484: ubfx            x0, x0, #0xc, #0x14
    // 0xf38488: stp             x3, x1, [SP]
    // 0xf3848c: mov             lr, x0
    // 0xf38490: ldr             lr, [x21, lr, lsl #3]
    // 0xf38494: blr             lr
    // 0xf38498: tbz             w0, #4, #0xf384d8
    // 0xf3849c: ldur            x1, [fp, #-8]
    // 0xf384a0: LoadField: r2 = r1->field_b
    //     0xf384a0: ldur            w2, [x1, #0xb]
    // 0xf384a4: DecompressPointer r2
    //     0xf384a4: add             x2, x2, HEAP, lsl #32
    // 0xf384a8: cmp             w2, NULL
    // 0xf384ac: b.eq            #0xf384f4
    // 0xf384b0: LoadField: r0 = r2->field_1f
    //     0xf384b0: ldur            w0, [x2, #0x1f]
    // 0xf384b4: DecompressPointer r0
    //     0xf384b4: add             x0, x0, HEAP, lsl #32
    // 0xf384b8: StoreField: r1->field_23 = r0
    //     0xf384b8: stur            w0, [x1, #0x23]
    //     0xf384bc: tbz             w0, #0, #0xf384d8
    //     0xf384c0: ldurb           w16, [x1, #-1]
    //     0xf384c4: ldurb           w17, [x0, #-1]
    //     0xf384c8: and             x16, x17, x16, lsr #2
    //     0xf384cc: tst             x16, HEAP, lsr #32
    //     0xf384d0: b.eq            #0xf384d8
    //     0xf384d4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf384d8: r0 = Null
    //     0xf384d8: mov             x0, NULL
    // 0xf384dc: LeaveFrame
    //     0xf384dc: mov             SP, fp
    //     0xf384e0: ldp             fp, lr, [SP], #0x10
    // 0xf384e4: ret
    //     0xf384e4: ret             
    // 0xf384e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf384e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf384ec: b               #0xf3841c
    // 0xf384f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf384f0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf384f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf384f4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 5761, size: 0x34, field offset: 0x14
class _DropdownButtonState<C1X0> extends _MixinApplication35&State&WidgetsBindingObserver<C1X0> {

  late Map<Type, Action<Intent>> _actionMap; // offset: 0x24

  _ build(/* No info */) {
    // ** addr: 0xd1b434, size: 0x1390
    // 0xd1b434: EnterFrame
    //     0xd1b434: stp             fp, lr, [SP, #-0x10]!
    //     0xd1b438: mov             fp, SP
    // 0xd1b43c: AllocStack(0xa0)
    //     0xd1b43c: sub             SP, SP, #0xa0
    // 0xd1b440: SetupParameters(_DropdownButtonState<C1X0> this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xd1b440: stur            x1, [fp, #-8]
    //     0xd1b444: stur            x2, [fp, #-0x10]
    // 0xd1b448: CheckStackOverflow
    //     0xd1b448: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd1b44c: cmp             SP, x16
    //     0xd1b450: b.ls            #0xd1c718
    // 0xd1b454: r1 = 1
    //     0xd1b454: mov             x1, #1
    // 0xd1b458: r0 = AllocateContext()
    //     0xd1b458: bl              #0x13de838  ; AllocateContextStub
    // 0xd1b45c: mov             x3, x0
    // 0xd1b460: ldur            x0, [fp, #-8]
    // 0xd1b464: stur            x3, [fp, #-0x18]
    // 0xd1b468: StoreField: r3->field_f = r0
    //     0xd1b468: stur            w0, [x3, #0xf]
    // 0xd1b46c: mov             x1, x0
    // 0xd1b470: ldur            x2, [fp, #-0x10]
    // 0xd1b474: r0 = _getOrientation()
    //     0xd1b474: bl              #0xd1eb3c  ; [package:flutter/src/material/dropdown.dart] _DropdownButtonState::_getOrientation
    // 0xd1b478: mov             x3, x0
    // 0xd1b47c: ldur            x2, [fp, #-8]
    // 0xd1b480: stur            x3, [fp, #-0x20]
    // 0xd1b484: LoadField: r0 = r2->field_1b
    //     0xd1b484: ldur            w0, [x2, #0x1b]
    // 0xd1b488: DecompressPointer r0
    //     0xd1b488: add             x0, x0, HEAP, lsl #32
    // 0xd1b48c: cmp             w0, NULL
    // 0xd1b490: b.ne            #0xd1b4b8
    // 0xd1b494: mov             x0, x3
    // 0xd1b498: StoreField: r2->field_1b = r0
    //     0xd1b498: stur            w0, [x2, #0x1b]
    //     0xd1b49c: ldurb           w16, [x2, #-1]
    //     0xd1b4a0: ldurb           w17, [x0, #-1]
    //     0xd1b4a4: and             x16, x17, x16, lsr #2
    //     0xd1b4a8: tst             x16, HEAP, lsr #32
    //     0xd1b4ac: b.eq            #0xd1b4b4
    //     0xd1b4b0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd1b4b4: mov             x0, x3
    // 0xd1b4b8: cmp             w3, w0
    // 0xd1b4bc: b.eq            #0xd1b4f0
    // 0xd1b4c0: mov             x1, x2
    // 0xd1b4c4: r0 = _removeDropdownRoute()
    //     0xd1b4c4: bl              #0xd1e8e4  ; [package:flutter/src/material/dropdown.dart] _DropdownButtonState::_removeDropdownRoute
    // 0xd1b4c8: ldur            x0, [fp, #-0x20]
    // 0xd1b4cc: ldur            x1, [fp, #-8]
    // 0xd1b4d0: StoreField: r1->field_1b = r0
    //     0xd1b4d0: stur            w0, [x1, #0x1b]
    //     0xd1b4d4: ldurb           w16, [x1, #-1]
    //     0xd1b4d8: ldurb           w17, [x0, #-1]
    //     0xd1b4dc: and             x16, x17, x16, lsr #2
    //     0xd1b4e0: tst             x16, HEAP, lsr #32
    //     0xd1b4e4: b.eq            #0xd1b4ec
    //     0xd1b4e8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd1b4ec: b               #0xd1b4f4
    // 0xd1b4f0: mov             x1, x2
    // 0xd1b4f4: LoadField: r0 = r1->field_b
    //     0xd1b4f4: ldur            w0, [x1, #0xb]
    // 0xd1b4f8: DecompressPointer r0
    //     0xd1b4f8: add             x0, x0, HEAP, lsl #32
    // 0xd1b4fc: cmp             w0, NULL
    // 0xd1b500: b.eq            #0xd1c720
    // 0xd1b504: LoadField: r2 = r0->field_27
    //     0xd1b504: ldur            w2, [x0, #0x27]
    // 0xd1b508: DecompressPointer r2
    //     0xd1b508: add             x2, x2, HEAP, lsl #32
    // 0xd1b50c: cmp             w2, NULL
    // 0xd1b510: b.eq            #0xd1b64c
    // 0xd1b514: ldur            x16, [fp, #-0x10]
    // 0xd1b518: stp             x16, x2, [SP]
    // 0xd1b51c: mov             x0, x2
    // 0xd1b520: ClosureCall
    //     0xd1b520: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xd1b524: ldur            x2, [x0, #0x1f]
    //     0xd1b528: blr             x2
    // 0xd1b52c: mov             x3, x0
    // 0xd1b530: stur            x3, [fp, #-0x20]
    // 0xd1b534: r0 = LoadClassIdInstr(r3)
    //     0xd1b534: ldur            x0, [x3, #-1]
    //     0xd1b538: ubfx            x0, x0, #0xc, #0x14
    // 0xd1b53c: cmp             x0, #0x5c
    // 0xd1b540: b.ne            #0xd1b554
    // 0xd1b544: mov             x2, x3
    // 0xd1b548: r1 = <Widget>
    //     0xd1b548: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xd1b54c: r0 = _GrowableList._ofGrowableList()
    //     0xd1b54c: bl              #0x7d7558  ; [dart:core] _GrowableList::_GrowableList._ofGrowableList
    // 0xd1b550: b               #0xd1b644
    // 0xd1b554: sub             x16, x0, #0x5a
    // 0xd1b558: cmp             x16, #1
    // 0xd1b55c: b.hi            #0xd1b570
    // 0xd1b560: mov             x2, x3
    // 0xd1b564: r1 = <Widget>
    //     0xd1b564: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xd1b568: r0 = _GrowableList._ofArray()
    //     0xd1b568: bl              #0x7d7adc  ; [dart:core] _GrowableList::_GrowableList._ofArray
    // 0xd1b56c: b               #0xd1b644
    // 0xd1b570: mov             x0, x3
    // 0xd1b574: r2 = Null
    //     0xd1b574: mov             x2, NULL
    // 0xd1b578: r1 = Null
    //     0xd1b578: mov             x1, NULL
    // 0xd1b57c: cmp             w0, NULL
    // 0xd1b580: b.eq            #0xd1b618
    // 0xd1b584: branchIfSmi(r0, 0xd1b618)
    //     0xd1b584: tbz             w0, #0, #0xd1b618
    // 0xd1b588: r3 = LoadClassIdInstr(r0)
    //     0xd1b588: ldur            x3, [x0, #-1]
    //     0xd1b58c: ubfx            x3, x3, #0xc, #0x14
    // 0xd1b590: r17 = 7724
    //     0xd1b590: mov             x17, #0x1e2c
    // 0xd1b594: cmp             x3, x17
    // 0xd1b598: b.eq            #0xd1b620
    // 0xd1b59c: r4 = LoadClassIdInstr(r0)
    //     0xd1b59c: ldur            x4, [x0, #-1]
    //     0xd1b5a0: ubfx            x4, x4, #0xc, #0x14
    // 0xd1b5a4: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0xd1b5a8: ldr             x3, [x3, #0x18]
    // 0xd1b5ac: ldr             x3, [x3, x4, lsl #3]
    // 0xd1b5b0: LoadField: r3 = r3->field_2b
    //     0xd1b5b0: ldur            w3, [x3, #0x2b]
    // 0xd1b5b4: DecompressPointer r3
    //     0xd1b5b4: add             x3, x3, HEAP, lsl #32
    // 0xd1b5b8: cmp             w3, NULL
    // 0xd1b5bc: b.eq            #0xd1b618
    // 0xd1b5c0: LoadField: r3 = r3->field_f
    //     0xd1b5c0: ldur            w3, [x3, #0xf]
    // 0xd1b5c4: lsr             x3, x3, #3
    // 0xd1b5c8: r17 = 7724
    //     0xd1b5c8: mov             x17, #0x1e2c
    // 0xd1b5cc: cmp             x3, x17
    // 0xd1b5d0: b.eq            #0xd1b620
    // 0xd1b5d4: r3 = SubtypeTestCache
    //     0xd1b5d4: add             x3, PP, #0x99, lsl #12  ; [pp+0x998f8] SubtypeTestCache
    //     0xd1b5d8: ldr             x3, [x3, #0x8f8]
    // 0xd1b5dc: r30 = Subtype1TestCacheStub
    //     0xd1b5dc: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0xd1b5e0: LoadField: r30 = r30->field_7
    //     0xd1b5e0: ldur            lr, [lr, #7]
    // 0xd1b5e4: blr             lr
    // 0xd1b5e8: cmp             w7, NULL
    // 0xd1b5ec: b.eq            #0xd1b5f8
    // 0xd1b5f0: tbnz            w7, #4, #0xd1b618
    // 0xd1b5f4: b               #0xd1b620
    // 0xd1b5f8: r8 = EfficientLengthIterable
    //     0xd1b5f8: add             x8, PP, #0x99, lsl #12  ; [pp+0x99900] Type: EfficientLengthIterable
    //     0xd1b5fc: ldr             x8, [x8, #0x900]
    // 0xd1b600: r3 = SubtypeTestCache
    //     0xd1b600: add             x3, PP, #0x99, lsl #12  ; [pp+0x99908] SubtypeTestCache
    //     0xd1b604: ldr             x3, [x3, #0x908]
    // 0xd1b608: r30 = InstanceOfStub
    //     0xd1b608: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0xd1b60c: LoadField: r30 = r30->field_7
    //     0xd1b60c: ldur            lr, [lr, #7]
    // 0xd1b610: blr             lr
    // 0xd1b614: b               #0xd1b624
    // 0xd1b618: r0 = false
    //     0xd1b618: add             x0, NULL, #0x30  ; false
    // 0xd1b61c: b               #0xd1b624
    // 0xd1b620: r0 = true
    //     0xd1b620: add             x0, NULL, #0x20  ; true
    // 0xd1b624: tbnz            w0, #4, #0xd1b638
    // 0xd1b628: ldur            x2, [fp, #-0x20]
    // 0xd1b62c: r1 = <Widget>
    //     0xd1b62c: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xd1b630: r0 = _GrowableList._ofEfficientLengthIterable()
    //     0xd1b630: bl              #0x7d732c  ; [dart:core] _GrowableList::_GrowableList._ofEfficientLengthIterable
    // 0xd1b634: b               #0xd1b644
    // 0xd1b638: ldur            x2, [fp, #-0x20]
    // 0xd1b63c: r1 = <Widget>
    //     0xd1b63c: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xd1b640: r0 = _GrowableList._ofOther()
    //     0xd1b640: bl              #0x7d94b4  ; [dart:core] _GrowableList::_GrowableList._ofOther
    // 0xd1b644: mov             x2, x0
    // 0xd1b648: b               #0xd1b660
    // 0xd1b64c: LoadField: r2 = r0->field_f
    //     0xd1b64c: ldur            w2, [x0, #0xf]
    // 0xd1b650: DecompressPointer r2
    //     0xd1b650: add             x2, x2, HEAP, lsl #32
    // 0xd1b654: r1 = <Widget>
    //     0xd1b654: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xd1b658: r0 = _GrowableList._ofGrowableList()
    //     0xd1b658: bl              #0x7d7558  ; [dart:core] _GrowableList::_GrowableList._ofGrowableList
    // 0xd1b65c: mov             x2, x0
    // 0xd1b660: ldur            x0, [fp, #-8]
    // 0xd1b664: stur            x2, [fp, #-0x20]
    // 0xd1b668: LoadField: r1 = r0->field_b
    //     0xd1b668: ldur            w1, [x0, #0xb]
    // 0xd1b66c: DecompressPointer r1
    //     0xd1b66c: add             x1, x1, HEAP, lsl #32
    // 0xd1b670: cmp             w1, NULL
    // 0xd1b674: b.eq            #0xd1c724
    // 0xd1b678: ArrayLoad: r3 = r1[0]  ; List_4
    //     0xd1b678: ldur            w3, [x1, #0x17]
    // 0xd1b67c: DecompressPointer r3
    //     0xd1b67c: add             x3, x3, HEAP, lsl #32
    // 0xd1b680: cmp             w3, NULL
    // 0xd1b684: b.ne            #0xd1b6b8
    // 0xd1b688: mov             x1, x0
    // 0xd1b68c: r0 = _enabled()
    //     0xd1b68c: bl              #0xd1e854  ; [package:flutter/src/material/dropdown.dart] _DropdownButtonState::_enabled
    // 0xd1b690: tbz             w0, #4, #0xd1b8cc
    // 0xd1b694: ldur            x0, [fp, #-8]
    // 0xd1b698: LoadField: r1 = r0->field_b
    //     0xd1b698: ldur            w1, [x0, #0xb]
    // 0xd1b69c: DecompressPointer r1
    //     0xd1b69c: add             x1, x1, HEAP, lsl #32
    // 0xd1b6a0: cmp             w1, NULL
    // 0xd1b6a4: b.eq            #0xd1c728
    // 0xd1b6a8: LoadField: r2 = r1->field_1b
    //     0xd1b6a8: ldur            w2, [x1, #0x1b]
    // 0xd1b6ac: DecompressPointer r2
    //     0xd1b6ac: add             x2, x2, HEAP, lsl #32
    // 0xd1b6b0: cmp             w2, NULL
    // 0xd1b6b4: b.eq            #0xd1b8c4
    // 0xd1b6b8: mov             x1, x0
    // 0xd1b6bc: r0 = _enabled()
    //     0xd1b6bc: bl              #0xd1e854  ; [package:flutter/src/material/dropdown.dart] _DropdownButtonState::_enabled
    // 0xd1b6c0: tbnz            w0, #4, #0xd1b6f0
    // 0xd1b6c4: ldur            x0, [fp, #-8]
    // 0xd1b6c8: LoadField: r1 = r0->field_b
    //     0xd1b6c8: ldur            w1, [x0, #0xb]
    // 0xd1b6cc: DecompressPointer r1
    //     0xd1b6cc: add             x1, x1, HEAP, lsl #32
    // 0xd1b6d0: cmp             w1, NULL
    // 0xd1b6d4: b.eq            #0xd1c72c
    // 0xd1b6d8: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xd1b6d8: ldur            w2, [x1, #0x17]
    // 0xd1b6dc: DecompressPointer r2
    //     0xd1b6dc: add             x2, x2, HEAP, lsl #32
    // 0xd1b6e0: cmp             w2, NULL
    // 0xd1b6e4: b.eq            #0xd1c730
    // 0xd1b6e8: mov             x3, x2
    // 0xd1b6ec: b               #0xd1b734
    // 0xd1b6f0: ldur            x0, [fp, #-8]
    // 0xd1b6f4: LoadField: r1 = r0->field_b
    //     0xd1b6f4: ldur            w1, [x0, #0xb]
    // 0xd1b6f8: DecompressPointer r1
    //     0xd1b6f8: add             x1, x1, HEAP, lsl #32
    // 0xd1b6fc: cmp             w1, NULL
    // 0xd1b700: b.eq            #0xd1c734
    // 0xd1b704: LoadField: r2 = r1->field_1b
    //     0xd1b704: ldur            w2, [x1, #0x1b]
    // 0xd1b708: DecompressPointer r2
    //     0xd1b708: add             x2, x2, HEAP, lsl #32
    // 0xd1b70c: cmp             w2, NULL
    // 0xd1b710: b.ne            #0xd1b72c
    // 0xd1b714: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xd1b714: ldur            w2, [x1, #0x17]
    // 0xd1b718: DecompressPointer r2
    //     0xd1b718: add             x2, x2, HEAP, lsl #32
    // 0xd1b71c: cmp             w2, NULL
    // 0xd1b720: b.eq            #0xd1c738
    // 0xd1b724: mov             x1, x2
    // 0xd1b728: b               #0xd1b730
    // 0xd1b72c: mov             x1, x2
    // 0xd1b730: mov             x3, x1
    // 0xd1b734: ldur            x2, [fp, #-0x20]
    // 0xd1b738: stur            x3, [fp, #-0x30]
    // 0xd1b73c: LoadField: r4 = r2->field_b
    //     0xd1b73c: ldur            w4, [x2, #0xb]
    // 0xd1b740: mov             x1, x0
    // 0xd1b744: stur            x4, [fp, #-0x28]
    // 0xd1b748: r0 = _textStyle()
    //     0xd1b748: bl              #0xd1e7d0  ; [package:flutter/src/material/dropdown.dart] _DropdownButtonState::_textStyle
    // 0xd1b74c: ldur            x1, [fp, #-0x10]
    // 0xd1b750: stur            x0, [fp, #-0x38]
    // 0xd1b754: r0 = of()
    //     0xd1b754: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd1b758: LoadField: r1 = r0->field_53
    //     0xd1b758: ldur            w1, [x0, #0x53]
    // 0xd1b75c: DecompressPointer r1
    //     0xd1b75c: add             x1, x1, HEAP, lsl #32
    // 0xd1b760: str             x1, [SP]
    // 0xd1b764: ldur            x1, [fp, #-0x38]
    // 0xd1b768: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0xd1b768: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0xd1b76c: ldr             x4, [x4, #0x7f0]
    // 0xd1b770: r0 = copyWith()
    //     0xd1b770: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xd1b774: ldur            x1, [fp, #-8]
    // 0xd1b778: stur            x0, [fp, #-0x40]
    // 0xd1b77c: LoadField: r2 = r1->field_b
    //     0xd1b77c: ldur            w2, [x1, #0xb]
    // 0xd1b780: DecompressPointer r2
    //     0xd1b780: add             x2, x2, HEAP, lsl #32
    // 0xd1b784: cmp             w2, NULL
    // 0xd1b788: b.eq            #0xd1c73c
    // 0xd1b78c: LoadField: r3 = r2->field_7b
    //     0xd1b78c: ldur            w3, [x2, #0x7b]
    // 0xd1b790: DecompressPointer r3
    //     0xd1b790: add             x3, x3, HEAP, lsl #32
    // 0xd1b794: stur            x3, [fp, #-0x38]
    // 0xd1b798: r0 = _DropdownMenuItemContainer()
    //     0xd1b798: bl              #0xd1e7c4  ; Allocate_DropdownMenuItemContainerStub -> _DropdownMenuItemContainer (size=0x14)
    // 0xd1b79c: mov             x1, x0
    // 0xd1b7a0: ldur            x0, [fp, #-0x38]
    // 0xd1b7a4: stur            x1, [fp, #-0x48]
    // 0xd1b7a8: StoreField: r1->field_f = r0
    //     0xd1b7a8: stur            w0, [x1, #0xf]
    // 0xd1b7ac: ldur            x0, [fp, #-0x30]
    // 0xd1b7b0: StoreField: r1->field_b = r0
    //     0xd1b7b0: stur            w0, [x1, #0xb]
    // 0xd1b7b4: r0 = IgnorePointer()
    //     0xd1b7b4: bl              #0xbadc08  ; AllocateIgnorePointerStub -> IgnorePointer (size=0x18)
    // 0xd1b7b8: mov             x1, x0
    // 0xd1b7bc: r0 = true
    //     0xd1b7bc: add             x0, NULL, #0x20  ; true
    // 0xd1b7c0: stur            x1, [fp, #-0x30]
    // 0xd1b7c4: StoreField: r1->field_f = r0
    //     0xd1b7c4: stur            w0, [x1, #0xf]
    // 0xd1b7c8: ldur            x2, [fp, #-0x48]
    // 0xd1b7cc: StoreField: r1->field_b = r2
    //     0xd1b7cc: stur            w2, [x1, #0xb]
    // 0xd1b7d0: r0 = DefaultTextStyle()
    //     0xd1b7d0: bl              #0xd0b11c  ; AllocateDefaultTextStyleStub -> DefaultTextStyle (size=0x2c)
    // 0xd1b7d4: mov             x3, x0
    // 0xd1b7d8: ldur            x0, [fp, #-0x40]
    // 0xd1b7dc: stur            x3, [fp, #-0x38]
    // 0xd1b7e0: StoreField: r3->field_f = r0
    //     0xd1b7e0: stur            w0, [x3, #0xf]
    // 0xd1b7e4: r4 = true
    //     0xd1b7e4: add             x4, NULL, #0x20  ; true
    // 0xd1b7e8: ArrayStore: r3[0] = r4  ; List_4
    //     0xd1b7e8: stur            w4, [x3, #0x17]
    // 0xd1b7ec: r5 = Instance_TextOverflow
    //     0xd1b7ec: add             x5, PP, #0x20, lsl #12  ; [pp+0x20108] Obj!TextOverflow@12c47c1
    //     0xd1b7f0: ldr             x5, [x5, #0x108]
    // 0xd1b7f4: StoreField: r3->field_1b = r5
    //     0xd1b7f4: stur            w5, [x3, #0x1b]
    // 0xd1b7f8: r6 = Instance_TextWidthBasis
    //     0xd1b7f8: add             x6, PP, #0x20, lsl #12  ; [pp+0x20110] Obj!TextWidthBasis@12c4781
    //     0xd1b7fc: ldr             x6, [x6, #0x110]
    // 0xd1b800: StoreField: r3->field_23 = r6
    //     0xd1b800: stur            w6, [x3, #0x23]
    // 0xd1b804: ldur            x0, [fp, #-0x30]
    // 0xd1b808: StoreField: r3->field_b = r0
    //     0xd1b808: stur            w0, [x3, #0xb]
    // 0xd1b80c: ldur            x7, [fp, #-0x20]
    // 0xd1b810: LoadField: r2 = r7->field_7
    //     0xd1b810: ldur            w2, [x7, #7]
    // 0xd1b814: DecompressPointer r2
    //     0xd1b814: add             x2, x2, HEAP, lsl #32
    // 0xd1b818: mov             x0, x3
    // 0xd1b81c: r1 = Null
    //     0xd1b81c: mov             x1, NULL
    // 0xd1b820: cmp             w2, NULL
    // 0xd1b824: b.eq            #0xd1b844
    // 0xd1b828: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xd1b828: ldur            w4, [x2, #0x17]
    // 0xd1b82c: DecompressPointer r4
    //     0xd1b82c: add             x4, x4, HEAP, lsl #32
    // 0xd1b830: r8 = X0
    //     0xd1b830: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xd1b834: LoadField: r9 = r4->field_7
    //     0xd1b834: ldur            x9, [x4, #7]
    // 0xd1b838: r3 = Null
    //     0xd1b838: add             x3, PP, #0x99, lsl #12  ; [pp+0x99910] Null
    //     0xd1b83c: ldr             x3, [x3, #0x910]
    // 0xd1b840: blr             x9
    // 0xd1b844: ldur            x0, [fp, #-0x20]
    // 0xd1b848: LoadField: r1 = r0->field_b
    //     0xd1b848: ldur            w1, [x0, #0xb]
    // 0xd1b84c: LoadField: r2 = r0->field_f
    //     0xd1b84c: ldur            w2, [x0, #0xf]
    // 0xd1b850: DecompressPointer r2
    //     0xd1b850: add             x2, x2, HEAP, lsl #32
    // 0xd1b854: LoadField: r3 = r2->field_b
    //     0xd1b854: ldur            w3, [x2, #0xb]
    // 0xd1b858: r2 = LoadInt32Instr(r1)
    //     0xd1b858: sbfx            x2, x1, #1, #0x1f
    // 0xd1b85c: stur            x2, [fp, #-0x50]
    // 0xd1b860: r1 = LoadInt32Instr(r3)
    //     0xd1b860: sbfx            x1, x3, #1, #0x1f
    // 0xd1b864: cmp             x2, x1
    // 0xd1b868: b.ne            #0xd1b874
    // 0xd1b86c: mov             x1, x0
    // 0xd1b870: r0 = _growToNextCapacity()
    //     0xd1b870: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xd1b874: ldur            x2, [fp, #-0x20]
    // 0xd1b878: ldur            x3, [fp, #-0x50]
    // 0xd1b87c: add             x0, x3, #1
    // 0xd1b880: lsl             x1, x0, #1
    // 0xd1b884: StoreField: r2->field_b = r1
    //     0xd1b884: stur            w1, [x2, #0xb]
    // 0xd1b888: LoadField: r1 = r2->field_f
    //     0xd1b888: ldur            w1, [x2, #0xf]
    // 0xd1b88c: DecompressPointer r1
    //     0xd1b88c: add             x1, x1, HEAP, lsl #32
    // 0xd1b890: ldur            x0, [fp, #-0x38]
    // 0xd1b894: ArrayStore: r1[r3] = r0  ; List_4
    //     0xd1b894: add             x25, x1, x3, lsl #2
    //     0xd1b898: add             x25, x25, #0xf
    //     0xd1b89c: str             w0, [x25]
    //     0xd1b8a0: tbz             w0, #0, #0xd1b8bc
    //     0xd1b8a4: ldurb           w16, [x1, #-1]
    //     0xd1b8a8: ldurb           w17, [x0, #-1]
    //     0xd1b8ac: and             x16, x17, x16, lsr #2
    //     0xd1b8b0: tst             x16, HEAP, lsr #32
    //     0xd1b8b4: b.eq            #0xd1b8bc
    //     0xd1b8b8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd1b8bc: ldur            x0, [fp, #-0x28]
    // 0xd1b8c0: b               #0xd1b8d4
    // 0xd1b8c4: ldur            x2, [fp, #-0x20]
    // 0xd1b8c8: b               #0xd1b8d0
    // 0xd1b8cc: ldur            x2, [fp, #-0x20]
    // 0xd1b8d0: r0 = Null
    //     0xd1b8d0: mov             x0, NULL
    // 0xd1b8d4: ldur            x1, [fp, #-0x10]
    // 0xd1b8d8: stur            x0, [fp, #-0x28]
    // 0xd1b8dc: r0 = of()
    //     0xd1b8dc: bl              #0xd1e5a4  ; [package:flutter/src/material/button_theme.dart] ButtonTheme::of
    // 0xd1b8e0: ldur            x0, [fp, #-0x20]
    // 0xd1b8e4: LoadField: r1 = r0->field_b
    //     0xd1b8e4: ldur            w1, [x0, #0xb]
    // 0xd1b8e8: cbnz            w1, #0xd1b904
    // 0xd1b8ec: r4 = Instance_SizedBox
    //     0xd1b8ec: ldr             x4, [PP, #0x4f58]  ; [pp+0x4f58] Obj!SizedBox@12b70e1
    // 0xd1b8f0: r0 = Instance_Clip
    //     0xd1b8f0: add             x0, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xd1b8f4: ldr             x0, [x0, #0x850]
    // 0xd1b8f8: r2 = Instance_StackFit
    //     0xd1b8f8: add             x2, PP, #0x15, lsl #12  ; [pp+0x158e0] Obj!StackFit@12c4221
    //     0xd1b8fc: ldr             x2, [x2, #0x8e0]
    // 0xd1b900: b               #0xd1bac0
    // 0xd1b904: ldur            x3, [fp, #-8]
    // 0xd1b908: LoadField: r1 = r3->field_13
    //     0xd1b908: ldur            w1, [x3, #0x13]
    // 0xd1b90c: DecompressPointer r1
    //     0xd1b90c: add             x1, x1, HEAP, lsl #32
    // 0xd1b910: cmp             w1, NULL
    // 0xd1b914: b.ne            #0xd1b920
    // 0xd1b918: ldur            x4, [fp, #-0x28]
    // 0xd1b91c: b               #0xd1b924
    // 0xd1b920: mov             x4, x1
    // 0xd1b924: stur            x4, [fp, #-0x38]
    // 0xd1b928: LoadField: r1 = r3->field_b
    //     0xd1b928: ldur            w1, [x3, #0xb]
    // 0xd1b92c: DecompressPointer r1
    //     0xd1b92c: add             x1, x1, HEAP, lsl #32
    // 0xd1b930: cmp             w1, NULL
    // 0xd1b934: b.eq            #0xd1c740
    // 0xd1b938: LoadField: r5 = r1->field_7b
    //     0xd1b938: ldur            w5, [x1, #0x7b]
    // 0xd1b93c: DecompressPointer r5
    //     0xd1b93c: add             x5, x5, HEAP, lsl #32
    // 0xd1b940: stur            x5, [fp, #-0x30]
    // 0xd1b944: LoadField: r2 = r1->field_4f
    //     0xd1b944: ldur            w2, [x1, #0x4f]
    // 0xd1b948: DecompressPointer r2
    //     0xd1b948: add             x2, x2, HEAP, lsl #32
    // 0xd1b94c: tbnz            w2, #4, #0xd1b960
    // 0xd1b950: mov             x2, x0
    // 0xd1b954: mov             x0, x4
    // 0xd1b958: mov             x1, x5
    // 0xd1b95c: b               #0xd1ba80
    // 0xd1b960: ldur            x2, [fp, #-0x18]
    // 0xd1b964: r1 = Function '<anonymous closure>':.
    //     0xd1b964: add             x1, PP, #0x99, lsl #12  ; [pp+0x99920] AnonymousClosure: (0xd1f984), in [package:flutter/src/material/dropdown.dart] _DropdownButtonState::build (0xd1b434)
    //     0xd1b968: ldr             x1, [x1, #0x920]
    // 0xd1b96c: r0 = AllocateClosure()
    //     0xd1b96c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd1b970: r16 = <RenderObjectWidget>
    //     0xd1b970: add             x16, PP, #0x99, lsl #12  ; [pp+0x99928] TypeArguments: <RenderObjectWidget>
    //     0xd1b974: ldr             x16, [x16, #0x928]
    // 0xd1b978: ldur            lr, [fp, #-0x20]
    // 0xd1b97c: stp             lr, x16, [SP, #8]
    // 0xd1b980: str             x0, [SP]
    // 0xd1b984: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xd1b984: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xd1b988: r0 = map()
    //     0xd1b988: bl              #0xba574c  ; [dart:collection] ListBase::map
    // 0xd1b98c: mov             x3, x0
    // 0xd1b990: stur            x3, [fp, #-0x40]
    // 0xd1b994: LoadField: r4 = r3->field_7
    //     0xd1b994: ldur            w4, [x3, #7]
    // 0xd1b998: DecompressPointer r4
    //     0xd1b998: add             x4, x4, HEAP, lsl #32
    // 0xd1b99c: mov             x0, x3
    // 0xd1b9a0: stur            x4, [fp, #-0x20]
    // 0xd1b9a4: r2 = Null
    //     0xd1b9a4: mov             x2, NULL
    // 0xd1b9a8: r1 = Null
    //     0xd1b9a8: mov             x1, NULL
    // 0xd1b9ac: cmp             w0, NULL
    // 0xd1b9b0: b.eq            #0xd1ba48
    // 0xd1b9b4: branchIfSmi(r0, 0xd1ba48)
    //     0xd1b9b4: tbz             w0, #0, #0xd1ba48
    // 0xd1b9b8: r3 = LoadClassIdInstr(r0)
    //     0xd1b9b8: ldur            x3, [x0, #-1]
    //     0xd1b9bc: ubfx            x3, x3, #0xc, #0x14
    // 0xd1b9c0: r17 = 7724
    //     0xd1b9c0: mov             x17, #0x1e2c
    // 0xd1b9c4: cmp             x3, x17
    // 0xd1b9c8: b.eq            #0xd1ba50
    // 0xd1b9cc: r4 = LoadClassIdInstr(r0)
    //     0xd1b9cc: ldur            x4, [x0, #-1]
    //     0xd1b9d0: ubfx            x4, x4, #0xc, #0x14
    // 0xd1b9d4: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0xd1b9d8: ldr             x3, [x3, #0x18]
    // 0xd1b9dc: ldr             x3, [x3, x4, lsl #3]
    // 0xd1b9e0: LoadField: r3 = r3->field_2b
    //     0xd1b9e0: ldur            w3, [x3, #0x2b]
    // 0xd1b9e4: DecompressPointer r3
    //     0xd1b9e4: add             x3, x3, HEAP, lsl #32
    // 0xd1b9e8: cmp             w3, NULL
    // 0xd1b9ec: b.eq            #0xd1ba48
    // 0xd1b9f0: LoadField: r3 = r3->field_f
    //     0xd1b9f0: ldur            w3, [x3, #0xf]
    // 0xd1b9f4: lsr             x3, x3, #3
    // 0xd1b9f8: r17 = 7724
    //     0xd1b9f8: mov             x17, #0x1e2c
    // 0xd1b9fc: cmp             x3, x17
    // 0xd1ba00: b.eq            #0xd1ba50
    // 0xd1ba04: r3 = SubtypeTestCache
    //     0xd1ba04: add             x3, PP, #0x99, lsl #12  ; [pp+0x99930] SubtypeTestCache
    //     0xd1ba08: ldr             x3, [x3, #0x930]
    // 0xd1ba0c: r30 = Subtype1TestCacheStub
    //     0xd1ba0c: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0xd1ba10: LoadField: r30 = r30->field_7
    //     0xd1ba10: ldur            lr, [lr, #7]
    // 0xd1ba14: blr             lr
    // 0xd1ba18: cmp             w7, NULL
    // 0xd1ba1c: b.eq            #0xd1ba28
    // 0xd1ba20: tbnz            w7, #4, #0xd1ba48
    // 0xd1ba24: b               #0xd1ba50
    // 0xd1ba28: r8 = EfficientLengthIterable
    //     0xd1ba28: add             x8, PP, #0x99, lsl #12  ; [pp+0x99938] Type: EfficientLengthIterable
    //     0xd1ba2c: ldr             x8, [x8, #0x938]
    // 0xd1ba30: r3 = SubtypeTestCache
    //     0xd1ba30: add             x3, PP, #0x99, lsl #12  ; [pp+0x99940] SubtypeTestCache
    //     0xd1ba34: ldr             x3, [x3, #0x940]
    // 0xd1ba38: r30 = InstanceOfStub
    //     0xd1ba38: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0xd1ba3c: LoadField: r30 = r30->field_7
    //     0xd1ba3c: ldur            lr, [lr, #7]
    // 0xd1ba40: blr             lr
    // 0xd1ba44: b               #0xd1ba54
    // 0xd1ba48: r0 = false
    //     0xd1ba48: add             x0, NULL, #0x30  ; false
    // 0xd1ba4c: b               #0xd1ba54
    // 0xd1ba50: r0 = true
    //     0xd1ba50: add             x0, NULL, #0x20  ; true
    // 0xd1ba54: tbnz            w0, #4, #0xd1ba68
    // 0xd1ba58: ldur            x1, [fp, #-0x20]
    // 0xd1ba5c: ldur            x2, [fp, #-0x40]
    // 0xd1ba60: r0 = _GrowableList._ofEfficientLengthIterable()
    //     0xd1ba60: bl              #0x7d732c  ; [dart:core] _GrowableList::_GrowableList._ofEfficientLengthIterable
    // 0xd1ba64: b               #0xd1ba74
    // 0xd1ba68: ldur            x1, [fp, #-0x20]
    // 0xd1ba6c: ldur            x2, [fp, #-0x40]
    // 0xd1ba70: r0 = _GrowableList._ofOther()
    //     0xd1ba70: bl              #0x7d94b4  ; [dart:core] _GrowableList::_GrowableList._ofOther
    // 0xd1ba74: mov             x2, x0
    // 0xd1ba78: ldur            x0, [fp, #-0x38]
    // 0xd1ba7c: ldur            x1, [fp, #-0x30]
    // 0xd1ba80: stur            x2, [fp, #-0x20]
    // 0xd1ba84: r0 = IndexedStack()
    //     0xd1ba84: bl              #0xd1e598  ; AllocateIndexedStackStub -> IndexedStack (size=0x24)
    // 0xd1ba88: mov             x1, x0
    // 0xd1ba8c: ldur            x0, [fp, #-0x30]
    // 0xd1ba90: StoreField: r1->field_b = r0
    //     0xd1ba90: stur            w0, [x1, #0xb]
    // 0xd1ba94: r0 = Instance_Clip
    //     0xd1ba94: add             x0, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xd1ba98: ldr             x0, [x0, #0x850]
    // 0xd1ba9c: StoreField: r1->field_13 = r0
    //     0xd1ba9c: stur            w0, [x1, #0x13]
    // 0xd1baa0: r2 = Instance_StackFit
    //     0xd1baa0: add             x2, PP, #0x15, lsl #12  ; [pp+0x158e0] Obj!StackFit@12c4221
    //     0xd1baa4: ldr             x2, [x2, #0x8e0]
    // 0xd1baa8: ArrayStore: r1[0] = r2  ; List_4
    //     0xd1baa8: stur            w2, [x1, #0x17]
    // 0xd1baac: ldur            x3, [fp, #-0x38]
    // 0xd1bab0: StoreField: r1->field_1b = r3
    //     0xd1bab0: stur            w3, [x1, #0x1b]
    // 0xd1bab4: ldur            x3, [fp, #-0x20]
    // 0xd1bab8: StoreField: r1->field_1f = r3
    //     0xd1bab8: stur            w3, [x1, #0x1f]
    // 0xd1babc: mov             x4, x1
    // 0xd1bac0: ldur            x3, [fp, #-8]
    // 0xd1bac4: mov             x1, x3
    // 0xd1bac8: stur            x4, [fp, #-0x20]
    // 0xd1bacc: r0 = _iconColor()
    //     0xd1bacc: bl              #0xd1e324  ; [package:flutter/src/material/dropdown.dart] _DropdownButtonState::_iconColor
    // 0xd1bad0: ldur            x1, [fp, #-8]
    // 0xd1bad4: stur            x0, [fp, #-0x38]
    // 0xd1bad8: LoadField: r2 = r1->field_b
    //     0xd1bad8: ldur            w2, [x1, #0xb]
    // 0xd1badc: DecompressPointer r2
    //     0xd1badc: add             x2, x2, HEAP, lsl #32
    // 0xd1bae0: stur            x2, [fp, #-0x30]
    // 0xd1bae4: cmp             w2, NULL
    // 0xd1bae8: b.eq            #0xd1c744
    // 0xd1baec: r0 = IconThemeData()
    //     0xd1baec: bl              #0x8ac78c  ; AllocateIconThemeDataStub -> IconThemeData (size=0x2c)
    // 0xd1baf0: mov             x1, x0
    // 0xd1baf4: r0 = 24.000000
    //     0xd1baf4: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e4d0] 24
    //     0xd1baf8: ldr             x0, [x0, #0x4d0]
    // 0xd1bafc: stur            x1, [fp, #-0x40]
    // 0xd1bb00: StoreField: r1->field_7 = r0
    //     0xd1bb00: stur            w0, [x1, #7]
    // 0xd1bb04: ldur            x0, [fp, #-0x38]
    // 0xd1bb08: StoreField: r1->field_1b = r0
    //     0xd1bb08: stur            w0, [x1, #0x1b]
    // 0xd1bb0c: ldur            x0, [fp, #-0x30]
    // 0xd1bb10: LoadField: r2 = r0->field_3b
    //     0xd1bb10: ldur            w2, [x0, #0x3b]
    // 0xd1bb14: DecompressPointer r2
    //     0xd1bb14: add             x2, x2, HEAP, lsl #32
    // 0xd1bb18: cmp             w2, NULL
    // 0xd1bb1c: b.ne            #0xd1bb44
    // 0xd1bb20: LoadField: r2 = r0->field_8f
    //     0xd1bb20: ldur            w2, [x0, #0x8f]
    // 0xd1bb24: DecompressPointer r2
    //     0xd1bb24: add             x2, x2, HEAP, lsl #32
    // 0xd1bb28: cmp             w2, NULL
    // 0xd1bb2c: b.ne            #0xd1bb38
    // 0xd1bb30: r0 = Null
    //     0xd1bb30: mov             x0, NULL
    // 0xd1bb34: b               #0xd1bb48
    // 0xd1bb38: LoadField: r0 = r2->field_8f
    //     0xd1bb38: ldur            w0, [x2, #0x8f]
    // 0xd1bb3c: DecompressPointer r0
    //     0xd1bb3c: add             x0, x0, HEAP, lsl #32
    // 0xd1bb40: b               #0xd1bb48
    // 0xd1bb44: mov             x0, x2
    // 0xd1bb48: cmp             w0, NULL
    // 0xd1bb4c: b.ne            #0xd1bb58
    // 0xd1bb50: r0 = Instance_Icon
    //     0xd1bb50: add             x0, PP, #0x99, lsl #12  ; [pp+0x99948] Obj!Icon@12b5ce1
    //     0xd1bb54: ldr             x0, [x0, #0x948]
    // 0xd1bb58: stur            x0, [fp, #-0x30]
    // 0xd1bb5c: r0 = IconTheme()
    //     0xd1bb5c: bl              #0xd0c668  ; AllocateIconThemeStub -> IconTheme (size=0x14)
    // 0xd1bb60: mov             x2, x0
    // 0xd1bb64: ldur            x0, [fp, #-0x40]
    // 0xd1bb68: stur            x2, [fp, #-0x38]
    // 0xd1bb6c: StoreField: r2->field_f = r0
    //     0xd1bb6c: stur            w0, [x2, #0xf]
    // 0xd1bb70: ldur            x0, [fp, #-0x30]
    // 0xd1bb74: StoreField: r2->field_b = r0
    //     0xd1bb74: stur            w0, [x2, #0xb]
    // 0xd1bb78: ldur            x1, [fp, #-8]
    // 0xd1bb7c: r0 = _enabled()
    //     0xd1bb7c: bl              #0xd1e854  ; [package:flutter/src/material/dropdown.dart] _DropdownButtonState::_enabled
    // 0xd1bb80: tbnz            w0, #4, #0xd1bb94
    // 0xd1bb84: ldur            x1, [fp, #-8]
    // 0xd1bb88: r0 = _textStyle()
    //     0xd1bb88: bl              #0xd1e7d0  ; [package:flutter/src/material/dropdown.dart] _DropdownButtonState::_textStyle
    // 0xd1bb8c: mov             x2, x0
    // 0xd1bb90: b               #0xd1bbc8
    // 0xd1bb94: ldur            x1, [fp, #-8]
    // 0xd1bb98: r0 = _textStyle()
    //     0xd1bb98: bl              #0xd1e7d0  ; [package:flutter/src/material/dropdown.dart] _DropdownButtonState::_textStyle
    // 0xd1bb9c: ldur            x1, [fp, #-0x10]
    // 0xd1bba0: stur            x0, [fp, #-0x30]
    // 0xd1bba4: r0 = of()
    //     0xd1bba4: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd1bba8: LoadField: r1 = r0->field_43
    //     0xd1bba8: ldur            w1, [x0, #0x43]
    // 0xd1bbac: DecompressPointer r1
    //     0xd1bbac: add             x1, x1, HEAP, lsl #32
    // 0xd1bbb0: str             x1, [SP]
    // 0xd1bbb4: ldur            x1, [fp, #-0x30]
    // 0xd1bbb8: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0xd1bbb8: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0xd1bbbc: ldr             x4, [x4, #0x7f0]
    // 0xd1bbc0: r0 = copyWith()
    //     0xd1bbc0: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xd1bbc4: mov             x2, x0
    // 0xd1bbc8: ldur            x0, [fp, #-8]
    // 0xd1bbcc: stur            x2, [fp, #-0x30]
    // 0xd1bbd0: LoadField: r1 = r0->field_b
    //     0xd1bbd0: ldur            w1, [x0, #0xb]
    // 0xd1bbd4: DecompressPointer r1
    //     0xd1bbd4: add             x1, x1, HEAP, lsl #32
    // 0xd1bbd8: cmp             w1, NULL
    // 0xd1bbdc: b.eq            #0xd1c748
    // 0xd1bbe0: LoadField: r3 = r1->field_4f
    //     0xd1bbe0: ldur            w3, [x1, #0x4f]
    // 0xd1bbe4: DecompressPointer r3
    //     0xd1bbe4: add             x3, x3, HEAP, lsl #32
    // 0xd1bbe8: tbnz            w3, #4, #0xd1bc28
    // 0xd1bbec: mov             x1, x0
    // 0xd1bbf0: r0 = _denseButtonHeight()
    //     0xd1bbf0: bl              #0xd1e19c  ; [package:flutter/src/material/dropdown.dart] _DropdownButtonState::_denseButtonHeight
    // 0xd1bbf4: r0 = inline_Allocate_Double()
    //     0xd1bbf4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xd1bbf8: add             x0, x0, #0x10
    //     0xd1bbfc: cmp             x1, x0
    //     0xd1bc00: b.ls            #0xd1c74c
    //     0xd1bc04: str             x0, [THR, #0x60]  ; THR::top
    //     0xd1bc08: sub             x0, x0, #0xf
    //     0xd1bc0c: mov             x1, #0xe19c
    //     0xd1bc10: movk            x1, #3, lsl #16
    //     0xd1bc14: stur            x1, [x0, #-1]
    // 0xd1bc18: dmb             ishst
    // 0xd1bc1c: StoreField: r0->field_7 = d0
    //     0xd1bc1c: stur            d0, [x0, #7]
    // 0xd1bc20: mov             x2, x0
    // 0xd1bc24: b               #0xd1bc2c
    // 0xd1bc28: r2 = Null
    //     0xd1bc28: mov             x2, NULL
    // 0xd1bc2c: ldur            x0, [fp, #-8]
    // 0xd1bc30: ldur            x1, [fp, #-0x10]
    // 0xd1bc34: stur            x2, [fp, #-0x40]
    // 0xd1bc38: r0 = of()
    //     0xd1bc38: bl              #0x87371c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0xd1bc3c: r1 = <Widget>
    //     0xd1bc3c: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xd1bc40: r2 = 0
    //     0xd1bc40: mov             x2, #0
    // 0xd1bc44: r0 = _GrowableList()
    //     0xd1bc44: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xd1bc48: mov             x2, x0
    // 0xd1bc4c: ldur            x0, [fp, #-8]
    // 0xd1bc50: stur            x2, [fp, #-0x48]
    // 0xd1bc54: LoadField: r1 = r0->field_b
    //     0xd1bc54: ldur            w1, [x0, #0xb]
    // 0xd1bc58: DecompressPointer r1
    //     0xd1bc58: add             x1, x1, HEAP, lsl #32
    // 0xd1bc5c: cmp             w1, NULL
    // 0xd1bc60: b.eq            #0xd1c75c
    // 0xd1bc64: LoadField: r3 = r1->field_53
    //     0xd1bc64: ldur            w3, [x1, #0x53]
    // 0xd1bc68: DecompressPointer r3
    //     0xd1bc68: add             x3, x3, HEAP, lsl #32
    // 0xd1bc6c: tbnz            w3, #4, #0xd1bd2c
    // 0xd1bc70: ldur            x3, [fp, #-0x20]
    // 0xd1bc74: r1 = <FlexParentData>
    //     0xd1bc74: add             x1, PP, #0x15, lsl #12  ; [pp+0x15878] TypeArguments: <FlexParentData>
    //     0xd1bc78: ldr             x1, [x1, #0x878]
    // 0xd1bc7c: r0 = Expanded()
    //     0xd1bc7c: bl              #0x8a5b10  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0xd1bc80: mov             x2, x0
    // 0xd1bc84: r0 = 1
    //     0xd1bc84: mov             x0, #1
    // 0xd1bc88: stur            x2, [fp, #-0x58]
    // 0xd1bc8c: StoreField: r2->field_13 = r0
    //     0xd1bc8c: stur            x0, [x2, #0x13]
    // 0xd1bc90: r0 = Instance_FlexFit
    //     0xd1bc90: add             x0, PP, #0x15, lsl #12  ; [pp+0x15880] Obj!FlexFit@12c4641
    //     0xd1bc94: ldr             x0, [x0, #0x880]
    // 0xd1bc98: StoreField: r2->field_1b = r0
    //     0xd1bc98: stur            w0, [x2, #0x1b]
    // 0xd1bc9c: ldur            x0, [fp, #-0x20]
    // 0xd1bca0: StoreField: r2->field_b = r0
    //     0xd1bca0: stur            w0, [x2, #0xb]
    // 0xd1bca4: ldur            x0, [fp, #-0x48]
    // 0xd1bca8: LoadField: r1 = r0->field_b
    //     0xd1bca8: ldur            w1, [x0, #0xb]
    // 0xd1bcac: LoadField: r3 = r0->field_f
    //     0xd1bcac: ldur            w3, [x0, #0xf]
    // 0xd1bcb0: DecompressPointer r3
    //     0xd1bcb0: add             x3, x3, HEAP, lsl #32
    // 0xd1bcb4: LoadField: r4 = r3->field_b
    //     0xd1bcb4: ldur            w4, [x3, #0xb]
    // 0xd1bcb8: r3 = LoadInt32Instr(r1)
    //     0xd1bcb8: sbfx            x3, x1, #1, #0x1f
    // 0xd1bcbc: stur            x3, [fp, #-0x50]
    // 0xd1bcc0: r1 = LoadInt32Instr(r4)
    //     0xd1bcc0: sbfx            x1, x4, #1, #0x1f
    // 0xd1bcc4: cmp             x3, x1
    // 0xd1bcc8: b.ne            #0xd1bcd4
    // 0xd1bccc: mov             x1, x0
    // 0xd1bcd0: r0 = _growToNextCapacity()
    //     0xd1bcd0: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xd1bcd4: ldur            x2, [fp, #-0x48]
    // 0xd1bcd8: ldur            x3, [fp, #-0x50]
    // 0xd1bcdc: add             x4, x3, #1
    // 0xd1bce0: lsl             x0, x4, #1
    // 0xd1bce4: StoreField: r2->field_b = r0
    //     0xd1bce4: stur            w0, [x2, #0xb]
    // 0xd1bce8: LoadField: r5 = r2->field_f
    //     0xd1bce8: ldur            w5, [x2, #0xf]
    // 0xd1bcec: DecompressPointer r5
    //     0xd1bcec: add             x5, x5, HEAP, lsl #32
    // 0xd1bcf0: mov             x1, x5
    // 0xd1bcf4: ldur            x0, [fp, #-0x58]
    // 0xd1bcf8: ArrayStore: r1[r3] = r0  ; List_4
    //     0xd1bcf8: add             x25, x1, x3, lsl #2
    //     0xd1bcfc: add             x25, x25, #0xf
    //     0xd1bd00: str             w0, [x25]
    //     0xd1bd04: tbz             w0, #0, #0xd1bd20
    //     0xd1bd08: ldurb           w16, [x1, #-1]
    //     0xd1bd0c: ldurb           w17, [x0, #-1]
    //     0xd1bd10: and             x16, x17, x16, lsr #2
    //     0xd1bd14: tst             x16, HEAP, lsr #32
    //     0xd1bd18: b.eq            #0xd1bd20
    //     0xd1bd1c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd1bd20: mov             x3, x4
    // 0xd1bd24: mov             x1, x5
    // 0xd1bd28: b               #0xd1bdb0
    // 0xd1bd2c: ldur            x0, [fp, #-0x20]
    // 0xd1bd30: LoadField: r1 = r2->field_b
    //     0xd1bd30: ldur            w1, [x2, #0xb]
    // 0xd1bd34: LoadField: r3 = r2->field_f
    //     0xd1bd34: ldur            w3, [x2, #0xf]
    // 0xd1bd38: DecompressPointer r3
    //     0xd1bd38: add             x3, x3, HEAP, lsl #32
    // 0xd1bd3c: LoadField: r4 = r3->field_b
    //     0xd1bd3c: ldur            w4, [x3, #0xb]
    // 0xd1bd40: r3 = LoadInt32Instr(r1)
    //     0xd1bd40: sbfx            x3, x1, #1, #0x1f
    // 0xd1bd44: stur            x3, [fp, #-0x50]
    // 0xd1bd48: r1 = LoadInt32Instr(r4)
    //     0xd1bd48: sbfx            x1, x4, #1, #0x1f
    // 0xd1bd4c: cmp             x3, x1
    // 0xd1bd50: b.ne            #0xd1bd5c
    // 0xd1bd54: mov             x1, x2
    // 0xd1bd58: r0 = _growToNextCapacity()
    //     0xd1bd58: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xd1bd5c: ldur            x2, [fp, #-0x48]
    // 0xd1bd60: ldur            x3, [fp, #-0x50]
    // 0xd1bd64: add             x4, x3, #1
    // 0xd1bd68: lsl             x0, x4, #1
    // 0xd1bd6c: StoreField: r2->field_b = r0
    //     0xd1bd6c: stur            w0, [x2, #0xb]
    // 0xd1bd70: LoadField: r5 = r2->field_f
    //     0xd1bd70: ldur            w5, [x2, #0xf]
    // 0xd1bd74: DecompressPointer r5
    //     0xd1bd74: add             x5, x5, HEAP, lsl #32
    // 0xd1bd78: mov             x1, x5
    // 0xd1bd7c: ldur            x0, [fp, #-0x20]
    // 0xd1bd80: ArrayStore: r1[r3] = r0  ; List_4
    //     0xd1bd80: add             x25, x1, x3, lsl #2
    //     0xd1bd84: add             x25, x25, #0xf
    //     0xd1bd88: str             w0, [x25]
    //     0xd1bd8c: tbz             w0, #0, #0xd1bda8
    //     0xd1bd90: ldurb           w16, [x1, #-1]
    //     0xd1bd94: ldurb           w17, [x0, #-1]
    //     0xd1bd98: and             x16, x17, x16, lsr #2
    //     0xd1bd9c: tst             x16, HEAP, lsr #32
    //     0xd1bda0: b.eq            #0xd1bda8
    //     0xd1bda4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd1bda8: mov             x3, x4
    // 0xd1bdac: mov             x1, x5
    // 0xd1bdb0: ldur            x0, [fp, #-8]
    // 0xd1bdb4: stur            x3, [fp, #-0x50]
    // 0xd1bdb8: LoadField: r4 = r0->field_b
    //     0xd1bdb8: ldur            w4, [x0, #0xb]
    // 0xd1bdbc: DecompressPointer r4
    //     0xd1bdbc: add             x4, x4, HEAP, lsl #32
    // 0xd1bdc0: cmp             w4, NULL
    // 0xd1bdc4: b.eq            #0xd1c760
    // 0xd1bdc8: LoadField: r5 = r4->field_8f
    //     0xd1bdc8: ldur            w5, [x4, #0x8f]
    // 0xd1bdcc: DecompressPointer r5
    //     0xd1bdcc: add             x5, x5, HEAP, lsl #32
    // 0xd1bdd0: cmp             w5, NULL
    // 0xd1bdd4: b.ne            #0xd1be44
    // 0xd1bdd8: LoadField: r4 = r1->field_b
    //     0xd1bdd8: ldur            w4, [x1, #0xb]
    // 0xd1bddc: r1 = LoadInt32Instr(r4)
    //     0xd1bddc: sbfx            x1, x4, #1, #0x1f
    // 0xd1bde0: cmp             x3, x1
    // 0xd1bde4: b.ne            #0xd1bdf0
    // 0xd1bde8: mov             x1, x2
    // 0xd1bdec: r0 = _growToNextCapacity()
    //     0xd1bdec: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xd1bdf0: ldur            x2, [fp, #-0x48]
    // 0xd1bdf4: ldur            x3, [fp, #-0x50]
    // 0xd1bdf8: add             x0, x3, #1
    // 0xd1bdfc: lsl             x1, x0, #1
    // 0xd1be00: StoreField: r2->field_b = r1
    //     0xd1be00: stur            w1, [x2, #0xb]
    // 0xd1be04: mov             x1, x3
    // 0xd1be08: cmp             x1, x0
    // 0xd1be0c: b.hs            #0xd1c764
    // 0xd1be10: LoadField: r1 = r2->field_f
    //     0xd1be10: ldur            w1, [x2, #0xf]
    // 0xd1be14: DecompressPointer r1
    //     0xd1be14: add             x1, x1, HEAP, lsl #32
    // 0xd1be18: ldur            x0, [fp, #-0x38]
    // 0xd1be1c: ArrayStore: r1[r3] = r0  ; List_4
    //     0xd1be1c: add             x25, x1, x3, lsl #2
    //     0xd1be20: add             x25, x25, #0xf
    //     0xd1be24: str             w0, [x25]
    //     0xd1be28: tbz             w0, #0, #0xd1be44
    //     0xd1be2c: ldurb           w16, [x1, #-1]
    //     0xd1be30: ldurb           w17, [x0, #-1]
    //     0xd1be34: and             x16, x17, x16, lsr #2
    //     0xd1be38: tst             x16, HEAP, lsr #32
    //     0xd1be3c: b.eq            #0xd1be44
    //     0xd1be40: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd1be44: ldur            x1, [fp, #-0x30]
    // 0xd1be48: ldur            x0, [fp, #-0x40]
    // 0xd1be4c: r0 = Row()
    //     0xd1be4c: bl              #0x8a5b04  ; AllocateRowStub -> Row (size=0x38)
    // 0xd1be50: mov             x1, x0
    // 0xd1be54: r0 = Instance_Axis
    //     0xd1be54: ldr             x0, [PP, #0x49c8]  ; [pp+0x49c8] Obj!Axis@12c4a61
    // 0xd1be58: stur            x1, [fp, #-0x20]
    // 0xd1be5c: StoreField: r1->field_f = r0
    //     0xd1be5c: stur            w0, [x1, #0xf]
    // 0xd1be60: r0 = Instance_MainAxisAlignment
    //     0xd1be60: add             x0, PP, #0x17, lsl #12  ; [pp+0x177b0] Obj!MainAxisAlignment@12c45c1
    //     0xd1be64: ldr             x0, [x0, #0x7b0]
    // 0xd1be68: StoreField: r1->field_13 = r0
    //     0xd1be68: stur            w0, [x1, #0x13]
    // 0xd1be6c: r0 = Instance_MainAxisSize
    //     0xd1be6c: add             x0, PP, #0x17, lsl #12  ; [pp+0x17200] Obj!MainAxisSize@12c4601
    //     0xd1be70: ldr             x0, [x0, #0x200]
    // 0xd1be74: ArrayStore: r1[0] = r0  ; List_4
    //     0xd1be74: stur            w0, [x1, #0x17]
    // 0xd1be78: r0 = Instance_CrossAxisAlignment
    //     0xd1be78: add             x0, PP, #0x15, lsl #12  ; [pp+0x15888] Obj!CrossAxisAlignment@12c44a1
    //     0xd1be7c: ldr             x0, [x0, #0x888]
    // 0xd1be80: StoreField: r1->field_1b = r0
    //     0xd1be80: stur            w0, [x1, #0x1b]
    // 0xd1be84: r0 = Instance_VerticalDirection
    //     0xd1be84: add             x0, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xd1be88: ldr             x0, [x0, #0x838]
    // 0xd1be8c: StoreField: r1->field_23 = r0
    //     0xd1be8c: stur            w0, [x1, #0x23]
    // 0xd1be90: r0 = Instance_Clip
    //     0xd1be90: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xd1be94: ldr             x0, [x0, #0x840]
    // 0xd1be98: StoreField: r1->field_2b = r0
    //     0xd1be98: stur            w0, [x1, #0x2b]
    // 0xd1be9c: StoreField: r1->field_2f = rZR
    //     0xd1be9c: stur            xzr, [x1, #0x2f]
    // 0xd1bea0: ldur            x0, [fp, #-0x48]
    // 0xd1bea4: StoreField: r1->field_b = r0
    //     0xd1bea4: stur            w0, [x1, #0xb]
    // 0xd1bea8: r0 = Padding()
    //     0xd1bea8: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xd1beac: mov             x1, x0
    // 0xd1beb0: r0 = Instance_EdgeInsets
    //     0xd1beb0: ldr             x0, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0xd1beb4: stur            x1, [fp, #-0x48]
    // 0xd1beb8: StoreField: r1->field_f = r0
    //     0xd1beb8: stur            w0, [x1, #0xf]
    // 0xd1bebc: ldur            x0, [fp, #-0x20]
    // 0xd1bec0: StoreField: r1->field_b = r0
    //     0xd1bec0: stur            w0, [x1, #0xb]
    // 0xd1bec4: r0 = SizedBox()
    //     0xd1bec4: bl              #0x8a7210  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0xd1bec8: mov             x1, x0
    // 0xd1becc: ldur            x0, [fp, #-0x40]
    // 0xd1bed0: stur            x1, [fp, #-0x20]
    // 0xd1bed4: StoreField: r1->field_13 = r0
    //     0xd1bed4: stur            w0, [x1, #0x13]
    // 0xd1bed8: ldur            x0, [fp, #-0x48]
    // 0xd1bedc: StoreField: r1->field_b = r0
    //     0xd1bedc: stur            w0, [x1, #0xb]
    // 0xd1bee0: r0 = DefaultTextStyle()
    //     0xd1bee0: bl              #0xd0b11c  ; AllocateDefaultTextStyleStub -> DefaultTextStyle (size=0x2c)
    // 0xd1bee4: mov             x2, x0
    // 0xd1bee8: ldur            x0, [fp, #-0x30]
    // 0xd1beec: stur            x2, [fp, #-0x40]
    // 0xd1bef0: StoreField: r2->field_f = r0
    //     0xd1bef0: stur            w0, [x2, #0xf]
    // 0xd1bef4: r0 = true
    //     0xd1bef4: add             x0, NULL, #0x20  ; true
    // 0xd1bef8: ArrayStore: r2[0] = r0  ; List_4
    //     0xd1bef8: stur            w0, [x2, #0x17]
    // 0xd1befc: r1 = Instance_TextOverflow
    //     0xd1befc: add             x1, PP, #0x20, lsl #12  ; [pp+0x20108] Obj!TextOverflow@12c47c1
    //     0xd1bf00: ldr             x1, [x1, #0x108]
    // 0xd1bf04: StoreField: r2->field_1b = r1
    //     0xd1bf04: stur            w1, [x2, #0x1b]
    // 0xd1bf08: r1 = Instance_TextWidthBasis
    //     0xd1bf08: add             x1, PP, #0x20, lsl #12  ; [pp+0x20110] Obj!TextWidthBasis@12c4781
    //     0xd1bf0c: ldr             x1, [x1, #0x110]
    // 0xd1bf10: StoreField: r2->field_23 = r1
    //     0xd1bf10: stur            w1, [x2, #0x23]
    // 0xd1bf14: ldur            x1, [fp, #-0x20]
    // 0xd1bf18: StoreField: r2->field_b = r1
    //     0xd1bf18: stur            w1, [x2, #0xb]
    // 0xd1bf1c: ldur            x1, [fp, #-0x10]
    // 0xd1bf20: r0 = at()
    //     0xd1bf20: bl              #0xd1e148  ; [package:flutter/src/material/dropdown.dart] DropdownButtonHideUnderline::at
    // 0xd1bf24: tbz             w0, #4, #0xd1c08c
    // 0xd1bf28: ldur            x1, [fp, #-8]
    // 0xd1bf2c: LoadField: r0 = r1->field_b
    //     0xd1bf2c: ldur            w0, [x1, #0xb]
    // 0xd1bf30: DecompressPointer r0
    //     0xd1bf30: add             x0, x0, HEAP, lsl #32
    // 0xd1bf34: cmp             w0, NULL
    // 0xd1bf38: b.eq            #0xd1c768
    // 0xd1bf3c: LoadField: r2 = r0->field_4f
    //     0xd1bf3c: ldur            w2, [x0, #0x4f]
    // 0xd1bf40: DecompressPointer r2
    //     0xd1bf40: add             x2, x2, HEAP, lsl #32
    // 0xd1bf44: tbz             w2, #4, #0xd1bf58
    // 0xd1bf48: LoadField: r2 = r0->field_57
    //     0xd1bf48: ldur            w2, [x0, #0x57]
    // 0xd1bf4c: DecompressPointer r2
    //     0xd1bf4c: add             x2, x2, HEAP, lsl #32
    // 0xd1bf50: cmp             w2, NULL
    // 0xd1bf54: b.ne            #0xd1bf60
    // 0xd1bf58: d0 = 0.000000
    //     0xd1bf58: eor             v0.16b, v0.16b, v0.16b
    // 0xd1bf5c: b               #0xd1bf64
    // 0xd1bf60: d0 = 8.000000
    //     0xd1bf60: fmov            d0, #8.00000000
    // 0xd1bf64: stur            d0, [fp, #-0x80]
    // 0xd1bf68: LoadField: r2 = r0->field_37
    //     0xd1bf68: ldur            w2, [x0, #0x37]
    // 0xd1bf6c: DecompressPointer r2
    //     0xd1bf6c: add             x2, x2, HEAP, lsl #32
    // 0xd1bf70: cmp             w2, NULL
    // 0xd1bf74: b.ne            #0xd1bfa4
    // 0xd1bf78: r0 = Container()
    //     0xd1bf78: bl              #0x8a5af8  ; AllocateContainerStub -> Container (size=0x38)
    // 0xd1bf7c: stur            x0, [fp, #-0x20]
    // 0xd1bf80: r16 = 1.000000
    //     0xd1bf80: ldr             x16, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xd1bf84: r30 = Instance_BoxDecoration
    //     0xd1bf84: add             lr, PP, #0x99, lsl #12  ; [pp+0x99950] Obj!BoxDecoration@12b3431
    //     0xd1bf88: ldr             lr, [lr, #0x950]
    // 0xd1bf8c: stp             lr, x16, [SP]
    // 0xd1bf90: mov             x1, x0
    // 0xd1bf94: r4 = const [0, 0x3, 0x2, 0x1, decoration, 0x2, height, 0x1, null]
    //     0xd1bf94: add             x4, PP, #0x1e, lsl #12  ; [pp+0x1e740] List(9) [0, 0x3, 0x2, 0x1, "decoration", 0x2, "height", 0x1, Null]
    //     0xd1bf98: ldr             x4, [x4, #0x740]
    // 0xd1bf9c: r0 = Container()
    //     0xd1bf9c: bl              #0x8a54e0  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0xd1bfa0: ldur            x2, [fp, #-0x20]
    // 0xd1bfa4: ldur            x0, [fp, #-0x40]
    // 0xd1bfa8: ldur            d0, [fp, #-0x80]
    // 0xd1bfac: stur            x2, [fp, #-0x20]
    // 0xd1bfb0: r1 = <StackParentData>
    //     0xd1bfb0: add             x1, PP, #0x15, lsl #12  ; [pp+0x15858] TypeArguments: <StackParentData>
    //     0xd1bfb4: ldr             x1, [x1, #0x858]
    // 0xd1bfb8: r0 = Positioned()
    //     0xd1bfb8: bl              #0x8a54a4  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0xd1bfbc: mov             x3, x0
    // 0xd1bfc0: r0 = 0.000000
    //     0xd1bfc0: ldr             x0, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xd1bfc4: stur            x3, [fp, #-0x30]
    // 0xd1bfc8: StoreField: r3->field_13 = r0
    //     0xd1bfc8: stur            w0, [x3, #0x13]
    // 0xd1bfcc: StoreField: r3->field_1b = r0
    //     0xd1bfcc: stur            w0, [x3, #0x1b]
    // 0xd1bfd0: ldur            d0, [fp, #-0x80]
    // 0xd1bfd4: r0 = inline_Allocate_Double()
    //     0xd1bfd4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xd1bfd8: add             x0, x0, #0x10
    //     0xd1bfdc: cmp             x1, x0
    //     0xd1bfe0: b.ls            #0xd1c76c
    //     0xd1bfe4: str             x0, [THR, #0x60]  ; THR::top
    //     0xd1bfe8: sub             x0, x0, #0xf
    //     0xd1bfec: mov             x1, #0xe19c
    //     0xd1bff0: movk            x1, #3, lsl #16
    //     0xd1bff4: stur            x1, [x0, #-1]
    // 0xd1bff8: dmb             ishst
    // 0xd1bffc: StoreField: r0->field_7 = d0
    //     0xd1bffc: stur            d0, [x0, #7]
    // 0xd1c000: StoreField: r3->field_1f = r0
    //     0xd1c000: stur            w0, [x3, #0x1f]
    // 0xd1c004: ldur            x0, [fp, #-0x20]
    // 0xd1c008: StoreField: r3->field_b = r0
    //     0xd1c008: stur            w0, [x3, #0xb]
    // 0xd1c00c: r1 = Null
    //     0xd1c00c: mov             x1, NULL
    // 0xd1c010: r2 = 4
    //     0xd1c010: mov             x2, #4
    // 0xd1c014: r0 = AllocateArray()
    //     0xd1c014: bl              #0x13df928  ; AllocateArrayStub
    // 0xd1c018: mov             x2, x0
    // 0xd1c01c: ldur            x0, [fp, #-0x40]
    // 0xd1c020: stur            x2, [fp, #-0x20]
    // 0xd1c024: StoreField: r2->field_f = r0
    //     0xd1c024: stur            w0, [x2, #0xf]
    // 0xd1c028: ldur            x0, [fp, #-0x30]
    // 0xd1c02c: StoreField: r2->field_13 = r0
    //     0xd1c02c: stur            w0, [x2, #0x13]
    // 0xd1c030: r1 = <Widget>
    //     0xd1c030: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xd1c034: r0 = AllocateGrowableArray()
    //     0xd1c034: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xd1c038: mov             x1, x0
    // 0xd1c03c: ldur            x0, [fp, #-0x20]
    // 0xd1c040: stur            x1, [fp, #-0x30]
    // 0xd1c044: StoreField: r1->field_f = r0
    //     0xd1c044: stur            w0, [x1, #0xf]
    // 0xd1c048: r0 = 4
    //     0xd1c048: mov             x0, #4
    // 0xd1c04c: StoreField: r1->field_b = r0
    //     0xd1c04c: stur            w0, [x1, #0xb]
    // 0xd1c050: r0 = Stack()
    //     0xd1c050: bl              #0xd1a854  ; AllocateStackStub -> Stack (size=0x20)
    // 0xd1c054: mov             x1, x0
    // 0xd1c058: r0 = Instance_AlignmentDirectional
    //     0xd1c058: add             x0, PP, #0x15, lsl #12  ; [pp+0x158d8] Obj!AlignmentDirectional@129e611
    //     0xd1c05c: ldr             x0, [x0, #0x8d8]
    // 0xd1c060: StoreField: r1->field_f = r0
    //     0xd1c060: stur            w0, [x1, #0xf]
    // 0xd1c064: r0 = Instance_StackFit
    //     0xd1c064: add             x0, PP, #0x15, lsl #12  ; [pp+0x158e0] Obj!StackFit@12c4221
    //     0xd1c068: ldr             x0, [x0, #0x8e0]
    // 0xd1c06c: ArrayStore: r1[0] = r0  ; List_4
    //     0xd1c06c: stur            w0, [x1, #0x17]
    // 0xd1c070: r0 = Instance_Clip
    //     0xd1c070: add             x0, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xd1c074: ldr             x0, [x0, #0x850]
    // 0xd1c078: StoreField: r1->field_1b = r0
    //     0xd1c078: stur            w0, [x1, #0x1b]
    // 0xd1c07c: ldur            x0, [fp, #-0x30]
    // 0xd1c080: StoreField: r1->field_b = r0
    //     0xd1c080: stur            w0, [x1, #0xb]
    // 0xd1c084: mov             x2, x1
    // 0xd1c088: b               #0xd1c094
    // 0xd1c08c: ldur            x0, [fp, #-0x40]
    // 0xd1c090: mov             x2, x0
    // 0xd1c094: ldur            x0, [fp, #-8]
    // 0xd1c098: stur            x2, [fp, #-0x20]
    // 0xd1c09c: LoadField: r1 = r0->field_b
    //     0xd1c09c: ldur            w1, [x0, #0xb]
    // 0xd1c0a0: DecompressPointer r1
    //     0xd1c0a0: add             x1, x1, HEAP, lsl #32
    // 0xd1c0a4: cmp             w1, NULL
    // 0xd1c0a8: b.eq            #0xd1c784
    // 0xd1c0ac: r1 = <WidgetState>
    //     0xd1c0ac: add             x1, PP, #0x84, lsl #12  ; [pp+0x84a10] TypeArguments: <WidgetState>
    //     0xd1c0b0: ldr             x1, [x1, #0xa10]
    // 0xd1c0b4: r0 = _Set()
    //     0xd1c0b4: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0xd1c0b8: mov             x2, x0
    // 0xd1c0bc: r0 = _Uint32List
    //     0xd1c0bc: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0xd1c0c0: stur            x2, [fp, #-0x30]
    // 0xd1c0c4: StoreField: r2->field_1b = r0
    //     0xd1c0c4: stur            w0, [x2, #0x1b]
    // 0xd1c0c8: StoreField: r2->field_b = rZR
    //     0xd1c0c8: stur            wzr, [x2, #0xb]
    // 0xd1c0cc: r0 = const []
    //     0xd1c0cc: ldr             x0, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0xd1c0d0: StoreField: r2->field_f = r0
    //     0xd1c0d0: stur            w0, [x2, #0xf]
    // 0xd1c0d4: StoreField: r2->field_13 = rZR
    //     0xd1c0d4: stur            wzr, [x2, #0x13]
    // 0xd1c0d8: ArrayStore: r2[0] = rZR  ; List_4
    //     0xd1c0d8: stur            wzr, [x2, #0x17]
    // 0xd1c0dc: ldur            x1, [fp, #-8]
    // 0xd1c0e0: r0 = _enabled()
    //     0xd1c0e0: bl              #0xd1e854  ; [package:flutter/src/material/dropdown.dart] _DropdownButtonState::_enabled
    // 0xd1c0e4: tbz             w0, #4, #0xd1c0f8
    // 0xd1c0e8: ldur            x1, [fp, #-0x30]
    // 0xd1c0ec: r2 = Instance_WidgetState
    //     0xd1c0ec: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xd1c0f0: ldr             x2, [x2, #0xa70]
    // 0xd1c0f4: r0 = add()
    //     0xd1c0f4: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xd1c0f8: ldur            x1, [fp, #-8]
    // 0xd1c0fc: r16 = <MouseCursor>
    //     0xd1c0fc: ldr             x16, [PP, #0x21a8]  ; [pp+0x21a8] TypeArguments: <MouseCursor>
    // 0xd1c100: r30 = Instance__WidgetStateMouseCursor
    //     0xd1c100: add             lr, PP, #0x80, lsl #12  ; [pp+0x80c18] Obj!_WidgetStateMouseCursor@12b3251
    //     0xd1c104: ldr             lr, [lr, #0xc18]
    // 0xd1c108: stp             lr, x16, [SP, #8]
    // 0xd1c10c: ldur            x16, [fp, #-0x30]
    // 0xd1c110: str             x16, [SP]
    // 0xd1c114: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xd1c114: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xd1c118: r0 = resolveAs()
    //     0xd1c118: bl              #0x8de57c  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveAs
    // 0xd1c11c: mov             x2, x0
    // 0xd1c120: ldur            x0, [fp, #-8]
    // 0xd1c124: stur            x2, [fp, #-0x30]
    // 0xd1c128: LoadField: r1 = r0->field_b
    //     0xd1c128: ldur            w1, [x0, #0xb]
    // 0xd1c12c: DecompressPointer r1
    //     0xd1c12c: add             x1, x1, HEAP, lsl #32
    // 0xd1c130: cmp             w1, NULL
    // 0xd1c134: b.eq            #0xd1c788
    // 0xd1c138: LoadField: r3 = r1->field_8f
    //     0xd1c138: ldur            w3, [x1, #0x8f]
    // 0xd1c13c: DecompressPointer r3
    //     0xd1c13c: add             x3, x3, HEAP, lsl #32
    // 0xd1c140: cmp             w3, NULL
    // 0xd1c144: b.eq            #0xd1c520
    // 0xd1c148: LoadField: r1 = r3->field_b3
    //     0xd1c148: ldur            w1, [x3, #0xb3]
    // 0xd1c14c: DecompressPointer r1
    //     0xd1c14c: add             x1, x1, HEAP, lsl #32
    // 0xd1c150: cmp             w1, NULL
    // 0xd1c154: b.ne            #0xd1c168
    // 0xd1c158: ldur            x1, [fp, #-0x10]
    // 0xd1c15c: r0 = of()
    //     0xd1c15c: bl              #0xd1e0d0  ; [package:flutter/src/material/input_decorator.dart] InputDecorationTheme::of
    // 0xd1c160: r2 = false
    //     0xd1c160: add             x2, NULL, #0x30  ; false
    // 0xd1c164: b               #0xd1c16c
    // 0xd1c168: mov             x2, x1
    // 0xd1c16c: ldur            x0, [fp, #-8]
    // 0xd1c170: stur            x2, [fp, #-0x40]
    // 0xd1c174: LoadField: r1 = r0->field_b
    //     0xd1c174: ldur            w1, [x0, #0xb]
    // 0xd1c178: DecompressPointer r1
    //     0xd1c178: add             x1, x1, HEAP, lsl #32
    // 0xd1c17c: cmp             w1, NULL
    // 0xd1c180: b.eq            #0xd1c78c
    // 0xd1c184: LoadField: r3 = r1->field_8f
    //     0xd1c184: ldur            w3, [x1, #0x8f]
    // 0xd1c188: DecompressPointer r3
    //     0xd1c188: add             x3, x3, HEAP, lsl #32
    // 0xd1c18c: cmp             w3, NULL
    // 0xd1c190: b.ne            #0xd1c19c
    // 0xd1c194: r1 = Null
    //     0xd1c194: mov             x1, NULL
    // 0xd1c198: b               #0xd1c1e0
    // 0xd1c19c: LoadField: r1 = r3->field_d7
    //     0xd1c19c: ldur            w1, [x3, #0xd7]
    // 0xd1c1a0: DecompressPointer r1
    //     0xd1c1a0: add             x1, x1, HEAP, lsl #32
    // 0xd1c1a4: cmp             w1, NULL
    // 0xd1c1a8: b.ne            #0xd1c1b4
    // 0xd1c1ac: r1 = Null
    //     0xd1c1ac: mov             x1, NULL
    // 0xd1c1b0: b               #0xd1c1e0
    // 0xd1c1b4: r3 = LoadClassIdInstr(r1)
    //     0xd1c1b4: ldur            x3, [x1, #-1]
    //     0xd1c1b8: ubfx            x3, x3, #0xc, #0x14
    // 0xd1c1bc: cmp             x3, #0xbc8
    // 0xd1c1c0: b.ne            #0xd1c1cc
    // 0xd1c1c4: r1 = true
    //     0xd1c1c4: add             x1, NULL, #0x20  ; true
    // 0xd1c1c8: b               #0xd1c1e0
    // 0xd1c1cc: cmp             x3, #0xbc9
    // 0xd1c1d0: b.ne            #0xd1c1dc
    // 0xd1c1d4: r1 = false
    //     0xd1c1d4: add             x1, NULL, #0x30  ; false
    // 0xd1c1d8: b               #0xd1c1e0
    // 0xd1c1dc: r1 = false
    //     0xd1c1dc: add             x1, NULL, #0x30  ; false
    // 0xd1c1e0: cmp             w1, NULL
    // 0xd1c1e4: b.ne            #0xd1c238
    // 0xd1c1e8: ldur            x1, [fp, #-0x10]
    // 0xd1c1ec: r0 = of()
    //     0xd1c1ec: bl              #0xd1e0d0  ; [package:flutter/src/material/input_decorator.dart] InputDecorationTheme::of
    // 0xd1c1f0: LoadField: r1 = r0->field_8b
    //     0xd1c1f0: ldur            w1, [x0, #0x8b]
    // 0xd1c1f4: DecompressPointer r1
    //     0xd1c1f4: add             x1, x1, HEAP, lsl #32
    // 0xd1c1f8: cmp             w1, NULL
    // 0xd1c1fc: b.ne            #0xd1c208
    // 0xd1c200: r0 = Null
    //     0xd1c200: mov             x0, NULL
    // 0xd1c204: b               #0xd1c23c
    // 0xd1c208: r0 = LoadClassIdInstr(r1)
    //     0xd1c208: ldur            x0, [x1, #-1]
    //     0xd1c20c: ubfx            x0, x0, #0xc, #0x14
    // 0xd1c210: cmp             x0, #0xbc8
    // 0xd1c214: b.ne            #0xd1c220
    // 0xd1c218: r0 = true
    //     0xd1c218: add             x0, NULL, #0x20  ; true
    // 0xd1c21c: b               #0xd1c23c
    // 0xd1c220: cmp             x0, #0xbc9
    // 0xd1c224: b.ne            #0xd1c230
    // 0xd1c228: r0 = false
    //     0xd1c228: add             x0, NULL, #0x30  ; false
    // 0xd1c22c: b               #0xd1c23c
    // 0xd1c230: r0 = false
    //     0xd1c230: add             x0, NULL, #0x30  ; false
    // 0xd1c234: b               #0xd1c23c
    // 0xd1c238: mov             x0, x1
    // 0xd1c23c: cmp             w0, NULL
    // 0xd1c240: b.ne            #0xd1c24c
    // 0xd1c244: r1 = false
    //     0xd1c244: add             x1, NULL, #0x30  ; false
    // 0xd1c248: b               #0xd1c250
    // 0xd1c24c: mov             x1, x0
    // 0xd1c250: ldur            x0, [fp, #-0x40]
    // 0xd1c254: tbz             w0, #4, #0xd1c25c
    // 0xd1c258: tbnz            w1, #4, #0xd1c264
    // 0xd1c25c: d1 = 12.000000
    //     0xd1c25c: fmov            d1, #12.00000000
    // 0xd1c260: b               #0xd1c268
    // 0xd1c264: d1 = 0.000000
    //     0xd1c264: eor             v1.16b, v1.16b, v1.16b
    // 0xd1c268: ldur            x1, [fp, #-8]
    // 0xd1c26c: ldur            x0, [fp, #-0x38]
    // 0xd1c270: d0 = 24.000000
    //     0xd1c270: fmov            d0, #24.00000000
    // 0xd1c274: stur            d1, [fp, #-0x88]
    // 0xd1c278: LoadField: r2 = r1->field_b
    //     0xd1c278: ldur            w2, [x1, #0xb]
    // 0xd1c27c: DecompressPointer r2
    //     0xd1c27c: add             x2, x2, HEAP, lsl #32
    // 0xd1c280: cmp             w2, NULL
    // 0xd1c284: b.eq            #0xd1c790
    // 0xd1c288: LoadField: r3 = r2->field_8f
    //     0xd1c288: ldur            w3, [x2, #0x8f]
    // 0xd1c28c: DecompressPointer r3
    //     0xd1c28c: add             x3, x3, HEAP, lsl #32
    // 0xd1c290: stur            x3, [fp, #-0x40]
    // 0xd1c294: cmp             w3, NULL
    // 0xd1c298: b.eq            #0xd1c794
    // 0xd1c29c: fadd            d2, d1, d0
    // 0xd1c2a0: stur            d2, [fp, #-0x80]
    // 0xd1c2a4: r0 = BoxConstraints()
    //     0xd1c2a4: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xd1c2a8: ldur            d0, [fp, #-0x80]
    // 0xd1c2ac: stur            x0, [fp, #-0x48]
    // 0xd1c2b0: StoreField: r0->field_7 = d0
    //     0xd1c2b0: stur            d0, [x0, #7]
    // 0xd1c2b4: d0 = inf
    //     0xd1c2b4: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xd1c2b8: StoreField: r0->field_f = d0
    //     0xd1c2b8: stur            d0, [x0, #0xf]
    // 0xd1c2bc: d1 = 24.000000
    //     0xd1c2bc: fmov            d1, #24.00000000
    // 0xd1c2c0: ArrayStore: r0[0] = d1  ; List_8
    //     0xd1c2c0: stur            d1, [x0, #0x17]
    // 0xd1c2c4: StoreField: r0->field_1f = d0
    //     0xd1c2c4: stur            d0, [x0, #0x1f]
    // 0xd1c2c8: r0 = EdgeInsetsDirectional()
    //     0xd1c2c8: bl              #0xb50060  ; AllocateEdgeInsetsDirectionalStub -> EdgeInsetsDirectional (size=0x28)
    // 0xd1c2cc: stur            x0, [fp, #-0x58]
    // 0xd1c2d0: StoreField: r0->field_7 = rZR
    //     0xd1c2d0: stur            xzr, [x0, #7]
    // 0xd1c2d4: StoreField: r0->field_f = rZR
    //     0xd1c2d4: stur            xzr, [x0, #0xf]
    // 0xd1c2d8: ldur            d0, [fp, #-0x88]
    // 0xd1c2dc: ArrayStore: r0[0] = d0  ; List_8
    //     0xd1c2dc: stur            d0, [x0, #0x17]
    // 0xd1c2e0: StoreField: r0->field_1f = rZR
    //     0xd1c2e0: stur            xzr, [x0, #0x1f]
    // 0xd1c2e4: r0 = Padding()
    //     0xd1c2e4: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xd1c2e8: mov             x1, x0
    // 0xd1c2ec: ldur            x0, [fp, #-0x58]
    // 0xd1c2f0: StoreField: r1->field_f = r0
    //     0xd1c2f0: stur            w0, [x1, #0xf]
    // 0xd1c2f4: ldur            x0, [fp, #-0x38]
    // 0xd1c2f8: StoreField: r1->field_b = r0
    //     0xd1c2f8: stur            w0, [x1, #0xb]
    // 0xd1c2fc: ldur            x16, [fp, #-0x48]
    // 0xd1c300: stp             x1, x16, [SP]
    // 0xd1c304: ldur            x1, [fp, #-0x40]
    // 0xd1c308: r4 = const [0, 0x3, 0x2, 0x1, suffixIcon, 0x2, suffixIconConstraints, 0x1, null]
    //     0xd1c308: add             x4, PP, #0x99, lsl #12  ; [pp+0x99958] List(9) [0, 0x3, 0x2, 0x1, "suffixIcon", 0x2, "suffixIconConstraints", 0x1, Null]
    //     0xd1c30c: ldr             x4, [x4, #0x958]
    // 0xd1c310: r0 = copyWith()
    //     0xd1c310: bl              #0xd1c914  ; [package:flutter/src/material/input_decorator.dart] InputDecoration::copyWith
    // 0xd1c314: mov             x1, x0
    // 0xd1c318: ldur            x0, [fp, #-8]
    // 0xd1c31c: LoadField: r2 = r0->field_2b
    //     0xd1c31c: ldur            w2, [x0, #0x2b]
    // 0xd1c320: DecompressPointer r2
    //     0xd1c320: add             x2, x2, HEAP, lsl #32
    // 0xd1c324: tbnz            w2, #4, #0xd1c368
    // 0xd1c328: LoadField: r2 = r0->field_b
    //     0xd1c328: ldur            w2, [x0, #0xb]
    // 0xd1c32c: DecompressPointer r2
    //     0xd1c32c: add             x2, x2, HEAP, lsl #32
    // 0xd1c330: cmp             w2, NULL
    // 0xd1c334: b.eq            #0xd1c798
    // 0xd1c338: LoadField: r2 = r1->field_bb
    //     0xd1c338: ldur            w2, [x1, #0xbb]
    // 0xd1c33c: DecompressPointer r2
    //     0xd1c33c: add             x2, x2, HEAP, lsl #32
    // 0xd1c340: cmp             w2, NULL
    // 0xd1c344: b.eq            #0xd1c35c
    // 0xd1c348: str             x2, [SP]
    // 0xd1c34c: r4 = const [0, 0x2, 0x1, 0x1, fillColor, 0x1, null]
    //     0xd1c34c: add             x4, PP, #0x99, lsl #12  ; [pp+0x99960] List(7) [0, 0x2, 0x1, 0x1, "fillColor", 0x1, Null]
    //     0xd1c350: ldr             x4, [x4, #0x960]
    // 0xd1c354: r0 = copyWith()
    //     0xd1c354: bl              #0xd1c914  ; [package:flutter/src/material/input_decorator.dart] InputDecoration::copyWith
    // 0xd1c358: b               #0xd1c360
    // 0xd1c35c: mov             x0, x1
    // 0xd1c360: mov             x2, x0
    // 0xd1c364: b               #0xd1c36c
    // 0xd1c368: mov             x2, x1
    // 0xd1c36c: ldur            x0, [fp, #-8]
    // 0xd1c370: mov             x1, x0
    // 0xd1c374: stur            x2, [fp, #-0x38]
    // 0xd1c378: r0 = _enabled()
    //     0xd1c378: bl              #0xd1e854  ; [package:flutter/src/material/dropdown.dart] _DropdownButtonState::_enabled
    // 0xd1c37c: mov             x2, x0
    // 0xd1c380: ldur            x0, [fp, #-8]
    // 0xd1c384: stur            x2, [fp, #-0x48]
    // 0xd1c388: LoadField: r1 = r0->field_b
    //     0xd1c388: ldur            w1, [x0, #0xb]
    // 0xd1c38c: DecompressPointer r1
    //     0xd1c38c: add             x1, x1, HEAP, lsl #32
    // 0xd1c390: cmp             w1, NULL
    // 0xd1c394: b.eq            #0xd1c79c
    // 0xd1c398: LoadField: r3 = r0->field_1f
    //     0xd1c398: ldur            w3, [x0, #0x1f]
    // 0xd1c39c: DecompressPointer r3
    //     0xd1c39c: add             x3, x3, HEAP, lsl #32
    // 0xd1c3a0: stur            x3, [fp, #-0x40]
    // 0xd1c3a4: cmp             w3, NULL
    // 0xd1c3a8: b.eq            #0xd1c7a0
    // 0xd1c3ac: mov             x1, x0
    // 0xd1c3b0: r0 = _enabled()
    //     0xd1c3b0: bl              #0xd1e854  ; [package:flutter/src/material/dropdown.dart] _DropdownButtonState::_enabled
    // 0xd1c3b4: tbnz            w0, #4, #0xd1c3d0
    // 0xd1c3b8: ldur            x2, [fp, #-8]
    // 0xd1c3bc: r1 = Function '_handleTap@83005770':.
    //     0xd1c3bc: add             x1, PP, #0x99, lsl #12  ; [pp+0x99968] AnonymousClosure: (0xd1ee14), in [package:flutter/src/material/dropdown.dart] _DropdownButtonState::_handleTap (0xd1ee4c)
    //     0xd1c3c0: ldr             x1, [x1, #0x968]
    // 0xd1c3c4: r0 = AllocateClosure()
    //     0xd1c3c4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd1c3c8: mov             x6, x0
    // 0xd1c3cc: b               #0xd1c3d4
    // 0xd1c3d0: r6 = Null
    //     0xd1c3d0: mov             x6, NULL
    // 0xd1c3d4: ldur            x1, [fp, #-8]
    // 0xd1c3d8: ldur            x5, [fp, #-0x20]
    // 0xd1c3dc: ldur            x4, [fp, #-0x30]
    // 0xd1c3e0: ldur            x3, [fp, #-0x38]
    // 0xd1c3e4: ldur            x0, [fp, #-0x48]
    // 0xd1c3e8: ldur            x2, [fp, #-0x40]
    // 0xd1c3ec: stur            x6, [fp, #-0x70]
    // 0xd1c3f0: LoadField: r7 = r1->field_b
    //     0xd1c3f0: ldur            w7, [x1, #0xb]
    // 0xd1c3f4: DecompressPointer r7
    //     0xd1c3f4: add             x7, x7, HEAP, lsl #32
    // 0xd1c3f8: cmp             w7, NULL
    // 0xd1c3fc: b.eq            #0xd1c7a4
    // 0xd1c400: LoadField: r8 = r7->field_93
    //     0xd1c400: ldur            w8, [x7, #0x93]
    // 0xd1c404: DecompressPointer r8
    //     0xd1c404: add             x8, x8, HEAP, lsl #32
    // 0xd1c408: stur            x8, [fp, #-0x68]
    // 0xd1c40c: LoadField: r7 = r1->field_2b
    //     0xd1c40c: ldur            w7, [x1, #0x2b]
    // 0xd1c410: DecompressPointer r7
    //     0xd1c410: add             x7, x7, HEAP, lsl #32
    // 0xd1c414: stur            x7, [fp, #-0x60]
    // 0xd1c418: LoadField: r9 = r1->field_27
    //     0xd1c418: ldur            w9, [x1, #0x27]
    // 0xd1c41c: DecompressPointer r9
    //     0xd1c41c: add             x9, x9, HEAP, lsl #32
    // 0xd1c420: stur            x9, [fp, #-0x58]
    // 0xd1c424: r0 = InputDecorator()
    //     0xd1c424: bl              #0xd1c908  ; AllocateInputDecoratorStub -> InputDecorator (size=0x30)
    // 0xd1c428: mov             x1, x0
    // 0xd1c42c: ldur            x0, [fp, #-0x38]
    // 0xd1c430: stur            x1, [fp, #-0x78]
    // 0xd1c434: StoreField: r1->field_b = r0
    //     0xd1c434: stur            w0, [x1, #0xb]
    // 0xd1c438: ldur            x0, [fp, #-0x60]
    // 0xd1c43c: StoreField: r1->field_1b = r0
    //     0xd1c43c: stur            w0, [x1, #0x1b]
    // 0xd1c440: ldur            x0, [fp, #-0x58]
    // 0xd1c444: StoreField: r1->field_1f = r0
    //     0xd1c444: stur            w0, [x1, #0x1f]
    // 0xd1c448: r0 = false
    //     0xd1c448: add             x0, NULL, #0x30  ; false
    // 0xd1c44c: StoreField: r1->field_23 = r0
    //     0xd1c44c: stur            w0, [x1, #0x23]
    // 0xd1c450: ldur            x2, [fp, #-0x68]
    // 0xd1c454: StoreField: r1->field_27 = r2
    //     0xd1c454: stur            w2, [x1, #0x27]
    // 0xd1c458: ldur            x2, [fp, #-0x20]
    // 0xd1c45c: StoreField: r1->field_2b = r2
    //     0xd1c45c: stur            w2, [x1, #0x2b]
    // 0xd1c460: r0 = GestureDetector()
    //     0xd1c460: bl              #0x918e18  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0xd1c464: stur            x0, [fp, #-0x38]
    // 0xd1c468: ldur            x16, [fp, #-0x70]
    // 0xd1c46c: r30 = Instance_HitTestBehavior
    //     0xd1c46c: add             lr, PP, #0x15, lsl #12  ; [pp+0x155c0] Obj!HitTestBehavior@12c43c1
    //     0xd1c470: ldr             lr, [lr, #0x5c0]
    // 0xd1c474: stp             lr, x16, [SP, #8]
    // 0xd1c478: ldur            x16, [fp, #-0x78]
    // 0xd1c47c: str             x16, [SP]
    // 0xd1c480: mov             x1, x0
    // 0xd1c484: r4 = const [0, 0x4, 0x3, 0x1, behavior, 0x2, child, 0x3, onTap, 0x1, null]
    //     0xd1c484: add             x4, PP, #0x99, lsl #12  ; [pp+0x99970] List(11) [0, 0x4, 0x3, 0x1, "behavior", 0x2, "child", 0x3, "onTap", 0x1, Null]
    //     0xd1c488: ldr             x4, [x4, #0x970]
    // 0xd1c48c: r0 = GestureDetector()
    //     0xd1c48c: bl              #0x9182dc  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0xd1c490: ldur            x2, [fp, #-0x18]
    // 0xd1c494: r1 = Function '<anonymous closure>':.
    //     0xd1c494: add             x1, PP, #0x99, lsl #12  ; [pp+0x99978] AnonymousClosure: (0xd1ed84), in [package:flutter/src/material/dropdown.dart] _DropdownButtonState::build (0xd1b434)
    //     0xd1c498: ldr             x1, [x1, #0x978]
    // 0xd1c49c: r0 = AllocateClosure()
    //     0xd1c49c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd1c4a0: stur            x0, [fp, #-0x58]
    // 0xd1c4a4: r0 = MouseRegion()
    //     0xd1c4a4: bl              #0xd1c8fc  ; AllocateMouseRegionStub -> MouseRegion (size=0x28)
    // 0xd1c4a8: mov             x3, x0
    // 0xd1c4ac: ldur            x0, [fp, #-0x58]
    // 0xd1c4b0: stur            x3, [fp, #-0x60]
    // 0xd1c4b4: StoreField: r3->field_f = r0
    //     0xd1c4b4: stur            w0, [x3, #0xf]
    // 0xd1c4b8: ldur            x2, [fp, #-0x18]
    // 0xd1c4bc: r1 = Function '<anonymous closure>':.
    //     0xd1c4bc: add             x1, PP, #0x99, lsl #12  ; [pp+0x99980] AnonymousClosure: (0xd1ecf4), in [package:flutter/src/material/dropdown.dart] _DropdownButtonState::build (0xd1b434)
    //     0xd1c4c0: ldr             x1, [x1, #0x980]
    // 0xd1c4c4: r0 = AllocateClosure()
    //     0xd1c4c4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd1c4c8: mov             x1, x0
    // 0xd1c4cc: ldur            x0, [fp, #-0x60]
    // 0xd1c4d0: ArrayStore: r0[0] = r1  ; List_4
    //     0xd1c4d0: stur            w1, [x0, #0x17]
    // 0xd1c4d4: ldur            x3, [fp, #-0x30]
    // 0xd1c4d8: StoreField: r0->field_1b = r3
    //     0xd1c4d8: stur            w3, [x0, #0x1b]
    // 0xd1c4dc: r1 = true
    //     0xd1c4dc: add             x1, NULL, #0x20  ; true
    // 0xd1c4e0: StoreField: r0->field_1f = r1
    //     0xd1c4e0: stur            w1, [x0, #0x1f]
    // 0xd1c4e4: ldur            x2, [fp, #-0x38]
    // 0xd1c4e8: StoreField: r0->field_b = r2
    //     0xd1c4e8: stur            w2, [x0, #0xb]
    // 0xd1c4ec: r0 = Focus()
    //     0xd1c4ec: bl              #0xd1c8f0  ; AllocateFocusStub -> Focus (size=0x40)
    // 0xd1c4f0: mov             x1, x0
    // 0xd1c4f4: ldur            x0, [fp, #-0x60]
    // 0xd1c4f8: StoreField: r1->field_f = r0
    //     0xd1c4f8: stur            w0, [x1, #0xf]
    // 0xd1c4fc: ldur            x0, [fp, #-0x40]
    // 0xd1c500: StoreField: r1->field_13 = r0
    //     0xd1c500: stur            w0, [x1, #0x13]
    // 0xd1c504: r0 = false
    //     0xd1c504: add             x0, NULL, #0x30  ; false
    // 0xd1c508: ArrayStore: r1[0] = r0  ; List_4
    //     0xd1c508: stur            w0, [x1, #0x17]
    // 0xd1c50c: r4 = true
    //     0xd1c50c: add             x4, NULL, #0x20  ; true
    // 0xd1c510: StoreField: r1->field_37 = r4
    //     0xd1c510: stur            w4, [x1, #0x37]
    // 0xd1c514: ldur            x0, [fp, #-0x48]
    // 0xd1c518: StoreField: r1->field_27 = r0
    //     0xd1c518: stur            w0, [x1, #0x27]
    // 0xd1c51c: b               #0xd1c634
    // 0xd1c520: mov             x3, x2
    // 0xd1c524: ldur            x2, [fp, #-0x20]
    // 0xd1c528: r4 = true
    //     0xd1c528: add             x4, NULL, #0x20  ; true
    // 0xd1c52c: r0 = false
    //     0xd1c52c: add             x0, NULL, #0x30  ; false
    // 0xd1c530: ldur            x1, [fp, #-8]
    // 0xd1c534: r0 = _enabled()
    //     0xd1c534: bl              #0xd1e854  ; [package:flutter/src/material/dropdown.dart] _DropdownButtonState::_enabled
    // 0xd1c538: tbnz            w0, #4, #0xd1c554
    // 0xd1c53c: ldur            x2, [fp, #-8]
    // 0xd1c540: r1 = Function '_handleTap@83005770':.
    //     0xd1c540: add             x1, PP, #0x99, lsl #12  ; [pp+0x99968] AnonymousClosure: (0xd1ee14), in [package:flutter/src/material/dropdown.dart] _DropdownButtonState::_handleTap (0xd1ee4c)
    //     0xd1c544: ldr             x1, [x1, #0x968]
    // 0xd1c548: r0 = AllocateClosure()
    //     0xd1c548: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd1c54c: mov             x4, x0
    // 0xd1c550: b               #0xd1c558
    // 0xd1c554: r4 = Null
    //     0xd1c554: mov             x4, NULL
    // 0xd1c558: ldur            x3, [fp, #-8]
    // 0xd1c55c: ldur            x0, [fp, #-0x20]
    // 0xd1c560: ldur            x2, [fp, #-0x30]
    // 0xd1c564: mov             x1, x3
    // 0xd1c568: stur            x4, [fp, #-0x18]
    // 0xd1c56c: r0 = _enabled()
    //     0xd1c56c: bl              #0xd1e854  ; [package:flutter/src/material/dropdown.dart] _DropdownButtonState::_enabled
    // 0xd1c570: mov             x2, x0
    // 0xd1c574: ldur            x0, [fp, #-8]
    // 0xd1c578: stur            x2, [fp, #-0x38]
    // 0xd1c57c: LoadField: r1 = r0->field_b
    //     0xd1c57c: ldur            w1, [x0, #0xb]
    // 0xd1c580: DecompressPointer r1
    //     0xd1c580: add             x1, x1, HEAP, lsl #32
    // 0xd1c584: cmp             w1, NULL
    // 0xd1c588: b.eq            #0xd1c7a8
    // 0xd1c58c: mov             x1, x0
    // 0xd1c590: r0 = focusNode()
    //     0xd1c590: bl              #0xd1c8b4  ; [package:flutter/src/material/dropdown.dart] _DropdownButtonState::focusNode
    // 0xd1c594: mov             x2, x0
    // 0xd1c598: ldur            x0, [fp, #-8]
    // 0xd1c59c: stur            x2, [fp, #-0x40]
    // 0xd1c5a0: LoadField: r1 = r0->field_b
    //     0xd1c5a0: ldur            w1, [x0, #0xb]
    // 0xd1c5a4: DecompressPointer r1
    //     0xd1c5a4: add             x1, x1, HEAP, lsl #32
    // 0xd1c5a8: cmp             w1, NULL
    // 0xd1c5ac: b.eq            #0xd1c7ac
    // 0xd1c5b0: ldur            x1, [fp, #-0x10]
    // 0xd1c5b4: r0 = of()
    //     0xd1c5b4: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd1c5b8: LoadField: r1 = r0->field_4b
    //     0xd1c5b8: ldur            w1, [x0, #0x4b]
    // 0xd1c5bc: DecompressPointer r1
    //     0xd1c5bc: add             x1, x1, HEAP, lsl #32
    // 0xd1c5c0: ldur            x0, [fp, #-8]
    // 0xd1c5c4: stur            x1, [fp, #-0x10]
    // 0xd1c5c8: LoadField: r2 = r0->field_b
    //     0xd1c5c8: ldur            w2, [x0, #0xb]
    // 0xd1c5cc: DecompressPointer r2
    //     0xd1c5cc: add             x2, x2, HEAP, lsl #32
    // 0xd1c5d0: cmp             w2, NULL
    // 0xd1c5d4: b.eq            #0xd1c7b0
    // 0xd1c5d8: r0 = InkWell()
    //     0xd1c5d8: bl              #0xd0c57c  ; AllocateInkWellStub -> InkWell (size=0x94)
    // 0xd1c5dc: mov             x1, x0
    // 0xd1c5e0: ldur            x0, [fp, #-0x20]
    // 0xd1c5e4: StoreField: r1->field_b = r0
    //     0xd1c5e4: stur            w0, [x1, #0xb]
    // 0xd1c5e8: ldur            x0, [fp, #-0x18]
    // 0xd1c5ec: StoreField: r1->field_f = r0
    //     0xd1c5ec: stur            w0, [x1, #0xf]
    // 0xd1c5f0: ldur            x0, [fp, #-0x30]
    // 0xd1c5f4: StoreField: r1->field_43 = r0
    //     0xd1c5f4: stur            w0, [x1, #0x43]
    // 0xd1c5f8: r0 = true
    //     0xd1c5f8: add             x0, NULL, #0x20  ; true
    // 0xd1c5fc: StoreField: r1->field_47 = r0
    //     0xd1c5fc: stur            w0, [x1, #0x47]
    // 0xd1c600: r0 = Instance_BoxShape
    //     0xd1c600: add             x0, PP, #0x17, lsl #12  ; [pp+0x171f8] Obj!BoxShape@12c4921
    //     0xd1c604: ldr             x0, [x0, #0x1f8]
    // 0xd1c608: StoreField: r1->field_4b = r0
    //     0xd1c608: stur            w0, [x1, #0x4b]
    // 0xd1c60c: ldur            x0, [fp, #-0x10]
    // 0xd1c610: StoreField: r1->field_5b = r0
    //     0xd1c610: stur            w0, [x1, #0x5b]
    // 0xd1c614: r0 = false
    //     0xd1c614: add             x0, NULL, #0x30  ; false
    // 0xd1c618: StoreField: r1->field_73 = r0
    //     0xd1c618: stur            w0, [x1, #0x73]
    // 0xd1c61c: StoreField: r1->field_77 = r0
    //     0xd1c61c: stur            w0, [x1, #0x77]
    // 0xd1c620: ldur            x2, [fp, #-0x40]
    // 0xd1c624: StoreField: r1->field_83 = r2
    //     0xd1c624: stur            w2, [x1, #0x83]
    // 0xd1c628: ldur            x2, [fp, #-0x38]
    // 0xd1c62c: StoreField: r1->field_87 = r2
    //     0xd1c62c: stur            w2, [x1, #0x87]
    // 0xd1c630: StoreField: r1->field_7f = r0
    //     0xd1c630: stur            w0, [x1, #0x7f]
    // 0xd1c634: ldur            x0, [fp, #-0x28]
    // 0xd1c638: stur            x1, [fp, #-0x30]
    // 0xd1c63c: cmp             w0, NULL
    // 0xd1c640: b.eq            #0xd1c650
    // 0xd1c644: ldur            x0, [fp, #-8]
    // 0xd1c648: r2 = true
    //     0xd1c648: add             x2, NULL, #0x20  ; true
    // 0xd1c64c: b               #0xd1c694
    // 0xd1c650: ldur            x0, [fp, #-8]
    // 0xd1c654: LoadField: r2 = r0->field_13
    //     0xd1c654: ldur            w2, [x0, #0x13]
    // 0xd1c658: DecompressPointer r2
    //     0xd1c658: add             x2, x2, HEAP, lsl #32
    // 0xd1c65c: cmp             w2, NULL
    // 0xd1c660: b.eq            #0xd1c690
    // 0xd1c664: LoadField: r2 = r0->field_b
    //     0xd1c664: ldur            w2, [x0, #0xb]
    // 0xd1c668: DecompressPointer r2
    //     0xd1c668: add             x2, x2, HEAP, lsl #32
    // 0xd1c66c: cmp             w2, NULL
    // 0xd1c670: b.eq            #0xd1c7b4
    // 0xd1c674: LoadField: r3 = r2->field_27
    //     0xd1c674: ldur            w3, [x2, #0x27]
    // 0xd1c678: DecompressPointer r3
    //     0xd1c678: add             x3, x3, HEAP, lsl #32
    // 0xd1c67c: cmp             w3, NULL
    // 0xd1c680: r16 = true
    //     0xd1c680: add             x16, NULL, #0x20  ; true
    // 0xd1c684: r17 = false
    //     0xd1c684: add             x17, NULL, #0x30  ; false
    // 0xd1c688: csel            x2, x16, x17, eq
    // 0xd1c68c: b               #0xd1c694
    // 0xd1c690: r2 = false
    //     0xd1c690: add             x2, NULL, #0x30  ; false
    // 0xd1c694: eor             x3, x2, #0x10
    // 0xd1c698: stur            x3, [fp, #-0x20]
    // 0xd1c69c: LoadField: r2 = r0->field_2f
    //     0xd1c69c: ldur            w2, [x0, #0x2f]
    // 0xd1c6a0: DecompressPointer r2
    //     0xd1c6a0: add             x2, x2, HEAP, lsl #32
    // 0xd1c6a4: stur            x2, [fp, #-0x18]
    // 0xd1c6a8: LoadField: r4 = r0->field_23
    //     0xd1c6a8: ldur            w4, [x0, #0x23]
    // 0xd1c6ac: DecompressPointer r4
    //     0xd1c6ac: add             x4, x4, HEAP, lsl #32
    // 0xd1c6b0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd1c6b4: cmp             w4, w16
    // 0xd1c6b8: b.eq            #0xd1c7b8
    // 0xd1c6bc: stur            x4, [fp, #-0x10]
    // 0xd1c6c0: r0 = Actions()
    //     0xd1c6c0: bl              #0xd1c8a8  ; AllocateActionsStub -> Actions (size=0x18)
    // 0xd1c6c4: mov             x1, x0
    // 0xd1c6c8: ldur            x0, [fp, #-0x10]
    // 0xd1c6cc: stur            x1, [fp, #-8]
    // 0xd1c6d0: StoreField: r1->field_f = r0
    //     0xd1c6d0: stur            w0, [x1, #0xf]
    // 0xd1c6d4: ldur            x0, [fp, #-0x30]
    // 0xd1c6d8: StoreField: r1->field_13 = r0
    //     0xd1c6d8: stur            w0, [x1, #0x13]
    // 0xd1c6dc: r0 = Semantics()
    //     0xd1c6dc: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xd1c6e0: stur            x0, [fp, #-0x10]
    // 0xd1c6e4: ldur            x16, [fp, #-0x20]
    // 0xd1c6e8: ldur            lr, [fp, #-0x18]
    // 0xd1c6ec: stp             lr, x16, [SP, #8]
    // 0xd1c6f0: ldur            x16, [fp, #-8]
    // 0xd1c6f4: str             x16, [SP]
    // 0xd1c6f8: mov             x1, x0
    // 0xd1c6fc: r4 = const [0, 0x4, 0x3, 0x1, button, 0x1, child, 0x3, expanded, 0x2, null]
    //     0xd1c6fc: add             x4, PP, #0x99, lsl #12  ; [pp+0x99988] List(11) [0, 0x4, 0x3, 0x1, "button", 0x1, "child", 0x3, "expanded", 0x2, Null]
    //     0xd1c700: ldr             x4, [x4, #0x988]
    // 0xd1c704: r0 = Semantics()
    //     0xd1c704: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xd1c708: ldur            x0, [fp, #-0x10]
    // 0xd1c70c: LeaveFrame
    //     0xd1c70c: mov             SP, fp
    //     0xd1c710: ldp             fp, lr, [SP], #0x10
    // 0xd1c714: ret
    //     0xd1c714: ret             
    // 0xd1c718: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1c718: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd1c71c: b               #0xd1b454
    // 0xd1c720: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1c720: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1c724: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1c724: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1c728: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1c728: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1c72c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1c72c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1c730: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1c730: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1c734: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1c734: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1c738: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1c738: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1c73c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1c73c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1c740: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1c740: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1c744: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1c744: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1c748: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1c748: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1c74c: SaveReg d0
    //     0xd1c74c: str             q0, [SP, #-0x10]!
    // 0xd1c750: r0 = AllocateDouble()
    //     0xd1c750: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd1c754: RestoreReg d0
    //     0xd1c754: ldr             q0, [SP], #0x10
    // 0xd1c758: b               #0xd1bc1c
    // 0xd1c75c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1c75c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1c760: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1c760: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1c764: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xd1c764: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xd1c768: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1c768: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1c76c: SaveReg d0
    //     0xd1c76c: str             q0, [SP, #-0x10]!
    // 0xd1c770: SaveReg r3
    //     0xd1c770: str             x3, [SP, #-8]!
    // 0xd1c774: r0 = AllocateDouble()
    //     0xd1c774: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd1c778: RestoreReg r3
    //     0xd1c778: ldr             x3, [SP], #8
    // 0xd1c77c: RestoreReg d0
    //     0xd1c77c: ldr             q0, [SP], #0x10
    // 0xd1c780: b               #0xd1bffc
    // 0xd1c784: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1c784: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1c788: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1c788: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1c78c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1c78c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1c790: r0 = NullCastErrorSharedWithFPURegs()
    //     0xd1c790: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xd1c794: r0 = NullCastErrorSharedWithFPURegs()
    //     0xd1c794: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xd1c798: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1c798: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1c79c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1c79c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1c7a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1c7a0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1c7a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1c7a4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1c7a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1c7a8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1c7ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1c7ac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1c7b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1c7b0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1c7b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1c7b4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1c7b8: r9 = _actionMap
    //     0xd1c7b8: add             x9, PP, #0x99, lsl #12  ; [pp+0x99990] Field <_DropdownButtonState@83005770._actionMap@83005770>: late (offset: 0x24)
    //     0xd1c7bc: ldr             x9, [x9, #0x990]
    // 0xd1c7c0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd1c7c0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  get _ focusNode(/* No info */) {
    // ** addr: 0xd1c8b4, size: 0x3c
    // 0xd1c8b4: EnterFrame
    //     0xd1c8b4: stp             fp, lr, [SP, #-0x10]!
    //     0xd1c8b8: mov             fp, SP
    // 0xd1c8bc: LoadField: r2 = r1->field_b
    //     0xd1c8bc: ldur            w2, [x1, #0xb]
    // 0xd1c8c0: DecompressPointer r2
    //     0xd1c8c0: add             x2, x2, HEAP, lsl #32
    // 0xd1c8c4: cmp             w2, NULL
    // 0xd1c8c8: b.eq            #0xd1c8e8
    // 0xd1c8cc: LoadField: r0 = r1->field_1f
    //     0xd1c8cc: ldur            w0, [x1, #0x1f]
    // 0xd1c8d0: DecompressPointer r0
    //     0xd1c8d0: add             x0, x0, HEAP, lsl #32
    // 0xd1c8d4: cmp             w0, NULL
    // 0xd1c8d8: b.eq            #0xd1c8ec
    // 0xd1c8dc: LeaveFrame
    //     0xd1c8dc: mov             SP, fp
    //     0xd1c8e0: ldp             fp, lr, [SP], #0x10
    // 0xd1c8e4: ret
    //     0xd1c8e4: ret             
    // 0xd1c8e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1c8e8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1c8ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1c8ec: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _denseButtonHeight(/* No info */) {
    // ** addr: 0xd1e19c, size: 0x188
    // 0xd1e19c: EnterFrame
    //     0xd1e19c: stp             fp, lr, [SP, #-0x10]!
    //     0xd1e1a0: mov             fp, SP
    // 0xd1e1a4: AllocStack(0x18)
    //     0xd1e1a4: sub             SP, SP, #0x18
    // 0xd1e1a8: SetupParameters(_DropdownButtonState<C1X0> this /* r1 => r0, fp-0x8 */)
    //     0xd1e1a8: mov             x0, x1
    //     0xd1e1ac: stur            x1, [fp, #-8]
    // 0xd1e1b0: CheckStackOverflow
    //     0xd1e1b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd1e1b4: cmp             SP, x16
    //     0xd1e1b8: b.ls            #0xd1e308
    // 0xd1e1bc: mov             x1, x0
    // 0xd1e1c0: r0 = _textStyle()
    //     0xd1e1c0: bl              #0xd1e7d0  ; [package:flutter/src/material/dropdown.dart] _DropdownButtonState::_textStyle
    // 0xd1e1c4: LoadField: r1 = r0->field_1f
    //     0xd1e1c4: ldur            w1, [x0, #0x1f]
    // 0xd1e1c8: DecompressPointer r1
    //     0xd1e1c8: add             x1, x1, HEAP, lsl #32
    // 0xd1e1cc: cmp             w1, NULL
    // 0xd1e1d0: b.ne            #0xd1e214
    // 0xd1e1d4: ldur            x0, [fp, #-8]
    // 0xd1e1d8: LoadField: r1 = r0->field_f
    //     0xd1e1d8: ldur            w1, [x0, #0xf]
    // 0xd1e1dc: DecompressPointer r1
    //     0xd1e1dc: add             x1, x1, HEAP, lsl #32
    // 0xd1e1e0: cmp             w1, NULL
    // 0xd1e1e4: b.eq            #0xd1e310
    // 0xd1e1e8: r0 = of()
    //     0xd1e1e8: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd1e1ec: LoadField: r1 = r0->field_87
    //     0xd1e1ec: ldur            w1, [x0, #0x87]
    // 0xd1e1f0: DecompressPointer r1
    //     0xd1e1f0: add             x1, x1, HEAP, lsl #32
    // 0xd1e1f4: LoadField: r0 = r1->field_23
    //     0xd1e1f4: ldur            w0, [x1, #0x23]
    // 0xd1e1f8: DecompressPointer r0
    //     0xd1e1f8: add             x0, x0, HEAP, lsl #32
    // 0xd1e1fc: LoadField: r1 = r0->field_1f
    //     0xd1e1fc: ldur            w1, [x0, #0x1f]
    // 0xd1e200: DecompressPointer r1
    //     0xd1e200: add             x1, x1, HEAP, lsl #32
    // 0xd1e204: cmp             w1, NULL
    // 0xd1e208: b.eq            #0xd1e314
    // 0xd1e20c: LoadField: d0 = r1->field_7
    //     0xd1e20c: ldur            d0, [x1, #7]
    // 0xd1e210: b               #0xd1e218
    // 0xd1e214: LoadField: d0 = r1->field_7
    //     0xd1e214: ldur            d0, [x1, #7]
    // 0xd1e218: ldur            x1, [fp, #-8]
    // 0xd1e21c: stur            d0, [fp, #-0x10]
    // 0xd1e220: r0 = _textStyle()
    //     0xd1e220: bl              #0xd1e7d0  ; [package:flutter/src/material/dropdown.dart] _DropdownButtonState::_textStyle
    // 0xd1e224: LoadField: r1 = r0->field_37
    //     0xd1e224: ldur            w1, [x0, #0x37]
    // 0xd1e228: DecompressPointer r1
    //     0xd1e228: add             x1, x1, HEAP, lsl #32
    // 0xd1e22c: cmp             w1, NULL
    // 0xd1e230: b.ne            #0xd1e26c
    // 0xd1e234: ldur            x0, [fp, #-8]
    // 0xd1e238: LoadField: r1 = r0->field_f
    //     0xd1e238: ldur            w1, [x0, #0xf]
    // 0xd1e23c: DecompressPointer r1
    //     0xd1e23c: add             x1, x1, HEAP, lsl #32
    // 0xd1e240: cmp             w1, NULL
    // 0xd1e244: b.eq            #0xd1e318
    // 0xd1e248: r0 = of()
    //     0xd1e248: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd1e24c: LoadField: r1 = r0->field_87
    //     0xd1e24c: ldur            w1, [x0, #0x87]
    // 0xd1e250: DecompressPointer r1
    //     0xd1e250: add             x1, x1, HEAP, lsl #32
    // 0xd1e254: LoadField: r0 = r1->field_23
    //     0xd1e254: ldur            w0, [x1, #0x23]
    // 0xd1e258: DecompressPointer r0
    //     0xd1e258: add             x0, x0, HEAP, lsl #32
    // 0xd1e25c: LoadField: r1 = r0->field_37
    //     0xd1e25c: ldur            w1, [x0, #0x37]
    // 0xd1e260: DecompressPointer r1
    //     0xd1e260: add             x1, x1, HEAP, lsl #32
    // 0xd1e264: mov             x0, x1
    // 0xd1e268: b               #0xd1e270
    // 0xd1e26c: mov             x0, x1
    // 0xd1e270: cmp             w0, NULL
    // 0xd1e274: b.ne            #0xd1e280
    // 0xd1e278: d1 = 1.000000
    //     0xd1e278: fmov            d1, #1.00000000
    // 0xd1e27c: b               #0xd1e288
    // 0xd1e280: LoadField: d0 = r0->field_7
    //     0xd1e280: ldur            d0, [x0, #7]
    // 0xd1e284: mov             v1.16b, v0.16b
    // 0xd1e288: ldur            x0, [fp, #-8]
    // 0xd1e28c: ldur            d0, [fp, #-0x10]
    // 0xd1e290: stur            d1, [fp, #-0x18]
    // 0xd1e294: LoadField: r1 = r0->field_f
    //     0xd1e294: ldur            w1, [x0, #0xf]
    // 0xd1e298: DecompressPointer r1
    //     0xd1e298: add             x1, x1, HEAP, lsl #32
    // 0xd1e29c: cmp             w1, NULL
    // 0xd1e2a0: b.eq            #0xd1e31c
    // 0xd1e2a4: r0 = textScalerOf()
    //     0xd1e2a4: bl              #0xd16168  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::textScalerOf
    // 0xd1e2a8: ldur            d0, [fp, #-0x10]
    // 0xd1e2ac: ldur            d1, [fp, #-0x18]
    // 0xd1e2b0: fmul            d2, d0, d1
    // 0xd1e2b4: r1 = LoadClassIdInstr(r0)
    //     0xd1e2b4: ldur            x1, [x0, #-1]
    //     0xd1e2b8: ubfx            x1, x1, #0xc, #0x14
    // 0xd1e2bc: mov             x16, x0
    // 0xd1e2c0: mov             x0, x1
    // 0xd1e2c4: mov             x1, x16
    // 0xd1e2c8: mov             v0.16b, v2.16b
    // 0xd1e2cc: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd1e2cc: sub             lr, x0, #1, lsl #12
    //     0xd1e2d0: ldr             lr, [x21, lr, lsl #3]
    //     0xd1e2d4: blr             lr
    // 0xd1e2d8: mov             x1, x0
    // 0xd1e2dc: ldur            x0, [fp, #-8]
    // 0xd1e2e0: LoadField: r2 = r0->field_b
    //     0xd1e2e0: ldur            w2, [x0, #0xb]
    // 0xd1e2e4: DecompressPointer r2
    //     0xd1e2e4: add             x2, x2, HEAP, lsl #32
    // 0xd1e2e8: cmp             w2, NULL
    // 0xd1e2ec: b.eq            #0xd1e320
    // 0xd1e2f0: LoadField: d1 = r1->field_7
    //     0xd1e2f0: ldur            d1, [x1, #7]
    // 0xd1e2f4: d2 = 24.000000
    //     0xd1e2f4: fmov            d2, #24.00000000
    // 0xd1e2f8: fmax            v0.2d, v1.2d, v2.2d
    // 0xd1e2fc: LeaveFrame
    //     0xd1e2fc: mov             SP, fp
    //     0xd1e300: ldp             fp, lr, [SP], #0x10
    // 0xd1e304: ret
    //     0xd1e304: ret             
    // 0xd1e308: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1e308: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd1e30c: b               #0xd1e1bc
    // 0xd1e310: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1e310: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1e314: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1e314: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1e318: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1e318: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1e31c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xd1e31c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xd1e320: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1e320: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _iconColor(/* No info */) {
    // ** addr: 0xd1e324, size: 0xf8
    // 0xd1e324: EnterFrame
    //     0xd1e324: stp             fp, lr, [SP, #-0x10]!
    //     0xd1e328: mov             fp, SP
    // 0xd1e32c: AllocStack(0x10)
    //     0xd1e32c: sub             SP, SP, #0x10
    // 0xd1e330: SetupParameters(_DropdownButtonState<C1X0> this /* r1 => r0, fp-0x8 */)
    //     0xd1e330: mov             x0, x1
    //     0xd1e334: stur            x1, [fp, #-8]
    // 0xd1e338: CheckStackOverflow
    //     0xd1e338: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd1e33c: cmp             SP, x16
    //     0xd1e340: b.ls            #0xd1e404
    // 0xd1e344: LoadField: r1 = r0->field_f
    //     0xd1e344: ldur            w1, [x0, #0xf]
    // 0xd1e348: DecompressPointer r1
    //     0xd1e348: add             x1, x1, HEAP, lsl #32
    // 0xd1e34c: cmp             w1, NULL
    // 0xd1e350: b.eq            #0xd1e40c
    // 0xd1e354: r0 = brightnessOf()
    //     0xd1e354: bl              #0xd1e4dc  ; [package:flutter/src/material/theme.dart] Theme::brightnessOf
    // 0xd1e358: ldur            x1, [fp, #-8]
    // 0xd1e35c: stur            x0, [fp, #-0x10]
    // 0xd1e360: r0 = _enabled()
    //     0xd1e360: bl              #0xd1e854  ; [package:flutter/src/material/dropdown.dart] _DropdownButtonState::_enabled
    // 0xd1e364: tbnz            w0, #4, #0xd1e3b0
    // 0xd1e368: ldur            x1, [fp, #-8]
    // 0xd1e36c: ldur            x0, [fp, #-0x10]
    // 0xd1e370: LoadField: r2 = r1->field_b
    //     0xd1e370: ldur            w2, [x1, #0xb]
    // 0xd1e374: DecompressPointer r2
    //     0xd1e374: add             x2, x2, HEAP, lsl #32
    // 0xd1e378: cmp             w2, NULL
    // 0xd1e37c: b.eq            #0xd1e410
    // 0xd1e380: LoadField: r1 = r0->field_7
    //     0xd1e380: ldur            x1, [x0, #7]
    // 0xd1e384: cmp             x1, #0
    // 0xd1e388: b.gt            #0xd1e398
    // 0xd1e38c: r0 = Instance_Color
    //     0xd1e38c: add             x0, PP, #0x12, lsl #12  ; [pp+0x12c70] Obj!Color@12a1771
    //     0xd1e390: ldr             x0, [x0, #0xc70]
    // 0xd1e394: b               #0xd1e3a4
    // 0xd1e398: r1 = Instance_MaterialColor
    //     0xd1e398: add             x1, PP, #0x16, lsl #12  ; [pp+0x16d48] Obj!MaterialColor@12a6e71
    //     0xd1e39c: ldr             x1, [x1, #0xd48]
    // 0xd1e3a0: r0 = shade700()
    //     0xd1e3a0: bl              #0xd1e47c  ; [package:flutter/src/material/colors.dart] MaterialColor::shade700
    // 0xd1e3a4: LeaveFrame
    //     0xd1e3a4: mov             SP, fp
    //     0xd1e3a8: ldp             fp, lr, [SP], #0x10
    // 0xd1e3ac: ret
    //     0xd1e3ac: ret             
    // 0xd1e3b0: ldur            x1, [fp, #-8]
    // 0xd1e3b4: ldur            x0, [fp, #-0x10]
    // 0xd1e3b8: LoadField: r2 = r1->field_b
    //     0xd1e3b8: ldur            w2, [x1, #0xb]
    // 0xd1e3bc: DecompressPointer r2
    //     0xd1e3bc: add             x2, x2, HEAP, lsl #32
    // 0xd1e3c0: cmp             w2, NULL
    // 0xd1e3c4: b.eq            #0xd1e414
    // 0xd1e3c8: LoadField: r1 = r0->field_7
    //     0xd1e3c8: ldur            x1, [x0, #7]
    // 0xd1e3cc: cmp             x1, #0
    // 0xd1e3d0: b.gt            #0xd1e3e0
    // 0xd1e3d4: r0 = Instance_Color
    //     0xd1e3d4: add             x0, PP, #0x26, lsl #12  ; [pp+0x261d8] Obj!Color@12a2b81
    //     0xd1e3d8: ldr             x0, [x0, #0x1d8]
    // 0xd1e3dc: b               #0xd1e3f8
    // 0xd1e3e0: r1 = _ConstMap len:12
    //     0xd1e3e0: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c20] Map<int, Color>(12)
    //     0xd1e3e4: ldr             x1, [x1, #0xc20]
    // 0xd1e3e8: r2 = 800
    //     0xd1e3e8: mov             x2, #0x320
    // 0xd1e3ec: r0 = []()
    //     0xd1e3ec: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0xd1e3f0: cmp             w0, NULL
    // 0xd1e3f4: b.eq            #0xd1e418
    // 0xd1e3f8: LeaveFrame
    //     0xd1e3f8: mov             SP, fp
    //     0xd1e3fc: ldp             fp, lr, [SP], #0x10
    // 0xd1e400: ret
    //     0xd1e400: ret             
    // 0xd1e404: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1e404: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd1e408: b               #0xd1e344
    // 0xd1e40c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1e40c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1e410: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1e410: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1e414: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1e414: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1e418: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1e418: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _textStyle(/* No info */) {
    // ** addr: 0xd1e7d0, size: 0x84
    // 0xd1e7d0: EnterFrame
    //     0xd1e7d0: stp             fp, lr, [SP, #-0x10]!
    //     0xd1e7d4: mov             fp, SP
    // 0xd1e7d8: CheckStackOverflow
    //     0xd1e7d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd1e7dc: cmp             SP, x16
    //     0xd1e7e0: b.ls            #0xd1e844
    // 0xd1e7e4: LoadField: r0 = r1->field_b
    //     0xd1e7e4: ldur            w0, [x1, #0xb]
    // 0xd1e7e8: DecompressPointer r0
    //     0xd1e7e8: add             x0, x0, HEAP, lsl #32
    // 0xd1e7ec: cmp             w0, NULL
    // 0xd1e7f0: b.eq            #0xd1e84c
    // 0xd1e7f4: LoadField: r2 = r0->field_33
    //     0xd1e7f4: ldur            w2, [x0, #0x33]
    // 0xd1e7f8: DecompressPointer r2
    //     0xd1e7f8: add             x2, x2, HEAP, lsl #32
    // 0xd1e7fc: cmp             w2, NULL
    // 0xd1e800: b.ne            #0xd1e834
    // 0xd1e804: LoadField: r0 = r1->field_f
    //     0xd1e804: ldur            w0, [x1, #0xf]
    // 0xd1e808: DecompressPointer r0
    //     0xd1e808: add             x0, x0, HEAP, lsl #32
    // 0xd1e80c: cmp             w0, NULL
    // 0xd1e810: b.eq            #0xd1e850
    // 0xd1e814: mov             x1, x0
    // 0xd1e818: r0 = of()
    //     0xd1e818: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd1e81c: LoadField: r1 = r0->field_87
    //     0xd1e81c: ldur            w1, [x0, #0x87]
    // 0xd1e820: DecompressPointer r1
    //     0xd1e820: add             x1, x1, HEAP, lsl #32
    // 0xd1e824: LoadField: r3 = r1->field_23
    //     0xd1e824: ldur            w3, [x1, #0x23]
    // 0xd1e828: DecompressPointer r3
    //     0xd1e828: add             x3, x3, HEAP, lsl #32
    // 0xd1e82c: mov             x0, x3
    // 0xd1e830: b               #0xd1e838
    // 0xd1e834: mov             x0, x2
    // 0xd1e838: LeaveFrame
    //     0xd1e838: mov             SP, fp
    //     0xd1e83c: ldp             fp, lr, [SP], #0x10
    // 0xd1e840: ret
    //     0xd1e840: ret             
    // 0xd1e844: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1e844: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd1e848: b               #0xd1e7e4
    // 0xd1e84c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1e84c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1e850: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1e850: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _enabled(/* No info */) {
    // ** addr: 0xd1e854, size: 0x90
    // 0xd1e854: EnterFrame
    //     0xd1e854: stp             fp, lr, [SP, #-0x10]!
    //     0xd1e858: mov             fp, SP
    // 0xd1e85c: AllocStack(0x8)
    //     0xd1e85c: sub             SP, SP, #8
    // 0xd1e860: LoadField: r0 = r1->field_b
    //     0xd1e860: ldur            w0, [x1, #0xb]
    // 0xd1e864: DecompressPointer r0
    //     0xd1e864: add             x0, x0, HEAP, lsl #32
    // 0xd1e868: cmp             w0, NULL
    // 0xd1e86c: b.eq            #0xd1e8e0
    // 0xd1e870: LoadField: r2 = r0->field_f
    //     0xd1e870: ldur            w2, [x0, #0xf]
    // 0xd1e874: DecompressPointer r2
    //     0xd1e874: add             x2, x2, HEAP, lsl #32
    // 0xd1e878: LoadField: r3 = r2->field_b
    //     0xd1e878: ldur            w3, [x2, #0xb]
    // 0xd1e87c: cbz             w3, #0xd1e8d0
    // 0xd1e880: LoadField: r3 = r0->field_1f
    //     0xd1e880: ldur            w3, [x0, #0x1f]
    // 0xd1e884: DecompressPointer r3
    //     0xd1e884: add             x3, x3, HEAP, lsl #32
    // 0xd1e888: stur            x3, [fp, #-8]
    // 0xd1e88c: LoadField: r2 = r1->field_7
    //     0xd1e88c: ldur            w2, [x1, #7]
    // 0xd1e890: DecompressPointer r2
    //     0xd1e890: add             x2, x2, HEAP, lsl #32
    // 0xd1e894: mov             x0, x3
    // 0xd1e898: r1 = Null
    //     0xd1e898: mov             x1, NULL
    // 0xd1e89c: r8 = ((dynamic this, C1X0?) => void?)?
    //     0xd1e89c: add             x8, PP, #0x28, lsl #12  ; [pp+0x28308] FunctionType: ((dynamic this, C1X0?) => void?)?
    //     0xd1e8a0: ldr             x8, [x8, #0x308]
    // 0xd1e8a4: LoadField: r9 = r8->field_7
    //     0xd1e8a4: ldur            x9, [x8, #7]
    // 0xd1e8a8: r3 = Null
    //     0xd1e8a8: add             x3, PP, #0x99, lsl #12  ; [pp+0x99a10] Null
    //     0xd1e8ac: ldr             x3, [x3, #0xa10]
    // 0xd1e8b0: blr             x9
    // 0xd1e8b4: ldur            x1, [fp, #-8]
    // 0xd1e8b8: cmp             w1, NULL
    // 0xd1e8bc: r16 = true
    //     0xd1e8bc: add             x16, NULL, #0x20  ; true
    // 0xd1e8c0: r17 = false
    //     0xd1e8c0: add             x17, NULL, #0x30  ; false
    // 0xd1e8c4: csel            x2, x16, x17, ne
    // 0xd1e8c8: mov             x0, x2
    // 0xd1e8cc: b               #0xd1e8d4
    // 0xd1e8d0: r0 = false
    //     0xd1e8d0: add             x0, NULL, #0x30  ; false
    // 0xd1e8d4: LeaveFrame
    //     0xd1e8d4: mov             SP, fp
    //     0xd1e8d8: ldp             fp, lr, [SP], #0x10
    // 0xd1e8dc: ret
    //     0xd1e8dc: ret             
    // 0xd1e8e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1e8e0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _removeDropdownRoute(/* No info */) {
    // ** addr: 0xd1e8e4, size: 0x60
    // 0xd1e8e4: EnterFrame
    //     0xd1e8e4: stp             fp, lr, [SP, #-0x10]!
    //     0xd1e8e8: mov             fp, SP
    // 0xd1e8ec: AllocStack(0x8)
    //     0xd1e8ec: sub             SP, SP, #8
    // 0xd1e8f0: SetupParameters(_DropdownButtonState<C1X0> this /* r1 => r0, fp-0x8 */)
    //     0xd1e8f0: mov             x0, x1
    //     0xd1e8f4: stur            x1, [fp, #-8]
    // 0xd1e8f8: CheckStackOverflow
    //     0xd1e8f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd1e8fc: cmp             SP, x16
    //     0xd1e900: b.ls            #0xd1e93c
    // 0xd1e904: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd1e904: ldur            w1, [x0, #0x17]
    // 0xd1e908: DecompressPointer r1
    //     0xd1e908: add             x1, x1, HEAP, lsl #32
    // 0xd1e90c: cmp             w1, NULL
    // 0xd1e910: b.ne            #0xd1e91c
    // 0xd1e914: mov             x1, x0
    // 0xd1e918: b               #0xd1e924
    // 0xd1e91c: r0 = _dismiss()
    //     0xd1e91c: bl              #0xd1e944  ; [package:flutter/src/material/dropdown.dart] _DropdownRoute::_dismiss
    // 0xd1e920: ldur            x1, [fp, #-8]
    // 0xd1e924: ArrayStore: r1[0] = rNULL  ; List_4
    //     0xd1e924: stur            NULL, [x1, #0x17]
    // 0xd1e928: StoreField: r1->field_1b = rNULL
    //     0xd1e928: stur            NULL, [x1, #0x1b]
    // 0xd1e92c: r0 = Null
    //     0xd1e92c: mov             x0, NULL
    // 0xd1e930: LeaveFrame
    //     0xd1e930: mov             SP, fp
    //     0xd1e934: ldp             fp, lr, [SP], #0x10
    // 0xd1e938: ret
    //     0xd1e938: ret             
    // 0xd1e93c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1e93c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd1e940: b               #0xd1e904
  }
  _ _getOrientation(/* No info */) {
    // ** addr: 0xd1eb3c, size: 0x138
    // 0xd1eb3c: EnterFrame
    //     0xd1eb3c: stp             fp, lr, [SP, #-0x10]!
    //     0xd1eb40: mov             fp, SP
    // 0xd1eb44: AllocStack(0x10)
    //     0xd1eb44: sub             SP, SP, #0x10
    // 0xd1eb48: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0xd1eb48: mov             x0, x2
    //     0xd1eb4c: stur            x2, [fp, #-8]
    // 0xd1eb50: CheckStackOverflow
    //     0xd1eb50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd1eb54: cmp             SP, x16
    //     0xd1eb58: b.ls            #0xd1ec6c
    // 0xd1eb5c: mov             x1, x0
    // 0xd1eb60: r0 = maybeOrientationOf()
    //     0xd1eb60: bl              #0xd1ec74  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::maybeOrientationOf
    // 0xd1eb64: cmp             w0, NULL
    // 0xd1eb68: b.ne            #0xd1ec60
    // 0xd1eb6c: ldur            x1, [fp, #-8]
    // 0xd1eb70: r0 = of()
    //     0xd1eb70: bl              #0x864fc4  ; [package:flutter/src/widgets/view.dart] View::of
    // 0xd1eb74: mov             x3, x0
    // 0xd1eb78: stur            x3, [fp, #-0x10]
    // 0xd1eb7c: r0 = LoadClassIdInstr(r3)
    //     0xd1eb7c: ldur            x0, [x3, #-1]
    //     0xd1eb80: ubfx            x0, x0, #0xc, #0x14
    // 0xd1eb84: cmp             x0, #0xe86
    // 0xd1eb88: b.ne            #0xd1eb9c
    // 0xd1eb8c: LoadField: r0 = r3->field_13
    //     0xd1eb8c: ldur            w0, [x3, #0x13]
    // 0xd1eb90: DecompressPointer r0
    //     0xd1eb90: add             x0, x0, HEAP, lsl #32
    // 0xd1eb94: mov             x1, x0
    // 0xd1eb98: b               #0xd1ec30
    // 0xd1eb9c: LoadField: r0 = r3->field_f
    //     0xd1eb9c: ldur            w0, [x3, #0xf]
    // 0xd1eba0: DecompressPointer r0
    //     0xd1eba0: add             x0, x0, HEAP, lsl #32
    // 0xd1eba4: ArrayLoad: r4 = r0[0]  ; List_4
    //     0xd1eba4: ldur            w4, [x0, #0x17]
    // 0xd1eba8: DecompressPointer r4
    //     0xd1eba8: add             x4, x4, HEAP, lsl #32
    // 0xd1ebac: stur            x4, [fp, #-8]
    // 0xd1ebb0: LoadField: r2 = r3->field_7
    //     0xd1ebb0: ldur            x2, [x3, #7]
    // 0xd1ebb4: r0 = BoxInt64Instr(r2)
    //     0xd1ebb4: sbfiz           x0, x2, #1, #0x1f
    //     0xd1ebb8: cmp             x2, x0, asr #1
    //     0xd1ebbc: b.eq            #0xd1ebc8
    //     0xd1ebc0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xd1ebc4: stur            x2, [x0, #7]
    // 0xd1ebc8: mov             x1, x4
    // 0xd1ebcc: mov             x2, x0
    // 0xd1ebd0: r0 = _getValueOrData()
    //     0xd1ebd0: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xd1ebd4: mov             x1, x0
    // 0xd1ebd8: ldur            x0, [fp, #-8]
    // 0xd1ebdc: LoadField: r2 = r0->field_f
    //     0xd1ebdc: ldur            w2, [x0, #0xf]
    // 0xd1ebe0: DecompressPointer r2
    //     0xd1ebe0: add             x2, x2, HEAP, lsl #32
    // 0xd1ebe4: cmp             w2, w1
    // 0xd1ebe8: b.ne            #0xd1ebf0
    // 0xd1ebec: r1 = Null
    //     0xd1ebec: mov             x1, NULL
    // 0xd1ebf0: cmp             w1, NULL
    // 0xd1ebf4: b.ne            #0xd1ec00
    // 0xd1ebf8: r1 = Null
    //     0xd1ebf8: mov             x1, NULL
    // 0xd1ebfc: b               #0xd1ec18
    // 0xd1ec00: r0 = LoadClassIdInstr(r1)
    //     0xd1ec00: ldur            x0, [x1, #-1]
    //     0xd1ec04: ubfx            x0, x0, #0xc, #0x14
    // 0xd1ec08: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd1ec08: sub             lr, x0, #1, lsl #12
    //     0xd1ec0c: ldr             lr, [x21, lr, lsl #3]
    //     0xd1ec10: blr             lr
    // 0xd1ec14: mov             x1, x0
    // 0xd1ec18: cmp             w1, NULL
    // 0xd1ec1c: b.ne            #0xd1ec30
    // 0xd1ec20: ldur            x2, [fp, #-0x10]
    // 0xd1ec24: LoadField: r3 = r2->field_13
    //     0xd1ec24: ldur            w3, [x2, #0x13]
    // 0xd1ec28: DecompressPointer r3
    //     0xd1ec28: add             x3, x3, HEAP, lsl #32
    // 0xd1ec2c: mov             x1, x3
    // 0xd1ec30: LoadField: r2 = r1->field_1b
    //     0xd1ec30: ldur            w2, [x1, #0x1b]
    // 0xd1ec34: DecompressPointer r2
    //     0xd1ec34: add             x2, x2, HEAP, lsl #32
    // 0xd1ec38: LoadField: d0 = r2->field_7
    //     0xd1ec38: ldur            d0, [x2, #7]
    // 0xd1ec3c: LoadField: d1 = r2->field_f
    //     0xd1ec3c: ldur            d1, [x2, #0xf]
    // 0xd1ec40: fcmp            d0, d1
    // 0xd1ec44: b.le            #0xd1ec54
    // 0xd1ec48: r1 = Instance_Orientation
    //     0xd1ec48: add             x1, PP, #0x14, lsl #12  ; [pp+0x143c0] Obj!Orientation@12c2ee1
    //     0xd1ec4c: ldr             x1, [x1, #0x3c0]
    // 0xd1ec50: b               #0xd1ec5c
    // 0xd1ec54: r1 = Instance_Orientation
    //     0xd1ec54: add             x1, PP, #0x14, lsl #12  ; [pp+0x143c8] Obj!Orientation@12c2ec1
    //     0xd1ec58: ldr             x1, [x1, #0x3c8]
    // 0xd1ec5c: mov             x0, x1
    // 0xd1ec60: LeaveFrame
    //     0xd1ec60: mov             SP, fp
    //     0xd1ec64: ldp             fp, lr, [SP], #0x10
    // 0xd1ec68: ret
    //     0xd1ec68: ret             
    // 0xd1ec6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1ec6c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd1ec70: b               #0xd1eb5c
  }
  [closure] void <anonymous closure>(dynamic, PointerExitEvent) {
    // ** addr: 0xd1ecf4, size: 0x6c
    // 0xd1ecf4: EnterFrame
    //     0xd1ecf4: stp             fp, lr, [SP, #-0x10]!
    //     0xd1ecf8: mov             fp, SP
    // 0xd1ecfc: AllocStack(0x8)
    //     0xd1ecfc: sub             SP, SP, #8
    // 0xd1ed00: SetupParameters([dynamic _ /* r0 */])
    //     0xd1ed00: ldr             x0, [fp, #0x18]
    //     0xd1ed04: ldur            w2, [x0, #0x17]
    //     0xd1ed08: add             x2, x2, HEAP, lsl #32
    // 0xd1ed0c: CheckStackOverflow
    //     0xd1ed0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd1ed10: cmp             SP, x16
    //     0xd1ed14: b.ls            #0xd1ed58
    // 0xd1ed18: LoadField: r0 = r2->field_f
    //     0xd1ed18: ldur            w0, [x2, #0xf]
    // 0xd1ed1c: DecompressPointer r0
    //     0xd1ed1c: add             x0, x0, HEAP, lsl #32
    // 0xd1ed20: stur            x0, [fp, #-8]
    // 0xd1ed24: LoadField: r1 = r0->field_27
    //     0xd1ed24: ldur            w1, [x0, #0x27]
    // 0xd1ed28: DecompressPointer r1
    //     0xd1ed28: add             x1, x1, HEAP, lsl #32
    // 0xd1ed2c: tbnz            w1, #4, #0xd1ed48
    // 0xd1ed30: r1 = Function '<anonymous closure>':.
    //     0xd1ed30: add             x1, PP, #0x99, lsl #12  ; [pp+0x99998] AnonymousClosure: (0xd1ed60), in [package:flutter/src/material/dropdown.dart] _DropdownButtonState::build (0xd1b434)
    //     0xd1ed34: ldr             x1, [x1, #0x998]
    // 0xd1ed38: r0 = AllocateClosure()
    //     0xd1ed38: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd1ed3c: ldur            x1, [fp, #-8]
    // 0xd1ed40: mov             x2, x0
    // 0xd1ed44: r0 = setState()
    //     0xd1ed44: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xd1ed48: r0 = Null
    //     0xd1ed48: mov             x0, NULL
    // 0xd1ed4c: LeaveFrame
    //     0xd1ed4c: mov             SP, fp
    //     0xd1ed50: ldp             fp, lr, [SP], #0x10
    // 0xd1ed54: ret
    //     0xd1ed54: ret             
    // 0xd1ed58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1ed58: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd1ed5c: b               #0xd1ed18
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xd1ed60, size: 0x24
    // 0xd1ed60: r1 = false
    //     0xd1ed60: add             x1, NULL, #0x30  ; false
    // 0xd1ed64: ldr             x2, [SP]
    // 0xd1ed68: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xd1ed68: ldur            w3, [x2, #0x17]
    // 0xd1ed6c: DecompressPointer r3
    //     0xd1ed6c: add             x3, x3, HEAP, lsl #32
    // 0xd1ed70: LoadField: r2 = r3->field_f
    //     0xd1ed70: ldur            w2, [x3, #0xf]
    // 0xd1ed74: DecompressPointer r2
    //     0xd1ed74: add             x2, x2, HEAP, lsl #32
    // 0xd1ed78: StoreField: r2->field_27 = r1
    //     0xd1ed78: stur            w1, [x2, #0x27]
    // 0xd1ed7c: r0 = Null
    //     0xd1ed7c: mov             x0, NULL
    // 0xd1ed80: ret
    //     0xd1ed80: ret             
  }
  [closure] void <anonymous closure>(dynamic, PointerEnterEvent) {
    // ** addr: 0xd1ed84, size: 0x6c
    // 0xd1ed84: EnterFrame
    //     0xd1ed84: stp             fp, lr, [SP, #-0x10]!
    //     0xd1ed88: mov             fp, SP
    // 0xd1ed8c: AllocStack(0x8)
    //     0xd1ed8c: sub             SP, SP, #8
    // 0xd1ed90: SetupParameters([dynamic _ /* r0 */])
    //     0xd1ed90: ldr             x0, [fp, #0x18]
    //     0xd1ed94: ldur            w2, [x0, #0x17]
    //     0xd1ed98: add             x2, x2, HEAP, lsl #32
    // 0xd1ed9c: CheckStackOverflow
    //     0xd1ed9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd1eda0: cmp             SP, x16
    //     0xd1eda4: b.ls            #0xd1ede8
    // 0xd1eda8: LoadField: r0 = r2->field_f
    //     0xd1eda8: ldur            w0, [x2, #0xf]
    // 0xd1edac: DecompressPointer r0
    //     0xd1edac: add             x0, x0, HEAP, lsl #32
    // 0xd1edb0: stur            x0, [fp, #-8]
    // 0xd1edb4: LoadField: r1 = r0->field_27
    //     0xd1edb4: ldur            w1, [x0, #0x27]
    // 0xd1edb8: DecompressPointer r1
    //     0xd1edb8: add             x1, x1, HEAP, lsl #32
    // 0xd1edbc: tbz             w1, #4, #0xd1edd8
    // 0xd1edc0: r1 = Function '<anonymous closure>':.
    //     0xd1edc0: add             x1, PP, #0x99, lsl #12  ; [pp+0x999a0] AnonymousClosure: (0xd1edf0), in [package:flutter/src/material/dropdown.dart] _DropdownButtonState::build (0xd1b434)
    //     0xd1edc4: ldr             x1, [x1, #0x9a0]
    // 0xd1edc8: r0 = AllocateClosure()
    //     0xd1edc8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd1edcc: ldur            x1, [fp, #-8]
    // 0xd1edd0: mov             x2, x0
    // 0xd1edd4: r0 = setState()
    //     0xd1edd4: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xd1edd8: r0 = Null
    //     0xd1edd8: mov             x0, NULL
    // 0xd1eddc: LeaveFrame
    //     0xd1eddc: mov             SP, fp
    //     0xd1ede0: ldp             fp, lr, [SP], #0x10
    // 0xd1ede4: ret
    //     0xd1ede4: ret             
    // 0xd1ede8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1ede8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd1edec: b               #0xd1eda8
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xd1edf0, size: 0x24
    // 0xd1edf0: r1 = true
    //     0xd1edf0: add             x1, NULL, #0x20  ; true
    // 0xd1edf4: ldr             x2, [SP]
    // 0xd1edf8: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xd1edf8: ldur            w3, [x2, #0x17]
    // 0xd1edfc: DecompressPointer r3
    //     0xd1edfc: add             x3, x3, HEAP, lsl #32
    // 0xd1ee00: LoadField: r2 = r3->field_f
    //     0xd1ee00: ldur            w2, [x3, #0xf]
    // 0xd1ee04: DecompressPointer r2
    //     0xd1ee04: add             x2, x2, HEAP, lsl #32
    // 0xd1ee08: StoreField: r2->field_27 = r1
    //     0xd1ee08: stur            w1, [x2, #0x27]
    // 0xd1ee0c: r0 = Null
    //     0xd1ee0c: mov             x0, NULL
    // 0xd1ee10: ret
    //     0xd1ee10: ret             
  }
  [closure] void _handleTap(dynamic) {
    // ** addr: 0xd1ee14, size: 0x38
    // 0xd1ee14: EnterFrame
    //     0xd1ee14: stp             fp, lr, [SP, #-0x10]!
    //     0xd1ee18: mov             fp, SP
    // 0xd1ee1c: ldr             x0, [fp, #0x10]
    // 0xd1ee20: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd1ee20: ldur            w1, [x0, #0x17]
    // 0xd1ee24: DecompressPointer r1
    //     0xd1ee24: add             x1, x1, HEAP, lsl #32
    // 0xd1ee28: CheckStackOverflow
    //     0xd1ee28: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd1ee2c: cmp             SP, x16
    //     0xd1ee30: b.ls            #0xd1ee44
    // 0xd1ee34: r0 = _handleTap()
    //     0xd1ee34: bl              #0xd1ee4c  ; [package:flutter/src/material/dropdown.dart] _DropdownButtonState::_handleTap
    // 0xd1ee38: LeaveFrame
    //     0xd1ee38: mov             SP, fp
    //     0xd1ee3c: ldp             fp, lr, [SP], #0x10
    // 0xd1ee40: ret
    //     0xd1ee40: ret             
    // 0xd1ee44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1ee44: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd1ee48: b               #0xd1ee34
  }
  _ _handleTap(/* No info */) {
    // ** addr: 0xd1ee4c, size: 0x614
    // 0xd1ee4c: EnterFrame
    //     0xd1ee4c: stp             fp, lr, [SP, #-0x10]!
    //     0xd1ee50: mov             fp, SP
    // 0xd1ee54: AllocStack(0x90)
    //     0xd1ee54: sub             SP, SP, #0x90
    // 0xd1ee58: SetupParameters(_DropdownButtonState<C1X0> this /* r1 => r1, fp-0x8 */)
    //     0xd1ee58: stur            x1, [fp, #-8]
    // 0xd1ee5c: CheckStackOverflow
    //     0xd1ee5c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd1ee60: cmp             SP, x16
    //     0xd1ee64: b.ls            #0xd1f40c
    // 0xd1ee68: r1 = 1
    //     0xd1ee68: mov             x1, #1
    // 0xd1ee6c: r0 = AllocateContext()
    //     0xd1ee6c: bl              #0x13de838  ; AllocateContextStub
    // 0xd1ee70: mov             x2, x0
    // 0xd1ee74: ldur            x0, [fp, #-8]
    // 0xd1ee78: stur            x2, [fp, #-0x10]
    // 0xd1ee7c: StoreField: r2->field_f = r0
    //     0xd1ee7c: stur            w0, [x2, #0xf]
    // 0xd1ee80: LoadField: r1 = r0->field_f
    //     0xd1ee80: ldur            w1, [x0, #0xf]
    // 0xd1ee84: DecompressPointer r1
    //     0xd1ee84: add             x1, x1, HEAP, lsl #32
    // 0xd1ee88: cmp             w1, NULL
    // 0xd1ee8c: b.eq            #0xd1f414
    // 0xd1ee90: r0 = maybeOf()
    //     0xd1ee90: bl              #0xcee820  ; [package:flutter/src/widgets/basic.dart] Directionality::maybeOf
    // 0xd1ee94: mov             x2, x0
    // 0xd1ee98: ldur            x0, [fp, #-8]
    // 0xd1ee9c: stur            x2, [fp, #-0x18]
    // 0xd1eea0: LoadField: r1 = r0->field_f
    //     0xd1eea0: ldur            w1, [x0, #0xf]
    // 0xd1eea4: DecompressPointer r1
    //     0xd1eea4: add             x1, x1, HEAP, lsl #32
    // 0xd1eea8: cmp             w1, NULL
    // 0xd1eeac: b.eq            #0xd1f418
    // 0xd1eeb0: r0 = of()
    //     0xd1eeb0: bl              #0xd1e5a4  ; [package:flutter/src/material/button_theme.dart] ButtonTheme::of
    // 0xd1eeb4: ldur            x0, [fp, #-8]
    // 0xd1eeb8: LoadField: r4 = r0->field_7
    //     0xd1eeb8: ldur            w4, [x0, #7]
    // 0xd1eebc: DecompressPointer r4
    //     0xd1eebc: add             x4, x4, HEAP, lsl #32
    // 0xd1eec0: mov             x2, x4
    // 0xd1eec4: stur            x4, [fp, #-0x20]
    // 0xd1eec8: r1 = Null
    //     0xd1eec8: mov             x1, NULL
    // 0xd1eecc: r3 = <_MenuItem<C1X0>>
    //     0xd1eecc: add             x3, PP, #0x99, lsl #12  ; [pp+0x999a8] TypeArguments: <_MenuItem<C1X0>>
    //     0xd1eed0: ldr             x3, [x3, #0x9a8]
    // 0xd1eed4: r30 = InstantiateTypeArgumentsStub
    //     0xd1eed4: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0xd1eed8: LoadField: r30 = r30->field_7
    //     0xd1eed8: ldur            lr, [lr, #7]
    // 0xd1eedc: blr             lr
    // 0xd1eee0: mov             x1, x0
    // 0xd1eee4: r2 = 0
    //     0xd1eee4: mov             x2, #0
    // 0xd1eee8: r0 = _GrowableList()
    //     0xd1eee8: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xd1eeec: stur            x0, [fp, #-0x28]
    // 0xd1eef0: r1 = 1
    //     0xd1eef0: mov             x1, #1
    // 0xd1eef4: r0 = AllocateContext()
    //     0xd1eef4: bl              #0x13de838  ; AllocateContextStub
    // 0xd1eef8: mov             x1, x0
    // 0xd1eefc: ldur            x0, [fp, #-0x10]
    // 0xd1ef00: StoreField: r1->field_b = r0
    //     0xd1ef00: stur            w0, [x1, #0xb]
    // 0xd1ef04: StoreField: r1->field_f = rZR
    //     0xd1ef04: stur            wzr, [x1, #0xf]
    // 0xd1ef08: mov             x6, x1
    // 0xd1ef0c: r2 = 0
    //     0xd1ef0c: mov             x2, #0
    // 0xd1ef10: ldur            x5, [fp, #-8]
    // 0xd1ef14: ldur            x4, [fp, #-0x28]
    // 0xd1ef18: stur            x6, [fp, #-0x30]
    // 0xd1ef1c: CheckStackOverflow
    //     0xd1ef1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd1ef20: cmp             SP, x16
    //     0xd1ef24: b.ls            #0xd1f41c
    // 0xd1ef28: LoadField: r0 = r5->field_b
    //     0xd1ef28: ldur            w0, [x5, #0xb]
    // 0xd1ef2c: DecompressPointer r0
    //     0xd1ef2c: add             x0, x0, HEAP, lsl #32
    // 0xd1ef30: cmp             w0, NULL
    // 0xd1ef34: b.eq            #0xd1f424
    // 0xd1ef38: LoadField: r3 = r0->field_f
    //     0xd1ef38: ldur            w3, [x0, #0xf]
    // 0xd1ef3c: DecompressPointer r3
    //     0xd1ef3c: add             x3, x3, HEAP, lsl #32
    // 0xd1ef40: LoadField: r0 = r3->field_b
    //     0xd1ef40: ldur            w0, [x3, #0xb]
    // 0xd1ef44: r1 = LoadInt32Instr(r0)
    //     0xd1ef44: sbfx            x1, x0, #1, #0x1f
    // 0xd1ef48: cmp             x2, x1
    // 0xd1ef4c: b.ge            #0xd1f0b4
    // 0xd1ef50: mov             x0, x1
    // 0xd1ef54: mov             x1, x2
    // 0xd1ef58: cmp             x1, x0
    // 0xd1ef5c: b.hs            #0xd1f428
    // 0xd1ef60: LoadField: r0 = r3->field_f
    //     0xd1ef60: ldur            w0, [x3, #0xf]
    // 0xd1ef64: DecompressPointer r0
    //     0xd1ef64: add             x0, x0, HEAP, lsl #32
    // 0xd1ef68: ArrayLoad: r7 = r0[r2]  ; Unknown_4
    //     0xd1ef68: add             x16, x0, x2, lsl #2
    //     0xd1ef6c: ldur            w7, [x16, #0xf]
    // 0xd1ef70: DecompressPointer r7
    //     0xd1ef70: add             x7, x7, HEAP, lsl #32
    // 0xd1ef74: ldur            x2, [fp, #-0x20]
    // 0xd1ef78: stur            x7, [fp, #-0x10]
    // 0xd1ef7c: r1 = Null
    //     0xd1ef7c: mov             x1, NULL
    // 0xd1ef80: r3 = <C1X0>
    //     0xd1ef80: add             x3, PP, #0x11, lsl #12  ; [pp+0x11880] TypeArguments: <C1X0>
    //     0xd1ef84: ldr             x3, [x3, #0x880]
    // 0xd1ef88: r0 = Null
    //     0xd1ef88: mov             x0, NULL
    // 0xd1ef8c: cmp             x2, x0
    // 0xd1ef90: b.eq            #0xd1efa0
    // 0xd1ef94: r30 = InstantiateTypeArgumentsStub
    //     0xd1ef94: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0xd1ef98: LoadField: r30 = r30->field_7
    //     0xd1ef98: ldur            lr, [lr, #7]
    // 0xd1ef9c: blr             lr
    // 0xd1efa0: ldur            x2, [fp, #-0x30]
    // 0xd1efa4: r1 = Function '<anonymous closure>':.
    //     0xd1efa4: add             x1, PP, #0x99, lsl #12  ; [pp+0x999b0] AnonymousClosure: (0xd1f884), in [package:flutter/src/material/dropdown.dart] _DropdownButtonState::_handleTap (0xd1ee4c)
    //     0xd1efa8: ldr             x1, [x1, #0x9b0]
    // 0xd1efac: stur            x0, [fp, #-0x38]
    // 0xd1efb0: r0 = AllocateClosure()
    //     0xd1efb0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd1efb4: ldur            x1, [fp, #-0x38]
    // 0xd1efb8: stur            x0, [fp, #-0x38]
    // 0xd1efbc: r0 = _MenuItem()
    //     0xd1efbc: bl              #0xd1f700  ; Allocate_MenuItemStub -> _MenuItem<X0> (size=0x1c)
    // 0xd1efc0: mov             x2, x0
    // 0xd1efc4: ldur            x0, [fp, #-0x38]
    // 0xd1efc8: stur            x2, [fp, #-0x48]
    // 0xd1efcc: StoreField: r2->field_13 = r0
    //     0xd1efcc: stur            w0, [x2, #0x13]
    // 0xd1efd0: ldur            x0, [fp, #-0x10]
    // 0xd1efd4: ArrayStore: r2[0] = r0  ; List_4
    //     0xd1efd4: stur            w0, [x2, #0x17]
    // 0xd1efd8: StoreField: r2->field_b = r0
    //     0xd1efd8: stur            w0, [x2, #0xb]
    // 0xd1efdc: ldur            x0, [fp, #-0x28]
    // 0xd1efe0: LoadField: r1 = r0->field_b
    //     0xd1efe0: ldur            w1, [x0, #0xb]
    // 0xd1efe4: LoadField: r3 = r0->field_f
    //     0xd1efe4: ldur            w3, [x0, #0xf]
    // 0xd1efe8: DecompressPointer r3
    //     0xd1efe8: add             x3, x3, HEAP, lsl #32
    // 0xd1efec: LoadField: r4 = r3->field_b
    //     0xd1efec: ldur            w4, [x3, #0xb]
    // 0xd1eff0: r3 = LoadInt32Instr(r1)
    //     0xd1eff0: sbfx            x3, x1, #1, #0x1f
    // 0xd1eff4: stur            x3, [fp, #-0x40]
    // 0xd1eff8: r1 = LoadInt32Instr(r4)
    //     0xd1eff8: sbfx            x1, x4, #1, #0x1f
    // 0xd1effc: cmp             x3, x1
    // 0xd1f000: b.ne            #0xd1f00c
    // 0xd1f004: mov             x1, x0
    // 0xd1f008: r0 = _growToNextCapacity()
    //     0xd1f008: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xd1f00c: ldur            x2, [fp, #-0x28]
    // 0xd1f010: ldur            x3, [fp, #-0x40]
    // 0xd1f014: add             x0, x3, #1
    // 0xd1f018: lsl             x1, x0, #1
    // 0xd1f01c: StoreField: r2->field_b = r1
    //     0xd1f01c: stur            w1, [x2, #0xb]
    // 0xd1f020: LoadField: r1 = r2->field_f
    //     0xd1f020: ldur            w1, [x2, #0xf]
    // 0xd1f024: DecompressPointer r1
    //     0xd1f024: add             x1, x1, HEAP, lsl #32
    // 0xd1f028: ldur            x0, [fp, #-0x48]
    // 0xd1f02c: ArrayStore: r1[r3] = r0  ; List_4
    //     0xd1f02c: add             x25, x1, x3, lsl #2
    //     0xd1f030: add             x25, x25, #0xf
    //     0xd1f034: str             w0, [x25]
    //     0xd1f038: tbz             w0, #0, #0xd1f054
    //     0xd1f03c: ldurb           w16, [x1, #-1]
    //     0xd1f040: ldurb           w17, [x0, #-1]
    //     0xd1f044: and             x16, x17, x16, lsr #2
    //     0xd1f048: tst             x16, HEAP, lsr #32
    //     0xd1f04c: b.eq            #0xd1f054
    //     0xd1f050: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd1f054: ldur            x5, [fp, #-0x30]
    // 0xd1f058: r0 = CloneContext()
    //     0xd1f058: bl              #0x13de1f4  ; CloneContextStub
    // 0xd1f05c: mov             x3, x0
    // 0xd1f060: LoadField: r0 = r3->field_f
    //     0xd1f060: ldur            w0, [x3, #0xf]
    // 0xd1f064: DecompressPointer r0
    //     0xd1f064: add             x0, x0, HEAP, lsl #32
    // 0xd1f068: r1 = LoadInt32Instr(r0)
    //     0xd1f068: sbfx            x1, x0, #1, #0x1f
    //     0xd1f06c: tbz             w0, #0, #0xd1f074
    //     0xd1f070: ldur            x1, [x0, #7]
    // 0xd1f074: add             x2, x1, #1
    // 0xd1f078: r0 = BoxInt64Instr(r2)
    //     0xd1f078: sbfiz           x0, x2, #1, #0x1f
    //     0xd1f07c: cmp             x2, x0, asr #1
    //     0xd1f080: b.eq            #0xd1f08c
    //     0xd1f084: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xd1f088: stur            x2, [x0, #7]
    // 0xd1f08c: StoreField: r3->field_f = r0
    //     0xd1f08c: stur            w0, [x3, #0xf]
    //     0xd1f090: tbz             w0, #0, #0xd1f0ac
    //     0xd1f094: ldurb           w16, [x3, #-1]
    //     0xd1f098: ldurb           w17, [x0, #-1]
    //     0xd1f09c: and             x16, x17, x16, lsr #2
    //     0xd1f0a0: tst             x16, HEAP, lsr #32
    //     0xd1f0a4: b.eq            #0xd1f0ac
    //     0xd1f0a8: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xd1f0ac: mov             x6, x3
    // 0xd1f0b0: b               #0xd1ef10
    // 0xd1f0b4: mov             x0, x5
    // 0xd1f0b8: mov             x1, x6
    // 0xd1f0bc: LoadField: r2 = r1->field_b
    //     0xd1f0bc: ldur            w2, [x1, #0xb]
    // 0xd1f0c0: DecompressPointer r2
    //     0xd1f0c0: add             x2, x2, HEAP, lsl #32
    // 0xd1f0c4: stur            x2, [fp, #-0x10]
    // 0xd1f0c8: LoadField: r1 = r0->field_f
    //     0xd1f0c8: ldur            w1, [x0, #0xf]
    // 0xd1f0cc: DecompressPointer r1
    //     0xd1f0cc: add             x1, x1, HEAP, lsl #32
    // 0xd1f0d0: cmp             w1, NULL
    // 0xd1f0d4: b.eq            #0xd1f42c
    // 0xd1f0d8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd1f0d8: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd1f0dc: r0 = of()
    //     0xd1f0dc: bl              #0xb35e68  ; [package:flutter/src/widgets/navigator.dart] Navigator::of
    // 0xd1f0e0: mov             x2, x0
    // 0xd1f0e4: ldur            x0, [fp, #-8]
    // 0xd1f0e8: stur            x2, [fp, #-0x30]
    // 0xd1f0ec: LoadField: r1 = r0->field_f
    //     0xd1f0ec: ldur            w1, [x0, #0xf]
    // 0xd1f0f0: DecompressPointer r1
    //     0xd1f0f0: add             x1, x1, HEAP, lsl #32
    // 0xd1f0f4: cmp             w1, NULL
    // 0xd1f0f8: b.eq            #0xd1f430
    // 0xd1f0fc: r0 = renderObject()
    //     0xd1f0fc: bl              #0x123f10c  ; [package:flutter/src/widgets/framework.dart] Element::renderObject
    // 0xd1f100: mov             x3, x0
    // 0xd1f104: stur            x3, [fp, #-0x38]
    // 0xd1f108: cmp             w3, NULL
    // 0xd1f10c: b.eq            #0xd1f434
    // 0xd1f110: mov             x0, x3
    // 0xd1f114: r2 = Null
    //     0xd1f114: mov             x2, NULL
    // 0xd1f118: r1 = Null
    //     0xd1f118: mov             x1, NULL
    // 0xd1f11c: r4 = LoadClassIdInstr(r0)
    //     0xd1f11c: ldur            x4, [x0, #-1]
    //     0xd1f120: ubfx            x4, x4, #0xc, #0x14
    // 0xd1f124: r17 = -4710
    //     0xd1f124: mov             x17, #-0x1266
    // 0xd1f128: add             x4, x4, x17
    // 0xd1f12c: cmp             x4, #0x109
    // 0xd1f130: b.ls            #0xd1f144
    // 0xd1f134: r8 = RenderBox
    //     0xd1f134: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0xd1f138: r3 = Null
    //     0xd1f138: add             x3, PP, #0x99, lsl #12  ; [pp+0x999b8] Null
    //     0xd1f13c: ldr             x3, [x3, #0x9b8]
    // 0xd1f140: r0 = RenderBox()
    //     0xd1f140: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0xd1f144: ldur            x0, [fp, #-0x30]
    // 0xd1f148: LoadField: r1 = r0->field_f
    //     0xd1f148: ldur            w1, [x0, #0xf]
    // 0xd1f14c: DecompressPointer r1
    //     0xd1f14c: add             x1, x1, HEAP, lsl #32
    // 0xd1f150: cmp             w1, NULL
    // 0xd1f154: b.eq            #0xd1f438
    // 0xd1f158: r0 = renderObject()
    //     0xd1f158: bl              #0x123f10c  ; [package:flutter/src/widgets/framework.dart] Element::renderObject
    // 0xd1f15c: str             x0, [SP]
    // 0xd1f160: ldur            x1, [fp, #-0x38]
    // 0xd1f164: r2 = Instance_Offset
    //     0xd1f164: ldr             x2, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xd1f168: r4 = const [0, 0x3, 0x1, 0x2, ancestor, 0x2, null]
    //     0xd1f168: add             x4, PP, #0x8c, lsl #12  ; [pp+0x8caa8] List(7) [0, 0x3, 0x1, 0x2, "ancestor", 0x2, Null]
    //     0xd1f16c: ldr             x4, [x4, #0xaa8]
    // 0xd1f170: r0 = localToGlobal()
    //     0xd1f170: bl              #0x856eb0  ; [package:flutter/src/rendering/box.dart] RenderBox::localToGlobal
    // 0xd1f174: ldur            x1, [fp, #-0x38]
    // 0xd1f178: stur            x0, [fp, #-0x38]
    // 0xd1f17c: r0 = size()
    //     0xd1f17c: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xd1f180: ldur            x1, [fp, #-0x38]
    // 0xd1f184: mov             x2, x0
    // 0xd1f188: r0 = &()
    //     0xd1f188: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xd1f18c: ldur            x2, [fp, #-0x18]
    // 0xd1f190: r1 = Instance_EdgeInsetsDirectional
    //     0xd1f190: add             x1, PP, #0x84, lsl #12  ; [pp+0x84a00] Obj!EdgeInsetsDirectional@129c841
    //     0xd1f194: ldr             x1, [x1, #0xa00]
    // 0xd1f198: stur            x0, [fp, #-0x18]
    // 0xd1f19c: r0 = resolve()
    //     0xd1f19c: bl              #0x1304ae0  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsDirectional::resolve
    // 0xd1f1a0: mov             x1, x0
    // 0xd1f1a4: ldur            x2, [fp, #-0x18]
    // 0xd1f1a8: r0 = inflateRect()
    //     0xd1f1a8: bl              #0x8685c4  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::inflateRect
    // 0xd1f1ac: mov             x3, x0
    // 0xd1f1b0: ldur            x0, [fp, #-8]
    // 0xd1f1b4: stur            x3, [fp, #-0x18]
    // 0xd1f1b8: LoadField: r1 = r0->field_13
    //     0xd1f1b8: ldur            w1, [x0, #0x13]
    // 0xd1f1bc: DecompressPointer r1
    //     0xd1f1bc: add             x1, x1, HEAP, lsl #32
    // 0xd1f1c0: cmp             w1, NULL
    // 0xd1f1c4: b.ne            #0xd1f1d0
    // 0xd1f1c8: r5 = 0
    //     0xd1f1c8: mov             x5, #0
    // 0xd1f1cc: b               #0xd1f1e0
    // 0xd1f1d0: r2 = LoadInt32Instr(r1)
    //     0xd1f1d0: sbfx            x2, x1, #1, #0x1f
    //     0xd1f1d4: tbz             w1, #0, #0xd1f1dc
    //     0xd1f1d8: ldur            x2, [x1, #7]
    // 0xd1f1dc: mov             x5, x2
    // 0xd1f1e0: ldur            x4, [fp, #-0x30]
    // 0xd1f1e4: stur            x5, [fp, #-0x40]
    // 0xd1f1e8: LoadField: r1 = r0->field_b
    //     0xd1f1e8: ldur            w1, [x0, #0xb]
    // 0xd1f1ec: DecompressPointer r1
    //     0xd1f1ec: add             x1, x1, HEAP, lsl #32
    // 0xd1f1f0: cmp             w1, NULL
    // 0xd1f1f4: b.eq            #0xd1f43c
    // 0xd1f1f8: LoadField: r1 = r0->field_f
    //     0xd1f1f8: ldur            w1, [x0, #0xf]
    // 0xd1f1fc: DecompressPointer r1
    //     0xd1f1fc: add             x1, x1, HEAP, lsl #32
    // 0xd1f200: cmp             w1, NULL
    // 0xd1f204: b.eq            #0xd1f440
    // 0xd1f208: LoadField: r2 = r4->field_f
    //     0xd1f208: ldur            w2, [x4, #0xf]
    // 0xd1f20c: DecompressPointer r2
    //     0xd1f20c: add             x2, x2, HEAP, lsl #32
    // 0xd1f210: cmp             w2, NULL
    // 0xd1f214: b.eq            #0xd1f444
    // 0xd1f218: r0 = capture()
    //     0xd1f218: bl              #0x8556d4  ; [package:flutter/src/widgets/inherited_theme.dart] InheritedTheme::capture
    // 0xd1f21c: ldur            x1, [fp, #-8]
    // 0xd1f220: stur            x0, [fp, #-0x38]
    // 0xd1f224: r0 = _textStyle()
    //     0xd1f224: bl              #0xd1e7d0  ; [package:flutter/src/material/dropdown.dart] _DropdownButtonState::_textStyle
    // 0xd1f228: mov             x2, x0
    // 0xd1f22c: ldur            x0, [fp, #-8]
    // 0xd1f230: stur            x2, [fp, #-0x48]
    // 0xd1f234: LoadField: r1 = r0->field_f
    //     0xd1f234: ldur            w1, [x0, #0xf]
    // 0xd1f238: DecompressPointer r1
    //     0xd1f238: add             x1, x1, HEAP, lsl #32
    // 0xd1f23c: cmp             w1, NULL
    // 0xd1f240: b.eq            #0xd1f448
    // 0xd1f244: r0 = of()
    //     0xd1f244: bl              #0xd0bbf8  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0xd1f248: r1 = LoadClassIdInstr(r0)
    //     0xd1f248: ldur            x1, [x0, #-1]
    //     0xd1f24c: ubfx            x1, x1, #0xc, #0x14
    // 0xd1f250: mov             x16, x0
    // 0xd1f254: mov             x0, x1
    // 0xd1f258: mov             x1, x16
    // 0xd1f25c: r0 = GDT[cid_x0 + 0x173c8]()
    //     0xd1f25c: mov             x17, #0x73c8
    //     0xd1f260: movk            x17, #1, lsl #16
    //     0xd1f264: add             lr, x0, x17
    //     0xd1f268: ldr             lr, [x21, lr, lsl #3]
    //     0xd1f26c: blr             lr
    // 0xd1f270: mov             x4, x0
    // 0xd1f274: ldur            x0, [fp, #-8]
    // 0xd1f278: stur            x4, [fp, #-0x68]
    // 0xd1f27c: LoadField: r1 = r0->field_b
    //     0xd1f27c: ldur            w1, [x0, #0xb]
    // 0xd1f280: DecompressPointer r1
    //     0xd1f280: add             x1, x1, HEAP, lsl #32
    // 0xd1f284: cmp             w1, NULL
    // 0xd1f288: b.eq            #0xd1f44c
    // 0xd1f28c: LoadField: r7 = r1->field_57
    //     0xd1f28c: ldur            w7, [x1, #0x57]
    // 0xd1f290: DecompressPointer r7
    //     0xd1f290: add             x7, x7, HEAP, lsl #32
    // 0xd1f294: stur            x7, [fp, #-0x60]
    // 0xd1f298: LoadField: r6 = r1->field_6b
    //     0xd1f298: ldur            w6, [x1, #0x6b]
    // 0xd1f29c: DecompressPointer r6
    //     0xd1f29c: add             x6, x6, HEAP, lsl #32
    // 0xd1f2a0: stur            x6, [fp, #-0x58]
    // 0xd1f2a4: LoadField: r5 = r1->field_73
    //     0xd1f2a4: ldur            w5, [x1, #0x73]
    // 0xd1f2a8: DecompressPointer r5
    //     0xd1f2a8: add             x5, x5, HEAP, lsl #32
    // 0xd1f2ac: ldur            x2, [fp, #-0x20]
    // 0xd1f2b0: stur            x5, [fp, #-0x50]
    // 0xd1f2b4: r1 = Null
    //     0xd1f2b4: mov             x1, NULL
    // 0xd1f2b8: r3 = <_DropdownRouteResult<C1X0>, C1X0>
    //     0xd1f2b8: add             x3, PP, #0x99, lsl #12  ; [pp+0x999c8] TypeArguments: <_DropdownRouteResult<C1X0>, C1X0>
    //     0xd1f2bc: ldr             x3, [x3, #0x9c8]
    // 0xd1f2c0: r30 = InstantiateTypeArgumentsStub
    //     0xd1f2c0: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0xd1f2c4: LoadField: r30 = r30->field_7
    //     0xd1f2c4: ldur            lr, [lr, #7]
    // 0xd1f2c8: blr             lr
    // 0xd1f2cc: mov             x1, x0
    // 0xd1f2d0: r0 = _DropdownRoute()
    //     0xd1f2d0: bl              #0xd1f6f4  ; Allocate_DropdownRouteStub -> _DropdownRoute<C1X0> (size=0xe4)
    // 0xd1f2d4: stur            x0, [fp, #-0x70]
    // 0xd1f2d8: ldur            x16, [fp, #-0x28]
    // 0xd1f2dc: ldur            lr, [fp, #-0x50]
    // 0xd1f2e0: stp             lr, x16, [SP, #0x10]
    // 0xd1f2e4: ldur            x1, [fp, #-0x40]
    // 0xd1f2e8: ldur            x16, [fp, #-0x48]
    // 0xd1f2ec: stp             x16, x1, [SP]
    // 0xd1f2f0: mov             x1, x0
    // 0xd1f2f4: ldur            x2, [fp, #-0x68]
    // 0xd1f2f8: ldur            x3, [fp, #-0x18]
    // 0xd1f2fc: ldur            x5, [fp, #-0x38]
    // 0xd1f300: ldur            x6, [fp, #-0x58]
    // 0xd1f304: ldur            x7, [fp, #-0x60]
    // 0xd1f308: r0 = _DropdownRoute()
    //     0xd1f308: bl              #0xd1f460  ; [package:flutter/src/material/dropdown.dart] _DropdownRoute::_DropdownRoute
    // 0xd1f30c: ldur            x0, [fp, #-0x70]
    // 0xd1f310: ldur            x2, [fp, #-8]
    // 0xd1f314: ArrayStore: r2[0] = r0  ; List_4
    //     0xd1f314: stur            w0, [x2, #0x17]
    //     0xd1f318: ldurb           w16, [x2, #-1]
    //     0xd1f31c: ldurb           w17, [x0, #-1]
    //     0xd1f320: and             x16, x17, x16, lsr #2
    //     0xd1f324: tst             x16, HEAP, lsr #32
    //     0xd1f328: b.eq            #0xd1f330
    //     0xd1f32c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd1f330: LoadField: r0 = r2->field_b
    //     0xd1f330: ldur            w0, [x2, #0xb]
    // 0xd1f334: DecompressPointer r0
    //     0xd1f334: add             x0, x0, HEAP, lsl #32
    // 0xd1f338: cmp             w0, NULL
    // 0xd1f33c: b.eq            #0xd1f450
    // 0xd1f340: LoadField: r1 = r2->field_1f
    //     0xd1f340: ldur            w1, [x2, #0x1f]
    // 0xd1f344: DecompressPointer r1
    //     0xd1f344: add             x1, x1, HEAP, lsl #32
    // 0xd1f348: cmp             w1, NULL
    // 0xd1f34c: b.eq            #0xd1f454
    // 0xd1f350: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd1f350: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd1f354: r0 = requestFocus()
    //     0xd1f354: bl              #0x83e7b8  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::requestFocus
    // 0xd1f358: ldur            x2, [fp, #-0x20]
    // 0xd1f35c: r1 = Null
    //     0xd1f35c: mov             x1, NULL
    // 0xd1f360: r3 = <_DropdownRouteResult<C1X0>>
    //     0xd1f360: add             x3, PP, #0x99, lsl #12  ; [pp+0x999d0] TypeArguments: <_DropdownRouteResult<C1X0>>
    //     0xd1f364: ldr             x3, [x3, #0x9d0]
    // 0xd1f368: r30 = InstantiateTypeArgumentsStub
    //     0xd1f368: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0xd1f36c: LoadField: r30 = r30->field_7
    //     0xd1f36c: ldur            lr, [lr, #7]
    // 0xd1f370: blr             lr
    // 0xd1f374: ldur            x1, [fp, #-8]
    // 0xd1f378: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xd1f378: ldur            w2, [x1, #0x17]
    // 0xd1f37c: DecompressPointer r2
    //     0xd1f37c: add             x2, x2, HEAP, lsl #32
    // 0xd1f380: cmp             w2, NULL
    // 0xd1f384: b.eq            #0xd1f458
    // 0xd1f388: ldur            x16, [fp, #-0x30]
    // 0xd1f38c: stp             x16, x0, [SP, #8]
    // 0xd1f390: str             x2, [SP]
    // 0xd1f394: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xd1f394: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xd1f398: r0 = push()
    //     0xd1f398: bl              #0x9ec7a0  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::push
    // 0xd1f39c: ldur            x2, [fp, #-0x10]
    // 0xd1f3a0: ldur            x3, [fp, #-0x20]
    // 0xd1f3a4: r1 = Function '<anonymous closure>':.
    //     0xd1f3a4: add             x1, PP, #0x99, lsl #12  ; [pp+0x999d8] AnonymousClosure: (0xd1f730), in [package:flutter/src/material/dropdown.dart] _DropdownButtonState::_handleTap (0xd1ee4c)
    //     0xd1f3a8: ldr             x1, [x1, #0x9d8]
    // 0xd1f3ac: stur            x0, [fp, #-0x18]
    // 0xd1f3b0: r0 = AllocateClosureTA()
    //     0xd1f3b0: bl              #0x13dea48  ; AllocateClosureTAStub
    // 0xd1f3b4: r16 = <void?>
    //     0xd1f3b4: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xd1f3b8: ldur            lr, [fp, #-0x18]
    // 0xd1f3bc: stp             lr, x16, [SP, #8]
    // 0xd1f3c0: str             x0, [SP]
    // 0xd1f3c4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xd1f3c4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xd1f3c8: r0 = then()
    //     0xd1f3c8: bl              #0x1293070  ; [dart:async] _Future::then
    // 0xd1f3cc: ldur            x0, [fp, #-8]
    // 0xd1f3d0: LoadField: r1 = r0->field_b
    //     0xd1f3d0: ldur            w1, [x0, #0xb]
    // 0xd1f3d4: DecompressPointer r1
    //     0xd1f3d4: add             x1, x1, HEAP, lsl #32
    // 0xd1f3d8: cmp             w1, NULL
    // 0xd1f3dc: b.eq            #0xd1f45c
    // 0xd1f3e0: ldur            x2, [fp, #-0x10]
    // 0xd1f3e4: r1 = Function '<anonymous closure>':.
    //     0xd1f3e4: add             x1, PP, #0x99, lsl #12  ; [pp+0x999e0] AnonymousClosure: (0xd1f70c), in [package:flutter/src/material/dropdown.dart] _DropdownButtonState::_handleTap (0xd1ee4c)
    //     0xd1f3e8: ldr             x1, [x1, #0x9e0]
    // 0xd1f3ec: r0 = AllocateClosure()
    //     0xd1f3ec: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd1f3f0: ldur            x1, [fp, #-8]
    // 0xd1f3f4: mov             x2, x0
    // 0xd1f3f8: r0 = setState()
    //     0xd1f3f8: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xd1f3fc: r0 = Null
    //     0xd1f3fc: mov             x0, NULL
    // 0xd1f400: LeaveFrame
    //     0xd1f400: mov             SP, fp
    //     0xd1f404: ldp             fp, lr, [SP], #0x10
    // 0xd1f408: ret
    //     0xd1f408: ret             
    // 0xd1f40c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1f40c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd1f410: b               #0xd1ee68
    // 0xd1f414: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1f414: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1f418: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1f418: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1f41c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1f41c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd1f420: b               #0xd1ef28
    // 0xd1f424: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1f424: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1f428: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xd1f428: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xd1f42c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1f42c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1f430: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1f430: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1f434: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1f434: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1f438: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1f438: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1f43c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1f43c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1f440: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1f440: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1f444: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1f444: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1f448: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1f448: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1f44c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1f44c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1f450: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1f450: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1f454: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1f454: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1f458: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1f458: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1f45c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1f45c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xd1f70c, size: 0x24
    // 0xd1f70c: r1 = true
    //     0xd1f70c: add             x1, NULL, #0x20  ; true
    // 0xd1f710: ldr             x2, [SP]
    // 0xd1f714: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xd1f714: ldur            w3, [x2, #0x17]
    // 0xd1f718: DecompressPointer r3
    //     0xd1f718: add             x3, x3, HEAP, lsl #32
    // 0xd1f71c: LoadField: r2 = r3->field_f
    //     0xd1f71c: ldur            w2, [x3, #0xf]
    // 0xd1f720: DecompressPointer r2
    //     0xd1f720: add             x2, x2, HEAP, lsl #32
    // 0xd1f724: StoreField: r2->field_2f = r1
    //     0xd1f724: stur            w1, [x2, #0x2f]
    // 0xd1f728: r0 = Null
    //     0xd1f728: mov             x0, NULL
    // 0xd1f72c: ret
    //     0xd1f72c: ret             
  }
  [closure] Null <anonymous closure>(dynamic, _DropdownRouteResult<C1X0>?) {
    // ** addr: 0xd1f730, size: 0x130
    // 0xd1f730: EnterFrame
    //     0xd1f730: stp             fp, lr, [SP, #-0x10]!
    //     0xd1f734: mov             fp, SP
    // 0xd1f738: AllocStack(0x20)
    //     0xd1f738: sub             SP, SP, #0x20
    // 0xd1f73c: SetupParameters([dynamic _ /* r0 */])
    //     0xd1f73c: ldr             x0, [fp, #0x18]
    //     0xd1f740: ldur            w2, [x0, #0x17]
    //     0xd1f744: add             x2, x2, HEAP, lsl #32
    //     0xd1f748: stur            x2, [fp, #-8]
    // 0xd1f74c: CheckStackOverflow
    //     0xd1f74c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd1f750: cmp             SP, x16
    //     0xd1f754: b.ls            #0xd1f854
    // 0xd1f758: LoadField: r1 = r2->field_f
    //     0xd1f758: ldur            w1, [x2, #0xf]
    // 0xd1f75c: DecompressPointer r1
    //     0xd1f75c: add             x1, x1, HEAP, lsl #32
    // 0xd1f760: r0 = _removeDropdownRoute()
    //     0xd1f760: bl              #0xd1e8e4  ; [package:flutter/src/material/dropdown.dart] _DropdownButtonState::_removeDropdownRoute
    // 0xd1f764: ldur            x0, [fp, #-8]
    // 0xd1f768: LoadField: r3 = r0->field_f
    //     0xd1f768: ldur            w3, [x0, #0xf]
    // 0xd1f76c: DecompressPointer r3
    //     0xd1f76c: add             x3, x3, HEAP, lsl #32
    // 0xd1f770: stur            x3, [fp, #-0x10]
    // 0xd1f774: LoadField: r1 = r3->field_f
    //     0xd1f774: ldur            w1, [x3, #0xf]
    // 0xd1f778: DecompressPointer r1
    //     0xd1f778: add             x1, x1, HEAP, lsl #32
    // 0xd1f77c: cmp             w1, NULL
    // 0xd1f780: b.eq            #0xd1f7a0
    // 0xd1f784: mov             x2, x0
    // 0xd1f788: r1 = Function '<anonymous closure>':.
    //     0xd1f788: add             x1, PP, #0x99, lsl #12  ; [pp+0x999e8] AnonymousClosure: (0xd1f860), in [package:flutter/src/material/dropdown.dart] _DropdownButtonState::_handleTap (0xd1ee4c)
    //     0xd1f78c: ldr             x1, [x1, #0x9e8]
    // 0xd1f790: r0 = AllocateClosure()
    //     0xd1f790: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd1f794: ldur            x1, [fp, #-0x10]
    // 0xd1f798: mov             x2, x0
    // 0xd1f79c: r0 = setState()
    //     0xd1f79c: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xd1f7a0: ldur            x0, [fp, #-8]
    // 0xd1f7a4: LoadField: r1 = r0->field_f
    //     0xd1f7a4: ldur            w1, [x0, #0xf]
    // 0xd1f7a8: DecompressPointer r1
    //     0xd1f7a8: add             x1, x1, HEAP, lsl #32
    // 0xd1f7ac: LoadField: r0 = r1->field_f
    //     0xd1f7ac: ldur            w0, [x1, #0xf]
    // 0xd1f7b0: DecompressPointer r0
    //     0xd1f7b0: add             x0, x0, HEAP, lsl #32
    // 0xd1f7b4: cmp             w0, NULL
    // 0xd1f7b8: b.eq            #0xd1f7c8
    // 0xd1f7bc: ldr             x3, [fp, #0x10]
    // 0xd1f7c0: cmp             w3, NULL
    // 0xd1f7c4: b.ne            #0xd1f7d8
    // 0xd1f7c8: r0 = Null
    //     0xd1f7c8: mov             x0, NULL
    // 0xd1f7cc: LeaveFrame
    //     0xd1f7cc: mov             SP, fp
    //     0xd1f7d0: ldp             fp, lr, [SP], #0x10
    // 0xd1f7d4: ret
    //     0xd1f7d4: ret             
    // 0xd1f7d8: LoadField: r0 = r1->field_b
    //     0xd1f7d8: ldur            w0, [x1, #0xb]
    // 0xd1f7dc: DecompressPointer r0
    //     0xd1f7dc: add             x0, x0, HEAP, lsl #32
    // 0xd1f7e0: cmp             w0, NULL
    // 0xd1f7e4: b.eq            #0xd1f85c
    // 0xd1f7e8: LoadField: r4 = r0->field_1f
    //     0xd1f7e8: ldur            w4, [x0, #0x1f]
    // 0xd1f7ec: DecompressPointer r4
    //     0xd1f7ec: add             x4, x4, HEAP, lsl #32
    // 0xd1f7f0: stur            x4, [fp, #-8]
    // 0xd1f7f4: LoadField: r2 = r1->field_7
    //     0xd1f7f4: ldur            w2, [x1, #7]
    // 0xd1f7f8: DecompressPointer r2
    //     0xd1f7f8: add             x2, x2, HEAP, lsl #32
    // 0xd1f7fc: mov             x0, x4
    // 0xd1f800: r1 = Null
    //     0xd1f800: mov             x1, NULL
    // 0xd1f804: r8 = ((dynamic this, C1X0?) => void?)?
    //     0xd1f804: add             x8, PP, #0x28, lsl #12  ; [pp+0x28308] FunctionType: ((dynamic this, C1X0?) => void?)?
    //     0xd1f808: ldr             x8, [x8, #0x308]
    // 0xd1f80c: LoadField: r9 = r8->field_7
    //     0xd1f80c: ldur            x9, [x8, #7]
    // 0xd1f810: r3 = Null
    //     0xd1f810: add             x3, PP, #0x99, lsl #12  ; [pp+0x999f0] Null
    //     0xd1f814: ldr             x3, [x3, #0x9f0]
    // 0xd1f818: blr             x9
    // 0xd1f81c: ldur            x0, [fp, #-8]
    // 0xd1f820: cmp             w0, NULL
    // 0xd1f824: b.eq            #0xd1f844
    // 0xd1f828: ldr             x1, [fp, #0x10]
    // 0xd1f82c: LoadField: r2 = r1->field_b
    //     0xd1f82c: ldur            w2, [x1, #0xb]
    // 0xd1f830: DecompressPointer r2
    //     0xd1f830: add             x2, x2, HEAP, lsl #32
    // 0xd1f834: stp             x2, x0, [SP]
    // 0xd1f838: ClosureCall
    //     0xd1f838: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xd1f83c: ldur            x2, [x0, #0x1f]
    //     0xd1f840: blr             x2
    // 0xd1f844: r0 = Null
    //     0xd1f844: mov             x0, NULL
    // 0xd1f848: LeaveFrame
    //     0xd1f848: mov             SP, fp
    //     0xd1f84c: ldp             fp, lr, [SP], #0x10
    // 0xd1f850: ret
    //     0xd1f850: ret             
    // 0xd1f854: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1f854: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd1f858: b               #0xd1f758
    // 0xd1f85c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1f85c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xd1f860, size: 0x24
    // 0xd1f860: r1 = false
    //     0xd1f860: add             x1, NULL, #0x30  ; false
    // 0xd1f864: ldr             x2, [SP]
    // 0xd1f868: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xd1f868: ldur            w3, [x2, #0x17]
    // 0xd1f86c: DecompressPointer r3
    //     0xd1f86c: add             x3, x3, HEAP, lsl #32
    // 0xd1f870: LoadField: r2 = r3->field_f
    //     0xd1f870: ldur            w2, [x3, #0xf]
    // 0xd1f874: DecompressPointer r2
    //     0xd1f874: add             x2, x2, HEAP, lsl #32
    // 0xd1f878: StoreField: r2->field_2f = r1
    //     0xd1f878: stur            w1, [x2, #0x2f]
    // 0xd1f87c: r0 = Null
    //     0xd1f87c: mov             x0, NULL
    // 0xd1f880: ret
    //     0xd1f880: ret             
  }
  [closure] void <anonymous closure>(dynamic, Size) {
    // ** addr: 0xd1f884, size: 0x100
    // 0xd1f884: EnterFrame
    //     0xd1f884: stp             fp, lr, [SP, #-0x10]!
    //     0xd1f888: mov             fp, SP
    // 0xd1f88c: ldr             x2, [fp, #0x18]
    // 0xd1f890: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xd1f890: ldur            w3, [x2, #0x17]
    // 0xd1f894: DecompressPointer r3
    //     0xd1f894: add             x3, x3, HEAP, lsl #32
    // 0xd1f898: LoadField: r2 = r3->field_b
    //     0xd1f898: ldur            w2, [x3, #0xb]
    // 0xd1f89c: DecompressPointer r2
    //     0xd1f89c: add             x2, x2, HEAP, lsl #32
    // 0xd1f8a0: LoadField: r4 = r2->field_f
    //     0xd1f8a0: ldur            w4, [x2, #0xf]
    // 0xd1f8a4: DecompressPointer r4
    //     0xd1f8a4: add             x4, x4, HEAP, lsl #32
    // 0xd1f8a8: ArrayLoad: r2 = r4[0]  ; List_4
    //     0xd1f8a8: ldur            w2, [x4, #0x17]
    // 0xd1f8ac: DecompressPointer r2
    //     0xd1f8ac: add             x2, x2, HEAP, lsl #32
    // 0xd1f8b0: cmp             w2, NULL
    // 0xd1f8b4: b.ne            #0xd1f8c8
    // 0xd1f8b8: r0 = Null
    //     0xd1f8b8: mov             x0, NULL
    // 0xd1f8bc: LeaveFrame
    //     0xd1f8bc: mov             SP, fp
    //     0xd1f8c0: ldp             fp, lr, [SP], #0x10
    // 0xd1f8c4: ret
    //     0xd1f8c4: ret             
    // 0xd1f8c8: ldr             x4, [fp, #0x10]
    // 0xd1f8cc: LoadField: r5 = r2->field_d7
    //     0xd1f8cc: ldur            w5, [x2, #0xd7]
    // 0xd1f8d0: DecompressPointer r5
    //     0xd1f8d0: add             x5, x5, HEAP, lsl #32
    // 0xd1f8d4: LoadField: r2 = r3->field_f
    //     0xd1f8d4: ldur            w2, [x3, #0xf]
    // 0xd1f8d8: DecompressPointer r2
    //     0xd1f8d8: add             x2, x2, HEAP, lsl #32
    // 0xd1f8dc: LoadField: d0 = r4->field_f
    //     0xd1f8dc: ldur            d0, [x4, #0xf]
    // 0xd1f8e0: LoadField: r3 = r5->field_b
    //     0xd1f8e0: ldur            w3, [x5, #0xb]
    // 0xd1f8e4: r4 = LoadInt32Instr(r2)
    //     0xd1f8e4: sbfx            x4, x2, #1, #0x1f
    //     0xd1f8e8: tbz             w2, #0, #0xd1f8f0
    //     0xd1f8ec: ldur            x4, [x2, #7]
    // 0xd1f8f0: r0 = LoadInt32Instr(r3)
    //     0xd1f8f0: sbfx            x0, x3, #1, #0x1f
    // 0xd1f8f4: mov             x1, x4
    // 0xd1f8f8: cmp             x1, x0
    // 0xd1f8fc: b.hs            #0xd1f968
    // 0xd1f900: r0 = inline_Allocate_Double()
    //     0xd1f900: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xd1f904: add             x0, x0, #0x10
    //     0xd1f908: cmp             x2, x0
    //     0xd1f90c: b.ls            #0xd1f96c
    //     0xd1f910: str             x0, [THR, #0x60]  ; THR::top
    //     0xd1f914: sub             x0, x0, #0xf
    //     0xd1f918: mov             x2, #0xe19c
    //     0xd1f91c: movk            x2, #3, lsl #16
    //     0xd1f920: stur            x2, [x0, #-1]
    // 0xd1f924: dmb             ishst
    // 0xd1f928: StoreField: r0->field_7 = d0
    //     0xd1f928: stur            d0, [x0, #7]
    // 0xd1f92c: mov             x1, x5
    // 0xd1f930: ArrayStore: r1[r4] = r0  ; List_4
    //     0xd1f930: add             x25, x1, x4, lsl #2
    //     0xd1f934: add             x25, x25, #0xf
    //     0xd1f938: str             w0, [x25]
    //     0xd1f93c: tbz             w0, #0, #0xd1f958
    //     0xd1f940: ldurb           w16, [x1, #-1]
    //     0xd1f944: ldurb           w17, [x0, #-1]
    //     0xd1f948: and             x16, x17, x16, lsr #2
    //     0xd1f94c: tst             x16, HEAP, lsr #32
    //     0xd1f950: b.eq            #0xd1f958
    //     0xd1f954: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd1f958: r0 = Null
    //     0xd1f958: mov             x0, NULL
    // 0xd1f95c: LeaveFrame
    //     0xd1f95c: mov             SP, fp
    //     0xd1f960: ldp             fp, lr, [SP], #0x10
    // 0xd1f964: ret
    //     0xd1f964: ret             
    // 0xd1f968: r0 = RangeErrorSharedWithFPURegs()
    //     0xd1f968: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0xd1f96c: SaveReg d0
    //     0xd1f96c: str             q0, [SP, #-0x10]!
    // 0xd1f970: stp             x4, x5, [SP, #-0x10]!
    // 0xd1f974: r0 = AllocateDouble()
    //     0xd1f974: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd1f978: ldp             x4, x5, [SP], #0x10
    // 0xd1f97c: RestoreReg d0
    //     0xd1f97c: ldr             q0, [SP], #0x10
    // 0xd1f980: b               #0xd1f928
  }
  [closure] RenderObjectWidget <anonymous closure>(dynamic, Widget) {
    // ** addr: 0xd1f984, size: 0x110
    // 0xd1f984: EnterFrame
    //     0xd1f984: stp             fp, lr, [SP, #-0x10]!
    //     0xd1f988: mov             fp, SP
    // 0xd1f98c: AllocStack(0x10)
    //     0xd1f98c: sub             SP, SP, #0x10
    // 0xd1f990: SetupParameters([dynamic _ /* r0 */])
    //     0xd1f990: ldr             x0, [fp, #0x18]
    //     0xd1f994: ldur            w1, [x0, #0x17]
    //     0xd1f998: add             x1, x1, HEAP, lsl #32
    // 0xd1f99c: LoadField: r0 = r1->field_f
    //     0xd1f99c: ldur            w0, [x1, #0xf]
    // 0xd1f9a0: DecompressPointer r0
    //     0xd1f9a0: add             x0, x0, HEAP, lsl #32
    // 0xd1f9a4: LoadField: r1 = r0->field_b
    //     0xd1f9a4: ldur            w1, [x0, #0xb]
    // 0xd1f9a8: DecompressPointer r1
    //     0xd1f9a8: add             x1, x1, HEAP, lsl #32
    // 0xd1f9ac: cmp             w1, NULL
    // 0xd1f9b0: b.eq            #0xd1fa90
    // 0xd1f9b4: LoadField: r0 = r1->field_57
    //     0xd1f9b4: ldur            w0, [x1, #0x57]
    // 0xd1f9b8: DecompressPointer r0
    //     0xd1f9b8: add             x0, x0, HEAP, lsl #32
    // 0xd1f9bc: stur            x0, [fp, #-8]
    // 0xd1f9c0: cmp             w0, NULL
    // 0xd1f9c4: b.eq            #0xd1f9ec
    // 0xd1f9c8: ldr             x1, [fp, #0x10]
    // 0xd1f9cc: r0 = SizedBox()
    //     0xd1f9cc: bl              #0x8a7210  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0xd1f9d0: mov             x1, x0
    // 0xd1f9d4: ldur            x0, [fp, #-8]
    // 0xd1f9d8: StoreField: r1->field_13 = r0
    //     0xd1f9d8: stur            w0, [x1, #0x13]
    // 0xd1f9dc: ldr             x0, [fp, #0x10]
    // 0xd1f9e0: StoreField: r1->field_b = r0
    //     0xd1f9e0: stur            w0, [x1, #0xb]
    // 0xd1f9e4: mov             x0, x1
    // 0xd1f9e8: b               #0xd1fa84
    // 0xd1f9ec: ldr             x0, [fp, #0x10]
    // 0xd1f9f0: r3 = 2
    //     0xd1f9f0: mov             x3, #2
    // 0xd1f9f4: mov             x2, x3
    // 0xd1f9f8: r1 = Null
    //     0xd1f9f8: mov             x1, NULL
    // 0xd1f9fc: r0 = AllocateArray()
    //     0xd1f9fc: bl              #0x13df928  ; AllocateArrayStub
    // 0xd1fa00: mov             x2, x0
    // 0xd1fa04: ldr             x0, [fp, #0x10]
    // 0xd1fa08: stur            x2, [fp, #-8]
    // 0xd1fa0c: StoreField: r2->field_f = r0
    //     0xd1fa0c: stur            w0, [x2, #0xf]
    // 0xd1fa10: r1 = <Widget>
    //     0xd1fa10: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xd1fa14: r0 = AllocateGrowableArray()
    //     0xd1fa14: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xd1fa18: mov             x1, x0
    // 0xd1fa1c: ldur            x0, [fp, #-8]
    // 0xd1fa20: stur            x1, [fp, #-0x10]
    // 0xd1fa24: StoreField: r1->field_f = r0
    //     0xd1fa24: stur            w0, [x1, #0xf]
    // 0xd1fa28: r0 = 2
    //     0xd1fa28: mov             x0, #2
    // 0xd1fa2c: StoreField: r1->field_b = r0
    //     0xd1fa2c: stur            w0, [x1, #0xb]
    // 0xd1fa30: r0 = Column()
    //     0xd1fa30: bl              #0x8a5b1c  ; AllocateColumnStub -> Column (size=0x38)
    // 0xd1fa34: r1 = Instance_Axis
    //     0xd1fa34: ldr             x1, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xd1fa38: StoreField: r0->field_f = r1
    //     0xd1fa38: stur            w1, [x0, #0xf]
    // 0xd1fa3c: r1 = Instance_MainAxisAlignment
    //     0xd1fa3c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15820] Obj!MainAxisAlignment@12c4541
    //     0xd1fa40: ldr             x1, [x1, #0x820]
    // 0xd1fa44: StoreField: r0->field_13 = r1
    //     0xd1fa44: stur            w1, [x0, #0x13]
    // 0xd1fa48: r1 = Instance_MainAxisSize
    //     0xd1fa48: add             x1, PP, #0x17, lsl #12  ; [pp+0x17200] Obj!MainAxisSize@12c4601
    //     0xd1fa4c: ldr             x1, [x1, #0x200]
    // 0xd1fa50: ArrayStore: r0[0] = r1  ; List_4
    //     0xd1fa50: stur            w1, [x0, #0x17]
    // 0xd1fa54: r1 = Instance_CrossAxisAlignment
    //     0xd1fa54: add             x1, PP, #0x15, lsl #12  ; [pp+0x15888] Obj!CrossAxisAlignment@12c44a1
    //     0xd1fa58: ldr             x1, [x1, #0x888]
    // 0xd1fa5c: StoreField: r0->field_1b = r1
    //     0xd1fa5c: stur            w1, [x0, #0x1b]
    // 0xd1fa60: r1 = Instance_VerticalDirection
    //     0xd1fa60: add             x1, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xd1fa64: ldr             x1, [x1, #0x838]
    // 0xd1fa68: StoreField: r0->field_23 = r1
    //     0xd1fa68: stur            w1, [x0, #0x23]
    // 0xd1fa6c: r1 = Instance_Clip
    //     0xd1fa6c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xd1fa70: ldr             x1, [x1, #0x840]
    // 0xd1fa74: StoreField: r0->field_2b = r1
    //     0xd1fa74: stur            w1, [x0, #0x2b]
    // 0xd1fa78: StoreField: r0->field_2f = rZR
    //     0xd1fa78: stur            xzr, [x0, #0x2f]
    // 0xd1fa7c: ldur            x1, [fp, #-0x10]
    // 0xd1fa80: StoreField: r0->field_b = r1
    //     0xd1fa80: stur            w1, [x0, #0xb]
    // 0xd1fa84: LeaveFrame
    //     0xd1fa84: mov             SP, fp
    //     0xd1fa88: ldp             fp, lr, [SP], #0x10
    // 0xd1fa8c: ret
    //     0xd1fa8c: ret             
    // 0xd1fa90: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1fa90: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf380dc, size: 0xc0
    // 0xf380dc: EnterFrame
    //     0xf380dc: stp             fp, lr, [SP, #-0x10]!
    //     0xf380e0: mov             fp, SP
    // 0xf380e4: AllocStack(0x18)
    //     0xf380e4: sub             SP, SP, #0x18
    // 0xf380e8: SetupParameters(_DropdownButtonState<C1X0> this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r3, fp-0x18 */)
    //     0xf380e8: mov             x4, x1
    //     0xf380ec: mov             x3, x2
    //     0xf380f0: stur            x1, [fp, #-0x10]
    //     0xf380f4: stur            x2, [fp, #-0x18]
    // 0xf380f8: CheckStackOverflow
    //     0xf380f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf380fc: cmp             SP, x16
    //     0xf38100: b.ls            #0xf38190
    // 0xf38104: LoadField: r5 = r4->field_7
    //     0xf38104: ldur            w5, [x4, #7]
    // 0xf38108: DecompressPointer r5
    //     0xf38108: add             x5, x5, HEAP, lsl #32
    // 0xf3810c: mov             x0, x3
    // 0xf38110: mov             x2, x5
    // 0xf38114: stur            x5, [fp, #-8]
    // 0xf38118: r1 = Null
    //     0xf38118: mov             x1, NULL
    // 0xf3811c: r8 = DropdownButton<C1X0>
    //     0xf3811c: add             x8, PP, #0x99, lsl #12  ; [pp+0x99a30] Type: DropdownButton<C1X0>
    //     0xf38120: ldr             x8, [x8, #0xa30]
    // 0xf38124: LoadField: r9 = r8->field_7
    //     0xf38124: ldur            x9, [x8, #7]
    // 0xf38128: r3 = Null
    //     0xf38128: add             x3, PP, #0x99, lsl #12  ; [pp+0x99a38] Null
    //     0xf3812c: ldr             x3, [x3, #0xa38]
    // 0xf38130: blr             x9
    // 0xf38134: ldur            x0, [fp, #-0x18]
    // 0xf38138: ldur            x2, [fp, #-8]
    // 0xf3813c: r1 = Null
    //     0xf3813c: mov             x1, NULL
    // 0xf38140: cmp             w2, NULL
    // 0xf38144: b.eq            #0xf38168
    // 0xf38148: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf38148: ldur            w4, [x2, #0x17]
    // 0xf3814c: DecompressPointer r4
    //     0xf3814c: add             x4, x4, HEAP, lsl #32
    // 0xf38150: r8 = X0 bound StatefulWidget
    //     0xf38150: add             x8, PP, #0x12, lsl #12  ; [pp+0x12498] TypeParameter: X0 bound StatefulWidget
    //     0xf38154: ldr             x8, [x8, #0x498]
    // 0xf38158: LoadField: r9 = r4->field_7
    //     0xf38158: ldur            x9, [x4, #7]
    // 0xf3815c: r3 = Null
    //     0xf3815c: add             x3, PP, #0x99, lsl #12  ; [pp+0x99a48] Null
    //     0xf38160: ldr             x3, [x3, #0xa48]
    // 0xf38164: blr             x9
    // 0xf38168: ldur            x1, [fp, #-0x10]
    // 0xf3816c: LoadField: r0 = r1->field_b
    //     0xf3816c: ldur            w0, [x1, #0xb]
    // 0xf38170: DecompressPointer r0
    //     0xf38170: add             x0, x0, HEAP, lsl #32
    // 0xf38174: cmp             w0, NULL
    // 0xf38178: b.eq            #0xf38198
    // 0xf3817c: r0 = _updateSelectedIndex()
    //     0xf3817c: bl              #0xf3819c  ; [package:flutter/src/material/dropdown.dart] _DropdownButtonState::_updateSelectedIndex
    // 0xf38180: r0 = Null
    //     0xf38180: mov             x0, NULL
    // 0xf38184: LeaveFrame
    //     0xf38184: mov             SP, fp
    //     0xf38188: ldp             fp, lr, [SP], #0x10
    // 0xf3818c: ret
    //     0xf3818c: ret             
    // 0xf38190: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf38190: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf38194: b               #0xf38104
    // 0xf38198: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf38198: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateSelectedIndex(/* No info */) {
    // ** addr: 0xf3819c, size: 0x1cc
    // 0xf3819c: EnterFrame
    //     0xf3819c: stp             fp, lr, [SP, #-0x10]!
    //     0xf381a0: mov             fp, SP
    // 0xf381a4: AllocStack(0x28)
    //     0xf381a4: sub             SP, SP, #0x28
    // 0xf381a8: SetupParameters(_DropdownButtonState<C1X0> this /* r1 => r1, fp-0x8 */)
    //     0xf381a8: stur            x1, [fp, #-8]
    // 0xf381ac: CheckStackOverflow
    //     0xf381ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf381b0: cmp             SP, x16
    //     0xf381b4: b.ls            #0xf38350
    // 0xf381b8: r1 = 1
    //     0xf381b8: mov             x1, #1
    // 0xf381bc: r0 = AllocateContext()
    //     0xf381bc: bl              #0x13de838  ; AllocateContextStub
    // 0xf381c0: mov             x1, x0
    // 0xf381c4: ldur            x0, [fp, #-8]
    // 0xf381c8: StoreField: r1->field_f = r0
    //     0xf381c8: stur            w0, [x1, #0xf]
    // 0xf381cc: LoadField: r2 = r0->field_b
    //     0xf381cc: ldur            w2, [x0, #0xb]
    // 0xf381d0: DecompressPointer r2
    //     0xf381d0: add             x2, x2, HEAP, lsl #32
    // 0xf381d4: cmp             w2, NULL
    // 0xf381d8: b.eq            #0xf38358
    // 0xf381dc: LoadField: r4 = r2->field_f
    //     0xf381dc: ldur            w4, [x2, #0xf]
    // 0xf381e0: DecompressPointer r4
    //     0xf381e0: add             x4, x4, HEAP, lsl #32
    // 0xf381e4: stur            x4, [fp, #-0x10]
    // 0xf381e8: LoadField: r3 = r4->field_b
    //     0xf381e8: ldur            w3, [x4, #0xb]
    // 0xf381ec: cbnz            w3, #0xf381f8
    // 0xf381f0: mov             x1, x0
    // 0xf381f4: b               #0xf38268
    // 0xf381f8: LoadField: r3 = r2->field_13
    //     0xf381f8: ldur            w3, [x2, #0x13]
    // 0xf381fc: DecompressPointer r3
    //     0xf381fc: add             x3, x3, HEAP, lsl #32
    // 0xf38200: cmp             w3, NULL
    // 0xf38204: b.ne            #0xf38284
    // 0xf38208: LoadField: r3 = r0->field_7
    //     0xf38208: ldur            w3, [x0, #7]
    // 0xf3820c: DecompressPointer r3
    //     0xf3820c: add             x3, x3, HEAP, lsl #32
    // 0xf38210: mov             x2, x1
    // 0xf38214: r1 = Function '<anonymous closure>':.
    //     0xf38214: add             x1, PP, #0x99, lsl #12  ; [pp+0x99a58] AnonymousClosure: (0xf38368), in [package:flutter/src/material/dropdown.dart] _DropdownButtonState::_updateSelectedIndex (0xf3819c)
    //     0xf38218: ldr             x1, [x1, #0xa58]
    // 0xf3821c: r0 = AllocateClosureTA()
    //     0xf3821c: bl              #0x13dea48  ; AllocateClosureTAStub
    // 0xf38220: ldur            x1, [fp, #-0x10]
    // 0xf38224: mov             x2, x0
    // 0xf38228: r0 = where()
    //     0xf38228: bl              #0xb92e4c  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::where
    // 0xf3822c: mov             x1, x0
    // 0xf38230: r0 = iterator()
    //     0xf38230: bl              #0xb0a104  ; [dart:_internal] WhereIterable::iterator
    // 0xf38234: r1 = LoadClassIdInstr(r0)
    //     0xf38234: ldur            x1, [x0, #-1]
    //     0xf38238: ubfx            x1, x1, #0xc, #0x14
    // 0xf3823c: mov             x16, x0
    // 0xf38240: mov             x0, x1
    // 0xf38244: mov             x1, x16
    // 0xf38248: r0 = GDT[cid_x0 + 0x1845b]()
    //     0xf38248: mov             x17, #0x845b
    //     0xf3824c: movk            x17, #1, lsl #16
    //     0xf38250: add             lr, x0, x17
    //     0xf38254: ldr             lr, [x21, lr, lsl #3]
    //     0xf38258: blr             lr
    // 0xf3825c: eor             x1, x0, #0x10
    // 0xf38260: tbnz            w1, #4, #0xf3827c
    // 0xf38264: ldur            x1, [fp, #-8]
    // 0xf38268: StoreField: r1->field_13 = rNULL
    //     0xf38268: stur            NULL, [x1, #0x13]
    // 0xf3826c: r0 = Null
    //     0xf3826c: mov             x0, NULL
    // 0xf38270: LeaveFrame
    //     0xf38270: mov             SP, fp
    //     0xf38274: ldp             fp, lr, [SP], #0x10
    // 0xf38278: ret
    //     0xf38278: ret             
    // 0xf3827c: ldur            x1, [fp, #-8]
    // 0xf38280: b               #0xf38288
    // 0xf38284: mov             x1, x0
    // 0xf38288: r2 = 0
    //     0xf38288: mov             x2, #0
    // 0xf3828c: stur            x2, [fp, #-0x18]
    // 0xf38290: CheckStackOverflow
    //     0xf38290: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf38294: cmp             SP, x16
    //     0xf38298: b.ls            #0xf3835c
    // 0xf3829c: LoadField: r0 = r1->field_b
    //     0xf3829c: ldur            w0, [x1, #0xb]
    // 0xf382a0: DecompressPointer r0
    //     0xf382a0: add             x0, x0, HEAP, lsl #32
    // 0xf382a4: cmp             w0, NULL
    // 0xf382a8: b.eq            #0xf38364
    // 0xf382ac: LoadField: r3 = r0->field_f
    //     0xf382ac: ldur            w3, [x0, #0xf]
    // 0xf382b0: DecompressPointer r3
    //     0xf382b0: add             x3, x3, HEAP, lsl #32
    // 0xf382b4: LoadField: r4 = r3->field_b
    //     0xf382b4: ldur            w4, [x3, #0xb]
    // 0xf382b8: r5 = LoadInt32Instr(r4)
    //     0xf382b8: sbfx            x5, x4, #1, #0x1f
    // 0xf382bc: cmp             x2, x5
    // 0xf382c0: b.ge            #0xf38340
    // 0xf382c4: LoadField: r4 = r3->field_f
    //     0xf382c4: ldur            w4, [x3, #0xf]
    // 0xf382c8: DecompressPointer r4
    //     0xf382c8: add             x4, x4, HEAP, lsl #32
    // 0xf382cc: lsl             x3, x2, #1
    // 0xf382d0: stur            x3, [fp, #-0x10]
    // 0xf382d4: ArrayLoad: r5 = r4[r2]  ; Unknown_4
    //     0xf382d4: add             x16, x4, x2, lsl #2
    //     0xf382d8: ldur            w5, [x16, #0xf]
    // 0xf382dc: DecompressPointer r5
    //     0xf382dc: add             x5, x5, HEAP, lsl #32
    // 0xf382e0: LoadField: r4 = r5->field_1b
    //     0xf382e0: ldur            w4, [x5, #0x1b]
    // 0xf382e4: DecompressPointer r4
    //     0xf382e4: add             x4, x4, HEAP, lsl #32
    // 0xf382e8: LoadField: r5 = r0->field_13
    //     0xf382e8: ldur            w5, [x0, #0x13]
    // 0xf382ec: DecompressPointer r5
    //     0xf382ec: add             x5, x5, HEAP, lsl #32
    // 0xf382f0: r0 = 60
    //     0xf382f0: mov             x0, #0x3c
    // 0xf382f4: branchIfSmi(r4, 0xf38300)
    //     0xf382f4: tbz             w4, #0, #0xf38300
    // 0xf382f8: r0 = LoadClassIdInstr(r4)
    //     0xf382f8: ldur            x0, [x4, #-1]
    //     0xf382fc: ubfx            x0, x0, #0xc, #0x14
    // 0xf38300: stp             x5, x4, [SP]
    // 0xf38304: mov             lr, x0
    // 0xf38308: ldr             lr, [x21, lr, lsl #3]
    // 0xf3830c: blr             lr
    // 0xf38310: tbz             w0, #4, #0xf38324
    // 0xf38314: ldur            x1, [fp, #-0x18]
    // 0xf38318: add             x2, x1, #1
    // 0xf3831c: ldur            x1, [fp, #-8]
    // 0xf38320: b               #0xf3828c
    // 0xf38324: ldur            x1, [fp, #-8]
    // 0xf38328: ldur            x2, [fp, #-0x10]
    // 0xf3832c: StoreField: r1->field_13 = r2
    //     0xf3832c: stur            w2, [x1, #0x13]
    // 0xf38330: r0 = Null
    //     0xf38330: mov             x0, NULL
    // 0xf38334: LeaveFrame
    //     0xf38334: mov             SP, fp
    //     0xf38338: ldp             fp, lr, [SP], #0x10
    // 0xf3833c: ret
    //     0xf3833c: ret             
    // 0xf38340: r0 = Null
    //     0xf38340: mov             x0, NULL
    // 0xf38344: LeaveFrame
    //     0xf38344: mov             SP, fp
    //     0xf38348: ldp             fp, lr, [SP], #0x10
    // 0xf3834c: ret
    //     0xf3834c: ret             
    // 0xf38350: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf38350: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf38354: b               #0xf381b8
    // 0xf38358: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf38358: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3835c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3835c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf38360: b               #0xf3829c
    // 0xf38364: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf38364: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] bool <anonymous closure>(dynamic, DropdownMenuItem<C1X0>) {
    // ** addr: 0xf38368, size: 0x8c
    // 0xf38368: EnterFrame
    //     0xf38368: stp             fp, lr, [SP, #-0x10]!
    //     0xf3836c: mov             fp, SP
    // 0xf38370: AllocStack(0x10)
    //     0xf38370: sub             SP, SP, #0x10
    // 0xf38374: SetupParameters([dynamic _ /* r0 */])
    //     0xf38374: ldr             x0, [fp, #0x18]
    //     0xf38378: ldur            w1, [x0, #0x17]
    //     0xf3837c: add             x1, x1, HEAP, lsl #32
    // 0xf38380: CheckStackOverflow
    //     0xf38380: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf38384: cmp             SP, x16
    //     0xf38388: b.ls            #0xf383e8
    // 0xf3838c: ldr             x0, [fp, #0x10]
    // 0xf38390: LoadField: r2 = r0->field_1b
    //     0xf38390: ldur            w2, [x0, #0x1b]
    // 0xf38394: DecompressPointer r2
    //     0xf38394: add             x2, x2, HEAP, lsl #32
    // 0xf38398: LoadField: r0 = r1->field_f
    //     0xf38398: ldur            w0, [x1, #0xf]
    // 0xf3839c: DecompressPointer r0
    //     0xf3839c: add             x0, x0, HEAP, lsl #32
    // 0xf383a0: LoadField: r1 = r0->field_b
    //     0xf383a0: ldur            w1, [x0, #0xb]
    // 0xf383a4: DecompressPointer r1
    //     0xf383a4: add             x1, x1, HEAP, lsl #32
    // 0xf383a8: cmp             w1, NULL
    // 0xf383ac: b.eq            #0xf383f0
    // 0xf383b0: LoadField: r0 = r1->field_13
    //     0xf383b0: ldur            w0, [x1, #0x13]
    // 0xf383b4: DecompressPointer r0
    //     0xf383b4: add             x0, x0, HEAP, lsl #32
    // 0xf383b8: r1 = 60
    //     0xf383b8: mov             x1, #0x3c
    // 0xf383bc: branchIfSmi(r2, 0xf383c8)
    //     0xf383bc: tbz             w2, #0, #0xf383c8
    // 0xf383c0: r1 = LoadClassIdInstr(r2)
    //     0xf383c0: ldur            x1, [x2, #-1]
    //     0xf383c4: ubfx            x1, x1, #0xc, #0x14
    // 0xf383c8: stp             x0, x2, [SP]
    // 0xf383cc: mov             x0, x1
    // 0xf383d0: mov             lr, x0
    // 0xf383d4: ldr             lr, [x21, lr, lsl #3]
    // 0xf383d8: blr             lr
    // 0xf383dc: LeaveFrame
    //     0xf383dc: mov             SP, fp
    //     0xf383e0: ldp             fp, lr, [SP], #0x10
    // 0xf383e4: ret
    //     0xf383e4: ret             
    // 0xf383e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf383e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf383ec: b               #0xf3838c
    // 0xf383f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf383f0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0xf79a08, size: 0x2f8
    // 0xf79a08: EnterFrame
    //     0xf79a08: stp             fp, lr, [SP, #-0x10]!
    //     0xf79a0c: mov             fp, SP
    // 0xf79a10: AllocStack(0x38)
    //     0xf79a10: sub             SP, SP, #0x38
    // 0xf79a14: SetupParameters(_DropdownButtonState<C1X0> this /* r1 => r1, fp-0x8 */)
    //     0xf79a14: stur            x1, [fp, #-8]
    // 0xf79a18: CheckStackOverflow
    //     0xf79a18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf79a1c: cmp             SP, x16
    //     0xf79a20: b.ls            #0xf79cec
    // 0xf79a24: r1 = 1
    //     0xf79a24: mov             x1, #1
    // 0xf79a28: r0 = AllocateContext()
    //     0xf79a28: bl              #0x13de838  ; AllocateContextStub
    // 0xf79a2c: mov             x2, x0
    // 0xf79a30: ldur            x0, [fp, #-8]
    // 0xf79a34: stur            x2, [fp, #-0x10]
    // 0xf79a38: StoreField: r2->field_f = r0
    //     0xf79a38: stur            w0, [x2, #0xf]
    // 0xf79a3c: mov             x1, x0
    // 0xf79a40: r0 = _updateSelectedIndex()
    //     0xf79a40: bl              #0xf3819c  ; [package:flutter/src/material/dropdown.dart] _DropdownButtonState::_updateSelectedIndex
    // 0xf79a44: ldur            x0, [fp, #-8]
    // 0xf79a48: LoadField: r1 = r0->field_b
    //     0xf79a48: ldur            w1, [x0, #0xb]
    // 0xf79a4c: DecompressPointer r1
    //     0xf79a4c: add             x1, x1, HEAP, lsl #32
    // 0xf79a50: cmp             w1, NULL
    // 0xf79a54: b.eq            #0xf79cf4
    // 0xf79a58: LoadField: r1 = r0->field_1f
    //     0xf79a58: ldur            w1, [x0, #0x1f]
    // 0xf79a5c: DecompressPointer r1
    //     0xf79a5c: add             x1, x1, HEAP, lsl #32
    // 0xf79a60: cmp             w1, NULL
    // 0xf79a64: b.ne            #0xf79a94
    // 0xf79a68: mov             x1, x0
    // 0xf79a6c: r0 = _createFocusNode()
    //     0xf79a6c: bl              #0xf79d00  ; [package:flutter/src/material/dropdown.dart] _DropdownButtonState::_createFocusNode
    // 0xf79a70: ldur            x3, [fp, #-8]
    // 0xf79a74: StoreField: r3->field_1f = r0
    //     0xf79a74: stur            w0, [x3, #0x1f]
    //     0xf79a78: ldurb           w16, [x3, #-1]
    //     0xf79a7c: ldurb           w17, [x0, #-1]
    //     0xf79a80: and             x16, x17, x16, lsr #2
    //     0xf79a84: tst             x16, HEAP, lsr #32
    //     0xf79a88: b.eq            #0xf79a90
    //     0xf79a8c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xf79a90: b               #0xf79a98
    // 0xf79a94: mov             x3, x0
    // 0xf79a98: r1 = Null
    //     0xf79a98: mov             x1, NULL
    // 0xf79a9c: r2 = 8
    //     0xf79a9c: mov             x2, #8
    // 0xf79aa0: r0 = AllocateArray()
    //     0xf79aa0: bl              #0x13df928  ; AllocateArrayStub
    // 0xf79aa4: stur            x0, [fp, #-0x18]
    // 0xf79aa8: r16 = ActivateIntent
    //     0xf79aa8: add             x16, PP, #0x90, lsl #12  ; [pp+0x904d0] Type: ActivateIntent
    //     0xf79aac: ldr             x16, [x16, #0x4d0]
    // 0xf79ab0: StoreField: r0->field_f = r16
    //     0xf79ab0: stur            w16, [x0, #0xf]
    // 0xf79ab4: ldur            x2, [fp, #-0x10]
    // 0xf79ab8: r1 = Function '<anonymous closure>':.
    //     0xf79ab8: add             x1, PP, #0x99, lsl #12  ; [pp+0x99a70] AnonymousClosure: (0xf79d74), in [package:flutter/src/material/dropdown.dart] _DropdownButtonState::initState (0xf79a08)
    //     0xf79abc: ldr             x1, [x1, #0xa70]
    // 0xf79ac0: r0 = AllocateClosure()
    //     0xf79ac0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf79ac4: r1 = <ActivateIntent>
    //     0xf79ac4: add             x1, PP, #0x90, lsl #12  ; [pp+0x904d8] TypeArguments: <ActivateIntent>
    //     0xf79ac8: ldr             x1, [x1, #0x4d8]
    // 0xf79acc: stur            x0, [fp, #-0x20]
    // 0xf79ad0: r0 = CallbackAction()
    //     0xf79ad0: bl              #0xd126e8  ; AllocateCallbackActionStub -> CallbackAction<X0 bound Intent> (size=0x18)
    // 0xf79ad4: mov             x2, x0
    // 0xf79ad8: ldur            x0, [fp, #-0x20]
    // 0xf79adc: stur            x2, [fp, #-0x28]
    // 0xf79ae0: StoreField: r2->field_13 = r0
    //     0xf79ae0: stur            w0, [x2, #0x13]
    // 0xf79ae4: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0xf79ae4: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a7a0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0xf79ae8: ldr             x1, [x1, #0x7a0]
    // 0xf79aec: r0 = ObserverList()
    //     0xf79aec: bl              #0x89f8bc  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0xf79af0: mov             x3, x0
    // 0xf79af4: r0 = false
    //     0xf79af4: add             x0, NULL, #0x30  ; false
    // 0xf79af8: stur            x3, [fp, #-0x20]
    // 0xf79afc: StoreField: r3->field_f = r0
    //     0xf79afc: stur            w0, [x3, #0xf]
    // 0xf79b00: ldr             x4, [THR, #0x90]  ; THR::object_sentinel
    // 0xf79b04: StoreField: r3->field_13 = r4
    //     0xf79b04: stur            w4, [x3, #0x13]
    // 0xf79b08: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0xf79b08: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a7a0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0xf79b0c: ldr             x1, [x1, #0x7a0]
    // 0xf79b10: r2 = 0
    //     0xf79b10: mov             x2, #0
    // 0xf79b14: r0 = _GrowableList()
    //     0xf79b14: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xf79b18: ldur            x1, [fp, #-0x20]
    // 0xf79b1c: StoreField: r1->field_b = r0
    //     0xf79b1c: stur            w0, [x1, #0xb]
    //     0xf79b20: ldurb           w16, [x1, #-1]
    //     0xf79b24: ldurb           w17, [x0, #-1]
    //     0xf79b28: and             x16, x17, x16, lsr #2
    //     0xf79b2c: tst             x16, HEAP, lsr #32
    //     0xf79b30: b.eq            #0xf79b38
    //     0xf79b34: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf79b38: mov             x0, x1
    // 0xf79b3c: ldur            x1, [fp, #-0x28]
    // 0xf79b40: StoreField: r1->field_b = r0
    //     0xf79b40: stur            w0, [x1, #0xb]
    //     0xf79b44: ldurb           w16, [x1, #-1]
    //     0xf79b48: ldurb           w17, [x0, #-1]
    //     0xf79b4c: and             x16, x17, x16, lsr #2
    //     0xf79b50: tst             x16, HEAP, lsr #32
    //     0xf79b54: b.eq            #0xf79b5c
    //     0xf79b58: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf79b5c: mov             x0, x1
    // 0xf79b60: ldur            x1, [fp, #-0x18]
    // 0xf79b64: ArrayStore: r1[1] = r0  ; List_4
    //     0xf79b64: add             x25, x1, #0x13
    //     0xf79b68: str             w0, [x25]
    //     0xf79b6c: tbz             w0, #0, #0xf79b88
    //     0xf79b70: ldurb           w16, [x1, #-1]
    //     0xf79b74: ldurb           w17, [x0, #-1]
    //     0xf79b78: and             x16, x17, x16, lsr #2
    //     0xf79b7c: tst             x16, HEAP, lsr #32
    //     0xf79b80: b.eq            #0xf79b88
    //     0xf79b84: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xf79b88: ldur            x0, [fp, #-0x18]
    // 0xf79b8c: r16 = ButtonActivateIntent
    //     0xf79b8c: add             x16, PP, #0x99, lsl #12  ; [pp+0x99658] Type: ButtonActivateIntent
    //     0xf79b90: ldr             x16, [x16, #0x658]
    // 0xf79b94: ArrayStore: r0[0] = r16  ; List_4
    //     0xf79b94: stur            w16, [x0, #0x17]
    // 0xf79b98: ldur            x2, [fp, #-0x10]
    // 0xf79b9c: r1 = Function '<anonymous closure>':.
    //     0xf79b9c: add             x1, PP, #0x99, lsl #12  ; [pp+0x99a78] AnonymousClosure: (0xf79d74), in [package:flutter/src/material/dropdown.dart] _DropdownButtonState::initState (0xf79a08)
    //     0xf79ba0: ldr             x1, [x1, #0xa78]
    // 0xf79ba4: r0 = AllocateClosure()
    //     0xf79ba4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf79ba8: r1 = <ButtonActivateIntent>
    //     0xf79ba8: add             x1, PP, #0x99, lsl #12  ; [pp+0x99660] TypeArguments: <ButtonActivateIntent>
    //     0xf79bac: ldr             x1, [x1, #0x660]
    // 0xf79bb0: stur            x0, [fp, #-0x10]
    // 0xf79bb4: r0 = CallbackAction()
    //     0xf79bb4: bl              #0xd126e8  ; AllocateCallbackActionStub -> CallbackAction<X0 bound Intent> (size=0x18)
    // 0xf79bb8: mov             x2, x0
    // 0xf79bbc: ldur            x0, [fp, #-0x10]
    // 0xf79bc0: stur            x2, [fp, #-0x20]
    // 0xf79bc4: StoreField: r2->field_13 = r0
    //     0xf79bc4: stur            w0, [x2, #0x13]
    // 0xf79bc8: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0xf79bc8: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a7a0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0xf79bcc: ldr             x1, [x1, #0x7a0]
    // 0xf79bd0: r0 = ObserverList()
    //     0xf79bd0: bl              #0x89f8bc  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0xf79bd4: mov             x3, x0
    // 0xf79bd8: r0 = false
    //     0xf79bd8: add             x0, NULL, #0x30  ; false
    // 0xf79bdc: stur            x3, [fp, #-0x10]
    // 0xf79be0: StoreField: r3->field_f = r0
    //     0xf79be0: stur            w0, [x3, #0xf]
    // 0xf79be4: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xf79be8: StoreField: r3->field_13 = r0
    //     0xf79be8: stur            w0, [x3, #0x13]
    // 0xf79bec: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0xf79bec: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a7a0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0xf79bf0: ldr             x1, [x1, #0x7a0]
    // 0xf79bf4: r2 = 0
    //     0xf79bf4: mov             x2, #0
    // 0xf79bf8: r0 = _GrowableList()
    //     0xf79bf8: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xf79bfc: ldur            x1, [fp, #-0x10]
    // 0xf79c00: StoreField: r1->field_b = r0
    //     0xf79c00: stur            w0, [x1, #0xb]
    //     0xf79c04: ldurb           w16, [x1, #-1]
    //     0xf79c08: ldurb           w17, [x0, #-1]
    //     0xf79c0c: and             x16, x17, x16, lsr #2
    //     0xf79c10: tst             x16, HEAP, lsr #32
    //     0xf79c14: b.eq            #0xf79c1c
    //     0xf79c18: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf79c1c: mov             x0, x1
    // 0xf79c20: ldur            x1, [fp, #-0x20]
    // 0xf79c24: StoreField: r1->field_b = r0
    //     0xf79c24: stur            w0, [x1, #0xb]
    //     0xf79c28: ldurb           w16, [x1, #-1]
    //     0xf79c2c: ldurb           w17, [x0, #-1]
    //     0xf79c30: and             x16, x17, x16, lsr #2
    //     0xf79c34: tst             x16, HEAP, lsr #32
    //     0xf79c38: b.eq            #0xf79c40
    //     0xf79c3c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf79c40: mov             x0, x1
    // 0xf79c44: ldur            x1, [fp, #-0x18]
    // 0xf79c48: ArrayStore: r1[3] = r0  ; List_4
    //     0xf79c48: add             x25, x1, #0x1b
    //     0xf79c4c: str             w0, [x25]
    //     0xf79c50: tbz             w0, #0, #0xf79c6c
    //     0xf79c54: ldurb           w16, [x1, #-1]
    //     0xf79c58: ldurb           w17, [x0, #-1]
    //     0xf79c5c: and             x16, x17, x16, lsr #2
    //     0xf79c60: tst             x16, HEAP, lsr #32
    //     0xf79c64: b.eq            #0xf79c6c
    //     0xf79c68: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xf79c6c: r16 = <Type, Action<Intent>>
    //     0xf79c6c: add             x16, PP, #0x84, lsl #12  ; [pp+0x84b80] TypeArguments: <Type, Action<Intent>>
    //     0xf79c70: ldr             x16, [x16, #0xb80]
    // 0xf79c74: ldur            lr, [fp, #-0x18]
    // 0xf79c78: stp             lr, x16, [SP]
    // 0xf79c7c: r0 = Map._fromLiteral()
    //     0xf79c7c: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xf79c80: ldur            x2, [fp, #-8]
    // 0xf79c84: StoreField: r2->field_23 = r0
    //     0xf79c84: stur            w0, [x2, #0x23]
    //     0xf79c88: ldurb           w16, [x2, #-1]
    //     0xf79c8c: ldurb           w17, [x0, #-1]
    //     0xf79c90: and             x16, x17, x16, lsr #2
    //     0xf79c94: tst             x16, HEAP, lsr #32
    //     0xf79c98: b.eq            #0xf79ca0
    //     0xf79c9c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf79ca0: LoadField: r0 = r2->field_b
    //     0xf79ca0: ldur            w0, [x2, #0xb]
    // 0xf79ca4: DecompressPointer r0
    //     0xf79ca4: add             x0, x0, HEAP, lsl #32
    // 0xf79ca8: cmp             w0, NULL
    // 0xf79cac: b.eq            #0xf79cf8
    // 0xf79cb0: LoadField: r0 = r2->field_1f
    //     0xf79cb0: ldur            w0, [x2, #0x1f]
    // 0xf79cb4: DecompressPointer r0
    //     0xf79cb4: add             x0, x0, HEAP, lsl #32
    // 0xf79cb8: stur            x0, [fp, #-0x10]
    // 0xf79cbc: cmp             w0, NULL
    // 0xf79cc0: b.eq            #0xf79cfc
    // 0xf79cc4: r1 = Function '_handleFocusChanged@83005770':.
    //     0xf79cc4: add             x1, PP, #0x99, lsl #12  ; [pp+0x99a60] AnonymousClosure: (0xf79dbc), in [package:flutter/src/material/dropdown.dart] _DropdownButtonState::_handleFocusChanged (0xf79df4)
    //     0xf79cc8: ldr             x1, [x1, #0xa60]
    // 0xf79ccc: r0 = AllocateClosure()
    //     0xf79ccc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf79cd0: ldur            x1, [fp, #-0x10]
    // 0xf79cd4: mov             x2, x0
    // 0xf79cd8: r0 = addListener()
    //     0xf79cd8: bl              #0xd01514  ; [dart:mixin_deduplication] _MixinApplication219&Object&DiagnosticableTreeMixin&ChangeNotifier::addListener
    // 0xf79cdc: r0 = Null
    //     0xf79cdc: mov             x0, NULL
    // 0xf79ce0: LeaveFrame
    //     0xf79ce0: mov             SP, fp
    //     0xf79ce4: ldp             fp, lr, [SP], #0x10
    // 0xf79ce8: ret
    //     0xf79ce8: ret             
    // 0xf79cec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf79cec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf79cf0: b               #0xf79a24
    // 0xf79cf4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf79cf4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf79cf8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf79cf8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf79cfc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf79cfc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _createFocusNode(/* No info */) {
    // ** addr: 0xf79d00, size: 0x74
    // 0xf79d00: EnterFrame
    //     0xf79d00: stp             fp, lr, [SP, #-0x10]!
    //     0xf79d04: mov             fp, SP
    // 0xf79d08: AllocStack(0x18)
    //     0xf79d08: sub             SP, SP, #0x18
    // 0xf79d0c: CheckStackOverflow
    //     0xf79d0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf79d10: cmp             SP, x16
    //     0xf79d14: b.ls            #0xf79d68
    // 0xf79d18: LoadField: r0 = r1->field_b
    //     0xf79d18: ldur            w0, [x1, #0xb]
    // 0xf79d1c: DecompressPointer r0
    //     0xf79d1c: add             x0, x0, HEAP, lsl #32
    // 0xf79d20: cmp             w0, NULL
    // 0xf79d24: b.eq            #0xf79d70
    // 0xf79d28: str             x0, [SP]
    // 0xf79d2c: r0 = runtimeType()
    //     0xf79d2c: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0xf79d30: str             x0, [SP]
    // 0xf79d34: r0 = _interpolateSingle()
    //     0xf79d34: bl              #0x7e237c  ; [dart:core] _StringBase::_interpolateSingle
    // 0xf79d38: stur            x0, [fp, #-8]
    // 0xf79d3c: r0 = FocusNode()
    //     0xf79d3c: bl              #0xd4952c  ; AllocateFocusNodeStub -> FocusNode (size=0x68)
    // 0xf79d40: stur            x0, [fp, #-0x10]
    // 0xf79d44: ldur            x16, [fp, #-8]
    // 0xf79d48: str             x16, [SP]
    // 0xf79d4c: mov             x1, x0
    // 0xf79d50: r4 = const [0, 0x2, 0x1, 0x1, debugLabel, 0x1, null]
    //     0xf79d50: ldr             x4, [PP, #0x1e10]  ; [pp+0x1e10] List(7) [0, 0x2, 0x1, 0x1, "debugLabel", 0x1, Null]
    // 0xf79d54: r0 = FocusNode()
    //     0xf79d54: bl              #0x83cf84  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::FocusNode
    // 0xf79d58: ldur            x0, [fp, #-0x10]
    // 0xf79d5c: LeaveFrame
    //     0xf79d5c: mov             SP, fp
    //     0xf79d60: ldp             fp, lr, [SP], #0x10
    // 0xf79d64: ret
    //     0xf79d64: ret             
    // 0xf79d68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf79d68: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf79d6c: b               #0xf79d18
    // 0xf79d70: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf79d70: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, ActivateIntent) {
    // ** addr: 0xf79d74, size: 0x48
    // 0xf79d74: EnterFrame
    //     0xf79d74: stp             fp, lr, [SP, #-0x10]!
    //     0xf79d78: mov             fp, SP
    // 0xf79d7c: ldr             x0, [fp, #0x18]
    // 0xf79d80: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf79d80: ldur            w1, [x0, #0x17]
    // 0xf79d84: DecompressPointer r1
    //     0xf79d84: add             x1, x1, HEAP, lsl #32
    // 0xf79d88: CheckStackOverflow
    //     0xf79d88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf79d8c: cmp             SP, x16
    //     0xf79d90: b.ls            #0xf79db4
    // 0xf79d94: LoadField: r0 = r1->field_f
    //     0xf79d94: ldur            w0, [x1, #0xf]
    // 0xf79d98: DecompressPointer r0
    //     0xf79d98: add             x0, x0, HEAP, lsl #32
    // 0xf79d9c: mov             x1, x0
    // 0xf79da0: r0 = _handleTap()
    //     0xf79da0: bl              #0xd1ee4c  ; [package:flutter/src/material/dropdown.dart] _DropdownButtonState::_handleTap
    // 0xf79da4: r0 = Null
    //     0xf79da4: mov             x0, NULL
    // 0xf79da8: LeaveFrame
    //     0xf79da8: mov             SP, fp
    //     0xf79dac: ldp             fp, lr, [SP], #0x10
    // 0xf79db0: ret
    //     0xf79db0: ret             
    // 0xf79db4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf79db4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf79db8: b               #0xf79d94
  }
  [closure] void _handleFocusChanged(dynamic) {
    // ** addr: 0xf79dbc, size: 0x38
    // 0xf79dbc: EnterFrame
    //     0xf79dbc: stp             fp, lr, [SP, #-0x10]!
    //     0xf79dc0: mov             fp, SP
    // 0xf79dc4: ldr             x0, [fp, #0x10]
    // 0xf79dc8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf79dc8: ldur            w1, [x0, #0x17]
    // 0xf79dcc: DecompressPointer r1
    //     0xf79dcc: add             x1, x1, HEAP, lsl #32
    // 0xf79dd0: CheckStackOverflow
    //     0xf79dd0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf79dd4: cmp             SP, x16
    //     0xf79dd8: b.ls            #0xf79dec
    // 0xf79ddc: r0 = _handleFocusChanged()
    //     0xf79ddc: bl              #0xf79df4  ; [package:flutter/src/material/dropdown.dart] _DropdownButtonState::_handleFocusChanged
    // 0xf79de0: LeaveFrame
    //     0xf79de0: mov             SP, fp
    //     0xf79de4: ldp             fp, lr, [SP], #0x10
    // 0xf79de8: ret
    //     0xf79de8: ret             
    // 0xf79dec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf79dec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf79df0: b               #0xf79ddc
  }
  _ _handleFocusChanged(/* No info */) {
    // ** addr: 0xf79df4, size: 0xb0
    // 0xf79df4: EnterFrame
    //     0xf79df4: stp             fp, lr, [SP, #-0x10]!
    //     0xf79df8: mov             fp, SP
    // 0xf79dfc: AllocStack(0x18)
    //     0xf79dfc: sub             SP, SP, #0x18
    // 0xf79e00: SetupParameters(_DropdownButtonState<C1X0> this /* r1 => r1, fp-0x8 */)
    //     0xf79e00: stur            x1, [fp, #-8]
    // 0xf79e04: CheckStackOverflow
    //     0xf79e04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf79e08: cmp             SP, x16
    //     0xf79e0c: b.ls            #0xf79e94
    // 0xf79e10: r1 = 1
    //     0xf79e10: mov             x1, #1
    // 0xf79e14: r0 = AllocateContext()
    //     0xf79e14: bl              #0x13de838  ; AllocateContextStub
    // 0xf79e18: mov             x2, x0
    // 0xf79e1c: ldur            x0, [fp, #-8]
    // 0xf79e20: stur            x2, [fp, #-0x18]
    // 0xf79e24: StoreField: r2->field_f = r0
    //     0xf79e24: stur            w0, [x2, #0xf]
    // 0xf79e28: LoadField: r3 = r0->field_2b
    //     0xf79e28: ldur            w3, [x0, #0x2b]
    // 0xf79e2c: DecompressPointer r3
    //     0xf79e2c: add             x3, x3, HEAP, lsl #32
    // 0xf79e30: stur            x3, [fp, #-0x10]
    // 0xf79e34: LoadField: r1 = r0->field_b
    //     0xf79e34: ldur            w1, [x0, #0xb]
    // 0xf79e38: DecompressPointer r1
    //     0xf79e38: add             x1, x1, HEAP, lsl #32
    // 0xf79e3c: cmp             w1, NULL
    // 0xf79e40: b.eq            #0xf79e9c
    // 0xf79e44: LoadField: r1 = r0->field_1f
    //     0xf79e44: ldur            w1, [x0, #0x1f]
    // 0xf79e48: DecompressPointer r1
    //     0xf79e48: add             x1, x1, HEAP, lsl #32
    // 0xf79e4c: cmp             w1, NULL
    // 0xf79e50: b.eq            #0xf79ea0
    // 0xf79e54: r0 = hasPrimaryFocus()
    //     0xf79e54: bl              #0x83e41c  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::hasPrimaryFocus
    // 0xf79e58: mov             x1, x0
    // 0xf79e5c: ldur            x0, [fp, #-0x10]
    // 0xf79e60: cmp             w0, w1
    // 0xf79e64: b.eq            #0xf79e84
    // 0xf79e68: ldur            x2, [fp, #-0x18]
    // 0xf79e6c: r1 = Function '<anonymous closure>':.
    //     0xf79e6c: add             x1, PP, #0x99, lsl #12  ; [pp+0x99a68] AnonymousClosure: (0xf79ea4), in [package:flutter/src/material/dropdown.dart] _DropdownButtonState::_handleFocusChanged (0xf79df4)
    //     0xf79e70: ldr             x1, [x1, #0xa68]
    // 0xf79e74: r0 = AllocateClosure()
    //     0xf79e74: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf79e78: ldur            x1, [fp, #-8]
    // 0xf79e7c: mov             x2, x0
    // 0xf79e80: r0 = setState()
    //     0xf79e80: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xf79e84: r0 = Null
    //     0xf79e84: mov             x0, NULL
    // 0xf79e88: LeaveFrame
    //     0xf79e88: mov             SP, fp
    //     0xf79e8c: ldp             fp, lr, [SP], #0x10
    // 0xf79e90: ret
    //     0xf79e90: ret             
    // 0xf79e94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf79e94: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf79e98: b               #0xf79e10
    // 0xf79e9c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf79e9c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf79ea0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf79ea0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xf79ea4, size: 0x7c
    // 0xf79ea4: EnterFrame
    //     0xf79ea4: stp             fp, lr, [SP, #-0x10]!
    //     0xf79ea8: mov             fp, SP
    // 0xf79eac: AllocStack(0x8)
    //     0xf79eac: sub             SP, SP, #8
    // 0xf79eb0: SetupParameters([dynamic _ /* r0 */])
    //     0xf79eb0: ldr             x0, [fp, #0x10]
    //     0xf79eb4: ldur            w1, [x0, #0x17]
    //     0xf79eb8: add             x1, x1, HEAP, lsl #32
    // 0xf79ebc: CheckStackOverflow
    //     0xf79ebc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf79ec0: cmp             SP, x16
    //     0xf79ec4: b.ls            #0xf79f10
    // 0xf79ec8: LoadField: r0 = r1->field_f
    //     0xf79ec8: ldur            w0, [x1, #0xf]
    // 0xf79ecc: DecompressPointer r0
    //     0xf79ecc: add             x0, x0, HEAP, lsl #32
    // 0xf79ed0: stur            x0, [fp, #-8]
    // 0xf79ed4: LoadField: r1 = r0->field_b
    //     0xf79ed4: ldur            w1, [x0, #0xb]
    // 0xf79ed8: DecompressPointer r1
    //     0xf79ed8: add             x1, x1, HEAP, lsl #32
    // 0xf79edc: cmp             w1, NULL
    // 0xf79ee0: b.eq            #0xf79f18
    // 0xf79ee4: LoadField: r1 = r0->field_1f
    //     0xf79ee4: ldur            w1, [x0, #0x1f]
    // 0xf79ee8: DecompressPointer r1
    //     0xf79ee8: add             x1, x1, HEAP, lsl #32
    // 0xf79eec: cmp             w1, NULL
    // 0xf79ef0: b.eq            #0xf79f1c
    // 0xf79ef4: r0 = hasPrimaryFocus()
    //     0xf79ef4: bl              #0x83e41c  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::hasPrimaryFocus
    // 0xf79ef8: ldur            x1, [fp, #-8]
    // 0xf79efc: StoreField: r1->field_2b = r0
    //     0xf79efc: stur            w0, [x1, #0x2b]
    // 0xf79f00: r0 = Null
    //     0xf79f00: mov             x0, NULL
    // 0xf79f04: LeaveFrame
    //     0xf79f04: mov             SP, fp
    //     0xf79f08: ldp             fp, lr, [SP], #0x10
    // 0xf79f0c: ret
    //     0xf79f0c: ret             
    // 0xf79f10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf79f10: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf79f14: b               #0xf79ec8
    // 0xf79f18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf79f18: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf79f1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf79f1c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10dc9cc, size: 0xc0
    // 0x10dc9cc: EnterFrame
    //     0x10dc9cc: stp             fp, lr, [SP, #-0x10]!
    //     0x10dc9d0: mov             fp, SP
    // 0x10dc9d4: AllocStack(0x10)
    //     0x10dc9d4: sub             SP, SP, #0x10
    // 0x10dc9d8: SetupParameters(_DropdownButtonState<C1X0> this /* r1 => r0, fp-0x8 */)
    //     0x10dc9d8: mov             x0, x1
    //     0x10dc9dc: stur            x1, [fp, #-8]
    // 0x10dc9e0: CheckStackOverflow
    //     0x10dc9e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10dc9e4: cmp             SP, x16
    //     0x10dc9e8: b.ls            #0x10dca78
    // 0x10dc9ec: r1 = LoadStaticField(0x6a0)
    //     0x10dc9ec: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x10dc9f0: ldr             x1, [x1, #0xd40]
    // 0x10dc9f4: cmp             w1, NULL
    // 0x10dc9f8: b.eq            #0x10dca80
    // 0x10dc9fc: mov             x2, x0
    // 0x10dca00: r0 = removeObserver()
    //     0x10dca00: bl              #0xb3ac3c  ; [dart:mixin_deduplication] _MixinApplication208&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding&PaintingBinding&SemanticsBinding&RendererBinding&WidgetsBinding::removeObserver
    // 0x10dca04: ldur            x1, [fp, #-8]
    // 0x10dca08: r0 = _removeDropdownRoute()
    //     0x10dca08: bl              #0xd1e8e4  ; [package:flutter/src/material/dropdown.dart] _DropdownButtonState::_removeDropdownRoute
    // 0x10dca0c: ldur            x0, [fp, #-8]
    // 0x10dca10: LoadField: r1 = r0->field_b
    //     0x10dca10: ldur            w1, [x0, #0xb]
    // 0x10dca14: DecompressPointer r1
    //     0x10dca14: add             x1, x1, HEAP, lsl #32
    // 0x10dca18: cmp             w1, NULL
    // 0x10dca1c: b.eq            #0x10dca84
    // 0x10dca20: LoadField: r3 = r0->field_1f
    //     0x10dca20: ldur            w3, [x0, #0x1f]
    // 0x10dca24: DecompressPointer r3
    //     0x10dca24: add             x3, x3, HEAP, lsl #32
    // 0x10dca28: stur            x3, [fp, #-0x10]
    // 0x10dca2c: cmp             w3, NULL
    // 0x10dca30: b.eq            #0x10dca88
    // 0x10dca34: mov             x2, x0
    // 0x10dca38: r1 = Function '_handleFocusChanged@83005770':.
    //     0x10dca38: add             x1, PP, #0x99, lsl #12  ; [pp+0x99a60] AnonymousClosure: (0xf79dbc), in [package:flutter/src/material/dropdown.dart] _DropdownButtonState::_handleFocusChanged (0xf79df4)
    //     0x10dca3c: ldr             x1, [x1, #0xa60]
    // 0x10dca40: r0 = AllocateClosure()
    //     0x10dca40: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10dca44: ldur            x1, [fp, #-0x10]
    // 0x10dca48: mov             x2, x0
    // 0x10dca4c: r0 = removeListener()
    //     0x10dca4c: bl              #0xcff298  ; [dart:mixin_deduplication] _MixinApplication219&Object&DiagnosticableTreeMixin&ChangeNotifier::removeListener
    // 0x10dca50: ldur            x0, [fp, #-8]
    // 0x10dca54: LoadField: r1 = r0->field_1f
    //     0x10dca54: ldur            w1, [x0, #0x1f]
    // 0x10dca58: DecompressPointer r1
    //     0x10dca58: add             x1, x1, HEAP, lsl #32
    // 0x10dca5c: cmp             w1, NULL
    // 0x10dca60: b.eq            #0x10dca68
    // 0x10dca64: r0 = dispose()
    //     0x10dca64: bl              #0x10ec024  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::dispose
    // 0x10dca68: r0 = Null
    //     0x10dca68: mov             x0, NULL
    // 0x10dca6c: LeaveFrame
    //     0x10dca6c: mov             SP, fp
    //     0x10dca70: ldp             fp, lr, [SP], #0x10
    // 0x10dca74: ret
    //     0x10dca74: ret             
    // 0x10dca78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10dca78: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10dca7c: b               #0x10dc9ec
    // 0x10dca80: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10dca80: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x10dca84: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10dca84: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x10dca88: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10dca88: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 6157, size: 0x14, field offset: 0xc
//   const constructor, 
class _DropdownMenuItemContainer extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfb9fc4, size: 0xa8
    // 0xfb9fc4: EnterFrame
    //     0xfb9fc4: stp             fp, lr, [SP, #-0x10]!
    //     0xfb9fc8: mov             fp, SP
    // 0xfb9fcc: AllocStack(0x28)
    //     0xfb9fcc: sub             SP, SP, #0x28
    // 0xfb9fd0: CheckStackOverflow
    //     0xfb9fd0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb9fd4: cmp             SP, x16
    //     0xfb9fd8: b.ls            #0xfba064
    // 0xfb9fdc: LoadField: r0 = r1->field_f
    //     0xfb9fdc: ldur            w0, [x1, #0xf]
    // 0xfb9fe0: DecompressPointer r0
    //     0xfb9fe0: add             x0, x0, HEAP, lsl #32
    // 0xfb9fe4: stur            x0, [fp, #-0x10]
    // 0xfb9fe8: LoadField: r2 = r1->field_b
    //     0xfb9fe8: ldur            w2, [x1, #0xb]
    // 0xfb9fec: DecompressPointer r2
    //     0xfb9fec: add             x2, x2, HEAP, lsl #32
    // 0xfb9ff0: stur            x2, [fp, #-8]
    // 0xfb9ff4: r0 = Align()
    //     0xfb9ff4: bl              #0xb281f8  ; AllocateAlignStub -> Align (size=0x1c)
    // 0xfb9ff8: mov             x1, x0
    // 0xfb9ffc: ldur            x0, [fp, #-0x10]
    // 0xfba000: stur            x1, [fp, #-0x18]
    // 0xfba004: StoreField: r1->field_f = r0
    //     0xfba004: stur            w0, [x1, #0xf]
    // 0xfba008: ldur            x0, [fp, #-8]
    // 0xfba00c: StoreField: r1->field_b = r0
    //     0xfba00c: stur            w0, [x1, #0xb]
    // 0xfba010: r0 = ConstrainedBox()
    //     0xfba010: bl              #0xd0a588  ; AllocateConstrainedBoxStub -> ConstrainedBox (size=0x14)
    // 0xfba014: mov             x1, x0
    // 0xfba018: r0 = Instance_BoxConstraints
    //     0xfba018: add             x0, PP, #0x8f, lsl #12  ; [pp+0x8ff00] Obj!BoxConstraints@129c471
    //     0xfba01c: ldr             x0, [x0, #0xf00]
    // 0xfba020: stur            x1, [fp, #-8]
    // 0xfba024: StoreField: r1->field_f = r0
    //     0xfba024: stur            w0, [x1, #0xf]
    // 0xfba028: ldur            x0, [fp, #-0x18]
    // 0xfba02c: StoreField: r1->field_b = r0
    //     0xfba02c: stur            w0, [x1, #0xb]
    // 0xfba030: r0 = Semantics()
    //     0xfba030: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xfba034: stur            x0, [fp, #-0x10]
    // 0xfba038: r16 = true
    //     0xfba038: add             x16, NULL, #0x20  ; true
    // 0xfba03c: ldur            lr, [fp, #-8]
    // 0xfba040: stp             lr, x16, [SP]
    // 0xfba044: mov             x1, x0
    // 0xfba048: r4 = const [0, 0x3, 0x2, 0x1, button, 0x1, child, 0x2, null]
    //     0xfba048: add             x4, PP, #0x8f, lsl #12  ; [pp+0x8ff08] List(9) [0, 0x3, 0x2, 0x1, "button", 0x1, "child", 0x2, Null]
    //     0xfba04c: ldr             x4, [x4, #0xf08]
    // 0xfba050: r0 = Semantics()
    //     0xfba050: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xfba054: ldur            x0, [fp, #-0x10]
    // 0xfba058: LeaveFrame
    //     0xfba058: mov             SP, fp
    //     0xfba05c: ldp             fp, lr, [SP], #0x10
    // 0xfba060: ret
    //     0xfba060: ret             
    // 0xfba064: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfba064: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfba068: b               #0xfb9fdc
  }
}

// class id: 6158, size: 0x24, field offset: 0x14
//   const constructor, 
class DropdownMenuItem<X0> extends _DropdownMenuItemContainer {

  const X0? dyn:get:value(DropdownMenuItem<X0>) {
    // ** addr: 0x8e9afc, size: 0x28
    // 0x8e9afc: ldr             x1, [SP]
    // 0x8e9b00: LoadField: r0 = r1->field_1b
    //     0x8e9b00: ldur            w0, [x1, #0x1b]
    // 0x8e9b04: DecompressPointer r0
    //     0x8e9b04: add             x0, x0, HEAP, lsl #32
    // 0x8e9b08: ret
    //     0x8e9b08: ret             
  }
}

// class id: 6479, size: 0x34, field offset: 0x30
class DropdownButtonFormField<X0> extends FormField<X0> {

  _ DropdownButtonFormField(/* No info */) {
    // ** addr: 0xe62c14, size: 0x424
    // 0xe62c14: EnterFrame
    //     0xe62c14: stp             fp, lr, [SP, #-0x10]!
    //     0xe62c18: mov             fp, SP
    // 0xe62c1c: AllocStack(0x68)
    //     0xe62c1c: sub             SP, SP, #0x68
    // 0xe62c20: SetupParameters(DropdownButtonFormField<X0> this /* r1 => r1, fp-0x48 */, dynamic _ /* r2 => r2, fp-0x50 */, dynamic _ /* r3 => r3, fp-0x58 */, dynamic _ /* r5 => r0, fp-0x60 */, dynamic _ /* r6 => r6, fp-0x68 */, {dynamic alignment = Instance_AlignmentDirectional /* r7, fp-0x40 */, dynamic decoration = Null /* r8, fp-0x38 */, dynamic hint = Null /* r9, fp-0x30 */, dynamic icon = Null /* r10, fp-0x28 */, dynamic initialValue = Null /* r12, fp-0x20 */, dynamic isExpanded = false /* r11, fp-0x18 */, dynamic menuMaxHeight = Null /* r13, fp-0x10 */, dynamic validator = Null /* r4, fp-0x8 */})
    //     0xe62c20: mov             x0, x5
    //     0xe62c24: stur            x1, [fp, #-0x48]
    //     0xe62c28: stur            x2, [fp, #-0x50]
    //     0xe62c2c: stur            x3, [fp, #-0x58]
    //     0xe62c30: stur            x5, [fp, #-0x60]
    //     0xe62c34: stur            x6, [fp, #-0x68]
    //     0xe62c38: ldur            w5, [x4, #0x13]
    //     0xe62c3c: ldur            w7, [x4, #0x1f]
    //     0xe62c40: add             x7, x7, HEAP, lsl #32
    //     0xe62c44: ldr             x16, [PP, #0x5c70]  ; [pp+0x5c70] "alignment"
    //     0xe62c48: cmp             w7, w16
    //     0xe62c4c: b.ne            #0xe62c6c
    //     0xe62c50: ldur            w7, [x4, #0x23]
    //     0xe62c54: add             x7, x7, HEAP, lsl #32
    //     0xe62c58: sub             w8, w5, w7
    //     0xe62c5c: add             x7, fp, w8, sxtw #2
    //     0xe62c60: ldr             x7, [x7, #8]
    //     0xe62c64: mov             x8, #1
    //     0xe62c68: b               #0xe62c78
    //     0xe62c6c: mov             x8, #0
    //     0xe62c70: add             x7, PP, #0x28, lsl #12  ; [pp+0x28258] Obj!AlignmentDirectional@129e651
    //     0xe62c74: ldr             x7, [x7, #0x258]
    //     0xe62c78: stur            x7, [fp, #-0x40]
    //     0xe62c7c: lsl             x9, x8, #1
    //     0xe62c80: lsl             w10, w9, #1
    //     0xe62c84: add             w11, w10, #8
    //     0xe62c88: add             x16, x4, w11, sxtw #1
    //     0xe62c8c: ldur            w12, [x16, #0xf]
    //     0xe62c90: add             x12, x12, HEAP, lsl #32
    //     0xe62c94: ldr             x16, [PP, #0x4a78]  ; [pp+0x4a78] "decoration"
    //     0xe62c98: cmp             w12, w16
    //     0xe62c9c: b.ne            #0xe62ccc
    //     0xe62ca0: add             w8, w10, #0xa
    //     0xe62ca4: add             x16, x4, w8, sxtw #1
    //     0xe62ca8: ldur            w10, [x16, #0xf]
    //     0xe62cac: add             x10, x10, HEAP, lsl #32
    //     0xe62cb0: sub             w8, w5, w10
    //     0xe62cb4: add             x10, fp, w8, sxtw #2
    //     0xe62cb8: ldr             x10, [x10, #8]
    //     0xe62cbc: add             w8, w9, #2
    //     0xe62cc0: sbfx            x9, x8, #1, #0x1f
    //     0xe62cc4: mov             x8, x10
    //     0xe62cc8: b               #0xe62cd4
    //     0xe62ccc: mov             x9, x8
    //     0xe62cd0: mov             x8, NULL
    //     0xe62cd4: stur            x8, [fp, #-0x38]
    //     0xe62cd8: lsl             x10, x9, #1
    //     0xe62cdc: lsl             w11, w10, #1
    //     0xe62ce0: add             w12, w11, #8
    //     0xe62ce4: add             x16, x4, w12, sxtw #1
    //     0xe62ce8: ldur            w13, [x16, #0xf]
    //     0xe62cec: add             x13, x13, HEAP, lsl #32
    //     0xe62cf0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15150] "hint"
    //     0xe62cf4: ldr             x16, [x16, #0x150]
    //     0xe62cf8: cmp             w13, w16
    //     0xe62cfc: b.ne            #0xe62d2c
    //     0xe62d00: add             w9, w11, #0xa
    //     0xe62d04: add             x16, x4, w9, sxtw #1
    //     0xe62d08: ldur            w11, [x16, #0xf]
    //     0xe62d0c: add             x11, x11, HEAP, lsl #32
    //     0xe62d10: sub             w9, w5, w11
    //     0xe62d14: add             x11, fp, w9, sxtw #2
    //     0xe62d18: ldr             x11, [x11, #8]
    //     0xe62d1c: add             w9, w10, #2
    //     0xe62d20: sbfx            x10, x9, #1, #0x1f
    //     0xe62d24: mov             x9, x11
    //     0xe62d28: b               #0xe62d34
    //     0xe62d2c: mov             x10, x9
    //     0xe62d30: mov             x9, NULL
    //     0xe62d34: stur            x9, [fp, #-0x30]
    //     0xe62d38: lsl             x11, x10, #1
    //     0xe62d3c: lsl             w12, w11, #1
    //     0xe62d40: add             w13, w12, #8
    //     0xe62d44: add             x16, x4, w13, sxtw #1
    //     0xe62d48: ldur            w14, [x16, #0xf]
    //     0xe62d4c: add             x14, x14, HEAP, lsl #32
    //     0xe62d50: add             x16, PP, #8, lsl #12  ; [pp+0x82f8] "icon"
    //     0xe62d54: ldr             x16, [x16, #0x2f8]
    //     0xe62d58: cmp             w14, w16
    //     0xe62d5c: b.ne            #0xe62d8c
    //     0xe62d60: add             w10, w12, #0xa
    //     0xe62d64: add             x16, x4, w10, sxtw #1
    //     0xe62d68: ldur            w12, [x16, #0xf]
    //     0xe62d6c: add             x12, x12, HEAP, lsl #32
    //     0xe62d70: sub             w10, w5, w12
    //     0xe62d74: add             x12, fp, w10, sxtw #2
    //     0xe62d78: ldr             x12, [x12, #8]
    //     0xe62d7c: add             w10, w11, #2
    //     0xe62d80: sbfx            x11, x10, #1, #0x1f
    //     0xe62d84: mov             x10, x12
    //     0xe62d88: b               #0xe62d94
    //     0xe62d8c: mov             x11, x10
    //     0xe62d90: mov             x10, NULL
    //     0xe62d94: stur            x10, [fp, #-0x28]
    //     0xe62d98: lsl             x12, x11, #1
    //     0xe62d9c: lsl             w13, w12, #1
    //     0xe62da0: add             w14, w13, #8
    //     0xe62da4: add             x16, x4, w14, sxtw #1
    //     0xe62da8: ldur            w19, [x16, #0xf]
    //     0xe62dac: add             x19, x19, HEAP, lsl #32
    //     0xe62db0: add             x16, PP, #0x28, lsl #12  ; [pp+0x28260] "initialValue"
    //     0xe62db4: ldr             x16, [x16, #0x260]
    //     0xe62db8: cmp             w19, w16
    //     0xe62dbc: b.ne            #0xe62df0
    //     0xe62dc0: add             w11, w13, #0xa
    //     0xe62dc4: add             x16, x4, w11, sxtw #1
    //     0xe62dc8: ldur            w13, [x16, #0xf]
    //     0xe62dcc: add             x13, x13, HEAP, lsl #32
    //     0xe62dd0: sub             w11, w5, w13
    //     0xe62dd4: add             x13, fp, w11, sxtw #2
    //     0xe62dd8: ldr             x13, [x13, #8]
    //     0xe62ddc: add             w11, w12, #2
    //     0xe62de0: sbfx            x12, x11, #1, #0x1f
    //     0xe62de4: mov             x11, x12
    //     0xe62de8: mov             x12, x13
    //     0xe62dec: b               #0xe62df4
    //     0xe62df0: mov             x12, NULL
    //     0xe62df4: stur            x12, [fp, #-0x20]
    //     0xe62df8: lsl             x13, x11, #1
    //     0xe62dfc: lsl             w14, w13, #1
    //     0xe62e00: add             w19, w14, #8
    //     0xe62e04: add             x16, x4, w19, sxtw #1
    //     0xe62e08: ldur            w20, [x16, #0xf]
    //     0xe62e0c: add             x20, x20, HEAP, lsl #32
    //     0xe62e10: ldr             x16, [PP, #0x2798]  ; [pp+0x2798] "isExpanded"
    //     0xe62e14: cmp             w20, w16
    //     0xe62e18: b.ne            #0xe62e48
    //     0xe62e1c: add             w11, w14, #0xa
    //     0xe62e20: add             x16, x4, w11, sxtw #1
    //     0xe62e24: ldur            w14, [x16, #0xf]
    //     0xe62e28: add             x14, x14, HEAP, lsl #32
    //     0xe62e2c: sub             w11, w5, w14
    //     0xe62e30: add             x14, fp, w11, sxtw #2
    //     0xe62e34: ldr             x14, [x14, #8]
    //     0xe62e38: add             w11, w13, #2
    //     0xe62e3c: sbfx            x13, x11, #1, #0x1f
    //     0xe62e40: mov             x11, x14
    //     0xe62e44: b               #0xe62e50
    //     0xe62e48: mov             x13, x11
    //     0xe62e4c: add             x11, NULL, #0x30  ; false
    //     0xe62e50: stur            x11, [fp, #-0x18]
    //     0xe62e54: lsl             x14, x13, #1
    //     0xe62e58: lsl             w19, w14, #1
    //     0xe62e5c: add             w20, w19, #8
    //     0xe62e60: add             x16, x4, w20, sxtw #1
    //     0xe62e64: ldur            w23, [x16, #0xf]
    //     0xe62e68: add             x23, x23, HEAP, lsl #32
    //     0xe62e6c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28268] "menuMaxHeight"
    //     0xe62e70: ldr             x16, [x16, #0x268]
    //     0xe62e74: cmp             w23, w16
    //     0xe62e78: b.ne            #0xe62ea8
    //     0xe62e7c: add             w13, w19, #0xa
    //     0xe62e80: add             x16, x4, w13, sxtw #1
    //     0xe62e84: ldur            w19, [x16, #0xf]
    //     0xe62e88: add             x19, x19, HEAP, lsl #32
    //     0xe62e8c: sub             w13, w5, w19
    //     0xe62e90: add             x19, fp, w13, sxtw #2
    //     0xe62e94: ldr             x19, [x19, #8]
    //     0xe62e98: add             w13, w14, #2
    //     0xe62e9c: sbfx            x14, x13, #1, #0x1f
    //     0xe62ea0: mov             x13, x19
    //     0xe62ea4: b               #0xe62eb0
    //     0xe62ea8: mov             x14, x13
    //     0xe62eac: mov             x13, NULL
    //     0xe62eb0: stur            x13, [fp, #-0x10]
    //     0xe62eb4: lsl             x19, x14, #1
    //     0xe62eb8: lsl             w14, w19, #1
    //     0xe62ebc: add             w19, w14, #8
    //     0xe62ec0: add             x16, x4, w19, sxtw #1
    //     0xe62ec4: ldur            w20, [x16, #0xf]
    //     0xe62ec8: add             x20, x20, HEAP, lsl #32
    //     0xe62ecc: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a5f8] "validator"
    //     0xe62ed0: ldr             x16, [x16, #0x5f8]
    //     0xe62ed4: cmp             w20, w16
    //     0xe62ed8: b.ne            #0xe62f00
    //     0xe62edc: add             w19, w14, #0xa
    //     0xe62ee0: add             x16, x4, w19, sxtw #1
    //     0xe62ee4: ldur            w14, [x16, #0xf]
    //     0xe62ee8: add             x14, x14, HEAP, lsl #32
    //     0xe62eec: sub             w4, w5, w14
    //     0xe62ef0: add             x5, fp, w4, sxtw #2
    //     0xe62ef4: ldr             x5, [x5, #8]
    //     0xe62ef8: mov             x4, x5
    //     0xe62efc: b               #0xe62f04
    //     0xe62f00: mov             x4, NULL
    //     0xe62f04: stur            x4, [fp, #-8]
    // 0xe62f08: r1 = 10
    //     0xe62f08: mov             x1, #0xa
    // 0xe62f0c: r0 = AllocateContext()
    //     0xe62f0c: bl              #0x13de838  ; AllocateContextStub
    // 0xe62f10: mov             x1, x0
    // 0xe62f14: ldur            x4, [fp, #-0x48]
    // 0xe62f18: StoreField: r1->field_f = r4
    //     0xe62f18: stur            w4, [x1, #0xf]
    // 0xe62f1c: ldur            x0, [fp, #-0x50]
    // 0xe62f20: StoreField: r1->field_13 = r0
    //     0xe62f20: stur            w0, [x1, #0x13]
    // 0xe62f24: ldur            x0, [fp, #-0x58]
    // 0xe62f28: ArrayStore: r1[0] = r0  ; List_4
    //     0xe62f28: stur            w0, [x1, #0x17]
    // 0xe62f2c: ldur            x0, [fp, #-0x68]
    // 0xe62f30: StoreField: r1->field_1b = r0
    //     0xe62f30: stur            w0, [x1, #0x1b]
    // 0xe62f34: ldur            x0, [fp, #-0x40]
    // 0xe62f38: StoreField: r1->field_1f = r0
    //     0xe62f38: stur            w0, [x1, #0x1f]
    // 0xe62f3c: ldur            x0, [fp, #-0x38]
    // 0xe62f40: StoreField: r1->field_23 = r0
    //     0xe62f40: stur            w0, [x1, #0x23]
    // 0xe62f44: ldur            x0, [fp, #-0x30]
    // 0xe62f48: StoreField: r1->field_27 = r0
    //     0xe62f48: stur            w0, [x1, #0x27]
    // 0xe62f4c: ldur            x0, [fp, #-0x28]
    // 0xe62f50: StoreField: r1->field_2b = r0
    //     0xe62f50: stur            w0, [x1, #0x2b]
    // 0xe62f54: ldur            x0, [fp, #-0x18]
    // 0xe62f58: StoreField: r1->field_2f = r0
    //     0xe62f58: stur            w0, [x1, #0x2f]
    // 0xe62f5c: ldur            x0, [fp, #-0x10]
    // 0xe62f60: StoreField: r1->field_33 = r0
    //     0xe62f60: stur            w0, [x1, #0x33]
    // 0xe62f64: ldur            x0, [fp, #-0x60]
    // 0xe62f68: StoreField: r4->field_2f = r0
    //     0xe62f68: stur            w0, [x4, #0x2f]
    //     0xe62f6c: ldurb           w16, [x4, #-1]
    //     0xe62f70: ldurb           w17, [x0, #-1]
    //     0xe62f74: and             x16, x17, x16, lsr #2
    //     0xe62f78: tst             x16, HEAP, lsr #32
    //     0xe62f7c: b.eq            #0xe62f84
    //     0xe62f80: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xe62f84: ldur            x0, [fp, #-0x20]
    // 0xe62f88: cmp             w0, NULL
    // 0xe62f8c: b.ne            #0xe62f94
    // 0xe62f90: r0 = Null
    //     0xe62f90: mov             x0, NULL
    // 0xe62f94: stur            x0, [fp, #-0x10]
    // 0xe62f98: LoadField: r3 = r4->field_b
    //     0xe62f98: ldur            w3, [x4, #0xb]
    // 0xe62f9c: DecompressPointer r3
    //     0xe62f9c: add             x3, x3, HEAP, lsl #32
    // 0xe62fa0: mov             x2, x1
    // 0xe62fa4: r1 = Function '<anonymous closure>':.
    //     0xe62fa4: add             x1, PP, #0x28, lsl #12  ; [pp+0x28270] AnonymousClosure: (0xe63038), in [package:flutter/src/material/dropdown.dart] DropdownButtonFormField::DropdownButtonFormField (0xe62c14)
    //     0xe62fa8: ldr             x1, [x1, #0x270]
    // 0xe62fac: r0 = AllocateClosureTA()
    //     0xe62fac: bl              #0x13dea48  ; AllocateClosureTAStub
    // 0xe62fb0: ldur            x1, [fp, #-0x48]
    // 0xe62fb4: StoreField: r1->field_f = r0
    //     0xe62fb4: stur            w0, [x1, #0xf]
    //     0xe62fb8: ldurb           w16, [x1, #-1]
    //     0xe62fbc: ldurb           w17, [x0, #-1]
    //     0xe62fc0: and             x16, x17, x16, lsr #2
    //     0xe62fc4: tst             x16, HEAP, lsr #32
    //     0xe62fc8: b.eq            #0xe62fd0
    //     0xe62fcc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xe62fd0: ldur            x0, [fp, #-8]
    // 0xe62fd4: StoreField: r1->field_1b = r0
    //     0xe62fd4: stur            w0, [x1, #0x1b]
    //     0xe62fd8: ldurb           w16, [x1, #-1]
    //     0xe62fdc: ldurb           w17, [x0, #-1]
    //     0xe62fe0: and             x16, x17, x16, lsr #2
    //     0xe62fe4: tst             x16, HEAP, lsr #32
    //     0xe62fe8: b.eq            #0xe62ff0
    //     0xe62fec: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xe62ff0: ldur            x0, [fp, #-0x10]
    // 0xe62ff4: StoreField: r1->field_1f = r0
    //     0xe62ff4: stur            w0, [x1, #0x1f]
    //     0xe62ff8: tbz             w0, #0, #0xe63014
    //     0xe62ffc: ldurb           w16, [x1, #-1]
    //     0xe63000: ldurb           w17, [x0, #-1]
    //     0xe63004: and             x16, x17, x16, lsr #2
    //     0xe63008: tst             x16, HEAP, lsr #32
    //     0xe6300c: b.eq            #0xe63014
    //     0xe63010: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xe63014: r2 = true
    //     0xe63014: add             x2, NULL, #0x20  ; true
    // 0xe63018: StoreField: r1->field_23 = r2
    //     0xe63018: stur            w2, [x1, #0x23]
    // 0xe6301c: r2 = Instance_AutovalidateMode
    //     0xe6301c: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1a608] Obj!AutovalidateMode@12c3061
    //     0xe63020: ldr             x2, [x2, #0x608]
    // 0xe63024: StoreField: r1->field_27 = r2
    //     0xe63024: stur            w2, [x1, #0x27]
    // 0xe63028: r0 = Null
    //     0xe63028: mov             x0, NULL
    // 0xe6302c: LeaveFrame
    //     0xe6302c: mov             SP, fp
    //     0xe63030: ldp             fp, lr, [SP], #0x10
    // 0xe63034: ret
    //     0xe63034: ret             
  }
  [closure] Focus <anonymous closure>(dynamic, FormFieldState<X0>) {
    // ** addr: 0xe63038, size: 0x4d8
    // 0xe63038: EnterFrame
    //     0xe63038: stp             fp, lr, [SP, #-0x10]!
    //     0xe6303c: mov             fp, SP
    // 0xe63040: AllocStack(0xb0)
    //     0xe63040: sub             SP, SP, #0xb0
    // 0xe63044: SetupParameters([dynamic _ /* r0 */])
    //     0xe63044: ldr             x0, [fp, #0x18]
    //     0xe63048: ldur            w1, [x0, #0x17]
    //     0xe6304c: add             x1, x1, HEAP, lsl #32
    //     0xe63050: stur            x1, [fp, #-8]
    // 0xe63054: CheckStackOverflow
    //     0xe63054: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe63058: cmp             SP, x16
    //     0xe6305c: b.ls            #0xe634f8
    // 0xe63060: r1 = 1
    //     0xe63060: mov             x1, #1
    // 0xe63064: r0 = AllocateContext()
    //     0xe63064: bl              #0x13de838  ; AllocateContextStub
    // 0xe63068: mov             x4, x0
    // 0xe6306c: ldur            x3, [fp, #-8]
    // 0xe63070: stur            x4, [fp, #-0x10]
    // 0xe63074: StoreField: r4->field_b = r3
    //     0xe63074: stur            w3, [x4, #0xb]
    // 0xe63078: LoadField: r0 = r3->field_f
    //     0xe63078: ldur            w0, [x3, #0xf]
    // 0xe6307c: DecompressPointer r0
    //     0xe6307c: add             x0, x0, HEAP, lsl #32
    // 0xe63080: LoadField: r2 = r0->field_b
    //     0xe63080: ldur            w2, [x0, #0xb]
    // 0xe63084: DecompressPointer r2
    //     0xe63084: add             x2, x2, HEAP, lsl #32
    // 0xe63088: ldr             x0, [fp, #0x10]
    // 0xe6308c: r1 = Null
    //     0xe6308c: mov             x1, NULL
    // 0xe63090: r8 = _DropdownButtonFormFieldState<X0>
    //     0xe63090: add             x8, PP, #0x28, lsl #12  ; [pp+0x28278] Type: _DropdownButtonFormFieldState<X0>
    //     0xe63094: ldr             x8, [x8, #0x278]
    // 0xe63098: LoadField: r9 = r8->field_7
    //     0xe63098: ldur            x9, [x8, #7]
    // 0xe6309c: r3 = Null
    //     0xe6309c: add             x3, PP, #0x28, lsl #12  ; [pp+0x28280] Null
    //     0xe630a0: ldr             x3, [x3, #0x280]
    // 0xe630a4: blr             x9
    // 0xe630a8: ldr             x0, [fp, #0x10]
    // 0xe630ac: ldur            x2, [fp, #-0x10]
    // 0xe630b0: StoreField: r2->field_f = r0
    //     0xe630b0: stur            w0, [x2, #0xf]
    // 0xe630b4: ldur            x3, [fp, #-8]
    // 0xe630b8: LoadField: r1 = r3->field_23
    //     0xe630b8: ldur            w1, [x3, #0x23]
    // 0xe630bc: DecompressPointer r1
    //     0xe630bc: add             x1, x1, HEAP, lsl #32
    // 0xe630c0: cmp             w1, NULL
    // 0xe630c4: b.ne            #0xe630d4
    // 0xe630c8: r4 = Instance_InputDecoration
    //     0xe630c8: add             x4, PP, #0x28, lsl #12  ; [pp+0x28290] Obj!InputDecoration@129ea41
    //     0xe630cc: ldr             x4, [x4, #0x290]
    // 0xe630d0: b               #0xe630d8
    // 0xe630d4: mov             x4, x1
    // 0xe630d8: stur            x4, [fp, #-0x18]
    // 0xe630dc: LoadField: r1 = r0->field_f
    //     0xe630dc: ldur            w1, [x0, #0xf]
    // 0xe630e0: DecompressPointer r1
    //     0xe630e0: add             x1, x1, HEAP, lsl #32
    // 0xe630e4: cmp             w1, NULL
    // 0xe630e8: b.eq            #0xe63500
    // 0xe630ec: r0 = of()
    //     0xe630ec: bl              #0xd1e0d0  ; [package:flutter/src/material/input_decorator.dart] InputDecorationTheme::of
    // 0xe630f0: ldur            x1, [fp, #-0x18]
    // 0xe630f4: mov             x2, x0
    // 0xe630f8: r0 = applyDefaults()
    //     0xe630f8: bl              #0xd2d7ec  ; [package:flutter/src/material/input_decorator.dart] InputDecoration::applyDefaults
    // 0xe630fc: mov             x4, x0
    // 0xe63100: ldur            x0, [fp, #-8]
    // 0xe63104: stur            x4, [fp, #-0x20]
    // 0xe63108: ArrayLoad: r5 = r0[0]  ; List_4
    //     0xe63108: ldur            w5, [x0, #0x17]
    // 0xe6310c: DecompressPointer r5
    //     0xe6310c: add             x5, x5, HEAP, lsl #32
    // 0xe63110: stur            x5, [fp, #-0x18]
    // 0xe63114: LoadField: r1 = r0->field_f
    //     0xe63114: ldur            w1, [x0, #0xf]
    // 0xe63118: DecompressPointer r1
    //     0xe63118: add             x1, x1, HEAP, lsl #32
    // 0xe6311c: LoadField: r3 = r1->field_b
    //     0xe6311c: ldur            w3, [x1, #0xb]
    // 0xe63120: DecompressPointer r3
    //     0xe63120: add             x3, x3, HEAP, lsl #32
    // 0xe63124: ldur            x2, [fp, #-0x10]
    // 0xe63128: r1 = Function '<anonymous closure>':.
    //     0xe63128: add             x1, PP, #0x28, lsl #12  ; [pp+0x28298] AnonymousClosure: (0xe63968), in [package:flutter/src/material/dropdown.dart] DropdownButtonFormField::DropdownButtonFormField (0xe62c14)
    //     0xe6312c: ldr             x1, [x1, #0x298]
    // 0xe63130: r0 = AllocateClosureTA()
    //     0xe63130: bl              #0x13dea48  ; AllocateClosureTAStub
    // 0xe63134: ldur            x1, [fp, #-0x18]
    // 0xe63138: mov             x2, x0
    // 0xe6313c: r0 = where()
    //     0xe6313c: bl              #0xb92e4c  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::where
    // 0xe63140: mov             x1, x0
    // 0xe63144: r0 = iterator()
    //     0xe63144: bl              #0xb0a104  ; [dart:_internal] WhereIterable::iterator
    // 0xe63148: r1 = LoadClassIdInstr(r0)
    //     0xe63148: ldur            x1, [x0, #-1]
    //     0xe6314c: ubfx            x1, x1, #0xc, #0x14
    // 0xe63150: mov             x16, x0
    // 0xe63154: mov             x0, x1
    // 0xe63158: mov             x1, x16
    // 0xe6315c: r0 = GDT[cid_x0 + 0x1845b]()
    //     0xe6315c: mov             x17, #0x845b
    //     0xe63160: movk            x17, #1, lsl #16
    //     0xe63164: add             lr, x0, x17
    //     0xe63168: ldr             lr, [x21, lr, lsl #3]
    //     0xe6316c: blr             lr
    // 0xe63170: eor             x1, x0, #0x10
    // 0xe63174: eor             x0, x1, #0x10
    // 0xe63178: ldur            x1, [fp, #-8]
    // 0xe6317c: stur            x0, [fp, #-0x28]
    // 0xe63180: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xe63180: ldur            w2, [x1, #0x17]
    // 0xe63184: DecompressPointer r2
    //     0xe63184: add             x2, x2, HEAP, lsl #32
    // 0xe63188: LoadField: r3 = r2->field_b
    //     0xe63188: ldur            w3, [x2, #0xb]
    // 0xe6318c: ldur            x2, [fp, #-0x20]
    // 0xe63190: stur            x3, [fp, #-0x18]
    // 0xe63194: LoadField: r4 = r2->field_2f
    //     0xe63194: ldur            w4, [x2, #0x2f]
    // 0xe63198: DecompressPointer r4
    //     0xe63198: add             x4, x4, HEAP, lsl #32
    // 0xe6319c: stur            x4, [fp, #-0x10]
    // 0xe631a0: cmp             w4, NULL
    // 0xe631a4: b.eq            #0xe631b8
    // 0xe631a8: r0 = Text()
    //     0xe631a8: bl              #0x8a70a4  ; AllocateTextStub -> Text (size=0x50)
    // 0xe631ac: ldur            x3, [fp, #-0x10]
    // 0xe631b0: StoreField: r0->field_b = r3
    //     0xe631b0: stur            w3, [x0, #0xb]
    // 0xe631b4: b               #0xe631c0
    // 0xe631b8: mov             x3, x4
    // 0xe631bc: r0 = Null
    //     0xe631bc: mov             x0, NULL
    // 0xe631c0: ldur            x4, [fp, #-8]
    // 0xe631c4: LoadField: r1 = r4->field_27
    //     0xe631c4: ldur            w1, [x4, #0x27]
    // 0xe631c8: DecompressPointer r1
    //     0xe631c8: add             x1, x1, HEAP, lsl #32
    // 0xe631cc: cmp             w1, NULL
    // 0xe631d0: b.ne            #0xe631dc
    // 0xe631d4: mov             x6, x0
    // 0xe631d8: b               #0xe631e0
    // 0xe631dc: mov             x6, x1
    // 0xe631e0: ldur            x0, [fp, #-0x18]
    // 0xe631e4: stur            x6, [fp, #-0x38]
    // 0xe631e8: cbz             w0, #0xe63204
    // 0xe631ec: cmp             w6, NULL
    // 0xe631f0: r16 = true
    //     0xe631f0: add             x16, NULL, #0x20  ; true
    // 0xe631f4: r17 = false
    //     0xe631f4: add             x17, NULL, #0x30  ; false
    // 0xe631f8: csel            x0, x16, x17, ne
    // 0xe631fc: mov             x1, x0
    // 0xe63200: b               #0xe6321c
    // 0xe63204: cmp             w6, NULL
    // 0xe63208: b.eq            #0xe63214
    // 0xe6320c: r0 = true
    //     0xe6320c: add             x0, NULL, #0x20  ; true
    // 0xe63210: b               #0xe63218
    // 0xe63214: r0 = false
    //     0xe63214: add             x0, NULL, #0x30  ; false
    // 0xe63218: mov             x1, x0
    // 0xe6321c: ldur            x0, [fp, #-0x28]
    // 0xe63220: tbz             w0, #4, #0xe63230
    // 0xe63224: eor             x0, x1, #0x10
    // 0xe63228: mov             x7, x0
    // 0xe6322c: b               #0xe63234
    // 0xe63230: r7 = false
    //     0xe63230: add             x7, NULL, #0x30  ; false
    // 0xe63234: ldr             x5, [fp, #0x10]
    // 0xe63238: stur            x7, [fp, #-0x30]
    // 0xe6323c: LoadField: r8 = r5->field_27
    //     0xe6323c: ldur            w8, [x5, #0x27]
    // 0xe63240: DecompressPointer r8
    //     0xe63240: add             x8, x8, HEAP, lsl #32
    // 0xe63244: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xe63248: cmp             w8, w16
    // 0xe6324c: b.eq            #0xe63504
    // 0xe63250: stur            x8, [fp, #-0x28]
    // 0xe63254: LoadField: r9 = r8->field_33
    //     0xe63254: ldur            w9, [x8, #0x33]
    // 0xe63258: DecompressPointer r9
    //     0xe63258: add             x9, x9, HEAP, lsl #32
    // 0xe6325c: stur            x9, [fp, #-0x18]
    // 0xe63260: cmp             w9, NULL
    // 0xe63264: b.ne            #0xe6329c
    // 0xe63268: LoadField: r2 = r8->field_23
    //     0xe63268: ldur            w2, [x8, #0x23]
    // 0xe6326c: DecompressPointer r2
    //     0xe6326c: add             x2, x2, HEAP, lsl #32
    // 0xe63270: mov             x0, x9
    // 0xe63274: r1 = Null
    //     0xe63274: mov             x1, NULL
    // 0xe63278: cmp             w2, NULL
    // 0xe6327c: b.eq            #0xe6329c
    // 0xe63280: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xe63280: ldur            w4, [x2, #0x17]
    // 0xe63284: DecompressPointer r4
    //     0xe63284: add             x4, x4, HEAP, lsl #32
    // 0xe63288: r8 = X0
    //     0xe63288: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xe6328c: LoadField: r9 = r4->field_7
    //     0xe6328c: ldur            x9, [x4, #7]
    // 0xe63290: r3 = Null
    //     0xe63290: add             x3, PP, #0x28, lsl #12  ; [pp+0x282a0] Null
    //     0xe63294: ldr             x3, [x3, #0x2a0]
    // 0xe63298: blr             x9
    // 0xe6329c: ldur            x3, [fp, #-0x18]
    // 0xe632a0: cmp             w3, NULL
    // 0xe632a4: b.eq            #0xe632b0
    // 0xe632a8: ldur            x4, [fp, #-0x10]
    // 0xe632ac: b               #0xe632bc
    // 0xe632b0: ldur            x4, [fp, #-0x10]
    // 0xe632b4: cmp             w4, NULL
    // 0xe632b8: b.eq            #0xe6337c
    // 0xe632bc: cmp             w3, NULL
    // 0xe632c0: b.ne            #0xe632fc
    // 0xe632c4: ldur            x5, [fp, #-0x28]
    // 0xe632c8: LoadField: r2 = r5->field_23
    //     0xe632c8: ldur            w2, [x5, #0x23]
    // 0xe632cc: DecompressPointer r2
    //     0xe632cc: add             x2, x2, HEAP, lsl #32
    // 0xe632d0: mov             x0, x3
    // 0xe632d4: r1 = Null
    //     0xe632d4: mov             x1, NULL
    // 0xe632d8: cmp             w2, NULL
    // 0xe632dc: b.eq            #0xe632fc
    // 0xe632e0: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xe632e0: ldur            w4, [x2, #0x17]
    // 0xe632e4: DecompressPointer r4
    //     0xe632e4: add             x4, x4, HEAP, lsl #32
    // 0xe632e8: r8 = X0
    //     0xe632e8: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xe632ec: LoadField: r9 = r4->field_7
    //     0xe632ec: ldur            x9, [x4, #7]
    // 0xe632f0: r3 = Null
    //     0xe632f0: add             x3, PP, #0x28, lsl #12  ; [pp+0x282b0] Null
    //     0xe632f4: ldr             x3, [x3, #0x2b0]
    // 0xe632f8: blr             x9
    // 0xe632fc: ldur            x3, [fp, #-0x18]
    // 0xe63300: cmp             w3, NULL
    // 0xe63304: b.ne            #0xe63340
    // 0xe63308: ldur            x0, [fp, #-0x28]
    // 0xe6330c: LoadField: r2 = r0->field_23
    //     0xe6330c: ldur            w2, [x0, #0x23]
    // 0xe63310: DecompressPointer r2
    //     0xe63310: add             x2, x2, HEAP, lsl #32
    // 0xe63314: mov             x0, x3
    // 0xe63318: r1 = Null
    //     0xe63318: mov             x1, NULL
    // 0xe6331c: cmp             w2, NULL
    // 0xe63320: b.eq            #0xe63340
    // 0xe63324: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xe63324: ldur            w4, [x2, #0x17]
    // 0xe63328: DecompressPointer r4
    //     0xe63328: add             x4, x4, HEAP, lsl #32
    // 0xe6332c: r8 = X0
    //     0xe6332c: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xe63330: LoadField: r9 = r4->field_7
    //     0xe63330: ldur            x9, [x4, #7]
    // 0xe63334: r3 = Null
    //     0xe63334: add             x3, PP, #0x28, lsl #12  ; [pp+0x282c0] Null
    //     0xe63338: ldr             x3, [x3, #0x2c0]
    // 0xe6333c: blr             x9
    // 0xe63340: ldur            x0, [fp, #-0x10]
    // 0xe63344: cmp             w0, NULL
    // 0xe63348: b.eq            #0xe63354
    // 0xe6334c: r0 = ""
    //     0xe6334c: ldr             x0, [PP, #0x900]  ; [pp+0x900] ""
    // 0xe63350: b               #0xe63358
    // 0xe63354: r0 = Null
    //     0xe63354: mov             x0, NULL
    // 0xe63358: ldur            x16, [fp, #-0x18]
    // 0xe6335c: stp             x16, NULL, [SP, #8]
    // 0xe63360: str             x0, [SP]
    // 0xe63364: ldur            x1, [fp, #-0x20]
    // 0xe63368: r4 = const [0, 0x4, 0x3, 0x1, error, 0x1, errorText, 0x2, hintText, 0x3, null]
    //     0xe63368: add             x4, PP, #0x28, lsl #12  ; [pp+0x282d0] List(11) [0, 0x4, 0x3, 0x1, "error", 0x1, "errorText", 0x2, "hintText", 0x3, Null]
    //     0xe6336c: ldr             x4, [x4, #0x2d0]
    // 0xe63370: r0 = copyWith()
    //     0xe63370: bl              #0xd1c914  ; [package:flutter/src/material/input_decorator.dart] InputDecoration::copyWith
    // 0xe63374: mov             x2, x0
    // 0xe63378: b               #0xe63380
    // 0xe6337c: ldur            x2, [fp, #-0x20]
    // 0xe63380: ldur            x0, [fp, #-8]
    // 0xe63384: stur            x2, [fp, #-0x18]
    // 0xe63388: ArrayLoad: r3 = r0[0]  ; List_4
    //     0xe63388: ldur            w3, [x0, #0x17]
    // 0xe6338c: DecompressPointer r3
    //     0xe6338c: add             x3, x3, HEAP, lsl #32
    // 0xe63390: ldr             x1, [fp, #0x10]
    // 0xe63394: stur            x3, [fp, #-0x10]
    // 0xe63398: LoadField: r0 = r1->field_23
    //     0xe63398: ldur            w0, [x1, #0x23]
    // 0xe6339c: DecompressPointer r0
    //     0xe6339c: add             x0, x0, HEAP, lsl #32
    // 0xe633a0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xe633a4: cmp             w0, w16
    // 0xe633a8: b.ne            #0xe633b8
    // 0xe633ac: r2 = _value
    //     0xe633ac: add             x2, PP, #0x1c, lsl #12  ; [pp+0x1cc48] Field <FormFieldState._value@87032539>: late (offset: 0x24)
    //     0xe633b0: ldr             x2, [x2, #0xc48]
    // 0xe633b4: r0 = InitLateInstanceField()
    //     0xe633b4: bl              #0x13dd948  ; InitLateInstanceFieldStub
    // 0xe633b8: mov             x3, x0
    // 0xe633bc: ldur            x0, [fp, #-8]
    // 0xe633c0: stur            x3, [fp, #-0x28]
    // 0xe633c4: LoadField: r1 = r0->field_f
    //     0xe633c4: ldur            w1, [x0, #0xf]
    // 0xe633c8: DecompressPointer r1
    //     0xe633c8: add             x1, x1, HEAP, lsl #32
    // 0xe633cc: LoadField: r4 = r1->field_b
    //     0xe633cc: ldur            w4, [x1, #0xb]
    // 0xe633d0: DecompressPointer r4
    //     0xe633d0: add             x4, x4, HEAP, lsl #32
    // 0xe633d4: ldr             x2, [fp, #0x10]
    // 0xe633d8: stur            x4, [fp, #-0x20]
    // 0xe633dc: r1 = Function 'didChange':.
    //     0xe633dc: add             x1, PP, #0x28, lsl #12  ; [pp+0x282d8] AnonymousClosure: (0xe636fc), in [package:flutter/src/material/dropdown.dart] _DropdownButtonFormFieldState::didChange (0xe63738)
    //     0xe633e0: ldr             x1, [x1, #0x2d8]
    // 0xe633e4: r0 = AllocateClosure()
    //     0xe633e4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xe633e8: ldur            x2, [fp, #-0x20]
    // 0xe633ec: mov             x3, x0
    // 0xe633f0: r1 = Null
    //     0xe633f0: mov             x1, NULL
    // 0xe633f4: stur            x3, [fp, #-0x40]
    // 0xe633f8: r8 = (dynamic this, X0?) => void?
    //     0xe633f8: add             x8, PP, #0x28, lsl #12  ; [pp+0x282e0] FunctionType: (dynamic this, X0?) => void?
    //     0xe633fc: ldr             x8, [x8, #0x2e0]
    // 0xe63400: LoadField: r9 = r8->field_7
    //     0xe63400: ldur            x9, [x8, #7]
    // 0xe63404: r3 = Null
    //     0xe63404: add             x3, PP, #0x28, lsl #12  ; [pp+0x282e8] Null
    //     0xe63408: ldr             x3, [x3, #0x2e8]
    // 0xe6340c: blr             x9
    // 0xe63410: ldur            x0, [fp, #-8]
    // 0xe63414: LoadField: r2 = r0->field_1b
    //     0xe63414: ldur            w2, [x0, #0x1b]
    // 0xe63418: DecompressPointer r2
    //     0xe63418: add             x2, x2, HEAP, lsl #32
    // 0xe6341c: stur            x2, [fp, #-0x70]
    // 0xe63420: LoadField: r7 = r0->field_2b
    //     0xe63420: ldur            w7, [x0, #0x2b]
    // 0xe63424: DecompressPointer r7
    //     0xe63424: add             x7, x7, HEAP, lsl #32
    // 0xe63428: stur            x7, [fp, #-0x68]
    // 0xe6342c: LoadField: r3 = r0->field_2f
    //     0xe6342c: ldur            w3, [x0, #0x2f]
    // 0xe63430: DecompressPointer r3
    //     0xe63430: add             x3, x3, HEAP, lsl #32
    // 0xe63434: stur            x3, [fp, #-0x60]
    // 0xe63438: LoadField: r5 = r0->field_13
    //     0xe63438: ldur            w5, [x0, #0x13]
    // 0xe6343c: DecompressPointer r5
    //     0xe6343c: add             x5, x5, HEAP, lsl #32
    // 0xe63440: stur            x5, [fp, #-0x58]
    // 0xe63444: LoadField: r4 = r0->field_33
    //     0xe63444: ldur            w4, [x0, #0x33]
    // 0xe63448: DecompressPointer r4
    //     0xe63448: add             x4, x4, HEAP, lsl #32
    // 0xe6344c: stur            x4, [fp, #-0x50]
    // 0xe63450: LoadField: r6 = r0->field_1f
    //     0xe63450: ldur            w6, [x0, #0x1f]
    // 0xe63454: DecompressPointer r6
    //     0xe63454: add             x6, x6, HEAP, lsl #32
    // 0xe63458: ldur            x1, [fp, #-0x20]
    // 0xe6345c: stur            x6, [fp, #-0x48]
    // 0xe63460: r0 = DropdownButton()
    //     0xe63460: bl              #0xe636f0  ; AllocateDropdownButtonStub -> DropdownButton<X0> (size=0x98)
    // 0xe63464: stur            x0, [fp, #-8]
    // 0xe63468: ldur            x16, [fp, #-0x18]
    // 0xe6346c: ldur            lr, [fp, #-0x30]
    // 0xe63470: stp             lr, x16, [SP, #0x30]
    // 0xe63474: ldur            x16, [fp, #-0x60]
    // 0xe63478: ldur            lr, [fp, #-0x10]
    // 0xe6347c: stp             lr, x16, [SP, #0x20]
    // 0xe63480: ldur            x16, [fp, #-0x50]
    // 0xe63484: ldur            lr, [fp, #-0x40]
    // 0xe63488: stp             lr, x16, [SP, #0x10]
    // 0xe6348c: ldur            x16, [fp, #-0x70]
    // 0xe63490: ldur            lr, [fp, #-0x28]
    // 0xe63494: stp             lr, x16, [SP]
    // 0xe63498: mov             x1, x0
    // 0xe6349c: ldur            x2, [fp, #-0x48]
    // 0xe634a0: ldur            x3, [fp, #-0x38]
    // 0xe634a4: ldur            x5, [fp, #-0x58]
    // 0xe634a8: ldur            x6, [fp, #-0x38]
    // 0xe634ac: ldur            x7, [fp, #-0x68]
    // 0xe634b0: r0 = DropdownButton._formField()
    //     0xe634b0: bl              #0xe6351c  ; [package:flutter/src/material/dropdown.dart] DropdownButton::DropdownButton._formField
    // 0xe634b4: r0 = DropdownButtonHideUnderline()
    //     0xe634b4: bl              #0xe63510  ; AllocateDropdownButtonHideUnderlineStub -> DropdownButtonHideUnderline (size=0x10)
    // 0xe634b8: mov             x1, x0
    // 0xe634bc: ldur            x0, [fp, #-8]
    // 0xe634c0: stur            x1, [fp, #-0x10]
    // 0xe634c4: StoreField: r1->field_b = r0
    //     0xe634c4: stur            w0, [x1, #0xb]
    // 0xe634c8: r0 = Focus()
    //     0xe634c8: bl              #0xd1c8f0  ; AllocateFocusStub -> Focus (size=0x40)
    // 0xe634cc: ldur            x1, [fp, #-0x10]
    // 0xe634d0: StoreField: r0->field_f = r1
    //     0xe634d0: stur            w1, [x0, #0xf]
    // 0xe634d4: r1 = false
    //     0xe634d4: add             x1, NULL, #0x30  ; false
    // 0xe634d8: ArrayStore: r0[0] = r1  ; List_4
    //     0xe634d8: stur            w1, [x0, #0x17]
    // 0xe634dc: r2 = true
    //     0xe634dc: add             x2, NULL, #0x20  ; true
    // 0xe634e0: StoreField: r0->field_37 = r2
    //     0xe634e0: stur            w2, [x0, #0x37]
    // 0xe634e4: StoreField: r0->field_27 = r1
    //     0xe634e4: stur            w1, [x0, #0x27]
    // 0xe634e8: StoreField: r0->field_2b = r2
    //     0xe634e8: stur            w2, [x0, #0x2b]
    // 0xe634ec: LeaveFrame
    //     0xe634ec: mov             SP, fp
    //     0xe634f0: ldp             fp, lr, [SP], #0x10
    // 0xe634f4: ret
    //     0xe634f4: ret             
    // 0xe634f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe634f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe634fc: b               #0xe63060
    // 0xe63500: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe63500: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xe63504: r9 = _errorText
    //     0xe63504: add             x9, PP, #0x1a, lsl #12  ; [pp+0x1aa40] Field <FormFieldState._errorText@87032539>: late final (offset: 0x28)
    //     0xe63508: ldr             x9, [x9, #0xa40]
    // 0xe6350c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xe6350c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] bool <anonymous closure>(dynamic, DropdownMenuItem<X0>) {
    // ** addr: 0xe63968, size: 0xa0
    // 0xe63968: EnterFrame
    //     0xe63968: stp             fp, lr, [SP, #-0x10]!
    //     0xe6396c: mov             fp, SP
    // 0xe63970: AllocStack(0x18)
    //     0xe63970: sub             SP, SP, #0x18
    // 0xe63974: SetupParameters([dynamic _ /* r0 */])
    //     0xe63974: ldr             x0, [fp, #0x18]
    //     0xe63978: ldur            w1, [x0, #0x17]
    //     0xe6397c: add             x1, x1, HEAP, lsl #32
    // 0xe63980: CheckStackOverflow
    //     0xe63980: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe63984: cmp             SP, x16
    //     0xe63988: b.ls            #0xe63a00
    // 0xe6398c: ldr             x0, [fp, #0x10]
    // 0xe63990: LoadField: r2 = r0->field_1b
    //     0xe63990: ldur            w2, [x0, #0x1b]
    // 0xe63994: DecompressPointer r2
    //     0xe63994: add             x2, x2, HEAP, lsl #32
    // 0xe63998: stur            x2, [fp, #-8]
    // 0xe6399c: LoadField: r0 = r1->field_f
    //     0xe6399c: ldur            w0, [x1, #0xf]
    // 0xe639a0: DecompressPointer r0
    //     0xe639a0: add             x0, x0, HEAP, lsl #32
    // 0xe639a4: mov             x1, x0
    // 0xe639a8: LoadField: r0 = r1->field_23
    //     0xe639a8: ldur            w0, [x1, #0x23]
    // 0xe639ac: DecompressPointer r0
    //     0xe639ac: add             x0, x0, HEAP, lsl #32
    // 0xe639b0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xe639b4: cmp             w0, w16
    // 0xe639b8: b.ne            #0xe639c8
    // 0xe639bc: r2 = _value
    //     0xe639bc: add             x2, PP, #0x1c, lsl #12  ; [pp+0x1cc48] Field <FormFieldState._value@87032539>: late (offset: 0x24)
    //     0xe639c0: ldr             x2, [x2, #0xc48]
    // 0xe639c4: r0 = InitLateInstanceField()
    //     0xe639c4: bl              #0x13dd948  ; InitLateInstanceFieldStub
    // 0xe639c8: mov             x1, x0
    // 0xe639cc: ldur            x0, [fp, #-8]
    // 0xe639d0: r2 = 60
    //     0xe639d0: mov             x2, #0x3c
    // 0xe639d4: branchIfSmi(r0, 0xe639e0)
    //     0xe639d4: tbz             w0, #0, #0xe639e0
    // 0xe639d8: r2 = LoadClassIdInstr(r0)
    //     0xe639d8: ldur            x2, [x0, #-1]
    //     0xe639dc: ubfx            x2, x2, #0xc, #0x14
    // 0xe639e0: stp             x1, x0, [SP]
    // 0xe639e4: mov             x0, x2
    // 0xe639e8: mov             lr, x0
    // 0xe639ec: ldr             lr, [x21, lr, lsl #3]
    // 0xe639f0: blr             lr
    // 0xe639f4: LeaveFrame
    //     0xe639f4: mov             SP, fp
    //     0xe639f8: ldp             fp, lr, [SP], #0x10
    // 0xe639fc: ret
    //     0xe639fc: ret             
    // 0xe63a00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe63a00: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe63a04: b               #0xe6398c
  }
  _ createState(/* No info */) {
    // ** addr: 0xfa1670, size: 0x64
    // 0xfa1670: EnterFrame
    //     0xfa1670: stp             fp, lr, [SP, #-0x10]!
    //     0xfa1674: mov             fp, SP
    // 0xfa1678: AllocStack(0x8)
    //     0xfa1678: sub             SP, SP, #8
    // 0xfa167c: CheckStackOverflow
    //     0xfa167c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa1680: cmp             SP, x16
    //     0xfa1684: b.ls            #0xfa16cc
    // 0xfa1688: LoadField: r2 = r1->field_b
    //     0xfa1688: ldur            w2, [x1, #0xb]
    // 0xfa168c: DecompressPointer r2
    //     0xfa168c: add             x2, x2, HEAP, lsl #32
    // 0xfa1690: r1 = Null
    //     0xfa1690: mov             x1, NULL
    // 0xfa1694: r3 = <FormField<X0>, X0>
    //     0xfa1694: add             x3, PP, #0x8f, lsl #12  ; [pp+0x8fef0] TypeArguments: <FormField<X0>, X0>
    //     0xfa1698: ldr             x3, [x3, #0xef0]
    // 0xfa169c: r30 = InstantiateTypeArgumentsStub
    //     0xfa169c: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0xfa16a0: LoadField: r30 = r30->field_7
    //     0xfa16a0: ldur            lr, [lr, #7]
    // 0xfa16a4: blr             lr
    // 0xfa16a8: mov             x1, x0
    // 0xfa16ac: r0 = _DropdownButtonFormFieldState()
    //     0xfa16ac: bl              #0xfa1808  ; Allocate_DropdownButtonFormFieldStateStub -> _DropdownButtonFormFieldState<C1X0> (size=0x34)
    // 0xfa16b0: mov             x1, x0
    // 0xfa16b4: stur            x0, [fp, #-8]
    // 0xfa16b8: r0 = FormFieldState()
    //     0xfa16b8: bl              #0xfa16d4  ; [package:flutter/src/widgets/form.dart] FormFieldState::FormFieldState
    // 0xfa16bc: ldur            x0, [fp, #-8]
    // 0xfa16c0: LeaveFrame
    //     0xfa16c0: mov             SP, fp
    //     0xfa16c4: ldp             fp, lr, [SP], #0x10
    // 0xfa16c8: ret
    //     0xfa16c8: ret             
    // 0xfa16cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa16cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa16d0: b               #0xfa1688
  }
}

// class id: 6480, size: 0x98, field offset: 0xc
class DropdownButton<X0> extends StatefulWidget {

  _ DropdownButton._formField(/* No info */) {
    // ** addr: 0xe6351c, size: 0x1d4
    // 0xe6351c: EnterFrame
    //     0xe6351c: stp             fp, lr, [SP, #-0x10]!
    //     0xe63520: mov             fp, SP
    // 0xe63524: r9 = true
    //     0xe63524: add             x9, NULL, #0x20  ; true
    // 0xe63528: r8 = false
    //     0xe63528: add             x8, NULL, #0x30  ; false
    // 0xe6352c: r4 = 8
    //     0xe6352c: mov             x4, #8
    // 0xe63530: d0 = 24.000000
    //     0xe63530: fmov            d0, #24.00000000
    // 0xe63534: ldr             x0, [fp, #0x30]
    // 0xe63538: mov             x16, x7
    // 0xe6353c: mov             x7, x1
    // 0xe63540: mov             x1, x16
    // 0xe63544: mov             x16, x6
    // 0xe63548: mov             x6, x2
    // 0xe6354c: mov             x2, x16
    // 0xe63550: mov             x16, x5
    // 0xe63554: mov             x5, x3
    // 0xe63558: mov             x3, x16
    // 0xe6355c: StoreField: r7->field_f = r0
    //     0xe6355c: stur            w0, [x7, #0xf]
    //     0xe63560: ldurb           w16, [x7, #-1]
    //     0xe63564: ldurb           w17, [x0, #-1]
    //     0xe63568: and             x16, x17, x16, lsr #2
    //     0xe6356c: tst             x16, HEAP, lsr #32
    //     0xe63570: b.eq            #0xe63578
    //     0xe63574: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xe63578: ldr             x0, [fp, #0x10]
    // 0xe6357c: StoreField: r7->field_13 = r0
    //     0xe6357c: stur            w0, [x7, #0x13]
    //     0xe63580: tbz             w0, #0, #0xe6359c
    //     0xe63584: ldurb           w16, [x7, #-1]
    //     0xe63588: ldurb           w17, [x0, #-1]
    //     0xe6358c: and             x16, x17, x16, lsr #2
    //     0xe63590: tst             x16, HEAP, lsr #32
    //     0xe63594: b.eq            #0xe6359c
    //     0xe63598: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xe6359c: mov             x0, x2
    // 0xe635a0: ArrayStore: r7[0] = r0  ; List_4
    //     0xe635a0: stur            w0, [x7, #0x17]
    //     0xe635a4: ldurb           w16, [x7, #-1]
    //     0xe635a8: ldurb           w17, [x0, #-1]
    //     0xe635ac: and             x16, x17, x16, lsr #2
    //     0xe635b0: tst             x16, HEAP, lsr #32
    //     0xe635b4: b.eq            #0xe635bc
    //     0xe635b8: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xe635bc: mov             x0, x5
    // 0xe635c0: StoreField: r7->field_1b = r0
    //     0xe635c0: stur            w0, [x7, #0x1b]
    //     0xe635c4: ldurb           w16, [x7, #-1]
    //     0xe635c8: ldurb           w17, [x0, #-1]
    //     0xe635cc: and             x16, x17, x16, lsr #2
    //     0xe635d0: tst             x16, HEAP, lsr #32
    //     0xe635d4: b.eq            #0xe635dc
    //     0xe635d8: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xe635dc: ldr             x0, [fp, #0x20]
    // 0xe635e0: StoreField: r7->field_1f = r0
    //     0xe635e0: stur            w0, [x7, #0x1f]
    //     0xe635e4: ldurb           w16, [x7, #-1]
    //     0xe635e8: ldurb           w17, [x0, #-1]
    //     0xe635ec: and             x16, x17, x16, lsr #2
    //     0xe635f0: tst             x16, HEAP, lsr #32
    //     0xe635f4: b.eq            #0xe635fc
    //     0xe635f8: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xe635fc: StoreField: r7->field_2b = r4
    //     0xe635fc: stur            x4, [x7, #0x2b]
    // 0xe63600: ldr             x0, [fp, #0x18]
    // 0xe63604: StoreField: r7->field_33 = r0
    //     0xe63604: stur            w0, [x7, #0x33]
    //     0xe63608: ldurb           w16, [x7, #-1]
    //     0xe6360c: ldurb           w17, [x0, #-1]
    //     0xe63610: and             x16, x17, x16, lsr #2
    //     0xe63614: tst             x16, HEAP, lsr #32
    //     0xe63618: b.eq            #0xe63620
    //     0xe6361c: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xe63620: mov             x0, x1
    // 0xe63624: StoreField: r7->field_3b = r0
    //     0xe63624: stur            w0, [x7, #0x3b]
    //     0xe63628: ldurb           w16, [x7, #-1]
    //     0xe6362c: ldurb           w17, [x0, #-1]
    //     0xe63630: and             x16, x17, x16, lsr #2
    //     0xe63634: tst             x16, HEAP, lsr #32
    //     0xe63638: b.eq            #0xe63640
    //     0xe6363c: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xe63640: StoreField: r7->field_47 = d0
    //     0xe63640: stur            d0, [x7, #0x47]
    // 0xe63644: StoreField: r7->field_4f = r9
    //     0xe63644: stur            w9, [x7, #0x4f]
    // 0xe63648: ldr             x1, [fp, #0x38]
    // 0xe6364c: StoreField: r7->field_53 = r1
    //     0xe6364c: stur            w1, [x7, #0x53]
    // 0xe63650: StoreField: r7->field_67 = r8
    //     0xe63650: stur            w8, [x7, #0x67]
    // 0xe63654: mov             x0, x3
    // 0xe63658: StoreField: r7->field_6b = r0
    //     0xe63658: stur            w0, [x7, #0x6b]
    //     0xe6365c: ldurb           w16, [x7, #-1]
    //     0xe63660: ldurb           w17, [x0, #-1]
    //     0xe63664: and             x16, x17, x16, lsr #2
    //     0xe63668: tst             x16, HEAP, lsr #32
    //     0xe6366c: b.eq            #0xe63674
    //     0xe63670: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xe63674: ldr             x0, [fp, #0x28]
    // 0xe63678: StoreField: r7->field_73 = r0
    //     0xe63678: stur            w0, [x7, #0x73]
    //     0xe6367c: ldurb           w16, [x7, #-1]
    //     0xe63680: ldurb           w17, [x0, #-1]
    //     0xe63684: and             x16, x17, x16, lsr #2
    //     0xe63688: tst             x16, HEAP, lsr #32
    //     0xe6368c: b.eq            #0xe63694
    //     0xe63690: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xe63694: mov             x0, x6
    // 0xe63698: StoreField: r7->field_7b = r0
    //     0xe63698: stur            w0, [x7, #0x7b]
    //     0xe6369c: ldurb           w16, [x7, #-1]
    //     0xe636a0: ldurb           w17, [x0, #-1]
    //     0xe636a4: and             x16, x17, x16, lsr #2
    //     0xe636a8: tst             x16, HEAP, lsr #32
    //     0xe636ac: b.eq            #0xe636b4
    //     0xe636b0: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xe636b4: StoreField: r7->field_83 = r9
    //     0xe636b4: stur            w9, [x7, #0x83]
    // 0xe636b8: ldr             x0, [fp, #0x48]
    // 0xe636bc: StoreField: r7->field_8f = r0
    //     0xe636bc: stur            w0, [x7, #0x8f]
    //     0xe636c0: ldurb           w16, [x7, #-1]
    //     0xe636c4: ldurb           w17, [x0, #-1]
    //     0xe636c8: and             x16, x17, x16, lsr #2
    //     0xe636cc: tst             x16, HEAP, lsr #32
    //     0xe636d0: b.eq            #0xe636d8
    //     0xe636d4: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xe636d8: ldr             x1, [fp, #0x40]
    // 0xe636dc: StoreField: r7->field_93 = r1
    //     0xe636dc: stur            w1, [x7, #0x93]
    // 0xe636e0: r0 = Null
    //     0xe636e0: mov             x0, NULL
    // 0xe636e4: LeaveFrame
    //     0xe636e4: mov             SP, fp
    //     0xe636e8: ldp             fp, lr, [SP], #0x10
    // 0xe636ec: ret
    //     0xe636ec: ret             
  }
  _ DropdownButton(/* No info */) {
    // ** addr: 0xee3c38, size: 0x178
    // 0xee3c38: EnterFrame
    //     0xee3c38: stp             fp, lr, [SP, #-0x10]!
    //     0xee3c3c: mov             fp, SP
    // 0xee3c40: r11 = false
    //     0xee3c40: add             x11, NULL, #0x30  ; false
    // 0xee3c44: r10 = true
    //     0xee3c44: add             x10, NULL, #0x20  ; true
    // 0xee3c48: r9 = 48.000000
    //     0xee3c48: add             x9, PP, #0x15, lsl #12  ; [pp+0x158d0] 48
    //     0xee3c4c: ldr             x9, [x9, #0x8d0]
    // 0xee3c50: r8 = 300.000000
    //     0xee3c50: add             x8, PP, #0x22, lsl #12  ; [pp+0x222f0] 300
    //     0xee3c54: ldr             x8, [x8, #0x2f0]
    // 0xee3c58: r4 = 8
    //     0xee3c58: mov             x4, #8
    // 0xee3c5c: d0 = 24.000000
    //     0xee3c5c: fmov            d0, #24.00000000
    // 0xee3c60: mov             x0, x5
    // 0xee3c64: mov             x16, x7
    // 0xee3c68: mov             x7, x1
    // 0xee3c6c: mov             x1, x16
    // 0xee3c70: mov             x16, x6
    // 0xee3c74: mov             x6, x2
    // 0xee3c78: mov             x2, x16
    // 0xee3c7c: StoreField: r7->field_f = r0
    //     0xee3c7c: stur            w0, [x7, #0xf]
    //     0xee3c80: ldurb           w16, [x7, #-1]
    //     0xee3c84: ldurb           w17, [x0, #-1]
    //     0xee3c88: and             x16, x17, x16, lsr #2
    //     0xee3c8c: tst             x16, HEAP, lsr #32
    //     0xee3c90: b.eq            #0xee3c98
    //     0xee3c94: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xee3c98: mov             x0, x1
    // 0xee3c9c: StoreField: r7->field_27 = r0
    //     0xee3c9c: stur            w0, [x7, #0x27]
    //     0xee3ca0: ldurb           w16, [x7, #-1]
    //     0xee3ca4: ldurb           w17, [x0, #-1]
    //     0xee3ca8: and             x16, x17, x16, lsr #2
    //     0xee3cac: tst             x16, HEAP, lsr #32
    //     0xee3cb0: b.eq            #0xee3cb8
    //     0xee3cb4: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xee3cb8: ldr             x0, [fp, #0x10]
    // 0xee3cbc: StoreField: r7->field_13 = r0
    //     0xee3cbc: stur            w0, [x7, #0x13]
    //     0xee3cc0: tbz             w0, #0, #0xee3cdc
    //     0xee3cc4: ldurb           w16, [x7, #-1]
    //     0xee3cc8: ldurb           w17, [x0, #-1]
    //     0xee3ccc: and             x16, x17, x16, lsr #2
    //     0xee3cd0: tst             x16, HEAP, lsr #32
    //     0xee3cd4: b.eq            #0xee3cdc
    //     0xee3cd8: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xee3cdc: mov             x0, x2
    // 0xee3ce0: StoreField: r7->field_1f = r0
    //     0xee3ce0: stur            w0, [x7, #0x1f]
    //     0xee3ce4: ldurb           w16, [x7, #-1]
    //     0xee3ce8: ldurb           w17, [x0, #-1]
    //     0xee3cec: and             x16, x17, x16, lsr #2
    //     0xee3cf0: tst             x16, HEAP, lsr #32
    //     0xee3cf4: b.eq            #0xee3cfc
    //     0xee3cf8: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xee3cfc: StoreField: r7->field_2b = r4
    //     0xee3cfc: stur            x4, [x7, #0x2b]
    // 0xee3d00: ldr             x0, [fp, #0x20]
    // 0xee3d04: StoreField: r7->field_33 = r0
    //     0xee3d04: stur            w0, [x7, #0x33]
    //     0xee3d08: ldurb           w16, [x7, #-1]
    //     0xee3d0c: ldurb           w17, [x0, #-1]
    //     0xee3d10: and             x16, x17, x16, lsr #2
    //     0xee3d14: tst             x16, HEAP, lsr #32
    //     0xee3d18: b.eq            #0xee3d20
    //     0xee3d1c: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xee3d20: ldr             x0, [fp, #0x18]
    // 0xee3d24: StoreField: r7->field_37 = r0
    //     0xee3d24: stur            w0, [x7, #0x37]
    //     0xee3d28: ldurb           w16, [x7, #-1]
    //     0xee3d2c: ldurb           w17, [x0, #-1]
    //     0xee3d30: and             x16, x17, x16, lsr #2
    //     0xee3d34: tst             x16, HEAP, lsr #32
    //     0xee3d38: b.eq            #0xee3d40
    //     0xee3d3c: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xee3d40: mov             x0, x3
    // 0xee3d44: StoreField: r7->field_3b = r0
    //     0xee3d44: stur            w0, [x7, #0x3b]
    //     0xee3d48: ldurb           w16, [x7, #-1]
    //     0xee3d4c: ldurb           w17, [x0, #-1]
    //     0xee3d50: and             x16, x17, x16, lsr #2
    //     0xee3d54: tst             x16, HEAP, lsr #32
    //     0xee3d58: b.eq            #0xee3d60
    //     0xee3d5c: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xee3d60: StoreField: r7->field_47 = d0
    //     0xee3d60: stur            d0, [x7, #0x47]
    // 0xee3d64: StoreField: r7->field_4f = r11
    //     0xee3d64: stur            w11, [x7, #0x4f]
    // 0xee3d68: StoreField: r7->field_53 = r10
    //     0xee3d68: stur            w10, [x7, #0x53]
    // 0xee3d6c: StoreField: r7->field_57 = r9
    //     0xee3d6c: stur            w9, [x7, #0x57]
    // 0xee3d70: StoreField: r7->field_67 = r11
    //     0xee3d70: stur            w11, [x7, #0x67]
    // 0xee3d74: StoreField: r7->field_73 = r8
    //     0xee3d74: stur            w8, [x7, #0x73]
    // 0xee3d78: mov             x0, x6
    // 0xee3d7c: StoreField: r7->field_7b = r0
    //     0xee3d7c: stur            w0, [x7, #0x7b]
    //     0xee3d80: ldurb           w16, [x7, #-1]
    //     0xee3d84: ldurb           w17, [x0, #-1]
    //     0xee3d88: and             x16, x17, x16, lsr #2
    //     0xee3d8c: tst             x16, HEAP, lsr #32
    //     0xee3d90: b.eq            #0xee3d98
    //     0xee3d94: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xee3d98: StoreField: r7->field_83 = r10
    //     0xee3d98: stur            w10, [x7, #0x83]
    // 0xee3d9c: StoreField: r7->field_93 = r11
    //     0xee3d9c: stur            w11, [x7, #0x93]
    // 0xee3da0: r0 = Null
    //     0xee3da0: mov             x0, NULL
    // 0xee3da4: LeaveFrame
    //     0xee3da4: mov             SP, fp
    //     0xee3da8: ldp             fp, lr, [SP], #0x10
    // 0xee3dac: ret
    //     0xee3dac: ret             
  }
  _ createState(/* No info */) {
    // ** addr: 0xfa1610, size: 0x54
    // 0xfa1610: EnterFrame
    //     0xfa1610: stp             fp, lr, [SP, #-0x10]!
    //     0xfa1614: mov             fp, SP
    // 0xfa1618: LoadField: r2 = r1->field_b
    //     0xfa1618: ldur            w2, [x1, #0xb]
    // 0xfa161c: DecompressPointer r2
    //     0xfa161c: add             x2, x2, HEAP, lsl #32
    // 0xfa1620: r1 = Null
    //     0xfa1620: mov             x1, NULL
    // 0xfa1624: r3 = <DropdownButton<X0>, X0>
    //     0xfa1624: add             x3, PP, #0x8f, lsl #12  ; [pp+0x8fef8] TypeArguments: <DropdownButton<X0>, X0>
    //     0xfa1628: ldr             x3, [x3, #0xef8]
    // 0xfa162c: r30 = InstantiateTypeArgumentsStub
    //     0xfa162c: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0xfa1630: LoadField: r30 = r30->field_7
    //     0xfa1630: ldur            lr, [lr, #7]
    // 0xfa1634: blr             lr
    // 0xfa1638: mov             x1, x0
    // 0xfa163c: r0 = _DropdownButtonState()
    //     0xfa163c: bl              #0xfa1664  ; Allocate_DropdownButtonStateStub -> _DropdownButtonState<C1X0> (size=0x34)
    // 0xfa1640: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa1644: StoreField: r0->field_23 = r1
    //     0xfa1644: stur            w1, [x0, #0x23]
    // 0xfa1648: r1 = false
    //     0xfa1648: add             x1, NULL, #0x30  ; false
    // 0xfa164c: StoreField: r0->field_27 = r1
    //     0xfa164c: stur            w1, [x0, #0x27]
    // 0xfa1650: StoreField: r0->field_2b = r1
    //     0xfa1650: stur            w1, [x0, #0x2b]
    // 0xfa1654: StoreField: r0->field_2f = r1
    //     0xfa1654: stur            w1, [x0, #0x2f]
    // 0xfa1658: LeaveFrame
    //     0xfa1658: mov             SP, fp
    //     0xfa165c: ldp             fp, lr, [SP], #0x10
    // 0xfa1660: ret
    //     0xfa1660: ret             
  }
}

// class id: 6481, size: 0x40, field offset: 0xc
//   const constructor, 
class _DropdownRoutePage<X0> extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa15c0, size: 0x44
    // 0xfa15c0: EnterFrame
    //     0xfa15c0: stp             fp, lr, [SP, #-0x10]!
    //     0xfa15c4: mov             fp, SP
    // 0xfa15c8: LoadField: r2 = r1->field_b
    //     0xfa15c8: ldur            w2, [x1, #0xb]
    // 0xfa15cc: DecompressPointer r2
    //     0xfa15cc: add             x2, x2, HEAP, lsl #32
    // 0xfa15d0: r1 = Null
    //     0xfa15d0: mov             x1, NULL
    // 0xfa15d4: r3 = <_DropdownRoutePage<X0>, X0>
    //     0xfa15d4: add             x3, PP, #0xad, lsl #12  ; [pp+0xadea0] TypeArguments: <_DropdownRoutePage<X0>, X0>
    //     0xfa15d8: ldr             x3, [x3, #0xea0]
    // 0xfa15dc: r30 = InstantiateTypeArgumentsStub
    //     0xfa15dc: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0xfa15e0: LoadField: r30 = r30->field_7
    //     0xfa15e0: ldur            lr, [lr, #7]
    // 0xfa15e4: blr             lr
    // 0xfa15e8: mov             x1, x0
    // 0xfa15ec: r0 = _DropdownRoutePageState()
    //     0xfa15ec: bl              #0xfa1604  ; Allocate_DropdownRoutePageStateStub -> _DropdownRoutePageState<C1X0> (size=0x18)
    // 0xfa15f0: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa15f4: StoreField: r0->field_13 = r1
    //     0xfa15f4: stur            w1, [x0, #0x13]
    // 0xfa15f8: LeaveFrame
    //     0xfa15f8: mov             SP, fp
    //     0xfa15fc: ldp             fp, lr, [SP], #0x10
    // 0xfa1600: ret
    //     0xfa1600: ret             
  }
}

// class id: 6482, size: 0x34, field offset: 0xc
//   const constructor, 
class _DropdownMenu<X0> extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa156c, size: 0x48
    // 0xfa156c: EnterFrame
    //     0xfa156c: stp             fp, lr, [SP, #-0x10]!
    //     0xfa1570: mov             fp, SP
    // 0xfa1574: LoadField: r2 = r1->field_b
    //     0xfa1574: ldur            w2, [x1, #0xb]
    // 0xfa1578: DecompressPointer r2
    //     0xfa1578: add             x2, x2, HEAP, lsl #32
    // 0xfa157c: r1 = Null
    //     0xfa157c: mov             x1, NULL
    // 0xfa1580: r3 = <_DropdownMenu<X0>, X0>
    //     0xfa1580: add             x3, PP, #0xd0, lsl #12  ; [pp+0xd05a0] TypeArguments: <_DropdownMenu<X0>, X0>
    //     0xfa1584: ldr             x3, [x3, #0x5a0]
    // 0xfa1588: r30 = InstantiateTypeArgumentsStub
    //     0xfa1588: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0xfa158c: LoadField: r30 = r30->field_7
    //     0xfa158c: ldur            lr, [lr, #7]
    // 0xfa1590: blr             lr
    // 0xfa1594: mov             x1, x0
    // 0xfa1598: r0 = _DropdownMenuState()
    //     0xfa1598: bl              #0xfa15b4  ; Allocate_DropdownMenuStateStub -> _DropdownMenuState<C1X0> (size=0x1c)
    // 0xfa159c: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa15a0: StoreField: r0->field_13 = r1
    //     0xfa15a0: stur            w1, [x0, #0x13]
    // 0xfa15a4: ArrayStore: r0[0] = r1  ; List_4
    //     0xfa15a4: stur            w1, [x0, #0x17]
    // 0xfa15a8: LeaveFrame
    //     0xfa15a8: mov             SP, fp
    //     0xfa15ac: ldp             fp, lr, [SP], #0x10
    // 0xfa15b0: ret
    //     0xfa15b0: ret             
  }
}

// class id: 6483, size: 0x34, field offset: 0xc
//   const constructor, 
class _DropdownMenuItemButton<X0> extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa151c, size: 0x44
    // 0xfa151c: EnterFrame
    //     0xfa151c: stp             fp, lr, [SP, #-0x10]!
    //     0xfa1520: mov             fp, SP
    // 0xfa1524: LoadField: r2 = r1->field_b
    //     0xfa1524: ldur            w2, [x1, #0xb]
    // 0xfa1528: DecompressPointer r2
    //     0xfa1528: add             x2, x2, HEAP, lsl #32
    // 0xfa152c: r1 = Null
    //     0xfa152c: mov             x1, NULL
    // 0xfa1530: r3 = <_DropdownMenuItemButton<X0>, X0>
    //     0xfa1530: add             x3, PP, #0xd2, lsl #12  ; [pp+0xd28b8] TypeArguments: <_DropdownMenuItemButton<X0>, X0>
    //     0xfa1534: ldr             x3, [x3, #0x8b8]
    // 0xfa1538: r30 = InstantiateTypeArgumentsStub
    //     0xfa1538: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0xfa153c: LoadField: r30 = r30->field_7
    //     0xfa153c: ldur            lr, [lr, #7]
    // 0xfa1540: blr             lr
    // 0xfa1544: mov             x1, x0
    // 0xfa1548: r0 = _DropdownMenuItemButtonState()
    //     0xfa1548: bl              #0xfa1560  ; Allocate_DropdownMenuItemButtonStateStub -> _DropdownMenuItemButtonState<C1X0> (size=0x18)
    // 0xfa154c: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa1550: StoreField: r0->field_13 = r1
    //     0xfa1550: stur            w1, [x0, #0x13]
    // 0xfa1554: LeaveFrame
    //     0xfa1554: mov             SP, fp
    //     0xfa1558: ldp             fp, lr, [SP], #0x10
    // 0xfa155c: ret
    //     0xfa155c: ret             
  }
}

// class id: 6654, size: 0x1c, field offset: 0x10
//   const constructor, 
class _MenuItem<X0> extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xcf4a4c, size: 0x94
    // 0xcf4a4c: EnterFrame
    //     0xcf4a4c: stp             fp, lr, [SP, #-0x10]!
    //     0xcf4a50: mov             fp, SP
    // 0xcf4a54: AllocStack(0x10)
    //     0xcf4a54: sub             SP, SP, #0x10
    // 0xcf4a58: SetupParameters(_MenuItem<X0> this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4 */, dynamic _ /* r3 => r0, fp-0x10 */)
    //     0xcf4a58: mov             x0, x3
    //     0xcf4a5c: mov             x5, x1
    //     0xcf4a60: mov             x4, x2
    //     0xcf4a64: stur            x1, [fp, #-8]
    //     0xcf4a68: stur            x3, [fp, #-0x10]
    // 0xcf4a6c: r2 = Null
    //     0xcf4a6c: mov             x2, NULL
    // 0xcf4a70: r1 = Null
    //     0xcf4a70: mov             x1, NULL
    // 0xcf4a74: r4 = 60
    //     0xcf4a74: mov             x4, #0x3c
    // 0xcf4a78: branchIfSmi(r0, 0xcf4a84)
    //     0xcf4a78: tbz             w0, #0, #0xcf4a84
    // 0xcf4a7c: r4 = LoadClassIdInstr(r0)
    //     0xcf4a7c: ldur            x4, [x0, #-1]
    //     0xcf4a80: ubfx            x4, x4, #0xc, #0x14
    // 0xcf4a84: r17 = 4959
    //     0xcf4a84: mov             x17, #0x135f
    // 0xcf4a88: cmp             x4, x17
    // 0xcf4a8c: b.eq            #0xcf4aa4
    // 0xcf4a90: r8 = _RenderMenuItem
    //     0xcf4a90: add             x8, PP, #0xa3, lsl #12  ; [pp+0xa3d30] Type: _RenderMenuItem
    //     0xcf4a94: ldr             x8, [x8, #0xd30]
    // 0xcf4a98: r3 = Null
    //     0xcf4a98: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa3d38] Null
    //     0xcf4a9c: ldr             x3, [x3, #0xd38]
    // 0xcf4aa0: r0 = DefaultTypeTest()
    //     0xcf4aa0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf4aa4: ldur            x1, [fp, #-8]
    // 0xcf4aa8: LoadField: r0 = r1->field_13
    //     0xcf4aa8: ldur            w0, [x1, #0x13]
    // 0xcf4aac: DecompressPointer r0
    //     0xcf4aac: add             x0, x0, HEAP, lsl #32
    // 0xcf4ab0: ldur            x1, [fp, #-0x10]
    // 0xcf4ab4: StoreField: r1->field_53 = r0
    //     0xcf4ab4: stur            w0, [x1, #0x53]
    //     0xcf4ab8: ldurb           w16, [x1, #-1]
    //     0xcf4abc: ldurb           w17, [x0, #-1]
    //     0xcf4ac0: and             x16, x17, x16, lsr #2
    //     0xcf4ac4: tst             x16, HEAP, lsr #32
    //     0xcf4ac8: b.eq            #0xcf4ad0
    //     0xcf4acc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf4ad0: r0 = Null
    //     0xcf4ad0: mov             x0, NULL
    // 0xcf4ad4: LeaveFrame
    //     0xcf4ad4: mov             SP, fp
    //     0xcf4ad8: ldp             fp, lr, [SP], #0x10
    // 0xcf4adc: ret
    //     0xcf4adc: ret             
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11cf994, size: 0x50
    // 0x11cf994: EnterFrame
    //     0x11cf994: stp             fp, lr, [SP, #-0x10]!
    //     0x11cf998: mov             fp, SP
    // 0x11cf99c: AllocStack(0x8)
    //     0x11cf99c: sub             SP, SP, #8
    // 0x11cf9a0: CheckStackOverflow
    //     0x11cf9a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11cf9a4: cmp             SP, x16
    //     0x11cf9a8: b.ls            #0x11cf9dc
    // 0x11cf9ac: LoadField: r2 = r1->field_13
    //     0x11cf9ac: ldur            w2, [x1, #0x13]
    // 0x11cf9b0: DecompressPointer r2
    //     0x11cf9b0: add             x2, x2, HEAP, lsl #32
    // 0x11cf9b4: stur            x2, [fp, #-8]
    // 0x11cf9b8: r0 = _RenderMenuItem()
    //     0x11cf9b8: bl              #0x11cf9e4  ; Allocate_RenderMenuItemStub -> _RenderMenuItem (size=0x58)
    // 0x11cf9bc: mov             x1, x0
    // 0x11cf9c0: ldur            x2, [fp, #-8]
    // 0x11cf9c4: stur            x0, [fp, #-8]
    // 0x11cf9c8: r0 = RenderIntrinsicWidth()
    //     0x11cf9c8: bl              #0x11bf530  ; [package:flutter/src/rendering/proxy_box.dart] RenderIntrinsicWidth::RenderIntrinsicWidth
    // 0x11cf9cc: ldur            x0, [fp, #-8]
    // 0x11cf9d0: LeaveFrame
    //     0x11cf9d0: mov             SP, fp
    //     0x11cf9d4: ldp             fp, lr, [SP], #0x10
    // 0x11cf9d8: ret
    //     0x11cf9d8: ret             
    // 0x11cf9dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11cf9dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11cf9e0: b               #0x11cf9ac
  }
}

// class id: 6814, size: 0x10, field offset: 0x10
//   const constructor, 
class DropdownButtonHideUnderline extends InheritedWidget {

  _ updateShouldNotify(/* No info */) {
    // ** addr: 0xc00ed8, size: 0x5c
    // 0xc00ed8: EnterFrame
    //     0xc00ed8: stp             fp, lr, [SP, #-0x10]!
    //     0xc00edc: mov             fp, SP
    // 0xc00ee0: mov             x0, x2
    // 0xc00ee4: mov             x4, x1
    // 0xc00ee8: mov             x3, x2
    // 0xc00eec: r2 = Null
    //     0xc00eec: mov             x2, NULL
    // 0xc00ef0: r1 = Null
    //     0xc00ef0: mov             x1, NULL
    // 0xc00ef4: r4 = 60
    //     0xc00ef4: mov             x4, #0x3c
    // 0xc00ef8: branchIfSmi(r0, 0xc00f04)
    //     0xc00ef8: tbz             w0, #0, #0xc00f04
    // 0xc00efc: r4 = LoadClassIdInstr(r0)
    //     0xc00efc: ldur            x4, [x0, #-1]
    //     0xc00f00: ubfx            x4, x4, #0xc, #0x14
    // 0xc00f04: r17 = 6814
    //     0xc00f04: mov             x17, #0x1a9e
    // 0xc00f08: cmp             x4, x17
    // 0xc00f0c: b.eq            #0xc00f24
    // 0xc00f10: r8 = DropdownButtonHideUnderline
    //     0xc00f10: add             x8, PP, #0x99, lsl #12  ; [pp+0x998e0] Type: DropdownButtonHideUnderline
    //     0xc00f14: ldr             x8, [x8, #0x8e0]
    // 0xc00f18: r3 = Null
    //     0xc00f18: add             x3, PP, #0x99, lsl #12  ; [pp+0x998e8] Null
    //     0xc00f1c: ldr             x3, [x3, #0x8e8]
    // 0xc00f20: r0 = DefaultTypeTest()
    //     0xc00f20: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xc00f24: r0 = false
    //     0xc00f24: add             x0, NULL, #0x30  ; false
    // 0xc00f28: LeaveFrame
    //     0xc00f28: mov             SP, fp
    //     0xc00f2c: ldp             fp, lr, [SP], #0x10
    // 0xc00f30: ret
    //     0xc00f30: ret             
  }
  static _ at(/* No info */) {
    // ** addr: 0xd1e148, size: 0x54
    // 0xd1e148: EnterFrame
    //     0xd1e148: stp             fp, lr, [SP, #-0x10]!
    //     0xd1e14c: mov             fp, SP
    // 0xd1e150: AllocStack(0x10)
    //     0xd1e150: sub             SP, SP, #0x10
    // 0xd1e154: CheckStackOverflow
    //     0xd1e154: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd1e158: cmp             SP, x16
    //     0xd1e15c: b.ls            #0xd1e194
    // 0xd1e160: r16 = <DropdownButtonHideUnderline>
    //     0xd1e160: add             x16, PP, #0x99, lsl #12  ; [pp+0x99a00] TypeArguments: <DropdownButtonHideUnderline>
    //     0xd1e164: ldr             x16, [x16, #0xa00]
    // 0xd1e168: stp             x1, x16, [SP]
    // 0xd1e16c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd1e16c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd1e170: r0 = dependOnInheritedWidgetOfExactType()
    //     0xd1e170: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xd1e174: cmp             w0, NULL
    // 0xd1e178: r16 = true
    //     0xd1e178: add             x16, NULL, #0x20  ; true
    // 0xd1e17c: r17 = false
    //     0xd1e17c: add             x17, NULL, #0x30  ; false
    // 0xd1e180: csel            x1, x16, x17, ne
    // 0xd1e184: mov             x0, x1
    // 0xd1e188: LeaveFrame
    //     0xd1e188: mov             SP, fp
    //     0xd1e18c: ldp             fp, lr, [SP], #0x10
    // 0xd1e190: ret
    //     0xd1e190: ret             
    // 0xd1e194: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1e194: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd1e198: b               #0xd1e160
  }
}
