// lib: , url: package:flutter/src/material/action_buttons.dart

// class id: 1048838, size: 0x8
class :: {
}

// class id: 6189, size: 0xc, field offset: 0xc
//   const constructor, 
class DrawerButtonIcon extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfaec80, size: 0x80
    // 0xfaec80: EnterFrame
    //     0xfaec80: stp             fp, lr, [SP, #-0x10]!
    //     0xfaec84: mov             fp, SP
    // 0xfaec88: AllocStack(0x10)
    //     0xfaec88: sub             SP, SP, #0x10
    // 0xfaec8c: SetupParameters(DrawerButtonIcon this /* r1 => r3 */, dynamic _ /* r2 => r0 */)
    //     0xfaec8c: mov             x3, x1
    //     0xfaec90: mov             x0, x2
    // 0xfaec94: r1 = Function '<anonymous closure>':.
    //     0xfaec94: add             x1, PP, #0x95, lsl #12  ; [pp+0x95f78] AnonymousClosure: (0xfaed54), in [package:flutter/src/material/action_buttons.dart] DrawerButtonIcon::build (0xfaec80)
    //     0xfaec98: ldr             x1, [x1, #0xf78]
    // 0xfaec9c: r2 = Null
    //     0xfaec9c: mov             x2, NULL
    // 0xfaeca0: r0 = AllocateClosure()
    //     0xfaeca0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfaeca4: stur            x0, [fp, #-8]
    // 0xfaeca8: r0 = _ActionIcon()
    //     0xfaeca8: bl              #0xfaea94  ; Allocate_ActionIconStub -> _ActionIcon (size=0x18)
    // 0xfaecac: mov             x3, x0
    // 0xfaecb0: ldur            x0, [fp, #-8]
    // 0xfaecb4: stur            x3, [fp, #-0x10]
    // 0xfaecb8: StoreField: r3->field_b = r0
    //     0xfaecb8: stur            w0, [x3, #0xb]
    // 0xfaecbc: r1 = Function '<anonymous closure>':.
    //     0xfaecbc: add             x1, PP, #0x95, lsl #12  ; [pp+0x95f80] AnonymousClosure: (0xfaed48), in [package:flutter/src/material/action_buttons.dart] DrawerButtonIcon::build (0xfaec80)
    //     0xfaecc0: ldr             x1, [x1, #0xf80]
    // 0xfaecc4: r2 = Null
    //     0xfaecc4: mov             x2, NULL
    // 0xfaecc8: r0 = AllocateClosure()
    //     0xfaecc8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfaeccc: mov             x1, x0
    // 0xfaecd0: ldur            x0, [fp, #-0x10]
    // 0xfaecd4: StoreField: r0->field_f = r1
    //     0xfaecd4: stur            w1, [x0, #0xf]
    // 0xfaecd8: r1 = Function '<anonymous closure>':.
    //     0xfaecd8: add             x1, PP, #0x95, lsl #12  ; [pp+0x95f88] AnonymousClosure: (0xfaed00), in [package:flutter/src/material/action_buttons.dart] DrawerButtonIcon::build (0xfaec80)
    //     0xfaecdc: ldr             x1, [x1, #0xf88]
    // 0xfaece0: r2 = Null
    //     0xfaece0: mov             x2, NULL
    // 0xfaece4: r0 = AllocateClosure()
    //     0xfaece4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfaece8: mov             x1, x0
    // 0xfaecec: ldur            x0, [fp, #-0x10]
    // 0xfaecf0: StoreField: r0->field_13 = r1
    //     0xfaecf0: stur            w1, [x0, #0x13]
    // 0xfaecf4: LeaveFrame
    //     0xfaecf4: mov             SP, fp
    //     0xfaecf8: ldp             fp, lr, [SP], #0x10
    // 0xfaecfc: ret
    //     0xfaecfc: ret             
  }
  [closure] String <anonymous closure>(dynamic, MaterialLocalizations) {
    // ** addr: 0xfaed00, size: 0x48
    // 0xfaed00: EnterFrame
    //     0xfaed00: stp             fp, lr, [SP, #-0x10]!
    //     0xfaed04: mov             fp, SP
    // 0xfaed08: CheckStackOverflow
    //     0xfaed08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfaed0c: cmp             SP, x16
    //     0xfaed10: b.ls            #0xfaed40
    // 0xfaed14: ldr             x1, [fp, #0x10]
    // 0xfaed18: r0 = LoadClassIdInstr(r1)
    //     0xfaed18: ldur            x0, [x1, #-1]
    //     0xfaed1c: ubfx            x0, x0, #0xc, #0x14
    // 0xfaed20: r0 = GDT[cid_x0 + 0x1743f]()
    //     0xfaed20: mov             x17, #0x743f
    //     0xfaed24: movk            x17, #1, lsl #16
    //     0xfaed28: add             lr, x0, x17
    //     0xfaed2c: ldr             lr, [x21, lr, lsl #3]
    //     0xfaed30: blr             lr
    // 0xfaed34: LeaveFrame
    //     0xfaed34: mov             SP, fp
    //     0xfaed38: ldp             fp, lr, [SP], #0x10
    // 0xfaed3c: ret
    //     0xfaed3c: ret             
    // 0xfaed40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfaed40: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfaed44: b               #0xfaed14
  }
  [closure] IconData <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0xfaed48, size: 0xc
    // 0xfaed48: r0 = Instance_IconData
    //     0xfaed48: add             x0, PP, #0x95, lsl #12  ; [pp+0x95f90] Obj!IconData@128abd1
    //     0xfaed4c: ldr             x0, [x0, #0xf90]
    // 0xfaed50: ret
    //     0xfaed50: ret             
  }
  [closure] ((dynamic, BuildContext) => Widget)? <anonymous closure>(dynamic, ActionIconThemeData?) {
    // ** addr: 0xfaed54, size: 0x24
    // 0xfaed54: ldr             x1, [SP]
    // 0xfaed58: cmp             w1, NULL
    // 0xfaed5c: b.ne            #0xfaed68
    // 0xfaed60: r0 = Null
    //     0xfaed60: mov             x0, NULL
    // 0xfaed64: b               #0xfaed74
    // 0xfaed68: LoadField: r2 = r1->field_f
    //     0xfaed68: ldur            w2, [x1, #0xf]
    // 0xfaed6c: DecompressPointer r2
    //     0xfaed6c: add             x2, x2, HEAP, lsl #32
    // 0xfaed70: mov             x0, x2
    // 0xfaed74: ret
    //     0xfaed74: ret             
  }
}

// class id: 6190, size: 0xc, field offset: 0xc
//   const constructor, 
class CloseButtonIcon extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfaeb88, size: 0x80
    // 0xfaeb88: EnterFrame
    //     0xfaeb88: stp             fp, lr, [SP, #-0x10]!
    //     0xfaeb8c: mov             fp, SP
    // 0xfaeb90: AllocStack(0x10)
    //     0xfaeb90: sub             SP, SP, #0x10
    // 0xfaeb94: SetupParameters(CloseButtonIcon this /* r1 => r3 */, dynamic _ /* r2 => r0 */)
    //     0xfaeb94: mov             x3, x1
    //     0xfaeb98: mov             x0, x2
    // 0xfaeb9c: r1 = Function '<anonymous closure>':.
    //     0xfaeb9c: add             x1, PP, #0x95, lsl #12  ; [pp+0x95fb8] AnonymousClosure: (0xfaec5c), in [package:flutter/src/material/action_buttons.dart] CloseButtonIcon::build (0xfaeb88)
    //     0xfaeba0: ldr             x1, [x1, #0xfb8]
    // 0xfaeba4: r2 = Null
    //     0xfaeba4: mov             x2, NULL
    // 0xfaeba8: r0 = AllocateClosure()
    //     0xfaeba8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfaebac: stur            x0, [fp, #-8]
    // 0xfaebb0: r0 = _ActionIcon()
    //     0xfaebb0: bl              #0xfaea94  ; Allocate_ActionIconStub -> _ActionIcon (size=0x18)
    // 0xfaebb4: mov             x3, x0
    // 0xfaebb8: ldur            x0, [fp, #-8]
    // 0xfaebbc: stur            x3, [fp, #-0x10]
    // 0xfaebc0: StoreField: r3->field_b = r0
    //     0xfaebc0: stur            w0, [x3, #0xb]
    // 0xfaebc4: r1 = Function '<anonymous closure>':.
    //     0xfaebc4: add             x1, PP, #0x95, lsl #12  ; [pp+0x95fc0] AnonymousClosure: (0xfaec50), in [package:flutter/src/material/action_buttons.dart] CloseButtonIcon::build (0xfaeb88)
    //     0xfaebc8: ldr             x1, [x1, #0xfc0]
    // 0xfaebcc: r2 = Null
    //     0xfaebcc: mov             x2, NULL
    // 0xfaebd0: r0 = AllocateClosure()
    //     0xfaebd0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfaebd4: mov             x1, x0
    // 0xfaebd8: ldur            x0, [fp, #-0x10]
    // 0xfaebdc: StoreField: r0->field_f = r1
    //     0xfaebdc: stur            w1, [x0, #0xf]
    // 0xfaebe0: r1 = Function '<anonymous closure>':.
    //     0xfaebe0: add             x1, PP, #0x95, lsl #12  ; [pp+0x95fc8] AnonymousClosure: (0xfaec08), in [package:flutter/src/material/action_buttons.dart] CloseButtonIcon::build (0xfaeb88)
    //     0xfaebe4: ldr             x1, [x1, #0xfc8]
    // 0xfaebe8: r2 = Null
    //     0xfaebe8: mov             x2, NULL
    // 0xfaebec: r0 = AllocateClosure()
    //     0xfaebec: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfaebf0: mov             x1, x0
    // 0xfaebf4: ldur            x0, [fp, #-0x10]
    // 0xfaebf8: StoreField: r0->field_13 = r1
    //     0xfaebf8: stur            w1, [x0, #0x13]
    // 0xfaebfc: LeaveFrame
    //     0xfaebfc: mov             SP, fp
    //     0xfaec00: ldp             fp, lr, [SP], #0x10
    // 0xfaec04: ret
    //     0xfaec04: ret             
  }
  [closure] String <anonymous closure>(dynamic, MaterialLocalizations) {
    // ** addr: 0xfaec08, size: 0x48
    // 0xfaec08: EnterFrame
    //     0xfaec08: stp             fp, lr, [SP, #-0x10]!
    //     0xfaec0c: mov             fp, SP
    // 0xfaec10: CheckStackOverflow
    //     0xfaec10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfaec14: cmp             SP, x16
    //     0xfaec18: b.ls            #0xfaec48
    // 0xfaec1c: ldr             x1, [fp, #0x10]
    // 0xfaec20: r0 = LoadClassIdInstr(r1)
    //     0xfaec20: ldur            x0, [x1, #-1]
    //     0xfaec24: ubfx            x0, x0, #0xc, #0x14
    // 0xfaec28: r0 = GDT[cid_x0 + 0x16ae1]()
    //     0xfaec28: mov             x17, #0x6ae1
    //     0xfaec2c: movk            x17, #1, lsl #16
    //     0xfaec30: add             lr, x0, x17
    //     0xfaec34: ldr             lr, [x21, lr, lsl #3]
    //     0xfaec38: blr             lr
    // 0xfaec3c: LeaveFrame
    //     0xfaec3c: mov             SP, fp
    //     0xfaec40: ldp             fp, lr, [SP], #0x10
    // 0xfaec44: ret
    //     0xfaec44: ret             
    // 0xfaec48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfaec48: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfaec4c: b               #0xfaec1c
  }
  [closure] IconData <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0xfaec50, size: 0xc
    // 0xfaec50: r0 = Instance_IconData
    //     0xfaec50: add             x0, PP, #0x17, lsl #12  ; [pp+0x17798] Obj!IconData@128a611
    //     0xfaec54: ldr             x0, [x0, #0x798]
    // 0xfaec58: ret
    //     0xfaec58: ret             
  }
  [closure] ((dynamic, BuildContext) => Widget)? <anonymous closure>(dynamic, ActionIconThemeData?) {
    // ** addr: 0xfaec5c, size: 0x24
    // 0xfaec5c: ldr             x1, [SP]
    // 0xfaec60: cmp             w1, NULL
    // 0xfaec64: b.ne            #0xfaec70
    // 0xfaec68: r0 = Null
    //     0xfaec68: mov             x0, NULL
    // 0xfaec6c: b               #0xfaec7c
    // 0xfaec70: LoadField: r2 = r1->field_b
    //     0xfaec70: ldur            w2, [x1, #0xb]
    // 0xfaec74: DecompressPointer r2
    //     0xfaec74: add             x2, x2, HEAP, lsl #32
    // 0xfaec78: mov             x0, x2
    // 0xfaec7c: ret
    //     0xfaec7c: ret             
  }
}

// class id: 6191, size: 0xc, field offset: 0xc
//   const constructor, 
class BackButtonIcon extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfaea14, size: 0x80
    // 0xfaea14: EnterFrame
    //     0xfaea14: stp             fp, lr, [SP, #-0x10]!
    //     0xfaea18: mov             fp, SP
    // 0xfaea1c: AllocStack(0x10)
    //     0xfaea1c: sub             SP, SP, #0x10
    // 0xfaea20: SetupParameters(BackButtonIcon this /* r1 => r3 */, dynamic _ /* r2 => r0 */)
    //     0xfaea20: mov             x3, x1
    //     0xfaea24: mov             x0, x2
    // 0xfaea28: r1 = Function '<anonymous closure>':.
    //     0xfaea28: add             x1, PP, #0x95, lsl #12  ; [pp+0x95f58] AnonymousClosure: (0xfaeb64), in [package:flutter/src/material/action_buttons.dart] BackButtonIcon::build (0xfaea14)
    //     0xfaea2c: ldr             x1, [x1, #0xf58]
    // 0xfaea30: r2 = Null
    //     0xfaea30: mov             x2, NULL
    // 0xfaea34: r0 = AllocateClosure()
    //     0xfaea34: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfaea38: stur            x0, [fp, #-8]
    // 0xfaea3c: r0 = _ActionIcon()
    //     0xfaea3c: bl              #0xfaea94  ; Allocate_ActionIconStub -> _ActionIcon (size=0x18)
    // 0xfaea40: mov             x3, x0
    // 0xfaea44: ldur            x0, [fp, #-8]
    // 0xfaea48: stur            x3, [fp, #-0x10]
    // 0xfaea4c: StoreField: r3->field_b = r0
    //     0xfaea4c: stur            w0, [x3, #0xb]
    // 0xfaea50: r1 = Function '<anonymous closure>':.
    //     0xfaea50: add             x1, PP, #0x95, lsl #12  ; [pp+0x95f60] AnonymousClosure: (0xfaeae8), in [package:flutter/src/material/action_buttons.dart] BackButtonIcon::build (0xfaea14)
    //     0xfaea54: ldr             x1, [x1, #0xf60]
    // 0xfaea58: r2 = Null
    //     0xfaea58: mov             x2, NULL
    // 0xfaea5c: r0 = AllocateClosure()
    //     0xfaea5c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfaea60: mov             x1, x0
    // 0xfaea64: ldur            x0, [fp, #-0x10]
    // 0xfaea68: StoreField: r0->field_f = r1
    //     0xfaea68: stur            w1, [x0, #0xf]
    // 0xfaea6c: r1 = Function '<anonymous closure>':.
    //     0xfaea6c: add             x1, PP, #0x95, lsl #12  ; [pp+0x95f68] AnonymousClosure: (0xfaeaa0), in [package:flutter/src/material/action_buttons.dart] BackButtonIcon::build (0xfaea14)
    //     0xfaea70: ldr             x1, [x1, #0xf68]
    // 0xfaea74: r2 = Null
    //     0xfaea74: mov             x2, NULL
    // 0xfaea78: r0 = AllocateClosure()
    //     0xfaea78: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfaea7c: mov             x1, x0
    // 0xfaea80: ldur            x0, [fp, #-0x10]
    // 0xfaea84: StoreField: r0->field_13 = r1
    //     0xfaea84: stur            w1, [x0, #0x13]
    // 0xfaea88: LeaveFrame
    //     0xfaea88: mov             SP, fp
    //     0xfaea8c: ldp             fp, lr, [SP], #0x10
    // 0xfaea90: ret
    //     0xfaea90: ret             
  }
  [closure] String <anonymous closure>(dynamic, MaterialLocalizations) {
    // ** addr: 0xfaeaa0, size: 0x48
    // 0xfaeaa0: EnterFrame
    //     0xfaeaa0: stp             fp, lr, [SP, #-0x10]!
    //     0xfaeaa4: mov             fp, SP
    // 0xfaeaa8: CheckStackOverflow
    //     0xfaeaa8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfaeaac: cmp             SP, x16
    //     0xfaeab0: b.ls            #0xfaeae0
    // 0xfaeab4: ldr             x1, [fp, #0x10]
    // 0xfaeab8: r0 = LoadClassIdInstr(r1)
    //     0xfaeab8: ldur            x0, [x1, #-1]
    //     0xfaeabc: ubfx            x0, x0, #0xc, #0x14
    // 0xfaeac0: r0 = GDT[cid_x0 + 0x15235]()
    //     0xfaeac0: mov             x17, #0x5235
    //     0xfaeac4: movk            x17, #1, lsl #16
    //     0xfaeac8: add             lr, x0, x17
    //     0xfaeacc: ldr             lr, [x21, lr, lsl #3]
    //     0xfaead0: blr             lr
    // 0xfaead4: LeaveFrame
    //     0xfaead4: mov             SP, fp
    //     0xfaead8: ldp             fp, lr, [SP], #0x10
    // 0xfaeadc: ret
    //     0xfaeadc: ret             
    // 0xfaeae0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfaeae0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfaeae4: b               #0xfaeab4
  }
  [closure] IconData <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0xfaeae8, size: 0x7c
    // 0xfaeae8: EnterFrame
    //     0xfaeae8: stp             fp, lr, [SP, #-0x10]!
    //     0xfaeaec: mov             fp, SP
    // 0xfaeaf0: CheckStackOverflow
    //     0xfaeaf0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfaeaf4: cmp             SP, x16
    //     0xfaeaf8: b.ls            #0xfaeb5c
    // 0xfaeafc: ldr             x1, [fp, #0x10]
    // 0xfaeb00: r0 = of()
    //     0xfaeb00: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfaeb04: LoadField: r1 = r0->field_23
    //     0xfaeb04: ldur            w1, [x0, #0x23]
    // 0xfaeb08: DecompressPointer r1
    //     0xfaeb08: add             x1, x1, HEAP, lsl #32
    // 0xfaeb0c: LoadField: r2 = r1->field_7
    //     0xfaeb0c: ldur            x2, [x1, #7]
    // 0xfaeb10: cmp             x2, #2
    // 0xfaeb14: b.gt            #0xfaeb24
    // 0xfaeb18: cmp             x2, #1
    // 0xfaeb1c: b.gt            #0xfaeb34
    // 0xfaeb20: b               #0xfaeb48
    // 0xfaeb24: cmp             x2, #4
    // 0xfaeb28: b.gt            #0xfaeb48
    // 0xfaeb2c: cmp             x2, #3
    // 0xfaeb30: b.le            #0xfaeb48
    // 0xfaeb34: r0 = Instance_IconData
    //     0xfaeb34: add             x0, PP, #0x95, lsl #12  ; [pp+0x95f70] Obj!IconData@128abb1
    //     0xfaeb38: ldr             x0, [x0, #0xf70]
    // 0xfaeb3c: LeaveFrame
    //     0xfaeb3c: mov             SP, fp
    //     0xfaeb40: ldp             fp, lr, [SP], #0x10
    // 0xfaeb44: ret
    //     0xfaeb44: ret             
    // 0xfaeb48: r0 = Instance_IconData
    //     0xfaeb48: add             x0, PP, #0x17, lsl #12  ; [pp+0x176d8] Obj!IconData@128a2d1
    //     0xfaeb4c: ldr             x0, [x0, #0x6d8]
    // 0xfaeb50: LeaveFrame
    //     0xfaeb50: mov             SP, fp
    //     0xfaeb54: ldp             fp, lr, [SP], #0x10
    // 0xfaeb58: ret
    //     0xfaeb58: ret             
    // 0xfaeb5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfaeb5c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfaeb60: b               #0xfaeafc
  }
  [closure] ((dynamic, BuildContext) => Widget)? <anonymous closure>(dynamic, ActionIconThemeData?) {
    // ** addr: 0xfaeb64, size: 0x24
    // 0xfaeb64: ldr             x1, [SP]
    // 0xfaeb68: cmp             w1, NULL
    // 0xfaeb6c: b.ne            #0xfaeb78
    // 0xfaeb70: r0 = Null
    //     0xfaeb70: mov             x0, NULL
    // 0xfaeb74: b               #0xfaeb84
    // 0xfaeb78: LoadField: r2 = r1->field_7
    //     0xfaeb78: ldur            w2, [x1, #7]
    // 0xfaeb7c: DecompressPointer r2
    //     0xfaeb7c: add             x2, x2, HEAP, lsl #32
    // 0xfaeb80: mov             x0, x2
    // 0xfaeb84: ret
    //     0xfaeb84: ret             
  }
}

// class id: 6192, size: 0x18, field offset: 0xc
//   const constructor, 
class _ActionIcon extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfae8d4, size: 0xf0
    // 0xfae8d4: EnterFrame
    //     0xfae8d4: stp             fp, lr, [SP, #-0x10]!
    //     0xfae8d8: mov             fp, SP
    // 0xfae8dc: AllocStack(0x20)
    //     0xfae8dc: sub             SP, SP, #0x20
    // 0xfae8e0: SetupParameters(_ActionIcon this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xfae8e0: mov             x0, x2
    //     0xfae8e4: stur            x2, [fp, #-0x10]
    //     0xfae8e8: mov             x2, x1
    //     0xfae8ec: stur            x1, [fp, #-8]
    // 0xfae8f0: CheckStackOverflow
    //     0xfae8f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfae8f4: cmp             SP, x16
    //     0xfae8f8: b.ls            #0xfae9bc
    // 0xfae8fc: mov             x1, x0
    // 0xfae900: r0 = of()
    //     0xfae900: bl              #0xfae9c4  ; [package:flutter/src/material/action_icons_theme.dart] ActionIconTheme::of
    // 0xfae904: ldur            x1, [fp, #-8]
    // 0xfae908: LoadField: r0 = r1->field_b
    //     0xfae908: ldur            w0, [x1, #0xb]
    // 0xfae90c: DecompressPointer r0
    //     0xfae90c: add             x0, x0, HEAP, lsl #32
    // 0xfae910: stp             NULL, x0, [SP]
    // 0xfae914: ClosureCall
    //     0xfae914: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xfae918: ldur            x2, [x0, #0x1f]
    //     0xfae91c: blr             x2
    // 0xfae920: cmp             w0, NULL
    // 0xfae924: b.eq            #0xfae948
    // 0xfae928: ldur            x16, [fp, #-0x10]
    // 0xfae92c: stp             x16, x0, [SP]
    // 0xfae930: ClosureCall
    //     0xfae930: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xfae934: ldur            x2, [x0, #0x1f]
    //     0xfae938: blr             x2
    // 0xfae93c: LeaveFrame
    //     0xfae93c: mov             SP, fp
    //     0xfae940: ldp             fp, lr, [SP], #0x10
    // 0xfae944: ret
    //     0xfae944: ret             
    // 0xfae948: ldur            x1, [fp, #-8]
    // 0xfae94c: LoadField: r0 = r1->field_f
    //     0xfae94c: ldur            w0, [x1, #0xf]
    // 0xfae950: DecompressPointer r0
    //     0xfae950: add             x0, x0, HEAP, lsl #32
    // 0xfae954: ldur            x16, [fp, #-0x10]
    // 0xfae958: stp             x16, x0, [SP]
    // 0xfae95c: ClosureCall
    //     0xfae95c: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xfae960: ldur            x2, [x0, #0x1f]
    //     0xfae964: blr             x2
    // 0xfae968: ldur            x1, [fp, #-0x10]
    // 0xfae96c: stur            x0, [fp, #-0x10]
    // 0xfae970: r0 = of()
    //     0xfae970: bl              #0xd0bbf8  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0xfae974: mov             x1, x0
    // 0xfae978: ldur            x0, [fp, #-8]
    // 0xfae97c: LoadField: r2 = r0->field_13
    //     0xfae97c: ldur            w2, [x0, #0x13]
    // 0xfae980: DecompressPointer r2
    //     0xfae980: add             x2, x2, HEAP, lsl #32
    // 0xfae984: stp             x1, x2, [SP]
    // 0xfae988: mov             x0, x2
    // 0xfae98c: ClosureCall
    //     0xfae98c: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xfae990: ldur            x2, [x0, #0x1f]
    //     0xfae994: blr             x2
    // 0xfae998: stur            x0, [fp, #-8]
    // 0xfae99c: r0 = Icon()
    //     0xfae99c: bl              #0xd0fd5c  ; AllocateIconStub -> Icon (size=0x40)
    // 0xfae9a0: ldur            x1, [fp, #-0x10]
    // 0xfae9a4: StoreField: r0->field_b = r1
    //     0xfae9a4: stur            w1, [x0, #0xb]
    // 0xfae9a8: ldur            x1, [fp, #-8]
    // 0xfae9ac: StoreField: r0->field_2b = r1
    //     0xfae9ac: stur            w1, [x0, #0x2b]
    // 0xfae9b0: LeaveFrame
    //     0xfae9b0: mov             SP, fp
    //     0xfae9b4: ldp             fp, lr, [SP], #0x10
    // 0xfae9b8: ret
    //     0xfae9b8: ret             
    // 0xfae9bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfae9bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfae9c0: b               #0xfae8fc
  }
}

// class id: 6194, size: 0x78, field offset: 0x74
//   const constructor, 
abstract class _ActionButton extends IconButton {

  _ build(/* No info */) {
    // ** addr: 0xfaddd4, size: 0x218
    // 0xfaddd4: EnterFrame
    //     0xfaddd4: stp             fp, lr, [SP, #-0x10]!
    //     0xfaddd8: mov             fp, SP
    // 0xfadddc: AllocStack(0x38)
    //     0xfadddc: sub             SP, SP, #0x38
    // 0xfadde0: SetupParameters(_ActionButton this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xfadde0: mov             x0, x1
    //     0xfadde4: stur            x1, [fp, #-8]
    //     0xfadde8: mov             x1, x2
    //     0xfaddec: stur            x2, [fp, #-0x10]
    // 0xfaddf0: CheckStackOverflow
    //     0xfaddf0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfaddf4: cmp             SP, x16
    //     0xfaddf8: b.ls            #0xfadfe4
    // 0xfaddfc: r1 = 2
    //     0xfaddfc: mov             x1, #2
    // 0xfade00: r0 = AllocateContext()
    //     0xfade00: bl              #0x13de838  ; AllocateContextStub
    // 0xfade04: mov             x2, x0
    // 0xfade08: ldur            x0, [fp, #-8]
    // 0xfade0c: stur            x2, [fp, #-0x18]
    // 0xfade10: StoreField: r2->field_f = r0
    //     0xfade10: stur            w0, [x2, #0xf]
    // 0xfade14: ldur            x3, [fp, #-0x10]
    // 0xfade18: StoreField: r2->field_13 = r3
    //     0xfade18: stur            w3, [x2, #0x13]
    // 0xfade1c: LoadField: r1 = r0->field_73
    //     0xfade1c: ldur            w1, [x0, #0x73]
    // 0xfade20: DecompressPointer r1
    //     0xfade20: add             x1, x1, HEAP, lsl #32
    // 0xfade24: r0 = key()
    //     0xfade24: bl              #0xd4aa70  ; [package:flutter/src/widgets/standard_component_type.dart] StandardComponentType::key
    // 0xfade28: mov             x2, x0
    // 0xfade2c: ldur            x0, [fp, #-8]
    // 0xfade30: stur            x2, [fp, #-0x38]
    // 0xfade34: LoadField: r3 = r0->field_1f
    //     0xfade34: ldur            w3, [x0, #0x1f]
    // 0xfade38: DecompressPointer r3
    //     0xfade38: add             x3, x3, HEAP, lsl #32
    // 0xfade3c: stur            x3, [fp, #-0x30]
    // 0xfade40: LoadField: r4 = r0->field_5f
    //     0xfade40: ldur            w4, [x0, #0x5f]
    // 0xfade44: DecompressPointer r4
    //     0xfade44: add             x4, x4, HEAP, lsl #32
    // 0xfade48: stur            x4, [fp, #-0x28]
    // 0xfade4c: LoadField: r5 = r0->field_2b
    //     0xfade4c: ldur            w5, [x0, #0x2b]
    // 0xfade50: DecompressPointer r5
    //     0xfade50: add             x5, x5, HEAP, lsl #32
    // 0xfade54: stur            x5, [fp, #-0x20]
    // 0xfade58: r1 = LoadClassIdInstr(r0)
    //     0xfade58: ldur            x1, [x0, #-1]
    //     0xfade5c: ubfx            x1, x1, #0xc, #0x14
    // 0xfade60: r17 = 6195
    //     0xfade60: mov             x17, #0x1833
    // 0xfade64: cmp             x1, x17
    // 0xfade68: b.ne            #0xfadea4
    // 0xfade6c: ldur            x1, [fp, #-0x10]
    // 0xfade70: r0 = of()
    //     0xfade70: bl              #0xd0bbf8  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0xfade74: r1 = LoadClassIdInstr(r0)
    //     0xfade74: ldur            x1, [x0, #-1]
    //     0xfade78: ubfx            x1, x1, #0xc, #0x14
    // 0xfade7c: mov             x16, x0
    // 0xfade80: mov             x0, x1
    // 0xfade84: mov             x1, x16
    // 0xfade88: r0 = GDT[cid_x0 + 0x1743f]()
    //     0xfade88: mov             x17, #0x743f
    //     0xfade8c: movk            x17, #1, lsl #16
    //     0xfade90: add             lr, x0, x17
    //     0xfade94: ldr             lr, [x21, lr, lsl #3]
    //     0xfade98: blr             lr
    // 0xfade9c: mov             x4, x0
    // 0xfadea0: b               #0xfadf60
    // 0xfadea4: r17 = 6196
    //     0xfadea4: mov             x17, #0x1834
    // 0xfadea8: cmp             x1, x17
    // 0xfadeac: b.ne            #0xfadee8
    // 0xfadeb0: ldur            x1, [fp, #-0x10]
    // 0xfadeb4: r0 = of()
    //     0xfadeb4: bl              #0xd0bbf8  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0xfadeb8: r1 = LoadClassIdInstr(r0)
    //     0xfadeb8: ldur            x1, [x0, #-1]
    //     0xfadebc: ubfx            x1, x1, #0xc, #0x14
    // 0xfadec0: mov             x16, x0
    // 0xfadec4: mov             x0, x1
    // 0xfadec8: mov             x1, x16
    // 0xfadecc: r0 = GDT[cid_x0 + 0x1743f]()
    //     0xfadecc: mov             x17, #0x743f
    //     0xfaded0: movk            x17, #1, lsl #16
    //     0xfaded4: add             lr, x0, x17
    //     0xfaded8: ldr             lr, [x21, lr, lsl #3]
    //     0xfadedc: blr             lr
    // 0xfadee0: mov             x4, x0
    // 0xfadee4: b               #0xfadf60
    // 0xfadee8: r17 = 6197
    //     0xfadee8: mov             x17, #0x1835
    // 0xfadeec: cmp             x1, x17
    // 0xfadef0: b.ne            #0xfadf2c
    // 0xfadef4: ldur            x1, [fp, #-0x10]
    // 0xfadef8: r0 = of()
    //     0xfadef8: bl              #0xd0bbf8  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0xfadefc: r1 = LoadClassIdInstr(r0)
    //     0xfadefc: ldur            x1, [x0, #-1]
    //     0xfadf00: ubfx            x1, x1, #0xc, #0x14
    // 0xfadf04: mov             x16, x0
    // 0xfadf08: mov             x0, x1
    // 0xfadf0c: mov             x1, x16
    // 0xfadf10: r0 = GDT[cid_x0 + 0x16ae1]()
    //     0xfadf10: mov             x17, #0x6ae1
    //     0xfadf14: movk            x17, #1, lsl #16
    //     0xfadf18: add             lr, x0, x17
    //     0xfadf1c: ldr             lr, [x21, lr, lsl #3]
    //     0xfadf20: blr             lr
    // 0xfadf24: mov             x4, x0
    // 0xfadf28: b               #0xfadf60
    // 0xfadf2c: ldur            x1, [fp, #-0x10]
    // 0xfadf30: r0 = of()
    //     0xfadf30: bl              #0xd0bbf8  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0xfadf34: r1 = LoadClassIdInstr(r0)
    //     0xfadf34: ldur            x1, [x0, #-1]
    //     0xfadf38: ubfx            x1, x1, #0xc, #0x14
    // 0xfadf3c: mov             x16, x0
    // 0xfadf40: mov             x0, x1
    // 0xfadf44: mov             x1, x16
    // 0xfadf48: r0 = GDT[cid_x0 + 0x15235]()
    //     0xfadf48: mov             x17, #0x5235
    //     0xfadf4c: movk            x17, #1, lsl #16
    //     0xfadf50: add             lr, x0, x17
    //     0xfadf54: ldr             lr, [x21, lr, lsl #3]
    //     0xfadf58: blr             lr
    // 0xfadf5c: mov             x4, x0
    // 0xfadf60: ldur            x0, [fp, #-0x38]
    // 0xfadf64: ldur            x1, [fp, #-0x30]
    // 0xfadf68: ldur            x2, [fp, #-0x28]
    // 0xfadf6c: ldur            x3, [fp, #-0x20]
    // 0xfadf70: stur            x4, [fp, #-8]
    // 0xfadf74: r0 = IconButton()
    //     0xfadf74: bl              #0xd16288  ; AllocateIconButtonStub -> IconButton (size=0x74)
    // 0xfadf78: mov             x3, x0
    // 0xfadf7c: ldur            x0, [fp, #-0x20]
    // 0xfadf80: stur            x3, [fp, #-0x10]
    // 0xfadf84: StoreField: r3->field_2b = r0
    //     0xfadf84: stur            w0, [x3, #0x2b]
    // 0xfadf88: ldur            x2, [fp, #-0x18]
    // 0xfadf8c: r1 = Function '<anonymous closure>':.
    //     0xfadf8c: add             x1, PP, #0x95, lsl #12  ; [pp+0x95f98] AnonymousClosure: (0xfadfec), in [package:flutter/src/material/action_buttons.dart] _ActionButton::build (0xfaddd4)
    //     0xfadf90: ldr             x1, [x1, #0xf98]
    // 0xfadf94: r0 = AllocateClosure()
    //     0xfadf94: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfadf98: mov             x1, x0
    // 0xfadf9c: ldur            x0, [fp, #-0x10]
    // 0xfadfa0: StoreField: r0->field_3b = r1
    //     0xfadfa0: stur            w1, [x0, #0x3b]
    // 0xfadfa4: r1 = false
    //     0xfadfa4: add             x1, NULL, #0x30  ; false
    // 0xfadfa8: StoreField: r0->field_4f = r1
    //     0xfadfa8: stur            w1, [x0, #0x4f]
    // 0xfadfac: ldur            x1, [fp, #-8]
    // 0xfadfb0: StoreField: r0->field_53 = r1
    //     0xfadfb0: stur            w1, [x0, #0x53]
    // 0xfadfb4: ldur            x1, [fp, #-0x28]
    // 0xfadfb8: StoreField: r0->field_5f = r1
    //     0xfadfb8: stur            w1, [x0, #0x5f]
    // 0xfadfbc: ldur            x1, [fp, #-0x30]
    // 0xfadfc0: StoreField: r0->field_1f = r1
    //     0xfadfc0: stur            w1, [x0, #0x1f]
    // 0xfadfc4: r1 = Instance__IconButtonVariant
    //     0xfadfc4: add             x1, PP, #0x17, lsl #12  ; [pp+0x177a8] Obj!_IconButtonVariant@12c57a1
    //     0xfadfc8: ldr             x1, [x1, #0x7a8]
    // 0xfadfcc: StoreField: r0->field_6f = r1
    //     0xfadfcc: stur            w1, [x0, #0x6f]
    // 0xfadfd0: ldur            x1, [fp, #-0x38]
    // 0xfadfd4: StoreField: r0->field_7 = r1
    //     0xfadfd4: stur            w1, [x0, #7]
    // 0xfadfd8: LeaveFrame
    //     0xfadfd8: mov             SP, fp
    //     0xfadfdc: ldp             fp, lr, [SP], #0x10
    // 0xfadfe0: ret
    //     0xfadfe0: ret             
    // 0xfadfe4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfadfe4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfadfe8: b               #0xfaddfc
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xfadfec, size: 0xec
    // 0xfadfec: EnterFrame
    //     0xfadfec: stp             fp, lr, [SP, #-0x10]!
    //     0xfadff0: mov             fp, SP
    // 0xfadff4: AllocStack(0x10)
    //     0xfadff4: sub             SP, SP, #0x10
    // 0xfadff8: SetupParameters([dynamic _ /* r0 */])
    //     0xfadff8: ldr             x0, [fp, #0x10]
    //     0xfadffc: ldur            w1, [x0, #0x17]
    //     0xfae000: add             x1, x1, HEAP, lsl #32
    // 0xfae004: CheckStackOverflow
    //     0xfae004: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfae008: cmp             SP, x16
    //     0xfae00c: b.ls            #0xfae0d0
    // 0xfae010: LoadField: r0 = r1->field_f
    //     0xfae010: ldur            w0, [x1, #0xf]
    // 0xfae014: DecompressPointer r0
    //     0xfae014: add             x0, x0, HEAP, lsl #32
    // 0xfae018: LoadField: r2 = r0->field_3b
    //     0xfae018: ldur            w2, [x0, #0x3b]
    // 0xfae01c: DecompressPointer r2
    //     0xfae01c: add             x2, x2, HEAP, lsl #32
    // 0xfae020: cmp             w2, NULL
    // 0xfae024: b.eq            #0xfae040
    // 0xfae028: str             x2, [SP]
    // 0xfae02c: mov             x0, x2
    // 0xfae030: ClosureCall
    //     0xfae030: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xfae034: ldur            x2, [x0, #0x1f]
    //     0xfae038: blr             x2
    // 0xfae03c: b               #0xfae0c0
    // 0xfae040: LoadField: r2 = r1->field_13
    //     0xfae040: ldur            w2, [x1, #0x13]
    // 0xfae044: DecompressPointer r2
    //     0xfae044: add             x2, x2, HEAP, lsl #32
    // 0xfae048: r1 = LoadClassIdInstr(r0)
    //     0xfae048: ldur            x1, [x0, #-1]
    //     0xfae04c: ubfx            x1, x1, #0xc, #0x14
    // 0xfae050: r17 = 6195
    //     0xfae050: mov             x17, #0x1833
    // 0xfae054: cmp             x1, x17
    // 0xfae058: b.ne            #0xfae070
    // 0xfae05c: mov             x1, x2
    // 0xfae060: r0 = of()
    //     0xfae060: bl              #0xb35cb4  ; [package:flutter/src/material/scaffold.dart] Scaffold::of
    // 0xfae064: mov             x1, x0
    // 0xfae068: r0 = openEndDrawer()
    //     0xfae068: bl              #0xfae154  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::openEndDrawer
    // 0xfae06c: b               #0xfae0c0
    // 0xfae070: r17 = 6196
    //     0xfae070: mov             x17, #0x1834
    // 0xfae074: cmp             x1, x17
    // 0xfae078: b.ne            #0xfae090
    // 0xfae07c: mov             x1, x2
    // 0xfae080: r0 = of()
    //     0xfae080: bl              #0xb35cb4  ; [package:flutter/src/material/scaffold.dart] Scaffold::of
    // 0xfae084: mov             x1, x0
    // 0xfae088: r0 = openDrawer()
    //     0xfae088: bl              #0xd564d4  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::openDrawer
    // 0xfae08c: b               #0xfae0c0
    // 0xfae090: r17 = 6197
    //     0xfae090: mov             x17, #0x1835
    // 0xfae094: cmp             x1, x17
    // 0xfae098: b.ne            #0xfae0b0
    // 0xfae09c: r16 = <Object?>
    //     0xfae09c: ldr             x16, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0xfae0a0: stp             x2, x16, [SP]
    // 0xfae0a4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xfae0a4: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xfae0a8: r0 = maybePop()
    //     0xfae0a8: bl              #0xfae0d8  ; [package:flutter/src/widgets/navigator.dart] Navigator::maybePop
    // 0xfae0ac: b               #0xfae0c0
    // 0xfae0b0: r16 = <Object?>
    //     0xfae0b0: ldr             x16, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0xfae0b4: stp             x2, x16, [SP]
    // 0xfae0b8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xfae0b8: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xfae0bc: r0 = maybePop()
    //     0xfae0bc: bl              #0xfae0d8  ; [package:flutter/src/widgets/navigator.dart] Navigator::maybePop
    // 0xfae0c0: r0 = Null
    //     0xfae0c0: mov             x0, NULL
    // 0xfae0c4: LeaveFrame
    //     0xfae0c4: mov             SP, fp
    //     0xfae0c8: ldp             fp, lr, [SP], #0x10
    // 0xfae0cc: ret
    //     0xfae0cc: ret             
    // 0xfae0d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfae0d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfae0d4: b               #0xfae010
  }
}

// class id: 6195, size: 0x78, field offset: 0x78
//   const constructor, 
class EndDrawerButton extends _ActionButton {
}

// class id: 6196, size: 0x78, field offset: 0x78
//   const constructor, 
class DrawerButton extends _ActionButton {
}

// class id: 6197, size: 0x78, field offset: 0x78
//   const constructor, 
class CloseButton extends _ActionButton {

  CloseButtonIcon field_20;
  bool field_50;
  _IconButtonVariant field_70;
  StandardComponentType field_74;
}

// class id: 6198, size: 0x78, field offset: 0x78
//   const constructor, 
class BackButton extends _ActionButton {

  BackButtonIcon field_20;
  bool field_50;
  _IconButtonVariant field_70;
  StandardComponentType field_74;
}
