// lib: , url: package:flutter/src/material/navigation_drawer_theme.dart

// class id: 1048921, size: 0x8
class :: {
}

// class id: 5135, size: 0x30, field offset: 0x8
//   const constructor, 
class NavigationDrawerThemeData extends _MixinApplication3&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0x1134e34, size: 0x78
    // 0x1134e34: EnterFrame
    //     0x1134e34: stp             fp, lr, [SP, #-0x10]!
    //     0x1134e38: mov             fp, SP
    // 0x1134e3c: AllocStack(0x40)
    //     0x1134e3c: sub             SP, SP, #0x40
    // 0x1134e40: CheckStackOverflow
    //     0x1134e40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1134e44: cmp             SP, x16
    //     0x1134e48: b.ls            #0x1134ea4
    // 0x1134e4c: ldr             x0, [fp, #0x10]
    // 0x1134e50: LoadField: r1 = r0->field_7
    //     0x1134e50: ldur            w1, [x0, #7]
    // 0x1134e54: DecompressPointer r1
    //     0x1134e54: add             x1, x1, HEAP, lsl #32
    // 0x1134e58: LoadField: r2 = r0->field_f
    //     0x1134e58: ldur            w2, [x0, #0xf]
    // 0x1134e5c: DecompressPointer r2
    //     0x1134e5c: add             x2, x2, HEAP, lsl #32
    // 0x1134e60: stp             NULL, x2, [SP, #0x30]
    // 0x1134e64: stp             NULL, NULL, [SP, #0x20]
    // 0x1134e68: stp             NULL, NULL, [SP, #0x10]
    // 0x1134e6c: stp             NULL, NULL, [SP]
    // 0x1134e70: r2 = Null
    //     0x1134e70: mov             x2, NULL
    // 0x1134e74: r4 = const [0, 0xa, 0x8, 0xa, null]
    //     0x1134e74: add             x4, PP, #0x26, lsl #12  ; [pp+0x261f8] List(5) [0, 0xa, 0x8, 0xa, Null]
    //     0x1134e78: ldr             x4, [x4, #0x1f8]
    // 0x1134e7c: r0 = hash()
    //     0x1134e7c: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x1134e80: mov             x2, x0
    // 0x1134e84: r0 = BoxInt64Instr(r2)
    //     0x1134e84: sbfiz           x0, x2, #1, #0x1f
    //     0x1134e88: cmp             x2, x0, asr #1
    //     0x1134e8c: b.eq            #0x1134e98
    //     0x1134e90: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1134e94: stur            x2, [x0, #7]
    // 0x1134e98: LeaveFrame
    //     0x1134e98: mov             SP, fp
    //     0x1134e9c: ldp             fp, lr, [SP], #0x10
    // 0x1134ea0: ret
    //     0x1134ea0: ret             
    // 0x1134ea4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1134ea4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1134ea8: b               #0x1134e4c
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x116667c, size: 0x150
    // 0x116667c: EnterFrame
    //     0x116667c: stp             fp, lr, [SP, #-0x10]!
    //     0x1166680: mov             fp, SP
    // 0x1166684: AllocStack(0x28)
    //     0x1166684: sub             SP, SP, #0x28
    // 0x1166688: SetupParameters(dynamic _ /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */, dynamic _ /* d0 => d0, fp-0x28 */)
    //     0x1166688: mov             x4, x1
    //     0x116668c: mov             x0, x2
    //     0x1166690: stur            x1, [fp, #-0x10]
    //     0x1166694: stur            x2, [fp, #-0x18]
    //     0x1166698: stur            d0, [fp, #-0x28]
    // 0x116669c: CheckStackOverflow
    //     0x116669c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11666a0: cmp             SP, x16
    //     0x11666a4: b.ls            #0x11667a0
    // 0x11666a8: cmp             w4, w0
    // 0x11666ac: b.ne            #0x11666c0
    // 0x11666b0: mov             x0, x4
    // 0x11666b4: LeaveFrame
    //     0x11666b4: mov             SP, fp
    //     0x11666b8: ldp             fp, lr, [SP], #0x10
    // 0x11666bc: ret
    //     0x11666bc: ret             
    // 0x11666c0: LoadField: r1 = r4->field_7
    //     0x11666c0: ldur            w1, [x4, #7]
    // 0x11666c4: DecompressPointer r1
    //     0x11666c4: add             x1, x1, HEAP, lsl #32
    // 0x11666c8: LoadField: r2 = r0->field_7
    //     0x11666c8: ldur            w2, [x0, #7]
    // 0x11666cc: DecompressPointer r2
    //     0x11666cc: add             x2, x2, HEAP, lsl #32
    // 0x11666d0: r5 = inline_Allocate_Double()
    //     0x11666d0: ldp             x5, x3, [THR, #0x60]  ; THR::top
    //     0x11666d4: add             x5, x5, #0x10
    //     0x11666d8: cmp             x3, x5
    //     0x11666dc: b.ls            #0x11667a8
    //     0x11666e0: str             x5, [THR, #0x60]  ; THR::top
    //     0x11666e4: sub             x5, x5, #0xf
    //     0x11666e8: mov             x3, #0xe19c
    //     0x11666ec: movk            x3, #3, lsl #16
    //     0x11666f0: stur            x3, [x5, #-1]
    // 0x11666f4: dmb             ishst
    // 0x11666f8: StoreField: r5->field_7 = d0
    //     0x11666f8: stur            d0, [x5, #7]
    // 0x11666fc: mov             x3, x5
    // 0x1166700: stur            x5, [fp, #-8]
    // 0x1166704: r0 = lerpDouble()
    //     0x1166704: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1166708: ldur            x3, [fp, #-8]
    // 0x116670c: r1 = Null
    //     0x116670c: mov             x1, NULL
    // 0x1166710: r2 = Null
    //     0x1166710: mov             x2, NULL
    // 0x1166714: stur            x0, [fp, #-0x20]
    // 0x1166718: r0 = lerp()
    //     0x1166718: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x116671c: ldur            x0, [fp, #-0x10]
    // 0x1166720: LoadField: r1 = r0->field_f
    //     0x1166720: ldur            w1, [x0, #0xf]
    // 0x1166724: DecompressPointer r1
    //     0x1166724: add             x1, x1, HEAP, lsl #32
    // 0x1166728: ldur            x0, [fp, #-0x18]
    // 0x116672c: LoadField: r2 = r0->field_f
    //     0x116672c: ldur            w2, [x0, #0xf]
    // 0x1166730: DecompressPointer r2
    //     0x1166730: add             x2, x2, HEAP, lsl #32
    // 0x1166734: ldur            x3, [fp, #-8]
    // 0x1166738: r0 = lerpDouble()
    //     0x1166738: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x116673c: ldur            x3, [fp, #-8]
    // 0x1166740: r1 = Null
    //     0x1166740: mov             x1, NULL
    // 0x1166744: r2 = Null
    //     0x1166744: mov             x2, NULL
    // 0x1166748: stur            x0, [fp, #-0x10]
    // 0x116674c: r0 = lerp()
    //     0x116674c: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1166750: ldur            x3, [fp, #-8]
    // 0x1166754: r1 = Null
    //     0x1166754: mov             x1, NULL
    // 0x1166758: r2 = Null
    //     0x1166758: mov             x2, NULL
    // 0x116675c: r0 = lerp()
    //     0x116675c: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1166760: ldur            x3, [fp, #-8]
    // 0x1166764: r1 = Null
    //     0x1166764: mov             x1, NULL
    // 0x1166768: r2 = Null
    //     0x1166768: mov             x2, NULL
    // 0x116676c: r0 = lerp()
    //     0x116676c: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1166770: ldur            d0, [fp, #-0x28]
    // 0x1166774: r1 = Null
    //     0x1166774: mov             x1, NULL
    // 0x1166778: r2 = Null
    //     0x1166778: mov             x2, NULL
    // 0x116677c: r0 = lerp()
    //     0x116677c: bl              #0x115deb4  ; [package:flutter/src/painting/borders.dart] ShapeBorder::lerp
    // 0x1166780: r0 = NavigationDrawerThemeData()
    //     0x1166780: bl              #0x11667cc  ; AllocateNavigationDrawerThemeDataStub -> NavigationDrawerThemeData (size=0x30)
    // 0x1166784: ldur            x1, [fp, #-0x20]
    // 0x1166788: StoreField: r0->field_7 = r1
    //     0x1166788: stur            w1, [x0, #7]
    // 0x116678c: ldur            x1, [fp, #-0x10]
    // 0x1166790: StoreField: r0->field_f = r1
    //     0x1166790: stur            w1, [x0, #0xf]
    // 0x1166794: LeaveFrame
    //     0x1166794: mov             SP, fp
    //     0x1166798: ldp             fp, lr, [SP], #0x10
    // 0x116679c: ret
    //     0x116679c: ret             
    // 0x11667a0: r0 = StackOverflowSharedWithFPURegs()
    //     0x11667a0: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x11667a4: b               #0x11666a8
    // 0x11667a8: SaveReg d0
    //     0x11667a8: str             q0, [SP, #-0x10]!
    // 0x11667ac: stp             x2, x4, [SP, #-0x10]!
    // 0x11667b0: stp             x0, x1, [SP, #-0x10]!
    // 0x11667b4: r0 = AllocateDouble()
    //     0x11667b4: bl              #0x13df878  ; AllocateDoubleStub
    // 0x11667b8: mov             x5, x0
    // 0x11667bc: ldp             x0, x1, [SP], #0x10
    // 0x11667c0: ldp             x2, x4, [SP], #0x10
    // 0x11667c4: RestoreReg d0
    //     0x11667c4: ldr             q0, [SP], #0x10
    // 0x11667c8: b               #0x11666f8
  }
  _ ==(/* No info */) {
    // ** addr: 0x126fe20, size: 0x13c
    // 0x126fe20: EnterFrame
    //     0x126fe20: stp             fp, lr, [SP, #-0x10]!
    //     0x126fe24: mov             fp, SP
    // 0x126fe28: AllocStack(0x10)
    //     0x126fe28: sub             SP, SP, #0x10
    // 0x126fe2c: CheckStackOverflow
    //     0x126fe2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x126fe30: cmp             SP, x16
    //     0x126fe34: b.ls            #0x126ff54
    // 0x126fe38: ldr             x0, [fp, #0x10]
    // 0x126fe3c: cmp             w0, NULL
    // 0x126fe40: b.ne            #0x126fe54
    // 0x126fe44: r0 = false
    //     0x126fe44: add             x0, NULL, #0x30  ; false
    // 0x126fe48: LeaveFrame
    //     0x126fe48: mov             SP, fp
    //     0x126fe4c: ldp             fp, lr, [SP], #0x10
    // 0x126fe50: ret
    //     0x126fe50: ret             
    // 0x126fe54: ldr             x1, [fp, #0x18]
    // 0x126fe58: cmp             w1, w0
    // 0x126fe5c: b.ne            #0x126fe70
    // 0x126fe60: r0 = true
    //     0x126fe60: add             x0, NULL, #0x20  ; true
    // 0x126fe64: LeaveFrame
    //     0x126fe64: mov             SP, fp
    //     0x126fe68: ldp             fp, lr, [SP], #0x10
    // 0x126fe6c: ret
    //     0x126fe6c: ret             
    // 0x126fe70: str             x0, [SP]
    // 0x126fe74: r0 = runtimeType()
    //     0x126fe74: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x126fe78: r1 = LoadClassIdInstr(r0)
    //     0x126fe78: ldur            x1, [x0, #-1]
    //     0x126fe7c: ubfx            x1, x1, #0xc, #0x14
    // 0x126fe80: r16 = NavigationDrawerThemeData
    //     0x126fe80: add             x16, PP, #0x26, lsl #12  ; [pp+0x26680] Type: NavigationDrawerThemeData
    //     0x126fe84: ldr             x16, [x16, #0x680]
    // 0x126fe88: stp             x16, x0, [SP]
    // 0x126fe8c: mov             x0, x1
    // 0x126fe90: mov             lr, x0
    // 0x126fe94: ldr             lr, [x21, lr, lsl #3]
    // 0x126fe98: blr             lr
    // 0x126fe9c: tbz             w0, #4, #0x126feb0
    // 0x126fea0: r0 = false
    //     0x126fea0: add             x0, NULL, #0x30  ; false
    // 0x126fea4: LeaveFrame
    //     0x126fea4: mov             SP, fp
    //     0x126fea8: ldp             fp, lr, [SP], #0x10
    // 0x126feac: ret
    //     0x126feac: ret             
    // 0x126feb0: ldr             x1, [fp, #0x10]
    // 0x126feb4: r0 = 60
    //     0x126feb4: mov             x0, #0x3c
    // 0x126feb8: branchIfSmi(r1, 0x126fec4)
    //     0x126feb8: tbz             w1, #0, #0x126fec4
    // 0x126febc: r0 = LoadClassIdInstr(r1)
    //     0x126febc: ldur            x0, [x1, #-1]
    //     0x126fec0: ubfx            x0, x0, #0xc, #0x14
    // 0x126fec4: r17 = 5135
    //     0x126fec4: mov             x17, #0x140f
    // 0x126fec8: cmp             x0, x17
    // 0x126fecc: b.ne            #0x126ff44
    // 0x126fed0: ldr             x2, [fp, #0x18]
    // 0x126fed4: LoadField: r0 = r1->field_7
    //     0x126fed4: ldur            w0, [x1, #7]
    // 0x126fed8: DecompressPointer r0
    //     0x126fed8: add             x0, x0, HEAP, lsl #32
    // 0x126fedc: LoadField: r3 = r2->field_7
    //     0x126fedc: ldur            w3, [x2, #7]
    // 0x126fee0: DecompressPointer r3
    //     0x126fee0: add             x3, x3, HEAP, lsl #32
    // 0x126fee4: r4 = LoadClassIdInstr(r0)
    //     0x126fee4: ldur            x4, [x0, #-1]
    //     0x126fee8: ubfx            x4, x4, #0xc, #0x14
    // 0x126feec: stp             x3, x0, [SP]
    // 0x126fef0: mov             x0, x4
    // 0x126fef4: mov             lr, x0
    // 0x126fef8: ldr             lr, [x21, lr, lsl #3]
    // 0x126fefc: blr             lr
    // 0x126ff00: tbnz            w0, #4, #0x126ff44
    // 0x126ff04: ldr             x1, [fp, #0x18]
    // 0x126ff08: ldr             x0, [fp, #0x10]
    // 0x126ff0c: LoadField: r2 = r0->field_f
    //     0x126ff0c: ldur            w2, [x0, #0xf]
    // 0x126ff10: DecompressPointer r2
    //     0x126ff10: add             x2, x2, HEAP, lsl #32
    // 0x126ff14: LoadField: r0 = r1->field_f
    //     0x126ff14: ldur            w0, [x1, #0xf]
    // 0x126ff18: DecompressPointer r0
    //     0x126ff18: add             x0, x0, HEAP, lsl #32
    // 0x126ff1c: r1 = LoadClassIdInstr(r2)
    //     0x126ff1c: ldur            x1, [x2, #-1]
    //     0x126ff20: ubfx            x1, x1, #0xc, #0x14
    // 0x126ff24: stp             x0, x2, [SP]
    // 0x126ff28: mov             x0, x1
    // 0x126ff2c: mov             lr, x0
    // 0x126ff30: ldr             lr, [x21, lr, lsl #3]
    // 0x126ff34: blr             lr
    // 0x126ff38: tbnz            w0, #4, #0x126ff44
    // 0x126ff3c: r0 = true
    //     0x126ff3c: add             x0, NULL, #0x20  ; true
    // 0x126ff40: b               #0x126ff48
    // 0x126ff44: r0 = false
    //     0x126ff44: add             x0, NULL, #0x30  ; false
    // 0x126ff48: LeaveFrame
    //     0x126ff48: mov             SP, fp
    //     0x126ff4c: ldp             fp, lr, [SP], #0x10
    // 0x126ff50: ret
    //     0x126ff50: ret             
    // 0x126ff54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x126ff54: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x126ff58: b               #0x126fe38
  }
}
