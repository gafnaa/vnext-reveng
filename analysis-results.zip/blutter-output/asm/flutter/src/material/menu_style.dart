// lib: , url: package:flutter/src/material/menu_style.dart

// class id: 1048917, size: 0x8
class :: {
}

// class id: 5137, size: 0x3c, field offset: 0x8
//   const constructor, 
class MenuStyle extends _MixinApplication3&Object&Diagnosticable {

  static _ lerp(/* No info */) {
    // ** addr: 0x11669bc, size: 0x50
    // 0x11669bc: EnterFrame
    //     0x11669bc: stp             fp, lr, [SP, #-0x10]!
    //     0x11669c0: mov             fp, SP
    // 0x11669c4: mov             x0, x1
    // 0x11669c8: CheckStackOverflow
    //     0x11669c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11669cc: cmp             SP, x16
    //     0x11669d0: b.ls            #0x1166a04
    // 0x11669d4: cmp             w0, w2
    // 0x11669d8: b.ne            #0x11669e8
    // 0x11669dc: LeaveFrame
    //     0x11669dc: mov             SP, fp
    //     0x11669e0: ldp             fp, lr, [SP], #0x10
    // 0x11669e4: ret
    //     0x11669e4: ret             
    // 0x11669e8: r1 = Null
    //     0x11669e8: mov             x1, NULL
    // 0x11669ec: r2 = Null
    //     0x11669ec: mov             x2, NULL
    // 0x11669f0: r0 = lerp()
    //     0x11669f0: bl              #0x1160c48  ; [package:flutter/src/painting/alignment.dart] AlignmentGeometry::lerp
    // 0x11669f4: r0 = MenuStyle()
    //     0x11669f4: bl              #0x1166a0c  ; AllocateMenuStyleStub -> MenuStyle (size=0x3c)
    // 0x11669f8: LeaveFrame
    //     0x11669f8: mov             SP, fp
    //     0x11669fc: ldp             fp, lr, [SP], #0x10
    // 0x1166a00: ret
    //     0x1166a00: ret             
    // 0x1166a04: r0 = StackOverflowSharedWithFPURegs()
    //     0x1166a04: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1166a08: b               #0x11669d4
  }
  _ ==(/* No info */) {
    // ** addr: 0x126fc14, size: 0xd0
    // 0x126fc14: EnterFrame
    //     0x126fc14: stp             fp, lr, [SP, #-0x10]!
    //     0x126fc18: mov             fp, SP
    // 0x126fc1c: AllocStack(0x10)
    //     0x126fc1c: sub             SP, SP, #0x10
    // 0x126fc20: CheckStackOverflow
    //     0x126fc20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x126fc24: cmp             SP, x16
    //     0x126fc28: b.ls            #0x126fcdc
    // 0x126fc2c: ldr             x0, [fp, #0x10]
    // 0x126fc30: cmp             w0, NULL
    // 0x126fc34: b.ne            #0x126fc48
    // 0x126fc38: r0 = false
    //     0x126fc38: add             x0, NULL, #0x30  ; false
    // 0x126fc3c: LeaveFrame
    //     0x126fc3c: mov             SP, fp
    //     0x126fc40: ldp             fp, lr, [SP], #0x10
    // 0x126fc44: ret
    //     0x126fc44: ret             
    // 0x126fc48: ldr             x1, [fp, #0x18]
    // 0x126fc4c: cmp             w1, w0
    // 0x126fc50: b.ne            #0x126fc64
    // 0x126fc54: r0 = true
    //     0x126fc54: add             x0, NULL, #0x20  ; true
    // 0x126fc58: LeaveFrame
    //     0x126fc58: mov             SP, fp
    //     0x126fc5c: ldp             fp, lr, [SP], #0x10
    // 0x126fc60: ret
    //     0x126fc60: ret             
    // 0x126fc64: str             x0, [SP]
    // 0x126fc68: r0 = runtimeType()
    //     0x126fc68: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x126fc6c: r1 = LoadClassIdInstr(r0)
    //     0x126fc6c: ldur            x1, [x0, #-1]
    //     0x126fc70: ubfx            x1, x1, #0xc, #0x14
    // 0x126fc74: r16 = MenuStyle
    //     0x126fc74: add             x16, PP, #0xb0, lsl #12  ; [pp+0xb09f0] Type: MenuStyle
    //     0x126fc78: ldr             x16, [x16, #0x9f0]
    // 0x126fc7c: stp             x16, x0, [SP]
    // 0x126fc80: mov             x0, x1
    // 0x126fc84: mov             lr, x0
    // 0x126fc88: ldr             lr, [x21, lr, lsl #3]
    // 0x126fc8c: blr             lr
    // 0x126fc90: tbz             w0, #4, #0x126fca4
    // 0x126fc94: r0 = false
    //     0x126fc94: add             x0, NULL, #0x30  ; false
    // 0x126fc98: LeaveFrame
    //     0x126fc98: mov             SP, fp
    //     0x126fc9c: ldp             fp, lr, [SP], #0x10
    // 0x126fca0: ret
    //     0x126fca0: ret             
    // 0x126fca4: ldr             x1, [fp, #0x10]
    // 0x126fca8: r2 = 60
    //     0x126fca8: mov             x2, #0x3c
    // 0x126fcac: branchIfSmi(r1, 0x126fcb8)
    //     0x126fcac: tbz             w1, #0, #0x126fcb8
    // 0x126fcb0: r2 = LoadClassIdInstr(r1)
    //     0x126fcb0: ldur            x2, [x1, #-1]
    //     0x126fcb4: ubfx            x2, x2, #0xc, #0x14
    // 0x126fcb8: r17 = 5137
    //     0x126fcb8: mov             x17, #0x1411
    // 0x126fcbc: cmp             x2, x17
    // 0x126fcc0: b.ne            #0x126fccc
    // 0x126fcc4: r0 = true
    //     0x126fcc4: add             x0, NULL, #0x20  ; true
    // 0x126fcc8: b               #0x126fcd0
    // 0x126fccc: r0 = false
    //     0x126fccc: add             x0, NULL, #0x30  ; false
    // 0x126fcd0: LeaveFrame
    //     0x126fcd0: mov             SP, fp
    //     0x126fcd4: ldp             fp, lr, [SP], #0x10
    // 0x126fcd8: ret
    //     0x126fcd8: ret             
    // 0x126fcdc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x126fcdc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x126fce0: b               #0x126fc2c
  }
}
