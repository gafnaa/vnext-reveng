// lib: , url: package:flutter/src/material/slider_value_indicator_shape.dart

// class id: 1048948, size: 0x8
class :: {
}

// class id: 2973, size: 0x8, field offset: 0x8
//   const constructor, 
class _RectangularSliderValueIndicatorPathPainter extends Object {

  _ paint(/* No info */) {
    // ** addr: 0x12eb2ac, size: 0x6fc
    // 0x12eb2ac: EnterFrame
    //     0x12eb2ac: stp             fp, lr, [SP, #-0x10]!
    //     0x12eb2b0: mov             fp, SP
    // 0x12eb2b4: AllocStack(0x88)
    //     0x12eb2b4: sub             SP, SP, #0x88
    // 0x12eb2b8: d2 = 0.000000
    //     0x12eb2b8: eor             v2.16b, v2.16b, v2.16b
    // 0x12eb2bc: mov             x4, x3
    // 0x12eb2c0: stur            x3, [fp, #-0x18]
    // 0x12eb2c4: mov             x3, x5
    // 0x12eb2c8: stur            x5, [fp, #-0x20]
    // 0x12eb2cc: mov             x5, x7
    // 0x12eb2d0: stur            x7, [fp, #-0x30]
    // 0x12eb2d4: mov             x7, x1
    // 0x12eb2d8: mov             x0, x6
    // 0x12eb2dc: stur            x6, [fp, #-0x28]
    // 0x12eb2e0: mov             x6, x2
    // 0x12eb2e4: mov             v4.16b, v0.16b
    // 0x12eb2e8: mov             v3.16b, v1.16b
    // 0x12eb2ec: stur            x1, [fp, #-8]
    // 0x12eb2f0: stur            x2, [fp, #-0x10]
    // 0x12eb2f4: stur            d0, [fp, #-0x50]
    // 0x12eb2f8: stur            d1, [fp, #-0x58]
    // 0x12eb2fc: CheckStackOverflow
    //     0x12eb2fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12eb300: cmp             SP, x16
    //     0x12eb304: b.ls            #0x12eb970
    // 0x12eb308: fcmp            d4, d2
    // 0x12eb30c: b.ne            #0x12eb320
    // 0x12eb310: r0 = Null
    //     0x12eb310: mov             x0, NULL
    // 0x12eb314: LeaveFrame
    //     0x12eb314: mov             SP, fp
    //     0x12eb318: ldp             fp, lr, [SP], #0x10
    // 0x12eb31c: ret
    //     0x12eb31c: ret             
    // 0x12eb320: mov             x1, x7
    // 0x12eb324: mov             x2, x0
    // 0x12eb328: mov             v0.16b, v4.16b
    // 0x12eb32c: mov             v1.16b, v3.16b
    // 0x12eb330: r0 = _upperRectangleWidth()
    //     0x12eb330: bl              #0x12eba9c  ; [package:flutter/src/material/slider_value_indicator_shape.dart] _RectangularSliderValueIndicatorPathPainter::_upperRectangleWidth
    // 0x12eb334: ldur            x1, [fp, #-8]
    // 0x12eb338: ldur            x2, [fp, #-0x20]
    // 0x12eb33c: ldur            x3, [fp, #-0x28]
    // 0x12eb340: ldur            x5, [fp, #-0x30]
    // 0x12eb344: mov             v2.16b, v0.16b
    // 0x12eb348: ldur            d0, [fp, #-0x50]
    // 0x12eb34c: ldr             x6, [fp, #0x10]
    // 0x12eb350: ldur            d1, [fp, #-0x58]
    // 0x12eb354: stur            d2, [fp, #-0x58]
    // 0x12eb358: r0 = getHorizontalShift()
    //     0x12eb358: bl              #0x12eb9a8  ; [package:flutter/src/material/slider_value_indicator_shape.dart] _RectangularSliderValueIndicatorPathPainter::getHorizontalShift
    // 0x12eb35c: ldur            x1, [fp, #-0x28]
    // 0x12eb360: stur            d0, [fp, #-0x60]
    // 0x12eb364: r0 = height()
    //     0x12eb364: bl              #0x859ce8  ; [package:flutter/src/painting/text_painter.dart] TextPainter::height
    // 0x12eb368: mov             v1.16b, v0.16b
    // 0x12eb36c: d0 = 16.000000
    //     0x12eb36c: fmov            d0, #16.00000000
    // 0x12eb370: fadd            d2, d1, d0
    // 0x12eb374: ldur            d0, [fp, #-0x58]
    // 0x12eb378: fneg            d1, d0
    // 0x12eb37c: d3 = 2.000000
    //     0x12eb37c: fmov            d3, #2.00000000
    // 0x12eb380: fdiv            d4, d1, d3
    // 0x12eb384: ldur            d1, [fp, #-0x60]
    // 0x12eb388: fadd            d5, d4, d1
    // 0x12eb38c: stur            d5, [fp, #-0x78]
    // 0x12eb390: d4 = -8.000000
    //     0x12eb390: fmov            d4, #-8.00000000
    // 0x12eb394: fsub            d6, d4, d2
    // 0x12eb398: stur            d6, [fp, #-0x70]
    // 0x12eb39c: fadd            d7, d5, d0
    // 0x12eb3a0: stur            d7, [fp, #-0x68]
    // 0x12eb3a4: fadd            d0, d6, d2
    // 0x12eb3a8: stur            d0, [fp, #-0x58]
    // 0x12eb3ac: r0 = Rect()
    //     0x12eb3ac: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0x12eb3b0: ldur            d0, [fp, #-0x78]
    // 0x12eb3b4: stur            x0, [fp, #-8]
    // 0x12eb3b8: StoreField: r0->field_7 = d0
    //     0x12eb3b8: stur            d0, [x0, #7]
    // 0x12eb3bc: ldur            d0, [fp, #-0x70]
    // 0x12eb3c0: StoreField: r0->field_f = d0
    //     0x12eb3c0: stur            d0, [x0, #0xf]
    // 0x12eb3c4: ldur            d1, [fp, #-0x68]
    // 0x12eb3c8: ArrayStore: r0[0] = d1  ; List_8
    //     0x12eb3c8: stur            d1, [x0, #0x17]
    // 0x12eb3cc: ldur            d1, [fp, #-0x58]
    // 0x12eb3d0: StoreField: r0->field_1f = d1
    //     0x12eb3d0: stur            d1, [x0, #0x1f]
    // 0x12eb3d4: r0 = _NativePath()
    //     0x12eb3d4: bl              #0xb69eb4  ; Allocate_NativePathStub -> _NativePath (size=0xc)
    // 0x12eb3d8: mov             x1, x0
    // 0x12eb3dc: stur            x0, [fp, #-0x30]
    // 0x12eb3e0: r0 = __constructor$Method$FfiNative()
    //     0x12eb3e0: bl              #0xb69d18  ; [dart:ui] _NativePath::__constructor$Method$FfiNative
    // 0x12eb3e4: ldur            x0, [fp, #-0x30]
    // 0x12eb3e8: LoadField: r1 = r0->field_7
    //     0x12eb3e8: ldur            w1, [x0, #7]
    // 0x12eb3ec: DecompressPointer r1
    //     0x12eb3ec: add             x1, x1, HEAP, lsl #32
    // 0x12eb3f0: cmp             w1, NULL
    // 0x12eb3f4: b.eq            #0x12eb978
    // 0x12eb3f8: LoadField: r2 = r1->field_7
    //     0x12eb3f8: ldur            x2, [x1, #7]
    // 0x12eb3fc: ldr             x1, [x2]
    // 0x12eb400: cbz             x1, #0x12eb8d0
    // 0x12eb404: mov             x2, x1
    // 0x12eb408: stur            x2, [fp, #-0x38]
    // 0x12eb40c: r1 = <Never>
    //     0x12eb40c: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12eb410: r0 = Pointer()
    //     0x12eb410: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12eb414: mov             x1, x0
    // 0x12eb418: ldur            x0, [fp, #-0x38]
    // 0x12eb41c: StoreField: r1->field_7 = r0
    //     0x12eb41c: stur            x0, [x1, #7]
    // 0x12eb420: d0 = -8.000000
    //     0x12eb420: fmov            d0, #-8.00000000
    // 0x12eb424: d1 = -8.000000
    //     0x12eb424: fmov            d1, #-8.00000000
    // 0x12eb428: r0 = _lineTo$Method$FfiNative()
    //     0x12eb428: bl              #0xb69bd0  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x12eb42c: ldur            x0, [fp, #-0x30]
    // 0x12eb430: LoadField: r1 = r0->field_7
    //     0x12eb430: ldur            w1, [x0, #7]
    // 0x12eb434: DecompressPointer r1
    //     0x12eb434: add             x1, x1, HEAP, lsl #32
    // 0x12eb438: cmp             w1, NULL
    // 0x12eb43c: b.eq            #0x12eb97c
    // 0x12eb440: LoadField: r2 = r1->field_7
    //     0x12eb440: ldur            x2, [x1, #7]
    // 0x12eb444: ldr             x1, [x2]
    // 0x12eb448: cbz             x1, #0x12eb8e0
    // 0x12eb44c: mov             x2, x1
    // 0x12eb450: stur            x2, [fp, #-0x38]
    // 0x12eb454: r1 = <Never>
    //     0x12eb454: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12eb458: r0 = Pointer()
    //     0x12eb458: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12eb45c: mov             x1, x0
    // 0x12eb460: ldur            x0, [fp, #-0x38]
    // 0x12eb464: StoreField: r1->field_7 = r0
    //     0x12eb464: stur            x0, [x1, #7]
    // 0x12eb468: d0 = 8.000000
    //     0x12eb468: fmov            d0, #8.00000000
    // 0x12eb46c: d1 = -8.000000
    //     0x12eb46c: fmov            d1, #-8.00000000
    // 0x12eb470: r0 = _lineTo$Method$FfiNative()
    //     0x12eb470: bl              #0xb69bd0  ; [dart:ui] _NativePath::_lineTo$Method$FfiNative
    // 0x12eb474: ldur            x0, [fp, #-0x30]
    // 0x12eb478: LoadField: r1 = r0->field_7
    //     0x12eb478: ldur            w1, [x0, #7]
    // 0x12eb47c: DecompressPointer r1
    //     0x12eb47c: add             x1, x1, HEAP, lsl #32
    // 0x12eb480: cmp             w1, NULL
    // 0x12eb484: b.eq            #0x12eb980
    // 0x12eb488: LoadField: r2 = r1->field_7
    //     0x12eb488: ldur            x2, [x1, #7]
    // 0x12eb48c: ldr             x1, [x2]
    // 0x12eb490: cbz             x1, #0x12eb8f0
    // 0x12eb494: mov             x2, x1
    // 0x12eb498: stur            x2, [fp, #-0x38]
    // 0x12eb49c: r1 = <Never>
    //     0x12eb49c: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12eb4a0: r0 = Pointer()
    //     0x12eb4a0: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12eb4a4: mov             x1, x0
    // 0x12eb4a8: ldur            x0, [fp, #-0x38]
    // 0x12eb4ac: StoreField: r1->field_7 = r0
    //     0x12eb4ac: stur            x0, [x1, #7]
    // 0x12eb4b0: r0 = _close$Method$FfiNative()
    //     0x12eb4b0: bl              #0xb78188  ; [dart:ui] _NativePath::_close$Method$FfiNative
    // 0x12eb4b4: r16 = 136
    //     0x12eb4b4: mov             x16, #0x88
    // 0x12eb4b8: stp             x16, NULL, [SP]
    // 0x12eb4bc: r0 = ByteData()
    //     0x12eb4bc: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0x12eb4c0: stur            x0, [fp, #-0x40]
    // 0x12eb4c4: r0 = Paint()
    //     0x12eb4c4: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x12eb4c8: ldur            x5, [fp, #-0x40]
    // 0x12eb4cc: stur            x0, [fp, #-0x48]
    // 0x12eb4d0: StoreField: r0->field_7 = r5
    //     0x12eb4d0: stur            w5, [x0, #7]
    // 0x12eb4d4: mov             x1, x0
    // 0x12eb4d8: ldur            x2, [fp, #-0x10]
    // 0x12eb4dc: r0 = color=()
    //     0x12eb4dc: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0x12eb4e0: r1 = <RRect>
    //     0x12eb4e0: add             x1, PP, #0x85, lsl #12  ; [pp+0x85108] TypeArguments: <RRect>
    //     0x12eb4e4: ldr             x1, [x1, #0x108]
    // 0x12eb4e8: r0 = RRect()
    //     0x12eb4e8: bl              #0xb6e214  ; AllocateRRectStub -> RRect (size=0x6c)
    // 0x12eb4ec: mov             x1, x0
    // 0x12eb4f0: ldur            x2, [fp, #-8]
    // 0x12eb4f4: r3 = Instance_Radius
    //     0x12eb4f4: add             x3, PP, #0x9d, lsl #12  ; [pp+0x9d080] Obj!Radius@12a7121
    //     0x12eb4f8: ldr             x3, [x3, #0x80]
    // 0x12eb4fc: stur            x0, [fp, #-8]
    // 0x12eb500: r0 = RRect.fromRectAndRadius()
    //     0x12eb500: bl              #0xb6e920  ; [dart:ui] RRect::RRect.fromRectAndRadius
    // 0x12eb504: ldur            x0, [fp, #-8]
    // 0x12eb508: LoadField: d0 = r0->field_b
    //     0x12eb508: ldur            d0, [x0, #0xb]
    // 0x12eb50c: fcvt            s1, d0
    // 0x12eb510: stur            d1, [fp, #-0x68]
    // 0x12eb514: r4 = 24
    //     0x12eb514: mov             x4, #0x18
    // 0x12eb518: r0 = AllocateFloat32Array()
    //     0x12eb518: bl              #0x13defe8  ; AllocateFloat32ArrayStub
    // 0x12eb51c: ldur            d0, [fp, #-0x68]
    // 0x12eb520: stur            x0, [fp, #-0x10]
    // 0x12eb524: ArrayStore: r0[0] = d0  ; List_8
    //     0x12eb524: stur            s0, [x0, #0x17]
    // 0x12eb528: ldur            x1, [fp, #-8]
    // 0x12eb52c: LoadField: d0 = r1->field_13
    //     0x12eb52c: ldur            d0, [x1, #0x13]
    // 0x12eb530: fcvt            s1, d0
    // 0x12eb534: StoreField: r0->field_1b = d1
    //     0x12eb534: stur            s1, [x0, #0x1b]
    // 0x12eb538: LoadField: d0 = r1->field_1b
    //     0x12eb538: ldur            d0, [x1, #0x1b]
    // 0x12eb53c: fcvt            s1, d0
    // 0x12eb540: StoreField: r0->field_1f = d1
    //     0x12eb540: stur            s1, [x0, #0x1f]
    // 0x12eb544: LoadField: d0 = r1->field_23
    //     0x12eb544: ldur            d0, [x1, #0x23]
    // 0x12eb548: fcvt            s1, d0
    // 0x12eb54c: StoreField: r0->field_23 = d1
    //     0x12eb54c: stur            s1, [x0, #0x23]
    // 0x12eb550: LoadField: d0 = r1->field_2b
    //     0x12eb550: ldur            d0, [x1, #0x2b]
    // 0x12eb554: fcvt            s1, d0
    // 0x12eb558: StoreField: r0->field_27 = d1
    //     0x12eb558: stur            s1, [x0, #0x27]
    // 0x12eb55c: LoadField: d0 = r1->field_33
    //     0x12eb55c: ldur            d0, [x1, #0x33]
    // 0x12eb560: fcvt            s1, d0
    // 0x12eb564: StoreField: r0->field_2b = d1
    //     0x12eb564: stur            s1, [x0, #0x2b]
    // 0x12eb568: LoadField: d0 = r1->field_3b
    //     0x12eb568: ldur            d0, [x1, #0x3b]
    // 0x12eb56c: fcvt            s1, d0
    // 0x12eb570: StoreField: r0->field_2f = d1
    //     0x12eb570: stur            s1, [x0, #0x2f]
    // 0x12eb574: LoadField: d0 = r1->field_43
    //     0x12eb574: ldur            d0, [x1, #0x43]
    // 0x12eb578: fcvt            s1, d0
    // 0x12eb57c: StoreField: r0->field_33 = d1
    //     0x12eb57c: stur            s1, [x0, #0x33]
    // 0x12eb580: LoadField: d0 = r1->field_4b
    //     0x12eb580: ldur            d0, [x1, #0x4b]
    // 0x12eb584: fcvt            s1, d0
    // 0x12eb588: StoreField: r0->field_37 = d1
    //     0x12eb588: stur            s1, [x0, #0x37]
    // 0x12eb58c: LoadField: d0 = r1->field_53
    //     0x12eb58c: ldur            d0, [x1, #0x53]
    // 0x12eb590: fcvt            s1, d0
    // 0x12eb594: StoreField: r0->field_3b = d1
    //     0x12eb594: stur            s1, [x0, #0x3b]
    // 0x12eb598: LoadField: d0 = r1->field_5b
    //     0x12eb598: ldur            d0, [x1, #0x5b]
    // 0x12eb59c: fcvt            s1, d0
    // 0x12eb5a0: StoreField: r0->field_3f = d1
    //     0x12eb5a0: stur            s1, [x0, #0x3f]
    // 0x12eb5a4: LoadField: d0 = r1->field_63
    //     0x12eb5a4: ldur            d0, [x1, #0x63]
    // 0x12eb5a8: fcvt            s1, d0
    // 0x12eb5ac: StoreField: r0->field_43 = d1
    //     0x12eb5ac: stur            s1, [x0, #0x43]
    // 0x12eb5b0: ldur            x2, [fp, #-0x30]
    // 0x12eb5b4: LoadField: r1 = r2->field_7
    //     0x12eb5b4: ldur            w1, [x2, #7]
    // 0x12eb5b8: DecompressPointer r1
    //     0x12eb5b8: add             x1, x1, HEAP, lsl #32
    // 0x12eb5bc: cmp             w1, NULL
    // 0x12eb5c0: b.eq            #0x12eb984
    // 0x12eb5c4: LoadField: r3 = r1->field_7
    //     0x12eb5c4: ldur            x3, [x1, #7]
    // 0x12eb5c8: ldr             x1, [x3]
    // 0x12eb5cc: cbz             x1, #0x12eb900
    // 0x12eb5d0: ldur            x3, [fp, #-0x18]
    // 0x12eb5d4: mov             x4, x1
    // 0x12eb5d8: stur            x4, [fp, #-0x38]
    // 0x12eb5dc: r1 = <Never>
    //     0x12eb5dc: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12eb5e0: r0 = Pointer()
    //     0x12eb5e0: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12eb5e4: mov             x1, x0
    // 0x12eb5e8: ldur            x0, [fp, #-0x38]
    // 0x12eb5ec: StoreField: r1->field_7 = r0
    //     0x12eb5ec: stur            x0, [x1, #7]
    // 0x12eb5f0: ldur            x2, [fp, #-0x10]
    // 0x12eb5f4: r0 = __addRRect$Method$FfiNative()
    //     0x12eb5f4: bl              #0xbfd930  ; [dart:ui] _NativePath::__addRRect$Method$FfiNative
    // 0x12eb5f8: ldur            x2, [fp, #-0x18]
    // 0x12eb5fc: LoadField: r0 = r2->field_7
    //     0x12eb5fc: ldur            w0, [x2, #7]
    // 0x12eb600: DecompressPointer r0
    //     0x12eb600: add             x0, x0, HEAP, lsl #32
    // 0x12eb604: cmp             w0, NULL
    // 0x12eb608: b.eq            #0x12eb988
    // 0x12eb60c: LoadField: r1 = r0->field_7
    //     0x12eb60c: ldur            x1, [x0, #7]
    // 0x12eb610: ldr             x0, [x1]
    // 0x12eb614: cbz             x0, #0x12eb910
    // 0x12eb618: ldur            x3, [fp, #-0x20]
    // 0x12eb61c: stur            x0, [fp, #-0x38]
    // 0x12eb620: r1 = <Never>
    //     0x12eb620: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12eb624: r0 = Pointer()
    //     0x12eb624: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12eb628: mov             x1, x0
    // 0x12eb62c: ldur            x0, [fp, #-0x38]
    // 0x12eb630: StoreField: r1->field_7 = r0
    //     0x12eb630: stur            x0, [x1, #7]
    // 0x12eb634: r0 = _save$Method$FfiNative()
    //     0x12eb634: bl              #0xb74adc  ; [dart:ui] _NativeCanvas::_save$Method$FfiNative
    // 0x12eb638: ldur            x0, [fp, #-0x20]
    // 0x12eb63c: LoadField: d0 = r0->field_7
    //     0x12eb63c: ldur            d0, [x0, #7]
    // 0x12eb640: stur            d0, [fp, #-0x78]
    // 0x12eb644: LoadField: d1 = r0->field_f
    //     0x12eb644: ldur            d1, [x0, #0xf]
    // 0x12eb648: d2 = 14.000000
    //     0x12eb648: fmov            d2, #14.00000000
    // 0x12eb64c: fsub            d3, d1, d2
    // 0x12eb650: ldur            x2, [fp, #-0x18]
    // 0x12eb654: stur            d3, [fp, #-0x68]
    // 0x12eb658: LoadField: r0 = r2->field_7
    //     0x12eb658: ldur            w0, [x2, #7]
    // 0x12eb65c: DecompressPointer r0
    //     0x12eb65c: add             x0, x0, HEAP, lsl #32
    // 0x12eb660: cmp             w0, NULL
    // 0x12eb664: b.eq            #0x12eb98c
    // 0x12eb668: LoadField: r1 = r0->field_7
    //     0x12eb668: ldur            x1, [x0, #7]
    // 0x12eb66c: ldr             x0, [x1]
    // 0x12eb670: cbz             x0, #0x12eb920
    // 0x12eb674: stur            x0, [fp, #-0x38]
    // 0x12eb678: r1 = <Never>
    //     0x12eb678: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12eb67c: r0 = Pointer()
    //     0x12eb67c: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12eb680: mov             x1, x0
    // 0x12eb684: ldur            x0, [fp, #-0x38]
    // 0x12eb688: StoreField: r1->field_7 = r0
    //     0x12eb688: stur            x0, [x1, #7]
    // 0x12eb68c: ldur            d0, [fp, #-0x78]
    // 0x12eb690: ldur            d1, [fp, #-0x68]
    // 0x12eb694: r0 = _translate$Method$FfiNative()
    //     0x12eb694: bl              #0xb74a38  ; [dart:ui] _NativeCanvas::_translate$Method$FfiNative
    // 0x12eb698: ldur            x2, [fp, #-0x18]
    // 0x12eb69c: LoadField: r0 = r2->field_7
    //     0x12eb69c: ldur            w0, [x2, #7]
    // 0x12eb6a0: DecompressPointer r0
    //     0x12eb6a0: add             x0, x0, HEAP, lsl #32
    // 0x12eb6a4: cmp             w0, NULL
    // 0x12eb6a8: b.eq            #0x12eb990
    // 0x12eb6ac: LoadField: r1 = r0->field_7
    //     0x12eb6ac: ldur            x1, [x0, #7]
    // 0x12eb6b0: ldr             x0, [x1]
    // 0x12eb6b4: cbz             x0, #0x12eb930
    // 0x12eb6b8: ldur            x3, [fp, #-0x48]
    // 0x12eb6bc: stur            x0, [fp, #-0x38]
    // 0x12eb6c0: r1 = <Never>
    //     0x12eb6c0: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12eb6c4: r0 = Pointer()
    //     0x12eb6c4: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12eb6c8: mov             x1, x0
    // 0x12eb6cc: ldur            x0, [fp, #-0x38]
    // 0x12eb6d0: StoreField: r1->field_7 = r0
    //     0x12eb6d0: stur            x0, [x1, #7]
    // 0x12eb6d4: ldur            d0, [fp, #-0x50]
    // 0x12eb6d8: ldur            d1, [fp, #-0x50]
    // 0x12eb6dc: r0 = __scale$Method$FfiNative()
    //     0x12eb6dc: bl              #0xb76308  ; [dart:ui] _NativeCanvas::__scale$Method$FfiNative
    // 0x12eb6e0: ldur            x0, [fp, #-0x48]
    // 0x12eb6e4: LoadField: r3 = r0->field_b
    //     0x12eb6e4: ldur            w3, [x0, #0xb]
    // 0x12eb6e8: DecompressPointer r3
    //     0x12eb6e8: add             x3, x3, HEAP, lsl #32
    // 0x12eb6ec: ldur            x2, [fp, #-0x18]
    // 0x12eb6f0: stur            x3, [fp, #-8]
    // 0x12eb6f4: LoadField: r0 = r2->field_7
    //     0x12eb6f4: ldur            w0, [x2, #7]
    // 0x12eb6f8: DecompressPointer r0
    //     0x12eb6f8: add             x0, x0, HEAP, lsl #32
    // 0x12eb6fc: cmp             w0, NULL
    // 0x12eb700: b.eq            #0x12eb994
    // 0x12eb704: LoadField: r1 = r0->field_7
    //     0x12eb704: ldur            x1, [x0, #7]
    // 0x12eb708: ldr             x0, [x1]
    // 0x12eb70c: cbz             x0, #0x12eb940
    // 0x12eb710: ldur            d0, [fp, #-0x70]
    // 0x12eb714: ldur            x4, [fp, #-0x30]
    // 0x12eb718: ldur            d1, [fp, #-0x58]
    // 0x12eb71c: stur            x0, [fp, #-0x38]
    // 0x12eb720: r1 = <Never>
    //     0x12eb720: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12eb724: r0 = Pointer()
    //     0x12eb724: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12eb728: mov             x2, x0
    // 0x12eb72c: ldur            x0, [fp, #-0x38]
    // 0x12eb730: stur            x2, [fp, #-0x10]
    // 0x12eb734: StoreField: r2->field_7 = r0
    //     0x12eb734: stur            x0, [x2, #7]
    // 0x12eb738: ldur            x0, [fp, #-0x30]
    // 0x12eb73c: LoadField: r1 = r0->field_7
    //     0x12eb73c: ldur            w1, [x0, #7]
    // 0x12eb740: DecompressPointer r1
    //     0x12eb740: add             x1, x1, HEAP, lsl #32
    // 0x12eb744: cmp             w1, NULL
    // 0x12eb748: b.eq            #0x12eb998
    // 0x12eb74c: LoadField: r3 = r1->field_7
    //     0x12eb74c: ldur            x3, [x1, #7]
    // 0x12eb750: ldr             x1, [x3]
    // 0x12eb754: mov             x3, x1
    // 0x12eb758: stur            x3, [fp, #-0x38]
    // 0x12eb75c: r1 = <Never>
    //     0x12eb75c: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12eb760: r0 = Pointer()
    //     0x12eb760: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12eb764: mov             x1, x0
    // 0x12eb768: ldur            x0, [fp, #-0x38]
    // 0x12eb76c: StoreField: r1->field_7 = r0
    //     0x12eb76c: stur            x0, [x1, #7]
    // 0x12eb770: mov             x2, x1
    // 0x12eb774: ldur            x1, [fp, #-0x10]
    // 0x12eb778: ldur            x3, [fp, #-8]
    // 0x12eb77c: ldur            x5, [fp, #-0x40]
    // 0x12eb780: r0 = __drawPath$Method$FfiNative()
    //     0x12eb780: bl              #0xb69a00  ; [dart:ui] _NativeCanvas::__drawPath$Method$FfiNative
    // 0x12eb784: ldur            d0, [fp, #-0x70]
    // 0x12eb788: ldur            d1, [fp, #-0x58]
    // 0x12eb78c: fsub            d2, d1, d0
    // 0x12eb790: stur            d2, [fp, #-0x68]
    // 0x12eb794: d0 = -8.000000
    //     0x12eb794: fmov            d0, #-8.00000000
    // 0x12eb798: fsub            d1, d0, d2
    // 0x12eb79c: ldur            x2, [fp, #-0x18]
    // 0x12eb7a0: stur            d1, [fp, #-0x50]
    // 0x12eb7a4: LoadField: r0 = r2->field_7
    //     0x12eb7a4: ldur            w0, [x2, #7]
    // 0x12eb7a8: DecompressPointer r0
    //     0x12eb7a8: add             x0, x0, HEAP, lsl #32
    // 0x12eb7ac: cmp             w0, NULL
    // 0x12eb7b0: b.eq            #0x12eb99c
    // 0x12eb7b4: LoadField: r1 = r0->field_7
    //     0x12eb7b4: ldur            x1, [x0, #7]
    // 0x12eb7b8: ldr             x0, [x1]
    // 0x12eb7bc: cbz             x0, #0x12eb950
    // 0x12eb7c0: ldur            x3, [fp, #-0x28]
    // 0x12eb7c4: ldur            d0, [fp, #-0x60]
    // 0x12eb7c8: stur            x0, [fp, #-0x38]
    // 0x12eb7cc: r1 = <Never>
    //     0x12eb7cc: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12eb7d0: r0 = Pointer()
    //     0x12eb7d0: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12eb7d4: mov             x1, x0
    // 0x12eb7d8: ldur            x0, [fp, #-0x38]
    // 0x12eb7dc: StoreField: r1->field_7 = r0
    //     0x12eb7dc: stur            x0, [x1, #7]
    // 0x12eb7e0: ldur            d1, [fp, #-0x50]
    // 0x12eb7e4: d0 = 0.000000
    //     0x12eb7e4: eor             v0.16b, v0.16b, v0.16b
    // 0x12eb7e8: r0 = _translate$Method$FfiNative()
    //     0x12eb7e8: bl              #0xb74a38  ; [dart:ui] _NativeCanvas::_translate$Method$FfiNative
    // 0x12eb7ec: ldur            d0, [fp, #-0x68]
    // 0x12eb7f0: d1 = 2.000000
    //     0x12eb7f0: fmov            d1, #2.00000000
    // 0x12eb7f4: fdiv            d2, d0, d1
    // 0x12eb7f8: stur            d2, [fp, #-0x50]
    // 0x12eb7fc: r0 = Offset()
    //     0x12eb7fc: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x12eb800: ldur            d0, [fp, #-0x60]
    // 0x12eb804: stur            x0, [fp, #-8]
    // 0x12eb808: StoreField: r0->field_7 = d0
    //     0x12eb808: stur            d0, [x0, #7]
    // 0x12eb80c: ldur            d0, [fp, #-0x50]
    // 0x12eb810: StoreField: r0->field_f = d0
    //     0x12eb810: stur            d0, [x0, #0xf]
    // 0x12eb814: ldur            x2, [fp, #-0x28]
    // 0x12eb818: LoadField: r1 = r2->field_7
    //     0x12eb818: ldur            w1, [x2, #7]
    // 0x12eb81c: DecompressPointer r1
    //     0x12eb81c: add             x1, x1, HEAP, lsl #32
    // 0x12eb820: cmp             w1, NULL
    // 0x12eb824: b.eq            #0x12eb9a0
    // 0x12eb828: LoadField: d0 = r1->field_13
    //     0x12eb828: ldur            d0, [x1, #0x13]
    // 0x12eb82c: d1 = 2.000000
    //     0x12eb82c: fmov            d1, #2.00000000
    // 0x12eb830: fdiv            d2, d0, d1
    // 0x12eb834: mov             x1, x2
    // 0x12eb838: stur            d2, [fp, #-0x50]
    // 0x12eb83c: r0 = height()
    //     0x12eb83c: bl              #0x859ce8  ; [package:flutter/src/painting/text_painter.dart] TextPainter::height
    // 0x12eb840: mov             v1.16b, v0.16b
    // 0x12eb844: d0 = 2.000000
    //     0x12eb844: fmov            d0, #2.00000000
    // 0x12eb848: fdiv            d2, d1, d0
    // 0x12eb84c: stur            d2, [fp, #-0x58]
    // 0x12eb850: r0 = Offset()
    //     0x12eb850: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x12eb854: ldur            d0, [fp, #-0x50]
    // 0x12eb858: StoreField: r0->field_7 = d0
    //     0x12eb858: stur            d0, [x0, #7]
    // 0x12eb85c: ldur            d0, [fp, #-0x58]
    // 0x12eb860: StoreField: r0->field_f = d0
    //     0x12eb860: stur            d0, [x0, #0xf]
    // 0x12eb864: ldur            x1, [fp, #-8]
    // 0x12eb868: mov             x2, x0
    // 0x12eb86c: r0 = -()
    //     0x12eb86c: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0x12eb870: ldur            x1, [fp, #-0x28]
    // 0x12eb874: ldur            x2, [fp, #-0x18]
    // 0x12eb878: mov             x3, x0
    // 0x12eb87c: r0 = paint()
    //     0x12eb87c: bl              #0xc22fac  ; [package:flutter/src/painting/text_painter.dart] TextPainter::paint
    // 0x12eb880: ldur            x0, [fp, #-0x18]
    // 0x12eb884: LoadField: r1 = r0->field_7
    //     0x12eb884: ldur            w1, [x0, #7]
    // 0x12eb888: DecompressPointer r1
    //     0x12eb888: add             x1, x1, HEAP, lsl #32
    // 0x12eb88c: cmp             w1, NULL
    // 0x12eb890: b.eq            #0x12eb9a4
    // 0x12eb894: LoadField: r2 = r1->field_7
    //     0x12eb894: ldur            x2, [x1, #7]
    // 0x12eb898: ldr             x1, [x2]
    // 0x12eb89c: cbz             x1, #0x12eb960
    // 0x12eb8a0: mov             x2, x1
    // 0x12eb8a4: stur            x2, [fp, #-0x38]
    // 0x12eb8a8: r1 = <Never>
    //     0x12eb8a8: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x12eb8ac: r0 = Pointer()
    //     0x12eb8ac: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x12eb8b0: mov             x1, x0
    // 0x12eb8b4: ldur            x0, [fp, #-0x38]
    // 0x12eb8b8: StoreField: r1->field_7 = r0
    //     0x12eb8b8: stur            x0, [x1, #7]
    // 0x12eb8bc: r0 = _restore$Method$FfiNative()
    //     0x12eb8bc: bl              #0xb74908  ; [dart:ui] _NativeCanvas::_restore$Method$FfiNative
    // 0x12eb8c0: r0 = Null
    //     0x12eb8c0: mov             x0, NULL
    // 0x12eb8c4: LeaveFrame
    //     0x12eb8c4: mov             SP, fp
    //     0x12eb8c8: ldp             fp, lr, [SP], #0x10
    // 0x12eb8cc: ret
    //     0x12eb8cc: ret             
    // 0x12eb8d0: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12eb8d0: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12eb8d4: str             x16, [SP]
    // 0x12eb8d8: r0 = _throwNew()
    //     0x12eb8d8: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12eb8dc: brk             #0
    // 0x12eb8e0: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12eb8e0: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12eb8e4: str             x16, [SP]
    // 0x12eb8e8: r0 = _throwNew()
    //     0x12eb8e8: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12eb8ec: brk             #0
    // 0x12eb8f0: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12eb8f0: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12eb8f4: str             x16, [SP]
    // 0x12eb8f8: r0 = _throwNew()
    //     0x12eb8f8: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12eb8fc: brk             #0
    // 0x12eb900: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12eb900: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12eb904: str             x16, [SP]
    // 0x12eb908: r0 = _throwNew()
    //     0x12eb908: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12eb90c: brk             #0
    // 0x12eb910: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12eb910: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12eb914: str             x16, [SP]
    // 0x12eb918: r0 = _throwNew()
    //     0x12eb918: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12eb91c: brk             #0
    // 0x12eb920: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12eb920: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12eb924: str             x16, [SP]
    // 0x12eb928: r0 = _throwNew()
    //     0x12eb928: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12eb92c: brk             #0
    // 0x12eb930: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12eb930: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12eb934: str             x16, [SP]
    // 0x12eb938: r0 = _throwNew()
    //     0x12eb938: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12eb93c: brk             #0
    // 0x12eb940: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12eb940: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12eb944: str             x16, [SP]
    // 0x12eb948: r0 = _throwNew()
    //     0x12eb948: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12eb94c: brk             #0
    // 0x12eb950: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12eb950: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12eb954: str             x16, [SP]
    // 0x12eb958: r0 = _throwNew()
    //     0x12eb958: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12eb95c: brk             #0
    // 0x12eb960: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x12eb960: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x12eb964: str             x16, [SP]
    // 0x12eb968: r0 = _throwNew()
    //     0x12eb968: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x12eb96c: brk             #0
    // 0x12eb970: r0 = StackOverflowSharedWithFPURegs()
    //     0x12eb970: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12eb974: b               #0x12eb308
    // 0x12eb978: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12eb978: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12eb97c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12eb97c: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12eb980: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12eb980: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12eb984: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12eb984: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12eb988: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12eb988: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12eb98c: r0 = NullErrorSharedWithFPURegs()
    //     0x12eb98c: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0x12eb990: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12eb990: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12eb994: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12eb994: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12eb998: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12eb998: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x12eb99c: r0 = NullErrorSharedWithFPURegs()
    //     0x12eb99c: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0x12eb9a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12eb9a0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x12eb9a4: r0 = NullErrorSharedWithoutFPURegs()
    //     0x12eb9a4: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ getHorizontalShift(/* No info */) {
    // ** addr: 0x12eb9a8, size: 0xf4
    // 0x12eb9a8: EnterFrame
    //     0x12eb9a8: stp             fp, lr, [SP, #-0x10]!
    //     0x12eb9ac: mov             fp, SP
    // 0x12eb9b0: AllocStack(0x28)
    //     0x12eb9b0: sub             SP, SP, #0x28
    // 0x12eb9b4: SetupParameters(dynamic _ /* r2 => r3, fp-0x10 */, dynamic _ /* r3 => d2, fp-0x20 */, [dynamic _ /* fp-0x18 */])
    //     0x12eb9b4: stur            x2, [fp, #-8]
    //     0x12eb9b8: mov             x16, x3
    //     0x12eb9bc: mov             x3, x2
    //     0x12eb9c0: mov             x2, x16
    //     0x12eb9c4: mov             x0, x5
    //     0x12eb9c8: mov             v2.16b, v1.16b
    //     0x12eb9cc: stur            x5, [fp, #-0x10]
    //     0x12eb9d0: stur            x6, [fp, #-0x18]
    //     0x12eb9d4: stur            d1, [fp, #-0x20]
    // 0x12eb9d8: CheckStackOverflow
    //     0x12eb9d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12eb9dc: cmp             SP, x16
    //     0x12eb9e0: b.ls            #0x12eba94
    // 0x12eb9e4: mov             v1.16b, v2.16b
    // 0x12eb9e8: r0 = _upperRectangleWidth()
    //     0x12eb9e8: bl              #0x12eba9c  ; [package:flutter/src/material/slider_value_indicator_shape.dart] _RectangularSliderValueIndicatorPathPainter::_upperRectangleWidth
    // 0x12eb9ec: ldur            x1, [fp, #-0x10]
    // 0x12eb9f0: ldur            x2, [fp, #-8]
    // 0x12eb9f4: stur            d0, [fp, #-0x28]
    // 0x12eb9f8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x12eb9f8: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x12eb9fc: r0 = localToGlobal()
    //     0x12eb9fc: bl              #0x856eb0  ; [package:flutter/src/rendering/box.dart] RenderBox::localToGlobal
    // 0x12eba00: ldur            d1, [fp, #-0x28]
    // 0x12eba04: d2 = 2.000000
    //     0x12eba04: fmov            d2, #2.00000000
    // 0x12eba08: fdiv            d3, d1, d2
    // 0x12eba0c: LoadField: d2 = r0->field_7
    //     0x12eba0c: ldur            d2, [x0, #7]
    // 0x12eba10: fsub            d4, d3, d2
    // 0x12eba14: d5 = 8.000000
    //     0x12eba14: fmov            d5, #8.00000000
    // 0x12eba18: fadd            d6, d4, d5
    // 0x12eba1c: d4 = 0.000000
    //     0x12eba1c: eor             v4.16b, v4.16b, v4.16b
    // 0x12eba20: fmax            v7.2d, v4.2d, v6.2d
    // 0x12eba24: ldur            x0, [fp, #-0x18]
    // 0x12eba28: LoadField: d6 = r0->field_7
    //     0x12eba28: ldur            d6, [x0, #7]
    // 0x12eba2c: fsub            d8, d6, d2
    // 0x12eba30: fsub            d2, d8, d5
    // 0x12eba34: fsub            d8, d3, d2
    // 0x12eba38: fmax            v2.2d, v4.2d, v8.2d
    // 0x12eba3c: fcmp            d6, d1
    // 0x12eba40: b.le            #0x12eba54
    // 0x12eba44: fsub            d0, d7, d2
    // 0x12eba48: LeaveFrame
    //     0x12eba48: mov             SP, fp
    //     0x12eba4c: ldp             fp, lr, [SP], #0x10
    // 0x12eba50: ret
    //     0x12eba50: ret             
    // 0x12eba54: fsub            d1, d7, d2
    // 0x12eba58: fcmp            d1, d4
    // 0x12eba5c: b.le            #0x12eba78
    // 0x12eba60: ldur            d1, [fp, #-0x20]
    // 0x12eba64: fmul            d3, d1, d5
    // 0x12eba68: fsub            d0, d7, d3
    // 0x12eba6c: LeaveFrame
    //     0x12eba6c: mov             SP, fp
    //     0x12eba70: ldp             fp, lr, [SP], #0x10
    // 0x12eba74: ret
    //     0x12eba74: ret             
    // 0x12eba78: ldur            d1, [fp, #-0x20]
    // 0x12eba7c: fneg            d3, d2
    // 0x12eba80: fmul            d2, d1, d5
    // 0x12eba84: fadd            d0, d3, d2
    // 0x12eba88: LeaveFrame
    //     0x12eba88: mov             SP, fp
    //     0x12eba8c: ldp             fp, lr, [SP], #0x10
    // 0x12eba90: ret
    //     0x12eba90: ret             
    // 0x12eba94: r0 = StackOverflowSharedWithFPURegs()
    //     0x12eba94: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12eba98: b               #0x12eb9e4
  }
  _ _upperRectangleWidth(/* No info */) {
    // ** addr: 0x12eba9c, size: 0x44
    // 0x12eba9c: d3 = 32.000000
    //     0x12eba9c: add             x17, PP, #0x13, lsl #12  ; [pp+0x13a60] IMM: double(32) from 0x4040000000000000
    //     0x12ebaa0: ldr             d3, [x17, #0xa60]
    // 0x12ebaa4: d2 = 16.000000
    //     0x12ebaa4: fmov            d2, #16.00000000
    // 0x12ebaa8: fmul            d4, d1, d2
    // 0x12ebaac: LoadField: r0 = r2->field_7
    //     0x12ebaac: ldur            w0, [x2, #7]
    // 0x12ebab0: DecompressPointer r0
    //     0x12ebab0: add             x0, x0, HEAP, lsl #32
    // 0x12ebab4: cmp             w0, NULL
    // 0x12ebab8: b.eq            #0x12ebad4
    // 0x12ebabc: LoadField: d1 = r0->field_13
    //     0x12ebabc: ldur            d1, [x0, #0x13]
    // 0x12ebac0: fmax            v2.2d, v4.2d, v1.2d
    // 0x12ebac4: fadd            d1, d2, d3
    // 0x12ebac8: fmul            d2, d1, d0
    // 0x12ebacc: mov             v0.16b, v2.16b
    // 0x12ebad0: ret
    //     0x12ebad0: ret             
    // 0x12ebad4: EnterFrame
    //     0x12ebad4: stp             fp, lr, [SP, #-0x10]!
    //     0x12ebad8: mov             fp, SP
    // 0x12ebadc: r0 = NullCastErrorSharedWithFPURegs()
    //     0x12ebadc: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
}

// class id: 2976, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class SliderComponentShape extends Object {
}

// class id: 2977, size: 0x8, field offset: 0x8
//   const constructor, 
class RectangularSliderValueIndicatorShape extends SliderComponentShape {

  _ paint(/* No info */) {
    // ** addr: 0x12eb1c8, size: 0xe4
    // 0x12eb1c8: EnterFrame
    //     0x12eb1c8: stp             fp, lr, [SP, #-0x10]!
    //     0x12eb1cc: mov             fp, SP
    // 0x12eb1d0: AllocStack(0x30)
    //     0x12eb1d0: sub             SP, SP, #0x30
    // 0x12eb1d4: SetupParameters(RectangularSliderValueIndicatorShape this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r5, fp-0x8 */, [dynamic _ /* r0 */, dynamic _ /* r6, fp-0x18 */, dynamic _ /* d1, fp-0x28 */])
    //     0x12eb1d4: mov             x16, x2
    //     0x12eb1d8: mov             x2, x1
    //     0x12eb1dc: mov             x1, x16
    //     0x12eb1e0: mov             x16, x5
    //     0x12eb1e4: mov             x5, x2
    //     0x12eb1e8: mov             x2, x16
    //     0x12eb1ec: mov             x16, x3
    //     0x12eb1f0: mov             x3, x5
    //     0x12eb1f4: mov             x5, x16
    //     0x12eb1f8: mov             x0, x6
    //     0x12eb1fc: mov             x6, x7
    //     0x12eb200: mov             v1.16b, v0.16b
    //     0x12eb204: stur            x5, [fp, #-8]
    //     0x12eb208: stur            x2, [fp, #-0x10]
    //     0x12eb20c: stur            x7, [fp, #-0x18]
    //     0x12eb210: stur            d0, [fp, #-0x28]
    // 0x12eb214: CheckStackOverflow
    //     0x12eb214: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12eb218: cmp             SP, x16
    //     0x12eb21c: b.ls            #0x12eb2a0
    // 0x12eb220: r0 = canvas()
    //     0x12eb220: bl              #0xc17694  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0x12eb224: mov             x2, x0
    // 0x12eb228: ldur            x1, [fp, #-0x10]
    // 0x12eb22c: stur            x2, [fp, #-0x20]
    // 0x12eb230: r0 = LoadClassIdInstr(r1)
    //     0x12eb230: ldur            x0, [x1, #-1]
    //     0x12eb234: ubfx            x0, x0, #0xc, #0x14
    // 0x12eb238: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0x12eb238: mov             x17, #0x4e2e
    //     0x12eb23c: movk            x17, #1, lsl #16
    //     0x12eb240: add             lr, x0, x17
    //     0x12eb244: ldr             lr, [x21, lr, lsl #3]
    //     0x12eb248: blr             lr
    // 0x12eb24c: mov             x1, x0
    // 0x12eb250: ldr             x0, [fp, #0x10]
    // 0x12eb254: LoadField: r2 = r0->field_43
    //     0x12eb254: ldur            w2, [x0, #0x43]
    // 0x12eb258: DecompressPointer r2
    //     0x12eb258: add             x2, x2, HEAP, lsl #32
    // 0x12eb25c: cmp             w2, NULL
    // 0x12eb260: b.eq            #0x12eb2a8
    // 0x12eb264: LoadField: d0 = r1->field_7
    //     0x12eb264: ldur            d0, [x1, #7]
    // 0x12eb268: ldr             x16, [fp, #0x18]
    // 0x12eb26c: str             x16, [SP]
    // 0x12eb270: ldur            x3, [fp, #-0x20]
    // 0x12eb274: ldur            x5, [fp, #-8]
    // 0x12eb278: ldur            x6, [fp, #-0x18]
    // 0x12eb27c: ldr             x7, [fp, #0x20]
    // 0x12eb280: ldur            d1, [fp, #-0x28]
    // 0x12eb284: r1 = Instance__RectangularSliderValueIndicatorPathPainter
    //     0x12eb284: add             x1, PP, #0xcc, lsl #12  ; [pp+0xccfd0] Obj!_RectangularSliderValueIndicatorPathPainter@129e871
    //     0x12eb288: ldr             x1, [x1, #0xfd0]
    // 0x12eb28c: r0 = paint()
    //     0x12eb28c: bl              #0x12eb2ac  ; [package:flutter/src/material/slider_value_indicator_shape.dart] _RectangularSliderValueIndicatorPathPainter::paint
    // 0x12eb290: r0 = Null
    //     0x12eb290: mov             x0, NULL
    // 0x12eb294: LeaveFrame
    //     0x12eb294: mov             SP, fp
    //     0x12eb298: ldp             fp, lr, [SP], #0x10
    // 0x12eb29c: ret
    //     0x12eb29c: ret             
    // 0x12eb2a0: r0 = StackOverflowSharedWithFPURegs()
    //     0x12eb2a0: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12eb2a4: b               #0x12eb220
    // 0x12eb2a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12eb2a8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2978, size: 0x10, field offset: 0x8
//   const constructor, 
class RoundSliderOverlayShape extends SliderComponentShape {

  _Double field_8;

  _ getPreferredSize(/* No info */) {
    // ** addr: 0xb1e4f8, size: 0x24
    // 0xb1e4f8: EnterFrame
    //     0xb1e4f8: stp             fp, lr, [SP, #-0x10]!
    //     0xb1e4fc: mov             fp, SP
    // 0xb1e500: r0 = Size()
    //     0xb1e500: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb1e504: d0 = 48.000000
    //     0xb1e504: ldr             d0, [PP, #0x5650]  ; [pp+0x5650] IMM: double(48) from 0x4048000000000000
    // 0xb1e508: StoreField: r0->field_7 = d0
    //     0xb1e508: stur            d0, [x0, #7]
    // 0xb1e50c: StoreField: r0->field_f = d0
    //     0xb1e50c: stur            d0, [x0, #0xf]
    // 0xb1e510: LeaveFrame
    //     0xb1e510: mov             SP, fp
    //     0xb1e514: ldp             fp, lr, [SP], #0x10
    // 0xb1e518: ret
    //     0xb1e518: ret             
  }
  _ paint(/* No info */) {
    // ** addr: 0x12eb0f0, size: 0xd8
    // 0x12eb0f0: EnterFrame
    //     0x12eb0f0: stp             fp, lr, [SP, #-0x10]!
    //     0x12eb0f4: mov             fp, SP
    // 0x12eb0f8: AllocStack(0x38)
    //     0x12eb0f8: sub             SP, SP, #0x38
    // 0x12eb0fc: SetupParameters(RoundSliderOverlayShape this /* r1 => r3 */, dynamic _ /* r2 => r1 */, dynamic _ /* r3 => r0, fp-0x8 */, dynamic _ /* r5 => r2, fp-0x10 */)
    //     0x12eb0fc: mov             x0, x3
    //     0x12eb100: stur            x3, [fp, #-8]
    //     0x12eb104: mov             x3, x1
    //     0x12eb108: mov             x1, x2
    //     0x12eb10c: mov             x2, x5
    //     0x12eb110: stur            x5, [fp, #-0x10]
    // 0x12eb114: CheckStackOverflow
    //     0x12eb114: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12eb118: cmp             SP, x16
    //     0x12eb11c: b.ls            #0x12eb1bc
    // 0x12eb120: r0 = canvas()
    //     0x12eb120: bl              #0xc17694  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0x12eb124: r1 = <double>
    //     0x12eb124: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0x12eb128: stur            x0, [fp, #-0x18]
    // 0x12eb12c: r0 = Tween()
    //     0x12eb12c: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x12eb130: mov             x1, x0
    // 0x12eb134: r0 = 0.000000
    //     0x12eb134: ldr             x0, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0x12eb138: StoreField: r1->field_b = r0
    //     0x12eb138: stur            w0, [x1, #0xb]
    // 0x12eb13c: r0 = 24.000000
    //     0x12eb13c: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e4d0] 24
    //     0x12eb140: ldr             x0, [x0, #0x4d0]
    // 0x12eb144: StoreField: r1->field_f = r0
    //     0x12eb144: stur            w0, [x1, #0xf]
    // 0x12eb148: ldur            x2, [fp, #-0x10]
    // 0x12eb14c: r0 = evaluate()
    //     0x12eb14c: bl              #0x112be60  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x12eb150: stur            x0, [fp, #-0x10]
    // 0x12eb154: r16 = 136
    //     0x12eb154: mov             x16, #0x88
    // 0x12eb158: stp             x16, NULL, [SP]
    // 0x12eb15c: r0 = ByteData()
    //     0x12eb15c: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0x12eb160: stur            x0, [fp, #-0x20]
    // 0x12eb164: r0 = Paint()
    //     0x12eb164: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x12eb168: mov             x3, x0
    // 0x12eb16c: ldur            x0, [fp, #-0x20]
    // 0x12eb170: stur            x3, [fp, #-0x28]
    // 0x12eb174: StoreField: r3->field_7 = r0
    //     0x12eb174: stur            w0, [x3, #7]
    // 0x12eb178: ldr             x0, [fp, #0x10]
    // 0x12eb17c: LoadField: r2 = r0->field_3f
    //     0x12eb17c: ldur            w2, [x0, #0x3f]
    // 0x12eb180: DecompressPointer r2
    //     0x12eb180: add             x2, x2, HEAP, lsl #32
    // 0x12eb184: cmp             w2, NULL
    // 0x12eb188: b.eq            #0x12eb1c4
    // 0x12eb18c: mov             x1, x3
    // 0x12eb190: r0 = color=()
    //     0x12eb190: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0x12eb194: ldur            x0, [fp, #-0x10]
    // 0x12eb198: LoadField: d0 = r0->field_7
    //     0x12eb198: ldur            d0, [x0, #7]
    // 0x12eb19c: ldur            x1, [fp, #-0x18]
    // 0x12eb1a0: ldur            x2, [fp, #-8]
    // 0x12eb1a4: ldur            x3, [fp, #-0x28]
    // 0x12eb1a8: r0 = drawCircle()
    //     0x12eb1a8: bl              #0xb6acd4  ; [dart:ui] _NativeCanvas::drawCircle
    // 0x12eb1ac: r0 = Null
    //     0x12eb1ac: mov             x0, NULL
    // 0x12eb1b0: LeaveFrame
    //     0x12eb1b0: mov             SP, fp
    //     0x12eb1b4: ldp             fp, lr, [SP], #0x10
    // 0x12eb1b8: ret
    //     0x12eb1b8: ret             
    // 0x12eb1bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12eb1bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12eb1c0: b               #0x12eb120
    // 0x12eb1c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12eb1c4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}
