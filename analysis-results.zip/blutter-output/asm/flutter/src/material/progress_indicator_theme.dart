// lib: , url: package:flutter/src/material/progress_indicator_theme.dart

// class id: 1048932, size: 0x8
class :: {
}

// class id: 5122, size: 0x48, field offset: 0x8
//   const constructor, 
class ProgressIndicatorThemeData extends _MixinApplication3&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0x113541c, size: 0x244
    // 0x113541c: EnterFrame
    //     0x113541c: stp             fp, lr, [SP, #-0x10]!
    //     0x1135420: mov             fp, SP
    // 0x1135424: AllocStack(0xb8)
    //     0x1135424: sub             SP, SP, #0xb8
    // 0x1135428: CheckStackOverflow
    //     0x1135428: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x113542c: cmp             SP, x16
    //     0x1135430: b.ls            #0x1135658
    // 0x1135434: ldr             x2, [fp, #0x10]
    // 0x1135438: r0 = LoadClassIdInstr(r2)
    //     0x1135438: ldur            x0, [x2, #-1]
    //     0x113543c: ubfx            x0, x0, #0xc, #0x14
    // 0x1135440: mov             x1, x2
    // 0x1135444: r0 = GDT[cid_x0 + 0xec6]()
    //     0x1135444: add             lr, x0, #0xec6
    //     0x1135448: ldr             lr, [x21, lr, lsl #3]
    //     0x113544c: blr             lr
    // 0x1135450: mov             x3, x0
    // 0x1135454: ldr             x2, [fp, #0x10]
    // 0x1135458: stur            x3, [fp, #-8]
    // 0x113545c: r0 = LoadClassIdInstr(r2)
    //     0x113545c: ldur            x0, [x2, #-1]
    //     0x1135460: ubfx            x0, x0, #0xc, #0x14
    // 0x1135464: mov             x1, x2
    // 0x1135468: r0 = GDT[cid_x0 + 0x1458]()
    //     0x1135468: mov             x17, #0x1458
    //     0x113546c: add             lr, x0, x17
    //     0x1135470: ldr             lr, [x21, lr, lsl #3]
    //     0x1135474: blr             lr
    // 0x1135478: mov             x3, x0
    // 0x113547c: ldr             x2, [fp, #0x10]
    // 0x1135480: stur            x3, [fp, #-0x10]
    // 0x1135484: r0 = LoadClassIdInstr(r2)
    //     0x1135484: ldur            x0, [x2, #-1]
    //     0x1135488: ubfx            x0, x0, #0xc, #0x14
    // 0x113548c: mov             x1, x2
    // 0x1135490: r0 = GDT[cid_x0 + 0x167f]()
    //     0x1135490: mov             x17, #0x167f
    //     0x1135494: add             lr, x0, x17
    //     0x1135498: ldr             lr, [x21, lr, lsl #3]
    //     0x113549c: blr             lr
    // 0x11354a0: mov             x3, x0
    // 0x11354a4: ldr             x2, [fp, #0x10]
    // 0x11354a8: stur            x3, [fp, #-0x18]
    // 0x11354ac: r0 = LoadClassIdInstr(r2)
    //     0x11354ac: ldur            x0, [x2, #-1]
    //     0x11354b0: ubfx            x0, x0, #0xc, #0x14
    // 0x11354b4: mov             x1, x2
    // 0x11354b8: r0 = GDT[cid_x0 + 0x6727]()
    //     0x11354b8: mov             x17, #0x6727
    //     0x11354bc: add             lr, x0, x17
    //     0x11354c0: ldr             lr, [x21, lr, lsl #3]
    //     0x11354c4: blr             lr
    // 0x11354c8: ldr             x2, [fp, #0x10]
    // 0x11354cc: r0 = LoadClassIdInstr(r2)
    //     0x11354cc: ldur            x0, [x2, #-1]
    //     0x11354d0: ubfx            x0, x0, #0xc, #0x14
    // 0x11354d4: mov             x1, x2
    // 0x11354d8: r0 = GDT[cid_x0 + 0x4e42]()
    //     0x11354d8: mov             x17, #0x4e42
    //     0x11354dc: add             lr, x0, x17
    //     0x11354e0: ldr             lr, [x21, lr, lsl #3]
    //     0x11354e4: blr             lr
    // 0x11354e8: mov             x3, x0
    // 0x11354ec: ldr             x2, [fp, #0x10]
    // 0x11354f0: stur            x3, [fp, #-0x20]
    // 0x11354f4: r0 = LoadClassIdInstr(r2)
    //     0x11354f4: ldur            x0, [x2, #-1]
    //     0x11354f8: ubfx            x0, x0, #0xc, #0x14
    // 0x11354fc: mov             x1, x2
    // 0x1135500: r0 = GDT[cid_x0 + 0x4af1]()
    //     0x1135500: mov             x17, #0x4af1
    //     0x1135504: add             lr, x0, x17
    //     0x1135508: ldr             lr, [x21, lr, lsl #3]
    //     0x113550c: blr             lr
    // 0x1135510: ldr             x2, [fp, #0x10]
    // 0x1135514: r0 = LoadClassIdInstr(r2)
    //     0x1135514: ldur            x0, [x2, #-1]
    //     0x1135518: ubfx            x0, x0, #0xc, #0x14
    // 0x113551c: mov             x1, x2
    // 0x1135520: r0 = GDT[cid_x0 + 0x2d5f]()
    //     0x1135520: mov             x17, #0x2d5f
    //     0x1135524: add             lr, x0, x17
    //     0x1135528: ldr             lr, [x21, lr, lsl #3]
    //     0x113552c: blr             lr
    // 0x1135530: mov             x3, x0
    // 0x1135534: ldr             x2, [fp, #0x10]
    // 0x1135538: stur            x3, [fp, #-0x28]
    // 0x113553c: r0 = LoadClassIdInstr(r2)
    //     0x113553c: ldur            x0, [x2, #-1]
    //     0x1135540: ubfx            x0, x0, #0xc, #0x14
    // 0x1135544: mov             x1, x2
    // 0x1135548: r0 = GDT[cid_x0 + 0xeb8]()
    //     0x1135548: add             lr, x0, #0xeb8
    //     0x113554c: ldr             lr, [x21, lr, lsl #3]
    //     0x1135550: blr             lr
    // 0x1135554: mov             x3, x0
    // 0x1135558: ldr             x2, [fp, #0x10]
    // 0x113555c: stur            x3, [fp, #-0x30]
    // 0x1135560: r0 = LoadClassIdInstr(r2)
    //     0x1135560: ldur            x0, [x2, #-1]
    //     0x1135564: ubfx            x0, x0, #0xc, #0x14
    // 0x1135568: mov             x1, x2
    // 0x113556c: r0 = GDT[cid_x0 + 0xebf]()
    //     0x113556c: add             lr, x0, #0xebf
    //     0x1135570: ldr             lr, [x21, lr, lsl #3]
    //     0x1135574: blr             lr
    // 0x1135578: mov             x3, x0
    // 0x113557c: ldr             x2, [fp, #0x10]
    // 0x1135580: stur            x3, [fp, #-0x38]
    // 0x1135584: r0 = LoadClassIdInstr(r2)
    //     0x1135584: ldur            x0, [x2, #-1]
    //     0x1135588: ubfx            x0, x0, #0xc, #0x14
    // 0x113558c: mov             x1, x2
    // 0x1135590: r0 = GDT[cid_x0 + 0xfed]()
    //     0x1135590: add             lr, x0, #0xfed
    //     0x1135594: ldr             lr, [x21, lr, lsl #3]
    //     0x1135598: blr             lr
    // 0x113559c: mov             x3, x0
    // 0x11355a0: ldr             x2, [fp, #0x10]
    // 0x11355a4: stur            x3, [fp, #-0x40]
    // 0x11355a8: r0 = LoadClassIdInstr(r2)
    //     0x11355a8: ldur            x0, [x2, #-1]
    //     0x11355ac: ubfx            x0, x0, #0xc, #0x14
    // 0x11355b0: mov             x1, x2
    // 0x11355b4: r0 = GDT[cid_x0 + 0x5efe]()
    //     0x11355b4: mov             x17, #0x5efe
    //     0x11355b8: add             lr, x0, x17
    //     0x11355bc: ldr             lr, [x21, lr, lsl #3]
    //     0x11355c0: blr             lr
    // 0x11355c4: mov             x2, x0
    // 0x11355c8: ldr             x1, [fp, #0x10]
    // 0x11355cc: stur            x2, [fp, #-0x48]
    // 0x11355d0: r0 = LoadClassIdInstr(r1)
    //     0x11355d0: ldur            x0, [x1, #-1]
    //     0x11355d4: ubfx            x0, x0, #0xc, #0x14
    // 0x11355d8: r0 = GDT[cid_x0 + 0x5cd1]()
    //     0x11355d8: mov             x17, #0x5cd1
    //     0x11355dc: add             lr, x0, x17
    //     0x11355e0: ldr             lr, [x21, lr, lsl #3]
    //     0x11355e4: blr             lr
    // 0x11355e8: ldur            x16, [fp, #-0x18]
    // 0x11355ec: stp             NULL, x16, [SP, #0x60]
    // 0x11355f0: ldur            x16, [fp, #-0x20]
    // 0x11355f4: stp             x16, NULL, [SP, #0x50]
    // 0x11355f8: ldur            x16, [fp, #-0x28]
    // 0x11355fc: stp             x16, NULL, [SP, #0x40]
    // 0x1135600: ldur            x16, [fp, #-0x30]
    // 0x1135604: ldur            lr, [fp, #-0x38]
    // 0x1135608: stp             lr, x16, [SP, #0x30]
    // 0x113560c: ldur            x16, [fp, #-0x40]
    // 0x1135610: stp             x16, NULL, [SP, #0x20]
    // 0x1135614: ldur            x16, [fp, #-0x48]
    // 0x1135618: stp             x0, x16, [SP, #0x10]
    // 0x113561c: stp             NULL, NULL, [SP]
    // 0x1135620: ldur            x1, [fp, #-8]
    // 0x1135624: ldur            x2, [fp, #-0x10]
    // 0x1135628: r4 = const [0, 0x10, 0xe, 0x10, null]
    //     0x1135628: add             x4, PP, #0x26, lsl #12  ; [pp+0x262c8] List(5) [0, 0x10, 0xe, 0x10, Null]
    //     0x113562c: ldr             x4, [x4, #0x2c8]
    // 0x1135630: r0 = hash()
    //     0x1135630: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x1135634: mov             x2, x0
    // 0x1135638: r0 = BoxInt64Instr(r2)
    //     0x1135638: sbfiz           x0, x2, #1, #0x1f
    //     0x113563c: cmp             x2, x0, asr #1
    //     0x1135640: b.eq            #0x113564c
    //     0x1135644: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1135648: stur            x2, [x0, #7]
    // 0x113564c: LeaveFrame
    //     0x113564c: mov             SP, fp
    //     0x1135650: ldp             fp, lr, [SP], #0x10
    // 0x1135654: ret
    //     0x1135654: ret             
    // 0x1135658: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1135658: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x113565c: b               #0x1135434
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x116609c, size: 0x228
    // 0x116609c: EnterFrame
    //     0x116609c: stp             fp, lr, [SP, #-0x10]!
    //     0x11660a0: mov             fp, SP
    // 0x11660a4: AllocStack(0x48)
    //     0x11660a4: sub             SP, SP, #0x48
    // 0x11660a8: SetupParameters(dynamic _ /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */, dynamic _ /* d0 => d0, fp-0x48 */)
    //     0x11660a8: mov             x4, x1
    //     0x11660ac: mov             x0, x2
    //     0x11660b0: stur            x1, [fp, #-0x10]
    //     0x11660b4: stur            x2, [fp, #-0x18]
    //     0x11660b8: stur            d0, [fp, #-0x48]
    // 0x11660bc: CheckStackOverflow
    //     0x11660bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11660c0: cmp             SP, x16
    //     0x11660c4: b.ls            #0x11662a0
    // 0x11660c8: cmp             w4, w0
    // 0x11660cc: b.ne            #0x11660e0
    // 0x11660d0: mov             x0, x4
    // 0x11660d4: LeaveFrame
    //     0x11660d4: mov             SP, fp
    //     0x11660d8: ldp             fp, lr, [SP], #0x10
    // 0x11660dc: ret
    //     0x11660dc: ret             
    // 0x11660e0: r5 = inline_Allocate_Double()
    //     0x11660e0: ldp             x5, x1, [THR, #0x60]  ; THR::top
    //     0x11660e4: add             x5, x5, #0x10
    //     0x11660e8: cmp             x1, x5
    //     0x11660ec: b.ls            #0x11662a8
    //     0x11660f0: str             x5, [THR, #0x60]  ; THR::top
    //     0x11660f4: sub             x5, x5, #0xf
    //     0x11660f8: mov             x1, #0xe19c
    //     0x11660fc: movk            x1, #3, lsl #16
    //     0x1166100: stur            x1, [x5, #-1]
    // 0x1166104: dmb             ishst
    // 0x1166108: StoreField: r5->field_7 = d0
    //     0x1166108: stur            d0, [x5, #7]
    // 0x116610c: mov             x3, x5
    // 0x1166110: stur            x5, [fp, #-8]
    // 0x1166114: r1 = Null
    //     0x1166114: mov             x1, NULL
    // 0x1166118: r2 = Null
    //     0x1166118: mov             x2, NULL
    // 0x116611c: r0 = lerp()
    //     0x116611c: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1166120: ldur            x3, [fp, #-8]
    // 0x1166124: r1 = Null
    //     0x1166124: mov             x1, NULL
    // 0x1166128: r2 = Null
    //     0x1166128: mov             x2, NULL
    // 0x116612c: r0 = lerp()
    //     0x116612c: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1166130: ldur            x0, [fp, #-0x10]
    // 0x1166134: LoadField: r1 = r0->field_f
    //     0x1166134: ldur            w1, [x0, #0xf]
    // 0x1166138: DecompressPointer r1
    //     0x1166138: add             x1, x1, HEAP, lsl #32
    // 0x116613c: ldur            x4, [fp, #-0x18]
    // 0x1166140: LoadField: r2 = r4->field_f
    //     0x1166140: ldur            w2, [x4, #0xf]
    // 0x1166144: DecompressPointer r2
    //     0x1166144: add             x2, x2, HEAP, lsl #32
    // 0x1166148: ldur            x3, [fp, #-8]
    // 0x116614c: r0 = lerpDouble()
    //     0x116614c: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1166150: ldur            x3, [fp, #-8]
    // 0x1166154: r1 = Null
    //     0x1166154: mov             x1, NULL
    // 0x1166158: r2 = Null
    //     0x1166158: mov             x2, NULL
    // 0x116615c: stur            x0, [fp, #-0x20]
    // 0x1166160: r0 = lerp()
    //     0x1166160: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1166164: ldur            x3, [fp, #-8]
    // 0x1166168: r1 = Null
    //     0x1166168: mov             x1, NULL
    // 0x116616c: r2 = Null
    //     0x116616c: mov             x2, NULL
    // 0x1166170: r0 = lerp()
    //     0x1166170: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1166174: ldur            x0, [fp, #-0x10]
    // 0x1166178: LoadField: r1 = r0->field_1b
    //     0x1166178: ldur            w1, [x0, #0x1b]
    // 0x116617c: DecompressPointer r1
    //     0x116617c: add             x1, x1, HEAP, lsl #32
    // 0x1166180: ldur            x3, [fp, #-0x18]
    // 0x1166184: LoadField: r2 = r3->field_1b
    //     0x1166184: ldur            w2, [x3, #0x1b]
    // 0x1166188: DecompressPointer r2
    //     0x1166188: add             x2, x2, HEAP, lsl #32
    // 0x116618c: ldur            d0, [fp, #-0x48]
    // 0x1166190: r0 = lerp()
    //     0x1166190: bl              #0xbff804  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::lerp
    // 0x1166194: ldur            x3, [fp, #-8]
    // 0x1166198: r1 = Null
    //     0x1166198: mov             x1, NULL
    // 0x116619c: r2 = Null
    //     0x116619c: mov             x2, NULL
    // 0x11661a0: stur            x0, [fp, #-0x28]
    // 0x11661a4: r0 = lerp()
    //     0x11661a4: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x11661a8: ldur            x0, [fp, #-0x10]
    // 0x11661ac: LoadField: r1 = r0->field_23
    //     0x11661ac: ldur            w1, [x0, #0x23]
    // 0x11661b0: DecompressPointer r1
    //     0x11661b0: add             x1, x1, HEAP, lsl #32
    // 0x11661b4: ldur            x4, [fp, #-0x18]
    // 0x11661b8: LoadField: r2 = r4->field_23
    //     0x11661b8: ldur            w2, [x4, #0x23]
    // 0x11661bc: DecompressPointer r2
    //     0x11661bc: add             x2, x2, HEAP, lsl #32
    // 0x11661c0: ldur            x3, [fp, #-8]
    // 0x11661c4: r0 = lerpDouble()
    //     0x11661c4: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x11661c8: mov             x4, x0
    // 0x11661cc: ldur            x0, [fp, #-0x10]
    // 0x11661d0: stur            x4, [fp, #-0x30]
    // 0x11661d4: LoadField: r1 = r0->field_27
    //     0x11661d4: ldur            w1, [x0, #0x27]
    // 0x11661d8: DecompressPointer r1
    //     0x11661d8: add             x1, x1, HEAP, lsl #32
    // 0x11661dc: ldur            x5, [fp, #-0x18]
    // 0x11661e0: LoadField: r2 = r5->field_27
    //     0x11661e0: ldur            w2, [x5, #0x27]
    // 0x11661e4: DecompressPointer r2
    //     0x11661e4: add             x2, x2, HEAP, lsl #32
    // 0x11661e8: ldur            x3, [fp, #-8]
    // 0x11661ec: r0 = lerpDouble()
    //     0x11661ec: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x11661f0: mov             x4, x0
    // 0x11661f4: ldur            x0, [fp, #-0x10]
    // 0x11661f8: stur            x4, [fp, #-0x38]
    // 0x11661fc: LoadField: r1 = r0->field_2b
    //     0x11661fc: ldur            w1, [x0, #0x2b]
    // 0x1166200: DecompressPointer r1
    //     0x1166200: add             x1, x1, HEAP, lsl #32
    // 0x1166204: ldur            x5, [fp, #-0x18]
    // 0x1166208: LoadField: r2 = r5->field_2b
    //     0x1166208: ldur            w2, [x5, #0x2b]
    // 0x116620c: DecompressPointer r2
    //     0x116620c: add             x2, x2, HEAP, lsl #32
    // 0x1166210: ldur            x3, [fp, #-8]
    // 0x1166214: r0 = lerpDouble()
    //     0x1166214: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1166218: ldur            d0, [fp, #-0x48]
    // 0x116621c: r1 = Null
    //     0x116621c: mov             x1, NULL
    // 0x1166220: r2 = Null
    //     0x1166220: mov             x2, NULL
    // 0x1166224: stur            x0, [fp, #-0x40]
    // 0x1166228: r0 = lerp()
    //     0x1166228: bl              #0x1163c14  ; [package:flutter/src/rendering/box.dart] BoxConstraints::lerp
    // 0x116622c: ldur            x0, [fp, #-0x10]
    // 0x1166230: LoadField: r1 = r0->field_37
    //     0x1166230: ldur            w1, [x0, #0x37]
    // 0x1166234: DecompressPointer r1
    //     0x1166234: add             x1, x1, HEAP, lsl #32
    // 0x1166238: ldur            x0, [fp, #-0x18]
    // 0x116623c: LoadField: r2 = r0->field_37
    //     0x116623c: ldur            w2, [x0, #0x37]
    // 0x1166240: DecompressPointer r2
    //     0x1166240: add             x2, x2, HEAP, lsl #32
    // 0x1166244: ldur            x3, [fp, #-8]
    // 0x1166248: r0 = lerpDouble()
    //     0x1166248: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x116624c: ldur            x3, [fp, #-8]
    // 0x1166250: r1 = Null
    //     0x1166250: mov             x1, NULL
    // 0x1166254: r2 = Null
    //     0x1166254: mov             x2, NULL
    // 0x1166258: stur            x0, [fp, #-8]
    // 0x116625c: r0 = lerp()
    //     0x116625c: bl              #0x1140de0  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0x1166260: r0 = ProgressIndicatorThemeData()
    //     0x1166260: bl              #0x11662c4  ; AllocateProgressIndicatorThemeDataStub -> ProgressIndicatorThemeData (size=0x48)
    // 0x1166264: ldur            x1, [fp, #-0x20]
    // 0x1166268: StoreField: r0->field_f = r1
    //     0x1166268: stur            w1, [x0, #0xf]
    // 0x116626c: ldur            x1, [fp, #-0x28]
    // 0x1166270: StoreField: r0->field_1b = r1
    //     0x1166270: stur            w1, [x0, #0x1b]
    // 0x1166274: ldur            x1, [fp, #-0x30]
    // 0x1166278: StoreField: r0->field_23 = r1
    //     0x1166278: stur            w1, [x0, #0x23]
    // 0x116627c: ldur            x1, [fp, #-0x38]
    // 0x1166280: StoreField: r0->field_27 = r1
    //     0x1166280: stur            w1, [x0, #0x27]
    // 0x1166284: ldur            x1, [fp, #-0x40]
    // 0x1166288: StoreField: r0->field_2b = r1
    //     0x1166288: stur            w1, [x0, #0x2b]
    // 0x116628c: ldur            x1, [fp, #-8]
    // 0x1166290: StoreField: r0->field_37 = r1
    //     0x1166290: stur            w1, [x0, #0x37]
    // 0x1166294: LeaveFrame
    //     0x1166294: mov             SP, fp
    //     0x1166298: ldp             fp, lr, [SP], #0x10
    // 0x116629c: ret
    //     0x116629c: ret             
    // 0x11662a0: r0 = StackOverflowSharedWithFPURegs()
    //     0x11662a0: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x11662a4: b               #0x11660c8
    // 0x11662a8: SaveReg d0
    //     0x11662a8: str             q0, [SP, #-0x10]!
    // 0x11662ac: stp             x0, x4, [SP, #-0x10]!
    // 0x11662b0: r0 = AllocateDouble()
    //     0x11662b0: bl              #0x13df878  ; AllocateDoubleStub
    // 0x11662b4: mov             x5, x0
    // 0x11662b8: ldp             x0, x4, [SP], #0x10
    // 0x11662bc: RestoreReg d0
    //     0x11662bc: ldr             q0, [SP], #0x10
    // 0x11662c0: b               #0x1166108
  }
  _ ==(/* No info */) {
    // ** addr: 0x1270a1c, size: 0x58c
    // 0x1270a1c: EnterFrame
    //     0x1270a1c: stp             fp, lr, [SP, #-0x10]!
    //     0x1270a20: mov             fp, SP
    // 0x1270a24: AllocStack(0x18)
    //     0x1270a24: sub             SP, SP, #0x18
    // 0x1270a28: CheckStackOverflow
    //     0x1270a28: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1270a2c: cmp             SP, x16
    //     0x1270a30: b.ls            #0x1270fa0
    // 0x1270a34: ldr             x1, [fp, #0x10]
    // 0x1270a38: cmp             w1, NULL
    // 0x1270a3c: b.ne            #0x1270a50
    // 0x1270a40: r0 = false
    //     0x1270a40: add             x0, NULL, #0x30  ; false
    // 0x1270a44: LeaveFrame
    //     0x1270a44: mov             SP, fp
    //     0x1270a48: ldp             fp, lr, [SP], #0x10
    // 0x1270a4c: ret
    //     0x1270a4c: ret             
    // 0x1270a50: ldr             x0, [fp, #0x18]
    // 0x1270a54: cmp             w0, w1
    // 0x1270a58: b.ne            #0x1270a6c
    // 0x1270a5c: r0 = true
    //     0x1270a5c: add             x0, NULL, #0x20  ; true
    // 0x1270a60: LeaveFrame
    //     0x1270a60: mov             SP, fp
    //     0x1270a64: ldp             fp, lr, [SP], #0x10
    // 0x1270a68: ret
    //     0x1270a68: ret             
    // 0x1270a6c: stp             x0, x1, [SP]
    // 0x1270a70: r0 = _haveSameRuntimeType()
    //     0x1270a70: bl              #0x88249c  ; [dart:core] Object::_haveSameRuntimeType
    // 0x1270a74: tbz             w0, #4, #0x1270a88
    // 0x1270a78: r0 = false
    //     0x1270a78: add             x0, NULL, #0x30  ; false
    // 0x1270a7c: LeaveFrame
    //     0x1270a7c: mov             SP, fp
    //     0x1270a80: ldp             fp, lr, [SP], #0x10
    // 0x1270a84: ret
    //     0x1270a84: ret             
    // 0x1270a88: ldr             x2, [fp, #0x10]
    // 0x1270a8c: r0 = 60
    //     0x1270a8c: mov             x0, #0x3c
    // 0x1270a90: branchIfSmi(r2, 0x1270a9c)
    //     0x1270a90: tbz             w2, #0, #0x1270a9c
    // 0x1270a94: r0 = LoadClassIdInstr(r2)
    //     0x1270a94: ldur            x0, [x2, #-1]
    //     0x1270a98: ubfx            x0, x0, #0xc, #0x14
    // 0x1270a9c: r17 = -5122
    //     0x1270a9c: mov             x17, #-0x1402
    // 0x1270aa0: add             x16, x0, x17
    // 0x1270aa4: cmp             x16, #6
    // 0x1270aa8: b.hi            #0x1270f90
    // 0x1270aac: ldr             x3, [fp, #0x18]
    // 0x1270ab0: r0 = LoadClassIdInstr(r2)
    //     0x1270ab0: ldur            x0, [x2, #-1]
    //     0x1270ab4: ubfx            x0, x0, #0xc, #0x14
    // 0x1270ab8: mov             x1, x2
    // 0x1270abc: r0 = GDT[cid_x0 + 0xec6]()
    //     0x1270abc: add             lr, x0, #0xec6
    //     0x1270ac0: ldr             lr, [x21, lr, lsl #3]
    //     0x1270ac4: blr             lr
    // 0x1270ac8: mov             x3, x0
    // 0x1270acc: ldr             x2, [fp, #0x18]
    // 0x1270ad0: stur            x3, [fp, #-8]
    // 0x1270ad4: r0 = LoadClassIdInstr(r2)
    //     0x1270ad4: ldur            x0, [x2, #-1]
    //     0x1270ad8: ubfx            x0, x0, #0xc, #0x14
    // 0x1270adc: mov             x1, x2
    // 0x1270ae0: r0 = GDT[cid_x0 + 0xec6]()
    //     0x1270ae0: add             lr, x0, #0xec6
    //     0x1270ae4: ldr             lr, [x21, lr, lsl #3]
    //     0x1270ae8: blr             lr
    // 0x1270aec: mov             x1, x0
    // 0x1270af0: ldur            x0, [fp, #-8]
    // 0x1270af4: r2 = LoadClassIdInstr(r0)
    //     0x1270af4: ldur            x2, [x0, #-1]
    //     0x1270af8: ubfx            x2, x2, #0xc, #0x14
    // 0x1270afc: stp             x1, x0, [SP]
    // 0x1270b00: mov             x0, x2
    // 0x1270b04: mov             lr, x0
    // 0x1270b08: ldr             lr, [x21, lr, lsl #3]
    // 0x1270b0c: blr             lr
    // 0x1270b10: tbnz            w0, #4, #0x1270f90
    // 0x1270b14: ldr             x2, [fp, #0x18]
    // 0x1270b18: ldr             x3, [fp, #0x10]
    // 0x1270b1c: r0 = LoadClassIdInstr(r3)
    //     0x1270b1c: ldur            x0, [x3, #-1]
    //     0x1270b20: ubfx            x0, x0, #0xc, #0x14
    // 0x1270b24: mov             x1, x3
    // 0x1270b28: r0 = GDT[cid_x0 + 0x1458]()
    //     0x1270b28: mov             x17, #0x1458
    //     0x1270b2c: add             lr, x0, x17
    //     0x1270b30: ldr             lr, [x21, lr, lsl #3]
    //     0x1270b34: blr             lr
    // 0x1270b38: mov             x3, x0
    // 0x1270b3c: ldr             x2, [fp, #0x18]
    // 0x1270b40: stur            x3, [fp, #-8]
    // 0x1270b44: r0 = LoadClassIdInstr(r2)
    //     0x1270b44: ldur            x0, [x2, #-1]
    //     0x1270b48: ubfx            x0, x0, #0xc, #0x14
    // 0x1270b4c: mov             x1, x2
    // 0x1270b50: r0 = GDT[cid_x0 + 0x1458]()
    //     0x1270b50: mov             x17, #0x1458
    //     0x1270b54: add             lr, x0, x17
    //     0x1270b58: ldr             lr, [x21, lr, lsl #3]
    //     0x1270b5c: blr             lr
    // 0x1270b60: mov             x1, x0
    // 0x1270b64: ldur            x0, [fp, #-8]
    // 0x1270b68: r2 = LoadClassIdInstr(r0)
    //     0x1270b68: ldur            x2, [x0, #-1]
    //     0x1270b6c: ubfx            x2, x2, #0xc, #0x14
    // 0x1270b70: stp             x1, x0, [SP]
    // 0x1270b74: mov             x0, x2
    // 0x1270b78: mov             lr, x0
    // 0x1270b7c: ldr             lr, [x21, lr, lsl #3]
    // 0x1270b80: blr             lr
    // 0x1270b84: tbnz            w0, #4, #0x1270f90
    // 0x1270b88: ldr             x2, [fp, #0x18]
    // 0x1270b8c: ldr             x3, [fp, #0x10]
    // 0x1270b90: r0 = LoadClassIdInstr(r3)
    //     0x1270b90: ldur            x0, [x3, #-1]
    //     0x1270b94: ubfx            x0, x0, #0xc, #0x14
    // 0x1270b98: mov             x1, x3
    // 0x1270b9c: r0 = GDT[cid_x0 + 0x167f]()
    //     0x1270b9c: mov             x17, #0x167f
    //     0x1270ba0: add             lr, x0, x17
    //     0x1270ba4: ldr             lr, [x21, lr, lsl #3]
    //     0x1270ba8: blr             lr
    // 0x1270bac: mov             x3, x0
    // 0x1270bb0: ldr             x2, [fp, #0x18]
    // 0x1270bb4: stur            x3, [fp, #-8]
    // 0x1270bb8: r0 = LoadClassIdInstr(r2)
    //     0x1270bb8: ldur            x0, [x2, #-1]
    //     0x1270bbc: ubfx            x0, x0, #0xc, #0x14
    // 0x1270bc0: mov             x1, x2
    // 0x1270bc4: r0 = GDT[cid_x0 + 0x167f]()
    //     0x1270bc4: mov             x17, #0x167f
    //     0x1270bc8: add             lr, x0, x17
    //     0x1270bcc: ldr             lr, [x21, lr, lsl #3]
    //     0x1270bd0: blr             lr
    // 0x1270bd4: mov             x1, x0
    // 0x1270bd8: ldur            x0, [fp, #-8]
    // 0x1270bdc: r2 = LoadClassIdInstr(r0)
    //     0x1270bdc: ldur            x2, [x0, #-1]
    //     0x1270be0: ubfx            x2, x2, #0xc, #0x14
    // 0x1270be4: stp             x1, x0, [SP]
    // 0x1270be8: mov             x0, x2
    // 0x1270bec: mov             lr, x0
    // 0x1270bf0: ldr             lr, [x21, lr, lsl #3]
    // 0x1270bf4: blr             lr
    // 0x1270bf8: tbnz            w0, #4, #0x1270f90
    // 0x1270bfc: ldr             x2, [fp, #0x18]
    // 0x1270c00: ldr             x3, [fp, #0x10]
    // 0x1270c04: r0 = LoadClassIdInstr(r3)
    //     0x1270c04: ldur            x0, [x3, #-1]
    //     0x1270c08: ubfx            x0, x0, #0xc, #0x14
    // 0x1270c0c: mov             x1, x3
    // 0x1270c10: r0 = GDT[cid_x0 + 0x6727]()
    //     0x1270c10: mov             x17, #0x6727
    //     0x1270c14: add             lr, x0, x17
    //     0x1270c18: ldr             lr, [x21, lr, lsl #3]
    //     0x1270c1c: blr             lr
    // 0x1270c20: ldr             x2, [fp, #0x18]
    // 0x1270c24: r0 = LoadClassIdInstr(r2)
    //     0x1270c24: ldur            x0, [x2, #-1]
    //     0x1270c28: ubfx            x0, x0, #0xc, #0x14
    // 0x1270c2c: mov             x1, x2
    // 0x1270c30: r0 = GDT[cid_x0 + 0x6727]()
    //     0x1270c30: mov             x17, #0x6727
    //     0x1270c34: add             lr, x0, x17
    //     0x1270c38: ldr             lr, [x21, lr, lsl #3]
    //     0x1270c3c: blr             lr
    // 0x1270c40: ldr             x2, [fp, #0x10]
    // 0x1270c44: r0 = LoadClassIdInstr(r2)
    //     0x1270c44: ldur            x0, [x2, #-1]
    //     0x1270c48: ubfx            x0, x0, #0xc, #0x14
    // 0x1270c4c: mov             x1, x2
    // 0x1270c50: r0 = GDT[cid_x0 + 0x4e42]()
    //     0x1270c50: mov             x17, #0x4e42
    //     0x1270c54: add             lr, x0, x17
    //     0x1270c58: ldr             lr, [x21, lr, lsl #3]
    //     0x1270c5c: blr             lr
    // 0x1270c60: mov             x3, x0
    // 0x1270c64: ldr             x2, [fp, #0x18]
    // 0x1270c68: stur            x3, [fp, #-8]
    // 0x1270c6c: r0 = LoadClassIdInstr(r2)
    //     0x1270c6c: ldur            x0, [x2, #-1]
    //     0x1270c70: ubfx            x0, x0, #0xc, #0x14
    // 0x1270c74: mov             x1, x2
    // 0x1270c78: r0 = GDT[cid_x0 + 0x4e42]()
    //     0x1270c78: mov             x17, #0x4e42
    //     0x1270c7c: add             lr, x0, x17
    //     0x1270c80: ldr             lr, [x21, lr, lsl #3]
    //     0x1270c84: blr             lr
    // 0x1270c88: mov             x1, x0
    // 0x1270c8c: ldur            x0, [fp, #-8]
    // 0x1270c90: r2 = LoadClassIdInstr(r0)
    //     0x1270c90: ldur            x2, [x0, #-1]
    //     0x1270c94: ubfx            x2, x2, #0xc, #0x14
    // 0x1270c98: stp             x1, x0, [SP]
    // 0x1270c9c: mov             x0, x2
    // 0x1270ca0: mov             lr, x0
    // 0x1270ca4: ldr             lr, [x21, lr, lsl #3]
    // 0x1270ca8: blr             lr
    // 0x1270cac: tbnz            w0, #4, #0x1270f90
    // 0x1270cb0: ldr             x2, [fp, #0x18]
    // 0x1270cb4: ldr             x3, [fp, #0x10]
    // 0x1270cb8: r0 = LoadClassIdInstr(r3)
    //     0x1270cb8: ldur            x0, [x3, #-1]
    //     0x1270cbc: ubfx            x0, x0, #0xc, #0x14
    // 0x1270cc0: mov             x1, x3
    // 0x1270cc4: r0 = GDT[cid_x0 + 0x4af1]()
    //     0x1270cc4: mov             x17, #0x4af1
    //     0x1270cc8: add             lr, x0, x17
    //     0x1270ccc: ldr             lr, [x21, lr, lsl #3]
    //     0x1270cd0: blr             lr
    // 0x1270cd4: ldr             x2, [fp, #0x18]
    // 0x1270cd8: r0 = LoadClassIdInstr(r2)
    //     0x1270cd8: ldur            x0, [x2, #-1]
    //     0x1270cdc: ubfx            x0, x0, #0xc, #0x14
    // 0x1270ce0: mov             x1, x2
    // 0x1270ce4: r0 = GDT[cid_x0 + 0x4af1]()
    //     0x1270ce4: mov             x17, #0x4af1
    //     0x1270ce8: add             lr, x0, x17
    //     0x1270cec: ldr             lr, [x21, lr, lsl #3]
    //     0x1270cf0: blr             lr
    // 0x1270cf4: ldr             x2, [fp, #0x10]
    // 0x1270cf8: r0 = LoadClassIdInstr(r2)
    //     0x1270cf8: ldur            x0, [x2, #-1]
    //     0x1270cfc: ubfx            x0, x0, #0xc, #0x14
    // 0x1270d00: mov             x1, x2
    // 0x1270d04: r0 = GDT[cid_x0 + 0x2d5f]()
    //     0x1270d04: mov             x17, #0x2d5f
    //     0x1270d08: add             lr, x0, x17
    //     0x1270d0c: ldr             lr, [x21, lr, lsl #3]
    //     0x1270d10: blr             lr
    // 0x1270d14: mov             x3, x0
    // 0x1270d18: ldr             x2, [fp, #0x18]
    // 0x1270d1c: stur            x3, [fp, #-8]
    // 0x1270d20: r0 = LoadClassIdInstr(r2)
    //     0x1270d20: ldur            x0, [x2, #-1]
    //     0x1270d24: ubfx            x0, x0, #0xc, #0x14
    // 0x1270d28: mov             x1, x2
    // 0x1270d2c: r0 = GDT[cid_x0 + 0x2d5f]()
    //     0x1270d2c: mov             x17, #0x2d5f
    //     0x1270d30: add             lr, x0, x17
    //     0x1270d34: ldr             lr, [x21, lr, lsl #3]
    //     0x1270d38: blr             lr
    // 0x1270d3c: mov             x1, x0
    // 0x1270d40: ldur            x0, [fp, #-8]
    // 0x1270d44: r2 = LoadClassIdInstr(r0)
    //     0x1270d44: ldur            x2, [x0, #-1]
    //     0x1270d48: ubfx            x2, x2, #0xc, #0x14
    // 0x1270d4c: stp             x1, x0, [SP]
    // 0x1270d50: mov             x0, x2
    // 0x1270d54: mov             lr, x0
    // 0x1270d58: ldr             lr, [x21, lr, lsl #3]
    // 0x1270d5c: blr             lr
    // 0x1270d60: tbnz            w0, #4, #0x1270f90
    // 0x1270d64: ldr             x2, [fp, #0x18]
    // 0x1270d68: ldr             x3, [fp, #0x10]
    // 0x1270d6c: r0 = LoadClassIdInstr(r3)
    //     0x1270d6c: ldur            x0, [x3, #-1]
    //     0x1270d70: ubfx            x0, x0, #0xc, #0x14
    // 0x1270d74: mov             x1, x3
    // 0x1270d78: r0 = GDT[cid_x0 + 0xeb8]()
    //     0x1270d78: add             lr, x0, #0xeb8
    //     0x1270d7c: ldr             lr, [x21, lr, lsl #3]
    //     0x1270d80: blr             lr
    // 0x1270d84: mov             x3, x0
    // 0x1270d88: ldr             x2, [fp, #0x18]
    // 0x1270d8c: stur            x3, [fp, #-8]
    // 0x1270d90: r0 = LoadClassIdInstr(r2)
    //     0x1270d90: ldur            x0, [x2, #-1]
    //     0x1270d94: ubfx            x0, x0, #0xc, #0x14
    // 0x1270d98: mov             x1, x2
    // 0x1270d9c: r0 = GDT[cid_x0 + 0xeb8]()
    //     0x1270d9c: add             lr, x0, #0xeb8
    //     0x1270da0: ldr             lr, [x21, lr, lsl #3]
    //     0x1270da4: blr             lr
    // 0x1270da8: mov             x1, x0
    // 0x1270dac: ldur            x0, [fp, #-8]
    // 0x1270db0: r2 = LoadClassIdInstr(r0)
    //     0x1270db0: ldur            x2, [x0, #-1]
    //     0x1270db4: ubfx            x2, x2, #0xc, #0x14
    // 0x1270db8: stp             x1, x0, [SP]
    // 0x1270dbc: mov             x0, x2
    // 0x1270dc0: mov             lr, x0
    // 0x1270dc4: ldr             lr, [x21, lr, lsl #3]
    // 0x1270dc8: blr             lr
    // 0x1270dcc: tbnz            w0, #4, #0x1270f90
    // 0x1270dd0: ldr             x2, [fp, #0x18]
    // 0x1270dd4: ldr             x3, [fp, #0x10]
    // 0x1270dd8: r0 = LoadClassIdInstr(r3)
    //     0x1270dd8: ldur            x0, [x3, #-1]
    //     0x1270ddc: ubfx            x0, x0, #0xc, #0x14
    // 0x1270de0: mov             x1, x3
    // 0x1270de4: r0 = GDT[cid_x0 + 0xebf]()
    //     0x1270de4: add             lr, x0, #0xebf
    //     0x1270de8: ldr             lr, [x21, lr, lsl #3]
    //     0x1270dec: blr             lr
    // 0x1270df0: mov             x3, x0
    // 0x1270df4: ldr             x2, [fp, #0x18]
    // 0x1270df8: stur            x3, [fp, #-8]
    // 0x1270dfc: r0 = LoadClassIdInstr(r2)
    //     0x1270dfc: ldur            x0, [x2, #-1]
    //     0x1270e00: ubfx            x0, x0, #0xc, #0x14
    // 0x1270e04: mov             x1, x2
    // 0x1270e08: r0 = GDT[cid_x0 + 0xebf]()
    //     0x1270e08: add             lr, x0, #0xebf
    //     0x1270e0c: ldr             lr, [x21, lr, lsl #3]
    //     0x1270e10: blr             lr
    // 0x1270e14: mov             x1, x0
    // 0x1270e18: ldur            x0, [fp, #-8]
    // 0x1270e1c: r2 = LoadClassIdInstr(r0)
    //     0x1270e1c: ldur            x2, [x0, #-1]
    //     0x1270e20: ubfx            x2, x2, #0xc, #0x14
    // 0x1270e24: stp             x1, x0, [SP]
    // 0x1270e28: mov             x0, x2
    // 0x1270e2c: mov             lr, x0
    // 0x1270e30: ldr             lr, [x21, lr, lsl #3]
    // 0x1270e34: blr             lr
    // 0x1270e38: tbnz            w0, #4, #0x1270f90
    // 0x1270e3c: ldr             x2, [fp, #0x18]
    // 0x1270e40: ldr             x3, [fp, #0x10]
    // 0x1270e44: r0 = LoadClassIdInstr(r3)
    //     0x1270e44: ldur            x0, [x3, #-1]
    //     0x1270e48: ubfx            x0, x0, #0xc, #0x14
    // 0x1270e4c: mov             x1, x3
    // 0x1270e50: r0 = GDT[cid_x0 + 0xfed]()
    //     0x1270e50: add             lr, x0, #0xfed
    //     0x1270e54: ldr             lr, [x21, lr, lsl #3]
    //     0x1270e58: blr             lr
    // 0x1270e5c: mov             x3, x0
    // 0x1270e60: ldr             x2, [fp, #0x18]
    // 0x1270e64: stur            x3, [fp, #-8]
    // 0x1270e68: r0 = LoadClassIdInstr(r2)
    //     0x1270e68: ldur            x0, [x2, #-1]
    //     0x1270e6c: ubfx            x0, x0, #0xc, #0x14
    // 0x1270e70: mov             x1, x2
    // 0x1270e74: r0 = GDT[cid_x0 + 0xfed]()
    //     0x1270e74: add             lr, x0, #0xfed
    //     0x1270e78: ldr             lr, [x21, lr, lsl #3]
    //     0x1270e7c: blr             lr
    // 0x1270e80: mov             x1, x0
    // 0x1270e84: ldur            x0, [fp, #-8]
    // 0x1270e88: r2 = LoadClassIdInstr(r0)
    //     0x1270e88: ldur            x2, [x0, #-1]
    //     0x1270e8c: ubfx            x2, x2, #0xc, #0x14
    // 0x1270e90: stp             x1, x0, [SP]
    // 0x1270e94: mov             x0, x2
    // 0x1270e98: mov             lr, x0
    // 0x1270e9c: ldr             lr, [x21, lr, lsl #3]
    // 0x1270ea0: blr             lr
    // 0x1270ea4: tbnz            w0, #4, #0x1270f90
    // 0x1270ea8: ldr             x2, [fp, #0x18]
    // 0x1270eac: ldr             x3, [fp, #0x10]
    // 0x1270eb0: r0 = LoadClassIdInstr(r3)
    //     0x1270eb0: ldur            x0, [x3, #-1]
    //     0x1270eb4: ubfx            x0, x0, #0xc, #0x14
    // 0x1270eb8: mov             x1, x3
    // 0x1270ebc: r0 = GDT[cid_x0 + 0x5efe]()
    //     0x1270ebc: mov             x17, #0x5efe
    //     0x1270ec0: add             lr, x0, x17
    //     0x1270ec4: ldr             lr, [x21, lr, lsl #3]
    //     0x1270ec8: blr             lr
    // 0x1270ecc: mov             x3, x0
    // 0x1270ed0: ldr             x2, [fp, #0x18]
    // 0x1270ed4: stur            x3, [fp, #-8]
    // 0x1270ed8: r0 = LoadClassIdInstr(r2)
    //     0x1270ed8: ldur            x0, [x2, #-1]
    //     0x1270edc: ubfx            x0, x0, #0xc, #0x14
    // 0x1270ee0: mov             x1, x2
    // 0x1270ee4: r0 = GDT[cid_x0 + 0x5efe]()
    //     0x1270ee4: mov             x17, #0x5efe
    //     0x1270ee8: add             lr, x0, x17
    //     0x1270eec: ldr             lr, [x21, lr, lsl #3]
    //     0x1270ef0: blr             lr
    // 0x1270ef4: mov             x1, x0
    // 0x1270ef8: ldur            x0, [fp, #-8]
    // 0x1270efc: r2 = LoadClassIdInstr(r0)
    //     0x1270efc: ldur            x2, [x0, #-1]
    //     0x1270f00: ubfx            x2, x2, #0xc, #0x14
    // 0x1270f04: stp             x1, x0, [SP]
    // 0x1270f08: mov             x0, x2
    // 0x1270f0c: mov             lr, x0
    // 0x1270f10: ldr             lr, [x21, lr, lsl #3]
    // 0x1270f14: blr             lr
    // 0x1270f18: tbnz            w0, #4, #0x1270f90
    // 0x1270f1c: ldr             x2, [fp, #0x18]
    // 0x1270f20: ldr             x1, [fp, #0x10]
    // 0x1270f24: r0 = LoadClassIdInstr(r1)
    //     0x1270f24: ldur            x0, [x1, #-1]
    //     0x1270f28: ubfx            x0, x0, #0xc, #0x14
    // 0x1270f2c: r0 = GDT[cid_x0 + 0x5cd1]()
    //     0x1270f2c: mov             x17, #0x5cd1
    //     0x1270f30: add             lr, x0, x17
    //     0x1270f34: ldr             lr, [x21, lr, lsl #3]
    //     0x1270f38: blr             lr
    // 0x1270f3c: mov             x2, x0
    // 0x1270f40: ldr             x1, [fp, #0x18]
    // 0x1270f44: stur            x2, [fp, #-8]
    // 0x1270f48: r0 = LoadClassIdInstr(r1)
    //     0x1270f48: ldur            x0, [x1, #-1]
    //     0x1270f4c: ubfx            x0, x0, #0xc, #0x14
    // 0x1270f50: r0 = GDT[cid_x0 + 0x5cd1]()
    //     0x1270f50: mov             x17, #0x5cd1
    //     0x1270f54: add             lr, x0, x17
    //     0x1270f58: ldr             lr, [x21, lr, lsl #3]
    //     0x1270f5c: blr             lr
    // 0x1270f60: mov             x1, x0
    // 0x1270f64: ldur            x0, [fp, #-8]
    // 0x1270f68: r2 = LoadClassIdInstr(r0)
    //     0x1270f68: ldur            x2, [x0, #-1]
    //     0x1270f6c: ubfx            x2, x2, #0xc, #0x14
    // 0x1270f70: stp             x1, x0, [SP]
    // 0x1270f74: mov             x0, x2
    // 0x1270f78: mov             lr, x0
    // 0x1270f7c: ldr             lr, [x21, lr, lsl #3]
    // 0x1270f80: blr             lr
    // 0x1270f84: tbnz            w0, #4, #0x1270f90
    // 0x1270f88: r0 = true
    //     0x1270f88: add             x0, NULL, #0x20  ; true
    // 0x1270f8c: b               #0x1270f94
    // 0x1270f90: r0 = false
    //     0x1270f90: add             x0, NULL, #0x30  ; false
    // 0x1270f94: LeaveFrame
    //     0x1270f94: mov             SP, fp
    //     0x1270f98: ldp             fp, lr, [SP], #0x10
    // 0x1270f9c: ret
    //     0x1270f9c: ret             
    // 0x1270fa0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1270fa0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1270fa4: b               #0x1270a34
  }
}

// class id: 6840, size: 0x10, field offset: 0x10
//   const constructor, 
abstract class ProgressIndicatorTheme extends InheritedTheme {

  static _ of(/* No info */) {
    // ** addr: 0xd30c34, size: 0x5c
    // 0xd30c34: EnterFrame
    //     0xd30c34: stp             fp, lr, [SP, #-0x10]!
    //     0xd30c38: mov             fp, SP
    // 0xd30c3c: AllocStack(0x18)
    //     0xd30c3c: sub             SP, SP, #0x18
    // 0xd30c40: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0xd30c40: stur            x1, [fp, #-8]
    // 0xd30c44: CheckStackOverflow
    //     0xd30c44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd30c48: cmp             SP, x16
    //     0xd30c4c: b.ls            #0xd30c88
    // 0xd30c50: r16 = <ProgressIndicatorTheme>
    //     0xd30c50: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8fb58] TypeArguments: <ProgressIndicatorTheme>
    //     0xd30c54: ldr             x16, [x16, #0xb58]
    // 0xd30c58: stp             x1, x16, [SP]
    // 0xd30c5c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd30c5c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd30c60: r0 = dependOnInheritedWidgetOfExactType()
    //     0xd30c60: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xd30c64: ldur            x1, [fp, #-8]
    // 0xd30c68: r0 = of()
    //     0xd30c68: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd30c6c: r17 = 271
    //     0xd30c6c: mov             x17, #0x10f
    // 0xd30c70: ldr             w1, [x0, x17]
    // 0xd30c74: DecompressPointer r1
    //     0xd30c74: add             x1, x1, HEAP, lsl #32
    // 0xd30c78: mov             x0, x1
    // 0xd30c7c: LeaveFrame
    //     0xd30c7c: mov             SP, fp
    //     0xd30c80: ldp             fp, lr, [SP], #0x10
    // 0xd30c84: ret
    //     0xd30c84: ret             
    // 0xd30c88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd30c88: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd30c8c: b               #0xd30c50
  }
}
