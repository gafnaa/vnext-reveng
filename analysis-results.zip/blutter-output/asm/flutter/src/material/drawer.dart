// lib: , url: package:flutter/src/material/drawer.dart

// class id: 1048884, size: 0x8
class :: {
}

// class id: 5158, size: 0x34, field offset: 0x2c
class _DrawerDefaultsM3 extends DrawerThemeData {

  late final TextDirection direction; // offset: 0x30

  TextDirection direction(_DrawerDefaultsM3) {
    // ** addr: 0xfb9f8c, size: 0x38
    // 0xfb9f8c: EnterFrame
    //     0xfb9f8c: stp             fp, lr, [SP, #-0x10]!
    //     0xfb9f90: mov             fp, SP
    // 0xfb9f94: CheckStackOverflow
    //     0xfb9f94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb9f98: cmp             SP, x16
    //     0xfb9f9c: b.ls            #0xfb9fbc
    // 0xfb9fa0: ldr             x0, [fp, #0x10]
    // 0xfb9fa4: LoadField: r1 = r0->field_2b
    //     0xfb9fa4: ldur            w1, [x0, #0x2b]
    // 0xfb9fa8: DecompressPointer r1
    //     0xfb9fa8: add             x1, x1, HEAP, lsl #32
    // 0xfb9fac: r0 = of()
    //     0xfb9fac: bl              #0x87371c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0xfb9fb0: LeaveFrame
    //     0xfb9fb0: mov             SP, fp
    //     0xfb9fb4: ldp             fp, lr, [SP], #0x10
    // 0xfb9fb8: ret
    //     0xfb9fb8: ret             
    // 0xfb9fbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb9fbc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb9fc0: b               #0xfb9fa0
  }
}

// class id: 5159, size: 0x30, field offset: 0x2c
//   const constructor, 
class _DrawerDefaultsM2 extends DrawerThemeData {
}

// class id: 5763, size: 0x34, field offset: 0x1c
class DrawerControllerState extends _MixinApplication34&State&SingleTickerProviderStateMixin {

  late AnimationController _controller; // offset: 0x24

  _ close(/* No info */) {
    // ** addr: 0xb34b88, size: 0xac
    // 0xb34b88: EnterFrame
    //     0xb34b88: stp             fp, lr, [SP, #-0x10]!
    //     0xb34b8c: mov             fp, SP
    // 0xb34b90: AllocStack(0x10)
    //     0xb34b90: sub             SP, SP, #0x10
    // 0xb34b94: SetupParameters(DrawerControllerState this /* r1 => r0, fp-0x8 */)
    //     0xb34b94: mov             x0, x1
    //     0xb34b98: stur            x1, [fp, #-8]
    // 0xb34b9c: CheckStackOverflow
    //     0xb34b9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb34ba0: cmp             SP, x16
    //     0xb34ba4: b.ls            #0xb34c18
    // 0xb34ba8: LoadField: r1 = r0->field_23
    //     0xb34ba8: ldur            w1, [x0, #0x23]
    // 0xb34bac: DecompressPointer r1
    //     0xb34bac: add             x1, x1, HEAP, lsl #32
    // 0xb34bb0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb34bb4: cmp             w1, w16
    // 0xb34bb8: b.eq            #0xb34c20
    // 0xb34bbc: r16 = -1.000000
    //     0xb34bbc: add             x16, PP, #0x13, lsl #12  ; [pp+0x132a8] -1
    //     0xb34bc0: ldr             x16, [x16, #0x2a8]
    // 0xb34bc4: str             x16, [SP]
    // 0xb34bc8: r4 = const [0, 0x2, 0x1, 0x1, velocity, 0x1, null]
    //     0xb34bc8: add             x4, PP, #0x83, lsl #12  ; [pp+0x83820] List(7) [0, 0x2, 0x1, 0x1, "velocity", 0x1, Null]
    //     0xb34bcc: ldr             x4, [x4, #0x820]
    // 0xb34bd0: r0 = fling()
    //     0xb34bd0: bl              #0xb34edc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::fling
    // 0xb34bd4: ldur            x0, [fp, #-8]
    // 0xb34bd8: LoadField: r1 = r0->field_b
    //     0xb34bd8: ldur            w1, [x0, #0xb]
    // 0xb34bdc: DecompressPointer r1
    //     0xb34bdc: add             x1, x1, HEAP, lsl #32
    // 0xb34be0: cmp             w1, NULL
    // 0xb34be4: b.eq            #0xb34c2c
    // 0xb34be8: LoadField: r0 = r1->field_13
    //     0xb34be8: ldur            w0, [x1, #0x13]
    // 0xb34bec: DecompressPointer r0
    //     0xb34bec: add             x0, x0, HEAP, lsl #32
    // 0xb34bf0: cmp             w0, NULL
    // 0xb34bf4: b.eq            #0xb34c30
    // 0xb34bf8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb34bf8: ldur            w1, [x0, #0x17]
    // 0xb34bfc: DecompressPointer r1
    //     0xb34bfc: add             x1, x1, HEAP, lsl #32
    // 0xb34c00: r2 = false
    //     0xb34c00: add             x2, NULL, #0x30  ; false
    // 0xb34c04: r0 = _drawerOpenedCallback()
    //     0xb34c04: bl              #0xb34ca8  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::_drawerOpenedCallback
    // 0xb34c08: r0 = Null
    //     0xb34c08: mov             x0, NULL
    // 0xb34c0c: LeaveFrame
    //     0xb34c0c: mov             SP, fp
    //     0xb34c10: ldp             fp, lr, [SP], #0x10
    // 0xb34c14: ret
    //     0xb34c14: ret             
    // 0xb34c18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb34c18: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb34c1c: b               #0xb34ba8
    // 0xb34c20: r9 = _controller
    //     0xb34c20: add             x9, PP, #0x83, lsl #12  ; [pp+0x837c0] Field <DrawerControllerState._controller@82517151>: late (offset: 0x24)
    //     0xb34c24: ldr             x9, [x9, #0x7c0]
    // 0xb34c28: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xb34c28: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xb34c2c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb34c2c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb34c30: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb34c30: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  [closure] void close(dynamic) {
    // ** addr: 0xb34c70, size: 0x38
    // 0xb34c70: EnterFrame
    //     0xb34c70: stp             fp, lr, [SP, #-0x10]!
    //     0xb34c74: mov             fp, SP
    // 0xb34c78: ldr             x0, [fp, #0x10]
    // 0xb34c7c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb34c7c: ldur            w1, [x0, #0x17]
    // 0xb34c80: DecompressPointer r1
    //     0xb34c80: add             x1, x1, HEAP, lsl #32
    // 0xb34c84: CheckStackOverflow
    //     0xb34c84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb34c88: cmp             SP, x16
    //     0xb34c8c: b.ls            #0xb34ca0
    // 0xb34c90: r0 = close()
    //     0xb34c90: bl              #0xb34b88  ; [package:flutter/src/material/drawer.dart] DrawerControllerState::close
    // 0xb34c94: LeaveFrame
    //     0xb34c94: mov             SP, fp
    //     0xb34c98: ldp             fp, lr, [SP], #0x10
    // 0xb34c9c: ret
    //     0xb34c9c: ret             
    // 0xb34ca0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb34ca0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb34ca4: b               #0xb34c90
  }
  _ build(/* No info */) {
    // ** addr: 0xd19cc4, size: 0x4c
    // 0xd19cc4: EnterFrame
    //     0xd19cc4: stp             fp, lr, [SP, #-0x10]!
    //     0xd19cc8: mov             fp, SP
    // 0xd19ccc: AllocStack(0x8)
    //     0xd19ccc: sub             SP, SP, #8
    // 0xd19cd0: CheckStackOverflow
    //     0xd19cd0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd19cd4: cmp             SP, x16
    //     0xd19cd8: b.ls            #0xd19d08
    // 0xd19cdc: r0 = _buildDrawer()
    //     0xd19cdc: bl              #0xd1a160  ; [package:flutter/src/material/drawer.dart] DrawerControllerState::_buildDrawer
    // 0xd19ce0: r16 = Instance_ListTileStyle
    //     0xd19ce0: add             x16, PP, #0x99, lsl #12  ; [pp+0x99a90] Obj!ListTileStyle@12c5541
    //     0xd19ce4: ldr             x16, [x16, #0xa90]
    // 0xd19ce8: str             x16, [SP]
    // 0xd19cec: mov             x1, x0
    // 0xd19cf0: r4 = const [0, 0x2, 0x1, 0x1, style, 0x1, null]
    //     0xd19cf0: add             x4, PP, #0x99, lsl #12  ; [pp+0x99a98] List(7) [0, 0x2, 0x1, 0x1, "style", 0x1, Null]
    //     0xd19cf4: ldr             x4, [x4, #0xa98]
    // 0xd19cf8: r0 = merge()
    //     0xd19cf8: bl              #0xd19d10  ; [package:flutter/src/material/list_tile_theme.dart] ListTileTheme::merge
    // 0xd19cfc: LeaveFrame
    //     0xd19cfc: mov             SP, fp
    //     0xd19d00: ldp             fp, lr, [SP], #0x10
    // 0xd19d04: ret
    //     0xd19d04: ret             
    // 0xd19d08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd19d08: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd19d0c: b               #0xd19cdc
  }
  _ _buildDrawer(/* No info */) {
    // ** addr: 0xd1a160, size: 0x6e8
    // 0xd1a160: EnterFrame
    //     0xd1a160: stp             fp, lr, [SP, #-0x10]!
    //     0xd1a164: mov             fp, SP
    // 0xd1a168: AllocStack(0x88)
    //     0xd1a168: sub             SP, SP, #0x88
    // 0xd1a16c: SetupParameters(DrawerControllerState this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xd1a16c: mov             x0, x2
    //     0xd1a170: stur            x2, [fp, #-0x10]
    //     0xd1a174: mov             x2, x1
    //     0xd1a178: stur            x1, [fp, #-8]
    // 0xd1a17c: CheckStackOverflow
    //     0xd1a17c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd1a180: cmp             SP, x16
    //     0xd1a184: b.ls            #0xd1a7ac
    // 0xd1a188: mov             x1, x0
    // 0xd1a18c: r0 = of()
    //     0xd1a18c: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd1a190: ldur            x2, [fp, #-8]
    // 0xd1a194: LoadField: r0 = r2->field_b
    //     0xd1a194: ldur            w0, [x2, #0xb]
    // 0xd1a198: DecompressPointer r0
    //     0xd1a198: add             x0, x0, HEAP, lsl #32
    // 0xd1a19c: cmp             w0, NULL
    // 0xd1a1a0: b.eq            #0xd1a7b4
    // 0xd1a1a4: ldur            x1, [fp, #-0x10]
    // 0xd1a1a8: r0 = of()
    //     0xd1a1a8: bl              #0x87371c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0xd1a1ac: r16 = Instance_TextDirection
    //     0xd1a1ac: ldr             x16, [PP, #0x25b0]  ; [pp+0x25b0] Obj!TextDirection@12c73a1
    // 0xd1a1b0: cmp             w0, w16
    // 0xd1a1b4: b.ne            #0xd1a1f4
    // 0xd1a1b8: ldur            x1, [fp, #-0x10]
    // 0xd1a1bc: r0 = paddingOf()
    //     0xd1a1bc: bl              #0xd1a984  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::paddingOf
    // 0xd1a1c0: LoadField: d0 = r0->field_7
    //     0xd1a1c0: ldur            d0, [x0, #7]
    // 0xd1a1c4: r0 = inline_Allocate_Double()
    //     0xd1a1c4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xd1a1c8: add             x0, x0, #0x10
    //     0xd1a1cc: cmp             x1, x0
    //     0xd1a1d0: b.ls            #0xd1a7b8
    //     0xd1a1d4: str             x0, [THR, #0x60]  ; THR::top
    //     0xd1a1d8: sub             x0, x0, #0xf
    //     0xd1a1dc: mov             x1, #0xe19c
    //     0xd1a1e0: movk            x1, #3, lsl #16
    //     0xd1a1e4: stur            x1, [x0, #-1]
    // 0xd1a1e8: dmb             ishst
    // 0xd1a1ec: StoreField: r0->field_7 = d0
    //     0xd1a1ec: stur            d0, [x0, #7]
    // 0xd1a1f0: b               #0xd1a240
    // 0xd1a1f4: r16 = Instance_TextDirection
    //     0xd1a1f4: ldr             x16, [PP, #0x2578]  ; [pp+0x2578] Obj!TextDirection@12c7381
    // 0xd1a1f8: cmp             w0, w16
    // 0xd1a1fc: b.ne            #0xd1a23c
    // 0xd1a200: ldur            x1, [fp, #-0x10]
    // 0xd1a204: r0 = paddingOf()
    //     0xd1a204: bl              #0xd1a984  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::paddingOf
    // 0xd1a208: ArrayLoad: d0 = r0[0]  ; List_8
    //     0xd1a208: ldur            d0, [x0, #0x17]
    // 0xd1a20c: r0 = inline_Allocate_Double()
    //     0xd1a20c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xd1a210: add             x0, x0, #0x10
    //     0xd1a214: cmp             x1, x0
    //     0xd1a218: b.ls            #0xd1a7c8
    //     0xd1a21c: str             x0, [THR, #0x60]  ; THR::top
    //     0xd1a220: sub             x0, x0, #0xf
    //     0xd1a224: mov             x1, #0xe19c
    //     0xd1a228: movk            x1, #3, lsl #16
    //     0xd1a22c: stur            x1, [x0, #-1]
    // 0xd1a230: dmb             ishst
    // 0xd1a234: StoreField: r0->field_7 = d0
    //     0xd1a234: stur            d0, [x0, #7]
    // 0xd1a238: b               #0xd1a240
    // 0xd1a23c: r0 = Null
    //     0xd1a23c: mov             x0, NULL
    // 0xd1a240: ldur            x2, [fp, #-8]
    // 0xd1a244: d0 = 20.000000
    //     0xd1a244: fmov            d0, #20.00000000
    // 0xd1a248: LoadField: d1 = r0->field_7
    //     0xd1a248: ldur            d1, [x0, #7]
    // 0xd1a24c: fadd            d2, d1, d0
    // 0xd1a250: LoadField: r0 = r2->field_23
    //     0xd1a250: ldur            w0, [x2, #0x23]
    // 0xd1a254: DecompressPointer r0
    //     0xd1a254: add             x0, x0, HEAP, lsl #32
    // 0xd1a258: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd1a25c: cmp             w0, w16
    // 0xd1a260: b.eq            #0xd1a7d8
    // 0xd1a264: LoadField: r1 = r0->field_43
    //     0xd1a264: ldur            w1, [x0, #0x43]
    // 0xd1a268: DecompressPointer r1
    //     0xd1a268: add             x1, x1, HEAP, lsl #32
    // 0xd1a26c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd1a270: cmp             w1, w16
    // 0xd1a274: b.eq            #0xd1a7e4
    // 0xd1a278: r16 = Instance_AnimationStatus
    //     0xd1a278: ldr             x16, [PP, #0x51a8]  ; [pp+0x51a8] Obj!AnimationStatus@12c61c1
    // 0xd1a27c: cmp             w1, w16
    // 0xd1a280: b.ne            #0xd1a3c8
    // 0xd1a284: LoadField: r0 = r2->field_b
    //     0xd1a284: ldur            w0, [x2, #0xb]
    // 0xd1a288: DecompressPointer r0
    //     0xd1a288: add             x0, x0, HEAP, lsl #32
    // 0xd1a28c: cmp             w0, NULL
    // 0xd1a290: b.eq            #0xd1a7ec
    // 0xd1a294: LoadField: r1 = r0->field_f
    //     0xd1a294: ldur            w1, [x0, #0xf]
    // 0xd1a298: DecompressPointer r1
    //     0xd1a298: add             x1, x1, HEAP, lsl #32
    // 0xd1a29c: LoadField: r0 = r1->field_7
    //     0xd1a29c: ldur            x0, [x1, #7]
    // 0xd1a2a0: cmp             x0, #0
    // 0xd1a2a4: b.gt            #0xd1a2b4
    // 0xd1a2a8: r0 = Instance_AlignmentDirectional
    //     0xd1a2a8: add             x0, PP, #0x28, lsl #12  ; [pp+0x28258] Obj!AlignmentDirectional@129e651
    //     0xd1a2ac: ldr             x0, [x0, #0x258]
    // 0xd1a2b0: b               #0xd1a2bc
    // 0xd1a2b4: r0 = Instance_AlignmentDirectional
    //     0xd1a2b4: add             x0, PP, #0x99, lsl #12  ; [pp+0x99aa0] Obj!AlignmentDirectional@129e631
    //     0xd1a2b8: ldr             x0, [x0, #0xaa0]
    // 0xd1a2bc: stur            x0, [fp, #-0x28]
    // 0xd1a2c0: LoadField: r1 = r2->field_2f
    //     0xd1a2c0: ldur            w1, [x2, #0x2f]
    // 0xd1a2c4: DecompressPointer r1
    //     0xd1a2c4: add             x1, x1, HEAP, lsl #32
    // 0xd1a2c8: stur            x1, [fp, #-0x20]
    // 0xd1a2cc: r3 = inline_Allocate_Double()
    //     0xd1a2cc: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0xd1a2d0: add             x3, x3, #0x10
    //     0xd1a2d4: cmp             x4, x3
    //     0xd1a2d8: b.ls            #0xd1a7f0
    //     0xd1a2dc: str             x3, [THR, #0x60]  ; THR::top
    //     0xd1a2e0: sub             x3, x3, #0xf
    //     0xd1a2e4: mov             x4, #0xe19c
    //     0xd1a2e8: movk            x4, #3, lsl #16
    //     0xd1a2ec: stur            x4, [x3, #-1]
    // 0xd1a2f0: dmb             ishst
    // 0xd1a2f4: StoreField: r3->field_7 = d2
    //     0xd1a2f4: stur            d2, [x3, #7]
    // 0xd1a2f8: stur            x3, [fp, #-0x18]
    // 0xd1a2fc: r0 = SizedBox()
    //     0xd1a2fc: bl              #0x8a7210  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0xd1a300: mov             x1, x0
    // 0xd1a304: ldur            x0, [fp, #-0x18]
    // 0xd1a308: stur            x1, [fp, #-0x30]
    // 0xd1a30c: StoreField: r1->field_f = r0
    //     0xd1a30c: stur            w0, [x1, #0xf]
    // 0xd1a310: r0 = inf
    //     0xd1a310: add             x0, PP, #0x15, lsl #12  ; [pp+0x158a8] inf
    //     0xd1a314: ldr             x0, [x0, #0x8a8]
    // 0xd1a318: StoreField: r1->field_13 = r0
    //     0xd1a318: stur            w0, [x1, #0x13]
    // 0xd1a31c: r0 = LimitedBox()
    //     0xd1a31c: bl              #0xd1a978  ; AllocateLimitedBoxStub -> LimitedBox (size=0x20)
    // 0xd1a320: d0 = inf
    //     0xd1a320: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xd1a324: stur            x0, [fp, #-0x18]
    // 0xd1a328: StoreField: r0->field_f = d0
    //     0xd1a328: stur            d0, [x0, #0xf]
    // 0xd1a32c: ArrayStore: r0[0] = rZR  ; List_8
    //     0xd1a32c: stur            xzr, [x0, #0x17]
    // 0xd1a330: ldur            x1, [fp, #-0x30]
    // 0xd1a334: StoreField: r0->field_b = r1
    //     0xd1a334: stur            w1, [x0, #0xb]
    // 0xd1a338: ldur            x2, [fp, #-8]
    // 0xd1a33c: r1 = Function '_move@82517151':.
    //     0xd1a33c: add             x1, PP, #0x99, lsl #12  ; [pp+0x99aa8] AnonymousClosure: (0xd1b24c), in [package:flutter/src/material/drawer.dart] DrawerControllerState::_move (0xd1b288)
    //     0xd1a340: ldr             x1, [x1, #0xaa8]
    // 0xd1a344: r0 = AllocateClosure()
    //     0xd1a344: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd1a348: ldur            x2, [fp, #-8]
    // 0xd1a34c: r1 = Function '_settle@82517151':.
    //     0xd1a34c: add             x1, PP, #0x99, lsl #12  ; [pp+0x99ab0] AnonymousClosure: (0xd1ae58), in [package:flutter/src/material/drawer.dart] DrawerControllerState::_settle (0xd1ae94)
    //     0xd1a350: ldr             x1, [x1, #0xab0]
    // 0xd1a354: stur            x0, [fp, #-0x30]
    // 0xd1a358: r0 = AllocateClosure()
    //     0xd1a358: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd1a35c: stur            x0, [fp, #-0x38]
    // 0xd1a360: r0 = GestureDetector()
    //     0xd1a360: bl              #0x918e18  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0xd1a364: stur            x0, [fp, #-0x40]
    // 0xd1a368: ldur            x16, [fp, #-0x20]
    // 0xd1a36c: ldur            lr, [fp, #-0x30]
    // 0xd1a370: stp             lr, x16, [SP, #0x20]
    // 0xd1a374: ldur            x16, [fp, #-0x38]
    // 0xd1a378: r30 = Instance_HitTestBehavior
    //     0xd1a378: add             lr, PP, #0x15, lsl #12  ; [pp+0x15508] Obj!HitTestBehavior@12c43e1
    //     0xd1a37c: ldr             lr, [lr, #0x508]
    // 0xd1a380: stp             lr, x16, [SP, #0x10]
    // 0xd1a384: r16 = true
    //     0xd1a384: add             x16, NULL, #0x20  ; true
    // 0xd1a388: ldur            lr, [fp, #-0x18]
    // 0xd1a38c: stp             lr, x16, [SP]
    // 0xd1a390: mov             x1, x0
    // 0xd1a394: r4 = const [0, 0x7, 0x6, 0x1, behavior, 0x4, child, 0x6, excludeFromSemantics, 0x5, key, 0x1, onHorizontalDragEnd, 0x3, onHorizontalDragUpdate, 0x2, null]
    //     0xd1a394: add             x4, PP, #0x99, lsl #12  ; [pp+0x99ab8] List(17) [0, 0x7, 0x6, 0x1, "behavior", 0x4, "child", 0x6, "excludeFromSemantics", 0x5, "key", 0x1, "onHorizontalDragEnd", 0x3, "onHorizontalDragUpdate", 0x2, Null]
    //     0xd1a398: ldr             x4, [x4, #0xab8]
    // 0xd1a39c: r0 = GestureDetector()
    //     0xd1a39c: bl              #0x9182dc  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0xd1a3a0: r0 = Align()
    //     0xd1a3a0: bl              #0xb281f8  ; AllocateAlignStub -> Align (size=0x1c)
    // 0xd1a3a4: mov             x1, x0
    // 0xd1a3a8: ldur            x0, [fp, #-0x28]
    // 0xd1a3ac: StoreField: r1->field_f = r0
    //     0xd1a3ac: stur            w0, [x1, #0xf]
    // 0xd1a3b0: ldur            x0, [fp, #-0x40]
    // 0xd1a3b4: StoreField: r1->field_b = r0
    //     0xd1a3b4: stur            w0, [x1, #0xb]
    // 0xd1a3b8: mov             x0, x1
    // 0xd1a3bc: LeaveFrame
    //     0xd1a3bc: mov             SP, fp
    //     0xd1a3c0: ldp             fp, lr, [SP], #0x10
    // 0xd1a3c4: ret
    //     0xd1a3c4: ret             
    // 0xd1a3c8: LoadField: r0 = r2->field_b
    //     0xd1a3c8: ldur            w0, [x2, #0xb]
    // 0xd1a3cc: DecompressPointer r0
    //     0xd1a3cc: add             x0, x0, HEAP, lsl #32
    // 0xd1a3d0: cmp             w0, NULL
    // 0xd1a3d4: b.eq            #0xd1a814
    // 0xd1a3d8: ldur            x1, [fp, #-0x10]
    // 0xd1a3dc: r0 = of()
    //     0xd1a3dc: bl              #0xd1a920  ; [package:flutter/src/material/drawer_theme.dart] DrawerTheme::of
    // 0xd1a3e0: r1 = Instance_Color
    //     0xd1a3e0: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c78] Obj!Color@12a1741
    //     0xd1a3e4: ldr             x1, [x1, #0xc78]
    // 0xd1a3e8: LoadField: d0 = r1->field_7
    //     0xd1a3e8: ldur            d0, [x1, #7]
    // 0xd1a3ec: ldur            x2, [fp, #-8]
    // 0xd1a3f0: LoadField: r0 = r2->field_23
    //     0xd1a3f0: ldur            w0, [x2, #0x23]
    // 0xd1a3f4: DecompressPointer r0
    //     0xd1a3f4: add             x0, x0, HEAP, lsl #32
    // 0xd1a3f8: LoadField: r3 = r0->field_37
    //     0xd1a3f8: ldur            w3, [x0, #0x37]
    // 0xd1a3fc: DecompressPointer r3
    //     0xd1a3fc: add             x3, x3, HEAP, lsl #32
    // 0xd1a400: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd1a404: cmp             w3, w16
    // 0xd1a408: b.eq            #0xd1a818
    // 0xd1a40c: LoadField: d1 = r3->field_7
    //     0xd1a40c: ldur            d1, [x3, #7]
    // 0xd1a410: fmul            d2, d0, d1
    // 0xd1a414: r0 = inline_Allocate_Double()
    //     0xd1a414: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0xd1a418: add             x0, x0, #0x10
    //     0xd1a41c: cmp             x3, x0
    //     0xd1a420: b.ls            #0xd1a820
    //     0xd1a424: str             x0, [THR, #0x60]  ; THR::top
    //     0xd1a428: sub             x0, x0, #0xf
    //     0xd1a42c: mov             x3, #0xe19c
    //     0xd1a430: movk            x3, #3, lsl #16
    //     0xd1a434: stur            x3, [x0, #-1]
    // 0xd1a438: dmb             ishst
    // 0xd1a43c: StoreField: r0->field_7 = d2
    //     0xd1a43c: stur            d2, [x0, #7]
    // 0xd1a440: str             x0, [SP]
    // 0xd1a444: r4 = const [0, 0x2, 0x1, 0x1, alpha, 0x1, null]
    //     0xd1a444: add             x4, PP, #0x28, lsl #12  ; [pp+0x28640] List(7) [0, 0x2, 0x1, 0x1, "alpha", 0x1, Null]
    //     0xd1a448: ldr             x4, [x4, #0x640]
    // 0xd1a44c: r0 = withValues()
    //     0xd1a44c: bl              #0x12d8818  ; [dart:ui] Color::withValues
    // 0xd1a450: stur            x0, [fp, #-0x18]
    // 0xd1a454: r0 = ColoredBox()
    //     0xd1a454: bl              #0xd1a914  ; AllocateColoredBoxStub -> ColoredBox (size=0x18)
    // 0xd1a458: mov             x2, x0
    // 0xd1a45c: ldur            x0, [fp, #-0x18]
    // 0xd1a460: stur            x2, [fp, #-0x20]
    // 0xd1a464: StoreField: r2->field_f = r0
    //     0xd1a464: stur            w0, [x2, #0xf]
    // 0xd1a468: r0 = true
    //     0xd1a468: add             x0, NULL, #0x20  ; true
    // 0xd1a46c: StoreField: r2->field_13 = r0
    //     0xd1a46c: stur            w0, [x2, #0x13]
    // 0xd1a470: r1 = Instance_LimitedBox
    //     0xd1a470: add             x1, PP, #0x99, lsl #12  ; [pp+0x99ac0] Obj!LimitedBox@12b70a1
    //     0xd1a474: ldr             x1, [x1, #0xac0]
    // 0xd1a478: StoreField: r2->field_b = r1
    //     0xd1a478: stur            w1, [x2, #0xb]
    // 0xd1a47c: ldur            x3, [fp, #-8]
    // 0xd1a480: LoadField: r4 = r3->field_b
    //     0xd1a480: ldur            w4, [x3, #0xb]
    // 0xd1a484: DecompressPointer r4
    //     0xd1a484: add             x4, x4, HEAP, lsl #32
    // 0xd1a488: stur            x4, [fp, #-0x18]
    // 0xd1a48c: cmp             w4, NULL
    // 0xd1a490: b.eq            #0xd1a838
    // 0xd1a494: ldur            x1, [fp, #-0x10]
    // 0xd1a498: r0 = of()
    //     0xd1a498: bl              #0xd0bbf8  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0xd1a49c: r1 = LoadClassIdInstr(r0)
    //     0xd1a49c: ldur            x1, [x0, #-1]
    //     0xd1a4a0: ubfx            x1, x1, #0xc, #0x14
    // 0xd1a4a4: mov             x16, x0
    // 0xd1a4a8: mov             x0, x1
    // 0xd1a4ac: mov             x1, x16
    // 0xd1a4b0: r0 = GDT[cid_x0 + 0x173c8]()
    //     0xd1a4b0: mov             x17, #0x73c8
    //     0xd1a4b4: movk            x17, #1, lsl #16
    //     0xd1a4b8: add             lr, x0, x17
    //     0xd1a4bc: ldr             lr, [x21, lr, lsl #3]
    //     0xd1a4c0: blr             lr
    // 0xd1a4c4: stur            x0, [fp, #-0x10]
    // 0xd1a4c8: r0 = Semantics()
    //     0xd1a4c8: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xd1a4cc: stur            x0, [fp, #-0x28]
    // 0xd1a4d0: ldur            x16, [fp, #-0x10]
    // 0xd1a4d4: ldur            lr, [fp, #-0x20]
    // 0xd1a4d8: stp             lr, x16, [SP]
    // 0xd1a4dc: mov             x1, x0
    // 0xd1a4e0: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, label, 0x1, null]
    //     0xd1a4e0: add             x4, PP, #0x80, lsl #12  ; [pp+0x80e10] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "label", 0x1, Null]
    //     0xd1a4e4: ldr             x4, [x4, #0xe10]
    // 0xd1a4e8: r0 = Semantics()
    //     0xd1a4e8: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xd1a4ec: r0 = GestureDetector()
    //     0xd1a4ec: bl              #0x918e18  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0xd1a4f0: ldur            x2, [fp, #-8]
    // 0xd1a4f4: r1 = Function 'close':.
    //     0xd1a4f4: add             x1, PP, #0x99, lsl #12  ; [pp+0x99ac8] AnonymousClosure: (0xb34c70), in [package:flutter/src/material/drawer.dart] DrawerControllerState::close (0xb34b88)
    //     0xd1a4f8: ldr             x1, [x1, #0xac8]
    // 0xd1a4fc: stur            x0, [fp, #-0x10]
    // 0xd1a500: r0 = AllocateClosure()
    //     0xd1a500: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd1a504: ldur            x16, [fp, #-0x28]
    // 0xd1a508: stp             x16, x0, [SP]
    // 0xd1a50c: ldur            x1, [fp, #-0x10]
    // 0xd1a510: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, onTap, 0x1, null]
    //     0xd1a510: add             x4, PP, #0x16, lsl #12  ; [pp+0x16e90] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0xd1a514: ldr             x4, [x4, #0xe90]
    // 0xd1a518: r0 = GestureDetector()
    //     0xd1a518: bl              #0x9182dc  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0xd1a51c: r0 = ExcludeSemantics()
    //     0xd1a51c: bl              #0x86a6ac  ; AllocateExcludeSemanticsStub -> ExcludeSemantics (size=0x14)
    // 0xd1a520: mov             x1, x0
    // 0xd1a524: r0 = true
    //     0xd1a524: add             x0, NULL, #0x20  ; true
    // 0xd1a528: stur            x1, [fp, #-0x20]
    // 0xd1a52c: StoreField: r1->field_f = r0
    //     0xd1a52c: stur            w0, [x1, #0xf]
    // 0xd1a530: ldur            x2, [fp, #-0x10]
    // 0xd1a534: StoreField: r1->field_b = r2
    //     0xd1a534: stur            w2, [x1, #0xb]
    // 0xd1a538: r0 = BlockSemantics()
    //     0xd1a538: bl              #0xd1a908  ; AllocateBlockSemanticsStub -> BlockSemantics (size=0x14)
    // 0xd1a53c: mov             x2, x0
    // 0xd1a540: r0 = true
    //     0xd1a540: add             x0, NULL, #0x20  ; true
    // 0xd1a544: stur            x2, [fp, #-0x10]
    // 0xd1a548: StoreField: r2->field_f = r0
    //     0xd1a548: stur            w0, [x2, #0xf]
    // 0xd1a54c: ldur            x1, [fp, #-0x20]
    // 0xd1a550: StoreField: r2->field_b = r1
    //     0xd1a550: stur            w1, [x2, #0xb]
    // 0xd1a554: ldur            x1, [fp, #-8]
    // 0xd1a558: r0 = _drawerOuterAlignment()
    //     0xd1a558: bl              #0xd1a8c0  ; [package:flutter/src/material/drawer.dart] DrawerControllerState::_drawerOuterAlignment
    // 0xd1a55c: ldur            x1, [fp, #-8]
    // 0xd1a560: stur            x0, [fp, #-0x20]
    // 0xd1a564: r0 = _drawerInnerAlignment()
    //     0xd1a564: bl              #0xd1a878  ; [package:flutter/src/material/drawer.dart] DrawerControllerState::_drawerInnerAlignment
    // 0xd1a568: ldur            x2, [fp, #-8]
    // 0xd1a56c: stur            x0, [fp, #-0x48]
    // 0xd1a570: LoadField: r1 = r2->field_23
    //     0xd1a570: ldur            w1, [x2, #0x23]
    // 0xd1a574: DecompressPointer r1
    //     0xd1a574: add             x1, x1, HEAP, lsl #32
    // 0xd1a578: LoadField: r3 = r1->field_37
    //     0xd1a578: ldur            w3, [x1, #0x37]
    // 0xd1a57c: DecompressPointer r3
    //     0xd1a57c: add             x3, x3, HEAP, lsl #32
    // 0xd1a580: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd1a584: cmp             w3, w16
    // 0xd1a588: b.eq            #0xd1a83c
    // 0xd1a58c: stur            x3, [fp, #-0x40]
    // 0xd1a590: LoadField: r1 = r2->field_27
    //     0xd1a590: ldur            w1, [x2, #0x27]
    // 0xd1a594: DecompressPointer r1
    //     0xd1a594: add             x1, x1, HEAP, lsl #32
    // 0xd1a598: stur            x1, [fp, #-0x38]
    // 0xd1a59c: LoadField: r4 = r2->field_1f
    //     0xd1a59c: ldur            w4, [x2, #0x1f]
    // 0xd1a5a0: DecompressPointer r4
    //     0xd1a5a0: add             x4, x4, HEAP, lsl #32
    // 0xd1a5a4: stur            x4, [fp, #-0x30]
    // 0xd1a5a8: LoadField: r5 = r2->field_b
    //     0xd1a5a8: ldur            w5, [x2, #0xb]
    // 0xd1a5ac: DecompressPointer r5
    //     0xd1a5ac: add             x5, x5, HEAP, lsl #32
    // 0xd1a5b0: cmp             w5, NULL
    // 0xd1a5b4: b.eq            #0xd1a844
    // 0xd1a5b8: LoadField: r6 = r5->field_b
    //     0xd1a5b8: ldur            w6, [x5, #0xb]
    // 0xd1a5bc: DecompressPointer r6
    //     0xd1a5bc: add             x6, x6, HEAP, lsl #32
    // 0xd1a5c0: stur            x6, [fp, #-0x28]
    // 0xd1a5c4: r0 = FocusScope()
    //     0xd1a5c4: bl              #0xd1a86c  ; AllocateFocusScopeStub -> FocusScope (size=0x40)
    // 0xd1a5c8: mov             x1, x0
    // 0xd1a5cc: ldur            x0, [fp, #-0x28]
    // 0xd1a5d0: stur            x1, [fp, #-0x50]
    // 0xd1a5d4: StoreField: r1->field_f = r0
    //     0xd1a5d4: stur            w0, [x1, #0xf]
    // 0xd1a5d8: ldur            x0, [fp, #-0x30]
    // 0xd1a5dc: StoreField: r1->field_13 = r0
    //     0xd1a5dc: stur            w0, [x1, #0x13]
    // 0xd1a5e0: r0 = false
    //     0xd1a5e0: add             x0, NULL, #0x30  ; false
    // 0xd1a5e4: ArrayStore: r1[0] = r0  ; List_4
    //     0xd1a5e4: stur            w0, [x1, #0x17]
    // 0xd1a5e8: r0 = true
    //     0xd1a5e8: add             x0, NULL, #0x20  ; true
    // 0xd1a5ec: StoreField: r1->field_37 = r0
    //     0xd1a5ec: stur            w0, [x1, #0x37]
    // 0xd1a5f0: ldur            x0, [fp, #-0x38]
    // 0xd1a5f4: StoreField: r1->field_7 = r0
    //     0xd1a5f4: stur            w0, [x1, #7]
    // 0xd1a5f8: r0 = RepaintBoundary()
    //     0xd1a5f8: bl              #0xd1a860  ; AllocateRepaintBoundaryStub -> RepaintBoundary (size=0x10)
    // 0xd1a5fc: mov             x1, x0
    // 0xd1a600: ldur            x0, [fp, #-0x50]
    // 0xd1a604: stur            x1, [fp, #-0x28]
    // 0xd1a608: StoreField: r1->field_b = r0
    //     0xd1a608: stur            w0, [x1, #0xb]
    // 0xd1a60c: r0 = Align()
    //     0xd1a60c: bl              #0xb281f8  ; AllocateAlignStub -> Align (size=0x1c)
    // 0xd1a610: mov             x1, x0
    // 0xd1a614: ldur            x0, [fp, #-0x48]
    // 0xd1a618: stur            x1, [fp, #-0x30]
    // 0xd1a61c: StoreField: r1->field_f = r0
    //     0xd1a61c: stur            w0, [x1, #0xf]
    // 0xd1a620: ldur            x0, [fp, #-0x40]
    // 0xd1a624: StoreField: r1->field_13 = r0
    //     0xd1a624: stur            w0, [x1, #0x13]
    // 0xd1a628: ldur            x0, [fp, #-0x28]
    // 0xd1a62c: StoreField: r1->field_b = r0
    //     0xd1a62c: stur            w0, [x1, #0xb]
    // 0xd1a630: r0 = Align()
    //     0xd1a630: bl              #0xb281f8  ; AllocateAlignStub -> Align (size=0x1c)
    // 0xd1a634: mov             x3, x0
    // 0xd1a638: ldur            x0, [fp, #-0x20]
    // 0xd1a63c: stur            x3, [fp, #-0x28]
    // 0xd1a640: StoreField: r3->field_f = r0
    //     0xd1a640: stur            w0, [x3, #0xf]
    // 0xd1a644: ldur            x0, [fp, #-0x30]
    // 0xd1a648: StoreField: r3->field_b = r0
    //     0xd1a648: stur            w0, [x3, #0xb]
    // 0xd1a64c: r1 = Null
    //     0xd1a64c: mov             x1, NULL
    // 0xd1a650: r2 = 4
    //     0xd1a650: mov             x2, #4
    // 0xd1a654: r0 = AllocateArray()
    //     0xd1a654: bl              #0x13df928  ; AllocateArrayStub
    // 0xd1a658: mov             x2, x0
    // 0xd1a65c: ldur            x0, [fp, #-0x10]
    // 0xd1a660: stur            x2, [fp, #-0x20]
    // 0xd1a664: StoreField: r2->field_f = r0
    //     0xd1a664: stur            w0, [x2, #0xf]
    // 0xd1a668: ldur            x0, [fp, #-0x28]
    // 0xd1a66c: StoreField: r2->field_13 = r0
    //     0xd1a66c: stur            w0, [x2, #0x13]
    // 0xd1a670: r1 = <Widget>
    //     0xd1a670: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xd1a674: r0 = AllocateGrowableArray()
    //     0xd1a674: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xd1a678: mov             x1, x0
    // 0xd1a67c: ldur            x0, [fp, #-0x20]
    // 0xd1a680: stur            x1, [fp, #-0x10]
    // 0xd1a684: StoreField: r1->field_f = r0
    //     0xd1a684: stur            w0, [x1, #0xf]
    // 0xd1a688: r0 = 4
    //     0xd1a688: mov             x0, #4
    // 0xd1a68c: StoreField: r1->field_b = r0
    //     0xd1a68c: stur            w0, [x1, #0xb]
    // 0xd1a690: r0 = Stack()
    //     0xd1a690: bl              #0xd1a854  ; AllocateStackStub -> Stack (size=0x20)
    // 0xd1a694: mov             x1, x0
    // 0xd1a698: r0 = Instance_AlignmentDirectional
    //     0xd1a698: add             x0, PP, #0x15, lsl #12  ; [pp+0x158d8] Obj!AlignmentDirectional@129e611
    //     0xd1a69c: ldr             x0, [x0, #0x8d8]
    // 0xd1a6a0: stur            x1, [fp, #-0x20]
    // 0xd1a6a4: StoreField: r1->field_f = r0
    //     0xd1a6a4: stur            w0, [x1, #0xf]
    // 0xd1a6a8: r0 = Instance_StackFit
    //     0xd1a6a8: add             x0, PP, #0x15, lsl #12  ; [pp+0x158e0] Obj!StackFit@12c4221
    //     0xd1a6ac: ldr             x0, [x0, #0x8e0]
    // 0xd1a6b0: ArrayStore: r1[0] = r0  ; List_4
    //     0xd1a6b0: stur            w0, [x1, #0x17]
    // 0xd1a6b4: r0 = Instance_Clip
    //     0xd1a6b4: add             x0, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xd1a6b8: ldr             x0, [x0, #0x850]
    // 0xd1a6bc: StoreField: r1->field_1b = r0
    //     0xd1a6bc: stur            w0, [x1, #0x1b]
    // 0xd1a6c0: ldur            x0, [fp, #-0x10]
    // 0xd1a6c4: StoreField: r1->field_b = r0
    //     0xd1a6c4: stur            w0, [x1, #0xb]
    // 0xd1a6c8: r0 = RepaintBoundary()
    //     0xd1a6c8: bl              #0xd1a860  ; AllocateRepaintBoundaryStub -> RepaintBoundary (size=0x10)
    // 0xd1a6cc: mov             x1, x0
    // 0xd1a6d0: ldur            x0, [fp, #-0x20]
    // 0xd1a6d4: stur            x1, [fp, #-0x10]
    // 0xd1a6d8: StoreField: r1->field_b = r0
    //     0xd1a6d8: stur            w0, [x1, #0xb]
    // 0xd1a6dc: r0 = _DrawerControllerScope()
    //     0xd1a6dc: bl              #0xd1a848  ; Allocate_DrawerControllerScopeStub -> _DrawerControllerScope (size=0x14)
    // 0xd1a6e0: mov             x3, x0
    // 0xd1a6e4: ldur            x0, [fp, #-0x18]
    // 0xd1a6e8: stur            x3, [fp, #-0x20]
    // 0xd1a6ec: StoreField: r3->field_f = r0
    //     0xd1a6ec: stur            w0, [x3, #0xf]
    // 0xd1a6f0: ldur            x0, [fp, #-0x10]
    // 0xd1a6f4: StoreField: r3->field_b = r0
    //     0xd1a6f4: stur            w0, [x3, #0xb]
    // 0xd1a6f8: ldur            x0, [fp, #-8]
    // 0xd1a6fc: LoadField: r4 = r0->field_2f
    //     0xd1a6fc: ldur            w4, [x0, #0x2f]
    // 0xd1a700: DecompressPointer r4
    //     0xd1a700: add             x4, x4, HEAP, lsl #32
    // 0xd1a704: mov             x2, x0
    // 0xd1a708: stur            x4, [fp, #-0x10]
    // 0xd1a70c: r1 = Function '_handleDragDown@82517151':.
    //     0xd1a70c: add             x1, PP, #0x99, lsl #12  ; [pp+0x99ad0] AnonymousClosure: (0xd1ab80), in [package:flutter/src/material/drawer.dart] DrawerControllerState::_handleDragDown (0xd1abbc)
    //     0xd1a710: ldr             x1, [x1, #0xad0]
    // 0xd1a714: r0 = AllocateClosure()
    //     0xd1a714: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd1a718: ldur            x2, [fp, #-8]
    // 0xd1a71c: r1 = Function '_move@82517151':.
    //     0xd1a71c: add             x1, PP, #0x99, lsl #12  ; [pp+0x99aa8] AnonymousClosure: (0xd1b24c), in [package:flutter/src/material/drawer.dart] DrawerControllerState::_move (0xd1b288)
    //     0xd1a720: ldr             x1, [x1, #0xaa8]
    // 0xd1a724: stur            x0, [fp, #-0x18]
    // 0xd1a728: r0 = AllocateClosure()
    //     0xd1a728: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd1a72c: ldur            x2, [fp, #-8]
    // 0xd1a730: r1 = Function '_settle@82517151':.
    //     0xd1a730: add             x1, PP, #0x99, lsl #12  ; [pp+0x99ab0] AnonymousClosure: (0xd1ae58), in [package:flutter/src/material/drawer.dart] DrawerControllerState::_settle (0xd1ae94)
    //     0xd1a734: ldr             x1, [x1, #0xab0]
    // 0xd1a738: stur            x0, [fp, #-0x28]
    // 0xd1a73c: r0 = AllocateClosure()
    //     0xd1a73c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd1a740: ldur            x2, [fp, #-8]
    // 0xd1a744: r1 = Function '_handleDragCancel@82517151':.
    //     0xd1a744: add             x1, PP, #0x99, lsl #12  ; [pp+0x99ad8] AnonymousClosure: (0xd1a9d0), in [package:flutter/src/material/drawer.dart] DrawerControllerState::_handleDragCancel (0xd1aa08)
    //     0xd1a748: ldr             x1, [x1, #0xad8]
    // 0xd1a74c: stur            x0, [fp, #-8]
    // 0xd1a750: r0 = AllocateClosure()
    //     0xd1a750: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd1a754: stur            x0, [fp, #-0x30]
    // 0xd1a758: r0 = GestureDetector()
    //     0xd1a758: bl              #0x918e18  ; AllocateGestureDetectorStub -> GestureDetector (size=0x10c)
    // 0xd1a75c: stur            x0, [fp, #-0x38]
    // 0xd1a760: ldur            x16, [fp, #-0x10]
    // 0xd1a764: ldur            lr, [fp, #-0x18]
    // 0xd1a768: stp             lr, x16, [SP, #0x28]
    // 0xd1a76c: ldur            x16, [fp, #-0x28]
    // 0xd1a770: ldur            lr, [fp, #-8]
    // 0xd1a774: stp             lr, x16, [SP, #0x18]
    // 0xd1a778: ldur            x16, [fp, #-0x30]
    // 0xd1a77c: r30 = true
    //     0xd1a77c: add             lr, NULL, #0x20  ; true
    // 0xd1a780: stp             lr, x16, [SP, #8]
    // 0xd1a784: ldur            x16, [fp, #-0x20]
    // 0xd1a788: str             x16, [SP]
    // 0xd1a78c: mov             x1, x0
    // 0xd1a790: r4 = const [0, 0x8, 0x7, 0x1, child, 0x7, excludeFromSemantics, 0x6, key, 0x1, onHorizontalDragCancel, 0x5, onHorizontalDragDown, 0x2, onHorizontalDragEnd, 0x4, onHorizontalDragUpdate, 0x3, null]
    //     0xd1a790: add             x4, PP, #0x99, lsl #12  ; [pp+0x99ae0] List(19) [0, 0x8, 0x7, 0x1, "child", 0x7, "excludeFromSemantics", 0x6, "key", 0x1, "onHorizontalDragCancel", 0x5, "onHorizontalDragDown", 0x2, "onHorizontalDragEnd", 0x4, "onHorizontalDragUpdate", 0x3, Null]
    //     0xd1a794: ldr             x4, [x4, #0xae0]
    // 0xd1a798: r0 = GestureDetector()
    //     0xd1a798: bl              #0x9182dc  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0xd1a79c: ldur            x0, [fp, #-0x38]
    // 0xd1a7a0: LeaveFrame
    //     0xd1a7a0: mov             SP, fp
    //     0xd1a7a4: ldp             fp, lr, [SP], #0x10
    // 0xd1a7a8: ret
    //     0xd1a7a8: ret             
    // 0xd1a7ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1a7ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd1a7b0: b               #0xd1a188
    // 0xd1a7b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1a7b4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1a7b8: SaveReg d0
    //     0xd1a7b8: str             q0, [SP, #-0x10]!
    // 0xd1a7bc: r0 = AllocateDouble()
    //     0xd1a7bc: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd1a7c0: RestoreReg d0
    //     0xd1a7c0: ldr             q0, [SP], #0x10
    // 0xd1a7c4: b               #0xd1a1ec
    // 0xd1a7c8: SaveReg d0
    //     0xd1a7c8: str             q0, [SP, #-0x10]!
    // 0xd1a7cc: r0 = AllocateDouble()
    //     0xd1a7cc: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd1a7d0: RestoreReg d0
    //     0xd1a7d0: ldr             q0, [SP], #0x10
    // 0xd1a7d4: b               #0xd1a234
    // 0xd1a7d8: r9 = _controller
    //     0xd1a7d8: add             x9, PP, #0x83, lsl #12  ; [pp+0x837c0] Field <DrawerControllerState._controller@82517151>: late (offset: 0x24)
    //     0xd1a7dc: ldr             x9, [x9, #0x7c0]
    // 0xd1a7e0: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xd1a7e0: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xd1a7e4: r9 = _status
    //     0xd1a7e4: ldr             x9, [PP, #0x51e8]  ; [pp+0x51e8] Field <AnimationController._status@62066280>: late (offset: 0x44)
    // 0xd1a7e8: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xd1a7e8: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xd1a7ec: r0 = NullCastErrorSharedWithFPURegs()
    //     0xd1a7ec: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xd1a7f0: SaveReg d2
    //     0xd1a7f0: str             q2, [SP, #-0x10]!
    // 0xd1a7f4: stp             x1, x2, [SP, #-0x10]!
    // 0xd1a7f8: SaveReg r0
    //     0xd1a7f8: str             x0, [SP, #-8]!
    // 0xd1a7fc: r0 = AllocateDouble()
    //     0xd1a7fc: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd1a800: mov             x3, x0
    // 0xd1a804: RestoreReg r0
    //     0xd1a804: ldr             x0, [SP], #8
    // 0xd1a808: ldp             x1, x2, [SP], #0x10
    // 0xd1a80c: RestoreReg d2
    //     0xd1a80c: ldr             q2, [SP], #0x10
    // 0xd1a810: b               #0xd1a2f4
    // 0xd1a814: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1a814: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1a818: r9 = _value
    //     0xd1a818: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0xd1a81c: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xd1a81c: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xd1a820: SaveReg d2
    //     0xd1a820: str             q2, [SP, #-0x10]!
    // 0xd1a824: stp             x1, x2, [SP, #-0x10]!
    // 0xd1a828: r0 = AllocateDouble()
    //     0xd1a828: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd1a82c: ldp             x1, x2, [SP], #0x10
    // 0xd1a830: RestoreReg d2
    //     0xd1a830: ldr             q2, [SP], #0x10
    // 0xd1a834: b               #0xd1a43c
    // 0xd1a838: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1a838: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1a83c: r9 = _value
    //     0xd1a83c: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0xd1a840: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd1a840: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd1a844: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1a844: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _drawerInnerAlignment(/* No info */) {
    // ** addr: 0xd1a878, size: 0x48
    // 0xd1a878: LoadField: r2 = r1->field_b
    //     0xd1a878: ldur            w2, [x1, #0xb]
    // 0xd1a87c: DecompressPointer r2
    //     0xd1a87c: add             x2, x2, HEAP, lsl #32
    // 0xd1a880: cmp             w2, NULL
    // 0xd1a884: b.eq            #0xd1a8b4
    // 0xd1a888: LoadField: r1 = r2->field_f
    //     0xd1a888: ldur            w1, [x2, #0xf]
    // 0xd1a88c: DecompressPointer r1
    //     0xd1a88c: add             x1, x1, HEAP, lsl #32
    // 0xd1a890: LoadField: r2 = r1->field_7
    //     0xd1a890: ldur            x2, [x1, #7]
    // 0xd1a894: cmp             x2, #0
    // 0xd1a898: b.gt            #0xd1a8a8
    // 0xd1a89c: r0 = Instance_AlignmentDirectional
    //     0xd1a89c: add             x0, PP, #0x99, lsl #12  ; [pp+0x99aa0] Obj!AlignmentDirectional@129e631
    //     0xd1a8a0: ldr             x0, [x0, #0xaa0]
    // 0xd1a8a4: b               #0xd1a8b0
    // 0xd1a8a8: r0 = Instance_AlignmentDirectional
    //     0xd1a8a8: add             x0, PP, #0x28, lsl #12  ; [pp+0x28258] Obj!AlignmentDirectional@129e651
    //     0xd1a8ac: ldr             x0, [x0, #0x258]
    // 0xd1a8b0: ret
    //     0xd1a8b0: ret             
    // 0xd1a8b4: EnterFrame
    //     0xd1a8b4: stp             fp, lr, [SP, #-0x10]!
    //     0xd1a8b8: mov             fp, SP
    // 0xd1a8bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1a8bc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _drawerOuterAlignment(/* No info */) {
    // ** addr: 0xd1a8c0, size: 0x48
    // 0xd1a8c0: LoadField: r2 = r1->field_b
    //     0xd1a8c0: ldur            w2, [x1, #0xb]
    // 0xd1a8c4: DecompressPointer r2
    //     0xd1a8c4: add             x2, x2, HEAP, lsl #32
    // 0xd1a8c8: cmp             w2, NULL
    // 0xd1a8cc: b.eq            #0xd1a8fc
    // 0xd1a8d0: LoadField: r1 = r2->field_f
    //     0xd1a8d0: ldur            w1, [x2, #0xf]
    // 0xd1a8d4: DecompressPointer r1
    //     0xd1a8d4: add             x1, x1, HEAP, lsl #32
    // 0xd1a8d8: LoadField: r2 = r1->field_7
    //     0xd1a8d8: ldur            x2, [x1, #7]
    // 0xd1a8dc: cmp             x2, #0
    // 0xd1a8e0: b.gt            #0xd1a8f0
    // 0xd1a8e4: r0 = Instance_AlignmentDirectional
    //     0xd1a8e4: add             x0, PP, #0x28, lsl #12  ; [pp+0x28258] Obj!AlignmentDirectional@129e651
    //     0xd1a8e8: ldr             x0, [x0, #0x258]
    // 0xd1a8ec: b               #0xd1a8f8
    // 0xd1a8f0: r0 = Instance_AlignmentDirectional
    //     0xd1a8f0: add             x0, PP, #0x99, lsl #12  ; [pp+0x99aa0] Obj!AlignmentDirectional@129e631
    //     0xd1a8f4: ldr             x0, [x0, #0xaa0]
    // 0xd1a8f8: ret
    //     0xd1a8f8: ret             
    // 0xd1a8fc: EnterFrame
    //     0xd1a8fc: stp             fp, lr, [SP, #-0x10]!
    //     0xd1a900: mov             fp, SP
    // 0xd1a904: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1a904: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleDragCancel(dynamic) {
    // ** addr: 0xd1a9d0, size: 0x38
    // 0xd1a9d0: EnterFrame
    //     0xd1a9d0: stp             fp, lr, [SP, #-0x10]!
    //     0xd1a9d4: mov             fp, SP
    // 0xd1a9d8: ldr             x0, [fp, #0x10]
    // 0xd1a9dc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd1a9dc: ldur            w1, [x0, #0x17]
    // 0xd1a9e0: DecompressPointer r1
    //     0xd1a9e0: add             x1, x1, HEAP, lsl #32
    // 0xd1a9e4: CheckStackOverflow
    //     0xd1a9e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd1a9e8: cmp             SP, x16
    //     0xd1a9ec: b.ls            #0xd1aa00
    // 0xd1a9f0: r0 = _handleDragCancel()
    //     0xd1a9f0: bl              #0xd1aa08  ; [package:flutter/src/material/drawer.dart] DrawerControllerState::_handleDragCancel
    // 0xd1a9f4: LeaveFrame
    //     0xd1a9f4: mov             SP, fp
    //     0xd1a9f8: ldp             fp, lr, [SP], #0x10
    // 0xd1a9fc: ret
    //     0xd1a9fc: ret             
    // 0xd1aa00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1aa00: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd1aa04: b               #0xd1a9f0
  }
  _ _handleDragCancel(/* No info */) {
    // ** addr: 0xd1aa08, size: 0xdc
    // 0xd1aa08: EnterFrame
    //     0xd1aa08: stp             fp, lr, [SP, #-0x10]!
    //     0xd1aa0c: mov             fp, SP
    // 0xd1aa10: CheckStackOverflow
    //     0xd1aa10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd1aa14: cmp             SP, x16
    //     0xd1aa18: b.ls            #0xd1aac0
    // 0xd1aa1c: LoadField: r0 = r1->field_23
    //     0xd1aa1c: ldur            w0, [x1, #0x23]
    // 0xd1aa20: DecompressPointer r0
    //     0xd1aa20: add             x0, x0, HEAP, lsl #32
    // 0xd1aa24: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd1aa28: cmp             w0, w16
    // 0xd1aa2c: b.eq            #0xd1aac8
    // 0xd1aa30: LoadField: r2 = r0->field_43
    //     0xd1aa30: ldur            w2, [x0, #0x43]
    // 0xd1aa34: DecompressPointer r2
    //     0xd1aa34: add             x2, x2, HEAP, lsl #32
    // 0xd1aa38: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd1aa3c: cmp             w2, w16
    // 0xd1aa40: b.eq            #0xd1aad4
    // 0xd1aa44: r16 = Instance_AnimationStatus
    //     0xd1aa44: ldr             x16, [PP, #0x51a8]  ; [pp+0x51a8] Obj!AnimationStatus@12c61c1
    // 0xd1aa48: cmp             w2, w16
    // 0xd1aa4c: b.eq            #0xd1aa70
    // 0xd1aa50: LoadField: r2 = r0->field_2f
    //     0xd1aa50: ldur            w2, [x0, #0x2f]
    // 0xd1aa54: DecompressPointer r2
    //     0xd1aa54: add             x2, x2, HEAP, lsl #32
    // 0xd1aa58: cmp             w2, NULL
    // 0xd1aa5c: b.eq            #0xd1aa80
    // 0xd1aa60: LoadField: r3 = r2->field_7
    //     0xd1aa60: ldur            w3, [x2, #7]
    // 0xd1aa64: DecompressPointer r3
    //     0xd1aa64: add             x3, x3, HEAP, lsl #32
    // 0xd1aa68: cmp             w3, NULL
    // 0xd1aa6c: b.eq            #0xd1aa80
    // 0xd1aa70: r0 = Null
    //     0xd1aa70: mov             x0, NULL
    // 0xd1aa74: LeaveFrame
    //     0xd1aa74: mov             SP, fp
    //     0xd1aa78: ldp             fp, lr, [SP], #0x10
    // 0xd1aa7c: ret
    //     0xd1aa7c: ret             
    // 0xd1aa80: d0 = 0.500000
    //     0xd1aa80: fmov            d0, #0.50000000
    // 0xd1aa84: LoadField: r2 = r0->field_37
    //     0xd1aa84: ldur            w2, [x0, #0x37]
    // 0xd1aa88: DecompressPointer r2
    //     0xd1aa88: add             x2, x2, HEAP, lsl #32
    // 0xd1aa8c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd1aa90: cmp             w2, w16
    // 0xd1aa94: b.eq            #0xd1aadc
    // 0xd1aa98: LoadField: d1 = r2->field_7
    //     0xd1aa98: ldur            d1, [x2, #7]
    // 0xd1aa9c: fcmp            d0, d1
    // 0xd1aaa0: b.le            #0xd1aaac
    // 0xd1aaa4: r0 = close()
    //     0xd1aaa4: bl              #0xb34b88  ; [package:flutter/src/material/drawer.dart] DrawerControllerState::close
    // 0xd1aaa8: b               #0xd1aab0
    // 0xd1aaac: r0 = open()
    //     0xd1aaac: bl              #0xd1aae4  ; [package:flutter/src/material/drawer.dart] DrawerControllerState::open
    // 0xd1aab0: r0 = Null
    //     0xd1aab0: mov             x0, NULL
    // 0xd1aab4: LeaveFrame
    //     0xd1aab4: mov             SP, fp
    //     0xd1aab8: ldp             fp, lr, [SP], #0x10
    // 0xd1aabc: ret
    //     0xd1aabc: ret             
    // 0xd1aac0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1aac0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd1aac4: b               #0xd1aa1c
    // 0xd1aac8: r9 = _controller
    //     0xd1aac8: add             x9, PP, #0x83, lsl #12  ; [pp+0x837c0] Field <DrawerControllerState._controller@82517151>: late (offset: 0x24)
    //     0xd1aacc: ldr             x9, [x9, #0x7c0]
    // 0xd1aad0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd1aad0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd1aad4: r9 = _status
    //     0xd1aad4: ldr             x9, [PP, #0x51e8]  ; [pp+0x51e8] Field <AnimationController._status@62066280>: late (offset: 0x44)
    // 0xd1aad8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd1aad8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd1aadc: r9 = _value
    //     0xd1aadc: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0xd1aae0: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xd1aae0: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
  }
  _ open(/* No info */) {
    // ** addr: 0xd1aae4, size: 0x9c
    // 0xd1aae4: EnterFrame
    //     0xd1aae4: stp             fp, lr, [SP, #-0x10]!
    //     0xd1aae8: mov             fp, SP
    // 0xd1aaec: AllocStack(0x8)
    //     0xd1aaec: sub             SP, SP, #8
    // 0xd1aaf0: SetupParameters(DrawerControllerState this /* r1 => r0, fp-0x8 */)
    //     0xd1aaf0: mov             x0, x1
    //     0xd1aaf4: stur            x1, [fp, #-8]
    // 0xd1aaf8: CheckStackOverflow
    //     0xd1aaf8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd1aafc: cmp             SP, x16
    //     0xd1ab00: b.ls            #0xd1ab64
    // 0xd1ab04: LoadField: r1 = r0->field_23
    //     0xd1ab04: ldur            w1, [x0, #0x23]
    // 0xd1ab08: DecompressPointer r1
    //     0xd1ab08: add             x1, x1, HEAP, lsl #32
    // 0xd1ab0c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd1ab10: cmp             w1, w16
    // 0xd1ab14: b.eq            #0xd1ab6c
    // 0xd1ab18: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd1ab18: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd1ab1c: r0 = fling()
    //     0xd1ab1c: bl              #0xb34edc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::fling
    // 0xd1ab20: ldur            x0, [fp, #-8]
    // 0xd1ab24: LoadField: r1 = r0->field_b
    //     0xd1ab24: ldur            w1, [x0, #0xb]
    // 0xd1ab28: DecompressPointer r1
    //     0xd1ab28: add             x1, x1, HEAP, lsl #32
    // 0xd1ab2c: cmp             w1, NULL
    // 0xd1ab30: b.eq            #0xd1ab78
    // 0xd1ab34: LoadField: r0 = r1->field_13
    //     0xd1ab34: ldur            w0, [x1, #0x13]
    // 0xd1ab38: DecompressPointer r0
    //     0xd1ab38: add             x0, x0, HEAP, lsl #32
    // 0xd1ab3c: cmp             w0, NULL
    // 0xd1ab40: b.eq            #0xd1ab7c
    // 0xd1ab44: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd1ab44: ldur            w1, [x0, #0x17]
    // 0xd1ab48: DecompressPointer r1
    //     0xd1ab48: add             x1, x1, HEAP, lsl #32
    // 0xd1ab4c: r2 = true
    //     0xd1ab4c: add             x2, NULL, #0x20  ; true
    // 0xd1ab50: r0 = _drawerOpenedCallback()
    //     0xd1ab50: bl              #0xb34ca8  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::_drawerOpenedCallback
    // 0xd1ab54: r0 = Null
    //     0xd1ab54: mov             x0, NULL
    // 0xd1ab58: LeaveFrame
    //     0xd1ab58: mov             SP, fp
    //     0xd1ab5c: ldp             fp, lr, [SP], #0x10
    // 0xd1ab60: ret
    //     0xd1ab60: ret             
    // 0xd1ab64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1ab64: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd1ab68: b               #0xd1ab04
    // 0xd1ab6c: r9 = _controller
    //     0xd1ab6c: add             x9, PP, #0x83, lsl #12  ; [pp+0x837c0] Field <DrawerControllerState._controller@82517151>: late (offset: 0x24)
    //     0xd1ab70: ldr             x9, [x9, #0x7c0]
    // 0xd1ab74: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd1ab74: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd1ab78: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1ab78: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1ab7c: r0 = NullErrorSharedWithoutFPURegs()
    //     0xd1ab7c: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleDragDown(dynamic, DragDownDetails) {
    // ** addr: 0xd1ab80, size: 0x3c
    // 0xd1ab80: EnterFrame
    //     0xd1ab80: stp             fp, lr, [SP, #-0x10]!
    //     0xd1ab84: mov             fp, SP
    // 0xd1ab88: ldr             x0, [fp, #0x18]
    // 0xd1ab8c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd1ab8c: ldur            w1, [x0, #0x17]
    // 0xd1ab90: DecompressPointer r1
    //     0xd1ab90: add             x1, x1, HEAP, lsl #32
    // 0xd1ab94: CheckStackOverflow
    //     0xd1ab94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd1ab98: cmp             SP, x16
    //     0xd1ab9c: b.ls            #0xd1abb4
    // 0xd1aba0: ldr             x2, [fp, #0x10]
    // 0xd1aba4: r0 = _handleDragDown()
    //     0xd1aba4: bl              #0xd1abbc  ; [package:flutter/src/material/drawer.dart] DrawerControllerState::_handleDragDown
    // 0xd1aba8: LeaveFrame
    //     0xd1aba8: mov             SP, fp
    //     0xd1abac: ldp             fp, lr, [SP], #0x10
    // 0xd1abb0: ret
    //     0xd1abb0: ret             
    // 0xd1abb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1abb4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd1abb8: b               #0xd1aba0
  }
  _ _handleDragDown(/* No info */) {
    // ** addr: 0xd1abbc, size: 0x68
    // 0xd1abbc: EnterFrame
    //     0xd1abbc: stp             fp, lr, [SP, #-0x10]!
    //     0xd1abc0: mov             fp, SP
    // 0xd1abc4: AllocStack(0x8)
    //     0xd1abc4: sub             SP, SP, #8
    // 0xd1abc8: SetupParameters(DrawerControllerState this /* r1 => r0, fp-0x8 */)
    //     0xd1abc8: mov             x0, x1
    //     0xd1abcc: stur            x1, [fp, #-8]
    // 0xd1abd0: CheckStackOverflow
    //     0xd1abd0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd1abd4: cmp             SP, x16
    //     0xd1abd8: b.ls            #0xd1ac10
    // 0xd1abdc: LoadField: r1 = r0->field_23
    //     0xd1abdc: ldur            w1, [x0, #0x23]
    // 0xd1abe0: DecompressPointer r1
    //     0xd1abe0: add             x1, x1, HEAP, lsl #32
    // 0xd1abe4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd1abe8: cmp             w1, w16
    // 0xd1abec: b.eq            #0xd1ac18
    // 0xd1abf0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd1abf0: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd1abf4: r0 = stop()
    //     0xd1abf4: bl              #0x82eb24  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::stop
    // 0xd1abf8: ldur            x1, [fp, #-8]
    // 0xd1abfc: r0 = _ensureHistoryEntry()
    //     0xd1abfc: bl              #0xd1ac24  ; [package:flutter/src/material/drawer.dart] DrawerControllerState::_ensureHistoryEntry
    // 0xd1ac00: r0 = Null
    //     0xd1ac00: mov             x0, NULL
    // 0xd1ac04: LeaveFrame
    //     0xd1ac04: mov             SP, fp
    //     0xd1ac08: ldp             fp, lr, [SP], #0x10
    // 0xd1ac0c: ret
    //     0xd1ac0c: ret             
    // 0xd1ac10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1ac10: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd1ac14: b               #0xd1abdc
    // 0xd1ac18: r9 = _controller
    //     0xd1ac18: add             x9, PP, #0x83, lsl #12  ; [pp+0x837c0] Field <DrawerControllerState._controller@82517151>: late (offset: 0x24)
    //     0xd1ac1c: ldr             x9, [x9, #0x7c0]
    // 0xd1ac20: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd1ac20: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _ensureHistoryEntry(/* No info */) {
    // ** addr: 0xd1ac24, size: 0x108
    // 0xd1ac24: EnterFrame
    //     0xd1ac24: stp             fp, lr, [SP, #-0x10]!
    //     0xd1ac28: mov             fp, SP
    // 0xd1ac2c: AllocStack(0x28)
    //     0xd1ac2c: sub             SP, SP, #0x28
    // 0xd1ac30: SetupParameters(DrawerControllerState this /* r1 => r2, fp-0x8 */)
    //     0xd1ac30: mov             x2, x1
    //     0xd1ac34: stur            x1, [fp, #-8]
    // 0xd1ac38: CheckStackOverflow
    //     0xd1ac38: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd1ac3c: cmp             SP, x16
    //     0xd1ac40: b.ls            #0xd1ad1c
    // 0xd1ac44: LoadField: r0 = r2->field_1b
    //     0xd1ac44: ldur            w0, [x2, #0x1b]
    // 0xd1ac48: DecompressPointer r0
    //     0xd1ac48: add             x0, x0, HEAP, lsl #32
    // 0xd1ac4c: cmp             w0, NULL
    // 0xd1ac50: b.ne            #0xd1ad0c
    // 0xd1ac54: LoadField: r0 = r2->field_f
    //     0xd1ac54: ldur            w0, [x2, #0xf]
    // 0xd1ac58: DecompressPointer r0
    //     0xd1ac58: add             x0, x0, HEAP, lsl #32
    // 0xd1ac5c: cmp             w0, NULL
    // 0xd1ac60: b.eq            #0xd1ad24
    // 0xd1ac64: r16 = <Object?>
    //     0xd1ac64: ldr             x16, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0xd1ac68: stp             x0, x16, [SP]
    // 0xd1ac6c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd1ac6c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd1ac70: r0 = of()
    //     0xd1ac70: bl              #0xbfcc54  ; [package:flutter/src/widgets/routes.dart] ModalRoute::of
    // 0xd1ac74: stur            x0, [fp, #-0x10]
    // 0xd1ac78: cmp             w0, NULL
    // 0xd1ac7c: b.eq            #0xd1ad0c
    // 0xd1ac80: ldur            x3, [fp, #-8]
    // 0xd1ac84: mov             x2, x3
    // 0xd1ac88: r1 = Function '_handleHistoryEntryRemoved@82517151':.
    //     0xd1ac88: add             x1, PP, #0x99, lsl #12  ; [pp+0x99ae8] AnonymousClosure: (0xd1adec), in [package:flutter/src/material/drawer.dart] DrawerControllerState::_handleHistoryEntryRemoved (0xd1ae24)
    //     0xd1ac8c: ldr             x1, [x1, #0xae8]
    // 0xd1ac90: r0 = AllocateClosure()
    //     0xd1ac90: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd1ac94: stur            x0, [fp, #-0x18]
    // 0xd1ac98: r0 = LocalHistoryEntry()
    //     0xd1ac98: bl              #0xc3b58c  ; AllocateLocalHistoryEntryStub -> LocalHistoryEntry (size=0x14)
    // 0xd1ac9c: mov             x1, x0
    // 0xd1aca0: ldur            x0, [fp, #-0x18]
    // 0xd1aca4: StoreField: r1->field_7 = r0
    //     0xd1aca4: stur            w0, [x1, #7]
    // 0xd1aca8: r0 = false
    //     0xd1aca8: add             x0, NULL, #0x30  ; false
    // 0xd1acac: StoreField: r1->field_f = r0
    //     0xd1acac: stur            w0, [x1, #0xf]
    // 0xd1acb0: mov             x0, x1
    // 0xd1acb4: ldur            x3, [fp, #-8]
    // 0xd1acb8: StoreField: r3->field_1b = r0
    //     0xd1acb8: stur            w0, [x3, #0x1b]
    //     0xd1acbc: ldurb           w16, [x3, #-1]
    //     0xd1acc0: ldurb           w17, [x0, #-1]
    //     0xd1acc4: and             x16, x17, x16, lsr #2
    //     0xd1acc8: tst             x16, HEAP, lsr #32
    //     0xd1accc: b.eq            #0xd1acd4
    //     0xd1acd0: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xd1acd4: mov             x2, x1
    // 0xd1acd8: ldur            x1, [fp, #-0x10]
    // 0xd1acdc: r0 = addLocalHistoryEntry()
    //     0xd1acdc: bl              #0xc3b418  ; [dart:mixin_deduplication] _MixinApplication12&TransitionRoute&LocalHistoryRoute::addLocalHistoryEntry
    // 0xd1ace0: ldur            x0, [fp, #-8]
    // 0xd1ace4: LoadField: r1 = r0->field_f
    //     0xd1ace4: ldur            w1, [x0, #0xf]
    // 0xd1ace8: DecompressPointer r1
    //     0xd1ace8: add             x1, x1, HEAP, lsl #32
    // 0xd1acec: cmp             w1, NULL
    // 0xd1acf0: b.eq            #0xd1ad28
    // 0xd1acf4: r0 = of()
    //     0xd1acf4: bl              #0xd1ad2c  ; [package:flutter/src/widgets/focus_scope.dart] FocusScope::of
    // 0xd1acf8: mov             x1, x0
    // 0xd1acfc: ldur            x0, [fp, #-8]
    // 0xd1ad00: LoadField: r2 = r0->field_1f
    //     0xd1ad00: ldur            w2, [x0, #0x1f]
    // 0xd1ad04: DecompressPointer r2
    //     0xd1ad04: add             x2, x2, HEAP, lsl #32
    // 0xd1ad08: r0 = setFirstFocus()
    //     0xd1ad08: bl              #0xb92c58  ; [package:flutter/src/widgets/focus_manager.dart] FocusScopeNode::setFirstFocus
    // 0xd1ad0c: r0 = Null
    //     0xd1ad0c: mov             x0, NULL
    // 0xd1ad10: LeaveFrame
    //     0xd1ad10: mov             SP, fp
    //     0xd1ad14: ldp             fp, lr, [SP], #0x10
    // 0xd1ad18: ret
    //     0xd1ad18: ret             
    // 0xd1ad1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1ad1c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd1ad20: b               #0xd1ac44
    // 0xd1ad24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1ad24: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1ad28: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1ad28: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleHistoryEntryRemoved(dynamic) {
    // ** addr: 0xd1adec, size: 0x38
    // 0xd1adec: EnterFrame
    //     0xd1adec: stp             fp, lr, [SP, #-0x10]!
    //     0xd1adf0: mov             fp, SP
    // 0xd1adf4: ldr             x0, [fp, #0x10]
    // 0xd1adf8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd1adf8: ldur            w1, [x0, #0x17]
    // 0xd1adfc: DecompressPointer r1
    //     0xd1adfc: add             x1, x1, HEAP, lsl #32
    // 0xd1ae00: CheckStackOverflow
    //     0xd1ae00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd1ae04: cmp             SP, x16
    //     0xd1ae08: b.ls            #0xd1ae1c
    // 0xd1ae0c: r0 = _handleHistoryEntryRemoved()
    //     0xd1ae0c: bl              #0xd1ae24  ; [package:flutter/src/material/drawer.dart] DrawerControllerState::_handleHistoryEntryRemoved
    // 0xd1ae10: LeaveFrame
    //     0xd1ae10: mov             SP, fp
    //     0xd1ae14: ldp             fp, lr, [SP], #0x10
    // 0xd1ae18: ret
    //     0xd1ae18: ret             
    // 0xd1ae1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1ae1c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd1ae20: b               #0xd1ae0c
  }
  _ _handleHistoryEntryRemoved(/* No info */) {
    // ** addr: 0xd1ae24, size: 0x34
    // 0xd1ae24: EnterFrame
    //     0xd1ae24: stp             fp, lr, [SP, #-0x10]!
    //     0xd1ae28: mov             fp, SP
    // 0xd1ae2c: CheckStackOverflow
    //     0xd1ae2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd1ae30: cmp             SP, x16
    //     0xd1ae34: b.ls            #0xd1ae50
    // 0xd1ae38: StoreField: r1->field_1b = rNULL
    //     0xd1ae38: stur            NULL, [x1, #0x1b]
    // 0xd1ae3c: r0 = close()
    //     0xd1ae3c: bl              #0xb34b88  ; [package:flutter/src/material/drawer.dart] DrawerControllerState::close
    // 0xd1ae40: r0 = Null
    //     0xd1ae40: mov             x0, NULL
    // 0xd1ae44: LeaveFrame
    //     0xd1ae44: mov             SP, fp
    //     0xd1ae48: ldp             fp, lr, [SP], #0x10
    // 0xd1ae4c: ret
    //     0xd1ae4c: ret             
    // 0xd1ae50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1ae50: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd1ae54: b               #0xd1ae38
  }
  [closure] void _settle(dynamic, DragEndDetails) {
    // ** addr: 0xd1ae58, size: 0x3c
    // 0xd1ae58: EnterFrame
    //     0xd1ae58: stp             fp, lr, [SP, #-0x10]!
    //     0xd1ae5c: mov             fp, SP
    // 0xd1ae60: ldr             x0, [fp, #0x18]
    // 0xd1ae64: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd1ae64: ldur            w1, [x0, #0x17]
    // 0xd1ae68: DecompressPointer r1
    //     0xd1ae68: add             x1, x1, HEAP, lsl #32
    // 0xd1ae6c: CheckStackOverflow
    //     0xd1ae6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd1ae70: cmp             SP, x16
    //     0xd1ae74: b.ls            #0xd1ae8c
    // 0xd1ae78: ldr             x2, [fp, #0x10]
    // 0xd1ae7c: r0 = _settle()
    //     0xd1ae7c: bl              #0xd1ae94  ; [package:flutter/src/material/drawer.dart] DrawerControllerState::_settle
    // 0xd1ae80: LeaveFrame
    //     0xd1ae80: mov             SP, fp
    //     0xd1ae84: ldp             fp, lr, [SP], #0x10
    // 0xd1ae88: ret
    //     0xd1ae88: ret             
    // 0xd1ae8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1ae8c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd1ae90: b               #0xd1ae78
  }
  _ _settle(/* No info */) {
    // ** addr: 0xd1ae94, size: 0x218
    // 0xd1ae94: EnterFrame
    //     0xd1ae94: stp             fp, lr, [SP, #-0x10]!
    //     0xd1ae98: mov             fp, SP
    // 0xd1ae9c: AllocStack(0x20)
    //     0xd1ae9c: sub             SP, SP, #0x20
    // 0xd1aea0: SetupParameters(DrawerControllerState this /* r1 => r0, fp-0x8 */)
    //     0xd1aea0: mov             x0, x1
    //     0xd1aea4: stur            x1, [fp, #-8]
    // 0xd1aea8: CheckStackOverflow
    //     0xd1aea8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd1aeac: cmp             SP, x16
    //     0xd1aeb0: b.ls            #0xd1b064
    // 0xd1aeb4: LoadField: r1 = r0->field_23
    //     0xd1aeb4: ldur            w1, [x0, #0x23]
    // 0xd1aeb8: DecompressPointer r1
    //     0xd1aeb8: add             x1, x1, HEAP, lsl #32
    // 0xd1aebc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd1aec0: cmp             w1, w16
    // 0xd1aec4: b.eq            #0xd1b06c
    // 0xd1aec8: LoadField: r3 = r1->field_43
    //     0xd1aec8: ldur            w3, [x1, #0x43]
    // 0xd1aecc: DecompressPointer r3
    //     0xd1aecc: add             x3, x3, HEAP, lsl #32
    // 0xd1aed0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd1aed4: cmp             w3, w16
    // 0xd1aed8: b.eq            #0xd1b078
    // 0xd1aedc: r16 = Instance_AnimationStatus
    //     0xd1aedc: ldr             x16, [PP, #0x51a8]  ; [pp+0x51a8] Obj!AnimationStatus@12c61c1
    // 0xd1aee0: cmp             w3, w16
    // 0xd1aee4: b.ne            #0xd1aef8
    // 0xd1aee8: r0 = Null
    //     0xd1aee8: mov             x0, NULL
    // 0xd1aeec: LeaveFrame
    //     0xd1aeec: mov             SP, fp
    //     0xd1aef0: ldp             fp, lr, [SP], #0x10
    // 0xd1aef4: ret
    //     0xd1aef4: ret             
    // 0xd1aef8: d0 = 0.000000
    //     0xd1aef8: eor             v0.16b, v0.16b, v0.16b
    // 0xd1aefc: LoadField: r3 = r2->field_b
    //     0xd1aefc: ldur            w3, [x2, #0xb]
    // 0xd1af00: DecompressPointer r3
    //     0xd1af00: add             x3, x3, HEAP, lsl #32
    // 0xd1af04: LoadField: r2 = r3->field_7
    //     0xd1af04: ldur            w2, [x3, #7]
    // 0xd1af08: DecompressPointer r2
    //     0xd1af08: add             x2, x2, HEAP, lsl #32
    // 0xd1af0c: LoadField: d1 = r2->field_7
    //     0xd1af0c: ldur            d1, [x2, #7]
    // 0xd1af10: stur            d1, [fp, #-0x10]
    // 0xd1af14: fcmp            d1, d0
    // 0xd1af18: b.ne            #0xd1af30
    // 0xd1af1c: d2 = 365.000000
    //     0xd1af1c: add             x17, PP, #0x99, lsl #12  ; [pp+0x99af0] IMM: double(365) from 0x4076d00000000000
    //     0xd1af20: ldr             d2, [x17, #0xaf0]
    // 0xd1af24: fcmp            d0, d2
    // 0xd1af28: b.lt            #0xd1b01c
    // 0xd1af2c: b               #0xd1af58
    // 0xd1af30: d2 = 365.000000
    //     0xd1af30: add             x17, PP, #0x99, lsl #12  ; [pp+0x99af0] IMM: double(365) from 0x4076d00000000000
    //     0xd1af34: ldr             d2, [x17, #0xaf0]
    // 0xd1af38: fcmp            d0, d1
    // 0xd1af3c: b.le            #0xd1af50
    // 0xd1af40: fneg            d3, d1
    // 0xd1af44: fcmp            d3, d2
    // 0xd1af48: b.lt            #0xd1b01c
    // 0xd1af4c: b               #0xd1af58
    // 0xd1af50: fcmp            d1, d2
    // 0xd1af54: b.lt            #0xd1b01c
    // 0xd1af58: mov             x1, x0
    // 0xd1af5c: r0 = _width()
    //     0xd1af5c: bl              #0xd1b148  ; [package:flutter/src/material/drawer.dart] DrawerControllerState::_width
    // 0xd1af60: mov             v1.16b, v0.16b
    // 0xd1af64: ldur            d0, [fp, #-0x10]
    // 0xd1af68: fdiv            d2, d0, d1
    // 0xd1af6c: ldur            x1, [fp, #-8]
    // 0xd1af70: stur            d2, [fp, #-0x18]
    // 0xd1af74: r0 = _directionFactor()
    //     0xd1af74: bl              #0xd1b0ac  ; [package:flutter/src/material/drawer.dart] DrawerControllerState::_directionFactor
    // 0xd1af78: scvtf           d0, x0
    // 0xd1af7c: ldur            d1, [fp, #-0x18]
    // 0xd1af80: fmul            d2, d1, d0
    // 0xd1af84: ldur            x0, [fp, #-8]
    // 0xd1af88: stur            d2, [fp, #-0x10]
    // 0xd1af8c: LoadField: r1 = r0->field_23
    //     0xd1af8c: ldur            w1, [x0, #0x23]
    // 0xd1af90: DecompressPointer r1
    //     0xd1af90: add             x1, x1, HEAP, lsl #32
    // 0xd1af94: r2 = inline_Allocate_Double()
    //     0xd1af94: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xd1af98: add             x2, x2, #0x10
    //     0xd1af9c: cmp             x3, x2
    //     0xd1afa0: b.ls            #0xd1b080
    //     0xd1afa4: str             x2, [THR, #0x60]  ; THR::top
    //     0xd1afa8: sub             x2, x2, #0xf
    //     0xd1afac: mov             x3, #0xe19c
    //     0xd1afb0: movk            x3, #3, lsl #16
    //     0xd1afb4: stur            x3, [x2, #-1]
    // 0xd1afb8: dmb             ishst
    // 0xd1afbc: StoreField: r2->field_7 = d2
    //     0xd1afbc: stur            d2, [x2, #7]
    // 0xd1afc0: str             x2, [SP]
    // 0xd1afc4: r4 = const [0, 0x2, 0x1, 0x1, velocity, 0x1, null]
    //     0xd1afc4: add             x4, PP, #0x83, lsl #12  ; [pp+0x83820] List(7) [0, 0x2, 0x1, 0x1, "velocity", 0x1, Null]
    //     0xd1afc8: ldr             x4, [x4, #0x820]
    // 0xd1afcc: r0 = fling()
    //     0xd1afcc: bl              #0xb34edc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::fling
    // 0xd1afd0: ldur            x0, [fp, #-8]
    // 0xd1afd4: LoadField: r1 = r0->field_b
    //     0xd1afd4: ldur            w1, [x0, #0xb]
    // 0xd1afd8: DecompressPointer r1
    //     0xd1afd8: add             x1, x1, HEAP, lsl #32
    // 0xd1afdc: cmp             w1, NULL
    // 0xd1afe0: b.eq            #0xd1b09c
    // 0xd1afe4: LoadField: r0 = r1->field_13
    //     0xd1afe4: ldur            w0, [x1, #0x13]
    // 0xd1afe8: DecompressPointer r0
    //     0xd1afe8: add             x0, x0, HEAP, lsl #32
    // 0xd1afec: ldur            d0, [fp, #-0x10]
    // 0xd1aff0: d1 = 0.000000
    //     0xd1aff0: eor             v1.16b, v1.16b, v1.16b
    // 0xd1aff4: fcmp            d0, d1
    // 0xd1aff8: r16 = true
    //     0xd1aff8: add             x16, NULL, #0x20  ; true
    // 0xd1affc: r17 = false
    //     0xd1affc: add             x17, NULL, #0x30  ; false
    // 0xd1b000: csel            x2, x16, x17, gt
    // 0xd1b004: cmp             w0, NULL
    // 0xd1b008: b.eq            #0xd1b0a0
    // 0xd1b00c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd1b00c: ldur            w1, [x0, #0x17]
    // 0xd1b010: DecompressPointer r1
    //     0xd1b010: add             x1, x1, HEAP, lsl #32
    // 0xd1b014: r0 = _drawerOpenedCallback()
    //     0xd1b014: bl              #0xb34ca8  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::_drawerOpenedCallback
    // 0xd1b018: b               #0xd1b054
    // 0xd1b01c: d0 = 0.500000
    //     0xd1b01c: fmov            d0, #0.50000000
    // 0xd1b020: LoadField: r2 = r1->field_37
    //     0xd1b020: ldur            w2, [x1, #0x37]
    // 0xd1b024: DecompressPointer r2
    //     0xd1b024: add             x2, x2, HEAP, lsl #32
    // 0xd1b028: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd1b02c: cmp             w2, w16
    // 0xd1b030: b.eq            #0xd1b0a4
    // 0xd1b034: LoadField: d1 = r2->field_7
    //     0xd1b034: ldur            d1, [x2, #7]
    // 0xd1b038: fcmp            d0, d1
    // 0xd1b03c: b.le            #0xd1b04c
    // 0xd1b040: mov             x1, x0
    // 0xd1b044: r0 = close()
    //     0xd1b044: bl              #0xb34b88  ; [package:flutter/src/material/drawer.dart] DrawerControllerState::close
    // 0xd1b048: b               #0xd1b054
    // 0xd1b04c: mov             x1, x0
    // 0xd1b050: r0 = open()
    //     0xd1b050: bl              #0xd1aae4  ; [package:flutter/src/material/drawer.dart] DrawerControllerState::open
    // 0xd1b054: r0 = Null
    //     0xd1b054: mov             x0, NULL
    // 0xd1b058: LeaveFrame
    //     0xd1b058: mov             SP, fp
    //     0xd1b05c: ldp             fp, lr, [SP], #0x10
    // 0xd1b060: ret
    //     0xd1b060: ret             
    // 0xd1b064: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1b064: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd1b068: b               #0xd1aeb4
    // 0xd1b06c: r9 = _controller
    //     0xd1b06c: add             x9, PP, #0x83, lsl #12  ; [pp+0x837c0] Field <DrawerControllerState._controller@82517151>: late (offset: 0x24)
    //     0xd1b070: ldr             x9, [x9, #0x7c0]
    // 0xd1b074: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd1b074: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd1b078: r9 = _status
    //     0xd1b078: ldr             x9, [PP, #0x51e8]  ; [pp+0x51e8] Field <AnimationController._status@62066280>: late (offset: 0x44)
    // 0xd1b07c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd1b07c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd1b080: SaveReg d2
    //     0xd1b080: str             q2, [SP, #-0x10]!
    // 0xd1b084: stp             x0, x1, [SP, #-0x10]!
    // 0xd1b088: r0 = AllocateDouble()
    //     0xd1b088: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd1b08c: mov             x2, x0
    // 0xd1b090: ldp             x0, x1, [SP], #0x10
    // 0xd1b094: RestoreReg d2
    //     0xd1b094: ldr             q2, [SP], #0x10
    // 0xd1b098: b               #0xd1afbc
    // 0xd1b09c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1b09c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1b0a0: r0 = NullErrorSharedWithoutFPURegs()
    //     0xd1b0a0: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xd1b0a4: r9 = _value
    //     0xd1b0a4: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0xd1b0a8: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xd1b0a8: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
  }
  get _ _directionFactor(/* No info */) {
    // ** addr: 0xd1b0ac, size: 0x9c
    // 0xd1b0ac: EnterFrame
    //     0xd1b0ac: stp             fp, lr, [SP, #-0x10]!
    //     0xd1b0b0: mov             fp, SP
    // 0xd1b0b4: AllocStack(0x8)
    //     0xd1b0b4: sub             SP, SP, #8
    // 0xd1b0b8: SetupParameters(DrawerControllerState this /* r1 => r0, fp-0x8 */)
    //     0xd1b0b8: mov             x0, x1
    //     0xd1b0bc: stur            x1, [fp, #-8]
    // 0xd1b0c0: CheckStackOverflow
    //     0xd1b0c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd1b0c4: cmp             SP, x16
    //     0xd1b0c8: b.ls            #0xd1b138
    // 0xd1b0cc: LoadField: r1 = r0->field_f
    //     0xd1b0cc: ldur            w1, [x0, #0xf]
    // 0xd1b0d0: DecompressPointer r1
    //     0xd1b0d0: add             x1, x1, HEAP, lsl #32
    // 0xd1b0d4: cmp             w1, NULL
    // 0xd1b0d8: b.eq            #0xd1b140
    // 0xd1b0dc: r0 = of()
    //     0xd1b0dc: bl              #0x87371c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0xd1b0e0: ldur            x1, [fp, #-8]
    // 0xd1b0e4: LoadField: r2 = r1->field_b
    //     0xd1b0e4: ldur            w2, [x1, #0xb]
    // 0xd1b0e8: DecompressPointer r2
    //     0xd1b0e8: add             x2, x2, HEAP, lsl #32
    // 0xd1b0ec: cmp             w2, NULL
    // 0xd1b0f0: b.eq            #0xd1b144
    // 0xd1b0f4: r16 = Instance_TextDirection
    //     0xd1b0f4: ldr             x16, [PP, #0x2578]  ; [pp+0x2578] Obj!TextDirection@12c7381
    // 0xd1b0f8: cmp             w0, w16
    // 0xd1b0fc: b.ne            #0xd1b108
    // 0xd1b100: r1 = -2
    //     0xd1b100: mov             x1, #-2
    // 0xd1b104: b               #0xd1b120
    // 0xd1b108: r16 = Instance_TextDirection
    //     0xd1b108: ldr             x16, [PP, #0x25b0]  ; [pp+0x25b0] Obj!TextDirection@12c73a1
    // 0xd1b10c: cmp             w0, w16
    // 0xd1b110: b.ne            #0xd1b11c
    // 0xd1b114: r1 = 2
    //     0xd1b114: mov             x1, #2
    // 0xd1b118: b               #0xd1b120
    // 0xd1b11c: r1 = Null
    //     0xd1b11c: mov             x1, NULL
    // 0xd1b120: r0 = LoadInt32Instr(r1)
    //     0xd1b120: sbfx            x0, x1, #1, #0x1f
    //     0xd1b124: tbz             w1, #0, #0xd1b12c
    //     0xd1b128: ldur            x0, [x1, #7]
    // 0xd1b12c: LeaveFrame
    //     0xd1b12c: mov             SP, fp
    //     0xd1b130: ldp             fp, lr, [SP], #0x10
    // 0xd1b134: ret
    //     0xd1b134: ret             
    // 0xd1b138: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1b138: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd1b13c: b               #0xd1b0cc
    // 0xd1b140: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1b140: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1b144: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1b144: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _width(/* No info */) {
    // ** addr: 0xd1b148, size: 0x104
    // 0xd1b148: EnterFrame
    //     0xd1b148: stp             fp, lr, [SP, #-0x10]!
    //     0xd1b14c: mov             fp, SP
    // 0xd1b150: AllocStack(0x8)
    //     0xd1b150: sub             SP, SP, #8
    // 0xd1b154: CheckStackOverflow
    //     0xd1b154: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd1b158: cmp             SP, x16
    //     0xd1b15c: b.ls            #0xd1b234
    // 0xd1b160: LoadField: r0 = r1->field_27
    //     0xd1b160: ldur            w0, [x1, #0x27]
    // 0xd1b164: DecompressPointer r0
    //     0xd1b164: add             x0, x0, HEAP, lsl #32
    // 0xd1b168: mov             x1, x0
    // 0xd1b16c: r0 = _currentElement()
    //     0xd1b16c: bl              #0x859318  ; [package:flutter/src/widgets/framework.dart] GlobalKey::_currentElement
    // 0xd1b170: cmp             w0, NULL
    // 0xd1b174: b.ne            #0xd1b180
    // 0xd1b178: r3 = Null
    //     0xd1b178: mov             x3, NULL
    // 0xd1b17c: b               #0xd1b18c
    // 0xd1b180: mov             x1, x0
    // 0xd1b184: r0 = findRenderObject()
    //     0xd1b184: bl              #0x8418fc  ; [package:flutter/src/widgets/framework.dart] Element::findRenderObject
    // 0xd1b188: mov             x3, x0
    // 0xd1b18c: mov             x0, x3
    // 0xd1b190: stur            x3, [fp, #-8]
    // 0xd1b194: r2 = Null
    //     0xd1b194: mov             x2, NULL
    // 0xd1b198: r1 = Null
    //     0xd1b198: mov             x1, NULL
    // 0xd1b19c: r4 = LoadClassIdInstr(r0)
    //     0xd1b19c: ldur            x4, [x0, #-1]
    //     0xd1b1a0: ubfx            x4, x4, #0xc, #0x14
    // 0xd1b1a4: r17 = -4710
    //     0xd1b1a4: mov             x17, #-0x1266
    // 0xd1b1a8: add             x4, x4, x17
    // 0xd1b1ac: cmp             x4, #0x109
    // 0xd1b1b0: b.ls            #0xd1b1c4
    // 0xd1b1b4: r8 = RenderBox?
    //     0xd1b1b4: ldr             x8, [PP, #0x47c8]  ; [pp+0x47c8] Type: RenderBox?
    // 0xd1b1b8: r3 = Null
    //     0xd1b1b8: add             x3, PP, #0x99, lsl #12  ; [pp+0x99af8] Null
    //     0xd1b1bc: ldr             x3, [x3, #0xaf8]
    // 0xd1b1c0: r0 = RenderBox?()
    //     0xd1b1c0: bl              #0x870a94  ; IsType_RenderBox?_Stub
    // 0xd1b1c4: ldur            x1, [fp, #-8]
    // 0xd1b1c8: cmp             w1, NULL
    // 0xd1b1cc: b.ne            #0xd1b1d8
    // 0xd1b1d0: r0 = Null
    //     0xd1b1d0: mov             x0, NULL
    // 0xd1b1d4: b               #0xd1b20c
    // 0xd1b1d8: r0 = size()
    //     0xd1b1d8: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xd1b1dc: LoadField: d1 = r0->field_7
    //     0xd1b1dc: ldur            d1, [x0, #7]
    // 0xd1b1e0: r0 = inline_Allocate_Double()
    //     0xd1b1e0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xd1b1e4: add             x0, x0, #0x10
    //     0xd1b1e8: cmp             x1, x0
    //     0xd1b1ec: b.ls            #0xd1b23c
    //     0xd1b1f0: str             x0, [THR, #0x60]  ; THR::top
    //     0xd1b1f4: sub             x0, x0, #0xf
    //     0xd1b1f8: mov             x1, #0xe19c
    //     0xd1b1fc: movk            x1, #3, lsl #16
    //     0xd1b200: stur            x1, [x0, #-1]
    // 0xd1b204: dmb             ishst
    // 0xd1b208: StoreField: r0->field_7 = d1
    //     0xd1b208: stur            d1, [x0, #7]
    // 0xd1b20c: cmp             w0, NULL
    // 0xd1b210: b.ne            #0xd1b220
    // 0xd1b214: d0 = 304.000000
    //     0xd1b214: add             x17, PP, #0x99, lsl #12  ; [pp+0x99b08] IMM: double(304) from 0x4073000000000000
    //     0xd1b218: ldr             d0, [x17, #0xb08]
    // 0xd1b21c: b               #0xd1b228
    // 0xd1b220: LoadField: d1 = r0->field_7
    //     0xd1b220: ldur            d1, [x0, #7]
    // 0xd1b224: mov             v0.16b, v1.16b
    // 0xd1b228: LeaveFrame
    //     0xd1b228: mov             SP, fp
    //     0xd1b22c: ldp             fp, lr, [SP], #0x10
    // 0xd1b230: ret
    //     0xd1b230: ret             
    // 0xd1b234: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1b234: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd1b238: b               #0xd1b160
    // 0xd1b23c: SaveReg d1
    //     0xd1b23c: str             q1, [SP, #-0x10]!
    // 0xd1b240: r0 = AllocateDouble()
    //     0xd1b240: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd1b244: RestoreReg d1
    //     0xd1b244: ldr             q1, [SP], #0x10
    // 0xd1b248: b               #0xd1b208
  }
  [closure] void _move(dynamic, DragUpdateDetails) {
    // ** addr: 0xd1b24c, size: 0x3c
    // 0xd1b24c: EnterFrame
    //     0xd1b24c: stp             fp, lr, [SP, #-0x10]!
    //     0xd1b250: mov             fp, SP
    // 0xd1b254: ldr             x0, [fp, #0x18]
    // 0xd1b258: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd1b258: ldur            w1, [x0, #0x17]
    // 0xd1b25c: DecompressPointer r1
    //     0xd1b25c: add             x1, x1, HEAP, lsl #32
    // 0xd1b260: CheckStackOverflow
    //     0xd1b260: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd1b264: cmp             SP, x16
    //     0xd1b268: b.ls            #0xd1b280
    // 0xd1b26c: ldr             x2, [fp, #0x10]
    // 0xd1b270: r0 = _move()
    //     0xd1b270: bl              #0xd1b288  ; [package:flutter/src/material/drawer.dart] DrawerControllerState::_move
    // 0xd1b274: LeaveFrame
    //     0xd1b274: mov             SP, fp
    //     0xd1b278: ldp             fp, lr, [SP], #0x10
    // 0xd1b27c: ret
    //     0xd1b27c: ret             
    // 0xd1b280: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1b280: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd1b284: b               #0xd1b26c
  }
  _ _move(/* No info */) {
    // ** addr: 0xd1b288, size: 0x1ac
    // 0xd1b288: EnterFrame
    //     0xd1b288: stp             fp, lr, [SP, #-0x10]!
    //     0xd1b28c: mov             fp, SP
    // 0xd1b290: AllocStack(0x28)
    //     0xd1b290: sub             SP, SP, #0x28
    // 0xd1b294: SetupParameters(DrawerControllerState this /* r1 => r0, fp-0x20 */)
    //     0xd1b294: mov             x0, x1
    //     0xd1b298: stur            x1, [fp, #-0x20]
    // 0xd1b29c: CheckStackOverflow
    //     0xd1b29c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd1b2a0: cmp             SP, x16
    //     0xd1b2a4: b.ls            #0xd1b3f0
    // 0xd1b2a8: LoadField: r3 = r0->field_23
    //     0xd1b2a8: ldur            w3, [x0, #0x23]
    // 0xd1b2ac: DecompressPointer r3
    //     0xd1b2ac: add             x3, x3, HEAP, lsl #32
    // 0xd1b2b0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd1b2b4: cmp             w3, w16
    // 0xd1b2b8: b.eq            #0xd1b3f8
    // 0xd1b2bc: stur            x3, [fp, #-0x18]
    // 0xd1b2c0: LoadField: r4 = r3->field_37
    //     0xd1b2c0: ldur            w4, [x3, #0x37]
    // 0xd1b2c4: DecompressPointer r4
    //     0xd1b2c4: add             x4, x4, HEAP, lsl #32
    // 0xd1b2c8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd1b2cc: cmp             w4, w16
    // 0xd1b2d0: b.eq            #0xd1b404
    // 0xd1b2d4: stur            x4, [fp, #-0x10]
    // 0xd1b2d8: ArrayLoad: r5 = r2[0]  ; List_4
    //     0xd1b2d8: ldur            w5, [x2, #0x17]
    // 0xd1b2dc: DecompressPointer r5
    //     0xd1b2dc: add             x5, x5, HEAP, lsl #32
    // 0xd1b2e0: stur            x5, [fp, #-8]
    // 0xd1b2e4: cmp             w5, NULL
    // 0xd1b2e8: b.eq            #0xd1b40c
    // 0xd1b2ec: mov             x1, x0
    // 0xd1b2f0: r0 = _width()
    //     0xd1b2f0: bl              #0xd1b148  ; [package:flutter/src/material/drawer.dart] DrawerControllerState::_width
    // 0xd1b2f4: ldur            x0, [fp, #-8]
    // 0xd1b2f8: LoadField: d1 = r0->field_7
    //     0xd1b2f8: ldur            d1, [x0, #7]
    // 0xd1b2fc: fdiv            d2, d1, d0
    // 0xd1b300: ldur            x1, [fp, #-0x20]
    // 0xd1b304: stur            d2, [fp, #-0x28]
    // 0xd1b308: r0 = _directionFactor()
    //     0xd1b308: bl              #0xd1b0ac  ; [package:flutter/src/material/drawer.dart] DrawerControllerState::_directionFactor
    // 0xd1b30c: scvtf           d0, x0
    // 0xd1b310: ldur            d1, [fp, #-0x28]
    // 0xd1b314: fmul            d2, d1, d0
    // 0xd1b318: ldur            x0, [fp, #-0x10]
    // 0xd1b31c: LoadField: d0 = r0->field_7
    //     0xd1b31c: ldur            d0, [x0, #7]
    // 0xd1b320: fadd            d1, d0, d2
    // 0xd1b324: r2 = inline_Allocate_Double()
    //     0xd1b324: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0xd1b328: add             x2, x2, #0x10
    //     0xd1b32c: cmp             x0, x2
    //     0xd1b330: b.ls            #0xd1b410
    //     0xd1b334: str             x2, [THR, #0x60]  ; THR::top
    //     0xd1b338: sub             x2, x2, #0xf
    //     0xd1b33c: mov             x0, #0xe19c
    //     0xd1b340: movk            x0, #3, lsl #16
    //     0xd1b344: stur            x0, [x2, #-1]
    // 0xd1b348: dmb             ishst
    // 0xd1b34c: StoreField: r2->field_7 = d1
    //     0xd1b34c: stur            d1, [x2, #7]
    // 0xd1b350: ldur            x1, [fp, #-0x18]
    // 0xd1b354: r0 = value=()
    //     0xd1b354: bl              #0x829534  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0xd1b358: ldur            x0, [fp, #-0x20]
    // 0xd1b35c: LoadField: r1 = r0->field_23
    //     0xd1b35c: ldur            w1, [x0, #0x23]
    // 0xd1b360: DecompressPointer r1
    //     0xd1b360: add             x1, x1, HEAP, lsl #32
    // 0xd1b364: LoadField: r2 = r1->field_37
    //     0xd1b364: ldur            w2, [x1, #0x37]
    // 0xd1b368: DecompressPointer r2
    //     0xd1b368: add             x2, x2, HEAP, lsl #32
    // 0xd1b36c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd1b370: cmp             w2, w16
    // 0xd1b374: b.eq            #0xd1b424
    // 0xd1b378: LoadField: d0 = r2->field_7
    //     0xd1b378: ldur            d0, [x2, #7]
    // 0xd1b37c: d1 = 0.500000
    //     0xd1b37c: fmov            d1, #0.50000000
    // 0xd1b380: fcmp            d0, d1
    // 0xd1b384: r16 = true
    //     0xd1b384: add             x16, NULL, #0x20  ; true
    // 0xd1b388: r17 = false
    //     0xd1b388: add             x17, NULL, #0x30  ; false
    // 0xd1b38c: csel            x3, x16, x17, gt
    // 0xd1b390: stur            x3, [fp, #-8]
    // 0xd1b394: LoadField: r1 = r0->field_2b
    //     0xd1b394: ldur            w1, [x0, #0x2b]
    // 0xd1b398: DecompressPointer r1
    //     0xd1b398: add             x1, x1, HEAP, lsl #32
    // 0xd1b39c: cmp             w3, w1
    // 0xd1b3a0: b.eq            #0xd1b3d4
    // 0xd1b3a4: LoadField: r1 = r0->field_b
    //     0xd1b3a4: ldur            w1, [x0, #0xb]
    // 0xd1b3a8: DecompressPointer r1
    //     0xd1b3a8: add             x1, x1, HEAP, lsl #32
    // 0xd1b3ac: cmp             w1, NULL
    // 0xd1b3b0: b.eq            #0xd1b42c
    // 0xd1b3b4: LoadField: r2 = r1->field_13
    //     0xd1b3b4: ldur            w2, [x1, #0x13]
    // 0xd1b3b8: DecompressPointer r2
    //     0xd1b3b8: add             x2, x2, HEAP, lsl #32
    // 0xd1b3bc: cmp             w2, NULL
    // 0xd1b3c0: b.eq            #0xd1b430
    // 0xd1b3c4: ArrayLoad: r1 = r2[0]  ; List_4
    //     0xd1b3c4: ldur            w1, [x2, #0x17]
    // 0xd1b3c8: DecompressPointer r1
    //     0xd1b3c8: add             x1, x1, HEAP, lsl #32
    // 0xd1b3cc: mov             x2, x3
    // 0xd1b3d0: r0 = _drawerOpenedCallback()
    //     0xd1b3d0: bl              #0xb34ca8  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::_drawerOpenedCallback
    // 0xd1b3d4: ldur            x1, [fp, #-0x20]
    // 0xd1b3d8: ldur            x2, [fp, #-8]
    // 0xd1b3dc: StoreField: r1->field_2b = r2
    //     0xd1b3dc: stur            w2, [x1, #0x2b]
    // 0xd1b3e0: r0 = Null
    //     0xd1b3e0: mov             x0, NULL
    // 0xd1b3e4: LeaveFrame
    //     0xd1b3e4: mov             SP, fp
    //     0xd1b3e8: ldp             fp, lr, [SP], #0x10
    // 0xd1b3ec: ret
    //     0xd1b3ec: ret             
    // 0xd1b3f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1b3f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd1b3f4: b               #0xd1b2a8
    // 0xd1b3f8: r9 = _controller
    //     0xd1b3f8: add             x9, PP, #0x83, lsl #12  ; [pp+0x837c0] Field <DrawerControllerState._controller@82517151>: late (offset: 0x24)
    //     0xd1b3fc: ldr             x9, [x9, #0x7c0]
    // 0xd1b400: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd1b400: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd1b404: r9 = _value
    //     0xd1b404: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0xd1b408: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd1b408: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd1b40c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1b40c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1b410: SaveReg d1
    //     0xd1b410: str             q1, [SP, #-0x10]!
    // 0xd1b414: r0 = AllocateDouble()
    //     0xd1b414: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd1b418: mov             x2, x0
    // 0xd1b41c: RestoreReg d1
    //     0xd1b41c: ldr             q1, [SP], #0x10
    // 0xd1b420: b               #0xd1b34c
    // 0xd1b424: r9 = _value
    //     0xd1b424: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0xd1b428: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd1b428: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd1b42c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1b42c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd1b430: r0 = NullErrorSharedWithoutFPURegs()
    //     0xd1b430: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf37f18, size: 0x1c4
    // 0xf37f18: EnterFrame
    //     0xf37f18: stp             fp, lr, [SP, #-0x10]!
    //     0xf37f1c: mov             fp, SP
    // 0xf37f20: AllocStack(0x10)
    //     0xf37f20: sub             SP, SP, #0x10
    // 0xf37f24: SetupParameters(DrawerControllerState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xf37f24: mov             x4, x1
    //     0xf37f28: mov             x3, x2
    //     0xf37f2c: stur            x1, [fp, #-8]
    //     0xf37f30: stur            x2, [fp, #-0x10]
    // 0xf37f34: CheckStackOverflow
    //     0xf37f34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf37f38: cmp             SP, x16
    //     0xf37f3c: b.ls            #0xf380a0
    // 0xf37f40: mov             x0, x3
    // 0xf37f44: r2 = Null
    //     0xf37f44: mov             x2, NULL
    // 0xf37f48: r1 = Null
    //     0xf37f48: mov             x1, NULL
    // 0xf37f4c: r4 = 60
    //     0xf37f4c: mov             x4, #0x3c
    // 0xf37f50: branchIfSmi(r0, 0xf37f5c)
    //     0xf37f50: tbz             w0, #0, #0xf37f5c
    // 0xf37f54: r4 = LoadClassIdInstr(r0)
    //     0xf37f54: ldur            x4, [x0, #-1]
    //     0xf37f58: ubfx            x4, x4, #0xc, #0x14
    // 0xf37f5c: r17 = 6484
    //     0xf37f5c: mov             x17, #0x1954
    // 0xf37f60: cmp             x4, x17
    // 0xf37f64: b.eq            #0xf37f7c
    // 0xf37f68: r8 = DrawerController
    //     0xf37f68: add             x8, PP, #0x99, lsl #12  ; [pp+0x99b18] Type: DrawerController
    //     0xf37f6c: ldr             x8, [x8, #0xb18]
    // 0xf37f70: r3 = Null
    //     0xf37f70: add             x3, PP, #0x99, lsl #12  ; [pp+0x99b20] Null
    //     0xf37f74: ldr             x3, [x3, #0xb20]
    // 0xf37f78: r0 = DrawerController()
    //     0xf37f78: bl              #0xace270  ; IsType_DrawerController_Stub
    // 0xf37f7c: ldur            x3, [fp, #-8]
    // 0xf37f80: LoadField: r2 = r3->field_7
    //     0xf37f80: ldur            w2, [x3, #7]
    // 0xf37f84: DecompressPointer r2
    //     0xf37f84: add             x2, x2, HEAP, lsl #32
    // 0xf37f88: ldur            x0, [fp, #-0x10]
    // 0xf37f8c: r1 = Null
    //     0xf37f8c: mov             x1, NULL
    // 0xf37f90: cmp             w2, NULL
    // 0xf37f94: b.eq            #0xf37fb8
    // 0xf37f98: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf37f98: ldur            w4, [x2, #0x17]
    // 0xf37f9c: DecompressPointer r4
    //     0xf37f9c: add             x4, x4, HEAP, lsl #32
    // 0xf37fa0: r8 = X0 bound StatefulWidget
    //     0xf37fa0: add             x8, PP, #0x12, lsl #12  ; [pp+0x12498] TypeParameter: X0 bound StatefulWidget
    //     0xf37fa4: ldr             x8, [x8, #0x498]
    // 0xf37fa8: LoadField: r9 = r4->field_7
    //     0xf37fa8: ldur            x9, [x4, #7]
    // 0xf37fac: r3 = Null
    //     0xf37fac: add             x3, PP, #0x99, lsl #12  ; [pp+0x99b30] Null
    //     0xf37fb0: ldr             x3, [x3, #0xb30]
    // 0xf37fb4: blr             x9
    // 0xf37fb8: ldur            x0, [fp, #-8]
    // 0xf37fbc: LoadField: r1 = r0->field_23
    //     0xf37fbc: ldur            w1, [x0, #0x23]
    // 0xf37fc0: DecompressPointer r1
    //     0xf37fc0: add             x1, x1, HEAP, lsl #32
    // 0xf37fc4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf37fc8: cmp             w1, w16
    // 0xf37fcc: b.eq            #0xf380a8
    // 0xf37fd0: LoadField: r2 = r1->field_43
    //     0xf37fd0: ldur            w2, [x1, #0x43]
    // 0xf37fd4: DecompressPointer r2
    //     0xf37fd4: add             x2, x2, HEAP, lsl #32
    // 0xf37fd8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf37fdc: cmp             w2, w16
    // 0xf37fe0: b.eq            #0xf380b4
    // 0xf37fe4: r16 = Instance_AnimationStatus
    //     0xf37fe4: ldr             x16, [PP, #0x51b8]  ; [pp+0x51b8] Obj!AnimationStatus@12c6181
    // 0xf37fe8: cmp             w2, w16
    // 0xf37fec: b.eq            #0xf37ffc
    // 0xf37ff0: r16 = Instance_AnimationStatus
    //     0xf37ff0: ldr             x16, [PP, #0x51c0]  ; [pp+0x51c0] Obj!AnimationStatus@12c6161
    // 0xf37ff4: cmp             w2, w16
    // 0xf37ff8: b.ne            #0xf3800c
    // 0xf37ffc: r0 = Null
    //     0xf37ffc: mov             x0, NULL
    // 0xf38000: LeaveFrame
    //     0xf38000: mov             SP, fp
    //     0xf38004: ldp             fp, lr, [SP], #0x10
    // 0xf38008: ret
    //     0xf38008: ret             
    // 0xf3800c: r16 = Instance_AnimationStatus
    //     0xf3800c: ldr             x16, [PP, #0x51a0]  ; [pp+0x51a0] Obj!AnimationStatus@12c61a1
    // 0xf38010: cmp             w2, w16
    // 0xf38014: b.eq            #0xf38024
    // 0xf38018: r16 = Instance_AnimationStatus
    //     0xf38018: ldr             x16, [PP, #0x51a8]  ; [pp+0x51a8] Obj!AnimationStatus@12c61c1
    // 0xf3801c: cmp             w2, w16
    // 0xf38020: b.eq            #0xf38024
    // 0xf38024: ldur            x2, [fp, #-0x10]
    // 0xf38028: LoadField: r3 = r0->field_b
    //     0xf38028: ldur            w3, [x0, #0xb]
    // 0xf3802c: DecompressPointer r3
    //     0xf3802c: add             x3, x3, HEAP, lsl #32
    // 0xf38030: cmp             w3, NULL
    // 0xf38034: b.eq            #0xf380bc
    // 0xf38038: LoadField: r0 = r3->field_2b
    //     0xf38038: ldur            w0, [x3, #0x2b]
    // 0xf3803c: DecompressPointer r0
    //     0xf3803c: add             x0, x0, HEAP, lsl #32
    // 0xf38040: LoadField: r3 = r2->field_2b
    //     0xf38040: ldur            w3, [x2, #0x2b]
    // 0xf38044: DecompressPointer r3
    //     0xf38044: add             x3, x3, HEAP, lsl #32
    // 0xf38048: cmp             w0, w3
    // 0xf3804c: b.eq            #0xf38090
    // 0xf38050: tbnz            w0, #4, #0xf3805c
    // 0xf38054: d0 = 1.000000
    //     0xf38054: fmov            d0, #1.00000000
    // 0xf38058: b               #0xf38060
    // 0xf3805c: d0 = 0.000000
    //     0xf3805c: eor             v0.16b, v0.16b, v0.16b
    // 0xf38060: r2 = inline_Allocate_Double()
    //     0xf38060: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0xf38064: add             x2, x2, #0x10
    //     0xf38068: cmp             x0, x2
    //     0xf3806c: b.ls            #0xf380c0
    //     0xf38070: str             x2, [THR, #0x60]  ; THR::top
    //     0xf38074: sub             x2, x2, #0xf
    //     0xf38078: mov             x0, #0xe19c
    //     0xf3807c: movk            x0, #3, lsl #16
    //     0xf38080: stur            x0, [x2, #-1]
    // 0xf38084: dmb             ishst
    // 0xf38088: StoreField: r2->field_7 = d0
    //     0xf38088: stur            d0, [x2, #7]
    // 0xf3808c: r0 = value=()
    //     0xf3808c: bl              #0x829534  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0xf38090: r0 = Null
    //     0xf38090: mov             x0, NULL
    // 0xf38094: LeaveFrame
    //     0xf38094: mov             SP, fp
    //     0xf38098: ldp             fp, lr, [SP], #0x10
    // 0xf3809c: ret
    //     0xf3809c: ret             
    // 0xf380a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf380a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf380a4: b               #0xf37f40
    // 0xf380a8: r9 = _controller
    //     0xf380a8: add             x9, PP, #0x83, lsl #12  ; [pp+0x837c0] Field <DrawerControllerState._controller@82517151>: late (offset: 0x24)
    //     0xf380ac: ldr             x9, [x9, #0x7c0]
    // 0xf380b0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf380b0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xf380b4: r9 = _status
    //     0xf380b4: ldr             x9, [PP, #0x51e8]  ; [pp+0x51e8] Field <AnimationController._status@62066280>: late (offset: 0x44)
    // 0xf380b8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf380b8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xf380bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf380bc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf380c0: SaveReg d0
    //     0xf380c0: str             q0, [SP, #-0x10]!
    // 0xf380c4: SaveReg r1
    //     0xf380c4: str             x1, [SP, #-8]!
    // 0xf380c8: r0 = AllocateDouble()
    //     0xf380c8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xf380cc: mov             x2, x0
    // 0xf380d0: RestoreReg r1
    //     0xf380d0: ldr             x1, [SP], #8
    // 0xf380d4: RestoreReg d0
    //     0xf380d4: ldr             q0, [SP], #0x10
    // 0xf380d8: b               #0xf38088
  }
  _ initState(/* No info */) {
    // ** addr: 0xf79784, size: 0x138
    // 0xf79784: EnterFrame
    //     0xf79784: stp             fp, lr, [SP, #-0x10]!
    //     0xf79788: mov             fp, SP
    // 0xf7978c: AllocStack(0x28)
    //     0xf7978c: sub             SP, SP, #0x28
    // 0xf79790: SetupParameters(DrawerControllerState this /* r1 => r2, fp-0x10 */)
    //     0xf79790: mov             x2, x1
    //     0xf79794: stur            x1, [fp, #-0x10]
    // 0xf79798: CheckStackOverflow
    //     0xf79798: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf7979c: cmp             SP, x16
    //     0xf797a0: b.ls            #0xf79898
    // 0xf797a4: LoadField: r0 = r2->field_b
    //     0xf797a4: ldur            w0, [x2, #0xb]
    // 0xf797a8: DecompressPointer r0
    //     0xf797a8: add             x0, x0, HEAP, lsl #32
    // 0xf797ac: cmp             w0, NULL
    // 0xf797b0: b.eq            #0xf798a0
    // 0xf797b4: LoadField: r1 = r0->field_2b
    //     0xf797b4: ldur            w1, [x0, #0x2b]
    // 0xf797b8: DecompressPointer r1
    //     0xf797b8: add             x1, x1, HEAP, lsl #32
    // 0xf797bc: tbnz            w1, #4, #0xf797c8
    // 0xf797c0: d0 = 1.000000
    //     0xf797c0: fmov            d0, #1.00000000
    // 0xf797c4: b               #0xf797cc
    // 0xf797c8: d0 = 0.000000
    //     0xf797c8: eor             v0.16b, v0.16b, v0.16b
    // 0xf797cc: r0 = inline_Allocate_Double()
    //     0xf797cc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xf797d0: add             x0, x0, #0x10
    //     0xf797d4: cmp             x1, x0
    //     0xf797d8: b.ls            #0xf798a4
    //     0xf797dc: str             x0, [THR, #0x60]  ; THR::top
    //     0xf797e0: sub             x0, x0, #0xf
    //     0xf797e4: mov             x1, #0xe19c
    //     0xf797e8: movk            x1, #3, lsl #16
    //     0xf797ec: stur            x1, [x0, #-1]
    // 0xf797f0: dmb             ishst
    // 0xf797f4: StoreField: r0->field_7 = d0
    //     0xf797f4: stur            d0, [x0, #7]
    // 0xf797f8: stur            x0, [fp, #-8]
    // 0xf797fc: r1 = <double>
    //     0xf797fc: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf79800: r0 = AnimationController()
    //     0xf79800: bl              #0x87522c  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0xf79804: stur            x0, [fp, #-0x18]
    // 0xf79808: ldur            x16, [fp, #-8]
    // 0xf7980c: r30 = Instance_Duration
    //     0xf7980c: add             lr, PP, #0x99, lsl #12  ; [pp+0x99b40] Obj!Duration@12c8bf1
    //     0xf79810: ldr             lr, [lr, #0xb40]
    // 0xf79814: stp             lr, x16, [SP]
    // 0xf79818: mov             x1, x0
    // 0xf7981c: ldur            x2, [fp, #-0x10]
    // 0xf79820: r4 = const [0, 0x4, 0x2, 0x2, duration, 0x3, value, 0x2, null]
    //     0xf79820: add             x4, PP, #0x84, lsl #12  ; [pp+0x84ce0] List(9) [0, 0x4, 0x2, 0x2, "duration", 0x3, "value", 0x2, Null]
    //     0xf79824: ldr             x4, [x4, #0xce0]
    // 0xf79828: r0 = AnimationController()
    //     0xf79828: bl              #0x874ea4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0xf7982c: ldur            x0, [fp, #-0x18]
    // 0xf79830: ldur            x3, [fp, #-0x10]
    // 0xf79834: StoreField: r3->field_23 = r0
    //     0xf79834: stur            w0, [x3, #0x23]
    //     0xf79838: ldurb           w16, [x3, #-1]
    //     0xf7983c: ldurb           w17, [x0, #-1]
    //     0xf79840: and             x16, x17, x16, lsr #2
    //     0xf79844: tst             x16, HEAP, lsr #32
    //     0xf79848: b.eq            #0xf79850
    //     0xf7984c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xf79850: mov             x2, x3
    // 0xf79854: r1 = Function '_animationChanged@82517151':.
    //     0xf79854: add             x1, PP, #0x99, lsl #12  ; [pp+0x99b48] AnonymousClosure: (0xf7997c), in [package:flutter/src/material/drawer.dart] DrawerControllerState::_animationChanged (0xf799b4)
    //     0xf79858: ldr             x1, [x1, #0xb48]
    // 0xf7985c: r0 = AllocateClosure()
    //     0xf7985c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf79860: ldur            x1, [fp, #-0x18]
    // 0xf79864: mov             x2, x0
    // 0xf79868: r0 = addListener()
    //     0xf79868: bl              #0xd0440c  ; [dart:mixin_deduplication] _MixinApplication455&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::addListener
    // 0xf7986c: ldur            x2, [fp, #-0x10]
    // 0xf79870: r1 = Function '_animationStatusChanged@82517151':.
    //     0xf79870: add             x1, PP, #0x99, lsl #12  ; [pp+0x99b50] AnonymousClosure: (0xf798bc), in [package:flutter/src/material/drawer.dart] DrawerControllerState::_animationStatusChanged (0xf798f8)
    //     0xf79874: ldr             x1, [x1, #0xb50]
    // 0xf79878: r0 = AllocateClosure()
    //     0xf79878: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf7987c: ldur            x1, [fp, #-0x18]
    // 0xf79880: mov             x2, x0
    // 0xf79884: r0 = addStatusListener()
    //     0xf79884: bl              #0x1254cc0  ; [dart:mixin_deduplication] _MixinApplication456&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::addStatusListener
    // 0xf79888: r0 = Null
    //     0xf79888: mov             x0, NULL
    // 0xf7988c: LeaveFrame
    //     0xf7988c: mov             SP, fp
    //     0xf79890: ldp             fp, lr, [SP], #0x10
    // 0xf79894: ret
    //     0xf79894: ret             
    // 0xf79898: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf79898: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf7989c: b               #0xf797a4
    // 0xf798a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf798a0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf798a4: SaveReg d0
    //     0xf798a4: str             q0, [SP, #-0x10]!
    // 0xf798a8: SaveReg r2
    //     0xf798a8: str             x2, [SP, #-8]!
    // 0xf798ac: r0 = AllocateDouble()
    //     0xf798ac: bl              #0x13df878  ; AllocateDoubleStub
    // 0xf798b0: RestoreReg r2
    //     0xf798b0: ldr             x2, [SP], #8
    // 0xf798b4: RestoreReg d0
    //     0xf798b4: ldr             q0, [SP], #0x10
    // 0xf798b8: b               #0xf797f4
  }
  [closure] void _animationStatusChanged(dynamic, AnimationStatus) {
    // ** addr: 0xf798bc, size: 0x3c
    // 0xf798bc: EnterFrame
    //     0xf798bc: stp             fp, lr, [SP, #-0x10]!
    //     0xf798c0: mov             fp, SP
    // 0xf798c4: ldr             x0, [fp, #0x18]
    // 0xf798c8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf798c8: ldur            w1, [x0, #0x17]
    // 0xf798cc: DecompressPointer r1
    //     0xf798cc: add             x1, x1, HEAP, lsl #32
    // 0xf798d0: CheckStackOverflow
    //     0xf798d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf798d4: cmp             SP, x16
    //     0xf798d8: b.ls            #0xf798f0
    // 0xf798dc: ldr             x2, [fp, #0x10]
    // 0xf798e0: r0 = _animationStatusChanged()
    //     0xf798e0: bl              #0xf798f8  ; [package:flutter/src/material/drawer.dart] DrawerControllerState::_animationStatusChanged
    // 0xf798e4: LeaveFrame
    //     0xf798e4: mov             SP, fp
    //     0xf798e8: ldp             fp, lr, [SP], #0x10
    // 0xf798ec: ret
    //     0xf798ec: ret             
    // 0xf798f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf798f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf798f4: b               #0xf798dc
  }
  _ _animationStatusChanged(/* No info */) {
    // ** addr: 0xf798f8, size: 0x84
    // 0xf798f8: EnterFrame
    //     0xf798f8: stp             fp, lr, [SP, #-0x10]!
    //     0xf798fc: mov             fp, SP
    // 0xf79900: AllocStack(0x8)
    //     0xf79900: sub             SP, SP, #8
    // 0xf79904: SetupParameters(DrawerControllerState this /* r1 => r0, fp-0x8 */)
    //     0xf79904: mov             x0, x1
    //     0xf79908: stur            x1, [fp, #-8]
    // 0xf7990c: CheckStackOverflow
    //     0xf7990c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf79910: cmp             SP, x16
    //     0xf79914: b.ls            #0xf79974
    // 0xf79918: LoadField: r1 = r2->field_7
    //     0xf79918: ldur            x1, [x2, #7]
    // 0xf7991c: cmp             x1, #1
    // 0xf79920: b.gt            #0xf79938
    // 0xf79924: cmp             x1, #0
    // 0xf79928: b.le            #0xf79964
    // 0xf7992c: mov             x1, x0
    // 0xf79930: r0 = _ensureHistoryEntry()
    //     0xf79930: bl              #0xd1ac24  ; [package:flutter/src/material/drawer.dart] DrawerControllerState::_ensureHistoryEntry
    // 0xf79934: b               #0xf79964
    // 0xf79938: cmp             x1, #2
    // 0xf7993c: b.gt            #0xf79964
    // 0xf79940: LoadField: r1 = r0->field_1b
    //     0xf79940: ldur            w1, [x0, #0x1b]
    // 0xf79944: DecompressPointer r1
    //     0xf79944: add             x1, x1, HEAP, lsl #32
    // 0xf79948: cmp             w1, NULL
    // 0xf7994c: b.ne            #0xf79958
    // 0xf79950: mov             x1, x0
    // 0xf79954: b               #0xf79960
    // 0xf79958: r0 = remove()
    //     0xf79958: bl              #0xeee288  ; [package:flutter/src/widgets/routes.dart] LocalHistoryEntry::remove
    // 0xf7995c: ldur            x1, [fp, #-8]
    // 0xf79960: StoreField: r1->field_1b = rNULL
    //     0xf79960: stur            NULL, [x1, #0x1b]
    // 0xf79964: r0 = Null
    //     0xf79964: mov             x0, NULL
    // 0xf79968: LeaveFrame
    //     0xf79968: mov             SP, fp
    //     0xf7996c: ldp             fp, lr, [SP], #0x10
    // 0xf79970: ret
    //     0xf79970: ret             
    // 0xf79974: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf79974: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf79978: b               #0xf79918
  }
  [closure] void _animationChanged(dynamic) {
    // ** addr: 0xf7997c, size: 0x38
    // 0xf7997c: EnterFrame
    //     0xf7997c: stp             fp, lr, [SP, #-0x10]!
    //     0xf79980: mov             fp, SP
    // 0xf79984: ldr             x0, [fp, #0x10]
    // 0xf79988: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf79988: ldur            w1, [x0, #0x17]
    // 0xf7998c: DecompressPointer r1
    //     0xf7998c: add             x1, x1, HEAP, lsl #32
    // 0xf79990: CheckStackOverflow
    //     0xf79990: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf79994: cmp             SP, x16
    //     0xf79998: b.ls            #0xf799ac
    // 0xf7999c: r0 = _animationChanged()
    //     0xf7999c: bl              #0xf799b4  ; [package:flutter/src/material/drawer.dart] DrawerControllerState::_animationChanged
    // 0xf799a0: LeaveFrame
    //     0xf799a0: mov             SP, fp
    //     0xf799a4: ldp             fp, lr, [SP], #0x10
    // 0xf799a8: ret
    //     0xf799a8: ret             
    // 0xf799ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf799ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf799b0: b               #0xf7999c
  }
  _ _animationChanged(/* No info */) {
    // ** addr: 0xf799b4, size: 0x54
    // 0xf799b4: EnterFrame
    //     0xf799b4: stp             fp, lr, [SP, #-0x10]!
    //     0xf799b8: mov             fp, SP
    // 0xf799bc: AllocStack(0x8)
    //     0xf799bc: sub             SP, SP, #8
    // 0xf799c0: SetupParameters(DrawerControllerState this /* r1 => r0, fp-0x8 */)
    //     0xf799c0: mov             x0, x1
    //     0xf799c4: stur            x1, [fp, #-8]
    // 0xf799c8: CheckStackOverflow
    //     0xf799c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf799cc: cmp             SP, x16
    //     0xf799d0: b.ls            #0xf79a00
    // 0xf799d4: r1 = Function '<anonymous closure>':.
    //     0xf799d4: add             x1, PP, #0x99, lsl #12  ; [pp+0x99b58] Function: [dart:ui] Shader::Shader._ (0x13cf838)
    //     0xf799d8: ldr             x1, [x1, #0xb58]
    // 0xf799dc: r2 = Null
    //     0xf799dc: mov             x2, NULL
    // 0xf799e0: r0 = AllocateClosure()
    //     0xf799e0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf799e4: ldur            x1, [fp, #-8]
    // 0xf799e8: mov             x2, x0
    // 0xf799ec: r0 = setState()
    //     0xf799ec: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xf799f0: r0 = Null
    //     0xf799f0: mov             x0, NULL
    // 0xf799f4: LeaveFrame
    //     0xf799f4: mov             SP, fp
    //     0xf799f8: ldp             fp, lr, [SP], #0x10
    // 0xf799fc: ret
    //     0xf799fc: ret             
    // 0xf79a00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf79a00: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf79a04: b               #0xf799d4
  }
  _ DrawerControllerState(/* No info */) {
    // ** addr: 0xfa1444, size: 0xcc
    // 0xfa1444: EnterFrame
    //     0xfa1444: stp             fp, lr, [SP, #-0x10]!
    //     0xfa1448: mov             fp, SP
    // 0xfa144c: AllocStack(0x10)
    //     0xfa144c: sub             SP, SP, #0x10
    // 0xfa1450: ldr             x2, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa1454: r0 = false
    //     0xfa1454: add             x0, NULL, #0x30  ; false
    // 0xfa1458: stur            x1, [fp, #-8]
    // 0xfa145c: CheckStackOverflow
    //     0xfa145c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa1460: cmp             SP, x16
    //     0xfa1464: b.ls            #0xfa1508
    // 0xfa1468: StoreField: r1->field_23 = r2
    //     0xfa1468: stur            w2, [x1, #0x23]
    // 0xfa146c: StoreField: r1->field_2b = r0
    //     0xfa146c: stur            w0, [x1, #0x2b]
    // 0xfa1470: r0 = FocusScopeNode()
    //     0xfa1470: bl              #0x83d1f8  ; AllocateFocusScopeNodeStub -> FocusScopeNode (size=0x74)
    // 0xfa1474: mov             x1, x0
    // 0xfa1478: stur            x0, [fp, #-0x10]
    // 0xfa147c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xfa147c: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xfa1480: r0 = FocusScopeNode()
    //     0xfa1480: bl              #0x83cdd8  ; [package:flutter/src/widgets/focus_manager.dart] FocusScopeNode::FocusScopeNode
    // 0xfa1484: ldur            x0, [fp, #-0x10]
    // 0xfa1488: ldur            x2, [fp, #-8]
    // 0xfa148c: StoreField: r2->field_1f = r0
    //     0xfa148c: stur            w0, [x2, #0x1f]
    //     0xfa1490: ldurb           w16, [x2, #-1]
    //     0xfa1494: ldurb           w17, [x0, #-1]
    //     0xfa1498: and             x16, x17, x16, lsr #2
    //     0xfa149c: tst             x16, HEAP, lsr #32
    //     0xfa14a0: b.eq            #0xfa14a8
    //     0xfa14a4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xfa14a8: r1 = <State<StatefulWidget>>
    //     0xfa14a8: ldr             x1, [PP, #0x4df8]  ; [pp+0x4df8] TypeArguments: <State<StatefulWidget>>
    // 0xfa14ac: r0 = LabeledGlobalKey()
    //     0xfa14ac: bl              #0x856cf8  ; AllocateLabeledGlobalKeyStub -> LabeledGlobalKey<X0 bound State> (size=0x10)
    // 0xfa14b0: ldur            x2, [fp, #-8]
    // 0xfa14b4: StoreField: r2->field_27 = r0
    //     0xfa14b4: stur            w0, [x2, #0x27]
    //     0xfa14b8: ldurb           w16, [x2, #-1]
    //     0xfa14bc: ldurb           w17, [x0, #-1]
    //     0xfa14c0: and             x16, x17, x16, lsr #2
    //     0xfa14c4: tst             x16, HEAP, lsr #32
    //     0xfa14c8: b.eq            #0xfa14d0
    //     0xfa14cc: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xfa14d0: r1 = <State<StatefulWidget>>
    //     0xfa14d0: ldr             x1, [PP, #0x4df8]  ; [pp+0x4df8] TypeArguments: <State<StatefulWidget>>
    // 0xfa14d4: r0 = LabeledGlobalKey()
    //     0xfa14d4: bl              #0x856cf8  ; AllocateLabeledGlobalKeyStub -> LabeledGlobalKey<X0 bound State> (size=0x10)
    // 0xfa14d8: ldur            x1, [fp, #-8]
    // 0xfa14dc: StoreField: r1->field_2f = r0
    //     0xfa14dc: stur            w0, [x1, #0x2f]
    //     0xfa14e0: ldurb           w16, [x1, #-1]
    //     0xfa14e4: ldurb           w17, [x0, #-1]
    //     0xfa14e8: and             x16, x17, x16, lsr #2
    //     0xfa14ec: tst             x16, HEAP, lsr #32
    //     0xfa14f0: b.eq            #0xfa14f8
    //     0xfa14f4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfa14f8: r0 = Null
    //     0xfa14f8: mov             x0, NULL
    // 0xfa14fc: LeaveFrame
    //     0xfa14fc: mov             SP, fp
    //     0xfa1500: ldp             fp, lr, [SP], #0x10
    // 0xfa1504: ret
    //     0xfa1504: ret             
    // 0xfa1508: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa1508: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa150c: b               #0xfa1468
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10dc8ac, size: 0x8c
    // 0x10dc8ac: EnterFrame
    //     0x10dc8ac: stp             fp, lr, [SP, #-0x10]!
    //     0x10dc8b0: mov             fp, SP
    // 0x10dc8b4: AllocStack(0x8)
    //     0x10dc8b4: sub             SP, SP, #8
    // 0x10dc8b8: SetupParameters(DrawerControllerState this /* r1 => r0, fp-0x8 */)
    //     0x10dc8b8: mov             x0, x1
    //     0x10dc8bc: stur            x1, [fp, #-8]
    // 0x10dc8c0: CheckStackOverflow
    //     0x10dc8c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10dc8c4: cmp             SP, x16
    //     0x10dc8c8: b.ls            #0x10dc924
    // 0x10dc8cc: LoadField: r1 = r0->field_1b
    //     0x10dc8cc: ldur            w1, [x0, #0x1b]
    // 0x10dc8d0: DecompressPointer r1
    //     0x10dc8d0: add             x1, x1, HEAP, lsl #32
    // 0x10dc8d4: cmp             w1, NULL
    // 0x10dc8d8: b.eq            #0x10dc8e4
    // 0x10dc8dc: r0 = remove()
    //     0x10dc8dc: bl              #0xeee288  ; [package:flutter/src/widgets/routes.dart] LocalHistoryEntry::remove
    // 0x10dc8e0: ldur            x0, [fp, #-8]
    // 0x10dc8e4: LoadField: r1 = r0->field_23
    //     0x10dc8e4: ldur            w1, [x0, #0x23]
    // 0x10dc8e8: DecompressPointer r1
    //     0x10dc8e8: add             x1, x1, HEAP, lsl #32
    // 0x10dc8ec: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10dc8f0: cmp             w1, w16
    // 0x10dc8f4: b.eq            #0x10dc92c
    // 0x10dc8f8: r0 = dispose()
    //     0x10dc8f8: bl              #0x9164f4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x10dc8fc: ldur            x0, [fp, #-8]
    // 0x10dc900: LoadField: r1 = r0->field_1f
    //     0x10dc900: ldur            w1, [x0, #0x1f]
    // 0x10dc904: DecompressPointer r1
    //     0x10dc904: add             x1, x1, HEAP, lsl #32
    // 0x10dc908: r0 = dispose()
    //     0x10dc908: bl              #0x10ec024  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::dispose
    // 0x10dc90c: ldur            x1, [fp, #-8]
    // 0x10dc910: r0 = dispose()
    //     0x10dc910: bl              #0x10dc938  ; [dart:mixin_deduplication] _MixinApplication34&State&SingleTickerProviderStateMixin::dispose
    // 0x10dc914: r0 = Null
    //     0x10dc914: mov             x0, NULL
    // 0x10dc918: LeaveFrame
    //     0x10dc918: mov             SP, fp
    //     0x10dc91c: ldp             fp, lr, [SP], #0x10
    // 0x10dc920: ret
    //     0x10dc920: ret             
    // 0x10dc924: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10dc924: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10dc928: b               #0x10dc8cc
    // 0x10dc92c: r9 = _controller
    //     0x10dc92c: add             x9, PP, #0x83, lsl #12  ; [pp+0x837c0] Field <DrawerControllerState._controller@82517151>: late (offset: 0x24)
    //     0x10dc930: ldr             x9, [x9, #0x7c0]
    // 0x10dc934: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x10dc934: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 6159, size: 0x30, field offset: 0xc
//   const constructor, 
class Drawer extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfb9a64, size: 0x4b4
    // 0xfb9a64: EnterFrame
    //     0xfb9a64: stp             fp, lr, [SP, #-0x10]!
    //     0xfb9a68: mov             fp, SP
    // 0xfb9a6c: AllocStack(0x80)
    //     0xfb9a6c: sub             SP, SP, #0x80
    // 0xfb9a70: SetupParameters(Drawer this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xfb9a70: mov             x0, x2
    //     0xfb9a74: stur            x2, [fp, #-0x10]
    //     0xfb9a78: mov             x2, x1
    //     0xfb9a7c: stur            x1, [fp, #-8]
    // 0xfb9a80: CheckStackOverflow
    //     0xfb9a80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb9a84: cmp             SP, x16
    //     0xfb9a88: b.ls            #0xfb9f10
    // 0xfb9a8c: mov             x1, x0
    // 0xfb9a90: r0 = of()
    //     0xfb9a90: bl              #0xd1a920  ; [package:flutter/src/material/drawer_theme.dart] DrawerTheme::of
    // 0xfb9a94: ldur            x1, [fp, #-0x10]
    // 0xfb9a98: stur            x0, [fp, #-0x18]
    // 0xfb9a9c: r0 = of()
    //     0xfb9a9c: bl              #0xd0bbf8  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0xfb9aa0: r1 = LoadClassIdInstr(r0)
    //     0xfb9aa0: ldur            x1, [x0, #-1]
    //     0xfb9aa4: ubfx            x1, x1, #0xc, #0x14
    // 0xfb9aa8: mov             x16, x0
    // 0xfb9aac: mov             x0, x1
    // 0xfb9ab0: mov             x1, x16
    // 0xfb9ab4: r0 = GDT[cid_x0 + 0x163a8]()
    //     0xfb9ab4: mov             x17, #0x63a8
    //     0xfb9ab8: movk            x17, #1, lsl #16
    //     0xfb9abc: add             lr, x0, x17
    //     0xfb9ac0: ldr             lr, [x21, lr, lsl #3]
    //     0xfb9ac4: blr             lr
    // 0xfb9ac8: ldur            x1, [fp, #-0x10]
    // 0xfb9acc: stur            x0, [fp, #-0x20]
    // 0xfb9ad0: r0 = of()
    //     0xfb9ad0: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfb9ad4: LoadField: r2 = r0->field_2f
    //     0xfb9ad4: ldur            w2, [x0, #0x2f]
    // 0xfb9ad8: DecompressPointer r2
    //     0xfb9ad8: add             x2, x2, HEAP, lsl #32
    // 0xfb9adc: ldur            x1, [fp, #-0x10]
    // 0xfb9ae0: stur            x2, [fp, #-0x28]
    // 0xfb9ae4: r0 = maybeOf()
    //     0xfb9ae4: bl              #0xfb9f30  ; [package:flutter/src/material/drawer.dart] DrawerController::maybeOf
    // 0xfb9ae8: cmp             w0, NULL
    // 0xfb9aec: b.ne            #0xfb9af8
    // 0xfb9af0: r1 = Null
    //     0xfb9af0: mov             x1, NULL
    // 0xfb9af4: b               #0xfb9b00
    // 0xfb9af8: r1 = Instance_DrawerAlignment
    //     0xfb9af8: add             x1, PP, #0x84, lsl #12  ; [pp+0x84bb0] Obj!DrawerAlignment@12c57e1
    //     0xfb9afc: ldr             x1, [x1, #0xbb0]
    // 0xfb9b00: ldur            x0, [fp, #-0x28]
    // 0xfb9b04: stur            x1, [fp, #-0x30]
    // 0xfb9b08: tbnz            w0, #4, #0xfb9b48
    // 0xfb9b0c: ldur            x0, [fp, #-0x10]
    // 0xfb9b10: r0 = _DrawerDefaultsM3()
    //     0xfb9b10: bl              #0xfb9f24  ; Allocate_DrawerDefaultsM3Stub -> _DrawerDefaultsM3 (size=0x34)
    // 0xfb9b14: mov             x1, x0
    // 0xfb9b18: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xfb9b1c: StoreField: r1->field_2f = r0
    //     0xfb9b1c: stur            w0, [x1, #0x2f]
    // 0xfb9b20: ldur            x0, [fp, #-0x10]
    // 0xfb9b24: StoreField: r1->field_2b = r0
    //     0xfb9b24: stur            w0, [x1, #0x2b]
    // 0xfb9b28: r0 = 1.000000
    //     0xfb9b28: ldr             x0, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xfb9b2c: StoreField: r1->field_f = r0
    //     0xfb9b2c: stur            w0, [x1, #0xf]
    // 0xfb9b30: r2 = Instance_Clip
    //     0xfb9b30: add             x2, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xfb9b34: ldr             x2, [x2, #0x850]
    // 0xfb9b38: StoreField: r1->field_27 = r2
    //     0xfb9b38: stur            w2, [x1, #0x27]
    // 0xfb9b3c: mov             x2, x1
    // 0xfb9b40: d0 = 1.000000
    //     0xfb9b40: fmov            d0, #1.00000000
    // 0xfb9b44: b               #0xfb9b84
    // 0xfb9b48: ldur            x0, [fp, #-0x10]
    // 0xfb9b4c: r2 = Instance_Clip
    //     0xfb9b4c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xfb9b50: ldr             x2, [x2, #0x850]
    // 0xfb9b54: r0 = _DrawerDefaultsM2()
    //     0xfb9b54: bl              #0xfb9f18  ; Allocate_DrawerDefaultsM2Stub -> _DrawerDefaultsM2 (size=0x30)
    // 0xfb9b58: mov             x1, x0
    // 0xfb9b5c: ldur            x0, [fp, #-0x10]
    // 0xfb9b60: StoreField: r1->field_2b = r0
    //     0xfb9b60: stur            w0, [x1, #0x2b]
    // 0xfb9b64: r0 = 16.000000
    //     0xfb9b64: add             x0, PP, #0x13, lsl #12  ; [pp+0x13df8] 16
    //     0xfb9b68: ldr             x0, [x0, #0xdf8]
    // 0xfb9b6c: StoreField: r1->field_f = r0
    //     0xfb9b6c: stur            w0, [x1, #0xf]
    // 0xfb9b70: r0 = Instance_Clip
    //     0xfb9b70: add             x0, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xfb9b74: ldr             x0, [x0, #0x850]
    // 0xfb9b78: StoreField: r1->field_27 = r0
    //     0xfb9b78: stur            w0, [x1, #0x27]
    // 0xfb9b7c: mov             x2, x1
    // 0xfb9b80: d0 = 16.000000
    //     0xfb9b80: fmov            d0, #16.00000000
    // 0xfb9b84: ldur            x0, [fp, #-0x30]
    // 0xfb9b88: stur            x2, [fp, #-0x10]
    // 0xfb9b8c: stur            d0, [fp, #-0x50]
    // 0xfb9b90: r16 = Instance_DrawerAlignment
    //     0xfb9b90: add             x16, PP, #0x99, lsl #12  ; [pp+0x99b60] Obj!DrawerAlignment@12c5801
    //     0xfb9b94: ldr             x16, [x16, #0xb60]
    // 0xfb9b98: cmp             w0, w16
    // 0xfb9b9c: b.eq            #0xfb9c3c
    // 0xfb9ba0: r0 = LoadClassIdInstr(r2)
    //     0xfb9ba0: ldur            x0, [x2, #-1]
    //     0xfb9ba4: ubfx            x0, x0, #0xc, #0x14
    // 0xfb9ba8: r17 = 5157
    //     0xfb9ba8: mov             x17, #0x1425
    // 0xfb9bac: cmp             x0, x17
    // 0xfb9bb0: b.eq            #0xfb9c24
    // 0xfb9bb4: r17 = 5158
    //     0xfb9bb4: mov             x17, #0x1426
    // 0xfb9bb8: cmp             x0, x17
    // 0xfb9bbc: b.ne            #0xfb9c20
    // 0xfb9bc0: mov             x1, x2
    // 0xfb9bc4: LoadField: r0 = r1->field_2f
    //     0xfb9bc4: ldur            w0, [x1, #0x2f]
    // 0xfb9bc8: DecompressPointer r0
    //     0xfb9bc8: add             x0, x0, HEAP, lsl #32
    // 0xfb9bcc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfb9bd0: cmp             w0, w16
    // 0xfb9bd4: b.ne            #0xfb9be4
    // 0xfb9bd8: r2 = direction
    //     0xfb9bd8: add             x2, PP, #0x26, lsl #12  ; [pp+0x263b8] Field <_DrawerDefaultsM3@82517151.direction>: late final (offset: 0x30)
    //     0xfb9bdc: ldr             x2, [x2, #0x3b8]
    // 0xfb9be0: r0 = InitLateFinalInstanceField()
    //     0xfb9be0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfb9be4: mov             x2, x0
    // 0xfb9be8: r1 = Instance_BorderRadiusDirectional
    //     0xfb9be8: add             x1, PP, #0x26, lsl #12  ; [pp+0x263c0] Obj!BorderRadiusDirectional@129e2d1
    //     0xfb9bec: ldr             x1, [x1, #0x3c0]
    // 0xfb9bf0: r0 = resolve()
    //     0xfb9bf0: bl              #0x1304c78  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusDirectional::resolve
    // 0xfb9bf4: stur            x0, [fp, #-0x28]
    // 0xfb9bf8: r0 = RoundedRectangleBorder()
    //     0xfb9bf8: bl              #0xd2ea90  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0xfb9bfc: mov             x1, x0
    // 0xfb9c00: ldur            x0, [fp, #-0x28]
    // 0xfb9c04: StoreField: r1->field_b = r0
    //     0xfb9c04: stur            w0, [x1, #0xb]
    // 0xfb9c08: r0 = Instance_BorderSide
    //     0xfb9c08: add             x0, PP, #0x18, lsl #12  ; [pp+0x18310] Obj!BorderSide@12b1b31
    //     0xfb9c0c: ldr             x0, [x0, #0x310]
    // 0xfb9c10: StoreField: r1->field_7 = r0
    //     0xfb9c10: stur            w0, [x1, #7]
    // 0xfb9c14: mov             x0, x1
    // 0xfb9c18: ldur            x2, [fp, #-0x10]
    // 0xfb9c1c: b               #0xfb9c2c
    // 0xfb9c20: ldur            x2, [fp, #-0x10]
    // 0xfb9c24: LoadField: r0 = r2->field_1b
    //     0xfb9c24: ldur            w0, [x2, #0x1b]
    // 0xfb9c28: DecompressPointer r0
    //     0xfb9c28: add             x0, x0, HEAP, lsl #32
    // 0xfb9c2c: mov             x16, x2
    // 0xfb9c30: mov             x2, x0
    // 0xfb9c34: mov             x0, x16
    // 0xfb9c38: b               #0xfb9cd8
    // 0xfb9c3c: r0 = Instance_BorderSide
    //     0xfb9c3c: add             x0, PP, #0x18, lsl #12  ; [pp+0x18310] Obj!BorderSide@12b1b31
    //     0xfb9c40: ldr             x0, [x0, #0x310]
    // 0xfb9c44: r1 = LoadClassIdInstr(r2)
    //     0xfb9c44: ldur            x1, [x2, #-1]
    //     0xfb9c48: ubfx            x1, x1, #0xc, #0x14
    // 0xfb9c4c: r17 = 5157
    //     0xfb9c4c: mov             x17, #0x1425
    // 0xfb9c50: cmp             x1, x17
    // 0xfb9c54: b.ne            #0xfb9c60
    // 0xfb9c58: mov             x0, x2
    // 0xfb9c5c: b               #0xfb9ccc
    // 0xfb9c60: r17 = 5158
    //     0xfb9c60: mov             x17, #0x1426
    // 0xfb9c64: cmp             x1, x17
    // 0xfb9c68: b.ne            #0xfb9cc8
    // 0xfb9c6c: mov             x1, x2
    // 0xfb9c70: LoadField: r0 = r1->field_2f
    //     0xfb9c70: ldur            w0, [x1, #0x2f]
    // 0xfb9c74: DecompressPointer r0
    //     0xfb9c74: add             x0, x0, HEAP, lsl #32
    // 0xfb9c78: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfb9c7c: cmp             w0, w16
    // 0xfb9c80: b.ne            #0xfb9c90
    // 0xfb9c84: r2 = direction
    //     0xfb9c84: add             x2, PP, #0x26, lsl #12  ; [pp+0x263b8] Field <_DrawerDefaultsM3@82517151.direction>: late final (offset: 0x30)
    //     0xfb9c88: ldr             x2, [x2, #0x3b8]
    // 0xfb9c8c: r0 = InitLateFinalInstanceField()
    //     0xfb9c8c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xfb9c90: mov             x2, x0
    // 0xfb9c94: r1 = Instance_BorderRadiusDirectional
    //     0xfb9c94: add             x1, PP, #0x26, lsl #12  ; [pp+0x263c8] Obj!BorderRadiusDirectional@129e2b1
    //     0xfb9c98: ldr             x1, [x1, #0x3c8]
    // 0xfb9c9c: r0 = resolve()
    //     0xfb9c9c: bl              #0x1304c78  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusDirectional::resolve
    // 0xfb9ca0: stur            x0, [fp, #-0x28]
    // 0xfb9ca4: r0 = RoundedRectangleBorder()
    //     0xfb9ca4: bl              #0xd2ea90  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0xfb9ca8: mov             x1, x0
    // 0xfb9cac: ldur            x0, [fp, #-0x28]
    // 0xfb9cb0: StoreField: r1->field_b = r0
    //     0xfb9cb0: stur            w0, [x1, #0xb]
    // 0xfb9cb4: r0 = Instance_BorderSide
    //     0xfb9cb4: add             x0, PP, #0x18, lsl #12  ; [pp+0x18310] Obj!BorderSide@12b1b31
    //     0xfb9cb8: ldr             x0, [x0, #0x310]
    // 0xfb9cbc: StoreField: r1->field_7 = r0
    //     0xfb9cbc: stur            w0, [x1, #7]
    // 0xfb9cc0: ldur            x0, [fp, #-0x10]
    // 0xfb9cc4: b               #0xfb9cd4
    // 0xfb9cc8: ldur            x0, [fp, #-0x10]
    // 0xfb9ccc: LoadField: r1 = r0->field_1f
    //     0xfb9ccc: ldur            w1, [x0, #0x1f]
    // 0xfb9cd0: DecompressPointer r1
    //     0xfb9cd0: add             x1, x1, HEAP, lsl #32
    // 0xfb9cd4: mov             x2, x1
    // 0xfb9cd8: ldur            x1, [fp, #-0x18]
    // 0xfb9cdc: stur            x2, [fp, #-0x28]
    // 0xfb9ce0: LoadField: r3 = r1->field_23
    //     0xfb9ce0: ldur            w3, [x1, #0x23]
    // 0xfb9ce4: DecompressPointer r3
    //     0xfb9ce4: add             x3, x3, HEAP, lsl #32
    // 0xfb9ce8: cmp             w3, NULL
    // 0xfb9cec: b.ne            #0xfb9cfc
    // 0xfb9cf0: d0 = 304.000000
    //     0xfb9cf0: add             x17, PP, #0x99, lsl #12  ; [pp+0x99b08] IMM: double(304) from 0x4073000000000000
    //     0xfb9cf4: ldr             d0, [x17, #0xb08]
    // 0xfb9cf8: b               #0xfb9d00
    // 0xfb9cfc: LoadField: d0 = r3->field_7
    //     0xfb9cfc: ldur            d0, [x3, #7]
    // 0xfb9d00: stur            d0, [fp, #-0x58]
    // 0xfb9d04: r0 = BoxConstraints()
    //     0xfb9d04: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xfb9d08: ldur            d0, [fp, #-0x58]
    // 0xfb9d0c: stur            x0, [fp, #-0x30]
    // 0xfb9d10: StoreField: r0->field_7 = d0
    //     0xfb9d10: stur            d0, [x0, #7]
    // 0xfb9d14: StoreField: r0->field_f = d0
    //     0xfb9d14: stur            d0, [x0, #0xf]
    // 0xfb9d18: d0 = inf
    //     0xfb9d18: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xfb9d1c: ArrayStore: r0[0] = d0  ; List_8
    //     0xfb9d1c: stur            d0, [x0, #0x17]
    // 0xfb9d20: StoreField: r0->field_1f = d0
    //     0xfb9d20: stur            d0, [x0, #0x1f]
    // 0xfb9d24: ldur            x2, [fp, #-0x18]
    // 0xfb9d28: LoadField: r1 = r2->field_f
    //     0xfb9d28: ldur            w1, [x2, #0xf]
    // 0xfb9d2c: DecompressPointer r1
    //     0xfb9d2c: add             x1, x1, HEAP, lsl #32
    // 0xfb9d30: cmp             w1, NULL
    // 0xfb9d34: b.ne            #0xfb9d40
    // 0xfb9d38: ldur            d0, [fp, #-0x50]
    // 0xfb9d3c: b               #0xfb9d44
    // 0xfb9d40: LoadField: d0 = r1->field_7
    //     0xfb9d40: ldur            d0, [x1, #7]
    // 0xfb9d44: ldur            x3, [fp, #-0x10]
    // 0xfb9d48: stur            d0, [fp, #-0x50]
    // 0xfb9d4c: r4 = LoadClassIdInstr(r3)
    //     0xfb9d4c: ldur            x4, [x3, #-1]
    //     0xfb9d50: ubfx            x4, x4, #0xc, #0x14
    // 0xfb9d54: stur            x4, [fp, #-0x38]
    // 0xfb9d58: r17 = 5157
    //     0xfb9d58: mov             x17, #0x1425
    // 0xfb9d5c: cmp             x4, x17
    // 0xfb9d60: b.ne            #0xfb9d74
    // 0xfb9d64: LoadField: r1 = r3->field_13
    //     0xfb9d64: ldur            w1, [x3, #0x13]
    // 0xfb9d68: DecompressPointer r1
    //     0xfb9d68: add             x1, x1, HEAP, lsl #32
    // 0xfb9d6c: mov             x0, x4
    // 0xfb9d70: b               #0xfb9da8
    // 0xfb9d74: r17 = 5158
    //     0xfb9d74: mov             x17, #0x1426
    // 0xfb9d78: cmp             x4, x17
    // 0xfb9d7c: b.ne            #0xfb9d90
    // 0xfb9d80: mov             x0, x4
    // 0xfb9d84: r1 = Instance_Color
    //     0xfb9d84: add             x1, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xfb9d88: ldr             x1, [x1, #0x810]
    // 0xfb9d8c: b               #0xfb9da8
    // 0xfb9d90: LoadField: r1 = r3->field_2b
    //     0xfb9d90: ldur            w1, [x3, #0x2b]
    // 0xfb9d94: DecompressPointer r1
    //     0xfb9d94: add             x1, x1, HEAP, lsl #32
    // 0xfb9d98: r0 = of()
    //     0xfb9d98: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfb9d9c: LoadField: r1 = r0->field_6f
    //     0xfb9d9c: ldur            w1, [x0, #0x6f]
    // 0xfb9da0: DecompressPointer r1
    //     0xfb9da0: add             x1, x1, HEAP, lsl #32
    // 0xfb9da4: ldur            x0, [fp, #-0x38]
    // 0xfb9da8: stur            x1, [fp, #-0x48]
    // 0xfb9dac: r17 = 5157
    //     0xfb9dac: mov             x17, #0x1425
    // 0xfb9db0: cmp             x0, x17
    // 0xfb9db4: b.eq            #0xfb9dd0
    // 0xfb9db8: r17 = 5158
    //     0xfb9db8: mov             x17, #0x1426
    // 0xfb9dbc: cmp             x0, x17
    // 0xfb9dc0: b.ne            #0xfb9dd0
    // 0xfb9dc4: r2 = Instance_Color
    //     0xfb9dc4: add             x2, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xfb9dc8: ldr             x2, [x2, #0x810]
    // 0xfb9dcc: b               #0xfb9ddc
    // 0xfb9dd0: ldur            x0, [fp, #-0x10]
    // 0xfb9dd4: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xfb9dd4: ldur            w2, [x0, #0x17]
    // 0xfb9dd8: DecompressPointer r2
    //     0xfb9dd8: add             x2, x2, HEAP, lsl #32
    // 0xfb9ddc: ldur            x0, [fp, #-0x28]
    // 0xfb9de0: stur            x2, [fp, #-0x40]
    // 0xfb9de4: cmp             w0, NULL
    // 0xfb9de8: b.eq            #0xfb9e18
    // 0xfb9dec: ldur            x3, [fp, #-0x18]
    // 0xfb9df0: LoadField: r4 = r3->field_27
    //     0xfb9df0: ldur            w4, [x3, #0x27]
    // 0xfb9df4: DecompressPointer r4
    //     0xfb9df4: add             x4, x4, HEAP, lsl #32
    // 0xfb9df8: cmp             w4, NULL
    // 0xfb9dfc: b.ne            #0xfb9e0c
    // 0xfb9e00: r3 = Instance_Clip
    //     0xfb9e00: add             x3, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xfb9e04: ldr             x3, [x3, #0x850]
    // 0xfb9e08: b               #0xfb9e10
    // 0xfb9e0c: mov             x3, x4
    // 0xfb9e10: mov             x5, x3
    // 0xfb9e14: b               #0xfb9e20
    // 0xfb9e18: r5 = Instance_Clip
    //     0xfb9e18: add             x5, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xfb9e1c: ldr             x5, [x5, #0x840]
    // 0xfb9e20: ldur            x4, [fp, #-8]
    // 0xfb9e24: ldur            x3, [fp, #-0x30]
    // 0xfb9e28: ldur            d0, [fp, #-0x50]
    // 0xfb9e2c: stur            x5, [fp, #-0x18]
    // 0xfb9e30: LoadField: r6 = r4->field_23
    //     0xfb9e30: ldur            w6, [x4, #0x23]
    // 0xfb9e34: DecompressPointer r6
    //     0xfb9e34: add             x6, x6, HEAP, lsl #32
    // 0xfb9e38: stur            x6, [fp, #-0x10]
    // 0xfb9e3c: r0 = Material()
    //     0xfb9e3c: bl              #0x8a54b0  ; AllocateMaterialStub -> Material (size=0x44)
    // 0xfb9e40: mov             x1, x0
    // 0xfb9e44: r0 = Instance_MaterialType
    //     0xfb9e44: add             x0, PP, #0x17, lsl #12  ; [pp+0x17210] Obj!MaterialType@12c5341
    //     0xfb9e48: ldr             x0, [x0, #0x210]
    // 0xfb9e4c: stur            x1, [fp, #-8]
    // 0xfb9e50: StoreField: r1->field_f = r0
    //     0xfb9e50: stur            w0, [x1, #0xf]
    // 0xfb9e54: ldur            d0, [fp, #-0x50]
    // 0xfb9e58: ArrayStore: r1[0] = d0  ; List_8
    //     0xfb9e58: stur            d0, [x1, #0x17]
    // 0xfb9e5c: r0 = Instance_Color
    //     0xfb9e5c: add             x0, PP, #0x83, lsl #12  ; [pp+0x83790] Obj!Color@12a2eb1
    //     0xfb9e60: ldr             x0, [x0, #0x790]
    // 0xfb9e64: StoreField: r1->field_1f = r0
    //     0xfb9e64: stur            w0, [x1, #0x1f]
    // 0xfb9e68: ldur            x0, [fp, #-0x48]
    // 0xfb9e6c: StoreField: r1->field_23 = r0
    //     0xfb9e6c: stur            w0, [x1, #0x23]
    // 0xfb9e70: ldur            x0, [fp, #-0x40]
    // 0xfb9e74: StoreField: r1->field_27 = r0
    //     0xfb9e74: stur            w0, [x1, #0x27]
    // 0xfb9e78: ldur            x0, [fp, #-0x28]
    // 0xfb9e7c: StoreField: r1->field_2f = r0
    //     0xfb9e7c: stur            w0, [x1, #0x2f]
    // 0xfb9e80: r0 = true
    //     0xfb9e80: add             x0, NULL, #0x20  ; true
    // 0xfb9e84: StoreField: r1->field_33 = r0
    //     0xfb9e84: stur            w0, [x1, #0x33]
    // 0xfb9e88: ldur            x0, [fp, #-0x18]
    // 0xfb9e8c: StoreField: r1->field_37 = r0
    //     0xfb9e8c: stur            w0, [x1, #0x37]
    // 0xfb9e90: r0 = Instance_Duration
    //     0xfb9e90: add             x0, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xfb9e94: ldr             x0, [x0, #0x318]
    // 0xfb9e98: StoreField: r1->field_3b = r0
    //     0xfb9e98: stur            w0, [x1, #0x3b]
    // 0xfb9e9c: ldur            x0, [fp, #-0x10]
    // 0xfb9ea0: StoreField: r1->field_b = r0
    //     0xfb9ea0: stur            w0, [x1, #0xb]
    // 0xfb9ea4: r0 = false
    //     0xfb9ea4: add             x0, NULL, #0x30  ; false
    // 0xfb9ea8: StoreField: r1->field_13 = r0
    //     0xfb9ea8: stur            w0, [x1, #0x13]
    // 0xfb9eac: r0 = ConstrainedBox()
    //     0xfb9eac: bl              #0xd0a588  ; AllocateConstrainedBoxStub -> ConstrainedBox (size=0x14)
    // 0xfb9eb0: mov             x1, x0
    // 0xfb9eb4: ldur            x0, [fp, #-0x30]
    // 0xfb9eb8: stur            x1, [fp, #-0x10]
    // 0xfb9ebc: StoreField: r1->field_f = r0
    //     0xfb9ebc: stur            w0, [x1, #0xf]
    // 0xfb9ec0: ldur            x0, [fp, #-8]
    // 0xfb9ec4: StoreField: r1->field_b = r0
    //     0xfb9ec4: stur            w0, [x1, #0xb]
    // 0xfb9ec8: r0 = Semantics()
    //     0xfb9ec8: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xfb9ecc: stur            x0, [fp, #-8]
    // 0xfb9ed0: r16 = true
    //     0xfb9ed0: add             x16, NULL, #0x20  ; true
    // 0xfb9ed4: r30 = true
    //     0xfb9ed4: add             lr, NULL, #0x20  ; true
    // 0xfb9ed8: stp             lr, x16, [SP, #0x18]
    // 0xfb9edc: r16 = true
    //     0xfb9edc: add             x16, NULL, #0x20  ; true
    // 0xfb9ee0: ldur            lr, [fp, #-0x20]
    // 0xfb9ee4: stp             lr, x16, [SP, #8]
    // 0xfb9ee8: ldur            x16, [fp, #-0x10]
    // 0xfb9eec: str             x16, [SP]
    // 0xfb9ef0: mov             x1, x0
    // 0xfb9ef4: r4 = const [0, 0x6, 0x5, 0x1, child, 0x5, explicitChildNodes, 0x3, label, 0x4, namesRoute, 0x2, scopesRoute, 0x1, null]
    //     0xfb9ef4: add             x4, PP, #0x99, lsl #12  ; [pp+0x99b68] List(15) [0, 0x6, 0x5, 0x1, "child", 0x5, "explicitChildNodes", 0x3, "label", 0x4, "namesRoute", 0x2, "scopesRoute", 0x1, Null]
    //     0xfb9ef8: ldr             x4, [x4, #0xb68]
    // 0xfb9efc: r0 = Semantics()
    //     0xfb9efc: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xfb9f00: ldur            x0, [fp, #-8]
    // 0xfb9f04: LeaveFrame
    //     0xfb9f04: mov             SP, fp
    //     0xfb9f08: ldp             fp, lr, [SP], #0x10
    // 0xfb9f0c: ret
    //     0xfb9f0c: ret             
    // 0xfb9f10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb9f10: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb9f14: b               #0xfb9a8c
  }
}

// class id: 6484, size: 0x30, field offset: 0xc
//   const constructor, 
class DrawerController extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa13fc, size: 0x48
    // 0xfa13fc: EnterFrame
    //     0xfa13fc: stp             fp, lr, [SP, #-0x10]!
    //     0xfa1400: mov             fp, SP
    // 0xfa1404: AllocStack(0x8)
    //     0xfa1404: sub             SP, SP, #8
    // 0xfa1408: CheckStackOverflow
    //     0xfa1408: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa140c: cmp             SP, x16
    //     0xfa1410: b.ls            #0xfa143c
    // 0xfa1414: r1 = <DrawerController>
    //     0xfa1414: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8ff18] TypeArguments: <DrawerController>
    //     0xfa1418: ldr             x1, [x1, #0xf18]
    // 0xfa141c: r0 = DrawerControllerState()
    //     0xfa141c: bl              #0xfa1510  ; AllocateDrawerControllerStateStub -> DrawerControllerState (size=0x34)
    // 0xfa1420: mov             x1, x0
    // 0xfa1424: stur            x0, [fp, #-8]
    // 0xfa1428: r0 = DrawerControllerState()
    //     0xfa1428: bl              #0xfa1444  ; [package:flutter/src/material/drawer.dart] DrawerControllerState::DrawerControllerState
    // 0xfa142c: ldur            x0, [fp, #-8]
    // 0xfa1430: LeaveFrame
    //     0xfa1430: mov             SP, fp
    //     0xfa1434: ldp             fp, lr, [SP], #0x10
    // 0xfa1438: ret
    //     0xfa1438: ret             
    // 0xfa143c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa143c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa1440: b               #0xfa1414
  }
  static _ maybeOf(/* No info */) {
    // ** addr: 0xfb9f30, size: 0x5c
    // 0xfb9f30: EnterFrame
    //     0xfb9f30: stp             fp, lr, [SP, #-0x10]!
    //     0xfb9f34: mov             fp, SP
    // 0xfb9f38: AllocStack(0x10)
    //     0xfb9f38: sub             SP, SP, #0x10
    // 0xfb9f3c: CheckStackOverflow
    //     0xfb9f3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb9f40: cmp             SP, x16
    //     0xfb9f44: b.ls            #0xfb9f84
    // 0xfb9f48: r16 = <_DrawerControllerScope>
    //     0xfb9f48: add             x16, PP, #0x99, lsl #12  ; [pp+0x99b70] TypeArguments: <_DrawerControllerScope>
    //     0xfb9f4c: ldr             x16, [x16, #0xb70]
    // 0xfb9f50: stp             x1, x16, [SP]
    // 0xfb9f54: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xfb9f54: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xfb9f58: r0 = dependOnInheritedWidgetOfExactType()
    //     0xfb9f58: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xfb9f5c: cmp             w0, NULL
    // 0xfb9f60: b.ne            #0xfb9f6c
    // 0xfb9f64: r0 = Null
    //     0xfb9f64: mov             x0, NULL
    // 0xfb9f68: b               #0xfb9f78
    // 0xfb9f6c: LoadField: r1 = r0->field_f
    //     0xfb9f6c: ldur            w1, [x0, #0xf]
    // 0xfb9f70: DecompressPointer r1
    //     0xfb9f70: add             x1, x1, HEAP, lsl #32
    // 0xfb9f74: mov             x0, x1
    // 0xfb9f78: LeaveFrame
    //     0xfb9f78: mov             SP, fp
    //     0xfb9f7c: ldp             fp, lr, [SP], #0x10
    // 0xfb9f80: ret
    //     0xfb9f80: ret             
    // 0xfb9f84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb9f84: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb9f88: b               #0xfb9f48
  }
}

// class id: 6815, size: 0x14, field offset: 0x10
//   const constructor, 
class _DrawerControllerScope extends InheritedWidget {

  _ updateShouldNotify(/* No info */) {
    // ** addr: 0xc00e4c, size: 0x8c
    // 0xc00e4c: EnterFrame
    //     0xc00e4c: stp             fp, lr, [SP, #-0x10]!
    //     0xc00e50: mov             fp, SP
    // 0xc00e54: AllocStack(0x10)
    //     0xc00e54: sub             SP, SP, #0x10
    // 0xc00e58: SetupParameters(_DrawerControllerScope this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xc00e58: mov             x0, x2
    //     0xc00e5c: mov             x4, x1
    //     0xc00e60: mov             x3, x2
    //     0xc00e64: stur            x1, [fp, #-8]
    //     0xc00e68: stur            x2, [fp, #-0x10]
    // 0xc00e6c: r2 = Null
    //     0xc00e6c: mov             x2, NULL
    // 0xc00e70: r1 = Null
    //     0xc00e70: mov             x1, NULL
    // 0xc00e74: r4 = 60
    //     0xc00e74: mov             x4, #0x3c
    // 0xc00e78: branchIfSmi(r0, 0xc00e84)
    //     0xc00e78: tbz             w0, #0, #0xc00e84
    // 0xc00e7c: r4 = LoadClassIdInstr(r0)
    //     0xc00e7c: ldur            x4, [x0, #-1]
    //     0xc00e80: ubfx            x4, x4, #0xc, #0x14
    // 0xc00e84: r17 = 6815
    //     0xc00e84: mov             x17, #0x1a9f
    // 0xc00e88: cmp             x4, x17
    // 0xc00e8c: b.eq            #0xc00ea4
    // 0xc00e90: r8 = _DrawerControllerScope
    //     0xc00e90: add             x8, PP, #0xa3, lsl #12  ; [pp+0xa3d50] Type: _DrawerControllerScope
    //     0xc00e94: ldr             x8, [x8, #0xd50]
    // 0xc00e98: r3 = Null
    //     0xc00e98: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa3d58] Null
    //     0xc00e9c: ldr             x3, [x3, #0xd58]
    // 0xc00ea0: r0 = DefaultTypeTest()
    //     0xc00ea0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xc00ea4: ldur            x1, [fp, #-8]
    // 0xc00ea8: LoadField: r2 = r1->field_f
    //     0xc00ea8: ldur            w2, [x1, #0xf]
    // 0xc00eac: DecompressPointer r2
    //     0xc00eac: add             x2, x2, HEAP, lsl #32
    // 0xc00eb0: ldur            x1, [fp, #-0x10]
    // 0xc00eb4: LoadField: r3 = r1->field_f
    //     0xc00eb4: ldur            w3, [x1, #0xf]
    // 0xc00eb8: DecompressPointer r3
    //     0xc00eb8: add             x3, x3, HEAP, lsl #32
    // 0xc00ebc: cmp             w2, w3
    // 0xc00ec0: r16 = true
    //     0xc00ec0: add             x16, NULL, #0x20  ; true
    // 0xc00ec4: r17 = false
    //     0xc00ec4: add             x17, NULL, #0x30  ; false
    // 0xc00ec8: csel            x0, x16, x17, ne
    // 0xc00ecc: LeaveFrame
    //     0xc00ecc: mov             SP, fp
    //     0xc00ed0: ldp             fp, lr, [SP], #0x10
    // 0xc00ed4: ret
    //     0xc00ed4: ret             
  }
}

// class id: 8289, size: 0x14, field offset: 0x14
enum DrawerAlignment extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11aa030, size: 0x64
    // 0x11aa030: EnterFrame
    //     0x11aa030: stp             fp, lr, [SP, #-0x10]!
    //     0x11aa034: mov             fp, SP
    // 0x11aa038: AllocStack(0x10)
    //     0x11aa038: sub             SP, SP, #0x10
    // 0x11aa03c: SetupParameters(DrawerAlignment this /* r1 => r0, fp-0x8 */)
    //     0x11aa03c: mov             x0, x1
    //     0x11aa040: stur            x1, [fp, #-8]
    // 0x11aa044: CheckStackOverflow
    //     0x11aa044: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11aa048: cmp             SP, x16
    //     0x11aa04c: b.ls            #0x11aa08c
    // 0x11aa050: r1 = Null
    //     0x11aa050: mov             x1, NULL
    // 0x11aa054: r2 = 4
    //     0x11aa054: mov             x2, #4
    // 0x11aa058: r0 = AllocateArray()
    //     0x11aa058: bl              #0x13df928  ; AllocateArrayStub
    // 0x11aa05c: r16 = "DrawerAlignment."
    //     0x11aa05c: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8ff10] "DrawerAlignment."
    //     0x11aa060: ldr             x16, [x16, #0xf10]
    // 0x11aa064: StoreField: r0->field_f = r16
    //     0x11aa064: stur            w16, [x0, #0xf]
    // 0x11aa068: ldur            x1, [fp, #-8]
    // 0x11aa06c: LoadField: r2 = r1->field_f
    //     0x11aa06c: ldur            w2, [x1, #0xf]
    // 0x11aa070: DecompressPointer r2
    //     0x11aa070: add             x2, x2, HEAP, lsl #32
    // 0x11aa074: StoreField: r0->field_13 = r2
    //     0x11aa074: stur            w2, [x0, #0x13]
    // 0x11aa078: str             x0, [SP]
    // 0x11aa07c: r0 = _interpolate()
    //     0x11aa07c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11aa080: LeaveFrame
    //     0x11aa080: mov             SP, fp
    //     0x11aa084: ldp             fp, lr, [SP], #0x10
    // 0x11aa088: ret
    //     0x11aa088: ret             
    // 0x11aa08c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11aa08c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11aa090: b               #0x11aa050
  }
}
