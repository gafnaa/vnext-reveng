// lib: , url: package:flutter/src/material/material_localizations.dart

// class id: 1048913, size: 0x8
class :: {
}

// class id: 3001, size: 0x8, field offset: 0x8
//   const constructor, 
class DefaultMaterialLocalizations extends Object
    implements MaterialLocalizations {

  _ formatCompactDate(/* No info */) {
    // ** addr: 0xa0e564, size: 0x194
    // 0xa0e564: EnterFrame
    //     0xa0e564: stp             fp, lr, [SP, #-0x10]!
    //     0xa0e568: mov             fp, SP
    // 0xa0e56c: AllocStack(0x20)
    //     0xa0e56c: sub             SP, SP, #0x20
    // 0xa0e570: SetupParameters(DefaultMaterialLocalizations this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xa0e570: mov             x0, x2
    //     0xa0e574: stur            x2, [fp, #-0x10]
    //     0xa0e578: mov             x2, x1
    //     0xa0e57c: stur            x1, [fp, #-8]
    // 0xa0e580: CheckStackOverflow
    //     0xa0e580: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xa0e584: cmp             SP, x16
    //     0xa0e588: b.ls            #0xa0e6e4
    // 0xa0e58c: mov             x1, x0
    // 0xa0e590: r0 = _parts()
    //     0xa0e590: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xa0e594: mov             x2, x0
    // 0xa0e598: LoadField: r0 = r2->field_b
    //     0xa0e598: ldur            w0, [x2, #0xb]
    // 0xa0e59c: r1 = LoadInt32Instr(r0)
    //     0xa0e59c: sbfx            x1, x0, #1, #0x1f
    // 0xa0e5a0: mov             x0, x1
    // 0xa0e5a4: r1 = 7
    //     0xa0e5a4: mov             x1, #7
    // 0xa0e5a8: cmp             x1, x0
    // 0xa0e5ac: b.hs            #0xa0e6ec
    // 0xa0e5b0: LoadField: r0 = r2->field_2b
    //     0xa0e5b0: ldur            w0, [x2, #0x2b]
    // 0xa0e5b4: DecompressPointer r0
    //     0xa0e5b4: add             x0, x0, HEAP, lsl #32
    // 0xa0e5b8: r2 = LoadInt32Instr(r0)
    //     0xa0e5b8: sbfx            x2, x0, #1, #0x1f
    //     0xa0e5bc: tbz             w0, #0, #0xa0e5c4
    //     0xa0e5c0: ldur            x2, [x0, #7]
    // 0xa0e5c4: ldur            x1, [fp, #-8]
    // 0xa0e5c8: r0 = _formatTwoDigitZeroPad()
    //     0xa0e5c8: bl              #0xa0e6f8  ; [package:flutter/src/material/material_localizations.dart] DefaultMaterialLocalizations::_formatTwoDigitZeroPad
    // 0xa0e5cc: ldur            x1, [fp, #-0x10]
    // 0xa0e5d0: stur            x0, [fp, #-0x18]
    // 0xa0e5d4: r0 = _parts()
    //     0xa0e5d4: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xa0e5d8: mov             x2, x0
    // 0xa0e5dc: LoadField: r0 = r2->field_b
    //     0xa0e5dc: ldur            w0, [x2, #0xb]
    // 0xa0e5e0: r1 = LoadInt32Instr(r0)
    //     0xa0e5e0: sbfx            x1, x0, #1, #0x1f
    // 0xa0e5e4: mov             x0, x1
    // 0xa0e5e8: r1 = 5
    //     0xa0e5e8: mov             x1, #5
    // 0xa0e5ec: cmp             x1, x0
    // 0xa0e5f0: b.hs            #0xa0e6f0
    // 0xa0e5f4: LoadField: r0 = r2->field_23
    //     0xa0e5f4: ldur            w0, [x2, #0x23]
    // 0xa0e5f8: DecompressPointer r0
    //     0xa0e5f8: add             x0, x0, HEAP, lsl #32
    // 0xa0e5fc: r2 = LoadInt32Instr(r0)
    //     0xa0e5fc: sbfx            x2, x0, #1, #0x1f
    //     0xa0e600: tbz             w0, #0, #0xa0e608
    //     0xa0e604: ldur            x2, [x0, #7]
    // 0xa0e608: ldur            x1, [fp, #-8]
    // 0xa0e60c: r0 = _formatTwoDigitZeroPad()
    //     0xa0e60c: bl              #0xa0e6f8  ; [package:flutter/src/material/material_localizations.dart] DefaultMaterialLocalizations::_formatTwoDigitZeroPad
    // 0xa0e610: ldur            x1, [fp, #-0x10]
    // 0xa0e614: stur            x0, [fp, #-8]
    // 0xa0e618: r0 = _parts()
    //     0xa0e618: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xa0e61c: mov             x2, x0
    // 0xa0e620: LoadField: r0 = r2->field_b
    //     0xa0e620: ldur            w0, [x2, #0xb]
    // 0xa0e624: r1 = LoadInt32Instr(r0)
    //     0xa0e624: sbfx            x1, x0, #1, #0x1f
    // 0xa0e628: mov             x0, x1
    // 0xa0e62c: r1 = 8
    //     0xa0e62c: mov             x1, #8
    // 0xa0e630: cmp             x1, x0
    // 0xa0e634: b.hs            #0xa0e6f4
    // 0xa0e638: LoadField: r0 = r2->field_2f
    //     0xa0e638: ldur            w0, [x2, #0x2f]
    // 0xa0e63c: DecompressPointer r0
    //     0xa0e63c: add             x0, x0, HEAP, lsl #32
    // 0xa0e640: r1 = 60
    //     0xa0e640: mov             x1, #0x3c
    // 0xa0e644: branchIfSmi(r0, 0xa0e650)
    //     0xa0e644: tbz             w0, #0, #0xa0e650
    // 0xa0e648: r1 = LoadClassIdInstr(r0)
    //     0xa0e648: ldur            x1, [x0, #-1]
    //     0xa0e64c: ubfx            x1, x1, #0xc, #0x14
    // 0xa0e650: str             x0, [SP]
    // 0xa0e654: mov             x0, x1
    // 0xa0e658: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa0e658: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa0e65c: r0 = GDT[cid_x0 + 0x91c1]()
    //     0xa0e65c: mov             x17, #0x91c1
    //     0xa0e660: add             lr, x0, x17
    //     0xa0e664: ldr             lr, [x21, lr, lsl #3]
    //     0xa0e668: blr             lr
    // 0xa0e66c: r1 = LoadClassIdInstr(r0)
    //     0xa0e66c: ldur            x1, [x0, #-1]
    //     0xa0e670: ubfx            x1, x1, #0xc, #0x14
    // 0xa0e674: mov             x16, x0
    // 0xa0e678: mov             x0, x1
    // 0xa0e67c: mov             x1, x16
    // 0xa0e680: r2 = 4
    //     0xa0e680: mov             x2, #4
    // 0xa0e684: r3 = "0"
    //     0xa0e684: ldr             x3, [PP, #0x47e8]  ; [pp+0x47e8] "0"
    // 0xa0e688: r0 = GDT[cid_x0 + -0xff6]()
    //     0xa0e688: sub             lr, x0, #0xff6
    //     0xa0e68c: ldr             lr, [x21, lr, lsl #3]
    //     0xa0e690: blr             lr
    // 0xa0e694: r1 = Null
    //     0xa0e694: mov             x1, NULL
    // 0xa0e698: r2 = 10
    //     0xa0e698: mov             x2, #0xa
    // 0xa0e69c: stur            x0, [fp, #-0x10]
    // 0xa0e6a0: r0 = AllocateArray()
    //     0xa0e6a0: bl              #0x13df928  ; AllocateArrayStub
    // 0xa0e6a4: mov             x1, x0
    // 0xa0e6a8: ldur            x0, [fp, #-0x18]
    // 0xa0e6ac: StoreField: r1->field_f = r0
    //     0xa0e6ac: stur            w0, [x1, #0xf]
    // 0xa0e6b0: r16 = "/"
    //     0xa0e6b0: ldr             x16, [PP, #0xfe0]  ; [pp+0xfe0] "/"
    // 0xa0e6b4: StoreField: r1->field_13 = r16
    //     0xa0e6b4: stur            w16, [x1, #0x13]
    // 0xa0e6b8: ldur            x0, [fp, #-8]
    // 0xa0e6bc: ArrayStore: r1[0] = r0  ; List_4
    //     0xa0e6bc: stur            w0, [x1, #0x17]
    // 0xa0e6c0: r16 = "/"
    //     0xa0e6c0: ldr             x16, [PP, #0xfe0]  ; [pp+0xfe0] "/"
    // 0xa0e6c4: StoreField: r1->field_1b = r16
    //     0xa0e6c4: stur            w16, [x1, #0x1b]
    // 0xa0e6c8: ldur            x0, [fp, #-0x10]
    // 0xa0e6cc: StoreField: r1->field_1f = r0
    //     0xa0e6cc: stur            w0, [x1, #0x1f]
    // 0xa0e6d0: str             x1, [SP]
    // 0xa0e6d4: r0 = _interpolate()
    //     0xa0e6d4: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xa0e6d8: LeaveFrame
    //     0xa0e6d8: mov             SP, fp
    //     0xa0e6dc: ldp             fp, lr, [SP], #0x10
    // 0xa0e6e0: ret
    //     0xa0e6e0: ret             
    // 0xa0e6e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0e6e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0e6e8: b               #0xa0e58c
    // 0xa0e6ec: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa0e6ec: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xa0e6f0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa0e6f0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xa0e6f4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa0e6f4: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _formatTwoDigitZeroPad(/* No info */) {
    // ** addr: 0xa0e6f8, size: 0xa4
    // 0xa0e6f8: EnterFrame
    //     0xa0e6f8: stp             fp, lr, [SP, #-0x10]!
    //     0xa0e6fc: mov             fp, SP
    // 0xa0e700: AllocStack(0x10)
    //     0xa0e700: sub             SP, SP, #0x10
    // 0xa0e704: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0xa0e704: mov             x0, x2
    //     0xa0e708: stur            x2, [fp, #-8]
    // 0xa0e70c: CheckStackOverflow
    //     0xa0e70c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xa0e710: cmp             SP, x16
    //     0xa0e714: b.ls            #0xa0e794
    // 0xa0e718: cmp             x0, #0xa
    // 0xa0e71c: b.ge            #0xa0e768
    // 0xa0e720: r1 = Null
    //     0xa0e720: mov             x1, NULL
    // 0xa0e724: r2 = 4
    //     0xa0e724: mov             x2, #4
    // 0xa0e728: r0 = AllocateArray()
    //     0xa0e728: bl              #0x13df928  ; AllocateArrayStub
    // 0xa0e72c: mov             x2, x0
    // 0xa0e730: r16 = "0"
    //     0xa0e730: ldr             x16, [PP, #0x47e8]  ; [pp+0x47e8] "0"
    // 0xa0e734: StoreField: r2->field_f = r16
    //     0xa0e734: stur            w16, [x2, #0xf]
    // 0xa0e738: ldur            x3, [fp, #-8]
    // 0xa0e73c: r0 = BoxInt64Instr(r3)
    //     0xa0e73c: sbfiz           x0, x3, #1, #0x1f
    //     0xa0e740: cmp             x3, x0, asr #1
    //     0xa0e744: b.eq            #0xa0e750
    //     0xa0e748: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xa0e74c: stur            x3, [x0, #7]
    // 0xa0e750: StoreField: r2->field_13 = r0
    //     0xa0e750: stur            w0, [x2, #0x13]
    // 0xa0e754: str             x2, [SP]
    // 0xa0e758: r0 = _interpolate()
    //     0xa0e758: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xa0e75c: LeaveFrame
    //     0xa0e75c: mov             SP, fp
    //     0xa0e760: ldp             fp, lr, [SP], #0x10
    // 0xa0e764: ret
    //     0xa0e764: ret             
    // 0xa0e768: mov             x3, x0
    // 0xa0e76c: r0 = BoxInt64Instr(r3)
    //     0xa0e76c: sbfiz           x0, x3, #1, #0x1f
    //     0xa0e770: cmp             x3, x0, asr #1
    //     0xa0e774: b.eq            #0xa0e780
    //     0xa0e778: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xa0e77c: stur            x3, [x0, #7]
    // 0xa0e780: str             x0, [SP]
    // 0xa0e784: r0 = _interpolateSingle()
    //     0xa0e784: bl              #0x7e237c  ; [dart:core] _StringBase::_interpolateSingle
    // 0xa0e788: LeaveFrame
    //     0xa0e788: mov             SP, fp
    //     0xa0e78c: ldp             fp, lr, [SP], #0x10
    // 0xa0e790: ret
    //     0xa0e790: ret             
    // 0xa0e794: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0e794: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0e798: b               #0xa0e718
  }
  get _ narrowWeekdays(/* No info */) {
    // ** addr: 0xa0ef50, size: 0xc
    // 0xa0ef50: r0 = const [S, M, T, W, T, F, S]
    //     0xa0ef50: add             x0, PP, #9, lsl #12  ; [pp+0x98d0] List<String>(7)
    //     0xa0ef54: ldr             x0, [x0, #0x8d0]
    // 0xa0ef58: ret
    //     0xa0ef58: ret             
  }
  _ formatYear(/* No info */) {
    // ** addr: 0xa111e8, size: 0x8c
    // 0xa111e8: EnterFrame
    //     0xa111e8: stp             fp, lr, [SP, #-0x10]!
    //     0xa111ec: mov             fp, SP
    // 0xa111f0: AllocStack(0x8)
    //     0xa111f0: sub             SP, SP, #8
    // 0xa111f4: SetupParameters(DefaultMaterialLocalizations this /* r1 => r0 */, dynamic _ /* r2 => r1 */)
    //     0xa111f4: mov             x0, x1
    //     0xa111f8: mov             x1, x2
    // 0xa111fc: CheckStackOverflow
    //     0xa111fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xa11200: cmp             SP, x16
    //     0xa11204: b.ls            #0xa11268
    // 0xa11208: r0 = _parts()
    //     0xa11208: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xa1120c: mov             x2, x0
    // 0xa11210: LoadField: r0 = r2->field_b
    //     0xa11210: ldur            w0, [x2, #0xb]
    // 0xa11214: r1 = LoadInt32Instr(r0)
    //     0xa11214: sbfx            x1, x0, #1, #0x1f
    // 0xa11218: mov             x0, x1
    // 0xa1121c: r1 = 8
    //     0xa1121c: mov             x1, #8
    // 0xa11220: cmp             x1, x0
    // 0xa11224: b.hs            #0xa11270
    // 0xa11228: LoadField: r0 = r2->field_2f
    //     0xa11228: ldur            w0, [x2, #0x2f]
    // 0xa1122c: DecompressPointer r0
    //     0xa1122c: add             x0, x0, HEAP, lsl #32
    // 0xa11230: r1 = 60
    //     0xa11230: mov             x1, #0x3c
    // 0xa11234: branchIfSmi(r0, 0xa11240)
    //     0xa11234: tbz             w0, #0, #0xa11240
    // 0xa11238: r1 = LoadClassIdInstr(r0)
    //     0xa11238: ldur            x1, [x0, #-1]
    //     0xa1123c: ubfx            x1, x1, #0xc, #0x14
    // 0xa11240: str             x0, [SP]
    // 0xa11244: mov             x0, x1
    // 0xa11248: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa11248: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa1124c: r0 = GDT[cid_x0 + 0x91c1]()
    //     0xa1124c: mov             x17, #0x91c1
    //     0xa11250: add             lr, x0, x17
    //     0xa11254: ldr             lr, [x21, lr, lsl #3]
    //     0xa11258: blr             lr
    // 0xa1125c: LeaveFrame
    //     0xa1125c: mov             SP, fp
    //     0xa11260: ldp             fp, lr, [SP], #0x10
    // 0xa11264: ret
    //     0xa11264: ret             
    // 0xa11268: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa11268: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa1126c: b               #0xa11208
    // 0xa11270: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xa11270: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ scrimOnTapHint(/* No info */) {
    // ** addr: 0xa12af0, size: 0x5c
    // 0xa12af0: EnterFrame
    //     0xa12af0: stp             fp, lr, [SP, #-0x10]!
    //     0xa12af4: mov             fp, SP
    // 0xa12af8: AllocStack(0x10)
    //     0xa12af8: sub             SP, SP, #0x10
    // 0xa12afc: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0xa12afc: mov             x0, x2
    //     0xa12b00: stur            x2, [fp, #-8]
    // 0xa12b04: CheckStackOverflow
    //     0xa12b04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xa12b08: cmp             SP, x16
    //     0xa12b0c: b.ls            #0xa12b44
    // 0xa12b10: r1 = Null
    //     0xa12b10: mov             x1, NULL
    // 0xa12b14: r2 = 4
    //     0xa12b14: mov             x2, #4
    // 0xa12b18: r0 = AllocateArray()
    //     0xa12b18: bl              #0x13df928  ; AllocateArrayStub
    // 0xa12b1c: r16 = "Close "
    //     0xa12b1c: add             x16, PP, #0xab, lsl #12  ; [pp+0xabdb8] "Close "
    //     0xa12b20: ldr             x16, [x16, #0xdb8]
    // 0xa12b24: StoreField: r0->field_f = r16
    //     0xa12b24: stur            w16, [x0, #0xf]
    // 0xa12b28: ldur            x1, [fp, #-8]
    // 0xa12b2c: StoreField: r0->field_13 = r1
    //     0xa12b2c: stur            w1, [x0, #0x13]
    // 0xa12b30: str             x0, [SP]
    // 0xa12b34: r0 = _interpolate()
    //     0xa12b34: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xa12b38: LeaveFrame
    //     0xa12b38: mov             SP, fp
    //     0xa12b3c: ldp             fp, lr, [SP], #0x10
    // 0xa12b40: ret
    //     0xa12b40: ret             
    // 0xa12b44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa12b44: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa12b48: b               #0xa12b10
  }
  _ tabLabel(/* No info */) {
    // ** addr: 0xa14f98, size: 0x90
    // 0xa14f98: EnterFrame
    //     0xa14f98: stp             fp, lr, [SP, #-0x10]!
    //     0xa14f9c: mov             fp, SP
    // 0xa14fa0: AllocStack(0x18)
    //     0xa14fa0: sub             SP, SP, #0x18
    // 0xa14fa4: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xa14fa4: mov             x0, x2
    //     0xa14fa8: stur            x2, [fp, #-8]
    //     0xa14fac: stur            x3, [fp, #-0x10]
    // 0xa14fb0: CheckStackOverflow
    //     0xa14fb0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xa14fb4: cmp             SP, x16
    //     0xa14fb8: b.ls            #0xa15020
    // 0xa14fbc: r1 = Null
    //     0xa14fbc: mov             x1, NULL
    // 0xa14fc0: r2 = 8
    //     0xa14fc0: mov             x2, #8
    // 0xa14fc4: r0 = AllocateArray()
    //     0xa14fc4: bl              #0x13df928  ; AllocateArrayStub
    // 0xa14fc8: mov             x2, x0
    // 0xa14fcc: r16 = "Tab "
    //     0xa14fcc: add             x16, PP, #0xab, lsl #12  ; [pp+0xabda8] "Tab "
    //     0xa14fd0: ldr             x16, [x16, #0xda8]
    // 0xa14fd4: StoreField: r2->field_f = r16
    //     0xa14fd4: stur            w16, [x2, #0xf]
    // 0xa14fd8: ldur            x3, [fp, #-0x10]
    // 0xa14fdc: r0 = BoxInt64Instr(r3)
    //     0xa14fdc: sbfiz           x0, x3, #1, #0x1f
    //     0xa14fe0: cmp             x3, x0, asr #1
    //     0xa14fe4: b.eq            #0xa14ff0
    //     0xa14fe8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xa14fec: stur            x3, [x0, #7]
    // 0xa14ff0: StoreField: r2->field_13 = r0
    //     0xa14ff0: stur            w0, [x2, #0x13]
    // 0xa14ff4: r16 = " of "
    //     0xa14ff4: add             x16, PP, #0xab, lsl #12  ; [pp+0xabdb0] " of "
    //     0xa14ff8: ldr             x16, [x16, #0xdb0]
    // 0xa14ffc: ArrayStore: r2[0] = r16  ; List_4
    //     0xa14ffc: stur            w16, [x2, #0x17]
    // 0xa15000: ldur            x0, [fp, #-8]
    // 0xa15004: lsl             x1, x0, #1
    // 0xa15008: StoreField: r2->field_1b = r1
    //     0xa15008: stur            w1, [x2, #0x1b]
    // 0xa1500c: str             x2, [SP]
    // 0xa15010: r0 = _interpolate()
    //     0xa15010: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xa15014: LeaveFrame
    //     0xa15014: mov             SP, fp
    //     0xa15018: ldp             fp, lr, [SP], #0x10
    // 0xa1501c: ret
    //     0xa1501c: ret             
    // 0xa15020: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa15020: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa15024: b               #0xa14fbc
  }
  _ formatDecimal(/* No info */) {
    // ** addr: 0xa1ac74, size: 0x208
    // 0xa1ac74: EnterFrame
    //     0xa1ac74: stp             fp, lr, [SP, #-0x10]!
    //     0xa1ac78: mov             fp, SP
    // 0xa1ac7c: AllocStack(0x38)
    //     0xa1ac7c: sub             SP, SP, #0x38
    // 0xa1ac80: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0xa1ac80: stur            x2, [fp, #-8]
    // 0xa1ac84: CheckStackOverflow
    //     0xa1ac84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xa1ac88: cmp             SP, x16
    //     0xa1ac8c: b.ls            #0xa1ae64
    // 0xa1ac90: cmn             x2, #0x3e8
    // 0xa1ac94: b.le            #0xa1acec
    // 0xa1ac98: cmp             x2, #0x3e8
    // 0xa1ac9c: b.ge            #0xa1acec
    // 0xa1aca0: r0 = BoxInt64Instr(r2)
    //     0xa1aca0: sbfiz           x0, x2, #1, #0x1f
    //     0xa1aca4: cmp             x2, x0, asr #1
    //     0xa1aca8: b.eq            #0xa1acb4
    //     0xa1acac: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xa1acb0: stur            x2, [x0, #7]
    // 0xa1acb4: r1 = 60
    //     0xa1acb4: mov             x1, #0x3c
    // 0xa1acb8: branchIfSmi(r0, 0xa1acc4)
    //     0xa1acb8: tbz             w0, #0, #0xa1acc4
    // 0xa1acbc: r1 = LoadClassIdInstr(r0)
    //     0xa1acbc: ldur            x1, [x0, #-1]
    //     0xa1acc0: ubfx            x1, x1, #0xc, #0x14
    // 0xa1acc4: str             x0, [SP]
    // 0xa1acc8: mov             x0, x1
    // 0xa1accc: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa1accc: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa1acd0: r0 = GDT[cid_x0 + 0x91c1]()
    //     0xa1acd0: mov             x17, #0x91c1
    //     0xa1acd4: add             lr, x0, x17
    //     0xa1acd8: ldr             lr, [x21, lr, lsl #3]
    //     0xa1acdc: blr             lr
    // 0xa1ace0: LeaveFrame
    //     0xa1ace0: mov             SP, fp
    //     0xa1ace4: ldp             fp, lr, [SP], #0x10
    // 0xa1ace8: ret
    //     0xa1ace8: ret             
    // 0xa1acec: tbz             x2, #0x3f, #0xa1acfc
    // 0xa1acf0: neg             x0, x2
    // 0xa1acf4: mov             x3, x0
    // 0xa1acf8: b               #0xa1ad00
    // 0xa1acfc: mov             x3, x2
    // 0xa1ad00: r0 = BoxInt64Instr(r3)
    //     0xa1ad00: sbfiz           x0, x3, #1, #0x1f
    //     0xa1ad04: cmp             x3, x0, asr #1
    //     0xa1ad08: b.eq            #0xa1ad14
    //     0xa1ad0c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xa1ad10: stur            x3, [x0, #7]
    // 0xa1ad14: r1 = 60
    //     0xa1ad14: mov             x1, #0x3c
    // 0xa1ad18: branchIfSmi(r0, 0xa1ad24)
    //     0xa1ad18: tbz             w0, #0, #0xa1ad24
    // 0xa1ad1c: r1 = LoadClassIdInstr(r0)
    //     0xa1ad1c: ldur            x1, [x0, #-1]
    //     0xa1ad20: ubfx            x1, x1, #0xc, #0x14
    // 0xa1ad24: str             x0, [SP]
    // 0xa1ad28: mov             x0, x1
    // 0xa1ad2c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa1ad2c: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa1ad30: r0 = GDT[cid_x0 + 0x91c1]()
    //     0xa1ad30: mov             x17, #0x91c1
    //     0xa1ad34: add             lr, x0, x17
    //     0xa1ad38: ldr             lr, [x21, lr, lsl #3]
    //     0xa1ad3c: blr             lr
    // 0xa1ad40: mov             x1, x0
    // 0xa1ad44: ldur            x0, [fp, #-8]
    // 0xa1ad48: stur            x1, [fp, #-0x18]
    // 0xa1ad4c: tbz             x0, #0x3f, #0xa1ad58
    // 0xa1ad50: r0 = "-"
    //     0xa1ad50: ldr             x0, [PP, #0x24e8]  ; [pp+0x24e8] "-"
    // 0xa1ad54: b               #0xa1ad5c
    // 0xa1ad58: r0 = ""
    //     0xa1ad58: ldr             x0, [PP, #0x900]  ; [pp+0x900] ""
    // 0xa1ad5c: stur            x0, [fp, #-0x10]
    // 0xa1ad60: r0 = StringBuffer()
    //     0xa1ad60: bl              #0x7e51d4  ; AllocateStringBufferStub -> StringBuffer (size=0x38)
    // 0xa1ad64: stur            x0, [fp, #-0x20]
    // 0xa1ad68: ldur            x16, [fp, #-0x10]
    // 0xa1ad6c: str             x16, [SP]
    // 0xa1ad70: mov             x1, x0
    // 0xa1ad74: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0xa1ad74: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0xa1ad78: r0 = StringBuffer()
    //     0xa1ad78: bl              #0x7e4a4c  ; [dart:core] StringBuffer::StringBuffer
    // 0xa1ad7c: ldur            x2, [fp, #-0x18]
    // 0xa1ad80: LoadField: r0 = r2->field_7
    //     0xa1ad80: ldur            w0, [x2, #7]
    // 0xa1ad84: r1 = LoadInt32Instr(r0)
    //     0xa1ad84: sbfx            x1, x0, #1, #0x1f
    // 0xa1ad88: sub             x3, x1, #1
    // 0xa1ad8c: stur            x3, [fp, #-0x28]
    // 0xa1ad90: r4 = 0
    //     0xa1ad90: mov             x4, #0
    // 0xa1ad94: stur            x4, [fp, #-8]
    // 0xa1ad98: CheckStackOverflow
    //     0xa1ad98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xa1ad9c: cmp             SP, x16
    //     0xa1ada0: b.ls            #0xa1ae6c
    // 0xa1ada4: cmp             x4, x3
    // 0xa1ada8: b.gt            #0xa1ae4c
    // 0xa1adac: r0 = BoxInt64Instr(r4)
    //     0xa1adac: sbfiz           x0, x4, #1, #0x1f
    //     0xa1adb0: cmp             x4, x0, asr #1
    //     0xa1adb4: b.eq            #0xa1adc0
    //     0xa1adb8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xa1adbc: stur            x4, [x0, #7]
    // 0xa1adc0: stp             x0, x2, [SP]
    // 0xa1adc4: r0 = []()
    //     0xa1adc4: bl              #0x7e2288  ; [dart:core] _StringBase::[]
    // 0xa1adc8: r1 = LoadClassIdInstr(r0)
    //     0xa1adc8: ldur            x1, [x0, #-1]
    //     0xa1adcc: ubfx            x1, x1, #0xc, #0x14
    // 0xa1add0: str             x0, [SP]
    // 0xa1add4: mov             x0, x1
    // 0xa1add8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa1add8: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa1addc: r0 = GDT[cid_x0 + 0x91c1]()
    //     0xa1addc: mov             x17, #0x91c1
    //     0xa1ade0: add             lr, x0, x17
    //     0xa1ade4: ldr             lr, [x21, lr, lsl #3]
    //     0xa1ade8: blr             lr
    // 0xa1adec: LoadField: r1 = r0->field_7
    //     0xa1adec: ldur            w1, [x0, #7]
    // 0xa1adf0: cbz             w1, #0xa1ae00
    // 0xa1adf4: ldur            x1, [fp, #-0x20]
    // 0xa1adf8: mov             x2, x0
    // 0xa1adfc: r0 = _writeString()
    //     0xa1adfc: bl              #0x7e4c0c  ; [dart:core] StringBuffer::_writeString
    // 0xa1ae00: ldur            x0, [fp, #-0x28]
    // 0xa1ae04: ldur            x3, [fp, #-8]
    // 0xa1ae08: cmp             x3, x0
    // 0xa1ae0c: b.ge            #0xa1ae38
    // 0xa1ae10: r4 = 3
    //     0xa1ae10: mov             x4, #3
    // 0xa1ae14: sub             x1, x0, x3
    // 0xa1ae18: sdiv            x5, x1, x4
    // 0xa1ae1c: msub            x2, x5, x4, x1
    // 0xa1ae20: cmp             x2, xzr
    // 0xa1ae24: b.lt            #0xa1ae74
    // 0xa1ae28: cbnz            x2, #0xa1ae38
    // 0xa1ae2c: ldur            x1, [fp, #-0x20]
    // 0xa1ae30: r2 = ","
    //     0xa1ae30: ldr             x2, [PP, #0x7c28]  ; [pp+0x7c28] ","
    // 0xa1ae34: r0 = _writeString()
    //     0xa1ae34: bl              #0x7e4c0c  ; [dart:core] StringBuffer::_writeString
    // 0xa1ae38: ldur            x0, [fp, #-8]
    // 0xa1ae3c: add             x4, x0, #1
    // 0xa1ae40: ldur            x2, [fp, #-0x18]
    // 0xa1ae44: ldur            x3, [fp, #-0x28]
    // 0xa1ae48: b               #0xa1ad94
    // 0xa1ae4c: ldur            x16, [fp, #-0x20]
    // 0xa1ae50: str             x16, [SP]
    // 0xa1ae54: r0 = toString()
    //     0xa1ae54: bl              #0x1101d44  ; [dart:core] StringBuffer::toString
    // 0xa1ae58: LeaveFrame
    //     0xa1ae58: mov             SP, fp
    //     0xa1ae5c: ldp             fp, lr, [SP], #0x10
    // 0xa1ae60: ret
    //     0xa1ae60: ret             
    // 0xa1ae64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa1ae64: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa1ae68: b               #0xa1ac90
    // 0xa1ae6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa1ae6c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa1ae70: b               #0xa1ada4
    // 0xa1ae74: add             x2, x2, x4
    // 0xa1ae78: b               #0xa1ae28
  }
  _ formatFullDate(/* No info */) {
    // ** addr: 0xacc12c, size: 0x208
    // 0xacc12c: EnterFrame
    //     0xacc12c: stp             fp, lr, [SP, #-0x10]!
    //     0xacc130: mov             fp, SP
    // 0xacc134: AllocStack(0x28)
    //     0xacc134: sub             SP, SP, #0x28
    // 0xacc138: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0xacc138: mov             x0, x2
    //     0xacc13c: stur            x2, [fp, #-8]
    // 0xacc140: CheckStackOverflow
    //     0xacc140: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xacc144: cmp             SP, x16
    //     0xacc148: b.ls            #0xacc314
    // 0xacc14c: mov             x1, x0
    // 0xacc150: r0 = _parts()
    //     0xacc150: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xacc154: mov             x2, x0
    // 0xacc158: LoadField: r0 = r2->field_b
    //     0xacc158: ldur            w0, [x2, #0xb]
    // 0xacc15c: r1 = LoadInt32Instr(r0)
    //     0xacc15c: sbfx            x1, x0, #1, #0x1f
    // 0xacc160: mov             x0, x1
    // 0xacc164: r1 = 7
    //     0xacc164: mov             x1, #7
    // 0xacc168: cmp             x1, x0
    // 0xacc16c: b.hs            #0xacc31c
    // 0xacc170: LoadField: r0 = r2->field_2b
    //     0xacc170: ldur            w0, [x2, #0x2b]
    // 0xacc174: DecompressPointer r0
    //     0xacc174: add             x0, x0, HEAP, lsl #32
    // 0xacc178: r1 = LoadInt32Instr(r0)
    //     0xacc178: sbfx            x1, x0, #1, #0x1f
    //     0xacc17c: tbz             w0, #0, #0xacc184
    //     0xacc180: ldur            x1, [x0, #7]
    // 0xacc184: sub             x2, x1, #1
    // 0xacc188: mov             x1, x2
    // 0xacc18c: r0 = 12
    //     0xacc18c: mov             x0, #0xc
    // 0xacc190: cmp             x1, x0
    // 0xacc194: b.hs            #0xacc320
    // 0xacc198: r0 = const [January, February, March, April, May, June, July, August, September, October, November, December]
    //     0xacc198: add             x0, PP, #9, lsl #12  ; [pp+0x98b0] List<String>(12)
    //     0xacc19c: ldr             x0, [x0, #0x8b0]
    // 0xacc1a0: ArrayLoad: r3 = r0[r2]  ; Unknown_4
    //     0xacc1a0: add             x16, x0, x2, lsl #2
    //     0xacc1a4: ldur            w3, [x16, #0xf]
    // 0xacc1a8: DecompressPointer r3
    //     0xacc1a8: add             x3, x3, HEAP, lsl #32
    // 0xacc1ac: ldur            x1, [fp, #-8]
    // 0xacc1b0: stur            x3, [fp, #-0x10]
    // 0xacc1b4: r0 = _parts()
    //     0xacc1b4: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xacc1b8: mov             x2, x0
    // 0xacc1bc: LoadField: r0 = r2->field_b
    //     0xacc1bc: ldur            w0, [x2, #0xb]
    // 0xacc1c0: r1 = LoadInt32Instr(r0)
    //     0xacc1c0: sbfx            x1, x0, #1, #0x1f
    // 0xacc1c4: mov             x0, x1
    // 0xacc1c8: r1 = 6
    //     0xacc1c8: mov             x1, #6
    // 0xacc1cc: cmp             x1, x0
    // 0xacc1d0: b.hs            #0xacc324
    // 0xacc1d4: LoadField: r0 = r2->field_27
    //     0xacc1d4: ldur            w0, [x2, #0x27]
    // 0xacc1d8: DecompressPointer r0
    //     0xacc1d8: add             x0, x0, HEAP, lsl #32
    // 0xacc1dc: r1 = LoadInt32Instr(r0)
    //     0xacc1dc: sbfx            x1, x0, #1, #0x1f
    //     0xacc1e0: tbz             w0, #0, #0xacc1e8
    //     0xacc1e4: ldur            x1, [x0, #7]
    // 0xacc1e8: sub             x2, x1, #1
    // 0xacc1ec: mov             x1, x2
    // 0xacc1f0: r0 = 7
    //     0xacc1f0: mov             x0, #7
    // 0xacc1f4: cmp             x1, x0
    // 0xacc1f8: b.hs            #0xacc328
    // 0xacc1fc: r0 = const [Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday]
    //     0xacc1fc: add             x0, PP, #0x82, lsl #12  ; [pp+0x820d8] List<String>(7)
    //     0xacc200: ldr             x0, [x0, #0xd8]
    // 0xacc204: ArrayLoad: r3 = r0[r2]  ; Unknown_4
    //     0xacc204: add             x16, x0, x2, lsl #2
    //     0xacc208: ldur            w3, [x16, #0xf]
    // 0xacc20c: DecompressPointer r3
    //     0xacc20c: add             x3, x3, HEAP, lsl #32
    // 0xacc210: stur            x3, [fp, #-0x18]
    // 0xacc214: r1 = Null
    //     0xacc214: mov             x1, NULL
    // 0xacc218: r2 = 14
    //     0xacc218: mov             x2, #0xe
    // 0xacc21c: r0 = AllocateArray()
    //     0xacc21c: bl              #0x13df928  ; AllocateArrayStub
    // 0xacc220: mov             x2, x0
    // 0xacc224: ldur            x0, [fp, #-0x18]
    // 0xacc228: stur            x2, [fp, #-0x20]
    // 0xacc22c: StoreField: r2->field_f = r0
    //     0xacc22c: stur            w0, [x2, #0xf]
    // 0xacc230: r16 = ", "
    //     0xacc230: ldr             x16, [PP, #0xe80]  ; [pp+0xe80] ", "
    // 0xacc234: StoreField: r2->field_13 = r16
    //     0xacc234: stur            w16, [x2, #0x13]
    // 0xacc238: ldur            x0, [fp, #-0x10]
    // 0xacc23c: ArrayStore: r2[0] = r0  ; List_4
    //     0xacc23c: stur            w0, [x2, #0x17]
    // 0xacc240: r16 = " "
    //     0xacc240: ldr             x16, [PP, #0x8f8]  ; [pp+0x8f8] " "
    // 0xacc244: StoreField: r2->field_1b = r16
    //     0xacc244: stur            w16, [x2, #0x1b]
    // 0xacc248: ldur            x1, [fp, #-8]
    // 0xacc24c: r0 = _parts()
    //     0xacc24c: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xacc250: mov             x2, x0
    // 0xacc254: LoadField: r0 = r2->field_b
    //     0xacc254: ldur            w0, [x2, #0xb]
    // 0xacc258: r1 = LoadInt32Instr(r0)
    //     0xacc258: sbfx            x1, x0, #1, #0x1f
    // 0xacc25c: mov             x0, x1
    // 0xacc260: r1 = 5
    //     0xacc260: mov             x1, #5
    // 0xacc264: cmp             x1, x0
    // 0xacc268: b.hs            #0xacc32c
    // 0xacc26c: LoadField: r0 = r2->field_23
    //     0xacc26c: ldur            w0, [x2, #0x23]
    // 0xacc270: DecompressPointer r0
    //     0xacc270: add             x0, x0, HEAP, lsl #32
    // 0xacc274: ldur            x1, [fp, #-0x20]
    // 0xacc278: ArrayStore: r1[4] = r0  ; List_4
    //     0xacc278: add             x25, x1, #0x1f
    //     0xacc27c: str             w0, [x25]
    //     0xacc280: tbz             w0, #0, #0xacc29c
    //     0xacc284: ldurb           w16, [x1, #-1]
    //     0xacc288: ldurb           w17, [x0, #-1]
    //     0xacc28c: and             x16, x17, x16, lsr #2
    //     0xacc290: tst             x16, HEAP, lsr #32
    //     0xacc294: b.eq            #0xacc29c
    //     0xacc298: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xacc29c: ldur            x0, [fp, #-0x20]
    // 0xacc2a0: r16 = ", "
    //     0xacc2a0: ldr             x16, [PP, #0xe80]  ; [pp+0xe80] ", "
    // 0xacc2a4: StoreField: r0->field_23 = r16
    //     0xacc2a4: stur            w16, [x0, #0x23]
    // 0xacc2a8: ldur            x1, [fp, #-8]
    // 0xacc2ac: r0 = _parts()
    //     0xacc2ac: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xacc2b0: mov             x2, x0
    // 0xacc2b4: LoadField: r0 = r2->field_b
    //     0xacc2b4: ldur            w0, [x2, #0xb]
    // 0xacc2b8: r1 = LoadInt32Instr(r0)
    //     0xacc2b8: sbfx            x1, x0, #1, #0x1f
    // 0xacc2bc: mov             x0, x1
    // 0xacc2c0: r1 = 8
    //     0xacc2c0: mov             x1, #8
    // 0xacc2c4: cmp             x1, x0
    // 0xacc2c8: b.hs            #0xacc330
    // 0xacc2cc: LoadField: r0 = r2->field_2f
    //     0xacc2cc: ldur            w0, [x2, #0x2f]
    // 0xacc2d0: DecompressPointer r0
    //     0xacc2d0: add             x0, x0, HEAP, lsl #32
    // 0xacc2d4: ldur            x1, [fp, #-0x20]
    // 0xacc2d8: ArrayStore: r1[6] = r0  ; List_4
    //     0xacc2d8: add             x25, x1, #0x27
    //     0xacc2dc: str             w0, [x25]
    //     0xacc2e0: tbz             w0, #0, #0xacc2fc
    //     0xacc2e4: ldurb           w16, [x1, #-1]
    //     0xacc2e8: ldurb           w17, [x0, #-1]
    //     0xacc2ec: and             x16, x17, x16, lsr #2
    //     0xacc2f0: tst             x16, HEAP, lsr #32
    //     0xacc2f4: b.eq            #0xacc2fc
    //     0xacc2f8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xacc2fc: ldur            x16, [fp, #-0x20]
    // 0xacc300: str             x16, [SP]
    // 0xacc304: r0 = _interpolate()
    //     0xacc304: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xacc308: LeaveFrame
    //     0xacc308: mov             SP, fp
    //     0xacc30c: ldp             fp, lr, [SP], #0x10
    // 0xacc310: ret
    //     0xacc310: ret             
    // 0xacc314: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xacc314: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xacc318: b               #0xacc14c
    // 0xacc31c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xacc31c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xacc320: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xacc320: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xacc324: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xacc324: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xacc328: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xacc328: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xacc32c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xacc32c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xacc330: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xacc330: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ remainingTextFieldCharacterCount(/* No info */) {
    // ** addr: 0xae455c, size: 0x94
    // 0xae455c: EnterFrame
    //     0xae455c: stp             fp, lr, [SP, #-0x10]!
    //     0xae4560: mov             fp, SP
    // 0xae4564: AllocStack(0x10)
    //     0xae4564: sub             SP, SP, #0x10
    // 0xae4568: CheckStackOverflow
    //     0xae4568: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xae456c: cmp             SP, x16
    //     0xae4570: b.ls            #0xae45e8
    // 0xae4574: cbnz            x2, #0xae4584
    // 0xae4578: r0 = "No characters remaining"
    //     0xae4578: add             x0, PP, #0xab, lsl #12  ; [pp+0xabd90] "No characters remaining"
    //     0xae457c: ldr             x0, [x0, #0xd90]
    // 0xae4580: b               #0xae45dc
    // 0xae4584: cmp             x2, #1
    // 0xae4588: b.ne            #0xae4598
    // 0xae458c: r0 = "1 character remaining"
    //     0xae458c: add             x0, PP, #0xab, lsl #12  ; [pp+0xabd98] "1 character remaining"
    //     0xae4590: ldr             x0, [x0, #0xd98]
    // 0xae4594: b               #0xae45dc
    // 0xae4598: r0 = BoxInt64Instr(r2)
    //     0xae4598: sbfiz           x0, x2, #1, #0x1f
    //     0xae459c: cmp             x2, x0, asr #1
    //     0xae45a0: b.eq            #0xae45ac
    //     0xae45a4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xae45a8: stur            x2, [x0, #7]
    // 0xae45ac: r1 = Null
    //     0xae45ac: mov             x1, NULL
    // 0xae45b0: r2 = 4
    //     0xae45b0: mov             x2, #4
    // 0xae45b4: stur            x0, [fp, #-8]
    // 0xae45b8: r0 = AllocateArray()
    //     0xae45b8: bl              #0x13df928  ; AllocateArrayStub
    // 0xae45bc: mov             x1, x0
    // 0xae45c0: ldur            x0, [fp, #-8]
    // 0xae45c4: StoreField: r1->field_f = r0
    //     0xae45c4: stur            w0, [x1, #0xf]
    // 0xae45c8: r16 = " characters remaining"
    //     0xae45c8: add             x16, PP, #0xab, lsl #12  ; [pp+0xabda0] " characters remaining"
    //     0xae45cc: ldr             x16, [x16, #0xda0]
    // 0xae45d0: StoreField: r1->field_13 = r16
    //     0xae45d0: stur            w16, [x1, #0x13]
    // 0xae45d4: str             x1, [SP]
    // 0xae45d8: r0 = _interpolate()
    //     0xae45d8: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xae45dc: LeaveFrame
    //     0xae45dc: mov             SP, fp
    //     0xae45e0: ldp             fp, lr, [SP], #0x10
    // 0xae45e4: ret
    //     0xae45e4: ret             
    // 0xae45e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae45e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae45ec: b               #0xae4574
  }
  _ parseCompactDate(/* No info */) {
    // ** addr: 0xaf06d8, size: 0x30c
    // 0xaf06d8: EnterFrame
    //     0xaf06d8: stp             fp, lr, [SP, #-0x10]!
    //     0xaf06dc: mov             fp, SP
    // 0xaf06e0: AllocStack(0xa0)
    //     0xaf06e0: sub             SP, SP, #0xa0
    // 0xaf06e4: SetupParameters(DefaultMaterialLocalizations this /* r1 => r0 */, dynamic _ /* r2 => r1 */)
    //     0xaf06e4: mov             x0, x1
    //     0xaf06e8: mov             x1, x2
    // 0xaf06ec: CheckStackOverflow
    //     0xaf06ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xaf06f0: cmp             SP, x16
    //     0xaf06f4: b.ls            #0xaf09bc
    // 0xaf06f8: cmp             w1, NULL
    // 0xaf06fc: b.ne            #0xaf0710
    // 0xaf0700: r0 = Null
    //     0xaf0700: mov             x0, NULL
    // 0xaf0704: LeaveFrame
    //     0xaf0704: mov             SP, fp
    //     0xaf0708: ldp             fp, lr, [SP], #0x10
    // 0xaf070c: ret
    //     0xaf070c: ret             
    // 0xaf0710: r0 = LoadClassIdInstr(r1)
    //     0xaf0710: ldur            x0, [x1, #-1]
    //     0xaf0714: ubfx            x0, x0, #0xc, #0x14
    // 0xaf0718: r2 = "/"
    //     0xaf0718: ldr             x2, [PP, #0xfe0]  ; [pp+0xfe0] "/"
    // 0xaf071c: r0 = GDT[cid_x0 + -0xffe]()
    //     0xaf071c: sub             lr, x0, #0xffe
    //     0xaf0720: ldr             lr, [x21, lr, lsl #3]
    //     0xaf0724: blr             lr
    // 0xaf0728: mov             x2, x0
    // 0xaf072c: stur            x2, [fp, #-0x68]
    // 0xaf0730: LoadField: r0 = r2->field_b
    //     0xaf0730: ldur            w0, [x2, #0xb]
    // 0xaf0734: r1 = LoadInt32Instr(r0)
    //     0xaf0734: sbfx            x1, x0, #1, #0x1f
    // 0xaf0738: cmp             x1, #3
    // 0xaf073c: b.eq            #0xaf0750
    // 0xaf0740: r0 = Null
    //     0xaf0740: mov             x0, NULL
    // 0xaf0744: LeaveFrame
    //     0xaf0744: mov             SP, fp
    //     0xaf0748: ldp             fp, lr, [SP], #0x10
    // 0xaf074c: ret
    //     0xaf074c: ret             
    // 0xaf0750: mov             x0, x1
    // 0xaf0754: r1 = 2
    //     0xaf0754: mov             x1, #2
    // 0xaf0758: cmp             x1, x0
    // 0xaf075c: b.hs            #0xaf09c4
    // 0xaf0760: LoadField: r0 = r2->field_f
    //     0xaf0760: ldur            w0, [x2, #0xf]
    // 0xaf0764: DecompressPointer r0
    //     0xaf0764: add             x0, x0, HEAP, lsl #32
    // 0xaf0768: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xaf0768: ldur            w1, [x0, #0x17]
    // 0xaf076c: DecompressPointer r1
    //     0xaf076c: add             x1, x1, HEAP, lsl #32
    // 0xaf0770: r16 = 20
    //     0xaf0770: mov             x16, #0x14
    // 0xaf0774: str             x16, [SP]
    // 0xaf0778: r4 = const [0, 0x2, 0x1, 0x1, radix, 0x1, null]
    //     0xaf0778: add             x4, PP, #0xb, lsl #12  ; [pp+0xbb18] List(7) [0, 0x2, 0x1, 0x1, "radix", 0x1, Null]
    //     0xaf077c: ldr             x4, [x4, #0xb18]
    // 0xaf0780: r0 = tryParse()
    //     0xaf0780: bl              #0x7f8758  ; [dart:core] int::tryParse
    // 0xaf0784: mov             x2, x0
    // 0xaf0788: stur            x2, [fp, #-0x78]
    // 0xaf078c: cmp             w2, NULL
    // 0xaf0790: b.eq            #0xaf07ac
    // 0xaf0794: r3 = LoadInt32Instr(r2)
    //     0xaf0794: sbfx            x3, x2, #1, #0x1f
    //     0xaf0798: tbz             w2, #0, #0xaf07a0
    //     0xaf079c: ldur            x3, [x2, #7]
    // 0xaf07a0: stur            x3, [fp, #-0x70]
    // 0xaf07a4: cmp             x3, #1
    // 0xaf07a8: b.ge            #0xaf07bc
    // 0xaf07ac: r0 = Null
    //     0xaf07ac: mov             x0, NULL
    // 0xaf07b0: LeaveFrame
    //     0xaf07b0: mov             SP, fp
    //     0xaf07b4: ldp             fp, lr, [SP], #0x10
    // 0xaf07b8: ret
    //     0xaf07b8: ret             
    // 0xaf07bc: ldur            x4, [fp, #-0x68]
    // 0xaf07c0: LoadField: r0 = r4->field_b
    //     0xaf07c0: ldur            w0, [x4, #0xb]
    // 0xaf07c4: r1 = LoadInt32Instr(r0)
    //     0xaf07c4: sbfx            x1, x0, #1, #0x1f
    // 0xaf07c8: mov             x0, x1
    // 0xaf07cc: r1 = 0
    //     0xaf07cc: mov             x1, #0
    // 0xaf07d0: cmp             x1, x0
    // 0xaf07d4: b.hs            #0xaf09c8
    // 0xaf07d8: LoadField: r0 = r4->field_f
    //     0xaf07d8: ldur            w0, [x4, #0xf]
    // 0xaf07dc: DecompressPointer r0
    //     0xaf07dc: add             x0, x0, HEAP, lsl #32
    // 0xaf07e0: LoadField: r1 = r0->field_f
    //     0xaf07e0: ldur            w1, [x0, #0xf]
    // 0xaf07e4: DecompressPointer r1
    //     0xaf07e4: add             x1, x1, HEAP, lsl #32
    // 0xaf07e8: r16 = 20
    //     0xaf07e8: mov             x16, #0x14
    // 0xaf07ec: str             x16, [SP]
    // 0xaf07f0: r4 = const [0, 0x2, 0x1, 0x1, radix, 0x1, null]
    //     0xaf07f0: add             x4, PP, #0xb, lsl #12  ; [pp+0xbb18] List(7) [0, 0x2, 0x1, 0x1, "radix", 0x1, Null]
    //     0xaf07f4: ldr             x4, [x4, #0xb18]
    // 0xaf07f8: r0 = tryParse()
    //     0xaf07f8: bl              #0x7f8758  ; [dart:core] int::tryParse
    // 0xaf07fc: mov             x2, x0
    // 0xaf0800: stur            x2, [fp, #-0x88]
    // 0xaf0804: cmp             w2, NULL
    // 0xaf0808: b.eq            #0xaf082c
    // 0xaf080c: r3 = LoadInt32Instr(r2)
    //     0xaf080c: sbfx            x3, x2, #1, #0x1f
    //     0xaf0810: tbz             w2, #0, #0xaf0818
    //     0xaf0814: ldur            x3, [x2, #7]
    // 0xaf0818: stur            x3, [fp, #-0x80]
    // 0xaf081c: cmp             x3, #1
    // 0xaf0820: b.lt            #0xaf082c
    // 0xaf0824: cmp             x3, #0xc
    // 0xaf0828: b.le            #0xaf083c
    // 0xaf082c: r0 = Null
    //     0xaf082c: mov             x0, NULL
    // 0xaf0830: LeaveFrame
    //     0xaf0830: mov             SP, fp
    //     0xaf0834: ldp             fp, lr, [SP], #0x10
    // 0xaf0838: ret
    //     0xaf0838: ret             
    // 0xaf083c: ldur            x4, [fp, #-0x68]
    // 0xaf0840: LoadField: r0 = r4->field_b
    //     0xaf0840: ldur            w0, [x4, #0xb]
    // 0xaf0844: r1 = LoadInt32Instr(r0)
    //     0xaf0844: sbfx            x1, x0, #1, #0x1f
    // 0xaf0848: mov             x0, x1
    // 0xaf084c: r1 = 1
    //     0xaf084c: mov             x1, #1
    // 0xaf0850: cmp             x1, x0
    // 0xaf0854: b.hs            #0xaf09cc
    // 0xaf0858: LoadField: r0 = r4->field_f
    //     0xaf0858: ldur            w0, [x4, #0xf]
    // 0xaf085c: DecompressPointer r0
    //     0xaf085c: add             x0, x0, HEAP, lsl #32
    // 0xaf0860: LoadField: r1 = r0->field_13
    //     0xaf0860: ldur            w1, [x0, #0x13]
    // 0xaf0864: DecompressPointer r1
    //     0xaf0864: add             x1, x1, HEAP, lsl #32
    // 0xaf0868: r16 = 20
    //     0xaf0868: mov             x16, #0x14
    // 0xaf086c: str             x16, [SP]
    // 0xaf0870: r4 = const [0, 0x2, 0x1, 0x1, radix, 0x1, null]
    //     0xaf0870: add             x4, PP, #0xb, lsl #12  ; [pp+0xbb18] List(7) [0, 0x2, 0x1, 0x1, "radix", 0x1, Null]
    //     0xaf0874: ldr             x4, [x4, #0xb18]
    // 0xaf0878: r0 = tryParse()
    //     0xaf0878: bl              #0x7f8758  ; [dart:core] int::tryParse
    // 0xaf087c: mov             x2, x0
    // 0xaf0880: stur            x2, [fp, #-0x68]
    // 0xaf0884: cmp             w2, NULL
    // 0xaf0888: b.eq            #0xaf093c
    // 0xaf088c: r3 = LoadInt32Instr(r2)
    //     0xaf088c: sbfx            x3, x2, #1, #0x1f
    //     0xaf0890: tbz             w2, #0, #0xaf0898
    //     0xaf0894: ldur            x3, [x2, #7]
    // 0xaf0898: cmp             x3, #1
    // 0xaf089c: b.lt            #0xaf093c
    // 0xaf08a0: ldur            x0, [fp, #-0x80]
    // 0xaf08a4: cmp             x0, #2
    // 0xaf08a8: b.ne            #0xaf08f8
    // 0xaf08ac: ldur            x4, [fp, #-0x70]
    // 0xaf08b0: tst             x4, #3
    // 0xaf08b4: b.ne            #0xaf08d0
    // 0xaf08b8: r0 = 100
    //     0xaf08b8: mov             x0, #0x64
    // 0xaf08bc: sdiv            x5, x4, x0
    // 0xaf08c0: msub            x1, x5, x0, x4
    // 0xaf08c4: cmp             x1, xzr
    // 0xaf08c8: b.lt            #0xaf09d0
    // 0xaf08cc: cbnz            x1, #0xaf08e8
    // 0xaf08d0: r0 = 400
    //     0xaf08d0: mov             x0, #0x190
    // 0xaf08d4: sdiv            x5, x4, x0
    // 0xaf08d8: msub            x1, x5, x0, x4
    // 0xaf08dc: cmp             x1, xzr
    // 0xaf08e0: b.lt            #0xaf09d8
    // 0xaf08e4: cbnz            x1, #0xaf08f0
    // 0xaf08e8: r0 = 29
    //     0xaf08e8: mov             x0, #0x1d
    // 0xaf08ec: b               #0xaf0934
    // 0xaf08f0: r0 = 28
    //     0xaf08f0: mov             x0, #0x1c
    // 0xaf08f4: b               #0xaf0934
    // 0xaf08f8: ldur            x4, [fp, #-0x70]
    // 0xaf08fc: r5 = const [0x1f, 0xffffffffffffffff, 0x1f, 0x1e, 0x1f, 0x1e, 0x1f, 0x1f, 0x1e, 0x1f, 0x1e, 0x1f]
    //     0xaf08fc: add             x5, PP, #0xa3, lsl #12  ; [pp+0xa3fb0] List<int>(12)
    //     0xaf0900: ldr             x5, [x5, #0xfb0]
    // 0xaf0904: sub             x6, x0, #1
    // 0xaf0908: mov             x1, x6
    // 0xaf090c: r0 = 12
    //     0xaf090c: mov             x0, #0xc
    // 0xaf0910: cmp             x1, x0
    // 0xaf0914: b.hs            #0xaf09e0
    // 0xaf0918: ArrayLoad: r0 = r5[r6]  ; Unknown_4
    //     0xaf0918: add             x16, x5, x6, lsl #2
    //     0xaf091c: ldur            w0, [x16, #0xf]
    // 0xaf0920: DecompressPointer r0
    //     0xaf0920: add             x0, x0, HEAP, lsl #32
    // 0xaf0924: r1 = LoadInt32Instr(r0)
    //     0xaf0924: sbfx            x1, x0, #1, #0x1f
    //     0xaf0928: tbz             w0, #0, #0xaf0930
    //     0xaf092c: ldur            x1, [x0, #7]
    // 0xaf0930: mov             x0, x1
    // 0xaf0934: cmp             x3, x0
    // 0xaf0938: b.le            #0xaf094c
    // 0xaf093c: r0 = Null
    //     0xaf093c: mov             x0, NULL
    // 0xaf0940: LeaveFrame
    //     0xaf0940: mov             SP, fp
    //     0xaf0944: ldp             fp, lr, [SP], #0x10
    // 0xaf0948: ret
    //     0xaf0948: ret             
    // 0xaf094c: r0 = DateTime()
    //     0xaf094c: bl              #0x8174b8  ; AllocateDateTimeStub -> DateTime (size=0x18)
    // 0xaf0950: stur            x0, [fp, #-0x90]
    // 0xaf0954: ldur            x16, [fp, #-0x88]
    // 0xaf0958: ldur            lr, [fp, #-0x68]
    // 0xaf095c: stp             lr, x16, [SP]
    // 0xaf0960: mov             x1, x0
    // 0xaf0964: ldur            x2, [fp, #-0x70]
    // 0xaf0968: r4 = const [0, 0x4, 0x2, 0x4, null]
    //     0xaf0968: ldr             x4, [PP, #0x1388]  ; [pp+0x1388] List(5) [0, 0x4, 0x2, 0x4, Null]
    // 0xaf096c: r0 = DateTime()
    //     0xaf096c: bl              #0xaf09e4  ; [dart:core] DateTime::DateTime
    // 0xaf0970: ldur            x0, [fp, #-0x90]
    // 0xaf0974: LeaveFrame
    //     0xaf0974: mov             SP, fp
    //     0xaf0978: ldp             fp, lr, [SP], #0x10
    // 0xaf097c: ret
    //     0xaf097c: ret             
    // 0xaf0980: sub             SP, fp, #0xa0
    // 0xaf0984: r2 = 60
    //     0xaf0984: mov             x2, #0x3c
    // 0xaf0988: branchIfSmi(r0, 0xaf0994)
    //     0xaf0988: tbz             w0, #0, #0xaf0994
    // 0xaf098c: r2 = LoadClassIdInstr(r0)
    //     0xaf098c: ldur            x2, [x0, #-1]
    //     0xaf0990: ubfx            x2, x2, #0xc, #0x14
    // 0xaf0994: r17 = -7777
    //     0xaf0994: mov             x17, #-0x1e61
    // 0xaf0998: add             x16, x2, x17
    // 0xaf099c: cmp             x16, #2
    // 0xaf09a0: b.hi            #0xaf09b4
    // 0xaf09a4: r0 = Null
    //     0xaf09a4: mov             x0, NULL
    // 0xaf09a8: LeaveFrame
    //     0xaf09a8: mov             SP, fp
    //     0xaf09ac: ldp             fp, lr, [SP], #0x10
    // 0xaf09b0: ret
    //     0xaf09b0: ret             
    // 0xaf09b4: r0 = ReThrow()
    //     0xaf09b4: bl              #0x13ddb00  ; ReThrowStub
    // 0xaf09b8: brk             #0
    // 0xaf09bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaf09bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaf09c0: b               #0xaf06f8
    // 0xaf09c4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xaf09c4: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xaf09c8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xaf09c8: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xaf09cc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xaf09cc: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xaf09d0: add             x1, x1, x0
    // 0xaf09d4: b               #0xaf08cc
    // 0xaf09d8: add             x1, x1, x0
    // 0xaf09dc: b               #0xaf08e4
    // 0xaf09e0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xaf09e0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ formatMonthYear(/* No info */) {
    // ** addr: 0xaf1194, size: 0xdc
    // 0xaf1194: EnterFrame
    //     0xaf1194: stp             fp, lr, [SP, #-0x10]!
    //     0xaf1198: mov             fp, SP
    // 0xaf119c: AllocStack(0x18)
    //     0xaf119c: sub             SP, SP, #0x18
    // 0xaf11a0: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0xaf11a0: mov             x0, x2
    //     0xaf11a4: stur            x2, [fp, #-8]
    // 0xaf11a8: CheckStackOverflow
    //     0xaf11a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xaf11ac: cmp             SP, x16
    //     0xaf11b0: b.ls            #0xaf1260
    // 0xaf11b4: mov             x2, x0
    // 0xaf11b8: r0 = formatYear()
    //     0xaf11b8: bl              #0xa111e8  ; [package:flutter/src/material/material_localizations.dart] DefaultMaterialLocalizations::formatYear
    // 0xaf11bc: ldur            x1, [fp, #-8]
    // 0xaf11c0: stur            x0, [fp, #-8]
    // 0xaf11c4: r0 = _parts()
    //     0xaf11c4: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xaf11c8: mov             x2, x0
    // 0xaf11cc: LoadField: r0 = r2->field_b
    //     0xaf11cc: ldur            w0, [x2, #0xb]
    // 0xaf11d0: r1 = LoadInt32Instr(r0)
    //     0xaf11d0: sbfx            x1, x0, #1, #0x1f
    // 0xaf11d4: mov             x0, x1
    // 0xaf11d8: r1 = 7
    //     0xaf11d8: mov             x1, #7
    // 0xaf11dc: cmp             x1, x0
    // 0xaf11e0: b.hs            #0xaf1268
    // 0xaf11e4: LoadField: r0 = r2->field_2b
    //     0xaf11e4: ldur            w0, [x2, #0x2b]
    // 0xaf11e8: DecompressPointer r0
    //     0xaf11e8: add             x0, x0, HEAP, lsl #32
    // 0xaf11ec: r1 = LoadInt32Instr(r0)
    //     0xaf11ec: sbfx            x1, x0, #1, #0x1f
    //     0xaf11f0: tbz             w0, #0, #0xaf11f8
    //     0xaf11f4: ldur            x1, [x0, #7]
    // 0xaf11f8: sub             x2, x1, #1
    // 0xaf11fc: mov             x1, x2
    // 0xaf1200: r0 = 12
    //     0xaf1200: mov             x0, #0xc
    // 0xaf1204: cmp             x1, x0
    // 0xaf1208: b.hs            #0xaf126c
    // 0xaf120c: r0 = const [January, February, March, April, May, June, July, August, September, October, November, December]
    //     0xaf120c: add             x0, PP, #9, lsl #12  ; [pp+0x98b0] List<String>(12)
    //     0xaf1210: ldr             x0, [x0, #0x8b0]
    // 0xaf1214: ArrayLoad: r3 = r0[r2]  ; Unknown_4
    //     0xaf1214: add             x16, x0, x2, lsl #2
    //     0xaf1218: ldur            w3, [x16, #0xf]
    // 0xaf121c: DecompressPointer r3
    //     0xaf121c: add             x3, x3, HEAP, lsl #32
    // 0xaf1220: stur            x3, [fp, #-0x10]
    // 0xaf1224: r1 = Null
    //     0xaf1224: mov             x1, NULL
    // 0xaf1228: r2 = 6
    //     0xaf1228: mov             x2, #6
    // 0xaf122c: r0 = AllocateArray()
    //     0xaf122c: bl              #0x13df928  ; AllocateArrayStub
    // 0xaf1230: mov             x1, x0
    // 0xaf1234: ldur            x0, [fp, #-0x10]
    // 0xaf1238: StoreField: r1->field_f = r0
    //     0xaf1238: stur            w0, [x1, #0xf]
    // 0xaf123c: r16 = " "
    //     0xaf123c: ldr             x16, [PP, #0x8f8]  ; [pp+0x8f8] " "
    // 0xaf1240: StoreField: r1->field_13 = r16
    //     0xaf1240: stur            w16, [x1, #0x13]
    // 0xaf1244: ldur            x0, [fp, #-8]
    // 0xaf1248: ArrayStore: r1[0] = r0  ; List_4
    //     0xaf1248: stur            w0, [x1, #0x17]
    // 0xaf124c: str             x1, [SP]
    // 0xaf1250: r0 = _interpolate()
    //     0xaf1250: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xaf1254: LeaveFrame
    //     0xaf1254: mov             SP, fp
    //     0xaf1258: ldp             fp, lr, [SP], #0x10
    // 0xaf125c: ret
    //     0xaf125c: ret             
    // 0xaf1260: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaf1260: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaf1264: b               #0xaf11b4
    // 0xaf1268: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xaf1268: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xaf126c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xaf126c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ formatMediumDate(/* No info */) {
    // ** addr: 0xaf15c4, size: 0x1a4
    // 0xaf15c4: EnterFrame
    //     0xaf15c4: stp             fp, lr, [SP, #-0x10]!
    //     0xaf15c8: mov             fp, SP
    // 0xaf15cc: AllocStack(0x28)
    //     0xaf15cc: sub             SP, SP, #0x28
    // 0xaf15d0: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0xaf15d0: mov             x0, x2
    //     0xaf15d4: stur            x2, [fp, #-8]
    // 0xaf15d8: CheckStackOverflow
    //     0xaf15d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xaf15dc: cmp             SP, x16
    //     0xaf15e0: b.ls            #0xaf174c
    // 0xaf15e4: mov             x1, x0
    // 0xaf15e8: r0 = _parts()
    //     0xaf15e8: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xaf15ec: mov             x2, x0
    // 0xaf15f0: LoadField: r0 = r2->field_b
    //     0xaf15f0: ldur            w0, [x2, #0xb]
    // 0xaf15f4: r1 = LoadInt32Instr(r0)
    //     0xaf15f4: sbfx            x1, x0, #1, #0x1f
    // 0xaf15f8: mov             x0, x1
    // 0xaf15fc: r1 = 6
    //     0xaf15fc: mov             x1, #6
    // 0xaf1600: cmp             x1, x0
    // 0xaf1604: b.hs            #0xaf1754
    // 0xaf1608: LoadField: r0 = r2->field_27
    //     0xaf1608: ldur            w0, [x2, #0x27]
    // 0xaf160c: DecompressPointer r0
    //     0xaf160c: add             x0, x0, HEAP, lsl #32
    // 0xaf1610: r1 = LoadInt32Instr(r0)
    //     0xaf1610: sbfx            x1, x0, #1, #0x1f
    //     0xaf1614: tbz             w0, #0, #0xaf161c
    //     0xaf1618: ldur            x1, [x0, #7]
    // 0xaf161c: sub             x2, x1, #1
    // 0xaf1620: mov             x1, x2
    // 0xaf1624: r0 = 7
    //     0xaf1624: mov             x0, #7
    // 0xaf1628: cmp             x1, x0
    // 0xaf162c: b.hs            #0xaf1758
    // 0xaf1630: r0 = const [Mon, Tue, Wed, Thu, Fri, Sat, Sun]
    //     0xaf1630: add             x0, PP, #0xb, lsl #12  ; [pp+0xbaa8] List<String>(7)
    //     0xaf1634: ldr             x0, [x0, #0xaa8]
    // 0xaf1638: ArrayLoad: r3 = r0[r2]  ; Unknown_4
    //     0xaf1638: add             x16, x0, x2, lsl #2
    //     0xaf163c: ldur            w3, [x16, #0xf]
    // 0xaf1640: DecompressPointer r3
    //     0xaf1640: add             x3, x3, HEAP, lsl #32
    // 0xaf1644: ldur            x1, [fp, #-8]
    // 0xaf1648: stur            x3, [fp, #-0x10]
    // 0xaf164c: r0 = _parts()
    //     0xaf164c: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xaf1650: mov             x2, x0
    // 0xaf1654: LoadField: r0 = r2->field_b
    //     0xaf1654: ldur            w0, [x2, #0xb]
    // 0xaf1658: r1 = LoadInt32Instr(r0)
    //     0xaf1658: sbfx            x1, x0, #1, #0x1f
    // 0xaf165c: mov             x0, x1
    // 0xaf1660: r1 = 7
    //     0xaf1660: mov             x1, #7
    // 0xaf1664: cmp             x1, x0
    // 0xaf1668: b.hs            #0xaf175c
    // 0xaf166c: LoadField: r0 = r2->field_2b
    //     0xaf166c: ldur            w0, [x2, #0x2b]
    // 0xaf1670: DecompressPointer r0
    //     0xaf1670: add             x0, x0, HEAP, lsl #32
    // 0xaf1674: r1 = LoadInt32Instr(r0)
    //     0xaf1674: sbfx            x1, x0, #1, #0x1f
    //     0xaf1678: tbz             w0, #0, #0xaf1680
    //     0xaf167c: ldur            x1, [x0, #7]
    // 0xaf1680: sub             x2, x1, #1
    // 0xaf1684: mov             x1, x2
    // 0xaf1688: r0 = 12
    //     0xaf1688: mov             x0, #0xc
    // 0xaf168c: cmp             x1, x0
    // 0xaf1690: b.hs            #0xaf1760
    // 0xaf1694: r0 = const [Jan, Feb, Mar, Apr, May, Jun, Jul, Aug, Sep, Oct, Nov, Dec]
    //     0xaf1694: add             x0, PP, #9, lsl #12  ; [pp+0x98b8] List<String>(12)
    //     0xaf1698: ldr             x0, [x0, #0x8b8]
    // 0xaf169c: ArrayLoad: r3 = r0[r2]  ; Unknown_4
    //     0xaf169c: add             x16, x0, x2, lsl #2
    //     0xaf16a0: ldur            w3, [x16, #0xf]
    // 0xaf16a4: DecompressPointer r3
    //     0xaf16a4: add             x3, x3, HEAP, lsl #32
    // 0xaf16a8: stur            x3, [fp, #-0x18]
    // 0xaf16ac: r1 = Null
    //     0xaf16ac: mov             x1, NULL
    // 0xaf16b0: r2 = 10
    //     0xaf16b0: mov             x2, #0xa
    // 0xaf16b4: r0 = AllocateArray()
    //     0xaf16b4: bl              #0x13df928  ; AllocateArrayStub
    // 0xaf16b8: mov             x2, x0
    // 0xaf16bc: ldur            x0, [fp, #-0x10]
    // 0xaf16c0: stur            x2, [fp, #-0x20]
    // 0xaf16c4: StoreField: r2->field_f = r0
    //     0xaf16c4: stur            w0, [x2, #0xf]
    // 0xaf16c8: r16 = ", "
    //     0xaf16c8: ldr             x16, [PP, #0xe80]  ; [pp+0xe80] ", "
    // 0xaf16cc: StoreField: r2->field_13 = r16
    //     0xaf16cc: stur            w16, [x2, #0x13]
    // 0xaf16d0: ldur            x0, [fp, #-0x18]
    // 0xaf16d4: ArrayStore: r2[0] = r0  ; List_4
    //     0xaf16d4: stur            w0, [x2, #0x17]
    // 0xaf16d8: r16 = " "
    //     0xaf16d8: ldr             x16, [PP, #0x8f8]  ; [pp+0x8f8] " "
    // 0xaf16dc: StoreField: r2->field_1b = r16
    //     0xaf16dc: stur            w16, [x2, #0x1b]
    // 0xaf16e0: ldur            x1, [fp, #-8]
    // 0xaf16e4: r0 = _parts()
    //     0xaf16e4: bl              #0x816b24  ; [dart:core] DateTime::_parts
    // 0xaf16e8: mov             x2, x0
    // 0xaf16ec: LoadField: r0 = r2->field_b
    //     0xaf16ec: ldur            w0, [x2, #0xb]
    // 0xaf16f0: r1 = LoadInt32Instr(r0)
    //     0xaf16f0: sbfx            x1, x0, #1, #0x1f
    // 0xaf16f4: mov             x0, x1
    // 0xaf16f8: r1 = 5
    //     0xaf16f8: mov             x1, #5
    // 0xaf16fc: cmp             x1, x0
    // 0xaf1700: b.hs            #0xaf1764
    // 0xaf1704: LoadField: r0 = r2->field_23
    //     0xaf1704: ldur            w0, [x2, #0x23]
    // 0xaf1708: DecompressPointer r0
    //     0xaf1708: add             x0, x0, HEAP, lsl #32
    // 0xaf170c: ldur            x1, [fp, #-0x20]
    // 0xaf1710: ArrayStore: r1[4] = r0  ; List_4
    //     0xaf1710: add             x25, x1, #0x1f
    //     0xaf1714: str             w0, [x25]
    //     0xaf1718: tbz             w0, #0, #0xaf1734
    //     0xaf171c: ldurb           w16, [x1, #-1]
    //     0xaf1720: ldurb           w17, [x0, #-1]
    //     0xaf1724: and             x16, x17, x16, lsr #2
    //     0xaf1728: tst             x16, HEAP, lsr #32
    //     0xaf172c: b.eq            #0xaf1734
    //     0xaf1730: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xaf1734: ldur            x16, [fp, #-0x20]
    // 0xaf1738: str             x16, [SP]
    // 0xaf173c: r0 = _interpolate()
    //     0xaf173c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xaf1740: LeaveFrame
    //     0xaf1740: mov             SP, fp
    //     0xaf1744: ldp             fp, lr, [SP], #0x10
    // 0xaf1748: ret
    //     0xaf1748: ret             
    // 0xaf174c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaf174c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaf1750: b               #0xaf15e4
    // 0xaf1754: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xaf1754: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xaf1758: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xaf1758: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xaf175c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xaf175c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xaf1760: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xaf1760: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xaf1764: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xaf1764: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  static _ load(/* No info */) {
    // ** addr: 0x120964c, size: 0x2c
    // 0x120964c: EnterFrame
    //     0x120964c: stp             fp, lr, [SP, #-0x10]!
    //     0x1209650: mov             fp, SP
    // 0x1209654: r1 = <MaterialLocalizations>
    //     0x1209654: add             x1, PP, #0x12, lsl #12  ; [pp+0x128b0] TypeArguments: <MaterialLocalizations>
    //     0x1209658: ldr             x1, [x1, #0x8b0]
    // 0x120965c: r0 = SynchronousFuture()
    //     0x120965c: bl              #0xeb3f1c  ; AllocateSynchronousFutureStub -> SynchronousFuture<X0> (size=0x10)
    // 0x1209660: r1 = Instance_DefaultMaterialLocalizations
    //     0x1209660: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa1a20] Obj!DefaultMaterialLocalizations@129e941
    //     0x1209664: ldr             x1, [x1, #0xa20]
    // 0x1209668: StoreField: r0->field_b = r1
    //     0x1209668: stur            w1, [x0, #0xb]
    // 0x120966c: LeaveFrame
    //     0x120966c: mov             SP, fp
    //     0x1209670: ldp             fp, lr, [SP], #0x10
    // 0x1209674: ret
    //     0x1209674: ret             
  }
}

// class id: 3002, size: 0x8, field offset: 0x8
abstract class MaterialLocalizations extends Object {

  static _ of(/* No info */) {
    // ** addr: 0xd0bbf8, size: 0x58
    // 0xd0bbf8: EnterFrame
    //     0xd0bbf8: stp             fp, lr, [SP, #-0x10]!
    //     0xd0bbfc: mov             fp, SP
    // 0xd0bc00: AllocStack(0x18)
    //     0xd0bc00: sub             SP, SP, #0x18
    // 0xd0bc04: CheckStackOverflow
    //     0xd0bc04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0bc08: cmp             SP, x16
    //     0xd0bc0c: b.ls            #0xd0bc44
    // 0xd0bc10: r16 = <MaterialLocalizations>
    //     0xd0bc10: add             x16, PP, #0x12, lsl #12  ; [pp+0x128b0] TypeArguments: <MaterialLocalizations>
    //     0xd0bc14: ldr             x16, [x16, #0x8b0]
    // 0xd0bc18: stp             x1, x16, [SP, #8]
    // 0xd0bc1c: r16 = MaterialLocalizations
    //     0xd0bc1c: add             x16, PP, #0x12, lsl #12  ; [pp+0x128b8] Type: MaterialLocalizations
    //     0xd0bc20: ldr             x16, [x16, #0x8b8]
    // 0xd0bc24: str             x16, [SP]
    // 0xd0bc28: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xd0bc28: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xd0bc2c: r0 = of()
    //     0xd0bc2c: bl              #0x8bde0c  ; [package:flutter/src/widgets/localizations.dart] Localizations::of
    // 0xd0bc30: cmp             w0, NULL
    // 0xd0bc34: b.eq            #0xd0bc4c
    // 0xd0bc38: LeaveFrame
    //     0xd0bc38: mov             SP, fp
    //     0xd0bc3c: ldp             fp, lr, [SP], #0x10
    // 0xd0bc40: ret
    //     0xd0bc40: ret             
    // 0xd0bc44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0bc44: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0bc48: b               #0xd0bc10
    // 0xd0bc4c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0bc4c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 3273, size: 0xc, field offset: 0xc
//   const constructor, 
class _MaterialLocalizationsDelegate extends LocalizationsDelegate<dynamic> {

  _ isSupported(/* No info */) {
    // ** addr: 0x11a0584, size: 0x70
    // 0x11a0584: EnterFrame
    //     0x11a0584: stp             fp, lr, [SP, #-0x10]!
    //     0x11a0588: mov             fp, SP
    // 0x11a058c: AllocStack(0x18)
    //     0x11a058c: sub             SP, SP, #0x18
    // 0x11a0590: CheckStackOverflow
    //     0x11a0590: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a0594: cmp             SP, x16
    //     0x11a0598: b.ls            #0x11a05ec
    // 0x11a059c: LoadField: r0 = r2->field_7
    //     0x11a059c: ldur            w0, [x2, #7]
    // 0x11a05a0: DecompressPointer r0
    //     0x11a05a0: add             x0, x0, HEAP, lsl #32
    // 0x11a05a4: mov             x2, x0
    // 0x11a05a8: stur            x0, [fp, #-8]
    // 0x11a05ac: r1 = _ConstMap len:78
    //     0x11a05ac: ldr             x1, [PP, #0x2510]  ; [pp+0x2510] Map<String, String>(78)
    // 0x11a05b0: r0 = []()
    //     0x11a05b0: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x11a05b4: cmp             w0, NULL
    // 0x11a05b8: b.ne            #0x11a05c0
    // 0x11a05bc: ldur            x0, [fp, #-8]
    // 0x11a05c0: r1 = LoadClassIdInstr(r0)
    //     0x11a05c0: ldur            x1, [x0, #-1]
    //     0x11a05c4: ubfx            x1, x1, #0xc, #0x14
    // 0x11a05c8: r16 = "en"
    //     0x11a05c8: ldr             x16, [PP, #0x7f98]  ; [pp+0x7f98] "en"
    // 0x11a05cc: stp             x16, x0, [SP]
    // 0x11a05d0: mov             x0, x1
    // 0x11a05d4: mov             lr, x0
    // 0x11a05d8: ldr             lr, [x21, lr, lsl #3]
    // 0x11a05dc: blr             lr
    // 0x11a05e0: LeaveFrame
    //     0x11a05e0: mov             SP, fp
    //     0x11a05e4: ldp             fp, lr, [SP], #0x10
    // 0x11a05e8: ret
    //     0x11a05e8: ret             
    // 0x11a05ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a05ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a05f0: b               #0x11a059c
  }
  _ shouldReload(/* No info */) {
    // ** addr: 0x11b46e8, size: 0x58
    // 0x11b46e8: EnterFrame
    //     0x11b46e8: stp             fp, lr, [SP, #-0x10]!
    //     0x11b46ec: mov             fp, SP
    // 0x11b46f0: mov             x0, x2
    // 0x11b46f4: mov             x4, x1
    // 0x11b46f8: mov             x3, x2
    // 0x11b46fc: r2 = Null
    //     0x11b46fc: mov             x2, NULL
    // 0x11b4700: r1 = Null
    //     0x11b4700: mov             x1, NULL
    // 0x11b4704: r4 = 60
    //     0x11b4704: mov             x4, #0x3c
    // 0x11b4708: branchIfSmi(r0, 0x11b4714)
    //     0x11b4708: tbz             w0, #0, #0x11b4714
    // 0x11b470c: r4 = LoadClassIdInstr(r0)
    //     0x11b470c: ldur            x4, [x0, #-1]
    //     0x11b4710: ubfx            x4, x4, #0xc, #0x14
    // 0x11b4714: cmp             x4, #0xcc9
    // 0x11b4718: b.eq            #0x11b4730
    // 0x11b471c: r8 = _MaterialLocalizationsDelegate
    //     0x11b471c: add             x8, PP, #0xa1, lsl #12  ; [pp+0xa1a08] Type: _MaterialLocalizationsDelegate
    //     0x11b4720: ldr             x8, [x8, #0xa08]
    // 0x11b4724: r3 = Null
    //     0x11b4724: add             x3, PP, #0xa1, lsl #12  ; [pp+0xa1a10] Null
    //     0x11b4728: ldr             x3, [x3, #0xa10]
    // 0x11b472c: r0 = DefaultTypeTest()
    //     0x11b472c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x11b4730: r0 = false
    //     0x11b4730: add             x0, NULL, #0x30  ; false
    // 0x11b4734: LeaveFrame
    //     0x11b4734: mov             SP, fp
    //     0x11b4738: ldp             fp, lr, [SP], #0x10
    // 0x11b473c: ret
    //     0x11b473c: ret             
  }
  _ load(/* No info */) {
    // ** addr: 0x1209620, size: 0x2c
    // 0x1209620: EnterFrame
    //     0x1209620: stp             fp, lr, [SP, #-0x10]!
    //     0x1209624: mov             fp, SP
    // 0x1209628: CheckStackOverflow
    //     0x1209628: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x120962c: cmp             SP, x16
    //     0x1209630: b.ls            #0x1209644
    // 0x1209634: r0 = load()
    //     0x1209634: bl              #0x120964c  ; [package:flutter/src/material/material_localizations.dart] DefaultMaterialLocalizations::load
    // 0x1209638: LeaveFrame
    //     0x1209638: mov             SP, fp
    //     0x120963c: ldp             fp, lr, [SP], #0x10
    // 0x1209640: ret
    //     0x1209640: ret             
    // 0x1209644: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1209644: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1209648: b               #0x1209634
  }
}
