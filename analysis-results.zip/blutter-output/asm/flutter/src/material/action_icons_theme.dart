// lib: , url: package:flutter/src/material/action_icons_theme.dart

// class id: 1048839, size: 0x8
class :: {
}

// class id: 5212, size: 0x18, field offset: 0x8
//   const constructor, 
class ActionIconThemeData extends _MixinApplication3&Object&Diagnosticable {
}

// class id: 6853, size: 0x10, field offset: 0x10
//   const constructor, 
abstract class ActionIconTheme extends InheritedTheme {

  static _ of(/* No info */) {
    // ** addr: 0xfae9c4, size: 0x50
    // 0xfae9c4: EnterFrame
    //     0xfae9c4: stp             fp, lr, [SP, #-0x10]!
    //     0xfae9c8: mov             fp, SP
    // 0xfae9cc: AllocStack(0x18)
    //     0xfae9cc: sub             SP, SP, #0x18
    // 0xfae9d0: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0xfae9d0: stur            x1, [fp, #-8]
    // 0xfae9d4: CheckStackOverflow
    //     0xfae9d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfae9d8: cmp             SP, x16
    //     0xfae9dc: b.ls            #0xfaea0c
    // 0xfae9e0: r16 = <ActionIconTheme>
    //     0xfae9e0: add             x16, PP, #0xa0, lsl #12  ; [pp+0xa0fc8] TypeArguments: <ActionIconTheme>
    //     0xfae9e4: ldr             x16, [x16, #0xfc8]
    // 0xfae9e8: stp             x1, x16, [SP]
    // 0xfae9ec: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xfae9ec: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xfae9f0: r0 = dependOnInheritedWidgetOfExactType()
    //     0xfae9f0: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xfae9f4: ldur            x1, [fp, #-8]
    // 0xfae9f8: r0 = of()
    //     0xfae9f8: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfae9fc: r0 = Null
    //     0xfae9fc: mov             x0, NULL
    // 0xfaea00: LeaveFrame
    //     0xfaea00: mov             SP, fp
    //     0xfaea04: ldp             fp, lr, [SP], #0x10
    // 0xfaea08: ret
    //     0xfaea08: ret             
    // 0xfaea0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfaea0c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfaea10: b               #0xfae9e0
  }
}
