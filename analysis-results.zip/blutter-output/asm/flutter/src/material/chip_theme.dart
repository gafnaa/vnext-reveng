// lib: , url: package:flutter/src/material/chip_theme.dart

// class id: 1048867, size: 0x8
class :: {
}

// class id: 5172, size: 0x64, field offset: 0x8
//   const constructor, 
class ChipThemeData extends _MixinApplication3&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0x1130108, size: 0x1a0
    // 0x1130108: EnterFrame
    //     0x1130108: stp             fp, lr, [SP, #-0x10]!
    //     0x113010c: mov             fp, SP
    // 0x1130110: AllocStack(0x10)
    //     0x1130110: sub             SP, SP, #0x10
    // 0x1130114: r0 = 46
    //     0x1130114: mov             x0, #0x2e
    // 0x1130118: CheckStackOverflow
    //     0x1130118: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x113011c: cmp             SP, x16
    //     0x1130120: b.ls            #0x11302a0
    // 0x1130124: ldr             x3, [fp, #0x10]
    // 0x1130128: LoadField: r4 = r3->field_7
    //     0x1130128: ldur            w4, [x3, #7]
    // 0x113012c: DecompressPointer r4
    //     0x113012c: add             x4, x4, HEAP, lsl #32
    // 0x1130130: mov             x2, x0
    // 0x1130134: stur            x4, [fp, #-8]
    // 0x1130138: r1 = <Object?>
    //     0x1130138: ldr             x1, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0x113013c: r0 = AllocateArray()
    //     0x113013c: bl              #0x13df928  ; AllocateArrayStub
    // 0x1130140: mov             x2, x0
    // 0x1130144: ldur            x0, [fp, #-8]
    // 0x1130148: stur            x2, [fp, #-0x10]
    // 0x113014c: StoreField: r2->field_f = r0
    //     0x113014c: stur            w0, [x2, #0xf]
    // 0x1130150: ldr             x0, [fp, #0x10]
    // 0x1130154: LoadField: r1 = r0->field_b
    //     0x1130154: ldur            w1, [x0, #0xb]
    // 0x1130158: DecompressPointer r1
    //     0x1130158: add             x1, x1, HEAP, lsl #32
    // 0x113015c: StoreField: r2->field_13 = r1
    //     0x113015c: stur            w1, [x2, #0x13]
    // 0x1130160: LoadField: r1 = r0->field_f
    //     0x1130160: ldur            w1, [x0, #0xf]
    // 0x1130164: DecompressPointer r1
    //     0x1130164: add             x1, x1, HEAP, lsl #32
    // 0x1130168: ArrayStore: r2[0] = r1  ; List_4
    //     0x1130168: stur            w1, [x2, #0x17]
    // 0x113016c: LoadField: r1 = r0->field_13
    //     0x113016c: ldur            w1, [x0, #0x13]
    // 0x1130170: DecompressPointer r1
    //     0x1130170: add             x1, x1, HEAP, lsl #32
    // 0x1130174: StoreField: r2->field_1b = r1
    //     0x1130174: stur            w1, [x2, #0x1b]
    // 0x1130178: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x1130178: ldur            w1, [x0, #0x17]
    // 0x113017c: DecompressPointer r1
    //     0x113017c: add             x1, x1, HEAP, lsl #32
    // 0x1130180: StoreField: r2->field_1f = r1
    //     0x1130180: stur            w1, [x2, #0x1f]
    // 0x1130184: LoadField: r1 = r0->field_1b
    //     0x1130184: ldur            w1, [x0, #0x1b]
    // 0x1130188: DecompressPointer r1
    //     0x1130188: add             x1, x1, HEAP, lsl #32
    // 0x113018c: StoreField: r2->field_23 = r1
    //     0x113018c: stur            w1, [x2, #0x23]
    // 0x1130190: LoadField: r1 = r0->field_1f
    //     0x1130190: ldur            w1, [x0, #0x1f]
    // 0x1130194: DecompressPointer r1
    //     0x1130194: add             x1, x1, HEAP, lsl #32
    // 0x1130198: StoreField: r2->field_27 = r1
    //     0x1130198: stur            w1, [x2, #0x27]
    // 0x113019c: LoadField: r1 = r0->field_23
    //     0x113019c: ldur            w1, [x0, #0x23]
    // 0x11301a0: DecompressPointer r1
    //     0x11301a0: add             x1, x1, HEAP, lsl #32
    // 0x11301a4: StoreField: r2->field_2b = r1
    //     0x11301a4: stur            w1, [x2, #0x2b]
    // 0x11301a8: LoadField: r1 = r0->field_27
    //     0x11301a8: ldur            w1, [x0, #0x27]
    // 0x11301ac: DecompressPointer r1
    //     0x11301ac: add             x1, x1, HEAP, lsl #32
    // 0x11301b0: StoreField: r2->field_2f = r1
    //     0x11301b0: stur            w1, [x2, #0x2f]
    // 0x11301b4: LoadField: r1 = r0->field_2b
    //     0x11301b4: ldur            w1, [x0, #0x2b]
    // 0x11301b8: DecompressPointer r1
    //     0x11301b8: add             x1, x1, HEAP, lsl #32
    // 0x11301bc: StoreField: r2->field_33 = r1
    //     0x11301bc: stur            w1, [x2, #0x33]
    // 0x11301c0: LoadField: r1 = r0->field_2f
    //     0x11301c0: ldur            w1, [x0, #0x2f]
    // 0x11301c4: DecompressPointer r1
    //     0x11301c4: add             x1, x1, HEAP, lsl #32
    // 0x11301c8: StoreField: r2->field_37 = r1
    //     0x11301c8: stur            w1, [x2, #0x37]
    // 0x11301cc: LoadField: r1 = r0->field_33
    //     0x11301cc: ldur            w1, [x0, #0x33]
    // 0x11301d0: DecompressPointer r1
    //     0x11301d0: add             x1, x1, HEAP, lsl #32
    // 0x11301d4: StoreField: r2->field_3b = r1
    //     0x11301d4: stur            w1, [x2, #0x3b]
    // 0x11301d8: LoadField: r1 = r0->field_37
    //     0x11301d8: ldur            w1, [x0, #0x37]
    // 0x11301dc: DecompressPointer r1
    //     0x11301dc: add             x1, x1, HEAP, lsl #32
    // 0x11301e0: StoreField: r2->field_3f = r1
    //     0x11301e0: stur            w1, [x2, #0x3f]
    // 0x11301e4: LoadField: r1 = r0->field_3b
    //     0x11301e4: ldur            w1, [x0, #0x3b]
    // 0x11301e8: DecompressPointer r1
    //     0x11301e8: add             x1, x1, HEAP, lsl #32
    // 0x11301ec: StoreField: r2->field_43 = r1
    //     0x11301ec: stur            w1, [x2, #0x43]
    // 0x11301f0: LoadField: r1 = r0->field_3f
    //     0x11301f0: ldur            w1, [x0, #0x3f]
    // 0x11301f4: DecompressPointer r1
    //     0x11301f4: add             x1, x1, HEAP, lsl #32
    // 0x11301f8: StoreField: r2->field_47 = r1
    //     0x11301f8: stur            w1, [x2, #0x47]
    // 0x11301fc: LoadField: r1 = r0->field_43
    //     0x11301fc: ldur            w1, [x0, #0x43]
    // 0x1130200: DecompressPointer r1
    //     0x1130200: add             x1, x1, HEAP, lsl #32
    // 0x1130204: StoreField: r2->field_4b = r1
    //     0x1130204: stur            w1, [x2, #0x4b]
    // 0x1130208: LoadField: r1 = r0->field_47
    //     0x1130208: ldur            w1, [x0, #0x47]
    // 0x113020c: DecompressPointer r1
    //     0x113020c: add             x1, x1, HEAP, lsl #32
    // 0x1130210: StoreField: r2->field_4f = r1
    //     0x1130210: stur            w1, [x2, #0x4f]
    // 0x1130214: LoadField: r1 = r0->field_4b
    //     0x1130214: ldur            w1, [x0, #0x4b]
    // 0x1130218: DecompressPointer r1
    //     0x1130218: add             x1, x1, HEAP, lsl #32
    // 0x113021c: StoreField: r2->field_53 = r1
    //     0x113021c: stur            w1, [x2, #0x53]
    // 0x1130220: LoadField: r1 = r0->field_4f
    //     0x1130220: ldur            w1, [x0, #0x4f]
    // 0x1130224: DecompressPointer r1
    //     0x1130224: add             x1, x1, HEAP, lsl #32
    // 0x1130228: StoreField: r2->field_57 = r1
    //     0x1130228: stur            w1, [x2, #0x57]
    // 0x113022c: LoadField: r1 = r0->field_53
    //     0x113022c: ldur            w1, [x0, #0x53]
    // 0x1130230: DecompressPointer r1
    //     0x1130230: add             x1, x1, HEAP, lsl #32
    // 0x1130234: StoreField: r2->field_5b = r1
    //     0x1130234: stur            w1, [x2, #0x5b]
    // 0x1130238: LoadField: r1 = r0->field_57
    //     0x1130238: ldur            w1, [x0, #0x57]
    // 0x113023c: DecompressPointer r1
    //     0x113023c: add             x1, x1, HEAP, lsl #32
    // 0x1130240: StoreField: r2->field_5f = r1
    //     0x1130240: stur            w1, [x2, #0x5f]
    // 0x1130244: LoadField: r1 = r0->field_5b
    //     0x1130244: ldur            w1, [x0, #0x5b]
    // 0x1130248: DecompressPointer r1
    //     0x1130248: add             x1, x1, HEAP, lsl #32
    // 0x113024c: StoreField: r2->field_63 = r1
    //     0x113024c: stur            w1, [x2, #0x63]
    // 0x1130250: LoadField: r1 = r0->field_5f
    //     0x1130250: ldur            w1, [x0, #0x5f]
    // 0x1130254: DecompressPointer r1
    //     0x1130254: add             x1, x1, HEAP, lsl #32
    // 0x1130258: StoreField: r2->field_67 = r1
    //     0x1130258: stur            w1, [x2, #0x67]
    // 0x113025c: r1 = <Object?>
    //     0x113025c: ldr             x1, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0x1130260: r0 = AllocateGrowableArray()
    //     0x1130260: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x1130264: mov             x1, x0
    // 0x1130268: ldur            x0, [fp, #-0x10]
    // 0x113026c: StoreField: r1->field_f = r0
    //     0x113026c: stur            w0, [x1, #0xf]
    // 0x1130270: r0 = 46
    //     0x1130270: mov             x0, #0x2e
    // 0x1130274: StoreField: r1->field_b = r0
    //     0x1130274: stur            w0, [x1, #0xb]
    // 0x1130278: r0 = hashAll()
    //     0x1130278: bl              #0x112b348  ; [dart:core] Object::hashAll
    // 0x113027c: mov             x2, x0
    // 0x1130280: r0 = BoxInt64Instr(r2)
    //     0x1130280: sbfiz           x0, x2, #1, #0x1f
    //     0x1130284: cmp             x2, x0, asr #1
    //     0x1130288: b.eq            #0x1130294
    //     0x113028c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1130290: stur            x2, [x0, #7]
    // 0x1130294: LeaveFrame
    //     0x1130294: mov             SP, fp
    //     0x1130298: ldp             fp, lr, [SP], #0x10
    // 0x113029c: ret
    //     0x113029c: ret             
    // 0x11302a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11302a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11302a4: b               #0x1130124
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x116814c, size: 0x234
    // 0x116814c: EnterFrame
    //     0x116814c: stp             fp, lr, [SP, #-0x10]!
    //     0x1168150: mov             fp, SP
    // 0x1168154: AllocStack(0x28)
    //     0x1168154: sub             SP, SP, #0x28
    // 0x1168158: SetupParameters(dynamic _ /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */, dynamic _ /* d0 => d0, fp-0x28 */)
    //     0x1168158: mov             x4, x1
    //     0x116815c: mov             x0, x2
    //     0x1168160: stur            x1, [fp, #-0x10]
    //     0x1168164: stur            x2, [fp, #-0x18]
    //     0x1168168: stur            d0, [fp, #-0x28]
    // 0x116816c: CheckStackOverflow
    //     0x116816c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1168170: cmp             SP, x16
    //     0x1168174: b.ls            #0x116835c
    // 0x1168178: cmp             w4, w0
    // 0x116817c: b.ne            #0x1168190
    // 0x1168180: mov             x0, x4
    // 0x1168184: LeaveFrame
    //     0x1168184: mov             SP, fp
    //     0x1168188: ldp             fp, lr, [SP], #0x10
    // 0x116818c: ret
    //     0x116818c: ret             
    // 0x1168190: r5 = inline_Allocate_Double()
    //     0x1168190: ldp             x5, x1, [THR, #0x60]  ; THR::top
    //     0x1168194: add             x5, x5, #0x10
    //     0x1168198: cmp             x1, x5
    //     0x116819c: b.ls            #0x1168364
    //     0x11681a0: str             x5, [THR, #0x60]  ; THR::top
    //     0x11681a4: sub             x5, x5, #0xf
    //     0x11681a8: mov             x1, #0xe19c
    //     0x11681ac: movk            x1, #3, lsl #16
    //     0x11681b0: stur            x1, [x5, #-1]
    // 0x11681b4: dmb             ishst
    // 0x11681b8: StoreField: r5->field_7 = d0
    //     0x11681b8: stur            d0, [x5, #7]
    // 0x11681bc: mov             x3, x5
    // 0x11681c0: stur            x5, [fp, #-8]
    // 0x11681c4: r1 = Null
    //     0x11681c4: mov             x1, NULL
    // 0x11681c8: r2 = Null
    //     0x11681c8: mov             x2, NULL
    // 0x11681cc: r0 = lerp()
    //     0x11681cc: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x11681d0: ldur            x3, [fp, #-8]
    // 0x11681d4: r1 = Null
    //     0x11681d4: mov             x1, NULL
    // 0x11681d8: r2 = Null
    //     0x11681d8: mov             x2, NULL
    // 0x11681dc: r0 = lerp()
    //     0x11681dc: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x11681e0: ldur            x3, [fp, #-8]
    // 0x11681e4: r1 = Null
    //     0x11681e4: mov             x1, NULL
    // 0x11681e8: r2 = Null
    //     0x11681e8: mov             x2, NULL
    // 0x11681ec: r0 = lerp()
    //     0x11681ec: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x11681f0: ldur            x3, [fp, #-8]
    // 0x11681f4: r1 = Null
    //     0x11681f4: mov             x1, NULL
    // 0x11681f8: r2 = Null
    //     0x11681f8: mov             x2, NULL
    // 0x11681fc: r0 = lerp()
    //     0x11681fc: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1168200: ldur            x3, [fp, #-8]
    // 0x1168204: r1 = Null
    //     0x1168204: mov             x1, NULL
    // 0x1168208: r2 = Null
    //     0x1168208: mov             x2, NULL
    // 0x116820c: r0 = lerp()
    //     0x116820c: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1168210: ldur            x3, [fp, #-8]
    // 0x1168214: r1 = Null
    //     0x1168214: mov             x1, NULL
    // 0x1168218: r2 = Null
    //     0x1168218: mov             x2, NULL
    // 0x116821c: r0 = lerp()
    //     0x116821c: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1168220: ldur            x3, [fp, #-8]
    // 0x1168224: r1 = Null
    //     0x1168224: mov             x1, NULL
    // 0x1168228: r2 = Null
    //     0x1168228: mov             x2, NULL
    // 0x116822c: r0 = lerp()
    //     0x116822c: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1168230: ldur            x3, [fp, #-8]
    // 0x1168234: r1 = Null
    //     0x1168234: mov             x1, NULL
    // 0x1168238: r2 = Null
    //     0x1168238: mov             x2, NULL
    // 0x116823c: r0 = lerp()
    //     0x116823c: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1168240: ldur            d0, [fp, #-0x28]
    // 0x1168244: d1 = 0.500000
    //     0x1168244: fmov            d1, #0.50000000
    // 0x1168248: fcmp            d1, d0
    // 0x116824c: b.gt            #0x1168250
    // 0x1168250: ldur            x3, [fp, #-8]
    // 0x1168254: r1 = Null
    //     0x1168254: mov             x1, NULL
    // 0x1168258: r2 = Null
    //     0x1168258: mov             x2, NULL
    // 0x116825c: r0 = lerp()
    //     0x116825c: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1168260: ldur            x3, [fp, #-8]
    // 0x1168264: r1 = Null
    //     0x1168264: mov             x1, NULL
    // 0x1168268: r2 = Null
    //     0x1168268: mov             x2, NULL
    // 0x116826c: r0 = lerp()
    //     0x116826c: bl              #0x1140de0  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0x1168270: ldur            x3, [fp, #-8]
    // 0x1168274: r1 = Null
    //     0x1168274: mov             x1, NULL
    // 0x1168278: r2 = Null
    //     0x1168278: mov             x2, NULL
    // 0x116827c: r0 = lerp()
    //     0x116827c: bl              #0x1140de0  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0x1168280: ldur            x3, [fp, #-8]
    // 0x1168284: r1 = Null
    //     0x1168284: mov             x1, NULL
    // 0x1168288: r2 = Null
    //     0x1168288: mov             x2, NULL
    // 0x116828c: r0 = lerp()
    //     0x116828c: bl              #0x1165150  ; [package:flutter/src/painting/borders.dart] OutlinedBorder::lerp
    // 0x1168290: ldur            x3, [fp, #-8]
    // 0x1168294: r1 = Null
    //     0x1168294: mov             x1, NULL
    // 0x1168298: r2 = Null
    //     0x1168298: mov             x2, NULL
    // 0x116829c: r0 = lerp()
    //     0x116829c: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x11682a0: ldur            x3, [fp, #-8]
    // 0x11682a4: r1 = Null
    //     0x11682a4: mov             x1, NULL
    // 0x11682a8: r2 = Null
    //     0x11682a8: mov             x2, NULL
    // 0x11682ac: r0 = lerp()
    //     0x11682ac: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x11682b0: ldur            d0, [fp, #-0x28]
    // 0x11682b4: d1 = 0.500000
    //     0x11682b4: fmov            d1, #0.50000000
    // 0x11682b8: fcmp            d1, d0
    // 0x11682bc: b.gt            #0x11682c0
    // 0x11682c0: ldur            x4, [fp, #-0x10]
    // 0x11682c4: ldur            x0, [fp, #-0x18]
    // 0x11682c8: LoadField: r1 = r4->field_4f
    //     0x11682c8: ldur            w1, [x4, #0x4f]
    // 0x11682cc: DecompressPointer r1
    //     0x11682cc: add             x1, x1, HEAP, lsl #32
    // 0x11682d0: LoadField: r2 = r0->field_4f
    //     0x11682d0: ldur            w2, [x0, #0x4f]
    // 0x11682d4: DecompressPointer r2
    //     0x11682d4: add             x2, x2, HEAP, lsl #32
    // 0x11682d8: ldur            x3, [fp, #-8]
    // 0x11682dc: r0 = lerpDouble()
    //     0x11682dc: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x11682e0: mov             x4, x0
    // 0x11682e4: ldur            x0, [fp, #-0x10]
    // 0x11682e8: stur            x4, [fp, #-0x20]
    // 0x11682ec: LoadField: r1 = r0->field_53
    //     0x11682ec: ldur            w1, [x0, #0x53]
    // 0x11682f0: DecompressPointer r1
    //     0x11682f0: add             x1, x1, HEAP, lsl #32
    // 0x11682f4: ldur            x0, [fp, #-0x18]
    // 0x11682f8: LoadField: r2 = r0->field_53
    //     0x11682f8: ldur            w2, [x0, #0x53]
    // 0x11682fc: DecompressPointer r2
    //     0x11682fc: add             x2, x2, HEAP, lsl #32
    // 0x1168300: ldur            x3, [fp, #-8]
    // 0x1168304: r0 = lerpDouble()
    //     0x1168304: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x1168308: ldur            d0, [fp, #-0x28]
    // 0x116830c: r1 = Null
    //     0x116830c: mov             x1, NULL
    // 0x1168310: r2 = Null
    //     0x1168310: mov             x2, NULL
    // 0x1168314: stur            x0, [fp, #-8]
    // 0x1168318: r0 = lerp()
    //     0x1168318: bl              #0x1163c14  ; [package:flutter/src/rendering/box.dart] BoxConstraints::lerp
    // 0x116831c: ldur            d0, [fp, #-0x28]
    // 0x1168320: r1 = Null
    //     0x1168320: mov             x1, NULL
    // 0x1168324: r2 = Null
    //     0x1168324: mov             x2, NULL
    // 0x1168328: r0 = lerp()
    //     0x1168328: bl              #0x1163c14  ; [package:flutter/src/rendering/box.dart] BoxConstraints::lerp
    // 0x116832c: r0 = ChipThemeData()
    //     0x116832c: bl              #0x1168380  ; AllocateChipThemeDataStub -> ChipThemeData (size=0x64)
    // 0x1168330: r1 = true
    //     0x1168330: add             x1, NULL, #0x20  ; true
    // 0x1168334: StoreField: r0->field_2b = r1
    //     0x1168334: stur            w1, [x0, #0x2b]
    // 0x1168338: r1 = Instance_Brightness
    //     0x1168338: ldr             x1, [PP, #0x6da0]  ; [pp+0x6da0] Obj!Brightness@12c71c1
    // 0x116833c: StoreField: r0->field_4b = r1
    //     0x116833c: stur            w1, [x0, #0x4b]
    // 0x1168340: ldur            x1, [fp, #-0x20]
    // 0x1168344: StoreField: r0->field_4f = r1
    //     0x1168344: stur            w1, [x0, #0x4f]
    // 0x1168348: ldur            x1, [fp, #-8]
    // 0x116834c: StoreField: r0->field_53 = r1
    //     0x116834c: stur            w1, [x0, #0x53]
    // 0x1168350: LeaveFrame
    //     0x1168350: mov             SP, fp
    //     0x1168354: ldp             fp, lr, [SP], #0x10
    // 0x1168358: ret
    //     0x1168358: ret             
    // 0x116835c: r0 = StackOverflowSharedWithFPURegs()
    //     0x116835c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1168360: b               #0x1168178
    // 0x1168364: SaveReg d0
    //     0x1168364: str             q0, [SP, #-0x10]!
    // 0x1168368: stp             x0, x4, [SP, #-0x10]!
    // 0x116836c: r0 = AllocateDouble()
    //     0x116836c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1168370: mov             x5, x0
    // 0x1168374: ldp             x0, x4, [SP], #0x10
    // 0x1168378: RestoreReg d0
    //     0x1168378: ldr             q0, [SP], #0x10
    // 0x116837c: b               #0x11681b8
  }
  _ ==(/* No info */) {
    // ** addr: 0x12668bc, size: 0x16c
    // 0x12668bc: EnterFrame
    //     0x12668bc: stp             fp, lr, [SP, #-0x10]!
    //     0x12668c0: mov             fp, SP
    // 0x12668c4: AllocStack(0x10)
    //     0x12668c4: sub             SP, SP, #0x10
    // 0x12668c8: CheckStackOverflow
    //     0x12668c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12668cc: cmp             SP, x16
    //     0x12668d0: b.ls            #0x1266a20
    // 0x12668d4: ldr             x0, [fp, #0x10]
    // 0x12668d8: cmp             w0, NULL
    // 0x12668dc: b.ne            #0x12668f0
    // 0x12668e0: r0 = false
    //     0x12668e0: add             x0, NULL, #0x30  ; false
    // 0x12668e4: LeaveFrame
    //     0x12668e4: mov             SP, fp
    //     0x12668e8: ldp             fp, lr, [SP], #0x10
    // 0x12668ec: ret
    //     0x12668ec: ret             
    // 0x12668f0: ldr             x1, [fp, #0x18]
    // 0x12668f4: cmp             w1, w0
    // 0x12668f8: b.ne            #0x126690c
    // 0x12668fc: r0 = true
    //     0x12668fc: add             x0, NULL, #0x20  ; true
    // 0x1266900: LeaveFrame
    //     0x1266900: mov             SP, fp
    //     0x1266904: ldp             fp, lr, [SP], #0x10
    // 0x1266908: ret
    //     0x1266908: ret             
    // 0x126690c: str             x0, [SP]
    // 0x1266910: r0 = runtimeType()
    //     0x1266910: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x1266914: r1 = LoadClassIdInstr(r0)
    //     0x1266914: ldur            x1, [x0, #-1]
    //     0x1266918: ubfx            x1, x1, #0xc, #0x14
    // 0x126691c: r16 = ChipThemeData
    //     0x126691c: add             x16, PP, #0x26, lsl #12  ; [pp+0x26808] Type: ChipThemeData
    //     0x1266920: ldr             x16, [x16, #0x808]
    // 0x1266924: stp             x16, x0, [SP]
    // 0x1266928: mov             x0, x1
    // 0x126692c: mov             lr, x0
    // 0x1266930: ldr             lr, [x21, lr, lsl #3]
    // 0x1266934: blr             lr
    // 0x1266938: tbz             w0, #4, #0x126694c
    // 0x126693c: r0 = false
    //     0x126693c: add             x0, NULL, #0x30  ; false
    // 0x1266940: LeaveFrame
    //     0x1266940: mov             SP, fp
    //     0x1266944: ldp             fp, lr, [SP], #0x10
    // 0x1266948: ret
    //     0x1266948: ret             
    // 0x126694c: ldr             x1, [fp, #0x10]
    // 0x1266950: r0 = 60
    //     0x1266950: mov             x0, #0x3c
    // 0x1266954: branchIfSmi(r1, 0x1266960)
    //     0x1266954: tbz             w1, #0, #0x1266960
    // 0x1266958: r0 = LoadClassIdInstr(r1)
    //     0x1266958: ldur            x0, [x1, #-1]
    //     0x126695c: ubfx            x0, x0, #0xc, #0x14
    // 0x1266960: r17 = 5172
    //     0x1266960: mov             x17, #0x1434
    // 0x1266964: cmp             x0, x17
    // 0x1266968: b.ne            #0x1266a10
    // 0x126696c: ldr             x2, [fp, #0x18]
    // 0x1266970: LoadField: r0 = r1->field_2b
    //     0x1266970: ldur            w0, [x1, #0x2b]
    // 0x1266974: DecompressPointer r0
    //     0x1266974: add             x0, x0, HEAP, lsl #32
    // 0x1266978: LoadField: r3 = r2->field_2b
    //     0x1266978: ldur            w3, [x2, #0x2b]
    // 0x126697c: DecompressPointer r3
    //     0x126697c: add             x3, x3, HEAP, lsl #32
    // 0x1266980: cmp             w0, w3
    // 0x1266984: b.ne            #0x1266a10
    // 0x1266988: LoadField: r0 = r1->field_4b
    //     0x1266988: ldur            w0, [x1, #0x4b]
    // 0x126698c: DecompressPointer r0
    //     0x126698c: add             x0, x0, HEAP, lsl #32
    // 0x1266990: LoadField: r3 = r2->field_4b
    //     0x1266990: ldur            w3, [x2, #0x4b]
    // 0x1266994: DecompressPointer r3
    //     0x1266994: add             x3, x3, HEAP, lsl #32
    // 0x1266998: cmp             w0, w3
    // 0x126699c: b.ne            #0x1266a10
    // 0x12669a0: LoadField: r0 = r1->field_4f
    //     0x12669a0: ldur            w0, [x1, #0x4f]
    // 0x12669a4: DecompressPointer r0
    //     0x12669a4: add             x0, x0, HEAP, lsl #32
    // 0x12669a8: LoadField: r3 = r2->field_4f
    //     0x12669a8: ldur            w3, [x2, #0x4f]
    // 0x12669ac: DecompressPointer r3
    //     0x12669ac: add             x3, x3, HEAP, lsl #32
    // 0x12669b0: r4 = LoadClassIdInstr(r0)
    //     0x12669b0: ldur            x4, [x0, #-1]
    //     0x12669b4: ubfx            x4, x4, #0xc, #0x14
    // 0x12669b8: stp             x3, x0, [SP]
    // 0x12669bc: mov             x0, x4
    // 0x12669c0: mov             lr, x0
    // 0x12669c4: ldr             lr, [x21, lr, lsl #3]
    // 0x12669c8: blr             lr
    // 0x12669cc: tbnz            w0, #4, #0x1266a10
    // 0x12669d0: ldr             x1, [fp, #0x18]
    // 0x12669d4: ldr             x0, [fp, #0x10]
    // 0x12669d8: LoadField: r2 = r0->field_53
    //     0x12669d8: ldur            w2, [x0, #0x53]
    // 0x12669dc: DecompressPointer r2
    //     0x12669dc: add             x2, x2, HEAP, lsl #32
    // 0x12669e0: LoadField: r0 = r1->field_53
    //     0x12669e0: ldur            w0, [x1, #0x53]
    // 0x12669e4: DecompressPointer r0
    //     0x12669e4: add             x0, x0, HEAP, lsl #32
    // 0x12669e8: r1 = LoadClassIdInstr(r2)
    //     0x12669e8: ldur            x1, [x2, #-1]
    //     0x12669ec: ubfx            x1, x1, #0xc, #0x14
    // 0x12669f0: stp             x0, x2, [SP]
    // 0x12669f4: mov             x0, x1
    // 0x12669f8: mov             lr, x0
    // 0x12669fc: ldr             lr, [x21, lr, lsl #3]
    // 0x1266a00: blr             lr
    // 0x1266a04: tbnz            w0, #4, #0x1266a10
    // 0x1266a08: r0 = true
    //     0x1266a08: add             x0, NULL, #0x20  ; true
    // 0x1266a0c: b               #0x1266a14
    // 0x1266a10: r0 = false
    //     0x1266a10: add             x0, NULL, #0x30  ; false
    // 0x1266a14: LeaveFrame
    //     0x1266a14: mov             SP, fp
    //     0x1266a18: ldp             fp, lr, [SP], #0x10
    // 0x1266a1c: ret
    //     0x1266a1c: ret             
    // 0x1266a20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1266a20: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1266a24: b               #0x12668d4
  }
}
