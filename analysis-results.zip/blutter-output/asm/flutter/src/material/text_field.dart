// lib: , url: package:flutter/src/material/text_field.dart

// class id: 1048961, size: 0x8
class :: {

  static _ _m2CounterErrorStyle(/* No info */) {
    // ** addr: 0xd49150, size: 0x88
    // 0xd49150: EnterFrame
    //     0xd49150: stp             fp, lr, [SP, #-0x10]!
    //     0xd49154: mov             fp, SP
    // 0xd49158: AllocStack(0x18)
    //     0xd49158: sub             SP, SP, #0x18
    // 0xd4915c: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */)
    //     0xd4915c: mov             x0, x1
    //     0xd49160: stur            x1, [fp, #-8]
    // 0xd49164: CheckStackOverflow
    //     0xd49164: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd49168: cmp             SP, x16
    //     0xd4916c: b.ls            #0xd491cc
    // 0xd49170: mov             x1, x0
    // 0xd49174: r0 = of()
    //     0xd49174: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd49178: LoadField: r1 = r0->field_87
    //     0xd49178: ldur            w1, [x0, #0x87]
    // 0xd4917c: DecompressPointer r1
    //     0xd4917c: add             x1, x1, HEAP, lsl #32
    // 0xd49180: LoadField: r0 = r1->field_33
    //     0xd49180: ldur            w0, [x1, #0x33]
    // 0xd49184: DecompressPointer r0
    //     0xd49184: add             x0, x0, HEAP, lsl #32
    // 0xd49188: stur            x0, [fp, #-0x10]
    // 0xd4918c: cmp             w0, NULL
    // 0xd49190: b.eq            #0xd491d4
    // 0xd49194: ldur            x1, [fp, #-8]
    // 0xd49198: r0 = of()
    //     0xd49198: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd4919c: LoadField: r1 = r0->field_3f
    //     0xd4919c: ldur            w1, [x0, #0x3f]
    // 0xd491a0: DecompressPointer r1
    //     0xd491a0: add             x1, x1, HEAP, lsl #32
    // 0xd491a4: LoadField: r0 = r1->field_6b
    //     0xd491a4: ldur            w0, [x1, #0x6b]
    // 0xd491a8: DecompressPointer r0
    //     0xd491a8: add             x0, x0, HEAP, lsl #32
    // 0xd491ac: str             x0, [SP]
    // 0xd491b0: ldur            x1, [fp, #-0x10]
    // 0xd491b4: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0xd491b4: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0xd491b8: ldr             x4, [x4, #0x7f0]
    // 0xd491bc: r0 = copyWith()
    //     0xd491bc: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xd491c0: LeaveFrame
    //     0xd491c0: mov             SP, fp
    //     0xd491c4: ldp             fp, lr, [SP], #0x10
    // 0xd491c8: ret
    //     0xd491c8: ret             
    // 0xd491cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd491cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd491d0: b               #0xd49170
    // 0xd491d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd491d4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static _ _m2StateInputStyle(/* No info */) {
    // ** addr: 0xd49730, size: 0x60
    // 0xd49730: EnterFrame
    //     0xd49730: stp             fp, lr, [SP, #-0x10]!
    //     0xd49734: mov             fp, SP
    // 0xd49738: AllocStack(0x10)
    //     0xd49738: sub             SP, SP, #0x10
    // 0xd4973c: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0xd4973c: stur            x1, [fp, #-8]
    // 0xd49740: r1 = 1
    //     0xd49740: mov             x1, #1
    // 0xd49744: r0 = AllocateContext()
    //     0xd49744: bl              #0x13de838  ; AllocateContextStub
    // 0xd49748: mov             x1, x0
    // 0xd4974c: ldur            x0, [fp, #-8]
    // 0xd49750: stur            x1, [fp, #-0x10]
    // 0xd49754: StoreField: r1->field_f = r0
    //     0xd49754: stur            w0, [x1, #0xf]
    // 0xd49758: r0 = _WidgetStateTextStyle()
    //     0xd49758: bl              #0xd28900  ; Allocate_WidgetStateTextStyleStub -> _WidgetStateTextStyle (size=0x74)
    // 0xd4975c: ldur            x2, [fp, #-0x10]
    // 0xd49760: r1 = Function '<anonymous closure>': static.
    //     0xd49760: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f8c0] AnonymousClosure: static (0xd49790), in [package:flutter/src/material/text_field.dart] ::_m2StateInputStyle (0xd49730)
    //     0xd49764: ldr             x1, [x1, #0x8c0]
    // 0xd49768: stur            x0, [fp, #-8]
    // 0xd4976c: r0 = AllocateClosure()
    //     0xd4976c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd49770: mov             x1, x0
    // 0xd49774: ldur            x0, [fp, #-8]
    // 0xd49778: StoreField: r0->field_6f = r1
    //     0xd49778: stur            w1, [x0, #0x6f]
    // 0xd4977c: r1 = true
    //     0xd4977c: add             x1, NULL, #0x20  ; true
    // 0xd49780: StoreField: r0->field_7 = r1
    //     0xd49780: stur            w1, [x0, #7]
    // 0xd49784: LeaveFrame
    //     0xd49784: mov             SP, fp
    //     0xd49788: ldp             fp, lr, [SP], #0x10
    // 0xd4978c: ret
    //     0xd4978c: ret             
  }
  [closure] static TextStyle <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xd49790, size: 0xe4
    // 0xd49790: EnterFrame
    //     0xd49790: stp             fp, lr, [SP, #-0x10]!
    //     0xd49794: mov             fp, SP
    // 0xd49798: AllocStack(0x10)
    //     0xd49798: sub             SP, SP, #0x10
    // 0xd4979c: SetupParameters([dynamic _ /* r0 */])
    //     0xd4979c: ldr             x0, [fp, #0x18]
    //     0xd497a0: ldur            w1, [x0, #0x17]
    //     0xd497a4: add             x1, x1, HEAP, lsl #32
    // 0xd497a8: CheckStackOverflow
    //     0xd497a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd497ac: cmp             SP, x16
    //     0xd497b0: b.ls            #0xd4986c
    // 0xd497b4: LoadField: r0 = r1->field_f
    //     0xd497b4: ldur            w0, [x1, #0xf]
    // 0xd497b8: DecompressPointer r0
    //     0xd497b8: add             x0, x0, HEAP, lsl #32
    // 0xd497bc: mov             x1, x0
    // 0xd497c0: r0 = of()
    //     0xd497c0: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd497c4: mov             x3, x0
    // 0xd497c8: ldr             x1, [fp, #0x10]
    // 0xd497cc: stur            x3, [fp, #-8]
    // 0xd497d0: r0 = LoadClassIdInstr(r1)
    //     0xd497d0: ldur            x0, [x1, #-1]
    //     0xd497d4: ubfx            x0, x0, #0xc, #0x14
    // 0xd497d8: r2 = Instance_WidgetState
    //     0xd497d8: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xd497dc: ldr             x2, [x2, #0xa70]
    // 0xd497e0: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd497e0: mov             x17, #0x2929
    //     0xd497e4: movk            x17, #1, lsl #16
    //     0xd497e8: add             lr, x0, x17
    //     0xd497ec: ldr             lr, [x21, lr, lsl #3]
    //     0xd497f0: blr             lr
    // 0xd497f4: tbnz            w0, #4, #0xd49828
    // 0xd497f8: ldur            x0, [fp, #-8]
    // 0xd497fc: LoadField: r1 = r0->field_43
    //     0xd497fc: ldur            w1, [x0, #0x43]
    // 0xd49800: DecompressPointer r1
    //     0xd49800: add             x1, x1, HEAP, lsl #32
    // 0xd49804: stur            x1, [fp, #-0x10]
    // 0xd49808: r0 = TextStyle()
    //     0xd49808: bl              #0x8a68f4  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0xd4980c: r1 = true
    //     0xd4980c: add             x1, NULL, #0x20  ; true
    // 0xd49810: StoreField: r0->field_7 = r1
    //     0xd49810: stur            w1, [x0, #7]
    // 0xd49814: ldur            x1, [fp, #-0x10]
    // 0xd49818: StoreField: r0->field_b = r1
    //     0xd49818: stur            w1, [x0, #0xb]
    // 0xd4981c: LeaveFrame
    //     0xd4981c: mov             SP, fp
    //     0xd49820: ldp             fp, lr, [SP], #0x10
    // 0xd49824: ret
    //     0xd49824: ret             
    // 0xd49828: ldur            x0, [fp, #-8]
    // 0xd4982c: r1 = true
    //     0xd4982c: add             x1, NULL, #0x20  ; true
    // 0xd49830: LoadField: r2 = r0->field_87
    //     0xd49830: ldur            w2, [x0, #0x87]
    // 0xd49834: DecompressPointer r2
    //     0xd49834: add             x2, x2, HEAP, lsl #32
    // 0xd49838: LoadField: r0 = r2->field_23
    //     0xd49838: ldur            w0, [x2, #0x23]
    // 0xd4983c: DecompressPointer r0
    //     0xd4983c: add             x0, x0, HEAP, lsl #32
    // 0xd49840: LoadField: r2 = r0->field_b
    //     0xd49840: ldur            w2, [x0, #0xb]
    // 0xd49844: DecompressPointer r2
    //     0xd49844: add             x2, x2, HEAP, lsl #32
    // 0xd49848: stur            x2, [fp, #-8]
    // 0xd4984c: r0 = TextStyle()
    //     0xd4984c: bl              #0x8a68f4  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0xd49850: r1 = true
    //     0xd49850: add             x1, NULL, #0x20  ; true
    // 0xd49854: StoreField: r0->field_7 = r1
    //     0xd49854: stur            w1, [x0, #7]
    // 0xd49858: ldur            x1, [fp, #-8]
    // 0xd4985c: StoreField: r0->field_b = r1
    //     0xd4985c: stur            w1, [x0, #0xb]
    // 0xd49860: LeaveFrame
    //     0xd49860: mov             SP, fp
    //     0xd49864: ldp             fp, lr, [SP], #0x10
    // 0xd49868: ret
    //     0xd49868: ret             
    // 0xd4986c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd4986c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd49870: b               #0xd497b4
  }
  static _ _m3StateInputStyle(/* No info */) {
    // ** addr: 0xd49874, size: 0x60
    // 0xd49874: EnterFrame
    //     0xd49874: stp             fp, lr, [SP, #-0x10]!
    //     0xd49878: mov             fp, SP
    // 0xd4987c: AllocStack(0x10)
    //     0xd4987c: sub             SP, SP, #0x10
    // 0xd49880: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0xd49880: stur            x1, [fp, #-8]
    // 0xd49884: r1 = 1
    //     0xd49884: mov             x1, #1
    // 0xd49888: r0 = AllocateContext()
    //     0xd49888: bl              #0x13de838  ; AllocateContextStub
    // 0xd4988c: mov             x1, x0
    // 0xd49890: ldur            x0, [fp, #-8]
    // 0xd49894: stur            x1, [fp, #-0x10]
    // 0xd49898: StoreField: r1->field_f = r0
    //     0xd49898: stur            w0, [x1, #0xf]
    // 0xd4989c: r0 = _WidgetStateTextStyle()
    //     0xd4989c: bl              #0xd28900  ; Allocate_WidgetStateTextStyleStub -> _WidgetStateTextStyle (size=0x74)
    // 0xd498a0: ldur            x2, [fp, #-0x10]
    // 0xd498a4: r1 = Function '<anonymous closure>': static.
    //     0xd498a4: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f8c8] AnonymousClosure: static (0xd498d4), in [package:flutter/src/material/text_field.dart] ::_m3StateInputStyle (0xd49874)
    //     0xd498a8: ldr             x1, [x1, #0x8c8]
    // 0xd498ac: stur            x0, [fp, #-8]
    // 0xd498b0: r0 = AllocateClosure()
    //     0xd498b0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd498b4: mov             x1, x0
    // 0xd498b8: ldur            x0, [fp, #-8]
    // 0xd498bc: StoreField: r0->field_6f = r1
    //     0xd498bc: stur            w1, [x0, #0x6f]
    // 0xd498c0: r1 = true
    //     0xd498c0: add             x1, NULL, #0x20  ; true
    // 0xd498c4: StoreField: r0->field_7 = r1
    //     0xd498c4: stur            w1, [x0, #7]
    // 0xd498c8: LeaveFrame
    //     0xd498c8: mov             SP, fp
    //     0xd498cc: ldp             fp, lr, [SP], #0x10
    // 0xd498d0: ret
    //     0xd498d0: ret             
  }
  [closure] static TextStyle <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xd498d4, size: 0x124
    // 0xd498d4: EnterFrame
    //     0xd498d4: stp             fp, lr, [SP, #-0x10]!
    //     0xd498d8: mov             fp, SP
    // 0xd498dc: AllocStack(0x10)
    //     0xd498dc: sub             SP, SP, #0x10
    // 0xd498e0: SetupParameters([dynamic _ /* r0 */])
    //     0xd498e0: ldr             x0, [fp, #0x18]
    //     0xd498e4: ldur            w3, [x0, #0x17]
    //     0xd498e8: add             x3, x3, HEAP, lsl #32
    //     0xd498ec: stur            x3, [fp, #-8]
    // 0xd498f0: CheckStackOverflow
    //     0xd498f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd498f4: cmp             SP, x16
    //     0xd498f8: b.ls            #0xd499f0
    // 0xd498fc: ldr             x1, [fp, #0x10]
    // 0xd49900: r0 = LoadClassIdInstr(r1)
    //     0xd49900: ldur            x0, [x1, #-1]
    //     0xd49904: ubfx            x0, x0, #0xc, #0x14
    // 0xd49908: r2 = Instance_WidgetState
    //     0xd49908: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xd4990c: ldr             x2, [x2, #0xa70]
    // 0xd49910: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd49910: mov             x17, #0x2929
    //     0xd49914: movk            x17, #1, lsl #16
    //     0xd49918: add             lr, x0, x17
    //     0xd4991c: ldr             lr, [x21, lr, lsl #3]
    //     0xd49920: blr             lr
    // 0xd49924: tbnz            w0, #4, #0xd499a0
    // 0xd49928: ldur            x0, [fp, #-8]
    // 0xd4992c: LoadField: r1 = r0->field_f
    //     0xd4992c: ldur            w1, [x0, #0xf]
    // 0xd49930: DecompressPointer r1
    //     0xd49930: add             x1, x1, HEAP, lsl #32
    // 0xd49934: r0 = of()
    //     0xd49934: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd49938: LoadField: r1 = r0->field_87
    //     0xd49938: ldur            w1, [x0, #0x87]
    // 0xd4993c: DecompressPointer r1
    //     0xd4993c: add             x1, x1, HEAP, lsl #32
    // 0xd49940: LoadField: r0 = r1->field_2b
    //     0xd49940: ldur            w0, [x1, #0x2b]
    // 0xd49944: DecompressPointer r0
    //     0xd49944: add             x0, x0, HEAP, lsl #32
    // 0xd49948: LoadField: r1 = r0->field_b
    //     0xd49948: ldur            w1, [x0, #0xb]
    // 0xd4994c: DecompressPointer r1
    //     0xd4994c: add             x1, x1, HEAP, lsl #32
    // 0xd49950: cmp             w1, NULL
    // 0xd49954: b.ne            #0xd49960
    // 0xd49958: r0 = Null
    //     0xd49958: mov             x0, NULL
    // 0xd4995c: b               #0xd4997c
    // 0xd49960: r0 = LoadClassIdInstr(r1)
    //     0xd49960: ldur            x0, [x1, #-1]
    //     0xd49964: ubfx            x0, x0, #0xc, #0x14
    // 0xd49968: d0 = 0.380000
    //     0xd49968: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xd4996c: ldr             d0, [x17, #0x1f0]
    // 0xd49970: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd49970: sub             lr, x0, #1, lsl #12
    //     0xd49974: ldr             lr, [x21, lr, lsl #3]
    //     0xd49978: blr             lr
    // 0xd4997c: stur            x0, [fp, #-0x10]
    // 0xd49980: r0 = TextStyle()
    //     0xd49980: bl              #0x8a68f4  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0xd49984: r2 = true
    //     0xd49984: add             x2, NULL, #0x20  ; true
    // 0xd49988: StoreField: r0->field_7 = r2
    //     0xd49988: stur            w2, [x0, #7]
    // 0xd4998c: ldur            x1, [fp, #-0x10]
    // 0xd49990: StoreField: r0->field_b = r1
    //     0xd49990: stur            w1, [x0, #0xb]
    // 0xd49994: LeaveFrame
    //     0xd49994: mov             SP, fp
    //     0xd49998: ldp             fp, lr, [SP], #0x10
    // 0xd4999c: ret
    //     0xd4999c: ret             
    // 0xd499a0: ldur            x0, [fp, #-8]
    // 0xd499a4: r2 = true
    //     0xd499a4: add             x2, NULL, #0x20  ; true
    // 0xd499a8: LoadField: r1 = r0->field_f
    //     0xd499a8: ldur            w1, [x0, #0xf]
    // 0xd499ac: DecompressPointer r1
    //     0xd499ac: add             x1, x1, HEAP, lsl #32
    // 0xd499b0: r0 = of()
    //     0xd499b0: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd499b4: LoadField: r1 = r0->field_87
    //     0xd499b4: ldur            w1, [x0, #0x87]
    // 0xd499b8: DecompressPointer r1
    //     0xd499b8: add             x1, x1, HEAP, lsl #32
    // 0xd499bc: LoadField: r0 = r1->field_2b
    //     0xd499bc: ldur            w0, [x1, #0x2b]
    // 0xd499c0: DecompressPointer r0
    //     0xd499c0: add             x0, x0, HEAP, lsl #32
    // 0xd499c4: LoadField: r1 = r0->field_b
    //     0xd499c4: ldur            w1, [x0, #0xb]
    // 0xd499c8: DecompressPointer r1
    //     0xd499c8: add             x1, x1, HEAP, lsl #32
    // 0xd499cc: stur            x1, [fp, #-8]
    // 0xd499d0: r0 = TextStyle()
    //     0xd499d0: bl              #0x8a68f4  ; AllocateTextStyleStub -> TextStyle (size=0x70)
    // 0xd499d4: r1 = true
    //     0xd499d4: add             x1, NULL, #0x20  ; true
    // 0xd499d8: StoreField: r0->field_7 = r1
    //     0xd499d8: stur            w1, [x0, #7]
    // 0xd499dc: ldur            x1, [fp, #-8]
    // 0xd499e0: StoreField: r0->field_b = r1
    //     0xd499e0: stur            w1, [x0, #0xb]
    // 0xd499e4: LeaveFrame
    //     0xd499e4: mov             SP, fp
    //     0xd499e8: ldp             fp, lr, [SP], #0x10
    // 0xd499ec: ret
    //     0xd499ec: ret             
    // 0xd499f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd499f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd499f4: b               #0xd498fc
  }
  static _ _m3InputStyle(/* No info */) {
    // ** addr: 0xd499f8, size: 0x3c
    // 0xd499f8: EnterFrame
    //     0xd499f8: stp             fp, lr, [SP, #-0x10]!
    //     0xd499fc: mov             fp, SP
    // 0xd49a00: CheckStackOverflow
    //     0xd49a00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd49a04: cmp             SP, x16
    //     0xd49a08: b.ls            #0xd49a2c
    // 0xd49a0c: r0 = of()
    //     0xd49a0c: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd49a10: LoadField: r1 = r0->field_87
    //     0xd49a10: ldur            w1, [x0, #0x87]
    // 0xd49a14: DecompressPointer r1
    //     0xd49a14: add             x1, x1, HEAP, lsl #32
    // 0xd49a18: LoadField: r0 = r1->field_2b
    //     0xd49a18: ldur            w0, [x1, #0x2b]
    // 0xd49a1c: DecompressPointer r0
    //     0xd49a1c: add             x0, x0, HEAP, lsl #32
    // 0xd49a20: LeaveFrame
    //     0xd49a20: mov             SP, fp
    //     0xd49a24: ldp             fp, lr, [SP], #0x10
    // 0xd49a28: ret
    //     0xd49a28: ret             
    // 0xd49a2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd49a2c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd49a30: b               #0xd49a0c
  }
}

// class id: 2987, size: 0x30, field offset: 0x2c
class _TextFieldSelectionGestureDetectorBuilder extends TextSelectionGestureDetectorBuilder {

  [closure] void onUserTap(dynamic) {
    // ** addr: 0xd47780, size: 0x38
    // 0xd47780: EnterFrame
    //     0xd47780: stp             fp, lr, [SP, #-0x10]!
    //     0xd47784: mov             fp, SP
    // 0xd47788: ldr             x0, [fp, #0x10]
    // 0xd4778c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd4778c: ldur            w1, [x0, #0x17]
    // 0xd47790: DecompressPointer r1
    //     0xd47790: add             x1, x1, HEAP, lsl #32
    // 0xd47794: CheckStackOverflow
    //     0xd47794: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd47798: cmp             SP, x16
    //     0xd4779c: b.ls            #0xd477b0
    // 0xd477a0: r0 = onUserTap()
    //     0xd477a0: bl              #0xd477b8  ; [package:flutter/src/material/text_field.dart] _TextFieldSelectionGestureDetectorBuilder::onUserTap
    // 0xd477a4: LeaveFrame
    //     0xd477a4: mov             SP, fp
    //     0xd477a8: ldp             fp, lr, [SP], #0x10
    // 0xd477ac: ret
    //     0xd477ac: ret             
    // 0xd477b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd477b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd477b4: b               #0xd477a0
  }
  _ onUserTap(/* No info */) {
    // ** addr: 0xd477b8, size: 0x6c
    // 0xd477b8: EnterFrame
    //     0xd477b8: stp             fp, lr, [SP, #-0x10]!
    //     0xd477bc: mov             fp, SP
    // 0xd477c0: AllocStack(0x8)
    //     0xd477c0: sub             SP, SP, #8
    // 0xd477c4: CheckStackOverflow
    //     0xd477c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd477c8: cmp             SP, x16
    //     0xd477cc: b.ls            #0xd47818
    // 0xd477d0: LoadField: r0 = r1->field_2b
    //     0xd477d0: ldur            w0, [x1, #0x2b]
    // 0xd477d4: DecompressPointer r0
    //     0xd477d4: add             x0, x0, HEAP, lsl #32
    // 0xd477d8: LoadField: r1 = r0->field_b
    //     0xd477d8: ldur            w1, [x0, #0xb]
    // 0xd477dc: DecompressPointer r1
    //     0xd477dc: add             x1, x1, HEAP, lsl #32
    // 0xd477e0: cmp             w1, NULL
    // 0xd477e4: b.eq            #0xd47820
    // 0xd477e8: LoadField: r0 = r1->field_d7
    //     0xd477e8: ldur            w0, [x1, #0xd7]
    // 0xd477ec: DecompressPointer r0
    //     0xd477ec: add             x0, x0, HEAP, lsl #32
    // 0xd477f0: cmp             w0, NULL
    // 0xd477f4: b.eq            #0xd47808
    // 0xd477f8: str             x0, [SP]
    // 0xd477fc: ClosureCall
    //     0xd477fc: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xd47800: ldur            x2, [x0, #0x1f]
    //     0xd47804: blr             x2
    // 0xd47808: r0 = Null
    //     0xd47808: mov             x0, NULL
    // 0xd4780c: LeaveFrame
    //     0xd4780c: mov             SP, fp
    //     0xd47810: ldp             fp, lr, [SP], #0x10
    // 0xd47814: ret
    //     0xd47814: ret             
    // 0xd47818: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd47818: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd4781c: b               #0xd477d0
    // 0xd47820: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd47820: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 5695, size: 0x44, field offset: 0x24
class _TextFieldState extends _MixinApplication114&State&RestorationMixin
    implements TextSelectionGestureDetectorBuilderDelegate, AutofillClient {

  late _TextFieldSelectionGestureDetectorBuilder _selectionGestureDetectorBuilder; // offset: 0x34
  late bool forcePressEnabled; // offset: 0x38

  _ build(/* No info */) {
    // ** addr: 0xd455b4, size: 0x1214
    // 0xd455b4: EnterFrame
    //     0xd455b4: stp             fp, lr, [SP, #-0x10]!
    //     0xd455b8: mov             fp, SP
    // 0xd455bc: AllocStack(0x2b0)
    //     0xd455bc: sub             SP, SP, #0x2b0
    // 0xd455c0: SetupParameters(_TextFieldState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xd455c0: mov             x0, x1
    //     0xd455c4: stur            x1, [fp, #-8]
    //     0xd455c8: mov             x1, x2
    //     0xd455cc: stur            x2, [fp, #-0x10]
    // 0xd455d0: CheckStackOverflow
    //     0xd455d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd455d4: cmp             SP, x16
    //     0xd455d8: b.ls            #0xd46768
    // 0xd455dc: r1 = 6
    //     0xd455dc: mov             x1, #6
    // 0xd455e0: r0 = AllocateContext()
    //     0xd455e0: bl              #0x13de838  ; AllocateContextStub
    // 0xd455e4: mov             x2, x0
    // 0xd455e8: ldur            x0, [fp, #-8]
    // 0xd455ec: stur            x2, [fp, #-0x18]
    // 0xd455f0: StoreField: r2->field_f = r0
    //     0xd455f0: stur            w0, [x2, #0xf]
    // 0xd455f4: ldur            x1, [fp, #-0x10]
    // 0xd455f8: r0 = of()
    //     0xd455f8: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd455fc: ldur            x1, [fp, #-0x10]
    // 0xd45600: stur            x0, [fp, #-0x20]
    // 0xd45604: r0 = of()
    //     0xd45604: bl              #0xd2096c  ; [package:flutter/src/widgets/default_selection_style.dart] DefaultSelectionStyle::of
    // 0xd45608: ldur            x1, [fp, #-8]
    // 0xd4560c: stur            x0, [fp, #-0x28]
    // 0xd45610: LoadField: r2 = r1->field_b
    //     0xd45610: ldur            w2, [x1, #0xb]
    // 0xd45614: DecompressPointer r2
    //     0xd45614: add             x2, x2, HEAP, lsl #32
    // 0xd45618: cmp             w2, NULL
    // 0xd4561c: b.eq            #0xd46770
    // 0xd45620: LoadField: r3 = r2->field_2b
    //     0xd45620: ldur            w3, [x2, #0x2b]
    // 0xd45624: DecompressPointer r3
    //     0xd45624: add             x3, x3, HEAP, lsl #32
    // 0xd45628: LoadField: r2 = r1->field_3f
    //     0xd45628: ldur            w2, [x1, #0x3f]
    // 0xd4562c: DecompressPointer r2
    //     0xd4562c: add             x2, x2, HEAP, lsl #32
    // 0xd45630: cmp             w2, NULL
    // 0xd45634: b.eq            #0xd46774
    // 0xd45638: LoadField: r4 = r2->field_27
    //     0xd45638: ldur            w4, [x2, #0x27]
    // 0xd4563c: DecompressPointer r4
    //     0xd4563c: add             x4, x4, HEAP, lsl #32
    // 0xd45640: r16 = <TextStyle?>
    //     0xd45640: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a88] TypeArguments: <TextStyle?>
    //     0xd45644: ldr             x16, [x16, #0xa88]
    // 0xd45648: stp             x3, x16, [SP, #8]
    // 0xd4564c: str             x4, [SP]
    // 0xd45650: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xd45650: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xd45654: r0 = resolveAs()
    //     0xd45654: bl              #0x8de57c  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveAs
    // 0xd45658: mov             x2, x0
    // 0xd4565c: ldur            x0, [fp, #-0x20]
    // 0xd45660: stur            x2, [fp, #-0x30]
    // 0xd45664: LoadField: r1 = r0->field_2f
    //     0xd45664: ldur            w1, [x0, #0x2f]
    // 0xd45668: DecompressPointer r1
    //     0xd45668: add             x1, x1, HEAP, lsl #32
    // 0xd4566c: tbnz            w1, #4, #0xd45684
    // 0xd45670: ldur            x1, [fp, #-0x10]
    // 0xd45674: r0 = _m3InputStyle()
    //     0xd45674: bl              #0xd499f8  ; [package:flutter/src/material/text_field.dart] ::_m3InputStyle
    // 0xd45678: mov             x2, x0
    // 0xd4567c: ldur            x0, [fp, #-0x20]
    // 0xd45680: b               #0xd45694
    // 0xd45684: LoadField: r1 = r0->field_87
    //     0xd45684: ldur            w1, [x0, #0x87]
    // 0xd45688: DecompressPointer r1
    //     0xd45688: add             x1, x1, HEAP, lsl #32
    // 0xd4568c: LoadField: r2 = r1->field_23
    //     0xd4568c: ldur            w2, [x1, #0x23]
    // 0xd45690: DecompressPointer r2
    //     0xd45690: add             x2, x2, HEAP, lsl #32
    // 0xd45694: ldur            x3, [fp, #-8]
    // 0xd45698: ldur            x4, [fp, #-0x18]
    // 0xd4569c: mov             x1, x3
    // 0xd456a0: r0 = _getInputStyleForState()
    //     0xd456a0: bl              #0xd495e0  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_getInputStyleForState
    // 0xd456a4: mov             x1, x0
    // 0xd456a8: ldur            x2, [fp, #-0x30]
    // 0xd456ac: r0 = merge()
    //     0xd456ac: bl              #0x8a98e8  ; [package:flutter/src/painting/text_style.dart] TextStyle::merge
    // 0xd456b0: mov             x2, x0
    // 0xd456b4: ldur            x0, [fp, #-8]
    // 0xd456b8: stur            x2, [fp, #-0x40]
    // 0xd456bc: LoadField: r1 = r0->field_b
    //     0xd456bc: ldur            w1, [x0, #0xb]
    // 0xd456c0: DecompressPointer r1
    //     0xd456c0: add             x1, x1, HEAP, lsl #32
    // 0xd456c4: cmp             w1, NULL
    // 0xd456c8: b.eq            #0xd46778
    // 0xd456cc: ldur            x3, [fp, #-0x20]
    // 0xd456d0: LoadField: r4 = r3->field_3f
    //     0xd456d0: ldur            w4, [x3, #0x3f]
    // 0xd456d4: DecompressPointer r4
    //     0xd456d4: add             x4, x4, HEAP, lsl #32
    // 0xd456d8: stur            x4, [fp, #-0x38]
    // 0xd456dc: LoadField: r5 = r4->field_7
    //     0xd456dc: ldur            w5, [x4, #7]
    // 0xd456e0: DecompressPointer r5
    //     0xd456e0: add             x5, x5, HEAP, lsl #32
    // 0xd456e4: mov             x1, x0
    // 0xd456e8: stur            x5, [fp, #-0x30]
    // 0xd456ec: r0 = _effectiveController()
    //     0xd456ec: bl              #0xd49538  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_effectiveController
    // 0xd456f0: mov             x3, x0
    // 0xd456f4: ldur            x2, [fp, #-0x18]
    // 0xd456f8: stur            x3, [fp, #-0x48]
    // 0xd456fc: StoreField: r2->field_13 = r0
    //     0xd456fc: stur            w0, [x2, #0x13]
    //     0xd45700: ldurb           w16, [x2, #-1]
    //     0xd45704: ldurb           w17, [x0, #-1]
    //     0xd45708: and             x16, x17, x16, lsr #2
    //     0xd4570c: tst             x16, HEAP, lsr #32
    //     0xd45710: b.eq            #0xd45718
    //     0xd45714: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd45718: ldur            x1, [fp, #-8]
    // 0xd4571c: r0 = _effectiveFocusNode()
    //     0xd4571c: bl              #0xd49478  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_effectiveFocusNode
    // 0xd45720: mov             x4, x0
    // 0xd45724: ldur            x3, [fp, #-0x18]
    // 0xd45728: stur            x4, [fp, #-0x50]
    // 0xd4572c: ArrayStore: r3[0] = r0  ; List_4
    //     0xd4572c: stur            w0, [x3, #0x17]
    //     0xd45730: ldurb           w16, [x3, #-1]
    //     0xd45734: ldurb           w17, [x0, #-1]
    //     0xd45738: and             x16, x17, x16, lsr #2
    //     0xd4573c: tst             x16, HEAP, lsr #32
    //     0xd45740: b.eq            #0xd45748
    //     0xd45744: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xd45748: r1 = <TextInputFormatter>
    //     0xd45748: add             x1, PP, #0x7d, lsl #12  ; [pp+0x7d198] TypeArguments: <TextInputFormatter>
    //     0xd4574c: ldr             x1, [x1, #0x198]
    // 0xd45750: r2 = 0
    //     0xd45750: mov             x2, #0
    // 0xd45754: r0 = _GrowableList()
    //     0xd45754: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xd45758: mov             x3, x0
    // 0xd4575c: ldur            x0, [fp, #-8]
    // 0xd45760: stur            x3, [fp, #-0x58]
    // 0xd45764: LoadField: r1 = r0->field_b
    //     0xd45764: ldur            w1, [x0, #0xb]
    // 0xd45768: DecompressPointer r1
    //     0xd45768: add             x1, x1, HEAP, lsl #32
    // 0xd4576c: cmp             w1, NULL
    // 0xd45770: b.eq            #0xd4677c
    // 0xd45774: LoadField: r2 = r1->field_8f
    //     0xd45774: ldur            w2, [x1, #0x8f]
    // 0xd45778: DecompressPointer r2
    //     0xd45778: add             x2, x2, HEAP, lsl #32
    // 0xd4577c: cmp             w2, NULL
    // 0xd45780: b.eq            #0xd4578c
    // 0xd45784: mov             x1, x3
    // 0xd45788: r0 = addAll()
    //     0xd45788: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0xd4578c: ldur            x0, [fp, #-8]
    // 0xd45790: LoadField: r1 = r0->field_b
    //     0xd45790: ldur            w1, [x0, #0xb]
    // 0xd45794: DecompressPointer r1
    //     0xd45794: add             x1, x1, HEAP, lsl #32
    // 0xd45798: cmp             w1, NULL
    // 0xd4579c: b.eq            #0xd46780
    // 0xd457a0: LoadField: r2 = r1->field_77
    //     0xd457a0: ldur            w2, [x1, #0x77]
    // 0xd457a4: DecompressPointer r2
    //     0xd457a4: add             x2, x2, HEAP, lsl #32
    // 0xd457a8: stur            x2, [fp, #-0x60]
    // 0xd457ac: cmp             w2, NULL
    // 0xd457b0: b.eq            #0xd45868
    // 0xd457b4: ldur            x3, [fp, #-0x58]
    // 0xd457b8: LoadField: r1 = r0->field_f
    //     0xd457b8: ldur            w1, [x0, #0xf]
    // 0xd457bc: DecompressPointer r1
    //     0xd457bc: add             x1, x1, HEAP, lsl #32
    // 0xd457c0: cmp             w1, NULL
    // 0xd457c4: b.eq            #0xd46784
    // 0xd457c8: r0 = of()
    //     0xd457c8: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd457cc: r0 = LengthLimitingTextInputFormatter()
    //     0xd457cc: bl              #0xd4946c  ; AllocateLengthLimitingTextInputFormatterStub -> LengthLimitingTextInputFormatter (size=0x10)
    // 0xd457d0: mov             x2, x0
    // 0xd457d4: ldur            x0, [fp, #-0x60]
    // 0xd457d8: stur            x2, [fp, #-0x70]
    // 0xd457dc: StoreField: r2->field_7 = r0
    //     0xd457dc: stur            w0, [x2, #7]
    // 0xd457e0: r0 = Instance_MaxLengthEnforcement
    //     0xd457e0: add             x0, PP, #0x8f, lsl #12  ; [pp+0x8f608] Obj!MaxLengthEnforcement@12c3a21
    //     0xd457e4: ldr             x0, [x0, #0x608]
    // 0xd457e8: StoreField: r2->field_b = r0
    //     0xd457e8: stur            w0, [x2, #0xb]
    // 0xd457ec: ldur            x0, [fp, #-0x58]
    // 0xd457f0: LoadField: r1 = r0->field_b
    //     0xd457f0: ldur            w1, [x0, #0xb]
    // 0xd457f4: LoadField: r3 = r0->field_f
    //     0xd457f4: ldur            w3, [x0, #0xf]
    // 0xd457f8: DecompressPointer r3
    //     0xd457f8: add             x3, x3, HEAP, lsl #32
    // 0xd457fc: LoadField: r4 = r3->field_b
    //     0xd457fc: ldur            w4, [x3, #0xb]
    // 0xd45800: r3 = LoadInt32Instr(r1)
    //     0xd45800: sbfx            x3, x1, #1, #0x1f
    // 0xd45804: stur            x3, [fp, #-0x68]
    // 0xd45808: r1 = LoadInt32Instr(r4)
    //     0xd45808: sbfx            x1, x4, #1, #0x1f
    // 0xd4580c: cmp             x3, x1
    // 0xd45810: b.ne            #0xd4581c
    // 0xd45814: mov             x1, x0
    // 0xd45818: r0 = _growToNextCapacity()
    //     0xd45818: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xd4581c: ldur            x2, [fp, #-0x58]
    // 0xd45820: ldur            x3, [fp, #-0x68]
    // 0xd45824: add             x0, x3, #1
    // 0xd45828: lsl             x1, x0, #1
    // 0xd4582c: StoreField: r2->field_b = r1
    //     0xd4582c: stur            w1, [x2, #0xb]
    // 0xd45830: LoadField: r1 = r2->field_f
    //     0xd45830: ldur            w1, [x2, #0xf]
    // 0xd45834: DecompressPointer r1
    //     0xd45834: add             x1, x1, HEAP, lsl #32
    // 0xd45838: ldur            x0, [fp, #-0x70]
    // 0xd4583c: ArrayStore: r1[r3] = r0  ; List_4
    //     0xd4583c: add             x25, x1, x3, lsl #2
    //     0xd45840: add             x25, x25, #0xf
    //     0xd45844: str             w0, [x25]
    //     0xd45848: tbz             w0, #0, #0xd45864
    //     0xd4584c: ldurb           w16, [x1, #-1]
    //     0xd45850: ldurb           w17, [x0, #-1]
    //     0xd45854: and             x16, x17, x16, lsr #2
    //     0xd45858: tst             x16, HEAP, lsr #32
    //     0xd4585c: b.eq            #0xd45864
    //     0xd45860: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd45864: b               #0xd4586c
    // 0xd45868: ldur            x2, [fp, #-0x58]
    // 0xd4586c: ldur            x1, [fp, #-8]
    // 0xd45870: ldur            x0, [fp, #-0x18]
    // 0xd45874: ldur            x3, [fp, #-0x20]
    // 0xd45878: LoadField: r4 = r1->field_b
    //     0xd45878: ldur            w4, [x1, #0xb]
    // 0xd4587c: DecompressPointer r4
    //     0xd4587c: add             x4, x4, HEAP, lsl #32
    // 0xd45880: cmp             w4, NULL
    // 0xd45884: b.eq            #0xd46788
    // 0xd45888: StoreField: r0->field_1b = rNULL
    //     0xd45888: stur            NULL, [x0, #0x1b]
    // 0xd4588c: StoreField: r0->field_1f = rNULL
    //     0xd4588c: stur            NULL, [x0, #0x1f]
    // 0xd45890: LoadField: r4 = r3->field_23
    //     0xd45890: ldur            w4, [x3, #0x23]
    // 0xd45894: DecompressPointer r4
    //     0xd45894: add             x4, x4, HEAP, lsl #32
    // 0xd45898: LoadField: r3 = r4->field_7
    //     0xd45898: ldur            x3, [x4, #7]
    // 0xd4589c: cmp             x3, #2
    // 0xd458a0: b.gt            #0xd45b94
    // 0xd458a4: cmp             x3, #1
    // 0xd458a8: b.gt            #0xd459b4
    // 0xd458ac: r3 = false
    //     0xd458ac: add             x3, NULL, #0x30  ; false
    // 0xd458b0: StoreField: r1->field_37 = r3
    //     0xd458b0: stur            w3, [x1, #0x37]
    // 0xd458b4: r0 = LoadStaticField(0x7b8)
    //     0xd458b4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xd458b8: ldr             x0, [x0, #0xf70]
    // 0xd458bc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd458c0: cmp             w0, w16
    // 0xd458c4: b.ne            #0xd458d4
    // 0xd458c8: r2 = materialTextSelectionHandleControls
    //     0xd458c8: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8f610] Field <::.materialTextSelectionHandleControls>: static late final (offset: 0x7b8)
    //     0xd458cc: ldr             x2, [x2, #0x610]
    // 0xd458d0: r0 = InitLateFinalStaticField()
    //     0xd458d0: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xd458d4: ldur            x1, [fp, #-8]
    // 0xd458d8: stur            x0, [fp, #-0x20]
    // 0xd458dc: r0 = _hasError()
    //     0xd458dc: bl              #0xd493fc  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_hasError
    // 0xd458e0: tbnz            w0, #4, #0xd45900
    // 0xd458e4: ldur            x1, [fp, #-8]
    // 0xd458e8: r0 = _errorColor()
    //     0xd458e8: bl              #0xd48cc8  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_errorColor
    // 0xd458ec: mov             x4, x0
    // 0xd458f0: ldur            x0, [fp, #-8]
    // 0xd458f4: ldur            x3, [fp, #-0x28]
    // 0xd458f8: ldur            x2, [fp, #-0x38]
    // 0xd458fc: b               #0xd4595c
    // 0xd45900: ldur            x0, [fp, #-8]
    // 0xd45904: LoadField: r1 = r0->field_b
    //     0xd45904: ldur            w1, [x0, #0xb]
    // 0xd45908: DecompressPointer r1
    //     0xd45908: add             x1, x1, HEAP, lsl #32
    // 0xd4590c: cmp             w1, NULL
    // 0xd45910: b.eq            #0xd4678c
    // 0xd45914: LoadField: r2 = r1->field_af
    //     0xd45914: ldur            w2, [x1, #0xaf]
    // 0xd45918: DecompressPointer r2
    //     0xd45918: add             x2, x2, HEAP, lsl #32
    // 0xd4591c: cmp             w2, NULL
    // 0xd45920: b.ne            #0xd45934
    // 0xd45924: ldur            x3, [fp, #-0x28]
    // 0xd45928: LoadField: r1 = r3->field_f
    //     0xd45928: ldur            w1, [x3, #0xf]
    // 0xd4592c: DecompressPointer r1
    //     0xd4592c: add             x1, x1, HEAP, lsl #32
    // 0xd45930: b               #0xd4593c
    // 0xd45934: ldur            x3, [fp, #-0x28]
    // 0xd45938: mov             x1, x2
    // 0xd4593c: cmp             w1, NULL
    // 0xd45940: b.ne            #0xd45954
    // 0xd45944: ldur            x2, [fp, #-0x38]
    // 0xd45948: LoadField: r1 = r2->field_b
    //     0xd45948: ldur            w1, [x2, #0xb]
    // 0xd4594c: DecompressPointer r1
    //     0xd4594c: add             x1, x1, HEAP, lsl #32
    // 0xd45950: b               #0xd45958
    // 0xd45954: ldur            x2, [fp, #-0x38]
    // 0xd45958: mov             x4, x1
    // 0xd4595c: stur            x4, [fp, #-0x60]
    // 0xd45960: LoadField: r1 = r3->field_13
    //     0xd45960: ldur            w1, [x3, #0x13]
    // 0xd45964: DecompressPointer r1
    //     0xd45964: add             x1, x1, HEAP, lsl #32
    // 0xd45968: cmp             w1, NULL
    // 0xd4596c: b.ne            #0xd45988
    // 0xd45970: LoadField: r1 = r2->field_b
    //     0xd45970: ldur            w1, [x2, #0xb]
    // 0xd45974: DecompressPointer r1
    //     0xd45974: add             x1, x1, HEAP, lsl #32
    // 0xd45978: d0 = 0.400000
    //     0xd45978: add             x17, PP, #0x13, lsl #12  ; [pp+0x13368] IMM: double(0.4) from 0x3fd999999999999a
    //     0xd4597c: ldr             d0, [x17, #0x368]
    // 0xd45980: r0 = withOpacity()
    //     0xd45980: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xd45984: b               #0xd4598c
    // 0xd45988: mov             x0, x1
    // 0xd4598c: ldur            x10, [fp, #-0x20]
    // 0xd45990: ldur            x7, [fp, #-0x60]
    // 0xd45994: mov             x5, x0
    // 0xd45998: ldur            x2, [fp, #-0x18]
    // 0xd4599c: r9 = false
    //     0xd4599c: add             x9, NULL, #0x30  ; false
    // 0xd459a0: r8 = false
    //     0xd459a0: add             x8, NULL, #0x30  ; false
    // 0xd459a4: r6 = Null
    //     0xd459a4: mov             x6, NULL
    // 0xd459a8: r4 = Null
    //     0xd459a8: mov             x4, NULL
    // 0xd459ac: r3 = Null
    //     0xd459ac: mov             x3, NULL
    // 0xd459b0: b               #0xd460dc
    // 0xd459b4: mov             x0, x1
    // 0xd459b8: ldur            x3, [fp, #-0x28]
    // 0xd459bc: ldur            x1, [fp, #-0x10]
    // 0xd459c0: r0 = of()
    //     0xd459c0: bl              #0xccc364  ; [package:flutter/src/cupertino/theme.dart] CupertinoTheme::of
    // 0xd459c4: mov             x2, x0
    // 0xd459c8: ldur            x1, [fp, #-8]
    // 0xd459cc: r0 = true
    //     0xd459cc: add             x0, NULL, #0x20  ; true
    // 0xd459d0: stur            x2, [fp, #-0x20]
    // 0xd459d4: StoreField: r1->field_37 = r0
    //     0xd459d4: stur            w0, [x1, #0x37]
    // 0xd459d8: r0 = LoadStaticField(0x9bc)
    //     0xd459d8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xd459dc: ldr             x0, [x0, #0x1378]
    // 0xd459e0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd459e4: cmp             w0, w16
    // 0xd459e8: b.ne            #0xd459f8
    // 0xd459ec: r2 = cupertinoTextSelectionHandleControls
    //     0xd459ec: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8f618] Field <::.cupertinoTextSelectionHandleControls>: static late final (offset: 0x9bc)
    //     0xd459f0: ldr             x2, [x2, #0x618]
    // 0xd459f4: r0 = InitLateFinalStaticField()
    //     0xd459f4: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xd459f8: ldur            x1, [fp, #-8]
    // 0xd459fc: stur            x0, [fp, #-0x60]
    // 0xd45a00: r0 = _hasError()
    //     0xd45a00: bl              #0xd493fc  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_hasError
    // 0xd45a04: tbnz            w0, #4, #0xd45a24
    // 0xd45a08: ldur            x1, [fp, #-8]
    // 0xd45a0c: r0 = _errorColor()
    //     0xd45a0c: bl              #0xd48cc8  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_errorColor
    // 0xd45a10: mov             x4, x0
    // 0xd45a14: ldur            x2, [fp, #-8]
    // 0xd45a18: ldur            x0, [fp, #-0x28]
    // 0xd45a1c: ldur            x3, [fp, #-0x20]
    // 0xd45a20: b               #0xd45ab8
    // 0xd45a24: ldur            x2, [fp, #-8]
    // 0xd45a28: LoadField: r0 = r2->field_b
    //     0xd45a28: ldur            w0, [x2, #0xb]
    // 0xd45a2c: DecompressPointer r0
    //     0xd45a2c: add             x0, x0, HEAP, lsl #32
    // 0xd45a30: cmp             w0, NULL
    // 0xd45a34: b.eq            #0xd46790
    // 0xd45a38: LoadField: r1 = r0->field_af
    //     0xd45a38: ldur            w1, [x0, #0xaf]
    // 0xd45a3c: DecompressPointer r1
    //     0xd45a3c: add             x1, x1, HEAP, lsl #32
    // 0xd45a40: cmp             w1, NULL
    // 0xd45a44: b.ne            #0xd45a58
    // 0xd45a48: ldur            x0, [fp, #-0x28]
    // 0xd45a4c: LoadField: r1 = r0->field_f
    //     0xd45a4c: ldur            w1, [x0, #0xf]
    // 0xd45a50: DecompressPointer r1
    //     0xd45a50: add             x1, x1, HEAP, lsl #32
    // 0xd45a54: b               #0xd45a5c
    // 0xd45a58: ldur            x0, [fp, #-0x28]
    // 0xd45a5c: cmp             w1, NULL
    // 0xd45a60: b.ne            #0xd45ab0
    // 0xd45a64: ldur            x3, [fp, #-0x20]
    // 0xd45a68: r1 = LoadClassIdInstr(r3)
    //     0xd45a68: ldur            x1, [x3, #-1]
    //     0xd45a6c: ubfx            x1, x1, #0xc, #0x14
    // 0xd45a70: r17 = 4617
    //     0xd45a70: mov             x17, #0x1209
    // 0xd45a74: cmp             x1, x17
    // 0xd45a78: b.ne            #0xd45a94
    // 0xd45a7c: LoadField: r1 = r3->field_27
    //     0xd45a7c: ldur            w1, [x3, #0x27]
    // 0xd45a80: DecompressPointer r1
    //     0xd45a80: add             x1, x1, HEAP, lsl #32
    // 0xd45a84: LoadField: r4 = r1->field_b
    //     0xd45a84: ldur            w4, [x1, #0xb]
    // 0xd45a88: DecompressPointer r4
    //     0xd45a88: add             x4, x4, HEAP, lsl #32
    // 0xd45a8c: mov             x1, x4
    // 0xd45a90: b               #0xd45ab4
    // 0xd45a94: LoadField: r1 = r3->field_2b
    //     0xd45a94: ldur            w1, [x3, #0x2b]
    // 0xd45a98: DecompressPointer r1
    //     0xd45a98: add             x1, x1, HEAP, lsl #32
    // 0xd45a9c: LoadField: r4 = r1->field_3f
    //     0xd45a9c: ldur            w4, [x1, #0x3f]
    // 0xd45aa0: DecompressPointer r4
    //     0xd45aa0: add             x4, x4, HEAP, lsl #32
    // 0xd45aa4: LoadField: r1 = r4->field_b
    //     0xd45aa4: ldur            w1, [x4, #0xb]
    // 0xd45aa8: DecompressPointer r1
    //     0xd45aa8: add             x1, x1, HEAP, lsl #32
    // 0xd45aac: b               #0xd45ab4
    // 0xd45ab0: ldur            x3, [fp, #-0x20]
    // 0xd45ab4: mov             x4, x1
    // 0xd45ab8: stur            x4, [fp, #-0x70]
    // 0xd45abc: LoadField: r1 = r0->field_13
    //     0xd45abc: ldur            w1, [x0, #0x13]
    // 0xd45ac0: DecompressPointer r1
    //     0xd45ac0: add             x1, x1, HEAP, lsl #32
    // 0xd45ac4: cmp             w1, NULL
    // 0xd45ac8: b.ne            #0xd45b30
    // 0xd45acc: r0 = LoadClassIdInstr(r3)
    //     0xd45acc: ldur            x0, [x3, #-1]
    //     0xd45ad0: ubfx            x0, x0, #0xc, #0x14
    // 0xd45ad4: r17 = 4617
    //     0xd45ad4: mov             x17, #0x1209
    // 0xd45ad8: cmp             x0, x17
    // 0xd45adc: b.ne            #0xd45af4
    // 0xd45ae0: LoadField: r0 = r3->field_27
    //     0xd45ae0: ldur            w0, [x3, #0x27]
    // 0xd45ae4: DecompressPointer r0
    //     0xd45ae4: add             x0, x0, HEAP, lsl #32
    // 0xd45ae8: LoadField: r1 = r0->field_b
    //     0xd45ae8: ldur            w1, [x0, #0xb]
    // 0xd45aec: DecompressPointer r1
    //     0xd45aec: add             x1, x1, HEAP, lsl #32
    // 0xd45af0: b               #0xd45b10
    // 0xd45af4: LoadField: r0 = r3->field_2b
    //     0xd45af4: ldur            w0, [x3, #0x2b]
    // 0xd45af8: DecompressPointer r0
    //     0xd45af8: add             x0, x0, HEAP, lsl #32
    // 0xd45afc: LoadField: r1 = r0->field_3f
    //     0xd45afc: ldur            w1, [x0, #0x3f]
    // 0xd45b00: DecompressPointer r1
    //     0xd45b00: add             x1, x1, HEAP, lsl #32
    // 0xd45b04: LoadField: r0 = r1->field_b
    //     0xd45b04: ldur            w0, [x1, #0xb]
    // 0xd45b08: DecompressPointer r0
    //     0xd45b08: add             x0, x0, HEAP, lsl #32
    // 0xd45b0c: mov             x1, x0
    // 0xd45b10: r0 = LoadClassIdInstr(r1)
    //     0xd45b10: ldur            x0, [x1, #-1]
    //     0xd45b14: ubfx            x0, x0, #0xc, #0x14
    // 0xd45b18: d0 = 0.400000
    //     0xd45b18: add             x17, PP, #0x13, lsl #12  ; [pp+0x13368] IMM: double(0.4) from 0x3fd999999999999a
    //     0xd45b1c: ldr             d0, [x17, #0x368]
    // 0xd45b20: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd45b20: sub             lr, x0, #1, lsl #12
    //     0xd45b24: ldr             lr, [x21, lr, lsl #3]
    //     0xd45b28: blr             lr
    // 0xd45b2c: b               #0xd45b34
    // 0xd45b30: mov             x0, x1
    // 0xd45b34: ldur            x1, [fp, #-0x10]
    // 0xd45b38: stur            x0, [fp, #-0x20]
    // 0xd45b3c: r0 = devicePixelRatioOf()
    //     0xd45b3c: bl              #0xcfce5c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::devicePixelRatioOf
    // 0xd45b40: mov             v1.16b, v0.16b
    // 0xd45b44: d0 = -2.000000
    //     0xd45b44: fmov            d0, #-2.00000000
    // 0xd45b48: fdiv            d2, d0, d1
    // 0xd45b4c: r17 = -360
    //     0xd45b4c: mov             x17, #-0x168
    // 0xd45b50: str             d2, [fp, x17]
    // 0xd45b54: r0 = Offset()
    //     0xd45b54: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xd45b58: r17 = -360
    //     0xd45b58: mov             x17, #-0x168
    // 0xd45b5c: ldr             d0, [fp, x17]
    // 0xd45b60: StoreField: r0->field_7 = d0
    //     0xd45b60: stur            d0, [x0, #7]
    // 0xd45b64: StoreField: r0->field_f = rZR
    //     0xd45b64: stur            xzr, [x0, #0xf]
    // 0xd45b68: ldur            x10, [fp, #-0x60]
    // 0xd45b6c: mov             x6, x0
    // 0xd45b70: ldur            x7, [fp, #-0x70]
    // 0xd45b74: ldur            x5, [fp, #-0x20]
    // 0xd45b78: ldur            x4, [fp, #-0x20]
    // 0xd45b7c: ldur            x2, [fp, #-0x18]
    // 0xd45b80: r9 = true
    //     0xd45b80: add             x9, NULL, #0x20  ; true
    // 0xd45b84: r8 = true
    //     0xd45b84: add             x8, NULL, #0x20  ; true
    // 0xd45b88: r3 = Instance_Radius
    //     0xd45b88: add             x3, PP, #0x8f, lsl #12  ; [pp+0x8f620] Obj!Radius@12a7241
    //     0xd45b8c: ldr             x3, [x3, #0x620]
    // 0xd45b90: b               #0xd460dc
    // 0xd45b94: ldur            x0, [fp, #-0x28]
    // 0xd45b98: ldur            x2, [fp, #-0x38]
    // 0xd45b9c: d0 = -2.000000
    //     0xd45b9c: fmov            d0, #-2.00000000
    // 0xd45ba0: cmp             x3, #4
    // 0xd45ba4: b.gt            #0xd45f70
    // 0xd45ba8: cmp             x3, #3
    // 0xd45bac: b.gt            #0xd45d24
    // 0xd45bb0: ldur            x1, [fp, #-8]
    // 0xd45bb4: r3 = false
    //     0xd45bb4: add             x3, NULL, #0x30  ; false
    // 0xd45bb8: StoreField: r1->field_37 = r3
    //     0xd45bb8: stur            w3, [x1, #0x37]
    // 0xd45bbc: r0 = LoadStaticField(0x668)
    //     0xd45bbc: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xd45bc0: ldr             x0, [x0, #0xcd0]
    // 0xd45bc4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd45bc8: cmp             w0, w16
    // 0xd45bcc: b.ne            #0xd45bdc
    // 0xd45bd0: r2 = desktopTextSelectionHandleControls
    //     0xd45bd0: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8f628] Field <::.desktopTextSelectionHandleControls>: static late final (offset: 0x668)
    //     0xd45bd4: ldr             x2, [x2, #0x628]
    // 0xd45bd8: r0 = InitLateFinalStaticField()
    //     0xd45bd8: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xd45bdc: ldur            x1, [fp, #-8]
    // 0xd45be0: stur            x0, [fp, #-0x20]
    // 0xd45be4: r0 = _hasError()
    //     0xd45be4: bl              #0xd493fc  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_hasError
    // 0xd45be8: tbnz            w0, #4, #0xd45c08
    // 0xd45bec: ldur            x1, [fp, #-8]
    // 0xd45bf0: r0 = _errorColor()
    //     0xd45bf0: bl              #0xd48cc8  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_errorColor
    // 0xd45bf4: mov             x4, x0
    // 0xd45bf8: ldur            x0, [fp, #-8]
    // 0xd45bfc: ldur            x3, [fp, #-0x28]
    // 0xd45c00: ldur            x2, [fp, #-0x38]
    // 0xd45c04: b               #0xd45c64
    // 0xd45c08: ldur            x0, [fp, #-8]
    // 0xd45c0c: LoadField: r1 = r0->field_b
    //     0xd45c0c: ldur            w1, [x0, #0xb]
    // 0xd45c10: DecompressPointer r1
    //     0xd45c10: add             x1, x1, HEAP, lsl #32
    // 0xd45c14: cmp             w1, NULL
    // 0xd45c18: b.eq            #0xd46794
    // 0xd45c1c: LoadField: r2 = r1->field_af
    //     0xd45c1c: ldur            w2, [x1, #0xaf]
    // 0xd45c20: DecompressPointer r2
    //     0xd45c20: add             x2, x2, HEAP, lsl #32
    // 0xd45c24: cmp             w2, NULL
    // 0xd45c28: b.ne            #0xd45c3c
    // 0xd45c2c: ldur            x3, [fp, #-0x28]
    // 0xd45c30: LoadField: r1 = r3->field_f
    //     0xd45c30: ldur            w1, [x3, #0xf]
    // 0xd45c34: DecompressPointer r1
    //     0xd45c34: add             x1, x1, HEAP, lsl #32
    // 0xd45c38: b               #0xd45c44
    // 0xd45c3c: ldur            x3, [fp, #-0x28]
    // 0xd45c40: mov             x1, x2
    // 0xd45c44: cmp             w1, NULL
    // 0xd45c48: b.ne            #0xd45c5c
    // 0xd45c4c: ldur            x2, [fp, #-0x38]
    // 0xd45c50: LoadField: r1 = r2->field_b
    //     0xd45c50: ldur            w1, [x2, #0xb]
    // 0xd45c54: DecompressPointer r1
    //     0xd45c54: add             x1, x1, HEAP, lsl #32
    // 0xd45c58: b               #0xd45c60
    // 0xd45c5c: ldur            x2, [fp, #-0x38]
    // 0xd45c60: mov             x4, x1
    // 0xd45c64: stur            x4, [fp, #-0x60]
    // 0xd45c68: LoadField: r1 = r3->field_13
    //     0xd45c68: ldur            w1, [x3, #0x13]
    // 0xd45c6c: DecompressPointer r1
    //     0xd45c6c: add             x1, x1, HEAP, lsl #32
    // 0xd45c70: cmp             w1, NULL
    // 0xd45c74: b.ne            #0xd45c94
    // 0xd45c78: LoadField: r1 = r2->field_b
    //     0xd45c78: ldur            w1, [x2, #0xb]
    // 0xd45c7c: DecompressPointer r1
    //     0xd45c7c: add             x1, x1, HEAP, lsl #32
    // 0xd45c80: d0 = 0.400000
    //     0xd45c80: add             x17, PP, #0x13, lsl #12  ; [pp+0x13368] IMM: double(0.4) from 0x3fd999999999999a
    //     0xd45c84: ldr             d0, [x17, #0x368]
    // 0xd45c88: r0 = withOpacity()
    //     0xd45c88: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xd45c8c: mov             x3, x0
    // 0xd45c90: b               #0xd45c98
    // 0xd45c94: mov             x3, x1
    // 0xd45c98: ldur            x0, [fp, #-0x18]
    // 0xd45c9c: mov             x2, x0
    // 0xd45ca0: stur            x3, [fp, #-0x70]
    // 0xd45ca4: r1 = Function '<anonymous closure>':.
    //     0xd45ca4: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f630] AnonymousClosure: (0xd4a644), in [package:flutter/src/material/text_field.dart] _TextFieldState::build (0xd455b4)
    //     0xd45ca8: ldr             x1, [x1, #0x630]
    // 0xd45cac: r0 = AllocateClosure()
    //     0xd45cac: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd45cb0: ldur            x3, [fp, #-0x18]
    // 0xd45cb4: StoreField: r3->field_1b = r0
    //     0xd45cb4: stur            w0, [x3, #0x1b]
    //     0xd45cb8: ldurb           w16, [x3, #-1]
    //     0xd45cbc: ldurb           w17, [x0, #-1]
    //     0xd45cc0: and             x16, x17, x16, lsr #2
    //     0xd45cc4: tst             x16, HEAP, lsr #32
    //     0xd45cc8: b.eq            #0xd45cd0
    //     0xd45ccc: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xd45cd0: mov             x2, x3
    // 0xd45cd4: r1 = Function '<anonymous closure>':.
    //     0xd45cd4: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f638] AnonymousClosure: (0xd4a5f0), in [package:flutter/src/material/text_field.dart] _TextFieldState::build (0xd455b4)
    //     0xd45cd8: ldr             x1, [x1, #0x638]
    // 0xd45cdc: r0 = AllocateClosure()
    //     0xd45cdc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd45ce0: ldur            x2, [fp, #-0x18]
    // 0xd45ce4: StoreField: r2->field_1f = r0
    //     0xd45ce4: stur            w0, [x2, #0x1f]
    //     0xd45ce8: ldurb           w16, [x2, #-1]
    //     0xd45cec: ldurb           w17, [x0, #-1]
    //     0xd45cf0: and             x16, x17, x16, lsr #2
    //     0xd45cf4: tst             x16, HEAP, lsr #32
    //     0xd45cf8: b.eq            #0xd45d00
    //     0xd45cfc: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd45d00: ldur            x10, [fp, #-0x20]
    // 0xd45d04: ldur            x7, [fp, #-0x60]
    // 0xd45d08: ldur            x5, [fp, #-0x70]
    // 0xd45d0c: r9 = false
    //     0xd45d0c: add             x9, NULL, #0x30  ; false
    // 0xd45d10: r8 = false
    //     0xd45d10: add             x8, NULL, #0x30  ; false
    // 0xd45d14: r6 = Null
    //     0xd45d14: mov             x6, NULL
    // 0xd45d18: r4 = Null
    //     0xd45d18: mov             x4, NULL
    // 0xd45d1c: r3 = Null
    //     0xd45d1c: mov             x3, NULL
    // 0xd45d20: b               #0xd460dc
    // 0xd45d24: mov             x3, x0
    // 0xd45d28: ldur            x0, [fp, #-8]
    // 0xd45d2c: ldur            x2, [fp, #-0x18]
    // 0xd45d30: ldur            x1, [fp, #-0x10]
    // 0xd45d34: r0 = of()
    //     0xd45d34: bl              #0xccc364  ; [package:flutter/src/cupertino/theme.dart] CupertinoTheme::of
    // 0xd45d38: mov             x2, x0
    // 0xd45d3c: ldur            x1, [fp, #-8]
    // 0xd45d40: r0 = false
    //     0xd45d40: add             x0, NULL, #0x30  ; false
    // 0xd45d44: stur            x2, [fp, #-0x20]
    // 0xd45d48: StoreField: r1->field_37 = r0
    //     0xd45d48: stur            w0, [x1, #0x37]
    // 0xd45d4c: r0 = LoadStaticField(0x9b8)
    //     0xd45d4c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xd45d50: ldr             x0, [x0, #0x1370]
    // 0xd45d54: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd45d58: cmp             w0, w16
    // 0xd45d5c: b.ne            #0xd45d6c
    // 0xd45d60: r2 = cupertinoDesktopTextSelectionHandleControls
    //     0xd45d60: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8f640] Field <::.cupertinoDesktopTextSelectionHandleControls>: static late final (offset: 0x9b8)
    //     0xd45d64: ldr             x2, [x2, #0x640]
    // 0xd45d68: r0 = InitLateFinalStaticField()
    //     0xd45d68: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xd45d6c: ldur            x1, [fp, #-8]
    // 0xd45d70: stur            x0, [fp, #-0x60]
    // 0xd45d74: r0 = _hasError()
    //     0xd45d74: bl              #0xd493fc  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_hasError
    // 0xd45d78: tbnz            w0, #4, #0xd45d98
    // 0xd45d7c: ldur            x1, [fp, #-8]
    // 0xd45d80: r0 = _errorColor()
    //     0xd45d80: bl              #0xd48cc8  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_errorColor
    // 0xd45d84: mov             x4, x0
    // 0xd45d88: ldur            x2, [fp, #-8]
    // 0xd45d8c: ldur            x0, [fp, #-0x28]
    // 0xd45d90: ldur            x3, [fp, #-0x20]
    // 0xd45d94: b               #0xd45e2c
    // 0xd45d98: ldur            x2, [fp, #-8]
    // 0xd45d9c: LoadField: r0 = r2->field_b
    //     0xd45d9c: ldur            w0, [x2, #0xb]
    // 0xd45da0: DecompressPointer r0
    //     0xd45da0: add             x0, x0, HEAP, lsl #32
    // 0xd45da4: cmp             w0, NULL
    // 0xd45da8: b.eq            #0xd46798
    // 0xd45dac: LoadField: r1 = r0->field_af
    //     0xd45dac: ldur            w1, [x0, #0xaf]
    // 0xd45db0: DecompressPointer r1
    //     0xd45db0: add             x1, x1, HEAP, lsl #32
    // 0xd45db4: cmp             w1, NULL
    // 0xd45db8: b.ne            #0xd45dcc
    // 0xd45dbc: ldur            x0, [fp, #-0x28]
    // 0xd45dc0: LoadField: r1 = r0->field_f
    //     0xd45dc0: ldur            w1, [x0, #0xf]
    // 0xd45dc4: DecompressPointer r1
    //     0xd45dc4: add             x1, x1, HEAP, lsl #32
    // 0xd45dc8: b               #0xd45dd0
    // 0xd45dcc: ldur            x0, [fp, #-0x28]
    // 0xd45dd0: cmp             w1, NULL
    // 0xd45dd4: b.ne            #0xd45e24
    // 0xd45dd8: ldur            x3, [fp, #-0x20]
    // 0xd45ddc: r1 = LoadClassIdInstr(r3)
    //     0xd45ddc: ldur            x1, [x3, #-1]
    //     0xd45de0: ubfx            x1, x1, #0xc, #0x14
    // 0xd45de4: r17 = 4617
    //     0xd45de4: mov             x17, #0x1209
    // 0xd45de8: cmp             x1, x17
    // 0xd45dec: b.ne            #0xd45e08
    // 0xd45df0: LoadField: r1 = r3->field_27
    //     0xd45df0: ldur            w1, [x3, #0x27]
    // 0xd45df4: DecompressPointer r1
    //     0xd45df4: add             x1, x1, HEAP, lsl #32
    // 0xd45df8: LoadField: r4 = r1->field_b
    //     0xd45df8: ldur            w4, [x1, #0xb]
    // 0xd45dfc: DecompressPointer r4
    //     0xd45dfc: add             x4, x4, HEAP, lsl #32
    // 0xd45e00: mov             x1, x4
    // 0xd45e04: b               #0xd45e28
    // 0xd45e08: LoadField: r1 = r3->field_2b
    //     0xd45e08: ldur            w1, [x3, #0x2b]
    // 0xd45e0c: DecompressPointer r1
    //     0xd45e0c: add             x1, x1, HEAP, lsl #32
    // 0xd45e10: LoadField: r4 = r1->field_3f
    //     0xd45e10: ldur            w4, [x1, #0x3f]
    // 0xd45e14: DecompressPointer r4
    //     0xd45e14: add             x4, x4, HEAP, lsl #32
    // 0xd45e18: LoadField: r1 = r4->field_b
    //     0xd45e18: ldur            w1, [x4, #0xb]
    // 0xd45e1c: DecompressPointer r1
    //     0xd45e1c: add             x1, x1, HEAP, lsl #32
    // 0xd45e20: b               #0xd45e28
    // 0xd45e24: ldur            x3, [fp, #-0x20]
    // 0xd45e28: mov             x4, x1
    // 0xd45e2c: stur            x4, [fp, #-0x70]
    // 0xd45e30: LoadField: r1 = r0->field_13
    //     0xd45e30: ldur            w1, [x0, #0x13]
    // 0xd45e34: DecompressPointer r1
    //     0xd45e34: add             x1, x1, HEAP, lsl #32
    // 0xd45e38: cmp             w1, NULL
    // 0xd45e3c: b.ne            #0xd45ea4
    // 0xd45e40: r0 = LoadClassIdInstr(r3)
    //     0xd45e40: ldur            x0, [x3, #-1]
    //     0xd45e44: ubfx            x0, x0, #0xc, #0x14
    // 0xd45e48: r17 = 4617
    //     0xd45e48: mov             x17, #0x1209
    // 0xd45e4c: cmp             x0, x17
    // 0xd45e50: b.ne            #0xd45e68
    // 0xd45e54: LoadField: r0 = r3->field_27
    //     0xd45e54: ldur            w0, [x3, #0x27]
    // 0xd45e58: DecompressPointer r0
    //     0xd45e58: add             x0, x0, HEAP, lsl #32
    // 0xd45e5c: LoadField: r1 = r0->field_b
    //     0xd45e5c: ldur            w1, [x0, #0xb]
    // 0xd45e60: DecompressPointer r1
    //     0xd45e60: add             x1, x1, HEAP, lsl #32
    // 0xd45e64: b               #0xd45e84
    // 0xd45e68: LoadField: r0 = r3->field_2b
    //     0xd45e68: ldur            w0, [x3, #0x2b]
    // 0xd45e6c: DecompressPointer r0
    //     0xd45e6c: add             x0, x0, HEAP, lsl #32
    // 0xd45e70: LoadField: r1 = r0->field_3f
    //     0xd45e70: ldur            w1, [x0, #0x3f]
    // 0xd45e74: DecompressPointer r1
    //     0xd45e74: add             x1, x1, HEAP, lsl #32
    // 0xd45e78: LoadField: r0 = r1->field_b
    //     0xd45e78: ldur            w0, [x1, #0xb]
    // 0xd45e7c: DecompressPointer r0
    //     0xd45e7c: add             x0, x0, HEAP, lsl #32
    // 0xd45e80: mov             x1, x0
    // 0xd45e84: r0 = LoadClassIdInstr(r1)
    //     0xd45e84: ldur            x0, [x1, #-1]
    //     0xd45e88: ubfx            x0, x0, #0xc, #0x14
    // 0xd45e8c: d0 = 0.400000
    //     0xd45e8c: add             x17, PP, #0x13, lsl #12  ; [pp+0x13368] IMM: double(0.4) from 0x3fd999999999999a
    //     0xd45e90: ldr             d0, [x17, #0x368]
    // 0xd45e94: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd45e94: sub             lr, x0, #1, lsl #12
    //     0xd45e98: ldr             lr, [x21, lr, lsl #3]
    //     0xd45e9c: blr             lr
    // 0xd45ea0: b               #0xd45ea8
    // 0xd45ea4: mov             x0, x1
    // 0xd45ea8: ldur            x2, [fp, #-0x18]
    // 0xd45eac: ldur            x1, [fp, #-0x10]
    // 0xd45eb0: stur            x0, [fp, #-0x20]
    // 0xd45eb4: r0 = devicePixelRatioOf()
    //     0xd45eb4: bl              #0xcfce5c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::devicePixelRatioOf
    // 0xd45eb8: mov             v1.16b, v0.16b
    // 0xd45ebc: d0 = -2.000000
    //     0xd45ebc: fmov            d0, #-2.00000000
    // 0xd45ec0: fdiv            d2, d0, d1
    // 0xd45ec4: r17 = -360
    //     0xd45ec4: mov             x17, #-0x168
    // 0xd45ec8: str             d2, [fp, x17]
    // 0xd45ecc: r0 = Offset()
    //     0xd45ecc: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xd45ed0: r17 = -360
    //     0xd45ed0: mov             x17, #-0x168
    // 0xd45ed4: ldr             d0, [fp, x17]
    // 0xd45ed8: stur            x0, [fp, #-0x10]
    // 0xd45edc: StoreField: r0->field_7 = d0
    //     0xd45edc: stur            d0, [x0, #7]
    // 0xd45ee0: StoreField: r0->field_f = rZR
    //     0xd45ee0: stur            xzr, [x0, #0xf]
    // 0xd45ee4: ldur            x2, [fp, #-0x18]
    // 0xd45ee8: r1 = Function '<anonymous closure>':.
    //     0xd45ee8: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f648] AnonymousClosure: (0xd4a644), in [package:flutter/src/material/text_field.dart] _TextFieldState::build (0xd455b4)
    //     0xd45eec: ldr             x1, [x1, #0x648]
    // 0xd45ef0: r0 = AllocateClosure()
    //     0xd45ef0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd45ef4: ldur            x3, [fp, #-0x18]
    // 0xd45ef8: StoreField: r3->field_1b = r0
    //     0xd45ef8: stur            w0, [x3, #0x1b]
    //     0xd45efc: ldurb           w16, [x3, #-1]
    //     0xd45f00: ldurb           w17, [x0, #-1]
    //     0xd45f04: and             x16, x17, x16, lsr #2
    //     0xd45f08: tst             x16, HEAP, lsr #32
    //     0xd45f0c: b.eq            #0xd45f14
    //     0xd45f10: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xd45f14: mov             x2, x3
    // 0xd45f18: r1 = Function '<anonymous closure>':.
    //     0xd45f18: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f650] AnonymousClosure: (0xd4a5f0), in [package:flutter/src/material/text_field.dart] _TextFieldState::build (0xd455b4)
    //     0xd45f1c: ldr             x1, [x1, #0x650]
    // 0xd45f20: r0 = AllocateClosure()
    //     0xd45f20: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd45f24: ldur            x1, [fp, #-0x18]
    // 0xd45f28: StoreField: r1->field_1f = r0
    //     0xd45f28: stur            w0, [x1, #0x1f]
    //     0xd45f2c: ldurb           w16, [x1, #-1]
    //     0xd45f30: ldurb           w17, [x0, #-1]
    //     0xd45f34: and             x16, x17, x16, lsr #2
    //     0xd45f38: tst             x16, HEAP, lsr #32
    //     0xd45f3c: b.eq            #0xd45f44
    //     0xd45f40: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd45f44: ldur            x10, [fp, #-0x60]
    // 0xd45f48: ldur            x6, [fp, #-0x10]
    // 0xd45f4c: ldur            x7, [fp, #-0x70]
    // 0xd45f50: ldur            x5, [fp, #-0x20]
    // 0xd45f54: mov             x2, x1
    // 0xd45f58: r9 = true
    //     0xd45f58: add             x9, NULL, #0x20  ; true
    // 0xd45f5c: r8 = false
    //     0xd45f5c: add             x8, NULL, #0x30  ; false
    // 0xd45f60: r4 = Null
    //     0xd45f60: mov             x4, NULL
    // 0xd45f64: r3 = Instance_Radius
    //     0xd45f64: add             x3, PP, #0x8f, lsl #12  ; [pp+0x8f620] Obj!Radius@12a7241
    //     0xd45f68: ldr             x3, [x3, #0x620]
    // 0xd45f6c: b               #0xd460dc
    // 0xd45f70: ldur            x3, [fp, #-8]
    // 0xd45f74: ldur            x1, [fp, #-0x18]
    // 0xd45f78: r4 = false
    //     0xd45f78: add             x4, NULL, #0x30  ; false
    // 0xd45f7c: StoreField: r3->field_37 = r4
    //     0xd45f7c: stur            w4, [x3, #0x37]
    // 0xd45f80: r0 = LoadStaticField(0x668)
    //     0xd45f80: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xd45f84: ldr             x0, [x0, #0xcd0]
    // 0xd45f88: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd45f8c: cmp             w0, w16
    // 0xd45f90: b.ne            #0xd45fa0
    // 0xd45f94: r2 = desktopTextSelectionHandleControls
    //     0xd45f94: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8f628] Field <::.desktopTextSelectionHandleControls>: static late final (offset: 0x668)
    //     0xd45f98: ldr             x2, [x2, #0x628]
    // 0xd45f9c: r0 = InitLateFinalStaticField()
    //     0xd45f9c: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xd45fa0: ldur            x1, [fp, #-8]
    // 0xd45fa4: stur            x0, [fp, #-0x10]
    // 0xd45fa8: r0 = _hasError()
    //     0xd45fa8: bl              #0xd493fc  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_hasError
    // 0xd45fac: tbnz            w0, #4, #0xd45fcc
    // 0xd45fb0: ldur            x1, [fp, #-8]
    // 0xd45fb4: r0 = _errorColor()
    //     0xd45fb4: bl              #0xd48cc8  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_errorColor
    // 0xd45fb8: mov             x2, x0
    // 0xd45fbc: ldur            x0, [fp, #-8]
    // 0xd45fc0: ldur            x1, [fp, #-0x28]
    // 0xd45fc4: ldur            x3, [fp, #-0x38]
    // 0xd45fc8: b               #0xd46020
    // 0xd45fcc: ldur            x0, [fp, #-8]
    // 0xd45fd0: LoadField: r1 = r0->field_b
    //     0xd45fd0: ldur            w1, [x0, #0xb]
    // 0xd45fd4: DecompressPointer r1
    //     0xd45fd4: add             x1, x1, HEAP, lsl #32
    // 0xd45fd8: cmp             w1, NULL
    // 0xd45fdc: b.eq            #0xd4679c
    // 0xd45fe0: LoadField: r2 = r1->field_af
    //     0xd45fe0: ldur            w2, [x1, #0xaf]
    // 0xd45fe4: DecompressPointer r2
    //     0xd45fe4: add             x2, x2, HEAP, lsl #32
    // 0xd45fe8: cmp             w2, NULL
    // 0xd45fec: b.ne            #0xd46000
    // 0xd45ff0: ldur            x1, [fp, #-0x28]
    // 0xd45ff4: LoadField: r2 = r1->field_f
    //     0xd45ff4: ldur            w2, [x1, #0xf]
    // 0xd45ff8: DecompressPointer r2
    //     0xd45ff8: add             x2, x2, HEAP, lsl #32
    // 0xd45ffc: b               #0xd46004
    // 0xd46000: ldur            x1, [fp, #-0x28]
    // 0xd46004: cmp             w2, NULL
    // 0xd46008: b.ne            #0xd4601c
    // 0xd4600c: ldur            x3, [fp, #-0x38]
    // 0xd46010: LoadField: r2 = r3->field_b
    //     0xd46010: ldur            w2, [x3, #0xb]
    // 0xd46014: DecompressPointer r2
    //     0xd46014: add             x2, x2, HEAP, lsl #32
    // 0xd46018: b               #0xd46020
    // 0xd4601c: ldur            x3, [fp, #-0x38]
    // 0xd46020: stur            x2, [fp, #-0x20]
    // 0xd46024: LoadField: r4 = r1->field_13
    //     0xd46024: ldur            w4, [x1, #0x13]
    // 0xd46028: DecompressPointer r4
    //     0xd46028: add             x4, x4, HEAP, lsl #32
    // 0xd4602c: cmp             w4, NULL
    // 0xd46030: b.ne            #0xd46050
    // 0xd46034: LoadField: r1 = r3->field_b
    //     0xd46034: ldur            w1, [x3, #0xb]
    // 0xd46038: DecompressPointer r1
    //     0xd46038: add             x1, x1, HEAP, lsl #32
    // 0xd4603c: d0 = 0.400000
    //     0xd4603c: add             x17, PP, #0x13, lsl #12  ; [pp+0x13368] IMM: double(0.4) from 0x3fd999999999999a
    //     0xd46040: ldr             d0, [x17, #0x368]
    // 0xd46044: r0 = withOpacity()
    //     0xd46044: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xd46048: mov             x3, x0
    // 0xd4604c: b               #0xd46054
    // 0xd46050: mov             x3, x4
    // 0xd46054: ldur            x0, [fp, #-0x18]
    // 0xd46058: mov             x2, x0
    // 0xd4605c: stur            x3, [fp, #-0x28]
    // 0xd46060: r1 = Function '<anonymous closure>':.
    //     0xd46060: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f658] AnonymousClosure: (0xd4a644), in [package:flutter/src/material/text_field.dart] _TextFieldState::build (0xd455b4)
    //     0xd46064: ldr             x1, [x1, #0x658]
    // 0xd46068: r0 = AllocateClosure()
    //     0xd46068: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd4606c: ldur            x3, [fp, #-0x18]
    // 0xd46070: StoreField: r3->field_1b = r0
    //     0xd46070: stur            w0, [x3, #0x1b]
    //     0xd46074: ldurb           w16, [x3, #-1]
    //     0xd46078: ldurb           w17, [x0, #-1]
    //     0xd4607c: and             x16, x17, x16, lsr #2
    //     0xd46080: tst             x16, HEAP, lsr #32
    //     0xd46084: b.eq            #0xd4608c
    //     0xd46088: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xd4608c: mov             x2, x3
    // 0xd46090: r1 = Function '<anonymous closure>':.
    //     0xd46090: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f660] AnonymousClosure: (0xd4a5f0), in [package:flutter/src/material/text_field.dart] _TextFieldState::build (0xd455b4)
    //     0xd46094: ldr             x1, [x1, #0x660]
    // 0xd46098: r0 = AllocateClosure()
    //     0xd46098: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd4609c: ldur            x2, [fp, #-0x18]
    // 0xd460a0: StoreField: r2->field_1f = r0
    //     0xd460a0: stur            w0, [x2, #0x1f]
    //     0xd460a4: ldurb           w16, [x2, #-1]
    //     0xd460a8: ldurb           w17, [x0, #-1]
    //     0xd460ac: and             x16, x17, x16, lsr #2
    //     0xd460b0: tst             x16, HEAP, lsr #32
    //     0xd460b4: b.eq            #0xd460bc
    //     0xd460b8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd460bc: ldur            x10, [fp, #-0x10]
    // 0xd460c0: ldur            x7, [fp, #-0x20]
    // 0xd460c4: ldur            x5, [fp, #-0x28]
    // 0xd460c8: r9 = false
    //     0xd460c8: add             x9, NULL, #0x30  ; false
    // 0xd460cc: r8 = false
    //     0xd460cc: add             x8, NULL, #0x30  ; false
    // 0xd460d0: r6 = Null
    //     0xd460d0: mov             x6, NULL
    // 0xd460d4: r4 = Null
    //     0xd460d4: mov             x4, NULL
    // 0xd460d8: r3 = Null
    //     0xd460d8: mov             x3, NULL
    // 0xd460dc: ldur            x0, [fp, #-8]
    // 0xd460e0: stur            x10, [fp, #-0x20]
    // 0xd460e4: stur            x9, [fp, #-0x28]
    // 0xd460e8: stur            x8, [fp, #-0x38]
    // 0xd460ec: stur            x6, [fp, #-0x60]
    // 0xd460f0: stur            x7, [fp, #-0x70]
    // 0xd460f4: stur            x5, [fp, #-0x78]
    // 0xd460f8: stur            x4, [fp, #-0x80]
    // 0xd460fc: stur            x3, [fp, #-0x88]
    // 0xd46100: LoadField: r11 = r0->field_3b
    //     0xd46100: ldur            w11, [x0, #0x3b]
    // 0xd46104: DecompressPointer r11
    //     0xd46104: add             x11, x11, HEAP, lsl #32
    // 0xd46108: stur            x11, [fp, #-0x10]
    // 0xd4610c: LoadField: r1 = r0->field_b
    //     0xd4610c: ldur            w1, [x0, #0xb]
    // 0xd46110: DecompressPointer r1
    //     0xd46110: add             x1, x1, HEAP, lsl #32
    // 0xd46114: cmp             w1, NULL
    // 0xd46118: b.eq            #0xd467a0
    // 0xd4611c: LoadField: r12 = r1->field_6b
    //     0xd4611c: ldur            w12, [x1, #0x6b]
    // 0xd46120: DecompressPointer r12
    //     0xd46120: add             x12, x12, HEAP, lsl #32
    // 0xd46124: tbnz            w12, #4, #0xd46134
    // 0xd46128: mov             x2, x0
    // 0xd4612c: r0 = true
    //     0xd4612c: add             x0, NULL, #0x20  ; true
    // 0xd46130: b               #0xd46148
    // 0xd46134: mov             x1, x0
    // 0xd46138: r0 = _isEnabled()
    //     0xd46138: bl              #0xd48c7c  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_isEnabled
    // 0xd4613c: eor             x1, x0, #0x10
    // 0xd46140: mov             x0, x1
    // 0xd46144: ldur            x2, [fp, #-8]
    // 0xd46148: stur            x0, [fp, #-0xf0]
    // 0xd4614c: LoadField: r1 = r2->field_b
    //     0xd4614c: ldur            w1, [x2, #0xb]
    // 0xd46150: DecompressPointer r1
    //     0xd46150: add             x1, x1, HEAP, lsl #32
    // 0xd46154: cmp             w1, NULL
    // 0xd46158: b.eq            #0xd467a4
    // 0xd4615c: LoadField: r3 = r2->field_2f
    //     0xd4615c: ldur            w3, [x2, #0x2f]
    // 0xd46160: DecompressPointer r3
    //     0xd46160: add             x3, x3, HEAP, lsl #32
    // 0xd46164: stur            x3, [fp, #-0xe8]
    // 0xd46168: LoadField: r4 = r1->field_1f
    //     0xd46168: ldur            w4, [x1, #0x1f]
    // 0xd4616c: DecompressPointer r4
    //     0xd4616c: add             x4, x4, HEAP, lsl #32
    // 0xd46170: stur            x4, [fp, #-0xe0]
    // 0xd46174: LoadField: r5 = r1->field_23
    //     0xd46174: ldur            w5, [x1, #0x23]
    // 0xd46178: DecompressPointer r5
    //     0xd46178: add             x5, x5, HEAP, lsl #32
    // 0xd4617c: stur            x5, [fp, #-0xd8]
    // 0xd46180: LoadField: r6 = r1->field_33
    //     0xd46180: ldur            w6, [x1, #0x33]
    // 0xd46184: DecompressPointer r6
    //     0xd46184: add             x6, x6, HEAP, lsl #32
    // 0xd46188: stur            x6, [fp, #-0xd0]
    // 0xd4618c: LoadField: r7 = r1->field_3f
    //     0xd4618c: ldur            w7, [x1, #0x3f]
    // 0xd46190: DecompressPointer r7
    //     0xd46190: add             x7, x7, HEAP, lsl #32
    // 0xd46194: stur            x7, [fp, #-0xc8]
    // 0xd46198: LoadField: r8 = r1->field_47
    //     0xd46198: ldur            w8, [x1, #0x47]
    // 0xd4619c: DecompressPointer r8
    //     0xd4619c: add             x8, x8, HEAP, lsl #32
    // 0xd461a0: stur            x8, [fp, #-0xc0]
    // 0xd461a4: LoadField: r9 = r1->field_4b
    //     0xd461a4: ldur            w9, [x1, #0x4b]
    // 0xd461a8: DecompressPointer r9
    //     0xd461a8: add             x9, x9, HEAP, lsl #32
    // 0xd461ac: stur            x9, [fp, #-0xb8]
    // 0xd461b0: LoadField: r10 = r1->field_4f
    //     0xd461b0: ldur            w10, [x1, #0x4f]
    // 0xd461b4: DecompressPointer r10
    //     0xd461b4: add             x10, x10, HEAP, lsl #32
    // 0xd461b8: stur            x10, [fp, #-0xb0]
    // 0xd461bc: LoadField: r11 = r1->field_53
    //     0xd461bc: ldur            w11, [x1, #0x53]
    // 0xd461c0: DecompressPointer r11
    //     0xd461c0: add             x11, x11, HEAP, lsl #32
    // 0xd461c4: stur            x11, [fp, #-0xa8]
    // 0xd461c8: LoadField: r12 = r1->field_57
    //     0xd461c8: ldur            w12, [x1, #0x57]
    // 0xd461cc: DecompressPointer r12
    //     0xd461cc: add             x12, x12, HEAP, lsl #32
    // 0xd461d0: stur            x12, [fp, #-0xa0]
    // 0xd461d4: LoadField: r13 = r1->field_5f
    //     0xd461d4: ldur            w13, [x1, #0x5f]
    // 0xd461d8: DecompressPointer r13
    //     0xd461d8: add             x13, x13, HEAP, lsl #32
    // 0xd461dc: stur            x13, [fp, #-0x98]
    // 0xd461e0: LoadField: r14 = r1->field_67
    //     0xd461e0: ldur            w14, [x1, #0x67]
    // 0xd461e4: DecompressPointer r14
    //     0xd461e4: add             x14, x14, HEAP, lsl #32
    // 0xd461e8: ldur            x1, [fp, #-0x50]
    // 0xd461ec: stur            x14, [fp, #-0x90]
    // 0xd461f0: r0 = hasFocus()
    //     0xd461f0: bl              #0x843d08  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::hasFocus
    // 0xd461f4: tbnz            w0, #4, #0xd46200
    // 0xd461f8: ldur            x0, [fp, #-0x78]
    // 0xd461fc: b               #0xd46204
    // 0xd46200: r0 = Null
    //     0xd46200: mov             x0, NULL
    // 0xd46204: ldur            x2, [fp, #-8]
    // 0xd46208: r17 = -320
    //     0xd46208: mov             x17, #-0x140
    // 0xd4620c: str             x0, [fp, x17]
    // 0xd46210: LoadField: r1 = r2->field_b
    //     0xd46210: ldur            w1, [x2, #0xb]
    // 0xd46214: DecompressPointer r1
    //     0xd46214: add             x1, x1, HEAP, lsl #32
    // 0xd46218: cmp             w1, NULL
    // 0xd4621c: b.eq            #0xd467a8
    // 0xd46220: LoadField: r3 = r1->field_c7
    //     0xd46220: ldur            w3, [x1, #0xc7]
    // 0xd46224: DecompressPointer r3
    //     0xd46224: add             x3, x3, HEAP, lsl #32
    // 0xd46228: r17 = -312
    //     0xd46228: mov             x17, #-0x138
    // 0xd4622c: str             x3, [fp, x17]
    // 0xd46230: tbnz            w3, #4, #0xd4623c
    // 0xd46234: ldur            x7, [fp, #-0x20]
    // 0xd46238: b               #0xd46240
    // 0xd4623c: r7 = Null
    //     0xd4623c: mov             x7, NULL
    // 0xd46240: ldur            x4, [fp, #-0x18]
    // 0xd46244: ldur            x6, [fp, #-0x48]
    // 0xd46248: ldur            x5, [fp, #-0x50]
    // 0xd4624c: r17 = -304
    //     0xd4624c: mov             x17, #-0x130
    // 0xd46250: str             x7, [fp, x17]
    // 0xd46254: LoadField: r8 = r1->field_7f
    //     0xd46254: ldur            w8, [x1, #0x7f]
    // 0xd46258: DecompressPointer r8
    //     0xd46258: add             x8, x8, HEAP, lsl #32
    // 0xd4625c: r17 = -296
    //     0xd4625c: mov             x17, #-0x128
    // 0xd46260: str             x8, [fp, x17]
    // 0xd46264: LoadField: r9 = r1->field_83
    //     0xd46264: ldur            w9, [x1, #0x83]
    // 0xd46268: DecompressPointer r9
    //     0xd46268: add             x9, x9, HEAP, lsl #32
    // 0xd4626c: r17 = -288
    //     0xd4626c: mov             x17, #-0x120
    // 0xd46270: str             x9, [fp, x17]
    // 0xd46274: LoadField: r10 = r1->field_87
    //     0xd46274: ldur            w10, [x1, #0x87]
    // 0xd46278: DecompressPointer r10
    //     0xd46278: add             x10, x10, HEAP, lsl #32
    // 0xd4627c: r17 = -280
    //     0xd4627c: mov             x17, #-0x118
    // 0xd46280: str             x10, [fp, x17]
    // 0xd46284: LoadField: r11 = r1->field_f
    //     0xd46284: ldur            w11, [x1, #0xf]
    // 0xd46288: DecompressPointer r11
    //     0xd46288: add             x11, x11, HEAP, lsl #32
    // 0xd4628c: r17 = -272
    //     0xd4628c: mov             x17, #-0x110
    // 0xd46290: str             x11, [fp, x17]
    // 0xd46294: LoadField: d0 = r1->field_9b
    //     0xd46294: ldur            d0, [x1, #0x9b]
    // 0xd46298: r17 = -360
    //     0xd46298: mov             x17, #-0x168
    // 0xd4629c: str             d0, [fp, x17]
    // 0xd462a0: LoadField: r12 = r1->field_b7
    //     0xd462a0: ldur            w12, [x1, #0xb7]
    // 0xd462a4: DecompressPointer r12
    //     0xd462a4: add             x12, x12, HEAP, lsl #32
    // 0xd462a8: r17 = -264
    //     0xd462a8: mov             x17, #-0x108
    // 0xd462ac: str             x12, [fp, x17]
    // 0xd462b0: LoadField: r13 = r1->field_bb
    //     0xd462b0: ldur            w13, [x1, #0xbb]
    // 0xd462b4: DecompressPointer r13
    //     0xd462b4: add             x13, x13, HEAP, lsl #32
    // 0xd462b8: stur            x13, [fp, #-0x100]
    // 0xd462bc: LoadField: r14 = r1->field_ef
    //     0xd462bc: ldur            w14, [x1, #0xef]
    // 0xd462c0: DecompressPointer r14
    //     0xd462c0: add             x14, x14, HEAP, lsl #32
    // 0xd462c4: stur            x14, [fp, #-0xf8]
    // 0xd462c8: LoadField: r19 = r1->field_f7
    //     0xd462c8: ldur            w19, [x1, #0xf7]
    // 0xd462cc: DecompressPointer r19
    //     0xd462cc: add             x19, x19, HEAP, lsl #32
    // 0xd462d0: stur            x19, [fp, #-0x78]
    // 0xd462d4: r17 = 279
    //     0xd462d4: mov             x17, #0x117
    // 0xd462d8: ldr             w20, [x1, x17]
    // 0xd462dc: DecompressPointer r20
    //     0xd462dc: add             x20, x20, HEAP, lsl #32
    // 0xd462e0: stur            x20, [fp, #-0x20]
    // 0xd462e4: r0 = LoadStaticField(0xcb4)
    //     0xd462e4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xd462e8: ldr             x0, [x0, #0x1968]
    // 0xd462ec: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd462f0: cmp             w0, w16
    // 0xd462f4: b.ne            #0xd46304
    // 0xd462f8: r2 = adaptiveMagnifierConfiguration
    //     0xd462f8: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8f668] Field <TextMagnifier.adaptiveMagnifierConfiguration>: static late (offset: 0xcb4)
    //     0xd462fc: ldr             x2, [x2, #0x668]
    // 0xd46300: r0 = InitLateStaticField()
    //     0xd46300: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0xd46304: mov             x3, x0
    // 0xd46308: ldur            x0, [fp, #-8]
    // 0xd4630c: r17 = -328
    //     0xd4630c: mov             x17, #-0x148
    // 0xd46310: str             x3, [fp, x17]
    // 0xd46314: LoadField: r1 = r0->field_b
    //     0xd46314: ldur            w1, [x0, #0xb]
    // 0xd46318: DecompressPointer r1
    //     0xd46318: add             x1, x1, HEAP, lsl #32
    // 0xd4631c: cmp             w1, NULL
    // 0xd46320: b.eq            #0xd467ac
    // 0xd46324: mov             x2, x0
    // 0xd46328: r1 = Function '_handleSelectionChanged@130181401':.
    //     0xd46328: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f670] AnonymousClosure: (0xd4a210), in [package:flutter/src/material/text_field.dart] _TextFieldState::_handleSelectionChanged (0xd4a250)
    //     0xd4632c: ldr             x1, [x1, #0x670]
    // 0xd46330: r0 = AllocateClosure()
    //     0xd46330: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd46334: ldur            x2, [fp, #-8]
    // 0xd46338: r1 = Function '_handleSelectionHandleTapped@130181401':.
    //     0xd46338: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f678] AnonymousClosure: (0xd4a154), in [package:flutter/src/material/text_field.dart] _TextFieldState::_handleSelectionHandleTapped (0xd4a18c)
    //     0xd4633c: ldr             x1, [x1, #0x678]
    // 0xd46340: r17 = -336
    //     0xd46340: mov             x17, #-0x150
    // 0xd46344: str             x0, [fp, x17]
    // 0xd46348: r0 = AllocateClosure()
    //     0xd46348: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd4634c: r17 = -344
    //     0xd4634c: mov             x17, #-0x158
    // 0xd46350: str             x0, [fp, x17]
    // 0xd46354: r0 = EditableText()
    //     0xd46354: bl              #0xd48c68  ; AllocateEditableTextStub -> EditableText (size=0x140)
    // 0xd46358: r17 = -352
    //     0xd46358: mov             x17, #-0x160
    // 0xd4635c: str             x0, [fp, x17]
    // 0xd46360: ldur            x16, [fp, #-0x60]
    // 0xd46364: ldur            lr, [fp, #-0x38]
    // 0xd46368: stp             lr, x16, [SP, #0x138]
    // 0xd4636c: ldur            x16, [fp, #-0x88]
    // 0xd46370: r17 = -312
    //     0xd46370: mov             x17, #-0x138
    // 0xd46374: ldr             lr, [fp, x17]
    // 0xd46378: stp             lr, x16, [SP, #0x128]
    // 0xd4637c: ldur            x16, [fp, #-0x50]
    // 0xd46380: ldur            lr, [fp, #-0x10]
    // 0xd46384: stp             lr, x16, [SP, #0x118]
    // 0xd46388: r17 = -328
    //     0xd46388: mov             x17, #-0x148
    // 0xd4638c: ldr             x16, [fp, x17]
    // 0xd46390: ldur            lr, [fp, #-0x98]
    // 0xd46394: stp             lr, x16, [SP, #0x108]
    // 0xd46398: r17 = -336
    //     0xd46398: mov             x17, #-0x150
    // 0xd4639c: ldr             x16, [fp, x17]
    // 0xd463a0: r17 = -344
    //     0xd463a0: mov             x17, #-0x158
    // 0xd463a4: ldr             lr, [fp, x17]
    // 0xd463a8: stp             lr, x16, [SP, #0xf8]
    // 0xd463ac: ldur            x16, [fp, #-0x28]
    // 0xd463b0: ldur            lr, [fp, #-0xf0]
    // 0xd463b4: stp             lr, x16, [SP, #0xe8]
    // 0xd463b8: ldur            x16, [fp, #-0xf8]
    // 0xd463bc: r17 = -320
    //     0xd463bc: mov             x17, #-0x140
    // 0xd463c0: ldr             lr, [fp, x17]
    // 0xd463c4: stp             lr, x16, [SP, #0xd8]
    // 0xd463c8: r17 = -304
    //     0xd463c8: mov             x17, #-0x130
    // 0xd463cc: ldr             x16, [fp, x17]
    // 0xd463d0: r17 = -264
    //     0xd463d0: mov             x17, #-0x108
    // 0xd463d4: ldr             lr, [fp, x17]
    // 0xd463d8: stp             lr, x16, [SP, #0xc8]
    // 0xd463dc: ldur            x16, [fp, #-0x100]
    // 0xd463e0: stp             NULL, x16, [SP, #0xb8]
    // 0xd463e4: ldur            x16, [fp, #-0xe8]
    // 0xd463e8: stp             NULL, x16, [SP, #0xa8]
    // 0xd463ec: ldur            x16, [fp, #-0x40]
    // 0xd463f0: ldur            lr, [fp, #-0xd0]
    // 0xd463f4: stp             lr, x16, [SP, #0x98]
    // 0xd463f8: ldur            x16, [fp, #-0xe0]
    // 0xd463fc: ldur            lr, [fp, #-0xd8]
    // 0xd46400: stp             lr, x16, [SP, #0x88]
    // 0xd46404: ldur            x16, [fp, #-0xc0]
    // 0xd46408: ldur            lr, [fp, #-0xb8]
    // 0xd4640c: stp             lr, x16, [SP, #0x78]
    // 0xd46410: ldur            x16, [fp, #-0xb0]
    // 0xd46414: ldur            lr, [fp, #-0xa8]
    // 0xd46418: stp             lr, x16, [SP, #0x68]
    // 0xd4641c: ldur            x16, [fp, #-0xa0]
    // 0xd46420: ldur            lr, [fp, #-0x90]
    // 0xd46424: stp             lr, x16, [SP, #0x58]
    // 0xd46428: r17 = -296
    //     0xd46428: mov             x17, #-0x128
    // 0xd4642c: ldr             x16, [fp, x17]
    // 0xd46430: r17 = -288
    //     0xd46430: mov             x17, #-0x120
    // 0xd46434: ldr             lr, [fp, x17]
    // 0xd46438: stp             lr, x16, [SP, #0x48]
    // 0xd4643c: r17 = -280
    //     0xd4643c: mov             x17, #-0x118
    // 0xd46440: ldr             x16, [fp, x17]
    // 0xd46444: r17 = -272
    //     0xd46444: mov             x17, #-0x110
    // 0xd46448: ldr             lr, [fp, x17]
    // 0xd4644c: stp             lr, x16, [SP, #0x38]
    // 0xd46450: ldur            x16, [fp, #-0x58]
    // 0xd46454: r30 = Instance__DeferringMouseCursor
    //     0xd46454: ldr             lr, [PP, #0x2208]  ; [pp+0x2208] Obj!_DeferringMouseCursor@12b3241
    // 0xd46458: stp             lr, x16, [SP, #0x28]
    // 0xd4645c: ldur            x16, [fp, #-0x30]
    // 0xd46460: ldur            lr, [fp, #-8]
    // 0xd46464: stp             lr, x16, [SP, #0x18]
    // 0xd46468: ldur            x16, [fp, #-0x80]
    // 0xd4646c: r30 = "editable"
    //     0xd4646c: add             lr, PP, #0x8f, lsl #12  ; [pp+0x8f680] "editable"
    //     0xd46470: ldr             lr, [lr, #0x680]
    // 0xd46474: stp             lr, x16, [SP, #8]
    // 0xd46478: r16 = Instance_SpellCheckConfiguration
    //     0xd46478: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8f688] Obj!SpellCheckConfiguration@128a151
    //     0xd4647c: ldr             x16, [x16, #0x688]
    // 0xd46480: str             x16, [SP]
    // 0xd46484: mov             x1, x0
    // 0xd46488: ldur            x2, [fp, #-0x78]
    // 0xd4648c: ldur            x3, [fp, #-0xc8]
    // 0xd46490: ldur            x5, [fp, #-0x20]
    // 0xd46494: ldur            x6, [fp, #-0x48]
    // 0xd46498: ldur            x7, [fp, #-0x70]
    // 0xd4649c: r17 = -360
    //     0xd4649c: mov             x17, #-0x168
    // 0xd464a0: ldr             d0, [fp, x17]
    // 0xd464a4: r4 = const [0, 0x30, 0x29, 0x1d, autocorrect, 0x21, autocorrectionTextRectColor, 0x2d, autofillClient, 0x2c, expands, 0x24, groupId, 0x28, inputFormatters, 0x29, keyboardAppearance, 0x2b, keyboardType, 0x1d, mouseCursor, 0x2a, obscureText, 0x20, obscuringCharacter, 0x1f, onChanged, 0x25, onEditingComplete, 0x26, onSubmitted, 0x27, restorationId, 0x2e, smartDashesType, 0x22, smartQuotesType, 0x23, spellCheckConfiguration, 0x2f, textInputAction, 0x1e, null]
    //     0xd464a4: add             x4, PP, #0x8f, lsl #12  ; [pp+0x8f690] List(43) [0, 0x30, 0x29, 0x1d, "autocorrect", 0x21, "autocorrectionTextRectColor", 0x2d, "autofillClient", 0x2c, "expands", 0x24, "groupId", 0x28, "inputFormatters", 0x29, "keyboardAppearance", 0x2b, "keyboardType", 0x1d, "mouseCursor", 0x2a, "obscureText", 0x20, "obscuringCharacter", 0x1f, "onChanged", 0x25, "onEditingComplete", 0x26, "onSubmitted", 0x27, "restorationId", 0x2e, "smartDashesType", 0x22, "smartQuotesType", 0x23, "spellCheckConfiguration", 0x2f, "textInputAction", 0x1e, Null]
    //     0xd464a8: ldr             x4, [x4, #0x690]
    // 0xd464ac: r0 = EditableText()
    //     0xd464ac: bl              #0xd47c38  ; [package:flutter/src/widgets/editable_text.dart] EditableText::EditableText
    // 0xd464b0: r0 = UnmanagedRestorationScope()
    //     0xd464b0: bl              #0xd47c2c  ; AllocateUnmanagedRestorationScopeStub -> UnmanagedRestorationScope (size=0x14)
    // 0xd464b4: mov             x1, x0
    // 0xd464b8: r17 = -352
    //     0xd464b8: mov             x17, #-0x160
    // 0xd464bc: ldr             x0, [fp, x17]
    // 0xd464c0: stur            x1, [fp, #-0x10]
    // 0xd464c4: StoreField: r1->field_b = r0
    //     0xd464c4: stur            w0, [x1, #0xb]
    // 0xd464c8: r0 = RepaintBoundary()
    //     0xd464c8: bl              #0xd1a860  ; AllocateRepaintBoundaryStub -> RepaintBoundary (size=0x10)
    // 0xd464cc: mov             x3, x0
    // 0xd464d0: ldur            x0, [fp, #-0x10]
    // 0xd464d4: stur            x3, [fp, #-0x20]
    // 0xd464d8: StoreField: r3->field_b = r0
    //     0xd464d8: stur            w0, [x3, #0xb]
    // 0xd464dc: ldur            x0, [fp, #-8]
    // 0xd464e0: LoadField: r1 = r0->field_b
    //     0xd464e0: ldur            w1, [x0, #0xb]
    // 0xd464e4: DecompressPointer r1
    //     0xd464e4: add             x1, x1, HEAP, lsl #32
    // 0xd464e8: cmp             w1, NULL
    // 0xd464ec: b.eq            #0xd467b0
    // 0xd464f0: r1 = Null
    //     0xd464f0: mov             x1, NULL
    // 0xd464f4: r2 = 4
    //     0xd464f4: mov             x2, #4
    // 0xd464f8: r0 = AllocateArray()
    //     0xd464f8: bl              #0x13df928  ; AllocateArrayStub
    // 0xd464fc: mov             x2, x0
    // 0xd46500: ldur            x0, [fp, #-0x50]
    // 0xd46504: stur            x2, [fp, #-0x10]
    // 0xd46508: StoreField: r2->field_f = r0
    //     0xd46508: stur            w0, [x2, #0xf]
    // 0xd4650c: ldur            x0, [fp, #-0x48]
    // 0xd46510: StoreField: r2->field_13 = r0
    //     0xd46510: stur            w0, [x2, #0x13]
    // 0xd46514: r1 = <Listenable>
    //     0xd46514: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f698] TypeArguments: <Listenable>
    //     0xd46518: ldr             x1, [x1, #0x698]
    // 0xd4651c: r0 = AllocateGrowableArray()
    //     0xd4651c: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xd46520: mov             x1, x0
    // 0xd46524: ldur            x0, [fp, #-0x10]
    // 0xd46528: stur            x1, [fp, #-0x28]
    // 0xd4652c: StoreField: r1->field_f = r0
    //     0xd4652c: stur            w0, [x1, #0xf]
    // 0xd46530: r0 = 4
    //     0xd46530: mov             x0, #4
    // 0xd46534: StoreField: r1->field_b = r0
    //     0xd46534: stur            w0, [x1, #0xb]
    // 0xd46538: r0 = _MergingListenable()
    //     0xd46538: bl              #0xd26450  ; Allocate_MergingListenableStub -> _MergingListenable (size=0xc)
    // 0xd4653c: mov             x3, x0
    // 0xd46540: ldur            x0, [fp, #-0x28]
    // 0xd46544: stur            x3, [fp, #-0x10]
    // 0xd46548: StoreField: r3->field_7 = r0
    //     0xd46548: stur            w0, [x3, #7]
    // 0xd4654c: ldur            x2, [fp, #-0x18]
    // 0xd46550: r1 = Function '<anonymous closure>':.
    //     0xd46550: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f6a0] AnonymousClosure: (0xd49ff8), in [package:flutter/src/material/text_field.dart] _TextFieldState::build (0xd455b4)
    //     0xd46554: ldr             x1, [x1, #0x6a0]
    // 0xd46558: r0 = AllocateClosure()
    //     0xd46558: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd4655c: stur            x0, [fp, #-0x28]
    // 0xd46560: r0 = AnimatedBuilder()
    //     0xd46560: bl              #0x918e2c  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0xd46564: mov             x2, x0
    // 0xd46568: ldur            x0, [fp, #-0x28]
    // 0xd4656c: stur            x2, [fp, #-0x30]
    // 0xd46570: StoreField: r2->field_f = r0
    //     0xd46570: stur            w0, [x2, #0xf]
    // 0xd46574: ldur            x0, [fp, #-0x20]
    // 0xd46578: StoreField: r2->field_13 = r0
    //     0xd46578: stur            w0, [x2, #0x13]
    // 0xd4657c: ldur            x0, [fp, #-0x10]
    // 0xd46580: StoreField: r2->field_b = r0
    //     0xd46580: stur            w0, [x2, #0xb]
    // 0xd46584: ldur            x1, [fp, #-8]
    // 0xd46588: r0 = _statesController()
    //     0xd46588: bl              #0xd47bf0  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_statesController
    // 0xd4658c: LoadField: r1 = r0->field_27
    //     0xd4658c: ldur            w1, [x0, #0x27]
    // 0xd46590: DecompressPointer r1
    //     0xd46590: add             x1, x1, HEAP, lsl #32
    // 0xd46594: r16 = <MouseCursor>
    //     0xd46594: ldr             x16, [PP, #0x21a8]  ; [pp+0x21a8] TypeArguments: <MouseCursor>
    // 0xd46598: r30 = Instance__WidgetStateMouseCursor
    //     0xd46598: add             lr, PP, #0x8f, lsl #12  ; [pp+0x8f6a8] Obj!_WidgetStateMouseCursor@12b3271
    //     0xd4659c: ldr             lr, [lr, #0x6a8]
    // 0xd465a0: stp             lr, x16, [SP, #8]
    // 0xd465a4: str             x1, [SP]
    // 0xd465a8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xd465a8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xd465ac: r0 = resolveAs()
    //     0xd465ac: bl              #0x8de57c  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveAs
    // 0xd465b0: ldur            x2, [fp, #-0x18]
    // 0xd465b4: stur            x0, [fp, #-0x10]
    // 0xd465b8: StoreField: r2->field_23 = rNULL
    //     0xd465b8: stur            NULL, [x2, #0x23]
    // 0xd465bc: ldur            x1, [fp, #-8]
    // 0xd465c0: r0 = _effectiveMaxLengthEnforcement()
    //     0xd465c0: bl              #0xd47b90  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_effectiveMaxLengthEnforcement
    // 0xd465c4: r16 = Instance_MaxLengthEnforcement
    //     0xd465c4: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8f6b0] Obj!MaxLengthEnforcement@12c3a01
    //     0xd465c8: ldr             x16, [x16, #0x6b0]
    // 0xd465cc: cmp             w0, w16
    // 0xd465d0: b.eq            #0xd46620
    // 0xd465d4: ldur            x0, [fp, #-8]
    // 0xd465d8: LoadField: r1 = r0->field_b
    //     0xd465d8: ldur            w1, [x0, #0xb]
    // 0xd465dc: DecompressPointer r1
    //     0xd465dc: add             x1, x1, HEAP, lsl #32
    // 0xd465e0: cmp             w1, NULL
    // 0xd465e4: b.eq            #0xd467b4
    // 0xd465e8: LoadField: r2 = r1->field_77
    //     0xd465e8: ldur            w2, [x1, #0x77]
    // 0xd465ec: DecompressPointer r2
    //     0xd465ec: add             x2, x2, HEAP, lsl #32
    // 0xd465f0: cmp             w2, NULL
    // 0xd465f4: b.eq            #0xd46618
    // 0xd465f8: r1 = LoadInt32Instr(r2)
    //     0xd465f8: sbfx            x1, x2, #1, #0x1f
    // 0xd465fc: cmp             x1, #0
    // 0xd46600: b.le            #0xd46610
    // 0xd46604: ldur            x3, [fp, #-0x18]
    // 0xd46608: StoreField: r3->field_23 = r2
    //     0xd46608: stur            w2, [x3, #0x23]
    // 0xd4660c: b               #0xd4662c
    // 0xd46610: ldur            x3, [fp, #-0x18]
    // 0xd46614: b               #0xd46628
    // 0xd46618: ldur            x3, [fp, #-0x18]
    // 0xd4661c: b               #0xd46628
    // 0xd46620: ldur            x0, [fp, #-8]
    // 0xd46624: ldur            x3, [fp, #-0x18]
    // 0xd46628: StoreField: r3->field_23 = rNULL
    //     0xd46628: stur            NULL, [x3, #0x23]
    // 0xd4662c: ldur            x4, [fp, #-0x48]
    // 0xd46630: ldur            x2, [fp, #-0x10]
    // 0xd46634: LoadField: r1 = r0->field_b
    //     0xd46634: ldur            w1, [x0, #0xb]
    // 0xd46638: DecompressPointer r1
    //     0xd46638: add             x1, x1, HEAP, lsl #32
    // 0xd4663c: cmp             w1, NULL
    // 0xd46640: b.eq            #0xd467b8
    // 0xd46644: mov             x1, x0
    // 0xd46648: r0 = _isEnabled()
    //     0xd46648: bl              #0xd48c7c  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_isEnabled
    // 0xd4664c: eor             x3, x0, #0x10
    // 0xd46650: ldur            x0, [fp, #-8]
    // 0xd46654: stur            x3, [fp, #-0x20]
    // 0xd46658: LoadField: r1 = r0->field_33
    //     0xd46658: ldur            w1, [x0, #0x33]
    // 0xd4665c: DecompressPointer r1
    //     0xd4665c: add             x1, x1, HEAP, lsl #32
    // 0xd46660: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd46664: cmp             w1, w16
    // 0xd46668: b.eq            #0xd467bc
    // 0xd4666c: ldur            x2, [fp, #-0x30]
    // 0xd46670: r0 = buildGestureDetector()
    //     0xd46670: bl              #0xd467ec  ; [package:flutter/src/widgets/text_selection.dart] TextSelectionGestureDetectorBuilder::buildGestureDetector
    // 0xd46674: ldur            x2, [fp, #-0x18]
    // 0xd46678: r1 = Function '<anonymous closure>':.
    //     0xd46678: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f6b8] AnonymousClosure: (0xd49bb4), in [package:flutter/src/material/text_field.dart] _TextFieldState::build (0xd455b4)
    //     0xd4667c: ldr             x1, [x1, #0x6b8]
    // 0xd46680: stur            x0, [fp, #-8]
    // 0xd46684: r0 = AllocateClosure()
    //     0xd46684: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd46688: stur            x0, [fp, #-0x28]
    // 0xd4668c: r0 = AnimatedBuilder()
    //     0xd4668c: bl              #0x918e2c  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0xd46690: mov             x1, x0
    // 0xd46694: ldur            x0, [fp, #-0x28]
    // 0xd46698: stur            x1, [fp, #-0x30]
    // 0xd4669c: StoreField: r1->field_f = r0
    //     0xd4669c: stur            w0, [x1, #0xf]
    // 0xd466a0: ldur            x0, [fp, #-8]
    // 0xd466a4: StoreField: r1->field_13 = r0
    //     0xd466a4: stur            w0, [x1, #0x13]
    // 0xd466a8: ldur            x0, [fp, #-0x48]
    // 0xd466ac: StoreField: r1->field_b = r0
    //     0xd466ac: stur            w0, [x1, #0xb]
    // 0xd466b0: r0 = IgnorePointer()
    //     0xd466b0: bl              #0xbadc08  ; AllocateIgnorePointerStub -> IgnorePointer (size=0x18)
    // 0xd466b4: mov             x1, x0
    // 0xd466b8: ldur            x0, [fp, #-0x20]
    // 0xd466bc: stur            x1, [fp, #-8]
    // 0xd466c0: StoreField: r1->field_f = r0
    //     0xd466c0: stur            w0, [x1, #0xf]
    // 0xd466c4: ldur            x0, [fp, #-0x30]
    // 0xd466c8: StoreField: r1->field_b = r0
    //     0xd466c8: stur            w0, [x1, #0xb]
    // 0xd466cc: r0 = TextFieldTapRegion()
    //     0xd466cc: bl              #0x86a6a0  ; AllocateTextFieldTapRegionStub -> TextFieldTapRegion (size=0x34)
    // 0xd466d0: mov             x3, x0
    // 0xd466d4: r0 = true
    //     0xd466d4: add             x0, NULL, #0x20  ; true
    // 0xd466d8: stur            x3, [fp, #-0x20]
    // 0xd466dc: StoreField: r3->field_f = r0
    //     0xd466dc: stur            w0, [x3, #0xf]
    // 0xd466e0: r1 = Instance_HitTestBehavior
    //     0xd466e0: ldr             x1, [PP, #0x5368]  ; [pp+0x5368] Obj!HitTestBehavior@12c43a1
    // 0xd466e4: StoreField: r3->field_13 = r1
    //     0xd466e4: stur            w1, [x3, #0x13]
    // 0xd466e8: r1 = EditableText
    //     0xd466e8: ldr             x1, [PP, #0x5370]  ; [pp+0x5370] Type: EditableText
    // 0xd466ec: StoreField: r3->field_27 = r1
    //     0xd466ec: stur            w1, [x3, #0x27]
    // 0xd466f0: r1 = false
    //     0xd466f0: add             x1, NULL, #0x30  ; false
    // 0xd466f4: StoreField: r3->field_2b = r1
    //     0xd466f4: stur            w1, [x3, #0x2b]
    // 0xd466f8: ldur            x1, [fp, #-8]
    // 0xd466fc: StoreField: r3->field_b = r1
    //     0xd466fc: stur            w1, [x3, #0xb]
    // 0xd46700: ldur            x2, [fp, #-0x18]
    // 0xd46704: r1 = Function '<anonymous closure>':.
    //     0xd46704: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f6c0] AnonymousClosure: (0xd49b68), in [package:flutter/src/material/text_field.dart] _TextFieldState::build (0xd455b4)
    //     0xd46708: ldr             x1, [x1, #0x6c0]
    // 0xd4670c: r0 = AllocateClosure()
    //     0xd4670c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd46710: stur            x0, [fp, #-8]
    // 0xd46714: r0 = MouseRegion()
    //     0xd46714: bl              #0xd1c8fc  ; AllocateMouseRegionStub -> MouseRegion (size=0x28)
    // 0xd46718: mov             x3, x0
    // 0xd4671c: ldur            x0, [fp, #-8]
    // 0xd46720: stur            x3, [fp, #-0x28]
    // 0xd46724: StoreField: r3->field_f = r0
    //     0xd46724: stur            w0, [x3, #0xf]
    // 0xd46728: ldur            x2, [fp, #-0x18]
    // 0xd4672c: r1 = Function '<anonymous closure>':.
    //     0xd4672c: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f6c8] AnonymousClosure: (0xd49a34), in [package:flutter/src/material/text_field.dart] _TextFieldState::build (0xd455b4)
    //     0xd46730: ldr             x1, [x1, #0x6c8]
    // 0xd46734: r0 = AllocateClosure()
    //     0xd46734: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd46738: mov             x1, x0
    // 0xd4673c: ldur            x0, [fp, #-0x28]
    // 0xd46740: ArrayStore: r0[0] = r1  ; List_4
    //     0xd46740: stur            w1, [x0, #0x17]
    // 0xd46744: ldur            x1, [fp, #-0x10]
    // 0xd46748: StoreField: r0->field_1b = r1
    //     0xd46748: stur            w1, [x0, #0x1b]
    // 0xd4674c: r1 = true
    //     0xd4674c: add             x1, NULL, #0x20  ; true
    // 0xd46750: StoreField: r0->field_1f = r1
    //     0xd46750: stur            w1, [x0, #0x1f]
    // 0xd46754: ldur            x1, [fp, #-0x20]
    // 0xd46758: StoreField: r0->field_b = r1
    //     0xd46758: stur            w1, [x0, #0xb]
    // 0xd4675c: LeaveFrame
    //     0xd4675c: mov             SP, fp
    //     0xd46760: ldp             fp, lr, [SP], #0x10
    // 0xd46764: ret
    //     0xd46764: ret             
    // 0xd46768: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd46768: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd4676c: b               #0xd455dc
    // 0xd46770: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd46770: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd46774: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd46774: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd46778: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd46778: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd4677c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd4677c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd46780: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd46780: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd46784: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd46784: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd46788: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd46788: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd4678c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd4678c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd46790: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd46790: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd46794: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd46794: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd46798: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd46798: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd4679c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd4679c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd467a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd467a0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd467a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd467a4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd467a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd467a8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd467ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd467ac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd467b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd467b0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd467b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd467b4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd467b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd467b8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd467bc: r9 = _selectionGestureDetectorBuilder
    //     0xd467bc: add             x9, PP, #0x8f, lsl #12  ; [pp+0x8f6d0] Field <_TextFieldState@130181401._selectionGestureDetectorBuilder@130181401>: late (offset: 0x34)
    //     0xd467c0: ldr             x9, [x9, #0x6d0]
    // 0xd467c4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd467c4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  get _ _effectiveMaxLengthEnforcement(/* No info */) {
    // ** addr: 0xd47b90, size: 0x60
    // 0xd47b90: EnterFrame
    //     0xd47b90: stp             fp, lr, [SP, #-0x10]!
    //     0xd47b94: mov             fp, SP
    // 0xd47b98: CheckStackOverflow
    //     0xd47b98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd47b9c: cmp             SP, x16
    //     0xd47ba0: b.ls            #0xd47be0
    // 0xd47ba4: LoadField: r0 = r1->field_b
    //     0xd47ba4: ldur            w0, [x1, #0xb]
    // 0xd47ba8: DecompressPointer r0
    //     0xd47ba8: add             x0, x0, HEAP, lsl #32
    // 0xd47bac: cmp             w0, NULL
    // 0xd47bb0: b.eq            #0xd47be8
    // 0xd47bb4: LoadField: r0 = r1->field_f
    //     0xd47bb4: ldur            w0, [x1, #0xf]
    // 0xd47bb8: DecompressPointer r0
    //     0xd47bb8: add             x0, x0, HEAP, lsl #32
    // 0xd47bbc: cmp             w0, NULL
    // 0xd47bc0: b.eq            #0xd47bec
    // 0xd47bc4: mov             x1, x0
    // 0xd47bc8: r0 = of()
    //     0xd47bc8: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd47bcc: r0 = Instance_MaxLengthEnforcement
    //     0xd47bcc: add             x0, PP, #0x8f, lsl #12  ; [pp+0x8f608] Obj!MaxLengthEnforcement@12c3a21
    //     0xd47bd0: ldr             x0, [x0, #0x608]
    // 0xd47bd4: LeaveFrame
    //     0xd47bd4: mov             SP, fp
    //     0xd47bd8: ldp             fp, lr, [SP], #0x10
    // 0xd47bdc: ret
    //     0xd47bdc: ret             
    // 0xd47be0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd47be0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd47be4: b               #0xd47ba4
    // 0xd47be8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd47be8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd47bec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd47bec: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _statesController(/* No info */) {
    // ** addr: 0xd47bf0, size: 0x3c
    // 0xd47bf0: EnterFrame
    //     0xd47bf0: stp             fp, lr, [SP, #-0x10]!
    //     0xd47bf4: mov             fp, SP
    // 0xd47bf8: LoadField: r2 = r1->field_b
    //     0xd47bf8: ldur            w2, [x1, #0xb]
    // 0xd47bfc: DecompressPointer r2
    //     0xd47bfc: add             x2, x2, HEAP, lsl #32
    // 0xd47c00: cmp             w2, NULL
    // 0xd47c04: b.eq            #0xd47c24
    // 0xd47c08: LoadField: r0 = r1->field_3f
    //     0xd47c08: ldur            w0, [x1, #0x3f]
    // 0xd47c0c: DecompressPointer r0
    //     0xd47c0c: add             x0, x0, HEAP, lsl #32
    // 0xd47c10: cmp             w0, NULL
    // 0xd47c14: b.eq            #0xd47c28
    // 0xd47c18: LeaveFrame
    //     0xd47c18: mov             SP, fp
    //     0xd47c1c: ldp             fp, lr, [SP], #0x10
    // 0xd47c20: ret
    //     0xd47c20: ret             
    // 0xd47c24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd47c24: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd47c28: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd47c28: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _isEnabled(/* No info */) {
    // ** addr: 0xd48c7c, size: 0x4c
    // 0xd48c7c: LoadField: r2 = r1->field_b
    //     0xd48c7c: ldur            w2, [x1, #0xb]
    // 0xd48c80: DecompressPointer r2
    //     0xd48c80: add             x2, x2, HEAP, lsl #32
    // 0xd48c84: cmp             w2, NULL
    // 0xd48c88: b.eq            #0xd48cbc
    // 0xd48c8c: LoadField: r1 = r2->field_93
    //     0xd48c8c: ldur            w1, [x2, #0x93]
    // 0xd48c90: DecompressPointer r1
    //     0xd48c90: add             x1, x1, HEAP, lsl #32
    // 0xd48c94: cmp             w1, NULL
    // 0xd48c98: b.ne            #0xd48cb4
    // 0xd48c9c: LoadField: r3 = r2->field_1b
    //     0xd48c9c: ldur            w3, [x2, #0x1b]
    // 0xd48ca0: DecompressPointer r3
    //     0xd48ca0: add             x3, x3, HEAP, lsl #32
    // 0xd48ca4: LoadField: r2 = r3->field_db
    //     0xd48ca4: ldur            w2, [x3, #0xdb]
    // 0xd48ca8: DecompressPointer r2
    //     0xd48ca8: add             x2, x2, HEAP, lsl #32
    // 0xd48cac: mov             x0, x2
    // 0xd48cb0: b               #0xd48cb8
    // 0xd48cb4: mov             x0, x1
    // 0xd48cb8: ret
    //     0xd48cb8: ret             
    // 0xd48cbc: EnterFrame
    //     0xd48cbc: stp             fp, lr, [SP, #-0x10]!
    //     0xd48cc0: mov             fp, SP
    // 0xd48cc4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd48cc4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _errorColor(/* No info */) {
    // ** addr: 0xd48cc8, size: 0xa8
    // 0xd48cc8: EnterFrame
    //     0xd48cc8: stp             fp, lr, [SP, #-0x10]!
    //     0xd48ccc: mov             fp, SP
    // 0xd48cd0: AllocStack(0x8)
    //     0xd48cd0: sub             SP, SP, #8
    // 0xd48cd4: SetupParameters(_TextFieldState this /* r1 => r0, fp-0x8 */)
    //     0xd48cd4: mov             x0, x1
    //     0xd48cd8: stur            x1, [fp, #-8]
    // 0xd48cdc: CheckStackOverflow
    //     0xd48cdc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd48ce0: cmp             SP, x16
    //     0xd48ce4: b.ls            #0xd48d60
    // 0xd48ce8: LoadField: r1 = r0->field_b
    //     0xd48ce8: ldur            w1, [x0, #0xb]
    // 0xd48cec: DecompressPointer r1
    //     0xd48cec: add             x1, x1, HEAP, lsl #32
    // 0xd48cf0: cmp             w1, NULL
    // 0xd48cf4: b.eq            #0xd48d68
    // 0xd48cf8: mov             x1, x0
    // 0xd48cfc: r0 = _getEffectiveDecoration()
    //     0xd48cfc: bl              #0xd48d70  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_getEffectiveDecoration
    // 0xd48d00: LoadField: r1 = r0->field_5b
    //     0xd48d00: ldur            w1, [x0, #0x5b]
    // 0xd48d04: DecompressPointer r1
    //     0xd48d04: add             x1, x1, HEAP, lsl #32
    // 0xd48d08: cmp             w1, NULL
    // 0xd48d0c: b.ne            #0xd48d18
    // 0xd48d10: r0 = Null
    //     0xd48d10: mov             x0, NULL
    // 0xd48d14: b               #0xd48d20
    // 0xd48d18: LoadField: r0 = r1->field_b
    //     0xd48d18: ldur            w0, [x1, #0xb]
    // 0xd48d1c: DecompressPointer r0
    //     0xd48d1c: add             x0, x0, HEAP, lsl #32
    // 0xd48d20: cmp             w0, NULL
    // 0xd48d24: b.ne            #0xd48d54
    // 0xd48d28: ldur            x0, [fp, #-8]
    // 0xd48d2c: LoadField: r1 = r0->field_f
    //     0xd48d2c: ldur            w1, [x0, #0xf]
    // 0xd48d30: DecompressPointer r1
    //     0xd48d30: add             x1, x1, HEAP, lsl #32
    // 0xd48d34: cmp             w1, NULL
    // 0xd48d38: b.eq            #0xd48d6c
    // 0xd48d3c: r0 = of()
    //     0xd48d3c: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd48d40: LoadField: r1 = r0->field_3f
    //     0xd48d40: ldur            w1, [x0, #0x3f]
    // 0xd48d44: DecompressPointer r1
    //     0xd48d44: add             x1, x1, HEAP, lsl #32
    // 0xd48d48: LoadField: r2 = r1->field_6b
    //     0xd48d48: ldur            w2, [x1, #0x6b]
    // 0xd48d4c: DecompressPointer r2
    //     0xd48d4c: add             x2, x2, HEAP, lsl #32
    // 0xd48d50: mov             x0, x2
    // 0xd48d54: LeaveFrame
    //     0xd48d54: mov             SP, fp
    //     0xd48d58: ldp             fp, lr, [SP], #0x10
    // 0xd48d5c: ret
    //     0xd48d5c: ret             
    // 0xd48d60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd48d60: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd48d64: b               #0xd48ce8
    // 0xd48d68: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd48d68: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd48d6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd48d6c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _getEffectiveDecoration(/* No info */) {
    // ** addr: 0xd48d70, size: 0x3e0
    // 0xd48d70: EnterFrame
    //     0xd48d70: stp             fp, lr, [SP, #-0x10]!
    //     0xd48d74: mov             fp, SP
    // 0xd48d78: AllocStack(0x58)
    //     0xd48d78: sub             SP, SP, #0x58
    // 0xd48d7c: SetupParameters(_TextFieldState this /* r1 => r0, fp-0x8 */)
    //     0xd48d7c: mov             x0, x1
    //     0xd48d80: stur            x1, [fp, #-8]
    // 0xd48d84: CheckStackOverflow
    //     0xd48d84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd48d88: cmp             SP, x16
    //     0xd48d8c: b.ls            #0xd49118
    // 0xd48d90: LoadField: r1 = r0->field_f
    //     0xd48d90: ldur            w1, [x0, #0xf]
    // 0xd48d94: DecompressPointer r1
    //     0xd48d94: add             x1, x1, HEAP, lsl #32
    // 0xd48d98: cmp             w1, NULL
    // 0xd48d9c: b.eq            #0xd49120
    // 0xd48da0: r0 = of()
    //     0xd48da0: bl              #0xd0bbf8  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0xd48da4: mov             x2, x0
    // 0xd48da8: ldur            x0, [fp, #-8]
    // 0xd48dac: stur            x2, [fp, #-0x10]
    // 0xd48db0: LoadField: r1 = r0->field_f
    //     0xd48db0: ldur            w1, [x0, #0xf]
    // 0xd48db4: DecompressPointer r1
    //     0xd48db4: add             x1, x1, HEAP, lsl #32
    // 0xd48db8: cmp             w1, NULL
    // 0xd48dbc: b.eq            #0xd49124
    // 0xd48dc0: r0 = of()
    //     0xd48dc0: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd48dc4: mov             x2, x0
    // 0xd48dc8: ldur            x0, [fp, #-8]
    // 0xd48dcc: stur            x2, [fp, #-0x18]
    // 0xd48dd0: LoadField: r1 = r0->field_f
    //     0xd48dd0: ldur            w1, [x0, #0xf]
    // 0xd48dd4: DecompressPointer r1
    //     0xd48dd4: add             x1, x1, HEAP, lsl #32
    // 0xd48dd8: cmp             w1, NULL
    // 0xd48ddc: b.eq            #0xd49128
    // 0xd48de0: r0 = of()
    //     0xd48de0: bl              #0xd1e0d0  ; [package:flutter/src/material/input_decorator.dart] InputDecorationTheme::of
    // 0xd48de4: mov             x1, x0
    // 0xd48de8: ldur            x0, [fp, #-8]
    // 0xd48dec: LoadField: r2 = r0->field_b
    //     0xd48dec: ldur            w2, [x0, #0xb]
    // 0xd48df0: DecompressPointer r2
    //     0xd48df0: add             x2, x2, HEAP, lsl #32
    // 0xd48df4: cmp             w2, NULL
    // 0xd48df8: b.eq            #0xd4912c
    // 0xd48dfc: LoadField: r3 = r2->field_1b
    //     0xd48dfc: ldur            w3, [x2, #0x1b]
    // 0xd48e00: DecompressPointer r3
    //     0xd48e00: add             x3, x3, HEAP, lsl #32
    // 0xd48e04: mov             x2, x1
    // 0xd48e08: mov             x1, x3
    // 0xd48e0c: r0 = applyDefaults()
    //     0xd48e0c: bl              #0xd2d7ec  ; [package:flutter/src/material/input_decorator.dart] InputDecoration::applyDefaults
    // 0xd48e10: ldur            x1, [fp, #-8]
    // 0xd48e14: stur            x0, [fp, #-0x20]
    // 0xd48e18: r0 = _isEnabled()
    //     0xd48e18: bl              #0xd48c7c  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_isEnabled
    // 0xd48e1c: mov             x1, x0
    // 0xd48e20: ldur            x0, [fp, #-8]
    // 0xd48e24: LoadField: r2 = r0->field_b
    //     0xd48e24: ldur            w2, [x0, #0xb]
    // 0xd48e28: DecompressPointer r2
    //     0xd48e28: add             x2, x2, HEAP, lsl #32
    // 0xd48e2c: cmp             w2, NULL
    // 0xd48e30: b.eq            #0xd49130
    // 0xd48e34: LoadField: r3 = r2->field_1b
    //     0xd48e34: ldur            w3, [x2, #0x1b]
    // 0xd48e38: DecompressPointer r3
    //     0xd48e38: add             x3, x3, HEAP, lsl #32
    // 0xd48e3c: LoadField: r4 = r3->field_3f
    //     0xd48e3c: ldur            w4, [x3, #0x3f]
    // 0xd48e40: DecompressPointer r4
    //     0xd48e40: add             x4, x4, HEAP, lsl #32
    // 0xd48e44: cmp             w4, NULL
    // 0xd48e48: b.ne            #0xd48e54
    // 0xd48e4c: r3 = Null
    //     0xd48e4c: mov             x3, NULL
    // 0xd48e50: b               #0xd48e58
    // 0xd48e54: mov             x3, x4
    // 0xd48e58: cmp             w3, NULL
    // 0xd48e5c: b.ne            #0xd48e70
    // 0xd48e60: LoadField: r3 = r2->field_5f
    //     0xd48e60: ldur            w3, [x2, #0x5f]
    // 0xd48e64: DecompressPointer r3
    //     0xd48e64: add             x3, x3, HEAP, lsl #32
    // 0xd48e68: mov             x2, x3
    // 0xd48e6c: b               #0xd48e74
    // 0xd48e70: mov             x2, x3
    // 0xd48e74: stp             x2, x1, [SP]
    // 0xd48e78: ldur            x1, [fp, #-0x20]
    // 0xd48e7c: r4 = const [0, 0x3, 0x2, 0x1, enabled, 0x1, hintMaxLines, 0x2, null]
    //     0xd48e7c: add             x4, PP, #0x8f, lsl #12  ; [pp+0x8f700] List(9) [0, 0x3, 0x2, 0x1, "enabled", 0x1, "hintMaxLines", 0x2, Null]
    //     0xd48e80: ldr             x4, [x4, #0x700]
    // 0xd48e84: r0 = copyWith()
    //     0xd48e84: bl              #0xd1c914  ; [package:flutter/src/material/input_decorator.dart] InputDecoration::copyWith
    // 0xd48e88: stur            x0, [fp, #-0x20]
    // 0xd48e8c: LoadField: r1 = r0->field_ab
    //     0xd48e8c: ldur            w1, [x0, #0xab]
    // 0xd48e90: DecompressPointer r1
    //     0xd48e90: add             x1, x1, HEAP, lsl #32
    // 0xd48e94: cmp             w1, NULL
    // 0xd48e98: b.ne            #0xd48eac
    // 0xd48e9c: LoadField: r1 = r0->field_a7
    //     0xd48e9c: ldur            w1, [x0, #0xa7]
    // 0xd48ea0: DecompressPointer r1
    //     0xd48ea0: add             x1, x1, HEAP, lsl #32
    // 0xd48ea4: cmp             w1, NULL
    // 0xd48ea8: b.eq            #0xd48eb8
    // 0xd48eac: LeaveFrame
    //     0xd48eac: mov             SP, fp
    //     0xd48eb0: ldp             fp, lr, [SP], #0x10
    // 0xd48eb4: ret
    //     0xd48eb4: ret             
    // 0xd48eb8: ldur            x2, [fp, #-8]
    // 0xd48ebc: mov             x1, x2
    // 0xd48ec0: r0 = _currentLength()
    //     0xd48ec0: bl              #0xd4939c  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_currentLength
    // 0xd48ec4: mov             x3, x0
    // 0xd48ec8: ldur            x2, [fp, #-8]
    // 0xd48ecc: stur            x3, [fp, #-0x28]
    // 0xd48ed0: LoadField: r0 = r2->field_b
    //     0xd48ed0: ldur            w0, [x2, #0xb]
    // 0xd48ed4: DecompressPointer r0
    //     0xd48ed4: add             x0, x0, HEAP, lsl #32
    // 0xd48ed8: cmp             w0, NULL
    // 0xd48edc: b.eq            #0xd49134
    // 0xd48ee0: LoadField: r1 = r0->field_77
    //     0xd48ee0: ldur            w1, [x0, #0x77]
    // 0xd48ee4: DecompressPointer r1
    //     0xd48ee4: add             x1, x1, HEAP, lsl #32
    // 0xd48ee8: cmp             w1, NULL
    // 0xd48eec: b.ne            #0xd48f00
    // 0xd48ef0: ldur            x0, [fp, #-0x20]
    // 0xd48ef4: LeaveFrame
    //     0xd48ef4: mov             SP, fp
    //     0xd48ef8: ldp             fp, lr, [SP], #0x10
    // 0xd48efc: ret
    //     0xd48efc: ret             
    // 0xd48f00: r0 = BoxInt64Instr(r3)
    //     0xd48f00: sbfiz           x0, x3, #1, #0x1f
    //     0xd48f04: cmp             x3, x0, asr #1
    //     0xd48f08: b.eq            #0xd48f14
    //     0xd48f0c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xd48f10: stur            x3, [x0, #7]
    // 0xd48f14: str             x0, [SP]
    // 0xd48f18: r0 = _interpolateSingle()
    //     0xd48f18: bl              #0x7e237c  ; [dart:core] _StringBase::_interpolateSingle
    // 0xd48f1c: mov             x3, x0
    // 0xd48f20: ldur            x0, [fp, #-8]
    // 0xd48f24: stur            x3, [fp, #-0x38]
    // 0xd48f28: LoadField: r1 = r0->field_b
    //     0xd48f28: ldur            w1, [x0, #0xb]
    // 0xd48f2c: DecompressPointer r1
    //     0xd48f2c: add             x1, x1, HEAP, lsl #32
    // 0xd48f30: cmp             w1, NULL
    // 0xd48f34: b.eq            #0xd49138
    // 0xd48f38: LoadField: r4 = r1->field_77
    //     0xd48f38: ldur            w4, [x1, #0x77]
    // 0xd48f3c: DecompressPointer r4
    //     0xd48f3c: add             x4, x4, HEAP, lsl #32
    // 0xd48f40: stur            x4, [fp, #-0x30]
    // 0xd48f44: cmp             w4, NULL
    // 0xd48f48: b.eq            #0xd4913c
    // 0xd48f4c: r1 = LoadInt32Instr(r4)
    //     0xd48f4c: sbfx            x1, x4, #1, #0x1f
    // 0xd48f50: cmp             x1, #0
    // 0xd48f54: b.le            #0xd4901c
    // 0xd48f58: ldur            x6, [fp, #-0x10]
    // 0xd48f5c: ldur            x5, [fp, #-0x28]
    // 0xd48f60: r1 = Null
    //     0xd48f60: mov             x1, NULL
    // 0xd48f64: r2 = 4
    //     0xd48f64: mov             x2, #4
    // 0xd48f68: r0 = AllocateArray()
    //     0xd48f68: bl              #0x13df928  ; AllocateArrayStub
    // 0xd48f6c: r16 = "/"
    //     0xd48f6c: ldr             x16, [PP, #0xfe0]  ; [pp+0xfe0] "/"
    // 0xd48f70: StoreField: r0->field_f = r16
    //     0xd48f70: stur            w16, [x0, #0xf]
    // 0xd48f74: ldur            x1, [fp, #-0x30]
    // 0xd48f78: StoreField: r0->field_13 = r1
    //     0xd48f78: stur            w1, [x0, #0x13]
    // 0xd48f7c: str             x0, [SP]
    // 0xd48f80: r0 = _interpolate()
    //     0xd48f80: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xd48f84: ldur            x16, [fp, #-0x38]
    // 0xd48f88: stp             x0, x16, [SP]
    // 0xd48f8c: r0 = +()
    //     0xd48f8c: bl              #0x7e1e74  ; [dart:core] _StringBase::+
    // 0xd48f90: mov             x5, x0
    // 0xd48f94: ldur            x4, [fp, #-8]
    // 0xd48f98: stur            x5, [fp, #-0x30]
    // 0xd48f9c: LoadField: r0 = r4->field_b
    //     0xd48f9c: ldur            w0, [x4, #0xb]
    // 0xd48fa0: DecompressPointer r0
    //     0xd48fa0: add             x0, x0, HEAP, lsl #32
    // 0xd48fa4: cmp             w0, NULL
    // 0xd48fa8: b.eq            #0xd49140
    // 0xd48fac: LoadField: r3 = r0->field_77
    //     0xd48fac: ldur            w3, [x0, #0x77]
    // 0xd48fb0: DecompressPointer r3
    //     0xd48fb0: add             x3, x3, HEAP, lsl #32
    // 0xd48fb4: cmp             w3, NULL
    // 0xd48fb8: b.eq            #0xd49144
    // 0xd48fbc: r0 = LoadInt32Instr(r3)
    //     0xd48fbc: sbfx            x0, x3, #1, #0x1f
    // 0xd48fc0: ldur            x1, [fp, #-0x28]
    // 0xd48fc4: sub             x2, x0, x1
    // 0xd48fc8: r0 = BoxInt64Instr(r2)
    //     0xd48fc8: sbfiz           x0, x2, #1, #0x1f
    //     0xd48fcc: cmp             x2, x0, asr #1
    //     0xd48fd0: b.eq            #0xd48fdc
    //     0xd48fd4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xd48fd8: stur            x2, [x0, #7]
    // 0xd48fdc: mov             x1, x0
    // 0xd48fe0: r2 = 0
    //     0xd48fe0: mov             x2, #0
    // 0xd48fe4: r0 = clamp()
    //     0xd48fe4: bl              #0x13db4a0  ; [dart:core] _IntegerImplementation::clamp
    // 0xd48fe8: r2 = LoadInt32Instr(r0)
    //     0xd48fe8: sbfx            x2, x0, #1, #0x1f
    //     0xd48fec: tbz             w0, #0, #0xd48ff4
    //     0xd48ff0: ldur            x2, [x0, #7]
    // 0xd48ff4: ldur            x1, [fp, #-0x10]
    // 0xd48ff8: r0 = LoadClassIdInstr(r1)
    //     0xd48ff8: ldur            x0, [x1, #-1]
    //     0xd48ffc: ubfx            x0, x0, #0xc, #0x14
    // 0xd49000: r0 = GDT[cid_x0 + 0x153a1]()
    //     0xd49000: mov             x17, #0x53a1
    //     0xd49004: movk            x17, #1, lsl #16
    //     0xd49008: add             lr, x0, x17
    //     0xd4900c: ldr             lr, [x21, lr, lsl #3]
    //     0xd49010: blr             lr
    // 0xd49014: ldur            x2, [fp, #-0x30]
    // 0xd49018: b               #0xd49024
    // 0xd4901c: ldur            x2, [fp, #-0x38]
    // 0xd49020: r0 = ""
    //     0xd49020: ldr             x0, [PP, #0x900]  ; [pp+0x900] ""
    // 0xd49024: ldur            x1, [fp, #-8]
    // 0xd49028: stur            x2, [fp, #-0x10]
    // 0xd4902c: stur            x0, [fp, #-0x30]
    // 0xd49030: r0 = _hasIntrinsicError()
    //     0xd49030: bl              #0xd491d8  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_hasIntrinsicError
    // 0xd49034: tbnz            w0, #4, #0xd490f0
    // 0xd49038: ldur            x0, [fp, #-0x20]
    // 0xd4903c: LoadField: r1 = r0->field_57
    //     0xd4903c: ldur            w1, [x0, #0x57]
    // 0xd49040: DecompressPointer r1
    //     0xd49040: add             x1, x1, HEAP, lsl #32
    // 0xd49044: cmp             w1, NULL
    // 0xd49048: b.ne            #0xd49054
    // 0xd4904c: r2 = ""
    //     0xd4904c: ldr             x2, [PP, #0x900]  ; [pp+0x900] ""
    // 0xd49050: b               #0xd49058
    // 0xd49054: mov             x2, x1
    // 0xd49058: stur            x2, [fp, #-0x38]
    // 0xd4905c: LoadField: r1 = r0->field_5b
    //     0xd4905c: ldur            w1, [x0, #0x5b]
    // 0xd49060: DecompressPointer r1
    //     0xd49060: add             x1, x1, HEAP, lsl #32
    // 0xd49064: cmp             w1, NULL
    // 0xd49068: b.ne            #0xd490bc
    // 0xd4906c: ldur            x1, [fp, #-0x18]
    // 0xd49070: LoadField: r3 = r1->field_2f
    //     0xd49070: ldur            w3, [x1, #0x2f]
    // 0xd49074: DecompressPointer r3
    //     0xd49074: add             x3, x3, HEAP, lsl #32
    // 0xd49078: tbnz            w3, #4, #0xd4909c
    // 0xd4907c: ldur            x1, [fp, #-8]
    // 0xd49080: LoadField: r3 = r1->field_f
    //     0xd49080: ldur            w3, [x1, #0xf]
    // 0xd49084: DecompressPointer r3
    //     0xd49084: add             x3, x3, HEAP, lsl #32
    // 0xd49088: cmp             w3, NULL
    // 0xd4908c: b.eq            #0xd49148
    // 0xd49090: mov             x1, x3
    // 0xd49094: r0 = _m2CounterErrorStyle()
    //     0xd49094: bl              #0xd49150  ; [package:flutter/src/material/text_field.dart] ::_m2CounterErrorStyle
    // 0xd49098: b               #0xd490c0
    // 0xd4909c: ldur            x1, [fp, #-8]
    // 0xd490a0: LoadField: r0 = r1->field_f
    //     0xd490a0: ldur            w0, [x1, #0xf]
    // 0xd490a4: DecompressPointer r0
    //     0xd490a4: add             x0, x0, HEAP, lsl #32
    // 0xd490a8: cmp             w0, NULL
    // 0xd490ac: b.eq            #0xd4914c
    // 0xd490b0: mov             x1, x0
    // 0xd490b4: r0 = _m2CounterErrorStyle()
    //     0xd490b4: bl              #0xd49150  ; [package:flutter/src/material/text_field.dart] ::_m2CounterErrorStyle
    // 0xd490b8: b               #0xd490c0
    // 0xd490bc: mov             x0, x1
    // 0xd490c0: ldur            x16, [fp, #-0x38]
    // 0xd490c4: stp             x0, x16, [SP, #0x10]
    // 0xd490c8: ldur            x16, [fp, #-0x10]
    // 0xd490cc: ldur            lr, [fp, #-0x30]
    // 0xd490d0: stp             lr, x16, [SP]
    // 0xd490d4: ldur            x1, [fp, #-0x20]
    // 0xd490d8: r4 = const [0, 0x5, 0x4, 0x1, counterStyle, 0x2, counterText, 0x3, errorText, 0x1, semanticCounterText, 0x4, null]
    //     0xd490d8: add             x4, PP, #0x8f, lsl #12  ; [pp+0x8f708] List(13) [0, 0x5, 0x4, 0x1, "counterStyle", 0x2, "counterText", 0x3, "errorText", 0x1, "semanticCounterText", 0x4, Null]
    //     0xd490dc: ldr             x4, [x4, #0x708]
    // 0xd490e0: r0 = copyWith()
    //     0xd490e0: bl              #0xd1c914  ; [package:flutter/src/material/input_decorator.dart] InputDecoration::copyWith
    // 0xd490e4: LeaveFrame
    //     0xd490e4: mov             SP, fp
    //     0xd490e8: ldp             fp, lr, [SP], #0x10
    // 0xd490ec: ret
    //     0xd490ec: ret             
    // 0xd490f0: ldur            x16, [fp, #-0x10]
    // 0xd490f4: ldur            lr, [fp, #-0x30]
    // 0xd490f8: stp             lr, x16, [SP]
    // 0xd490fc: ldur            x1, [fp, #-0x20]
    // 0xd49100: r4 = const [0, 0x3, 0x2, 0x1, counterText, 0x1, semanticCounterText, 0x2, null]
    //     0xd49100: add             x4, PP, #0x8f, lsl #12  ; [pp+0x8f710] List(9) [0, 0x3, 0x2, 0x1, "counterText", 0x1, "semanticCounterText", 0x2, Null]
    //     0xd49104: ldr             x4, [x4, #0x710]
    // 0xd49108: r0 = copyWith()
    //     0xd49108: bl              #0xd1c914  ; [package:flutter/src/material/input_decorator.dart] InputDecoration::copyWith
    // 0xd4910c: LeaveFrame
    //     0xd4910c: mov             SP, fp
    //     0xd49110: ldp             fp, lr, [SP], #0x10
    // 0xd49114: ret
    //     0xd49114: ret             
    // 0xd49118: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd49118: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd4911c: b               #0xd48d90
    // 0xd49120: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd49120: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd49124: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd49124: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd49128: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd49128: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd4912c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd4912c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd49130: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd49130: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd49134: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd49134: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd49138: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd49138: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd4913c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd4913c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd49140: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd49140: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd49144: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd49144: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd49148: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd49148: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd4914c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd4914c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _hasIntrinsicError(/* No info */) {
    // ** addr: 0xd491d8, size: 0x18c
    // 0xd491d8: EnterFrame
    //     0xd491d8: stp             fp, lr, [SP, #-0x10]!
    //     0xd491dc: mov             fp, SP
    // 0xd491e0: AllocStack(0x10)
    //     0xd491e0: sub             SP, SP, #0x10
    // 0xd491e4: SetupParameters(_TextFieldState this /* r1 => r0, fp-0x8 */)
    //     0xd491e4: mov             x0, x1
    //     0xd491e8: stur            x1, [fp, #-8]
    // 0xd491ec: CheckStackOverflow
    //     0xd491ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd491f0: cmp             SP, x16
    //     0xd491f4: b.ls            #0xd49348
    // 0xd491f8: LoadField: r1 = r0->field_b
    //     0xd491f8: ldur            w1, [x0, #0xb]
    // 0xd491fc: DecompressPointer r1
    //     0xd491fc: add             x1, x1, HEAP, lsl #32
    // 0xd49200: cmp             w1, NULL
    // 0xd49204: b.eq            #0xd49350
    // 0xd49208: LoadField: r2 = r1->field_77
    //     0xd49208: ldur            w2, [x1, #0x77]
    // 0xd4920c: DecompressPointer r2
    //     0xd4920c: add             x2, x2, HEAP, lsl #32
    // 0xd49210: cmp             w2, NULL
    // 0xd49214: b.eq            #0xd49338
    // 0xd49218: r3 = LoadInt32Instr(r2)
    //     0xd49218: sbfx            x3, x2, #1, #0x1f
    // 0xd4921c: cmp             x3, #0
    // 0xd49220: b.le            #0xd49338
    // 0xd49224: LoadField: r2 = r1->field_13
    //     0xd49224: ldur            w2, [x1, #0x13]
    // 0xd49228: DecompressPointer r2
    //     0xd49228: add             x2, x2, HEAP, lsl #32
    // 0xd4922c: cmp             w2, NULL
    // 0xd49230: b.ne            #0xd492c4
    // 0xd49234: mov             x1, x0
    // 0xd49238: r0 = restorePending()
    //     0xd49238: bl              #0xd49364  ; [dart:mixin_deduplication] _MixinApplication36&State&RestorationMixin::restorePending
    // 0xd4923c: tbz             w0, #4, #0xd492b8
    // 0xd49240: ldur            x0, [fp, #-8]
    // 0xd49244: mov             x1, x0
    // 0xd49248: r0 = _effectiveController()
    //     0xd49248: bl              #0xd49538  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_effectiveController
    // 0xd4924c: LoadField: r1 = r0->field_27
    //     0xd4924c: ldur            w1, [x0, #0x27]
    // 0xd49250: DecompressPointer r1
    //     0xd49250: add             x1, x1, HEAP, lsl #32
    // 0xd49254: LoadField: r0 = r1->field_7
    //     0xd49254: ldur            w0, [x1, #7]
    // 0xd49258: DecompressPointer r0
    //     0xd49258: add             x0, x0, HEAP, lsl #32
    // 0xd4925c: mov             x1, x0
    // 0xd49260: r0 = StringCharacters.characters()
    //     0xd49260: bl              #0x8613d0  ; [package:characters/src/extensions.dart] ::StringCharacters.characters
    // 0xd49264: str             x0, [SP]
    // 0xd49268: r0 = length()
    //     0xd49268: bl              #0xbfbeac  ; [package:characters/src/characters_impl.dart] StringCharacters::length
    // 0xd4926c: mov             x1, x0
    // 0xd49270: ldur            x0, [fp, #-8]
    // 0xd49274: LoadField: r2 = r0->field_b
    //     0xd49274: ldur            w2, [x0, #0xb]
    // 0xd49278: DecompressPointer r2
    //     0xd49278: add             x2, x2, HEAP, lsl #32
    // 0xd4927c: cmp             w2, NULL
    // 0xd49280: b.eq            #0xd49354
    // 0xd49284: LoadField: r0 = r2->field_77
    //     0xd49284: ldur            w0, [x2, #0x77]
    // 0xd49288: DecompressPointer r0
    //     0xd49288: add             x0, x0, HEAP, lsl #32
    // 0xd4928c: cmp             w0, NULL
    // 0xd49290: b.eq            #0xd49358
    // 0xd49294: r2 = LoadInt32Instr(r1)
    //     0xd49294: sbfx            x2, x1, #1, #0x1f
    //     0xd49298: tbz             w1, #0, #0xd492a0
    //     0xd4929c: ldur            x2, [x1, #7]
    // 0xd492a0: r1 = LoadInt32Instr(r0)
    //     0xd492a0: sbfx            x1, x0, #1, #0x1f
    // 0xd492a4: cmp             x2, x1
    // 0xd492a8: r16 = true
    //     0xd492a8: add             x16, NULL, #0x20  ; true
    // 0xd492ac: r17 = false
    //     0xd492ac: add             x17, NULL, #0x30  ; false
    // 0xd492b0: csel            x0, x16, x17, gt
    // 0xd492b4: b               #0xd492bc
    // 0xd492b8: r0 = false
    //     0xd492b8: add             x0, NULL, #0x30  ; false
    // 0xd492bc: mov             x1, x0
    // 0xd492c0: b               #0xd49330
    // 0xd492c4: mov             x1, x0
    // 0xd492c8: r0 = _effectiveController()
    //     0xd492c8: bl              #0xd49538  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_effectiveController
    // 0xd492cc: LoadField: r1 = r0->field_27
    //     0xd492cc: ldur            w1, [x0, #0x27]
    // 0xd492d0: DecompressPointer r1
    //     0xd492d0: add             x1, x1, HEAP, lsl #32
    // 0xd492d4: LoadField: r0 = r1->field_7
    //     0xd492d4: ldur            w0, [x1, #7]
    // 0xd492d8: DecompressPointer r0
    //     0xd492d8: add             x0, x0, HEAP, lsl #32
    // 0xd492dc: mov             x1, x0
    // 0xd492e0: r0 = StringCharacters.characters()
    //     0xd492e0: bl              #0x8613d0  ; [package:characters/src/extensions.dart] ::StringCharacters.characters
    // 0xd492e4: str             x0, [SP]
    // 0xd492e8: r0 = length()
    //     0xd492e8: bl              #0xbfbeac  ; [package:characters/src/characters_impl.dart] StringCharacters::length
    // 0xd492ec: ldur            x1, [fp, #-8]
    // 0xd492f0: LoadField: r2 = r1->field_b
    //     0xd492f0: ldur            w2, [x1, #0xb]
    // 0xd492f4: DecompressPointer r2
    //     0xd492f4: add             x2, x2, HEAP, lsl #32
    // 0xd492f8: cmp             w2, NULL
    // 0xd492fc: b.eq            #0xd4935c
    // 0xd49300: LoadField: r1 = r2->field_77
    //     0xd49300: ldur            w1, [x2, #0x77]
    // 0xd49304: DecompressPointer r1
    //     0xd49304: add             x1, x1, HEAP, lsl #32
    // 0xd49308: cmp             w1, NULL
    // 0xd4930c: b.eq            #0xd49360
    // 0xd49310: r2 = LoadInt32Instr(r0)
    //     0xd49310: sbfx            x2, x0, #1, #0x1f
    //     0xd49314: tbz             w0, #0, #0xd4931c
    //     0xd49318: ldur            x2, [x0, #7]
    // 0xd4931c: r3 = LoadInt32Instr(r1)
    //     0xd4931c: sbfx            x3, x1, #1, #0x1f
    // 0xd49320: cmp             x2, x3
    // 0xd49324: r16 = true
    //     0xd49324: add             x16, NULL, #0x20  ; true
    // 0xd49328: r17 = false
    //     0xd49328: add             x17, NULL, #0x30  ; false
    // 0xd4932c: csel            x1, x16, x17, gt
    // 0xd49330: mov             x0, x1
    // 0xd49334: b               #0xd4933c
    // 0xd49338: r0 = false
    //     0xd49338: add             x0, NULL, #0x30  ; false
    // 0xd4933c: LeaveFrame
    //     0xd4933c: mov             SP, fp
    //     0xd49340: ldp             fp, lr, [SP], #0x10
    // 0xd49344: ret
    //     0xd49344: ret             
    // 0xd49348: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd49348: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd4934c: b               #0xd491f8
    // 0xd49350: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd49350: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd49354: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd49354: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd49358: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd49358: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd4935c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd4935c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd49360: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd49360: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _currentLength(/* No info */) {
    // ** addr: 0xd4939c, size: 0x60
    // 0xd4939c: EnterFrame
    //     0xd4939c: stp             fp, lr, [SP, #-0x10]!
    //     0xd493a0: mov             fp, SP
    // 0xd493a4: AllocStack(0x8)
    //     0xd493a4: sub             SP, SP, #8
    // 0xd493a8: CheckStackOverflow
    //     0xd493a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd493ac: cmp             SP, x16
    //     0xd493b0: b.ls            #0xd493f4
    // 0xd493b4: r0 = _effectiveController()
    //     0xd493b4: bl              #0xd49538  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_effectiveController
    // 0xd493b8: LoadField: r1 = r0->field_27
    //     0xd493b8: ldur            w1, [x0, #0x27]
    // 0xd493bc: DecompressPointer r1
    //     0xd493bc: add             x1, x1, HEAP, lsl #32
    // 0xd493c0: LoadField: r0 = r1->field_7
    //     0xd493c0: ldur            w0, [x1, #7]
    // 0xd493c4: DecompressPointer r0
    //     0xd493c4: add             x0, x0, HEAP, lsl #32
    // 0xd493c8: mov             x1, x0
    // 0xd493cc: r0 = StringCharacters.characters()
    //     0xd493cc: bl              #0x8613d0  ; [package:characters/src/extensions.dart] ::StringCharacters.characters
    // 0xd493d0: str             x0, [SP]
    // 0xd493d4: r0 = length()
    //     0xd493d4: bl              #0xbfbeac  ; [package:characters/src/characters_impl.dart] StringCharacters::length
    // 0xd493d8: r1 = LoadInt32Instr(r0)
    //     0xd493d8: sbfx            x1, x0, #1, #0x1f
    //     0xd493dc: tbz             w0, #0, #0xd493e4
    //     0xd493e0: ldur            x1, [x0, #7]
    // 0xd493e4: mov             x0, x1
    // 0xd493e8: LeaveFrame
    //     0xd493e8: mov             SP, fp
    //     0xd493ec: ldp             fp, lr, [SP], #0x10
    // 0xd493f0: ret
    //     0xd493f0: ret             
    // 0xd493f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd493f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd493f8: b               #0xd493b4
  }
  get _ _hasError(/* No info */) {
    // ** addr: 0xd493fc, size: 0x70
    // 0xd493fc: EnterFrame
    //     0xd493fc: stp             fp, lr, [SP, #-0x10]!
    //     0xd49400: mov             fp, SP
    // 0xd49404: CheckStackOverflow
    //     0xd49404: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd49408: cmp             SP, x16
    //     0xd4940c: b.ls            #0xd49460
    // 0xd49410: LoadField: r0 = r1->field_b
    //     0xd49410: ldur            w0, [x1, #0xb]
    // 0xd49414: DecompressPointer r0
    //     0xd49414: add             x0, x0, HEAP, lsl #32
    // 0xd49418: cmp             w0, NULL
    // 0xd4941c: b.eq            #0xd49468
    // 0xd49420: LoadField: r2 = r0->field_1b
    //     0xd49420: ldur            w2, [x0, #0x1b]
    // 0xd49424: DecompressPointer r2
    //     0xd49424: add             x2, x2, HEAP, lsl #32
    // 0xd49428: LoadField: r0 = r2->field_57
    //     0xd49428: ldur            w0, [x2, #0x57]
    // 0xd4942c: DecompressPointer r0
    //     0xd4942c: add             x0, x0, HEAP, lsl #32
    // 0xd49430: cmp             w0, NULL
    // 0xd49434: b.ne            #0xd49448
    // 0xd49438: LoadField: r0 = r2->field_53
    //     0xd49438: ldur            w0, [x2, #0x53]
    // 0xd4943c: DecompressPointer r0
    //     0xd4943c: add             x0, x0, HEAP, lsl #32
    // 0xd49440: cmp             w0, NULL
    // 0xd49444: b.eq            #0xd49450
    // 0xd49448: r0 = true
    //     0xd49448: add             x0, NULL, #0x20  ; true
    // 0xd4944c: b               #0xd49454
    // 0xd49450: r0 = _hasIntrinsicError()
    //     0xd49450: bl              #0xd491d8  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_hasIntrinsicError
    // 0xd49454: LeaveFrame
    //     0xd49454: mov             SP, fp
    //     0xd49458: ldp             fp, lr, [SP], #0x10
    // 0xd4945c: ret
    //     0xd4945c: ret             
    // 0xd49460: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd49460: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd49464: b               #0xd49410
    // 0xd49468: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd49468: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _effectiveFocusNode(/* No info */) {
    // ** addr: 0xd49478, size: 0xb4
    // 0xd49478: EnterFrame
    //     0xd49478: stp             fp, lr, [SP, #-0x10]!
    //     0xd4947c: mov             fp, SP
    // 0xd49480: AllocStack(0x10)
    //     0xd49480: sub             SP, SP, #0x10
    // 0xd49484: SetupParameters(_TextFieldState this /* r1 => r1, fp-0x8 */)
    //     0xd49484: stur            x1, [fp, #-8]
    // 0xd49488: CheckStackOverflow
    //     0xd49488: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd4948c: cmp             SP, x16
    //     0xd49490: b.ls            #0xd49520
    // 0xd49494: LoadField: r0 = r1->field_b
    //     0xd49494: ldur            w0, [x1, #0xb]
    // 0xd49498: DecompressPointer r0
    //     0xd49498: add             x0, x0, HEAP, lsl #32
    // 0xd4949c: cmp             w0, NULL
    // 0xd494a0: b.eq            #0xd49528
    // 0xd494a4: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xd494a4: ldur            w2, [x0, #0x17]
    // 0xd494a8: DecompressPointer r2
    //     0xd494a8: add             x2, x2, HEAP, lsl #32
    // 0xd494ac: cmp             w2, NULL
    // 0xd494b0: b.ne            #0xd49510
    // 0xd494b4: LoadField: r0 = r1->field_27
    //     0xd494b4: ldur            w0, [x1, #0x27]
    // 0xd494b8: DecompressPointer r0
    //     0xd494b8: add             x0, x0, HEAP, lsl #32
    // 0xd494bc: cmp             w0, NULL
    // 0xd494c0: b.ne            #0xd49504
    // 0xd494c4: r0 = FocusNode()
    //     0xd494c4: bl              #0xd4952c  ; AllocateFocusNodeStub -> FocusNode (size=0x68)
    // 0xd494c8: mov             x1, x0
    // 0xd494cc: stur            x0, [fp, #-0x10]
    // 0xd494d0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd494d0: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd494d4: r0 = FocusNode()
    //     0xd494d4: bl              #0x83cf84  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::FocusNode
    // 0xd494d8: ldur            x0, [fp, #-0x10]
    // 0xd494dc: ldur            x1, [fp, #-8]
    // 0xd494e0: StoreField: r1->field_27 = r0
    //     0xd494e0: stur            w0, [x1, #0x27]
    //     0xd494e4: ldurb           w16, [x1, #-1]
    //     0xd494e8: ldurb           w17, [x0, #-1]
    //     0xd494ec: and             x16, x17, x16, lsr #2
    //     0xd494f0: tst             x16, HEAP, lsr #32
    //     0xd494f4: b.eq            #0xd494fc
    //     0xd494f8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd494fc: ldur            x1, [fp, #-0x10]
    // 0xd49500: b               #0xd49508
    // 0xd49504: mov             x1, x0
    // 0xd49508: mov             x0, x1
    // 0xd4950c: b               #0xd49514
    // 0xd49510: mov             x0, x2
    // 0xd49514: LeaveFrame
    //     0xd49514: mov             SP, fp
    //     0xd49518: ldp             fp, lr, [SP], #0x10
    // 0xd4951c: ret
    //     0xd4951c: ret             
    // 0xd49520: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd49520: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd49524: b               #0xd49494
    // 0xd49528: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd49528: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _effectiveController(/* No info */) {
    // ** addr: 0xd49538, size: 0x6c
    // 0xd49538: EnterFrame
    //     0xd49538: stp             fp, lr, [SP, #-0x10]!
    //     0xd4953c: mov             fp, SP
    // 0xd49540: LoadField: r2 = r1->field_b
    //     0xd49540: ldur            w2, [x1, #0xb]
    // 0xd49544: DecompressPointer r2
    //     0xd49544: add             x2, x2, HEAP, lsl #32
    // 0xd49548: cmp             w2, NULL
    // 0xd4954c: b.eq            #0xd49598
    // 0xd49550: LoadField: r3 = r2->field_13
    //     0xd49550: ldur            w3, [x2, #0x13]
    // 0xd49554: DecompressPointer r3
    //     0xd49554: add             x3, x3, HEAP, lsl #32
    // 0xd49558: cmp             w3, NULL
    // 0xd4955c: b.ne            #0xd49588
    // 0xd49560: LoadField: r2 = r1->field_23
    //     0xd49560: ldur            w2, [x1, #0x23]
    // 0xd49564: DecompressPointer r2
    //     0xd49564: add             x2, x2, HEAP, lsl #32
    // 0xd49568: cmp             w2, NULL
    // 0xd4956c: b.eq            #0xd4959c
    // 0xd49570: LoadField: r1 = r2->field_33
    //     0xd49570: ldur            w1, [x2, #0x33]
    // 0xd49574: DecompressPointer r1
    //     0xd49574: add             x1, x1, HEAP, lsl #32
    // 0xd49578: cmp             w1, NULL
    // 0xd4957c: b.eq            #0xd495a0
    // 0xd49580: mov             x0, x1
    // 0xd49584: b               #0xd4958c
    // 0xd49588: mov             x0, x3
    // 0xd4958c: LeaveFrame
    //     0xd4958c: mov             SP, fp
    //     0xd49590: ldp             fp, lr, [SP], #0x10
    // 0xd49594: ret
    //     0xd49594: ret             
    // 0xd49598: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd49598: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd4959c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd4959c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd495a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd495a0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _getInputStyleForState(/* No info */) {
    // ** addr: 0xd495e0, size: 0x150
    // 0xd495e0: EnterFrame
    //     0xd495e0: stp             fp, lr, [SP, #-0x10]!
    //     0xd495e4: mov             fp, SP
    // 0xd495e8: AllocStack(0x30)
    //     0xd495e8: sub             SP, SP, #0x30
    // 0xd495ec: SetupParameters(_TextFieldState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xd495ec: mov             x0, x1
    //     0xd495f0: stur            x1, [fp, #-8]
    //     0xd495f4: stur            x2, [fp, #-0x10]
    // 0xd495f8: CheckStackOverflow
    //     0xd495f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd495fc: cmp             SP, x16
    //     0xd49600: b.ls            #0xd4970c
    // 0xd49604: LoadField: r1 = r0->field_f
    //     0xd49604: ldur            w1, [x0, #0xf]
    // 0xd49608: DecompressPointer r1
    //     0xd49608: add             x1, x1, HEAP, lsl #32
    // 0xd4960c: cmp             w1, NULL
    // 0xd49610: b.eq            #0xd49714
    // 0xd49614: r0 = of()
    //     0xd49614: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd49618: LoadField: r1 = r0->field_2f
    //     0xd49618: ldur            w1, [x0, #0x2f]
    // 0xd4961c: DecompressPointer r1
    //     0xd4961c: add             x1, x1, HEAP, lsl #32
    // 0xd49620: tbnz            w1, #4, #0xd49644
    // 0xd49624: ldur            x0, [fp, #-8]
    // 0xd49628: LoadField: r1 = r0->field_f
    //     0xd49628: ldur            w1, [x0, #0xf]
    // 0xd4962c: DecompressPointer r1
    //     0xd4962c: add             x1, x1, HEAP, lsl #32
    // 0xd49630: cmp             w1, NULL
    // 0xd49634: b.eq            #0xd49718
    // 0xd49638: r0 = _m3StateInputStyle()
    //     0xd49638: bl              #0xd49874  ; [package:flutter/src/material/text_field.dart] ::_m3StateInputStyle
    // 0xd4963c: mov             x1, x0
    // 0xd49640: b               #0xd49660
    // 0xd49644: ldur            x0, [fp, #-8]
    // 0xd49648: LoadField: r1 = r0->field_f
    //     0xd49648: ldur            w1, [x0, #0xf]
    // 0xd4964c: DecompressPointer r1
    //     0xd4964c: add             x1, x1, HEAP, lsl #32
    // 0xd49650: cmp             w1, NULL
    // 0xd49654: b.eq            #0xd4971c
    // 0xd49658: r0 = _m2StateInputStyle()
    //     0xd49658: bl              #0xd49730  ; [package:flutter/src/material/text_field.dart] ::_m2StateInputStyle
    // 0xd4965c: mov             x1, x0
    // 0xd49660: ldur            x0, [fp, #-8]
    // 0xd49664: LoadField: r2 = r0->field_b
    //     0xd49664: ldur            w2, [x0, #0xb]
    // 0xd49668: DecompressPointer r2
    //     0xd49668: add             x2, x2, HEAP, lsl #32
    // 0xd4966c: cmp             w2, NULL
    // 0xd49670: b.eq            #0xd49720
    // 0xd49674: LoadField: r2 = r0->field_3f
    //     0xd49674: ldur            w2, [x0, #0x3f]
    // 0xd49678: DecompressPointer r2
    //     0xd49678: add             x2, x2, HEAP, lsl #32
    // 0xd4967c: cmp             w2, NULL
    // 0xd49680: b.eq            #0xd49724
    // 0xd49684: LoadField: r3 = r2->field_27
    //     0xd49684: ldur            w3, [x2, #0x27]
    // 0xd49688: DecompressPointer r3
    //     0xd49688: add             x3, x3, HEAP, lsl #32
    // 0xd4968c: r16 = <TextStyle>
    //     0xd4968c: add             x16, PP, #0x18, lsl #12  ; [pp+0x18370] TypeArguments: <TextStyle>
    //     0xd49690: ldr             x16, [x16, #0x370]
    // 0xd49694: stp             x1, x16, [SP, #8]
    // 0xd49698: str             x3, [SP]
    // 0xd4969c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xd4969c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xd496a0: r0 = resolveAs()
    //     0xd496a0: bl              #0x8de57c  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveAs
    // 0xd496a4: mov             x1, x0
    // 0xd496a8: ldur            x0, [fp, #-8]
    // 0xd496ac: stur            x1, [fp, #-0x18]
    // 0xd496b0: LoadField: r2 = r0->field_b
    //     0xd496b0: ldur            w2, [x0, #0xb]
    // 0xd496b4: DecompressPointer r2
    //     0xd496b4: add             x2, x2, HEAP, lsl #32
    // 0xd496b8: cmp             w2, NULL
    // 0xd496bc: b.eq            #0xd49728
    // 0xd496c0: LoadField: r2 = r0->field_3f
    //     0xd496c0: ldur            w2, [x0, #0x3f]
    // 0xd496c4: DecompressPointer r2
    //     0xd496c4: add             x2, x2, HEAP, lsl #32
    // 0xd496c8: cmp             w2, NULL
    // 0xd496cc: b.eq            #0xd4972c
    // 0xd496d0: LoadField: r0 = r2->field_27
    //     0xd496d0: ldur            w0, [x2, #0x27]
    // 0xd496d4: DecompressPointer r0
    //     0xd496d4: add             x0, x0, HEAP, lsl #32
    // 0xd496d8: r16 = <TextStyle>
    //     0xd496d8: add             x16, PP, #0x18, lsl #12  ; [pp+0x18370] TypeArguments: <TextStyle>
    //     0xd496dc: ldr             x16, [x16, #0x370]
    // 0xd496e0: ldur            lr, [fp, #-0x10]
    // 0xd496e4: stp             lr, x16, [SP, #8]
    // 0xd496e8: str             x0, [SP]
    // 0xd496ec: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xd496ec: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xd496f0: r0 = resolveAs()
    //     0xd496f0: bl              #0x8de57c  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveAs
    // 0xd496f4: mov             x1, x0
    // 0xd496f8: ldur            x2, [fp, #-0x18]
    // 0xd496fc: r0 = merge()
    //     0xd496fc: bl              #0x8a98e8  ; [package:flutter/src/painting/text_style.dart] TextStyle::merge
    // 0xd49700: LeaveFrame
    //     0xd49700: mov             SP, fp
    //     0xd49704: ldp             fp, lr, [SP], #0x10
    // 0xd49708: ret
    //     0xd49708: ret             
    // 0xd4970c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd4970c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd49710: b               #0xd49604
    // 0xd49714: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd49714: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd49718: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd49718: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd4971c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd4971c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd49720: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd49720: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd49724: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd49724: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd49728: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd49728: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd4972c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd4972c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, PointerExitEvent) {
    // ** addr: 0xd49a34, size: 0x4c
    // 0xd49a34: EnterFrame
    //     0xd49a34: stp             fp, lr, [SP, #-0x10]!
    //     0xd49a38: mov             fp, SP
    // 0xd49a3c: ldr             x0, [fp, #0x18]
    // 0xd49a40: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd49a40: ldur            w1, [x0, #0x17]
    // 0xd49a44: DecompressPointer r1
    //     0xd49a44: add             x1, x1, HEAP, lsl #32
    // 0xd49a48: CheckStackOverflow
    //     0xd49a48: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd49a4c: cmp             SP, x16
    //     0xd49a50: b.ls            #0xd49a78
    // 0xd49a54: LoadField: r0 = r1->field_f
    //     0xd49a54: ldur            w0, [x1, #0xf]
    // 0xd49a58: DecompressPointer r0
    //     0xd49a58: add             x0, x0, HEAP, lsl #32
    // 0xd49a5c: mov             x1, x0
    // 0xd49a60: r2 = false
    //     0xd49a60: add             x2, NULL, #0x30  ; false
    // 0xd49a64: r0 = _handleHover()
    //     0xd49a64: bl              #0xd49a80  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_handleHover
    // 0xd49a68: r0 = Null
    //     0xd49a68: mov             x0, NULL
    // 0xd49a6c: LeaveFrame
    //     0xd49a6c: mov             SP, fp
    //     0xd49a70: ldp             fp, lr, [SP], #0x10
    // 0xd49a74: ret
    //     0xd49a74: ret             
    // 0xd49a78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd49a78: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd49a7c: b               #0xd49a54
  }
  _ _handleHover(/* No info */) {
    // ** addr: 0xd49a80, size: 0xc0
    // 0xd49a80: EnterFrame
    //     0xd49a80: stp             fp, lr, [SP, #-0x10]!
    //     0xd49a84: mov             fp, SP
    // 0xd49a88: AllocStack(0x10)
    //     0xd49a88: sub             SP, SP, #0x10
    // 0xd49a8c: SetupParameters(_TextFieldState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xd49a8c: stur            x1, [fp, #-8]
    //     0xd49a90: stur            x2, [fp, #-0x10]
    // 0xd49a94: CheckStackOverflow
    //     0xd49a94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd49a98: cmp             SP, x16
    //     0xd49a9c: b.ls            #0xd49b30
    // 0xd49aa0: r1 = 2
    //     0xd49aa0: mov             x1, #2
    // 0xd49aa4: r0 = AllocateContext()
    //     0xd49aa4: bl              #0x13de838  ; AllocateContextStub
    // 0xd49aa8: mov             x1, x0
    // 0xd49aac: ldur            x0, [fp, #-8]
    // 0xd49ab0: StoreField: r1->field_f = r0
    //     0xd49ab0: stur            w0, [x1, #0xf]
    // 0xd49ab4: ldur            x2, [fp, #-0x10]
    // 0xd49ab8: StoreField: r1->field_13 = r2
    //     0xd49ab8: stur            w2, [x1, #0x13]
    // 0xd49abc: LoadField: r3 = r0->field_2b
    //     0xd49abc: ldur            w3, [x0, #0x2b]
    // 0xd49ac0: DecompressPointer r3
    //     0xd49ac0: add             x3, x3, HEAP, lsl #32
    // 0xd49ac4: cmp             w2, w3
    // 0xd49ac8: b.eq            #0xd49b20
    // 0xd49acc: mov             x2, x1
    // 0xd49ad0: r1 = Function '<anonymous closure>':.
    //     0xd49ad0: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f6d8] AnonymousClosure: (0xd49b40), in [package:flutter/src/material/text_field.dart] _TextFieldState::_handleHover (0xd49a80)
    //     0xd49ad4: ldr             x1, [x1, #0x6d8]
    // 0xd49ad8: r0 = AllocateClosure()
    //     0xd49ad8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd49adc: ldur            x1, [fp, #-8]
    // 0xd49ae0: mov             x2, x0
    // 0xd49ae4: r0 = setState()
    //     0xd49ae4: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xd49ae8: ldur            x0, [fp, #-8]
    // 0xd49aec: LoadField: r1 = r0->field_b
    //     0xd49aec: ldur            w1, [x0, #0xb]
    // 0xd49af0: DecompressPointer r1
    //     0xd49af0: add             x1, x1, HEAP, lsl #32
    // 0xd49af4: cmp             w1, NULL
    // 0xd49af8: b.eq            #0xd49b38
    // 0xd49afc: LoadField: r1 = r0->field_3f
    //     0xd49afc: ldur            w1, [x0, #0x3f]
    // 0xd49b00: DecompressPointer r1
    //     0xd49b00: add             x1, x1, HEAP, lsl #32
    // 0xd49b04: cmp             w1, NULL
    // 0xd49b08: b.eq            #0xd49b3c
    // 0xd49b0c: LoadField: r3 = r0->field_2b
    //     0xd49b0c: ldur            w3, [x0, #0x2b]
    // 0xd49b10: DecompressPointer r3
    //     0xd49b10: add             x3, x3, HEAP, lsl #32
    // 0xd49b14: r2 = Instance_WidgetState
    //     0xd49b14: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xd49b18: ldr             x2, [x2, #0xa50]
    // 0xd49b1c: r0 = update()
    //     0xd49b1c: bl              #0xd223e0  ; [package:flutter/src/widgets/widget_state.dart] WidgetStatesController::update
    // 0xd49b20: r0 = Null
    //     0xd49b20: mov             x0, NULL
    // 0xd49b24: LeaveFrame
    //     0xd49b24: mov             SP, fp
    //     0xd49b28: ldp             fp, lr, [SP], #0x10
    // 0xd49b2c: ret
    //     0xd49b2c: ret             
    // 0xd49b30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd49b30: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd49b34: b               #0xd49aa0
    // 0xd49b38: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd49b38: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd49b3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd49b3c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xd49b40, size: 0x28
    // 0xd49b40: ldr             x1, [SP]
    // 0xd49b44: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xd49b44: ldur            w2, [x1, #0x17]
    // 0xd49b48: DecompressPointer r2
    //     0xd49b48: add             x2, x2, HEAP, lsl #32
    // 0xd49b4c: LoadField: r1 = r2->field_f
    //     0xd49b4c: ldur            w1, [x2, #0xf]
    // 0xd49b50: DecompressPointer r1
    //     0xd49b50: add             x1, x1, HEAP, lsl #32
    // 0xd49b54: LoadField: r3 = r2->field_13
    //     0xd49b54: ldur            w3, [x2, #0x13]
    // 0xd49b58: DecompressPointer r3
    //     0xd49b58: add             x3, x3, HEAP, lsl #32
    // 0xd49b5c: StoreField: r1->field_2b = r3
    //     0xd49b5c: stur            w3, [x1, #0x2b]
    // 0xd49b60: r0 = Null
    //     0xd49b60: mov             x0, NULL
    // 0xd49b64: ret
    //     0xd49b64: ret             
  }
  [closure] void <anonymous closure>(dynamic, PointerEnterEvent) {
    // ** addr: 0xd49b68, size: 0x4c
    // 0xd49b68: EnterFrame
    //     0xd49b68: stp             fp, lr, [SP, #-0x10]!
    //     0xd49b6c: mov             fp, SP
    // 0xd49b70: ldr             x0, [fp, #0x18]
    // 0xd49b74: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd49b74: ldur            w1, [x0, #0x17]
    // 0xd49b78: DecompressPointer r1
    //     0xd49b78: add             x1, x1, HEAP, lsl #32
    // 0xd49b7c: CheckStackOverflow
    //     0xd49b7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd49b80: cmp             SP, x16
    //     0xd49b84: b.ls            #0xd49bac
    // 0xd49b88: LoadField: r0 = r1->field_f
    //     0xd49b88: ldur            w0, [x1, #0xf]
    // 0xd49b8c: DecompressPointer r0
    //     0xd49b8c: add             x0, x0, HEAP, lsl #32
    // 0xd49b90: mov             x1, x0
    // 0xd49b94: r2 = true
    //     0xd49b94: add             x2, NULL, #0x20  ; true
    // 0xd49b98: r0 = _handleHover()
    //     0xd49b98: bl              #0xd49a80  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_handleHover
    // 0xd49b9c: r0 = Null
    //     0xd49b9c: mov             x0, NULL
    // 0xd49ba0: LeaveFrame
    //     0xd49ba0: mov             SP, fp
    //     0xd49ba4: ldp             fp, lr, [SP], #0x10
    // 0xd49ba8: ret
    //     0xd49ba8: ret             
    // 0xd49bac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd49bac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd49bb0: b               #0xd49b88
  }
  [closure] Semantics <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0xd49bb4, size: 0x170
    // 0xd49bb4: EnterFrame
    //     0xd49bb4: stp             fp, lr, [SP, #-0x10]!
    //     0xd49bb8: mov             fp, SP
    // 0xd49bbc: AllocStack(0x88)
    //     0xd49bbc: sub             SP, SP, #0x88
    // 0xd49bc0: SetupParameters([dynamic _ /* r0 */])
    //     0xd49bc0: ldr             x0, [fp, #0x20]
    //     0xd49bc4: ldur            w2, [x0, #0x17]
    //     0xd49bc8: add             x2, x2, HEAP, lsl #32
    //     0xd49bcc: stur            x2, [fp, #-8]
    // 0xd49bd0: CheckStackOverflow
    //     0xd49bd0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd49bd4: cmp             SP, x16
    //     0xd49bd8: b.ls            #0xd49d18
    // 0xd49bdc: LoadField: r1 = r2->field_f
    //     0xd49bdc: ldur            w1, [x2, #0xf]
    // 0xd49be0: DecompressPointer r1
    //     0xd49be0: add             x1, x1, HEAP, lsl #32
    // 0xd49be4: r0 = _isEnabled()
    //     0xd49be4: bl              #0xd48c7c  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_isEnabled
    // 0xd49be8: ldur            x2, [fp, #-8]
    // 0xd49bec: stur            x0, [fp, #-0x18]
    // 0xd49bf0: LoadField: r3 = r2->field_23
    //     0xd49bf0: ldur            w3, [x2, #0x23]
    // 0xd49bf4: DecompressPointer r3
    //     0xd49bf4: add             x3, x3, HEAP, lsl #32
    // 0xd49bf8: stur            x3, [fp, #-0x10]
    // 0xd49bfc: LoadField: r1 = r2->field_f
    //     0xd49bfc: ldur            w1, [x2, #0xf]
    // 0xd49c00: DecompressPointer r1
    //     0xd49c00: add             x1, x1, HEAP, lsl #32
    // 0xd49c04: r0 = _currentLength()
    //     0xd49c04: bl              #0xd4939c  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_currentLength
    // 0xd49c08: mov             x3, x0
    // 0xd49c0c: ldur            x0, [fp, #-8]
    // 0xd49c10: stur            x3, [fp, #-0x28]
    // 0xd49c14: LoadField: r4 = r0->field_f
    //     0xd49c14: ldur            w4, [x0, #0xf]
    // 0xd49c18: DecompressPointer r4
    //     0xd49c18: add             x4, x4, HEAP, lsl #32
    // 0xd49c1c: stur            x4, [fp, #-0x20]
    // 0xd49c20: LoadField: r1 = r4->field_b
    //     0xd49c20: ldur            w1, [x4, #0xb]
    // 0xd49c24: DecompressPointer r1
    //     0xd49c24: add             x1, x1, HEAP, lsl #32
    // 0xd49c28: cmp             w1, NULL
    // 0xd49c2c: b.eq            #0xd49d20
    // 0xd49c30: LoadField: r2 = r1->field_6b
    //     0xd49c30: ldur            w2, [x1, #0x6b]
    // 0xd49c34: DecompressPointer r2
    //     0xd49c34: add             x2, x2, HEAP, lsl #32
    // 0xd49c38: tbnz            w2, #4, #0xd49c48
    // 0xd49c3c: mov             x2, x0
    // 0xd49c40: r0 = Null
    //     0xd49c40: mov             x0, NULL
    // 0xd49c44: b               #0xd49c5c
    // 0xd49c48: mov             x2, x0
    // 0xd49c4c: r1 = Function '<anonymous closure>':.
    //     0xd49c4c: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f6e0] AnonymousClosure: (0xd49e68), in [package:flutter/src/material/text_field.dart] _TextFieldState::build (0xd455b4)
    //     0xd49c50: ldr             x1, [x1, #0x6e0]
    // 0xd49c54: r0 = AllocateClosure()
    //     0xd49c54: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd49c58: ldur            x2, [fp, #-8]
    // 0xd49c5c: stur            x0, [fp, #-0x40]
    // 0xd49c60: LoadField: r3 = r2->field_1b
    //     0xd49c60: ldur            w3, [x2, #0x1b]
    // 0xd49c64: DecompressPointer r3
    //     0xd49c64: add             x3, x3, HEAP, lsl #32
    // 0xd49c68: stur            x3, [fp, #-0x38]
    // 0xd49c6c: LoadField: r4 = r2->field_1f
    //     0xd49c6c: ldur            w4, [x2, #0x1f]
    // 0xd49c70: DecompressPointer r4
    //     0xd49c70: add             x4, x4, HEAP, lsl #32
    // 0xd49c74: ldur            x1, [fp, #-0x20]
    // 0xd49c78: stur            x4, [fp, #-0x30]
    // 0xd49c7c: r0 = _isEnabled()
    //     0xd49c7c: bl              #0xd48c7c  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_isEnabled
    // 0xd49c80: tbnz            w0, #4, #0xd49c9c
    // 0xd49c84: ldur            x2, [fp, #-8]
    // 0xd49c88: r1 = Function '<anonymous closure>':.
    //     0xd49c88: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f6e8] AnonymousClosure: (0xd49d24), in [package:flutter/src/material/text_field.dart] _TextFieldState::build (0xd455b4)
    //     0xd49c8c: ldr             x1, [x1, #0x6e8]
    // 0xd49c90: r0 = AllocateClosure()
    //     0xd49c90: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd49c94: mov             x3, x0
    // 0xd49c98: b               #0xd49ca0
    // 0xd49c9c: r3 = Null
    //     0xd49c9c: mov             x3, NULL
    // 0xd49ca0: ldur            x2, [fp, #-0x28]
    // 0xd49ca4: stur            x3, [fp, #-0x20]
    // 0xd49ca8: r0 = BoxInt64Instr(r2)
    //     0xd49ca8: sbfiz           x0, x2, #1, #0x1f
    //     0xd49cac: cmp             x2, x0, asr #1
    //     0xd49cb0: b.eq            #0xd49cbc
    //     0xd49cb4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xd49cb8: stur            x2, [x0, #7]
    // 0xd49cbc: stur            x0, [fp, #-8]
    // 0xd49cc0: r0 = Semantics()
    //     0xd49cc0: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xd49cc4: stur            x0, [fp, #-0x48]
    // 0xd49cc8: ldur            x16, [fp, #-0x18]
    // 0xd49ccc: ldur            lr, [fp, #-0x10]
    // 0xd49cd0: stp             lr, x16, [SP, #0x30]
    // 0xd49cd4: ldur            x16, [fp, #-8]
    // 0xd49cd8: ldur            lr, [fp, #-0x40]
    // 0xd49cdc: stp             lr, x16, [SP, #0x20]
    // 0xd49ce0: ldur            x16, [fp, #-0x38]
    // 0xd49ce4: ldur            lr, [fp, #-0x30]
    // 0xd49ce8: stp             lr, x16, [SP, #0x10]
    // 0xd49cec: ldur            x16, [fp, #-0x20]
    // 0xd49cf0: ldr             lr, [fp, #0x10]
    // 0xd49cf4: stp             lr, x16, [SP]
    // 0xd49cf8: mov             x1, x0
    // 0xd49cfc: r4 = const [0, 0x9, 0x8, 0x1, child, 0x8, currentValueLength, 0x3, enabled, 0x1, maxValueLength, 0x2, onDidGainAccessibilityFocus, 0x5, onDidLoseAccessibilityFocus, 0x6, onFocus, 0x7, onTap, 0x4, null]
    //     0xd49cfc: add             x4, PP, #0x8f, lsl #12  ; [pp+0x8f6f0] List(21) [0, 0x9, 0x8, 0x1, "child", 0x8, "currentValueLength", 0x3, "enabled", 0x1, "maxValueLength", 0x2, "onDidGainAccessibilityFocus", 0x5, "onDidLoseAccessibilityFocus", 0x6, "onFocus", 0x7, "onTap", 0x4, Null]
    //     0xd49d00: ldr             x4, [x4, #0x6f0]
    // 0xd49d04: r0 = Semantics()
    //     0xd49d04: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xd49d08: ldur            x0, [fp, #-0x48]
    // 0xd49d0c: LeaveFrame
    //     0xd49d0c: mov             SP, fp
    //     0xd49d10: ldp             fp, lr, [SP], #0x10
    // 0xd49d14: ret
    //     0xd49d14: ret             
    // 0xd49d18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd49d18: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd49d1c: b               #0xd49bdc
    // 0xd49d20: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd49d20: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xd49d24, size: 0xcc
    // 0xd49d24: EnterFrame
    //     0xd49d24: stp             fp, lr, [SP, #-0x10]!
    //     0xd49d28: mov             fp, SP
    // 0xd49d2c: AllocStack(0x8)
    //     0xd49d2c: sub             SP, SP, #8
    // 0xd49d30: SetupParameters([dynamic _ /* r0 */])
    //     0xd49d30: ldr             x0, [fp, #0x10]
    //     0xd49d34: ldur            w2, [x0, #0x17]
    //     0xd49d38: add             x2, x2, HEAP, lsl #32
    //     0xd49d3c: stur            x2, [fp, #-8]
    // 0xd49d40: CheckStackOverflow
    //     0xd49d40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd49d44: cmp             SP, x16
    //     0xd49d48: b.ls            #0xd49de4
    // 0xd49d4c: LoadField: r1 = r2->field_f
    //     0xd49d4c: ldur            w1, [x2, #0xf]
    // 0xd49d50: DecompressPointer r1
    //     0xd49d50: add             x1, x1, HEAP, lsl #32
    // 0xd49d54: r0 = _effectiveFocusNode()
    //     0xd49d54: bl              #0xd49478  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_effectiveFocusNode
    // 0xd49d58: mov             x1, x0
    // 0xd49d5c: r0 = canRequestFocus()
    //     0xd49d5c: bl              #0x83fac0  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::canRequestFocus
    // 0xd49d60: tbnz            w0, #4, #0xd49da8
    // 0xd49d64: ldur            x0, [fp, #-8]
    // 0xd49d68: LoadField: r1 = r0->field_f
    //     0xd49d68: ldur            w1, [x0, #0xf]
    // 0xd49d6c: DecompressPointer r1
    //     0xd49d6c: add             x1, x1, HEAP, lsl #32
    // 0xd49d70: r0 = _effectiveFocusNode()
    //     0xd49d70: bl              #0xd49478  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_effectiveFocusNode
    // 0xd49d74: mov             x1, x0
    // 0xd49d78: r0 = hasFocus()
    //     0xd49d78: bl              #0x843d08  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::hasFocus
    // 0xd49d7c: tbz             w0, #4, #0xd49da0
    // 0xd49d80: ldur            x0, [fp, #-8]
    // 0xd49d84: LoadField: r1 = r0->field_f
    //     0xd49d84: ldur            w1, [x0, #0xf]
    // 0xd49d88: DecompressPointer r1
    //     0xd49d88: add             x1, x1, HEAP, lsl #32
    // 0xd49d8c: r0 = _effectiveFocusNode()
    //     0xd49d8c: bl              #0xd49478  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_effectiveFocusNode
    // 0xd49d90: mov             x1, x0
    // 0xd49d94: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd49d94: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd49d98: r0 = requestFocus()
    //     0xd49d98: bl              #0x83e7b8  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::requestFocus
    // 0xd49d9c: b               #0xd49dd4
    // 0xd49da0: ldur            x0, [fp, #-8]
    // 0xd49da4: b               #0xd49dac
    // 0xd49da8: ldur            x0, [fp, #-8]
    // 0xd49dac: LoadField: r1 = r0->field_f
    //     0xd49dac: ldur            w1, [x0, #0xf]
    // 0xd49db0: DecompressPointer r1
    //     0xd49db0: add             x1, x1, HEAP, lsl #32
    // 0xd49db4: LoadField: r0 = r1->field_b
    //     0xd49db4: ldur            w0, [x1, #0xb]
    // 0xd49db8: DecompressPointer r0
    //     0xd49db8: add             x0, x0, HEAP, lsl #32
    // 0xd49dbc: cmp             w0, NULL
    // 0xd49dc0: b.eq            #0xd49dec
    // 0xd49dc4: LoadField: r2 = r0->field_6b
    //     0xd49dc4: ldur            w2, [x0, #0x6b]
    // 0xd49dc8: DecompressPointer r2
    //     0xd49dc8: add             x2, x2, HEAP, lsl #32
    // 0xd49dcc: tbz             w2, #4, #0xd49dd4
    // 0xd49dd0: r0 = _requestKeyboard()
    //     0xd49dd0: bl              #0xd49df0  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_requestKeyboard
    // 0xd49dd4: r0 = Null
    //     0xd49dd4: mov             x0, NULL
    // 0xd49dd8: LeaveFrame
    //     0xd49dd8: mov             SP, fp
    //     0xd49ddc: ldp             fp, lr, [SP], #0x10
    // 0xd49de0: ret
    //     0xd49de0: ret             
    // 0xd49de4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd49de4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd49de8: b               #0xd49d4c
    // 0xd49dec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd49dec: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _requestKeyboard(/* No info */) {
    // ** addr: 0xd49df0, size: 0x40
    // 0xd49df0: EnterFrame
    //     0xd49df0: stp             fp, lr, [SP, #-0x10]!
    //     0xd49df4: mov             fp, SP
    // 0xd49df8: CheckStackOverflow
    //     0xd49df8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd49dfc: cmp             SP, x16
    //     0xd49e00: b.ls            #0xd49e28
    // 0xd49e04: r0 = _editableText()
    //     0xd49e04: bl              #0xd49e30  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_editableText
    // 0xd49e08: cmp             w0, NULL
    // 0xd49e0c: b.eq            #0xd49e18
    // 0xd49e10: mov             x1, x0
    // 0xd49e14: r0 = requestKeyboard()
    //     0xd49e14: bl              #0x87293c  ; [package:flutter/src/widgets/editable_text.dart] EditableTextState::requestKeyboard
    // 0xd49e18: r0 = Null
    //     0xd49e18: mov             x0, NULL
    // 0xd49e1c: LeaveFrame
    //     0xd49e1c: mov             SP, fp
    //     0xd49e20: ldp             fp, lr, [SP], #0x10
    // 0xd49e24: ret
    //     0xd49e24: ret             
    // 0xd49e28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd49e28: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd49e2c: b               #0xd49e04
  }
  get _ _editableText(/* No info */) {
    // ** addr: 0xd49e30, size: 0x38
    // 0xd49e30: EnterFrame
    //     0xd49e30: stp             fp, lr, [SP, #-0x10]!
    //     0xd49e34: mov             fp, SP
    // 0xd49e38: CheckStackOverflow
    //     0xd49e38: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd49e3c: cmp             SP, x16
    //     0xd49e40: b.ls            #0xd49e60
    // 0xd49e44: LoadField: r0 = r1->field_3b
    //     0xd49e44: ldur            w0, [x1, #0x3b]
    // 0xd49e48: DecompressPointer r0
    //     0xd49e48: add             x0, x0, HEAP, lsl #32
    // 0xd49e4c: mov             x1, x0
    // 0xd49e50: r0 = currentState()
    //     0xd49e50: bl              #0x8591f8  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0xd49e54: LeaveFrame
    //     0xd49e54: mov             SP, fp
    //     0xd49e58: ldp             fp, lr, [SP], #0x10
    // 0xd49e5c: ret
    //     0xd49e5c: ret             
    // 0xd49e60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd49e60: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd49e64: b               #0xd49e44
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xd49e68, size: 0xf8
    // 0xd49e68: EnterFrame
    //     0xd49e68: stp             fp, lr, [SP, #-0x10]!
    //     0xd49e6c: mov             fp, SP
    // 0xd49e70: AllocStack(0x18)
    //     0xd49e70: sub             SP, SP, #0x18
    // 0xd49e74: SetupParameters([dynamic _ /* r0 */])
    //     0xd49e74: ldr             x0, [fp, #0x10]
    //     0xd49e78: ldur            w2, [x0, #0x17]
    //     0xd49e7c: add             x2, x2, HEAP, lsl #32
    //     0xd49e80: stur            x2, [fp, #-8]
    // 0xd49e84: CheckStackOverflow
    //     0xd49e84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd49e88: cmp             SP, x16
    //     0xd49e8c: b.ls            #0xd49f58
    // 0xd49e90: LoadField: r1 = r2->field_f
    //     0xd49e90: ldur            w1, [x2, #0xf]
    // 0xd49e94: DecompressPointer r1
    //     0xd49e94: add             x1, x1, HEAP, lsl #32
    // 0xd49e98: r0 = _effectiveController()
    //     0xd49e98: bl              #0xd49538  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_effectiveController
    // 0xd49e9c: LoadField: r1 = r0->field_27
    //     0xd49e9c: ldur            w1, [x0, #0x27]
    // 0xd49ea0: DecompressPointer r1
    //     0xd49ea0: add             x1, x1, HEAP, lsl #32
    // 0xd49ea4: LoadField: r0 = r1->field_b
    //     0xd49ea4: ldur            w0, [x1, #0xb]
    // 0xd49ea8: DecompressPointer r0
    //     0xd49ea8: add             x0, x0, HEAP, lsl #32
    // 0xd49eac: LoadField: r1 = r0->field_7
    //     0xd49eac: ldur            x1, [x0, #7]
    // 0xd49eb0: tbnz            x1, #0x3f, #0xd49ebc
    // 0xd49eb4: LoadField: r1 = r0->field_f
    //     0xd49eb4: ldur            x1, [x0, #0xf]
    // 0xd49eb8: tbz             x1, #0x3f, #0xd49f38
    // 0xd49ebc: ldur            x0, [fp, #-8]
    // 0xd49ec0: LoadField: r1 = r0->field_f
    //     0xd49ec0: ldur            w1, [x0, #0xf]
    // 0xd49ec4: DecompressPointer r1
    //     0xd49ec4: add             x1, x1, HEAP, lsl #32
    // 0xd49ec8: r0 = _effectiveController()
    //     0xd49ec8: bl              #0xd49538  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_effectiveController
    // 0xd49ecc: mov             x2, x0
    // 0xd49ed0: ldur            x0, [fp, #-8]
    // 0xd49ed4: stur            x2, [fp, #-0x10]
    // 0xd49ed8: LoadField: r1 = r0->field_f
    //     0xd49ed8: ldur            w1, [x0, #0xf]
    // 0xd49edc: DecompressPointer r1
    //     0xd49edc: add             x1, x1, HEAP, lsl #32
    // 0xd49ee0: r0 = _effectiveController()
    //     0xd49ee0: bl              #0xd49538  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_effectiveController
    // 0xd49ee4: LoadField: r1 = r0->field_27
    //     0xd49ee4: ldur            w1, [x0, #0x27]
    // 0xd49ee8: DecompressPointer r1
    //     0xd49ee8: add             x1, x1, HEAP, lsl #32
    // 0xd49eec: LoadField: r0 = r1->field_7
    //     0xd49eec: ldur            w0, [x1, #7]
    // 0xd49ef0: DecompressPointer r0
    //     0xd49ef0: add             x0, x0, HEAP, lsl #32
    // 0xd49ef4: LoadField: r1 = r0->field_7
    //     0xd49ef4: ldur            w1, [x0, #7]
    // 0xd49ef8: stur            x1, [fp, #-0x18]
    // 0xd49efc: r0 = TextSelection()
    //     0xd49efc: bl              #0x861260  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0xd49f00: mov             x1, x0
    // 0xd49f04: r0 = Instance_TextAffinity
    //     0xd49f04: ldr             x0, [PP, #0x4bb0]  ; [pp+0x4bb0] Obj!TextAffinity@12c7361
    // 0xd49f08: StoreField: r1->field_27 = r0
    //     0xd49f08: stur            w0, [x1, #0x27]
    // 0xd49f0c: ldur            x0, [fp, #-0x18]
    // 0xd49f10: r2 = LoadInt32Instr(r0)
    //     0xd49f10: sbfx            x2, x0, #1, #0x1f
    // 0xd49f14: ArrayStore: r1[0] = r2  ; List_8
    //     0xd49f14: stur            x2, [x1, #0x17]
    // 0xd49f18: StoreField: r1->field_1f = r2
    //     0xd49f18: stur            x2, [x1, #0x1f]
    // 0xd49f1c: r0 = false
    //     0xd49f1c: add             x0, NULL, #0x30  ; false
    // 0xd49f20: StoreField: r1->field_2b = r0
    //     0xd49f20: stur            w0, [x1, #0x2b]
    // 0xd49f24: StoreField: r1->field_7 = r2
    //     0xd49f24: stur            x2, [x1, #7]
    // 0xd49f28: StoreField: r1->field_f = r2
    //     0xd49f28: stur            x2, [x1, #0xf]
    // 0xd49f2c: mov             x2, x1
    // 0xd49f30: ldur            x1, [fp, #-0x10]
    // 0xd49f34: r0 = selection=()
    //     0xd49f34: bl              #0x874cb0  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::selection=
    // 0xd49f38: ldur            x0, [fp, #-8]
    // 0xd49f3c: LoadField: r1 = r0->field_f
    //     0xd49f3c: ldur            w1, [x0, #0xf]
    // 0xd49f40: DecompressPointer r1
    //     0xd49f40: add             x1, x1, HEAP, lsl #32
    // 0xd49f44: r0 = _requestKeyboard()
    //     0xd49f44: bl              #0xd49df0  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_requestKeyboard
    // 0xd49f48: r0 = Null
    //     0xd49f48: mov             x0, NULL
    // 0xd49f4c: LeaveFrame
    //     0xd49f4c: mov             SP, fp
    //     0xd49f50: ldp             fp, lr, [SP], #0x10
    // 0xd49f54: ret
    //     0xd49f54: ret             
    // 0xd49f58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd49f58: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd49f5c: b               #0xd49e90
  }
  [closure] InputDecorator <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0xd49ff8, size: 0x15c
    // 0xd49ff8: EnterFrame
    //     0xd49ff8: stp             fp, lr, [SP, #-0x10]!
    //     0xd49ffc: mov             fp, SP
    // 0xd4a000: AllocStack(0x40)
    //     0xd4a000: sub             SP, SP, #0x40
    // 0xd4a004: SetupParameters([dynamic _ /* r0 */])
    //     0xd4a004: ldr             x0, [fp, #0x20]
    //     0xd4a008: ldur            w2, [x0, #0x17]
    //     0xd4a00c: add             x2, x2, HEAP, lsl #32
    //     0xd4a010: stur            x2, [fp, #-8]
    // 0xd4a014: CheckStackOverflow
    //     0xd4a014: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd4a018: cmp             SP, x16
    //     0xd4a01c: b.ls            #0xd4a144
    // 0xd4a020: LoadField: r1 = r2->field_f
    //     0xd4a020: ldur            w1, [x2, #0xf]
    // 0xd4a024: DecompressPointer r1
    //     0xd4a024: add             x1, x1, HEAP, lsl #32
    // 0xd4a028: r0 = _getEffectiveDecoration()
    //     0xd4a028: bl              #0xd48d70  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_getEffectiveDecoration
    // 0xd4a02c: mov             x2, x0
    // 0xd4a030: ldur            x0, [fp, #-8]
    // 0xd4a034: stur            x2, [fp, #-0x30]
    // 0xd4a038: LoadField: r1 = r0->field_f
    //     0xd4a038: ldur            w1, [x0, #0xf]
    // 0xd4a03c: DecompressPointer r1
    //     0xd4a03c: add             x1, x1, HEAP, lsl #32
    // 0xd4a040: LoadField: r3 = r1->field_b
    //     0xd4a040: ldur            w3, [x1, #0xb]
    // 0xd4a044: DecompressPointer r3
    //     0xd4a044: add             x3, x3, HEAP, lsl #32
    // 0xd4a048: cmp             w3, NULL
    // 0xd4a04c: b.eq            #0xd4a14c
    // 0xd4a050: LoadField: r4 = r3->field_2b
    //     0xd4a050: ldur            w4, [x3, #0x2b]
    // 0xd4a054: DecompressPointer r4
    //     0xd4a054: add             x4, x4, HEAP, lsl #32
    // 0xd4a058: stur            x4, [fp, #-0x28]
    // 0xd4a05c: LoadField: r5 = r3->field_33
    //     0xd4a05c: ldur            w5, [x3, #0x33]
    // 0xd4a060: DecompressPointer r5
    //     0xd4a060: add             x5, x5, HEAP, lsl #32
    // 0xd4a064: stur            x5, [fp, #-0x20]
    // 0xd4a068: LoadField: r6 = r3->field_37
    //     0xd4a068: ldur            w6, [x3, #0x37]
    // 0xd4a06c: DecompressPointer r6
    //     0xd4a06c: add             x6, x6, HEAP, lsl #32
    // 0xd4a070: stur            x6, [fp, #-0x18]
    // 0xd4a074: LoadField: r3 = r1->field_2b
    //     0xd4a074: ldur            w3, [x1, #0x2b]
    // 0xd4a078: DecompressPointer r3
    //     0xd4a078: add             x3, x3, HEAP, lsl #32
    // 0xd4a07c: stur            x3, [fp, #-0x10]
    // 0xd4a080: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd4a080: ldur            w1, [x0, #0x17]
    // 0xd4a084: DecompressPointer r1
    //     0xd4a084: add             x1, x1, HEAP, lsl #32
    // 0xd4a088: r0 = hasFocus()
    //     0xd4a088: bl              #0x843d08  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::hasFocus
    // 0xd4a08c: mov             x1, x0
    // 0xd4a090: ldur            x0, [fp, #-8]
    // 0xd4a094: stur            x1, [fp, #-0x40]
    // 0xd4a098: LoadField: r2 = r0->field_13
    //     0xd4a098: ldur            w2, [x0, #0x13]
    // 0xd4a09c: DecompressPointer r2
    //     0xd4a09c: add             x2, x2, HEAP, lsl #32
    // 0xd4a0a0: LoadField: r3 = r2->field_27
    //     0xd4a0a0: ldur            w3, [x2, #0x27]
    // 0xd4a0a4: DecompressPointer r3
    //     0xd4a0a4: add             x3, x3, HEAP, lsl #32
    // 0xd4a0a8: LoadField: r2 = r3->field_7
    //     0xd4a0a8: ldur            w2, [x3, #7]
    // 0xd4a0ac: DecompressPointer r2
    //     0xd4a0ac: add             x2, x2, HEAP, lsl #32
    // 0xd4a0b0: LoadField: r3 = r2->field_7
    //     0xd4a0b0: ldur            w3, [x2, #7]
    // 0xd4a0b4: cbz             w3, #0xd4a0c0
    // 0xd4a0b8: r2 = false
    //     0xd4a0b8: add             x2, NULL, #0x30  ; false
    // 0xd4a0bc: b               #0xd4a0c4
    // 0xd4a0c0: r2 = true
    //     0xd4a0c0: add             x2, NULL, #0x20  ; true
    // 0xd4a0c4: stur            x2, [fp, #-0x38]
    // 0xd4a0c8: LoadField: r3 = r0->field_f
    //     0xd4a0c8: ldur            w3, [x0, #0xf]
    // 0xd4a0cc: DecompressPointer r3
    //     0xd4a0cc: add             x3, x3, HEAP, lsl #32
    // 0xd4a0d0: LoadField: r0 = r3->field_b
    //     0xd4a0d0: ldur            w0, [x3, #0xb]
    // 0xd4a0d4: DecompressPointer r0
    //     0xd4a0d4: add             x0, x0, HEAP, lsl #32
    // 0xd4a0d8: cmp             w0, NULL
    // 0xd4a0dc: b.eq            #0xd4a150
    // 0xd4a0e0: LoadField: r3 = r0->field_67
    //     0xd4a0e0: ldur            w3, [x0, #0x67]
    // 0xd4a0e4: DecompressPointer r3
    //     0xd4a0e4: add             x3, x3, HEAP, lsl #32
    // 0xd4a0e8: stur            x3, [fp, #-8]
    // 0xd4a0ec: r0 = InputDecorator()
    //     0xd4a0ec: bl              #0xd1c908  ; AllocateInputDecoratorStub -> InputDecorator (size=0x30)
    // 0xd4a0f0: ldur            x1, [fp, #-0x30]
    // 0xd4a0f4: StoreField: r0->field_b = r1
    //     0xd4a0f4: stur            w1, [x0, #0xb]
    // 0xd4a0f8: ldur            x1, [fp, #-0x28]
    // 0xd4a0fc: StoreField: r0->field_f = r1
    //     0xd4a0fc: stur            w1, [x0, #0xf]
    // 0xd4a100: ldur            x1, [fp, #-0x20]
    // 0xd4a104: StoreField: r0->field_13 = r1
    //     0xd4a104: stur            w1, [x0, #0x13]
    // 0xd4a108: ldur            x1, [fp, #-0x18]
    // 0xd4a10c: ArrayStore: r0[0] = r1  ; List_4
    //     0xd4a10c: stur            w1, [x0, #0x17]
    // 0xd4a110: ldur            x1, [fp, #-0x40]
    // 0xd4a114: StoreField: r0->field_1b = r1
    //     0xd4a114: stur            w1, [x0, #0x1b]
    // 0xd4a118: ldur            x1, [fp, #-0x10]
    // 0xd4a11c: StoreField: r0->field_1f = r1
    //     0xd4a11c: stur            w1, [x0, #0x1f]
    // 0xd4a120: ldur            x1, [fp, #-8]
    // 0xd4a124: StoreField: r0->field_23 = r1
    //     0xd4a124: stur            w1, [x0, #0x23]
    // 0xd4a128: ldur            x1, [fp, #-0x38]
    // 0xd4a12c: StoreField: r0->field_27 = r1
    //     0xd4a12c: stur            w1, [x0, #0x27]
    // 0xd4a130: ldr             x1, [fp, #0x10]
    // 0xd4a134: StoreField: r0->field_2b = r1
    //     0xd4a134: stur            w1, [x0, #0x2b]
    // 0xd4a138: LeaveFrame
    //     0xd4a138: mov             SP, fp
    //     0xd4a13c: ldp             fp, lr, [SP], #0x10
    // 0xd4a140: ret
    //     0xd4a140: ret             
    // 0xd4a144: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd4a144: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd4a148: b               #0xd4a020
    // 0xd4a14c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd4a14c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd4a150: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd4a150: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleSelectionHandleTapped(dynamic) {
    // ** addr: 0xd4a154, size: 0x38
    // 0xd4a154: EnterFrame
    //     0xd4a154: stp             fp, lr, [SP, #-0x10]!
    //     0xd4a158: mov             fp, SP
    // 0xd4a15c: ldr             x0, [fp, #0x10]
    // 0xd4a160: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd4a160: ldur            w1, [x0, #0x17]
    // 0xd4a164: DecompressPointer r1
    //     0xd4a164: add             x1, x1, HEAP, lsl #32
    // 0xd4a168: CheckStackOverflow
    //     0xd4a168: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd4a16c: cmp             SP, x16
    //     0xd4a170: b.ls            #0xd4a184
    // 0xd4a174: r0 = _handleSelectionHandleTapped()
    //     0xd4a174: bl              #0xd4a18c  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_handleSelectionHandleTapped
    // 0xd4a178: LeaveFrame
    //     0xd4a178: mov             SP, fp
    //     0xd4a17c: ldp             fp, lr, [SP], #0x10
    // 0xd4a180: ret
    //     0xd4a180: ret             
    // 0xd4a184: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd4a184: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd4a188: b               #0xd4a174
  }
  _ _handleSelectionHandleTapped(/* No info */) {
    // ** addr: 0xd4a18c, size: 0x84
    // 0xd4a18c: EnterFrame
    //     0xd4a18c: stp             fp, lr, [SP, #-0x10]!
    //     0xd4a190: mov             fp, SP
    // 0xd4a194: AllocStack(0x8)
    //     0xd4a194: sub             SP, SP, #8
    // 0xd4a198: SetupParameters(_TextFieldState this /* r1 => r0, fp-0x8 */)
    //     0xd4a198: mov             x0, x1
    //     0xd4a19c: stur            x1, [fp, #-8]
    // 0xd4a1a0: CheckStackOverflow
    //     0xd4a1a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd4a1a4: cmp             SP, x16
    //     0xd4a1a8: b.ls            #0xd4a204
    // 0xd4a1ac: mov             x1, x0
    // 0xd4a1b0: r0 = _effectiveController()
    //     0xd4a1b0: bl              #0xd49538  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_effectiveController
    // 0xd4a1b4: LoadField: r1 = r0->field_27
    //     0xd4a1b4: ldur            w1, [x0, #0x27]
    // 0xd4a1b8: DecompressPointer r1
    //     0xd4a1b8: add             x1, x1, HEAP, lsl #32
    // 0xd4a1bc: LoadField: r0 = r1->field_b
    //     0xd4a1bc: ldur            w0, [x1, #0xb]
    // 0xd4a1c0: DecompressPointer r0
    //     0xd4a1c0: add             x0, x0, HEAP, lsl #32
    // 0xd4a1c4: LoadField: r1 = r0->field_7
    //     0xd4a1c4: ldur            x1, [x0, #7]
    // 0xd4a1c8: LoadField: r2 = r0->field_f
    //     0xd4a1c8: ldur            x2, [x0, #0xf]
    // 0xd4a1cc: cmp             x1, x2
    // 0xd4a1d0: b.ne            #0xd4a1f4
    // 0xd4a1d4: ldur            x0, [fp, #-8]
    // 0xd4a1d8: LoadField: r1 = r0->field_3b
    //     0xd4a1d8: ldur            w1, [x0, #0x3b]
    // 0xd4a1dc: DecompressPointer r1
    //     0xd4a1dc: add             x1, x1, HEAP, lsl #32
    // 0xd4a1e0: r0 = currentState()
    //     0xd4a1e0: bl              #0x8591f8  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0xd4a1e4: cmp             w0, NULL
    // 0xd4a1e8: b.eq            #0xd4a20c
    // 0xd4a1ec: mov             x1, x0
    // 0xd4a1f0: r0 = toggleToolbar()
    //     0xd4a1f0: bl              #0xd476b8  ; [package:flutter/src/widgets/editable_text.dart] EditableTextState::toggleToolbar
    // 0xd4a1f4: r0 = Null
    //     0xd4a1f4: mov             x0, NULL
    // 0xd4a1f8: LeaveFrame
    //     0xd4a1f8: mov             SP, fp
    //     0xd4a1fc: ldp             fp, lr, [SP], #0x10
    // 0xd4a200: ret
    //     0xd4a200: ret             
    // 0xd4a204: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd4a204: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd4a208: b               #0xd4a1ac
    // 0xd4a20c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd4a20c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleSelectionChanged(dynamic, TextSelection, SelectionChangedCause?) {
    // ** addr: 0xd4a210, size: 0x40
    // 0xd4a210: EnterFrame
    //     0xd4a210: stp             fp, lr, [SP, #-0x10]!
    //     0xd4a214: mov             fp, SP
    // 0xd4a218: ldr             x0, [fp, #0x20]
    // 0xd4a21c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd4a21c: ldur            w1, [x0, #0x17]
    // 0xd4a220: DecompressPointer r1
    //     0xd4a220: add             x1, x1, HEAP, lsl #32
    // 0xd4a224: CheckStackOverflow
    //     0xd4a224: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd4a228: cmp             SP, x16
    //     0xd4a22c: b.ls            #0xd4a248
    // 0xd4a230: ldr             x2, [fp, #0x18]
    // 0xd4a234: ldr             x3, [fp, #0x10]
    // 0xd4a238: r0 = _handleSelectionChanged()
    //     0xd4a238: bl              #0xd4a250  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_handleSelectionChanged
    // 0xd4a23c: LeaveFrame
    //     0xd4a23c: mov             SP, fp
    //     0xd4a240: ldp             fp, lr, [SP], #0x10
    // 0xd4a244: ret
    //     0xd4a244: ret             
    // 0xd4a248: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd4a248: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd4a24c: b               #0xd4a230
  }
  _ _handleSelectionChanged(/* No info */) {
    // ** addr: 0xd4a250, size: 0x164
    // 0xd4a250: EnterFrame
    //     0xd4a250: stp             fp, lr, [SP, #-0x10]!
    //     0xd4a254: mov             fp, SP
    // 0xd4a258: AllocStack(0x20)
    //     0xd4a258: sub             SP, SP, #0x20
    // 0xd4a25c: SetupParameters(_TextFieldState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */, dynamic _ /* r3 => r2, fp-0x18 */)
    //     0xd4a25c: mov             x0, x1
    //     0xd4a260: stur            x1, [fp, #-8]
    //     0xd4a264: mov             x1, x2
    //     0xd4a268: stur            x2, [fp, #-0x10]
    //     0xd4a26c: mov             x2, x3
    //     0xd4a270: stur            x3, [fp, #-0x18]
    // 0xd4a274: CheckStackOverflow
    //     0xd4a274: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd4a278: cmp             SP, x16
    //     0xd4a27c: b.ls            #0xd4a3a4
    // 0xd4a280: r1 = 2
    //     0xd4a280: mov             x1, #2
    // 0xd4a284: r0 = AllocateContext()
    //     0xd4a284: bl              #0x13de838  ; AllocateContextStub
    // 0xd4a288: mov             x3, x0
    // 0xd4a28c: ldur            x0, [fp, #-8]
    // 0xd4a290: stur            x3, [fp, #-0x20]
    // 0xd4a294: StoreField: r3->field_f = r0
    //     0xd4a294: stur            w0, [x3, #0xf]
    // 0xd4a298: mov             x1, x0
    // 0xd4a29c: ldur            x2, [fp, #-0x18]
    // 0xd4a2a0: r0 = _shouldShowSelectionHandles()
    //     0xd4a2a0: bl              #0xd4a3b4  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_shouldShowSelectionHandles
    // 0xd4a2a4: ldur            x2, [fp, #-0x20]
    // 0xd4a2a8: StoreField: r2->field_13 = r0
    //     0xd4a2a8: stur            w0, [x2, #0x13]
    // 0xd4a2ac: ldur            x3, [fp, #-8]
    // 0xd4a2b0: LoadField: r1 = r3->field_2f
    //     0xd4a2b0: ldur            w1, [x3, #0x2f]
    // 0xd4a2b4: DecompressPointer r1
    //     0xd4a2b4: add             x1, x1, HEAP, lsl #32
    // 0xd4a2b8: cmp             w0, w1
    // 0xd4a2bc: b.eq            #0xd4a2d8
    // 0xd4a2c0: r1 = Function '<anonymous closure>':.
    //     0xd4a2c0: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f718] AnonymousClosure: (0xd4a524), in [package:flutter/src/material/text_field.dart] _TextFieldState::_handleSelectionChanged (0xd4a250)
    //     0xd4a2c4: ldr             x1, [x1, #0x718]
    // 0xd4a2c8: r0 = AllocateClosure()
    //     0xd4a2c8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd4a2cc: ldur            x1, [fp, #-8]
    // 0xd4a2d0: mov             x2, x0
    // 0xd4a2d4: r0 = setState()
    //     0xd4a2d4: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xd4a2d8: ldur            x0, [fp, #-8]
    // 0xd4a2dc: ldur            x2, [fp, #-0x18]
    // 0xd4a2e0: LoadField: r1 = r0->field_f
    //     0xd4a2e0: ldur            w1, [x0, #0xf]
    // 0xd4a2e4: DecompressPointer r1
    //     0xd4a2e4: add             x1, x1, HEAP, lsl #32
    // 0xd4a2e8: cmp             w1, NULL
    // 0xd4a2ec: b.eq            #0xd4a3ac
    // 0xd4a2f0: r0 = of()
    //     0xd4a2f0: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd4a2f4: ldur            x0, [fp, #-0x18]
    // 0xd4a2f8: r16 = Instance_SelectionChangedCause
    //     0xd4a2f8: ldr             x16, [PP, #0x5300]  ; [pp+0x5300] Obj!SelectionChangedCause@12c36e1
    // 0xd4a2fc: cmp             w0, w16
    // 0xd4a300: b.ne            #0xd4a334
    // 0xd4a304: ldur            x2, [fp, #-8]
    // 0xd4a308: LoadField: r1 = r2->field_3b
    //     0xd4a308: ldur            w1, [x2, #0x3b]
    // 0xd4a30c: DecompressPointer r1
    //     0xd4a30c: add             x1, x1, HEAP, lsl #32
    // 0xd4a310: r0 = currentState()
    //     0xd4a310: bl              #0x8591f8  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0xd4a314: stur            x0, [fp, #-0x20]
    // 0xd4a318: cmp             w0, NULL
    // 0xd4a31c: b.eq            #0xd4a334
    // 0xd4a320: ldur            x1, [fp, #-0x10]
    // 0xd4a324: r0 = extent()
    //     0xd4a324: bl              #0x85fb94  ; [package:flutter/src/services/text_editing.dart] TextSelection::extent
    // 0xd4a328: ldur            x1, [fp, #-0x20]
    // 0xd4a32c: mov             x2, x0
    // 0xd4a330: r0 = bringIntoView()
    //     0xd4a330: bl              #0x86b880  ; [package:flutter/src/widgets/editable_text.dart] EditableTextState::bringIntoView
    // 0xd4a334: ldur            x0, [fp, #-8]
    // 0xd4a338: LoadField: r1 = r0->field_f
    //     0xd4a338: ldur            w1, [x0, #0xf]
    // 0xd4a33c: DecompressPointer r1
    //     0xd4a33c: add             x1, x1, HEAP, lsl #32
    // 0xd4a340: cmp             w1, NULL
    // 0xd4a344: b.eq            #0xd4a3b0
    // 0xd4a348: r0 = of()
    //     0xd4a348: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd4a34c: LoadField: r1 = r0->field_23
    //     0xd4a34c: ldur            w1, [x0, #0x23]
    // 0xd4a350: DecompressPointer r1
    //     0xd4a350: add             x1, x1, HEAP, lsl #32
    // 0xd4a354: LoadField: r0 = r1->field_7
    //     0xd4a354: ldur            x0, [x1, #7]
    // 0xd4a358: cmp             x0, #2
    // 0xd4a35c: b.le            #0xd4a394
    // 0xd4a360: ldur            x0, [fp, #-0x18]
    // 0xd4a364: r16 = Instance_SelectionChangedCause
    //     0xd4a364: ldr             x16, [PP, #0x52f8]  ; [pp+0x52f8] Obj!SelectionChangedCause@12c3701
    // 0xd4a368: cmp             w0, w16
    // 0xd4a36c: b.ne            #0xd4a394
    // 0xd4a370: ldur            x0, [fp, #-8]
    // 0xd4a374: LoadField: r1 = r0->field_3b
    //     0xd4a374: ldur            w1, [x0, #0x3b]
    // 0xd4a378: DecompressPointer r1
    //     0xd4a378: add             x1, x1, HEAP, lsl #32
    // 0xd4a37c: r0 = currentState()
    //     0xd4a37c: bl              #0x8591f8  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0xd4a380: cmp             w0, NULL
    // 0xd4a384: b.eq            #0xd4a394
    // 0xd4a388: mov             x1, x0
    // 0xd4a38c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd4a38c: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd4a390: r0 = hideToolbar()
    //     0xd4a390: bl              #0x877770  ; [package:flutter/src/widgets/editable_text.dart] EditableTextState::hideToolbar
    // 0xd4a394: r0 = Null
    //     0xd4a394: mov             x0, NULL
    // 0xd4a398: LeaveFrame
    //     0xd4a398: mov             SP, fp
    //     0xd4a39c: ldp             fp, lr, [SP], #0x10
    // 0xd4a3a0: ret
    //     0xd4a3a0: ret             
    // 0xd4a3a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd4a3a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd4a3a8: b               #0xd4a280
    // 0xd4a3ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd4a3ac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd4a3b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd4a3b0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _shouldShowSelectionHandles(/* No info */) {
    // ** addr: 0xd4a3b4, size: 0x170
    // 0xd4a3b4: EnterFrame
    //     0xd4a3b4: stp             fp, lr, [SP, #-0x10]!
    //     0xd4a3b8: mov             fp, SP
    // 0xd4a3bc: AllocStack(0x10)
    //     0xd4a3bc: sub             SP, SP, #0x10
    // 0xd4a3c0: SetupParameters(_TextFieldState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xd4a3c0: mov             x0, x1
    //     0xd4a3c4: stur            x1, [fp, #-8]
    //     0xd4a3c8: stur            x2, [fp, #-0x10]
    // 0xd4a3cc: CheckStackOverflow
    //     0xd4a3cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd4a3d0: cmp             SP, x16
    //     0xd4a3d4: b.ls            #0xd4a50c
    // 0xd4a3d8: LoadField: r1 = r0->field_33
    //     0xd4a3d8: ldur            w1, [x0, #0x33]
    // 0xd4a3dc: DecompressPointer r1
    //     0xd4a3dc: add             x1, x1, HEAP, lsl #32
    // 0xd4a3e0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd4a3e4: cmp             w1, w16
    // 0xd4a3e8: b.eq            #0xd4a514
    // 0xd4a3ec: LoadField: r3 = r1->field_b
    //     0xd4a3ec: ldur            w3, [x1, #0xb]
    // 0xd4a3f0: DecompressPointer r3
    //     0xd4a3f0: add             x3, x3, HEAP, lsl #32
    // 0xd4a3f4: tbnz            w3, #4, #0xd4a404
    // 0xd4a3f8: LoadField: r3 = r1->field_f
    //     0xd4a3f8: ldur            w3, [x1, #0xf]
    // 0xd4a3fc: DecompressPointer r3
    //     0xd4a3fc: add             x3, x3, HEAP, lsl #32
    // 0xd4a400: tbz             w3, #4, #0xd4a414
    // 0xd4a404: r0 = false
    //     0xd4a404: add             x0, NULL, #0x30  ; false
    // 0xd4a408: LeaveFrame
    //     0xd4a408: mov             SP, fp
    //     0xd4a40c: ldp             fp, lr, [SP], #0x10
    // 0xd4a410: ret
    //     0xd4a410: ret             
    // 0xd4a414: r16 = Instance_SelectionChangedCause
    //     0xd4a414: ldr             x16, [PP, #0x53c8]  ; [pp+0x53c8] Obj!SelectionChangedCause@12c3661
    // 0xd4a418: cmp             w2, w16
    // 0xd4a41c: b.ne            #0xd4a430
    // 0xd4a420: r0 = false
    //     0xd4a420: add             x0, NULL, #0x30  ; false
    // 0xd4a424: LeaveFrame
    //     0xd4a424: mov             SP, fp
    //     0xd4a428: ldp             fp, lr, [SP], #0x10
    // 0xd4a42c: ret
    //     0xd4a42c: ret             
    // 0xd4a430: LoadField: r1 = r0->field_b
    //     0xd4a430: ldur            w1, [x0, #0xb]
    // 0xd4a434: DecompressPointer r1
    //     0xd4a434: add             x1, x1, HEAP, lsl #32
    // 0xd4a438: cmp             w1, NULL
    // 0xd4a43c: b.eq            #0xd4a520
    // 0xd4a440: LoadField: r3 = r1->field_6b
    //     0xd4a440: ldur            w3, [x1, #0x6b]
    // 0xd4a444: DecompressPointer r3
    //     0xd4a444: add             x3, x3, HEAP, lsl #32
    // 0xd4a448: tbnz            w3, #4, #0xd4a484
    // 0xd4a44c: mov             x1, x0
    // 0xd4a450: r0 = _effectiveController()
    //     0xd4a450: bl              #0xd49538  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_effectiveController
    // 0xd4a454: LoadField: r1 = r0->field_27
    //     0xd4a454: ldur            w1, [x0, #0x27]
    // 0xd4a458: DecompressPointer r1
    //     0xd4a458: add             x1, x1, HEAP, lsl #32
    // 0xd4a45c: LoadField: r0 = r1->field_b
    //     0xd4a45c: ldur            w0, [x1, #0xb]
    // 0xd4a460: DecompressPointer r0
    //     0xd4a460: add             x0, x0, HEAP, lsl #32
    // 0xd4a464: LoadField: r1 = r0->field_7
    //     0xd4a464: ldur            x1, [x0, #7]
    // 0xd4a468: LoadField: r2 = r0->field_f
    //     0xd4a468: ldur            x2, [x0, #0xf]
    // 0xd4a46c: cmp             x1, x2
    // 0xd4a470: b.ne            #0xd4a484
    // 0xd4a474: r0 = false
    //     0xd4a474: add             x0, NULL, #0x30  ; false
    // 0xd4a478: LeaveFrame
    //     0xd4a478: mov             SP, fp
    //     0xd4a47c: ldp             fp, lr, [SP], #0x10
    // 0xd4a480: ret
    //     0xd4a480: ret             
    // 0xd4a484: ldur            x1, [fp, #-8]
    // 0xd4a488: r0 = _isEnabled()
    //     0xd4a488: bl              #0xd48c7c  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_isEnabled
    // 0xd4a48c: tbz             w0, #4, #0xd4a4a0
    // 0xd4a490: r0 = false
    //     0xd4a490: add             x0, NULL, #0x30  ; false
    // 0xd4a494: LeaveFrame
    //     0xd4a494: mov             SP, fp
    //     0xd4a498: ldp             fp, lr, [SP], #0x10
    // 0xd4a49c: ret
    //     0xd4a49c: ret             
    // 0xd4a4a0: ldur            x0, [fp, #-0x10]
    // 0xd4a4a4: r16 = Instance_SelectionChangedCause
    //     0xd4a4a4: ldr             x16, [PP, #0x5300]  ; [pp+0x5300] Obj!SelectionChangedCause@12c36e1
    // 0xd4a4a8: cmp             w0, w16
    // 0xd4a4ac: b.eq            #0xd4a4bc
    // 0xd4a4b0: r16 = Instance_SelectionChangedCause
    //     0xd4a4b0: ldr             x16, [PP, #0x5308]  ; [pp+0x5308] Obj!SelectionChangedCause@12c36c1
    // 0xd4a4b4: cmp             w0, w16
    // 0xd4a4b8: b.ne            #0xd4a4cc
    // 0xd4a4bc: r0 = true
    //     0xd4a4bc: add             x0, NULL, #0x20  ; true
    // 0xd4a4c0: LeaveFrame
    //     0xd4a4c0: mov             SP, fp
    //     0xd4a4c4: ldp             fp, lr, [SP], #0x10
    // 0xd4a4c8: ret
    //     0xd4a4c8: ret             
    // 0xd4a4cc: ldur            x1, [fp, #-8]
    // 0xd4a4d0: r0 = _effectiveController()
    //     0xd4a4d0: bl              #0xd49538  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_effectiveController
    // 0xd4a4d4: LoadField: r1 = r0->field_27
    //     0xd4a4d4: ldur            w1, [x0, #0x27]
    // 0xd4a4d8: DecompressPointer r1
    //     0xd4a4d8: add             x1, x1, HEAP, lsl #32
    // 0xd4a4dc: LoadField: r2 = r1->field_7
    //     0xd4a4dc: ldur            w2, [x1, #7]
    // 0xd4a4e0: DecompressPointer r2
    //     0xd4a4e0: add             x2, x2, HEAP, lsl #32
    // 0xd4a4e4: LoadField: r1 = r2->field_7
    //     0xd4a4e4: ldur            w1, [x2, #7]
    // 0xd4a4e8: cbz             w1, #0xd4a4fc
    // 0xd4a4ec: r0 = true
    //     0xd4a4ec: add             x0, NULL, #0x20  ; true
    // 0xd4a4f0: LeaveFrame
    //     0xd4a4f0: mov             SP, fp
    //     0xd4a4f4: ldp             fp, lr, [SP], #0x10
    // 0xd4a4f8: ret
    //     0xd4a4f8: ret             
    // 0xd4a4fc: r0 = false
    //     0xd4a4fc: add             x0, NULL, #0x30  ; false
    // 0xd4a500: LeaveFrame
    //     0xd4a500: mov             SP, fp
    //     0xd4a504: ldp             fp, lr, [SP], #0x10
    // 0xd4a508: ret
    //     0xd4a508: ret             
    // 0xd4a50c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd4a50c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd4a510: b               #0xd4a3d8
    // 0xd4a514: r9 = _selectionGestureDetectorBuilder
    //     0xd4a514: add             x9, PP, #0x8f, lsl #12  ; [pp+0x8f6d0] Field <_TextFieldState@130181401._selectionGestureDetectorBuilder@130181401>: late (offset: 0x34)
    //     0xd4a518: ldr             x9, [x9, #0x6d0]
    // 0xd4a51c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd4a51c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd4a520: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd4a520: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xd4a524, size: 0x28
    // 0xd4a524: ldr             x1, [SP]
    // 0xd4a528: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xd4a528: ldur            w2, [x1, #0x17]
    // 0xd4a52c: DecompressPointer r2
    //     0xd4a52c: add             x2, x2, HEAP, lsl #32
    // 0xd4a530: LoadField: r1 = r2->field_f
    //     0xd4a530: ldur            w1, [x2, #0xf]
    // 0xd4a534: DecompressPointer r1
    //     0xd4a534: add             x1, x1, HEAP, lsl #32
    // 0xd4a538: LoadField: r3 = r2->field_13
    //     0xd4a538: ldur            w3, [x2, #0x13]
    // 0xd4a53c: DecompressPointer r3
    //     0xd4a53c: add             x3, x3, HEAP, lsl #32
    // 0xd4a540: StoreField: r1->field_2f = r3
    //     0xd4a540: stur            w3, [x1, #0x2f]
    // 0xd4a544: r0 = Null
    //     0xd4a544: mov             x0, NULL
    // 0xd4a548: ret
    //     0xd4a548: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xd4a5f0, size: 0x54
    // 0xd4a5f0: EnterFrame
    //     0xd4a5f0: stp             fp, lr, [SP, #-0x10]!
    //     0xd4a5f4: mov             fp, SP
    // 0xd4a5f8: ldr             x0, [fp, #0x10]
    // 0xd4a5fc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd4a5fc: ldur            w1, [x0, #0x17]
    // 0xd4a600: DecompressPointer r1
    //     0xd4a600: add             x1, x1, HEAP, lsl #32
    // 0xd4a604: CheckStackOverflow
    //     0xd4a604: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd4a608: cmp             SP, x16
    //     0xd4a60c: b.ls            #0xd4a63c
    // 0xd4a610: LoadField: r0 = r1->field_f
    //     0xd4a610: ldur            w0, [x1, #0xf]
    // 0xd4a614: DecompressPointer r0
    //     0xd4a614: add             x0, x0, HEAP, lsl #32
    // 0xd4a618: mov             x1, x0
    // 0xd4a61c: r0 = _effectiveFocusNode()
    //     0xd4a61c: bl              #0xd49478  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_effectiveFocusNode
    // 0xd4a620: mov             x1, x0
    // 0xd4a624: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd4a624: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd4a628: r0 = unfocus()
    //     0xd4a628: bl              #0x83f51c  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::unfocus
    // 0xd4a62c: r0 = Null
    //     0xd4a62c: mov             x0, NULL
    // 0xd4a630: LeaveFrame
    //     0xd4a630: mov             SP, fp
    //     0xd4a634: ldp             fp, lr, [SP], #0x10
    // 0xd4a638: ret
    //     0xd4a638: ret             
    // 0xd4a63c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd4a63c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd4a640: b               #0xd4a610
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xd4a644, size: 0x90
    // 0xd4a644: EnterFrame
    //     0xd4a644: stp             fp, lr, [SP, #-0x10]!
    //     0xd4a648: mov             fp, SP
    // 0xd4a64c: AllocStack(0x8)
    //     0xd4a64c: sub             SP, SP, #8
    // 0xd4a650: SetupParameters([dynamic _ /* r0 */])
    //     0xd4a650: ldr             x0, [fp, #0x10]
    //     0xd4a654: ldur            w2, [x0, #0x17]
    //     0xd4a658: add             x2, x2, HEAP, lsl #32
    //     0xd4a65c: stur            x2, [fp, #-8]
    // 0xd4a660: CheckStackOverflow
    //     0xd4a660: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd4a664: cmp             SP, x16
    //     0xd4a668: b.ls            #0xd4a6cc
    // 0xd4a66c: LoadField: r1 = r2->field_f
    //     0xd4a66c: ldur            w1, [x2, #0xf]
    // 0xd4a670: DecompressPointer r1
    //     0xd4a670: add             x1, x1, HEAP, lsl #32
    // 0xd4a674: r0 = _effectiveFocusNode()
    //     0xd4a674: bl              #0xd49478  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_effectiveFocusNode
    // 0xd4a678: mov             x1, x0
    // 0xd4a67c: r0 = hasFocus()
    //     0xd4a67c: bl              #0x843d08  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::hasFocus
    // 0xd4a680: tbz             w0, #4, #0xd4a6bc
    // 0xd4a684: ldur            x0, [fp, #-8]
    // 0xd4a688: LoadField: r1 = r0->field_f
    //     0xd4a688: ldur            w1, [x0, #0xf]
    // 0xd4a68c: DecompressPointer r1
    //     0xd4a68c: add             x1, x1, HEAP, lsl #32
    // 0xd4a690: r0 = _effectiveFocusNode()
    //     0xd4a690: bl              #0xd49478  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_effectiveFocusNode
    // 0xd4a694: mov             x1, x0
    // 0xd4a698: r0 = canRequestFocus()
    //     0xd4a698: bl              #0x83fac0  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::canRequestFocus
    // 0xd4a69c: tbnz            w0, #4, #0xd4a6bc
    // 0xd4a6a0: ldur            x0, [fp, #-8]
    // 0xd4a6a4: LoadField: r1 = r0->field_f
    //     0xd4a6a4: ldur            w1, [x0, #0xf]
    // 0xd4a6a8: DecompressPointer r1
    //     0xd4a6a8: add             x1, x1, HEAP, lsl #32
    // 0xd4a6ac: r0 = _effectiveFocusNode()
    //     0xd4a6ac: bl              #0xd49478  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_effectiveFocusNode
    // 0xd4a6b0: mov             x1, x0
    // 0xd4a6b4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd4a6b4: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd4a6b8: r0 = requestFocus()
    //     0xd4a6b8: bl              #0x83e7b8  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::requestFocus
    // 0xd4a6bc: r0 = Null
    //     0xd4a6bc: mov             x0, NULL
    // 0xd4a6c0: LeaveFrame
    //     0xd4a6c0: mov             SP, fp
    //     0xd4a6c4: ldp             fp, lr, [SP], #0x10
    // 0xd4a6c8: ret
    //     0xd4a6c8: ret             
    // 0xd4a6cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd4a6cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd4a6d0: b               #0xd4a66c
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0xeeee18, size: 0x60
    // 0xeeee18: EnterFrame
    //     0xeeee18: stp             fp, lr, [SP, #-0x10]!
    //     0xeeee1c: mov             fp, SP
    // 0xeeee20: AllocStack(0x8)
    //     0xeeee20: sub             SP, SP, #8
    // 0xeeee24: SetupParameters(_TextFieldState this /* r1 => r0, fp-0x8 */)
    //     0xeeee24: mov             x0, x1
    //     0xeeee28: stur            x1, [fp, #-8]
    // 0xeeee2c: CheckStackOverflow
    //     0xeeee2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeeee30: cmp             SP, x16
    //     0xeeee34: b.ls            #0xeeee70
    // 0xeeee38: mov             x1, x0
    // 0xeeee3c: r0 = didChangeDependencies()
    //     0xeeee3c: bl              #0xeeef30  ; [dart:mixin_deduplication] _MixinApplication114&State&RestorationMixin::didChangeDependencies
    // 0xeeee40: ldur            x1, [fp, #-8]
    // 0xeeee44: r0 = _effectiveFocusNode()
    //     0xeeee44: bl              #0xd49478  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_effectiveFocusNode
    // 0xeeee48: ldur            x1, [fp, #-8]
    // 0xeeee4c: stur            x0, [fp, #-8]
    // 0xeeee50: r0 = _canRequestFocus()
    //     0xeeee50: bl              #0xeeee78  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_canRequestFocus
    // 0xeeee54: ldur            x1, [fp, #-8]
    // 0xeeee58: mov             x2, x0
    // 0xeeee5c: r0 = canRequestFocus=()
    //     0xeeee5c: bl              #0xe0d7f0  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::canRequestFocus=
    // 0xeeee60: r0 = Null
    //     0xeeee60: mov             x0, NULL
    // 0xeeee64: LeaveFrame
    //     0xeeee64: mov             SP, fp
    //     0xeeee68: ldp             fp, lr, [SP], #0x10
    // 0xeeee6c: ret
    //     0xeeee6c: ret             
    // 0xeeee70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeeee70: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeeee74: b               #0xeeee38
  }
  get _ _canRequestFocus(/* No info */) {
    // ** addr: 0xeeee78, size: 0xb8
    // 0xeeee78: EnterFrame
    //     0xeeee78: stp             fp, lr, [SP, #-0x10]!
    //     0xeeee7c: mov             fp, SP
    // 0xeeee80: AllocStack(0x8)
    //     0xeeee80: sub             SP, SP, #8
    // 0xeeee84: SetupParameters(_TextFieldState this /* r1 => r0, fp-0x8 */)
    //     0xeeee84: mov             x0, x1
    //     0xeeee88: stur            x1, [fp, #-8]
    // 0xeeee8c: CheckStackOverflow
    //     0xeeee8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeeee90: cmp             SP, x16
    //     0xeeee94: b.ls            #0xeeef20
    // 0xeeee98: LoadField: r1 = r0->field_f
    //     0xeeee98: ldur            w1, [x0, #0xf]
    // 0xeeee9c: DecompressPointer r1
    //     0xeeee9c: add             x1, x1, HEAP, lsl #32
    // 0xeeeea0: cmp             w1, NULL
    // 0xeeeea4: b.eq            #0xeeef28
    // 0xeeeea8: r0 = maybeNavigationModeOf()
    //     0xeeeea8: bl              #0xd20b74  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::maybeNavigationModeOf
    // 0xeeeeac: cmp             w0, NULL
    // 0xeeeeb0: b.ne            #0xeeeec0
    // 0xeeeeb4: r1 = Instance_NavigationMode
    //     0xeeeeb4: add             x1, PP, #0x12, lsl #12  ; [pp+0x12858] Obj!NavigationMode@12c2ba1
    //     0xeeeeb8: ldr             x1, [x1, #0x858]
    // 0xeeeebc: b               #0xeeeec4
    // 0xeeeec0: mov             x1, x0
    // 0xeeeec4: LoadField: r2 = r1->field_7
    //     0xeeeec4: ldur            x2, [x1, #7]
    // 0xeeeec8: cmp             x2, #0
    // 0xeeeecc: b.gt            #0xeeef10
    // 0xeeeed0: ldur            x1, [fp, #-8]
    // 0xeeeed4: LoadField: r2 = r1->field_b
    //     0xeeeed4: ldur            w2, [x1, #0xb]
    // 0xeeeed8: DecompressPointer r2
    //     0xeeeed8: add             x2, x2, HEAP, lsl #32
    // 0xeeeedc: cmp             w2, NULL
    // 0xeeeee0: b.eq            #0xeeef2c
    // 0xeeeee4: LoadField: r1 = r2->field_93
    //     0xeeeee4: ldur            w1, [x2, #0x93]
    // 0xeeeee8: DecompressPointer r1
    //     0xeeeee8: add             x1, x1, HEAP, lsl #32
    // 0xeeeeec: cmp             w1, NULL
    // 0xeeeef0: b.ne            #0xeeef08
    // 0xeeeef4: LoadField: r3 = r2->field_1b
    //     0xeeeef4: ldur            w3, [x2, #0x1b]
    // 0xeeeef8: DecompressPointer r3
    //     0xeeeef8: add             x3, x3, HEAP, lsl #32
    // 0xeeeefc: LoadField: r2 = r3->field_db
    //     0xeeeefc: ldur            w2, [x3, #0xdb]
    // 0xeeef00: DecompressPointer r2
    //     0xeeef00: add             x2, x2, HEAP, lsl #32
    // 0xeeef04: mov             x1, x2
    // 0xeeef08: mov             x0, x1
    // 0xeeef0c: b               #0xeeef14
    // 0xeeef10: r0 = true
    //     0xeeef10: add             x0, NULL, #0x20  ; true
    // 0xeeef14: LeaveFrame
    //     0xeeef14: mov             SP, fp
    //     0xeeef18: ldp             fp, lr, [SP], #0x10
    // 0xeeef1c: ret
    //     0xeeef1c: ret             
    // 0xeeef20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeeef20: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeeef24: b               #0xeeee98
    // 0xeeef28: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xeeef28: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xeeef2c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xeeef2c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf3dfbc, size: 0x460
    // 0xf3dfbc: EnterFrame
    //     0xf3dfbc: stp             fp, lr, [SP, #-0x10]!
    //     0xf3dfc0: mov             fp, SP
    // 0xf3dfc4: AllocStack(0x20)
    //     0xf3dfc4: sub             SP, SP, #0x20
    // 0xf3dfc8: SetupParameters(_TextFieldState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xf3dfc8: mov             x4, x1
    //     0xf3dfcc: mov             x3, x2
    //     0xf3dfd0: stur            x1, [fp, #-8]
    //     0xf3dfd4: stur            x2, [fp, #-0x10]
    // 0xf3dfd8: CheckStackOverflow
    //     0xf3dfd8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3dfdc: cmp             SP, x16
    //     0xf3dfe0: b.ls            #0xf3e3d8
    // 0xf3dfe4: mov             x0, x3
    // 0xf3dfe8: r2 = Null
    //     0xf3dfe8: mov             x2, NULL
    // 0xf3dfec: r1 = Null
    //     0xf3dfec: mov             x1, NULL
    // 0xf3dff0: r4 = 60
    //     0xf3dff0: mov             x4, #0x3c
    // 0xf3dff4: branchIfSmi(r0, 0xf3e000)
    //     0xf3dff4: tbz             w0, #0, #0xf3e000
    // 0xf3dff8: r4 = LoadClassIdInstr(r0)
    //     0xf3dff8: ldur            x4, [x0, #-1]
    //     0xf3dffc: ubfx            x4, x4, #0xc, #0x14
    // 0xf3e000: r17 = 6414
    //     0xf3e000: mov             x17, #0x190e
    // 0xf3e004: cmp             x4, x17
    // 0xf3e008: b.eq            #0xf3e020
    // 0xf3e00c: r8 = TextField
    //     0xf3e00c: add             x8, PP, #0x8f, lsl #12  ; [pp+0x8f930] Type: TextField
    //     0xf3e010: ldr             x8, [x8, #0x930]
    // 0xf3e014: r3 = Null
    //     0xf3e014: add             x3, PP, #0x8f, lsl #12  ; [pp+0x8f938] Null
    //     0xf3e018: ldr             x3, [x3, #0x938]
    // 0xf3e01c: r0 = TextField()
    //     0xf3e01c: bl              #0xd467c8  ; IsType_TextField_Stub
    // 0xf3e020: ldur            x1, [fp, #-8]
    // 0xf3e024: ldur            x2, [fp, #-0x10]
    // 0xf3e028: r0 = didUpdateWidget()
    //     0xf3e028: bl              #0xf3e6d8  ; [dart:mixin_deduplication] _MixinApplication114&State&RestorationMixin::didUpdateWidget
    // 0xf3e02c: ldur            x0, [fp, #-8]
    // 0xf3e030: LoadField: r1 = r0->field_b
    //     0xf3e030: ldur            w1, [x0, #0xb]
    // 0xf3e034: DecompressPointer r1
    //     0xf3e034: add             x1, x1, HEAP, lsl #32
    // 0xf3e038: cmp             w1, NULL
    // 0xf3e03c: b.eq            #0xf3e3e0
    // 0xf3e040: LoadField: r2 = r1->field_13
    //     0xf3e040: ldur            w2, [x1, #0x13]
    // 0xf3e044: DecompressPointer r2
    //     0xf3e044: add             x2, x2, HEAP, lsl #32
    // 0xf3e048: cmp             w2, NULL
    // 0xf3e04c: b.ne            #0xf3e084
    // 0xf3e050: ldur            x3, [fp, #-0x10]
    // 0xf3e054: LoadField: r1 = r3->field_13
    //     0xf3e054: ldur            w1, [x3, #0x13]
    // 0xf3e058: DecompressPointer r1
    //     0xf3e058: add             x1, x1, HEAP, lsl #32
    // 0xf3e05c: cmp             w1, NULL
    // 0xf3e060: b.eq            #0xf3e084
    // 0xf3e064: LoadField: r2 = r1->field_27
    //     0xf3e064: ldur            w2, [x1, #0x27]
    // 0xf3e068: DecompressPointer r2
    //     0xf3e068: add             x2, x2, HEAP, lsl #32
    // 0xf3e06c: str             x2, [SP]
    // 0xf3e070: mov             x1, x0
    // 0xf3e074: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0xf3e074: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0xf3e078: r0 = _createLocalController()
    //     0xf3e078: bl              #0xf3e41c  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_createLocalController
    // 0xf3e07c: ldur            x0, [fp, #-8]
    // 0xf3e080: b               #0xf3e0ec
    // 0xf3e084: cmp             w2, NULL
    // 0xf3e088: b.eq            #0xf3e0e8
    // 0xf3e08c: ldur            x0, [fp, #-0x10]
    // 0xf3e090: LoadField: r1 = r0->field_13
    //     0xf3e090: ldur            w1, [x0, #0x13]
    // 0xf3e094: DecompressPointer r1
    //     0xf3e094: add             x1, x1, HEAP, lsl #32
    // 0xf3e098: cmp             w1, NULL
    // 0xf3e09c: b.ne            #0xf3e0e0
    // 0xf3e0a0: ldur            x3, [fp, #-8]
    // 0xf3e0a4: LoadField: r2 = r3->field_23
    //     0xf3e0a4: ldur            w2, [x3, #0x23]
    // 0xf3e0a8: DecompressPointer r2
    //     0xf3e0a8: add             x2, x2, HEAP, lsl #32
    // 0xf3e0ac: cmp             w2, NULL
    // 0xf3e0b0: b.eq            #0xf3e3e4
    // 0xf3e0b4: mov             x1, x3
    // 0xf3e0b8: r0 = _unregister()
    //     0xf3e0b8: bl              #0x1185af4  ; [dart:mixin_deduplication] _MixinApplication114&State&RestorationMixin::_unregister
    // 0xf3e0bc: ldur            x2, [fp, #-8]
    // 0xf3e0c0: LoadField: r1 = r2->field_23
    //     0xf3e0c0: ldur            w1, [x2, #0x23]
    // 0xf3e0c4: DecompressPointer r1
    //     0xf3e0c4: add             x1, x1, HEAP, lsl #32
    // 0xf3e0c8: cmp             w1, NULL
    // 0xf3e0cc: b.eq            #0xf3e3e8
    // 0xf3e0d0: r0 = dispose()
    //     0xf3e0d0: bl              #0x10ef154  ; [package:flutter/src/widgets/restoration_properties.dart] RestorableChangeNotifier::dispose
    // 0xf3e0d4: ldur            x0, [fp, #-8]
    // 0xf3e0d8: StoreField: r0->field_23 = rNULL
    //     0xf3e0d8: stur            NULL, [x0, #0x23]
    // 0xf3e0dc: b               #0xf3e0ec
    // 0xf3e0e0: ldur            x0, [fp, #-8]
    // 0xf3e0e4: b               #0xf3e0ec
    // 0xf3e0e8: ldur            x0, [fp, #-8]
    // 0xf3e0ec: ldur            x3, [fp, #-0x10]
    // 0xf3e0f0: LoadField: r1 = r0->field_b
    //     0xf3e0f0: ldur            w1, [x0, #0xb]
    // 0xf3e0f4: DecompressPointer r1
    //     0xf3e0f4: add             x1, x1, HEAP, lsl #32
    // 0xf3e0f8: cmp             w1, NULL
    // 0xf3e0fc: b.eq            #0xf3e3ec
    // 0xf3e100: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xf3e100: ldur            w2, [x1, #0x17]
    // 0xf3e104: DecompressPointer r2
    //     0xf3e104: add             x2, x2, HEAP, lsl #32
    // 0xf3e108: ArrayLoad: r1 = r3[0]  ; List_4
    //     0xf3e108: ldur            w1, [x3, #0x17]
    // 0xf3e10c: DecompressPointer r1
    //     0xf3e10c: add             x1, x1, HEAP, lsl #32
    // 0xf3e110: cmp             w2, w1
    // 0xf3e114: b.eq            #0xf3e1bc
    // 0xf3e118: cmp             w1, NULL
    // 0xf3e11c: b.ne            #0xf3e130
    // 0xf3e120: LoadField: r1 = r0->field_27
    //     0xf3e120: ldur            w1, [x0, #0x27]
    // 0xf3e124: DecompressPointer r1
    //     0xf3e124: add             x1, x1, HEAP, lsl #32
    // 0xf3e128: mov             x4, x1
    // 0xf3e12c: b               #0xf3e134
    // 0xf3e130: mov             x4, x1
    // 0xf3e134: stur            x4, [fp, #-0x18]
    // 0xf3e138: cmp             w4, NULL
    // 0xf3e13c: b.eq            #0xf3e160
    // 0xf3e140: mov             x2, x0
    // 0xf3e144: r1 = Function '_handleFocusChanged@130181401':.
    //     0xf3e144: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f908] AnonymousClosure: (0xf3e750), in [package:flutter/src/material/text_field.dart] _TextFieldState::_handleFocusChanged (0xf3e788)
    //     0xf3e148: ldr             x1, [x1, #0x908]
    // 0xf3e14c: r0 = AllocateClosure()
    //     0xf3e14c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf3e150: ldur            x1, [fp, #-0x18]
    // 0xf3e154: mov             x2, x0
    // 0xf3e158: r0 = removeListener()
    //     0xf3e158: bl              #0xcff298  ; [dart:mixin_deduplication] _MixinApplication219&Object&DiagnosticableTreeMixin&ChangeNotifier::removeListener
    // 0xf3e15c: ldur            x0, [fp, #-8]
    // 0xf3e160: LoadField: r1 = r0->field_b
    //     0xf3e160: ldur            w1, [x0, #0xb]
    // 0xf3e164: DecompressPointer r1
    //     0xf3e164: add             x1, x1, HEAP, lsl #32
    // 0xf3e168: cmp             w1, NULL
    // 0xf3e16c: b.eq            #0xf3e3f0
    // 0xf3e170: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xf3e170: ldur            w2, [x1, #0x17]
    // 0xf3e174: DecompressPointer r2
    //     0xf3e174: add             x2, x2, HEAP, lsl #32
    // 0xf3e178: cmp             w2, NULL
    // 0xf3e17c: b.ne            #0xf3e190
    // 0xf3e180: LoadField: r1 = r0->field_27
    //     0xf3e180: ldur            w1, [x0, #0x27]
    // 0xf3e184: DecompressPointer r1
    //     0xf3e184: add             x1, x1, HEAP, lsl #32
    // 0xf3e188: mov             x3, x1
    // 0xf3e18c: b               #0xf3e194
    // 0xf3e190: mov             x3, x2
    // 0xf3e194: stur            x3, [fp, #-0x18]
    // 0xf3e198: cmp             w3, NULL
    // 0xf3e19c: b.eq            #0xf3e1bc
    // 0xf3e1a0: mov             x2, x0
    // 0xf3e1a4: r1 = Function '_handleFocusChanged@130181401':.
    //     0xf3e1a4: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f908] AnonymousClosure: (0xf3e750), in [package:flutter/src/material/text_field.dart] _TextFieldState::_handleFocusChanged (0xf3e788)
    //     0xf3e1a8: ldr             x1, [x1, #0x908]
    // 0xf3e1ac: r0 = AllocateClosure()
    //     0xf3e1ac: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf3e1b0: ldur            x1, [fp, #-0x18]
    // 0xf3e1b4: mov             x2, x0
    // 0xf3e1b8: r0 = addListener()
    //     0xf3e1b8: bl              #0xd01514  ; [dart:mixin_deduplication] _MixinApplication219&Object&DiagnosticableTreeMixin&ChangeNotifier::addListener
    // 0xf3e1bc: ldur            x1, [fp, #-8]
    // 0xf3e1c0: r0 = _effectiveFocusNode()
    //     0xf3e1c0: bl              #0xd49478  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_effectiveFocusNode
    // 0xf3e1c4: ldur            x1, [fp, #-8]
    // 0xf3e1c8: stur            x0, [fp, #-0x18]
    // 0xf3e1cc: r0 = _canRequestFocus()
    //     0xf3e1cc: bl              #0xeeee78  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_canRequestFocus
    // 0xf3e1d0: ldur            x1, [fp, #-0x18]
    // 0xf3e1d4: mov             x2, x0
    // 0xf3e1d8: r0 = canRequestFocus=()
    //     0xf3e1d8: bl              #0xe0d7f0  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::canRequestFocus=
    // 0xf3e1dc: ldur            x1, [fp, #-8]
    // 0xf3e1e0: r0 = _effectiveFocusNode()
    //     0xf3e1e0: bl              #0xd49478  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_effectiveFocusNode
    // 0xf3e1e4: mov             x1, x0
    // 0xf3e1e8: r0 = hasFocus()
    //     0xf3e1e8: bl              #0x843d08  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::hasFocus
    // 0xf3e1ec: tbnz            w0, #4, #0xf3e2a4
    // 0xf3e1f0: ldur            x0, [fp, #-8]
    // 0xf3e1f4: ldur            x1, [fp, #-0x10]
    // 0xf3e1f8: LoadField: r2 = r0->field_b
    //     0xf3e1f8: ldur            w2, [x0, #0xb]
    // 0xf3e1fc: DecompressPointer r2
    //     0xf3e1fc: add             x2, x2, HEAP, lsl #32
    // 0xf3e200: cmp             w2, NULL
    // 0xf3e204: b.eq            #0xf3e3f4
    // 0xf3e208: LoadField: r3 = r2->field_6b
    //     0xf3e208: ldur            w3, [x2, #0x6b]
    // 0xf3e20c: DecompressPointer r3
    //     0xf3e20c: add             x3, x3, HEAP, lsl #32
    // 0xf3e210: LoadField: r4 = r1->field_6b
    //     0xf3e210: ldur            w4, [x1, #0x6b]
    // 0xf3e214: DecompressPointer r4
    //     0xf3e214: add             x4, x4, HEAP, lsl #32
    // 0xf3e218: cmp             w3, w4
    // 0xf3e21c: b.eq            #0xf3e2a8
    // 0xf3e220: LoadField: r1 = r2->field_93
    //     0xf3e220: ldur            w1, [x2, #0x93]
    // 0xf3e224: DecompressPointer r1
    //     0xf3e224: add             x1, x1, HEAP, lsl #32
    // 0xf3e228: cmp             w1, NULL
    // 0xf3e22c: b.ne            #0xf3e248
    // 0xf3e230: LoadField: r1 = r2->field_1b
    //     0xf3e230: ldur            w1, [x2, #0x1b]
    // 0xf3e234: DecompressPointer r1
    //     0xf3e234: add             x1, x1, HEAP, lsl #32
    // 0xf3e238: LoadField: r2 = r1->field_db
    //     0xf3e238: ldur            w2, [x1, #0xdb]
    // 0xf3e23c: DecompressPointer r2
    //     0xf3e23c: add             x2, x2, HEAP, lsl #32
    // 0xf3e240: tbnz            w2, #4, #0xf3e2a8
    // 0xf3e244: b               #0xf3e24c
    // 0xf3e248: tbnz            w1, #4, #0xf3e2a8
    // 0xf3e24c: mov             x1, x0
    // 0xf3e250: r0 = _effectiveController()
    //     0xf3e250: bl              #0xd49538  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_effectiveController
    // 0xf3e254: LoadField: r1 = r0->field_27
    //     0xf3e254: ldur            w1, [x0, #0x27]
    // 0xf3e258: DecompressPointer r1
    //     0xf3e258: add             x1, x1, HEAP, lsl #32
    // 0xf3e25c: LoadField: r0 = r1->field_b
    //     0xf3e25c: ldur            w0, [x1, #0xb]
    // 0xf3e260: DecompressPointer r0
    //     0xf3e260: add             x0, x0, HEAP, lsl #32
    // 0xf3e264: LoadField: r1 = r0->field_7
    //     0xf3e264: ldur            x1, [x0, #7]
    // 0xf3e268: LoadField: r2 = r0->field_f
    //     0xf3e268: ldur            x2, [x0, #0xf]
    // 0xf3e26c: cmp             x1, x2
    // 0xf3e270: b.ne            #0xf3e29c
    // 0xf3e274: ldur            x0, [fp, #-8]
    // 0xf3e278: LoadField: r1 = r0->field_b
    //     0xf3e278: ldur            w1, [x0, #0xb]
    // 0xf3e27c: DecompressPointer r1
    //     0xf3e27c: add             x1, x1, HEAP, lsl #32
    // 0xf3e280: cmp             w1, NULL
    // 0xf3e284: b.eq            #0xf3e3f8
    // 0xf3e288: LoadField: r2 = r1->field_6b
    //     0xf3e288: ldur            w2, [x1, #0x6b]
    // 0xf3e28c: DecompressPointer r2
    //     0xf3e28c: add             x2, x2, HEAP, lsl #32
    // 0xf3e290: eor             x1, x2, #0x10
    // 0xf3e294: StoreField: r0->field_2f = r1
    //     0xf3e294: stur            w1, [x0, #0x2f]
    // 0xf3e298: b               #0xf3e2a8
    // 0xf3e29c: ldur            x0, [fp, #-8]
    // 0xf3e2a0: b               #0xf3e2a8
    // 0xf3e2a4: ldur            x0, [fp, #-8]
    // 0xf3e2a8: LoadField: r1 = r0->field_b
    //     0xf3e2a8: ldur            w1, [x0, #0xb]
    // 0xf3e2ac: DecompressPointer r1
    //     0xf3e2ac: add             x1, x1, HEAP, lsl #32
    // 0xf3e2b0: cmp             w1, NULL
    // 0xf3e2b4: b.eq            #0xf3e3fc
    // 0xf3e2b8: LoadField: r2 = r0->field_3f
    //     0xf3e2b8: ldur            w2, [x0, #0x3f]
    // 0xf3e2bc: DecompressPointer r2
    //     0xf3e2bc: add             x2, x2, HEAP, lsl #32
    // 0xf3e2c0: cmp             w2, NULL
    // 0xf3e2c4: b.eq            #0xf3e400
    // 0xf3e2c8: LoadField: r3 = r1->field_93
    //     0xf3e2c8: ldur            w3, [x1, #0x93]
    // 0xf3e2cc: DecompressPointer r3
    //     0xf3e2cc: add             x3, x3, HEAP, lsl #32
    // 0xf3e2d0: cmp             w3, NULL
    // 0xf3e2d4: b.ne            #0xf3e2ec
    // 0xf3e2d8: LoadField: r3 = r1->field_1b
    //     0xf3e2d8: ldur            w3, [x1, #0x1b]
    // 0xf3e2dc: DecompressPointer r3
    //     0xf3e2dc: add             x3, x3, HEAP, lsl #32
    // 0xf3e2e0: LoadField: r1 = r3->field_db
    //     0xf3e2e0: ldur            w1, [x3, #0xdb]
    // 0xf3e2e4: DecompressPointer r1
    //     0xf3e2e4: add             x1, x1, HEAP, lsl #32
    // 0xf3e2e8: b               #0xf3e2f0
    // 0xf3e2ec: mov             x1, x3
    // 0xf3e2f0: eor             x3, x1, #0x10
    // 0xf3e2f4: mov             x1, x2
    // 0xf3e2f8: r2 = Instance_WidgetState
    //     0xf3e2f8: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xf3e2fc: ldr             x2, [x2, #0xa70]
    // 0xf3e300: r0 = update()
    //     0xf3e300: bl              #0xd223e0  ; [package:flutter/src/widgets/widget_state.dart] WidgetStatesController::update
    // 0xf3e304: ldur            x0, [fp, #-8]
    // 0xf3e308: LoadField: r1 = r0->field_b
    //     0xf3e308: ldur            w1, [x0, #0xb]
    // 0xf3e30c: DecompressPointer r1
    //     0xf3e30c: add             x1, x1, HEAP, lsl #32
    // 0xf3e310: cmp             w1, NULL
    // 0xf3e314: b.eq            #0xf3e404
    // 0xf3e318: LoadField: r1 = r0->field_3f
    //     0xf3e318: ldur            w1, [x0, #0x3f]
    // 0xf3e31c: DecompressPointer r1
    //     0xf3e31c: add             x1, x1, HEAP, lsl #32
    // 0xf3e320: cmp             w1, NULL
    // 0xf3e324: b.eq            #0xf3e408
    // 0xf3e328: LoadField: r3 = r0->field_2b
    //     0xf3e328: ldur            w3, [x0, #0x2b]
    // 0xf3e32c: DecompressPointer r3
    //     0xf3e32c: add             x3, x3, HEAP, lsl #32
    // 0xf3e330: r2 = Instance_WidgetState
    //     0xf3e330: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xf3e334: ldr             x2, [x2, #0xa50]
    // 0xf3e338: r0 = update()
    //     0xf3e338: bl              #0xd223e0  ; [package:flutter/src/widgets/widget_state.dart] WidgetStatesController::update
    // 0xf3e33c: ldur            x0, [fp, #-8]
    // 0xf3e340: LoadField: r1 = r0->field_b
    //     0xf3e340: ldur            w1, [x0, #0xb]
    // 0xf3e344: DecompressPointer r1
    //     0xf3e344: add             x1, x1, HEAP, lsl #32
    // 0xf3e348: cmp             w1, NULL
    // 0xf3e34c: b.eq            #0xf3e40c
    // 0xf3e350: LoadField: r2 = r0->field_3f
    //     0xf3e350: ldur            w2, [x0, #0x3f]
    // 0xf3e354: DecompressPointer r2
    //     0xf3e354: add             x2, x2, HEAP, lsl #32
    // 0xf3e358: stur            x2, [fp, #-0x10]
    // 0xf3e35c: cmp             w2, NULL
    // 0xf3e360: b.eq            #0xf3e410
    // 0xf3e364: mov             x1, x0
    // 0xf3e368: r0 = _effectiveFocusNode()
    //     0xf3e368: bl              #0xd49478  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_effectiveFocusNode
    // 0xf3e36c: mov             x1, x0
    // 0xf3e370: r0 = hasFocus()
    //     0xf3e370: bl              #0x843d08  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::hasFocus
    // 0xf3e374: ldur            x1, [fp, #-0x10]
    // 0xf3e378: mov             x3, x0
    // 0xf3e37c: r2 = Instance_WidgetState
    //     0xf3e37c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xf3e380: ldr             x2, [x2, #0xa60]
    // 0xf3e384: r0 = update()
    //     0xf3e384: bl              #0xd223e0  ; [package:flutter/src/widgets/widget_state.dart] WidgetStatesController::update
    // 0xf3e388: ldur            x1, [fp, #-8]
    // 0xf3e38c: LoadField: r0 = r1->field_b
    //     0xf3e38c: ldur            w0, [x1, #0xb]
    // 0xf3e390: DecompressPointer r0
    //     0xf3e390: add             x0, x0, HEAP, lsl #32
    // 0xf3e394: cmp             w0, NULL
    // 0xf3e398: b.eq            #0xf3e414
    // 0xf3e39c: LoadField: r0 = r1->field_3f
    //     0xf3e39c: ldur            w0, [x1, #0x3f]
    // 0xf3e3a0: DecompressPointer r0
    //     0xf3e3a0: add             x0, x0, HEAP, lsl #32
    // 0xf3e3a4: stur            x0, [fp, #-0x10]
    // 0xf3e3a8: cmp             w0, NULL
    // 0xf3e3ac: b.eq            #0xf3e418
    // 0xf3e3b0: r0 = _hasError()
    //     0xf3e3b0: bl              #0xd493fc  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_hasError
    // 0xf3e3b4: ldur            x1, [fp, #-0x10]
    // 0xf3e3b8: mov             x3, x0
    // 0xf3e3bc: r2 = Instance_WidgetState
    //     0xf3e3bc: add             x2, PP, #0x26, lsl #12  ; [pp+0x26500] Obj!WidgetState@12c8781
    //     0xf3e3c0: ldr             x2, [x2, #0x500]
    // 0xf3e3c4: r0 = update()
    //     0xf3e3c4: bl              #0xd223e0  ; [package:flutter/src/widgets/widget_state.dart] WidgetStatesController::update
    // 0xf3e3c8: r0 = Null
    //     0xf3e3c8: mov             x0, NULL
    // 0xf3e3cc: LeaveFrame
    //     0xf3e3cc: mov             SP, fp
    //     0xf3e3d0: ldp             fp, lr, [SP], #0x10
    // 0xf3e3d4: ret
    //     0xf3e3d4: ret             
    // 0xf3e3d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3e3d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3e3dc: b               #0xf3dfe4
    // 0xf3e3e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3e3e0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3e3e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3e3e4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3e3e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3e3e8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3e3ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3e3ec: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3e3f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3e3f0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3e3f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3e3f4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3e3f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3e3f8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3e3fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3e3fc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3e400: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3e400: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3e404: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3e404: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3e408: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3e408: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3e40c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3e40c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3e410: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3e410: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3e414: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3e414: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3e418: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3e418: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _createLocalController(/* No info */) {
    // ** addr: 0xf3e41c, size: 0x114
    // 0xf3e41c: EnterFrame
    //     0xf3e41c: stp             fp, lr, [SP, #-0x10]!
    //     0xf3e420: mov             fp, SP
    // 0xf3e424: AllocStack(0x18)
    //     0xf3e424: sub             SP, SP, #0x18
    // 0xf3e428: SetupParameters(_TextFieldState this /* r1 => r0, fp-0x8 */, [dynamic _ = Null /* r2, fp-0x10 */])
    //     0xf3e428: mov             x0, x1
    //     0xf3e42c: stur            x1, [fp, #-8]
    //     0xf3e430: ldur            w1, [x4, #0x13]
    //     0xf3e434: sub             x2, x1, #2
    //     0xf3e438: cmp             w2, #2
    //     0xf3e43c: b.lt            #0xf3e450
    //     0xf3e440: add             x1, fp, w2, sxtw #2
    //     0xf3e444: ldr             x1, [x1, #8]
    //     0xf3e448: mov             x2, x1
    //     0xf3e44c: b               #0xf3e454
    //     0xf3e450: mov             x2, NULL
    //     0xf3e454: stur            x2, [fp, #-0x10]
    // 0xf3e458: CheckStackOverflow
    //     0xf3e458: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3e45c: cmp             SP, x16
    //     0xf3e460: b.ls            #0xf3e524
    // 0xf3e464: cmp             w2, NULL
    // 0xf3e468: b.ne            #0xf3e47c
    // 0xf3e46c: r1 = <TextEditingController>
    //     0xf3e46c: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f950] TypeArguments: <TextEditingController>
    //     0xf3e470: ldr             x1, [x1, #0x950]
    // 0xf3e474: r0 = RestorableTextEditingController()
    //     0xf3e474: bl              #0xf3e650  ; [package:flutter/src/widgets/restoration_properties.dart] RestorableTextEditingController::RestorableTextEditingController
    // 0xf3e478: b               #0xf3e4d4
    // 0xf3e47c: r1 = <TextEditingController>
    //     0xf3e47c: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f950] TypeArguments: <TextEditingController>
    //     0xf3e480: ldr             x1, [x1, #0x950]
    // 0xf3e484: r0 = RestorableTextEditingController()
    //     0xf3e484: bl              #0xf3e644  ; AllocateRestorableTextEditingControllerStub -> RestorableTextEditingController (size=0x3c)
    // 0xf3e488: mov             x1, x0
    // 0xf3e48c: ldur            x0, [fp, #-0x10]
    // 0xf3e490: stur            x1, [fp, #-0x18]
    // 0xf3e494: StoreField: r1->field_37 = r0
    //     0xf3e494: stur            w0, [x1, #0x37]
    // 0xf3e498: r0 = false
    //     0xf3e498: add             x0, NULL, #0x30  ; false
    // 0xf3e49c: StoreField: r1->field_27 = r0
    //     0xf3e49c: stur            w0, [x1, #0x27]
    // 0xf3e4a0: StoreField: r1->field_7 = rZR
    //     0xf3e4a0: stur            xzr, [x1, #7]
    // 0xf3e4a4: StoreField: r1->field_13 = rZR
    //     0xf3e4a4: stur            xzr, [x1, #0x13]
    // 0xf3e4a8: StoreField: r1->field_1b = rZR
    //     0xf3e4a8: stur            xzr, [x1, #0x1b]
    // 0xf3e4ac: r0 = LoadStaticField(0x45c)
    //     0xf3e4ac: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf3e4b0: ldr             x0, [x0, #0x8b8]
    // 0xf3e4b4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3e4b8: cmp             w0, w16
    // 0xf3e4bc: b.ne            #0xf3e4c8
    // 0xf3e4c0: r2 = _emptyListeners
    //     0xf3e4c0: ldr             x2, [PP, #0x17f0]  ; [pp+0x17f0] Field <ChangeNotifier._emptyListeners@28329750>: static late final (offset: 0x45c)
    // 0xf3e4c4: r0 = InitLateFinalStaticField()
    //     0xf3e4c4: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xf3e4c8: mov             x1, x0
    // 0xf3e4cc: ldur            x0, [fp, #-0x18]
    // 0xf3e4d0: StoreField: r0->field_f = r1
    //     0xf3e4d0: stur            w1, [x0, #0xf]
    // 0xf3e4d4: ldur            x1, [fp, #-8]
    // 0xf3e4d8: StoreField: r1->field_23 = r0
    //     0xf3e4d8: stur            w0, [x1, #0x23]
    //     0xf3e4dc: ldurb           w16, [x1, #-1]
    //     0xf3e4e0: ldurb           w17, [x0, #-1]
    //     0xf3e4e4: and             x16, x17, x16, lsr #2
    //     0xf3e4e8: tst             x16, HEAP, lsr #32
    //     0xf3e4ec: b.eq            #0xf3e4f4
    //     0xf3e4f0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf3e4f4: LoadField: r0 = r1->field_1b
    //     0xf3e4f4: ldur            w0, [x1, #0x1b]
    // 0xf3e4f8: DecompressPointer r0
    //     0xf3e4f8: add             x0, x0, HEAP, lsl #32
    // 0xf3e4fc: tbz             w0, #4, #0xf3e514
    // 0xf3e500: LoadField: r0 = r1->field_b
    //     0xf3e500: ldur            w0, [x1, #0xb]
    // 0xf3e504: DecompressPointer r0
    //     0xf3e504: add             x0, x0, HEAP, lsl #32
    // 0xf3e508: cmp             w0, NULL
    // 0xf3e50c: b.eq            #0xf3e52c
    // 0xf3e510: r0 = _registerController()
    //     0xf3e510: bl              #0xf3e530  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_registerController
    // 0xf3e514: r0 = Null
    //     0xf3e514: mov             x0, NULL
    // 0xf3e518: LeaveFrame
    //     0xf3e518: mov             SP, fp
    //     0xf3e51c: ldp             fp, lr, [SP], #0x10
    // 0xf3e520: ret
    //     0xf3e520: ret             
    // 0xf3e524: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3e524: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3e528: b               #0xf3e464
    // 0xf3e52c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3e52c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _registerController(/* No info */) {
    // ** addr: 0xf3e530, size: 0x44
    // 0xf3e530: EnterFrame
    //     0xf3e530: stp             fp, lr, [SP, #-0x10]!
    //     0xf3e534: mov             fp, SP
    // 0xf3e538: CheckStackOverflow
    //     0xf3e538: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3e53c: cmp             SP, x16
    //     0xf3e540: b.ls            #0xf3e568
    // 0xf3e544: LoadField: r2 = r1->field_23
    //     0xf3e544: ldur            w2, [x1, #0x23]
    // 0xf3e548: DecompressPointer r2
    //     0xf3e548: add             x2, x2, HEAP, lsl #32
    // 0xf3e54c: cmp             w2, NULL
    // 0xf3e550: b.eq            #0xf3e570
    // 0xf3e554: r0 = registerForRestoration()
    //     0xf3e554: bl              #0xf3e574  ; [dart:mixin_deduplication] _MixinApplication114&State&RestorationMixin::registerForRestoration
    // 0xf3e558: r0 = Null
    //     0xf3e558: mov             x0, NULL
    // 0xf3e55c: LeaveFrame
    //     0xf3e55c: mov             SP, fp
    //     0xf3e560: ldp             fp, lr, [SP], #0x10
    // 0xf3e564: ret
    //     0xf3e564: ret             
    // 0xf3e568: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3e568: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3e56c: b               #0xf3e544
    // 0xf3e570: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3e570: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleFocusChanged(dynamic) {
    // ** addr: 0xf3e750, size: 0x38
    // 0xf3e750: EnterFrame
    //     0xf3e750: stp             fp, lr, [SP, #-0x10]!
    //     0xf3e754: mov             fp, SP
    // 0xf3e758: ldr             x0, [fp, #0x10]
    // 0xf3e75c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf3e75c: ldur            w1, [x0, #0x17]
    // 0xf3e760: DecompressPointer r1
    //     0xf3e760: add             x1, x1, HEAP, lsl #32
    // 0xf3e764: CheckStackOverflow
    //     0xf3e764: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3e768: cmp             SP, x16
    //     0xf3e76c: b.ls            #0xf3e780
    // 0xf3e770: r0 = _handleFocusChanged()
    //     0xf3e770: bl              #0xf3e788  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_handleFocusChanged
    // 0xf3e774: LeaveFrame
    //     0xf3e774: mov             SP, fp
    //     0xf3e778: ldp             fp, lr, [SP], #0x10
    // 0xf3e77c: ret
    //     0xf3e77c: ret             
    // 0xf3e780: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3e780: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3e784: b               #0xf3e770
  }
  _ _handleFocusChanged(/* No info */) {
    // ** addr: 0xf3e788, size: 0xa4
    // 0xf3e788: EnterFrame
    //     0xf3e788: stp             fp, lr, [SP, #-0x10]!
    //     0xf3e78c: mov             fp, SP
    // 0xf3e790: AllocStack(0x10)
    //     0xf3e790: sub             SP, SP, #0x10
    // 0xf3e794: SetupParameters(_TextFieldState this /* r1 => r0, fp-0x8 */)
    //     0xf3e794: mov             x0, x1
    //     0xf3e798: stur            x1, [fp, #-8]
    // 0xf3e79c: CheckStackOverflow
    //     0xf3e79c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3e7a0: cmp             SP, x16
    //     0xf3e7a4: b.ls            #0xf3e81c
    // 0xf3e7a8: r1 = Function '<anonymous closure>':.
    //     0xf3e7a8: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f920] Function: [dart:ui] Shader::Shader._ (0x13cf838)
    //     0xf3e7ac: ldr             x1, [x1, #0x920]
    // 0xf3e7b0: r2 = Null
    //     0xf3e7b0: mov             x2, NULL
    // 0xf3e7b4: r0 = AllocateClosure()
    //     0xf3e7b4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf3e7b8: ldur            x1, [fp, #-8]
    // 0xf3e7bc: mov             x2, x0
    // 0xf3e7c0: r0 = setState()
    //     0xf3e7c0: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xf3e7c4: ldur            x1, [fp, #-8]
    // 0xf3e7c8: LoadField: r0 = r1->field_b
    //     0xf3e7c8: ldur            w0, [x1, #0xb]
    // 0xf3e7cc: DecompressPointer r0
    //     0xf3e7cc: add             x0, x0, HEAP, lsl #32
    // 0xf3e7d0: cmp             w0, NULL
    // 0xf3e7d4: b.eq            #0xf3e824
    // 0xf3e7d8: LoadField: r0 = r1->field_3f
    //     0xf3e7d8: ldur            w0, [x1, #0x3f]
    // 0xf3e7dc: DecompressPointer r0
    //     0xf3e7dc: add             x0, x0, HEAP, lsl #32
    // 0xf3e7e0: stur            x0, [fp, #-0x10]
    // 0xf3e7e4: cmp             w0, NULL
    // 0xf3e7e8: b.eq            #0xf3e828
    // 0xf3e7ec: r0 = _effectiveFocusNode()
    //     0xf3e7ec: bl              #0xd49478  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_effectiveFocusNode
    // 0xf3e7f0: mov             x1, x0
    // 0xf3e7f4: r0 = hasFocus()
    //     0xf3e7f4: bl              #0x843d08  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::hasFocus
    // 0xf3e7f8: ldur            x1, [fp, #-0x10]
    // 0xf3e7fc: mov             x3, x0
    // 0xf3e800: r2 = Instance_WidgetState
    //     0xf3e800: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xf3e804: ldr             x2, [x2, #0xa60]
    // 0xf3e808: r0 = update()
    //     0xf3e808: bl              #0xd223e0  ; [package:flutter/src/widgets/widget_state.dart] WidgetStatesController::update
    // 0xf3e80c: r0 = Null
    //     0xf3e80c: mov             x0, NULL
    // 0xf3e810: LeaveFrame
    //     0xf3e810: mov             SP, fp
    //     0xf3e814: ldp             fp, lr, [SP], #0x10
    // 0xf3e818: ret
    //     0xf3e818: ret             
    // 0xf3e81c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3e81c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3e820: b               #0xf3e7a8
    // 0xf3e824: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3e824: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3e828: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3e828: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0xf7c984, size: 0x130
    // 0xf7c984: EnterFrame
    //     0xf7c984: stp             fp, lr, [SP, #-0x10]!
    //     0xf7c988: mov             fp, SP
    // 0xf7c98c: AllocStack(0x10)
    //     0xf7c98c: sub             SP, SP, #0x10
    // 0xf7c990: SetupParameters(_TextFieldState this /* r1 => r1, fp-0x8 */)
    //     0xf7c990: stur            x1, [fp, #-8]
    // 0xf7c994: CheckStackOverflow
    //     0xf7c994: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf7c998: cmp             SP, x16
    //     0xf7c99c: b.ls            #0xf7caa4
    // 0xf7c9a0: r0 = _TextFieldSelectionGestureDetectorBuilder()
    //     0xf7c9a0: bl              #0xf7cd40  ; Allocate_TextFieldSelectionGestureDetectorBuilderStub -> _TextFieldSelectionGestureDetectorBuilder (size=0x30)
    // 0xf7c9a4: ldur            x2, [fp, #-8]
    // 0xf7c9a8: StoreField: r0->field_2b = r2
    //     0xf7c9a8: stur            w2, [x0, #0x2b]
    // 0xf7c9ac: r1 = true
    //     0xf7c9ac: add             x1, NULL, #0x20  ; true
    // 0xf7c9b0: StoreField: r0->field_b = r1
    //     0xf7c9b0: stur            w1, [x0, #0xb]
    // 0xf7c9b4: StoreField: r0->field_f = r1
    //     0xf7c9b4: stur            w1, [x0, #0xf]
    // 0xf7c9b8: r1 = false
    //     0xf7c9b8: add             x1, NULL, #0x30  ; false
    // 0xf7c9bc: StoreField: r0->field_13 = r1
    //     0xf7c9bc: stur            w1, [x0, #0x13]
    // 0xf7c9c0: ArrayStore: r0[0] = rZR  ; List_8
    //     0xf7c9c0: stur            xzr, [x0, #0x17]
    // 0xf7c9c4: StoreField: r0->field_1f = rZR
    //     0xf7c9c4: stur            xzr, [x0, #0x1f]
    // 0xf7c9c8: StoreField: r0->field_7 = r2
    //     0xf7c9c8: stur            w2, [x0, #7]
    // 0xf7c9cc: StoreField: r2->field_33 = r0
    //     0xf7c9cc: stur            w0, [x2, #0x33]
    //     0xf7c9d0: ldurb           w16, [x2, #-1]
    //     0xf7c9d4: ldurb           w17, [x0, #-1]
    //     0xf7c9d8: and             x16, x17, x16, lsr #2
    //     0xf7c9dc: tst             x16, HEAP, lsr #32
    //     0xf7c9e0: b.eq            #0xf7c9e8
    //     0xf7c9e4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf7c9e8: LoadField: r0 = r2->field_b
    //     0xf7c9e8: ldur            w0, [x2, #0xb]
    // 0xf7c9ec: DecompressPointer r0
    //     0xf7c9ec: add             x0, x0, HEAP, lsl #32
    // 0xf7c9f0: cmp             w0, NULL
    // 0xf7c9f4: b.eq            #0xf7caac
    // 0xf7c9f8: LoadField: r1 = r0->field_13
    //     0xf7c9f8: ldur            w1, [x0, #0x13]
    // 0xf7c9fc: DecompressPointer r1
    //     0xf7c9fc: add             x1, x1, HEAP, lsl #32
    // 0xf7ca00: cmp             w1, NULL
    // 0xf7ca04: b.ne            #0xf7ca14
    // 0xf7ca08: mov             x1, x2
    // 0xf7ca0c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xf7ca0c: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xf7ca10: r0 = _createLocalController()
    //     0xf7ca10: bl              #0xf3e41c  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_createLocalController
    // 0xf7ca14: ldur            x0, [fp, #-8]
    // 0xf7ca18: mov             x1, x0
    // 0xf7ca1c: r0 = _effectiveFocusNode()
    //     0xf7ca1c: bl              #0xd49478  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_effectiveFocusNode
    // 0xf7ca20: mov             x1, x0
    // 0xf7ca24: ldur            x0, [fp, #-8]
    // 0xf7ca28: LoadField: r2 = r0->field_b
    //     0xf7ca28: ldur            w2, [x0, #0xb]
    // 0xf7ca2c: DecompressPointer r2
    //     0xf7ca2c: add             x2, x2, HEAP, lsl #32
    // 0xf7ca30: cmp             w2, NULL
    // 0xf7ca34: b.eq            #0xf7cab0
    // 0xf7ca38: LoadField: r3 = r2->field_93
    //     0xf7ca38: ldur            w3, [x2, #0x93]
    // 0xf7ca3c: DecompressPointer r3
    //     0xf7ca3c: add             x3, x3, HEAP, lsl #32
    // 0xf7ca40: cmp             w3, NULL
    // 0xf7ca44: b.ne            #0xf7ca5c
    // 0xf7ca48: LoadField: r3 = r2->field_1b
    //     0xf7ca48: ldur            w3, [x2, #0x1b]
    // 0xf7ca4c: DecompressPointer r3
    //     0xf7ca4c: add             x3, x3, HEAP, lsl #32
    // 0xf7ca50: LoadField: r2 = r3->field_db
    //     0xf7ca50: ldur            w2, [x3, #0xdb]
    // 0xf7ca54: DecompressPointer r2
    //     0xf7ca54: add             x2, x2, HEAP, lsl #32
    // 0xf7ca58: b               #0xf7ca60
    // 0xf7ca5c: mov             x2, x3
    // 0xf7ca60: r0 = canRequestFocus=()
    //     0xf7ca60: bl              #0xe0d7f0  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::canRequestFocus=
    // 0xf7ca64: ldur            x1, [fp, #-8]
    // 0xf7ca68: r0 = _effectiveFocusNode()
    //     0xf7ca68: bl              #0xd49478  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_effectiveFocusNode
    // 0xf7ca6c: ldur            x2, [fp, #-8]
    // 0xf7ca70: r1 = Function '_handleFocusChanged@130181401':.
    //     0xf7ca70: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f908] AnonymousClosure: (0xf3e750), in [package:flutter/src/material/text_field.dart] _TextFieldState::_handleFocusChanged (0xf3e788)
    //     0xf7ca74: ldr             x1, [x1, #0x908]
    // 0xf7ca78: stur            x0, [fp, #-0x10]
    // 0xf7ca7c: r0 = AllocateClosure()
    //     0xf7ca7c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf7ca80: ldur            x1, [fp, #-0x10]
    // 0xf7ca84: mov             x2, x0
    // 0xf7ca88: r0 = addListener()
    //     0xf7ca88: bl              #0xd01514  ; [dart:mixin_deduplication] _MixinApplication219&Object&DiagnosticableTreeMixin&ChangeNotifier::addListener
    // 0xf7ca8c: ldur            x1, [fp, #-8]
    // 0xf7ca90: r0 = _initStatesController()
    //     0xf7ca90: bl              #0xf7cab4  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_initStatesController
    // 0xf7ca94: r0 = Null
    //     0xf7ca94: mov             x0, NULL
    // 0xf7ca98: LeaveFrame
    //     0xf7ca98: mov             SP, fp
    //     0xf7ca9c: ldp             fp, lr, [SP], #0x10
    // 0xf7caa0: ret
    //     0xf7caa0: ret             
    // 0xf7caa4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf7caa4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf7caa8: b               #0xf7c9a0
    // 0xf7caac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf7caac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf7cab0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf7cab0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _initStatesController(/* No info */) {
    // ** addr: 0xf7cab4, size: 0x200
    // 0xf7cab4: EnterFrame
    //     0xf7cab4: stp             fp, lr, [SP, #-0x10]!
    //     0xf7cab8: mov             fp, SP
    // 0xf7cabc: AllocStack(0x10)
    //     0xf7cabc: sub             SP, SP, #0x10
    // 0xf7cac0: SetupParameters(_TextFieldState this /* r1 => r0, fp-0x8 */)
    //     0xf7cac0: mov             x0, x1
    //     0xf7cac4: stur            x1, [fp, #-8]
    // 0xf7cac8: CheckStackOverflow
    //     0xf7cac8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf7cacc: cmp             SP, x16
    //     0xf7cad0: b.ls            #0xf7cc84
    // 0xf7cad4: LoadField: r1 = r0->field_b
    //     0xf7cad4: ldur            w1, [x0, #0xb]
    // 0xf7cad8: DecompressPointer r1
    //     0xf7cad8: add             x1, x1, HEAP, lsl #32
    // 0xf7cadc: cmp             w1, NULL
    // 0xf7cae0: b.eq            #0xf7cc8c
    // 0xf7cae4: r1 = <Set<WidgetState>>
    //     0xf7cae4: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f978] TypeArguments: <Set<WidgetState>>
    //     0xf7cae8: ldr             x1, [x1, #0x978]
    // 0xf7caec: r0 = WidgetStatesController()
    //     0xf7caec: bl              #0xf379b8  ; AllocateWidgetStatesControllerStub -> WidgetStatesController (size=0x2c)
    // 0xf7caf0: mov             x1, x0
    // 0xf7caf4: stur            x0, [fp, #-0x10]
    // 0xf7caf8: r0 = WidgetStatesController()
    //     0xf7caf8: bl              #0xf378e8  ; [package:flutter/src/widgets/widget_state.dart] WidgetStatesController::WidgetStatesController
    // 0xf7cafc: ldur            x0, [fp, #-0x10]
    // 0xf7cb00: ldur            x4, [fp, #-8]
    // 0xf7cb04: StoreField: r4->field_3f = r0
    //     0xf7cb04: stur            w0, [x4, #0x3f]
    //     0xf7cb08: ldurb           w16, [x4, #-1]
    //     0xf7cb0c: ldurb           w17, [x0, #-1]
    //     0xf7cb10: and             x16, x17, x16, lsr #2
    //     0xf7cb14: tst             x16, HEAP, lsr #32
    //     0xf7cb18: b.eq            #0xf7cb20
    //     0xf7cb1c: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xf7cb20: LoadField: r0 = r4->field_b
    //     0xf7cb20: ldur            w0, [x4, #0xb]
    // 0xf7cb24: DecompressPointer r0
    //     0xf7cb24: add             x0, x0, HEAP, lsl #32
    // 0xf7cb28: cmp             w0, NULL
    // 0xf7cb2c: b.eq            #0xf7cc90
    // 0xf7cb30: LoadField: r1 = r0->field_93
    //     0xf7cb30: ldur            w1, [x0, #0x93]
    // 0xf7cb34: DecompressPointer r1
    //     0xf7cb34: add             x1, x1, HEAP, lsl #32
    // 0xf7cb38: cmp             w1, NULL
    // 0xf7cb3c: b.ne            #0xf7cb54
    // 0xf7cb40: LoadField: r1 = r0->field_1b
    //     0xf7cb40: ldur            w1, [x0, #0x1b]
    // 0xf7cb44: DecompressPointer r1
    //     0xf7cb44: add             x1, x1, HEAP, lsl #32
    // 0xf7cb48: LoadField: r0 = r1->field_db
    //     0xf7cb48: ldur            w0, [x1, #0xdb]
    // 0xf7cb4c: DecompressPointer r0
    //     0xf7cb4c: add             x0, x0, HEAP, lsl #32
    // 0xf7cb50: b               #0xf7cb58
    // 0xf7cb54: mov             x0, x1
    // 0xf7cb58: eor             x3, x0, #0x10
    // 0xf7cb5c: ldur            x1, [fp, #-0x10]
    // 0xf7cb60: r2 = Instance_WidgetState
    //     0xf7cb60: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xf7cb64: ldr             x2, [x2, #0xa70]
    // 0xf7cb68: r0 = update()
    //     0xf7cb68: bl              #0xd223e0  ; [package:flutter/src/widgets/widget_state.dart] WidgetStatesController::update
    // 0xf7cb6c: ldur            x0, [fp, #-8]
    // 0xf7cb70: LoadField: r1 = r0->field_b
    //     0xf7cb70: ldur            w1, [x0, #0xb]
    // 0xf7cb74: DecompressPointer r1
    //     0xf7cb74: add             x1, x1, HEAP, lsl #32
    // 0xf7cb78: cmp             w1, NULL
    // 0xf7cb7c: b.eq            #0xf7cc94
    // 0xf7cb80: LoadField: r1 = r0->field_3f
    //     0xf7cb80: ldur            w1, [x0, #0x3f]
    // 0xf7cb84: DecompressPointer r1
    //     0xf7cb84: add             x1, x1, HEAP, lsl #32
    // 0xf7cb88: cmp             w1, NULL
    // 0xf7cb8c: b.eq            #0xf7cc98
    // 0xf7cb90: LoadField: r3 = r0->field_2b
    //     0xf7cb90: ldur            w3, [x0, #0x2b]
    // 0xf7cb94: DecompressPointer r3
    //     0xf7cb94: add             x3, x3, HEAP, lsl #32
    // 0xf7cb98: r2 = Instance_WidgetState
    //     0xf7cb98: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xf7cb9c: ldr             x2, [x2, #0xa50]
    // 0xf7cba0: r0 = update()
    //     0xf7cba0: bl              #0xd223e0  ; [package:flutter/src/widgets/widget_state.dart] WidgetStatesController::update
    // 0xf7cba4: ldur            x0, [fp, #-8]
    // 0xf7cba8: LoadField: r1 = r0->field_b
    //     0xf7cba8: ldur            w1, [x0, #0xb]
    // 0xf7cbac: DecompressPointer r1
    //     0xf7cbac: add             x1, x1, HEAP, lsl #32
    // 0xf7cbb0: cmp             w1, NULL
    // 0xf7cbb4: b.eq            #0xf7cc9c
    // 0xf7cbb8: LoadField: r2 = r0->field_3f
    //     0xf7cbb8: ldur            w2, [x0, #0x3f]
    // 0xf7cbbc: DecompressPointer r2
    //     0xf7cbbc: add             x2, x2, HEAP, lsl #32
    // 0xf7cbc0: stur            x2, [fp, #-0x10]
    // 0xf7cbc4: cmp             w2, NULL
    // 0xf7cbc8: b.eq            #0xf7cca0
    // 0xf7cbcc: mov             x1, x0
    // 0xf7cbd0: r0 = _effectiveFocusNode()
    //     0xf7cbd0: bl              #0xd49478  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_effectiveFocusNode
    // 0xf7cbd4: mov             x1, x0
    // 0xf7cbd8: r0 = hasFocus()
    //     0xf7cbd8: bl              #0x843d08  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::hasFocus
    // 0xf7cbdc: ldur            x1, [fp, #-0x10]
    // 0xf7cbe0: mov             x3, x0
    // 0xf7cbe4: r2 = Instance_WidgetState
    //     0xf7cbe4: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xf7cbe8: ldr             x2, [x2, #0xa60]
    // 0xf7cbec: r0 = update()
    //     0xf7cbec: bl              #0xd223e0  ; [package:flutter/src/widgets/widget_state.dart] WidgetStatesController::update
    // 0xf7cbf0: ldur            x0, [fp, #-8]
    // 0xf7cbf4: LoadField: r1 = r0->field_b
    //     0xf7cbf4: ldur            w1, [x0, #0xb]
    // 0xf7cbf8: DecompressPointer r1
    //     0xf7cbf8: add             x1, x1, HEAP, lsl #32
    // 0xf7cbfc: cmp             w1, NULL
    // 0xf7cc00: b.eq            #0xf7cca4
    // 0xf7cc04: LoadField: r2 = r0->field_3f
    //     0xf7cc04: ldur            w2, [x0, #0x3f]
    // 0xf7cc08: DecompressPointer r2
    //     0xf7cc08: add             x2, x2, HEAP, lsl #32
    // 0xf7cc0c: stur            x2, [fp, #-0x10]
    // 0xf7cc10: cmp             w2, NULL
    // 0xf7cc14: b.eq            #0xf7cca8
    // 0xf7cc18: mov             x1, x0
    // 0xf7cc1c: r0 = _hasError()
    //     0xf7cc1c: bl              #0xd493fc  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_hasError
    // 0xf7cc20: ldur            x1, [fp, #-0x10]
    // 0xf7cc24: mov             x3, x0
    // 0xf7cc28: r2 = Instance_WidgetState
    //     0xf7cc28: add             x2, PP, #0x26, lsl #12  ; [pp+0x26500] Obj!WidgetState@12c8781
    //     0xf7cc2c: ldr             x2, [x2, #0x500]
    // 0xf7cc30: r0 = update()
    //     0xf7cc30: bl              #0xd223e0  ; [package:flutter/src/widgets/widget_state.dart] WidgetStatesController::update
    // 0xf7cc34: ldur            x2, [fp, #-8]
    // 0xf7cc38: LoadField: r0 = r2->field_b
    //     0xf7cc38: ldur            w0, [x2, #0xb]
    // 0xf7cc3c: DecompressPointer r0
    //     0xf7cc3c: add             x0, x0, HEAP, lsl #32
    // 0xf7cc40: cmp             w0, NULL
    // 0xf7cc44: b.eq            #0xf7ccac
    // 0xf7cc48: LoadField: r0 = r2->field_3f
    //     0xf7cc48: ldur            w0, [x2, #0x3f]
    // 0xf7cc4c: DecompressPointer r0
    //     0xf7cc4c: add             x0, x0, HEAP, lsl #32
    // 0xf7cc50: stur            x0, [fp, #-0x10]
    // 0xf7cc54: cmp             w0, NULL
    // 0xf7cc58: b.eq            #0xf7ccb0
    // 0xf7cc5c: r1 = Function '_handleStatesControllerChange@130181401':.
    //     0xf7cc5c: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f910] AnonymousClosure: (0xf7ccb4), in [package:flutter/src/material/text_field.dart] _TextFieldState::_handleStatesControllerChange (0xf7ccec)
    //     0xf7cc60: ldr             x1, [x1, #0x910]
    // 0xf7cc64: r0 = AllocateClosure()
    //     0xf7cc64: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf7cc68: ldur            x1, [fp, #-0x10]
    // 0xf7cc6c: mov             x2, x0
    // 0xf7cc70: r0 = addListener()
    //     0xf7cc70: bl              #0xd038e0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0xf7cc74: r0 = Null
    //     0xf7cc74: mov             x0, NULL
    // 0xf7cc78: LeaveFrame
    //     0xf7cc78: mov             SP, fp
    //     0xf7cc7c: ldp             fp, lr, [SP], #0x10
    // 0xf7cc80: ret
    //     0xf7cc80: ret             
    // 0xf7cc84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf7cc84: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf7cc88: b               #0xf7cad4
    // 0xf7cc8c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf7cc8c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf7cc90: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf7cc90: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf7cc94: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf7cc94: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf7cc98: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf7cc98: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf7cc9c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf7cc9c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf7cca0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf7cca0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf7cca4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf7cca4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf7cca8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf7cca8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf7ccac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf7ccac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf7ccb0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf7ccb0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleStatesControllerChange(dynamic) {
    // ** addr: 0xf7ccb4, size: 0x38
    // 0xf7ccb4: EnterFrame
    //     0xf7ccb4: stp             fp, lr, [SP, #-0x10]!
    //     0xf7ccb8: mov             fp, SP
    // 0xf7ccbc: ldr             x0, [fp, #0x10]
    // 0xf7ccc0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf7ccc0: ldur            w1, [x0, #0x17]
    // 0xf7ccc4: DecompressPointer r1
    //     0xf7ccc4: add             x1, x1, HEAP, lsl #32
    // 0xf7ccc8: CheckStackOverflow
    //     0xf7ccc8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf7cccc: cmp             SP, x16
    //     0xf7ccd0: b.ls            #0xf7cce4
    // 0xf7ccd4: r0 = _handleStatesControllerChange()
    //     0xf7ccd4: bl              #0xf7ccec  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_handleStatesControllerChange
    // 0xf7ccd8: LeaveFrame
    //     0xf7ccd8: mov             SP, fp
    //     0xf7ccdc: ldp             fp, lr, [SP], #0x10
    // 0xf7cce0: ret
    //     0xf7cce0: ret             
    // 0xf7cce4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf7cce4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf7cce8: b               #0xf7ccd4
  }
  _ _handleStatesControllerChange(/* No info */) {
    // ** addr: 0xf7ccec, size: 0x54
    // 0xf7ccec: EnterFrame
    //     0xf7ccec: stp             fp, lr, [SP, #-0x10]!
    //     0xf7ccf0: mov             fp, SP
    // 0xf7ccf4: AllocStack(0x8)
    //     0xf7ccf4: sub             SP, SP, #8
    // 0xf7ccf8: SetupParameters(_TextFieldState this /* r1 => r0, fp-0x8 */)
    //     0xf7ccf8: mov             x0, x1
    //     0xf7ccfc: stur            x1, [fp, #-8]
    // 0xf7cd00: CheckStackOverflow
    //     0xf7cd00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf7cd04: cmp             SP, x16
    //     0xf7cd08: b.ls            #0xf7cd38
    // 0xf7cd0c: r1 = Function '<anonymous closure>':.
    //     0xf7cd0c: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f918] Function: [dart:ui] Shader::Shader._ (0x13cf838)
    //     0xf7cd10: ldr             x1, [x1, #0x918]
    // 0xf7cd14: r2 = Null
    //     0xf7cd14: mov             x2, NULL
    // 0xf7cd18: r0 = AllocateClosure()
    //     0xf7cd18: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf7cd1c: ldur            x1, [fp, #-8]
    // 0xf7cd20: mov             x2, x0
    // 0xf7cd24: r0 = setState()
    //     0xf7cd24: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xf7cd28: r0 = Null
    //     0xf7cd28: mov             x0, NULL
    // 0xf7cd2c: LeaveFrame
    //     0xf7cd2c: mov             SP, fp
    //     0xf7cd30: ldp             fp, lr, [SP], #0x10
    // 0xf7cd34: ret
    //     0xf7cd34: ret             
    // 0xf7cd38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf7cd38: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf7cd3c: b               #0xf7cd0c
  }
  _ _TextFieldState(/* No info */) {
    // ** addr: 0xfa32dc, size: 0xb8
    // 0xfa32dc: EnterFrame
    //     0xfa32dc: stp             fp, lr, [SP, #-0x10]!
    //     0xfa32e0: mov             fp, SP
    // 0xfa32e4: AllocStack(0x18)
    //     0xfa32e4: sub             SP, SP, #0x18
    // 0xfa32e8: r2 = false
    //     0xfa32e8: add             x2, NULL, #0x30  ; false
    // 0xfa32ec: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa32f0: mov             x3, x1
    // 0xfa32f4: stur            x1, [fp, #-8]
    // 0xfa32f8: CheckStackOverflow
    //     0xfa32f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa32fc: cmp             SP, x16
    //     0xfa3300: b.ls            #0xfa338c
    // 0xfa3304: StoreField: r3->field_2b = r2
    //     0xfa3304: stur            w2, [x3, #0x2b]
    // 0xfa3308: StoreField: r3->field_2f = r2
    //     0xfa3308: stur            w2, [x3, #0x2f]
    // 0xfa330c: StoreField: r3->field_33 = r0
    //     0xfa330c: stur            w0, [x3, #0x33]
    // 0xfa3310: StoreField: r3->field_37 = r0
    //     0xfa3310: stur            w0, [x3, #0x37]
    // 0xfa3314: r1 = <EditableTextState>
    //     0xfa3314: add             x1, PP, #0x84, lsl #12  ; [pp+0x84930] TypeArguments: <EditableTextState>
    //     0xfa3318: ldr             x1, [x1, #0x930]
    // 0xfa331c: r0 = LabeledGlobalKey()
    //     0xfa331c: bl              #0x856cf8  ; AllocateLabeledGlobalKeyStub -> LabeledGlobalKey<X0 bound State> (size=0x10)
    // 0xfa3320: ldur            x1, [fp, #-8]
    // 0xfa3324: StoreField: r1->field_3b = r0
    //     0xfa3324: stur            w0, [x1, #0x3b]
    //     0xfa3328: ldurb           w16, [x1, #-1]
    //     0xfa332c: ldurb           w17, [x0, #-1]
    //     0xfa3330: and             x16, x17, x16, lsr #2
    //     0xfa3334: tst             x16, HEAP, lsr #32
    //     0xfa3338: b.eq            #0xfa3340
    //     0xfa333c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfa3340: r0 = true
    //     0xfa3340: add             x0, NULL, #0x20  ; true
    // 0xfa3344: StoreField: r1->field_1b = r0
    //     0xfa3344: stur            w0, [x1, #0x1b]
    // 0xfa3348: r16 = <RestorableProperty<Object?>, (dynamic this) => void?>
    //     0xfa3348: add             x16, PP, #0x26, lsl #12  ; [pp+0x26c60] TypeArguments: <RestorableProperty<Object?>, (dynamic this) => void?>
    //     0xfa334c: ldr             x16, [x16, #0xc60]
    // 0xfa3350: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0xfa3354: stp             lr, x16, [SP]
    // 0xfa3358: r0 = Map._fromLiteral()
    //     0xfa3358: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xfa335c: ldur            x1, [fp, #-8]
    // 0xfa3360: ArrayStore: r1[0] = r0  ; List_4
    //     0xfa3360: stur            w0, [x1, #0x17]
    //     0xfa3364: ldurb           w16, [x1, #-1]
    //     0xfa3368: ldurb           w17, [x0, #-1]
    //     0xfa336c: and             x16, x17, x16, lsr #2
    //     0xfa3370: tst             x16, HEAP, lsr #32
    //     0xfa3374: b.eq            #0xfa337c
    //     0xfa3378: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfa337c: r0 = Null
    //     0xfa337c: mov             x0, NULL
    // 0xfa3380: LeaveFrame
    //     0xfa3380: mov             SP, fp
    //     0xfa3384: ldp             fp, lr, [SP], #0x10
    // 0xfa3388: ret
    //     0xfa3388: ret             
    // 0xfa338c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa338c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa3390: b               #0xfa3304
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10de494, size: 0x104
    // 0x10de494: EnterFrame
    //     0x10de494: stp             fp, lr, [SP, #-0x10]!
    //     0x10de498: mov             fp, SP
    // 0x10de49c: AllocStack(0x10)
    //     0x10de49c: sub             SP, SP, #0x10
    // 0x10de4a0: SetupParameters(_TextFieldState this /* r1 => r0, fp-0x8 */)
    //     0x10de4a0: mov             x0, x1
    //     0x10de4a4: stur            x1, [fp, #-8]
    // 0x10de4a8: CheckStackOverflow
    //     0x10de4a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10de4ac: cmp             SP, x16
    //     0x10de4b0: b.ls            #0x10de588
    // 0x10de4b4: mov             x1, x0
    // 0x10de4b8: r0 = _effectiveFocusNode()
    //     0x10de4b8: bl              #0xd49478  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_effectiveFocusNode
    // 0x10de4bc: ldur            x2, [fp, #-8]
    // 0x10de4c0: r1 = Function '_handleFocusChanged@130181401':.
    //     0x10de4c0: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f908] AnonymousClosure: (0xf3e750), in [package:flutter/src/material/text_field.dart] _TextFieldState::_handleFocusChanged (0xf3e788)
    //     0x10de4c4: ldr             x1, [x1, #0x908]
    // 0x10de4c8: stur            x0, [fp, #-0x10]
    // 0x10de4cc: r0 = AllocateClosure()
    //     0x10de4cc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10de4d0: ldur            x1, [fp, #-0x10]
    // 0x10de4d4: mov             x2, x0
    // 0x10de4d8: r0 = removeListener()
    //     0x10de4d8: bl              #0xcff298  ; [dart:mixin_deduplication] _MixinApplication219&Object&DiagnosticableTreeMixin&ChangeNotifier::removeListener
    // 0x10de4dc: ldur            x2, [fp, #-8]
    // 0x10de4e0: LoadField: r1 = r2->field_27
    //     0x10de4e0: ldur            w1, [x2, #0x27]
    // 0x10de4e4: DecompressPointer r1
    //     0x10de4e4: add             x1, x1, HEAP, lsl #32
    // 0x10de4e8: cmp             w1, NULL
    // 0x10de4ec: b.eq            #0x10de4f8
    // 0x10de4f0: r0 = dispose()
    //     0x10de4f0: bl              #0x10ec024  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::dispose
    // 0x10de4f4: ldur            x2, [fp, #-8]
    // 0x10de4f8: LoadField: r1 = r2->field_23
    //     0x10de4f8: ldur            w1, [x2, #0x23]
    // 0x10de4fc: DecompressPointer r1
    //     0x10de4fc: add             x1, x1, HEAP, lsl #32
    // 0x10de500: cmp             w1, NULL
    // 0x10de504: b.ne            #0x10de510
    // 0x10de508: mov             x0, x2
    // 0x10de50c: b               #0x10de518
    // 0x10de510: r0 = dispose()
    //     0x10de510: bl              #0x10ef154  ; [package:flutter/src/widgets/restoration_properties.dart] RestorableChangeNotifier::dispose
    // 0x10de514: ldur            x0, [fp, #-8]
    // 0x10de518: LoadField: r1 = r0->field_b
    //     0x10de518: ldur            w1, [x0, #0xb]
    // 0x10de51c: DecompressPointer r1
    //     0x10de51c: add             x1, x1, HEAP, lsl #32
    // 0x10de520: cmp             w1, NULL
    // 0x10de524: b.eq            #0x10de590
    // 0x10de528: LoadField: r3 = r0->field_3f
    //     0x10de528: ldur            w3, [x0, #0x3f]
    // 0x10de52c: DecompressPointer r3
    //     0x10de52c: add             x3, x3, HEAP, lsl #32
    // 0x10de530: stur            x3, [fp, #-0x10]
    // 0x10de534: cmp             w3, NULL
    // 0x10de538: b.eq            #0x10de594
    // 0x10de53c: mov             x2, x0
    // 0x10de540: r1 = Function '_handleStatesControllerChange@130181401':.
    //     0x10de540: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f910] AnonymousClosure: (0xf7ccb4), in [package:flutter/src/material/text_field.dart] _TextFieldState::_handleStatesControllerChange (0xf7ccec)
    //     0x10de544: ldr             x1, [x1, #0x910]
    // 0x10de548: r0 = AllocateClosure()
    //     0x10de548: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10de54c: ldur            x1, [fp, #-0x10]
    // 0x10de550: mov             x2, x0
    // 0x10de554: r0 = removeListener()
    //     0x10de554: bl              #0xcff968  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x10de558: ldur            x0, [fp, #-8]
    // 0x10de55c: LoadField: r1 = r0->field_3f
    //     0x10de55c: ldur            w1, [x0, #0x3f]
    // 0x10de560: DecompressPointer r1
    //     0x10de560: add             x1, x1, HEAP, lsl #32
    // 0x10de564: cmp             w1, NULL
    // 0x10de568: b.eq            #0x10de570
    // 0x10de56c: r0 = dispose()
    //     0x10de56c: bl              #0x10ef878  ; [dart:mixin_deduplication] _MixinApplication276&Object&ChangeNotifier::dispose
    // 0x10de570: ldur            x1, [fp, #-8]
    // 0x10de574: r0 = dispose()
    //     0x10de574: bl              #0x10de598  ; [dart:mixin_deduplication] _MixinApplication114&State&RestorationMixin::dispose
    // 0x10de578: r0 = Null
    //     0x10de578: mov             x0, NULL
    // 0x10de57c: LeaveFrame
    //     0x10de57c: mov             SP, fp
    //     0x10de580: ldp             fp, lr, [SP], #0x10
    // 0x10de584: ret
    //     0x10de584: ret             
    // 0x10de588: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10de588: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10de58c: b               #0x10de4b4
    // 0x10de590: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10de590: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x10de594: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10de594: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ restoreState(/* No info */) {
    // ** addr: 0x11974c4, size: 0x40
    // 0x11974c4: EnterFrame
    //     0x11974c4: stp             fp, lr, [SP, #-0x10]!
    //     0x11974c8: mov             fp, SP
    // 0x11974cc: CheckStackOverflow
    //     0x11974cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11974d0: cmp             SP, x16
    //     0x11974d4: b.ls            #0x11974fc
    // 0x11974d8: LoadField: r0 = r1->field_23
    //     0x11974d8: ldur            w0, [x1, #0x23]
    // 0x11974dc: DecompressPointer r0
    //     0x11974dc: add             x0, x0, HEAP, lsl #32
    // 0x11974e0: cmp             w0, NULL
    // 0x11974e4: b.eq            #0x11974ec
    // 0x11974e8: r0 = _registerController()
    //     0x11974e8: bl              #0xf3e530  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_registerController
    // 0x11974ec: r0 = Null
    //     0x11974ec: mov             x0, NULL
    // 0x11974f0: LeaveFrame
    //     0x11974f0: mov             SP, fp
    //     0x11974f4: ldp             fp, lr, [SP], #0x10
    // 0x11974f8: ret
    //     0x11974f8: ret             
    // 0x11974fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11974fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1197500: b               #0x11974d8
  }
  get _ forcePressEnabled(/* No info */) {
    // ** addr: 0x12827a4, size: 0x2c
    // 0x12827a4: LoadField: r0 = r1->field_37
    //     0x12827a4: ldur            w0, [x1, #0x37]
    // 0x12827a8: DecompressPointer r0
    //     0x12827a8: add             x0, x0, HEAP, lsl #32
    // 0x12827ac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12827b0: cmp             w0, w16
    // 0x12827b4: b.eq            #0x12827bc
    // 0x12827b8: ret
    //     0x12827b8: ret             
    // 0x12827bc: EnterFrame
    //     0x12827bc: stp             fp, lr, [SP, #-0x10]!
    //     0x12827c0: mov             fp, SP
    // 0x12827c4: r9 = forcePressEnabled
    //     0x12827c4: add             x9, PP, #0x98, lsl #12  ; [pp+0x98e88] Field <_TextFieldState@130181401.forcePressEnabled>: late (offset: 0x38)
    //     0x12827c8: ldr             x9, [x9, #0xe88]
    // 0x12827cc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12827cc: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  get _ textInputConfiguration(/* No info */) {
    // ** addr: 0x12a1a14, size: 0x24c
    // 0x12a1a14: EnterFrame
    //     0x12a1a14: stp             fp, lr, [SP, #-0x10]!
    //     0x12a1a18: mov             fp, SP
    // 0x12a1a1c: AllocStack(0x58)
    //     0x12a1a1c: sub             SP, SP, #0x58
    // 0x12a1a20: SetupParameters(_TextFieldState this /* r1 => r0, fp-0x20 */)
    //     0x12a1a20: mov             x0, x1
    //     0x12a1a24: stur            x1, [fp, #-0x20]
    // 0x12a1a28: CheckStackOverflow
    //     0x12a1a28: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12a1a2c: cmp             SP, x16
    //     0x12a1a30: b.ls            #0x12a1c44
    // 0x12a1a34: LoadField: r1 = r0->field_b
    //     0x12a1a34: ldur            w1, [x0, #0xb]
    // 0x12a1a38: DecompressPointer r1
    //     0x12a1a38: add             x1, x1, HEAP, lsl #32
    // 0x12a1a3c: cmp             w1, NULL
    // 0x12a1a40: b.eq            #0x12a1c4c
    // 0x12a1a44: LoadField: r3 = r1->field_f7
    //     0x12a1a44: ldur            w3, [x1, #0xf7]
    // 0x12a1a48: DecompressPointer r3
    //     0x12a1a48: add             x3, x3, HEAP, lsl #32
    // 0x12a1a4c: stur            x3, [fp, #-0x18]
    // 0x12a1a50: cmp             w3, NULL
    // 0x12a1a54: b.ne            #0x12a1a60
    // 0x12a1a58: r0 = Null
    //     0x12a1a58: mov             x0, NULL
    // 0x12a1a5c: b               #0x12a1b70
    // 0x12a1a60: LoadField: r2 = r3->field_b
    //     0x12a1a60: ldur            w2, [x3, #0xb]
    // 0x12a1a64: r4 = LoadInt32Instr(r2)
    //     0x12a1a64: sbfx            x4, x2, #1, #0x1f
    // 0x12a1a68: stur            x4, [fp, #-0x10]
    // 0x12a1a6c: cmp             x4, #0
    // 0x12a1a70: b.le            #0x12a1b5c
    // 0x12a1a74: cmp             x4, #0x40
    // 0x12a1a78: b.gt            #0x12a1b44
    // 0x12a1a7c: LoadField: r5 = r3->field_7
    //     0x12a1a7c: ldur            w5, [x3, #7]
    // 0x12a1a80: DecompressPointer r5
    //     0x12a1a80: add             x5, x5, HEAP, lsl #32
    // 0x12a1a84: mov             x1, x5
    // 0x12a1a88: stur            x5, [fp, #-8]
    // 0x12a1a8c: r0 = AllocateArray()
    //     0x12a1a8c: bl              #0x13df928  ; AllocateArrayStub
    // 0x12a1a90: mov             x3, x0
    // 0x12a1a94: stur            x3, [fp, #-0x38]
    // 0x12a1a98: r6 = 0
    //     0x12a1a98: mov             x6, #0
    // 0x12a1a9c: ldur            x4, [fp, #-0x18]
    // 0x12a1aa0: ldur            x5, [fp, #-0x10]
    // 0x12a1aa4: stur            x6, [fp, #-0x30]
    // 0x12a1aa8: CheckStackOverflow
    //     0x12a1aa8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12a1aac: cmp             SP, x16
    //     0x12a1ab0: b.ls            #0x12a1c50
    // 0x12a1ab4: cmp             x6, x5
    // 0x12a1ab8: b.ge            #0x12a1b3c
    // 0x12a1abc: ArrayLoad: r7 = r4[r6]  ; Unknown_4
    //     0x12a1abc: add             x16, x4, x6, lsl #2
    //     0x12a1ac0: ldur            w7, [x16, #0xf]
    // 0x12a1ac4: DecompressPointer r7
    //     0x12a1ac4: add             x7, x7, HEAP, lsl #32
    // 0x12a1ac8: mov             x0, x7
    // 0x12a1acc: ldur            x2, [fp, #-8]
    // 0x12a1ad0: stur            x7, [fp, #-0x28]
    // 0x12a1ad4: r1 = Null
    //     0x12a1ad4: mov             x1, NULL
    // 0x12a1ad8: cmp             w2, NULL
    // 0x12a1adc: b.eq            #0x12a1afc
    // 0x12a1ae0: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x12a1ae0: ldur            w4, [x2, #0x17]
    // 0x12a1ae4: DecompressPointer r4
    //     0x12a1ae4: add             x4, x4, HEAP, lsl #32
    // 0x12a1ae8: r8 = X0
    //     0x12a1ae8: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x12a1aec: LoadField: r9 = r4->field_7
    //     0x12a1aec: ldur            x9, [x4, #7]
    // 0x12a1af0: r3 = Null
    //     0x12a1af0: add             x3, PP, #0x8f, lsl #12  ; [pp+0x8f8d8] Null
    //     0x12a1af4: ldr             x3, [x3, #0x8d8]
    // 0x12a1af8: blr             x9
    // 0x12a1afc: ldur            x1, [fp, #-0x38]
    // 0x12a1b00: ldur            x0, [fp, #-0x28]
    // 0x12a1b04: ldur            x2, [fp, #-0x30]
    // 0x12a1b08: ArrayStore: r1[r2] = r0  ; List_4
    //     0x12a1b08: add             x25, x1, x2, lsl #2
    //     0x12a1b0c: add             x25, x25, #0xf
    //     0x12a1b10: str             w0, [x25]
    //     0x12a1b14: tbz             w0, #0, #0x12a1b30
    //     0x12a1b18: ldurb           w16, [x1, #-1]
    //     0x12a1b1c: ldurb           w17, [x0, #-1]
    //     0x12a1b20: and             x16, x17, x16, lsr #2
    //     0x12a1b24: tst             x16, HEAP, lsr #32
    //     0x12a1b28: b.eq            #0x12a1b30
    //     0x12a1b2c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12a1b30: add             x6, x2, #1
    // 0x12a1b34: ldur            x3, [fp, #-0x38]
    // 0x12a1b38: b               #0x12a1a9c
    // 0x12a1b3c: ldur            x0, [fp, #-0x38]
    // 0x12a1b40: b               #0x12a1b70
    // 0x12a1b44: ldur            x16, [fp, #-0x18]
    // 0x12a1b48: stp             xzr, x16, [SP, #0x10]
    // 0x12a1b4c: r16 = true
    //     0x12a1b4c: add             x16, NULL, #0x20  ; true
    // 0x12a1b50: stp             x16, x2, [SP]
    // 0x12a1b54: r0 = _sliceInternal()
    //     0x12a1b54: bl              #0xa01a28  ; [dart:core] _Array::_sliceInternal
    // 0x12a1b58: b               #0x12a1b70
    // 0x12a1b5c: mov             x0, x3
    // 0x12a1b60: LoadField: r1 = r0->field_7
    //     0x12a1b60: ldur            w1, [x0, #7]
    // 0x12a1b64: DecompressPointer r1
    //     0x12a1b64: add             x1, x1, HEAP, lsl #32
    // 0x12a1b68: r2 = 0
    //     0x12a1b68: mov             x2, #0
    // 0x12a1b6c: r0 = AllocateArray()
    //     0x12a1b6c: bl              #0x13df928  ; AllocateArrayStub
    // 0x12a1b70: stur            x0, [fp, #-8]
    // 0x12a1b74: cmp             w0, NULL
    // 0x12a1b78: b.eq            #0x12a1c00
    // 0x12a1b7c: ldur            x2, [fp, #-0x20]
    // 0x12a1b80: mov             x1, x2
    // 0x12a1b84: r0 = autofillId()
    //     0x12a1b84: bl              #0x12a1d80  ; [package:flutter/src/material/text_field.dart] _TextFieldState::autofillId
    // 0x12a1b88: ldur            x1, [fp, #-0x20]
    // 0x12a1b8c: stur            x0, [fp, #-0x18]
    // 0x12a1b90: r0 = _effectiveController()
    //     0x12a1b90: bl              #0xd49538  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_effectiveController
    // 0x12a1b94: LoadField: r1 = r0->field_27
    //     0x12a1b94: ldur            w1, [x0, #0x27]
    // 0x12a1b98: DecompressPointer r1
    //     0x12a1b98: add             x1, x1, HEAP, lsl #32
    // 0x12a1b9c: ldur            x0, [fp, #-0x20]
    // 0x12a1ba0: stur            x1, [fp, #-0x38]
    // 0x12a1ba4: LoadField: r2 = r0->field_b
    //     0x12a1ba4: ldur            w2, [x0, #0xb]
    // 0x12a1ba8: DecompressPointer r2
    //     0x12a1ba8: add             x2, x2, HEAP, lsl #32
    // 0x12a1bac: cmp             w2, NULL
    // 0x12a1bb0: b.eq            #0x12a1c58
    // 0x12a1bb4: LoadField: r3 = r2->field_1b
    //     0x12a1bb4: ldur            w3, [x2, #0x1b]
    // 0x12a1bb8: DecompressPointer r3
    //     0x12a1bb8: add             x3, x3, HEAP, lsl #32
    // 0x12a1bbc: LoadField: r2 = r3->field_2f
    //     0x12a1bbc: ldur            w2, [x3, #0x2f]
    // 0x12a1bc0: DecompressPointer r2
    //     0x12a1bc0: add             x2, x2, HEAP, lsl #32
    // 0x12a1bc4: stur            x2, [fp, #-0x28]
    // 0x12a1bc8: r0 = AutofillConfiguration()
    //     0x12a1bc8: bl              #0x12a1d74  ; AllocateAutofillConfigurationStub -> AutofillConfiguration (size=0x1c)
    // 0x12a1bcc: mov             x1, x0
    // 0x12a1bd0: r0 = true
    //     0x12a1bd0: add             x0, NULL, #0x20  ; true
    // 0x12a1bd4: StoreField: r1->field_7 = r0
    //     0x12a1bd4: stur            w0, [x1, #7]
    // 0x12a1bd8: ldur            x0, [fp, #-0x18]
    // 0x12a1bdc: StoreField: r1->field_b = r0
    //     0x12a1bdc: stur            w0, [x1, #0xb]
    // 0x12a1be0: ldur            x0, [fp, #-8]
    // 0x12a1be4: StoreField: r1->field_f = r0
    //     0x12a1be4: stur            w0, [x1, #0xf]
    // 0x12a1be8: ldur            x0, [fp, #-0x28]
    // 0x12a1bec: ArrayStore: r1[0] = r0  ; List_4
    //     0x12a1bec: stur            w0, [x1, #0x17]
    // 0x12a1bf0: ldur            x0, [fp, #-0x38]
    // 0x12a1bf4: StoreField: r1->field_13 = r0
    //     0x12a1bf4: stur            w0, [x1, #0x13]
    // 0x12a1bf8: mov             x2, x1
    // 0x12a1bfc: b               #0x12a1c08
    // 0x12a1c00: r2 = Instance_AutofillConfiguration
    //     0x12a1c00: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8f8e8] Obj!AutofillConfiguration@129c081
    //     0x12a1c04: ldr             x2, [x2, #0x8e8]
    // 0x12a1c08: ldur            x0, [fp, #-0x20]
    // 0x12a1c0c: stur            x2, [fp, #-8]
    // 0x12a1c10: LoadField: r1 = r0->field_3b
    //     0x12a1c10: ldur            w1, [x0, #0x3b]
    // 0x12a1c14: DecompressPointer r1
    //     0x12a1c14: add             x1, x1, HEAP, lsl #32
    // 0x12a1c18: r0 = currentState()
    //     0x12a1c18: bl              #0x8591f8  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0x12a1c1c: cmp             w0, NULL
    // 0x12a1c20: b.eq            #0x12a1c5c
    // 0x12a1c24: mov             x1, x0
    // 0x12a1c28: r0 = textInputConfiguration()
    //     0x12a1c28: bl              #0x12a22f0  ; [package:flutter/src/widgets/editable_text.dart] EditableTextState::textInputConfiguration
    // 0x12a1c2c: mov             x1, x0
    // 0x12a1c30: ldur            x2, [fp, #-8]
    // 0x12a1c34: r0 = copyWith()
    //     0x12a1c34: bl              #0x12a1c60  ; [package:flutter/src/services/text_input.dart] TextInputConfiguration::copyWith
    // 0x12a1c38: LeaveFrame
    //     0x12a1c38: mov             SP, fp
    //     0x12a1c3c: ldp             fp, lr, [SP], #0x10
    // 0x12a1c40: ret
    //     0x12a1c40: ret             
    // 0x12a1c44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12a1c44: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12a1c48: b               #0x12a1a34
    // 0x12a1c4c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12a1c4c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x12a1c50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12a1c50: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12a1c54: b               #0x12a1ab4
    // 0x12a1c58: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12a1c58: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x12a1c5c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12a1c5c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ autofillId(/* No info */) {
    // ** addr: 0x12a1d80, size: 0x88
    // 0x12a1d80: EnterFrame
    //     0x12a1d80: stp             fp, lr, [SP, #-0x10]!
    //     0x12a1d84: mov             fp, SP
    // 0x12a1d88: AllocStack(0x18)
    //     0x12a1d88: sub             SP, SP, #0x18
    // 0x12a1d8c: CheckStackOverflow
    //     0x12a1d8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12a1d90: cmp             SP, x16
    //     0x12a1d94: b.ls            #0x12a1dfc
    // 0x12a1d98: LoadField: r0 = r1->field_3b
    //     0x12a1d98: ldur            w0, [x1, #0x3b]
    // 0x12a1d9c: DecompressPointer r0
    //     0x12a1d9c: add             x0, x0, HEAP, lsl #32
    // 0x12a1da0: mov             x1, x0
    // 0x12a1da4: r0 = currentState()
    //     0x12a1da4: bl              #0x8591f8  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0x12a1da8: stur            x0, [fp, #-8]
    // 0x12a1dac: cmp             w0, NULL
    // 0x12a1db0: b.eq            #0x12a1e04
    // 0x12a1db4: r1 = Null
    //     0x12a1db4: mov             x1, NULL
    // 0x12a1db8: r2 = 4
    //     0x12a1db8: mov             x2, #4
    // 0x12a1dbc: r0 = AllocateArray()
    //     0x12a1dbc: bl              #0x13df928  ; AllocateArrayStub
    // 0x12a1dc0: stur            x0, [fp, #-0x10]
    // 0x12a1dc4: r16 = "EditableText-"
    //     0x12a1dc4: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8f900] "EditableText-"
    //     0x12a1dc8: ldr             x16, [x16, #0x900]
    // 0x12a1dcc: StoreField: r0->field_f = r16
    //     0x12a1dcc: stur            w16, [x0, #0xf]
    // 0x12a1dd0: ldur            x16, [fp, #-8]
    // 0x12a1dd4: str             x16, [SP]
    // 0x12a1dd8: r0 = _getHash()
    //     0x12a1dd8: bl              #0x84c644  ; [dart:core] ::_getHash
    // 0x12a1ddc: mov             x1, x0
    // 0x12a1de0: ldur            x0, [fp, #-0x10]
    // 0x12a1de4: StoreField: r0->field_13 = r1
    //     0x12a1de4: stur            w1, [x0, #0x13]
    // 0x12a1de8: str             x0, [SP]
    // 0x12a1dec: r0 = _interpolate()
    //     0x12a1dec: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x12a1df0: LeaveFrame
    //     0x12a1df0: mov             SP, fp
    //     0x12a1df4: ldp             fp, lr, [SP], #0x10
    // 0x12a1df8: ret
    //     0x12a1df8: ret             
    // 0x12a1dfc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12a1dfc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12a1e00: b               #0x12a1d98
    // 0x12a1e04: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12a1e04: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ selectionEnabled(/* No info */) {
    // ** addr: 0x12a2920, size: 0x5c
    // 0x12a2920: LoadField: r2 = r1->field_b
    //     0x12a2920: ldur            w2, [x1, #0xb]
    // 0x12a2924: DecompressPointer r2
    //     0x12a2924: add             x2, x2, HEAP, lsl #32
    // 0x12a2928: cmp             w2, NULL
    // 0x12a292c: b.eq            #0x12a2970
    // 0x12a2930: LoadField: r1 = r2->field_c7
    //     0x12a2930: ldur            w1, [x2, #0xc7]
    // 0x12a2934: DecompressPointer r1
    //     0x12a2934: add             x1, x1, HEAP, lsl #32
    // 0x12a2938: tbnz            w1, #4, #0x12a2968
    // 0x12a293c: LoadField: r1 = r2->field_93
    //     0x12a293c: ldur            w1, [x2, #0x93]
    // 0x12a2940: DecompressPointer r1
    //     0x12a2940: add             x1, x1, HEAP, lsl #32
    // 0x12a2944: cmp             w1, NULL
    // 0x12a2948: b.ne            #0x12a2960
    // 0x12a294c: LoadField: r3 = r2->field_1b
    //     0x12a294c: ldur            w3, [x2, #0x1b]
    // 0x12a2950: DecompressPointer r3
    //     0x12a2950: add             x3, x3, HEAP, lsl #32
    // 0x12a2954: LoadField: r2 = r3->field_db
    //     0x12a2954: ldur            w2, [x3, #0xdb]
    // 0x12a2958: DecompressPointer r2
    //     0x12a2958: add             x2, x2, HEAP, lsl #32
    // 0x12a295c: mov             x1, x2
    // 0x12a2960: mov             x0, x1
    // 0x12a2964: b               #0x12a296c
    // 0x12a2968: r0 = false
    //     0x12a2968: add             x0, NULL, #0x30  ; false
    // 0x12a296c: ret
    //     0x12a296c: ret             
    // 0x12a2970: EnterFrame
    //     0x12a2970: stp             fp, lr, [SP, #-0x10]!
    //     0x12a2974: mov             fp, SP
    // 0x12a2978: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12a2978: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 6414, size: 0x12c, field offset: 0xc
//   const constructor, 
class TextField extends StatefulWidget {

  static _ _defaultContextMenuBuilder(/* No info */) {
    // ** addr: 0xd91074, size: 0xa4
    // 0xd91074: EnterFrame
    //     0xd91074: stp             fp, lr, [SP, #-0x10]!
    //     0xd91078: mov             fp, SP
    // 0xd9107c: AllocStack(0x18)
    //     0xd9107c: sub             SP, SP, #0x18
    // 0xd91080: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0xd91080: mov             x0, x2
    //     0xd91084: stur            x2, [fp, #-8]
    // 0xd91088: CheckStackOverflow
    //     0xd91088: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd9108c: cmp             SP, x16
    //     0xd91090: b.ls            #0xd91110
    // 0xd91094: mov             x1, x0
    // 0xd91098: r0 = isSupportedByField()
    //     0xd91098: bl              #0xd93afc  ; [package:flutter/src/widgets/system_context_menu.dart] SystemContextMenu::isSupportedByField
    // 0xd9109c: tbnz            w0, #4, #0xd910b8
    // 0xd910a0: ldur            x2, [fp, #-8]
    // 0xd910a4: r1 = Null
    //     0xd910a4: mov             x1, NULL
    // 0xd910a8: r0 = SystemContextMenu.editableText()
    //     0xd910a8: bl              #0xd934f8  ; [package:flutter/src/widgets/system_context_menu.dart] SystemContextMenu::SystemContextMenu.editableText
    // 0xd910ac: LeaveFrame
    //     0xd910ac: mov             SP, fp
    //     0xd910b0: ldp             fp, lr, [SP], #0x10
    // 0xd910b4: ret
    //     0xd910b4: ret             
    // 0xd910b8: ldur            x1, [fp, #-8]
    // 0xd910bc: r0 = contextMenuButtonItems()
    //     0xd910bc: bl              #0xd91b28  ; [package:flutter/src/widgets/editable_text.dart] EditableTextState::contextMenuButtonItems
    // 0xd910c0: stur            x0, [fp, #-0x10]
    // 0xd910c4: r0 = AdaptiveTextSelectionToolbar()
    //     0xd910c4: bl              #0xd91b1c  ; AllocateAdaptiveTextSelectionToolbarStub -> AdaptiveTextSelectionToolbar (size=0x18)
    // 0xd910c8: mov             x2, x0
    // 0xd910cc: ldur            x0, [fp, #-0x10]
    // 0xd910d0: stur            x2, [fp, #-0x18]
    // 0xd910d4: StoreField: r2->field_b = r0
    //     0xd910d4: stur            w0, [x2, #0xb]
    // 0xd910d8: ldur            x1, [fp, #-8]
    // 0xd910dc: r0 = contextMenuAnchors()
    //     0xd910dc: bl              #0xd9114c  ; [package:flutter/src/widgets/editable_text.dart] EditableTextState::contextMenuAnchors
    // 0xd910e0: ldur            x1, [fp, #-0x18]
    // 0xd910e4: StoreField: r1->field_13 = r0
    //     0xd910e4: stur            w0, [x1, #0x13]
    //     0xd910e8: ldurb           w16, [x1, #-1]
    //     0xd910ec: ldurb           w17, [x0, #-1]
    //     0xd910f0: and             x16, x17, x16, lsr #2
    //     0xd910f4: tst             x16, HEAP, lsr #32
    //     0xd910f8: b.eq            #0xd91100
    //     0xd910fc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd91100: mov             x0, x1
    // 0xd91104: LeaveFrame
    //     0xd91104: mov             SP, fp
    //     0xd91108: ldp             fp, lr, [SP], #0x10
    // 0xd9110c: ret
    //     0xd9110c: ret             
    // 0xd91110: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd91110: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd91114: b               #0xd91094
  }
  [closure] static Widget _defaultContextMenuBuilder(dynamic, BuildContext, EditableTextState) {
    // ** addr: 0xd91118, size: 0x34
    // 0xd91118: EnterFrame
    //     0xd91118: stp             fp, lr, [SP, #-0x10]!
    //     0xd9111c: mov             fp, SP
    // 0xd91120: CheckStackOverflow
    //     0xd91120: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd91124: cmp             SP, x16
    //     0xd91128: b.ls            #0xd91144
    // 0xd9112c: ldr             x1, [fp, #0x18]
    // 0xd91130: ldr             x2, [fp, #0x10]
    // 0xd91134: r0 = _defaultContextMenuBuilder()
    //     0xd91134: bl              #0xd91074  ; [package:flutter/src/material/text_field.dart] TextField::_defaultContextMenuBuilder
    // 0xd91138: LeaveFrame
    //     0xd91138: mov             SP, fp
    //     0xd9113c: ldp             fp, lr, [SP], #0x10
    // 0xd91140: ret
    //     0xd91140: ret             
    // 0xd91144: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd91144: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd91148: b               #0xd9112c
  }
  _ createState(/* No info */) {
    // ** addr: 0xfa3294, size: 0x48
    // 0xfa3294: EnterFrame
    //     0xfa3294: stp             fp, lr, [SP, #-0x10]!
    //     0xfa3298: mov             fp, SP
    // 0xfa329c: AllocStack(0x8)
    //     0xfa329c: sub             SP, SP, #8
    // 0xfa32a0: CheckStackOverflow
    //     0xfa32a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa32a4: cmp             SP, x16
    //     0xfa32a8: b.ls            #0xfa32d4
    // 0xfa32ac: r1 = <TextField>
    //     0xfa32ac: add             x1, PP, #0x84, lsl #12  ; [pp+0x84928] TypeArguments: <TextField>
    //     0xfa32b0: ldr             x1, [x1, #0x928]
    // 0xfa32b4: r0 = _TextFieldState()
    //     0xfa32b4: bl              #0xfa3394  ; Allocate_TextFieldStateStub -> _TextFieldState (size=0x44)
    // 0xfa32b8: mov             x1, x0
    // 0xfa32bc: stur            x0, [fp, #-8]
    // 0xfa32c0: r0 = _TextFieldState()
    //     0xfa32c0: bl              #0xfa32dc  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_TextFieldState
    // 0xfa32c4: ldur            x0, [fp, #-8]
    // 0xfa32c8: LeaveFrame
    //     0xfa32c8: mov             SP, fp
    //     0xfa32cc: ldp             fp, lr, [SP], #0x10
    // 0xfa32d0: ret
    //     0xfa32d0: ret             
    // 0xfa32d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa32d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa32d8: b               #0xfa32ac
  }
}
