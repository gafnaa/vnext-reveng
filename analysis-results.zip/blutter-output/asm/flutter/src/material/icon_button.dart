// lib: , url: package:flutter/src/material/icon_button.dart

// class id: 1048898, size: 0x8
class :: {
}

// class id: 5195, size: 0x74, field offset: 0x6c
class _OutlinedIconButtonDefaultsM3 extends ButtonStyle {

  late final ColorScheme _colors; // offset: 0x70

  get _ padding(/* No info */) {
    // ** addr: 0x1141d34, size: 0xc
    // 0x1141d34: r0 = Instance_WidgetStatePropertyAll
    //     0x1141d34: add             x0, PP, #0xab, lsl #12  ; [pp+0xab408] Obj!WidgetStatePropertyAll<EdgeInsetsGeometry>@128a091
    //     0x1141d38: ldr             x0, [x0, #0x408]
    // 0x1141d3c: ret
    //     0x1141d3c: ret             
  }
  get _ iconSize(/* No info */) {
    // ** addr: 0x1151b94, size: 0xc
    // 0x1151b94: r0 = Instance_WidgetStatePropertyAll
    //     0x1151b94: add             x0, PP, #0xab, lsl #12  ; [pp+0xab3f8] Obj!WidgetStatePropertyAll<double>@128a0a1
    //     0x1151b98: ldr             x0, [x0, #0x3f8]
    // 0x1151b9c: ret
    //     0x1151b9c: ret             
  }
  get _ minimumSize(/* No info */) {
    // ** addr: 0x115a87c, size: 0xc
    // 0x115a87c: r0 = Instance_WidgetStatePropertyAll
    //     0x115a87c: add             x0, PP, #0xab, lsl #12  ; [pp+0xab400] Obj!WidgetStatePropertyAll<Size>@128a0d1
    //     0x115a880: ldr             x0, [x0, #0x400]
    // 0x115a884: ret
    //     0x115a884: ret             
  }
  get _ side(/* No info */) {
    // ** addr: 0x11817bc, size: 0x68
    // 0x11817bc: EnterFrame
    //     0x11817bc: stp             fp, lr, [SP, #-0x10]!
    //     0x11817c0: mov             fp, SP
    // 0x11817c4: AllocStack(0x18)
    //     0x11817c4: sub             SP, SP, #0x18
    // 0x11817c8: SetupParameters(_OutlinedIconButtonDefaultsM3 this /* r1 => r1, fp-0x8 */)
    //     0x11817c8: stur            x1, [fp, #-8]
    // 0x11817cc: CheckStackOverflow
    //     0x11817cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11817d0: cmp             SP, x16
    //     0x11817d4: b.ls            #0x118181c
    // 0x11817d8: r1 = 1
    //     0x11817d8: mov             x1, #1
    // 0x11817dc: r0 = AllocateContext()
    //     0x11817dc: bl              #0x13de838  ; AllocateContextStub
    // 0x11817e0: mov             x1, x0
    // 0x11817e4: ldur            x0, [fp, #-8]
    // 0x11817e8: StoreField: r1->field_f = r0
    //     0x11817e8: stur            w0, [x1, #0xf]
    // 0x11817ec: mov             x2, x1
    // 0x11817f0: r1 = Function '<anonymous closure>':.
    //     0x11817f0: add             x1, PP, #0xab, lsl #12  ; [pp+0xab450] AnonymousClosure: (0x1181824), in [package:flutter/src/material/icon_button.dart] _OutlinedIconButtonDefaultsM3::side (0x11817bc)
    //     0x11817f4: ldr             x1, [x1, #0x450]
    // 0x11817f8: r0 = AllocateClosure()
    //     0x11817f8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11817fc: r16 = <BorderSide?>
    //     0x11817fc: add             x16, PP, #0x7d, lsl #12  ; [pp+0x7d4b0] TypeArguments: <BorderSide?>
    //     0x1181800: ldr             x16, [x16, #0x4b0]
    // 0x1181804: stp             x0, x16, [SP]
    // 0x1181808: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1181808: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x118180c: r0 = resolveWith()
    //     0x118180c: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1181810: LeaveFrame
    //     0x1181810: mov             SP, fp
    //     0x1181814: ldp             fp, lr, [SP], #0x10
    // 0x1181818: ret
    //     0x1181818: ret             
    // 0x118181c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x118181c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1181820: b               #0x11817d8
  }
  [closure] BorderSide? <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0x1181824, size: 0x1c4
    // 0x1181824: EnterFrame
    //     0x1181824: stp             fp, lr, [SP, #-0x10]!
    //     0x1181828: mov             fp, SP
    // 0x118182c: AllocStack(0x10)
    //     0x118182c: sub             SP, SP, #0x10
    // 0x1181830: SetupParameters([dynamic _ /* r0 */])
    //     0x1181830: ldr             x0, [fp, #0x18]
    //     0x1181834: ldur            w3, [x0, #0x17]
    //     0x1181838: add             x3, x3, HEAP, lsl #32
    //     0x118183c: stur            x3, [fp, #-8]
    // 0x1181840: CheckStackOverflow
    //     0x1181840: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1181844: cmp             SP, x16
    //     0x1181848: b.ls            #0x11819e0
    // 0x118184c: ldr             x4, [fp, #0x10]
    // 0x1181850: r0 = LoadClassIdInstr(r4)
    //     0x1181850: ldur            x0, [x4, #-1]
    //     0x1181854: ubfx            x0, x0, #0xc, #0x14
    // 0x1181858: mov             x1, x4
    // 0x118185c: r2 = Instance_WidgetState
    //     0x118185c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0x1181860: ldr             x2, [x2, #0x100]
    // 0x1181864: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1181864: mov             x17, #0x2929
    //     0x1181868: movk            x17, #1, lsl #16
    //     0x118186c: add             lr, x0, x17
    //     0x1181870: ldr             lr, [x21, lr, lsl #3]
    //     0x1181874: blr             lr
    // 0x1181878: tbnz            w0, #4, #0x118188c
    // 0x118187c: r0 = Null
    //     0x118187c: mov             x0, NULL
    // 0x1181880: LeaveFrame
    //     0x1181880: mov             SP, fp
    //     0x1181884: ldp             fp, lr, [SP], #0x10
    // 0x1181888: ret
    //     0x1181888: ret             
    // 0x118188c: ldr             x1, [fp, #0x10]
    // 0x1181890: r0 = LoadClassIdInstr(r1)
    //     0x1181890: ldur            x0, [x1, #-1]
    //     0x1181894: ubfx            x0, x0, #0xc, #0x14
    // 0x1181898: r2 = Instance_WidgetState
    //     0x1181898: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0x118189c: ldr             x2, [x2, #0xa70]
    // 0x11818a0: r0 = GDT[cid_x0 + 0x12929]()
    //     0x11818a0: mov             x17, #0x2929
    //     0x11818a4: movk            x17, #1, lsl #16
    //     0x11818a8: add             lr, x0, x17
    //     0x11818ac: ldr             lr, [x21, lr, lsl #3]
    //     0x11818b0: blr             lr
    // 0x11818b4: tbnz            w0, #4, #0x1181948
    // 0x11818b8: ldur            x0, [fp, #-8]
    // 0x11818bc: LoadField: r1 = r0->field_f
    //     0x11818bc: ldur            w1, [x0, #0xf]
    // 0x11818c0: DecompressPointer r1
    //     0x11818c0: add             x1, x1, HEAP, lsl #32
    // 0x11818c4: LoadField: r0 = r1->field_6f
    //     0x11818c4: ldur            w0, [x1, #0x6f]
    // 0x11818c8: DecompressPointer r0
    //     0x11818c8: add             x0, x0, HEAP, lsl #32
    // 0x11818cc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11818d0: cmp             w0, w16
    // 0x11818d4: b.ne            #0x11818e4
    // 0x11818d8: r2 = _colors
    //     0x11818d8: add             x2, PP, #0xab, lsl #12  ; [pp+0xab458] Field <_OutlinedIconButtonDefaultsM3@619331726._colors@619331726>: late final (offset: 0x70)
    //     0x11818dc: ldr             x2, [x2, #0x458]
    // 0x11818e0: r0 = InitLateFinalInstanceField()
    //     0x11818e0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x11818e4: LoadField: r1 = r0->field_7f
    //     0x11818e4: ldur            w1, [x0, #0x7f]
    // 0x11818e8: DecompressPointer r1
    //     0x11818e8: add             x1, x1, HEAP, lsl #32
    // 0x11818ec: r0 = LoadClassIdInstr(r1)
    //     0x11818ec: ldur            x0, [x1, #-1]
    //     0x11818f0: ubfx            x0, x0, #0xc, #0x14
    // 0x11818f4: d0 = 0.120000
    //     0x11818f4: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x11818f8: ldr             d0, [x17, #0xc40]
    // 0x11818fc: r0 = GDT[cid_x0 + -0x1000]()
    //     0x11818fc: sub             lr, x0, #1, lsl #12
    //     0x1181900: ldr             lr, [x21, lr, lsl #3]
    //     0x1181904: blr             lr
    // 0x1181908: stur            x0, [fp, #-0x10]
    // 0x118190c: r0 = BorderSide()
    //     0x118190c: bl              #0x8a73bc  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x1181910: mov             x1, x0
    // 0x1181914: ldur            x0, [fp, #-0x10]
    // 0x1181918: StoreField: r1->field_7 = r0
    //     0x1181918: stur            w0, [x1, #7]
    // 0x118191c: d0 = 1.000000
    //     0x118191c: fmov            d0, #1.00000000
    // 0x1181920: StoreField: r1->field_b = d0
    //     0x1181920: stur            d0, [x1, #0xb]
    // 0x1181924: r2 = Instance_BorderStyle
    //     0x1181924: add             x2, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0x1181928: ldr             x2, [x2, #0xdc8]
    // 0x118192c: StoreField: r1->field_13 = r2
    //     0x118192c: stur            w2, [x1, #0x13]
    // 0x1181930: d1 = -1.000000
    //     0x1181930: fmov            d1, #-1.00000000
    // 0x1181934: ArrayStore: r1[0] = d1  ; List_8
    //     0x1181934: stur            d1, [x1, #0x17]
    // 0x1181938: mov             x0, x1
    // 0x118193c: LeaveFrame
    //     0x118193c: mov             SP, fp
    //     0x1181940: ldp             fp, lr, [SP], #0x10
    // 0x1181944: ret
    //     0x1181944: ret             
    // 0x1181948: ldur            x0, [fp, #-8]
    // 0x118194c: r2 = Instance_BorderStyle
    //     0x118194c: add             x2, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0x1181950: ldr             x2, [x2, #0xdc8]
    // 0x1181954: d0 = 1.000000
    //     0x1181954: fmov            d0, #1.00000000
    // 0x1181958: d1 = -1.000000
    //     0x1181958: fmov            d1, #-1.00000000
    // 0x118195c: LoadField: r1 = r0->field_f
    //     0x118195c: ldur            w1, [x0, #0xf]
    // 0x1181960: DecompressPointer r1
    //     0x1181960: add             x1, x1, HEAP, lsl #32
    // 0x1181964: LoadField: r0 = r1->field_6f
    //     0x1181964: ldur            w0, [x1, #0x6f]
    // 0x1181968: DecompressPointer r0
    //     0x1181968: add             x0, x0, HEAP, lsl #32
    // 0x118196c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1181970: cmp             w0, w16
    // 0x1181974: b.ne            #0x1181984
    // 0x1181978: r2 = _colors
    //     0x1181978: add             x2, PP, #0xab, lsl #12  ; [pp+0xab458] Field <_OutlinedIconButtonDefaultsM3@619331726._colors@619331726>: late final (offset: 0x70)
    //     0x118197c: ldr             x2, [x2, #0x458]
    // 0x1181980: r0 = InitLateFinalInstanceField()
    //     0x1181980: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1181984: LoadField: r1 = r0->field_a7
    //     0x1181984: ldur            w1, [x0, #0xa7]
    // 0x1181988: DecompressPointer r1
    //     0x1181988: add             x1, x1, HEAP, lsl #32
    // 0x118198c: cmp             w1, NULL
    // 0x1181990: b.ne            #0x11819a4
    // 0x1181994: LoadField: r1 = r0->field_cb
    //     0x1181994: ldur            w1, [x0, #0xcb]
    // 0x1181998: DecompressPointer r1
    //     0x1181998: add             x1, x1, HEAP, lsl #32
    // 0x118199c: mov             x0, x1
    // 0x11819a0: b               #0x11819a8
    // 0x11819a4: mov             x0, x1
    // 0x11819a8: stur            x0, [fp, #-8]
    // 0x11819ac: r0 = BorderSide()
    //     0x11819ac: bl              #0x8a73bc  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x11819b0: ldur            x1, [fp, #-8]
    // 0x11819b4: StoreField: r0->field_7 = r1
    //     0x11819b4: stur            w1, [x0, #7]
    // 0x11819b8: d0 = 1.000000
    //     0x11819b8: fmov            d0, #1.00000000
    // 0x11819bc: StoreField: r0->field_b = d0
    //     0x11819bc: stur            d0, [x0, #0xb]
    // 0x11819c0: r1 = Instance_BorderStyle
    //     0x11819c0: add             x1, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0x11819c4: ldr             x1, [x1, #0xdc8]
    // 0x11819c8: StoreField: r0->field_13 = r1
    //     0x11819c8: stur            w1, [x0, #0x13]
    // 0x11819cc: d0 = -1.000000
    //     0x11819cc: fmov            d0, #-1.00000000
    // 0x11819d0: ArrayStore: r0[0] = d0  ; List_8
    //     0x11819d0: stur            d0, [x0, #0x17]
    // 0x11819d4: LeaveFrame
    //     0x11819d4: mov             SP, fp
    //     0x11819d8: ldp             fp, lr, [SP], #0x10
    // 0x11819dc: ret
    //     0x11819dc: ret             
    // 0x11819e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11819e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11819e4: b               #0x118184c
  }
  get _ backgroundColor(/* No info */) {
    // ** addr: 0x1240dc0, size: 0x68
    // 0x1240dc0: EnterFrame
    //     0x1240dc0: stp             fp, lr, [SP, #-0x10]!
    //     0x1240dc4: mov             fp, SP
    // 0x1240dc8: AllocStack(0x18)
    //     0x1240dc8: sub             SP, SP, #0x18
    // 0x1240dcc: SetupParameters(_OutlinedIconButtonDefaultsM3 this /* r1 => r1, fp-0x8 */)
    //     0x1240dcc: stur            x1, [fp, #-8]
    // 0x1240dd0: CheckStackOverflow
    //     0x1240dd0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1240dd4: cmp             SP, x16
    //     0x1240dd8: b.ls            #0x1240e20
    // 0x1240ddc: r1 = 1
    //     0x1240ddc: mov             x1, #1
    // 0x1240de0: r0 = AllocateContext()
    //     0x1240de0: bl              #0x13de838  ; AllocateContextStub
    // 0x1240de4: mov             x1, x0
    // 0x1240de8: ldur            x0, [fp, #-8]
    // 0x1240dec: StoreField: r1->field_f = r0
    //     0x1240dec: stur            w0, [x1, #0xf]
    // 0x1240df0: mov             x2, x1
    // 0x1240df4: r1 = Function '<anonymous closure>':.
    //     0x1240df4: add             x1, PP, #0xab, lsl #12  ; [pp+0xab470] AnonymousClosure: (0x1240e28), in [package:flutter/src/material/icon_button.dart] _OutlinedIconButtonDefaultsM3::backgroundColor (0x1240dc0)
    //     0x1240df8: ldr             x1, [x1, #0x470]
    // 0x1240dfc: r0 = AllocateClosure()
    //     0x1240dfc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1240e00: r16 = <Color?>
    //     0x1240e00: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1240e04: ldr             x16, [x16, #0xa40]
    // 0x1240e08: stp             x0, x16, [SP]
    // 0x1240e0c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1240e0c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1240e10: r0 = resolveWith()
    //     0x1240e10: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1240e14: LeaveFrame
    //     0x1240e14: mov             SP, fp
    //     0x1240e18: ldp             fp, lr, [SP], #0x10
    // 0x1240e1c: ret
    //     0x1240e1c: ret             
    // 0x1240e20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1240e20: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1240e24: b               #0x1240ddc
  }
  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0x1240e28, size: 0x19c
    // 0x1240e28: EnterFrame
    //     0x1240e28: stp             fp, lr, [SP, #-0x10]!
    //     0x1240e2c: mov             fp, SP
    // 0x1240e30: AllocStack(0x8)
    //     0x1240e30: sub             SP, SP, #8
    // 0x1240e34: SetupParameters([dynamic _ /* r0 */])
    //     0x1240e34: ldr             x0, [fp, #0x18]
    //     0x1240e38: ldur            w3, [x0, #0x17]
    //     0x1240e3c: add             x3, x3, HEAP, lsl #32
    //     0x1240e40: stur            x3, [fp, #-8]
    // 0x1240e44: CheckStackOverflow
    //     0x1240e44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1240e48: cmp             SP, x16
    //     0x1240e4c: b.ls            #0x1240fbc
    // 0x1240e50: ldr             x4, [fp, #0x10]
    // 0x1240e54: r0 = LoadClassIdInstr(r4)
    //     0x1240e54: ldur            x0, [x4, #-1]
    //     0x1240e58: ubfx            x0, x0, #0xc, #0x14
    // 0x1240e5c: mov             x1, x4
    // 0x1240e60: r2 = Instance_WidgetState
    //     0x1240e60: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0x1240e64: ldr             x2, [x2, #0xa70]
    // 0x1240e68: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1240e68: mov             x17, #0x2929
    //     0x1240e6c: movk            x17, #1, lsl #16
    //     0x1240e70: add             lr, x0, x17
    //     0x1240e74: ldr             lr, [x21, lr, lsl #3]
    //     0x1240e78: blr             lr
    // 0x1240e7c: tbnz            w0, #4, #0x1240f1c
    // 0x1240e80: ldr             x1, [fp, #0x10]
    // 0x1240e84: r0 = LoadClassIdInstr(r1)
    //     0x1240e84: ldur            x0, [x1, #-1]
    //     0x1240e88: ubfx            x0, x0, #0xc, #0x14
    // 0x1240e8c: r2 = Instance_WidgetState
    //     0x1240e8c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0x1240e90: ldr             x2, [x2, #0x100]
    // 0x1240e94: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1240e94: mov             x17, #0x2929
    //     0x1240e98: movk            x17, #1, lsl #16
    //     0x1240e9c: add             lr, x0, x17
    //     0x1240ea0: ldr             lr, [x21, lr, lsl #3]
    //     0x1240ea4: blr             lr
    // 0x1240ea8: tbnz            w0, #4, #0x1240f08
    // 0x1240eac: ldur            x3, [fp, #-8]
    // 0x1240eb0: LoadField: r1 = r3->field_f
    //     0x1240eb0: ldur            w1, [x3, #0xf]
    // 0x1240eb4: DecompressPointer r1
    //     0x1240eb4: add             x1, x1, HEAP, lsl #32
    // 0x1240eb8: LoadField: r0 = r1->field_6f
    //     0x1240eb8: ldur            w0, [x1, #0x6f]
    // 0x1240ebc: DecompressPointer r0
    //     0x1240ebc: add             x0, x0, HEAP, lsl #32
    // 0x1240ec0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1240ec4: cmp             w0, w16
    // 0x1240ec8: b.ne            #0x1240ed8
    // 0x1240ecc: r2 = _colors
    //     0x1240ecc: add             x2, PP, #0xab, lsl #12  ; [pp+0xab458] Field <_OutlinedIconButtonDefaultsM3@619331726._colors@619331726>: late final (offset: 0x70)
    //     0x1240ed0: ldr             x2, [x2, #0x458]
    // 0x1240ed4: r0 = InitLateFinalInstanceField()
    //     0x1240ed4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1240ed8: LoadField: r1 = r0->field_7f
    //     0x1240ed8: ldur            w1, [x0, #0x7f]
    // 0x1240edc: DecompressPointer r1
    //     0x1240edc: add             x1, x1, HEAP, lsl #32
    // 0x1240ee0: r0 = LoadClassIdInstr(r1)
    //     0x1240ee0: ldur            x0, [x1, #-1]
    //     0x1240ee4: ubfx            x0, x0, #0xc, #0x14
    // 0x1240ee8: d0 = 0.120000
    //     0x1240ee8: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x1240eec: ldr             d0, [x17, #0xc40]
    // 0x1240ef0: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1240ef0: sub             lr, x0, #1, lsl #12
    //     0x1240ef4: ldr             lr, [x21, lr, lsl #3]
    //     0x1240ef8: blr             lr
    // 0x1240efc: LeaveFrame
    //     0x1240efc: mov             SP, fp
    //     0x1240f00: ldp             fp, lr, [SP], #0x10
    // 0x1240f04: ret
    //     0x1240f04: ret             
    // 0x1240f08: r0 = Instance_Color
    //     0x1240f08: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x1240f0c: ldr             x0, [x0, #0x810]
    // 0x1240f10: LeaveFrame
    //     0x1240f10: mov             SP, fp
    //     0x1240f14: ldp             fp, lr, [SP], #0x10
    // 0x1240f18: ret
    //     0x1240f18: ret             
    // 0x1240f1c: ldr             x1, [fp, #0x10]
    // 0x1240f20: ldur            x3, [fp, #-8]
    // 0x1240f24: r0 = LoadClassIdInstr(r1)
    //     0x1240f24: ldur            x0, [x1, #-1]
    //     0x1240f28: ubfx            x0, x0, #0xc, #0x14
    // 0x1240f2c: r2 = Instance_WidgetState
    //     0x1240f2c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0x1240f30: ldr             x2, [x2, #0x100]
    // 0x1240f34: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1240f34: mov             x17, #0x2929
    //     0x1240f38: movk            x17, #1, lsl #16
    //     0x1240f3c: add             lr, x0, x17
    //     0x1240f40: ldr             lr, [x21, lr, lsl #3]
    //     0x1240f44: blr             lr
    // 0x1240f48: tbnz            w0, #4, #0x1240fa8
    // 0x1240f4c: ldur            x0, [fp, #-8]
    // 0x1240f50: LoadField: r1 = r0->field_f
    //     0x1240f50: ldur            w1, [x0, #0xf]
    // 0x1240f54: DecompressPointer r1
    //     0x1240f54: add             x1, x1, HEAP, lsl #32
    // 0x1240f58: LoadField: r0 = r1->field_6f
    //     0x1240f58: ldur            w0, [x1, #0x6f]
    // 0x1240f5c: DecompressPointer r0
    //     0x1240f5c: add             x0, x0, HEAP, lsl #32
    // 0x1240f60: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1240f64: cmp             w0, w16
    // 0x1240f68: b.ne            #0x1240f78
    // 0x1240f6c: r2 = _colors
    //     0x1240f6c: add             x2, PP, #0xab, lsl #12  ; [pp+0xab458] Field <_OutlinedIconButtonDefaultsM3@619331726._colors@619331726>: late final (offset: 0x70)
    //     0x1240f70: ldr             x2, [x2, #0x458]
    // 0x1240f74: r0 = InitLateFinalInstanceField()
    //     0x1240f74: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1240f78: LoadField: r1 = r0->field_b7
    //     0x1240f78: ldur            w1, [x0, #0xb7]
    // 0x1240f7c: DecompressPointer r1
    //     0x1240f7c: add             x1, x1, HEAP, lsl #32
    // 0x1240f80: cmp             w1, NULL
    // 0x1240f84: b.ne            #0x1240f98
    // 0x1240f88: LoadField: r2 = r0->field_7f
    //     0x1240f88: ldur            w2, [x0, #0x7f]
    // 0x1240f8c: DecompressPointer r2
    //     0x1240f8c: add             x2, x2, HEAP, lsl #32
    // 0x1240f90: mov             x0, x2
    // 0x1240f94: b               #0x1240f9c
    // 0x1240f98: mov             x0, x1
    // 0x1240f9c: LeaveFrame
    //     0x1240f9c: mov             SP, fp
    //     0x1240fa0: ldp             fp, lr, [SP], #0x10
    // 0x1240fa4: ret
    //     0x1240fa4: ret             
    // 0x1240fa8: r0 = Instance_Color
    //     0x1240fa8: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x1240fac: ldr             x0, [x0, #0x810]
    // 0x1240fb0: LeaveFrame
    //     0x1240fb0: mov             SP, fp
    //     0x1240fb4: ldp             fp, lr, [SP], #0x10
    // 0x1240fb8: ret
    //     0x1240fb8: ret             
    // 0x1240fbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1240fbc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1240fc0: b               #0x1240e50
  }
  get _ overlayColor(/* No info */) {
    // ** addr: 0x1242e28, size: 0x68
    // 0x1242e28: EnterFrame
    //     0x1242e28: stp             fp, lr, [SP, #-0x10]!
    //     0x1242e2c: mov             fp, SP
    // 0x1242e30: AllocStack(0x18)
    //     0x1242e30: sub             SP, SP, #0x18
    // 0x1242e34: SetupParameters(_OutlinedIconButtonDefaultsM3 this /* r1 => r1, fp-0x8 */)
    //     0x1242e34: stur            x1, [fp, #-8]
    // 0x1242e38: CheckStackOverflow
    //     0x1242e38: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1242e3c: cmp             SP, x16
    //     0x1242e40: b.ls            #0x1242e88
    // 0x1242e44: r1 = 1
    //     0x1242e44: mov             x1, #1
    // 0x1242e48: r0 = AllocateContext()
    //     0x1242e48: bl              #0x13de838  ; AllocateContextStub
    // 0x1242e4c: mov             x1, x0
    // 0x1242e50: ldur            x0, [fp, #-8]
    // 0x1242e54: StoreField: r1->field_f = r0
    //     0x1242e54: stur            w0, [x1, #0xf]
    // 0x1242e58: mov             x2, x1
    // 0x1242e5c: r1 = Function '<anonymous closure>':.
    //     0x1242e5c: add             x1, PP, #0xab, lsl #12  ; [pp+0xab460] AnonymousClosure: (0x1242e90), in [package:flutter/src/material/icon_button.dart] _OutlinedIconButtonDefaultsM3::overlayColor (0x1242e28)
    //     0x1242e60: ldr             x1, [x1, #0x460]
    // 0x1242e64: r0 = AllocateClosure()
    //     0x1242e64: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1242e68: r16 = <Color?>
    //     0x1242e68: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1242e6c: ldr             x16, [x16, #0xa40]
    // 0x1242e70: stp             x0, x16, [SP]
    // 0x1242e74: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1242e74: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1242e78: r0 = resolveWith()
    //     0x1242e78: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1242e7c: LeaveFrame
    //     0x1242e7c: mov             SP, fp
    //     0x1242e80: ldp             fp, lr, [SP], #0x10
    // 0x1242e84: ret
    //     0x1242e84: ret             
    // 0x1242e88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1242e88: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1242e8c: b               #0x1242e44
  }
  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0x1242e90, size: 0x424
    // 0x1242e90: EnterFrame
    //     0x1242e90: stp             fp, lr, [SP, #-0x10]!
    //     0x1242e94: mov             fp, SP
    // 0x1242e98: AllocStack(0x8)
    //     0x1242e98: sub             SP, SP, #8
    // 0x1242e9c: SetupParameters([dynamic _ /* r0 */])
    //     0x1242e9c: ldr             x0, [fp, #0x18]
    //     0x1242ea0: ldur            w3, [x0, #0x17]
    //     0x1242ea4: add             x3, x3, HEAP, lsl #32
    //     0x1242ea8: stur            x3, [fp, #-8]
    // 0x1242eac: CheckStackOverflow
    //     0x1242eac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1242eb0: cmp             SP, x16
    //     0x1242eb4: b.ls            #0x12432ac
    // 0x1242eb8: ldr             x4, [fp, #0x10]
    // 0x1242ebc: r0 = LoadClassIdInstr(r4)
    //     0x1242ebc: ldur            x0, [x4, #-1]
    //     0x1242ec0: ubfx            x0, x0, #0xc, #0x14
    // 0x1242ec4: mov             x1, x4
    // 0x1242ec8: r2 = Instance_WidgetState
    //     0x1242ec8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0x1242ecc: ldr             x2, [x2, #0x100]
    // 0x1242ed0: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1242ed0: mov             x17, #0x2929
    //     0x1242ed4: movk            x17, #1, lsl #16
    //     0x1242ed8: add             lr, x0, x17
    //     0x1242edc: ldr             lr, [x21, lr, lsl #3]
    //     0x1242ee0: blr             lr
    // 0x1242ee4: tbnz            w0, #4, #0x12430cc
    // 0x1242ee8: ldr             x3, [fp, #0x10]
    // 0x1242eec: r0 = LoadClassIdInstr(r3)
    //     0x1242eec: ldur            x0, [x3, #-1]
    //     0x1242ef0: ubfx            x0, x0, #0xc, #0x14
    // 0x1242ef4: mov             x1, x3
    // 0x1242ef8: r2 = Instance_WidgetState
    //     0x1242ef8: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0x1242efc: ldr             x2, [x2, #0xa48]
    // 0x1242f00: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1242f00: mov             x17, #0x2929
    //     0x1242f04: movk            x17, #1, lsl #16
    //     0x1242f08: add             lr, x0, x17
    //     0x1242f0c: ldr             lr, [x21, lr, lsl #3]
    //     0x1242f10: blr             lr
    // 0x1242f14: tbnz            w0, #4, #0x1242f84
    // 0x1242f18: ldur            x3, [fp, #-8]
    // 0x1242f1c: LoadField: r1 = r3->field_f
    //     0x1242f1c: ldur            w1, [x3, #0xf]
    // 0x1242f20: DecompressPointer r1
    //     0x1242f20: add             x1, x1, HEAP, lsl #32
    // 0x1242f24: LoadField: r0 = r1->field_6f
    //     0x1242f24: ldur            w0, [x1, #0x6f]
    // 0x1242f28: DecompressPointer r0
    //     0x1242f28: add             x0, x0, HEAP, lsl #32
    // 0x1242f2c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1242f30: cmp             w0, w16
    // 0x1242f34: b.ne            #0x1242f44
    // 0x1242f38: r2 = _colors
    //     0x1242f38: add             x2, PP, #0xab, lsl #12  ; [pp+0xab458] Field <_OutlinedIconButtonDefaultsM3@619331726._colors@619331726>: late final (offset: 0x70)
    //     0x1242f3c: ldr             x2, [x2, #0x458]
    // 0x1242f40: r0 = InitLateFinalInstanceField()
    //     0x1242f40: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1242f44: LoadField: r1 = r0->field_bb
    //     0x1242f44: ldur            w1, [x0, #0xbb]
    // 0x1242f48: DecompressPointer r1
    //     0x1242f48: add             x1, x1, HEAP, lsl #32
    // 0x1242f4c: cmp             w1, NULL
    // 0x1242f50: b.ne            #0x1242f5c
    // 0x1242f54: LoadField: r1 = r0->field_7b
    //     0x1242f54: ldur            w1, [x0, #0x7b]
    // 0x1242f58: DecompressPointer r1
    //     0x1242f58: add             x1, x1, HEAP, lsl #32
    // 0x1242f5c: r0 = LoadClassIdInstr(r1)
    //     0x1242f5c: ldur            x0, [x1, #-1]
    //     0x1242f60: ubfx            x0, x0, #0xc, #0x14
    // 0x1242f64: d0 = 0.100000
    //     0x1242f64: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0x1242f68: ldr             d0, [x17, #0x1e0]
    // 0x1242f6c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1242f6c: sub             lr, x0, #1, lsl #12
    //     0x1242f70: ldr             lr, [x21, lr, lsl #3]
    //     0x1242f74: blr             lr
    // 0x1242f78: LeaveFrame
    //     0x1242f78: mov             SP, fp
    //     0x1242f7c: ldp             fp, lr, [SP], #0x10
    // 0x1242f80: ret
    //     0x1242f80: ret             
    // 0x1242f84: ldr             x4, [fp, #0x10]
    // 0x1242f88: ldur            x3, [fp, #-8]
    // 0x1242f8c: r0 = LoadClassIdInstr(r4)
    //     0x1242f8c: ldur            x0, [x4, #-1]
    //     0x1242f90: ubfx            x0, x0, #0xc, #0x14
    // 0x1242f94: mov             x1, x4
    // 0x1242f98: r2 = Instance_WidgetState
    //     0x1242f98: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0x1242f9c: ldr             x2, [x2, #0xa50]
    // 0x1242fa0: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1242fa0: mov             x17, #0x2929
    //     0x1242fa4: movk            x17, #1, lsl #16
    //     0x1242fa8: add             lr, x0, x17
    //     0x1242fac: ldr             lr, [x21, lr, lsl #3]
    //     0x1242fb0: blr             lr
    // 0x1242fb4: tbnz            w0, #4, #0x1243024
    // 0x1242fb8: ldur            x3, [fp, #-8]
    // 0x1242fbc: LoadField: r1 = r3->field_f
    //     0x1242fbc: ldur            w1, [x3, #0xf]
    // 0x1242fc0: DecompressPointer r1
    //     0x1242fc0: add             x1, x1, HEAP, lsl #32
    // 0x1242fc4: LoadField: r0 = r1->field_6f
    //     0x1242fc4: ldur            w0, [x1, #0x6f]
    // 0x1242fc8: DecompressPointer r0
    //     0x1242fc8: add             x0, x0, HEAP, lsl #32
    // 0x1242fcc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1242fd0: cmp             w0, w16
    // 0x1242fd4: b.ne            #0x1242fe4
    // 0x1242fd8: r2 = _colors
    //     0x1242fd8: add             x2, PP, #0xab, lsl #12  ; [pp+0xab458] Field <_OutlinedIconButtonDefaultsM3@619331726._colors@619331726>: late final (offset: 0x70)
    //     0x1242fdc: ldr             x2, [x2, #0x458]
    // 0x1242fe0: r0 = InitLateFinalInstanceField()
    //     0x1242fe0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1242fe4: LoadField: r1 = r0->field_bb
    //     0x1242fe4: ldur            w1, [x0, #0xbb]
    // 0x1242fe8: DecompressPointer r1
    //     0x1242fe8: add             x1, x1, HEAP, lsl #32
    // 0x1242fec: cmp             w1, NULL
    // 0x1242ff0: b.ne            #0x1242ffc
    // 0x1242ff4: LoadField: r1 = r0->field_7b
    //     0x1242ff4: ldur            w1, [x0, #0x7b]
    // 0x1242ff8: DecompressPointer r1
    //     0x1242ff8: add             x1, x1, HEAP, lsl #32
    // 0x1242ffc: r0 = LoadClassIdInstr(r1)
    //     0x1242ffc: ldur            x0, [x1, #-1]
    //     0x1243000: ubfx            x0, x0, #0xc, #0x14
    // 0x1243004: d0 = 0.080000
    //     0x1243004: add             x17, PP, #0x15, lsl #12  ; [pp+0x15a58] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x1243008: ldr             d0, [x17, #0xa58]
    // 0x124300c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x124300c: sub             lr, x0, #1, lsl #12
    //     0x1243010: ldr             lr, [x21, lr, lsl #3]
    //     0x1243014: blr             lr
    // 0x1243018: LeaveFrame
    //     0x1243018: mov             SP, fp
    //     0x124301c: ldp             fp, lr, [SP], #0x10
    // 0x1243020: ret
    //     0x1243020: ret             
    // 0x1243024: ldr             x4, [fp, #0x10]
    // 0x1243028: ldur            x3, [fp, #-8]
    // 0x124302c: r0 = LoadClassIdInstr(r4)
    //     0x124302c: ldur            x0, [x4, #-1]
    //     0x1243030: ubfx            x0, x0, #0xc, #0x14
    // 0x1243034: mov             x1, x4
    // 0x1243038: r2 = Instance_WidgetState
    //     0x1243038: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0x124303c: ldr             x2, [x2, #0xa60]
    // 0x1243040: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1243040: mov             x17, #0x2929
    //     0x1243044: movk            x17, #1, lsl #16
    //     0x1243048: add             lr, x0, x17
    //     0x124304c: ldr             lr, [x21, lr, lsl #3]
    //     0x1243050: blr             lr
    // 0x1243054: tbnz            w0, #4, #0x12430c4
    // 0x1243058: ldur            x3, [fp, #-8]
    // 0x124305c: LoadField: r1 = r3->field_f
    //     0x124305c: ldur            w1, [x3, #0xf]
    // 0x1243060: DecompressPointer r1
    //     0x1243060: add             x1, x1, HEAP, lsl #32
    // 0x1243064: LoadField: r0 = r1->field_6f
    //     0x1243064: ldur            w0, [x1, #0x6f]
    // 0x1243068: DecompressPointer r0
    //     0x1243068: add             x0, x0, HEAP, lsl #32
    // 0x124306c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1243070: cmp             w0, w16
    // 0x1243074: b.ne            #0x1243084
    // 0x1243078: r2 = _colors
    //     0x1243078: add             x2, PP, #0xab, lsl #12  ; [pp+0xab458] Field <_OutlinedIconButtonDefaultsM3@619331726._colors@619331726>: late final (offset: 0x70)
    //     0x124307c: ldr             x2, [x2, #0x458]
    // 0x1243080: r0 = InitLateFinalInstanceField()
    //     0x1243080: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1243084: LoadField: r1 = r0->field_bb
    //     0x1243084: ldur            w1, [x0, #0xbb]
    // 0x1243088: DecompressPointer r1
    //     0x1243088: add             x1, x1, HEAP, lsl #32
    // 0x124308c: cmp             w1, NULL
    // 0x1243090: b.ne            #0x124309c
    // 0x1243094: LoadField: r1 = r0->field_7b
    //     0x1243094: ldur            w1, [x0, #0x7b]
    // 0x1243098: DecompressPointer r1
    //     0x1243098: add             x1, x1, HEAP, lsl #32
    // 0x124309c: r0 = LoadClassIdInstr(r1)
    //     0x124309c: ldur            x0, [x1, #-1]
    //     0x12430a0: ubfx            x0, x0, #0xc, #0x14
    // 0x12430a4: d0 = 0.080000
    //     0x12430a4: add             x17, PP, #0x15, lsl #12  ; [pp+0x15a58] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x12430a8: ldr             d0, [x17, #0xa58]
    // 0x12430ac: r0 = GDT[cid_x0 + -0x1000]()
    //     0x12430ac: sub             lr, x0, #1, lsl #12
    //     0x12430b0: ldr             lr, [x21, lr, lsl #3]
    //     0x12430b4: blr             lr
    // 0x12430b8: LeaveFrame
    //     0x12430b8: mov             SP, fp
    //     0x12430bc: ldp             fp, lr, [SP], #0x10
    // 0x12430c0: ret
    //     0x12430c0: ret             
    // 0x12430c4: ldur            x3, [fp, #-8]
    // 0x12430c8: b               #0x12430d0
    // 0x12430cc: ldur            x3, [fp, #-8]
    // 0x12430d0: ldr             x4, [fp, #0x10]
    // 0x12430d4: r0 = LoadClassIdInstr(r4)
    //     0x12430d4: ldur            x0, [x4, #-1]
    //     0x12430d8: ubfx            x0, x0, #0xc, #0x14
    // 0x12430dc: mov             x1, x4
    // 0x12430e0: r2 = Instance_WidgetState
    //     0x12430e0: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0x12430e4: ldr             x2, [x2, #0xa48]
    // 0x12430e8: r0 = GDT[cid_x0 + 0x12929]()
    //     0x12430e8: mov             x17, #0x2929
    //     0x12430ec: movk            x17, #1, lsl #16
    //     0x12430f0: add             lr, x0, x17
    //     0x12430f4: ldr             lr, [x21, lr, lsl #3]
    //     0x12430f8: blr             lr
    // 0x12430fc: tbnz            w0, #4, #0x124315c
    // 0x1243100: ldur            x3, [fp, #-8]
    // 0x1243104: LoadField: r1 = r3->field_f
    //     0x1243104: ldur            w1, [x3, #0xf]
    // 0x1243108: DecompressPointer r1
    //     0x1243108: add             x1, x1, HEAP, lsl #32
    // 0x124310c: LoadField: r0 = r1->field_6f
    //     0x124310c: ldur            w0, [x1, #0x6f]
    // 0x1243110: DecompressPointer r0
    //     0x1243110: add             x0, x0, HEAP, lsl #32
    // 0x1243114: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1243118: cmp             w0, w16
    // 0x124311c: b.ne            #0x124312c
    // 0x1243120: r2 = _colors
    //     0x1243120: add             x2, PP, #0xab, lsl #12  ; [pp+0xab458] Field <_OutlinedIconButtonDefaultsM3@619331726._colors@619331726>: late final (offset: 0x70)
    //     0x1243124: ldr             x2, [x2, #0x458]
    // 0x1243128: r0 = InitLateFinalInstanceField()
    //     0x1243128: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x124312c: LoadField: r1 = r0->field_7f
    //     0x124312c: ldur            w1, [x0, #0x7f]
    // 0x1243130: DecompressPointer r1
    //     0x1243130: add             x1, x1, HEAP, lsl #32
    // 0x1243134: r0 = LoadClassIdInstr(r1)
    //     0x1243134: ldur            x0, [x1, #-1]
    //     0x1243138: ubfx            x0, x0, #0xc, #0x14
    // 0x124313c: d0 = 0.100000
    //     0x124313c: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0x1243140: ldr             d0, [x17, #0x1e0]
    // 0x1243144: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1243144: sub             lr, x0, #1, lsl #12
    //     0x1243148: ldr             lr, [x21, lr, lsl #3]
    //     0x124314c: blr             lr
    // 0x1243150: LeaveFrame
    //     0x1243150: mov             SP, fp
    //     0x1243154: ldp             fp, lr, [SP], #0x10
    // 0x1243158: ret
    //     0x1243158: ret             
    // 0x124315c: ldr             x4, [fp, #0x10]
    // 0x1243160: ldur            x3, [fp, #-8]
    // 0x1243164: r0 = LoadClassIdInstr(r4)
    //     0x1243164: ldur            x0, [x4, #-1]
    //     0x1243168: ubfx            x0, x0, #0xc, #0x14
    // 0x124316c: mov             x1, x4
    // 0x1243170: r2 = Instance_WidgetState
    //     0x1243170: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0x1243174: ldr             x2, [x2, #0xa50]
    // 0x1243178: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1243178: mov             x17, #0x2929
    //     0x124317c: movk            x17, #1, lsl #16
    //     0x1243180: add             lr, x0, x17
    //     0x1243184: ldr             lr, [x21, lr, lsl #3]
    //     0x1243188: blr             lr
    // 0x124318c: tbnz            w0, #4, #0x12431fc
    // 0x1243190: ldur            x3, [fp, #-8]
    // 0x1243194: LoadField: r1 = r3->field_f
    //     0x1243194: ldur            w1, [x3, #0xf]
    // 0x1243198: DecompressPointer r1
    //     0x1243198: add             x1, x1, HEAP, lsl #32
    // 0x124319c: LoadField: r0 = r1->field_6f
    //     0x124319c: ldur            w0, [x1, #0x6f]
    // 0x12431a0: DecompressPointer r0
    //     0x12431a0: add             x0, x0, HEAP, lsl #32
    // 0x12431a4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12431a8: cmp             w0, w16
    // 0x12431ac: b.ne            #0x12431bc
    // 0x12431b0: r2 = _colors
    //     0x12431b0: add             x2, PP, #0xab, lsl #12  ; [pp+0xab458] Field <_OutlinedIconButtonDefaultsM3@619331726._colors@619331726>: late final (offset: 0x70)
    //     0x12431b4: ldr             x2, [x2, #0x458]
    // 0x12431b8: r0 = InitLateFinalInstanceField()
    //     0x12431b8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12431bc: LoadField: r1 = r0->field_a3
    //     0x12431bc: ldur            w1, [x0, #0xa3]
    // 0x12431c0: DecompressPointer r1
    //     0x12431c0: add             x1, x1, HEAP, lsl #32
    // 0x12431c4: cmp             w1, NULL
    // 0x12431c8: b.ne            #0x12431d4
    // 0x12431cc: LoadField: r1 = r0->field_7f
    //     0x12431cc: ldur            w1, [x0, #0x7f]
    // 0x12431d0: DecompressPointer r1
    //     0x12431d0: add             x1, x1, HEAP, lsl #32
    // 0x12431d4: r0 = LoadClassIdInstr(r1)
    //     0x12431d4: ldur            x0, [x1, #-1]
    //     0x12431d8: ubfx            x0, x0, #0xc, #0x14
    // 0x12431dc: d0 = 0.080000
    //     0x12431dc: add             x17, PP, #0x15, lsl #12  ; [pp+0x15a58] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x12431e0: ldr             d0, [x17, #0xa58]
    // 0x12431e4: r0 = GDT[cid_x0 + -0x1000]()
    //     0x12431e4: sub             lr, x0, #1, lsl #12
    //     0x12431e8: ldr             lr, [x21, lr, lsl #3]
    //     0x12431ec: blr             lr
    // 0x12431f0: LeaveFrame
    //     0x12431f0: mov             SP, fp
    //     0x12431f4: ldp             fp, lr, [SP], #0x10
    // 0x12431f8: ret
    //     0x12431f8: ret             
    // 0x12431fc: ldr             x1, [fp, #0x10]
    // 0x1243200: ldur            x3, [fp, #-8]
    // 0x1243204: r0 = LoadClassIdInstr(r1)
    //     0x1243204: ldur            x0, [x1, #-1]
    //     0x1243208: ubfx            x0, x0, #0xc, #0x14
    // 0x124320c: r2 = Instance_WidgetState
    //     0x124320c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0x1243210: ldr             x2, [x2, #0xa60]
    // 0x1243214: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1243214: mov             x17, #0x2929
    //     0x1243218: movk            x17, #1, lsl #16
    //     0x124321c: add             lr, x0, x17
    //     0x1243220: ldr             lr, [x21, lr, lsl #3]
    //     0x1243224: blr             lr
    // 0x1243228: tbnz            w0, #4, #0x1243298
    // 0x124322c: ldur            x0, [fp, #-8]
    // 0x1243230: LoadField: r1 = r0->field_f
    //     0x1243230: ldur            w1, [x0, #0xf]
    // 0x1243234: DecompressPointer r1
    //     0x1243234: add             x1, x1, HEAP, lsl #32
    // 0x1243238: LoadField: r0 = r1->field_6f
    //     0x1243238: ldur            w0, [x1, #0x6f]
    // 0x124323c: DecompressPointer r0
    //     0x124323c: add             x0, x0, HEAP, lsl #32
    // 0x1243240: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1243244: cmp             w0, w16
    // 0x1243248: b.ne            #0x1243258
    // 0x124324c: r2 = _colors
    //     0x124324c: add             x2, PP, #0xab, lsl #12  ; [pp+0xab458] Field <_OutlinedIconButtonDefaultsM3@619331726._colors@619331726>: late final (offset: 0x70)
    //     0x1243250: ldr             x2, [x2, #0x458]
    // 0x1243254: r0 = InitLateFinalInstanceField()
    //     0x1243254: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1243258: LoadField: r1 = r0->field_a3
    //     0x1243258: ldur            w1, [x0, #0xa3]
    // 0x124325c: DecompressPointer r1
    //     0x124325c: add             x1, x1, HEAP, lsl #32
    // 0x1243260: cmp             w1, NULL
    // 0x1243264: b.ne            #0x1243270
    // 0x1243268: LoadField: r1 = r0->field_7f
    //     0x1243268: ldur            w1, [x0, #0x7f]
    // 0x124326c: DecompressPointer r1
    //     0x124326c: add             x1, x1, HEAP, lsl #32
    // 0x1243270: r0 = LoadClassIdInstr(r1)
    //     0x1243270: ldur            x0, [x1, #-1]
    //     0x1243274: ubfx            x0, x0, #0xc, #0x14
    // 0x1243278: d0 = 0.080000
    //     0x1243278: add             x17, PP, #0x15, lsl #12  ; [pp+0x15a58] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x124327c: ldr             d0, [x17, #0xa58]
    // 0x1243280: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1243280: sub             lr, x0, #1, lsl #12
    //     0x1243284: ldr             lr, [x21, lr, lsl #3]
    //     0x1243288: blr             lr
    // 0x124328c: LeaveFrame
    //     0x124328c: mov             SP, fp
    //     0x1243290: ldp             fp, lr, [SP], #0x10
    // 0x1243294: ret
    //     0x1243294: ret             
    // 0x1243298: r0 = Instance_Color
    //     0x1243298: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x124329c: ldr             x0, [x0, #0x810]
    // 0x12432a0: LeaveFrame
    //     0x12432a0: mov             SP, fp
    //     0x12432a4: ldp             fp, lr, [SP], #0x10
    // 0x12432a8: ret
    //     0x12432a8: ret             
    // 0x12432ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12432ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12432b0: b               #0x1242eb8
  }
  get _ visualDensity(/* No info */) {
    // ** addr: 0x1245f38, size: 0xc
    // 0x1245f38: r0 = Instance_VisualDensity
    //     0x1245f38: add             x0, PP, #0x12, lsl #12  ; [pp+0x12ef0] Obj!VisualDensity@12b1d61
    //     0x1245f3c: ldr             x0, [x0, #0xef0]
    // 0x1245f40: ret
    //     0x1245f40: ret             
  }
  get _ foregroundColor(/* No info */) {
    // ** addr: 0x1249d04, size: 0x68
    // 0x1249d04: EnterFrame
    //     0x1249d04: stp             fp, lr, [SP, #-0x10]!
    //     0x1249d08: mov             fp, SP
    // 0x1249d0c: AllocStack(0x18)
    //     0x1249d0c: sub             SP, SP, #0x18
    // 0x1249d10: SetupParameters(_OutlinedIconButtonDefaultsM3 this /* r1 => r1, fp-0x8 */)
    //     0x1249d10: stur            x1, [fp, #-8]
    // 0x1249d14: CheckStackOverflow
    //     0x1249d14: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1249d18: cmp             SP, x16
    //     0x1249d1c: b.ls            #0x1249d64
    // 0x1249d20: r1 = 1
    //     0x1249d20: mov             x1, #1
    // 0x1249d24: r0 = AllocateContext()
    //     0x1249d24: bl              #0x13de838  ; AllocateContextStub
    // 0x1249d28: mov             x1, x0
    // 0x1249d2c: ldur            x0, [fp, #-8]
    // 0x1249d30: StoreField: r1->field_f = r0
    //     0x1249d30: stur            w0, [x1, #0xf]
    // 0x1249d34: mov             x2, x1
    // 0x1249d38: r1 = Function '<anonymous closure>':.
    //     0x1249d38: add             x1, PP, #0xab, lsl #12  ; [pp+0xab468] AnonymousClosure: (0x1249d6c), in [package:flutter/src/material/icon_button.dart] _OutlinedIconButtonDefaultsM3::foregroundColor (0x1249d04)
    //     0x1249d3c: ldr             x1, [x1, #0x468]
    // 0x1249d40: r0 = AllocateClosure()
    //     0x1249d40: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1249d44: r16 = <Color?>
    //     0x1249d44: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1249d48: ldr             x16, [x16, #0xa40]
    // 0x1249d4c: stp             x0, x16, [SP]
    // 0x1249d50: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1249d50: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1249d54: r0 = resolveWith()
    //     0x1249d54: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1249d58: LeaveFrame
    //     0x1249d58: mov             SP, fp
    //     0x1249d5c: ldp             fp, lr, [SP], #0x10
    // 0x1249d60: ret
    //     0x1249d60: ret             
    // 0x1249d64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1249d64: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1249d68: b               #0x1249d20
  }
  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0x1249d6c, size: 0x1a4
    // 0x1249d6c: EnterFrame
    //     0x1249d6c: stp             fp, lr, [SP, #-0x10]!
    //     0x1249d70: mov             fp, SP
    // 0x1249d74: AllocStack(0x8)
    //     0x1249d74: sub             SP, SP, #8
    // 0x1249d78: SetupParameters([dynamic _ /* r0 */])
    //     0x1249d78: ldr             x0, [fp, #0x18]
    //     0x1249d7c: ldur            w3, [x0, #0x17]
    //     0x1249d80: add             x3, x3, HEAP, lsl #32
    //     0x1249d84: stur            x3, [fp, #-8]
    // 0x1249d88: CheckStackOverflow
    //     0x1249d88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1249d8c: cmp             SP, x16
    //     0x1249d90: b.ls            #0x1249f08
    // 0x1249d94: ldr             x4, [fp, #0x10]
    // 0x1249d98: r0 = LoadClassIdInstr(r4)
    //     0x1249d98: ldur            x0, [x4, #-1]
    //     0x1249d9c: ubfx            x0, x0, #0xc, #0x14
    // 0x1249da0: mov             x1, x4
    // 0x1249da4: r2 = Instance_WidgetState
    //     0x1249da4: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0x1249da8: ldr             x2, [x2, #0xa70]
    // 0x1249dac: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1249dac: mov             x17, #0x2929
    //     0x1249db0: movk            x17, #1, lsl #16
    //     0x1249db4: add             lr, x0, x17
    //     0x1249db8: ldr             lr, [x21, lr, lsl #3]
    //     0x1249dbc: blr             lr
    // 0x1249dc0: tbnz            w0, #4, #0x1249e20
    // 0x1249dc4: ldur            x3, [fp, #-8]
    // 0x1249dc8: LoadField: r1 = r3->field_f
    //     0x1249dc8: ldur            w1, [x3, #0xf]
    // 0x1249dcc: DecompressPointer r1
    //     0x1249dcc: add             x1, x1, HEAP, lsl #32
    // 0x1249dd0: LoadField: r0 = r1->field_6f
    //     0x1249dd0: ldur            w0, [x1, #0x6f]
    // 0x1249dd4: DecompressPointer r0
    //     0x1249dd4: add             x0, x0, HEAP, lsl #32
    // 0x1249dd8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1249ddc: cmp             w0, w16
    // 0x1249de0: b.ne            #0x1249df0
    // 0x1249de4: r2 = _colors
    //     0x1249de4: add             x2, PP, #0xab, lsl #12  ; [pp+0xab458] Field <_OutlinedIconButtonDefaultsM3@619331726._colors@619331726>: late final (offset: 0x70)
    //     0x1249de8: ldr             x2, [x2, #0x458]
    // 0x1249dec: r0 = InitLateFinalInstanceField()
    //     0x1249dec: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1249df0: LoadField: r1 = r0->field_7f
    //     0x1249df0: ldur            w1, [x0, #0x7f]
    // 0x1249df4: DecompressPointer r1
    //     0x1249df4: add             x1, x1, HEAP, lsl #32
    // 0x1249df8: r0 = LoadClassIdInstr(r1)
    //     0x1249df8: ldur            x0, [x1, #-1]
    //     0x1249dfc: ubfx            x0, x0, #0xc, #0x14
    // 0x1249e00: d0 = 0.380000
    //     0x1249e00: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0x1249e04: ldr             d0, [x17, #0x1f0]
    // 0x1249e08: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1249e08: sub             lr, x0, #1, lsl #12
    //     0x1249e0c: ldr             lr, [x21, lr, lsl #3]
    //     0x1249e10: blr             lr
    // 0x1249e14: LeaveFrame
    //     0x1249e14: mov             SP, fp
    //     0x1249e18: ldp             fp, lr, [SP], #0x10
    // 0x1249e1c: ret
    //     0x1249e1c: ret             
    // 0x1249e20: ldr             x1, [fp, #0x10]
    // 0x1249e24: ldur            x3, [fp, #-8]
    // 0x1249e28: r0 = LoadClassIdInstr(r1)
    //     0x1249e28: ldur            x0, [x1, #-1]
    //     0x1249e2c: ubfx            x0, x0, #0xc, #0x14
    // 0x1249e30: r2 = Instance_WidgetState
    //     0x1249e30: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0x1249e34: ldr             x2, [x2, #0x100]
    // 0x1249e38: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1249e38: mov             x17, #0x2929
    //     0x1249e3c: movk            x17, #1, lsl #16
    //     0x1249e40: add             lr, x0, x17
    //     0x1249e44: ldr             lr, [x21, lr, lsl #3]
    //     0x1249e48: blr             lr
    // 0x1249e4c: tbnz            w0, #4, #0x1249eac
    // 0x1249e50: ldur            x0, [fp, #-8]
    // 0x1249e54: LoadField: r1 = r0->field_f
    //     0x1249e54: ldur            w1, [x0, #0xf]
    // 0x1249e58: DecompressPointer r1
    //     0x1249e58: add             x1, x1, HEAP, lsl #32
    // 0x1249e5c: LoadField: r0 = r1->field_6f
    //     0x1249e5c: ldur            w0, [x1, #0x6f]
    // 0x1249e60: DecompressPointer r0
    //     0x1249e60: add             x0, x0, HEAP, lsl #32
    // 0x1249e64: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1249e68: cmp             w0, w16
    // 0x1249e6c: b.ne            #0x1249e7c
    // 0x1249e70: r2 = _colors
    //     0x1249e70: add             x2, PP, #0xab, lsl #12  ; [pp+0xab458] Field <_OutlinedIconButtonDefaultsM3@619331726._colors@619331726>: late final (offset: 0x70)
    //     0x1249e74: ldr             x2, [x2, #0x458]
    // 0x1249e78: r0 = InitLateFinalInstanceField()
    //     0x1249e78: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1249e7c: LoadField: r1 = r0->field_bb
    //     0x1249e7c: ldur            w1, [x0, #0xbb]
    // 0x1249e80: DecompressPointer r1
    //     0x1249e80: add             x1, x1, HEAP, lsl #32
    // 0x1249e84: cmp             w1, NULL
    // 0x1249e88: b.ne            #0x1249e9c
    // 0x1249e8c: LoadField: r1 = r0->field_7b
    //     0x1249e8c: ldur            w1, [x0, #0x7b]
    // 0x1249e90: DecompressPointer r1
    //     0x1249e90: add             x1, x1, HEAP, lsl #32
    // 0x1249e94: mov             x0, x1
    // 0x1249e98: b               #0x1249ea0
    // 0x1249e9c: mov             x0, x1
    // 0x1249ea0: LeaveFrame
    //     0x1249ea0: mov             SP, fp
    //     0x1249ea4: ldp             fp, lr, [SP], #0x10
    // 0x1249ea8: ret
    //     0x1249ea8: ret             
    // 0x1249eac: ldur            x0, [fp, #-8]
    // 0x1249eb0: LoadField: r1 = r0->field_f
    //     0x1249eb0: ldur            w1, [x0, #0xf]
    // 0x1249eb4: DecompressPointer r1
    //     0x1249eb4: add             x1, x1, HEAP, lsl #32
    // 0x1249eb8: LoadField: r0 = r1->field_6f
    //     0x1249eb8: ldur            w0, [x1, #0x6f]
    // 0x1249ebc: DecompressPointer r0
    //     0x1249ebc: add             x0, x0, HEAP, lsl #32
    // 0x1249ec0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1249ec4: cmp             w0, w16
    // 0x1249ec8: b.ne            #0x1249ed8
    // 0x1249ecc: r2 = _colors
    //     0x1249ecc: add             x2, PP, #0xab, lsl #12  ; [pp+0xab458] Field <_OutlinedIconButtonDefaultsM3@619331726._colors@619331726>: late final (offset: 0x70)
    //     0x1249ed0: ldr             x2, [x2, #0x458]
    // 0x1249ed4: r0 = InitLateFinalInstanceField()
    //     0x1249ed4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1249ed8: LoadField: r1 = r0->field_a3
    //     0x1249ed8: ldur            w1, [x0, #0xa3]
    // 0x1249edc: DecompressPointer r1
    //     0x1249edc: add             x1, x1, HEAP, lsl #32
    // 0x1249ee0: cmp             w1, NULL
    // 0x1249ee4: b.ne            #0x1249ef8
    // 0x1249ee8: LoadField: r2 = r0->field_7f
    //     0x1249ee8: ldur            w2, [x0, #0x7f]
    // 0x1249eec: DecompressPointer r2
    //     0x1249eec: add             x2, x2, HEAP, lsl #32
    // 0x1249ef0: mov             x0, x2
    // 0x1249ef4: b               #0x1249efc
    // 0x1249ef8: mov             x0, x1
    // 0x1249efc: LeaveFrame
    //     0x1249efc: mov             SP, fp
    //     0x1249f00: ldp             fp, lr, [SP], #0x10
    // 0x1249f04: ret
    //     0x1249f04: ret             
    // 0x1249f08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1249f08: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1249f0c: b               #0x1249d94
  }
}

// class id: 5196, size: 0x78, field offset: 0x6c
class _FilledTonalIconButtonDefaultsM3 extends ButtonStyle {

  late final ColorScheme _colors; // offset: 0x74

  get _ backgroundColor(/* No info */) {
    // ** addr: 0x1240bb4, size: 0x68
    // 0x1240bb4: EnterFrame
    //     0x1240bb4: stp             fp, lr, [SP, #-0x10]!
    //     0x1240bb8: mov             fp, SP
    // 0x1240bbc: AllocStack(0x18)
    //     0x1240bbc: sub             SP, SP, #0x18
    // 0x1240bc0: SetupParameters(_FilledTonalIconButtonDefaultsM3 this /* r1 => r1, fp-0x8 */)
    //     0x1240bc0: stur            x1, [fp, #-8]
    // 0x1240bc4: CheckStackOverflow
    //     0x1240bc4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1240bc8: cmp             SP, x16
    //     0x1240bcc: b.ls            #0x1240c14
    // 0x1240bd0: r1 = 1
    //     0x1240bd0: mov             x1, #1
    // 0x1240bd4: r0 = AllocateContext()
    //     0x1240bd4: bl              #0x13de838  ; AllocateContextStub
    // 0x1240bd8: mov             x1, x0
    // 0x1240bdc: ldur            x0, [fp, #-8]
    // 0x1240be0: StoreField: r1->field_f = r0
    //     0x1240be0: stur            w0, [x1, #0xf]
    // 0x1240be4: mov             x2, x1
    // 0x1240be8: r1 = Function '<anonymous closure>':.
    //     0x1240be8: add             x1, PP, #0xab, lsl #12  ; [pp+0xab490] AnonymousClosure: (0x1240c1c), in [package:flutter/src/material/icon_button.dart] _FilledTonalIconButtonDefaultsM3::backgroundColor (0x1240bb4)
    //     0x1240bec: ldr             x1, [x1, #0x490]
    // 0x1240bf0: r0 = AllocateClosure()
    //     0x1240bf0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1240bf4: r16 = <Color?>
    //     0x1240bf4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1240bf8: ldr             x16, [x16, #0xa40]
    // 0x1240bfc: stp             x0, x16, [SP]
    // 0x1240c00: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1240c00: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1240c04: r0 = resolveWith()
    //     0x1240c04: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1240c08: LeaveFrame
    //     0x1240c08: mov             SP, fp
    //     0x1240c0c: ldp             fp, lr, [SP], #0x10
    // 0x1240c10: ret
    //     0x1240c10: ret             
    // 0x1240c14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1240c14: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1240c18: b               #0x1240bd0
  }
  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0x1240c1c, size: 0x1a4
    // 0x1240c1c: EnterFrame
    //     0x1240c1c: stp             fp, lr, [SP, #-0x10]!
    //     0x1240c20: mov             fp, SP
    // 0x1240c24: AllocStack(0x8)
    //     0x1240c24: sub             SP, SP, #8
    // 0x1240c28: SetupParameters([dynamic _ /* r0 */])
    //     0x1240c28: ldr             x0, [fp, #0x18]
    //     0x1240c2c: ldur            w3, [x0, #0x17]
    //     0x1240c30: add             x3, x3, HEAP, lsl #32
    //     0x1240c34: stur            x3, [fp, #-8]
    // 0x1240c38: CheckStackOverflow
    //     0x1240c38: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1240c3c: cmp             SP, x16
    //     0x1240c40: b.ls            #0x1240db8
    // 0x1240c44: ldr             x4, [fp, #0x10]
    // 0x1240c48: r0 = LoadClassIdInstr(r4)
    //     0x1240c48: ldur            x0, [x4, #-1]
    //     0x1240c4c: ubfx            x0, x0, #0xc, #0x14
    // 0x1240c50: mov             x1, x4
    // 0x1240c54: r2 = Instance_WidgetState
    //     0x1240c54: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0x1240c58: ldr             x2, [x2, #0xa70]
    // 0x1240c5c: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1240c5c: mov             x17, #0x2929
    //     0x1240c60: movk            x17, #1, lsl #16
    //     0x1240c64: add             lr, x0, x17
    //     0x1240c68: ldr             lr, [x21, lr, lsl #3]
    //     0x1240c6c: blr             lr
    // 0x1240c70: tbnz            w0, #4, #0x1240cd0
    // 0x1240c74: ldur            x3, [fp, #-8]
    // 0x1240c78: LoadField: r1 = r3->field_f
    //     0x1240c78: ldur            w1, [x3, #0xf]
    // 0x1240c7c: DecompressPointer r1
    //     0x1240c7c: add             x1, x1, HEAP, lsl #32
    // 0x1240c80: LoadField: r0 = r1->field_73
    //     0x1240c80: ldur            w0, [x1, #0x73]
    // 0x1240c84: DecompressPointer r0
    //     0x1240c84: add             x0, x0, HEAP, lsl #32
    // 0x1240c88: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1240c8c: cmp             w0, w16
    // 0x1240c90: b.ne            #0x1240ca0
    // 0x1240c94: r2 = _colors
    //     0x1240c94: add             x2, PP, #0xab, lsl #12  ; [pp+0xab480] Field <_FilledTonalIconButtonDefaultsM3@619331726._colors@619331726>: late final (offset: 0x74)
    //     0x1240c98: ldr             x2, [x2, #0x480]
    // 0x1240c9c: r0 = InitLateFinalInstanceField()
    //     0x1240c9c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1240ca0: LoadField: r1 = r0->field_7f
    //     0x1240ca0: ldur            w1, [x0, #0x7f]
    // 0x1240ca4: DecompressPointer r1
    //     0x1240ca4: add             x1, x1, HEAP, lsl #32
    // 0x1240ca8: r0 = LoadClassIdInstr(r1)
    //     0x1240ca8: ldur            x0, [x1, #-1]
    //     0x1240cac: ubfx            x0, x0, #0xc, #0x14
    // 0x1240cb0: d0 = 0.120000
    //     0x1240cb0: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x1240cb4: ldr             d0, [x17, #0xc40]
    // 0x1240cb8: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1240cb8: sub             lr, x0, #1, lsl #12
    //     0x1240cbc: ldr             lr, [x21, lr, lsl #3]
    //     0x1240cc0: blr             lr
    // 0x1240cc4: LeaveFrame
    //     0x1240cc4: mov             SP, fp
    //     0x1240cc8: ldp             fp, lr, [SP], #0x10
    // 0x1240ccc: ret
    //     0x1240ccc: ret             
    // 0x1240cd0: ldr             x1, [fp, #0x10]
    // 0x1240cd4: ldur            x3, [fp, #-8]
    // 0x1240cd8: r0 = LoadClassIdInstr(r1)
    //     0x1240cd8: ldur            x0, [x1, #-1]
    //     0x1240cdc: ubfx            x0, x0, #0xc, #0x14
    // 0x1240ce0: r2 = Instance_WidgetState
    //     0x1240ce0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0x1240ce4: ldr             x2, [x2, #0x100]
    // 0x1240ce8: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1240ce8: mov             x17, #0x2929
    //     0x1240cec: movk            x17, #1, lsl #16
    //     0x1240cf0: add             lr, x0, x17
    //     0x1240cf4: ldr             lr, [x21, lr, lsl #3]
    //     0x1240cf8: blr             lr
    // 0x1240cfc: tbnz            w0, #4, #0x1240d5c
    // 0x1240d00: ldur            x0, [fp, #-8]
    // 0x1240d04: LoadField: r1 = r0->field_f
    //     0x1240d04: ldur            w1, [x0, #0xf]
    // 0x1240d08: DecompressPointer r1
    //     0x1240d08: add             x1, x1, HEAP, lsl #32
    // 0x1240d0c: LoadField: r0 = r1->field_73
    //     0x1240d0c: ldur            w0, [x1, #0x73]
    // 0x1240d10: DecompressPointer r0
    //     0x1240d10: add             x0, x0, HEAP, lsl #32
    // 0x1240d14: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1240d18: cmp             w0, w16
    // 0x1240d1c: b.ne            #0x1240d2c
    // 0x1240d20: r2 = _colors
    //     0x1240d20: add             x2, PP, #0xab, lsl #12  ; [pp+0xab480] Field <_FilledTonalIconButtonDefaultsM3@619331726._colors@619331726>: late final (offset: 0x74)
    //     0x1240d24: ldr             x2, [x2, #0x480]
    // 0x1240d28: r0 = InitLateFinalInstanceField()
    //     0x1240d28: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1240d2c: LoadField: r1 = r0->field_33
    //     0x1240d2c: ldur            w1, [x0, #0x33]
    // 0x1240d30: DecompressPointer r1
    //     0x1240d30: add             x1, x1, HEAP, lsl #32
    // 0x1240d34: cmp             w1, NULL
    // 0x1240d38: b.ne            #0x1240d4c
    // 0x1240d3c: LoadField: r1 = r0->field_2b
    //     0x1240d3c: ldur            w1, [x0, #0x2b]
    // 0x1240d40: DecompressPointer r1
    //     0x1240d40: add             x1, x1, HEAP, lsl #32
    // 0x1240d44: mov             x0, x1
    // 0x1240d48: b               #0x1240d50
    // 0x1240d4c: mov             x0, x1
    // 0x1240d50: LeaveFrame
    //     0x1240d50: mov             SP, fp
    //     0x1240d54: ldp             fp, lr, [SP], #0x10
    // 0x1240d58: ret
    //     0x1240d58: ret             
    // 0x1240d5c: ldur            x0, [fp, #-8]
    // 0x1240d60: LoadField: r1 = r0->field_f
    //     0x1240d60: ldur            w1, [x0, #0xf]
    // 0x1240d64: DecompressPointer r1
    //     0x1240d64: add             x1, x1, HEAP, lsl #32
    // 0x1240d68: LoadField: r0 = r1->field_73
    //     0x1240d68: ldur            w0, [x1, #0x73]
    // 0x1240d6c: DecompressPointer r0
    //     0x1240d6c: add             x0, x0, HEAP, lsl #32
    // 0x1240d70: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1240d74: cmp             w0, w16
    // 0x1240d78: b.ne            #0x1240d88
    // 0x1240d7c: r2 = _colors
    //     0x1240d7c: add             x2, PP, #0xab, lsl #12  ; [pp+0xab480] Field <_FilledTonalIconButtonDefaultsM3@619331726._colors@619331726>: late final (offset: 0x74)
    //     0x1240d80: ldr             x2, [x2, #0x480]
    // 0x1240d84: r0 = InitLateFinalInstanceField()
    //     0x1240d84: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1240d88: LoadField: r1 = r0->field_33
    //     0x1240d88: ldur            w1, [x0, #0x33]
    // 0x1240d8c: DecompressPointer r1
    //     0x1240d8c: add             x1, x1, HEAP, lsl #32
    // 0x1240d90: cmp             w1, NULL
    // 0x1240d94: b.ne            #0x1240da8
    // 0x1240d98: LoadField: r2 = r0->field_2b
    //     0x1240d98: ldur            w2, [x0, #0x2b]
    // 0x1240d9c: DecompressPointer r2
    //     0x1240d9c: add             x2, x2, HEAP, lsl #32
    // 0x1240da0: mov             x0, x2
    // 0x1240da4: b               #0x1240dac
    // 0x1240da8: mov             x0, x1
    // 0x1240dac: LeaveFrame
    //     0x1240dac: mov             SP, fp
    //     0x1240db0: ldp             fp, lr, [SP], #0x10
    // 0x1240db4: ret
    //     0x1240db4: ret             
    // 0x1240db8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1240db8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1240dbc: b               #0x1240c44
  }
  get _ overlayColor(/* No info */) {
    // ** addr: 0x124298c, size: 0x68
    // 0x124298c: EnterFrame
    //     0x124298c: stp             fp, lr, [SP, #-0x10]!
    //     0x1242990: mov             fp, SP
    // 0x1242994: AllocStack(0x18)
    //     0x1242994: sub             SP, SP, #0x18
    // 0x1242998: SetupParameters(_FilledTonalIconButtonDefaultsM3 this /* r1 => r1, fp-0x8 */)
    //     0x1242998: stur            x1, [fp, #-8]
    // 0x124299c: CheckStackOverflow
    //     0x124299c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12429a0: cmp             SP, x16
    //     0x12429a4: b.ls            #0x12429ec
    // 0x12429a8: r1 = 1
    //     0x12429a8: mov             x1, #1
    // 0x12429ac: r0 = AllocateContext()
    //     0x12429ac: bl              #0x13de838  ; AllocateContextStub
    // 0x12429b0: mov             x1, x0
    // 0x12429b4: ldur            x0, [fp, #-8]
    // 0x12429b8: StoreField: r1->field_f = r0
    //     0x12429b8: stur            w0, [x1, #0xf]
    // 0x12429bc: mov             x2, x1
    // 0x12429c0: r1 = Function '<anonymous closure>':.
    //     0x12429c0: add             x1, PP, #0xab, lsl #12  ; [pp+0xab478] AnonymousClosure: (0x12429f4), in [package:flutter/src/material/icon_button.dart] _FilledTonalIconButtonDefaultsM3::overlayColor (0x124298c)
    //     0x12429c4: ldr             x1, [x1, #0x478]
    // 0x12429c8: r0 = AllocateClosure()
    //     0x12429c8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x12429cc: r16 = <Color?>
    //     0x12429cc: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x12429d0: ldr             x16, [x16, #0xa40]
    // 0x12429d4: stp             x0, x16, [SP]
    // 0x12429d8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x12429d8: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x12429dc: r0 = resolveWith()
    //     0x12429dc: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x12429e0: LeaveFrame
    //     0x12429e0: mov             SP, fp
    //     0x12429e4: ldp             fp, lr, [SP], #0x10
    // 0x12429e8: ret
    //     0x12429e8: ret             
    // 0x12429ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12429ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12429f0: b               #0x12429a8
  }
  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0x12429f4, size: 0x434
    // 0x12429f4: EnterFrame
    //     0x12429f4: stp             fp, lr, [SP, #-0x10]!
    //     0x12429f8: mov             fp, SP
    // 0x12429fc: AllocStack(0x8)
    //     0x12429fc: sub             SP, SP, #8
    // 0x1242a00: SetupParameters([dynamic _ /* r0 */])
    //     0x1242a00: ldr             x0, [fp, #0x18]
    //     0x1242a04: ldur            w3, [x0, #0x17]
    //     0x1242a08: add             x3, x3, HEAP, lsl #32
    //     0x1242a0c: stur            x3, [fp, #-8]
    // 0x1242a10: CheckStackOverflow
    //     0x1242a10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1242a14: cmp             SP, x16
    //     0x1242a18: b.ls            #0x1242e20
    // 0x1242a1c: ldr             x4, [fp, #0x10]
    // 0x1242a20: r0 = LoadClassIdInstr(r4)
    //     0x1242a20: ldur            x0, [x4, #-1]
    //     0x1242a24: ubfx            x0, x0, #0xc, #0x14
    // 0x1242a28: mov             x1, x4
    // 0x1242a2c: r2 = Instance_WidgetState
    //     0x1242a2c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0x1242a30: ldr             x2, [x2, #0x100]
    // 0x1242a34: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1242a34: mov             x17, #0x2929
    //     0x1242a38: movk            x17, #1, lsl #16
    //     0x1242a3c: add             lr, x0, x17
    //     0x1242a40: ldr             lr, [x21, lr, lsl #3]
    //     0x1242a44: blr             lr
    // 0x1242a48: tbnz            w0, #4, #0x1242c30
    // 0x1242a4c: ldr             x3, [fp, #0x10]
    // 0x1242a50: r0 = LoadClassIdInstr(r3)
    //     0x1242a50: ldur            x0, [x3, #-1]
    //     0x1242a54: ubfx            x0, x0, #0xc, #0x14
    // 0x1242a58: mov             x1, x3
    // 0x1242a5c: r2 = Instance_WidgetState
    //     0x1242a5c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0x1242a60: ldr             x2, [x2, #0xa48]
    // 0x1242a64: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1242a64: mov             x17, #0x2929
    //     0x1242a68: movk            x17, #1, lsl #16
    //     0x1242a6c: add             lr, x0, x17
    //     0x1242a70: ldr             lr, [x21, lr, lsl #3]
    //     0x1242a74: blr             lr
    // 0x1242a78: tbnz            w0, #4, #0x1242ae8
    // 0x1242a7c: ldur            x3, [fp, #-8]
    // 0x1242a80: LoadField: r1 = r3->field_f
    //     0x1242a80: ldur            w1, [x3, #0xf]
    // 0x1242a84: DecompressPointer r1
    //     0x1242a84: add             x1, x1, HEAP, lsl #32
    // 0x1242a88: LoadField: r0 = r1->field_73
    //     0x1242a88: ldur            w0, [x1, #0x73]
    // 0x1242a8c: DecompressPointer r0
    //     0x1242a8c: add             x0, x0, HEAP, lsl #32
    // 0x1242a90: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1242a94: cmp             w0, w16
    // 0x1242a98: b.ne            #0x1242aa8
    // 0x1242a9c: r2 = _colors
    //     0x1242a9c: add             x2, PP, #0xab, lsl #12  ; [pp+0xab480] Field <_FilledTonalIconButtonDefaultsM3@619331726._colors@619331726>: late final (offset: 0x74)
    //     0x1242aa0: ldr             x2, [x2, #0x480]
    // 0x1242aa4: r0 = InitLateFinalInstanceField()
    //     0x1242aa4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1242aa8: LoadField: r1 = r0->field_37
    //     0x1242aa8: ldur            w1, [x0, #0x37]
    // 0x1242aac: DecompressPointer r1
    //     0x1242aac: add             x1, x1, HEAP, lsl #32
    // 0x1242ab0: cmp             w1, NULL
    // 0x1242ab4: b.ne            #0x1242ac0
    // 0x1242ab8: LoadField: r1 = r0->field_2f
    //     0x1242ab8: ldur            w1, [x0, #0x2f]
    // 0x1242abc: DecompressPointer r1
    //     0x1242abc: add             x1, x1, HEAP, lsl #32
    // 0x1242ac0: r0 = LoadClassIdInstr(r1)
    //     0x1242ac0: ldur            x0, [x1, #-1]
    //     0x1242ac4: ubfx            x0, x0, #0xc, #0x14
    // 0x1242ac8: d0 = 0.100000
    //     0x1242ac8: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0x1242acc: ldr             d0, [x17, #0x1e0]
    // 0x1242ad0: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1242ad0: sub             lr, x0, #1, lsl #12
    //     0x1242ad4: ldr             lr, [x21, lr, lsl #3]
    //     0x1242ad8: blr             lr
    // 0x1242adc: LeaveFrame
    //     0x1242adc: mov             SP, fp
    //     0x1242ae0: ldp             fp, lr, [SP], #0x10
    // 0x1242ae4: ret
    //     0x1242ae4: ret             
    // 0x1242ae8: ldr             x4, [fp, #0x10]
    // 0x1242aec: ldur            x3, [fp, #-8]
    // 0x1242af0: r0 = LoadClassIdInstr(r4)
    //     0x1242af0: ldur            x0, [x4, #-1]
    //     0x1242af4: ubfx            x0, x0, #0xc, #0x14
    // 0x1242af8: mov             x1, x4
    // 0x1242afc: r2 = Instance_WidgetState
    //     0x1242afc: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0x1242b00: ldr             x2, [x2, #0xa50]
    // 0x1242b04: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1242b04: mov             x17, #0x2929
    //     0x1242b08: movk            x17, #1, lsl #16
    //     0x1242b0c: add             lr, x0, x17
    //     0x1242b10: ldr             lr, [x21, lr, lsl #3]
    //     0x1242b14: blr             lr
    // 0x1242b18: tbnz            w0, #4, #0x1242b88
    // 0x1242b1c: ldur            x3, [fp, #-8]
    // 0x1242b20: LoadField: r1 = r3->field_f
    //     0x1242b20: ldur            w1, [x3, #0xf]
    // 0x1242b24: DecompressPointer r1
    //     0x1242b24: add             x1, x1, HEAP, lsl #32
    // 0x1242b28: LoadField: r0 = r1->field_73
    //     0x1242b28: ldur            w0, [x1, #0x73]
    // 0x1242b2c: DecompressPointer r0
    //     0x1242b2c: add             x0, x0, HEAP, lsl #32
    // 0x1242b30: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1242b34: cmp             w0, w16
    // 0x1242b38: b.ne            #0x1242b48
    // 0x1242b3c: r2 = _colors
    //     0x1242b3c: add             x2, PP, #0xab, lsl #12  ; [pp+0xab480] Field <_FilledTonalIconButtonDefaultsM3@619331726._colors@619331726>: late final (offset: 0x74)
    //     0x1242b40: ldr             x2, [x2, #0x480]
    // 0x1242b44: r0 = InitLateFinalInstanceField()
    //     0x1242b44: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1242b48: LoadField: r1 = r0->field_37
    //     0x1242b48: ldur            w1, [x0, #0x37]
    // 0x1242b4c: DecompressPointer r1
    //     0x1242b4c: add             x1, x1, HEAP, lsl #32
    // 0x1242b50: cmp             w1, NULL
    // 0x1242b54: b.ne            #0x1242b60
    // 0x1242b58: LoadField: r1 = r0->field_2f
    //     0x1242b58: ldur            w1, [x0, #0x2f]
    // 0x1242b5c: DecompressPointer r1
    //     0x1242b5c: add             x1, x1, HEAP, lsl #32
    // 0x1242b60: r0 = LoadClassIdInstr(r1)
    //     0x1242b60: ldur            x0, [x1, #-1]
    //     0x1242b64: ubfx            x0, x0, #0xc, #0x14
    // 0x1242b68: d0 = 0.080000
    //     0x1242b68: add             x17, PP, #0x15, lsl #12  ; [pp+0x15a58] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x1242b6c: ldr             d0, [x17, #0xa58]
    // 0x1242b70: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1242b70: sub             lr, x0, #1, lsl #12
    //     0x1242b74: ldr             lr, [x21, lr, lsl #3]
    //     0x1242b78: blr             lr
    // 0x1242b7c: LeaveFrame
    //     0x1242b7c: mov             SP, fp
    //     0x1242b80: ldp             fp, lr, [SP], #0x10
    // 0x1242b84: ret
    //     0x1242b84: ret             
    // 0x1242b88: ldr             x4, [fp, #0x10]
    // 0x1242b8c: ldur            x3, [fp, #-8]
    // 0x1242b90: r0 = LoadClassIdInstr(r4)
    //     0x1242b90: ldur            x0, [x4, #-1]
    //     0x1242b94: ubfx            x0, x0, #0xc, #0x14
    // 0x1242b98: mov             x1, x4
    // 0x1242b9c: r2 = Instance_WidgetState
    //     0x1242b9c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0x1242ba0: ldr             x2, [x2, #0xa60]
    // 0x1242ba4: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1242ba4: mov             x17, #0x2929
    //     0x1242ba8: movk            x17, #1, lsl #16
    //     0x1242bac: add             lr, x0, x17
    //     0x1242bb0: ldr             lr, [x21, lr, lsl #3]
    //     0x1242bb4: blr             lr
    // 0x1242bb8: tbnz            w0, #4, #0x1242c28
    // 0x1242bbc: ldur            x3, [fp, #-8]
    // 0x1242bc0: LoadField: r1 = r3->field_f
    //     0x1242bc0: ldur            w1, [x3, #0xf]
    // 0x1242bc4: DecompressPointer r1
    //     0x1242bc4: add             x1, x1, HEAP, lsl #32
    // 0x1242bc8: LoadField: r0 = r1->field_73
    //     0x1242bc8: ldur            w0, [x1, #0x73]
    // 0x1242bcc: DecompressPointer r0
    //     0x1242bcc: add             x0, x0, HEAP, lsl #32
    // 0x1242bd0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1242bd4: cmp             w0, w16
    // 0x1242bd8: b.ne            #0x1242be8
    // 0x1242bdc: r2 = _colors
    //     0x1242bdc: add             x2, PP, #0xab, lsl #12  ; [pp+0xab480] Field <_FilledTonalIconButtonDefaultsM3@619331726._colors@619331726>: late final (offset: 0x74)
    //     0x1242be0: ldr             x2, [x2, #0x480]
    // 0x1242be4: r0 = InitLateFinalInstanceField()
    //     0x1242be4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1242be8: LoadField: r1 = r0->field_37
    //     0x1242be8: ldur            w1, [x0, #0x37]
    // 0x1242bec: DecompressPointer r1
    //     0x1242bec: add             x1, x1, HEAP, lsl #32
    // 0x1242bf0: cmp             w1, NULL
    // 0x1242bf4: b.ne            #0x1242c00
    // 0x1242bf8: LoadField: r1 = r0->field_2f
    //     0x1242bf8: ldur            w1, [x0, #0x2f]
    // 0x1242bfc: DecompressPointer r1
    //     0x1242bfc: add             x1, x1, HEAP, lsl #32
    // 0x1242c00: r0 = LoadClassIdInstr(r1)
    //     0x1242c00: ldur            x0, [x1, #-1]
    //     0x1242c04: ubfx            x0, x0, #0xc, #0x14
    // 0x1242c08: d0 = 0.100000
    //     0x1242c08: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0x1242c0c: ldr             d0, [x17, #0x1e0]
    // 0x1242c10: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1242c10: sub             lr, x0, #1, lsl #12
    //     0x1242c14: ldr             lr, [x21, lr, lsl #3]
    //     0x1242c18: blr             lr
    // 0x1242c1c: LeaveFrame
    //     0x1242c1c: mov             SP, fp
    //     0x1242c20: ldp             fp, lr, [SP], #0x10
    // 0x1242c24: ret
    //     0x1242c24: ret             
    // 0x1242c28: ldur            x3, [fp, #-8]
    // 0x1242c2c: b               #0x1242c34
    // 0x1242c30: ldur            x3, [fp, #-8]
    // 0x1242c34: ldr             x4, [fp, #0x10]
    // 0x1242c38: r0 = LoadClassIdInstr(r4)
    //     0x1242c38: ldur            x0, [x4, #-1]
    //     0x1242c3c: ubfx            x0, x0, #0xc, #0x14
    // 0x1242c40: mov             x1, x4
    // 0x1242c44: r2 = Instance_WidgetState
    //     0x1242c44: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0x1242c48: ldr             x2, [x2, #0xa48]
    // 0x1242c4c: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1242c4c: mov             x17, #0x2929
    //     0x1242c50: movk            x17, #1, lsl #16
    //     0x1242c54: add             lr, x0, x17
    //     0x1242c58: ldr             lr, [x21, lr, lsl #3]
    //     0x1242c5c: blr             lr
    // 0x1242c60: tbnz            w0, #4, #0x1242cd0
    // 0x1242c64: ldur            x3, [fp, #-8]
    // 0x1242c68: LoadField: r1 = r3->field_f
    //     0x1242c68: ldur            w1, [x3, #0xf]
    // 0x1242c6c: DecompressPointer r1
    //     0x1242c6c: add             x1, x1, HEAP, lsl #32
    // 0x1242c70: LoadField: r0 = r1->field_73
    //     0x1242c70: ldur            w0, [x1, #0x73]
    // 0x1242c74: DecompressPointer r0
    //     0x1242c74: add             x0, x0, HEAP, lsl #32
    // 0x1242c78: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1242c7c: cmp             w0, w16
    // 0x1242c80: b.ne            #0x1242c90
    // 0x1242c84: r2 = _colors
    //     0x1242c84: add             x2, PP, #0xab, lsl #12  ; [pp+0xab480] Field <_FilledTonalIconButtonDefaultsM3@619331726._colors@619331726>: late final (offset: 0x74)
    //     0x1242c88: ldr             x2, [x2, #0x480]
    // 0x1242c8c: r0 = InitLateFinalInstanceField()
    //     0x1242c8c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1242c90: LoadField: r1 = r0->field_37
    //     0x1242c90: ldur            w1, [x0, #0x37]
    // 0x1242c94: DecompressPointer r1
    //     0x1242c94: add             x1, x1, HEAP, lsl #32
    // 0x1242c98: cmp             w1, NULL
    // 0x1242c9c: b.ne            #0x1242ca8
    // 0x1242ca0: LoadField: r1 = r0->field_2f
    //     0x1242ca0: ldur            w1, [x0, #0x2f]
    // 0x1242ca4: DecompressPointer r1
    //     0x1242ca4: add             x1, x1, HEAP, lsl #32
    // 0x1242ca8: r0 = LoadClassIdInstr(r1)
    //     0x1242ca8: ldur            x0, [x1, #-1]
    //     0x1242cac: ubfx            x0, x0, #0xc, #0x14
    // 0x1242cb0: d0 = 0.100000
    //     0x1242cb0: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0x1242cb4: ldr             d0, [x17, #0x1e0]
    // 0x1242cb8: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1242cb8: sub             lr, x0, #1, lsl #12
    //     0x1242cbc: ldr             lr, [x21, lr, lsl #3]
    //     0x1242cc0: blr             lr
    // 0x1242cc4: LeaveFrame
    //     0x1242cc4: mov             SP, fp
    //     0x1242cc8: ldp             fp, lr, [SP], #0x10
    // 0x1242ccc: ret
    //     0x1242ccc: ret             
    // 0x1242cd0: ldr             x4, [fp, #0x10]
    // 0x1242cd4: ldur            x3, [fp, #-8]
    // 0x1242cd8: r0 = LoadClassIdInstr(r4)
    //     0x1242cd8: ldur            x0, [x4, #-1]
    //     0x1242cdc: ubfx            x0, x0, #0xc, #0x14
    // 0x1242ce0: mov             x1, x4
    // 0x1242ce4: r2 = Instance_WidgetState
    //     0x1242ce4: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0x1242ce8: ldr             x2, [x2, #0xa50]
    // 0x1242cec: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1242cec: mov             x17, #0x2929
    //     0x1242cf0: movk            x17, #1, lsl #16
    //     0x1242cf4: add             lr, x0, x17
    //     0x1242cf8: ldr             lr, [x21, lr, lsl #3]
    //     0x1242cfc: blr             lr
    // 0x1242d00: tbnz            w0, #4, #0x1242d70
    // 0x1242d04: ldur            x3, [fp, #-8]
    // 0x1242d08: LoadField: r1 = r3->field_f
    //     0x1242d08: ldur            w1, [x3, #0xf]
    // 0x1242d0c: DecompressPointer r1
    //     0x1242d0c: add             x1, x1, HEAP, lsl #32
    // 0x1242d10: LoadField: r0 = r1->field_73
    //     0x1242d10: ldur            w0, [x1, #0x73]
    // 0x1242d14: DecompressPointer r0
    //     0x1242d14: add             x0, x0, HEAP, lsl #32
    // 0x1242d18: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1242d1c: cmp             w0, w16
    // 0x1242d20: b.ne            #0x1242d30
    // 0x1242d24: r2 = _colors
    //     0x1242d24: add             x2, PP, #0xab, lsl #12  ; [pp+0xab480] Field <_FilledTonalIconButtonDefaultsM3@619331726._colors@619331726>: late final (offset: 0x74)
    //     0x1242d28: ldr             x2, [x2, #0x480]
    // 0x1242d2c: r0 = InitLateFinalInstanceField()
    //     0x1242d2c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1242d30: LoadField: r1 = r0->field_37
    //     0x1242d30: ldur            w1, [x0, #0x37]
    // 0x1242d34: DecompressPointer r1
    //     0x1242d34: add             x1, x1, HEAP, lsl #32
    // 0x1242d38: cmp             w1, NULL
    // 0x1242d3c: b.ne            #0x1242d48
    // 0x1242d40: LoadField: r1 = r0->field_2f
    //     0x1242d40: ldur            w1, [x0, #0x2f]
    // 0x1242d44: DecompressPointer r1
    //     0x1242d44: add             x1, x1, HEAP, lsl #32
    // 0x1242d48: r0 = LoadClassIdInstr(r1)
    //     0x1242d48: ldur            x0, [x1, #-1]
    //     0x1242d4c: ubfx            x0, x0, #0xc, #0x14
    // 0x1242d50: d0 = 0.080000
    //     0x1242d50: add             x17, PP, #0x15, lsl #12  ; [pp+0x15a58] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x1242d54: ldr             d0, [x17, #0xa58]
    // 0x1242d58: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1242d58: sub             lr, x0, #1, lsl #12
    //     0x1242d5c: ldr             lr, [x21, lr, lsl #3]
    //     0x1242d60: blr             lr
    // 0x1242d64: LeaveFrame
    //     0x1242d64: mov             SP, fp
    //     0x1242d68: ldp             fp, lr, [SP], #0x10
    // 0x1242d6c: ret
    //     0x1242d6c: ret             
    // 0x1242d70: ldr             x1, [fp, #0x10]
    // 0x1242d74: ldur            x3, [fp, #-8]
    // 0x1242d78: r0 = LoadClassIdInstr(r1)
    //     0x1242d78: ldur            x0, [x1, #-1]
    //     0x1242d7c: ubfx            x0, x0, #0xc, #0x14
    // 0x1242d80: r2 = Instance_WidgetState
    //     0x1242d80: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0x1242d84: ldr             x2, [x2, #0xa60]
    // 0x1242d88: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1242d88: mov             x17, #0x2929
    //     0x1242d8c: movk            x17, #1, lsl #16
    //     0x1242d90: add             lr, x0, x17
    //     0x1242d94: ldr             lr, [x21, lr, lsl #3]
    //     0x1242d98: blr             lr
    // 0x1242d9c: tbnz            w0, #4, #0x1242e0c
    // 0x1242da0: ldur            x0, [fp, #-8]
    // 0x1242da4: LoadField: r1 = r0->field_f
    //     0x1242da4: ldur            w1, [x0, #0xf]
    // 0x1242da8: DecompressPointer r1
    //     0x1242da8: add             x1, x1, HEAP, lsl #32
    // 0x1242dac: LoadField: r0 = r1->field_73
    //     0x1242dac: ldur            w0, [x1, #0x73]
    // 0x1242db0: DecompressPointer r0
    //     0x1242db0: add             x0, x0, HEAP, lsl #32
    // 0x1242db4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1242db8: cmp             w0, w16
    // 0x1242dbc: b.ne            #0x1242dcc
    // 0x1242dc0: r2 = _colors
    //     0x1242dc0: add             x2, PP, #0xab, lsl #12  ; [pp+0xab480] Field <_FilledTonalIconButtonDefaultsM3@619331726._colors@619331726>: late final (offset: 0x74)
    //     0x1242dc4: ldr             x2, [x2, #0x480]
    // 0x1242dc8: r0 = InitLateFinalInstanceField()
    //     0x1242dc8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1242dcc: LoadField: r1 = r0->field_37
    //     0x1242dcc: ldur            w1, [x0, #0x37]
    // 0x1242dd0: DecompressPointer r1
    //     0x1242dd0: add             x1, x1, HEAP, lsl #32
    // 0x1242dd4: cmp             w1, NULL
    // 0x1242dd8: b.ne            #0x1242de4
    // 0x1242ddc: LoadField: r1 = r0->field_2f
    //     0x1242ddc: ldur            w1, [x0, #0x2f]
    // 0x1242de0: DecompressPointer r1
    //     0x1242de0: add             x1, x1, HEAP, lsl #32
    // 0x1242de4: r0 = LoadClassIdInstr(r1)
    //     0x1242de4: ldur            x0, [x1, #-1]
    //     0x1242de8: ubfx            x0, x0, #0xc, #0x14
    // 0x1242dec: d0 = 0.100000
    //     0x1242dec: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0x1242df0: ldr             d0, [x17, #0x1e0]
    // 0x1242df4: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1242df4: sub             lr, x0, #1, lsl #12
    //     0x1242df8: ldr             lr, [x21, lr, lsl #3]
    //     0x1242dfc: blr             lr
    // 0x1242e00: LeaveFrame
    //     0x1242e00: mov             SP, fp
    //     0x1242e04: ldp             fp, lr, [SP], #0x10
    // 0x1242e08: ret
    //     0x1242e08: ret             
    // 0x1242e0c: r0 = Instance_Color
    //     0x1242e0c: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x1242e10: ldr             x0, [x0, #0x810]
    // 0x1242e14: LeaveFrame
    //     0x1242e14: mov             SP, fp
    //     0x1242e18: ldp             fp, lr, [SP], #0x10
    // 0x1242e1c: ret
    //     0x1242e1c: ret             
    // 0x1242e20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1242e20: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1242e24: b               #0x1242a1c
  }
  get _ foregroundColor(/* No info */) {
    // ** addr: 0x1249af8, size: 0x68
    // 0x1249af8: EnterFrame
    //     0x1249af8: stp             fp, lr, [SP, #-0x10]!
    //     0x1249afc: mov             fp, SP
    // 0x1249b00: AllocStack(0x18)
    //     0x1249b00: sub             SP, SP, #0x18
    // 0x1249b04: SetupParameters(_FilledTonalIconButtonDefaultsM3 this /* r1 => r1, fp-0x8 */)
    //     0x1249b04: stur            x1, [fp, #-8]
    // 0x1249b08: CheckStackOverflow
    //     0x1249b08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1249b0c: cmp             SP, x16
    //     0x1249b10: b.ls            #0x1249b58
    // 0x1249b14: r1 = 1
    //     0x1249b14: mov             x1, #1
    // 0x1249b18: r0 = AllocateContext()
    //     0x1249b18: bl              #0x13de838  ; AllocateContextStub
    // 0x1249b1c: mov             x1, x0
    // 0x1249b20: ldur            x0, [fp, #-8]
    // 0x1249b24: StoreField: r1->field_f = r0
    //     0x1249b24: stur            w0, [x1, #0xf]
    // 0x1249b28: mov             x2, x1
    // 0x1249b2c: r1 = Function '<anonymous closure>':.
    //     0x1249b2c: add             x1, PP, #0xab, lsl #12  ; [pp+0xab488] AnonymousClosure: (0x1249b60), in [package:flutter/src/material/icon_button.dart] _FilledTonalIconButtonDefaultsM3::foregroundColor (0x1249af8)
    //     0x1249b30: ldr             x1, [x1, #0x488]
    // 0x1249b34: r0 = AllocateClosure()
    //     0x1249b34: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1249b38: r16 = <Color?>
    //     0x1249b38: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1249b3c: ldr             x16, [x16, #0xa40]
    // 0x1249b40: stp             x0, x16, [SP]
    // 0x1249b44: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1249b44: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1249b48: r0 = resolveWith()
    //     0x1249b48: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1249b4c: LeaveFrame
    //     0x1249b4c: mov             SP, fp
    //     0x1249b50: ldp             fp, lr, [SP], #0x10
    // 0x1249b54: ret
    //     0x1249b54: ret             
    // 0x1249b58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1249b58: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1249b5c: b               #0x1249b14
  }
  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0x1249b60, size: 0x1a4
    // 0x1249b60: EnterFrame
    //     0x1249b60: stp             fp, lr, [SP, #-0x10]!
    //     0x1249b64: mov             fp, SP
    // 0x1249b68: AllocStack(0x8)
    //     0x1249b68: sub             SP, SP, #8
    // 0x1249b6c: SetupParameters([dynamic _ /* r0 */])
    //     0x1249b6c: ldr             x0, [fp, #0x18]
    //     0x1249b70: ldur            w3, [x0, #0x17]
    //     0x1249b74: add             x3, x3, HEAP, lsl #32
    //     0x1249b78: stur            x3, [fp, #-8]
    // 0x1249b7c: CheckStackOverflow
    //     0x1249b7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1249b80: cmp             SP, x16
    //     0x1249b84: b.ls            #0x1249cfc
    // 0x1249b88: ldr             x4, [fp, #0x10]
    // 0x1249b8c: r0 = LoadClassIdInstr(r4)
    //     0x1249b8c: ldur            x0, [x4, #-1]
    //     0x1249b90: ubfx            x0, x0, #0xc, #0x14
    // 0x1249b94: mov             x1, x4
    // 0x1249b98: r2 = Instance_WidgetState
    //     0x1249b98: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0x1249b9c: ldr             x2, [x2, #0xa70]
    // 0x1249ba0: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1249ba0: mov             x17, #0x2929
    //     0x1249ba4: movk            x17, #1, lsl #16
    //     0x1249ba8: add             lr, x0, x17
    //     0x1249bac: ldr             lr, [x21, lr, lsl #3]
    //     0x1249bb0: blr             lr
    // 0x1249bb4: tbnz            w0, #4, #0x1249c14
    // 0x1249bb8: ldur            x3, [fp, #-8]
    // 0x1249bbc: LoadField: r1 = r3->field_f
    //     0x1249bbc: ldur            w1, [x3, #0xf]
    // 0x1249bc0: DecompressPointer r1
    //     0x1249bc0: add             x1, x1, HEAP, lsl #32
    // 0x1249bc4: LoadField: r0 = r1->field_73
    //     0x1249bc4: ldur            w0, [x1, #0x73]
    // 0x1249bc8: DecompressPointer r0
    //     0x1249bc8: add             x0, x0, HEAP, lsl #32
    // 0x1249bcc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1249bd0: cmp             w0, w16
    // 0x1249bd4: b.ne            #0x1249be4
    // 0x1249bd8: r2 = _colors
    //     0x1249bd8: add             x2, PP, #0xab, lsl #12  ; [pp+0xab480] Field <_FilledTonalIconButtonDefaultsM3@619331726._colors@619331726>: late final (offset: 0x74)
    //     0x1249bdc: ldr             x2, [x2, #0x480]
    // 0x1249be0: r0 = InitLateFinalInstanceField()
    //     0x1249be0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1249be4: LoadField: r1 = r0->field_7f
    //     0x1249be4: ldur            w1, [x0, #0x7f]
    // 0x1249be8: DecompressPointer r1
    //     0x1249be8: add             x1, x1, HEAP, lsl #32
    // 0x1249bec: r0 = LoadClassIdInstr(r1)
    //     0x1249bec: ldur            x0, [x1, #-1]
    //     0x1249bf0: ubfx            x0, x0, #0xc, #0x14
    // 0x1249bf4: d0 = 0.380000
    //     0x1249bf4: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0x1249bf8: ldr             d0, [x17, #0x1f0]
    // 0x1249bfc: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1249bfc: sub             lr, x0, #1, lsl #12
    //     0x1249c00: ldr             lr, [x21, lr, lsl #3]
    //     0x1249c04: blr             lr
    // 0x1249c08: LeaveFrame
    //     0x1249c08: mov             SP, fp
    //     0x1249c0c: ldp             fp, lr, [SP], #0x10
    // 0x1249c10: ret
    //     0x1249c10: ret             
    // 0x1249c14: ldr             x1, [fp, #0x10]
    // 0x1249c18: ldur            x3, [fp, #-8]
    // 0x1249c1c: r0 = LoadClassIdInstr(r1)
    //     0x1249c1c: ldur            x0, [x1, #-1]
    //     0x1249c20: ubfx            x0, x0, #0xc, #0x14
    // 0x1249c24: r2 = Instance_WidgetState
    //     0x1249c24: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0x1249c28: ldr             x2, [x2, #0x100]
    // 0x1249c2c: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1249c2c: mov             x17, #0x2929
    //     0x1249c30: movk            x17, #1, lsl #16
    //     0x1249c34: add             lr, x0, x17
    //     0x1249c38: ldr             lr, [x21, lr, lsl #3]
    //     0x1249c3c: blr             lr
    // 0x1249c40: tbnz            w0, #4, #0x1249ca0
    // 0x1249c44: ldur            x0, [fp, #-8]
    // 0x1249c48: LoadField: r1 = r0->field_f
    //     0x1249c48: ldur            w1, [x0, #0xf]
    // 0x1249c4c: DecompressPointer r1
    //     0x1249c4c: add             x1, x1, HEAP, lsl #32
    // 0x1249c50: LoadField: r0 = r1->field_73
    //     0x1249c50: ldur            w0, [x1, #0x73]
    // 0x1249c54: DecompressPointer r0
    //     0x1249c54: add             x0, x0, HEAP, lsl #32
    // 0x1249c58: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1249c5c: cmp             w0, w16
    // 0x1249c60: b.ne            #0x1249c70
    // 0x1249c64: r2 = _colors
    //     0x1249c64: add             x2, PP, #0xab, lsl #12  ; [pp+0xab480] Field <_FilledTonalIconButtonDefaultsM3@619331726._colors@619331726>: late final (offset: 0x74)
    //     0x1249c68: ldr             x2, [x2, #0x480]
    // 0x1249c6c: r0 = InitLateFinalInstanceField()
    //     0x1249c6c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1249c70: LoadField: r1 = r0->field_37
    //     0x1249c70: ldur            w1, [x0, #0x37]
    // 0x1249c74: DecompressPointer r1
    //     0x1249c74: add             x1, x1, HEAP, lsl #32
    // 0x1249c78: cmp             w1, NULL
    // 0x1249c7c: b.ne            #0x1249c90
    // 0x1249c80: LoadField: r1 = r0->field_2f
    //     0x1249c80: ldur            w1, [x0, #0x2f]
    // 0x1249c84: DecompressPointer r1
    //     0x1249c84: add             x1, x1, HEAP, lsl #32
    // 0x1249c88: mov             x0, x1
    // 0x1249c8c: b               #0x1249c94
    // 0x1249c90: mov             x0, x1
    // 0x1249c94: LeaveFrame
    //     0x1249c94: mov             SP, fp
    //     0x1249c98: ldp             fp, lr, [SP], #0x10
    // 0x1249c9c: ret
    //     0x1249c9c: ret             
    // 0x1249ca0: ldur            x0, [fp, #-8]
    // 0x1249ca4: LoadField: r1 = r0->field_f
    //     0x1249ca4: ldur            w1, [x0, #0xf]
    // 0x1249ca8: DecompressPointer r1
    //     0x1249ca8: add             x1, x1, HEAP, lsl #32
    // 0x1249cac: LoadField: r0 = r1->field_73
    //     0x1249cac: ldur            w0, [x1, #0x73]
    // 0x1249cb0: DecompressPointer r0
    //     0x1249cb0: add             x0, x0, HEAP, lsl #32
    // 0x1249cb4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1249cb8: cmp             w0, w16
    // 0x1249cbc: b.ne            #0x1249ccc
    // 0x1249cc0: r2 = _colors
    //     0x1249cc0: add             x2, PP, #0xab, lsl #12  ; [pp+0xab480] Field <_FilledTonalIconButtonDefaultsM3@619331726._colors@619331726>: late final (offset: 0x74)
    //     0x1249cc4: ldr             x2, [x2, #0x480]
    // 0x1249cc8: r0 = InitLateFinalInstanceField()
    //     0x1249cc8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1249ccc: LoadField: r1 = r0->field_37
    //     0x1249ccc: ldur            w1, [x0, #0x37]
    // 0x1249cd0: DecompressPointer r1
    //     0x1249cd0: add             x1, x1, HEAP, lsl #32
    // 0x1249cd4: cmp             w1, NULL
    // 0x1249cd8: b.ne            #0x1249cec
    // 0x1249cdc: LoadField: r2 = r0->field_2f
    //     0x1249cdc: ldur            w2, [x0, #0x2f]
    // 0x1249ce0: DecompressPointer r2
    //     0x1249ce0: add             x2, x2, HEAP, lsl #32
    // 0x1249ce4: mov             x0, x2
    // 0x1249ce8: b               #0x1249cf0
    // 0x1249cec: mov             x0, x1
    // 0x1249cf0: LeaveFrame
    //     0x1249cf0: mov             SP, fp
    //     0x1249cf4: ldp             fp, lr, [SP], #0x10
    // 0x1249cf8: ret
    //     0x1249cf8: ret             
    // 0x1249cfc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1249cfc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1249d00: b               #0x1249b88
  }
}

// class id: 5197, size: 0x78, field offset: 0x6c
class _FilledIconButtonDefaultsM3 extends ButtonStyle {

  late final ColorScheme _colors; // offset: 0x74

  ColorScheme _colors(_FilledIconButtonDefaultsM3) {
    // ** addr: 0x1152034, size: 0x44
    // 0x1152034: EnterFrame
    //     0x1152034: stp             fp, lr, [SP, #-0x10]!
    //     0x1152038: mov             fp, SP
    // 0x115203c: CheckStackOverflow
    //     0x115203c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1152040: cmp             SP, x16
    //     0x1152044: b.ls            #0x1152070
    // 0x1152048: ldr             x0, [fp, #0x10]
    // 0x115204c: LoadField: r1 = r0->field_6b
    //     0x115204c: ldur            w1, [x0, #0x6b]
    // 0x1152050: DecompressPointer r1
    //     0x1152050: add             x1, x1, HEAP, lsl #32
    // 0x1152054: r0 = of()
    //     0x1152054: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x1152058: LoadField: r1 = r0->field_3f
    //     0x1152058: ldur            w1, [x0, #0x3f]
    // 0x115205c: DecompressPointer r1
    //     0x115205c: add             x1, x1, HEAP, lsl #32
    // 0x1152060: mov             x0, x1
    // 0x1152064: LeaveFrame
    //     0x1152064: mov             SP, fp
    //     0x1152068: ldp             fp, lr, [SP], #0x10
    // 0x115206c: ret
    //     0x115206c: ret             
    // 0x1152070: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1152070: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1152074: b               #0x1152048
  }
  get _ backgroundColor(/* No info */) {
    // ** addr: 0x12409d8, size: 0x68
    // 0x12409d8: EnterFrame
    //     0x12409d8: stp             fp, lr, [SP, #-0x10]!
    //     0x12409dc: mov             fp, SP
    // 0x12409e0: AllocStack(0x18)
    //     0x12409e0: sub             SP, SP, #0x18
    // 0x12409e4: SetupParameters(_FilledIconButtonDefaultsM3 this /* r1 => r1, fp-0x8 */)
    //     0x12409e4: stur            x1, [fp, #-8]
    // 0x12409e8: CheckStackOverflow
    //     0x12409e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12409ec: cmp             SP, x16
    //     0x12409f0: b.ls            #0x1240a38
    // 0x12409f4: r1 = 1
    //     0x12409f4: mov             x1, #1
    // 0x12409f8: r0 = AllocateContext()
    //     0x12409f8: bl              #0x13de838  ; AllocateContextStub
    // 0x12409fc: mov             x1, x0
    // 0x1240a00: ldur            x0, [fp, #-8]
    // 0x1240a04: StoreField: r1->field_f = r0
    //     0x1240a04: stur            w0, [x1, #0xf]
    // 0x1240a08: mov             x2, x1
    // 0x1240a0c: r1 = Function '<anonymous closure>':.
    //     0x1240a0c: add             x1, PP, #0xab, lsl #12  ; [pp+0xab448] AnonymousClosure: (0x1240a40), in [package:flutter/src/material/icon_button.dart] _FilledIconButtonDefaultsM3::backgroundColor (0x12409d8)
    //     0x1240a10: ldr             x1, [x1, #0x448]
    // 0x1240a14: r0 = AllocateClosure()
    //     0x1240a14: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1240a18: r16 = <Color?>
    //     0x1240a18: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1240a1c: ldr             x16, [x16, #0xa40]
    // 0x1240a20: stp             x0, x16, [SP]
    // 0x1240a24: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1240a24: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1240a28: r0 = resolveWith()
    //     0x1240a28: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1240a2c: LeaveFrame
    //     0x1240a2c: mov             SP, fp
    //     0x1240a30: ldp             fp, lr, [SP], #0x10
    // 0x1240a34: ret
    //     0x1240a34: ret             
    // 0x1240a38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1240a38: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1240a3c: b               #0x12409f4
  }
  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0x1240a40, size: 0x174
    // 0x1240a40: EnterFrame
    //     0x1240a40: stp             fp, lr, [SP, #-0x10]!
    //     0x1240a44: mov             fp, SP
    // 0x1240a48: AllocStack(0x8)
    //     0x1240a48: sub             SP, SP, #8
    // 0x1240a4c: SetupParameters([dynamic _ /* r0 */])
    //     0x1240a4c: ldr             x0, [fp, #0x18]
    //     0x1240a50: ldur            w3, [x0, #0x17]
    //     0x1240a54: add             x3, x3, HEAP, lsl #32
    //     0x1240a58: stur            x3, [fp, #-8]
    // 0x1240a5c: CheckStackOverflow
    //     0x1240a5c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1240a60: cmp             SP, x16
    //     0x1240a64: b.ls            #0x1240bac
    // 0x1240a68: ldr             x4, [fp, #0x10]
    // 0x1240a6c: r0 = LoadClassIdInstr(r4)
    //     0x1240a6c: ldur            x0, [x4, #-1]
    //     0x1240a70: ubfx            x0, x0, #0xc, #0x14
    // 0x1240a74: mov             x1, x4
    // 0x1240a78: r2 = Instance_WidgetState
    //     0x1240a78: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0x1240a7c: ldr             x2, [x2, #0xa70]
    // 0x1240a80: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1240a80: mov             x17, #0x2929
    //     0x1240a84: movk            x17, #1, lsl #16
    //     0x1240a88: add             lr, x0, x17
    //     0x1240a8c: ldr             lr, [x21, lr, lsl #3]
    //     0x1240a90: blr             lr
    // 0x1240a94: tbnz            w0, #4, #0x1240af4
    // 0x1240a98: ldur            x3, [fp, #-8]
    // 0x1240a9c: LoadField: r1 = r3->field_f
    //     0x1240a9c: ldur            w1, [x3, #0xf]
    // 0x1240aa0: DecompressPointer r1
    //     0x1240aa0: add             x1, x1, HEAP, lsl #32
    // 0x1240aa4: LoadField: r0 = r1->field_73
    //     0x1240aa4: ldur            w0, [x1, #0x73]
    // 0x1240aa8: DecompressPointer r0
    //     0x1240aa8: add             x0, x0, HEAP, lsl #32
    // 0x1240aac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1240ab0: cmp             w0, w16
    // 0x1240ab4: b.ne            #0x1240ac4
    // 0x1240ab8: r2 = _colors
    //     0x1240ab8: add             x2, PP, #0xab, lsl #12  ; [pp+0xab438] Field <_FilledIconButtonDefaultsM3@619331726._colors@619331726>: late final (offset: 0x74)
    //     0x1240abc: ldr             x2, [x2, #0x438]
    // 0x1240ac0: r0 = InitLateFinalInstanceField()
    //     0x1240ac0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1240ac4: LoadField: r1 = r0->field_7f
    //     0x1240ac4: ldur            w1, [x0, #0x7f]
    // 0x1240ac8: DecompressPointer r1
    //     0x1240ac8: add             x1, x1, HEAP, lsl #32
    // 0x1240acc: r0 = LoadClassIdInstr(r1)
    //     0x1240acc: ldur            x0, [x1, #-1]
    //     0x1240ad0: ubfx            x0, x0, #0xc, #0x14
    // 0x1240ad4: d0 = 0.120000
    //     0x1240ad4: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x1240ad8: ldr             d0, [x17, #0xc40]
    // 0x1240adc: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1240adc: sub             lr, x0, #1, lsl #12
    //     0x1240ae0: ldr             lr, [x21, lr, lsl #3]
    //     0x1240ae4: blr             lr
    // 0x1240ae8: LeaveFrame
    //     0x1240ae8: mov             SP, fp
    //     0x1240aec: ldp             fp, lr, [SP], #0x10
    // 0x1240af0: ret
    //     0x1240af0: ret             
    // 0x1240af4: ldr             x1, [fp, #0x10]
    // 0x1240af8: ldur            x3, [fp, #-8]
    // 0x1240afc: r0 = LoadClassIdInstr(r1)
    //     0x1240afc: ldur            x0, [x1, #-1]
    //     0x1240b00: ubfx            x0, x0, #0xc, #0x14
    // 0x1240b04: r2 = Instance_WidgetState
    //     0x1240b04: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0x1240b08: ldr             x2, [x2, #0x100]
    // 0x1240b0c: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1240b0c: mov             x17, #0x2929
    //     0x1240b10: movk            x17, #1, lsl #16
    //     0x1240b14: add             lr, x0, x17
    //     0x1240b18: ldr             lr, [x21, lr, lsl #3]
    //     0x1240b1c: blr             lr
    // 0x1240b20: tbnz            w0, #4, #0x1240b68
    // 0x1240b24: ldur            x0, [fp, #-8]
    // 0x1240b28: LoadField: r1 = r0->field_f
    //     0x1240b28: ldur            w1, [x0, #0xf]
    // 0x1240b2c: DecompressPointer r1
    //     0x1240b2c: add             x1, x1, HEAP, lsl #32
    // 0x1240b30: LoadField: r0 = r1->field_73
    //     0x1240b30: ldur            w0, [x1, #0x73]
    // 0x1240b34: DecompressPointer r0
    //     0x1240b34: add             x0, x0, HEAP, lsl #32
    // 0x1240b38: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1240b3c: cmp             w0, w16
    // 0x1240b40: b.ne            #0x1240b50
    // 0x1240b44: r2 = _colors
    //     0x1240b44: add             x2, PP, #0xab, lsl #12  ; [pp+0xab438] Field <_FilledIconButtonDefaultsM3@619331726._colors@619331726>: late final (offset: 0x74)
    //     0x1240b48: ldr             x2, [x2, #0x438]
    // 0x1240b4c: r0 = InitLateFinalInstanceField()
    //     0x1240b4c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1240b50: LoadField: r1 = r0->field_b
    //     0x1240b50: ldur            w1, [x0, #0xb]
    // 0x1240b54: DecompressPointer r1
    //     0x1240b54: add             x1, x1, HEAP, lsl #32
    // 0x1240b58: mov             x0, x1
    // 0x1240b5c: LeaveFrame
    //     0x1240b5c: mov             SP, fp
    //     0x1240b60: ldp             fp, lr, [SP], #0x10
    // 0x1240b64: ret
    //     0x1240b64: ret             
    // 0x1240b68: ldur            x0, [fp, #-8]
    // 0x1240b6c: LoadField: r1 = r0->field_f
    //     0x1240b6c: ldur            w1, [x0, #0xf]
    // 0x1240b70: DecompressPointer r1
    //     0x1240b70: add             x1, x1, HEAP, lsl #32
    // 0x1240b74: LoadField: r0 = r1->field_73
    //     0x1240b74: ldur            w0, [x1, #0x73]
    // 0x1240b78: DecompressPointer r0
    //     0x1240b78: add             x0, x0, HEAP, lsl #32
    // 0x1240b7c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1240b80: cmp             w0, w16
    // 0x1240b84: b.ne            #0x1240b94
    // 0x1240b88: r2 = _colors
    //     0x1240b88: add             x2, PP, #0xab, lsl #12  ; [pp+0xab438] Field <_FilledIconButtonDefaultsM3@619331726._colors@619331726>: late final (offset: 0x74)
    //     0x1240b8c: ldr             x2, [x2, #0x438]
    // 0x1240b90: r0 = InitLateFinalInstanceField()
    //     0x1240b90: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1240b94: LoadField: r1 = r0->field_b
    //     0x1240b94: ldur            w1, [x0, #0xb]
    // 0x1240b98: DecompressPointer r1
    //     0x1240b98: add             x1, x1, HEAP, lsl #32
    // 0x1240b9c: mov             x0, x1
    // 0x1240ba0: LeaveFrame
    //     0x1240ba0: mov             SP, fp
    //     0x1240ba4: ldp             fp, lr, [SP], #0x10
    // 0x1240ba8: ret
    //     0x1240ba8: ret             
    // 0x1240bac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1240bac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1240bb0: b               #0x1240a68
  }
  get _ overlayColor(/* No info */) {
    // ** addr: 0x12425b0, size: 0x68
    // 0x12425b0: EnterFrame
    //     0x12425b0: stp             fp, lr, [SP, #-0x10]!
    //     0x12425b4: mov             fp, SP
    // 0x12425b8: AllocStack(0x18)
    //     0x12425b8: sub             SP, SP, #0x18
    // 0x12425bc: SetupParameters(_FilledIconButtonDefaultsM3 this /* r1 => r1, fp-0x8 */)
    //     0x12425bc: stur            x1, [fp, #-8]
    // 0x12425c0: CheckStackOverflow
    //     0x12425c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12425c4: cmp             SP, x16
    //     0x12425c8: b.ls            #0x1242610
    // 0x12425cc: r1 = 1
    //     0x12425cc: mov             x1, #1
    // 0x12425d0: r0 = AllocateContext()
    //     0x12425d0: bl              #0x13de838  ; AllocateContextStub
    // 0x12425d4: mov             x1, x0
    // 0x12425d8: ldur            x0, [fp, #-8]
    // 0x12425dc: StoreField: r1->field_f = r0
    //     0x12425dc: stur            w0, [x1, #0xf]
    // 0x12425e0: mov             x2, x1
    // 0x12425e4: r1 = Function '<anonymous closure>':.
    //     0x12425e4: add             x1, PP, #0xab, lsl #12  ; [pp+0xab430] AnonymousClosure: (0x1242618), in [package:flutter/src/material/icon_button.dart] _FilledIconButtonDefaultsM3::overlayColor (0x12425b0)
    //     0x12425e8: ldr             x1, [x1, #0x430]
    // 0x12425ec: r0 = AllocateClosure()
    //     0x12425ec: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x12425f0: r16 = <Color?>
    //     0x12425f0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x12425f4: ldr             x16, [x16, #0xa40]
    // 0x12425f8: stp             x0, x16, [SP]
    // 0x12425fc: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x12425fc: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1242600: r0 = resolveWith()
    //     0x1242600: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1242604: LeaveFrame
    //     0x1242604: mov             SP, fp
    //     0x1242608: ldp             fp, lr, [SP], #0x10
    // 0x124260c: ret
    //     0x124260c: ret             
    // 0x1242610: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1242610: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1242614: b               #0x12425cc
  }
  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0x1242618, size: 0x374
    // 0x1242618: EnterFrame
    //     0x1242618: stp             fp, lr, [SP, #-0x10]!
    //     0x124261c: mov             fp, SP
    // 0x1242620: AllocStack(0x8)
    //     0x1242620: sub             SP, SP, #8
    // 0x1242624: SetupParameters([dynamic _ /* r0 */])
    //     0x1242624: ldr             x0, [fp, #0x18]
    //     0x1242628: ldur            w3, [x0, #0x17]
    //     0x124262c: add             x3, x3, HEAP, lsl #32
    //     0x1242630: stur            x3, [fp, #-8]
    // 0x1242634: CheckStackOverflow
    //     0x1242634: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1242638: cmp             SP, x16
    //     0x124263c: b.ls            #0x1242984
    // 0x1242640: ldr             x4, [fp, #0x10]
    // 0x1242644: r0 = LoadClassIdInstr(r4)
    //     0x1242644: ldur            x0, [x4, #-1]
    //     0x1242648: ubfx            x0, x0, #0xc, #0x14
    // 0x124264c: mov             x1, x4
    // 0x1242650: r2 = Instance_WidgetState
    //     0x1242650: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0x1242654: ldr             x2, [x2, #0x100]
    // 0x1242658: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1242658: mov             x17, #0x2929
    //     0x124265c: movk            x17, #1, lsl #16
    //     0x1242660: add             lr, x0, x17
    //     0x1242664: ldr             lr, [x21, lr, lsl #3]
    //     0x1242668: blr             lr
    // 0x124266c: tbnz            w0, #4, #0x12427f4
    // 0x1242670: ldr             x3, [fp, #0x10]
    // 0x1242674: r0 = LoadClassIdInstr(r3)
    //     0x1242674: ldur            x0, [x3, #-1]
    //     0x1242678: ubfx            x0, x0, #0xc, #0x14
    // 0x124267c: mov             x1, x3
    // 0x1242680: r2 = Instance_WidgetState
    //     0x1242680: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0x1242684: ldr             x2, [x2, #0xa48]
    // 0x1242688: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1242688: mov             x17, #0x2929
    //     0x124268c: movk            x17, #1, lsl #16
    //     0x1242690: add             lr, x0, x17
    //     0x1242694: ldr             lr, [x21, lr, lsl #3]
    //     0x1242698: blr             lr
    // 0x124269c: tbnz            w0, #4, #0x12426ec
    // 0x12426a0: ldur            x3, [fp, #-8]
    // 0x12426a4: LoadField: r1 = r3->field_f
    //     0x12426a4: ldur            w1, [x3, #0xf]
    // 0x12426a8: DecompressPointer r1
    //     0x12426a8: add             x1, x1, HEAP, lsl #32
    // 0x12426ac: LoadField: r0 = r1->field_73
    //     0x12426ac: ldur            w0, [x1, #0x73]
    // 0x12426b0: DecompressPointer r0
    //     0x12426b0: add             x0, x0, HEAP, lsl #32
    // 0x12426b4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12426b8: cmp             w0, w16
    // 0x12426bc: b.ne            #0x12426cc
    // 0x12426c0: r2 = _colors
    //     0x12426c0: add             x2, PP, #0xab, lsl #12  ; [pp+0xab438] Field <_FilledIconButtonDefaultsM3@619331726._colors@619331726>: late final (offset: 0x74)
    //     0x12426c4: ldr             x2, [x2, #0x438]
    // 0x12426c8: r0 = InitLateFinalInstanceField()
    //     0x12426c8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12426cc: LoadField: r1 = r0->field_f
    //     0x12426cc: ldur            w1, [x0, #0xf]
    // 0x12426d0: DecompressPointer r1
    //     0x12426d0: add             x1, x1, HEAP, lsl #32
    // 0x12426d4: d0 = 0.100000
    //     0x12426d4: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0x12426d8: ldr             d0, [x17, #0x1e0]
    // 0x12426dc: r0 = withOpacity()
    //     0x12426dc: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x12426e0: LeaveFrame
    //     0x12426e0: mov             SP, fp
    //     0x12426e4: ldp             fp, lr, [SP], #0x10
    // 0x12426e8: ret
    //     0x12426e8: ret             
    // 0x12426ec: ldr             x4, [fp, #0x10]
    // 0x12426f0: ldur            x3, [fp, #-8]
    // 0x12426f4: r0 = LoadClassIdInstr(r4)
    //     0x12426f4: ldur            x0, [x4, #-1]
    //     0x12426f8: ubfx            x0, x0, #0xc, #0x14
    // 0x12426fc: mov             x1, x4
    // 0x1242700: r2 = Instance_WidgetState
    //     0x1242700: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0x1242704: ldr             x2, [x2, #0xa50]
    // 0x1242708: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1242708: mov             x17, #0x2929
    //     0x124270c: movk            x17, #1, lsl #16
    //     0x1242710: add             lr, x0, x17
    //     0x1242714: ldr             lr, [x21, lr, lsl #3]
    //     0x1242718: blr             lr
    // 0x124271c: tbnz            w0, #4, #0x124276c
    // 0x1242720: ldur            x3, [fp, #-8]
    // 0x1242724: LoadField: r1 = r3->field_f
    //     0x1242724: ldur            w1, [x3, #0xf]
    // 0x1242728: DecompressPointer r1
    //     0x1242728: add             x1, x1, HEAP, lsl #32
    // 0x124272c: LoadField: r0 = r1->field_73
    //     0x124272c: ldur            w0, [x1, #0x73]
    // 0x1242730: DecompressPointer r0
    //     0x1242730: add             x0, x0, HEAP, lsl #32
    // 0x1242734: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1242738: cmp             w0, w16
    // 0x124273c: b.ne            #0x124274c
    // 0x1242740: r2 = _colors
    //     0x1242740: add             x2, PP, #0xab, lsl #12  ; [pp+0xab438] Field <_FilledIconButtonDefaultsM3@619331726._colors@619331726>: late final (offset: 0x74)
    //     0x1242744: ldr             x2, [x2, #0x438]
    // 0x1242748: r0 = InitLateFinalInstanceField()
    //     0x1242748: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x124274c: LoadField: r1 = r0->field_f
    //     0x124274c: ldur            w1, [x0, #0xf]
    // 0x1242750: DecompressPointer r1
    //     0x1242750: add             x1, x1, HEAP, lsl #32
    // 0x1242754: d0 = 0.080000
    //     0x1242754: add             x17, PP, #0x15, lsl #12  ; [pp+0x15a58] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x1242758: ldr             d0, [x17, #0xa58]
    // 0x124275c: r0 = withOpacity()
    //     0x124275c: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x1242760: LeaveFrame
    //     0x1242760: mov             SP, fp
    //     0x1242764: ldp             fp, lr, [SP], #0x10
    // 0x1242768: ret
    //     0x1242768: ret             
    // 0x124276c: ldr             x4, [fp, #0x10]
    // 0x1242770: ldur            x3, [fp, #-8]
    // 0x1242774: r0 = LoadClassIdInstr(r4)
    //     0x1242774: ldur            x0, [x4, #-1]
    //     0x1242778: ubfx            x0, x0, #0xc, #0x14
    // 0x124277c: mov             x1, x4
    // 0x1242780: r2 = Instance_WidgetState
    //     0x1242780: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0x1242784: ldr             x2, [x2, #0xa60]
    // 0x1242788: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1242788: mov             x17, #0x2929
    //     0x124278c: movk            x17, #1, lsl #16
    //     0x1242790: add             lr, x0, x17
    //     0x1242794: ldr             lr, [x21, lr, lsl #3]
    //     0x1242798: blr             lr
    // 0x124279c: tbnz            w0, #4, #0x12427ec
    // 0x12427a0: ldur            x3, [fp, #-8]
    // 0x12427a4: LoadField: r1 = r3->field_f
    //     0x12427a4: ldur            w1, [x3, #0xf]
    // 0x12427a8: DecompressPointer r1
    //     0x12427a8: add             x1, x1, HEAP, lsl #32
    // 0x12427ac: LoadField: r0 = r1->field_73
    //     0x12427ac: ldur            w0, [x1, #0x73]
    // 0x12427b0: DecompressPointer r0
    //     0x12427b0: add             x0, x0, HEAP, lsl #32
    // 0x12427b4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12427b8: cmp             w0, w16
    // 0x12427bc: b.ne            #0x12427cc
    // 0x12427c0: r2 = _colors
    //     0x12427c0: add             x2, PP, #0xab, lsl #12  ; [pp+0xab438] Field <_FilledIconButtonDefaultsM3@619331726._colors@619331726>: late final (offset: 0x74)
    //     0x12427c4: ldr             x2, [x2, #0x438]
    // 0x12427c8: r0 = InitLateFinalInstanceField()
    //     0x12427c8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12427cc: LoadField: r1 = r0->field_f
    //     0x12427cc: ldur            w1, [x0, #0xf]
    // 0x12427d0: DecompressPointer r1
    //     0x12427d0: add             x1, x1, HEAP, lsl #32
    // 0x12427d4: d0 = 0.100000
    //     0x12427d4: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0x12427d8: ldr             d0, [x17, #0x1e0]
    // 0x12427dc: r0 = withOpacity()
    //     0x12427dc: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x12427e0: LeaveFrame
    //     0x12427e0: mov             SP, fp
    //     0x12427e4: ldp             fp, lr, [SP], #0x10
    // 0x12427e8: ret
    //     0x12427e8: ret             
    // 0x12427ec: ldur            x3, [fp, #-8]
    // 0x12427f0: b               #0x12427f8
    // 0x12427f4: ldur            x3, [fp, #-8]
    // 0x12427f8: ldr             x4, [fp, #0x10]
    // 0x12427fc: r0 = LoadClassIdInstr(r4)
    //     0x12427fc: ldur            x0, [x4, #-1]
    //     0x1242800: ubfx            x0, x0, #0xc, #0x14
    // 0x1242804: mov             x1, x4
    // 0x1242808: r2 = Instance_WidgetState
    //     0x1242808: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0x124280c: ldr             x2, [x2, #0xa48]
    // 0x1242810: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1242810: mov             x17, #0x2929
    //     0x1242814: movk            x17, #1, lsl #16
    //     0x1242818: add             lr, x0, x17
    //     0x124281c: ldr             lr, [x21, lr, lsl #3]
    //     0x1242820: blr             lr
    // 0x1242824: tbnz            w0, #4, #0x1242874
    // 0x1242828: ldur            x3, [fp, #-8]
    // 0x124282c: LoadField: r1 = r3->field_f
    //     0x124282c: ldur            w1, [x3, #0xf]
    // 0x1242830: DecompressPointer r1
    //     0x1242830: add             x1, x1, HEAP, lsl #32
    // 0x1242834: LoadField: r0 = r1->field_73
    //     0x1242834: ldur            w0, [x1, #0x73]
    // 0x1242838: DecompressPointer r0
    //     0x1242838: add             x0, x0, HEAP, lsl #32
    // 0x124283c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1242840: cmp             w0, w16
    // 0x1242844: b.ne            #0x1242854
    // 0x1242848: r2 = _colors
    //     0x1242848: add             x2, PP, #0xab, lsl #12  ; [pp+0xab438] Field <_FilledIconButtonDefaultsM3@619331726._colors@619331726>: late final (offset: 0x74)
    //     0x124284c: ldr             x2, [x2, #0x438]
    // 0x1242850: r0 = InitLateFinalInstanceField()
    //     0x1242850: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1242854: LoadField: r1 = r0->field_f
    //     0x1242854: ldur            w1, [x0, #0xf]
    // 0x1242858: DecompressPointer r1
    //     0x1242858: add             x1, x1, HEAP, lsl #32
    // 0x124285c: d0 = 0.100000
    //     0x124285c: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0x1242860: ldr             d0, [x17, #0x1e0]
    // 0x1242864: r0 = withOpacity()
    //     0x1242864: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x1242868: LeaveFrame
    //     0x1242868: mov             SP, fp
    //     0x124286c: ldp             fp, lr, [SP], #0x10
    // 0x1242870: ret
    //     0x1242870: ret             
    // 0x1242874: ldr             x4, [fp, #0x10]
    // 0x1242878: ldur            x3, [fp, #-8]
    // 0x124287c: r0 = LoadClassIdInstr(r4)
    //     0x124287c: ldur            x0, [x4, #-1]
    //     0x1242880: ubfx            x0, x0, #0xc, #0x14
    // 0x1242884: mov             x1, x4
    // 0x1242888: r2 = Instance_WidgetState
    //     0x1242888: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0x124288c: ldr             x2, [x2, #0xa50]
    // 0x1242890: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1242890: mov             x17, #0x2929
    //     0x1242894: movk            x17, #1, lsl #16
    //     0x1242898: add             lr, x0, x17
    //     0x124289c: ldr             lr, [x21, lr, lsl #3]
    //     0x12428a0: blr             lr
    // 0x12428a4: tbnz            w0, #4, #0x12428f4
    // 0x12428a8: ldur            x3, [fp, #-8]
    // 0x12428ac: LoadField: r1 = r3->field_f
    //     0x12428ac: ldur            w1, [x3, #0xf]
    // 0x12428b0: DecompressPointer r1
    //     0x12428b0: add             x1, x1, HEAP, lsl #32
    // 0x12428b4: LoadField: r0 = r1->field_73
    //     0x12428b4: ldur            w0, [x1, #0x73]
    // 0x12428b8: DecompressPointer r0
    //     0x12428b8: add             x0, x0, HEAP, lsl #32
    // 0x12428bc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12428c0: cmp             w0, w16
    // 0x12428c4: b.ne            #0x12428d4
    // 0x12428c8: r2 = _colors
    //     0x12428c8: add             x2, PP, #0xab, lsl #12  ; [pp+0xab438] Field <_FilledIconButtonDefaultsM3@619331726._colors@619331726>: late final (offset: 0x74)
    //     0x12428cc: ldr             x2, [x2, #0x438]
    // 0x12428d0: r0 = InitLateFinalInstanceField()
    //     0x12428d0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12428d4: LoadField: r1 = r0->field_f
    //     0x12428d4: ldur            w1, [x0, #0xf]
    // 0x12428d8: DecompressPointer r1
    //     0x12428d8: add             x1, x1, HEAP, lsl #32
    // 0x12428dc: d0 = 0.080000
    //     0x12428dc: add             x17, PP, #0x15, lsl #12  ; [pp+0x15a58] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x12428e0: ldr             d0, [x17, #0xa58]
    // 0x12428e4: r0 = withOpacity()
    //     0x12428e4: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x12428e8: LeaveFrame
    //     0x12428e8: mov             SP, fp
    //     0x12428ec: ldp             fp, lr, [SP], #0x10
    // 0x12428f0: ret
    //     0x12428f0: ret             
    // 0x12428f4: ldr             x1, [fp, #0x10]
    // 0x12428f8: ldur            x3, [fp, #-8]
    // 0x12428fc: r0 = LoadClassIdInstr(r1)
    //     0x12428fc: ldur            x0, [x1, #-1]
    //     0x1242900: ubfx            x0, x0, #0xc, #0x14
    // 0x1242904: r2 = Instance_WidgetState
    //     0x1242904: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0x1242908: ldr             x2, [x2, #0xa60]
    // 0x124290c: r0 = GDT[cid_x0 + 0x12929]()
    //     0x124290c: mov             x17, #0x2929
    //     0x1242910: movk            x17, #1, lsl #16
    //     0x1242914: add             lr, x0, x17
    //     0x1242918: ldr             lr, [x21, lr, lsl #3]
    //     0x124291c: blr             lr
    // 0x1242920: tbnz            w0, #4, #0x1242970
    // 0x1242924: ldur            x0, [fp, #-8]
    // 0x1242928: LoadField: r1 = r0->field_f
    //     0x1242928: ldur            w1, [x0, #0xf]
    // 0x124292c: DecompressPointer r1
    //     0x124292c: add             x1, x1, HEAP, lsl #32
    // 0x1242930: LoadField: r0 = r1->field_73
    //     0x1242930: ldur            w0, [x1, #0x73]
    // 0x1242934: DecompressPointer r0
    //     0x1242934: add             x0, x0, HEAP, lsl #32
    // 0x1242938: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x124293c: cmp             w0, w16
    // 0x1242940: b.ne            #0x1242950
    // 0x1242944: r2 = _colors
    //     0x1242944: add             x2, PP, #0xab, lsl #12  ; [pp+0xab438] Field <_FilledIconButtonDefaultsM3@619331726._colors@619331726>: late final (offset: 0x74)
    //     0x1242948: ldr             x2, [x2, #0x438]
    // 0x124294c: r0 = InitLateFinalInstanceField()
    //     0x124294c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1242950: LoadField: r1 = r0->field_f
    //     0x1242950: ldur            w1, [x0, #0xf]
    // 0x1242954: DecompressPointer r1
    //     0x1242954: add             x1, x1, HEAP, lsl #32
    // 0x1242958: d0 = 0.100000
    //     0x1242958: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0x124295c: ldr             d0, [x17, #0x1e0]
    // 0x1242960: r0 = withOpacity()
    //     0x1242960: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x1242964: LeaveFrame
    //     0x1242964: mov             SP, fp
    //     0x1242968: ldp             fp, lr, [SP], #0x10
    // 0x124296c: ret
    //     0x124296c: ret             
    // 0x1242970: r0 = Instance_Color
    //     0x1242970: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x1242974: ldr             x0, [x0, #0x810]
    // 0x1242978: LeaveFrame
    //     0x1242978: mov             SP, fp
    //     0x124297c: ldp             fp, lr, [SP], #0x10
    // 0x1242980: ret
    //     0x1242980: ret             
    // 0x1242984: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1242984: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1242988: b               #0x1242640
  }
  get _ foregroundColor(/* No info */) {
    // ** addr: 0x124991c, size: 0x68
    // 0x124991c: EnterFrame
    //     0x124991c: stp             fp, lr, [SP, #-0x10]!
    //     0x1249920: mov             fp, SP
    // 0x1249924: AllocStack(0x18)
    //     0x1249924: sub             SP, SP, #0x18
    // 0x1249928: SetupParameters(_FilledIconButtonDefaultsM3 this /* r1 => r1, fp-0x8 */)
    //     0x1249928: stur            x1, [fp, #-8]
    // 0x124992c: CheckStackOverflow
    //     0x124992c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1249930: cmp             SP, x16
    //     0x1249934: b.ls            #0x124997c
    // 0x1249938: r1 = 1
    //     0x1249938: mov             x1, #1
    // 0x124993c: r0 = AllocateContext()
    //     0x124993c: bl              #0x13de838  ; AllocateContextStub
    // 0x1249940: mov             x1, x0
    // 0x1249944: ldur            x0, [fp, #-8]
    // 0x1249948: StoreField: r1->field_f = r0
    //     0x1249948: stur            w0, [x1, #0xf]
    // 0x124994c: mov             x2, x1
    // 0x1249950: r1 = Function '<anonymous closure>':.
    //     0x1249950: add             x1, PP, #0xab, lsl #12  ; [pp+0xab440] AnonymousClosure: (0x1249984), in [package:flutter/src/material/icon_button.dart] _FilledIconButtonDefaultsM3::foregroundColor (0x124991c)
    //     0x1249954: ldr             x1, [x1, #0x440]
    // 0x1249958: r0 = AllocateClosure()
    //     0x1249958: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x124995c: r16 = <Color?>
    //     0x124995c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1249960: ldr             x16, [x16, #0xa40]
    // 0x1249964: stp             x0, x16, [SP]
    // 0x1249968: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1249968: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x124996c: r0 = resolveWith()
    //     0x124996c: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1249970: LeaveFrame
    //     0x1249970: mov             SP, fp
    //     0x1249974: ldp             fp, lr, [SP], #0x10
    // 0x1249978: ret
    //     0x1249978: ret             
    // 0x124997c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x124997c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1249980: b               #0x1249938
  }
  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0x1249984, size: 0x174
    // 0x1249984: EnterFrame
    //     0x1249984: stp             fp, lr, [SP, #-0x10]!
    //     0x1249988: mov             fp, SP
    // 0x124998c: AllocStack(0x8)
    //     0x124998c: sub             SP, SP, #8
    // 0x1249990: SetupParameters([dynamic _ /* r0 */])
    //     0x1249990: ldr             x0, [fp, #0x18]
    //     0x1249994: ldur            w3, [x0, #0x17]
    //     0x1249998: add             x3, x3, HEAP, lsl #32
    //     0x124999c: stur            x3, [fp, #-8]
    // 0x12499a0: CheckStackOverflow
    //     0x12499a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12499a4: cmp             SP, x16
    //     0x12499a8: b.ls            #0x1249af0
    // 0x12499ac: ldr             x4, [fp, #0x10]
    // 0x12499b0: r0 = LoadClassIdInstr(r4)
    //     0x12499b0: ldur            x0, [x4, #-1]
    //     0x12499b4: ubfx            x0, x0, #0xc, #0x14
    // 0x12499b8: mov             x1, x4
    // 0x12499bc: r2 = Instance_WidgetState
    //     0x12499bc: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0x12499c0: ldr             x2, [x2, #0xa70]
    // 0x12499c4: r0 = GDT[cid_x0 + 0x12929]()
    //     0x12499c4: mov             x17, #0x2929
    //     0x12499c8: movk            x17, #1, lsl #16
    //     0x12499cc: add             lr, x0, x17
    //     0x12499d0: ldr             lr, [x21, lr, lsl #3]
    //     0x12499d4: blr             lr
    // 0x12499d8: tbnz            w0, #4, #0x1249a38
    // 0x12499dc: ldur            x3, [fp, #-8]
    // 0x12499e0: LoadField: r1 = r3->field_f
    //     0x12499e0: ldur            w1, [x3, #0xf]
    // 0x12499e4: DecompressPointer r1
    //     0x12499e4: add             x1, x1, HEAP, lsl #32
    // 0x12499e8: LoadField: r0 = r1->field_73
    //     0x12499e8: ldur            w0, [x1, #0x73]
    // 0x12499ec: DecompressPointer r0
    //     0x12499ec: add             x0, x0, HEAP, lsl #32
    // 0x12499f0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12499f4: cmp             w0, w16
    // 0x12499f8: b.ne            #0x1249a08
    // 0x12499fc: r2 = _colors
    //     0x12499fc: add             x2, PP, #0xab, lsl #12  ; [pp+0xab438] Field <_FilledIconButtonDefaultsM3@619331726._colors@619331726>: late final (offset: 0x74)
    //     0x1249a00: ldr             x2, [x2, #0x438]
    // 0x1249a04: r0 = InitLateFinalInstanceField()
    //     0x1249a04: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1249a08: LoadField: r1 = r0->field_7f
    //     0x1249a08: ldur            w1, [x0, #0x7f]
    // 0x1249a0c: DecompressPointer r1
    //     0x1249a0c: add             x1, x1, HEAP, lsl #32
    // 0x1249a10: r0 = LoadClassIdInstr(r1)
    //     0x1249a10: ldur            x0, [x1, #-1]
    //     0x1249a14: ubfx            x0, x0, #0xc, #0x14
    // 0x1249a18: d0 = 0.380000
    //     0x1249a18: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0x1249a1c: ldr             d0, [x17, #0x1f0]
    // 0x1249a20: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1249a20: sub             lr, x0, #1, lsl #12
    //     0x1249a24: ldr             lr, [x21, lr, lsl #3]
    //     0x1249a28: blr             lr
    // 0x1249a2c: LeaveFrame
    //     0x1249a2c: mov             SP, fp
    //     0x1249a30: ldp             fp, lr, [SP], #0x10
    // 0x1249a34: ret
    //     0x1249a34: ret             
    // 0x1249a38: ldr             x1, [fp, #0x10]
    // 0x1249a3c: ldur            x3, [fp, #-8]
    // 0x1249a40: r0 = LoadClassIdInstr(r1)
    //     0x1249a40: ldur            x0, [x1, #-1]
    //     0x1249a44: ubfx            x0, x0, #0xc, #0x14
    // 0x1249a48: r2 = Instance_WidgetState
    //     0x1249a48: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0x1249a4c: ldr             x2, [x2, #0x100]
    // 0x1249a50: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1249a50: mov             x17, #0x2929
    //     0x1249a54: movk            x17, #1, lsl #16
    //     0x1249a58: add             lr, x0, x17
    //     0x1249a5c: ldr             lr, [x21, lr, lsl #3]
    //     0x1249a60: blr             lr
    // 0x1249a64: tbnz            w0, #4, #0x1249aac
    // 0x1249a68: ldur            x0, [fp, #-8]
    // 0x1249a6c: LoadField: r1 = r0->field_f
    //     0x1249a6c: ldur            w1, [x0, #0xf]
    // 0x1249a70: DecompressPointer r1
    //     0x1249a70: add             x1, x1, HEAP, lsl #32
    // 0x1249a74: LoadField: r0 = r1->field_73
    //     0x1249a74: ldur            w0, [x1, #0x73]
    // 0x1249a78: DecompressPointer r0
    //     0x1249a78: add             x0, x0, HEAP, lsl #32
    // 0x1249a7c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1249a80: cmp             w0, w16
    // 0x1249a84: b.ne            #0x1249a94
    // 0x1249a88: r2 = _colors
    //     0x1249a88: add             x2, PP, #0xab, lsl #12  ; [pp+0xab438] Field <_FilledIconButtonDefaultsM3@619331726._colors@619331726>: late final (offset: 0x74)
    //     0x1249a8c: ldr             x2, [x2, #0x438]
    // 0x1249a90: r0 = InitLateFinalInstanceField()
    //     0x1249a90: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1249a94: LoadField: r1 = r0->field_f
    //     0x1249a94: ldur            w1, [x0, #0xf]
    // 0x1249a98: DecompressPointer r1
    //     0x1249a98: add             x1, x1, HEAP, lsl #32
    // 0x1249a9c: mov             x0, x1
    // 0x1249aa0: LeaveFrame
    //     0x1249aa0: mov             SP, fp
    //     0x1249aa4: ldp             fp, lr, [SP], #0x10
    // 0x1249aa8: ret
    //     0x1249aa8: ret             
    // 0x1249aac: ldur            x0, [fp, #-8]
    // 0x1249ab0: LoadField: r1 = r0->field_f
    //     0x1249ab0: ldur            w1, [x0, #0xf]
    // 0x1249ab4: DecompressPointer r1
    //     0x1249ab4: add             x1, x1, HEAP, lsl #32
    // 0x1249ab8: LoadField: r0 = r1->field_73
    //     0x1249ab8: ldur            w0, [x1, #0x73]
    // 0x1249abc: DecompressPointer r0
    //     0x1249abc: add             x0, x0, HEAP, lsl #32
    // 0x1249ac0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1249ac4: cmp             w0, w16
    // 0x1249ac8: b.ne            #0x1249ad8
    // 0x1249acc: r2 = _colors
    //     0x1249acc: add             x2, PP, #0xab, lsl #12  ; [pp+0xab438] Field <_FilledIconButtonDefaultsM3@619331726._colors@619331726>: late final (offset: 0x74)
    //     0x1249ad0: ldr             x2, [x2, #0x438]
    // 0x1249ad4: r0 = InitLateFinalInstanceField()
    //     0x1249ad4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1249ad8: LoadField: r1 = r0->field_f
    //     0x1249ad8: ldur            w1, [x0, #0xf]
    // 0x1249adc: DecompressPointer r1
    //     0x1249adc: add             x1, x1, HEAP, lsl #32
    // 0x1249ae0: mov             x0, x1
    // 0x1249ae4: LeaveFrame
    //     0x1249ae4: mov             SP, fp
    //     0x1249ae8: ldp             fp, lr, [SP], #0x10
    // 0x1249aec: ret
    //     0x1249aec: ret             
    // 0x1249af0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1249af0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1249af4: b               #0x12499ac
  }
}

// class id: 5198, size: 0x74, field offset: 0x6c
class _IconButtonDefaultsM3 extends ButtonStyle {

  late final ColorScheme _colors; // offset: 0x70

  get _ backgroundColor(/* No info */) {
    // ** addr: 0x12409cc, size: 0xc
    // 0x12409cc: r0 = Instance_WidgetStatePropertyAll
    //     0x12409cc: add             x0, PP, #0xab, lsl #12  ; [pp+0xab428] Obj!WidgetStatePropertyAll<Color?>@128a0f1
    //     0x12409d0: ldr             x0, [x0, #0x428]
    // 0x12409d4: ret
    //     0x12409d4: ret             
  }
  get _ overlayColor(/* No info */) {
    // ** addr: 0x1242174, size: 0x68
    // 0x1242174: EnterFrame
    //     0x1242174: stp             fp, lr, [SP, #-0x10]!
    //     0x1242178: mov             fp, SP
    // 0x124217c: AllocStack(0x18)
    //     0x124217c: sub             SP, SP, #0x18
    // 0x1242180: SetupParameters(_IconButtonDefaultsM3 this /* r1 => r1, fp-0x8 */)
    //     0x1242180: stur            x1, [fp, #-8]
    // 0x1242184: CheckStackOverflow
    //     0x1242184: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1242188: cmp             SP, x16
    //     0x124218c: b.ls            #0x12421d4
    // 0x1242190: r1 = 1
    //     0x1242190: mov             x1, #1
    // 0x1242194: r0 = AllocateContext()
    //     0x1242194: bl              #0x13de838  ; AllocateContextStub
    // 0x1242198: mov             x1, x0
    // 0x124219c: ldur            x0, [fp, #-8]
    // 0x12421a0: StoreField: r1->field_f = r0
    //     0x12421a0: stur            w0, [x1, #0xf]
    // 0x12421a4: mov             x2, x1
    // 0x12421a8: r1 = Function '<anonymous closure>':.
    //     0x12421a8: add             x1, PP, #0xab, lsl #12  ; [pp+0xab410] AnonymousClosure: (0x12421dc), in [package:flutter/src/material/icon_button.dart] _IconButtonDefaultsM3::overlayColor (0x1242174)
    //     0x12421ac: ldr             x1, [x1, #0x410]
    // 0x12421b0: r0 = AllocateClosure()
    //     0x12421b0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x12421b4: r16 = <Color?>
    //     0x12421b4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x12421b8: ldr             x16, [x16, #0xa40]
    // 0x12421bc: stp             x0, x16, [SP]
    // 0x12421c0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x12421c0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x12421c4: r0 = resolveWith()
    //     0x12421c4: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x12421c8: LeaveFrame
    //     0x12421c8: mov             SP, fp
    //     0x12421cc: ldp             fp, lr, [SP], #0x10
    // 0x12421d0: ret
    //     0x12421d0: ret             
    // 0x12421d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12421d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12421d8: b               #0x1242190
  }
  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0x12421dc, size: 0x3d4
    // 0x12421dc: EnterFrame
    //     0x12421dc: stp             fp, lr, [SP, #-0x10]!
    //     0x12421e0: mov             fp, SP
    // 0x12421e4: AllocStack(0x8)
    //     0x12421e4: sub             SP, SP, #8
    // 0x12421e8: SetupParameters([dynamic _ /* r0 */])
    //     0x12421e8: ldr             x0, [fp, #0x18]
    //     0x12421ec: ldur            w3, [x0, #0x17]
    //     0x12421f0: add             x3, x3, HEAP, lsl #32
    //     0x12421f4: stur            x3, [fp, #-8]
    // 0x12421f8: CheckStackOverflow
    //     0x12421f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12421fc: cmp             SP, x16
    //     0x1242200: b.ls            #0x12425a8
    // 0x1242204: ldr             x4, [fp, #0x10]
    // 0x1242208: r0 = LoadClassIdInstr(r4)
    //     0x1242208: ldur            x0, [x4, #-1]
    //     0x124220c: ubfx            x0, x0, #0xc, #0x14
    // 0x1242210: mov             x1, x4
    // 0x1242214: r2 = Instance_WidgetState
    //     0x1242214: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0x1242218: ldr             x2, [x2, #0x100]
    // 0x124221c: r0 = GDT[cid_x0 + 0x12929]()
    //     0x124221c: mov             x17, #0x2929
    //     0x1242220: movk            x17, #1, lsl #16
    //     0x1242224: add             lr, x0, x17
    //     0x1242228: ldr             lr, [x21, lr, lsl #3]
    //     0x124222c: blr             lr
    // 0x1242230: tbnz            w0, #4, #0x12423b8
    // 0x1242234: ldr             x3, [fp, #0x10]
    // 0x1242238: r0 = LoadClassIdInstr(r3)
    //     0x1242238: ldur            x0, [x3, #-1]
    //     0x124223c: ubfx            x0, x0, #0xc, #0x14
    // 0x1242240: mov             x1, x3
    // 0x1242244: r2 = Instance_WidgetState
    //     0x1242244: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0x1242248: ldr             x2, [x2, #0xa48]
    // 0x124224c: r0 = GDT[cid_x0 + 0x12929]()
    //     0x124224c: mov             x17, #0x2929
    //     0x1242250: movk            x17, #1, lsl #16
    //     0x1242254: add             lr, x0, x17
    //     0x1242258: ldr             lr, [x21, lr, lsl #3]
    //     0x124225c: blr             lr
    // 0x1242260: tbnz            w0, #4, #0x12422b0
    // 0x1242264: ldur            x3, [fp, #-8]
    // 0x1242268: LoadField: r1 = r3->field_f
    //     0x1242268: ldur            w1, [x3, #0xf]
    // 0x124226c: DecompressPointer r1
    //     0x124226c: add             x1, x1, HEAP, lsl #32
    // 0x1242270: LoadField: r0 = r1->field_6f
    //     0x1242270: ldur            w0, [x1, #0x6f]
    // 0x1242274: DecompressPointer r0
    //     0x1242274: add             x0, x0, HEAP, lsl #32
    // 0x1242278: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x124227c: cmp             w0, w16
    // 0x1242280: b.ne            #0x1242290
    // 0x1242284: r2 = _colors
    //     0x1242284: add             x2, PP, #0xab, lsl #12  ; [pp+0xab418] Field <_IconButtonDefaultsM3@619331726._colors@619331726>: late final (offset: 0x70)
    //     0x1242288: ldr             x2, [x2, #0x418]
    // 0x124228c: r0 = InitLateFinalInstanceField()
    //     0x124228c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1242290: LoadField: r1 = r0->field_b
    //     0x1242290: ldur            w1, [x0, #0xb]
    // 0x1242294: DecompressPointer r1
    //     0x1242294: add             x1, x1, HEAP, lsl #32
    // 0x1242298: d0 = 0.100000
    //     0x1242298: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0x124229c: ldr             d0, [x17, #0x1e0]
    // 0x12422a0: r0 = withOpacity()
    //     0x12422a0: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x12422a4: LeaveFrame
    //     0x12422a4: mov             SP, fp
    //     0x12422a8: ldp             fp, lr, [SP], #0x10
    // 0x12422ac: ret
    //     0x12422ac: ret             
    // 0x12422b0: ldr             x4, [fp, #0x10]
    // 0x12422b4: ldur            x3, [fp, #-8]
    // 0x12422b8: r0 = LoadClassIdInstr(r4)
    //     0x12422b8: ldur            x0, [x4, #-1]
    //     0x12422bc: ubfx            x0, x0, #0xc, #0x14
    // 0x12422c0: mov             x1, x4
    // 0x12422c4: r2 = Instance_WidgetState
    //     0x12422c4: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0x12422c8: ldr             x2, [x2, #0xa50]
    // 0x12422cc: r0 = GDT[cid_x0 + 0x12929]()
    //     0x12422cc: mov             x17, #0x2929
    //     0x12422d0: movk            x17, #1, lsl #16
    //     0x12422d4: add             lr, x0, x17
    //     0x12422d8: ldr             lr, [x21, lr, lsl #3]
    //     0x12422dc: blr             lr
    // 0x12422e0: tbnz            w0, #4, #0x1242330
    // 0x12422e4: ldur            x3, [fp, #-8]
    // 0x12422e8: LoadField: r1 = r3->field_f
    //     0x12422e8: ldur            w1, [x3, #0xf]
    // 0x12422ec: DecompressPointer r1
    //     0x12422ec: add             x1, x1, HEAP, lsl #32
    // 0x12422f0: LoadField: r0 = r1->field_6f
    //     0x12422f0: ldur            w0, [x1, #0x6f]
    // 0x12422f4: DecompressPointer r0
    //     0x12422f4: add             x0, x0, HEAP, lsl #32
    // 0x12422f8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12422fc: cmp             w0, w16
    // 0x1242300: b.ne            #0x1242310
    // 0x1242304: r2 = _colors
    //     0x1242304: add             x2, PP, #0xab, lsl #12  ; [pp+0xab418] Field <_IconButtonDefaultsM3@619331726._colors@619331726>: late final (offset: 0x70)
    //     0x1242308: ldr             x2, [x2, #0x418]
    // 0x124230c: r0 = InitLateFinalInstanceField()
    //     0x124230c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1242310: LoadField: r1 = r0->field_b
    //     0x1242310: ldur            w1, [x0, #0xb]
    // 0x1242314: DecompressPointer r1
    //     0x1242314: add             x1, x1, HEAP, lsl #32
    // 0x1242318: d0 = 0.080000
    //     0x1242318: add             x17, PP, #0x15, lsl #12  ; [pp+0x15a58] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x124231c: ldr             d0, [x17, #0xa58]
    // 0x1242320: r0 = withOpacity()
    //     0x1242320: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x1242324: LeaveFrame
    //     0x1242324: mov             SP, fp
    //     0x1242328: ldp             fp, lr, [SP], #0x10
    // 0x124232c: ret
    //     0x124232c: ret             
    // 0x1242330: ldr             x4, [fp, #0x10]
    // 0x1242334: ldur            x3, [fp, #-8]
    // 0x1242338: r0 = LoadClassIdInstr(r4)
    //     0x1242338: ldur            x0, [x4, #-1]
    //     0x124233c: ubfx            x0, x0, #0xc, #0x14
    // 0x1242340: mov             x1, x4
    // 0x1242344: r2 = Instance_WidgetState
    //     0x1242344: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0x1242348: ldr             x2, [x2, #0xa60]
    // 0x124234c: r0 = GDT[cid_x0 + 0x12929]()
    //     0x124234c: mov             x17, #0x2929
    //     0x1242350: movk            x17, #1, lsl #16
    //     0x1242354: add             lr, x0, x17
    //     0x1242358: ldr             lr, [x21, lr, lsl #3]
    //     0x124235c: blr             lr
    // 0x1242360: tbnz            w0, #4, #0x12423b0
    // 0x1242364: ldur            x3, [fp, #-8]
    // 0x1242368: LoadField: r1 = r3->field_f
    //     0x1242368: ldur            w1, [x3, #0xf]
    // 0x124236c: DecompressPointer r1
    //     0x124236c: add             x1, x1, HEAP, lsl #32
    // 0x1242370: LoadField: r0 = r1->field_6f
    //     0x1242370: ldur            w0, [x1, #0x6f]
    // 0x1242374: DecompressPointer r0
    //     0x1242374: add             x0, x0, HEAP, lsl #32
    // 0x1242378: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x124237c: cmp             w0, w16
    // 0x1242380: b.ne            #0x1242390
    // 0x1242384: r2 = _colors
    //     0x1242384: add             x2, PP, #0xab, lsl #12  ; [pp+0xab418] Field <_IconButtonDefaultsM3@619331726._colors@619331726>: late final (offset: 0x70)
    //     0x1242388: ldr             x2, [x2, #0x418]
    // 0x124238c: r0 = InitLateFinalInstanceField()
    //     0x124238c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1242390: LoadField: r1 = r0->field_b
    //     0x1242390: ldur            w1, [x0, #0xb]
    // 0x1242394: DecompressPointer r1
    //     0x1242394: add             x1, x1, HEAP, lsl #32
    // 0x1242398: d0 = 0.100000
    //     0x1242398: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0x124239c: ldr             d0, [x17, #0x1e0]
    // 0x12423a0: r0 = withOpacity()
    //     0x12423a0: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x12423a4: LeaveFrame
    //     0x12423a4: mov             SP, fp
    //     0x12423a8: ldp             fp, lr, [SP], #0x10
    // 0x12423ac: ret
    //     0x12423ac: ret             
    // 0x12423b0: ldur            x3, [fp, #-8]
    // 0x12423b4: b               #0x12423bc
    // 0x12423b8: ldur            x3, [fp, #-8]
    // 0x12423bc: ldr             x4, [fp, #0x10]
    // 0x12423c0: r0 = LoadClassIdInstr(r4)
    //     0x12423c0: ldur            x0, [x4, #-1]
    //     0x12423c4: ubfx            x0, x0, #0xc, #0x14
    // 0x12423c8: mov             x1, x4
    // 0x12423cc: r2 = Instance_WidgetState
    //     0x12423cc: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0x12423d0: ldr             x2, [x2, #0xa48]
    // 0x12423d4: r0 = GDT[cid_x0 + 0x12929]()
    //     0x12423d4: mov             x17, #0x2929
    //     0x12423d8: movk            x17, #1, lsl #16
    //     0x12423dc: add             lr, x0, x17
    //     0x12423e0: ldr             lr, [x21, lr, lsl #3]
    //     0x12423e4: blr             lr
    // 0x12423e8: tbnz            w0, #4, #0x1242458
    // 0x12423ec: ldur            x3, [fp, #-8]
    // 0x12423f0: LoadField: r1 = r3->field_f
    //     0x12423f0: ldur            w1, [x3, #0xf]
    // 0x12423f4: DecompressPointer r1
    //     0x12423f4: add             x1, x1, HEAP, lsl #32
    // 0x12423f8: LoadField: r0 = r1->field_6f
    //     0x12423f8: ldur            w0, [x1, #0x6f]
    // 0x12423fc: DecompressPointer r0
    //     0x12423fc: add             x0, x0, HEAP, lsl #32
    // 0x1242400: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1242404: cmp             w0, w16
    // 0x1242408: b.ne            #0x1242418
    // 0x124240c: r2 = _colors
    //     0x124240c: add             x2, PP, #0xab, lsl #12  ; [pp+0xab418] Field <_IconButtonDefaultsM3@619331726._colors@619331726>: late final (offset: 0x70)
    //     0x1242410: ldr             x2, [x2, #0x418]
    // 0x1242414: r0 = InitLateFinalInstanceField()
    //     0x1242414: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1242418: LoadField: r1 = r0->field_a3
    //     0x1242418: ldur            w1, [x0, #0xa3]
    // 0x124241c: DecompressPointer r1
    //     0x124241c: add             x1, x1, HEAP, lsl #32
    // 0x1242420: cmp             w1, NULL
    // 0x1242424: b.ne            #0x1242430
    // 0x1242428: LoadField: r1 = r0->field_7f
    //     0x1242428: ldur            w1, [x0, #0x7f]
    // 0x124242c: DecompressPointer r1
    //     0x124242c: add             x1, x1, HEAP, lsl #32
    // 0x1242430: r0 = LoadClassIdInstr(r1)
    //     0x1242430: ldur            x0, [x1, #-1]
    //     0x1242434: ubfx            x0, x0, #0xc, #0x14
    // 0x1242438: d0 = 0.100000
    //     0x1242438: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0x124243c: ldr             d0, [x17, #0x1e0]
    // 0x1242440: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1242440: sub             lr, x0, #1, lsl #12
    //     0x1242444: ldr             lr, [x21, lr, lsl #3]
    //     0x1242448: blr             lr
    // 0x124244c: LeaveFrame
    //     0x124244c: mov             SP, fp
    //     0x1242450: ldp             fp, lr, [SP], #0x10
    // 0x1242454: ret
    //     0x1242454: ret             
    // 0x1242458: ldr             x4, [fp, #0x10]
    // 0x124245c: ldur            x3, [fp, #-8]
    // 0x1242460: r0 = LoadClassIdInstr(r4)
    //     0x1242460: ldur            x0, [x4, #-1]
    //     0x1242464: ubfx            x0, x0, #0xc, #0x14
    // 0x1242468: mov             x1, x4
    // 0x124246c: r2 = Instance_WidgetState
    //     0x124246c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0x1242470: ldr             x2, [x2, #0xa50]
    // 0x1242474: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1242474: mov             x17, #0x2929
    //     0x1242478: movk            x17, #1, lsl #16
    //     0x124247c: add             lr, x0, x17
    //     0x1242480: ldr             lr, [x21, lr, lsl #3]
    //     0x1242484: blr             lr
    // 0x1242488: tbnz            w0, #4, #0x12424f8
    // 0x124248c: ldur            x3, [fp, #-8]
    // 0x1242490: LoadField: r1 = r3->field_f
    //     0x1242490: ldur            w1, [x3, #0xf]
    // 0x1242494: DecompressPointer r1
    //     0x1242494: add             x1, x1, HEAP, lsl #32
    // 0x1242498: LoadField: r0 = r1->field_6f
    //     0x1242498: ldur            w0, [x1, #0x6f]
    // 0x124249c: DecompressPointer r0
    //     0x124249c: add             x0, x0, HEAP, lsl #32
    // 0x12424a0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12424a4: cmp             w0, w16
    // 0x12424a8: b.ne            #0x12424b8
    // 0x12424ac: r2 = _colors
    //     0x12424ac: add             x2, PP, #0xab, lsl #12  ; [pp+0xab418] Field <_IconButtonDefaultsM3@619331726._colors@619331726>: late final (offset: 0x70)
    //     0x12424b0: ldr             x2, [x2, #0x418]
    // 0x12424b4: r0 = InitLateFinalInstanceField()
    //     0x12424b4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12424b8: LoadField: r1 = r0->field_a3
    //     0x12424b8: ldur            w1, [x0, #0xa3]
    // 0x12424bc: DecompressPointer r1
    //     0x12424bc: add             x1, x1, HEAP, lsl #32
    // 0x12424c0: cmp             w1, NULL
    // 0x12424c4: b.ne            #0x12424d0
    // 0x12424c8: LoadField: r1 = r0->field_7f
    //     0x12424c8: ldur            w1, [x0, #0x7f]
    // 0x12424cc: DecompressPointer r1
    //     0x12424cc: add             x1, x1, HEAP, lsl #32
    // 0x12424d0: r0 = LoadClassIdInstr(r1)
    //     0x12424d0: ldur            x0, [x1, #-1]
    //     0x12424d4: ubfx            x0, x0, #0xc, #0x14
    // 0x12424d8: d0 = 0.080000
    //     0x12424d8: add             x17, PP, #0x15, lsl #12  ; [pp+0x15a58] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x12424dc: ldr             d0, [x17, #0xa58]
    // 0x12424e0: r0 = GDT[cid_x0 + -0x1000]()
    //     0x12424e0: sub             lr, x0, #1, lsl #12
    //     0x12424e4: ldr             lr, [x21, lr, lsl #3]
    //     0x12424e8: blr             lr
    // 0x12424ec: LeaveFrame
    //     0x12424ec: mov             SP, fp
    //     0x12424f0: ldp             fp, lr, [SP], #0x10
    // 0x12424f4: ret
    //     0x12424f4: ret             
    // 0x12424f8: ldr             x1, [fp, #0x10]
    // 0x12424fc: ldur            x3, [fp, #-8]
    // 0x1242500: r0 = LoadClassIdInstr(r1)
    //     0x1242500: ldur            x0, [x1, #-1]
    //     0x1242504: ubfx            x0, x0, #0xc, #0x14
    // 0x1242508: r2 = Instance_WidgetState
    //     0x1242508: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0x124250c: ldr             x2, [x2, #0xa60]
    // 0x1242510: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1242510: mov             x17, #0x2929
    //     0x1242514: movk            x17, #1, lsl #16
    //     0x1242518: add             lr, x0, x17
    //     0x124251c: ldr             lr, [x21, lr, lsl #3]
    //     0x1242520: blr             lr
    // 0x1242524: tbnz            w0, #4, #0x1242594
    // 0x1242528: ldur            x0, [fp, #-8]
    // 0x124252c: LoadField: r1 = r0->field_f
    //     0x124252c: ldur            w1, [x0, #0xf]
    // 0x1242530: DecompressPointer r1
    //     0x1242530: add             x1, x1, HEAP, lsl #32
    // 0x1242534: LoadField: r0 = r1->field_6f
    //     0x1242534: ldur            w0, [x1, #0x6f]
    // 0x1242538: DecompressPointer r0
    //     0x1242538: add             x0, x0, HEAP, lsl #32
    // 0x124253c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1242540: cmp             w0, w16
    // 0x1242544: b.ne            #0x1242554
    // 0x1242548: r2 = _colors
    //     0x1242548: add             x2, PP, #0xab, lsl #12  ; [pp+0xab418] Field <_IconButtonDefaultsM3@619331726._colors@619331726>: late final (offset: 0x70)
    //     0x124254c: ldr             x2, [x2, #0x418]
    // 0x1242550: r0 = InitLateFinalInstanceField()
    //     0x1242550: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1242554: LoadField: r1 = r0->field_a3
    //     0x1242554: ldur            w1, [x0, #0xa3]
    // 0x1242558: DecompressPointer r1
    //     0x1242558: add             x1, x1, HEAP, lsl #32
    // 0x124255c: cmp             w1, NULL
    // 0x1242560: b.ne            #0x124256c
    // 0x1242564: LoadField: r1 = r0->field_7f
    //     0x1242564: ldur            w1, [x0, #0x7f]
    // 0x1242568: DecompressPointer r1
    //     0x1242568: add             x1, x1, HEAP, lsl #32
    // 0x124256c: r0 = LoadClassIdInstr(r1)
    //     0x124256c: ldur            x0, [x1, #-1]
    //     0x1242570: ubfx            x0, x0, #0xc, #0x14
    // 0x1242574: d0 = 0.100000
    //     0x1242574: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0x1242578: ldr             d0, [x17, #0x1e0]
    // 0x124257c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x124257c: sub             lr, x0, #1, lsl #12
    //     0x1242580: ldr             lr, [x21, lr, lsl #3]
    //     0x1242584: blr             lr
    // 0x1242588: LeaveFrame
    //     0x1242588: mov             SP, fp
    //     0x124258c: ldp             fp, lr, [SP], #0x10
    // 0x1242590: ret
    //     0x1242590: ret             
    // 0x1242594: r0 = Instance_Color
    //     0x1242594: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x1242598: ldr             x0, [x0, #0x810]
    // 0x124259c: LeaveFrame
    //     0x124259c: mov             SP, fp
    //     0x12425a0: ldp             fp, lr, [SP], #0x10
    // 0x12425a4: ret
    //     0x12425a4: ret             
    // 0x12425a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12425a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12425ac: b               #0x1242204
  }
  get _ foregroundColor(/* No info */) {
    // ** addr: 0x1249728, size: 0x68
    // 0x1249728: EnterFrame
    //     0x1249728: stp             fp, lr, [SP, #-0x10]!
    //     0x124972c: mov             fp, SP
    // 0x1249730: AllocStack(0x18)
    //     0x1249730: sub             SP, SP, #0x18
    // 0x1249734: SetupParameters(_IconButtonDefaultsM3 this /* r1 => r1, fp-0x8 */)
    //     0x1249734: stur            x1, [fp, #-8]
    // 0x1249738: CheckStackOverflow
    //     0x1249738: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x124973c: cmp             SP, x16
    //     0x1249740: b.ls            #0x1249788
    // 0x1249744: r1 = 1
    //     0x1249744: mov             x1, #1
    // 0x1249748: r0 = AllocateContext()
    //     0x1249748: bl              #0x13de838  ; AllocateContextStub
    // 0x124974c: mov             x1, x0
    // 0x1249750: ldur            x0, [fp, #-8]
    // 0x1249754: StoreField: r1->field_f = r0
    //     0x1249754: stur            w0, [x1, #0xf]
    // 0x1249758: mov             x2, x1
    // 0x124975c: r1 = Function '<anonymous closure>':.
    //     0x124975c: add             x1, PP, #0xab, lsl #12  ; [pp+0xab420] AnonymousClosure: (0x1249790), in [package:flutter/src/material/icon_button.dart] _IconButtonDefaultsM3::foregroundColor (0x1249728)
    //     0x1249760: ldr             x1, [x1, #0x420]
    // 0x1249764: r0 = AllocateClosure()
    //     0x1249764: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1249768: r16 = <Color?>
    //     0x1249768: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x124976c: ldr             x16, [x16, #0xa40]
    // 0x1249770: stp             x0, x16, [SP]
    // 0x1249774: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1249774: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1249778: r0 = resolveWith()
    //     0x1249778: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x124977c: LeaveFrame
    //     0x124977c: mov             SP, fp
    //     0x1249780: ldp             fp, lr, [SP], #0x10
    // 0x1249784: ret
    //     0x1249784: ret             
    // 0x1249788: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1249788: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x124978c: b               #0x1249744
  }
  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0x1249790, size: 0x18c
    // 0x1249790: EnterFrame
    //     0x1249790: stp             fp, lr, [SP, #-0x10]!
    //     0x1249794: mov             fp, SP
    // 0x1249798: AllocStack(0x8)
    //     0x1249798: sub             SP, SP, #8
    // 0x124979c: SetupParameters([dynamic _ /* r0 */])
    //     0x124979c: ldr             x0, [fp, #0x18]
    //     0x12497a0: ldur            w3, [x0, #0x17]
    //     0x12497a4: add             x3, x3, HEAP, lsl #32
    //     0x12497a8: stur            x3, [fp, #-8]
    // 0x12497ac: CheckStackOverflow
    //     0x12497ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12497b0: cmp             SP, x16
    //     0x12497b4: b.ls            #0x1249914
    // 0x12497b8: ldr             x4, [fp, #0x10]
    // 0x12497bc: r0 = LoadClassIdInstr(r4)
    //     0x12497bc: ldur            x0, [x4, #-1]
    //     0x12497c0: ubfx            x0, x0, #0xc, #0x14
    // 0x12497c4: mov             x1, x4
    // 0x12497c8: r2 = Instance_WidgetState
    //     0x12497c8: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0x12497cc: ldr             x2, [x2, #0xa70]
    // 0x12497d0: r0 = GDT[cid_x0 + 0x12929]()
    //     0x12497d0: mov             x17, #0x2929
    //     0x12497d4: movk            x17, #1, lsl #16
    //     0x12497d8: add             lr, x0, x17
    //     0x12497dc: ldr             lr, [x21, lr, lsl #3]
    //     0x12497e0: blr             lr
    // 0x12497e4: tbnz            w0, #4, #0x1249844
    // 0x12497e8: ldur            x3, [fp, #-8]
    // 0x12497ec: LoadField: r1 = r3->field_f
    //     0x12497ec: ldur            w1, [x3, #0xf]
    // 0x12497f0: DecompressPointer r1
    //     0x12497f0: add             x1, x1, HEAP, lsl #32
    // 0x12497f4: LoadField: r0 = r1->field_6f
    //     0x12497f4: ldur            w0, [x1, #0x6f]
    // 0x12497f8: DecompressPointer r0
    //     0x12497f8: add             x0, x0, HEAP, lsl #32
    // 0x12497fc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1249800: cmp             w0, w16
    // 0x1249804: b.ne            #0x1249814
    // 0x1249808: r2 = _colors
    //     0x1249808: add             x2, PP, #0xab, lsl #12  ; [pp+0xab418] Field <_IconButtonDefaultsM3@619331726._colors@619331726>: late final (offset: 0x70)
    //     0x124980c: ldr             x2, [x2, #0x418]
    // 0x1249810: r0 = InitLateFinalInstanceField()
    //     0x1249810: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1249814: LoadField: r1 = r0->field_7f
    //     0x1249814: ldur            w1, [x0, #0x7f]
    // 0x1249818: DecompressPointer r1
    //     0x1249818: add             x1, x1, HEAP, lsl #32
    // 0x124981c: r0 = LoadClassIdInstr(r1)
    //     0x124981c: ldur            x0, [x1, #-1]
    //     0x1249820: ubfx            x0, x0, #0xc, #0x14
    // 0x1249824: d0 = 0.380000
    //     0x1249824: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0x1249828: ldr             d0, [x17, #0x1f0]
    // 0x124982c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x124982c: sub             lr, x0, #1, lsl #12
    //     0x1249830: ldr             lr, [x21, lr, lsl #3]
    //     0x1249834: blr             lr
    // 0x1249838: LeaveFrame
    //     0x1249838: mov             SP, fp
    //     0x124983c: ldp             fp, lr, [SP], #0x10
    // 0x1249840: ret
    //     0x1249840: ret             
    // 0x1249844: ldr             x1, [fp, #0x10]
    // 0x1249848: ldur            x3, [fp, #-8]
    // 0x124984c: r0 = LoadClassIdInstr(r1)
    //     0x124984c: ldur            x0, [x1, #-1]
    //     0x1249850: ubfx            x0, x0, #0xc, #0x14
    // 0x1249854: r2 = Instance_WidgetState
    //     0x1249854: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0x1249858: ldr             x2, [x2, #0x100]
    // 0x124985c: r0 = GDT[cid_x0 + 0x12929]()
    //     0x124985c: mov             x17, #0x2929
    //     0x1249860: movk            x17, #1, lsl #16
    //     0x1249864: add             lr, x0, x17
    //     0x1249868: ldr             lr, [x21, lr, lsl #3]
    //     0x124986c: blr             lr
    // 0x1249870: tbnz            w0, #4, #0x12498b8
    // 0x1249874: ldur            x0, [fp, #-8]
    // 0x1249878: LoadField: r1 = r0->field_f
    //     0x1249878: ldur            w1, [x0, #0xf]
    // 0x124987c: DecompressPointer r1
    //     0x124987c: add             x1, x1, HEAP, lsl #32
    // 0x1249880: LoadField: r0 = r1->field_6f
    //     0x1249880: ldur            w0, [x1, #0x6f]
    // 0x1249884: DecompressPointer r0
    //     0x1249884: add             x0, x0, HEAP, lsl #32
    // 0x1249888: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x124988c: cmp             w0, w16
    // 0x1249890: b.ne            #0x12498a0
    // 0x1249894: r2 = _colors
    //     0x1249894: add             x2, PP, #0xab, lsl #12  ; [pp+0xab418] Field <_IconButtonDefaultsM3@619331726._colors@619331726>: late final (offset: 0x70)
    //     0x1249898: ldr             x2, [x2, #0x418]
    // 0x124989c: r0 = InitLateFinalInstanceField()
    //     0x124989c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12498a0: LoadField: r1 = r0->field_b
    //     0x12498a0: ldur            w1, [x0, #0xb]
    // 0x12498a4: DecompressPointer r1
    //     0x12498a4: add             x1, x1, HEAP, lsl #32
    // 0x12498a8: mov             x0, x1
    // 0x12498ac: LeaveFrame
    //     0x12498ac: mov             SP, fp
    //     0x12498b0: ldp             fp, lr, [SP], #0x10
    // 0x12498b4: ret
    //     0x12498b4: ret             
    // 0x12498b8: ldur            x0, [fp, #-8]
    // 0x12498bc: LoadField: r1 = r0->field_f
    //     0x12498bc: ldur            w1, [x0, #0xf]
    // 0x12498c0: DecompressPointer r1
    //     0x12498c0: add             x1, x1, HEAP, lsl #32
    // 0x12498c4: LoadField: r0 = r1->field_6f
    //     0x12498c4: ldur            w0, [x1, #0x6f]
    // 0x12498c8: DecompressPointer r0
    //     0x12498c8: add             x0, x0, HEAP, lsl #32
    // 0x12498cc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12498d0: cmp             w0, w16
    // 0x12498d4: b.ne            #0x12498e4
    // 0x12498d8: r2 = _colors
    //     0x12498d8: add             x2, PP, #0xab, lsl #12  ; [pp+0xab418] Field <_IconButtonDefaultsM3@619331726._colors@619331726>: late final (offset: 0x70)
    //     0x12498dc: ldr             x2, [x2, #0x418]
    // 0x12498e0: r0 = InitLateFinalInstanceField()
    //     0x12498e0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12498e4: LoadField: r1 = r0->field_a3
    //     0x12498e4: ldur            w1, [x0, #0xa3]
    // 0x12498e8: DecompressPointer r1
    //     0x12498e8: add             x1, x1, HEAP, lsl #32
    // 0x12498ec: cmp             w1, NULL
    // 0x12498f0: b.ne            #0x1249904
    // 0x12498f4: LoadField: r2 = r0->field_7f
    //     0x12498f4: ldur            w2, [x0, #0x7f]
    // 0x12498f8: DecompressPointer r2
    //     0x12498f8: add             x2, x2, HEAP, lsl #32
    // 0x12498fc: mov             x0, x2
    // 0x1249900: b               #0x1249908
    // 0x1249904: mov             x0, x1
    // 0x1249908: LeaveFrame
    //     0x1249908: mov             SP, fp
    //     0x124990c: ldp             fp, lr, [SP], #0x10
    // 0x1249910: ret
    //     0x1249910: ret             
    // 0x1249914: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1249914: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1249918: b               #0x12497b8
  }
}

// class id: 5467, size: 0x18, field offset: 0x14
class _SelectableIconButtonState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0xdf6a7c, size: 0x118
    // 0xdf6a7c: EnterFrame
    //     0xdf6a7c: stp             fp, lr, [SP, #-0x10]!
    //     0xdf6a80: mov             fp, SP
    // 0xdf6a84: AllocStack(0x40)
    //     0xdf6a84: sub             SP, SP, #0x40
    // 0xdf6a88: SetupParameters(_SelectableIconButtonState this /* r1 => r0, fp-0x8 */)
    //     0xdf6a88: mov             x0, x1
    //     0xdf6a8c: stur            x1, [fp, #-8]
    // 0xdf6a90: CheckStackOverflow
    //     0xdf6a90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf6a94: cmp             SP, x16
    //     0xdf6a98: b.ls            #0xdf6b84
    // 0xdf6a9c: LoadField: r1 = r0->field_b
    //     0xdf6a9c: ldur            w1, [x0, #0xb]
    // 0xdf6aa0: DecompressPointer r1
    //     0xdf6aa0: add             x1, x1, HEAP, lsl #32
    // 0xdf6aa4: cmp             w1, NULL
    // 0xdf6aa8: b.eq            #0xdf6b8c
    // 0xdf6aac: mov             x1, x0
    // 0xdf6ab0: r0 = statesController()
    //     0xdf6ab0: bl              #0xdf6bc4  ; [package:flutter/src/material/icon_button.dart] _SelectableIconButtonState::statesController
    // 0xdf6ab4: mov             x1, x0
    // 0xdf6ab8: ldur            x0, [fp, #-8]
    // 0xdf6abc: stur            x1, [fp, #-0x28]
    // 0xdf6ac0: LoadField: r2 = r0->field_b
    //     0xdf6ac0: ldur            w2, [x0, #0xb]
    // 0xdf6ac4: DecompressPointer r2
    //     0xdf6ac4: add             x2, x2, HEAP, lsl #32
    // 0xdf6ac8: cmp             w2, NULL
    // 0xdf6acc: b.eq            #0xdf6b90
    // 0xdf6ad0: LoadField: r0 = r2->field_f
    //     0xdf6ad0: ldur            w0, [x2, #0xf]
    // 0xdf6ad4: DecompressPointer r0
    //     0xdf6ad4: add             x0, x0, HEAP, lsl #32
    // 0xdf6ad8: stur            x0, [fp, #-0x20]
    // 0xdf6adc: LoadField: r3 = r2->field_1f
    //     0xdf6adc: ldur            w3, [x2, #0x1f]
    // 0xdf6ae0: DecompressPointer r3
    //     0xdf6ae0: add             x3, x3, HEAP, lsl #32
    // 0xdf6ae4: stur            x3, [fp, #-0x18]
    // 0xdf6ae8: LoadField: r4 = r2->field_23
    //     0xdf6ae8: ldur            w4, [x2, #0x23]
    // 0xdf6aec: DecompressPointer r4
    //     0xdf6aec: add             x4, x4, HEAP, lsl #32
    // 0xdf6af0: stur            x4, [fp, #-0x10]
    // 0xdf6af4: LoadField: r5 = r2->field_27
    //     0xdf6af4: ldur            w5, [x2, #0x27]
    // 0xdf6af8: DecompressPointer r5
    //     0xdf6af8: add             x5, x5, HEAP, lsl #32
    // 0xdf6afc: stur            x5, [fp, #-8]
    // 0xdf6b00: r0 = Semantics()
    //     0xdf6b00: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xdf6b04: stur            x0, [fp, #-0x30]
    // 0xdf6b08: ldur            x16, [fp, #-8]
    // 0xdf6b0c: stp             x16, NULL, [SP]
    // 0xdf6b10: mov             x1, x0
    // 0xdf6b14: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, selected, 0x1, null]
    //     0xdf6b14: add             x4, PP, #0x96, lsl #12  ; [pp+0x96178] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "selected", 0x1, Null]
    //     0xdf6b18: ldr             x4, [x4, #0x178]
    // 0xdf6b1c: r0 = Semantics()
    //     0xdf6b1c: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xdf6b20: r0 = _IconButtonM3()
    //     0xdf6b20: bl              #0xdf6bb8  ; Allocate_IconButtonM3Stub -> _IconButtonM3 (size=0x44)
    // 0xdf6b24: r1 = Instance__IconButtonVariant
    //     0xdf6b24: add             x1, PP, #0x17, lsl #12  ; [pp+0x177a8] Obj!_IconButtonVariant@12c57a1
    //     0xdf6b28: ldr             x1, [x1, #0x7a8]
    // 0xdf6b2c: StoreField: r0->field_3b = r1
    //     0xdf6b2c: stur            w1, [x0, #0x3b]
    // 0xdf6b30: r1 = false
    //     0xdf6b30: add             x1, NULL, #0x30  ; false
    // 0xdf6b34: StoreField: r0->field_3f = r1
    //     0xdf6b34: stur            w1, [x0, #0x3f]
    // 0xdf6b38: ldur            x2, [fp, #-0x18]
    // 0xdf6b3c: StoreField: r0->field_b = r2
    //     0xdf6b3c: stur            w2, [x0, #0xb]
    // 0xdf6b40: ldur            x2, [fp, #-0x20]
    // 0xdf6b44: StoreField: r0->field_1b = r2
    //     0xdf6b44: stur            w2, [x0, #0x1b]
    // 0xdf6b48: StoreField: r0->field_27 = r1
    //     0xdf6b48: stur            w1, [x0, #0x27]
    // 0xdf6b4c: r1 = Instance_Clip
    //     0xdf6b4c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xdf6b50: ldr             x1, [x1, #0x840]
    // 0xdf6b54: StoreField: r0->field_1f = r1
    //     0xdf6b54: stur            w1, [x0, #0x1f]
    // 0xdf6b58: ldur            x1, [fp, #-0x28]
    // 0xdf6b5c: StoreField: r0->field_2b = r1
    //     0xdf6b5c: stur            w1, [x0, #0x2b]
    // 0xdf6b60: r1 = true
    //     0xdf6b60: add             x1, NULL, #0x20  ; true
    // 0xdf6b64: StoreField: r0->field_2f = r1
    //     0xdf6b64: stur            w1, [x0, #0x2f]
    // 0xdf6b68: ldur            x1, [fp, #-0x10]
    // 0xdf6b6c: StoreField: r0->field_33 = r1
    //     0xdf6b6c: stur            w1, [x0, #0x33]
    // 0xdf6b70: ldur            x1, [fp, #-0x30]
    // 0xdf6b74: StoreField: r0->field_37 = r1
    //     0xdf6b74: stur            w1, [x0, #0x37]
    // 0xdf6b78: LeaveFrame
    //     0xdf6b78: mov             SP, fp
    //     0xdf6b7c: ldp             fp, lr, [SP], #0x10
    // 0xdf6b80: ret
    //     0xdf6b80: ret             
    // 0xdf6b84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf6b84: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf6b88: b               #0xdf6a9c
    // 0xdf6b8c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf6b8c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf6b90: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf6b90: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ statesController(/* No info */) {
    // ** addr: 0xdf6bc4, size: 0x3c
    // 0xdf6bc4: EnterFrame
    //     0xdf6bc4: stp             fp, lr, [SP, #-0x10]!
    //     0xdf6bc8: mov             fp, SP
    // 0xdf6bcc: LoadField: r2 = r1->field_b
    //     0xdf6bcc: ldur            w2, [x1, #0xb]
    // 0xdf6bd0: DecompressPointer r2
    //     0xdf6bd0: add             x2, x2, HEAP, lsl #32
    // 0xdf6bd4: cmp             w2, NULL
    // 0xdf6bd8: b.eq            #0xdf6bf8
    // 0xdf6bdc: LoadField: r0 = r1->field_13
    //     0xdf6bdc: ldur            w0, [x1, #0x13]
    // 0xdf6be0: DecompressPointer r0
    //     0xdf6be0: add             x0, x0, HEAP, lsl #32
    // 0xdf6be4: cmp             w0, NULL
    // 0xdf6be8: b.eq            #0xdf6bfc
    // 0xdf6bec: LeaveFrame
    //     0xdf6bec: mov             SP, fp
    //     0xdf6bf0: ldp             fp, lr, [SP], #0x10
    // 0xdf6bf4: ret
    //     0xdf6bf4: ret             
    // 0xdf6bf8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf6bf8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf6bfc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf6bfc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf6dae8, size: 0xbc
    // 0xf6dae8: EnterFrame
    //     0xf6dae8: stp             fp, lr, [SP, #-0x10]!
    //     0xf6daec: mov             fp, SP
    // 0xf6daf0: AllocStack(0x10)
    //     0xf6daf0: sub             SP, SP, #0x10
    // 0xf6daf4: SetupParameters(_SelectableIconButtonState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xf6daf4: mov             x0, x2
    //     0xf6daf8: mov             x4, x1
    //     0xf6dafc: mov             x3, x2
    //     0xf6db00: stur            x1, [fp, #-8]
    //     0xf6db04: stur            x2, [fp, #-0x10]
    // 0xf6db08: r2 = Null
    //     0xf6db08: mov             x2, NULL
    // 0xf6db0c: r1 = Null
    //     0xf6db0c: mov             x1, NULL
    // 0xf6db10: r4 = 60
    //     0xf6db10: mov             x4, #0x3c
    // 0xf6db14: branchIfSmi(r0, 0xf6db20)
    //     0xf6db14: tbz             w0, #0, #0xf6db20
    // 0xf6db18: r4 = LoadClassIdInstr(r0)
    //     0xf6db18: ldur            x4, [x0, #-1]
    //     0xf6db1c: ubfx            x4, x4, #0xc, #0x14
    // 0xf6db20: r17 = 6475
    //     0xf6db20: mov             x17, #0x194b
    // 0xf6db24: cmp             x4, x17
    // 0xf6db28: b.eq            #0xf6db40
    // 0xf6db2c: r8 = _SelectableIconButton
    //     0xf6db2c: add             x8, PP, #0x96, lsl #12  ; [pp+0x96180] Type: _SelectableIconButton
    //     0xf6db30: ldr             x8, [x8, #0x180]
    // 0xf6db34: r3 = Null
    //     0xf6db34: add             x3, PP, #0x96, lsl #12  ; [pp+0x96188] Null
    //     0xf6db38: ldr             x3, [x3, #0x188]
    // 0xf6db3c: r0 = _SelectableIconButton()
    //     0xf6db3c: bl              #0xdf6b94  ; IsType__SelectableIconButton_Stub
    // 0xf6db40: ldur            x3, [fp, #-8]
    // 0xf6db44: LoadField: r2 = r3->field_7
    //     0xf6db44: ldur            w2, [x3, #7]
    // 0xf6db48: DecompressPointer r2
    //     0xf6db48: add             x2, x2, HEAP, lsl #32
    // 0xf6db4c: ldur            x0, [fp, #-0x10]
    // 0xf6db50: r1 = Null
    //     0xf6db50: mov             x1, NULL
    // 0xf6db54: cmp             w2, NULL
    // 0xf6db58: b.eq            #0xf6db7c
    // 0xf6db5c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf6db5c: ldur            w4, [x2, #0x17]
    // 0xf6db60: DecompressPointer r4
    //     0xf6db60: add             x4, x4, HEAP, lsl #32
    // 0xf6db64: r8 = X0 bound StatefulWidget
    //     0xf6db64: add             x8, PP, #0x12, lsl #12  ; [pp+0x12498] TypeParameter: X0 bound StatefulWidget
    //     0xf6db68: ldr             x8, [x8, #0x498]
    // 0xf6db6c: LoadField: r9 = r4->field_7
    //     0xf6db6c: ldur            x9, [x4, #7]
    // 0xf6db70: r3 = Null
    //     0xf6db70: add             x3, PP, #0x96, lsl #12  ; [pp+0x96198] Null
    //     0xf6db74: ldr             x3, [x3, #0x198]
    // 0xf6db78: blr             x9
    // 0xf6db7c: ldur            x1, [fp, #-8]
    // 0xf6db80: LoadField: r2 = r1->field_b
    //     0xf6db80: ldur            w2, [x1, #0xb]
    // 0xf6db84: DecompressPointer r2
    //     0xf6db84: add             x2, x2, HEAP, lsl #32
    // 0xf6db88: cmp             w2, NULL
    // 0xf6db8c: b.eq            #0xf6dba0
    // 0xf6db90: r0 = Null
    //     0xf6db90: mov             x0, NULL
    // 0xf6db94: LeaveFrame
    //     0xf6db94: mov             SP, fp
    //     0xf6db98: ldp             fp, lr, [SP], #0x10
    // 0xf6db9c: ret
    //     0xf6db9c: ret             
    // 0xf6dba0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6dba0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0xf90e54, size: 0xb0
    // 0xf90e54: EnterFrame
    //     0xf90e54: stp             fp, lr, [SP, #-0x10]!
    //     0xf90e58: mov             fp, SP
    // 0xf90e5c: AllocStack(0x10)
    //     0xf90e5c: sub             SP, SP, #0x10
    // 0xf90e60: SetupParameters(_SelectableIconButtonState this /* r1 => r0, fp-0x8 */)
    //     0xf90e60: mov             x0, x1
    //     0xf90e64: stur            x1, [fp, #-8]
    // 0xf90e68: CheckStackOverflow
    //     0xf90e68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf90e6c: cmp             SP, x16
    //     0xf90e70: b.ls            #0xf90ef4
    // 0xf90e74: LoadField: r1 = r0->field_b
    //     0xf90e74: ldur            w1, [x0, #0xb]
    // 0xf90e78: DecompressPointer r1
    //     0xf90e78: add             x1, x1, HEAP, lsl #32
    // 0xf90e7c: cmp             w1, NULL
    // 0xf90e80: b.eq            #0xf90efc
    // 0xf90e84: r1 = <Set<WidgetState>>
    //     0xf90e84: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f978] TypeArguments: <Set<WidgetState>>
    //     0xf90e88: ldr             x1, [x1, #0x978]
    // 0xf90e8c: r0 = WidgetStatesController()
    //     0xf90e8c: bl              #0xf379b8  ; AllocateWidgetStatesControllerStub -> WidgetStatesController (size=0x2c)
    // 0xf90e90: mov             x1, x0
    // 0xf90e94: stur            x0, [fp, #-0x10]
    // 0xf90e98: r0 = WidgetStatesController()
    //     0xf90e98: bl              #0xf378e8  ; [package:flutter/src/widgets/widget_state.dart] WidgetStatesController::WidgetStatesController
    // 0xf90e9c: ldur            x0, [fp, #-0x10]
    // 0xf90ea0: ldur            x1, [fp, #-8]
    // 0xf90ea4: StoreField: r1->field_13 = r0
    //     0xf90ea4: stur            w0, [x1, #0x13]
    //     0xf90ea8: ldurb           w16, [x1, #-1]
    //     0xf90eac: ldurb           w17, [x0, #-1]
    //     0xf90eb0: and             x16, x17, x16, lsr #2
    //     0xf90eb4: tst             x16, HEAP, lsr #32
    //     0xf90eb8: b.eq            #0xf90ec0
    //     0xf90ebc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf90ec0: LoadField: r0 = r1->field_b
    //     0xf90ec0: ldur            w0, [x1, #0xb]
    // 0xf90ec4: DecompressPointer r0
    //     0xf90ec4: add             x0, x0, HEAP, lsl #32
    // 0xf90ec8: cmp             w0, NULL
    // 0xf90ecc: b.eq            #0xf90f00
    // 0xf90ed0: ldur            x1, [fp, #-0x10]
    // 0xf90ed4: r2 = Instance_WidgetState
    //     0xf90ed4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xf90ed8: ldr             x2, [x2, #0x100]
    // 0xf90edc: r3 = false
    //     0xf90edc: add             x3, NULL, #0x30  ; false
    // 0xf90ee0: r0 = update()
    //     0xf90ee0: bl              #0xd223e0  ; [package:flutter/src/widgets/widget_state.dart] WidgetStatesController::update
    // 0xf90ee4: r0 = Null
    //     0xf90ee4: mov             x0, NULL
    // 0xf90ee8: LeaveFrame
    //     0xf90ee8: mov             SP, fp
    //     0xf90eec: ldp             fp, lr, [SP], #0x10
    // 0xf90ef0: ret
    //     0xf90ef0: ret             
    // 0xf90ef4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf90ef4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf90ef8: b               #0xf90e74
    // 0xf90efc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf90efc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf90f00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf90f00: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10e5c90, size: 0x44
    // 0x10e5c90: EnterFrame
    //     0x10e5c90: stp             fp, lr, [SP, #-0x10]!
    //     0x10e5c94: mov             fp, SP
    // 0x10e5c98: CheckStackOverflow
    //     0x10e5c98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e5c9c: cmp             SP, x16
    //     0x10e5ca0: b.ls            #0x10e5ccc
    // 0x10e5ca4: LoadField: r0 = r1->field_13
    //     0x10e5ca4: ldur            w0, [x1, #0x13]
    // 0x10e5ca8: DecompressPointer r0
    //     0x10e5ca8: add             x0, x0, HEAP, lsl #32
    // 0x10e5cac: cmp             w0, NULL
    // 0x10e5cb0: b.eq            #0x10e5cbc
    // 0x10e5cb4: mov             x1, x0
    // 0x10e5cb8: r0 = dispose()
    //     0x10e5cb8: bl              #0x10ef878  ; [dart:mixin_deduplication] _MixinApplication276&Object&ChangeNotifier::dispose
    // 0x10e5cbc: r0 = Null
    //     0x10e5cbc: mov             x0, NULL
    // 0x10e5cc0: LeaveFrame
    //     0x10e5cc0: mov             SP, fp
    //     0x10e5cc4: ldp             fp, lr, [SP], #0x10
    // 0x10e5cc8: ret
    //     0x10e5cc8: ret             
    // 0x10e5ccc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e5ccc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e5cd0: b               #0x10e5ca4
  }
}

// class id: 6193, size: 0x74, field offset: 0xc
//   const constructor, 
class IconButton extends StatelessWidget {

  static _ styleFrom(/* No info */) {
    // ** addr: 0xdea068, size: 0x6f8
    // 0xdea068: EnterFrame
    //     0xdea068: stp             fp, lr, [SP, #-0x10]!
    //     0xdea06c: mov             fp, SP
    // 0xdea070: AllocStack(0x70)
    //     0xdea070: sub             SP, SP, #0x70
    // 0xdea074: SetupParameters({dynamic backgroundColor = Null /* r3, fp-0x58 */, dynamic focusColor = Null /* r5, fp-0x50 */, dynamic foregroundColor = Null /* r6, fp-0x48 */, dynamic hoverColor = Null /* r7, fp-0x40 */, dynamic iconSize = Null /* r8, fp-0x38 */, dynamic maximumSize = Null /* r9, fp-0x30 */, dynamic minimumSize = Null /* r10, fp-0x28 */, dynamic padding = Null /* r11, fp-0x20 */, dynamic side = Null /* r12, fp-0x18 */, dynamic tapTargetSize = Null /* r13, fp-0x10 */, dynamic visualDensity = Null /* r0, fp-0x8 */})
    //     0xdea074: ldur            w0, [x4, #0x13]
    //     0xdea078: ldur            w1, [x4, #0x1f]
    //     0xdea07c: add             x1, x1, HEAP, lsl #32
    //     0xdea080: add             x16, PP, #0x12, lsl #12  ; [pp+0x12958] "backgroundColor"
    //     0xdea084: ldr             x16, [x16, #0x958]
    //     0xdea088: cmp             w1, w16
    //     0xdea08c: b.ne            #0xdea0b0
    //     0xdea090: ldur            w1, [x4, #0x23]
    //     0xdea094: add             x1, x1, HEAP, lsl #32
    //     0xdea098: sub             w2, w0, w1
    //     0xdea09c: add             x1, fp, w2, sxtw #2
    //     0xdea0a0: ldr             x1, [x1, #8]
    //     0xdea0a4: mov             x3, x1
    //     0xdea0a8: mov             x1, #1
    //     0xdea0ac: b               #0xdea0b8
    //     0xdea0b0: mov             x3, NULL
    //     0xdea0b4: mov             x1, #0
    //     0xdea0b8: stur            x3, [fp, #-0x58]
    //     0xdea0bc: lsl             x2, x1, #1
    //     0xdea0c0: lsl             w5, w2, #1
    //     0xdea0c4: add             w6, w5, #8
    //     0xdea0c8: add             x16, x4, w6, sxtw #1
    //     0xdea0cc: ldur            w7, [x16, #0xf]
    //     0xdea0d0: add             x7, x7, HEAP, lsl #32
    //     0xdea0d4: add             x16, PP, #0x12, lsl #12  ; [pp+0x12a78] "focusColor"
    //     0xdea0d8: ldr             x16, [x16, #0xa78]
    //     0xdea0dc: cmp             w7, w16
    //     0xdea0e0: b.ne            #0xdea110
    //     0xdea0e4: add             w1, w5, #0xa
    //     0xdea0e8: add             x16, x4, w1, sxtw #1
    //     0xdea0ec: ldur            w5, [x16, #0xf]
    //     0xdea0f0: add             x5, x5, HEAP, lsl #32
    //     0xdea0f4: sub             w1, w0, w5
    //     0xdea0f8: add             x5, fp, w1, sxtw #2
    //     0xdea0fc: ldr             x5, [x5, #8]
    //     0xdea100: add             w1, w2, #2
    //     0xdea104: sbfx            x2, x1, #1, #0x1f
    //     0xdea108: mov             x1, x2
    //     0xdea10c: b               #0xdea114
    //     0xdea110: mov             x5, NULL
    //     0xdea114: stur            x5, [fp, #-0x50]
    //     0xdea118: lsl             x2, x1, #1
    //     0xdea11c: lsl             w6, w2, #1
    //     0xdea120: add             w7, w6, #8
    //     0xdea124: add             x16, x4, w7, sxtw #1
    //     0xdea128: ldur            w8, [x16, #0xf]
    //     0xdea12c: add             x8, x8, HEAP, lsl #32
    //     0xdea130: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a10] "foregroundColor"
    //     0xdea134: ldr             x16, [x16, #0xa10]
    //     0xdea138: cmp             w8, w16
    //     0xdea13c: b.ne            #0xdea16c
    //     0xdea140: add             w1, w6, #0xa
    //     0xdea144: add             x16, x4, w1, sxtw #1
    //     0xdea148: ldur            w6, [x16, #0xf]
    //     0xdea14c: add             x6, x6, HEAP, lsl #32
    //     0xdea150: sub             w1, w0, w6
    //     0xdea154: add             x6, fp, w1, sxtw #2
    //     0xdea158: ldr             x6, [x6, #8]
    //     0xdea15c: add             w1, w2, #2
    //     0xdea160: sbfx            x2, x1, #1, #0x1f
    //     0xdea164: mov             x1, x2
    //     0xdea168: b               #0xdea170
    //     0xdea16c: mov             x6, NULL
    //     0xdea170: stur            x6, [fp, #-0x48]
    //     0xdea174: lsl             x2, x1, #1
    //     0xdea178: lsl             w7, w2, #1
    //     0xdea17c: add             w8, w7, #8
    //     0xdea180: add             x16, x4, w8, sxtw #1
    //     0xdea184: ldur            w9, [x16, #0xf]
    //     0xdea188: add             x9, x9, HEAP, lsl #32
    //     0xdea18c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12a88] "hoverColor"
    //     0xdea190: ldr             x16, [x16, #0xa88]
    //     0xdea194: cmp             w9, w16
    //     0xdea198: b.ne            #0xdea1c8
    //     0xdea19c: add             w1, w7, #0xa
    //     0xdea1a0: add             x16, x4, w1, sxtw #1
    //     0xdea1a4: ldur            w7, [x16, #0xf]
    //     0xdea1a8: add             x7, x7, HEAP, lsl #32
    //     0xdea1ac: sub             w1, w0, w7
    //     0xdea1b0: add             x7, fp, w1, sxtw #2
    //     0xdea1b4: ldr             x7, [x7, #8]
    //     0xdea1b8: add             w1, w2, #2
    //     0xdea1bc: sbfx            x2, x1, #1, #0x1f
    //     0xdea1c0: mov             x1, x2
    //     0xdea1c4: b               #0xdea1cc
    //     0xdea1c8: mov             x7, NULL
    //     0xdea1cc: stur            x7, [fp, #-0x40]
    //     0xdea1d0: lsl             x2, x1, #1
    //     0xdea1d4: lsl             w8, w2, #1
    //     0xdea1d8: add             w9, w8, #8
    //     0xdea1dc: add             x16, x4, w9, sxtw #1
    //     0xdea1e0: ldur            w10, [x16, #0xf]
    //     0xdea1e4: add             x10, x10, HEAP, lsl #32
    //     0xdea1e8: add             x16, PP, #0x80, lsl #12  ; [pp+0x80c70] "iconSize"
    //     0xdea1ec: ldr             x16, [x16, #0xc70]
    //     0xdea1f0: cmp             w10, w16
    //     0xdea1f4: b.ne            #0xdea224
    //     0xdea1f8: add             w1, w8, #0xa
    //     0xdea1fc: add             x16, x4, w1, sxtw #1
    //     0xdea200: ldur            w8, [x16, #0xf]
    //     0xdea204: add             x8, x8, HEAP, lsl #32
    //     0xdea208: sub             w1, w0, w8
    //     0xdea20c: add             x8, fp, w1, sxtw #2
    //     0xdea210: ldr             x8, [x8, #8]
    //     0xdea214: add             w1, w2, #2
    //     0xdea218: sbfx            x2, x1, #1, #0x1f
    //     0xdea21c: mov             x1, x2
    //     0xdea220: b               #0xdea228
    //     0xdea224: mov             x8, NULL
    //     0xdea228: stur            x8, [fp, #-0x38]
    //     0xdea22c: lsl             x2, x1, #1
    //     0xdea230: lsl             w9, w2, #1
    //     0xdea234: add             w10, w9, #8
    //     0xdea238: add             x16, x4, w10, sxtw #1
    //     0xdea23c: ldur            w11, [x16, #0xf]
    //     0xdea240: add             x11, x11, HEAP, lsl #32
    //     0xdea244: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a18] "maximumSize"
    //     0xdea248: ldr             x16, [x16, #0xa18]
    //     0xdea24c: cmp             w11, w16
    //     0xdea250: b.ne            #0xdea280
    //     0xdea254: add             w1, w9, #0xa
    //     0xdea258: add             x16, x4, w1, sxtw #1
    //     0xdea25c: ldur            w9, [x16, #0xf]
    //     0xdea260: add             x9, x9, HEAP, lsl #32
    //     0xdea264: sub             w1, w0, w9
    //     0xdea268: add             x9, fp, w1, sxtw #2
    //     0xdea26c: ldr             x9, [x9, #8]
    //     0xdea270: add             w1, w2, #2
    //     0xdea274: sbfx            x2, x1, #1, #0x1f
    //     0xdea278: mov             x1, x2
    //     0xdea27c: b               #0xdea284
    //     0xdea280: mov             x9, NULL
    //     0xdea284: stur            x9, [fp, #-0x30]
    //     0xdea288: lsl             x2, x1, #1
    //     0xdea28c: lsl             w10, w2, #1
    //     0xdea290: add             w11, w10, #8
    //     0xdea294: add             x16, x4, w11, sxtw #1
    //     0xdea298: ldur            w12, [x16, #0xf]
    //     0xdea29c: add             x12, x12, HEAP, lsl #32
    //     0xdea2a0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a20] "minimumSize"
    //     0xdea2a4: ldr             x16, [x16, #0xa20]
    //     0xdea2a8: cmp             w12, w16
    //     0xdea2ac: b.ne            #0xdea2dc
    //     0xdea2b0: add             w1, w10, #0xa
    //     0xdea2b4: add             x16, x4, w1, sxtw #1
    //     0xdea2b8: ldur            w10, [x16, #0xf]
    //     0xdea2bc: add             x10, x10, HEAP, lsl #32
    //     0xdea2c0: sub             w1, w0, w10
    //     0xdea2c4: add             x10, fp, w1, sxtw #2
    //     0xdea2c8: ldr             x10, [x10, #8]
    //     0xdea2cc: add             w1, w2, #2
    //     0xdea2d0: sbfx            x2, x1, #1, #0x1f
    //     0xdea2d4: mov             x1, x2
    //     0xdea2d8: b               #0xdea2e0
    //     0xdea2dc: mov             x10, NULL
    //     0xdea2e0: stur            x10, [fp, #-0x28]
    //     0xdea2e4: lsl             x2, x1, #1
    //     0xdea2e8: lsl             w11, w2, #1
    //     0xdea2ec: add             w12, w11, #8
    //     0xdea2f0: add             x16, x4, w12, sxtw #1
    //     0xdea2f4: ldur            w13, [x16, #0xf]
    //     0xdea2f8: add             x13, x13, HEAP, lsl #32
    //     0xdea2fc: add             x16, PP, #0x12, lsl #12  ; [pp+0x12838] "padding"
    //     0xdea300: ldr             x16, [x16, #0x838]
    //     0xdea304: cmp             w13, w16
    //     0xdea308: b.ne            #0xdea338
    //     0xdea30c: add             w1, w11, #0xa
    //     0xdea310: add             x16, x4, w1, sxtw #1
    //     0xdea314: ldur            w11, [x16, #0xf]
    //     0xdea318: add             x11, x11, HEAP, lsl #32
    //     0xdea31c: sub             w1, w0, w11
    //     0xdea320: add             x11, fp, w1, sxtw #2
    //     0xdea324: ldr             x11, [x11, #8]
    //     0xdea328: add             w1, w2, #2
    //     0xdea32c: sbfx            x2, x1, #1, #0x1f
    //     0xdea330: mov             x1, x2
    //     0xdea334: b               #0xdea33c
    //     0xdea338: mov             x11, NULL
    //     0xdea33c: stur            x11, [fp, #-0x20]
    //     0xdea340: lsl             x2, x1, #1
    //     0xdea344: lsl             w12, w2, #1
    //     0xdea348: add             w13, w12, #8
    //     0xdea34c: add             x16, x4, w13, sxtw #1
    //     0xdea350: ldur            w14, [x16, #0xf]
    //     0xdea354: add             x14, x14, HEAP, lsl #32
    //     0xdea358: add             x16, PP, #0x80, lsl #12  ; [pp+0x80c88] "side"
    //     0xdea35c: ldr             x16, [x16, #0xc88]
    //     0xdea360: cmp             w14, w16
    //     0xdea364: b.ne            #0xdea394
    //     0xdea368: add             w1, w12, #0xa
    //     0xdea36c: add             x16, x4, w1, sxtw #1
    //     0xdea370: ldur            w12, [x16, #0xf]
    //     0xdea374: add             x12, x12, HEAP, lsl #32
    //     0xdea378: sub             w1, w0, w12
    //     0xdea37c: add             x12, fp, w1, sxtw #2
    //     0xdea380: ldr             x12, [x12, #8]
    //     0xdea384: add             w1, w2, #2
    //     0xdea388: sbfx            x2, x1, #1, #0x1f
    //     0xdea38c: mov             x1, x2
    //     0xdea390: b               #0xdea398
    //     0xdea394: mov             x12, NULL
    //     0xdea398: stur            x12, [fp, #-0x18]
    //     0xdea39c: lsl             x2, x1, #1
    //     0xdea3a0: lsl             w13, w2, #1
    //     0xdea3a4: add             w14, w13, #8
    //     0xdea3a8: add             x16, x4, w14, sxtw #1
    //     0xdea3ac: ldur            w19, [x16, #0xf]
    //     0xdea3b0: add             x19, x19, HEAP, lsl #32
    //     0xdea3b4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a30] "tapTargetSize"
    //     0xdea3b8: ldr             x16, [x16, #0xa30]
    //     0xdea3bc: cmp             w19, w16
    //     0xdea3c0: b.ne            #0xdea3f0
    //     0xdea3c4: add             w1, w13, #0xa
    //     0xdea3c8: add             x16, x4, w1, sxtw #1
    //     0xdea3cc: ldur            w13, [x16, #0xf]
    //     0xdea3d0: add             x13, x13, HEAP, lsl #32
    //     0xdea3d4: sub             w1, w0, w13
    //     0xdea3d8: add             x13, fp, w1, sxtw #2
    //     0xdea3dc: ldr             x13, [x13, #8]
    //     0xdea3e0: add             w1, w2, #2
    //     0xdea3e4: sbfx            x2, x1, #1, #0x1f
    //     0xdea3e8: mov             x1, x2
    //     0xdea3ec: b               #0xdea3f4
    //     0xdea3f0: mov             x13, NULL
    //     0xdea3f4: stur            x13, [fp, #-0x10]
    //     0xdea3f8: lsl             x2, x1, #1
    //     0xdea3fc: lsl             w1, w2, #1
    //     0xdea400: add             w2, w1, #8
    //     0xdea404: add             x16, x4, w2, sxtw #1
    //     0xdea408: ldur            w14, [x16, #0xf]
    //     0xdea40c: add             x14, x14, HEAP, lsl #32
    //     0xdea410: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a38] "visualDensity"
    //     0xdea414: ldr             x16, [x16, #0xa38]
    //     0xdea418: cmp             w14, w16
    //     0xdea41c: b.ne            #0xdea440
    //     0xdea420: add             w2, w1, #0xa
    //     0xdea424: add             x16, x4, w2, sxtw #1
    //     0xdea428: ldur            w1, [x16, #0xf]
    //     0xdea42c: add             x1, x1, HEAP, lsl #32
    //     0xdea430: sub             w2, w0, w1
    //     0xdea434: add             x0, fp, w2, sxtw #2
    //     0xdea438: ldr             x0, [x0, #8]
    //     0xdea43c: b               #0xdea444
    //     0xdea440: mov             x0, NULL
    //     0xdea444: stur            x0, [fp, #-8]
    // 0xdea448: CheckStackOverflow
    //     0xdea448: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdea44c: cmp             SP, x16
    //     0xdea450: b.ls            #0xdea758
    // 0xdea454: cmp             w7, NULL
    // 0xdea458: b.ne            #0xdea464
    // 0xdea45c: mov             x1, x5
    // 0xdea460: b               #0xdea468
    // 0xdea464: mov             x1, x7
    // 0xdea468: cmp             w1, NULL
    // 0xdea46c: b.ne            #0xdea474
    // 0xdea470: r1 = Null
    //     0xdea470: mov             x1, NULL
    // 0xdea474: cmp             w1, NULL
    // 0xdea478: b.ne            #0xdea494
    // 0xdea47c: cmp             w6, NULL
    // 0xdea480: b.ne            #0xdea494
    // 0xdea484: mov             x3, x0
    // 0xdea488: mov             x0, x13
    // 0xdea48c: r4 = Null
    //     0xdea48c: mov             x4, NULL
    // 0xdea490: b               #0xdea64c
    // 0xdea494: r1 = Null
    //     0xdea494: mov             x1, NULL
    // 0xdea498: r2 = 12
    //     0xdea498: mov             x2, #0xc
    // 0xdea49c: r0 = AllocateArray()
    //     0xdea49c: bl              #0x13df928  ; AllocateArrayStub
    // 0xdea4a0: mov             x2, x0
    // 0xdea4a4: stur            x2, [fp, #-0x60]
    // 0xdea4a8: r16 = Instance_WidgetState
    //     0xdea4a8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0xdea4ac: ldr             x16, [x16, #0xa48]
    // 0xdea4b0: StoreField: r2->field_f = r16
    //     0xdea4b0: stur            w16, [x2, #0xf]
    // 0xdea4b4: ldur            x3, [fp, #-0x48]
    // 0xdea4b8: cmp             w3, NULL
    // 0xdea4bc: b.ne            #0xdea4c8
    // 0xdea4c0: r0 = Null
    //     0xdea4c0: mov             x0, NULL
    // 0xdea4c4: b               #0xdea4ec
    // 0xdea4c8: r0 = LoadClassIdInstr(r3)
    //     0xdea4c8: ldur            x0, [x3, #-1]
    //     0xdea4cc: ubfx            x0, x0, #0xc, #0x14
    // 0xdea4d0: mov             x1, x3
    // 0xdea4d4: d0 = 0.100000
    //     0xdea4d4: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0xdea4d8: ldr             d0, [x17, #0x1e0]
    // 0xdea4dc: r0 = GDT[cid_x0 + -0x1000]()
    //     0xdea4dc: sub             lr, x0, #1, lsl #12
    //     0xdea4e0: ldr             lr, [x21, lr, lsl #3]
    //     0xdea4e4: blr             lr
    // 0xdea4e8: ldur            x2, [fp, #-0x60]
    // 0xdea4ec: ldur            x3, [fp, #-0x40]
    // 0xdea4f0: mov             x1, x2
    // 0xdea4f4: ArrayStore: r1[1] = r0  ; List_4
    //     0xdea4f4: add             x25, x1, #0x13
    //     0xdea4f8: str             w0, [x25]
    //     0xdea4fc: tbz             w0, #0, #0xdea518
    //     0xdea500: ldurb           w16, [x1, #-1]
    //     0xdea504: ldurb           w17, [x0, #-1]
    //     0xdea508: and             x16, x17, x16, lsr #2
    //     0xdea50c: tst             x16, HEAP, lsr #32
    //     0xdea510: b.eq            #0xdea518
    //     0xdea514: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdea518: r16 = Instance_WidgetState
    //     0xdea518: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xdea51c: ldr             x16, [x16, #0xa50]
    // 0xdea520: ArrayStore: r2[0] = r16  ; List_4
    //     0xdea520: stur            w16, [x2, #0x17]
    // 0xdea524: cmp             w3, NULL
    // 0xdea528: b.ne            #0xdea564
    // 0xdea52c: ldur            x3, [fp, #-0x48]
    // 0xdea530: cmp             w3, NULL
    // 0xdea534: b.ne            #0xdea540
    // 0xdea538: r0 = Null
    //     0xdea538: mov             x0, NULL
    // 0xdea53c: b               #0xdea568
    // 0xdea540: r0 = LoadClassIdInstr(r3)
    //     0xdea540: ldur            x0, [x3, #-1]
    //     0xdea544: ubfx            x0, x0, #0xc, #0x14
    // 0xdea548: mov             x1, x3
    // 0xdea54c: d0 = 0.080000
    //     0xdea54c: add             x17, PP, #0x15, lsl #12  ; [pp+0x15a58] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0xdea550: ldr             d0, [x17, #0xa58]
    // 0xdea554: r0 = GDT[cid_x0 + -0x1000]()
    //     0xdea554: sub             lr, x0, #1, lsl #12
    //     0xdea558: ldr             lr, [x21, lr, lsl #3]
    //     0xdea55c: blr             lr
    // 0xdea560: b               #0xdea568
    // 0xdea564: mov             x0, x3
    // 0xdea568: ldur            x3, [fp, #-0x50]
    // 0xdea56c: ldur            x2, [fp, #-0x60]
    // 0xdea570: mov             x1, x2
    // 0xdea574: ArrayStore: r1[3] = r0  ; List_4
    //     0xdea574: add             x25, x1, #0x1b
    //     0xdea578: str             w0, [x25]
    //     0xdea57c: tbz             w0, #0, #0xdea598
    //     0xdea580: ldurb           w16, [x1, #-1]
    //     0xdea584: ldurb           w17, [x0, #-1]
    //     0xdea588: and             x16, x17, x16, lsr #2
    //     0xdea58c: tst             x16, HEAP, lsr #32
    //     0xdea590: b.eq            #0xdea598
    //     0xdea594: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdea598: r16 = Instance_WidgetState
    //     0xdea598: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xdea59c: ldr             x16, [x16, #0xa60]
    // 0xdea5a0: StoreField: r2->field_1f = r16
    //     0xdea5a0: stur            w16, [x2, #0x1f]
    // 0xdea5a4: cmp             w3, NULL
    // 0xdea5a8: b.ne            #0xdea5e4
    // 0xdea5ac: ldur            x3, [fp, #-0x48]
    // 0xdea5b0: cmp             w3, NULL
    // 0xdea5b4: b.ne            #0xdea5c0
    // 0xdea5b8: r0 = Null
    //     0xdea5b8: mov             x0, NULL
    // 0xdea5bc: b               #0xdea5e8
    // 0xdea5c0: r0 = LoadClassIdInstr(r3)
    //     0xdea5c0: ldur            x0, [x3, #-1]
    //     0xdea5c4: ubfx            x0, x0, #0xc, #0x14
    // 0xdea5c8: mov             x1, x3
    // 0xdea5cc: d0 = 0.100000
    //     0xdea5cc: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0xdea5d0: ldr             d0, [x17, #0x1e0]
    // 0xdea5d4: r0 = GDT[cid_x0 + -0x1000]()
    //     0xdea5d4: sub             lr, x0, #1, lsl #12
    //     0xdea5d8: ldr             lr, [x21, lr, lsl #3]
    //     0xdea5dc: blr             lr
    // 0xdea5e0: b               #0xdea5e8
    // 0xdea5e4: mov             x0, x3
    // 0xdea5e8: ldur            x1, [fp, #-0x60]
    // 0xdea5ec: ArrayStore: r1[5] = r0  ; List_4
    //     0xdea5ec: add             x25, x1, #0x23
    //     0xdea5f0: str             w0, [x25]
    //     0xdea5f4: tbz             w0, #0, #0xdea610
    //     0xdea5f8: ldurb           w16, [x1, #-1]
    //     0xdea5fc: ldurb           w17, [x0, #-1]
    //     0xdea600: and             x16, x17, x16, lsr #2
    //     0xdea604: tst             x16, HEAP, lsr #32
    //     0xdea608: b.eq            #0xdea610
    //     0xdea60c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xdea610: r16 = <WidgetState, Color?>
    //     0xdea610: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a68] TypeArguments: <WidgetState, Color?>
    //     0xdea614: ldr             x16, [x16, #0xa68]
    // 0xdea618: ldur            lr, [fp, #-0x60]
    // 0xdea61c: stp             lr, x16, [SP]
    // 0xdea620: r0 = Map._fromLiteral()
    //     0xdea620: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xdea624: r1 = <Color?>
    //     0xdea624: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xdea628: ldr             x1, [x1, #0xa40]
    // 0xdea62c: stur            x0, [fp, #-0x40]
    // 0xdea630: r0 = WidgetStateMapper()
    //     0xdea630: bl              #0xd171e0  ; AllocateWidgetStateMapperStub -> WidgetStateMapper<X0> (size=0x10)
    // 0xdea634: mov             x1, x0
    // 0xdea638: ldur            x0, [fp, #-0x40]
    // 0xdea63c: StoreField: r1->field_b = r0
    //     0xdea63c: stur            w0, [x1, #0xb]
    // 0xdea640: mov             x4, x1
    // 0xdea644: ldur            x0, [fp, #-0x10]
    // 0xdea648: ldur            x3, [fp, #-8]
    // 0xdea64c: ldur            x1, [fp, #-0x58]
    // 0xdea650: stur            x4, [fp, #-0x40]
    // 0xdea654: r2 = Null
    //     0xdea654: mov             x2, NULL
    // 0xdea658: r0 = defaultColor()
    //     0xdea658: bl              #0xd171ec  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::defaultColor
    // 0xdea65c: ldur            x1, [fp, #-0x48]
    // 0xdea660: r2 = Null
    //     0xdea660: mov             x2, NULL
    // 0xdea664: stur            x0, [fp, #-0x48]
    // 0xdea668: r0 = defaultColor()
    //     0xdea668: bl              #0xd171ec  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::defaultColor
    // 0xdea66c: stur            x0, [fp, #-0x50]
    // 0xdea670: r16 = <EdgeInsetsGeometry>
    //     0xdea670: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a98] TypeArguments: <EdgeInsetsGeometry>
    //     0xdea674: ldr             x16, [x16, #0xa98]
    // 0xdea678: ldur            lr, [fp, #-0x20]
    // 0xdea67c: stp             lr, x16, [SP]
    // 0xdea680: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdea680: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdea684: r0 = allOrNull()
    //     0xdea684: bl              #0xd17190  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0xdea688: stur            x0, [fp, #-0x20]
    // 0xdea68c: r16 = <Size>
    //     0xdea68c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15aa0] TypeArguments: <Size>
    //     0xdea690: ldr             x16, [x16, #0xaa0]
    // 0xdea694: ldur            lr, [fp, #-0x28]
    // 0xdea698: stp             lr, x16, [SP]
    // 0xdea69c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdea69c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdea6a0: r0 = allOrNull()
    //     0xdea6a0: bl              #0xd17190  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0xdea6a4: stur            x0, [fp, #-0x28]
    // 0xdea6a8: r16 = <Size>
    //     0xdea6a8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15aa0] TypeArguments: <Size>
    //     0xdea6ac: ldr             x16, [x16, #0xaa0]
    // 0xdea6b0: ldur            lr, [fp, #-0x30]
    // 0xdea6b4: stp             lr, x16, [SP]
    // 0xdea6b8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdea6b8: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdea6bc: r0 = allOrNull()
    //     0xdea6bc: bl              #0xd17190  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0xdea6c0: stur            x0, [fp, #-0x30]
    // 0xdea6c4: r16 = <double>
    //     0xdea6c4: ldr             x16, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xdea6c8: ldur            lr, [fp, #-0x38]
    // 0xdea6cc: stp             lr, x16, [SP]
    // 0xdea6d0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdea6d0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdea6d4: r0 = allOrNull()
    //     0xdea6d4: bl              #0xd17190  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0xdea6d8: stur            x0, [fp, #-0x38]
    // 0xdea6dc: r16 = <BorderSide>
    //     0xdea6dc: add             x16, PP, #0x80, lsl #12  ; [pp+0x80c98] TypeArguments: <BorderSide>
    //     0xdea6e0: ldr             x16, [x16, #0xc98]
    // 0xdea6e4: ldur            lr, [fp, #-0x18]
    // 0xdea6e8: stp             lr, x16, [SP]
    // 0xdea6ec: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdea6ec: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdea6f0: r0 = allOrNull()
    //     0xdea6f0: bl              #0xd17190  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0xdea6f4: stur            x0, [fp, #-0x18]
    // 0xdea6f8: r0 = ButtonStyle()
    //     0xdea6f8: bl              #0xd17184  ; AllocateButtonStyleStub -> ButtonStyle (size=0x6c)
    // 0xdea6fc: ldur            x1, [fp, #-0x48]
    // 0xdea700: StoreField: r0->field_b = r1
    //     0xdea700: stur            w1, [x0, #0xb]
    // 0xdea704: ldur            x1, [fp, #-0x50]
    // 0xdea708: StoreField: r0->field_f = r1
    //     0xdea708: stur            w1, [x0, #0xf]
    // 0xdea70c: ldur            x1, [fp, #-0x40]
    // 0xdea710: StoreField: r0->field_13 = r1
    //     0xdea710: stur            w1, [x0, #0x13]
    // 0xdea714: ldur            x1, [fp, #-0x20]
    // 0xdea718: StoreField: r0->field_23 = r1
    //     0xdea718: stur            w1, [x0, #0x23]
    // 0xdea71c: ldur            x1, [fp, #-0x28]
    // 0xdea720: StoreField: r0->field_27 = r1
    //     0xdea720: stur            w1, [x0, #0x27]
    // 0xdea724: ldur            x1, [fp, #-0x30]
    // 0xdea728: StoreField: r0->field_2f = r1
    //     0xdea728: stur            w1, [x0, #0x2f]
    // 0xdea72c: ldur            x1, [fp, #-0x38]
    // 0xdea730: StoreField: r0->field_37 = r1
    //     0xdea730: stur            w1, [x0, #0x37]
    // 0xdea734: ldur            x1, [fp, #-0x18]
    // 0xdea738: StoreField: r0->field_3f = r1
    //     0xdea738: stur            w1, [x0, #0x3f]
    // 0xdea73c: ldur            x1, [fp, #-8]
    // 0xdea740: StoreField: r0->field_4b = r1
    //     0xdea740: stur            w1, [x0, #0x4b]
    // 0xdea744: ldur            x1, [fp, #-0x10]
    // 0xdea748: StoreField: r0->field_4f = r1
    //     0xdea748: stur            w1, [x0, #0x4f]
    // 0xdea74c: LeaveFrame
    //     0xdea74c: mov             SP, fp
    //     0xdea750: ldp             fp, lr, [SP], #0x10
    // 0xdea754: ret
    //     0xdea754: ret             
    // 0xdea758: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdea758: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdea75c: b               #0xdea454
  }
  _ build(/* No info */) {
    // ** addr: 0xfae240, size: 0x688
    // 0xfae240: EnterFrame
    //     0xfae240: stp             fp, lr, [SP, #-0x10]!
    //     0xfae244: mov             fp, SP
    // 0xfae248: AllocStack(0xa8)
    //     0xfae248: sub             SP, SP, #0xa8
    // 0xfae24c: SetupParameters(IconButton this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xfae24c: mov             x0, x2
    //     0xfae250: stur            x2, [fp, #-0x10]
    //     0xfae254: mov             x2, x1
    //     0xfae258: stur            x1, [fp, #-8]
    // 0xfae25c: CheckStackOverflow
    //     0xfae25c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfae260: cmp             SP, x16
    //     0xfae264: b.ls            #0xfae878
    // 0xfae268: mov             x1, x0
    // 0xfae26c: r0 = of()
    //     0xfae26c: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfae270: stur            x0, [fp, #-0x38]
    // 0xfae274: LoadField: r1 = r0->field_2f
    //     0xfae274: ldur            w1, [x0, #0x2f]
    // 0xfae278: DecompressPointer r1
    //     0xfae278: add             x1, x1, HEAP, lsl #32
    // 0xfae27c: tbnz            w1, #4, #0xfae434
    // 0xfae280: ldur            x0, [fp, #-8]
    // 0xfae284: LoadField: r1 = r0->field_5b
    //     0xfae284: ldur            w1, [x0, #0x5b]
    // 0xfae288: DecompressPointer r1
    //     0xfae288: add             x1, x1, HEAP, lsl #32
    // 0xfae28c: stur            x1, [fp, #-0x18]
    // 0xfae290: cmp             w1, NULL
    // 0xfae294: b.ne            #0xfae2a4
    // 0xfae298: mov             x0, x1
    // 0xfae29c: r1 = Null
    //     0xfae29c: mov             x1, NULL
    // 0xfae2a0: b               #0xfae2d0
    // 0xfae2a4: LoadField: d0 = r1->field_7
    //     0xfae2a4: ldur            d0, [x1, #7]
    // 0xfae2a8: stur            d0, [fp, #-0x68]
    // 0xfae2ac: ArrayLoad: d1 = r1[0]  ; List_8
    //     0xfae2ac: ldur            d1, [x1, #0x17]
    // 0xfae2b0: stur            d1, [fp, #-0x60]
    // 0xfae2b4: r0 = Size()
    //     0xfae2b4: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xfae2b8: ldur            d0, [fp, #-0x68]
    // 0xfae2bc: StoreField: r0->field_7 = d0
    //     0xfae2bc: stur            d0, [x0, #7]
    // 0xfae2c0: ldur            d0, [fp, #-0x60]
    // 0xfae2c4: StoreField: r0->field_f = d0
    //     0xfae2c4: stur            d0, [x0, #0xf]
    // 0xfae2c8: mov             x1, x0
    // 0xfae2cc: ldur            x0, [fp, #-0x18]
    // 0xfae2d0: stur            x1, [fp, #-0x20]
    // 0xfae2d4: cmp             w0, NULL
    // 0xfae2d8: b.ne            #0xfae2e4
    // 0xfae2dc: r1 = Null
    //     0xfae2dc: mov             x1, NULL
    // 0xfae2e0: b               #0xfae30c
    // 0xfae2e4: LoadField: d0 = r0->field_f
    //     0xfae2e4: ldur            d0, [x0, #0xf]
    // 0xfae2e8: stur            d0, [fp, #-0x68]
    // 0xfae2ec: LoadField: d1 = r0->field_1f
    //     0xfae2ec: ldur            d1, [x0, #0x1f]
    // 0xfae2f0: stur            d1, [fp, #-0x60]
    // 0xfae2f4: r0 = Size()
    //     0xfae2f4: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xfae2f8: ldur            d0, [fp, #-0x68]
    // 0xfae2fc: StoreField: r0->field_7 = d0
    //     0xfae2fc: stur            d0, [x0, #7]
    // 0xfae300: ldur            d0, [fp, #-0x60]
    // 0xfae304: StoreField: r0->field_f = d0
    //     0xfae304: stur            d0, [x0, #0xf]
    // 0xfae308: mov             x1, x0
    // 0xfae30c: ldur            x0, [fp, #-8]
    // 0xfae310: LoadField: r2 = r0->field_f
    //     0xfae310: ldur            w2, [x0, #0xf]
    // 0xfae314: DecompressPointer r2
    //     0xfae314: add             x2, x2, HEAP, lsl #32
    // 0xfae318: LoadField: r3 = r0->field_2b
    //     0xfae318: ldur            w3, [x0, #0x2b]
    // 0xfae31c: DecompressPointer r3
    //     0xfae31c: add             x3, x3, HEAP, lsl #32
    // 0xfae320: LoadField: r4 = r0->field_23
    //     0xfae320: ldur            w4, [x0, #0x23]
    // 0xfae324: DecompressPointer r4
    //     0xfae324: add             x4, x4, HEAP, lsl #32
    // 0xfae328: LoadField: r5 = r0->field_27
    //     0xfae328: ldur            w5, [x0, #0x27]
    // 0xfae32c: DecompressPointer r5
    //     0xfae32c: add             x5, x5, HEAP, lsl #32
    // 0xfae330: LoadField: r6 = r0->field_13
    //     0xfae330: ldur            w6, [x0, #0x13]
    // 0xfae334: DecompressPointer r6
    //     0xfae334: add             x6, x6, HEAP, lsl #32
    // 0xfae338: LoadField: r7 = r0->field_b
    //     0xfae338: ldur            w7, [x0, #0xb]
    // 0xfae33c: DecompressPointer r7
    //     0xfae33c: add             x7, x7, HEAP, lsl #32
    // 0xfae340: stp             x3, x2, [SP, #0x30]
    // 0xfae344: stp             x5, x4, [SP, #0x20]
    // 0xfae348: ldur            x16, [fp, #-0x20]
    // 0xfae34c: stp             x16, x6, [SP, #0x10]
    // 0xfae350: stp             x7, x1, [SP]
    // 0xfae354: r4 = const [0, 0x8, 0x8, 0, focusColor, 0x2, foregroundColor, 0x1, hoverColor, 0x3, iconSize, 0x7, maximumSize, 0x6, minimumSize, 0x5, padding, 0x4, visualDensity, 0, null]
    //     0xfae354: add             x4, PP, #0x80, lsl #12  ; [pp+0x80c00] List(21) [0, 0x8, 0x8, 0, "focusColor", 0x2, "foregroundColor", 0x1, "hoverColor", 0x3, "iconSize", 0x7, "maximumSize", 0x6, "minimumSize", 0x5, "padding", 0x4, "visualDensity", 0, Null]
    //     0xfae358: ldr             x4, [x4, #0xc00]
    // 0xfae35c: r0 = styleFrom()
    //     0xfae35c: bl              #0xdea068  ; [package:flutter/src/material/icon_button.dart] IconButton::styleFrom
    // 0xfae360: mov             x1, x0
    // 0xfae364: ldur            x0, [fp, #-8]
    // 0xfae368: LoadField: r2 = r0->field_5f
    //     0xfae368: ldur            w2, [x0, #0x5f]
    // 0xfae36c: DecompressPointer r2
    //     0xfae36c: add             x2, x2, HEAP, lsl #32
    // 0xfae370: cmp             w2, NULL
    // 0xfae374: b.eq            #0xfae38c
    // 0xfae378: mov             x16, x1
    // 0xfae37c: mov             x1, x2
    // 0xfae380: mov             x2, x16
    // 0xfae384: r0 = merge()
    //     0xfae384: bl              #0xd29660  ; [package:flutter/src/material/button_style.dart] ButtonStyle::merge
    // 0xfae388: mov             x1, x0
    // 0xfae38c: LoadField: r0 = r1->field_33
    //     0xfae38c: ldur            w0, [x1, #0x33]
    // 0xfae390: DecompressPointer r0
    //     0xfae390: add             x0, x0, HEAP, lsl #32
    // 0xfae394: cmp             w0, NULL
    // 0xfae398: b.ne            #0xfae3b8
    // 0xfae39c: LoadField: r0 = r1->field_f
    //     0xfae39c: ldur            w0, [x1, #0xf]
    // 0xfae3a0: DecompressPointer r0
    //     0xfae3a0: add             x0, x0, HEAP, lsl #32
    // 0xfae3a4: str             x0, [SP]
    // 0xfae3a8: r4 = const [0, 0x2, 0x1, 0x1, iconColor, 0x1, null]
    //     0xfae3a8: add             x4, PP, #0x80, lsl #12  ; [pp+0x80c08] List(7) [0, 0x2, 0x1, 0x1, "iconColor", 0x1, Null]
    //     0xfae3ac: ldr             x4, [x4, #0xc08]
    // 0xfae3b0: r0 = copyWith()
    //     0xfae3b0: bl              #0xd2991c  ; [package:flutter/src/material/button_style.dart] ButtonStyle::copyWith
    // 0xfae3b4: b               #0xfae3bc
    // 0xfae3b8: mov             x0, x1
    // 0xfae3bc: ldur            x3, [fp, #-8]
    // 0xfae3c0: stur            x0, [fp, #-0x30]
    // 0xfae3c4: LoadField: r1 = r3->field_1f
    //     0xfae3c4: ldur            w1, [x3, #0x1f]
    // 0xfae3c8: DecompressPointer r1
    //     0xfae3c8: add             x1, x1, HEAP, lsl #32
    // 0xfae3cc: stur            x1, [fp, #-0x28]
    // 0xfae3d0: LoadField: r2 = r3->field_3b
    //     0xfae3d0: ldur            w2, [x3, #0x3b]
    // 0xfae3d4: DecompressPointer r2
    //     0xfae3d4: add             x2, x2, HEAP, lsl #32
    // 0xfae3d8: stur            x2, [fp, #-0x20]
    // 0xfae3dc: LoadField: r4 = r3->field_53
    //     0xfae3dc: ldur            w4, [x3, #0x53]
    // 0xfae3e0: DecompressPointer r4
    //     0xfae3e0: add             x4, x4, HEAP, lsl #32
    // 0xfae3e4: stur            x4, [fp, #-0x18]
    // 0xfae3e8: r0 = _SelectableIconButton()
    //     0xfae3e8: bl              #0xfae8c8  ; Allocate_SelectableIconButtonStub -> _SelectableIconButton (size=0x38)
    // 0xfae3ec: mov             x1, x0
    // 0xfae3f0: ldur            x0, [fp, #-0x30]
    // 0xfae3f4: StoreField: r1->field_f = r0
    //     0xfae3f4: stur            w0, [x1, #0xf]
    // 0xfae3f8: r0 = Instance__IconButtonVariant
    //     0xfae3f8: add             x0, PP, #0x17, lsl #12  ; [pp+0x177a8] Obj!_IconButtonVariant@12c57a1
    //     0xfae3fc: ldr             x0, [x0, #0x7a8]
    // 0xfae400: ArrayStore: r1[0] = r0  ; List_4
    //     0xfae400: stur            w0, [x1, #0x17]
    // 0xfae404: r4 = false
    //     0xfae404: add             x4, NULL, #0x30  ; false
    // 0xfae408: StoreField: r1->field_1b = r4
    //     0xfae408: stur            w4, [x1, #0x1b]
    // 0xfae40c: ldur            x0, [fp, #-0x20]
    // 0xfae410: StoreField: r1->field_1f = r0
    //     0xfae410: stur            w0, [x1, #0x1f]
    // 0xfae414: ldur            x0, [fp, #-0x18]
    // 0xfae418: StoreField: r1->field_23 = r0
    //     0xfae418: stur            w0, [x1, #0x23]
    // 0xfae41c: ldur            x0, [fp, #-0x28]
    // 0xfae420: StoreField: r1->field_27 = r0
    //     0xfae420: stur            w0, [x1, #0x27]
    // 0xfae424: mov             x0, x1
    // 0xfae428: LeaveFrame
    //     0xfae428: mov             SP, fp
    //     0xfae42c: ldp             fp, lr, [SP], #0x10
    // 0xfae430: ret
    //     0xfae430: ret             
    // 0xfae434: ldur            x3, [fp, #-8]
    // 0xfae438: r4 = false
    //     0xfae438: add             x4, NULL, #0x30  ; false
    // 0xfae43c: LoadField: r5 = r3->field_3b
    //     0xfae43c: ldur            w5, [x3, #0x3b]
    // 0xfae440: DecompressPointer r5
    //     0xfae440: add             x5, x5, HEAP, lsl #32
    // 0xfae444: stur            x5, [fp, #-0x20]
    // 0xfae448: cmp             w5, NULL
    // 0xfae44c: b.eq            #0xfae460
    // 0xfae450: LoadField: r1 = r3->field_2b
    //     0xfae450: ldur            w1, [x3, #0x2b]
    // 0xfae454: DecompressPointer r1
    //     0xfae454: add             x1, x1, HEAP, lsl #32
    // 0xfae458: mov             x6, x1
    // 0xfae45c: b               #0xfae46c
    // 0xfae460: LoadField: r1 = r0->field_43
    //     0xfae460: ldur            w1, [x0, #0x43]
    // 0xfae464: DecompressPointer r1
    //     0xfae464: add             x1, x1, HEAP, lsl #32
    // 0xfae468: mov             x6, x1
    // 0xfae46c: stur            x6, [fp, #-0x18]
    // 0xfae470: LoadField: r1 = r3->field_f
    //     0xfae470: ldur            w1, [x3, #0xf]
    // 0xfae474: DecompressPointer r1
    //     0xfae474: add             x1, x1, HEAP, lsl #32
    // 0xfae478: cmp             w1, NULL
    // 0xfae47c: b.ne            #0xfae488
    // 0xfae480: LoadField: r1 = r0->field_33
    //     0xfae480: ldur            w1, [x0, #0x33]
    // 0xfae484: DecompressPointer r1
    //     0xfae484: add             x1, x1, HEAP, lsl #32
    // 0xfae488: LoadField: r2 = r3->field_5b
    //     0xfae488: ldur            w2, [x3, #0x5b]
    // 0xfae48c: DecompressPointer r2
    //     0xfae48c: add             x2, x2, HEAP, lsl #32
    // 0xfae490: cmp             w2, NULL
    // 0xfae494: b.ne            #0xfae4a0
    // 0xfae498: r2 = Instance_BoxConstraints
    //     0xfae498: add             x2, PP, #0x80, lsl #12  ; [pp+0x80c10] Obj!BoxConstraints@129c231
    //     0xfae49c: ldr             x2, [x2, #0xc10]
    // 0xfae4a0: r0 = effectiveConstraints()
    //     0xfae4a0: bl              #0xd0cad0  ; [package:flutter/src/material/theme_data.dart] VisualDensity::effectiveConstraints
    // 0xfae4a4: mov             x2, x0
    // 0xfae4a8: ldur            x0, [fp, #-8]
    // 0xfae4ac: stur            x2, [fp, #-0x28]
    // 0xfae4b0: LoadField: r1 = r0->field_b
    //     0xfae4b0: ldur            w1, [x0, #0xb]
    // 0xfae4b4: DecompressPointer r1
    //     0xfae4b4: add             x1, x1, HEAP, lsl #32
    // 0xfae4b8: cmp             w1, NULL
    // 0xfae4bc: b.ne            #0xfae4d8
    // 0xfae4c0: ldur            x1, [fp, #-0x10]
    // 0xfae4c4: r0 = of()
    //     0xfae4c4: bl              #0xd0e004  ; [package:flutter/src/widgets/icon_theme.dart] IconTheme::of
    // 0xfae4c8: LoadField: r1 = r0->field_7
    //     0xfae4c8: ldur            w1, [x0, #7]
    // 0xfae4cc: DecompressPointer r1
    //     0xfae4cc: add             x1, x1, HEAP, lsl #32
    // 0xfae4d0: mov             x0, x1
    // 0xfae4d4: b               #0xfae4dc
    // 0xfae4d8: mov             x0, x1
    // 0xfae4dc: cmp             w0, NULL
    // 0xfae4e0: b.ne            #0xfae4ec
    // 0xfae4e4: d0 = 24.000000
    //     0xfae4e4: fmov            d0, #24.00000000
    // 0xfae4e8: b               #0xfae4f0
    // 0xfae4ec: LoadField: d0 = r0->field_7
    //     0xfae4ec: ldur            d0, [x0, #7]
    // 0xfae4f0: ldur            x0, [fp, #-8]
    // 0xfae4f4: stur            d0, [fp, #-0x60]
    // 0xfae4f8: LoadField: r1 = r0->field_13
    //     0xfae4f8: ldur            w1, [x0, #0x13]
    // 0xfae4fc: DecompressPointer r1
    //     0xfae4fc: add             x1, x1, HEAP, lsl #32
    // 0xfae500: cmp             w1, NULL
    // 0xfae504: b.ne            #0xfae514
    // 0xfae508: r4 = Instance_EdgeInsets
    //     0xfae508: add             x4, PP, #0x18, lsl #12  ; [pp+0x18338] Obj!EdgeInsets@129d051
    //     0xfae50c: ldr             x4, [x4, #0x338]
    // 0xfae510: b               #0xfae518
    // 0xfae514: mov             x4, x1
    // 0xfae518: ldur            x2, [fp, #-0x20]
    // 0xfae51c: ldur            x3, [fp, #-0x18]
    // 0xfae520: ldur            x1, [fp, #-0x28]
    // 0xfae524: stur            x4, [fp, #-0x30]
    // 0xfae528: r5 = inline_Allocate_Double()
    //     0xfae528: ldp             x5, x6, [THR, #0x60]  ; THR::top
    //     0xfae52c: add             x5, x5, #0x10
    //     0xfae530: cmp             x6, x5
    //     0xfae534: b.ls            #0xfae880
    //     0xfae538: str             x5, [THR, #0x60]  ; THR::top
    //     0xfae53c: sub             x5, x5, #0xf
    //     0xfae540: mov             x6, #0xe19c
    //     0xfae544: movk            x6, #3, lsl #16
    //     0xfae548: stur            x6, [x5, #-1]
    // 0xfae54c: dmb             ishst
    // 0xfae550: StoreField: r5->field_7 = d0
    //     0xfae550: stur            d0, [x5, #7]
    // 0xfae554: stur            x5, [fp, #-0x10]
    // 0xfae558: r0 = IconThemeData()
    //     0xfae558: bl              #0x8ac78c  ; AllocateIconThemeDataStub -> IconThemeData (size=0x2c)
    // 0xfae55c: mov             x1, x0
    // 0xfae560: ldur            x0, [fp, #-0x10]
    // 0xfae564: StoreField: r1->field_7 = r0
    //     0xfae564: stur            w0, [x1, #7]
    // 0xfae568: ldur            x2, [fp, #-0x18]
    // 0xfae56c: StoreField: r1->field_1b = r2
    //     0xfae56c: stur            w2, [x1, #0x1b]
    // 0xfae570: ldur            x3, [fp, #-8]
    // 0xfae574: LoadField: r2 = r3->field_1f
    //     0xfae574: ldur            w2, [x3, #0x1f]
    // 0xfae578: DecompressPointer r2
    //     0xfae578: add             x2, x2, HEAP, lsl #32
    // 0xfae57c: mov             x16, x1
    // 0xfae580: mov             x1, x2
    // 0xfae584: mov             x2, x16
    // 0xfae588: r0 = merge()
    //     0xfae588: bl              #0xd0c588  ; [package:flutter/src/widgets/icon_theme.dart] IconTheme::merge
    // 0xfae58c: stur            x0, [fp, #-0x18]
    // 0xfae590: r0 = Align()
    //     0xfae590: bl              #0xb281f8  ; AllocateAlignStub -> Align (size=0x1c)
    // 0xfae594: mov             x1, x0
    // 0xfae598: r0 = Instance_Alignment
    //     0xfae598: add             x0, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xfae59c: ldr             x0, [x0, #0xb80]
    // 0xfae5a0: stur            x1, [fp, #-0x40]
    // 0xfae5a4: StoreField: r1->field_f = r0
    //     0xfae5a4: stur            w0, [x1, #0xf]
    // 0xfae5a8: ldur            x0, [fp, #-0x18]
    // 0xfae5ac: StoreField: r1->field_b = r0
    //     0xfae5ac: stur            w0, [x1, #0xb]
    // 0xfae5b0: r0 = SizedBox()
    //     0xfae5b0: bl              #0x8a7210  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0xfae5b4: mov             x1, x0
    // 0xfae5b8: ldur            x0, [fp, #-0x10]
    // 0xfae5bc: stur            x1, [fp, #-0x18]
    // 0xfae5c0: StoreField: r1->field_f = r0
    //     0xfae5c0: stur            w0, [x1, #0xf]
    // 0xfae5c4: StoreField: r1->field_13 = r0
    //     0xfae5c4: stur            w0, [x1, #0x13]
    // 0xfae5c8: ldur            x0, [fp, #-0x40]
    // 0xfae5cc: StoreField: r1->field_b = r0
    //     0xfae5cc: stur            w0, [x1, #0xb]
    // 0xfae5d0: r0 = Padding()
    //     0xfae5d0: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xfae5d4: ldur            x1, [fp, #-0x30]
    // 0xfae5d8: stur            x0, [fp, #-0x10]
    // 0xfae5dc: StoreField: r0->field_f = r1
    //     0xfae5dc: stur            w1, [x0, #0xf]
    // 0xfae5e0: ldur            x2, [fp, #-0x18]
    // 0xfae5e4: StoreField: r0->field_b = r2
    //     0xfae5e4: stur            w2, [x0, #0xb]
    // 0xfae5e8: r0 = ConstrainedBox()
    //     0xfae5e8: bl              #0xd0a588  ; AllocateConstrainedBoxStub -> ConstrainedBox (size=0x14)
    // 0xfae5ec: mov             x2, x0
    // 0xfae5f0: ldur            x0, [fp, #-0x28]
    // 0xfae5f4: stur            x2, [fp, #-0x58]
    // 0xfae5f8: StoreField: r2->field_f = r0
    //     0xfae5f8: stur            w0, [x2, #0xf]
    // 0xfae5fc: ldur            x0, [fp, #-0x10]
    // 0xfae600: StoreField: r2->field_b = r0
    //     0xfae600: stur            w0, [x2, #0xb]
    // 0xfae604: ldur            x0, [fp, #-0x20]
    // 0xfae608: cmp             w0, NULL
    // 0xfae60c: r16 = true
    //     0xfae60c: add             x16, NULL, #0x20  ; true
    // 0xfae610: r17 = false
    //     0xfae610: add             x17, NULL, #0x30  ; false
    // 0xfae614: csel            x3, x16, x17, ne
    // 0xfae618: stur            x3, [fp, #-0x50]
    // 0xfae61c: cmp             w0, NULL
    // 0xfae620: b.eq            #0xfae630
    // 0xfae624: r5 = Instance__WidgetStateMouseCursor
    //     0xfae624: add             x5, PP, #0x80, lsl #12  ; [pp+0x80c18] Obj!_WidgetStateMouseCursor@12b3251
    //     0xfae628: ldr             x5, [x5, #0xc18]
    // 0xfae62c: b               #0xfae634
    // 0xfae630: r5 = Instance_SystemMouseCursor
    //     0xfae630: ldr             x5, [PP, #0x21b0]  ; [pp+0x21b0] Obj!SystemMouseCursor@12b3201
    // 0xfae634: ldur            x4, [fp, #-8]
    // 0xfae638: stur            x5, [fp, #-0x48]
    // 0xfae63c: LoadField: r1 = r4->field_23
    //     0xfae63c: ldur            w1, [x4, #0x23]
    // 0xfae640: DecompressPointer r1
    //     0xfae640: add             x1, x1, HEAP, lsl #32
    // 0xfae644: cmp             w1, NULL
    // 0xfae648: b.ne            #0xfae660
    // 0xfae64c: ldur            x6, [fp, #-0x38]
    // 0xfae650: LoadField: r1 = r6->field_4b
    //     0xfae650: ldur            w1, [x6, #0x4b]
    // 0xfae654: DecompressPointer r1
    //     0xfae654: add             x1, x1, HEAP, lsl #32
    // 0xfae658: mov             x7, x1
    // 0xfae65c: b               #0xfae668
    // 0xfae660: ldur            x6, [fp, #-0x38]
    // 0xfae664: mov             x7, x1
    // 0xfae668: stur            x7, [fp, #-0x40]
    // 0xfae66c: LoadField: r1 = r4->field_27
    //     0xfae66c: ldur            w1, [x4, #0x27]
    // 0xfae670: DecompressPointer r1
    //     0xfae670: add             x1, x1, HEAP, lsl #32
    // 0xfae674: cmp             w1, NULL
    // 0xfae678: b.ne            #0xfae68c
    // 0xfae67c: LoadField: r1 = r6->field_57
    //     0xfae67c: ldur            w1, [x6, #0x57]
    // 0xfae680: DecompressPointer r1
    //     0xfae680: add             x1, x1, HEAP, lsl #32
    // 0xfae684: mov             x8, x1
    // 0xfae688: b               #0xfae690
    // 0xfae68c: mov             x8, x1
    // 0xfae690: stur            x8, [fp, #-0x28]
    // 0xfae694: LoadField: r9 = r6->field_4f
    //     0xfae694: ldur            w9, [x6, #0x4f]
    // 0xfae698: DecompressPointer r9
    //     0xfae698: add             x9, x9, HEAP, lsl #32
    // 0xfae69c: stur            x9, [fp, #-0x18]
    // 0xfae6a0: LoadField: r1 = r4->field_2f
    //     0xfae6a0: ldur            w1, [x4, #0x2f]
    // 0xfae6a4: DecompressPointer r1
    //     0xfae6a4: add             x1, x1, HEAP, lsl #32
    // 0xfae6a8: cmp             w1, NULL
    // 0xfae6ac: b.ne            #0xfae6c0
    // 0xfae6b0: LoadField: r1 = r6->field_73
    //     0xfae6b0: ldur            w1, [x6, #0x73]
    // 0xfae6b4: DecompressPointer r1
    //     0xfae6b4: add             x1, x1, HEAP, lsl #32
    // 0xfae6b8: mov             x6, x1
    // 0xfae6bc: b               #0xfae6c4
    // 0xfae6c0: mov             x6, x1
    // 0xfae6c4: stur            x6, [fp, #-0x10]
    // 0xfae6c8: LoadField: r1 = r4->field_1b
    //     0xfae6c8: ldur            w1, [x4, #0x1b]
    // 0xfae6cc: DecompressPointer r1
    //     0xfae6cc: add             x1, x1, HEAP, lsl #32
    // 0xfae6d0: cmp             w1, NULL
    // 0xfae6d4: b.ne            #0xfae724
    // 0xfae6d8: ldur            d0, [fp, #-0x60]
    // 0xfae6dc: ldur            x1, [fp, #-0x30]
    // 0xfae6e0: r0 = horizontal()
    //     0xfae6e0: bl              #0xb17264  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::horizontal
    // 0xfae6e4: ldur            x1, [fp, #-0x30]
    // 0xfae6e8: stur            d0, [fp, #-0x68]
    // 0xfae6ec: r0 = vertical()
    //     0xfae6ec: bl              #0xb1730c  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::vertical
    // 0xfae6f0: mov             v1.16b, v0.16b
    // 0xfae6f4: ldur            d0, [fp, #-0x68]
    // 0xfae6f8: fmin            v2.2d, v0.2d, v1.2d
    // 0xfae6fc: ldur            d0, [fp, #-0x60]
    // 0xfae700: fadd            d1, d0, d2
    // 0xfae704: d0 = 0.700000
    //     0xfae704: add             x17, PP, #0x80, lsl #12  ; [pp+0x80c20] IMM: double(0.7) from 0x3fe6666666666666
    //     0xfae708: ldr             d0, [x17, #0xc20]
    // 0xfae70c: fmul            d2, d1, d0
    // 0xfae710: d0 = 35.000000
    //     0xfae710: add             x17, PP, #0x80, lsl #12  ; [pp+0x80c28] IMM: double(35) from 0x4041800000000000
    //     0xfae714: ldr             d0, [x17, #0xc28]
    // 0xfae718: fmax            v1.2d, v0.2d, v2.2d
    // 0xfae71c: mov             v0.16b, v1.16b
    // 0xfae720: b               #0xfae728
    // 0xfae724: LoadField: d0 = r1->field_7
    //     0xfae724: ldur            d0, [x1, #7]
    // 0xfae728: ldur            x3, [fp, #-8]
    // 0xfae72c: ldur            x1, [fp, #-0x20]
    // 0xfae730: ldur            x0, [fp, #-0x58]
    // 0xfae734: ldur            x2, [fp, #-0x50]
    // 0xfae738: ldur            x4, [fp, #-0x48]
    // 0xfae73c: ldur            x5, [fp, #-0x40]
    // 0xfae740: ldur            x6, [fp, #-0x28]
    // 0xfae744: ldur            x7, [fp, #-0x18]
    // 0xfae748: ldur            x8, [fp, #-0x10]
    // 0xfae74c: stur            d0, [fp, #-0x60]
    // 0xfae750: r0 = InkResponse()
    //     0xfae750: bl              #0xdf1b70  ; AllocateInkResponseStub -> InkResponse (size=0x94)
    // 0xfae754: mov             x1, x0
    // 0xfae758: ldur            x0, [fp, #-0x58]
    // 0xfae75c: stur            x1, [fp, #-0x30]
    // 0xfae760: StoreField: r1->field_b = r0
    //     0xfae760: stur            w0, [x1, #0xb]
    // 0xfae764: ldur            x0, [fp, #-0x20]
    // 0xfae768: StoreField: r1->field_f = r0
    //     0xfae768: stur            w0, [x1, #0xf]
    // 0xfae76c: ldur            x0, [fp, #-0x48]
    // 0xfae770: StoreField: r1->field_43 = r0
    //     0xfae770: stur            w0, [x1, #0x43]
    // 0xfae774: r0 = false
    //     0xfae774: add             x0, NULL, #0x30  ; false
    // 0xfae778: StoreField: r1->field_47 = r0
    //     0xfae778: stur            w0, [x1, #0x47]
    // 0xfae77c: r2 = Instance_BoxShape
    //     0xfae77c: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1abf0] Obj!BoxShape@12c4941
    //     0xfae780: ldr             x2, [x2, #0xbf0]
    // 0xfae784: StoreField: r1->field_4b = r2
    //     0xfae784: stur            w2, [x1, #0x4b]
    // 0xfae788: ldur            d0, [fp, #-0x60]
    // 0xfae78c: r2 = inline_Allocate_Double()
    //     0xfae78c: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xfae790: add             x2, x2, #0x10
    //     0xfae794: cmp             x3, x2
    //     0xfae798: b.ls            #0xfae8ac
    //     0xfae79c: str             x2, [THR, #0x60]  ; THR::top
    //     0xfae7a0: sub             x2, x2, #0xf
    //     0xfae7a4: mov             x3, #0xe19c
    //     0xfae7a8: movk            x3, #3, lsl #16
    //     0xfae7ac: stur            x3, [x2, #-1]
    // 0xfae7b0: dmb             ishst
    // 0xfae7b4: StoreField: r2->field_7 = d0
    //     0xfae7b4: stur            d0, [x2, #7]
    // 0xfae7b8: StoreField: r1->field_4f = r2
    //     0xfae7b8: stur            w2, [x1, #0x4f]
    // 0xfae7bc: ldur            x2, [fp, #-0x40]
    // 0xfae7c0: StoreField: r1->field_5b = r2
    //     0xfae7c0: stur            w2, [x1, #0x5b]
    // 0xfae7c4: ldur            x2, [fp, #-0x28]
    // 0xfae7c8: StoreField: r1->field_5f = r2
    //     0xfae7c8: stur            w2, [x1, #0x5f]
    // 0xfae7cc: ldur            x2, [fp, #-0x18]
    // 0xfae7d0: StoreField: r1->field_63 = r2
    //     0xfae7d0: stur            w2, [x1, #0x63]
    // 0xfae7d4: ldur            x2, [fp, #-0x10]
    // 0xfae7d8: StoreField: r1->field_6b = r2
    //     0xfae7d8: stur            w2, [x1, #0x6b]
    // 0xfae7dc: r2 = true
    //     0xfae7dc: add             x2, NULL, #0x20  ; true
    // 0xfae7e0: StoreField: r1->field_73 = r2
    //     0xfae7e0: stur            w2, [x1, #0x73]
    // 0xfae7e4: StoreField: r1->field_77 = r0
    //     0xfae7e4: stur            w0, [x1, #0x77]
    // 0xfae7e8: ldur            x3, [fp, #-0x50]
    // 0xfae7ec: StoreField: r1->field_87 = r3
    //     0xfae7ec: stur            w3, [x1, #0x87]
    // 0xfae7f0: StoreField: r1->field_7f = r0
    //     0xfae7f0: stur            w0, [x1, #0x7f]
    // 0xfae7f4: ldur            x0, [fp, #-8]
    // 0xfae7f8: LoadField: r4 = r0->field_53
    //     0xfae7f8: ldur            w4, [x0, #0x53]
    // 0xfae7fc: DecompressPointer r4
    //     0xfae7fc: add             x4, x4, HEAP, lsl #32
    // 0xfae800: stur            x4, [fp, #-0x10]
    // 0xfae804: cmp             w4, NULL
    // 0xfae808: b.eq            #0xfae834
    // 0xfae80c: r0 = Tooltip()
    //     0xfae80c: bl              #0xd0deac  ; AllocateTooltipStub -> Tooltip (size=0x68)
    // 0xfae810: mov             x1, x0
    // 0xfae814: ldur            x0, [fp, #-0x10]
    // 0xfae818: StoreField: r1->field_b = r0
    //     0xfae818: stur            w0, [x1, #0xb]
    // 0xfae81c: r0 = true
    //     0xfae81c: add             x0, NULL, #0x20  ; true
    // 0xfae820: StoreField: r1->field_4b = r0
    //     0xfae820: stur            w0, [x1, #0x4b]
    // 0xfae824: ldur            x0, [fp, #-0x30]
    // 0xfae828: StoreField: r1->field_2f = r0
    //     0xfae828: stur            w0, [x1, #0x2f]
    // 0xfae82c: mov             x0, x1
    // 0xfae830: b               #0xfae838
    // 0xfae834: mov             x0, x1
    // 0xfae838: stur            x0, [fp, #-8]
    // 0xfae83c: r0 = Semantics()
    //     0xfae83c: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xfae840: stur            x0, [fp, #-0x10]
    // 0xfae844: r16 = true
    //     0xfae844: add             x16, NULL, #0x20  ; true
    // 0xfae848: ldur            lr, [fp, #-0x50]
    // 0xfae84c: stp             lr, x16, [SP, #8]
    // 0xfae850: ldur            x16, [fp, #-8]
    // 0xfae854: str             x16, [SP]
    // 0xfae858: mov             x1, x0
    // 0xfae85c: r4 = const [0, 0x4, 0x3, 0x1, button, 0x1, child, 0x3, enabled, 0x2, null]
    //     0xfae85c: add             x4, PP, #0x80, lsl #12  ; [pp+0x80c30] List(11) [0, 0x4, 0x3, 0x1, "button", 0x1, "child", 0x3, "enabled", 0x2, Null]
    //     0xfae860: ldr             x4, [x4, #0xc30]
    // 0xfae864: r0 = Semantics()
    //     0xfae864: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xfae868: ldur            x0, [fp, #-0x10]
    // 0xfae86c: LeaveFrame
    //     0xfae86c: mov             SP, fp
    //     0xfae870: ldp             fp, lr, [SP], #0x10
    // 0xfae874: ret
    //     0xfae874: ret             
    // 0xfae878: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfae878: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfae87c: b               #0xfae268
    // 0xfae880: SaveReg d0
    //     0xfae880: str             q0, [SP, #-0x10]!
    // 0xfae884: stp             x3, x4, [SP, #-0x10]!
    // 0xfae888: stp             x1, x2, [SP, #-0x10]!
    // 0xfae88c: SaveReg r0
    //     0xfae88c: str             x0, [SP, #-8]!
    // 0xfae890: r0 = AllocateDouble()
    //     0xfae890: bl              #0x13df878  ; AllocateDoubleStub
    // 0xfae894: mov             x5, x0
    // 0xfae898: RestoreReg r0
    //     0xfae898: ldr             x0, [SP], #8
    // 0xfae89c: ldp             x1, x2, [SP], #0x10
    // 0xfae8a0: ldp             x3, x4, [SP], #0x10
    // 0xfae8a4: RestoreReg d0
    //     0xfae8a4: ldr             q0, [SP], #0x10
    // 0xfae8a8: b               #0xfae550
    // 0xfae8ac: SaveReg d0
    //     0xfae8ac: str             q0, [SP, #-0x10]!
    // 0xfae8b0: stp             x0, x1, [SP, #-0x10]!
    // 0xfae8b4: r0 = AllocateDouble()
    //     0xfae8b4: bl              #0x13df878  ; AllocateDoubleStub
    // 0xfae8b8: mov             x2, x0
    // 0xfae8bc: ldp             x0, x1, [SP], #0x10
    // 0xfae8c0: RestoreReg d0
    //     0xfae8c0: ldr             q0, [SP], #0x10
    // 0xfae8c4: b               #0xfae7b4
  }
}

// class id: 6475, size: 0x38, field offset: 0xc
//   const constructor, 
class _SelectableIconButton extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa19d4, size: 0x24
    // 0xfa19d4: EnterFrame
    //     0xfa19d4: stp             fp, lr, [SP, #-0x10]!
    //     0xfa19d8: mov             fp, SP
    // 0xfa19dc: mov             x0, x1
    // 0xfa19e0: r1 = <_SelectableIconButton>
    //     0xfa19e0: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8ce48] TypeArguments: <_SelectableIconButton>
    //     0xfa19e4: ldr             x1, [x1, #0xe48]
    // 0xfa19e8: r0 = _SelectableIconButtonState()
    //     0xfa19e8: bl              #0xfa19f8  ; Allocate_SelectableIconButtonStateStub -> _SelectableIconButtonState (size=0x18)
    // 0xfa19ec: LeaveFrame
    //     0xfa19ec: mov             SP, fp
    //     0xfa19f0: ldp             fp, lr, [SP], #0x10
    // 0xfa19f4: ret
    //     0xfa19f4: ret             
  }
}

// class id: 6497, size: 0x44, field offset: 0x3c
//   const constructor, 
class _IconButtonM3 extends ButtonStyleButton {

  _ defaultStyleOf(/* No info */) {
    // ** addr: 0x122a138, size: 0x184
    // 0x122a138: EnterFrame
    //     0x122a138: stp             fp, lr, [SP, #-0x10]!
    //     0x122a13c: mov             fp, SP
    // 0x122a140: AllocStack(0x8)
    //     0x122a140: sub             SP, SP, #8
    // 0x122a144: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x122a144: stur            x2, [fp, #-8]
    // 0x122a148: LoadField: r0 = r1->field_3b
    //     0x122a148: ldur            w0, [x1, #0x3b]
    // 0x122a14c: DecompressPointer r0
    //     0x122a14c: add             x0, x0, HEAP, lsl #32
    // 0x122a150: LoadField: r1 = r0->field_7
    //     0x122a150: ldur            x1, [x0, #7]
    // 0x122a154: cmp             x1, #1
    // 0x122a158: b.gt            #0x122a204
    // 0x122a15c: cmp             x1, #0
    // 0x122a160: b.gt            #0x122a1a4
    // 0x122a164: r0 = _IconButtonDefaultsM3()
    //     0x122a164: bl              #0x122a2e0  ; Allocate_IconButtonDefaultsM3Stub -> _IconButtonDefaultsM3 (size=0x74)
    // 0x122a168: mov             x1, x0
    // 0x122a16c: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x122a170: StoreField: r1->field_6f = r0
    //     0x122a170: stur            w0, [x1, #0x6f]
    // 0x122a174: ldur            x2, [fp, #-8]
    // 0x122a178: StoreField: r1->field_6b = r2
    //     0x122a178: stur            w2, [x1, #0x6b]
    // 0x122a17c: r3 = Instance_Duration
    //     0x122a17c: add             x3, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0x122a180: ldr             x3, [x3, #0x318]
    // 0x122a184: StoreField: r1->field_53 = r3
    //     0x122a184: stur            w3, [x1, #0x53]
    // 0x122a188: r4 = true
    //     0x122a188: add             x4, NULL, #0x20  ; true
    // 0x122a18c: StoreField: r1->field_57 = r4
    //     0x122a18c: stur            w4, [x1, #0x57]
    // 0x122a190: r5 = Instance_Alignment
    //     0x122a190: add             x5, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0x122a194: ldr             x5, [x5, #0xb80]
    // 0x122a198: StoreField: r1->field_5b = r5
    //     0x122a198: stur            w5, [x1, #0x5b]
    // 0x122a19c: mov             x0, x1
    // 0x122a1a0: b               #0x122a2b0
    // 0x122a1a4: r4 = true
    //     0x122a1a4: add             x4, NULL, #0x20  ; true
    // 0x122a1a8: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x122a1ac: r3 = Instance_Duration
    //     0x122a1ac: add             x3, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0x122a1b0: ldr             x3, [x3, #0x318]
    // 0x122a1b4: r5 = Instance_Alignment
    //     0x122a1b4: add             x5, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0x122a1b8: ldr             x5, [x5, #0xb80]
    // 0x122a1bc: r0 = _FilledIconButtonDefaultsM3()
    //     0x122a1bc: bl              #0x122a2d4  ; Allocate_FilledIconButtonDefaultsM3Stub -> _FilledIconButtonDefaultsM3 (size=0x78)
    // 0x122a1c0: mov             x1, x0
    // 0x122a1c4: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x122a1c8: StoreField: r1->field_73 = r0
    //     0x122a1c8: stur            w0, [x1, #0x73]
    // 0x122a1cc: ldur            x2, [fp, #-8]
    // 0x122a1d0: StoreField: r1->field_6b = r2
    //     0x122a1d0: stur            w2, [x1, #0x6b]
    // 0x122a1d4: r3 = false
    //     0x122a1d4: add             x3, NULL, #0x30  ; false
    // 0x122a1d8: StoreField: r1->field_6f = r3
    //     0x122a1d8: stur            w3, [x1, #0x6f]
    // 0x122a1dc: r4 = Instance_Duration
    //     0x122a1dc: add             x4, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0x122a1e0: ldr             x4, [x4, #0x318]
    // 0x122a1e4: StoreField: r1->field_53 = r4
    //     0x122a1e4: stur            w4, [x1, #0x53]
    // 0x122a1e8: r5 = true
    //     0x122a1e8: add             x5, NULL, #0x20  ; true
    // 0x122a1ec: StoreField: r1->field_57 = r5
    //     0x122a1ec: stur            w5, [x1, #0x57]
    // 0x122a1f0: r6 = Instance_Alignment
    //     0x122a1f0: add             x6, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0x122a1f4: ldr             x6, [x6, #0xb80]
    // 0x122a1f8: StoreField: r1->field_5b = r6
    //     0x122a1f8: stur            w6, [x1, #0x5b]
    // 0x122a1fc: mov             x0, x1
    // 0x122a200: b               #0x122a2b0
    // 0x122a204: r5 = true
    //     0x122a204: add             x5, NULL, #0x20  ; true
    // 0x122a208: r3 = false
    //     0x122a208: add             x3, NULL, #0x30  ; false
    // 0x122a20c: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x122a210: r4 = Instance_Duration
    //     0x122a210: add             x4, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0x122a214: ldr             x4, [x4, #0x318]
    // 0x122a218: r6 = Instance_Alignment
    //     0x122a218: add             x6, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0x122a21c: ldr             x6, [x6, #0xb80]
    // 0x122a220: cmp             x1, #2
    // 0x122a224: b.gt            #0x122a270
    // 0x122a228: r0 = _FilledTonalIconButtonDefaultsM3()
    //     0x122a228: bl              #0x122a2c8  ; Allocate_FilledTonalIconButtonDefaultsM3Stub -> _FilledTonalIconButtonDefaultsM3 (size=0x78)
    // 0x122a22c: mov             x1, x0
    // 0x122a230: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x122a234: StoreField: r1->field_73 = r0
    //     0x122a234: stur            w0, [x1, #0x73]
    // 0x122a238: ldur            x2, [fp, #-8]
    // 0x122a23c: StoreField: r1->field_6b = r2
    //     0x122a23c: stur            w2, [x1, #0x6b]
    // 0x122a240: r0 = false
    //     0x122a240: add             x0, NULL, #0x30  ; false
    // 0x122a244: StoreField: r1->field_6f = r0
    //     0x122a244: stur            w0, [x1, #0x6f]
    // 0x122a248: r3 = Instance_Duration
    //     0x122a248: add             x3, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0x122a24c: ldr             x3, [x3, #0x318]
    // 0x122a250: StoreField: r1->field_53 = r3
    //     0x122a250: stur            w3, [x1, #0x53]
    // 0x122a254: r4 = true
    //     0x122a254: add             x4, NULL, #0x20  ; true
    // 0x122a258: StoreField: r1->field_57 = r4
    //     0x122a258: stur            w4, [x1, #0x57]
    // 0x122a25c: r5 = Instance_Alignment
    //     0x122a25c: add             x5, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0x122a260: ldr             x5, [x5, #0xb80]
    // 0x122a264: StoreField: r1->field_5b = r5
    //     0x122a264: stur            w5, [x1, #0x5b]
    // 0x122a268: mov             x0, x1
    // 0x122a26c: b               #0x122a2b0
    // 0x122a270: mov             x3, x4
    // 0x122a274: mov             x4, x5
    // 0x122a278: mov             x5, x6
    // 0x122a27c: r0 = _OutlinedIconButtonDefaultsM3()
    //     0x122a27c: bl              #0x122a2bc  ; Allocate_OutlinedIconButtonDefaultsM3Stub -> _OutlinedIconButtonDefaultsM3 (size=0x74)
    // 0x122a280: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0x122a284: StoreField: r0->field_6f = r1
    //     0x122a284: stur            w1, [x0, #0x6f]
    // 0x122a288: ldur            x1, [fp, #-8]
    // 0x122a28c: StoreField: r0->field_6b = r1
    //     0x122a28c: stur            w1, [x0, #0x6b]
    // 0x122a290: r1 = Instance_Duration
    //     0x122a290: add             x1, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0x122a294: ldr             x1, [x1, #0x318]
    // 0x122a298: StoreField: r0->field_53 = r1
    //     0x122a298: stur            w1, [x0, #0x53]
    // 0x122a29c: r1 = true
    //     0x122a29c: add             x1, NULL, #0x20  ; true
    // 0x122a2a0: StoreField: r0->field_57 = r1
    //     0x122a2a0: stur            w1, [x0, #0x57]
    // 0x122a2a4: r1 = Instance_Alignment
    //     0x122a2a4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0x122a2a8: ldr             x1, [x1, #0xb80]
    // 0x122a2ac: StoreField: r0->field_5b = r1
    //     0x122a2ac: stur            w1, [x0, #0x5b]
    // 0x122a2b0: LeaveFrame
    //     0x122a2b0: mov             SP, fp
    //     0x122a2b4: ldp             fp, lr, [SP], #0x10
    // 0x122a2b8: ret
    //     0x122a2b8: ret             
  }
  _ themeStyleOf(/* No info */) {
    // ** addr: 0x122a9b4, size: 0x168
    // 0x122a9b4: EnterFrame
    //     0x122a9b4: stp             fp, lr, [SP, #-0x10]!
    //     0x122a9b8: mov             fp, SP
    // 0x122a9bc: AllocStack(0x38)
    //     0x122a9bc: sub             SP, SP, #0x38
    // 0x122a9c0: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0x122a9c0: mov             x0, x2
    //     0x122a9c4: stur            x2, [fp, #-8]
    // 0x122a9c8: CheckStackOverflow
    //     0x122a9c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x122a9cc: cmp             SP, x16
    //     0x122a9d0: b.ls            #0x122ab14
    // 0x122a9d4: mov             x1, x0
    // 0x122a9d8: r0 = of()
    //     0x122a9d8: bl              #0xd0e004  ; [package:flutter/src/widgets/icon_theme.dart] IconTheme::of
    // 0x122a9dc: mov             x1, x0
    // 0x122a9e0: stur            x1, [fp, #-0x18]
    // 0x122a9e4: LoadField: r2 = r1->field_7
    //     0x122a9e4: ldur            w2, [x1, #7]
    // 0x122a9e8: DecompressPointer r2
    //     0x122a9e8: add             x2, x2, HEAP, lsl #32
    // 0x122a9ec: stur            x2, [fp, #-0x10]
    // 0x122a9f0: r0 = LoadClassIdInstr(r2)
    //     0x122a9f0: ldur            x0, [x2, #-1]
    //     0x122a9f4: ubfx            x0, x0, #0xc, #0x14
    // 0x122a9f8: r16 = 24.000000
    //     0x122a9f8: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e4d0] 24
    //     0x122a9fc: ldr             x16, [x16, #0x4d0]
    // 0x122aa00: stp             x16, x2, [SP]
    // 0x122aa04: mov             lr, x0
    // 0x122aa08: ldr             lr, [x21, lr, lsl #3]
    // 0x122aa0c: blr             lr
    // 0x122aa10: mov             x2, x0
    // 0x122aa14: ldur            x0, [fp, #-0x18]
    // 0x122aa18: stur            x2, [fp, #-0x28]
    // 0x122aa1c: LoadField: r3 = r0->field_1b
    //     0x122aa1c: ldur            w3, [x0, #0x1b]
    // 0x122aa20: DecompressPointer r3
    //     0x122aa20: add             x3, x3, HEAP, lsl #32
    // 0x122aa24: ldur            x1, [fp, #-8]
    // 0x122aa28: stur            x3, [fp, #-0x20]
    // 0x122aa2c: r0 = brightnessOf()
    //     0x122aa2c: bl              #0xd1e4dc  ; [package:flutter/src/material/theme.dart] Theme::brightnessOf
    // 0x122aa30: LoadField: r1 = r0->field_7
    //     0x122aa30: ldur            x1, [x0, #7]
    // 0x122aa34: cmp             x1, #0
    // 0x122aa38: b.gt            #0x122aa64
    // 0x122aa3c: r0 = LoadStaticField(0xb80)
    //     0x122aa3c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x122aa40: ldr             x0, [x0, #0x1700]
    // 0x122aa44: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x122aa48: cmp             w0, w16
    // 0x122aa4c: b.ne            #0x122aa5c
    // 0x122aa50: r2 = kDefaultIconLightColor
    //     0x122aa50: add             x2, PP, #0x12, lsl #12  ; [pp+0x12ce0] Field <::.kDefaultIconLightColor>: static late final (offset: 0xb80)
    //     0x122aa54: ldr             x2, [x2, #0xce0]
    // 0x122aa58: r0 = InitLateFinalStaticField()
    //     0x122aa58: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x122aa5c: mov             x1, x0
    // 0x122aa60: b               #0x122aa88
    // 0x122aa64: r0 = LoadStaticField(0xb84)
    //     0x122aa64: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x122aa68: ldr             x0, [x0, #0x1708]
    // 0x122aa6c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x122aa70: cmp             w0, w16
    // 0x122aa74: b.ne            #0x122aa84
    // 0x122aa78: r2 = kDefaultIconDarkColor
    //     0x122aa78: add             x2, PP, #0x12, lsl #12  ; [pp+0x12ce8] Field <::.kDefaultIconDarkColor>: static late final (offset: 0xb84)
    //     0x122aa7c: ldr             x2, [x2, #0xce8]
    // 0x122aa80: r0 = InitLateFinalStaticField()
    //     0x122aa80: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x122aa84: mov             x1, x0
    // 0x122aa88: ldur            x0, [fp, #-0x20]
    // 0x122aa8c: cmp             w0, w1
    // 0x122aa90: b.ne            #0x122aa9c
    // 0x122aa94: r1 = Null
    //     0x122aa94: mov             x1, NULL
    // 0x122aa98: b               #0x122aaa0
    // 0x122aa9c: mov             x1, x0
    // 0x122aaa0: ldur            x0, [fp, #-0x28]
    // 0x122aaa4: tbnz            w0, #4, #0x122aab0
    // 0x122aaa8: r0 = Null
    //     0x122aaa8: mov             x0, NULL
    // 0x122aaac: b               #0x122aab4
    // 0x122aab0: ldur            x0, [fp, #-0x10]
    // 0x122aab4: stp             x0, x1, [SP]
    // 0x122aab8: r4 = const [0, 0x2, 0x2, 0, foregroundColor, 0, iconSize, 0x1, null]
    //     0x122aab8: add             x4, PP, #0x90, lsl #12  ; [pp+0x90d50] List(9) [0, 0x2, 0x2, 0, "foregroundColor", 0, "iconSize", 0x1, Null]
    //     0x122aabc: ldr             x4, [x4, #0xd50]
    // 0x122aac0: r0 = styleFrom()
    //     0x122aac0: bl              #0xdea068  ; [package:flutter/src/material/icon_button.dart] IconButton::styleFrom
    // 0x122aac4: ldur            x1, [fp, #-8]
    // 0x122aac8: stur            x0, [fp, #-8]
    // 0x122aacc: r0 = of()
    //     0x122aacc: bl              #0xd2d638  ; [package:flutter/src/material/icon_button_theme.dart] IconButtonTheme::of
    // 0x122aad0: LoadField: r1 = r0->field_7
    //     0x122aad0: ldur            w1, [x0, #7]
    // 0x122aad4: DecompressPointer r1
    //     0x122aad4: add             x1, x1, HEAP, lsl #32
    // 0x122aad8: cmp             w1, NULL
    // 0x122aadc: b.ne            #0x122aae8
    // 0x122aae0: r1 = Null
    //     0x122aae0: mov             x1, NULL
    // 0x122aae4: b               #0x122aaf4
    // 0x122aae8: ldur            x2, [fp, #-8]
    // 0x122aaec: r0 = merge()
    //     0x122aaec: bl              #0xd29660  ; [package:flutter/src/material/button_style.dart] ButtonStyle::merge
    // 0x122aaf0: mov             x1, x0
    // 0x122aaf4: cmp             w1, NULL
    // 0x122aaf8: b.ne            #0x122ab04
    // 0x122aafc: ldur            x0, [fp, #-8]
    // 0x122ab00: b               #0x122ab08
    // 0x122ab04: mov             x0, x1
    // 0x122ab08: LeaveFrame
    //     0x122ab08: mov             SP, fp
    //     0x122ab0c: ldp             fp, lr, [SP], #0x10
    // 0x122ab10: ret
    //     0x122ab10: ret             
    // 0x122ab14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x122ab14: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x122ab18: b               #0x122a9d4
  }
}

// class id: 8287, size: 0x14, field offset: 0x14
enum _IconButtonVariant extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11aa0f8, size: 0x64
    // 0x11aa0f8: EnterFrame
    //     0x11aa0f8: stp             fp, lr, [SP, #-0x10]!
    //     0x11aa0fc: mov             fp, SP
    // 0x11aa100: AllocStack(0x10)
    //     0x11aa100: sub             SP, SP, #0x10
    // 0x11aa104: SetupParameters(_IconButtonVariant this /* r1 => r0, fp-0x8 */)
    //     0x11aa104: mov             x0, x1
    //     0x11aa108: stur            x1, [fp, #-8]
    // 0x11aa10c: CheckStackOverflow
    //     0x11aa10c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11aa110: cmp             SP, x16
    //     0x11aa114: b.ls            #0x11aa154
    // 0x11aa118: r1 = Null
    //     0x11aa118: mov             x1, NULL
    // 0x11aa11c: r2 = 4
    //     0x11aa11c: mov             x2, #4
    // 0x11aa120: r0 = AllocateArray()
    //     0x11aa120: bl              #0x13df928  ; AllocateArrayStub
    // 0x11aa124: r16 = "_IconButtonVariant."
    //     0x11aa124: add             x16, PP, #0x80, lsl #12  ; [pp+0x80bf8] "_IconButtonVariant."
    //     0x11aa128: ldr             x16, [x16, #0xbf8]
    // 0x11aa12c: StoreField: r0->field_f = r16
    //     0x11aa12c: stur            w16, [x0, #0xf]
    // 0x11aa130: ldur            x1, [fp, #-8]
    // 0x11aa134: LoadField: r2 = r1->field_f
    //     0x11aa134: ldur            w2, [x1, #0xf]
    // 0x11aa138: DecompressPointer r2
    //     0x11aa138: add             x2, x2, HEAP, lsl #32
    // 0x11aa13c: StoreField: r0->field_13 = r2
    //     0x11aa13c: stur            w2, [x0, #0x13]
    // 0x11aa140: str             x0, [SP]
    // 0x11aa144: r0 = _interpolate()
    //     0x11aa144: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11aa148: LeaveFrame
    //     0x11aa148: mov             SP, fp
    //     0x11aa14c: ldp             fp, lr, [SP], #0x10
    // 0x11aa150: ret
    //     0x11aa150: ret             
    // 0x11aa154: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11aa154: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11aa158: b               #0x11aa118
  }
}
