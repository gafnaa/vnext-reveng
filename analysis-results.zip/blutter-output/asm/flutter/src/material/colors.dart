// lib: , url: package:flutter/src/material/colors.dart

// class id: 1048870, size: 0x8
class :: {
}

// class id: 3792, size: 0x34, field offset: 0x34
//   const constructor, 
class MaterialAccentColor extends ColorSwatch<dynamic> {

  _Double field_8;
  _Double field_10;
  _Double field_18;
  _Double field_20;
  ColorSpace field_28;
  _ConstMap<int, Color> field_30;
}

// class id: 3793, size: 0x34, field offset: 0x34
//   const constructor, 
class MaterialColor extends ColorSwatch<dynamic> {

  _Double field_8;
  _Double field_10;
  _Double field_18;
  _Double field_20;
  ColorSpace field_28;
  _ConstMap<int, Color> field_30;

  get _ shade300(/* No info */) {
    // ** addr: 0xb8176c, size: 0x60
    // 0xb8176c: EnterFrame
    //     0xb8176c: stp             fp, lr, [SP, #-0x10]!
    //     0xb81770: mov             fp, SP
    // 0xb81774: CheckStackOverflow
    //     0xb81774: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb81778: cmp             SP, x16
    //     0xb8177c: b.ls            #0xb817c0
    // 0xb81780: LoadField: r0 = r1->field_2f
    //     0xb81780: ldur            w0, [x1, #0x2f]
    // 0xb81784: DecompressPointer r0
    //     0xb81784: add             x0, x0, HEAP, lsl #32
    // 0xb81788: r1 = LoadClassIdInstr(r0)
    //     0xb81788: ldur            x1, [x0, #-1]
    //     0xb8178c: ubfx            x1, x1, #0xc, #0x14
    // 0xb81790: mov             x16, x0
    // 0xb81794: mov             x0, x1
    // 0xb81798: mov             x1, x16
    // 0xb8179c: r2 = 600
    //     0xb8179c: mov             x2, #0x258
    // 0xb817a0: r0 = GDT[cid_x0 + -0xd48]()
    //     0xb817a0: sub             lr, x0, #0xd48
    //     0xb817a4: ldr             lr, [x21, lr, lsl #3]
    //     0xb817a8: blr             lr
    // 0xb817ac: cmp             w0, NULL
    // 0xb817b0: b.eq            #0xb817c8
    // 0xb817b4: LeaveFrame
    //     0xb817b4: mov             SP, fp
    //     0xb817b8: ldp             fp, lr, [SP], #0x10
    // 0xb817bc: ret
    //     0xb817bc: ret             
    // 0xb817c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb817c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb817c4: b               #0xb81780
    // 0xb817c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb817c8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ shade400(/* No info */) {
    // ** addr: 0xd1e41c, size: 0x60
    // 0xd1e41c: EnterFrame
    //     0xd1e41c: stp             fp, lr, [SP, #-0x10]!
    //     0xd1e420: mov             fp, SP
    // 0xd1e424: CheckStackOverflow
    //     0xd1e424: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd1e428: cmp             SP, x16
    //     0xd1e42c: b.ls            #0xd1e470
    // 0xd1e430: LoadField: r0 = r1->field_2f
    //     0xd1e430: ldur            w0, [x1, #0x2f]
    // 0xd1e434: DecompressPointer r0
    //     0xd1e434: add             x0, x0, HEAP, lsl #32
    // 0xd1e438: r1 = LoadClassIdInstr(r0)
    //     0xd1e438: ldur            x1, [x0, #-1]
    //     0xd1e43c: ubfx            x1, x1, #0xc, #0x14
    // 0xd1e440: mov             x16, x0
    // 0xd1e444: mov             x0, x1
    // 0xd1e448: mov             x1, x16
    // 0xd1e44c: r2 = 800
    //     0xd1e44c: mov             x2, #0x320
    // 0xd1e450: r0 = GDT[cid_x0 + -0xd48]()
    //     0xd1e450: sub             lr, x0, #0xd48
    //     0xd1e454: ldr             lr, [x21, lr, lsl #3]
    //     0xd1e458: blr             lr
    // 0xd1e45c: cmp             w0, NULL
    // 0xd1e460: b.eq            #0xd1e478
    // 0xd1e464: LeaveFrame
    //     0xd1e464: mov             SP, fp
    //     0xd1e468: ldp             fp, lr, [SP], #0x10
    // 0xd1e46c: ret
    //     0xd1e46c: ret             
    // 0xd1e470: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1e470: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd1e474: b               #0xd1e430
    // 0xd1e478: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1e478: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ shade700(/* No info */) {
    // ** addr: 0xd1e47c, size: 0x60
    // 0xd1e47c: EnterFrame
    //     0xd1e47c: stp             fp, lr, [SP, #-0x10]!
    //     0xd1e480: mov             fp, SP
    // 0xd1e484: CheckStackOverflow
    //     0xd1e484: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd1e488: cmp             SP, x16
    //     0xd1e48c: b.ls            #0xd1e4d0
    // 0xd1e490: LoadField: r0 = r1->field_2f
    //     0xd1e490: ldur            w0, [x1, #0x2f]
    // 0xd1e494: DecompressPointer r0
    //     0xd1e494: add             x0, x0, HEAP, lsl #32
    // 0xd1e498: r1 = LoadClassIdInstr(r0)
    //     0xd1e498: ldur            x1, [x0, #-1]
    //     0xd1e49c: ubfx            x1, x1, #0xc, #0x14
    // 0xd1e4a0: mov             x16, x0
    // 0xd1e4a4: mov             x0, x1
    // 0xd1e4a8: mov             x1, x16
    // 0xd1e4ac: r2 = 1400
    //     0xd1e4ac: mov             x2, #0x578
    // 0xd1e4b0: r0 = GDT[cid_x0 + -0xd48]()
    //     0xd1e4b0: sub             lr, x0, #0xd48
    //     0xd1e4b4: ldr             lr, [x21, lr, lsl #3]
    //     0xd1e4b8: blr             lr
    // 0xd1e4bc: cmp             w0, NULL
    // 0xd1e4c0: b.eq            #0xd1e4d8
    // 0xd1e4c4: LeaveFrame
    //     0xd1e4c4: mov             SP, fp
    //     0xd1e4c8: ldp             fp, lr, [SP], #0x10
    // 0xd1e4cc: ret
    //     0xd1e4cc: ret             
    // 0xd1e4d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1e4d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd1e4d4: b               #0xd1e490
    // 0xd1e4d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd1e4d8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ shade50(/* No info */) {
    // ** addr: 0xd44e64, size: 0x60
    // 0xd44e64: EnterFrame
    //     0xd44e64: stp             fp, lr, [SP, #-0x10]!
    //     0xd44e68: mov             fp, SP
    // 0xd44e6c: CheckStackOverflow
    //     0xd44e6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd44e70: cmp             SP, x16
    //     0xd44e74: b.ls            #0xd44eb8
    // 0xd44e78: LoadField: r0 = r1->field_2f
    //     0xd44e78: ldur            w0, [x1, #0x2f]
    // 0xd44e7c: DecompressPointer r0
    //     0xd44e7c: add             x0, x0, HEAP, lsl #32
    // 0xd44e80: r1 = LoadClassIdInstr(r0)
    //     0xd44e80: ldur            x1, [x0, #-1]
    //     0xd44e84: ubfx            x1, x1, #0xc, #0x14
    // 0xd44e88: mov             x16, x0
    // 0xd44e8c: mov             x0, x1
    // 0xd44e90: mov             x1, x16
    // 0xd44e94: r2 = 100
    //     0xd44e94: mov             x2, #0x64
    // 0xd44e98: r0 = GDT[cid_x0 + -0xd48]()
    //     0xd44e98: sub             lr, x0, #0xd48
    //     0xd44e9c: ldr             lr, [x21, lr, lsl #3]
    //     0xd44ea0: blr             lr
    // 0xd44ea4: cmp             w0, NULL
    // 0xd44ea8: b.eq            #0xd44ec0
    // 0xd44eac: LeaveFrame
    //     0xd44eac: mov             SP, fp
    //     0xd44eb0: ldp             fp, lr, [SP], #0x10
    // 0xd44eb4: ret
    //     0xd44eb4: ret             
    // 0xd44eb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd44eb8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd44ebc: b               #0xd44e78
    // 0xd44ec0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd44ec0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ shade800(/* No info */) {
    // ** addr: 0xd44ec4, size: 0x60
    // 0xd44ec4: EnterFrame
    //     0xd44ec4: stp             fp, lr, [SP, #-0x10]!
    //     0xd44ec8: mov             fp, SP
    // 0xd44ecc: CheckStackOverflow
    //     0xd44ecc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd44ed0: cmp             SP, x16
    //     0xd44ed4: b.ls            #0xd44f18
    // 0xd44ed8: LoadField: r0 = r1->field_2f
    //     0xd44ed8: ldur            w0, [x1, #0x2f]
    // 0xd44edc: DecompressPointer r0
    //     0xd44edc: add             x0, x0, HEAP, lsl #32
    // 0xd44ee0: r1 = LoadClassIdInstr(r0)
    //     0xd44ee0: ldur            x1, [x0, #-1]
    //     0xd44ee4: ubfx            x1, x1, #0xc, #0x14
    // 0xd44ee8: mov             x16, x0
    // 0xd44eec: mov             x0, x1
    // 0xd44ef0: mov             x1, x16
    // 0xd44ef4: r2 = 1600
    //     0xd44ef4: mov             x2, #0x640
    // 0xd44ef8: r0 = GDT[cid_x0 + -0xd48]()
    //     0xd44ef8: sub             lr, x0, #0xd48
    //     0xd44efc: ldr             lr, [x21, lr, lsl #3]
    //     0xd44f00: blr             lr
    // 0xd44f04: cmp             w0, NULL
    // 0xd44f08: b.eq            #0xd44f20
    // 0xd44f0c: LeaveFrame
    //     0xd44f0c: mov             SP, fp
    //     0xd44f10: ldp             fp, lr, [SP], #0x10
    // 0xd44f14: ret
    //     0xd44f14: ret             
    // 0xd44f18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd44f18: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd44f1c: b               #0xd44ed8
    // 0xd44f20: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd44f20: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ shade100(/* No info */) {
    // ** addr: 0xe9f4d4, size: 0x60
    // 0xe9f4d4: EnterFrame
    //     0xe9f4d4: stp             fp, lr, [SP, #-0x10]!
    //     0xe9f4d8: mov             fp, SP
    // 0xe9f4dc: CheckStackOverflow
    //     0xe9f4dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe9f4e0: cmp             SP, x16
    //     0xe9f4e4: b.ls            #0xe9f528
    // 0xe9f4e8: LoadField: r0 = r1->field_2f
    //     0xe9f4e8: ldur            w0, [x1, #0x2f]
    // 0xe9f4ec: DecompressPointer r0
    //     0xe9f4ec: add             x0, x0, HEAP, lsl #32
    // 0xe9f4f0: r1 = LoadClassIdInstr(r0)
    //     0xe9f4f0: ldur            x1, [x0, #-1]
    //     0xe9f4f4: ubfx            x1, x1, #0xc, #0x14
    // 0xe9f4f8: mov             x16, x0
    // 0xe9f4fc: mov             x0, x1
    // 0xe9f500: mov             x1, x16
    // 0xe9f504: r2 = 200
    //     0xe9f504: mov             x2, #0xc8
    // 0xe9f508: r0 = GDT[cid_x0 + -0xd48]()
    //     0xe9f508: sub             lr, x0, #0xd48
    //     0xe9f50c: ldr             lr, [x21, lr, lsl #3]
    //     0xe9f510: blr             lr
    // 0xe9f514: cmp             w0, NULL
    // 0xe9f518: b.eq            #0xe9f530
    // 0xe9f51c: LeaveFrame
    //     0xe9f51c: mov             SP, fp
    //     0xe9f520: ldp             fp, lr, [SP], #0x10
    // 0xe9f524: ret
    //     0xe9f524: ret             
    // 0xe9f528: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe9f528: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe9f52c: b               #0xe9f4e8
    // 0xe9f530: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe9f530: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}
