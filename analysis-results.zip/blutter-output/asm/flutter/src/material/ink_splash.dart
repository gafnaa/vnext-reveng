// lib: , url: package:flutter/src/material/ink_splash.dart

// class id: 1048904, size: 0x8
class :: {

  static _ _getTargetRadius(/* No info */) {
    // ** addr: 0xd258a4, size: 0x94
    // 0xd258a4: EnterFrame
    //     0xd258a4: stp             fp, lr, [SP, #-0x10]!
    //     0xd258a8: mov             fp, SP
    // 0xd258ac: AllocStack(0x10)
    //     0xd258ac: sub             SP, SP, #0x10
    // 0xd258b0: SetupParameters(dynamic _ /* r1 => r3 */, dynamic _ /* r2 => r1 */, dynamic _ /* r3 => r0 */, dynamic _ /* r5 => r2, fp-0x8 */)
    //     0xd258b0: mov             x0, x3
    //     0xd258b4: mov             x3, x1
    //     0xd258b8: mov             x1, x2
    //     0xd258bc: mov             x2, x5
    //     0xd258c0: stur            x5, [fp, #-8]
    // 0xd258c4: CheckStackOverflow
    //     0xd258c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd258c8: cmp             SP, x16
    //     0xd258cc: b.ls            #0xd25930
    // 0xd258d0: tbnz            w1, #4, #0xd2591c
    // 0xd258d4: cmp             w0, NULL
    // 0xd258d8: b.eq            #0xd258fc
    // 0xd258dc: str             x0, [SP]
    // 0xd258e0: ClosureCall
    //     0xd258e0: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xd258e4: ldur            x2, [x0, #0x1f]
    //     0xd258e8: blr             x2
    // 0xd258ec: mov             x1, x0
    // 0xd258f0: r0 = size()
    //     0xd258f0: bl              #0x8632d0  ; [dart:ui] Rect::size
    // 0xd258f4: mov             x1, x0
    // 0xd258f8: b               #0xd25908
    // 0xd258fc: mov             x1, x3
    // 0xd25900: r0 = size()
    //     0xd25900: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xd25904: mov             x1, x0
    // 0xd25908: ldur            x2, [fp, #-8]
    // 0xd2590c: r0 = _getSplashRadiusForPositionInSize()
    //     0xd2590c: bl              #0xd25938  ; [package:flutter/src/material/ink_splash.dart] ::_getSplashRadiusForPositionInSize
    // 0xd25910: LeaveFrame
    //     0xd25910: mov             SP, fp
    //     0xd25914: ldp             fp, lr, [SP], #0x10
    // 0xd25918: ret
    //     0xd25918: ret             
    // 0xd2591c: d0 = 35.000000
    //     0xd2591c: add             x17, PP, #0x80, lsl #12  ; [pp+0x80c28] IMM: double(35) from 0x4041800000000000
    //     0xd25920: ldr             d0, [x17, #0xc28]
    // 0xd25924: LeaveFrame
    //     0xd25924: mov             SP, fp
    //     0xd25928: ldp             fp, lr, [SP], #0x10
    // 0xd2592c: ret
    //     0xd2592c: ret             
    // 0xd25930: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd25930: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd25934: b               #0xd258d0
  }
  static _ _getSplashRadiusForPositionInSize(/* No info */) {
    // ** addr: 0xd25938, size: 0x13c
    // 0xd25938: EnterFrame
    //     0xd25938: stp             fp, lr, [SP, #-0x10]!
    //     0xd2593c: mov             fp, SP
    // 0xd25940: AllocStack(0x28)
    //     0xd25940: sub             SP, SP, #0x28
    // 0xd25944: SetupParameters(dynamic _ /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xd25944: mov             x3, x1
    //     0xd25948: mov             x0, x2
    //     0xd2594c: stur            x1, [fp, #-8]
    //     0xd25950: stur            x2, [fp, #-0x10]
    // 0xd25954: CheckStackOverflow
    //     0xd25954: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd25958: cmp             SP, x16
    //     0xd2595c: b.ls            #0xd25a6c
    // 0xd25960: mov             x1, x0
    // 0xd25964: r2 = Instance_Offset
    //     0xd25964: ldr             x2, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xd25968: r0 = -()
    //     0xd25968: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0xd2596c: LoadField: d0 = r0->field_7
    //     0xd2596c: ldur            d0, [x0, #7]
    // 0xd25970: fmul            d1, d0, d0
    // 0xd25974: LoadField: d0 = r0->field_f
    //     0xd25974: ldur            d0, [x0, #0xf]
    // 0xd25978: fmul            d2, d0, d0
    // 0xd2597c: fadd            d0, d1, d2
    // 0xd25980: fsqrt           d1, d0
    // 0xd25984: ldur            x1, [fp, #-8]
    // 0xd25988: stur            d1, [fp, #-0x18]
    // 0xd2598c: r0 = topRight()
    //     0xd2598c: bl              #0xd23c60  ; [dart:ui] Size::topRight
    // 0xd25990: ldur            x1, [fp, #-0x10]
    // 0xd25994: mov             x2, x0
    // 0xd25998: r0 = -()
    //     0xd25998: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0xd2599c: LoadField: d0 = r0->field_7
    //     0xd2599c: ldur            d0, [x0, #7]
    // 0xd259a0: fmul            d1, d0, d0
    // 0xd259a4: LoadField: d0 = r0->field_f
    //     0xd259a4: ldur            d0, [x0, #0xf]
    // 0xd259a8: fmul            d2, d0, d0
    // 0xd259ac: fadd            d0, d1, d2
    // 0xd259b0: fsqrt           d1, d0
    // 0xd259b4: ldur            x1, [fp, #-8]
    // 0xd259b8: stur            d1, [fp, #-0x20]
    // 0xd259bc: r0 = bottomLeft()
    //     0xd259bc: bl              #0xd23c18  ; [dart:ui] Size::bottomLeft
    // 0xd259c0: ldur            x1, [fp, #-0x10]
    // 0xd259c4: mov             x2, x0
    // 0xd259c8: r0 = -()
    //     0xd259c8: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0xd259cc: LoadField: d0 = r0->field_7
    //     0xd259cc: ldur            d0, [x0, #7]
    // 0xd259d0: fmul            d1, d0, d0
    // 0xd259d4: LoadField: d0 = r0->field_f
    //     0xd259d4: ldur            d0, [x0, #0xf]
    // 0xd259d8: fmul            d2, d0, d0
    // 0xd259dc: fadd            d0, d1, d2
    // 0xd259e0: fsqrt           d1, d0
    // 0xd259e4: ldur            x1, [fp, #-8]
    // 0xd259e8: stur            d1, [fp, #-0x28]
    // 0xd259ec: r0 = bottomRight()
    //     0xd259ec: bl              #0x8587b8  ; [dart:ui] Size::bottomRight
    // 0xd259f0: ldur            x1, [fp, #-0x10]
    // 0xd259f4: mov             x2, x0
    // 0xd259f8: r0 = -()
    //     0xd259f8: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0xd259fc: LoadField: d0 = r0->field_7
    //     0xd259fc: ldur            d0, [x0, #7]
    // 0xd25a00: fmul            d1, d0, d0
    // 0xd25a04: LoadField: d0 = r0->field_f
    //     0xd25a04: ldur            d0, [x0, #0xf]
    // 0xd25a08: fmul            d2, d0, d0
    // 0xd25a0c: fadd            d0, d1, d2
    // 0xd25a10: fsqrt           d1, d0
    // 0xd25a14: ldur            d2, [fp, #-0x18]
    // 0xd25a18: ldur            d0, [fp, #-0x20]
    // 0xd25a1c: fmax            v3.2d, v2.2d, v0.2d
    // 0xd25a20: ldur            d0, [fp, #-0x28]
    // 0xd25a24: fmax            v2.2d, v0.2d, v1.2d
    // 0xd25a28: fmax            v0.2d, v3.2d, v2.2d
    // 0xd25a2c: stp             fp, lr, [SP, #-0x10]!
    // 0xd25a30: mov             fp, SP
    // 0xd25a34: CallRuntime_LibcCeil(double) -> double
    //     0xd25a34: and             SP, SP, #0xfffffffffffffff0
    //     0xd25a38: mov             sp, SP
    //     0xd25a3c: ldr             x16, [THR, #0x760]  ; THR::LibcCeil
    //     0xd25a40: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xd25a44: blr             x16
    //     0xd25a48: mov             x16, #8
    //     0xd25a4c: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xd25a50: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xd25a54: sub             sp, x16, #1, lsl #12
    //     0xd25a58: mov             SP, fp
    //     0xd25a5c: ldp             fp, lr, [SP], #0x10
    // 0xd25a60: LeaveFrame
    //     0xd25a60: mov             SP, fp
    //     0xd25a64: ldp             fp, lr, [SP], #0x10
    // 0xd25a68: ret
    //     0xd25a68: ret             
    // 0xd25a6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd25a6c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd25a70: b               #0xd25960
  }
}

// class id: 3033, size: 0x8, field offset: 0x8
//   const constructor, 
class _InkSplashFactory extends InteractiveInkFeatureFactory {
}

// class id: 3038, size: 0x48, field offset: 0x1c
class InkSplash extends InteractiveInkFeature {

  late AnimationController _radiusController; // offset: 0x3c
  late Animation<int> _alpha; // offset: 0x40
  late Animation<double> _radius; // offset: 0x38

  _ InkSplash(/* No info */) {
    // ** addr: 0xd2546c, size: 0x438
    // 0xd2546c: EnterFrame
    //     0xd2546c: stp             fp, lr, [SP, #-0x10]!
    //     0xd25470: mov             fp, SP
    // 0xd25474: AllocStack(0x40)
    //     0xd25474: sub             SP, SP, #0x40
    // 0xd25478: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xd2547c: mov             x9, x1
    // 0xd25480: mov             x8, x3
    // 0xd25484: mov             x4, x7
    // 0xd25488: stur            x7, [fp, #-0x28]
    // 0xd2548c: mov             x7, x5
    // 0xd25490: stur            x1, [fp, #-8]
    // 0xd25494: stur            x3, [fp, #-0x10]
    // 0xd25498: stur            x5, [fp, #-0x18]
    // 0xd2549c: stur            x6, [fp, #-0x20]
    // 0xd254a0: CheckStackOverflow
    //     0xd254a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd254a4: cmp             SP, x16
    //     0xd254a8: b.ls            #0xd25884
    // 0xd254ac: StoreField: r9->field_37 = r0
    //     0xd254ac: stur            w0, [x9, #0x37]
    // 0xd254b0: StoreField: r9->field_3b = r0
    //     0xd254b0: stur            w0, [x9, #0x3b]
    // 0xd254b4: StoreField: r9->field_3f = r0
    //     0xd254b4: stur            w0, [x9, #0x3f]
    // 0xd254b8: ldr             x0, [fp, #0x30]
    // 0xd254bc: StoreField: r9->field_1b = r0
    //     0xd254bc: stur            w0, [x9, #0x1b]
    //     0xd254c0: ldurb           w16, [x9, #-1]
    //     0xd254c4: ldurb           w17, [x0, #-1]
    //     0xd254c8: and             x16, x17, x16, lsr #2
    //     0xd254cc: tst             x16, HEAP, lsr #32
    //     0xd254d0: b.eq            #0xd254d8
    //     0xd254d4: bl              #0x13de094  ; WriteBarrierWrappersStub
    // 0xd254d8: cmp             w2, NULL
    // 0xd254dc: b.ne            #0xd254ec
    // 0xd254e0: r0 = Instance_BorderRadius
    //     0xd254e0: add             x0, PP, #0x99, lsl #12  ; [pp+0x99508] Obj!BorderRadius@129e311
    //     0xd254e4: ldr             x0, [x0, #0x508]
    // 0xd254e8: b               #0xd254f0
    // 0xd254ec: mov             x0, x2
    // 0xd254f0: ldr             x1, [fp, #0x28]
    // 0xd254f4: StoreField: r9->field_1f = r0
    //     0xd254f4: stur            w0, [x9, #0x1f]
    //     0xd254f8: ldurb           w16, [x9, #-1]
    //     0xd254fc: ldurb           w17, [x0, #-1]
    //     0xd25500: and             x16, x17, x16, lsr #2
    //     0xd25504: tst             x16, HEAP, lsr #32
    //     0xd25508: b.eq            #0xd25510
    //     0xd2550c: bl              #0x13de094  ; WriteBarrierWrappersStub
    // 0xd25510: cmp             w1, NULL
    // 0xd25514: b.ne            #0xd25530
    // 0xd25518: ldr             x1, [fp, #0x18]
    // 0xd2551c: mov             x2, x7
    // 0xd25520: ldr             x3, [fp, #0x20]
    // 0xd25524: ldr             x5, [fp, #0x30]
    // 0xd25528: r0 = _getTargetRadius()
    //     0xd25528: bl              #0xd258a4  ; [package:flutter/src/material/ink_splash.dart] ::_getTargetRadius
    // 0xd2552c: b               #0xd25534
    // 0xd25530: LoadField: d0 = r1->field_7
    //     0xd25530: ldur            d0, [x1, #7]
    // 0xd25534: ldur            x2, [fp, #-8]
    // 0xd25538: ldr             x1, [fp, #0x20]
    // 0xd2553c: ldr             x0, [fp, #0x18]
    // 0xd25540: stur            d0, [fp, #-0x38]
    // 0xd25544: StoreField: r2->field_23 = d0
    //     0xd25544: stur            d0, [x2, #0x23]
    // 0xd25548: r1 = 1
    //     0xd25548: mov             x1, #1
    // 0xd2554c: r0 = AllocateContext()
    //     0xd2554c: bl              #0x13de838  ; AllocateContextStub
    // 0xd25550: mov             x1, x0
    // 0xd25554: ldr             x0, [fp, #0x18]
    // 0xd25558: StoreField: r1->field_f = r0
    //     0xd25558: stur            w0, [x1, #0xf]
    // 0xd2555c: ldr             x2, [fp, #0x20]
    // 0xd25560: cmp             w2, NULL
    // 0xd25564: b.eq            #0xd25570
    // 0xd25568: mov             x0, x2
    // 0xd2556c: b               #0xd25590
    // 0xd25570: ldur            x3, [fp, #-0x18]
    // 0xd25574: tbnz            w3, #4, #0xd2558c
    // 0xd25578: mov             x2, x1
    // 0xd2557c: r1 = Function '<anonymous closure>': static.
    //     0xd2557c: add             x1, PP, #0x99, lsl #12  ; [pp+0x99648] AnonymousClosure: static (0xd23d6c), of [package:flutter/src/material/ink_ripple.dart] 
    //     0xd25580: ldr             x1, [x1, #0x648]
    // 0xd25584: r0 = AllocateClosure()
    //     0xd25584: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd25588: b               #0xd25590
    // 0xd2558c: r0 = Null
    //     0xd2558c: mov             x0, NULL
    // 0xd25590: ldur            x2, [fp, #-8]
    // 0xd25594: ldur            x4, [fp, #-0x10]
    // 0xd25598: ldur            x1, [fp, #-0x18]
    // 0xd2559c: ldur            x3, [fp, #-0x20]
    // 0xd255a0: ldur            d0, [fp, #-0x38]
    // 0xd255a4: StoreField: r2->field_2b = r0
    //     0xd255a4: stur            w0, [x2, #0x2b]
    //     0xd255a8: tbz             w0, #0, #0xd255c4
    //     0xd255ac: ldurb           w16, [x2, #-1]
    //     0xd255b0: ldurb           w17, [x0, #-1]
    //     0xd255b4: and             x16, x17, x16, lsr #2
    //     0xd255b8: tst             x16, HEAP, lsr #32
    //     0xd255bc: b.eq            #0xd255c4
    //     0xd255c0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd255c4: eor             x0, x1, #0x10
    // 0xd255c8: StoreField: r2->field_2f = r0
    //     0xd255c8: stur            w0, [x2, #0x2f]
    // 0xd255cc: ldr             x0, [fp, #0x10]
    // 0xd255d0: StoreField: r2->field_33 = r0
    //     0xd255d0: stur            w0, [x2, #0x33]
    //     0xd255d4: ldurb           w16, [x2, #-1]
    //     0xd255d8: ldurb           w17, [x0, #-1]
    //     0xd255dc: and             x16, x17, x16, lsr #2
    //     0xd255e0: tst             x16, HEAP, lsr #32
    //     0xd255e4: b.eq            #0xd255ec
    //     0xd255e8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd255ec: mov             x0, x4
    // 0xd255f0: StoreField: r2->field_13 = r0
    //     0xd255f0: stur            w0, [x2, #0x13]
    //     0xd255f4: ldurb           w16, [x2, #-1]
    //     0xd255f8: ldurb           w17, [x0, #-1]
    //     0xd255fc: and             x16, x17, x16, lsr #2
    //     0xd25600: tst             x16, HEAP, lsr #32
    //     0xd25604: b.eq            #0xd2560c
    //     0xd25608: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd2560c: ldur            x0, [fp, #-0x28]
    // 0xd25610: ArrayStore: r2[0] = r0  ; List_4
    //     0xd25610: stur            w0, [x2, #0x17]
    //     0xd25614: ldurb           w16, [x2, #-1]
    //     0xd25618: ldurb           w17, [x0, #-1]
    //     0xd2561c: and             x16, x17, x16, lsr #2
    //     0xd25620: tst             x16, HEAP, lsr #32
    //     0xd25624: b.eq            #0xd2562c
    //     0xd25628: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd2562c: ldr             x0, [fp, #0x18]
    // 0xd25630: StoreField: r2->field_b = r0
    //     0xd25630: stur            w0, [x2, #0xb]
    //     0xd25634: ldurb           w16, [x2, #-1]
    //     0xd25638: ldurb           w17, [x0, #-1]
    //     0xd2563c: and             x16, x17, x16, lsr #2
    //     0xd25640: tst             x16, HEAP, lsr #32
    //     0xd25644: b.eq            #0xd2564c
    //     0xd25648: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd2564c: ldr             x0, [fp, #0x38]
    // 0xd25650: StoreField: r2->field_f = r0
    //     0xd25650: stur            w0, [x2, #0xf]
    //     0xd25654: ldurb           w16, [x2, #-1]
    //     0xd25658: ldurb           w17, [x0, #-1]
    //     0xd2565c: and             x16, x17, x16, lsr #2
    //     0xd25660: tst             x16, HEAP, lsr #32
    //     0xd25664: b.eq            #0xd2566c
    //     0xd25668: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd2566c: mov             x0, x3
    // 0xd25670: StoreField: r2->field_7 = r0
    //     0xd25670: stur            w0, [x2, #7]
    //     0xd25674: ldurb           w16, [x2, #-1]
    //     0xd25678: ldurb           w17, [x0, #-1]
    //     0xd2567c: and             x16, x17, x16, lsr #2
    //     0xd25680: tst             x16, HEAP, lsr #32
    //     0xd25684: b.eq            #0xd2568c
    //     0xd25688: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd2568c: LoadField: r0 = r3->field_53
    //     0xd2568c: ldur            w0, [x3, #0x53]
    // 0xd25690: DecompressPointer r0
    //     0xd25690: add             x0, x0, HEAP, lsl #32
    // 0xd25694: stur            x0, [fp, #-0x18]
    // 0xd25698: r1 = <double>
    //     0xd25698: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd2569c: r0 = AnimationController()
    //     0xd2569c: bl              #0x87522c  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0xd256a0: stur            x0, [fp, #-0x28]
    // 0xd256a4: r16 = Instance_Duration
    //     0xd256a4: ldr             x16, [PP, #0xa80]  ; [pp+0xa80] Obj!Duration@12c8921
    // 0xd256a8: str             x16, [SP]
    // 0xd256ac: mov             x1, x0
    // 0xd256b0: ldur            x2, [fp, #-0x18]
    // 0xd256b4: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0xd256b4: add             x4, PP, #0x15, lsl #12  ; [pp+0x155a0] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0xd256b8: ldr             x4, [x4, #0x5a0]
    // 0xd256bc: r0 = AnimationController()
    //     0xd256bc: bl              #0x874ea4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0xd256c0: ldur            x2, [fp, #-0x20]
    // 0xd256c4: r1 = Function 'markNeedsPaint':.
    //     0xd256c4: add             x1, PP, #0x90, lsl #12  ; [pp+0x901f0] AnonymousClosure: (0xbf0a50), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0xbf0858)
    //     0xd256c8: ldr             x1, [x1, #0x1f0]
    // 0xd256cc: r0 = AllocateClosure()
    //     0xd256cc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd256d0: ldur            x1, [fp, #-0x28]
    // 0xd256d4: mov             x2, x0
    // 0xd256d8: stur            x0, [fp, #-0x30]
    // 0xd256dc: r0 = addListener()
    //     0xd256dc: bl              #0xd0440c  ; [dart:mixin_deduplication] _MixinApplication455&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::addListener
    // 0xd256e0: ldur            x1, [fp, #-0x28]
    // 0xd256e4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd256e4: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd256e8: r0 = forward()
    //     0xd256e8: bl              #0x8cd83c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0xd256ec: ldur            x0, [fp, #-0x28]
    // 0xd256f0: ldur            x2, [fp, #-8]
    // 0xd256f4: StoreField: r2->field_3b = r0
    //     0xd256f4: stur            w0, [x2, #0x3b]
    //     0xd256f8: ldurb           w16, [x2, #-1]
    //     0xd256fc: ldurb           w17, [x0, #-1]
    //     0xd25700: and             x16, x17, x16, lsr #2
    //     0xd25704: tst             x16, HEAP, lsr #32
    //     0xd25708: b.eq            #0xd25710
    //     0xd2570c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd25710: r1 = <double>
    //     0xd25710: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd25714: r0 = Tween()
    //     0xd25714: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xd25718: mov             x1, x0
    // 0xd2571c: r0 = 0.000000
    //     0xd2571c: ldr             x0, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xd25720: StoreField: r1->field_b = r0
    //     0xd25720: stur            w0, [x1, #0xb]
    // 0xd25724: ldur            d0, [fp, #-0x38]
    // 0xd25728: r0 = inline_Allocate_Double()
    //     0xd25728: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xd2572c: add             x0, x0, #0x10
    //     0xd25730: cmp             x2, x0
    //     0xd25734: b.ls            #0xd2588c
    //     0xd25738: str             x0, [THR, #0x60]  ; THR::top
    //     0xd2573c: sub             x0, x0, #0xf
    //     0xd25740: mov             x2, #0xe19c
    //     0xd25744: movk            x2, #3, lsl #16
    //     0xd25748: stur            x2, [x0, #-1]
    // 0xd2574c: dmb             ishst
    // 0xd25750: StoreField: r0->field_7 = d0
    //     0xd25750: stur            d0, [x0, #7]
    // 0xd25754: StoreField: r1->field_f = r0
    //     0xd25754: stur            w0, [x1, #0xf]
    // 0xd25758: ldur            x2, [fp, #-0x28]
    // 0xd2575c: r0 = animate()
    //     0xd2575c: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xd25760: ldur            x2, [fp, #-8]
    // 0xd25764: StoreField: r2->field_37 = r0
    //     0xd25764: stur            w0, [x2, #0x37]
    //     0xd25768: ldurb           w16, [x2, #-1]
    //     0xd2576c: ldurb           w17, [x0, #-1]
    //     0xd25770: and             x16, x17, x16, lsr #2
    //     0xd25774: tst             x16, HEAP, lsr #32
    //     0xd25778: b.eq            #0xd25780
    //     0xd2577c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd25780: r1 = <double>
    //     0xd25780: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd25784: r0 = AnimationController()
    //     0xd25784: bl              #0x87522c  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0xd25788: stur            x0, [fp, #-0x28]
    // 0xd2578c: r16 = Instance_Duration
    //     0xd2578c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xd25790: ldr             x16, [x16, #0x318]
    // 0xd25794: str             x16, [SP]
    // 0xd25798: mov             x1, x0
    // 0xd2579c: ldur            x2, [fp, #-0x18]
    // 0xd257a0: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0xd257a0: add             x4, PP, #0x15, lsl #12  ; [pp+0x155a0] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0xd257a4: ldr             x4, [x4, #0x5a0]
    // 0xd257a8: r0 = AnimationController()
    //     0xd257a8: bl              #0x874ea4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0xd257ac: ldur            x1, [fp, #-0x28]
    // 0xd257b0: ldur            x2, [fp, #-0x30]
    // 0xd257b4: r0 = addListener()
    //     0xd257b4: bl              #0xd0440c  ; [dart:mixin_deduplication] _MixinApplication455&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::addListener
    // 0xd257b8: ldur            x2, [fp, #-8]
    // 0xd257bc: r1 = Function '_handleAlphaStatusChanged@757036029':.
    //     0xd257bc: add             x1, PP, #0x99, lsl #12  ; [pp+0x99650] AnonymousClosure: (0xd25a74), in [package:flutter/src/material/ink_splash.dart] InkSplash::_handleAlphaStatusChanged (0xd25ab0)
    //     0xd257c0: ldr             x1, [x1, #0x650]
    // 0xd257c4: r0 = AllocateClosure()
    //     0xd257c4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd257c8: ldur            x1, [fp, #-0x28]
    // 0xd257cc: mov             x2, x0
    // 0xd257d0: r0 = addStatusListener()
    //     0xd257d0: bl              #0x1254cc0  ; [dart:mixin_deduplication] _MixinApplication456&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::addStatusListener
    // 0xd257d4: ldur            x0, [fp, #-0x28]
    // 0xd257d8: ldur            x2, [fp, #-8]
    // 0xd257dc: StoreField: r2->field_43 = r0
    //     0xd257dc: stur            w0, [x2, #0x43]
    //     0xd257e0: ldurb           w16, [x2, #-1]
    //     0xd257e4: ldurb           w17, [x0, #-1]
    //     0xd257e8: and             x16, x17, x16, lsr #2
    //     0xd257ec: tst             x16, HEAP, lsr #32
    //     0xd257f0: b.eq            #0xd257f8
    //     0xd257f4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd257f8: ldur            x1, [fp, #-0x10]
    // 0xd257fc: r0 = LoadClassIdInstr(r1)
    //     0xd257fc: ldur            x0, [x1, #-1]
    //     0xd25800: ubfx            x0, x0, #0xc, #0x14
    // 0xd25804: r0 = GDT[cid_x0 + -0xfc0]()
    //     0xd25804: sub             lr, x0, #0xfc0
    //     0xd25808: ldr             lr, [x21, lr, lsl #3]
    //     0xd2580c: blr             lr
    // 0xd25810: mov             x2, x0
    // 0xd25814: r0 = BoxInt64Instr(r2)
    //     0xd25814: sbfiz           x0, x2, #1, #0x1f
    //     0xd25818: cmp             x2, x0, asr #1
    //     0xd2581c: b.eq            #0xd25828
    //     0xd25820: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xd25824: stur            x2, [x0, #7]
    // 0xd25828: r1 = <int>
    //     0xd25828: ldr             x1, [PP, #0x50]  ; [pp+0x50] TypeArguments: <int>
    // 0xd2582c: stur            x0, [fp, #-0x10]
    // 0xd25830: r0 = IntTween()
    //     0xd25830: bl              #0xd21d54  ; AllocateIntTweenStub -> IntTween (size=0x14)
    // 0xd25834: mov             x1, x0
    // 0xd25838: ldur            x0, [fp, #-0x10]
    // 0xd2583c: StoreField: r1->field_b = r0
    //     0xd2583c: stur            w0, [x1, #0xb]
    // 0xd25840: StoreField: r1->field_f = rZR
    //     0xd25840: stur            wzr, [x1, #0xf]
    // 0xd25844: ldur            x2, [fp, #-0x28]
    // 0xd25848: r0 = animate()
    //     0xd25848: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xd2584c: ldur            x2, [fp, #-8]
    // 0xd25850: StoreField: r2->field_3f = r0
    //     0xd25850: stur            w0, [x2, #0x3f]
    //     0xd25854: ldurb           w16, [x2, #-1]
    //     0xd25858: ldurb           w17, [x0, #-1]
    //     0xd2585c: and             x16, x17, x16, lsr #2
    //     0xd25860: tst             x16, HEAP, lsr #32
    //     0xd25864: b.eq            #0xd2586c
    //     0xd25868: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd2586c: ldur            x1, [fp, #-0x20]
    // 0xd25870: r0 = addInkFeature()
    //     0xd25870: bl              #0xd21c40  ; [package:flutter/src/material/material.dart] _RenderInkFeatures::addInkFeature
    // 0xd25874: r0 = Null
    //     0xd25874: mov             x0, NULL
    // 0xd25878: LeaveFrame
    //     0xd25878: mov             SP, fp
    //     0xd2587c: ldp             fp, lr, [SP], #0x10
    // 0xd25880: ret
    //     0xd25880: ret             
    // 0xd25884: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd25884: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd25888: b               #0xd254ac
    // 0xd2588c: SaveReg d0
    //     0xd2588c: str             q0, [SP, #-0x10]!
    // 0xd25890: SaveReg r1
    //     0xd25890: str             x1, [SP, #-8]!
    // 0xd25894: r0 = AllocateDouble()
    //     0xd25894: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd25898: RestoreReg r1
    //     0xd25898: ldr             x1, [SP], #8
    // 0xd2589c: RestoreReg d0
    //     0xd2589c: ldr             q0, [SP], #0x10
    // 0xd258a0: b               #0xd25750
  }
  [closure] void _handleAlphaStatusChanged(dynamic, AnimationStatus) {
    // ** addr: 0xd25a74, size: 0x3c
    // 0xd25a74: EnterFrame
    //     0xd25a74: stp             fp, lr, [SP, #-0x10]!
    //     0xd25a78: mov             fp, SP
    // 0xd25a7c: ldr             x0, [fp, #0x18]
    // 0xd25a80: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd25a80: ldur            w1, [x0, #0x17]
    // 0xd25a84: DecompressPointer r1
    //     0xd25a84: add             x1, x1, HEAP, lsl #32
    // 0xd25a88: CheckStackOverflow
    //     0xd25a88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd25a8c: cmp             SP, x16
    //     0xd25a90: b.ls            #0xd25aa8
    // 0xd25a94: ldr             x2, [fp, #0x10]
    // 0xd25a98: r0 = _handleAlphaStatusChanged()
    //     0xd25a98: bl              #0xd25ab0  ; [package:flutter/src/material/ink_splash.dart] InkSplash::_handleAlphaStatusChanged
    // 0xd25a9c: LeaveFrame
    //     0xd25a9c: mov             SP, fp
    //     0xd25aa0: ldp             fp, lr, [SP], #0x10
    // 0xd25aa4: ret
    //     0xd25aa4: ret             
    // 0xd25aa8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd25aa8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd25aac: b               #0xd25a94
  }
  _ _handleAlphaStatusChanged(/* No info */) {
    // ** addr: 0xd25ab0, size: 0x3c
    // 0xd25ab0: EnterFrame
    //     0xd25ab0: stp             fp, lr, [SP, #-0x10]!
    //     0xd25ab4: mov             fp, SP
    // 0xd25ab8: CheckStackOverflow
    //     0xd25ab8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd25abc: cmp             SP, x16
    //     0xd25ac0: b.ls            #0xd25ae4
    // 0xd25ac4: r16 = Instance_AnimationStatus
    //     0xd25ac4: ldr             x16, [PP, #0x51a0]  ; [pp+0x51a0] Obj!AnimationStatus@12c61a1
    // 0xd25ac8: cmp             w2, w16
    // 0xd25acc: b.ne            #0xd25ad4
    // 0xd25ad0: r0 = dispose()
    //     0xd25ad0: bl              #0x119e928  ; [package:flutter/src/material/ink_splash.dart] InkSplash::dispose
    // 0xd25ad4: r0 = Null
    //     0xd25ad4: mov             x0, NULL
    // 0xd25ad8: LeaveFrame
    //     0xd25ad8: mov             SP, fp
    //     0xd25adc: ldp             fp, lr, [SP], #0x10
    // 0xd25ae0: ret
    //     0xd25ae0: ret             
    // 0xd25ae4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd25ae4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd25ae8: b               #0xd25ac4
  }
  _ dispose(/* No info */) {
    // ** addr: 0x119e928, size: 0x84
    // 0x119e928: EnterFrame
    //     0x119e928: stp             fp, lr, [SP, #-0x10]!
    //     0x119e92c: mov             fp, SP
    // 0x119e930: AllocStack(0x8)
    //     0x119e930: sub             SP, SP, #8
    // 0x119e934: SetupParameters(InkSplash this /* r1 => r0, fp-0x8 */)
    //     0x119e934: mov             x0, x1
    //     0x119e938: stur            x1, [fp, #-8]
    // 0x119e93c: CheckStackOverflow
    //     0x119e93c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x119e940: cmp             SP, x16
    //     0x119e944: b.ls            #0x119e994
    // 0x119e948: LoadField: r1 = r0->field_3b
    //     0x119e948: ldur            w1, [x0, #0x3b]
    // 0x119e94c: DecompressPointer r1
    //     0x119e94c: add             x1, x1, HEAP, lsl #32
    // 0x119e950: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x119e954: cmp             w1, w16
    // 0x119e958: b.eq            #0x119e99c
    // 0x119e95c: r0 = dispose()
    //     0x119e95c: bl              #0x9164f4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x119e960: ldur            x0, [fp, #-8]
    // 0x119e964: LoadField: r1 = r0->field_43
    //     0x119e964: ldur            w1, [x0, #0x43]
    // 0x119e968: DecompressPointer r1
    //     0x119e968: add             x1, x1, HEAP, lsl #32
    // 0x119e96c: cmp             w1, NULL
    // 0x119e970: b.eq            #0x119e9a8
    // 0x119e974: r0 = dispose()
    //     0x119e974: bl              #0x9164f4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x119e978: ldur            x1, [fp, #-8]
    // 0x119e97c: StoreField: r1->field_43 = rNULL
    //     0x119e97c: stur            NULL, [x1, #0x43]
    // 0x119e980: r0 = dispose()
    //     0x119e980: bl              #0xf786a8  ; [package:flutter/src/material/material.dart] InkFeature::dispose
    // 0x119e984: r0 = Null
    //     0x119e984: mov             x0, NULL
    // 0x119e988: LeaveFrame
    //     0x119e988: mov             SP, fp
    //     0x119e98c: ldp             fp, lr, [SP], #0x10
    // 0x119e990: ret
    //     0x119e990: ret             
    // 0x119e994: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x119e994: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x119e998: b               #0x119e948
    // 0x119e99c: r9 = _radiusController
    //     0x119e99c: add             x9, PP, #0x99, lsl #12  ; [pp+0x99548] Field <InkSplash._radiusController@757036029>: late (offset: 0x3c)
    //     0x119e9a0: ldr             x9, [x9, #0x548]
    // 0x119e9a4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x119e9a4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x119e9a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x119e9a8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ paintFeature(/* No info */) {
    // ** addr: 0x12dc050, size: 0x214
    // 0x12dc050: EnterFrame
    //     0x12dc050: stp             fp, lr, [SP, #-0x10]!
    //     0x12dc054: mov             fp, SP
    // 0x12dc058: AllocStack(0x48)
    //     0x12dc058: sub             SP, SP, #0x48
    // 0x12dc05c: SetupParameters(InkSplash this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x12dc05c: mov             x0, x2
    //     0x12dc060: stur            x1, [fp, #-8]
    //     0x12dc064: stur            x2, [fp, #-0x10]
    //     0x12dc068: stur            x3, [fp, #-0x18]
    // 0x12dc06c: CheckStackOverflow
    //     0x12dc06c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12dc070: cmp             SP, x16
    //     0x12dc074: b.ls            #0x12dc230
    // 0x12dc078: r16 = 136
    //     0x12dc078: mov             x16, #0x88
    // 0x12dc07c: stp             x16, NULL, [SP]
    // 0x12dc080: r0 = ByteData()
    //     0x12dc080: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0x12dc084: stur            x0, [fp, #-0x20]
    // 0x12dc088: r0 = Paint()
    //     0x12dc088: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x12dc08c: mov             x3, x0
    // 0x12dc090: ldur            x0, [fp, #-0x20]
    // 0x12dc094: stur            x3, [fp, #-0x28]
    // 0x12dc098: StoreField: r3->field_7 = r0
    //     0x12dc098: stur            w0, [x3, #7]
    // 0x12dc09c: ldur            x4, [fp, #-8]
    // 0x12dc0a0: LoadField: r5 = r4->field_13
    //     0x12dc0a0: ldur            w5, [x4, #0x13]
    // 0x12dc0a4: DecompressPointer r5
    //     0x12dc0a4: add             x5, x5, HEAP, lsl #32
    // 0x12dc0a8: stur            x5, [fp, #-0x20]
    // 0x12dc0ac: LoadField: r0 = r4->field_3f
    //     0x12dc0ac: ldur            w0, [x4, #0x3f]
    // 0x12dc0b0: DecompressPointer r0
    //     0x12dc0b0: add             x0, x0, HEAP, lsl #32
    // 0x12dc0b4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12dc0b8: cmp             w0, w16
    // 0x12dc0bc: b.eq            #0x12dc238
    // 0x12dc0c0: LoadField: r1 = r0->field_f
    //     0x12dc0c0: ldur            w1, [x0, #0xf]
    // 0x12dc0c4: DecompressPointer r1
    //     0x12dc0c4: add             x1, x1, HEAP, lsl #32
    // 0x12dc0c8: LoadField: r2 = r0->field_b
    //     0x12dc0c8: ldur            w2, [x0, #0xb]
    // 0x12dc0cc: DecompressPointer r2
    //     0x12dc0cc: add             x2, x2, HEAP, lsl #32
    // 0x12dc0d0: r0 = LoadClassIdInstr(r1)
    //     0x12dc0d0: ldur            x0, [x1, #-1]
    //     0x12dc0d4: ubfx            x0, x0, #0xc, #0x14
    // 0x12dc0d8: r0 = GDT[cid_x0 + 0x80ed]()
    //     0x12dc0d8: mov             x17, #0x80ed
    //     0x12dc0dc: add             lr, x0, x17
    //     0x12dc0e0: ldr             lr, [x21, lr, lsl #3]
    //     0x12dc0e4: blr             lr
    // 0x12dc0e8: r2 = LoadInt32Instr(r0)
    //     0x12dc0e8: sbfx            x2, x0, #1, #0x1f
    //     0x12dc0ec: tbz             w0, #0, #0x12dc0f4
    //     0x12dc0f0: ldur            x2, [x0, #7]
    // 0x12dc0f4: ldur            x1, [fp, #-0x20]
    // 0x12dc0f8: r0 = LoadClassIdInstr(r1)
    //     0x12dc0f8: ldur            x0, [x1, #-1]
    //     0x12dc0fc: ubfx            x0, x0, #0xc, #0x14
    // 0x12dc100: r0 = GDT[cid_x0 + -0xff4]()
    //     0x12dc100: sub             lr, x0, #0xff4
    //     0x12dc104: ldr             lr, [x21, lr, lsl #3]
    //     0x12dc108: blr             lr
    // 0x12dc10c: ldur            x1, [fp, #-0x28]
    // 0x12dc110: mov             x2, x0
    // 0x12dc114: r0 = color=()
    //     0x12dc114: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0x12dc118: ldur            x0, [fp, #-8]
    // 0x12dc11c: LoadField: r2 = r0->field_1b
    //     0x12dc11c: ldur            w2, [x0, #0x1b]
    // 0x12dc120: DecompressPointer r2
    //     0x12dc120: add             x2, x2, HEAP, lsl #32
    // 0x12dc124: stur            x2, [fp, #-0x20]
    // 0x12dc128: LoadField: r1 = r0->field_2f
    //     0x12dc128: ldur            w1, [x0, #0x2f]
    // 0x12dc12c: DecompressPointer r1
    //     0x12dc12c: add             x1, x1, HEAP, lsl #32
    // 0x12dc130: tbnz            w1, #4, #0x12dc18c
    // 0x12dc134: LoadField: r1 = r0->field_b
    //     0x12dc134: ldur            w1, [x0, #0xb]
    // 0x12dc138: DecompressPointer r1
    //     0x12dc138: add             x1, x1, HEAP, lsl #32
    // 0x12dc13c: r0 = size()
    //     0x12dc13c: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0x12dc140: mov             x1, x0
    // 0x12dc144: r0 = center()
    //     0x12dc144: bl              #0xaf9a1c  ; [dart:ui] Size::center
    // 0x12dc148: mov             x1, x0
    // 0x12dc14c: ldur            x0, [fp, #-8]
    // 0x12dc150: LoadField: r2 = r0->field_3b
    //     0x12dc150: ldur            w2, [x0, #0x3b]
    // 0x12dc154: DecompressPointer r2
    //     0x12dc154: add             x2, x2, HEAP, lsl #32
    // 0x12dc158: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12dc15c: cmp             w2, w16
    // 0x12dc160: b.eq            #0x12dc244
    // 0x12dc164: LoadField: r3 = r2->field_37
    //     0x12dc164: ldur            w3, [x2, #0x37]
    // 0x12dc168: DecompressPointer r3
    //     0x12dc168: add             x3, x3, HEAP, lsl #32
    // 0x12dc16c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12dc170: cmp             w3, w16
    // 0x12dc174: b.eq            #0x12dc250
    // 0x12dc178: mov             x2, x1
    // 0x12dc17c: ldur            x1, [fp, #-0x20]
    // 0x12dc180: r0 = lerp()
    //     0x12dc180: bl              #0xb6bc84  ; [dart:ui] Offset::lerp
    // 0x12dc184: mov             x5, x0
    // 0x12dc188: b               #0x12dc190
    // 0x12dc18c: ldur            x5, [fp, #-0x20]
    // 0x12dc190: ldur            x3, [fp, #-8]
    // 0x12dc194: stur            x5, [fp, #-0x30]
    // 0x12dc198: LoadField: r4 = r3->field_33
    //     0x12dc198: ldur            w4, [x3, #0x33]
    // 0x12dc19c: DecompressPointer r4
    //     0x12dc19c: add             x4, x4, HEAP, lsl #32
    // 0x12dc1a0: stur            x4, [fp, #-0x20]
    // 0x12dc1a4: LoadField: r0 = r3->field_37
    //     0x12dc1a4: ldur            w0, [x3, #0x37]
    // 0x12dc1a8: DecompressPointer r0
    //     0x12dc1a8: add             x0, x0, HEAP, lsl #32
    // 0x12dc1ac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12dc1b0: cmp             w0, w16
    // 0x12dc1b4: b.eq            #0x12dc258
    // 0x12dc1b8: LoadField: r1 = r0->field_f
    //     0x12dc1b8: ldur            w1, [x0, #0xf]
    // 0x12dc1bc: DecompressPointer r1
    //     0x12dc1bc: add             x1, x1, HEAP, lsl #32
    // 0x12dc1c0: LoadField: r2 = r0->field_b
    //     0x12dc1c0: ldur            w2, [x0, #0xb]
    // 0x12dc1c4: DecompressPointer r2
    //     0x12dc1c4: add             x2, x2, HEAP, lsl #32
    // 0x12dc1c8: r0 = LoadClassIdInstr(r1)
    //     0x12dc1c8: ldur            x0, [x1, #-1]
    //     0x12dc1cc: ubfx            x0, x0, #0xc, #0x14
    // 0x12dc1d0: r0 = GDT[cid_x0 + 0x80ed]()
    //     0x12dc1d0: mov             x17, #0x80ed
    //     0x12dc1d4: add             lr, x0, x17
    //     0x12dc1d8: ldr             lr, [x21, lr, lsl #3]
    //     0x12dc1dc: blr             lr
    // 0x12dc1e0: ldur            x1, [fp, #-8]
    // 0x12dc1e4: ArrayLoad: r7 = r1[0]  ; List_4
    //     0x12dc1e4: ldur            w7, [x1, #0x17]
    // 0x12dc1e8: DecompressPointer r7
    //     0x12dc1e8: add             x7, x7, HEAP, lsl #32
    // 0x12dc1ec: LoadField: r2 = r1->field_1f
    //     0x12dc1ec: ldur            w2, [x1, #0x1f]
    // 0x12dc1f0: DecompressPointer r2
    //     0x12dc1f0: add             x2, x2, HEAP, lsl #32
    // 0x12dc1f4: LoadField: r6 = r1->field_2b
    //     0x12dc1f4: ldur            w6, [x1, #0x2b]
    // 0x12dc1f8: DecompressPointer r6
    //     0x12dc1f8: add             x6, x6, HEAP, lsl #32
    // 0x12dc1fc: LoadField: d0 = r0->field_7
    //     0x12dc1fc: ldur            d0, [x0, #7]
    // 0x12dc200: ldur            x16, [fp, #-0x28]
    // 0x12dc204: ldur            lr, [fp, #-0x20]
    // 0x12dc208: stp             lr, x16, [SP, #8]
    // 0x12dc20c: ldur            x16, [fp, #-0x18]
    // 0x12dc210: str             x16, [SP]
    // 0x12dc214: ldur            x3, [fp, #-0x10]
    // 0x12dc218: ldur            x5, [fp, #-0x30]
    // 0x12dc21c: r0 = paintInkCircle()
    //     0x12dc21c: bl              #0x12dac04  ; [package:flutter/src/material/ink_well.dart] InteractiveInkFeature::paintInkCircle
    // 0x12dc220: r0 = Null
    //     0x12dc220: mov             x0, NULL
    // 0x12dc224: LeaveFrame
    //     0x12dc224: mov             SP, fp
    //     0x12dc228: ldp             fp, lr, [SP], #0x10
    // 0x12dc22c: ret
    //     0x12dc22c: ret             
    // 0x12dc230: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12dc230: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12dc234: b               #0x12dc078
    // 0x12dc238: r9 = _alpha
    //     0x12dc238: add             x9, PP, #0xab, lsl #12  ; [pp+0xab098] Field <InkSplash._alpha@757036029>: late (offset: 0x40)
    //     0x12dc23c: ldr             x9, [x9, #0x98]
    // 0x12dc240: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12dc240: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12dc244: r9 = _radiusController
    //     0x12dc244: add             x9, PP, #0x99, lsl #12  ; [pp+0x99548] Field <InkSplash._radiusController@757036029>: late (offset: 0x3c)
    //     0x12dc248: ldr             x9, [x9, #0x548]
    // 0x12dc24c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12dc24c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12dc250: r9 = _value
    //     0x12dc250: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0x12dc254: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12dc254: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12dc258: r9 = _radius
    //     0x12dc258: add             x9, PP, #0xab, lsl #12  ; [pp+0xab0a0] Field <InkSplash._radius@757036029>: late (offset: 0x38)
    //     0x12dc25c: ldr             x9, [x9, #0xa0]
    // 0x12dc260: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12dc260: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}
