// lib: , url: package:flutter/src/material/tooltip_visibility.dart

// class id: 1048974, size: 0x8
class :: {
}

// class id: 2962, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class TooltipVisibility extends Object {

  static _ of(/* No info */) {
    // ** addr: 0xeef17c, size: 0x44
    // 0xeef17c: EnterFrame
    //     0xeef17c: stp             fp, lr, [SP, #-0x10]!
    //     0xeef180: mov             fp, SP
    // 0xeef184: AllocStack(0x10)
    //     0xeef184: sub             SP, SP, #0x10
    // 0xeef188: CheckStackOverflow
    //     0xeef188: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeef18c: cmp             SP, x16
    //     0xeef190: b.ls            #0xeef1b8
    // 0xeef194: r16 = <_TooltipVisibilityScope>
    //     0xeef194: add             x16, PP, #0x98, lsl #12  ; [pp+0x98e30] TypeArguments: <_TooltipVisibilityScope>
    //     0xeef198: ldr             x16, [x16, #0xe30]
    // 0xeef19c: stp             x1, x16, [SP]
    // 0xeef1a0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xeef1a0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xeef1a4: r0 = dependOnInheritedWidgetOfExactType()
    //     0xeef1a4: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xeef1a8: r0 = true
    //     0xeef1a8: add             x0, NULL, #0x20  ; true
    // 0xeef1ac: LeaveFrame
    //     0xeef1ac: mov             SP, fp
    //     0xeef1b0: ldp             fp, lr, [SP], #0x10
    // 0xeef1b4: ret
    //     0xeef1b4: ret             
    // 0xeef1b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeef1b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeef1bc: b               #0xeef194
  }
}

// class id: 6806, size: 0x10, field offset: 0x10
//   const constructor, 
abstract class _TooltipVisibilityScope extends InheritedWidget {
}
