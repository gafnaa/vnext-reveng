// lib: , url: package:flutter/src/material/filled_button_theme.dart

// class id: 1048893, size: 0x8
class :: {
}

// class id: 5151, size: 0xc, field offset: 0x8
//   const constructor, 
class FilledButtonThemeData extends _MixinApplication3&Object&Diagnosticable {

  static _ lerp(/* No info */) {
    // ** addr: 0x116722c, size: 0x6c
    // 0x116722c: EnterFrame
    //     0x116722c: stp             fp, lr, [SP, #-0x10]!
    //     0x1167230: mov             fp, SP
    // 0x1167234: AllocStack(0x8)
    //     0x1167234: sub             SP, SP, #8
    // 0x1167238: SetupParameters(dynamic _ /* r1 => r0 */)
    //     0x1167238: mov             x0, x1
    // 0x116723c: CheckStackOverflow
    //     0x116723c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1167240: cmp             SP, x16
    //     0x1167244: b.ls            #0x1167290
    // 0x1167248: cmp             w0, w2
    // 0x116724c: b.ne            #0x116725c
    // 0x1167250: LeaveFrame
    //     0x1167250: mov             SP, fp
    //     0x1167254: ldp             fp, lr, [SP], #0x10
    // 0x1167258: ret
    //     0x1167258: ret             
    // 0x116725c: LoadField: r1 = r0->field_7
    //     0x116725c: ldur            w1, [x0, #7]
    // 0x1167260: DecompressPointer r1
    //     0x1167260: add             x1, x1, HEAP, lsl #32
    // 0x1167264: LoadField: r0 = r2->field_7
    //     0x1167264: ldur            w0, [x2, #7]
    // 0x1167268: DecompressPointer r0
    //     0x1167268: add             x0, x0, HEAP, lsl #32
    // 0x116726c: mov             x2, x0
    // 0x1167270: r0 = lerp()
    //     0x1167270: bl              #0x1164644  ; [package:flutter/src/material/button_style.dart] ButtonStyle::lerp
    // 0x1167274: stur            x0, [fp, #-8]
    // 0x1167278: r0 = FilledButtonThemeData()
    //     0x1167278: bl              #0x1167298  ; AllocateFilledButtonThemeDataStub -> FilledButtonThemeData (size=0xc)
    // 0x116727c: ldur            x1, [fp, #-8]
    // 0x1167280: StoreField: r0->field_7 = r1
    //     0x1167280: stur            w1, [x0, #7]
    // 0x1167284: LeaveFrame
    //     0x1167284: mov             SP, fp
    //     0x1167288: ldp             fp, lr, [SP], #0x10
    // 0x116728c: ret
    //     0x116728c: ret             
    // 0x1167290: r0 = StackOverflowSharedWithFPURegs()
    //     0x1167290: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1167294: b               #0x1167248
  }
  _ ==(/* No info */) {
    // ** addr: 0x126c73c, size: 0xfc
    // 0x126c73c: EnterFrame
    //     0x126c73c: stp             fp, lr, [SP, #-0x10]!
    //     0x126c740: mov             fp, SP
    // 0x126c744: AllocStack(0x10)
    //     0x126c744: sub             SP, SP, #0x10
    // 0x126c748: CheckStackOverflow
    //     0x126c748: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x126c74c: cmp             SP, x16
    //     0x126c750: b.ls            #0x126c830
    // 0x126c754: ldr             x0, [fp, #0x10]
    // 0x126c758: cmp             w0, NULL
    // 0x126c75c: b.ne            #0x126c770
    // 0x126c760: r0 = false
    //     0x126c760: add             x0, NULL, #0x30  ; false
    // 0x126c764: LeaveFrame
    //     0x126c764: mov             SP, fp
    //     0x126c768: ldp             fp, lr, [SP], #0x10
    // 0x126c76c: ret
    //     0x126c76c: ret             
    // 0x126c770: ldr             x1, [fp, #0x18]
    // 0x126c774: cmp             w1, w0
    // 0x126c778: b.ne            #0x126c78c
    // 0x126c77c: r0 = true
    //     0x126c77c: add             x0, NULL, #0x20  ; true
    // 0x126c780: LeaveFrame
    //     0x126c780: mov             SP, fp
    //     0x126c784: ldp             fp, lr, [SP], #0x10
    // 0x126c788: ret
    //     0x126c788: ret             
    // 0x126c78c: str             x0, [SP]
    // 0x126c790: r0 = runtimeType()
    //     0x126c790: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x126c794: r1 = LoadClassIdInstr(r0)
    //     0x126c794: ldur            x1, [x0, #-1]
    //     0x126c798: ubfx            x1, x1, #0xc, #0x14
    // 0x126c79c: r16 = FilledButtonThemeData
    //     0x126c79c: add             x16, PP, #0x26, lsl #12  ; [pp+0x26388] Type: FilledButtonThemeData
    //     0x126c7a0: ldr             x16, [x16, #0x388]
    // 0x126c7a4: stp             x16, x0, [SP]
    // 0x126c7a8: mov             x0, x1
    // 0x126c7ac: mov             lr, x0
    // 0x126c7b0: ldr             lr, [x21, lr, lsl #3]
    // 0x126c7b4: blr             lr
    // 0x126c7b8: tbz             w0, #4, #0x126c7cc
    // 0x126c7bc: r0 = false
    //     0x126c7bc: add             x0, NULL, #0x30  ; false
    // 0x126c7c0: LeaveFrame
    //     0x126c7c0: mov             SP, fp
    //     0x126c7c4: ldp             fp, lr, [SP], #0x10
    // 0x126c7c8: ret
    //     0x126c7c8: ret             
    // 0x126c7cc: ldr             x0, [fp, #0x10]
    // 0x126c7d0: r1 = 60
    //     0x126c7d0: mov             x1, #0x3c
    // 0x126c7d4: branchIfSmi(r0, 0x126c7e0)
    //     0x126c7d4: tbz             w0, #0, #0x126c7e0
    // 0x126c7d8: r1 = LoadClassIdInstr(r0)
    //     0x126c7d8: ldur            x1, [x0, #-1]
    //     0x126c7dc: ubfx            x1, x1, #0xc, #0x14
    // 0x126c7e0: r17 = 5151
    //     0x126c7e0: mov             x17, #0x141f
    // 0x126c7e4: cmp             x1, x17
    // 0x126c7e8: b.ne            #0x126c820
    // 0x126c7ec: ldr             x1, [fp, #0x18]
    // 0x126c7f0: LoadField: r2 = r0->field_7
    //     0x126c7f0: ldur            w2, [x0, #7]
    // 0x126c7f4: DecompressPointer r2
    //     0x126c7f4: add             x2, x2, HEAP, lsl #32
    // 0x126c7f8: LoadField: r0 = r1->field_7
    //     0x126c7f8: ldur            w0, [x1, #7]
    // 0x126c7fc: DecompressPointer r0
    //     0x126c7fc: add             x0, x0, HEAP, lsl #32
    // 0x126c800: r1 = LoadClassIdInstr(r2)
    //     0x126c800: ldur            x1, [x2, #-1]
    //     0x126c804: ubfx            x1, x1, #0xc, #0x14
    // 0x126c808: stp             x0, x2, [SP]
    // 0x126c80c: mov             x0, x1
    // 0x126c810: mov             lr, x0
    // 0x126c814: ldr             lr, [x21, lr, lsl #3]
    // 0x126c818: blr             lr
    // 0x126c81c: b               #0x126c824
    // 0x126c820: r0 = false
    //     0x126c820: add             x0, NULL, #0x30  ; false
    // 0x126c824: LeaveFrame
    //     0x126c824: mov             SP, fp
    //     0x126c828: ldp             fp, lr, [SP], #0x10
    // 0x126c82c: ret
    //     0x126c82c: ret             
    // 0x126c830: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x126c830: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x126c834: b               #0x126c754
  }
}
