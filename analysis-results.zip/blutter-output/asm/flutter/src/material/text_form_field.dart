// lib: , url: package:flutter/src/material/text_form_field.dart

// class id: 1048962, size: 0x8
class :: {
}

// class id: 5758, size: 0x3c, field offset: 0x34
class _TextFormFieldState extends FormFieldState<dynamic> {

  get _ _effectiveController(/* No info */) {
    // ** addr: 0xd90f68, size: 0x70
    // 0xd90f68: EnterFrame
    //     0xd90f68: stp             fp, lr, [SP, #-0x10]!
    //     0xd90f6c: mov             fp, SP
    // 0xd90f70: AllocStack(0x8)
    //     0xd90f70: sub             SP, SP, #8
    // 0xd90f74: LoadField: r3 = r1->field_b
    //     0xd90f74: ldur            w3, [x1, #0xb]
    // 0xd90f78: DecompressPointer r3
    //     0xd90f78: add             x3, x3, HEAP, lsl #32
    // 0xd90f7c: stur            x3, [fp, #-8]
    // 0xd90f80: cmp             w3, NULL
    // 0xd90f84: b.eq            #0xd90fd4
    // 0xd90f88: mov             x0, x3
    // 0xd90f8c: r2 = Null
    //     0xd90f8c: mov             x2, NULL
    // 0xd90f90: r1 = Null
    //     0xd90f90: mov             x1, NULL
    // 0xd90f94: r4 = LoadClassIdInstr(r0)
    //     0xd90f94: ldur            x4, [x0, #-1]
    //     0xd90f98: ubfx            x4, x4, #0xc, #0x14
    // 0xd90f9c: r17 = 6478
    //     0xd90f9c: mov             x17, #0x194e
    // 0xd90fa0: cmp             x4, x17
    // 0xd90fa4: b.eq            #0xd90fbc
    // 0xd90fa8: r8 = TextFormField
    //     0xd90fa8: add             x8, PP, #0x1a, lsl #12  ; [pp+0x1a8b0] Type: TextFormField
    //     0xd90fac: ldr             x8, [x8, #0x8b0]
    // 0xd90fb0: r3 = Null
    //     0xd90fb0: add             x3, PP, #0x1a, lsl #12  ; [pp+0x1a908] Null
    //     0xd90fb4: ldr             x3, [x3, #0x908]
    // 0xd90fb8: r0 = DefaultTypeTest()
    //     0xd90fb8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xd90fbc: ldur            x1, [fp, #-8]
    // 0xd90fc0: LoadField: r0 = r1->field_2f
    //     0xd90fc0: ldur            w0, [x1, #0x2f]
    // 0xd90fc4: DecompressPointer r0
    //     0xd90fc4: add             x0, x0, HEAP, lsl #32
    // 0xd90fc8: LeaveFrame
    //     0xd90fc8: mov             SP, fp
    //     0xd90fcc: ldp             fp, lr, [SP], #0x10
    // 0xd90fd0: ret
    //     0xd90fd0: ret             
    // 0xd90fd4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd90fd4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _textFormField(/* No info */) {
    // ** addr: 0xd90fd8, size: 0x68
    // 0xd90fd8: EnterFrame
    //     0xd90fd8: stp             fp, lr, [SP, #-0x10]!
    //     0xd90fdc: mov             fp, SP
    // 0xd90fe0: AllocStack(0x8)
    //     0xd90fe0: sub             SP, SP, #8
    // 0xd90fe4: LoadField: r3 = r1->field_b
    //     0xd90fe4: ldur            w3, [x1, #0xb]
    // 0xd90fe8: DecompressPointer r3
    //     0xd90fe8: add             x3, x3, HEAP, lsl #32
    // 0xd90fec: stur            x3, [fp, #-8]
    // 0xd90ff0: cmp             w3, NULL
    // 0xd90ff4: b.eq            #0xd9103c
    // 0xd90ff8: mov             x0, x3
    // 0xd90ffc: r2 = Null
    //     0xd90ffc: mov             x2, NULL
    // 0xd91000: r1 = Null
    //     0xd91000: mov             x1, NULL
    // 0xd91004: r4 = LoadClassIdInstr(r0)
    //     0xd91004: ldur            x4, [x0, #-1]
    //     0xd91008: ubfx            x4, x4, #0xc, #0x14
    // 0xd9100c: r17 = 6478
    //     0xd9100c: mov             x17, #0x194e
    // 0xd91010: cmp             x4, x17
    // 0xd91014: b.eq            #0xd9102c
    // 0xd91018: r8 = TextFormField
    //     0xd91018: add             x8, PP, #0x1a, lsl #12  ; [pp+0x1a8b0] Type: TextFormField
    //     0xd9101c: ldr             x8, [x8, #0x8b0]
    // 0xd91020: r3 = Null
    //     0xd91020: add             x3, PP, #0x1a, lsl #12  ; [pp+0x1a8c8] Null
    //     0xd91024: ldr             x3, [x3, #0x8c8]
    // 0xd91028: r0 = DefaultTypeTest()
    //     0xd91028: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xd9102c: ldur            x0, [fp, #-8]
    // 0xd91030: LeaveFrame
    //     0xd91030: mov             SP, fp
    //     0xd91034: ldp             fp, lr, [SP], #0x10
    // 0xd91038: ret
    //     0xd91038: ret             
    // 0xd9103c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd9103c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didChange(/* No info */) {
    // ** addr: 0xd93be8, size: 0x120
    // 0xd93be8: EnterFrame
    //     0xd93be8: stp             fp, lr, [SP, #-0x10]!
    //     0xd93bec: mov             fp, SP
    // 0xd93bf0: AllocStack(0x28)
    //     0xd93bf0: sub             SP, SP, #0x28
    // 0xd93bf4: SetupParameters(_TextFormFieldState this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xd93bf4: mov             x3, x1
    //     0xd93bf8: mov             x0, x2
    //     0xd93bfc: stur            x1, [fp, #-8]
    //     0xd93c00: stur            x2, [fp, #-0x10]
    // 0xd93c04: CheckStackOverflow
    //     0xd93c04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd93c08: cmp             SP, x16
    //     0xd93c0c: b.ls            #0xd93cfc
    // 0xd93c10: mov             x1, x3
    // 0xd93c14: mov             x2, x0
    // 0xd93c18: r0 = didChange()
    //     0xd93c18: bl              #0xd93d08  ; [package:flutter/src/widgets/form.dart] FormFieldState::didChange
    // 0xd93c1c: ldur            x3, [fp, #-8]
    // 0xd93c20: LoadField: r4 = r3->field_b
    //     0xd93c20: ldur            w4, [x3, #0xb]
    // 0xd93c24: DecompressPointer r4
    //     0xd93c24: add             x4, x4, HEAP, lsl #32
    // 0xd93c28: stur            x4, [fp, #-0x18]
    // 0xd93c2c: cmp             w4, NULL
    // 0xd93c30: b.eq            #0xd93d04
    // 0xd93c34: mov             x0, x4
    // 0xd93c38: r2 = Null
    //     0xd93c38: mov             x2, NULL
    // 0xd93c3c: r1 = Null
    //     0xd93c3c: mov             x1, NULL
    // 0xd93c40: r4 = LoadClassIdInstr(r0)
    //     0xd93c40: ldur            x4, [x0, #-1]
    //     0xd93c44: ubfx            x4, x4, #0xc, #0x14
    // 0xd93c48: r17 = 6478
    //     0xd93c48: mov             x17, #0x194e
    // 0xd93c4c: cmp             x4, x17
    // 0xd93c50: b.eq            #0xd93c68
    // 0xd93c54: r8 = TextFormField
    //     0xd93c54: add             x8, PP, #0x1a, lsl #12  ; [pp+0x1a8b0] Type: TextFormField
    //     0xd93c58: ldr             x8, [x8, #0x8b0]
    // 0xd93c5c: r3 = Null
    //     0xd93c5c: add             x3, PP, #0x1a, lsl #12  ; [pp+0x1a8b8] Null
    //     0xd93c60: ldr             x3, [x3, #0x8b8]
    // 0xd93c64: r0 = DefaultTypeTest()
    //     0xd93c64: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xd93c68: ldur            x0, [fp, #-0x18]
    // 0xd93c6c: LoadField: r1 = r0->field_2f
    //     0xd93c6c: ldur            w1, [x0, #0x2f]
    // 0xd93c70: DecompressPointer r1
    //     0xd93c70: add             x1, x1, HEAP, lsl #32
    // 0xd93c74: LoadField: r0 = r1->field_27
    //     0xd93c74: ldur            w0, [x1, #0x27]
    // 0xd93c78: DecompressPointer r0
    //     0xd93c78: add             x0, x0, HEAP, lsl #32
    // 0xd93c7c: LoadField: r1 = r0->field_7
    //     0xd93c7c: ldur            w1, [x0, #7]
    // 0xd93c80: DecompressPointer r1
    //     0xd93c80: add             x1, x1, HEAP, lsl #32
    // 0xd93c84: r0 = LoadClassIdInstr(r1)
    //     0xd93c84: ldur            x0, [x1, #-1]
    //     0xd93c88: ubfx            x0, x0, #0xc, #0x14
    // 0xd93c8c: ldur            x16, [fp, #-0x10]
    // 0xd93c90: stp             x16, x1, [SP]
    // 0xd93c94: mov             lr, x0
    // 0xd93c98: ldr             lr, [x21, lr, lsl #3]
    // 0xd93c9c: blr             lr
    // 0xd93ca0: tbz             w0, #4, #0xd93cec
    // 0xd93ca4: ldur            x0, [fp, #-0x10]
    // 0xd93ca8: ldur            x1, [fp, #-8]
    // 0xd93cac: r0 = _textFormField()
    //     0xd93cac: bl              #0xd90fd8  ; [package:flutter/src/material/text_form_field.dart] _TextFormFieldState::_textFormField
    // 0xd93cb0: LoadField: r1 = r0->field_2f
    //     0xd93cb0: ldur            w1, [x0, #0x2f]
    // 0xd93cb4: DecompressPointer r1
    //     0xd93cb4: add             x1, x1, HEAP, lsl #32
    // 0xd93cb8: stur            x1, [fp, #-8]
    // 0xd93cbc: r0 = TextEditingValue()
    //     0xd93cbc: bl              #0x86e1d4  ; AllocateTextEditingValueStub -> TextEditingValue (size=0x14)
    // 0xd93cc0: mov             x1, x0
    // 0xd93cc4: ldur            x0, [fp, #-0x10]
    // 0xd93cc8: StoreField: r1->field_7 = r0
    //     0xd93cc8: stur            w0, [x1, #7]
    // 0xd93ccc: r0 = Instance_TextSelection
    //     0xd93ccc: add             x0, PP, #0x14, lsl #12  ; [pp+0x14b30] Obj!TextSelection@12a0491
    //     0xd93cd0: ldr             x0, [x0, #0xb30]
    // 0xd93cd4: StoreField: r1->field_b = r0
    //     0xd93cd4: stur            w0, [x1, #0xb]
    // 0xd93cd8: r0 = Instance_TextRange
    //     0xd93cd8: ldr             x0, [PP, #0x53d8]  ; [pp+0x53d8] Obj!TextRange@12a0471
    // 0xd93cdc: StoreField: r1->field_f = r0
    //     0xd93cdc: stur            w0, [x1, #0xf]
    // 0xd93ce0: mov             x2, x1
    // 0xd93ce4: ldur            x1, [fp, #-8]
    // 0xd93ce8: r0 = value=()
    //     0xd93ce8: bl              #0xb68ce8  ; [package:flutter/src/foundation/change_notifier.dart] ValueNotifier::value=
    // 0xd93cec: r0 = Null
    //     0xd93cec: mov             x0, NULL
    // 0xd93cf0: LeaveFrame
    //     0xd93cf0: mov             SP, fp
    //     0xd93cf4: ldp             fp, lr, [SP], #0x10
    // 0xd93cf8: ret
    //     0xd93cf8: ret             
    // 0xd93cfc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd93cfc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd93d00: b               #0xd93c10
    // 0xd93d04: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd93d04: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf38630, size: 0x210
    // 0xf38630: EnterFrame
    //     0xf38630: stp             fp, lr, [SP, #-0x10]!
    //     0xf38634: mov             fp, SP
    // 0xf38638: AllocStack(0x18)
    //     0xf38638: sub             SP, SP, #0x18
    // 0xf3863c: SetupParameters(_TextFormFieldState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xf3863c: mov             x4, x1
    //     0xf38640: mov             x3, x2
    //     0xf38644: stur            x1, [fp, #-8]
    //     0xf38648: stur            x2, [fp, #-0x10]
    // 0xf3864c: CheckStackOverflow
    //     0xf3864c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf38650: cmp             SP, x16
    //     0xf38654: b.ls            #0xf3882c
    // 0xf38658: mov             x0, x3
    // 0xf3865c: r2 = Null
    //     0xf3865c: mov             x2, NULL
    // 0xf38660: r1 = Null
    //     0xf38660: mov             x1, NULL
    // 0xf38664: r4 = 60
    //     0xf38664: mov             x4, #0x3c
    // 0xf38668: branchIfSmi(r0, 0xf38674)
    //     0xf38668: tbz             w0, #0, #0xf38674
    // 0xf3866c: r4 = LoadClassIdInstr(r0)
    //     0xf3866c: ldur            x4, [x0, #-1]
    //     0xf38670: ubfx            x4, x4, #0xc, #0x14
    // 0xf38674: r17 = 6478
    //     0xf38674: mov             x17, #0x194e
    // 0xf38678: cmp             x4, x17
    // 0xf3867c: b.eq            #0xf38694
    // 0xf38680: r8 = TextFormField
    //     0xf38680: add             x8, PP, #0x1a, lsl #12  ; [pp+0x1a8b0] Type: TextFormField
    //     0xf38684: ldr             x8, [x8, #0x8b0]
    // 0xf38688: r3 = Null
    //     0xf38688: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8cb98] Null
    //     0xf3868c: ldr             x3, [x3, #0xb98]
    // 0xf38690: r0 = DefaultTypeTest()
    //     0xf38690: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xf38694: ldur            x1, [fp, #-8]
    // 0xf38698: ldur            x2, [fp, #-0x10]
    // 0xf3869c: r0 = didUpdateWidget()
    //     0xf3869c: bl              #0xf384f8  ; [package:flutter/src/widgets/form.dart] FormFieldState::didUpdateWidget
    // 0xf386a0: ldur            x3, [fp, #-8]
    // 0xf386a4: LoadField: r4 = r3->field_b
    //     0xf386a4: ldur            w4, [x3, #0xb]
    // 0xf386a8: DecompressPointer r4
    //     0xf386a8: add             x4, x4, HEAP, lsl #32
    // 0xf386ac: stur            x4, [fp, #-0x18]
    // 0xf386b0: cmp             w4, NULL
    // 0xf386b4: b.eq            #0xf38834
    // 0xf386b8: mov             x0, x4
    // 0xf386bc: r2 = Null
    //     0xf386bc: mov             x2, NULL
    // 0xf386c0: r1 = Null
    //     0xf386c0: mov             x1, NULL
    // 0xf386c4: r4 = LoadClassIdInstr(r0)
    //     0xf386c4: ldur            x4, [x0, #-1]
    //     0xf386c8: ubfx            x4, x4, #0xc, #0x14
    // 0xf386cc: r17 = 6478
    //     0xf386cc: mov             x17, #0x194e
    // 0xf386d0: cmp             x4, x17
    // 0xf386d4: b.eq            #0xf386ec
    // 0xf386d8: r8 = TextFormField
    //     0xf386d8: add             x8, PP, #0x1a, lsl #12  ; [pp+0x1a8b0] Type: TextFormField
    //     0xf386dc: ldr             x8, [x8, #0x8b0]
    // 0xf386e0: r3 = Null
    //     0xf386e0: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8cba8] Null
    //     0xf386e4: ldr             x3, [x3, #0xba8]
    // 0xf386e8: r0 = DefaultTypeTest()
    //     0xf386e8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xf386ec: ldur            x0, [fp, #-0x18]
    // 0xf386f0: LoadField: r1 = r0->field_2f
    //     0xf386f0: ldur            w1, [x0, #0x2f]
    // 0xf386f4: DecompressPointer r1
    //     0xf386f4: add             x1, x1, HEAP, lsl #32
    // 0xf386f8: ldur            x0, [fp, #-0x10]
    // 0xf386fc: LoadField: r3 = r0->field_2f
    //     0xf386fc: ldur            w3, [x0, #0x2f]
    // 0xf38700: DecompressPointer r3
    //     0xf38700: add             x3, x3, HEAP, lsl #32
    // 0xf38704: stur            x3, [fp, #-0x18]
    // 0xf38708: cmp             w1, w3
    // 0xf3870c: b.eq            #0xf3881c
    // 0xf38710: ldur            x0, [fp, #-8]
    // 0xf38714: mov             x2, x0
    // 0xf38718: r1 = Function '_handleControllerChanged@665147271':.
    //     0xf38718: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8cb70] AnonymousClosure: (0xf38840), in [package:flutter/src/material/text_form_field.dart] _TextFormFieldState::_handleControllerChanged (0xf38878)
    //     0xf3871c: ldr             x1, [x1, #0xb70]
    // 0xf38720: r0 = AllocateClosure()
    //     0xf38720: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf38724: ldur            x1, [fp, #-0x18]
    // 0xf38728: mov             x2, x0
    // 0xf3872c: stur            x0, [fp, #-0x10]
    // 0xf38730: r0 = removeListener()
    //     0xf38730: bl              #0xcff968  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xf38734: ldur            x3, [fp, #-8]
    // 0xf38738: LoadField: r4 = r3->field_b
    //     0xf38738: ldur            w4, [x3, #0xb]
    // 0xf3873c: DecompressPointer r4
    //     0xf3873c: add             x4, x4, HEAP, lsl #32
    // 0xf38740: stur            x4, [fp, #-0x18]
    // 0xf38744: cmp             w4, NULL
    // 0xf38748: b.eq            #0xf38838
    // 0xf3874c: mov             x0, x4
    // 0xf38750: r2 = Null
    //     0xf38750: mov             x2, NULL
    // 0xf38754: r1 = Null
    //     0xf38754: mov             x1, NULL
    // 0xf38758: r4 = LoadClassIdInstr(r0)
    //     0xf38758: ldur            x4, [x0, #-1]
    //     0xf3875c: ubfx            x4, x4, #0xc, #0x14
    // 0xf38760: r17 = 6478
    //     0xf38760: mov             x17, #0x194e
    // 0xf38764: cmp             x4, x17
    // 0xf38768: b.eq            #0xf38780
    // 0xf3876c: r8 = TextFormField
    //     0xf3876c: add             x8, PP, #0x1a, lsl #12  ; [pp+0x1a8b0] Type: TextFormField
    //     0xf38770: ldr             x8, [x8, #0x8b0]
    // 0xf38774: r3 = Null
    //     0xf38774: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8cbb8] Null
    //     0xf38778: ldr             x3, [x3, #0xbb8]
    // 0xf3877c: r0 = DefaultTypeTest()
    //     0xf3877c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xf38780: ldur            x0, [fp, #-0x18]
    // 0xf38784: LoadField: r1 = r0->field_2f
    //     0xf38784: ldur            w1, [x0, #0x2f]
    // 0xf38788: DecompressPointer r1
    //     0xf38788: add             x1, x1, HEAP, lsl #32
    // 0xf3878c: ldur            x2, [fp, #-0x10]
    // 0xf38790: r0 = addListener()
    //     0xf38790: bl              #0xd038e0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0xf38794: ldur            x3, [fp, #-8]
    // 0xf38798: LoadField: r4 = r3->field_b
    //     0xf38798: ldur            w4, [x3, #0xb]
    // 0xf3879c: DecompressPointer r4
    //     0xf3879c: add             x4, x4, HEAP, lsl #32
    // 0xf387a0: stur            x4, [fp, #-0x10]
    // 0xf387a4: cmp             w4, NULL
    // 0xf387a8: b.eq            #0xf3883c
    // 0xf387ac: mov             x0, x4
    // 0xf387b0: r2 = Null
    //     0xf387b0: mov             x2, NULL
    // 0xf387b4: r1 = Null
    //     0xf387b4: mov             x1, NULL
    // 0xf387b8: r4 = LoadClassIdInstr(r0)
    //     0xf387b8: ldur            x4, [x0, #-1]
    //     0xf387bc: ubfx            x4, x4, #0xc, #0x14
    // 0xf387c0: r17 = 6478
    //     0xf387c0: mov             x17, #0x194e
    // 0xf387c4: cmp             x4, x17
    // 0xf387c8: b.eq            #0xf387e0
    // 0xf387cc: r8 = TextFormField
    //     0xf387cc: add             x8, PP, #0x1a, lsl #12  ; [pp+0x1a8b0] Type: TextFormField
    //     0xf387d0: ldr             x8, [x8, #0x8b0]
    // 0xf387d4: r3 = Null
    //     0xf387d4: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8cbc8] Null
    //     0xf387d8: ldr             x3, [x3, #0xbc8]
    // 0xf387dc: r0 = DefaultTypeTest()
    //     0xf387dc: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xf387e0: ldur            x1, [fp, #-0x10]
    // 0xf387e4: LoadField: r2 = r1->field_2f
    //     0xf387e4: ldur            w2, [x1, #0x2f]
    // 0xf387e8: DecompressPointer r2
    //     0xf387e8: add             x2, x2, HEAP, lsl #32
    // 0xf387ec: LoadField: r1 = r2->field_27
    //     0xf387ec: ldur            w1, [x2, #0x27]
    // 0xf387f0: DecompressPointer r1
    //     0xf387f0: add             x1, x1, HEAP, lsl #32
    // 0xf387f4: LoadField: r0 = r1->field_7
    //     0xf387f4: ldur            w0, [x1, #7]
    // 0xf387f8: DecompressPointer r0
    //     0xf387f8: add             x0, x0, HEAP, lsl #32
    // 0xf387fc: ldur            x1, [fp, #-8]
    // 0xf38800: StoreField: r1->field_23 = r0
    //     0xf38800: stur            w0, [x1, #0x23]
    //     0xf38804: ldurb           w16, [x1, #-1]
    //     0xf38808: ldurb           w17, [x0, #-1]
    //     0xf3880c: and             x16, x17, x16, lsr #2
    //     0xf38810: tst             x16, HEAP, lsr #32
    //     0xf38814: b.eq            #0xf3881c
    //     0xf38818: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf3881c: r0 = Null
    //     0xf3881c: mov             x0, NULL
    // 0xf38820: LeaveFrame
    //     0xf38820: mov             SP, fp
    //     0xf38824: ldp             fp, lr, [SP], #0x10
    // 0xf38828: ret
    //     0xf38828: ret             
    // 0xf3882c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3882c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf38830: b               #0xf38658
    // 0xf38834: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf38834: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf38838: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf38838: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3883c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3883c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleControllerChanged(dynamic) {
    // ** addr: 0xf38840, size: 0x38
    // 0xf38840: EnterFrame
    //     0xf38840: stp             fp, lr, [SP, #-0x10]!
    //     0xf38844: mov             fp, SP
    // 0xf38848: ldr             x0, [fp, #0x10]
    // 0xf3884c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf3884c: ldur            w1, [x0, #0x17]
    // 0xf38850: DecompressPointer r1
    //     0xf38850: add             x1, x1, HEAP, lsl #32
    // 0xf38854: CheckStackOverflow
    //     0xf38854: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf38858: cmp             SP, x16
    //     0xf3885c: b.ls            #0xf38870
    // 0xf38860: r0 = _handleControllerChanged()
    //     0xf38860: bl              #0xf38878  ; [package:flutter/src/material/text_form_field.dart] _TextFormFieldState::_handleControllerChanged
    // 0xf38864: LeaveFrame
    //     0xf38864: mov             SP, fp
    //     0xf38868: ldp             fp, lr, [SP], #0x10
    // 0xf3886c: ret
    //     0xf3886c: ret             
    // 0xf38870: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf38870: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf38874: b               #0xf38860
  }
  _ _handleControllerChanged(/* No info */) {
    // ** addr: 0xf38878, size: 0x164
    // 0xf38878: EnterFrame
    //     0xf38878: stp             fp, lr, [SP, #-0x10]!
    //     0xf3887c: mov             fp, SP
    // 0xf38880: AllocStack(0x20)
    //     0xf38880: sub             SP, SP, #0x20
    // 0xf38884: SetupParameters(_TextFormFieldState this /* r1 => r3, fp-0x10 */)
    //     0xf38884: mov             x3, x1
    //     0xf38888: stur            x1, [fp, #-0x10]
    // 0xf3888c: CheckStackOverflow
    //     0xf3888c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf38890: cmp             SP, x16
    //     0xf38894: b.ls            #0xf389cc
    // 0xf38898: LoadField: r4 = r3->field_b
    //     0xf38898: ldur            w4, [x3, #0xb]
    // 0xf3889c: DecompressPointer r4
    //     0xf3889c: add             x4, x4, HEAP, lsl #32
    // 0xf388a0: stur            x4, [fp, #-8]
    // 0xf388a4: cmp             w4, NULL
    // 0xf388a8: b.eq            #0xf389d4
    // 0xf388ac: mov             x0, x4
    // 0xf388b0: r2 = Null
    //     0xf388b0: mov             x2, NULL
    // 0xf388b4: r1 = Null
    //     0xf388b4: mov             x1, NULL
    // 0xf388b8: r4 = LoadClassIdInstr(r0)
    //     0xf388b8: ldur            x4, [x0, #-1]
    //     0xf388bc: ubfx            x4, x4, #0xc, #0x14
    // 0xf388c0: r17 = 6478
    //     0xf388c0: mov             x17, #0x194e
    // 0xf388c4: cmp             x4, x17
    // 0xf388c8: b.eq            #0xf388e0
    // 0xf388cc: r8 = TextFormField
    //     0xf388cc: add             x8, PP, #0x1a, lsl #12  ; [pp+0x1a8b0] Type: TextFormField
    //     0xf388d0: ldr             x8, [x8, #0x8b0]
    // 0xf388d4: r3 = Null
    //     0xf388d4: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8cb78] Null
    //     0xf388d8: ldr             x3, [x3, #0xb78]
    // 0xf388dc: r0 = DefaultTypeTest()
    //     0xf388dc: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xf388e0: ldur            x0, [fp, #-8]
    // 0xf388e4: LoadField: r1 = r0->field_2f
    //     0xf388e4: ldur            w1, [x0, #0x2f]
    // 0xf388e8: DecompressPointer r1
    //     0xf388e8: add             x1, x1, HEAP, lsl #32
    // 0xf388ec: LoadField: r0 = r1->field_27
    //     0xf388ec: ldur            w0, [x1, #0x27]
    // 0xf388f0: DecompressPointer r0
    //     0xf388f0: add             x0, x0, HEAP, lsl #32
    // 0xf388f4: LoadField: r2 = r0->field_7
    //     0xf388f4: ldur            w2, [x0, #7]
    // 0xf388f8: DecompressPointer r2
    //     0xf388f8: add             x2, x2, HEAP, lsl #32
    // 0xf388fc: ldur            x1, [fp, #-0x10]
    // 0xf38900: stur            x2, [fp, #-8]
    // 0xf38904: LoadField: r0 = r1->field_23
    //     0xf38904: ldur            w0, [x1, #0x23]
    // 0xf38908: DecompressPointer r0
    //     0xf38908: add             x0, x0, HEAP, lsl #32
    // 0xf3890c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf38910: cmp             w0, w16
    // 0xf38914: b.ne            #0xf38924
    // 0xf38918: r2 = _value
    //     0xf38918: add             x2, PP, #0x1c, lsl #12  ; [pp+0x1cc48] Field <FormFieldState._value@87032539>: late (offset: 0x24)
    //     0xf3891c: ldr             x2, [x2, #0xc48]
    // 0xf38920: r0 = InitLateInstanceField()
    //     0xf38920: bl              #0x13dd948  ; InitLateInstanceFieldStub
    // 0xf38924: mov             x1, x0
    // 0xf38928: ldur            x0, [fp, #-8]
    // 0xf3892c: r2 = LoadClassIdInstr(r0)
    //     0xf3892c: ldur            x2, [x0, #-1]
    //     0xf38930: ubfx            x2, x2, #0xc, #0x14
    // 0xf38934: stp             x1, x0, [SP]
    // 0xf38938: mov             x0, x2
    // 0xf3893c: mov             lr, x0
    // 0xf38940: ldr             lr, [x21, lr, lsl #3]
    // 0xf38944: blr             lr
    // 0xf38948: tbz             w0, #4, #0xf389bc
    // 0xf3894c: ldur            x3, [fp, #-0x10]
    // 0xf38950: LoadField: r4 = r3->field_b
    //     0xf38950: ldur            w4, [x3, #0xb]
    // 0xf38954: DecompressPointer r4
    //     0xf38954: add             x4, x4, HEAP, lsl #32
    // 0xf38958: stur            x4, [fp, #-8]
    // 0xf3895c: cmp             w4, NULL
    // 0xf38960: b.eq            #0xf389d8
    // 0xf38964: mov             x0, x4
    // 0xf38968: r2 = Null
    //     0xf38968: mov             x2, NULL
    // 0xf3896c: r1 = Null
    //     0xf3896c: mov             x1, NULL
    // 0xf38970: r4 = LoadClassIdInstr(r0)
    //     0xf38970: ldur            x4, [x0, #-1]
    //     0xf38974: ubfx            x4, x4, #0xc, #0x14
    // 0xf38978: r17 = 6478
    //     0xf38978: mov             x17, #0x194e
    // 0xf3897c: cmp             x4, x17
    // 0xf38980: b.eq            #0xf38998
    // 0xf38984: r8 = TextFormField
    //     0xf38984: add             x8, PP, #0x1a, lsl #12  ; [pp+0x1a8b0] Type: TextFormField
    //     0xf38988: ldr             x8, [x8, #0x8b0]
    // 0xf3898c: r3 = Null
    //     0xf3898c: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8cb88] Null
    //     0xf38990: ldr             x3, [x3, #0xb88]
    // 0xf38994: r0 = DefaultTypeTest()
    //     0xf38994: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xf38998: ldur            x0, [fp, #-8]
    // 0xf3899c: LoadField: r1 = r0->field_2f
    //     0xf3899c: ldur            w1, [x0, #0x2f]
    // 0xf389a0: DecompressPointer r1
    //     0xf389a0: add             x1, x1, HEAP, lsl #32
    // 0xf389a4: LoadField: r0 = r1->field_27
    //     0xf389a4: ldur            w0, [x1, #0x27]
    // 0xf389a8: DecompressPointer r0
    //     0xf389a8: add             x0, x0, HEAP, lsl #32
    // 0xf389ac: LoadField: r2 = r0->field_7
    //     0xf389ac: ldur            w2, [x0, #7]
    // 0xf389b0: DecompressPointer r2
    //     0xf389b0: add             x2, x2, HEAP, lsl #32
    // 0xf389b4: ldur            x1, [fp, #-0x10]
    // 0xf389b8: r0 = didChange()
    //     0xf389b8: bl              #0xd93be8  ; [package:flutter/src/material/text_form_field.dart] _TextFormFieldState::didChange
    // 0xf389bc: r0 = Null
    //     0xf389bc: mov             x0, NULL
    // 0xf389c0: LeaveFrame
    //     0xf389c0: mov             SP, fp
    //     0xf389c4: ldp             fp, lr, [SP], #0x10
    // 0xf389c8: ret
    //     0xf389c8: ret             
    // 0xf389cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf389cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf389d0: b               #0xf38898
    // 0xf389d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf389d4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf389d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf389d8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0xf7a00c, size: 0x18c
    // 0xf7a00c: EnterFrame
    //     0xf7a00c: stp             fp, lr, [SP, #-0x10]!
    //     0xf7a010: mov             fp, SP
    // 0xf7a014: AllocStack(0x20)
    //     0xf7a014: sub             SP, SP, #0x20
    // 0xf7a018: SetupParameters(_TextFormFieldState this /* r1 => r0, fp-0x8 */)
    //     0xf7a018: mov             x0, x1
    //     0xf7a01c: stur            x1, [fp, #-8]
    // 0xf7a020: CheckStackOverflow
    //     0xf7a020: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf7a024: cmp             SP, x16
    //     0xf7a028: b.ls            #0xf7a188
    // 0xf7a02c: mov             x1, x0
    // 0xf7a030: r0 = initState()
    //     0xf7a030: bl              #0xf79f20  ; [package:flutter/src/widgets/form.dart] FormFieldState::initState
    // 0xf7a034: ldur            x3, [fp, #-8]
    // 0xf7a038: LoadField: r4 = r3->field_b
    //     0xf7a038: ldur            w4, [x3, #0xb]
    // 0xf7a03c: DecompressPointer r4
    //     0xf7a03c: add             x4, x4, HEAP, lsl #32
    // 0xf7a040: stur            x4, [fp, #-0x10]
    // 0xf7a044: cmp             w4, NULL
    // 0xf7a048: b.eq            #0xf7a190
    // 0xf7a04c: mov             x0, x4
    // 0xf7a050: r2 = Null
    //     0xf7a050: mov             x2, NULL
    // 0xf7a054: r1 = Null
    //     0xf7a054: mov             x1, NULL
    // 0xf7a058: r4 = LoadClassIdInstr(r0)
    //     0xf7a058: ldur            x4, [x0, #-1]
    //     0xf7a05c: ubfx            x4, x4, #0xc, #0x14
    // 0xf7a060: r17 = 6478
    //     0xf7a060: mov             x17, #0x194e
    // 0xf7a064: cmp             x4, x17
    // 0xf7a068: b.eq            #0xf7a080
    // 0xf7a06c: r8 = TextFormField
    //     0xf7a06c: add             x8, PP, #0x1a, lsl #12  ; [pp+0x1a8b0] Type: TextFormField
    //     0xf7a070: ldr             x8, [x8, #0x8b0]
    // 0xf7a074: r3 = Null
    //     0xf7a074: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8cbd8] Null
    //     0xf7a078: ldr             x3, [x3, #0xbd8]
    // 0xf7a07c: r0 = DefaultTypeTest()
    //     0xf7a07c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xf7a080: ldur            x0, [fp, #-0x10]
    // 0xf7a084: LoadField: r3 = r0->field_2f
    //     0xf7a084: ldur            w3, [x0, #0x2f]
    // 0xf7a088: DecompressPointer r3
    //     0xf7a088: add             x3, x3, HEAP, lsl #32
    // 0xf7a08c: ldur            x2, [fp, #-8]
    // 0xf7a090: stur            x3, [fp, #-0x18]
    // 0xf7a094: r1 = Function '_handleControllerChanged@665147271':.
    //     0xf7a094: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8cb70] AnonymousClosure: (0xf38840), in [package:flutter/src/material/text_form_field.dart] _TextFormFieldState::_handleControllerChanged (0xf38878)
    //     0xf7a098: ldr             x1, [x1, #0xb70]
    // 0xf7a09c: r0 = AllocateClosure()
    //     0xf7a09c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf7a0a0: ldur            x1, [fp, #-0x18]
    // 0xf7a0a4: mov             x2, x0
    // 0xf7a0a8: r0 = addListener()
    //     0xf7a0a8: bl              #0xd038e0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0xf7a0ac: ldur            x3, [fp, #-8]
    // 0xf7a0b0: LoadField: r4 = r3->field_b
    //     0xf7a0b0: ldur            w4, [x3, #0xb]
    // 0xf7a0b4: DecompressPointer r4
    //     0xf7a0b4: add             x4, x4, HEAP, lsl #32
    // 0xf7a0b8: stur            x4, [fp, #-0x10]
    // 0xf7a0bc: cmp             w4, NULL
    // 0xf7a0c0: b.eq            #0xf7a194
    // 0xf7a0c4: mov             x0, x4
    // 0xf7a0c8: r2 = Null
    //     0xf7a0c8: mov             x2, NULL
    // 0xf7a0cc: r1 = Null
    //     0xf7a0cc: mov             x1, NULL
    // 0xf7a0d0: r4 = LoadClassIdInstr(r0)
    //     0xf7a0d0: ldur            x4, [x0, #-1]
    //     0xf7a0d4: ubfx            x4, x4, #0xc, #0x14
    // 0xf7a0d8: r17 = 6478
    //     0xf7a0d8: mov             x17, #0x194e
    // 0xf7a0dc: cmp             x4, x17
    // 0xf7a0e0: b.eq            #0xf7a0f8
    // 0xf7a0e4: r8 = TextFormField
    //     0xf7a0e4: add             x8, PP, #0x1a, lsl #12  ; [pp+0x1a8b0] Type: TextFormField
    //     0xf7a0e8: ldr             x8, [x8, #0x8b0]
    // 0xf7a0ec: r3 = Null
    //     0xf7a0ec: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8cbe8] Null
    //     0xf7a0f0: ldr             x3, [x3, #0xbe8]
    // 0xf7a0f4: r0 = DefaultTypeTest()
    //     0xf7a0f4: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xf7a0f8: ldur            x0, [fp, #-0x10]
    // 0xf7a0fc: LoadField: r1 = r0->field_1f
    //     0xf7a0fc: ldur            w1, [x0, #0x1f]
    // 0xf7a100: DecompressPointer r1
    //     0xf7a100: add             x1, x1, HEAP, lsl #32
    // 0xf7a104: cmp             w1, NULL
    // 0xf7a108: b.ne            #0xf7a12c
    // 0xf7a10c: LoadField: r1 = r0->field_2f
    //     0xf7a10c: ldur            w1, [x0, #0x2f]
    // 0xf7a110: DecompressPointer r1
    //     0xf7a110: add             x1, x1, HEAP, lsl #32
    // 0xf7a114: LoadField: r0 = r1->field_27
    //     0xf7a114: ldur            w0, [x1, #0x27]
    // 0xf7a118: DecompressPointer r0
    //     0xf7a118: add             x0, x0, HEAP, lsl #32
    // 0xf7a11c: LoadField: r1 = r0->field_7
    //     0xf7a11c: ldur            w1, [x0, #7]
    // 0xf7a120: DecompressPointer r1
    //     0xf7a120: add             x1, x1, HEAP, lsl #32
    // 0xf7a124: mov             x0, x1
    // 0xf7a128: b               #0xf7a130
    // 0xf7a12c: mov             x0, x1
    // 0xf7a130: ldur            x1, [fp, #-8]
    // 0xf7a134: LoadField: r2 = r1->field_37
    //     0xf7a134: ldur            w2, [x1, #0x37]
    // 0xf7a138: DecompressPointer r2
    //     0xf7a138: add             x2, x2, HEAP, lsl #32
    // 0xf7a13c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf7a140: cmp             w2, w16
    // 0xf7a144: b.ne            #0xf7a174
    // 0xf7a148: StoreField: r1->field_37 = r0
    //     0xf7a148: stur            w0, [x1, #0x37]
    //     0xf7a14c: ldurb           w16, [x1, #-1]
    //     0xf7a150: ldurb           w17, [x0, #-1]
    //     0xf7a154: and             x16, x17, x16, lsr #2
    //     0xf7a158: tst             x16, HEAP, lsr #32
    //     0xf7a15c: b.eq            #0xf7a164
    //     0xf7a160: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf7a164: r0 = Null
    //     0xf7a164: mov             x0, NULL
    // 0xf7a168: LeaveFrame
    //     0xf7a168: mov             SP, fp
    //     0xf7a16c: ldp             fp, lr, [SP], #0x10
    // 0xf7a170: ret
    //     0xf7a170: ret             
    // 0xf7a174: r16 = "_initialValue@665147271"
    //     0xf7a174: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8cbf8] "_initialValue@665147271"
    //     0xf7a178: ldr             x16, [x16, #0xbf8]
    // 0xf7a17c: str             x16, [SP]
    // 0xf7a180: r0 = _throwFieldAlreadyInitialized()
    //     0xf7a180: bl              #0x82b720  ; [dart:_internal] LateError::_throwFieldAlreadyInitialized
    // 0xf7a184: brk             #0
    // 0xf7a188: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf7a188: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf7a18c: b               #0xf7a02c
    // 0xf7a190: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf7a190: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf7a194: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf7a194: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10dcb78, size: 0xb8
    // 0x10dcb78: EnterFrame
    //     0x10dcb78: stp             fp, lr, [SP, #-0x10]!
    //     0x10dcb7c: mov             fp, SP
    // 0x10dcb80: AllocStack(0x18)
    //     0x10dcb80: sub             SP, SP, #0x18
    // 0x10dcb84: SetupParameters(_TextFormFieldState this /* r1 => r3, fp-0x10 */)
    //     0x10dcb84: mov             x3, x1
    //     0x10dcb88: stur            x1, [fp, #-0x10]
    // 0x10dcb8c: CheckStackOverflow
    //     0x10dcb8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10dcb90: cmp             SP, x16
    //     0x10dcb94: b.ls            #0x10dcc24
    // 0x10dcb98: LoadField: r4 = r3->field_b
    //     0x10dcb98: ldur            w4, [x3, #0xb]
    // 0x10dcb9c: DecompressPointer r4
    //     0x10dcb9c: add             x4, x4, HEAP, lsl #32
    // 0x10dcba0: stur            x4, [fp, #-8]
    // 0x10dcba4: cmp             w4, NULL
    // 0x10dcba8: b.eq            #0x10dcc2c
    // 0x10dcbac: mov             x0, x4
    // 0x10dcbb0: r2 = Null
    //     0x10dcbb0: mov             x2, NULL
    // 0x10dcbb4: r1 = Null
    //     0x10dcbb4: mov             x1, NULL
    // 0x10dcbb8: r4 = LoadClassIdInstr(r0)
    //     0x10dcbb8: ldur            x4, [x0, #-1]
    //     0x10dcbbc: ubfx            x4, x4, #0xc, #0x14
    // 0x10dcbc0: r17 = 6478
    //     0x10dcbc0: mov             x17, #0x194e
    // 0x10dcbc4: cmp             x4, x17
    // 0x10dcbc8: b.eq            #0x10dcbe0
    // 0x10dcbcc: r8 = TextFormField
    //     0x10dcbcc: add             x8, PP, #0x1a, lsl #12  ; [pp+0x1a8b0] Type: TextFormField
    //     0x10dcbd0: ldr             x8, [x8, #0x8b0]
    // 0x10dcbd4: r3 = Null
    //     0x10dcbd4: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8cb60] Null
    //     0x10dcbd8: ldr             x3, [x3, #0xb60]
    // 0x10dcbdc: r0 = DefaultTypeTest()
    //     0x10dcbdc: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x10dcbe0: ldur            x0, [fp, #-8]
    // 0x10dcbe4: LoadField: r3 = r0->field_2f
    //     0x10dcbe4: ldur            w3, [x0, #0x2f]
    // 0x10dcbe8: DecompressPointer r3
    //     0x10dcbe8: add             x3, x3, HEAP, lsl #32
    // 0x10dcbec: ldur            x2, [fp, #-0x10]
    // 0x10dcbf0: stur            x3, [fp, #-0x18]
    // 0x10dcbf4: r1 = Function '_handleControllerChanged@665147271':.
    //     0x10dcbf4: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8cb70] AnonymousClosure: (0xf38840), in [package:flutter/src/material/text_form_field.dart] _TextFormFieldState::_handleControllerChanged (0xf38878)
    //     0x10dcbf8: ldr             x1, [x1, #0xb70]
    // 0x10dcbfc: r0 = AllocateClosure()
    //     0x10dcbfc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10dcc00: ldur            x1, [fp, #-0x18]
    // 0x10dcc04: mov             x2, x0
    // 0x10dcc08: r0 = removeListener()
    //     0x10dcc08: bl              #0xcff968  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x10dcc0c: ldur            x1, [fp, #-0x10]
    // 0x10dcc10: r0 = dispose()
    //     0x10dcc10: bl              #0x10dca8c  ; [package:flutter/src/widgets/form.dart] FormFieldState::dispose
    // 0x10dcc14: r0 = Null
    //     0x10dcc14: mov             x0, NULL
    // 0x10dcc18: LeaveFrame
    //     0x10dcc18: mov             SP, fp
    //     0x10dcc1c: ldp             fp, lr, [SP], #0x10
    // 0x10dcc20: ret
    //     0x10dcc20: ret             
    // 0x10dcc24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10dcc24: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10dcc28: b               #0x10dcb98
    // 0x10dcc2c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10dcc2c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 6478, size: 0x34, field offset: 0x30
class TextFormField extends FormField<dynamic> {

  _ TextFormField(/* No info */) {
    // ** addr: 0xd8ff70, size: 0xae4
    // 0xd8ff70: EnterFrame
    //     0xd8ff70: stp             fp, lr, [SP, #-0x10]!
    //     0xd8ff74: mov             fp, SP
    // 0xd8ff78: AllocStack(0xd8)
    //     0xd8ff78: sub             SP, SP, #0xd8
    // 0xd8ff7c: SetupParameters(TextFormField this /* r1 => fp-0x28 */, dynamic _ /* r2 => fp-0x8 */, dynamic _ /* r3 => r3, fp-0xd0 */, {dynamic autofocus = false /* r5, fp-0xc8 */, dynamic cursorColor = Null /* r6, fp-0xc0 */, _Double cursorWidth = 2.000000 /* d0, fp-0xd8 */, dynamic enableInteractiveSelection = Null /* r7, fp-0xb8 */, dynamic expands = false /* r8, fp-0xb0 */, dynamic focusNode = Null /* r9, fp-0xa8 */, dynamic inputFormatters = Null /* r10, fp-0xa0 */, dynamic keyboardType = Null /* r11, fp-0x98 */, dynamic maxLength = Null /* r12, fp-0x90 */, dynamic maxLines = 2 /* r13, fp-0x88 */, dynamic obscureText = false /* r14, fp-0x80 */, dynamic obscuringCharacter = "•" /* r19, fp-0x78 */, dynamic onChanged = Null /* fp-0x10 */, dynamic onEditingComplete = Null /* fp-0x18 */, dynamic onFieldSubmitted = Null /* fp-0x20 */, dynamic onSaved = Null /* r20, fp-0x70 */, dynamic onTap = Null /* fp-0x30 */, dynamic readOnly = false /* fp-0x38 */, dynamic scrollPhysics = Null /* fp-0x40 */, dynamic style = Null /* fp-0x48 */, dynamic textAlign = Instance_TextAlign /* fp-0x50 */, dynamic textAlignVertical = Null /* fp-0x58 */, dynamic textInputAction = Null /* r0, fp-0x68 */, dynamic validator = Null /* r1, fp-0x60 */})
    //     0xd8ff7c: mov             x0, x2
    //     0xd8ff80: stur            x2, [fp, #-8]
    //     0xd8ff84: stur            x1, [fp, #-0x28]
    //     0xd8ff88: stur            x3, [fp, #-0xd0]
    //     0xd8ff8c: ldur            w2, [x4, #0x13]
    //     0xd8ff90: ldur            w5, [x4, #0x1f]
    //     0xd8ff94: add             x5, x5, HEAP, lsl #32
    //     0xd8ff98: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a570] "autofocus"
    //     0xd8ff9c: ldr             x16, [x16, #0x570]
    //     0xd8ffa0: cmp             w5, w16
    //     0xd8ffa4: b.ne            #0xd8ffc4
    //     0xd8ffa8: ldur            w5, [x4, #0x23]
    //     0xd8ffac: add             x5, x5, HEAP, lsl #32
    //     0xd8ffb0: sub             w6, w2, w5
    //     0xd8ffb4: add             x5, fp, w6, sxtw #2
    //     0xd8ffb8: ldr             x5, [x5, #8]
    //     0xd8ffbc: mov             x6, #1
    //     0xd8ffc0: b               #0xd8ffcc
    //     0xd8ffc4: mov             x6, #0
    //     0xd8ffc8: add             x5, NULL, #0x30  ; false
    //     0xd8ffcc: stur            x5, [fp, #-0xc8]
    //     0xd8ffd0: lsl             x7, x6, #1
    //     0xd8ffd4: lsl             w8, w7, #1
    //     0xd8ffd8: add             w9, w8, #8
    //     0xd8ffdc: add             x16, x4, w9, sxtw #1
    //     0xd8ffe0: ldur            w10, [x16, #0xf]
    //     0xd8ffe4: add             x10, x10, HEAP, lsl #32
    //     0xd8ffe8: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a578] "cursorColor"
    //     0xd8ffec: ldr             x16, [x16, #0x578]
    //     0xd8fff0: cmp             w10, w16
    //     0xd8fff4: b.ne            #0xd90024
    //     0xd8fff8: add             w6, w8, #0xa
    //     0xd8fffc: add             x16, x4, w6, sxtw #1
    //     0xd90000: ldur            w8, [x16, #0xf]
    //     0xd90004: add             x8, x8, HEAP, lsl #32
    //     0xd90008: sub             w6, w2, w8
    //     0xd9000c: add             x8, fp, w6, sxtw #2
    //     0xd90010: ldr             x8, [x8, #8]
    //     0xd90014: add             w6, w7, #2
    //     0xd90018: sbfx            x7, x6, #1, #0x1f
    //     0xd9001c: mov             x6, x8
    //     0xd90020: b               #0xd9002c
    //     0xd90024: mov             x7, x6
    //     0xd90028: mov             x6, NULL
    //     0xd9002c: stur            x6, [fp, #-0xc0]
    //     0xd90030: lsl             x8, x7, #1
    //     0xd90034: lsl             w9, w8, #1
    //     0xd90038: add             w10, w9, #8
    //     0xd9003c: add             x16, x4, w10, sxtw #1
    //     0xd90040: ldur            w11, [x16, #0xf]
    //     0xd90044: add             x11, x11, HEAP, lsl #32
    //     0xd90048: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a580] "cursorWidth"
    //     0xd9004c: ldr             x16, [x16, #0x580]
    //     0xd90050: cmp             w11, w16
    //     0xd90054: b.ne            #0xd90088
    //     0xd90058: add             w7, w9, #0xa
    //     0xd9005c: add             x16, x4, w7, sxtw #1
    //     0xd90060: ldur            w9, [x16, #0xf]
    //     0xd90064: add             x9, x9, HEAP, lsl #32
    //     0xd90068: sub             w7, w2, w9
    //     0xd9006c: add             x9, fp, w7, sxtw #2
    //     0xd90070: ldr             x9, [x9, #8]
    //     0xd90074: add             w7, w8, #2
    //     0xd90078: ldur            d0, [x9, #7]
    //     0xd9007c: sbfx            x8, x7, #1, #0x1f
    //     0xd90080: mov             x7, x8
    //     0xd90084: b               #0xd9008c
    //     0xd90088: fmov            d0, #2.00000000
    //     0xd9008c: stur            d0, [fp, #-0xd8]
    //     0xd90090: lsl             x8, x7, #1
    //     0xd90094: lsl             w9, w8, #1
    //     0xd90098: add             w10, w9, #8
    //     0xd9009c: add             x16, x4, w10, sxtw #1
    //     0xd900a0: ldur            w11, [x16, #0xf]
    //     0xd900a4: add             x11, x11, HEAP, lsl #32
    //     0xd900a8: ldr             x16, [PP, #0x6180]  ; [pp+0x6180] "enableInteractiveSelection"
    //     0xd900ac: cmp             w11, w16
    //     0xd900b0: b.ne            #0xd900e0
    //     0xd900b4: add             w7, w9, #0xa
    //     0xd900b8: add             x16, x4, w7, sxtw #1
    //     0xd900bc: ldur            w9, [x16, #0xf]
    //     0xd900c0: add             x9, x9, HEAP, lsl #32
    //     0xd900c4: sub             w7, w2, w9
    //     0xd900c8: add             x9, fp, w7, sxtw #2
    //     0xd900cc: ldr             x9, [x9, #8]
    //     0xd900d0: add             w7, w8, #2
    //     0xd900d4: sbfx            x8, x7, #1, #0x1f
    //     0xd900d8: mov             x7, x9
    //     0xd900dc: b               #0xd900e8
    //     0xd900e0: mov             x8, x7
    //     0xd900e4: mov             x7, NULL
    //     0xd900e8: stur            x7, [fp, #-0xb8]
    //     0xd900ec: lsl             x9, x8, #1
    //     0xd900f0: lsl             w10, w9, #1
    //     0xd900f4: add             w11, w10, #8
    //     0xd900f8: add             x16, x4, w11, sxtw #1
    //     0xd900fc: ldur            w12, [x16, #0xf]
    //     0xd90100: add             x12, x12, HEAP, lsl #32
    //     0xd90104: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a588] "expands"
    //     0xd90108: ldr             x16, [x16, #0x588]
    //     0xd9010c: cmp             w12, w16
    //     0xd90110: b.ne            #0xd90140
    //     0xd90114: add             w8, w10, #0xa
    //     0xd90118: add             x16, x4, w8, sxtw #1
    //     0xd9011c: ldur            w10, [x16, #0xf]
    //     0xd90120: add             x10, x10, HEAP, lsl #32
    //     0xd90124: sub             w8, w2, w10
    //     0xd90128: add             x10, fp, w8, sxtw #2
    //     0xd9012c: ldr             x10, [x10, #8]
    //     0xd90130: add             w8, w9, #2
    //     0xd90134: sbfx            x9, x8, #1, #0x1f
    //     0xd90138: mov             x8, x10
    //     0xd9013c: b               #0xd90148
    //     0xd90140: mov             x9, x8
    //     0xd90144: add             x8, NULL, #0x30  ; false
    //     0xd90148: stur            x8, [fp, #-0xb0]
    //     0xd9014c: lsl             x10, x9, #1
    //     0xd90150: lsl             w11, w10, #1
    //     0xd90154: add             w12, w11, #8
    //     0xd90158: add             x16, x4, w12, sxtw #1
    //     0xd9015c: ldur            w13, [x16, #0xf]
    //     0xd90160: add             x13, x13, HEAP, lsl #32
    //     0xd90164: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a590] "focusNode"
    //     0xd90168: ldr             x16, [x16, #0x590]
    //     0xd9016c: cmp             w13, w16
    //     0xd90170: b.ne            #0xd901a0
    //     0xd90174: add             w9, w11, #0xa
    //     0xd90178: add             x16, x4, w9, sxtw #1
    //     0xd9017c: ldur            w11, [x16, #0xf]
    //     0xd90180: add             x11, x11, HEAP, lsl #32
    //     0xd90184: sub             w9, w2, w11
    //     0xd90188: add             x11, fp, w9, sxtw #2
    //     0xd9018c: ldr             x11, [x11, #8]
    //     0xd90190: add             w9, w10, #2
    //     0xd90194: sbfx            x10, x9, #1, #0x1f
    //     0xd90198: mov             x9, x11
    //     0xd9019c: b               #0xd901a8
    //     0xd901a0: mov             x10, x9
    //     0xd901a4: mov             x9, NULL
    //     0xd901a8: stur            x9, [fp, #-0xa8]
    //     0xd901ac: lsl             x11, x10, #1
    //     0xd901b0: lsl             w12, w11, #1
    //     0xd901b4: add             w13, w12, #8
    //     0xd901b8: add             x16, x4, w13, sxtw #1
    //     0xd901bc: ldur            w14, [x16, #0xf]
    //     0xd901c0: add             x14, x14, HEAP, lsl #32
    //     0xd901c4: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a598] "inputFormatters"
    //     0xd901c8: ldr             x16, [x16, #0x598]
    //     0xd901cc: cmp             w14, w16
    //     0xd901d0: b.ne            #0xd90200
    //     0xd901d4: add             w10, w12, #0xa
    //     0xd901d8: add             x16, x4, w10, sxtw #1
    //     0xd901dc: ldur            w12, [x16, #0xf]
    //     0xd901e0: add             x12, x12, HEAP, lsl #32
    //     0xd901e4: sub             w10, w2, w12
    //     0xd901e8: add             x12, fp, w10, sxtw #2
    //     0xd901ec: ldr             x12, [x12, #8]
    //     0xd901f0: add             w10, w11, #2
    //     0xd901f4: sbfx            x11, x10, #1, #0x1f
    //     0xd901f8: mov             x10, x12
    //     0xd901fc: b               #0xd90208
    //     0xd90200: mov             x11, x10
    //     0xd90204: mov             x10, NULL
    //     0xd90208: stur            x10, [fp, #-0xa0]
    //     0xd9020c: lsl             x12, x11, #1
    //     0xd90210: lsl             w13, w12, #1
    //     0xd90214: add             w14, w13, #8
    //     0xd90218: add             x16, x4, w14, sxtw #1
    //     0xd9021c: ldur            w19, [x16, #0xf]
    //     0xd90220: add             x19, x19, HEAP, lsl #32
    //     0xd90224: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a5a0] "keyboardType"
    //     0xd90228: ldr             x16, [x16, #0x5a0]
    //     0xd9022c: cmp             w19, w16
    //     0xd90230: b.ne            #0xd90260
    //     0xd90234: add             w11, w13, #0xa
    //     0xd90238: add             x16, x4, w11, sxtw #1
    //     0xd9023c: ldur            w13, [x16, #0xf]
    //     0xd90240: add             x13, x13, HEAP, lsl #32
    //     0xd90244: sub             w11, w2, w13
    //     0xd90248: add             x13, fp, w11, sxtw #2
    //     0xd9024c: ldr             x13, [x13, #8]
    //     0xd90250: add             w11, w12, #2
    //     0xd90254: sbfx            x12, x11, #1, #0x1f
    //     0xd90258: mov             x11, x13
    //     0xd9025c: b               #0xd90268
    //     0xd90260: mov             x12, x11
    //     0xd90264: mov             x11, NULL
    //     0xd90268: stur            x11, [fp, #-0x98]
    //     0xd9026c: lsl             x13, x12, #1
    //     0xd90270: lsl             w14, w13, #1
    //     0xd90274: add             w19, w14, #8
    //     0xd90278: add             x16, x4, w19, sxtw #1
    //     0xd9027c: ldur            w20, [x16, #0xf]
    //     0xd90280: add             x20, x20, HEAP, lsl #32
    //     0xd90284: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a5a8] "maxLength"
    //     0xd90288: ldr             x16, [x16, #0x5a8]
    //     0xd9028c: cmp             w20, w16
    //     0xd90290: b.ne            #0xd902c0
    //     0xd90294: add             w12, w14, #0xa
    //     0xd90298: add             x16, x4, w12, sxtw #1
    //     0xd9029c: ldur            w14, [x16, #0xf]
    //     0xd902a0: add             x14, x14, HEAP, lsl #32
    //     0xd902a4: sub             w12, w2, w14
    //     0xd902a8: add             x14, fp, w12, sxtw #2
    //     0xd902ac: ldr             x14, [x14, #8]
    //     0xd902b0: add             w12, w13, #2
    //     0xd902b4: sbfx            x13, x12, #1, #0x1f
    //     0xd902b8: mov             x12, x14
    //     0xd902bc: b               #0xd902c8
    //     0xd902c0: mov             x13, x12
    //     0xd902c4: mov             x12, NULL
    //     0xd902c8: stur            x12, [fp, #-0x90]
    //     0xd902cc: lsl             x14, x13, #1
    //     0xd902d0: lsl             w19, w14, #1
    //     0xd902d4: add             w20, w19, #8
    //     0xd902d8: add             x16, x4, w20, sxtw #1
    //     0xd902dc: ldur            w23, [x16, #0xf]
    //     0xd902e0: add             x23, x23, HEAP, lsl #32
    //     0xd902e4: ldr             x16, [PP, #0x4b68]  ; [pp+0x4b68] "maxLines"
    //     0xd902e8: cmp             w23, w16
    //     0xd902ec: b.ne            #0xd9031c
    //     0xd902f0: add             w13, w19, #0xa
    //     0xd902f4: add             x16, x4, w13, sxtw #1
    //     0xd902f8: ldur            w19, [x16, #0xf]
    //     0xd902fc: add             x19, x19, HEAP, lsl #32
    //     0xd90300: sub             w13, w2, w19
    //     0xd90304: add             x19, fp, w13, sxtw #2
    //     0xd90308: ldr             x19, [x19, #8]
    //     0xd9030c: add             w13, w14, #2
    //     0xd90310: sbfx            x14, x13, #1, #0x1f
    //     0xd90314: mov             x13, x19
    //     0xd90318: b               #0xd90324
    //     0xd9031c: mov             x14, x13
    //     0xd90320: mov             x13, #2
    //     0xd90324: stur            x13, [fp, #-0x88]
    //     0xd90328: lsl             x19, x14, #1
    //     0xd9032c: lsl             w20, w19, #1
    //     0xd90330: add             w23, w20, #8
    //     0xd90334: add             x16, x4, w23, sxtw #1
    //     0xd90338: ldur            w24, [x16, #0xf]
    //     0xd9033c: add             x24, x24, HEAP, lsl #32
    //     0xd90340: ldr             x16, [PP, #0x6158]  ; [pp+0x6158] "obscureText"
    //     0xd90344: cmp             w24, w16
    //     0xd90348: b.ne            #0xd90378
    //     0xd9034c: add             w14, w20, #0xa
    //     0xd90350: add             x16, x4, w14, sxtw #1
    //     0xd90354: ldur            w20, [x16, #0xf]
    //     0xd90358: add             x20, x20, HEAP, lsl #32
    //     0xd9035c: sub             w14, w2, w20
    //     0xd90360: add             x20, fp, w14, sxtw #2
    //     0xd90364: ldr             x20, [x20, #8]
    //     0xd90368: add             w14, w19, #2
    //     0xd9036c: sbfx            x19, x14, #1, #0x1f
    //     0xd90370: mov             x14, x20
    //     0xd90374: b               #0xd90380
    //     0xd90378: mov             x19, x14
    //     0xd9037c: add             x14, NULL, #0x30  ; false
    //     0xd90380: stur            x14, [fp, #-0x80]
    //     0xd90384: lsl             x20, x19, #1
    //     0xd90388: lsl             w23, w20, #1
    //     0xd9038c: add             w24, w23, #8
    //     0xd90390: add             x16, x4, w24, sxtw #1
    //     0xd90394: ldur            w25, [x16, #0xf]
    //     0xd90398: add             x25, x25, HEAP, lsl #32
    //     0xd9039c: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a5b0] "obscuringCharacter"
    //     0xd903a0: ldr             x16, [x16, #0x5b0]
    //     0xd903a4: cmp             w25, w16
    //     0xd903a8: b.ne            #0xd903d8
    //     0xd903ac: add             w19, w23, #0xa
    //     0xd903b0: add             x16, x4, w19, sxtw #1
    //     0xd903b4: ldur            w23, [x16, #0xf]
    //     0xd903b8: add             x23, x23, HEAP, lsl #32
    //     0xd903bc: sub             w19, w2, w23
    //     0xd903c0: add             x23, fp, w19, sxtw #2
    //     0xd903c4: ldr             x23, [x23, #8]
    //     0xd903c8: add             w19, w20, #2
    //     0xd903cc: sbfx            x20, x19, #1, #0x1f
    //     0xd903d0: mov             x19, x23
    //     0xd903d4: b               #0xd903e4
    //     0xd903d8: mov             x20, x19
    //     0xd903dc: add             x19, PP, #0x1a, lsl #12  ; [pp+0x1a5b8] "•"
    //     0xd903e0: ldr             x19, [x19, #0x5b8]
    //     0xd903e4: stur            x19, [fp, #-0x78]
    //     0xd903e8: lsl             x23, x20, #1
    //     0xd903ec: lsl             w24, w23, #1
    //     0xd903f0: add             w25, w24, #8
    //     0xd903f4: add             x16, x4, w25, sxtw #1
    //     0xd903f8: ldur            w0, [x16, #0xf]
    //     0xd903fc: add             x0, x0, HEAP, lsl #32
    //     0xd90400: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a5c0] "onChanged"
    //     0xd90404: ldr             x16, [x16, #0x5c0]
    //     0xd90408: cmp             w0, w16
    //     0xd9040c: b.ne            #0xd90440
    //     0xd90410: add             w0, w24, #0xa
    //     0xd90414: add             x16, x4, w0, sxtw #1
    //     0xd90418: ldur            w20, [x16, #0xf]
    //     0xd9041c: add             x20, x20, HEAP, lsl #32
    //     0xd90420: sub             w0, w2, w20
    //     0xd90424: add             x20, fp, w0, sxtw #2
    //     0xd90428: ldr             x20, [x20, #8]
    //     0xd9042c: add             w0, w23, #2
    //     0xd90430: sbfx            x23, x0, #1, #0x1f
    //     0xd90434: mov             x0, x20
    //     0xd90438: mov             x20, x23
    //     0xd9043c: b               #0xd90444
    //     0xd90440: mov             x0, NULL
    //     0xd90444: stur            x0, [fp, #-0x10]
    //     0xd90448: lsl             x23, x20, #1
    //     0xd9044c: lsl             w24, w23, #1
    //     0xd90450: add             w25, w24, #8
    //     0xd90454: add             x16, x4, w25, sxtw #1
    //     0xd90458: ldur            w0, [x16, #0xf]
    //     0xd9045c: add             x0, x0, HEAP, lsl #32
    //     0xd90460: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a5c8] "onEditingComplete"
    //     0xd90464: ldr             x16, [x16, #0x5c8]
    //     0xd90468: cmp             w0, w16
    //     0xd9046c: b.ne            #0xd904a0
    //     0xd90470: add             w0, w24, #0xa
    //     0xd90474: add             x16, x4, w0, sxtw #1
    //     0xd90478: ldur            w20, [x16, #0xf]
    //     0xd9047c: add             x20, x20, HEAP, lsl #32
    //     0xd90480: sub             w0, w2, w20
    //     0xd90484: add             x20, fp, w0, sxtw #2
    //     0xd90488: ldr             x20, [x20, #8]
    //     0xd9048c: add             w0, w23, #2
    //     0xd90490: sbfx            x23, x0, #1, #0x1f
    //     0xd90494: mov             x0, x20
    //     0xd90498: mov             x20, x23
    //     0xd9049c: b               #0xd904a4
    //     0xd904a0: mov             x0, NULL
    //     0xd904a4: stur            x0, [fp, #-0x18]
    //     0xd904a8: lsl             x23, x20, #1
    //     0xd904ac: lsl             w24, w23, #1
    //     0xd904b0: add             w25, w24, #8
    //     0xd904b4: add             x16, x4, w25, sxtw #1
    //     0xd904b8: ldur            w0, [x16, #0xf]
    //     0xd904bc: add             x0, x0, HEAP, lsl #32
    //     0xd904c0: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a5d0] "onFieldSubmitted"
    //     0xd904c4: ldr             x16, [x16, #0x5d0]
    //     0xd904c8: cmp             w0, w16
    //     0xd904cc: b.ne            #0xd90500
    //     0xd904d0: add             w0, w24, #0xa
    //     0xd904d4: add             x16, x4, w0, sxtw #1
    //     0xd904d8: ldur            w20, [x16, #0xf]
    //     0xd904dc: add             x20, x20, HEAP, lsl #32
    //     0xd904e0: sub             w0, w2, w20
    //     0xd904e4: add             x20, fp, w0, sxtw #2
    //     0xd904e8: ldr             x20, [x20, #8]
    //     0xd904ec: add             w0, w23, #2
    //     0xd904f0: sbfx            x23, x0, #1, #0x1f
    //     0xd904f4: mov             x0, x20
    //     0xd904f8: mov             x20, x23
    //     0xd904fc: b               #0xd90504
    //     0xd90500: mov             x0, NULL
    //     0xd90504: stur            x0, [fp, #-0x20]
    //     0xd90508: lsl             x23, x20, #1
    //     0xd9050c: lsl             w24, w23, #1
    //     0xd90510: add             w25, w24, #8
    //     0xd90514: add             x16, x4, w25, sxtw #1
    //     0xd90518: ldur            w0, [x16, #0xf]
    //     0xd9051c: add             x0, x0, HEAP, lsl #32
    //     0xd90520: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a5d8] "onSaved"
    //     0xd90524: ldr             x16, [x16, #0x5d8]
    //     0xd90528: cmp             w0, w16
    //     0xd9052c: b.ne            #0xd9055c
    //     0xd90530: add             w0, w24, #0xa
    //     0xd90534: add             x16, x4, w0, sxtw #1
    //     0xd90538: ldur            w20, [x16, #0xf]
    //     0xd9053c: add             x20, x20, HEAP, lsl #32
    //     0xd90540: sub             w0, w2, w20
    //     0xd90544: add             x20, fp, w0, sxtw #2
    //     0xd90548: ldr             x20, [x20, #8]
    //     0xd9054c: add             w0, w23, #2
    //     0xd90550: sbfx            x23, x0, #1, #0x1f
    //     0xd90554: mov             x0, x23
    //     0xd90558: b               #0xd90564
    //     0xd9055c: mov             x0, x20
    //     0xd90560: mov             x20, NULL
    //     0xd90564: stur            x20, [fp, #-0x70]
    //     0xd90568: lsl             x23, x0, #1
    //     0xd9056c: lsl             w24, w23, #1
    //     0xd90570: add             w25, w24, #8
    //     0xd90574: add             x16, x4, w25, sxtw #1
    //     0xd90578: ldur            w1, [x16, #0xf]
    //     0xd9057c: add             x1, x1, HEAP, lsl #32
    //     0xd90580: add             x16, PP, #0x15, lsl #12  ; [pp+0x151e0] "onTap"
    //     0xd90584: ldr             x16, [x16, #0x1e0]
    //     0xd90588: cmp             w1, w16
    //     0xd9058c: b.ne            #0xd905c0
    //     0xd90590: add             w0, w24, #0xa
    //     0xd90594: add             x16, x4, w0, sxtw #1
    //     0xd90598: ldur            w1, [x16, #0xf]
    //     0xd9059c: add             x1, x1, HEAP, lsl #32
    //     0xd905a0: sub             w0, w2, w1
    //     0xd905a4: add             x1, fp, w0, sxtw #2
    //     0xd905a8: ldr             x1, [x1, #8]
    //     0xd905ac: add             w0, w23, #2
    //     0xd905b0: sbfx            x23, x0, #1, #0x1f
    //     0xd905b4: mov             x0, x1
    //     0xd905b8: mov             x1, x23
    //     0xd905bc: b               #0xd905c8
    //     0xd905c0: mov             x1, x0
    //     0xd905c4: mov             x0, NULL
    //     0xd905c8: stur            x0, [fp, #-0x30]
    //     0xd905cc: lsl             x23, x1, #1
    //     0xd905d0: lsl             w24, w23, #1
    //     0xd905d4: add             w25, w24, #8
    //     0xd905d8: add             x16, x4, w25, sxtw #1
    //     0xd905dc: ldur            w0, [x16, #0xf]
    //     0xd905e0: add             x0, x0, HEAP, lsl #32
    //     0xd905e4: ldr             x16, [PP, #0x6150]  ; [pp+0x6150] "readOnly"
    //     0xd905e8: cmp             w0, w16
    //     0xd905ec: b.ne            #0xd90620
    //     0xd905f0: add             w0, w24, #0xa
    //     0xd905f4: add             x16, x4, w0, sxtw #1
    //     0xd905f8: ldur            w1, [x16, #0xf]
    //     0xd905fc: add             x1, x1, HEAP, lsl #32
    //     0xd90600: sub             w0, w2, w1
    //     0xd90604: add             x1, fp, w0, sxtw #2
    //     0xd90608: ldr             x1, [x1, #8]
    //     0xd9060c: add             w0, w23, #2
    //     0xd90610: sbfx            x23, x0, #1, #0x1f
    //     0xd90614: mov             x0, x1
    //     0xd90618: mov             x1, x23
    //     0xd9061c: b               #0xd90624
    //     0xd90620: add             x0, NULL, #0x30  ; false
    //     0xd90624: stur            x0, [fp, #-0x38]
    //     0xd90628: lsl             x23, x1, #1
    //     0xd9062c: lsl             w24, w23, #1
    //     0xd90630: add             w25, w24, #8
    //     0xd90634: add             x16, x4, w25, sxtw #1
    //     0xd90638: ldur            w0, [x16, #0xf]
    //     0xd9063c: add             x0, x0, HEAP, lsl #32
    //     0xd90640: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a5e0] "scrollPhysics"
    //     0xd90644: ldr             x16, [x16, #0x5e0]
    //     0xd90648: cmp             w0, w16
    //     0xd9064c: b.ne            #0xd90680
    //     0xd90650: add             w0, w24, #0xa
    //     0xd90654: add             x16, x4, w0, sxtw #1
    //     0xd90658: ldur            w1, [x16, #0xf]
    //     0xd9065c: add             x1, x1, HEAP, lsl #32
    //     0xd90660: sub             w0, w2, w1
    //     0xd90664: add             x1, fp, w0, sxtw #2
    //     0xd90668: ldr             x1, [x1, #8]
    //     0xd9066c: add             w0, w23, #2
    //     0xd90670: sbfx            x23, x0, #1, #0x1f
    //     0xd90674: mov             x0, x1
    //     0xd90678: mov             x1, x23
    //     0xd9067c: b               #0xd90684
    //     0xd90680: mov             x0, NULL
    //     0xd90684: stur            x0, [fp, #-0x40]
    //     0xd90688: lsl             x23, x1, #1
    //     0xd9068c: lsl             w24, w23, #1
    //     0xd90690: add             w25, w24, #8
    //     0xd90694: add             x16, x4, w25, sxtw #1
    //     0xd90698: ldur            w0, [x16, #0xf]
    //     0xd9069c: add             x0, x0, HEAP, lsl #32
    //     0xd906a0: add             x16, PP, #8, lsl #12  ; [pp+0x8400] "style"
    //     0xd906a4: ldr             x16, [x16, #0x400]
    //     0xd906a8: cmp             w0, w16
    //     0xd906ac: b.ne            #0xd906e0
    //     0xd906b0: add             w0, w24, #0xa
    //     0xd906b4: add             x16, x4, w0, sxtw #1
    //     0xd906b8: ldur            w1, [x16, #0xf]
    //     0xd906bc: add             x1, x1, HEAP, lsl #32
    //     0xd906c0: sub             w0, w2, w1
    //     0xd906c4: add             x1, fp, w0, sxtw #2
    //     0xd906c8: ldr             x1, [x1, #8]
    //     0xd906cc: add             w0, w23, #2
    //     0xd906d0: sbfx            x23, x0, #1, #0x1f
    //     0xd906d4: mov             x0, x1
    //     0xd906d8: mov             x1, x23
    //     0xd906dc: b               #0xd906e4
    //     0xd906e0: mov             x0, NULL
    //     0xd906e4: stur            x0, [fp, #-0x48]
    //     0xd906e8: lsl             x23, x1, #1
    //     0xd906ec: lsl             w24, w23, #1
    //     0xd906f0: add             w25, w24, #8
    //     0xd906f4: add             x16, x4, w25, sxtw #1
    //     0xd906f8: ldur            w0, [x16, #0xf]
    //     0xd906fc: add             x0, x0, HEAP, lsl #32
    //     0xd90700: ldr             x16, [PP, #0x4b78]  ; [pp+0x4b78] "textAlign"
    //     0xd90704: cmp             w0, w16
    //     0xd90708: b.ne            #0xd9073c
    //     0xd9070c: add             w0, w24, #0xa
    //     0xd90710: add             x16, x4, w0, sxtw #1
    //     0xd90714: ldur            w1, [x16, #0xf]
    //     0xd90718: add             x1, x1, HEAP, lsl #32
    //     0xd9071c: sub             w0, w2, w1
    //     0xd90720: add             x1, fp, w0, sxtw #2
    //     0xd90724: ldr             x1, [x1, #8]
    //     0xd90728: add             w0, w23, #2
    //     0xd9072c: sbfx            x23, x0, #1, #0x1f
    //     0xd90730: mov             x0, x1
    //     0xd90734: mov             x1, x23
    //     0xd90738: b               #0xd90740
    //     0xd9073c: ldr             x0, [PP, #0x4c78]  ; [pp+0x4c78] Obj!TextAlign@12c7541
    //     0xd90740: stur            x0, [fp, #-0x50]
    //     0xd90744: lsl             x23, x1, #1
    //     0xd90748: lsl             w24, w23, #1
    //     0xd9074c: add             w25, w24, #8
    //     0xd90750: add             x16, x4, w25, sxtw #1
    //     0xd90754: ldur            w0, [x16, #0xf]
    //     0xd90758: add             x0, x0, HEAP, lsl #32
    //     0xd9075c: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a5e8] "textAlignVertical"
    //     0xd90760: ldr             x16, [x16, #0x5e8]
    //     0xd90764: cmp             w0, w16
    //     0xd90768: b.ne            #0xd9079c
    //     0xd9076c: add             w0, w24, #0xa
    //     0xd90770: add             x16, x4, w0, sxtw #1
    //     0xd90774: ldur            w1, [x16, #0xf]
    //     0xd90778: add             x1, x1, HEAP, lsl #32
    //     0xd9077c: sub             w0, w2, w1
    //     0xd90780: add             x1, fp, w0, sxtw #2
    //     0xd90784: ldr             x1, [x1, #8]
    //     0xd90788: add             w0, w23, #2
    //     0xd9078c: sbfx            x23, x0, #1, #0x1f
    //     0xd90790: mov             x0, x1
    //     0xd90794: mov             x1, x23
    //     0xd90798: b               #0xd907a0
    //     0xd9079c: mov             x0, NULL
    //     0xd907a0: stur            x0, [fp, #-0x58]
    //     0xd907a4: lsl             x23, x1, #1
    //     0xd907a8: lsl             w24, w23, #1
    //     0xd907ac: add             w25, w24, #8
    //     0xd907b0: add             x16, x4, w25, sxtw #1
    //     0xd907b4: ldur            w0, [x16, #0xf]
    //     0xd907b8: add             x0, x0, HEAP, lsl #32
    //     0xd907bc: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a5f0] "textInputAction"
    //     0xd907c0: ldr             x16, [x16, #0x5f0]
    //     0xd907c4: cmp             w0, w16
    //     0xd907c8: b.ne            #0xd907fc
    //     0xd907cc: add             w0, w24, #0xa
    //     0xd907d0: add             x16, x4, w0, sxtw #1
    //     0xd907d4: ldur            w1, [x16, #0xf]
    //     0xd907d8: add             x1, x1, HEAP, lsl #32
    //     0xd907dc: sub             w0, w2, w1
    //     0xd907e0: add             x1, fp, w0, sxtw #2
    //     0xd907e4: ldr             x1, [x1, #8]
    //     0xd907e8: add             w0, w23, #2
    //     0xd907ec: sbfx            x23, x0, #1, #0x1f
    //     0xd907f0: mov             x0, x1
    //     0xd907f4: mov             x1, x23
    //     0xd907f8: b               #0xd90800
    //     0xd907fc: mov             x0, NULL
    //     0xd90800: stur            x0, [fp, #-0x68]
    //     0xd90804: lsl             x23, x1, #1
    //     0xd90808: lsl             w1, w23, #1
    //     0xd9080c: add             w23, w1, #8
    //     0xd90810: add             x16, x4, w23, sxtw #1
    //     0xd90814: ldur            w24, [x16, #0xf]
    //     0xd90818: add             x24, x24, HEAP, lsl #32
    //     0xd9081c: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a5f8] "validator"
    //     0xd90820: ldr             x16, [x16, #0x5f8]
    //     0xd90824: cmp             w24, w16
    //     0xd90828: b.ne            #0xd9084c
    //     0xd9082c: add             w23, w1, #0xa
    //     0xd90830: add             x16, x4, w23, sxtw #1
    //     0xd90834: ldur            w1, [x16, #0xf]
    //     0xd90838: add             x1, x1, HEAP, lsl #32
    //     0xd9083c: sub             w4, w2, w1
    //     0xd90840: add             x1, fp, w4, sxtw #2
    //     0xd90844: ldr             x1, [x1, #8]
    //     0xd90848: b               #0xd90850
    //     0xd9084c: mov             x1, NULL
    //     0xd90850: stur            x1, [fp, #-0x60]
    // 0xd90854: r1 = 23
    //     0xd90854: mov             x1, #0x17
    // 0xd90858: r0 = AllocateContext()
    //     0xd90858: bl              #0x13de838  ; AllocateContextStub
    // 0xd9085c: mov             x2, x0
    // 0xd90860: ldur            x1, [fp, #-0xd0]
    // 0xd90864: StoreField: r2->field_f = r1
    //     0xd90864: stur            w1, [x2, #0xf]
    // 0xd90868: ldur            x0, [fp, #-0xc8]
    // 0xd9086c: StoreField: r2->field_13 = r0
    //     0xd9086c: stur            w0, [x2, #0x13]
    // 0xd90870: ldur            x0, [fp, #-0xc0]
    // 0xd90874: ArrayStore: r2[0] = r0  ; List_4
    //     0xd90874: stur            w0, [x2, #0x17]
    // 0xd90878: ldur            d0, [fp, #-0xd8]
    // 0xd9087c: r0 = inline_Allocate_Double()
    //     0xd9087c: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0xd90880: add             x0, x0, #0x10
    //     0xd90884: cmp             x3, x0
    //     0xd90888: b.ls            #0xd90a3c
    //     0xd9088c: str             x0, [THR, #0x60]  ; THR::top
    //     0xd90890: sub             x0, x0, #0xf
    //     0xd90894: mov             x3, #0xe19c
    //     0xd90898: movk            x3, #3, lsl #16
    //     0xd9089c: stur            x3, [x0, #-1]
    // 0xd908a0: dmb             ishst
    // 0xd908a4: StoreField: r0->field_7 = d0
    //     0xd908a4: stur            d0, [x0, #7]
    // 0xd908a8: StoreField: r2->field_1b = r0
    //     0xd908a8: stur            w0, [x2, #0x1b]
    // 0xd908ac: ldur            x0, [fp, #-0xb8]
    // 0xd908b0: StoreField: r2->field_1f = r0
    //     0xd908b0: stur            w0, [x2, #0x1f]
    // 0xd908b4: ldur            x0, [fp, #-0xb0]
    // 0xd908b8: StoreField: r2->field_23 = r0
    //     0xd908b8: stur            w0, [x2, #0x23]
    // 0xd908bc: ldur            x0, [fp, #-0xa8]
    // 0xd908c0: StoreField: r2->field_27 = r0
    //     0xd908c0: stur            w0, [x2, #0x27]
    // 0xd908c4: ldur            x0, [fp, #-0xa0]
    // 0xd908c8: StoreField: r2->field_2b = r0
    //     0xd908c8: stur            w0, [x2, #0x2b]
    // 0xd908cc: ldur            x0, [fp, #-0x98]
    // 0xd908d0: StoreField: r2->field_2f = r0
    //     0xd908d0: stur            w0, [x2, #0x2f]
    // 0xd908d4: ldur            x0, [fp, #-0x90]
    // 0xd908d8: StoreField: r2->field_33 = r0
    //     0xd908d8: stur            w0, [x2, #0x33]
    // 0xd908dc: ldur            x0, [fp, #-0x88]
    // 0xd908e0: StoreField: r2->field_37 = r0
    //     0xd908e0: stur            w0, [x2, #0x37]
    // 0xd908e4: ldur            x0, [fp, #-0x80]
    // 0xd908e8: StoreField: r2->field_3b = r0
    //     0xd908e8: stur            w0, [x2, #0x3b]
    // 0xd908ec: ldur            x0, [fp, #-0x78]
    // 0xd908f0: StoreField: r2->field_3f = r0
    //     0xd908f0: stur            w0, [x2, #0x3f]
    // 0xd908f4: ldur            x0, [fp, #-0x10]
    // 0xd908f8: StoreField: r2->field_43 = r0
    //     0xd908f8: stur            w0, [x2, #0x43]
    // 0xd908fc: ldur            x0, [fp, #-0x18]
    // 0xd90900: StoreField: r2->field_47 = r0
    //     0xd90900: stur            w0, [x2, #0x47]
    // 0xd90904: ldur            x0, [fp, #-0x20]
    // 0xd90908: StoreField: r2->field_4b = r0
    //     0xd90908: stur            w0, [x2, #0x4b]
    // 0xd9090c: ldur            x0, [fp, #-0x30]
    // 0xd90910: StoreField: r2->field_4f = r0
    //     0xd90910: stur            w0, [x2, #0x4f]
    // 0xd90914: ldur            x0, [fp, #-0x38]
    // 0xd90918: StoreField: r2->field_53 = r0
    //     0xd90918: stur            w0, [x2, #0x53]
    // 0xd9091c: ldur            x0, [fp, #-0x40]
    // 0xd90920: StoreField: r2->field_57 = r0
    //     0xd90920: stur            w0, [x2, #0x57]
    // 0xd90924: ldur            x0, [fp, #-0x48]
    // 0xd90928: StoreField: r2->field_5b = r0
    //     0xd90928: stur            w0, [x2, #0x5b]
    // 0xd9092c: ldur            x0, [fp, #-0x50]
    // 0xd90930: StoreField: r2->field_5f = r0
    //     0xd90930: stur            w0, [x2, #0x5f]
    // 0xd90934: ldur            x0, [fp, #-0x58]
    // 0xd90938: StoreField: r2->field_63 = r0
    //     0xd90938: stur            w0, [x2, #0x63]
    // 0xd9093c: ldur            x0, [fp, #-0x68]
    // 0xd90940: StoreField: r2->field_67 = r0
    //     0xd90940: stur            w0, [x2, #0x67]
    // 0xd90944: ldur            x0, [fp, #-8]
    // 0xd90948: ldur            x3, [fp, #-0x28]
    // 0xd9094c: StoreField: r3->field_2f = r0
    //     0xd9094c: stur            w0, [x3, #0x2f]
    //     0xd90950: ldurb           w16, [x3, #-1]
    //     0xd90954: ldurb           w17, [x0, #-1]
    //     0xd90958: and             x16, x17, x16, lsr #2
    //     0xd9095c: tst             x16, HEAP, lsr #32
    //     0xd90960: b.eq            #0xd90968
    //     0xd90964: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xd90968: ldur            x0, [fp, #-8]
    // 0xd9096c: LoadField: r4 = r0->field_27
    //     0xd9096c: ldur            w4, [x0, #0x27]
    // 0xd90970: DecompressPointer r4
    //     0xd90970: add             x4, x4, HEAP, lsl #32
    // 0xd90974: LoadField: r0 = r4->field_7
    //     0xd90974: ldur            w0, [x4, #7]
    // 0xd90978: DecompressPointer r0
    //     0xd90978: add             x0, x0, HEAP, lsl #32
    // 0xd9097c: stur            x0, [fp, #-0x10]
    // 0xd90980: LoadField: r4 = r1->field_db
    //     0xd90980: ldur            w4, [x1, #0xdb]
    // 0xd90984: DecompressPointer r4
    //     0xd90984: add             x4, x4, HEAP, lsl #32
    // 0xd90988: stur            x4, [fp, #-8]
    // 0xd9098c: r1 = Function '<anonymous closure>':.
    //     0xd9098c: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a600] AnonymousClosure: (0xd90aec), in [package:flutter/src/material/text_form_field.dart] TextFormField::TextFormField (0xd8ff70)
    //     0xd90990: ldr             x1, [x1, #0x600]
    // 0xd90994: r0 = AllocateClosure()
    //     0xd90994: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd90998: ldur            x1, [fp, #-0x28]
    // 0xd9099c: StoreField: r1->field_f = r0
    //     0xd9099c: stur            w0, [x1, #0xf]
    //     0xd909a0: ldurb           w16, [x1, #-1]
    //     0xd909a4: ldurb           w17, [x0, #-1]
    //     0xd909a8: and             x16, x17, x16, lsr #2
    //     0xd909ac: tst             x16, HEAP, lsr #32
    //     0xd909b0: b.eq            #0xd909b8
    //     0xd909b4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd909b8: ldur            x0, [fp, #-0x70]
    // 0xd909bc: StoreField: r1->field_13 = r0
    //     0xd909bc: stur            w0, [x1, #0x13]
    //     0xd909c0: ldurb           w16, [x1, #-1]
    //     0xd909c4: ldurb           w17, [x0, #-1]
    //     0xd909c8: and             x16, x17, x16, lsr #2
    //     0xd909cc: tst             x16, HEAP, lsr #32
    //     0xd909d0: b.eq            #0xd909d8
    //     0xd909d4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd909d8: ldur            x0, [fp, #-0x60]
    // 0xd909dc: StoreField: r1->field_1b = r0
    //     0xd909dc: stur            w0, [x1, #0x1b]
    //     0xd909e0: ldurb           w16, [x1, #-1]
    //     0xd909e4: ldurb           w17, [x0, #-1]
    //     0xd909e8: and             x16, x17, x16, lsr #2
    //     0xd909ec: tst             x16, HEAP, lsr #32
    //     0xd909f0: b.eq            #0xd909f8
    //     0xd909f4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd909f8: ldur            x0, [fp, #-0x10]
    // 0xd909fc: StoreField: r1->field_1f = r0
    //     0xd909fc: stur            w0, [x1, #0x1f]
    //     0xd90a00: ldurb           w16, [x1, #-1]
    //     0xd90a04: ldurb           w17, [x0, #-1]
    //     0xd90a08: and             x16, x17, x16, lsr #2
    //     0xd90a0c: tst             x16, HEAP, lsr #32
    //     0xd90a10: b.eq            #0xd90a18
    //     0xd90a14: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd90a18: ldur            x2, [fp, #-8]
    // 0xd90a1c: StoreField: r1->field_23 = r2
    //     0xd90a1c: stur            w2, [x1, #0x23]
    // 0xd90a20: r2 = Instance_AutovalidateMode
    //     0xd90a20: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1a608] Obj!AutovalidateMode@12c3061
    //     0xd90a24: ldr             x2, [x2, #0x608]
    // 0xd90a28: StoreField: r1->field_27 = r2
    //     0xd90a28: stur            w2, [x1, #0x27]
    // 0xd90a2c: r0 = Null
    //     0xd90a2c: mov             x0, NULL
    // 0xd90a30: LeaveFrame
    //     0xd90a30: mov             SP, fp
    //     0xd90a34: ldp             fp, lr, [SP], #0x10
    // 0xd90a38: ret
    //     0xd90a38: ret             
    // 0xd90a3c: SaveReg d0
    //     0xd90a3c: str             q0, [SP, #-0x10]!
    // 0xd90a40: stp             x1, x2, [SP, #-0x10]!
    // 0xd90a44: r0 = AllocateDouble()
    //     0xd90a44: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd90a48: ldp             x1, x2, [SP], #0x10
    // 0xd90a4c: RestoreReg d0
    //     0xd90a4c: ldr             q0, [SP], #0x10
    // 0xd90a50: b               #0xd908a4
  }
  [closure] UnmanagedRestorationScope <anonymous closure>(dynamic, FormFieldState<String>) {
    // ** addr: 0xd90aec, size: 0x468
    // 0xd90aec: EnterFrame
    //     0xd90aec: stp             fp, lr, [SP, #-0x10]!
    //     0xd90af0: mov             fp, SP
    // 0xd90af4: AllocStack(0xe8)
    //     0xd90af4: sub             SP, SP, #0xe8
    // 0xd90af8: SetupParameters([dynamic _ /* r0 */])
    //     0xd90af8: ldr             x0, [fp, #0x18]
    //     0xd90afc: ldur            w1, [x0, #0x17]
    //     0xd90b00: add             x1, x1, HEAP, lsl #32
    //     0xd90b04: stur            x1, [fp, #-8]
    // 0xd90b08: CheckStackOverflow
    //     0xd90b08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd90b0c: cmp             SP, x16
    //     0xd90b10: b.ls            #0xd90f48
    // 0xd90b14: r1 = 1
    //     0xd90b14: mov             x1, #1
    // 0xd90b18: r0 = AllocateContext()
    //     0xd90b18: bl              #0x13de838  ; AllocateContextStub
    // 0xd90b1c: mov             x4, x0
    // 0xd90b20: ldur            x3, [fp, #-8]
    // 0xd90b24: stur            x4, [fp, #-0x10]
    // 0xd90b28: StoreField: r4->field_b = r3
    //     0xd90b28: stur            w3, [x4, #0xb]
    // 0xd90b2c: ldr             x5, [fp, #0x10]
    // 0xd90b30: StoreField: r4->field_f = r5
    //     0xd90b30: stur            w5, [x4, #0xf]
    // 0xd90b34: mov             x0, x5
    // 0xd90b38: r2 = Null
    //     0xd90b38: mov             x2, NULL
    // 0xd90b3c: r1 = Null
    //     0xd90b3c: mov             x1, NULL
    // 0xd90b40: r4 = LoadClassIdInstr(r0)
    //     0xd90b40: ldur            x4, [x0, #-1]
    //     0xd90b44: ubfx            x4, x4, #0xc, #0x14
    // 0xd90b48: r17 = 5758
    //     0xd90b48: mov             x17, #0x167e
    // 0xd90b4c: cmp             x4, x17
    // 0xd90b50: b.eq            #0xd90b68
    // 0xd90b54: r8 = _TextFormFieldState
    //     0xd90b54: add             x8, PP, #0x1a, lsl #12  ; [pp+0x1a610] Type: _TextFormFieldState
    //     0xd90b58: ldr             x8, [x8, #0x610]
    // 0xd90b5c: r3 = Null
    //     0xd90b5c: add             x3, PP, #0x1a, lsl #12  ; [pp+0x1a618] Null
    //     0xd90b60: ldr             x3, [x3, #0x618]
    // 0xd90b64: r0 = DefaultTypeTest()
    //     0xd90b64: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xd90b68: ldur            x0, [fp, #-8]
    // 0xd90b6c: LoadField: r2 = r0->field_f
    //     0xd90b6c: ldur            w2, [x0, #0xf]
    // 0xd90b70: DecompressPointer r2
    //     0xd90b70: add             x2, x2, HEAP, lsl #32
    // 0xd90b74: ldr             x3, [fp, #0x10]
    // 0xd90b78: stur            x2, [fp, #-0x18]
    // 0xd90b7c: LoadField: r1 = r3->field_f
    //     0xd90b7c: ldur            w1, [x3, #0xf]
    // 0xd90b80: DecompressPointer r1
    //     0xd90b80: add             x1, x1, HEAP, lsl #32
    // 0xd90b84: cmp             w1, NULL
    // 0xd90b88: b.eq            #0xd90f50
    // 0xd90b8c: r0 = of()
    //     0xd90b8c: bl              #0xd1e0d0  ; [package:flutter/src/material/input_decorator.dart] InputDecorationTheme::of
    // 0xd90b90: ldur            x1, [fp, #-0x18]
    // 0xd90b94: mov             x2, x0
    // 0xd90b98: r0 = applyDefaults()
    //     0xd90b98: bl              #0xd2d7ec  ; [package:flutter/src/material/input_decorator.dart] InputDecoration::applyDefaults
    // 0xd90b9c: ldr             x1, [fp, #0x10]
    // 0xd90ba0: stur            x0, [fp, #-0x18]
    // 0xd90ba4: r0 = errorText()
    //     0xd90ba4: bl              #0xd194cc  ; [package:flutter/src/widgets/form.dart] FormFieldState::errorText
    // 0xd90ba8: cmp             w0, NULL
    // 0xd90bac: b.eq            #0xd90bcc
    // 0xd90bb0: str             x0, [SP]
    // 0xd90bb4: ldur            x1, [fp, #-0x18]
    // 0xd90bb8: r4 = const [0, 0x2, 0x1, 0x1, errorText, 0x1, null]
    //     0xd90bb8: add             x4, PP, #0x1a, lsl #12  ; [pp+0x1a628] List(7) [0, 0x2, 0x1, 0x1, "errorText", 0x1, Null]
    //     0xd90bbc: ldr             x4, [x4, #0x628]
    // 0xd90bc0: r0 = copyWith()
    //     0xd90bc0: bl              #0xd1c914  ; [package:flutter/src/material/input_decorator.dart] InputDecoration::copyWith
    // 0xd90bc4: mov             x2, x0
    // 0xd90bc8: b               #0xd90bd0
    // 0xd90bcc: ldur            x2, [fp, #-0x18]
    // 0xd90bd0: ldur            x0, [fp, #-8]
    // 0xd90bd4: ldr             x1, [fp, #0x10]
    // 0xd90bd8: stur            x2, [fp, #-0x18]
    // 0xd90bdc: r0 = _effectiveController()
    //     0xd90bdc: bl              #0xd90f68  ; [package:flutter/src/material/text_form_field.dart] _TextFormFieldState::_effectiveController
    // 0xd90be0: mov             x1, x0
    // 0xd90be4: ldur            x0, [fp, #-8]
    // 0xd90be8: stur            x1, [fp, #-0x20]
    // 0xd90bec: LoadField: r2 = r0->field_27
    //     0xd90bec: ldur            w2, [x0, #0x27]
    // 0xd90bf0: DecompressPointer r2
    //     0xd90bf0: add             x2, x2, HEAP, lsl #32
    // 0xd90bf4: stur            x2, [fp, #-0x28]
    // 0xd90bf8: LoadField: r3 = r0->field_2f
    //     0xd90bf8: ldur            w3, [x0, #0x2f]
    // 0xd90bfc: DecompressPointer r3
    //     0xd90bfc: add             x3, x3, HEAP, lsl #32
    // 0xd90c00: stur            x3, [fp, #-0x30]
    // 0xd90c04: LoadField: r4 = r0->field_67
    //     0xd90c04: ldur            w4, [x0, #0x67]
    // 0xd90c08: DecompressPointer r4
    //     0xd90c08: add             x4, x4, HEAP, lsl #32
    // 0xd90c0c: stur            x4, [fp, #-0x40]
    // 0xd90c10: LoadField: r5 = r0->field_5b
    //     0xd90c10: ldur            w5, [x0, #0x5b]
    // 0xd90c14: DecompressPointer r5
    //     0xd90c14: add             x5, x5, HEAP, lsl #32
    // 0xd90c18: stur            x5, [fp, #-0x48]
    // 0xd90c1c: LoadField: r6 = r0->field_5f
    //     0xd90c1c: ldur            w6, [x0, #0x5f]
    // 0xd90c20: DecompressPointer r6
    //     0xd90c20: add             x6, x6, HEAP, lsl #32
    // 0xd90c24: stur            x6, [fp, #-0xd8]
    // 0xd90c28: LoadField: r7 = r0->field_63
    //     0xd90c28: ldur            w7, [x0, #0x63]
    // 0xd90c2c: DecompressPointer r7
    //     0xd90c2c: add             x7, x7, HEAP, lsl #32
    // 0xd90c30: stur            x7, [fp, #-0xd0]
    // 0xd90c34: LoadField: r8 = r0->field_13
    //     0xd90c34: ldur            w8, [x0, #0x13]
    // 0xd90c38: DecompressPointer r8
    //     0xd90c38: add             x8, x8, HEAP, lsl #32
    // 0xd90c3c: stur            x8, [fp, #-0xc8]
    // 0xd90c40: LoadField: r9 = r0->field_53
    //     0xd90c40: ldur            w9, [x0, #0x53]
    // 0xd90c44: DecompressPointer r9
    //     0xd90c44: add             x9, x9, HEAP, lsl #32
    // 0xd90c48: stur            x9, [fp, #-0xc0]
    // 0xd90c4c: LoadField: r10 = r0->field_3f
    //     0xd90c4c: ldur            w10, [x0, #0x3f]
    // 0xd90c50: DecompressPointer r10
    //     0xd90c50: add             x10, x10, HEAP, lsl #32
    // 0xd90c54: stur            x10, [fp, #-0xb8]
    // 0xd90c58: LoadField: r11 = r0->field_3b
    //     0xd90c58: ldur            w11, [x0, #0x3b]
    // 0xd90c5c: DecompressPointer r11
    //     0xd90c5c: add             x11, x11, HEAP, lsl #32
    // 0xd90c60: stur            x11, [fp, #-0xb0]
    // 0xd90c64: tbnz            w11, #4, #0xd90c74
    // 0xd90c68: r12 = Instance_SmartDashesType
    //     0xd90c68: add             x12, PP, #0x1a, lsl #12  ; [pp+0x1a630] Obj!SmartDashesType@12c39e1
    //     0xd90c6c: ldr             x12, [x12, #0x630]
    // 0xd90c70: b               #0xd90c7c
    // 0xd90c74: r12 = Instance_SmartDashesType
    //     0xd90c74: add             x12, PP, #0x1a, lsl #12  ; [pp+0x1a638] Obj!SmartDashesType@12c39c1
    //     0xd90c78: ldr             x12, [x12, #0x638]
    // 0xd90c7c: stur            x12, [fp, #-0xa8]
    // 0xd90c80: tbnz            w11, #4, #0xd90c90
    // 0xd90c84: r13 = Instance_SmartQuotesType
    //     0xd90c84: add             x13, PP, #0x1a, lsl #12  ; [pp+0x1a640] Obj!SmartQuotesType@12c39a1
    //     0xd90c88: ldr             x13, [x13, #0x640]
    // 0xd90c8c: b               #0xd90c98
    // 0xd90c90: r13 = Instance_SmartQuotesType
    //     0xd90c90: add             x13, PP, #0x1a, lsl #12  ; [pp+0x1a648] Obj!SmartQuotesType@12c3981
    //     0xd90c94: ldr             x13, [x13, #0x648]
    // 0xd90c98: stur            x13, [fp, #-0xa0]
    // 0xd90c9c: LoadField: r14 = r0->field_37
    //     0xd90c9c: ldur            w14, [x0, #0x37]
    // 0xd90ca0: DecompressPointer r14
    //     0xd90ca0: add             x14, x14, HEAP, lsl #32
    // 0xd90ca4: stur            x14, [fp, #-0x98]
    // 0xd90ca8: LoadField: r19 = r0->field_23
    //     0xd90ca8: ldur            w19, [x0, #0x23]
    // 0xd90cac: DecompressPointer r19
    //     0xd90cac: add             x19, x19, HEAP, lsl #32
    // 0xd90cb0: stur            x19, [fp, #-0x90]
    // 0xd90cb4: LoadField: r20 = r0->field_33
    //     0xd90cb4: ldur            w20, [x0, #0x33]
    // 0xd90cb8: DecompressPointer r20
    //     0xd90cb8: add             x20, x20, HEAP, lsl #32
    // 0xd90cbc: stur            x20, [fp, #-0x88]
    // 0xd90cc0: LoadField: r23 = r0->field_4f
    //     0xd90cc0: ldur            w23, [x0, #0x4f]
    // 0xd90cc4: DecompressPointer r23
    //     0xd90cc4: add             x23, x23, HEAP, lsl #32
    // 0xd90cc8: stur            x23, [fp, #-0x80]
    // 0xd90ccc: LoadField: r24 = r0->field_47
    //     0xd90ccc: ldur            w24, [x0, #0x47]
    // 0xd90cd0: DecompressPointer r24
    //     0xd90cd0: add             x24, x24, HEAP, lsl #32
    // 0xd90cd4: stur            x24, [fp, #-0x78]
    // 0xd90cd8: LoadField: r25 = r0->field_4b
    //     0xd90cd8: ldur            w25, [x0, #0x4b]
    // 0xd90cdc: DecompressPointer r25
    //     0xd90cdc: add             x25, x25, HEAP, lsl #32
    // 0xd90ce0: stur            x25, [fp, #-0x70]
    // 0xd90ce4: LoadField: r1 = r0->field_2b
    //     0xd90ce4: ldur            w1, [x0, #0x2b]
    // 0xd90ce8: DecompressPointer r1
    //     0xd90ce8: add             x1, x1, HEAP, lsl #32
    // 0xd90cec: stur            x1, [fp, #-0x50]
    // 0xd90cf0: LoadField: r2 = r0->field_f
    //     0xd90cf0: ldur            w2, [x0, #0xf]
    // 0xd90cf4: DecompressPointer r2
    //     0xd90cf4: add             x2, x2, HEAP, lsl #32
    // 0xd90cf8: LoadField: r3 = r2->field_db
    //     0xd90cf8: ldur            w3, [x2, #0xdb]
    // 0xd90cfc: DecompressPointer r3
    //     0xd90cfc: add             x3, x3, HEAP, lsl #32
    // 0xd90d00: stur            x3, [fp, #-0x58]
    // 0xd90d04: LoadField: r2 = r0->field_1b
    //     0xd90d04: ldur            w2, [x0, #0x1b]
    // 0xd90d08: DecompressPointer r2
    //     0xd90d08: add             x2, x2, HEAP, lsl #32
    // 0xd90d0c: stur            x2, [fp, #-0x38]
    // 0xd90d10: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xd90d10: ldur            w2, [x0, #0x17]
    // 0xd90d14: DecompressPointer r2
    //     0xd90d14: add             x2, x2, HEAP, lsl #32
    // 0xd90d18: stur            x2, [fp, #-0x60]
    // 0xd90d1c: LoadField: r4 = r0->field_57
    //     0xd90d1c: ldur            w4, [x0, #0x57]
    // 0xd90d20: DecompressPointer r4
    //     0xd90d20: add             x4, x4, HEAP, lsl #32
    // 0xd90d24: stur            x4, [fp, #-0x68]
    // 0xd90d28: LoadField: r5 = r0->field_1f
    //     0xd90d28: ldur            w5, [x0, #0x1f]
    // 0xd90d2c: DecompressPointer r5
    //     0xd90d2c: add             x5, x5, HEAP, lsl #32
    // 0xd90d30: cmp             w5, NULL
    // 0xd90d34: b.ne            #0xd90d4c
    // 0xd90d38: tbz             w11, #4, #0xd90d44
    // 0xd90d3c: r0 = true
    //     0xd90d3c: add             x0, NULL, #0x20  ; true
    // 0xd90d40: b               #0xd90d48
    // 0xd90d44: eor             x0, x9, #0x10
    // 0xd90d48: mov             x5, x0
    // 0xd90d4c: mov             x0, x4
    // 0xd90d50: ldur            x4, [fp, #-0x18]
    // 0xd90d54: mov             x16, x2
    // 0xd90d58: mov             x2, x1
    // 0xd90d5c: mov             x1, x16
    // 0xd90d60: mov             x16, x3
    // 0xd90d64: mov             x3, x2
    // 0xd90d68: mov             x2, x16
    // 0xd90d6c: stur            x5, [fp, #-8]
    // 0xd90d70: r0 = TextField()
    //     0xd90d70: bl              #0xd90f54  ; AllocateTextFieldStub -> TextField (size=0x12c)
    // 0xd90d74: mov             x3, x0
    // 0xd90d78: r0 = EditableText
    //     0xd90d78: ldr             x0, [PP, #0x5370]  ; [pp+0x5370] Type: EditableText
    // 0xd90d7c: stur            x3, [fp, #-0xe0]
    // 0xd90d80: StoreField: r3->field_f = r0
    //     0xd90d80: stur            w0, [x3, #0xf]
    // 0xd90d84: ldur            x0, [fp, #-0x20]
    // 0xd90d88: StoreField: r3->field_13 = r0
    //     0xd90d88: stur            w0, [x3, #0x13]
    // 0xd90d8c: ldur            x0, [fp, #-0x28]
    // 0xd90d90: ArrayStore: r3[0] = r0  ; List_4
    //     0xd90d90: stur            w0, [x3, #0x17]
    // 0xd90d94: ldur            x0, [fp, #-0x18]
    // 0xd90d98: StoreField: r3->field_1b = r0
    //     0xd90d98: stur            w0, [x3, #0x1b]
    // 0xd90d9c: ldur            x0, [fp, #-0x40]
    // 0xd90da0: StoreField: r3->field_23 = r0
    //     0xd90da0: stur            w0, [x3, #0x23]
    // 0xd90da4: r0 = Instance_TextCapitalization
    //     0xd90da4: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a650] Obj!TextCapitalization@12c37c1
    //     0xd90da8: ldr             x0, [x0, #0x650]
    // 0xd90dac: StoreField: r3->field_27 = r0
    //     0xd90dac: stur            w0, [x3, #0x27]
    // 0xd90db0: ldur            x0, [fp, #-0x48]
    // 0xd90db4: StoreField: r3->field_2b = r0
    //     0xd90db4: stur            w0, [x3, #0x2b]
    // 0xd90db8: ldur            x0, [fp, #-0xd8]
    // 0xd90dbc: StoreField: r3->field_33 = r0
    //     0xd90dbc: stur            w0, [x3, #0x33]
    // 0xd90dc0: ldur            x0, [fp, #-0xd0]
    // 0xd90dc4: StoreField: r3->field_37 = r0
    //     0xd90dc4: stur            w0, [x3, #0x37]
    // 0xd90dc8: ldur            x0, [fp, #-0xc0]
    // 0xd90dcc: StoreField: r3->field_6b = r0
    //     0xd90dcc: stur            w0, [x3, #0x6b]
    // 0xd90dd0: ldur            x0, [fp, #-0xc8]
    // 0xd90dd4: StoreField: r3->field_3f = r0
    //     0xd90dd4: stur            w0, [x3, #0x3f]
    // 0xd90dd8: ldur            x0, [fp, #-0xb8]
    // 0xd90ddc: StoreField: r3->field_47 = r0
    //     0xd90ddc: stur            w0, [x3, #0x47]
    // 0xd90de0: ldur            x0, [fp, #-0xb0]
    // 0xd90de4: StoreField: r3->field_4b = r0
    //     0xd90de4: stur            w0, [x3, #0x4b]
    // 0xd90de8: r0 = true
    //     0xd90de8: add             x0, NULL, #0x20  ; true
    // 0xd90dec: StoreField: r3->field_4f = r0
    //     0xd90dec: stur            w0, [x3, #0x4f]
    // 0xd90df0: StoreField: r3->field_5b = r0
    //     0xd90df0: stur            w0, [x3, #0x5b]
    // 0xd90df4: ldur            x4, [fp, #-0x98]
    // 0xd90df8: StoreField: r3->field_5f = r4
    //     0xd90df8: stur            w4, [x3, #0x5f]
    // 0xd90dfc: ldur            x1, [fp, #-0x90]
    // 0xd90e00: StoreField: r3->field_67 = r1
    //     0xd90e00: stur            w1, [x3, #0x67]
    // 0xd90e04: ldur            x1, [fp, #-0x88]
    // 0xd90e08: StoreField: r3->field_77 = r1
    //     0xd90e08: stur            w1, [x3, #0x77]
    // 0xd90e0c: ldur            x2, [fp, #-0x10]
    // 0xd90e10: r1 = Function 'onChangedHandler':.
    //     0xd90e10: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a658] AnonymousClosure: (0xd93b68), in [package:flutter/src/material/text_form_field.dart] TextFormField::TextFormField (0xd8ff70)
    //     0xd90e14: ldr             x1, [x1, #0x658]
    // 0xd90e18: r0 = AllocateClosure()
    //     0xd90e18: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd90e1c: mov             x1, x0
    // 0xd90e20: ldur            x0, [fp, #-0xe0]
    // 0xd90e24: StoreField: r0->field_7f = r1
    //     0xd90e24: stur            w1, [x0, #0x7f]
    // 0xd90e28: ldur            x1, [fp, #-0x78]
    // 0xd90e2c: StoreField: r0->field_83 = r1
    //     0xd90e2c: stur            w1, [x0, #0x83]
    // 0xd90e30: ldur            x1, [fp, #-0x70]
    // 0xd90e34: StoreField: r0->field_87 = r1
    //     0xd90e34: stur            w1, [x0, #0x87]
    // 0xd90e38: ldur            x1, [fp, #-0x50]
    // 0xd90e3c: StoreField: r0->field_8f = r1
    //     0xd90e3c: stur            w1, [x0, #0x8f]
    // 0xd90e40: ldur            x1, [fp, #-0x58]
    // 0xd90e44: StoreField: r0->field_93 = r1
    //     0xd90e44: stur            w1, [x0, #0x93]
    // 0xd90e48: ldur            x1, [fp, #-0x38]
    // 0xd90e4c: LoadField: d0 = r1->field_7
    //     0xd90e4c: ldur            d0, [x1, #7]
    // 0xd90e50: StoreField: r0->field_9b = d0
    //     0xd90e50: stur            d0, [x0, #0x9b]
    // 0xd90e54: ldur            x1, [fp, #-0x60]
    // 0xd90e58: StoreField: r0->field_af = r1
    //     0xd90e58: stur            w1, [x0, #0xaf]
    // 0xd90e5c: r1 = Instance_BoxHeightStyle
    //     0xd90e5c: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a660] Obj!BoxHeightStyle@12c7321
    //     0xd90e60: ldr             x1, [x1, #0x660]
    // 0xd90e64: StoreField: r0->field_b7 = r1
    //     0xd90e64: stur            w1, [x0, #0xb7]
    // 0xd90e68: r1 = Instance_BoxWidthStyle
    //     0xd90e68: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a668] Obj!BoxWidthStyle@12c72e1
    //     0xd90e6c: ldr             x1, [x1, #0x668]
    // 0xd90e70: StoreField: r0->field_bb = r1
    //     0xd90e70: stur            w1, [x0, #0xbb]
    // 0xd90e74: r1 = Instance_EdgeInsets
    //     0xd90e74: ldr             x1, [PP, #0x5648]  ; [pp+0x5648] Obj!EdgeInsets@129cc61
    // 0xd90e78: StoreField: r0->field_c3 = r1
    //     0xd90e78: stur            w1, [x0, #0xc3]
    // 0xd90e7c: r1 = Instance_DragStartBehavior
    //     0xd90e7c: ldr             x1, [PP, #0x5360]  ; [pp+0x5360] Obj!DragStartBehavior@12c5c61
    // 0xd90e80: StoreField: r0->field_d3 = r1
    //     0xd90e80: stur            w1, [x0, #0xd3]
    // 0xd90e84: ldur            x1, [fp, #-0x80]
    // 0xd90e88: StoreField: r0->field_d7 = r1
    //     0xd90e88: stur            w1, [x0, #0xd7]
    // 0xd90e8c: r1 = false
    //     0xd90e8c: add             x1, NULL, #0x30  ; false
    // 0xd90e90: StoreField: r0->field_db = r1
    //     0xd90e90: stur            w1, [x0, #0xdb]
    // 0xd90e94: ldur            x1, [fp, #-0x68]
    // 0xd90e98: StoreField: r0->field_ef = r1
    //     0xd90e98: stur            w1, [x0, #0xef]
    // 0xd90e9c: r1 = Instance_Clip
    //     0xd90e9c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xd90ea0: ldr             x1, [x1, #0x850]
    // 0xd90ea4: StoreField: r0->field_fb = r1
    //     0xd90ea4: stur            w1, [x0, #0xfb]
    // 0xd90ea8: r1 = true
    //     0xd90ea8: add             x1, NULL, #0x20  ; true
    // 0xd90eac: r17 = 259
    //     0xd90eac: mov             x17, #0x103
    // 0xd90eb0: str             w1, [x0, x17]
    // 0xd90eb4: r17 = 263
    //     0xd90eb4: mov             x17, #0x107
    // 0xd90eb8: str             w1, [x0, x17]
    // 0xd90ebc: r17 = 267
    //     0xd90ebc: mov             x17, #0x10b
    // 0xd90ec0: str             w1, [x0, x17]
    // 0xd90ec4: r2 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@665147271': static.
    //     0xd90ec4: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1a670] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@665147271': static. (0x7f2adac78040)
    //     0xd90ec8: ldr             x2, [x2, #0x670]
    // 0xd90ecc: r17 = 279
    //     0xd90ecc: mov             x17, #0x117
    // 0xd90ed0: str             w2, [x0, x17]
    // 0xd90ed4: r17 = 283
    //     0xd90ed4: mov             x17, #0x11b
    // 0xd90ed8: str             w1, [x0, x17]
    // 0xd90edc: ldur            x1, [fp, #-0xa8]
    // 0xd90ee0: StoreField: r0->field_53 = r1
    //     0xd90ee0: stur            w1, [x0, #0x53]
    // 0xd90ee4: ldur            x1, [fp, #-0xa0]
    // 0xd90ee8: StoreField: r0->field_57 = r1
    //     0xd90ee8: stur            w1, [x0, #0x57]
    // 0xd90eec: ldur            x1, [fp, #-0x30]
    // 0xd90ef0: cmp             w1, NULL
    // 0xd90ef4: b.ne            #0xd90f20
    // 0xd90ef8: ldur            x1, [fp, #-0x98]
    // 0xd90efc: cmp             w1, #2
    // 0xd90f00: b.ne            #0xd90f10
    // 0xd90f04: r1 = Instance_TextInputType
    //     0xd90f04: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a678] Obj!TextInputType@129b841
    //     0xd90f08: ldr             x1, [x1, #0x678]
    // 0xd90f0c: b               #0xd90f18
    // 0xd90f10: r1 = Instance_TextInputType
    //     0xd90f10: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a680] Obj!TextInputType@129b821
    //     0xd90f14: ldr             x1, [x1, #0x680]
    // 0xd90f18: mov             x2, x1
    // 0xd90f1c: b               #0xd90f24
    // 0xd90f20: mov             x2, x1
    // 0xd90f24: ldur            x1, [fp, #-8]
    // 0xd90f28: StoreField: r0->field_1f = r2
    //     0xd90f28: stur            w2, [x0, #0x1f]
    // 0xd90f2c: StoreField: r0->field_c7 = r1
    //     0xd90f2c: stur            w1, [x0, #0xc7]
    // 0xd90f30: r0 = UnmanagedRestorationScope()
    //     0xd90f30: bl              #0xd47c2c  ; AllocateUnmanagedRestorationScopeStub -> UnmanagedRestorationScope (size=0x14)
    // 0xd90f34: ldur            x1, [fp, #-0xe0]
    // 0xd90f38: StoreField: r0->field_b = r1
    //     0xd90f38: stur            w1, [x0, #0xb]
    // 0xd90f3c: LeaveFrame
    //     0xd90f3c: mov             SP, fp
    //     0xd90f40: ldp             fp, lr, [SP], #0x10
    // 0xd90f44: ret
    //     0xd90f44: ret             
    // 0xd90f48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd90f48: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd90f4c: b               #0xd90b14
    // 0xd90f50: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd90f50: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] static Widget _defaultContextMenuBuilder(dynamic, BuildContext, EditableTextState) {
    // ** addr: 0xd91040, size: 0x34
    // 0xd91040: EnterFrame
    //     0xd91040: stp             fp, lr, [SP, #-0x10]!
    //     0xd91044: mov             fp, SP
    // 0xd91048: CheckStackOverflow
    //     0xd91048: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd9104c: cmp             SP, x16
    //     0xd91050: b.ls            #0xd9106c
    // 0xd91054: ldr             x1, [fp, #0x18]
    // 0xd91058: ldr             x2, [fp, #0x10]
    // 0xd9105c: r0 = _defaultContextMenuBuilder()
    //     0xd9105c: bl              #0xd91074  ; [package:flutter/src/material/text_field.dart] TextField::_defaultContextMenuBuilder
    // 0xd91060: LeaveFrame
    //     0xd91060: mov             SP, fp
    //     0xd91064: ldp             fp, lr, [SP], #0x10
    // 0xd91068: ret
    //     0xd91068: ret             
    // 0xd9106c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd9106c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd91070: b               #0xd91054
  }
  [closure] void onChangedHandler(dynamic, String) {
    // ** addr: 0xd93b68, size: 0x80
    // 0xd93b68: EnterFrame
    //     0xd93b68: stp             fp, lr, [SP, #-0x10]!
    //     0xd93b6c: mov             fp, SP
    // 0xd93b70: AllocStack(0x18)
    //     0xd93b70: sub             SP, SP, #0x18
    // 0xd93b74: SetupParameters([dynamic _ /* r0 */])
    //     0xd93b74: ldr             x0, [fp, #0x18]
    //     0xd93b78: ldur            w3, [x0, #0x17]
    //     0xd93b7c: add             x3, x3, HEAP, lsl #32
    //     0xd93b80: stur            x3, [fp, #-8]
    // 0xd93b84: CheckStackOverflow
    //     0xd93b84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd93b88: cmp             SP, x16
    //     0xd93b8c: b.ls            #0xd93be0
    // 0xd93b90: LoadField: r1 = r3->field_f
    //     0xd93b90: ldur            w1, [x3, #0xf]
    // 0xd93b94: DecompressPointer r1
    //     0xd93b94: add             x1, x1, HEAP, lsl #32
    // 0xd93b98: ldr             x2, [fp, #0x10]
    // 0xd93b9c: r0 = didChange()
    //     0xd93b9c: bl              #0xd93be8  ; [package:flutter/src/material/text_form_field.dart] _TextFormFieldState::didChange
    // 0xd93ba0: ldur            x0, [fp, #-8]
    // 0xd93ba4: LoadField: r1 = r0->field_b
    //     0xd93ba4: ldur            w1, [x0, #0xb]
    // 0xd93ba8: DecompressPointer r1
    //     0xd93ba8: add             x1, x1, HEAP, lsl #32
    // 0xd93bac: LoadField: r0 = r1->field_43
    //     0xd93bac: ldur            w0, [x1, #0x43]
    // 0xd93bb0: DecompressPointer r0
    //     0xd93bb0: add             x0, x0, HEAP, lsl #32
    // 0xd93bb4: cmp             w0, NULL
    // 0xd93bb8: b.eq            #0xd93bd0
    // 0xd93bbc: ldr             x16, [fp, #0x10]
    // 0xd93bc0: stp             x16, x0, [SP]
    // 0xd93bc4: ClosureCall
    //     0xd93bc4: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xd93bc8: ldur            x2, [x0, #0x1f]
    //     0xd93bcc: blr             x2
    // 0xd93bd0: r0 = Null
    //     0xd93bd0: mov             x0, NULL
    // 0xd93bd4: LeaveFrame
    //     0xd93bd4: mov             SP, fp
    //     0xd93bd8: ldp             fp, lr, [SP], #0x10
    // 0xd93bdc: ret
    //     0xd93bdc: ret             
    // 0xd93be0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd93be0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd93be4: b               #0xd93b90
  }
  _ createState(/* No info */) {
    // ** addr: 0xfa1814, size: 0x54
    // 0xfa1814: EnterFrame
    //     0xfa1814: stp             fp, lr, [SP, #-0x10]!
    //     0xfa1818: mov             fp, SP
    // 0xfa181c: AllocStack(0x8)
    //     0xfa181c: sub             SP, SP, #8
    // 0xfa1820: CheckStackOverflow
    //     0xfa1820: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa1824: cmp             SP, x16
    //     0xfa1828: b.ls            #0xfa1860
    // 0xfa182c: r1 = <FormField<String>, String>
    //     0xfa182c: add             x1, PP, #0x80, lsl #12  ; [pp+0x80a98] TypeArguments: <FormField<String>, String>
    //     0xfa1830: ldr             x1, [x1, #0xa98]
    // 0xfa1834: r0 = _TextFormFieldState()
    //     0xfa1834: bl              #0xfa1868  ; Allocate_TextFormFieldStateStub -> _TextFormFieldState (size=0x3c)
    // 0xfa1838: mov             x2, x0
    // 0xfa183c: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa1840: stur            x2, [fp, #-8]
    // 0xfa1844: StoreField: r2->field_37 = r0
    //     0xfa1844: stur            w0, [x2, #0x37]
    // 0xfa1848: mov             x1, x2
    // 0xfa184c: r0 = FormFieldState()
    //     0xfa184c: bl              #0xfa16d4  ; [package:flutter/src/widgets/form.dart] FormFieldState::FormFieldState
    // 0xfa1850: ldur            x0, [fp, #-8]
    // 0xfa1854: LeaveFrame
    //     0xfa1854: mov             SP, fp
    //     0xfa1858: ldp             fp, lr, [SP], #0x10
    // 0xfa185c: ret
    //     0xfa185c: ret             
    // 0xfa1860: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa1860: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa1864: b               #0xfa182c
  }
}
