// lib: , url: package:flutter/src/material/radio.dart

// class id: 1048933, size: 0x8
class :: {
}

// class id: 4513, size: 0x74, field offset: 0x60
class _RadioPainter extends ToggleablePainter {

  _ paint(/* No info */) {
    // ** addr: 0xb6c4b8, size: 0x2e8
    // 0xb6c4b8: EnterFrame
    //     0xb6c4b8: stp             fp, lr, [SP, #-0x10]!
    //     0xb6c4bc: mov             fp, SP
    // 0xb6c4c0: AllocStack(0x50)
    //     0xb6c4c0: sub             SP, SP, #0x50
    // 0xb6c4c4: SetupParameters(_RadioPainter this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r0, fp-0x18 */)
    //     0xb6c4c4: mov             x0, x3
    //     0xb6c4c8: stur            x3, [fp, #-0x18]
    //     0xb6c4cc: mov             x3, x1
    //     0xb6c4d0: stur            x1, [fp, #-8]
    //     0xb6c4d4: stur            x2, [fp, #-0x10]
    // 0xb6c4d8: CheckStackOverflow
    //     0xb6c4d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb6c4dc: cmp             SP, x16
    //     0xb6c4e0: b.ls            #0xb6c768
    // 0xb6c4e4: mov             x1, x0
    // 0xb6c4e8: r0 = center()
    //     0xb6c4e8: bl              #0xaf9a1c  ; [dart:ui] Size::center
    // 0xb6c4ec: ldur            x1, [fp, #-8]
    // 0xb6c4f0: ldur            x2, [fp, #-0x10]
    // 0xb6c4f4: mov             x3, x0
    // 0xb6c4f8: r0 = paintRadialReaction()
    //     0xb6c4f8: bl              #0xb6c1b8  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::paintRadialReaction
    // 0xb6c4fc: ldur            x2, [fp, #-0x18]
    // 0xb6c500: r1 = Instance_Offset
    //     0xb6c500: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xb6c504: r0 = &()
    //     0xb6c504: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xb6c508: mov             x1, x0
    // 0xb6c50c: r0 = center()
    //     0xb6c50c: bl              #0x869350  ; [dart:ui] Rect::center
    // 0xb6c510: mov             x1, x0
    // 0xb6c514: r2 = Instance_Size
    //     0xb6c514: add             x2, PP, #0xd4, lsl #12  ; [pp+0xd4fe0] Obj!Size@12a7591
    //     0xb6c518: ldr             x2, [x2, #0xfe0]
    // 0xb6c51c: stur            x0, [fp, #-0x18]
    // 0xb6c520: r0 = &()
    //     0xb6c520: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xb6c524: mov             x1, x0
    // 0xb6c528: d0 = -8.000000
    //     0xb6c528: fmov            d0, #-8.00000000
    // 0xb6c52c: d1 = -8.000000
    //     0xb6c52c: fmov            d1, #-8.00000000
    // 0xb6c530: r0 = translate()
    //     0xb6c530: bl              #0xb6c7ac  ; [dart:ui] Rect::translate
    // 0xb6c534: stur            x0, [fp, #-0x20]
    // 0xb6c538: r16 = 136
    //     0xb6c538: mov             x16, #0x88
    // 0xb6c53c: stp             x16, NULL, [SP]
    // 0xb6c540: r0 = ByteData()
    //     0xb6c540: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xb6c544: stur            x0, [fp, #-0x28]
    // 0xb6c548: r0 = Paint()
    //     0xb6c548: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xb6c54c: mov             x2, x0
    // 0xb6c550: ldur            x0, [fp, #-0x28]
    // 0xb6c554: stur            x2, [fp, #-0x40]
    // 0xb6c558: StoreField: r2->field_7 = r0
    //     0xb6c558: stur            w0, [x2, #7]
    // 0xb6c55c: ldur            x3, [fp, #-8]
    // 0xb6c560: LoadField: r4 = r3->field_5f
    //     0xb6c560: ldur            w4, [x3, #0x5f]
    // 0xb6c564: DecompressPointer r4
    //     0xb6c564: add             x4, x4, HEAP, lsl #32
    // 0xb6c568: stur            x4, [fp, #-0x38]
    // 0xb6c56c: cmp             w4, NULL
    // 0xb6c570: b.eq            #0xb6c770
    // 0xb6c574: LoadField: r5 = r3->field_63
    //     0xb6c574: ldur            w5, [x3, #0x63]
    // 0xb6c578: DecompressPointer r5
    //     0xb6c578: add             x5, x5, HEAP, lsl #32
    // 0xb6c57c: stur            x5, [fp, #-0x30]
    // 0xb6c580: cmp             w5, NULL
    // 0xb6c584: b.eq            #0xb6c774
    // 0xb6c588: LoadField: r1 = r3->field_23
    //     0xb6c588: ldur            w1, [x3, #0x23]
    // 0xb6c58c: DecompressPointer r1
    //     0xb6c58c: add             x1, x1, HEAP, lsl #32
    // 0xb6c590: cmp             w1, NULL
    // 0xb6c594: b.eq            #0xb6c778
    // 0xb6c598: r0 = value()
    //     0xb6c598: bl              #0xae5f84  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::value
    // 0xb6c59c: ldur            x1, [fp, #-0x38]
    // 0xb6c5a0: ldur            x2, [fp, #-0x30]
    // 0xb6c5a4: mov             x3, x0
    // 0xb6c5a8: r0 = lerp()
    //     0xb6c5a8: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0xb6c5ac: ldur            x1, [fp, #-0x40]
    // 0xb6c5b0: mov             x2, x0
    // 0xb6c5b4: r0 = color=()
    //     0xb6c5b4: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xb6c5b8: ldur            x0, [fp, #-0x28]
    // 0xb6c5bc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb6c5bc: ldur            w1, [x0, #0x17]
    // 0xb6c5c0: DecompressPointer r1
    //     0xb6c5c0: add             x1, x1, HEAP, lsl #32
    // 0xb6c5c4: LoadField: r0 = r1->field_7
    //     0xb6c5c4: ldur            x0, [x1, #7]
    // 0xb6c5c8: str             wzr, [x0, #0x1c]
    // 0xb6c5cc: ldur            x1, [fp, #-0x10]
    // 0xb6c5d0: ldur            x2, [fp, #-0x18]
    // 0xb6c5d4: ldur            x3, [fp, #-0x40]
    // 0xb6c5d8: d0 = 8.000000
    //     0xb6c5d8: fmov            d0, #8.00000000
    // 0xb6c5dc: r0 = drawCircle()
    //     0xb6c5dc: bl              #0xb6acd4  ; [dart:ui] _NativeCanvas::drawCircle
    // 0xb6c5e0: ldur            x0, [fp, #-8]
    // 0xb6c5e4: LoadField: r2 = r0->field_67
    //     0xb6c5e4: ldur            w2, [x0, #0x67]
    // 0xb6c5e8: DecompressPointer r2
    //     0xb6c5e8: add             x2, x2, HEAP, lsl #32
    // 0xb6c5ec: stur            x2, [fp, #-0x30]
    // 0xb6c5f0: cmp             w2, NULL
    // 0xb6c5f4: b.eq            #0xb6c77c
    // 0xb6c5f8: LoadField: r3 = r0->field_6b
    //     0xb6c5f8: ldur            w3, [x0, #0x6b]
    // 0xb6c5fc: DecompressPointer r3
    //     0xb6c5fc: add             x3, x3, HEAP, lsl #32
    // 0xb6c600: stur            x3, [fp, #-0x28]
    // 0xb6c604: cmp             w3, NULL
    // 0xb6c608: b.eq            #0xb6c780
    // 0xb6c60c: LoadField: r1 = r0->field_23
    //     0xb6c60c: ldur            w1, [x0, #0x23]
    // 0xb6c610: DecompressPointer r1
    //     0xb6c610: add             x1, x1, HEAP, lsl #32
    // 0xb6c614: cmp             w1, NULL
    // 0xb6c618: b.eq            #0xb6c784
    // 0xb6c61c: r0 = value()
    //     0xb6c61c: bl              #0xae5f84  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::value
    // 0xb6c620: LoadField: d0 = r0->field_7
    //     0xb6c620: ldur            d0, [x0, #7]
    // 0xb6c624: ldur            x1, [fp, #-0x30]
    // 0xb6c628: ldur            x2, [fp, #-0x28]
    // 0xb6c62c: r0 = lerp()
    //     0xb6c62c: bl              #0xa07be0  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0xb6c630: stur            x0, [fp, #-0x28]
    // 0xb6c634: r0 = CircleBorder()
    //     0xb6c634: bl              #0xb6c7a0  ; AllocateCircleBorderStub -> CircleBorder (size=0x14)
    // 0xb6c638: StoreField: r0->field_b = rZR
    //     0xb6c638: stur            xzr, [x0, #0xb]
    // 0xb6c63c: ldur            x1, [fp, #-0x28]
    // 0xb6c640: StoreField: r0->field_7 = r1
    //     0xb6c640: stur            w1, [x0, #7]
    // 0xb6c644: mov             x1, x0
    // 0xb6c648: ldur            x2, [fp, #-0x10]
    // 0xb6c64c: ldur            x3, [fp, #-0x20]
    // 0xb6c650: r4 = const [0, 0x3, 0, 0x3, null]
    //     0xb6c650: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0xb6c654: r0 = paint()
    //     0xb6c654: bl              #0x12ed644  ; [package:flutter/src/painting/circle_border.dart] CircleBorder::paint
    // 0xb6c658: ldur            x0, [fp, #-8]
    // 0xb6c65c: LoadField: r1 = r0->field_23
    //     0xb6c65c: ldur            w1, [x0, #0x23]
    // 0xb6c660: DecompressPointer r1
    //     0xb6c660: add             x1, x1, HEAP, lsl #32
    // 0xb6c664: cmp             w1, NULL
    // 0xb6c668: b.eq            #0xb6c788
    // 0xb6c66c: r0 = status()
    //     0xb6c66c: bl              #0x1284c0c  ; [dart:mixin_deduplication] _MixinApplication113&Animation&AnimationWithParentMixin::status
    // 0xb6c670: r16 = Instance_AnimationStatus
    //     0xb6c670: ldr             x16, [PP, #0x51a8]  ; [pp+0x51a8] Obj!AnimationStatus@12c61c1
    // 0xb6c674: cmp             w0, w16
    // 0xb6c678: b.eq            #0xb6c758
    // 0xb6c67c: ldur            x0, [fp, #-8]
    // 0xb6c680: r16 = 136
    //     0xb6c680: mov             x16, #0x88
    // 0xb6c684: stp             x16, NULL, [SP]
    // 0xb6c688: r0 = ByteData()
    //     0xb6c688: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xb6c68c: stur            x0, [fp, #-0x20]
    // 0xb6c690: r0 = Paint()
    //     0xb6c690: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xb6c694: mov             x2, x0
    // 0xb6c698: ldur            x0, [fp, #-0x20]
    // 0xb6c69c: stur            x2, [fp, #-0x30]
    // 0xb6c6a0: StoreField: r2->field_7 = r0
    //     0xb6c6a0: stur            w0, [x2, #7]
    // 0xb6c6a4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb6c6a4: ldur            w1, [x0, #0x17]
    // 0xb6c6a8: DecompressPointer r1
    //     0xb6c6a8: add             x1, x1, HEAP, lsl #32
    // 0xb6c6ac: LoadField: r0 = r1->field_7
    //     0xb6c6ac: ldur            x0, [x1, #7]
    // 0xb6c6b0: str             wzr, [x0, #0x1c]
    // 0xb6c6b4: ldur            x0, [fp, #-8]
    // 0xb6c6b8: LoadField: r3 = r0->field_37
    //     0xb6c6b8: ldur            w3, [x0, #0x37]
    // 0xb6c6bc: DecompressPointer r3
    //     0xb6c6bc: add             x3, x3, HEAP, lsl #32
    // 0xb6c6c0: stur            x3, [fp, #-0x28]
    // 0xb6c6c4: cmp             w3, NULL
    // 0xb6c6c8: b.eq            #0xb6c78c
    // 0xb6c6cc: LoadField: r4 = r0->field_33
    //     0xb6c6cc: ldur            w4, [x0, #0x33]
    // 0xb6c6d0: DecompressPointer r4
    //     0xb6c6d0: add             x4, x4, HEAP, lsl #32
    // 0xb6c6d4: stur            x4, [fp, #-0x20]
    // 0xb6c6d8: cmp             w4, NULL
    // 0xb6c6dc: b.eq            #0xb6c790
    // 0xb6c6e0: LoadField: r1 = r0->field_23
    //     0xb6c6e0: ldur            w1, [x0, #0x23]
    // 0xb6c6e4: DecompressPointer r1
    //     0xb6c6e4: add             x1, x1, HEAP, lsl #32
    // 0xb6c6e8: cmp             w1, NULL
    // 0xb6c6ec: b.eq            #0xb6c794
    // 0xb6c6f0: r0 = value()
    //     0xb6c6f0: bl              #0xae5f84  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::value
    // 0xb6c6f4: ldur            x1, [fp, #-0x28]
    // 0xb6c6f8: ldur            x2, [fp, #-0x20]
    // 0xb6c6fc: mov             x3, x0
    // 0xb6c700: r0 = lerp()
    //     0xb6c700: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0xb6c704: ldur            x1, [fp, #-0x30]
    // 0xb6c708: mov             x2, x0
    // 0xb6c70c: r0 = color=()
    //     0xb6c70c: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xb6c710: ldur            x0, [fp, #-8]
    // 0xb6c714: LoadField: r1 = r0->field_6f
    //     0xb6c714: ldur            w1, [x0, #0x6f]
    // 0xb6c718: DecompressPointer r1
    //     0xb6c718: add             x1, x1, HEAP, lsl #32
    // 0xb6c71c: cmp             w1, NULL
    // 0xb6c720: b.eq            #0xb6c798
    // 0xb6c724: LoadField: r1 = r0->field_23
    //     0xb6c724: ldur            w1, [x0, #0x23]
    // 0xb6c728: DecompressPointer r1
    //     0xb6c728: add             x1, x1, HEAP, lsl #32
    // 0xb6c72c: cmp             w1, NULL
    // 0xb6c730: b.eq            #0xb6c79c
    // 0xb6c734: r0 = value()
    //     0xb6c734: bl              #0xae5f84  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::value
    // 0xb6c738: LoadField: d0 = r0->field_7
    //     0xb6c738: ldur            d0, [x0, #7]
    // 0xb6c73c: d1 = 4.500000
    //     0xb6c73c: fmov            d1, #4.50000000
    // 0xb6c740: fmul            d2, d0, d1
    // 0xb6c744: ldur            x1, [fp, #-0x10]
    // 0xb6c748: ldur            x2, [fp, #-0x18]
    // 0xb6c74c: mov             v0.16b, v2.16b
    // 0xb6c750: ldur            x3, [fp, #-0x30]
    // 0xb6c754: r0 = drawCircle()
    //     0xb6c754: bl              #0xb6acd4  ; [dart:ui] _NativeCanvas::drawCircle
    // 0xb6c758: r0 = Null
    //     0xb6c758: mov             x0, NULL
    // 0xb6c75c: LeaveFrame
    //     0xb6c75c: mov             SP, fp
    //     0xb6c760: ldp             fp, lr, [SP], #0x10
    // 0xb6c764: ret
    //     0xb6c764: ret             
    // 0xb6c768: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb6c768: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb6c76c: b               #0xb6c4e4
    // 0xb6c770: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6c770: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6c774: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6c774: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6c778: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6c778: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6c77c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6c77c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6c780: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6c780: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6c784: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6c784: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6c788: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6c788: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6c78c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6c78c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6c790: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6c790: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6c794: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6c794: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6c798: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6c798: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb6c79c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6c79c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ innerRadius=(/* No info */) {
    // ** addr: 0xdfab1c, size: 0x88
    // 0xdfab1c: EnterFrame
    //     0xdfab1c: stp             fp, lr, [SP, #-0x10]!
    //     0xdfab20: mov             fp, SP
    // 0xdfab24: AllocStack(0x18)
    //     0xdfab24: sub             SP, SP, #0x18
    // 0xdfab28: SetupParameters(_RadioPainter this /* r1 => r1, fp-0x8 */)
    //     0xdfab28: stur            x1, [fp, #-8]
    // 0xdfab2c: CheckStackOverflow
    //     0xdfab2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdfab30: cmp             SP, x16
    //     0xdfab34: b.ls            #0xdfab9c
    // 0xdfab38: LoadField: r0 = r1->field_6f
    //     0xdfab38: ldur            w0, [x1, #0x6f]
    // 0xdfab3c: DecompressPointer r0
    //     0xdfab3c: add             x0, x0, HEAP, lsl #32
    // 0xdfab40: r2 = LoadClassIdInstr(r0)
    //     0xdfab40: ldur            x2, [x0, #-1]
    //     0xdfab44: ubfx            x2, x2, #0xc, #0x14
    // 0xdfab48: r16 = 4.500000
    //     0xdfab48: add             x16, PP, #0xd4, lsl #12  ; [pp+0xd4ff0] 4.5
    //     0xdfab4c: ldr             x16, [x16, #0xff0]
    // 0xdfab50: stp             x16, x0, [SP]
    // 0xdfab54: mov             x0, x2
    // 0xdfab58: mov             lr, x0
    // 0xdfab5c: ldr             lr, [x21, lr, lsl #3]
    // 0xdfab60: blr             lr
    // 0xdfab64: tbnz            w0, #4, #0xdfab78
    // 0xdfab68: r0 = Null
    //     0xdfab68: mov             x0, NULL
    // 0xdfab6c: LeaveFrame
    //     0xdfab6c: mov             SP, fp
    //     0xdfab70: ldp             fp, lr, [SP], #0x10
    // 0xdfab74: ret
    //     0xdfab74: ret             
    // 0xdfab78: ldur            x1, [fp, #-8]
    // 0xdfab7c: r0 = 4.500000
    //     0xdfab7c: add             x0, PP, #0xd4, lsl #12  ; [pp+0xd4ff0] 4.5
    //     0xdfab80: ldr             x0, [x0, #0xff0]
    // 0xdfab84: StoreField: r1->field_6f = r0
    //     0xdfab84: stur            w0, [x1, #0x6f]
    // 0xdfab88: r0 = notifyListeners()
    //     0xdfab88: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xdfab8c: r0 = Null
    //     0xdfab8c: mov             x0, NULL
    // 0xdfab90: LeaveFrame
    //     0xdfab90: mov             SP, fp
    //     0xdfab94: ldp             fp, lr, [SP], #0x10
    // 0xdfab98: ret
    //     0xdfab98: ret             
    // 0xdfab9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdfab9c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdfaba0: b               #0xdfab38
  }
  set _ inactiveSide=(/* No info */) {
    // ** addr: 0xdfaba4, size: 0xa4
    // 0xdfaba4: EnterFrame
    //     0xdfaba4: stp             fp, lr, [SP, #-0x10]!
    //     0xdfaba8: mov             fp, SP
    // 0xdfabac: AllocStack(0x20)
    //     0xdfabac: sub             SP, SP, #0x20
    // 0xdfabb0: SetupParameters(_RadioPainter this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xdfabb0: stur            x1, [fp, #-8]
    //     0xdfabb4: mov             x16, x2
    //     0xdfabb8: mov             x2, x1
    //     0xdfabbc: mov             x1, x16
    //     0xdfabc0: stur            x1, [fp, #-0x10]
    // 0xdfabc4: CheckStackOverflow
    //     0xdfabc4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdfabc8: cmp             SP, x16
    //     0xdfabcc: b.ls            #0xdfac40
    // 0xdfabd0: LoadField: r0 = r2->field_67
    //     0xdfabd0: ldur            w0, [x2, #0x67]
    // 0xdfabd4: DecompressPointer r0
    //     0xdfabd4: add             x0, x0, HEAP, lsl #32
    // 0xdfabd8: r3 = LoadClassIdInstr(r0)
    //     0xdfabd8: ldur            x3, [x0, #-1]
    //     0xdfabdc: ubfx            x3, x3, #0xc, #0x14
    // 0xdfabe0: stp             x1, x0, [SP]
    // 0xdfabe4: mov             x0, x3
    // 0xdfabe8: mov             lr, x0
    // 0xdfabec: ldr             lr, [x21, lr, lsl #3]
    // 0xdfabf0: blr             lr
    // 0xdfabf4: tbnz            w0, #4, #0xdfac08
    // 0xdfabf8: r0 = Null
    //     0xdfabf8: mov             x0, NULL
    // 0xdfabfc: LeaveFrame
    //     0xdfabfc: mov             SP, fp
    //     0xdfac00: ldp             fp, lr, [SP], #0x10
    // 0xdfac04: ret
    //     0xdfac04: ret             
    // 0xdfac08: ldur            x1, [fp, #-8]
    // 0xdfac0c: ldur            x0, [fp, #-0x10]
    // 0xdfac10: StoreField: r1->field_67 = r0
    //     0xdfac10: stur            w0, [x1, #0x67]
    //     0xdfac14: ldurb           w16, [x1, #-1]
    //     0xdfac18: ldurb           w17, [x0, #-1]
    //     0xdfac1c: and             x16, x17, x16, lsr #2
    //     0xdfac20: tst             x16, HEAP, lsr #32
    //     0xdfac24: b.eq            #0xdfac2c
    //     0xdfac28: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdfac2c: r0 = notifyListeners()
    //     0xdfac2c: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xdfac30: r0 = Null
    //     0xdfac30: mov             x0, NULL
    // 0xdfac34: LeaveFrame
    //     0xdfac34: mov             SP, fp
    //     0xdfac38: ldp             fp, lr, [SP], #0x10
    // 0xdfac3c: ret
    //     0xdfac3c: ret             
    // 0xdfac40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdfac40: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdfac44: b               #0xdfabd0
  }
  set _ activeBackgroundColor=(/* No info */) {
    // ** addr: 0xdfac48, size: 0xa4
    // 0xdfac48: EnterFrame
    //     0xdfac48: stp             fp, lr, [SP, #-0x10]!
    //     0xdfac4c: mov             fp, SP
    // 0xdfac50: AllocStack(0x20)
    //     0xdfac50: sub             SP, SP, #0x20
    // 0xdfac54: SetupParameters(_RadioPainter this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xdfac54: stur            x1, [fp, #-8]
    //     0xdfac58: mov             x16, x2
    //     0xdfac5c: mov             x2, x1
    //     0xdfac60: mov             x1, x16
    //     0xdfac64: stur            x1, [fp, #-0x10]
    // 0xdfac68: CheckStackOverflow
    //     0xdfac68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdfac6c: cmp             SP, x16
    //     0xdfac70: b.ls            #0xdface4
    // 0xdfac74: LoadField: r0 = r2->field_63
    //     0xdfac74: ldur            w0, [x2, #0x63]
    // 0xdfac78: DecompressPointer r0
    //     0xdfac78: add             x0, x0, HEAP, lsl #32
    // 0xdfac7c: r3 = LoadClassIdInstr(r0)
    //     0xdfac7c: ldur            x3, [x0, #-1]
    //     0xdfac80: ubfx            x3, x3, #0xc, #0x14
    // 0xdfac84: stp             x1, x0, [SP]
    // 0xdfac88: mov             x0, x3
    // 0xdfac8c: mov             lr, x0
    // 0xdfac90: ldr             lr, [x21, lr, lsl #3]
    // 0xdfac94: blr             lr
    // 0xdfac98: tbnz            w0, #4, #0xdfacac
    // 0xdfac9c: r0 = Null
    //     0xdfac9c: mov             x0, NULL
    // 0xdfaca0: LeaveFrame
    //     0xdfaca0: mov             SP, fp
    //     0xdfaca4: ldp             fp, lr, [SP], #0x10
    // 0xdfaca8: ret
    //     0xdfaca8: ret             
    // 0xdfacac: ldur            x1, [fp, #-8]
    // 0xdfacb0: ldur            x0, [fp, #-0x10]
    // 0xdfacb4: StoreField: r1->field_63 = r0
    //     0xdfacb4: stur            w0, [x1, #0x63]
    //     0xdfacb8: ldurb           w16, [x1, #-1]
    //     0xdfacbc: ldurb           w17, [x0, #-1]
    //     0xdfacc0: and             x16, x17, x16, lsr #2
    //     0xdfacc4: tst             x16, HEAP, lsr #32
    //     0xdfacc8: b.eq            #0xdfacd0
    //     0xdfaccc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdfacd0: r0 = notifyListeners()
    //     0xdfacd0: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xdfacd4: r0 = Null
    //     0xdfacd4: mov             x0, NULL
    // 0xdfacd8: LeaveFrame
    //     0xdfacd8: mov             SP, fp
    //     0xdfacdc: ldp             fp, lr, [SP], #0x10
    // 0xdface0: ret
    //     0xdface0: ret             
    // 0xdface4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdface4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdface8: b               #0xdfac74
  }
}

// class id: 5120, size: 0x38, field offset: 0x2c
class _RadioDefaultsM3 extends RadioThemeData {

  late final ThemeData _theme; // offset: 0x30
  late final ColorScheme _colors; // offset: 0x34

  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xdfb064, size: 0x3b0
    // 0xdfb064: EnterFrame
    //     0xdfb064: stp             fp, lr, [SP, #-0x10]!
    //     0xdfb068: mov             fp, SP
    // 0xdfb06c: AllocStack(0x8)
    //     0xdfb06c: sub             SP, SP, #8
    // 0xdfb070: SetupParameters([dynamic _ /* r0 */])
    //     0xdfb070: ldr             x0, [fp, #0x18]
    //     0xdfb074: ldur            w3, [x0, #0x17]
    //     0xdfb078: add             x3, x3, HEAP, lsl #32
    //     0xdfb07c: stur            x3, [fp, #-8]
    // 0xdfb080: CheckStackOverflow
    //     0xdfb080: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdfb084: cmp             SP, x16
    //     0xdfb088: b.ls            #0xdfb40c
    // 0xdfb08c: ldr             x4, [fp, #0x10]
    // 0xdfb090: r0 = LoadClassIdInstr(r4)
    //     0xdfb090: ldur            x0, [x4, #-1]
    //     0xdfb094: ubfx            x0, x0, #0xc, #0x14
    // 0xdfb098: mov             x1, x4
    // 0xdfb09c: r2 = Instance_WidgetState
    //     0xdfb09c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xdfb0a0: ldr             x2, [x2, #0x100]
    // 0xdfb0a4: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdfb0a4: mov             x17, #0x2929
    //     0xdfb0a8: movk            x17, #1, lsl #16
    //     0xdfb0ac: add             lr, x0, x17
    //     0xdfb0b0: ldr             lr, [x21, lr, lsl #3]
    //     0xdfb0b4: blr             lr
    // 0xdfb0b8: tbnz            w0, #4, #0xdfb25c
    // 0xdfb0bc: ldr             x3, [fp, #0x10]
    // 0xdfb0c0: r0 = LoadClassIdInstr(r3)
    //     0xdfb0c0: ldur            x0, [x3, #-1]
    //     0xdfb0c4: ubfx            x0, x0, #0xc, #0x14
    // 0xdfb0c8: mov             x1, x3
    // 0xdfb0cc: r2 = Instance_WidgetState
    //     0xdfb0cc: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0xdfb0d0: ldr             x2, [x2, #0xa48]
    // 0xdfb0d4: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdfb0d4: mov             x17, #0x2929
    //     0xdfb0d8: movk            x17, #1, lsl #16
    //     0xdfb0dc: add             lr, x0, x17
    //     0xdfb0e0: ldr             lr, [x21, lr, lsl #3]
    //     0xdfb0e4: blr             lr
    // 0xdfb0e8: tbnz            w0, #4, #0xdfb148
    // 0xdfb0ec: ldur            x3, [fp, #-8]
    // 0xdfb0f0: LoadField: r1 = r3->field_f
    //     0xdfb0f0: ldur            w1, [x3, #0xf]
    // 0xdfb0f4: DecompressPointer r1
    //     0xdfb0f4: add             x1, x1, HEAP, lsl #32
    // 0xdfb0f8: LoadField: r0 = r1->field_33
    //     0xdfb0f8: ldur            w0, [x1, #0x33]
    // 0xdfb0fc: DecompressPointer r0
    //     0xdfb0fc: add             x0, x0, HEAP, lsl #32
    // 0xdfb100: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfb104: cmp             w0, w16
    // 0xdfb108: b.ne            #0xdfb118
    // 0xdfb10c: r2 = _colors
    //     0xdfb10c: add             x2, PP, #0x26, lsl #12  ; [pp+0x262b8] Field <_RadioDefaultsM3@625266229._colors@625266229>: late final (offset: 0x34)
    //     0xdfb110: ldr             x2, [x2, #0x2b8]
    // 0xdfb114: r0 = InitLateFinalInstanceField()
    //     0xdfb114: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdfb118: LoadField: r1 = r0->field_7f
    //     0xdfb118: ldur            w1, [x0, #0x7f]
    // 0xdfb11c: DecompressPointer r1
    //     0xdfb11c: add             x1, x1, HEAP, lsl #32
    // 0xdfb120: r0 = LoadClassIdInstr(r1)
    //     0xdfb120: ldur            x0, [x1, #-1]
    //     0xdfb124: ubfx            x0, x0, #0xc, #0x14
    // 0xdfb128: d0 = 0.100000
    //     0xdfb128: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0xdfb12c: ldr             d0, [x17, #0x1e0]
    // 0xdfb130: r0 = GDT[cid_x0 + -0x1000]()
    //     0xdfb130: sub             lr, x0, #1, lsl #12
    //     0xdfb134: ldr             lr, [x21, lr, lsl #3]
    //     0xdfb138: blr             lr
    // 0xdfb13c: LeaveFrame
    //     0xdfb13c: mov             SP, fp
    //     0xdfb140: ldp             fp, lr, [SP], #0x10
    // 0xdfb144: ret
    //     0xdfb144: ret             
    // 0xdfb148: ldr             x4, [fp, #0x10]
    // 0xdfb14c: ldur            x3, [fp, #-8]
    // 0xdfb150: r0 = LoadClassIdInstr(r4)
    //     0xdfb150: ldur            x0, [x4, #-1]
    //     0xdfb154: ubfx            x0, x0, #0xc, #0x14
    // 0xdfb158: mov             x1, x4
    // 0xdfb15c: r2 = Instance_WidgetState
    //     0xdfb15c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xdfb160: ldr             x2, [x2, #0xa50]
    // 0xdfb164: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdfb164: mov             x17, #0x2929
    //     0xdfb168: movk            x17, #1, lsl #16
    //     0xdfb16c: add             lr, x0, x17
    //     0xdfb170: ldr             lr, [x21, lr, lsl #3]
    //     0xdfb174: blr             lr
    // 0xdfb178: tbnz            w0, #4, #0xdfb1c8
    // 0xdfb17c: ldur            x3, [fp, #-8]
    // 0xdfb180: LoadField: r1 = r3->field_f
    //     0xdfb180: ldur            w1, [x3, #0xf]
    // 0xdfb184: DecompressPointer r1
    //     0xdfb184: add             x1, x1, HEAP, lsl #32
    // 0xdfb188: LoadField: r0 = r1->field_33
    //     0xdfb188: ldur            w0, [x1, #0x33]
    // 0xdfb18c: DecompressPointer r0
    //     0xdfb18c: add             x0, x0, HEAP, lsl #32
    // 0xdfb190: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfb194: cmp             w0, w16
    // 0xdfb198: b.ne            #0xdfb1a8
    // 0xdfb19c: r2 = _colors
    //     0xdfb19c: add             x2, PP, #0x26, lsl #12  ; [pp+0x262b8] Field <_RadioDefaultsM3@625266229._colors@625266229>: late final (offset: 0x34)
    //     0xdfb1a0: ldr             x2, [x2, #0x2b8]
    // 0xdfb1a4: r0 = InitLateFinalInstanceField()
    //     0xdfb1a4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdfb1a8: LoadField: r1 = r0->field_b
    //     0xdfb1a8: ldur            w1, [x0, #0xb]
    // 0xdfb1ac: DecompressPointer r1
    //     0xdfb1ac: add             x1, x1, HEAP, lsl #32
    // 0xdfb1b0: d0 = 0.080000
    //     0xdfb1b0: add             x17, PP, #0x15, lsl #12  ; [pp+0x15a58] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0xdfb1b4: ldr             d0, [x17, #0xa58]
    // 0xdfb1b8: r0 = withOpacity()
    //     0xdfb1b8: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xdfb1bc: LeaveFrame
    //     0xdfb1bc: mov             SP, fp
    //     0xdfb1c0: ldp             fp, lr, [SP], #0x10
    // 0xdfb1c4: ret
    //     0xdfb1c4: ret             
    // 0xdfb1c8: ldr             x4, [fp, #0x10]
    // 0xdfb1cc: ldur            x3, [fp, #-8]
    // 0xdfb1d0: r0 = LoadClassIdInstr(r4)
    //     0xdfb1d0: ldur            x0, [x4, #-1]
    //     0xdfb1d4: ubfx            x0, x0, #0xc, #0x14
    // 0xdfb1d8: mov             x1, x4
    // 0xdfb1dc: r2 = Instance_WidgetState
    //     0xdfb1dc: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xdfb1e0: ldr             x2, [x2, #0xa60]
    // 0xdfb1e4: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdfb1e4: mov             x17, #0x2929
    //     0xdfb1e8: movk            x17, #1, lsl #16
    //     0xdfb1ec: add             lr, x0, x17
    //     0xdfb1f0: ldr             lr, [x21, lr, lsl #3]
    //     0xdfb1f4: blr             lr
    // 0xdfb1f8: tbnz            w0, #4, #0xdfb248
    // 0xdfb1fc: ldur            x3, [fp, #-8]
    // 0xdfb200: LoadField: r1 = r3->field_f
    //     0xdfb200: ldur            w1, [x3, #0xf]
    // 0xdfb204: DecompressPointer r1
    //     0xdfb204: add             x1, x1, HEAP, lsl #32
    // 0xdfb208: LoadField: r0 = r1->field_33
    //     0xdfb208: ldur            w0, [x1, #0x33]
    // 0xdfb20c: DecompressPointer r0
    //     0xdfb20c: add             x0, x0, HEAP, lsl #32
    // 0xdfb210: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfb214: cmp             w0, w16
    // 0xdfb218: b.ne            #0xdfb228
    // 0xdfb21c: r2 = _colors
    //     0xdfb21c: add             x2, PP, #0x26, lsl #12  ; [pp+0x262b8] Field <_RadioDefaultsM3@625266229._colors@625266229>: late final (offset: 0x34)
    //     0xdfb220: ldr             x2, [x2, #0x2b8]
    // 0xdfb224: r0 = InitLateFinalInstanceField()
    //     0xdfb224: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdfb228: LoadField: r1 = r0->field_b
    //     0xdfb228: ldur            w1, [x0, #0xb]
    // 0xdfb22c: DecompressPointer r1
    //     0xdfb22c: add             x1, x1, HEAP, lsl #32
    // 0xdfb230: d0 = 0.100000
    //     0xdfb230: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0xdfb234: ldr             d0, [x17, #0x1e0]
    // 0xdfb238: r0 = withOpacity()
    //     0xdfb238: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xdfb23c: LeaveFrame
    //     0xdfb23c: mov             SP, fp
    //     0xdfb240: ldp             fp, lr, [SP], #0x10
    // 0xdfb244: ret
    //     0xdfb244: ret             
    // 0xdfb248: r0 = Instance_Color
    //     0xdfb248: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xdfb24c: ldr             x0, [x0, #0x810]
    // 0xdfb250: LeaveFrame
    //     0xdfb250: mov             SP, fp
    //     0xdfb254: ldp             fp, lr, [SP], #0x10
    // 0xdfb258: ret
    //     0xdfb258: ret             
    // 0xdfb25c: ldr             x4, [fp, #0x10]
    // 0xdfb260: ldur            x3, [fp, #-8]
    // 0xdfb264: r0 = LoadClassIdInstr(r4)
    //     0xdfb264: ldur            x0, [x4, #-1]
    //     0xdfb268: ubfx            x0, x0, #0xc, #0x14
    // 0xdfb26c: mov             x1, x4
    // 0xdfb270: r2 = Instance_WidgetState
    //     0xdfb270: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0xdfb274: ldr             x2, [x2, #0xa48]
    // 0xdfb278: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdfb278: mov             x17, #0x2929
    //     0xdfb27c: movk            x17, #1, lsl #16
    //     0xdfb280: add             lr, x0, x17
    //     0xdfb284: ldr             lr, [x21, lr, lsl #3]
    //     0xdfb288: blr             lr
    // 0xdfb28c: tbnz            w0, #4, #0xdfb2dc
    // 0xdfb290: ldur            x3, [fp, #-8]
    // 0xdfb294: LoadField: r1 = r3->field_f
    //     0xdfb294: ldur            w1, [x3, #0xf]
    // 0xdfb298: DecompressPointer r1
    //     0xdfb298: add             x1, x1, HEAP, lsl #32
    // 0xdfb29c: LoadField: r0 = r1->field_33
    //     0xdfb29c: ldur            w0, [x1, #0x33]
    // 0xdfb2a0: DecompressPointer r0
    //     0xdfb2a0: add             x0, x0, HEAP, lsl #32
    // 0xdfb2a4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfb2a8: cmp             w0, w16
    // 0xdfb2ac: b.ne            #0xdfb2bc
    // 0xdfb2b0: r2 = _colors
    //     0xdfb2b0: add             x2, PP, #0x26, lsl #12  ; [pp+0x262b8] Field <_RadioDefaultsM3@625266229._colors@625266229>: late final (offset: 0x34)
    //     0xdfb2b4: ldr             x2, [x2, #0x2b8]
    // 0xdfb2b8: r0 = InitLateFinalInstanceField()
    //     0xdfb2b8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdfb2bc: LoadField: r1 = r0->field_b
    //     0xdfb2bc: ldur            w1, [x0, #0xb]
    // 0xdfb2c0: DecompressPointer r1
    //     0xdfb2c0: add             x1, x1, HEAP, lsl #32
    // 0xdfb2c4: d0 = 0.100000
    //     0xdfb2c4: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0xdfb2c8: ldr             d0, [x17, #0x1e0]
    // 0xdfb2cc: r0 = withOpacity()
    //     0xdfb2cc: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xdfb2d0: LeaveFrame
    //     0xdfb2d0: mov             SP, fp
    //     0xdfb2d4: ldp             fp, lr, [SP], #0x10
    // 0xdfb2d8: ret
    //     0xdfb2d8: ret             
    // 0xdfb2dc: ldr             x4, [fp, #0x10]
    // 0xdfb2e0: ldur            x3, [fp, #-8]
    // 0xdfb2e4: r0 = LoadClassIdInstr(r4)
    //     0xdfb2e4: ldur            x0, [x4, #-1]
    //     0xdfb2e8: ubfx            x0, x0, #0xc, #0x14
    // 0xdfb2ec: mov             x1, x4
    // 0xdfb2f0: r2 = Instance_WidgetState
    //     0xdfb2f0: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xdfb2f4: ldr             x2, [x2, #0xa50]
    // 0xdfb2f8: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdfb2f8: mov             x17, #0x2929
    //     0xdfb2fc: movk            x17, #1, lsl #16
    //     0xdfb300: add             lr, x0, x17
    //     0xdfb304: ldr             lr, [x21, lr, lsl #3]
    //     0xdfb308: blr             lr
    // 0xdfb30c: tbnz            w0, #4, #0xdfb36c
    // 0xdfb310: ldur            x3, [fp, #-8]
    // 0xdfb314: LoadField: r1 = r3->field_f
    //     0xdfb314: ldur            w1, [x3, #0xf]
    // 0xdfb318: DecompressPointer r1
    //     0xdfb318: add             x1, x1, HEAP, lsl #32
    // 0xdfb31c: LoadField: r0 = r1->field_33
    //     0xdfb31c: ldur            w0, [x1, #0x33]
    // 0xdfb320: DecompressPointer r0
    //     0xdfb320: add             x0, x0, HEAP, lsl #32
    // 0xdfb324: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfb328: cmp             w0, w16
    // 0xdfb32c: b.ne            #0xdfb33c
    // 0xdfb330: r2 = _colors
    //     0xdfb330: add             x2, PP, #0x26, lsl #12  ; [pp+0x262b8] Field <_RadioDefaultsM3@625266229._colors@625266229>: late final (offset: 0x34)
    //     0xdfb334: ldr             x2, [x2, #0x2b8]
    // 0xdfb338: r0 = InitLateFinalInstanceField()
    //     0xdfb338: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdfb33c: LoadField: r1 = r0->field_7f
    //     0xdfb33c: ldur            w1, [x0, #0x7f]
    // 0xdfb340: DecompressPointer r1
    //     0xdfb340: add             x1, x1, HEAP, lsl #32
    // 0xdfb344: r0 = LoadClassIdInstr(r1)
    //     0xdfb344: ldur            x0, [x1, #-1]
    //     0xdfb348: ubfx            x0, x0, #0xc, #0x14
    // 0xdfb34c: d0 = 0.080000
    //     0xdfb34c: add             x17, PP, #0x15, lsl #12  ; [pp+0x15a58] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0xdfb350: ldr             d0, [x17, #0xa58]
    // 0xdfb354: r0 = GDT[cid_x0 + -0x1000]()
    //     0xdfb354: sub             lr, x0, #1, lsl #12
    //     0xdfb358: ldr             lr, [x21, lr, lsl #3]
    //     0xdfb35c: blr             lr
    // 0xdfb360: LeaveFrame
    //     0xdfb360: mov             SP, fp
    //     0xdfb364: ldp             fp, lr, [SP], #0x10
    // 0xdfb368: ret
    //     0xdfb368: ret             
    // 0xdfb36c: ldr             x1, [fp, #0x10]
    // 0xdfb370: ldur            x3, [fp, #-8]
    // 0xdfb374: r0 = LoadClassIdInstr(r1)
    //     0xdfb374: ldur            x0, [x1, #-1]
    //     0xdfb378: ubfx            x0, x0, #0xc, #0x14
    // 0xdfb37c: r2 = Instance_WidgetState
    //     0xdfb37c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xdfb380: ldr             x2, [x2, #0xa60]
    // 0xdfb384: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdfb384: mov             x17, #0x2929
    //     0xdfb388: movk            x17, #1, lsl #16
    //     0xdfb38c: add             lr, x0, x17
    //     0xdfb390: ldr             lr, [x21, lr, lsl #3]
    //     0xdfb394: blr             lr
    // 0xdfb398: tbnz            w0, #4, #0xdfb3f8
    // 0xdfb39c: ldur            x0, [fp, #-8]
    // 0xdfb3a0: LoadField: r1 = r0->field_f
    //     0xdfb3a0: ldur            w1, [x0, #0xf]
    // 0xdfb3a4: DecompressPointer r1
    //     0xdfb3a4: add             x1, x1, HEAP, lsl #32
    // 0xdfb3a8: LoadField: r0 = r1->field_33
    //     0xdfb3a8: ldur            w0, [x1, #0x33]
    // 0xdfb3ac: DecompressPointer r0
    //     0xdfb3ac: add             x0, x0, HEAP, lsl #32
    // 0xdfb3b0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfb3b4: cmp             w0, w16
    // 0xdfb3b8: b.ne            #0xdfb3c8
    // 0xdfb3bc: r2 = _colors
    //     0xdfb3bc: add             x2, PP, #0x26, lsl #12  ; [pp+0x262b8] Field <_RadioDefaultsM3@625266229._colors@625266229>: late final (offset: 0x34)
    //     0xdfb3c0: ldr             x2, [x2, #0x2b8]
    // 0xdfb3c4: r0 = InitLateFinalInstanceField()
    //     0xdfb3c4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdfb3c8: LoadField: r1 = r0->field_7f
    //     0xdfb3c8: ldur            w1, [x0, #0x7f]
    // 0xdfb3cc: DecompressPointer r1
    //     0xdfb3cc: add             x1, x1, HEAP, lsl #32
    // 0xdfb3d0: r0 = LoadClassIdInstr(r1)
    //     0xdfb3d0: ldur            x0, [x1, #-1]
    //     0xdfb3d4: ubfx            x0, x0, #0xc, #0x14
    // 0xdfb3d8: d0 = 0.100000
    //     0xdfb3d8: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0xdfb3dc: ldr             d0, [x17, #0x1e0]
    // 0xdfb3e0: r0 = GDT[cid_x0 + -0x1000]()
    //     0xdfb3e0: sub             lr, x0, #1, lsl #12
    //     0xdfb3e4: ldr             lr, [x21, lr, lsl #3]
    //     0xdfb3e8: blr             lr
    // 0xdfb3ec: LeaveFrame
    //     0xdfb3ec: mov             SP, fp
    //     0xdfb3f0: ldp             fp, lr, [SP], #0x10
    // 0xdfb3f4: ret
    //     0xdfb3f4: ret             
    // 0xdfb3f8: r0 = Instance_Color
    //     0xdfb3f8: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xdfb3fc: ldr             x0, [x0, #0x810]
    // 0xdfb400: LeaveFrame
    //     0xdfb400: mov             SP, fp
    //     0xdfb404: ldp             fp, lr, [SP], #0x10
    // 0xdfb408: ret
    //     0xdfb408: ret             
    // 0xdfb40c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdfb40c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdfb410: b               #0xdfb08c
  }
  ColorScheme _colors(_RadioDefaultsM3) {
    // ** addr: 0xdfb414, size: 0x58
    // 0xdfb414: EnterFrame
    //     0xdfb414: stp             fp, lr, [SP, #-0x10]!
    //     0xdfb418: mov             fp, SP
    // 0xdfb41c: CheckStackOverflow
    //     0xdfb41c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdfb420: cmp             SP, x16
    //     0xdfb424: b.ls            #0xdfb464
    // 0xdfb428: ldr             x1, [fp, #0x10]
    // 0xdfb42c: LoadField: r0 = r1->field_2f
    //     0xdfb42c: ldur            w0, [x1, #0x2f]
    // 0xdfb430: DecompressPointer r0
    //     0xdfb430: add             x0, x0, HEAP, lsl #32
    // 0xdfb434: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfb438: cmp             w0, w16
    // 0xdfb43c: b.ne            #0xdfb44c
    // 0xdfb440: r2 = _theme
    //     0xdfb440: add             x2, PP, #0x26, lsl #12  ; [pp+0x262a8] Field <_RadioDefaultsM3@625266229._theme@625266229>: late final (offset: 0x30)
    //     0xdfb444: ldr             x2, [x2, #0x2a8]
    // 0xdfb448: r0 = InitLateFinalInstanceField()
    //     0xdfb448: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdfb44c: LoadField: r1 = r0->field_3f
    //     0xdfb44c: ldur            w1, [x0, #0x3f]
    // 0xdfb450: DecompressPointer r1
    //     0xdfb450: add             x1, x1, HEAP, lsl #32
    // 0xdfb454: mov             x0, x1
    // 0xdfb458: LeaveFrame
    //     0xdfb458: mov             SP, fp
    //     0xdfb45c: ldp             fp, lr, [SP], #0x10
    // 0xdfb460: ret
    //     0xdfb460: ret             
    // 0xdfb464: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdfb464: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdfb468: b               #0xdfb428
  }
  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xdfb620, size: 0x4e8
    // 0xdfb620: EnterFrame
    //     0xdfb620: stp             fp, lr, [SP, #-0x10]!
    //     0xdfb624: mov             fp, SP
    // 0xdfb628: AllocStack(0x8)
    //     0xdfb628: sub             SP, SP, #8
    // 0xdfb62c: SetupParameters([dynamic _ /* r0 */])
    //     0xdfb62c: ldr             x0, [fp, #0x18]
    //     0xdfb630: ldur            w3, [x0, #0x17]
    //     0xdfb634: add             x3, x3, HEAP, lsl #32
    //     0xdfb638: stur            x3, [fp, #-8]
    // 0xdfb63c: CheckStackOverflow
    //     0xdfb63c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdfb640: cmp             SP, x16
    //     0xdfb644: b.ls            #0xdfbb00
    // 0xdfb648: ldr             x4, [fp, #0x10]
    // 0xdfb64c: r0 = LoadClassIdInstr(r4)
    //     0xdfb64c: ldur            x0, [x4, #-1]
    //     0xdfb650: ubfx            x0, x0, #0xc, #0x14
    // 0xdfb654: mov             x1, x4
    // 0xdfb658: r2 = Instance_WidgetState
    //     0xdfb658: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xdfb65c: ldr             x2, [x2, #0x100]
    // 0xdfb660: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdfb660: mov             x17, #0x2929
    //     0xdfb664: movk            x17, #1, lsl #16
    //     0xdfb668: add             lr, x0, x17
    //     0xdfb66c: ldr             lr, [x21, lr, lsl #3]
    //     0xdfb670: blr             lr
    // 0xdfb674: tbnz            w0, #4, #0xdfb8b0
    // 0xdfb678: ldr             x3, [fp, #0x10]
    // 0xdfb67c: r0 = LoadClassIdInstr(r3)
    //     0xdfb67c: ldur            x0, [x3, #-1]
    //     0xdfb680: ubfx            x0, x0, #0xc, #0x14
    // 0xdfb684: mov             x1, x3
    // 0xdfb688: r2 = Instance_WidgetState
    //     0xdfb688: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xdfb68c: ldr             x2, [x2, #0xa70]
    // 0xdfb690: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdfb690: mov             x17, #0x2929
    //     0xdfb694: movk            x17, #1, lsl #16
    //     0xdfb698: add             lr, x0, x17
    //     0xdfb69c: ldr             lr, [x21, lr, lsl #3]
    //     0xdfb6a0: blr             lr
    // 0xdfb6a4: tbnz            w0, #4, #0xdfb704
    // 0xdfb6a8: ldur            x3, [fp, #-8]
    // 0xdfb6ac: LoadField: r1 = r3->field_f
    //     0xdfb6ac: ldur            w1, [x3, #0xf]
    // 0xdfb6b0: DecompressPointer r1
    //     0xdfb6b0: add             x1, x1, HEAP, lsl #32
    // 0xdfb6b4: LoadField: r0 = r1->field_33
    //     0xdfb6b4: ldur            w0, [x1, #0x33]
    // 0xdfb6b8: DecompressPointer r0
    //     0xdfb6b8: add             x0, x0, HEAP, lsl #32
    // 0xdfb6bc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfb6c0: cmp             w0, w16
    // 0xdfb6c4: b.ne            #0xdfb6d4
    // 0xdfb6c8: r2 = _colors
    //     0xdfb6c8: add             x2, PP, #0x26, lsl #12  ; [pp+0x262b8] Field <_RadioDefaultsM3@625266229._colors@625266229>: late final (offset: 0x34)
    //     0xdfb6cc: ldr             x2, [x2, #0x2b8]
    // 0xdfb6d0: r0 = InitLateFinalInstanceField()
    //     0xdfb6d0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdfb6d4: LoadField: r1 = r0->field_7f
    //     0xdfb6d4: ldur            w1, [x0, #0x7f]
    // 0xdfb6d8: DecompressPointer r1
    //     0xdfb6d8: add             x1, x1, HEAP, lsl #32
    // 0xdfb6dc: r0 = LoadClassIdInstr(r1)
    //     0xdfb6dc: ldur            x0, [x1, #-1]
    //     0xdfb6e0: ubfx            x0, x0, #0xc, #0x14
    // 0xdfb6e4: d0 = 0.380000
    //     0xdfb6e4: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xdfb6e8: ldr             d0, [x17, #0x1f0]
    // 0xdfb6ec: r0 = GDT[cid_x0 + -0x1000]()
    //     0xdfb6ec: sub             lr, x0, #1, lsl #12
    //     0xdfb6f0: ldr             lr, [x21, lr, lsl #3]
    //     0xdfb6f4: blr             lr
    // 0xdfb6f8: LeaveFrame
    //     0xdfb6f8: mov             SP, fp
    //     0xdfb6fc: ldp             fp, lr, [SP], #0x10
    // 0xdfb700: ret
    //     0xdfb700: ret             
    // 0xdfb704: ldr             x4, [fp, #0x10]
    // 0xdfb708: ldur            x3, [fp, #-8]
    // 0xdfb70c: r0 = LoadClassIdInstr(r4)
    //     0xdfb70c: ldur            x0, [x4, #-1]
    //     0xdfb710: ubfx            x0, x0, #0xc, #0x14
    // 0xdfb714: mov             x1, x4
    // 0xdfb718: r2 = Instance_WidgetState
    //     0xdfb718: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0xdfb71c: ldr             x2, [x2, #0xa48]
    // 0xdfb720: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdfb720: mov             x17, #0x2929
    //     0xdfb724: movk            x17, #1, lsl #16
    //     0xdfb728: add             lr, x0, x17
    //     0xdfb72c: ldr             lr, [x21, lr, lsl #3]
    //     0xdfb730: blr             lr
    // 0xdfb734: tbnz            w0, #4, #0xdfb77c
    // 0xdfb738: ldur            x3, [fp, #-8]
    // 0xdfb73c: LoadField: r1 = r3->field_f
    //     0xdfb73c: ldur            w1, [x3, #0xf]
    // 0xdfb740: DecompressPointer r1
    //     0xdfb740: add             x1, x1, HEAP, lsl #32
    // 0xdfb744: LoadField: r0 = r1->field_33
    //     0xdfb744: ldur            w0, [x1, #0x33]
    // 0xdfb748: DecompressPointer r0
    //     0xdfb748: add             x0, x0, HEAP, lsl #32
    // 0xdfb74c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfb750: cmp             w0, w16
    // 0xdfb754: b.ne            #0xdfb764
    // 0xdfb758: r2 = _colors
    //     0xdfb758: add             x2, PP, #0x26, lsl #12  ; [pp+0x262b8] Field <_RadioDefaultsM3@625266229._colors@625266229>: late final (offset: 0x34)
    //     0xdfb75c: ldr             x2, [x2, #0x2b8]
    // 0xdfb760: r0 = InitLateFinalInstanceField()
    //     0xdfb760: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdfb764: LoadField: r1 = r0->field_b
    //     0xdfb764: ldur            w1, [x0, #0xb]
    // 0xdfb768: DecompressPointer r1
    //     0xdfb768: add             x1, x1, HEAP, lsl #32
    // 0xdfb76c: mov             x0, x1
    // 0xdfb770: LeaveFrame
    //     0xdfb770: mov             SP, fp
    //     0xdfb774: ldp             fp, lr, [SP], #0x10
    // 0xdfb778: ret
    //     0xdfb778: ret             
    // 0xdfb77c: ldr             x4, [fp, #0x10]
    // 0xdfb780: ldur            x3, [fp, #-8]
    // 0xdfb784: r0 = LoadClassIdInstr(r4)
    //     0xdfb784: ldur            x0, [x4, #-1]
    //     0xdfb788: ubfx            x0, x0, #0xc, #0x14
    // 0xdfb78c: mov             x1, x4
    // 0xdfb790: r2 = Instance_WidgetState
    //     0xdfb790: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xdfb794: ldr             x2, [x2, #0xa50]
    // 0xdfb798: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdfb798: mov             x17, #0x2929
    //     0xdfb79c: movk            x17, #1, lsl #16
    //     0xdfb7a0: add             lr, x0, x17
    //     0xdfb7a4: ldr             lr, [x21, lr, lsl #3]
    //     0xdfb7a8: blr             lr
    // 0xdfb7ac: tbnz            w0, #4, #0xdfb7f4
    // 0xdfb7b0: ldur            x3, [fp, #-8]
    // 0xdfb7b4: LoadField: r1 = r3->field_f
    //     0xdfb7b4: ldur            w1, [x3, #0xf]
    // 0xdfb7b8: DecompressPointer r1
    //     0xdfb7b8: add             x1, x1, HEAP, lsl #32
    // 0xdfb7bc: LoadField: r0 = r1->field_33
    //     0xdfb7bc: ldur            w0, [x1, #0x33]
    // 0xdfb7c0: DecompressPointer r0
    //     0xdfb7c0: add             x0, x0, HEAP, lsl #32
    // 0xdfb7c4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfb7c8: cmp             w0, w16
    // 0xdfb7cc: b.ne            #0xdfb7dc
    // 0xdfb7d0: r2 = _colors
    //     0xdfb7d0: add             x2, PP, #0x26, lsl #12  ; [pp+0x262b8] Field <_RadioDefaultsM3@625266229._colors@625266229>: late final (offset: 0x34)
    //     0xdfb7d4: ldr             x2, [x2, #0x2b8]
    // 0xdfb7d8: r0 = InitLateFinalInstanceField()
    //     0xdfb7d8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdfb7dc: LoadField: r1 = r0->field_b
    //     0xdfb7dc: ldur            w1, [x0, #0xb]
    // 0xdfb7e0: DecompressPointer r1
    //     0xdfb7e0: add             x1, x1, HEAP, lsl #32
    // 0xdfb7e4: mov             x0, x1
    // 0xdfb7e8: LeaveFrame
    //     0xdfb7e8: mov             SP, fp
    //     0xdfb7ec: ldp             fp, lr, [SP], #0x10
    // 0xdfb7f0: ret
    //     0xdfb7f0: ret             
    // 0xdfb7f4: ldr             x4, [fp, #0x10]
    // 0xdfb7f8: ldur            x3, [fp, #-8]
    // 0xdfb7fc: r0 = LoadClassIdInstr(r4)
    //     0xdfb7fc: ldur            x0, [x4, #-1]
    //     0xdfb800: ubfx            x0, x0, #0xc, #0x14
    // 0xdfb804: mov             x1, x4
    // 0xdfb808: r2 = Instance_WidgetState
    //     0xdfb808: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xdfb80c: ldr             x2, [x2, #0xa60]
    // 0xdfb810: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdfb810: mov             x17, #0x2929
    //     0xdfb814: movk            x17, #1, lsl #16
    //     0xdfb818: add             lr, x0, x17
    //     0xdfb81c: ldr             lr, [x21, lr, lsl #3]
    //     0xdfb820: blr             lr
    // 0xdfb824: tbnz            w0, #4, #0xdfb86c
    // 0xdfb828: ldur            x3, [fp, #-8]
    // 0xdfb82c: LoadField: r1 = r3->field_f
    //     0xdfb82c: ldur            w1, [x3, #0xf]
    // 0xdfb830: DecompressPointer r1
    //     0xdfb830: add             x1, x1, HEAP, lsl #32
    // 0xdfb834: LoadField: r0 = r1->field_33
    //     0xdfb834: ldur            w0, [x1, #0x33]
    // 0xdfb838: DecompressPointer r0
    //     0xdfb838: add             x0, x0, HEAP, lsl #32
    // 0xdfb83c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfb840: cmp             w0, w16
    // 0xdfb844: b.ne            #0xdfb854
    // 0xdfb848: r2 = _colors
    //     0xdfb848: add             x2, PP, #0x26, lsl #12  ; [pp+0x262b8] Field <_RadioDefaultsM3@625266229._colors@625266229>: late final (offset: 0x34)
    //     0xdfb84c: ldr             x2, [x2, #0x2b8]
    // 0xdfb850: r0 = InitLateFinalInstanceField()
    //     0xdfb850: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdfb854: LoadField: r1 = r0->field_b
    //     0xdfb854: ldur            w1, [x0, #0xb]
    // 0xdfb858: DecompressPointer r1
    //     0xdfb858: add             x1, x1, HEAP, lsl #32
    // 0xdfb85c: mov             x0, x1
    // 0xdfb860: LeaveFrame
    //     0xdfb860: mov             SP, fp
    //     0xdfb864: ldp             fp, lr, [SP], #0x10
    // 0xdfb868: ret
    //     0xdfb868: ret             
    // 0xdfb86c: ldur            x3, [fp, #-8]
    // 0xdfb870: LoadField: r1 = r3->field_f
    //     0xdfb870: ldur            w1, [x3, #0xf]
    // 0xdfb874: DecompressPointer r1
    //     0xdfb874: add             x1, x1, HEAP, lsl #32
    // 0xdfb878: LoadField: r0 = r1->field_33
    //     0xdfb878: ldur            w0, [x1, #0x33]
    // 0xdfb87c: DecompressPointer r0
    //     0xdfb87c: add             x0, x0, HEAP, lsl #32
    // 0xdfb880: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfb884: cmp             w0, w16
    // 0xdfb888: b.ne            #0xdfb898
    // 0xdfb88c: r2 = _colors
    //     0xdfb88c: add             x2, PP, #0x26, lsl #12  ; [pp+0x262b8] Field <_RadioDefaultsM3@625266229._colors@625266229>: late final (offset: 0x34)
    //     0xdfb890: ldr             x2, [x2, #0x2b8]
    // 0xdfb894: r0 = InitLateFinalInstanceField()
    //     0xdfb894: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdfb898: LoadField: r1 = r0->field_b
    //     0xdfb898: ldur            w1, [x0, #0xb]
    // 0xdfb89c: DecompressPointer r1
    //     0xdfb89c: add             x1, x1, HEAP, lsl #32
    // 0xdfb8a0: mov             x0, x1
    // 0xdfb8a4: LeaveFrame
    //     0xdfb8a4: mov             SP, fp
    //     0xdfb8a8: ldp             fp, lr, [SP], #0x10
    // 0xdfb8ac: ret
    //     0xdfb8ac: ret             
    // 0xdfb8b0: ldr             x4, [fp, #0x10]
    // 0xdfb8b4: ldur            x3, [fp, #-8]
    // 0xdfb8b8: r0 = LoadClassIdInstr(r4)
    //     0xdfb8b8: ldur            x0, [x4, #-1]
    //     0xdfb8bc: ubfx            x0, x0, #0xc, #0x14
    // 0xdfb8c0: mov             x1, x4
    // 0xdfb8c4: r2 = Instance_WidgetState
    //     0xdfb8c4: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xdfb8c8: ldr             x2, [x2, #0xa70]
    // 0xdfb8cc: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdfb8cc: mov             x17, #0x2929
    //     0xdfb8d0: movk            x17, #1, lsl #16
    //     0xdfb8d4: add             lr, x0, x17
    //     0xdfb8d8: ldr             lr, [x21, lr, lsl #3]
    //     0xdfb8dc: blr             lr
    // 0xdfb8e0: tbnz            w0, #4, #0xdfb940
    // 0xdfb8e4: ldur            x3, [fp, #-8]
    // 0xdfb8e8: LoadField: r1 = r3->field_f
    //     0xdfb8e8: ldur            w1, [x3, #0xf]
    // 0xdfb8ec: DecompressPointer r1
    //     0xdfb8ec: add             x1, x1, HEAP, lsl #32
    // 0xdfb8f0: LoadField: r0 = r1->field_33
    //     0xdfb8f0: ldur            w0, [x1, #0x33]
    // 0xdfb8f4: DecompressPointer r0
    //     0xdfb8f4: add             x0, x0, HEAP, lsl #32
    // 0xdfb8f8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfb8fc: cmp             w0, w16
    // 0xdfb900: b.ne            #0xdfb910
    // 0xdfb904: r2 = _colors
    //     0xdfb904: add             x2, PP, #0x26, lsl #12  ; [pp+0x262b8] Field <_RadioDefaultsM3@625266229._colors@625266229>: late final (offset: 0x34)
    //     0xdfb908: ldr             x2, [x2, #0x2b8]
    // 0xdfb90c: r0 = InitLateFinalInstanceField()
    //     0xdfb90c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdfb910: LoadField: r1 = r0->field_7f
    //     0xdfb910: ldur            w1, [x0, #0x7f]
    // 0xdfb914: DecompressPointer r1
    //     0xdfb914: add             x1, x1, HEAP, lsl #32
    // 0xdfb918: r0 = LoadClassIdInstr(r1)
    //     0xdfb918: ldur            x0, [x1, #-1]
    //     0xdfb91c: ubfx            x0, x0, #0xc, #0x14
    // 0xdfb920: d0 = 0.380000
    //     0xdfb920: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xdfb924: ldr             d0, [x17, #0x1f0]
    // 0xdfb928: r0 = GDT[cid_x0 + -0x1000]()
    //     0xdfb928: sub             lr, x0, #1, lsl #12
    //     0xdfb92c: ldr             lr, [x21, lr, lsl #3]
    //     0xdfb930: blr             lr
    // 0xdfb934: LeaveFrame
    //     0xdfb934: mov             SP, fp
    //     0xdfb938: ldp             fp, lr, [SP], #0x10
    // 0xdfb93c: ret
    //     0xdfb93c: ret             
    // 0xdfb940: ldr             x4, [fp, #0x10]
    // 0xdfb944: ldur            x3, [fp, #-8]
    // 0xdfb948: r0 = LoadClassIdInstr(r4)
    //     0xdfb948: ldur            x0, [x4, #-1]
    //     0xdfb94c: ubfx            x0, x0, #0xc, #0x14
    // 0xdfb950: mov             x1, x4
    // 0xdfb954: r2 = Instance_WidgetState
    //     0xdfb954: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0xdfb958: ldr             x2, [x2, #0xa48]
    // 0xdfb95c: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdfb95c: mov             x17, #0x2929
    //     0xdfb960: movk            x17, #1, lsl #16
    //     0xdfb964: add             lr, x0, x17
    //     0xdfb968: ldr             lr, [x21, lr, lsl #3]
    //     0xdfb96c: blr             lr
    // 0xdfb970: tbnz            w0, #4, #0xdfb9b8
    // 0xdfb974: ldur            x3, [fp, #-8]
    // 0xdfb978: LoadField: r1 = r3->field_f
    //     0xdfb978: ldur            w1, [x3, #0xf]
    // 0xdfb97c: DecompressPointer r1
    //     0xdfb97c: add             x1, x1, HEAP, lsl #32
    // 0xdfb980: LoadField: r0 = r1->field_33
    //     0xdfb980: ldur            w0, [x1, #0x33]
    // 0xdfb984: DecompressPointer r0
    //     0xdfb984: add             x0, x0, HEAP, lsl #32
    // 0xdfb988: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfb98c: cmp             w0, w16
    // 0xdfb990: b.ne            #0xdfb9a0
    // 0xdfb994: r2 = _colors
    //     0xdfb994: add             x2, PP, #0x26, lsl #12  ; [pp+0x262b8] Field <_RadioDefaultsM3@625266229._colors@625266229>: late final (offset: 0x34)
    //     0xdfb998: ldr             x2, [x2, #0x2b8]
    // 0xdfb99c: r0 = InitLateFinalInstanceField()
    //     0xdfb99c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdfb9a0: LoadField: r1 = r0->field_7f
    //     0xdfb9a0: ldur            w1, [x0, #0x7f]
    // 0xdfb9a4: DecompressPointer r1
    //     0xdfb9a4: add             x1, x1, HEAP, lsl #32
    // 0xdfb9a8: mov             x0, x1
    // 0xdfb9ac: LeaveFrame
    //     0xdfb9ac: mov             SP, fp
    //     0xdfb9b0: ldp             fp, lr, [SP], #0x10
    // 0xdfb9b4: ret
    //     0xdfb9b4: ret             
    // 0xdfb9b8: ldr             x4, [fp, #0x10]
    // 0xdfb9bc: ldur            x3, [fp, #-8]
    // 0xdfb9c0: r0 = LoadClassIdInstr(r4)
    //     0xdfb9c0: ldur            x0, [x4, #-1]
    //     0xdfb9c4: ubfx            x0, x0, #0xc, #0x14
    // 0xdfb9c8: mov             x1, x4
    // 0xdfb9cc: r2 = Instance_WidgetState
    //     0xdfb9cc: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xdfb9d0: ldr             x2, [x2, #0xa50]
    // 0xdfb9d4: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdfb9d4: mov             x17, #0x2929
    //     0xdfb9d8: movk            x17, #1, lsl #16
    //     0xdfb9dc: add             lr, x0, x17
    //     0xdfb9e0: ldr             lr, [x21, lr, lsl #3]
    //     0xdfb9e4: blr             lr
    // 0xdfb9e8: tbnz            w0, #4, #0xdfba30
    // 0xdfb9ec: ldur            x3, [fp, #-8]
    // 0xdfb9f0: LoadField: r1 = r3->field_f
    //     0xdfb9f0: ldur            w1, [x3, #0xf]
    // 0xdfb9f4: DecompressPointer r1
    //     0xdfb9f4: add             x1, x1, HEAP, lsl #32
    // 0xdfb9f8: LoadField: r0 = r1->field_33
    //     0xdfb9f8: ldur            w0, [x1, #0x33]
    // 0xdfb9fc: DecompressPointer r0
    //     0xdfb9fc: add             x0, x0, HEAP, lsl #32
    // 0xdfba00: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfba04: cmp             w0, w16
    // 0xdfba08: b.ne            #0xdfba18
    // 0xdfba0c: r2 = _colors
    //     0xdfba0c: add             x2, PP, #0x26, lsl #12  ; [pp+0x262b8] Field <_RadioDefaultsM3@625266229._colors@625266229>: late final (offset: 0x34)
    //     0xdfba10: ldr             x2, [x2, #0x2b8]
    // 0xdfba14: r0 = InitLateFinalInstanceField()
    //     0xdfba14: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdfba18: LoadField: r1 = r0->field_7f
    //     0xdfba18: ldur            w1, [x0, #0x7f]
    // 0xdfba1c: DecompressPointer r1
    //     0xdfba1c: add             x1, x1, HEAP, lsl #32
    // 0xdfba20: mov             x0, x1
    // 0xdfba24: LeaveFrame
    //     0xdfba24: mov             SP, fp
    //     0xdfba28: ldp             fp, lr, [SP], #0x10
    // 0xdfba2c: ret
    //     0xdfba2c: ret             
    // 0xdfba30: ldr             x1, [fp, #0x10]
    // 0xdfba34: ldur            x3, [fp, #-8]
    // 0xdfba38: r0 = LoadClassIdInstr(r1)
    //     0xdfba38: ldur            x0, [x1, #-1]
    //     0xdfba3c: ubfx            x0, x0, #0xc, #0x14
    // 0xdfba40: r2 = Instance_WidgetState
    //     0xdfba40: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xdfba44: ldr             x2, [x2, #0xa60]
    // 0xdfba48: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdfba48: mov             x17, #0x2929
    //     0xdfba4c: movk            x17, #1, lsl #16
    //     0xdfba50: add             lr, x0, x17
    //     0xdfba54: ldr             lr, [x21, lr, lsl #3]
    //     0xdfba58: blr             lr
    // 0xdfba5c: tbnz            w0, #4, #0xdfbaa4
    // 0xdfba60: ldur            x0, [fp, #-8]
    // 0xdfba64: LoadField: r1 = r0->field_f
    //     0xdfba64: ldur            w1, [x0, #0xf]
    // 0xdfba68: DecompressPointer r1
    //     0xdfba68: add             x1, x1, HEAP, lsl #32
    // 0xdfba6c: LoadField: r0 = r1->field_33
    //     0xdfba6c: ldur            w0, [x1, #0x33]
    // 0xdfba70: DecompressPointer r0
    //     0xdfba70: add             x0, x0, HEAP, lsl #32
    // 0xdfba74: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfba78: cmp             w0, w16
    // 0xdfba7c: b.ne            #0xdfba8c
    // 0xdfba80: r2 = _colors
    //     0xdfba80: add             x2, PP, #0x26, lsl #12  ; [pp+0x262b8] Field <_RadioDefaultsM3@625266229._colors@625266229>: late final (offset: 0x34)
    //     0xdfba84: ldr             x2, [x2, #0x2b8]
    // 0xdfba88: r0 = InitLateFinalInstanceField()
    //     0xdfba88: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdfba8c: LoadField: r1 = r0->field_7f
    //     0xdfba8c: ldur            w1, [x0, #0x7f]
    // 0xdfba90: DecompressPointer r1
    //     0xdfba90: add             x1, x1, HEAP, lsl #32
    // 0xdfba94: mov             x0, x1
    // 0xdfba98: LeaveFrame
    //     0xdfba98: mov             SP, fp
    //     0xdfba9c: ldp             fp, lr, [SP], #0x10
    // 0xdfbaa0: ret
    //     0xdfbaa0: ret             
    // 0xdfbaa4: ldur            x0, [fp, #-8]
    // 0xdfbaa8: LoadField: r1 = r0->field_f
    //     0xdfbaa8: ldur            w1, [x0, #0xf]
    // 0xdfbaac: DecompressPointer r1
    //     0xdfbaac: add             x1, x1, HEAP, lsl #32
    // 0xdfbab0: LoadField: r0 = r1->field_33
    //     0xdfbab0: ldur            w0, [x1, #0x33]
    // 0xdfbab4: DecompressPointer r0
    //     0xdfbab4: add             x0, x0, HEAP, lsl #32
    // 0xdfbab8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfbabc: cmp             w0, w16
    // 0xdfbac0: b.ne            #0xdfbad0
    // 0xdfbac4: r2 = _colors
    //     0xdfbac4: add             x2, PP, #0x26, lsl #12  ; [pp+0x262b8] Field <_RadioDefaultsM3@625266229._colors@625266229>: late final (offset: 0x34)
    //     0xdfbac8: ldr             x2, [x2, #0x2b8]
    // 0xdfbacc: r0 = InitLateFinalInstanceField()
    //     0xdfbacc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdfbad0: LoadField: r1 = r0->field_a3
    //     0xdfbad0: ldur            w1, [x0, #0xa3]
    // 0xdfbad4: DecompressPointer r1
    //     0xdfbad4: add             x1, x1, HEAP, lsl #32
    // 0xdfbad8: cmp             w1, NULL
    // 0xdfbadc: b.ne            #0xdfbaf0
    // 0xdfbae0: LoadField: r2 = r0->field_7f
    //     0xdfbae0: ldur            w2, [x0, #0x7f]
    // 0xdfbae4: DecompressPointer r2
    //     0xdfbae4: add             x2, x2, HEAP, lsl #32
    // 0xdfbae8: mov             x0, x2
    // 0xdfbaec: b               #0xdfbaf4
    // 0xdfbaf0: mov             x0, x1
    // 0xdfbaf4: LeaveFrame
    //     0xdfbaf4: mov             SP, fp
    //     0xdfbaf8: ldp             fp, lr, [SP], #0x10
    // 0xdfbafc: ret
    //     0xdfbafc: ret             
    // 0xdfbb00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdfbb00: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdfbb04: b               #0xdfb648
  }
}

// class id: 5121, size: 0x38, field offset: 0x2c
class _RadioDefaultsM2 extends RadioThemeData {

  late final ThemeData _theme; // offset: 0x30
  late final ColorScheme _colors; // offset: 0x34

  ThemeData _theme(_RadioDefaultsM2) {
    // ** addr: 0xdfae48, size: 0x38
    // 0xdfae48: EnterFrame
    //     0xdfae48: stp             fp, lr, [SP, #-0x10]!
    //     0xdfae4c: mov             fp, SP
    // 0xdfae50: CheckStackOverflow
    //     0xdfae50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdfae54: cmp             SP, x16
    //     0xdfae58: b.ls            #0xdfae78
    // 0xdfae5c: ldr             x0, [fp, #0x10]
    // 0xdfae60: LoadField: r1 = r0->field_2b
    //     0xdfae60: ldur            w1, [x0, #0x2b]
    // 0xdfae64: DecompressPointer r1
    //     0xdfae64: add             x1, x1, HEAP, lsl #32
    // 0xdfae68: r0 = of()
    //     0xdfae68: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xdfae6c: LeaveFrame
    //     0xdfae6c: mov             SP, fp
    //     0xdfae70: ldp             fp, lr, [SP], #0x10
    // 0xdfae74: ret
    //     0xdfae74: ret             
    // 0xdfae78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdfae78: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdfae7c: b               #0xdfae5c
  }
  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xdfae80, size: 0x1e4
    // 0xdfae80: EnterFrame
    //     0xdfae80: stp             fp, lr, [SP, #-0x10]!
    //     0xdfae84: mov             fp, SP
    // 0xdfae88: AllocStack(0x20)
    //     0xdfae88: sub             SP, SP, #0x20
    // 0xdfae8c: SetupParameters([dynamic _ /* r0 */])
    //     0xdfae8c: ldr             x0, [fp, #0x18]
    //     0xdfae90: ldur            w3, [x0, #0x17]
    //     0xdfae94: add             x3, x3, HEAP, lsl #32
    //     0xdfae98: stur            x3, [fp, #-8]
    // 0xdfae9c: CheckStackOverflow
    //     0xdfae9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdfaea0: cmp             SP, x16
    //     0xdfaea4: b.ls            #0xdfb05c
    // 0xdfaea8: ldr             x4, [fp, #0x10]
    // 0xdfaeac: r0 = LoadClassIdInstr(r4)
    //     0xdfaeac: ldur            x0, [x4, #-1]
    //     0xdfaeb0: ubfx            x0, x0, #0xc, #0x14
    // 0xdfaeb4: mov             x1, x4
    // 0xdfaeb8: r2 = Instance_WidgetState
    //     0xdfaeb8: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0xdfaebc: ldr             x2, [x2, #0xa48]
    // 0xdfaec0: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdfaec0: mov             x17, #0x2929
    //     0xdfaec4: movk            x17, #1, lsl #16
    //     0xdfaec8: add             lr, x0, x17
    //     0xdfaecc: ldr             lr, [x21, lr, lsl #3]
    //     0xdfaed0: blr             lr
    // 0xdfaed4: tbnz            w0, #4, #0xdfaf5c
    // 0xdfaed8: ldur            x3, [fp, #-8]
    // 0xdfaedc: LoadField: r0 = r3->field_f
    //     0xdfaedc: ldur            w0, [x3, #0xf]
    // 0xdfaee0: DecompressPointer r0
    //     0xdfaee0: add             x0, x0, HEAP, lsl #32
    // 0xdfaee4: stur            x0, [fp, #-0x10]
    // 0xdfaee8: r1 = 1
    //     0xdfaee8: mov             x1, #1
    // 0xdfaeec: r0 = AllocateContext()
    //     0xdfaeec: bl              #0x13de838  ; AllocateContextStub
    // 0xdfaef0: mov             x1, x0
    // 0xdfaef4: ldur            x0, [fp, #-0x10]
    // 0xdfaef8: StoreField: r1->field_f = r0
    //     0xdfaef8: stur            w0, [x1, #0xf]
    // 0xdfaefc: mov             x2, x1
    // 0xdfaf00: r1 = Function '<anonymous closure>':.
    //     0xdfaf00: add             x1, PP, #0x26, lsl #12  ; [pp+0x26290] AnonymousClosure: (0xdfb46c), of [package:flutter/src/material/radio.dart] _RadioDefaultsM2
    //     0xdfaf04: ldr             x1, [x1, #0x290]
    // 0xdfaf08: r0 = AllocateClosure()
    //     0xdfaf08: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdfaf0c: r16 = <Color>
    //     0xdfaf0c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xdfaf10: ldr             x16, [x16, #0xa90]
    // 0xdfaf14: stp             x0, x16, [SP]
    // 0xdfaf18: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdfaf18: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdfaf1c: r0 = resolveWith()
    //     0xdfaf1c: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xdfaf20: mov             x1, x0
    // 0xdfaf24: ldr             x2, [fp, #0x10]
    // 0xdfaf28: r0 = build()
    //     0xdfaf28: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xdfaf2c: r1 = LoadClassIdInstr(r0)
    //     0xdfaf2c: ldur            x1, [x0, #-1]
    //     0xdfaf30: ubfx            x1, x1, #0xc, #0x14
    // 0xdfaf34: mov             x16, x0
    // 0xdfaf38: mov             x0, x1
    // 0xdfaf3c: mov             x1, x16
    // 0xdfaf40: r2 = 31
    //     0xdfaf40: mov             x2, #0x1f
    // 0xdfaf44: r0 = GDT[cid_x0 + -0xff4]()
    //     0xdfaf44: sub             lr, x0, #0xff4
    //     0xdfaf48: ldr             lr, [x21, lr, lsl #3]
    //     0xdfaf4c: blr             lr
    // 0xdfaf50: LeaveFrame
    //     0xdfaf50: mov             SP, fp
    //     0xdfaf54: ldp             fp, lr, [SP], #0x10
    // 0xdfaf58: ret
    //     0xdfaf58: ret             
    // 0xdfaf5c: ldr             x4, [fp, #0x10]
    // 0xdfaf60: ldur            x3, [fp, #-8]
    // 0xdfaf64: r0 = LoadClassIdInstr(r4)
    //     0xdfaf64: ldur            x0, [x4, #-1]
    //     0xdfaf68: ubfx            x0, x0, #0xc, #0x14
    // 0xdfaf6c: mov             x1, x4
    // 0xdfaf70: r2 = Instance_WidgetState
    //     0xdfaf70: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xdfaf74: ldr             x2, [x2, #0xa50]
    // 0xdfaf78: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdfaf78: mov             x17, #0x2929
    //     0xdfaf7c: movk            x17, #1, lsl #16
    //     0xdfaf80: add             lr, x0, x17
    //     0xdfaf84: ldr             lr, [x21, lr, lsl #3]
    //     0xdfaf88: blr             lr
    // 0xdfaf8c: tbnz            w0, #4, #0xdfafd4
    // 0xdfaf90: ldur            x3, [fp, #-8]
    // 0xdfaf94: LoadField: r1 = r3->field_f
    //     0xdfaf94: ldur            w1, [x3, #0xf]
    // 0xdfaf98: DecompressPointer r1
    //     0xdfaf98: add             x1, x1, HEAP, lsl #32
    // 0xdfaf9c: LoadField: r0 = r1->field_2f
    //     0xdfaf9c: ldur            w0, [x1, #0x2f]
    // 0xdfafa0: DecompressPointer r0
    //     0xdfafa0: add             x0, x0, HEAP, lsl #32
    // 0xdfafa4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfafa8: cmp             w0, w16
    // 0xdfafac: b.ne            #0xdfafbc
    // 0xdfafb0: r2 = _theme
    //     0xdfafb0: add             x2, PP, #0x26, lsl #12  ; [pp+0x262b0] Field <_RadioDefaultsM2@625266229._theme@625266229>: late final (offset: 0x30)
    //     0xdfafb4: ldr             x2, [x2, #0x2b0]
    // 0xdfafb8: r0 = InitLateFinalInstanceField()
    //     0xdfafb8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdfafbc: LoadField: r1 = r0->field_57
    //     0xdfafbc: ldur            w1, [x0, #0x57]
    // 0xdfafc0: DecompressPointer r1
    //     0xdfafc0: add             x1, x1, HEAP, lsl #32
    // 0xdfafc4: mov             x0, x1
    // 0xdfafc8: LeaveFrame
    //     0xdfafc8: mov             SP, fp
    //     0xdfafcc: ldp             fp, lr, [SP], #0x10
    // 0xdfafd0: ret
    //     0xdfafd0: ret             
    // 0xdfafd4: ldr             x1, [fp, #0x10]
    // 0xdfafd8: ldur            x3, [fp, #-8]
    // 0xdfafdc: r0 = LoadClassIdInstr(r1)
    //     0xdfafdc: ldur            x0, [x1, #-1]
    //     0xdfafe0: ubfx            x0, x0, #0xc, #0x14
    // 0xdfafe4: r2 = Instance_WidgetState
    //     0xdfafe4: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xdfafe8: ldr             x2, [x2, #0xa60]
    // 0xdfafec: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdfafec: mov             x17, #0x2929
    //     0xdfaff0: movk            x17, #1, lsl #16
    //     0xdfaff4: add             lr, x0, x17
    //     0xdfaff8: ldr             lr, [x21, lr, lsl #3]
    //     0xdfaffc: blr             lr
    // 0xdfb000: tbnz            w0, #4, #0xdfb048
    // 0xdfb004: ldur            x0, [fp, #-8]
    // 0xdfb008: LoadField: r1 = r0->field_f
    //     0xdfb008: ldur            w1, [x0, #0xf]
    // 0xdfb00c: DecompressPointer r1
    //     0xdfb00c: add             x1, x1, HEAP, lsl #32
    // 0xdfb010: LoadField: r0 = r1->field_2f
    //     0xdfb010: ldur            w0, [x1, #0x2f]
    // 0xdfb014: DecompressPointer r0
    //     0xdfb014: add             x0, x0, HEAP, lsl #32
    // 0xdfb018: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfb01c: cmp             w0, w16
    // 0xdfb020: b.ne            #0xdfb030
    // 0xdfb024: r2 = _theme
    //     0xdfb024: add             x2, PP, #0x26, lsl #12  ; [pp+0x262b0] Field <_RadioDefaultsM2@625266229._theme@625266229>: late final (offset: 0x30)
    //     0xdfb028: ldr             x2, [x2, #0x2b0]
    // 0xdfb02c: r0 = InitLateFinalInstanceField()
    //     0xdfb02c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdfb030: LoadField: r1 = r0->field_4b
    //     0xdfb030: ldur            w1, [x0, #0x4b]
    // 0xdfb034: DecompressPointer r1
    //     0xdfb034: add             x1, x1, HEAP, lsl #32
    // 0xdfb038: mov             x0, x1
    // 0xdfb03c: LeaveFrame
    //     0xdfb03c: mov             SP, fp
    //     0xdfb040: ldp             fp, lr, [SP], #0x10
    // 0xdfb044: ret
    //     0xdfb044: ret             
    // 0xdfb048: r0 = Instance_Color
    //     0xdfb048: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xdfb04c: ldr             x0, [x0, #0x810]
    // 0xdfb050: LeaveFrame
    //     0xdfb050: mov             SP, fp
    //     0xdfb054: ldp             fp, lr, [SP], #0x10
    // 0xdfb058: ret
    //     0xdfb058: ret             
    // 0xdfb05c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdfb05c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdfb060: b               #0xdfaea8
  }
  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xdfb46c, size: 0x15c
    // 0xdfb46c: EnterFrame
    //     0xdfb46c: stp             fp, lr, [SP, #-0x10]!
    //     0xdfb470: mov             fp, SP
    // 0xdfb474: AllocStack(0x8)
    //     0xdfb474: sub             SP, SP, #8
    // 0xdfb478: SetupParameters([dynamic _ /* r0 */])
    //     0xdfb478: ldr             x0, [fp, #0x18]
    //     0xdfb47c: ldur            w3, [x0, #0x17]
    //     0xdfb480: add             x3, x3, HEAP, lsl #32
    //     0xdfb484: stur            x3, [fp, #-8]
    // 0xdfb488: CheckStackOverflow
    //     0xdfb488: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdfb48c: cmp             SP, x16
    //     0xdfb490: b.ls            #0xdfb5c0
    // 0xdfb494: ldr             x4, [fp, #0x10]
    // 0xdfb498: r0 = LoadClassIdInstr(r4)
    //     0xdfb498: ldur            x0, [x4, #-1]
    //     0xdfb49c: ubfx            x0, x0, #0xc, #0x14
    // 0xdfb4a0: mov             x1, x4
    // 0xdfb4a4: r2 = Instance_WidgetState
    //     0xdfb4a4: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xdfb4a8: ldr             x2, [x2, #0xa70]
    // 0xdfb4ac: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdfb4ac: mov             x17, #0x2929
    //     0xdfb4b0: movk            x17, #1, lsl #16
    //     0xdfb4b4: add             lr, x0, x17
    //     0xdfb4b8: ldr             lr, [x21, lr, lsl #3]
    //     0xdfb4bc: blr             lr
    // 0xdfb4c0: tbnz            w0, #4, #0xdfb508
    // 0xdfb4c4: ldur            x3, [fp, #-8]
    // 0xdfb4c8: LoadField: r1 = r3->field_f
    //     0xdfb4c8: ldur            w1, [x3, #0xf]
    // 0xdfb4cc: DecompressPointer r1
    //     0xdfb4cc: add             x1, x1, HEAP, lsl #32
    // 0xdfb4d0: LoadField: r0 = r1->field_2f
    //     0xdfb4d0: ldur            w0, [x1, #0x2f]
    // 0xdfb4d4: DecompressPointer r0
    //     0xdfb4d4: add             x0, x0, HEAP, lsl #32
    // 0xdfb4d8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfb4dc: cmp             w0, w16
    // 0xdfb4e0: b.ne            #0xdfb4f0
    // 0xdfb4e4: r2 = _theme
    //     0xdfb4e4: add             x2, PP, #0x26, lsl #12  ; [pp+0x262b0] Field <_RadioDefaultsM2@625266229._theme@625266229>: late final (offset: 0x30)
    //     0xdfb4e8: ldr             x2, [x2, #0x2b0]
    // 0xdfb4ec: r0 = InitLateFinalInstanceField()
    //     0xdfb4ec: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdfb4f0: LoadField: r1 = r0->field_43
    //     0xdfb4f0: ldur            w1, [x0, #0x43]
    // 0xdfb4f4: DecompressPointer r1
    //     0xdfb4f4: add             x1, x1, HEAP, lsl #32
    // 0xdfb4f8: mov             x0, x1
    // 0xdfb4fc: LeaveFrame
    //     0xdfb4fc: mov             SP, fp
    //     0xdfb500: ldp             fp, lr, [SP], #0x10
    // 0xdfb504: ret
    //     0xdfb504: ret             
    // 0xdfb508: ldr             x1, [fp, #0x10]
    // 0xdfb50c: ldur            x3, [fp, #-8]
    // 0xdfb510: r0 = LoadClassIdInstr(r1)
    //     0xdfb510: ldur            x0, [x1, #-1]
    //     0xdfb514: ubfx            x0, x0, #0xc, #0x14
    // 0xdfb518: r2 = Instance_WidgetState
    //     0xdfb518: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xdfb51c: ldr             x2, [x2, #0x100]
    // 0xdfb520: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdfb520: mov             x17, #0x2929
    //     0xdfb524: movk            x17, #1, lsl #16
    //     0xdfb528: add             lr, x0, x17
    //     0xdfb52c: ldr             lr, [x21, lr, lsl #3]
    //     0xdfb530: blr             lr
    // 0xdfb534: tbnz            w0, #4, #0xdfb57c
    // 0xdfb538: ldur            x0, [fp, #-8]
    // 0xdfb53c: LoadField: r1 = r0->field_f
    //     0xdfb53c: ldur            w1, [x0, #0xf]
    // 0xdfb540: DecompressPointer r1
    //     0xdfb540: add             x1, x1, HEAP, lsl #32
    // 0xdfb544: LoadField: r0 = r1->field_33
    //     0xdfb544: ldur            w0, [x1, #0x33]
    // 0xdfb548: DecompressPointer r0
    //     0xdfb548: add             x0, x0, HEAP, lsl #32
    // 0xdfb54c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfb550: cmp             w0, w16
    // 0xdfb554: b.ne            #0xdfb564
    // 0xdfb558: r2 = _colors
    //     0xdfb558: add             x2, PP, #0x26, lsl #12  ; [pp+0x262c0] Field <_RadioDefaultsM2@625266229._colors@625266229>: late final (offset: 0x34)
    //     0xdfb55c: ldr             x2, [x2, #0x2c0]
    // 0xdfb560: r0 = InitLateFinalInstanceField()
    //     0xdfb560: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdfb564: LoadField: r1 = r0->field_2b
    //     0xdfb564: ldur            w1, [x0, #0x2b]
    // 0xdfb568: DecompressPointer r1
    //     0xdfb568: add             x1, x1, HEAP, lsl #32
    // 0xdfb56c: mov             x0, x1
    // 0xdfb570: LeaveFrame
    //     0xdfb570: mov             SP, fp
    //     0xdfb574: ldp             fp, lr, [SP], #0x10
    // 0xdfb578: ret
    //     0xdfb578: ret             
    // 0xdfb57c: ldur            x0, [fp, #-8]
    // 0xdfb580: LoadField: r1 = r0->field_f
    //     0xdfb580: ldur            w1, [x0, #0xf]
    // 0xdfb584: DecompressPointer r1
    //     0xdfb584: add             x1, x1, HEAP, lsl #32
    // 0xdfb588: LoadField: r0 = r1->field_2f
    //     0xdfb588: ldur            w0, [x1, #0x2f]
    // 0xdfb58c: DecompressPointer r0
    //     0xdfb58c: add             x0, x0, HEAP, lsl #32
    // 0xdfb590: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfb594: cmp             w0, w16
    // 0xdfb598: b.ne            #0xdfb5a8
    // 0xdfb59c: r2 = _theme
    //     0xdfb59c: add             x2, PP, #0x26, lsl #12  ; [pp+0x262b0] Field <_RadioDefaultsM2@625266229._theme@625266229>: late final (offset: 0x30)
    //     0xdfb5a0: ldr             x2, [x2, #0x2b0]
    // 0xdfb5a4: r0 = InitLateFinalInstanceField()
    //     0xdfb5a4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdfb5a8: LoadField: r1 = r0->field_77
    //     0xdfb5a8: ldur            w1, [x0, #0x77]
    // 0xdfb5ac: DecompressPointer r1
    //     0xdfb5ac: add             x1, x1, HEAP, lsl #32
    // 0xdfb5b0: mov             x0, x1
    // 0xdfb5b4: LeaveFrame
    //     0xdfb5b4: mov             SP, fp
    //     0xdfb5b8: ldp             fp, lr, [SP], #0x10
    // 0xdfb5bc: ret
    //     0xdfb5bc: ret             
    // 0xdfb5c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdfb5c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdfb5c4: b               #0xdfb494
  }
  ColorScheme _colors(_RadioDefaultsM2) {
    // ** addr: 0xdfb5c8, size: 0x58
    // 0xdfb5c8: EnterFrame
    //     0xdfb5c8: stp             fp, lr, [SP, #-0x10]!
    //     0xdfb5cc: mov             fp, SP
    // 0xdfb5d0: CheckStackOverflow
    //     0xdfb5d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdfb5d4: cmp             SP, x16
    //     0xdfb5d8: b.ls            #0xdfb618
    // 0xdfb5dc: ldr             x1, [fp, #0x10]
    // 0xdfb5e0: LoadField: r0 = r1->field_2f
    //     0xdfb5e0: ldur            w0, [x1, #0x2f]
    // 0xdfb5e4: DecompressPointer r0
    //     0xdfb5e4: add             x0, x0, HEAP, lsl #32
    // 0xdfb5e8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfb5ec: cmp             w0, w16
    // 0xdfb5f0: b.ne            #0xdfb600
    // 0xdfb5f4: r2 = _theme
    //     0xdfb5f4: add             x2, PP, #0x26, lsl #12  ; [pp+0x262b0] Field <_RadioDefaultsM2@625266229._theme@625266229>: late final (offset: 0x30)
    //     0xdfb5f8: ldr             x2, [x2, #0x2b0]
    // 0xdfb5fc: r0 = InitLateFinalInstanceField()
    //     0xdfb5fc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdfb600: LoadField: r1 = r0->field_3f
    //     0xdfb600: ldur            w1, [x0, #0x3f]
    // 0xdfb604: DecompressPointer r1
    //     0xdfb604: add             x1, x1, HEAP, lsl #32
    // 0xdfb608: mov             x0, x1
    // 0xdfb60c: LeaveFrame
    //     0xdfb60c: mov             SP, fp
    //     0xdfb610: ldp             fp, lr, [SP], #0x10
    // 0xdfb614: ret
    //     0xdfb614: ret             
    // 0xdfb618: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdfb618: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdfb61c: b               #0xdfb5dc
  }
}

// class id: 5458, size: 0x18, field offset: 0x14
class _RadioPaintState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0xdf9b58, size: 0xfc4
    // 0xdf9b58: EnterFrame
    //     0xdf9b58: stp             fp, lr, [SP, #-0x10]!
    //     0xdf9b5c: mov             fp, SP
    // 0xdf9b60: AllocStack(0x88)
    //     0xdf9b60: sub             SP, SP, #0x88
    // 0xdf9b64: SetupParameters(_RadioPaintState this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xdf9b64: mov             x0, x2
    //     0xdf9b68: stur            x2, [fp, #-0x10]
    //     0xdf9b6c: mov             x2, x1
    //     0xdf9b70: stur            x1, [fp, #-8]
    // 0xdf9b74: CheckStackOverflow
    //     0xdf9b74: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf9b78: cmp             SP, x16
    //     0xdf9b7c: b.ls            #0xdfaa8c
    // 0xdf9b80: mov             x1, x0
    // 0xdf9b84: r0 = of()
    //     0xdf9b84: bl              #0xd32f98  ; [package:flutter/src/material/radio_theme.dart] RadioTheme::of
    // 0xdf9b88: ldur            x1, [fp, #-0x10]
    // 0xdf9b8c: stur            x0, [fp, #-0x18]
    // 0xdf9b90: r0 = of()
    //     0xdf9b90: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xdf9b94: LoadField: r1 = r0->field_2f
    //     0xdf9b94: ldur            w1, [x0, #0x2f]
    // 0xdf9b98: DecompressPointer r1
    //     0xdf9b98: add             x1, x1, HEAP, lsl #32
    // 0xdf9b9c: tbnz            w1, #4, #0xdf9bc8
    // 0xdf9ba0: ldur            x0, [fp, #-0x10]
    // 0xdf9ba4: r0 = _RadioDefaultsM3()
    //     0xdf9ba4: bl              #0xdfad60  ; Allocate_RadioDefaultsM3Stub -> _RadioDefaultsM3 (size=0x38)
    // 0xdf9ba8: mov             x1, x0
    // 0xdf9bac: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf9bb0: StoreField: r1->field_2f = r0
    //     0xdf9bb0: stur            w0, [x1, #0x2f]
    // 0xdf9bb4: StoreField: r1->field_33 = r0
    //     0xdf9bb4: stur            w0, [x1, #0x33]
    // 0xdf9bb8: ldur            x2, [fp, #-0x10]
    // 0xdf9bbc: StoreField: r1->field_2b = r2
    //     0xdf9bbc: stur            w2, [x1, #0x2b]
    // 0xdf9bc0: mov             x3, x1
    // 0xdf9bc4: b               #0xdf9bf0
    // 0xdf9bc8: ldur            x2, [fp, #-0x10]
    // 0xdf9bcc: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf9bd0: r0 = _RadioDefaultsM2()
    //     0xdf9bd0: bl              #0xdfad54  ; Allocate_RadioDefaultsM2Stub -> _RadioDefaultsM2 (size=0x38)
    // 0xdf9bd4: mov             x1, x0
    // 0xdf9bd8: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xdf9bdc: StoreField: r1->field_2f = r0
    //     0xdf9bdc: stur            w0, [x1, #0x2f]
    // 0xdf9be0: StoreField: r1->field_33 = r0
    //     0xdf9be0: stur            w0, [x1, #0x33]
    // 0xdf9be4: ldur            x0, [fp, #-0x10]
    // 0xdf9be8: StoreField: r1->field_2b = r0
    //     0xdf9be8: stur            w0, [x1, #0x2b]
    // 0xdf9bec: mov             x3, x1
    // 0xdf9bf0: ldur            x2, [fp, #-8]
    // 0xdf9bf4: stur            x3, [fp, #-0x10]
    // 0xdf9bf8: LoadField: r0 = r2->field_b
    //     0xdf9bf8: ldur            w0, [x2, #0xb]
    // 0xdf9bfc: DecompressPointer r0
    //     0xdf9bfc: add             x0, x0, HEAP, lsl #32
    // 0xdf9c00: cmp             w0, NULL
    // 0xdf9c04: b.eq            #0xdfaa94
    // 0xdf9c08: LoadField: r1 = r0->field_b
    //     0xdf9c08: ldur            w1, [x0, #0xb]
    // 0xdf9c0c: DecompressPointer r1
    //     0xdf9c0c: add             x1, x1, HEAP, lsl #32
    // 0xdf9c10: r0 = LoadClassIdInstr(r1)
    //     0xdf9c10: ldur            x0, [x1, #-1]
    //     0xdf9c14: ubfx            x0, x0, #0xc, #0x14
    // 0xdf9c18: r0 = GDT[cid_x0 + -0xc50]()
    //     0xdf9c18: sub             lr, x0, #0xc50
    //     0xdf9c1c: ldr             lr, [x21, lr, lsl #3]
    //     0xdf9c20: blr             lr
    // 0xdf9c24: mov             x1, x0
    // 0xdf9c28: r2 = Instance_WidgetState
    //     0xdf9c28: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xdf9c2c: ldr             x2, [x2, #0x100]
    // 0xdf9c30: stur            x0, [fp, #-0x20]
    // 0xdf9c34: r0 = add()
    //     0xdf9c34: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xdf9c38: ldur            x2, [fp, #-8]
    // 0xdf9c3c: LoadField: r0 = r2->field_b
    //     0xdf9c3c: ldur            w0, [x2, #0xb]
    // 0xdf9c40: DecompressPointer r0
    //     0xdf9c40: add             x0, x0, HEAP, lsl #32
    // 0xdf9c44: cmp             w0, NULL
    // 0xdf9c48: b.eq            #0xdfaa98
    // 0xdf9c4c: LoadField: r1 = r0->field_b
    //     0xdf9c4c: ldur            w1, [x0, #0xb]
    // 0xdf9c50: DecompressPointer r1
    //     0xdf9c50: add             x1, x1, HEAP, lsl #32
    // 0xdf9c54: r0 = LoadClassIdInstr(r1)
    //     0xdf9c54: ldur            x0, [x1, #-1]
    //     0xdf9c58: ubfx            x0, x0, #0xc, #0x14
    // 0xdf9c5c: r0 = GDT[cid_x0 + -0xc50]()
    //     0xdf9c5c: sub             lr, x0, #0xc50
    //     0xdf9c60: ldr             lr, [x21, lr, lsl #3]
    //     0xdf9c64: blr             lr
    // 0xdf9c68: mov             x1, x0
    // 0xdf9c6c: r2 = Instance_WidgetState
    //     0xdf9c6c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xdf9c70: ldr             x2, [x2, #0x100]
    // 0xdf9c74: stur            x0, [fp, #-0x28]
    // 0xdf9c78: r0 = remove()
    //     0xdf9c78: bl              #0x115bfd0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::remove
    // 0xdf9c7c: ldur            x1, [fp, #-8]
    // 0xdf9c80: LoadField: r0 = r1->field_b
    //     0xdf9c80: ldur            w0, [x1, #0xb]
    // 0xdf9c84: DecompressPointer r0
    //     0xdf9c84: add             x0, x0, HEAP, lsl #32
    // 0xdf9c88: cmp             w0, NULL
    // 0xdf9c8c: b.eq            #0xdfaa9c
    // 0xdf9c90: r1 = 1
    //     0xdf9c90: mov             x1, #1
    // 0xdf9c94: r0 = AllocateContext()
    //     0xdf9c94: bl              #0x13de838  ; AllocateContextStub
    // 0xdf9c98: mov             x1, x0
    // 0xdf9c9c: ldur            x0, [fp, #-8]
    // 0xdf9ca0: StoreField: r1->field_f = r0
    //     0xdf9ca0: stur            w0, [x1, #0xf]
    // 0xdf9ca4: mov             x2, x1
    // 0xdf9ca8: r1 = Function '<anonymous closure>':.
    //     0xdf9ca8: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4fe8] AnonymousClosure: (0xdfad6c), in [package:flutter/src/material/radio.dart] _RadioPaintState::_widgetFillColor (0xdfacec)
    //     0xdf9cac: ldr             x1, [x1, #0xfe8]
    // 0xdf9cb0: r0 = AllocateClosure()
    //     0xdf9cb0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf9cb4: r16 = <Color?>
    //     0xdf9cb4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xdf9cb8: ldr             x16, [x16, #0xa40]
    // 0xdf9cbc: stp             x0, x16, [SP]
    // 0xdf9cc0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdf9cc0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdf9cc4: r0 = resolveWith()
    //     0xdf9cc4: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xdf9cc8: mov             x1, x0
    // 0xdf9ccc: ldur            x2, [fp, #-0x20]
    // 0xdf9cd0: r0 = build()
    //     0xdf9cd0: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xdf9cd4: cmp             w0, NULL
    // 0xdf9cd8: b.ne            #0xdf9ce0
    // 0xdf9cdc: r0 = Null
    //     0xdf9cdc: mov             x0, NULL
    // 0xdf9ce0: stur            x0, [fp, #-0x30]
    // 0xdf9ce4: cmp             w0, NULL
    // 0xdf9ce8: b.ne            #0xdf9db4
    // 0xdf9cec: ldur            x1, [fp, #-0x10]
    // 0xdf9cf0: r2 = LoadClassIdInstr(r1)
    //     0xdf9cf0: ldur            x2, [x1, #-1]
    //     0xdf9cf4: ubfx            x2, x2, #0xc, #0x14
    // 0xdf9cf8: r17 = 5119
    //     0xdf9cf8: mov             x17, #0x13ff
    // 0xdf9cfc: cmp             x2, x17
    // 0xdf9d00: b.ne            #0xdf9d14
    // 0xdf9d04: LoadField: r2 = r1->field_b
    //     0xdf9d04: ldur            w2, [x1, #0xb]
    // 0xdf9d08: DecompressPointer r2
    //     0xdf9d08: add             x2, x2, HEAP, lsl #32
    // 0xdf9d0c: mov             x1, x2
    // 0xdf9d10: b               #0xdf9d9c
    // 0xdf9d14: r17 = 5120
    //     0xdf9d14: mov             x17, #0x1400
    // 0xdf9d18: cmp             x2, x17
    // 0xdf9d1c: b.ne            #0xdf9d60
    // 0xdf9d20: r1 = 1
    //     0xdf9d20: mov             x1, #1
    // 0xdf9d24: r0 = AllocateContext()
    //     0xdf9d24: bl              #0x13de838  ; AllocateContextStub
    // 0xdf9d28: mov             x1, x0
    // 0xdf9d2c: ldur            x0, [fp, #-0x10]
    // 0xdf9d30: StoreField: r1->field_f = r0
    //     0xdf9d30: stur            w0, [x1, #0xf]
    // 0xdf9d34: mov             x2, x1
    // 0xdf9d38: r1 = Function '<anonymous closure>':.
    //     0xdf9d38: add             x1, PP, #0x26, lsl #12  ; [pp+0x26288] AnonymousClosure: (0xdfb620), of [package:flutter/src/material/radio.dart] _RadioDefaultsM3
    //     0xdf9d3c: ldr             x1, [x1, #0x288]
    // 0xdf9d40: r0 = AllocateClosure()
    //     0xdf9d40: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf9d44: r16 = <Color>
    //     0xdf9d44: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xdf9d48: ldr             x16, [x16, #0xa90]
    // 0xdf9d4c: stp             x0, x16, [SP]
    // 0xdf9d50: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdf9d50: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdf9d54: r0 = resolveWith()
    //     0xdf9d54: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xdf9d58: mov             x1, x0
    // 0xdf9d5c: b               #0xdf9d9c
    // 0xdf9d60: r1 = 1
    //     0xdf9d60: mov             x1, #1
    // 0xdf9d64: r0 = AllocateContext()
    //     0xdf9d64: bl              #0x13de838  ; AllocateContextStub
    // 0xdf9d68: mov             x1, x0
    // 0xdf9d6c: ldur            x0, [fp, #-0x10]
    // 0xdf9d70: StoreField: r1->field_f = r0
    //     0xdf9d70: stur            w0, [x1, #0xf]
    // 0xdf9d74: mov             x2, x1
    // 0xdf9d78: r1 = Function '<anonymous closure>':.
    //     0xdf9d78: add             x1, PP, #0x26, lsl #12  ; [pp+0x26290] AnonymousClosure: (0xdfb46c), of [package:flutter/src/material/radio.dart] _RadioDefaultsM2
    //     0xdf9d7c: ldr             x1, [x1, #0x290]
    // 0xdf9d80: r0 = AllocateClosure()
    //     0xdf9d80: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf9d84: r16 = <Color>
    //     0xdf9d84: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xdf9d88: ldr             x16, [x16, #0xa90]
    // 0xdf9d8c: stp             x0, x16, [SP]
    // 0xdf9d90: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdf9d90: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdf9d94: r0 = resolveWith()
    //     0xdf9d94: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xdf9d98: mov             x1, x0
    // 0xdf9d9c: ldur            x2, [fp, #-0x20]
    // 0xdf9da0: r0 = build()
    //     0xdf9da0: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xdf9da4: cmp             w0, NULL
    // 0xdf9da8: b.eq            #0xdfaaa0
    // 0xdf9dac: mov             x2, x0
    // 0xdf9db0: b               #0xdf9db8
    // 0xdf9db4: ldur            x2, [fp, #-0x30]
    // 0xdf9db8: ldur            x0, [fp, #-8]
    // 0xdf9dbc: stur            x2, [fp, #-0x38]
    // 0xdf9dc0: LoadField: r1 = r0->field_b
    //     0xdf9dc0: ldur            w1, [x0, #0xb]
    // 0xdf9dc4: DecompressPointer r1
    //     0xdf9dc4: add             x1, x1, HEAP, lsl #32
    // 0xdf9dc8: cmp             w1, NULL
    // 0xdf9dcc: b.eq            #0xdfaaa4
    // 0xdf9dd0: mov             x1, x0
    // 0xdf9dd4: r0 = _widgetFillColor()
    //     0xdf9dd4: bl              #0xdfacec  ; [package:flutter/src/material/radio.dart] _RadioPaintState::_widgetFillColor
    // 0xdf9dd8: mov             x1, x0
    // 0xdf9ddc: ldur            x2, [fp, #-0x28]
    // 0xdf9de0: r0 = build()
    //     0xdf9de0: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xdf9de4: cmp             w0, NULL
    // 0xdf9de8: b.ne            #0xdf9df0
    // 0xdf9dec: r0 = Null
    //     0xdf9dec: mov             x0, NULL
    // 0xdf9df0: stur            x0, [fp, #-0x40]
    // 0xdf9df4: cmp             w0, NULL
    // 0xdf9df8: b.ne            #0xdf9ec4
    // 0xdf9dfc: ldur            x1, [fp, #-0x10]
    // 0xdf9e00: r2 = LoadClassIdInstr(r1)
    //     0xdf9e00: ldur            x2, [x1, #-1]
    //     0xdf9e04: ubfx            x2, x2, #0xc, #0x14
    // 0xdf9e08: r17 = 5119
    //     0xdf9e08: mov             x17, #0x13ff
    // 0xdf9e0c: cmp             x2, x17
    // 0xdf9e10: b.ne            #0xdf9e24
    // 0xdf9e14: LoadField: r2 = r1->field_b
    //     0xdf9e14: ldur            w2, [x1, #0xb]
    // 0xdf9e18: DecompressPointer r2
    //     0xdf9e18: add             x2, x2, HEAP, lsl #32
    // 0xdf9e1c: mov             x1, x2
    // 0xdf9e20: b               #0xdf9eac
    // 0xdf9e24: r17 = 5120
    //     0xdf9e24: mov             x17, #0x1400
    // 0xdf9e28: cmp             x2, x17
    // 0xdf9e2c: b.ne            #0xdf9e70
    // 0xdf9e30: r1 = 1
    //     0xdf9e30: mov             x1, #1
    // 0xdf9e34: r0 = AllocateContext()
    //     0xdf9e34: bl              #0x13de838  ; AllocateContextStub
    // 0xdf9e38: mov             x1, x0
    // 0xdf9e3c: ldur            x0, [fp, #-0x10]
    // 0xdf9e40: StoreField: r1->field_f = r0
    //     0xdf9e40: stur            w0, [x1, #0xf]
    // 0xdf9e44: mov             x2, x1
    // 0xdf9e48: r1 = Function '<anonymous closure>':.
    //     0xdf9e48: add             x1, PP, #0x26, lsl #12  ; [pp+0x26288] AnonymousClosure: (0xdfb620), of [package:flutter/src/material/radio.dart] _RadioDefaultsM3
    //     0xdf9e4c: ldr             x1, [x1, #0x288]
    // 0xdf9e50: r0 = AllocateClosure()
    //     0xdf9e50: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf9e54: r16 = <Color>
    //     0xdf9e54: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xdf9e58: ldr             x16, [x16, #0xa90]
    // 0xdf9e5c: stp             x0, x16, [SP]
    // 0xdf9e60: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdf9e60: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdf9e64: r0 = resolveWith()
    //     0xdf9e64: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xdf9e68: mov             x1, x0
    // 0xdf9e6c: b               #0xdf9eac
    // 0xdf9e70: r1 = 1
    //     0xdf9e70: mov             x1, #1
    // 0xdf9e74: r0 = AllocateContext()
    //     0xdf9e74: bl              #0x13de838  ; AllocateContextStub
    // 0xdf9e78: mov             x1, x0
    // 0xdf9e7c: ldur            x0, [fp, #-0x10]
    // 0xdf9e80: StoreField: r1->field_f = r0
    //     0xdf9e80: stur            w0, [x1, #0xf]
    // 0xdf9e84: mov             x2, x1
    // 0xdf9e88: r1 = Function '<anonymous closure>':.
    //     0xdf9e88: add             x1, PP, #0x26, lsl #12  ; [pp+0x26290] AnonymousClosure: (0xdfb46c), of [package:flutter/src/material/radio.dart] _RadioDefaultsM2
    //     0xdf9e8c: ldr             x1, [x1, #0x290]
    // 0xdf9e90: r0 = AllocateClosure()
    //     0xdf9e90: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf9e94: r16 = <Color>
    //     0xdf9e94: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xdf9e98: ldr             x16, [x16, #0xa90]
    // 0xdf9e9c: stp             x0, x16, [SP]
    // 0xdf9ea0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdf9ea0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdf9ea4: r0 = resolveWith()
    //     0xdf9ea4: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xdf9ea8: mov             x1, x0
    // 0xdf9eac: ldur            x2, [fp, #-0x28]
    // 0xdf9eb0: r0 = build()
    //     0xdf9eb0: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xdf9eb4: cmp             w0, NULL
    // 0xdf9eb8: b.eq            #0xdfaaa8
    // 0xdf9ebc: mov             x2, x0
    // 0xdf9ec0: b               #0xdf9ec8
    // 0xdf9ec4: ldur            x2, [fp, #-0x40]
    // 0xdf9ec8: ldur            x0, [fp, #-8]
    // 0xdf9ecc: ldur            x1, [fp, #-0x10]
    // 0xdf9ed0: stur            x2, [fp, #-0x50]
    // 0xdf9ed4: LoadField: r3 = r0->field_b
    //     0xdf9ed4: ldur            w3, [x0, #0xb]
    // 0xdf9ed8: DecompressPointer r3
    //     0xdf9ed8: add             x3, x3, HEAP, lsl #32
    // 0xdf9edc: cmp             w3, NULL
    // 0xdf9ee0: b.eq            #0xdfaaac
    // 0xdf9ee4: r3 = LoadClassIdInstr(r1)
    //     0xdf9ee4: ldur            x3, [x1, #-1]
    //     0xdf9ee8: ubfx            x3, x3, #0xc, #0x14
    // 0xdf9eec: stur            x3, [fp, #-0x48]
    // 0xdf9ef0: r17 = 5119
    //     0xdf9ef0: mov             x17, #0x13ff
    // 0xdf9ef4: cmp             x3, x17
    // 0xdf9ef8: b.ne            #0xdf9f14
    // 0xdf9efc: LoadField: r4 = r1->field_1f
    //     0xdf9efc: ldur            w4, [x1, #0x1f]
    // 0xdf9f00: DecompressPointer r4
    //     0xdf9f00: add             x4, x4, HEAP, lsl #32
    // 0xdf9f04: mov             x2, x4
    // 0xdf9f08: mov             x1, x0
    // 0xdf9f0c: mov             x0, x3
    // 0xdf9f10: b               #0xdf9f74
    // 0xdf9f14: r17 = 5120
    //     0xdf9f14: mov             x17, #0x1400
    // 0xdf9f18: cmp             x3, x17
    // 0xdf9f1c: b.ne            #0xdf9f4c
    // 0xdf9f20: r16 = <Color>
    //     0xdf9f20: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xdf9f24: ldr             x16, [x16, #0xa90]
    // 0xdf9f28: r30 = Instance_Color
    //     0xdf9f28: add             lr, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xdf9f2c: ldr             lr, [lr, #0x810]
    // 0xdf9f30: stp             lr, x16, [SP]
    // 0xdf9f34: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdf9f34: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdf9f38: r0 = all()
    //     0xdf9f38: bl              #0xd13288  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::all
    // 0xdf9f3c: mov             x2, x0
    // 0xdf9f40: ldur            x1, [fp, #-8]
    // 0xdf9f44: ldur            x0, [fp, #-0x48]
    // 0xdf9f48: b               #0xdf9f74
    // 0xdf9f4c: r16 = <Color>
    //     0xdf9f4c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xdf9f50: ldr             x16, [x16, #0xa90]
    // 0xdf9f54: r30 = Instance_Color
    //     0xdf9f54: add             lr, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xdf9f58: ldr             lr, [lr, #0x810]
    // 0xdf9f5c: stp             lr, x16, [SP]
    // 0xdf9f60: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdf9f60: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdf9f64: r0 = all()
    //     0xdf9f64: bl              #0xd13288  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::all
    // 0xdf9f68: mov             x2, x0
    // 0xdf9f6c: ldur            x1, [fp, #-8]
    // 0xdf9f70: ldur            x0, [fp, #-0x48]
    // 0xdf9f74: LoadField: r3 = r2->field_b
    //     0xdf9f74: ldur            w3, [x2, #0xb]
    // 0xdf9f78: DecompressPointer r3
    //     0xdf9f78: add             x3, x3, HEAP, lsl #32
    // 0xdf9f7c: stur            x3, [fp, #-0x58]
    // 0xdf9f80: cmp             w3, NULL
    // 0xdf9f84: b.eq            #0xdfaab0
    // 0xdf9f88: LoadField: r2 = r1->field_b
    //     0xdf9f88: ldur            w2, [x1, #0xb]
    // 0xdf9f8c: DecompressPointer r2
    //     0xdf9f8c: add             x2, x2, HEAP, lsl #32
    // 0xdf9f90: cmp             w2, NULL
    // 0xdf9f94: b.eq            #0xdfaab4
    // 0xdf9f98: r17 = 5119
    //     0xdf9f98: mov             x17, #0x13ff
    // 0xdf9f9c: cmp             x0, x17
    // 0xdf9fa0: b.ne            #0xdf9fc0
    // 0xdf9fa4: ldur            x2, [fp, #-0x10]
    // 0xdf9fa8: LoadField: r4 = r2->field_1f
    //     0xdf9fa8: ldur            w4, [x2, #0x1f]
    // 0xdf9fac: DecompressPointer r4
    //     0xdf9fac: add             x4, x4, HEAP, lsl #32
    // 0xdf9fb0: mov             x3, x0
    // 0xdf9fb4: mov             x0, x4
    // 0xdf9fb8: mov             x2, x1
    // 0xdf9fbc: b               #0xdfa01c
    // 0xdf9fc0: ldur            x2, [fp, #-0x10]
    // 0xdf9fc4: r17 = 5120
    //     0xdf9fc4: mov             x17, #0x1400
    // 0xdf9fc8: cmp             x0, x17
    // 0xdf9fcc: b.ne            #0xdf9ff8
    // 0xdf9fd0: r16 = <Color>
    //     0xdf9fd0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xdf9fd4: ldr             x16, [x16, #0xa90]
    // 0xdf9fd8: r30 = Instance_Color
    //     0xdf9fd8: add             lr, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xdf9fdc: ldr             lr, [lr, #0x810]
    // 0xdf9fe0: stp             lr, x16, [SP]
    // 0xdf9fe4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdf9fe4: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdf9fe8: r0 = all()
    //     0xdf9fe8: bl              #0xd13288  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::all
    // 0xdf9fec: ldur            x2, [fp, #-8]
    // 0xdf9ff0: ldur            x3, [fp, #-0x48]
    // 0xdf9ff4: b               #0xdfa01c
    // 0xdf9ff8: r16 = <Color>
    //     0xdf9ff8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xdf9ffc: ldr             x16, [x16, #0xa90]
    // 0xdfa000: r30 = Instance_Color
    //     0xdfa000: add             lr, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xdfa004: ldr             lr, [lr, #0x810]
    // 0xdfa008: stp             lr, x16, [SP]
    // 0xdfa00c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdfa00c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdfa010: r0 = all()
    //     0xdfa010: bl              #0xd13288  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::all
    // 0xdfa014: ldur            x2, [fp, #-8]
    // 0xdfa018: ldur            x3, [fp, #-0x48]
    // 0xdfa01c: LoadField: r4 = r0->field_b
    //     0xdfa01c: ldur            w4, [x0, #0xb]
    // 0xdfa020: DecompressPointer r4
    //     0xdfa020: add             x4, x4, HEAP, lsl #32
    // 0xdfa024: stur            x4, [fp, #-0x60]
    // 0xdfa028: cmp             w4, NULL
    // 0xdfa02c: b.eq            #0xdfaab8
    // 0xdfa030: LoadField: r0 = r2->field_b
    //     0xdfa030: ldur            w0, [x2, #0xb]
    // 0xdfa034: DecompressPointer r0
    //     0xdfa034: add             x0, x0, HEAP, lsl #32
    // 0xdfa038: cmp             w0, NULL
    // 0xdfa03c: b.eq            #0xdfaabc
    // 0xdfa040: LoadField: r1 = r0->field_b
    //     0xdfa040: ldur            w1, [x0, #0xb]
    // 0xdfa044: DecompressPointer r1
    //     0xdfa044: add             x1, x1, HEAP, lsl #32
    // 0xdfa048: r0 = LoadClassIdInstr(r1)
    //     0xdfa048: ldur            x0, [x1, #-1]
    //     0xdfa04c: ubfx            x0, x0, #0xc, #0x14
    // 0xdfa050: r0 = GDT[cid_x0 + -0xc50]()
    //     0xdfa050: sub             lr, x0, #0xc50
    //     0xdfa054: ldr             lr, [x21, lr, lsl #3]
    //     0xdfa058: blr             lr
    // 0xdfa05c: mov             x1, x0
    // 0xdfa060: r2 = Instance_WidgetState
    //     0xdfa060: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xdfa064: ldr             x2, [x2, #0xa60]
    // 0xdfa068: stur            x0, [fp, #-0x68]
    // 0xdfa06c: r0 = add()
    //     0xdfa06c: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xdfa070: ldur            x1, [fp, #-8]
    // 0xdfa074: LoadField: r0 = r1->field_b
    //     0xdfa074: ldur            w0, [x1, #0xb]
    // 0xdfa078: DecompressPointer r0
    //     0xdfa078: add             x0, x0, HEAP, lsl #32
    // 0xdfa07c: cmp             w0, NULL
    // 0xdfa080: b.eq            #0xdfaac0
    // 0xdfa084: ldur            x0, [fp, #-0x48]
    // 0xdfa088: r17 = 5119
    //     0xdfa088: mov             x17, #0x13ff
    // 0xdfa08c: cmp             x0, x17
    // 0xdfa090: b.ne            #0xdfa0bc
    // 0xdfa094: ldur            x2, [fp, #-0x10]
    // 0xdfa098: LoadField: r3 = r2->field_f
    //     0xdfa098: ldur            w3, [x2, #0xf]
    // 0xdfa09c: DecompressPointer r3
    //     0xdfa09c: add             x3, x3, HEAP, lsl #32
    // 0xdfa0a0: mov             x16, x0
    // 0xdfa0a4: mov             x0, x3
    // 0xdfa0a8: mov             x3, x16
    // 0xdfa0ac: mov             x16, x1
    // 0xdfa0b0: mov             x1, x0
    // 0xdfa0b4: mov             x0, x16
    // 0xdfa0b8: b               #0xdfa15c
    // 0xdfa0bc: ldur            x2, [fp, #-0x10]
    // 0xdfa0c0: r17 = 5120
    //     0xdfa0c0: mov             x17, #0x1400
    // 0xdfa0c4: cmp             x0, x17
    // 0xdfa0c8: b.ne            #0xdfa114
    // 0xdfa0cc: r1 = 1
    //     0xdfa0cc: mov             x1, #1
    // 0xdfa0d0: r0 = AllocateContext()
    //     0xdfa0d0: bl              #0x13de838  ; AllocateContextStub
    // 0xdfa0d4: mov             x1, x0
    // 0xdfa0d8: ldur            x0, [fp, #-0x10]
    // 0xdfa0dc: StoreField: r1->field_f = r0
    //     0xdfa0dc: stur            w0, [x1, #0xf]
    // 0xdfa0e0: mov             x2, x1
    // 0xdfa0e4: r1 = Function '<anonymous closure>':.
    //     0xdfa0e4: add             x1, PP, #0x26, lsl #12  ; [pp+0x26298] AnonymousClosure: (0xdfb064), of [package:flutter/src/material/radio.dart] _RadioDefaultsM3
    //     0xdfa0e8: ldr             x1, [x1, #0x298]
    // 0xdfa0ec: r0 = AllocateClosure()
    //     0xdfa0ec: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdfa0f0: r16 = <Color>
    //     0xdfa0f0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xdfa0f4: ldr             x16, [x16, #0xa90]
    // 0xdfa0f8: stp             x0, x16, [SP]
    // 0xdfa0fc: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdfa0fc: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdfa100: r0 = resolveWith()
    //     0xdfa100: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xdfa104: mov             x1, x0
    // 0xdfa108: ldur            x0, [fp, #-8]
    // 0xdfa10c: ldur            x3, [fp, #-0x48]
    // 0xdfa110: b               #0xdfa15c
    // 0xdfa114: mov             x1, x2
    // 0xdfa118: r1 = 1
    //     0xdfa118: mov             x1, #1
    // 0xdfa11c: r0 = AllocateContext()
    //     0xdfa11c: bl              #0x13de838  ; AllocateContextStub
    // 0xdfa120: mov             x1, x0
    // 0xdfa124: ldur            x0, [fp, #-0x10]
    // 0xdfa128: StoreField: r1->field_f = r0
    //     0xdfa128: stur            w0, [x1, #0xf]
    // 0xdfa12c: mov             x2, x1
    // 0xdfa130: r1 = Function '<anonymous closure>':.
    //     0xdfa130: add             x1, PP, #0x26, lsl #12  ; [pp+0x262a0] AnonymousClosure: (0xdfae80), of [package:flutter/src/material/radio.dart] _RadioDefaultsM2
    //     0xdfa134: ldr             x1, [x1, #0x2a0]
    // 0xdfa138: r0 = AllocateClosure()
    //     0xdfa138: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdfa13c: r16 = <Color>
    //     0xdfa13c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xdfa140: ldr             x16, [x16, #0xa90]
    // 0xdfa144: stp             x0, x16, [SP]
    // 0xdfa148: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdfa148: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdfa14c: r0 = resolveWith()
    //     0xdfa14c: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xdfa150: mov             x1, x0
    // 0xdfa154: ldur            x0, [fp, #-8]
    // 0xdfa158: ldur            x3, [fp, #-0x48]
    // 0xdfa15c: ldur            x2, [fp, #-0x68]
    // 0xdfa160: r0 = build()
    //     0xdfa160: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xdfa164: mov             x2, x0
    // 0xdfa168: stur            x2, [fp, #-0x68]
    // 0xdfa16c: cmp             w2, NULL
    // 0xdfa170: b.eq            #0xdfaac4
    // 0xdfa174: ldur            x3, [fp, #-8]
    // 0xdfa178: LoadField: r0 = r3->field_b
    //     0xdfa178: ldur            w0, [x3, #0xb]
    // 0xdfa17c: DecompressPointer r0
    //     0xdfa17c: add             x0, x0, HEAP, lsl #32
    // 0xdfa180: cmp             w0, NULL
    // 0xdfa184: b.eq            #0xdfaac8
    // 0xdfa188: LoadField: r1 = r0->field_b
    //     0xdfa188: ldur            w1, [x0, #0xb]
    // 0xdfa18c: DecompressPointer r1
    //     0xdfa18c: add             x1, x1, HEAP, lsl #32
    // 0xdfa190: r0 = LoadClassIdInstr(r1)
    //     0xdfa190: ldur            x0, [x1, #-1]
    //     0xdfa194: ubfx            x0, x0, #0xc, #0x14
    // 0xdfa198: r0 = GDT[cid_x0 + -0xc50]()
    //     0xdfa198: sub             lr, x0, #0xc50
    //     0xdfa19c: ldr             lr, [x21, lr, lsl #3]
    //     0xdfa1a0: blr             lr
    // 0xdfa1a4: mov             x1, x0
    // 0xdfa1a8: r2 = Instance_WidgetState
    //     0xdfa1a8: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xdfa1ac: ldr             x2, [x2, #0xa50]
    // 0xdfa1b0: stur            x0, [fp, #-0x70]
    // 0xdfa1b4: r0 = add()
    //     0xdfa1b4: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xdfa1b8: ldur            x1, [fp, #-8]
    // 0xdfa1bc: LoadField: r0 = r1->field_b
    //     0xdfa1bc: ldur            w0, [x1, #0xb]
    // 0xdfa1c0: DecompressPointer r0
    //     0xdfa1c0: add             x0, x0, HEAP, lsl #32
    // 0xdfa1c4: cmp             w0, NULL
    // 0xdfa1c8: b.eq            #0xdfaacc
    // 0xdfa1cc: ldur            x0, [fp, #-0x48]
    // 0xdfa1d0: r17 = 5119
    //     0xdfa1d0: mov             x17, #0x13ff
    // 0xdfa1d4: cmp             x0, x17
    // 0xdfa1d8: b.ne            #0xdfa1f4
    // 0xdfa1dc: ldur            x2, [fp, #-0x10]
    // 0xdfa1e0: LoadField: r3 = r2->field_f
    //     0xdfa1e0: ldur            w3, [x2, #0xf]
    // 0xdfa1e4: DecompressPointer r3
    //     0xdfa1e4: add             x3, x3, HEAP, lsl #32
    // 0xdfa1e8: mov             x0, x1
    // 0xdfa1ec: mov             x1, x3
    // 0xdfa1f0: b               #0xdfa28c
    // 0xdfa1f4: ldur            x2, [fp, #-0x10]
    // 0xdfa1f8: r17 = 5120
    //     0xdfa1f8: mov             x17, #0x1400
    // 0xdfa1fc: cmp             x0, x17
    // 0xdfa200: b.ne            #0xdfa248
    // 0xdfa204: r1 = 1
    //     0xdfa204: mov             x1, #1
    // 0xdfa208: r0 = AllocateContext()
    //     0xdfa208: bl              #0x13de838  ; AllocateContextStub
    // 0xdfa20c: mov             x1, x0
    // 0xdfa210: ldur            x0, [fp, #-0x10]
    // 0xdfa214: StoreField: r1->field_f = r0
    //     0xdfa214: stur            w0, [x1, #0xf]
    // 0xdfa218: mov             x2, x1
    // 0xdfa21c: r1 = Function '<anonymous closure>':.
    //     0xdfa21c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26298] AnonymousClosure: (0xdfb064), of [package:flutter/src/material/radio.dart] _RadioDefaultsM3
    //     0xdfa220: ldr             x1, [x1, #0x298]
    // 0xdfa224: r0 = AllocateClosure()
    //     0xdfa224: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdfa228: r16 = <Color>
    //     0xdfa228: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xdfa22c: ldr             x16, [x16, #0xa90]
    // 0xdfa230: stp             x0, x16, [SP]
    // 0xdfa234: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdfa234: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdfa238: r0 = resolveWith()
    //     0xdfa238: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xdfa23c: mov             x1, x0
    // 0xdfa240: ldur            x0, [fp, #-8]
    // 0xdfa244: b               #0xdfa28c
    // 0xdfa248: mov             x1, x2
    // 0xdfa24c: r1 = 1
    //     0xdfa24c: mov             x1, #1
    // 0xdfa250: r0 = AllocateContext()
    //     0xdfa250: bl              #0x13de838  ; AllocateContextStub
    // 0xdfa254: mov             x1, x0
    // 0xdfa258: ldur            x0, [fp, #-0x10]
    // 0xdfa25c: StoreField: r1->field_f = r0
    //     0xdfa25c: stur            w0, [x1, #0xf]
    // 0xdfa260: mov             x2, x1
    // 0xdfa264: r1 = Function '<anonymous closure>':.
    //     0xdfa264: add             x1, PP, #0x26, lsl #12  ; [pp+0x262a0] AnonymousClosure: (0xdfae80), of [package:flutter/src/material/radio.dart] _RadioDefaultsM2
    //     0xdfa268: ldr             x1, [x1, #0x2a0]
    // 0xdfa26c: r0 = AllocateClosure()
    //     0xdfa26c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdfa270: r16 = <Color>
    //     0xdfa270: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xdfa274: ldr             x16, [x16, #0xa90]
    // 0xdfa278: stp             x0, x16, [SP]
    // 0xdfa27c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdfa27c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdfa280: r0 = resolveWith()
    //     0xdfa280: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xdfa284: mov             x1, x0
    // 0xdfa288: ldur            x0, [fp, #-8]
    // 0xdfa28c: ldur            x3, [fp, #-0x30]
    // 0xdfa290: ldur            x2, [fp, #-0x70]
    // 0xdfa294: r0 = build()
    //     0xdfa294: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xdfa298: stur            x0, [fp, #-0x70]
    // 0xdfa29c: cmp             w0, NULL
    // 0xdfa2a0: b.eq            #0xdfaad0
    // 0xdfa2a4: ldur            x1, [fp, #-0x20]
    // 0xdfa2a8: r2 = Instance_WidgetState
    //     0xdfa2a8: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0xdfa2ac: ldr             x2, [x2, #0xa48]
    // 0xdfa2b0: r0 = add()
    //     0xdfa2b0: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xdfa2b4: ldur            x3, [fp, #-8]
    // 0xdfa2b8: LoadField: r0 = r3->field_b
    //     0xdfa2b8: ldur            w0, [x3, #0xb]
    // 0xdfa2bc: DecompressPointer r0
    //     0xdfa2bc: add             x0, x0, HEAP, lsl #32
    // 0xdfa2c0: cmp             w0, NULL
    // 0xdfa2c4: b.eq            #0xdfaad4
    // 0xdfa2c8: ldur            x1, [fp, #-0x30]
    // 0xdfa2cc: cmp             w1, NULL
    // 0xdfa2d0: b.ne            #0xdfa2dc
    // 0xdfa2d4: r0 = Null
    //     0xdfa2d4: mov             x0, NULL
    // 0xdfa2d8: b               #0xdfa2f4
    // 0xdfa2dc: r0 = LoadClassIdInstr(r1)
    //     0xdfa2dc: ldur            x0, [x1, #-1]
    //     0xdfa2e0: ubfx            x0, x0, #0xc, #0x14
    // 0xdfa2e4: r2 = 31
    //     0xdfa2e4: mov             x2, #0x1f
    // 0xdfa2e8: r0 = GDT[cid_x0 + -0xff4]()
    //     0xdfa2e8: sub             lr, x0, #0xff4
    //     0xdfa2ec: ldr             lr, [x21, lr, lsl #3]
    //     0xdfa2f0: blr             lr
    // 0xdfa2f4: cmp             w0, NULL
    // 0xdfa2f8: b.ne            #0xdfa3c4
    // 0xdfa2fc: ldur            x0, [fp, #-0x48]
    // 0xdfa300: r17 = 5119
    //     0xdfa300: mov             x17, #0x13ff
    // 0xdfa304: cmp             x0, x17
    // 0xdfa308: b.ne            #0xdfa320
    // 0xdfa30c: ldur            x1, [fp, #-0x10]
    // 0xdfa310: LoadField: r2 = r1->field_f
    //     0xdfa310: ldur            w2, [x1, #0xf]
    // 0xdfa314: DecompressPointer r2
    //     0xdfa314: add             x2, x2, HEAP, lsl #32
    // 0xdfa318: mov             x1, x2
    // 0xdfa31c: b               #0xdfa3ac
    // 0xdfa320: ldur            x1, [fp, #-0x10]
    // 0xdfa324: r17 = 5120
    //     0xdfa324: mov             x17, #0x1400
    // 0xdfa328: cmp             x0, x17
    // 0xdfa32c: b.ne            #0xdfa370
    // 0xdfa330: r1 = 1
    //     0xdfa330: mov             x1, #1
    // 0xdfa334: r0 = AllocateContext()
    //     0xdfa334: bl              #0x13de838  ; AllocateContextStub
    // 0xdfa338: mov             x1, x0
    // 0xdfa33c: ldur            x0, [fp, #-0x10]
    // 0xdfa340: StoreField: r1->field_f = r0
    //     0xdfa340: stur            w0, [x1, #0xf]
    // 0xdfa344: mov             x2, x1
    // 0xdfa348: r1 = Function '<anonymous closure>':.
    //     0xdfa348: add             x1, PP, #0x26, lsl #12  ; [pp+0x26298] AnonymousClosure: (0xdfb064), of [package:flutter/src/material/radio.dart] _RadioDefaultsM3
    //     0xdfa34c: ldr             x1, [x1, #0x298]
    // 0xdfa350: r0 = AllocateClosure()
    //     0xdfa350: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdfa354: r16 = <Color>
    //     0xdfa354: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xdfa358: ldr             x16, [x16, #0xa90]
    // 0xdfa35c: stp             x0, x16, [SP]
    // 0xdfa360: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdfa360: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdfa364: r0 = resolveWith()
    //     0xdfa364: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xdfa368: mov             x1, x0
    // 0xdfa36c: b               #0xdfa3ac
    // 0xdfa370: r1 = 1
    //     0xdfa370: mov             x1, #1
    // 0xdfa374: r0 = AllocateContext()
    //     0xdfa374: bl              #0x13de838  ; AllocateContextStub
    // 0xdfa378: mov             x1, x0
    // 0xdfa37c: ldur            x0, [fp, #-0x10]
    // 0xdfa380: StoreField: r1->field_f = r0
    //     0xdfa380: stur            w0, [x1, #0xf]
    // 0xdfa384: mov             x2, x1
    // 0xdfa388: r1 = Function '<anonymous closure>':.
    //     0xdfa388: add             x1, PP, #0x26, lsl #12  ; [pp+0x262a0] AnonymousClosure: (0xdfae80), of [package:flutter/src/material/radio.dart] _RadioDefaultsM2
    //     0xdfa38c: ldr             x1, [x1, #0x2a0]
    // 0xdfa390: r0 = AllocateClosure()
    //     0xdfa390: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdfa394: r16 = <Color>
    //     0xdfa394: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xdfa398: ldr             x16, [x16, #0xa90]
    // 0xdfa39c: stp             x0, x16, [SP]
    // 0xdfa3a0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdfa3a0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdfa3a4: r0 = resolveWith()
    //     0xdfa3a4: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xdfa3a8: mov             x1, x0
    // 0xdfa3ac: ldur            x2, [fp, #-0x20]
    // 0xdfa3b0: r0 = build()
    //     0xdfa3b0: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xdfa3b4: cmp             w0, NULL
    // 0xdfa3b8: b.eq            #0xdfaad8
    // 0xdfa3bc: mov             x4, x0
    // 0xdfa3c0: b               #0xdfa3c8
    // 0xdfa3c4: mov             x4, x0
    // 0xdfa3c8: ldur            x0, [fp, #-8]
    // 0xdfa3cc: ldur            x3, [fp, #-0x40]
    // 0xdfa3d0: ldur            x1, [fp, #-0x28]
    // 0xdfa3d4: stur            x4, [fp, #-0x30]
    // 0xdfa3d8: r2 = Instance_WidgetState
    //     0xdfa3d8: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0xdfa3dc: ldr             x2, [x2, #0xa48]
    // 0xdfa3e0: r0 = add()
    //     0xdfa3e0: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xdfa3e4: ldur            x3, [fp, #-8]
    // 0xdfa3e8: LoadField: r0 = r3->field_b
    //     0xdfa3e8: ldur            w0, [x3, #0xb]
    // 0xdfa3ec: DecompressPointer r0
    //     0xdfa3ec: add             x0, x0, HEAP, lsl #32
    // 0xdfa3f0: cmp             w0, NULL
    // 0xdfa3f4: b.eq            #0xdfaadc
    // 0xdfa3f8: ldur            x1, [fp, #-0x40]
    // 0xdfa3fc: cmp             w1, NULL
    // 0xdfa400: b.ne            #0xdfa40c
    // 0xdfa404: r0 = Null
    //     0xdfa404: mov             x0, NULL
    // 0xdfa408: b               #0xdfa424
    // 0xdfa40c: r0 = LoadClassIdInstr(r1)
    //     0xdfa40c: ldur            x0, [x1, #-1]
    //     0xdfa410: ubfx            x0, x0, #0xc, #0x14
    // 0xdfa414: r2 = 31
    //     0xdfa414: mov             x2, #0x1f
    // 0xdfa418: r0 = GDT[cid_x0 + -0xff4]()
    //     0xdfa418: sub             lr, x0, #0xff4
    //     0xdfa41c: ldr             lr, [x21, lr, lsl #3]
    //     0xdfa420: blr             lr
    // 0xdfa424: cmp             w0, NULL
    // 0xdfa428: b.ne            #0xdfa4f4
    // 0xdfa42c: ldur            x0, [fp, #-0x48]
    // 0xdfa430: r17 = 5119
    //     0xdfa430: mov             x17, #0x13ff
    // 0xdfa434: cmp             x0, x17
    // 0xdfa438: b.ne            #0xdfa450
    // 0xdfa43c: ldur            x1, [fp, #-0x10]
    // 0xdfa440: LoadField: r2 = r1->field_f
    //     0xdfa440: ldur            w2, [x1, #0xf]
    // 0xdfa444: DecompressPointer r2
    //     0xdfa444: add             x2, x2, HEAP, lsl #32
    // 0xdfa448: mov             x1, x2
    // 0xdfa44c: b               #0xdfa4dc
    // 0xdfa450: ldur            x1, [fp, #-0x10]
    // 0xdfa454: r17 = 5120
    //     0xdfa454: mov             x17, #0x1400
    // 0xdfa458: cmp             x0, x17
    // 0xdfa45c: b.ne            #0xdfa4a0
    // 0xdfa460: r1 = 1
    //     0xdfa460: mov             x1, #1
    // 0xdfa464: r0 = AllocateContext()
    //     0xdfa464: bl              #0x13de838  ; AllocateContextStub
    // 0xdfa468: mov             x1, x0
    // 0xdfa46c: ldur            x0, [fp, #-0x10]
    // 0xdfa470: StoreField: r1->field_f = r0
    //     0xdfa470: stur            w0, [x1, #0xf]
    // 0xdfa474: mov             x2, x1
    // 0xdfa478: r1 = Function '<anonymous closure>':.
    //     0xdfa478: add             x1, PP, #0x26, lsl #12  ; [pp+0x26298] AnonymousClosure: (0xdfb064), of [package:flutter/src/material/radio.dart] _RadioDefaultsM3
    //     0xdfa47c: ldr             x1, [x1, #0x298]
    // 0xdfa480: r0 = AllocateClosure()
    //     0xdfa480: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdfa484: r16 = <Color>
    //     0xdfa484: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xdfa488: ldr             x16, [x16, #0xa90]
    // 0xdfa48c: stp             x0, x16, [SP]
    // 0xdfa490: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdfa490: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdfa494: r0 = resolveWith()
    //     0xdfa494: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xdfa498: mov             x1, x0
    // 0xdfa49c: b               #0xdfa4dc
    // 0xdfa4a0: r1 = 1
    //     0xdfa4a0: mov             x1, #1
    // 0xdfa4a4: r0 = AllocateContext()
    //     0xdfa4a4: bl              #0x13de838  ; AllocateContextStub
    // 0xdfa4a8: mov             x1, x0
    // 0xdfa4ac: ldur            x0, [fp, #-0x10]
    // 0xdfa4b0: StoreField: r1->field_f = r0
    //     0xdfa4b0: stur            w0, [x1, #0xf]
    // 0xdfa4b4: mov             x2, x1
    // 0xdfa4b8: r1 = Function '<anonymous closure>':.
    //     0xdfa4b8: add             x1, PP, #0x26, lsl #12  ; [pp+0x262a0] AnonymousClosure: (0xdfae80), of [package:flutter/src/material/radio.dart] _RadioDefaultsM2
    //     0xdfa4bc: ldr             x1, [x1, #0x2a0]
    // 0xdfa4c0: r0 = AllocateClosure()
    //     0xdfa4c0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdfa4c4: r16 = <Color>
    //     0xdfa4c4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xdfa4c8: ldr             x16, [x16, #0xa90]
    // 0xdfa4cc: stp             x0, x16, [SP]
    // 0xdfa4d0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdfa4d0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdfa4d4: r0 = resolveWith()
    //     0xdfa4d4: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xdfa4d8: mov             x1, x0
    // 0xdfa4dc: ldur            x2, [fp, #-0x28]
    // 0xdfa4e0: r0 = build()
    //     0xdfa4e0: bl              #0xfbf624  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xdfa4e4: cmp             w0, NULL
    // 0xdfa4e8: b.eq            #0xdfaae0
    // 0xdfa4ec: mov             x3, x0
    // 0xdfa4f0: b               #0xdfa4f8
    // 0xdfa4f4: mov             x3, x0
    // 0xdfa4f8: ldur            x2, [fp, #-8]
    // 0xdfa4fc: stur            x3, [fp, #-0x40]
    // 0xdfa500: LoadField: r0 = r2->field_b
    //     0xdfa500: ldur            w0, [x2, #0xb]
    // 0xdfa504: DecompressPointer r0
    //     0xdfa504: add             x0, x0, HEAP, lsl #32
    // 0xdfa508: cmp             w0, NULL
    // 0xdfa50c: b.eq            #0xdfaae4
    // 0xdfa510: LoadField: r1 = r0->field_b
    //     0xdfa510: ldur            w1, [x0, #0xb]
    // 0xdfa514: DecompressPointer r1
    //     0xdfa514: add             x1, x1, HEAP, lsl #32
    // 0xdfa518: r0 = LoadClassIdInstr(r1)
    //     0xdfa518: ldur            x0, [x1, #-1]
    //     0xdfa51c: ubfx            x0, x0, #0xc, #0x14
    // 0xdfa520: r0 = GDT[cid_x0 + 0x4f2]()
    //     0xdfa520: add             lr, x0, #0x4f2
    //     0xdfa524: ldr             lr, [x21, lr, lsl #3]
    //     0xdfa528: blr             lr
    // 0xdfa52c: cmp             w0, NULL
    // 0xdfa530: b.eq            #0xdfa5e4
    // 0xdfa534: ldur            x2, [fp, #-8]
    // 0xdfa538: LoadField: r0 = r2->field_b
    //     0xdfa538: ldur            w0, [x2, #0xb]
    // 0xdfa53c: DecompressPointer r0
    //     0xdfa53c: add             x0, x0, HEAP, lsl #32
    // 0xdfa540: cmp             w0, NULL
    // 0xdfa544: b.eq            #0xdfaae8
    // 0xdfa548: LoadField: r1 = r0->field_b
    //     0xdfa548: ldur            w1, [x0, #0xb]
    // 0xdfa54c: DecompressPointer r1
    //     0xdfa54c: add             x1, x1, HEAP, lsl #32
    // 0xdfa550: r0 = LoadClassIdInstr(r1)
    //     0xdfa550: ldur            x0, [x1, #-1]
    //     0xdfa554: ubfx            x0, x0, #0xc, #0x14
    // 0xdfa558: r0 = GDT[cid_x0 + -0xc50]()
    //     0xdfa558: sub             lr, x0, #0xc50
    //     0xdfa55c: ldr             lr, [x21, lr, lsl #3]
    //     0xdfa560: blr             lr
    // 0xdfa564: mov             x1, x0
    // 0xdfa568: r2 = Instance_WidgetState
    //     0xdfa568: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xdfa56c: ldr             x2, [x2, #0x100]
    // 0xdfa570: r0 = contains()
    //     0xdfa570: bl              #0xbafbf4  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0xdfa574: tbnz            w0, #4, #0xdfa580
    // 0xdfa578: ldur            x3, [fp, #-0x30]
    // 0xdfa57c: b               #0xdfa584
    // 0xdfa580: ldur            x3, [fp, #-0x40]
    // 0xdfa584: ldur            x2, [fp, #-8]
    // 0xdfa588: stur            x3, [fp, #-0x78]
    // 0xdfa58c: LoadField: r0 = r2->field_b
    //     0xdfa58c: ldur            w0, [x2, #0xb]
    // 0xdfa590: DecompressPointer r0
    //     0xdfa590: add             x0, x0, HEAP, lsl #32
    // 0xdfa594: cmp             w0, NULL
    // 0xdfa598: b.eq            #0xdfaaec
    // 0xdfa59c: LoadField: r1 = r0->field_b
    //     0xdfa59c: ldur            w1, [x0, #0xb]
    // 0xdfa5a0: DecompressPointer r1
    //     0xdfa5a0: add             x1, x1, HEAP, lsl #32
    // 0xdfa5a4: r0 = LoadClassIdInstr(r1)
    //     0xdfa5a4: ldur            x0, [x1, #-1]
    //     0xdfa5a8: ubfx            x0, x0, #0xc, #0x14
    // 0xdfa5ac: r0 = GDT[cid_x0 + -0xc50]()
    //     0xdfa5ac: sub             lr, x0, #0xc50
    //     0xdfa5b0: ldr             lr, [x21, lr, lsl #3]
    //     0xdfa5b4: blr             lr
    // 0xdfa5b8: mov             x1, x0
    // 0xdfa5bc: r2 = Instance_WidgetState
    //     0xdfa5bc: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xdfa5c0: ldr             x2, [x2, #0x100]
    // 0xdfa5c4: r0 = contains()
    //     0xdfa5c4: bl              #0xbafbf4  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0xdfa5c8: tbnz            w0, #4, #0xdfa5d4
    // 0xdfa5cc: ldur            x0, [fp, #-0x30]
    // 0xdfa5d0: b               #0xdfa5d8
    // 0xdfa5d4: ldur            x0, [fp, #-0x40]
    // 0xdfa5d8: mov             x3, x0
    // 0xdfa5dc: ldur            x2, [fp, #-0x78]
    // 0xdfa5e0: b               #0xdfa5ec
    // 0xdfa5e4: ldur            x3, [fp, #-0x68]
    // 0xdfa5e8: ldur            x2, [fp, #-0x70]
    // 0xdfa5ec: ldur            x0, [fp, #-8]
    // 0xdfa5f0: ldur            x1, [fp, #-0x48]
    // 0xdfa5f4: stur            x3, [fp, #-0x68]
    // 0xdfa5f8: stur            x2, [fp, #-0x70]
    // 0xdfa5fc: LoadField: r4 = r0->field_b
    //     0xdfa5fc: ldur            w4, [x0, #0xb]
    // 0xdfa600: DecompressPointer r4
    //     0xdfa600: add             x4, x4, HEAP, lsl #32
    // 0xdfa604: cmp             w4, NULL
    // 0xdfa608: b.eq            #0xdfaaf0
    // 0xdfa60c: r17 = 5119
    //     0xdfa60c: mov             x17, #0x13ff
    // 0xdfa610: cmp             x1, x17
    // 0xdfa614: b.ne            #0xdfa628
    // 0xdfa618: ldur            x4, [fp, #-0x10]
    // 0xdfa61c: LoadField: r1 = r4->field_1b
    //     0xdfa61c: ldur            w1, [x4, #0x1b]
    // 0xdfa620: DecompressPointer r1
    //     0xdfa620: add             x1, x1, HEAP, lsl #32
    // 0xdfa624: b               #0xdfa69c
    // 0xdfa628: ldur            x4, [fp, #-0x10]
    // 0xdfa62c: r17 = 5120
    //     0xdfa62c: mov             x17, #0x1400
    // 0xdfa630: cmp             x1, x17
    // 0xdfa634: b.ne            #0xdfa66c
    // 0xdfa638: mov             x1, x4
    // 0xdfa63c: LoadField: r0 = r1->field_2f
    //     0xdfa63c: ldur            w0, [x1, #0x2f]
    // 0xdfa640: DecompressPointer r0
    //     0xdfa640: add             x0, x0, HEAP, lsl #32
    // 0xdfa644: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfa648: cmp             w0, w16
    // 0xdfa64c: b.ne            #0xdfa65c
    // 0xdfa650: r2 = _theme
    //     0xdfa650: add             x2, PP, #0x26, lsl #12  ; [pp+0x262a8] Field <_RadioDefaultsM3@625266229._theme@625266229>: late final (offset: 0x30)
    //     0xdfa654: ldr             x2, [x2, #0x2a8]
    // 0xdfa658: r0 = InitLateFinalInstanceField()
    //     0xdfa658: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdfa65c: LoadField: r1 = r0->field_33
    //     0xdfa65c: ldur            w1, [x0, #0x33]
    // 0xdfa660: DecompressPointer r1
    //     0xdfa660: add             x1, x1, HEAP, lsl #32
    // 0xdfa664: ldur            x0, [fp, #-8]
    // 0xdfa668: b               #0xdfa69c
    // 0xdfa66c: mov             x1, x4
    // 0xdfa670: LoadField: r0 = r1->field_2f
    //     0xdfa670: ldur            w0, [x1, #0x2f]
    // 0xdfa674: DecompressPointer r0
    //     0xdfa674: add             x0, x0, HEAP, lsl #32
    // 0xdfa678: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfa67c: cmp             w0, w16
    // 0xdfa680: b.ne            #0xdfa690
    // 0xdfa684: r2 = _theme
    //     0xdfa684: add             x2, PP, #0x26, lsl #12  ; [pp+0x262b0] Field <_RadioDefaultsM2@625266229._theme@625266229>: late final (offset: 0x30)
    //     0xdfa688: ldr             x2, [x2, #0x2b0]
    // 0xdfa68c: r0 = InitLateFinalInstanceField()
    //     0xdfa68c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xdfa690: LoadField: r1 = r0->field_33
    //     0xdfa690: ldur            w1, [x0, #0x33]
    // 0xdfa694: DecompressPointer r1
    //     0xdfa694: add             x1, x1, HEAP, lsl #32
    // 0xdfa698: ldur            x0, [fp, #-8]
    // 0xdfa69c: ldur            x4, [fp, #-0x18]
    // 0xdfa6a0: ldur            x3, [fp, #-0x38]
    // 0xdfa6a4: ldur            x2, [fp, #-0x50]
    // 0xdfa6a8: r0 = baseSizeAdjustment()
    //     0xdfa6a8: bl              #0xb2496c  ; [package:flutter/src/material/theme_data.dart] VisualDensity::baseSizeAdjustment
    // 0xdfa6ac: mov             x2, x0
    // 0xdfa6b0: r1 = Instance_Size
    //     0xdfa6b0: add             x1, PP, #0x90, lsl #12  ; [pp+0x90408] Obj!Size@12a75b1
    //     0xdfa6b4: ldr             x1, [x1, #0x408]
    // 0xdfa6b8: r0 = +()
    //     0xdfa6b8: bl              #0x81d158  ; [dart:ui] Size::+
    // 0xdfa6bc: mov             x3, x0
    // 0xdfa6c0: ldur            x0, [fp, #-8]
    // 0xdfa6c4: stur            x3, [fp, #-0x10]
    // 0xdfa6c8: LoadField: r1 = r0->field_b
    //     0xdfa6c8: ldur            w1, [x0, #0xb]
    // 0xdfa6cc: DecompressPointer r1
    //     0xdfa6cc: add             x1, x1, HEAP, lsl #32
    // 0xdfa6d0: cmp             w1, NULL
    // 0xdfa6d4: b.eq            #0xdfaaf4
    // 0xdfa6d8: mov             x1, x0
    // 0xdfa6dc: ldur            x2, [fp, #-0x20]
    // 0xdfa6e0: r0 = _resolveSide()
    //     0xdfa6e0: bl              #0xd76d84  ; [package:flutter/src/cupertino/checkbox.dart] _CupertinoCheckboxState::_resolveSide
    // 0xdfa6e4: ldur            x1, [fp, #-8]
    // 0xdfa6e8: ldur            x2, [fp, #-0x20]
    // 0xdfa6ec: r0 = _resolveSide()
    //     0xdfa6ec: bl              #0xd76d84  ; [package:flutter/src/cupertino/checkbox.dart] _CupertinoCheckboxState::_resolveSide
    // 0xdfa6f0: r0 = BorderSide()
    //     0xdfa6f0: bl              #0x8a73bc  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0xdfa6f4: mov             x3, x0
    // 0xdfa6f8: ldur            x0, [fp, #-0x38]
    // 0xdfa6fc: stur            x3, [fp, #-0x20]
    // 0xdfa700: StoreField: r3->field_7 = r0
    //     0xdfa700: stur            w0, [x3, #7]
    // 0xdfa704: d0 = 2.000000
    //     0xdfa704: fmov            d0, #2.00000000
    // 0xdfa708: StoreField: r3->field_b = d0
    //     0xdfa708: stur            d0, [x3, #0xb]
    // 0xdfa70c: r4 = Instance_BorderStyle
    //     0xdfa70c: add             x4, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0xdfa710: ldr             x4, [x4, #0xdc8]
    // 0xdfa714: StoreField: r3->field_13 = r4
    //     0xdfa714: stur            w4, [x3, #0x13]
    // 0xdfa718: ArrayStore: r3[0] = rZR  ; List_8
    //     0xdfa718: stur            xzr, [x3, #0x17]
    // 0xdfa71c: ldur            x5, [fp, #-8]
    // 0xdfa720: LoadField: r1 = r5->field_b
    //     0xdfa720: ldur            w1, [x5, #0xb]
    // 0xdfa724: DecompressPointer r1
    //     0xdfa724: add             x1, x1, HEAP, lsl #32
    // 0xdfa728: cmp             w1, NULL
    // 0xdfa72c: b.eq            #0xdfaaf8
    // 0xdfa730: mov             x1, x5
    // 0xdfa734: ldur            x2, [fp, #-0x28]
    // 0xdfa738: r0 = _resolveSide()
    //     0xdfa738: bl              #0xd76d84  ; [package:flutter/src/cupertino/checkbox.dart] _CupertinoCheckboxState::_resolveSide
    // 0xdfa73c: ldur            x1, [fp, #-8]
    // 0xdfa740: ldur            x2, [fp, #-0x28]
    // 0xdfa744: r0 = _resolveSide()
    //     0xdfa744: bl              #0xd76d84  ; [package:flutter/src/cupertino/checkbox.dart] _CupertinoCheckboxState::_resolveSide
    // 0xdfa748: r0 = BorderSide()
    //     0xdfa748: bl              #0x8a73bc  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0xdfa74c: mov             x3, x0
    // 0xdfa750: ldur            x2, [fp, #-0x50]
    // 0xdfa754: stur            x3, [fp, #-0x78]
    // 0xdfa758: StoreField: r3->field_7 = r2
    //     0xdfa758: stur            w2, [x3, #7]
    // 0xdfa75c: d0 = 2.000000
    //     0xdfa75c: fmov            d0, #2.00000000
    // 0xdfa760: StoreField: r3->field_b = d0
    //     0xdfa760: stur            d0, [x3, #0xb]
    // 0xdfa764: r0 = Instance_BorderStyle
    //     0xdfa764: add             x0, PP, #0x13, lsl #12  ; [pp+0x13dc8] Obj!BorderStyle@12c4961
    //     0xdfa768: ldr             x0, [x0, #0xdc8]
    // 0xdfa76c: StoreField: r3->field_13 = r0
    //     0xdfa76c: stur            w0, [x3, #0x13]
    // 0xdfa770: ArrayStore: r3[0] = rZR  ; List_8
    //     0xdfa770: stur            xzr, [x3, #0x17]
    // 0xdfa774: ldur            x4, [fp, #-8]
    // 0xdfa778: LoadField: r0 = r4->field_b
    //     0xdfa778: ldur            w0, [x4, #0xb]
    // 0xdfa77c: DecompressPointer r0
    //     0xdfa77c: add             x0, x0, HEAP, lsl #32
    // 0xdfa780: cmp             w0, NULL
    // 0xdfa784: b.eq            #0xdfaafc
    // 0xdfa788: LoadField: r5 = r4->field_13
    //     0xdfa788: ldur            w5, [x4, #0x13]
    // 0xdfa78c: DecompressPointer r5
    //     0xdfa78c: add             x5, x5, HEAP, lsl #32
    // 0xdfa790: stur            x5, [fp, #-0x28]
    // 0xdfa794: LoadField: r1 = r0->field_b
    //     0xdfa794: ldur            w1, [x0, #0xb]
    // 0xdfa798: DecompressPointer r1
    //     0xdfa798: add             x1, x1, HEAP, lsl #32
    // 0xdfa79c: r0 = LoadClassIdInstr(r1)
    //     0xdfa79c: ldur            x0, [x1, #-1]
    //     0xdfa7a0: ubfx            x0, x0, #0xc, #0x14
    // 0xdfa7a4: r0 = GDT[cid_x0 + 0xec4]()
    //     0xdfa7a4: add             lr, x0, #0xec4
    //     0xdfa7a8: ldr             lr, [x21, lr, lsl #3]
    //     0xdfa7ac: blr             lr
    // 0xdfa7b0: ldur            x1, [fp, #-0x28]
    // 0xdfa7b4: mov             x2, x0
    // 0xdfa7b8: r0 = position=()
    //     0xdfa7b8: bl              #0xd131b8  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::position=
    // 0xdfa7bc: ldur            x2, [fp, #-8]
    // 0xdfa7c0: LoadField: r0 = r2->field_b
    //     0xdfa7c0: ldur            w0, [x2, #0xb]
    // 0xdfa7c4: DecompressPointer r0
    //     0xdfa7c4: add             x0, x0, HEAP, lsl #32
    // 0xdfa7c8: cmp             w0, NULL
    // 0xdfa7cc: b.eq            #0xdfab00
    // 0xdfa7d0: LoadField: r1 = r0->field_b
    //     0xdfa7d0: ldur            w1, [x0, #0xb]
    // 0xdfa7d4: DecompressPointer r1
    //     0xdfa7d4: add             x1, x1, HEAP, lsl #32
    // 0xdfa7d8: r0 = LoadClassIdInstr(r1)
    //     0xdfa7d8: ldur            x0, [x1, #-1]
    //     0xdfa7dc: ubfx            x0, x0, #0xc, #0x14
    // 0xdfa7e0: r0 = GDT[cid_x0 + 0xd20]()
    //     0xdfa7e0: add             lr, x0, #0xd20
    //     0xdfa7e4: ldr             lr, [x21, lr, lsl #3]
    //     0xdfa7e8: blr             lr
    // 0xdfa7ec: ldur            x1, [fp, #-0x28]
    // 0xdfa7f0: mov             x2, x0
    // 0xdfa7f4: r0 = reaction=()
    //     0xdfa7f4: bl              #0xd130e8  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::reaction=
    // 0xdfa7f8: ldur            x2, [fp, #-8]
    // 0xdfa7fc: LoadField: r0 = r2->field_b
    //     0xdfa7fc: ldur            w0, [x2, #0xb]
    // 0xdfa800: DecompressPointer r0
    //     0xdfa800: add             x0, x0, HEAP, lsl #32
    // 0xdfa804: cmp             w0, NULL
    // 0xdfa808: b.eq            #0xdfab04
    // 0xdfa80c: LoadField: r1 = r0->field_b
    //     0xdfa80c: ldur            w1, [x0, #0xb]
    // 0xdfa810: DecompressPointer r1
    //     0xdfa810: add             x1, x1, HEAP, lsl #32
    // 0xdfa814: r0 = LoadClassIdInstr(r1)
    //     0xdfa814: ldur            x0, [x1, #-1]
    //     0xdfa818: ubfx            x0, x0, #0xc, #0x14
    // 0xdfa81c: r0 = GDT[cid_x0 + 0x1e5c]()
    //     0xdfa81c: mov             x17, #0x1e5c
    //     0xdfa820: add             lr, x0, x17
    //     0xdfa824: ldr             lr, [x21, lr, lsl #3]
    //     0xdfa828: blr             lr
    // 0xdfa82c: ldur            x1, [fp, #-0x28]
    // 0xdfa830: mov             x2, x0
    // 0xdfa834: r0 = reactionFocusFade=()
    //     0xdfa834: bl              #0xd13018  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::reactionFocusFade=
    // 0xdfa838: ldur            x2, [fp, #-8]
    // 0xdfa83c: LoadField: r0 = r2->field_b
    //     0xdfa83c: ldur            w0, [x2, #0xb]
    // 0xdfa840: DecompressPointer r0
    //     0xdfa840: add             x0, x0, HEAP, lsl #32
    // 0xdfa844: cmp             w0, NULL
    // 0xdfa848: b.eq            #0xdfab08
    // 0xdfa84c: LoadField: r1 = r0->field_b
    //     0xdfa84c: ldur            w1, [x0, #0xb]
    // 0xdfa850: DecompressPointer r1
    //     0xdfa850: add             x1, x1, HEAP, lsl #32
    // 0xdfa854: r0 = LoadClassIdInstr(r1)
    //     0xdfa854: ldur            x0, [x1, #-1]
    //     0xdfa858: ubfx            x0, x0, #0xc, #0x14
    // 0xdfa85c: r0 = GDT[cid_x0 + 0x1dbb]()
    //     0xdfa85c: mov             x17, #0x1dbb
    //     0xdfa860: add             lr, x0, x17
    //     0xdfa864: ldr             lr, [x21, lr, lsl #3]
    //     0xdfa868: blr             lr
    // 0xdfa86c: ldur            x1, [fp, #-0x28]
    // 0xdfa870: mov             x2, x0
    // 0xdfa874: r0 = reactionHoverFade=()
    //     0xdfa874: bl              #0xd12f48  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::reactionHoverFade=
    // 0xdfa878: ldur            x1, [fp, #-0x28]
    // 0xdfa87c: ldur            x2, [fp, #-0x40]
    // 0xdfa880: r0 = inactiveReactionColor=()
    //     0xdfa880: bl              #0xd12ea4  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::inactiveReactionColor=
    // 0xdfa884: ldur            x1, [fp, #-0x28]
    // 0xdfa888: ldur            x2, [fp, #-0x30]
    // 0xdfa88c: r0 = reactionColor=()
    //     0xdfa88c: bl              #0xd12e00  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::reactionColor=
    // 0xdfa890: ldur            x1, [fp, #-0x28]
    // 0xdfa894: ldur            x2, [fp, #-0x70]
    // 0xdfa898: r0 = hoverColor=()
    //     0xdfa898: bl              #0xd12d5c  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::hoverColor=
    // 0xdfa89c: ldur            x1, [fp, #-0x28]
    // 0xdfa8a0: ldur            x2, [fp, #-0x68]
    // 0xdfa8a4: r0 = focusColor=()
    //     0xdfa8a4: bl              #0xd12cb8  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::focusColor=
    // 0xdfa8a8: ldur            x0, [fp, #-8]
    // 0xdfa8ac: LoadField: r1 = r0->field_b
    //     0xdfa8ac: ldur            w1, [x0, #0xb]
    // 0xdfa8b0: DecompressPointer r1
    //     0xdfa8b0: add             x1, x1, HEAP, lsl #32
    // 0xdfa8b4: cmp             w1, NULL
    // 0xdfa8b8: b.eq            #0xdfab0c
    // 0xdfa8bc: ldur            x1, [fp, #-0x18]
    // 0xdfa8c0: LoadField: r2 = r1->field_13
    //     0xdfa8c0: ldur            w2, [x1, #0x13]
    // 0xdfa8c4: DecompressPointer r2
    //     0xdfa8c4: add             x2, x2, HEAP, lsl #32
    // 0xdfa8c8: cmp             w2, NULL
    // 0xdfa8cc: b.ne            #0xdfa8d8
    // 0xdfa8d0: d0 = 20.000000
    //     0xdfa8d0: fmov            d0, #20.00000000
    // 0xdfa8d4: b               #0xdfa8dc
    // 0xdfa8d8: LoadField: d0 = r2->field_7
    //     0xdfa8d8: ldur            d0, [x2, #7]
    // 0xdfa8dc: ldur            x2, [fp, #-0x28]
    // 0xdfa8e0: mov             x1, x2
    // 0xdfa8e4: r0 = splashRadius=()
    //     0xdfa8e4: bl              #0xd12bec  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::splashRadius=
    // 0xdfa8e8: ldur            x2, [fp, #-8]
    // 0xdfa8ec: LoadField: r0 = r2->field_b
    //     0xdfa8ec: ldur            w0, [x2, #0xb]
    // 0xdfa8f0: DecompressPointer r0
    //     0xdfa8f0: add             x0, x0, HEAP, lsl #32
    // 0xdfa8f4: cmp             w0, NULL
    // 0xdfa8f8: b.eq            #0xdfab10
    // 0xdfa8fc: LoadField: r1 = r0->field_b
    //     0xdfa8fc: ldur            w1, [x0, #0xb]
    // 0xdfa900: DecompressPointer r1
    //     0xdfa900: add             x1, x1, HEAP, lsl #32
    // 0xdfa904: r0 = LoadClassIdInstr(r1)
    //     0xdfa904: ldur            x0, [x1, #-1]
    //     0xdfa908: ubfx            x0, x0, #0xc, #0x14
    // 0xdfa90c: r0 = GDT[cid_x0 + 0x4f2]()
    //     0xdfa90c: add             lr, x0, #0x4f2
    //     0xdfa910: ldr             lr, [x21, lr, lsl #3]
    //     0xdfa914: blr             lr
    // 0xdfa918: ldur            x1, [fp, #-0x28]
    // 0xdfa91c: mov             x2, x0
    // 0xdfa920: r0 = downPosition=()
    //     0xdfa920: bl              #0xd12b48  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::downPosition=
    // 0xdfa924: ldur            x2, [fp, #-8]
    // 0xdfa928: LoadField: r0 = r2->field_b
    //     0xdfa928: ldur            w0, [x2, #0xb]
    // 0xdfa92c: DecompressPointer r0
    //     0xdfa92c: add             x0, x0, HEAP, lsl #32
    // 0xdfa930: cmp             w0, NULL
    // 0xdfa934: b.eq            #0xdfab14
    // 0xdfa938: LoadField: r1 = r0->field_b
    //     0xdfa938: ldur            w1, [x0, #0xb]
    // 0xdfa93c: DecompressPointer r1
    //     0xdfa93c: add             x1, x1, HEAP, lsl #32
    // 0xdfa940: r0 = LoadClassIdInstr(r1)
    //     0xdfa940: ldur            x0, [x1, #-1]
    //     0xdfa944: ubfx            x0, x0, #0xc, #0x14
    // 0xdfa948: r0 = GDT[cid_x0 + -0xc50]()
    //     0xdfa948: sub             lr, x0, #0xc50
    //     0xdfa94c: ldr             lr, [x21, lr, lsl #3]
    //     0xdfa950: blr             lr
    // 0xdfa954: mov             x1, x0
    // 0xdfa958: r2 = Instance_WidgetState
    //     0xdfa958: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xdfa95c: ldr             x2, [x2, #0xa60]
    // 0xdfa960: r0 = contains()
    //     0xdfa960: bl              #0xbafbf4  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0xdfa964: mov             x1, x0
    // 0xdfa968: ldur            x0, [fp, #-0x28]
    // 0xdfa96c: LoadField: r2 = r0->field_53
    //     0xdfa96c: ldur            w2, [x0, #0x53]
    // 0xdfa970: DecompressPointer r2
    //     0xdfa970: add             x2, x2, HEAP, lsl #32
    // 0xdfa974: cmp             w1, w2
    // 0xdfa978: b.ne            #0xdfa984
    // 0xdfa97c: mov             x2, x0
    // 0xdfa980: b               #0xdfa994
    // 0xdfa984: StoreField: r0->field_53 = r1
    //     0xdfa984: stur            w1, [x0, #0x53]
    // 0xdfa988: mov             x1, x0
    // 0xdfa98c: r0 = notifyListeners()
    //     0xdfa98c: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xdfa990: ldur            x2, [fp, #-0x28]
    // 0xdfa994: ldur            x0, [fp, #-8]
    // 0xdfa998: LoadField: r1 = r0->field_b
    //     0xdfa998: ldur            w1, [x0, #0xb]
    // 0xdfa99c: DecompressPointer r1
    //     0xdfa99c: add             x1, x1, HEAP, lsl #32
    // 0xdfa9a0: cmp             w1, NULL
    // 0xdfa9a4: b.eq            #0xdfab18
    // 0xdfa9a8: LoadField: r0 = r1->field_b
    //     0xdfa9a8: ldur            w0, [x1, #0xb]
    // 0xdfa9ac: DecompressPointer r0
    //     0xdfa9ac: add             x0, x0, HEAP, lsl #32
    // 0xdfa9b0: r1 = LoadClassIdInstr(r0)
    //     0xdfa9b0: ldur            x1, [x0, #-1]
    //     0xdfa9b4: ubfx            x1, x1, #0xc, #0x14
    // 0xdfa9b8: mov             x16, x0
    // 0xdfa9bc: mov             x0, x1
    // 0xdfa9c0: mov             x1, x16
    // 0xdfa9c4: r0 = GDT[cid_x0 + -0xc50]()
    //     0xdfa9c4: sub             lr, x0, #0xc50
    //     0xdfa9c8: ldr             lr, [x21, lr, lsl #3]
    //     0xdfa9cc: blr             lr
    // 0xdfa9d0: mov             x1, x0
    // 0xdfa9d4: r2 = Instance_WidgetState
    //     0xdfa9d4: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xdfa9d8: ldr             x2, [x2, #0xa50]
    // 0xdfa9dc: r0 = contains()
    //     0xdfa9dc: bl              #0xbafbf4  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0xdfa9e0: mov             x1, x0
    // 0xdfa9e4: ldur            x0, [fp, #-0x28]
    // 0xdfa9e8: LoadField: r2 = r0->field_57
    //     0xdfa9e8: ldur            w2, [x0, #0x57]
    // 0xdfa9ec: DecompressPointer r2
    //     0xdfa9ec: add             x2, x2, HEAP, lsl #32
    // 0xdfa9f0: cmp             w1, w2
    // 0xdfa9f4: b.eq            #0xdfaa08
    // 0xdfa9f8: StoreField: r0->field_57 = r1
    //     0xdfa9f8: stur            w1, [x0, #0x57]
    // 0xdfa9fc: mov             x1, x0
    // 0xdfaa00: r0 = notifyListeners()
    //     0xdfaa00: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xdfaa04: ldur            x0, [fp, #-0x28]
    // 0xdfaa08: ldur            x3, [fp, #-0x10]
    // 0xdfaa0c: mov             x1, x0
    // 0xdfaa10: ldur            x2, [fp, #-0x38]
    // 0xdfaa14: r0 = activeColor=()
    //     0xdfaa14: bl              #0xd129fc  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::activeColor=
    // 0xdfaa18: ldur            x1, [fp, #-0x28]
    // 0xdfaa1c: ldur            x2, [fp, #-0x50]
    // 0xdfaa20: r0 = inactiveColor=()
    //     0xdfaa20: bl              #0xcf0d78  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::inactiveColor=
    // 0xdfaa24: ldur            x1, [fp, #-0x28]
    // 0xdfaa28: ldur            x2, [fp, #-0x58]
    // 0xdfaa2c: r0 = activeBackgroundColor=()
    //     0xdfaa2c: bl              #0xdfac48  ; [package:flutter/src/material/radio.dart] _RadioPainter::activeBackgroundColor=
    // 0xdfaa30: ldur            x1, [fp, #-0x28]
    // 0xdfaa34: ldur            x2, [fp, #-0x60]
    // 0xdfaa38: r0 = checkColor=()
    //     0xdfaa38: bl              #0xd12958  ; [package:flutter/src/material/checkbox.dart] _CheckboxPainter::checkColor=
    // 0xdfaa3c: ldur            x1, [fp, #-0x28]
    // 0xdfaa40: ldur            x2, [fp, #-0x20]
    // 0xdfaa44: r0 = shape=()
    //     0xdfaa44: bl              #0xd12860  ; [package:flutter/src/material/checkbox.dart] _CheckboxPainter::shape=
    // 0xdfaa48: ldur            x1, [fp, #-0x28]
    // 0xdfaa4c: ldur            x2, [fp, #-0x78]
    // 0xdfaa50: r0 = inactiveSide=()
    //     0xdfaa50: bl              #0xdfaba4  ; [package:flutter/src/material/radio.dart] _RadioPainter::inactiveSide=
    // 0xdfaa54: ldur            x1, [fp, #-0x28]
    // 0xdfaa58: d0 = 4.500000
    //     0xdfaa58: fmov            d0, #4.50000000
    // 0xdfaa5c: r0 = innerRadius=()
    //     0xdfaa5c: bl              #0xdfab1c  ; [package:flutter/src/material/radio.dart] _RadioPainter::innerRadius=
    // 0xdfaa60: r0 = CustomPaint()
    //     0xdfaa60: bl              #0xd0a594  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0xdfaa64: ldur            x1, [fp, #-0x28]
    // 0xdfaa68: StoreField: r0->field_f = r1
    //     0xdfaa68: stur            w1, [x0, #0xf]
    // 0xdfaa6c: ldur            x1, [fp, #-0x10]
    // 0xdfaa70: ArrayStore: r0[0] = r1  ; List_4
    //     0xdfaa70: stur            w1, [x0, #0x17]
    // 0xdfaa74: r1 = false
    //     0xdfaa74: add             x1, NULL, #0x30  ; false
    // 0xdfaa78: StoreField: r0->field_1b = r1
    //     0xdfaa78: stur            w1, [x0, #0x1b]
    // 0xdfaa7c: StoreField: r0->field_1f = r1
    //     0xdfaa7c: stur            w1, [x0, #0x1f]
    // 0xdfaa80: LeaveFrame
    //     0xdfaa80: mov             SP, fp
    //     0xdfaa84: ldp             fp, lr, [SP], #0x10
    // 0xdfaa88: ret
    //     0xdfaa88: ret             
    // 0xdfaa8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdfaa8c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdfaa90: b               #0xdf9b80
    // 0xdfaa94: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfaa94: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfaa98: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfaa98: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfaa9c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfaa9c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfaaa0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfaaa0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfaaa4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfaaa4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfaaa8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfaaa8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfaaac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfaaac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfaab0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfaab0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfaab4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfaab4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfaab8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfaab8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfaabc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfaabc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfaac0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfaac0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfaac4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfaac4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfaac8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfaac8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfaacc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfaacc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfaad0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfaad0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfaad4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfaad4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfaad8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfaad8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfaadc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfaadc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfaae0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfaae0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfaae4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfaae4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfaae8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfaae8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfaaec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfaaec: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfaaf0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfaaf0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfaaf4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfaaf4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfaaf8: r0 = NullCastErrorSharedWithFPURegs()
    //     0xdfaaf8: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xdfaafc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfaafc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfab00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfab00: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfab04: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfab04: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfab08: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfab08: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfab0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfab0c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfab10: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfab10: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfab14: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfab14: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfab18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfab18: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _widgetFillColor(/* No info */) {
    // ** addr: 0xdfacec, size: 0x68
    // 0xdfacec: EnterFrame
    //     0xdfacec: stp             fp, lr, [SP, #-0x10]!
    //     0xdfacf0: mov             fp, SP
    // 0xdfacf4: AllocStack(0x18)
    //     0xdfacf4: sub             SP, SP, #0x18
    // 0xdfacf8: SetupParameters(_RadioPaintState this /* r1 => r1, fp-0x8 */)
    //     0xdfacf8: stur            x1, [fp, #-8]
    // 0xdfacfc: CheckStackOverflow
    //     0xdfacfc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdfad00: cmp             SP, x16
    //     0xdfad04: b.ls            #0xdfad4c
    // 0xdfad08: r1 = 1
    //     0xdfad08: mov             x1, #1
    // 0xdfad0c: r0 = AllocateContext()
    //     0xdfad0c: bl              #0x13de838  ; AllocateContextStub
    // 0xdfad10: mov             x1, x0
    // 0xdfad14: ldur            x0, [fp, #-8]
    // 0xdfad18: StoreField: r1->field_f = r0
    //     0xdfad18: stur            w0, [x1, #0xf]
    // 0xdfad1c: mov             x2, x1
    // 0xdfad20: r1 = Function '<anonymous closure>':.
    //     0xdfad20: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4fe8] AnonymousClosure: (0xdfad6c), in [package:flutter/src/material/radio.dart] _RadioPaintState::_widgetFillColor (0xdfacec)
    //     0xdfad24: ldr             x1, [x1, #0xfe8]
    // 0xdfad28: r0 = AllocateClosure()
    //     0xdfad28: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdfad2c: r16 = <Color?>
    //     0xdfad2c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xdfad30: ldr             x16, [x16, #0xa40]
    // 0xdfad34: stp             x0, x16, [SP]
    // 0xdfad38: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdfad38: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdfad3c: r0 = resolveWith()
    //     0xdfad3c: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xdfad40: LeaveFrame
    //     0xdfad40: mov             SP, fp
    //     0xdfad44: ldp             fp, lr, [SP], #0x10
    // 0xdfad48: ret
    //     0xdfad48: ret             
    // 0xdfad4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdfad4c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdfad50: b               #0xdfad08
  }
  [closure] Color? <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xdfad6c, size: 0xdc
    // 0xdfad6c: EnterFrame
    //     0xdfad6c: stp             fp, lr, [SP, #-0x10]!
    //     0xdfad70: mov             fp, SP
    // 0xdfad74: AllocStack(0x8)
    //     0xdfad74: sub             SP, SP, #8
    // 0xdfad78: SetupParameters([dynamic _ /* r0 */])
    //     0xdfad78: ldr             x0, [fp, #0x18]
    //     0xdfad7c: ldur            w3, [x0, #0x17]
    //     0xdfad80: add             x3, x3, HEAP, lsl #32
    //     0xdfad84: stur            x3, [fp, #-8]
    // 0xdfad88: CheckStackOverflow
    //     0xdfad88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdfad8c: cmp             SP, x16
    //     0xdfad90: b.ls            #0xdfae3c
    // 0xdfad94: ldr             x4, [fp, #0x10]
    // 0xdfad98: r0 = LoadClassIdInstr(r4)
    //     0xdfad98: ldur            x0, [x4, #-1]
    //     0xdfad9c: ubfx            x0, x0, #0xc, #0x14
    // 0xdfada0: mov             x1, x4
    // 0xdfada4: r2 = Instance_WidgetState
    //     0xdfada4: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xdfada8: ldr             x2, [x2, #0xa70]
    // 0xdfadac: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdfadac: mov             x17, #0x2929
    //     0xdfadb0: movk            x17, #1, lsl #16
    //     0xdfadb4: add             lr, x0, x17
    //     0xdfadb8: ldr             lr, [x21, lr, lsl #3]
    //     0xdfadbc: blr             lr
    // 0xdfadc0: tbnz            w0, #4, #0xdfadd4
    // 0xdfadc4: r0 = Null
    //     0xdfadc4: mov             x0, NULL
    // 0xdfadc8: LeaveFrame
    //     0xdfadc8: mov             SP, fp
    //     0xdfadcc: ldp             fp, lr, [SP], #0x10
    // 0xdfadd0: ret
    //     0xdfadd0: ret             
    // 0xdfadd4: ldr             x1, [fp, #0x10]
    // 0xdfadd8: r0 = LoadClassIdInstr(r1)
    //     0xdfadd8: ldur            x0, [x1, #-1]
    //     0xdfaddc: ubfx            x0, x0, #0xc, #0x14
    // 0xdfade0: r2 = Instance_WidgetState
    //     0xdfade0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26100] Obj!WidgetState@12c8701
    //     0xdfade4: ldr             x2, [x2, #0x100]
    // 0xdfade8: r0 = GDT[cid_x0 + 0x12929]()
    //     0xdfade8: mov             x17, #0x2929
    //     0xdfadec: movk            x17, #1, lsl #16
    //     0xdfadf0: add             lr, x0, x17
    //     0xdfadf4: ldr             lr, [x21, lr, lsl #3]
    //     0xdfadf8: blr             lr
    // 0xdfadfc: tbnz            w0, #4, #0xdfae2c
    // 0xdfae00: ldur            x1, [fp, #-8]
    // 0xdfae04: LoadField: r2 = r1->field_f
    //     0xdfae04: ldur            w2, [x1, #0xf]
    // 0xdfae08: DecompressPointer r2
    //     0xdfae08: add             x2, x2, HEAP, lsl #32
    // 0xdfae0c: LoadField: r1 = r2->field_b
    //     0xdfae0c: ldur            w1, [x2, #0xb]
    // 0xdfae10: DecompressPointer r1
    //     0xdfae10: add             x1, x1, HEAP, lsl #32
    // 0xdfae14: cmp             w1, NULL
    // 0xdfae18: b.eq            #0xdfae44
    // 0xdfae1c: r0 = Null
    //     0xdfae1c: mov             x0, NULL
    // 0xdfae20: LeaveFrame
    //     0xdfae20: mov             SP, fp
    //     0xdfae24: ldp             fp, lr, [SP], #0x10
    // 0xdfae28: ret
    //     0xdfae28: ret             
    // 0xdfae2c: r0 = Null
    //     0xdfae2c: mov             x0, NULL
    // 0xdfae30: LeaveFrame
    //     0xdfae30: mov             SP, fp
    //     0xdfae34: ldp             fp, lr, [SP], #0x10
    // 0xdfae38: ret
    //     0xdfae38: ret             
    // 0xdfae3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdfae3c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdfae40: b               #0xdfad94
    // 0xdfae44: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfae44: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10e5ecc, size: 0x3c
    // 0x10e5ecc: EnterFrame
    //     0x10e5ecc: stp             fp, lr, [SP, #-0x10]!
    //     0x10e5ed0: mov             fp, SP
    // 0x10e5ed4: CheckStackOverflow
    //     0x10e5ed4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e5ed8: cmp             SP, x16
    //     0x10e5edc: b.ls            #0x10e5f00
    // 0x10e5ee0: LoadField: r0 = r1->field_13
    //     0x10e5ee0: ldur            w0, [x1, #0x13]
    // 0x10e5ee4: DecompressPointer r0
    //     0x10e5ee4: add             x0, x0, HEAP, lsl #32
    // 0x10e5ee8: mov             x1, x0
    // 0x10e5eec: r0 = dispose()
    //     0x10e5eec: bl              #0x10eef48  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::dispose
    // 0x10e5ef0: r0 = Null
    //     0x10e5ef0: mov             x0, NULL
    // 0x10e5ef4: LeaveFrame
    //     0x10e5ef4: mov             SP, fp
    //     0x10e5ef8: ldp             fp, lr, [SP], #0x10
    // 0x10e5efc: ret
    //     0x10e5efc: ret             
    // 0x10e5f00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e5f00: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e5f04: b               #0x10e5ee0
  }
}

// class id: 5459, size: 0x18, field offset: 0x14
class _RadioState<C1X0> extends State<C1X0> {

  _ build(/* No info */) {
    // ** addr: 0xdf9628, size: 0x330
    // 0xdf9628: EnterFrame
    //     0xdf9628: stp             fp, lr, [SP, #-0x10]!
    //     0xdf962c: mov             fp, SP
    // 0xdf9630: AllocStack(0x50)
    //     0xdf9630: sub             SP, SP, #0x50
    // 0xdf9634: SetupParameters(_RadioState<C1X0> this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xdf9634: mov             x0, x1
    //     0xdf9638: stur            x1, [fp, #-8]
    //     0xdf963c: mov             x1, x2
    //     0xdf9640: stur            x2, [fp, #-0x10]
    // 0xdf9644: CheckStackOverflow
    //     0xdf9644: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf9648: cmp             SP, x16
    //     0xdf964c: b.ls            #0xdf993c
    // 0xdf9650: r1 = 2
    //     0xdf9650: mov             x1, #2
    // 0xdf9654: r0 = AllocateContext()
    //     0xdf9654: bl              #0x13de838  ; AllocateContextStub
    // 0xdf9658: mov             x2, x0
    // 0xdf965c: ldur            x0, [fp, #-8]
    // 0xdf9660: stur            x2, [fp, #-0x18]
    // 0xdf9664: StoreField: r2->field_f = r0
    //     0xdf9664: stur            w0, [x2, #0xf]
    // 0xdf9668: LoadField: r1 = r0->field_b
    //     0xdf9668: ldur            w1, [x0, #0xb]
    // 0xdf966c: DecompressPointer r1
    //     0xdf966c: add             x1, x1, HEAP, lsl #32
    // 0xdf9670: cmp             w1, NULL
    // 0xdf9674: b.eq            #0xdf9944
    // 0xdf9678: LoadField: r3 = r1->field_53
    //     0xdf9678: ldur            w3, [x1, #0x53]
    // 0xdf967c: DecompressPointer r3
    //     0xdf967c: add             x3, x3, HEAP, lsl #32
    // 0xdf9680: LoadField: r1 = r3->field_7
    //     0xdf9680: ldur            x1, [x3, #7]
    // 0xdf9684: cmp             x1, #0
    // 0xdf9688: b.gt            #0xdf9698
    // 0xdf968c: mov             x3, x2
    // 0xdf9690: r2 = false
    //     0xdf9690: add             x2, NULL, #0x30  ; false
    // 0xdf9694: b               #0xdf97f0
    // 0xdf9698: ldur            x1, [fp, #-0x10]
    // 0xdf969c: r0 = of()
    //     0xdf969c: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xdf96a0: LoadField: r1 = r0->field_23
    //     0xdf96a0: ldur            w1, [x0, #0x23]
    // 0xdf96a4: DecompressPointer r1
    //     0xdf96a4: add             x1, x1, HEAP, lsl #32
    // 0xdf96a8: LoadField: r0 = r1->field_7
    //     0xdf96a8: ldur            x0, [x1, #7]
    // 0xdf96ac: cmp             x0, #2
    // 0xdf96b0: b.gt            #0xdf96c8
    // 0xdf96b4: cmp             x0, #1
    // 0xdf96b8: b.gt            #0xdf96e4
    // 0xdf96bc: ldur            x0, [fp, #-8]
    // 0xdf96c0: r2 = false
    //     0xdf96c0: add             x2, NULL, #0x30  ; false
    // 0xdf96c4: b               #0xdf97ec
    // 0xdf96c8: cmp             x0, #4
    // 0xdf96cc: b.gt            #0xdf97e4
    // 0xdf96d0: cmp             x0, #3
    // 0xdf96d4: b.gt            #0xdf96e4
    // 0xdf96d8: ldur            x0, [fp, #-8]
    // 0xdf96dc: r2 = false
    //     0xdf96dc: add             x2, NULL, #0x30  ; false
    // 0xdf96e0: b               #0xdf97ec
    // 0xdf96e4: ldur            x3, [fp, #-8]
    // 0xdf96e8: LoadField: r0 = r3->field_b
    //     0xdf96e8: ldur            w0, [x3, #0xb]
    // 0xdf96ec: DecompressPointer r0
    //     0xdf96ec: add             x0, x0, HEAP, lsl #32
    // 0xdf96f0: cmp             w0, NULL
    // 0xdf96f4: b.eq            #0xdf9948
    // 0xdf96f8: LoadField: r4 = r0->field_f
    //     0xdf96f8: ldur            w4, [x0, #0xf]
    // 0xdf96fc: DecompressPointer r4
    //     0xdf96fc: add             x4, x4, HEAP, lsl #32
    // 0xdf9700: stur            x4, [fp, #-0x28]
    // 0xdf9704: LoadField: r5 = r3->field_7
    //     0xdf9704: ldur            w5, [x3, #7]
    // 0xdf9708: DecompressPointer r5
    //     0xdf9708: add             x5, x5, HEAP, lsl #32
    // 0xdf970c: mov             x2, x5
    // 0xdf9710: stur            x5, [fp, #-0x20]
    // 0xdf9714: r0 = Null
    //     0xdf9714: mov             x0, NULL
    // 0xdf9718: r1 = Null
    //     0xdf9718: mov             x1, NULL
    // 0xdf971c: r8 = ((dynamic this, C1X0?) => void?)?
    //     0xdf971c: add             x8, PP, #0x28, lsl #12  ; [pp+0x28308] FunctionType: ((dynamic this, C1X0?) => void?)?
    //     0xdf9720: ldr             x8, [x8, #0x308]
    // 0xdf9724: LoadField: r9 = r8->field_7
    //     0xdf9724: ldur            x9, [x8, #7]
    // 0xdf9728: r3 = Null
    //     0xdf9728: add             x3, PP, #0xd4, lsl #12  ; [pp+0xd4e00] Null
    //     0xdf972c: ldr             x3, [x3, #0xe00]
    // 0xdf9730: blr             x9
    // 0xdf9734: ldur            x1, [fp, #-8]
    // 0xdf9738: r0 = _focusNode()
    //     0xdf9738: bl              #0xdf99b4  ; [package:flutter/src/material/radio.dart] _RadioState::_focusNode
    // 0xdf973c: mov             x4, x0
    // 0xdf9740: ldur            x0, [fp, #-8]
    // 0xdf9744: stur            x4, [fp, #-0x40]
    // 0xdf9748: LoadField: r1 = r0->field_b
    //     0xdf9748: ldur            w1, [x0, #0xb]
    // 0xdf974c: DecompressPointer r1
    //     0xdf974c: add             x1, x1, HEAP, lsl #32
    // 0xdf9750: cmp             w1, NULL
    // 0xdf9754: b.eq            #0xdf994c
    // 0xdf9758: LoadField: r0 = r1->field_4f
    //     0xdf9758: ldur            w0, [x1, #0x4f]
    // 0xdf975c: DecompressPointer r0
    //     0xdf975c: add             x0, x0, HEAP, lsl #32
    // 0xdf9760: stur            x0, [fp, #-0x38]
    // 0xdf9764: LoadField: r5 = r1->field_57
    //     0xdf9764: ldur            w5, [x1, #0x57]
    // 0xdf9768: DecompressPointer r5
    //     0xdf9768: add             x5, x5, HEAP, lsl #32
    // 0xdf976c: ldur            x2, [fp, #-0x20]
    // 0xdf9770: stur            x5, [fp, #-0x30]
    // 0xdf9774: r1 = Null
    //     0xdf9774: mov             x1, NULL
    // 0xdf9778: r3 = <C1X0>
    //     0xdf9778: add             x3, PP, #0x11, lsl #12  ; [pp+0x11880] TypeArguments: <C1X0>
    //     0xdf977c: ldr             x3, [x3, #0x880]
    // 0xdf9780: r0 = Null
    //     0xdf9780: mov             x0, NULL
    // 0xdf9784: cmp             x2, x0
    // 0xdf9788: b.eq            #0xdf9798
    // 0xdf978c: r30 = InstantiateTypeArgumentsStub
    //     0xdf978c: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0xdf9790: LoadField: r30 = r30->field_7
    //     0xdf9790: ldur            lr, [lr, #7]
    // 0xdf9794: blr             lr
    // 0xdf9798: mov             x1, x0
    // 0xdf979c: r0 = CupertinoRadio()
    //     0xdf979c: bl              #0xdf99a8  ; AllocateCupertinoRadioStub -> CupertinoRadio<X0> (size=0x40)
    // 0xdf97a0: mov             x1, x0
    // 0xdf97a4: ldur            x0, [fp, #-0x28]
    // 0xdf97a8: StoreField: r1->field_f = r0
    //     0xdf97a8: stur            w0, [x1, #0xf]
    // 0xdf97ac: r2 = false
    //     0xdf97ac: add             x2, NULL, #0x30  ; false
    // 0xdf97b0: ArrayStore: r1[0] = r2  ; List_4
    //     0xdf97b0: stur            w2, [x1, #0x17]
    // 0xdf97b4: ldur            x0, [fp, #-0x40]
    // 0xdf97b8: StoreField: r1->field_2f = r0
    //     0xdf97b8: stur            w0, [x1, #0x2f]
    // 0xdf97bc: StoreField: r1->field_33 = r2
    //     0xdf97bc: stur            w2, [x1, #0x33]
    // 0xdf97c0: StoreField: r1->field_1b = r2
    //     0xdf97c0: stur            w2, [x1, #0x1b]
    // 0xdf97c4: ldur            x0, [fp, #-0x30]
    // 0xdf97c8: StoreField: r1->field_3b = r0
    //     0xdf97c8: stur            w0, [x1, #0x3b]
    // 0xdf97cc: ldur            x0, [fp, #-0x38]
    // 0xdf97d0: StoreField: r1->field_37 = r0
    //     0xdf97d0: stur            w0, [x1, #0x37]
    // 0xdf97d4: mov             x0, x1
    // 0xdf97d8: LeaveFrame
    //     0xdf97d8: mov             SP, fp
    //     0xdf97dc: ldp             fp, lr, [SP], #0x10
    // 0xdf97e0: ret
    //     0xdf97e0: ret             
    // 0xdf97e4: ldur            x0, [fp, #-8]
    // 0xdf97e8: r2 = false
    //     0xdf97e8: add             x2, NULL, #0x30  ; false
    // 0xdf97ec: ldur            x3, [fp, #-0x18]
    // 0xdf97f0: ldur            x1, [fp, #-0x10]
    // 0xdf97f4: r0 = of()
    //     0xdf97f4: bl              #0xd32f98  ; [package:flutter/src/material/radio_theme.dart] RadioTheme::of
    // 0xdf97f8: ldur            x3, [fp, #-0x18]
    // 0xdf97fc: StoreField: r3->field_13 = r0
    //     0xdf97fc: stur            w0, [x3, #0x13]
    //     0xdf9800: ldurb           w16, [x3, #-1]
    //     0xdf9804: ldurb           w17, [x0, #-1]
    //     0xdf9808: and             x16, x17, x16, lsr #2
    //     0xdf980c: tst             x16, HEAP, lsr #32
    //     0xdf9810: b.eq            #0xdf9818
    //     0xdf9814: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xdf9818: mov             x2, x3
    // 0xdf981c: r1 = Function '<anonymous closure>':.
    //     0xdf981c: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4e10] AnonymousClosure: (0xdf9ac8), in [package:flutter/src/material/radio.dart] _RadioState::build (0xdf9628)
    //     0xdf9820: ldr             x1, [x1, #0xe10]
    // 0xdf9824: r0 = AllocateClosure()
    //     0xdf9824: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf9828: r16 = <MouseCursor>
    //     0xdf9828: ldr             x16, [PP, #0x21a8]  ; [pp+0x21a8] TypeArguments: <MouseCursor>
    // 0xdf982c: stp             x0, x16, [SP]
    // 0xdf9830: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdf9830: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdf9834: r0 = resolveWith()
    //     0xdf9834: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0xdf9838: mov             x2, x0
    // 0xdf983c: ldur            x0, [fp, #-8]
    // 0xdf9840: stur            x2, [fp, #-0x20]
    // 0xdf9844: LoadField: r1 = r0->field_b
    //     0xdf9844: ldur            w1, [x0, #0xb]
    // 0xdf9848: DecompressPointer r1
    //     0xdf9848: add             x1, x1, HEAP, lsl #32
    // 0xdf984c: cmp             w1, NULL
    // 0xdf9850: b.eq            #0xdf9950
    // 0xdf9854: LoadField: r3 = r1->field_f
    //     0xdf9854: ldur            w3, [x1, #0xf]
    // 0xdf9858: DecompressPointer r3
    //     0xdf9858: add             x3, x3, HEAP, lsl #32
    // 0xdf985c: mov             x1, x0
    // 0xdf9860: stur            x3, [fp, #-0x10]
    // 0xdf9864: r0 = _focusNode()
    //     0xdf9864: bl              #0xdf99b4  ; [package:flutter/src/material/radio.dart] _RadioState::_focusNode
    // 0xdf9868: mov             x2, x0
    // 0xdf986c: ldur            x0, [fp, #-8]
    // 0xdf9870: stur            x2, [fp, #-0x28]
    // 0xdf9874: LoadField: r1 = r0->field_b
    //     0xdf9874: ldur            w1, [x0, #0xb]
    // 0xdf9878: DecompressPointer r1
    //     0xdf9878: add             x1, x1, HEAP, lsl #32
    // 0xdf987c: cmp             w1, NULL
    // 0xdf9880: b.eq            #0xdf9954
    // 0xdf9884: mov             x1, x0
    // 0xdf9888: r0 = _effectiveRegistry()
    //     0xdf9888: bl              #0xdf9980  ; [package:flutter/src/material/radio.dart] _RadioState::_effectiveRegistry
    // 0xdf988c: ldur            x1, [fp, #-8]
    // 0xdf9890: stur            x0, [fp, #-0x30]
    // 0xdf9894: r0 = _enabled()
    //     0xdf9894: bl              #0xdf9958  ; [package:flutter/src/material/radio.dart] _RadioState::_enabled
    // 0xdf9898: mov             x4, x0
    // 0xdf989c: ldur            x0, [fp, #-8]
    // 0xdf98a0: stur            x4, [fp, #-0x38]
    // 0xdf98a4: LoadField: r2 = r0->field_7
    //     0xdf98a4: ldur            w2, [x0, #7]
    // 0xdf98a8: DecompressPointer r2
    //     0xdf98a8: add             x2, x2, HEAP, lsl #32
    // 0xdf98ac: r1 = Null
    //     0xdf98ac: mov             x1, NULL
    // 0xdf98b0: r3 = <C1X0>
    //     0xdf98b0: add             x3, PP, #0x11, lsl #12  ; [pp+0x11880] TypeArguments: <C1X0>
    //     0xdf98b4: ldr             x3, [x3, #0x880]
    // 0xdf98b8: r0 = Null
    //     0xdf98b8: mov             x0, NULL
    // 0xdf98bc: cmp             x2, x0
    // 0xdf98c0: b.eq            #0xdf98d0
    // 0xdf98c4: r30 = InstantiateTypeArgumentsStub
    //     0xdf98c4: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0xdf98c8: LoadField: r30 = r30->field_7
    //     0xdf98c8: ldur            lr, [lr, #7]
    // 0xdf98cc: blr             lr
    // 0xdf98d0: mov             x1, x0
    // 0xdf98d4: r0 = RawRadio()
    //     0xdf98d4: bl              #0xde626c  ; AllocateRawRadioStub -> RawRadio<X0> (size=0x30)
    // 0xdf98d8: mov             x3, x0
    // 0xdf98dc: ldur            x0, [fp, #-0x10]
    // 0xdf98e0: stur            x3, [fp, #-8]
    // 0xdf98e4: StoreField: r3->field_f = r0
    //     0xdf98e4: stur            w0, [x3, #0xf]
    // 0xdf98e8: ldur            x0, [fp, #-0x20]
    // 0xdf98ec: StoreField: r3->field_13 = r0
    //     0xdf98ec: stur            w0, [x3, #0x13]
    // 0xdf98f0: r0 = false
    //     0xdf98f0: add             x0, NULL, #0x30  ; false
    // 0xdf98f4: ArrayStore: r3[0] = r0  ; List_4
    //     0xdf98f4: stur            w0, [x3, #0x17]
    // 0xdf98f8: ldur            x1, [fp, #-0x28]
    // 0xdf98fc: StoreField: r3->field_1b = r1
    //     0xdf98fc: stur            w1, [x3, #0x1b]
    // 0xdf9900: StoreField: r3->field_1f = r0
    //     0xdf9900: stur            w0, [x3, #0x1f]
    // 0xdf9904: ldur            x0, [fp, #-0x30]
    // 0xdf9908: StoreField: r3->field_2b = r0
    //     0xdf9908: stur            w0, [x3, #0x2b]
    // 0xdf990c: ldur            x0, [fp, #-0x38]
    // 0xdf9910: StoreField: r3->field_27 = r0
    //     0xdf9910: stur            w0, [x3, #0x27]
    // 0xdf9914: ldur            x2, [fp, #-0x18]
    // 0xdf9918: r1 = Function '<anonymous closure>':.
    //     0xdf9918: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4e18] AnonymousClosure: (0xdf9a44), in [package:flutter/src/material/radio.dart] _RadioState::build (0xdf9628)
    //     0xdf991c: ldr             x1, [x1, #0xe18]
    // 0xdf9920: r0 = AllocateClosure()
    //     0xdf9920: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf9924: mov             x1, x0
    // 0xdf9928: ldur            x0, [fp, #-8]
    // 0xdf992c: StoreField: r0->field_23 = r1
    //     0xdf992c: stur            w1, [x0, #0x23]
    // 0xdf9930: LeaveFrame
    //     0xdf9930: mov             SP, fp
    //     0xdf9934: ldp             fp, lr, [SP], #0x10
    // 0xdf9938: ret
    //     0xdf9938: ret             
    // 0xdf993c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf993c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf9940: b               #0xdf9650
    // 0xdf9944: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf9944: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf9948: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf9948: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf994c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf994c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf9950: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf9950: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf9954: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf9954: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _enabled(/* No info */) {
    // ** addr: 0xdf9958, size: 0x28
    // 0xdf9958: LoadField: r2 = r1->field_b
    //     0xdf9958: ldur            w2, [x1, #0xb]
    // 0xdf995c: DecompressPointer r2
    //     0xdf995c: add             x2, x2, HEAP, lsl #32
    // 0xdf9960: cmp             w2, NULL
    // 0xdf9964: b.eq            #0xdf9974
    // 0xdf9968: LoadField: r0 = r2->field_57
    //     0xdf9968: ldur            w0, [x2, #0x57]
    // 0xdf996c: DecompressPointer r0
    //     0xdf996c: add             x0, x0, HEAP, lsl #32
    // 0xdf9970: ret
    //     0xdf9970: ret             
    // 0xdf9974: EnterFrame
    //     0xdf9974: stp             fp, lr, [SP, #-0x10]!
    //     0xdf9978: mov             fp, SP
    // 0xdf997c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf997c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _effectiveRegistry(/* No info */) {
    // ** addr: 0xdf9980, size: 0x28
    // 0xdf9980: LoadField: r2 = r1->field_b
    //     0xdf9980: ldur            w2, [x1, #0xb]
    // 0xdf9984: DecompressPointer r2
    //     0xdf9984: add             x2, x2, HEAP, lsl #32
    // 0xdf9988: cmp             w2, NULL
    // 0xdf998c: b.eq            #0xdf999c
    // 0xdf9990: LoadField: r0 = r2->field_4f
    //     0xdf9990: ldur            w0, [x2, #0x4f]
    // 0xdf9994: DecompressPointer r0
    //     0xdf9994: add             x0, x0, HEAP, lsl #32
    // 0xdf9998: ret
    //     0xdf9998: ret             
    // 0xdf999c: EnterFrame
    //     0xdf999c: stp             fp, lr, [SP, #-0x10]!
    //     0xdf99a0: mov             fp, SP
    // 0xdf99a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf99a4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _focusNode(/* No info */) {
    // ** addr: 0xdf99b4, size: 0x90
    // 0xdf99b4: EnterFrame
    //     0xdf99b4: stp             fp, lr, [SP, #-0x10]!
    //     0xdf99b8: mov             fp, SP
    // 0xdf99bc: AllocStack(0x10)
    //     0xdf99bc: sub             SP, SP, #0x10
    // 0xdf99c0: SetupParameters(_RadioState<C1X0> this /* r1 => r1, fp-0x8 */)
    //     0xdf99c0: stur            x1, [fp, #-8]
    // 0xdf99c4: CheckStackOverflow
    //     0xdf99c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf99c8: cmp             SP, x16
    //     0xdf99cc: b.ls            #0xdf9a38
    // 0xdf99d0: LoadField: r0 = r1->field_b
    //     0xdf99d0: ldur            w0, [x1, #0xb]
    // 0xdf99d4: DecompressPointer r0
    //     0xdf99d4: add             x0, x0, HEAP, lsl #32
    // 0xdf99d8: cmp             w0, NULL
    // 0xdf99dc: b.eq            #0xdf9a40
    // 0xdf99e0: LoadField: r0 = r1->field_13
    //     0xdf99e0: ldur            w0, [x1, #0x13]
    // 0xdf99e4: DecompressPointer r0
    //     0xdf99e4: add             x0, x0, HEAP, lsl #32
    // 0xdf99e8: cmp             w0, NULL
    // 0xdf99ec: b.ne            #0xdf9a2c
    // 0xdf99f0: r0 = FocusNode()
    //     0xdf99f0: bl              #0xd4952c  ; AllocateFocusNodeStub -> FocusNode (size=0x68)
    // 0xdf99f4: mov             x1, x0
    // 0xdf99f8: stur            x0, [fp, #-0x10]
    // 0xdf99fc: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xdf99fc: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xdf9a00: r0 = FocusNode()
    //     0xdf9a00: bl              #0x83cf84  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::FocusNode
    // 0xdf9a04: ldur            x0, [fp, #-0x10]
    // 0xdf9a08: ldur            x1, [fp, #-8]
    // 0xdf9a0c: StoreField: r1->field_13 = r0
    //     0xdf9a0c: stur            w0, [x1, #0x13]
    //     0xdf9a10: ldurb           w16, [x1, #-1]
    //     0xdf9a14: ldurb           w17, [x0, #-1]
    //     0xdf9a18: and             x16, x17, x16, lsr #2
    //     0xdf9a1c: tst             x16, HEAP, lsr #32
    //     0xdf9a20: b.eq            #0xdf9a28
    //     0xdf9a24: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdf9a28: ldur            x0, [fp, #-0x10]
    // 0xdf9a2c: LeaveFrame
    //     0xdf9a2c: mov             SP, fp
    //     0xdf9a30: ldp             fp, lr, [SP], #0x10
    // 0xdf9a34: ret
    //     0xdf9a34: ret             
    // 0xdf9a38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf9a38: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf9a3c: b               #0xdf99d0
    // 0xdf9a40: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf9a40: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] _RadioPaint <anonymous closure>(dynamic, BuildContext, ToggleableStateMixin<StatefulWidget>) {
    // ** addr: 0xdf9a44, size: 0x54
    // 0xdf9a44: EnterFrame
    //     0xdf9a44: stp             fp, lr, [SP, #-0x10]!
    //     0xdf9a48: mov             fp, SP
    // 0xdf9a4c: ldr             x0, [fp, #0x20]
    // 0xdf9a50: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdf9a50: ldur            w1, [x0, #0x17]
    // 0xdf9a54: DecompressPointer r1
    //     0xdf9a54: add             x1, x1, HEAP, lsl #32
    // 0xdf9a58: LoadField: r0 = r1->field_f
    //     0xdf9a58: ldur            w0, [x1, #0xf]
    // 0xdf9a5c: DecompressPointer r0
    //     0xdf9a5c: add             x0, x0, HEAP, lsl #32
    // 0xdf9a60: LoadField: r1 = r0->field_b
    //     0xdf9a60: ldur            w1, [x0, #0xb]
    // 0xdf9a64: DecompressPointer r1
    //     0xdf9a64: add             x1, x1, HEAP, lsl #32
    // 0xdf9a68: cmp             w1, NULL
    // 0xdf9a6c: b.eq            #0xdf9a94
    // 0xdf9a70: r0 = _RadioPaint()
    //     0xdf9a70: bl              #0xdf9a98  ; Allocate_RadioPaintStub -> _RadioPaint (size=0x3c)
    // 0xdf9a74: ldr             x1, [fp, #0x10]
    // 0xdf9a78: StoreField: r0->field_b = r1
    //     0xdf9a78: stur            w1, [x0, #0xb]
    // 0xdf9a7c: r1 = Instance_MaterialTapTargetSize
    //     0xdf9a7c: add             x1, PP, #0x18, lsl #12  ; [pp+0x18318] Obj!MaterialTapTargetSize@12c4ba1
    //     0xdf9a80: ldr             x1, [x1, #0x318]
    // 0xdf9a84: StoreField: r0->field_2b = r1
    //     0xdf9a84: stur            w1, [x0, #0x2b]
    // 0xdf9a88: LeaveFrame
    //     0xdf9a88: mov             SP, fp
    //     0xdf9a8c: ldp             fp, lr, [SP], #0x10
    // 0xdf9a90: ret
    //     0xdf9a90: ret             
    // 0xdf9a94: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf9a94: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] MouseCursor <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xdf9ac8, size: 0x90
    // 0xdf9ac8: EnterFrame
    //     0xdf9ac8: stp             fp, lr, [SP, #-0x10]!
    //     0xdf9acc: mov             fp, SP
    // 0xdf9ad0: AllocStack(0x18)
    //     0xdf9ad0: sub             SP, SP, #0x18
    // 0xdf9ad4: SetupParameters([dynamic _ /* r0 */])
    //     0xdf9ad4: ldr             x0, [fp, #0x18]
    //     0xdf9ad8: ldur            w1, [x0, #0x17]
    //     0xdf9adc: add             x1, x1, HEAP, lsl #32
    // 0xdf9ae0: CheckStackOverflow
    //     0xdf9ae0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf9ae4: cmp             SP, x16
    //     0xdf9ae8: b.ls            #0xdf9b4c
    // 0xdf9aec: LoadField: r0 = r1->field_f
    //     0xdf9aec: ldur            w0, [x1, #0xf]
    // 0xdf9af0: DecompressPointer r0
    //     0xdf9af0: add             x0, x0, HEAP, lsl #32
    // 0xdf9af4: LoadField: r1 = r0->field_b
    //     0xdf9af4: ldur            w1, [x0, #0xb]
    // 0xdf9af8: DecompressPointer r1
    //     0xdf9af8: add             x1, x1, HEAP, lsl #32
    // 0xdf9afc: cmp             w1, NULL
    // 0xdf9b00: b.eq            #0xdf9b54
    // 0xdf9b04: r16 = <MouseCursor?>
    //     0xdf9b04: add             x16, PP, #0x15, lsl #12  ; [pp+0x15ab8] TypeArguments: <MouseCursor?>
    //     0xdf9b08: ldr             x16, [x16, #0xab8]
    // 0xdf9b0c: stp             NULL, x16, [SP, #8]
    // 0xdf9b10: ldr             x16, [fp, #0x10]
    // 0xdf9b14: str             x16, [SP]
    // 0xdf9b18: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xdf9b18: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xdf9b1c: r0 = resolveAs()
    //     0xdf9b1c: bl              #0x8de57c  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveAs
    // 0xdf9b20: r16 = <MouseCursor>
    //     0xdf9b20: ldr             x16, [PP, #0x21a8]  ; [pp+0x21a8] TypeArguments: <MouseCursor>
    // 0xdf9b24: r30 = Instance__WidgetStateMouseCursor
    //     0xdf9b24: add             lr, PP, #0x80, lsl #12  ; [pp+0x80c18] Obj!_WidgetStateMouseCursor@12b3251
    //     0xdf9b28: ldr             lr, [lr, #0xc18]
    // 0xdf9b2c: stp             lr, x16, [SP, #8]
    // 0xdf9b30: ldr             x16, [fp, #0x10]
    // 0xdf9b34: str             x16, [SP]
    // 0xdf9b38: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xdf9b38: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xdf9b3c: r0 = resolveAs()
    //     0xdf9b3c: bl              #0x8de57c  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveAs
    // 0xdf9b40: LeaveFrame
    //     0xdf9b40: mov             SP, fp
    //     0xdf9b44: ldp             fp, lr, [SP], #0x10
    // 0xdf9b48: ret
    //     0xdf9b48: ret             
    // 0xdf9b4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf9b4c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf9b50: b               #0xdf9aec
    // 0xdf9b54: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf9b54: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10e5e88, size: 0x44
    // 0x10e5e88: EnterFrame
    //     0x10e5e88: stp             fp, lr, [SP, #-0x10]!
    //     0x10e5e8c: mov             fp, SP
    // 0x10e5e90: CheckStackOverflow
    //     0x10e5e90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e5e94: cmp             SP, x16
    //     0x10e5e98: b.ls            #0x10e5ec4
    // 0x10e5e9c: LoadField: r0 = r1->field_13
    //     0x10e5e9c: ldur            w0, [x1, #0x13]
    // 0x10e5ea0: DecompressPointer r0
    //     0x10e5ea0: add             x0, x0, HEAP, lsl #32
    // 0x10e5ea4: cmp             w0, NULL
    // 0x10e5ea8: b.eq            #0x10e5eb4
    // 0x10e5eac: mov             x1, x0
    // 0x10e5eb0: r0 = dispose()
    //     0x10e5eb0: bl              #0x10ec024  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::dispose
    // 0x10e5eb4: r0 = Null
    //     0x10e5eb4: mov             x0, NULL
    // 0x10e5eb8: LeaveFrame
    //     0x10e5eb8: mov             SP, fp
    //     0x10e5ebc: ldp             fp, lr, [SP], #0x10
    // 0x10e5ec0: ret
    //     0x10e5ec0: ret             
    // 0x10e5ec4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e5ec4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e5ec8: b               #0x10e5e9c
  }
}

// class id: 6442, size: 0x3c, field offset: 0xc
//   const constructor, 
class _RadioPaint extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa26f0, size: 0x7c
    // 0xfa26f0: EnterFrame
    //     0xfa26f0: stp             fp, lr, [SP, #-0x10]!
    //     0xfa26f4: mov             fp, SP
    // 0xfa26f8: AllocStack(0x8)
    //     0xfa26f8: sub             SP, SP, #8
    // 0xfa26fc: CheckStackOverflow
    //     0xfa26fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa2700: cmp             SP, x16
    //     0xfa2704: b.ls            #0xfa2764
    // 0xfa2708: r0 = _RadioPainter()
    //     0xfa2708: bl              #0xfa2778  ; Allocate_RadioPainterStub -> _RadioPainter (size=0x74)
    // 0xfa270c: stur            x0, [fp, #-8]
    // 0xfa2710: StoreField: r0->field_7 = rZR
    //     0xfa2710: stur            xzr, [x0, #7]
    // 0xfa2714: StoreField: r0->field_13 = rZR
    //     0xfa2714: stur            xzr, [x0, #0x13]
    // 0xfa2718: StoreField: r0->field_1b = rZR
    //     0xfa2718: stur            xzr, [x0, #0x1b]
    // 0xfa271c: r0 = LoadStaticField(0x45c)
    //     0xfa271c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xfa2720: ldr             x0, [x0, #0x8b8]
    // 0xfa2724: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa2728: cmp             w0, w16
    // 0xfa272c: b.ne            #0xfa2738
    // 0xfa2730: r2 = _emptyListeners
    //     0xfa2730: ldr             x2, [PP, #0x17f0]  ; [pp+0x17f0] Field <ChangeNotifier._emptyListeners@28329750>: static late final (offset: 0x45c)
    // 0xfa2734: r0 = InitLateFinalStaticField()
    //     0xfa2734: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xfa2738: mov             x1, x0
    // 0xfa273c: ldur            x0, [fp, #-8]
    // 0xfa2740: StoreField: r0->field_f = r1
    //     0xfa2740: stur            w1, [x0, #0xf]
    // 0xfa2744: r1 = <_RadioPaint>
    //     0xfa2744: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd4f20] TypeArguments: <_RadioPaint>
    //     0xfa2748: ldr             x1, [x1, #0xf20]
    // 0xfa274c: r0 = _RadioPaintState()
    //     0xfa274c: bl              #0xfa276c  ; Allocate_RadioPaintStateStub -> _RadioPaintState (size=0x18)
    // 0xfa2750: ldur            x1, [fp, #-8]
    // 0xfa2754: StoreField: r0->field_13 = r1
    //     0xfa2754: stur            w1, [x0, #0x13]
    // 0xfa2758: LeaveFrame
    //     0xfa2758: mov             SP, fp
    //     0xfa275c: ldp             fp, lr, [SP], #0x10
    // 0xfa2760: ret
    //     0xfa2760: ret             
    // 0xfa2764: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa2764: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa2768: b               #0xfa2708
  }
}

// class id: 6443, size: 0x68, field offset: 0xc
//   const constructor, 
class Radio<X0> extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa26a8, size: 0x3c
    // 0xfa26a8: EnterFrame
    //     0xfa26a8: stp             fp, lr, [SP, #-0x10]!
    //     0xfa26ac: mov             fp, SP
    // 0xfa26b0: LoadField: r2 = r1->field_b
    //     0xfa26b0: ldur            w2, [x1, #0xb]
    // 0xfa26b4: DecompressPointer r2
    //     0xfa26b4: add             x2, x2, HEAP, lsl #32
    // 0xfa26b8: r1 = Null
    //     0xfa26b8: mov             x1, NULL
    // 0xfa26bc: r3 = <Radio<X0>, X0>
    //     0xfa26bc: add             x3, PP, #0xd4, lsl #12  ; [pp+0xd49f8] TypeArguments: <Radio<X0>, X0>
    //     0xfa26c0: ldr             x3, [x3, #0x9f8]
    // 0xfa26c4: r30 = InstantiateTypeArgumentsStub
    //     0xfa26c4: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0xfa26c8: LoadField: r30 = r30->field_7
    //     0xfa26c8: ldur            lr, [lr, #7]
    // 0xfa26cc: blr             lr
    // 0xfa26d0: mov             x1, x0
    // 0xfa26d4: r0 = _RadioState()
    //     0xfa26d4: bl              #0xfa26e4  ; Allocate_RadioStateStub -> _RadioState<C1X0> (size=0x18)
    // 0xfa26d8: LeaveFrame
    //     0xfa26d8: mov             SP, fp
    //     0xfa26dc: ldp             fp, lr, [SP], #0x10
    // 0xfa26e0: ret
    //     0xfa26e0: ret             
  }
}

// class id: 8273, size: 0x14, field offset: 0x14
enum _RadioType extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}
