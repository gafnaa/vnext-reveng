// lib: , url: package:flutter/src/material/tooltip_theme.dart

// class id: 1048973, size: 0x8
class :: {
}

// class id: 5050, size: 0x44, field offset: 0x8
//   const constructor, 
class TooltipThemeData extends _MixinApplication3&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0x113b17c, size: 0x84
    // 0x113b17c: EnterFrame
    //     0x113b17c: stp             fp, lr, [SP, #-0x10]!
    //     0x113b180: mov             fp, SP
    // 0x113b184: AllocStack(0x68)
    //     0x113b184: sub             SP, SP, #0x68
    // 0x113b188: CheckStackOverflow
    //     0x113b188: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x113b18c: cmp             SP, x16
    //     0x113b190: b.ls            #0x113b1f8
    // 0x113b194: ldr             x0, [fp, #0x10]
    // 0x113b198: LoadField: r1 = r0->field_7
    //     0x113b198: ldur            w1, [x0, #7]
    // 0x113b19c: DecompressPointer r1
    //     0x113b19c: add             x1, x1, HEAP, lsl #32
    // 0x113b1a0: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x113b1a0: ldur            w2, [x0, #0x17]
    // 0x113b1a4: DecompressPointer r2
    //     0x113b1a4: add             x2, x2, HEAP, lsl #32
    // 0x113b1a8: stp             NULL, NULL, [SP, #0x58]
    // 0x113b1ac: stp             NULL, x2, [SP, #0x48]
    // 0x113b1b0: stp             NULL, NULL, [SP, #0x38]
    // 0x113b1b4: stp             NULL, NULL, [SP, #0x28]
    // 0x113b1b8: stp             NULL, NULL, [SP, #0x18]
    // 0x113b1bc: stp             NULL, NULL, [SP, #8]
    // 0x113b1c0: str             NULL, [SP]
    // 0x113b1c4: r2 = Null
    //     0x113b1c4: mov             x2, NULL
    // 0x113b1c8: r4 = const [0, 0xf, 0xd, 0xf, null]
    //     0x113b1c8: add             x4, PP, #0xd, lsl #12  ; [pp+0xdf18] List(5) [0, 0xf, 0xd, 0xf, Null]
    //     0x113b1cc: ldr             x4, [x4, #0xf18]
    // 0x113b1d0: r0 = hash()
    //     0x113b1d0: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x113b1d4: mov             x2, x0
    // 0x113b1d8: r0 = BoxInt64Instr(r2)
    //     0x113b1d8: sbfiz           x0, x2, #1, #0x1f
    //     0x113b1dc: cmp             x2, x0, asr #1
    //     0x113b1e0: b.eq            #0x113b1ec
    //     0x113b1e4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x113b1e8: stur            x2, [x0, #7]
    // 0x113b1ec: LeaveFrame
    //     0x113b1ec: mov             SP, fp
    //     0x113b1f0: ldp             fp, lr, [SP], #0x10
    // 0x113b1f4: ret
    //     0x113b1f4: ret             
    // 0x113b1f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x113b1f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x113b1fc: b               #0x113b194
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x115f500, size: 0x150
    // 0x115f500: EnterFrame
    //     0x115f500: stp             fp, lr, [SP, #-0x10]!
    //     0x115f504: mov             fp, SP
    // 0x115f508: AllocStack(0x28)
    //     0x115f508: sub             SP, SP, #0x28
    // 0x115f50c: SetupParameters(dynamic _ /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */, dynamic _ /* d0 => d0, fp-0x28 */)
    //     0x115f50c: mov             x4, x1
    //     0x115f510: mov             x0, x2
    //     0x115f514: stur            x1, [fp, #-0x10]
    //     0x115f518: stur            x2, [fp, #-0x18]
    //     0x115f51c: stur            d0, [fp, #-0x28]
    // 0x115f520: CheckStackOverflow
    //     0x115f520: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x115f524: cmp             SP, x16
    //     0x115f528: b.ls            #0x115f624
    // 0x115f52c: cmp             w4, w0
    // 0x115f530: b.ne            #0x115f544
    // 0x115f534: mov             x0, x4
    // 0x115f538: LeaveFrame
    //     0x115f538: mov             SP, fp
    //     0x115f53c: ldp             fp, lr, [SP], #0x10
    // 0x115f540: ret
    //     0x115f540: ret             
    // 0x115f544: LoadField: r1 = r4->field_7
    //     0x115f544: ldur            w1, [x4, #7]
    // 0x115f548: DecompressPointer r1
    //     0x115f548: add             x1, x1, HEAP, lsl #32
    // 0x115f54c: LoadField: r2 = r0->field_7
    //     0x115f54c: ldur            w2, [x0, #7]
    // 0x115f550: DecompressPointer r2
    //     0x115f550: add             x2, x2, HEAP, lsl #32
    // 0x115f554: r5 = inline_Allocate_Double()
    //     0x115f554: ldp             x5, x3, [THR, #0x60]  ; THR::top
    //     0x115f558: add             x5, x5, #0x10
    //     0x115f55c: cmp             x3, x5
    //     0x115f560: b.ls            #0x115f62c
    //     0x115f564: str             x5, [THR, #0x60]  ; THR::top
    //     0x115f568: sub             x5, x5, #0xf
    //     0x115f56c: mov             x3, #0xe19c
    //     0x115f570: movk            x3, #3, lsl #16
    //     0x115f574: stur            x3, [x5, #-1]
    // 0x115f578: dmb             ishst
    // 0x115f57c: StoreField: r5->field_7 = d0
    //     0x115f57c: stur            d0, [x5, #7]
    // 0x115f580: mov             x3, x5
    // 0x115f584: stur            x5, [fp, #-8]
    // 0x115f588: r0 = lerpDouble()
    //     0x115f588: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x115f58c: ldur            d0, [fp, #-0x28]
    // 0x115f590: r1 = Null
    //     0x115f590: mov             x1, NULL
    // 0x115f594: r2 = Null
    //     0x115f594: mov             x2, NULL
    // 0x115f598: stur            x0, [fp, #-0x20]
    // 0x115f59c: r0 = lerp()
    //     0x115f59c: bl              #0x1163c14  ; [package:flutter/src/rendering/box.dart] BoxConstraints::lerp
    // 0x115f5a0: ldur            x3, [fp, #-8]
    // 0x115f5a4: r1 = Null
    //     0x115f5a4: mov             x1, NULL
    // 0x115f5a8: r2 = Null
    //     0x115f5a8: mov             x2, NULL
    // 0x115f5ac: r0 = lerp()
    //     0x115f5ac: bl              #0x1140de0  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0x115f5b0: ldur            x3, [fp, #-8]
    // 0x115f5b4: r1 = Null
    //     0x115f5b4: mov             x1, NULL
    // 0x115f5b8: r2 = Null
    //     0x115f5b8: mov             x2, NULL
    // 0x115f5bc: r0 = lerp()
    //     0x115f5bc: bl              #0x1140de0  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0x115f5c0: ldur            x0, [fp, #-0x10]
    // 0x115f5c4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x115f5c4: ldur            w1, [x0, #0x17]
    // 0x115f5c8: DecompressPointer r1
    //     0x115f5c8: add             x1, x1, HEAP, lsl #32
    // 0x115f5cc: ldur            x0, [fp, #-0x18]
    // 0x115f5d0: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x115f5d0: ldur            w2, [x0, #0x17]
    // 0x115f5d4: DecompressPointer r2
    //     0x115f5d4: add             x2, x2, HEAP, lsl #32
    // 0x115f5d8: ldur            x3, [fp, #-8]
    // 0x115f5dc: r0 = lerpDouble()
    //     0x115f5dc: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x115f5e0: ldur            d0, [fp, #-0x28]
    // 0x115f5e4: r1 = Null
    //     0x115f5e4: mov             x1, NULL
    // 0x115f5e8: r2 = Null
    //     0x115f5e8: mov             x2, NULL
    // 0x115f5ec: stur            x0, [fp, #-0x10]
    // 0x115f5f0: r0 = lerp()
    //     0x115f5f0: bl              #0x115f65c  ; [package:flutter/src/painting/decoration.dart] Decoration::lerp
    // 0x115f5f4: ldur            x3, [fp, #-8]
    // 0x115f5f8: r1 = Null
    //     0x115f5f8: mov             x1, NULL
    // 0x115f5fc: r2 = Null
    //     0x115f5fc: mov             x2, NULL
    // 0x115f600: r0 = lerp()
    //     0x115f600: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x115f604: r0 = TooltipThemeData()
    //     0x115f604: bl              #0x115f650  ; AllocateTooltipThemeDataStub -> TooltipThemeData (size=0x44)
    // 0x115f608: ldur            x1, [fp, #-0x20]
    // 0x115f60c: StoreField: r0->field_7 = r1
    //     0x115f60c: stur            w1, [x0, #7]
    // 0x115f610: ldur            x1, [fp, #-0x10]
    // 0x115f614: ArrayStore: r0[0] = r1  ; List_4
    //     0x115f614: stur            w1, [x0, #0x17]
    // 0x115f618: LeaveFrame
    //     0x115f618: mov             SP, fp
    //     0x115f61c: ldp             fp, lr, [SP], #0x10
    // 0x115f620: ret
    //     0x115f620: ret             
    // 0x115f624: r0 = StackOverflowSharedWithFPURegs()
    //     0x115f624: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x115f628: b               #0x115f52c
    // 0x115f62c: SaveReg d0
    //     0x115f62c: str             q0, [SP, #-0x10]!
    // 0x115f630: stp             x2, x4, [SP, #-0x10]!
    // 0x115f634: stp             x0, x1, [SP, #-0x10]!
    // 0x115f638: r0 = AllocateDouble()
    //     0x115f638: bl              #0x13df878  ; AllocateDoubleStub
    // 0x115f63c: mov             x5, x0
    // 0x115f640: ldp             x0, x1, [SP], #0x10
    // 0x115f644: ldp             x2, x4, [SP], #0x10
    // 0x115f648: RestoreReg d0
    //     0x115f648: ldr             q0, [SP], #0x10
    // 0x115f64c: b               #0x115f57c
  }
  _ ==(/* No info */) {
    // ** addr: 0x12785a0, size: 0x13c
    // 0x12785a0: EnterFrame
    //     0x12785a0: stp             fp, lr, [SP, #-0x10]!
    //     0x12785a4: mov             fp, SP
    // 0x12785a8: AllocStack(0x10)
    //     0x12785a8: sub             SP, SP, #0x10
    // 0x12785ac: CheckStackOverflow
    //     0x12785ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12785b0: cmp             SP, x16
    //     0x12785b4: b.ls            #0x12786d4
    // 0x12785b8: ldr             x0, [fp, #0x10]
    // 0x12785bc: cmp             w0, NULL
    // 0x12785c0: b.ne            #0x12785d4
    // 0x12785c4: r0 = false
    //     0x12785c4: add             x0, NULL, #0x30  ; false
    // 0x12785c8: LeaveFrame
    //     0x12785c8: mov             SP, fp
    //     0x12785cc: ldp             fp, lr, [SP], #0x10
    // 0x12785d0: ret
    //     0x12785d0: ret             
    // 0x12785d4: ldr             x1, [fp, #0x18]
    // 0x12785d8: cmp             w1, w0
    // 0x12785dc: b.ne            #0x12785f0
    // 0x12785e0: r0 = true
    //     0x12785e0: add             x0, NULL, #0x20  ; true
    // 0x12785e4: LeaveFrame
    //     0x12785e4: mov             SP, fp
    //     0x12785e8: ldp             fp, lr, [SP], #0x10
    // 0x12785ec: ret
    //     0x12785ec: ret             
    // 0x12785f0: str             x0, [SP]
    // 0x12785f4: r0 = runtimeType()
    //     0x12785f4: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x12785f8: r1 = LoadClassIdInstr(r0)
    //     0x12785f8: ldur            x1, [x0, #-1]
    //     0x12785fc: ubfx            x1, x1, #0xc, #0x14
    // 0x1278600: r16 = TooltipThemeData
    //     0x1278600: add             x16, PP, #0x26, lsl #12  ; [pp+0x26090] Type: TooltipThemeData
    //     0x1278604: ldr             x16, [x16, #0x90]
    // 0x1278608: stp             x16, x0, [SP]
    // 0x127860c: mov             x0, x1
    // 0x1278610: mov             lr, x0
    // 0x1278614: ldr             lr, [x21, lr, lsl #3]
    // 0x1278618: blr             lr
    // 0x127861c: tbz             w0, #4, #0x1278630
    // 0x1278620: r0 = false
    //     0x1278620: add             x0, NULL, #0x30  ; false
    // 0x1278624: LeaveFrame
    //     0x1278624: mov             SP, fp
    //     0x1278628: ldp             fp, lr, [SP], #0x10
    // 0x127862c: ret
    //     0x127862c: ret             
    // 0x1278630: ldr             x1, [fp, #0x10]
    // 0x1278634: r0 = 60
    //     0x1278634: mov             x0, #0x3c
    // 0x1278638: branchIfSmi(r1, 0x1278644)
    //     0x1278638: tbz             w1, #0, #0x1278644
    // 0x127863c: r0 = LoadClassIdInstr(r1)
    //     0x127863c: ldur            x0, [x1, #-1]
    //     0x1278640: ubfx            x0, x0, #0xc, #0x14
    // 0x1278644: r17 = 5050
    //     0x1278644: mov             x17, #0x13ba
    // 0x1278648: cmp             x0, x17
    // 0x127864c: b.ne            #0x12786c4
    // 0x1278650: ldr             x2, [fp, #0x18]
    // 0x1278654: LoadField: r0 = r1->field_7
    //     0x1278654: ldur            w0, [x1, #7]
    // 0x1278658: DecompressPointer r0
    //     0x1278658: add             x0, x0, HEAP, lsl #32
    // 0x127865c: LoadField: r3 = r2->field_7
    //     0x127865c: ldur            w3, [x2, #7]
    // 0x1278660: DecompressPointer r3
    //     0x1278660: add             x3, x3, HEAP, lsl #32
    // 0x1278664: r4 = LoadClassIdInstr(r0)
    //     0x1278664: ldur            x4, [x0, #-1]
    //     0x1278668: ubfx            x4, x4, #0xc, #0x14
    // 0x127866c: stp             x3, x0, [SP]
    // 0x1278670: mov             x0, x4
    // 0x1278674: mov             lr, x0
    // 0x1278678: ldr             lr, [x21, lr, lsl #3]
    // 0x127867c: blr             lr
    // 0x1278680: tbnz            w0, #4, #0x12786c4
    // 0x1278684: ldr             x1, [fp, #0x18]
    // 0x1278688: ldr             x0, [fp, #0x10]
    // 0x127868c: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x127868c: ldur            w2, [x0, #0x17]
    // 0x1278690: DecompressPointer r2
    //     0x1278690: add             x2, x2, HEAP, lsl #32
    // 0x1278694: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x1278694: ldur            w0, [x1, #0x17]
    // 0x1278698: DecompressPointer r0
    //     0x1278698: add             x0, x0, HEAP, lsl #32
    // 0x127869c: r1 = LoadClassIdInstr(r2)
    //     0x127869c: ldur            x1, [x2, #-1]
    //     0x12786a0: ubfx            x1, x1, #0xc, #0x14
    // 0x12786a4: stp             x0, x2, [SP]
    // 0x12786a8: mov             x0, x1
    // 0x12786ac: mov             lr, x0
    // 0x12786b0: ldr             lr, [x21, lr, lsl #3]
    // 0x12786b4: blr             lr
    // 0x12786b8: tbnz            w0, #4, #0x12786c4
    // 0x12786bc: r0 = true
    //     0x12786bc: add             x0, NULL, #0x20  ; true
    // 0x12786c0: b               #0x12786c8
    // 0x12786c4: r0 = false
    //     0x12786c4: add             x0, NULL, #0x30  ; false
    // 0x12786c8: LeaveFrame
    //     0x12786c8: mov             SP, fp
    //     0x12786cc: ldp             fp, lr, [SP], #0x10
    // 0x12786d0: ret
    //     0x12786d0: ret             
    // 0x12786d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12786d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12786d8: b               #0x12785b8
  }
}

// class id: 6833, size: 0x10, field offset: 0x10
//   const constructor, 
abstract class TooltipTheme extends InheritedTheme {

  static _ of(/* No info */) {
    // ** addr: 0xeef120, size: 0x5c
    // 0xeef120: EnterFrame
    //     0xeef120: stp             fp, lr, [SP, #-0x10]!
    //     0xeef124: mov             fp, SP
    // 0xeef128: AllocStack(0x18)
    //     0xeef128: sub             SP, SP, #0x18
    // 0xeef12c: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0xeef12c: stur            x1, [fp, #-8]
    // 0xeef130: CheckStackOverflow
    //     0xeef130: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeef134: cmp             SP, x16
    //     0xeef138: b.ls            #0xeef174
    // 0xeef13c: r16 = <TooltipTheme>
    //     0xeef13c: add             x16, PP, #0x98, lsl #12  ; [pp+0x98e28] TypeArguments: <TooltipTheme>
    //     0xeef140: ldr             x16, [x16, #0xe28]
    // 0xeef144: stp             x1, x16, [SP]
    // 0xeef148: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xeef148: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xeef14c: r0 = dependOnInheritedWidgetOfExactType()
    //     0xeef14c: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xeef150: ldur            x1, [fp, #-8]
    // 0xeef154: r0 = of()
    //     0xeef154: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xeef158: r17 = 323
    //     0xeef158: mov             x17, #0x143
    // 0xeef15c: ldr             w1, [x0, x17]
    // 0xeef160: DecompressPointer r1
    //     0xeef160: add             x1, x1, HEAP, lsl #32
    // 0xeef164: mov             x0, x1
    // 0xeef168: LeaveFrame
    //     0xeef168: mov             SP, fp
    //     0xeef16c: ldp             fp, lr, [SP], #0x10
    // 0xeef170: ret
    //     0xeef170: ret             
    // 0xeef174: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeef174: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeef178: b               #0xeef13c
  }
}
