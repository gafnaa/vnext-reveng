// lib: , url: package:flutter/src/material/toggle_buttons_theme.dart

// class id: 1048971, size: 0x8
class :: {
}

// class id: 5051, size: 0x44, field offset: 0x8
//   const constructor, 
class ToggleButtonsThemeData extends _MixinApplication3&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0x113b0fc, size: 0x80
    // 0x113b0fc: EnterFrame
    //     0x113b0fc: stp             fp, lr, [SP, #-0x10]!
    //     0x113b100: mov             fp, SP
    // 0x113b104: AllocStack(0x68)
    //     0x113b104: sub             SP, SP, #0x68
    // 0x113b108: CheckStackOverflow
    //     0x113b108: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x113b10c: cmp             SP, x16
    //     0x113b110: b.ls            #0x113b174
    // 0x113b114: ldr             x0, [fp, #0x10]
    // 0x113b118: LoadField: r1 = r0->field_3b
    //     0x113b118: ldur            w1, [x0, #0x3b]
    // 0x113b11c: DecompressPointer r1
    //     0x113b11c: add             x1, x1, HEAP, lsl #32
    // 0x113b120: stp             NULL, NULL, [SP, #0x58]
    // 0x113b124: stp             NULL, NULL, [SP, #0x48]
    // 0x113b128: stp             NULL, NULL, [SP, #0x38]
    // 0x113b12c: stp             NULL, NULL, [SP, #0x28]
    // 0x113b130: stp             NULL, NULL, [SP, #0x18]
    // 0x113b134: stp             NULL, NULL, [SP, #8]
    // 0x113b138: str             x1, [SP]
    // 0x113b13c: r1 = Null
    //     0x113b13c: mov             x1, NULL
    // 0x113b140: r2 = Null
    //     0x113b140: mov             x2, NULL
    // 0x113b144: r4 = const [0, 0xf, 0xd, 0xf, null]
    //     0x113b144: add             x4, PP, #0xd, lsl #12  ; [pp+0xdf18] List(5) [0, 0xf, 0xd, 0xf, Null]
    //     0x113b148: ldr             x4, [x4, #0xf18]
    // 0x113b14c: r0 = hash()
    //     0x113b14c: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x113b150: mov             x2, x0
    // 0x113b154: r0 = BoxInt64Instr(r2)
    //     0x113b154: sbfiz           x0, x2, #1, #0x1f
    //     0x113b158: cmp             x2, x0, asr #1
    //     0x113b15c: b.eq            #0x113b168
    //     0x113b160: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x113b164: stur            x2, [x0, #7]
    // 0x113b168: LeaveFrame
    //     0x113b168: mov             SP, fp
    //     0x113b16c: ldp             fp, lr, [SP], #0x10
    // 0x113b170: ret
    //     0x113b170: ret             
    // 0x113b174: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x113b174: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x113b178: b               #0x113b114
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x1164238, size: 0x1b4
    // 0x1164238: EnterFrame
    //     0x1164238: stp             fp, lr, [SP, #-0x10]!
    //     0x116423c: mov             fp, SP
    // 0x1164240: AllocStack(0x20)
    //     0x1164240: sub             SP, SP, #0x20
    // 0x1164244: SetupParameters(dynamic _ /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */, dynamic _ /* d0 => d0, fp-0x20 */)
    //     0x1164244: mov             x4, x1
    //     0x1164248: mov             x0, x2
    //     0x116424c: stur            x1, [fp, #-0x10]
    //     0x1164250: stur            x2, [fp, #-0x18]
    //     0x1164254: stur            d0, [fp, #-0x20]
    // 0x1164258: CheckStackOverflow
    //     0x1164258: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x116425c: cmp             SP, x16
    //     0x1164260: b.ls            #0x11643c8
    // 0x1164264: cmp             w4, w0
    // 0x1164268: b.ne            #0x116427c
    // 0x116426c: mov             x0, x4
    // 0x1164270: LeaveFrame
    //     0x1164270: mov             SP, fp
    //     0x1164274: ldp             fp, lr, [SP], #0x10
    // 0x1164278: ret
    //     0x1164278: ret             
    // 0x116427c: r5 = inline_Allocate_Double()
    //     0x116427c: ldp             x5, x1, [THR, #0x60]  ; THR::top
    //     0x1164280: add             x5, x5, #0x10
    //     0x1164284: cmp             x1, x5
    //     0x1164288: b.ls            #0x11643d0
    //     0x116428c: str             x5, [THR, #0x60]  ; THR::top
    //     0x1164290: sub             x5, x5, #0xf
    //     0x1164294: mov             x1, #0xe19c
    //     0x1164298: movk            x1, #3, lsl #16
    //     0x116429c: stur            x1, [x5, #-1]
    // 0x11642a0: dmb             ishst
    // 0x11642a4: StoreField: r5->field_7 = d0
    //     0x11642a4: stur            d0, [x5, #7]
    // 0x11642a8: mov             x3, x5
    // 0x11642ac: stur            x5, [fp, #-8]
    // 0x11642b0: r1 = Null
    //     0x11642b0: mov             x1, NULL
    // 0x11642b4: r2 = Null
    //     0x11642b4: mov             x2, NULL
    // 0x11642b8: r0 = lerp()
    //     0x11642b8: bl              #0xfb0d58  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0x11642bc: ldur            d0, [fp, #-0x20]
    // 0x11642c0: r1 = Null
    //     0x11642c0: mov             x1, NULL
    // 0x11642c4: r2 = Null
    //     0x11642c4: mov             x2, NULL
    // 0x11642c8: r0 = lerp()
    //     0x11642c8: bl              #0x1163c14  ; [package:flutter/src/rendering/box.dart] BoxConstraints::lerp
    // 0x11642cc: ldur            x3, [fp, #-8]
    // 0x11642d0: r1 = Null
    //     0x11642d0: mov             x1, NULL
    // 0x11642d4: r2 = Null
    //     0x11642d4: mov             x2, NULL
    // 0x11642d8: r0 = lerp()
    //     0x11642d8: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x11642dc: ldur            x3, [fp, #-8]
    // 0x11642e0: r1 = Null
    //     0x11642e0: mov             x1, NULL
    // 0x11642e4: r2 = Null
    //     0x11642e4: mov             x2, NULL
    // 0x11642e8: r0 = lerp()
    //     0x11642e8: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x11642ec: ldur            x3, [fp, #-8]
    // 0x11642f0: r1 = Null
    //     0x11642f0: mov             x1, NULL
    // 0x11642f4: r2 = Null
    //     0x11642f4: mov             x2, NULL
    // 0x11642f8: r0 = lerp()
    //     0x11642f8: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x11642fc: ldur            x3, [fp, #-8]
    // 0x1164300: r1 = Null
    //     0x1164300: mov             x1, NULL
    // 0x1164304: r2 = Null
    //     0x1164304: mov             x2, NULL
    // 0x1164308: r0 = lerp()
    //     0x1164308: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x116430c: ldur            x3, [fp, #-8]
    // 0x1164310: r1 = Null
    //     0x1164310: mov             x1, NULL
    // 0x1164314: r2 = Null
    //     0x1164314: mov             x2, NULL
    // 0x1164318: r0 = lerp()
    //     0x1164318: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x116431c: ldur            x3, [fp, #-8]
    // 0x1164320: r1 = Null
    //     0x1164320: mov             x1, NULL
    // 0x1164324: r2 = Null
    //     0x1164324: mov             x2, NULL
    // 0x1164328: r0 = lerp()
    //     0x1164328: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x116432c: ldur            x3, [fp, #-8]
    // 0x1164330: r1 = Null
    //     0x1164330: mov             x1, NULL
    // 0x1164334: r2 = Null
    //     0x1164334: mov             x2, NULL
    // 0x1164338: r0 = lerp()
    //     0x1164338: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x116433c: ldur            x3, [fp, #-8]
    // 0x1164340: r1 = Null
    //     0x1164340: mov             x1, NULL
    // 0x1164344: r2 = Null
    //     0x1164344: mov             x2, NULL
    // 0x1164348: r0 = lerp()
    //     0x1164348: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x116434c: ldur            x3, [fp, #-8]
    // 0x1164350: r1 = Null
    //     0x1164350: mov             x1, NULL
    // 0x1164354: r2 = Null
    //     0x1164354: mov             x2, NULL
    // 0x1164358: r0 = lerp()
    //     0x1164358: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x116435c: ldur            x3, [fp, #-8]
    // 0x1164360: r1 = Null
    //     0x1164360: mov             x1, NULL
    // 0x1164364: r2 = Null
    //     0x1164364: mov             x2, NULL
    // 0x1164368: r0 = lerp()
    //     0x1164368: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x116436c: ldur            x3, [fp, #-8]
    // 0x1164370: r1 = Null
    //     0x1164370: mov             x1, NULL
    // 0x1164374: r2 = Null
    //     0x1164374: mov             x2, NULL
    // 0x1164378: r0 = lerp()
    //     0x1164378: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x116437c: ldur            d0, [fp, #-0x20]
    // 0x1164380: r1 = Null
    //     0x1164380: mov             x1, NULL
    // 0x1164384: r2 = Null
    //     0x1164384: mov             x2, NULL
    // 0x1164388: r0 = lerp()
    //     0x1164388: bl              #0xbfea10  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::lerp
    // 0x116438c: ldur            x0, [fp, #-0x10]
    // 0x1164390: LoadField: r1 = r0->field_3b
    //     0x1164390: ldur            w1, [x0, #0x3b]
    // 0x1164394: DecompressPointer r1
    //     0x1164394: add             x1, x1, HEAP, lsl #32
    // 0x1164398: ldur            x0, [fp, #-0x18]
    // 0x116439c: LoadField: r2 = r0->field_3b
    //     0x116439c: ldur            w2, [x0, #0x3b]
    // 0x11643a0: DecompressPointer r2
    //     0x11643a0: add             x2, x2, HEAP, lsl #32
    // 0x11643a4: ldur            x3, [fp, #-8]
    // 0x11643a8: r0 = lerpDouble()
    //     0x11643a8: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0x11643ac: stur            x0, [fp, #-8]
    // 0x11643b0: r0 = ToggleButtonsThemeData()
    //     0x11643b0: bl              #0x11643ec  ; AllocateToggleButtonsThemeDataStub -> ToggleButtonsThemeData (size=0x44)
    // 0x11643b4: ldur            x1, [fp, #-8]
    // 0x11643b8: StoreField: r0->field_3b = r1
    //     0x11643b8: stur            w1, [x0, #0x3b]
    // 0x11643bc: LeaveFrame
    //     0x11643bc: mov             SP, fp
    //     0x11643c0: ldp             fp, lr, [SP], #0x10
    // 0x11643c4: ret
    //     0x11643c4: ret             
    // 0x11643c8: r0 = StackOverflowSharedWithFPURegs()
    //     0x11643c8: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x11643cc: b               #0x1164264
    // 0x11643d0: SaveReg d0
    //     0x11643d0: str             q0, [SP, #-0x10]!
    // 0x11643d4: stp             x0, x4, [SP, #-0x10]!
    // 0x11643d8: r0 = AllocateDouble()
    //     0x11643d8: bl              #0x13df878  ; AllocateDoubleStub
    // 0x11643dc: mov             x5, x0
    // 0x11643e0: ldp             x0, x4, [SP], #0x10
    // 0x11643e4: RestoreReg d0
    //     0x11643e4: ldr             q0, [SP], #0x10
    // 0x11643e8: b               #0x11642a4
  }
  _ ==(/* No info */) {
    // ** addr: 0x12784a4, size: 0xfc
    // 0x12784a4: EnterFrame
    //     0x12784a4: stp             fp, lr, [SP, #-0x10]!
    //     0x12784a8: mov             fp, SP
    // 0x12784ac: AllocStack(0x10)
    //     0x12784ac: sub             SP, SP, #0x10
    // 0x12784b0: CheckStackOverflow
    //     0x12784b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12784b4: cmp             SP, x16
    //     0x12784b8: b.ls            #0x1278598
    // 0x12784bc: ldr             x0, [fp, #0x10]
    // 0x12784c0: cmp             w0, NULL
    // 0x12784c4: b.ne            #0x12784d8
    // 0x12784c8: r0 = false
    //     0x12784c8: add             x0, NULL, #0x30  ; false
    // 0x12784cc: LeaveFrame
    //     0x12784cc: mov             SP, fp
    //     0x12784d0: ldp             fp, lr, [SP], #0x10
    // 0x12784d4: ret
    //     0x12784d4: ret             
    // 0x12784d8: ldr             x1, [fp, #0x18]
    // 0x12784dc: cmp             w1, w0
    // 0x12784e0: b.ne            #0x12784f4
    // 0x12784e4: r0 = true
    //     0x12784e4: add             x0, NULL, #0x20  ; true
    // 0x12784e8: LeaveFrame
    //     0x12784e8: mov             SP, fp
    //     0x12784ec: ldp             fp, lr, [SP], #0x10
    // 0x12784f0: ret
    //     0x12784f0: ret             
    // 0x12784f4: str             x0, [SP]
    // 0x12784f8: r0 = runtimeType()
    //     0x12784f8: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x12784fc: r1 = LoadClassIdInstr(r0)
    //     0x12784fc: ldur            x1, [x0, #-1]
    //     0x1278500: ubfx            x1, x1, #0xc, #0x14
    // 0x1278504: r16 = ToggleButtonsThemeData
    //     0x1278504: add             x16, PP, #0x26, lsl #12  ; [pp+0x26098] Type: ToggleButtonsThemeData
    //     0x1278508: ldr             x16, [x16, #0x98]
    // 0x127850c: stp             x16, x0, [SP]
    // 0x1278510: mov             x0, x1
    // 0x1278514: mov             lr, x0
    // 0x1278518: ldr             lr, [x21, lr, lsl #3]
    // 0x127851c: blr             lr
    // 0x1278520: tbz             w0, #4, #0x1278534
    // 0x1278524: r0 = false
    //     0x1278524: add             x0, NULL, #0x30  ; false
    // 0x1278528: LeaveFrame
    //     0x1278528: mov             SP, fp
    //     0x127852c: ldp             fp, lr, [SP], #0x10
    // 0x1278530: ret
    //     0x1278530: ret             
    // 0x1278534: ldr             x0, [fp, #0x10]
    // 0x1278538: r1 = 60
    //     0x1278538: mov             x1, #0x3c
    // 0x127853c: branchIfSmi(r0, 0x1278548)
    //     0x127853c: tbz             w0, #0, #0x1278548
    // 0x1278540: r1 = LoadClassIdInstr(r0)
    //     0x1278540: ldur            x1, [x0, #-1]
    //     0x1278544: ubfx            x1, x1, #0xc, #0x14
    // 0x1278548: r17 = 5051
    //     0x1278548: mov             x17, #0x13bb
    // 0x127854c: cmp             x1, x17
    // 0x1278550: b.ne            #0x1278588
    // 0x1278554: ldr             x1, [fp, #0x18]
    // 0x1278558: LoadField: r2 = r0->field_3b
    //     0x1278558: ldur            w2, [x0, #0x3b]
    // 0x127855c: DecompressPointer r2
    //     0x127855c: add             x2, x2, HEAP, lsl #32
    // 0x1278560: LoadField: r0 = r1->field_3b
    //     0x1278560: ldur            w0, [x1, #0x3b]
    // 0x1278564: DecompressPointer r0
    //     0x1278564: add             x0, x0, HEAP, lsl #32
    // 0x1278568: r1 = LoadClassIdInstr(r2)
    //     0x1278568: ldur            x1, [x2, #-1]
    //     0x127856c: ubfx            x1, x1, #0xc, #0x14
    // 0x1278570: stp             x0, x2, [SP]
    // 0x1278574: mov             x0, x1
    // 0x1278578: mov             lr, x0
    // 0x127857c: ldr             lr, [x21, lr, lsl #3]
    // 0x1278580: blr             lr
    // 0x1278584: b               #0x127858c
    // 0x1278588: r0 = false
    //     0x1278588: add             x0, NULL, #0x30  ; false
    // 0x127858c: LeaveFrame
    //     0x127858c: mov             SP, fp
    //     0x1278590: ldp             fp, lr, [SP], #0x10
    // 0x1278594: ret
    //     0x1278594: ret             
    // 0x1278598: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1278598: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x127859c: b               #0x12784bc
  }
}
