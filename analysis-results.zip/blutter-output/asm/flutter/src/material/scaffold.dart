// lib: , url: package:flutter/src/material/scaffold.dart

// class id: 1048938, size: 0x8
class :: {
}

// class id: 2887, size: 0x40, field offset: 0x28
//   const constructor, 
class _BodyBoxConstraints extends BoxConstraints {

  get _ hashCode(/* No info */) {
    // ** addr: 0x114c2e8, size: 0x154
    // 0x114c2e8: EnterFrame
    //     0x114c2e8: stp             fp, lr, [SP, #-0x10]!
    //     0x114c2ec: mov             fp, SP
    // 0x114c2f0: AllocStack(0x10)
    //     0x114c2f0: sub             SP, SP, #0x10
    // 0x114c2f4: CheckStackOverflow
    //     0x114c2f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x114c2f8: cmp             SP, x16
    //     0x114c2fc: b.ls            #0x114c3d4
    // 0x114c300: ldr             x16, [fp, #0x10]
    // 0x114c304: str             x16, [SP]
    // 0x114c308: r0 = hashCode()
    //     0x114c308: bl              #0x1155d88  ; [package:vector_graphics_compiler/src/geometry/basic_types.dart] Rect::hashCode
    // 0x114c30c: mov             x1, x0
    // 0x114c310: ldr             x0, [fp, #0x10]
    // 0x114c314: LoadField: d0 = r0->field_37
    //     0x114c314: ldur            d0, [x0, #0x37]
    // 0x114c318: LoadField: d1 = r0->field_27
    //     0x114c318: ldur            d1, [x0, #0x27]
    // 0x114c31c: LoadField: d2 = r0->field_2f
    //     0x114c31c: ldur            d2, [x0, #0x2f]
    // 0x114c320: r2 = inline_Allocate_Double()
    //     0x114c320: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0x114c324: add             x2, x2, #0x10
    //     0x114c328: cmp             x0, x2
    //     0x114c32c: b.ls            #0x114c3dc
    //     0x114c330: str             x2, [THR, #0x60]  ; THR::top
    //     0x114c334: sub             x2, x2, #0xf
    //     0x114c338: mov             x0, #0xe19c
    //     0x114c33c: movk            x0, #3, lsl #16
    //     0x114c340: stur            x0, [x2, #-1]
    // 0x114c344: dmb             ishst
    // 0x114c348: StoreField: r2->field_7 = d0
    //     0x114c348: stur            d0, [x2, #7]
    // 0x114c34c: r0 = inline_Allocate_Double()
    //     0x114c34c: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0x114c350: add             x0, x0, #0x10
    //     0x114c354: cmp             x3, x0
    //     0x114c358: b.ls            #0x114c400
    //     0x114c35c: str             x0, [THR, #0x60]  ; THR::top
    //     0x114c360: sub             x0, x0, #0xf
    //     0x114c364: mov             x3, #0xe19c
    //     0x114c368: movk            x3, #3, lsl #16
    //     0x114c36c: stur            x3, [x0, #-1]
    // 0x114c370: dmb             ishst
    // 0x114c374: StoreField: r0->field_7 = d1
    //     0x114c374: stur            d1, [x0, #7]
    // 0x114c378: r3 = inline_Allocate_Double()
    //     0x114c378: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x114c37c: add             x3, x3, #0x10
    //     0x114c380: cmp             x4, x3
    //     0x114c384: b.ls            #0x114c418
    //     0x114c388: str             x3, [THR, #0x60]  ; THR::top
    //     0x114c38c: sub             x3, x3, #0xf
    //     0x114c390: mov             x4, #0xe19c
    //     0x114c394: movk            x4, #3, lsl #16
    //     0x114c398: stur            x4, [x3, #-1]
    // 0x114c39c: dmb             ishst
    // 0x114c3a0: StoreField: r3->field_7 = d2
    //     0x114c3a0: stur            d2, [x3, #7]
    // 0x114c3a4: stp             x3, x0, [SP]
    // 0x114c3a8: r4 = const [0, 0x4, 0x2, 0x4, null]
    //     0x114c3a8: ldr             x4, [PP, #0x1388]  ; [pp+0x1388] List(5) [0, 0x4, 0x2, 0x4, Null]
    // 0x114c3ac: r0 = hash()
    //     0x114c3ac: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x114c3b0: mov             x2, x0
    // 0x114c3b4: r0 = BoxInt64Instr(r2)
    //     0x114c3b4: sbfiz           x0, x2, #1, #0x1f
    //     0x114c3b8: cmp             x2, x0, asr #1
    //     0x114c3bc: b.eq            #0x114c3c8
    //     0x114c3c0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x114c3c4: stur            x2, [x0, #7]
    // 0x114c3c8: LeaveFrame
    //     0x114c3c8: mov             SP, fp
    //     0x114c3cc: ldp             fp, lr, [SP], #0x10
    // 0x114c3d0: ret
    //     0x114c3d0: ret             
    // 0x114c3d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x114c3d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x114c3d8: b               #0x114c300
    // 0x114c3dc: stp             q1, q2, [SP, #-0x20]!
    // 0x114c3e0: SaveReg d0
    //     0x114c3e0: str             q0, [SP, #-0x10]!
    // 0x114c3e4: SaveReg r1
    //     0x114c3e4: str             x1, [SP, #-8]!
    // 0x114c3e8: r0 = AllocateDouble()
    //     0x114c3e8: bl              #0x13df878  ; AllocateDoubleStub
    // 0x114c3ec: mov             x2, x0
    // 0x114c3f0: RestoreReg r1
    //     0x114c3f0: ldr             x1, [SP], #8
    // 0x114c3f4: RestoreReg d0
    //     0x114c3f4: ldr             q0, [SP], #0x10
    // 0x114c3f8: ldp             q1, q2, [SP], #0x20
    // 0x114c3fc: b               #0x114c348
    // 0x114c400: stp             q1, q2, [SP, #-0x20]!
    // 0x114c404: stp             x1, x2, [SP, #-0x10]!
    // 0x114c408: r0 = AllocateDouble()
    //     0x114c408: bl              #0x13df878  ; AllocateDoubleStub
    // 0x114c40c: ldp             x1, x2, [SP], #0x10
    // 0x114c410: ldp             q1, q2, [SP], #0x20
    // 0x114c414: b               #0x114c374
    // 0x114c418: SaveReg d2
    //     0x114c418: str             q2, [SP, #-0x10]!
    // 0x114c41c: stp             x1, x2, [SP, #-0x10]!
    // 0x114c420: SaveReg r0
    //     0x114c420: str             x0, [SP, #-8]!
    // 0x114c424: r0 = AllocateDouble()
    //     0x114c424: bl              #0x13df878  ; AllocateDoubleStub
    // 0x114c428: mov             x3, x0
    // 0x114c42c: RestoreReg r0
    //     0x114c42c: ldr             x0, [SP], #8
    // 0x114c430: ldp             x1, x2, [SP], #0x10
    // 0x114c434: RestoreReg d2
    //     0x114c434: ldr             q2, [SP], #0x10
    // 0x114c438: b               #0x114c3a0
  }
  _ ==(/* No info */) {
    // ** addr: 0x1299a20, size: 0xcc
    // 0x1299a20: EnterFrame
    //     0x1299a20: stp             fp, lr, [SP, #-0x10]!
    //     0x1299a24: mov             fp, SP
    // 0x1299a28: AllocStack(0x10)
    //     0x1299a28: sub             SP, SP, #0x10
    // 0x1299a2c: CheckStackOverflow
    //     0x1299a2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1299a30: cmp             SP, x16
    //     0x1299a34: b.ls            #0x1299ae4
    // 0x1299a38: ldr             x0, [fp, #0x10]
    // 0x1299a3c: cmp             w0, NULL
    // 0x1299a40: b.ne            #0x1299a54
    // 0x1299a44: r0 = false
    //     0x1299a44: add             x0, NULL, #0x30  ; false
    // 0x1299a48: LeaveFrame
    //     0x1299a48: mov             SP, fp
    //     0x1299a4c: ldp             fp, lr, [SP], #0x10
    // 0x1299a50: ret
    //     0x1299a50: ret             
    // 0x1299a54: ldr             x16, [fp, #0x18]
    // 0x1299a58: stp             x0, x16, [SP]
    // 0x1299a5c: r0 = ==()
    //     0x1299a5c: bl              #0x1299aec  ; [package:flutter/src/rendering/box.dart] BoxConstraints::==
    // 0x1299a60: tbz             w0, #4, #0x1299a74
    // 0x1299a64: r0 = false
    //     0x1299a64: add             x0, NULL, #0x30  ; false
    // 0x1299a68: LeaveFrame
    //     0x1299a68: mov             SP, fp
    //     0x1299a6c: ldp             fp, lr, [SP], #0x10
    // 0x1299a70: ret
    //     0x1299a70: ret             
    // 0x1299a74: ldr             x1, [fp, #0x10]
    // 0x1299a78: r2 = 60
    //     0x1299a78: mov             x2, #0x3c
    // 0x1299a7c: branchIfSmi(r1, 0x1299a88)
    //     0x1299a7c: tbz             w1, #0, #0x1299a88
    // 0x1299a80: r2 = LoadClassIdInstr(r1)
    //     0x1299a80: ldur            x2, [x1, #-1]
    //     0x1299a84: ubfx            x2, x2, #0xc, #0x14
    // 0x1299a88: cmp             x2, #0xb47
    // 0x1299a8c: b.ne            #0x1299ad4
    // 0x1299a90: ldr             x2, [fp, #0x18]
    // 0x1299a94: LoadField: d0 = r1->field_37
    //     0x1299a94: ldur            d0, [x1, #0x37]
    // 0x1299a98: LoadField: d1 = r2->field_37
    //     0x1299a98: ldur            d1, [x2, #0x37]
    // 0x1299a9c: fcmp            d0, d1
    // 0x1299aa0: b.ne            #0x1299ad4
    // 0x1299aa4: LoadField: d0 = r1->field_27
    //     0x1299aa4: ldur            d0, [x1, #0x27]
    // 0x1299aa8: LoadField: d1 = r2->field_27
    //     0x1299aa8: ldur            d1, [x2, #0x27]
    // 0x1299aac: fcmp            d0, d1
    // 0x1299ab0: b.ne            #0x1299ad4
    // 0x1299ab4: LoadField: d0 = r1->field_2f
    //     0x1299ab4: ldur            d0, [x1, #0x2f]
    // 0x1299ab8: LoadField: d1 = r2->field_2f
    //     0x1299ab8: ldur            d1, [x2, #0x2f]
    // 0x1299abc: fcmp            d0, d1
    // 0x1299ac0: r16 = true
    //     0x1299ac0: add             x16, NULL, #0x20  ; true
    // 0x1299ac4: r17 = false
    //     0x1299ac4: add             x17, NULL, #0x30  ; false
    // 0x1299ac8: csel            x1, x16, x17, eq
    // 0x1299acc: mov             x0, x1
    // 0x1299ad0: b               #0x1299ad8
    // 0x1299ad4: r0 = false
    //     0x1299ad4: add             x0, NULL, #0x30  ; false
    // 0x1299ad8: LeaveFrame
    //     0x1299ad8: mov             SP, fp
    //     0x1299adc: ldp             fp, lr, [SP], #0x10
    // 0x1299ae0: ret
    //     0x1299ae0: ret             
    // 0x1299ae4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1299ae4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1299ae8: b               #0x1299a38
  }
}

// class id: 2989, size: 0x18, field offset: 0x8
//   const constructor, 
class ScaffoldFeatureController<X0 bound Widget, X1> extends Object {
}

// class id: 2990, size: 0x1c, field offset: 0x18
//   const constructor, 
class PersistentBottomSheetController extends ScaffoldFeatureController<dynamic, dynamic> {
}

// class id: 2993, size: 0x44, field offset: 0x10
class _ScaffoldLayout extends MultiChildLayoutDelegate {

  _ _ScaffoldLayout(/* No info */) {
    // ** addr: 0xd3725c, size: 0x15c
    // 0xd3725c: EnterFrame
    //     0xd3725c: stp             fp, lr, [SP, #-0x10]!
    //     0xd37260: mov             fp, SP
    // 0xd37264: r9 = Instance__EndFloatFabLocation
    //     0xd37264: add             x9, PP, #0x84, lsl #12  ; [pp+0x84b88] Obj!_EndFloatFabLocation@129ecf1
    //     0xd37268: ldr             x9, [x9, #0xb88]
    // 0xd3726c: r8 = Instance__ScalingFabMotionAnimator
    //     0xd3726c: add             x8, PP, #0x84, lsl #12  ; [pp+0x84b18] Obj!_ScalingFabMotionAnimator@129ece1
    //     0xd37270: ldr             x8, [x8, #0xb18]
    // 0xd37274: r4 = false
    //     0xd37274: add             x4, NULL, #0x30  ; false
    // 0xd37278: mov             x0, x7
    // 0xd3727c: mov             x16, x5
    // 0xd37280: mov             x5, x1
    // 0xd37284: mov             x1, x16
    // 0xd37288: mov             x16, x3
    // 0xd3728c: mov             x3, x2
    // 0xd37290: mov             x2, x16
    // 0xd37294: ArrayStore: r5[0] = r0  ; List_4
    //     0xd37294: stur            w0, [x5, #0x17]
    //     0xd37298: ldurb           w16, [x5, #-1]
    //     0xd3729c: ldurb           w17, [x0, #-1]
    //     0xd372a0: and             x16, x17, x16, lsr #2
    //     0xd372a4: tst             x16, HEAP, lsr #32
    //     0xd372a8: b.eq            #0xd372b0
    //     0xd372ac: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0xd372b0: ldr             x0, [fp, #0x28]
    // 0xd372b4: StoreField: r5->field_1b = r0
    //     0xd372b4: stur            w0, [x5, #0x1b]
    //     0xd372b8: ldurb           w16, [x5, #-1]
    //     0xd372bc: ldurb           w17, [x0, #-1]
    //     0xd372c0: and             x16, x17, x16, lsr #2
    //     0xd372c4: tst             x16, HEAP, lsr #32
    //     0xd372c8: b.eq            #0xd372d0
    //     0xd372cc: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0xd372d0: ldr             x0, [fp, #0x10]
    // 0xd372d4: StoreField: r5->field_1f = r0
    //     0xd372d4: stur            w0, [x5, #0x1f]
    //     0xd372d8: ldurb           w16, [x5, #-1]
    //     0xd372dc: ldurb           w17, [x0, #-1]
    //     0xd372e0: and             x16, x17, x16, lsr #2
    //     0xd372e4: tst             x16, HEAP, lsr #32
    //     0xd372e8: b.eq            #0xd372f0
    //     0xd372ec: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0xd372f0: mov             x0, x1
    // 0xd372f4: StoreField: r5->field_23 = r0
    //     0xd372f4: stur            w0, [x5, #0x23]
    //     0xd372f8: ldurb           w16, [x5, #-1]
    //     0xd372fc: ldurb           w17, [x0, #-1]
    //     0xd37300: and             x16, x17, x16, lsr #2
    //     0xd37304: tst             x16, HEAP, lsr #32
    //     0xd37308: b.eq            #0xd37310
    //     0xd3730c: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0xd37310: ldr             x0, [fp, #0x20]
    // 0xd37314: StoreField: r5->field_27 = r0
    //     0xd37314: stur            w0, [x5, #0x27]
    //     0xd37318: ldurb           w16, [x5, #-1]
    //     0xd3731c: ldurb           w17, [x0, #-1]
    //     0xd37320: and             x16, x17, x16, lsr #2
    //     0xd37324: tst             x16, HEAP, lsr #32
    //     0xd37328: b.eq            #0xd37330
    //     0xd3732c: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0xd37330: StoreField: r5->field_2b = r9
    //     0xd37330: stur            w9, [x5, #0x2b]
    // 0xd37334: mov             x0, x2
    // 0xd37338: StoreField: r5->field_2f = r0
    //     0xd37338: stur            w0, [x5, #0x2f]
    //     0xd3733c: ldurb           w16, [x5, #-1]
    //     0xd37340: ldurb           w17, [x0, #-1]
    //     0xd37344: and             x16, x17, x16, lsr #2
    //     0xd37348: tst             x16, HEAP, lsr #32
    //     0xd3734c: b.eq            #0xd37354
    //     0xd37350: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0xd37354: StoreField: r5->field_33 = r8
    //     0xd37354: stur            w8, [x5, #0x33]
    // 0xd37358: StoreField: r5->field_37 = r6
    //     0xd37358: stur            w6, [x5, #0x37]
    // 0xd3735c: ldr             x0, [fp, #0x18]
    // 0xd37360: StoreField: r5->field_3b = r0
    //     0xd37360: stur            w0, [x5, #0x3b]
    //     0xd37364: ldurb           w16, [x5, #-1]
    //     0xd37368: ldurb           w17, [x0, #-1]
    //     0xd3736c: and             x16, x17, x16, lsr #2
    //     0xd37370: tst             x16, HEAP, lsr #32
    //     0xd37374: b.eq            #0xd3737c
    //     0xd37378: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0xd3737c: StoreField: r5->field_f = r4
    //     0xd3737c: stur            w4, [x5, #0xf]
    // 0xd37380: StoreField: r5->field_13 = r4
    //     0xd37380: stur            w4, [x5, #0x13]
    // 0xd37384: StoreField: r5->field_3f = r3
    //     0xd37384: stur            w3, [x5, #0x3f]
    // 0xd37388: mov             x0, x2
    // 0xd3738c: StoreField: r5->field_7 = r0
    //     0xd3738c: stur            w0, [x5, #7]
    //     0xd37390: ldurb           w16, [x5, #-1]
    //     0xd37394: ldurb           w17, [x0, #-1]
    //     0xd37398: and             x16, x17, x16, lsr #2
    //     0xd3739c: tst             x16, HEAP, lsr #32
    //     0xd373a0: b.eq            #0xd373a8
    //     0xd373a4: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0xd373a8: r0 = Null
    //     0xd373a8: mov             x0, NULL
    // 0xd373ac: LeaveFrame
    //     0xd373ac: mov             SP, fp
    //     0xd373b0: ldp             fp, lr, [SP], #0x10
    // 0xd373b4: ret
    //     0xd373b4: ret             
  }
  _ performLayout(/* No info */) {
    // ** addr: 0x12f970c, size: 0xad0
    // 0x12f970c: EnterFrame
    //     0x12f970c: stp             fp, lr, [SP, #-0x10]!
    //     0x12f9710: mov             fp, SP
    // 0x12f9714: AllocStack(0xb0)
    //     0x12f9714: sub             SP, SP, #0xb0
    // 0x12f9718: SetupParameters(_ScaffoldLayout this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x12f9718: stur            x1, [fp, #-8]
    //     0x12f971c: stur            x2, [fp, #-0x10]
    // 0x12f9720: CheckStackOverflow
    //     0x12f9720: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f9724: cmp             SP, x16
    //     0x12f9728: b.ls            #0x12fa18c
    // 0x12f972c: r0 = BoxConstraints()
    //     0x12f972c: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x12f9730: stur            x0, [fp, #-0x18]
    // 0x12f9734: StoreField: r0->field_7 = rZR
    //     0x12f9734: stur            xzr, [x0, #7]
    // 0x12f9738: ldur            x2, [fp, #-0x10]
    // 0x12f973c: LoadField: d0 = r2->field_7
    //     0x12f973c: ldur            d0, [x2, #7]
    // 0x12f9740: stur            d0, [fp, #-0x70]
    // 0x12f9744: StoreField: r0->field_f = d0
    //     0x12f9744: stur            d0, [x0, #0xf]
    // 0x12f9748: ArrayStore: r0[0] = rZR  ; List_8
    //     0x12f9748: stur            xzr, [x0, #0x17]
    // 0x12f974c: LoadField: d1 = r2->field_f
    //     0x12f974c: ldur            d1, [x2, #0xf]
    // 0x12f9750: stur            d1, [fp, #-0x68]
    // 0x12f9754: StoreField: r0->field_1f = d1
    //     0x12f9754: stur            d1, [x0, #0x1f]
    // 0x12f9758: r1 = inline_Allocate_Double()
    //     0x12f9758: ldp             x1, x3, [THR, #0x60]  ; THR::top
    //     0x12f975c: add             x1, x1, #0x10
    //     0x12f9760: cmp             x3, x1
    //     0x12f9764: b.ls            #0x12fa194
    //     0x12f9768: str             x1, [THR, #0x60]  ; THR::top
    //     0x12f976c: sub             x1, x1, #0xf
    //     0x12f9770: mov             x3, #0xe19c
    //     0x12f9774: movk            x3, #3, lsl #16
    //     0x12f9778: stur            x3, [x1, #-1]
    // 0x12f977c: dmb             ishst
    // 0x12f9780: StoreField: r1->field_7 = d0
    //     0x12f9780: stur            d0, [x1, #7]
    // 0x12f9784: str             x1, [SP]
    // 0x12f9788: mov             x1, x0
    // 0x12f978c: r4 = const [0, 0x2, 0x1, 0x1, width, 0x1, null]
    //     0x12f978c: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1f198] List(7) [0, 0x2, 0x1, 0x1, "width", 0x1, Null]
    //     0x12f9790: ldr             x4, [x4, #0x198]
    // 0x12f9794: r0 = tighten()
    //     0x12f9794: bl              #0xb4aa24  ; [package:flutter/src/rendering/box.dart] BoxConstraints::tighten
    // 0x12f9798: ldur            x1, [fp, #-8]
    // 0x12f979c: r2 = Instance__ScaffoldSlot
    //     0x12f979c: add             x2, PP, #0x84, lsl #12  ; [pp+0x84ad8] Obj!_ScaffoldSlot@12c5061
    //     0x12f97a0: ldr             x2, [x2, #0xad8]
    // 0x12f97a4: stur            x0, [fp, #-0x20]
    // 0x12f97a8: r0 = hasChild()
    //     0x12f97a8: bl              #0x12fa3ac  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::hasChild
    // 0x12f97ac: tbnz            w0, #4, #0x12f97ec
    // 0x12f97b0: ldur            x1, [fp, #-8]
    // 0x12f97b4: ldur            x3, [fp, #-0x20]
    // 0x12f97b8: r2 = Instance__ScaffoldSlot
    //     0x12f97b8: add             x2, PP, #0x84, lsl #12  ; [pp+0x84ad8] Obj!_ScaffoldSlot@12c5061
    //     0x12f97bc: ldr             x2, [x2, #0xad8]
    // 0x12f97c0: r0 = layoutChild()
    //     0x12f97c0: bl              #0x12fa2ec  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::layoutChild
    // 0x12f97c4: LoadField: d0 = r0->field_f
    //     0x12f97c4: ldur            d0, [x0, #0xf]
    // 0x12f97c8: ldur            x1, [fp, #-8]
    // 0x12f97cc: stur            d0, [fp, #-0x78]
    // 0x12f97d0: r2 = Instance__ScaffoldSlot
    //     0x12f97d0: add             x2, PP, #0x84, lsl #12  ; [pp+0x84ad8] Obj!_ScaffoldSlot@12c5061
    //     0x12f97d4: ldr             x2, [x2, #0xad8]
    // 0x12f97d8: r3 = Instance_Offset
    //     0x12f97d8: ldr             x3, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x12f97dc: r0 = positionChild()
    //     0x12f97dc: bl              #0x12fa1f4  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::positionChild
    // 0x12f97e0: ldur            d1, [fp, #-0x78]
    // 0x12f97e4: ldur            d0, [fp, #-0x78]
    // 0x12f97e8: b               #0x12f97f4
    // 0x12f97ec: d1 = 0.000000
    //     0x12f97ec: eor             v1.16b, v1.16b, v1.16b
    // 0x12f97f0: d0 = 0.000000
    //     0x12f97f0: eor             v0.16b, v0.16b, v0.16b
    // 0x12f97f4: ldur            x1, [fp, #-8]
    // 0x12f97f8: stur            d1, [fp, #-0x78]
    // 0x12f97fc: stur            d0, [fp, #-0x80]
    // 0x12f9800: r2 = Instance__ScaffoldSlot
    //     0x12f9800: add             x2, PP, #0x84, lsl #12  ; [pp+0x84b10] Obj!_ScaffoldSlot@12c4fe1
    //     0x12f9804: ldr             x2, [x2, #0xb10]
    // 0x12f9808: r0 = hasChild()
    //     0x12f9808: bl              #0x12fa3ac  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::hasChild
    // 0x12f980c: tbnz            w0, #4, #0x12f98a4
    // 0x12f9810: ldur            d0, [fp, #-0x68]
    // 0x12f9814: ldur            x1, [fp, #-8]
    // 0x12f9818: ldur            x3, [fp, #-0x20]
    // 0x12f981c: r2 = Instance__ScaffoldSlot
    //     0x12f981c: add             x2, PP, #0x84, lsl #12  ; [pp+0x84b10] Obj!_ScaffoldSlot@12c4fe1
    //     0x12f9820: ldr             x2, [x2, #0xb10]
    // 0x12f9824: r0 = layoutChild()
    //     0x12f9824: bl              #0x12fa2ec  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::layoutChild
    // 0x12f9828: LoadField: d0 = r0->field_f
    //     0x12f9828: ldur            d0, [x0, #0xf]
    // 0x12f982c: d1 = 0.000000
    //     0x12f982c: eor             v1.16b, v1.16b, v1.16b
    // 0x12f9830: fadd            d2, d0, d1
    // 0x12f9834: ldur            d0, [fp, #-0x68]
    // 0x12f9838: stur            d2, [fp, #-0x90]
    // 0x12f983c: fsub            d3, d0, d2
    // 0x12f9840: fmax            v4.2d, v1.2d, v3.2d
    // 0x12f9844: stur            d4, [fp, #-0x88]
    // 0x12f9848: r0 = Offset()
    //     0x12f9848: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x12f984c: StoreField: r0->field_7 = rZR
    //     0x12f984c: stur            xzr, [x0, #7]
    // 0x12f9850: ldur            d0, [fp, #-0x88]
    // 0x12f9854: StoreField: r0->field_f = d0
    //     0x12f9854: stur            d0, [x0, #0xf]
    // 0x12f9858: ldur            x1, [fp, #-8]
    // 0x12f985c: mov             x3, x0
    // 0x12f9860: r2 = Instance__ScaffoldSlot
    //     0x12f9860: add             x2, PP, #0x84, lsl #12  ; [pp+0x84b10] Obj!_ScaffoldSlot@12c4fe1
    //     0x12f9864: ldr             x2, [x2, #0xb10]
    // 0x12f9868: r0 = positionChild()
    //     0x12f9868: bl              #0x12fa1f4  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::positionChild
    // 0x12f986c: ldur            d0, [fp, #-0x88]
    // 0x12f9870: r0 = inline_Allocate_Double()
    //     0x12f9870: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x12f9874: add             x0, x0, #0x10
    //     0x12f9878: cmp             x1, x0
    //     0x12f987c: b.ls            #0x12fa1b0
    //     0x12f9880: str             x0, [THR, #0x60]  ; THR::top
    //     0x12f9884: sub             x0, x0, #0xf
    //     0x12f9888: mov             x1, #0xe19c
    //     0x12f988c: movk            x1, #3, lsl #16
    //     0x12f9890: stur            x1, [x0, #-1]
    // 0x12f9894: dmb             ishst
    // 0x12f9898: StoreField: r0->field_7 = d0
    //     0x12f9898: stur            d0, [x0, #7]
    // 0x12f989c: ldur            d0, [fp, #-0x90]
    // 0x12f98a0: b               #0x12f98ac
    // 0x12f98a4: d0 = 0.000000
    //     0x12f98a4: eor             v0.16b, v0.16b, v0.16b
    // 0x12f98a8: r0 = Null
    //     0x12f98a8: mov             x0, NULL
    // 0x12f98ac: ldur            x1, [fp, #-8]
    // 0x12f98b0: stur            x0, [fp, #-0x28]
    // 0x12f98b4: stur            d0, [fp, #-0x88]
    // 0x12f98b8: r2 = Instance__ScaffoldSlot
    //     0x12f98b8: add             x2, PP, #0xa3, lsl #12  ; [pp+0xa3cf8] Obj!_ScaffoldSlot@12c50e1
    //     0x12f98bc: ldr             x2, [x2, #0xcf8]
    // 0x12f98c0: r0 = hasChild()
    //     0x12f98c0: bl              #0x12fa3ac  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::hasChild
    // 0x12f98c4: tbnz            w0, #4, #0x12f9974
    // 0x12f98c8: ldur            x3, [fp, #-0x20]
    // 0x12f98cc: ldur            d3, [fp, #-0x78]
    // 0x12f98d0: ldur            d0, [fp, #-0x88]
    // 0x12f98d4: ldur            d2, [fp, #-0x68]
    // 0x12f98d8: d1 = 0.000000
    //     0x12f98d8: eor             v1.16b, v1.16b, v1.16b
    // 0x12f98dc: LoadField: d4 = r3->field_f
    //     0x12f98dc: ldur            d4, [x3, #0xf]
    // 0x12f98e0: stur            d4, [fp, #-0x98]
    // 0x12f98e4: fsub            d5, d2, d0
    // 0x12f98e8: fsub            d6, d5, d3
    // 0x12f98ec: fmax            v5.2d, v1.2d, v6.2d
    // 0x12f98f0: stur            d5, [fp, #-0x90]
    // 0x12f98f4: r0 = BoxConstraints()
    //     0x12f98f4: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x12f98f8: StoreField: r0->field_7 = rZR
    //     0x12f98f8: stur            xzr, [x0, #7]
    // 0x12f98fc: ldur            d0, [fp, #-0x98]
    // 0x12f9900: StoreField: r0->field_f = d0
    //     0x12f9900: stur            d0, [x0, #0xf]
    // 0x12f9904: ArrayStore: r0[0] = rZR  ; List_8
    //     0x12f9904: stur            xzr, [x0, #0x17]
    // 0x12f9908: ldur            d0, [fp, #-0x90]
    // 0x12f990c: StoreField: r0->field_1f = d0
    //     0x12f990c: stur            d0, [x0, #0x1f]
    // 0x12f9910: ldur            x1, [fp, #-8]
    // 0x12f9914: mov             x3, x0
    // 0x12f9918: r2 = Instance__ScaffoldSlot
    //     0x12f9918: add             x2, PP, #0xa3, lsl #12  ; [pp+0xa3cf8] Obj!_ScaffoldSlot@12c50e1
    //     0x12f991c: ldr             x2, [x2, #0xcf8]
    // 0x12f9920: r0 = layoutChild()
    //     0x12f9920: bl              #0x12fa2ec  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::layoutChild
    // 0x12f9924: LoadField: d0 = r0->field_f
    //     0x12f9924: ldur            d0, [x0, #0xf]
    // 0x12f9928: ldur            d1, [fp, #-0x88]
    // 0x12f992c: fadd            d2, d1, d0
    // 0x12f9930: ldur            d0, [fp, #-0x68]
    // 0x12f9934: stur            d2, [fp, #-0x98]
    // 0x12f9938: fsub            d1, d0, d2
    // 0x12f993c: d3 = 0.000000
    //     0x12f993c: eor             v3.16b, v3.16b, v3.16b
    // 0x12f9940: fmax            v4.2d, v3.2d, v1.2d
    // 0x12f9944: stur            d4, [fp, #-0x90]
    // 0x12f9948: r0 = Offset()
    //     0x12f9948: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x12f994c: StoreField: r0->field_7 = rZR
    //     0x12f994c: stur            xzr, [x0, #7]
    // 0x12f9950: ldur            d0, [fp, #-0x90]
    // 0x12f9954: StoreField: r0->field_f = d0
    //     0x12f9954: stur            d0, [x0, #0xf]
    // 0x12f9958: ldur            x1, [fp, #-8]
    // 0x12f995c: mov             x3, x0
    // 0x12f9960: r2 = Instance__ScaffoldSlot
    //     0x12f9960: add             x2, PP, #0xa3, lsl #12  ; [pp+0xa3cf8] Obj!_ScaffoldSlot@12c50e1
    //     0x12f9964: ldr             x2, [x2, #0xcf8]
    // 0x12f9968: r0 = positionChild()
    //     0x12f9968: bl              #0x12fa1f4  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::positionChild
    // 0x12f996c: ldur            d0, [fp, #-0x98]
    // 0x12f9970: b               #0x12f997c
    // 0x12f9974: ldur            d1, [fp, #-0x88]
    // 0x12f9978: mov             v0.16b, v1.16b
    // 0x12f997c: ldur            x1, [fp, #-8]
    // 0x12f9980: stur            d0, [fp, #-0x88]
    // 0x12f9984: r2 = Instance__ScaffoldSlot
    //     0x12f9984: add             x2, PP, #0x84, lsl #12  ; [pp+0x84b08] Obj!_ScaffoldSlot@12c5001
    //     0x12f9988: ldr             x2, [x2, #0xb08]
    // 0x12f998c: r0 = hasChild()
    //     0x12f998c: bl              #0x12fa3ac  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::hasChild
    // 0x12f9990: tbnz            w0, #4, #0x12f9a14
    // 0x12f9994: ldur            x0, [fp, #-8]
    // 0x12f9998: ldur            d0, [fp, #-0x80]
    // 0x12f999c: mov             x1, x0
    // 0x12f99a0: ldur            x3, [fp, #-0x20]
    // 0x12f99a4: r2 = Instance__ScaffoldSlot
    //     0x12f99a4: add             x2, PP, #0x84, lsl #12  ; [pp+0x84b08] Obj!_ScaffoldSlot@12c5001
    //     0x12f99a8: ldr             x2, [x2, #0xb08]
    // 0x12f99ac: r0 = layoutChild()
    //     0x12f99ac: bl              #0x12fa2ec  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::layoutChild
    // 0x12f99b0: stur            x0, [fp, #-0x30]
    // 0x12f99b4: r0 = Offset()
    //     0x12f99b4: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x12f99b8: StoreField: r0->field_7 = rZR
    //     0x12f99b8: stur            xzr, [x0, #7]
    // 0x12f99bc: ldur            d0, [fp, #-0x80]
    // 0x12f99c0: StoreField: r0->field_f = d0
    //     0x12f99c0: stur            d0, [x0, #0xf]
    // 0x12f99c4: ldur            x1, [fp, #-8]
    // 0x12f99c8: mov             x3, x0
    // 0x12f99cc: r2 = Instance__ScaffoldSlot
    //     0x12f99cc: add             x2, PP, #0x84, lsl #12  ; [pp+0x84b08] Obj!_ScaffoldSlot@12c5001
    //     0x12f99d0: ldr             x2, [x2, #0xb08]
    // 0x12f99d4: r0 = positionChild()
    //     0x12f99d4: bl              #0x12fa1f4  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::positionChild
    // 0x12f99d8: ldur            x0, [fp, #-8]
    // 0x12f99dc: LoadField: r1 = r0->field_3f
    //     0x12f99dc: ldur            w1, [x0, #0x3f]
    // 0x12f99e0: DecompressPointer r1
    //     0x12f99e0: add             x1, x1, HEAP, lsl #32
    // 0x12f99e4: tbz             w1, #4, #0x12f9a00
    // 0x12f99e8: ldur            d0, [fp, #-0x78]
    // 0x12f99ec: ldur            x1, [fp, #-0x30]
    // 0x12f99f0: LoadField: d1 = r1->field_f
    //     0x12f99f0: ldur            d1, [x1, #0xf]
    // 0x12f99f4: fadd            d2, d0, d1
    // 0x12f99f8: mov             v0.16b, v2.16b
    // 0x12f99fc: b               #0x12f9a08
    // 0x12f9a00: ldur            d0, [fp, #-0x78]
    // 0x12f9a04: ldur            x1, [fp, #-0x30]
    // 0x12f9a08: mov             v3.16b, v0.16b
    // 0x12f9a0c: mov             x3, x1
    // 0x12f9a10: b               #0x12f9a24
    // 0x12f9a14: ldur            x0, [fp, #-8]
    // 0x12f9a18: ldur            d0, [fp, #-0x78]
    // 0x12f9a1c: mov             v3.16b, v0.16b
    // 0x12f9a20: r3 = Instance_Size
    //     0x12f9a20: ldr             x3, [PP, #0x7f28]  ; [pp+0x7f28] Obj!Size@12a74d1
    // 0x12f9a24: ldur            d0, [fp, #-0x88]
    // 0x12f9a28: ldur            d1, [fp, #-0x68]
    // 0x12f9a2c: d2 = 0.000000
    //     0x12f9a2c: eor             v2.16b, v2.16b, v2.16b
    // 0x12f9a30: stur            x3, [fp, #-0x38]
    // 0x12f9a34: stur            d3, [fp, #-0x90]
    // 0x12f9a38: ArrayLoad: r4 = r0[0]  ; List_4
    //     0x12f9a38: ldur            w4, [x0, #0x17]
    // 0x12f9a3c: DecompressPointer r4
    //     0x12f9a3c: add             x4, x4, HEAP, lsl #32
    // 0x12f9a40: stur            x4, [fp, #-0x30]
    // 0x12f9a44: LoadField: d4 = r4->field_1f
    //     0x12f9a44: ldur            d4, [x4, #0x1f]
    // 0x12f9a48: fmax            v5.2d, v4.2d, v0.2d
    // 0x12f9a4c: fsub            d0, d1, d5
    // 0x12f9a50: fmax            v4.2d, v2.2d, v0.2d
    // 0x12f9a54: mov             x1, x0
    // 0x12f9a58: stur            d4, [fp, #-0x78]
    // 0x12f9a5c: r2 = Instance__ScaffoldSlot
    //     0x12f9a5c: add             x2, PP, #0x84, lsl #12  ; [pp+0x84ac0] Obj!_ScaffoldSlot@12c50a1
    //     0x12f9a60: ldr             x2, [x2, #0xac0]
    // 0x12f9a64: r0 = hasChild()
    //     0x12f9a64: bl              #0x12fa3ac  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::hasChild
    // 0x12f9a68: tbnz            w0, #4, #0x12f9b08
    // 0x12f9a6c: ldur            x3, [fp, #-0x20]
    // 0x12f9a70: ldur            d3, [fp, #-0x80]
    // 0x12f9a74: ldur            d1, [fp, #-0x90]
    // 0x12f9a78: ldur            x0, [fp, #-0x38]
    // 0x12f9a7c: ldur            d2, [fp, #-0x78]
    // 0x12f9a80: d0 = 0.000000
    //     0x12f9a80: eor             v0.16b, v0.16b, v0.16b
    // 0x12f9a84: fsub            d4, d2, d1
    // 0x12f9a88: fmax            v5.2d, v0.2d, v4.2d
    // 0x12f9a8c: stur            d5, [fp, #-0xa0]
    // 0x12f9a90: LoadField: d4 = r3->field_f
    //     0x12f9a90: ldur            d4, [x3, #0xf]
    // 0x12f9a94: stur            d4, [fp, #-0x98]
    // 0x12f9a98: LoadField: d6 = r0->field_f
    //     0x12f9a98: ldur            d6, [x0, #0xf]
    // 0x12f9a9c: stur            d6, [fp, #-0x88]
    // 0x12f9aa0: r0 = _BodyBoxConstraints()
    //     0x12f9aa0: bl              #0x12fa1e8  ; Allocate_BodyBoxConstraintsStub -> _BodyBoxConstraints (size=0x40)
    // 0x12f9aa4: StoreField: r0->field_27 = rZR
    //     0x12f9aa4: stur            xzr, [x0, #0x27]
    // 0x12f9aa8: ldur            d0, [fp, #-0x80]
    // 0x12f9aac: StoreField: r0->field_2f = d0
    //     0x12f9aac: stur            d0, [x0, #0x2f]
    // 0x12f9ab0: ldur            d0, [fp, #-0x88]
    // 0x12f9ab4: StoreField: r0->field_37 = d0
    //     0x12f9ab4: stur            d0, [x0, #0x37]
    // 0x12f9ab8: StoreField: r0->field_7 = rZR
    //     0x12f9ab8: stur            xzr, [x0, #7]
    // 0x12f9abc: ldur            d0, [fp, #-0x98]
    // 0x12f9ac0: StoreField: r0->field_f = d0
    //     0x12f9ac0: stur            d0, [x0, #0xf]
    // 0x12f9ac4: ArrayStore: r0[0] = rZR  ; List_8
    //     0x12f9ac4: stur            xzr, [x0, #0x17]
    // 0x12f9ac8: ldur            d0, [fp, #-0xa0]
    // 0x12f9acc: StoreField: r0->field_1f = d0
    //     0x12f9acc: stur            d0, [x0, #0x1f]
    // 0x12f9ad0: ldur            x1, [fp, #-8]
    // 0x12f9ad4: mov             x3, x0
    // 0x12f9ad8: r2 = Instance__ScaffoldSlot
    //     0x12f9ad8: add             x2, PP, #0x84, lsl #12  ; [pp+0x84ac0] Obj!_ScaffoldSlot@12c50a1
    //     0x12f9adc: ldr             x2, [x2, #0xac0]
    // 0x12f9ae0: r0 = layoutChild()
    //     0x12f9ae0: bl              #0x12fa2ec  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::layoutChild
    // 0x12f9ae4: r0 = Offset()
    //     0x12f9ae4: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x12f9ae8: StoreField: r0->field_7 = rZR
    //     0x12f9ae8: stur            xzr, [x0, #7]
    // 0x12f9aec: ldur            d0, [fp, #-0x90]
    // 0x12f9af0: StoreField: r0->field_f = d0
    //     0x12f9af0: stur            d0, [x0, #0xf]
    // 0x12f9af4: ldur            x1, [fp, #-8]
    // 0x12f9af8: mov             x3, x0
    // 0x12f9afc: r2 = Instance__ScaffoldSlot
    //     0x12f9afc: add             x2, PP, #0x84, lsl #12  ; [pp+0x84ac0] Obj!_ScaffoldSlot@12c50a1
    //     0x12f9b00: ldr             x2, [x2, #0xac0]
    // 0x12f9b04: r0 = positionChild()
    //     0x12f9b04: bl              #0x12fa1f4  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::positionChild
    // 0x12f9b08: ldur            x1, [fp, #-8]
    // 0x12f9b0c: r2 = Instance__ScaffoldSlot
    //     0x12f9b0c: add             x2, PP, #0x84, lsl #12  ; [pp+0x84ad0] Obj!_ScaffoldSlot@12c5081
    //     0x12f9b10: ldr             x2, [x2, #0xad0]
    // 0x12f9b14: r0 = hasChild()
    //     0x12f9b14: bl              #0x12fa3ac  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::hasChild
    // 0x12f9b18: tbnz            w0, #4, #0x12f9b70
    // 0x12f9b1c: ldur            x3, [fp, #-0x20]
    // 0x12f9b20: ldur            d0, [fp, #-0x78]
    // 0x12f9b24: LoadField: d1 = r3->field_f
    //     0x12f9b24: ldur            d1, [x3, #0xf]
    // 0x12f9b28: stur            d1, [fp, #-0x80]
    // 0x12f9b2c: r0 = BoxConstraints()
    //     0x12f9b2c: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x12f9b30: StoreField: r0->field_7 = rZR
    //     0x12f9b30: stur            xzr, [x0, #7]
    // 0x12f9b34: ldur            d0, [fp, #-0x80]
    // 0x12f9b38: StoreField: r0->field_f = d0
    //     0x12f9b38: stur            d0, [x0, #0xf]
    // 0x12f9b3c: ArrayStore: r0[0] = rZR  ; List_8
    //     0x12f9b3c: stur            xzr, [x0, #0x17]
    // 0x12f9b40: ldur            d0, [fp, #-0x78]
    // 0x12f9b44: StoreField: r0->field_1f = d0
    //     0x12f9b44: stur            d0, [x0, #0x1f]
    // 0x12f9b48: ldur            x1, [fp, #-8]
    // 0x12f9b4c: mov             x3, x0
    // 0x12f9b50: r2 = Instance__ScaffoldSlot
    //     0x12f9b50: add             x2, PP, #0x84, lsl #12  ; [pp+0x84ad0] Obj!_ScaffoldSlot@12c5081
    //     0x12f9b54: ldr             x2, [x2, #0xad0]
    // 0x12f9b58: r0 = layoutChild()
    //     0x12f9b58: bl              #0x12fa2ec  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::layoutChild
    // 0x12f9b5c: ldur            x1, [fp, #-8]
    // 0x12f9b60: r2 = Instance__ScaffoldSlot
    //     0x12f9b60: add             x2, PP, #0x84, lsl #12  ; [pp+0x84ad0] Obj!_ScaffoldSlot@12c5081
    //     0x12f9b64: ldr             x2, [x2, #0xad0]
    // 0x12f9b68: r3 = Instance_Offset
    //     0x12f9b68: ldr             x3, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x12f9b6c: r0 = positionChild()
    //     0x12f9b6c: bl              #0x12fa1f4  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::positionChild
    // 0x12f9b70: ldur            x1, [fp, #-8]
    // 0x12f9b74: r2 = Instance__ScaffoldSlot
    //     0x12f9b74: add             x2, PP, #0x84, lsl #12  ; [pp+0x84ae8] Obj!_ScaffoldSlot@12c5021
    //     0x12f9b78: ldr             x2, [x2, #0xae8]
    // 0x12f9b7c: r0 = hasChild()
    //     0x12f9b7c: bl              #0x12fa3ac  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::hasChild
    // 0x12f9b80: tbnz            w0, #4, #0x12f9bac
    // 0x12f9b84: ldur            x0, [fp, #-8]
    // 0x12f9b88: LoadField: r1 = r0->field_37
    //     0x12f9b88: ldur            w1, [x0, #0x37]
    // 0x12f9b8c: DecompressPointer r1
    //     0x12f9b8c: add             x1, x1, HEAP, lsl #32
    // 0x12f9b90: tbz             w1, #4, #0x12f9bac
    // 0x12f9b94: mov             x1, x0
    // 0x12f9b98: ldur            x3, [fp, #-0x20]
    // 0x12f9b9c: r2 = Instance__ScaffoldSlot
    //     0x12f9b9c: add             x2, PP, #0x84, lsl #12  ; [pp+0x84ae8] Obj!_ScaffoldSlot@12c5021
    //     0x12f9ba0: ldr             x2, [x2, #0xae8]
    // 0x12f9ba4: r0 = layoutChild()
    //     0x12f9ba4: bl              #0x12fa2ec  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::layoutChild
    // 0x12f9ba8: b               #0x12f9bb0
    // 0x12f9bac: r0 = Instance_Size
    //     0x12f9bac: ldr             x0, [PP, #0x7f28]  ; [pp+0x7f28] Obj!Size@12a74d1
    // 0x12f9bb0: ldur            x1, [fp, #-8]
    // 0x12f9bb4: stur            x0, [fp, #-0x38]
    // 0x12f9bb8: r2 = Instance__ScaffoldSlot
    //     0x12f9bb8: add             x2, PP, #0x84, lsl #12  ; [pp+0x84ae0] Obj!_ScaffoldSlot@12c5041
    //     0x12f9bbc: ldr             x2, [x2, #0xae0]
    // 0x12f9bc0: r0 = hasChild()
    //     0x12f9bc0: bl              #0x12fa3ac  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::hasChild
    // 0x12f9bc4: tbnz            w0, #4, #0x12f9c7c
    // 0x12f9bc8: ldur            x0, [fp, #-0x20]
    // 0x12f9bcc: ldur            d1, [fp, #-0x90]
    // 0x12f9bd0: ldur            d0, [fp, #-0x78]
    // 0x12f9bd4: ldur            d3, [fp, #-0x70]
    // 0x12f9bd8: d2 = 0.000000
    //     0x12f9bd8: eor             v2.16b, v2.16b, v2.16b
    // 0x12f9bdc: LoadField: d4 = r0->field_f
    //     0x12f9bdc: ldur            d4, [x0, #0xf]
    // 0x12f9be0: stur            d4, [fp, #-0x88]
    // 0x12f9be4: fsub            d5, d0, d1
    // 0x12f9be8: fmax            v1.2d, v2.2d, v5.2d
    // 0x12f9bec: stur            d1, [fp, #-0x80]
    // 0x12f9bf0: r0 = BoxConstraints()
    //     0x12f9bf0: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x12f9bf4: StoreField: r0->field_7 = rZR
    //     0x12f9bf4: stur            xzr, [x0, #7]
    // 0x12f9bf8: ldur            d0, [fp, #-0x88]
    // 0x12f9bfc: StoreField: r0->field_f = d0
    //     0x12f9bfc: stur            d0, [x0, #0xf]
    // 0x12f9c00: ArrayStore: r0[0] = rZR  ; List_8
    //     0x12f9c00: stur            xzr, [x0, #0x17]
    // 0x12f9c04: ldur            d0, [fp, #-0x80]
    // 0x12f9c08: StoreField: r0->field_1f = d0
    //     0x12f9c08: stur            d0, [x0, #0x1f]
    // 0x12f9c0c: ldur            x1, [fp, #-8]
    // 0x12f9c10: mov             x3, x0
    // 0x12f9c14: r2 = Instance__ScaffoldSlot
    //     0x12f9c14: add             x2, PP, #0x84, lsl #12  ; [pp+0x84ae0] Obj!_ScaffoldSlot@12c5041
    //     0x12f9c18: ldr             x2, [x2, #0xae0]
    // 0x12f9c1c: r0 = layoutChild()
    //     0x12f9c1c: bl              #0x12fa2ec  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::layoutChild
    // 0x12f9c20: stur            x0, [fp, #-0x40]
    // 0x12f9c24: LoadField: d0 = r0->field_7
    //     0x12f9c24: ldur            d0, [x0, #7]
    // 0x12f9c28: ldur            d1, [fp, #-0x70]
    // 0x12f9c2c: fsub            d2, d1, d0
    // 0x12f9c30: d0 = 2.000000
    //     0x12f9c30: fmov            d0, #2.00000000
    // 0x12f9c34: fdiv            d3, d2, d0
    // 0x12f9c38: stur            d3, [fp, #-0x88]
    // 0x12f9c3c: LoadField: d2 = r0->field_f
    //     0x12f9c3c: ldur            d2, [x0, #0xf]
    // 0x12f9c40: ldur            d4, [fp, #-0x78]
    // 0x12f9c44: fsub            d5, d4, d2
    // 0x12f9c48: stur            d5, [fp, #-0x80]
    // 0x12f9c4c: r0 = Offset()
    //     0x12f9c4c: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x12f9c50: ldur            d0, [fp, #-0x88]
    // 0x12f9c54: StoreField: r0->field_7 = d0
    //     0x12f9c54: stur            d0, [x0, #7]
    // 0x12f9c58: ldur            d0, [fp, #-0x80]
    // 0x12f9c5c: StoreField: r0->field_f = d0
    //     0x12f9c5c: stur            d0, [x0, #0xf]
    // 0x12f9c60: ldur            x1, [fp, #-8]
    // 0x12f9c64: mov             x3, x0
    // 0x12f9c68: r2 = Instance__ScaffoldSlot
    //     0x12f9c68: add             x2, PP, #0x84, lsl #12  ; [pp+0x84ae0] Obj!_ScaffoldSlot@12c5041
    //     0x12f9c6c: ldr             x2, [x2, #0xae0]
    // 0x12f9c70: r0 = positionChild()
    //     0x12f9c70: bl              #0x12fa1f4  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::positionChild
    // 0x12f9c74: ldur            x0, [fp, #-0x40]
    // 0x12f9c78: b               #0x12f9c80
    // 0x12f9c7c: r0 = Instance_Size
    //     0x12f9c7c: ldr             x0, [PP, #0x7f28]  ; [pp+0x7f28] Obj!Size@12a74d1
    // 0x12f9c80: ldur            x1, [fp, #-8]
    // 0x12f9c84: stur            x0, [fp, #-0x40]
    // 0x12f9c88: r2 = Instance__ScaffoldSlot
    //     0x12f9c88: add             x2, PP, #0x84, lsl #12  ; [pp+0x84b20] Obj!_ScaffoldSlot@12c4fc1
    //     0x12f9c8c: ldr             x2, [x2, #0xb20]
    // 0x12f9c90: r0 = hasChild()
    //     0x12f9c90: bl              #0x12fa3ac  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::hasChild
    // 0x12f9c94: tbnz            w0, #4, #0x12f9dd8
    // 0x12f9c98: ldur            x5, [fp, #-8]
    // 0x12f9c9c: ldur            x7, [fp, #-0x10]
    // 0x12f9ca0: ldur            x6, [fp, #-0x30]
    // 0x12f9ca4: ldur            x4, [fp, #-0x38]
    // 0x12f9ca8: ldur            x0, [fp, #-0x40]
    // 0x12f9cac: ldur            d0, [fp, #-0x78]
    // 0x12f9cb0: mov             x1, x5
    // 0x12f9cb4: ldur            x3, [fp, #-0x18]
    // 0x12f9cb8: r2 = Instance__ScaffoldSlot
    //     0x12f9cb8: add             x2, PP, #0x84, lsl #12  ; [pp+0x84b20] Obj!_ScaffoldSlot@12c4fc1
    //     0x12f9cbc: ldr             x2, [x2, #0xb20]
    // 0x12f9cc0: r0 = layoutChild()
    //     0x12f9cc0: bl              #0x12fa2ec  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::layoutChild
    // 0x12f9cc4: ldur            x1, [fp, #-8]
    // 0x12f9cc8: stur            x0, [fp, #-0x58]
    // 0x12f9ccc: LoadField: r2 = r1->field_1f
    //     0x12f9ccc: ldur            w2, [x1, #0x1f]
    // 0x12f9cd0: DecompressPointer r2
    //     0x12f9cd0: add             x2, x2, HEAP, lsl #32
    // 0x12f9cd4: stur            x2, [fp, #-0x50]
    // 0x12f9cd8: LoadField: r3 = r1->field_1b
    //     0x12f9cd8: ldur            w3, [x1, #0x1b]
    // 0x12f9cdc: DecompressPointer r3
    //     0x12f9cdc: add             x3, x3, HEAP, lsl #32
    // 0x12f9ce0: stur            x3, [fp, #-0x48]
    // 0x12f9ce4: r0 = ScaffoldPrelayoutGeometry()
    //     0x12f9ce4: bl              #0x12fa1dc  ; AllocateScaffoldPrelayoutGeometryStub -> ScaffoldPrelayoutGeometry (size=0x2c)
    // 0x12f9ce8: mov             x3, x0
    // 0x12f9cec: ldur            x0, [fp, #-0x40]
    // 0x12f9cf0: stur            x3, [fp, #-0x60]
    // 0x12f9cf4: StoreField: r3->field_b = r0
    //     0x12f9cf4: stur            w0, [x3, #0xb]
    // 0x12f9cf8: ldur            d0, [fp, #-0x78]
    // 0x12f9cfc: StoreField: r3->field_f = d0
    //     0x12f9cfc: stur            d0, [x3, #0xf]
    // 0x12f9d00: ldur            x0, [fp, #-0x58]
    // 0x12f9d04: StoreField: r3->field_7 = r0
    //     0x12f9d04: stur            w0, [x3, #7]
    // 0x12f9d08: ldur            x4, [fp, #-0x30]
    // 0x12f9d0c: ArrayStore: r3[0] = r4  ; List_4
    //     0x12f9d0c: stur            w4, [x3, #0x17]
    // 0x12f9d10: ldur            x1, [fp, #-0x48]
    // 0x12f9d14: StoreField: r3->field_1b = r1
    //     0x12f9d14: stur            w1, [x3, #0x1b]
    // 0x12f9d18: ldur            x1, [fp, #-0x10]
    // 0x12f9d1c: StoreField: r3->field_1f = r1
    //     0x12f9d1c: stur            w1, [x3, #0x1f]
    // 0x12f9d20: ldur            x5, [fp, #-0x38]
    // 0x12f9d24: StoreField: r3->field_23 = r5
    //     0x12f9d24: stur            w5, [x3, #0x23]
    // 0x12f9d28: ldur            x1, [fp, #-0x50]
    // 0x12f9d2c: StoreField: r3->field_27 = r1
    //     0x12f9d2c: stur            w1, [x3, #0x27]
    // 0x12f9d30: mov             x2, x3
    // 0x12f9d34: r1 = Instance__EndFloatFabLocation
    //     0x12f9d34: add             x1, PP, #0x84, lsl #12  ; [pp+0x84b88] Obj!_EndFloatFabLocation@129ecf1
    //     0x12f9d38: ldr             x1, [x1, #0xb88]
    // 0x12f9d3c: r0 = getOffset()
    //     0x12f9d3c: bl              #0x119e4dc  ; [package:flutter/src/material/floating_action_button_location.dart] StandardFabLocation::getOffset
    // 0x12f9d40: mov             x4, x0
    // 0x12f9d44: ldur            x3, [fp, #-8]
    // 0x12f9d48: stur            x4, [fp, #-0x10]
    // 0x12f9d4c: LoadField: r1 = r3->field_27
    //     0x12f9d4c: ldur            w1, [x3, #0x27]
    // 0x12f9d50: DecompressPointer r1
    //     0x12f9d50: add             x1, x1, HEAP, lsl #32
    // 0x12f9d54: r0 = LoadClassIdInstr(r1)
    //     0x12f9d54: ldur            x0, [x1, #-1]
    //     0x12f9d58: ubfx            x0, x0, #0xc, #0x14
    // 0x12f9d5c: ldur            x2, [fp, #-0x60]
    // 0x12f9d60: r0 = GDT[cid_x0 + 0x2f17]()
    //     0x12f9d60: mov             x17, #0x2f17
    //     0x12f9d64: add             lr, x0, x17
    //     0x12f9d68: ldr             lr, [x21, lr, lsl #3]
    //     0x12f9d6c: blr             lr
    // 0x12f9d70: mov             x1, x0
    // 0x12f9d74: ldur            x0, [fp, #-8]
    // 0x12f9d78: LoadField: r2 = r0->field_2f
    //     0x12f9d78: ldur            w2, [x0, #0x2f]
    // 0x12f9d7c: DecompressPointer r2
    //     0x12f9d7c: add             x2, x2, HEAP, lsl #32
    // 0x12f9d80: LoadField: r3 = r2->field_37
    //     0x12f9d80: ldur            w3, [x2, #0x37]
    // 0x12f9d84: DecompressPointer r3
    //     0x12f9d84: add             x3, x3, HEAP, lsl #32
    // 0x12f9d88: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12f9d8c: cmp             w3, w16
    // 0x12f9d90: b.eq            #0x12fa1c0
    // 0x12f9d94: LoadField: d0 = r3->field_7
    //     0x12f9d94: ldur            d0, [x3, #7]
    // 0x12f9d98: d1 = 0.500000
    //     0x12f9d98: fmov            d1, #0.50000000
    // 0x12f9d9c: fcmp            d1, d0
    // 0x12f9da0: b.le            #0x12f9dac
    // 0x12f9da4: mov             x4, x1
    // 0x12f9da8: b               #0x12f9db0
    // 0x12f9dac: ldur            x4, [fp, #-0x10]
    // 0x12f9db0: mov             x1, x0
    // 0x12f9db4: mov             x3, x4
    // 0x12f9db8: stur            x4, [fp, #-0x10]
    // 0x12f9dbc: r2 = Instance__ScaffoldSlot
    //     0x12f9dbc: add             x2, PP, #0x84, lsl #12  ; [pp+0x84b20] Obj!_ScaffoldSlot@12c4fc1
    //     0x12f9dc0: ldr             x2, [x2, #0xb20]
    // 0x12f9dc4: r0 = positionChild()
    //     0x12f9dc4: bl              #0x12fa1f4  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::positionChild
    // 0x12f9dc8: ldur            x1, [fp, #-0x10]
    // 0x12f9dcc: ldur            x2, [fp, #-0x58]
    // 0x12f9dd0: r0 = &()
    //     0x12f9dd0: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0x12f9dd4: b               #0x12f9ddc
    // 0x12f9dd8: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x12f9ddc: ldur            x1, [fp, #-8]
    // 0x12f9de0: stur            x0, [fp, #-0x10]
    // 0x12f9de4: r2 = Instance__ScaffoldSlot
    //     0x12f9de4: add             x2, PP, #0x84, lsl #12  ; [pp+0x84ae8] Obj!_ScaffoldSlot@12c5021
    //     0x12f9de8: ldr             x2, [x2, #0xae8]
    // 0x12f9dec: r0 = hasChild()
    //     0x12f9dec: bl              #0x12fa3ac  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::hasChild
    // 0x12f9df0: tbnz            w0, #4, #0x12f9fdc
    // 0x12f9df4: ldur            x0, [fp, #-8]
    // 0x12f9df8: LoadField: r4 = r0->field_3b
    //     0x12f9df8: ldur            w4, [x0, #0x3b]
    // 0x12f9dfc: DecompressPointer r4
    //     0x12f9dfc: add             x4, x4, HEAP, lsl #32
    // 0x12f9e00: stur            x4, [fp, #-0x48]
    // 0x12f9e04: cmp             w4, NULL
    // 0x12f9e08: b.eq            #0x12f9e2c
    // 0x12f9e0c: ldur            d0, [fp, #-0x70]
    // 0x12f9e10: LoadField: d1 = r4->field_7
    //     0x12f9e10: ldur            d1, [x4, #7]
    // 0x12f9e14: fcmp            d0, d1
    // 0x12f9e18: r16 = true
    //     0x12f9e18: add             x16, NULL, #0x20  ; true
    // 0x12f9e1c: r17 = false
    //     0x12f9e1c: add             x17, NULL, #0x30  ; false
    // 0x12f9e20: csel            x1, x16, x17, gt
    // 0x12f9e24: mov             x6, x1
    // 0x12f9e28: b               #0x12f9e34
    // 0x12f9e2c: ldur            d0, [fp, #-0x70]
    // 0x12f9e30: r6 = false
    //     0x12f9e30: add             x6, NULL, #0x30  ; false
    // 0x12f9e34: ldur            x1, [fp, #-0x38]
    // 0x12f9e38: r5 = Instance_Size
    //     0x12f9e38: ldr             x5, [PP, #0x7f28]  ; [pp+0x7f28] Obj!Size@12a74d1
    // 0x12f9e3c: stur            x6, [fp, #-0x40]
    // 0x12f9e40: LoadField: d1 = r5->field_7
    //     0x12f9e40: ldur            d1, [x5, #7]
    // 0x12f9e44: stur            d1, [fp, #-0x80]
    // 0x12f9e48: LoadField: d2 = r1->field_7
    //     0x12f9e48: ldur            d2, [x1, #7]
    // 0x12f9e4c: fcmp            d1, d2
    // 0x12f9e50: b.ne            #0x12f9e8c
    // 0x12f9e54: LoadField: d2 = r5->field_f
    //     0x12f9e54: ldur            d2, [x5, #0xf]
    // 0x12f9e58: LoadField: d3 = r1->field_f
    //     0x12f9e58: ldur            d3, [x1, #0xf]
    // 0x12f9e5c: fcmp            d2, d3
    // 0x12f9e60: b.ne            #0x12f9e8c
    // 0x12f9e64: tbnz            w6, #4, #0x12f9e70
    // 0x12f9e68: ldur            x3, [fp, #-0x18]
    // 0x12f9e6c: b               #0x12f9e74
    // 0x12f9e70: ldur            x3, [fp, #-0x20]
    // 0x12f9e74: mov             x1, x0
    // 0x12f9e78: r2 = Instance__ScaffoldSlot
    //     0x12f9e78: add             x2, PP, #0x84, lsl #12  ; [pp+0x84ae8] Obj!_ScaffoldSlot@12c5021
    //     0x12f9e7c: ldr             x2, [x2, #0xae8]
    // 0x12f9e80: r0 = layoutChild()
    //     0x12f9e80: bl              #0x12fa2ec  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::layoutChild
    // 0x12f9e84: mov             x2, x0
    // 0x12f9e88: b               #0x12f9e90
    // 0x12f9e8c: mov             x2, x1
    // 0x12f9e90: ldur            x0, [fp, #-0x10]
    // 0x12f9e94: stur            x2, [fp, #-0x18]
    // 0x12f9e98: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12f9e9c: cmp             w0, w16
    // 0x12f9ea0: b.eq            #0x12fa164
    // 0x12f9ea4: ldur            d0, [fp, #-0x80]
    // 0x12f9ea8: mov             x1, x0
    // 0x12f9eac: r0 = size()
    //     0x12f9eac: bl              #0x8632d0  ; [dart:ui] Rect::size
    // 0x12f9eb0: LoadField: d0 = r0->field_7
    //     0x12f9eb0: ldur            d0, [x0, #7]
    // 0x12f9eb4: ldur            d1, [fp, #-0x80]
    // 0x12f9eb8: fcmp            d1, d0
    // 0x12f9ebc: b.ne            #0x12f9ee4
    // 0x12f9ec0: r1 = Instance_Size
    //     0x12f9ec0: ldr             x1, [PP, #0x7f28]  ; [pp+0x7f28] Obj!Size@12a74d1
    // 0x12f9ec4: LoadField: d0 = r1->field_f
    //     0x12f9ec4: ldur            d0, [x1, #0xf]
    // 0x12f9ec8: LoadField: d1 = r0->field_f
    //     0x12f9ec8: ldur            d1, [x0, #0xf]
    // 0x12f9ecc: fcmp            d0, d1
    // 0x12f9ed0: b.ne            #0x12f9ee4
    // 0x12f9ed4: ldur            x1, [fp, #-8]
    // 0x12f9ed8: ldur            x0, [fp, #-0x28]
    // 0x12f9edc: ldur            x2, [fp, #-0x10]
    // 0x12f9ee0: b               #0x12f9f34
    // 0x12f9ee4: ldur            x1, [fp, #-8]
    // 0x12f9ee8: LoadField: r0 = r1->field_37
    //     0x12f9ee8: ldur            w0, [x1, #0x37]
    // 0x12f9eec: DecompressPointer r0
    //     0x12f9eec: add             x0, x0, HEAP, lsl #32
    // 0x12f9ef0: tbnz            w0, #4, #0x12f9f2c
    // 0x12f9ef4: ldur            x0, [fp, #-0x28]
    // 0x12f9ef8: cmp             w0, NULL
    // 0x12f9efc: b.eq            #0x12f9f18
    // 0x12f9f00: ldur            x2, [fp, #-0x10]
    // 0x12f9f04: LoadField: d0 = r2->field_f
    //     0x12f9f04: ldur            d0, [x2, #0xf]
    // 0x12f9f08: LoadField: d1 = r0->field_7
    //     0x12f9f08: ldur            d1, [x0, #7]
    // 0x12f9f0c: fmin            v2.2d, v1.2d, v0.2d
    // 0x12f9f10: mov             v0.16b, v2.16b
    // 0x12f9f14: b               #0x12f9f20
    // 0x12f9f18: ldur            x2, [fp, #-0x10]
    // 0x12f9f1c: LoadField: d0 = r2->field_f
    //     0x12f9f1c: ldur            d0, [x2, #0xf]
    // 0x12f9f20: mov             v1.16b, v0.16b
    // 0x12f9f24: ldur            d0, [fp, #-0x68]
    // 0x12f9f28: b               #0x12f9f68
    // 0x12f9f2c: ldur            x0, [fp, #-0x28]
    // 0x12f9f30: ldur            x2, [fp, #-0x10]
    // 0x12f9f34: ldur            d0, [fp, #-0x68]
    // 0x12f9f38: LoadField: r3 = r1->field_1b
    //     0x12f9f38: ldur            w3, [x1, #0x1b]
    // 0x12f9f3c: DecompressPointer r3
    //     0x12f9f3c: add             x3, x3, HEAP, lsl #32
    // 0x12f9f40: LoadField: d1 = r3->field_1f
    //     0x12f9f40: ldur            d1, [x3, #0x1f]
    // 0x12f9f44: fsub            d2, d0, d1
    // 0x12f9f48: LoadField: r3 = r1->field_37
    //     0x12f9f48: ldur            w3, [x1, #0x37]
    // 0x12f9f4c: DecompressPointer r3
    //     0x12f9f4c: add             x3, x3, HEAP, lsl #32
    // 0x12f9f50: tbnz            w3, #4, #0x12f9f64
    // 0x12f9f54: ldur            d1, [fp, #-0x78]
    // 0x12f9f58: fmin            v3.2d, v1.2d, v2.2d
    // 0x12f9f5c: mov             v1.16b, v3.16b
    // 0x12f9f60: b               #0x12f9f68
    // 0x12f9f64: ldur            d1, [fp, #-0x78]
    // 0x12f9f68: ldur            x3, [fp, #-0x40]
    // 0x12f9f6c: tbnz            w3, #4, #0x12f9f98
    // 0x12f9f70: ldur            x3, [fp, #-0x48]
    // 0x12f9f74: ldur            d2, [fp, #-0x70]
    // 0x12f9f78: d3 = 2.000000
    //     0x12f9f78: fmov            d3, #2.00000000
    // 0x12f9f7c: cmp             w3, NULL
    // 0x12f9f80: b.eq            #0x12fa1c8
    // 0x12f9f84: LoadField: d4 = r3->field_7
    //     0x12f9f84: ldur            d4, [x3, #7]
    // 0x12f9f88: fsub            d5, d2, d4
    // 0x12f9f8c: fdiv            d4, d5, d3
    // 0x12f9f90: mov             v3.16b, v4.16b
    // 0x12f9f94: b               #0x12f9fa0
    // 0x12f9f98: ldur            d2, [fp, #-0x70]
    // 0x12f9f9c: d3 = 0.000000
    //     0x12f9f9c: eor             v3.16b, v3.16b, v3.16b
    // 0x12f9fa0: ldur            x3, [fp, #-0x18]
    // 0x12f9fa4: stur            d3, [fp, #-0x80]
    // 0x12f9fa8: LoadField: d4 = r3->field_f
    //     0x12f9fa8: ldur            d4, [x3, #0xf]
    // 0x12f9fac: fsub            d5, d1, d4
    // 0x12f9fb0: stur            d5, [fp, #-0x78]
    // 0x12f9fb4: r0 = Offset()
    //     0x12f9fb4: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x12f9fb8: ldur            d0, [fp, #-0x80]
    // 0x12f9fbc: StoreField: r0->field_7 = d0
    //     0x12f9fbc: stur            d0, [x0, #7]
    // 0x12f9fc0: ldur            d0, [fp, #-0x78]
    // 0x12f9fc4: StoreField: r0->field_f = d0
    //     0x12f9fc4: stur            d0, [x0, #0xf]
    // 0x12f9fc8: ldur            x1, [fp, #-8]
    // 0x12f9fcc: mov             x3, x0
    // 0x12f9fd0: r2 = Instance__ScaffoldSlot
    //     0x12f9fd0: add             x2, PP, #0x84, lsl #12  ; [pp+0x84ae8] Obj!_ScaffoldSlot@12c5021
    //     0x12f9fd4: ldr             x2, [x2, #0xae8]
    // 0x12f9fd8: r0 = positionChild()
    //     0x12f9fd8: bl              #0x12fa1f4  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::positionChild
    // 0x12f9fdc: ldur            x1, [fp, #-8]
    // 0x12f9fe0: r2 = Instance__ScaffoldSlot
    //     0x12f9fe0: add             x2, PP, #0x84, lsl #12  ; [pp+0x84b28] Obj!_ScaffoldSlot@12c4fa1
    //     0x12f9fe4: ldr             x2, [x2, #0xb28]
    // 0x12f9fe8: r0 = hasChild()
    //     0x12f9fe8: bl              #0x12fa3ac  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::hasChild
    // 0x12f9fec: tbnz            w0, #4, #0x12fa060
    // 0x12f9ff0: ldur            x0, [fp, #-0x30]
    // 0x12f9ff4: LoadField: d0 = r0->field_f
    //     0x12f9ff4: ldur            d0, [x0, #0xf]
    // 0x12f9ff8: r0 = inline_Allocate_Double()
    //     0x12f9ff8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x12f9ffc: add             x0, x0, #0x10
    //     0x12fa000: cmp             x1, x0
    //     0x12fa004: b.ls            #0x12fa1cc
    //     0x12fa008: str             x0, [THR, #0x60]  ; THR::top
    //     0x12fa00c: sub             x0, x0, #0xf
    //     0x12fa010: mov             x1, #0xe19c
    //     0x12fa014: movk            x1, #3, lsl #16
    //     0x12fa018: stur            x1, [x0, #-1]
    // 0x12fa01c: dmb             ishst
    // 0x12fa020: StoreField: r0->field_7 = d0
    //     0x12fa020: stur            d0, [x0, #7]
    // 0x12fa024: str             x0, [SP]
    // 0x12fa028: ldur            x1, [fp, #-0x20]
    // 0x12fa02c: r4 = const [0, 0x2, 0x1, 0x1, height, 0x1, null]
    //     0x12fa02c: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1f1a0] List(7) [0, 0x2, 0x1, 0x1, "height", 0x1, Null]
    //     0x12fa030: ldr             x4, [x4, #0x1a0]
    // 0x12fa034: r0 = tighten()
    //     0x12fa034: bl              #0xb4aa24  ; [package:flutter/src/rendering/box.dart] BoxConstraints::tighten
    // 0x12fa038: ldur            x1, [fp, #-8]
    // 0x12fa03c: mov             x3, x0
    // 0x12fa040: r2 = Instance__ScaffoldSlot
    //     0x12fa040: add             x2, PP, #0x84, lsl #12  ; [pp+0x84b28] Obj!_ScaffoldSlot@12c4fa1
    //     0x12fa044: ldr             x2, [x2, #0xb28]
    // 0x12fa048: r0 = layoutChild()
    //     0x12fa048: bl              #0x12fa2ec  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::layoutChild
    // 0x12fa04c: ldur            x1, [fp, #-8]
    // 0x12fa050: r2 = Instance__ScaffoldSlot
    //     0x12fa050: add             x2, PP, #0x84, lsl #12  ; [pp+0x84b28] Obj!_ScaffoldSlot@12c4fa1
    //     0x12fa054: ldr             x2, [x2, #0xb28]
    // 0x12fa058: r3 = Instance_Offset
    //     0x12fa058: ldr             x3, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x12fa05c: r0 = positionChild()
    //     0x12fa05c: bl              #0x12fa1f4  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::positionChild
    // 0x12fa060: ldur            x1, [fp, #-8]
    // 0x12fa064: r2 = Instance__ScaffoldSlot
    //     0x12fa064: add             x2, PP, #0x84, lsl #12  ; [pp+0x84bc0] Obj!_ScaffoldSlot@12c4f81
    //     0x12fa068: ldr             x2, [x2, #0xbc0]
    // 0x12fa06c: r0 = hasChild()
    //     0x12fa06c: bl              #0x12fa3ac  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::hasChild
    // 0x12fa070: tbnz            w0, #4, #0x12fa0c0
    // 0x12fa074: ldur            d1, [fp, #-0x70]
    // 0x12fa078: ldur            d0, [fp, #-0x68]
    // 0x12fa07c: r0 = BoxConstraints()
    //     0x12fa07c: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x12fa080: ldur            d0, [fp, #-0x70]
    // 0x12fa084: StoreField: r0->field_7 = d0
    //     0x12fa084: stur            d0, [x0, #7]
    // 0x12fa088: StoreField: r0->field_f = d0
    //     0x12fa088: stur            d0, [x0, #0xf]
    // 0x12fa08c: ldur            d1, [fp, #-0x68]
    // 0x12fa090: ArrayStore: r0[0] = d1  ; List_8
    //     0x12fa090: stur            d1, [x0, #0x17]
    // 0x12fa094: StoreField: r0->field_1f = d1
    //     0x12fa094: stur            d1, [x0, #0x1f]
    // 0x12fa098: ldur            x1, [fp, #-8]
    // 0x12fa09c: mov             x3, x0
    // 0x12fa0a0: r2 = Instance__ScaffoldSlot
    //     0x12fa0a0: add             x2, PP, #0x84, lsl #12  ; [pp+0x84bc0] Obj!_ScaffoldSlot@12c4f81
    //     0x12fa0a4: ldr             x2, [x2, #0xbc0]
    // 0x12fa0a8: r0 = layoutChild()
    //     0x12fa0a8: bl              #0x12fa2ec  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::layoutChild
    // 0x12fa0ac: ldur            x1, [fp, #-8]
    // 0x12fa0b0: r2 = Instance__ScaffoldSlot
    //     0x12fa0b0: add             x2, PP, #0x84, lsl #12  ; [pp+0x84bc0] Obj!_ScaffoldSlot@12c4f81
    //     0x12fa0b4: ldr             x2, [x2, #0xbc0]
    // 0x12fa0b8: r3 = Instance_Offset
    //     0x12fa0b8: ldr             x3, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x12fa0bc: r0 = positionChild()
    //     0x12fa0bc: bl              #0x12fa1f4  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::positionChild
    // 0x12fa0c0: ldur            x1, [fp, #-8]
    // 0x12fa0c4: r2 = Instance__ScaffoldSlot
    //     0x12fa0c4: add             x2, PP, #0xa3, lsl #12  ; [pp+0xa3d00] Obj!_ScaffoldSlot@12c50c1
    //     0x12fa0c8: ldr             x2, [x2, #0xd00]
    // 0x12fa0cc: r0 = hasChild()
    //     0x12fa0cc: bl              #0x12fa3ac  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::hasChild
    // 0x12fa0d0: tbnz            w0, #4, #0x12fa120
    // 0x12fa0d4: ldur            d0, [fp, #-0x70]
    // 0x12fa0d8: ldur            d1, [fp, #-0x68]
    // 0x12fa0dc: r0 = BoxConstraints()
    //     0x12fa0dc: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x12fa0e0: ldur            d0, [fp, #-0x70]
    // 0x12fa0e4: StoreField: r0->field_7 = d0
    //     0x12fa0e4: stur            d0, [x0, #7]
    // 0x12fa0e8: StoreField: r0->field_f = d0
    //     0x12fa0e8: stur            d0, [x0, #0xf]
    // 0x12fa0ec: ldur            d0, [fp, #-0x68]
    // 0x12fa0f0: ArrayStore: r0[0] = d0  ; List_8
    //     0x12fa0f0: stur            d0, [x0, #0x17]
    // 0x12fa0f4: StoreField: r0->field_1f = d0
    //     0x12fa0f4: stur            d0, [x0, #0x1f]
    // 0x12fa0f8: ldur            x1, [fp, #-8]
    // 0x12fa0fc: mov             x3, x0
    // 0x12fa100: r2 = Instance__ScaffoldSlot
    //     0x12fa100: add             x2, PP, #0xa3, lsl #12  ; [pp+0xa3d00] Obj!_ScaffoldSlot@12c50c1
    //     0x12fa104: ldr             x2, [x2, #0xd00]
    // 0x12fa108: r0 = layoutChild()
    //     0x12fa108: bl              #0x12fa2ec  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::layoutChild
    // 0x12fa10c: ldur            x1, [fp, #-8]
    // 0x12fa110: r2 = Instance__ScaffoldSlot
    //     0x12fa110: add             x2, PP, #0xa3, lsl #12  ; [pp+0xa3d00] Obj!_ScaffoldSlot@12c50c1
    //     0x12fa114: ldr             x2, [x2, #0xd00]
    // 0x12fa118: r3 = Instance_Offset
    //     0x12fa118: ldr             x3, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x12fa11c: r0 = positionChild()
    //     0x12fa11c: bl              #0x12fa1f4  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::positionChild
    // 0x12fa120: ldur            x0, [fp, #-8]
    // 0x12fa124: ldur            x1, [fp, #-0x10]
    // 0x12fa128: LoadField: r2 = r0->field_23
    //     0x12fa128: ldur            w2, [x0, #0x23]
    // 0x12fa12c: DecompressPointer r2
    //     0x12fa12c: add             x2, x2, HEAP, lsl #32
    // 0x12fa130: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12fa134: cmp             w1, w16
    // 0x12fa138: b.eq            #0x12fa178
    // 0x12fa13c: ldur            x16, [fp, #-0x28]
    // 0x12fa140: stp             x1, x16, [SP]
    // 0x12fa144: mov             x1, x2
    // 0x12fa148: r4 = const [0, 0x3, 0x2, 0x1, bottomNavigationBarTop, 0x1, floatingActionButtonArea, 0x2, null]
    //     0x12fa148: add             x4, PP, #0xa3, lsl #12  ; [pp+0xa3d08] List(9) [0, 0x3, 0x2, 0x1, "bottomNavigationBarTop", 0x1, "floatingActionButtonArea", 0x2, Null]
    //     0x12fa14c: ldr             x4, [x4, #0xd08]
    // 0x12fa150: r0 = _updateWith()
    //     0x12fa150: bl              #0xf3d2e8  ; [package:flutter/src/material/scaffold.dart] _ScaffoldGeometryNotifier::_updateWith
    // 0x12fa154: r0 = Null
    //     0x12fa154: mov             x0, NULL
    // 0x12fa158: LeaveFrame
    //     0x12fa158: mov             SP, fp
    //     0x12fa15c: ldp             fp, lr, [SP], #0x10
    // 0x12fa160: ret
    //     0x12fa160: ret             
    // 0x12fa164: r16 = "floatingActionButtonRect"
    //     0x12fa164: add             x16, PP, #0xa3, lsl #12  ; [pp+0xa3d10] "floatingActionButtonRect"
    //     0x12fa168: ldr             x16, [x16, #0xd10]
    // 0x12fa16c: str             x16, [SP]
    // 0x12fa170: r0 = _throwLocalNotInitialized()
    //     0x12fa170: bl              #0x82b57c  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0x12fa174: brk             #0
    // 0x12fa178: r16 = "floatingActionButtonRect"
    //     0x12fa178: add             x16, PP, #0xa3, lsl #12  ; [pp+0xa3d10] "floatingActionButtonRect"
    //     0x12fa17c: ldr             x16, [x16, #0xd10]
    // 0x12fa180: str             x16, [SP]
    // 0x12fa184: r0 = _throwLocalNotInitialized()
    //     0x12fa184: bl              #0x82b57c  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0x12fa188: brk             #0
    // 0x12fa18c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12fa18c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12fa190: b               #0x12f972c
    // 0x12fa194: stp             q0, q1, [SP, #-0x20]!
    // 0x12fa198: stp             x0, x2, [SP, #-0x10]!
    // 0x12fa19c: r0 = AllocateDouble()
    //     0x12fa19c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x12fa1a0: mov             x1, x0
    // 0x12fa1a4: ldp             x0, x2, [SP], #0x10
    // 0x12fa1a8: ldp             q0, q1, [SP], #0x20
    // 0x12fa1ac: b               #0x12f9780
    // 0x12fa1b0: SaveReg d0
    //     0x12fa1b0: str             q0, [SP, #-0x10]!
    // 0x12fa1b4: r0 = AllocateDouble()
    //     0x12fa1b4: bl              #0x13df878  ; AllocateDoubleStub
    // 0x12fa1b8: RestoreReg d0
    //     0x12fa1b8: ldr             q0, [SP], #0x10
    // 0x12fa1bc: b               #0x12f9898
    // 0x12fa1c0: r9 = _value
    //     0x12fa1c0: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0x12fa1c4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x12fa1c4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x12fa1c8: r0 = NullCastErrorSharedWithFPURegs()
    //     0x12fa1c8: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0x12fa1cc: SaveReg d0
    //     0x12fa1cc: str             q0, [SP, #-0x10]!
    // 0x12fa1d0: r0 = AllocateDouble()
    //     0x12fa1d0: bl              #0x13df878  ; AllocateDoubleStub
    // 0x12fa1d4: RestoreReg d0
    //     0x12fa1d4: ldr             q0, [SP], #0x10
    // 0x12fa1d8: b               #0x12fa020
  }
  _ shouldRelayout(/* No info */) {
    // ** addr: 0x12fa7dc, size: 0x100
    // 0x12fa7dc: EnterFrame
    //     0x12fa7dc: stp             fp, lr, [SP, #-0x10]!
    //     0x12fa7e0: mov             fp, SP
    // 0x12fa7e4: AllocStack(0x20)
    //     0x12fa7e4: sub             SP, SP, #0x20
    // 0x12fa7e8: SetupParameters(_ScaffoldLayout this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x12fa7e8: mov             x4, x1
    //     0x12fa7ec: mov             x3, x2
    //     0x12fa7f0: stur            x1, [fp, #-8]
    //     0x12fa7f4: stur            x2, [fp, #-0x10]
    // 0x12fa7f8: CheckStackOverflow
    //     0x12fa7f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fa7fc: cmp             SP, x16
    //     0x12fa800: b.ls            #0x12fa8d4
    // 0x12fa804: mov             x0, x3
    // 0x12fa808: r2 = Null
    //     0x12fa808: mov             x2, NULL
    // 0x12fa80c: r1 = Null
    //     0x12fa80c: mov             x1, NULL
    // 0x12fa810: r4 = 60
    //     0x12fa810: mov             x4, #0x3c
    // 0x12fa814: branchIfSmi(r0, 0x12fa820)
    //     0x12fa814: tbz             w0, #0, #0x12fa820
    // 0x12fa818: r4 = LoadClassIdInstr(r0)
    //     0x12fa818: ldur            x4, [x0, #-1]
    //     0x12fa81c: ubfx            x4, x4, #0xc, #0x14
    // 0x12fa820: cmp             x4, #0xbb1
    // 0x12fa824: b.eq            #0x12fa83c
    // 0x12fa828: r8 = _ScaffoldLayout
    //     0x12fa828: add             x8, PP, #0x99, lsl #12  ; [pp+0x99788] Type: _ScaffoldLayout
    //     0x12fa82c: ldr             x8, [x8, #0x788]
    // 0x12fa830: r3 = Null
    //     0x12fa830: add             x3, PP, #0x99, lsl #12  ; [pp+0x99790] Null
    //     0x12fa834: ldr             x3, [x3, #0x790]
    // 0x12fa838: r0 = DefaultTypeTest()
    //     0x12fa838: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x12fa83c: ldur            x0, [fp, #-0x10]
    // 0x12fa840: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x12fa840: ldur            w1, [x0, #0x17]
    // 0x12fa844: DecompressPointer r1
    //     0x12fa844: add             x1, x1, HEAP, lsl #32
    // 0x12fa848: ldur            x2, [fp, #-8]
    // 0x12fa84c: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x12fa84c: ldur            w3, [x2, #0x17]
    // 0x12fa850: DecompressPointer r3
    //     0x12fa850: add             x3, x3, HEAP, lsl #32
    // 0x12fa854: stp             x3, x1, [SP]
    // 0x12fa858: r0 = ==()
    //     0x12fa858: bl              #0x1298c8c  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::==
    // 0x12fa85c: tbnz            w0, #4, #0x12fa8bc
    // 0x12fa860: ldur            x1, [fp, #-8]
    // 0x12fa864: ldur            x0, [fp, #-0x10]
    // 0x12fa868: LoadField: r2 = r0->field_1b
    //     0x12fa868: ldur            w2, [x0, #0x1b]
    // 0x12fa86c: DecompressPointer r2
    //     0x12fa86c: add             x2, x2, HEAP, lsl #32
    // 0x12fa870: LoadField: r3 = r1->field_1b
    //     0x12fa870: ldur            w3, [x1, #0x1b]
    // 0x12fa874: DecompressPointer r3
    //     0x12fa874: add             x3, x3, HEAP, lsl #32
    // 0x12fa878: stp             x3, x2, [SP]
    // 0x12fa87c: r0 = ==()
    //     0x12fa87c: bl              #0x1298c8c  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::==
    // 0x12fa880: tbnz            w0, #4, #0x12fa8bc
    // 0x12fa884: ldur            x2, [fp, #-8]
    // 0x12fa888: ldur            x1, [fp, #-0x10]
    // 0x12fa88c: LoadField: r3 = r1->field_1f
    //     0x12fa88c: ldur            w3, [x1, #0x1f]
    // 0x12fa890: DecompressPointer r3
    //     0x12fa890: add             x3, x3, HEAP, lsl #32
    // 0x12fa894: LoadField: r4 = r2->field_1f
    //     0x12fa894: ldur            w4, [x2, #0x1f]
    // 0x12fa898: DecompressPointer r4
    //     0x12fa898: add             x4, x4, HEAP, lsl #32
    // 0x12fa89c: cmp             w3, w4
    // 0x12fa8a0: b.ne            #0x12fa8bc
    // 0x12fa8a4: LoadField: r3 = r1->field_27
    //     0x12fa8a4: ldur            w3, [x1, #0x27]
    // 0x12fa8a8: DecompressPointer r3
    //     0x12fa8a8: add             x3, x3, HEAP, lsl #32
    // 0x12fa8ac: LoadField: r1 = r2->field_27
    //     0x12fa8ac: ldur            w1, [x2, #0x27]
    // 0x12fa8b0: DecompressPointer r1
    //     0x12fa8b0: add             x1, x1, HEAP, lsl #32
    // 0x12fa8b4: cmp             w3, w1
    // 0x12fa8b8: b.eq            #0x12fa8c4
    // 0x12fa8bc: r0 = true
    //     0x12fa8bc: add             x0, NULL, #0x20  ; true
    // 0x12fa8c0: b               #0x12fa8c8
    // 0x12fa8c4: r0 = false
    //     0x12fa8c4: add             x0, NULL, #0x30  ; false
    // 0x12fa8c8: LeaveFrame
    //     0x12fa8c8: mov             SP, fp
    //     0x12fa8cc: ldp             fp, lr, [SP], #0x10
    // 0x12fa8d0: ret
    //     0x12fa8d0: ret             
    // 0x12fa8d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12fa8d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12fa8d8: b               #0x12fa804
  }
}

// class id: 2994, size: 0x10, field offset: 0x8
//   const constructor, 
class ScaffoldGeometry extends Object {

  _ _scaleFloatingActionButton(/* No info */) {
    // ** addr: 0xae07b8, size: 0xd4
    // 0xae07b8: EnterFrame
    //     0xae07b8: stp             fp, lr, [SP, #-0x10]!
    //     0xae07bc: mov             fp, SP
    // 0xae07c0: AllocStack(0x18)
    //     0xae07c0: sub             SP, SP, #0x18
    // 0xae07c4: d1 = 1.000000
    //     0xae07c4: fmov            d1, #1.00000000
    // 0xae07c8: mov             x0, x1
    // 0xae07cc: stur            x1, [fp, #-0x10]
    // 0xae07d0: stur            d0, [fp, #-0x18]
    // 0xae07d4: CheckStackOverflow
    //     0xae07d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xae07d8: cmp             SP, x16
    //     0xae07dc: b.ls            #0xae0880
    // 0xae07e0: fcmp            d0, d1
    // 0xae07e4: b.ne            #0xae07f4
    // 0xae07e8: LeaveFrame
    //     0xae07e8: mov             SP, fp
    //     0xae07ec: ldp             fp, lr, [SP], #0x10
    // 0xae07f0: ret
    //     0xae07f0: ret             
    // 0xae07f4: d1 = 0.000000
    //     0xae07f4: eor             v1.16b, v1.16b, v1.16b
    // 0xae07f8: fcmp            d0, d1
    // 0xae07fc: b.ne            #0xae082c
    // 0xae0800: LoadField: r1 = r0->field_7
    //     0xae0800: ldur            w1, [x0, #7]
    // 0xae0804: DecompressPointer r1
    //     0xae0804: add             x1, x1, HEAP, lsl #32
    // 0xae0808: stur            x1, [fp, #-8]
    // 0xae080c: r0 = ScaffoldGeometry()
    //     0xae080c: bl              #0xae0ab8  ; AllocateScaffoldGeometryStub -> ScaffoldGeometry (size=0x10)
    // 0xae0810: mov             x1, x0
    // 0xae0814: ldur            x0, [fp, #-8]
    // 0xae0818: StoreField: r1->field_7 = r0
    //     0xae0818: stur            w0, [x1, #7]
    // 0xae081c: mov             x0, x1
    // 0xae0820: LeaveFrame
    //     0xae0820: mov             SP, fp
    //     0xae0824: ldp             fp, lr, [SP], #0x10
    // 0xae0828: ret
    //     0xae0828: ret             
    // 0xae082c: LoadField: r2 = r0->field_b
    //     0xae082c: ldur            w2, [x0, #0xb]
    // 0xae0830: DecompressPointer r2
    //     0xae0830: add             x2, x2, HEAP, lsl #32
    // 0xae0834: stur            x2, [fp, #-8]
    // 0xae0838: cmp             w2, NULL
    // 0xae083c: b.eq            #0xae0888
    // 0xae0840: mov             x1, x2
    // 0xae0844: r0 = center()
    //     0xae0844: bl              #0x869350  ; [dart:ui] Rect::center
    // 0xae0848: mov             x1, x0
    // 0xae084c: r2 = Instance_Size
    //     0xae084c: ldr             x2, [PP, #0x7f28]  ; [pp+0x7f28] Obj!Size@12a74d1
    // 0xae0850: r0 = &()
    //     0xae0850: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xae0854: mov             x1, x0
    // 0xae0858: ldur            x2, [fp, #-8]
    // 0xae085c: ldur            d0, [fp, #-0x18]
    // 0xae0860: r0 = lerp()
    //     0xae0860: bl              #0xae0924  ; [dart:ui] Rect::lerp
    // 0xae0864: ldur            x1, [fp, #-0x10]
    // 0xae0868: mov             x2, x0
    // 0xae086c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xae086c: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xae0870: r0 = copyWith()
    //     0xae0870: bl              #0xae088c  ; [package:flutter/src/material/scaffold.dart] ScaffoldGeometry::copyWith
    // 0xae0874: LeaveFrame
    //     0xae0874: mov             SP, fp
    //     0xae0878: ldp             fp, lr, [SP], #0x10
    // 0xae087c: ret
    //     0xae087c: ret             
    // 0xae0880: r0 = StackOverflowSharedWithFPURegs()
    //     0xae0880: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xae0884: b               #0xae07e0
    // 0xae0888: r0 = NullCastErrorSharedWithFPURegs()
    //     0xae0888: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  _ copyWith(/* No info */) {
    // ** addr: 0xae088c, size: 0x98
    // 0xae088c: EnterFrame
    //     0xae088c: stp             fp, lr, [SP, #-0x10]!
    //     0xae0890: mov             fp, SP
    // 0xae0894: AllocStack(0x10)
    //     0xae0894: sub             SP, SP, #0x10
    // 0xae0898: SetupParameters({dynamic bottomNavigationBarTop = Null /* r0 */})
    //     0xae0898: ldur            w0, [x4, #0x13]
    //     0xae089c: ldur            w3, [x4, #0x1f]
    //     0xae08a0: add             x3, x3, HEAP, lsl #32
    //     0xae08a4: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8fd68] "bottomNavigationBarTop"
    //     0xae08a8: ldr             x16, [x16, #0xd68]
    //     0xae08ac: cmp             w3, w16
    //     0xae08b0: b.ne            #0xae08cc
    //     0xae08b4: ldur            w3, [x4, #0x23]
    //     0xae08b8: add             x3, x3, HEAP, lsl #32
    //     0xae08bc: sub             w4, w0, w3
    //     0xae08c0: add             x0, fp, w4, sxtw #2
    //     0xae08c4: ldr             x0, [x0, #8]
    //     0xae08c8: b               #0xae08d0
    //     0xae08cc: mov             x0, NULL
    // 0xae08d0: cmp             w0, NULL
    // 0xae08d4: b.ne            #0xae08e0
    // 0xae08d8: LoadField: r0 = r1->field_7
    //     0xae08d8: ldur            w0, [x1, #7]
    // 0xae08dc: DecompressPointer r0
    //     0xae08dc: add             x0, x0, HEAP, lsl #32
    // 0xae08e0: stur            x0, [fp, #-0x10]
    // 0xae08e4: cmp             w2, NULL
    // 0xae08e8: b.ne            #0xae08fc
    // 0xae08ec: LoadField: r2 = r1->field_b
    //     0xae08ec: ldur            w2, [x1, #0xb]
    // 0xae08f0: DecompressPointer r2
    //     0xae08f0: add             x2, x2, HEAP, lsl #32
    // 0xae08f4: mov             x1, x2
    // 0xae08f8: b               #0xae0900
    // 0xae08fc: mov             x1, x2
    // 0xae0900: stur            x1, [fp, #-8]
    // 0xae0904: r0 = ScaffoldGeometry()
    //     0xae0904: bl              #0xae0ab8  ; AllocateScaffoldGeometryStub -> ScaffoldGeometry (size=0x10)
    // 0xae0908: ldur            x1, [fp, #-0x10]
    // 0xae090c: StoreField: r0->field_7 = r1
    //     0xae090c: stur            w1, [x0, #7]
    // 0xae0910: ldur            x1, [fp, #-8]
    // 0xae0914: StoreField: r0->field_b = r1
    //     0xae0914: stur            w1, [x0, #0xb]
    // 0xae0918: LeaveFrame
    //     0xae0918: mov             SP, fp
    //     0xae091c: ldp             fp, lr, [SP], #0x10
    // 0xae0920: ret
    //     0xae0920: ret             
  }
}

// class id: 2995, size: 0x2c, field offset: 0x8
//   const constructor, 
class ScaffoldPrelayoutGeometry extends Object {
}

// class id: 4490, size: 0x2c, field offset: 0x24
class _ScaffoldGeometryNotifier extends ChangeNotifier
    implements ValueListenable<X0> {

  ScaffoldGeometry value(_ScaffoldGeometryNotifier) {
    // ** addr: 0xae0720, size: 0x50
    // 0xae0720: EnterFrame
    //     0xae0720: stp             fp, lr, [SP, #-0x10]!
    //     0xae0724: mov             fp, SP
    // 0xae0728: CheckStackOverflow
    //     0xae0728: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xae072c: cmp             SP, x16
    //     0xae0730: b.ls            #0xae0764
    // 0xae0734: LoadField: r0 = r1->field_27
    //     0xae0734: ldur            w0, [x1, #0x27]
    // 0xae0738: DecompressPointer r0
    //     0xae0738: add             x0, x0, HEAP, lsl #32
    // 0xae073c: LoadField: r2 = r1->field_23
    //     0xae073c: ldur            w2, [x1, #0x23]
    // 0xae0740: DecompressPointer r2
    //     0xae0740: add             x2, x2, HEAP, lsl #32
    // 0xae0744: cmp             w2, NULL
    // 0xae0748: b.eq            #0xae076c
    // 0xae074c: LoadField: d0 = r2->field_7
    //     0xae074c: ldur            d0, [x2, #7]
    // 0xae0750: mov             x1, x0
    // 0xae0754: r0 = _scaleFloatingActionButton()
    //     0xae0754: bl              #0xae07b8  ; [package:flutter/src/material/scaffold.dart] ScaffoldGeometry::_scaleFloatingActionButton
    // 0xae0758: LeaveFrame
    //     0xae0758: mov             SP, fp
    //     0xae075c: ldp             fp, lr, [SP], #0x10
    // 0xae0760: ret
    //     0xae0760: ret             
    // 0xae0764: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae0764: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae0768: b               #0xae0734
    // 0xae076c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xae076c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  ScaffoldGeometry dyn:get:value(_ScaffoldGeometryNotifier) {
    // ** addr: 0xae0788, size: 0x48
    // 0xae0788: EnterFrame
    //     0xae0788: stp             fp, lr, [SP, #-0x10]!
    //     0xae078c: mov             fp, SP
    // 0xae0790: CheckStackOverflow
    //     0xae0790: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xae0794: cmp             SP, x16
    //     0xae0798: b.ls            #0xae07b0
    // 0xae079c: ldr             x1, [fp, #0x10]
    // 0xae07a0: r0 = value()
    //     0xae07a0: bl              #0xae0720  ; [package:flutter/src/material/scaffold.dart] _ScaffoldGeometryNotifier::value
    // 0xae07a4: LeaveFrame
    //     0xae07a4: mov             SP, fp
    //     0xae07a8: ldp             fp, lr, [SP], #0x10
    // 0xae07ac: ret
    //     0xae07ac: ret             
    // 0xae07b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae07b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae07b4: b               #0xae079c
  }
  _ _updateWith(/* No info */) {
    // ** addr: 0xf3d2e8, size: 0x190
    // 0xf3d2e8: EnterFrame
    //     0xf3d2e8: stp             fp, lr, [SP, #-0x10]!
    //     0xf3d2ec: mov             fp, SP
    // 0xf3d2f0: AllocStack(0x10)
    //     0xf3d2f0: sub             SP, SP, #0x10
    // 0xf3d2f4: SetupParameters(_ScaffoldGeometryNotifier this /* r1 => r3, fp-0x8 */, {dynamic bottomNavigationBarTop = Null /* r2 */, dynamic floatingActionButtonArea = Null /* r5 */, dynamic floatingActionButtonScale = Null /* r0 */})
    //     0xf3d2f4: mov             x3, x1
    //     0xf3d2f8: stur            x1, [fp, #-8]
    //     0xf3d2fc: ldur            w0, [x4, #0x13]
    //     0xf3d300: ldur            w1, [x4, #0x1f]
    //     0xf3d304: add             x1, x1, HEAP, lsl #32
    //     0xf3d308: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8fd68] "bottomNavigationBarTop"
    //     0xf3d30c: ldr             x16, [x16, #0xd68]
    //     0xf3d310: cmp             w1, w16
    //     0xf3d314: b.ne            #0xf3d338
    //     0xf3d318: ldur            w1, [x4, #0x23]
    //     0xf3d31c: add             x1, x1, HEAP, lsl #32
    //     0xf3d320: sub             w2, w0, w1
    //     0xf3d324: add             x1, fp, w2, sxtw #2
    //     0xf3d328: ldr             x1, [x1, #8]
    //     0xf3d32c: mov             x2, x1
    //     0xf3d330: mov             x1, #1
    //     0xf3d334: b               #0xf3d340
    //     0xf3d338: mov             x2, NULL
    //     0xf3d33c: mov             x1, #0
    //     0xf3d340: lsl             x5, x1, #1
    //     0xf3d344: lsl             w6, w5, #1
    //     0xf3d348: add             w7, w6, #8
    //     0xf3d34c: add             x16, x4, w7, sxtw #1
    //     0xf3d350: ldur            w8, [x16, #0xf]
    //     0xf3d354: add             x8, x8, HEAP, lsl #32
    //     0xf3d358: add             x16, PP, #0x99, lsl #12  ; [pp+0x99810] "floatingActionButtonArea"
    //     0xf3d35c: ldr             x16, [x16, #0x810]
    //     0xf3d360: cmp             w8, w16
    //     0xf3d364: b.ne            #0xf3d398
    //     0xf3d368: add             w1, w6, #0xa
    //     0xf3d36c: add             x16, x4, w1, sxtw #1
    //     0xf3d370: ldur            w6, [x16, #0xf]
    //     0xf3d374: add             x6, x6, HEAP, lsl #32
    //     0xf3d378: sub             w1, w0, w6
    //     0xf3d37c: add             x6, fp, w1, sxtw #2
    //     0xf3d380: ldr             x6, [x6, #8]
    //     0xf3d384: add             w1, w5, #2
    //     0xf3d388: sbfx            x5, x1, #1, #0x1f
    //     0xf3d38c: mov             x1, x5
    //     0xf3d390: mov             x5, x6
    //     0xf3d394: b               #0xf3d39c
    //     0xf3d398: mov             x5, NULL
    //     0xf3d39c: lsl             x6, x1, #1
    //     0xf3d3a0: lsl             w1, w6, #1
    //     0xf3d3a4: add             w6, w1, #8
    //     0xf3d3a8: add             x16, x4, w6, sxtw #1
    //     0xf3d3ac: ldur            w7, [x16, #0xf]
    //     0xf3d3b0: add             x7, x7, HEAP, lsl #32
    //     0xf3d3b4: add             x16, PP, #0x99, lsl #12  ; [pp+0x99818] "floatingActionButtonScale"
    //     0xf3d3b8: ldr             x16, [x16, #0x818]
    //     0xf3d3bc: cmp             w7, w16
    //     0xf3d3c0: b.ne            #0xf3d3e4
    //     0xf3d3c4: add             w6, w1, #0xa
    //     0xf3d3c8: add             x16, x4, w6, sxtw #1
    //     0xf3d3cc: ldur            w1, [x16, #0xf]
    //     0xf3d3d0: add             x1, x1, HEAP, lsl #32
    //     0xf3d3d4: sub             w4, w0, w1
    //     0xf3d3d8: add             x0, fp, w4, sxtw #2
    //     0xf3d3dc: ldr             x0, [x0, #8]
    //     0xf3d3e0: b               #0xf3d3e8
    //     0xf3d3e4: mov             x0, NULL
    // 0xf3d3e8: CheckStackOverflow
    //     0xf3d3e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3d3ec: cmp             SP, x16
    //     0xf3d3f0: b.ls            #0xf3d470
    // 0xf3d3f4: cmp             w0, NULL
    // 0xf3d3f8: b.ne            #0xf3d404
    // 0xf3d3fc: LoadField: r0 = r3->field_23
    //     0xf3d3fc: ldur            w0, [x3, #0x23]
    // 0xf3d400: DecompressPointer r0
    //     0xf3d400: add             x0, x0, HEAP, lsl #32
    // 0xf3d404: StoreField: r3->field_23 = r0
    //     0xf3d404: stur            w0, [x3, #0x23]
    //     0xf3d408: ldurb           w16, [x3, #-1]
    //     0xf3d40c: ldurb           w17, [x0, #-1]
    //     0xf3d410: and             x16, x17, x16, lsr #2
    //     0xf3d414: tst             x16, HEAP, lsr #32
    //     0xf3d418: b.eq            #0xf3d420
    //     0xf3d41c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xf3d420: LoadField: r1 = r3->field_27
    //     0xf3d420: ldur            w1, [x3, #0x27]
    // 0xf3d424: DecompressPointer r1
    //     0xf3d424: add             x1, x1, HEAP, lsl #32
    // 0xf3d428: str             x2, [SP]
    // 0xf3d42c: mov             x2, x5
    // 0xf3d430: r4 = const [0, 0x3, 0x1, 0x2, bottomNavigationBarTop, 0x2, null]
    //     0xf3d430: add             x4, PP, #0x99, lsl #12  ; [pp+0x99820] List(7) [0, 0x3, 0x1, 0x2, "bottomNavigationBarTop", 0x2, Null]
    //     0xf3d434: ldr             x4, [x4, #0x820]
    // 0xf3d438: r0 = copyWith()
    //     0xf3d438: bl              #0xae088c  ; [package:flutter/src/material/scaffold.dart] ScaffoldGeometry::copyWith
    // 0xf3d43c: ldur            x1, [fp, #-8]
    // 0xf3d440: StoreField: r1->field_27 = r0
    //     0xf3d440: stur            w0, [x1, #0x27]
    //     0xf3d444: ldurb           w16, [x1, #-1]
    //     0xf3d448: ldurb           w17, [x0, #-1]
    //     0xf3d44c: and             x16, x17, x16, lsr #2
    //     0xf3d450: tst             x16, HEAP, lsr #32
    //     0xf3d454: b.eq            #0xf3d45c
    //     0xf3d458: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf3d45c: r0 = notifyListeners()
    //     0xf3d45c: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xf3d460: r0 = Null
    //     0xf3d460: mov             x0, NULL
    // 0xf3d464: LeaveFrame
    //     0xf3d464: mov             SP, fp
    //     0xf3d468: ldp             fp, lr, [SP], #0x10
    // 0xf3d46c: ret
    //     0xf3d46c: ret             
    // 0xf3d470: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3d470: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3d474: b               #0xf3d3f4
  }
}

// class id: 5326, size: 0x18, field offset: 0x14
class _DismissDrawerAction extends DismissAction {

  _ invoke(/* No info */) {
    // ** addr: 0xb34a44, size: 0x80
    // 0xb34a44: EnterFrame
    //     0xb34a44: stp             fp, lr, [SP, #-0x10]!
    //     0xb34a48: mov             fp, SP
    // 0xb34a4c: AllocStack(0x10)
    //     0xb34a4c: sub             SP, SP, #0x10
    // 0xb34a50: SetupParameters(_DismissDrawerAction this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xb34a50: mov             x0, x1
    //     0xb34a54: stur            x1, [fp, #-8]
    //     0xb34a58: stur            x2, [fp, #-0x10]
    // 0xb34a5c: CheckStackOverflow
    //     0xb34a5c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb34a60: cmp             SP, x16
    //     0xb34a64: b.ls            #0xb34ab8
    // 0xb34a68: LoadField: r1 = r0->field_13
    //     0xb34a68: ldur            w1, [x0, #0x13]
    // 0xb34a6c: DecompressPointer r1
    //     0xb34a6c: add             x1, x1, HEAP, lsl #32
    // 0xb34a70: r0 = of()
    //     0xb34a70: bl              #0xb35cb4  ; [package:flutter/src/material/scaffold.dart] Scaffold::of
    // 0xb34a74: ldur            x1, [fp, #-8]
    // 0xb34a78: ldur            x2, [fp, #-0x10]
    // 0xb34a7c: stur            x0, [fp, #-8]
    // 0xb34a80: r0 = isEnabled()
    //     0xb34a80: bl              #0xbfcab0  ; [package:flutter/src/material/scaffold.dart] _DismissDrawerAction::isEnabled
    // 0xb34a84: tbnz            w0, #4, #0xb34aa8
    // 0xb34a88: ldur            x0, [fp, #-8]
    // 0xb34a8c: mov             x1, x0
    // 0xb34a90: r0 = closeDrawer()
    //     0xb34a90: bl              #0xb34ac4  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::closeDrawer
    // 0xb34a94: ldur            x1, [fp, #-8]
    // 0xb34a98: LoadField: r2 = r1->field_b
    //     0xb34a98: ldur            w2, [x1, #0xb]
    // 0xb34a9c: DecompressPointer r2
    //     0xb34a9c: add             x2, x2, HEAP, lsl #32
    // 0xb34aa0: cmp             w2, NULL
    // 0xb34aa4: b.eq            #0xb34ac0
    // 0xb34aa8: r0 = Null
    //     0xb34aa8: mov             x0, NULL
    // 0xb34aac: LeaveFrame
    //     0xb34aac: mov             SP, fp
    //     0xb34ab0: ldp             fp, lr, [SP], #0x10
    // 0xb34ab4: ret
    //     0xb34ab4: ret             
    // 0xb34ab8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb34ab8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb34abc: b               #0xb34a68
    // 0xb34ac0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb34ac0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ isEnabled(/* No info */) {
    // ** addr: 0xbfcab0, size: 0xcc
    // 0xbfcab0: EnterFrame
    //     0xbfcab0: stp             fp, lr, [SP, #-0x10]!
    //     0xbfcab4: mov             fp, SP
    // 0xbfcab8: AllocStack(0x10)
    //     0xbfcab8: sub             SP, SP, #0x10
    // 0xbfcabc: CheckStackOverflow
    //     0xbfcabc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbfcac0: cmp             SP, x16
    //     0xbfcac4: b.ls            #0xbfcb70
    // 0xbfcac8: LoadField: r0 = r1->field_13
    //     0xbfcac8: ldur            w0, [x1, #0x13]
    // 0xbfcacc: DecompressPointer r0
    //     0xbfcacc: add             x0, x0, HEAP, lsl #32
    // 0xbfcad0: mov             x1, x0
    // 0xbfcad4: r0 = of()
    //     0xbfcad4: bl              #0xb35cb4  ; [package:flutter/src/material/scaffold.dart] Scaffold::of
    // 0xbfcad8: mov             x3, x0
    // 0xbfcadc: stur            x3, [fp, #-0x10]
    // 0xbfcae0: LoadField: r0 = r3->field_3f
    //     0xbfcae0: ldur            w0, [x3, #0x3f]
    // 0xbfcae4: DecompressPointer r0
    //     0xbfcae4: add             x0, x0, HEAP, lsl #32
    // 0xbfcae8: LoadField: r4 = r0->field_33
    //     0xbfcae8: ldur            w4, [x0, #0x33]
    // 0xbfcaec: DecompressPointer r4
    //     0xbfcaec: add             x4, x4, HEAP, lsl #32
    // 0xbfcaf0: stur            x4, [fp, #-8]
    // 0xbfcaf4: cmp             w4, NULL
    // 0xbfcaf8: b.ne            #0xbfcb30
    // 0xbfcafc: LoadField: r2 = r0->field_23
    //     0xbfcafc: ldur            w2, [x0, #0x23]
    // 0xbfcb00: DecompressPointer r2
    //     0xbfcb00: add             x2, x2, HEAP, lsl #32
    // 0xbfcb04: mov             x0, x4
    // 0xbfcb08: r1 = Null
    //     0xbfcb08: mov             x1, NULL
    // 0xbfcb0c: cmp             w2, NULL
    // 0xbfcb10: b.eq            #0xbfcb30
    // 0xbfcb14: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xbfcb14: ldur            w4, [x2, #0x17]
    // 0xbfcb18: DecompressPointer r4
    //     0xbfcb18: add             x4, x4, HEAP, lsl #32
    // 0xbfcb1c: r8 = X0
    //     0xbfcb1c: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xbfcb20: LoadField: r9 = r4->field_7
    //     0xbfcb20: ldur            x9, [x4, #7]
    // 0xbfcb24: r3 = Null
    //     0xbfcb24: add             x3, PP, #0x8f, lsl #12  ; [pp+0x8fda8] Null
    //     0xbfcb28: ldr             x3, [x3, #0xda8]
    // 0xbfcb2c: blr             x9
    // 0xbfcb30: ldur            x0, [fp, #-8]
    // 0xbfcb34: tbz             w0, #4, #0xbfcb44
    // 0xbfcb38: ldur            x1, [fp, #-0x10]
    // 0xbfcb3c: r0 = isEndDrawerOpen()
    //     0xbfcb3c: bl              #0xbfcb7c  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::isEndDrawerOpen
    // 0xbfcb40: tbnz            w0, #4, #0xbfcb60
    // 0xbfcb44: ldur            x1, [fp, #-0x10]
    // 0xbfcb48: LoadField: r2 = r1->field_b
    //     0xbfcb48: ldur            w2, [x1, #0xb]
    // 0xbfcb4c: DecompressPointer r2
    //     0xbfcb4c: add             x2, x2, HEAP, lsl #32
    // 0xbfcb50: cmp             w2, NULL
    // 0xbfcb54: b.eq            #0xbfcb78
    // 0xbfcb58: r0 = true
    //     0xbfcb58: add             x0, NULL, #0x20  ; true
    // 0xbfcb5c: b               #0xbfcb64
    // 0xbfcb60: r0 = false
    //     0xbfcb60: add             x0, NULL, #0x30  ; false
    // 0xbfcb64: LeaveFrame
    //     0xbfcb64: mov             SP, fp
    //     0xbfcb68: ldp             fp, lr, [SP], #0x10
    // 0xbfcb6c: ret
    //     0xbfcb6c: ret             
    // 0xbfcb70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfcb70: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfcb74: b               #0xbfcac8
    // 0xbfcb78: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbfcb78: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 5457, size: 0x18, field offset: 0x14
class _StandardBottomSheetState extends State<dynamic> {

  _ build(/* No info */) {
    // ** addr: 0xdfbb08, size: 0x174
    // 0xdfbb08: EnterFrame
    //     0xdfbb08: stp             fp, lr, [SP, #-0x10]!
    //     0xdfbb0c: mov             fp, SP
    // 0xdfbb10: AllocStack(0x48)
    //     0xdfbb10: sub             SP, SP, #0x48
    // 0xdfbb14: SetupParameters(_StandardBottomSheetState this /* r1 => r0, fp-0x8 */)
    //     0xdfbb14: mov             x0, x1
    //     0xdfbb18: stur            x1, [fp, #-8]
    // 0xdfbb1c: CheckStackOverflow
    //     0xdfbb1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdfbb20: cmp             SP, x16
    //     0xdfbb24: b.ls            #0xdfbc70
    // 0xdfbb28: r1 = 1
    //     0xdfbb28: mov             x1, #1
    // 0xdfbb2c: r0 = AllocateContext()
    //     0xdfbb2c: bl              #0x13de838  ; AllocateContextStub
    // 0xdfbb30: ldur            x2, [fp, #-8]
    // 0xdfbb34: stur            x0, [fp, #-0x28]
    // 0xdfbb38: StoreField: r0->field_f = r2
    //     0xdfbb38: stur            w2, [x0, #0xf]
    // 0xdfbb3c: LoadField: r1 = r2->field_b
    //     0xdfbb3c: ldur            w1, [x2, #0xb]
    // 0xdfbb40: DecompressPointer r1
    //     0xdfbb40: add             x1, x1, HEAP, lsl #32
    // 0xdfbb44: cmp             w1, NULL
    // 0xdfbb48: b.eq            #0xdfbc78
    // 0xdfbb4c: LoadField: r3 = r1->field_b
    //     0xdfbb4c: ldur            w3, [x1, #0xb]
    // 0xdfbb50: DecompressPointer r3
    //     0xdfbb50: add             x3, x3, HEAP, lsl #32
    // 0xdfbb54: stur            x3, [fp, #-0x20]
    // 0xdfbb58: ArrayLoad: r4 = r1[0]  ; List_4
    //     0xdfbb58: ldur            w4, [x1, #0x17]
    // 0xdfbb5c: DecompressPointer r4
    //     0xdfbb5c: add             x4, x4, HEAP, lsl #32
    // 0xdfbb60: stur            x4, [fp, #-0x18]
    // 0xdfbb64: LoadField: r5 = r1->field_23
    //     0xdfbb64: ldur            w5, [x1, #0x23]
    // 0xdfbb68: DecompressPointer r5
    //     0xdfbb68: add             x5, x5, HEAP, lsl #32
    // 0xdfbb6c: stur            x5, [fp, #-0x10]
    // 0xdfbb70: r0 = BottomSheet()
    //     0xdfbb70: bl              #0xdec174  ; AllocateBottomSheetStub -> BottomSheet (size=0x48)
    // 0xdfbb74: mov             x3, x0
    // 0xdfbb78: ldur            x0, [fp, #-0x20]
    // 0xdfbb7c: stur            x3, [fp, #-0x30]
    // 0xdfbb80: StoreField: r3->field_b = r0
    //     0xdfbb80: stur            w0, [x3, #0xb]
    // 0xdfbb84: r1 = false
    //     0xdfbb84: add             x1, NULL, #0x30  ; false
    // 0xdfbb88: ArrayStore: r3[0] = r1  ; List_4
    //     0xdfbb88: stur            w1, [x3, #0x17]
    // 0xdfbb8c: ldur            x2, [fp, #-8]
    // 0xdfbb90: r1 = Function '_handleDragStart@89420462':.
    //     0xdfbb90: add             x1, PP, #0x99, lsl #12  ; [pp+0x99720] AnonymousClosure: (0xdfc2a0), of [package:flutter/src/material/scaffold.dart] _StandardBottomSheetState
    //     0xdfbb94: ldr             x1, [x1, #0x720]
    // 0xdfbb98: r0 = AllocateClosure()
    //     0xdfbb98: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdfbb9c: mov             x1, x0
    // 0xdfbba0: ldur            x0, [fp, #-0x30]
    // 0xdfbba4: StoreField: r0->field_27 = r1
    //     0xdfbba4: stur            w1, [x0, #0x27]
    // 0xdfbba8: ldur            x2, [fp, #-8]
    // 0xdfbbac: r1 = Function '_handleDragEnd@89420462':.
    //     0xdfbbac: add             x1, PP, #0x99, lsl #12  ; [pp+0x99728] AnonymousClosure: (0xdfc168), in [package:flutter/src/material/scaffold.dart] _StandardBottomSheetState::_handleDragEnd (0xdfc1fc)
    //     0xdfbbb0: ldr             x1, [x1, #0x728]
    // 0xdfbbb4: r0 = AllocateClosure()
    //     0xdfbbb4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdfbbb8: mov             x1, x0
    // 0xdfbbbc: ldur            x0, [fp, #-0x30]
    // 0xdfbbc0: StoreField: r0->field_2b = r1
    //     0xdfbbc0: stur            w1, [x0, #0x2b]
    // 0xdfbbc4: ldur            x1, [fp, #-0x18]
    // 0xdfbbc8: StoreField: r0->field_f = r1
    //     0xdfbbc8: stur            w1, [x0, #0xf]
    // 0xdfbbcc: ldur            x1, [fp, #-0x10]
    // 0xdfbbd0: StoreField: r0->field_13 = r1
    //     0xdfbbd0: stur            w1, [x0, #0x13]
    // 0xdfbbd4: ldur            x2, [fp, #-8]
    // 0xdfbbd8: r1 = Function 'extentChanged':.
    //     0xdfbbd8: add             x1, PP, #0x99, lsl #12  ; [pp+0x99730] AnonymousClosure: (0xdfbda4), in [package:flutter/src/material/scaffold.dart] _StandardBottomSheetState::extentChanged (0xdfbde0)
    //     0xdfbbdc: ldr             x1, [x1, #0x730]
    // 0xdfbbe0: r0 = AllocateClosure()
    //     0xdfbbe0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdfbbe4: r1 = <DraggableScrollableNotification>
    //     0xdfbbe4: add             x1, PP, #0x84, lsl #12  ; [pp+0x84c20] TypeArguments: <DraggableScrollableNotification>
    //     0xdfbbe8: ldr             x1, [x1, #0xc20]
    // 0xdfbbec: stur            x0, [fp, #-8]
    // 0xdfbbf0: r0 = NotificationListener()
    //     0xdfbbf0: bl              #0xd2ea9c  ; AllocateNotificationListenerStub -> NotificationListener<X0 bound Notification> (size=0x18)
    // 0xdfbbf4: mov             x1, x0
    // 0xdfbbf8: ldur            x0, [fp, #-8]
    // 0xdfbbfc: stur            x1, [fp, #-0x10]
    // 0xdfbc00: StoreField: r1->field_13 = r0
    //     0xdfbc00: stur            w0, [x1, #0x13]
    // 0xdfbc04: ldur            x0, [fp, #-0x30]
    // 0xdfbc08: StoreField: r1->field_b = r0
    //     0xdfbc08: stur            w0, [x1, #0xb]
    // 0xdfbc0c: r0 = Semantics()
    //     0xdfbc0c: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xdfbc10: stur            x0, [fp, #-8]
    // 0xdfbc14: r16 = true
    //     0xdfbc14: add             x16, NULL, #0x20  ; true
    // 0xdfbc18: stp             NULL, x16, [SP, #8]
    // 0xdfbc1c: ldur            x16, [fp, #-0x10]
    // 0xdfbc20: str             x16, [SP]
    // 0xdfbc24: mov             x1, x0
    // 0xdfbc28: r4 = const [0, 0x4, 0x3, 0x1, child, 0x3, container, 0x1, onDismiss, 0x2, null]
    //     0xdfbc28: add             x4, PP, #0x99, lsl #12  ; [pp+0x99738] List(11) [0, 0x4, 0x3, 0x1, "child", 0x3, "container", 0x1, "onDismiss", 0x2, Null]
    //     0xdfbc2c: ldr             x4, [x4, #0x738]
    // 0xdfbc30: r0 = Semantics()
    //     0xdfbc30: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xdfbc34: ldur            x2, [fp, #-0x28]
    // 0xdfbc38: r1 = Function '<anonymous closure>':.
    //     0xdfbc38: add             x1, PP, #0x99, lsl #12  ; [pp+0x99740] AnonymousClosure: (0xdfbca0), in [package:flutter/src/material/scaffold.dart] _StandardBottomSheetState::build (0xdfbb08)
    //     0xdfbc3c: ldr             x1, [x1, #0x740]
    // 0xdfbc40: r0 = AllocateClosure()
    //     0xdfbc40: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdfbc44: stur            x0, [fp, #-0x10]
    // 0xdfbc48: r0 = AnimatedBuilder()
    //     0xdfbc48: bl              #0x918e2c  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0xdfbc4c: ldur            x1, [fp, #-0x10]
    // 0xdfbc50: StoreField: r0->field_f = r1
    //     0xdfbc50: stur            w1, [x0, #0xf]
    // 0xdfbc54: ldur            x1, [fp, #-8]
    // 0xdfbc58: StoreField: r0->field_13 = r1
    //     0xdfbc58: stur            w1, [x0, #0x13]
    // 0xdfbc5c: ldur            x1, [fp, #-0x20]
    // 0xdfbc60: StoreField: r0->field_b = r1
    //     0xdfbc60: stur            w1, [x0, #0xb]
    // 0xdfbc64: LeaveFrame
    //     0xdfbc64: mov             SP, fp
    //     0xdfbc68: ldp             fp, lr, [SP], #0x10
    // 0xdfbc6c: ret
    //     0xdfbc6c: ret             
    // 0xdfbc70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdfbc70: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdfbc74: b               #0xdfbb28
    // 0xdfbc78: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfbc78: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Align <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0xdfbca0, size: 0x104
    // 0xdfbca0: EnterFrame
    //     0xdfbca0: stp             fp, lr, [SP, #-0x10]!
    //     0xdfbca4: mov             fp, SP
    // 0xdfbca8: AllocStack(0x8)
    //     0xdfbca8: sub             SP, SP, #8
    // 0xdfbcac: SetupParameters([dynamic _ /* r0 */])
    //     0xdfbcac: ldr             x0, [fp, #0x20]
    //     0xdfbcb0: ldur            w1, [x0, #0x17]
    //     0xdfbcb4: add             x1, x1, HEAP, lsl #32
    // 0xdfbcb8: CheckStackOverflow
    //     0xdfbcb8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdfbcbc: cmp             SP, x16
    //     0xdfbcc0: b.ls            #0xdfbd74
    // 0xdfbcc4: LoadField: r0 = r1->field_f
    //     0xdfbcc4: ldur            w0, [x1, #0xf]
    // 0xdfbcc8: DecompressPointer r0
    //     0xdfbcc8: add             x0, x0, HEAP, lsl #32
    // 0xdfbccc: LoadField: r1 = r0->field_13
    //     0xdfbccc: ldur            w1, [x0, #0x13]
    // 0xdfbcd0: DecompressPointer r1
    //     0xdfbcd0: add             x1, x1, HEAP, lsl #32
    // 0xdfbcd4: LoadField: r2 = r0->field_b
    //     0xdfbcd4: ldur            w2, [x0, #0xb]
    // 0xdfbcd8: DecompressPointer r2
    //     0xdfbcd8: add             x2, x2, HEAP, lsl #32
    // 0xdfbcdc: cmp             w2, NULL
    // 0xdfbce0: b.eq            #0xdfbd7c
    // 0xdfbce4: LoadField: r0 = r2->field_b
    //     0xdfbce4: ldur            w0, [x2, #0xb]
    // 0xdfbce8: DecompressPointer r0
    //     0xdfbce8: add             x0, x0, HEAP, lsl #32
    // 0xdfbcec: LoadField: r2 = r0->field_37
    //     0xdfbcec: ldur            w2, [x0, #0x37]
    // 0xdfbcf0: DecompressPointer r2
    //     0xdfbcf0: add             x2, x2, HEAP, lsl #32
    // 0xdfbcf4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfbcf8: cmp             w2, w16
    // 0xdfbcfc: b.eq            #0xdfbd80
    // 0xdfbd00: LoadField: d0 = r2->field_7
    //     0xdfbd00: ldur            d0, [x2, #7]
    // 0xdfbd04: r0 = LoadClassIdInstr(r1)
    //     0xdfbd04: ldur            x0, [x1, #-1]
    //     0xdfbd08: ubfx            x0, x0, #0xc, #0x14
    // 0xdfbd0c: r0 = GDT[cid_x0 + -0x1000]()
    //     0xdfbd0c: sub             lr, x0, #1, lsl #12
    //     0xdfbd10: ldr             lr, [x21, lr, lsl #3]
    //     0xdfbd14: blr             lr
    // 0xdfbd18: stur            d0, [fp, #-8]
    // 0xdfbd1c: r0 = Align()
    //     0xdfbd1c: bl              #0xb281f8  ; AllocateAlignStub -> Align (size=0x1c)
    // 0xdfbd20: r1 = Instance_AlignmentDirectional
    //     0xdfbd20: add             x1, PP, #0x15, lsl #12  ; [pp+0x158d8] Obj!AlignmentDirectional@129e611
    //     0xdfbd24: ldr             x1, [x1, #0x8d8]
    // 0xdfbd28: StoreField: r0->field_f = r1
    //     0xdfbd28: stur            w1, [x0, #0xf]
    // 0xdfbd2c: ldur            d0, [fp, #-8]
    // 0xdfbd30: r1 = inline_Allocate_Double()
    //     0xdfbd30: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xdfbd34: add             x1, x1, #0x10
    //     0xdfbd38: cmp             x2, x1
    //     0xdfbd3c: b.ls            #0xdfbd88
    //     0xdfbd40: str             x1, [THR, #0x60]  ; THR::top
    //     0xdfbd44: sub             x1, x1, #0xf
    //     0xdfbd48: mov             x2, #0xe19c
    //     0xdfbd4c: movk            x2, #3, lsl #16
    //     0xdfbd50: stur            x2, [x1, #-1]
    // 0xdfbd54: dmb             ishst
    // 0xdfbd58: StoreField: r1->field_7 = d0
    //     0xdfbd58: stur            d0, [x1, #7]
    // 0xdfbd5c: ArrayStore: r0[0] = r1  ; List_4
    //     0xdfbd5c: stur            w1, [x0, #0x17]
    // 0xdfbd60: ldr             x1, [fp, #0x10]
    // 0xdfbd64: StoreField: r0->field_b = r1
    //     0xdfbd64: stur            w1, [x0, #0xb]
    // 0xdfbd68: LeaveFrame
    //     0xdfbd68: mov             SP, fp
    //     0xdfbd6c: ldp             fp, lr, [SP], #0x10
    // 0xdfbd70: ret
    //     0xdfbd70: ret             
    // 0xdfbd74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdfbd74: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdfbd78: b               #0xdfbcc4
    // 0xdfbd7c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfbd7c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfbd80: r9 = _value
    //     0xdfbd80: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0xdfbd84: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdfbd84: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdfbd88: SaveReg d0
    //     0xdfbd88: str             q0, [SP, #-0x10]!
    // 0xdfbd8c: SaveReg r0
    //     0xdfbd8c: str             x0, [SP, #-8]!
    // 0xdfbd90: r0 = AllocateDouble()
    //     0xdfbd90: bl              #0x13df878  ; AllocateDoubleStub
    // 0xdfbd94: mov             x1, x0
    // 0xdfbd98: RestoreReg r0
    //     0xdfbd98: ldr             x0, [SP], #8
    // 0xdfbd9c: RestoreReg d0
    //     0xdfbd9c: ldr             q0, [SP], #0x10
    // 0xdfbda0: b               #0xdfbd58
  }
  [closure] bool extentChanged(dynamic, DraggableScrollableNotification) {
    // ** addr: 0xdfbda4, size: 0x3c
    // 0xdfbda4: EnterFrame
    //     0xdfbda4: stp             fp, lr, [SP, #-0x10]!
    //     0xdfbda8: mov             fp, SP
    // 0xdfbdac: ldr             x0, [fp, #0x18]
    // 0xdfbdb0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdfbdb0: ldur            w1, [x0, #0x17]
    // 0xdfbdb4: DecompressPointer r1
    //     0xdfbdb4: add             x1, x1, HEAP, lsl #32
    // 0xdfbdb8: CheckStackOverflow
    //     0xdfbdb8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdfbdbc: cmp             SP, x16
    //     0xdfbdc0: b.ls            #0xdfbdd8
    // 0xdfbdc4: ldr             x2, [fp, #0x10]
    // 0xdfbdc8: r0 = extentChanged()
    //     0xdfbdc8: bl              #0xdfbde0  ; [package:flutter/src/material/scaffold.dart] _StandardBottomSheetState::extentChanged
    // 0xdfbdcc: LeaveFrame
    //     0xdfbdcc: mov             SP, fp
    //     0xdfbdd0: ldp             fp, lr, [SP], #0x10
    // 0xdfbdd4: ret
    //     0xdfbdd4: ret             
    // 0xdfbdd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdfbdd8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdfbddc: b               #0xdfbdc4
  }
  _ extentChanged(/* No info */) {
    // ** addr: 0xdfbde0, size: 0x1a4
    // 0xdfbde0: EnterFrame
    //     0xdfbde0: stp             fp, lr, [SP, #-0x10]!
    //     0xdfbde4: mov             fp, SP
    // 0xdfbde8: AllocStack(0x20)
    //     0xdfbde8: sub             SP, SP, #0x20
    // 0xdfbdec: d0 = 1.000000
    //     0xdfbdec: fmov            d0, #1.00000000
    // 0xdfbdf0: mov             x0, x1
    // 0xdfbdf4: stur            x1, [fp, #-8]
    // 0xdfbdf8: CheckStackOverflow
    //     0xdfbdf8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdfbdfc: cmp             SP, x16
    //     0xdfbe00: b.ls            #0xdfbf38
    // 0xdfbe04: LoadField: d1 = r2->field_f
    //     0xdfbe04: ldur            d1, [x2, #0xf]
    // 0xdfbe08: stur            d1, [fp, #-0x20]
    // 0xdfbe0c: fsub            d2, d0, d1
    // 0xdfbe10: stur            d2, [fp, #-0x18]
    // 0xdfbe14: LoadField: r1 = r0->field_f
    //     0xdfbe14: ldur            w1, [x0, #0xf]
    // 0xdfbe18: DecompressPointer r1
    //     0xdfbe18: add             x1, x1, HEAP, lsl #32
    // 0xdfbe1c: cmp             w1, NULL
    // 0xdfbe20: b.eq            #0xdfbf40
    // 0xdfbe24: r0 = of()
    //     0xdfbe24: bl              #0xb35cb4  ; [package:flutter/src/material/scaffold.dart] Scaffold::of
    // 0xdfbe28: ldur            d1, [fp, #-0x18]
    // 0xdfbe2c: d0 = 0.300000
    //     0xdfbe2c: add             x17, PP, #0x13, lsl #12  ; [pp+0x13a88] IMM: double(0.3) from 0x3fd3333333333333
    //     0xdfbe30: ldr             d0, [x17, #0xa88]
    // 0xdfbe34: stur            x0, [fp, #-0x10]
    // 0xdfbe38: fcmp            d0, d1
    // 0xdfbe3c: b.le            #0xdfbebc
    // 0xdfbe40: d2 = 10.000000
    //     0xdfbe40: fmov            d2, #10.00000000
    // 0xdfbe44: LoadField: r1 = r0->field_73
    //     0xdfbe44: ldur            w1, [x0, #0x73]
    // 0xdfbe48: DecompressPointer r1
    //     0xdfbe48: add             x1, x1, HEAP, lsl #32
    // 0xdfbe4c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfbe50: cmp             w1, w16
    // 0xdfbe54: b.eq            #0xdfbf44
    // 0xdfbe58: fmul            d3, d1, d0
    // 0xdfbe5c: fmul            d4, d3, d2
    // 0xdfbe60: r2 = inline_Allocate_Double()
    //     0xdfbe60: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xdfbe64: add             x2, x2, #0x10
    //     0xdfbe68: cmp             x3, x2
    //     0xdfbe6c: b.ls            #0xdfbf50
    //     0xdfbe70: str             x2, [THR, #0x60]  ; THR::top
    //     0xdfbe74: sub             x2, x2, #0xf
    //     0xdfbe78: mov             x3, #0xe19c
    //     0xdfbe7c: movk            x3, #3, lsl #16
    //     0xdfbe80: stur            x3, [x2, #-1]
    // 0xdfbe84: dmb             ishst
    // 0xdfbe88: StoreField: r2->field_7 = d4
    //     0xdfbe88: stur            d4, [x2, #7]
    // 0xdfbe8c: r0 = value=()
    //     0xdfbe8c: bl              #0x829534  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0xdfbe90: ldur            d1, [fp, #-0x18]
    // 0xdfbe94: d0 = 0.300000
    //     0xdfbe94: add             x17, PP, #0x13, lsl #12  ; [pp+0x13a88] IMM: double(0.3) from 0x3fd3333333333333
    //     0xdfbe98: ldr             d0, [x17, #0xa88]
    // 0xdfbe9c: fdiv            d2, d1, d0
    // 0xdfbea0: d0 = 1.000000
    //     0xdfbea0: fmov            d0, #1.00000000
    // 0xdfbea4: fsub            d1, d0, d2
    // 0xdfbea8: ldur            x1, [fp, #-0x10]
    // 0xdfbeac: mov             v0.16b, v1.16b
    // 0xdfbeb0: r2 = true
    //     0xdfbeb0: add             x2, NULL, #0x20  ; true
    // 0xdfbeb4: r0 = showBodyScrim()
    //     0xdfbeb4: bl              #0xdfc020  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::showBodyScrim
    // 0xdfbeb8: b               #0xdfbee8
    // 0xdfbebc: LoadField: r1 = r0->field_73
    //     0xdfbebc: ldur            w1, [x0, #0x73]
    // 0xdfbec0: DecompressPointer r1
    //     0xdfbec0: add             x1, x1, HEAP, lsl #32
    // 0xdfbec4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfbec8: cmp             w1, w16
    // 0xdfbecc: b.eq            #0xdfbf74
    // 0xdfbed0: r2 = 1.000000
    //     0xdfbed0: ldr             x2, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xdfbed4: r0 = value=()
    //     0xdfbed4: bl              #0x829534  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0xdfbed8: ldur            x1, [fp, #-0x10]
    // 0xdfbedc: r2 = false
    //     0xdfbedc: add             x2, NULL, #0x30  ; false
    // 0xdfbee0: d0 = 0.000000
    //     0xdfbee0: eor             v0.16b, v0.16b, v0.16b
    // 0xdfbee4: r0 = showBodyScrim()
    //     0xdfbee4: bl              #0xdfc020  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::showBodyScrim
    // 0xdfbee8: ldur            d0, [fp, #-0x20]
    // 0xdfbeec: d1 = 0.200000
    //     0xdfbeec: add             x17, PP, #0x13, lsl #12  ; [pp+0x13230] IMM: double(0.2) from 0x3fc999999999999a
    //     0xdfbef0: ldr             d1, [x17, #0x230]
    // 0xdfbef4: fcmp            d0, d1
    // 0xdfbef8: b.ne            #0xdfbf28
    // 0xdfbefc: ldur            x0, [fp, #-0x10]
    // 0xdfbf00: LoadField: r1 = r0->field_b
    //     0xdfbf00: ldur            w1, [x0, #0xb]
    // 0xdfbf04: DecompressPointer r1
    //     0xdfbf04: add             x1, x1, HEAP, lsl #32
    // 0xdfbf08: cmp             w1, NULL
    // 0xdfbf0c: b.eq            #0xdfbf80
    // 0xdfbf10: LoadField: r0 = r1->field_53
    //     0xdfbf10: ldur            w0, [x1, #0x53]
    // 0xdfbf14: DecompressPointer r0
    //     0xdfbf14: add             x0, x0, HEAP, lsl #32
    // 0xdfbf18: cmp             w0, NULL
    // 0xdfbf1c: b.ne            #0xdfbf28
    // 0xdfbf20: ldur            x1, [fp, #-8]
    // 0xdfbf24: r0 = close()
    //     0xdfbf24: bl              #0xdfbf84  ; [package:flutter/src/material/scaffold.dart] _StandardBottomSheetState::close
    // 0xdfbf28: r0 = false
    //     0xdfbf28: add             x0, NULL, #0x30  ; false
    // 0xdfbf2c: LeaveFrame
    //     0xdfbf2c: mov             SP, fp
    //     0xdfbf30: ldp             fp, lr, [SP], #0x10
    // 0xdfbf34: ret
    //     0xdfbf34: ret             
    // 0xdfbf38: r0 = StackOverflowSharedWithFPURegs()
    //     0xdfbf38: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xdfbf3c: b               #0xdfbe04
    // 0xdfbf40: r0 = NullCastErrorSharedWithFPURegs()
    //     0xdfbf40: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xdfbf44: r9 = _floatingActionButtonVisibilityController
    //     0xdfbf44: add             x9, PP, #0x84, lsl #12  ; [pp+0x84b68] Field <ScaffoldState._floatingActionButtonVisibilityController@89420462>: late (offset: 0x74)
    //     0xdfbf48: ldr             x9, [x9, #0xb68]
    // 0xdfbf4c: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xdfbf4c: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xdfbf50: stp             q1, q4, [SP, #-0x20]!
    // 0xdfbf54: SaveReg d0
    //     0xdfbf54: str             q0, [SP, #-0x10]!
    // 0xdfbf58: stp             x0, x1, [SP, #-0x10]!
    // 0xdfbf5c: r0 = AllocateDouble()
    //     0xdfbf5c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xdfbf60: mov             x2, x0
    // 0xdfbf64: ldp             x0, x1, [SP], #0x10
    // 0xdfbf68: RestoreReg d0
    //     0xdfbf68: ldr             q0, [SP], #0x10
    // 0xdfbf6c: ldp             q1, q4, [SP], #0x20
    // 0xdfbf70: b               #0xdfbe88
    // 0xdfbf74: r9 = _floatingActionButtonVisibilityController
    //     0xdfbf74: add             x9, PP, #0x84, lsl #12  ; [pp+0x84b68] Field <ScaffoldState._floatingActionButtonVisibilityController@89420462>: late (offset: 0x74)
    //     0xdfbf78: ldr             x9, [x9, #0xb68]
    // 0xdfbf7c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdfbf7c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xdfbf80: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfbf80: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ close(/* No info */) {
    // ** addr: 0xdfbf84, size: 0x9c
    // 0xdfbf84: EnterFrame
    //     0xdfbf84: stp             fp, lr, [SP, #-0x10]!
    //     0xdfbf88: mov             fp, SP
    // 0xdfbf8c: AllocStack(0x10)
    //     0xdfbf8c: sub             SP, SP, #0x10
    // 0xdfbf90: SetupParameters(_StandardBottomSheetState this /* r1 => r0, fp-0x8 */)
    //     0xdfbf90: mov             x0, x1
    //     0xdfbf94: stur            x1, [fp, #-8]
    // 0xdfbf98: CheckStackOverflow
    //     0xdfbf98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdfbf9c: cmp             SP, x16
    //     0xdfbfa0: b.ls            #0xdfc00c
    // 0xdfbfa4: LoadField: r1 = r0->field_b
    //     0xdfbfa4: ldur            w1, [x0, #0xb]
    // 0xdfbfa8: DecompressPointer r1
    //     0xdfbfa8: add             x1, x1, HEAP, lsl #32
    // 0xdfbfac: cmp             w1, NULL
    // 0xdfbfb0: b.eq            #0xdfc014
    // 0xdfbfb4: LoadField: r2 = r1->field_b
    //     0xdfbfb4: ldur            w2, [x1, #0xb]
    // 0xdfbfb8: DecompressPointer r2
    //     0xdfbfb8: add             x2, x2, HEAP, lsl #32
    // 0xdfbfbc: mov             x1, x2
    // 0xdfbfc0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xdfbfc0: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xdfbfc4: r0 = reverse()
    //     0xdfbfc4: bl              #0x8c8688  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0xdfbfc8: ldur            x0, [fp, #-8]
    // 0xdfbfcc: LoadField: r1 = r0->field_b
    //     0xdfbfcc: ldur            w1, [x0, #0xb]
    // 0xdfbfd0: DecompressPointer r1
    //     0xdfbfd0: add             x1, x1, HEAP, lsl #32
    // 0xdfbfd4: cmp             w1, NULL
    // 0xdfbfd8: b.eq            #0xdfc018
    // 0xdfbfdc: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xdfbfdc: ldur            w0, [x1, #0x17]
    // 0xdfbfe0: DecompressPointer r0
    //     0xdfbfe0: add             x0, x0, HEAP, lsl #32
    // 0xdfbfe4: cmp             w0, NULL
    // 0xdfbfe8: b.eq            #0xdfc01c
    // 0xdfbfec: str             x0, [SP]
    // 0xdfbff0: ClosureCall
    //     0xdfbff0: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xdfbff4: ldur            x2, [x0, #0x1f]
    //     0xdfbff8: blr             x2
    // 0xdfbffc: r0 = Null
    //     0xdfbffc: mov             x0, NULL
    // 0xdfc000: LeaveFrame
    //     0xdfc000: mov             SP, fp
    //     0xdfc004: ldp             fp, lr, [SP], #0x10
    // 0xdfc008: ret
    //     0xdfc008: ret             
    // 0xdfc00c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdfc00c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdfc010: b               #0xdfbfa4
    // 0xdfc014: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfc014: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfc018: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfc018: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfc01c: r0 = NullErrorSharedWithoutFPURegs()
    //     0xdfc01c: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleDragEnd(dynamic, DragEndDetails, {bool? isClosing}) {
    // ** addr: 0xdfc168, size: 0x94
    // 0xdfc168: EnterFrame
    //     0xdfc168: stp             fp, lr, [SP, #-0x10]!
    //     0xdfc16c: mov             fp, SP
    // 0xdfc170: AllocStack(0x8)
    //     0xdfc170: sub             SP, SP, #8
    // 0xdfc174: SetupParameters(_StandardBottomSheetState this /* r2 */, dynamic _ /* r3 */, {dynamic isClosing = Null /* r0 */})
    //     0xdfc174: ldur            w0, [x4, #0x13]
    //     0xdfc178: sub             x1, x0, #4
    //     0xdfc17c: add             x2, fp, w1, sxtw #2
    //     0xdfc180: ldr             x2, [x2, #0x18]
    //     0xdfc184: add             x3, fp, w1, sxtw #2
    //     0xdfc188: ldr             x3, [x3, #0x10]
    //     0xdfc18c: ldur            w1, [x4, #0x1f]
    //     0xdfc190: add             x1, x1, HEAP, lsl #32
    //     0xdfc194: add             x16, PP, #0x99, lsl #12  ; [pp+0x99748] "isClosing"
    //     0xdfc198: ldr             x16, [x16, #0x748]
    //     0xdfc19c: cmp             w1, w16
    //     0xdfc1a0: b.ne            #0xdfc1bc
    //     0xdfc1a4: ldur            w1, [x4, #0x23]
    //     0xdfc1a8: add             x1, x1, HEAP, lsl #32
    //     0xdfc1ac: sub             w4, w0, w1
    //     0xdfc1b0: add             x0, fp, w4, sxtw #2
    //     0xdfc1b4: ldr             x0, [x0, #8]
    //     0xdfc1b8: b               #0xdfc1c0
    //     0xdfc1bc: mov             x0, NULL
    //     0xdfc1c0: ldur            w1, [x2, #0x17]
    //     0xdfc1c4: add             x1, x1, HEAP, lsl #32
    // 0xdfc1c8: CheckStackOverflow
    //     0xdfc1c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdfc1cc: cmp             SP, x16
    //     0xdfc1d0: b.ls            #0xdfc1f4
    // 0xdfc1d4: str             x0, [SP]
    // 0xdfc1d8: mov             x2, x3
    // 0xdfc1dc: r4 = const [0, 0x3, 0x1, 0x2, isClosing, 0x2, null]
    //     0xdfc1dc: add             x4, PP, #0x99, lsl #12  ; [pp+0x99750] List(7) [0, 0x3, 0x1, 0x2, "isClosing", 0x2, Null]
    //     0xdfc1e0: ldr             x4, [x4, #0x750]
    // 0xdfc1e4: r0 = _handleDragEnd()
    //     0xdfc1e4: bl              #0xdfc1fc  ; [package:flutter/src/material/scaffold.dart] _StandardBottomSheetState::_handleDragEnd
    // 0xdfc1e8: LeaveFrame
    //     0xdfc1e8: mov             SP, fp
    //     0xdfc1ec: ldp             fp, lr, [SP], #0x10
    // 0xdfc1f0: ret
    //     0xdfc1f0: ret             
    // 0xdfc1f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdfc1f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdfc1f8: b               #0xdfc1d4
  }
  _ _handleDragEnd(/* No info */) {
    // ** addr: 0xdfc1fc, size: 0xa4
    // 0xdfc1fc: EnterFrame
    //     0xdfc1fc: stp             fp, lr, [SP, #-0x10]!
    //     0xdfc200: mov             fp, SP
    // 0xdfc204: AllocStack(0x10)
    //     0xdfc204: sub             SP, SP, #0x10
    // 0xdfc208: SetupParameters(_StandardBottomSheetState this /* r1 => r0, fp-0x8 */)
    //     0xdfc208: mov             x0, x1
    //     0xdfc20c: stur            x1, [fp, #-8]
    // 0xdfc210: LoadField: r1 = r0->field_b
    //     0xdfc210: ldur            w1, [x0, #0xb]
    // 0xdfc214: DecompressPointer r1
    //     0xdfc214: add             x1, x1, HEAP, lsl #32
    // 0xdfc218: cmp             w1, NULL
    // 0xdfc21c: b.eq            #0xdfc294
    // 0xdfc220: LoadField: r2 = r1->field_b
    //     0xdfc220: ldur            w2, [x1, #0xb]
    // 0xdfc224: DecompressPointer r2
    //     0xdfc224: add             x2, x2, HEAP, lsl #32
    // 0xdfc228: LoadField: r1 = r2->field_37
    //     0xdfc228: ldur            w1, [x2, #0x37]
    // 0xdfc22c: DecompressPointer r1
    //     0xdfc22c: add             x1, x1, HEAP, lsl #32
    // 0xdfc230: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfc234: cmp             w1, w16
    // 0xdfc238: b.eq            #0xdfc298
    // 0xdfc23c: LoadField: d0 = r1->field_7
    //     0xdfc23c: ldur            d0, [x1, #7]
    // 0xdfc240: stur            d0, [fp, #-0x10]
    // 0xdfc244: r1 = <double>
    //     0xdfc244: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xdfc248: r0 = Split()
    //     0xdfc248: bl              #0xdec6f4  ; AllocateSplitStub -> Split (size=0x1c)
    // 0xdfc24c: ldur            d0, [fp, #-0x10]
    // 0xdfc250: StoreField: r0->field_b = d0
    //     0xdfc250: stur            d0, [x0, #0xb]
    // 0xdfc254: r1 = Instance__Linear
    //     0xdfc254: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] Obj!_Linear@129fef1
    // 0xdfc258: StoreField: r0->field_13 = r1
    //     0xdfc258: stur            w1, [x0, #0x13]
    // 0xdfc25c: r1 = Instance_Cubic
    //     0xdfc25c: ldr             x1, [PP, #0x5660]  ; [pp+0x5660] Obj!Cubic@129f451
    // 0xdfc260: ArrayStore: r0[0] = r1  ; List_4
    //     0xdfc260: stur            w1, [x0, #0x17]
    // 0xdfc264: ldur            x1, [fp, #-8]
    // 0xdfc268: StoreField: r1->field_13 = r0
    //     0xdfc268: stur            w0, [x1, #0x13]
    //     0xdfc26c: ldurb           w16, [x1, #-1]
    //     0xdfc270: ldurb           w17, [x0, #-1]
    //     0xdfc274: and             x16, x17, x16, lsr #2
    //     0xdfc278: tst             x16, HEAP, lsr #32
    //     0xdfc27c: b.eq            #0xdfc284
    //     0xdfc280: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xdfc284: r0 = Null
    //     0xdfc284: mov             x0, NULL
    // 0xdfc288: LeaveFrame
    //     0xdfc288: mov             SP, fp
    //     0xdfc28c: ldp             fp, lr, [SP], #0x10
    // 0xdfc290: ret
    //     0xdfc290: ret             
    // 0xdfc294: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfc294: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdfc298: r9 = _value
    //     0xdfc298: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0xdfc29c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xdfc29c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleDragStart(dynamic, DragStartDetails) {
    // ** addr: 0xdfc2a0, size: 0x1c
    // 0xdfc2a0: r1 = Instance__Linear
    //     0xdfc2a0: ldr             x1, [PP, #0x5168]  ; [pp+0x5168] Obj!_Linear@129fef1
    // 0xdfc2a4: ldr             x2, [SP, #8]
    // 0xdfc2a8: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xdfc2a8: ldur            w3, [x2, #0x17]
    // 0xdfc2ac: DecompressPointer r3
    //     0xdfc2ac: add             x3, x3, HEAP, lsl #32
    // 0xdfc2b0: StoreField: r3->field_13 = r1
    //     0xdfc2b0: stur            w1, [x3, #0x13]
    // 0xdfc2b4: r0 = Null
    //     0xdfc2b4: mov             x0, NULL
    // 0xdfc2b8: ret
    //     0xdfc2b8: ret             
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf6e448, size: 0xa4
    // 0xf6e448: EnterFrame
    //     0xf6e448: stp             fp, lr, [SP, #-0x10]!
    //     0xf6e44c: mov             fp, SP
    // 0xf6e450: AllocStack(0x10)
    //     0xf6e450: sub             SP, SP, #0x10
    // 0xf6e454: SetupParameters(_StandardBottomSheetState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xf6e454: mov             x0, x2
    //     0xf6e458: mov             x4, x1
    //     0xf6e45c: mov             x3, x2
    //     0xf6e460: stur            x1, [fp, #-8]
    //     0xf6e464: stur            x2, [fp, #-0x10]
    // 0xf6e468: r2 = Null
    //     0xf6e468: mov             x2, NULL
    // 0xf6e46c: r1 = Null
    //     0xf6e46c: mov             x1, NULL
    // 0xf6e470: r4 = 60
    //     0xf6e470: mov             x4, #0x3c
    // 0xf6e474: branchIfSmi(r0, 0xf6e480)
    //     0xf6e474: tbz             w0, #0, #0xf6e480
    // 0xf6e478: r4 = LoadClassIdInstr(r0)
    //     0xf6e478: ldur            x4, [x0, #-1]
    //     0xf6e47c: ubfx            x4, x4, #0xc, #0x14
    // 0xf6e480: r17 = 6436
    //     0xf6e480: mov             x17, #0x1924
    // 0xf6e484: cmp             x4, x17
    // 0xf6e488: b.eq            #0xf6e4a0
    // 0xf6e48c: r8 = _StandardBottomSheet
    //     0xf6e48c: add             x8, PP, #0x99, lsl #12  ; [pp+0x99758] Type: _StandardBottomSheet
    //     0xf6e490: ldr             x8, [x8, #0x758]
    // 0xf6e494: r3 = Null
    //     0xf6e494: add             x3, PP, #0x99, lsl #12  ; [pp+0x99760] Null
    //     0xf6e498: ldr             x3, [x3, #0x760]
    // 0xf6e49c: r0 = _StandardBottomSheet()
    //     0xf6e49c: bl              #0xdfbc7c  ; IsType__StandardBottomSheet_Stub
    // 0xf6e4a0: ldur            x0, [fp, #-8]
    // 0xf6e4a4: LoadField: r2 = r0->field_7
    //     0xf6e4a4: ldur            w2, [x0, #7]
    // 0xf6e4a8: DecompressPointer r2
    //     0xf6e4a8: add             x2, x2, HEAP, lsl #32
    // 0xf6e4ac: ldur            x0, [fp, #-0x10]
    // 0xf6e4b0: r1 = Null
    //     0xf6e4b0: mov             x1, NULL
    // 0xf6e4b4: cmp             w2, NULL
    // 0xf6e4b8: b.eq            #0xf6e4dc
    // 0xf6e4bc: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf6e4bc: ldur            w4, [x2, #0x17]
    // 0xf6e4c0: DecompressPointer r4
    //     0xf6e4c0: add             x4, x4, HEAP, lsl #32
    // 0xf6e4c4: r8 = X0 bound StatefulWidget
    //     0xf6e4c4: add             x8, PP, #0x12, lsl #12  ; [pp+0x12498] TypeParameter: X0 bound StatefulWidget
    //     0xf6e4c8: ldr             x8, [x8, #0x498]
    // 0xf6e4cc: LoadField: r9 = r4->field_7
    //     0xf6e4cc: ldur            x9, [x4, #7]
    // 0xf6e4d0: r3 = Null
    //     0xf6e4d0: add             x3, PP, #0x99, lsl #12  ; [pp+0x99770] Null
    //     0xf6e4d4: ldr             x3, [x3, #0x770]
    // 0xf6e4d8: blr             x9
    // 0xf6e4dc: r0 = Null
    //     0xf6e4dc: mov             x0, NULL
    // 0xf6e4e0: LeaveFrame
    //     0xf6e4e0: mov             SP, fp
    //     0xf6e4e4: ldp             fp, lr, [SP], #0x10
    // 0xf6e4e8: ret
    //     0xf6e4e8: ret             
  }
  _ initState(/* No info */) {
    // ** addr: 0xf9100c, size: 0x6c
    // 0xf9100c: EnterFrame
    //     0xf9100c: stp             fp, lr, [SP, #-0x10]!
    //     0xf91010: mov             fp, SP
    // 0xf91014: AllocStack(0x8)
    //     0xf91014: sub             SP, SP, #8
    // 0xf91018: SetupParameters(_StandardBottomSheetState this /* r1 => r2 */)
    //     0xf91018: mov             x2, x1
    // 0xf9101c: CheckStackOverflow
    //     0xf9101c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf91020: cmp             SP, x16
    //     0xf91024: b.ls            #0xf9106c
    // 0xf91028: LoadField: r0 = r2->field_b
    //     0xf91028: ldur            w0, [x2, #0xb]
    // 0xf9102c: DecompressPointer r0
    //     0xf9102c: add             x0, x0, HEAP, lsl #32
    // 0xf91030: cmp             w0, NULL
    // 0xf91034: b.eq            #0xf91074
    // 0xf91038: LoadField: r3 = r0->field_b
    //     0xf91038: ldur            w3, [x0, #0xb]
    // 0xf9103c: DecompressPointer r3
    //     0xf9103c: add             x3, x3, HEAP, lsl #32
    // 0xf91040: stur            x3, [fp, #-8]
    // 0xf91044: r1 = Function '_handleStatusChange@89420462':.
    //     0xf91044: add             x1, PP, #0x99, lsl #12  ; [pp+0x99780] AnonymousClosure: (0xf91078), in [package:flutter/src/material/scaffold.dart] _StandardBottomSheetState::_handleStatusChange (0xf910b4)
    //     0xf91048: ldr             x1, [x1, #0x780]
    // 0xf9104c: r0 = AllocateClosure()
    //     0xf9104c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf91050: ldur            x1, [fp, #-8]
    // 0xf91054: mov             x2, x0
    // 0xf91058: r0 = addStatusListener()
    //     0xf91058: bl              #0x1254cc0  ; [dart:mixin_deduplication] _MixinApplication456&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::addStatusListener
    // 0xf9105c: r0 = Null
    //     0xf9105c: mov             x0, NULL
    // 0xf91060: LeaveFrame
    //     0xf91060: mov             SP, fp
    //     0xf91064: ldp             fp, lr, [SP], #0x10
    // 0xf91068: ret
    //     0xf91068: ret             
    // 0xf9106c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf9106c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf91070: b               #0xf91028
    // 0xf91074: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf91074: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleStatusChange(dynamic, AnimationStatus) {
    // ** addr: 0xf91078, size: 0x3c
    // 0xf91078: EnterFrame
    //     0xf91078: stp             fp, lr, [SP, #-0x10]!
    //     0xf9107c: mov             fp, SP
    // 0xf91080: ldr             x0, [fp, #0x18]
    // 0xf91084: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf91084: ldur            w1, [x0, #0x17]
    // 0xf91088: DecompressPointer r1
    //     0xf91088: add             x1, x1, HEAP, lsl #32
    // 0xf9108c: CheckStackOverflow
    //     0xf9108c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf91090: cmp             SP, x16
    //     0xf91094: b.ls            #0xf910ac
    // 0xf91098: ldr             x2, [fp, #0x10]
    // 0xf9109c: r0 = _handleStatusChange()
    //     0xf9109c: bl              #0xf910b4  ; [package:flutter/src/material/scaffold.dart] _StandardBottomSheetState::_handleStatusChange
    // 0xf910a0: LeaveFrame
    //     0xf910a0: mov             SP, fp
    //     0xf910a4: ldp             fp, lr, [SP], #0x10
    // 0xf910a8: ret
    //     0xf910a8: ret             
    // 0xf910ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf910ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf910b0: b               #0xf91098
  }
  _ _handleStatusChange(/* No info */) {
    // ** addr: 0xf910b4, size: 0x78
    // 0xf910b4: EnterFrame
    //     0xf910b4: stp             fp, lr, [SP, #-0x10]!
    //     0xf910b8: mov             fp, SP
    // 0xf910bc: AllocStack(0x8)
    //     0xf910bc: sub             SP, SP, #8
    // 0xf910c0: CheckStackOverflow
    //     0xf910c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf910c4: cmp             SP, x16
    //     0xf910c8: b.ls            #0xf9111c
    // 0xf910cc: r16 = Instance_AnimationStatus
    //     0xf910cc: ldr             x16, [PP, #0x51a8]  ; [pp+0x51a8] Obj!AnimationStatus@12c61c1
    // 0xf910d0: cmp             w2, w16
    // 0xf910d4: b.ne            #0xf9110c
    // 0xf910d8: LoadField: r0 = r1->field_b
    //     0xf910d8: ldur            w0, [x1, #0xb]
    // 0xf910dc: DecompressPointer r0
    //     0xf910dc: add             x0, x0, HEAP, lsl #32
    // 0xf910e0: cmp             w0, NULL
    // 0xf910e4: b.eq            #0xf91124
    // 0xf910e8: LoadField: r1 = r0->field_1b
    //     0xf910e8: ldur            w1, [x0, #0x1b]
    // 0xf910ec: DecompressPointer r1
    //     0xf910ec: add             x1, x1, HEAP, lsl #32
    // 0xf910f0: cmp             w1, NULL
    // 0xf910f4: b.eq            #0xf91128
    // 0xf910f8: str             x1, [SP]
    // 0xf910fc: mov             x0, x1
    // 0xf91100: ClosureCall
    //     0xf91100: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xf91104: ldur            x2, [x0, #0x1f]
    //     0xf91108: blr             x2
    // 0xf9110c: r0 = Null
    //     0xf9110c: mov             x0, NULL
    // 0xf91110: LeaveFrame
    //     0xf91110: mov             SP, fp
    //     0xf91114: ldp             fp, lr, [SP], #0x10
    // 0xf91118: ret
    //     0xf91118: ret             
    // 0xf9111c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf9111c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf91120: b               #0xf910cc
    // 0xf91124: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf91124: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf91128: r0 = NullErrorSharedWithoutFPURegs()
    //     0xf91128: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10e5f08, size: 0xb0
    // 0x10e5f08: EnterFrame
    //     0x10e5f08: stp             fp, lr, [SP, #-0x10]!
    //     0x10e5f0c: mov             fp, SP
    // 0x10e5f10: AllocStack(0x18)
    //     0x10e5f10: sub             SP, SP, #0x18
    // 0x10e5f14: SetupParameters(_StandardBottomSheetState this /* r1 => r0, fp-0x10 */)
    //     0x10e5f14: mov             x0, x1
    //     0x10e5f18: stur            x1, [fp, #-0x10]
    // 0x10e5f1c: CheckStackOverflow
    //     0x10e5f1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e5f20: cmp             SP, x16
    //     0x10e5f24: b.ls            #0x10e5fa4
    // 0x10e5f28: LoadField: r1 = r0->field_b
    //     0x10e5f28: ldur            w1, [x0, #0xb]
    // 0x10e5f2c: DecompressPointer r1
    //     0x10e5f2c: add             x1, x1, HEAP, lsl #32
    // 0x10e5f30: cmp             w1, NULL
    // 0x10e5f34: b.eq            #0x10e5fac
    // 0x10e5f38: LoadField: r3 = r1->field_b
    //     0x10e5f38: ldur            w3, [x1, #0xb]
    // 0x10e5f3c: DecompressPointer r3
    //     0x10e5f3c: add             x3, x3, HEAP, lsl #32
    // 0x10e5f40: mov             x2, x0
    // 0x10e5f44: stur            x3, [fp, #-8]
    // 0x10e5f48: r1 = Function '_handleStatusChange@89420462':.
    //     0x10e5f48: add             x1, PP, #0x99, lsl #12  ; [pp+0x99780] AnonymousClosure: (0xf91078), in [package:flutter/src/material/scaffold.dart] _StandardBottomSheetState::_handleStatusChange (0xf910b4)
    //     0x10e5f4c: ldr             x1, [x1, #0x780]
    // 0x10e5f50: r0 = AllocateClosure()
    //     0x10e5f50: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10e5f54: ldur            x1, [fp, #-8]
    // 0x10e5f58: mov             x2, x0
    // 0x10e5f5c: r0 = removeStatusListener()
    //     0x10e5f5c: bl              #0x12599f4  ; [dart:mixin_deduplication] _MixinApplication456&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::removeStatusListener
    // 0x10e5f60: ldur            x0, [fp, #-0x10]
    // 0x10e5f64: LoadField: r1 = r0->field_b
    //     0x10e5f64: ldur            w1, [x0, #0xb]
    // 0x10e5f68: DecompressPointer r1
    //     0x10e5f68: add             x1, x1, HEAP, lsl #32
    // 0x10e5f6c: cmp             w1, NULL
    // 0x10e5f70: b.eq            #0x10e5fb0
    // 0x10e5f74: LoadField: r0 = r1->field_1f
    //     0x10e5f74: ldur            w0, [x1, #0x1f]
    // 0x10e5f78: DecompressPointer r0
    //     0x10e5f78: add             x0, x0, HEAP, lsl #32
    // 0x10e5f7c: cmp             w0, NULL
    // 0x10e5f80: b.eq            #0x10e5fb4
    // 0x10e5f84: str             x0, [SP]
    // 0x10e5f88: ClosureCall
    //     0x10e5f88: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x10e5f8c: ldur            x2, [x0, #0x1f]
    //     0x10e5f90: blr             x2
    // 0x10e5f94: r0 = Null
    //     0x10e5f94: mov             x0, NULL
    // 0x10e5f98: LeaveFrame
    //     0x10e5f98: mov             SP, fp
    //     0x10e5f9c: ldp             fp, lr, [SP], #0x10
    // 0x10e5fa0: ret
    //     0x10e5fa0: ret             
    // 0x10e5fa4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e5fa4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e5fa8: b               #0x10e5f28
    // 0x10e5fac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10e5fac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x10e5fb0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10e5fb0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x10e5fb4: r0 = NullErrorSharedWithoutFPURegs()
    //     0x10e5fb4: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
}

// class id: 5710, size: 0x84, field offset: 0x2c
class ScaffoldState extends _MixinApplication102&State&TickerProviderStateMixin&RestorationMixin&WidgetsBindingObserver {

  late AnimationController _bottomSheetScrimAnimationController; // offset: 0x7c
  late AnimationController _floatingActionButtonMoveController; // offset: 0x64
  late FloatingActionButtonAnimator _floatingActionButtonAnimator; // offset: 0x68
  late _ScaffoldGeometryNotifier _geometryNotifier; // offset: 0x78
  late AnimationController _floatingActionButtonVisibilityController; // offset: 0x74
  late final GlobalKey<State<StatefulWidget>> _statusBarKey; // offset: 0x38

  _ handleStatusBarTap(/* No info */) {
    // ** addr: 0x8d130c, size: 0xb4
    // 0x8d130c: EnterFrame
    //     0x8d130c: stp             fp, lr, [SP, #-0x10]!
    //     0x8d1310: mov             fp, SP
    // 0x8d1314: AllocStack(0x10)
    //     0x8d1314: sub             SP, SP, #0x10
    // 0x8d1318: SetupParameters(ScaffoldState this /* r1 => r0, fp-0x8 */)
    //     0x8d1318: mov             x0, x1
    //     0x8d131c: stur            x1, [fp, #-8]
    // 0x8d1320: CheckStackOverflow
    //     0x8d1320: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d1324: cmp             SP, x16
    //     0x8d1328: b.ls            #0x8d13b4
    // 0x8d132c: LoadField: r1 = r0->field_f
    //     0x8d132c: ldur            w1, [x0, #0xf]
    // 0x8d1330: DecompressPointer r1
    //     0x8d1330: add             x1, x1, HEAP, lsl #32
    // 0x8d1334: cmp             w1, NULL
    // 0x8d1338: b.eq            #0x8d13bc
    // 0x8d133c: r0 = maybeOf()
    //     0x8d133c: bl              #0x8d15a8  ; [package:flutter/src/widgets/primary_scroll_controller.dart] PrimaryScrollController::maybeOf
    // 0x8d1340: stur            x0, [fp, #-0x10]
    // 0x8d1344: cmp             w0, NULL
    // 0x8d1348: b.eq            #0x8d13a4
    // 0x8d134c: LoadField: r1 = r0->field_3b
    //     0x8d134c: ldur            w1, [x0, #0x3b]
    // 0x8d1350: DecompressPointer r1
    //     0x8d1350: add             x1, x1, HEAP, lsl #32
    // 0x8d1354: LoadField: r2 = r1->field_b
    //     0x8d1354: ldur            w2, [x1, #0xb]
    // 0x8d1358: cbz             w2, #0x8d13a4
    // 0x8d135c: ldur            x1, [fp, #-8]
    // 0x8d1360: LoadField: r0 = r1->field_37
    //     0x8d1360: ldur            w0, [x1, #0x37]
    // 0x8d1364: DecompressPointer r0
    //     0x8d1364: add             x0, x0, HEAP, lsl #32
    // 0x8d1368: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8d136c: cmp             w0, w16
    // 0x8d1370: b.ne            #0x8d1380
    // 0x8d1374: r2 = _statusBarKey
    //     0x8d1374: add             x2, PP, #0x84, lsl #12  ; [pp+0x84ce8] Field <ScaffoldState._statusBarKey@89420462>: late final (offset: 0x38)
    //     0x8d1378: ldr             x2, [x2, #0xce8]
    // 0x8d137c: r0 = InitLateFinalInstanceField()
    //     0x8d137c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x8d1380: mov             x1, x0
    // 0x8d1384: r0 = hitTestableAtOrigin()
    //     0x8d1384: bl              #0x8d1408  ; [package:flutter/src/material/scaffold.dart] _HitTestableAtOrigin::hitTestableAtOrigin
    // 0x8d1388: tbnz            w0, #4, #0x8d13a4
    // 0x8d138c: ldur            x1, [fp, #-0x10]
    // 0x8d1390: d0 = 0.000000
    //     0x8d1390: eor             v0.16b, v0.16b, v0.16b
    // 0x8d1394: r2 = Instance_Cubic
    //     0x8d1394: add             x2, PP, #0x16, lsl #12  ; [pp+0x16d58] Obj!Cubic@129f4b1
    //     0x8d1398: ldr             x2, [x2, #0xd58]
    // 0x8d139c: r3 = Instance_Duration
    //     0x8d139c: ldr             x3, [PP, #0xa80]  ; [pp+0xa80] Obj!Duration@12c8921
    // 0x8d13a0: r0 = animateTo()
    //     0x8d13a0: bl              #0x86e8cc  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::animateTo
    // 0x8d13a4: r0 = Null
    //     0x8d13a4: mov             x0, NULL
    // 0x8d13a8: LeaveFrame
    //     0x8d13a8: mov             SP, fp
    //     0x8d13ac: ldp             fp, lr, [SP], #0x10
    // 0x8d13b0: ret
    //     0x8d13b0: ret             
    // 0x8d13b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d13b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d13b8: b               #0x8d132c
    // 0x8d13bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8d13bc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ closeDrawer(/* No info */) {
    // ** addr: 0xb34ac4, size: 0x8c
    // 0xb34ac4: EnterFrame
    //     0xb34ac4: stp             fp, lr, [SP, #-0x10]!
    //     0xb34ac8: mov             fp, SP
    // 0xb34acc: AllocStack(0x8)
    //     0xb34acc: sub             SP, SP, #8
    // 0xb34ad0: SetupParameters(ScaffoldState this /* r1 => r0, fp-0x8 */)
    //     0xb34ad0: mov             x0, x1
    //     0xb34ad4: stur            x1, [fp, #-8]
    // 0xb34ad8: CheckStackOverflow
    //     0xb34ad8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb34adc: cmp             SP, x16
    //     0xb34ae0: b.ls            #0xb34b40
    // 0xb34ae4: LoadField: r1 = r0->field_b
    //     0xb34ae4: ldur            w1, [x0, #0xb]
    // 0xb34ae8: DecompressPointer r1
    //     0xb34ae8: add             x1, x1, HEAP, lsl #32
    // 0xb34aec: cmp             w1, NULL
    // 0xb34af0: b.eq            #0xb34b48
    // 0xb34af4: LoadField: r2 = r1->field_33
    //     0xb34af4: ldur            w2, [x1, #0x33]
    // 0xb34af8: DecompressPointer r2
    //     0xb34af8: add             x2, x2, HEAP, lsl #32
    // 0xb34afc: cmp             w2, NULL
    // 0xb34b00: b.eq            #0xb34b30
    // 0xb34b04: mov             x1, x0
    // 0xb34b08: r0 = isDrawerOpen()
    //     0xb34b08: bl              #0xb35c48  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::isDrawerOpen
    // 0xb34b0c: tbnz            w0, #4, #0xb34b30
    // 0xb34b10: ldur            x0, [fp, #-8]
    // 0xb34b14: LoadField: r1 = r0->field_2b
    //     0xb34b14: ldur            w1, [x0, #0x2b]
    // 0xb34b18: DecompressPointer r1
    //     0xb34b18: add             x1, x1, HEAP, lsl #32
    // 0xb34b1c: r0 = currentState()
    //     0xb34b1c: bl              #0x8591f8  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0xb34b20: cmp             w0, NULL
    // 0xb34b24: b.eq            #0xb34b4c
    // 0xb34b28: mov             x1, x0
    // 0xb34b2c: r0 = close()
    //     0xb34b2c: bl              #0xb34b88  ; [package:flutter/src/material/drawer.dart] DrawerControllerState::close
    // 0xb34b30: r0 = Null
    //     0xb34b30: mov             x0, NULL
    // 0xb34b34: LeaveFrame
    //     0xb34b34: mov             SP, fp
    //     0xb34b38: ldp             fp, lr, [SP], #0x10
    // 0xb34b3c: ret
    //     0xb34b3c: ret             
    // 0xb34b40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb34b40: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb34b44: b               #0xb34ae4
    // 0xb34b48: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb34b48: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb34b4c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb34b4c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ hasDrawer(/* No info */) {
    // ** addr: 0xb34b50, size: 0x38
    // 0xb34b50: LoadField: r2 = r1->field_b
    //     0xb34b50: ldur            w2, [x1, #0xb]
    // 0xb34b54: DecompressPointer r2
    //     0xb34b54: add             x2, x2, HEAP, lsl #32
    // 0xb34b58: cmp             w2, NULL
    // 0xb34b5c: b.eq            #0xb34b7c
    // 0xb34b60: LoadField: r1 = r2->field_33
    //     0xb34b60: ldur            w1, [x2, #0x33]
    // 0xb34b64: DecompressPointer r1
    //     0xb34b64: add             x1, x1, HEAP, lsl #32
    // 0xb34b68: cmp             w1, NULL
    // 0xb34b6c: r16 = true
    //     0xb34b6c: add             x16, NULL, #0x20  ; true
    // 0xb34b70: r17 = false
    //     0xb34b70: add             x17, NULL, #0x30  ; false
    // 0xb34b74: csel            x0, x16, x17, ne
    // 0xb34b78: ret
    //     0xb34b78: ret             
    // 0xb34b7c: EnterFrame
    //     0xb34b7c: stp             fp, lr, [SP, #-0x10]!
    //     0xb34b80: mov             fp, SP
    // 0xb34b84: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb34b84: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _drawerOpenedCallback(dynamic, bool) {
    // ** addr: 0xb34c34, size: 0x3c
    // 0xb34c34: EnterFrame
    //     0xb34c34: stp             fp, lr, [SP, #-0x10]!
    //     0xb34c38: mov             fp, SP
    // 0xb34c3c: ldr             x0, [fp, #0x18]
    // 0xb34c40: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb34c40: ldur            w1, [x0, #0x17]
    // 0xb34c44: DecompressPointer r1
    //     0xb34c44: add             x1, x1, HEAP, lsl #32
    // 0xb34c48: CheckStackOverflow
    //     0xb34c48: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb34c4c: cmp             SP, x16
    //     0xb34c50: b.ls            #0xb34c68
    // 0xb34c54: ldr             x2, [fp, #0x10]
    // 0xb34c58: r0 = _drawerOpenedCallback()
    //     0xb34c58: bl              #0xb34ca8  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::_drawerOpenedCallback
    // 0xb34c5c: LeaveFrame
    //     0xb34c5c: mov             SP, fp
    //     0xb34c60: ldp             fp, lr, [SP], #0x10
    // 0xb34c64: ret
    //     0xb34c64: ret             
    // 0xb34c68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb34c68: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb34c6c: b               #0xb34c54
  }
  _ _drawerOpenedCallback(/* No info */) {
    // ** addr: 0xb34ca8, size: 0x108
    // 0xb34ca8: EnterFrame
    //     0xb34ca8: stp             fp, lr, [SP, #-0x10]!
    //     0xb34cac: mov             fp, SP
    // 0xb34cb0: AllocStack(0x20)
    //     0xb34cb0: sub             SP, SP, #0x20
    // 0xb34cb4: SetupParameters(ScaffoldState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xb34cb4: stur            x1, [fp, #-8]
    //     0xb34cb8: stur            x2, [fp, #-0x10]
    // 0xb34cbc: CheckStackOverflow
    //     0xb34cbc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb34cc0: cmp             SP, x16
    //     0xb34cc4: b.ls            #0xb34da4
    // 0xb34cc8: r1 = 2
    //     0xb34cc8: mov             x1, #2
    // 0xb34ccc: r0 = AllocateContext()
    //     0xb34ccc: bl              #0x13de838  ; AllocateContextStub
    // 0xb34cd0: mov             x4, x0
    // 0xb34cd4: ldur            x3, [fp, #-8]
    // 0xb34cd8: stur            x4, [fp, #-0x20]
    // 0xb34cdc: StoreField: r4->field_f = r3
    //     0xb34cdc: stur            w3, [x4, #0xf]
    // 0xb34ce0: ldur            x5, [fp, #-0x10]
    // 0xb34ce4: StoreField: r4->field_13 = r5
    //     0xb34ce4: stur            w5, [x4, #0x13]
    // 0xb34ce8: LoadField: r0 = r3->field_3f
    //     0xb34ce8: ldur            w0, [x3, #0x3f]
    // 0xb34cec: DecompressPointer r0
    //     0xb34cec: add             x0, x0, HEAP, lsl #32
    // 0xb34cf0: LoadField: r6 = r0->field_33
    //     0xb34cf0: ldur            w6, [x0, #0x33]
    // 0xb34cf4: DecompressPointer r6
    //     0xb34cf4: add             x6, x6, HEAP, lsl #32
    // 0xb34cf8: stur            x6, [fp, #-0x18]
    // 0xb34cfc: cmp             w6, NULL
    // 0xb34d00: b.ne            #0xb34d38
    // 0xb34d04: LoadField: r2 = r0->field_23
    //     0xb34d04: ldur            w2, [x0, #0x23]
    // 0xb34d08: DecompressPointer r2
    //     0xb34d08: add             x2, x2, HEAP, lsl #32
    // 0xb34d0c: mov             x0, x6
    // 0xb34d10: r1 = Null
    //     0xb34d10: mov             x1, NULL
    // 0xb34d14: cmp             w2, NULL
    // 0xb34d18: b.eq            #0xb34d38
    // 0xb34d1c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xb34d1c: ldur            w4, [x2, #0x17]
    // 0xb34d20: DecompressPointer r4
    //     0xb34d20: add             x4, x4, HEAP, lsl #32
    // 0xb34d24: r8 = X0
    //     0xb34d24: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xb34d28: LoadField: r9 = r4->field_7
    //     0xb34d28: ldur            x9, [x4, #7]
    // 0xb34d2c: r3 = Null
    //     0xb34d2c: add             x3, PP, #0x83, lsl #12  ; [pp+0x837c8] Null
    //     0xb34d30: ldr             x3, [x3, #0x7c8]
    // 0xb34d34: blr             x9
    // 0xb34d38: ldur            x0, [fp, #-0x10]
    // 0xb34d3c: ldur            x1, [fp, #-0x18]
    // 0xb34d40: cmp             w1, w0
    // 0xb34d44: b.eq            #0xb34d94
    // 0xb34d48: ldur            x0, [fp, #-8]
    // 0xb34d4c: LoadField: r1 = r0->field_2b
    //     0xb34d4c: ldur            w1, [x0, #0x2b]
    // 0xb34d50: DecompressPointer r1
    //     0xb34d50: add             x1, x1, HEAP, lsl #32
    // 0xb34d54: r0 = currentState()
    //     0xb34d54: bl              #0x8591f8  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0xb34d58: cmp             w0, NULL
    // 0xb34d5c: b.eq            #0xb34d94
    // 0xb34d60: ldur            x0, [fp, #-8]
    // 0xb34d64: ldur            x2, [fp, #-0x20]
    // 0xb34d68: r1 = Function '<anonymous closure>':.
    //     0xb34d68: add             x1, PP, #0x83, lsl #12  ; [pp+0x837d8] AnonymousClosure: (0xb34db0), in [package:flutter/src/material/scaffold.dart] ScaffoldState::_drawerOpenedCallback (0xb34ca8)
    //     0xb34d6c: ldr             x1, [x1, #0x7d8]
    // 0xb34d70: r0 = AllocateClosure()
    //     0xb34d70: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb34d74: ldur            x1, [fp, #-8]
    // 0xb34d78: mov             x2, x0
    // 0xb34d7c: r0 = setState()
    //     0xb34d7c: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xb34d80: ldur            x1, [fp, #-8]
    // 0xb34d84: LoadField: r2 = r1->field_b
    //     0xb34d84: ldur            w2, [x1, #0xb]
    // 0xb34d88: DecompressPointer r2
    //     0xb34d88: add             x2, x2, HEAP, lsl #32
    // 0xb34d8c: cmp             w2, NULL
    // 0xb34d90: b.eq            #0xb34dac
    // 0xb34d94: r0 = Null
    //     0xb34d94: mov             x0, NULL
    // 0xb34d98: LeaveFrame
    //     0xb34d98: mov             SP, fp
    //     0xb34d9c: ldp             fp, lr, [SP], #0x10
    // 0xb34da0: ret
    //     0xb34da0: ret             
    // 0xb34da4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb34da4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb34da8: b               #0xb34cc8
    // 0xb34dac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb34dac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xb34db0, size: 0x5c
    // 0xb34db0: EnterFrame
    //     0xb34db0: stp             fp, lr, [SP, #-0x10]!
    //     0xb34db4: mov             fp, SP
    // 0xb34db8: ldr             x0, [fp, #0x10]
    // 0xb34dbc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb34dbc: ldur            w1, [x0, #0x17]
    // 0xb34dc0: DecompressPointer r1
    //     0xb34dc0: add             x1, x1, HEAP, lsl #32
    // 0xb34dc4: CheckStackOverflow
    //     0xb34dc4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb34dc8: cmp             SP, x16
    //     0xb34dcc: b.ls            #0xb34e04
    // 0xb34dd0: LoadField: r0 = r1->field_f
    //     0xb34dd0: ldur            w0, [x1, #0xf]
    // 0xb34dd4: DecompressPointer r0
    //     0xb34dd4: add             x0, x0, HEAP, lsl #32
    // 0xb34dd8: LoadField: r2 = r0->field_3f
    //     0xb34dd8: ldur            w2, [x0, #0x3f]
    // 0xb34ddc: DecompressPointer r2
    //     0xb34ddc: add             x2, x2, HEAP, lsl #32
    // 0xb34de0: LoadField: r0 = r1->field_13
    //     0xb34de0: ldur            w0, [x1, #0x13]
    // 0xb34de4: DecompressPointer r0
    //     0xb34de4: add             x0, x0, HEAP, lsl #32
    // 0xb34de8: mov             x1, x2
    // 0xb34dec: mov             x2, x0
    // 0xb34df0: r0 = value=()
    //     0xb34df0: bl              #0x86c6b4  ; [package:flutter/src/widgets/restoration_properties.dart] RestorableValue::value=
    // 0xb34df4: r0 = Null
    //     0xb34df4: mov             x0, NULL
    // 0xb34df8: LeaveFrame
    //     0xb34df8: mov             SP, fp
    //     0xb34dfc: ldp             fp, lr, [SP], #0x10
    // 0xb34e00: ret
    //     0xb34e00: ret             
    // 0xb34e04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb34e04: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb34e08: b               #0xb34dd0
  }
  get _ isDrawerOpen(/* No info */) {
    // ** addr: 0xb35c48, size: 0x6c
    // 0xb35c48: EnterFrame
    //     0xb35c48: stp             fp, lr, [SP, #-0x10]!
    //     0xb35c4c: mov             fp, SP
    // 0xb35c50: AllocStack(0x8)
    //     0xb35c50: sub             SP, SP, #8
    // 0xb35c54: LoadField: r0 = r1->field_3f
    //     0xb35c54: ldur            w0, [x1, #0x3f]
    // 0xb35c58: DecompressPointer r0
    //     0xb35c58: add             x0, x0, HEAP, lsl #32
    // 0xb35c5c: LoadField: r3 = r0->field_33
    //     0xb35c5c: ldur            w3, [x0, #0x33]
    // 0xb35c60: DecompressPointer r3
    //     0xb35c60: add             x3, x3, HEAP, lsl #32
    // 0xb35c64: stur            x3, [fp, #-8]
    // 0xb35c68: cmp             w3, NULL
    // 0xb35c6c: b.ne            #0xb35ca4
    // 0xb35c70: LoadField: r2 = r0->field_23
    //     0xb35c70: ldur            w2, [x0, #0x23]
    // 0xb35c74: DecompressPointer r2
    //     0xb35c74: add             x2, x2, HEAP, lsl #32
    // 0xb35c78: mov             x0, x3
    // 0xb35c7c: r1 = Null
    //     0xb35c7c: mov             x1, NULL
    // 0xb35c80: cmp             w2, NULL
    // 0xb35c84: b.eq            #0xb35ca4
    // 0xb35c88: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xb35c88: ldur            w4, [x2, #0x17]
    // 0xb35c8c: DecompressPointer r4
    //     0xb35c8c: add             x4, x4, HEAP, lsl #32
    // 0xb35c90: r8 = X0
    //     0xb35c90: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xb35c94: LoadField: r9 = r4->field_7
    //     0xb35c94: ldur            x9, [x4, #7]
    // 0xb35c98: r3 = Null
    //     0xb35c98: add             x3, PP, #0x8f, lsl #12  ; [pp+0x8fd78] Null
    //     0xb35c9c: ldr             x3, [x3, #0xd78]
    // 0xb35ca0: blr             x9
    // 0xb35ca4: ldur            x0, [fp, #-8]
    // 0xb35ca8: LeaveFrame
    //     0xb35ca8: mov             SP, fp
    //     0xb35cac: ldp             fp, lr, [SP], #0x10
    // 0xb35cb0: ret
    //     0xb35cb0: ret             
  }
  get _ isEndDrawerOpen(/* No info */) {
    // ** addr: 0xbfcb7c, size: 0x6c
    // 0xbfcb7c: EnterFrame
    //     0xbfcb7c: stp             fp, lr, [SP, #-0x10]!
    //     0xbfcb80: mov             fp, SP
    // 0xbfcb84: AllocStack(0x8)
    //     0xbfcb84: sub             SP, SP, #8
    // 0xbfcb88: LoadField: r0 = r1->field_43
    //     0xbfcb88: ldur            w0, [x1, #0x43]
    // 0xbfcb8c: DecompressPointer r0
    //     0xbfcb8c: add             x0, x0, HEAP, lsl #32
    // 0xbfcb90: LoadField: r3 = r0->field_33
    //     0xbfcb90: ldur            w3, [x0, #0x33]
    // 0xbfcb94: DecompressPointer r3
    //     0xbfcb94: add             x3, x3, HEAP, lsl #32
    // 0xbfcb98: stur            x3, [fp, #-8]
    // 0xbfcb9c: cmp             w3, NULL
    // 0xbfcba0: b.ne            #0xbfcbd8
    // 0xbfcba4: LoadField: r2 = r0->field_23
    //     0xbfcba4: ldur            w2, [x0, #0x23]
    // 0xbfcba8: DecompressPointer r2
    //     0xbfcba8: add             x2, x2, HEAP, lsl #32
    // 0xbfcbac: mov             x0, x3
    // 0xbfcbb0: r1 = Null
    //     0xbfcbb0: mov             x1, NULL
    // 0xbfcbb4: cmp             w2, NULL
    // 0xbfcbb8: b.eq            #0xbfcbd8
    // 0xbfcbbc: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xbfcbbc: ldur            w4, [x2, #0x17]
    // 0xbfcbc0: DecompressPointer r4
    //     0xbfcbc0: add             x4, x4, HEAP, lsl #32
    // 0xbfcbc4: r8 = X0
    //     0xbfcbc4: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xbfcbc8: LoadField: r9 = r4->field_7
    //     0xbfcbc8: ldur            x9, [x4, #7]
    // 0xbfcbcc: r3 = Null
    //     0xbfcbcc: add             x3, PP, #0x8f, lsl #12  ; [pp+0x8fdb8] Null
    //     0xbfcbd0: ldr             x3, [x3, #0xdb8]
    // 0xbfcbd4: blr             x9
    // 0xbfcbd8: ldur            x0, [fp, #-8]
    // 0xbfcbdc: LeaveFrame
    //     0xbfcbdc: mov             SP, fp
    //     0xbfcbe0: ldp             fp, lr, [SP], #0x10
    // 0xbfcbe4: ret
    //     0xbfcbe4: ret             
  }
  _ activate(/* No info */) {
    // ** addr: 0xd05968, size: 0xec
    // 0xd05968: EnterFrame
    //     0xd05968: stp             fp, lr, [SP, #-0x10]!
    //     0xd0596c: mov             fp, SP
    // 0xd05970: AllocStack(0x18)
    //     0xd05970: sub             SP, SP, #0x18
    // 0xd05974: SetupParameters(ScaffoldState this /* r1 => r0, fp-0x8 */)
    //     0xd05974: mov             x0, x1
    //     0xd05978: stur            x1, [fp, #-8]
    // 0xd0597c: CheckStackOverflow
    //     0xd0597c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd05980: cmp             SP, x16
    //     0xd05984: b.ls            #0xd05a44
    // 0xd05988: mov             x1, x0
    // 0xd0598c: r0 = activate()
    //     0xd0598c: bl              #0xd05a54  ; [dart:mixin_deduplication] _MixinApplication100&State&TickerProviderStateMixin::activate
    // 0xd05990: ldur            x0, [fp, #-8]
    // 0xd05994: LoadField: r1 = r0->field_b
    //     0xd05994: ldur            w1, [x0, #0xb]
    // 0xd05998: DecompressPointer r1
    //     0xd05998: add             x1, x1, HEAP, lsl #32
    // 0xd0599c: cmp             w1, NULL
    // 0xd059a0: b.eq            #0xd05a4c
    // 0xd059a4: r1 = LoadStaticField(0x6a0)
    //     0xd059a4: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0xd059a8: ldr             x1, [x1, #0xd40]
    // 0xd059ac: cmp             w1, NULL
    // 0xd059b0: b.eq            #0xd05a50
    // 0xd059b4: LoadField: r2 = r1->field_f3
    //     0xd059b4: ldur            w2, [x1, #0xf3]
    // 0xd059b8: DecompressPointer r2
    //     0xd059b8: add             x2, x2, HEAP, lsl #32
    // 0xd059bc: stur            x2, [fp, #-0x18]
    // 0xd059c0: LoadField: r1 = r2->field_b
    //     0xd059c0: ldur            w1, [x2, #0xb]
    // 0xd059c4: LoadField: r3 = r2->field_f
    //     0xd059c4: ldur            w3, [x2, #0xf]
    // 0xd059c8: DecompressPointer r3
    //     0xd059c8: add             x3, x3, HEAP, lsl #32
    // 0xd059cc: LoadField: r4 = r3->field_b
    //     0xd059cc: ldur            w4, [x3, #0xb]
    // 0xd059d0: r3 = LoadInt32Instr(r1)
    //     0xd059d0: sbfx            x3, x1, #1, #0x1f
    // 0xd059d4: stur            x3, [fp, #-0x10]
    // 0xd059d8: r1 = LoadInt32Instr(r4)
    //     0xd059d8: sbfx            x1, x4, #1, #0x1f
    // 0xd059dc: cmp             x3, x1
    // 0xd059e0: b.ne            #0xd059ec
    // 0xd059e4: mov             x1, x2
    // 0xd059e8: r0 = _growToNextCapacity()
    //     0xd059e8: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xd059ec: ldur            x2, [fp, #-0x18]
    // 0xd059f0: ldur            x3, [fp, #-0x10]
    // 0xd059f4: add             x4, x3, #1
    // 0xd059f8: lsl             x5, x4, #1
    // 0xd059fc: StoreField: r2->field_b = r5
    //     0xd059fc: stur            w5, [x2, #0xb]
    // 0xd05a00: LoadField: r1 = r2->field_f
    //     0xd05a00: ldur            w1, [x2, #0xf]
    // 0xd05a04: DecompressPointer r1
    //     0xd05a04: add             x1, x1, HEAP, lsl #32
    // 0xd05a08: ldur            x0, [fp, #-8]
    // 0xd05a0c: ArrayStore: r1[r3] = r0  ; List_4
    //     0xd05a0c: add             x25, x1, x3, lsl #2
    //     0xd05a10: add             x25, x25, #0xf
    //     0xd05a14: str             w0, [x25]
    //     0xd05a18: tbz             w0, #0, #0xd05a34
    //     0xd05a1c: ldurb           w16, [x1, #-1]
    //     0xd05a20: ldurb           w17, [x0, #-1]
    //     0xd05a24: and             x16, x17, x16, lsr #2
    //     0xd05a28: tst             x16, HEAP, lsr #32
    //     0xd05a2c: b.eq            #0xd05a34
    //     0xd05a30: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd05a34: r0 = Null
    //     0xd05a34: mov             x0, NULL
    // 0xd05a38: LeaveFrame
    //     0xd05a38: mov             SP, fp
    //     0xd05a3c: ldp             fp, lr, [SP], #0x10
    // 0xd05a40: ret
    //     0xd05a40: ret             
    // 0xd05a44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd05a44: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd05a48: b               #0xd05988
    // 0xd05a4c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd05a4c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd05a50: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd05a50: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ build(/* No info */) {
    // ** addr: 0xd35554, size: 0xcd4
    // 0xd35554: EnterFrame
    //     0xd35554: stp             fp, lr, [SP, #-0x10]!
    //     0xd35558: mov             fp, SP
    // 0xd3555c: AllocStack(0x80)
    //     0xd3555c: sub             SP, SP, #0x80
    // 0xd35560: SetupParameters(ScaffoldState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xd35560: mov             x0, x1
    //     0xd35564: stur            x1, [fp, #-8]
    //     0xd35568: mov             x1, x2
    //     0xd3556c: stur            x2, [fp, #-0x10]
    // 0xd35570: CheckStackOverflow
    //     0xd35570: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd35574: cmp             SP, x16
    //     0xd35578: b.ls            #0xd3617c
    // 0xd3557c: r1 = 8
    //     0xd3557c: mov             x1, #8
    // 0xd35580: r0 = AllocateContext()
    //     0xd35580: bl              #0x13de838  ; AllocateContextStub
    // 0xd35584: mov             x2, x0
    // 0xd35588: ldur            x0, [fp, #-8]
    // 0xd3558c: stur            x2, [fp, #-0x18]
    // 0xd35590: StoreField: r2->field_f = r0
    //     0xd35590: stur            w0, [x2, #0xf]
    // 0xd35594: ldur            x1, [fp, #-0x10]
    // 0xd35598: r0 = of()
    //     0xd35598: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd3559c: ldur            x1, [fp, #-0x10]
    // 0xd355a0: stur            x0, [fp, #-0x20]
    // 0xd355a4: r0 = of()
    //     0xd355a4: bl              #0x87371c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0xd355a8: mov             x4, x0
    // 0xd355ac: ldur            x3, [fp, #-0x18]
    // 0xd355b0: stur            x4, [fp, #-0x28]
    // 0xd355b4: StoreField: r3->field_13 = r0
    //     0xd355b4: stur            w0, [x3, #0x13]
    //     0xd355b8: ldurb           w16, [x3, #-1]
    //     0xd355bc: ldurb           w17, [x0, #-1]
    //     0xd355c0: and             x16, x17, x16, lsr #2
    //     0xd355c4: tst             x16, HEAP, lsr #32
    //     0xd355c8: b.eq            #0xd355d0
    //     0xd355cc: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xd355d0: r1 = <LayoutId>
    //     0xd355d0: add             x1, PP, #0x84, lsl #12  ; [pp+0x84ab8] TypeArguments: <LayoutId>
    //     0xd355d4: ldr             x1, [x1, #0xab8]
    // 0xd355d8: r2 = 0
    //     0xd355d8: mov             x2, #0
    // 0xd355dc: r0 = _GrowableList()
    //     0xd355dc: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xd355e0: mov             x1, x0
    // 0xd355e4: ldur            x2, [fp, #-0x18]
    // 0xd355e8: stur            x1, [fp, #-0x48]
    // 0xd355ec: ArrayStore: r2[0] = r0  ; List_4
    //     0xd355ec: stur            w0, [x2, #0x17]
    //     0xd355f0: ldurb           w16, [x2, #-1]
    //     0xd355f4: ldurb           w17, [x0, #-1]
    //     0xd355f8: and             x16, x17, x16, lsr #2
    //     0xd355fc: tst             x16, HEAP, lsr #32
    //     0xd35600: b.eq            #0xd35608
    //     0xd35604: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd35608: ldur            x0, [fp, #-8]
    // 0xd3560c: LoadField: r3 = r0->field_b
    //     0xd3560c: ldur            w3, [x0, #0xb]
    // 0xd35610: DecompressPointer r3
    //     0xd35610: add             x3, x3, HEAP, lsl #32
    // 0xd35614: stur            x3, [fp, #-0x40]
    // 0xd35618: cmp             w3, NULL
    // 0xd3561c: b.eq            #0xd36184
    // 0xd35620: LoadField: r4 = r3->field_1b
    //     0xd35620: ldur            w4, [x3, #0x1b]
    // 0xd35624: DecompressPointer r4
    //     0xd35624: add             x4, x4, HEAP, lsl #32
    // 0xd35628: stur            x4, [fp, #-0x38]
    // 0xd3562c: cmp             w4, NULL
    // 0xd35630: b.ne            #0xd35644
    // 0xd35634: mov             x1, x3
    // 0xd35638: r3 = Null
    //     0xd35638: mov             x3, NULL
    // 0xd3563c: r0 = false
    //     0xd3563c: add             x0, NULL, #0x30  ; false
    // 0xd35640: b               #0xd35690
    // 0xd35644: LoadField: r5 = r0->field_33
    //     0xd35644: ldur            w5, [x0, #0x33]
    // 0xd35648: DecompressPointer r5
    //     0xd35648: add             x5, x5, HEAP, lsl #32
    // 0xd3564c: stur            x5, [fp, #-0x30]
    // 0xd35650: r0 = KeyedSubtree()
    //     0xd35650: bl              #0xd36f98  ; AllocateKeyedSubtreeStub -> KeyedSubtree (size=0x10)
    // 0xd35654: mov             x1, x0
    // 0xd35658: ldur            x0, [fp, #-0x38]
    // 0xd3565c: stur            x1, [fp, #-0x50]
    // 0xd35660: StoreField: r1->field_b = r0
    //     0xd35660: stur            w0, [x1, #0xb]
    // 0xd35664: ldur            x0, [fp, #-0x30]
    // 0xd35668: StoreField: r1->field_7 = r0
    //     0xd35668: stur            w0, [x1, #7]
    // 0xd3566c: r0 = _BodyBuilder()
    //     0xd3566c: bl              #0xd36f8c  ; Allocate_BodyBuilderStub -> _BodyBuilder (size=0x18)
    // 0xd35670: mov             x1, x0
    // 0xd35674: r0 = false
    //     0xd35674: add             x0, NULL, #0x30  ; false
    // 0xd35678: StoreField: r1->field_f = r0
    //     0xd35678: stur            w0, [x1, #0xf]
    // 0xd3567c: StoreField: r1->field_13 = r0
    //     0xd3567c: stur            w0, [x1, #0x13]
    // 0xd35680: ldur            x2, [fp, #-0x50]
    // 0xd35684: StoreField: r1->field_b = r2
    //     0xd35684: stur            w2, [x1, #0xb]
    // 0xd35688: mov             x3, x1
    // 0xd3568c: ldur            x1, [fp, #-0x40]
    // 0xd35690: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xd35690: ldur            w2, [x1, #0x17]
    // 0xd35694: DecompressPointer r2
    //     0xd35694: add             x2, x2, HEAP, lsl #32
    // 0xd35698: cmp             w2, NULL
    // 0xd3569c: r16 = true
    //     0xd3569c: add             x16, NULL, #0x20  ; true
    // 0xd356a0: r17 = false
    //     0xd356a0: add             x17, NULL, #0x30  ; false
    // 0xd356a4: csel            x4, x16, x17, ne
    // 0xd356a8: LoadField: r2 = r1->field_4f
    //     0xd356a8: ldur            w2, [x1, #0x4f]
    // 0xd356ac: DecompressPointer r2
    //     0xd356ac: add             x2, x2, HEAP, lsl #32
    // 0xd356b0: cmp             w2, NULL
    // 0xd356b4: b.eq            #0xd356c0
    // 0xd356b8: r6 = true
    //     0xd356b8: add             x6, NULL, #0x20  ; true
    // 0xd356bc: b               #0xd356c4
    // 0xd356c0: r6 = false
    //     0xd356c0: add             x6, NULL, #0x30  ; false
    // 0xd356c4: LoadField: r2 = r1->field_57
    //     0xd356c4: ldur            w2, [x1, #0x57]
    // 0xd356c8: DecompressPointer r2
    //     0xd356c8: add             x2, x2, HEAP, lsl #32
    // 0xd356cc: cmp             w2, NULL
    // 0xd356d0: b.ne            #0xd356dc
    // 0xd356d4: r1 = true
    //     0xd356d4: add             x1, NULL, #0x20  ; true
    // 0xd356d8: b               #0xd356e0
    // 0xd356dc: mov             x1, x2
    // 0xd356e0: ldur            x8, [fp, #-8]
    // 0xd356e4: r16 = false
    //     0xd356e4: add             x16, NULL, #0x30  ; false
    // 0xd356e8: stp             x4, x16, [SP, #8]
    // 0xd356ec: str             x1, [SP]
    // 0xd356f0: mov             x1, x8
    // 0xd356f4: ldur            x2, [fp, #-0x48]
    // 0xd356f8: mov             x7, x0
    // 0xd356fc: r5 = Instance__ScaffoldSlot
    //     0xd356fc: add             x5, PP, #0x84, lsl #12  ; [pp+0x84ac0] Obj!_ScaffoldSlot@12c50a1
    //     0xd35700: ldr             x5, [x5, #0xac0]
    // 0xd35704: r4 = const [0, 0x9, 0x3, 0x8, removeBottomInset, 0x8, null]
    //     0xd35704: add             x4, PP, #0x84, lsl #12  ; [pp+0x84ac8] List(7) [0, 0x9, 0x3, 0x8, "removeBottomInset", 0x8, Null]
    //     0xd35708: ldr             x4, [x4, #0xac8]
    // 0xd3570c: r0 = _addIfNonNull()
    //     0xd3570c: bl              #0xd36854  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::_addIfNonNull
    // 0xd35710: ldur            x0, [fp, #-8]
    // 0xd35714: LoadField: r1 = r0->field_7f
    //     0xd35714: ldur            w1, [x0, #0x7f]
    // 0xd35718: DecompressPointer r1
    //     0xd35718: add             x1, x1, HEAP, lsl #32
    // 0xd3571c: tbnz            w1, #4, #0xd35780
    // 0xd35720: LoadField: r1 = r0->field_b
    //     0xd35720: ldur            w1, [x0, #0xb]
    // 0xd35724: DecompressPointer r1
    //     0xd35724: add             x1, x1, HEAP, lsl #32
    // 0xd35728: cmp             w1, NULL
    // 0xd3572c: b.eq            #0xd36188
    // 0xd35730: LoadField: r2 = r0->field_7b
    //     0xd35730: ldur            w2, [x0, #0x7b]
    // 0xd35734: DecompressPointer r2
    //     0xd35734: add             x2, x2, HEAP, lsl #32
    // 0xd35738: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3573c: cmp             w2, w16
    // 0xd35740: b.eq            #0xd3618c
    // 0xd35744: ldur            x1, [fp, #-0x10]
    // 0xd35748: r0 = _defaultBottomSheetScrimBuilder()
    //     0xd35748: bl              #0xd36728  ; [package:flutter/src/material/scaffold.dart] Scaffold::_defaultBottomSheetScrimBuilder
    // 0xd3574c: r16 = true
    //     0xd3574c: add             x16, NULL, #0x20  ; true
    // 0xd35750: r30 = true
    //     0xd35750: add             lr, NULL, #0x20  ; true
    // 0xd35754: stp             lr, x16, [SP]
    // 0xd35758: ldur            x1, [fp, #-8]
    // 0xd3575c: ldur            x2, [fp, #-0x48]
    // 0xd35760: mov             x3, x0
    // 0xd35764: r5 = Instance__ScaffoldSlot
    //     0xd35764: add             x5, PP, #0x84, lsl #12  ; [pp+0x84ad0] Obj!_ScaffoldSlot@12c5081
    //     0xd35768: ldr             x5, [x5, #0xad0]
    // 0xd3576c: r6 = true
    //     0xd3576c: add             x6, NULL, #0x20  ; true
    // 0xd35770: r7 = true
    //     0xd35770: add             x7, NULL, #0x20  ; true
    // 0xd35774: r4 = const [0, 0x8, 0x2, 0x8, null]
    //     0xd35774: add             x4, PP, #0x18, lsl #12  ; [pp+0x18a60] List(5) [0, 0x8, 0x2, 0x8, Null]
    //     0xd35778: ldr             x4, [x4, #0xa60]
    // 0xd3577c: r0 = _addIfNonNull()
    //     0xd3577c: bl              #0xd36854  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::_addIfNonNull
    // 0xd35780: ldur            x0, [fp, #-8]
    // 0xd35784: LoadField: r1 = r0->field_b
    //     0xd35784: ldur            w1, [x0, #0xb]
    // 0xd35788: DecompressPointer r1
    //     0xd35788: add             x1, x1, HEAP, lsl #32
    // 0xd3578c: cmp             w1, NULL
    // 0xd35790: b.eq            #0xd36198
    // 0xd35794: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xd35794: ldur            w2, [x1, #0x17]
    // 0xd35798: DecompressPointer r2
    //     0xd35798: add             x2, x2, HEAP, lsl #32
    // 0xd3579c: cmp             w2, NULL
    // 0xd357a0: b.eq            #0xd358f0
    // 0xd357a4: ldur            x1, [fp, #-0x10]
    // 0xd357a8: r0 = paddingOf()
    //     0xd357a8: bl              #0xd1a984  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::paddingOf
    // 0xd357ac: LoadField: d0 = r0->field_f
    //     0xd357ac: ldur            d0, [x0, #0xf]
    // 0xd357b0: ldur            x2, [fp, #-8]
    // 0xd357b4: stur            d0, [fp, #-0x60]
    // 0xd357b8: LoadField: r0 = r2->field_b
    //     0xd357b8: ldur            w0, [x2, #0xb]
    // 0xd357bc: DecompressPointer r0
    //     0xd357bc: add             x0, x0, HEAP, lsl #32
    // 0xd357c0: cmp             w0, NULL
    // 0xd357c4: b.eq            #0xd3619c
    // 0xd357c8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd357c8: ldur            w1, [x0, #0x17]
    // 0xd357cc: DecompressPointer r1
    //     0xd357cc: add             x1, x1, HEAP, lsl #32
    // 0xd357d0: cmp             w1, NULL
    // 0xd357d4: b.eq            #0xd361a0
    // 0xd357d8: r0 = LoadClassIdInstr(r1)
    //     0xd357d8: ldur            x0, [x1, #-1]
    //     0xd357dc: ubfx            x0, x0, #0xc, #0x14
    // 0xd357e0: r0 = GDT[cid_x0 + 0xade]()
    //     0xd357e0: add             lr, x0, #0xade
    //     0xd357e4: ldr             lr, [x21, lr, lsl #3]
    //     0xd357e8: blr             lr
    // 0xd357ec: ldur            x1, [fp, #-0x10]
    // 0xd357f0: mov             x2, x0
    // 0xd357f4: r0 = preferredHeightFor()
    //     0xd357f4: bl              #0xd365a0  ; [package:flutter/src/material/app_bar.dart] AppBar::preferredHeightFor
    // 0xd357f8: mov             v1.16b, v0.16b
    // 0xd357fc: ldur            d0, [fp, #-0x60]
    // 0xd35800: fadd            d2, d1, d0
    // 0xd35804: stur            d2, [fp, #-0x68]
    // 0xd35808: r0 = inline_Allocate_Double()
    //     0xd35808: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xd3580c: add             x0, x0, #0x10
    //     0xd35810: cmp             x1, x0
    //     0xd35814: b.ls            #0xd361a4
    //     0xd35818: str             x0, [THR, #0x60]  ; THR::top
    //     0xd3581c: sub             x0, x0, #0xf
    //     0xd35820: mov             x1, #0xe19c
    //     0xd35824: movk            x1, #3, lsl #16
    //     0xd35828: stur            x1, [x0, #-1]
    // 0xd3582c: dmb             ishst
    // 0xd35830: StoreField: r0->field_7 = d2
    //     0xd35830: stur            d2, [x0, #7]
    // 0xd35834: ldur            x1, [fp, #-8]
    // 0xd35838: StoreField: r1->field_3b = r0
    //     0xd35838: stur            w0, [x1, #0x3b]
    //     0xd3583c: ldurb           w16, [x1, #-1]
    //     0xd35840: ldurb           w17, [x0, #-1]
    //     0xd35844: and             x16, x17, x16, lsr #2
    //     0xd35848: tst             x16, HEAP, lsr #32
    //     0xd3584c: b.eq            #0xd35854
    //     0xd35850: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd35854: r0 = BoxConstraints()
    //     0xd35854: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xd35858: stur            x0, [fp, #-0x30]
    // 0xd3585c: StoreField: r0->field_7 = rZR
    //     0xd3585c: stur            xzr, [x0, #7]
    // 0xd35860: d0 = inf
    //     0xd35860: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xd35864: StoreField: r0->field_f = d0
    //     0xd35864: stur            d0, [x0, #0xf]
    // 0xd35868: ArrayStore: r0[0] = rZR  ; List_8
    //     0xd35868: stur            xzr, [x0, #0x17]
    // 0xd3586c: ldur            d0, [fp, #-0x68]
    // 0xd35870: StoreField: r0->field_1f = d0
    //     0xd35870: stur            d0, [x0, #0x1f]
    // 0xd35874: ldur            x2, [fp, #-8]
    // 0xd35878: LoadField: r1 = r2->field_b
    //     0xd35878: ldur            w1, [x2, #0xb]
    // 0xd3587c: DecompressPointer r1
    //     0xd3587c: add             x1, x1, HEAP, lsl #32
    // 0xd35880: cmp             w1, NULL
    // 0xd35884: b.eq            #0xd361b4
    // 0xd35888: ArrayLoad: r3 = r1[0]  ; List_4
    //     0xd35888: ldur            w3, [x1, #0x17]
    // 0xd3588c: DecompressPointer r3
    //     0xd3588c: add             x3, x3, HEAP, lsl #32
    // 0xd35890: cmp             w3, NULL
    // 0xd35894: b.eq            #0xd361b8
    // 0xd35898: mov             x1, x3
    // 0xd3589c: r0 = createSettings()
    //     0xd3589c: bl              #0xd36550  ; [package:flutter/src/material/flexible_space_bar.dart] FlexibleSpaceBar::createSettings
    // 0xd358a0: stur            x0, [fp, #-0x38]
    // 0xd358a4: r0 = ConstrainedBox()
    //     0xd358a4: bl              #0xd0a588  ; AllocateConstrainedBoxStub -> ConstrainedBox (size=0x14)
    // 0xd358a8: mov             x1, x0
    // 0xd358ac: ldur            x0, [fp, #-0x30]
    // 0xd358b0: StoreField: r1->field_f = r0
    //     0xd358b0: stur            w0, [x1, #0xf]
    // 0xd358b4: ldur            x0, [fp, #-0x38]
    // 0xd358b8: StoreField: r1->field_b = r0
    //     0xd358b8: stur            w0, [x1, #0xb]
    // 0xd358bc: r16 = false
    //     0xd358bc: add             x16, NULL, #0x30  ; false
    // 0xd358c0: r30 = false
    //     0xd358c0: add             lr, NULL, #0x30  ; false
    // 0xd358c4: stp             lr, x16, [SP]
    // 0xd358c8: mov             x3, x1
    // 0xd358cc: ldur            x1, [fp, #-8]
    // 0xd358d0: ldur            x2, [fp, #-0x48]
    // 0xd358d4: r5 = Instance__ScaffoldSlot
    //     0xd358d4: add             x5, PP, #0x84, lsl #12  ; [pp+0x84ad8] Obj!_ScaffoldSlot@12c5061
    //     0xd358d8: ldr             x5, [x5, #0xad8]
    // 0xd358dc: r6 = true
    //     0xd358dc: add             x6, NULL, #0x20  ; true
    // 0xd358e0: r7 = false
    //     0xd358e0: add             x7, NULL, #0x30  ; false
    // 0xd358e4: r4 = const [0, 0x8, 0x2, 0x8, null]
    //     0xd358e4: add             x4, PP, #0x18, lsl #12  ; [pp+0x18a60] List(5) [0, 0x8, 0x2, 0x8, Null]
    //     0xd358e8: ldr             x4, [x4, #0xa60]
    // 0xd358ec: r0 = _addIfNonNull()
    //     0xd358ec: bl              #0xd36854  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::_addIfNonNull
    // 0xd358f0: ldur            x0, [fp, #-8]
    // 0xd358f4: ldur            x3, [fp, #-0x18]
    // 0xd358f8: r7 = false
    //     0xd358f8: add             x7, NULL, #0x30  ; false
    // 0xd358fc: StoreField: r3->field_1b = r7
    //     0xd358fc: stur            w7, [x3, #0x1b]
    // 0xd35900: StoreField: r3->field_1f = rNULL
    //     0xd35900: stur            NULL, [x3, #0x1f]
    // 0xd35904: LoadField: r1 = r0->field_57
    //     0xd35904: ldur            w1, [x0, #0x57]
    // 0xd35908: DecompressPointer r1
    //     0xd35908: add             x1, x1, HEAP, lsl #32
    // 0xd3590c: cmp             w1, NULL
    // 0xd35910: b.ne            #0xd35924
    // 0xd35914: LoadField: r1 = r0->field_53
    //     0xd35914: ldur            w1, [x0, #0x53]
    // 0xd35918: DecompressPointer r1
    //     0xd35918: add             x1, x1, HEAP, lsl #32
    // 0xd3591c: LoadField: r2 = r1->field_b
    //     0xd3591c: ldur            w2, [x1, #0xb]
    // 0xd35920: cbz             w2, #0xd35a78
    // 0xd35924: LoadField: r2 = r0->field_53
    //     0xd35924: ldur            w2, [x0, #0x53]
    // 0xd35928: DecompressPointer r2
    //     0xd35928: add             x2, x2, HEAP, lsl #32
    // 0xd3592c: r1 = <Widget>
    //     0xd3592c: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xd35930: r0 = _GrowableList._ofGrowableList()
    //     0xd35930: bl              #0x7d7558  ; [dart:core] _GrowableList::_GrowableList._ofGrowableList
    // 0xd35934: mov             x2, x0
    // 0xd35938: ldur            x0, [fp, #-8]
    // 0xd3593c: stur            x2, [fp, #-0x38]
    // 0xd35940: LoadField: r1 = r0->field_57
    //     0xd35940: ldur            w1, [x0, #0x57]
    // 0xd35944: DecompressPointer r1
    //     0xd35944: add             x1, x1, HEAP, lsl #32
    // 0xd35948: cmp             w1, NULL
    // 0xd3594c: b.ne            #0xd35958
    // 0xd35950: r3 = Null
    //     0xd35950: mov             x3, NULL
    // 0xd35954: b               #0xd35960
    // 0xd35958: LoadField: r3 = r1->field_b
    //     0xd35958: ldur            w3, [x1, #0xb]
    // 0xd3595c: DecompressPointer r3
    //     0xd3595c: add             x3, x3, HEAP, lsl #32
    // 0xd35960: stur            x3, [fp, #-0x30]
    // 0xd35964: cmp             w3, NULL
    // 0xd35968: b.eq            #0xd359e0
    // 0xd3596c: LoadField: r1 = r2->field_b
    //     0xd3596c: ldur            w1, [x2, #0xb]
    // 0xd35970: LoadField: r4 = r2->field_f
    //     0xd35970: ldur            w4, [x2, #0xf]
    // 0xd35974: DecompressPointer r4
    //     0xd35974: add             x4, x4, HEAP, lsl #32
    // 0xd35978: LoadField: r5 = r4->field_b
    //     0xd35978: ldur            w5, [x4, #0xb]
    // 0xd3597c: r4 = LoadInt32Instr(r1)
    //     0xd3597c: sbfx            x4, x1, #1, #0x1f
    // 0xd35980: stur            x4, [fp, #-0x58]
    // 0xd35984: r1 = LoadInt32Instr(r5)
    //     0xd35984: sbfx            x1, x5, #1, #0x1f
    // 0xd35988: cmp             x4, x1
    // 0xd3598c: b.ne            #0xd35998
    // 0xd35990: mov             x1, x2
    // 0xd35994: r0 = _growToNextCapacity()
    //     0xd35994: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xd35998: ldur            x2, [fp, #-0x38]
    // 0xd3599c: ldur            x3, [fp, #-0x58]
    // 0xd359a0: add             x0, x3, #1
    // 0xd359a4: lsl             x1, x0, #1
    // 0xd359a8: StoreField: r2->field_b = r1
    //     0xd359a8: stur            w1, [x2, #0xb]
    // 0xd359ac: LoadField: r1 = r2->field_f
    //     0xd359ac: ldur            w1, [x2, #0xf]
    // 0xd359b0: DecompressPointer r1
    //     0xd359b0: add             x1, x1, HEAP, lsl #32
    // 0xd359b4: ldur            x0, [fp, #-0x30]
    // 0xd359b8: ArrayStore: r1[r3] = r0  ; List_4
    //     0xd359b8: add             x25, x1, x3, lsl #2
    //     0xd359bc: add             x25, x25, #0xf
    //     0xd359c0: str             w0, [x25]
    //     0xd359c4: tbz             w0, #0, #0xd359e0
    //     0xd359c8: ldurb           w16, [x1, #-1]
    //     0xd359cc: ldurb           w17, [x0, #-1]
    //     0xd359d0: and             x16, x17, x16, lsr #2
    //     0xd359d4: tst             x16, HEAP, lsr #32
    //     0xd359d8: b.eq            #0xd359e0
    //     0xd359dc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd359e0: ldur            x1, [fp, #-8]
    // 0xd359e4: r0 = Stack()
    //     0xd359e4: bl              #0xd1a854  ; AllocateStackStub -> Stack (size=0x20)
    // 0xd359e8: mov             x1, x0
    // 0xd359ec: r0 = Instance_Alignment
    //     0xd359ec: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e1b8] Obj!Alignment@129e6f1
    //     0xd359f0: ldr             x0, [x0, #0x1b8]
    // 0xd359f4: StoreField: r1->field_f = r0
    //     0xd359f4: stur            w0, [x1, #0xf]
    // 0xd359f8: r0 = Instance_StackFit
    //     0xd359f8: add             x0, PP, #0x15, lsl #12  ; [pp+0x158e0] Obj!StackFit@12c4221
    //     0xd359fc: ldr             x0, [x0, #0x8e0]
    // 0xd35a00: ArrayStore: r1[0] = r0  ; List_4
    //     0xd35a00: stur            w0, [x1, #0x17]
    // 0xd35a04: r0 = Instance_Clip
    //     0xd35a04: add             x0, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xd35a08: ldr             x0, [x0, #0x850]
    // 0xd35a0c: StoreField: r1->field_1b = r0
    //     0xd35a0c: stur            w0, [x1, #0x1b]
    // 0xd35a10: ldur            x0, [fp, #-0x38]
    // 0xd35a14: StoreField: r1->field_b = r0
    //     0xd35a14: stur            w0, [x1, #0xb]
    // 0xd35a18: ldur            x0, [fp, #-8]
    // 0xd35a1c: LoadField: r2 = r0->field_b
    //     0xd35a1c: ldur            w2, [x0, #0xb]
    // 0xd35a20: DecompressPointer r2
    //     0xd35a20: add             x2, x2, HEAP, lsl #32
    // 0xd35a24: cmp             w2, NULL
    // 0xd35a28: b.eq            #0xd361bc
    // 0xd35a2c: LoadField: r3 = r2->field_57
    //     0xd35a2c: ldur            w3, [x2, #0x57]
    // 0xd35a30: DecompressPointer r3
    //     0xd35a30: add             x3, x3, HEAP, lsl #32
    // 0xd35a34: cmp             w3, NULL
    // 0xd35a38: b.ne            #0xd35a44
    // 0xd35a3c: r6 = true
    //     0xd35a3c: add             x6, NULL, #0x20  ; true
    // 0xd35a40: b               #0xd35a48
    // 0xd35a44: mov             x6, x3
    // 0xd35a48: r16 = false
    //     0xd35a48: add             x16, NULL, #0x30  ; false
    // 0xd35a4c: r30 = true
    //     0xd35a4c: add             lr, NULL, #0x20  ; true
    // 0xd35a50: stp             lr, x16, [SP]
    // 0xd35a54: mov             x3, x1
    // 0xd35a58: mov             x1, x0
    // 0xd35a5c: ldur            x2, [fp, #-0x48]
    // 0xd35a60: r5 = Instance__ScaffoldSlot
    //     0xd35a60: add             x5, PP, #0x84, lsl #12  ; [pp+0x84ae0] Obj!_ScaffoldSlot@12c5041
    //     0xd35a64: ldr             x5, [x5, #0xae0]
    // 0xd35a68: r7 = false
    //     0xd35a68: add             x7, NULL, #0x30  ; false
    // 0xd35a6c: r4 = const [0, 0x8, 0x2, 0x8, null]
    //     0xd35a6c: add             x4, PP, #0x18, lsl #12  ; [pp+0x18a60] List(5) [0, 0x8, 0x2, 0x8, Null]
    //     0xd35a70: ldr             x4, [x4, #0xa60]
    // 0xd35a74: r0 = _addIfNonNull()
    //     0xd35a74: bl              #0xd36854  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::_addIfNonNull
    // 0xd35a78: ldur            x0, [fp, #-8]
    // 0xd35a7c: LoadField: r1 = r0->field_4b
    //     0xd35a7c: ldur            w1, [x0, #0x4b]
    // 0xd35a80: DecompressPointer r1
    //     0xd35a80: add             x1, x1, HEAP, lsl #32
    // 0xd35a84: cmp             w1, NULL
    // 0xd35a88: b.eq            #0xd35bc0
    // 0xd35a8c: ldur            x1, [fp, #-0x10]
    // 0xd35a90: r0 = of()
    //     0xd35a90: bl              #0xd364f4  ; [package:flutter/src/material/snack_bar_theme.dart] SnackBarTheme::of
    // 0xd35a94: ldur            x4, [fp, #-8]
    // 0xd35a98: LoadField: r1 = r4->field_4b
    //     0xd35a98: ldur            w1, [x4, #0x4b]
    // 0xd35a9c: DecompressPointer r1
    //     0xd35a9c: add             x1, x1, HEAP, lsl #32
    // 0xd35aa0: cmp             w1, NULL
    // 0xd35aa4: b.ne            #0xd35ab0
    // 0xd35aa8: r2 = Null
    //     0xd35aa8: mov             x2, NULL
    // 0xd35aac: b               #0xd35ac4
    // 0xd35ab0: LoadField: r2 = r1->field_b
    //     0xd35ab0: ldur            w2, [x1, #0xb]
    // 0xd35ab4: DecompressPointer r2
    //     0xd35ab4: add             x2, x2, HEAP, lsl #32
    // 0xd35ab8: LoadField: r3 = r2->field_2b
    //     0xd35ab8: ldur            w3, [x2, #0x2b]
    // 0xd35abc: DecompressPointer r3
    //     0xd35abc: add             x3, x3, HEAP, lsl #32
    // 0xd35ac0: mov             x2, x3
    // 0xd35ac4: cmp             w2, NULL
    // 0xd35ac8: b.ne            #0xd35ad0
    // 0xd35acc: r2 = Null
    //     0xd35acc: mov             x2, NULL
    // 0xd35ad0: cmp             w2, NULL
    // 0xd35ad4: b.ne            #0xd35ae0
    // 0xd35ad8: r2 = Instance_SnackBarBehavior
    //     0xd35ad8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26220] Obj!SnackBarBehavior@12c4d61
    //     0xd35adc: ldr             x2, [x2, #0x220]
    // 0xd35ae0: ldur            x8, [fp, #-0x18]
    // 0xd35ae4: r16 = Instance_SnackBarBehavior
    //     0xd35ae4: add             x16, PP, #0x7a, lsl #12  ; [pp+0x7aa48] Obj!SnackBarBehavior@12c4d41
    //     0xd35ae8: ldr             x16, [x16, #0xa48]
    // 0xd35aec: cmp             w2, w16
    // 0xd35af0: r16 = true
    //     0xd35af0: add             x16, NULL, #0x20  ; true
    // 0xd35af4: r17 = false
    //     0xd35af4: add             x17, NULL, #0x30  ; false
    // 0xd35af8: csel            x3, x16, x17, eq
    // 0xd35afc: StoreField: r8->field_1b = r3
    //     0xd35afc: stur            w3, [x8, #0x1b]
    // 0xd35b00: LoadField: r2 = r0->field_23
    //     0xd35b00: ldur            w2, [x0, #0x23]
    // 0xd35b04: DecompressPointer r2
    //     0xd35b04: add             x2, x2, HEAP, lsl #32
    // 0xd35b08: mov             x0, x2
    // 0xd35b0c: StoreField: r8->field_1f = r0
    //     0xd35b0c: stur            w0, [x8, #0x1f]
    //     0xd35b10: ldurb           w16, [x8, #-1]
    //     0xd35b14: ldurb           w17, [x0, #-1]
    //     0xd35b18: and             x16, x17, x16, lsr #2
    //     0xd35b1c: tst             x16, HEAP, lsr #32
    //     0xd35b20: b.eq            #0xd35b28
    //     0xd35b24: bl              #0x13de074  ; WriteBarrierWrappersStub
    // 0xd35b28: cmp             w1, NULL
    // 0xd35b2c: b.ne            #0xd35b38
    // 0xd35b30: r3 = Null
    //     0xd35b30: mov             x3, NULL
    // 0xd35b34: b               #0xd35b44
    // 0xd35b38: LoadField: r0 = r1->field_b
    //     0xd35b38: ldur            w0, [x1, #0xb]
    // 0xd35b3c: DecompressPointer r0
    //     0xd35b3c: add             x0, x0, HEAP, lsl #32
    // 0xd35b40: mov             x3, x0
    // 0xd35b44: LoadField: r0 = r4->field_b
    //     0xd35b44: ldur            w0, [x4, #0xb]
    // 0xd35b48: DecompressPointer r0
    //     0xd35b48: add             x0, x0, HEAP, lsl #32
    // 0xd35b4c: cmp             w0, NULL
    // 0xd35b50: b.eq            #0xd361c0
    // 0xd35b54: LoadField: r1 = r0->field_4f
    //     0xd35b54: ldur            w1, [x0, #0x4f]
    // 0xd35b58: DecompressPointer r1
    //     0xd35b58: add             x1, x1, HEAP, lsl #32
    // 0xd35b5c: cmp             w1, NULL
    // 0xd35b60: b.eq            #0xd35b6c
    // 0xd35b64: r6 = true
    //     0xd35b64: add             x6, NULL, #0x20  ; true
    // 0xd35b68: b               #0xd35b70
    // 0xd35b6c: r6 = false
    //     0xd35b6c: add             x6, NULL, #0x30  ; false
    // 0xd35b70: LoadField: r1 = r0->field_57
    //     0xd35b70: ldur            w1, [x0, #0x57]
    // 0xd35b74: DecompressPointer r1
    //     0xd35b74: add             x1, x1, HEAP, lsl #32
    // 0xd35b78: cmp             w1, NULL
    // 0xd35b7c: b.ne            #0xd35b88
    // 0xd35b80: r0 = true
    //     0xd35b80: add             x0, NULL, #0x20  ; true
    // 0xd35b84: b               #0xd35b8c
    // 0xd35b88: mov             x0, x1
    // 0xd35b8c: eor             x1, x0, #0x10
    // 0xd35b90: r16 = false
    //     0xd35b90: add             x16, NULL, #0x30  ; false
    // 0xd35b94: r30 = true
    //     0xd35b94: add             lr, NULL, #0x20  ; true
    // 0xd35b98: stp             lr, x16, [SP, #8]
    // 0xd35b9c: str             x1, [SP]
    // 0xd35ba0: mov             x1, x4
    // 0xd35ba4: ldur            x2, [fp, #-0x48]
    // 0xd35ba8: r5 = Instance__ScaffoldSlot
    //     0xd35ba8: add             x5, PP, #0x84, lsl #12  ; [pp+0x84ae8] Obj!_ScaffoldSlot@12c5021
    //     0xd35bac: ldr             x5, [x5, #0xae8]
    // 0xd35bb0: r7 = false
    //     0xd35bb0: add             x7, NULL, #0x30  ; false
    // 0xd35bb4: r4 = const [0, 0x9, 0x3, 0x8, maintainBottomViewPadding, 0x8, null]
    //     0xd35bb4: add             x4, PP, #0x84, lsl #12  ; [pp+0x84af0] List(7) [0, 0x9, 0x3, 0x8, "maintainBottomViewPadding", 0x8, Null]
    //     0xd35bb8: ldr             x4, [x4, #0xaf0]
    // 0xd35bbc: r0 = _addIfNonNull()
    //     0xd35bbc: bl              #0xd36854  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::_addIfNonNull
    // 0xd35bc0: ldur            x0, [fp, #-8]
    // 0xd35bc4: ldur            x2, [fp, #-0x18]
    // 0xd35bc8: r7 = false
    //     0xd35bc8: add             x7, NULL, #0x30  ; false
    // 0xd35bcc: StoreField: r2->field_23 = r7
    //     0xd35bcc: stur            w7, [x2, #0x23]
    // 0xd35bd0: LoadField: r1 = r0->field_4f
    //     0xd35bd0: ldur            w1, [x0, #0x4f]
    // 0xd35bd4: DecompressPointer r1
    //     0xd35bd4: add             x1, x1, HEAP, lsl #32
    // 0xd35bd8: cmp             w1, NULL
    // 0xd35bdc: b.eq            #0xd35d10
    // 0xd35be0: ldur            x1, [fp, #-0x10]
    // 0xd35be4: r0 = of()
    //     0xd35be4: bl              #0xd3649c  ; [package:flutter/src/material/banner_theme.dart] MaterialBannerTheme::of
    // 0xd35be8: mov             x2, x0
    // 0xd35bec: ldur            x0, [fp, #-8]
    // 0xd35bf0: stur            x2, [fp, #-0x30]
    // 0xd35bf4: LoadField: r1 = r0->field_4f
    //     0xd35bf4: ldur            w1, [x0, #0x4f]
    // 0xd35bf8: DecompressPointer r1
    //     0xd35bf8: add             x1, x1, HEAP, lsl #32
    // 0xd35bfc: cmp             w1, NULL
    // 0xd35c00: b.ne            #0xd35c0c
    // 0xd35c04: mov             x0, x2
    // 0xd35c08: b               #0xd35c34
    // 0xd35c0c: LoadField: r3 = r1->field_b
    //     0xd35c0c: ldur            w3, [x1, #0xb]
    // 0xd35c10: DecompressPointer r3
    //     0xd35c10: add             x3, x3, HEAP, lsl #32
    // 0xd35c14: mov             x1, x3
    // 0xd35c18: r4 = 0
    //     0xd35c18: mov             x4, #0
    // 0xd35c1c: LoadField: r0 = rSP->field_fffffff8
    //     0xd35c1c: ldur            x0, [SP, #-8]
    // 0xd35c20: r16 = 139822029843448
    //     0xd35c20: add             x16, PP, #0x84, lsl #12  ; [pp+0x84af8] IMM: 0x7f2ada6babf8
    //     0xd35c24: add             x16, x16, #0xaf8
    // 0xd35c28: ldp             lr, x5, [x16]
    // 0xd35c2c: blr             lr
    // 0xd35c30: ldur            x0, [fp, #-0x30]
    // 0xd35c34: LoadField: r1 = r0->field_1b
    //     0xd35c34: ldur            w1, [x0, #0x1b]
    // 0xd35c38: DecompressPointer r1
    //     0xd35c38: add             x1, x1, HEAP, lsl #32
    // 0xd35c3c: cmp             w1, NULL
    // 0xd35c40: b.ne            #0xd35c4c
    // 0xd35c44: d1 = 0.000000
    //     0xd35c44: eor             v1.16b, v1.16b, v1.16b
    // 0xd35c48: b               #0xd35c54
    // 0xd35c4c: LoadField: d0 = r1->field_7
    //     0xd35c4c: ldur            d0, [x1, #7]
    // 0xd35c50: mov             v1.16b, v0.16b
    // 0xd35c54: ldur            x0, [fp, #-8]
    // 0xd35c58: ldur            x4, [fp, #-0x18]
    // 0xd35c5c: d0 = 0.000000
    //     0xd35c5c: eor             v0.16b, v0.16b, v0.16b
    // 0xd35c60: fcmp            d1, d0
    // 0xd35c64: r16 = true
    //     0xd35c64: add             x16, NULL, #0x20  ; true
    // 0xd35c68: r17 = false
    //     0xd35c68: add             x17, NULL, #0x30  ; false
    // 0xd35c6c: csel            x1, x16, x17, ne
    // 0xd35c70: StoreField: r4->field_23 = r1
    //     0xd35c70: stur            w1, [x4, #0x23]
    // 0xd35c74: LoadField: r1 = r0->field_4f
    //     0xd35c74: ldur            w1, [x0, #0x4f]
    // 0xd35c78: DecompressPointer r1
    //     0xd35c78: add             x1, x1, HEAP, lsl #32
    // 0xd35c7c: cmp             w1, NULL
    // 0xd35c80: b.ne            #0xd35c8c
    // 0xd35c84: r3 = Null
    //     0xd35c84: mov             x3, NULL
    // 0xd35c88: b               #0xd35c98
    // 0xd35c8c: LoadField: r2 = r1->field_b
    //     0xd35c8c: ldur            w2, [x1, #0xb]
    // 0xd35c90: DecompressPointer r2
    //     0xd35c90: add             x2, x2, HEAP, lsl #32
    // 0xd35c94: mov             x3, x2
    // 0xd35c98: LoadField: r1 = r0->field_b
    //     0xd35c98: ldur            w1, [x0, #0xb]
    // 0xd35c9c: DecompressPointer r1
    //     0xd35c9c: add             x1, x1, HEAP, lsl #32
    // 0xd35ca0: cmp             w1, NULL
    // 0xd35ca4: b.eq            #0xd361c4
    // 0xd35ca8: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xd35ca8: ldur            w2, [x1, #0x17]
    // 0xd35cac: DecompressPointer r2
    //     0xd35cac: add             x2, x2, HEAP, lsl #32
    // 0xd35cb0: cmp             w2, NULL
    // 0xd35cb4: r16 = true
    //     0xd35cb4: add             x16, NULL, #0x20  ; true
    // 0xd35cb8: r17 = false
    //     0xd35cb8: add             x17, NULL, #0x30  ; false
    // 0xd35cbc: csel            x5, x16, x17, ne
    // 0xd35cc0: LoadField: r2 = r1->field_57
    //     0xd35cc0: ldur            w2, [x1, #0x57]
    // 0xd35cc4: DecompressPointer r2
    //     0xd35cc4: add             x2, x2, HEAP, lsl #32
    // 0xd35cc8: cmp             w2, NULL
    // 0xd35ccc: b.ne            #0xd35cd8
    // 0xd35cd0: r1 = true
    //     0xd35cd0: add             x1, NULL, #0x20  ; true
    // 0xd35cd4: b               #0xd35cdc
    // 0xd35cd8: mov             x1, x2
    // 0xd35cdc: eor             x2, x1, #0x10
    // 0xd35ce0: r16 = false
    //     0xd35ce0: add             x16, NULL, #0x30  ; false
    // 0xd35ce4: stp             x5, x16, [SP, #8]
    // 0xd35ce8: str             x2, [SP]
    // 0xd35cec: mov             x1, x0
    // 0xd35cf0: ldur            x2, [fp, #-0x48]
    // 0xd35cf4: r5 = Instance__ScaffoldSlot
    //     0xd35cf4: add             x5, PP, #0x84, lsl #12  ; [pp+0x84b08] Obj!_ScaffoldSlot@12c5001
    //     0xd35cf8: ldr             x5, [x5, #0xb08]
    // 0xd35cfc: r6 = true
    //     0xd35cfc: add             x6, NULL, #0x20  ; true
    // 0xd35d00: r7 = false
    //     0xd35d00: add             x7, NULL, #0x30  ; false
    // 0xd35d04: r4 = const [0, 0x9, 0x3, 0x8, maintainBottomViewPadding, 0x8, null]
    //     0xd35d04: add             x4, PP, #0x84, lsl #12  ; [pp+0x84af0] List(7) [0, 0x9, 0x3, 0x8, "maintainBottomViewPadding", 0x8, Null]
    //     0xd35d08: ldr             x4, [x4, #0xaf0]
    // 0xd35d0c: r0 = _addIfNonNull()
    //     0xd35d0c: bl              #0xd36854  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::_addIfNonNull
    // 0xd35d10: ldur            x0, [fp, #-8]
    // 0xd35d14: LoadField: r1 = r0->field_b
    //     0xd35d14: ldur            w1, [x0, #0xb]
    // 0xd35d18: DecompressPointer r1
    //     0xd35d18: add             x1, x1, HEAP, lsl #32
    // 0xd35d1c: cmp             w1, NULL
    // 0xd35d20: b.eq            #0xd361c8
    // 0xd35d24: LoadField: r3 = r1->field_4f
    //     0xd35d24: ldur            w3, [x1, #0x4f]
    // 0xd35d28: DecompressPointer r3
    //     0xd35d28: add             x3, x3, HEAP, lsl #32
    // 0xd35d2c: cmp             w3, NULL
    // 0xd35d30: b.eq            #0xd35d88
    // 0xd35d34: LoadField: r2 = r1->field_57
    //     0xd35d34: ldur            w2, [x1, #0x57]
    // 0xd35d38: DecompressPointer r2
    //     0xd35d38: add             x2, x2, HEAP, lsl #32
    // 0xd35d3c: cmp             w2, NULL
    // 0xd35d40: b.ne            #0xd35d4c
    // 0xd35d44: r1 = true
    //     0xd35d44: add             x1, NULL, #0x20  ; true
    // 0xd35d48: b               #0xd35d50
    // 0xd35d4c: mov             x1, x2
    // 0xd35d50: eor             x2, x1, #0x10
    // 0xd35d54: r16 = false
    //     0xd35d54: add             x16, NULL, #0x30  ; false
    // 0xd35d58: r30 = true
    //     0xd35d58: add             lr, NULL, #0x20  ; true
    // 0xd35d5c: stp             lr, x16, [SP, #8]
    // 0xd35d60: str             x2, [SP]
    // 0xd35d64: mov             x1, x0
    // 0xd35d68: ldur            x2, [fp, #-0x48]
    // 0xd35d6c: r5 = Instance__ScaffoldSlot
    //     0xd35d6c: add             x5, PP, #0x84, lsl #12  ; [pp+0x84b10] Obj!_ScaffoldSlot@12c4fe1
    //     0xd35d70: ldr             x5, [x5, #0xb10]
    // 0xd35d74: r6 = false
    //     0xd35d74: add             x6, NULL, #0x30  ; false
    // 0xd35d78: r7 = false
    //     0xd35d78: add             x7, NULL, #0x30  ; false
    // 0xd35d7c: r4 = const [0, 0x9, 0x3, 0x8, maintainBottomViewPadding, 0x8, null]
    //     0xd35d7c: add             x4, PP, #0x84, lsl #12  ; [pp+0x84af0] List(7) [0, 0x9, 0x3, 0x8, "maintainBottomViewPadding", 0x8, Null]
    //     0xd35d80: ldr             x4, [x4, #0xaf0]
    // 0xd35d84: r0 = _addIfNonNull()
    //     0xd35d84: bl              #0xd36854  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::_addIfNonNull
    // 0xd35d88: ldur            x1, [fp, #-8]
    // 0xd35d8c: LoadField: r0 = r1->field_63
    //     0xd35d8c: ldur            w0, [x1, #0x63]
    // 0xd35d90: DecompressPointer r0
    //     0xd35d90: add             x0, x0, HEAP, lsl #32
    // 0xd35d94: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd35d98: cmp             w0, w16
    // 0xd35d9c: b.eq            #0xd361cc
    // 0xd35da0: stur            x0, [fp, #-0x50]
    // 0xd35da4: LoadField: r2 = r1->field_67
    //     0xd35da4: ldur            w2, [x1, #0x67]
    // 0xd35da8: DecompressPointer r2
    //     0xd35da8: add             x2, x2, HEAP, lsl #32
    // 0xd35dac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd35db0: cmp             w2, w16
    // 0xd35db4: b.eq            #0xd361d8
    // 0xd35db8: LoadField: r2 = r1->field_77
    //     0xd35db8: ldur            w2, [x1, #0x77]
    // 0xd35dbc: DecompressPointer r2
    //     0xd35dbc: add             x2, x2, HEAP, lsl #32
    // 0xd35dc0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd35dc4: cmp             w2, w16
    // 0xd35dc8: b.eq            #0xd361e4
    // 0xd35dcc: stur            x2, [fp, #-0x40]
    // 0xd35dd0: LoadField: r3 = r1->field_73
    //     0xd35dd0: ldur            w3, [x1, #0x73]
    // 0xd35dd4: DecompressPointer r3
    //     0xd35dd4: add             x3, x3, HEAP, lsl #32
    // 0xd35dd8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd35ddc: cmp             w3, w16
    // 0xd35de0: b.eq            #0xd361f0
    // 0xd35de4: stur            x3, [fp, #-0x38]
    // 0xd35de8: LoadField: r4 = r1->field_b
    //     0xd35de8: ldur            w4, [x1, #0xb]
    // 0xd35dec: DecompressPointer r4
    //     0xd35dec: add             x4, x4, HEAP, lsl #32
    // 0xd35df0: cmp             w4, NULL
    // 0xd35df4: b.eq            #0xd361fc
    // 0xd35df8: LoadField: r5 = r4->field_1f
    //     0xd35df8: ldur            w5, [x4, #0x1f]
    // 0xd35dfc: DecompressPointer r5
    //     0xd35dfc: add             x5, x5, HEAP, lsl #32
    // 0xd35e00: stur            x5, [fp, #-0x30]
    // 0xd35e04: r0 = _FloatingActionButtonTransition()
    //     0xd35e04: bl              #0xd36490  ; Allocate_FloatingActionButtonTransitionStub -> _FloatingActionButtonTransition (size=0x20)
    // 0xd35e08: mov             x1, x0
    // 0xd35e0c: ldur            x0, [fp, #-0x30]
    // 0xd35e10: StoreField: r1->field_b = r0
    //     0xd35e10: stur            w0, [x1, #0xb]
    // 0xd35e14: ldur            x0, [fp, #-0x50]
    // 0xd35e18: StoreField: r1->field_f = r0
    //     0xd35e18: stur            w0, [x1, #0xf]
    // 0xd35e1c: r0 = Instance__ScalingFabMotionAnimator
    //     0xd35e1c: add             x0, PP, #0x84, lsl #12  ; [pp+0x84b18] Obj!_ScalingFabMotionAnimator@129ece1
    //     0xd35e20: ldr             x0, [x0, #0xb18]
    // 0xd35e24: StoreField: r1->field_13 = r0
    //     0xd35e24: stur            w0, [x1, #0x13]
    // 0xd35e28: ldur            x0, [fp, #-0x40]
    // 0xd35e2c: ArrayStore: r1[0] = r0  ; List_4
    //     0xd35e2c: stur            w0, [x1, #0x17]
    // 0xd35e30: ldur            x0, [fp, #-0x38]
    // 0xd35e34: StoreField: r1->field_1b = r0
    //     0xd35e34: stur            w0, [x1, #0x1b]
    // 0xd35e38: r16 = true
    //     0xd35e38: add             x16, NULL, #0x20  ; true
    // 0xd35e3c: r30 = true
    //     0xd35e3c: add             lr, NULL, #0x20  ; true
    // 0xd35e40: stp             lr, x16, [SP]
    // 0xd35e44: mov             x3, x1
    // 0xd35e48: ldur            x1, [fp, #-8]
    // 0xd35e4c: ldur            x2, [fp, #-0x48]
    // 0xd35e50: r5 = Instance__ScaffoldSlot
    //     0xd35e50: add             x5, PP, #0x84, lsl #12  ; [pp+0x84b20] Obj!_ScaffoldSlot@12c4fc1
    //     0xd35e54: ldr             x5, [x5, #0xb20]
    // 0xd35e58: r6 = true
    //     0xd35e58: add             x6, NULL, #0x20  ; true
    // 0xd35e5c: r7 = true
    //     0xd35e5c: add             x7, NULL, #0x20  ; true
    // 0xd35e60: r4 = const [0, 0x8, 0x2, 0x8, null]
    //     0xd35e60: add             x4, PP, #0x18, lsl #12  ; [pp+0x18a60] List(5) [0, 0x8, 0x2, 0x8, Null]
    //     0xd35e64: ldr             x4, [x4, #0xa60]
    // 0xd35e68: r0 = _addIfNonNull()
    //     0xd35e68: bl              #0xd36854  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::_addIfNonNull
    // 0xd35e6c: r16 = false
    //     0xd35e6c: add             x16, NULL, #0x30  ; false
    // 0xd35e70: r30 = true
    //     0xd35e70: add             lr, NULL, #0x20  ; true
    // 0xd35e74: stp             lr, x16, [SP]
    // 0xd35e78: ldur            x1, [fp, #-8]
    // 0xd35e7c: ldur            x2, [fp, #-0x48]
    // 0xd35e80: r3 = Null
    //     0xd35e80: mov             x3, NULL
    // 0xd35e84: r5 = Instance__ScaffoldSlot
    //     0xd35e84: add             x5, PP, #0x84, lsl #12  ; [pp+0x84b28] Obj!_ScaffoldSlot@12c4fa1
    //     0xd35e88: ldr             x5, [x5, #0xb28]
    // 0xd35e8c: r6 = true
    //     0xd35e8c: add             x6, NULL, #0x20  ; true
    // 0xd35e90: r7 = false
    //     0xd35e90: add             x7, NULL, #0x30  ; false
    // 0xd35e94: r4 = const [0, 0x8, 0x2, 0x8, null]
    //     0xd35e94: add             x4, PP, #0x18, lsl #12  ; [pp+0x18a60] List(5) [0, 0x8, 0x2, 0x8, Null]
    //     0xd35e98: ldr             x4, [x4, #0xa60]
    // 0xd35e9c: r0 = _addIfNonNull()
    //     0xd35e9c: bl              #0xd36854  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::_addIfNonNull
    // 0xd35ea0: ldur            x3, [fp, #-8]
    // 0xd35ea4: LoadField: r0 = r3->field_43
    //     0xd35ea4: ldur            w0, [x3, #0x43]
    // 0xd35ea8: DecompressPointer r0
    //     0xd35ea8: add             x0, x0, HEAP, lsl #32
    // 0xd35eac: LoadField: r4 = r0->field_33
    //     0xd35eac: ldur            w4, [x0, #0x33]
    // 0xd35eb0: DecompressPointer r4
    //     0xd35eb0: add             x4, x4, HEAP, lsl #32
    // 0xd35eb4: stur            x4, [fp, #-0x30]
    // 0xd35eb8: cmp             w4, NULL
    // 0xd35ebc: b.ne            #0xd35ef4
    // 0xd35ec0: LoadField: r2 = r0->field_23
    //     0xd35ec0: ldur            w2, [x0, #0x23]
    // 0xd35ec4: DecompressPointer r2
    //     0xd35ec4: add             x2, x2, HEAP, lsl #32
    // 0xd35ec8: mov             x0, x4
    // 0xd35ecc: r1 = Null
    //     0xd35ecc: mov             x1, NULL
    // 0xd35ed0: cmp             w2, NULL
    // 0xd35ed4: b.eq            #0xd35ef4
    // 0xd35ed8: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xd35ed8: ldur            w4, [x2, #0x17]
    // 0xd35edc: DecompressPointer r4
    //     0xd35edc: add             x4, x4, HEAP, lsl #32
    // 0xd35ee0: r8 = X0
    //     0xd35ee0: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xd35ee4: LoadField: r9 = r4->field_7
    //     0xd35ee4: ldur            x9, [x4, #7]
    // 0xd35ee8: r3 = Null
    //     0xd35ee8: add             x3, PP, #0x84, lsl #12  ; [pp+0x84b30] Null
    //     0xd35eec: ldr             x3, [x3, #0xb30]
    // 0xd35ef0: blr             x9
    // 0xd35ef4: ldur            x0, [fp, #-0x30]
    // 0xd35ef8: tbnz            w0, #4, #0xd35f28
    // 0xd35efc: ldur            x0, [fp, #-8]
    // 0xd35f00: mov             x1, x0
    // 0xd35f04: ldur            x2, [fp, #-0x48]
    // 0xd35f08: ldur            x3, [fp, #-0x28]
    // 0xd35f0c: r0 = _buildDrawer()
    //     0xd35f0c: bl              #0xd362fc  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::_buildDrawer
    // 0xd35f10: ldur            x0, [fp, #-8]
    // 0xd35f14: LoadField: r1 = r0->field_b
    //     0xd35f14: ldur            w1, [x0, #0xb]
    // 0xd35f18: DecompressPointer r1
    //     0xd35f18: add             x1, x1, HEAP, lsl #32
    // 0xd35f1c: cmp             w1, NULL
    // 0xd35f20: b.eq            #0xd36200
    // 0xd35f24: b               #0xd35f50
    // 0xd35f28: ldur            x0, [fp, #-8]
    // 0xd35f2c: LoadField: r1 = r0->field_b
    //     0xd35f2c: ldur            w1, [x0, #0xb]
    // 0xd35f30: DecompressPointer r1
    //     0xd35f30: add             x1, x1, HEAP, lsl #32
    // 0xd35f34: cmp             w1, NULL
    // 0xd35f38: b.eq            #0xd36204
    // 0xd35f3c: mov             x1, x0
    // 0xd35f40: ldur            x2, [fp, #-0x48]
    // 0xd35f44: ldur            x3, [fp, #-0x28]
    // 0xd35f48: r0 = _buildDrawer()
    //     0xd35f48: bl              #0xd362fc  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::_buildDrawer
    // 0xd35f4c: ldur            x0, [fp, #-8]
    // 0xd35f50: ldur            x1, [fp, #-0x10]
    // 0xd35f54: r0 = paddingOf()
    //     0xd35f54: bl              #0xd1a984  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::paddingOf
    // 0xd35f58: mov             x2, x0
    // 0xd35f5c: ldur            x0, [fp, #-8]
    // 0xd35f60: stur            x2, [fp, #-0x28]
    // 0xd35f64: LoadField: r1 = r0->field_b
    //     0xd35f64: ldur            w1, [x0, #0xb]
    // 0xd35f68: DecompressPointer r1
    //     0xd35f68: add             x1, x1, HEAP, lsl #32
    // 0xd35f6c: cmp             w1, NULL
    // 0xd35f70: b.eq            #0xd36208
    // 0xd35f74: LoadField: r3 = r1->field_57
    //     0xd35f74: ldur            w3, [x1, #0x57]
    // 0xd35f78: DecompressPointer r3
    //     0xd35f78: add             x3, x3, HEAP, lsl #32
    // 0xd35f7c: cmp             w3, NULL
    // 0xd35f80: b.eq            #0xd35f88
    // 0xd35f84: tbnz            w3, #4, #0xd35f98
    // 0xd35f88: ldur            x1, [fp, #-0x10]
    // 0xd35f8c: r0 = viewInsetsOf()
    //     0xd35f8c: bl              #0xd362b0  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::viewInsetsOf
    // 0xd35f90: LoadField: d0 = r0->field_1f
    //     0xd35f90: ldur            d0, [x0, #0x1f]
    // 0xd35f94: b               #0xd35f9c
    // 0xd35f98: d0 = 0.000000
    //     0xd35f98: eor             v0.16b, v0.16b, v0.16b
    // 0xd35f9c: ldur            x2, [fp, #-0x18]
    // 0xd35fa0: r0 = inline_Allocate_Double()
    //     0xd35fa0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xd35fa4: add             x0, x0, #0x10
    //     0xd35fa8: cmp             x1, x0
    //     0xd35fac: b.ls            #0xd3620c
    //     0xd35fb0: str             x0, [THR, #0x60]  ; THR::top
    //     0xd35fb4: sub             x0, x0, #0xf
    //     0xd35fb8: mov             x1, #0xe19c
    //     0xd35fbc: movk            x1, #3, lsl #16
    //     0xd35fc0: stur            x1, [x0, #-1]
    // 0xd35fc4: dmb             ishst
    // 0xd35fc8: StoreField: r0->field_7 = d0
    //     0xd35fc8: stur            d0, [x0, #7]
    // 0xd35fcc: str             x0, [SP]
    // 0xd35fd0: ldur            x1, [fp, #-0x28]
    // 0xd35fd4: r4 = const [0, 0x2, 0x1, 0x1, bottom, 0x1, null]
    //     0xd35fd4: ldr             x4, [PP, #0x5658]  ; [pp+0x5658] List(7) [0, 0x2, 0x1, 0x1, "bottom", 0x1, Null]
    // 0xd35fd8: r0 = copyWith()
    //     0xd35fd8: bl              #0x86fd70  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::copyWith
    // 0xd35fdc: ldur            x2, [fp, #-0x18]
    // 0xd35fe0: StoreField: r2->field_27 = r0
    //     0xd35fe0: stur            w0, [x2, #0x27]
    //     0xd35fe4: ldurb           w16, [x2, #-1]
    //     0xd35fe8: ldurb           w17, [x0, #-1]
    //     0xd35fec: and             x16, x17, x16, lsr #2
    //     0xd35ff0: tst             x16, HEAP, lsr #32
    //     0xd35ff4: b.eq            #0xd35ffc
    //     0xd35ff8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd35ffc: ldur            x1, [fp, #-0x10]
    // 0xd36000: r0 = viewPaddingOf()
    //     0xd36000: bl              #0xd0be80  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::viewPaddingOf
    // 0xd36004: ldur            x1, [fp, #-8]
    // 0xd36008: stur            x0, [fp, #-0x28]
    // 0xd3600c: r0 = _resizeToAvoidBottomInset()
    //     0xd3600c: bl              #0xd36274  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::_resizeToAvoidBottomInset
    // 0xd36010: tbnz            w0, #4, #0xd36034
    // 0xd36014: ldur            x1, [fp, #-0x10]
    // 0xd36018: r0 = viewInsetsOf()
    //     0xd36018: bl              #0xd362b0  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::viewInsetsOf
    // 0xd3601c: LoadField: d0 = r0->field_1f
    //     0xd3601c: ldur            d0, [x0, #0x1f]
    // 0xd36020: d1 = 0.000000
    //     0xd36020: eor             v1.16b, v1.16b, v1.16b
    // 0xd36024: fcmp            d0, d1
    // 0xd36028: b.eq            #0xd36034
    // 0xd3602c: r1 = 0.000000
    //     0xd3602c: ldr             x1, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xd36030: b               #0xd36038
    // 0xd36034: r1 = Null
    //     0xd36034: mov             x1, NULL
    // 0xd36038: ldur            x0, [fp, #-8]
    // 0xd3603c: ldur            x2, [fp, #-0x18]
    // 0xd36040: str             x1, [SP]
    // 0xd36044: ldur            x1, [fp, #-0x28]
    // 0xd36048: r4 = const [0, 0x2, 0x1, 0x1, bottom, 0x1, null]
    //     0xd36048: ldr             x4, [PP, #0x5658]  ; [pp+0x5658] List(7) [0, 0x2, 0x1, 0x1, "bottom", 0x1, Null]
    // 0xd3604c: r0 = copyWith()
    //     0xd3604c: bl              #0x86fd70  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::copyWith
    // 0xd36050: ldur            x2, [fp, #-0x18]
    // 0xd36054: StoreField: r2->field_2b = r0
    //     0xd36054: stur            w0, [x2, #0x2b]
    //     0xd36058: ldurb           w16, [x2, #-1]
    //     0xd3605c: ldurb           w17, [x0, #-1]
    //     0xd36060: and             x16, x17, x16, lsr #2
    //     0xd36064: tst             x16, HEAP, lsr #32
    //     0xd36068: b.eq            #0xd36070
    //     0xd3606c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd36070: ldur            x1, [fp, #-8]
    // 0xd36074: r0 = hasDrawer()
    //     0xd36074: bl              #0xb34b50  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::hasDrawer
    // 0xd36078: mov             x3, x0
    // 0xd3607c: ldur            x0, [fp, #-8]
    // 0xd36080: stur            x3, [fp, #-0x28]
    // 0xd36084: LoadField: r4 = r0->field_77
    //     0xd36084: ldur            w4, [x0, #0x77]
    // 0xd36088: DecompressPointer r4
    //     0xd36088: add             x4, x4, HEAP, lsl #32
    // 0xd3608c: stur            x4, [fp, #-0x10]
    // 0xd36090: LoadField: r1 = r0->field_b
    //     0xd36090: ldur            w1, [x0, #0xb]
    // 0xd36094: DecompressPointer r1
    //     0xd36094: add             x1, x1, HEAP, lsl #32
    // 0xd36098: cmp             w1, NULL
    // 0xd3609c: b.eq            #0xd36224
    // 0xd360a0: LoadField: r0 = r1->field_4b
    //     0xd360a0: ldur            w0, [x1, #0x4b]
    // 0xd360a4: DecompressPointer r0
    //     0xd360a4: add             x0, x0, HEAP, lsl #32
    // 0xd360a8: cmp             w0, NULL
    // 0xd360ac: b.ne            #0xd360c0
    // 0xd360b0: ldur            x0, [fp, #-0x20]
    // 0xd360b4: LoadField: r1 = r0->field_67
    //     0xd360b4: ldur            w1, [x0, #0x67]
    // 0xd360b8: DecompressPointer r1
    //     0xd360b8: add             x1, x1, HEAP, lsl #32
    // 0xd360bc: mov             x0, x1
    // 0xd360c0: ldur            x2, [fp, #-0x18]
    // 0xd360c4: stur            x0, [fp, #-8]
    // 0xd360c8: r1 = Function '<anonymous closure>':.
    //     0xd360c8: add             x1, PP, #0x84, lsl #12  ; [pp+0x84b40] AnonymousClosure: (0xd36fa4), in [package:flutter/src/material/scaffold.dart] ScaffoldState::build (0xd35554)
    //     0xd360cc: ldr             x1, [x1, #0xb40]
    // 0xd360d0: r0 = AllocateClosure()
    //     0xd360d0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd360d4: stur            x0, [fp, #-0x18]
    // 0xd360d8: r0 = Builder()
    //     0xd360d8: bl              #0x858774  ; AllocateBuilderStub -> Builder (size=0x10)
    // 0xd360dc: mov             x1, x0
    // 0xd360e0: ldur            x0, [fp, #-0x18]
    // 0xd360e4: stur            x1, [fp, #-0x20]
    // 0xd360e8: StoreField: r1->field_b = r0
    //     0xd360e8: stur            w0, [x1, #0xb]
    // 0xd360ec: r0 = Material()
    //     0xd360ec: bl              #0x8a54b0  ; AllocateMaterialStub -> Material (size=0x44)
    // 0xd360f0: mov             x1, x0
    // 0xd360f4: r0 = Instance_MaterialType
    //     0xd360f4: add             x0, PP, #0x17, lsl #12  ; [pp+0x17210] Obj!MaterialType@12c5341
    //     0xd360f8: ldr             x0, [x0, #0x210]
    // 0xd360fc: stur            x1, [fp, #-0x18]
    // 0xd36100: StoreField: r1->field_f = r0
    //     0xd36100: stur            w0, [x1, #0xf]
    // 0xd36104: ArrayStore: r1[0] = rZR  ; List_8
    //     0xd36104: stur            xzr, [x1, #0x17]
    // 0xd36108: ldur            x0, [fp, #-8]
    // 0xd3610c: StoreField: r1->field_1f = r0
    //     0xd3610c: stur            w0, [x1, #0x1f]
    // 0xd36110: r0 = true
    //     0xd36110: add             x0, NULL, #0x20  ; true
    // 0xd36114: StoreField: r1->field_33 = r0
    //     0xd36114: stur            w0, [x1, #0x33]
    // 0xd36118: r0 = Instance_Clip
    //     0xd36118: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xd3611c: ldr             x0, [x0, #0x840]
    // 0xd36120: StoreField: r1->field_37 = r0
    //     0xd36120: stur            w0, [x1, #0x37]
    // 0xd36124: r0 = Instance_Duration
    //     0xd36124: add             x0, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xd36128: ldr             x0, [x0, #0x318]
    // 0xd3612c: StoreField: r1->field_3b = r0
    //     0xd3612c: stur            w0, [x1, #0x3b]
    // 0xd36130: ldur            x0, [fp, #-0x20]
    // 0xd36134: StoreField: r1->field_b = r0
    //     0xd36134: stur            w0, [x1, #0xb]
    // 0xd36138: r0 = false
    //     0xd36138: add             x0, NULL, #0x30  ; false
    // 0xd3613c: StoreField: r1->field_13 = r0
    //     0xd3613c: stur            w0, [x1, #0x13]
    // 0xd36140: r0 = ScrollNotificationObserver()
    //     0xd36140: bl              #0xd36268  ; AllocateScrollNotificationObserverStub -> ScrollNotificationObserver (size=0x10)
    // 0xd36144: mov             x1, x0
    // 0xd36148: ldur            x0, [fp, #-0x18]
    // 0xd3614c: stur            x1, [fp, #-8]
    // 0xd36150: StoreField: r1->field_b = r0
    //     0xd36150: stur            w0, [x1, #0xb]
    // 0xd36154: r0 = _ScaffoldScope()
    //     0xd36154: bl              #0xd3625c  ; Allocate_ScaffoldScopeStub -> _ScaffoldScope (size=0x18)
    // 0xd36158: ldur            x1, [fp, #-0x28]
    // 0xd3615c: StoreField: r0->field_f = r1
    //     0xd3615c: stur            w1, [x0, #0xf]
    // 0xd36160: ldur            x1, [fp, #-0x10]
    // 0xd36164: StoreField: r0->field_13 = r1
    //     0xd36164: stur            w1, [x0, #0x13]
    // 0xd36168: ldur            x1, [fp, #-8]
    // 0xd3616c: StoreField: r0->field_b = r1
    //     0xd3616c: stur            w1, [x0, #0xb]
    // 0xd36170: LeaveFrame
    //     0xd36170: mov             SP, fp
    //     0xd36174: ldp             fp, lr, [SP], #0x10
    // 0xd36178: ret
    //     0xd36178: ret             
    // 0xd3617c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd3617c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd36180: b               #0xd3557c
    // 0xd36184: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd36184: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd36188: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd36188: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd3618c: r9 = _bottomSheetScrimAnimationController
    //     0xd3618c: add             x9, PP, #0x84, lsl #12  ; [pp+0x84b48] Field <ScaffoldState._bottomSheetScrimAnimationController@89420462>: late (offset: 0x7c)
    //     0xd36190: ldr             x9, [x9, #0xb48]
    // 0xd36194: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd36194: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd36198: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd36198: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd3619c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xd3619c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xd361a0: r0 = NullCastErrorSharedWithFPURegs()
    //     0xd361a0: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xd361a4: SaveReg d2
    //     0xd361a4: str             q2, [SP, #-0x10]!
    // 0xd361a8: r0 = AllocateDouble()
    //     0xd361a8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd361ac: RestoreReg d2
    //     0xd361ac: ldr             q2, [SP], #0x10
    // 0xd361b0: b               #0xd35830
    // 0xd361b4: r0 = NullCastErrorSharedWithFPURegs()
    //     0xd361b4: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xd361b8: r0 = NullCastErrorSharedWithFPURegs()
    //     0xd361b8: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xd361bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd361bc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd361c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd361c0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd361c4: r0 = NullCastErrorSharedWithFPURegs()
    //     0xd361c4: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xd361c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd361c8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd361cc: r9 = _floatingActionButtonMoveController
    //     0xd361cc: add             x9, PP, #0x84, lsl #12  ; [pp+0x84b50] Field <ScaffoldState._floatingActionButtonMoveController@89420462>: late (offset: 0x64)
    //     0xd361d0: ldr             x9, [x9, #0xb50]
    // 0xd361d4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd361d4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd361d8: r9 = _floatingActionButtonAnimator
    //     0xd361d8: add             x9, PP, #0x84, lsl #12  ; [pp+0x84b58] Field <ScaffoldState._floatingActionButtonAnimator@89420462>: late (offset: 0x68)
    //     0xd361dc: ldr             x9, [x9, #0xb58]
    // 0xd361e0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd361e0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd361e4: r9 = _geometryNotifier
    //     0xd361e4: add             x9, PP, #0x84, lsl #12  ; [pp+0x84b60] Field <ScaffoldState._geometryNotifier@89420462>: late (offset: 0x78)
    //     0xd361e8: ldr             x9, [x9, #0xb60]
    // 0xd361ec: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd361ec: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd361f0: r9 = _floatingActionButtonVisibilityController
    //     0xd361f0: add             x9, PP, #0x84, lsl #12  ; [pp+0x84b68] Field <ScaffoldState._floatingActionButtonVisibilityController@89420462>: late (offset: 0x74)
    //     0xd361f4: ldr             x9, [x9, #0xb68]
    // 0xd361f8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd361f8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd361fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd361fc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd36200: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd36200: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd36204: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd36204: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd36208: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd36208: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd3620c: SaveReg d0
    //     0xd3620c: str             q0, [SP, #-0x10]!
    // 0xd36210: SaveReg r2
    //     0xd36210: str             x2, [SP, #-8]!
    // 0xd36214: r0 = AllocateDouble()
    //     0xd36214: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd36218: RestoreReg r2
    //     0xd36218: ldr             x2, [SP], #8
    // 0xd3621c: RestoreReg d0
    //     0xd3621c: ldr             q0, [SP], #0x10
    // 0xd36220: b               #0xd35fc8
    // 0xd36224: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd36224: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _resizeToAvoidBottomInset(/* No info */) {
    // ** addr: 0xd36274, size: 0x3c
    // 0xd36274: LoadField: r2 = r1->field_b
    //     0xd36274: ldur            w2, [x1, #0xb]
    // 0xd36278: DecompressPointer r2
    //     0xd36278: add             x2, x2, HEAP, lsl #32
    // 0xd3627c: cmp             w2, NULL
    // 0xd36280: b.eq            #0xd362a4
    // 0xd36284: LoadField: r1 = r2->field_57
    //     0xd36284: ldur            w1, [x2, #0x57]
    // 0xd36288: DecompressPointer r1
    //     0xd36288: add             x1, x1, HEAP, lsl #32
    // 0xd3628c: cmp             w1, NULL
    // 0xd36290: b.ne            #0xd3629c
    // 0xd36294: r0 = true
    //     0xd36294: add             x0, NULL, #0x20  ; true
    // 0xd36298: b               #0xd362a0
    // 0xd3629c: mov             x0, x1
    // 0xd362a0: ret
    //     0xd362a0: ret             
    // 0xd362a4: EnterFrame
    //     0xd362a4: stp             fp, lr, [SP, #-0x10]!
    //     0xd362a8: mov             fp, SP
    // 0xd362ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd362ac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _buildDrawer(/* No info */) {
    // ** addr: 0xd362fc, size: 0x188
    // 0xd362fc: EnterFrame
    //     0xd362fc: stp             fp, lr, [SP, #-0x10]!
    //     0xd36300: mov             fp, SP
    // 0xd36304: AllocStack(0x48)
    //     0xd36304: sub             SP, SP, #0x48
    // 0xd36308: SetupParameters(ScaffoldState this /* r1 => r5, fp-0x20 */, dynamic _ /* r2 => r4, fp-0x28 */, dynamic _ /* r3 => r3, fp-0x30 */)
    //     0xd36308: mov             x5, x1
    //     0xd3630c: mov             x4, x2
    //     0xd36310: stur            x1, [fp, #-0x20]
    //     0xd36314: stur            x2, [fp, #-0x28]
    //     0xd36318: stur            x3, [fp, #-0x30]
    // 0xd3631c: CheckStackOverflow
    //     0xd3631c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd36320: cmp             SP, x16
    //     0xd36324: b.ls            #0xd36478
    // 0xd36328: LoadField: r0 = r5->field_b
    //     0xd36328: ldur            w0, [x5, #0xb]
    // 0xd3632c: DecompressPointer r0
    //     0xd3632c: add             x0, x0, HEAP, lsl #32
    // 0xd36330: cmp             w0, NULL
    // 0xd36334: b.eq            #0xd36480
    // 0xd36338: LoadField: r6 = r0->field_33
    //     0xd36338: ldur            w6, [x0, #0x33]
    // 0xd3633c: DecompressPointer r6
    //     0xd3633c: add             x6, x6, HEAP, lsl #32
    // 0xd36340: stur            x6, [fp, #-0x18]
    // 0xd36344: cmp             w6, NULL
    // 0xd36348: b.eq            #0xd36468
    // 0xd3634c: LoadField: r7 = r5->field_2b
    //     0xd3634c: ldur            w7, [x5, #0x2b]
    // 0xd36350: DecompressPointer r7
    //     0xd36350: add             x7, x7, HEAP, lsl #32
    // 0xd36354: stur            x7, [fp, #-0x10]
    // 0xd36358: LoadField: r0 = r5->field_3f
    //     0xd36358: ldur            w0, [x5, #0x3f]
    // 0xd3635c: DecompressPointer r0
    //     0xd3635c: add             x0, x0, HEAP, lsl #32
    // 0xd36360: LoadField: r8 = r0->field_33
    //     0xd36360: ldur            w8, [x0, #0x33]
    // 0xd36364: DecompressPointer r8
    //     0xd36364: add             x8, x8, HEAP, lsl #32
    // 0xd36368: stur            x8, [fp, #-8]
    // 0xd3636c: cmp             w8, NULL
    // 0xd36370: b.ne            #0xd363a8
    // 0xd36374: LoadField: r2 = r0->field_23
    //     0xd36374: ldur            w2, [x0, #0x23]
    // 0xd36378: DecompressPointer r2
    //     0xd36378: add             x2, x2, HEAP, lsl #32
    // 0xd3637c: mov             x0, x8
    // 0xd36380: r1 = Null
    //     0xd36380: mov             x1, NULL
    // 0xd36384: cmp             w2, NULL
    // 0xd36388: b.eq            #0xd363a8
    // 0xd3638c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xd3638c: ldur            w4, [x2, #0x17]
    // 0xd36390: DecompressPointer r4
    //     0xd36390: add             x4, x4, HEAP, lsl #32
    // 0xd36394: r8 = X0
    //     0xd36394: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xd36398: LoadField: r9 = r4->field_7
    //     0xd36398: ldur            x9, [x4, #7]
    // 0xd3639c: r3 = Null
    //     0xd3639c: add             x3, PP, #0x84, lsl #12  ; [pp+0x84ba0] Null
    //     0xd363a0: ldr             x3, [x3, #0xba0]
    // 0xd363a4: blr             x9
    // 0xd363a8: ldur            x0, [fp, #-0x30]
    // 0xd363ac: ldur            x1, [fp, #-0x18]
    // 0xd363b0: ldur            x2, [fp, #-0x10]
    // 0xd363b4: ldur            x3, [fp, #-8]
    // 0xd363b8: r0 = DrawerController()
    //     0xd363b8: bl              #0xd36484  ; AllocateDrawerControllerStub -> DrawerController (size=0x30)
    // 0xd363bc: mov             x3, x0
    // 0xd363c0: ldur            x0, [fp, #-0x18]
    // 0xd363c4: stur            x3, [fp, #-0x38]
    // 0xd363c8: StoreField: r3->field_b = r0
    //     0xd363c8: stur            w0, [x3, #0xb]
    // 0xd363cc: r0 = Instance_DrawerAlignment
    //     0xd363cc: add             x0, PP, #0x84, lsl #12  ; [pp+0x84bb0] Obj!DrawerAlignment@12c57e1
    //     0xd363d0: ldr             x0, [x0, #0xbb0]
    // 0xd363d4: StoreField: r3->field_f = r0
    //     0xd363d4: stur            w0, [x3, #0xf]
    // 0xd363d8: ldur            x0, [fp, #-8]
    // 0xd363dc: StoreField: r3->field_2b = r0
    //     0xd363dc: stur            w0, [x3, #0x2b]
    // 0xd363e0: ldur            x2, [fp, #-0x20]
    // 0xd363e4: r1 = Function '_drawerOpenedCallback@89420462':.
    //     0xd363e4: add             x1, PP, #0x84, lsl #12  ; [pp+0x84bb8] AnonymousClosure: (0xb34c34), in [package:flutter/src/material/scaffold.dart] ScaffoldState::_drawerOpenedCallback (0xb34ca8)
    //     0xd363e8: ldr             x1, [x1, #0xbb8]
    // 0xd363ec: r0 = AllocateClosure()
    //     0xd363ec: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd363f0: ldur            x3, [fp, #-0x38]
    // 0xd363f4: StoreField: r3->field_13 = r0
    //     0xd363f4: stur            w0, [x3, #0x13]
    // 0xd363f8: r0 = Instance_DragStartBehavior
    //     0xd363f8: ldr             x0, [PP, #0x5360]  ; [pp+0x5360] Obj!DragStartBehavior@12c5c61
    // 0xd363fc: StoreField: r3->field_1b = r0
    //     0xd363fc: stur            w0, [x3, #0x1b]
    // 0xd36400: r0 = true
    //     0xd36400: add             x0, NULL, #0x20  ; true
    // 0xd36404: StoreField: r3->field_23 = r0
    //     0xd36404: stur            w0, [x3, #0x23]
    // 0xd36408: ArrayStore: r3[0] = r0  ; List_4
    //     0xd36408: stur            w0, [x3, #0x17]
    // 0xd3640c: ldur            x0, [fp, #-0x10]
    // 0xd36410: StoreField: r3->field_7 = r0
    //     0xd36410: stur            w0, [x3, #7]
    // 0xd36414: ldur            x0, [fp, #-0x30]
    // 0xd36418: r16 = Instance_TextDirection
    //     0xd36418: ldr             x16, [PP, #0x2578]  ; [pp+0x2578] Obj!TextDirection@12c7381
    // 0xd3641c: cmp             w0, w16
    // 0xd36420: r16 = true
    //     0xd36420: add             x16, NULL, #0x20  ; true
    // 0xd36424: r17 = false
    //     0xd36424: add             x17, NULL, #0x30  ; false
    // 0xd36428: csel            x7, x16, x17, eq
    // 0xd3642c: r16 = Instance_TextDirection
    //     0xd3642c: ldr             x16, [PP, #0x25b0]  ; [pp+0x25b0] Obj!TextDirection@12c73a1
    // 0xd36430: cmp             w0, w16
    // 0xd36434: r16 = true
    //     0xd36434: add             x16, NULL, #0x20  ; true
    // 0xd36438: r17 = false
    //     0xd36438: add             x17, NULL, #0x30  ; false
    // 0xd3643c: csel            x1, x16, x17, eq
    // 0xd36440: r16 = false
    //     0xd36440: add             x16, NULL, #0x30  ; false
    // 0xd36444: stp             x16, x1, [SP]
    // 0xd36448: ldur            x1, [fp, #-0x20]
    // 0xd3644c: ldur            x2, [fp, #-0x28]
    // 0xd36450: r5 = Instance__ScaffoldSlot
    //     0xd36450: add             x5, PP, #0x84, lsl #12  ; [pp+0x84bc0] Obj!_ScaffoldSlot@12c4f81
    //     0xd36454: ldr             x5, [x5, #0xbc0]
    // 0xd36458: r6 = false
    //     0xd36458: add             x6, NULL, #0x30  ; false
    // 0xd3645c: r4 = const [0, 0x8, 0x2, 0x8, null]
    //     0xd3645c: add             x4, PP, #0x18, lsl #12  ; [pp+0x18a60] List(5) [0, 0x8, 0x2, 0x8, Null]
    //     0xd36460: ldr             x4, [x4, #0xa60]
    // 0xd36464: r0 = _addIfNonNull()
    //     0xd36464: bl              #0xd36854  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::_addIfNonNull
    // 0xd36468: r0 = Null
    //     0xd36468: mov             x0, NULL
    // 0xd3646c: LeaveFrame
    //     0xd3646c: mov             SP, fp
    //     0xd36470: ldp             fp, lr, [SP], #0x10
    // 0xd36474: ret
    //     0xd36474: ret             
    // 0xd36478: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd36478: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd3647c: b               #0xd36328
    // 0xd36480: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd36480: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _addIfNonNull(/* No info */) {
    // ** addr: 0xd36854, size: 0x33c
    // 0xd36854: EnterFrame
    //     0xd36854: stp             fp, lr, [SP, #-0x10]!
    //     0xd36858: mov             fp, SP
    // 0xd3685c: AllocStack(0x58)
    //     0xd3685c: sub             SP, SP, #0x58
    // 0xd36860: SetupParameters(dynamic _ /* r2 => r6, fp-0x30 */, dynamic _ /* r6 => r3, fp-0x48 */, [dynamic _ /* fp-0x38 */])
    //     0xd36860: stur            x2, [fp, #-0x28]
    //     0xd36864: mov             x16, x6
    //     0xd36868: mov             x6, x2
    //     0xd3686c: mov             x2, x16
    //     0xd36870: mov             x0, x3
    //     0xd36874: stur            x3, [fp, #-0x30]
    //     0xd36878: mov             x3, x7
    //     0xd3687c: stur            x5, [fp, #-0x38]
    //     0xd36880: stur            x2, [fp, #-0x40]
    //     0xd36884: stur            x7, [fp, #-0x48]
    // 0xd36888: LoadField: r7 = r4->field_13
    //     0xd36888: ldur            w7, [x4, #0x13]
    // 0xd3688c: sub             x8, x7, #0x10
    // 0xd36890: add             x9, fp, w8, sxtw #2
    // 0xd36894: ldr             x9, [x9, #0x18]
    // 0xd36898: stur            x9, [fp, #-0x20]
    // 0xd3689c: add             x10, fp, w8, sxtw #2
    // 0xd368a0: ldr             x10, [x10, #0x10]
    // 0xd368a4: stur            x10, [fp, #-0x18]
    // 0xd368a8: LoadField: r8 = r4->field_1f
    //     0xd368a8: ldur            w8, [x4, #0x1f]
    // 0xd368ac: DecompressPointer r8
    //     0xd368ac: add             x8, x8, HEAP, lsl #32
    // 0xd368b0: r16 = "maintainBottomViewPadding"
    //     0xd368b0: add             x16, PP, #0x84, lsl #12  ; [pp+0x84be0] "maintainBottomViewPadding"
    //     0xd368b4: ldr             x16, [x16, #0xbe0]
    // 0xd368b8: cmp             w8, w16
    // 0xd368bc: b.ne            #0xd368e0
    // 0xd368c0: LoadField: r8 = r4->field_23
    //     0xd368c0: ldur            w8, [x4, #0x23]
    // 0xd368c4: DecompressPointer r8
    //     0xd368c4: add             x8, x8, HEAP, lsl #32
    // 0xd368c8: sub             w11, w7, w8
    // 0xd368cc: add             x8, fp, w11, sxtw #2
    // 0xd368d0: ldr             x8, [x8, #8]
    // 0xd368d4: mov             x11, x8
    // 0xd368d8: r8 = 1
    //     0xd368d8: mov             x8, #1
    // 0xd368dc: b               #0xd368e8
    // 0xd368e0: r11 = false
    //     0xd368e0: add             x11, NULL, #0x30  ; false
    // 0xd368e4: r8 = 0
    //     0xd368e4: mov             x8, #0
    // 0xd368e8: stur            x11, [fp, #-0x10]
    // 0xd368ec: lsl             x12, x8, #1
    // 0xd368f0: lsl             w8, w12, #1
    // 0xd368f4: add             w12, w8, #8
    // 0xd368f8: ArrayLoad: r13 = r4[r12]  ; Unknown_4
    //     0xd368f8: add             x16, x4, w12, sxtw #1
    //     0xd368fc: ldur            w13, [x16, #0xf]
    // 0xd36900: DecompressPointer r13
    //     0xd36900: add             x13, x13, HEAP, lsl #32
    // 0xd36904: r16 = "removeBottomInset"
    //     0xd36904: add             x16, PP, #0x84, lsl #12  ; [pp+0x84be8] "removeBottomInset"
    //     0xd36908: ldr             x16, [x16, #0xbe8]
    // 0xd3690c: cmp             w13, w16
    // 0xd36910: b.ne            #0xd36938
    // 0xd36914: add             w12, w8, #0xa
    // 0xd36918: ArrayLoad: r8 = r4[r12]  ; Unknown_4
    //     0xd36918: add             x16, x4, w12, sxtw #1
    //     0xd3691c: ldur            w8, [x16, #0xf]
    // 0xd36920: DecompressPointer r8
    //     0xd36920: add             x8, x8, HEAP, lsl #32
    // 0xd36924: sub             w4, w7, w8
    // 0xd36928: add             x7, fp, w4, sxtw #2
    // 0xd3692c: ldr             x7, [x7, #8]
    // 0xd36930: mov             x4, x7
    // 0xd36934: b               #0xd3693c
    // 0xd36938: r4 = false
    //     0xd36938: add             x4, NULL, #0x30  ; false
    // 0xd3693c: stur            x4, [fp, #-8]
    // 0xd36940: CheckStackOverflow
    //     0xd36940: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd36944: cmp             SP, x16
    //     0xd36948: b.ls            #0xd36b6c
    // 0xd3694c: LoadField: r7 = r1->field_f
    //     0xd3694c: ldur            w7, [x1, #0xf]
    // 0xd36950: DecompressPointer r7
    //     0xd36950: add             x7, x7, HEAP, lsl #32
    // 0xd36954: cmp             w7, NULL
    // 0xd36958: b.eq            #0xd36b74
    // 0xd3695c: mov             x1, x7
    // 0xd36960: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd36960: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd36964: r0 = _of()
    //     0xd36964: bl              #0x8651cc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::_of
    // 0xd36968: mov             x1, x0
    // 0xd3696c: ldur            x2, [fp, #-0x40]
    // 0xd36970: ldur            x3, [fp, #-0x48]
    // 0xd36974: ldur            x5, [fp, #-0x20]
    // 0xd36978: ldur            x6, [fp, #-0x18]
    // 0xd3697c: r0 = removePadding()
    //     0xd3697c: bl              #0xd0a79c  ; [package:flutter/src/widgets/media_query.dart] MediaQueryData::removePadding
    // 0xd36980: mov             x1, x0
    // 0xd36984: ldur            x0, [fp, #-8]
    // 0xd36988: tbnz            w0, #4, #0xd3699c
    // 0xd3698c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd3698c: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd36990: r0 = removeViewInsets()
    //     0xd36990: bl              #0xd36bc0  ; [package:flutter/src/widgets/media_query.dart] MediaQueryData::removeViewInsets
    // 0xd36994: mov             x2, x0
    // 0xd36998: b               #0xd369a0
    // 0xd3699c: mov             x2, x1
    // 0xd369a0: ldur            x0, [fp, #-0x10]
    // 0xd369a4: stur            x2, [fp, #-8]
    // 0xd369a8: tbnz            w0, #4, #0xd36a2c
    // 0xd369ac: d0 = 0.000000
    //     0xd369ac: eor             v0.16b, v0.16b, v0.16b
    // 0xd369b0: LoadField: r0 = r2->field_23
    //     0xd369b0: ldur            w0, [x2, #0x23]
    // 0xd369b4: DecompressPointer r0
    //     0xd369b4: add             x0, x0, HEAP, lsl #32
    // 0xd369b8: LoadField: d1 = r0->field_1f
    //     0xd369b8: ldur            d1, [x0, #0x1f]
    // 0xd369bc: fcmp            d1, d0
    // 0xd369c0: b.eq            #0xd36a2c
    // 0xd369c4: LoadField: r1 = r2->field_27
    //     0xd369c4: ldur            w1, [x2, #0x27]
    // 0xd369c8: DecompressPointer r1
    //     0xd369c8: add             x1, x1, HEAP, lsl #32
    // 0xd369cc: LoadField: r0 = r2->field_2b
    //     0xd369cc: ldur            w0, [x2, #0x2b]
    // 0xd369d0: DecompressPointer r0
    //     0xd369d0: add             x0, x0, HEAP, lsl #32
    // 0xd369d4: LoadField: d0 = r0->field_1f
    //     0xd369d4: ldur            d0, [x0, #0x1f]
    // 0xd369d8: r0 = inline_Allocate_Double()
    //     0xd369d8: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0xd369dc: add             x0, x0, #0x10
    //     0xd369e0: cmp             x3, x0
    //     0xd369e4: b.ls            #0xd36b78
    //     0xd369e8: str             x0, [THR, #0x60]  ; THR::top
    //     0xd369ec: sub             x0, x0, #0xf
    //     0xd369f0: mov             x3, #0xe19c
    //     0xd369f4: movk            x3, #3, lsl #16
    //     0xd369f8: stur            x3, [x0, #-1]
    // 0xd369fc: dmb             ishst
    // 0xd36a00: StoreField: r0->field_7 = d0
    //     0xd36a00: stur            d0, [x0, #7]
    // 0xd36a04: str             x0, [SP]
    // 0xd36a08: r4 = const [0, 0x2, 0x1, 0x1, bottom, 0x1, null]
    //     0xd36a08: ldr             x4, [PP, #0x5658]  ; [pp+0x5658] List(7) [0, 0x2, 0x1, 0x1, "bottom", 0x1, Null]
    // 0xd36a0c: r0 = copyWith()
    //     0xd36a0c: bl              #0x86fd70  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::copyWith
    // 0xd36a10: str             x0, [SP]
    // 0xd36a14: ldur            x1, [fp, #-8]
    // 0xd36a18: r4 = const [0, 0x2, 0x1, 0x1, padding, 0x1, null]
    //     0xd36a18: add             x4, PP, #0x19, lsl #12  ; [pp+0x19df0] List(7) [0, 0x2, 0x1, 0x1, "padding", 0x1, Null]
    //     0xd36a1c: ldr             x4, [x4, #0xdf0]
    // 0xd36a20: r0 = copyWith()
    //     0xd36a20: bl              #0xd0aa98  ; [package:flutter/src/widgets/media_query.dart] MediaQueryData::copyWith
    // 0xd36a24: mov             x2, x0
    // 0xd36a28: b               #0xd36a30
    // 0xd36a2c: ldur            x2, [fp, #-8]
    // 0xd36a30: ldur            x0, [fp, #-0x30]
    // 0xd36a34: stur            x2, [fp, #-8]
    // 0xd36a38: cmp             w0, NULL
    // 0xd36a3c: b.eq            #0xd36b5c
    // 0xd36a40: ldur            x4, [fp, #-0x28]
    // 0xd36a44: ldur            x3, [fp, #-0x38]
    // 0xd36a48: r1 = <_MediaQueryAspect>
    //     0xd36a48: add             x1, PP, #0x12, lsl #12  ; [pp+0x12828] TypeArguments: <_MediaQueryAspect>
    //     0xd36a4c: ldr             x1, [x1, #0x828]
    // 0xd36a50: r0 = MediaQuery()
    //     0xd36a50: bl              #0xd0af24  ; AllocateMediaQueryStub -> MediaQuery (size=0x18)
    // 0xd36a54: mov             x2, x0
    // 0xd36a58: ldur            x0, [fp, #-8]
    // 0xd36a5c: stur            x2, [fp, #-0x10]
    // 0xd36a60: StoreField: r2->field_13 = r0
    //     0xd36a60: stur            w0, [x2, #0x13]
    // 0xd36a64: ldur            x0, [fp, #-0x30]
    // 0xd36a68: StoreField: r2->field_b = r0
    //     0xd36a68: stur            w0, [x2, #0xb]
    // 0xd36a6c: r1 = <MultiChildLayoutParentData>
    //     0xd36a6c: add             x1, PP, #0x84, lsl #12  ; [pp+0x84bf0] TypeArguments: <MultiChildLayoutParentData>
    //     0xd36a70: ldr             x1, [x1, #0xbf0]
    // 0xd36a74: r0 = LayoutId()
    //     0xd36a74: bl              #0xd36bb4  ; AllocateLayoutIdStub -> LayoutId (size=0x18)
    // 0xd36a78: mov             x2, x0
    // 0xd36a7c: ldur            x0, [fp, #-0x38]
    // 0xd36a80: stur            x2, [fp, #-8]
    // 0xd36a84: StoreField: r2->field_13 = r0
    //     0xd36a84: stur            w0, [x2, #0x13]
    // 0xd36a88: r1 = <Object>
    //     0xd36a88: ldr             x1, [PP, #0x720]  ; [pp+0x720] TypeArguments: <Object>
    // 0xd36a8c: r0 = ValueKey()
    //     0xd36a8c: bl              #0x8e283c  ; AllocateValueKeyStub -> ValueKey<X0> (size=0x10)
    // 0xd36a90: mov             x1, x0
    // 0xd36a94: ldur            x0, [fp, #-0x38]
    // 0xd36a98: StoreField: r1->field_b = r0
    //     0xd36a98: stur            w0, [x1, #0xb]
    // 0xd36a9c: ldur            x0, [fp, #-0x10]
    // 0xd36aa0: ldur            x3, [fp, #-8]
    // 0xd36aa4: StoreField: r3->field_b = r0
    //     0xd36aa4: stur            w0, [x3, #0xb]
    // 0xd36aa8: StoreField: r3->field_7 = r1
    //     0xd36aa8: stur            w1, [x3, #7]
    // 0xd36aac: ldur            x4, [fp, #-0x28]
    // 0xd36ab0: LoadField: r2 = r4->field_7
    //     0xd36ab0: ldur            w2, [x4, #7]
    // 0xd36ab4: DecompressPointer r2
    //     0xd36ab4: add             x2, x2, HEAP, lsl #32
    // 0xd36ab8: mov             x0, x3
    // 0xd36abc: r1 = Null
    //     0xd36abc: mov             x1, NULL
    // 0xd36ac0: cmp             w2, NULL
    // 0xd36ac4: b.eq            #0xd36ae4
    // 0xd36ac8: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xd36ac8: ldur            w4, [x2, #0x17]
    // 0xd36acc: DecompressPointer r4
    //     0xd36acc: add             x4, x4, HEAP, lsl #32
    // 0xd36ad0: r8 = X0
    //     0xd36ad0: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xd36ad4: LoadField: r9 = r4->field_7
    //     0xd36ad4: ldur            x9, [x4, #7]
    // 0xd36ad8: r3 = Null
    //     0xd36ad8: add             x3, PP, #0x84, lsl #12  ; [pp+0x84bf8] Null
    //     0xd36adc: ldr             x3, [x3, #0xbf8]
    // 0xd36ae0: blr             x9
    // 0xd36ae4: ldur            x0, [fp, #-0x28]
    // 0xd36ae8: LoadField: r1 = r0->field_b
    //     0xd36ae8: ldur            w1, [x0, #0xb]
    // 0xd36aec: LoadField: r2 = r0->field_f
    //     0xd36aec: ldur            w2, [x0, #0xf]
    // 0xd36af0: DecompressPointer r2
    //     0xd36af0: add             x2, x2, HEAP, lsl #32
    // 0xd36af4: LoadField: r3 = r2->field_b
    //     0xd36af4: ldur            w3, [x2, #0xb]
    // 0xd36af8: r2 = LoadInt32Instr(r1)
    //     0xd36af8: sbfx            x2, x1, #1, #0x1f
    // 0xd36afc: stur            x2, [fp, #-0x50]
    // 0xd36b00: r1 = LoadInt32Instr(r3)
    //     0xd36b00: sbfx            x1, x3, #1, #0x1f
    // 0xd36b04: cmp             x2, x1
    // 0xd36b08: b.ne            #0xd36b14
    // 0xd36b0c: mov             x1, x0
    // 0xd36b10: r0 = _growToNextCapacity()
    //     0xd36b10: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xd36b14: ldur            x2, [fp, #-0x28]
    // 0xd36b18: ldur            x3, [fp, #-0x50]
    // 0xd36b1c: add             x4, x3, #1
    // 0xd36b20: lsl             x5, x4, #1
    // 0xd36b24: StoreField: r2->field_b = r5
    //     0xd36b24: stur            w5, [x2, #0xb]
    // 0xd36b28: LoadField: r1 = r2->field_f
    //     0xd36b28: ldur            w1, [x2, #0xf]
    // 0xd36b2c: DecompressPointer r1
    //     0xd36b2c: add             x1, x1, HEAP, lsl #32
    // 0xd36b30: ldur            x0, [fp, #-8]
    // 0xd36b34: ArrayStore: r1[r3] = r0  ; List_4
    //     0xd36b34: add             x25, x1, x3, lsl #2
    //     0xd36b38: add             x25, x25, #0xf
    //     0xd36b3c: str             w0, [x25]
    //     0xd36b40: tbz             w0, #0, #0xd36b5c
    //     0xd36b44: ldurb           w16, [x1, #-1]
    //     0xd36b48: ldurb           w17, [x0, #-1]
    //     0xd36b4c: and             x16, x17, x16, lsr #2
    //     0xd36b50: tst             x16, HEAP, lsr #32
    //     0xd36b54: b.eq            #0xd36b5c
    //     0xd36b58: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd36b5c: r0 = Null
    //     0xd36b5c: mov             x0, NULL
    // 0xd36b60: LeaveFrame
    //     0xd36b60: mov             SP, fp
    //     0xd36b64: ldp             fp, lr, [SP], #0x10
    // 0xd36b68: ret
    //     0xd36b68: ret             
    // 0xd36b6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd36b6c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd36b70: b               #0xd3694c
    // 0xd36b74: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd36b74: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd36b78: SaveReg d0
    //     0xd36b78: str             q0, [SP, #-0x10]!
    // 0xd36b7c: stp             x1, x2, [SP, #-0x10]!
    // 0xd36b80: r0 = AllocateDouble()
    //     0xd36b80: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd36b84: ldp             x1, x2, [SP], #0x10
    // 0xd36b88: RestoreReg d0
    //     0xd36b88: ldr             q0, [SP], #0x10
    // 0xd36b8c: b               #0xd36a00
  }
  [closure] Actions <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0xd36fa4, size: 0x2ac
    // 0xd36fa4: EnterFrame
    //     0xd36fa4: stp             fp, lr, [SP, #-0x10]!
    //     0xd36fa8: mov             fp, SP
    // 0xd36fac: AllocStack(0x80)
    //     0xd36fac: sub             SP, SP, #0x80
    // 0xd36fb0: SetupParameters([dynamic _ /* r0 */])
    //     0xd36fb0: ldr             x0, [fp, #0x18]
    //     0xd36fb4: ldur            w3, [x0, #0x17]
    //     0xd36fb8: add             x3, x3, HEAP, lsl #32
    //     0xd36fbc: stur            x3, [fp, #-8]
    // 0xd36fc0: CheckStackOverflow
    //     0xd36fc0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd36fc4: cmp             SP, x16
    //     0xd36fc8: b.ls            #0xd37218
    // 0xd36fcc: r1 = Null
    //     0xd36fcc: mov             x1, NULL
    // 0xd36fd0: r2 = 4
    //     0xd36fd0: mov             x2, #4
    // 0xd36fd4: r0 = AllocateArray()
    //     0xd36fd4: bl              #0x13df928  ; AllocateArrayStub
    // 0xd36fd8: stur            x0, [fp, #-0x10]
    // 0xd36fdc: r16 = DismissIntent
    //     0xd36fdc: add             x16, PP, #0x84, lsl #12  ; [pp+0x84b70] Type: DismissIntent
    //     0xd36fe0: ldr             x16, [x16, #0xb70]
    // 0xd36fe4: StoreField: r0->field_f = r16
    //     0xd36fe4: stur            w16, [x0, #0xf]
    // 0xd36fe8: r1 = <DismissIntent>
    //     0xd36fe8: add             x1, PP, #0x84, lsl #12  ; [pp+0x84b78] TypeArguments: <DismissIntent>
    //     0xd36fec: ldr             x1, [x1, #0xb78]
    // 0xd36ff0: r0 = _DismissDrawerAction()
    //     0xd36ff0: bl              #0xd373c4  ; Allocate_DismissDrawerActionStub -> _DismissDrawerAction (size=0x18)
    // 0xd36ff4: mov             x2, x0
    // 0xd36ff8: ldr             x0, [fp, #0x10]
    // 0xd36ffc: stur            x2, [fp, #-0x18]
    // 0xd37000: StoreField: r2->field_13 = r0
    //     0xd37000: stur            w0, [x2, #0x13]
    // 0xd37004: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0xd37004: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a7a0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0xd37008: ldr             x1, [x1, #0x7a0]
    // 0xd3700c: r0 = ObserverList()
    //     0xd3700c: bl              #0x89f8bc  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0xd37010: mov             x3, x0
    // 0xd37014: r0 = false
    //     0xd37014: add             x0, NULL, #0x30  ; false
    // 0xd37018: stur            x3, [fp, #-0x20]
    // 0xd3701c: StoreField: r3->field_f = r0
    //     0xd3701c: stur            w0, [x3, #0xf]
    // 0xd37020: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xd37024: StoreField: r3->field_13 = r0
    //     0xd37024: stur            w0, [x3, #0x13]
    // 0xd37028: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0xd37028: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a7a0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0xd3702c: ldr             x1, [x1, #0x7a0]
    // 0xd37030: r2 = 0
    //     0xd37030: mov             x2, #0
    // 0xd37034: r0 = _GrowableList()
    //     0xd37034: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xd37038: ldur            x1, [fp, #-0x20]
    // 0xd3703c: StoreField: r1->field_b = r0
    //     0xd3703c: stur            w0, [x1, #0xb]
    //     0xd37040: ldurb           w16, [x1, #-1]
    //     0xd37044: ldurb           w17, [x0, #-1]
    //     0xd37048: and             x16, x17, x16, lsr #2
    //     0xd3704c: tst             x16, HEAP, lsr #32
    //     0xd37050: b.eq            #0xd37058
    //     0xd37054: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd37058: mov             x0, x1
    // 0xd3705c: ldur            x1, [fp, #-0x18]
    // 0xd37060: StoreField: r1->field_b = r0
    //     0xd37060: stur            w0, [x1, #0xb]
    //     0xd37064: ldurb           w16, [x1, #-1]
    //     0xd37068: ldurb           w17, [x0, #-1]
    //     0xd3706c: and             x16, x17, x16, lsr #2
    //     0xd37070: tst             x16, HEAP, lsr #32
    //     0xd37074: b.eq            #0xd3707c
    //     0xd37078: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd3707c: mov             x0, x1
    // 0xd37080: ldur            x1, [fp, #-0x10]
    // 0xd37084: ArrayStore: r1[1] = r0  ; List_4
    //     0xd37084: add             x25, x1, #0x13
    //     0xd37088: str             w0, [x25]
    //     0xd3708c: tbz             w0, #0, #0xd370a8
    //     0xd37090: ldurb           w16, [x1, #-1]
    //     0xd37094: ldurb           w17, [x0, #-1]
    //     0xd37098: and             x16, x17, x16, lsr #2
    //     0xd3709c: tst             x16, HEAP, lsr #32
    //     0xd370a0: b.eq            #0xd370a8
    //     0xd370a4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd370a8: r16 = <Type, Action<Intent>>
    //     0xd370a8: add             x16, PP, #0x84, lsl #12  ; [pp+0x84b80] TypeArguments: <Type, Action<Intent>>
    //     0xd370ac: ldr             x16, [x16, #0xb80]
    // 0xd370b0: ldur            lr, [fp, #-0x10]
    // 0xd370b4: stp             lr, x16, [SP]
    // 0xd370b8: r0 = Map._fromLiteral()
    //     0xd370b8: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xd370bc: mov             x1, x0
    // 0xd370c0: ldur            x0, [fp, #-8]
    // 0xd370c4: stur            x1, [fp, #-0x58]
    // 0xd370c8: LoadField: r2 = r0->field_f
    //     0xd370c8: ldur            w2, [x0, #0xf]
    // 0xd370cc: DecompressPointer r2
    //     0xd370cc: add             x2, x2, HEAP, lsl #32
    // 0xd370d0: LoadField: r3 = r2->field_b
    //     0xd370d0: ldur            w3, [x2, #0xb]
    // 0xd370d4: DecompressPointer r3
    //     0xd370d4: add             x3, x3, HEAP, lsl #32
    // 0xd370d8: cmp             w3, NULL
    // 0xd370dc: b.eq            #0xd37220
    // 0xd370e0: LoadField: r3 = r2->field_6f
    //     0xd370e0: ldur            w3, [x2, #0x6f]
    // 0xd370e4: DecompressPointer r3
    //     0xd370e4: add             x3, x3, HEAP, lsl #32
    // 0xd370e8: cmp             w3, NULL
    // 0xd370ec: b.eq            #0xd37224
    // 0xd370f0: LoadField: r3 = r2->field_63
    //     0xd370f0: ldur            w3, [x2, #0x63]
    // 0xd370f4: DecompressPointer r3
    //     0xd370f4: add             x3, x3, HEAP, lsl #32
    // 0xd370f8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd370fc: cmp             w3, w16
    // 0xd37100: b.eq            #0xd37228
    // 0xd37104: stur            x3, [fp, #-0x50]
    // 0xd37108: LoadField: r4 = r2->field_67
    //     0xd37108: ldur            w4, [x2, #0x67]
    // 0xd3710c: DecompressPointer r4
    //     0xd3710c: add             x4, x4, HEAP, lsl #32
    // 0xd37110: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd37114: cmp             w4, w16
    // 0xd37118: b.eq            #0xd37234
    // 0xd3711c: LoadField: r5 = r2->field_77
    //     0xd3711c: ldur            w5, [x2, #0x77]
    // 0xd37120: DecompressPointer r5
    //     0xd37120: add             x5, x5, HEAP, lsl #32
    // 0xd37124: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd37128: cmp             w5, w16
    // 0xd3712c: b.eq            #0xd37240
    // 0xd37130: stur            x5, [fp, #-0x48]
    // 0xd37134: LoadField: r4 = r2->field_6b
    //     0xd37134: ldur            w4, [x2, #0x6b]
    // 0xd37138: DecompressPointer r4
    //     0xd37138: add             x4, x4, HEAP, lsl #32
    // 0xd3713c: stur            x4, [fp, #-0x40]
    // 0xd37140: cmp             w4, NULL
    // 0xd37144: b.eq            #0xd3724c
    // 0xd37148: LoadField: r6 = r0->field_1b
    //     0xd37148: ldur            w6, [x0, #0x1b]
    // 0xd3714c: DecompressPointer r6
    //     0xd3714c: add             x6, x6, HEAP, lsl #32
    // 0xd37150: stur            x6, [fp, #-0x38]
    // 0xd37154: LoadField: r2 = r0->field_23
    //     0xd37154: ldur            w2, [x0, #0x23]
    // 0xd37158: DecompressPointer r2
    //     0xd37158: add             x2, x2, HEAP, lsl #32
    // 0xd3715c: stur            x2, [fp, #-0x30]
    // 0xd37160: LoadField: r7 = r0->field_1f
    //     0xd37160: ldur            w7, [x0, #0x1f]
    // 0xd37164: DecompressPointer r7
    //     0xd37164: add             x7, x7, HEAP, lsl #32
    // 0xd37168: stur            x7, [fp, #-0x28]
    // 0xd3716c: LoadField: r8 = r0->field_27
    //     0xd3716c: ldur            w8, [x0, #0x27]
    // 0xd37170: DecompressPointer r8
    //     0xd37170: add             x8, x8, HEAP, lsl #32
    // 0xd37174: stur            x8, [fp, #-0x20]
    // 0xd37178: LoadField: r9 = r0->field_2b
    //     0xd37178: ldur            w9, [x0, #0x2b]
    // 0xd3717c: DecompressPointer r9
    //     0xd3717c: add             x9, x9, HEAP, lsl #32
    // 0xd37180: stur            x9, [fp, #-0x18]
    // 0xd37184: LoadField: r10 = r0->field_13
    //     0xd37184: ldur            w10, [x0, #0x13]
    // 0xd37188: DecompressPointer r10
    //     0xd37188: add             x10, x10, HEAP, lsl #32
    // 0xd3718c: stur            x10, [fp, #-0x10]
    // 0xd37190: r0 = _ScaffoldLayout()
    //     0xd37190: bl              #0xd373b8  ; Allocate_ScaffoldLayoutStub -> _ScaffoldLayout (size=0x44)
    // 0xd37194: stur            x0, [fp, #-0x60]
    // 0xd37198: ldur            x16, [fp, #-0x18]
    // 0xd3719c: ldur            lr, [fp, #-0x40]
    // 0xd371a0: stp             lr, x16, [SP, #0x10]
    // 0xd371a4: ldur            x16, [fp, #-0x28]
    // 0xd371a8: ldur            lr, [fp, #-0x10]
    // 0xd371ac: stp             lr, x16, [SP]
    // 0xd371b0: mov             x1, x0
    // 0xd371b4: ldur            x2, [fp, #-0x30]
    // 0xd371b8: ldur            x3, [fp, #-0x50]
    // 0xd371bc: ldur            x5, [fp, #-0x48]
    // 0xd371c0: ldur            x6, [fp, #-0x38]
    // 0xd371c4: ldur            x7, [fp, #-0x20]
    // 0xd371c8: r0 = _ScaffoldLayout()
    //     0xd371c8: bl              #0xd3725c  ; [package:flutter/src/material/scaffold.dart] _ScaffoldLayout::_ScaffoldLayout
    // 0xd371cc: ldur            x0, [fp, #-8]
    // 0xd371d0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd371d0: ldur            w1, [x0, #0x17]
    // 0xd371d4: DecompressPointer r1
    //     0xd371d4: add             x1, x1, HEAP, lsl #32
    // 0xd371d8: stur            x1, [fp, #-0x10]
    // 0xd371dc: r0 = CustomMultiChildLayout()
    //     0xd371dc: bl              #0xd37250  ; AllocateCustomMultiChildLayoutStub -> CustomMultiChildLayout (size=0x14)
    // 0xd371e0: mov             x1, x0
    // 0xd371e4: ldur            x0, [fp, #-0x60]
    // 0xd371e8: stur            x1, [fp, #-8]
    // 0xd371ec: StoreField: r1->field_f = r0
    //     0xd371ec: stur            w0, [x1, #0xf]
    // 0xd371f0: ldur            x0, [fp, #-0x10]
    // 0xd371f4: StoreField: r1->field_b = r0
    //     0xd371f4: stur            w0, [x1, #0xb]
    // 0xd371f8: r0 = Actions()
    //     0xd371f8: bl              #0xd1c8a8  ; AllocateActionsStub -> Actions (size=0x18)
    // 0xd371fc: ldur            x1, [fp, #-0x58]
    // 0xd37200: StoreField: r0->field_f = r1
    //     0xd37200: stur            w1, [x0, #0xf]
    // 0xd37204: ldur            x1, [fp, #-8]
    // 0xd37208: StoreField: r0->field_13 = r1
    //     0xd37208: stur            w1, [x0, #0x13]
    // 0xd3720c: LeaveFrame
    //     0xd3720c: mov             SP, fp
    //     0xd37210: ldp             fp, lr, [SP], #0x10
    // 0xd37214: ret
    //     0xd37214: ret             
    // 0xd37218: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd37218: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd3721c: b               #0xd36fcc
    // 0xd37220: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd37220: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd37224: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd37224: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd37228: r9 = _floatingActionButtonMoveController
    //     0xd37228: add             x9, PP, #0x84, lsl #12  ; [pp+0x84b50] Field <ScaffoldState._floatingActionButtonMoveController@89420462>: late (offset: 0x64)
    //     0xd3722c: ldr             x9, [x9, #0xb50]
    // 0xd37230: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd37230: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd37234: r9 = _floatingActionButtonAnimator
    //     0xd37234: add             x9, PP, #0x84, lsl #12  ; [pp+0x84b58] Field <ScaffoldState._floatingActionButtonAnimator@89420462>: late (offset: 0x68)
    //     0xd37238: ldr             x9, [x9, #0xb58]
    // 0xd3723c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd3723c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd37240: r9 = _geometryNotifier
    //     0xd37240: add             x9, PP, #0x84, lsl #12  ; [pp+0x84b60] Field <ScaffoldState._geometryNotifier@89420462>: late (offset: 0x78)
    //     0xd37244: ldr             x9, [x9, #0xb60]
    // 0xd37248: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd37248: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd3724c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd3724c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ openDrawer(/* No info */) {
    // ** addr: 0xd564d4, size: 0xec
    // 0xd564d4: EnterFrame
    //     0xd564d4: stp             fp, lr, [SP, #-0x10]!
    //     0xd564d8: mov             fp, SP
    // 0xd564dc: AllocStack(0x18)
    //     0xd564dc: sub             SP, SP, #0x18
    // 0xd564e0: SetupParameters(ScaffoldState this /* r1 => r0, fp-0x10 */)
    //     0xd564e0: mov             x0, x1
    //     0xd564e4: stur            x1, [fp, #-0x10]
    // 0xd564e8: CheckStackOverflow
    //     0xd564e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd564ec: cmp             SP, x16
    //     0xd564f0: b.ls            #0xd565b4
    // 0xd564f4: LoadField: r2 = r0->field_2f
    //     0xd564f4: ldur            w2, [x0, #0x2f]
    // 0xd564f8: DecompressPointer r2
    //     0xd564f8: add             x2, x2, HEAP, lsl #32
    // 0xd564fc: mov             x1, x2
    // 0xd56500: stur            x2, [fp, #-8]
    // 0xd56504: r0 = currentState()
    //     0xd56504: bl              #0x8591f8  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0xd56508: cmp             w0, NULL
    // 0xd5650c: b.eq            #0xd56584
    // 0xd56510: ldur            x3, [fp, #-0x10]
    // 0xd56514: LoadField: r0 = r3->field_43
    //     0xd56514: ldur            w0, [x3, #0x43]
    // 0xd56518: DecompressPointer r0
    //     0xd56518: add             x0, x0, HEAP, lsl #32
    // 0xd5651c: LoadField: r4 = r0->field_33
    //     0xd5651c: ldur            w4, [x0, #0x33]
    // 0xd56520: DecompressPointer r4
    //     0xd56520: add             x4, x4, HEAP, lsl #32
    // 0xd56524: stur            x4, [fp, #-0x18]
    // 0xd56528: cmp             w4, NULL
    // 0xd5652c: b.ne            #0xd56564
    // 0xd56530: LoadField: r2 = r0->field_23
    //     0xd56530: ldur            w2, [x0, #0x23]
    // 0xd56534: DecompressPointer r2
    //     0xd56534: add             x2, x2, HEAP, lsl #32
    // 0xd56538: mov             x0, x4
    // 0xd5653c: r1 = Null
    //     0xd5653c: mov             x1, NULL
    // 0xd56540: cmp             w2, NULL
    // 0xd56544: b.eq            #0xd56564
    // 0xd56548: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xd56548: ldur            w4, [x2, #0x17]
    // 0xd5654c: DecompressPointer r4
    //     0xd5654c: add             x4, x4, HEAP, lsl #32
    // 0xd56550: r8 = X0
    //     0xd56550: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xd56554: LoadField: r9 = r4->field_7
    //     0xd56554: ldur            x9, [x4, #7]
    // 0xd56558: r3 = Null
    //     0xd56558: add             x3, PP, #0x83, lsl #12  ; [pp+0x837b0] Null
    //     0xd5655c: ldr             x3, [x3, #0x7b0]
    // 0xd56560: blr             x9
    // 0xd56564: ldur            x0, [fp, #-0x18]
    // 0xd56568: tbnz            w0, #4, #0xd56584
    // 0xd5656c: ldur            x1, [fp, #-8]
    // 0xd56570: r0 = currentState()
    //     0xd56570: bl              #0x8591f8  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0xd56574: cmp             w0, NULL
    // 0xd56578: b.eq            #0xd565bc
    // 0xd5657c: mov             x1, x0
    // 0xd56580: r0 = close()
    //     0xd56580: bl              #0xb34b88  ; [package:flutter/src/material/drawer.dart] DrawerControllerState::close
    // 0xd56584: ldur            x0, [fp, #-0x10]
    // 0xd56588: LoadField: r1 = r0->field_2b
    //     0xd56588: ldur            w1, [x0, #0x2b]
    // 0xd5658c: DecompressPointer r1
    //     0xd5658c: add             x1, x1, HEAP, lsl #32
    // 0xd56590: r0 = currentState()
    //     0xd56590: bl              #0x8591f8  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0xd56594: cmp             w0, NULL
    // 0xd56598: b.eq            #0xd565a4
    // 0xd5659c: mov             x1, x0
    // 0xd565a0: r0 = open()
    //     0xd565a0: bl              #0xd1aae4  ; [package:flutter/src/material/drawer.dart] DrawerControllerState::open
    // 0xd565a4: r0 = Null
    //     0xd565a4: mov             x0, NULL
    // 0xd565a8: LeaveFrame
    //     0xd565a8: mov             SP, fp
    //     0xd565ac: ldp             fp, lr, [SP], #0x10
    // 0xd565b0: ret
    //     0xd565b0: ret             
    // 0xd565b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd565b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd565b8: b               #0xd564f4
    // 0xd565bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd565bc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ hasFloatingActionButton(/* No info */) {
    // ** addr: 0xdeae10, size: 0x38
    // 0xdeae10: LoadField: r2 = r1->field_b
    //     0xdeae10: ldur            w2, [x1, #0xb]
    // 0xdeae14: DecompressPointer r2
    //     0xdeae14: add             x2, x2, HEAP, lsl #32
    // 0xdeae18: cmp             w2, NULL
    // 0xdeae1c: b.eq            #0xdeae3c
    // 0xdeae20: LoadField: r1 = r2->field_1f
    //     0xdeae20: ldur            w1, [x2, #0x1f]
    // 0xdeae24: DecompressPointer r1
    //     0xdeae24: add             x1, x1, HEAP, lsl #32
    // 0xdeae28: cmp             w1, NULL
    // 0xdeae2c: r16 = true
    //     0xdeae2c: add             x16, NULL, #0x20  ; true
    // 0xdeae30: r17 = false
    //     0xdeae30: add             x17, NULL, #0x30  ; false
    // 0xdeae34: csel            x0, x16, x17, ne
    // 0xdeae38: ret
    //     0xdeae38: ret             
    // 0xdeae3c: EnterFrame
    //     0xdeae3c: stp             fp, lr, [SP, #-0x10]!
    //     0xdeae40: mov             fp, SP
    // 0xdeae44: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdeae44: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ showBodyScrim(/* No info */) {
    // ** addr: 0xdfc020, size: 0x120
    // 0xdfc020: EnterFrame
    //     0xdfc020: stp             fp, lr, [SP, #-0x10]!
    //     0xdfc024: mov             fp, SP
    // 0xdfc028: AllocStack(0x18)
    //     0xdfc028: sub             SP, SP, #0x18
    // 0xdfc02c: SetupParameters(ScaffoldState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* d0 => d0, fp-0x18 */)
    //     0xdfc02c: stur            x1, [fp, #-8]
    //     0xdfc030: stur            x2, [fp, #-0x10]
    //     0xdfc034: stur            d0, [fp, #-0x18]
    // 0xdfc038: CheckStackOverflow
    //     0xdfc038: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdfc03c: cmp             SP, x16
    //     0xdfc040: b.ls            #0xdfc108
    // 0xdfc044: r1 = 2
    //     0xdfc044: mov             x1, #2
    // 0xdfc048: r0 = AllocateContext()
    //     0xdfc048: bl              #0x13de838  ; AllocateContextStub
    // 0xdfc04c: mov             x1, x0
    // 0xdfc050: ldur            x0, [fp, #-8]
    // 0xdfc054: StoreField: r1->field_f = r0
    //     0xdfc054: stur            w0, [x1, #0xf]
    // 0xdfc058: ldur            x2, [fp, #-0x10]
    // 0xdfc05c: StoreField: r1->field_13 = r2
    //     0xdfc05c: stur            w2, [x1, #0x13]
    // 0xdfc060: LoadField: r3 = r0->field_7f
    //     0xdfc060: ldur            w3, [x0, #0x7f]
    // 0xdfc064: DecompressPointer r3
    //     0xdfc064: add             x3, x3, HEAP, lsl #32
    // 0xdfc068: cmp             w3, w2
    // 0xdfc06c: b.eq            #0xdfc08c
    // 0xdfc070: mov             x2, x1
    // 0xdfc074: r1 = Function '<anonymous closure>':.
    //     0xdfc074: add             x1, PP, #0x84, lsl #12  ; [pp+0x84c30] AnonymousClosure: (0xdfc140), in [package:flutter/src/material/scaffold.dart] ScaffoldState::showBodyScrim (0xdfc020)
    //     0xdfc078: ldr             x1, [x1, #0xc30]
    // 0xdfc07c: r0 = AllocateClosure()
    //     0xdfc07c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdfc080: ldur            x1, [fp, #-8]
    // 0xdfc084: mov             x2, x0
    // 0xdfc088: r0 = setState()
    //     0xdfc088: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xdfc08c: ldur            x0, [fp, #-8]
    // 0xdfc090: ldur            d0, [fp, #-0x18]
    // 0xdfc094: LoadField: r1 = r0->field_7b
    //     0xdfc094: ldur            w1, [x0, #0x7b]
    // 0xdfc098: DecompressPointer r1
    //     0xdfc098: add             x1, x1, HEAP, lsl #32
    // 0xdfc09c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfc0a0: cmp             w1, w16
    // 0xdfc0a4: b.eq            #0xdfc110
    // 0xdfc0a8: LoadField: r0 = r1->field_37
    //     0xdfc0a8: ldur            w0, [x1, #0x37]
    // 0xdfc0ac: DecompressPointer r0
    //     0xdfc0ac: add             x0, x0, HEAP, lsl #32
    // 0xdfc0b0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xdfc0b4: cmp             w0, w16
    // 0xdfc0b8: b.eq            #0xdfc11c
    // 0xdfc0bc: LoadField: d1 = r0->field_7
    //     0xdfc0bc: ldur            d1, [x0, #7]
    // 0xdfc0c0: fcmp            d1, d0
    // 0xdfc0c4: b.eq            #0xdfc0f8
    // 0xdfc0c8: r2 = inline_Allocate_Double()
    //     0xdfc0c8: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0xdfc0cc: add             x2, x2, #0x10
    //     0xdfc0d0: cmp             x0, x2
    //     0xdfc0d4: b.ls            #0xdfc124
    //     0xdfc0d8: str             x2, [THR, #0x60]  ; THR::top
    //     0xdfc0dc: sub             x2, x2, #0xf
    //     0xdfc0e0: mov             x0, #0xe19c
    //     0xdfc0e4: movk            x0, #3, lsl #16
    //     0xdfc0e8: stur            x0, [x2, #-1]
    // 0xdfc0ec: dmb             ishst
    // 0xdfc0f0: StoreField: r2->field_7 = d0
    //     0xdfc0f0: stur            d0, [x2, #7]
    // 0xdfc0f4: r0 = value=()
    //     0xdfc0f4: bl              #0x829534  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0xdfc0f8: r0 = Null
    //     0xdfc0f8: mov             x0, NULL
    // 0xdfc0fc: LeaveFrame
    //     0xdfc0fc: mov             SP, fp
    //     0xdfc100: ldp             fp, lr, [SP], #0x10
    // 0xdfc104: ret
    //     0xdfc104: ret             
    // 0xdfc108: r0 = StackOverflowSharedWithFPURegs()
    //     0xdfc108: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xdfc10c: b               #0xdfc044
    // 0xdfc110: r9 = _bottomSheetScrimAnimationController
    //     0xdfc110: add             x9, PP, #0x84, lsl #12  ; [pp+0x84b48] Field <ScaffoldState._bottomSheetScrimAnimationController@89420462>: late (offset: 0x7c)
    //     0xdfc114: ldr             x9, [x9, #0xb48]
    // 0xdfc118: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xdfc118: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xdfc11c: r9 = _value
    //     0xdfc11c: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0xdfc120: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xdfc120: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xdfc124: SaveReg d0
    //     0xdfc124: str             q0, [SP, #-0x10]!
    // 0xdfc128: SaveReg r1
    //     0xdfc128: str             x1, [SP, #-8]!
    // 0xdfc12c: r0 = AllocateDouble()
    //     0xdfc12c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xdfc130: mov             x2, x0
    // 0xdfc134: RestoreReg r1
    //     0xdfc134: ldr             x1, [SP], #8
    // 0xdfc138: RestoreReg d0
    //     0xdfc138: ldr             q0, [SP], #0x10
    // 0xdfc13c: b               #0xdfc0f0
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xdfc140, size: 0x28
    // 0xdfc140: ldr             x1, [SP]
    // 0xdfc144: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xdfc144: ldur            w2, [x1, #0x17]
    // 0xdfc148: DecompressPointer r2
    //     0xdfc148: add             x2, x2, HEAP, lsl #32
    // 0xdfc14c: LoadField: r1 = r2->field_f
    //     0xdfc14c: ldur            w1, [x2, #0xf]
    // 0xdfc150: DecompressPointer r1
    //     0xdfc150: add             x1, x1, HEAP, lsl #32
    // 0xdfc154: LoadField: r3 = r2->field_13
    //     0xdfc154: ldur            w3, [x2, #0x13]
    // 0xdfc158: DecompressPointer r3
    //     0xdfc158: add             x3, x3, HEAP, lsl #32
    // 0xdfc15c: StoreField: r1->field_7f = r3
    //     0xdfc15c: stur            w3, [x1, #0x7f]
    // 0xdfc160: r0 = Null
    //     0xdfc160: mov             x0, NULL
    // 0xdfc164: ret
    //     0xdfc164: ret             
  }
  _ _updateMaterialBanner(/* No info */) {
    // ** addr: 0xe61df0, size: 0xfc
    // 0xe61df0: EnterFrame
    //     0xe61df0: stp             fp, lr, [SP, #-0x10]!
    //     0xe61df4: mov             fp, SP
    // 0xe61df8: AllocStack(0x20)
    //     0xe61df8: sub             SP, SP, #0x20
    // 0xe61dfc: SetupParameters(ScaffoldState this /* r1 => r1, fp-0x8 */)
    //     0xe61dfc: stur            x1, [fp, #-8]
    // 0xe61e00: CheckStackOverflow
    //     0xe61e00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe61e04: cmp             SP, x16
    //     0xe61e08: b.ls            #0xe61ee0
    // 0xe61e0c: r1 = 2
    //     0xe61e0c: mov             x1, #2
    // 0xe61e10: r0 = AllocateContext()
    //     0xe61e10: bl              #0x13de838  ; AllocateContextStub
    // 0xe61e14: mov             x2, x0
    // 0xe61e18: ldur            x0, [fp, #-8]
    // 0xe61e1c: stur            x2, [fp, #-0x10]
    // 0xe61e20: StoreField: r2->field_f = r0
    //     0xe61e20: stur            w0, [x2, #0xf]
    // 0xe61e24: LoadField: r1 = r0->field_47
    //     0xe61e24: ldur            w1, [x0, #0x47]
    // 0xe61e28: DecompressPointer r1
    //     0xe61e28: add             x1, x1, HEAP, lsl #32
    // 0xe61e2c: cmp             w1, NULL
    // 0xe61e30: b.eq            #0xe61ee8
    // 0xe61e34: LoadField: r3 = r1->field_1f
    //     0xe61e34: ldur            w3, [x1, #0x1f]
    // 0xe61e38: DecompressPointer r3
    //     0xe61e38: add             x3, x3, HEAP, lsl #32
    // 0xe61e3c: LoadField: r1 = r3->field_f
    //     0xe61e3c: ldur            x1, [x3, #0xf]
    // 0xe61e40: ArrayLoad: r4 = r3[0]  ; List_8
    //     0xe61e40: ldur            x4, [x3, #0x17]
    // 0xe61e44: cmp             x1, x4
    // 0xe61e48: b.eq            #0xe61e5c
    // 0xe61e4c: mov             x1, x3
    // 0xe61e50: r0 = first()
    //     0xe61e50: bl              #0xb067e0  ; [dart:collection] ListQueue::first
    // 0xe61e54: mov             x3, x0
    // 0xe61e58: b               #0xe61e60
    // 0xe61e5c: r3 = Null
    //     0xe61e5c: mov             x3, NULL
    // 0xe61e60: ldur            x1, [fp, #-8]
    // 0xe61e64: ldur            x2, [fp, #-0x10]
    // 0xe61e68: mov             x0, x3
    // 0xe61e6c: StoreField: r2->field_13 = r0
    //     0xe61e6c: stur            w0, [x2, #0x13]
    //     0xe61e70: tbz             w0, #0, #0xe61e8c
    //     0xe61e74: ldurb           w16, [x2, #-1]
    //     0xe61e78: ldurb           w17, [x0, #-1]
    //     0xe61e7c: and             x16, x17, x16, lsr #2
    //     0xe61e80: tst             x16, HEAP, lsr #32
    //     0xe61e84: b.eq            #0xe61e8c
    //     0xe61e88: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xe61e8c: LoadField: r0 = r1->field_4f
    //     0xe61e8c: ldur            w0, [x1, #0x4f]
    // 0xe61e90: DecompressPointer r0
    //     0xe61e90: add             x0, x0, HEAP, lsl #32
    // 0xe61e94: r4 = LoadClassIdInstr(r0)
    //     0xe61e94: ldur            x4, [x0, #-1]
    //     0xe61e98: ubfx            x4, x4, #0xc, #0x14
    // 0xe61e9c: stp             x3, x0, [SP]
    // 0xe61ea0: mov             x0, x4
    // 0xe61ea4: mov             lr, x0
    // 0xe61ea8: ldr             lr, [x21, lr, lsl #3]
    // 0xe61eac: blr             lr
    // 0xe61eb0: tbz             w0, #4, #0xe61ed0
    // 0xe61eb4: ldur            x2, [fp, #-0x10]
    // 0xe61eb8: r1 = Function '<anonymous closure>':.
    //     0xe61eb8: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e850] AnonymousClosure: (0xe61eec), in [package:flutter/src/material/scaffold.dart] ScaffoldState::_updateMaterialBanner (0xe61df0)
    //     0xe61ebc: ldr             x1, [x1, #0x850]
    // 0xe61ec0: r0 = AllocateClosure()
    //     0xe61ec0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xe61ec4: ldur            x1, [fp, #-8]
    // 0xe61ec8: mov             x2, x0
    // 0xe61ecc: r0 = setState()
    //     0xe61ecc: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xe61ed0: r0 = Null
    //     0xe61ed0: mov             x0, NULL
    // 0xe61ed4: LeaveFrame
    //     0xe61ed4: mov             SP, fp
    //     0xe61ed8: ldp             fp, lr, [SP], #0x10
    // 0xe61edc: ret
    //     0xe61edc: ret             
    // 0xe61ee0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe61ee0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe61ee4: b               #0xe61e0c
    // 0xe61ee8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe61ee8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xe61eec, size: 0x48
    // 0xe61eec: ldr             x1, [SP]
    // 0xe61ef0: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xe61ef0: ldur            w2, [x1, #0x17]
    // 0xe61ef4: DecompressPointer r2
    //     0xe61ef4: add             x2, x2, HEAP, lsl #32
    // 0xe61ef8: LoadField: r1 = r2->field_f
    //     0xe61ef8: ldur            w1, [x2, #0xf]
    // 0xe61efc: DecompressPointer r1
    //     0xe61efc: add             x1, x1, HEAP, lsl #32
    // 0xe61f00: LoadField: r0 = r2->field_13
    //     0xe61f00: ldur            w0, [x2, #0x13]
    // 0xe61f04: DecompressPointer r0
    //     0xe61f04: add             x0, x0, HEAP, lsl #32
    // 0xe61f08: StoreField: r1->field_4f = r0
    //     0xe61f08: stur            w0, [x1, #0x4f]
    //     0xe61f0c: ldurb           w16, [x1, #-1]
    //     0xe61f10: ldurb           w17, [x0, #-1]
    //     0xe61f14: and             x16, x17, x16, lsr #2
    //     0xe61f18: tst             x16, HEAP, lsr #32
    //     0xe61f1c: b.eq            #0xe61f2c
    //     0xe61f20: str             lr, [SP, #-8]!
    //     0xe61f24: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    //     0xe61f28: ldr             lr, [SP], #8
    // 0xe61f2c: r0 = Null
    //     0xe61f2c: mov             x0, NULL
    // 0xe61f30: ret
    //     0xe61f30: ret             
  }
  _ _updateSnackBar(/* No info */) {
    // ** addr: 0xe61f34, size: 0xfc
    // 0xe61f34: EnterFrame
    //     0xe61f34: stp             fp, lr, [SP, #-0x10]!
    //     0xe61f38: mov             fp, SP
    // 0xe61f3c: AllocStack(0x20)
    //     0xe61f3c: sub             SP, SP, #0x20
    // 0xe61f40: SetupParameters(ScaffoldState this /* r1 => r1, fp-0x8 */)
    //     0xe61f40: stur            x1, [fp, #-8]
    // 0xe61f44: CheckStackOverflow
    //     0xe61f44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe61f48: cmp             SP, x16
    //     0xe61f4c: b.ls            #0xe62024
    // 0xe61f50: r1 = 2
    //     0xe61f50: mov             x1, #2
    // 0xe61f54: r0 = AllocateContext()
    //     0xe61f54: bl              #0x13de838  ; AllocateContextStub
    // 0xe61f58: mov             x2, x0
    // 0xe61f5c: ldur            x0, [fp, #-8]
    // 0xe61f60: stur            x2, [fp, #-0x10]
    // 0xe61f64: StoreField: r2->field_f = r0
    //     0xe61f64: stur            w0, [x2, #0xf]
    // 0xe61f68: LoadField: r1 = r0->field_47
    //     0xe61f68: ldur            w1, [x0, #0x47]
    // 0xe61f6c: DecompressPointer r1
    //     0xe61f6c: add             x1, x1, HEAP, lsl #32
    // 0xe61f70: cmp             w1, NULL
    // 0xe61f74: b.eq            #0xe6202c
    // 0xe61f78: LoadField: r3 = r1->field_27
    //     0xe61f78: ldur            w3, [x1, #0x27]
    // 0xe61f7c: DecompressPointer r3
    //     0xe61f7c: add             x3, x3, HEAP, lsl #32
    // 0xe61f80: LoadField: r1 = r3->field_f
    //     0xe61f80: ldur            x1, [x3, #0xf]
    // 0xe61f84: ArrayLoad: r4 = r3[0]  ; List_8
    //     0xe61f84: ldur            x4, [x3, #0x17]
    // 0xe61f88: cmp             x1, x4
    // 0xe61f8c: b.eq            #0xe61fa0
    // 0xe61f90: mov             x1, x3
    // 0xe61f94: r0 = first()
    //     0xe61f94: bl              #0xb067e0  ; [dart:collection] ListQueue::first
    // 0xe61f98: mov             x3, x0
    // 0xe61f9c: b               #0xe61fa4
    // 0xe61fa0: r3 = Null
    //     0xe61fa0: mov             x3, NULL
    // 0xe61fa4: ldur            x1, [fp, #-8]
    // 0xe61fa8: ldur            x2, [fp, #-0x10]
    // 0xe61fac: mov             x0, x3
    // 0xe61fb0: StoreField: r2->field_13 = r0
    //     0xe61fb0: stur            w0, [x2, #0x13]
    //     0xe61fb4: tbz             w0, #0, #0xe61fd0
    //     0xe61fb8: ldurb           w16, [x2, #-1]
    //     0xe61fbc: ldurb           w17, [x0, #-1]
    //     0xe61fc0: and             x16, x17, x16, lsr #2
    //     0xe61fc4: tst             x16, HEAP, lsr #32
    //     0xe61fc8: b.eq            #0xe61fd0
    //     0xe61fcc: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xe61fd0: LoadField: r0 = r1->field_4b
    //     0xe61fd0: ldur            w0, [x1, #0x4b]
    // 0xe61fd4: DecompressPointer r0
    //     0xe61fd4: add             x0, x0, HEAP, lsl #32
    // 0xe61fd8: r4 = LoadClassIdInstr(r0)
    //     0xe61fd8: ldur            x4, [x0, #-1]
    //     0xe61fdc: ubfx            x4, x4, #0xc, #0x14
    // 0xe61fe0: stp             x3, x0, [SP]
    // 0xe61fe4: mov             x0, x4
    // 0xe61fe8: mov             lr, x0
    // 0xe61fec: ldr             lr, [x21, lr, lsl #3]
    // 0xe61ff0: blr             lr
    // 0xe61ff4: tbz             w0, #4, #0xe62014
    // 0xe61ff8: ldur            x2, [fp, #-0x10]
    // 0xe61ffc: r1 = Function '<anonymous closure>':.
    //     0xe61ffc: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e858] AnonymousClosure: (0xe62030), in [package:flutter/src/material/scaffold.dart] ScaffoldState::_updateSnackBar (0xe61f34)
    //     0xe62000: ldr             x1, [x1, #0x858]
    // 0xe62004: r0 = AllocateClosure()
    //     0xe62004: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xe62008: ldur            x1, [fp, #-8]
    // 0xe6200c: mov             x2, x0
    // 0xe62010: r0 = setState()
    //     0xe62010: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xe62014: r0 = Null
    //     0xe62014: mov             x0, NULL
    // 0xe62018: LeaveFrame
    //     0xe62018: mov             SP, fp
    //     0xe6201c: ldp             fp, lr, [SP], #0x10
    // 0xe62020: ret
    //     0xe62020: ret             
    // 0xe62024: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe62024: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe62028: b               #0xe61f50
    // 0xe6202c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe6202c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xe62030, size: 0x48
    // 0xe62030: ldr             x1, [SP]
    // 0xe62034: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xe62034: ldur            w2, [x1, #0x17]
    // 0xe62038: DecompressPointer r2
    //     0xe62038: add             x2, x2, HEAP, lsl #32
    // 0xe6203c: LoadField: r1 = r2->field_f
    //     0xe6203c: ldur            w1, [x2, #0xf]
    // 0xe62040: DecompressPointer r1
    //     0xe62040: add             x1, x1, HEAP, lsl #32
    // 0xe62044: LoadField: r0 = r2->field_13
    //     0xe62044: ldur            w0, [x2, #0x13]
    // 0xe62048: DecompressPointer r0
    //     0xe62048: add             x0, x0, HEAP, lsl #32
    // 0xe6204c: StoreField: r1->field_4b = r0
    //     0xe6204c: stur            w0, [x1, #0x4b]
    //     0xe62050: ldurb           w16, [x1, #-1]
    //     0xe62054: ldurb           w17, [x0, #-1]
    //     0xe62058: and             x16, x17, x16, lsr #2
    //     0xe6205c: tst             x16, HEAP, lsr #32
    //     0xe62060: b.eq            #0xe62070
    //     0xe62064: str             lr, [SP, #-8]!
    //     0xe62068: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    //     0xe6206c: ldr             lr, [SP], #8
    // 0xe62070: r0 = Null
    //     0xe62070: mov             x0, NULL
    // 0xe62074: ret
    //     0xe62074: ret             
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0xeed830, size: 0xcc
    // 0xeed830: EnterFrame
    //     0xeed830: stp             fp, lr, [SP, #-0x10]!
    //     0xeed834: mov             fp, SP
    // 0xeed838: AllocStack(0x10)
    //     0xeed838: sub             SP, SP, #0x10
    // 0xeed83c: SetupParameters(ScaffoldState this /* r1 => r2, fp-0x8 */)
    //     0xeed83c: mov             x2, x1
    //     0xeed840: stur            x1, [fp, #-8]
    // 0xeed844: CheckStackOverflow
    //     0xeed844: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeed848: cmp             SP, x16
    //     0xeed84c: b.ls            #0xeed8f0
    // 0xeed850: LoadField: r1 = r2->field_f
    //     0xeed850: ldur            w1, [x2, #0xf]
    // 0xeed854: DecompressPointer r1
    //     0xeed854: add             x1, x1, HEAP, lsl #32
    // 0xeed858: cmp             w1, NULL
    // 0xeed85c: b.eq            #0xeed8f8
    // 0xeed860: r0 = maybeOf()
    //     0xeed860: bl              #0xeeec70  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessenger::maybeOf
    // 0xeed864: mov             x3, x0
    // 0xeed868: ldur            x0, [fp, #-8]
    // 0xeed86c: stur            x3, [fp, #-0x10]
    // 0xeed870: LoadField: r1 = r0->field_47
    //     0xeed870: ldur            w1, [x0, #0x47]
    // 0xeed874: DecompressPointer r1
    //     0xeed874: add             x1, x1, HEAP, lsl #32
    // 0xeed878: cmp             w1, NULL
    // 0xeed87c: b.eq            #0xeed898
    // 0xeed880: cmp             w3, NULL
    // 0xeed884: b.eq            #0xeed890
    // 0xeed888: cmp             w1, w3
    // 0xeed88c: b.eq            #0xeed898
    // 0xeed890: mov             x2, x0
    // 0xeed894: r0 = _unregister()
    //     0xeed894: bl              #0xeeec34  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::_unregister
    // 0xeed898: ldur            x3, [fp, #-8]
    // 0xeed89c: ldur            x1, [fp, #-0x10]
    // 0xeed8a0: mov             x0, x1
    // 0xeed8a4: StoreField: r3->field_47 = r0
    //     0xeed8a4: stur            w0, [x3, #0x47]
    //     0xeed8a8: ldurb           w16, [x3, #-1]
    //     0xeed8ac: ldurb           w17, [x0, #-1]
    //     0xeed8b0: and             x16, x17, x16, lsr #2
    //     0xeed8b4: tst             x16, HEAP, lsr #32
    //     0xeed8b8: b.eq            #0xeed8c0
    //     0xeed8bc: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xeed8c0: cmp             w1, NULL
    // 0xeed8c4: b.eq            #0xeed8d0
    // 0xeed8c8: mov             x2, x3
    // 0xeed8cc: r0 = _register()
    //     0xeed8cc: bl              #0xeeeb8c  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::_register
    // 0xeed8d0: ldur            x1, [fp, #-8]
    // 0xeed8d4: r0 = _maybeBuildPersistentBottomSheet()
    //     0xeed8d4: bl              #0xeeda74  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::_maybeBuildPersistentBottomSheet
    // 0xeed8d8: ldur            x1, [fp, #-8]
    // 0xeed8dc: r0 = didChangeDependencies()
    //     0xeed8dc: bl              #0xeed8fc  ; [dart:mixin_deduplication] _MixinApplication101&State&TickerProviderStateMixin&RestorationMixin::didChangeDependencies
    // 0xeed8e0: r0 = Null
    //     0xeed8e0: mov             x0, NULL
    // 0xeed8e4: LeaveFrame
    //     0xeed8e4: mov             SP, fp
    //     0xeed8e8: ldp             fp, lr, [SP], #0x10
    // 0xeed8ec: ret
    //     0xeed8ec: ret             
    // 0xeed8f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeed8f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeed8f4: b               #0xeed850
    // 0xeed8f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xeed8f8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _maybeBuildPersistentBottomSheet(/* No info */) {
    // ** addr: 0xeeda74, size: 0x268
    // 0xeeda74: EnterFrame
    //     0xeeda74: stp             fp, lr, [SP, #-0x10]!
    //     0xeeda78: mov             fp, SP
    // 0xeeda7c: AllocStack(0x38)
    //     0xeeda7c: sub             SP, SP, #0x38
    // 0xeeda80: SetupParameters(ScaffoldState this /* r1 => r1, fp-0x8 */)
    //     0xeeda80: stur            x1, [fp, #-8]
    // 0xeeda84: CheckStackOverflow
    //     0xeeda84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeeda88: cmp             SP, x16
    //     0xeeda8c: b.ls            #0xeedc9c
    // 0xeeda90: r1 = 2
    //     0xeeda90: mov             x1, #2
    // 0xeeda94: r0 = AllocateContext()
    //     0xeeda94: bl              #0x13de838  ; AllocateContextStub
    // 0xeeda98: mov             x2, x0
    // 0xeeda9c: ldur            x0, [fp, #-8]
    // 0xeedaa0: stur            x2, [fp, #-0x10]
    // 0xeedaa4: StoreField: r2->field_f = r0
    //     0xeedaa4: stur            w0, [x2, #0xf]
    // 0xeedaa8: LoadField: r1 = r0->field_b
    //     0xeedaa8: ldur            w1, [x0, #0xb]
    // 0xeedaac: DecompressPointer r1
    //     0xeedaac: add             x1, x1, HEAP, lsl #32
    // 0xeedab0: cmp             w1, NULL
    // 0xeedab4: b.eq            #0xeedca4
    // 0xeedab8: LoadField: r3 = r1->field_53
    //     0xeedab8: ldur            w3, [x1, #0x53]
    // 0xeedabc: DecompressPointer r3
    //     0xeedabc: add             x3, x3, HEAP, lsl #32
    // 0xeedac0: cmp             w3, NULL
    // 0xeedac4: b.eq            #0xeedc8c
    // 0xeedac8: LoadField: r1 = r0->field_57
    //     0xeedac8: ldur            w1, [x0, #0x57]
    // 0xeedacc: DecompressPointer r1
    //     0xeedacc: add             x1, x1, HEAP, lsl #32
    // 0xeedad0: cmp             w1, NULL
    // 0xeedad4: b.ne            #0xeedc8c
    // 0xeedad8: mov             x1, x0
    // 0xeedadc: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xeedadc: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xeedae0: r0 = createAnimationController()
    //     0xeedae0: bl              #0xeee668  ; [package:flutter/src/material/bottom_sheet.dart] BottomSheet::createAnimationController
    // 0xeedae4: mov             x1, x0
    // 0xeedae8: r2 = 1.000000
    //     0xeedae8: ldr             x2, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xeedaec: stur            x0, [fp, #-0x18]
    // 0xeedaf0: r0 = value=()
    //     0xeedaf0: bl              #0x829534  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0xeedaf4: ldur            x2, [fp, #-0x10]
    // 0xeedaf8: r1 = Function 'persistentBottomSheetExtentChanged':.
    //     0xeedaf8: add             x1, PP, #0x84, lsl #12  ; [pp+0x84c08] AnonymousClosure: (0xeee870), in [package:flutter/src/material/scaffold.dart] ScaffoldState::_maybeBuildPersistentBottomSheet (0xeeda74)
    //     0xeedafc: ldr             x1, [x1, #0xc08]
    // 0xeedb00: r0 = AllocateClosure()
    //     0xeedb00: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xeedb04: ldur            x3, [fp, #-0x10]
    // 0xeedb08: StoreField: r3->field_13 = r0
    //     0xeedb08: stur            w0, [x3, #0x13]
    //     0xeedb0c: ldurb           w16, [x3, #-1]
    //     0xeedb10: ldurb           w17, [x0, #-1]
    //     0xeedb14: and             x16, x17, x16, lsr #2
    //     0xeedb18: tst             x16, HEAP, lsr #32
    //     0xeedb1c: b.eq            #0xeedb24
    //     0xeedb20: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xeedb24: ldur            x0, [fp, #-8]
    // 0xeedb28: LoadField: r4 = r0->field_53
    //     0xeedb28: ldur            w4, [x0, #0x53]
    // 0xeedb2c: DecompressPointer r4
    //     0xeedb2c: add             x4, x4, HEAP, lsl #32
    // 0xeedb30: stur            x4, [fp, #-0x28]
    // 0xeedb34: LoadField: r2 = r4->field_b
    //     0xeedb34: ldur            w2, [x4, #0xb]
    // 0xeedb38: r5 = LoadInt32Instr(r2)
    //     0xeedb38: sbfx            x5, x2, #1, #0x1f
    // 0xeedb3c: stur            x5, [fp, #-0x20]
    // 0xeedb40: cbz             w2, #0xeedc48
    // 0xeedb44: r1 = <_StandardBottomSheet>
    //     0xeedb44: add             x1, PP, #0x26, lsl #12  ; [pp+0x26c58] TypeArguments: <_StandardBottomSheet>
    //     0xeedb48: ldr             x1, [x1, #0xc58]
    // 0xeedb4c: r0 = AllocateArray()
    //     0xeedb4c: bl              #0x13df928  ; AllocateArrayStub
    // 0xeedb50: mov             x4, x0
    // 0xeedb54: ldur            x3, [fp, #-0x20]
    // 0xeedb58: stur            x4, [fp, #-0x38]
    // 0xeedb5c: cmp             x3, #0
    // 0xeedb60: b.le            #0xeedbcc
    // 0xeedb64: ldur            x0, [fp, #-0x28]
    // 0xeedb68: LoadField: r2 = r0->field_f
    //     0xeedb68: ldur            w2, [x0, #0xf]
    // 0xeedb6c: DecompressPointer r2
    //     0xeedb6c: add             x2, x2, HEAP, lsl #32
    // 0xeedb70: r5 = 0
    //     0xeedb70: mov             x5, #0
    // 0xeedb74: CheckStackOverflow
    //     0xeedb74: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeedb78: cmp             SP, x16
    //     0xeedb7c: b.ls            #0xeedca8
    // 0xeedb80: cmp             x5, x3
    // 0xeedb84: b.ge            #0xeedbcc
    // 0xeedb88: ArrayLoad: r0 = r2[r5]  ; Unknown_4
    //     0xeedb88: add             x16, x2, x5, lsl #2
    //     0xeedb8c: ldur            w0, [x16, #0xf]
    // 0xeedb90: DecompressPointer r0
    //     0xeedb90: add             x0, x0, HEAP, lsl #32
    // 0xeedb94: mov             x1, x4
    // 0xeedb98: ArrayStore: r1[r5] = r0  ; List_4
    //     0xeedb98: add             x25, x1, x5, lsl #2
    //     0xeedb9c: add             x25, x25, #0xf
    //     0xeedba0: str             w0, [x25]
    //     0xeedba4: tbz             w0, #0, #0xeedbc0
    //     0xeedba8: ldurb           w16, [x1, #-1]
    //     0xeedbac: ldurb           w17, [x0, #-1]
    //     0xeedbb0: and             x16, x17, x16, lsr #2
    //     0xeedbb4: tst             x16, HEAP, lsr #32
    //     0xeedbb8: b.eq            #0xeedbc0
    //     0xeedbbc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xeedbc0: add             x0, x5, #1
    // 0xeedbc4: mov             x5, x0
    // 0xeedbc8: b               #0xeedb74
    // 0xeedbcc: r0 = 0
    //     0xeedbcc: mov             x0, #0
    // 0xeedbd0: CheckStackOverflow
    //     0xeedbd0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeedbd4: cmp             SP, x16
    //     0xeedbd8: b.ls            #0xeedcb0
    // 0xeedbdc: cmp             x0, x3
    // 0xeedbe0: b.ge            #0xeedc48
    // 0xeedbe4: ArrayLoad: r1 = r4[r0]  ; Unknown_4
    //     0xeedbe4: add             x16, x4, x0, lsl #2
    //     0xeedbe8: ldur            w1, [x16, #0xf]
    // 0xeedbec: DecompressPointer r1
    //     0xeedbec: add             x1, x1, HEAP, lsl #32
    // 0xeedbf0: add             x5, x0, #1
    // 0xeedbf4: stur            x5, [fp, #-0x30]
    // 0xeedbf8: LoadField: r0 = r1->field_b
    //     0xeedbf8: ldur            w0, [x1, #0xb]
    // 0xeedbfc: DecompressPointer r0
    //     0xeedbfc: add             x0, x0, HEAP, lsl #32
    // 0xeedc00: LoadField: d0 = r0->field_13
    //     0xeedc00: ldur            d0, [x0, #0x13]
    // 0xeedc04: r2 = inline_Allocate_Double()
    //     0xeedc04: ldp             x2, x1, [THR, #0x60]  ; THR::top
    //     0xeedc08: add             x2, x2, #0x10
    //     0xeedc0c: cmp             x1, x2
    //     0xeedc10: b.ls            #0xeedcb8
    //     0xeedc14: str             x2, [THR, #0x60]  ; THR::top
    //     0xeedc18: sub             x2, x2, #0xf
    //     0xeedc1c: mov             x1, #0xe19c
    //     0xeedc20: movk            x1, #3, lsl #16
    //     0xeedc24: stur            x1, [x2, #-1]
    // 0xeedc28: dmb             ishst
    // 0xeedc2c: StoreField: r2->field_7 = d0
    //     0xeedc2c: stur            d0, [x2, #7]
    // 0xeedc30: mov             x1, x0
    // 0xeedc34: r0 = value=()
    //     0xeedc34: bl              #0x829534  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0xeedc38: ldur            x0, [fp, #-0x30]
    // 0xeedc3c: ldur            x4, [fp, #-0x38]
    // 0xeedc40: ldur            x3, [fp, #-0x20]
    // 0xeedc44: b               #0xeedbd0
    // 0xeedc48: ldur            x0, [fp, #-8]
    // 0xeedc4c: ldur            x2, [fp, #-0x10]
    // 0xeedc50: r1 = Function '<anonymous closure>':.
    //     0xeedc50: add             x1, PP, #0x84, lsl #12  ; [pp+0x84c10] AnonymousClosure: (0xeee768), in [package:flutter/src/material/scaffold.dart] ScaffoldState::_maybeBuildPersistentBottomSheet (0xeeda74)
    //     0xeedc54: ldr             x1, [x1, #0xc10]
    // 0xeedc58: r0 = AllocateClosure()
    //     0xeedc58: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xeedc5c: ldur            x1, [fp, #-8]
    // 0xeedc60: mov             x2, x0
    // 0xeedc64: ldur            x3, [fp, #-0x18]
    // 0xeedc68: r0 = _buildBottomSheet()
    //     0xeedc68: bl              #0xeedcdc  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::_buildBottomSheet
    // 0xeedc6c: ldur            x1, [fp, #-8]
    // 0xeedc70: StoreField: r1->field_57 = r0
    //     0xeedc70: stur            w0, [x1, #0x57]
    //     0xeedc74: ldurb           w16, [x1, #-1]
    //     0xeedc78: ldurb           w17, [x0, #-1]
    //     0xeedc7c: and             x16, x17, x16, lsr #2
    //     0xeedc80: tst             x16, HEAP, lsr #32
    //     0xeedc84: b.eq            #0xeedc8c
    //     0xeedc88: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xeedc8c: r0 = Null
    //     0xeedc8c: mov             x0, NULL
    // 0xeedc90: LeaveFrame
    //     0xeedc90: mov             SP, fp
    //     0xeedc94: ldp             fp, lr, [SP], #0x10
    // 0xeedc98: ret
    //     0xeedc98: ret             
    // 0xeedc9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeedc9c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeedca0: b               #0xeeda90
    // 0xeedca4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xeedca4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xeedca8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeedca8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeedcac: b               #0xeedb80
    // 0xeedcb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeedcb0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeedcb4: b               #0xeedbdc
    // 0xeedcb8: SaveReg d0
    //     0xeedcb8: str             q0, [SP, #-0x10]!
    // 0xeedcbc: stp             x4, x5, [SP, #-0x10]!
    // 0xeedcc0: stp             x0, x3, [SP, #-0x10]!
    // 0xeedcc4: r0 = AllocateDouble()
    //     0xeedcc4: bl              #0x13df878  ; AllocateDoubleStub
    // 0xeedcc8: mov             x2, x0
    // 0xeedccc: ldp             x0, x3, [SP], #0x10
    // 0xeedcd0: ldp             x4, x5, [SP], #0x10
    // 0xeedcd4: RestoreReg d0
    //     0xeedcd4: ldr             q0, [SP], #0x10
    // 0xeedcd8: b               #0xeedc2c
  }
  _ _buildBottomSheet(/* No info */) {
    // ** addr: 0xeedcdc, size: 0x1e8
    // 0xeedcdc: EnterFrame
    //     0xeedcdc: stp             fp, lr, [SP, #-0x10]!
    //     0xeedce0: mov             fp, SP
    // 0xeedce4: AllocStack(0x38)
    //     0xeedce4: sub             SP, SP, #0x38
    // 0xeedce8: SetupParameters(ScaffoldState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xeedce8: stur            x1, [fp, #-8]
    //     0xeedcec: stur            x2, [fp, #-0x10]
    //     0xeedcf0: stur            x3, [fp, #-0x18]
    // 0xeedcf4: CheckStackOverflow
    //     0xeedcf4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeedcf8: cmp             SP, x16
    //     0xeedcfc: b.ls            #0xeedebc
    // 0xeedd00: r1 = 11
    //     0xeedd00: mov             x1, #0xb
    // 0xeedd04: r0 = AllocateContext()
    //     0xeedd04: bl              #0x13de838  ; AllocateContextStub
    // 0xeedd08: mov             x2, x0
    // 0xeedd0c: ldur            x0, [fp, #-8]
    // 0xeedd10: stur            x2, [fp, #-0x20]
    // 0xeedd14: StoreField: r2->field_f = r0
    //     0xeedd14: stur            w0, [x2, #0xf]
    // 0xeedd18: ldur            x0, [fp, #-0x18]
    // 0xeedd1c: StoreField: r2->field_13 = r0
    //     0xeedd1c: stur            w0, [x2, #0x13]
    // 0xeedd20: r1 = <void?>
    //     0xeedd20: ldr             x1, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xeedd24: r0 = _Future()
    //     0xeedd24: bl              #0x7f5dd4  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0xeedd28: stur            x0, [fp, #-8]
    // 0xeedd2c: StoreField: r0->field_b = rZR
    //     0xeedd2c: stur            xzr, [x0, #0xb]
    // 0xeedd30: r0 = LoadStaticField(0x364)
    //     0xeedd30: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xeedd34: ldr             x0, [x0, #0x6c8]
    // 0xeedd38: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xeedd3c: cmp             w0, w16
    // 0xeedd40: b.ne            #0xeedd4c
    // 0xeedd44: r2 = _current
    //     0xeedd44: ldr             x2, [PP, #0x2c0]  ; [pp+0x2c0] Field <Zone._current@5048458>: static late (offset: 0x364)
    // 0xeedd48: r0 = InitLateStaticField()
    //     0xeedd48: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0xeedd4c: mov             x1, x0
    // 0xeedd50: ldur            x0, [fp, #-8]
    // 0xeedd54: StoreField: r0->field_13 = r1
    //     0xeedd54: stur            w1, [x0, #0x13]
    // 0xeedd58: r1 = <void?>
    //     0xeedd58: ldr             x1, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xeedd5c: r0 = _AsyncCompleter()
    //     0xeedd5c: bl              #0x7f5dc8  ; Allocate_AsyncCompleterStub -> _AsyncCompleter<X0> (size=0x10)
    // 0xeedd60: mov             x2, x0
    // 0xeedd64: ldur            x0, [fp, #-8]
    // 0xeedd68: stur            x2, [fp, #-0x28]
    // 0xeedd6c: StoreField: r2->field_b = r0
    //     0xeedd6c: stur            w0, [x2, #0xb]
    // 0xeedd70: ldur            x0, [fp, #-0x20]
    // 0xeedd74: ArrayStore: r0[0] = r2  ; List_4
    //     0xeedd74: stur            w2, [x0, #0x17]
    // 0xeedd78: r1 = <_StandardBottomSheetState>
    //     0xeedd78: add             x1, PP, #0x84, lsl #12  ; [pp+0x84c60] TypeArguments: <_StandardBottomSheetState>
    //     0xeedd7c: ldr             x1, [x1, #0xc60]
    // 0xeedd80: r0 = LabeledGlobalKey()
    //     0xeedd80: bl              #0x856cf8  ; AllocateLabeledGlobalKeyStub -> LabeledGlobalKey<X0 bound State> (size=0x10)
    // 0xeedd84: mov             x3, x0
    // 0xeedd88: ldur            x0, [fp, #-0x20]
    // 0xeedd8c: stur            x3, [fp, #-8]
    // 0xeedd90: StoreField: r0->field_1b = r3
    //     0xeedd90: stur            w3, [x0, #0x1b]
    // 0xeedd94: r4 = false
    //     0xeedd94: add             x4, NULL, #0x30  ; false
    // 0xeedd98: StoreField: r0->field_23 = r4
    //     0xeedd98: stur            w4, [x0, #0x23]
    // 0xeedd9c: StoreField: r0->field_27 = r4
    //     0xeedd9c: stur            w4, [x0, #0x27]
    // 0xeedda0: mov             x2, x0
    // 0xeedda4: r1 = Function 'removePersistentSheetHistoryEntryIfNeeded':.
    //     0xeedda4: add             x1, PP, #0x84, lsl #12  ; [pp+0x84c68] AnonymousClosure: (0xeee5fc), in [package:flutter/src/material/scaffold.dart] ScaffoldState::_buildBottomSheet (0xeedcdc)
    //     0xeedda8: ldr             x1, [x1, #0xc68]
    // 0xeeddac: r0 = AllocateClosure()
    //     0xeeddac: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xeeddb0: mov             x1, x0
    // 0xeeddb4: ldur            x0, [fp, #-0x20]
    // 0xeeddb8: StoreField: r0->field_2b = r1
    //     0xeeddb8: stur            w1, [x0, #0x2b]
    // 0xeeddbc: mov             x2, x0
    // 0xeeddc0: r1 = Function 'removeCurrentBottomSheet':.
    //     0xeeddc0: add             x1, PP, #0x84, lsl #12  ; [pp+0x84c70] AnonymousClosure: (0xeee084), in [package:flutter/src/material/scaffold.dart] ScaffoldState::_buildBottomSheet (0xeedcdc)
    //     0xeeddc4: ldr             x1, [x1, #0xc70]
    // 0xeeddc8: r0 = AllocateClosure()
    //     0xeeddc8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xeeddcc: mov             x3, x0
    // 0xeeddd0: ldur            x0, [fp, #-0x20]
    // 0xeeddd4: stur            x3, [fp, #-0x30]
    // 0xeeddd8: StoreField: r0->field_2f = r3
    //     0xeeddd8: stur            w3, [x0, #0x2f]
    // 0xeedddc: mov             x2, x0
    // 0xeedde0: r1 = Function 'removeEntryIfNeeded':.
    //     0xeedde0: add             x1, PP, #0x84, lsl #12  ; [pp+0x84c78] Function: [dart:ui] Shader::Shader._ (0x13cf838)
    //     0xeedde4: ldr             x1, [x1, #0xc78]
    // 0xeedde8: r0 = AllocateClosure()
    //     0xeedde8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xeeddec: ldur            x2, [fp, #-0x20]
    // 0xeeddf0: StoreField: r2->field_37 = r0
    //     0xeeddf0: stur            w0, [x2, #0x37]
    // 0xeeddf4: r0 = _StandardBottomSheet()
    //     0xeeddf4: bl              #0xeeded0  ; Allocate_StandardBottomSheetStub -> _StandardBottomSheet (size=0x40)
    // 0xeeddf8: mov             x3, x0
    // 0xeeddfc: ldur            x0, [fp, #-0x18]
    // 0xeede00: stur            x3, [fp, #-0x38]
    // 0xeede04: StoreField: r3->field_b = r0
    //     0xeede04: stur            w0, [x3, #0xb]
    // 0xeede08: r0 = false
    //     0xeede08: add             x0, NULL, #0x30  ; false
    // 0xeede0c: StoreField: r3->field_f = r0
    //     0xeede0c: stur            w0, [x3, #0xf]
    // 0xeede10: ldur            x2, [fp, #-0x20]
    // 0xeede14: r1 = Function '<anonymous closure>':.
    //     0xeede14: add             x1, PP, #0x84, lsl #12  ; [pp+0x84c80] AnonymousClosure: (0xeee050), in [package:flutter/src/material/scaffold.dart] ScaffoldState::_buildBottomSheet (0xeedcdc)
    //     0xeede18: ldr             x1, [x1, #0xc80]
    // 0xeede1c: r0 = AllocateClosure()
    //     0xeede1c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xeede20: mov             x1, x0
    // 0xeede24: ldur            x0, [fp, #-0x38]
    // 0xeede28: ArrayStore: r0[0] = r1  ; List_4
    //     0xeede28: stur            w1, [x0, #0x17]
    // 0xeede2c: ldur            x2, [fp, #-0x20]
    // 0xeede30: r1 = Function '<anonymous closure>':.
    //     0xeede30: add             x1, PP, #0x84, lsl #12  ; [pp+0x84c88] AnonymousClosure: (0xeedf28), in [package:flutter/src/material/scaffold.dart] ScaffoldState::_buildBottomSheet (0xeedcdc)
    //     0xeede34: ldr             x1, [x1, #0xc88]
    // 0xeede38: r0 = AllocateClosure()
    //     0xeede38: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xeede3c: mov             x1, x0
    // 0xeede40: ldur            x0, [fp, #-0x38]
    // 0xeede44: StoreField: r0->field_1b = r1
    //     0xeede44: stur            w1, [x0, #0x1b]
    // 0xeede48: ldur            x1, [fp, #-0x10]
    // 0xeede4c: StoreField: r0->field_23 = r1
    //     0xeede4c: stur            w1, [x0, #0x23]
    // 0xeede50: r1 = true
    //     0xeede50: add             x1, NULL, #0x20  ; true
    // 0xeede54: StoreField: r0->field_27 = r1
    //     0xeede54: stur            w1, [x0, #0x27]
    // 0xeede58: ldur            x2, [fp, #-0x20]
    // 0xeede5c: r1 = Function '<anonymous closure>':.
    //     0xeede5c: add             x1, PP, #0x84, lsl #12  ; [pp+0x84c90] AnonymousClosure: (0xeededc), in [package:flutter/src/material/scaffold.dart] ScaffoldState::_buildBottomSheet (0xeedcdc)
    //     0xeede60: ldr             x1, [x1, #0xc90]
    // 0xeede64: r0 = AllocateClosure()
    //     0xeede64: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xeede68: mov             x1, x0
    // 0xeede6c: ldur            x0, [fp, #-0x38]
    // 0xeede70: StoreField: r0->field_1f = r1
    //     0xeede70: stur            w1, [x0, #0x1f]
    // 0xeede74: ldur            x1, [fp, #-8]
    // 0xeede78: StoreField: r0->field_7 = r1
    //     0xeede78: stur            w1, [x0, #7]
    // 0xeede7c: ldur            x1, [fp, #-0x20]
    // 0xeede80: StoreField: r1->field_1f = r0
    //     0xeede80: stur            w0, [x1, #0x1f]
    // 0xeede84: r1 = <_StandardBottomSheet, void?>
    //     0xeede84: add             x1, PP, #0x84, lsl #12  ; [pp+0x84c98] TypeArguments: <_StandardBottomSheet, void?>
    //     0xeede88: ldr             x1, [x1, #0xc98]
    // 0xeede8c: r0 = PersistentBottomSheetController()
    //     0xeede8c: bl              #0xeedec4  ; AllocatePersistentBottomSheetControllerStub -> PersistentBottomSheetController (size=0x1c)
    // 0xeede90: r1 = false
    //     0xeede90: add             x1, NULL, #0x30  ; false
    // 0xeede94: ArrayStore: r0[0] = r1  ; List_4
    //     0xeede94: stur            w1, [x0, #0x17]
    // 0xeede98: ldur            x1, [fp, #-0x38]
    // 0xeede9c: StoreField: r0->field_b = r1
    //     0xeede9c: stur            w1, [x0, #0xb]
    // 0xeedea0: ldur            x1, [fp, #-0x28]
    // 0xeedea4: StoreField: r0->field_f = r1
    //     0xeedea4: stur            w1, [x0, #0xf]
    // 0xeedea8: ldur            x1, [fp, #-0x30]
    // 0xeedeac: StoreField: r0->field_13 = r1
    //     0xeedeac: stur            w1, [x0, #0x13]
    // 0xeedeb0: LeaveFrame
    //     0xeedeb0: mov             SP, fp
    //     0xeedeb4: ldp             fp, lr, [SP], #0x10
    // 0xeedeb8: ret
    //     0xeedeb8: ret             
    // 0xeedebc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeedebc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeedec0: b               #0xeedd00
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xeededc, size: 0x4c
    // 0xeededc: EnterFrame
    //     0xeededc: stp             fp, lr, [SP, #-0x10]!
    //     0xeedee0: mov             fp, SP
    // 0xeedee4: r0 = true
    //     0xeedee4: add             x0, NULL, #0x20  ; true
    // 0xeedee8: ldr             x1, [fp, #0x10]
    // 0xeedeec: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xeedeec: ldur            w2, [x1, #0x17]
    // 0xeedef0: DecompressPointer r2
    //     0xeedef0: add             x2, x2, HEAP, lsl #32
    // 0xeedef4: CheckStackOverflow
    //     0xeedef4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeedef8: cmp             SP, x16
    //     0xeedefc: b.ls            #0xeedf20
    // 0xeedf00: StoreField: r2->field_27 = r0
    //     0xeedf00: stur            w0, [x2, #0x27]
    // 0xeedf04: LoadField: r1 = r2->field_13
    //     0xeedf04: ldur            w1, [x2, #0x13]
    // 0xeedf08: DecompressPointer r1
    //     0xeedf08: add             x1, x1, HEAP, lsl #32
    // 0xeedf0c: r0 = dispose()
    //     0xeedf0c: bl              #0x9164f4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0xeedf10: r0 = Null
    //     0xeedf10: mov             x0, NULL
    // 0xeedf14: LeaveFrame
    //     0xeedf14: mov             SP, fp
    //     0xeedf18: ldp             fp, lr, [SP], #0x10
    // 0xeedf1c: ret
    //     0xeedf1c: ret             
    // 0xeedf20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeedf20: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeedf24: b               #0xeedf00
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xeedf28, size: 0xa8
    // 0xeedf28: EnterFrame
    //     0xeedf28: stp             fp, lr, [SP, #-0x10]!
    //     0xeedf2c: mov             fp, SP
    // 0xeedf30: AllocStack(0x18)
    //     0xeedf30: sub             SP, SP, #0x18
    // 0xeedf34: SetupParameters([dynamic _ /* r0 */])
    //     0xeedf34: ldr             x0, [fp, #0x10]
    //     0xeedf38: ldur            w3, [x0, #0x17]
    //     0xeedf3c: add             x3, x3, HEAP, lsl #32
    //     0xeedf40: stur            x3, [fp, #-8]
    // 0xeedf44: CheckStackOverflow
    //     0xeedf44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeedf48: cmp             SP, x16
    //     0xeedf4c: b.ls            #0xeedfc8
    // 0xeedf50: LoadField: r0 = r3->field_f
    //     0xeedf50: ldur            w0, [x3, #0xf]
    // 0xeedf54: DecompressPointer r0
    //     0xeedf54: add             x0, x0, HEAP, lsl #32
    // 0xeedf58: LoadField: r1 = r0->field_53
    //     0xeedf58: ldur            w1, [x0, #0x53]
    // 0xeedf5c: DecompressPointer r1
    //     0xeedf5c: add             x1, x1, HEAP, lsl #32
    // 0xeedf60: LoadField: r2 = r3->field_1f
    //     0xeedf60: ldur            w2, [x3, #0x1f]
    // 0xeedf64: DecompressPointer r2
    //     0xeedf64: add             x2, x2, HEAP, lsl #32
    // 0xeedf68: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xeedf6c: cmp             w2, w16
    // 0xeedf70: b.eq            #0xeedfb4
    // 0xeedf74: r0 = contains()
    //     0xeedf74: bl              #0xbaf414  ; [dart:collection] ListBase::contains
    // 0xeedf78: tbnz            w0, #4, #0xeedfa4
    // 0xeedf7c: ldur            x2, [fp, #-8]
    // 0xeedf80: LoadField: r0 = r2->field_f
    //     0xeedf80: ldur            w0, [x2, #0xf]
    // 0xeedf84: DecompressPointer r0
    //     0xeedf84: add             x0, x0, HEAP, lsl #32
    // 0xeedf88: stur            x0, [fp, #-0x10]
    // 0xeedf8c: r1 = Function '<anonymous closure>':.
    //     0xeedf8c: add             x1, PP, #0x84, lsl #12  ; [pp+0x84ca0] AnonymousClosure: (0xeedfd0), in [package:flutter/src/material/scaffold.dart] ScaffoldState::_buildBottomSheet (0xeedcdc)
    //     0xeedf90: ldr             x1, [x1, #0xca0]
    // 0xeedf94: r0 = AllocateClosure()
    //     0xeedf94: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xeedf98: ldur            x1, [fp, #-0x10]
    // 0xeedf9c: mov             x2, x0
    // 0xeedfa0: r0 = setState()
    //     0xeedfa0: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xeedfa4: r0 = Null
    //     0xeedfa4: mov             x0, NULL
    // 0xeedfa8: LeaveFrame
    //     0xeedfa8: mov             SP, fp
    //     0xeedfac: ldp             fp, lr, [SP], #0x10
    // 0xeedfb0: ret
    //     0xeedfb0: ret             
    // 0xeedfb4: r16 = "bottomSheet"
    //     0xeedfb4: add             x16, PP, #0x84, lsl #12  ; [pp+0x84ca8] "bottomSheet"
    //     0xeedfb8: ldr             x16, [x16, #0xca8]
    // 0xeedfbc: str             x16, [SP]
    // 0xeedfc0: r0 = _throwLocalNotInitialized()
    //     0xeedfc0: bl              #0x82b57c  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0xeedfc4: brk             #0
    // 0xeedfc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeedfc8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeedfcc: b               #0xeedf50
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xeedfd0, size: 0x80
    // 0xeedfd0: EnterFrame
    //     0xeedfd0: stp             fp, lr, [SP, #-0x10]!
    //     0xeedfd4: mov             fp, SP
    // 0xeedfd8: AllocStack(0x8)
    //     0xeedfd8: sub             SP, SP, #8
    // 0xeedfdc: SetupParameters([dynamic _ /* r0 */])
    //     0xeedfdc: ldr             x0, [fp, #0x10]
    //     0xeedfe0: ldur            w1, [x0, #0x17]
    //     0xeedfe4: add             x1, x1, HEAP, lsl #32
    // 0xeedfe8: CheckStackOverflow
    //     0xeedfe8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeedfec: cmp             SP, x16
    //     0xeedff0: b.ls            #0xeee048
    // 0xeedff4: LoadField: r0 = r1->field_f
    //     0xeedff4: ldur            w0, [x1, #0xf]
    // 0xeedff8: DecompressPointer r0
    //     0xeedff8: add             x0, x0, HEAP, lsl #32
    // 0xeedffc: LoadField: r2 = r0->field_53
    //     0xeedffc: ldur            w2, [x0, #0x53]
    // 0xeee000: DecompressPointer r2
    //     0xeee000: add             x2, x2, HEAP, lsl #32
    // 0xeee004: LoadField: r0 = r1->field_1f
    //     0xeee004: ldur            w0, [x1, #0x1f]
    // 0xeee008: DecompressPointer r0
    //     0xeee008: add             x0, x0, HEAP, lsl #32
    // 0xeee00c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xeee010: cmp             w0, w16
    // 0xeee014: b.eq            #0xeee034
    // 0xeee018: mov             x1, x2
    // 0xeee01c: mov             x2, x0
    // 0xeee020: r0 = remove()
    //     0xeee020: bl              #0xa10a64  ; [dart:core] _GrowableList::remove
    // 0xeee024: r0 = Null
    //     0xeee024: mov             x0, NULL
    // 0xeee028: LeaveFrame
    //     0xeee028: mov             SP, fp
    //     0xeee02c: ldp             fp, lr, [SP], #0x10
    // 0xeee030: ret
    //     0xeee030: ret             
    // 0xeee034: r16 = "bottomSheet"
    //     0xeee034: add             x16, PP, #0x84, lsl #12  ; [pp+0x84ca8] "bottomSheet"
    //     0xeee038: ldr             x16, [x16, #0xca8]
    // 0xeee03c: str             x16, [SP]
    // 0xeee040: r0 = _throwLocalNotInitialized()
    //     0xeee040: bl              #0x82b57c  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0xeee044: brk             #0
    // 0xeee048: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeee048: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeee04c: b               #0xeedff4
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xeee050, size: 0x34
    // 0xeee050: ldr             x1, [SP]
    // 0xeee054: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xeee054: ldur            w2, [x1, #0x17]
    // 0xeee058: DecompressPointer r2
    //     0xeee058: add             x2, x2, HEAP, lsl #32
    // 0xeee05c: LoadField: r1 = r2->field_f
    //     0xeee05c: ldur            w1, [x2, #0xf]
    // 0xeee060: DecompressPointer r1
    //     0xeee060: add             x1, x1, HEAP, lsl #32
    // 0xeee064: LoadField: r2 = r1->field_57
    //     0xeee064: ldur            w2, [x1, #0x57]
    // 0xeee068: DecompressPointer r2
    //     0xeee068: add             x2, x2, HEAP, lsl #32
    // 0xeee06c: cmp             w2, NULL
    // 0xeee070: b.ne            #0xeee07c
    // 0xeee074: r0 = Null
    //     0xeee074: mov             x0, NULL
    // 0xeee078: ret
    //     0xeee078: ret             
    // 0xeee07c: r0 = Null
    //     0xeee07c: mov             x0, NULL
    // 0xeee080: ret
    //     0xeee080: ret             
  }
  [closure] void removeCurrentBottomSheet(dynamic) {
    // ** addr: 0xeee084, size: 0x204
    // 0xeee084: EnterFrame
    //     0xeee084: stp             fp, lr, [SP, #-0x10]!
    //     0xeee088: mov             fp, SP
    // 0xeee08c: AllocStack(0x28)
    //     0xeee08c: sub             SP, SP, #0x28
    // 0xeee090: SetupParameters([dynamic _ /* r1 */])
    //     0xeee090: add             x0, NULL, #0x20  ; true
    //     0xeee094: ldr             x1, [fp, #0x10]
    //     0xeee098: ldur            w2, [x1, #0x17]
    //     0xeee09c: add             x2, x2, HEAP, lsl #32
    //     0xeee0a0: stur            x2, [fp, #-8]
    // 0xeee090: r0 = true
    // 0xeee0a4: CheckStackOverflow
    //     0xeee0a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeee0a8: cmp             SP, x16
    //     0xeee0ac: b.ls            #0xeee274
    // 0xeee0b0: StoreField: r2->field_23 = r0
    //     0xeee0b0: stur            w0, [x2, #0x23]
    // 0xeee0b4: LoadField: r1 = r2->field_f
    //     0xeee0b4: ldur            w1, [x2, #0xf]
    // 0xeee0b8: DecompressPointer r1
    //     0xeee0b8: add             x1, x1, HEAP, lsl #32
    // 0xeee0bc: LoadField: r0 = r1->field_57
    //     0xeee0bc: ldur            w0, [x1, #0x57]
    // 0xeee0c0: DecompressPointer r0
    //     0xeee0c0: add             x0, x0, HEAP, lsl #32
    // 0xeee0c4: cmp             w0, NULL
    // 0xeee0c8: b.ne            #0xeee0dc
    // 0xeee0cc: r0 = Null
    //     0xeee0cc: mov             x0, NULL
    // 0xeee0d0: LeaveFrame
    //     0xeee0d0: mov             SP, fp
    //     0xeee0d4: ldp             fp, lr, [SP], #0x10
    // 0xeee0d8: ret
    //     0xeee0d8: ret             
    // 0xeee0dc: r0 = _showFloatingActionButton()
    //     0xeee0dc: bl              #0xeee51c  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::_showFloatingActionButton
    // 0xeee0e0: ldur            x2, [fp, #-8]
    // 0xeee0e4: LoadField: r0 = r2->field_2b
    //     0xeee0e4: ldur            w0, [x2, #0x2b]
    // 0xeee0e8: DecompressPointer r0
    //     0xeee0e8: add             x0, x0, HEAP, lsl #32
    // 0xeee0ec: ArrayLoad: r3 = r0[0]  ; List_4
    //     0xeee0ec: ldur            w3, [x0, #0x17]
    // 0xeee0f0: DecompressPointer r3
    //     0xeee0f0: add             x3, x3, HEAP, lsl #32
    // 0xeee0f4: stur            x3, [fp, #-0x10]
    // 0xeee0f8: LoadField: r0 = r3->field_f
    //     0xeee0f8: ldur            w0, [x3, #0xf]
    // 0xeee0fc: DecompressPointer r0
    //     0xeee0fc: add             x0, x0, HEAP, lsl #32
    // 0xeee100: LoadField: r1 = r0->field_5f
    //     0xeee100: ldur            w1, [x0, #0x5f]
    // 0xeee104: DecompressPointer r1
    //     0xeee104: add             x1, x1, HEAP, lsl #32
    // 0xeee108: cmp             w1, NULL
    // 0xeee10c: b.eq            #0xeee124
    // 0xeee110: r0 = remove()
    //     0xeee110: bl              #0xeee288  ; [package:flutter/src/widgets/routes.dart] LocalHistoryEntry::remove
    // 0xeee114: ldur            x0, [fp, #-0x10]
    // 0xeee118: LoadField: r1 = r0->field_f
    //     0xeee118: ldur            w1, [x0, #0xf]
    // 0xeee11c: DecompressPointer r1
    //     0xeee11c: add             x1, x1, HEAP, lsl #32
    // 0xeee120: StoreField: r1->field_5f = rNULL
    //     0xeee120: stur            NULL, [x1, #0x5f]
    // 0xeee124: ldur            x2, [fp, #-8]
    // 0xeee128: LoadField: r1 = r2->field_1b
    //     0xeee128: ldur            w1, [x2, #0x1b]
    // 0xeee12c: DecompressPointer r1
    //     0xeee12c: add             x1, x1, HEAP, lsl #32
    // 0xeee130: r0 = currentState()
    //     0xeee130: bl              #0x8591f8  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0xeee134: cmp             w0, NULL
    // 0xeee138: b.eq            #0xeee27c
    // 0xeee13c: mov             x1, x0
    // 0xeee140: r0 = close()
    //     0xeee140: bl              #0xdfbf84  ; [package:flutter/src/material/scaffold.dart] _StandardBottomSheetState::close
    // 0xeee144: ldur            x0, [fp, #-8]
    // 0xeee148: LoadField: r3 = r0->field_f
    //     0xeee148: ldur            w3, [x0, #0xf]
    // 0xeee14c: DecompressPointer r3
    //     0xeee14c: add             x3, x3, HEAP, lsl #32
    // 0xeee150: mov             x2, x0
    // 0xeee154: stur            x3, [fp, #-0x10]
    // 0xeee158: r1 = Function '<anonymous closure>':.
    //     0xeee158: add             x1, PP, #0x84, lsl #12  ; [pp+0x84cb0] AnonymousClosure: (0xeee570), in [package:flutter/src/material/scaffold.dart] ScaffoldState::_buildBottomSheet (0xeedcdc)
    //     0xeee15c: ldr             x1, [x1, #0xcb0]
    // 0xeee160: r0 = AllocateClosure()
    //     0xeee160: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xeee164: ldur            x1, [fp, #-0x10]
    // 0xeee168: mov             x2, x0
    // 0xeee16c: r0 = setState()
    //     0xeee16c: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xeee170: ldur            x0, [fp, #-8]
    // 0xeee174: LoadField: r1 = r0->field_13
    //     0xeee174: ldur            w1, [x0, #0x13]
    // 0xeee178: DecompressPointer r1
    //     0xeee178: add             x1, x1, HEAP, lsl #32
    // 0xeee17c: LoadField: r2 = r1->field_43
    //     0xeee17c: ldur            w2, [x1, #0x43]
    // 0xeee180: DecompressPointer r2
    //     0xeee180: add             x2, x2, HEAP, lsl #32
    // 0xeee184: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xeee188: cmp             w2, w16
    // 0xeee18c: b.eq            #0xeee280
    // 0xeee190: r16 = Instance_AnimationStatus
    //     0xeee190: ldr             x16, [PP, #0x51a8]  ; [pp+0x51a8] Obj!AnimationStatus@12c61c1
    // 0xeee194: cmp             w2, w16
    // 0xeee198: b.eq            #0xeee23c
    // 0xeee19c: LoadField: r1 = r0->field_f
    //     0xeee19c: ldur            w1, [x0, #0xf]
    // 0xeee1a0: DecompressPointer r1
    //     0xeee1a0: add             x1, x1, HEAP, lsl #32
    // 0xeee1a4: LoadField: r2 = r1->field_53
    //     0xeee1a4: ldur            w2, [x1, #0x53]
    // 0xeee1a8: DecompressPointer r2
    //     0xeee1a8: add             x2, x2, HEAP, lsl #32
    // 0xeee1ac: stur            x2, [fp, #-0x20]
    // 0xeee1b0: LoadField: r3 = r0->field_1f
    //     0xeee1b0: ldur            w3, [x0, #0x1f]
    // 0xeee1b4: DecompressPointer r3
    //     0xeee1b4: add             x3, x3, HEAP, lsl #32
    // 0xeee1b8: stur            x3, [fp, #-0x10]
    // 0xeee1bc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xeee1c0: cmp             w3, w16
    // 0xeee1c4: b.eq            #0xeee260
    // 0xeee1c8: LoadField: r1 = r2->field_b
    //     0xeee1c8: ldur            w1, [x2, #0xb]
    // 0xeee1cc: LoadField: r4 = r2->field_f
    //     0xeee1cc: ldur            w4, [x2, #0xf]
    // 0xeee1d0: DecompressPointer r4
    //     0xeee1d0: add             x4, x4, HEAP, lsl #32
    // 0xeee1d4: LoadField: r5 = r4->field_b
    //     0xeee1d4: ldur            w5, [x4, #0xb]
    // 0xeee1d8: r4 = LoadInt32Instr(r1)
    //     0xeee1d8: sbfx            x4, x1, #1, #0x1f
    // 0xeee1dc: stur            x4, [fp, #-0x18]
    // 0xeee1e0: r1 = LoadInt32Instr(r5)
    //     0xeee1e0: sbfx            x1, x5, #1, #0x1f
    // 0xeee1e4: cmp             x4, x1
    // 0xeee1e8: b.ne            #0xeee1f4
    // 0xeee1ec: mov             x1, x2
    // 0xeee1f0: r0 = _growToNextCapacity()
    //     0xeee1f0: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xeee1f4: ldur            x0, [fp, #-0x20]
    // 0xeee1f8: ldur            x2, [fp, #-0x18]
    // 0xeee1fc: add             x1, x2, #1
    // 0xeee200: lsl             x3, x1, #1
    // 0xeee204: StoreField: r0->field_b = r3
    //     0xeee204: stur            w3, [x0, #0xb]
    // 0xeee208: LoadField: r1 = r0->field_f
    //     0xeee208: ldur            w1, [x0, #0xf]
    // 0xeee20c: DecompressPointer r1
    //     0xeee20c: add             x1, x1, HEAP, lsl #32
    // 0xeee210: ldur            x0, [fp, #-0x10]
    // 0xeee214: ArrayStore: r1[r2] = r0  ; List_4
    //     0xeee214: add             x25, x1, x2, lsl #2
    //     0xeee218: add             x25, x25, #0xf
    //     0xeee21c: str             w0, [x25]
    //     0xeee220: tbz             w0, #0, #0xeee23c
    //     0xeee224: ldurb           w16, [x1, #-1]
    //     0xeee228: ldurb           w17, [x0, #-1]
    //     0xeee22c: and             x16, x17, x16, lsr #2
    //     0xeee230: tst             x16, HEAP, lsr #32
    //     0xeee234: b.eq            #0xeee23c
    //     0xeee238: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xeee23c: ldur            x0, [fp, #-8]
    // 0xeee240: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xeee240: ldur            w1, [x0, #0x17]
    // 0xeee244: DecompressPointer r1
    //     0xeee244: add             x1, x1, HEAP, lsl #32
    // 0xeee248: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xeee248: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xeee24c: r0 = complete()
    //     0xeee24c: bl              #0x128a5ec  ; [dart:async] _AsyncCompleter::complete
    // 0xeee250: r0 = Null
    //     0xeee250: mov             x0, NULL
    // 0xeee254: LeaveFrame
    //     0xeee254: mov             SP, fp
    //     0xeee258: ldp             fp, lr, [SP], #0x10
    // 0xeee25c: ret
    //     0xeee25c: ret             
    // 0xeee260: r16 = "bottomSheet"
    //     0xeee260: add             x16, PP, #0x84, lsl #12  ; [pp+0x84ca8] "bottomSheet"
    //     0xeee264: ldr             x16, [x16, #0xca8]
    // 0xeee268: str             x16, [SP]
    // 0xeee26c: r0 = _throwLocalNotInitialized()
    //     0xeee26c: bl              #0x82b57c  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0xeee270: brk             #0
    // 0xeee274: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeee274: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeee278: b               #0xeee0b0
    // 0xeee27c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xeee27c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xeee280: r9 = _status
    //     0xeee280: ldr             x9, [PP, #0x51e8]  ; [pp+0x51e8] Field <AnimationController._status@62066280>: late (offset: 0x44)
    // 0xeee284: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xeee284: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _showFloatingActionButton(/* No info */) {
    // ** addr: 0xeee51c, size: 0x54
    // 0xeee51c: EnterFrame
    //     0xeee51c: stp             fp, lr, [SP, #-0x10]!
    //     0xeee520: mov             fp, SP
    // 0xeee524: CheckStackOverflow
    //     0xeee524: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeee528: cmp             SP, x16
    //     0xeee52c: b.ls            #0xeee55c
    // 0xeee530: LoadField: r0 = r1->field_73
    //     0xeee530: ldur            w0, [x1, #0x73]
    // 0xeee534: DecompressPointer r0
    //     0xeee534: add             x0, x0, HEAP, lsl #32
    // 0xeee538: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xeee53c: cmp             w0, w16
    // 0xeee540: b.eq            #0xeee564
    // 0xeee544: mov             x1, x0
    // 0xeee548: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xeee548: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xeee54c: r0 = forward()
    //     0xeee54c: bl              #0x8cd83c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0xeee550: LeaveFrame
    //     0xeee550: mov             SP, fp
    //     0xeee554: ldp             fp, lr, [SP], #0x10
    // 0xeee558: ret
    //     0xeee558: ret             
    // 0xeee55c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeee55c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeee560: b               #0xeee530
    // 0xeee564: r9 = _floatingActionButtonVisibilityController
    //     0xeee564: add             x9, PP, #0x84, lsl #12  ; [pp+0x84b68] Field <ScaffoldState._floatingActionButtonVisibilityController@89420462>: late (offset: 0x74)
    //     0xeee568: ldr             x9, [x9, #0xb68]
    // 0xeee56c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xeee56c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xeee570, size: 0x8c
    // 0xeee570: EnterFrame
    //     0xeee570: stp             fp, lr, [SP, #-0x10]!
    //     0xeee574: mov             fp, SP
    // 0xeee578: AllocStack(0x8)
    //     0xeee578: sub             SP, SP, #8
    // 0xeee57c: SetupParameters([dynamic _ /* r1 */])
    //     0xeee57c: add             x0, NULL, #0x30  ; false
    //     0xeee580: ldr             x1, [fp, #0x10]
    //     0xeee584: ldur            w3, [x1, #0x17]
    //     0xeee588: add             x3, x3, HEAP, lsl #32
    //     0xeee58c: stur            x3, [fp, #-8]
    // 0xeee57c: r0 = false
    // 0xeee590: CheckStackOverflow
    //     0xeee590: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeee594: cmp             SP, x16
    //     0xeee598: b.ls            #0xeee5e8
    // 0xeee59c: LoadField: r1 = r3->field_f
    //     0xeee59c: ldur            w1, [x3, #0xf]
    // 0xeee5a0: DecompressPointer r1
    //     0xeee5a0: add             x1, x1, HEAP, lsl #32
    // 0xeee5a4: StoreField: r1->field_7f = r0
    //     0xeee5a4: stur            w0, [x1, #0x7f]
    // 0xeee5a8: LoadField: r0 = r1->field_7b
    //     0xeee5a8: ldur            w0, [x1, #0x7b]
    // 0xeee5ac: DecompressPointer r0
    //     0xeee5ac: add             x0, x0, HEAP, lsl #32
    // 0xeee5b0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xeee5b4: cmp             w0, w16
    // 0xeee5b8: b.eq            #0xeee5f0
    // 0xeee5bc: mov             x1, x0
    // 0xeee5c0: r2 = 0.000000
    //     0xeee5c0: ldr             x2, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xeee5c4: r0 = value=()
    //     0xeee5c4: bl              #0x829534  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0xeee5c8: ldur            x1, [fp, #-8]
    // 0xeee5cc: LoadField: r2 = r1->field_f
    //     0xeee5cc: ldur            w2, [x1, #0xf]
    // 0xeee5d0: DecompressPointer r2
    //     0xeee5d0: add             x2, x2, HEAP, lsl #32
    // 0xeee5d4: StoreField: r2->field_57 = rNULL
    //     0xeee5d4: stur            NULL, [x2, #0x57]
    // 0xeee5d8: r0 = Null
    //     0xeee5d8: mov             x0, NULL
    // 0xeee5dc: LeaveFrame
    //     0xeee5dc: mov             SP, fp
    //     0xeee5e0: ldp             fp, lr, [SP], #0x10
    // 0xeee5e4: ret
    //     0xeee5e4: ret             
    // 0xeee5e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeee5e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeee5ec: b               #0xeee59c
    // 0xeee5f0: r9 = _bottomSheetScrimAnimationController
    //     0xeee5f0: add             x9, PP, #0x84, lsl #12  ; [pp+0x84b48] Field <ScaffoldState._bottomSheetScrimAnimationController@89420462>: late (offset: 0x7c)
    //     0xeee5f4: ldr             x9, [x9, #0xb48]
    // 0xeee5f8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xeee5f8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void removePersistentSheetHistoryEntryIfNeeded(dynamic) {
    // ** addr: 0xeee5fc, size: 0x6c
    // 0xeee5fc: EnterFrame
    //     0xeee5fc: stp             fp, lr, [SP, #-0x10]!
    //     0xeee600: mov             fp, SP
    // 0xeee604: AllocStack(0x8)
    //     0xeee604: sub             SP, SP, #8
    // 0xeee608: SetupParameters([dynamic _ /* r0 */])
    //     0xeee608: ldr             x0, [fp, #0x10]
    //     0xeee60c: ldur            w2, [x0, #0x17]
    //     0xeee610: add             x2, x2, HEAP, lsl #32
    //     0xeee614: stur            x2, [fp, #-8]
    // 0xeee618: CheckStackOverflow
    //     0xeee618: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeee61c: cmp             SP, x16
    //     0xeee620: b.ls            #0xeee660
    // 0xeee624: LoadField: r0 = r2->field_f
    //     0xeee624: ldur            w0, [x2, #0xf]
    // 0xeee628: DecompressPointer r0
    //     0xeee628: add             x0, x0, HEAP, lsl #32
    // 0xeee62c: LoadField: r1 = r0->field_5f
    //     0xeee62c: ldur            w1, [x0, #0x5f]
    // 0xeee630: DecompressPointer r1
    //     0xeee630: add             x1, x1, HEAP, lsl #32
    // 0xeee634: cmp             w1, NULL
    // 0xeee638: b.eq            #0xeee650
    // 0xeee63c: r0 = remove()
    //     0xeee63c: bl              #0xeee288  ; [package:flutter/src/widgets/routes.dart] LocalHistoryEntry::remove
    // 0xeee640: ldur            x1, [fp, #-8]
    // 0xeee644: LoadField: r2 = r1->field_f
    //     0xeee644: ldur            w2, [x1, #0xf]
    // 0xeee648: DecompressPointer r2
    //     0xeee648: add             x2, x2, HEAP, lsl #32
    // 0xeee64c: StoreField: r2->field_5f = rNULL
    //     0xeee64c: stur            NULL, [x2, #0x5f]
    // 0xeee650: r0 = Null
    //     0xeee650: mov             x0, NULL
    // 0xeee654: LeaveFrame
    //     0xeee654: mov             SP, fp
    //     0xeee658: ldp             fp, lr, [SP], #0x10
    // 0xeee65c: ret
    //     0xeee65c: ret             
    // 0xeee660: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeee660: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeee664: b               #0xeee624
  }
  [closure] NotificationListener<DraggableScrollableNotification> <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0xeee768, size: 0xac
    // 0xeee768: EnterFrame
    //     0xeee768: stp             fp, lr, [SP, #-0x10]!
    //     0xeee76c: mov             fp, SP
    // 0xeee770: AllocStack(0x20)
    //     0xeee770: sub             SP, SP, #0x20
    // 0xeee774: SetupParameters([dynamic _ /* r0 */])
    //     0xeee774: ldr             x0, [fp, #0x18]
    //     0xeee778: ldur            w3, [x0, #0x17]
    //     0xeee77c: add             x3, x3, HEAP, lsl #32
    //     0xeee780: stur            x3, [fp, #-0x10]
    // 0xeee784: LoadField: r0 = r3->field_f
    //     0xeee784: ldur            w0, [x3, #0xf]
    // 0xeee788: DecompressPointer r0
    //     0xeee788: add             x0, x0, HEAP, lsl #32
    // 0xeee78c: LoadField: r4 = r0->field_5b
    //     0xeee78c: ldur            w4, [x0, #0x5b]
    // 0xeee790: DecompressPointer r4
    //     0xeee790: add             x4, x4, HEAP, lsl #32
    // 0xeee794: mov             x2, x3
    // 0xeee798: stur            x4, [fp, #-8]
    // 0xeee79c: r1 = Function '<anonymous closure>':.
    //     0xeee79c: add             x1, PP, #0x84, lsl #12  ; [pp+0x84c18] AnonymousClosure: (0xeee820), in [package:flutter/src/material/scaffold.dart] ScaffoldState::_maybeBuildPersistentBottomSheet (0xeeda74)
    //     0xeee7a0: ldr             x1, [x1, #0xc18]
    // 0xeee7a4: r0 = AllocateClosure()
    //     0xeee7a4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xeee7a8: stur            x0, [fp, #-0x18]
    // 0xeee7ac: r0 = StatefulBuilder()
    //     0xeee7ac: bl              #0xd95de4  ; AllocateStatefulBuilderStub -> StatefulBuilder (size=0x10)
    // 0xeee7b0: mov             x1, x0
    // 0xeee7b4: ldur            x0, [fp, #-0x18]
    // 0xeee7b8: stur            x1, [fp, #-0x20]
    // 0xeee7bc: StoreField: r1->field_b = r0
    //     0xeee7bc: stur            w0, [x1, #0xb]
    // 0xeee7c0: ldur            x0, [fp, #-8]
    // 0xeee7c4: StoreField: r1->field_7 = r0
    //     0xeee7c4: stur            w0, [x1, #7]
    // 0xeee7c8: r0 = DraggableScrollableActuator()
    //     0xeee7c8: bl              #0xeee814  ; AllocateDraggableScrollableActuatorStub -> DraggableScrollableActuator (size=0x10)
    // 0xeee7cc: mov             x2, x0
    // 0xeee7d0: ldur            x0, [fp, #-0x20]
    // 0xeee7d4: stur            x2, [fp, #-0x18]
    // 0xeee7d8: StoreField: r2->field_b = r0
    //     0xeee7d8: stur            w0, [x2, #0xb]
    // 0xeee7dc: ldur            x0, [fp, #-0x10]
    // 0xeee7e0: LoadField: r3 = r0->field_13
    //     0xeee7e0: ldur            w3, [x0, #0x13]
    // 0xeee7e4: DecompressPointer r3
    //     0xeee7e4: add             x3, x3, HEAP, lsl #32
    // 0xeee7e8: stur            x3, [fp, #-8]
    // 0xeee7ec: r1 = <DraggableScrollableNotification>
    //     0xeee7ec: add             x1, PP, #0x84, lsl #12  ; [pp+0x84c20] TypeArguments: <DraggableScrollableNotification>
    //     0xeee7f0: ldr             x1, [x1, #0xc20]
    // 0xeee7f4: r0 = NotificationListener()
    //     0xeee7f4: bl              #0xd2ea9c  ; AllocateNotificationListenerStub -> NotificationListener<X0 bound Notification> (size=0x18)
    // 0xeee7f8: ldur            x1, [fp, #-8]
    // 0xeee7fc: StoreField: r0->field_13 = r1
    //     0xeee7fc: stur            w1, [x0, #0x13]
    // 0xeee800: ldur            x1, [fp, #-0x18]
    // 0xeee804: StoreField: r0->field_b = r1
    //     0xeee804: stur            w1, [x0, #0xb]
    // 0xeee808: LeaveFrame
    //     0xeee808: mov             SP, fp
    //     0xeee80c: ldp             fp, lr, [SP], #0x10
    // 0xeee810: ret
    //     0xeee810: ret             
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext, (dynamic, (dynamic) => void) => void) {
    // ** addr: 0xeee820, size: 0x50
    // 0xeee820: ldr             x1, [SP, #0x10]
    // 0xeee824: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xeee824: ldur            w2, [x1, #0x17]
    // 0xeee828: DecompressPointer r2
    //     0xeee828: add             x2, x2, HEAP, lsl #32
    // 0xeee82c: LoadField: r1 = r2->field_f
    //     0xeee82c: ldur            w1, [x2, #0xf]
    // 0xeee830: DecompressPointer r1
    //     0xeee830: add             x1, x1, HEAP, lsl #32
    // 0xeee834: LoadField: r2 = r1->field_b
    //     0xeee834: ldur            w2, [x1, #0xb]
    // 0xeee838: DecompressPointer r2
    //     0xeee838: add             x2, x2, HEAP, lsl #32
    // 0xeee83c: cmp             w2, NULL
    // 0xeee840: b.eq            #0xeee864
    // 0xeee844: LoadField: r1 = r2->field_53
    //     0xeee844: ldur            w1, [x2, #0x53]
    // 0xeee848: DecompressPointer r1
    //     0xeee848: add             x1, x1, HEAP, lsl #32
    // 0xeee84c: cmp             w1, NULL
    // 0xeee850: b.ne            #0xeee85c
    // 0xeee854: r0 = Instance_SizedBox
    //     0xeee854: ldr             x0, [PP, #0x4f58]  ; [pp+0x4f58] Obj!SizedBox@12b70e1
    // 0xeee858: b               #0xeee860
    // 0xeee85c: mov             x0, x1
    // 0xeee860: ret
    //     0xeee860: ret             
    // 0xeee864: EnterFrame
    //     0xeee864: stp             fp, lr, [SP, #-0x10]!
    //     0xeee868: mov             fp, SP
    // 0xeee86c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xeee86c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] bool persistentBottomSheetExtentChanged(dynamic, DraggableScrollableNotification) {
    // ** addr: 0xeee870, size: 0x160
    // 0xeee870: EnterFrame
    //     0xeee870: stp             fp, lr, [SP, #-0x10]!
    //     0xeee874: mov             fp, SP
    // 0xeee878: AllocStack(0x28)
    //     0xeee878: sub             SP, SP, #0x28
    // 0xeee87c: SetupParameters([dynamic _ /* r0 */])
    //     0xeee87c: ldr             x0, [fp, #0x18]
    //     0xeee880: ldur            w1, [x0, #0x17]
    //     0xeee884: add             x1, x1, HEAP, lsl #32
    //     0xeee888: stur            x1, [fp, #-8]
    // 0xeee88c: CheckStackOverflow
    //     0xeee88c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeee890: cmp             SP, x16
    //     0xeee894: b.ls            #0xeee9bc
    // 0xeee898: r1 = 1
    //     0xeee898: mov             x1, #1
    // 0xeee89c: r0 = AllocateContext()
    //     0xeee89c: bl              #0x13de838  ; AllocateContextStub
    // 0xeee8a0: mov             x1, x0
    // 0xeee8a4: ldur            x0, [fp, #-8]
    // 0xeee8a8: StoreField: r1->field_b = r0
    //     0xeee8a8: stur            w0, [x1, #0xb]
    // 0xeee8ac: ldr             x2, [fp, #0x10]
    // 0xeee8b0: StoreField: r1->field_f = r2
    //     0xeee8b0: stur            w2, [x1, #0xf]
    // 0xeee8b4: LoadField: d0 = r2->field_f
    //     0xeee8b4: ldur            d0, [x2, #0xf]
    // 0xeee8b8: LoadField: d1 = r2->field_1f
    //     0xeee8b8: ldur            d1, [x2, #0x1f]
    // 0xeee8bc: fsub            d2, d0, d1
    // 0xeee8c0: d0 = 0.000000
    //     0xeee8c0: ldr             d0, [PP, #0x5490]  ; [pp+0x5490] IMM: double(1e-10) from 0x3ddb7cdfd9d7bdbb
    // 0xeee8c4: fcmp            d2, d0
    // 0xeee8c8: b.le            #0xeee98c
    // 0xeee8cc: LoadField: r3 = r0->field_f
    //     0xeee8cc: ldur            w3, [x0, #0xf]
    // 0xeee8d0: DecompressPointer r3
    //     0xeee8d0: add             x3, x3, HEAP, lsl #32
    // 0xeee8d4: stur            x3, [fp, #-0x10]
    // 0xeee8d8: LoadField: r2 = r3->field_5f
    //     0xeee8d8: ldur            w2, [x3, #0x5f]
    // 0xeee8dc: DecompressPointer r2
    //     0xeee8dc: add             x2, x2, HEAP, lsl #32
    // 0xeee8e0: cmp             w2, NULL
    // 0xeee8e4: b.ne            #0xeee9ac
    // 0xeee8e8: mov             x2, x1
    // 0xeee8ec: r1 = Function '<anonymous closure>':.
    //     0xeee8ec: add             x1, PP, #0x84, lsl #12  ; [pp+0x84c28] AnonymousClosure: (0xeee9d0), in [package:flutter/src/material/scaffold.dart] ScaffoldState::_maybeBuildPersistentBottomSheet (0xeeda74)
    //     0xeee8f0: ldr             x1, [x1, #0xc28]
    // 0xeee8f4: r0 = AllocateClosure()
    //     0xeee8f4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xeee8f8: stur            x0, [fp, #-0x18]
    // 0xeee8fc: r0 = LocalHistoryEntry()
    //     0xeee8fc: bl              #0xc3b58c  ; AllocateLocalHistoryEntryStub -> LocalHistoryEntry (size=0x14)
    // 0xeee900: mov             x1, x0
    // 0xeee904: ldur            x0, [fp, #-0x18]
    // 0xeee908: StoreField: r1->field_7 = r0
    //     0xeee908: stur            w0, [x1, #7]
    // 0xeee90c: r0 = true
    //     0xeee90c: add             x0, NULL, #0x20  ; true
    // 0xeee910: StoreField: r1->field_f = r0
    //     0xeee910: stur            w0, [x1, #0xf]
    // 0xeee914: mov             x0, x1
    // 0xeee918: ldur            x1, [fp, #-0x10]
    // 0xeee91c: StoreField: r1->field_5f = r0
    //     0xeee91c: stur            w0, [x1, #0x5f]
    //     0xeee920: ldurb           w16, [x1, #-1]
    //     0xeee924: ldurb           w17, [x0, #-1]
    //     0xeee928: and             x16, x17, x16, lsr #2
    //     0xeee92c: tst             x16, HEAP, lsr #32
    //     0xeee930: b.eq            #0xeee938
    //     0xeee934: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xeee938: LoadField: r0 = r1->field_f
    //     0xeee938: ldur            w0, [x1, #0xf]
    // 0xeee93c: DecompressPointer r0
    //     0xeee93c: add             x0, x0, HEAP, lsl #32
    // 0xeee940: cmp             w0, NULL
    // 0xeee944: b.eq            #0xeee9c4
    // 0xeee948: r16 = <Object?>
    //     0xeee948: ldr             x16, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0xeee94c: stp             x0, x16, [SP]
    // 0xeee950: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xeee950: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xeee954: r0 = of()
    //     0xeee954: bl              #0xbfcc54  ; [package:flutter/src/widgets/routes.dart] ModalRoute::of
    // 0xeee958: cmp             w0, NULL
    // 0xeee95c: b.eq            #0xeee9c8
    // 0xeee960: ldur            x1, [fp, #-8]
    // 0xeee964: LoadField: r2 = r1->field_f
    //     0xeee964: ldur            w2, [x1, #0xf]
    // 0xeee968: DecompressPointer r2
    //     0xeee968: add             x2, x2, HEAP, lsl #32
    // 0xeee96c: LoadField: r1 = r2->field_5f
    //     0xeee96c: ldur            w1, [x2, #0x5f]
    // 0xeee970: DecompressPointer r1
    //     0xeee970: add             x1, x1, HEAP, lsl #32
    // 0xeee974: cmp             w1, NULL
    // 0xeee978: b.eq            #0xeee9cc
    // 0xeee97c: mov             x2, x1
    // 0xeee980: mov             x1, x0
    // 0xeee984: r0 = addLocalHistoryEntry()
    //     0xeee984: bl              #0xc3b418  ; [dart:mixin_deduplication] _MixinApplication12&TransitionRoute&LocalHistoryRoute::addLocalHistoryEntry
    // 0xeee988: b               #0xeee9ac
    // 0xeee98c: mov             x1, x0
    // 0xeee990: LoadField: r0 = r1->field_f
    //     0xeee990: ldur            w0, [x1, #0xf]
    // 0xeee994: DecompressPointer r0
    //     0xeee994: add             x0, x0, HEAP, lsl #32
    // 0xeee998: LoadField: r1 = r0->field_5f
    //     0xeee998: ldur            w1, [x0, #0x5f]
    // 0xeee99c: DecompressPointer r1
    //     0xeee99c: add             x1, x1, HEAP, lsl #32
    // 0xeee9a0: cmp             w1, NULL
    // 0xeee9a4: b.eq            #0xeee9ac
    // 0xeee9a8: r0 = remove()
    //     0xeee9a8: bl              #0xeee288  ; [package:flutter/src/widgets/routes.dart] LocalHistoryEntry::remove
    // 0xeee9ac: r0 = false
    //     0xeee9ac: add             x0, NULL, #0x30  ; false
    // 0xeee9b0: LeaveFrame
    //     0xeee9b0: mov             SP, fp
    //     0xeee9b4: ldp             fp, lr, [SP], #0x10
    // 0xeee9b8: ret
    //     0xeee9b8: ret             
    // 0xeee9bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeee9bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeee9c0: b               #0xeee898
    // 0xeee9c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xeee9c4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xeee9c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xeee9c8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xeee9cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xeee9cc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xeee9d0, size: 0xc0
    // 0xeee9d0: EnterFrame
    //     0xeee9d0: stp             fp, lr, [SP, #-0x10]!
    //     0xeee9d4: mov             fp, SP
    // 0xeee9d8: AllocStack(0x10)
    //     0xeee9d8: sub             SP, SP, #0x10
    // 0xeee9dc: SetupParameters([dynamic _ /* r0 */])
    //     0xeee9dc: ldr             x0, [fp, #0x10]
    //     0xeee9e0: ldur            w2, [x0, #0x17]
    //     0xeee9e4: add             x2, x2, HEAP, lsl #32
    //     0xeee9e8: stur            x2, [fp, #-8]
    // 0xeee9ec: CheckStackOverflow
    //     0xeee9ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeee9f0: cmp             SP, x16
    //     0xeee9f4: b.ls            #0xeeea7c
    // 0xeee9f8: LoadField: r0 = r2->field_f
    //     0xeee9f8: ldur            w0, [x2, #0xf]
    // 0xeee9fc: DecompressPointer r0
    //     0xeee9fc: add             x0, x0, HEAP, lsl #32
    // 0xeeea00: LoadField: r1 = r0->field_27
    //     0xeeea00: ldur            w1, [x0, #0x27]
    // 0xeeea04: DecompressPointer r1
    //     0xeeea04: add             x1, x1, HEAP, lsl #32
    // 0xeeea08: r0 = reset()
    //     0xeeea08: bl              #0xeeea90  ; [package:flutter/src/widgets/draggable_scrollable_sheet.dart] DraggableScrollableActuator::reset
    // 0xeeea0c: ldur            x0, [fp, #-8]
    // 0xeeea10: LoadField: r3 = r0->field_b
    //     0xeeea10: ldur            w3, [x0, #0xb]
    // 0xeeea14: DecompressPointer r3
    //     0xeeea14: add             x3, x3, HEAP, lsl #32
    // 0xeeea18: stur            x3, [fp, #-0x10]
    // 0xeeea1c: LoadField: r1 = r3->field_f
    //     0xeeea1c: ldur            w1, [x3, #0xf]
    // 0xeeea20: DecompressPointer r1
    //     0xeeea20: add             x1, x1, HEAP, lsl #32
    // 0xeeea24: r2 = false
    //     0xeeea24: add             x2, NULL, #0x30  ; false
    // 0xeeea28: d0 = 0.000000
    //     0xeeea28: eor             v0.16b, v0.16b, v0.16b
    // 0xeeea2c: r0 = showBodyScrim()
    //     0xeeea2c: bl              #0xdfc020  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::showBodyScrim
    // 0xeeea30: ldur            x0, [fp, #-0x10]
    // 0xeeea34: LoadField: r1 = r0->field_f
    //     0xeeea34: ldur            w1, [x0, #0xf]
    // 0xeeea38: DecompressPointer r1
    //     0xeeea38: add             x1, x1, HEAP, lsl #32
    // 0xeeea3c: LoadField: r2 = r1->field_73
    //     0xeeea3c: ldur            w2, [x1, #0x73]
    // 0xeeea40: DecompressPointer r2
    //     0xeeea40: add             x2, x2, HEAP, lsl #32
    // 0xeeea44: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xeeea48: cmp             w2, w16
    // 0xeeea4c: b.eq            #0xeeea84
    // 0xeeea50: mov             x1, x2
    // 0xeeea54: r2 = 1.000000
    //     0xeeea54: ldr             x2, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xeeea58: r0 = value=()
    //     0xeeea58: bl              #0x829534  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0xeeea5c: ldur            x1, [fp, #-0x10]
    // 0xeeea60: LoadField: r2 = r1->field_f
    //     0xeeea60: ldur            w2, [x1, #0xf]
    // 0xeeea64: DecompressPointer r2
    //     0xeeea64: add             x2, x2, HEAP, lsl #32
    // 0xeeea68: StoreField: r2->field_5f = rNULL
    //     0xeeea68: stur            NULL, [x2, #0x5f]
    // 0xeeea6c: r0 = Null
    //     0xeeea6c: mov             x0, NULL
    // 0xeeea70: LeaveFrame
    //     0xeeea70: mov             SP, fp
    //     0xeeea74: ldp             fp, lr, [SP], #0x10
    // 0xeeea78: ret
    //     0xeeea78: ret             
    // 0xeeea7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeeea7c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeeea80: b               #0xeee9f8
    // 0xeeea84: r9 = _floatingActionButtonVisibilityController
    //     0xeeea84: add             x9, PP, #0x84, lsl #12  ; [pp+0x84b68] Field <ScaffoldState._floatingActionButtonVisibilityController@89420462>: late (offset: 0x74)
    //     0xeeea88: ldr             x9, [x9, #0xb68]
    // 0xeeea8c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xeeea8c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf3d570, size: 0x140
    // 0xf3d570: EnterFrame
    //     0xf3d570: stp             fp, lr, [SP, #-0x10]!
    //     0xf3d574: mov             fp, SP
    // 0xf3d578: AllocStack(0x28)
    //     0xf3d578: sub             SP, SP, #0x28
    // 0xf3d57c: SetupParameters(ScaffoldState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xf3d57c: mov             x4, x1
    //     0xf3d580: mov             x3, x2
    //     0xf3d584: stur            x1, [fp, #-8]
    //     0xf3d588: stur            x2, [fp, #-0x10]
    // 0xf3d58c: CheckStackOverflow
    //     0xf3d58c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3d590: cmp             SP, x16
    //     0xf3d594: b.ls            #0xf3d69c
    // 0xf3d598: mov             x0, x3
    // 0xf3d59c: r2 = Null
    //     0xf3d59c: mov             x2, NULL
    // 0xf3d5a0: r1 = Null
    //     0xf3d5a0: mov             x1, NULL
    // 0xf3d5a4: r4 = 60
    //     0xf3d5a4: mov             x4, #0x3c
    // 0xf3d5a8: branchIfSmi(r0, 0xf3d5b4)
    //     0xf3d5a8: tbz             w0, #0, #0xf3d5b4
    // 0xf3d5ac: r4 = LoadClassIdInstr(r0)
    //     0xf3d5ac: ldur            x4, [x0, #-1]
    //     0xf3d5b0: ubfx            x4, x4, #0xc, #0x14
    // 0xf3d5b4: r17 = 6437
    //     0xf3d5b4: mov             x17, #0x1925
    // 0xf3d5b8: cmp             x4, x17
    // 0xf3d5bc: b.eq            #0xf3d5d4
    // 0xf3d5c0: r8 = Scaffold
    //     0xf3d5c0: add             x8, PP, #0x84, lsl #12  ; [pp+0x84cb8] Type: Scaffold
    //     0xf3d5c4: ldr             x8, [x8, #0xcb8]
    // 0xf3d5c8: r3 = Null
    //     0xf3d5c8: add             x3, PP, #0x84, lsl #12  ; [pp+0x84cc0] Null
    //     0xf3d5cc: ldr             x3, [x3, #0xcc0]
    // 0xf3d5d0: r0 = Scaffold()
    //     0xf3d5d0: bl              #0x8d13e4  ; IsType_Scaffold_Stub
    // 0xf3d5d4: ldur            x1, [fp, #-8]
    // 0xf3d5d8: ldur            x2, [fp, #-0x10]
    // 0xf3d5dc: r0 = didUpdateWidget()
    //     0xf3d5dc: bl              #0xf3d778  ; [dart:mixin_deduplication] _MixinApplication101&State&TickerProviderStateMixin&RestorationMixin::didUpdateWidget
    // 0xf3d5e0: ldur            x1, [fp, #-8]
    // 0xf3d5e4: LoadField: r0 = r1->field_b
    //     0xf3d5e4: ldur            w0, [x1, #0xb]
    // 0xf3d5e8: DecompressPointer r0
    //     0xf3d5e8: add             x0, x0, HEAP, lsl #32
    // 0xf3d5ec: cmp             w0, NULL
    // 0xf3d5f0: b.eq            #0xf3d6a4
    // 0xf3d5f4: LoadField: r2 = r0->field_53
    //     0xf3d5f4: ldur            w2, [x0, #0x53]
    // 0xf3d5f8: DecompressPointer r2
    //     0xf3d5f8: add             x2, x2, HEAP, lsl #32
    // 0xf3d5fc: ldur            x0, [fp, #-0x10]
    // 0xf3d600: LoadField: r3 = r0->field_53
    //     0xf3d600: ldur            w3, [x0, #0x53]
    // 0xf3d604: DecompressPointer r3
    //     0xf3d604: add             x3, x3, HEAP, lsl #32
    // 0xf3d608: stur            x3, [fp, #-0x18]
    // 0xf3d60c: r0 = LoadClassIdInstr(r2)
    //     0xf3d60c: ldur            x0, [x2, #-1]
    //     0xf3d610: ubfx            x0, x0, #0xc, #0x14
    // 0xf3d614: stp             x3, x2, [SP]
    // 0xf3d618: mov             lr, x0
    // 0xf3d61c: ldr             lr, [x21, lr, lsl #3]
    // 0xf3d620: blr             lr
    // 0xf3d624: tbz             w0, #4, #0xf3d678
    // 0xf3d628: ldur            x0, [fp, #-8]
    // 0xf3d62c: LoadField: r1 = r0->field_b
    //     0xf3d62c: ldur            w1, [x0, #0xb]
    // 0xf3d630: DecompressPointer r1
    //     0xf3d630: add             x1, x1, HEAP, lsl #32
    // 0xf3d634: cmp             w1, NULL
    // 0xf3d638: b.eq            #0xf3d6a8
    // 0xf3d63c: LoadField: r2 = r1->field_53
    //     0xf3d63c: ldur            w2, [x1, #0x53]
    // 0xf3d640: DecompressPointer r2
    //     0xf3d640: add             x2, x2, HEAP, lsl #32
    // 0xf3d644: cmp             w2, NULL
    // 0xf3d648: b.ne            #0xf3d658
    // 0xf3d64c: mov             x1, x0
    // 0xf3d650: r0 = _closeCurrentBottomSheet()
    //     0xf3d650: bl              #0xf3d71c  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::_closeCurrentBottomSheet
    // 0xf3d654: b               #0xf3d678
    // 0xf3d658: ldur            x0, [fp, #-0x18]
    // 0xf3d65c: cmp             w0, NULL
    // 0xf3d660: b.ne            #0xf3d670
    // 0xf3d664: ldur            x1, [fp, #-8]
    // 0xf3d668: r0 = _maybeBuildPersistentBottomSheet()
    //     0xf3d668: bl              #0xeeda74  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::_maybeBuildPersistentBottomSheet
    // 0xf3d66c: b               #0xf3d678
    // 0xf3d670: ldur            x1, [fp, #-8]
    // 0xf3d674: r0 = _updatePersistentBottomSheet()
    //     0xf3d674: bl              #0xf3d6b0  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::_updatePersistentBottomSheet
    // 0xf3d678: ldur            x1, [fp, #-8]
    // 0xf3d67c: LoadField: r2 = r1->field_b
    //     0xf3d67c: ldur            w2, [x1, #0xb]
    // 0xf3d680: DecompressPointer r2
    //     0xf3d680: add             x2, x2, HEAP, lsl #32
    // 0xf3d684: cmp             w2, NULL
    // 0xf3d688: b.eq            #0xf3d6ac
    // 0xf3d68c: r0 = Null
    //     0xf3d68c: mov             x0, NULL
    // 0xf3d690: LeaveFrame
    //     0xf3d690: mov             SP, fp
    //     0xf3d694: ldp             fp, lr, [SP], #0x10
    // 0xf3d698: ret
    //     0xf3d698: ret             
    // 0xf3d69c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3d69c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3d6a0: b               #0xf3d598
    // 0xf3d6a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3d6a4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3d6a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3d6a8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3d6ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3d6ac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updatePersistentBottomSheet(/* No info */) {
    // ** addr: 0xf3d6b0, size: 0x6c
    // 0xf3d6b0: EnterFrame
    //     0xf3d6b0: stp             fp, lr, [SP, #-0x10]!
    //     0xf3d6b4: mov             fp, SP
    // 0xf3d6b8: AllocStack(0x8)
    //     0xf3d6b8: sub             SP, SP, #8
    // 0xf3d6bc: CheckStackOverflow
    //     0xf3d6bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3d6c0: cmp             SP, x16
    //     0xf3d6c4: b.ls            #0xf3d710
    // 0xf3d6c8: LoadField: r0 = r1->field_5b
    //     0xf3d6c8: ldur            w0, [x1, #0x5b]
    // 0xf3d6cc: DecompressPointer r0
    //     0xf3d6cc: add             x0, x0, HEAP, lsl #32
    // 0xf3d6d0: mov             x1, x0
    // 0xf3d6d4: r0 = currentState()
    //     0xf3d6d4: bl              #0x8591f8  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0xf3d6d8: stur            x0, [fp, #-8]
    // 0xf3d6dc: cmp             w0, NULL
    // 0xf3d6e0: b.eq            #0xf3d718
    // 0xf3d6e4: r1 = Function '<anonymous closure>':.
    //     0xf3d6e4: add             x1, PP, #0x84, lsl #12  ; [pp+0x84cd0] Function: [dart:ui] Shader::Shader._ (0x13cf838)
    //     0xf3d6e8: ldr             x1, [x1, #0xcd0]
    // 0xf3d6ec: r2 = Null
    //     0xf3d6ec: mov             x2, NULL
    // 0xf3d6f0: r0 = AllocateClosure()
    //     0xf3d6f0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf3d6f4: ldur            x1, [fp, #-8]
    // 0xf3d6f8: mov             x2, x0
    // 0xf3d6fc: r0 = setState()
    //     0xf3d6fc: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xf3d700: r0 = Null
    //     0xf3d700: mov             x0, NULL
    // 0xf3d704: LeaveFrame
    //     0xf3d704: mov             SP, fp
    //     0xf3d708: ldp             fp, lr, [SP], #0x10
    // 0xf3d70c: ret
    //     0xf3d70c: ret             
    // 0xf3d710: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3d710: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3d714: b               #0xf3d6c8
    // 0xf3d718: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3d718: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _closeCurrentBottomSheet(/* No info */) {
    // ** addr: 0xf3d71c, size: 0x5c
    // 0xf3d71c: EnterFrame
    //     0xf3d71c: stp             fp, lr, [SP, #-0x10]!
    //     0xf3d720: mov             fp, SP
    // 0xf3d724: AllocStack(0x8)
    //     0xf3d724: sub             SP, SP, #8
    // 0xf3d728: CheckStackOverflow
    //     0xf3d728: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3d72c: cmp             SP, x16
    //     0xf3d730: b.ls            #0xf3d770
    // 0xf3d734: LoadField: r0 = r1->field_57
    //     0xf3d734: ldur            w0, [x1, #0x57]
    // 0xf3d738: DecompressPointer r0
    //     0xf3d738: add             x0, x0, HEAP, lsl #32
    // 0xf3d73c: cmp             w0, NULL
    // 0xf3d740: b.eq            #0xf3d760
    // 0xf3d744: LoadField: r1 = r0->field_13
    //     0xf3d744: ldur            w1, [x0, #0x13]
    // 0xf3d748: DecompressPointer r1
    //     0xf3d748: add             x1, x1, HEAP, lsl #32
    // 0xf3d74c: str             x1, [SP]
    // 0xf3d750: mov             x0, x1
    // 0xf3d754: ClosureCall
    //     0xf3d754: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xf3d758: ldur            x2, [x0, #0x1f]
    //     0xf3d75c: blr             x2
    // 0xf3d760: r0 = Null
    //     0xf3d760: mov             x0, NULL
    // 0xf3d764: LeaveFrame
    //     0xf3d764: mov             SP, fp
    //     0xf3d768: ldp             fp, lr, [SP], #0x10
    // 0xf3d76c: ret
    //     0xf3d76c: ret             
    // 0xf3d770: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3d770: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3d774: b               #0xf3d734
  }
  _ initState(/* No info */) {
    // ** addr: 0xf7b550, size: 0x284
    // 0xf7b550: EnterFrame
    //     0xf7b550: stp             fp, lr, [SP, #-0x10]!
    //     0xf7b554: mov             fp, SP
    // 0xf7b558: AllocStack(0x30)
    //     0xf7b558: sub             SP, SP, #0x30
    // 0xf7b55c: SetupParameters(ScaffoldState this /* r1 => r2, fp-0x8 */)
    //     0xf7b55c: mov             x2, x1
    //     0xf7b560: stur            x1, [fp, #-8]
    // 0xf7b564: CheckStackOverflow
    //     0xf7b564: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf7b568: cmp             SP, x16
    //     0xf7b56c: b.ls            #0xf7b7bc
    // 0xf7b570: LoadField: r0 = r2->field_f
    //     0xf7b570: ldur            w0, [x2, #0xf]
    // 0xf7b574: DecompressPointer r0
    //     0xf7b574: add             x0, x0, HEAP, lsl #32
    // 0xf7b578: cmp             w0, NULL
    // 0xf7b57c: b.eq            #0xf7b7c4
    // 0xf7b580: r0 = _ScaffoldGeometryNotifier()
    //     0xf7b580: bl              #0xf7b7d4  ; Allocate_ScaffoldGeometryNotifierStub -> _ScaffoldGeometryNotifier (size=0x2c)
    // 0xf7b584: mov             x1, x0
    // 0xf7b588: r0 = Instance_ScaffoldGeometry
    //     0xf7b588: add             x0, PP, #0x84, lsl #12  ; [pp+0x84cd8] Obj!ScaffoldGeometry@129e931
    //     0xf7b58c: ldr             x0, [x0, #0xcd8]
    // 0xf7b590: stur            x1, [fp, #-0x10]
    // 0xf7b594: StoreField: r1->field_27 = r0
    //     0xf7b594: stur            w0, [x1, #0x27]
    // 0xf7b598: StoreField: r1->field_7 = rZR
    //     0xf7b598: stur            xzr, [x1, #7]
    // 0xf7b59c: StoreField: r1->field_13 = rZR
    //     0xf7b59c: stur            xzr, [x1, #0x13]
    // 0xf7b5a0: StoreField: r1->field_1b = rZR
    //     0xf7b5a0: stur            xzr, [x1, #0x1b]
    // 0xf7b5a4: r0 = LoadStaticField(0x45c)
    //     0xf7b5a4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf7b5a8: ldr             x0, [x0, #0x8b8]
    // 0xf7b5ac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf7b5b0: cmp             w0, w16
    // 0xf7b5b4: b.ne            #0xf7b5c0
    // 0xf7b5b8: r2 = _emptyListeners
    //     0xf7b5b8: ldr             x2, [PP, #0x17f0]  ; [pp+0x17f0] Field <ChangeNotifier._emptyListeners@28329750>: static late final (offset: 0x45c)
    // 0xf7b5bc: r0 = InitLateFinalStaticField()
    //     0xf7b5bc: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xf7b5c0: mov             x1, x0
    // 0xf7b5c4: ldur            x0, [fp, #-0x10]
    // 0xf7b5c8: StoreField: r0->field_f = r1
    //     0xf7b5c8: stur            w1, [x0, #0xf]
    // 0xf7b5cc: ldur            x3, [fp, #-8]
    // 0xf7b5d0: StoreField: r3->field_77 = r0
    //     0xf7b5d0: stur            w0, [x3, #0x77]
    //     0xf7b5d4: ldurb           w16, [x3, #-1]
    //     0xf7b5d8: ldurb           w17, [x0, #-1]
    //     0xf7b5dc: and             x16, x17, x16, lsr #2
    //     0xf7b5e0: tst             x16, HEAP, lsr #32
    //     0xf7b5e4: b.eq            #0xf7b5ec
    //     0xf7b5e8: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xf7b5ec: LoadField: r0 = r3->field_b
    //     0xf7b5ec: ldur            w0, [x3, #0xb]
    // 0xf7b5f0: DecompressPointer r0
    //     0xf7b5f0: add             x0, x0, HEAP, lsl #32
    // 0xf7b5f4: cmp             w0, NULL
    // 0xf7b5f8: b.eq            #0xf7b7c8
    // 0xf7b5fc: r0 = Instance__EndFloatFabLocation
    //     0xf7b5fc: add             x0, PP, #0x84, lsl #12  ; [pp+0x84b88] Obj!_EndFloatFabLocation@129ecf1
    //     0xf7b600: ldr             x0, [x0, #0xb88]
    // 0xf7b604: StoreField: r3->field_6f = r0
    //     0xf7b604: stur            w0, [x3, #0x6f]
    // 0xf7b608: r1 = Instance__ScalingFabMotionAnimator
    //     0xf7b608: add             x1, PP, #0x84, lsl #12  ; [pp+0x84b18] Obj!_ScalingFabMotionAnimator@129ece1
    //     0xf7b60c: ldr             x1, [x1, #0xb18]
    // 0xf7b610: StoreField: r3->field_67 = r1
    //     0xf7b610: stur            w1, [x3, #0x67]
    // 0xf7b614: StoreField: r3->field_6b = r0
    //     0xf7b614: stur            w0, [x3, #0x6b]
    // 0xf7b618: r1 = Instance_Duration
    //     0xf7b618: add             x1, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xf7b61c: ldr             x1, [x1, #0x318]
    // 0xf7b620: r2 = 4
    //     0xf7b620: mov             x2, #4
    // 0xf7b624: r0 = *()
    //     0xf7b624: bl              #0x7dd190  ; [dart:core] Duration::*
    // 0xf7b628: r1 = <double>
    //     0xf7b628: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf7b62c: stur            x0, [fp, #-0x10]
    // 0xf7b630: r0 = AnimationController()
    //     0xf7b630: bl              #0x87522c  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0xf7b634: stur            x0, [fp, #-0x18]
    // 0xf7b638: r16 = 1.000000
    //     0xf7b638: ldr             x16, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xf7b63c: ldur            lr, [fp, #-0x10]
    // 0xf7b640: stp             lr, x16, [SP]
    // 0xf7b644: mov             x1, x0
    // 0xf7b648: ldur            x2, [fp, #-8]
    // 0xf7b64c: r4 = const [0, 0x4, 0x2, 0x2, duration, 0x3, value, 0x2, null]
    //     0xf7b64c: add             x4, PP, #0x84, lsl #12  ; [pp+0x84ce0] List(9) [0, 0x4, 0x2, 0x2, "duration", 0x3, "value", 0x2, Null]
    //     0xf7b650: ldr             x4, [x4, #0xce0]
    // 0xf7b654: r0 = AnimationController()
    //     0xf7b654: bl              #0x874ea4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0xf7b658: ldur            x0, [fp, #-0x18]
    // 0xf7b65c: ldur            x2, [fp, #-8]
    // 0xf7b660: StoreField: r2->field_63 = r0
    //     0xf7b660: stur            w0, [x2, #0x63]
    //     0xf7b664: ldurb           w16, [x2, #-1]
    //     0xf7b668: ldurb           w17, [x0, #-1]
    //     0xf7b66c: and             x16, x17, x16, lsr #2
    //     0xf7b670: tst             x16, HEAP, lsr #32
    //     0xf7b674: b.eq            #0xf7b67c
    //     0xf7b678: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf7b67c: r1 = <double>
    //     0xf7b67c: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf7b680: r0 = AnimationController()
    //     0xf7b680: bl              #0x87522c  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0xf7b684: stur            x0, [fp, #-0x10]
    // 0xf7b688: r16 = Instance_Duration
    //     0xf7b688: add             x16, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xf7b68c: ldr             x16, [x16, #0x318]
    // 0xf7b690: str             x16, [SP]
    // 0xf7b694: mov             x1, x0
    // 0xf7b698: ldur            x2, [fp, #-8]
    // 0xf7b69c: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0xf7b69c: add             x4, PP, #0x15, lsl #12  ; [pp+0x155a0] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0xf7b6a0: ldr             x4, [x4, #0x5a0]
    // 0xf7b6a4: r0 = AnimationController()
    //     0xf7b6a4: bl              #0x874ea4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0xf7b6a8: ldur            x0, [fp, #-0x10]
    // 0xf7b6ac: ldur            x2, [fp, #-8]
    // 0xf7b6b0: StoreField: r2->field_73 = r0
    //     0xf7b6b0: stur            w0, [x2, #0x73]
    //     0xf7b6b4: ldurb           w16, [x2, #-1]
    //     0xf7b6b8: ldurb           w17, [x0, #-1]
    //     0xf7b6bc: and             x16, x17, x16, lsr #2
    //     0xf7b6c0: tst             x16, HEAP, lsr #32
    //     0xf7b6c4: b.eq            #0xf7b6cc
    //     0xf7b6c8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf7b6cc: r1 = <double>
    //     0xf7b6cc: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf7b6d0: r0 = AnimationController()
    //     0xf7b6d0: bl              #0x87522c  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0xf7b6d4: mov             x1, x0
    // 0xf7b6d8: ldur            x2, [fp, #-8]
    // 0xf7b6dc: stur            x0, [fp, #-0x10]
    // 0xf7b6e0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xf7b6e0: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xf7b6e4: r0 = AnimationController()
    //     0xf7b6e4: bl              #0x874ea4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0xf7b6e8: ldur            x0, [fp, #-0x10]
    // 0xf7b6ec: ldur            x2, [fp, #-8]
    // 0xf7b6f0: StoreField: r2->field_7b = r0
    //     0xf7b6f0: stur            w0, [x2, #0x7b]
    //     0xf7b6f4: ldurb           w16, [x2, #-1]
    //     0xf7b6f8: ldurb           w17, [x0, #-1]
    //     0xf7b6fc: and             x16, x17, x16, lsr #2
    //     0xf7b700: tst             x16, HEAP, lsr #32
    //     0xf7b704: b.eq            #0xf7b70c
    //     0xf7b708: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf7b70c: LoadField: r0 = r2->field_b
    //     0xf7b70c: ldur            w0, [x2, #0xb]
    // 0xf7b710: DecompressPointer r0
    //     0xf7b710: add             x0, x0, HEAP, lsl #32
    // 0xf7b714: cmp             w0, NULL
    // 0xf7b718: b.eq            #0xf7b7cc
    // 0xf7b71c: r0 = LoadStaticField(0x6a0)
    //     0xf7b71c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf7b720: ldr             x0, [x0, #0xd40]
    // 0xf7b724: cmp             w0, NULL
    // 0xf7b728: b.eq            #0xf7b7d0
    // 0xf7b72c: LoadField: r3 = r0->field_f3
    //     0xf7b72c: ldur            w3, [x0, #0xf3]
    // 0xf7b730: DecompressPointer r3
    //     0xf7b730: add             x3, x3, HEAP, lsl #32
    // 0xf7b734: stur            x3, [fp, #-0x10]
    // 0xf7b738: LoadField: r0 = r3->field_b
    //     0xf7b738: ldur            w0, [x3, #0xb]
    // 0xf7b73c: LoadField: r1 = r3->field_f
    //     0xf7b73c: ldur            w1, [x3, #0xf]
    // 0xf7b740: DecompressPointer r1
    //     0xf7b740: add             x1, x1, HEAP, lsl #32
    // 0xf7b744: LoadField: r4 = r1->field_b
    //     0xf7b744: ldur            w4, [x1, #0xb]
    // 0xf7b748: r5 = LoadInt32Instr(r0)
    //     0xf7b748: sbfx            x5, x0, #1, #0x1f
    // 0xf7b74c: stur            x5, [fp, #-0x20]
    // 0xf7b750: r0 = LoadInt32Instr(r4)
    //     0xf7b750: sbfx            x0, x4, #1, #0x1f
    // 0xf7b754: cmp             x5, x0
    // 0xf7b758: b.ne            #0xf7b764
    // 0xf7b75c: mov             x1, x3
    // 0xf7b760: r0 = _growToNextCapacity()
    //     0xf7b760: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xf7b764: ldur            x2, [fp, #-0x10]
    // 0xf7b768: ldur            x3, [fp, #-0x20]
    // 0xf7b76c: add             x4, x3, #1
    // 0xf7b770: lsl             x5, x4, #1
    // 0xf7b774: StoreField: r2->field_b = r5
    //     0xf7b774: stur            w5, [x2, #0xb]
    // 0xf7b778: LoadField: r1 = r2->field_f
    //     0xf7b778: ldur            w1, [x2, #0xf]
    // 0xf7b77c: DecompressPointer r1
    //     0xf7b77c: add             x1, x1, HEAP, lsl #32
    // 0xf7b780: ldur            x0, [fp, #-8]
    // 0xf7b784: ArrayStore: r1[r3] = r0  ; List_4
    //     0xf7b784: add             x25, x1, x3, lsl #2
    //     0xf7b788: add             x25, x25, #0xf
    //     0xf7b78c: str             w0, [x25]
    //     0xf7b790: tbz             w0, #0, #0xf7b7ac
    //     0xf7b794: ldurb           w16, [x1, #-1]
    //     0xf7b798: ldurb           w17, [x0, #-1]
    //     0xf7b79c: and             x16, x17, x16, lsr #2
    //     0xf7b7a0: tst             x16, HEAP, lsr #32
    //     0xf7b7a4: b.eq            #0xf7b7ac
    //     0xf7b7a8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xf7b7ac: r0 = Null
    //     0xf7b7ac: mov             x0, NULL
    // 0xf7b7b0: LeaveFrame
    //     0xf7b7b0: mov             SP, fp
    //     0xf7b7b4: ldp             fp, lr, [SP], #0x10
    // 0xf7b7b8: ret
    //     0xf7b7b8: ret             
    // 0xf7b7bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf7b7bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf7b7c0: b               #0xf7b570
    // 0xf7b7c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf7b7c4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf7b7c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf7b7c8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf7b7cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf7b7cc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf7b7d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf7b7d0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ ScaffoldState(/* No info */) {
    // ** addr: 0xfa2b8c, size: 0x234
    // 0xfa2b8c: EnterFrame
    //     0xfa2b8c: stp             fp, lr, [SP, #-0x10]!
    //     0xfa2b90: mov             fp, SP
    // 0xfa2b94: AllocStack(0x28)
    //     0xfa2b94: sub             SP, SP, #0x28
    // 0xfa2b98: ldr             x2, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa2b9c: r0 = false
    //     0xfa2b9c: add             x0, NULL, #0x30  ; false
    // 0xfa2ba0: mov             x3, x1
    // 0xfa2ba4: stur            x1, [fp, #-8]
    // 0xfa2ba8: CheckStackOverflow
    //     0xfa2ba8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa2bac: cmp             SP, x16
    //     0xfa2bb0: b.ls            #0xfa2db8
    // 0xfa2bb4: StoreField: r3->field_37 = r2
    //     0xfa2bb4: stur            w2, [x3, #0x37]
    // 0xfa2bb8: StoreField: r3->field_63 = r2
    //     0xfa2bb8: stur            w2, [x3, #0x63]
    // 0xfa2bbc: StoreField: r3->field_67 = r2
    //     0xfa2bbc: stur            w2, [x3, #0x67]
    // 0xfa2bc0: StoreField: r3->field_73 = r2
    //     0xfa2bc0: stur            w2, [x3, #0x73]
    // 0xfa2bc4: StoreField: r3->field_77 = r2
    //     0xfa2bc4: stur            w2, [x3, #0x77]
    // 0xfa2bc8: StoreField: r3->field_7b = r2
    //     0xfa2bc8: stur            w2, [x3, #0x7b]
    // 0xfa2bcc: StoreField: r3->field_7f = r0
    //     0xfa2bcc: stur            w0, [x3, #0x7f]
    // 0xfa2bd0: r1 = <DrawerControllerState>
    //     0xfa2bd0: add             x1, PP, #0x26, lsl #12  ; [pp+0x26c50] TypeArguments: <DrawerControllerState>
    //     0xfa2bd4: ldr             x1, [x1, #0xc50]
    // 0xfa2bd8: r0 = LabeledGlobalKey()
    //     0xfa2bd8: bl              #0x856cf8  ; AllocateLabeledGlobalKeyStub -> LabeledGlobalKey<X0 bound State> (size=0x10)
    // 0xfa2bdc: ldur            x2, [fp, #-8]
    // 0xfa2be0: StoreField: r2->field_2b = r0
    //     0xfa2be0: stur            w0, [x2, #0x2b]
    //     0xfa2be4: ldurb           w16, [x2, #-1]
    //     0xfa2be8: ldurb           w17, [x0, #-1]
    //     0xfa2bec: and             x16, x17, x16, lsr #2
    //     0xfa2bf0: tst             x16, HEAP, lsr #32
    //     0xfa2bf4: b.eq            #0xfa2bfc
    //     0xfa2bf8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xfa2bfc: r1 = <DrawerControllerState>
    //     0xfa2bfc: add             x1, PP, #0x26, lsl #12  ; [pp+0x26c50] TypeArguments: <DrawerControllerState>
    //     0xfa2c00: ldr             x1, [x1, #0xc50]
    // 0xfa2c04: r0 = LabeledGlobalKey()
    //     0xfa2c04: bl              #0x856cf8  ; AllocateLabeledGlobalKeyStub -> LabeledGlobalKey<X0 bound State> (size=0x10)
    // 0xfa2c08: ldur            x2, [fp, #-8]
    // 0xfa2c0c: StoreField: r2->field_2f = r0
    //     0xfa2c0c: stur            w0, [x2, #0x2f]
    //     0xfa2c10: ldurb           w16, [x2, #-1]
    //     0xfa2c14: ldurb           w17, [x0, #-1]
    //     0xfa2c18: and             x16, x17, x16, lsr #2
    //     0xfa2c1c: tst             x16, HEAP, lsr #32
    //     0xfa2c20: b.eq            #0xfa2c28
    //     0xfa2c24: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xfa2c28: r1 = <State<StatefulWidget>>
    //     0xfa2c28: ldr             x1, [PP, #0x4df8]  ; [pp+0x4df8] TypeArguments: <State<StatefulWidget>>
    // 0xfa2c2c: r0 = LabeledGlobalKey()
    //     0xfa2c2c: bl              #0x856cf8  ; AllocateLabeledGlobalKeyStub -> LabeledGlobalKey<X0 bound State> (size=0x10)
    // 0xfa2c30: ldur            x2, [fp, #-8]
    // 0xfa2c34: StoreField: r2->field_33 = r0
    //     0xfa2c34: stur            w0, [x2, #0x33]
    //     0xfa2c38: ldurb           w16, [x2, #-1]
    //     0xfa2c3c: ldurb           w17, [x0, #-1]
    //     0xfa2c40: and             x16, x17, x16, lsr #2
    //     0xfa2c44: tst             x16, HEAP, lsr #32
    //     0xfa2c48: b.eq            #0xfa2c50
    //     0xfa2c4c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xfa2c50: r1 = <bool>
    //     0xfa2c50: ldr             x1, [PP, #0x1918]  ; [pp+0x1918] TypeArguments: <bool>
    // 0xfa2c54: r0 = RestorableBool()
    //     0xfa2c54: bl              #0xfa17fc  ; AllocateRestorableBoolStub -> RestorableBool (size=0x3c)
    // 0xfa2c58: mov             x1, x0
    // 0xfa2c5c: r0 = false
    //     0xfa2c5c: add             x0, NULL, #0x30  ; false
    // 0xfa2c60: stur            x1, [fp, #-0x10]
    // 0xfa2c64: StoreField: r1->field_37 = r0
    //     0xfa2c64: stur            w0, [x1, #0x37]
    // 0xfa2c68: StoreField: r1->field_27 = r0
    //     0xfa2c68: stur            w0, [x1, #0x27]
    // 0xfa2c6c: StoreField: r1->field_7 = rZR
    //     0xfa2c6c: stur            xzr, [x1, #7]
    // 0xfa2c70: StoreField: r1->field_13 = rZR
    //     0xfa2c70: stur            xzr, [x1, #0x13]
    // 0xfa2c74: StoreField: r1->field_1b = rZR
    //     0xfa2c74: stur            xzr, [x1, #0x1b]
    // 0xfa2c78: r0 = LoadStaticField(0x45c)
    //     0xfa2c78: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xfa2c7c: ldr             x0, [x0, #0x8b8]
    // 0xfa2c80: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa2c84: cmp             w0, w16
    // 0xfa2c88: b.ne            #0xfa2c94
    // 0xfa2c8c: r2 = _emptyListeners
    //     0xfa2c8c: ldr             x2, [PP, #0x17f0]  ; [pp+0x17f0] Field <ChangeNotifier._emptyListeners@28329750>: static late final (offset: 0x45c)
    // 0xfa2c90: r0 = InitLateFinalStaticField()
    //     0xfa2c90: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xfa2c94: mov             x2, x0
    // 0xfa2c98: ldur            x0, [fp, #-0x10]
    // 0xfa2c9c: stur            x2, [fp, #-0x18]
    // 0xfa2ca0: StoreField: r0->field_f = r2
    //     0xfa2ca0: stur            w2, [x0, #0xf]
    // 0xfa2ca4: ldur            x3, [fp, #-8]
    // 0xfa2ca8: StoreField: r3->field_3f = r0
    //     0xfa2ca8: stur            w0, [x3, #0x3f]
    //     0xfa2cac: ldurb           w16, [x3, #-1]
    //     0xfa2cb0: ldurb           w17, [x0, #-1]
    //     0xfa2cb4: and             x16, x17, x16, lsr #2
    //     0xfa2cb8: tst             x16, HEAP, lsr #32
    //     0xfa2cbc: b.eq            #0xfa2cc4
    //     0xfa2cc0: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xfa2cc4: r1 = <bool>
    //     0xfa2cc4: ldr             x1, [PP, #0x1918]  ; [pp+0x1918] TypeArguments: <bool>
    // 0xfa2cc8: r0 = RestorableBool()
    //     0xfa2cc8: bl              #0xfa17fc  ; AllocateRestorableBoolStub -> RestorableBool (size=0x3c)
    // 0xfa2ccc: mov             x1, x0
    // 0xfa2cd0: r0 = false
    //     0xfa2cd0: add             x0, NULL, #0x30  ; false
    // 0xfa2cd4: StoreField: r1->field_37 = r0
    //     0xfa2cd4: stur            w0, [x1, #0x37]
    // 0xfa2cd8: StoreField: r1->field_27 = r0
    //     0xfa2cd8: stur            w0, [x1, #0x27]
    // 0xfa2cdc: StoreField: r1->field_7 = rZR
    //     0xfa2cdc: stur            xzr, [x1, #7]
    // 0xfa2ce0: StoreField: r1->field_13 = rZR
    //     0xfa2ce0: stur            xzr, [x1, #0x13]
    // 0xfa2ce4: StoreField: r1->field_1b = rZR
    //     0xfa2ce4: stur            xzr, [x1, #0x1b]
    // 0xfa2ce8: ldur            x0, [fp, #-0x18]
    // 0xfa2cec: StoreField: r1->field_f = r0
    //     0xfa2cec: stur            w0, [x1, #0xf]
    // 0xfa2cf0: mov             x0, x1
    // 0xfa2cf4: ldur            x3, [fp, #-8]
    // 0xfa2cf8: StoreField: r3->field_43 = r0
    //     0xfa2cf8: stur            w0, [x3, #0x43]
    //     0xfa2cfc: ldurb           w16, [x3, #-1]
    //     0xfa2d00: ldurb           w17, [x0, #-1]
    //     0xfa2d04: and             x16, x17, x16, lsr #2
    //     0xfa2d08: tst             x16, HEAP, lsr #32
    //     0xfa2d0c: b.eq            #0xfa2d14
    //     0xfa2d10: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xfa2d14: r1 = <_StandardBottomSheet>
    //     0xfa2d14: add             x1, PP, #0x26, lsl #12  ; [pp+0x26c58] TypeArguments: <_StandardBottomSheet>
    //     0xfa2d18: ldr             x1, [x1, #0xc58]
    // 0xfa2d1c: r2 = 0
    //     0xfa2d1c: mov             x2, #0
    // 0xfa2d20: r0 = _GrowableList()
    //     0xfa2d20: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xfa2d24: ldur            x2, [fp, #-8]
    // 0xfa2d28: StoreField: r2->field_53 = r0
    //     0xfa2d28: stur            w0, [x2, #0x53]
    //     0xfa2d2c: ldurb           w16, [x2, #-1]
    //     0xfa2d30: ldurb           w17, [x0, #-1]
    //     0xfa2d34: and             x16, x17, x16, lsr #2
    //     0xfa2d38: tst             x16, HEAP, lsr #32
    //     0xfa2d3c: b.eq            #0xfa2d44
    //     0xfa2d40: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xfa2d44: r1 = <State<StatefulWidget>>
    //     0xfa2d44: ldr             x1, [PP, #0x4df8]  ; [pp+0x4df8] TypeArguments: <State<StatefulWidget>>
    // 0xfa2d48: r0 = LabeledGlobalKey()
    //     0xfa2d48: bl              #0x856cf8  ; AllocateLabeledGlobalKeyStub -> LabeledGlobalKey<X0 bound State> (size=0x10)
    // 0xfa2d4c: ldur            x1, [fp, #-8]
    // 0xfa2d50: StoreField: r1->field_5b = r0
    //     0xfa2d50: stur            w0, [x1, #0x5b]
    //     0xfa2d54: ldurb           w16, [x1, #-1]
    //     0xfa2d58: ldurb           w17, [x0, #-1]
    //     0xfa2d5c: and             x16, x17, x16, lsr #2
    //     0xfa2d60: tst             x16, HEAP, lsr #32
    //     0xfa2d64: b.eq            #0xfa2d6c
    //     0xfa2d68: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfa2d6c: r0 = true
    //     0xfa2d6c: add             x0, NULL, #0x20  ; true
    // 0xfa2d70: StoreField: r1->field_23 = r0
    //     0xfa2d70: stur            w0, [x1, #0x23]
    // 0xfa2d74: r16 = <RestorableProperty<Object?>, (dynamic this) => void?>
    //     0xfa2d74: add             x16, PP, #0x26, lsl #12  ; [pp+0x26c60] TypeArguments: <RestorableProperty<Object?>, (dynamic this) => void?>
    //     0xfa2d78: ldr             x16, [x16, #0xc60]
    // 0xfa2d7c: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0xfa2d80: stp             lr, x16, [SP]
    // 0xfa2d84: r0 = Map._fromLiteral()
    //     0xfa2d84: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xfa2d88: ldur            x1, [fp, #-8]
    // 0xfa2d8c: StoreField: r1->field_1f = r0
    //     0xfa2d8c: stur            w0, [x1, #0x1f]
    //     0xfa2d90: ldurb           w16, [x1, #-1]
    //     0xfa2d94: ldurb           w17, [x0, #-1]
    //     0xfa2d98: and             x16, x17, x16, lsr #2
    //     0xfa2d9c: tst             x16, HEAP, lsr #32
    //     0xfa2da0: b.eq            #0xfa2da8
    //     0xfa2da4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfa2da8: r0 = Null
    //     0xfa2da8: mov             x0, NULL
    // 0xfa2dac: LeaveFrame
    //     0xfa2dac: mov             SP, fp
    //     0xfa2db0: ldp             fp, lr, [SP], #0x10
    // 0xfa2db4: ret
    //     0xfa2db4: ret             
    // 0xfa2db8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa2db8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa2dbc: b               #0xfa2bb4
  }
  _ openEndDrawer(/* No info */) {
    // ** addr: 0xfae154, size: 0xec
    // 0xfae154: EnterFrame
    //     0xfae154: stp             fp, lr, [SP, #-0x10]!
    //     0xfae158: mov             fp, SP
    // 0xfae15c: AllocStack(0x18)
    //     0xfae15c: sub             SP, SP, #0x18
    // 0xfae160: SetupParameters(ScaffoldState this /* r1 => r0, fp-0x10 */)
    //     0xfae160: mov             x0, x1
    //     0xfae164: stur            x1, [fp, #-0x10]
    // 0xfae168: CheckStackOverflow
    //     0xfae168: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfae16c: cmp             SP, x16
    //     0xfae170: b.ls            #0xfae234
    // 0xfae174: LoadField: r2 = r0->field_2b
    //     0xfae174: ldur            w2, [x0, #0x2b]
    // 0xfae178: DecompressPointer r2
    //     0xfae178: add             x2, x2, HEAP, lsl #32
    // 0xfae17c: mov             x1, x2
    // 0xfae180: stur            x2, [fp, #-8]
    // 0xfae184: r0 = currentState()
    //     0xfae184: bl              #0x8591f8  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0xfae188: cmp             w0, NULL
    // 0xfae18c: b.eq            #0xfae204
    // 0xfae190: ldur            x3, [fp, #-0x10]
    // 0xfae194: LoadField: r0 = r3->field_3f
    //     0xfae194: ldur            w0, [x3, #0x3f]
    // 0xfae198: DecompressPointer r0
    //     0xfae198: add             x0, x0, HEAP, lsl #32
    // 0xfae19c: LoadField: r4 = r0->field_33
    //     0xfae19c: ldur            w4, [x0, #0x33]
    // 0xfae1a0: DecompressPointer r4
    //     0xfae1a0: add             x4, x4, HEAP, lsl #32
    // 0xfae1a4: stur            x4, [fp, #-0x18]
    // 0xfae1a8: cmp             w4, NULL
    // 0xfae1ac: b.ne            #0xfae1e4
    // 0xfae1b0: LoadField: r2 = r0->field_23
    //     0xfae1b0: ldur            w2, [x0, #0x23]
    // 0xfae1b4: DecompressPointer r2
    //     0xfae1b4: add             x2, x2, HEAP, lsl #32
    // 0xfae1b8: mov             x0, x4
    // 0xfae1bc: r1 = Null
    //     0xfae1bc: mov             x1, NULL
    // 0xfae1c0: cmp             w2, NULL
    // 0xfae1c4: b.eq            #0xfae1e4
    // 0xfae1c8: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xfae1c8: ldur            w4, [x2, #0x17]
    // 0xfae1cc: DecompressPointer r4
    //     0xfae1cc: add             x4, x4, HEAP, lsl #32
    // 0xfae1d0: r8 = X0
    //     0xfae1d0: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xfae1d4: LoadField: r9 = r4->field_7
    //     0xfae1d4: ldur            x9, [x4, #7]
    // 0xfae1d8: r3 = Null
    //     0xfae1d8: add             x3, PP, #0x95, lsl #12  ; [pp+0x95fa0] Null
    //     0xfae1dc: ldr             x3, [x3, #0xfa0]
    // 0xfae1e0: blr             x9
    // 0xfae1e4: ldur            x0, [fp, #-0x18]
    // 0xfae1e8: tbnz            w0, #4, #0xfae204
    // 0xfae1ec: ldur            x1, [fp, #-8]
    // 0xfae1f0: r0 = currentState()
    //     0xfae1f0: bl              #0x8591f8  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0xfae1f4: cmp             w0, NULL
    // 0xfae1f8: b.eq            #0xfae23c
    // 0xfae1fc: mov             x1, x0
    // 0xfae200: r0 = close()
    //     0xfae200: bl              #0xb34b88  ; [package:flutter/src/material/drawer.dart] DrawerControllerState::close
    // 0xfae204: ldur            x0, [fp, #-0x10]
    // 0xfae208: LoadField: r1 = r0->field_2f
    //     0xfae208: ldur            w1, [x0, #0x2f]
    // 0xfae20c: DecompressPointer r1
    //     0xfae20c: add             x1, x1, HEAP, lsl #32
    // 0xfae210: r0 = currentState()
    //     0xfae210: bl              #0x8591f8  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0xfae214: cmp             w0, NULL
    // 0xfae218: b.eq            #0xfae224
    // 0xfae21c: mov             x1, x0
    // 0xfae220: r0 = open()
    //     0xfae220: bl              #0xd1aae4  ; [package:flutter/src/material/drawer.dart] DrawerControllerState::open
    // 0xfae224: r0 = Null
    //     0xfae224: mov             x0, NULL
    // 0xfae228: LeaveFrame
    //     0xfae228: mov             SP, fp
    //     0xfae22c: ldp             fp, lr, [SP], #0x10
    // 0xfae230: ret
    //     0xfae230: ret             
    // 0xfae234: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfae234: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfae238: b               #0xfae174
    // 0xfae23c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xfae23c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10ddc60, size: 0x118
    // 0x10ddc60: EnterFrame
    //     0x10ddc60: stp             fp, lr, [SP, #-0x10]!
    //     0x10ddc64: mov             fp, SP
    // 0x10ddc68: AllocStack(0x8)
    //     0x10ddc68: sub             SP, SP, #8
    // 0x10ddc6c: SetupParameters(ScaffoldState this /* r1 => r2, fp-0x8 */)
    //     0x10ddc6c: mov             x2, x1
    //     0x10ddc70: stur            x1, [fp, #-8]
    // 0x10ddc74: CheckStackOverflow
    //     0x10ddc74: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10ddc78: cmp             SP, x16
    //     0x10ddc7c: b.ls            #0x10ddd40
    // 0x10ddc80: LoadField: r1 = r2->field_77
    //     0x10ddc80: ldur            w1, [x2, #0x77]
    // 0x10ddc84: DecompressPointer r1
    //     0x10ddc84: add             x1, x1, HEAP, lsl #32
    // 0x10ddc88: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10ddc8c: cmp             w1, w16
    // 0x10ddc90: b.eq            #0x10ddd48
    // 0x10ddc94: r0 = dispose()
    //     0x10ddc94: bl              #0x10ef878  ; [dart:mixin_deduplication] _MixinApplication276&Object&ChangeNotifier::dispose
    // 0x10ddc98: ldur            x2, [fp, #-8]
    // 0x10ddc9c: LoadField: r1 = r2->field_63
    //     0x10ddc9c: ldur            w1, [x2, #0x63]
    // 0x10ddca0: DecompressPointer r1
    //     0x10ddca0: add             x1, x1, HEAP, lsl #32
    // 0x10ddca4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10ddca8: cmp             w1, w16
    // 0x10ddcac: b.eq            #0x10ddd54
    // 0x10ddcb0: r0 = dispose()
    //     0x10ddcb0: bl              #0x9164f4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x10ddcb4: ldur            x2, [fp, #-8]
    // 0x10ddcb8: LoadField: r1 = r2->field_73
    //     0x10ddcb8: ldur            w1, [x2, #0x73]
    // 0x10ddcbc: DecompressPointer r1
    //     0x10ddcbc: add             x1, x1, HEAP, lsl #32
    // 0x10ddcc0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10ddcc4: cmp             w1, w16
    // 0x10ddcc8: b.eq            #0x10ddd60
    // 0x10ddccc: r0 = dispose()
    //     0x10ddccc: bl              #0x9164f4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x10ddcd0: ldur            x0, [fp, #-8]
    // 0x10ddcd4: LoadField: r1 = r0->field_47
    //     0x10ddcd4: ldur            w1, [x0, #0x47]
    // 0x10ddcd8: DecompressPointer r1
    //     0x10ddcd8: add             x1, x1, HEAP, lsl #32
    // 0x10ddcdc: cmp             w1, NULL
    // 0x10ddce0: b.eq            #0x10ddcf0
    // 0x10ddce4: mov             x2, x0
    // 0x10ddce8: r0 = _unregister()
    //     0x10ddce8: bl              #0xeeec34  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::_unregister
    // 0x10ddcec: ldur            x0, [fp, #-8]
    // 0x10ddcf0: LoadField: r1 = r0->field_3f
    //     0x10ddcf0: ldur            w1, [x0, #0x3f]
    // 0x10ddcf4: DecompressPointer r1
    //     0x10ddcf4: add             x1, x1, HEAP, lsl #32
    // 0x10ddcf8: r0 = dispose()
    //     0x10ddcf8: bl              #0x10ef0d0  ; [package:flutter/src/widgets/restoration.dart] RestorableProperty::dispose
    // 0x10ddcfc: ldur            x0, [fp, #-8]
    // 0x10ddd00: LoadField: r1 = r0->field_43
    //     0x10ddd00: ldur            w1, [x0, #0x43]
    // 0x10ddd04: DecompressPointer r1
    //     0x10ddd04: add             x1, x1, HEAP, lsl #32
    // 0x10ddd08: r0 = dispose()
    //     0x10ddd08: bl              #0x10ef0d0  ; [package:flutter/src/widgets/restoration.dart] RestorableProperty::dispose
    // 0x10ddd0c: ldur            x0, [fp, #-8]
    // 0x10ddd10: LoadField: r1 = r0->field_7b
    //     0x10ddd10: ldur            w1, [x0, #0x7b]
    // 0x10ddd14: DecompressPointer r1
    //     0x10ddd14: add             x1, x1, HEAP, lsl #32
    // 0x10ddd18: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10ddd1c: cmp             w1, w16
    // 0x10ddd20: b.eq            #0x10ddd6c
    // 0x10ddd24: r0 = dispose()
    //     0x10ddd24: bl              #0x9164f4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x10ddd28: ldur            x1, [fp, #-8]
    // 0x10ddd2c: r0 = dispose()
    //     0x10ddd2c: bl              #0x10dc7ac  ; [dart:mixin_deduplication] _MixinApplication101&State&TickerProviderStateMixin&RestorationMixin::dispose
    // 0x10ddd30: r0 = Null
    //     0x10ddd30: mov             x0, NULL
    // 0x10ddd34: LeaveFrame
    //     0x10ddd34: mov             SP, fp
    //     0x10ddd38: ldp             fp, lr, [SP], #0x10
    // 0x10ddd3c: ret
    //     0x10ddd3c: ret             
    // 0x10ddd40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10ddd40: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10ddd44: b               #0x10ddc80
    // 0x10ddd48: r9 = _geometryNotifier
    //     0x10ddd48: add             x9, PP, #0x84, lsl #12  ; [pp+0x84b60] Field <ScaffoldState._geometryNotifier@89420462>: late (offset: 0x78)
    //     0x10ddd4c: ldr             x9, [x9, #0xb60]
    // 0x10ddd50: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x10ddd50: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x10ddd54: r9 = _floatingActionButtonMoveController
    //     0x10ddd54: add             x9, PP, #0x84, lsl #12  ; [pp+0x84b50] Field <ScaffoldState._floatingActionButtonMoveController@89420462>: late (offset: 0x64)
    //     0x10ddd58: ldr             x9, [x9, #0xb50]
    // 0x10ddd5c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x10ddd5c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x10ddd60: r9 = _floatingActionButtonVisibilityController
    //     0x10ddd60: add             x9, PP, #0x84, lsl #12  ; [pp+0x84b68] Field <ScaffoldState._floatingActionButtonVisibilityController@89420462>: late (offset: 0x74)
    //     0x10ddd64: ldr             x9, [x9, #0xb68]
    // 0x10ddd68: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x10ddd68: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x10ddd6c: r9 = _bottomSheetScrimAnimationController
    //     0x10ddd6c: add             x9, PP, #0x84, lsl #12  ; [pp+0x84b48] Field <ScaffoldState._bottomSheetScrimAnimationController@89420462>: late (offset: 0x7c)
    //     0x10ddd70: ldr             x9, [x9, #0xb48]
    // 0x10ddd74: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x10ddd74: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ restoreState(/* No info */) {
    // ** addr: 0x1196b94, size: 0x68
    // 0x1196b94: EnterFrame
    //     0x1196b94: stp             fp, lr, [SP, #-0x10]!
    //     0x1196b98: mov             fp, SP
    // 0x1196b9c: AllocStack(0x8)
    //     0x1196b9c: sub             SP, SP, #8
    // 0x1196ba0: SetupParameters(ScaffoldState this /* r1 => r0, fp-0x8 */)
    //     0x1196ba0: mov             x0, x1
    //     0x1196ba4: stur            x1, [fp, #-8]
    // 0x1196ba8: CheckStackOverflow
    //     0x1196ba8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1196bac: cmp             SP, x16
    //     0x1196bb0: b.ls            #0x1196bf4
    // 0x1196bb4: LoadField: r2 = r0->field_3f
    //     0x1196bb4: ldur            w2, [x0, #0x3f]
    // 0x1196bb8: DecompressPointer r2
    //     0x1196bb8: add             x2, x2, HEAP, lsl #32
    // 0x1196bbc: mov             x1, x0
    // 0x1196bc0: r3 = "drawer_open"
    //     0x1196bc0: add             x3, PP, #0x85, lsl #12  ; [pp+0x857e0] "drawer_open"
    //     0x1196bc4: ldr             x3, [x3, #0x7e0]
    // 0x1196bc8: r0 = registerForRestoration()
    //     0x1196bc8: bl              #0x1196bfc  ; [dart:mixin_deduplication] _MixinApplication101&State&TickerProviderStateMixin&RestorationMixin::registerForRestoration
    // 0x1196bcc: ldur            x1, [fp, #-8]
    // 0x1196bd0: LoadField: r2 = r1->field_43
    //     0x1196bd0: ldur            w2, [x1, #0x43]
    // 0x1196bd4: DecompressPointer r2
    //     0x1196bd4: add             x2, x2, HEAP, lsl #32
    // 0x1196bd8: r3 = "end_drawer_open"
    //     0x1196bd8: add             x3, PP, #0x85, lsl #12  ; [pp+0x857e8] "end_drawer_open"
    //     0x1196bdc: ldr             x3, [x3, #0x7e8]
    // 0x1196be0: r0 = registerForRestoration()
    //     0x1196be0: bl              #0x1196bfc  ; [dart:mixin_deduplication] _MixinApplication101&State&TickerProviderStateMixin&RestorationMixin::registerForRestoration
    // 0x1196be4: r0 = Null
    //     0x1196be4: mov             x0, NULL
    // 0x1196be8: LeaveFrame
    //     0x1196be8: mov             SP, fp
    //     0x1196bec: ldp             fp, lr, [SP], #0x10
    // 0x1196bf0: ret
    //     0x1196bf0: ret             
    // 0x1196bf4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1196bf4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1196bf8: b               #0x1196bb4
  }
}

// class id: 5712, size: 0x44, field offset: 0x1c
class _FloatingActionButtonTransitionState extends _MixinApplication99&State&TickerProviderStateMixin {

  late AnimationController _previousController; // offset: 0x1c
  late Animation<double> _previousScaleAnimation; // offset: 0x2c
  late TrainHoppingAnimation _previousRotationAnimation; // offset: 0x30
  late Animation<double> _currentScaleAnimation; // offset: 0x34
  late TrainHoppingAnimation _currentRotationAnimation; // offset: 0x3c
  static late final Animatable<double> _entranceTurnTween; // offset: 0x6bc

  _ build(/* No info */) {
    // ** addr: 0xd35208, size: 0x34c
    // 0xd35208: EnterFrame
    //     0xd35208: stp             fp, lr, [SP, #-0x10]!
    //     0xd3520c: mov             fp, SP
    // 0xd35210: AllocStack(0x38)
    //     0xd35210: sub             SP, SP, #0x38
    // 0xd35214: SetupParameters(_FloatingActionButtonTransitionState this /* r1 => r0, fp-0x8 */)
    //     0xd35214: mov             x0, x1
    //     0xd35218: stur            x1, [fp, #-8]
    // 0xd3521c: CheckStackOverflow
    //     0xd3521c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd35220: cmp             SP, x16
    //     0xd35224: b.ls            #0xd35504
    // 0xd35228: r1 = <Widget>
    //     0xd35228: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xd3522c: r2 = 0
    //     0xd3522c: mov             x2, #0
    // 0xd35230: r0 = _GrowableList()
    //     0xd35230: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xd35234: mov             x1, x0
    // 0xd35238: ldur            x0, [fp, #-8]
    // 0xd3523c: stur            x1, [fp, #-0x28]
    // 0xd35240: LoadField: r2 = r0->field_1b
    //     0xd35240: ldur            w2, [x0, #0x1b]
    // 0xd35244: DecompressPointer r2
    //     0xd35244: add             x2, x2, HEAP, lsl #32
    // 0xd35248: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3524c: cmp             w2, w16
    // 0xd35250: b.eq            #0xd3550c
    // 0xd35254: LoadField: r3 = r2->field_43
    //     0xd35254: ldur            w3, [x2, #0x43]
    // 0xd35258: DecompressPointer r3
    //     0xd35258: add             x3, x3, HEAP, lsl #32
    // 0xd3525c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd35260: cmp             w3, w16
    // 0xd35264: b.eq            #0xd35518
    // 0xd35268: r16 = Instance_AnimationStatus
    //     0xd35268: ldr             x16, [PP, #0x51a8]  ; [pp+0x51a8] Obj!AnimationStatus@12c61c1
    // 0xd3526c: cmp             w3, w16
    // 0xd35270: b.eq            #0xd35394
    // 0xd35274: LoadField: r2 = r0->field_3f
    //     0xd35274: ldur            w2, [x0, #0x3f]
    // 0xd35278: DecompressPointer r2
    //     0xd35278: add             x2, x2, HEAP, lsl #32
    // 0xd3527c: stur            x2, [fp, #-0x20]
    // 0xd35280: LoadField: r3 = r0->field_2b
    //     0xd35280: ldur            w3, [x0, #0x2b]
    // 0xd35284: DecompressPointer r3
    //     0xd35284: add             x3, x3, HEAP, lsl #32
    // 0xd35288: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3528c: cmp             w3, w16
    // 0xd35290: b.eq            #0xd35520
    // 0xd35294: stur            x3, [fp, #-0x18]
    // 0xd35298: LoadField: r4 = r0->field_2f
    //     0xd35298: ldur            w4, [x0, #0x2f]
    // 0xd3529c: DecompressPointer r4
    //     0xd3529c: add             x4, x4, HEAP, lsl #32
    // 0xd352a0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd352a4: cmp             w4, w16
    // 0xd352a8: b.eq            #0xd3552c
    // 0xd352ac: stur            x4, [fp, #-0x10]
    // 0xd352b0: r0 = RotationTransition()
    //     0xd352b0: bl              #0xd0fd50  ; AllocateRotationTransitionStub -> RotationTransition (size=0x20)
    // 0xd352b4: mov             x1, x0
    // 0xd352b8: r0 = Closure: (double) => Matrix4 from Function '_handleTurnsMatrix@589170175': static.
    //     0xd352b8: add             x0, PP, #0x95, lsl #12  ; [pp+0x95d30] Closure: (double) => Matrix4 from Function '_handleTurnsMatrix@589170175': static. (0x7f2adabf7000)
    //     0xd352bc: ldr             x0, [x0, #0xd30]
    // 0xd352c0: stur            x1, [fp, #-0x30]
    // 0xd352c4: StoreField: r1->field_f = r0
    //     0xd352c4: stur            w0, [x1, #0xf]
    // 0xd352c8: r2 = Instance_Alignment
    //     0xd352c8: add             x2, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xd352cc: ldr             x2, [x2, #0xb80]
    // 0xd352d0: StoreField: r1->field_13 = r2
    //     0xd352d0: stur            w2, [x1, #0x13]
    // 0xd352d4: ldur            x3, [fp, #-0x20]
    // 0xd352d8: StoreField: r1->field_1b = r3
    //     0xd352d8: stur            w3, [x1, #0x1b]
    // 0xd352dc: ldur            x3, [fp, #-0x10]
    // 0xd352e0: StoreField: r1->field_b = r3
    //     0xd352e0: stur            w3, [x1, #0xb]
    // 0xd352e4: r0 = ScaleTransition()
    //     0xd352e4: bl              #0xb2851c  ; AllocateScaleTransitionStub -> ScaleTransition (size=0x20)
    // 0xd352e8: mov             x2, x0
    // 0xd352ec: r0 = Closure: (double) => Matrix4 from Function '_handleScaleMatrix@589170175': static.
    //     0xd352ec: add             x0, PP, #0x8f, lsl #12  ; [pp+0x8fa10] Closure: (double) => Matrix4 from Function '_handleScaleMatrix@589170175': static. (0x7f2adaa0f528)
    //     0xd352f0: ldr             x0, [x0, #0xa10]
    // 0xd352f4: stur            x2, [fp, #-0x10]
    // 0xd352f8: StoreField: r2->field_f = r0
    //     0xd352f8: stur            w0, [x2, #0xf]
    // 0xd352fc: r3 = Instance_Alignment
    //     0xd352fc: add             x3, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xd35300: ldr             x3, [x3, #0xb80]
    // 0xd35304: StoreField: r2->field_13 = r3
    //     0xd35304: stur            w3, [x2, #0x13]
    // 0xd35308: ldur            x1, [fp, #-0x30]
    // 0xd3530c: StoreField: r2->field_1b = r1
    //     0xd3530c: stur            w1, [x2, #0x1b]
    // 0xd35310: ldur            x1, [fp, #-0x18]
    // 0xd35314: StoreField: r2->field_b = r1
    //     0xd35314: stur            w1, [x2, #0xb]
    // 0xd35318: ldur            x4, [fp, #-0x28]
    // 0xd3531c: LoadField: r1 = r4->field_b
    //     0xd3531c: ldur            w1, [x4, #0xb]
    // 0xd35320: LoadField: r5 = r4->field_f
    //     0xd35320: ldur            w5, [x4, #0xf]
    // 0xd35324: DecompressPointer r5
    //     0xd35324: add             x5, x5, HEAP, lsl #32
    // 0xd35328: LoadField: r6 = r5->field_b
    //     0xd35328: ldur            w6, [x5, #0xb]
    // 0xd3532c: r5 = LoadInt32Instr(r1)
    //     0xd3532c: sbfx            x5, x1, #1, #0x1f
    // 0xd35330: stur            x5, [fp, #-0x38]
    // 0xd35334: r1 = LoadInt32Instr(r6)
    //     0xd35334: sbfx            x1, x6, #1, #0x1f
    // 0xd35338: cmp             x5, x1
    // 0xd3533c: b.ne            #0xd35348
    // 0xd35340: mov             x1, x4
    // 0xd35344: r0 = _growToNextCapacity()
    //     0xd35344: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xd35348: ldur            x2, [fp, #-0x28]
    // 0xd3534c: ldur            x3, [fp, #-0x38]
    // 0xd35350: add             x0, x3, #1
    // 0xd35354: lsl             x1, x0, #1
    // 0xd35358: StoreField: r2->field_b = r1
    //     0xd35358: stur            w1, [x2, #0xb]
    // 0xd3535c: LoadField: r1 = r2->field_f
    //     0xd3535c: ldur            w1, [x2, #0xf]
    // 0xd35360: DecompressPointer r1
    //     0xd35360: add             x1, x1, HEAP, lsl #32
    // 0xd35364: ldur            x0, [fp, #-0x10]
    // 0xd35368: ArrayStore: r1[r3] = r0  ; List_4
    //     0xd35368: add             x25, x1, x3, lsl #2
    //     0xd3536c: add             x25, x25, #0xf
    //     0xd35370: str             w0, [x25]
    //     0xd35374: tbz             w0, #0, #0xd35390
    //     0xd35378: ldurb           w16, [x1, #-1]
    //     0xd3537c: ldurb           w17, [x0, #-1]
    //     0xd35380: and             x16, x17, x16, lsr #2
    //     0xd35384: tst             x16, HEAP, lsr #32
    //     0xd35388: b.eq            #0xd35390
    //     0xd3538c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd35390: b               #0xd35398
    // 0xd35394: mov             x2, x1
    // 0xd35398: ldur            x0, [fp, #-8]
    // 0xd3539c: LoadField: r1 = r0->field_b
    //     0xd3539c: ldur            w1, [x0, #0xb]
    // 0xd353a0: DecompressPointer r1
    //     0xd353a0: add             x1, x1, HEAP, lsl #32
    // 0xd353a4: cmp             w1, NULL
    // 0xd353a8: b.eq            #0xd35538
    // 0xd353ac: LoadField: r3 = r1->field_b
    //     0xd353ac: ldur            w3, [x1, #0xb]
    // 0xd353b0: DecompressPointer r3
    //     0xd353b0: add             x3, x3, HEAP, lsl #32
    // 0xd353b4: stur            x3, [fp, #-0x20]
    // 0xd353b8: LoadField: r1 = r0->field_33
    //     0xd353b8: ldur            w1, [x0, #0x33]
    // 0xd353bc: DecompressPointer r1
    //     0xd353bc: add             x1, x1, HEAP, lsl #32
    // 0xd353c0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd353c4: cmp             w1, w16
    // 0xd353c8: b.eq            #0xd3553c
    // 0xd353cc: stur            x1, [fp, #-0x18]
    // 0xd353d0: LoadField: r4 = r0->field_3b
    //     0xd353d0: ldur            w4, [x0, #0x3b]
    // 0xd353d4: DecompressPointer r4
    //     0xd353d4: add             x4, x4, HEAP, lsl #32
    // 0xd353d8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd353dc: cmp             w4, w16
    // 0xd353e0: b.eq            #0xd35548
    // 0xd353e4: stur            x4, [fp, #-0x10]
    // 0xd353e8: r0 = RotationTransition()
    //     0xd353e8: bl              #0xd0fd50  ; AllocateRotationTransitionStub -> RotationTransition (size=0x20)
    // 0xd353ec: mov             x1, x0
    // 0xd353f0: r0 = Closure: (double) => Matrix4 from Function '_handleTurnsMatrix@589170175': static.
    //     0xd353f0: add             x0, PP, #0x95, lsl #12  ; [pp+0x95d30] Closure: (double) => Matrix4 from Function '_handleTurnsMatrix@589170175': static. (0x7f2adabf7000)
    //     0xd353f4: ldr             x0, [x0, #0xd30]
    // 0xd353f8: stur            x1, [fp, #-8]
    // 0xd353fc: StoreField: r1->field_f = r0
    //     0xd353fc: stur            w0, [x1, #0xf]
    // 0xd35400: r0 = Instance_Alignment
    //     0xd35400: add             x0, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xd35404: ldr             x0, [x0, #0xb80]
    // 0xd35408: StoreField: r1->field_13 = r0
    //     0xd35408: stur            w0, [x1, #0x13]
    // 0xd3540c: ldur            x2, [fp, #-0x20]
    // 0xd35410: StoreField: r1->field_1b = r2
    //     0xd35410: stur            w2, [x1, #0x1b]
    // 0xd35414: ldur            x2, [fp, #-0x10]
    // 0xd35418: StoreField: r1->field_b = r2
    //     0xd35418: stur            w2, [x1, #0xb]
    // 0xd3541c: r0 = ScaleTransition()
    //     0xd3541c: bl              #0xb2851c  ; AllocateScaleTransitionStub -> ScaleTransition (size=0x20)
    // 0xd35420: mov             x2, x0
    // 0xd35424: r0 = Closure: (double) => Matrix4 from Function '_handleScaleMatrix@589170175': static.
    //     0xd35424: add             x0, PP, #0x8f, lsl #12  ; [pp+0x8fa10] Closure: (double) => Matrix4 from Function '_handleScaleMatrix@589170175': static. (0x7f2adaa0f528)
    //     0xd35428: ldr             x0, [x0, #0xa10]
    // 0xd3542c: stur            x2, [fp, #-0x10]
    // 0xd35430: StoreField: r2->field_f = r0
    //     0xd35430: stur            w0, [x2, #0xf]
    // 0xd35434: r0 = Instance_Alignment
    //     0xd35434: add             x0, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xd35438: ldr             x0, [x0, #0xb80]
    // 0xd3543c: StoreField: r2->field_13 = r0
    //     0xd3543c: stur            w0, [x2, #0x13]
    // 0xd35440: ldur            x0, [fp, #-8]
    // 0xd35444: StoreField: r2->field_1b = r0
    //     0xd35444: stur            w0, [x2, #0x1b]
    // 0xd35448: ldur            x0, [fp, #-0x18]
    // 0xd3544c: StoreField: r2->field_b = r0
    //     0xd3544c: stur            w0, [x2, #0xb]
    // 0xd35450: ldur            x0, [fp, #-0x28]
    // 0xd35454: LoadField: r1 = r0->field_b
    //     0xd35454: ldur            w1, [x0, #0xb]
    // 0xd35458: LoadField: r3 = r0->field_f
    //     0xd35458: ldur            w3, [x0, #0xf]
    // 0xd3545c: DecompressPointer r3
    //     0xd3545c: add             x3, x3, HEAP, lsl #32
    // 0xd35460: LoadField: r4 = r3->field_b
    //     0xd35460: ldur            w4, [x3, #0xb]
    // 0xd35464: r3 = LoadInt32Instr(r1)
    //     0xd35464: sbfx            x3, x1, #1, #0x1f
    // 0xd35468: stur            x3, [fp, #-0x38]
    // 0xd3546c: r1 = LoadInt32Instr(r4)
    //     0xd3546c: sbfx            x1, x4, #1, #0x1f
    // 0xd35470: cmp             x3, x1
    // 0xd35474: b.ne            #0xd35480
    // 0xd35478: mov             x1, x0
    // 0xd3547c: r0 = _growToNextCapacity()
    //     0xd3547c: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xd35480: ldur            x2, [fp, #-0x28]
    // 0xd35484: ldur            x3, [fp, #-0x38]
    // 0xd35488: add             x0, x3, #1
    // 0xd3548c: lsl             x1, x0, #1
    // 0xd35490: StoreField: r2->field_b = r1
    //     0xd35490: stur            w1, [x2, #0xb]
    // 0xd35494: LoadField: r1 = r2->field_f
    //     0xd35494: ldur            w1, [x2, #0xf]
    // 0xd35498: DecompressPointer r1
    //     0xd35498: add             x1, x1, HEAP, lsl #32
    // 0xd3549c: ldur            x0, [fp, #-0x10]
    // 0xd354a0: ArrayStore: r1[r3] = r0  ; List_4
    //     0xd354a0: add             x25, x1, x3, lsl #2
    //     0xd354a4: add             x25, x25, #0xf
    //     0xd354a8: str             w0, [x25]
    //     0xd354ac: tbz             w0, #0, #0xd354c8
    //     0xd354b0: ldurb           w16, [x1, #-1]
    //     0xd354b4: ldurb           w17, [x0, #-1]
    //     0xd354b8: and             x16, x17, x16, lsr #2
    //     0xd354bc: tst             x16, HEAP, lsr #32
    //     0xd354c0: b.eq            #0xd354c8
    //     0xd354c4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd354c8: r0 = Stack()
    //     0xd354c8: bl              #0xd1a854  ; AllocateStackStub -> Stack (size=0x20)
    // 0xd354cc: r1 = Instance_Alignment
    //     0xd354cc: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e8f8] Obj!Alignment@129e831
    //     0xd354d0: ldr             x1, [x1, #0x8f8]
    // 0xd354d4: StoreField: r0->field_f = r1
    //     0xd354d4: stur            w1, [x0, #0xf]
    // 0xd354d8: r1 = Instance_StackFit
    //     0xd354d8: add             x1, PP, #0x15, lsl #12  ; [pp+0x158e0] Obj!StackFit@12c4221
    //     0xd354dc: ldr             x1, [x1, #0x8e0]
    // 0xd354e0: ArrayStore: r0[0] = r1  ; List_4
    //     0xd354e0: stur            w1, [x0, #0x17]
    // 0xd354e4: r1 = Instance_Clip
    //     0xd354e4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xd354e8: ldr             x1, [x1, #0x850]
    // 0xd354ec: StoreField: r0->field_1b = r1
    //     0xd354ec: stur            w1, [x0, #0x1b]
    // 0xd354f0: ldur            x1, [fp, #-0x28]
    // 0xd354f4: StoreField: r0->field_b = r1
    //     0xd354f4: stur            w1, [x0, #0xb]
    // 0xd354f8: LeaveFrame
    //     0xd354f8: mov             SP, fp
    //     0xd354fc: ldp             fp, lr, [SP], #0x10
    // 0xd35500: ret
    //     0xd35500: ret             
    // 0xd35504: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd35504: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd35508: b               #0xd35228
    // 0xd3550c: r9 = _previousController
    //     0xd3550c: add             x9, PP, #0x99, lsl #12  ; [pp+0x997a0] Field <_FloatingActionButtonTransitionState@89420462._previousController@89420462>: late (offset: 0x1c)
    //     0xd35510: ldr             x9, [x9, #0x7a0]
    // 0xd35514: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd35514: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd35518: r9 = _status
    //     0xd35518: ldr             x9, [PP, #0x51e8]  ; [pp+0x51e8] Field <AnimationController._status@62066280>: late (offset: 0x44)
    // 0xd3551c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd3551c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd35520: r9 = _previousScaleAnimation
    //     0xd35520: add             x9, PP, #0x99, lsl #12  ; [pp+0x997a8] Field <_FloatingActionButtonTransitionState@89420462._previousScaleAnimation@89420462>: late (offset: 0x2c)
    //     0xd35524: ldr             x9, [x9, #0x7a8]
    // 0xd35528: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd35528: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd3552c: r9 = _previousRotationAnimation
    //     0xd3552c: add             x9, PP, #0x99, lsl #12  ; [pp+0x997b0] Field <_FloatingActionButtonTransitionState@89420462._previousRotationAnimation@89420462>: late (offset: 0x30)
    //     0xd35530: ldr             x9, [x9, #0x7b0]
    // 0xd35534: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd35534: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd35538: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd35538: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd3553c: r9 = _currentScaleAnimation
    //     0xd3553c: add             x9, PP, #0x99, lsl #12  ; [pp+0x997b8] Field <_FloatingActionButtonTransitionState@89420462._currentScaleAnimation@89420462>: late (offset: 0x34)
    //     0xd35540: ldr             x9, [x9, #0x7b8]
    // 0xd35544: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd35544: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd35548: r9 = _currentRotationAnimation
    //     0xd35548: add             x9, PP, #0x99, lsl #12  ; [pp+0x997c0] Field <_FloatingActionButtonTransitionState@89420462._currentRotationAnimation@89420462>: late (offset: 0x3c)
    //     0xd3554c: ldr             x9, [x9, #0x7c0]
    // 0xd35550: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd35550: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf3c4f4, size: 0x2d8
    // 0xf3c4f4: EnterFrame
    //     0xf3c4f4: stp             fp, lr, [SP, #-0x10]!
    //     0xf3c4f8: mov             fp, SP
    // 0xf3c4fc: AllocStack(0x28)
    //     0xf3c4fc: sub             SP, SP, #0x28
    // 0xf3c500: SetupParameters(_FloatingActionButtonTransitionState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xf3c500: mov             x4, x1
    //     0xf3c504: mov             x3, x2
    //     0xf3c508: stur            x1, [fp, #-8]
    //     0xf3c50c: stur            x2, [fp, #-0x10]
    // 0xf3c510: CheckStackOverflow
    //     0xf3c510: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3c514: cmp             SP, x16
    //     0xf3c518: b.ls            #0xf3c798
    // 0xf3c51c: mov             x0, x3
    // 0xf3c520: r2 = Null
    //     0xf3c520: mov             x2, NULL
    // 0xf3c524: r1 = Null
    //     0xf3c524: mov             x1, NULL
    // 0xf3c528: r4 = 60
    //     0xf3c528: mov             x4, #0x3c
    // 0xf3c52c: branchIfSmi(r0, 0xf3c538)
    //     0xf3c52c: tbz             w0, #0, #0xf3c538
    // 0xf3c530: r4 = LoadClassIdInstr(r0)
    //     0xf3c530: ldur            x4, [x0, #-1]
    //     0xf3c534: ubfx            x4, x4, #0xc, #0x14
    // 0xf3c538: r17 = 6438
    //     0xf3c538: mov             x17, #0x1926
    // 0xf3c53c: cmp             x4, x17
    // 0xf3c540: b.eq            #0xf3c558
    // 0xf3c544: r8 = _FloatingActionButtonTransition
    //     0xf3c544: add             x8, PP, #0x99, lsl #12  ; [pp+0x997c8] Type: _FloatingActionButtonTransition
    //     0xf3c548: ldr             x8, [x8, #0x7c8]
    // 0xf3c54c: r3 = Null
    //     0xf3c54c: add             x3, PP, #0x99, lsl #12  ; [pp+0x997d0] Null
    //     0xf3c550: ldr             x3, [x3, #0x7d0]
    // 0xf3c554: r0 = _FloatingActionButtonTransition()
    //     0xf3c554: bl              #0xad05a8  ; IsType__FloatingActionButtonTransition_Stub
    // 0xf3c558: ldur            x3, [fp, #-8]
    // 0xf3c55c: LoadField: r2 = r3->field_7
    //     0xf3c55c: ldur            w2, [x3, #7]
    // 0xf3c560: DecompressPointer r2
    //     0xf3c560: add             x2, x2, HEAP, lsl #32
    // 0xf3c564: ldur            x0, [fp, #-0x10]
    // 0xf3c568: r1 = Null
    //     0xf3c568: mov             x1, NULL
    // 0xf3c56c: cmp             w2, NULL
    // 0xf3c570: b.eq            #0xf3c594
    // 0xf3c574: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf3c574: ldur            w4, [x2, #0x17]
    // 0xf3c578: DecompressPointer r4
    //     0xf3c578: add             x4, x4, HEAP, lsl #32
    // 0xf3c57c: r8 = X0 bound StatefulWidget
    //     0xf3c57c: add             x8, PP, #0x12, lsl #12  ; [pp+0x12498] TypeParameter: X0 bound StatefulWidget
    //     0xf3c580: ldr             x8, [x8, #0x498]
    // 0xf3c584: LoadField: r9 = r4->field_7
    //     0xf3c584: ldur            x9, [x4, #7]
    // 0xf3c588: r3 = Null
    //     0xf3c588: add             x3, PP, #0x99, lsl #12  ; [pp+0x997e0] Null
    //     0xf3c58c: ldr             x3, [x3, #0x7e0]
    // 0xf3c590: blr             x9
    // 0xf3c594: ldur            x0, [fp, #-8]
    // 0xf3c598: LoadField: r1 = r0->field_b
    //     0xf3c598: ldur            w1, [x0, #0xb]
    // 0xf3c59c: DecompressPointer r1
    //     0xf3c59c: add             x1, x1, HEAP, lsl #32
    // 0xf3c5a0: cmp             w1, NULL
    // 0xf3c5a4: b.eq            #0xf3c7a0
    // 0xf3c5a8: ldur            x2, [fp, #-0x10]
    // 0xf3c5ac: LoadField: r3 = r2->field_f
    //     0xf3c5ac: ldur            w3, [x2, #0xf]
    // 0xf3c5b0: DecompressPointer r3
    //     0xf3c5b0: add             x3, x3, HEAP, lsl #32
    // 0xf3c5b4: LoadField: r4 = r1->field_f
    //     0xf3c5b4: ldur            w4, [x1, #0xf]
    // 0xf3c5b8: DecompressPointer r4
    //     0xf3c5b8: add             x4, x4, HEAP, lsl #32
    // 0xf3c5bc: cmp             w3, w4
    // 0xf3c5c0: b.eq            #0xf3c5d4
    // 0xf3c5c4: mov             x1, x0
    // 0xf3c5c8: r0 = _disposeAnimations()
    //     0xf3c5c8: bl              #0xf3d4ec  ; [package:flutter/src/material/scaffold.dart] _FloatingActionButtonTransitionState::_disposeAnimations
    // 0xf3c5cc: ldur            x1, [fp, #-8]
    // 0xf3c5d0: r0 = _updateAnimations()
    //     0xf3c5d0: bl              #0xf3c7cc  ; [package:flutter/src/material/scaffold.dart] _FloatingActionButtonTransitionState::_updateAnimations
    // 0xf3c5d4: ldur            x1, [fp, #-8]
    // 0xf3c5d8: ldur            x0, [fp, #-0x10]
    // 0xf3c5dc: LoadField: r2 = r0->field_b
    //     0xf3c5dc: ldur            w2, [x0, #0xb]
    // 0xf3c5e0: DecompressPointer r2
    //     0xf3c5e0: add             x2, x2, HEAP, lsl #32
    // 0xf3c5e4: stur            x2, [fp, #-0x18]
    // 0xf3c5e8: cmp             w2, NULL
    // 0xf3c5ec: r16 = true
    //     0xf3c5ec: add             x16, NULL, #0x20  ; true
    // 0xf3c5f0: r17 = false
    //     0xf3c5f0: add             x17, NULL, #0x30  ; false
    // 0xf3c5f4: csel            x0, x16, x17, eq
    // 0xf3c5f8: LoadField: r3 = r1->field_b
    //     0xf3c5f8: ldur            w3, [x1, #0xb]
    // 0xf3c5fc: DecompressPointer r3
    //     0xf3c5fc: add             x3, x3, HEAP, lsl #32
    // 0xf3c600: cmp             w3, NULL
    // 0xf3c604: b.eq            #0xf3c7a4
    // 0xf3c608: LoadField: r4 = r3->field_b
    //     0xf3c608: ldur            w4, [x3, #0xb]
    // 0xf3c60c: DecompressPointer r4
    //     0xf3c60c: add             x4, x4, HEAP, lsl #32
    // 0xf3c610: cmp             w4, NULL
    // 0xf3c614: r16 = true
    //     0xf3c614: add             x16, NULL, #0x20  ; true
    // 0xf3c618: r17 = false
    //     0xf3c618: add             x17, NULL, #0x30  ; false
    // 0xf3c61c: csel            x3, x16, x17, eq
    // 0xf3c620: cmp             w0, w3
    // 0xf3c624: b.ne            #0xf3c688
    // 0xf3c628: cmp             w2, NULL
    // 0xf3c62c: b.ne            #0xf3c638
    // 0xf3c630: r0 = Null
    //     0xf3c630: mov             x0, NULL
    // 0xf3c634: b               #0xf3c640
    // 0xf3c638: LoadField: r0 = r2->field_7
    //     0xf3c638: ldur            w0, [x2, #7]
    // 0xf3c63c: DecompressPointer r0
    //     0xf3c63c: add             x0, x0, HEAP, lsl #32
    // 0xf3c640: cmp             w4, NULL
    // 0xf3c644: b.ne            #0xf3c650
    // 0xf3c648: r3 = Null
    //     0xf3c648: mov             x3, NULL
    // 0xf3c64c: b               #0xf3c658
    // 0xf3c650: LoadField: r3 = r4->field_7
    //     0xf3c650: ldur            w3, [x4, #7]
    // 0xf3c654: DecompressPointer r3
    //     0xf3c654: add             x3, x3, HEAP, lsl #32
    // 0xf3c658: r4 = LoadClassIdInstr(r0)
    //     0xf3c658: ldur            x4, [x0, #-1]
    //     0xf3c65c: ubfx            x4, x4, #0xc, #0x14
    // 0xf3c660: stp             x3, x0, [SP]
    // 0xf3c664: mov             x0, x4
    // 0xf3c668: mov             lr, x0
    // 0xf3c66c: ldr             lr, [x21, lr, lsl #3]
    // 0xf3c670: blr             lr
    // 0xf3c674: tbnz            w0, #4, #0xf3c688
    // 0xf3c678: r0 = Null
    //     0xf3c678: mov             x0, NULL
    // 0xf3c67c: LeaveFrame
    //     0xf3c67c: mov             SP, fp
    //     0xf3c680: ldp             fp, lr, [SP], #0x10
    // 0xf3c684: ret
    //     0xf3c684: ret             
    // 0xf3c688: ldur            x3, [fp, #-8]
    // 0xf3c68c: LoadField: r4 = r3->field_1b
    //     0xf3c68c: ldur            w4, [x3, #0x1b]
    // 0xf3c690: DecompressPointer r4
    //     0xf3c690: add             x4, x4, HEAP, lsl #32
    // 0xf3c694: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3c698: cmp             w4, w16
    // 0xf3c69c: b.eq            #0xf3c7a8
    // 0xf3c6a0: stur            x4, [fp, #-0x10]
    // 0xf3c6a4: LoadField: r0 = r4->field_43
    //     0xf3c6a4: ldur            w0, [x4, #0x43]
    // 0xf3c6a8: DecompressPointer r0
    //     0xf3c6a8: add             x0, x0, HEAP, lsl #32
    // 0xf3c6ac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3c6b0: cmp             w0, w16
    // 0xf3c6b4: b.eq            #0xf3c7b4
    // 0xf3c6b8: r16 = Instance_AnimationStatus
    //     0xf3c6b8: ldr             x16, [PP, #0x51a8]  ; [pp+0x51a8] Obj!AnimationStatus@12c61c1
    // 0xf3c6bc: cmp             w0, w16
    // 0xf3c6c0: b.ne            #0xf3c788
    // 0xf3c6c4: d0 = 0.000000
    //     0xf3c6c4: eor             v0.16b, v0.16b, v0.16b
    // 0xf3c6c8: LoadField: r0 = r3->field_b
    //     0xf3c6c8: ldur            w0, [x3, #0xb]
    // 0xf3c6cc: DecompressPointer r0
    //     0xf3c6cc: add             x0, x0, HEAP, lsl #32
    // 0xf3c6d0: cmp             w0, NULL
    // 0xf3c6d4: b.eq            #0xf3c7bc
    // 0xf3c6d8: LoadField: r1 = r0->field_1b
    //     0xf3c6d8: ldur            w1, [x0, #0x1b]
    // 0xf3c6dc: DecompressPointer r1
    //     0xf3c6dc: add             x1, x1, HEAP, lsl #32
    // 0xf3c6e0: LoadField: r2 = r1->field_37
    //     0xf3c6e0: ldur            w2, [x1, #0x37]
    // 0xf3c6e4: DecompressPointer r2
    //     0xf3c6e4: add             x2, x2, HEAP, lsl #32
    // 0xf3c6e8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3c6ec: cmp             w2, w16
    // 0xf3c6f0: b.eq            #0xf3c7c0
    // 0xf3c6f4: LoadField: d1 = r2->field_7
    //     0xf3c6f4: ldur            d1, [x2, #7]
    // 0xf3c6f8: fcmp            d1, d0
    // 0xf3c6fc: b.eq            #0xf3c70c
    // 0xf3c700: ldur            x5, [fp, #-0x18]
    // 0xf3c704: cmp             w5, NULL
    // 0xf3c708: b.ne            #0xf3c72c
    // 0xf3c70c: StoreField: r3->field_3f = rNULL
    //     0xf3c70c: stur            NULL, [x3, #0x3f]
    // 0xf3c710: LoadField: r2 = r0->field_b
    //     0xf3c710: ldur            w2, [x0, #0xb]
    // 0xf3c714: DecompressPointer r2
    //     0xf3c714: add             x2, x2, HEAP, lsl #32
    // 0xf3c718: cmp             w2, NULL
    // 0xf3c71c: b.eq            #0xf3c788
    // 0xf3c720: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xf3c720: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xf3c724: r0 = forward()
    //     0xf3c724: bl              #0x8cd83c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0xf3c728: b               #0xf3c788
    // 0xf3c72c: mov             x0, x5
    // 0xf3c730: StoreField: r3->field_3f = r0
    //     0xf3c730: stur            w0, [x3, #0x3f]
    //     0xf3c734: ldurb           w16, [x3, #-1]
    //     0xf3c738: ldurb           w17, [x0, #-1]
    //     0xf3c73c: and             x16, x17, x16, lsr #2
    //     0xf3c740: tst             x16, HEAP, lsr #32
    //     0xf3c744: b.eq            #0xf3c74c
    //     0xf3c748: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xf3c74c: mov             x1, x4
    // 0xf3c750: r0 = value=()
    //     0xf3c750: bl              #0x829534  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0xf3c754: ldur            x1, [fp, #-0x10]
    // 0xf3c758: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xf3c758: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xf3c75c: r0 = reverse()
    //     0xf3c75c: bl              #0x8c8688  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0xf3c760: ldur            x0, [fp, #-8]
    // 0xf3c764: LoadField: r1 = r0->field_b
    //     0xf3c764: ldur            w1, [x0, #0xb]
    // 0xf3c768: DecompressPointer r1
    //     0xf3c768: add             x1, x1, HEAP, lsl #32
    // 0xf3c76c: cmp             w1, NULL
    // 0xf3c770: b.eq            #0xf3c7c8
    // 0xf3c774: LoadField: r0 = r1->field_1b
    //     0xf3c774: ldur            w0, [x1, #0x1b]
    // 0xf3c778: DecompressPointer r0
    //     0xf3c778: add             x0, x0, HEAP, lsl #32
    // 0xf3c77c: mov             x1, x0
    // 0xf3c780: r2 = 0.000000
    //     0xf3c780: ldr             x2, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xf3c784: r0 = value=()
    //     0xf3c784: bl              #0x829534  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0xf3c788: r0 = Null
    //     0xf3c788: mov             x0, NULL
    // 0xf3c78c: LeaveFrame
    //     0xf3c78c: mov             SP, fp
    //     0xf3c790: ldp             fp, lr, [SP], #0x10
    // 0xf3c794: ret
    //     0xf3c794: ret             
    // 0xf3c798: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3c798: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3c79c: b               #0xf3c51c
    // 0xf3c7a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3c7a0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3c7a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3c7a4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3c7a8: r9 = _previousController
    //     0xf3c7a8: add             x9, PP, #0x99, lsl #12  ; [pp+0x997a0] Field <_FloatingActionButtonTransitionState@89420462._previousController@89420462>: late (offset: 0x1c)
    //     0xf3c7ac: ldr             x9, [x9, #0x7a0]
    // 0xf3c7b0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf3c7b0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xf3c7b4: r9 = _status
    //     0xf3c7b4: ldr             x9, [PP, #0x51e8]  ; [pp+0x51e8] Field <AnimationController._status@62066280>: late (offset: 0x44)
    // 0xf3c7b8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf3c7b8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xf3c7bc: r0 = NullCastErrorSharedWithFPURegs()
    //     0xf3c7bc: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xf3c7c0: r9 = _value
    //     0xf3c7c0: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0xf3c7c4: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xf3c7c4: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xf3c7c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3c7c8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateAnimations(/* No info */) {
    // ** addr: 0xf3c7cc, size: 0x55c
    // 0xf3c7cc: EnterFrame
    //     0xf3c7cc: stp             fp, lr, [SP, #-0x10]!
    //     0xf3c7d0: mov             fp, SP
    // 0xf3c7d4: AllocStack(0x38)
    //     0xf3c7d4: sub             SP, SP, #0x38
    // 0xf3c7d8: SetupParameters(_FloatingActionButtonTransitionState this /* r1 => r2, fp-0x8 */)
    //     0xf3c7d8: mov             x2, x1
    //     0xf3c7dc: stur            x1, [fp, #-8]
    // 0xf3c7e0: CheckStackOverflow
    //     0xf3c7e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3c7e4: cmp             SP, x16
    //     0xf3c7e8: b.ls            #0xf3ccf8
    // 0xf3c7ec: LoadField: r1 = r2->field_1f
    //     0xf3c7ec: ldur            w1, [x2, #0x1f]
    // 0xf3c7f0: DecompressPointer r1
    //     0xf3c7f0: add             x1, x1, HEAP, lsl #32
    // 0xf3c7f4: cmp             w1, NULL
    // 0xf3c7f8: b.eq            #0xf3c804
    // 0xf3c7fc: r0 = dispose()
    //     0xf3c7fc: bl              #0xb29014  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::dispose
    // 0xf3c800: ldur            x2, [fp, #-8]
    // 0xf3c804: LoadField: r3 = r2->field_1b
    //     0xf3c804: ldur            w3, [x2, #0x1b]
    // 0xf3c808: DecompressPointer r3
    //     0xf3c808: add             x3, x3, HEAP, lsl #32
    // 0xf3c80c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3c810: cmp             w3, w16
    // 0xf3c814: b.eq            #0xf3cd00
    // 0xf3c818: stur            x3, [fp, #-0x10]
    // 0xf3c81c: r1 = <double>
    //     0xf3c81c: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf3c820: r0 = CurvedAnimation()
    //     0xf3c820: bl              #0x915e4c  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0xf3c824: mov             x1, x0
    // 0xf3c828: ldur            x3, [fp, #-0x10]
    // 0xf3c82c: r2 = Instance_Cubic
    //     0xf3c82c: add             x2, PP, #0x1e, lsl #12  ; [pp+0x1e970] Obj!Cubic@129f541
    //     0xf3c830: ldr             x2, [x2, #0x970]
    // 0xf3c834: stur            x0, [fp, #-0x10]
    // 0xf3c838: r4 = const [0, 0x3, 0, 0x3, null]
    //     0xf3c838: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0xf3c83c: r0 = CurvedAnimation()
    //     0xf3c83c: bl              #0x915be4  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0xf3c840: ldur            x0, [fp, #-0x10]
    // 0xf3c844: ldur            x2, [fp, #-8]
    // 0xf3c848: StoreField: r2->field_1f = r0
    //     0xf3c848: stur            w0, [x2, #0x1f]
    //     0xf3c84c: ldurb           w16, [x2, #-1]
    //     0xf3c850: ldurb           w17, [x0, #-1]
    //     0xf3c854: and             x16, x17, x16, lsr #2
    //     0xf3c858: tst             x16, HEAP, lsr #32
    //     0xf3c85c: b.eq            #0xf3c864
    //     0xf3c860: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf3c864: LoadField: r1 = r2->field_23
    //     0xf3c864: ldur            w1, [x2, #0x23]
    // 0xf3c868: DecompressPointer r1
    //     0xf3c868: add             x1, x1, HEAP, lsl #32
    // 0xf3c86c: cmp             w1, NULL
    // 0xf3c870: b.eq            #0xf3c87c
    // 0xf3c874: r0 = dispose()
    //     0xf3c874: bl              #0xb29014  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::dispose
    // 0xf3c878: ldur            x2, [fp, #-8]
    // 0xf3c87c: LoadField: r3 = r2->field_1b
    //     0xf3c87c: ldur            w3, [x2, #0x1b]
    // 0xf3c880: DecompressPointer r3
    //     0xf3c880: add             x3, x3, HEAP, lsl #32
    // 0xf3c884: stur            x3, [fp, #-0x10]
    // 0xf3c888: r1 = <double>
    //     0xf3c888: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf3c88c: r0 = CurvedAnimation()
    //     0xf3c88c: bl              #0x915e4c  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0xf3c890: mov             x1, x0
    // 0xf3c894: ldur            x3, [fp, #-0x10]
    // 0xf3c898: r2 = Instance_Cubic
    //     0xf3c898: add             x2, PP, #0x1e, lsl #12  ; [pp+0x1e970] Obj!Cubic@129f541
    //     0xf3c89c: ldr             x2, [x2, #0x970]
    // 0xf3c8a0: stur            x0, [fp, #-0x10]
    // 0xf3c8a4: r4 = const [0, 0x3, 0, 0x3, null]
    //     0xf3c8a4: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0xf3c8a8: r0 = CurvedAnimation()
    //     0xf3c8a8: bl              #0x915be4  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0xf3c8ac: ldur            x0, [fp, #-0x10]
    // 0xf3c8b0: ldur            x2, [fp, #-8]
    // 0xf3c8b4: StoreField: r2->field_23 = r0
    //     0xf3c8b4: stur            w0, [x2, #0x23]
    //     0xf3c8b8: ldurb           w16, [x2, #-1]
    //     0xf3c8bc: ldurb           w17, [x0, #-1]
    //     0xf3c8c0: and             x16, x17, x16, lsr #2
    //     0xf3c8c4: tst             x16, HEAP, lsr #32
    //     0xf3c8c8: b.eq            #0xf3c8d0
    //     0xf3c8cc: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf3c8d0: r1 = <double>
    //     0xf3c8d0: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf3c8d4: r0 = Tween()
    //     0xf3c8d4: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xf3c8d8: mov             x1, x0
    // 0xf3c8dc: r0 = 1.000000
    //     0xf3c8dc: ldr             x0, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xf3c8e0: StoreField: r1->field_b = r0
    //     0xf3c8e0: stur            w0, [x1, #0xb]
    // 0xf3c8e4: StoreField: r1->field_f = r0
    //     0xf3c8e4: stur            w0, [x1, #0xf]
    // 0xf3c8e8: ldur            x2, [fp, #-0x10]
    // 0xf3c8ec: r0 = animate()
    //     0xf3c8ec: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xf3c8f0: ldur            x2, [fp, #-8]
    // 0xf3c8f4: stur            x0, [fp, #-0x10]
    // 0xf3c8f8: LoadField: r1 = r2->field_27
    //     0xf3c8f8: ldur            w1, [x2, #0x27]
    // 0xf3c8fc: DecompressPointer r1
    //     0xf3c8fc: add             x1, x1, HEAP, lsl #32
    // 0xf3c900: cmp             w1, NULL
    // 0xf3c904: b.eq            #0xf3c910
    // 0xf3c908: r0 = dispose()
    //     0xf3c908: bl              #0xb29014  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::dispose
    // 0xf3c90c: ldur            x2, [fp, #-8]
    // 0xf3c910: LoadField: r0 = r2->field_b
    //     0xf3c910: ldur            w0, [x2, #0xb]
    // 0xf3c914: DecompressPointer r0
    //     0xf3c914: add             x0, x0, HEAP, lsl #32
    // 0xf3c918: cmp             w0, NULL
    // 0xf3c91c: b.eq            #0xf3cd0c
    // 0xf3c920: LoadField: r3 = r0->field_1b
    //     0xf3c920: ldur            w3, [x0, #0x1b]
    // 0xf3c924: DecompressPointer r3
    //     0xf3c924: add             x3, x3, HEAP, lsl #32
    // 0xf3c928: stur            x3, [fp, #-0x18]
    // 0xf3c92c: r1 = <double>
    //     0xf3c92c: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf3c930: r0 = CurvedAnimation()
    //     0xf3c930: bl              #0x915e4c  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0xf3c934: mov             x1, x0
    // 0xf3c938: ldur            x3, [fp, #-0x18]
    // 0xf3c93c: r2 = Instance_Cubic
    //     0xf3c93c: add             x2, PP, #0x1e, lsl #12  ; [pp+0x1e970] Obj!Cubic@129f541
    //     0xf3c940: ldr             x2, [x2, #0x970]
    // 0xf3c944: stur            x0, [fp, #-0x18]
    // 0xf3c948: r4 = const [0, 0x3, 0, 0x3, null]
    //     0xf3c948: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0xf3c94c: r0 = CurvedAnimation()
    //     0xf3c94c: bl              #0x915be4  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0xf3c950: ldur            x0, [fp, #-0x18]
    // 0xf3c954: ldur            x2, [fp, #-8]
    // 0xf3c958: StoreField: r2->field_27 = r0
    //     0xf3c958: stur            w0, [x2, #0x27]
    //     0xf3c95c: ldurb           w16, [x2, #-1]
    //     0xf3c960: ldurb           w17, [x0, #-1]
    //     0xf3c964: and             x16, x17, x16, lsr #2
    //     0xf3c968: tst             x16, HEAP, lsr #32
    //     0xf3c96c: b.eq            #0xf3c974
    //     0xf3c970: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf3c974: LoadField: r0 = r2->field_b
    //     0xf3c974: ldur            w0, [x2, #0xb]
    // 0xf3c978: DecompressPointer r0
    //     0xf3c978: add             x0, x0, HEAP, lsl #32
    // 0xf3c97c: cmp             w0, NULL
    // 0xf3c980: b.eq            #0xf3cd10
    // 0xf3c984: LoadField: r1 = r0->field_1b
    //     0xf3c984: ldur            w1, [x0, #0x1b]
    // 0xf3c988: DecompressPointer r1
    //     0xf3c988: add             x1, x1, HEAP, lsl #32
    // 0xf3c98c: stur            x1, [fp, #-0x18]
    // 0xf3c990: r0 = LoadStaticField(0x6bc)
    //     0xf3c990: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf3c994: ldr             x0, [x0, #0xd78]
    // 0xf3c998: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3c99c: cmp             w0, w16
    // 0xf3c9a0: b.ne            #0xf3c9b0
    // 0xf3c9a4: r2 = _entranceTurnTween
    //     0xf3c9a4: add             x2, PP, #0x99, lsl #12  ; [pp+0x997f0] Field <_FloatingActionButtonTransitionState@89420462._entranceTurnTween@89420462>: static late final (offset: 0x6bc)
    //     0xf3c9a8: ldr             x2, [x2, #0x7f0]
    // 0xf3c9ac: r0 = InitLateFinalStaticField()
    //     0xf3c9ac: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xf3c9b0: mov             x1, x0
    // 0xf3c9b4: ldur            x2, [fp, #-0x18]
    // 0xf3c9b8: r0 = animate()
    //     0xf3c9b8: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xf3c9bc: mov             x3, x0
    // 0xf3c9c0: ldur            x0, [fp, #-8]
    // 0xf3c9c4: stur            x3, [fp, #-0x18]
    // 0xf3c9c8: LoadField: r1 = r0->field_b
    //     0xf3c9c8: ldur            w1, [x0, #0xb]
    // 0xf3c9cc: DecompressPointer r1
    //     0xf3c9cc: add             x1, x1, HEAP, lsl #32
    // 0xf3c9d0: cmp             w1, NULL
    // 0xf3c9d4: b.eq            #0xf3cd14
    // 0xf3c9d8: LoadField: r2 = r1->field_f
    //     0xf3c9d8: ldur            w2, [x1, #0xf]
    // 0xf3c9dc: DecompressPointer r2
    //     0xf3c9dc: add             x2, x2, HEAP, lsl #32
    // 0xf3c9e0: r1 = Instance__ScalingFabMotionAnimator
    //     0xf3c9e0: add             x1, PP, #0x84, lsl #12  ; [pp+0x84b18] Obj!_ScalingFabMotionAnimator@129ece1
    //     0xf3c9e4: ldr             x1, [x1, #0xb18]
    // 0xf3c9e8: r0 = getScaleAnimation()
    //     0xf3c9e8: bl              #0xf3cff4  ; [package:flutter/src/material/floating_action_button_location.dart] _ScalingFabMotionAnimator::getScaleAnimation
    // 0xf3c9ec: mov             x3, x0
    // 0xf3c9f0: ldur            x0, [fp, #-8]
    // 0xf3c9f4: stur            x3, [fp, #-0x20]
    // 0xf3c9f8: LoadField: r1 = r0->field_b
    //     0xf3c9f8: ldur            w1, [x0, #0xb]
    // 0xf3c9fc: DecompressPointer r1
    //     0xf3c9fc: add             x1, x1, HEAP, lsl #32
    // 0xf3ca00: cmp             w1, NULL
    // 0xf3ca04: b.eq            #0xf3cd18
    // 0xf3ca08: LoadField: r2 = r1->field_f
    //     0xf3ca08: ldur            w2, [x1, #0xf]
    // 0xf3ca0c: DecompressPointer r2
    //     0xf3ca0c: add             x2, x2, HEAP, lsl #32
    // 0xf3ca10: r1 = Instance__ScalingFabMotionAnimator
    //     0xf3ca10: add             x1, PP, #0x84, lsl #12  ; [pp+0x84b18] Obj!_ScalingFabMotionAnimator@129ece1
    //     0xf3ca14: ldr             x1, [x1, #0xb18]
    // 0xf3ca18: r0 = getRotationAnimation()
    //     0xf3ca18: bl              #0xf3cd34  ; [package:flutter/src/material/floating_action_button_location.dart] _ScalingFabMotionAnimator::getRotationAnimation
    // 0xf3ca1c: ldur            x2, [fp, #-8]
    // 0xf3ca20: stur            x0, [fp, #-0x30]
    // 0xf3ca24: LoadField: r1 = r2->field_b
    //     0xf3ca24: ldur            w1, [x2, #0xb]
    // 0xf3ca28: DecompressPointer r1
    //     0xf3ca28: add             x1, x1, HEAP, lsl #32
    // 0xf3ca2c: cmp             w1, NULL
    // 0xf3ca30: b.eq            #0xf3cd1c
    // 0xf3ca34: LoadField: r3 = r2->field_1f
    //     0xf3ca34: ldur            w3, [x2, #0x1f]
    // 0xf3ca38: DecompressPointer r3
    //     0xf3ca38: add             x3, x3, HEAP, lsl #32
    // 0xf3ca3c: stur            x3, [fp, #-0x28]
    // 0xf3ca40: cmp             w3, NULL
    // 0xf3ca44: b.eq            #0xf3cd20
    // 0xf3ca48: r1 = <double>
    //     0xf3ca48: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf3ca4c: r0 = AnimationMin()
    //     0xf3ca4c: bl              #0xf3cd28  ; AllocateAnimationMinStub -> AnimationMin<X0 bound num> (size=0x2c)
    // 0xf3ca50: mov             x2, x0
    // 0xf3ca54: ldur            x0, [fp, #-0x20]
    // 0xf3ca58: stur            x2, [fp, #-0x38]
    // 0xf3ca5c: StoreField: r2->field_1b = r0
    //     0xf3ca5c: stur            w0, [x2, #0x1b]
    // 0xf3ca60: ldur            x1, [fp, #-0x28]
    // 0xf3ca64: StoreField: r2->field_1f = r1
    //     0xf3ca64: stur            w1, [x2, #0x1f]
    // 0xf3ca68: r1 = <(dynamic this, AnimationStatus) => void?>
    //     0xf3ca68: ldr             x1, [PP, #0x5788]  ; [pp+0x5788] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    // 0xf3ca6c: r0 = ObserverList()
    //     0xf3ca6c: bl              #0x89f8bc  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0xf3ca70: mov             x3, x0
    // 0xf3ca74: r0 = false
    //     0xf3ca74: add             x0, NULL, #0x30  ; false
    // 0xf3ca78: stur            x3, [fp, #-0x28]
    // 0xf3ca7c: StoreField: r3->field_f = r0
    //     0xf3ca7c: stur            w0, [x3, #0xf]
    // 0xf3ca80: ldr             x4, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3ca84: StoreField: r3->field_13 = r4
    //     0xf3ca84: stur            w4, [x3, #0x13]
    // 0xf3ca88: r1 = <(dynamic this, AnimationStatus) => void?>
    //     0xf3ca88: ldr             x1, [PP, #0x5788]  ; [pp+0x5788] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    // 0xf3ca8c: r2 = 0
    //     0xf3ca8c: mov             x2, #0
    // 0xf3ca90: r0 = _GrowableList()
    //     0xf3ca90: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xf3ca94: ldur            x1, [fp, #-0x28]
    // 0xf3ca98: StoreField: r1->field_b = r0
    //     0xf3ca98: stur            w0, [x1, #0xb]
    //     0xf3ca9c: ldurb           w16, [x1, #-1]
    //     0xf3caa0: ldurb           w17, [x0, #-1]
    //     0xf3caa4: and             x16, x17, x16, lsr #2
    //     0xf3caa8: tst             x16, HEAP, lsr #32
    //     0xf3caac: b.eq            #0xf3cab4
    //     0xf3cab0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf3cab4: mov             x0, x1
    // 0xf3cab8: ldur            x2, [fp, #-0x38]
    // 0xf3cabc: ArrayStore: r2[0] = r0  ; List_4
    //     0xf3cabc: stur            w0, [x2, #0x17]
    //     0xf3cac0: ldurb           w16, [x2, #-1]
    //     0xf3cac4: ldurb           w17, [x0, #-1]
    //     0xf3cac8: and             x16, x17, x16, lsr #2
    //     0xf3cacc: tst             x16, HEAP, lsr #32
    //     0xf3cad0: b.eq            #0xf3cad8
    //     0xf3cad4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf3cad8: mov             x1, x2
    // 0xf3cadc: r0 = _MixinApplication68&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin()
    //     0xf3cadc: bl              #0x8e0b2c  ; [dart:mixin_deduplication] _MixinApplication68&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin::_MixinApplication68&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin
    // 0xf3cae0: ldur            x0, [fp, #-0x38]
    // 0xf3cae4: ldur            x2, [fp, #-8]
    // 0xf3cae8: StoreField: r2->field_2b = r0
    //     0xf3cae8: stur            w0, [x2, #0x2b]
    //     0xf3caec: ldurb           w16, [x2, #-1]
    //     0xf3caf0: ldurb           w17, [x0, #-1]
    //     0xf3caf4: and             x16, x17, x16, lsr #2
    //     0xf3caf8: tst             x16, HEAP, lsr #32
    //     0xf3cafc: b.eq            #0xf3cb04
    //     0xf3cb00: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf3cb04: LoadField: r0 = r2->field_27
    //     0xf3cb04: ldur            w0, [x2, #0x27]
    // 0xf3cb08: DecompressPointer r0
    //     0xf3cb08: add             x0, x0, HEAP, lsl #32
    // 0xf3cb0c: stur            x0, [fp, #-0x28]
    // 0xf3cb10: cmp             w0, NULL
    // 0xf3cb14: b.eq            #0xf3cd24
    // 0xf3cb18: r1 = <double>
    //     0xf3cb18: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf3cb1c: r0 = AnimationMin()
    //     0xf3cb1c: bl              #0xf3cd28  ; AllocateAnimationMinStub -> AnimationMin<X0 bound num> (size=0x2c)
    // 0xf3cb20: mov             x2, x0
    // 0xf3cb24: ldur            x0, [fp, #-0x20]
    // 0xf3cb28: stur            x2, [fp, #-0x38]
    // 0xf3cb2c: StoreField: r2->field_1b = r0
    //     0xf3cb2c: stur            w0, [x2, #0x1b]
    // 0xf3cb30: ldur            x0, [fp, #-0x28]
    // 0xf3cb34: StoreField: r2->field_1f = r0
    //     0xf3cb34: stur            w0, [x2, #0x1f]
    // 0xf3cb38: r1 = <(dynamic this, AnimationStatus) => void?>
    //     0xf3cb38: ldr             x1, [PP, #0x5788]  ; [pp+0x5788] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    // 0xf3cb3c: r0 = ObserverList()
    //     0xf3cb3c: bl              #0x89f8bc  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0xf3cb40: mov             x3, x0
    // 0xf3cb44: r0 = false
    //     0xf3cb44: add             x0, NULL, #0x30  ; false
    // 0xf3cb48: stur            x3, [fp, #-0x20]
    // 0xf3cb4c: StoreField: r3->field_f = r0
    //     0xf3cb4c: stur            w0, [x3, #0xf]
    // 0xf3cb50: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3cb54: StoreField: r3->field_13 = r0
    //     0xf3cb54: stur            w0, [x3, #0x13]
    // 0xf3cb58: r1 = <(dynamic this, AnimationStatus) => void?>
    //     0xf3cb58: ldr             x1, [PP, #0x5788]  ; [pp+0x5788] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    // 0xf3cb5c: r2 = 0
    //     0xf3cb5c: mov             x2, #0
    // 0xf3cb60: r0 = _GrowableList()
    //     0xf3cb60: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xf3cb64: ldur            x1, [fp, #-0x20]
    // 0xf3cb68: StoreField: r1->field_b = r0
    //     0xf3cb68: stur            w0, [x1, #0xb]
    //     0xf3cb6c: ldurb           w16, [x1, #-1]
    //     0xf3cb70: ldurb           w17, [x0, #-1]
    //     0xf3cb74: and             x16, x17, x16, lsr #2
    //     0xf3cb78: tst             x16, HEAP, lsr #32
    //     0xf3cb7c: b.eq            #0xf3cb84
    //     0xf3cb80: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf3cb84: mov             x0, x1
    // 0xf3cb88: ldur            x2, [fp, #-0x38]
    // 0xf3cb8c: ArrayStore: r2[0] = r0  ; List_4
    //     0xf3cb8c: stur            w0, [x2, #0x17]
    //     0xf3cb90: ldurb           w16, [x2, #-1]
    //     0xf3cb94: ldurb           w17, [x0, #-1]
    //     0xf3cb98: and             x16, x17, x16, lsr #2
    //     0xf3cb9c: tst             x16, HEAP, lsr #32
    //     0xf3cba0: b.eq            #0xf3cba8
    //     0xf3cba4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf3cba8: mov             x1, x2
    // 0xf3cbac: r0 = _MixinApplication68&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin()
    //     0xf3cbac: bl              #0x8e0b2c  ; [dart:mixin_deduplication] _MixinApplication68&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin::_MixinApplication68&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin
    // 0xf3cbb0: ldur            x0, [fp, #-0x38]
    // 0xf3cbb4: ldur            x2, [fp, #-8]
    // 0xf3cbb8: StoreField: r2->field_33 = r0
    //     0xf3cbb8: stur            w0, [x2, #0x33]
    //     0xf3cbbc: ldurb           w16, [x2, #-1]
    //     0xf3cbc0: ldurb           w17, [x0, #-1]
    //     0xf3cbc4: and             x16, x17, x16, lsr #2
    //     0xf3cbc8: tst             x16, HEAP, lsr #32
    //     0xf3cbcc: b.eq            #0xf3cbd4
    //     0xf3cbd0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf3cbd4: r1 = <double>
    //     0xf3cbd4: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf3cbd8: r0 = TrainHoppingAnimation()
    //     0xf3cbd8: bl              #0xb72c84  ; AllocateTrainHoppingAnimationStub -> TrainHoppingAnimation (size=0x2c)
    // 0xf3cbdc: mov             x1, x0
    // 0xf3cbe0: ldur            x2, [fp, #-0x10]
    // 0xf3cbe4: ldur            x3, [fp, #-0x30]
    // 0xf3cbe8: stur            x0, [fp, #-0x10]
    // 0xf3cbec: r4 = const [0, 0x3, 0, 0x3, null]
    //     0xf3cbec: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0xf3cbf0: r0 = TrainHoppingAnimation()
    //     0xf3cbf0: bl              #0xb724a0  ; [package:flutter/src/animation/animations.dart] TrainHoppingAnimation::TrainHoppingAnimation
    // 0xf3cbf4: ldur            x0, [fp, #-0x10]
    // 0xf3cbf8: ldur            x2, [fp, #-8]
    // 0xf3cbfc: StoreField: r2->field_2f = r0
    //     0xf3cbfc: stur            w0, [x2, #0x2f]
    //     0xf3cc00: ldurb           w16, [x2, #-1]
    //     0xf3cc04: ldurb           w17, [x0, #-1]
    //     0xf3cc08: and             x16, x17, x16, lsr #2
    //     0xf3cc0c: tst             x16, HEAP, lsr #32
    //     0xf3cc10: b.eq            #0xf3cc18
    //     0xf3cc14: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf3cc18: r1 = <double>
    //     0xf3cc18: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf3cc1c: r0 = TrainHoppingAnimation()
    //     0xf3cc1c: bl              #0xb72c84  ; AllocateTrainHoppingAnimationStub -> TrainHoppingAnimation (size=0x2c)
    // 0xf3cc20: mov             x1, x0
    // 0xf3cc24: ldur            x2, [fp, #-0x18]
    // 0xf3cc28: ldur            x3, [fp, #-0x30]
    // 0xf3cc2c: stur            x0, [fp, #-0x10]
    // 0xf3cc30: r4 = const [0, 0x3, 0, 0x3, null]
    //     0xf3cc30: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0xf3cc34: r0 = TrainHoppingAnimation()
    //     0xf3cc34: bl              #0xb724a0  ; [package:flutter/src/animation/animations.dart] TrainHoppingAnimation::TrainHoppingAnimation
    // 0xf3cc38: ldur            x0, [fp, #-0x10]
    // 0xf3cc3c: ldur            x2, [fp, #-8]
    // 0xf3cc40: StoreField: r2->field_3b = r0
    //     0xf3cc40: stur            w0, [x2, #0x3b]
    //     0xf3cc44: ldurb           w16, [x2, #-1]
    //     0xf3cc48: ldurb           w17, [x0, #-1]
    //     0xf3cc4c: and             x16, x17, x16, lsr #2
    //     0xf3cc50: tst             x16, HEAP, lsr #32
    //     0xf3cc54: b.eq            #0xf3cc5c
    //     0xf3cc58: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf3cc5c: LoadField: r0 = r2->field_33
    //     0xf3cc5c: ldur            w0, [x2, #0x33]
    // 0xf3cc60: DecompressPointer r0
    //     0xf3cc60: add             x0, x0, HEAP, lsl #32
    // 0xf3cc64: stur            x0, [fp, #-0x10]
    // 0xf3cc68: r1 = <double>
    //     0xf3cc68: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf3cc6c: r0 = CurveTween()
    //     0xf3cc6c: bl              #0xb280f4  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0xf3cc70: mov             x1, x0
    // 0xf3cc74: r0 = Instance_Interval
    //     0xf3cc74: add             x0, PP, #0x99, lsl #12  ; [pp+0x997f8] Obj!Interval@129fb31
    //     0xf3cc78: ldr             x0, [x0, #0x7f8]
    // 0xf3cc7c: StoreField: r1->field_b = r0
    //     0xf3cc7c: stur            w0, [x1, #0xb]
    // 0xf3cc80: ldur            x2, [fp, #-0x10]
    // 0xf3cc84: r0 = animate()
    //     0xf3cc84: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xf3cc88: ldur            x3, [fp, #-8]
    // 0xf3cc8c: StoreField: r3->field_37 = r0
    //     0xf3cc8c: stur            w0, [x3, #0x37]
    //     0xf3cc90: ldurb           w16, [x3, #-1]
    //     0xf3cc94: ldurb           w17, [x0, #-1]
    //     0xf3cc98: and             x16, x17, x16, lsr #2
    //     0xf3cc9c: tst             x16, HEAP, lsr #32
    //     0xf3cca0: b.eq            #0xf3cca8
    //     0xf3cca4: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xf3cca8: LoadField: r0 = r3->field_33
    //     0xf3cca8: ldur            w0, [x3, #0x33]
    // 0xf3ccac: DecompressPointer r0
    //     0xf3ccac: add             x0, x0, HEAP, lsl #32
    // 0xf3ccb0: mov             x2, x3
    // 0xf3ccb4: stur            x0, [fp, #-0x10]
    // 0xf3ccb8: r1 = Function '_onProgressChanged@89420462':.
    //     0xf3ccb8: add             x1, PP, #0x99, lsl #12  ; [pp+0x99800] AnonymousClosure: (0xf3d134), in [package:flutter/src/material/scaffold.dart] _FloatingActionButtonTransitionState::_onProgressChanged (0xf3d16c)
    //     0xf3ccbc: ldr             x1, [x1, #0x800]
    // 0xf3ccc0: r0 = AllocateClosure()
    //     0xf3ccc0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf3ccc4: ldur            x1, [fp, #-0x10]
    // 0xf3ccc8: mov             x2, x0
    // 0xf3cccc: stur            x0, [fp, #-0x10]
    // 0xf3ccd0: r0 = addListener()
    //     0xf3ccd0: bl              #0xd040fc  ; [dart:mixin_deduplication] _MixinApplication68&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin::addListener
    // 0xf3ccd4: ldur            x0, [fp, #-8]
    // 0xf3ccd8: LoadField: r1 = r0->field_2b
    //     0xf3ccd8: ldur            w1, [x0, #0x2b]
    // 0xf3ccdc: DecompressPointer r1
    //     0xf3ccdc: add             x1, x1, HEAP, lsl #32
    // 0xf3cce0: ldur            x2, [fp, #-0x10]
    // 0xf3cce4: r0 = addListener()
    //     0xf3cce4: bl              #0xd040fc  ; [dart:mixin_deduplication] _MixinApplication68&Animation&AnimationLazyListenerMixin&AnimationLocalListenersMixin::addListener
    // 0xf3cce8: r0 = Null
    //     0xf3cce8: mov             x0, NULL
    // 0xf3ccec: LeaveFrame
    //     0xf3ccec: mov             SP, fp
    //     0xf3ccf0: ldp             fp, lr, [SP], #0x10
    // 0xf3ccf4: ret
    //     0xf3ccf4: ret             
    // 0xf3ccf8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3ccf8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3ccfc: b               #0xf3c7ec
    // 0xf3cd00: r9 = _previousController
    //     0xf3cd00: add             x9, PP, #0x99, lsl #12  ; [pp+0x997a0] Field <_FloatingActionButtonTransitionState@89420462._previousController@89420462>: late (offset: 0x1c)
    //     0xf3cd04: ldr             x9, [x9, #0x7a0]
    // 0xf3cd08: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf3cd08: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xf3cd0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3cd0c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3cd10: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3cd10: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3cd14: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3cd14: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3cd18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3cd18: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3cd1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3cd1c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3cd20: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3cd20: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf3cd24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3cd24: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _onProgressChanged(dynamic) {
    // ** addr: 0xf3d134, size: 0x38
    // 0xf3d134: EnterFrame
    //     0xf3d134: stp             fp, lr, [SP, #-0x10]!
    //     0xf3d138: mov             fp, SP
    // 0xf3d13c: ldr             x0, [fp, #0x10]
    // 0xf3d140: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf3d140: ldur            w1, [x0, #0x17]
    // 0xf3d144: DecompressPointer r1
    //     0xf3d144: add             x1, x1, HEAP, lsl #32
    // 0xf3d148: CheckStackOverflow
    //     0xf3d148: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3d14c: cmp             SP, x16
    //     0xf3d150: b.ls            #0xf3d164
    // 0xf3d154: r0 = _onProgressChanged()
    //     0xf3d154: bl              #0xf3d16c  ; [package:flutter/src/material/scaffold.dart] _FloatingActionButtonTransitionState::_onProgressChanged
    // 0xf3d158: LeaveFrame
    //     0xf3d158: mov             SP, fp
    //     0xf3d15c: ldp             fp, lr, [SP], #0x10
    // 0xf3d160: ret
    //     0xf3d160: ret             
    // 0xf3d164: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3d164: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3d168: b               #0xf3d154
  }
  _ _onProgressChanged(/* No info */) {
    // ** addr: 0xf3d16c, size: 0xdc
    // 0xf3d16c: EnterFrame
    //     0xf3d16c: stp             fp, lr, [SP, #-0x10]!
    //     0xf3d170: mov             fp, SP
    // 0xf3d174: AllocStack(0x10)
    //     0xf3d174: sub             SP, SP, #0x10
    // 0xf3d178: SetupParameters(_FloatingActionButtonTransitionState this /* r1 => r2, fp-0x8 */)
    //     0xf3d178: mov             x2, x1
    //     0xf3d17c: stur            x1, [fp, #-8]
    // 0xf3d180: CheckStackOverflow
    //     0xf3d180: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3d184: cmp             SP, x16
    //     0xf3d188: b.ls            #0xf3d228
    // 0xf3d18c: LoadField: r1 = r2->field_2b
    //     0xf3d18c: ldur            w1, [x2, #0x2b]
    // 0xf3d190: DecompressPointer r1
    //     0xf3d190: add             x1, x1, HEAP, lsl #32
    // 0xf3d194: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3d198: cmp             w1, w16
    // 0xf3d19c: b.eq            #0xf3d230
    // 0xf3d1a0: r0 = LoadClassIdInstr(r1)
    //     0xf3d1a0: ldur            x0, [x1, #-1]
    //     0xf3d1a4: ubfx            x0, x0, #0xc, #0x14
    // 0xf3d1a8: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0xf3d1a8: mov             x17, #0x4e2e
    //     0xf3d1ac: movk            x17, #1, lsl #16
    //     0xf3d1b0: add             lr, x0, x17
    //     0xf3d1b4: ldr             lr, [x21, lr, lsl #3]
    //     0xf3d1b8: blr             lr
    // 0xf3d1bc: mov             x3, x0
    // 0xf3d1c0: ldur            x2, [fp, #-8]
    // 0xf3d1c4: stur            x3, [fp, #-0x10]
    // 0xf3d1c8: LoadField: r1 = r2->field_33
    //     0xf3d1c8: ldur            w1, [x2, #0x33]
    // 0xf3d1cc: DecompressPointer r1
    //     0xf3d1cc: add             x1, x1, HEAP, lsl #32
    // 0xf3d1d0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3d1d4: cmp             w1, w16
    // 0xf3d1d8: b.eq            #0xf3d23c
    // 0xf3d1dc: r0 = LoadClassIdInstr(r1)
    //     0xf3d1dc: ldur            x0, [x1, #-1]
    //     0xf3d1e0: ubfx            x0, x0, #0xc, #0x14
    // 0xf3d1e4: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0xf3d1e4: mov             x17, #0x4e2e
    //     0xf3d1e8: movk            x17, #1, lsl #16
    //     0xf3d1ec: add             lr, x0, x17
    //     0xf3d1f0: ldr             lr, [x21, lr, lsl #3]
    //     0xf3d1f4: blr             lr
    // 0xf3d1f8: mov             x1, x0
    // 0xf3d1fc: ldur            x0, [fp, #-0x10]
    // 0xf3d200: LoadField: d0 = r0->field_7
    //     0xf3d200: ldur            d0, [x0, #7]
    // 0xf3d204: LoadField: d1 = r1->field_7
    //     0xf3d204: ldur            d1, [x1, #7]
    // 0xf3d208: fmax            v2.2d, v0.2d, v1.2d
    // 0xf3d20c: ldur            x1, [fp, #-8]
    // 0xf3d210: mov             v0.16b, v2.16b
    // 0xf3d214: r0 = _updateGeometryScale()
    //     0xf3d214: bl              #0xf3d248  ; [package:flutter/src/material/scaffold.dart] _FloatingActionButtonTransitionState::_updateGeometryScale
    // 0xf3d218: r0 = Null
    //     0xf3d218: mov             x0, NULL
    // 0xf3d21c: LeaveFrame
    //     0xf3d21c: mov             SP, fp
    //     0xf3d220: ldp             fp, lr, [SP], #0x10
    // 0xf3d224: ret
    //     0xf3d224: ret             
    // 0xf3d228: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3d228: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3d22c: b               #0xf3d18c
    // 0xf3d230: r9 = _previousScaleAnimation
    //     0xf3d230: add             x9, PP, #0x99, lsl #12  ; [pp+0x997a8] Field <_FloatingActionButtonTransitionState@89420462._previousScaleAnimation@89420462>: late (offset: 0x2c)
    //     0xf3d234: ldr             x9, [x9, #0x7a8]
    // 0xf3d238: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf3d238: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xf3d23c: r9 = _currentScaleAnimation
    //     0xf3d23c: add             x9, PP, #0x99, lsl #12  ; [pp+0x997b8] Field <_FloatingActionButtonTransitionState@89420462._currentScaleAnimation@89420462>: late (offset: 0x34)
    //     0xf3d240: ldr             x9, [x9, #0x7b8]
    // 0xf3d244: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf3d244: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _updateGeometryScale(/* No info */) {
    // ** addr: 0xf3d248, size: 0xa0
    // 0xf3d248: EnterFrame
    //     0xf3d248: stp             fp, lr, [SP, #-0x10]!
    //     0xf3d24c: mov             fp, SP
    // 0xf3d250: AllocStack(0x8)
    //     0xf3d250: sub             SP, SP, #8
    // 0xf3d254: CheckStackOverflow
    //     0xf3d254: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3d258: cmp             SP, x16
    //     0xf3d25c: b.ls            #0xf3d2c4
    // 0xf3d260: LoadField: r0 = r1->field_b
    //     0xf3d260: ldur            w0, [x1, #0xb]
    // 0xf3d264: DecompressPointer r0
    //     0xf3d264: add             x0, x0, HEAP, lsl #32
    // 0xf3d268: cmp             w0, NULL
    // 0xf3d26c: b.eq            #0xf3d2cc
    // 0xf3d270: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf3d270: ldur            w1, [x0, #0x17]
    // 0xf3d274: DecompressPointer r1
    //     0xf3d274: add             x1, x1, HEAP, lsl #32
    // 0xf3d278: r0 = inline_Allocate_Double()
    //     0xf3d278: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xf3d27c: add             x0, x0, #0x10
    //     0xf3d280: cmp             x2, x0
    //     0xf3d284: b.ls            #0xf3d2d0
    //     0xf3d288: str             x0, [THR, #0x60]  ; THR::top
    //     0xf3d28c: sub             x0, x0, #0xf
    //     0xf3d290: mov             x2, #0xe19c
    //     0xf3d294: movk            x2, #3, lsl #16
    //     0xf3d298: stur            x2, [x0, #-1]
    // 0xf3d29c: dmb             ishst
    // 0xf3d2a0: StoreField: r0->field_7 = d0
    //     0xf3d2a0: stur            d0, [x0, #7]
    // 0xf3d2a4: str             x0, [SP]
    // 0xf3d2a8: r4 = const [0, 0x2, 0x1, 0x1, floatingActionButtonScale, 0x1, null]
    //     0xf3d2a8: add             x4, PP, #0x99, lsl #12  ; [pp+0x99808] List(7) [0, 0x2, 0x1, 0x1, "floatingActionButtonScale", 0x1, Null]
    //     0xf3d2ac: ldr             x4, [x4, #0x808]
    // 0xf3d2b0: r0 = _updateWith()
    //     0xf3d2b0: bl              #0xf3d2e8  ; [package:flutter/src/material/scaffold.dart] _ScaffoldGeometryNotifier::_updateWith
    // 0xf3d2b4: r0 = Null
    //     0xf3d2b4: mov             x0, NULL
    // 0xf3d2b8: LeaveFrame
    //     0xf3d2b8: mov             SP, fp
    //     0xf3d2bc: ldp             fp, lr, [SP], #0x10
    // 0xf3d2c0: ret
    //     0xf3d2c0: ret             
    // 0xf3d2c4: r0 = StackOverflowSharedWithFPURegs()
    //     0xf3d2c4: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xf3d2c8: b               #0xf3d260
    // 0xf3d2cc: r0 = NullCastErrorSharedWithFPURegs()
    //     0xf3d2cc: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xf3d2d0: SaveReg d0
    //     0xf3d2d0: str             q0, [SP, #-0x10]!
    // 0xf3d2d4: SaveReg r1
    //     0xf3d2d4: str             x1, [SP, #-8]!
    // 0xf3d2d8: r0 = AllocateDouble()
    //     0xf3d2d8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xf3d2dc: RestoreReg r1
    //     0xf3d2dc: ldr             x1, [SP], #8
    // 0xf3d2e0: RestoreReg d0
    //     0xf3d2e0: ldr             q0, [SP], #0x10
    // 0xf3d2e4: b               #0xf3d2a0
  }
  static Animatable<double> _entranceTurnTween() {
    // ** addr: 0xf3d478, size: 0x74
    // 0xf3d478: EnterFrame
    //     0xf3d478: stp             fp, lr, [SP, #-0x10]!
    //     0xf3d47c: mov             fp, SP
    // 0xf3d480: AllocStack(0x8)
    //     0xf3d480: sub             SP, SP, #8
    // 0xf3d484: CheckStackOverflow
    //     0xf3d484: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3d488: cmp             SP, x16
    //     0xf3d48c: b.ls            #0xf3d4e4
    // 0xf3d490: r1 = <double>
    //     0xf3d490: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf3d494: r0 = Tween()
    //     0xf3d494: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xf3d498: mov             x2, x0
    // 0xf3d49c: r0 = 0.875000
    //     0xf3d49c: add             x0, PP, #0x99, lsl #12  ; [pp+0x99898] 0.875
    //     0xf3d4a0: ldr             x0, [x0, #0x898]
    // 0xf3d4a4: stur            x2, [fp, #-8]
    // 0xf3d4a8: StoreField: r2->field_b = r0
    //     0xf3d4a8: stur            w0, [x2, #0xb]
    // 0xf3d4ac: r0 = 1.000000
    //     0xf3d4ac: ldr             x0, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xf3d4b0: StoreField: r2->field_f = r0
    //     0xf3d4b0: stur            w0, [x2, #0xf]
    // 0xf3d4b4: r1 = <double>
    //     0xf3d4b4: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf3d4b8: r0 = CurveTween()
    //     0xf3d4b8: bl              #0xb280f4  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0xf3d4bc: mov             x1, x0
    // 0xf3d4c0: r0 = Instance_Cubic
    //     0xf3d4c0: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e970] Obj!Cubic@129f541
    //     0xf3d4c4: ldr             x0, [x0, #0x970]
    // 0xf3d4c8: StoreField: r1->field_b = r0
    //     0xf3d4c8: stur            w0, [x1, #0xb]
    // 0xf3d4cc: mov             x2, x1
    // 0xf3d4d0: ldur            x1, [fp, #-8]
    // 0xf3d4d4: r0 = chain()
    //     0xf3d4d4: bl              #0xb28080  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0xf3d4d8: LeaveFrame
    //     0xf3d4d8: mov             SP, fp
    //     0xf3d4dc: ldp             fp, lr, [SP], #0x10
    // 0xf3d4e0: ret
    //     0xf3d4e0: ret             
    // 0xf3d4e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3d4e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3d4e8: b               #0xf3d490
  }
  _ _disposeAnimations(/* No info */) {
    // ** addr: 0xf3d4ec, size: 0x84
    // 0xf3d4ec: EnterFrame
    //     0xf3d4ec: stp             fp, lr, [SP, #-0x10]!
    //     0xf3d4f0: mov             fp, SP
    // 0xf3d4f4: AllocStack(0x8)
    //     0xf3d4f4: sub             SP, SP, #8
    // 0xf3d4f8: SetupParameters(_FloatingActionButtonTransitionState this /* r1 => r0, fp-0x8 */)
    //     0xf3d4f8: mov             x0, x1
    //     0xf3d4fc: stur            x1, [fp, #-8]
    // 0xf3d500: CheckStackOverflow
    //     0xf3d500: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3d504: cmp             SP, x16
    //     0xf3d508: b.ls            #0xf3d550
    // 0xf3d50c: LoadField: r1 = r0->field_2f
    //     0xf3d50c: ldur            w1, [x0, #0x2f]
    // 0xf3d510: DecompressPointer r1
    //     0xf3d510: add             x1, x1, HEAP, lsl #32
    // 0xf3d514: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3d518: cmp             w1, w16
    // 0xf3d51c: b.eq            #0xf3d558
    // 0xf3d520: r0 = dispose()
    //     0xf3d520: bl              #0xb7363c  ; [package:flutter/src/animation/animations.dart] TrainHoppingAnimation::dispose
    // 0xf3d524: ldur            x0, [fp, #-8]
    // 0xf3d528: LoadField: r1 = r0->field_3b
    //     0xf3d528: ldur            w1, [x0, #0x3b]
    // 0xf3d52c: DecompressPointer r1
    //     0xf3d52c: add             x1, x1, HEAP, lsl #32
    // 0xf3d530: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf3d534: cmp             w1, w16
    // 0xf3d538: b.eq            #0xf3d564
    // 0xf3d53c: r0 = dispose()
    //     0xf3d53c: bl              #0xb7363c  ; [package:flutter/src/animation/animations.dart] TrainHoppingAnimation::dispose
    // 0xf3d540: r0 = Null
    //     0xf3d540: mov             x0, NULL
    // 0xf3d544: LeaveFrame
    //     0xf3d544: mov             SP, fp
    //     0xf3d548: ldp             fp, lr, [SP], #0x10
    // 0xf3d54c: ret
    //     0xf3d54c: ret             
    // 0xf3d550: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3d550: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3d554: b               #0xf3d50c
    // 0xf3d558: r9 = _previousRotationAnimation
    //     0xf3d558: add             x9, PP, #0x99, lsl #12  ; [pp+0x997b0] Field <_FloatingActionButtonTransitionState@89420462._previousRotationAnimation@89420462>: late (offset: 0x30)
    //     0xf3d55c: ldr             x9, [x9, #0x7b0]
    // 0xf3d560: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf3d560: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xf3d564: r9 = _currentRotationAnimation
    //     0xf3d564: add             x9, PP, #0x99, lsl #12  ; [pp+0x997c0] Field <_FloatingActionButtonTransitionState@89420462._currentRotationAnimation@89420462>: late (offset: 0x3c)
    //     0xf3d568: ldr             x9, [x9, #0x7c0]
    // 0xf3d56c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xf3d56c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0xf7b318, size: 0x104
    // 0xf7b318: EnterFrame
    //     0xf7b318: stp             fp, lr, [SP, #-0x10]!
    //     0xf7b31c: mov             fp, SP
    // 0xf7b320: AllocStack(0x18)
    //     0xf7b320: sub             SP, SP, #0x18
    // 0xf7b324: SetupParameters(_FloatingActionButtonTransitionState this /* r1 => r2, fp-0x8 */)
    //     0xf7b324: mov             x2, x1
    //     0xf7b328: stur            x1, [fp, #-8]
    // 0xf7b32c: CheckStackOverflow
    //     0xf7b32c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf7b330: cmp             SP, x16
    //     0xf7b334: b.ls            #0xf7b410
    // 0xf7b338: r1 = <double>
    //     0xf7b338: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf7b33c: r0 = AnimationController()
    //     0xf7b33c: bl              #0x87522c  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0xf7b340: stur            x0, [fp, #-0x10]
    // 0xf7b344: r16 = Instance_Duration
    //     0xf7b344: add             x16, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xf7b348: ldr             x16, [x16, #0x318]
    // 0xf7b34c: str             x16, [SP]
    // 0xf7b350: mov             x1, x0
    // 0xf7b354: ldur            x2, [fp, #-8]
    // 0xf7b358: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0xf7b358: add             x4, PP, #0x15, lsl #12  ; [pp+0x155a0] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0xf7b35c: ldr             x4, [x4, #0x5a0]
    // 0xf7b360: r0 = AnimationController()
    //     0xf7b360: bl              #0x874ea4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0xf7b364: ldur            x2, [fp, #-8]
    // 0xf7b368: r1 = Function '_handlePreviousAnimationStatusChanged@89420462':.
    //     0xf7b368: add             x1, PP, #0x99, lsl #12  ; [pp+0x998a0] AnonymousClosure: (0xf7b41c), in [package:flutter/src/material/scaffold.dart] _FloatingActionButtonTransitionState::_handlePreviousAnimationStatusChanged (0xf7b458)
    //     0xf7b36c: ldr             x1, [x1, #0x8a0]
    // 0xf7b370: r0 = AllocateClosure()
    //     0xf7b370: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf7b374: ldur            x1, [fp, #-0x10]
    // 0xf7b378: mov             x2, x0
    // 0xf7b37c: r0 = addStatusListener()
    //     0xf7b37c: bl              #0x1254cc0  ; [dart:mixin_deduplication] _MixinApplication456&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::addStatusListener
    // 0xf7b380: ldur            x0, [fp, #-0x10]
    // 0xf7b384: ldur            x2, [fp, #-8]
    // 0xf7b388: StoreField: r2->field_1b = r0
    //     0xf7b388: stur            w0, [x2, #0x1b]
    //     0xf7b38c: ldurb           w16, [x2, #-1]
    //     0xf7b390: ldurb           w17, [x0, #-1]
    //     0xf7b394: and             x16, x17, x16, lsr #2
    //     0xf7b398: tst             x16, HEAP, lsr #32
    //     0xf7b39c: b.eq            #0xf7b3a4
    //     0xf7b3a0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf7b3a4: mov             x1, x2
    // 0xf7b3a8: r0 = _updateAnimations()
    //     0xf7b3a8: bl              #0xf3c7cc  ; [package:flutter/src/material/scaffold.dart] _FloatingActionButtonTransitionState::_updateAnimations
    // 0xf7b3ac: ldur            x0, [fp, #-8]
    // 0xf7b3b0: LoadField: r1 = r0->field_b
    //     0xf7b3b0: ldur            w1, [x0, #0xb]
    // 0xf7b3b4: DecompressPointer r1
    //     0xf7b3b4: add             x1, x1, HEAP, lsl #32
    // 0xf7b3b8: cmp             w1, NULL
    // 0xf7b3bc: b.eq            #0xf7b418
    // 0xf7b3c0: LoadField: r2 = r1->field_b
    //     0xf7b3c0: ldur            w2, [x1, #0xb]
    // 0xf7b3c4: DecompressPointer r2
    //     0xf7b3c4: add             x2, x2, HEAP, lsl #32
    // 0xf7b3c8: cmp             w2, NULL
    // 0xf7b3cc: b.eq            #0xf7b3f4
    // 0xf7b3d0: LoadField: r2 = r1->field_1b
    //     0xf7b3d0: ldur            w2, [x1, #0x1b]
    // 0xf7b3d4: DecompressPointer r2
    //     0xf7b3d4: add             x2, x2, HEAP, lsl #32
    // 0xf7b3d8: mov             x1, x2
    // 0xf7b3dc: r2 = 1.000000
    //     0xf7b3dc: ldr             x2, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xf7b3e0: r0 = value=()
    //     0xf7b3e0: bl              #0x829534  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0xf7b3e4: ldur            x1, [fp, #-8]
    // 0xf7b3e8: d0 = 1.000000
    //     0xf7b3e8: fmov            d0, #1.00000000
    // 0xf7b3ec: r0 = _updateGeometryScale()
    //     0xf7b3ec: bl              #0xf3d248  ; [package:flutter/src/material/scaffold.dart] _FloatingActionButtonTransitionState::_updateGeometryScale
    // 0xf7b3f0: b               #0xf7b400
    // 0xf7b3f4: ldur            x1, [fp, #-8]
    // 0xf7b3f8: d0 = 0.000000
    //     0xf7b3f8: eor             v0.16b, v0.16b, v0.16b
    // 0xf7b3fc: r0 = _updateGeometryScale()
    //     0xf7b3fc: bl              #0xf3d248  ; [package:flutter/src/material/scaffold.dart] _FloatingActionButtonTransitionState::_updateGeometryScale
    // 0xf7b400: r0 = Null
    //     0xf7b400: mov             x0, NULL
    // 0xf7b404: LeaveFrame
    //     0xf7b404: mov             SP, fp
    //     0xf7b408: ldp             fp, lr, [SP], #0x10
    // 0xf7b40c: ret
    //     0xf7b40c: ret             
    // 0xf7b410: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf7b410: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf7b414: b               #0xf7b338
    // 0xf7b418: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf7b418: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handlePreviousAnimationStatusChanged(dynamic, AnimationStatus) {
    // ** addr: 0xf7b41c, size: 0x3c
    // 0xf7b41c: EnterFrame
    //     0xf7b41c: stp             fp, lr, [SP, #-0x10]!
    //     0xf7b420: mov             fp, SP
    // 0xf7b424: ldr             x0, [fp, #0x18]
    // 0xf7b428: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf7b428: ldur            w1, [x0, #0x17]
    // 0xf7b42c: DecompressPointer r1
    //     0xf7b42c: add             x1, x1, HEAP, lsl #32
    // 0xf7b430: CheckStackOverflow
    //     0xf7b430: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf7b434: cmp             SP, x16
    //     0xf7b438: b.ls            #0xf7b450
    // 0xf7b43c: ldr             x2, [fp, #0x10]
    // 0xf7b440: r0 = _handlePreviousAnimationStatusChanged()
    //     0xf7b440: bl              #0xf7b458  ; [package:flutter/src/material/scaffold.dart] _FloatingActionButtonTransitionState::_handlePreviousAnimationStatusChanged
    // 0xf7b444: LeaveFrame
    //     0xf7b444: mov             SP, fp
    //     0xf7b448: ldp             fp, lr, [SP], #0x10
    // 0xf7b44c: ret
    //     0xf7b44c: ret             
    // 0xf7b450: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf7b450: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf7b454: b               #0xf7b43c
  }
  _ _handlePreviousAnimationStatusChanged(/* No info */) {
    // ** addr: 0xf7b458, size: 0x70
    // 0xf7b458: EnterFrame
    //     0xf7b458: stp             fp, lr, [SP, #-0x10]!
    //     0xf7b45c: mov             fp, SP
    // 0xf7b460: AllocStack(0x10)
    //     0xf7b460: sub             SP, SP, #0x10
    // 0xf7b464: SetupParameters(_FloatingActionButtonTransitionState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xf7b464: stur            x1, [fp, #-8]
    //     0xf7b468: stur            x2, [fp, #-0x10]
    // 0xf7b46c: CheckStackOverflow
    //     0xf7b46c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf7b470: cmp             SP, x16
    //     0xf7b474: b.ls            #0xf7b4c0
    // 0xf7b478: r1 = 2
    //     0xf7b478: mov             x1, #2
    // 0xf7b47c: r0 = AllocateContext()
    //     0xf7b47c: bl              #0x13de838  ; AllocateContextStub
    // 0xf7b480: mov             x1, x0
    // 0xf7b484: ldur            x0, [fp, #-8]
    // 0xf7b488: StoreField: r1->field_f = r0
    //     0xf7b488: stur            w0, [x1, #0xf]
    // 0xf7b48c: ldur            x2, [fp, #-0x10]
    // 0xf7b490: StoreField: r1->field_13 = r2
    //     0xf7b490: stur            w2, [x1, #0x13]
    // 0xf7b494: mov             x2, x1
    // 0xf7b498: r1 = Function '<anonymous closure>':.
    //     0xf7b498: add             x1, PP, #0x99, lsl #12  ; [pp+0x998a8] AnonymousClosure: (0xf7b4c8), in [package:flutter/src/material/scaffold.dart] _FloatingActionButtonTransitionState::_handlePreviousAnimationStatusChanged (0xf7b458)
    //     0xf7b49c: ldr             x1, [x1, #0x8a8]
    // 0xf7b4a0: r0 = AllocateClosure()
    //     0xf7b4a0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf7b4a4: ldur            x1, [fp, #-8]
    // 0xf7b4a8: mov             x2, x0
    // 0xf7b4ac: r0 = setState()
    //     0xf7b4ac: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xf7b4b0: r0 = Null
    //     0xf7b4b0: mov             x0, NULL
    // 0xf7b4b4: LeaveFrame
    //     0xf7b4b4: mov             SP, fp
    //     0xf7b4b8: ldp             fp, lr, [SP], #0x10
    // 0xf7b4bc: ret
    //     0xf7b4bc: ret             
    // 0xf7b4c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf7b4c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf7b4c4: b               #0xf7b478
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xf7b4c8, size: 0x88
    // 0xf7b4c8: EnterFrame
    //     0xf7b4c8: stp             fp, lr, [SP, #-0x10]!
    //     0xf7b4cc: mov             fp, SP
    // 0xf7b4d0: ldr             x0, [fp, #0x10]
    // 0xf7b4d4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf7b4d4: ldur            w1, [x0, #0x17]
    // 0xf7b4d8: DecompressPointer r1
    //     0xf7b4d8: add             x1, x1, HEAP, lsl #32
    // 0xf7b4dc: CheckStackOverflow
    //     0xf7b4dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf7b4e0: cmp             SP, x16
    //     0xf7b4e4: b.ls            #0xf7b544
    // 0xf7b4e8: LoadField: r0 = r1->field_f
    //     0xf7b4e8: ldur            w0, [x1, #0xf]
    // 0xf7b4ec: DecompressPointer r0
    //     0xf7b4ec: add             x0, x0, HEAP, lsl #32
    // 0xf7b4f0: LoadField: r2 = r0->field_b
    //     0xf7b4f0: ldur            w2, [x0, #0xb]
    // 0xf7b4f4: DecompressPointer r2
    //     0xf7b4f4: add             x2, x2, HEAP, lsl #32
    // 0xf7b4f8: cmp             w2, NULL
    // 0xf7b4fc: b.eq            #0xf7b54c
    // 0xf7b500: LoadField: r0 = r2->field_b
    //     0xf7b500: ldur            w0, [x2, #0xb]
    // 0xf7b504: DecompressPointer r0
    //     0xf7b504: add             x0, x0, HEAP, lsl #32
    // 0xf7b508: cmp             w0, NULL
    // 0xf7b50c: b.eq            #0xf7b534
    // 0xf7b510: LoadField: r0 = r1->field_13
    //     0xf7b510: ldur            w0, [x1, #0x13]
    // 0xf7b514: DecompressPointer r0
    //     0xf7b514: add             x0, x0, HEAP, lsl #32
    // 0xf7b518: r16 = Instance_AnimationStatus
    //     0xf7b518: ldr             x16, [PP, #0x51a8]  ; [pp+0x51a8] Obj!AnimationStatus@12c61c1
    // 0xf7b51c: cmp             w0, w16
    // 0xf7b520: b.ne            #0xf7b534
    // 0xf7b524: LoadField: r1 = r2->field_1b
    //     0xf7b524: ldur            w1, [x2, #0x1b]
    // 0xf7b528: DecompressPointer r1
    //     0xf7b528: add             x1, x1, HEAP, lsl #32
    // 0xf7b52c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xf7b52c: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xf7b530: r0 = forward()
    //     0xf7b530: bl              #0x8cd83c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0xf7b534: r0 = Null
    //     0xf7b534: mov             x0, NULL
    // 0xf7b538: LeaveFrame
    //     0xf7b538: mov             SP, fp
    //     0xf7b53c: ldp             fp, lr, [SP], #0x10
    // 0xf7b540: ret
    //     0xf7b540: ret             
    // 0xf7b544: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf7b544: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf7b548: b               #0xf7b4e8
    // 0xf7b54c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf7b54c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10ddb18, size: 0xb4
    // 0x10ddb18: EnterFrame
    //     0x10ddb18: stp             fp, lr, [SP, #-0x10]!
    //     0x10ddb1c: mov             fp, SP
    // 0x10ddb20: AllocStack(0x8)
    //     0x10ddb20: sub             SP, SP, #8
    // 0x10ddb24: SetupParameters(_FloatingActionButtonTransitionState this /* r1 => r0, fp-0x8 */)
    //     0x10ddb24: mov             x0, x1
    //     0x10ddb28: stur            x1, [fp, #-8]
    // 0x10ddb2c: CheckStackOverflow
    //     0x10ddb2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10ddb30: cmp             SP, x16
    //     0x10ddb34: b.ls            #0x10ddbb8
    // 0x10ddb38: LoadField: r1 = r0->field_1b
    //     0x10ddb38: ldur            w1, [x0, #0x1b]
    // 0x10ddb3c: DecompressPointer r1
    //     0x10ddb3c: add             x1, x1, HEAP, lsl #32
    // 0x10ddb40: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10ddb44: cmp             w1, w16
    // 0x10ddb48: b.eq            #0x10ddbc0
    // 0x10ddb4c: r0 = dispose()
    //     0x10ddb4c: bl              #0x9164f4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x10ddb50: ldur            x0, [fp, #-8]
    // 0x10ddb54: LoadField: r1 = r0->field_1f
    //     0x10ddb54: ldur            w1, [x0, #0x1f]
    // 0x10ddb58: DecompressPointer r1
    //     0x10ddb58: add             x1, x1, HEAP, lsl #32
    // 0x10ddb5c: cmp             w1, NULL
    // 0x10ddb60: b.eq            #0x10ddb6c
    // 0x10ddb64: r0 = dispose()
    //     0x10ddb64: bl              #0xb29014  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::dispose
    // 0x10ddb68: ldur            x0, [fp, #-8]
    // 0x10ddb6c: LoadField: r1 = r0->field_23
    //     0x10ddb6c: ldur            w1, [x0, #0x23]
    // 0x10ddb70: DecompressPointer r1
    //     0x10ddb70: add             x1, x1, HEAP, lsl #32
    // 0x10ddb74: cmp             w1, NULL
    // 0x10ddb78: b.eq            #0x10ddb84
    // 0x10ddb7c: r0 = dispose()
    //     0x10ddb7c: bl              #0xb29014  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::dispose
    // 0x10ddb80: ldur            x0, [fp, #-8]
    // 0x10ddb84: LoadField: r1 = r0->field_27
    //     0x10ddb84: ldur            w1, [x0, #0x27]
    // 0x10ddb88: DecompressPointer r1
    //     0x10ddb88: add             x1, x1, HEAP, lsl #32
    // 0x10ddb8c: cmp             w1, NULL
    // 0x10ddb90: b.eq            #0x10ddb98
    // 0x10ddb94: r0 = dispose()
    //     0x10ddb94: bl              #0xb29014  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::dispose
    // 0x10ddb98: ldur            x1, [fp, #-8]
    // 0x10ddb9c: r0 = _disposeAnimations()
    //     0x10ddb9c: bl              #0xf3d4ec  ; [package:flutter/src/material/scaffold.dart] _FloatingActionButtonTransitionState::_disposeAnimations
    // 0x10ddba0: ldur            x1, [fp, #-8]
    // 0x10ddba4: r0 = dispose()
    //     0x10ddba4: bl              #0x10ddbcc  ; [dart:mixin_deduplication] _MixinApplication99&State&TickerProviderStateMixin::dispose
    // 0x10ddba8: r0 = Null
    //     0x10ddba8: mov             x0, NULL
    // 0x10ddbac: LeaveFrame
    //     0x10ddbac: mov             SP, fp
    //     0x10ddbb0: ldp             fp, lr, [SP], #0x10
    // 0x10ddbb4: ret
    //     0x10ddbb4: ret             
    // 0x10ddbb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10ddbb8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10ddbbc: b               #0x10ddb38
    // 0x10ddbc0: r9 = _previousController
    //     0x10ddbc0: add             x9, PP, #0x99, lsl #12  ; [pp+0x997a0] Field <_FloatingActionButtonTransitionState@89420462._previousController@89420462>: late (offset: 0x1c)
    //     0x10ddbc4: ldr             x9, [x9, #0x7a0]
    // 0x10ddbc8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x10ddbc8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 5714, size: 0x38, field offset: 0x1c
class ScaffoldMessengerState extends _MixinApplication98&State&TickerProviderStateMixin {

  late bool _accessibleNavigation; // offset: 0x34

  _ build(/* No info */) {
    // ** addr: 0xd34d00, size: 0x1d0
    // 0xd34d00: EnterFrame
    //     0xd34d00: stp             fp, lr, [SP, #-0x10]!
    //     0xd34d04: mov             fp, SP
    // 0xd34d08: AllocStack(0x30)
    //     0xd34d08: sub             SP, SP, #0x30
    // 0xd34d0c: SetupParameters(ScaffoldMessengerState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xd34d0c: mov             x0, x1
    //     0xd34d10: stur            x1, [fp, #-8]
    //     0xd34d14: mov             x1, x2
    //     0xd34d18: stur            x2, [fp, #-0x10]
    // 0xd34d1c: CheckStackOverflow
    //     0xd34d1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd34d20: cmp             SP, x16
    //     0xd34d24: b.ls            #0xd34eb8
    // 0xd34d28: r1 = 2
    //     0xd34d28: mov             x1, #2
    // 0xd34d2c: r0 = AllocateContext()
    //     0xd34d2c: bl              #0x13de838  ; AllocateContextStub
    // 0xd34d30: mov             x2, x0
    // 0xd34d34: ldur            x0, [fp, #-8]
    // 0xd34d38: stur            x2, [fp, #-0x18]
    // 0xd34d3c: StoreField: r2->field_f = r0
    //     0xd34d3c: stur            w0, [x2, #0xf]
    // 0xd34d40: ldur            x1, [fp, #-0x10]
    // 0xd34d44: r0 = accessibleNavigationOf()
    //     0xd34d44: bl              #0xd34edc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::accessibleNavigationOf
    // 0xd34d48: mov             x1, x0
    // 0xd34d4c: ldur            x0, [fp, #-8]
    // 0xd34d50: StoreField: r0->field_33 = r1
    //     0xd34d50: stur            w1, [x0, #0x33]
    // 0xd34d54: LoadField: r1 = r0->field_27
    //     0xd34d54: ldur            w1, [x0, #0x27]
    // 0xd34d58: DecompressPointer r1
    //     0xd34d58: add             x1, x1, HEAP, lsl #32
    // 0xd34d5c: stur            x1, [fp, #-0x20]
    // 0xd34d60: LoadField: r2 = r1->field_f
    //     0xd34d60: ldur            x2, [x1, #0xf]
    // 0xd34d64: ArrayLoad: r3 = r1[0]  ; List_8
    //     0xd34d64: ldur            x3, [x1, #0x17]
    // 0xd34d68: cmp             x2, x3
    // 0xd34d6c: b.eq            #0xd34e78
    // 0xd34d70: r16 = <Object?>
    //     0xd34d70: ldr             x16, [PP, #0x37c8]  ; [pp+0x37c8] TypeArguments: <Object?>
    // 0xd34d74: ldur            lr, [fp, #-0x10]
    // 0xd34d78: stp             lr, x16, [SP]
    // 0xd34d7c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd34d7c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd34d80: r0 = of()
    //     0xd34d80: bl              #0xbfcc54  ; [package:flutter/src/widgets/routes.dart] ModalRoute::of
    // 0xd34d84: cmp             w0, NULL
    // 0xd34d88: b.eq            #0xd34d98
    // 0xd34d8c: mov             x1, x0
    // 0xd34d90: r0 = isCurrent()
    //     0xd34d90: bl              #0x82eeb4  ; [package:flutter/src/widgets/navigator.dart] Route::isCurrent
    // 0xd34d94: tbnz            w0, #4, #0xd34e70
    // 0xd34d98: ldur            x0, [fp, #-8]
    // 0xd34d9c: LoadField: r1 = r0->field_2b
    //     0xd34d9c: ldur            w1, [x0, #0x2b]
    // 0xd34da0: DecompressPointer r1
    //     0xd34da0: add             x1, x1, HEAP, lsl #32
    // 0xd34da4: cmp             w1, NULL
    // 0xd34da8: b.eq            #0xd34ec0
    // 0xd34dac: LoadField: r2 = r1->field_43
    //     0xd34dac: ldur            w2, [x1, #0x43]
    // 0xd34db0: DecompressPointer r2
    //     0xd34db0: add             x2, x2, HEAP, lsl #32
    // 0xd34db4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd34db8: cmp             w2, w16
    // 0xd34dbc: b.eq            #0xd34ec4
    // 0xd34dc0: r16 = Instance_AnimationStatus
    //     0xd34dc0: ldr             x16, [PP, #0x51a0]  ; [pp+0x51a0] Obj!AnimationStatus@12c61a1
    // 0xd34dc4: cmp             w2, w16
    // 0xd34dc8: b.ne            #0xd34e68
    // 0xd34dcc: LoadField: r1 = r0->field_2f
    //     0xd34dcc: ldur            w1, [x0, #0x2f]
    // 0xd34dd0: DecompressPointer r1
    //     0xd34dd0: add             x1, x1, HEAP, lsl #32
    // 0xd34dd4: cmp             w1, NULL
    // 0xd34dd8: b.ne            #0xd34e60
    // 0xd34ddc: ldur            x2, [fp, #-0x18]
    // 0xd34de0: ldur            x1, [fp, #-0x20]
    // 0xd34de4: r0 = first()
    //     0xd34de4: bl              #0xb067e0  ; [dart:collection] ListQueue::first
    // 0xd34de8: LoadField: r1 = r0->field_b
    //     0xd34de8: ldur            w1, [x0, #0xb]
    // 0xd34dec: DecompressPointer r1
    //     0xd34dec: add             x1, x1, HEAP, lsl #32
    // 0xd34df0: mov             x0, x1
    // 0xd34df4: ldur            x2, [fp, #-0x18]
    // 0xd34df8: StoreField: r2->field_13 = r0
    //     0xd34df8: stur            w0, [x2, #0x13]
    //     0xd34dfc: ldurb           w16, [x2, #-1]
    //     0xd34e00: ldurb           w17, [x0, #-1]
    //     0xd34e04: and             x16, x17, x16, lsr #2
    //     0xd34e08: tst             x16, HEAP, lsr #32
    //     0xd34e0c: b.eq            #0xd34e14
    //     0xd34e10: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd34e14: LoadField: r0 = r1->field_3f
    //     0xd34e14: ldur            w0, [x1, #0x3f]
    // 0xd34e18: DecompressPointer r0
    //     0xd34e18: add             x0, x0, HEAP, lsl #32
    // 0xd34e1c: stur            x0, [fp, #-0x10]
    // 0xd34e20: r1 = Function '<anonymous closure>':.
    //     0xd34e20: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3d18] AnonymousClosure: (0xd34f28), in [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::build (0xd34d00)
    //     0xd34e24: ldr             x1, [x1, #0xd18]
    // 0xd34e28: r0 = AllocateClosure()
    //     0xd34e28: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd34e2c: ldur            x2, [fp, #-0x10]
    // 0xd34e30: mov             x3, x0
    // 0xd34e34: r1 = Null
    //     0xd34e34: mov             x1, NULL
    // 0xd34e38: r0 = Timer()
    //     0xd34e38: bl              #0x7eed74  ; [dart:async] Timer::Timer
    // 0xd34e3c: ldur            x1, [fp, #-8]
    // 0xd34e40: StoreField: r1->field_2f = r0
    //     0xd34e40: stur            w0, [x1, #0x2f]
    //     0xd34e44: ldurb           w16, [x1, #-1]
    //     0xd34e48: ldurb           w17, [x0, #-1]
    //     0xd34e4c: and             x16, x17, x16, lsr #2
    //     0xd34e50: tst             x16, HEAP, lsr #32
    //     0xd34e54: b.eq            #0xd34e5c
    //     0xd34e58: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd34e5c: b               #0xd34e7c
    // 0xd34e60: mov             x1, x0
    // 0xd34e64: b               #0xd34e7c
    // 0xd34e68: mov             x1, x0
    // 0xd34e6c: b               #0xd34e7c
    // 0xd34e70: ldur            x1, [fp, #-8]
    // 0xd34e74: b               #0xd34e7c
    // 0xd34e78: mov             x1, x0
    // 0xd34e7c: LoadField: r0 = r1->field_b
    //     0xd34e7c: ldur            w0, [x1, #0xb]
    // 0xd34e80: DecompressPointer r0
    //     0xd34e80: add             x0, x0, HEAP, lsl #32
    // 0xd34e84: cmp             w0, NULL
    // 0xd34e88: b.eq            #0xd34ecc
    // 0xd34e8c: LoadField: r2 = r0->field_b
    //     0xd34e8c: ldur            w2, [x0, #0xb]
    // 0xd34e90: DecompressPointer r2
    //     0xd34e90: add             x2, x2, HEAP, lsl #32
    // 0xd34e94: stur            x2, [fp, #-0x10]
    // 0xd34e98: r0 = _ScaffoldMessengerScope()
    //     0xd34e98: bl              #0xd34ed0  ; Allocate_ScaffoldMessengerScopeStub -> _ScaffoldMessengerScope (size=0x14)
    // 0xd34e9c: ldur            x1, [fp, #-8]
    // 0xd34ea0: StoreField: r0->field_f = r1
    //     0xd34ea0: stur            w1, [x0, #0xf]
    // 0xd34ea4: ldur            x1, [fp, #-0x10]
    // 0xd34ea8: StoreField: r0->field_b = r1
    //     0xd34ea8: stur            w1, [x0, #0xb]
    // 0xd34eac: LeaveFrame
    //     0xd34eac: mov             SP, fp
    //     0xd34eb0: ldp             fp, lr, [SP], #0x10
    // 0xd34eb4: ret
    //     0xd34eb4: ret             
    // 0xd34eb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd34eb8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd34ebc: b               #0xd34d28
    // 0xd34ec0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd34ec0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd34ec4: r9 = _status
    //     0xd34ec4: ldr             x9, [PP, #0x51e8]  ; [pp+0x51e8] Field <AnimationController._status@62066280>: late (offset: 0x44)
    // 0xd34ec8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd34ec8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd34ecc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd34ecc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xd34f28, size: 0x60
    // 0xd34f28: EnterFrame
    //     0xd34f28: stp             fp, lr, [SP, #-0x10]!
    //     0xd34f2c: mov             fp, SP
    // 0xd34f30: AllocStack(0x8)
    //     0xd34f30: sub             SP, SP, #8
    // 0xd34f34: SetupParameters([dynamic _ /* r0 */])
    //     0xd34f34: ldr             x0, [fp, #0x10]
    //     0xd34f38: ldur            w1, [x0, #0x17]
    //     0xd34f3c: add             x1, x1, HEAP, lsl #32
    // 0xd34f40: CheckStackOverflow
    //     0xd34f40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd34f44: cmp             SP, x16
    //     0xd34f48: b.ls            #0xd34f80
    // 0xd34f4c: LoadField: r0 = r1->field_f
    //     0xd34f4c: ldur            w0, [x1, #0xf]
    // 0xd34f50: DecompressPointer r0
    //     0xd34f50: add             x0, x0, HEAP, lsl #32
    // 0xd34f54: r16 = Instance_SnackBarClosedReason
    //     0xd34f54: add             x16, PP, #0xa3, lsl #12  ; [pp+0xa3d20] Obj!SnackBarClosedReason@12c4da1
    //     0xd34f58: ldr             x16, [x16, #0xd20]
    // 0xd34f5c: str             x16, [SP]
    // 0xd34f60: mov             x1, x0
    // 0xd34f64: r4 = const [0, 0x2, 0x1, 0x1, reason, 0x1, null]
    //     0xd34f64: add             x4, PP, #0xa3, lsl #12  ; [pp+0xa3d28] List(7) [0, 0x2, 0x1, 0x1, "reason", 0x1, Null]
    //     0xd34f68: ldr             x4, [x4, #0xd28]
    // 0xd34f6c: r0 = hideCurrentSnackBar()
    //     0xd34f6c: bl              #0xd34f88  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::hideCurrentSnackBar
    // 0xd34f70: r0 = Null
    //     0xd34f70: mov             x0, NULL
    // 0xd34f74: LeaveFrame
    //     0xd34f74: mov             SP, fp
    //     0xd34f78: ldp             fp, lr, [SP], #0x10
    // 0xd34f7c: ret
    //     0xd34f7c: ret             
    // 0xd34f80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd34f80: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd34f84: b               #0xd34f4c
  }
  _ hideCurrentSnackBar(/* No info */) {
    // ** addr: 0xd34f88, size: 0x1ec
    // 0xd34f88: EnterFrame
    //     0xd34f88: stp             fp, lr, [SP, #-0x10]!
    //     0xd34f8c: mov             fp, SP
    // 0xd34f90: AllocStack(0x30)
    //     0xd34f90: sub             SP, SP, #0x30
    // 0xd34f94: SetupParameters(ScaffoldMessengerState this /* r1 => r1, fp-0x10 */, {dynamic reason = Instance_SnackBarClosedReason /* r0, fp-0x8 */})
    //     0xd34f94: stur            x1, [fp, #-0x10]
    //     0xd34f98: ldur            w0, [x4, #0x13]
    //     0xd34f9c: ldur            w2, [x4, #0x1f]
    //     0xd34fa0: add             x2, x2, HEAP, lsl #32
    //     0xd34fa4: ldr             x16, [PP, #0x7a40]  ; [pp+0x7a40] "reason"
    //     0xd34fa8: cmp             w2, w16
    //     0xd34fac: b.ne            #0xd34fc8
    //     0xd34fb0: ldur            w2, [x4, #0x23]
    //     0xd34fb4: add             x2, x2, HEAP, lsl #32
    //     0xd34fb8: sub             w3, w0, w2
    //     0xd34fbc: add             x0, fp, w3, sxtw #2
    //     0xd34fc0: ldr             x0, [x0, #8]
    //     0xd34fc4: b               #0xd34fd0
    //     0xd34fc8: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e810] Obj!SnackBarClosedReason@12c4d81
    //     0xd34fcc: ldr             x0, [x0, #0x810]
    //     0xd34fd0: stur            x0, [fp, #-8]
    // 0xd34fd4: CheckStackOverflow
    //     0xd34fd4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd34fd8: cmp             SP, x16
    //     0xd34fdc: b.ls            #0xd35154
    // 0xd34fe0: r1 = 2
    //     0xd34fe0: mov             x1, #2
    // 0xd34fe4: r0 = AllocateContext()
    //     0xd34fe4: bl              #0x13de838  ; AllocateContextStub
    // 0xd34fe8: mov             x2, x0
    // 0xd34fec: ldur            x0, [fp, #-8]
    // 0xd34ff0: stur            x2, [fp, #-0x18]
    // 0xd34ff4: StoreField: r2->field_f = r0
    //     0xd34ff4: stur            w0, [x2, #0xf]
    // 0xd34ff8: ldur            x0, [fp, #-0x10]
    // 0xd34ffc: LoadField: r3 = r0->field_27
    //     0xd34ffc: ldur            w3, [x0, #0x27]
    // 0xd35000: DecompressPointer r3
    //     0xd35000: add             x3, x3, HEAP, lsl #32
    // 0xd35004: stur            x3, [fp, #-8]
    // 0xd35008: LoadField: r1 = r3->field_f
    //     0xd35008: ldur            x1, [x3, #0xf]
    // 0xd3500c: ArrayLoad: r4 = r3[0]  ; List_8
    //     0xd3500c: ldur            x4, [x3, #0x17]
    // 0xd35010: cmp             x1, x4
    // 0xd35014: b.eq            #0xd35030
    // 0xd35018: LoadField: r1 = r0->field_2b
    //     0xd35018: ldur            w1, [x0, #0x2b]
    // 0xd3501c: DecompressPointer r1
    //     0xd3501c: add             x1, x1, HEAP, lsl #32
    // 0xd35020: cmp             w1, NULL
    // 0xd35024: b.eq            #0xd3515c
    // 0xd35028: r0 = isDismissed()
    //     0xd35028: bl              #0xb6c464  ; [package:flutter/src/animation/animation.dart] Animation::isDismissed
    // 0xd3502c: tbnz            w0, #4, #0xd35040
    // 0xd35030: r0 = Null
    //     0xd35030: mov             x0, NULL
    // 0xd35034: LeaveFrame
    //     0xd35034: mov             SP, fp
    //     0xd35038: ldp             fp, lr, [SP], #0x10
    // 0xd3503c: ret
    //     0xd3503c: ret             
    // 0xd35040: ldur            x0, [fp, #-0x10]
    // 0xd35044: ldur            x2, [fp, #-0x18]
    // 0xd35048: ldur            x1, [fp, #-8]
    // 0xd3504c: r0 = first()
    //     0xd3504c: bl              #0xb067e0  ; [dart:collection] ListQueue::first
    // 0xd35050: LoadField: r3 = r0->field_f
    //     0xd35050: ldur            w3, [x0, #0xf]
    // 0xd35054: DecompressPointer r3
    //     0xd35054: add             x3, x3, HEAP, lsl #32
    // 0xd35058: mov             x0, x3
    // 0xd3505c: ldur            x4, [fp, #-0x18]
    // 0xd35060: stur            x3, [fp, #-8]
    // 0xd35064: StoreField: r4->field_13 = r0
    //     0xd35064: stur            w0, [x4, #0x13]
    //     0xd35068: ldurb           w16, [x4, #-1]
    //     0xd3506c: ldurb           w17, [x0, #-1]
    //     0xd35070: and             x16, x17, x16, lsr #2
    //     0xd35074: tst             x16, HEAP, lsr #32
    //     0xd35078: b.eq            #0xd35080
    //     0xd3507c: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xd35080: ldur            x0, [fp, #-0x10]
    // 0xd35084: LoadField: r1 = r0->field_33
    //     0xd35084: ldur            w1, [x0, #0x33]
    // 0xd35088: DecompressPointer r1
    //     0xd35088: add             x1, x1, HEAP, lsl #32
    // 0xd3508c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd35090: cmp             w1, w16
    // 0xd35094: b.eq            #0xd35160
    // 0xd35098: tbnz            w1, #4, #0xd350d4
    // 0xd3509c: LoadField: r1 = r0->field_2b
    //     0xd3509c: ldur            w1, [x0, #0x2b]
    // 0xd350a0: DecompressPointer r1
    //     0xd350a0: add             x1, x1, HEAP, lsl #32
    // 0xd350a4: cmp             w1, NULL
    // 0xd350a8: b.eq            #0xd3516c
    // 0xd350ac: r2 = 0.000000
    //     0xd350ac: ldr             x2, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xd350b0: r0 = value=()
    //     0xd350b0: bl              #0x829534  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0xd350b4: ldur            x2, [fp, #-0x18]
    // 0xd350b8: LoadField: r0 = r2->field_f
    //     0xd350b8: ldur            w0, [x2, #0xf]
    // 0xd350bc: DecompressPointer r0
    //     0xd350bc: add             x0, x0, HEAP, lsl #32
    // 0xd350c0: str             x0, [SP]
    // 0xd350c4: ldur            x1, [fp, #-8]
    // 0xd350c8: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0xd350c8: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0xd350cc: r0 = complete()
    //     0xd350cc: bl              #0x128a5ec  ; [dart:async] _AsyncCompleter::complete
    // 0xd350d0: b               #0xd3511c
    // 0xd350d4: mov             x2, x4
    // 0xd350d8: LoadField: r1 = r0->field_2b
    //     0xd350d8: ldur            w1, [x0, #0x2b]
    // 0xd350dc: DecompressPointer r1
    //     0xd350dc: add             x1, x1, HEAP, lsl #32
    // 0xd350e0: cmp             w1, NULL
    // 0xd350e4: b.eq            #0xd35170
    // 0xd350e8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd350e8: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd350ec: r0 = reverse()
    //     0xd350ec: bl              #0x8c8688  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0xd350f0: ldur            x2, [fp, #-0x18]
    // 0xd350f4: r1 = Function '<anonymous closure>':.
    //     0xd350f4: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e818] AnonymousClosure: (0xd35174), in [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::hideCurrentSnackBar (0xd34f88)
    //     0xd350f8: ldr             x1, [x1, #0x818]
    // 0xd350fc: stur            x0, [fp, #-8]
    // 0xd35100: r0 = AllocateClosure()
    //     0xd35100: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd35104: r16 = <void?>
    //     0xd35104: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xd35108: ldur            lr, [fp, #-8]
    // 0xd3510c: stp             lr, x16, [SP, #8]
    // 0xd35110: str             x0, [SP]
    // 0xd35114: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xd35114: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xd35118: r0 = then()
    //     0xd35118: bl              #0x13083d8  ; [package:flutter/src/scheduler/ticker.dart] TickerFuture::then
    // 0xd3511c: ldur            x0, [fp, #-0x10]
    // 0xd35120: LoadField: r1 = r0->field_2f
    //     0xd35120: ldur            w1, [x0, #0x2f]
    // 0xd35124: DecompressPointer r1
    //     0xd35124: add             x1, x1, HEAP, lsl #32
    // 0xd35128: cmp             w1, NULL
    // 0xd3512c: b.ne            #0xd35138
    // 0xd35130: mov             x1, x0
    // 0xd35134: b               #0xd35140
    // 0xd35138: r0 = cancel()
    //     0xd35138: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0xd3513c: ldur            x1, [fp, #-0x10]
    // 0xd35140: StoreField: r1->field_2f = rNULL
    //     0xd35140: stur            NULL, [x1, #0x2f]
    // 0xd35144: r0 = Null
    //     0xd35144: mov             x0, NULL
    // 0xd35148: LeaveFrame
    //     0xd35148: mov             SP, fp
    //     0xd3514c: ldp             fp, lr, [SP], #0x10
    // 0xd35150: ret
    //     0xd35150: ret             
    // 0xd35154: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd35154: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd35158: b               #0xd34fe0
    // 0xd3515c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd3515c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd35160: r9 = _accessibleNavigation
    //     0xd35160: add             x9, PP, #0x1e, lsl #12  ; [pp+0x1e820] Field <ScaffoldMessengerState._accessibleNavigation@89420462>: late (offset: 0x34)
    //     0xd35164: ldr             x9, [x9, #0x820]
    // 0xd35168: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd35168: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd3516c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd3516c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd35170: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd35170: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Null <anonymous closure>(dynamic, void) {
    // ** addr: 0xd35174, size: 0x70
    // 0xd35174: EnterFrame
    //     0xd35174: stp             fp, lr, [SP, #-0x10]!
    //     0xd35178: mov             fp, SP
    // 0xd3517c: AllocStack(0x8)
    //     0xd3517c: sub             SP, SP, #8
    // 0xd35180: SetupParameters([dynamic _ /* r0 */])
    //     0xd35180: ldr             x0, [fp, #0x18]
    //     0xd35184: ldur            w1, [x0, #0x17]
    //     0xd35188: add             x1, x1, HEAP, lsl #32
    // 0xd3518c: CheckStackOverflow
    //     0xd3518c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd35190: cmp             SP, x16
    //     0xd35194: b.ls            #0xd351dc
    // 0xd35198: LoadField: r0 = r1->field_13
    //     0xd35198: ldur            w0, [x1, #0x13]
    // 0xd3519c: DecompressPointer r0
    //     0xd3519c: add             x0, x0, HEAP, lsl #32
    // 0xd351a0: LoadField: r2 = r0->field_b
    //     0xd351a0: ldur            w2, [x0, #0xb]
    // 0xd351a4: DecompressPointer r2
    //     0xd351a4: add             x2, x2, HEAP, lsl #32
    // 0xd351a8: LoadField: r3 = r2->field_b
    //     0xd351a8: ldur            x3, [x2, #0xb]
    // 0xd351ac: tst             x3, #0x1e
    // 0xd351b0: b.ne            #0xd351cc
    // 0xd351b4: LoadField: r2 = r1->field_f
    //     0xd351b4: ldur            w2, [x1, #0xf]
    // 0xd351b8: DecompressPointer r2
    //     0xd351b8: add             x2, x2, HEAP, lsl #32
    // 0xd351bc: str             x2, [SP]
    // 0xd351c0: mov             x1, x0
    // 0xd351c4: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0xd351c4: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0xd351c8: r0 = complete()
    //     0xd351c8: bl              #0x128a5ec  ; [dart:async] _AsyncCompleter::complete
    // 0xd351cc: r0 = Null
    //     0xd351cc: mov             x0, NULL
    // 0xd351d0: LeaveFrame
    //     0xd351d0: mov             SP, fp
    //     0xd351d4: ldp             fp, lr, [SP], #0x10
    // 0xd351d8: ret
    //     0xd351d8: ret             
    // 0xd351dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd351dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd351e0: b               #0xd35198
  }
  _ removeCurrentSnackBar(/* No info */) {
    // ** addr: 0xdfe3a0, size: 0xd0
    // 0xdfe3a0: EnterFrame
    //     0xdfe3a0: stp             fp, lr, [SP, #-0x10]!
    //     0xdfe3a4: mov             fp, SP
    // 0xdfe3a8: AllocStack(0x18)
    //     0xdfe3a8: sub             SP, SP, #0x18
    // 0xdfe3ac: SetupParameters(ScaffoldMessengerState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xdfe3ac: mov             x0, x1
    //     0xdfe3b0: stur            x1, [fp, #-8]
    //     0xdfe3b4: stur            x2, [fp, #-0x10]
    // 0xdfe3b8: CheckStackOverflow
    //     0xdfe3b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdfe3bc: cmp             SP, x16
    //     0xdfe3c0: b.ls            #0xdfe464
    // 0xdfe3c4: LoadField: r1 = r0->field_27
    //     0xdfe3c4: ldur            w1, [x0, #0x27]
    // 0xdfe3c8: DecompressPointer r1
    //     0xdfe3c8: add             x1, x1, HEAP, lsl #32
    // 0xdfe3cc: LoadField: r3 = r1->field_f
    //     0xdfe3cc: ldur            x3, [x1, #0xf]
    // 0xdfe3d0: ArrayLoad: r4 = r1[0]  ; List_8
    //     0xdfe3d0: ldur            x4, [x1, #0x17]
    // 0xdfe3d4: cmp             x3, x4
    // 0xdfe3d8: b.ne            #0xdfe3ec
    // 0xdfe3dc: r0 = Null
    //     0xdfe3dc: mov             x0, NULL
    // 0xdfe3e0: LeaveFrame
    //     0xdfe3e0: mov             SP, fp
    //     0xdfe3e4: ldp             fp, lr, [SP], #0x10
    // 0xdfe3e8: ret
    //     0xdfe3e8: ret             
    // 0xdfe3ec: r0 = first()
    //     0xdfe3ec: bl              #0xb067e0  ; [dart:collection] ListQueue::first
    // 0xdfe3f0: LoadField: r1 = r0->field_f
    //     0xdfe3f0: ldur            w1, [x0, #0xf]
    // 0xdfe3f4: DecompressPointer r1
    //     0xdfe3f4: add             x1, x1, HEAP, lsl #32
    // 0xdfe3f8: LoadField: r0 = r1->field_b
    //     0xdfe3f8: ldur            w0, [x1, #0xb]
    // 0xdfe3fc: DecompressPointer r0
    //     0xdfe3fc: add             x0, x0, HEAP, lsl #32
    // 0xdfe400: LoadField: r2 = r0->field_b
    //     0xdfe400: ldur            x2, [x0, #0xb]
    // 0xdfe404: tst             x2, #0x1e
    // 0xdfe408: b.ne            #0xdfe41c
    // 0xdfe40c: ldur            x16, [fp, #-0x10]
    // 0xdfe410: str             x16, [SP]
    // 0xdfe414: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0xdfe414: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0xdfe418: r0 = complete()
    //     0xdfe418: bl              #0x128a5ec  ; [dart:async] _AsyncCompleter::complete
    // 0xdfe41c: ldur            x0, [fp, #-8]
    // 0xdfe420: LoadField: r1 = r0->field_2f
    //     0xdfe420: ldur            w1, [x0, #0x2f]
    // 0xdfe424: DecompressPointer r1
    //     0xdfe424: add             x1, x1, HEAP, lsl #32
    // 0xdfe428: cmp             w1, NULL
    // 0xdfe42c: b.eq            #0xdfe438
    // 0xdfe430: r0 = cancel()
    //     0xdfe430: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0xdfe434: ldur            x0, [fp, #-8]
    // 0xdfe438: StoreField: r0->field_2f = rNULL
    //     0xdfe438: stur            NULL, [x0, #0x2f]
    // 0xdfe43c: LoadField: r1 = r0->field_2b
    //     0xdfe43c: ldur            w1, [x0, #0x2b]
    // 0xdfe440: DecompressPointer r1
    //     0xdfe440: add             x1, x1, HEAP, lsl #32
    // 0xdfe444: cmp             w1, NULL
    // 0xdfe448: b.eq            #0xdfe46c
    // 0xdfe44c: r2 = 0.000000
    //     0xdfe44c: ldr             x2, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xdfe450: r0 = value=()
    //     0xdfe450: bl              #0x829534  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0xdfe454: r0 = Null
    //     0xdfe454: mov             x0, NULL
    // 0xdfe458: LeaveFrame
    //     0xdfe458: mov             SP, fp
    //     0xdfe45c: ldp             fp, lr, [SP], #0x10
    // 0xdfe460: ret
    //     0xdfe460: ret             
    // 0xdfe464: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdfe464: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdfe468: b               #0xdfe3c4
    // 0xdfe46c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfe46c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ showSnackBar(/* No info */) {
    // ** addr: 0xe61a24, size: 0x224
    // 0xe61a24: EnterFrame
    //     0xe61a24: stp             fp, lr, [SP, #-0x10]!
    //     0xe61a28: mov             fp, SP
    // 0xe61a2c: AllocStack(0x30)
    //     0xe61a2c: sub             SP, SP, #0x30
    // 0xe61a30: SetupParameters(ScaffoldMessengerState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xe61a30: mov             x0, x1
    //     0xe61a34: stur            x1, [fp, #-8]
    //     0xe61a38: mov             x1, x2
    //     0xe61a3c: stur            x2, [fp, #-0x10]
    // 0xe61a40: CheckStackOverflow
    //     0xe61a40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe61a44: cmp             SP, x16
    //     0xe61a48: b.ls            #0xe61c3c
    // 0xe61a4c: r1 = 2
    //     0xe61a4c: mov             x1, #2
    // 0xe61a50: r0 = AllocateContext()
    //     0xe61a50: bl              #0x13de838  ; AllocateContextStub
    // 0xe61a54: mov             x2, x0
    // 0xe61a58: ldur            x0, [fp, #-8]
    // 0xe61a5c: stur            x2, [fp, #-0x18]
    // 0xe61a60: StoreField: r2->field_f = r0
    //     0xe61a60: stur            w0, [x2, #0xf]
    // 0xe61a64: LoadField: r1 = r0->field_2b
    //     0xe61a64: ldur            w1, [x0, #0x2b]
    // 0xe61a68: DecompressPointer r1
    //     0xe61a68: add             x1, x1, HEAP, lsl #32
    // 0xe61a6c: cmp             w1, NULL
    // 0xe61a70: b.ne            #0xe61ac8
    // 0xe61a74: mov             x1, x0
    // 0xe61a78: r0 = createAnimationController()
    //     0xe61a78: bl              #0xe62130  ; [package:flutter/src/material/snack_bar.dart] SnackBar::createAnimationController
    // 0xe61a7c: ldur            x2, [fp, #-8]
    // 0xe61a80: r1 = Function '_handleSnackBarStatusChanged@89420462':.
    //     0xe61a80: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e7e8] AnonymousClosure: (0xe6225c), in [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::_handleSnackBarStatusChanged (0xe62298)
    //     0xe61a84: ldr             x1, [x1, #0x7e8]
    // 0xe61a88: stur            x0, [fp, #-0x20]
    // 0xe61a8c: r0 = AllocateClosure()
    //     0xe61a8c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xe61a90: ldur            x1, [fp, #-0x20]
    // 0xe61a94: mov             x2, x0
    // 0xe61a98: r0 = addStatusListener()
    //     0xe61a98: bl              #0x1254cc0  ; [dart:mixin_deduplication] _MixinApplication456&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::addStatusListener
    // 0xe61a9c: ldur            x0, [fp, #-0x20]
    // 0xe61aa0: ldur            x2, [fp, #-8]
    // 0xe61aa4: StoreField: r2->field_2b = r0
    //     0xe61aa4: stur            w0, [x2, #0x2b]
    //     0xe61aa8: ldurb           w16, [x2, #-1]
    //     0xe61aac: ldurb           w17, [x0, #-1]
    //     0xe61ab0: and             x16, x17, x16, lsr #2
    //     0xe61ab4: tst             x16, HEAP, lsr #32
    //     0xe61ab8: b.eq            #0xe61ac0
    //     0xe61abc: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xe61ac0: ldur            x1, [fp, #-0x20]
    // 0xe61ac4: b               #0xe61acc
    // 0xe61ac8: mov             x2, x0
    // 0xe61acc: LoadField: r0 = r2->field_27
    //     0xe61acc: ldur            w0, [x2, #0x27]
    // 0xe61ad0: DecompressPointer r0
    //     0xe61ad0: add             x0, x0, HEAP, lsl #32
    // 0xe61ad4: LoadField: r3 = r0->field_f
    //     0xe61ad4: ldur            x3, [x0, #0xf]
    // 0xe61ad8: ArrayLoad: r4 = r0[0]  ; List_8
    //     0xe61ad8: ldur            x4, [x0, #0x17]
    // 0xe61adc: cmp             x3, x4
    // 0xe61ae0: b.ne            #0xe61aec
    // 0xe61ae4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xe61ae4: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xe61ae8: r0 = forward()
    //     0xe61ae8: bl              #0x8cd83c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0xe61aec: ldur            x1, [fp, #-8]
    // 0xe61af0: ldur            x2, [fp, #-0x18]
    // 0xe61af4: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xe61af8: StoreField: r2->field_13 = r0
    //     0xe61af8: stur            w0, [x2, #0x13]
    // 0xe61afc: LoadField: r0 = r1->field_2b
    //     0xe61afc: ldur            w0, [x1, #0x2b]
    // 0xe61b00: DecompressPointer r0
    //     0xe61b00: add             x0, x0, HEAP, lsl #32
    // 0xe61b04: stur            x0, [fp, #-0x20]
    // 0xe61b08: cmp             w0, NULL
    // 0xe61b0c: b.eq            #0xe61c44
    // 0xe61b10: r0 = UniqueKey()
    //     0xe61b10: bl              #0xb8f328  ; AllocateUniqueKeyStub -> UniqueKey (size=0x8)
    // 0xe61b14: ldur            x1, [fp, #-0x10]
    // 0xe61b18: ldur            x2, [fp, #-0x20]
    // 0xe61b1c: mov             x3, x0
    // 0xe61b20: r0 = withAnimation()
    //     0xe61b20: bl              #0xe62084  ; [package:flutter/src/material/snack_bar.dart] SnackBar::withAnimation
    // 0xe61b24: r1 = <SnackBarClosedReason>
    //     0xe61b24: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e7f0] TypeArguments: <SnackBarClosedReason>
    //     0xe61b28: ldr             x1, [x1, #0x7f0]
    // 0xe61b2c: stur            x0, [fp, #-0x10]
    // 0xe61b30: r0 = _Future()
    //     0xe61b30: bl              #0x7f5dd4  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0xe61b34: stur            x0, [fp, #-0x20]
    // 0xe61b38: StoreField: r0->field_b = rZR
    //     0xe61b38: stur            xzr, [x0, #0xb]
    // 0xe61b3c: r0 = LoadStaticField(0x364)
    //     0xe61b3c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xe61b40: ldr             x0, [x0, #0x6c8]
    // 0xe61b44: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xe61b48: cmp             w0, w16
    // 0xe61b4c: b.ne            #0xe61b58
    // 0xe61b50: r2 = _current
    //     0xe61b50: ldr             x2, [PP, #0x2c0]  ; [pp+0x2c0] Field <Zone._current@5048458>: static late (offset: 0x364)
    // 0xe61b54: r0 = InitLateStaticField()
    //     0xe61b54: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0xe61b58: mov             x1, x0
    // 0xe61b5c: ldur            x0, [fp, #-0x20]
    // 0xe61b60: StoreField: r0->field_13 = r1
    //     0xe61b60: stur            w1, [x0, #0x13]
    // 0xe61b64: r1 = <SnackBarClosedReason>
    //     0xe61b64: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e7f0] TypeArguments: <SnackBarClosedReason>
    //     0xe61b68: ldr             x1, [x1, #0x7f0]
    // 0xe61b6c: r0 = _AsyncCompleter()
    //     0xe61b6c: bl              #0x7f5dc8  ; Allocate_AsyncCompleterStub -> _AsyncCompleter<X0> (size=0x10)
    // 0xe61b70: mov             x2, x0
    // 0xe61b74: ldur            x0, [fp, #-0x20]
    // 0xe61b78: stur            x2, [fp, #-0x28]
    // 0xe61b7c: StoreField: r2->field_b = r0
    //     0xe61b7c: stur            w0, [x2, #0xb]
    // 0xe61b80: r1 = <SnackBar, SnackBarClosedReason>
    //     0xe61b80: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e7f8] TypeArguments: <SnackBar, SnackBarClosedReason>
    //     0xe61b84: ldr             x1, [x1, #0x7f8]
    // 0xe61b88: r0 = ScaffoldFeatureController()
    //     0xe61b88: bl              #0xe62078  ; AllocateScaffoldFeatureControllerStub -> ScaffoldFeatureController<X0 bound Widget, X1> (size=0x18)
    // 0xe61b8c: mov             x3, x0
    // 0xe61b90: ldur            x0, [fp, #-0x10]
    // 0xe61b94: stur            x3, [fp, #-0x20]
    // 0xe61b98: StoreField: r3->field_b = r0
    //     0xe61b98: stur            w0, [x3, #0xb]
    // 0xe61b9c: ldur            x0, [fp, #-0x28]
    // 0xe61ba0: StoreField: r3->field_f = r0
    //     0xe61ba0: stur            w0, [x3, #0xf]
    // 0xe61ba4: ldur            x2, [fp, #-0x18]
    // 0xe61ba8: r1 = Function '<anonymous closure>':.
    //     0xe61ba8: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e800] AnonymousClosure: (0xe62210), in [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::showSnackBar (0xe61a24)
    //     0xe61bac: ldr             x1, [x1, #0x800]
    // 0xe61bb0: r0 = AllocateClosure()
    //     0xe61bb0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xe61bb4: mov             x1, x0
    // 0xe61bb8: ldur            x0, [fp, #-0x20]
    // 0xe61bbc: StoreField: r0->field_13 = r1
    //     0xe61bbc: stur            w1, [x0, #0x13]
    // 0xe61bc0: ldur            x3, [fp, #-0x18]
    // 0xe61bc4: StoreField: r3->field_13 = r0
    //     0xe61bc4: stur            w0, [x3, #0x13]
    //     0xe61bc8: ldurb           w16, [x3, #-1]
    //     0xe61bcc: ldurb           w17, [x0, #-1]
    //     0xe61bd0: and             x16, x17, x16, lsr #2
    //     0xe61bd4: tst             x16, HEAP, lsr #32
    //     0xe61bd8: b.eq            #0xe61be0
    //     0xe61bdc: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xe61be0: mov             x2, x3
    // 0xe61be4: r1 = Function '<anonymous closure>':.
    //     0xe61be4: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e808] AnonymousClosure: (0xe62194), in [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::showSnackBar (0xe61a24)
    //     0xe61be8: ldr             x1, [x1, #0x808]
    // 0xe61bec: r0 = AllocateClosure()
    //     0xe61bec: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xe61bf0: ldur            x1, [fp, #-8]
    // 0xe61bf4: mov             x2, x0
    // 0xe61bf8: r0 = setState()
    //     0xe61bf8: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xe61bfc: ldur            x1, [fp, #-8]
    // 0xe61c00: r0 = _updateScaffolds()
    //     0xe61c00: bl              #0xe61c48  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::_updateScaffolds
    // 0xe61c04: ldur            x0, [fp, #-0x18]
    // 0xe61c08: LoadField: r1 = r0->field_13
    //     0xe61c08: ldur            w1, [x0, #0x13]
    // 0xe61c0c: DecompressPointer r1
    //     0xe61c0c: add             x1, x1, HEAP, lsl #32
    // 0xe61c10: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xe61c14: cmp             w1, w16
    // 0xe61c18: b.eq            #0xe61c2c
    // 0xe61c1c: mov             x0, x1
    // 0xe61c20: LeaveFrame
    //     0xe61c20: mov             SP, fp
    //     0xe61c24: ldp             fp, lr, [SP], #0x10
    // 0xe61c28: ret
    //     0xe61c28: ret             
    // 0xe61c2c: r16 = "controller"
    //     0xe61c2c: ldr             x16, [PP, #0x15b0]  ; [pp+0x15b0] "controller"
    // 0xe61c30: str             x16, [SP]
    // 0xe61c34: r0 = _throwLocalNotInitialized()
    //     0xe61c34: bl              #0x82b57c  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0xe61c38: brk             #0
    // 0xe61c3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe61c3c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe61c40: b               #0xe61a4c
    // 0xe61c44: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe61c44: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateScaffolds(/* No info */) {
    // ** addr: 0xe61c48, size: 0x120
    // 0xe61c48: EnterFrame
    //     0xe61c48: stp             fp, lr, [SP, #-0x10]!
    //     0xe61c4c: mov             fp, SP
    // 0xe61c50: AllocStack(0x30)
    //     0xe61c50: sub             SP, SP, #0x30
    // 0xe61c54: CheckStackOverflow
    //     0xe61c54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe61c58: cmp             SP, x16
    //     0xe61c5c: b.ls            #0xe61d54
    // 0xe61c60: LoadField: r0 = r1->field_1b
    //     0xe61c60: ldur            w0, [x1, #0x1b]
    // 0xe61c64: DecompressPointer r0
    //     0xe61c64: add             x0, x0, HEAP, lsl #32
    // 0xe61c68: mov             x1, x0
    // 0xe61c6c: stur            x0, [fp, #-8]
    // 0xe61c70: r0 = iterator()
    //     0xe61c70: bl              #0xbb7c60  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0xe61c74: stur            x0, [fp, #-0x18]
    // 0xe61c78: LoadField: r2 = r0->field_7
    //     0xe61c78: ldur            w2, [x0, #7]
    // 0xe61c7c: DecompressPointer r2
    //     0xe61c7c: add             x2, x2, HEAP, lsl #32
    // 0xe61c80: stur            x2, [fp, #-0x10]
    // 0xe61c84: CheckStackOverflow
    //     0xe61c84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe61c88: cmp             SP, x16
    //     0xe61c8c: b.ls            #0xe61d5c
    // 0xe61c90: mov             x1, x0
    // 0xe61c94: r0 = moveNext()
    //     0xe61c94: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0xe61c98: tbnz            w0, #4, #0xe61d44
    // 0xe61c9c: ldur            x3, [fp, #-0x18]
    // 0xe61ca0: LoadField: r4 = r3->field_33
    //     0xe61ca0: ldur            w4, [x3, #0x33]
    // 0xe61ca4: DecompressPointer r4
    //     0xe61ca4: add             x4, x4, HEAP, lsl #32
    // 0xe61ca8: stur            x4, [fp, #-0x20]
    // 0xe61cac: cmp             w4, NULL
    // 0xe61cb0: b.ne            #0xe61ce4
    // 0xe61cb4: mov             x0, x4
    // 0xe61cb8: ldur            x2, [fp, #-0x10]
    // 0xe61cbc: r1 = Null
    //     0xe61cbc: mov             x1, NULL
    // 0xe61cc0: cmp             w2, NULL
    // 0xe61cc4: b.eq            #0xe61ce4
    // 0xe61cc8: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xe61cc8: ldur            w4, [x2, #0x17]
    // 0xe61ccc: DecompressPointer r4
    //     0xe61ccc: add             x4, x4, HEAP, lsl #32
    // 0xe61cd0: r8 = X0
    //     0xe61cd0: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xe61cd4: LoadField: r9 = r4->field_7
    //     0xe61cd4: ldur            x9, [x4, #7]
    // 0xe61cd8: r3 = Null
    //     0xe61cd8: add             x3, PP, #0x1e, lsl #12  ; [pp+0x1e838] Null
    //     0xe61cdc: ldr             x3, [x3, #0x838]
    // 0xe61ce0: blr             x9
    // 0xe61ce4: ldur            x1, [fp, #-0x20]
    // 0xe61ce8: LoadField: r0 = r1->field_f
    //     0xe61ce8: ldur            w0, [x1, #0xf]
    // 0xe61cec: DecompressPointer r0
    //     0xe61cec: add             x0, x0, HEAP, lsl #32
    // 0xe61cf0: cmp             w0, NULL
    // 0xe61cf4: b.eq            #0xe61d64
    // 0xe61cf8: r16 = <ScaffoldState>
    //     0xe61cf8: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e848] TypeArguments: <ScaffoldState>
    //     0xe61cfc: ldr             x16, [x16, #0x848]
    // 0xe61d00: stp             x0, x16, [SP]
    // 0xe61d04: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xe61d04: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xe61d08: r0 = findAncestorStateOfType()
    //     0xe61d08: bl              #0x855b2c  ; [package:flutter/src/widgets/framework.dart] Element::findAncestorStateOfType
    // 0xe61d0c: cmp             w0, NULL
    // 0xe61d10: b.eq            #0xe61d28
    // 0xe61d14: ldur            x1, [fp, #-8]
    // 0xe61d18: mov             x2, x0
    // 0xe61d1c: r0 = contains()
    //     0xe61d1c: bl              #0xbafbf4  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0xe61d20: eor             x1, x0, #0x10
    // 0xe61d24: tbnz            w1, #4, #0xe61d38
    // 0xe61d28: ldur            x1, [fp, #-0x20]
    // 0xe61d2c: r0 = _updateSnackBar()
    //     0xe61d2c: bl              #0xe61f34  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::_updateSnackBar
    // 0xe61d30: ldur            x1, [fp, #-0x20]
    // 0xe61d34: r0 = _updateMaterialBanner()
    //     0xe61d34: bl              #0xe61df0  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::_updateMaterialBanner
    // 0xe61d38: ldur            x0, [fp, #-0x18]
    // 0xe61d3c: ldur            x2, [fp, #-0x10]
    // 0xe61d40: b               #0xe61c84
    // 0xe61d44: r0 = Null
    //     0xe61d44: mov             x0, NULL
    // 0xe61d48: LeaveFrame
    //     0xe61d48: mov             SP, fp
    //     0xe61d4c: ldp             fp, lr, [SP], #0x10
    // 0xe61d50: ret
    //     0xe61d50: ret             
    // 0xe61d54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe61d54: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe61d58: b               #0xe61c60
    // 0xe61d5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe61d5c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe61d60: b               #0xe61c90
    // 0xe61d64: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe61d64: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _isRoot(/* No info */) {
    // ** addr: 0xe61d68, size: 0x88
    // 0xe61d68: EnterFrame
    //     0xe61d68: stp             fp, lr, [SP, #-0x10]!
    //     0xe61d6c: mov             fp, SP
    // 0xe61d70: AllocStack(0x18)
    //     0xe61d70: sub             SP, SP, #0x18
    // 0xe61d74: SetupParameters(ScaffoldMessengerState this /* r1 => r1, fp-0x8 */)
    //     0xe61d74: stur            x1, [fp, #-8]
    // 0xe61d78: CheckStackOverflow
    //     0xe61d78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe61d7c: cmp             SP, x16
    //     0xe61d80: b.ls            #0xe61de4
    // 0xe61d84: LoadField: r0 = r2->field_f
    //     0xe61d84: ldur            w0, [x2, #0xf]
    // 0xe61d88: DecompressPointer r0
    //     0xe61d88: add             x0, x0, HEAP, lsl #32
    // 0xe61d8c: cmp             w0, NULL
    // 0xe61d90: b.eq            #0xe61dec
    // 0xe61d94: r16 = <ScaffoldState>
    //     0xe61d94: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e848] TypeArguments: <ScaffoldState>
    //     0xe61d98: ldr             x16, [x16, #0x848]
    // 0xe61d9c: stp             x0, x16, [SP]
    // 0xe61da0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xe61da0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xe61da4: r0 = findAncestorStateOfType()
    //     0xe61da4: bl              #0x855b2c  ; [package:flutter/src/widgets/framework.dart] Element::findAncestorStateOfType
    // 0xe61da8: cmp             w0, NULL
    // 0xe61dac: b.ne            #0xe61db8
    // 0xe61db0: r0 = true
    //     0xe61db0: add             x0, NULL, #0x20  ; true
    // 0xe61db4: b               #0xe61dd8
    // 0xe61db8: ldur            x1, [fp, #-8]
    // 0xe61dbc: LoadField: r2 = r1->field_1b
    //     0xe61dbc: ldur            w2, [x1, #0x1b]
    // 0xe61dc0: DecompressPointer r2
    //     0xe61dc0: add             x2, x2, HEAP, lsl #32
    // 0xe61dc4: mov             x1, x2
    // 0xe61dc8: mov             x2, x0
    // 0xe61dcc: r0 = contains()
    //     0xe61dcc: bl              #0xbafbf4  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0xe61dd0: eor             x1, x0, #0x10
    // 0xe61dd4: mov             x0, x1
    // 0xe61dd8: LeaveFrame
    //     0xe61dd8: mov             SP, fp
    //     0xe61ddc: ldp             fp, lr, [SP], #0x10
    // 0xe61de0: ret
    //     0xe61de0: ret             
    // 0xe61de4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe61de4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe61de8: b               #0xe61d84
    // 0xe61dec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe61dec: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xe62194, size: 0x7c
    // 0xe62194: EnterFrame
    //     0xe62194: stp             fp, lr, [SP, #-0x10]!
    //     0xe62198: mov             fp, SP
    // 0xe6219c: AllocStack(0x8)
    //     0xe6219c: sub             SP, SP, #8
    // 0xe621a0: SetupParameters([dynamic _ /* r0 */])
    //     0xe621a0: ldr             x0, [fp, #0x10]
    //     0xe621a4: ldur            w1, [x0, #0x17]
    //     0xe621a8: add             x1, x1, HEAP, lsl #32
    // 0xe621ac: CheckStackOverflow
    //     0xe621ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe621b0: cmp             SP, x16
    //     0xe621b4: b.ls            #0xe62208
    // 0xe621b8: LoadField: r0 = r1->field_f
    //     0xe621b8: ldur            w0, [x1, #0xf]
    // 0xe621bc: DecompressPointer r0
    //     0xe621bc: add             x0, x0, HEAP, lsl #32
    // 0xe621c0: LoadField: r2 = r0->field_27
    //     0xe621c0: ldur            w2, [x0, #0x27]
    // 0xe621c4: DecompressPointer r2
    //     0xe621c4: add             x2, x2, HEAP, lsl #32
    // 0xe621c8: LoadField: r0 = r1->field_13
    //     0xe621c8: ldur            w0, [x1, #0x13]
    // 0xe621cc: DecompressPointer r0
    //     0xe621cc: add             x0, x0, HEAP, lsl #32
    // 0xe621d0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xe621d4: cmp             w0, w16
    // 0xe621d8: b.eq            #0xe621f8
    // 0xe621dc: mov             x1, x2
    // 0xe621e0: mov             x2, x0
    // 0xe621e4: r0 = _add()
    //     0xe621e4: bl              #0x820990  ; [dart:collection] ListQueue::_add
    // 0xe621e8: r0 = Null
    //     0xe621e8: mov             x0, NULL
    // 0xe621ec: LeaveFrame
    //     0xe621ec: mov             SP, fp
    //     0xe621f0: ldp             fp, lr, [SP], #0x10
    // 0xe621f4: ret
    //     0xe621f4: ret             
    // 0xe621f8: r16 = "controller"
    //     0xe621f8: ldr             x16, [PP, #0x15b0]  ; [pp+0x15b0] "controller"
    // 0xe621fc: str             x16, [SP]
    // 0xe62200: r0 = _throwLocalNotInitialized()
    //     0xe62200: bl              #0x82b57c  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0xe62204: brk             #0
    // 0xe62208: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe62208: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe6220c: b               #0xe621b8
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xe62210, size: 0x4c
    // 0xe62210: EnterFrame
    //     0xe62210: stp             fp, lr, [SP, #-0x10]!
    //     0xe62214: mov             fp, SP
    // 0xe62218: ldr             x0, [fp, #0x10]
    // 0xe6221c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xe6221c: ldur            w1, [x0, #0x17]
    // 0xe62220: DecompressPointer r1
    //     0xe62220: add             x1, x1, HEAP, lsl #32
    // 0xe62224: CheckStackOverflow
    //     0xe62224: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe62228: cmp             SP, x16
    //     0xe6222c: b.ls            #0xe62254
    // 0xe62230: LoadField: r0 = r1->field_f
    //     0xe62230: ldur            w0, [x1, #0xf]
    // 0xe62234: DecompressPointer r0
    //     0xe62234: add             x0, x0, HEAP, lsl #32
    // 0xe62238: mov             x1, x0
    // 0xe6223c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xe6223c: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xe62240: r0 = hideCurrentSnackBar()
    //     0xe62240: bl              #0xd34f88  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::hideCurrentSnackBar
    // 0xe62244: r0 = Null
    //     0xe62244: mov             x0, NULL
    // 0xe62248: LeaveFrame
    //     0xe62248: mov             SP, fp
    //     0xe6224c: ldp             fp, lr, [SP], #0x10
    // 0xe62250: ret
    //     0xe62250: ret             
    // 0xe62254: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe62254: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe62258: b               #0xe62230
  }
  [closure] void _handleSnackBarStatusChanged(dynamic, AnimationStatus) {
    // ** addr: 0xe6225c, size: 0x3c
    // 0xe6225c: EnterFrame
    //     0xe6225c: stp             fp, lr, [SP, #-0x10]!
    //     0xe62260: mov             fp, SP
    // 0xe62264: ldr             x0, [fp, #0x18]
    // 0xe62268: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xe62268: ldur            w1, [x0, #0x17]
    // 0xe6226c: DecompressPointer r1
    //     0xe6226c: add             x1, x1, HEAP, lsl #32
    // 0xe62270: CheckStackOverflow
    //     0xe62270: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe62274: cmp             SP, x16
    //     0xe62278: b.ls            #0xe62290
    // 0xe6227c: ldr             x2, [fp, #0x10]
    // 0xe62280: r0 = _handleSnackBarStatusChanged()
    //     0xe62280: bl              #0xe62298  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::_handleSnackBarStatusChanged
    // 0xe62284: LeaveFrame
    //     0xe62284: mov             SP, fp
    //     0xe62288: ldp             fp, lr, [SP], #0x10
    // 0xe6228c: ret
    //     0xe6228c: ret             
    // 0xe62290: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe62290: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe62294: b               #0xe6227c
  }
  _ _handleSnackBarStatusChanged(/* No info */) {
    // ** addr: 0xe62298, size: 0xf0
    // 0xe62298: EnterFrame
    //     0xe62298: stp             fp, lr, [SP, #-0x10]!
    //     0xe6229c: mov             fp, SP
    // 0xe622a0: AllocStack(0x10)
    //     0xe622a0: sub             SP, SP, #0x10
    // 0xe622a4: SetupParameters(ScaffoldMessengerState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xe622a4: stur            x1, [fp, #-8]
    //     0xe622a8: stur            x2, [fp, #-0x10]
    // 0xe622ac: CheckStackOverflow
    //     0xe622ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe622b0: cmp             SP, x16
    //     0xe622b4: b.ls            #0xe6237c
    // 0xe622b8: r1 = 1
    //     0xe622b8: mov             x1, #1
    // 0xe622bc: r0 = AllocateContext()
    //     0xe622bc: bl              #0x13de838  ; AllocateContextStub
    // 0xe622c0: mov             x1, x0
    // 0xe622c4: ldur            x0, [fp, #-8]
    // 0xe622c8: StoreField: r1->field_f = r0
    //     0xe622c8: stur            w0, [x1, #0xf]
    // 0xe622cc: ldur            x2, [fp, #-0x10]
    // 0xe622d0: LoadField: r3 = r2->field_7
    //     0xe622d0: ldur            x3, [x2, #7]
    // 0xe622d4: cmp             x3, #1
    // 0xe622d8: b.gt            #0xe62340
    // 0xe622dc: cmp             x3, #0
    // 0xe622e0: b.gt            #0xe6236c
    // 0xe622e4: mov             x2, x1
    // 0xe622e8: r1 = Function '<anonymous closure>':.
    //     0xe622e8: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e828] AnonymousClosure: (0xe62388), in [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::_handleSnackBarStatusChanged (0xe62298)
    //     0xe622ec: ldr             x1, [x1, #0x828]
    // 0xe622f0: r0 = AllocateClosure()
    //     0xe622f0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xe622f4: ldur            x1, [fp, #-8]
    // 0xe622f8: mov             x2, x0
    // 0xe622fc: r0 = setState()
    //     0xe622fc: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xe62300: ldur            x1, [fp, #-8]
    // 0xe62304: r0 = _updateScaffolds()
    //     0xe62304: bl              #0xe61c48  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::_updateScaffolds
    // 0xe62308: ldur            x0, [fp, #-8]
    // 0xe6230c: LoadField: r1 = r0->field_27
    //     0xe6230c: ldur            w1, [x0, #0x27]
    // 0xe62310: DecompressPointer r1
    //     0xe62310: add             x1, x1, HEAP, lsl #32
    // 0xe62314: LoadField: r2 = r1->field_f
    //     0xe62314: ldur            x2, [x1, #0xf]
    // 0xe62318: ArrayLoad: r3 = r1[0]  ; List_8
    //     0xe62318: ldur            x3, [x1, #0x17]
    // 0xe6231c: cmp             x2, x3
    // 0xe62320: b.eq            #0xe6236c
    // 0xe62324: LoadField: r1 = r0->field_2b
    //     0xe62324: ldur            w1, [x0, #0x2b]
    // 0xe62328: DecompressPointer r1
    //     0xe62328: add             x1, x1, HEAP, lsl #32
    // 0xe6232c: cmp             w1, NULL
    // 0xe62330: b.eq            #0xe62384
    // 0xe62334: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xe62334: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xe62338: r0 = forward()
    //     0xe62338: bl              #0x8cd83c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0xe6233c: b               #0xe6236c
    // 0xe62340: cmp             x3, #2
    // 0xe62344: b.le            #0xe6236c
    // 0xe62348: r1 = Function '<anonymous closure>':.
    //     0xe62348: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e830] Function: [dart:ui] Shader::Shader._ (0x13cf838)
    //     0xe6234c: ldr             x1, [x1, #0x830]
    // 0xe62350: r2 = Null
    //     0xe62350: mov             x2, NULL
    // 0xe62354: r0 = AllocateClosure()
    //     0xe62354: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xe62358: ldur            x1, [fp, #-8]
    // 0xe6235c: mov             x2, x0
    // 0xe62360: r0 = setState()
    //     0xe62360: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xe62364: ldur            x1, [fp, #-8]
    // 0xe62368: r0 = _updateScaffolds()
    //     0xe62368: bl              #0xe61c48  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::_updateScaffolds
    // 0xe6236c: r0 = Null
    //     0xe6236c: mov             x0, NULL
    // 0xe62370: LeaveFrame
    //     0xe62370: mov             SP, fp
    //     0xe62374: ldp             fp, lr, [SP], #0x10
    // 0xe62378: ret
    //     0xe62378: ret             
    // 0xe6237c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe6237c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe62380: b               #0xe622b8
    // 0xe62384: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe62384: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xe62388, size: 0x4c
    // 0xe62388: EnterFrame
    //     0xe62388: stp             fp, lr, [SP, #-0x10]!
    //     0xe6238c: mov             fp, SP
    // 0xe62390: ldr             x0, [fp, #0x10]
    // 0xe62394: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xe62394: ldur            w1, [x0, #0x17]
    // 0xe62398: DecompressPointer r1
    //     0xe62398: add             x1, x1, HEAP, lsl #32
    // 0xe6239c: CheckStackOverflow
    //     0xe6239c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe623a0: cmp             SP, x16
    //     0xe623a4: b.ls            #0xe623cc
    // 0xe623a8: LoadField: r0 = r1->field_f
    //     0xe623a8: ldur            w0, [x1, #0xf]
    // 0xe623ac: DecompressPointer r0
    //     0xe623ac: add             x0, x0, HEAP, lsl #32
    // 0xe623b0: LoadField: r1 = r0->field_27
    //     0xe623b0: ldur            w1, [x0, #0x27]
    // 0xe623b4: DecompressPointer r1
    //     0xe623b4: add             x1, x1, HEAP, lsl #32
    // 0xe623b8: r0 = removeFirst()
    //     0xe623b8: bl              #0x820d24  ; [dart:collection] ListQueue::removeFirst
    // 0xe623bc: r0 = Null
    //     0xe623bc: mov             x0, NULL
    // 0xe623c0: LeaveFrame
    //     0xe623c0: mov             SP, fp
    //     0xe623c4: ldp             fp, lr, [SP], #0x10
    // 0xe623c8: ret
    //     0xe623c8: ret             
    // 0xe623cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe623cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe623d0: b               #0xe623a8
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0xeed7d8, size: 0x58
    // 0xeed7d8: EnterFrame
    //     0xeed7d8: stp             fp, lr, [SP, #-0x10]!
    //     0xeed7dc: mov             fp, SP
    // 0xeed7e0: AllocStack(0x8)
    //     0xeed7e0: sub             SP, SP, #8
    // 0xeed7e4: SetupParameters(ScaffoldMessengerState this /* r1 => r0, fp-0x8 */)
    //     0xeed7e4: mov             x0, x1
    //     0xeed7e8: stur            x1, [fp, #-8]
    // 0xeed7ec: CheckStackOverflow
    //     0xeed7ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeed7f0: cmp             SP, x16
    //     0xeed7f4: b.ls            #0xeed824
    // 0xeed7f8: LoadField: r1 = r0->field_f
    //     0xeed7f8: ldur            w1, [x0, #0xf]
    // 0xeed7fc: DecompressPointer r1
    //     0xeed7fc: add             x1, x1, HEAP, lsl #32
    // 0xeed800: cmp             w1, NULL
    // 0xeed804: b.eq            #0xeed82c
    // 0xeed808: r0 = accessibleNavigationOf()
    //     0xeed808: bl              #0xd34edc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::accessibleNavigationOf
    // 0xeed80c: ldur            x1, [fp, #-8]
    // 0xeed810: StoreField: r1->field_33 = r0
    //     0xeed810: stur            w0, [x1, #0x33]
    // 0xeed814: r0 = Null
    //     0xeed814: mov             x0, NULL
    // 0xeed818: LeaveFrame
    //     0xeed818: mov             SP, fp
    //     0xeed81c: ldp             fp, lr, [SP], #0x10
    // 0xeed820: ret
    //     0xeed820: ret             
    // 0xeed824: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeed824: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeed828: b               #0xeed7f8
    // 0xeed82c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xeed82c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _register(/* No info */) {
    // ** addr: 0xeeeb8c, size: 0xa8
    // 0xeeeb8c: EnterFrame
    //     0xeeeb8c: stp             fp, lr, [SP, #-0x10]!
    //     0xeeeb90: mov             fp, SP
    // 0xeeeb94: AllocStack(0x10)
    //     0xeeeb94: sub             SP, SP, #0x10
    // 0xeeeb98: SetupParameters(ScaffoldMessengerState this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xeeeb98: mov             x3, x1
    //     0xeeeb9c: mov             x0, x2
    //     0xeeeba0: stur            x1, [fp, #-8]
    //     0xeeeba4: stur            x2, [fp, #-0x10]
    // 0xeeeba8: CheckStackOverflow
    //     0xeeeba8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeeebac: cmp             SP, x16
    //     0xeeebb0: b.ls            #0xeeec2c
    // 0xeeebb4: LoadField: r1 = r3->field_1b
    //     0xeeebb4: ldur            w1, [x3, #0x1b]
    // 0xeeebb8: DecompressPointer r1
    //     0xeeebb8: add             x1, x1, HEAP, lsl #32
    // 0xeeebbc: mov             x2, x0
    // 0xeeebc0: r0 = add()
    //     0xeeebc0: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xeeebc4: ldur            x1, [fp, #-8]
    // 0xeeebc8: ldur            x2, [fp, #-0x10]
    // 0xeeebcc: r0 = _isRoot()
    //     0xeeebcc: bl              #0xe61d68  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::_isRoot
    // 0xeeebd0: tbnz            w0, #4, #0xeeec1c
    // 0xeeebd4: ldur            x0, [fp, #-8]
    // 0xeeebd8: LoadField: r1 = r0->field_27
    //     0xeeebd8: ldur            w1, [x0, #0x27]
    // 0xeeebdc: DecompressPointer r1
    //     0xeeebdc: add             x1, x1, HEAP, lsl #32
    // 0xeeebe0: LoadField: r2 = r1->field_f
    //     0xeeebe0: ldur            x2, [x1, #0xf]
    // 0xeeebe4: ArrayLoad: r3 = r1[0]  ; List_8
    //     0xeeebe4: ldur            x3, [x1, #0x17]
    // 0xeeebe8: cmp             x2, x3
    // 0xeeebec: b.eq            #0xeeebf8
    // 0xeeebf0: ldur            x1, [fp, #-0x10]
    // 0xeeebf4: r0 = _updateSnackBar()
    //     0xeeebf4: bl              #0xe61f34  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::_updateSnackBar
    // 0xeeebf8: ldur            x0, [fp, #-8]
    // 0xeeebfc: LoadField: r1 = r0->field_1f
    //     0xeeebfc: ldur            w1, [x0, #0x1f]
    // 0xeeec00: DecompressPointer r1
    //     0xeeec00: add             x1, x1, HEAP, lsl #32
    // 0xeeec04: LoadField: r0 = r1->field_f
    //     0xeeec04: ldur            x0, [x1, #0xf]
    // 0xeeec08: ArrayLoad: r2 = r1[0]  ; List_8
    //     0xeeec08: ldur            x2, [x1, #0x17]
    // 0xeeec0c: cmp             x0, x2
    // 0xeeec10: b.eq            #0xeeec1c
    // 0xeeec14: ldur            x1, [fp, #-0x10]
    // 0xeeec18: r0 = _updateMaterialBanner()
    //     0xeeec18: bl              #0xe61df0  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::_updateMaterialBanner
    // 0xeeec1c: r0 = Null
    //     0xeeec1c: mov             x0, NULL
    // 0xeeec20: LeaveFrame
    //     0xeeec20: mov             SP, fp
    //     0xeeec24: ldp             fp, lr, [SP], #0x10
    // 0xeeec28: ret
    //     0xeeec28: ret             
    // 0xeeec2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeeec2c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeeec30: b               #0xeeebb4
  }
  _ _unregister(/* No info */) {
    // ** addr: 0xeeec34, size: 0x3c
    // 0xeeec34: EnterFrame
    //     0xeeec34: stp             fp, lr, [SP, #-0x10]!
    //     0xeeec38: mov             fp, SP
    // 0xeeec3c: CheckStackOverflow
    //     0xeeec3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeeec40: cmp             SP, x16
    //     0xeeec44: b.ls            #0xeeec68
    // 0xeeec48: LoadField: r0 = r1->field_1b
    //     0xeeec48: ldur            w0, [x1, #0x1b]
    // 0xeeec4c: DecompressPointer r0
    //     0xeeec4c: add             x0, x0, HEAP, lsl #32
    // 0xeeec50: mov             x1, x0
    // 0xeeec54: r0 = remove()
    //     0xeeec54: bl              #0x115bfd0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::remove
    // 0xeeec58: r0 = Null
    //     0xeeec58: mov             x0, NULL
    // 0xeeec5c: LeaveFrame
    //     0xeeec5c: mov             SP, fp
    //     0xeeec60: ldp             fp, lr, [SP], #0x10
    // 0xeeec64: ret
    //     0xeeec64: ret             
    // 0xeeec68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeeec68: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeeec6c: b               #0xeeec48
  }
  _ ScaffoldMessengerState(/* No info */) {
    // ** addr: 0xfa286c, size: 0x110
    // 0xfa286c: EnterFrame
    //     0xfa286c: stp             fp, lr, [SP, #-0x10]!
    //     0xfa2870: mov             fp, SP
    // 0xfa2874: AllocStack(0x10)
    //     0xfa2874: sub             SP, SP, #0x10
    // 0xfa2878: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa287c: mov             x2, x1
    // 0xfa2880: stur            x1, [fp, #-8]
    // 0xfa2884: CheckStackOverflow
    //     0xfa2884: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa2888: cmp             SP, x16
    //     0xfa288c: b.ls            #0xfa2974
    // 0xfa2890: StoreField: r2->field_33 = r0
    //     0xfa2890: stur            w0, [x2, #0x33]
    // 0xfa2894: r1 = <ScaffoldState>
    //     0xfa2894: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e848] TypeArguments: <ScaffoldState>
    //     0xfa2898: ldr             x1, [x1, #0x848]
    // 0xfa289c: r0 = _Set()
    //     0xfa289c: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0xfa28a0: mov             x1, x0
    // 0xfa28a4: r0 = _Uint32List
    //     0xfa28a4: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0xfa28a8: StoreField: r1->field_1b = r0
    //     0xfa28a8: stur            w0, [x1, #0x1b]
    // 0xfa28ac: StoreField: r1->field_b = rZR
    //     0xfa28ac: stur            wzr, [x1, #0xb]
    // 0xfa28b0: r0 = const []
    //     0xfa28b0: ldr             x0, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0xfa28b4: StoreField: r1->field_f = r0
    //     0xfa28b4: stur            w0, [x1, #0xf]
    // 0xfa28b8: StoreField: r1->field_13 = rZR
    //     0xfa28b8: stur            wzr, [x1, #0x13]
    // 0xfa28bc: ArrayStore: r1[0] = rZR  ; List_4
    //     0xfa28bc: stur            wzr, [x1, #0x17]
    // 0xfa28c0: mov             x0, x1
    // 0xfa28c4: ldur            x2, [fp, #-8]
    // 0xfa28c8: StoreField: r2->field_1b = r0
    //     0xfa28c8: stur            w0, [x2, #0x1b]
    //     0xfa28cc: ldurb           w16, [x2, #-1]
    //     0xfa28d0: ldurb           w17, [x0, #-1]
    //     0xfa28d4: and             x16, x17, x16, lsr #2
    //     0xfa28d8: tst             x16, HEAP, lsr #32
    //     0xfa28dc: b.eq            #0xfa28e4
    //     0xfa28e0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xfa28e4: r1 = <ScaffoldFeatureController<MaterialBanner, MaterialBannerClosedReason>>
    //     0xfa28e4: add             x1, PP, #0x99, lsl #12  ; [pp+0x998b8] TypeArguments: <ScaffoldFeatureController<MaterialBanner, MaterialBannerClosedReason>>
    //     0xfa28e8: ldr             x1, [x1, #0x8b8]
    // 0xfa28ec: r0 = ListQueue()
    //     0xfa28ec: bl              #0x8217c0  ; AllocateListQueueStub -> ListQueue<X0> (size=0x28)
    // 0xfa28f0: mov             x1, x0
    // 0xfa28f4: stur            x0, [fp, #-0x10]
    // 0xfa28f8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xfa28f8: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xfa28fc: r0 = ListQueue()
    //     0xfa28fc: bl              #0x821650  ; [dart:collection] ListQueue::ListQueue
    // 0xfa2900: ldur            x0, [fp, #-0x10]
    // 0xfa2904: ldur            x2, [fp, #-8]
    // 0xfa2908: StoreField: r2->field_1f = r0
    //     0xfa2908: stur            w0, [x2, #0x1f]
    //     0xfa290c: ldurb           w16, [x2, #-1]
    //     0xfa2910: ldurb           w17, [x0, #-1]
    //     0xfa2914: and             x16, x17, x16, lsr #2
    //     0xfa2918: tst             x16, HEAP, lsr #32
    //     0xfa291c: b.eq            #0xfa2924
    //     0xfa2920: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xfa2924: r1 = <ScaffoldFeatureController<SnackBar, SnackBarClosedReason>>
    //     0xfa2924: add             x1, PP, #0x99, lsl #12  ; [pp+0x998c0] TypeArguments: <ScaffoldFeatureController<SnackBar, SnackBarClosedReason>>
    //     0xfa2928: ldr             x1, [x1, #0x8c0]
    // 0xfa292c: r0 = ListQueue()
    //     0xfa292c: bl              #0x8217c0  ; AllocateListQueueStub -> ListQueue<X0> (size=0x28)
    // 0xfa2930: mov             x1, x0
    // 0xfa2934: stur            x0, [fp, #-0x10]
    // 0xfa2938: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xfa2938: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xfa293c: r0 = ListQueue()
    //     0xfa293c: bl              #0x821650  ; [dart:collection] ListQueue::ListQueue
    // 0xfa2940: ldur            x0, [fp, #-0x10]
    // 0xfa2944: ldur            x1, [fp, #-8]
    // 0xfa2948: StoreField: r1->field_27 = r0
    //     0xfa2948: stur            w0, [x1, #0x27]
    //     0xfa294c: ldurb           w16, [x1, #-1]
    //     0xfa2950: ldurb           w17, [x0, #-1]
    //     0xfa2954: and             x16, x17, x16, lsr #2
    //     0xfa2958: tst             x16, HEAP, lsr #32
    //     0xfa295c: b.eq            #0xfa2964
    //     0xfa2960: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfa2964: r0 = Null
    //     0xfa2964: mov             x0, NULL
    // 0xfa2968: LeaveFrame
    //     0xfa2968: mov             SP, fp
    //     0xfa296c: ldp             fp, lr, [SP], #0x10
    // 0xfa2970: ret
    //     0xfa2970: ret             
    // 0xfa2974: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa2974: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa2978: b               #0xfa2890
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10dda0c, size: 0x78
    // 0x10dda0c: EnterFrame
    //     0x10dda0c: stp             fp, lr, [SP, #-0x10]!
    //     0x10dda10: mov             fp, SP
    // 0x10dda14: AllocStack(0x8)
    //     0x10dda14: sub             SP, SP, #8
    // 0x10dda18: SetupParameters(ScaffoldMessengerState this /* r1 => r0, fp-0x8 */)
    //     0x10dda18: mov             x0, x1
    //     0x10dda1c: stur            x1, [fp, #-8]
    // 0x10dda20: CheckStackOverflow
    //     0x10dda20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10dda24: cmp             SP, x16
    //     0x10dda28: b.ls            #0x10dda7c
    // 0x10dda2c: LoadField: r1 = r0->field_2b
    //     0x10dda2c: ldur            w1, [x0, #0x2b]
    // 0x10dda30: DecompressPointer r1
    //     0x10dda30: add             x1, x1, HEAP, lsl #32
    // 0x10dda34: cmp             w1, NULL
    // 0x10dda38: b.eq            #0x10dda44
    // 0x10dda3c: r0 = dispose()
    //     0x10dda3c: bl              #0x9164f4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x10dda40: ldur            x0, [fp, #-8]
    // 0x10dda44: LoadField: r1 = r0->field_2f
    //     0x10dda44: ldur            w1, [x0, #0x2f]
    // 0x10dda48: DecompressPointer r1
    //     0x10dda48: add             x1, x1, HEAP, lsl #32
    // 0x10dda4c: cmp             w1, NULL
    // 0x10dda50: b.ne            #0x10dda5c
    // 0x10dda54: mov             x1, x0
    // 0x10dda58: b               #0x10dda64
    // 0x10dda5c: r0 = cancel()
    //     0x10dda5c: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0x10dda60: ldur            x1, [fp, #-8]
    // 0x10dda64: StoreField: r1->field_2f = rNULL
    //     0x10dda64: stur            NULL, [x1, #0x2f]
    // 0x10dda68: r0 = dispose()
    //     0x10dda68: bl              #0x10dda84  ; [dart:mixin_deduplication] _MixinApplication98&State&TickerProviderStateMixin::dispose
    // 0x10dda6c: r0 = Null
    //     0x10dda6c: mov             x0, NULL
    // 0x10dda70: LeaveFrame
    //     0x10dda70: mov             SP, fp
    //     0x10dda74: ldp             fp, lr, [SP], #0x10
    // 0x10dda78: ret
    //     0x10dda78: ret             
    // 0x10dda7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10dda7c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10dda80: b               #0x10dda2c
  }
}

// class id: 6146, size: 0x10, field offset: 0xc
//   const constructor, 
class _HitTestableAtOrigin extends StatelessWidget {

  static _ hitTestableAtOrigin(/* No info */) {
    // ** addr: 0x8d1408, size: 0x138
    // 0x8d1408: EnterFrame
    //     0x8d1408: stp             fp, lr, [SP, #-0x10]!
    //     0x8d140c: mov             fp, SP
    // 0x8d1410: AllocStack(0x20)
    //     0x8d1410: sub             SP, SP, #0x20
    // 0x8d1414: CheckStackOverflow
    //     0x8d1414: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d1418: cmp             SP, x16
    //     0x8d141c: b.ls            #0x8d1530
    // 0x8d1420: r0 = _currentElement()
    //     0x8d1420: bl              #0x859318  ; [package:flutter/src/widgets/framework.dart] GlobalKey::_currentElement
    // 0x8d1424: mov             x2, x0
    // 0x8d1428: stur            x2, [fp, #-8]
    // 0x8d142c: cmp             w2, NULL
    // 0x8d1430: b.ne            #0x8d1444
    // 0x8d1434: r0 = false
    //     0x8d1434: add             x0, NULL, #0x30  ; false
    // 0x8d1438: LeaveFrame
    //     0x8d1438: mov             SP, fp
    //     0x8d143c: ldp             fp, lr, [SP], #0x10
    // 0x8d1440: ret
    //     0x8d1440: ret             
    // 0x8d1444: r0 = LoadClassIdInstr(r2)
    //     0x8d1444: ldur            x0, [x2, #-1]
    //     0x8d1448: ubfx            x0, x0, #0xc, #0x14
    // 0x8d144c: mov             x1, x2
    // 0x8d1450: r0 = GDT[cid_x0 + 0xd63]()
    //     0x8d1450: add             lr, x0, #0xd63
    //     0x8d1454: ldr             lr, [x21, lr, lsl #3]
    //     0x8d1458: blr             lr
    // 0x8d145c: mov             x3, x0
    // 0x8d1460: stur            x3, [fp, #-0x10]
    // 0x8d1464: cmp             w3, NULL
    // 0x8d1468: b.eq            #0x8d1538
    // 0x8d146c: mov             x0, x3
    // 0x8d1470: r2 = Null
    //     0x8d1470: mov             x2, NULL
    // 0x8d1474: r1 = Null
    //     0x8d1474: mov             x1, NULL
    // 0x8d1478: r4 = LoadClassIdInstr(r0)
    //     0x8d1478: ldur            x4, [x0, #-1]
    //     0x8d147c: ubfx            x4, x4, #0xc, #0x14
    // 0x8d1480: r17 = 4952
    //     0x8d1480: mov             x17, #0x1358
    // 0x8d1484: cmp             x4, x17
    // 0x8d1488: b.eq            #0x8d14a0
    // 0x8d148c: r8 = RenderMetaData
    //     0x8d148c: add             x8, PP, #0x84, lsl #12  ; [pp+0x84cf0] Type: RenderMetaData
    //     0x8d1490: ldr             x8, [x8, #0xcf0]
    // 0x8d1494: r3 = Null
    //     0x8d1494: add             x3, PP, #0x84, lsl #12  ; [pp+0x84cf8] Null
    //     0x8d1498: ldr             x3, [x3, #0xcf8]
    // 0x8d149c: r0 = DefaultTypeTest()
    //     0x8d149c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x8d14a0: r1 = 1
    //     0x8d14a0: mov             x1, #1
    // 0x8d14a4: r0 = AllocateContext()
    //     0x8d14a4: bl              #0x13de838  ; AllocateContextStub
    // 0x8d14a8: mov             x2, x0
    // 0x8d14ac: ldur            x0, [fp, #-0x10]
    // 0x8d14b0: stur            x2, [fp, #-0x18]
    // 0x8d14b4: StoreField: r2->field_f = r0
    //     0x8d14b4: stur            w0, [x2, #0xf]
    // 0x8d14b8: ldur            x1, [fp, #-8]
    // 0x8d14bc: r0 = of()
    //     0x8d14bc: bl              #0x864fc4  ; [package:flutter/src/widgets/view.dart] View::of
    // 0x8d14c0: LoadField: r5 = r0->field_7
    //     0x8d14c0: ldur            x5, [x0, #7]
    // 0x8d14c4: stur            x5, [fp, #-0x20]
    // 0x8d14c8: r0 = HitTestResult()
    //     0x8d14c8: bl              #0x836ee0  ; AllocateHitTestResultStub -> HitTestResult (size=0x14)
    // 0x8d14cc: mov             x1, x0
    // 0x8d14d0: stur            x0, [fp, #-8]
    // 0x8d14d4: r0 = HitTestResult()
    //     0x8d14d4: bl              #0x836bac  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::HitTestResult
    // 0x8d14d8: r1 = LoadStaticField(0x6a0)
    //     0x8d14d8: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0x8d14dc: ldr             x1, [x1, #0xd40]
    // 0x8d14e0: cmp             w1, NULL
    // 0x8d14e4: b.eq            #0x8d153c
    // 0x8d14e8: ldur            x2, [fp, #-8]
    // 0x8d14ec: ldur            x5, [fp, #-0x20]
    // 0x8d14f0: r3 = Instance_Offset
    //     0x8d14f0: ldr             x3, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x8d14f4: r0 = hitTestInView()
    //     0x8d14f4: bl              #0x83663c  ; [dart:mixin_deduplication] _MixinApplication207&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding&PaintingBinding&SemanticsBinding&RendererBinding::hitTestInView
    // 0x8d14f8: ldur            x0, [fp, #-8]
    // 0x8d14fc: LoadField: r3 = r0->field_7
    //     0x8d14fc: ldur            w3, [x0, #7]
    // 0x8d1500: DecompressPointer r3
    //     0x8d1500: add             x3, x3, HEAP, lsl #32
    // 0x8d1504: ldur            x2, [fp, #-0x18]
    // 0x8d1508: stur            x3, [fp, #-0x10]
    // 0x8d150c: r1 = Function '<anonymous closure>': static.
    //     0x8d150c: add             x1, PP, #0x84, lsl #12  ; [pp+0x84d08] AnonymousClosure: static (0x8d1540), in [package:flutter/src/material/scaffold.dart] _HitTestableAtOrigin::hitTestableAtOrigin (0x8d1408)
    //     0x8d1510: ldr             x1, [x1, #0xd08]
    // 0x8d1514: r0 = AllocateClosure()
    //     0x8d1514: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8d1518: ldur            x1, [fp, #-0x10]
    // 0x8d151c: mov             x2, x0
    // 0x8d1520: r0 = any()
    //     0x8d1520: bl              #0xbae1ac  ; [dart:collection] ListBase::any
    // 0x8d1524: LeaveFrame
    //     0x8d1524: mov             SP, fp
    //     0x8d1528: ldp             fp, lr, [SP], #0x10
    // 0x8d152c: ret
    //     0x8d152c: ret             
    // 0x8d1530: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d1530: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d1534: b               #0x8d1420
    // 0x8d1538: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8d1538: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8d153c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8d153c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] static bool <anonymous closure>(dynamic, HitTestEntry<HitTestTarget>) {
    // ** addr: 0x8d1540, size: 0x68
    // 0x8d1540: EnterFrame
    //     0x8d1540: stp             fp, lr, [SP, #-0x10]!
    //     0x8d1544: mov             fp, SP
    // 0x8d1548: AllocStack(0x10)
    //     0x8d1548: sub             SP, SP, #0x10
    // 0x8d154c: SetupParameters([dynamic _ /* r0 */])
    //     0x8d154c: ldr             x0, [fp, #0x18]
    //     0x8d1550: ldur            w1, [x0, #0x17]
    //     0x8d1554: add             x1, x1, HEAP, lsl #32
    // 0x8d1558: CheckStackOverflow
    //     0x8d1558: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d155c: cmp             SP, x16
    //     0x8d1560: b.ls            #0x8d15a0
    // 0x8d1564: ldr             x0, [fp, #0x10]
    // 0x8d1568: LoadField: r2 = r0->field_b
    //     0x8d1568: ldur            w2, [x0, #0xb]
    // 0x8d156c: DecompressPointer r2
    //     0x8d156c: add             x2, x2, HEAP, lsl #32
    // 0x8d1570: LoadField: r0 = r1->field_f
    //     0x8d1570: ldur            w0, [x1, #0xf]
    // 0x8d1574: DecompressPointer r0
    //     0x8d1574: add             x0, x0, HEAP, lsl #32
    // 0x8d1578: r1 = LoadClassIdInstr(r2)
    //     0x8d1578: ldur            x1, [x2, #-1]
    //     0x8d157c: ubfx            x1, x1, #0xc, #0x14
    // 0x8d1580: stp             x0, x2, [SP]
    // 0x8d1584: mov             x0, x1
    // 0x8d1588: mov             lr, x0
    // 0x8d158c: ldr             lr, [x21, lr, lsl #3]
    // 0x8d1590: blr             lr
    // 0x8d1594: LeaveFrame
    //     0x8d1594: mov             SP, fp
    //     0x8d1598: ldp             fp, lr, [SP], #0x10
    // 0x8d159c: ret
    //     0x8d159c: ret             
    // 0x8d15a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d15a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d15a4: b               #0x8d1564
  }
}

// class id: 6147, size: 0x18, field offset: 0xc
//   const constructor, 
class _BodyBuilder extends StatelessWidget {
}

// class id: 6436, size: 0x40, field offset: 0xc
//   const constructor, 
class _StandardBottomSheet extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa2dcc, size: 0x2c
    // 0xfa2dcc: EnterFrame
    //     0xfa2dcc: stp             fp, lr, [SP, #-0x10]!
    //     0xfa2dd0: mov             fp, SP
    // 0xfa2dd4: mov             x0, x1
    // 0xfa2dd8: r1 = <_StandardBottomSheet>
    //     0xfa2dd8: add             x1, PP, #0x26, lsl #12  ; [pp+0x26c58] TypeArguments: <_StandardBottomSheet>
    //     0xfa2ddc: ldr             x1, [x1, #0xc58]
    // 0xfa2de0: r0 = _StandardBottomSheetState()
    //     0xfa2de0: bl              #0xfa2df8  ; Allocate_StandardBottomSheetStateStub -> _StandardBottomSheetState (size=0x18)
    // 0xfa2de4: r1 = Instance_Cubic
    //     0xfa2de4: ldr             x1, [PP, #0x5660]  ; [pp+0x5660] Obj!Cubic@129f451
    // 0xfa2de8: StoreField: r0->field_13 = r1
    //     0xfa2de8: stur            w1, [x0, #0x13]
    // 0xfa2dec: LeaveFrame
    //     0xfa2dec: mov             SP, fp
    //     0xfa2df0: ldp             fp, lr, [SP], #0x10
    // 0xfa2df4: ret
    //     0xfa2df4: ret             
  }
}

// class id: 6437, size: 0x70, field offset: 0xc
//   const constructor, 
class Scaffold extends StatefulWidget {

  bool field_c;
  bool field_10;
  bool field_14;
  SizedBox field_1c;
  _Closure field_48;
  bool field_5c;
  DragStartBehavior field_60;
  bool field_68;

  static _ of(/* No info */) {
    // ** addr: 0xb35cb4, size: 0x158
    // 0xb35cb4: EnterFrame
    //     0xb35cb4: stp             fp, lr, [SP, #-0x10]!
    //     0xb35cb8: mov             fp, SP
    // 0xb35cbc: AllocStack(0x40)
    //     0xb35cbc: sub             SP, SP, #0x40
    // 0xb35cc0: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0xb35cc0: stur            x1, [fp, #-8]
    // 0xb35cc4: CheckStackOverflow
    //     0xb35cc4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb35cc8: cmp             SP, x16
    //     0xb35ccc: b.ls            #0xb35e04
    // 0xb35cd0: r16 = <ScaffoldState>
    //     0xb35cd0: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e848] TypeArguments: <ScaffoldState>
    //     0xb35cd4: ldr             x16, [x16, #0x848]
    // 0xb35cd8: stp             x1, x16, [SP]
    // 0xb35cdc: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xb35cdc: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xb35ce0: r0 = findAncestorStateOfType()
    //     0xb35ce0: bl              #0x855b2c  ; [package:flutter/src/widgets/framework.dart] Element::findAncestorStateOfType
    // 0xb35ce4: cmp             w0, NULL
    // 0xb35ce8: b.eq            #0xb35cf8
    // 0xb35cec: LeaveFrame
    //     0xb35cec: mov             SP, fp
    //     0xb35cf0: ldp             fp, lr, [SP], #0x10
    // 0xb35cf4: ret
    //     0xb35cf4: ret             
    // 0xb35cf8: r1 = <List<Object>>
    //     0xb35cf8: ldr             x1, [PP, #0x860]  ; [pp+0x860] TypeArguments: <List<Object>>
    // 0xb35cfc: r0 = ErrorSummary()
    //     0xb35cfc: bl              #0x84896c  ; AllocateErrorSummaryStub -> ErrorSummary (size=0x2c)
    // 0xb35d00: mov             x1, x0
    // 0xb35d04: r2 = "Scaffold.of() called with a context that does not contain a Scaffold."
    //     0xb35d04: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8fd88] "Scaffold.of() called with a context that does not contain a Scaffold."
    //     0xb35d08: ldr             x2, [x2, #0xd88]
    // 0xb35d0c: r3 = Instance_DiagnosticLevel
    //     0xb35d0c: ldr             x3, [PP, #0x22b0]  ; [pp+0x22b0] Obj!DiagnosticLevel@12c5f61
    // 0xb35d10: stur            x0, [fp, #-0x10]
    // 0xb35d14: r0 = _ErrorDiagnostic()
    //     0xb35d14: bl              #0x829bec  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0xb35d18: r1 = <List<Object>>
    //     0xb35d18: ldr             x1, [PP, #0x860]  ; [pp+0x860] TypeArguments: <List<Object>>
    // 0xb35d1c: r0 = ErrorDescription()
    //     0xb35d1c: bl              #0x829ca4  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x2c)
    // 0xb35d20: mov             x1, x0
    // 0xb35d24: r2 = "No Scaffold ancestor could be found starting from the context that was passed to Scaffold.of(). This usually happens when the context provided is from the same StatefulWidget as that whose build function actually creates the Scaffold widget being sought."
    //     0xb35d24: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8fd90] "No Scaffold ancestor could be found starting from the context that was passed to Scaffold.of(). This usually happens when the context provided is from the same StatefulWidget as that whose build function actually creates the Scaffold widget being sought."
    //     0xb35d28: ldr             x2, [x2, #0xd90]
    // 0xb35d2c: r3 = Instance_DiagnosticLevel
    //     0xb35d2c: ldr             x3, [PP, #0x868]  ; [pp+0x868] Obj!DiagnosticLevel@12c5f41
    // 0xb35d30: stur            x0, [fp, #-0x18]
    // 0xb35d34: r0 = _ErrorDiagnostic()
    //     0xb35d34: bl              #0x829bec  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0xb35d38: r1 = <List<Object>>
    //     0xb35d38: ldr             x1, [PP, #0x860]  ; [pp+0x860] TypeArguments: <List<Object>>
    // 0xb35d3c: r0 = ErrorHint()
    //     0xb35d3c: bl              #0xb35e0c  ; AllocateErrorHintStub -> ErrorHint (size=0x2c)
    // 0xb35d40: mov             x1, x0
    // 0xb35d44: r2 = "There are several ways to avoid this problem. The simplest is to use a Builder to get a context that is \"under\" the Scaffold. For an example of this, please see the documentation for Scaffold.of():\n  https://api.flutter.dev/flutter/material/Scaffold/of.html"
    //     0xb35d44: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8fd98] "There are several ways to avoid this problem. The simplest is to use a Builder to get a context that is \"under\" the Scaffold. For an example of this, please see the documentation for Scaffold.of():\n  https://api.flutter.dev/flutter/material/Scaffold/of.html"
    //     0xb35d48: ldr             x2, [x2, #0xd98]
    // 0xb35d4c: r3 = Instance_DiagnosticLevel
    //     0xb35d4c: add             x3, PP, #0x85, lsl #12  ; [pp+0x85260] Obj!DiagnosticLevel@12c5f81
    //     0xb35d50: ldr             x3, [x3, #0x260]
    // 0xb35d54: stur            x0, [fp, #-0x20]
    // 0xb35d58: r0 = _ErrorDiagnostic()
    //     0xb35d58: bl              #0x829bec  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0xb35d5c: r1 = <List<Object>>
    //     0xb35d5c: ldr             x1, [PP, #0x860]  ; [pp+0x860] TypeArguments: <List<Object>>
    // 0xb35d60: r0 = ErrorHint()
    //     0xb35d60: bl              #0xb35e0c  ; AllocateErrorHintStub -> ErrorHint (size=0x2c)
    // 0xb35d64: mov             x1, x0
    // 0xb35d68: r2 = "A more efficient solution is to split your build function into several widgets. This introduces a new context from which you can obtain the Scaffold. In this solution, you would have an outer widget that creates the Scaffold populated by instances of your new inner widgets, and then in these inner widgets you would use Scaffold.of().\nA less elegant but more expedient solution is assign a GlobalKey to the Scaffold, then use the key.currentState property to obtain the ScaffoldState rather than using the Scaffold.of() function."
    //     0xb35d68: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8fda0] "A more efficient solution is to split your build function into several widgets. This introduces a new context from which you can obtain the Scaffold. In this solution, you would have an outer widget that creates the Scaffold populated by instances of your new inner widgets, and then in these inner widgets you would use Scaffold.of().\nA less elegant but more expedient solution is assign a GlobalKey to the Scaffold, then use the key.currentState property to obtain the ScaffoldState rather than using the Scaffold.of() function."
    //     0xb35d6c: ldr             x2, [x2, #0xda0]
    // 0xb35d70: r3 = Instance_DiagnosticLevel
    //     0xb35d70: add             x3, PP, #0x85, lsl #12  ; [pp+0x85260] Obj!DiagnosticLevel@12c5f81
    //     0xb35d74: ldr             x3, [x3, #0x260]
    // 0xb35d78: stur            x0, [fp, #-0x28]
    // 0xb35d7c: r0 = _ErrorDiagnostic()
    //     0xb35d7c: bl              #0x829bec  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0xb35d80: ldur            x1, [fp, #-8]
    // 0xb35d84: r0 = describeElement()
    //     0xb35d84: bl              #0x89bf94  ; [package:flutter/src/widgets/framework.dart] Element::describeElement
    // 0xb35d88: r1 = Null
    //     0xb35d88: mov             x1, NULL
    // 0xb35d8c: r2 = 10
    //     0xb35d8c: mov             x2, #0xa
    // 0xb35d90: stur            x0, [fp, #-8]
    // 0xb35d94: r0 = AllocateArray()
    //     0xb35d94: bl              #0x13df928  ; AllocateArrayStub
    // 0xb35d98: mov             x2, x0
    // 0xb35d9c: ldur            x0, [fp, #-0x10]
    // 0xb35da0: stur            x2, [fp, #-0x30]
    // 0xb35da4: StoreField: r2->field_f = r0
    //     0xb35da4: stur            w0, [x2, #0xf]
    // 0xb35da8: ldur            x0, [fp, #-0x18]
    // 0xb35dac: StoreField: r2->field_13 = r0
    //     0xb35dac: stur            w0, [x2, #0x13]
    // 0xb35db0: ldur            x0, [fp, #-0x20]
    // 0xb35db4: ArrayStore: r2[0] = r0  ; List_4
    //     0xb35db4: stur            w0, [x2, #0x17]
    // 0xb35db8: ldur            x0, [fp, #-0x28]
    // 0xb35dbc: StoreField: r2->field_1b = r0
    //     0xb35dbc: stur            w0, [x2, #0x1b]
    // 0xb35dc0: ldur            x0, [fp, #-8]
    // 0xb35dc4: StoreField: r2->field_1f = r0
    //     0xb35dc4: stur            w0, [x2, #0x1f]
    // 0xb35dc8: r1 = <DiagnosticsNode>
    //     0xb35dc8: ldr             x1, [PP, #0x1ea8]  ; [pp+0x1ea8] TypeArguments: <DiagnosticsNode>
    // 0xb35dcc: r0 = AllocateGrowableArray()
    //     0xb35dcc: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xb35dd0: mov             x1, x0
    // 0xb35dd4: ldur            x0, [fp, #-0x30]
    // 0xb35dd8: stur            x1, [fp, #-8]
    // 0xb35ddc: StoreField: r1->field_f = r0
    //     0xb35ddc: stur            w0, [x1, #0xf]
    // 0xb35de0: r0 = 10
    //     0xb35de0: mov             x0, #0xa
    // 0xb35de4: StoreField: r1->field_b = r0
    //     0xb35de4: stur            w0, [x1, #0xb]
    // 0xb35de8: r0 = FlutterError()
    //     0xb35de8: bl              #0x8488dc  ; AllocateFlutterErrorStub -> FlutterError (size=0x10)
    // 0xb35dec: mov             x1, x0
    // 0xb35df0: ldur            x0, [fp, #-8]
    // 0xb35df4: StoreField: r1->field_b = r0
    //     0xb35df4: stur            w0, [x1, #0xb]
    // 0xb35df8: mov             x0, x1
    // 0xb35dfc: r0 = Throw()
    //     0xb35dfc: bl              #0x13ddb2c  ; ThrowStub
    // 0xb35e00: brk             #0
    // 0xb35e04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb35e04: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb35e08: b               #0xb35cd0
  }
  [closure] static Widget _defaultBottomSheetScrimBuilder(dynamic, BuildContext, Animation<double>) {
    // ** addr: 0xd36228, size: 0x34
    // 0xd36228: EnterFrame
    //     0xd36228: stp             fp, lr, [SP, #-0x10]!
    //     0xd3622c: mov             fp, SP
    // 0xd36230: CheckStackOverflow
    //     0xd36230: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd36234: cmp             SP, x16
    //     0xd36238: b.ls            #0xd36254
    // 0xd3623c: ldr             x1, [fp, #0x18]
    // 0xd36240: ldr             x2, [fp, #0x10]
    // 0xd36244: r0 = _defaultBottomSheetScrimBuilder()
    //     0xd36244: bl              #0xd36728  ; [package:flutter/src/material/scaffold.dart] Scaffold::_defaultBottomSheetScrimBuilder
    // 0xd36248: LeaveFrame
    //     0xd36248: mov             SP, fp
    //     0xd3624c: ldp             fp, lr, [SP], #0x10
    // 0xd36250: ret
    //     0xd36250: ret             
    // 0xd36254: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd36254: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd36258: b               #0xd3623c
  }
  static _ _defaultBottomSheetScrimBuilder(/* No info */) {
    // ** addr: 0xd36728, size: 0x58
    // 0xd36728: EnterFrame
    //     0xd36728: stp             fp, lr, [SP, #-0x10]!
    //     0xd3672c: mov             fp, SP
    // 0xd36730: AllocStack(0x10)
    //     0xd36730: sub             SP, SP, #0x10
    // 0xd36734: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0xd36734: stur            x2, [fp, #-8]
    // 0xd36738: r1 = 1
    //     0xd36738: mov             x1, #1
    // 0xd3673c: r0 = AllocateContext()
    //     0xd3673c: bl              #0x13de838  ; AllocateContextStub
    // 0xd36740: mov             x1, x0
    // 0xd36744: ldur            x0, [fp, #-8]
    // 0xd36748: StoreField: r1->field_f = r0
    //     0xd36748: stur            w0, [x1, #0xf]
    // 0xd3674c: mov             x2, x1
    // 0xd36750: r1 = Function '<anonymous closure>': static.
    //     0xd36750: add             x1, PP, #0x13, lsl #12  ; [pp+0x13a80] AnonymousClosure: static (0xd36780), in [package:flutter/src/material/scaffold.dart] Scaffold::_defaultBottomSheetScrimBuilder (0xd36728)
    //     0xd36754: ldr             x1, [x1, #0xa80]
    // 0xd36758: r0 = AllocateClosure()
    //     0xd36758: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3675c: stur            x0, [fp, #-0x10]
    // 0xd36760: r0 = AnimatedBuilder()
    //     0xd36760: bl              #0x918e2c  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0xd36764: ldur            x1, [fp, #-0x10]
    // 0xd36768: StoreField: r0->field_f = r1
    //     0xd36768: stur            w1, [x0, #0xf]
    // 0xd3676c: ldur            x1, [fp, #-8]
    // 0xd36770: StoreField: r0->field_b = r1
    //     0xd36770: stur            w1, [x0, #0xb]
    // 0xd36774: LeaveFrame
    //     0xd36774: mov             SP, fp
    //     0xd36778: ldp             fp, lr, [SP], #0x10
    // 0xd3677c: ret
    //     0xd3677c: ret             
  }
  [closure] static ModalBarrier <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0xd36780, size: 0xd4
    // 0xd36780: EnterFrame
    //     0xd36780: stp             fp, lr, [SP, #-0x10]!
    //     0xd36784: mov             fp, SP
    // 0xd36788: AllocStack(0x8)
    //     0xd36788: sub             SP, SP, #8
    // 0xd3678c: SetupParameters([dynamic _ /* r0 */])
    //     0xd3678c: ldr             x0, [fp, #0x20]
    //     0xd36790: ldur            w1, [x0, #0x17]
    //     0xd36794: add             x1, x1, HEAP, lsl #32
    // 0xd36798: CheckStackOverflow
    //     0xd36798: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd3679c: cmp             SP, x16
    //     0xd367a0: b.ls            #0xd3684c
    // 0xd367a4: LoadField: r0 = r1->field_f
    //     0xd367a4: ldur            w0, [x1, #0xf]
    // 0xd367a8: DecompressPointer r0
    //     0xd367a8: add             x0, x0, HEAP, lsl #32
    // 0xd367ac: r1 = LoadClassIdInstr(r0)
    //     0xd367ac: ldur            x1, [x0, #-1]
    //     0xd367b0: ubfx            x1, x1, #0xc, #0x14
    // 0xd367b4: mov             x16, x0
    // 0xd367b8: mov             x0, x1
    // 0xd367bc: mov             x1, x16
    // 0xd367c0: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0xd367c0: mov             x17, #0x4e2e
    //     0xd367c4: movk            x17, #1, lsl #16
    //     0xd367c8: add             lr, x0, x17
    //     0xd367cc: ldr             lr, [x21, lr, lsl #3]
    //     0xd367d0: blr             lr
    // 0xd367d4: LoadField: d0 = r0->field_7
    //     0xd367d4: ldur            d0, [x0, #7]
    // 0xd367d8: d1 = 1.000000
    //     0xd367d8: fmov            d1, #1.00000000
    // 0xd367dc: fsub            d2, d1, d0
    // 0xd367e0: d0 = 0.300000
    //     0xd367e0: add             x17, PP, #0x13, lsl #12  ; [pp+0x13a88] IMM: double(0.3) from 0x3fd3333333333333
    //     0xd367e4: ldr             d0, [x17, #0xa88]
    // 0xd367e8: fmul            d1, d2, d0
    // 0xd367ec: fmul            d2, d1, d0
    // 0xd367f0: d0 = 10.000000
    //     0xd367f0: fmov            d0, #10.00000000
    // 0xd367f4: fmul            d1, d2, d0
    // 0xd367f8: d0 = 0.600000
    //     0xd367f8: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c88] IMM: double(0.6) from 0x3fe3333333333333
    //     0xd367fc: ldr             d0, [x17, #0xc88]
    // 0xd36800: fsub            d2, d0, d1
    // 0xd36804: d0 = 0.100000
    //     0xd36804: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0xd36808: ldr             d0, [x17, #0x1e0]
    // 0xd3680c: fmax            v1.2d, v0.2d, v2.2d
    // 0xd36810: mov             v0.16b, v1.16b
    // 0xd36814: r1 = Instance_Color
    //     0xd36814: add             x1, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0xd36818: ldr             x1, [x1, #0x948]
    // 0xd3681c: r0 = withOpacity()
    //     0xd3681c: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xd36820: stur            x0, [fp, #-8]
    // 0xd36824: r0 = ModalBarrier()
    //     0xd36824: bl              #0xbb5c60  ; AllocateModalBarrierStub -> ModalBarrier (size=0x28)
    // 0xd36828: ldur            x1, [fp, #-8]
    // 0xd3682c: StoreField: r0->field_b = r1
    //     0xd3682c: stur            w1, [x0, #0xb]
    // 0xd36830: r1 = false
    //     0xd36830: add             x1, NULL, #0x30  ; false
    // 0xd36834: StoreField: r0->field_f = r1
    //     0xd36834: stur            w1, [x0, #0xf]
    // 0xd36838: r1 = true
    //     0xd36838: add             x1, NULL, #0x20  ; true
    // 0xd3683c: ArrayStore: r0[0] = r1  ; List_4
    //     0xd3683c: stur            w1, [x0, #0x17]
    // 0xd36840: LeaveFrame
    //     0xd36840: mov             SP, fp
    //     0xd36844: ldp             fp, lr, [SP], #0x10
    // 0xd36848: ret
    //     0xd36848: ret             
    // 0xd3684c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd3684c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd36850: b               #0xd367a4
  }
  static _ maybeOf(/* No info */) {
    // ** addr: 0xdea800, size: 0x40
    // 0xdea800: EnterFrame
    //     0xdea800: stp             fp, lr, [SP, #-0x10]!
    //     0xdea804: mov             fp, SP
    // 0xdea808: AllocStack(0x10)
    //     0xdea808: sub             SP, SP, #0x10
    // 0xdea80c: CheckStackOverflow
    //     0xdea80c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdea810: cmp             SP, x16
    //     0xdea814: b.ls            #0xdea838
    // 0xdea818: r16 = <ScaffoldState>
    //     0xdea818: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e848] TypeArguments: <ScaffoldState>
    //     0xdea81c: ldr             x16, [x16, #0x848]
    // 0xdea820: stp             x1, x16, [SP]
    // 0xdea824: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdea824: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdea828: r0 = findAncestorStateOfType()
    //     0xdea828: bl              #0x855b2c  ; [package:flutter/src/widgets/framework.dart] Element::findAncestorStateOfType
    // 0xdea82c: LeaveFrame
    //     0xdea82c: mov             SP, fp
    //     0xdea830: ldp             fp, lr, [SP], #0x10
    // 0xdea834: ret
    //     0xdea834: ret             
    // 0xdea838: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdea838: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdea83c: b               #0xdea818
  }
  static _ geometryOf(/* No info */) {
    // ** addr: 0xef3f3c, size: 0x164
    // 0xef3f3c: EnterFrame
    //     0xef3f3c: stp             fp, lr, [SP, #-0x10]!
    //     0xef3f40: mov             fp, SP
    // 0xef3f44: AllocStack(0x40)
    //     0xef3f44: sub             SP, SP, #0x40
    // 0xef3f48: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0xef3f48: stur            x1, [fp, #-8]
    // 0xef3f4c: CheckStackOverflow
    //     0xef3f4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef3f50: cmp             SP, x16
    //     0xef3f54: b.ls            #0xef4098
    // 0xef3f58: r16 = <_ScaffoldScope>
    //     0xef3f58: add             x16, PP, #0x95, lsl #12  ; [pp+0x95e90] TypeArguments: <_ScaffoldScope>
    //     0xef3f5c: ldr             x16, [x16, #0xe90]
    // 0xef3f60: stp             x1, x16, [SP]
    // 0xef3f64: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xef3f64: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xef3f68: r0 = dependOnInheritedWidgetOfExactType()
    //     0xef3f68: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xef3f6c: cmp             w0, NULL
    // 0xef3f70: b.eq            #0xef3f8c
    // 0xef3f74: LoadField: r1 = r0->field_13
    //     0xef3f74: ldur            w1, [x0, #0x13]
    // 0xef3f78: DecompressPointer r1
    //     0xef3f78: add             x1, x1, HEAP, lsl #32
    // 0xef3f7c: mov             x0, x1
    // 0xef3f80: LeaveFrame
    //     0xef3f80: mov             SP, fp
    //     0xef3f84: ldp             fp, lr, [SP], #0x10
    // 0xef3f88: ret
    //     0xef3f88: ret             
    // 0xef3f8c: r1 = <List<Object>>
    //     0xef3f8c: ldr             x1, [PP, #0x860]  ; [pp+0x860] TypeArguments: <List<Object>>
    // 0xef3f90: r0 = ErrorSummary()
    //     0xef3f90: bl              #0x84896c  ; AllocateErrorSummaryStub -> ErrorSummary (size=0x2c)
    // 0xef3f94: mov             x1, x0
    // 0xef3f98: r2 = "Scaffold.geometryOf() called with a context that does not contain a Scaffold."
    //     0xef3f98: add             x2, PP, #0x95, lsl #12  ; [pp+0x95e98] "Scaffold.geometryOf() called with a context that does not contain a Scaffold."
    //     0xef3f9c: ldr             x2, [x2, #0xe98]
    // 0xef3fa0: r3 = Instance_DiagnosticLevel
    //     0xef3fa0: ldr             x3, [PP, #0x22b0]  ; [pp+0x22b0] Obj!DiagnosticLevel@12c5f61
    // 0xef3fa4: stur            x0, [fp, #-0x10]
    // 0xef3fa8: r0 = _ErrorDiagnostic()
    //     0xef3fa8: bl              #0x829bec  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0xef3fac: r1 = <List<Object>>
    //     0xef3fac: ldr             x1, [PP, #0x860]  ; [pp+0x860] TypeArguments: <List<Object>>
    // 0xef3fb0: r0 = ErrorDescription()
    //     0xef3fb0: bl              #0x829ca4  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x2c)
    // 0xef3fb4: mov             x1, x0
    // 0xef3fb8: r2 = "This usually happens when the context provided is from the same StatefulWidget as that whose build function actually creates the Scaffold widget being sought."
    //     0xef3fb8: add             x2, PP, #0x95, lsl #12  ; [pp+0x95ea0] "This usually happens when the context provided is from the same StatefulWidget as that whose build function actually creates the Scaffold widget being sought."
    //     0xef3fbc: ldr             x2, [x2, #0xea0]
    // 0xef3fc0: r3 = Instance_DiagnosticLevel
    //     0xef3fc0: ldr             x3, [PP, #0x868]  ; [pp+0x868] Obj!DiagnosticLevel@12c5f41
    // 0xef3fc4: stur            x0, [fp, #-0x18]
    // 0xef3fc8: r0 = _ErrorDiagnostic()
    //     0xef3fc8: bl              #0x829bec  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0xef3fcc: r1 = <List<Object>>
    //     0xef3fcc: ldr             x1, [PP, #0x860]  ; [pp+0x860] TypeArguments: <List<Object>>
    // 0xef3fd0: r0 = ErrorHint()
    //     0xef3fd0: bl              #0xb35e0c  ; AllocateErrorHintStub -> ErrorHint (size=0x2c)
    // 0xef3fd4: mov             x1, x0
    // 0xef3fd8: r2 = "There are several ways to avoid this problem. The simplest is to use a Builder to get a context that is \"under\" the Scaffold. For an example of this, please see the documentation for Scaffold.of():\n  https://api.flutter.dev/flutter/material/Scaffold/of.html"
    //     0xef3fd8: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8fd98] "There are several ways to avoid this problem. The simplest is to use a Builder to get a context that is \"under\" the Scaffold. For an example of this, please see the documentation for Scaffold.of():\n  https://api.flutter.dev/flutter/material/Scaffold/of.html"
    //     0xef3fdc: ldr             x2, [x2, #0xd98]
    // 0xef3fe0: r3 = Instance_DiagnosticLevel
    //     0xef3fe0: add             x3, PP, #0x85, lsl #12  ; [pp+0x85260] Obj!DiagnosticLevel@12c5f81
    //     0xef3fe4: ldr             x3, [x3, #0x260]
    // 0xef3fe8: stur            x0, [fp, #-0x20]
    // 0xef3fec: r0 = _ErrorDiagnostic()
    //     0xef3fec: bl              #0x829bec  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0xef3ff0: r1 = <List<Object>>
    //     0xef3ff0: ldr             x1, [PP, #0x860]  ; [pp+0x860] TypeArguments: <List<Object>>
    // 0xef3ff4: r0 = ErrorHint()
    //     0xef3ff4: bl              #0xb35e0c  ; AllocateErrorHintStub -> ErrorHint (size=0x2c)
    // 0xef3ff8: mov             x1, x0
    // 0xef3ffc: r2 = "A more efficient solution is to split your build function into several widgets. This introduces a new context from which you can obtain the Scaffold. In this solution, you would have an outer widget that creates the Scaffold populated by instances of your new inner widgets, and then in these inner widgets you would use Scaffold.geometryOf()."
    //     0xef3ffc: add             x2, PP, #0x95, lsl #12  ; [pp+0x95ea8] "A more efficient solution is to split your build function into several widgets. This introduces a new context from which you can obtain the Scaffold. In this solution, you would have an outer widget that creates the Scaffold populated by instances of your new inner widgets, and then in these inner widgets you would use Scaffold.geometryOf()."
    //     0xef4000: ldr             x2, [x2, #0xea8]
    // 0xef4004: r3 = Instance_DiagnosticLevel
    //     0xef4004: add             x3, PP, #0x85, lsl #12  ; [pp+0x85260] Obj!DiagnosticLevel@12c5f81
    //     0xef4008: ldr             x3, [x3, #0x260]
    // 0xef400c: stur            x0, [fp, #-0x28]
    // 0xef4010: r0 = _ErrorDiagnostic()
    //     0xef4010: bl              #0x829bec  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0xef4014: ldur            x1, [fp, #-8]
    // 0xef4018: r0 = describeElement()
    //     0xef4018: bl              #0x89bf94  ; [package:flutter/src/widgets/framework.dart] Element::describeElement
    // 0xef401c: r1 = Null
    //     0xef401c: mov             x1, NULL
    // 0xef4020: r2 = 10
    //     0xef4020: mov             x2, #0xa
    // 0xef4024: stur            x0, [fp, #-8]
    // 0xef4028: r0 = AllocateArray()
    //     0xef4028: bl              #0x13df928  ; AllocateArrayStub
    // 0xef402c: mov             x2, x0
    // 0xef4030: ldur            x0, [fp, #-0x10]
    // 0xef4034: stur            x2, [fp, #-0x30]
    // 0xef4038: StoreField: r2->field_f = r0
    //     0xef4038: stur            w0, [x2, #0xf]
    // 0xef403c: ldur            x0, [fp, #-0x18]
    // 0xef4040: StoreField: r2->field_13 = r0
    //     0xef4040: stur            w0, [x2, #0x13]
    // 0xef4044: ldur            x0, [fp, #-0x20]
    // 0xef4048: ArrayStore: r2[0] = r0  ; List_4
    //     0xef4048: stur            w0, [x2, #0x17]
    // 0xef404c: ldur            x0, [fp, #-0x28]
    // 0xef4050: StoreField: r2->field_1b = r0
    //     0xef4050: stur            w0, [x2, #0x1b]
    // 0xef4054: ldur            x0, [fp, #-8]
    // 0xef4058: StoreField: r2->field_1f = r0
    //     0xef4058: stur            w0, [x2, #0x1f]
    // 0xef405c: r1 = <DiagnosticsNode>
    //     0xef405c: ldr             x1, [PP, #0x1ea8]  ; [pp+0x1ea8] TypeArguments: <DiagnosticsNode>
    // 0xef4060: r0 = AllocateGrowableArray()
    //     0xef4060: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xef4064: mov             x1, x0
    // 0xef4068: ldur            x0, [fp, #-0x30]
    // 0xef406c: stur            x1, [fp, #-8]
    // 0xef4070: StoreField: r1->field_f = r0
    //     0xef4070: stur            w0, [x1, #0xf]
    // 0xef4074: r0 = 10
    //     0xef4074: mov             x0, #0xa
    // 0xef4078: StoreField: r1->field_b = r0
    //     0xef4078: stur            w0, [x1, #0xb]
    // 0xef407c: r0 = FlutterError()
    //     0xef407c: bl              #0x8488dc  ; AllocateFlutterErrorStub -> FlutterError (size=0x10)
    // 0xef4080: mov             x1, x0
    // 0xef4084: ldur            x0, [fp, #-8]
    // 0xef4088: StoreField: r1->field_b = r0
    //     0xef4088: stur            w0, [x1, #0xb]
    // 0xef408c: mov             x0, x1
    // 0xef4090: r0 = Throw()
    //     0xef4090: bl              #0x13ddb2c  ; ThrowStub
    // 0xef4094: brk             #0
    // 0xef4098: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef4098: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef409c: b               #0xef3f58
  }
  _ createState(/* No info */) {
    // ** addr: 0xfa2b44, size: 0x48
    // 0xfa2b44: EnterFrame
    //     0xfa2b44: stp             fp, lr, [SP, #-0x10]!
    //     0xfa2b48: mov             fp, SP
    // 0xfa2b4c: AllocStack(0x8)
    //     0xfa2b4c: sub             SP, SP, #8
    // 0xfa2b50: CheckStackOverflow
    //     0xfa2b50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa2b54: cmp             SP, x16
    //     0xfa2b58: b.ls            #0xfa2b84
    // 0xfa2b5c: r1 = <Scaffold>
    //     0xfa2b5c: add             x1, PP, #0x26, lsl #12  ; [pp+0x26c48] TypeArguments: <Scaffold>
    //     0xfa2b60: ldr             x1, [x1, #0xc48]
    // 0xfa2b64: r0 = ScaffoldState()
    //     0xfa2b64: bl              #0xfa2dc0  ; AllocateScaffoldStateStub -> ScaffoldState (size=0x84)
    // 0xfa2b68: mov             x1, x0
    // 0xfa2b6c: stur            x0, [fp, #-8]
    // 0xfa2b70: r0 = ScaffoldState()
    //     0xfa2b70: bl              #0xfa2b8c  ; [package:flutter/src/material/scaffold.dart] ScaffoldState::ScaffoldState
    // 0xfa2b74: ldur            x0, [fp, #-8]
    // 0xfa2b78: LeaveFrame
    //     0xfa2b78: mov             SP, fp
    //     0xfa2b7c: ldp             fp, lr, [SP], #0x10
    // 0xfa2b80: ret
    //     0xfa2b80: ret             
    // 0xfa2b84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa2b84: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa2b88: b               #0xfa2b5c
  }
}

// class id: 6438, size: 0x20, field offset: 0xc
//   const constructor, 
class _FloatingActionButtonTransition extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa2af8, size: 0x40
    // 0xfa2af8: EnterFrame
    //     0xfa2af8: stp             fp, lr, [SP, #-0x10]!
    //     0xfa2afc: mov             fp, SP
    // 0xfa2b00: mov             x0, x1
    // 0xfa2b04: r1 = <_FloatingActionButtonTransition>
    //     0xfa2b04: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8fdc8] TypeArguments: <_FloatingActionButtonTransition>
    //     0xfa2b08: ldr             x1, [x1, #0xdc8]
    // 0xfa2b0c: r0 = _FloatingActionButtonTransitionState()
    //     0xfa2b0c: bl              #0xfa2b38  ; Allocate_FloatingActionButtonTransitionStateStub -> _FloatingActionButtonTransitionState (size=0x44)
    // 0xfa2b10: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa2b14: StoreField: r0->field_1b = r1
    //     0xfa2b14: stur            w1, [x0, #0x1b]
    // 0xfa2b18: StoreField: r0->field_2b = r1
    //     0xfa2b18: stur            w1, [x0, #0x2b]
    // 0xfa2b1c: StoreField: r0->field_2f = r1
    //     0xfa2b1c: stur            w1, [x0, #0x2f]
    // 0xfa2b20: StoreField: r0->field_33 = r1
    //     0xfa2b20: stur            w1, [x0, #0x33]
    // 0xfa2b24: StoreField: r0->field_37 = r1
    //     0xfa2b24: stur            w1, [x0, #0x37]
    // 0xfa2b28: StoreField: r0->field_3b = r1
    //     0xfa2b28: stur            w1, [x0, #0x3b]
    // 0xfa2b2c: LeaveFrame
    //     0xfa2b2c: mov             SP, fp
    //     0xfa2b30: ldp             fp, lr, [SP], #0x10
    // 0xfa2b34: ret
    //     0xfa2b34: ret             
  }
}

// class id: 6439, size: 0x10, field offset: 0xc
//   const constructor, 
class ScaffoldMessenger extends StatefulWidget {

  static _ of(/* No info */) {
    // ** addr: 0xdfe470, size: 0x58
    // 0xdfe470: EnterFrame
    //     0xdfe470: stp             fp, lr, [SP, #-0x10]!
    //     0xdfe474: mov             fp, SP
    // 0xdfe478: AllocStack(0x10)
    //     0xdfe478: sub             SP, SP, #0x10
    // 0xdfe47c: CheckStackOverflow
    //     0xdfe47c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdfe480: cmp             SP, x16
    //     0xdfe484: b.ls            #0xdfe4bc
    // 0xdfe488: r16 = <_ScaffoldMessengerScope>
    //     0xdfe488: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e868] TypeArguments: <_ScaffoldMessengerScope>
    //     0xdfe48c: ldr             x16, [x16, #0x868]
    // 0xdfe490: stp             x1, x16, [SP]
    // 0xdfe494: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xdfe494: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xdfe498: r0 = dependOnInheritedWidgetOfExactType()
    //     0xdfe498: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xdfe49c: cmp             w0, NULL
    // 0xdfe4a0: b.eq            #0xdfe4c4
    // 0xdfe4a4: LoadField: r1 = r0->field_f
    //     0xdfe4a4: ldur            w1, [x0, #0xf]
    // 0xdfe4a8: DecompressPointer r1
    //     0xdfe4a8: add             x1, x1, HEAP, lsl #32
    // 0xdfe4ac: mov             x0, x1
    // 0xdfe4b0: LeaveFrame
    //     0xdfe4b0: mov             SP, fp
    //     0xdfe4b4: ldp             fp, lr, [SP], #0x10
    // 0xdfe4b8: ret
    //     0xdfe4b8: ret             
    // 0xdfe4bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdfe4bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdfe4c0: b               #0xdfe488
    // 0xdfe4c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdfe4c4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static _ maybeOf(/* No info */) {
    // ** addr: 0xeeec70, size: 0x5c
    // 0xeeec70: EnterFrame
    //     0xeeec70: stp             fp, lr, [SP, #-0x10]!
    //     0xeeec74: mov             fp, SP
    // 0xeeec78: AllocStack(0x10)
    //     0xeeec78: sub             SP, SP, #0x10
    // 0xeeec7c: CheckStackOverflow
    //     0xeeec7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeeec80: cmp             SP, x16
    //     0xeeec84: b.ls            #0xeeecc4
    // 0xeeec88: r16 = <_ScaffoldMessengerScope>
    //     0xeeec88: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e868] TypeArguments: <_ScaffoldMessengerScope>
    //     0xeeec8c: ldr             x16, [x16, #0x868]
    // 0xeeec90: stp             x1, x16, [SP]
    // 0xeeec94: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xeeec94: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xeeec98: r0 = dependOnInheritedWidgetOfExactType()
    //     0xeeec98: bl              #0x84374c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xeeec9c: cmp             w0, NULL
    // 0xeeeca0: b.ne            #0xeeecac
    // 0xeeeca4: r0 = Null
    //     0xeeeca4: mov             x0, NULL
    // 0xeeeca8: b               #0xeeecb8
    // 0xeeecac: LoadField: r1 = r0->field_f
    //     0xeeecac: ldur            w1, [x0, #0xf]
    // 0xeeecb0: DecompressPointer r1
    //     0xeeecb0: add             x1, x1, HEAP, lsl #32
    // 0xeeecb4: mov             x0, x1
    // 0xeeecb8: LeaveFrame
    //     0xeeecb8: mov             SP, fp
    //     0xeeecbc: ldp             fp, lr, [SP], #0x10
    // 0xeeecc0: ret
    //     0xeeecc0: ret             
    // 0xeeecc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeeecc4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeeecc8: b               #0xeeec88
  }
  _ createState(/* No info */) {
    // ** addr: 0xfa2824, size: 0x48
    // 0xfa2824: EnterFrame
    //     0xfa2824: stp             fp, lr, [SP, #-0x10]!
    //     0xfa2828: mov             fp, SP
    // 0xfa282c: AllocStack(0x8)
    //     0xfa282c: sub             SP, SP, #8
    // 0xfa2830: CheckStackOverflow
    //     0xfa2830: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa2834: cmp             SP, x16
    //     0xfa2838: b.ls            #0xfa2864
    // 0xfa283c: r1 = <ScaffoldMessenger>
    //     0xfa283c: add             x1, PP, #0x99, lsl #12  ; [pp+0x998b0] TypeArguments: <ScaffoldMessenger>
    //     0xfa2840: ldr             x1, [x1, #0x8b0]
    // 0xfa2844: r0 = ScaffoldMessengerState()
    //     0xfa2844: bl              #0xfa2aec  ; AllocateScaffoldMessengerStateStub -> ScaffoldMessengerState (size=0x38)
    // 0xfa2848: mov             x1, x0
    // 0xfa284c: stur            x0, [fp, #-8]
    // 0xfa2850: r0 = ScaffoldMessengerState()
    //     0xfa2850: bl              #0xfa286c  ; [package:flutter/src/material/scaffold.dart] ScaffoldMessengerState::ScaffoldMessengerState
    // 0xfa2854: ldur            x0, [fp, #-8]
    // 0xfa2858: LeaveFrame
    //     0xfa2858: mov             SP, fp
    //     0xfa285c: ldp             fp, lr, [SP], #0x10
    // 0xfa2860: ret
    //     0xfa2860: ret             
    // 0xfa2864: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa2864: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa2868: b               #0xfa283c
  }
}

// class id: 6809, size: 0x18, field offset: 0x10
//   const constructor, 
class _ScaffoldScope extends InheritedWidget {

  _ updateShouldNotify(/* No info */) {
    // ** addr: 0xc01100, size: 0x8c
    // 0xc01100: EnterFrame
    //     0xc01100: stp             fp, lr, [SP, #-0x10]!
    //     0xc01104: mov             fp, SP
    // 0xc01108: AllocStack(0x10)
    //     0xc01108: sub             SP, SP, #0x10
    // 0xc0110c: SetupParameters(_ScaffoldScope this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xc0110c: mov             x0, x2
    //     0xc01110: mov             x4, x1
    //     0xc01114: mov             x3, x2
    //     0xc01118: stur            x1, [fp, #-8]
    //     0xc0111c: stur            x2, [fp, #-0x10]
    // 0xc01120: r2 = Null
    //     0xc01120: mov             x2, NULL
    // 0xc01124: r1 = Null
    //     0xc01124: mov             x1, NULL
    // 0xc01128: r4 = 60
    //     0xc01128: mov             x4, #0x3c
    // 0xc0112c: branchIfSmi(r0, 0xc01138)
    //     0xc0112c: tbz             w0, #0, #0xc01138
    // 0xc01130: r4 = LoadClassIdInstr(r0)
    //     0xc01130: ldur            x4, [x0, #-1]
    //     0xc01134: ubfx            x4, x4, #0xc, #0x14
    // 0xc01138: r17 = 6809
    //     0xc01138: mov             x17, #0x1a99
    // 0xc0113c: cmp             x4, x17
    // 0xc01140: b.eq            #0xc01158
    // 0xc01144: r8 = _ScaffoldScope
    //     0xc01144: add             x8, PP, #0x99, lsl #12  ; [pp+0x99708] Type: _ScaffoldScope
    //     0xc01148: ldr             x8, [x8, #0x708]
    // 0xc0114c: r3 = Null
    //     0xc0114c: add             x3, PP, #0x99, lsl #12  ; [pp+0x99710] Null
    //     0xc01150: ldr             x3, [x3, #0x710]
    // 0xc01154: r0 = DefaultTypeTest()
    //     0xc01154: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xc01158: ldur            x1, [fp, #-8]
    // 0xc0115c: LoadField: r2 = r1->field_f
    //     0xc0115c: ldur            w2, [x1, #0xf]
    // 0xc01160: DecompressPointer r2
    //     0xc01160: add             x2, x2, HEAP, lsl #32
    // 0xc01164: ldur            x1, [fp, #-0x10]
    // 0xc01168: LoadField: r3 = r1->field_f
    //     0xc01168: ldur            w3, [x1, #0xf]
    // 0xc0116c: DecompressPointer r3
    //     0xc0116c: add             x3, x3, HEAP, lsl #32
    // 0xc01170: cmp             w2, w3
    // 0xc01174: r16 = true
    //     0xc01174: add             x16, NULL, #0x20  ; true
    // 0xc01178: r17 = false
    //     0xc01178: add             x17, NULL, #0x30  ; false
    // 0xc0117c: csel            x0, x16, x17, ne
    // 0xc01180: LeaveFrame
    //     0xc01180: mov             SP, fp
    //     0xc01184: ldp             fp, lr, [SP], #0x10
    // 0xc01188: ret
    //     0xc01188: ret             
  }
}

// class id: 6810, size: 0x14, field offset: 0x10
//   const constructor, 
class _ScaffoldMessengerScope extends InheritedWidget {

  _ updateShouldNotify(/* No info */) {
    // ** addr: 0xc01074, size: 0x8c
    // 0xc01074: EnterFrame
    //     0xc01074: stp             fp, lr, [SP, #-0x10]!
    //     0xc01078: mov             fp, SP
    // 0xc0107c: AllocStack(0x10)
    //     0xc0107c: sub             SP, SP, #0x10
    // 0xc01080: SetupParameters(_ScaffoldMessengerScope this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xc01080: mov             x0, x2
    //     0xc01084: mov             x4, x1
    //     0xc01088: mov             x3, x2
    //     0xc0108c: stur            x1, [fp, #-8]
    //     0xc01090: stur            x2, [fp, #-0x10]
    // 0xc01094: r2 = Null
    //     0xc01094: mov             x2, NULL
    // 0xc01098: r1 = Null
    //     0xc01098: mov             x1, NULL
    // 0xc0109c: r4 = 60
    //     0xc0109c: mov             x4, #0x3c
    // 0xc010a0: branchIfSmi(r0, 0xc010ac)
    //     0xc010a0: tbz             w0, #0, #0xc010ac
    // 0xc010a4: r4 = LoadClassIdInstr(r0)
    //     0xc010a4: ldur            x4, [x0, #-1]
    //     0xc010a8: ubfx            x4, x4, #0xc, #0x14
    // 0xc010ac: r17 = 6810
    //     0xc010ac: mov             x17, #0x1a9a
    // 0xc010b0: cmp             x4, x17
    // 0xc010b4: b.eq            #0xc010cc
    // 0xc010b8: r8 = _ScaffoldMessengerScope
    //     0xc010b8: add             x8, PP, #0xad, lsl #12  ; [pp+0xade88] Type: _ScaffoldMessengerScope
    //     0xc010bc: ldr             x8, [x8, #0xe88]
    // 0xc010c0: r3 = Null
    //     0xc010c0: add             x3, PP, #0xad, lsl #12  ; [pp+0xade90] Null
    //     0xc010c4: ldr             x3, [x3, #0xe90]
    // 0xc010c8: r0 = DefaultTypeTest()
    //     0xc010c8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xc010cc: ldur            x1, [fp, #-8]
    // 0xc010d0: LoadField: r2 = r1->field_f
    //     0xc010d0: ldur            w2, [x1, #0xf]
    // 0xc010d4: DecompressPointer r2
    //     0xc010d4: add             x2, x2, HEAP, lsl #32
    // 0xc010d8: ldur            x1, [fp, #-0x10]
    // 0xc010dc: LoadField: r3 = r1->field_f
    //     0xc010dc: ldur            w3, [x1, #0xf]
    // 0xc010e0: DecompressPointer r3
    //     0xc010e0: add             x3, x3, HEAP, lsl #32
    // 0xc010e4: cmp             w2, w3
    // 0xc010e8: r16 = true
    //     0xc010e8: add             x16, NULL, #0x20  ; true
    // 0xc010ec: r17 = false
    //     0xc010ec: add             x17, NULL, #0x30  ; false
    // 0xc010f0: csel            x0, x16, x17, ne
    // 0xc010f4: LeaveFrame
    //     0xc010f4: mov             SP, fp
    //     0xc010f8: ldp             fp, lr, [SP], #0x10
    // 0xc010fc: ret
    //     0xc010fc: ret             
  }
}

// class id: 8268, size: 0x14, field offset: 0x14
enum _ScaffoldSlot extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11aa6d4, size: 0x64
    // 0x11aa6d4: EnterFrame
    //     0x11aa6d4: stp             fp, lr, [SP, #-0x10]!
    //     0x11aa6d8: mov             fp, SP
    // 0x11aa6dc: AllocStack(0x10)
    //     0x11aa6dc: sub             SP, SP, #0x10
    // 0x11aa6e0: SetupParameters(_ScaffoldSlot this /* r1 => r0, fp-0x8 */)
    //     0x11aa6e0: mov             x0, x1
    //     0x11aa6e4: stur            x1, [fp, #-8]
    // 0x11aa6e8: CheckStackOverflow
    //     0x11aa6e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11aa6ec: cmp             SP, x16
    //     0x11aa6f0: b.ls            #0x11aa730
    // 0x11aa6f4: r1 = Null
    //     0x11aa6f4: mov             x1, NULL
    // 0x11aa6f8: r2 = 4
    //     0x11aa6f8: mov             x2, #4
    // 0x11aa6fc: r0 = AllocateArray()
    //     0x11aa6fc: bl              #0x13df928  ; AllocateArrayStub
    // 0x11aa700: r16 = "_ScaffoldSlot."
    //     0x11aa700: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8fd70] "_ScaffoldSlot."
    //     0x11aa704: ldr             x16, [x16, #0xd70]
    // 0x11aa708: StoreField: r0->field_f = r16
    //     0x11aa708: stur            w16, [x0, #0xf]
    // 0x11aa70c: ldur            x1, [fp, #-8]
    // 0x11aa710: LoadField: r2 = r1->field_f
    //     0x11aa710: ldur            w2, [x1, #0xf]
    // 0x11aa714: DecompressPointer r2
    //     0x11aa714: add             x2, x2, HEAP, lsl #32
    // 0x11aa718: StoreField: r0->field_13 = r2
    //     0x11aa718: stur            w2, [x0, #0x13]
    // 0x11aa71c: str             x0, [SP]
    // 0x11aa720: r0 = _interpolate()
    //     0x11aa720: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11aa724: LeaveFrame
    //     0x11aa724: mov             SP, fp
    //     0x11aa728: ldp             fp, lr, [SP], #0x10
    // 0x11aa72c: ret
    //     0x11aa72c: ret             
    // 0x11aa730: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11aa730: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11aa734: b               #0x11aa6f4
  }
}
