// lib: , url: package:flutter/src/material/desktop_text_selection_toolbar.dart

// class id: 1048878, size: 0x8
class :: {
}

// class id: 6168, size: 0x14, field offset: 0xc
//   const constructor, 
class DesktopTextSelectionToolbar extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfb6fdc, size: 0x150
    // 0xfb6fdc: EnterFrame
    //     0xfb6fdc: stp             fp, lr, [SP, #-0x10]!
    //     0xfb6fe0: mov             fp, SP
    // 0xfb6fe4: AllocStack(0x28)
    //     0xfb6fe4: sub             SP, SP, #0x28
    // 0xfb6fe8: SetupParameters(DesktopTextSelectionToolbar this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1 */)
    //     0xfb6fe8: mov             x0, x1
    //     0xfb6fec: stur            x1, [fp, #-8]
    //     0xfb6ff0: mov             x1, x2
    // 0xfb6ff4: CheckStackOverflow
    //     0xfb6ff4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb6ff8: cmp             SP, x16
    //     0xfb6ffc: b.ls            #0xfb7124
    // 0xfb7000: r0 = paddingOf()
    //     0xfb7000: bl              #0xd1a984  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::paddingOf
    // 0xfb7004: LoadField: d0 = r0->field_f
    //     0xfb7004: ldur            d0, [x0, #0xf]
    // 0xfb7008: d1 = 8.000000
    //     0xfb7008: fmov            d1, #8.00000000
    // 0xfb700c: fadd            d2, d0, d1
    // 0xfb7010: stur            d2, [fp, #-0x28]
    // 0xfb7014: r0 = Offset()
    //     0xfb7014: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xfb7018: d0 = 8.000000
    //     0xfb7018: fmov            d0, #8.00000000
    // 0xfb701c: stur            x0, [fp, #-0x10]
    // 0xfb7020: StoreField: r0->field_7 = d0
    //     0xfb7020: stur            d0, [x0, #7]
    // 0xfb7024: ldur            d1, [fp, #-0x28]
    // 0xfb7028: StoreField: r0->field_f = d1
    //     0xfb7028: stur            d1, [x0, #0xf]
    // 0xfb702c: r0 = EdgeInsets()
    //     0xfb702c: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xfb7030: d0 = 8.000000
    //     0xfb7030: fmov            d0, #8.00000000
    // 0xfb7034: stur            x0, [fp, #-0x18]
    // 0xfb7038: StoreField: r0->field_7 = d0
    //     0xfb7038: stur            d0, [x0, #7]
    // 0xfb703c: ldur            d1, [fp, #-0x28]
    // 0xfb7040: StoreField: r0->field_f = d1
    //     0xfb7040: stur            d1, [x0, #0xf]
    // 0xfb7044: ArrayStore: r0[0] = d0  ; List_8
    //     0xfb7044: stur            d0, [x0, #0x17]
    // 0xfb7048: StoreField: r0->field_1f = d0
    //     0xfb7048: stur            d0, [x0, #0x1f]
    // 0xfb704c: ldur            x3, [fp, #-8]
    // 0xfb7050: LoadField: r1 = r3->field_b
    //     0xfb7050: ldur            w1, [x3, #0xb]
    // 0xfb7054: DecompressPointer r1
    //     0xfb7054: add             x1, x1, HEAP, lsl #32
    // 0xfb7058: ldur            x2, [fp, #-0x10]
    // 0xfb705c: r0 = -()
    //     0xfb705c: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0xfb7060: stur            x0, [fp, #-0x10]
    // 0xfb7064: r0 = DesktopTextSelectionToolbarLayoutDelegate()
    //     0xfb7064: bl              #0xfabe60  ; AllocateDesktopTextSelectionToolbarLayoutDelegateStub -> DesktopTextSelectionToolbarLayoutDelegate (size=0x10)
    // 0xfb7068: mov             x1, x0
    // 0xfb706c: ldur            x0, [fp, #-0x10]
    // 0xfb7070: stur            x1, [fp, #-0x20]
    // 0xfb7074: StoreField: r1->field_b = r0
    //     0xfb7074: stur            w0, [x1, #0xb]
    // 0xfb7078: ldur            x0, [fp, #-8]
    // 0xfb707c: LoadField: r2 = r0->field_f
    //     0xfb707c: ldur            w2, [x0, #0xf]
    // 0xfb7080: DecompressPointer r2
    //     0xfb7080: add             x2, x2, HEAP, lsl #32
    // 0xfb7084: stur            x2, [fp, #-0x10]
    // 0xfb7088: r0 = Column()
    //     0xfb7088: bl              #0x8a5b1c  ; AllocateColumnStub -> Column (size=0x38)
    // 0xfb708c: mov             x1, x0
    // 0xfb7090: r0 = Instance_Axis
    //     0xfb7090: ldr             x0, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xfb7094: StoreField: r1->field_f = r0
    //     0xfb7094: stur            w0, [x1, #0xf]
    // 0xfb7098: r0 = Instance_MainAxisAlignment
    //     0xfb7098: add             x0, PP, #0x15, lsl #12  ; [pp+0x15820] Obj!MainAxisAlignment@12c4541
    //     0xfb709c: ldr             x0, [x0, #0x820]
    // 0xfb70a0: StoreField: r1->field_13 = r0
    //     0xfb70a0: stur            w0, [x1, #0x13]
    // 0xfb70a4: r0 = Instance_MainAxisSize
    //     0xfb70a4: add             x0, PP, #0x17, lsl #12  ; [pp+0x17200] Obj!MainAxisSize@12c4601
    //     0xfb70a8: ldr             x0, [x0, #0x200]
    // 0xfb70ac: ArrayStore: r1[0] = r0  ; List_4
    //     0xfb70ac: stur            w0, [x1, #0x17]
    // 0xfb70b0: r0 = Instance_CrossAxisAlignment
    //     0xfb70b0: add             x0, PP, #0x15, lsl #12  ; [pp+0x15888] Obj!CrossAxisAlignment@12c44a1
    //     0xfb70b4: ldr             x0, [x0, #0x888]
    // 0xfb70b8: StoreField: r1->field_1b = r0
    //     0xfb70b8: stur            w0, [x1, #0x1b]
    // 0xfb70bc: r0 = Instance_VerticalDirection
    //     0xfb70bc: add             x0, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xfb70c0: ldr             x0, [x0, #0x838]
    // 0xfb70c4: StoreField: r1->field_23 = r0
    //     0xfb70c4: stur            w0, [x1, #0x23]
    // 0xfb70c8: r0 = Instance_Clip
    //     0xfb70c8: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xfb70cc: ldr             x0, [x0, #0x840]
    // 0xfb70d0: StoreField: r1->field_2b = r0
    //     0xfb70d0: stur            w0, [x1, #0x2b]
    // 0xfb70d4: StoreField: r1->field_2f = rZR
    //     0xfb70d4: stur            xzr, [x1, #0x2f]
    // 0xfb70d8: ldur            x0, [fp, #-0x10]
    // 0xfb70dc: StoreField: r1->field_b = r0
    //     0xfb70dc: stur            w0, [x1, #0xb]
    // 0xfb70e0: r0 = _defaultToolbarBuilder()
    //     0xfb70e0: bl              #0xfb712c  ; [package:flutter/src/material/desktop_text_selection_toolbar.dart] DesktopTextSelectionToolbar::_defaultToolbarBuilder
    // 0xfb70e4: stur            x0, [fp, #-8]
    // 0xfb70e8: r0 = CustomSingleChildLayout()
    //     0xfb70e8: bl              #0xd70b7c  ; AllocateCustomSingleChildLayoutStub -> CustomSingleChildLayout (size=0x14)
    // 0xfb70ec: mov             x1, x0
    // 0xfb70f0: ldur            x0, [fp, #-0x20]
    // 0xfb70f4: stur            x1, [fp, #-0x10]
    // 0xfb70f8: StoreField: r1->field_f = r0
    //     0xfb70f8: stur            w0, [x1, #0xf]
    // 0xfb70fc: ldur            x0, [fp, #-8]
    // 0xfb7100: StoreField: r1->field_b = r0
    //     0xfb7100: stur            w0, [x1, #0xb]
    // 0xfb7104: r0 = Padding()
    //     0xfb7104: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xfb7108: ldur            x1, [fp, #-0x18]
    // 0xfb710c: StoreField: r0->field_f = r1
    //     0xfb710c: stur            w1, [x0, #0xf]
    // 0xfb7110: ldur            x1, [fp, #-0x10]
    // 0xfb7114: StoreField: r0->field_b = r1
    //     0xfb7114: stur            w1, [x0, #0xb]
    // 0xfb7118: LeaveFrame
    //     0xfb7118: mov             SP, fp
    //     0xfb711c: ldp             fp, lr, [SP], #0x10
    // 0xfb7120: ret
    //     0xfb7120: ret             
    // 0xfb7124: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb7124: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb7128: b               #0xfb7000
  }
  static _ _defaultToolbarBuilder(/* No info */) {
    // ** addr: 0xfb712c, size: 0x90
    // 0xfb712c: EnterFrame
    //     0xfb712c: stp             fp, lr, [SP, #-0x10]!
    //     0xfb7130: mov             fp, SP
    // 0xfb7134: AllocStack(0x10)
    //     0xfb7134: sub             SP, SP, #0x10
    // 0xfb7138: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0xfb7138: stur            x1, [fp, #-8]
    // 0xfb713c: r0 = Material()
    //     0xfb713c: bl              #0x8a54b0  ; AllocateMaterialStub -> Material (size=0x44)
    // 0xfb7140: mov             x1, x0
    // 0xfb7144: r0 = Instance_MaterialType
    //     0xfb7144: add             x0, PP, #0x8c, lsl #12  ; [pp+0x8c988] Obj!MaterialType@12c53c1
    //     0xfb7148: ldr             x0, [x0, #0x988]
    // 0xfb714c: stur            x1, [fp, #-0x10]
    // 0xfb7150: StoreField: r1->field_f = r0
    //     0xfb7150: stur            w0, [x1, #0xf]
    // 0xfb7154: d0 = 1.000000
    //     0xfb7154: fmov            d0, #1.00000000
    // 0xfb7158: ArrayStore: r1[0] = d0  ; List_8
    //     0xfb7158: stur            d0, [x1, #0x17]
    // 0xfb715c: r0 = Instance_BorderRadius
    //     0xfb715c: add             x0, PP, #0x8c, lsl #12  ; [pp+0x8c990] Obj!BorderRadius@129e4f1
    //     0xfb7160: ldr             x0, [x0, #0x990]
    // 0xfb7164: StoreField: r1->field_3f = r0
    //     0xfb7164: stur            w0, [x1, #0x3f]
    // 0xfb7168: r0 = true
    //     0xfb7168: add             x0, NULL, #0x20  ; true
    // 0xfb716c: StoreField: r1->field_33 = r0
    //     0xfb716c: stur            w0, [x1, #0x33]
    // 0xfb7170: r0 = Instance_Clip
    //     0xfb7170: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e6f0] Obj!Clip@12c8101
    //     0xfb7174: ldr             x0, [x0, #0x6f0]
    // 0xfb7178: StoreField: r1->field_37 = r0
    //     0xfb7178: stur            w0, [x1, #0x37]
    // 0xfb717c: r0 = Instance_Duration
    //     0xfb717c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xfb7180: ldr             x0, [x0, #0x318]
    // 0xfb7184: StoreField: r1->field_3b = r0
    //     0xfb7184: stur            w0, [x1, #0x3b]
    // 0xfb7188: ldur            x0, [fp, #-8]
    // 0xfb718c: StoreField: r1->field_b = r0
    //     0xfb718c: stur            w0, [x1, #0xb]
    // 0xfb7190: r0 = false
    //     0xfb7190: add             x0, NULL, #0x30  ; false
    // 0xfb7194: StoreField: r1->field_13 = r0
    //     0xfb7194: stur            w0, [x1, #0x13]
    // 0xfb7198: r0 = SizedBox()
    //     0xfb7198: bl              #0x8a7210  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0xfb719c: r1 = 222.000000
    //     0xfb719c: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c998] 222
    //     0xfb71a0: ldr             x1, [x1, #0x998]
    // 0xfb71a4: StoreField: r0->field_f = r1
    //     0xfb71a4: stur            w1, [x0, #0xf]
    // 0xfb71a8: ldur            x1, [fp, #-0x10]
    // 0xfb71ac: StoreField: r0->field_b = r1
    //     0xfb71ac: stur            w1, [x0, #0xb]
    // 0xfb71b0: LeaveFrame
    //     0xfb71b0: mov             SP, fp
    //     0xfb71b4: ldp             fp, lr, [SP], #0x10
    // 0xfb71b8: ret
    //     0xfb71b8: ret             
  }
}
