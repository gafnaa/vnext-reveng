// lib: , url: package:flutter/src/material/text_button.dart

// class id: 1048959, size: 0x8
class :: {

  static _ _scaledPadding(/* No info */) {
    // ** addr: 0x1141de8, size: 0xe4
    // 0x1141de8: EnterFrame
    //     0x1141de8: stp             fp, lr, [SP, #-0x10]!
    //     0x1141dec: mov             fp, SP
    // 0x1141df0: AllocStack(0x18)
    //     0x1141df0: sub             SP, SP, #0x18
    // 0x1141df4: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */)
    //     0x1141df4: mov             x0, x1
    //     0x1141df8: stur            x1, [fp, #-8]
    // 0x1141dfc: CheckStackOverflow
    //     0x1141dfc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1141e00: cmp             SP, x16
    //     0x1141e04: b.ls            #0x1141ec4
    // 0x1141e08: mov             x1, x0
    // 0x1141e0c: r0 = of()
    //     0x1141e0c: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x1141e10: stur            x0, [fp, #-0x10]
    // 0x1141e14: LoadField: r1 = r0->field_87
    //     0x1141e14: ldur            w1, [x0, #0x87]
    // 0x1141e18: DecompressPointer r1
    //     0x1141e18: add             x1, x1, HEAP, lsl #32
    // 0x1141e1c: LoadField: r2 = r1->field_37
    //     0x1141e1c: ldur            w2, [x1, #0x37]
    // 0x1141e20: DecompressPointer r2
    //     0x1141e20: add             x2, x2, HEAP, lsl #32
    // 0x1141e24: LoadField: r1 = r2->field_1f
    //     0x1141e24: ldur            w1, [x2, #0x1f]
    // 0x1141e28: DecompressPointer r1
    //     0x1141e28: add             x1, x1, HEAP, lsl #32
    // 0x1141e2c: cmp             w1, NULL
    // 0x1141e30: b.ne            #0x1141e3c
    // 0x1141e34: d0 = 14.000000
    //     0x1141e34: fmov            d0, #14.00000000
    // 0x1141e38: b               #0x1141e40
    // 0x1141e3c: LoadField: d0 = r1->field_7
    //     0x1141e3c: ldur            d0, [x1, #7]
    // 0x1141e40: ldur            x1, [fp, #-8]
    // 0x1141e44: stur            d0, [fp, #-0x18]
    // 0x1141e48: r0 = textScalerOf()
    //     0x1141e48: bl              #0xd16168  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::textScalerOf
    // 0x1141e4c: r1 = LoadClassIdInstr(r0)
    //     0x1141e4c: ldur            x1, [x0, #-1]
    //     0x1141e50: ubfx            x1, x1, #0xc, #0x14
    // 0x1141e54: mov             x16, x0
    // 0x1141e58: mov             x0, x1
    // 0x1141e5c: mov             x1, x16
    // 0x1141e60: ldur            d0, [fp, #-0x18]
    // 0x1141e64: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1141e64: sub             lr, x0, #1, lsl #12
    //     0x1141e68: ldr             lr, [x21, lr, lsl #3]
    //     0x1141e6c: blr             lr
    // 0x1141e70: LoadField: d0 = r0->field_7
    //     0x1141e70: ldur            d0, [x0, #7]
    // 0x1141e74: d1 = 14.000000
    //     0x1141e74: fmov            d1, #14.00000000
    // 0x1141e78: fdiv            d2, d0, d1
    // 0x1141e7c: ldur            x0, [fp, #-0x10]
    // 0x1141e80: LoadField: r1 = r0->field_2f
    //     0x1141e80: ldur            w1, [x0, #0x2f]
    // 0x1141e84: DecompressPointer r1
    //     0x1141e84: add             x1, x1, HEAP, lsl #32
    // 0x1141e88: tbnz            w1, #4, #0x1141e98
    // 0x1141e8c: r1 = Instance_EdgeInsets
    //     0x1141e8c: add             x1, PP, #0x96, lsl #12  ; [pp+0x96168] Obj!EdgeInsets@129e131
    //     0x1141e90: ldr             x1, [x1, #0x168]
    // 0x1141e94: b               #0x1141ea0
    // 0x1141e98: r1 = Instance_EdgeInsets
    //     0x1141e98: add             x1, PP, #0x18, lsl #12  ; [pp+0x18338] Obj!EdgeInsets@129d051
    //     0x1141e9c: ldr             x1, [x1, #0x338]
    // 0x1141ea0: mov             v0.16b, v2.16b
    // 0x1141ea4: r2 = Instance_EdgeInsets
    //     0x1141ea4: add             x2, PP, #0x7a, lsl #12  ; [pp+0x7abf0] Obj!EdgeInsets@129cd21
    //     0x1141ea8: ldr             x2, [x2, #0xbf0]
    // 0x1141eac: r3 = Instance_EdgeInsets
    //     0x1141eac: add             x3, PP, #0x1c, lsl #12  ; [pp+0x1c430] Obj!EdgeInsets@129dc51
    //     0x1141eb0: ldr             x3, [x3, #0x430]
    // 0x1141eb4: r0 = scaledPadding()
    //     0x1141eb4: bl              #0x1140cd0  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::scaledPadding
    // 0x1141eb8: LeaveFrame
    //     0x1141eb8: mov             SP, fp
    //     0x1141ebc: ldp             fp, lr, [SP], #0x10
    // 0x1141ec0: ret
    //     0x1141ec0: ret             
    // 0x1141ec4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1141ec4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1141ec8: b               #0x1141e08
  }
}

// class id: 5193, size: 0x74, field offset: 0x6c
class _TextButtonDefaultsM3 extends ButtonStyle {

  late final ColorScheme _colors; // offset: 0x70

  get _ padding(/* No info */) {
    // ** addr: 0x1141d94, size: 0x54
    // 0x1141d94: EnterFrame
    //     0x1141d94: stp             fp, lr, [SP, #-0x10]!
    //     0x1141d98: mov             fp, SP
    // 0x1141d9c: AllocStack(0x8)
    //     0x1141d9c: sub             SP, SP, #8
    // 0x1141da0: CheckStackOverflow
    //     0x1141da0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1141da4: cmp             SP, x16
    //     0x1141da8: b.ls            #0x1141de0
    // 0x1141dac: LoadField: r0 = r1->field_6b
    //     0x1141dac: ldur            w0, [x1, #0x6b]
    // 0x1141db0: DecompressPointer r0
    //     0x1141db0: add             x0, x0, HEAP, lsl #32
    // 0x1141db4: mov             x1, x0
    // 0x1141db8: r0 = _scaledPadding()
    //     0x1141db8: bl              #0x1141de8  ; [package:flutter/src/material/text_button.dart] ::_scaledPadding
    // 0x1141dbc: r1 = <EdgeInsetsGeometry>
    //     0x1141dbc: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a98] TypeArguments: <EdgeInsetsGeometry>
    //     0x1141dc0: ldr             x1, [x1, #0xa98]
    // 0x1141dc4: stur            x0, [fp, #-8]
    // 0x1141dc8: r0 = WidgetStatePropertyAll()
    //     0x1141dc8: bl              #0xd132c8  ; AllocateWidgetStatePropertyAllStub -> WidgetStatePropertyAll<X0> (size=0x10)
    // 0x1141dcc: ldur            x1, [fp, #-8]
    // 0x1141dd0: StoreField: r0->field_b = r1
    //     0x1141dd0: stur            w1, [x0, #0xb]
    // 0x1141dd4: LeaveFrame
    //     0x1141dd4: mov             SP, fp
    //     0x1141dd8: ldp             fp, lr, [SP], #0x10
    // 0x1141ddc: ret
    //     0x1141ddc: ret             
    // 0x1141de0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1141de0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1141de4: b               #0x1141dac
  }
  get _ iconSize(/* No info */) {
    // ** addr: 0x1151ba0, size: 0xc
    // 0x1151ba0: r0 = Instance_WidgetStatePropertyAll
    //     0x1151ba0: add             x0, PP, #0xa0, lsl #12  ; [pp+0xa0e10] Obj!WidgetStatePropertyAll<double>@128a0b1
    //     0x1151ba4: ldr             x0, [x0, #0xe10]
    // 0x1151ba8: ret
    //     0x1151ba8: ret             
  }
  get _ iconColor(/* No info */) {
    // ** addr: 0x1152344, size: 0x68
    // 0x1152344: EnterFrame
    //     0x1152344: stp             fp, lr, [SP, #-0x10]!
    //     0x1152348: mov             fp, SP
    // 0x115234c: AllocStack(0x18)
    //     0x115234c: sub             SP, SP, #0x18
    // 0x1152350: SetupParameters(_TextButtonDefaultsM3 this /* r1 => r1, fp-0x8 */)
    //     0x1152350: stur            x1, [fp, #-8]
    // 0x1152354: CheckStackOverflow
    //     0x1152354: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1152358: cmp             SP, x16
    //     0x115235c: b.ls            #0x11523a4
    // 0x1152360: r1 = 1
    //     0x1152360: mov             x1, #1
    // 0x1152364: r0 = AllocateContext()
    //     0x1152364: bl              #0x13de838  ; AllocateContextStub
    // 0x1152368: mov             x1, x0
    // 0x115236c: ldur            x0, [fp, #-8]
    // 0x1152370: StoreField: r1->field_f = r0
    //     0x1152370: stur            w0, [x1, #0xf]
    // 0x1152374: mov             x2, x1
    // 0x1152378: r1 = Function '<anonymous closure>':.
    //     0x1152378: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa10e0] AnonymousClosure: (0x11523ac), in [package:flutter/src/material/text_button.dart] _TextButtonDefaultsM3::iconColor (0x1152344)
    //     0x115237c: ldr             x1, [x1, #0xe0]
    // 0x1152380: r0 = AllocateClosure()
    //     0x1152380: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1152384: r16 = <Color>
    //     0x1152384: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0x1152388: ldr             x16, [x16, #0xa90]
    // 0x115238c: stp             x0, x16, [SP]
    // 0x1152390: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1152390: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1152394: r0 = resolveWith()
    //     0x1152394: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1152398: LeaveFrame
    //     0x1152398: mov             SP, fp
    //     0x115239c: ldp             fp, lr, [SP], #0x10
    // 0x11523a0: ret
    //     0x11523a0: ret             
    // 0x11523a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11523a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11523a8: b               #0x1152360
  }
  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0x11523ac, size: 0x264
    // 0x11523ac: EnterFrame
    //     0x11523ac: stp             fp, lr, [SP, #-0x10]!
    //     0x11523b0: mov             fp, SP
    // 0x11523b4: AllocStack(0x8)
    //     0x11523b4: sub             SP, SP, #8
    // 0x11523b8: SetupParameters([dynamic _ /* r0 */])
    //     0x11523b8: ldr             x0, [fp, #0x18]
    //     0x11523bc: ldur            w3, [x0, #0x17]
    //     0x11523c0: add             x3, x3, HEAP, lsl #32
    //     0x11523c4: stur            x3, [fp, #-8]
    // 0x11523c8: CheckStackOverflow
    //     0x11523c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11523cc: cmp             SP, x16
    //     0x11523d0: b.ls            #0x1152608
    // 0x11523d4: ldr             x4, [fp, #0x10]
    // 0x11523d8: r0 = LoadClassIdInstr(r4)
    //     0x11523d8: ldur            x0, [x4, #-1]
    //     0x11523dc: ubfx            x0, x0, #0xc, #0x14
    // 0x11523e0: mov             x1, x4
    // 0x11523e4: r2 = Instance_WidgetState
    //     0x11523e4: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0x11523e8: ldr             x2, [x2, #0xa70]
    // 0x11523ec: r0 = GDT[cid_x0 + 0x12929]()
    //     0x11523ec: mov             x17, #0x2929
    //     0x11523f0: movk            x17, #1, lsl #16
    //     0x11523f4: add             lr, x0, x17
    //     0x11523f8: ldr             lr, [x21, lr, lsl #3]
    //     0x11523fc: blr             lr
    // 0x1152400: tbnz            w0, #4, #0x1152460
    // 0x1152404: ldur            x3, [fp, #-8]
    // 0x1152408: LoadField: r1 = r3->field_f
    //     0x1152408: ldur            w1, [x3, #0xf]
    // 0x115240c: DecompressPointer r1
    //     0x115240c: add             x1, x1, HEAP, lsl #32
    // 0x1152410: LoadField: r0 = r1->field_6f
    //     0x1152410: ldur            w0, [x1, #0x6f]
    // 0x1152414: DecompressPointer r0
    //     0x1152414: add             x0, x0, HEAP, lsl #32
    // 0x1152418: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x115241c: cmp             w0, w16
    // 0x1152420: b.ne            #0x1152430
    // 0x1152424: r2 = _colors
    //     0x1152424: add             x2, PP, #0xa1, lsl #12  ; [pp+0xa10e8] Field <_TextButtonDefaultsM3@627343580._colors@627343580>: late final (offset: 0x70)
    //     0x1152428: ldr             x2, [x2, #0xe8]
    // 0x115242c: r0 = InitLateFinalInstanceField()
    //     0x115242c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1152430: LoadField: r1 = r0->field_7f
    //     0x1152430: ldur            w1, [x0, #0x7f]
    // 0x1152434: DecompressPointer r1
    //     0x1152434: add             x1, x1, HEAP, lsl #32
    // 0x1152438: r0 = LoadClassIdInstr(r1)
    //     0x1152438: ldur            x0, [x1, #-1]
    //     0x115243c: ubfx            x0, x0, #0xc, #0x14
    // 0x1152440: d0 = 0.380000
    //     0x1152440: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0x1152444: ldr             d0, [x17, #0x1f0]
    // 0x1152448: r0 = GDT[cid_x0 + -0x1000]()
    //     0x1152448: sub             lr, x0, #1, lsl #12
    //     0x115244c: ldr             lr, [x21, lr, lsl #3]
    //     0x1152450: blr             lr
    // 0x1152454: LeaveFrame
    //     0x1152454: mov             SP, fp
    //     0x1152458: ldp             fp, lr, [SP], #0x10
    // 0x115245c: ret
    //     0x115245c: ret             
    // 0x1152460: ldr             x4, [fp, #0x10]
    // 0x1152464: ldur            x3, [fp, #-8]
    // 0x1152468: r0 = LoadClassIdInstr(r4)
    //     0x1152468: ldur            x0, [x4, #-1]
    //     0x115246c: ubfx            x0, x0, #0xc, #0x14
    // 0x1152470: mov             x1, x4
    // 0x1152474: r2 = Instance_WidgetState
    //     0x1152474: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0x1152478: ldr             x2, [x2, #0xa48]
    // 0x115247c: r0 = GDT[cid_x0 + 0x12929]()
    //     0x115247c: mov             x17, #0x2929
    //     0x1152480: movk            x17, #1, lsl #16
    //     0x1152484: add             lr, x0, x17
    //     0x1152488: ldr             lr, [x21, lr, lsl #3]
    //     0x115248c: blr             lr
    // 0x1152490: tbnz            w0, #4, #0x11524d8
    // 0x1152494: ldur            x3, [fp, #-8]
    // 0x1152498: LoadField: r1 = r3->field_f
    //     0x1152498: ldur            w1, [x3, #0xf]
    // 0x115249c: DecompressPointer r1
    //     0x115249c: add             x1, x1, HEAP, lsl #32
    // 0x11524a0: LoadField: r0 = r1->field_6f
    //     0x11524a0: ldur            w0, [x1, #0x6f]
    // 0x11524a4: DecompressPointer r0
    //     0x11524a4: add             x0, x0, HEAP, lsl #32
    // 0x11524a8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11524ac: cmp             w0, w16
    // 0x11524b0: b.ne            #0x11524c0
    // 0x11524b4: r2 = _colors
    //     0x11524b4: add             x2, PP, #0xa1, lsl #12  ; [pp+0xa10e8] Field <_TextButtonDefaultsM3@627343580._colors@627343580>: late final (offset: 0x70)
    //     0x11524b8: ldr             x2, [x2, #0xe8]
    // 0x11524bc: r0 = InitLateFinalInstanceField()
    //     0x11524bc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x11524c0: LoadField: r1 = r0->field_b
    //     0x11524c0: ldur            w1, [x0, #0xb]
    // 0x11524c4: DecompressPointer r1
    //     0x11524c4: add             x1, x1, HEAP, lsl #32
    // 0x11524c8: mov             x0, x1
    // 0x11524cc: LeaveFrame
    //     0x11524cc: mov             SP, fp
    //     0x11524d0: ldp             fp, lr, [SP], #0x10
    // 0x11524d4: ret
    //     0x11524d4: ret             
    // 0x11524d8: ldr             x4, [fp, #0x10]
    // 0x11524dc: ldur            x3, [fp, #-8]
    // 0x11524e0: r0 = LoadClassIdInstr(r4)
    //     0x11524e0: ldur            x0, [x4, #-1]
    //     0x11524e4: ubfx            x0, x0, #0xc, #0x14
    // 0x11524e8: mov             x1, x4
    // 0x11524ec: r2 = Instance_WidgetState
    //     0x11524ec: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0x11524f0: ldr             x2, [x2, #0xa50]
    // 0x11524f4: r0 = GDT[cid_x0 + 0x12929]()
    //     0x11524f4: mov             x17, #0x2929
    //     0x11524f8: movk            x17, #1, lsl #16
    //     0x11524fc: add             lr, x0, x17
    //     0x1152500: ldr             lr, [x21, lr, lsl #3]
    //     0x1152504: blr             lr
    // 0x1152508: tbnz            w0, #4, #0x1152550
    // 0x115250c: ldur            x3, [fp, #-8]
    // 0x1152510: LoadField: r1 = r3->field_f
    //     0x1152510: ldur            w1, [x3, #0xf]
    // 0x1152514: DecompressPointer r1
    //     0x1152514: add             x1, x1, HEAP, lsl #32
    // 0x1152518: LoadField: r0 = r1->field_6f
    //     0x1152518: ldur            w0, [x1, #0x6f]
    // 0x115251c: DecompressPointer r0
    //     0x115251c: add             x0, x0, HEAP, lsl #32
    // 0x1152520: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1152524: cmp             w0, w16
    // 0x1152528: b.ne            #0x1152538
    // 0x115252c: r2 = _colors
    //     0x115252c: add             x2, PP, #0xa1, lsl #12  ; [pp+0xa10e8] Field <_TextButtonDefaultsM3@627343580._colors@627343580>: late final (offset: 0x70)
    //     0x1152530: ldr             x2, [x2, #0xe8]
    // 0x1152534: r0 = InitLateFinalInstanceField()
    //     0x1152534: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1152538: LoadField: r1 = r0->field_b
    //     0x1152538: ldur            w1, [x0, #0xb]
    // 0x115253c: DecompressPointer r1
    //     0x115253c: add             x1, x1, HEAP, lsl #32
    // 0x1152540: mov             x0, x1
    // 0x1152544: LeaveFrame
    //     0x1152544: mov             SP, fp
    //     0x1152548: ldp             fp, lr, [SP], #0x10
    // 0x115254c: ret
    //     0x115254c: ret             
    // 0x1152550: ldr             x1, [fp, #0x10]
    // 0x1152554: ldur            x3, [fp, #-8]
    // 0x1152558: r0 = LoadClassIdInstr(r1)
    //     0x1152558: ldur            x0, [x1, #-1]
    //     0x115255c: ubfx            x0, x0, #0xc, #0x14
    // 0x1152560: r2 = Instance_WidgetState
    //     0x1152560: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0x1152564: ldr             x2, [x2, #0xa60]
    // 0x1152568: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1152568: mov             x17, #0x2929
    //     0x115256c: movk            x17, #1, lsl #16
    //     0x1152570: add             lr, x0, x17
    //     0x1152574: ldr             lr, [x21, lr, lsl #3]
    //     0x1152578: blr             lr
    // 0x115257c: tbnz            w0, #4, #0x11525c4
    // 0x1152580: ldur            x0, [fp, #-8]
    // 0x1152584: LoadField: r1 = r0->field_f
    //     0x1152584: ldur            w1, [x0, #0xf]
    // 0x1152588: DecompressPointer r1
    //     0x1152588: add             x1, x1, HEAP, lsl #32
    // 0x115258c: LoadField: r0 = r1->field_6f
    //     0x115258c: ldur            w0, [x1, #0x6f]
    // 0x1152590: DecompressPointer r0
    //     0x1152590: add             x0, x0, HEAP, lsl #32
    // 0x1152594: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1152598: cmp             w0, w16
    // 0x115259c: b.ne            #0x11525ac
    // 0x11525a0: r2 = _colors
    //     0x11525a0: add             x2, PP, #0xa1, lsl #12  ; [pp+0xa10e8] Field <_TextButtonDefaultsM3@627343580._colors@627343580>: late final (offset: 0x70)
    //     0x11525a4: ldr             x2, [x2, #0xe8]
    // 0x11525a8: r0 = InitLateFinalInstanceField()
    //     0x11525a8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x11525ac: LoadField: r1 = r0->field_b
    //     0x11525ac: ldur            w1, [x0, #0xb]
    // 0x11525b0: DecompressPointer r1
    //     0x11525b0: add             x1, x1, HEAP, lsl #32
    // 0x11525b4: mov             x0, x1
    // 0x11525b8: LeaveFrame
    //     0x11525b8: mov             SP, fp
    //     0x11525bc: ldp             fp, lr, [SP], #0x10
    // 0x11525c0: ret
    //     0x11525c0: ret             
    // 0x11525c4: ldur            x0, [fp, #-8]
    // 0x11525c8: LoadField: r1 = r0->field_f
    //     0x11525c8: ldur            w1, [x0, #0xf]
    // 0x11525cc: DecompressPointer r1
    //     0x11525cc: add             x1, x1, HEAP, lsl #32
    // 0x11525d0: LoadField: r0 = r1->field_6f
    //     0x11525d0: ldur            w0, [x1, #0x6f]
    // 0x11525d4: DecompressPointer r0
    //     0x11525d4: add             x0, x0, HEAP, lsl #32
    // 0x11525d8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11525dc: cmp             w0, w16
    // 0x11525e0: b.ne            #0x11525f0
    // 0x11525e4: r2 = _colors
    //     0x11525e4: add             x2, PP, #0xa1, lsl #12  ; [pp+0xa10e8] Field <_TextButtonDefaultsM3@627343580._colors@627343580>: late final (offset: 0x70)
    //     0x11525e8: ldr             x2, [x2, #0xe8]
    // 0x11525ec: r0 = InitLateFinalInstanceField()
    //     0x11525ec: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x11525f0: LoadField: r1 = r0->field_b
    //     0x11525f0: ldur            w1, [x0, #0xb]
    // 0x11525f4: DecompressPointer r1
    //     0x11525f4: add             x1, x1, HEAP, lsl #32
    // 0x11525f8: mov             x0, x1
    // 0x11525fc: LeaveFrame
    //     0x11525fc: mov             SP, fp
    //     0x1152600: ldp             fp, lr, [SP], #0x10
    // 0x1152604: ret
    //     0x1152604: ret             
    // 0x1152608: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1152608: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x115260c: b               #0x11523d4
  }
  get _ maximumSize(/* No info */) {
    // ** addr: 0x1159e1c, size: 0xc
    // 0x1159e1c: r0 = Instance_WidgetStatePropertyAll
    //     0x1159e1c: add             x0, PP, #0xa0, lsl #12  ; [pp+0xa0e00] Obj!WidgetStatePropertyAll<Size>@128a0c1
    //     0x1159e20: ldr             x0, [x0, #0xe00]
    // 0x1159e24: ret
    //     0x1159e24: ret             
  }
  get _ minimumSize(/* No info */) {
    // ** addr: 0x115a888, size: 0xc
    // 0x115a888: r0 = Instance_WidgetStatePropertyAll
    //     0x115a888: add             x0, PP, #0xa0, lsl #12  ; [pp+0xa0e18] Obj!WidgetStatePropertyAll<Size>@128a0e1
    //     0x115a88c: ldr             x0, [x0, #0xe18]
    // 0x115a890: ret
    //     0x115a890: ret             
  }
  get _ overlayColor(/* No info */) {
    // ** addr: 0x12434d4, size: 0x68
    // 0x12434d4: EnterFrame
    //     0x12434d4: stp             fp, lr, [SP, #-0x10]!
    //     0x12434d8: mov             fp, SP
    // 0x12434dc: AllocStack(0x18)
    //     0x12434dc: sub             SP, SP, #0x18
    // 0x12434e0: SetupParameters(_TextButtonDefaultsM3 this /* r1 => r1, fp-0x8 */)
    //     0x12434e0: stur            x1, [fp, #-8]
    // 0x12434e4: CheckStackOverflow
    //     0x12434e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12434e8: cmp             SP, x16
    //     0x12434ec: b.ls            #0x1243534
    // 0x12434f0: r1 = 1
    //     0x12434f0: mov             x1, #1
    // 0x12434f4: r0 = AllocateContext()
    //     0x12434f4: bl              #0x13de838  ; AllocateContextStub
    // 0x12434f8: mov             x1, x0
    // 0x12434fc: ldur            x0, [fp, #-8]
    // 0x1243500: StoreField: r1->field_f = r0
    //     0x1243500: stur            w0, [x1, #0xf]
    // 0x1243504: mov             x2, x1
    // 0x1243508: r1 = Function '<anonymous closure>':.
    //     0x1243508: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa10f0] AnonymousClosure: (0x124353c), in [package:flutter/src/material/text_button.dart] _TextButtonDefaultsM3::overlayColor (0x12434d4)
    //     0x124350c: ldr             x1, [x1, #0xf0]
    // 0x1243510: r0 = AllocateClosure()
    //     0x1243510: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1243514: r16 = <Color?>
    //     0x1243514: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x1243518: ldr             x16, [x16, #0xa40]
    // 0x124351c: stp             x0, x16, [SP]
    // 0x1243520: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x1243520: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x1243524: r0 = resolveWith()
    //     0x1243524: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x1243528: LeaveFrame
    //     0x1243528: mov             SP, fp
    //     0x124352c: ldp             fp, lr, [SP], #0x10
    // 0x1243530: ret
    //     0x1243530: ret             
    // 0x1243534: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1243534: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1243538: b               #0x12434f0
  }
  [closure] Color? <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0x124353c, size: 0x1b8
    // 0x124353c: EnterFrame
    //     0x124353c: stp             fp, lr, [SP, #-0x10]!
    //     0x1243540: mov             fp, SP
    // 0x1243544: AllocStack(0x8)
    //     0x1243544: sub             SP, SP, #8
    // 0x1243548: SetupParameters([dynamic _ /* r0 */])
    //     0x1243548: ldr             x0, [fp, #0x18]
    //     0x124354c: ldur            w3, [x0, #0x17]
    //     0x1243550: add             x3, x3, HEAP, lsl #32
    //     0x1243554: stur            x3, [fp, #-8]
    // 0x1243558: CheckStackOverflow
    //     0x1243558: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x124355c: cmp             SP, x16
    //     0x1243560: b.ls            #0x12436ec
    // 0x1243564: ldr             x4, [fp, #0x10]
    // 0x1243568: r0 = LoadClassIdInstr(r4)
    //     0x1243568: ldur            x0, [x4, #-1]
    //     0x124356c: ubfx            x0, x0, #0xc, #0x14
    // 0x1243570: mov             x1, x4
    // 0x1243574: r2 = Instance_WidgetState
    //     0x1243574: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0x1243578: ldr             x2, [x2, #0xa48]
    // 0x124357c: r0 = GDT[cid_x0 + 0x12929]()
    //     0x124357c: mov             x17, #0x2929
    //     0x1243580: movk            x17, #1, lsl #16
    //     0x1243584: add             lr, x0, x17
    //     0x1243588: ldr             lr, [x21, lr, lsl #3]
    //     0x124358c: blr             lr
    // 0x1243590: tbnz            w0, #4, #0x12435e0
    // 0x1243594: ldur            x3, [fp, #-8]
    // 0x1243598: LoadField: r1 = r3->field_f
    //     0x1243598: ldur            w1, [x3, #0xf]
    // 0x124359c: DecompressPointer r1
    //     0x124359c: add             x1, x1, HEAP, lsl #32
    // 0x12435a0: LoadField: r0 = r1->field_6f
    //     0x12435a0: ldur            w0, [x1, #0x6f]
    // 0x12435a4: DecompressPointer r0
    //     0x12435a4: add             x0, x0, HEAP, lsl #32
    // 0x12435a8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12435ac: cmp             w0, w16
    // 0x12435b0: b.ne            #0x12435c0
    // 0x12435b4: r2 = _colors
    //     0x12435b4: add             x2, PP, #0xa1, lsl #12  ; [pp+0xa10e8] Field <_TextButtonDefaultsM3@627343580._colors@627343580>: late final (offset: 0x70)
    //     0x12435b8: ldr             x2, [x2, #0xe8]
    // 0x12435bc: r0 = InitLateFinalInstanceField()
    //     0x12435bc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12435c0: LoadField: r1 = r0->field_b
    //     0x12435c0: ldur            w1, [x0, #0xb]
    // 0x12435c4: DecompressPointer r1
    //     0x12435c4: add             x1, x1, HEAP, lsl #32
    // 0x12435c8: d0 = 0.100000
    //     0x12435c8: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0x12435cc: ldr             d0, [x17, #0x1e0]
    // 0x12435d0: r0 = withOpacity()
    //     0x12435d0: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x12435d4: LeaveFrame
    //     0x12435d4: mov             SP, fp
    //     0x12435d8: ldp             fp, lr, [SP], #0x10
    // 0x12435dc: ret
    //     0x12435dc: ret             
    // 0x12435e0: ldr             x4, [fp, #0x10]
    // 0x12435e4: ldur            x3, [fp, #-8]
    // 0x12435e8: r0 = LoadClassIdInstr(r4)
    //     0x12435e8: ldur            x0, [x4, #-1]
    //     0x12435ec: ubfx            x0, x0, #0xc, #0x14
    // 0x12435f0: mov             x1, x4
    // 0x12435f4: r2 = Instance_WidgetState
    //     0x12435f4: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0x12435f8: ldr             x2, [x2, #0xa50]
    // 0x12435fc: r0 = GDT[cid_x0 + 0x12929]()
    //     0x12435fc: mov             x17, #0x2929
    //     0x1243600: movk            x17, #1, lsl #16
    //     0x1243604: add             lr, x0, x17
    //     0x1243608: ldr             lr, [x21, lr, lsl #3]
    //     0x124360c: blr             lr
    // 0x1243610: tbnz            w0, #4, #0x1243660
    // 0x1243614: ldur            x3, [fp, #-8]
    // 0x1243618: LoadField: r1 = r3->field_f
    //     0x1243618: ldur            w1, [x3, #0xf]
    // 0x124361c: DecompressPointer r1
    //     0x124361c: add             x1, x1, HEAP, lsl #32
    // 0x1243620: LoadField: r0 = r1->field_6f
    //     0x1243620: ldur            w0, [x1, #0x6f]
    // 0x1243624: DecompressPointer r0
    //     0x1243624: add             x0, x0, HEAP, lsl #32
    // 0x1243628: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x124362c: cmp             w0, w16
    // 0x1243630: b.ne            #0x1243640
    // 0x1243634: r2 = _colors
    //     0x1243634: add             x2, PP, #0xa1, lsl #12  ; [pp+0xa10e8] Field <_TextButtonDefaultsM3@627343580._colors@627343580>: late final (offset: 0x70)
    //     0x1243638: ldr             x2, [x2, #0xe8]
    // 0x124363c: r0 = InitLateFinalInstanceField()
    //     0x124363c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x1243640: LoadField: r1 = r0->field_b
    //     0x1243640: ldur            w1, [x0, #0xb]
    // 0x1243644: DecompressPointer r1
    //     0x1243644: add             x1, x1, HEAP, lsl #32
    // 0x1243648: d0 = 0.080000
    //     0x1243648: add             x17, PP, #0x15, lsl #12  ; [pp+0x15a58] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x124364c: ldr             d0, [x17, #0xa58]
    // 0x1243650: r0 = withOpacity()
    //     0x1243650: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x1243654: LeaveFrame
    //     0x1243654: mov             SP, fp
    //     0x1243658: ldp             fp, lr, [SP], #0x10
    // 0x124365c: ret
    //     0x124365c: ret             
    // 0x1243660: ldr             x1, [fp, #0x10]
    // 0x1243664: ldur            x3, [fp, #-8]
    // 0x1243668: r0 = LoadClassIdInstr(r1)
    //     0x1243668: ldur            x0, [x1, #-1]
    //     0x124366c: ubfx            x0, x0, #0xc, #0x14
    // 0x1243670: r2 = Instance_WidgetState
    //     0x1243670: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0x1243674: ldr             x2, [x2, #0xa60]
    // 0x1243678: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1243678: mov             x17, #0x2929
    //     0x124367c: movk            x17, #1, lsl #16
    //     0x1243680: add             lr, x0, x17
    //     0x1243684: ldr             lr, [x21, lr, lsl #3]
    //     0x1243688: blr             lr
    // 0x124368c: tbnz            w0, #4, #0x12436dc
    // 0x1243690: ldur            x0, [fp, #-8]
    // 0x1243694: LoadField: r1 = r0->field_f
    //     0x1243694: ldur            w1, [x0, #0xf]
    // 0x1243698: DecompressPointer r1
    //     0x1243698: add             x1, x1, HEAP, lsl #32
    // 0x124369c: LoadField: r0 = r1->field_6f
    //     0x124369c: ldur            w0, [x1, #0x6f]
    // 0x12436a0: DecompressPointer r0
    //     0x12436a0: add             x0, x0, HEAP, lsl #32
    // 0x12436a4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x12436a8: cmp             w0, w16
    // 0x12436ac: b.ne            #0x12436bc
    // 0x12436b0: r2 = _colors
    //     0x12436b0: add             x2, PP, #0xa1, lsl #12  ; [pp+0xa10e8] Field <_TextButtonDefaultsM3@627343580._colors@627343580>: late final (offset: 0x70)
    //     0x12436b4: ldr             x2, [x2, #0xe8]
    // 0x12436b8: r0 = InitLateFinalInstanceField()
    //     0x12436b8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x12436bc: LoadField: r1 = r0->field_b
    //     0x12436bc: ldur            w1, [x0, #0xb]
    // 0x12436c0: DecompressPointer r1
    //     0x12436c0: add             x1, x1, HEAP, lsl #32
    // 0x12436c4: d0 = 0.100000
    //     0x12436c4: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0x12436c8: ldr             d0, [x17, #0x1e0]
    // 0x12436cc: r0 = withOpacity()
    //     0x12436cc: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0x12436d0: LeaveFrame
    //     0x12436d0: mov             SP, fp
    //     0x12436d4: ldp             fp, lr, [SP], #0x10
    // 0x12436d8: ret
    //     0x12436d8: ret             
    // 0x12436dc: r0 = Null
    //     0x12436dc: mov             x0, NULL
    // 0x12436e0: LeaveFrame
    //     0x12436e0: mov             SP, fp
    //     0x12436e4: ldp             fp, lr, [SP], #0x10
    // 0x12436e8: ret
    //     0x12436e8: ret             
    // 0x12436ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12436ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12436f0: b               #0x1243564
  }
  get _ shadowColor(/* No info */) {
    // ** addr: 0x12438bc, size: 0xc
    // 0x12438bc: r0 = Instance_WidgetStatePropertyAll
    //     0x12438bc: add             x0, PP, #0x26, lsl #12  ; [pp+0x26148] Obj!WidgetStatePropertyAll<Color>@128a071
    //     0x12438c0: ldr             x0, [x0, #0x148]
    // 0x12438c4: ret
    //     0x12438c4: ret             
  }
  get _ shape(/* No info */) {
    // ** addr: 0x12438c8, size: 0xc
    // 0x12438c8: r0 = Instance_WidgetStatePropertyAll
    //     0x12438c8: add             x0, PP, #0x99, lsl #12  ; [pp+0x99d88] Obj!WidgetStatePropertyAll<OutlinedBorder>@128a041
    //     0x12438cc: ldr             x0, [x0, #0xd88]
    // 0x12438d0: ret
    //     0x12438d0: ret             
  }
  get _ mouseCursor(/* No info */) {
    // ** addr: 0x1243d58, size: 0xc
    // 0x1243d58: r0 = Instance__WidgetStateMouseCursor
    //     0x1243d58: add             x0, PP, #0x80, lsl #12  ; [pp+0x80c18] Obj!_WidgetStateMouseCursor@12b3251
    //     0x1243d5c: ldr             x0, [x0, #0xc18]
    // 0x1243d60: ret
    //     0x1243d60: ret             
  }
  get _ visualDensity(/* No info */) {
    // ** addr: 0x1245f44, size: 0x44
    // 0x1245f44: EnterFrame
    //     0x1245f44: stp             fp, lr, [SP, #-0x10]!
    //     0x1245f48: mov             fp, SP
    // 0x1245f4c: CheckStackOverflow
    //     0x1245f4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1245f50: cmp             SP, x16
    //     0x1245f54: b.ls            #0x1245f80
    // 0x1245f58: LoadField: r0 = r1->field_6b
    //     0x1245f58: ldur            w0, [x1, #0x6b]
    // 0x1245f5c: DecompressPointer r0
    //     0x1245f5c: add             x0, x0, HEAP, lsl #32
    // 0x1245f60: mov             x1, x0
    // 0x1245f64: r0 = of()
    //     0x1245f64: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x1245f68: LoadField: r1 = r0->field_33
    //     0x1245f68: ldur            w1, [x0, #0x33]
    // 0x1245f6c: DecompressPointer r1
    //     0x1245f6c: add             x1, x1, HEAP, lsl #32
    // 0x1245f70: mov             x0, x1
    // 0x1245f74: LeaveFrame
    //     0x1245f74: mov             SP, fp
    //     0x1245f78: ldp             fp, lr, [SP], #0x10
    // 0x1245f7c: ret
    //     0x1245f7c: ret             
    // 0x1245f80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1245f80: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1245f84: b               #0x1245f58
  }
  get _ tapTargetSize(/* No info */) {
    // ** addr: 0x1245f88, size: 0x44
    // 0x1245f88: EnterFrame
    //     0x1245f88: stp             fp, lr, [SP, #-0x10]!
    //     0x1245f8c: mov             fp, SP
    // 0x1245f90: CheckStackOverflow
    //     0x1245f90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1245f94: cmp             SP, x16
    //     0x1245f98: b.ls            #0x1245fc4
    // 0x1245f9c: LoadField: r0 = r1->field_6b
    //     0x1245f9c: ldur            w0, [x1, #0x6b]
    // 0x1245fa0: DecompressPointer r0
    //     0x1245fa0: add             x0, x0, HEAP, lsl #32
    // 0x1245fa4: mov             x1, x0
    // 0x1245fa8: r0 = of()
    //     0x1245fa8: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x1245fac: LoadField: r1 = r0->field_1b
    //     0x1245fac: ldur            w1, [x0, #0x1b]
    // 0x1245fb0: DecompressPointer r1
    //     0x1245fb0: add             x1, x1, HEAP, lsl #32
    // 0x1245fb4: mov             x0, x1
    // 0x1245fb8: LeaveFrame
    //     0x1245fb8: mov             SP, fp
    //     0x1245fbc: ldp             fp, lr, [SP], #0x10
    // 0x1245fc0: ret
    //     0x1245fc0: ret             
    // 0x1245fc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1245fc4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1245fc8: b               #0x1245f9c
  }
  get _ splashFactory(/* No info */) {
    // ** addr: 0x12485f8, size: 0x44
    // 0x12485f8: EnterFrame
    //     0x12485f8: stp             fp, lr, [SP, #-0x10]!
    //     0x12485fc: mov             fp, SP
    // 0x1248600: CheckStackOverflow
    //     0x1248600: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1248604: cmp             SP, x16
    //     0x1248608: b.ls            #0x1248634
    // 0x124860c: LoadField: r0 = r1->field_6b
    //     0x124860c: ldur            w0, [x1, #0x6b]
    // 0x1248610: DecompressPointer r0
    //     0x1248610: add             x0, x0, HEAP, lsl #32
    // 0x1248614: mov             x1, x0
    // 0x1248618: r0 = of()
    //     0x1248618: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x124861c: LoadField: r1 = r0->field_2b
    //     0x124861c: ldur            w1, [x0, #0x2b]
    // 0x1248620: DecompressPointer r1
    //     0x1248620: add             x1, x1, HEAP, lsl #32
    // 0x1248624: mov             x0, x1
    // 0x1248628: LeaveFrame
    //     0x1248628: mov             SP, fp
    //     0x124862c: ldp             fp, lr, [SP], #0x10
    // 0x1248630: ret
    //     0x1248630: ret             
    // 0x1248634: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1248634: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1248638: b               #0x124860c
  }
  get _ elevation(/* No info */) {
    // ** addr: 0x1249294, size: 0xc
    // 0x1249294: r0 = Instance_WidgetStatePropertyAll
    //     0x1249294: add             x0, PP, #0xa0, lsl #12  ; [pp+0xa0e20] Obj!WidgetStatePropertyAll<double>@128a101
    //     0x1249298: ldr             x0, [x0, #0xe20]
    // 0x124929c: ret
    //     0x124929c: ret             
  }
  get _ foregroundColor(/* No info */) {
    // ** addr: 0x124a074, size: 0x68
    // 0x124a074: EnterFrame
    //     0x124a074: stp             fp, lr, [SP, #-0x10]!
    //     0x124a078: mov             fp, SP
    // 0x124a07c: AllocStack(0x18)
    //     0x124a07c: sub             SP, SP, #0x18
    // 0x124a080: SetupParameters(_TextButtonDefaultsM3 this /* r1 => r1, fp-0x8 */)
    //     0x124a080: stur            x1, [fp, #-8]
    // 0x124a084: CheckStackOverflow
    //     0x124a084: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x124a088: cmp             SP, x16
    //     0x124a08c: b.ls            #0x124a0d4
    // 0x124a090: r1 = 1
    //     0x124a090: mov             x1, #1
    // 0x124a094: r0 = AllocateContext()
    //     0x124a094: bl              #0x13de838  ; AllocateContextStub
    // 0x124a098: mov             x1, x0
    // 0x124a09c: ldur            x0, [fp, #-8]
    // 0x124a0a0: StoreField: r1->field_f = r0
    //     0x124a0a0: stur            w0, [x1, #0xf]
    // 0x124a0a4: mov             x2, x1
    // 0x124a0a8: r1 = Function '<anonymous closure>':.
    //     0x124a0a8: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa10f8] AnonymousClosure: (0x124a0dc), in [package:flutter/src/material/text_button.dart] _TextButtonDefaultsM3::foregroundColor (0x124a074)
    //     0x124a0ac: ldr             x1, [x1, #0xf8]
    // 0x124a0b0: r0 = AllocateClosure()
    //     0x124a0b0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x124a0b4: r16 = <Color?>
    //     0x124a0b4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0x124a0b8: ldr             x16, [x16, #0xa40]
    // 0x124a0bc: stp             x0, x16, [SP]
    // 0x124a0c0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x124a0c0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x124a0c4: r0 = resolveWith()
    //     0x124a0c4: bl              #0xd0df40  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveWith
    // 0x124a0c8: LeaveFrame
    //     0x124a0c8: mov             SP, fp
    //     0x124a0cc: ldp             fp, lr, [SP], #0x10
    // 0x124a0d0: ret
    //     0x124a0d0: ret             
    // 0x124a0d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x124a0d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x124a0d8: b               #0x124a090
  }
  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0x124a0dc, size: 0xfc
    // 0x124a0dc: EnterFrame
    //     0x124a0dc: stp             fp, lr, [SP, #-0x10]!
    //     0x124a0e0: mov             fp, SP
    // 0x124a0e4: AllocStack(0x8)
    //     0x124a0e4: sub             SP, SP, #8
    // 0x124a0e8: SetupParameters([dynamic _ /* r0 */])
    //     0x124a0e8: ldr             x0, [fp, #0x18]
    //     0x124a0ec: ldur            w3, [x0, #0x17]
    //     0x124a0f0: add             x3, x3, HEAP, lsl #32
    //     0x124a0f4: stur            x3, [fp, #-8]
    // 0x124a0f8: CheckStackOverflow
    //     0x124a0f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x124a0fc: cmp             SP, x16
    //     0x124a100: b.ls            #0x124a1d0
    // 0x124a104: ldr             x1, [fp, #0x10]
    // 0x124a108: r0 = LoadClassIdInstr(r1)
    //     0x124a108: ldur            x0, [x1, #-1]
    //     0x124a10c: ubfx            x0, x0, #0xc, #0x14
    // 0x124a110: r2 = Instance_WidgetState
    //     0x124a110: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0x124a114: ldr             x2, [x2, #0xa70]
    // 0x124a118: r0 = GDT[cid_x0 + 0x12929]()
    //     0x124a118: mov             x17, #0x2929
    //     0x124a11c: movk            x17, #1, lsl #16
    //     0x124a120: add             lr, x0, x17
    //     0x124a124: ldr             lr, [x21, lr, lsl #3]
    //     0x124a128: blr             lr
    // 0x124a12c: tbnz            w0, #4, #0x124a18c
    // 0x124a130: ldur            x0, [fp, #-8]
    // 0x124a134: LoadField: r1 = r0->field_f
    //     0x124a134: ldur            w1, [x0, #0xf]
    // 0x124a138: DecompressPointer r1
    //     0x124a138: add             x1, x1, HEAP, lsl #32
    // 0x124a13c: LoadField: r0 = r1->field_6f
    //     0x124a13c: ldur            w0, [x1, #0x6f]
    // 0x124a140: DecompressPointer r0
    //     0x124a140: add             x0, x0, HEAP, lsl #32
    // 0x124a144: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x124a148: cmp             w0, w16
    // 0x124a14c: b.ne            #0x124a15c
    // 0x124a150: r2 = _colors
    //     0x124a150: add             x2, PP, #0xa1, lsl #12  ; [pp+0xa10e8] Field <_TextButtonDefaultsM3@627343580._colors@627343580>: late final (offset: 0x70)
    //     0x124a154: ldr             x2, [x2, #0xe8]
    // 0x124a158: r0 = InitLateFinalInstanceField()
    //     0x124a158: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x124a15c: LoadField: r1 = r0->field_7f
    //     0x124a15c: ldur            w1, [x0, #0x7f]
    // 0x124a160: DecompressPointer r1
    //     0x124a160: add             x1, x1, HEAP, lsl #32
    // 0x124a164: r0 = LoadClassIdInstr(r1)
    //     0x124a164: ldur            x0, [x1, #-1]
    //     0x124a168: ubfx            x0, x0, #0xc, #0x14
    // 0x124a16c: d0 = 0.380000
    //     0x124a16c: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0x124a170: ldr             d0, [x17, #0x1f0]
    // 0x124a174: r0 = GDT[cid_x0 + -0x1000]()
    //     0x124a174: sub             lr, x0, #1, lsl #12
    //     0x124a178: ldr             lr, [x21, lr, lsl #3]
    //     0x124a17c: blr             lr
    // 0x124a180: LeaveFrame
    //     0x124a180: mov             SP, fp
    //     0x124a184: ldp             fp, lr, [SP], #0x10
    // 0x124a188: ret
    //     0x124a188: ret             
    // 0x124a18c: ldur            x0, [fp, #-8]
    // 0x124a190: LoadField: r1 = r0->field_f
    //     0x124a190: ldur            w1, [x0, #0xf]
    // 0x124a194: DecompressPointer r1
    //     0x124a194: add             x1, x1, HEAP, lsl #32
    // 0x124a198: LoadField: r0 = r1->field_6f
    //     0x124a198: ldur            w0, [x1, #0x6f]
    // 0x124a19c: DecompressPointer r0
    //     0x124a19c: add             x0, x0, HEAP, lsl #32
    // 0x124a1a0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x124a1a4: cmp             w0, w16
    // 0x124a1a8: b.ne            #0x124a1b8
    // 0x124a1ac: r2 = _colors
    //     0x124a1ac: add             x2, PP, #0xa1, lsl #12  ; [pp+0xa10e8] Field <_TextButtonDefaultsM3@627343580._colors@627343580>: late final (offset: 0x70)
    //     0x124a1b0: ldr             x2, [x2, #0xe8]
    // 0x124a1b4: r0 = InitLateFinalInstanceField()
    //     0x124a1b4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x124a1b8: LoadField: r1 = r0->field_b
    //     0x124a1b8: ldur            w1, [x0, #0xb]
    // 0x124a1bc: DecompressPointer r1
    //     0x124a1bc: add             x1, x1, HEAP, lsl #32
    // 0x124a1c0: mov             x0, x1
    // 0x124a1c4: LeaveFrame
    //     0x124a1c4: mov             SP, fp
    //     0x124a1c8: ldp             fp, lr, [SP], #0x10
    // 0x124a1cc: ret
    //     0x124a1cc: ret             
    // 0x124a1d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x124a1d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x124a1d4: b               #0x124a104
  }
  get _ textStyle(/* No info */) {
    // ** addr: 0x124ac04, size: 0x64
    // 0x124ac04: EnterFrame
    //     0x124ac04: stp             fp, lr, [SP, #-0x10]!
    //     0x124ac08: mov             fp, SP
    // 0x124ac0c: AllocStack(0x8)
    //     0x124ac0c: sub             SP, SP, #8
    // 0x124ac10: CheckStackOverflow
    //     0x124ac10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x124ac14: cmp             SP, x16
    //     0x124ac18: b.ls            #0x124ac60
    // 0x124ac1c: LoadField: r0 = r1->field_6b
    //     0x124ac1c: ldur            w0, [x1, #0x6b]
    // 0x124ac20: DecompressPointer r0
    //     0x124ac20: add             x0, x0, HEAP, lsl #32
    // 0x124ac24: mov             x1, x0
    // 0x124ac28: r0 = of()
    //     0x124ac28: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x124ac2c: LoadField: r1 = r0->field_87
    //     0x124ac2c: ldur            w1, [x0, #0x87]
    // 0x124ac30: DecompressPointer r1
    //     0x124ac30: add             x1, x1, HEAP, lsl #32
    // 0x124ac34: LoadField: r0 = r1->field_37
    //     0x124ac34: ldur            w0, [x1, #0x37]
    // 0x124ac38: DecompressPointer r0
    //     0x124ac38: add             x0, x0, HEAP, lsl #32
    // 0x124ac3c: stur            x0, [fp, #-8]
    // 0x124ac40: r1 = <TextStyle?>
    //     0x124ac40: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a88] TypeArguments: <TextStyle?>
    //     0x124ac44: ldr             x1, [x1, #0xa88]
    // 0x124ac48: r0 = WidgetStatePropertyAll()
    //     0x124ac48: bl              #0xd132c8  ; AllocateWidgetStatePropertyAllStub -> WidgetStatePropertyAll<X0> (size=0x10)
    // 0x124ac4c: ldur            x1, [fp, #-8]
    // 0x124ac50: StoreField: r0->field_b = r1
    //     0x124ac50: stur            w1, [x0, #0xb]
    // 0x124ac54: LeaveFrame
    //     0x124ac54: mov             SP, fp
    //     0x124ac58: ldp             fp, lr, [SP], #0x10
    // 0x124ac5c: ret
    //     0x124ac5c: ret             
    // 0x124ac60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x124ac60: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x124ac64: b               #0x124ac1c
  }
}

// class id: 6140, size: 0x1c, field offset: 0xc
//   const constructor, 
class _TextButtonWithIconChild extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xfbe5ec, size: 0x280
    // 0xfbe5ec: EnterFrame
    //     0xfbe5ec: stp             fp, lr, [SP, #-0x10]!
    //     0xfbe5f0: mov             fp, SP
    // 0xfbe5f4: AllocStack(0x28)
    //     0xfbe5f4: sub             SP, SP, #0x28
    // 0xfbe5f8: SetupParameters(_TextButtonWithIconChild this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xfbe5f8: mov             x4, x1
    //     0xfbe5fc: mov             x3, x2
    //     0xfbe600: stur            x1, [fp, #-8]
    //     0xfbe604: stur            x2, [fp, #-0x10]
    // 0xfbe608: CheckStackOverflow
    //     0xfbe608: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbe60c: cmp             SP, x16
    //     0xfbe610: b.ls            #0xfbe850
    // 0xfbe614: LoadField: r0 = r4->field_13
    //     0xfbe614: ldur            w0, [x4, #0x13]
    // 0xfbe618: DecompressPointer r0
    //     0xfbe618: add             x0, x0, HEAP, lsl #32
    // 0xfbe61c: LoadField: r1 = r0->field_7
    //     0xfbe61c: ldur            w1, [x0, #7]
    // 0xfbe620: DecompressPointer r1
    //     0xfbe620: add             x1, x1, HEAP, lsl #32
    // 0xfbe624: cmp             w1, NULL
    // 0xfbe628: b.ne            #0xfbe634
    // 0xfbe62c: r0 = Null
    //     0xfbe62c: mov             x0, NULL
    // 0xfbe630: b               #0xfbe674
    // 0xfbe634: r0 = LoadClassIdInstr(r1)
    //     0xfbe634: ldur            x0, [x1, #-1]
    //     0xfbe638: ubfx            x0, x0, #0xc, #0x14
    // 0xfbe63c: r2 = _ConstSet len:0
    //     0xfbe63c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26248] Set<WidgetState>(0)
    //     0xfbe640: ldr             x2, [x2, #0x248]
    // 0xfbe644: r0 = GDT[cid_x0 + 0x17c77]()
    //     0xfbe644: mov             x17, #0x7c77
    //     0xfbe648: movk            x17, #1, lsl #16
    //     0xfbe64c: add             lr, x0, x17
    //     0xfbe650: ldr             lr, [x21, lr, lsl #3]
    //     0xfbe654: blr             lr
    // 0xfbe658: cmp             w0, NULL
    // 0xfbe65c: b.ne            #0xfbe668
    // 0xfbe660: r0 = Null
    //     0xfbe660: mov             x0, NULL
    // 0xfbe664: b               #0xfbe674
    // 0xfbe668: LoadField: r1 = r0->field_1f
    //     0xfbe668: ldur            w1, [x0, #0x1f]
    // 0xfbe66c: DecompressPointer r1
    //     0xfbe66c: add             x1, x1, HEAP, lsl #32
    // 0xfbe670: mov             x0, x1
    // 0xfbe674: cmp             w0, NULL
    // 0xfbe678: b.ne            #0xfbe684
    // 0xfbe67c: d0 = 14.000000
    //     0xfbe67c: fmov            d0, #14.00000000
    // 0xfbe680: b               #0xfbe688
    // 0xfbe684: LoadField: d0 = r0->field_7
    //     0xfbe684: ldur            d0, [x0, #7]
    // 0xfbe688: ldur            x1, [fp, #-0x10]
    // 0xfbe68c: stur            d0, [fp, #-0x28]
    // 0xfbe690: r0 = textScalerOf()
    //     0xfbe690: bl              #0xd16168  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::textScalerOf
    // 0xfbe694: r1 = LoadClassIdInstr(r0)
    //     0xfbe694: ldur            x1, [x0, #-1]
    //     0xfbe698: ubfx            x1, x1, #0xc, #0x14
    // 0xfbe69c: mov             x16, x0
    // 0xfbe6a0: mov             x0, x1
    // 0xfbe6a4: mov             x1, x16
    // 0xfbe6a8: ldur            d0, [fp, #-0x28]
    // 0xfbe6ac: r0 = GDT[cid_x0 + -0x1000]()
    //     0xfbe6ac: sub             lr, x0, #1, lsl #12
    //     0xfbe6b0: ldr             lr, [x21, lr, lsl #3]
    //     0xfbe6b4: blr             lr
    // 0xfbe6b8: LoadField: d0 = r0->field_7
    //     0xfbe6b8: ldur            d0, [x0, #7]
    // 0xfbe6bc: d1 = 14.000000
    //     0xfbe6bc: fmov            d1, #14.00000000
    // 0xfbe6c0: fdiv            d2, d0, d1
    // 0xfbe6c4: d0 = 1.000000
    //     0xfbe6c4: fmov            d0, #1.00000000
    // 0xfbe6c8: fcmp            d0, d2
    // 0xfbe6cc: b.le            #0xfbe6d8
    // 0xfbe6d0: d1 = 1.000000
    //     0xfbe6d0: fmov            d1, #1.00000000
    // 0xfbe6d4: b               #0xfbe700
    // 0xfbe6d8: d1 = 2.000000
    //     0xfbe6d8: fmov            d1, #2.00000000
    // 0xfbe6dc: fcmp            d2, d1
    // 0xfbe6e0: b.le            #0xfbe6ec
    // 0xfbe6e4: d1 = 2.000000
    //     0xfbe6e4: fmov            d1, #2.00000000
    // 0xfbe6e8: b               #0xfbe700
    // 0xfbe6ec: fcmp            d2, d2
    // 0xfbe6f0: b.vc            #0xfbe6fc
    // 0xfbe6f4: d1 = 2.000000
    //     0xfbe6f4: fmov            d1, #2.00000000
    // 0xfbe6f8: b               #0xfbe700
    // 0xfbe6fc: mov             v1.16b, v2.16b
    // 0xfbe700: ldur            x0, [fp, #-8]
    // 0xfbe704: fsub            d2, d1, d0
    // 0xfbe708: ldur            x1, [fp, #-0x10]
    // 0xfbe70c: stur            d2, [fp, #-0x28]
    // 0xfbe710: r0 = of()
    //     0xfbe710: bl              #0xfbe86c  ; [package:flutter/src/material/text_button_theme.dart] TextButtonTheme::of
    // 0xfbe714: ldur            d0, [fp, #-0x28]
    // 0xfbe718: r3 = inline_Allocate_Double()
    //     0xfbe718: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0xfbe71c: add             x3, x3, #0x10
    //     0xfbe720: cmp             x0, x3
    //     0xfbe724: b.ls            #0xfbe858
    //     0xfbe728: str             x3, [THR, #0x60]  ; THR::top
    //     0xfbe72c: sub             x3, x3, #0xf
    //     0xfbe730: mov             x0, #0xe19c
    //     0xfbe734: movk            x0, #3, lsl #16
    //     0xfbe738: stur            x0, [x3, #-1]
    // 0xfbe73c: dmb             ishst
    // 0xfbe740: StoreField: r3->field_7 = d0
    //     0xfbe740: stur            d0, [x3, #7]
    // 0xfbe744: r1 = 16
    //     0xfbe744: mov             x1, #0x10
    // 0xfbe748: r2 = 8
    //     0xfbe748: mov             x2, #8
    // 0xfbe74c: r0 = lerpDouble()
    //     0xfbe74c: bl              #0x868a5c  ; [dart:ui] ::lerpDouble
    // 0xfbe750: mov             x2, x0
    // 0xfbe754: ldur            x0, [fp, #-8]
    // 0xfbe758: stur            x2, [fp, #-0x20]
    // 0xfbe75c: LoadField: r3 = r0->field_f
    //     0xfbe75c: ldur            w3, [x0, #0xf]
    // 0xfbe760: DecompressPointer r3
    //     0xfbe760: add             x3, x3, HEAP, lsl #32
    // 0xfbe764: stur            x3, [fp, #-0x18]
    // 0xfbe768: LoadField: r4 = r0->field_b
    //     0xfbe768: ldur            w4, [x0, #0xb]
    // 0xfbe76c: DecompressPointer r4
    //     0xfbe76c: add             x4, x4, HEAP, lsl #32
    // 0xfbe770: stur            x4, [fp, #-0x10]
    // 0xfbe774: r1 = <FlexParentData>
    //     0xfbe774: add             x1, PP, #0x15, lsl #12  ; [pp+0x15878] TypeArguments: <FlexParentData>
    //     0xfbe778: ldr             x1, [x1, #0x878]
    // 0xfbe77c: r0 = Flexible()
    //     0xfbe77c: bl              #0xd0fd68  ; AllocateFlexibleStub -> Flexible (size=0x20)
    // 0xfbe780: mov             x3, x0
    // 0xfbe784: r0 = 1
    //     0xfbe784: mov             x0, #1
    // 0xfbe788: stur            x3, [fp, #-8]
    // 0xfbe78c: StoreField: r3->field_13 = r0
    //     0xfbe78c: stur            x0, [x3, #0x13]
    // 0xfbe790: r0 = Instance_FlexFit
    //     0xfbe790: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1ac30] Obj!FlexFit@12c4661
    //     0xfbe794: ldr             x0, [x0, #0xc30]
    // 0xfbe798: StoreField: r3->field_1b = r0
    //     0xfbe798: stur            w0, [x3, #0x1b]
    // 0xfbe79c: ldur            x0, [fp, #-0x10]
    // 0xfbe7a0: StoreField: r3->field_b = r0
    //     0xfbe7a0: stur            w0, [x3, #0xb]
    // 0xfbe7a4: r1 = Null
    //     0xfbe7a4: mov             x1, NULL
    // 0xfbe7a8: r2 = 4
    //     0xfbe7a8: mov             x2, #4
    // 0xfbe7ac: r0 = AllocateArray()
    //     0xfbe7ac: bl              #0x13df928  ; AllocateArrayStub
    // 0xfbe7b0: mov             x2, x0
    // 0xfbe7b4: ldur            x0, [fp, #-0x18]
    // 0xfbe7b8: stur            x2, [fp, #-0x10]
    // 0xfbe7bc: StoreField: r2->field_f = r0
    //     0xfbe7bc: stur            w0, [x2, #0xf]
    // 0xfbe7c0: ldur            x0, [fp, #-8]
    // 0xfbe7c4: StoreField: r2->field_13 = r0
    //     0xfbe7c4: stur            w0, [x2, #0x13]
    // 0xfbe7c8: r1 = <Widget>
    //     0xfbe7c8: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xfbe7cc: r0 = AllocateGrowableArray()
    //     0xfbe7cc: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xfbe7d0: mov             x1, x0
    // 0xfbe7d4: ldur            x0, [fp, #-0x10]
    // 0xfbe7d8: stur            x1, [fp, #-8]
    // 0xfbe7dc: StoreField: r1->field_f = r0
    //     0xfbe7dc: stur            w0, [x1, #0xf]
    // 0xfbe7e0: r0 = 4
    //     0xfbe7e0: mov             x0, #4
    // 0xfbe7e4: StoreField: r1->field_b = r0
    //     0xfbe7e4: stur            w0, [x1, #0xb]
    // 0xfbe7e8: r0 = Row()
    //     0xfbe7e8: bl              #0x8a5b04  ; AllocateRowStub -> Row (size=0x38)
    // 0xfbe7ec: r1 = Instance_Axis
    //     0xfbe7ec: ldr             x1, [PP, #0x49c8]  ; [pp+0x49c8] Obj!Axis@12c4a61
    // 0xfbe7f0: StoreField: r0->field_f = r1
    //     0xfbe7f0: stur            w1, [x0, #0xf]
    // 0xfbe7f4: r1 = Instance_MainAxisAlignment
    //     0xfbe7f4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15820] Obj!MainAxisAlignment@12c4541
    //     0xfbe7f8: ldr             x1, [x1, #0x820]
    // 0xfbe7fc: StoreField: r0->field_13 = r1
    //     0xfbe7fc: stur            w1, [x0, #0x13]
    // 0xfbe800: r1 = Instance_MainAxisSize
    //     0xfbe800: add             x1, PP, #0x17, lsl #12  ; [pp+0x17200] Obj!MainAxisSize@12c4601
    //     0xfbe804: ldr             x1, [x1, #0x200]
    // 0xfbe808: ArrayStore: r0[0] = r1  ; List_4
    //     0xfbe808: stur            w1, [x0, #0x17]
    // 0xfbe80c: r1 = Instance_CrossAxisAlignment
    //     0xfbe80c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15888] Obj!CrossAxisAlignment@12c44a1
    //     0xfbe810: ldr             x1, [x1, #0x888]
    // 0xfbe814: StoreField: r0->field_1b = r1
    //     0xfbe814: stur            w1, [x0, #0x1b]
    // 0xfbe818: r1 = Instance_VerticalDirection
    //     0xfbe818: add             x1, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0xfbe81c: ldr             x1, [x1, #0x838]
    // 0xfbe820: StoreField: r0->field_23 = r1
    //     0xfbe820: stur            w1, [x0, #0x23]
    // 0xfbe824: r1 = Instance_Clip
    //     0xfbe824: add             x1, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xfbe828: ldr             x1, [x1, #0x840]
    // 0xfbe82c: StoreField: r0->field_2b = r1
    //     0xfbe82c: stur            w1, [x0, #0x2b]
    // 0xfbe830: ldur            x1, [fp, #-0x20]
    // 0xfbe834: LoadField: d0 = r1->field_7
    //     0xfbe834: ldur            d0, [x1, #7]
    // 0xfbe838: StoreField: r0->field_2f = d0
    //     0xfbe838: stur            d0, [x0, #0x2f]
    // 0xfbe83c: ldur            x1, [fp, #-8]
    // 0xfbe840: StoreField: r0->field_b = r1
    //     0xfbe840: stur            w1, [x0, #0xb]
    // 0xfbe844: LeaveFrame
    //     0xfbe844: mov             SP, fp
    //     0xfbe848: ldp             fp, lr, [SP], #0x10
    // 0xfbe84c: ret
    //     0xfbe84c: ret             
    // 0xfbe850: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbe850: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbe854: b               #0xfbe614
    // 0xfbe858: SaveReg d0
    //     0xfbe858: str             q0, [SP, #-0x10]!
    // 0xfbe85c: r0 = AllocateDouble()
    //     0xfbe85c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xfbe860: mov             x3, x0
    // 0xfbe864: RestoreReg d0
    //     0xfbe864: ldr             q0, [SP], #0x10
    // 0xfbe868: b               #0xfbe740
  }
}

// class id: 6495, size: 0x40, field offset: 0x3c
//   const constructor, 
class TextButton extends ButtonStyleButton {

  static _ styleFrom(/* No info */) {
    // ** addr: 0xd16538, size: 0xc4c
    // 0xd16538: EnterFrame
    //     0xd16538: stp             fp, lr, [SP, #-0x10]!
    //     0xd1653c: mov             fp, SP
    // 0xd16540: AllocStack(0xb8)
    //     0xd16540: sub             SP, SP, #0xb8
    // 0xd16544: SetupParameters({dynamic alignment = Null /* fp-0x8 */, dynamic animationDuration = Null /* r3, fp-0x98 */, dynamic backgroundColor = Null /* r5, fp-0x90 */, dynamic disabledBackgroundColor = Null /* r6 */, dynamic disabledForegroundColor = Null /* r7, fp-0x88 */, dynamic disabledMouseCursor = Null /* r8, fp-0x80 */, dynamic elevation = Null /* r9, fp-0x78 */, dynamic enableFeedback = Null /* r10, fp-0x70 */, dynamic enabledMouseCursor = Null /* r11, fp-0x68 */, dynamic fixedSize = Null /* r12, fp-0x60 */, dynamic foregroundColor = Null /* r13, fp-0x58 */, dynamic maximumSize = Null /* r14, fp-0x50 */, dynamic minimumSize = Null /* r19, fp-0x48 */, dynamic padding = Null /* r20, fp-0x40 */, dynamic shadowColor = Null /* fp-0x10 */, dynamic shape = Null /* fp-0x18 */, dynamic splashFactory = Null /* fp-0x20 */, dynamic tapTargetSize = Null /* fp-0x28 */, dynamic textStyle = Null /* r2, fp-0x38 */, dynamic visualDensity = Null /* r0, fp-0x30 */})
    //     0xd16544: ldur            w0, [x4, #0x13]
    //     0xd16548: ldur            w1, [x4, #0x1f]
    //     0xd1654c: add             x1, x1, HEAP, lsl #32
    //     0xd16550: ldr             x16, [PP, #0x5c70]  ; [pp+0x5c70] "alignment"
    //     0xd16554: cmp             w1, w16
    //     0xd16558: b.ne            #0xd1657c
    //     0xd1655c: ldur            w1, [x4, #0x23]
    //     0xd16560: add             x1, x1, HEAP, lsl #32
    //     0xd16564: sub             w2, w0, w1
    //     0xd16568: add             x1, fp, w2, sxtw #2
    //     0xd1656c: ldr             x1, [x1, #8]
    //     0xd16570: mov             x2, x1
    //     0xd16574: mov             x1, #1
    //     0xd16578: b               #0xd16584
    //     0xd1657c: mov             x2, NULL
    //     0xd16580: mov             x1, #0
    //     0xd16584: stur            x2, [fp, #-8]
    //     0xd16588: lsl             x3, x1, #1
    //     0xd1658c: lsl             w5, w3, #1
    //     0xd16590: add             w6, w5, #8
    //     0xd16594: add             x16, x4, w6, sxtw #1
    //     0xd16598: ldur            w7, [x16, #0xf]
    //     0xd1659c: add             x7, x7, HEAP, lsl #32
    //     0xd165a0: add             x16, PP, #0x15, lsl #12  ; [pp+0x159d0] "animationDuration"
    //     0xd165a4: ldr             x16, [x16, #0x9d0]
    //     0xd165a8: cmp             w7, w16
    //     0xd165ac: b.ne            #0xd165e0
    //     0xd165b0: add             w1, w5, #0xa
    //     0xd165b4: add             x16, x4, w1, sxtw #1
    //     0xd165b8: ldur            w5, [x16, #0xf]
    //     0xd165bc: add             x5, x5, HEAP, lsl #32
    //     0xd165c0: sub             w1, w0, w5
    //     0xd165c4: add             x5, fp, w1, sxtw #2
    //     0xd165c8: ldr             x5, [x5, #8]
    //     0xd165cc: add             w1, w3, #2
    //     0xd165d0: sbfx            x3, x1, #1, #0x1f
    //     0xd165d4: mov             x1, x3
    //     0xd165d8: mov             x3, x5
    //     0xd165dc: b               #0xd165e4
    //     0xd165e0: mov             x3, NULL
    //     0xd165e4: stur            x3, [fp, #-0x98]
    //     0xd165e8: lsl             x5, x1, #1
    //     0xd165ec: lsl             w6, w5, #1
    //     0xd165f0: add             w7, w6, #8
    //     0xd165f4: add             x16, x4, w7, sxtw #1
    //     0xd165f8: ldur            w8, [x16, #0xf]
    //     0xd165fc: add             x8, x8, HEAP, lsl #32
    //     0xd16600: add             x16, PP, #0x12, lsl #12  ; [pp+0x12958] "backgroundColor"
    //     0xd16604: ldr             x16, [x16, #0x958]
    //     0xd16608: cmp             w8, w16
    //     0xd1660c: b.ne            #0xd16640
    //     0xd16610: add             w1, w6, #0xa
    //     0xd16614: add             x16, x4, w1, sxtw #1
    //     0xd16618: ldur            w6, [x16, #0xf]
    //     0xd1661c: add             x6, x6, HEAP, lsl #32
    //     0xd16620: sub             w1, w0, w6
    //     0xd16624: add             x6, fp, w1, sxtw #2
    //     0xd16628: ldr             x6, [x6, #8]
    //     0xd1662c: add             w1, w5, #2
    //     0xd16630: sbfx            x5, x1, #1, #0x1f
    //     0xd16634: mov             x1, x5
    //     0xd16638: mov             x5, x6
    //     0xd1663c: b               #0xd16644
    //     0xd16640: mov             x5, NULL
    //     0xd16644: stur            x5, [fp, #-0x90]
    //     0xd16648: lsl             x6, x1, #1
    //     0xd1664c: lsl             w7, w6, #1
    //     0xd16650: add             w8, w7, #8
    //     0xd16654: add             x16, x4, w8, sxtw #1
    //     0xd16658: ldur            w9, [x16, #0xf]
    //     0xd1665c: add             x9, x9, HEAP, lsl #32
    //     0xd16660: add             x16, PP, #0x15, lsl #12  ; [pp+0x159d8] "disabledBackgroundColor"
    //     0xd16664: ldr             x16, [x16, #0x9d8]
    //     0xd16668: cmp             w9, w16
    //     0xd1666c: b.ne            #0xd166a0
    //     0xd16670: add             w1, w7, #0xa
    //     0xd16674: add             x16, x4, w1, sxtw #1
    //     0xd16678: ldur            w7, [x16, #0xf]
    //     0xd1667c: add             x7, x7, HEAP, lsl #32
    //     0xd16680: sub             w1, w0, w7
    //     0xd16684: add             x7, fp, w1, sxtw #2
    //     0xd16688: ldr             x7, [x7, #8]
    //     0xd1668c: add             w1, w6, #2
    //     0xd16690: sbfx            x6, x1, #1, #0x1f
    //     0xd16694: mov             x1, x6
    //     0xd16698: mov             x6, x7
    //     0xd1669c: b               #0xd166a4
    //     0xd166a0: mov             x6, NULL
    //     0xd166a4: lsl             x7, x1, #1
    //     0xd166a8: lsl             w8, w7, #1
    //     0xd166ac: add             w9, w8, #8
    //     0xd166b0: add             x16, x4, w9, sxtw #1
    //     0xd166b4: ldur            w10, [x16, #0xf]
    //     0xd166b8: add             x10, x10, HEAP, lsl #32
    //     0xd166bc: add             x16, PP, #0x15, lsl #12  ; [pp+0x159e0] "disabledForegroundColor"
    //     0xd166c0: ldr             x16, [x16, #0x9e0]
    //     0xd166c4: cmp             w10, w16
    //     0xd166c8: b.ne            #0xd166fc
    //     0xd166cc: add             w1, w8, #0xa
    //     0xd166d0: add             x16, x4, w1, sxtw #1
    //     0xd166d4: ldur            w8, [x16, #0xf]
    //     0xd166d8: add             x8, x8, HEAP, lsl #32
    //     0xd166dc: sub             w1, w0, w8
    //     0xd166e0: add             x8, fp, w1, sxtw #2
    //     0xd166e4: ldr             x8, [x8, #8]
    //     0xd166e8: add             w1, w7, #2
    //     0xd166ec: sbfx            x7, x1, #1, #0x1f
    //     0xd166f0: mov             x1, x7
    //     0xd166f4: mov             x7, x8
    //     0xd166f8: b               #0xd16700
    //     0xd166fc: mov             x7, NULL
    //     0xd16700: stur            x7, [fp, #-0x88]
    //     0xd16704: lsl             x8, x1, #1
    //     0xd16708: lsl             w9, w8, #1
    //     0xd1670c: add             w10, w9, #8
    //     0xd16710: add             x16, x4, w10, sxtw #1
    //     0xd16714: ldur            w11, [x16, #0xf]
    //     0xd16718: add             x11, x11, HEAP, lsl #32
    //     0xd1671c: add             x16, PP, #0x15, lsl #12  ; [pp+0x159e8] "disabledMouseCursor"
    //     0xd16720: ldr             x16, [x16, #0x9e8]
    //     0xd16724: cmp             w11, w16
    //     0xd16728: b.ne            #0xd1675c
    //     0xd1672c: add             w1, w9, #0xa
    //     0xd16730: add             x16, x4, w1, sxtw #1
    //     0xd16734: ldur            w9, [x16, #0xf]
    //     0xd16738: add             x9, x9, HEAP, lsl #32
    //     0xd1673c: sub             w1, w0, w9
    //     0xd16740: add             x9, fp, w1, sxtw #2
    //     0xd16744: ldr             x9, [x9, #8]
    //     0xd16748: add             w1, w8, #2
    //     0xd1674c: sbfx            x8, x1, #1, #0x1f
    //     0xd16750: mov             x1, x8
    //     0xd16754: mov             x8, x9
    //     0xd16758: b               #0xd16760
    //     0xd1675c: mov             x8, NULL
    //     0xd16760: stur            x8, [fp, #-0x80]
    //     0xd16764: lsl             x9, x1, #1
    //     0xd16768: lsl             w10, w9, #1
    //     0xd1676c: add             w11, w10, #8
    //     0xd16770: add             x16, x4, w11, sxtw #1
    //     0xd16774: ldur            w12, [x16, #0xf]
    //     0xd16778: add             x12, x12, HEAP, lsl #32
    //     0xd1677c: add             x16, PP, #0x15, lsl #12  ; [pp+0x159f0] "elevation"
    //     0xd16780: ldr             x16, [x16, #0x9f0]
    //     0xd16784: cmp             w12, w16
    //     0xd16788: b.ne            #0xd167bc
    //     0xd1678c: add             w1, w10, #0xa
    //     0xd16790: add             x16, x4, w1, sxtw #1
    //     0xd16794: ldur            w10, [x16, #0xf]
    //     0xd16798: add             x10, x10, HEAP, lsl #32
    //     0xd1679c: sub             w1, w0, w10
    //     0xd167a0: add             x10, fp, w1, sxtw #2
    //     0xd167a4: ldr             x10, [x10, #8]
    //     0xd167a8: add             w1, w9, #2
    //     0xd167ac: sbfx            x9, x1, #1, #0x1f
    //     0xd167b0: mov             x1, x9
    //     0xd167b4: mov             x9, x10
    //     0xd167b8: b               #0xd167c0
    //     0xd167bc: mov             x9, NULL
    //     0xd167c0: stur            x9, [fp, #-0x78]
    //     0xd167c4: lsl             x10, x1, #1
    //     0xd167c8: lsl             w11, w10, #1
    //     0xd167cc: add             w12, w11, #8
    //     0xd167d0: add             x16, x4, w12, sxtw #1
    //     0xd167d4: ldur            w13, [x16, #0xf]
    //     0xd167d8: add             x13, x13, HEAP, lsl #32
    //     0xd167dc: add             x16, PP, #0x15, lsl #12  ; [pp+0x159f8] "enableFeedback"
    //     0xd167e0: ldr             x16, [x16, #0x9f8]
    //     0xd167e4: cmp             w13, w16
    //     0xd167e8: b.ne            #0xd1681c
    //     0xd167ec: add             w1, w11, #0xa
    //     0xd167f0: add             x16, x4, w1, sxtw #1
    //     0xd167f4: ldur            w11, [x16, #0xf]
    //     0xd167f8: add             x11, x11, HEAP, lsl #32
    //     0xd167fc: sub             w1, w0, w11
    //     0xd16800: add             x11, fp, w1, sxtw #2
    //     0xd16804: ldr             x11, [x11, #8]
    //     0xd16808: add             w1, w10, #2
    //     0xd1680c: sbfx            x10, x1, #1, #0x1f
    //     0xd16810: mov             x1, x10
    //     0xd16814: mov             x10, x11
    //     0xd16818: b               #0xd16820
    //     0xd1681c: mov             x10, NULL
    //     0xd16820: stur            x10, [fp, #-0x70]
    //     0xd16824: lsl             x11, x1, #1
    //     0xd16828: lsl             w12, w11, #1
    //     0xd1682c: add             w13, w12, #8
    //     0xd16830: add             x16, x4, w13, sxtw #1
    //     0xd16834: ldur            w14, [x16, #0xf]
    //     0xd16838: add             x14, x14, HEAP, lsl #32
    //     0xd1683c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a00] "enabledMouseCursor"
    //     0xd16840: ldr             x16, [x16, #0xa00]
    //     0xd16844: cmp             w14, w16
    //     0xd16848: b.ne            #0xd1687c
    //     0xd1684c: add             w1, w12, #0xa
    //     0xd16850: add             x16, x4, w1, sxtw #1
    //     0xd16854: ldur            w12, [x16, #0xf]
    //     0xd16858: add             x12, x12, HEAP, lsl #32
    //     0xd1685c: sub             w1, w0, w12
    //     0xd16860: add             x12, fp, w1, sxtw #2
    //     0xd16864: ldr             x12, [x12, #8]
    //     0xd16868: add             w1, w11, #2
    //     0xd1686c: sbfx            x11, x1, #1, #0x1f
    //     0xd16870: mov             x1, x11
    //     0xd16874: mov             x11, x12
    //     0xd16878: b               #0xd16880
    //     0xd1687c: mov             x11, NULL
    //     0xd16880: stur            x11, [fp, #-0x68]
    //     0xd16884: lsl             x12, x1, #1
    //     0xd16888: lsl             w13, w12, #1
    //     0xd1688c: add             w14, w13, #8
    //     0xd16890: add             x16, x4, w14, sxtw #1
    //     0xd16894: ldur            w19, [x16, #0xf]
    //     0xd16898: add             x19, x19, HEAP, lsl #32
    //     0xd1689c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a08] "fixedSize"
    //     0xd168a0: ldr             x16, [x16, #0xa08]
    //     0xd168a4: cmp             w19, w16
    //     0xd168a8: b.ne            #0xd168dc
    //     0xd168ac: add             w1, w13, #0xa
    //     0xd168b0: add             x16, x4, w1, sxtw #1
    //     0xd168b4: ldur            w13, [x16, #0xf]
    //     0xd168b8: add             x13, x13, HEAP, lsl #32
    //     0xd168bc: sub             w1, w0, w13
    //     0xd168c0: add             x13, fp, w1, sxtw #2
    //     0xd168c4: ldr             x13, [x13, #8]
    //     0xd168c8: add             w1, w12, #2
    //     0xd168cc: sbfx            x12, x1, #1, #0x1f
    //     0xd168d0: mov             x1, x12
    //     0xd168d4: mov             x12, x13
    //     0xd168d8: b               #0xd168e0
    //     0xd168dc: mov             x12, NULL
    //     0xd168e0: stur            x12, [fp, #-0x60]
    //     0xd168e4: lsl             x13, x1, #1
    //     0xd168e8: lsl             w14, w13, #1
    //     0xd168ec: add             w19, w14, #8
    //     0xd168f0: add             x16, x4, w19, sxtw #1
    //     0xd168f4: ldur            w20, [x16, #0xf]
    //     0xd168f8: add             x20, x20, HEAP, lsl #32
    //     0xd168fc: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a10] "foregroundColor"
    //     0xd16900: ldr             x16, [x16, #0xa10]
    //     0xd16904: cmp             w20, w16
    //     0xd16908: b.ne            #0xd1693c
    //     0xd1690c: add             w1, w14, #0xa
    //     0xd16910: add             x16, x4, w1, sxtw #1
    //     0xd16914: ldur            w14, [x16, #0xf]
    //     0xd16918: add             x14, x14, HEAP, lsl #32
    //     0xd1691c: sub             w1, w0, w14
    //     0xd16920: add             x14, fp, w1, sxtw #2
    //     0xd16924: ldr             x14, [x14, #8]
    //     0xd16928: add             w1, w13, #2
    //     0xd1692c: sbfx            x13, x1, #1, #0x1f
    //     0xd16930: mov             x1, x13
    //     0xd16934: mov             x13, x14
    //     0xd16938: b               #0xd16940
    //     0xd1693c: mov             x13, NULL
    //     0xd16940: stur            x13, [fp, #-0x58]
    //     0xd16944: lsl             x14, x1, #1
    //     0xd16948: lsl             w19, w14, #1
    //     0xd1694c: add             w20, w19, #8
    //     0xd16950: add             x16, x4, w20, sxtw #1
    //     0xd16954: ldur            w23, [x16, #0xf]
    //     0xd16958: add             x23, x23, HEAP, lsl #32
    //     0xd1695c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a18] "maximumSize"
    //     0xd16960: ldr             x16, [x16, #0xa18]
    //     0xd16964: cmp             w23, w16
    //     0xd16968: b.ne            #0xd1699c
    //     0xd1696c: add             w1, w19, #0xa
    //     0xd16970: add             x16, x4, w1, sxtw #1
    //     0xd16974: ldur            w19, [x16, #0xf]
    //     0xd16978: add             x19, x19, HEAP, lsl #32
    //     0xd1697c: sub             w1, w0, w19
    //     0xd16980: add             x19, fp, w1, sxtw #2
    //     0xd16984: ldr             x19, [x19, #8]
    //     0xd16988: add             w1, w14, #2
    //     0xd1698c: sbfx            x14, x1, #1, #0x1f
    //     0xd16990: mov             x1, x14
    //     0xd16994: mov             x14, x19
    //     0xd16998: b               #0xd169a0
    //     0xd1699c: mov             x14, NULL
    //     0xd169a0: stur            x14, [fp, #-0x50]
    //     0xd169a4: lsl             x19, x1, #1
    //     0xd169a8: lsl             w20, w19, #1
    //     0xd169ac: add             w23, w20, #8
    //     0xd169b0: add             x16, x4, w23, sxtw #1
    //     0xd169b4: ldur            w24, [x16, #0xf]
    //     0xd169b8: add             x24, x24, HEAP, lsl #32
    //     0xd169bc: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a20] "minimumSize"
    //     0xd169c0: ldr             x16, [x16, #0xa20]
    //     0xd169c4: cmp             w24, w16
    //     0xd169c8: b.ne            #0xd169fc
    //     0xd169cc: add             w1, w20, #0xa
    //     0xd169d0: add             x16, x4, w1, sxtw #1
    //     0xd169d4: ldur            w20, [x16, #0xf]
    //     0xd169d8: add             x20, x20, HEAP, lsl #32
    //     0xd169dc: sub             w1, w0, w20
    //     0xd169e0: add             x20, fp, w1, sxtw #2
    //     0xd169e4: ldr             x20, [x20, #8]
    //     0xd169e8: add             w1, w19, #2
    //     0xd169ec: sbfx            x19, x1, #1, #0x1f
    //     0xd169f0: mov             x1, x19
    //     0xd169f4: mov             x19, x20
    //     0xd169f8: b               #0xd16a00
    //     0xd169fc: mov             x19, NULL
    //     0xd16a00: stur            x19, [fp, #-0x48]
    //     0xd16a04: lsl             x20, x1, #1
    //     0xd16a08: lsl             w23, w20, #1
    //     0xd16a0c: add             w24, w23, #8
    //     0xd16a10: add             x16, x4, w24, sxtw #1
    //     0xd16a14: ldur            w25, [x16, #0xf]
    //     0xd16a18: add             x25, x25, HEAP, lsl #32
    //     0xd16a1c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12838] "padding"
    //     0xd16a20: ldr             x16, [x16, #0x838]
    //     0xd16a24: cmp             w25, w16
    //     0xd16a28: b.ne            #0xd16a5c
    //     0xd16a2c: add             w1, w23, #0xa
    //     0xd16a30: add             x16, x4, w1, sxtw #1
    //     0xd16a34: ldur            w23, [x16, #0xf]
    //     0xd16a38: add             x23, x23, HEAP, lsl #32
    //     0xd16a3c: sub             w1, w0, w23
    //     0xd16a40: add             x23, fp, w1, sxtw #2
    //     0xd16a44: ldr             x23, [x23, #8]
    //     0xd16a48: add             w1, w20, #2
    //     0xd16a4c: sbfx            x20, x1, #1, #0x1f
    //     0xd16a50: mov             x1, x20
    //     0xd16a54: mov             x20, x23
    //     0xd16a58: b               #0xd16a60
    //     0xd16a5c: mov             x20, NULL
    //     0xd16a60: stur            x20, [fp, #-0x40]
    //     0xd16a64: lsl             x23, x1, #1
    //     0xd16a68: lsl             w24, w23, #1
    //     0xd16a6c: add             w25, w24, #8
    //     0xd16a70: add             x16, x4, w25, sxtw #1
    //     0xd16a74: ldur            w2, [x16, #0xf]
    //     0xd16a78: add             x2, x2, HEAP, lsl #32
    //     0xd16a7c: add             x16, PP, #0x12, lsl #12  ; [pp+0x12b70] "shadowColor"
    //     0xd16a80: ldr             x16, [x16, #0xb70]
    //     0xd16a84: cmp             w2, w16
    //     0xd16a88: b.ne            #0xd16ab8
    //     0xd16a8c: add             w1, w24, #0xa
    //     0xd16a90: add             x16, x4, w1, sxtw #1
    //     0xd16a94: ldur            w2, [x16, #0xf]
    //     0xd16a98: add             x2, x2, HEAP, lsl #32
    //     0xd16a9c: sub             w1, w0, w2
    //     0xd16aa0: add             x2, fp, w1, sxtw #2
    //     0xd16aa4: ldr             x2, [x2, #8]
    //     0xd16aa8: add             w1, w23, #2
    //     0xd16aac: sbfx            x23, x1, #1, #0x1f
    //     0xd16ab0: mov             x1, x23
    //     0xd16ab4: b               #0xd16abc
    //     0xd16ab8: mov             x2, NULL
    //     0xd16abc: stur            x2, [fp, #-0x10]
    //     0xd16ac0: lsl             x23, x1, #1
    //     0xd16ac4: lsl             w24, w23, #1
    //     0xd16ac8: add             w25, w24, #8
    //     0xd16acc: add             x16, x4, w25, sxtw #1
    //     0xd16ad0: ldur            w2, [x16, #0xf]
    //     0xd16ad4: add             x2, x2, HEAP, lsl #32
    //     0xd16ad8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a28] "shape"
    //     0xd16adc: ldr             x16, [x16, #0xa28]
    //     0xd16ae0: cmp             w2, w16
    //     0xd16ae4: b.ne            #0xd16b14
    //     0xd16ae8: add             w1, w24, #0xa
    //     0xd16aec: add             x16, x4, w1, sxtw #1
    //     0xd16af0: ldur            w2, [x16, #0xf]
    //     0xd16af4: add             x2, x2, HEAP, lsl #32
    //     0xd16af8: sub             w1, w0, w2
    //     0xd16afc: add             x2, fp, w1, sxtw #2
    //     0xd16b00: ldr             x2, [x2, #8]
    //     0xd16b04: add             w1, w23, #2
    //     0xd16b08: sbfx            x23, x1, #1, #0x1f
    //     0xd16b0c: mov             x1, x23
    //     0xd16b10: b               #0xd16b18
    //     0xd16b14: mov             x2, NULL
    //     0xd16b18: stur            x2, [fp, #-0x18]
    //     0xd16b1c: lsl             x23, x1, #1
    //     0xd16b20: lsl             w24, w23, #1
    //     0xd16b24: add             w25, w24, #8
    //     0xd16b28: add             x16, x4, w25, sxtw #1
    //     0xd16b2c: ldur            w2, [x16, #0xf]
    //     0xd16b30: add             x2, x2, HEAP, lsl #32
    //     0xd16b34: add             x16, PP, #0x12, lsl #12  ; [pp+0x12b88] "splashFactory"
    //     0xd16b38: ldr             x16, [x16, #0xb88]
    //     0xd16b3c: cmp             w2, w16
    //     0xd16b40: b.ne            #0xd16b70
    //     0xd16b44: add             w1, w24, #0xa
    //     0xd16b48: add             x16, x4, w1, sxtw #1
    //     0xd16b4c: ldur            w2, [x16, #0xf]
    //     0xd16b50: add             x2, x2, HEAP, lsl #32
    //     0xd16b54: sub             w1, w0, w2
    //     0xd16b58: add             x2, fp, w1, sxtw #2
    //     0xd16b5c: ldr             x2, [x2, #8]
    //     0xd16b60: add             w1, w23, #2
    //     0xd16b64: sbfx            x23, x1, #1, #0x1f
    //     0xd16b68: mov             x1, x23
    //     0xd16b6c: b               #0xd16b74
    //     0xd16b70: mov             x2, NULL
    //     0xd16b74: stur            x2, [fp, #-0x20]
    //     0xd16b78: lsl             x23, x1, #1
    //     0xd16b7c: lsl             w24, w23, #1
    //     0xd16b80: add             w25, w24, #8
    //     0xd16b84: add             x16, x4, w25, sxtw #1
    //     0xd16b88: ldur            w2, [x16, #0xf]
    //     0xd16b8c: add             x2, x2, HEAP, lsl #32
    //     0xd16b90: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a30] "tapTargetSize"
    //     0xd16b94: ldr             x16, [x16, #0xa30]
    //     0xd16b98: cmp             w2, w16
    //     0xd16b9c: b.ne            #0xd16bcc
    //     0xd16ba0: add             w1, w24, #0xa
    //     0xd16ba4: add             x16, x4, w1, sxtw #1
    //     0xd16ba8: ldur            w2, [x16, #0xf]
    //     0xd16bac: add             x2, x2, HEAP, lsl #32
    //     0xd16bb0: sub             w1, w0, w2
    //     0xd16bb4: add             x2, fp, w1, sxtw #2
    //     0xd16bb8: ldr             x2, [x2, #8]
    //     0xd16bbc: add             w1, w23, #2
    //     0xd16bc0: sbfx            x23, x1, #1, #0x1f
    //     0xd16bc4: mov             x1, x23
    //     0xd16bc8: b               #0xd16bd0
    //     0xd16bcc: mov             x2, NULL
    //     0xd16bd0: stur            x2, [fp, #-0x28]
    //     0xd16bd4: lsl             x23, x1, #1
    //     0xd16bd8: lsl             w24, w23, #1
    //     0xd16bdc: add             w25, w24, #8
    //     0xd16be0: add             x16, x4, w25, sxtw #1
    //     0xd16be4: ldur            w2, [x16, #0xf]
    //     0xd16be8: add             x2, x2, HEAP, lsl #32
    //     0xd16bec: add             x16, PP, #0x13, lsl #12  ; [pp+0x13e08] "textStyle"
    //     0xd16bf0: ldr             x16, [x16, #0xe08]
    //     0xd16bf4: cmp             w2, w16
    //     0xd16bf8: b.ne            #0xd16c28
    //     0xd16bfc: add             w1, w24, #0xa
    //     0xd16c00: add             x16, x4, w1, sxtw #1
    //     0xd16c04: ldur            w2, [x16, #0xf]
    //     0xd16c08: add             x2, x2, HEAP, lsl #32
    //     0xd16c0c: sub             w1, w0, w2
    //     0xd16c10: add             x2, fp, w1, sxtw #2
    //     0xd16c14: ldr             x2, [x2, #8]
    //     0xd16c18: add             w1, w23, #2
    //     0xd16c1c: sbfx            x23, x1, #1, #0x1f
    //     0xd16c20: mov             x1, x23
    //     0xd16c24: b               #0xd16c2c
    //     0xd16c28: mov             x2, NULL
    //     0xd16c2c: stur            x2, [fp, #-0x38]
    //     0xd16c30: lsl             x23, x1, #1
    //     0xd16c34: lsl             w1, w23, #1
    //     0xd16c38: add             w23, w1, #8
    //     0xd16c3c: add             x16, x4, w23, sxtw #1
    //     0xd16c40: ldur            w24, [x16, #0xf]
    //     0xd16c44: add             x24, x24, HEAP, lsl #32
    //     0xd16c48: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a38] "visualDensity"
    //     0xd16c4c: ldr             x16, [x16, #0xa38]
    //     0xd16c50: cmp             w24, w16
    //     0xd16c54: b.ne            #0xd16c78
    //     0xd16c58: add             w23, w1, #0xa
    //     0xd16c5c: add             x16, x4, w23, sxtw #1
    //     0xd16c60: ldur            w1, [x16, #0xf]
    //     0xd16c64: add             x1, x1, HEAP, lsl #32
    //     0xd16c68: sub             w4, w0, w1
    //     0xd16c6c: add             x0, fp, w4, sxtw #2
    //     0xd16c70: ldr             x0, [x0, #8]
    //     0xd16c74: b               #0xd16c7c
    //     0xd16c78: mov             x0, NULL
    //     0xd16c7c: stur            x0, [fp, #-0x30]
    // 0xd16c80: CheckStackOverflow
    //     0xd16c80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd16c84: cmp             SP, x16
    //     0xd16c88: b.ls            #0xd1717c
    // 0xd16c8c: cmp             w5, NULL
    // 0xd16c90: b.eq            #0xd16cc0
    // 0xd16c94: cmp             w6, NULL
    // 0xd16c98: b.ne            #0xd16cb8
    // 0xd16c9c: r1 = <Color?>
    //     0xd16c9c: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xd16ca0: ldr             x1, [x1, #0xa40]
    // 0xd16ca4: r0 = WidgetStatePropertyAll()
    //     0xd16ca4: bl              #0xd132c8  ; AllocateWidgetStatePropertyAllStub -> WidgetStatePropertyAll<X0> (size=0x10)
    // 0xd16ca8: ldur            x1, [fp, #-0x90]
    // 0xd16cac: StoreField: r0->field_b = r1
    //     0xd16cac: stur            w1, [x0, #0xb]
    // 0xd16cb0: mov             x4, x0
    // 0xd16cb4: b               #0xd16cd0
    // 0xd16cb8: mov             x1, x5
    // 0xd16cbc: b               #0xd16cc4
    // 0xd16cc0: mov             x1, x5
    // 0xd16cc4: mov             x2, x6
    // 0xd16cc8: r0 = defaultColor()
    //     0xd16cc8: bl              #0xd171ec  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::defaultColor
    // 0xd16ccc: mov             x4, x0
    // 0xd16cd0: ldur            x3, [fp, #-0x58]
    // 0xd16cd4: stur            x4, [fp, #-0x90]
    // 0xd16cd8: cmp             w3, NULL
    // 0xd16cdc: b.ne            #0xd16cec
    // 0xd16ce0: mov             x0, x4
    // 0xd16ce4: r9 = Null
    //     0xd16ce4: mov             x9, NULL
    // 0xd16ce8: b               #0xd16f68
    // 0xd16cec: r0 = Null
    //     0xd16cec: mov             x0, NULL
    // 0xd16cf0: r2 = Null
    //     0xd16cf0: mov             x2, NULL
    // 0xd16cf4: r1 = Null
    //     0xd16cf4: mov             x1, NULL
    // 0xd16cf8: cmp             w0, NULL
    // 0xd16cfc: b.eq            #0xd16d20
    // 0xd16d00: branchIfSmi(r0, 0xd16d20)
    //     0xd16d00: tbz             w0, #0, #0xd16d20
    // 0xd16d04: r3 = LoadClassIdInstr(r0)
    //     0xd16d04: ldur            x3, [x0, #-1]
    //     0xd16d08: ubfx            x3, x3, #0xc, #0x14
    // 0xd16d0c: sub             x3, x3, #0xecc
    // 0xd16d10: cmp             x3, #5
    // 0xd16d14: b.ls            #0xd16d28
    // 0xd16d18: cmp             x3, #0x5ad
    // 0xd16d1c: b.eq            #0xd16d28
    // 0xd16d20: r0 = false
    //     0xd16d20: add             x0, NULL, #0x30  ; false
    // 0xd16d24: b               #0xd16d2c
    // 0xd16d28: r0 = true
    //     0xd16d28: add             x0, NULL, #0x20  ; true
    // 0xd16d2c: tbnz            w0, #4, #0xd16d6c
    // 0xd16d30: r0 = 171
    //     0xd16d30: mov             x0, #0xab
    // 0xd16d34: r1 = Null
    //     0xd16d34: mov             x1, NULL
    // 0xd16d38: r0 = GDT[cid_x0 + -0xfe4]()
    //     0xd16d38: sub             lr, x0, #0xfe4
    //     0xd16d3c: ldr             lr, [x21, lr, lsl #3]
    //     0xd16d40: blr             lr
    // 0xd16d44: mov             v1.16b, v0.16b
    // 0xd16d48: d0 = 0.000000
    //     0xd16d48: eor             v0.16b, v0.16b, v0.16b
    // 0xd16d4c: fcmp            d1, d0
    // 0xd16d50: b.ne            #0xd16d6c
    // 0xd16d54: r1 = <Color?>
    //     0xd16d54: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xd16d58: ldr             x1, [x1, #0xa40]
    // 0xd16d5c: r0 = WidgetStatePropertyAll()
    //     0xd16d5c: bl              #0xd132c8  ; AllocateWidgetStatePropertyAllStub -> WidgetStatePropertyAll<X0> (size=0x10)
    // 0xd16d60: mov             x9, x0
    // 0xd16d64: ldur            x0, [fp, #-0x90]
    // 0xd16d68: b               #0xd16f68
    // 0xd16d6c: r0 = Null
    //     0xd16d6c: mov             x0, NULL
    // 0xd16d70: r2 = Null
    //     0xd16d70: mov             x2, NULL
    // 0xd16d74: r1 = Null
    //     0xd16d74: mov             x1, NULL
    // 0xd16d78: cmp             w0, NULL
    // 0xd16d7c: b.eq            #0xd16da0
    // 0xd16d80: branchIfSmi(r0, 0xd16da0)
    //     0xd16d80: tbz             w0, #0, #0xd16da0
    // 0xd16d84: r3 = LoadClassIdInstr(r0)
    //     0xd16d84: ldur            x3, [x0, #-1]
    //     0xd16d88: ubfx            x3, x3, #0xc, #0x14
    // 0xd16d8c: sub             x3, x3, #0xecc
    // 0xd16d90: cmp             x3, #5
    // 0xd16d94: b.ls            #0xd16da8
    // 0xd16d98: cmp             x3, #0x5ad
    // 0xd16d9c: b.eq            #0xd16da8
    // 0xd16da0: r0 = false
    //     0xd16da0: add             x0, NULL, #0x30  ; false
    // 0xd16da4: b               #0xd16dac
    // 0xd16da8: r0 = true
    //     0xd16da8: add             x0, NULL, #0x20  ; true
    // 0xd16dac: tbnz            w0, #4, #0xd16db8
    // 0xd16db0: r0 = Null
    //     0xd16db0: mov             x0, NULL
    // 0xd16db4: b               #0xd16e00
    // 0xd16db8: ldur            x0, [fp, #-0x58]
    // 0xd16dbc: r2 = Null
    //     0xd16dbc: mov             x2, NULL
    // 0xd16dc0: r1 = Null
    //     0xd16dc0: mov             x1, NULL
    // 0xd16dc4: cmp             w0, NULL
    // 0xd16dc8: b.eq            #0xd16dec
    // 0xd16dcc: branchIfSmi(r0, 0xd16dec)
    //     0xd16dcc: tbz             w0, #0, #0xd16dec
    // 0xd16dd0: r3 = LoadClassIdInstr(r0)
    //     0xd16dd0: ldur            x3, [x0, #-1]
    //     0xd16dd4: ubfx            x3, x3, #0xc, #0x14
    // 0xd16dd8: sub             x3, x3, #0xecc
    // 0xd16ddc: cmp             x3, #5
    // 0xd16de0: b.ls            #0xd16df4
    // 0xd16de4: cmp             x3, #0x5ad
    // 0xd16de8: b.eq            #0xd16df4
    // 0xd16dec: r0 = false
    //     0xd16dec: add             x0, NULL, #0x30  ; false
    // 0xd16df0: b               #0xd16df8
    // 0xd16df4: r0 = true
    //     0xd16df4: add             x0, NULL, #0x20  ; true
    // 0xd16df8: tbnz            w0, #4, #0xd16f60
    // 0xd16dfc: ldur            x0, [fp, #-0x58]
    // 0xd16e00: stur            x0, [fp, #-0xa0]
    // 0xd16e04: r1 = Null
    //     0xd16e04: mov             x1, NULL
    // 0xd16e08: r2 = 12
    //     0xd16e08: mov             x2, #0xc
    // 0xd16e0c: r0 = AllocateArray()
    //     0xd16e0c: bl              #0x13df928  ; AllocateArrayStub
    // 0xd16e10: mov             x2, x0
    // 0xd16e14: stur            x2, [fp, #-0xa8]
    // 0xd16e18: r16 = Instance_WidgetState
    //     0xd16e18: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0xd16e1c: ldr             x16, [x16, #0xa48]
    // 0xd16e20: StoreField: r2->field_f = r16
    //     0xd16e20: stur            w16, [x2, #0xf]
    // 0xd16e24: ldur            x3, [fp, #-0xa0]
    // 0xd16e28: r0 = LoadClassIdInstr(r3)
    //     0xd16e28: ldur            x0, [x3, #-1]
    //     0xd16e2c: ubfx            x0, x0, #0xc, #0x14
    // 0xd16e30: mov             x1, x3
    // 0xd16e34: d0 = 0.100000
    //     0xd16e34: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0xd16e38: ldr             d0, [x17, #0x1e0]
    // 0xd16e3c: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd16e3c: sub             lr, x0, #1, lsl #12
    //     0xd16e40: ldr             lr, [x21, lr, lsl #3]
    //     0xd16e44: blr             lr
    // 0xd16e48: ldur            x1, [fp, #-0xa8]
    // 0xd16e4c: ArrayStore: r1[1] = r0  ; List_4
    //     0xd16e4c: add             x25, x1, #0x13
    //     0xd16e50: str             w0, [x25]
    //     0xd16e54: tbz             w0, #0, #0xd16e70
    //     0xd16e58: ldurb           w16, [x1, #-1]
    //     0xd16e5c: ldurb           w17, [x0, #-1]
    //     0xd16e60: and             x16, x17, x16, lsr #2
    //     0xd16e64: tst             x16, HEAP, lsr #32
    //     0xd16e68: b.eq            #0xd16e70
    //     0xd16e6c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd16e70: ldur            x2, [fp, #-0xa8]
    // 0xd16e74: r16 = Instance_WidgetState
    //     0xd16e74: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xd16e78: ldr             x16, [x16, #0xa50]
    // 0xd16e7c: ArrayStore: r2[0] = r16  ; List_4
    //     0xd16e7c: stur            w16, [x2, #0x17]
    // 0xd16e80: ldur            x3, [fp, #-0xa0]
    // 0xd16e84: r0 = LoadClassIdInstr(r3)
    //     0xd16e84: ldur            x0, [x3, #-1]
    //     0xd16e88: ubfx            x0, x0, #0xc, #0x14
    // 0xd16e8c: mov             x1, x3
    // 0xd16e90: d0 = 0.080000
    //     0xd16e90: add             x17, PP, #0x15, lsl #12  ; [pp+0x15a58] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0xd16e94: ldr             d0, [x17, #0xa58]
    // 0xd16e98: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd16e98: sub             lr, x0, #1, lsl #12
    //     0xd16e9c: ldr             lr, [x21, lr, lsl #3]
    //     0xd16ea0: blr             lr
    // 0xd16ea4: ldur            x1, [fp, #-0xa8]
    // 0xd16ea8: ArrayStore: r1[3] = r0  ; List_4
    //     0xd16ea8: add             x25, x1, #0x1b
    //     0xd16eac: str             w0, [x25]
    //     0xd16eb0: tbz             w0, #0, #0xd16ecc
    //     0xd16eb4: ldurb           w16, [x1, #-1]
    //     0xd16eb8: ldurb           w17, [x0, #-1]
    //     0xd16ebc: and             x16, x17, x16, lsr #2
    //     0xd16ec0: tst             x16, HEAP, lsr #32
    //     0xd16ec4: b.eq            #0xd16ecc
    //     0xd16ec8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd16ecc: ldur            x2, [fp, #-0xa8]
    // 0xd16ed0: r16 = Instance_WidgetState
    //     0xd16ed0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xd16ed4: ldr             x16, [x16, #0xa60]
    // 0xd16ed8: StoreField: r2->field_1f = r16
    //     0xd16ed8: stur            w16, [x2, #0x1f]
    // 0xd16edc: ldur            x1, [fp, #-0xa0]
    // 0xd16ee0: r0 = LoadClassIdInstr(r1)
    //     0xd16ee0: ldur            x0, [x1, #-1]
    //     0xd16ee4: ubfx            x0, x0, #0xc, #0x14
    // 0xd16ee8: d0 = 0.100000
    //     0xd16ee8: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0xd16eec: ldr             d0, [x17, #0x1e0]
    // 0xd16ef0: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd16ef0: sub             lr, x0, #1, lsl #12
    //     0xd16ef4: ldr             lr, [x21, lr, lsl #3]
    //     0xd16ef8: blr             lr
    // 0xd16efc: ldur            x1, [fp, #-0xa8]
    // 0xd16f00: ArrayStore: r1[5] = r0  ; List_4
    //     0xd16f00: add             x25, x1, #0x23
    //     0xd16f04: str             w0, [x25]
    //     0xd16f08: tbz             w0, #0, #0xd16f24
    //     0xd16f0c: ldurb           w16, [x1, #-1]
    //     0xd16f10: ldurb           w17, [x0, #-1]
    //     0xd16f14: and             x16, x17, x16, lsr #2
    //     0xd16f18: tst             x16, HEAP, lsr #32
    //     0xd16f1c: b.eq            #0xd16f24
    //     0xd16f20: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd16f24: r16 = <WidgetState, Color?>
    //     0xd16f24: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a68] TypeArguments: <WidgetState, Color?>
    //     0xd16f28: ldr             x16, [x16, #0xa68]
    // 0xd16f2c: ldur            lr, [fp, #-0xa8]
    // 0xd16f30: stp             lr, x16, [SP]
    // 0xd16f34: r0 = Map._fromLiteral()
    //     0xd16f34: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xd16f38: r1 = <Color?>
    //     0xd16f38: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xd16f3c: ldr             x1, [x1, #0xa40]
    // 0xd16f40: stur            x0, [fp, #-0xa0]
    // 0xd16f44: r0 = WidgetStateMapper()
    //     0xd16f44: bl              #0xd171e0  ; AllocateWidgetStateMapperStub -> WidgetStateMapper<X0> (size=0x10)
    // 0xd16f48: mov             x1, x0
    // 0xd16f4c: ldur            x0, [fp, #-0xa0]
    // 0xd16f50: StoreField: r1->field_b = r0
    //     0xd16f50: stur            w0, [x1, #0xb]
    // 0xd16f54: mov             x9, x1
    // 0xd16f58: ldur            x0, [fp, #-0x90]
    // 0xd16f5c: b               #0xd16f68
    // 0xd16f60: ldur            x0, [fp, #-0x90]
    // 0xd16f64: r9 = Null
    //     0xd16f64: mov             x9, NULL
    // 0xd16f68: ldur            x1, [fp, #-8]
    // 0xd16f6c: ldur            x2, [fp, #-0x98]
    // 0xd16f70: ldur            x3, [fp, #-0x80]
    // 0xd16f74: ldur            x4, [fp, #-0x70]
    // 0xd16f78: ldur            x5, [fp, #-0x68]
    // 0xd16f7c: ldur            x6, [fp, #-0x20]
    // 0xd16f80: ldur            x7, [fp, #-0x28]
    // 0xd16f84: ldur            x8, [fp, #-0x30]
    // 0xd16f88: stur            x9, [fp, #-0xa0]
    // 0xd16f8c: r16 = <TextStyle>
    //     0xd16f8c: add             x16, PP, #0x18, lsl #12  ; [pp+0x18370] TypeArguments: <TextStyle>
    //     0xd16f90: ldr             x16, [x16, #0x370]
    // 0xd16f94: ldur            lr, [fp, #-0x38]
    // 0xd16f98: stp             lr, x16, [SP]
    // 0xd16f9c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd16f9c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd16fa0: r0 = allOrNull()
    //     0xd16fa0: bl              #0xd17190  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0xd16fa4: ldur            x1, [fp, #-0x58]
    // 0xd16fa8: ldur            x2, [fp, #-0x88]
    // 0xd16fac: stur            x0, [fp, #-0x38]
    // 0xd16fb0: r0 = defaultColor()
    //     0xd16fb0: bl              #0xd171ec  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::defaultColor
    // 0xd16fb4: stur            x0, [fp, #-0x58]
    // 0xd16fb8: r16 = <Color>
    //     0xd16fb8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xd16fbc: ldr             x16, [x16, #0xa90]
    // 0xd16fc0: ldur            lr, [fp, #-0x10]
    // 0xd16fc4: stp             lr, x16, [SP]
    // 0xd16fc8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd16fc8: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd16fcc: r0 = allOrNull()
    //     0xd16fcc: bl              #0xd17190  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0xd16fd0: stur            x0, [fp, #-0x10]
    // 0xd16fd4: r16 = <double>
    //     0xd16fd4: ldr             x16, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xd16fd8: ldur            lr, [fp, #-0x78]
    // 0xd16fdc: stp             lr, x16, [SP]
    // 0xd16fe0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd16fe0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd16fe4: r0 = allOrNull()
    //     0xd16fe4: bl              #0xd17190  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0xd16fe8: stur            x0, [fp, #-0x78]
    // 0xd16fec: r16 = <EdgeInsetsGeometry>
    //     0xd16fec: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a98] TypeArguments: <EdgeInsetsGeometry>
    //     0xd16ff0: ldr             x16, [x16, #0xa98]
    // 0xd16ff4: ldur            lr, [fp, #-0x40]
    // 0xd16ff8: stp             lr, x16, [SP]
    // 0xd16ffc: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd16ffc: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd17000: r0 = allOrNull()
    //     0xd17000: bl              #0xd17190  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0xd17004: stur            x0, [fp, #-0x40]
    // 0xd17008: r16 = <Size>
    //     0xd17008: add             x16, PP, #0x15, lsl #12  ; [pp+0x15aa0] TypeArguments: <Size>
    //     0xd1700c: ldr             x16, [x16, #0xaa0]
    // 0xd17010: ldur            lr, [fp, #-0x48]
    // 0xd17014: stp             lr, x16, [SP]
    // 0xd17018: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd17018: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd1701c: r0 = allOrNull()
    //     0xd1701c: bl              #0xd17190  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0xd17020: stur            x0, [fp, #-0x48]
    // 0xd17024: r16 = <Size>
    //     0xd17024: add             x16, PP, #0x15, lsl #12  ; [pp+0x15aa0] TypeArguments: <Size>
    //     0xd17028: ldr             x16, [x16, #0xaa0]
    // 0xd1702c: ldur            lr, [fp, #-0x60]
    // 0xd17030: stp             lr, x16, [SP]
    // 0xd17034: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd17034: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd17038: r0 = allOrNull()
    //     0xd17038: bl              #0xd17190  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0xd1703c: stur            x0, [fp, #-0x60]
    // 0xd17040: r16 = <Size>
    //     0xd17040: add             x16, PP, #0x15, lsl #12  ; [pp+0x15aa0] TypeArguments: <Size>
    //     0xd17044: ldr             x16, [x16, #0xaa0]
    // 0xd17048: ldur            lr, [fp, #-0x50]
    // 0xd1704c: stp             lr, x16, [SP]
    // 0xd17050: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd17050: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd17054: r0 = allOrNull()
    //     0xd17054: bl              #0xd17190  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0xd17058: stur            x0, [fp, #-0x50]
    // 0xd1705c: r16 = <OutlinedBorder>
    //     0xd1705c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15aa8] TypeArguments: <OutlinedBorder>
    //     0xd17060: ldr             x16, [x16, #0xaa8]
    // 0xd17064: ldur            lr, [fp, #-0x18]
    // 0xd17068: stp             lr, x16, [SP]
    // 0xd1706c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xd1706c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xd17070: r0 = allOrNull()
    //     0xd17070: bl              #0xd17190  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0xd17074: r1 = Null
    //     0xd17074: mov             x1, NULL
    // 0xd17078: r2 = 8
    //     0xd17078: mov             x2, #8
    // 0xd1707c: stur            x0, [fp, #-0x18]
    // 0xd17080: r0 = AllocateArray()
    //     0xd17080: bl              #0x13df928  ; AllocateArrayStub
    // 0xd17084: r16 = Instance_WidgetState
    //     0xd17084: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0xd17088: ldr             x16, [x16, #0xa70]
    // 0xd1708c: StoreField: r0->field_f = r16
    //     0xd1708c: stur            w16, [x0, #0xf]
    // 0xd17090: ldur            x1, [fp, #-0x80]
    // 0xd17094: StoreField: r0->field_13 = r1
    //     0xd17094: stur            w1, [x0, #0x13]
    // 0xd17098: r16 = Instance__AnyWidgetStates
    //     0xd17098: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a78] Obj!_AnyWidgetStates@12aa401
    //     0xd1709c: ldr             x16, [x16, #0xa78]
    // 0xd170a0: ArrayStore: r0[0] = r16  ; List_4
    //     0xd170a0: stur            w16, [x0, #0x17]
    // 0xd170a4: ldur            x1, [fp, #-0x68]
    // 0xd170a8: StoreField: r0->field_1b = r1
    //     0xd170a8: stur            w1, [x0, #0x1b]
    // 0xd170ac: r16 = <WidgetStatesConstraint, MouseCursor?>
    //     0xd170ac: add             x16, PP, #0x15, lsl #12  ; [pp+0x15ab0] TypeArguments: <WidgetStatesConstraint, MouseCursor?>
    //     0xd170b0: ldr             x16, [x16, #0xab0]
    // 0xd170b4: stp             x0, x16, [SP]
    // 0xd170b8: r0 = Map._fromLiteral()
    //     0xd170b8: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xd170bc: r1 = <MouseCursor?>
    //     0xd170bc: add             x1, PP, #0x15, lsl #12  ; [pp+0x15ab8] TypeArguments: <MouseCursor?>
    //     0xd170c0: ldr             x1, [x1, #0xab8]
    // 0xd170c4: stur            x0, [fp, #-0x68]
    // 0xd170c8: r0 = WidgetStateMapper()
    //     0xd170c8: bl              #0xd171e0  ; AllocateWidgetStateMapperStub -> WidgetStateMapper<X0> (size=0x10)
    // 0xd170cc: mov             x1, x0
    // 0xd170d0: ldur            x0, [fp, #-0x68]
    // 0xd170d4: stur            x1, [fp, #-0x80]
    // 0xd170d8: StoreField: r1->field_b = r0
    //     0xd170d8: stur            w0, [x1, #0xb]
    // 0xd170dc: r0 = ButtonStyle()
    //     0xd170dc: bl              #0xd17184  ; AllocateButtonStyleStub -> ButtonStyle (size=0x6c)
    // 0xd170e0: ldur            x1, [fp, #-0x38]
    // 0xd170e4: StoreField: r0->field_7 = r1
    //     0xd170e4: stur            w1, [x0, #7]
    // 0xd170e8: ldur            x1, [fp, #-0x90]
    // 0xd170ec: StoreField: r0->field_b = r1
    //     0xd170ec: stur            w1, [x0, #0xb]
    // 0xd170f0: ldur            x1, [fp, #-0x58]
    // 0xd170f4: StoreField: r0->field_f = r1
    //     0xd170f4: stur            w1, [x0, #0xf]
    // 0xd170f8: ldur            x1, [fp, #-0xa0]
    // 0xd170fc: StoreField: r0->field_13 = r1
    //     0xd170fc: stur            w1, [x0, #0x13]
    // 0xd17100: ldur            x1, [fp, #-0x10]
    // 0xd17104: ArrayStore: r0[0] = r1  ; List_4
    //     0xd17104: stur            w1, [x0, #0x17]
    // 0xd17108: ldur            x1, [fp, #-0x78]
    // 0xd1710c: StoreField: r0->field_1f = r1
    //     0xd1710c: stur            w1, [x0, #0x1f]
    // 0xd17110: ldur            x1, [fp, #-0x40]
    // 0xd17114: StoreField: r0->field_23 = r1
    //     0xd17114: stur            w1, [x0, #0x23]
    // 0xd17118: ldur            x1, [fp, #-0x48]
    // 0xd1711c: StoreField: r0->field_27 = r1
    //     0xd1711c: stur            w1, [x0, #0x27]
    // 0xd17120: ldur            x1, [fp, #-0x60]
    // 0xd17124: StoreField: r0->field_2b = r1
    //     0xd17124: stur            w1, [x0, #0x2b]
    // 0xd17128: ldur            x1, [fp, #-0x50]
    // 0xd1712c: StoreField: r0->field_2f = r1
    //     0xd1712c: stur            w1, [x0, #0x2f]
    // 0xd17130: ldur            x1, [fp, #-0x18]
    // 0xd17134: StoreField: r0->field_43 = r1
    //     0xd17134: stur            w1, [x0, #0x43]
    // 0xd17138: ldur            x1, [fp, #-0x80]
    // 0xd1713c: StoreField: r0->field_47 = r1
    //     0xd1713c: stur            w1, [x0, #0x47]
    // 0xd17140: ldur            x1, [fp, #-0x30]
    // 0xd17144: StoreField: r0->field_4b = r1
    //     0xd17144: stur            w1, [x0, #0x4b]
    // 0xd17148: ldur            x1, [fp, #-0x28]
    // 0xd1714c: StoreField: r0->field_4f = r1
    //     0xd1714c: stur            w1, [x0, #0x4f]
    // 0xd17150: ldur            x1, [fp, #-0x98]
    // 0xd17154: StoreField: r0->field_53 = r1
    //     0xd17154: stur            w1, [x0, #0x53]
    // 0xd17158: ldur            x1, [fp, #-0x70]
    // 0xd1715c: StoreField: r0->field_57 = r1
    //     0xd1715c: stur            w1, [x0, #0x57]
    // 0xd17160: ldur            x1, [fp, #-8]
    // 0xd17164: StoreField: r0->field_5b = r1
    //     0xd17164: stur            w1, [x0, #0x5b]
    // 0xd17168: ldur            x1, [fp, #-0x20]
    // 0xd1716c: StoreField: r0->field_5f = r1
    //     0xd1716c: stur            w1, [x0, #0x5f]
    // 0xd17170: LeaveFrame
    //     0xd17170: mov             SP, fp
    //     0xd17174: ldp             fp, lr, [SP], #0x10
    // 0xd17178: ret
    //     0xd17178: ret             
    // 0xd1717c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1717c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd17180: b               #0xd16c8c
  }
  _ TextButton.icon(/* No info */) {
    // ** addr: 0xfd8bbc, size: 0xe8
    // 0xfd8bbc: EnterFrame
    //     0xfd8bbc: stp             fp, lr, [SP, #-0x10]!
    //     0xfd8bc0: mov             fp, SP
    // 0xfd8bc4: AllocStack(0x28)
    //     0xfd8bc4: sub             SP, SP, #0x28
    // 0xfd8bc8: r0 = true
    //     0xfd8bc8: add             x0, NULL, #0x20  ; true
    // 0xfd8bcc: mov             x4, x2
    // 0xfd8bd0: stur            x2, [fp, #-0x10]
    // 0xfd8bd4: mov             x2, x5
    // 0xfd8bd8: stur            x5, [fp, #-0x20]
    // 0xfd8bdc: mov             x5, x1
    // 0xfd8be0: stur            x1, [fp, #-8]
    // 0xfd8be4: mov             x1, x6
    // 0xfd8be8: stur            x3, [fp, #-0x18]
    // 0xfd8bec: stur            x6, [fp, #-0x28]
    // 0xfd8bf0: StoreField: r5->field_3b = r0
    //     0xfd8bf0: stur            w0, [x5, #0x3b]
    // 0xfd8bf4: r0 = _TextButtonWithIconChild()
    //     0xfd8bf4: bl              #0xfd8ca4  ; Allocate_TextButtonWithIconChildStub -> _TextButtonWithIconChild (size=0x1c)
    // 0xfd8bf8: mov             x2, x0
    // 0xfd8bfc: ldur            x1, [fp, #-0x18]
    // 0xfd8c00: StoreField: r2->field_b = r1
    //     0xfd8c00: stur            w1, [x2, #0xb]
    // 0xfd8c04: ldur            x1, [fp, #-0x10]
    // 0xfd8c08: StoreField: r2->field_f = r1
    //     0xfd8c08: stur            w1, [x2, #0xf]
    // 0xfd8c0c: ldur            x1, [fp, #-0x28]
    // 0xfd8c10: StoreField: r2->field_13 = r1
    //     0xfd8c10: stur            w1, [x2, #0x13]
    // 0xfd8c14: ldur            x0, [fp, #-0x20]
    // 0xfd8c18: ldur            x3, [fp, #-8]
    // 0xfd8c1c: StoreField: r3->field_b = r0
    //     0xfd8c1c: stur            w0, [x3, #0xb]
    //     0xfd8c20: ldurb           w16, [x3, #-1]
    //     0xfd8c24: ldurb           w17, [x0, #-1]
    //     0xfd8c28: and             x16, x17, x16, lsr #2
    //     0xfd8c2c: tst             x16, HEAP, lsr #32
    //     0xfd8c30: b.eq            #0xfd8c38
    //     0xfd8c34: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xfd8c38: mov             x0, x1
    // 0xfd8c3c: StoreField: r3->field_1b = r0
    //     0xfd8c3c: stur            w0, [x3, #0x1b]
    //     0xfd8c40: ldurb           w16, [x3, #-1]
    //     0xfd8c44: ldurb           w17, [x0, #-1]
    //     0xfd8c48: and             x16, x17, x16, lsr #2
    //     0xfd8c4c: tst             x16, HEAP, lsr #32
    //     0xfd8c50: b.eq            #0xfd8c58
    //     0xfd8c54: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xfd8c58: r1 = false
    //     0xfd8c58: add             x1, NULL, #0x30  ; false
    // 0xfd8c5c: StoreField: r3->field_27 = r1
    //     0xfd8c5c: stur            w1, [x3, #0x27]
    // 0xfd8c60: r1 = Instance_Clip
    //     0xfd8c60: add             x1, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xfd8c64: ldr             x1, [x1, #0x840]
    // 0xfd8c68: StoreField: r3->field_1f = r1
    //     0xfd8c68: stur            w1, [x3, #0x1f]
    // 0xfd8c6c: r1 = true
    //     0xfd8c6c: add             x1, NULL, #0x20  ; true
    // 0xfd8c70: StoreField: r3->field_2f = r1
    //     0xfd8c70: stur            w1, [x3, #0x2f]
    // 0xfd8c74: mov             x0, x2
    // 0xfd8c78: StoreField: r3->field_37 = r0
    //     0xfd8c78: stur            w0, [x3, #0x37]
    //     0xfd8c7c: ldurb           w16, [x3, #-1]
    //     0xfd8c80: ldurb           w17, [x0, #-1]
    //     0xfd8c84: and             x16, x17, x16, lsr #2
    //     0xfd8c88: tst             x16, HEAP, lsr #32
    //     0xfd8c8c: b.eq            #0xfd8c94
    //     0xfd8c90: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xfd8c94: r0 = Null
    //     0xfd8c94: mov             x0, NULL
    // 0xfd8c98: LeaveFrame
    //     0xfd8c98: mov             SP, fp
    //     0xfd8c9c: ldp             fp, lr, [SP], #0x10
    // 0xfd8ca0: ret
    //     0xfd8ca0: ret             
  }
  _ defaultStyleOf(/* No info */) {
    // ** addr: 0x122a658, size: 0x310
    // 0x122a658: EnterFrame
    //     0x122a658: stp             fp, lr, [SP, #-0x10]!
    //     0x122a65c: mov             fp, SP
    // 0x122a660: AllocStack(0xe0)
    //     0x122a660: sub             SP, SP, #0xe0
    // 0x122a664: SetupParameters(TextButton this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x122a664: mov             x0, x2
    //     0x122a668: stur            x2, [fp, #-0x10]
    //     0x122a66c: mov             x2, x1
    //     0x122a670: stur            x1, [fp, #-8]
    // 0x122a674: CheckStackOverflow
    //     0x122a674: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x122a678: cmp             SP, x16
    //     0x122a67c: b.ls            #0x122a960
    // 0x122a680: mov             x1, x0
    // 0x122a684: r0 = of()
    //     0x122a684: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x122a688: mov             x2, x0
    // 0x122a68c: stur            x2, [fp, #-0x28]
    // 0x122a690: LoadField: r0 = r2->field_3f
    //     0x122a690: ldur            w0, [x2, #0x3f]
    // 0x122a694: DecompressPointer r0
    //     0x122a694: add             x0, x0, HEAP, lsl #32
    // 0x122a698: LoadField: r1 = r2->field_2f
    //     0x122a698: ldur            w1, [x2, #0x2f]
    // 0x122a69c: DecompressPointer r1
    //     0x122a69c: add             x1, x1, HEAP, lsl #32
    // 0x122a6a0: stur            x1, [fp, #-0x18]
    // 0x122a6a4: tbnz            w1, #4, #0x122a6ec
    // 0x122a6a8: ldur            x0, [fp, #-0x10]
    // 0x122a6ac: r0 = _TextButtonDefaultsM3()
    //     0x122a6ac: bl              #0x122a968  ; Allocate_TextButtonDefaultsM3Stub -> _TextButtonDefaultsM3 (size=0x74)
    // 0x122a6b0: mov             x1, x0
    // 0x122a6b4: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x122a6b8: StoreField: r1->field_6f = r0
    //     0x122a6b8: stur            w0, [x1, #0x6f]
    // 0x122a6bc: ldur            x3, [fp, #-0x10]
    // 0x122a6c0: StoreField: r1->field_6b = r3
    //     0x122a6c0: stur            w3, [x1, #0x6b]
    // 0x122a6c4: r0 = Instance_Duration
    //     0x122a6c4: add             x0, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0x122a6c8: ldr             x0, [x0, #0x318]
    // 0x122a6cc: StoreField: r1->field_53 = r0
    //     0x122a6cc: stur            w0, [x1, #0x53]
    // 0x122a6d0: r0 = true
    //     0x122a6d0: add             x0, NULL, #0x20  ; true
    // 0x122a6d4: StoreField: r1->field_57 = r0
    //     0x122a6d4: stur            w0, [x1, #0x57]
    // 0x122a6d8: r0 = Instance_Alignment
    //     0x122a6d8: add             x0, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0x122a6dc: ldr             x0, [x0, #0xb80]
    // 0x122a6e0: StoreField: r1->field_5b = r0
    //     0x122a6e0: stur            w0, [x1, #0x5b]
    // 0x122a6e4: mov             x2, x1
    // 0x122a6e8: b               #0x122a804
    // 0x122a6ec: ldur            x3, [fp, #-0x10]
    // 0x122a6f0: LoadField: r4 = r0->field_b
    //     0x122a6f0: ldur            w4, [x0, #0xb]
    // 0x122a6f4: DecompressPointer r4
    //     0x122a6f4: add             x4, x4, HEAP, lsl #32
    // 0x122a6f8: stur            x4, [fp, #-0x20]
    // 0x122a6fc: LoadField: r1 = r0->field_7f
    //     0x122a6fc: ldur            w1, [x0, #0x7f]
    // 0x122a700: DecompressPointer r1
    //     0x122a700: add             x1, x1, HEAP, lsl #32
    // 0x122a704: r0 = LoadClassIdInstr(r1)
    //     0x122a704: ldur            x0, [x1, #-1]
    //     0x122a708: ubfx            x0, x0, #0xc, #0x14
    // 0x122a70c: d0 = 0.380000
    //     0x122a70c: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0x122a710: ldr             d0, [x17, #0x1f0]
    // 0x122a714: r0 = GDT[cid_x0 + -0x1000]()
    //     0x122a714: sub             lr, x0, #1, lsl #12
    //     0x122a718: ldr             lr, [x21, lr, lsl #3]
    //     0x122a71c: blr             lr
    // 0x122a720: mov             x2, x0
    // 0x122a724: ldur            x0, [fp, #-0x28]
    // 0x122a728: stur            x2, [fp, #-0x40]
    // 0x122a72c: LoadField: r3 = r0->field_6f
    //     0x122a72c: ldur            w3, [x0, #0x6f]
    // 0x122a730: DecompressPointer r3
    //     0x122a730: add             x3, x3, HEAP, lsl #32
    // 0x122a734: stur            x3, [fp, #-0x38]
    // 0x122a738: LoadField: r1 = r0->field_87
    //     0x122a738: ldur            w1, [x0, #0x87]
    // 0x122a73c: DecompressPointer r1
    //     0x122a73c: add             x1, x1, HEAP, lsl #32
    // 0x122a740: LoadField: r4 = r1->field_37
    //     0x122a740: ldur            w4, [x1, #0x37]
    // 0x122a744: DecompressPointer r4
    //     0x122a744: add             x4, x4, HEAP, lsl #32
    // 0x122a748: ldur            x1, [fp, #-0x10]
    // 0x122a74c: stur            x4, [fp, #-0x30]
    // 0x122a750: r0 = _scaledPadding()
    //     0x122a750: bl              #0x1141de8  ; [package:flutter/src/material/text_button.dart] ::_scaledPadding
    // 0x122a754: mov             x1, x0
    // 0x122a758: ldur            x0, [fp, #-0x28]
    // 0x122a75c: LoadField: r2 = r0->field_33
    //     0x122a75c: ldur            w2, [x0, #0x33]
    // 0x122a760: DecompressPointer r2
    //     0x122a760: add             x2, x2, HEAP, lsl #32
    // 0x122a764: LoadField: r3 = r0->field_1b
    //     0x122a764: ldur            w3, [x0, #0x1b]
    // 0x122a768: DecompressPointer r3
    //     0x122a768: add             x3, x3, HEAP, lsl #32
    // 0x122a76c: ldur            x16, [fp, #-0x20]
    // 0x122a770: ldur            lr, [fp, #-0x40]
    // 0x122a774: stp             lr, x16, [SP, #0x88]
    // 0x122a778: r16 = Instance_Color
    //     0x122a778: add             x16, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x122a77c: ldr             x16, [x16, #0x810]
    // 0x122a780: r30 = Instance_Color
    //     0x122a780: add             lr, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0x122a784: ldr             lr, [lr, #0x810]
    // 0x122a788: stp             lr, x16, [SP, #0x78]
    // 0x122a78c: ldur            x16, [fp, #-0x38]
    // 0x122a790: r30 = 0.000000
    //     0x122a790: ldr             lr, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0x122a794: stp             lr, x16, [SP, #0x68]
    // 0x122a798: ldur            x16, [fp, #-0x30]
    // 0x122a79c: stp             x1, x16, [SP, #0x58]
    // 0x122a7a0: r16 = Instance_Size
    //     0x122a7a0: add             x16, PP, #0x95, lsl #12  ; [pp+0x95c20] Obj!Size@12a79f1
    //     0x122a7a4: ldr             x16, [x16, #0xc20]
    // 0x122a7a8: r30 = Instance_Size
    //     0x122a7a8: add             lr, PP, #0x95, lsl #12  ; [pp+0x95c28] Obj!Size@12a79b1
    //     0x122a7ac: ldr             lr, [lr, #0xc28]
    // 0x122a7b0: stp             lr, x16, [SP, #0x48]
    // 0x122a7b4: r16 = Instance_RoundedRectangleBorder
    //     0x122a7b4: add             x16, PP, #0x26, lsl #12  ; [pp+0x26218] Obj!RoundedRectangleBorder@129ec21
    //     0x122a7b8: ldr             x16, [x16, #0x218]
    // 0x122a7bc: r30 = Instance_SystemMouseCursor
    //     0x122a7bc: ldr             lr, [PP, #0x21b0]  ; [pp+0x21b0] Obj!SystemMouseCursor@12b3201
    // 0x122a7c0: stp             lr, x16, [SP, #0x38]
    // 0x122a7c4: r16 = Instance_SystemMouseCursor
    //     0x122a7c4: ldr             x16, [PP, #0x21b0]  ; [pp+0x21b0] Obj!SystemMouseCursor@12b3201
    // 0x122a7c8: stp             x2, x16, [SP, #0x28]
    // 0x122a7cc: r16 = Instance_Duration
    //     0x122a7cc: add             x16, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0x122a7d0: ldr             x16, [x16, #0x318]
    // 0x122a7d4: stp             x16, x3, [SP, #0x18]
    // 0x122a7d8: r16 = true
    //     0x122a7d8: add             x16, NULL, #0x20  ; true
    // 0x122a7dc: r30 = Instance_Alignment
    //     0x122a7dc: add             lr, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0x122a7e0: ldr             lr, [lr, #0xb80]
    // 0x122a7e4: stp             lr, x16, [SP, #8]
    // 0x122a7e8: r16 = Instance__InkRippleFactory
    //     0x122a7e8: add             x16, PP, #0x95, lsl #12  ; [pp+0x95c30] Obj!_InkRippleFactory@129ecd1
    //     0x122a7ec: ldr             x16, [x16, #0xc30]
    // 0x122a7f0: str             x16, [SP]
    // 0x122a7f4: r4 = const [0, 0x13, 0x13, 0, alignment, 0x11, animationDuration, 0xf, backgroundColor, 0x2, disabledBackgroundColor, 0x3, disabledForegroundColor, 0x1, disabledMouseCursor, 0xc, elevation, 0x5, enableFeedback, 0x10, enabledMouseCursor, 0xb, foregroundColor, 0, maximumSize, 0x9, minimumSize, 0x8, padding, 0x7, shadowColor, 0x4, shape, 0xa, splashFactory, 0x12, tapTargetSize, 0xe, textStyle, 0x6, visualDensity, 0xd, null]
    //     0x122a7f4: add             x4, PP, #0x96, lsl #12  ; [pp+0x96158] List(43) [0, 0x13, 0x13, 0, "alignment", 0x11, "animationDuration", 0xf, "backgroundColor", 0x2, "disabledBackgroundColor", 0x3, "disabledForegroundColor", 0x1, "disabledMouseCursor", 0xc, "elevation", 0x5, "enableFeedback", 0x10, "enabledMouseCursor", 0xb, "foregroundColor", 0, "maximumSize", 0x9, "minimumSize", 0x8, "padding", 0x7, "shadowColor", 0x4, "shape", 0xa, "splashFactory", 0x12, "tapTargetSize", 0xe, "textStyle", 0x6, "visualDensity", 0xd, Null]
    //     0x122a7f8: ldr             x4, [x4, #0x158]
    // 0x122a7fc: r0 = styleFrom()
    //     0x122a7fc: bl              #0xd16538  ; [package:flutter/src/material/text_button.dart] TextButton::styleFrom
    // 0x122a800: mov             x2, x0
    // 0x122a804: ldur            x0, [fp, #-8]
    // 0x122a808: stur            x2, [fp, #-0x20]
    // 0x122a80c: LoadField: r1 = r0->field_3b
    //     0x122a80c: ldur            w1, [x0, #0x3b]
    // 0x122a810: DecompressPointer r1
    //     0x122a810: add             x1, x1, HEAP, lsl #32
    // 0x122a814: tbnz            w1, #4, #0x122a950
    // 0x122a818: r0 = LoadClassIdInstr(r2)
    //     0x122a818: ldur            x0, [x2, #-1]
    //     0x122a81c: ubfx            x0, x0, #0xc, #0x14
    // 0x122a820: mov             x1, x2
    // 0x122a824: r0 = GDT[cid_x0 + 0xe00]()
    //     0x122a824: add             lr, x0, #0xe00
    //     0x122a828: ldr             lr, [x21, lr, lsl #3]
    //     0x122a82c: blr             lr
    // 0x122a830: cmp             w0, NULL
    // 0x122a834: b.ne            #0x122a840
    // 0x122a838: r0 = Null
    //     0x122a838: mov             x0, NULL
    // 0x122a83c: b               #0x122a88c
    // 0x122a840: r1 = LoadClassIdInstr(r0)
    //     0x122a840: ldur            x1, [x0, #-1]
    //     0x122a844: ubfx            x1, x1, #0xc, #0x14
    // 0x122a848: mov             x16, x0
    // 0x122a84c: mov             x0, x1
    // 0x122a850: mov             x1, x16
    // 0x122a854: r2 = _ConstSet len:0
    //     0x122a854: add             x2, PP, #0x26, lsl #12  ; [pp+0x26248] Set<WidgetState>(0)
    //     0x122a858: ldr             x2, [x2, #0x248]
    // 0x122a85c: r0 = GDT[cid_x0 + 0x17c77]()
    //     0x122a85c: mov             x17, #0x7c77
    //     0x122a860: movk            x17, #1, lsl #16
    //     0x122a864: add             lr, x0, x17
    //     0x122a868: ldr             lr, [x21, lr, lsl #3]
    //     0x122a86c: blr             lr
    // 0x122a870: cmp             w0, NULL
    // 0x122a874: b.ne            #0x122a880
    // 0x122a878: r0 = Null
    //     0x122a878: mov             x0, NULL
    // 0x122a87c: b               #0x122a88c
    // 0x122a880: LoadField: r1 = r0->field_1f
    //     0x122a880: ldur            w1, [x0, #0x1f]
    // 0x122a884: DecompressPointer r1
    //     0x122a884: add             x1, x1, HEAP, lsl #32
    // 0x122a888: mov             x0, x1
    // 0x122a88c: cmp             w0, NULL
    // 0x122a890: b.ne            #0x122a89c
    // 0x122a894: d0 = 14.000000
    //     0x122a894: fmov            d0, #14.00000000
    // 0x122a898: b               #0x122a8a0
    // 0x122a89c: LoadField: d0 = r0->field_7
    //     0x122a89c: ldur            d0, [x0, #7]
    // 0x122a8a0: ldur            x0, [fp, #-0x18]
    // 0x122a8a4: ldur            x1, [fp, #-0x10]
    // 0x122a8a8: stur            d0, [fp, #-0x48]
    // 0x122a8ac: r0 = textScalerOf()
    //     0x122a8ac: bl              #0xd16168  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::textScalerOf
    // 0x122a8b0: r1 = LoadClassIdInstr(r0)
    //     0x122a8b0: ldur            x1, [x0, #-1]
    //     0x122a8b4: ubfx            x1, x1, #0xc, #0x14
    // 0x122a8b8: mov             x16, x0
    // 0x122a8bc: mov             x0, x1
    // 0x122a8c0: mov             x1, x16
    // 0x122a8c4: ldur            d0, [fp, #-0x48]
    // 0x122a8c8: r0 = GDT[cid_x0 + -0x1000]()
    //     0x122a8c8: sub             lr, x0, #1, lsl #12
    //     0x122a8cc: ldr             lr, [x21, lr, lsl #3]
    //     0x122a8d0: blr             lr
    // 0x122a8d4: LoadField: d0 = r0->field_7
    //     0x122a8d4: ldur            d0, [x0, #7]
    // 0x122a8d8: d1 = 14.000000
    //     0x122a8d8: fmov            d1, #14.00000000
    // 0x122a8dc: fdiv            d2, d0, d1
    // 0x122a8e0: ldur            x0, [fp, #-0x18]
    // 0x122a8e4: tbnz            w0, #4, #0x122a8f4
    // 0x122a8e8: r1 = Instance_EdgeInsetsDirectional
    //     0x122a8e8: add             x1, PP, #0x96, lsl #12  ; [pp+0x96160] Obj!EdgeInsetsDirectional@129cba1
    //     0x122a8ec: ldr             x1, [x1, #0x160]
    // 0x122a8f0: b               #0x122a8fc
    // 0x122a8f4: r1 = Instance_EdgeInsets
    //     0x122a8f4: add             x1, PP, #0x18, lsl #12  ; [pp+0x18338] Obj!EdgeInsets@129d051
    //     0x122a8f8: ldr             x1, [x1, #0x338]
    // 0x122a8fc: mov             v0.16b, v2.16b
    // 0x122a900: r2 = Instance_EdgeInsets
    //     0x122a900: add             x2, PP, #0x1c, lsl #12  ; [pp+0x1c430] Obj!EdgeInsets@129dc51
    //     0x122a904: ldr             x2, [x2, #0x430]
    // 0x122a908: r3 = Instance_EdgeInsets
    //     0x122a908: add             x3, PP, #0x1c, lsl #12  ; [pp+0x1c430] Obj!EdgeInsets@129dc51
    //     0x122a90c: ldr             x3, [x3, #0x430]
    // 0x122a910: r0 = scaledPadding()
    //     0x122a910: bl              #0x1140cd0  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::scaledPadding
    // 0x122a914: r1 = <EdgeInsetsGeometry>
    //     0x122a914: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a98] TypeArguments: <EdgeInsetsGeometry>
    //     0x122a918: ldr             x1, [x1, #0xa98]
    // 0x122a91c: stur            x0, [fp, #-8]
    // 0x122a920: r0 = WidgetStatePropertyAll()
    //     0x122a920: bl              #0xd132c8  ; AllocateWidgetStatePropertyAllStub -> WidgetStatePropertyAll<X0> (size=0x10)
    // 0x122a924: mov             x1, x0
    // 0x122a928: ldur            x0, [fp, #-8]
    // 0x122a92c: StoreField: r1->field_b = r0
    //     0x122a92c: stur            w0, [x1, #0xb]
    // 0x122a930: str             x1, [SP]
    // 0x122a934: ldur            x1, [fp, #-0x20]
    // 0x122a938: r4 = const [0, 0x2, 0x1, 0x1, padding, 0x1, null]
    //     0x122a938: add             x4, PP, #0x19, lsl #12  ; [pp+0x19df0] List(7) [0, 0x2, 0x1, 0x1, "padding", 0x1, Null]
    //     0x122a93c: ldr             x4, [x4, #0xdf0]
    // 0x122a940: r0 = copyWith()
    //     0x122a940: bl              #0xd2991c  ; [package:flutter/src/material/button_style.dart] ButtonStyle::copyWith
    // 0x122a944: LeaveFrame
    //     0x122a944: mov             SP, fp
    //     0x122a948: ldp             fp, lr, [SP], #0x10
    // 0x122a94c: ret
    //     0x122a94c: ret             
    // 0x122a950: ldur            x0, [fp, #-0x20]
    // 0x122a954: LeaveFrame
    //     0x122a954: mov             SP, fp
    //     0x122a958: ldp             fp, lr, [SP], #0x10
    // 0x122a95c: ret
    //     0x122a95c: ret             
    // 0x122a960: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x122a960: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x122a964: b               #0x122a680
  }
  _ themeStyleOf(/* No info */) {
    // ** addr: 0x122ab5c, size: 0x40
    // 0x122ab5c: EnterFrame
    //     0x122ab5c: stp             fp, lr, [SP, #-0x10]!
    //     0x122ab60: mov             fp, SP
    // 0x122ab64: mov             x0, x1
    // 0x122ab68: mov             x1, x2
    // 0x122ab6c: CheckStackOverflow
    //     0x122ab6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x122ab70: cmp             SP, x16
    //     0x122ab74: b.ls            #0x122ab94
    // 0x122ab78: r0 = of()
    //     0x122ab78: bl              #0xfbe86c  ; [package:flutter/src/material/text_button_theme.dart] TextButtonTheme::of
    // 0x122ab7c: LoadField: r1 = r0->field_7
    //     0x122ab7c: ldur            w1, [x0, #7]
    // 0x122ab80: DecompressPointer r1
    //     0x122ab80: add             x1, x1, HEAP, lsl #32
    // 0x122ab84: mov             x0, x1
    // 0x122ab88: LeaveFrame
    //     0x122ab88: mov             SP, fp
    //     0x122ab8c: ldp             fp, lr, [SP], #0x10
    // 0x122ab90: ret
    //     0x122ab90: ret             
    // 0x122ab94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x122ab94: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x122ab98: b               #0x122ab78
  }
}
