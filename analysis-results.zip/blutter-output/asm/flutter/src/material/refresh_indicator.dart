// lib: , url: package:flutter/src/material/refresh_indicator.dart

// class id: 1048937, size: 0x8
class :: {
}

// class id: 5716, size: 0x44, field offset: 0x1c
class RefreshIndicatorState extends _MixinApplication97&State&TickerProviderStateMixin {

  late Animation<double> _positionFactor; // offset: 0x24
  late Animation<double> _scaleFactor; // offset: 0x28
  late AnimationController _positionController; // offset: 0x1c
  late Animation<double> _value; // offset: 0x2c
  late Animation<Color?> _valueColor; // offset: 0x30
  late Color _effectiveValueColor; // offset: 0x40
  late AnimationController _scaleController; // offset: 0x20
  static late final Animatable<double> _kDragSizeFactorLimitTween; // offset: 0x79c
  static late final Animatable<double> _threeQuarterTween; // offset: 0x798
  static late final Animatable<double> _oneToZeroTween; // offset: 0x7a0

  _ build(/* No info */) {
    // ** addr: 0xd334ec, size: 0x3d8
    // 0xd334ec: EnterFrame
    //     0xd334ec: stp             fp, lr, [SP, #-0x10]!
    //     0xd334f0: mov             fp, SP
    // 0xd334f4: AllocStack(0x48)
    //     0xd334f4: sub             SP, SP, #0x48
    // 0xd334f8: SetupParameters(RefreshIndicatorState this /* r1 => r0, fp-0x8 */)
    //     0xd334f8: mov             x0, x1
    //     0xd334fc: stur            x1, [fp, #-8]
    // 0xd33500: CheckStackOverflow
    //     0xd33500: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd33504: cmp             SP, x16
    //     0xd33508: b.ls            #0xd33890
    // 0xd3350c: r1 = 2
    //     0xd3350c: mov             x1, #2
    // 0xd33510: r0 = AllocateContext()
    //     0xd33510: bl              #0x13de838  ; AllocateContextStub
    // 0xd33514: mov             x3, x0
    // 0xd33518: ldur            x0, [fp, #-8]
    // 0xd3351c: stur            x3, [fp, #-0x18]
    // 0xd33520: StoreField: r3->field_f = r0
    //     0xd33520: stur            w0, [x3, #0xf]
    // 0xd33524: LoadField: r1 = r0->field_b
    //     0xd33524: ldur            w1, [x0, #0xb]
    // 0xd33528: DecompressPointer r1
    //     0xd33528: add             x1, x1, HEAP, lsl #32
    // 0xd3352c: cmp             w1, NULL
    // 0xd33530: b.eq            #0xd33898
    // 0xd33534: LoadField: r4 = r1->field_b
    //     0xd33534: ldur            w4, [x1, #0xb]
    // 0xd33538: DecompressPointer r4
    //     0xd33538: add             x4, x4, HEAP, lsl #32
    // 0xd3353c: mov             x2, x0
    // 0xd33540: stur            x4, [fp, #-0x10]
    // 0xd33544: r1 = Function '_handleIndicatorNotification@123083489':.
    //     0xd33544: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f9e0] AnonymousClosure: (0xd34c0c), in [package:flutter/src/material/refresh_indicator.dart] RefreshIndicatorState::_handleIndicatorNotification (0xd34c48)
    //     0xd33548: ldr             x1, [x1, #0x9e0]
    // 0xd3354c: r0 = AllocateClosure()
    //     0xd3354c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd33550: r1 = <OverscrollIndicatorNotification>
    //     0xd33550: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f9e8] TypeArguments: <OverscrollIndicatorNotification>
    //     0xd33554: ldr             x1, [x1, #0x9e8]
    // 0xd33558: stur            x0, [fp, #-0x20]
    // 0xd3355c: r0 = NotificationListener()
    //     0xd3355c: bl              #0xd2ea9c  ; AllocateNotificationListenerStub -> NotificationListener<X0 bound Notification> (size=0x18)
    // 0xd33560: mov             x3, x0
    // 0xd33564: ldur            x0, [fp, #-0x20]
    // 0xd33568: stur            x3, [fp, #-0x28]
    // 0xd3356c: StoreField: r3->field_13 = r0
    //     0xd3356c: stur            w0, [x3, #0x13]
    // 0xd33570: ldur            x0, [fp, #-0x10]
    // 0xd33574: StoreField: r3->field_b = r0
    //     0xd33574: stur            w0, [x3, #0xb]
    // 0xd33578: ldur            x2, [fp, #-8]
    // 0xd3357c: r1 = Function '_handleScrollNotification@123083489':.
    //     0xd3357c: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f9f0] AnonymousClosure: (0xd33b8c), in [package:flutter/src/material/refresh_indicator.dart] RefreshIndicatorState::_handleScrollNotification (0xd33bc8)
    //     0xd33580: ldr             x1, [x1, #0x9f0]
    // 0xd33584: r0 = AllocateClosure()
    //     0xd33584: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd33588: r1 = <ScrollNotification>
    //     0xd33588: add             x1, PP, #0x88, lsl #12  ; [pp+0x88ad0] TypeArguments: <ScrollNotification>
    //     0xd3358c: ldr             x1, [x1, #0xad0]
    // 0xd33590: stur            x0, [fp, #-0x10]
    // 0xd33594: r0 = NotificationListener()
    //     0xd33594: bl              #0xd2ea9c  ; AllocateNotificationListenerStub -> NotificationListener<X0 bound Notification> (size=0x18)
    // 0xd33598: mov             x3, x0
    // 0xd3359c: ldur            x0, [fp, #-0x10]
    // 0xd335a0: stur            x3, [fp, #-0x20]
    // 0xd335a4: StoreField: r3->field_13 = r0
    //     0xd335a4: stur            w0, [x3, #0x13]
    // 0xd335a8: ldur            x0, [fp, #-0x28]
    // 0xd335ac: StoreField: r3->field_b = r0
    //     0xd335ac: stur            w0, [x3, #0xb]
    // 0xd335b0: ldur            x0, [fp, #-8]
    // 0xd335b4: LoadField: r4 = r0->field_33
    //     0xd335b4: ldur            w4, [x0, #0x33]
    // 0xd335b8: DecompressPointer r4
    //     0xd335b8: add             x4, x4, HEAP, lsl #32
    // 0xd335bc: stur            x4, [fp, #-0x10]
    // 0xd335c0: r16 = Instance_RefreshIndicatorStatus
    //     0xd335c0: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8f9f8] Obj!RefreshIndicatorStatus@12c5161
    //     0xd335c4: ldr             x16, [x16, #0x9f8]
    // 0xd335c8: cmp             w4, w16
    // 0xd335cc: b.ne            #0xd335d8
    // 0xd335d0: r1 = true
    //     0xd335d0: add             x1, NULL, #0x20  ; true
    // 0xd335d4: b               #0xd335f0
    // 0xd335d8: r16 = Instance_RefreshIndicatorStatus
    //     0xd335d8: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8fa00] Obj!RefreshIndicatorStatus@12c5141
    //     0xd335dc: ldr             x16, [x16, #0xa00]
    // 0xd335e0: cmp             w4, w16
    // 0xd335e4: r16 = true
    //     0xd335e4: add             x16, NULL, #0x20  ; true
    // 0xd335e8: r17 = false
    //     0xd335e8: add             x17, NULL, #0x30  ; false
    // 0xd335ec: csel            x1, x16, x17, eq
    // 0xd335f0: ldur            x5, [fp, #-0x18]
    // 0xd335f4: r6 = 2
    //     0xd335f4: mov             x6, #2
    // 0xd335f8: StoreField: r5->field_13 = r1
    //     0xd335f8: stur            w1, [x5, #0x13]
    // 0xd335fc: mov             x2, x6
    // 0xd33600: r1 = Null
    //     0xd33600: mov             x1, NULL
    // 0xd33604: r0 = AllocateArray()
    //     0xd33604: bl              #0x13df928  ; AllocateArrayStub
    // 0xd33608: mov             x2, x0
    // 0xd3360c: ldur            x0, [fp, #-0x20]
    // 0xd33610: stur            x2, [fp, #-0x28]
    // 0xd33614: StoreField: r2->field_f = r0
    //     0xd33614: stur            w0, [x2, #0xf]
    // 0xd33618: r1 = <Widget>
    //     0xd33618: ldr             x1, [PP, #0x5468]  ; [pp+0x5468] TypeArguments: <Widget>
    // 0xd3361c: r0 = AllocateGrowableArray()
    //     0xd3361c: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xd33620: mov             x1, x0
    // 0xd33624: ldur            x0, [fp, #-0x28]
    // 0xd33628: stur            x1, [fp, #-0x20]
    // 0xd3362c: StoreField: r1->field_f = r0
    //     0xd3362c: stur            w0, [x1, #0xf]
    // 0xd33630: r0 = 2
    //     0xd33630: mov             x0, #2
    // 0xd33634: StoreField: r1->field_b = r0
    //     0xd33634: stur            w0, [x1, #0xb]
    // 0xd33638: ldur            x0, [fp, #-0x10]
    // 0xd3363c: cmp             w0, NULL
    // 0xd33640: b.eq            #0xd3383c
    // 0xd33644: ldur            x0, [fp, #-8]
    // 0xd33648: LoadField: r2 = r0->field_37
    //     0xd33648: ldur            w2, [x0, #0x37]
    // 0xd3364c: DecompressPointer r2
    //     0xd3364c: add             x2, x2, HEAP, lsl #32
    // 0xd33650: cmp             w2, NULL
    // 0xd33654: b.eq            #0xd3389c
    // 0xd33658: tbnz            w2, #4, #0xd33664
    // 0xd3365c: r3 = 0.000000
    //     0xd3365c: ldr             x3, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xd33660: b               #0xd33668
    // 0xd33664: r3 = Null
    //     0xd33664: mov             x3, NULL
    // 0xd33668: stur            x3, [fp, #-0x10]
    // 0xd3366c: tbnz            w2, #4, #0xd33884
    // 0xd33670: r0 = AlignmentDirectional()
    //     0xd33670: bl              #0xb5f54c  ; AllocateAlignmentDirectionalStub -> AlignmentDirectional (size=0x18)
    // 0xd33674: d0 = -1.000000
    //     0xd33674: fmov            d0, #-1.00000000
    // 0xd33678: stur            x0, [fp, #-0x30]
    // 0xd3367c: StoreField: r0->field_7 = d0
    //     0xd3367c: stur            d0, [x0, #7]
    // 0xd33680: d0 = 1.000000
    //     0xd33680: fmov            d0, #1.00000000
    // 0xd33684: StoreField: r0->field_f = d0
    //     0xd33684: stur            d0, [x0, #0xf]
    // 0xd33688: ldur            x1, [fp, #-8]
    // 0xd3368c: LoadField: r2 = r1->field_23
    //     0xd3368c: ldur            w2, [x1, #0x23]
    // 0xd33690: DecompressPointer r2
    //     0xd33690: add             x2, x2, HEAP, lsl #32
    // 0xd33694: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd33698: cmp             w2, w16
    // 0xd3369c: b.eq            #0xd338a0
    // 0xd336a0: stur            x2, [fp, #-0x28]
    // 0xd336a4: r0 = EdgeInsets()
    //     0xd336a4: bl              #0x858568  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xd336a8: stur            x0, [fp, #-0x48]
    // 0xd336ac: StoreField: r0->field_7 = rZR
    //     0xd336ac: stur            xzr, [x0, #7]
    // 0xd336b0: d0 = 40.000000
    //     0xd336b0: add             x17, PP, #0x13, lsl #12  ; [pp+0x13168] IMM: double(40) from 0x4044000000000000
    //     0xd336b4: ldr             d0, [x17, #0x168]
    // 0xd336b8: StoreField: r0->field_f = d0
    //     0xd336b8: stur            d0, [x0, #0xf]
    // 0xd336bc: ArrayStore: r0[0] = rZR  ; List_8
    //     0xd336bc: stur            xzr, [x0, #0x17]
    // 0xd336c0: StoreField: r0->field_1f = rZR
    //     0xd336c0: stur            xzr, [x0, #0x1f]
    // 0xd336c4: ldur            x1, [fp, #-8]
    // 0xd336c8: LoadField: r3 = r1->field_27
    //     0xd336c8: ldur            w3, [x1, #0x27]
    // 0xd336cc: DecompressPointer r3
    //     0xd336cc: add             x3, x3, HEAP, lsl #32
    // 0xd336d0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd336d4: cmp             w3, w16
    // 0xd336d8: b.eq            #0xd338ac
    // 0xd336dc: stur            x3, [fp, #-0x40]
    // 0xd336e0: LoadField: r4 = r1->field_1b
    //     0xd336e0: ldur            w4, [x1, #0x1b]
    // 0xd336e4: DecompressPointer r4
    //     0xd336e4: add             x4, x4, HEAP, lsl #32
    // 0xd336e8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd336ec: cmp             w4, w16
    // 0xd336f0: b.eq            #0xd338b8
    // 0xd336f4: ldur            x2, [fp, #-0x18]
    // 0xd336f8: stur            x4, [fp, #-0x38]
    // 0xd336fc: r1 = Function '<anonymous closure>':.
    //     0xd336fc: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8fa08] AnonymousClosure: (0xd338c4), in [package:flutter/src/material/refresh_indicator.dart] RefreshIndicatorState::build (0xd334ec)
    //     0xd33700: ldr             x1, [x1, #0xa08]
    // 0xd33704: r0 = AllocateClosure()
    //     0xd33704: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd33708: stur            x0, [fp, #-8]
    // 0xd3370c: r0 = AnimatedBuilder()
    //     0xd3370c: bl              #0x918e2c  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0xd33710: mov             x1, x0
    // 0xd33714: ldur            x0, [fp, #-8]
    // 0xd33718: stur            x1, [fp, #-0x18]
    // 0xd3371c: StoreField: r1->field_f = r0
    //     0xd3371c: stur            w0, [x1, #0xf]
    // 0xd33720: ldur            x0, [fp, #-0x38]
    // 0xd33724: StoreField: r1->field_b = r0
    //     0xd33724: stur            w0, [x1, #0xb]
    // 0xd33728: r0 = ScaleTransition()
    //     0xd33728: bl              #0xb2851c  ; AllocateScaleTransitionStub -> ScaleTransition (size=0x20)
    // 0xd3372c: mov             x1, x0
    // 0xd33730: r0 = Closure: (double) => Matrix4 from Function '_handleScaleMatrix@589170175': static.
    //     0xd33730: add             x0, PP, #0x8f, lsl #12  ; [pp+0x8fa10] Closure: (double) => Matrix4 from Function '_handleScaleMatrix@589170175': static. (0x7f2adaa0f528)
    //     0xd33734: ldr             x0, [x0, #0xa10]
    // 0xd33738: stur            x1, [fp, #-8]
    // 0xd3373c: StoreField: r1->field_f = r0
    //     0xd3373c: stur            w0, [x1, #0xf]
    // 0xd33740: r0 = Instance_Alignment
    //     0xd33740: add             x0, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xd33744: ldr             x0, [x0, #0xb80]
    // 0xd33748: StoreField: r1->field_13 = r0
    //     0xd33748: stur            w0, [x1, #0x13]
    // 0xd3374c: ldur            x0, [fp, #-0x18]
    // 0xd33750: StoreField: r1->field_1b = r0
    //     0xd33750: stur            w0, [x1, #0x1b]
    // 0xd33754: ldur            x0, [fp, #-0x40]
    // 0xd33758: StoreField: r1->field_b = r0
    //     0xd33758: stur            w0, [x1, #0xb]
    // 0xd3375c: r0 = Align()
    //     0xd3375c: bl              #0xb281f8  ; AllocateAlignStub -> Align (size=0x1c)
    // 0xd33760: mov             x1, x0
    // 0xd33764: r0 = Instance_Alignment
    //     0xd33764: add             x0, PP, #0x19, lsl #12  ; [pp+0x197a8] Obj!Alignment@129e7d1
    //     0xd33768: ldr             x0, [x0, #0x7a8]
    // 0xd3376c: stur            x1, [fp, #-0x18]
    // 0xd33770: StoreField: r1->field_f = r0
    //     0xd33770: stur            w0, [x1, #0xf]
    // 0xd33774: ldur            x0, [fp, #-8]
    // 0xd33778: StoreField: r1->field_b = r0
    //     0xd33778: stur            w0, [x1, #0xb]
    // 0xd3377c: r0 = Padding()
    //     0xd3377c: bl              #0x8a5b28  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xd33780: mov             x1, x0
    // 0xd33784: ldur            x0, [fp, #-0x48]
    // 0xd33788: stur            x1, [fp, #-8]
    // 0xd3378c: StoreField: r1->field_f = r0
    //     0xd3378c: stur            w0, [x1, #0xf]
    // 0xd33790: ldur            x0, [fp, #-0x18]
    // 0xd33794: StoreField: r1->field_b = r0
    //     0xd33794: stur            w0, [x1, #0xb]
    // 0xd33798: r0 = SizeTransition()
    //     0xd33798: bl              #0xb28204  ; AllocateSizeTransitionStub -> SizeTransition (size=0x24)
    // 0xd3379c: mov             x2, x0
    // 0xd337a0: r0 = Instance_Axis
    //     0xd337a0: ldr             x0, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xd337a4: stur            x2, [fp, #-0x18]
    // 0xd337a8: StoreField: r2->field_f = r0
    //     0xd337a8: stur            w0, [x2, #0xf]
    // 0xd337ac: ldur            x0, [fp, #-0x30]
    // 0xd337b0: ArrayStore: r2[0] = r0  ; List_4
    //     0xd337b0: stur            w0, [x2, #0x17]
    // 0xd337b4: ldur            x0, [fp, #-8]
    // 0xd337b8: StoreField: r2->field_1f = r0
    //     0xd337b8: stur            w0, [x2, #0x1f]
    // 0xd337bc: ldur            x0, [fp, #-0x28]
    // 0xd337c0: StoreField: r2->field_b = r0
    //     0xd337c0: stur            w0, [x2, #0xb]
    // 0xd337c4: r1 = <StackParentData>
    //     0xd337c4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15858] TypeArguments: <StackParentData>
    //     0xd337c8: ldr             x1, [x1, #0x858]
    // 0xd337cc: r0 = Positioned()
    //     0xd337cc: bl              #0x8a54a4  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0xd337d0: mov             x2, x0
    // 0xd337d4: r0 = 0.000000
    //     0xd337d4: ldr             x0, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xd337d8: stur            x2, [fp, #-8]
    // 0xd337dc: StoreField: r2->field_13 = r0
    //     0xd337dc: stur            w0, [x2, #0x13]
    // 0xd337e0: ldur            x1, [fp, #-0x10]
    // 0xd337e4: ArrayStore: r2[0] = r1  ; List_4
    //     0xd337e4: stur            w1, [x2, #0x17]
    // 0xd337e8: StoreField: r2->field_1b = r0
    //     0xd337e8: stur            w0, [x2, #0x1b]
    // 0xd337ec: ldur            x0, [fp, #-0x18]
    // 0xd337f0: StoreField: r2->field_b = r0
    //     0xd337f0: stur            w0, [x2, #0xb]
    // 0xd337f4: ldur            x1, [fp, #-0x20]
    // 0xd337f8: r0 = _growToNextCapacity()
    //     0xd337f8: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xd337fc: ldur            x2, [fp, #-0x20]
    // 0xd33800: r0 = 4
    //     0xd33800: mov             x0, #4
    // 0xd33804: StoreField: r2->field_b = r0
    //     0xd33804: stur            w0, [x2, #0xb]
    // 0xd33808: LoadField: r1 = r2->field_f
    //     0xd33808: ldur            w1, [x2, #0xf]
    // 0xd3380c: DecompressPointer r1
    //     0xd3380c: add             x1, x1, HEAP, lsl #32
    // 0xd33810: ldur            x0, [fp, #-8]
    // 0xd33814: ArrayStore: r1[1] = r0  ; List_4
    //     0xd33814: add             x25, x1, #0x13
    //     0xd33818: str             w0, [x25]
    //     0xd3381c: tbz             w0, #0, #0xd33838
    //     0xd33820: ldurb           w16, [x1, #-1]
    //     0xd33824: ldurb           w17, [x0, #-1]
    //     0xd33828: and             x16, x17, x16, lsr #2
    //     0xd3382c: tst             x16, HEAP, lsr #32
    //     0xd33830: b.eq            #0xd33838
    //     0xd33834: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xd33838: b               #0xd33840
    // 0xd3383c: mov             x2, x1
    // 0xd33840: r0 = Stack()
    //     0xd33840: bl              #0xd1a854  ; AllocateStackStub -> Stack (size=0x20)
    // 0xd33844: mov             x1, x0
    // 0xd33848: r0 = Instance_AlignmentDirectional
    //     0xd33848: add             x0, PP, #0x15, lsl #12  ; [pp+0x158d8] Obj!AlignmentDirectional@129e611
    //     0xd3384c: ldr             x0, [x0, #0x8d8]
    // 0xd33850: StoreField: r1->field_f = r0
    //     0xd33850: stur            w0, [x1, #0xf]
    // 0xd33854: r0 = Instance_StackFit
    //     0xd33854: add             x0, PP, #0x15, lsl #12  ; [pp+0x158e0] Obj!StackFit@12c4221
    //     0xd33858: ldr             x0, [x0, #0x8e0]
    // 0xd3385c: ArrayStore: r1[0] = r0  ; List_4
    //     0xd3385c: stur            w0, [x1, #0x17]
    // 0xd33860: r0 = Instance_Clip
    //     0xd33860: add             x0, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xd33864: ldr             x0, [x0, #0x850]
    // 0xd33868: StoreField: r1->field_1b = r0
    //     0xd33868: stur            w0, [x1, #0x1b]
    // 0xd3386c: ldur            x0, [fp, #-0x20]
    // 0xd33870: StoreField: r1->field_b = r0
    //     0xd33870: stur            w0, [x1, #0xb]
    // 0xd33874: mov             x0, x1
    // 0xd33878: LeaveFrame
    //     0xd33878: mov             SP, fp
    //     0xd3387c: ldp             fp, lr, [SP], #0x10
    // 0xd33880: ret
    //     0xd33880: ret             
    // 0xd33884: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xd33884: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xd33888: r0 = Throw()
    //     0xd33888: bl              #0x13ddb2c  ; ThrowStub
    // 0xd3388c: brk             #0
    // 0xd33890: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd33890: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd33894: b               #0xd3350c
    // 0xd33898: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd33898: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd3389c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd3389c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd338a0: r9 = _positionFactor
    //     0xd338a0: add             x9, PP, #0x8f, lsl #12  ; [pp+0x8fa18] Field <RefreshIndicatorState._positionFactor@123083489>: late (offset: 0x24)
    //     0xd338a4: ldr             x9, [x9, #0xa18]
    // 0xd338a8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd338a8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd338ac: r9 = _scaleFactor
    //     0xd338ac: add             x9, PP, #0x8f, lsl #12  ; [pp+0x8fa20] Field <RefreshIndicatorState._scaleFactor@123083489>: late (offset: 0x28)
    //     0xd338b0: ldr             x9, [x9, #0xa20]
    // 0xd338b4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd338b4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd338b8: r9 = _positionController
    //     0xd338b8: add             x9, PP, #0x8f, lsl #12  ; [pp+0x8fa28] Field <RefreshIndicatorState._positionController@123083489>: late (offset: 0x1c)
    //     0xd338bc: ldr             x9, [x9, #0xa28]
    // 0xd338c0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd338c0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0xd338c4, size: 0x2bc
    // 0xd338c4: EnterFrame
    //     0xd338c4: stp             fp, lr, [SP, #-0x10]!
    //     0xd338c8: mov             fp, SP
    // 0xd338cc: AllocStack(0x30)
    //     0xd338cc: sub             SP, SP, #0x30
    // 0xd338d0: SetupParameters([dynamic _ /* r0 */])
    //     0xd338d0: ldr             x0, [fp, #0x20]
    //     0xd338d4: ldur            w2, [x0, #0x17]
    //     0xd338d8: add             x2, x2, HEAP, lsl #32
    //     0xd338dc: stur            x2, [fp, #-8]
    // 0xd338e0: CheckStackOverflow
    //     0xd338e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd338e4: cmp             SP, x16
    //     0xd338e8: b.ls            #0xd33b54
    // 0xd338ec: LoadField: r0 = r2->field_f
    //     0xd338ec: ldur            w0, [x2, #0xf]
    // 0xd338f0: DecompressPointer r0
    //     0xd338f0: add             x0, x0, HEAP, lsl #32
    // 0xd338f4: LoadField: r1 = r0->field_b
    //     0xd338f4: ldur            w1, [x0, #0xb]
    // 0xd338f8: DecompressPointer r1
    //     0xd338f8: add             x1, x1, HEAP, lsl #32
    // 0xd338fc: cmp             w1, NULL
    // 0xd33900: b.eq            #0xd33b5c
    // 0xd33904: ldr             x1, [fp, #0x18]
    // 0xd33908: r0 = of()
    //     0xd33908: bl              #0xd0bbf8  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0xd3390c: r1 = LoadClassIdInstr(r0)
    //     0xd3390c: ldur            x1, [x0, #-1]
    //     0xd33910: ubfx            x1, x1, #0xc, #0x14
    // 0xd33914: mov             x16, x0
    // 0xd33918: mov             x0, x1
    // 0xd3391c: mov             x1, x16
    // 0xd33920: r0 = GDT[cid_x0 + 0x1254d]()
    //     0xd33920: mov             x17, #0x254d
    //     0xd33924: movk            x17, #1, lsl #16
    //     0xd33928: add             lr, x0, x17
    //     0xd3392c: ldr             lr, [x21, lr, lsl #3]
    //     0xd33930: blr             lr
    // 0xd33934: mov             x4, x0
    // 0xd33938: ldur            x3, [fp, #-8]
    // 0xd3393c: stur            x4, [fp, #-0x10]
    // 0xd33940: LoadField: r0 = r3->field_f
    //     0xd33940: ldur            w0, [x3, #0xf]
    // 0xd33944: DecompressPointer r0
    //     0xd33944: add             x0, x0, HEAP, lsl #32
    // 0xd33948: LoadField: r1 = r0->field_b
    //     0xd33948: ldur            w1, [x0, #0xb]
    // 0xd3394c: DecompressPointer r1
    //     0xd3394c: add             x1, x1, HEAP, lsl #32
    // 0xd33950: cmp             w1, NULL
    // 0xd33954: b.eq            #0xd33b60
    // 0xd33958: LoadField: r1 = r3->field_13
    //     0xd33958: ldur            w1, [x3, #0x13]
    // 0xd3395c: DecompressPointer r1
    //     0xd3395c: add             x1, x1, HEAP, lsl #32
    // 0xd33960: tbnz            w1, #4, #0xd33974
    // 0xd33964: mov             x0, x3
    // 0xd33968: mov             x1, x4
    // 0xd3396c: r2 = Null
    //     0xd3396c: mov             x2, NULL
    // 0xd33970: b               #0xd339c8
    // 0xd33974: LoadField: r1 = r0->field_2b
    //     0xd33974: ldur            w1, [x0, #0x2b]
    // 0xd33978: DecompressPointer r1
    //     0xd33978: add             x1, x1, HEAP, lsl #32
    // 0xd3397c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd33980: cmp             w1, w16
    // 0xd33984: b.eq            #0xd33b64
    // 0xd33988: LoadField: r0 = r1->field_f
    //     0xd33988: ldur            w0, [x1, #0xf]
    // 0xd3398c: DecompressPointer r0
    //     0xd3398c: add             x0, x0, HEAP, lsl #32
    // 0xd33990: LoadField: r2 = r1->field_b
    //     0xd33990: ldur            w2, [x1, #0xb]
    // 0xd33994: DecompressPointer r2
    //     0xd33994: add             x2, x2, HEAP, lsl #32
    // 0xd33998: r1 = LoadClassIdInstr(r0)
    //     0xd33998: ldur            x1, [x0, #-1]
    //     0xd3399c: ubfx            x1, x1, #0xc, #0x14
    // 0xd339a0: mov             x16, x0
    // 0xd339a4: mov             x0, x1
    // 0xd339a8: mov             x1, x16
    // 0xd339ac: r0 = GDT[cid_x0 + 0x80ed]()
    //     0xd339ac: mov             x17, #0x80ed
    //     0xd339b0: add             lr, x0, x17
    //     0xd339b4: ldr             lr, [x21, lr, lsl #3]
    //     0xd339b8: blr             lr
    // 0xd339bc: mov             x2, x0
    // 0xd339c0: ldur            x0, [fp, #-8]
    // 0xd339c4: ldur            x1, [fp, #-0x10]
    // 0xd339c8: stur            x2, [fp, #-0x28]
    // 0xd339cc: LoadField: r3 = r0->field_f
    //     0xd339cc: ldur            w3, [x0, #0xf]
    // 0xd339d0: DecompressPointer r3
    //     0xd339d0: add             x3, x3, HEAP, lsl #32
    // 0xd339d4: LoadField: r0 = r3->field_2f
    //     0xd339d4: ldur            w0, [x3, #0x2f]
    // 0xd339d8: DecompressPointer r0
    //     0xd339d8: add             x0, x0, HEAP, lsl #32
    // 0xd339dc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd339e0: cmp             w0, w16
    // 0xd339e4: b.eq            #0xd33b70
    // 0xd339e8: stur            x0, [fp, #-0x20]
    // 0xd339ec: LoadField: r4 = r3->field_b
    //     0xd339ec: ldur            w4, [x3, #0xb]
    // 0xd339f0: DecompressPointer r4
    //     0xd339f0: add             x4, x4, HEAP, lsl #32
    // 0xd339f4: stur            x4, [fp, #-0x18]
    // 0xd339f8: cmp             w4, NULL
    // 0xd339fc: b.eq            #0xd33b7c
    // 0xd33a00: LoadField: r3 = r4->field_2b
    //     0xd33a00: ldur            w3, [x4, #0x2b]
    // 0xd33a04: DecompressPointer r3
    //     0xd33a04: add             x3, x3, HEAP, lsl #32
    // 0xd33a08: stur            x3, [fp, #-8]
    // 0xd33a0c: r0 = RefreshProgressIndicator()
    //     0xd33a0c: bl              #0xd33b80  ; AllocateRefreshProgressIndicatorStub -> RefreshProgressIndicator (size=0x58)
    // 0xd33a10: d0 = 2.000000
    //     0xd33a10: fmov            d0, #2.00000000
    // 0xd33a14: stur            x0, [fp, #-0x30]
    // 0xd33a18: StoreField: r0->field_47 = d0
    //     0xd33a18: stur            d0, [x0, #0x47]
    // 0xd33a1c: r1 = Instance_EdgeInsets
    //     0xd33a1c: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8c9b0] Obj!EdgeInsets@129cde1
    //     0xd33a20: ldr             x1, [x1, #0x9b0]
    // 0xd33a24: StoreField: r0->field_4f = r1
    //     0xd33a24: stur            w1, [x0, #0x4f]
    // 0xd33a28: r1 = Instance_EdgeInsets
    //     0xd33a28: add             x1, PP, #0x7b, lsl #12  ; [pp+0x7b208] Obj!EdgeInsets@129ce11
    //     0xd33a2c: ldr             x1, [x1, #0x208]
    // 0xd33a30: StoreField: r0->field_53 = r1
    //     0xd33a30: stur            w1, [x0, #0x53]
    // 0xd33a34: r1 = 2.500000
    //     0xd33a34: add             x1, PP, #0x7b, lsl #12  ; [pp+0x7b0b0] 2.5
    //     0xd33a38: ldr             x1, [x1, #0xb0]
    // 0xd33a3c: StoreField: r0->field_27 = r1
    //     0xd33a3c: stur            w1, [x0, #0x27]
    // 0xd33a40: r1 = Instance__ActivityIndicatorType
    //     0xd33a40: add             x1, PP, #0x22, lsl #12  ; [pp+0x22400] Obj!_ActivityIndicatorType@12c5261
    //     0xd33a44: ldr             x1, [x1, #0x400]
    // 0xd33a48: StoreField: r0->field_23 = r1
    //     0xd33a48: stur            w1, [x0, #0x23]
    // 0xd33a4c: ldur            x1, [fp, #-0x28]
    // 0xd33a50: StoreField: r0->field_b = r1
    //     0xd33a50: stur            w1, [x0, #0xb]
    // 0xd33a54: ldur            x1, [fp, #-8]
    // 0xd33a58: StoreField: r0->field_f = r1
    //     0xd33a58: stur            w1, [x0, #0xf]
    // 0xd33a5c: ldur            x1, [fp, #-0x20]
    // 0xd33a60: ArrayStore: r0[0] = r1  ; List_4
    //     0xd33a60: stur            w1, [x0, #0x17]
    // 0xd33a64: ldur            x1, [fp, #-0x10]
    // 0xd33a68: StoreField: r0->field_1b = r1
    //     0xd33a68: stur            w1, [x0, #0x1b]
    // 0xd33a6c: ldur            x1, [fp, #-0x18]
    // 0xd33a70: LoadField: r2 = r1->field_27
    //     0xd33a70: ldur            w2, [x1, #0x27]
    // 0xd33a74: DecompressPointer r2
    //     0xd33a74: add             x2, x2, HEAP, lsl #32
    // 0xd33a78: stur            x2, [fp, #-8]
    // 0xd33a7c: r0 = CupertinoActivityIndicator()
    //     0xd33a7c: bl              #0xd3253c  ; AllocateCupertinoActivityIndicatorStub -> CupertinoActivityIndicator (size=0x24)
    // 0xd33a80: mov             x2, x0
    // 0xd33a84: ldur            x0, [fp, #-8]
    // 0xd33a88: stur            x2, [fp, #-0x10]
    // 0xd33a8c: StoreField: r2->field_b = r0
    //     0xd33a8c: stur            w0, [x2, #0xb]
    // 0xd33a90: r0 = true
    //     0xd33a90: add             x0, NULL, #0x20  ; true
    // 0xd33a94: StoreField: r2->field_f = r0
    //     0xd33a94: stur            w0, [x2, #0xf]
    // 0xd33a98: d0 = 10.000000
    //     0xd33a98: fmov            d0, #10.00000000
    // 0xd33a9c: StoreField: r2->field_13 = d0
    //     0xd33a9c: stur            d0, [x2, #0x13]
    // 0xd33aa0: d0 = 1.000000
    //     0xd33aa0: fmov            d0, #1.00000000
    // 0xd33aa4: StoreField: r2->field_1b = d0
    //     0xd33aa4: stur            d0, [x2, #0x1b]
    // 0xd33aa8: ldur            x0, [fp, #-0x18]
    // 0xd33aac: LoadField: r1 = r0->field_43
    //     0xd33aac: ldur            w1, [x0, #0x43]
    // 0xd33ab0: DecompressPointer r1
    //     0xd33ab0: add             x1, x1, HEAP, lsl #32
    // 0xd33ab4: LoadField: r0 = r1->field_7
    //     0xd33ab4: ldur            x0, [x1, #7]
    // 0xd33ab8: cmp             x0, #1
    // 0xd33abc: b.gt            #0xd33b30
    // 0xd33ac0: cmp             x0, #0
    // 0xd33ac4: b.gt            #0xd33ad8
    // 0xd33ac8: ldur            x0, [fp, #-0x30]
    // 0xd33acc: LeaveFrame
    //     0xd33acc: mov             SP, fp
    //     0xd33ad0: ldp             fp, lr, [SP], #0x10
    // 0xd33ad4: ret
    //     0xd33ad4: ret             
    // 0xd33ad8: ldr             x1, [fp, #0x18]
    // 0xd33adc: r0 = of()
    //     0xd33adc: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd33ae0: LoadField: r1 = r0->field_23
    //     0xd33ae0: ldur            w1, [x0, #0x23]
    // 0xd33ae4: DecompressPointer r1
    //     0xd33ae4: add             x1, x1, HEAP, lsl #32
    // 0xd33ae8: LoadField: r0 = r1->field_7
    //     0xd33ae8: ldur            x0, [x1, #7]
    // 0xd33aec: cmp             x0, #2
    // 0xd33af0: b.gt            #0xd33b00
    // 0xd33af4: cmp             x0, #1
    // 0xd33af8: b.gt            #0xd33b10
    // 0xd33afc: b               #0xd33b20
    // 0xd33b00: cmp             x0, #4
    // 0xd33b04: b.gt            #0xd33b20
    // 0xd33b08: cmp             x0, #3
    // 0xd33b0c: b.le            #0xd33b20
    // 0xd33b10: ldur            x0, [fp, #-0x10]
    // 0xd33b14: LeaveFrame
    //     0xd33b14: mov             SP, fp
    //     0xd33b18: ldp             fp, lr, [SP], #0x10
    // 0xd33b1c: ret
    //     0xd33b1c: ret             
    // 0xd33b20: ldur            x0, [fp, #-0x30]
    // 0xd33b24: LeaveFrame
    //     0xd33b24: mov             SP, fp
    //     0xd33b28: ldp             fp, lr, [SP], #0x10
    // 0xd33b2c: ret
    //     0xd33b2c: ret             
    // 0xd33b30: r0 = Container()
    //     0xd33b30: bl              #0x8a5af8  ; AllocateContainerStub -> Container (size=0x38)
    // 0xd33b34: mov             x1, x0
    // 0xd33b38: stur            x0, [fp, #-8]
    // 0xd33b3c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd33b3c: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd33b40: r0 = Container()
    //     0xd33b40: bl              #0x8a54e0  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0xd33b44: ldur            x0, [fp, #-8]
    // 0xd33b48: LeaveFrame
    //     0xd33b48: mov             SP, fp
    //     0xd33b4c: ldp             fp, lr, [SP], #0x10
    // 0xd33b50: ret
    //     0xd33b50: ret             
    // 0xd33b54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd33b54: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd33b58: b               #0xd338ec
    // 0xd33b5c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd33b5c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd33b60: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd33b60: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd33b64: r9 = _value
    //     0xd33b64: add             x9, PP, #0x8f, lsl #12  ; [pp+0x8fa30] Field <RefreshIndicatorState._value@123083489>: late (offset: 0x2c)
    //     0xd33b68: ldr             x9, [x9, #0xa30]
    // 0xd33b6c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd33b6c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd33b70: r9 = _valueColor
    //     0xd33b70: add             x9, PP, #0x8f, lsl #12  ; [pp+0x8fa38] Field <RefreshIndicatorState._valueColor@123083489>: late (offset: 0x30)
    //     0xd33b74: ldr             x9, [x9, #0xa38]
    // 0xd33b78: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd33b78: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd33b7c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd33b7c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] bool _handleScrollNotification(dynamic, ScrollNotification) {
    // ** addr: 0xd33b8c, size: 0x3c
    // 0xd33b8c: EnterFrame
    //     0xd33b8c: stp             fp, lr, [SP, #-0x10]!
    //     0xd33b90: mov             fp, SP
    // 0xd33b94: ldr             x0, [fp, #0x18]
    // 0xd33b98: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd33b98: ldur            w1, [x0, #0x17]
    // 0xd33b9c: DecompressPointer r1
    //     0xd33b9c: add             x1, x1, HEAP, lsl #32
    // 0xd33ba0: CheckStackOverflow
    //     0xd33ba0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd33ba4: cmp             SP, x16
    //     0xd33ba8: b.ls            #0xd33bc0
    // 0xd33bac: ldr             x2, [fp, #0x10]
    // 0xd33bb0: r0 = _handleScrollNotification()
    //     0xd33bb0: bl              #0xd33bc8  ; [package:flutter/src/material/refresh_indicator.dart] RefreshIndicatorState::_handleScrollNotification
    // 0xd33bb4: LeaveFrame
    //     0xd33bb4: mov             SP, fp
    //     0xd33bb8: ldp             fp, lr, [SP], #0x10
    // 0xd33bbc: ret
    //     0xd33bbc: ret             
    // 0xd33bc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd33bc0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd33bc4: b               #0xd33bac
  }
  _ _handleScrollNotification(/* No info */) {
    // ** addr: 0xd33bc8, size: 0x5d4
    // 0xd33bc8: EnterFrame
    //     0xd33bc8: stp             fp, lr, [SP, #-0x10]!
    //     0xd33bcc: mov             fp, SP
    // 0xd33bd0: AllocStack(0x18)
    //     0xd33bd0: sub             SP, SP, #0x18
    // 0xd33bd4: SetupParameters(RefreshIndicatorState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xd33bd4: mov             x0, x1
    //     0xd33bd8: stur            x1, [fp, #-8]
    //     0xd33bdc: mov             x1, x2
    //     0xd33be0: stur            x2, [fp, #-0x10]
    // 0xd33be4: CheckStackOverflow
    //     0xd33be4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd33be8: cmp             SP, x16
    //     0xd33bec: b.ls            #0xd340ec
    // 0xd33bf0: r1 = 1
    //     0xd33bf0: mov             x1, #1
    // 0xd33bf4: r0 = AllocateContext()
    //     0xd33bf4: bl              #0x13de838  ; AllocateContextStub
    // 0xd33bf8: mov             x2, x0
    // 0xd33bfc: ldur            x0, [fp, #-8]
    // 0xd33c00: stur            x2, [fp, #-0x18]
    // 0xd33c04: StoreField: r2->field_f = r0
    //     0xd33c04: stur            w0, [x2, #0xf]
    // 0xd33c08: LoadField: r1 = r0->field_b
    //     0xd33c08: ldur            w1, [x0, #0xb]
    // 0xd33c0c: DecompressPointer r1
    //     0xd33c0c: add             x1, x1, HEAP, lsl #32
    // 0xd33c10: cmp             w1, NULL
    // 0xd33c14: b.eq            #0xd340f4
    // 0xd33c18: ldur            x1, [fp, #-0x10]
    // 0xd33c1c: r0 = defaultScrollNotificationPredicate()
    //     0xd33c1c: bl              #0xd34bb0  ; [package:flutter/src/widgets/scroll_notification.dart] ::defaultScrollNotificationPredicate
    // 0xd33c20: tbz             w0, #4, #0xd33c34
    // 0xd33c24: r0 = false
    //     0xd33c24: add             x0, NULL, #0x30  ; false
    // 0xd33c28: LeaveFrame
    //     0xd33c28: mov             SP, fp
    //     0xd33c2c: ldp             fp, lr, [SP], #0x10
    // 0xd33c30: ret
    //     0xd33c30: ret             
    // 0xd33c34: ldur            x1, [fp, #-8]
    // 0xd33c38: ldur            x2, [fp, #-0x10]
    // 0xd33c3c: r0 = _shouldStart()
    //     0xd33c3c: bl              #0xd349c4  ; [package:flutter/src/material/refresh_indicator.dart] RefreshIndicatorState::_shouldStart
    // 0xd33c40: tbnz            w0, #4, #0xd33c70
    // 0xd33c44: ldur            x2, [fp, #-0x18]
    // 0xd33c48: r1 = Function '<anonymous closure>':.
    //     0xd33c48: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8fa40] AnonymousClosure: (0xd34bc8), in [package:flutter/src/material/refresh_indicator.dart] RefreshIndicatorState::_handleScrollNotification (0xd33bc8)
    //     0xd33c4c: ldr             x1, [x1, #0xa40]
    // 0xd33c50: r0 = AllocateClosure()
    //     0xd33c50: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd33c54: ldur            x1, [fp, #-8]
    // 0xd33c58: mov             x2, x0
    // 0xd33c5c: r0 = setState()
    //     0xd33c5c: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xd33c60: r0 = false
    //     0xd33c60: add             x0, NULL, #0x30  ; false
    // 0xd33c64: LeaveFrame
    //     0xd33c64: mov             SP, fp
    //     0xd33c68: ldp             fp, lr, [SP], #0x10
    // 0xd33c6c: ret
    //     0xd33c6c: ret             
    // 0xd33c70: ldur            x2, [fp, #-0x10]
    // 0xd33c74: LoadField: r1 = r2->field_f
    //     0xd33c74: ldur            w1, [x2, #0xf]
    // 0xd33c78: DecompressPointer r1
    //     0xd33c78: add             x1, x1, HEAP, lsl #32
    // 0xd33c7c: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xd33c7c: ldur            w0, [x1, #0x17]
    // 0xd33c80: DecompressPointer r0
    //     0xd33c80: add             x0, x0, HEAP, lsl #32
    // 0xd33c84: r16 = Instance_AxisDirection
    //     0xd33c84: ldr             x16, [PP, #0x5cf0]  ; [pp+0x5cf0] Obj!AxisDirection@12c49e1
    // 0xd33c88: cmp             w0, w16
    // 0xd33c8c: b.eq            #0xd33c9c
    // 0xd33c90: r16 = Instance_AxisDirection
    //     0xd33c90: ldr             x16, [PP, #0x5ce8]  ; [pp+0x5ce8] Obj!AxisDirection@12c4a01
    // 0xd33c94: cmp             w0, w16
    // 0xd33c98: b.ne            #0xd33ca4
    // 0xd33c9c: r4 = true
    //     0xd33c9c: add             x4, NULL, #0x20  ; true
    // 0xd33ca0: b               #0xd33cc8
    // 0xd33ca4: r16 = Instance_AxisDirection
    //     0xd33ca4: ldr             x16, [PP, #0x5cf8]  ; [pp+0x5cf8] Obj!AxisDirection@12c49c1
    // 0xd33ca8: cmp             w0, w16
    // 0xd33cac: b.eq            #0xd33cbc
    // 0xd33cb0: r16 = Instance_AxisDirection
    //     0xd33cb0: ldr             x16, [PP, #0x5d00]  ; [pp+0x5d00] Obj!AxisDirection@12c49a1
    // 0xd33cb4: cmp             w0, w16
    // 0xd33cb8: b.ne            #0xd33cc4
    // 0xd33cbc: r4 = Null
    //     0xd33cbc: mov             x4, NULL
    // 0xd33cc0: b               #0xd33cc8
    // 0xd33cc4: r4 = Null
    //     0xd33cc4: mov             x4, NULL
    // 0xd33cc8: ldur            x3, [fp, #-8]
    // 0xd33ccc: LoadField: r5 = r3->field_37
    //     0xd33ccc: ldur            w5, [x3, #0x37]
    // 0xd33cd0: DecompressPointer r5
    //     0xd33cd0: add             x5, x5, HEAP, lsl #32
    // 0xd33cd4: cmp             w4, w5
    // 0xd33cd8: b.eq            #0xd33d18
    // 0xd33cdc: LoadField: r0 = r3->field_33
    //     0xd33cdc: ldur            w0, [x3, #0x33]
    // 0xd33ce0: DecompressPointer r0
    //     0xd33ce0: add             x0, x0, HEAP, lsl #32
    // 0xd33ce4: r16 = Instance_RefreshIndicatorStatus
    //     0xd33ce4: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8fa48] Obj!RefreshIndicatorStatus@12c51e1
    //     0xd33ce8: ldr             x16, [x16, #0xa48]
    // 0xd33cec: cmp             w0, w16
    // 0xd33cf0: b.eq            #0xd33d04
    // 0xd33cf4: r16 = Instance_RefreshIndicatorStatus
    //     0xd33cf4: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8fa50] Obj!RefreshIndicatorStatus@12c51c1
    //     0xd33cf8: ldr             x16, [x16, #0xa50]
    // 0xd33cfc: cmp             w0, w16
    // 0xd33d00: b.ne            #0xd340dc
    // 0xd33d04: mov             x1, x3
    // 0xd33d08: r2 = Instance_RefreshIndicatorStatus
    //     0xd33d08: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8fa58] Obj!RefreshIndicatorStatus@12c51a1
    //     0xd33d0c: ldr             x2, [x2, #0xa58]
    // 0xd33d10: r0 = _dismiss()
    //     0xd33d10: bl              #0xd34760  ; [package:flutter/src/material/refresh_indicator.dart] RefreshIndicatorState::_dismiss
    // 0xd33d14: b               #0xd340dc
    // 0xd33d18: r4 = LoadClassIdInstr(r2)
    //     0xd33d18: ldur            x4, [x2, #-1]
    //     0xd33d1c: ubfx            x4, x4, #0xc, #0x14
    // 0xd33d20: r17 = 4556
    //     0xd33d20: mov             x17, #0x11cc
    // 0xd33d24: cmp             x4, x17
    // 0xd33d28: b.ne            #0xd33eb0
    // 0xd33d2c: LoadField: r4 = r3->field_33
    //     0xd33d2c: ldur            w4, [x3, #0x33]
    // 0xd33d30: DecompressPointer r4
    //     0xd33d30: add             x4, x4, HEAP, lsl #32
    // 0xd33d34: r16 = Instance_RefreshIndicatorStatus
    //     0xd33d34: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8fa48] Obj!RefreshIndicatorStatus@12c51e1
    //     0xd33d38: ldr             x16, [x16, #0xa48]
    // 0xd33d3c: cmp             w4, w16
    // 0xd33d40: b.eq            #0xd33d54
    // 0xd33d44: r16 = Instance_RefreshIndicatorStatus
    //     0xd33d44: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8fa50] Obj!RefreshIndicatorStatus@12c51c1
    //     0xd33d48: ldr             x16, [x16, #0xa50]
    // 0xd33d4c: cmp             w4, w16
    // 0xd33d50: b.ne            #0xd33e74
    // 0xd33d54: r16 = Instance_AxisDirection
    //     0xd33d54: ldr             x16, [PP, #0x5cf0]  ; [pp+0x5cf0] Obj!AxisDirection@12c49e1
    // 0xd33d58: cmp             w0, w16
    // 0xd33d5c: b.ne            #0xd33dd8
    // 0xd33d60: LoadField: r0 = r3->field_3b
    //     0xd33d60: ldur            w0, [x3, #0x3b]
    // 0xd33d64: DecompressPointer r0
    //     0xd33d64: add             x0, x0, HEAP, lsl #32
    // 0xd33d68: cmp             w0, NULL
    // 0xd33d6c: b.eq            #0xd340f8
    // 0xd33d70: LoadField: r4 = r2->field_1b
    //     0xd33d70: ldur            w4, [x2, #0x1b]
    // 0xd33d74: DecompressPointer r4
    //     0xd33d74: add             x4, x4, HEAP, lsl #32
    // 0xd33d78: cmp             w4, NULL
    // 0xd33d7c: b.eq            #0xd340fc
    // 0xd33d80: LoadField: d0 = r0->field_7
    //     0xd33d80: ldur            d0, [x0, #7]
    // 0xd33d84: LoadField: d1 = r4->field_7
    //     0xd33d84: ldur            d1, [x4, #7]
    // 0xd33d88: fsub            d2, d0, d1
    // 0xd33d8c: r0 = inline_Allocate_Double()
    //     0xd33d8c: ldp             x0, x4, [THR, #0x60]  ; THR::top
    //     0xd33d90: add             x0, x0, #0x10
    //     0xd33d94: cmp             x4, x0
    //     0xd33d98: b.ls            #0xd34100
    //     0xd33d9c: str             x0, [THR, #0x60]  ; THR::top
    //     0xd33da0: sub             x0, x0, #0xf
    //     0xd33da4: mov             x4, #0xe19c
    //     0xd33da8: movk            x4, #3, lsl #16
    //     0xd33dac: stur            x4, [x0, #-1]
    // 0xd33db0: dmb             ishst
    // 0xd33db4: StoreField: r0->field_7 = d2
    //     0xd33db4: stur            d2, [x0, #7]
    // 0xd33db8: StoreField: r3->field_3b = r0
    //     0xd33db8: stur            w0, [x3, #0x3b]
    //     0xd33dbc: ldurb           w16, [x3, #-1]
    //     0xd33dc0: ldurb           w17, [x0, #-1]
    //     0xd33dc4: and             x16, x17, x16, lsr #2
    //     0xd33dc8: tst             x16, HEAP, lsr #32
    //     0xd33dcc: b.eq            #0xd33dd4
    //     0xd33dd0: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xd33dd4: b               #0xd33e58
    // 0xd33dd8: r16 = Instance_AxisDirection
    //     0xd33dd8: ldr             x16, [PP, #0x5ce8]  ; [pp+0x5ce8] Obj!AxisDirection@12c4a01
    // 0xd33ddc: cmp             w0, w16
    // 0xd33de0: b.ne            #0xd33e58
    // 0xd33de4: LoadField: r0 = r3->field_3b
    //     0xd33de4: ldur            w0, [x3, #0x3b]
    // 0xd33de8: DecompressPointer r0
    //     0xd33de8: add             x0, x0, HEAP, lsl #32
    // 0xd33dec: cmp             w0, NULL
    // 0xd33df0: b.eq            #0xd34120
    // 0xd33df4: LoadField: r4 = r2->field_1b
    //     0xd33df4: ldur            w4, [x2, #0x1b]
    // 0xd33df8: DecompressPointer r4
    //     0xd33df8: add             x4, x4, HEAP, lsl #32
    // 0xd33dfc: cmp             w4, NULL
    // 0xd33e00: b.eq            #0xd34124
    // 0xd33e04: LoadField: d0 = r0->field_7
    //     0xd33e04: ldur            d0, [x0, #7]
    // 0xd33e08: LoadField: d1 = r4->field_7
    //     0xd33e08: ldur            d1, [x4, #7]
    // 0xd33e0c: fadd            d2, d0, d1
    // 0xd33e10: r0 = inline_Allocate_Double()
    //     0xd33e10: ldp             x0, x4, [THR, #0x60]  ; THR::top
    //     0xd33e14: add             x0, x0, #0x10
    //     0xd33e18: cmp             x4, x0
    //     0xd33e1c: b.ls            #0xd34128
    //     0xd33e20: str             x0, [THR, #0x60]  ; THR::top
    //     0xd33e24: sub             x0, x0, #0xf
    //     0xd33e28: mov             x4, #0xe19c
    //     0xd33e2c: movk            x4, #3, lsl #16
    //     0xd33e30: stur            x4, [x0, #-1]
    // 0xd33e34: dmb             ishst
    // 0xd33e38: StoreField: r0->field_7 = d2
    //     0xd33e38: stur            d2, [x0, #7]
    // 0xd33e3c: StoreField: r3->field_3b = r0
    //     0xd33e3c: stur            w0, [x3, #0x3b]
    //     0xd33e40: ldurb           w16, [x3, #-1]
    //     0xd33e44: ldurb           w17, [x0, #-1]
    //     0xd33e48: and             x16, x17, x16, lsr #2
    //     0xd33e4c: tst             x16, HEAP, lsr #32
    //     0xd33e50: b.eq            #0xd33e58
    //     0xd33e54: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xd33e58: LoadField: r0 = r1->field_13
    //     0xd33e58: ldur            w0, [x1, #0x13]
    // 0xd33e5c: DecompressPointer r0
    //     0xd33e5c: add             x0, x0, HEAP, lsl #32
    // 0xd33e60: cmp             w0, NULL
    // 0xd33e64: b.eq            #0xd34148
    // 0xd33e68: LoadField: d0 = r0->field_7
    //     0xd33e68: ldur            d0, [x0, #7]
    // 0xd33e6c: mov             x1, x3
    // 0xd33e70: r0 = _checkDragOffset()
    //     0xd33e70: bl              #0xd344bc  ; [package:flutter/src/material/refresh_indicator.dart] RefreshIndicatorState::_checkDragOffset
    // 0xd33e74: ldur            x2, [fp, #-8]
    // 0xd33e78: LoadField: r0 = r2->field_33
    //     0xd33e78: ldur            w0, [x2, #0x33]
    // 0xd33e7c: DecompressPointer r0
    //     0xd33e7c: add             x0, x0, HEAP, lsl #32
    // 0xd33e80: r16 = Instance_RefreshIndicatorStatus
    //     0xd33e80: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8fa50] Obj!RefreshIndicatorStatus@12c51c1
    //     0xd33e84: ldr             x16, [x16, #0xa50]
    // 0xd33e88: cmp             w0, w16
    // 0xd33e8c: b.ne            #0xd340dc
    // 0xd33e90: ldur            x3, [fp, #-0x10]
    // 0xd33e94: ArrayLoad: r0 = r3[0]  ; List_4
    //     0xd33e94: ldur            w0, [x3, #0x17]
    // 0xd33e98: DecompressPointer r0
    //     0xd33e98: add             x0, x0, HEAP, lsl #32
    // 0xd33e9c: cmp             w0, NULL
    // 0xd33ea0: b.ne            #0xd340dc
    // 0xd33ea4: mov             x1, x2
    // 0xd33ea8: r0 = _show()
    //     0xd33ea8: bl              #0xd341cc  ; [package:flutter/src/material/refresh_indicator.dart] RefreshIndicatorState::_show
    // 0xd33eac: b               #0xd340dc
    // 0xd33eb0: mov             x16, x2
    // 0xd33eb4: mov             x2, x3
    // 0xd33eb8: mov             x3, x16
    // 0xd33ebc: r17 = 4555
    //     0xd33ebc: mov             x17, #0x11cb
    // 0xd33ec0: cmp             x4, x17
    // 0xd33ec4: b.ne            #0xd33ff4
    // 0xd33ec8: LoadField: r4 = r2->field_33
    //     0xd33ec8: ldur            w4, [x2, #0x33]
    // 0xd33ecc: DecompressPointer r4
    //     0xd33ecc: add             x4, x4, HEAP, lsl #32
    // 0xd33ed0: r16 = Instance_RefreshIndicatorStatus
    //     0xd33ed0: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8fa48] Obj!RefreshIndicatorStatus@12c51e1
    //     0xd33ed4: ldr             x16, [x16, #0xa48]
    // 0xd33ed8: cmp             w4, w16
    // 0xd33edc: b.eq            #0xd33ef0
    // 0xd33ee0: r16 = Instance_RefreshIndicatorStatus
    //     0xd33ee0: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8fa50] Obj!RefreshIndicatorStatus@12c51c1
    //     0xd33ee4: ldr             x16, [x16, #0xa50]
    // 0xd33ee8: cmp             w4, w16
    // 0xd33eec: b.ne            #0xd340dc
    // 0xd33ef0: r16 = Instance_AxisDirection
    //     0xd33ef0: ldr             x16, [PP, #0x5cf0]  ; [pp+0x5cf0] Obj!AxisDirection@12c49e1
    // 0xd33ef4: cmp             w0, w16
    // 0xd33ef8: b.ne            #0xd33f64
    // 0xd33efc: LoadField: r0 = r2->field_3b
    //     0xd33efc: ldur            w0, [x2, #0x3b]
    // 0xd33f00: DecompressPointer r0
    //     0xd33f00: add             x0, x0, HEAP, lsl #32
    // 0xd33f04: cmp             w0, NULL
    // 0xd33f08: b.eq            #0xd3414c
    // 0xd33f0c: LoadField: d0 = r3->field_1b
    //     0xd33f0c: ldur            d0, [x3, #0x1b]
    // 0xd33f10: LoadField: d1 = r0->field_7
    //     0xd33f10: ldur            d1, [x0, #7]
    // 0xd33f14: fsub            d2, d1, d0
    // 0xd33f18: r0 = inline_Allocate_Double()
    //     0xd33f18: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0xd33f1c: add             x0, x0, #0x10
    //     0xd33f20: cmp             x3, x0
    //     0xd33f24: b.ls            #0xd34150
    //     0xd33f28: str             x0, [THR, #0x60]  ; THR::top
    //     0xd33f2c: sub             x0, x0, #0xf
    //     0xd33f30: mov             x3, #0xe19c
    //     0xd33f34: movk            x3, #3, lsl #16
    //     0xd33f38: stur            x3, [x0, #-1]
    // 0xd33f3c: dmb             ishst
    // 0xd33f40: StoreField: r0->field_7 = d2
    //     0xd33f40: stur            d2, [x0, #7]
    // 0xd33f44: StoreField: r2->field_3b = r0
    //     0xd33f44: stur            w0, [x2, #0x3b]
    //     0xd33f48: ldurb           w16, [x2, #-1]
    //     0xd33f4c: ldurb           w17, [x0, #-1]
    //     0xd33f50: and             x16, x17, x16, lsr #2
    //     0xd33f54: tst             x16, HEAP, lsr #32
    //     0xd33f58: b.eq            #0xd33f60
    //     0xd33f5c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd33f60: b               #0xd33fd4
    // 0xd33f64: r16 = Instance_AxisDirection
    //     0xd33f64: ldr             x16, [PP, #0x5ce8]  ; [pp+0x5ce8] Obj!AxisDirection@12c4a01
    // 0xd33f68: cmp             w0, w16
    // 0xd33f6c: b.ne            #0xd33fd4
    // 0xd33f70: LoadField: r0 = r2->field_3b
    //     0xd33f70: ldur            w0, [x2, #0x3b]
    // 0xd33f74: DecompressPointer r0
    //     0xd33f74: add             x0, x0, HEAP, lsl #32
    // 0xd33f78: cmp             w0, NULL
    // 0xd33f7c: b.eq            #0xd34168
    // 0xd33f80: LoadField: d0 = r3->field_1b
    //     0xd33f80: ldur            d0, [x3, #0x1b]
    // 0xd33f84: LoadField: d1 = r0->field_7
    //     0xd33f84: ldur            d1, [x0, #7]
    // 0xd33f88: fadd            d2, d1, d0
    // 0xd33f8c: r0 = inline_Allocate_Double()
    //     0xd33f8c: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0xd33f90: add             x0, x0, #0x10
    //     0xd33f94: cmp             x3, x0
    //     0xd33f98: b.ls            #0xd3416c
    //     0xd33f9c: str             x0, [THR, #0x60]  ; THR::top
    //     0xd33fa0: sub             x0, x0, #0xf
    //     0xd33fa4: mov             x3, #0xe19c
    //     0xd33fa8: movk            x3, #3, lsl #16
    //     0xd33fac: stur            x3, [x0, #-1]
    // 0xd33fb0: dmb             ishst
    // 0xd33fb4: StoreField: r0->field_7 = d2
    //     0xd33fb4: stur            d2, [x0, #7]
    // 0xd33fb8: StoreField: r2->field_3b = r0
    //     0xd33fb8: stur            w0, [x2, #0x3b]
    //     0xd33fbc: ldurb           w16, [x2, #-1]
    //     0xd33fc0: ldurb           w17, [x0, #-1]
    //     0xd33fc4: and             x16, x17, x16, lsr #2
    //     0xd33fc8: tst             x16, HEAP, lsr #32
    //     0xd33fcc: b.eq            #0xd33fd4
    //     0xd33fd0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd33fd4: LoadField: r0 = r1->field_13
    //     0xd33fd4: ldur            w0, [x1, #0x13]
    // 0xd33fd8: DecompressPointer r0
    //     0xd33fd8: add             x0, x0, HEAP, lsl #32
    // 0xd33fdc: cmp             w0, NULL
    // 0xd33fe0: b.eq            #0xd34184
    // 0xd33fe4: LoadField: d0 = r0->field_7
    //     0xd33fe4: ldur            d0, [x0, #7]
    // 0xd33fe8: mov             x1, x2
    // 0xd33fec: r0 = _checkDragOffset()
    //     0xd33fec: bl              #0xd344bc  ; [package:flutter/src/material/refresh_indicator.dart] RefreshIndicatorState::_checkDragOffset
    // 0xd33ff0: b               #0xd340dc
    // 0xd33ff4: r17 = 4554
    //     0xd33ff4: mov             x17, #0x11ca
    // 0xd33ff8: cmp             x4, x17
    // 0xd33ffc: b.ne            #0xd340dc
    // 0xd34000: LoadField: r0 = r2->field_33
    //     0xd34000: ldur            w0, [x2, #0x33]
    // 0xd34004: DecompressPointer r0
    //     0xd34004: add             x0, x0, HEAP, lsl #32
    // 0xd34008: r16 = Instance_RefreshIndicatorStatus
    //     0xd34008: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8fa50] Obj!RefreshIndicatorStatus@12c51c1
    //     0xd3400c: ldr             x16, [x16, #0xa50]
    // 0xd34010: cmp             w0, w16
    // 0xd34014: b.ne            #0xd34070
    // 0xd34018: d0 = 1.000000
    //     0xd34018: fmov            d0, #1.00000000
    // 0xd3401c: LoadField: r0 = r2->field_1b
    //     0xd3401c: ldur            w0, [x2, #0x1b]
    // 0xd34020: DecompressPointer r0
    //     0xd34020: add             x0, x0, HEAP, lsl #32
    // 0xd34024: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd34028: cmp             w0, w16
    // 0xd3402c: b.eq            #0xd34188
    // 0xd34030: LoadField: r1 = r0->field_37
    //     0xd34030: ldur            w1, [x0, #0x37]
    // 0xd34034: DecompressPointer r1
    //     0xd34034: add             x1, x1, HEAP, lsl #32
    // 0xd34038: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3403c: cmp             w1, w16
    // 0xd34040: b.eq            #0xd34194
    // 0xd34044: LoadField: d1 = r1->field_7
    //     0xd34044: ldur            d1, [x1, #7]
    // 0xd34048: fcmp            d0, d1
    // 0xd3404c: b.le            #0xd34064
    // 0xd34050: mov             x1, x2
    // 0xd34054: r2 = Instance_RefreshIndicatorStatus
    //     0xd34054: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8fa58] Obj!RefreshIndicatorStatus@12c51a1
    //     0xd34058: ldr             x2, [x2, #0xa58]
    // 0xd3405c: r0 = _dismiss()
    //     0xd3405c: bl              #0xd34760  ; [package:flutter/src/material/refresh_indicator.dart] RefreshIndicatorState::_dismiss
    // 0xd34060: b               #0xd340dc
    // 0xd34064: mov             x1, x2
    // 0xd34068: r0 = _show()
    //     0xd34068: bl              #0xd341cc  ; [package:flutter/src/material/refresh_indicator.dart] RefreshIndicatorState::_show
    // 0xd3406c: b               #0xd340dc
    // 0xd34070: r16 = Instance_RefreshIndicatorStatus
    //     0xd34070: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8fa48] Obj!RefreshIndicatorStatus@12c51e1
    //     0xd34074: ldr             x16, [x16, #0xa48]
    // 0xd34078: cmp             w0, w16
    // 0xd3407c: b.ne            #0xd34094
    // 0xd34080: mov             x1, x2
    // 0xd34084: r2 = Instance_RefreshIndicatorStatus
    //     0xd34084: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8fa58] Obj!RefreshIndicatorStatus@12c51a1
    //     0xd34088: ldr             x2, [x2, #0xa58]
    // 0xd3408c: r0 = _dismiss()
    //     0xd3408c: bl              #0xd34760  ; [package:flutter/src/material/refresh_indicator.dart] RefreshIndicatorState::_dismiss
    // 0xd34090: b               #0xd340dc
    // 0xd34094: r16 = Instance_RefreshIndicatorStatus
    //     0xd34094: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8fa58] Obj!RefreshIndicatorStatus@12c51a1
    //     0xd34098: ldr             x16, [x16, #0xa58]
    // 0xd3409c: cmp             w0, w16
    // 0xd340a0: b.eq            #0xd340dc
    // 0xd340a4: r16 = Instance_RefreshIndicatorStatus
    //     0xd340a4: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8fa00] Obj!RefreshIndicatorStatus@12c5141
    //     0xd340a8: ldr             x16, [x16, #0xa00]
    // 0xd340ac: cmp             w0, w16
    // 0xd340b0: b.eq            #0xd340dc
    // 0xd340b4: r16 = Instance_RefreshIndicatorStatus
    //     0xd340b4: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8f9f8] Obj!RefreshIndicatorStatus@12c5161
    //     0xd340b8: ldr             x16, [x16, #0x9f8]
    // 0xd340bc: cmp             w0, w16
    // 0xd340c0: b.eq            #0xd340dc
    // 0xd340c4: r16 = Instance_RefreshIndicatorStatus
    //     0xd340c4: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8fa60] Obj!RefreshIndicatorStatus@12c5181
    //     0xd340c8: ldr             x16, [x16, #0xa60]
    // 0xd340cc: cmp             w0, w16
    // 0xd340d0: b.eq            #0xd340dc
    // 0xd340d4: cmp             w0, NULL
    // 0xd340d8: b.eq            #0xd340dc
    // 0xd340dc: r0 = false
    //     0xd340dc: add             x0, NULL, #0x30  ; false
    // 0xd340e0: LeaveFrame
    //     0xd340e0: mov             SP, fp
    //     0xd340e4: ldp             fp, lr, [SP], #0x10
    // 0xd340e8: ret
    //     0xd340e8: ret             
    // 0xd340ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd340ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd340f0: b               #0xd33bf0
    // 0xd340f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd340f4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd340f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd340f8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd340fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd340fc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd34100: SaveReg d2
    //     0xd34100: str             q2, [SP, #-0x10]!
    // 0xd34104: stp             x2, x3, [SP, #-0x10]!
    // 0xd34108: SaveReg r1
    //     0xd34108: str             x1, [SP, #-8]!
    // 0xd3410c: r0 = AllocateDouble()
    //     0xd3410c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd34110: RestoreReg r1
    //     0xd34110: ldr             x1, [SP], #8
    // 0xd34114: ldp             x2, x3, [SP], #0x10
    // 0xd34118: RestoreReg d2
    //     0xd34118: ldr             q2, [SP], #0x10
    // 0xd3411c: b               #0xd33db4
    // 0xd34120: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd34120: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd34124: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd34124: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd34128: SaveReg d2
    //     0xd34128: str             q2, [SP, #-0x10]!
    // 0xd3412c: stp             x2, x3, [SP, #-0x10]!
    // 0xd34130: SaveReg r1
    //     0xd34130: str             x1, [SP, #-8]!
    // 0xd34134: r0 = AllocateDouble()
    //     0xd34134: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd34138: RestoreReg r1
    //     0xd34138: ldr             x1, [SP], #8
    // 0xd3413c: ldp             x2, x3, [SP], #0x10
    // 0xd34140: RestoreReg d2
    //     0xd34140: ldr             q2, [SP], #0x10
    // 0xd34144: b               #0xd33e38
    // 0xd34148: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd34148: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd3414c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd3414c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd34150: SaveReg d2
    //     0xd34150: str             q2, [SP, #-0x10]!
    // 0xd34154: stp             x1, x2, [SP, #-0x10]!
    // 0xd34158: r0 = AllocateDouble()
    //     0xd34158: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd3415c: ldp             x1, x2, [SP], #0x10
    // 0xd34160: RestoreReg d2
    //     0xd34160: ldr             q2, [SP], #0x10
    // 0xd34164: b               #0xd33f40
    // 0xd34168: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd34168: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd3416c: SaveReg d2
    //     0xd3416c: str             q2, [SP, #-0x10]!
    // 0xd34170: stp             x1, x2, [SP, #-0x10]!
    // 0xd34174: r0 = AllocateDouble()
    //     0xd34174: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd34178: ldp             x1, x2, [SP], #0x10
    // 0xd3417c: RestoreReg d2
    //     0xd3417c: ldr             q2, [SP], #0x10
    // 0xd34180: b               #0xd33fb4
    // 0xd34184: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd34184: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd34188: r9 = _positionController
    //     0xd34188: add             x9, PP, #0x8f, lsl #12  ; [pp+0x8fa28] Field <RefreshIndicatorState._positionController@123083489>: late (offset: 0x1c)
    //     0xd3418c: ldr             x9, [x9, #0xa28]
    // 0xd34190: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xd34190: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xd34194: r9 = _value
    //     0xd34194: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0xd34198: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xd34198: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
  }
  _ _show(/* No info */) {
    // ** addr: 0xd341cc, size: 0x130
    // 0xd341cc: EnterFrame
    //     0xd341cc: stp             fp, lr, [SP, #-0x10]!
    //     0xd341d0: mov             fp, SP
    // 0xd341d4: AllocStack(0x30)
    //     0xd341d4: sub             SP, SP, #0x30
    // 0xd341d8: SetupParameters(RefreshIndicatorState this /* r1 => r1, fp-0x8 */)
    //     0xd341d8: stur            x1, [fp, #-8]
    // 0xd341dc: CheckStackOverflow
    //     0xd341dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd341e0: cmp             SP, x16
    //     0xd341e4: b.ls            #0xd342e4
    // 0xd341e8: r1 = 2
    //     0xd341e8: mov             x1, #2
    // 0xd341ec: r0 = AllocateContext()
    //     0xd341ec: bl              #0x13de838  ; AllocateContextStub
    // 0xd341f0: mov             x2, x0
    // 0xd341f4: ldur            x0, [fp, #-8]
    // 0xd341f8: stur            x2, [fp, #-0x10]
    // 0xd341fc: StoreField: r2->field_f = r0
    //     0xd341fc: stur            w0, [x2, #0xf]
    // 0xd34200: r1 = <void?>
    //     0xd34200: ldr             x1, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xd34204: r0 = _Future()
    //     0xd34204: bl              #0x7f5dd4  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0xd34208: stur            x0, [fp, #-0x18]
    // 0xd3420c: StoreField: r0->field_b = rZR
    //     0xd3420c: stur            xzr, [x0, #0xb]
    // 0xd34210: r0 = LoadStaticField(0x364)
    //     0xd34210: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xd34214: ldr             x0, [x0, #0x6c8]
    // 0xd34218: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3421c: cmp             w0, w16
    // 0xd34220: b.ne            #0xd3422c
    // 0xd34224: r2 = _current
    //     0xd34224: ldr             x2, [PP, #0x2c0]  ; [pp+0x2c0] Field <Zone._current@5048458>: static late (offset: 0x364)
    // 0xd34228: r0 = InitLateStaticField()
    //     0xd34228: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0xd3422c: mov             x1, x0
    // 0xd34230: ldur            x0, [fp, #-0x18]
    // 0xd34234: StoreField: r0->field_13 = r1
    //     0xd34234: stur            w1, [x0, #0x13]
    // 0xd34238: r1 = <void?>
    //     0xd34238: ldr             x1, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xd3423c: r0 = _AsyncCompleter()
    //     0xd3423c: bl              #0x7f5dc8  ; Allocate_AsyncCompleterStub -> _AsyncCompleter<X0> (size=0x10)
    // 0xd34240: mov             x1, x0
    // 0xd34244: ldur            x0, [fp, #-0x18]
    // 0xd34248: StoreField: r1->field_b = r0
    //     0xd34248: stur            w0, [x1, #0xb]
    // 0xd3424c: ldur            x2, [fp, #-0x10]
    // 0xd34250: StoreField: r2->field_13 = r1
    //     0xd34250: stur            w1, [x2, #0x13]
    // 0xd34254: ldur            x0, [fp, #-8]
    // 0xd34258: r1 = Instance_RefreshIndicatorStatus
    //     0xd34258: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8fa60] Obj!RefreshIndicatorStatus@12c5181
    //     0xd3425c: ldr             x1, [x1, #0xa60]
    // 0xd34260: StoreField: r0->field_33 = r1
    //     0xd34260: stur            w1, [x0, #0x33]
    // 0xd34264: LoadField: r1 = r0->field_b
    //     0xd34264: ldur            w1, [x0, #0xb]
    // 0xd34268: DecompressPointer r1
    //     0xd34268: add             x1, x1, HEAP, lsl #32
    // 0xd3426c: cmp             w1, NULL
    // 0xd34270: b.eq            #0xd342ec
    // 0xd34274: LoadField: r1 = r0->field_1b
    //     0xd34274: ldur            w1, [x0, #0x1b]
    // 0xd34278: DecompressPointer r1
    //     0xd34278: add             x1, x1, HEAP, lsl #32
    // 0xd3427c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd34280: cmp             w1, w16
    // 0xd34284: b.eq            #0xd342f0
    // 0xd34288: r16 = Instance_Duration
    //     0xd34288: add             x16, PP, #0x15, lsl #12  ; [pp+0x15238] Obj!Duration@12c8a31
    //     0xd3428c: ldr             x16, [x16, #0x238]
    // 0xd34290: str             x16, [SP]
    // 0xd34294: d0 = 0.666667
    //     0xd34294: add             x17, PP, #0x8f, lsl #12  ; [pp+0x8fa68] IMM: double(0.6666666666666666) from 0x3fe5555555555555
    //     0xd34298: ldr             d0, [x17, #0xa68]
    // 0xd3429c: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0xd3429c: add             x4, PP, #0x15, lsl #12  ; [pp+0x155a0] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0xd342a0: ldr             x4, [x4, #0x5a0]
    // 0xd342a4: r0 = animateTo()
    //     0xd342a4: bl              #0x866084  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::animateTo
    // 0xd342a8: ldur            x2, [fp, #-0x10]
    // 0xd342ac: r1 = Function '<anonymous closure>':.
    //     0xd342ac: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8fa70] AnonymousClosure: (0xd342fc), in [package:flutter/src/material/refresh_indicator.dart] RefreshIndicatorState::_show (0xd341cc)
    //     0xd342b0: ldr             x1, [x1, #0xa70]
    // 0xd342b4: stur            x0, [fp, #-8]
    // 0xd342b8: r0 = AllocateClosure()
    //     0xd342b8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd342bc: r16 = <void?>
    //     0xd342bc: ldr             x16, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xd342c0: ldur            lr, [fp, #-8]
    // 0xd342c4: stp             lr, x16, [SP, #8]
    // 0xd342c8: str             x0, [SP]
    // 0xd342cc: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xd342cc: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xd342d0: r0 = then()
    //     0xd342d0: bl              #0x13083d8  ; [package:flutter/src/scheduler/ticker.dart] TickerFuture::then
    // 0xd342d4: r0 = Null
    //     0xd342d4: mov             x0, NULL
    // 0xd342d8: LeaveFrame
    //     0xd342d8: mov             SP, fp
    //     0xd342dc: ldp             fp, lr, [SP], #0x10
    // 0xd342e0: ret
    //     0xd342e0: ret             
    // 0xd342e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd342e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd342e8: b               #0xd341e8
    // 0xd342ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd342ec: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd342f0: r9 = _positionController
    //     0xd342f0: add             x9, PP, #0x8f, lsl #12  ; [pp+0x8fa28] Field <RefreshIndicatorState._positionController@123083489>: late (offset: 0x1c)
    //     0xd342f4: ldr             x9, [x9, #0xa28]
    // 0xd342f8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd342f8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Null <anonymous closure>(dynamic, void) {
    // ** addr: 0xd342fc, size: 0x100
    // 0xd342fc: EnterFrame
    //     0xd342fc: stp             fp, lr, [SP, #-0x10]!
    //     0xd34300: mov             fp, SP
    // 0xd34304: AllocStack(0x18)
    //     0xd34304: sub             SP, SP, #0x18
    // 0xd34308: SetupParameters([dynamic _ /* r0 */])
    //     0xd34308: ldr             x0, [fp, #0x18]
    //     0xd3430c: ldur            w3, [x0, #0x17]
    //     0xd34310: add             x3, x3, HEAP, lsl #32
    //     0xd34314: stur            x3, [fp, #-0x10]
    // 0xd34318: CheckStackOverflow
    //     0xd34318: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd3431c: cmp             SP, x16
    //     0xd34320: b.ls            #0xd343f0
    // 0xd34324: LoadField: r0 = r3->field_f
    //     0xd34324: ldur            w0, [x3, #0xf]
    // 0xd34328: DecompressPointer r0
    //     0xd34328: add             x0, x0, HEAP, lsl #32
    // 0xd3432c: stur            x0, [fp, #-8]
    // 0xd34330: LoadField: r1 = r0->field_f
    //     0xd34330: ldur            w1, [x0, #0xf]
    // 0xd34334: DecompressPointer r1
    //     0xd34334: add             x1, x1, HEAP, lsl #32
    // 0xd34338: cmp             w1, NULL
    // 0xd3433c: b.eq            #0xd343e0
    // 0xd34340: LoadField: r1 = r0->field_33
    //     0xd34340: ldur            w1, [x0, #0x33]
    // 0xd34344: DecompressPointer r1
    //     0xd34344: add             x1, x1, HEAP, lsl #32
    // 0xd34348: r16 = Instance_RefreshIndicatorStatus
    //     0xd34348: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8fa60] Obj!RefreshIndicatorStatus@12c5181
    //     0xd3434c: ldr             x16, [x16, #0xa60]
    // 0xd34350: cmp             w1, w16
    // 0xd34354: b.ne            #0xd343e0
    // 0xd34358: mov             x2, x3
    // 0xd3435c: r1 = Function '<anonymous closure>':.
    //     0xd3435c: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8fa78] AnonymousClosure: (0xd34494), in [package:flutter/src/material/refresh_indicator.dart] RefreshIndicatorState::_show (0xd341cc)
    //     0xd34360: ldr             x1, [x1, #0xa78]
    // 0xd34364: r0 = AllocateClosure()
    //     0xd34364: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd34368: ldur            x1, [fp, #-8]
    // 0xd3436c: mov             x2, x0
    // 0xd34370: r0 = setState()
    //     0xd34370: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xd34374: ldur            x2, [fp, #-0x10]
    // 0xd34378: LoadField: r0 = r2->field_f
    //     0xd34378: ldur            w0, [x2, #0xf]
    // 0xd3437c: DecompressPointer r0
    //     0xd3437c: add             x0, x0, HEAP, lsl #32
    // 0xd34380: LoadField: r1 = r0->field_b
    //     0xd34380: ldur            w1, [x0, #0xb]
    // 0xd34384: DecompressPointer r1
    //     0xd34384: add             x1, x1, HEAP, lsl #32
    // 0xd34388: cmp             w1, NULL
    // 0xd3438c: b.eq            #0xd343f8
    // 0xd34390: LoadField: r0 = r1->field_1f
    //     0xd34390: ldur            w0, [x1, #0x1f]
    // 0xd34394: DecompressPointer r0
    //     0xd34394: add             x0, x0, HEAP, lsl #32
    // 0xd34398: str             x0, [SP]
    // 0xd3439c: ClosureCall
    //     0xd3439c: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xd343a0: ldur            x2, [x0, #0x1f]
    //     0xd343a4: blr             x2
    // 0xd343a8: ldur            x2, [fp, #-0x10]
    // 0xd343ac: r1 = Function '<anonymous closure>':.
    //     0xd343ac: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8fa80] AnonymousClosure: (0xd343fc), in [package:flutter/src/material/refresh_indicator.dart] RefreshIndicatorState::_show (0xd341cc)
    //     0xd343b0: ldr             x1, [x1, #0xa80]
    // 0xd343b4: stur            x0, [fp, #-8]
    // 0xd343b8: r0 = AllocateClosure()
    //     0xd343b8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd343bc: ldur            x1, [fp, #-8]
    // 0xd343c0: r2 = LoadClassIdInstr(r1)
    //     0xd343c0: ldur            x2, [x1, #-1]
    //     0xd343c4: ubfx            x2, x2, #0xc, #0x14
    // 0xd343c8: mov             x16, x0
    // 0xd343cc: mov             x0, x2
    // 0xd343d0: mov             x2, x16
    // 0xd343d4: r0 = GDT[cid_x0 + -0xfe1]()
    //     0xd343d4: sub             lr, x0, #0xfe1
    //     0xd343d8: ldr             lr, [x21, lr, lsl #3]
    //     0xd343dc: blr             lr
    // 0xd343e0: r0 = Null
    //     0xd343e0: mov             x0, NULL
    // 0xd343e4: LeaveFrame
    //     0xd343e4: mov             SP, fp
    //     0xd343e8: ldp             fp, lr, [SP], #0x10
    // 0xd343ec: ret
    //     0xd343ec: ret             
    // 0xd343f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd343f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd343f4: b               #0xd34324
    // 0xd343f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd343f8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Null <anonymous closure>(dynamic) {
    // ** addr: 0xd343fc, size: 0x98
    // 0xd343fc: EnterFrame
    //     0xd343fc: stp             fp, lr, [SP, #-0x10]!
    //     0xd34400: mov             fp, SP
    // 0xd34404: AllocStack(0x8)
    //     0xd34404: sub             SP, SP, #8
    // 0xd34408: SetupParameters([dynamic _ /* r0 */])
    //     0xd34408: ldr             x0, [fp, #0x10]
    //     0xd3440c: ldur            w2, [x0, #0x17]
    //     0xd34410: add             x2, x2, HEAP, lsl #32
    //     0xd34414: stur            x2, [fp, #-8]
    // 0xd34418: CheckStackOverflow
    //     0xd34418: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd3441c: cmp             SP, x16
    //     0xd34420: b.ls            #0xd3448c
    // 0xd34424: LoadField: r0 = r2->field_f
    //     0xd34424: ldur            w0, [x2, #0xf]
    // 0xd34428: DecompressPointer r0
    //     0xd34428: add             x0, x0, HEAP, lsl #32
    // 0xd3442c: LoadField: r1 = r0->field_f
    //     0xd3442c: ldur            w1, [x0, #0xf]
    // 0xd34430: DecompressPointer r1
    //     0xd34430: add             x1, x1, HEAP, lsl #32
    // 0xd34434: cmp             w1, NULL
    // 0xd34438: b.eq            #0xd3447c
    // 0xd3443c: LoadField: r1 = r0->field_33
    //     0xd3443c: ldur            w1, [x0, #0x33]
    // 0xd34440: DecompressPointer r1
    //     0xd34440: add             x1, x1, HEAP, lsl #32
    // 0xd34444: r16 = Instance_RefreshIndicatorStatus
    //     0xd34444: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8f9f8] Obj!RefreshIndicatorStatus@12c5161
    //     0xd34448: ldr             x16, [x16, #0x9f8]
    // 0xd3444c: cmp             w1, w16
    // 0xd34450: b.ne            #0xd3447c
    // 0xd34454: LoadField: r1 = r2->field_13
    //     0xd34454: ldur            w1, [x2, #0x13]
    // 0xd34458: DecompressPointer r1
    //     0xd34458: add             x1, x1, HEAP, lsl #32
    // 0xd3445c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd3445c: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd34460: r0 = complete()
    //     0xd34460: bl              #0x128a5ec  ; [dart:async] _AsyncCompleter::complete
    // 0xd34464: ldur            x0, [fp, #-8]
    // 0xd34468: LoadField: r1 = r0->field_f
    //     0xd34468: ldur            w1, [x0, #0xf]
    // 0xd3446c: DecompressPointer r1
    //     0xd3446c: add             x1, x1, HEAP, lsl #32
    // 0xd34470: r2 = Instance_RefreshIndicatorStatus
    //     0xd34470: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8fa00] Obj!RefreshIndicatorStatus@12c5141
    //     0xd34474: ldr             x2, [x2, #0xa00]
    // 0xd34478: r0 = _dismiss()
    //     0xd34478: bl              #0xd34760  ; [package:flutter/src/material/refresh_indicator.dart] RefreshIndicatorState::_dismiss
    // 0xd3447c: r0 = Null
    //     0xd3447c: mov             x0, NULL
    // 0xd34480: LeaveFrame
    //     0xd34480: mov             SP, fp
    //     0xd34484: ldp             fp, lr, [SP], #0x10
    // 0xd34488: ret
    //     0xd34488: ret             
    // 0xd3448c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd3448c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd34490: b               #0xd34424
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xd34494, size: 0x28
    // 0xd34494: r1 = Instance_RefreshIndicatorStatus
    //     0xd34494: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f9f8] Obj!RefreshIndicatorStatus@12c5161
    //     0xd34498: ldr             x1, [x1, #0x9f8]
    // 0xd3449c: ldr             x2, [SP]
    // 0xd344a0: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xd344a0: ldur            w3, [x2, #0x17]
    // 0xd344a4: DecompressPointer r3
    //     0xd344a4: add             x3, x3, HEAP, lsl #32
    // 0xd344a8: LoadField: r2 = r3->field_f
    //     0xd344a8: ldur            w2, [x3, #0xf]
    // 0xd344ac: DecompressPointer r2
    //     0xd344ac: add             x2, x2, HEAP, lsl #32
    // 0xd344b0: StoreField: r2->field_33 = r1
    //     0xd344b0: stur            w1, [x2, #0x33]
    // 0xd344b4: r0 = Null
    //     0xd344b4: mov             x0, NULL
    // 0xd344b8: ret
    //     0xd344b8: ret             
  }
  _ _checkDragOffset(/* No info */) {
    // ** addr: 0xd344bc, size: 0x220
    // 0xd344bc: EnterFrame
    //     0xd344bc: stp             fp, lr, [SP, #-0x10]!
    //     0xd344c0: mov             fp, SP
    // 0xd344c4: AllocStack(0x10)
    //     0xd344c4: sub             SP, SP, #0x10
    // 0xd344c8: d1 = 0.250000
    //     0xd344c8: fmov            d1, #0.25000000
    // 0xd344cc: mov             x0, x1
    // 0xd344d0: stur            x1, [fp, #-8]
    // 0xd344d4: CheckStackOverflow
    //     0xd344d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd344d8: cmp             SP, x16
    //     0xd344dc: b.ls            #0xd34694
    // 0xd344e0: LoadField: r1 = r0->field_3b
    //     0xd344e0: ldur            w1, [x0, #0x3b]
    // 0xd344e4: DecompressPointer r1
    //     0xd344e4: add             x1, x1, HEAP, lsl #32
    // 0xd344e8: cmp             w1, NULL
    // 0xd344ec: b.eq            #0xd3469c
    // 0xd344f0: fmul            d2, d0, d1
    // 0xd344f4: LoadField: d0 = r1->field_7
    //     0xd344f4: ldur            d0, [x1, #7]
    // 0xd344f8: fdiv            d1, d0, d2
    // 0xd344fc: LoadField: r1 = r0->field_33
    //     0xd344fc: ldur            w1, [x0, #0x33]
    // 0xd34500: DecompressPointer r1
    //     0xd34500: add             x1, x1, HEAP, lsl #32
    // 0xd34504: r16 = Instance_RefreshIndicatorStatus
    //     0xd34504: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8fa50] Obj!RefreshIndicatorStatus@12c51c1
    //     0xd34508: ldr             x16, [x16, #0xa50]
    // 0xd3450c: cmp             w1, w16
    // 0xd34510: b.ne            #0xd34524
    // 0xd34514: d0 = 0.666667
    //     0xd34514: add             x17, PP, #0x8f, lsl #12  ; [pp+0x8fa68] IMM: double(0.6666666666666666) from 0x3fe5555555555555
    //     0xd34518: ldr             d0, [x17, #0xa68]
    // 0xd3451c: fmax            v2.2d, v1.2d, v0.2d
    // 0xd34520: mov             v1.16b, v2.16b
    // 0xd34524: d0 = 0.000000
    //     0xd34524: eor             v0.16b, v0.16b, v0.16b
    // 0xd34528: LoadField: r1 = r0->field_1b
    //     0xd34528: ldur            w1, [x0, #0x1b]
    // 0xd3452c: DecompressPointer r1
    //     0xd3452c: add             x1, x1, HEAP, lsl #32
    // 0xd34530: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd34534: cmp             w1, w16
    // 0xd34538: b.eq            #0xd346a0
    // 0xd3453c: fcmp            d0, d1
    // 0xd34540: b.le            #0xd3454c
    // 0xd34544: d0 = 0.000000
    //     0xd34544: eor             v0.16b, v0.16b, v0.16b
    // 0xd34548: b               #0xd34574
    // 0xd3454c: d0 = 1.000000
    //     0xd3454c: fmov            d0, #1.00000000
    // 0xd34550: fcmp            d1, d0
    // 0xd34554: b.le            #0xd34560
    // 0xd34558: d0 = 1.000000
    //     0xd34558: fmov            d0, #1.00000000
    // 0xd3455c: b               #0xd34574
    // 0xd34560: fcmp            d1, d1
    // 0xd34564: b.vc            #0xd34570
    // 0xd34568: d0 = 1.000000
    //     0xd34568: fmov            d0, #1.00000000
    // 0xd3456c: b               #0xd34574
    // 0xd34570: mov             v0.16b, v1.16b
    // 0xd34574: r2 = inline_Allocate_Double()
    //     0xd34574: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xd34578: add             x2, x2, #0x10
    //     0xd3457c: cmp             x3, x2
    //     0xd34580: b.ls            #0xd346ac
    //     0xd34584: str             x2, [THR, #0x60]  ; THR::top
    //     0xd34588: sub             x2, x2, #0xf
    //     0xd3458c: mov             x3, #0xe19c
    //     0xd34590: movk            x3, #3, lsl #16
    //     0xd34594: stur            x3, [x2, #-1]
    // 0xd34598: dmb             ishst
    // 0xd3459c: StoreField: r2->field_7 = d0
    //     0xd3459c: stur            d0, [x2, #7]
    // 0xd345a0: r0 = value=()
    //     0xd345a0: bl              #0x829534  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0xd345a4: ldur            x2, [fp, #-8]
    // 0xd345a8: LoadField: r0 = r2->field_33
    //     0xd345a8: ldur            w0, [x2, #0x33]
    // 0xd345ac: DecompressPointer r0
    //     0xd345ac: add             x0, x0, HEAP, lsl #32
    // 0xd345b0: r16 = Instance_RefreshIndicatorStatus
    //     0xd345b0: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8fa48] Obj!RefreshIndicatorStatus@12c51e1
    //     0xd345b4: ldr             x16, [x16, #0xa48]
    // 0xd345b8: cmp             w0, w16
    // 0xd345bc: b.ne            #0xd34684
    // 0xd345c0: LoadField: r1 = r2->field_2f
    //     0xd345c0: ldur            w1, [x2, #0x2f]
    // 0xd345c4: DecompressPointer r1
    //     0xd345c4: add             x1, x1, HEAP, lsl #32
    // 0xd345c8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd345cc: cmp             w1, w16
    // 0xd345d0: b.eq            #0xd346c8
    // 0xd345d4: r0 = LoadClassIdInstr(r1)
    //     0xd345d4: ldur            x0, [x1, #-1]
    //     0xd345d8: ubfx            x0, x0, #0xc, #0x14
    // 0xd345dc: r0 = GDT[cid_x0 + 0x14e2e]()
    //     0xd345dc: mov             x17, #0x4e2e
    //     0xd345e0: movk            x17, #1, lsl #16
    //     0xd345e4: add             lr, x0, x17
    //     0xd345e8: ldr             lr, [x21, lr, lsl #3]
    //     0xd345ec: blr             lr
    // 0xd345f0: cmp             w0, NULL
    // 0xd345f4: b.eq            #0xd346d4
    // 0xd345f8: r1 = LoadClassIdInstr(r0)
    //     0xd345f8: ldur            x1, [x0, #-1]
    //     0xd345fc: ubfx            x1, x1, #0xc, #0x14
    // 0xd34600: mov             x16, x0
    // 0xd34604: mov             x0, x1
    // 0xd34608: mov             x1, x16
    // 0xd3460c: r0 = GDT[cid_x0 + -0xfc0]()
    //     0xd3460c: sub             lr, x0, #0xfc0
    //     0xd34610: ldr             lr, [x21, lr, lsl #3]
    //     0xd34614: blr             lr
    // 0xd34618: ldur            x1, [fp, #-8]
    // 0xd3461c: stur            x0, [fp, #-0x10]
    // 0xd34620: LoadField: r0 = r1->field_3f
    //     0xd34620: ldur            w0, [x1, #0x3f]
    // 0xd34624: DecompressPointer r0
    //     0xd34624: add             x0, x0, HEAP, lsl #32
    // 0xd34628: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3462c: cmp             w0, w16
    // 0xd34630: b.ne            #0xd34640
    // 0xd34634: r2 = _effectiveValueColor
    //     0xd34634: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8fa88] Field <RefreshIndicatorState._effectiveValueColor@123083489>: late (offset: 0x40)
    //     0xd34638: ldr             x2, [x2, #0xa88]
    // 0xd3463c: r0 = InitLateInstanceField()
    //     0xd3463c: bl              #0x13dd948  ; InitLateInstanceFieldStub
    // 0xd34640: mov             x1, x0
    // 0xd34644: r0 = toARGB32()
    //     0xd34644: bl              #0x119defc  ; [dart:ui] Color::toARGB32
    // 0xd34648: ubfx            x0, x0, #0, #0x20
    // 0xd3464c: and             w1, w0, #0xff000000
    // 0xd34650: ubfx            x1, x1, #0, #0x20
    // 0xd34654: asr             x2, x1, #0x18
    // 0xd34658: ldur            x1, [fp, #-0x10]
    // 0xd3465c: cmp             x1, x2
    // 0xd34660: b.ne            #0xd34684
    // 0xd34664: ldur            x1, [fp, #-8]
    // 0xd34668: r2 = Instance_RefreshIndicatorStatus
    //     0xd34668: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8fa50] Obj!RefreshIndicatorStatus@12c51c1
    //     0xd3466c: ldr             x2, [x2, #0xa50]
    // 0xd34670: StoreField: r1->field_33 = r2
    //     0xd34670: stur            w2, [x1, #0x33]
    // 0xd34674: LoadField: r2 = r1->field_b
    //     0xd34674: ldur            w2, [x1, #0xb]
    // 0xd34678: DecompressPointer r2
    //     0xd34678: add             x2, x2, HEAP, lsl #32
    // 0xd3467c: cmp             w2, NULL
    // 0xd34680: b.eq            #0xd346d8
    // 0xd34684: r0 = Null
    //     0xd34684: mov             x0, NULL
    // 0xd34688: LeaveFrame
    //     0xd34688: mov             SP, fp
    //     0xd3468c: ldp             fp, lr, [SP], #0x10
    // 0xd34690: ret
    //     0xd34690: ret             
    // 0xd34694: r0 = StackOverflowSharedWithFPURegs()
    //     0xd34694: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xd34698: b               #0xd344e0
    // 0xd3469c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xd3469c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xd346a0: r9 = _positionController
    //     0xd346a0: add             x9, PP, #0x8f, lsl #12  ; [pp+0x8fa28] Field <RefreshIndicatorState._positionController@123083489>: late (offset: 0x1c)
    //     0xd346a4: ldr             x9, [x9, #0xa28]
    // 0xd346a8: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xd346a8: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xd346ac: SaveReg d0
    //     0xd346ac: str             q0, [SP, #-0x10]!
    // 0xd346b0: stp             x0, x1, [SP, #-0x10]!
    // 0xd346b4: r0 = AllocateDouble()
    //     0xd346b4: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd346b8: mov             x2, x0
    // 0xd346bc: ldp             x0, x1, [SP], #0x10
    // 0xd346c0: RestoreReg d0
    //     0xd346c0: ldr             q0, [SP], #0x10
    // 0xd346c4: b               #0xd3459c
    // 0xd346c8: r9 = _valueColor
    //     0xd346c8: add             x9, PP, #0x8f, lsl #12  ; [pp+0x8fa38] Field <RefreshIndicatorState._valueColor@123083489>: late (offset: 0x30)
    //     0xd346cc: ldr             x9, [x9, #0xa38]
    // 0xd346d0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd346d0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd346d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd346d4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd346d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd346d8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  Color _effectiveValueColor(RefreshIndicatorState) {
    // ** addr: 0xd346dc, size: 0x84
    // 0xd346dc: EnterFrame
    //     0xd346dc: stp             fp, lr, [SP, #-0x10]!
    //     0xd346e0: mov             fp, SP
    // 0xd346e4: CheckStackOverflow
    //     0xd346e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd346e8: cmp             SP, x16
    //     0xd346ec: b.ls            #0xd34750
    // 0xd346f0: ldr             x0, [fp, #0x10]
    // 0xd346f4: LoadField: r1 = r0->field_b
    //     0xd346f4: ldur            w1, [x0, #0xb]
    // 0xd346f8: DecompressPointer r1
    //     0xd346f8: add             x1, x1, HEAP, lsl #32
    // 0xd346fc: cmp             w1, NULL
    // 0xd34700: b.eq            #0xd34758
    // 0xd34704: LoadField: r2 = r1->field_27
    //     0xd34704: ldur            w2, [x1, #0x27]
    // 0xd34708: DecompressPointer r2
    //     0xd34708: add             x2, x2, HEAP, lsl #32
    // 0xd3470c: cmp             w2, NULL
    // 0xd34710: b.ne            #0xd34740
    // 0xd34714: LoadField: r1 = r0->field_f
    //     0xd34714: ldur            w1, [x0, #0xf]
    // 0xd34718: DecompressPointer r1
    //     0xd34718: add             x1, x1, HEAP, lsl #32
    // 0xd3471c: cmp             w1, NULL
    // 0xd34720: b.eq            #0xd3475c
    // 0xd34724: r0 = of()
    //     0xd34724: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd34728: LoadField: r1 = r0->field_3f
    //     0xd34728: ldur            w1, [x0, #0x3f]
    // 0xd3472c: DecompressPointer r1
    //     0xd3472c: add             x1, x1, HEAP, lsl #32
    // 0xd34730: LoadField: r3 = r1->field_b
    //     0xd34730: ldur            w3, [x1, #0xb]
    // 0xd34734: DecompressPointer r3
    //     0xd34734: add             x3, x3, HEAP, lsl #32
    // 0xd34738: mov             x0, x3
    // 0xd3473c: b               #0xd34744
    // 0xd34740: mov             x0, x2
    // 0xd34744: LeaveFrame
    //     0xd34744: mov             SP, fp
    //     0xd34748: ldp             fp, lr, [SP], #0x10
    // 0xd3474c: ret
    //     0xd3474c: ret             
    // 0xd34750: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd34750: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd34754: b               #0xd346f0
    // 0xd34758: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd34758: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd3475c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd3475c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _dismiss(/* No info */) async {
    // ** addr: 0xd34760, size: 0x1e0
    // 0xd34760: EnterFrame
    //     0xd34760: stp             fp, lr, [SP, #-0x10]!
    //     0xd34764: mov             fp, SP
    // 0xd34768: AllocStack(0x28)
    //     0xd34768: sub             SP, SP, #0x28
    // 0xd3476c: SetupParameters(RefreshIndicatorState this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0xd3476c: stur            NULL, [fp, #-8]
    //     0xd34770: stur            x1, [fp, #-0x10]
    //     0xd34774: stur            x2, [fp, #-0x18]
    // 0xd34778: CheckStackOverflow
    //     0xd34778: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd3477c: cmp             SP, x16
    //     0xd34780: b.ls            #0xd3491c
    // 0xd34784: r1 = 2
    //     0xd34784: mov             x1, #2
    // 0xd34788: r0 = AllocateContext()
    //     0xd34788: bl              #0x13de838  ; AllocateContextStub
    // 0xd3478c: mov             x2, x0
    // 0xd34790: ldur            x1, [fp, #-0x10]
    // 0xd34794: stur            x2, [fp, #-0x20]
    // 0xd34798: StoreField: r2->field_f = r1
    //     0xd34798: stur            w1, [x2, #0xf]
    // 0xd3479c: ldur            x0, [fp, #-0x18]
    // 0xd347a0: StoreField: r2->field_13 = r0
    //     0xd347a0: stur            w0, [x2, #0x13]
    // 0xd347a4: InitAsync() -> Future<void?>
    //     0xd347a4: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0xd347a8: bl              #0x7f5e44  ; InitAsyncStub
    // 0xd347ac: r1 = <void?>
    //     0xd347ac: ldr             x1, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xd347b0: r0 = _Future()
    //     0xd347b0: bl              #0x7f5dd4  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0xd347b4: stur            x0, [fp, #-0x18]
    // 0xd347b8: StoreField: r0->field_b = rZR
    //     0xd347b8: stur            xzr, [x0, #0xb]
    // 0xd347bc: r0 = LoadStaticField(0x364)
    //     0xd347bc: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xd347c0: ldr             x0, [x0, #0x6c8]
    // 0xd347c4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd347c8: cmp             w0, w16
    // 0xd347cc: b.ne            #0xd347d8
    // 0xd347d0: r2 = _current
    //     0xd347d0: ldr             x2, [PP, #0x2c0]  ; [pp+0x2c0] Field <Zone._current@5048458>: static late (offset: 0x364)
    // 0xd347d4: r0 = InitLateStaticField()
    //     0xd347d4: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0xd347d8: mov             x1, x0
    // 0xd347dc: ldur            x0, [fp, #-0x18]
    // 0xd347e0: StoreField: r0->field_13 = r1
    //     0xd347e0: stur            w1, [x0, #0x13]
    // 0xd347e4: mov             x1, x0
    // 0xd347e8: r2 = Null
    //     0xd347e8: mov             x2, NULL
    // 0xd347ec: r0 = _asyncComplete()
    //     0xd347ec: bl              #0x7eee44  ; [dart:async] _Future::_asyncComplete
    // 0xd347f0: ldur            x0, [fp, #-0x18]
    // 0xd347f4: r0 = Await()
    //     0xd347f4: bl              #0x7f5c00  ; AwaitStub
    // 0xd347f8: ldur            x2, [fp, #-0x20]
    // 0xd347fc: r1 = Function '<anonymous closure>':.
    //     0xd347fc: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8fa90] AnonymousClosure: (0xd34960), in [package:flutter/src/material/refresh_indicator.dart] RefreshIndicatorState::_dismiss (0xd34760)
    //     0xd34800: ldr             x1, [x1, #0xa90]
    // 0xd34804: r0 = AllocateClosure()
    //     0xd34804: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd34808: ldur            x1, [fp, #-0x10]
    // 0xd3480c: mov             x2, x0
    // 0xd34810: r0 = setState()
    //     0xd34810: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xd34814: ldur            x0, [fp, #-0x10]
    // 0xd34818: LoadField: r1 = r0->field_33
    //     0xd34818: ldur            w1, [x0, #0x33]
    // 0xd3481c: DecompressPointer r1
    //     0xd3481c: add             x1, x1, HEAP, lsl #32
    // 0xd34820: cmp             w1, NULL
    // 0xd34824: b.eq            #0xd34924
    // 0xd34828: LoadField: r2 = r1->field_7
    //     0xd34828: ldur            x2, [x1, #7]
    // 0xd3482c: cmp             x2, #2
    // 0xd34830: b.le            #0xd348c8
    // 0xd34834: cmp             x2, #4
    // 0xd34838: b.gt            #0xd34888
    // 0xd3483c: cmp             x2, #3
    // 0xd34840: b.le            #0xd348c8
    // 0xd34844: LoadField: r1 = r0->field_1f
    //     0xd34844: ldur            w1, [x0, #0x1f]
    // 0xd34848: DecompressPointer r1
    //     0xd34848: add             x1, x1, HEAP, lsl #32
    // 0xd3484c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd34850: cmp             w1, w16
    // 0xd34854: b.eq            #0xd34928
    // 0xd34858: r16 = Instance_Duration
    //     0xd34858: add             x16, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xd3485c: ldr             x16, [x16, #0x318]
    // 0xd34860: str             x16, [SP]
    // 0xd34864: d0 = 1.000000
    //     0xd34864: fmov            d0, #1.00000000
    // 0xd34868: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0xd34868: add             x4, PP, #0x15, lsl #12  ; [pp+0x155a0] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0xd3486c: ldr             x4, [x4, #0x5a0]
    // 0xd34870: r0 = animateTo()
    //     0xd34870: bl              #0x866084  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::animateTo
    // 0xd34874: mov             x1, x0
    // 0xd34878: stur            x1, [fp, #-0x18]
    // 0xd3487c: r0 = Await()
    //     0xd3487c: bl              #0x7f5c00  ; AwaitStub
    // 0xd34880: ldur            x0, [fp, #-0x10]
    // 0xd34884: b               #0xd348c8
    // 0xd34888: LoadField: r1 = r0->field_1b
    //     0xd34888: ldur            w1, [x0, #0x1b]
    // 0xd3488c: DecompressPointer r1
    //     0xd3488c: add             x1, x1, HEAP, lsl #32
    // 0xd34890: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd34894: cmp             w1, w16
    // 0xd34898: b.eq            #0xd34934
    // 0xd3489c: r16 = Instance_Duration
    //     0xd3489c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15318] Obj!Duration@12c8981
    //     0xd348a0: ldr             x16, [x16, #0x318]
    // 0xd348a4: str             x16, [SP]
    // 0xd348a8: d0 = 0.000000
    //     0xd348a8: eor             v0.16b, v0.16b, v0.16b
    // 0xd348ac: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0xd348ac: add             x4, PP, #0x15, lsl #12  ; [pp+0x155a0] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0xd348b0: ldr             x4, [x4, #0x5a0]
    // 0xd348b4: r0 = animateTo()
    //     0xd348b4: bl              #0x866084  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::animateTo
    // 0xd348b8: mov             x1, x0
    // 0xd348bc: stur            x1, [fp, #-0x18]
    // 0xd348c0: r0 = Await()
    //     0xd348c0: bl              #0x7f5c00  ; AwaitStub
    // 0xd348c4: ldur            x0, [fp, #-0x10]
    // 0xd348c8: LoadField: r1 = r0->field_f
    //     0xd348c8: ldur            w1, [x0, #0xf]
    // 0xd348cc: DecompressPointer r1
    //     0xd348cc: add             x1, x1, HEAP, lsl #32
    // 0xd348d0: cmp             w1, NULL
    // 0xd348d4: b.eq            #0xd34914
    // 0xd348d8: ldur            x2, [fp, #-0x20]
    // 0xd348dc: LoadField: r1 = r0->field_33
    //     0xd348dc: ldur            w1, [x0, #0x33]
    // 0xd348e0: DecompressPointer r1
    //     0xd348e0: add             x1, x1, HEAP, lsl #32
    // 0xd348e4: LoadField: r3 = r2->field_13
    //     0xd348e4: ldur            w3, [x2, #0x13]
    // 0xd348e8: DecompressPointer r3
    //     0xd348e8: add             x3, x3, HEAP, lsl #32
    // 0xd348ec: cmp             w1, w3
    // 0xd348f0: b.ne            #0xd34914
    // 0xd348f4: StoreField: r0->field_3b = rNULL
    //     0xd348f4: stur            NULL, [x0, #0x3b]
    // 0xd348f8: StoreField: r0->field_37 = rNULL
    //     0xd348f8: stur            NULL, [x0, #0x37]
    // 0xd348fc: r1 = Function '<anonymous closure>':.
    //     0xd348fc: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8fa98] AnonymousClosure: (0xd34940), in [package:flutter/src/material/refresh_indicator.dart] RefreshIndicatorState::_dismiss (0xd34760)
    //     0xd34900: ldr             x1, [x1, #0xa98]
    // 0xd34904: r0 = AllocateClosure()
    //     0xd34904: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd34908: ldur            x1, [fp, #-0x10]
    // 0xd3490c: mov             x2, x0
    // 0xd34910: r0 = setState()
    //     0xd34910: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xd34914: r0 = Null
    //     0xd34914: mov             x0, NULL
    // 0xd34918: r0 = ReturnAsyncNotFuture()
    //     0xd34918: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xd3491c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd3491c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd34920: b               #0xd34784
    // 0xd34924: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd34924: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd34928: r9 = _scaleController
    //     0xd34928: add             x9, PP, #0x8f, lsl #12  ; [pp+0x8faa0] Field <RefreshIndicatorState._scaleController@123083489>: late (offset: 0x20)
    //     0xd3492c: ldr             x9, [x9, #0xaa0]
    // 0xd34930: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd34930: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd34934: r9 = _positionController
    //     0xd34934: add             x9, PP, #0x8f, lsl #12  ; [pp+0x8fa28] Field <RefreshIndicatorState._positionController@123083489>: late (offset: 0x1c)
    //     0xd34938: ldr             x9, [x9, #0xa28]
    // 0xd3493c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd3493c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xd34940, size: 0x20
    // 0xd34940: ldr             x1, [SP]
    // 0xd34944: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xd34944: ldur            w2, [x1, #0x17]
    // 0xd34948: DecompressPointer r2
    //     0xd34948: add             x2, x2, HEAP, lsl #32
    // 0xd3494c: LoadField: r1 = r2->field_f
    //     0xd3494c: ldur            w1, [x2, #0xf]
    // 0xd34950: DecompressPointer r1
    //     0xd34950: add             x1, x1, HEAP, lsl #32
    // 0xd34954: StoreField: r1->field_33 = rNULL
    //     0xd34954: stur            NULL, [x1, #0x33]
    // 0xd34958: r0 = Null
    //     0xd34958: mov             x0, NULL
    // 0xd3495c: ret
    //     0xd3495c: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xd34960, size: 0x64
    // 0xd34960: ldr             x1, [SP]
    // 0xd34964: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xd34964: ldur            w2, [x1, #0x17]
    // 0xd34968: DecompressPointer r2
    //     0xd34968: add             x2, x2, HEAP, lsl #32
    // 0xd3496c: LoadField: r1 = r2->field_f
    //     0xd3496c: ldur            w1, [x2, #0xf]
    // 0xd34970: DecompressPointer r1
    //     0xd34970: add             x1, x1, HEAP, lsl #32
    // 0xd34974: LoadField: r0 = r2->field_13
    //     0xd34974: ldur            w0, [x2, #0x13]
    // 0xd34978: DecompressPointer r0
    //     0xd34978: add             x0, x0, HEAP, lsl #32
    // 0xd3497c: StoreField: r1->field_33 = r0
    //     0xd3497c: stur            w0, [x1, #0x33]
    //     0xd34980: ldurb           w16, [x1, #-1]
    //     0xd34984: ldurb           w17, [x0, #-1]
    //     0xd34988: and             x16, x17, x16, lsr #2
    //     0xd3498c: tst             x16, HEAP, lsr #32
    //     0xd34990: b.eq            #0xd349a0
    //     0xd34994: str             lr, [SP, #-8]!
    //     0xd34998: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    //     0xd3499c: ldr             lr, [SP], #8
    // 0xd349a0: LoadField: r2 = r1->field_b
    //     0xd349a0: ldur            w2, [x1, #0xb]
    // 0xd349a4: DecompressPointer r2
    //     0xd349a4: add             x2, x2, HEAP, lsl #32
    // 0xd349a8: cmp             w2, NULL
    // 0xd349ac: b.eq            #0xd349b8
    // 0xd349b0: r0 = Null
    //     0xd349b0: mov             x0, NULL
    // 0xd349b4: ret
    //     0xd349b4: ret             
    // 0xd349b8: EnterFrame
    //     0xd349b8: stp             fp, lr, [SP, #-0x10]!
    //     0xd349bc: mov             fp, SP
    // 0xd349c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd349c0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _shouldStart(/* No info */) {
    // ** addr: 0xd349c4, size: 0x11c
    // 0xd349c4: EnterFrame
    //     0xd349c4: stp             fp, lr, [SP, #-0x10]!
    //     0xd349c8: mov             fp, SP
    // 0xd349cc: AllocStack(0x18)
    //     0xd349cc: sub             SP, SP, #0x18
    // 0xd349d0: SetupParameters(RefreshIndicatorState this /* r1 => r0, fp-0x18 */)
    //     0xd349d0: mov             x0, x1
    //     0xd349d4: stur            x1, [fp, #-0x18]
    // 0xd349d8: CheckStackOverflow
    //     0xd349d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd349dc: cmp             SP, x16
    //     0xd349e0: b.ls            #0xd34ad4
    // 0xd349e4: r1 = LoadClassIdInstr(r2)
    //     0xd349e4: ldur            x1, [x2, #-1]
    //     0xd349e8: ubfx            x1, x1, #0xc, #0x14
    // 0xd349ec: r17 = 4557
    //     0xd349ec: mov             x17, #0x11cd
    // 0xd349f0: cmp             x1, x17
    // 0xd349f4: b.ne            #0xd34a98
    // 0xd349f8: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xd349f8: ldur            w3, [x2, #0x17]
    // 0xd349fc: DecompressPointer r3
    //     0xd349fc: add             x3, x3, HEAP, lsl #32
    // 0xd34a00: cmp             w3, NULL
    // 0xd34a04: b.eq            #0xd34a98
    // 0xd34a08: LoadField: r3 = r2->field_f
    //     0xd34a08: ldur            w3, [x2, #0xf]
    // 0xd34a0c: DecompressPointer r3
    //     0xd34a0c: add             x3, x3, HEAP, lsl #32
    // 0xd34a10: stur            x3, [fp, #-0x10]
    // 0xd34a14: ArrayLoad: r2 = r3[0]  ; List_4
    //     0xd34a14: ldur            w2, [x3, #0x17]
    // 0xd34a18: DecompressPointer r2
    //     0xd34a18: add             x2, x2, HEAP, lsl #32
    // 0xd34a1c: stur            x2, [fp, #-8]
    // 0xd34a20: r16 = Instance_AxisDirection
    //     0xd34a20: ldr             x16, [PP, #0x5ce8]  ; [pp+0x5ce8] Obj!AxisDirection@12c4a01
    // 0xd34a24: cmp             w2, w16
    // 0xd34a28: b.ne            #0xd34a48
    // 0xd34a2c: mov             x1, x3
    // 0xd34a30: r0 = extentAfter()
    //     0xd34a30: bl              #0xb71190  ; [dart:mixin_deduplication] _MixinApplication23&Object&ScrollMetrics::extentAfter
    // 0xd34a34: mov             v1.16b, v0.16b
    // 0xd34a38: d0 = 0.000000
    //     0xd34a38: eor             v0.16b, v0.16b, v0.16b
    // 0xd34a3c: fcmp            d1, d0
    // 0xd34a40: b.ne            #0xd34a4c
    // 0xd34a44: b               #0xd34a74
    // 0xd34a48: d0 = 0.000000
    //     0xd34a48: eor             v0.16b, v0.16b, v0.16b
    // 0xd34a4c: ldur            x2, [fp, #-8]
    // 0xd34a50: r16 = Instance_AxisDirection
    //     0xd34a50: ldr             x16, [PP, #0x5cf0]  ; [pp+0x5cf0] Obj!AxisDirection@12c49e1
    // 0xd34a54: cmp             w2, w16
    // 0xd34a58: b.ne            #0xd34ac4
    // 0xd34a5c: ldur            x1, [fp, #-0x10]
    // 0xd34a60: r0 = extentBefore()
    //     0xd34a60: bl              #0xb711e0  ; [dart:mixin_deduplication] _MixinApplication23&Object&ScrollMetrics::extentBefore
    // 0xd34a64: mov             v1.16b, v0.16b
    // 0xd34a68: d0 = 0.000000
    //     0xd34a68: eor             v0.16b, v0.16b, v0.16b
    // 0xd34a6c: fcmp            d1, d0
    // 0xd34a70: b.ne            #0xd34ac4
    // 0xd34a74: ldur            x0, [fp, #-0x18]
    // 0xd34a78: LoadField: r1 = r0->field_33
    //     0xd34a78: ldur            w1, [x0, #0x33]
    // 0xd34a7c: DecompressPointer r1
    //     0xd34a7c: add             x1, x1, HEAP, lsl #32
    // 0xd34a80: cmp             w1, NULL
    // 0xd34a84: b.ne            #0xd34ac4
    // 0xd34a88: mov             x1, x0
    // 0xd34a8c: ldur            x2, [fp, #-8]
    // 0xd34a90: r0 = _start()
    //     0xd34a90: bl              #0xd34ae0  ; [package:flutter/src/material/refresh_indicator.dart] RefreshIndicatorState::_start
    // 0xd34a94: b               #0xd34ac8
    // 0xd34a98: r17 = 4556
    //     0xd34a98: mov             x17, #0x11cc
    // 0xd34a9c: cmp             x1, x17
    // 0xd34aa0: b.ne            #0xd34ac4
    // 0xd34aa4: ArrayLoad: r1 = r2[0]  ; List_4
    //     0xd34aa4: ldur            w1, [x2, #0x17]
    // 0xd34aa8: DecompressPointer r1
    //     0xd34aa8: add             x1, x1, HEAP, lsl #32
    // 0xd34aac: cmp             w1, NULL
    // 0xd34ab0: b.eq            #0xd34ac4
    // 0xd34ab4: LoadField: r1 = r0->field_b
    //     0xd34ab4: ldur            w1, [x0, #0xb]
    // 0xd34ab8: DecompressPointer r1
    //     0xd34ab8: add             x1, x1, HEAP, lsl #32
    // 0xd34abc: cmp             w1, NULL
    // 0xd34ac0: b.eq            #0xd34adc
    // 0xd34ac4: r0 = false
    //     0xd34ac4: add             x0, NULL, #0x30  ; false
    // 0xd34ac8: LeaveFrame
    //     0xd34ac8: mov             SP, fp
    //     0xd34acc: ldp             fp, lr, [SP], #0x10
    // 0xd34ad0: ret
    //     0xd34ad0: ret             
    // 0xd34ad4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd34ad4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd34ad8: b               #0xd349e4
    // 0xd34adc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd34adc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _start(/* No info */) {
    // ** addr: 0xd34ae0, size: 0xd0
    // 0xd34ae0: EnterFrame
    //     0xd34ae0: stp             fp, lr, [SP, #-0x10]!
    //     0xd34ae4: mov             fp, SP
    // 0xd34ae8: AllocStack(0x8)
    //     0xd34ae8: sub             SP, SP, #8
    // 0xd34aec: SetupParameters(RefreshIndicatorState this /* r1 => r0, fp-0x8 */)
    //     0xd34aec: mov             x0, x1
    //     0xd34af0: stur            x1, [fp, #-8]
    // 0xd34af4: CheckStackOverflow
    //     0xd34af4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd34af8: cmp             SP, x16
    //     0xd34afc: b.ls            #0xd34b90
    // 0xd34b00: LoadField: r1 = r2->field_7
    //     0xd34b00: ldur            x1, [x2, #7]
    // 0xd34b04: cmp             x1, #1
    // 0xd34b08: b.gt            #0xd34b18
    // 0xd34b0c: cmp             x1, #0
    // 0xd34b10: b.gt            #0xd34b7c
    // 0xd34b14: b               #0xd34b20
    // 0xd34b18: cmp             x1, #2
    // 0xd34b1c: b.gt            #0xd34b7c
    // 0xd34b20: r4 = true
    //     0xd34b20: add             x4, NULL, #0x20  ; true
    // 0xd34b24: r3 = 0.000000
    //     0xd34b24: ldr             x3, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xd34b28: StoreField: r0->field_37 = r4
    //     0xd34b28: stur            w4, [x0, #0x37]
    // 0xd34b2c: StoreField: r0->field_3b = r3
    //     0xd34b2c: stur            w3, [x0, #0x3b]
    // 0xd34b30: LoadField: r1 = r0->field_1f
    //     0xd34b30: ldur            w1, [x0, #0x1f]
    // 0xd34b34: DecompressPointer r1
    //     0xd34b34: add             x1, x1, HEAP, lsl #32
    // 0xd34b38: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd34b3c: cmp             w1, w16
    // 0xd34b40: b.eq            #0xd34b98
    // 0xd34b44: mov             x2, x3
    // 0xd34b48: r0 = value=()
    //     0xd34b48: bl              #0x829534  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0xd34b4c: ldur            x0, [fp, #-8]
    // 0xd34b50: LoadField: r1 = r0->field_1b
    //     0xd34b50: ldur            w1, [x0, #0x1b]
    // 0xd34b54: DecompressPointer r1
    //     0xd34b54: add             x1, x1, HEAP, lsl #32
    // 0xd34b58: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd34b5c: cmp             w1, w16
    // 0xd34b60: b.eq            #0xd34ba4
    // 0xd34b64: r2 = 0.000000
    //     0xd34b64: ldr             x2, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xd34b68: r0 = value=()
    //     0xd34b68: bl              #0x829534  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0xd34b6c: r0 = true
    //     0xd34b6c: add             x0, NULL, #0x20  ; true
    // 0xd34b70: LeaveFrame
    //     0xd34b70: mov             SP, fp
    //     0xd34b74: ldp             fp, lr, [SP], #0x10
    // 0xd34b78: ret
    //     0xd34b78: ret             
    // 0xd34b7c: StoreField: r0->field_37 = rNULL
    //     0xd34b7c: stur            NULL, [x0, #0x37]
    // 0xd34b80: r0 = false
    //     0xd34b80: add             x0, NULL, #0x30  ; false
    // 0xd34b84: LeaveFrame
    //     0xd34b84: mov             SP, fp
    //     0xd34b88: ldp             fp, lr, [SP], #0x10
    // 0xd34b8c: ret
    //     0xd34b8c: ret             
    // 0xd34b90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd34b90: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd34b94: b               #0xd34b00
    // 0xd34b98: r9 = _scaleController
    //     0xd34b98: add             x9, PP, #0x8f, lsl #12  ; [pp+0x8faa0] Field <RefreshIndicatorState._scaleController@123083489>: late (offset: 0x20)
    //     0xd34b9c: ldr             x9, [x9, #0xaa0]
    // 0xd34ba0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd34ba0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd34ba4: r9 = _positionController
    //     0xd34ba4: add             x9, PP, #0x8f, lsl #12  ; [pp+0x8fa28] Field <RefreshIndicatorState._positionController@123083489>: late (offset: 0x1c)
    //     0xd34ba8: ldr             x9, [x9, #0xa28]
    // 0xd34bac: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd34bac: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xd34bc8, size: 0x44
    // 0xd34bc8: r1 = Instance_RefreshIndicatorStatus
    //     0xd34bc8: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8fa48] Obj!RefreshIndicatorStatus@12c51e1
    //     0xd34bcc: ldr             x1, [x1, #0xa48]
    // 0xd34bd0: ldr             x2, [SP]
    // 0xd34bd4: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xd34bd4: ldur            w3, [x2, #0x17]
    // 0xd34bd8: DecompressPointer r3
    //     0xd34bd8: add             x3, x3, HEAP, lsl #32
    // 0xd34bdc: LoadField: r2 = r3->field_f
    //     0xd34bdc: ldur            w2, [x3, #0xf]
    // 0xd34be0: DecompressPointer r2
    //     0xd34be0: add             x2, x2, HEAP, lsl #32
    // 0xd34be4: StoreField: r2->field_33 = r1
    //     0xd34be4: stur            w1, [x2, #0x33]
    // 0xd34be8: LoadField: r1 = r2->field_b
    //     0xd34be8: ldur            w1, [x2, #0xb]
    // 0xd34bec: DecompressPointer r1
    //     0xd34bec: add             x1, x1, HEAP, lsl #32
    // 0xd34bf0: cmp             w1, NULL
    // 0xd34bf4: b.eq            #0xd34c00
    // 0xd34bf8: r0 = Null
    //     0xd34bf8: mov             x0, NULL
    // 0xd34bfc: ret
    //     0xd34bfc: ret             
    // 0xd34c00: EnterFrame
    //     0xd34c00: stp             fp, lr, [SP, #-0x10]!
    //     0xd34c04: mov             fp, SP
    // 0xd34c08: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd34c08: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] bool _handleIndicatorNotification(dynamic, OverscrollIndicatorNotification) {
    // ** addr: 0xd34c0c, size: 0x3c
    // 0xd34c0c: EnterFrame
    //     0xd34c0c: stp             fp, lr, [SP, #-0x10]!
    //     0xd34c10: mov             fp, SP
    // 0xd34c14: ldr             x0, [fp, #0x18]
    // 0xd34c18: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd34c18: ldur            w1, [x0, #0x17]
    // 0xd34c1c: DecompressPointer r1
    //     0xd34c1c: add             x1, x1, HEAP, lsl #32
    // 0xd34c20: CheckStackOverflow
    //     0xd34c20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd34c24: cmp             SP, x16
    //     0xd34c28: b.ls            #0xd34c40
    // 0xd34c2c: ldr             x2, [fp, #0x10]
    // 0xd34c30: r0 = _handleIndicatorNotification()
    //     0xd34c30: bl              #0xd34c48  ; [package:flutter/src/material/refresh_indicator.dart] RefreshIndicatorState::_handleIndicatorNotification
    // 0xd34c34: LeaveFrame
    //     0xd34c34: mov             SP, fp
    //     0xd34c38: ldp             fp, lr, [SP], #0x10
    // 0xd34c3c: ret
    //     0xd34c3c: ret             
    // 0xd34c40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd34c40: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd34c44: b               #0xd34c2c
  }
  _ _handleIndicatorNotification(/* No info */) {
    // ** addr: 0xd34c48, size: 0x84
    // 0xd34c48: EnterFrame
    //     0xd34c48: stp             fp, lr, [SP, #-0x10]!
    //     0xd34c4c: mov             fp, SP
    // 0xd34c50: mov             x0, x1
    // 0xd34c54: mov             x1, x2
    // 0xd34c58: CheckStackOverflow
    //     0xd34c58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd34c5c: cmp             SP, x16
    //     0xd34c60: b.ls            #0xd34cc4
    // 0xd34c64: LoadField: r2 = r1->field_7
    //     0xd34c64: ldur            x2, [x1, #7]
    // 0xd34c68: cbnz            x2, #0xd34c78
    // 0xd34c6c: LoadField: r2 = r1->field_f
    //     0xd34c6c: ldur            w2, [x1, #0xf]
    // 0xd34c70: DecompressPointer r2
    //     0xd34c70: add             x2, x2, HEAP, lsl #32
    // 0xd34c74: tbz             w2, #4, #0xd34c88
    // 0xd34c78: r0 = false
    //     0xd34c78: add             x0, NULL, #0x30  ; false
    // 0xd34c7c: LeaveFrame
    //     0xd34c7c: mov             SP, fp
    //     0xd34c80: ldp             fp, lr, [SP], #0x10
    // 0xd34c84: ret
    //     0xd34c84: ret             
    // 0xd34c88: LoadField: r2 = r0->field_33
    //     0xd34c88: ldur            w2, [x0, #0x33]
    // 0xd34c8c: DecompressPointer r2
    //     0xd34c8c: add             x2, x2, HEAP, lsl #32
    // 0xd34c90: r16 = Instance_RefreshIndicatorStatus
    //     0xd34c90: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8fa48] Obj!RefreshIndicatorStatus@12c51e1
    //     0xd34c94: ldr             x16, [x16, #0xa48]
    // 0xd34c98: cmp             w2, w16
    // 0xd34c9c: b.ne            #0xd34cb4
    // 0xd34ca0: r0 = _doRestore()
    //     0xd34ca0: bl              #0xd34ccc  ; [dart:mixin_deduplication] _MixinApplication262&State&RestorationMixin::_doRestore
    // 0xd34ca4: r0 = true
    //     0xd34ca4: add             x0, NULL, #0x20  ; true
    // 0xd34ca8: LeaveFrame
    //     0xd34ca8: mov             SP, fp
    //     0xd34cac: ldp             fp, lr, [SP], #0x10
    // 0xd34cb0: ret
    //     0xd34cb0: ret             
    // 0xd34cb4: r0 = false
    //     0xd34cb4: add             x0, NULL, #0x30  ; false
    // 0xd34cb8: LeaveFrame
    //     0xd34cb8: mov             SP, fp
    //     0xd34cbc: ldp             fp, lr, [SP], #0x10
    // 0xd34cc0: ret
    //     0xd34cc0: ret             
    // 0xd34cc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd34cc4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd34cc8: b               #0xd34c64
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0xeed5b8, size: 0x30
    // 0xeed5b8: EnterFrame
    //     0xeed5b8: stp             fp, lr, [SP, #-0x10]!
    //     0xeed5bc: mov             fp, SP
    // 0xeed5c0: CheckStackOverflow
    //     0xeed5c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeed5c4: cmp             SP, x16
    //     0xeed5c8: b.ls            #0xeed5e0
    // 0xeed5cc: r0 = _setupColorTween()
    //     0xeed5cc: bl              #0xeed5e8  ; [package:flutter/src/material/refresh_indicator.dart] RefreshIndicatorState::_setupColorTween
    // 0xeed5d0: r0 = Null
    //     0xeed5d0: mov             x0, NULL
    // 0xeed5d4: LeaveFrame
    //     0xeed5d4: mov             SP, fp
    //     0xeed5d8: ldp             fp, lr, [SP], #0x10
    // 0xeed5dc: ret
    //     0xeed5dc: ret             
    // 0xeed5e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeed5e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeed5e4: b               #0xeed5cc
  }
  _ _setupColorTween(/* No info */) {
    // ** addr: 0xeed5e8, size: 0x1f0
    // 0xeed5e8: EnterFrame
    //     0xeed5e8: stp             fp, lr, [SP, #-0x10]!
    //     0xeed5ec: mov             fp, SP
    // 0xeed5f0: AllocStack(0x28)
    //     0xeed5f0: sub             SP, SP, #0x28
    // 0xeed5f4: SetupParameters(RefreshIndicatorState this /* r1 => r0, fp-0x8 */)
    //     0xeed5f4: mov             x0, x1
    //     0xeed5f8: stur            x1, [fp, #-8]
    // 0xeed5fc: CheckStackOverflow
    //     0xeed5fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeed600: cmp             SP, x16
    //     0xeed604: b.ls            #0xeed7bc
    // 0xeed608: LoadField: r1 = r0->field_b
    //     0xeed608: ldur            w1, [x0, #0xb]
    // 0xeed60c: DecompressPointer r1
    //     0xeed60c: add             x1, x1, HEAP, lsl #32
    // 0xeed610: cmp             w1, NULL
    // 0xeed614: b.eq            #0xeed7c4
    // 0xeed618: LoadField: r2 = r1->field_27
    //     0xeed618: ldur            w2, [x1, #0x27]
    // 0xeed61c: DecompressPointer r2
    //     0xeed61c: add             x2, x2, HEAP, lsl #32
    // 0xeed620: cmp             w2, NULL
    // 0xeed624: b.ne            #0xeed654
    // 0xeed628: LoadField: r1 = r0->field_f
    //     0xeed628: ldur            w1, [x0, #0xf]
    // 0xeed62c: DecompressPointer r1
    //     0xeed62c: add             x1, x1, HEAP, lsl #32
    // 0xeed630: cmp             w1, NULL
    // 0xeed634: b.eq            #0xeed7c8
    // 0xeed638: r0 = of()
    //     0xeed638: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xeed63c: LoadField: r1 = r0->field_3f
    //     0xeed63c: ldur            w1, [x0, #0x3f]
    // 0xeed640: DecompressPointer r1
    //     0xeed640: add             x1, x1, HEAP, lsl #32
    // 0xeed644: LoadField: r0 = r1->field_b
    //     0xeed644: ldur            w0, [x1, #0xb]
    // 0xeed648: DecompressPointer r0
    //     0xeed648: add             x0, x0, HEAP, lsl #32
    // 0xeed64c: mov             x3, x0
    // 0xeed650: b               #0xeed658
    // 0xeed654: mov             x3, x2
    // 0xeed658: ldur            x2, [fp, #-8]
    // 0xeed65c: mov             x0, x3
    // 0xeed660: stur            x3, [fp, #-0x10]
    // 0xeed664: StoreField: r2->field_3f = r0
    //     0xeed664: stur            w0, [x2, #0x3f]
    //     0xeed668: ldurb           w16, [x2, #-1]
    //     0xeed66c: ldurb           w17, [x0, #-1]
    //     0xeed670: and             x16, x17, x16, lsr #2
    //     0xeed674: tst             x16, HEAP, lsr #32
    //     0xeed678: b.eq            #0xeed680
    //     0xeed67c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xeed680: mov             x1, x3
    // 0xeed684: r0 = toARGB32()
    //     0xeed684: bl              #0x119defc  ; [dart:ui] Color::toARGB32
    // 0xeed688: ubfx            x0, x0, #0, #0x20
    // 0xeed68c: and             w1, w0, #0xff000000
    // 0xeed690: ubfx            x1, x1, #0, #0x20
    // 0xeed694: asr             x0, x1, #0x18
    // 0xeed698: cbnz            x0, #0xeed6e4
    // 0xeed69c: ldur            x0, [fp, #-8]
    // 0xeed6a0: ldur            x2, [fp, #-0x10]
    // 0xeed6a4: r1 = <Color>
    //     0xeed6a4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xeed6a8: ldr             x1, [x1, #0xa90]
    // 0xeed6ac: r0 = AlwaysStoppedAnimation()
    //     0xeed6ac: bl              #0xdc0094  ; AllocateAlwaysStoppedAnimationStub -> AlwaysStoppedAnimation<X0> (size=0x10)
    // 0xeed6b0: mov             x1, x0
    // 0xeed6b4: ldur            x0, [fp, #-0x10]
    // 0xeed6b8: StoreField: r1->field_b = r0
    //     0xeed6b8: stur            w0, [x1, #0xb]
    // 0xeed6bc: mov             x0, x1
    // 0xeed6c0: ldur            x3, [fp, #-8]
    // 0xeed6c4: StoreField: r3->field_2f = r0
    //     0xeed6c4: stur            w0, [x3, #0x2f]
    //     0xeed6c8: ldurb           w16, [x3, #-1]
    //     0xeed6cc: ldurb           w17, [x0, #-1]
    //     0xeed6d0: and             x16, x17, x16, lsr #2
    //     0xeed6d4: tst             x16, HEAP, lsr #32
    //     0xeed6d8: b.eq            #0xeed6e0
    //     0xeed6dc: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xeed6e0: b               #0xeed7ac
    // 0xeed6e4: ldur            x3, [fp, #-8]
    // 0xeed6e8: ldur            x0, [fp, #-0x10]
    // 0xeed6ec: LoadField: r4 = r3->field_1b
    //     0xeed6ec: ldur            w4, [x3, #0x1b]
    // 0xeed6f0: DecompressPointer r4
    //     0xeed6f0: add             x4, x4, HEAP, lsl #32
    // 0xeed6f4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xeed6f8: cmp             w4, w16
    // 0xeed6fc: b.eq            #0xeed7cc
    // 0xeed700: mov             x1, x0
    // 0xeed704: stur            x4, [fp, #-0x18]
    // 0xeed708: r2 = 0
    //     0xeed708: mov             x2, #0
    // 0xeed70c: r0 = withAlpha()
    //     0xeed70c: bl              #0x12d872c  ; [dart:ui] Color::withAlpha
    // 0xeed710: ldur            x1, [fp, #-0x10]
    // 0xeed714: stur            x0, [fp, #-0x20]
    // 0xeed718: r0 = toARGB32()
    //     0xeed718: bl              #0x119defc  ; [dart:ui] Color::toARGB32
    // 0xeed71c: ubfx            x0, x0, #0, #0x20
    // 0xeed720: and             w1, w0, #0xff000000
    // 0xeed724: ubfx            x1, x1, #0, #0x20
    // 0xeed728: asr             x2, x1, #0x18
    // 0xeed72c: ldur            x1, [fp, #-0x10]
    // 0xeed730: r0 = withAlpha()
    //     0xeed730: bl              #0x12d872c  ; [dart:ui] Color::withAlpha
    // 0xeed734: r1 = <Color?>
    //     0xeed734: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xeed738: ldr             x1, [x1, #0xa40]
    // 0xeed73c: stur            x0, [fp, #-0x10]
    // 0xeed740: r0 = ColorTween()
    //     0xeed740: bl              #0x915f2c  ; AllocateColorTweenStub -> ColorTween (size=0x14)
    // 0xeed744: mov             x2, x0
    // 0xeed748: ldur            x0, [fp, #-0x20]
    // 0xeed74c: stur            x2, [fp, #-0x28]
    // 0xeed750: StoreField: r2->field_b = r0
    //     0xeed750: stur            w0, [x2, #0xb]
    // 0xeed754: ldur            x0, [fp, #-0x10]
    // 0xeed758: StoreField: r2->field_f = r0
    //     0xeed758: stur            w0, [x2, #0xf]
    // 0xeed75c: r1 = <double>
    //     0xeed75c: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xeed760: r0 = CurveTween()
    //     0xeed760: bl              #0xb280f4  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0xeed764: mov             x1, x0
    // 0xeed768: r0 = Instance_Interval
    //     0xeed768: add             x0, PP, #0x8f, lsl #12  ; [pp+0x8fad0] Obj!Interval@129f9b1
    //     0xeed76c: ldr             x0, [x0, #0xad0]
    // 0xeed770: StoreField: r1->field_b = r0
    //     0xeed770: stur            w0, [x1, #0xb]
    // 0xeed774: mov             x2, x1
    // 0xeed778: ldur            x1, [fp, #-0x28]
    // 0xeed77c: r0 = chain()
    //     0xeed77c: bl              #0xb28080  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0xeed780: mov             x1, x0
    // 0xeed784: ldur            x2, [fp, #-0x18]
    // 0xeed788: r0 = animate()
    //     0xeed788: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xeed78c: ldur            x1, [fp, #-8]
    // 0xeed790: StoreField: r1->field_2f = r0
    //     0xeed790: stur            w0, [x1, #0x2f]
    //     0xeed794: ldurb           w16, [x1, #-1]
    //     0xeed798: ldurb           w17, [x0, #-1]
    //     0xeed79c: and             x16, x17, x16, lsr #2
    //     0xeed7a0: tst             x16, HEAP, lsr #32
    //     0xeed7a4: b.eq            #0xeed7ac
    //     0xeed7a8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xeed7ac: r0 = Null
    //     0xeed7ac: mov             x0, NULL
    // 0xeed7b0: LeaveFrame
    //     0xeed7b0: mov             SP, fp
    //     0xeed7b4: ldp             fp, lr, [SP], #0x10
    // 0xeed7b8: ret
    //     0xeed7b8: ret             
    // 0xeed7bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeed7bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeed7c0: b               #0xeed608
    // 0xeed7c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xeed7c4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xeed7c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xeed7c8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xeed7cc: r9 = _positionController
    //     0xeed7cc: add             x9, PP, #0x8f, lsl #12  ; [pp+0x8fa28] Field <RefreshIndicatorState._positionController@123083489>: late (offset: 0x1c)
    //     0xeed7d0: ldr             x9, [x9, #0xa28]
    // 0xeed7d4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xeed7d4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf3c3ec, size: 0x108
    // 0xf3c3ec: EnterFrame
    //     0xf3c3ec: stp             fp, lr, [SP, #-0x10]!
    //     0xf3c3f0: mov             fp, SP
    // 0xf3c3f4: AllocStack(0x20)
    //     0xf3c3f4: sub             SP, SP, #0x20
    // 0xf3c3f8: SetupParameters(RefreshIndicatorState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xf3c3f8: mov             x4, x1
    //     0xf3c3fc: mov             x3, x2
    //     0xf3c400: stur            x1, [fp, #-8]
    //     0xf3c404: stur            x2, [fp, #-0x10]
    // 0xf3c408: CheckStackOverflow
    //     0xf3c408: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf3c40c: cmp             SP, x16
    //     0xf3c410: b.ls            #0xf3c4e8
    // 0xf3c414: mov             x0, x3
    // 0xf3c418: r2 = Null
    //     0xf3c418: mov             x2, NULL
    // 0xf3c41c: r1 = Null
    //     0xf3c41c: mov             x1, NULL
    // 0xf3c420: r4 = 60
    //     0xf3c420: mov             x4, #0x3c
    // 0xf3c424: branchIfSmi(r0, 0xf3c430)
    //     0xf3c424: tbz             w0, #0, #0xf3c430
    // 0xf3c428: r4 = LoadClassIdInstr(r0)
    //     0xf3c428: ldur            x4, [x0, #-1]
    //     0xf3c42c: ubfx            x4, x4, #0xc, #0x14
    // 0xf3c430: r17 = 6440
    //     0xf3c430: mov             x17, #0x1928
    // 0xf3c434: cmp             x4, x17
    // 0xf3c438: b.eq            #0xf3c450
    // 0xf3c43c: r8 = RefreshIndicator
    //     0xf3c43c: add             x8, PP, #0x8f, lsl #12  ; [pp+0x8faa8] Type: RefreshIndicator
    //     0xf3c440: ldr             x8, [x8, #0xaa8]
    // 0xf3c444: r3 = Null
    //     0xf3c444: add             x3, PP, #0x8f, lsl #12  ; [pp+0x8fab0] Null
    //     0xf3c448: ldr             x3, [x3, #0xab0]
    // 0xf3c44c: r0 = RefreshIndicator()
    //     0xf3c44c: bl              #0xacfcec  ; IsType_RefreshIndicator_Stub
    // 0xf3c450: ldur            x3, [fp, #-8]
    // 0xf3c454: LoadField: r2 = r3->field_7
    //     0xf3c454: ldur            w2, [x3, #7]
    // 0xf3c458: DecompressPointer r2
    //     0xf3c458: add             x2, x2, HEAP, lsl #32
    // 0xf3c45c: ldur            x0, [fp, #-0x10]
    // 0xf3c460: r1 = Null
    //     0xf3c460: mov             x1, NULL
    // 0xf3c464: cmp             w2, NULL
    // 0xf3c468: b.eq            #0xf3c48c
    // 0xf3c46c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf3c46c: ldur            w4, [x2, #0x17]
    // 0xf3c470: DecompressPointer r4
    //     0xf3c470: add             x4, x4, HEAP, lsl #32
    // 0xf3c474: r8 = X0 bound StatefulWidget
    //     0xf3c474: add             x8, PP, #0x12, lsl #12  ; [pp+0x12498] TypeParameter: X0 bound StatefulWidget
    //     0xf3c478: ldr             x8, [x8, #0x498]
    // 0xf3c47c: LoadField: r9 = r4->field_7
    //     0xf3c47c: ldur            x9, [x4, #7]
    // 0xf3c480: r3 = Null
    //     0xf3c480: add             x3, PP, #0x8f, lsl #12  ; [pp+0x8fac0] Null
    //     0xf3c484: ldr             x3, [x3, #0xac0]
    // 0xf3c488: blr             x9
    // 0xf3c48c: ldur            x0, [fp, #-0x10]
    // 0xf3c490: LoadField: r1 = r0->field_27
    //     0xf3c490: ldur            w1, [x0, #0x27]
    // 0xf3c494: DecompressPointer r1
    //     0xf3c494: add             x1, x1, HEAP, lsl #32
    // 0xf3c498: ldur            x2, [fp, #-8]
    // 0xf3c49c: LoadField: r0 = r2->field_b
    //     0xf3c49c: ldur            w0, [x2, #0xb]
    // 0xf3c4a0: DecompressPointer r0
    //     0xf3c4a0: add             x0, x0, HEAP, lsl #32
    // 0xf3c4a4: cmp             w0, NULL
    // 0xf3c4a8: b.eq            #0xf3c4f0
    // 0xf3c4ac: LoadField: r3 = r0->field_27
    //     0xf3c4ac: ldur            w3, [x0, #0x27]
    // 0xf3c4b0: DecompressPointer r3
    //     0xf3c4b0: add             x3, x3, HEAP, lsl #32
    // 0xf3c4b4: r0 = LoadClassIdInstr(r1)
    //     0xf3c4b4: ldur            x0, [x1, #-1]
    //     0xf3c4b8: ubfx            x0, x0, #0xc, #0x14
    // 0xf3c4bc: stp             x3, x1, [SP]
    // 0xf3c4c0: mov             lr, x0
    // 0xf3c4c4: ldr             lr, [x21, lr, lsl #3]
    // 0xf3c4c8: blr             lr
    // 0xf3c4cc: tbz             w0, #4, #0xf3c4d8
    // 0xf3c4d0: ldur            x1, [fp, #-8]
    // 0xf3c4d4: r0 = _setupColorTween()
    //     0xf3c4d4: bl              #0xeed5e8  ; [package:flutter/src/material/refresh_indicator.dart] RefreshIndicatorState::_setupColorTween
    // 0xf3c4d8: r0 = Null
    //     0xf3c4d8: mov             x0, NULL
    // 0xf3c4dc: LeaveFrame
    //     0xf3c4dc: mov             SP, fp
    //     0xf3c4e0: ldp             fp, lr, [SP], #0x10
    // 0xf3c4e4: ret
    //     0xf3c4e4: ret             
    // 0xf3c4e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf3c4e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3c4ec: b               #0xf3c414
    // 0xf3c4f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf3c4f0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0xf7b0e4, size: 0x1a8
    // 0xf7b0e4: EnterFrame
    //     0xf7b0e4: stp             fp, lr, [SP, #-0x10]!
    //     0xf7b0e8: mov             fp, SP
    // 0xf7b0ec: AllocStack(0x10)
    //     0xf7b0ec: sub             SP, SP, #0x10
    // 0xf7b0f0: SetupParameters(RefreshIndicatorState this /* r1 => r2, fp-0x8 */)
    //     0xf7b0f0: mov             x2, x1
    //     0xf7b0f4: stur            x1, [fp, #-8]
    // 0xf7b0f8: CheckStackOverflow
    //     0xf7b0f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf7b0fc: cmp             SP, x16
    //     0xf7b100: b.ls            #0xf7b284
    // 0xf7b104: r1 = <double>
    //     0xf7b104: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf7b108: r0 = AnimationController()
    //     0xf7b108: bl              #0x87522c  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0xf7b10c: mov             x1, x0
    // 0xf7b110: ldur            x2, [fp, #-8]
    // 0xf7b114: stur            x0, [fp, #-0x10]
    // 0xf7b118: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xf7b118: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xf7b11c: r0 = AnimationController()
    //     0xf7b11c: bl              #0x874ea4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0xf7b120: ldur            x0, [fp, #-0x10]
    // 0xf7b124: ldur            x2, [fp, #-8]
    // 0xf7b128: StoreField: r2->field_1b = r0
    //     0xf7b128: stur            w0, [x2, #0x1b]
    //     0xf7b12c: ldurb           w16, [x2, #-1]
    //     0xf7b130: ldurb           w17, [x0, #-1]
    //     0xf7b134: and             x16, x17, x16, lsr #2
    //     0xf7b138: tst             x16, HEAP, lsr #32
    //     0xf7b13c: b.eq            #0xf7b144
    //     0xf7b140: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf7b144: r0 = LoadStaticField(0x79c)
    //     0xf7b144: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf7b148: ldr             x0, [x0, #0xf38]
    // 0xf7b14c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf7b150: cmp             w0, w16
    // 0xf7b154: b.ne            #0xf7b164
    // 0xf7b158: r2 = _kDragSizeFactorLimitTween
    //     0xf7b158: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8fad8] Field <RefreshIndicatorState._kDragSizeFactorLimitTween@123083489>: static late final (offset: 0x79c)
    //     0xf7b15c: ldr             x2, [x2, #0xad8]
    // 0xf7b160: r0 = InitLateFinalStaticField()
    //     0xf7b160: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xf7b164: mov             x1, x0
    // 0xf7b168: ldur            x2, [fp, #-0x10]
    // 0xf7b16c: r0 = animate()
    //     0xf7b16c: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xf7b170: ldur            x2, [fp, #-8]
    // 0xf7b174: StoreField: r2->field_23 = r0
    //     0xf7b174: stur            w0, [x2, #0x23]
    //     0xf7b178: ldurb           w16, [x2, #-1]
    //     0xf7b17c: ldurb           w17, [x0, #-1]
    //     0xf7b180: and             x16, x17, x16, lsr #2
    //     0xf7b184: tst             x16, HEAP, lsr #32
    //     0xf7b188: b.eq            #0xf7b190
    //     0xf7b18c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf7b190: LoadField: r0 = r2->field_1b
    //     0xf7b190: ldur            w0, [x2, #0x1b]
    // 0xf7b194: DecompressPointer r0
    //     0xf7b194: add             x0, x0, HEAP, lsl #32
    // 0xf7b198: stur            x0, [fp, #-0x10]
    // 0xf7b19c: r0 = LoadStaticField(0x798)
    //     0xf7b19c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf7b1a0: ldr             x0, [x0, #0xf30]
    // 0xf7b1a4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf7b1a8: cmp             w0, w16
    // 0xf7b1ac: b.ne            #0xf7b1bc
    // 0xf7b1b0: r2 = _threeQuarterTween
    //     0xf7b1b0: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8fae0] Field <RefreshIndicatorState._threeQuarterTween@123083489>: static late final (offset: 0x798)
    //     0xf7b1b4: ldr             x2, [x2, #0xae0]
    // 0xf7b1b8: r0 = InitLateFinalStaticField()
    //     0xf7b1b8: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xf7b1bc: mov             x1, x0
    // 0xf7b1c0: ldur            x2, [fp, #-0x10]
    // 0xf7b1c4: r0 = animate()
    //     0xf7b1c4: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xf7b1c8: ldur            x2, [fp, #-8]
    // 0xf7b1cc: StoreField: r2->field_2b = r0
    //     0xf7b1cc: stur            w0, [x2, #0x2b]
    //     0xf7b1d0: ldurb           w16, [x2, #-1]
    //     0xf7b1d4: ldurb           w17, [x0, #-1]
    //     0xf7b1d8: and             x16, x17, x16, lsr #2
    //     0xf7b1dc: tst             x16, HEAP, lsr #32
    //     0xf7b1e0: b.eq            #0xf7b1e8
    //     0xf7b1e4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf7b1e8: r1 = <double>
    //     0xf7b1e8: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf7b1ec: r0 = AnimationController()
    //     0xf7b1ec: bl              #0x87522c  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0xf7b1f0: mov             x1, x0
    // 0xf7b1f4: ldur            x2, [fp, #-8]
    // 0xf7b1f8: stur            x0, [fp, #-0x10]
    // 0xf7b1fc: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xf7b1fc: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xf7b200: r0 = AnimationController()
    //     0xf7b200: bl              #0x874ea4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0xf7b204: ldur            x0, [fp, #-0x10]
    // 0xf7b208: ldur            x1, [fp, #-8]
    // 0xf7b20c: StoreField: r1->field_1f = r0
    //     0xf7b20c: stur            w0, [x1, #0x1f]
    //     0xf7b210: ldurb           w16, [x1, #-1]
    //     0xf7b214: ldurb           w17, [x0, #-1]
    //     0xf7b218: and             x16, x17, x16, lsr #2
    //     0xf7b21c: tst             x16, HEAP, lsr #32
    //     0xf7b220: b.eq            #0xf7b228
    //     0xf7b224: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf7b228: r0 = LoadStaticField(0x7a0)
    //     0xf7b228: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf7b22c: ldr             x0, [x0, #0xf40]
    // 0xf7b230: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xf7b234: cmp             w0, w16
    // 0xf7b238: b.ne            #0xf7b248
    // 0xf7b23c: r2 = _oneToZeroTween
    //     0xf7b23c: add             x2, PP, #0x8f, lsl #12  ; [pp+0x8fae8] Field <RefreshIndicatorState._oneToZeroTween@123083489>: static late final (offset: 0x7a0)
    //     0xf7b240: ldr             x2, [x2, #0xae8]
    // 0xf7b244: r0 = InitLateFinalStaticField()
    //     0xf7b244: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xf7b248: mov             x1, x0
    // 0xf7b24c: ldur            x2, [fp, #-0x10]
    // 0xf7b250: r0 = animate()
    //     0xf7b250: bl              #0x915b2c  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xf7b254: ldur            x1, [fp, #-8]
    // 0xf7b258: StoreField: r1->field_27 = r0
    //     0xf7b258: stur            w0, [x1, #0x27]
    //     0xf7b25c: ldurb           w16, [x1, #-1]
    //     0xf7b260: ldurb           w17, [x0, #-1]
    //     0xf7b264: and             x16, x17, x16, lsr #2
    //     0xf7b268: tst             x16, HEAP, lsr #32
    //     0xf7b26c: b.eq            #0xf7b274
    //     0xf7b270: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf7b274: r0 = Null
    //     0xf7b274: mov             x0, NULL
    // 0xf7b278: LeaveFrame
    //     0xf7b278: mov             SP, fp
    //     0xf7b27c: ldp             fp, lr, [SP], #0x10
    // 0xf7b280: ret
    //     0xf7b280: ret             
    // 0xf7b284: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf7b284: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf7b288: b               #0xf7b104
  }
  static Animatable<double> _oneToZeroTween() {
    // ** addr: 0xf7b28c, size: 0x2c
    // 0xf7b28c: EnterFrame
    //     0xf7b28c: stp             fp, lr, [SP, #-0x10]!
    //     0xf7b290: mov             fp, SP
    // 0xf7b294: r1 = <double>
    //     0xf7b294: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf7b298: r0 = Tween()
    //     0xf7b298: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xf7b29c: r1 = 1.000000
    //     0xf7b29c: ldr             x1, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xf7b2a0: StoreField: r0->field_b = r1
    //     0xf7b2a0: stur            w1, [x0, #0xb]
    // 0xf7b2a4: r1 = 0.000000
    //     0xf7b2a4: ldr             x1, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xf7b2a8: StoreField: r0->field_f = r1
    //     0xf7b2a8: stur            w1, [x0, #0xf]
    // 0xf7b2ac: LeaveFrame
    //     0xf7b2ac: mov             SP, fp
    //     0xf7b2b0: ldp             fp, lr, [SP], #0x10
    // 0xf7b2b4: ret
    //     0xf7b2b4: ret             
  }
  static Animatable<double> _threeQuarterTween() {
    // ** addr: 0xf7b2b8, size: 0x30
    // 0xf7b2b8: EnterFrame
    //     0xf7b2b8: stp             fp, lr, [SP, #-0x10]!
    //     0xf7b2bc: mov             fp, SP
    // 0xf7b2c0: r1 = <double>
    //     0xf7b2c0: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf7b2c4: r0 = Tween()
    //     0xf7b2c4: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xf7b2c8: r1 = 0.000000
    //     0xf7b2c8: ldr             x1, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xf7b2cc: StoreField: r0->field_b = r1
    //     0xf7b2cc: stur            w1, [x0, #0xb]
    // 0xf7b2d0: r1 = 0.750000
    //     0xf7b2d0: add             x1, PP, #0x8e, lsl #12  ; [pp+0x8e168] 0.75
    //     0xf7b2d4: ldr             x1, [x1, #0x168]
    // 0xf7b2d8: StoreField: r0->field_f = r1
    //     0xf7b2d8: stur            w1, [x0, #0xf]
    // 0xf7b2dc: LeaveFrame
    //     0xf7b2dc: mov             SP, fp
    //     0xf7b2e0: ldp             fp, lr, [SP], #0x10
    // 0xf7b2e4: ret
    //     0xf7b2e4: ret             
  }
  static Animatable<double> _kDragSizeFactorLimitTween() {
    // ** addr: 0xf7b2e8, size: 0x30
    // 0xf7b2e8: EnterFrame
    //     0xf7b2e8: stp             fp, lr, [SP, #-0x10]!
    //     0xf7b2ec: mov             fp, SP
    // 0xf7b2f0: r1 = <double>
    //     0xf7b2f0: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf7b2f4: r0 = Tween()
    //     0xf7b2f4: bl              #0x915fe0  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xf7b2f8: r1 = 0.000000
    //     0xf7b2f8: ldr             x1, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xf7b2fc: StoreField: r0->field_b = r1
    //     0xf7b2fc: stur            w1, [x0, #0xb]
    // 0xf7b300: r1 = 1.500000
    //     0xf7b300: add             x1, PP, #0x7b, lsl #12  ; [pp+0x7b590] 1.5
    //     0xf7b304: ldr             x1, [x1, #0x590]
    // 0xf7b308: StoreField: r0->field_f = r1
    //     0xf7b308: stur            w1, [x0, #0xf]
    // 0xf7b30c: LeaveFrame
    //     0xf7b30c: mov             SP, fp
    //     0xf7b310: ldp             fp, lr, [SP], #0x10
    // 0xf7b314: ret
    //     0xf7b314: ret             
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10dd8ec, size: 0x8c
    // 0x10dd8ec: EnterFrame
    //     0x10dd8ec: stp             fp, lr, [SP, #-0x10]!
    //     0x10dd8f0: mov             fp, SP
    // 0x10dd8f4: AllocStack(0x8)
    //     0x10dd8f4: sub             SP, SP, #8
    // 0x10dd8f8: SetupParameters(RefreshIndicatorState this /* r1 => r0, fp-0x8 */)
    //     0x10dd8f8: mov             x0, x1
    //     0x10dd8fc: stur            x1, [fp, #-8]
    // 0x10dd900: CheckStackOverflow
    //     0x10dd900: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10dd904: cmp             SP, x16
    //     0x10dd908: b.ls            #0x10dd958
    // 0x10dd90c: LoadField: r1 = r0->field_1b
    //     0x10dd90c: ldur            w1, [x0, #0x1b]
    // 0x10dd910: DecompressPointer r1
    //     0x10dd910: add             x1, x1, HEAP, lsl #32
    // 0x10dd914: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10dd918: cmp             w1, w16
    // 0x10dd91c: b.eq            #0x10dd960
    // 0x10dd920: r0 = dispose()
    //     0x10dd920: bl              #0x9164f4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x10dd924: ldur            x0, [fp, #-8]
    // 0x10dd928: LoadField: r1 = r0->field_1f
    //     0x10dd928: ldur            w1, [x0, #0x1f]
    // 0x10dd92c: DecompressPointer r1
    //     0x10dd92c: add             x1, x1, HEAP, lsl #32
    // 0x10dd930: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10dd934: cmp             w1, w16
    // 0x10dd938: b.eq            #0x10dd96c
    // 0x10dd93c: r0 = dispose()
    //     0x10dd93c: bl              #0x9164f4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x10dd940: ldur            x1, [fp, #-8]
    // 0x10dd944: r0 = dispose()
    //     0x10dd944: bl              #0x10dd978  ; [dart:mixin_deduplication] _MixinApplication97&State&TickerProviderStateMixin::dispose
    // 0x10dd948: r0 = Null
    //     0x10dd948: mov             x0, NULL
    // 0x10dd94c: LeaveFrame
    //     0x10dd94c: mov             SP, fp
    //     0x10dd950: ldp             fp, lr, [SP], #0x10
    // 0x10dd954: ret
    //     0x10dd954: ret             
    // 0x10dd958: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10dd958: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10dd95c: b               #0x10dd90c
    // 0x10dd960: r9 = _positionController
    //     0x10dd960: add             x9, PP, #0x8f, lsl #12  ; [pp+0x8fa28] Field <RefreshIndicatorState._positionController@123083489>: late (offset: 0x1c)
    //     0x10dd964: ldr             x9, [x9, #0xa28]
    // 0x10dd968: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x10dd968: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x10dd96c: r9 = _scaleController
    //     0x10dd96c: add             x9, PP, #0x8f, lsl #12  ; [pp+0x8faa0] Field <RefreshIndicatorState._scaleController@123083489>: late (offset: 0x20)
    //     0x10dd970: ldr             x9, [x9, #0xaa0]
    // 0x10dd974: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x10dd974: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 6440, size: 0x54, field offset: 0xc
//   const constructor, 
class RefreshIndicator extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa27d4, size: 0x44
    // 0xfa27d4: EnterFrame
    //     0xfa27d4: stp             fp, lr, [SP, #-0x10]!
    //     0xfa27d8: mov             fp, SP
    // 0xfa27dc: mov             x0, x1
    // 0xfa27e0: r1 = <RefreshIndicator>
    //     0xfa27e0: add             x1, PP, #0x84, lsl #12  ; [pp+0x84948] TypeArguments: <RefreshIndicator>
    //     0xfa27e4: ldr             x1, [x1, #0x948]
    // 0xfa27e8: r0 = RefreshIndicatorState()
    //     0xfa27e8: bl              #0xfa2818  ; AllocateRefreshIndicatorStateStub -> RefreshIndicatorState (size=0x44)
    // 0xfa27ec: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa27f0: StoreField: r0->field_1b = r1
    //     0xfa27f0: stur            w1, [x0, #0x1b]
    // 0xfa27f4: StoreField: r0->field_1f = r1
    //     0xfa27f4: stur            w1, [x0, #0x1f]
    // 0xfa27f8: StoreField: r0->field_23 = r1
    //     0xfa27f8: stur            w1, [x0, #0x23]
    // 0xfa27fc: StoreField: r0->field_27 = r1
    //     0xfa27fc: stur            w1, [x0, #0x27]
    // 0xfa2800: StoreField: r0->field_2b = r1
    //     0xfa2800: stur            w1, [x0, #0x2b]
    // 0xfa2804: StoreField: r0->field_2f = r1
    //     0xfa2804: stur            w1, [x0, #0x2f]
    // 0xfa2808: StoreField: r0->field_3f = r1
    //     0xfa2808: stur            w1, [x0, #0x3f]
    // 0xfa280c: LeaveFrame
    //     0xfa280c: mov             SP, fp
    //     0xfa2810: ldp             fp, lr, [SP], #0x10
    // 0xfa2814: ret
    //     0xfa2814: ret             
  }
}

// class id: 8269, size: 0x14, field offset: 0x14
enum _IndicatorType extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11aa670, size: 0x64
    // 0x11aa670: EnterFrame
    //     0x11aa670: stp             fp, lr, [SP, #-0x10]!
    //     0x11aa674: mov             fp, SP
    // 0x11aa678: AllocStack(0x10)
    //     0x11aa678: sub             SP, SP, #0x10
    // 0x11aa67c: SetupParameters(_IndicatorType this /* r1 => r0, fp-0x8 */)
    //     0x11aa67c: mov             x0, x1
    //     0x11aa680: stur            x1, [fp, #-8]
    // 0x11aa684: CheckStackOverflow
    //     0x11aa684: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11aa688: cmp             SP, x16
    //     0x11aa68c: b.ls            #0x11aa6cc
    // 0x11aa690: r1 = Null
    //     0x11aa690: mov             x1, NULL
    // 0x11aa694: r2 = 4
    //     0x11aa694: mov             x2, #4
    // 0x11aa698: r0 = AllocateArray()
    //     0x11aa698: bl              #0x13df928  ; AllocateArrayStub
    // 0x11aa69c: r16 = "_IndicatorType."
    //     0x11aa69c: add             x16, PP, #0x84, lsl #12  ; [pp+0x84958] "_IndicatorType."
    //     0x11aa6a0: ldr             x16, [x16, #0x958]
    // 0x11aa6a4: StoreField: r0->field_f = r16
    //     0x11aa6a4: stur            w16, [x0, #0xf]
    // 0x11aa6a8: ldur            x1, [fp, #-8]
    // 0x11aa6ac: LoadField: r2 = r1->field_f
    //     0x11aa6ac: ldur            w2, [x1, #0xf]
    // 0x11aa6b0: DecompressPointer r2
    //     0x11aa6b0: add             x2, x2, HEAP, lsl #32
    // 0x11aa6b4: StoreField: r0->field_13 = r2
    //     0x11aa6b4: stur            w2, [x0, #0x13]
    // 0x11aa6b8: str             x0, [SP]
    // 0x11aa6bc: r0 = _interpolate()
    //     0x11aa6bc: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11aa6c0: LeaveFrame
    //     0x11aa6c0: mov             SP, fp
    //     0x11aa6c4: ldp             fp, lr, [SP], #0x10
    // 0x11aa6c8: ret
    //     0x11aa6c8: ret             
    // 0x11aa6cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11aa6cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11aa6d0: b               #0x11aa690
  }
}

// class id: 8270, size: 0x14, field offset: 0x14
enum RefreshIndicatorTriggerMode extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11aa60c, size: 0x64
    // 0x11aa60c: EnterFrame
    //     0x11aa60c: stp             fp, lr, [SP, #-0x10]!
    //     0x11aa610: mov             fp, SP
    // 0x11aa614: AllocStack(0x10)
    //     0x11aa614: sub             SP, SP, #0x10
    // 0x11aa618: SetupParameters(RefreshIndicatorTriggerMode this /* r1 => r0, fp-0x8 */)
    //     0x11aa618: mov             x0, x1
    //     0x11aa61c: stur            x1, [fp, #-8]
    // 0x11aa620: CheckStackOverflow
    //     0x11aa620: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11aa624: cmp             SP, x16
    //     0x11aa628: b.ls            #0x11aa668
    // 0x11aa62c: r1 = Null
    //     0x11aa62c: mov             x1, NULL
    // 0x11aa630: r2 = 4
    //     0x11aa630: mov             x2, #4
    // 0x11aa634: r0 = AllocateArray()
    //     0x11aa634: bl              #0x13df928  ; AllocateArrayStub
    // 0x11aa638: r16 = "RefreshIndicatorTriggerMode."
    //     0x11aa638: add             x16, PP, #0x84, lsl #12  ; [pp+0x84950] "RefreshIndicatorTriggerMode."
    //     0x11aa63c: ldr             x16, [x16, #0x950]
    // 0x11aa640: StoreField: r0->field_f = r16
    //     0x11aa640: stur            w16, [x0, #0xf]
    // 0x11aa644: ldur            x1, [fp, #-8]
    // 0x11aa648: LoadField: r2 = r1->field_f
    //     0x11aa648: ldur            w2, [x1, #0xf]
    // 0x11aa64c: DecompressPointer r2
    //     0x11aa64c: add             x2, x2, HEAP, lsl #32
    // 0x11aa650: StoreField: r0->field_13 = r2
    //     0x11aa650: stur            w2, [x0, #0x13]
    // 0x11aa654: str             x0, [SP]
    // 0x11aa658: r0 = _interpolate()
    //     0x11aa658: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11aa65c: LeaveFrame
    //     0x11aa65c: mov             SP, fp
    //     0x11aa660: ldp             fp, lr, [SP], #0x10
    // 0x11aa664: ret
    //     0x11aa664: ret             
    // 0x11aa668: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11aa668: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11aa66c: b               #0x11aa62c
  }
}

// class id: 8271, size: 0x14, field offset: 0x14
enum RefreshIndicatorStatus extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11aa5a8, size: 0x64
    // 0x11aa5a8: EnterFrame
    //     0x11aa5a8: stp             fp, lr, [SP, #-0x10]!
    //     0x11aa5ac: mov             fp, SP
    // 0x11aa5b0: AllocStack(0x10)
    //     0x11aa5b0: sub             SP, SP, #0x10
    // 0x11aa5b4: SetupParameters(RefreshIndicatorStatus this /* r1 => r0, fp-0x8 */)
    //     0x11aa5b4: mov             x0, x1
    //     0x11aa5b8: stur            x1, [fp, #-8]
    // 0x11aa5bc: CheckStackOverflow
    //     0x11aa5bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11aa5c0: cmp             SP, x16
    //     0x11aa5c4: b.ls            #0x11aa604
    // 0x11aa5c8: r1 = Null
    //     0x11aa5c8: mov             x1, NULL
    // 0x11aa5cc: r2 = 4
    //     0x11aa5cc: mov             x2, #4
    // 0x11aa5d0: r0 = AllocateArray()
    //     0x11aa5d0: bl              #0x13df928  ; AllocateArrayStub
    // 0x11aa5d4: r16 = "RefreshIndicatorStatus."
    //     0x11aa5d4: add             x16, PP, #0x99, lsl #12  ; [pp+0x99050] "RefreshIndicatorStatus."
    //     0x11aa5d8: ldr             x16, [x16, #0x50]
    // 0x11aa5dc: StoreField: r0->field_f = r16
    //     0x11aa5dc: stur            w16, [x0, #0xf]
    // 0x11aa5e0: ldur            x1, [fp, #-8]
    // 0x11aa5e4: LoadField: r2 = r1->field_f
    //     0x11aa5e4: ldur            w2, [x1, #0xf]
    // 0x11aa5e8: DecompressPointer r2
    //     0x11aa5e8: add             x2, x2, HEAP, lsl #32
    // 0x11aa5ec: StoreField: r0->field_13 = r2
    //     0x11aa5ec: stur            w2, [x0, #0x13]
    // 0x11aa5f0: str             x0, [SP]
    // 0x11aa5f4: r0 = _interpolate()
    //     0x11aa5f4: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11aa5f8: LeaveFrame
    //     0x11aa5f8: mov             SP, fp
    //     0x11aa5fc: ldp             fp, lr, [SP], #0x10
    // 0x11aa600: ret
    //     0x11aa600: ret             
    // 0x11aa604: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11aa604: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11aa608: b               #0x11aa5c8
  }
}
