// lib: , url: package:flutter/src/material/radio_list_tile.dart

// class id: 1048934, size: 0x8
class :: {
}

// class id: 3264, size: 0x10, field offset: 0xc
class _RadioRegistry<X0> extends RadioGroupRegistry<X0> {

  get _ groupValue(/* No info */) {
    // ** addr: 0xd32ff4, size: 0x38
    // 0xd32ff4: EnterFrame
    //     0xd32ff4: stp             fp, lr, [SP, #-0x10]!
    //     0xd32ff8: mov             fp, SP
    // 0xd32ffc: CheckStackOverflow
    //     0xd32ffc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd33000: cmp             SP, x16
    //     0xd33004: b.ls            #0xd33024
    // 0xd33008: LoadField: r0 = r1->field_b
    //     0xd33008: ldur            w0, [x1, #0xb]
    // 0xd3300c: DecompressPointer r0
    //     0xd3300c: add             x0, x0, HEAP, lsl #32
    // 0xd33010: mov             x1, x0
    // 0xd33014: r0 = effectiveGroupValue()
    //     0xd33014: bl              #0xd330bc  ; [package:flutter/src/material/radio_list_tile.dart] _RadioListTileState::effectiveGroupValue
    // 0xd33018: LeaveFrame
    //     0xd33018: mov             SP, fp
    //     0xd3301c: ldp             fp, lr, [SP], #0x10
    // 0xd33020: ret
    //     0xd33020: ret             
    // 0xd33024: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd33024: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd33028: b               #0xd33008
  }
  get _ onChanged(/* No info */) {
    // ** addr: 0xd70454, size: 0x64
    // 0xd70454: EnterFrame
    //     0xd70454: stp             fp, lr, [SP, #-0x10]!
    //     0xd70458: mov             fp, SP
    // 0xd7045c: AllocStack(0x8)
    //     0xd7045c: sub             SP, SP, #8
    // 0xd70460: LoadField: r2 = r1->field_b
    //     0xd70460: ldur            w2, [x1, #0xb]
    // 0xd70464: DecompressPointer r2
    //     0xd70464: add             x2, x2, HEAP, lsl #32
    // 0xd70468: LoadField: r0 = r1->field_7
    //     0xd70468: ldur            w0, [x1, #7]
    // 0xd7046c: DecompressPointer r0
    //     0xd7046c: add             x0, x0, HEAP, lsl #32
    // 0xd70470: stur            x0, [fp, #-8]
    // 0xd70474: r1 = Function 'handleChange':.
    //     0xd70474: add             x1, PP, #0xd5, lsl #12  ; [pp+0xd5068] AnonymousClosure: (0xd33370), in [package:flutter/src/material/radio_list_tile.dart] _RadioListTileState::handleChange (0xd33250)
    //     0xd70478: ldr             x1, [x1, #0x68]
    // 0xd7047c: r0 = AllocateClosure()
    //     0xd7047c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd70480: ldur            x2, [fp, #-8]
    // 0xd70484: mov             x3, x0
    // 0xd70488: r1 = Null
    //     0xd70488: mov             x1, NULL
    // 0xd7048c: stur            x3, [fp, #-8]
    // 0xd70490: r8 = (dynamic this, X0?) => void?
    //     0xd70490: add             x8, PP, #0x28, lsl #12  ; [pp+0x282e0] FunctionType: (dynamic this, X0?) => void?
    //     0xd70494: ldr             x8, [x8, #0x2e0]
    // 0xd70498: LoadField: r9 = r8->field_7
    //     0xd70498: ldur            x9, [x8, #7]
    // 0xd7049c: r3 = Null
    //     0xd7049c: add             x3, PP, #0xd5, lsl #12  ; [pp+0xd50a0] Null
    //     0xd704a0: ldr             x3, [x3, #0xa0]
    // 0xd704a4: blr             x9
    // 0xd704a8: ldur            x0, [fp, #-8]
    // 0xd704ac: LeaveFrame
    //     0xd704ac: mov             SP, fp
    //     0xd704b0: ldp             fp, lr, [SP], #0x10
    // 0xd704b4: ret
    //     0xd704b4: ret             
  }
}

// class id: 5718, size: 0x20, field offset: 0x18
class _RadioListTileState<C1X0> extends _MixinApplication93&State&RadioClient<C1X0> {

  late final _RadioRegistry<C1X0> _radioRegistry; // offset: 0x1c

  _ build(/* No info */) {
    // ** addr: 0xd32af0, size: 0x480
    // 0xd32af0: EnterFrame
    //     0xd32af0: stp             fp, lr, [SP, #-0x10]!
    //     0xd32af4: mov             fp, SP
    // 0xd32af8: AllocStack(0x38)
    //     0xd32af8: sub             SP, SP, #0x38
    // 0xd32afc: SetupParameters(_RadioListTileState<C1X0> this /* r1 => r2, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */)
    //     0xd32afc: mov             x0, x2
    //     0xd32b00: stur            x2, [fp, #-0x18]
    //     0xd32b04: mov             x2, x1
    //     0xd32b08: stur            x1, [fp, #-0x10]
    // 0xd32b0c: CheckStackOverflow
    //     0xd32b0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd32b10: cmp             SP, x16
    //     0xd32b14: b.ls            #0xd32f40
    // 0xd32b18: LoadField: r1 = r2->field_b
    //     0xd32b18: ldur            w1, [x2, #0xb]
    // 0xd32b1c: DecompressPointer r1
    //     0xd32b1c: add             x1, x1, HEAP, lsl #32
    // 0xd32b20: cmp             w1, NULL
    // 0xd32b24: b.eq            #0xd32f48
    // 0xd32b28: LoadField: r3 = r1->field_8f
    //     0xd32b28: ldur            w3, [x1, #0x8f]
    // 0xd32b2c: DecompressPointer r3
    //     0xd32b2c: add             x3, x3, HEAP, lsl #32
    // 0xd32b30: LoadField: r4 = r3->field_7
    //     0xd32b30: ldur            x4, [x3, #7]
    // 0xd32b34: cmp             x4, #0
    // 0xd32b38: b.gt            #0xd32c68
    // 0xd32b3c: LoadField: r3 = r1->field_f
    //     0xd32b3c: ldur            w3, [x1, #0xf]
    // 0xd32b40: DecompressPointer r3
    //     0xd32b40: add             x3, x3, HEAP, lsl #32
    // 0xd32b44: mov             x1, x2
    // 0xd32b48: stur            x3, [fp, #-8]
    // 0xd32b4c: LoadField: r0 = r1->field_1b
    //     0xd32b4c: ldur            w0, [x1, #0x1b]
    // 0xd32b50: DecompressPointer r0
    //     0xd32b50: add             x0, x0, HEAP, lsl #32
    // 0xd32b54: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd32b58: cmp             w0, w16
    // 0xd32b5c: b.ne            #0xd32b6c
    // 0xd32b60: r2 = _radioRegistry
    //     0xd32b60: add             x2, PP, #0xd4, lsl #12  ; [pp+0xd47a0] Field <_RadioListTileState@116361843._radioRegistry@116361843>: late final (offset: 0x1c)
    //     0xd32b64: ldr             x2, [x2, #0x7a0]
    // 0xd32b68: r0 = InitLateFinalInstanceField()
    //     0xd32b68: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd32b6c: LoadField: r1 = r0->field_b
    //     0xd32b6c: ldur            w1, [x0, #0xb]
    // 0xd32b70: DecompressPointer r1
    //     0xd32b70: add             x1, x1, HEAP, lsl #32
    // 0xd32b74: r0 = effectiveGroupValue()
    //     0xd32b74: bl              #0xd330bc  ; [package:flutter/src/material/radio_list_tile.dart] _RadioListTileState::effectiveGroupValue
    // 0xd32b78: mov             x2, x0
    // 0xd32b7c: ldur            x0, [fp, #-0x10]
    // 0xd32b80: stur            x2, [fp, #-0x20]
    // 0xd32b84: LoadField: r1 = r0->field_b
    //     0xd32b84: ldur            w1, [x0, #0xb]
    // 0xd32b88: DecompressPointer r1
    //     0xd32b88: add             x1, x1, HEAP, lsl #32
    // 0xd32b8c: cmp             w1, NULL
    // 0xd32b90: b.eq            #0xd32f4c
    // 0xd32b94: mov             x1, x0
    // 0xd32b98: r0 = _enabled()
    //     0xd32b98: bl              #0xd33044  ; [package:flutter/src/material/radio_list_tile.dart] _RadioListTileState::_enabled
    // 0xd32b9c: mov             x4, x0
    // 0xd32ba0: ldur            x0, [fp, #-0x10]
    // 0xd32ba4: stur            x4, [fp, #-0x30]
    // 0xd32ba8: LoadField: r5 = r0->field_1b
    //     0xd32ba8: ldur            w5, [x0, #0x1b]
    // 0xd32bac: DecompressPointer r5
    //     0xd32bac: add             x5, x5, HEAP, lsl #32
    // 0xd32bb0: stur            x5, [fp, #-0x28]
    // 0xd32bb4: LoadField: r1 = r0->field_b
    //     0xd32bb4: ldur            w1, [x0, #0xb]
    // 0xd32bb8: DecompressPointer r1
    //     0xd32bb8: add             x1, x1, HEAP, lsl #32
    // 0xd32bbc: cmp             w1, NULL
    // 0xd32bc0: b.eq            #0xd32f50
    // 0xd32bc4: LoadField: r2 = r0->field_7
    //     0xd32bc4: ldur            w2, [x0, #7]
    // 0xd32bc8: DecompressPointer r2
    //     0xd32bc8: add             x2, x2, HEAP, lsl #32
    // 0xd32bcc: r1 = Null
    //     0xd32bcc: mov             x1, NULL
    // 0xd32bd0: r3 = <C1X0>
    //     0xd32bd0: add             x3, PP, #0x11, lsl #12  ; [pp+0x11880] TypeArguments: <C1X0>
    //     0xd32bd4: ldr             x3, [x3, #0x880]
    // 0xd32bd8: r0 = Null
    //     0xd32bd8: mov             x0, NULL
    // 0xd32bdc: cmp             x2, x0
    // 0xd32be0: b.eq            #0xd32bf0
    // 0xd32be4: r30 = InstantiateTypeArgumentsStub
    //     0xd32be4: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0xd32be8: LoadField: r30 = r30->field_7
    //     0xd32be8: ldur            lr, [lr, #7]
    // 0xd32bec: blr             lr
    // 0xd32bf0: mov             x1, x0
    // 0xd32bf4: r0 = Radio()
    //     0xd32bf4: bl              #0xd33038  ; AllocateRadioStub -> Radio<X0> (size=0x68)
    // 0xd32bf8: mov             x1, x0
    // 0xd32bfc: ldur            x0, [fp, #-8]
    // 0xd32c00: stur            x1, [fp, #-0x38]
    // 0xd32c04: StoreField: r1->field_f = r0
    //     0xd32c04: stur            w0, [x1, #0xf]
    // 0xd32c08: ldur            x0, [fp, #-0x20]
    // 0xd32c0c: StoreField: r1->field_13 = r0
    //     0xd32c0c: stur            w0, [x1, #0x13]
    // 0xd32c10: r0 = false
    //     0xd32c10: add             x0, NULL, #0x30  ; false
    // 0xd32c14: StoreField: r1->field_1f = r0
    //     0xd32c14: stur            w0, [x1, #0x1f]
    // 0xd32c18: r2 = Instance_MaterialTapTargetSize
    //     0xd32c18: add             x2, PP, #0x18, lsl #12  ; [pp+0x18318] Obj!MaterialTapTargetSize@12c4ba1
    //     0xd32c1c: ldr             x2, [x2, #0x318]
    // 0xd32c20: StoreField: r1->field_2b = r2
    //     0xd32c20: stur            w2, [x1, #0x2b]
    // 0xd32c24: StoreField: r1->field_47 = r0
    //     0xd32c24: stur            w0, [x1, #0x47]
    // 0xd32c28: ldur            x2, [fp, #-0x30]
    // 0xd32c2c: StoreField: r1->field_57 = r2
    //     0xd32c2c: stur            w2, [x1, #0x57]
    // 0xd32c30: ldur            x2, [fp, #-0x28]
    // 0xd32c34: StoreField: r1->field_4f = r2
    //     0xd32c34: stur            w2, [x1, #0x4f]
    // 0xd32c38: r2 = Instance__RadioType
    //     0xd32c38: add             x2, PP, #0xd4, lsl #12  ; [pp+0xd47a8] Obj!_RadioType@12c5241
    //     0xd32c3c: ldr             x2, [x2, #0x7a8]
    // 0xd32c40: StoreField: r1->field_53 = r2
    //     0xd32c40: stur            w2, [x1, #0x53]
    // 0xd32c44: StoreField: r1->field_4b = r0
    //     0xd32c44: stur            w0, [x1, #0x4b]
    // 0xd32c48: r0 = ExcludeFocus()
    //     0xd32c48: bl              #0xd3302c  ; AllocateExcludeFocusStub -> ExcludeFocus (size=0x14)
    // 0xd32c4c: mov             x1, x0
    // 0xd32c50: r0 = true
    //     0xd32c50: add             x0, NULL, #0x20  ; true
    // 0xd32c54: StoreField: r1->field_b = r0
    //     0xd32c54: stur            w0, [x1, #0xb]
    // 0xd32c58: ldur            x0, [fp, #-0x38]
    // 0xd32c5c: StoreField: r1->field_f = r0
    //     0xd32c5c: stur            w0, [x1, #0xf]
    // 0xd32c60: mov             x2, x1
    // 0xd32c64: b               #0xd32d9c
    // 0xd32c68: mov             x3, x2
    // 0xd32c6c: r0 = true
    //     0xd32c6c: add             x0, NULL, #0x20  ; true
    // 0xd32c70: r2 = Instance_MaterialTapTargetSize
    //     0xd32c70: add             x2, PP, #0x18, lsl #12  ; [pp+0x18318] Obj!MaterialTapTargetSize@12c4ba1
    //     0xd32c74: ldr             x2, [x2, #0x318]
    // 0xd32c78: mov             x1, x3
    // 0xd32c7c: r0 = radioValue()
    //     0xd32c7c: bl              #0x12a071c  ; [package:flutter/src/widgets/raw_radio.dart] _RawRadioState::radioValue
    // 0xd32c80: ldur            x1, [fp, #-0x10]
    // 0xd32c84: stur            x0, [fp, #-8]
    // 0xd32c88: LoadField: r0 = r1->field_1b
    //     0xd32c88: ldur            w0, [x1, #0x1b]
    // 0xd32c8c: DecompressPointer r0
    //     0xd32c8c: add             x0, x0, HEAP, lsl #32
    // 0xd32c90: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd32c94: cmp             w0, w16
    // 0xd32c98: b.ne            #0xd32ca8
    // 0xd32c9c: r2 = _radioRegistry
    //     0xd32c9c: add             x2, PP, #0xd4, lsl #12  ; [pp+0xd47a0] Field <_RadioListTileState@116361843._radioRegistry@116361843>: late final (offset: 0x1c)
    //     0xd32ca0: ldr             x2, [x2, #0x7a0]
    // 0xd32ca4: r0 = InitLateFinalInstanceField()
    //     0xd32ca4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd32ca8: mov             x1, x0
    // 0xd32cac: r0 = groupValue()
    //     0xd32cac: bl              #0xd32ff4  ; [package:flutter/src/material/radio_list_tile.dart] _RadioRegistry::groupValue
    // 0xd32cb0: mov             x2, x0
    // 0xd32cb4: ldur            x0, [fp, #-0x10]
    // 0xd32cb8: stur            x2, [fp, #-0x20]
    // 0xd32cbc: LoadField: r1 = r0->field_b
    //     0xd32cbc: ldur            w1, [x0, #0xb]
    // 0xd32cc0: DecompressPointer r1
    //     0xd32cc0: add             x1, x1, HEAP, lsl #32
    // 0xd32cc4: cmp             w1, NULL
    // 0xd32cc8: b.eq            #0xd32f54
    // 0xd32ccc: mov             x1, x0
    // 0xd32cd0: r0 = _enabled()
    //     0xd32cd0: bl              #0xd33044  ; [package:flutter/src/material/radio_list_tile.dart] _RadioListTileState::_enabled
    // 0xd32cd4: mov             x4, x0
    // 0xd32cd8: ldur            x0, [fp, #-0x10]
    // 0xd32cdc: stur            x4, [fp, #-0x30]
    // 0xd32ce0: LoadField: r5 = r0->field_1b
    //     0xd32ce0: ldur            w5, [x0, #0x1b]
    // 0xd32ce4: DecompressPointer r5
    //     0xd32ce4: add             x5, x5, HEAP, lsl #32
    // 0xd32ce8: stur            x5, [fp, #-0x28]
    // 0xd32cec: LoadField: r1 = r0->field_b
    //     0xd32cec: ldur            w1, [x0, #0xb]
    // 0xd32cf0: DecompressPointer r1
    //     0xd32cf0: add             x1, x1, HEAP, lsl #32
    // 0xd32cf4: cmp             w1, NULL
    // 0xd32cf8: b.eq            #0xd32f58
    // 0xd32cfc: LoadField: r2 = r0->field_7
    //     0xd32cfc: ldur            w2, [x0, #7]
    // 0xd32d00: DecompressPointer r2
    //     0xd32d00: add             x2, x2, HEAP, lsl #32
    // 0xd32d04: r1 = Null
    //     0xd32d04: mov             x1, NULL
    // 0xd32d08: r3 = <C1X0>
    //     0xd32d08: add             x3, PP, #0x11, lsl #12  ; [pp+0x11880] TypeArguments: <C1X0>
    //     0xd32d0c: ldr             x3, [x3, #0x880]
    // 0xd32d10: r0 = Null
    //     0xd32d10: mov             x0, NULL
    // 0xd32d14: cmp             x2, x0
    // 0xd32d18: b.eq            #0xd32d28
    // 0xd32d1c: r30 = InstantiateTypeArgumentsStub
    //     0xd32d1c: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0xd32d20: LoadField: r30 = r30->field_7
    //     0xd32d20: ldur            lr, [lr, #7]
    // 0xd32d24: blr             lr
    // 0xd32d28: mov             x1, x0
    // 0xd32d2c: r0 = Radio()
    //     0xd32d2c: bl              #0xd33038  ; AllocateRadioStub -> Radio<X0> (size=0x68)
    // 0xd32d30: mov             x1, x0
    // 0xd32d34: ldur            x0, [fp, #-8]
    // 0xd32d38: stur            x1, [fp, #-0x38]
    // 0xd32d3c: StoreField: r1->field_f = r0
    //     0xd32d3c: stur            w0, [x1, #0xf]
    // 0xd32d40: ldur            x0, [fp, #-0x20]
    // 0xd32d44: StoreField: r1->field_13 = r0
    //     0xd32d44: stur            w0, [x1, #0x13]
    // 0xd32d48: r0 = false
    //     0xd32d48: add             x0, NULL, #0x30  ; false
    // 0xd32d4c: StoreField: r1->field_1f = r0
    //     0xd32d4c: stur            w0, [x1, #0x1f]
    // 0xd32d50: r2 = Instance_MaterialTapTargetSize
    //     0xd32d50: add             x2, PP, #0x18, lsl #12  ; [pp+0x18318] Obj!MaterialTapTargetSize@12c4ba1
    //     0xd32d54: ldr             x2, [x2, #0x318]
    // 0xd32d58: StoreField: r1->field_2b = r2
    //     0xd32d58: stur            w2, [x1, #0x2b]
    // 0xd32d5c: StoreField: r1->field_47 = r0
    //     0xd32d5c: stur            w0, [x1, #0x47]
    // 0xd32d60: StoreField: r1->field_4b = r0
    //     0xd32d60: stur            w0, [x1, #0x4b]
    // 0xd32d64: ldur            x2, [fp, #-0x30]
    // 0xd32d68: StoreField: r1->field_57 = r2
    //     0xd32d68: stur            w2, [x1, #0x57]
    // 0xd32d6c: ldur            x2, [fp, #-0x28]
    // 0xd32d70: StoreField: r1->field_4f = r2
    //     0xd32d70: stur            w2, [x1, #0x4f]
    // 0xd32d74: r2 = Instance__RadioType
    //     0xd32d74: add             x2, PP, #0xd4, lsl #12  ; [pp+0xd47b0] Obj!_RadioType@12c5221
    //     0xd32d78: ldr             x2, [x2, #0x7b0]
    // 0xd32d7c: StoreField: r1->field_53 = r2
    //     0xd32d7c: stur            w2, [x1, #0x53]
    // 0xd32d80: r0 = ExcludeFocus()
    //     0xd32d80: bl              #0xd3302c  ; AllocateExcludeFocusStub -> ExcludeFocus (size=0x14)
    // 0xd32d84: mov             x1, x0
    // 0xd32d88: r0 = true
    //     0xd32d88: add             x0, NULL, #0x20  ; true
    // 0xd32d8c: StoreField: r1->field_b = r0
    //     0xd32d8c: stur            w0, [x1, #0xb]
    // 0xd32d90: ldur            x0, [fp, #-0x38]
    // 0xd32d94: StoreField: r1->field_f = r0
    //     0xd32d94: stur            w0, [x1, #0xf]
    // 0xd32d98: mov             x2, x1
    // 0xd32d9c: d0 = 1.000000
    //     0xd32d9c: fmov            d0, #1.00000000
    // 0xd32da0: stur            x2, [fp, #-8]
    // 0xd32da4: fcmp            d0, d0
    // 0xd32da8: b.eq            #0xd32dd0
    // 0xd32dac: r0 = Transform()
    //     0xd32dac: bl              #0xd30150  ; AllocateTransformStub -> Transform (size=0x24)
    // 0xd32db0: mov             x1, x0
    // 0xd32db4: ldur            x2, [fp, #-8]
    // 0xd32db8: d0 = 1.000000
    //     0xd32db8: fmov            d0, #1.00000000
    // 0xd32dbc: stur            x0, [fp, #-0x20]
    // 0xd32dc0: r4 = const [0, 0x3, 0, 0x3, null]
    //     0xd32dc0: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0xd32dc4: r0 = Transform.scale()
    //     0xd32dc4: bl              #0xd2ffac  ; [package:flutter/src/widgets/basic.dart] Transform::Transform.scale
    // 0xd32dc8: ldur            x2, [fp, #-0x20]
    // 0xd32dcc: b               #0xd32dd4
    // 0xd32dd0: ldur            x2, [fp, #-8]
    // 0xd32dd4: ldur            x0, [fp, #-0x10]
    // 0xd32dd8: ldur            x1, [fp, #-0x18]
    // 0xd32ddc: stur            x2, [fp, #-8]
    // 0xd32de0: r0 = of()
    //     0xd32de0: bl              #0xd1a0e4  ; [package:flutter/src/material/list_tile_theme.dart] ListTileTheme::of
    // 0xd32de4: ldur            x0, [fp, #-0x10]
    // 0xd32de8: LoadField: r1 = r0->field_b
    //     0xd32de8: ldur            w1, [x0, #0xb]
    // 0xd32dec: DecompressPointer r1
    //     0xd32dec: add             x1, x1, HEAP, lsl #32
    // 0xd32df0: cmp             w1, NULL
    // 0xd32df4: b.eq            #0xd32f5c
    // 0xd32df8: ldur            x1, [fp, #-0x18]
    // 0xd32dfc: r0 = of()
    //     0xd32dfc: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd32e00: ldur            x1, [fp, #-0x18]
    // 0xd32e04: stur            x0, [fp, #-0x18]
    // 0xd32e08: r0 = of()
    //     0xd32e08: bl              #0xd32f98  ; [package:flutter/src/material/radio_theme.dart] RadioTheme::of
    // 0xd32e0c: ldur            x0, [fp, #-0x10]
    // 0xd32e10: LoadField: r1 = r0->field_b
    //     0xd32e10: ldur            w1, [x0, #0xb]
    // 0xd32e14: DecompressPointer r1
    //     0xd32e14: add             x1, x1, HEAP, lsl #32
    // 0xd32e18: cmp             w1, NULL
    // 0xd32e1c: b.eq            #0xd32f60
    // 0xd32e20: ldur            x2, [fp, #-0x18]
    // 0xd32e24: LoadField: r3 = r2->field_3f
    //     0xd32e24: ldur            w3, [x2, #0x3f]
    // 0xd32e28: DecompressPointer r3
    //     0xd32e28: add             x3, x3, HEAP, lsl #32
    // 0xd32e2c: LoadField: r2 = r3->field_2b
    //     0xd32e2c: ldur            w2, [x3, #0x2b]
    // 0xd32e30: DecompressPointer r2
    //     0xd32e30: add             x2, x2, HEAP, lsl #32
    // 0xd32e34: stur            x2, [fp, #-0x20]
    // 0xd32e38: LoadField: r3 = r1->field_3b
    //     0xd32e38: ldur            w3, [x1, #0x3b]
    // 0xd32e3c: DecompressPointer r3
    //     0xd32e3c: add             x3, x3, HEAP, lsl #32
    // 0xd32e40: mov             x1, x0
    // 0xd32e44: stur            x3, [fp, #-0x18]
    // 0xd32e48: r0 = _enabled()
    //     0xd32e48: bl              #0xd33044  ; [package:flutter/src/material/radio_list_tile.dart] _RadioListTileState::_enabled
    // 0xd32e4c: mov             x2, x0
    // 0xd32e50: ldur            x0, [fp, #-0x10]
    // 0xd32e54: stur            x2, [fp, #-0x28]
    // 0xd32e58: LoadField: r1 = r0->field_b
    //     0xd32e58: ldur            w1, [x0, #0xb]
    // 0xd32e5c: DecompressPointer r1
    //     0xd32e5c: add             x1, x1, HEAP, lsl #32
    // 0xd32e60: cmp             w1, NULL
    // 0xd32e64: b.eq            #0xd32f64
    // 0xd32e68: mov             x1, x0
    // 0xd32e6c: r0 = _enabled()
    //     0xd32e6c: bl              #0xd33044  ; [package:flutter/src/material/radio_list_tile.dart] _RadioListTileState::_enabled
    // 0xd32e70: tbnz            w0, #4, #0xd32e8c
    // 0xd32e74: ldur            x2, [fp, #-0x10]
    // 0xd32e78: r1 = Function '_handleListTileTap@116361843':.
    //     0xd32e78: add             x1, PP, #0xd4, lsl #12  ; [pp+0xd47b8] AnonymousClosure: (0xd3313c), in [package:flutter/src/material/radio_list_tile.dart] _RadioListTileState::_handleListTileTap (0xd33174)
    //     0xd32e7c: ldr             x1, [x1, #0x7b8]
    // 0xd32e80: r0 = AllocateClosure()
    //     0xd32e80: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd32e84: mov             x6, x0
    // 0xd32e88: b               #0xd32e90
    // 0xd32e8c: r6 = Null
    //     0xd32e8c: mov             x6, NULL
    // 0xd32e90: ldur            x0, [fp, #-0x10]
    // 0xd32e94: ldur            x5, [fp, #-8]
    // 0xd32e98: ldur            x4, [fp, #-0x18]
    // 0xd32e9c: ldur            x2, [fp, #-0x28]
    // 0xd32ea0: ldur            x3, [fp, #-0x20]
    // 0xd32ea4: stur            x6, [fp, #-0x30]
    // 0xd32ea8: LoadField: r1 = r0->field_b
    //     0xd32ea8: ldur            w1, [x0, #0xb]
    // 0xd32eac: DecompressPointer r1
    //     0xd32eac: add             x1, x1, HEAP, lsl #32
    // 0xd32eb0: cmp             w1, NULL
    // 0xd32eb4: b.eq            #0xd32f68
    // 0xd32eb8: mov             x1, x0
    // 0xd32ebc: r0 = focusNode()
    //     0xd32ebc: bl              #0x12a1e78  ; [package:flutter/src/material/radio_list_tile.dart] _RadioListTileState::focusNode
    // 0xd32ec0: mov             x1, x0
    // 0xd32ec4: ldur            x0, [fp, #-0x10]
    // 0xd32ec8: stur            x1, [fp, #-0x38]
    // 0xd32ecc: LoadField: r2 = r0->field_b
    //     0xd32ecc: ldur            w2, [x0, #0xb]
    // 0xd32ed0: DecompressPointer r2
    //     0xd32ed0: add             x2, x2, HEAP, lsl #32
    // 0xd32ed4: cmp             w2, NULL
    // 0xd32ed8: b.eq            #0xd32f6c
    // 0xd32edc: r0 = ListTile()
    //     0xd32edc: bl              #0xd32f8c  ; AllocateListTileStub -> ListTile (size=0xa0)
    // 0xd32ee0: mov             x1, x0
    // 0xd32ee4: ldur            x0, [fp, #-8]
    // 0xd32ee8: stur            x1, [fp, #-0x10]
    // 0xd32eec: StoreField: r1->field_b = r0
    //     0xd32eec: stur            w0, [x1, #0xb]
    // 0xd32ef0: ldur            x0, [fp, #-0x18]
    // 0xd32ef4: StoreField: r1->field_f = r0
    //     0xd32ef4: stur            w0, [x1, #0xf]
    // 0xd32ef8: ldur            x0, [fp, #-0x20]
    // 0xd32efc: StoreField: r1->field_2b = r0
    //     0xd32efc: stur            w0, [x1, #0x2b]
    // 0xd32f00: ldur            x0, [fp, #-0x28]
    // 0xd32f04: StoreField: r1->field_4b = r0
    //     0xd32f04: stur            w0, [x1, #0x4b]
    // 0xd32f08: ldur            x0, [fp, #-0x30]
    // 0xd32f0c: StoreField: r1->field_4f = r0
    //     0xd32f0c: stur            w0, [x1, #0x4f]
    // 0xd32f10: r0 = false
    //     0xd32f10: add             x0, NULL, #0x30  ; false
    // 0xd32f14: StoreField: r1->field_5f = r0
    //     0xd32f14: stur            w0, [x1, #0x5f]
    // 0xd32f18: ldur            x2, [fp, #-0x38]
    // 0xd32f1c: StoreField: r1->field_6f = r2
    //     0xd32f1c: stur            w2, [x1, #0x6f]
    // 0xd32f20: StoreField: r1->field_73 = r0
    //     0xd32f20: stur            w0, [x1, #0x73]
    // 0xd32f24: StoreField: r1->field_97 = r0
    //     0xd32f24: stur            w0, [x1, #0x97]
    // 0xd32f28: r0 = MergeSemantics()
    //     0xd32f28: bl              #0xd32f80  ; AllocateMergeSemanticsStub -> MergeSemantics (size=0x10)
    // 0xd32f2c: ldur            x1, [fp, #-0x10]
    // 0xd32f30: StoreField: r0->field_b = r1
    //     0xd32f30: stur            w1, [x0, #0xb]
    // 0xd32f34: LeaveFrame
    //     0xd32f34: mov             SP, fp
    //     0xd32f38: ldp             fp, lr, [SP], #0x10
    // 0xd32f3c: ret
    //     0xd32f3c: ret             
    // 0xd32f40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd32f40: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd32f44: b               #0xd32b18
    // 0xd32f48: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd32f48: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd32f4c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd32f4c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd32f50: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd32f50: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd32f54: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd32f54: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd32f58: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd32f58: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd32f5c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd32f5c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd32f60: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd32f60: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd32f64: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd32f64: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd32f68: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd32f68: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd32f6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd32f6c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _enabled(/* No info */) {
    // ** addr: 0xd33044, size: 0x78
    // 0xd33044: EnterFrame
    //     0xd33044: stp             fp, lr, [SP, #-0x10]!
    //     0xd33048: mov             fp, SP
    // 0xd3304c: AllocStack(0x8)
    //     0xd3304c: sub             SP, SP, #8
    // 0xd33050: SetupParameters(_RadioListTileState<C1X0> this /* r1 => r3, fp-0x8 */)
    //     0xd33050: mov             x3, x1
    //     0xd33054: stur            x1, [fp, #-8]
    // 0xd33058: LoadField: r0 = r3->field_b
    //     0xd33058: ldur            w0, [x3, #0xb]
    // 0xd3305c: DecompressPointer r0
    //     0xd3305c: add             x0, x0, HEAP, lsl #32
    // 0xd33060: cmp             w0, NULL
    // 0xd33064: b.eq            #0xd330b8
    // 0xd33068: LoadField: r2 = r3->field_7
    //     0xd33068: ldur            w2, [x3, #7]
    // 0xd3306c: DecompressPointer r2
    //     0xd3306c: add             x2, x2, HEAP, lsl #32
    // 0xd33070: r0 = Null
    //     0xd33070: mov             x0, NULL
    // 0xd33074: r1 = Null
    //     0xd33074: mov             x1, NULL
    // 0xd33078: r8 = ((dynamic this, C1X0?) => void?)?
    //     0xd33078: add             x8, PP, #0x28, lsl #12  ; [pp+0x28308] FunctionType: ((dynamic this, C1X0?) => void?)?
    //     0xd3307c: ldr             x8, [x8, #0x308]
    // 0xd33080: LoadField: r9 = r8->field_7
    //     0xd33080: ldur            x9, [x8, #7]
    // 0xd33084: r3 = Null
    //     0xd33084: add             x3, PP, #0xd4, lsl #12  ; [pp+0xd4810] Null
    //     0xd33088: ldr             x3, [x3, #0x810]
    // 0xd3308c: blr             x9
    // 0xd33090: ldur            x1, [fp, #-8]
    // 0xd33094: LoadField: r2 = r1->field_13
    //     0xd33094: ldur            w2, [x1, #0x13]
    // 0xd33098: DecompressPointer r2
    //     0xd33098: add             x2, x2, HEAP, lsl #32
    // 0xd3309c: cmp             w2, NULL
    // 0xd330a0: r16 = true
    //     0xd330a0: add             x16, NULL, #0x20  ; true
    // 0xd330a4: r17 = false
    //     0xd330a4: add             x17, NULL, #0x30  ; false
    // 0xd330a8: csel            x0, x16, x17, ne
    // 0xd330ac: LeaveFrame
    //     0xd330ac: mov             SP, fp
    //     0xd330b0: ldp             fp, lr, [SP], #0x10
    // 0xd330b4: ret
    //     0xd330b4: ret             
    // 0xd330b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd330b8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ effectiveGroupValue(/* No info */) {
    // ** addr: 0xd330bc, size: 0x80
    // 0xd330bc: EnterFrame
    //     0xd330bc: stp             fp, lr, [SP, #-0x10]!
    //     0xd330c0: mov             fp, SP
    // 0xd330c4: AllocStack(0x8)
    //     0xd330c4: sub             SP, SP, #8
    // 0xd330c8: SetupParameters(_RadioListTileState<C1X0> this /* r1 => r0, fp-0x8 */)
    //     0xd330c8: mov             x0, x1
    //     0xd330cc: stur            x1, [fp, #-8]
    // 0xd330d0: CheckStackOverflow
    //     0xd330d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd330d4: cmp             SP, x16
    //     0xd330d8: b.ls            #0xd33130
    // 0xd330dc: LoadField: r1 = r0->field_13
    //     0xd330dc: ldur            w1, [x0, #0x13]
    // 0xd330e0: DecompressPointer r1
    //     0xd330e0: add             x1, x1, HEAP, lsl #32
    // 0xd330e4: cmp             w1, NULL
    // 0xd330e8: b.ne            #0xd330f4
    // 0xd330ec: r1 = Null
    //     0xd330ec: mov             x1, NULL
    // 0xd330f0: b               #0xd330fc
    // 0xd330f4: r0 = radioValue()
    //     0xd330f4: bl              #0x12a071c  ; [package:flutter/src/widgets/raw_radio.dart] _RawRadioState::radioValue
    // 0xd330f8: mov             x1, x0
    // 0xd330fc: cmp             w1, NULL
    // 0xd33100: b.ne            #0xd33120
    // 0xd33104: ldur            x2, [fp, #-8]
    // 0xd33108: LoadField: r3 = r2->field_b
    //     0xd33108: ldur            w3, [x2, #0xb]
    // 0xd3310c: DecompressPointer r3
    //     0xd3310c: add             x3, x3, HEAP, lsl #32
    // 0xd33110: cmp             w3, NULL
    // 0xd33114: b.eq            #0xd33138
    // 0xd33118: r0 = Null
    //     0xd33118: mov             x0, NULL
    // 0xd3311c: b               #0xd33124
    // 0xd33120: mov             x0, x1
    // 0xd33124: LeaveFrame
    //     0xd33124: mov             SP, fp
    //     0xd33128: ldp             fp, lr, [SP], #0x10
    // 0xd3312c: ret
    //     0xd3312c: ret             
    // 0xd33130: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd33130: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd33134: b               #0xd330dc
    // 0xd33138: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd33138: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleListTileTap(dynamic) {
    // ** addr: 0xd3313c, size: 0x38
    // 0xd3313c: EnterFrame
    //     0xd3313c: stp             fp, lr, [SP, #-0x10]!
    //     0xd33140: mov             fp, SP
    // 0xd33144: ldr             x0, [fp, #0x10]
    // 0xd33148: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd33148: ldur            w1, [x0, #0x17]
    // 0xd3314c: DecompressPointer r1
    //     0xd3314c: add             x1, x1, HEAP, lsl #32
    // 0xd33150: CheckStackOverflow
    //     0xd33150: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd33154: cmp             SP, x16
    //     0xd33158: b.ls            #0xd3316c
    // 0xd3315c: r0 = _handleListTileTap()
    //     0xd3315c: bl              #0xd33174  ; [package:flutter/src/material/radio_list_tile.dart] _RadioListTileState::_handleListTileTap
    // 0xd33160: LeaveFrame
    //     0xd33160: mov             SP, fp
    //     0xd33164: ldp             fp, lr, [SP], #0x10
    // 0xd33168: ret
    //     0xd33168: ret             
    // 0xd3316c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd3316c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd33170: b               #0xd3315c
  }
  _ _handleListTileTap(/* No info */) {
    // ** addr: 0xd33174, size: 0xdc
    // 0xd33174: EnterFrame
    //     0xd33174: stp             fp, lr, [SP, #-0x10]!
    //     0xd33178: mov             fp, SP
    // 0xd3317c: AllocStack(0x20)
    //     0xd3317c: sub             SP, SP, #0x20
    // 0xd33180: SetupParameters(_RadioListTileState<C1X0> this /* r1 => r0, fp-0x10 */)
    //     0xd33180: mov             x0, x1
    //     0xd33184: stur            x1, [fp, #-0x10]
    // 0xd33188: CheckStackOverflow
    //     0xd33188: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd3318c: cmp             SP, x16
    //     0xd33190: b.ls            #0xd33240
    // 0xd33194: LoadField: r1 = r0->field_b
    //     0xd33194: ldur            w1, [x0, #0xb]
    // 0xd33198: DecompressPointer r1
    //     0xd33198: add             x1, x1, HEAP, lsl #32
    // 0xd3319c: cmp             w1, NULL
    // 0xd331a0: b.eq            #0xd33248
    // 0xd331a4: LoadField: r2 = r1->field_f
    //     0xd331a4: ldur            w2, [x1, #0xf]
    // 0xd331a8: DecompressPointer r2
    //     0xd331a8: add             x2, x2, HEAP, lsl #32
    // 0xd331ac: mov             x1, x0
    // 0xd331b0: stur            x2, [fp, #-8]
    // 0xd331b4: r0 = effectiveGroupValue()
    //     0xd331b4: bl              #0xd330bc  ; [package:flutter/src/material/radio_list_tile.dart] _RadioListTileState::effectiveGroupValue
    // 0xd331b8: mov             x1, x0
    // 0xd331bc: ldur            x0, [fp, #-8]
    // 0xd331c0: r2 = 60
    //     0xd331c0: mov             x2, #0x3c
    // 0xd331c4: branchIfSmi(r0, 0xd331d0)
    //     0xd331c4: tbz             w0, #0, #0xd331d0
    // 0xd331c8: r2 = LoadClassIdInstr(r0)
    //     0xd331c8: ldur            x2, [x0, #-1]
    //     0xd331cc: ubfx            x2, x2, #0xc, #0x14
    // 0xd331d0: stp             x1, x0, [SP]
    // 0xd331d4: mov             x0, x2
    // 0xd331d8: mov             lr, x0
    // 0xd331dc: ldr             lr, [x21, lr, lsl #3]
    // 0xd331e0: blr             lr
    // 0xd331e4: tbnz            w0, #4, #0xd331f8
    // 0xd331e8: r0 = Null
    //     0xd331e8: mov             x0, NULL
    // 0xd331ec: LeaveFrame
    //     0xd331ec: mov             SP, fp
    //     0xd331f0: ldp             fp, lr, [SP], #0x10
    // 0xd331f4: ret
    //     0xd331f4: ret             
    // 0xd331f8: ldur            x1, [fp, #-0x10]
    // 0xd331fc: r0 = checked()
    //     0xd331fc: bl              #0xd33410  ; [package:flutter/src/material/radio_list_tile.dart] _RadioListTileState::checked
    // 0xd33200: tbnz            w0, #4, #0xd33210
    // 0xd33204: ldur            x1, [fp, #-0x10]
    // 0xd33208: r2 = Null
    //     0xd33208: mov             x2, NULL
    // 0xd3320c: b               #0xd3322c
    // 0xd33210: ldur            x1, [fp, #-0x10]
    // 0xd33214: LoadField: r0 = r1->field_b
    //     0xd33214: ldur            w0, [x1, #0xb]
    // 0xd33218: DecompressPointer r0
    //     0xd33218: add             x0, x0, HEAP, lsl #32
    // 0xd3321c: cmp             w0, NULL
    // 0xd33220: b.eq            #0xd3324c
    // 0xd33224: LoadField: r2 = r0->field_f
    //     0xd33224: ldur            w2, [x0, #0xf]
    // 0xd33228: DecompressPointer r2
    //     0xd33228: add             x2, x2, HEAP, lsl #32
    // 0xd3322c: r0 = handleChange()
    //     0xd3322c: bl              #0xd33250  ; [package:flutter/src/material/radio_list_tile.dart] _RadioListTileState::handleChange
    // 0xd33230: r0 = Null
    //     0xd33230: mov             x0, NULL
    // 0xd33234: LeaveFrame
    //     0xd33234: mov             SP, fp
    //     0xd33238: ldp             fp, lr, [SP], #0x10
    // 0xd3323c: ret
    //     0xd3323c: ret             
    // 0xd33240: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd33240: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd33244: b               #0xd33194
    // 0xd33248: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd33248: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd3324c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd3324c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ handleChange(/* No info */) {
    // ** addr: 0xd33250, size: 0x120
    // 0xd33250: EnterFrame
    //     0xd33250: stp             fp, lr, [SP, #-0x10]!
    //     0xd33254: mov             fp, SP
    // 0xd33258: AllocStack(0x30)
    //     0xd33258: sub             SP, SP, #0x30
    // 0xd3325c: SetupParameters(_RadioListTileState<C1X0> this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r3, fp-0x18 */)
    //     0xd3325c: mov             x4, x1
    //     0xd33260: mov             x3, x2
    //     0xd33264: stur            x1, [fp, #-0x10]
    //     0xd33268: stur            x2, [fp, #-0x18]
    // 0xd3326c: CheckStackOverflow
    //     0xd3326c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd33270: cmp             SP, x16
    //     0xd33274: b.ls            #0xd33364
    // 0xd33278: LoadField: r5 = r4->field_7
    //     0xd33278: ldur            w5, [x4, #7]
    // 0xd3327c: DecompressPointer r5
    //     0xd3327c: add             x5, x5, HEAP, lsl #32
    // 0xd33280: mov             x0, x3
    // 0xd33284: mov             x2, x5
    // 0xd33288: stur            x5, [fp, #-8]
    // 0xd3328c: r1 = Null
    //     0xd3328c: mov             x1, NULL
    // 0xd33290: cmp             w0, NULL
    // 0xd33294: b.eq            #0xd332c0
    // 0xd33298: cmp             w2, NULL
    // 0xd3329c: b.eq            #0xd332c0
    // 0xd332a0: LoadField: r4 = r2->field_1b
    //     0xd332a0: ldur            w4, [x2, #0x1b]
    // 0xd332a4: DecompressPointer r4
    //     0xd332a4: add             x4, x4, HEAP, lsl #32
    // 0xd332a8: r8 = C1X0?
    //     0xd332a8: add             x8, PP, #0x26, lsl #12  ; [pp+0x26fd0] TypeParameter: C1X0?
    //     0xd332ac: ldr             x8, [x8, #0xfd0]
    // 0xd332b0: LoadField: r9 = r4->field_7
    //     0xd332b0: ldur            x9, [x4, #7]
    // 0xd332b4: r3 = Null
    //     0xd332b4: add             x3, PP, #0xd4, lsl #12  ; [pp+0xd47c0] Null
    //     0xd332b8: ldr             x3, [x3, #0x7c0]
    // 0xd332bc: blr             x9
    // 0xd332c0: ldur            x0, [fp, #-0x10]
    // 0xd332c4: LoadField: r1 = r0->field_13
    //     0xd332c4: ldur            w1, [x0, #0x13]
    // 0xd332c8: DecompressPointer r1
    //     0xd332c8: add             x1, x1, HEAP, lsl #32
    // 0xd332cc: cmp             w1, NULL
    // 0xd332d0: b.eq            #0xd3331c
    // 0xd332d4: r0 = onChanged()
    //     0xd332d4: bl              #0xd333ac  ; [package:flutter/src/widgets/radio_group.dart] _RadioGroupState::onChanged
    // 0xd332d8: ldur            x2, [fp, #-8]
    // 0xd332dc: mov             x3, x0
    // 0xd332e0: r1 = Null
    //     0xd332e0: mov             x1, NULL
    // 0xd332e4: stur            x3, [fp, #-0x20]
    // 0xd332e8: r8 = (dynamic this, C1X0?) => void?
    //     0xd332e8: add             x8, PP, #0xd4, lsl #12  ; [pp+0xd47d0] FunctionType: (dynamic this, C1X0?) => void?
    //     0xd332ec: ldr             x8, [x8, #0x7d0]
    // 0xd332f0: LoadField: r9 = r8->field_7
    //     0xd332f0: ldur            x9, [x8, #7]
    // 0xd332f4: r3 = Null
    //     0xd332f4: add             x3, PP, #0xd4, lsl #12  ; [pp+0xd47d8] Null
    //     0xd332f8: ldr             x3, [x3, #0x7d8]
    // 0xd332fc: blr             x9
    // 0xd33300: ldur            x16, [fp, #-0x20]
    // 0xd33304: ldur            lr, [fp, #-0x18]
    // 0xd33308: stp             lr, x16, [SP]
    // 0xd3330c: ldur            x0, [fp, #-0x20]
    // 0xd33310: ClosureCall
    //     0xd33310: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xd33314: ldur            x2, [x0, #0x1f]
    //     0xd33318: blr             x2
    // 0xd3331c: ldur            x0, [fp, #-0x10]
    // 0xd33320: LoadField: r1 = r0->field_b
    //     0xd33320: ldur            w1, [x0, #0xb]
    // 0xd33324: DecompressPointer r1
    //     0xd33324: add             x1, x1, HEAP, lsl #32
    // 0xd33328: cmp             w1, NULL
    // 0xd3332c: b.eq            #0xd3336c
    // 0xd33330: ldur            x2, [fp, #-8]
    // 0xd33334: r0 = Null
    //     0xd33334: mov             x0, NULL
    // 0xd33338: r1 = Null
    //     0xd33338: mov             x1, NULL
    // 0xd3333c: r8 = ((dynamic this, C1X0?) => void?)?
    //     0xd3333c: add             x8, PP, #0x28, lsl #12  ; [pp+0x28308] FunctionType: ((dynamic this, C1X0?) => void?)?
    //     0xd33340: ldr             x8, [x8, #0x308]
    // 0xd33344: LoadField: r9 = r8->field_7
    //     0xd33344: ldur            x9, [x8, #7]
    // 0xd33348: r3 = Null
    //     0xd33348: add             x3, PP, #0xd4, lsl #12  ; [pp+0xd47e8] Null
    //     0xd3334c: ldr             x3, [x3, #0x7e8]
    // 0xd33350: blr             x9
    // 0xd33354: r0 = Null
    //     0xd33354: mov             x0, NULL
    // 0xd33358: LeaveFrame
    //     0xd33358: mov             SP, fp
    //     0xd3335c: ldp             fp, lr, [SP], #0x10
    // 0xd33360: ret
    //     0xd33360: ret             
    // 0xd33364: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd33364: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd33368: b               #0xd33278
    // 0xd3336c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd3336c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void handleChange(dynamic, Object?) {
    // ** addr: 0xd33370, size: 0x3c
    // 0xd33370: EnterFrame
    //     0xd33370: stp             fp, lr, [SP, #-0x10]!
    //     0xd33374: mov             fp, SP
    // 0xd33378: ldr             x0, [fp, #0x18]
    // 0xd3337c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd3337c: ldur            w1, [x0, #0x17]
    // 0xd33380: DecompressPointer r1
    //     0xd33380: add             x1, x1, HEAP, lsl #32
    // 0xd33384: CheckStackOverflow
    //     0xd33384: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd33388: cmp             SP, x16
    //     0xd3338c: b.ls            #0xd333a4
    // 0xd33390: ldr             x2, [fp, #0x10]
    // 0xd33394: r0 = handleChange()
    //     0xd33394: bl              #0xd33250  ; [package:flutter/src/material/radio_list_tile.dart] _RadioListTileState::handleChange
    // 0xd33398: LeaveFrame
    //     0xd33398: mov             SP, fp
    //     0xd3339c: ldp             fp, lr, [SP], #0x10
    // 0xd333a0: ret
    //     0xd333a0: ret             
    // 0xd333a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd333a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd333a8: b               #0xd33390
  }
  get _ checked(/* No info */) {
    // ** addr: 0xd33410, size: 0x7c
    // 0xd33410: EnterFrame
    //     0xd33410: stp             fp, lr, [SP, #-0x10]!
    //     0xd33414: mov             fp, SP
    // 0xd33418: AllocStack(0x18)
    //     0xd33418: sub             SP, SP, #0x18
    // 0xd3341c: CheckStackOverflow
    //     0xd3341c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd33420: cmp             SP, x16
    //     0xd33424: b.ls            #0xd33480
    // 0xd33428: LoadField: r0 = r1->field_b
    //     0xd33428: ldur            w0, [x1, #0xb]
    // 0xd3342c: DecompressPointer r0
    //     0xd3342c: add             x0, x0, HEAP, lsl #32
    // 0xd33430: cmp             w0, NULL
    // 0xd33434: b.eq            #0xd33488
    // 0xd33438: LoadField: r2 = r0->field_f
    //     0xd33438: ldur            w2, [x0, #0xf]
    // 0xd3343c: DecompressPointer r2
    //     0xd3343c: add             x2, x2, HEAP, lsl #32
    // 0xd33440: stur            x2, [fp, #-8]
    // 0xd33444: r0 = effectiveGroupValue()
    //     0xd33444: bl              #0xd330bc  ; [package:flutter/src/material/radio_list_tile.dart] _RadioListTileState::effectiveGroupValue
    // 0xd33448: mov             x1, x0
    // 0xd3344c: ldur            x0, [fp, #-8]
    // 0xd33450: r2 = 60
    //     0xd33450: mov             x2, #0x3c
    // 0xd33454: branchIfSmi(r0, 0xd33460)
    //     0xd33454: tbz             w0, #0, #0xd33460
    // 0xd33458: r2 = LoadClassIdInstr(r0)
    //     0xd33458: ldur            x2, [x0, #-1]
    //     0xd3345c: ubfx            x2, x2, #0xc, #0x14
    // 0xd33460: stp             x1, x0, [SP]
    // 0xd33464: mov             x0, x2
    // 0xd33468: mov             lr, x0
    // 0xd3346c: ldr             lr, [x21, lr, lsl #3]
    // 0xd33470: blr             lr
    // 0xd33474: LeaveFrame
    //     0xd33474: mov             SP, fp
    //     0xd33478: ldp             fp, lr, [SP], #0x10
    // 0xd3347c: ret
    //     0xd3347c: ret             
    // 0xd33480: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd33480: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd33484: b               #0xd33428
    // 0xd33488: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd33488: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _RadioRegistry<C1X0> _radioRegistry(_RadioListTileState<C1X0>) {
    // ** addr: 0xd3348c, size: 0x54
    // 0xd3348c: EnterFrame
    //     0xd3348c: stp             fp, lr, [SP, #-0x10]!
    //     0xd33490: mov             fp, SP
    // 0xd33494: ldr             x0, [fp, #0x10]
    // 0xd33498: LoadField: r2 = r0->field_7
    //     0xd33498: ldur            w2, [x0, #7]
    // 0xd3349c: DecompressPointer r2
    //     0xd3349c: add             x2, x2, HEAP, lsl #32
    // 0xd334a0: r1 = Null
    //     0xd334a0: mov             x1, NULL
    // 0xd334a4: r3 = <C1X0>
    //     0xd334a4: add             x3, PP, #0x11, lsl #12  ; [pp+0x11880] TypeArguments: <C1X0>
    //     0xd334a8: ldr             x3, [x3, #0x880]
    // 0xd334ac: r0 = Null
    //     0xd334ac: mov             x0, NULL
    // 0xd334b0: cmp             x2, x0
    // 0xd334b4: b.eq            #0xd334c4
    // 0xd334b8: r30 = InstantiateTypeArgumentsStub
    //     0xd334b8: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0xd334bc: LoadField: r30 = r30->field_7
    //     0xd334bc: ldur            lr, [lr, #7]
    // 0xd334c0: blr             lr
    // 0xd334c4: mov             x1, x0
    // 0xd334c8: r0 = _RadioRegistry()
    //     0xd334c8: bl              #0xd334e0  ; Allocate_RadioRegistryStub -> _RadioRegistry<X0> (size=0x10)
    // 0xd334cc: ldr             x1, [fp, #0x10]
    // 0xd334d0: StoreField: r0->field_b = r1
    //     0xd334d0: stur            w1, [x0, #0xb]
    // 0xd334d4: LeaveFrame
    //     0xd334d4: mov             SP, fp
    //     0xd334d8: ldp             fp, lr, [SP], #0x10
    // 0xd334dc: ret
    //     0xd334dc: ret             
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0xeed310, size: 0x94
    // 0xeed310: EnterFrame
    //     0xeed310: stp             fp, lr, [SP, #-0x10]!
    //     0xeed314: mov             fp, SP
    // 0xeed318: AllocStack(0x18)
    //     0xeed318: sub             SP, SP, #0x18
    // 0xeed31c: SetupParameters(_RadioListTileState<C1X0> this /* r1 => r0, fp-0x8 */)
    //     0xeed31c: mov             x0, x1
    //     0xeed320: stur            x1, [fp, #-8]
    // 0xeed324: CheckStackOverflow
    //     0xeed324: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeed328: cmp             SP, x16
    //     0xeed32c: b.ls            #0xeed398
    // 0xeed330: LoadField: r2 = r0->field_7
    //     0xeed330: ldur            w2, [x0, #7]
    // 0xeed334: DecompressPointer r2
    //     0xeed334: add             x2, x2, HEAP, lsl #32
    // 0xeed338: r1 = Null
    //     0xeed338: mov             x1, NULL
    // 0xeed33c: r3 = <C1X0>
    //     0xeed33c: add             x3, PP, #0x11, lsl #12  ; [pp+0x11880] TypeArguments: <C1X0>
    //     0xeed340: ldr             x3, [x3, #0x880]
    // 0xeed344: r0 = Null
    //     0xeed344: mov             x0, NULL
    // 0xeed348: cmp             x2, x0
    // 0xeed34c: b.eq            #0xeed35c
    // 0xeed350: r30 = InstantiateTypeArgumentsStub
    //     0xeed350: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0xeed354: LoadField: r30 = r30->field_7
    //     0xeed354: ldur            lr, [lr, #7]
    // 0xeed358: blr             lr
    // 0xeed35c: ldur            x1, [fp, #-8]
    // 0xeed360: LoadField: r2 = r1->field_f
    //     0xeed360: ldur            w2, [x1, #0xf]
    // 0xeed364: DecompressPointer r2
    //     0xeed364: add             x2, x2, HEAP, lsl #32
    // 0xeed368: cmp             w2, NULL
    // 0xeed36c: b.eq            #0xeed3a0
    // 0xeed370: stp             x2, x0, [SP]
    // 0xeed374: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xeed374: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xeed378: r0 = maybeOf()
    //     0xeed378: bl              #0xeed52c  ; [package:flutter/src/widgets/radio_group.dart] RadioGroup::maybeOf
    // 0xeed37c: ldur            x1, [fp, #-8]
    // 0xeed380: mov             x2, x0
    // 0xeed384: r0 = registry=()
    //     0xeed384: bl              #0xeed3a4  ; [dart:mixin_deduplication] _MixinApplication93&State&RadioClient::registry=
    // 0xeed388: r0 = Null
    //     0xeed388: mov             x0, NULL
    // 0xeed38c: LeaveFrame
    //     0xeed38c: mov             SP, fp
    //     0xeed390: ldp             fp, lr, [SP], #0x10
    // 0xeed394: ret
    //     0xeed394: ret             
    // 0xeed398: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xeed398: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xeed39c: b               #0xeed330
    // 0xeed3a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xeed3a0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10dd890, size: 0x5c
    // 0x10dd890: EnterFrame
    //     0x10dd890: stp             fp, lr, [SP, #-0x10]!
    //     0x10dd894: mov             fp, SP
    // 0x10dd898: AllocStack(0x8)
    //     0x10dd898: sub             SP, SP, #8
    // 0x10dd89c: SetupParameters(_RadioListTileState<C1X0> this /* r1 => r0, fp-0x8 */)
    //     0x10dd89c: mov             x0, x1
    //     0x10dd8a0: stur            x1, [fp, #-8]
    // 0x10dd8a4: CheckStackOverflow
    //     0x10dd8a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10dd8a8: cmp             SP, x16
    //     0x10dd8ac: b.ls            #0x10dd8e4
    // 0x10dd8b0: mov             x1, x0
    // 0x10dd8b4: r2 = Null
    //     0x10dd8b4: mov             x2, NULL
    // 0x10dd8b8: r0 = registry=()
    //     0x10dd8b8: bl              #0xeed3a4  ; [dart:mixin_deduplication] _MixinApplication93&State&RadioClient::registry=
    // 0x10dd8bc: ldur            x0, [fp, #-8]
    // 0x10dd8c0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x10dd8c0: ldur            w1, [x0, #0x17]
    // 0x10dd8c4: DecompressPointer r1
    //     0x10dd8c4: add             x1, x1, HEAP, lsl #32
    // 0x10dd8c8: cmp             w1, NULL
    // 0x10dd8cc: b.eq            #0x10dd8d4
    // 0x10dd8d0: r0 = dispose()
    //     0x10dd8d0: bl              #0x10ec024  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::dispose
    // 0x10dd8d4: r0 = Null
    //     0x10dd8d4: mov             x0, NULL
    // 0x10dd8d8: LeaveFrame
    //     0x10dd8d8: mov             SP, fp
    //     0x10dd8dc: ldp             fp, lr, [SP], #0x10
    // 0x10dd8e0: ret
    //     0x10dd8e0: ret             
    // 0x10dd8e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10dd8e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10dd8e8: b               #0x10dd8b0
  }
  get _ enabled(/* No info */) {
    // ** addr: 0x125c838, size: 0x78
    // 0x125c838: EnterFrame
    //     0x125c838: stp             fp, lr, [SP, #-0x10]!
    //     0x125c83c: mov             fp, SP
    // 0x125c840: AllocStack(0x8)
    //     0x125c840: sub             SP, SP, #8
    // 0x125c844: SetupParameters(_RadioListTileState<C1X0> this /* r1 => r3, fp-0x8 */)
    //     0x125c844: mov             x3, x1
    //     0x125c848: stur            x1, [fp, #-8]
    // 0x125c84c: LoadField: r0 = r3->field_b
    //     0x125c84c: ldur            w0, [x3, #0xb]
    // 0x125c850: DecompressPointer r0
    //     0x125c850: add             x0, x0, HEAP, lsl #32
    // 0x125c854: cmp             w0, NULL
    // 0x125c858: b.eq            #0x125c8ac
    // 0x125c85c: LoadField: r2 = r3->field_7
    //     0x125c85c: ldur            w2, [x3, #7]
    // 0x125c860: DecompressPointer r2
    //     0x125c860: add             x2, x2, HEAP, lsl #32
    // 0x125c864: r0 = Null
    //     0x125c864: mov             x0, NULL
    // 0x125c868: r1 = Null
    //     0x125c868: mov             x1, NULL
    // 0x125c86c: r8 = ((dynamic this, C1X0?) => void?)?
    //     0x125c86c: add             x8, PP, #0x28, lsl #12  ; [pp+0x28308] FunctionType: ((dynamic this, C1X0?) => void?)?
    //     0x125c870: ldr             x8, [x8, #0x308]
    // 0x125c874: LoadField: r9 = r8->field_7
    //     0x125c874: ldur            x9, [x8, #7]
    // 0x125c878: r3 = Null
    //     0x125c878: add             x3, PP, #0xd4, lsl #12  ; [pp+0xd4e60] Null
    //     0x125c87c: ldr             x3, [x3, #0xe60]
    // 0x125c880: blr             x9
    // 0x125c884: ldur            x1, [fp, #-8]
    // 0x125c888: LoadField: r2 = r1->field_13
    //     0x125c888: ldur            w2, [x1, #0x13]
    // 0x125c88c: DecompressPointer r2
    //     0x125c88c: add             x2, x2, HEAP, lsl #32
    // 0x125c890: cmp             w2, NULL
    // 0x125c894: r16 = true
    //     0x125c894: add             x16, NULL, #0x20  ; true
    // 0x125c898: r17 = false
    //     0x125c898: add             x17, NULL, #0x30  ; false
    // 0x125c89c: csel            x0, x16, x17, ne
    // 0x125c8a0: LeaveFrame
    //     0x125c8a0: mov             SP, fp
    //     0x125c8a4: ldp             fp, lr, [SP], #0x10
    // 0x125c8a8: ret
    //     0x125c8a8: ret             
    // 0x125c8ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x125c8ac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ focusNode(/* No info */) {
    // ** addr: 0x12a1e78, size: 0x90
    // 0x12a1e78: EnterFrame
    //     0x12a1e78: stp             fp, lr, [SP, #-0x10]!
    //     0x12a1e7c: mov             fp, SP
    // 0x12a1e80: AllocStack(0x10)
    //     0x12a1e80: sub             SP, SP, #0x10
    // 0x12a1e84: SetupParameters(_RadioListTileState<C1X0> this /* r1 => r1, fp-0x8 */)
    //     0x12a1e84: stur            x1, [fp, #-8]
    // 0x12a1e88: CheckStackOverflow
    //     0x12a1e88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12a1e8c: cmp             SP, x16
    //     0x12a1e90: b.ls            #0x12a1efc
    // 0x12a1e94: LoadField: r0 = r1->field_b
    //     0x12a1e94: ldur            w0, [x1, #0xb]
    // 0x12a1e98: DecompressPointer r0
    //     0x12a1e98: add             x0, x0, HEAP, lsl #32
    // 0x12a1e9c: cmp             w0, NULL
    // 0x12a1ea0: b.eq            #0x12a1f04
    // 0x12a1ea4: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x12a1ea4: ldur            w0, [x1, #0x17]
    // 0x12a1ea8: DecompressPointer r0
    //     0x12a1ea8: add             x0, x0, HEAP, lsl #32
    // 0x12a1eac: cmp             w0, NULL
    // 0x12a1eb0: b.ne            #0x12a1ef0
    // 0x12a1eb4: r0 = FocusNode()
    //     0x12a1eb4: bl              #0xd4952c  ; AllocateFocusNodeStub -> FocusNode (size=0x68)
    // 0x12a1eb8: mov             x1, x0
    // 0x12a1ebc: stur            x0, [fp, #-0x10]
    // 0x12a1ec0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x12a1ec0: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x12a1ec4: r0 = FocusNode()
    //     0x12a1ec4: bl              #0x83cf84  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::FocusNode
    // 0x12a1ec8: ldur            x0, [fp, #-0x10]
    // 0x12a1ecc: ldur            x1, [fp, #-8]
    // 0x12a1ed0: ArrayStore: r1[0] = r0  ; List_4
    //     0x12a1ed0: stur            w0, [x1, #0x17]
    //     0x12a1ed4: ldurb           w16, [x1, #-1]
    //     0x12a1ed8: ldurb           w17, [x0, #-1]
    //     0x12a1edc: and             x16, x17, x16, lsr #2
    //     0x12a1ee0: tst             x16, HEAP, lsr #32
    //     0x12a1ee4: b.eq            #0x12a1eec
    //     0x12a1ee8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x12a1eec: ldur            x0, [fp, #-0x10]
    // 0x12a1ef0: LeaveFrame
    //     0x12a1ef0: mov             SP, fp
    //     0x12a1ef4: ldp             fp, lr, [SP], #0x10
    // 0x12a1ef8: ret
    //     0x12a1ef8: ret             
    // 0x12a1efc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12a1efc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12a1f00: b               #0x12a1e94
    // 0x12a1f04: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12a1f04: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 6441, size: 0xb8, field offset: 0xc
//   const constructor, 
class RadioListTile<X0> extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa2784, size: 0x44
    // 0xfa2784: EnterFrame
    //     0xfa2784: stp             fp, lr, [SP, #-0x10]!
    //     0xfa2788: mov             fp, SP
    // 0xfa278c: LoadField: r2 = r1->field_b
    //     0xfa278c: ldur            w2, [x1, #0xb]
    // 0xfa2790: DecompressPointer r2
    //     0xfa2790: add             x2, x2, HEAP, lsl #32
    // 0xfa2794: r1 = Null
    //     0xfa2794: mov             x1, NULL
    // 0xfa2798: r3 = <RadioListTile<X0>, X0>
    //     0xfa2798: add             x3, PP, #0xd4, lsl #12  ; [pp+0xd41f8] TypeArguments: <RadioListTile<X0>, X0>
    //     0xfa279c: ldr             x3, [x3, #0x1f8]
    // 0xfa27a0: r30 = InstantiateTypeArgumentsStub
    //     0xfa27a0: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0xfa27a4: LoadField: r30 = r30->field_7
    //     0xfa27a4: ldur            lr, [lr, #7]
    // 0xfa27a8: blr             lr
    // 0xfa27ac: mov             x1, x0
    // 0xfa27b0: r0 = _RadioListTileState()
    //     0xfa27b0: bl              #0xfa27c8  ; Allocate_RadioListTileStateStub -> _RadioListTileState<C1X0> (size=0x20)
    // 0xfa27b4: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa27b8: StoreField: r0->field_1b = r1
    //     0xfa27b8: stur            w1, [x0, #0x1b]
    // 0xfa27bc: LeaveFrame
    //     0xfa27bc: mov             SP, fp
    //     0xfa27c0: ldp             fp, lr, [SP], #0x10
    // 0xfa27c4: ret
    //     0xfa27c4: ret             
  }
}

// class id: 8272, size: 0x14, field offset: 0x14
enum _RadioType extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11aa544, size: 0x64
    // 0x11aa544: EnterFrame
    //     0x11aa544: stp             fp, lr, [SP, #-0x10]!
    //     0x11aa548: mov             fp, SP
    // 0x11aa54c: AllocStack(0x10)
    //     0x11aa54c: sub             SP, SP, #0x10
    // 0x11aa550: SetupParameters(_RadioType this /* r1 => r0, fp-0x8 */)
    //     0x11aa550: mov             x0, x1
    //     0x11aa554: stur            x1, [fp, #-8]
    // 0x11aa558: CheckStackOverflow
    //     0x11aa558: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11aa55c: cmp             SP, x16
    //     0x11aa560: b.ls            #0x11aa5a0
    // 0x11aa564: r1 = Null
    //     0x11aa564: mov             x1, NULL
    // 0x11aa568: r2 = 4
    //     0x11aa568: mov             x2, #4
    // 0x11aa56c: r0 = AllocateArray()
    //     0x11aa56c: bl              #0x13df928  ; AllocateArrayStub
    // 0x11aa570: r16 = "_RadioType."
    //     0x11aa570: add             x16, PP, #0xd4, lsl #12  ; [pp+0xd41f0] "_RadioType."
    //     0x11aa574: ldr             x16, [x16, #0x1f0]
    // 0x11aa578: StoreField: r0->field_f = r16
    //     0x11aa578: stur            w16, [x0, #0xf]
    // 0x11aa57c: ldur            x1, [fp, #-8]
    // 0x11aa580: LoadField: r2 = r1->field_f
    //     0x11aa580: ldur            w2, [x1, #0xf]
    // 0x11aa584: DecompressPointer r2
    //     0x11aa584: add             x2, x2, HEAP, lsl #32
    // 0x11aa588: StoreField: r0->field_13 = r2
    //     0x11aa588: stur            w2, [x0, #0x13]
    // 0x11aa58c: str             x0, [SP]
    // 0x11aa590: r0 = _interpolate()
    //     0x11aa590: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11aa594: LeaveFrame
    //     0x11aa594: mov             SP, fp
    //     0x11aa598: ldp             fp, lr, [SP], #0x10
    // 0x11aa59c: ret
    //     0x11aa59c: ret             
    // 0x11aa5a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11aa5a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11aa5a4: b               #0x11aa564
  }
}
