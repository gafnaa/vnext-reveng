// lib: , url: package:flutter/src/material/color_scheme.dart

// class id: 1048869, size: 0x8
class :: {
}

// class id: 5171, size: 0xd0, field offset: 0x8
//   const constructor, 
class ColorScheme extends _MixinApplication3&Object&Diagnosticable {

  Brightness field_8;
  Color field_c;
  Color field_10;
  Color field_14;
  Color field_18;
  Color field_1c;
  Color field_20;
  Color field_24;
  Color field_28;
  Color field_2c;
  Color field_30;
  Color field_34;
  Color field_38;
  Color field_3c;
  Color field_40;
  Color field_44;
  Color field_48;
  Color field_4c;
  Color field_50;
  Color field_54;
  Color field_58;
  Color field_5c;
  Color field_60;
  Color field_64;
  Color field_68;
  Color field_6c;
  Color field_70;
  Color field_74;
  Color field_78;
  Color field_7c;
  Color field_80;
  Color field_84;
  Color field_88;
  Color field_8c;
  Color field_90;
  Color field_94;
  Color field_98;
  Color field_9c;
  Color field_a0;
  Color field_a4;
  Color field_a8;
  Color field_ac;
  Color field_b0;
  Color field_b4;
  Color field_b8;
  Color field_bc;
  Color field_c0;
  Color field_c4;
  Color field_c8;
  Color field_cc;

  _ copyWith(/* No info */) {
    // ** addr: 0x8a88a4, size: 0x760
    // 0x8a88a4: EnterFrame
    //     0x8a88a4: stp             fp, lr, [SP, #-0x10]!
    //     0x8a88a8: mov             fp, SP
    // 0x8a88ac: AllocStack(0x190)
    //     0x8a88ac: sub             SP, SP, #0x190
    // 0x8a88b0: SetupParameters(ColorScheme this /* r1 => r0, fp-0xa0 */)
    //     0x8a88b0: mov             x0, x1
    //     0x8a88b4: stur            x1, [fp, #-0xa0]
    // 0x8a88b8: CheckStackOverflow
    //     0x8a88b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a88bc: cmp             SP, x16
    //     0x8a88c0: b.ls            #0x8a8ffc
    // 0x8a88c4: LoadField: r2 = r0->field_7
    //     0x8a88c4: ldur            w2, [x0, #7]
    // 0x8a88c8: DecompressPointer r2
    //     0x8a88c8: add             x2, x2, HEAP, lsl #32
    // 0x8a88cc: stur            x2, [fp, #-0x98]
    // 0x8a88d0: LoadField: r3 = r0->field_b
    //     0x8a88d0: ldur            w3, [x0, #0xb]
    // 0x8a88d4: DecompressPointer r3
    //     0x8a88d4: add             x3, x3, HEAP, lsl #32
    // 0x8a88d8: stur            x3, [fp, #-0x90]
    // 0x8a88dc: LoadField: r4 = r0->field_f
    //     0x8a88dc: ldur            w4, [x0, #0xf]
    // 0x8a88e0: DecompressPointer r4
    //     0x8a88e0: add             x4, x4, HEAP, lsl #32
    // 0x8a88e4: stur            x4, [fp, #-0x88]
    // 0x8a88e8: LoadField: r1 = r0->field_13
    //     0x8a88e8: ldur            w1, [x0, #0x13]
    // 0x8a88ec: DecompressPointer r1
    //     0x8a88ec: add             x1, x1, HEAP, lsl #32
    // 0x8a88f0: cmp             w1, NULL
    // 0x8a88f4: b.ne            #0x8a8900
    // 0x8a88f8: mov             x5, x3
    // 0x8a88fc: b               #0x8a8904
    // 0x8a8900: mov             x5, x1
    // 0x8a8904: stur            x5, [fp, #-0x80]
    // 0x8a8908: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8a8908: ldur            w1, [x0, #0x17]
    // 0x8a890c: DecompressPointer r1
    //     0x8a890c: add             x1, x1, HEAP, lsl #32
    // 0x8a8910: cmp             w1, NULL
    // 0x8a8914: b.ne            #0x8a8920
    // 0x8a8918: mov             x6, x4
    // 0x8a891c: b               #0x8a8924
    // 0x8a8920: mov             x6, x1
    // 0x8a8924: stur            x6, [fp, #-0x78]
    // 0x8a8928: LoadField: r1 = r0->field_1b
    //     0x8a8928: ldur            w1, [x0, #0x1b]
    // 0x8a892c: DecompressPointer r1
    //     0x8a892c: add             x1, x1, HEAP, lsl #32
    // 0x8a8930: cmp             w1, NULL
    // 0x8a8934: b.ne            #0x8a8940
    // 0x8a8938: mov             x7, x3
    // 0x8a893c: b               #0x8a8944
    // 0x8a8940: mov             x7, x1
    // 0x8a8944: stur            x7, [fp, #-0x70]
    // 0x8a8948: LoadField: r1 = r0->field_1f
    //     0x8a8948: ldur            w1, [x0, #0x1f]
    // 0x8a894c: DecompressPointer r1
    //     0x8a894c: add             x1, x1, HEAP, lsl #32
    // 0x8a8950: cmp             w1, NULL
    // 0x8a8954: b.ne            #0x8a8960
    // 0x8a8958: mov             x8, x3
    // 0x8a895c: b               #0x8a8964
    // 0x8a8960: mov             x8, x1
    // 0x8a8964: stur            x8, [fp, #-0x68]
    // 0x8a8968: LoadField: r1 = r0->field_23
    //     0x8a8968: ldur            w1, [x0, #0x23]
    // 0x8a896c: DecompressPointer r1
    //     0x8a896c: add             x1, x1, HEAP, lsl #32
    // 0x8a8970: cmp             w1, NULL
    // 0x8a8974: b.ne            #0x8a8980
    // 0x8a8978: mov             x9, x4
    // 0x8a897c: b               #0x8a8984
    // 0x8a8980: mov             x9, x1
    // 0x8a8984: stur            x9, [fp, #-0x60]
    // 0x8a8988: LoadField: r1 = r0->field_27
    //     0x8a8988: ldur            w1, [x0, #0x27]
    // 0x8a898c: DecompressPointer r1
    //     0x8a898c: add             x1, x1, HEAP, lsl #32
    // 0x8a8990: cmp             w1, NULL
    // 0x8a8994: b.ne            #0x8a89a0
    // 0x8a8998: mov             x10, x4
    // 0x8a899c: b               #0x8a89a4
    // 0x8a89a0: mov             x10, x1
    // 0x8a89a4: stur            x10, [fp, #-0x58]
    // 0x8a89a8: LoadField: r11 = r0->field_2b
    //     0x8a89a8: ldur            w11, [x0, #0x2b]
    // 0x8a89ac: DecompressPointer r11
    //     0x8a89ac: add             x11, x11, HEAP, lsl #32
    // 0x8a89b0: stur            x11, [fp, #-0x50]
    // 0x8a89b4: LoadField: r12 = r0->field_2f
    //     0x8a89b4: ldur            w12, [x0, #0x2f]
    // 0x8a89b8: DecompressPointer r12
    //     0x8a89b8: add             x12, x12, HEAP, lsl #32
    // 0x8a89bc: stur            x12, [fp, #-0x48]
    // 0x8a89c0: LoadField: r1 = r0->field_33
    //     0x8a89c0: ldur            w1, [x0, #0x33]
    // 0x8a89c4: DecompressPointer r1
    //     0x8a89c4: add             x1, x1, HEAP, lsl #32
    // 0x8a89c8: cmp             w1, NULL
    // 0x8a89cc: b.ne            #0x8a89d8
    // 0x8a89d0: mov             x13, x11
    // 0x8a89d4: b               #0x8a89dc
    // 0x8a89d8: mov             x13, x1
    // 0x8a89dc: stur            x13, [fp, #-0x40]
    // 0x8a89e0: LoadField: r1 = r0->field_37
    //     0x8a89e0: ldur            w1, [x0, #0x37]
    // 0x8a89e4: DecompressPointer r1
    //     0x8a89e4: add             x1, x1, HEAP, lsl #32
    // 0x8a89e8: cmp             w1, NULL
    // 0x8a89ec: b.ne            #0x8a89f8
    // 0x8a89f0: mov             x14, x12
    // 0x8a89f4: b               #0x8a89fc
    // 0x8a89f8: mov             x14, x1
    // 0x8a89fc: stur            x14, [fp, #-0x38]
    // 0x8a8a00: LoadField: r1 = r0->field_3b
    //     0x8a8a00: ldur            w1, [x0, #0x3b]
    // 0x8a8a04: DecompressPointer r1
    //     0x8a8a04: add             x1, x1, HEAP, lsl #32
    // 0x8a8a08: cmp             w1, NULL
    // 0x8a8a0c: b.ne            #0x8a8a18
    // 0x8a8a10: mov             x19, x11
    // 0x8a8a14: b               #0x8a8a1c
    // 0x8a8a18: mov             x19, x1
    // 0x8a8a1c: stur            x19, [fp, #-0x30]
    // 0x8a8a20: LoadField: r1 = r0->field_3f
    //     0x8a8a20: ldur            w1, [x0, #0x3f]
    // 0x8a8a24: DecompressPointer r1
    //     0x8a8a24: add             x1, x1, HEAP, lsl #32
    // 0x8a8a28: cmp             w1, NULL
    // 0x8a8a2c: b.ne            #0x8a8a38
    // 0x8a8a30: mov             x20, x11
    // 0x8a8a34: b               #0x8a8a3c
    // 0x8a8a38: mov             x20, x1
    // 0x8a8a3c: stur            x20, [fp, #-0x28]
    // 0x8a8a40: LoadField: r1 = r0->field_43
    //     0x8a8a40: ldur            w1, [x0, #0x43]
    // 0x8a8a44: DecompressPointer r1
    //     0x8a8a44: add             x1, x1, HEAP, lsl #32
    // 0x8a8a48: cmp             w1, NULL
    // 0x8a8a4c: b.ne            #0x8a8a58
    // 0x8a8a50: mov             x23, x12
    // 0x8a8a54: b               #0x8a8a5c
    // 0x8a8a58: mov             x23, x1
    // 0x8a8a5c: stur            x23, [fp, #-0x20]
    // 0x8a8a60: LoadField: r1 = r0->field_47
    //     0x8a8a60: ldur            w1, [x0, #0x47]
    // 0x8a8a64: DecompressPointer r1
    //     0x8a8a64: add             x1, x1, HEAP, lsl #32
    // 0x8a8a68: cmp             w1, NULL
    // 0x8a8a6c: b.ne            #0x8a8a78
    // 0x8a8a70: mov             x24, x12
    // 0x8a8a74: b               #0x8a8a7c
    // 0x8a8a78: mov             x24, x1
    // 0x8a8a7c: stur            x24, [fp, #-0x18]
    // 0x8a8a80: LoadField: r1 = r0->field_4b
    //     0x8a8a80: ldur            w1, [x0, #0x4b]
    // 0x8a8a84: DecompressPointer r1
    //     0x8a8a84: add             x1, x1, HEAP, lsl #32
    // 0x8a8a88: cmp             w1, NULL
    // 0x8a8a8c: b.ne            #0x8a8a98
    // 0x8a8a90: mov             x25, x11
    // 0x8a8a94: b               #0x8a8a9c
    // 0x8a8a98: mov             x25, x1
    // 0x8a8a9c: stur            x25, [fp, #-0x10]
    // 0x8a8aa0: LoadField: r1 = r0->field_4f
    //     0x8a8aa0: ldur            w1, [x0, #0x4f]
    // 0x8a8aa4: DecompressPointer r1
    //     0x8a8aa4: add             x1, x1, HEAP, lsl #32
    // 0x8a8aa8: cmp             w1, NULL
    // 0x8a8aac: b.ne            #0x8a8ab4
    // 0x8a8ab0: mov             x1, x12
    // 0x8a8ab4: stur            x1, [fp, #-8]
    // 0x8a8ab8: mov             x1, x0
    // 0x8a8abc: r0 = tertiaryContainer()
    //     0x8a8abc: bl              #0x8a91b4  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::tertiaryContainer
    // 0x8a8ac0: ldur            x1, [fp, #-0xa0]
    // 0x8a8ac4: stur            x0, [fp, #-0xa8]
    // 0x8a8ac8: r0 = onTertiaryContainer()
    //     0x8a8ac8: bl              #0x8a9170  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::onTertiaryContainer
    // 0x8a8acc: ldur            x1, [fp, #-0xa0]
    // 0x8a8ad0: stur            x0, [fp, #-0xb0]
    // 0x8a8ad4: r0 = tertiaryFixed()
    //     0x8a8ad4: bl              #0x8a912c  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::tertiaryFixed
    // 0x8a8ad8: ldur            x1, [fp, #-0xa0]
    // 0x8a8adc: stur            x0, [fp, #-0xb8]
    // 0x8a8ae0: r0 = tertiaryFixedDim()
    //     0x8a8ae0: bl              #0x8a90e8  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::tertiaryFixedDim
    // 0x8a8ae4: ldur            x1, [fp, #-0xa0]
    // 0x8a8ae8: stur            x0, [fp, #-0xc0]
    // 0x8a8aec: r0 = onTertiaryFixed()
    //     0x8a8aec: bl              #0x8a90a4  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::onTertiaryFixed
    // 0x8a8af0: ldur            x1, [fp, #-0xa0]
    // 0x8a8af4: stur            x0, [fp, #-0xc8]
    // 0x8a8af8: r0 = onTertiaryFixedVariant()
    //     0x8a8af8: bl              #0x8a9060  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::onTertiaryFixedVariant
    // 0x8a8afc: mov             x2, x0
    // 0x8a8b00: ldur            x0, [fp, #-0xa0]
    // 0x8a8b04: r17 = -320
    //     0x8a8b04: mov             x17, #-0x140
    // 0x8a8b08: str             x2, [fp, x17]
    // 0x8a8b0c: LoadField: r3 = r0->field_6b
    //     0x8a8b0c: ldur            w3, [x0, #0x6b]
    // 0x8a8b10: DecompressPointer r3
    //     0x8a8b10: add             x3, x3, HEAP, lsl #32
    // 0x8a8b14: r17 = -312
    //     0x8a8b14: mov             x17, #-0x138
    // 0x8a8b18: str             x3, [fp, x17]
    // 0x8a8b1c: LoadField: r4 = r0->field_6f
    //     0x8a8b1c: ldur            w4, [x0, #0x6f]
    // 0x8a8b20: DecompressPointer r4
    //     0x8a8b20: add             x4, x4, HEAP, lsl #32
    // 0x8a8b24: r17 = -304
    //     0x8a8b24: mov             x17, #-0x130
    // 0x8a8b28: str             x4, [fp, x17]
    // 0x8a8b2c: LoadField: r1 = r0->field_73
    //     0x8a8b2c: ldur            w1, [x0, #0x73]
    // 0x8a8b30: DecompressPointer r1
    //     0x8a8b30: add             x1, x1, HEAP, lsl #32
    // 0x8a8b34: cmp             w1, NULL
    // 0x8a8b38: b.ne            #0x8a8b44
    // 0x8a8b3c: mov             x5, x3
    // 0x8a8b40: b               #0x8a8b48
    // 0x8a8b44: mov             x5, x1
    // 0x8a8b48: r17 = -296
    //     0x8a8b48: mov             x17, #-0x128
    // 0x8a8b4c: str             x5, [fp, x17]
    // 0x8a8b50: LoadField: r1 = r0->field_77
    //     0x8a8b50: ldur            w1, [x0, #0x77]
    // 0x8a8b54: DecompressPointer r1
    //     0x8a8b54: add             x1, x1, HEAP, lsl #32
    // 0x8a8b58: cmp             w1, NULL
    // 0x8a8b5c: b.ne            #0x8a8b68
    // 0x8a8b60: mov             x6, x4
    // 0x8a8b64: b               #0x8a8b6c
    // 0x8a8b68: mov             x6, x1
    // 0x8a8b6c: r17 = -288
    //     0x8a8b6c: mov             x17, #-0x120
    // 0x8a8b70: str             x6, [fp, x17]
    // 0x8a8b74: LoadField: r7 = r0->field_7b
    //     0x8a8b74: ldur            w7, [x0, #0x7b]
    // 0x8a8b78: DecompressPointer r7
    //     0x8a8b78: add             x7, x7, HEAP, lsl #32
    // 0x8a8b7c: r17 = -280
    //     0x8a8b7c: mov             x17, #-0x118
    // 0x8a8b80: str             x7, [fp, x17]
    // 0x8a8b84: LoadField: r8 = r0->field_7f
    //     0x8a8b84: ldur            w8, [x0, #0x7f]
    // 0x8a8b88: DecompressPointer r8
    //     0x8a8b88: add             x8, x8, HEAP, lsl #32
    // 0x8a8b8c: r17 = -272
    //     0x8a8b8c: mov             x17, #-0x110
    // 0x8a8b90: str             x8, [fp, x17]
    // 0x8a8b94: LoadField: r1 = r0->field_87
    //     0x8a8b94: ldur            w1, [x0, #0x87]
    // 0x8a8b98: DecompressPointer r1
    //     0x8a8b98: add             x1, x1, HEAP, lsl #32
    // 0x8a8b9c: cmp             w1, NULL
    // 0x8a8ba0: b.ne            #0x8a8bac
    // 0x8a8ba4: mov             x9, x7
    // 0x8a8ba8: b               #0x8a8bb0
    // 0x8a8bac: mov             x9, x1
    // 0x8a8bb0: r17 = -264
    //     0x8a8bb0: mov             x17, #-0x108
    // 0x8a8bb4: str             x9, [fp, x17]
    // 0x8a8bb8: LoadField: r1 = r0->field_8b
    //     0x8a8bb8: ldur            w1, [x0, #0x8b]
    // 0x8a8bbc: DecompressPointer r1
    //     0x8a8bbc: add             x1, x1, HEAP, lsl #32
    // 0x8a8bc0: cmp             w1, NULL
    // 0x8a8bc4: b.ne            #0x8a8bd0
    // 0x8a8bc8: mov             x10, x7
    // 0x8a8bcc: b               #0x8a8bd4
    // 0x8a8bd0: mov             x10, x1
    // 0x8a8bd4: stur            x10, [fp, #-0x100]
    // 0x8a8bd8: LoadField: r1 = r0->field_8f
    //     0x8a8bd8: ldur            w1, [x0, #0x8f]
    // 0x8a8bdc: DecompressPointer r1
    //     0x8a8bdc: add             x1, x1, HEAP, lsl #32
    // 0x8a8be0: cmp             w1, NULL
    // 0x8a8be4: b.ne            #0x8a8bf0
    // 0x8a8be8: mov             x11, x7
    // 0x8a8bec: b               #0x8a8bf4
    // 0x8a8bf0: mov             x11, x1
    // 0x8a8bf4: stur            x11, [fp, #-0xf8]
    // 0x8a8bf8: LoadField: r1 = r0->field_93
    //     0x8a8bf8: ldur            w1, [x0, #0x93]
    // 0x8a8bfc: DecompressPointer r1
    //     0x8a8bfc: add             x1, x1, HEAP, lsl #32
    // 0x8a8c00: cmp             w1, NULL
    // 0x8a8c04: b.ne            #0x8a8c10
    // 0x8a8c08: mov             x12, x7
    // 0x8a8c0c: b               #0x8a8c14
    // 0x8a8c10: mov             x12, x1
    // 0x8a8c14: stur            x12, [fp, #-0xf0]
    // 0x8a8c18: LoadField: r1 = r0->field_97
    //     0x8a8c18: ldur            w1, [x0, #0x97]
    // 0x8a8c1c: DecompressPointer r1
    //     0x8a8c1c: add             x1, x1, HEAP, lsl #32
    // 0x8a8c20: cmp             w1, NULL
    // 0x8a8c24: b.ne            #0x8a8c30
    // 0x8a8c28: mov             x13, x7
    // 0x8a8c2c: b               #0x8a8c34
    // 0x8a8c30: mov             x13, x1
    // 0x8a8c34: stur            x13, [fp, #-0xe8]
    // 0x8a8c38: LoadField: r1 = r0->field_9b
    //     0x8a8c38: ldur            w1, [x0, #0x9b]
    // 0x8a8c3c: DecompressPointer r1
    //     0x8a8c3c: add             x1, x1, HEAP, lsl #32
    // 0x8a8c40: cmp             w1, NULL
    // 0x8a8c44: b.ne            #0x8a8c50
    // 0x8a8c48: mov             x14, x7
    // 0x8a8c4c: b               #0x8a8c54
    // 0x8a8c50: mov             x14, x1
    // 0x8a8c54: stur            x14, [fp, #-0xe0]
    // 0x8a8c58: LoadField: r1 = r0->field_9f
    //     0x8a8c58: ldur            w1, [x0, #0x9f]
    // 0x8a8c5c: DecompressPointer r1
    //     0x8a8c5c: add             x1, x1, HEAP, lsl #32
    // 0x8a8c60: cmp             w1, NULL
    // 0x8a8c64: b.ne            #0x8a8c70
    // 0x8a8c68: mov             x19, x7
    // 0x8a8c6c: b               #0x8a8c74
    // 0x8a8c70: mov             x19, x1
    // 0x8a8c74: stur            x19, [fp, #-0xd8]
    // 0x8a8c78: LoadField: r1 = r0->field_a3
    //     0x8a8c78: ldur            w1, [x0, #0xa3]
    // 0x8a8c7c: DecompressPointer r1
    //     0x8a8c7c: add             x1, x1, HEAP, lsl #32
    // 0x8a8c80: cmp             w1, NULL
    // 0x8a8c84: b.ne            #0x8a8c90
    // 0x8a8c88: mov             x20, x8
    // 0x8a8c8c: b               #0x8a8c94
    // 0x8a8c90: mov             x20, x1
    // 0x8a8c94: mov             x1, x0
    // 0x8a8c98: stur            x20, [fp, #-0xd0]
    // 0x8a8c9c: r0 = outline()
    //     0x8a8c9c: bl              #0x8a9038  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::outline
    // 0x8a8ca0: ldur            x1, [fp, #-0xa0]
    // 0x8a8ca4: r17 = -328
    //     0x8a8ca4: mov             x17, #-0x148
    // 0x8a8ca8: str             x0, [fp, x17]
    // 0x8a8cac: r0 = outlineVariant()
    //     0x8a8cac: bl              #0x8a9010  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::outlineVariant
    // 0x8a8cb0: mov             x1, x0
    // 0x8a8cb4: ldur            x0, [fp, #-0xa0]
    // 0x8a8cb8: r17 = -400
    //     0x8a8cb8: mov             x17, #-0x190
    // 0x8a8cbc: str             x1, [fp, x17]
    // 0x8a8cc0: LoadField: r2 = r0->field_af
    //     0x8a8cc0: ldur            w2, [x0, #0xaf]
    // 0x8a8cc4: DecompressPointer r2
    //     0x8a8cc4: add             x2, x2, HEAP, lsl #32
    // 0x8a8cc8: cmp             w2, NULL
    // 0x8a8ccc: b.ne            #0x8a8cd8
    // 0x8a8cd0: r2 = Instance_Color
    //     0x8a8cd0: add             x2, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0x8a8cd4: ldr             x2, [x2, #0x948]
    // 0x8a8cd8: r17 = -392
    //     0x8a8cd8: mov             x17, #-0x188
    // 0x8a8cdc: str             x2, [fp, x17]
    // 0x8a8ce0: LoadField: r3 = r0->field_b3
    //     0x8a8ce0: ldur            w3, [x0, #0xb3]
    // 0x8a8ce4: DecompressPointer r3
    //     0x8a8ce4: add             x3, x3, HEAP, lsl #32
    // 0x8a8ce8: cmp             w3, NULL
    // 0x8a8cec: b.ne            #0x8a8cf8
    // 0x8a8cf0: r3 = Instance_Color
    //     0x8a8cf0: add             x3, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0x8a8cf4: ldr             x3, [x3, #0x948]
    // 0x8a8cf8: r17 = -384
    //     0x8a8cf8: mov             x17, #-0x180
    // 0x8a8cfc: str             x3, [fp, x17]
    // 0x8a8d00: LoadField: r4 = r0->field_b7
    //     0x8a8d00: ldur            w4, [x0, #0xb7]
    // 0x8a8d04: DecompressPointer r4
    //     0x8a8d04: add             x4, x4, HEAP, lsl #32
    // 0x8a8d08: cmp             w4, NULL
    // 0x8a8d0c: b.ne            #0x8a8d18
    // 0x8a8d10: r17 = -272
    //     0x8a8d10: mov             x17, #-0x110
    // 0x8a8d14: ldr             x4, [fp, x17]
    // 0x8a8d18: r17 = -376
    //     0x8a8d18: mov             x17, #-0x178
    // 0x8a8d1c: str             x4, [fp, x17]
    // 0x8a8d20: LoadField: r5 = r0->field_bb
    //     0x8a8d20: ldur            w5, [x0, #0xbb]
    // 0x8a8d24: DecompressPointer r5
    //     0x8a8d24: add             x5, x5, HEAP, lsl #32
    // 0x8a8d28: cmp             w5, NULL
    // 0x8a8d2c: b.ne            #0x8a8d38
    // 0x8a8d30: r17 = -280
    //     0x8a8d30: mov             x17, #-0x118
    // 0x8a8d34: ldr             x5, [fp, x17]
    // 0x8a8d38: r17 = -368
    //     0x8a8d38: mov             x17, #-0x170
    // 0x8a8d3c: str             x5, [fp, x17]
    // 0x8a8d40: LoadField: r6 = r0->field_bf
    //     0x8a8d40: ldur            w6, [x0, #0xbf]
    // 0x8a8d44: DecompressPointer r6
    //     0x8a8d44: add             x6, x6, HEAP, lsl #32
    // 0x8a8d48: cmp             w6, NULL
    // 0x8a8d4c: b.ne            #0x8a8d54
    // 0x8a8d50: ldur            x6, [fp, #-0x88]
    // 0x8a8d54: r17 = -360
    //     0x8a8d54: mov             x17, #-0x168
    // 0x8a8d58: str             x6, [fp, x17]
    // 0x8a8d5c: LoadField: r7 = r0->field_c3
    //     0x8a8d5c: ldur            w7, [x0, #0xc3]
    // 0x8a8d60: DecompressPointer r7
    //     0x8a8d60: add             x7, x7, HEAP, lsl #32
    // 0x8a8d64: cmp             w7, NULL
    // 0x8a8d68: b.ne            #0x8a8d70
    // 0x8a8d6c: ldur            x7, [fp, #-0x90]
    // 0x8a8d70: r17 = -352
    //     0x8a8d70: mov             x17, #-0x160
    // 0x8a8d74: str             x7, [fp, x17]
    // 0x8a8d78: LoadField: r8 = r0->field_c7
    //     0x8a8d78: ldur            w8, [x0, #0xc7]
    // 0x8a8d7c: DecompressPointer r8
    //     0x8a8d7c: add             x8, x8, HEAP, lsl #32
    // 0x8a8d80: r17 = -344
    //     0x8a8d80: mov             x17, #-0x158
    // 0x8a8d84: str             x8, [fp, x17]
    // 0x8a8d88: LoadField: r9 = r0->field_cb
    //     0x8a8d88: ldur            w9, [x0, #0xcb]
    // 0x8a8d8c: DecompressPointer r9
    //     0x8a8d8c: add             x9, x9, HEAP, lsl #32
    // 0x8a8d90: r17 = -336
    //     0x8a8d90: mov             x17, #-0x150
    // 0x8a8d94: str             x9, [fp, x17]
    // 0x8a8d98: LoadField: r10 = r0->field_83
    //     0x8a8d98: ldur            w10, [x0, #0x83]
    // 0x8a8d9c: DecompressPointer r10
    //     0x8a8d9c: add             x10, x10, HEAP, lsl #32
    // 0x8a8da0: cmp             w10, NULL
    // 0x8a8da4: b.ne            #0x8a8dc0
    // 0x8a8da8: SaveReg r0
    //     0x8a8da8: str             x0, [SP, #-8]!
    // 0x8a8dac: r17 = -280
    //     0x8a8dac: mov             x17, #-0x118
    // 0x8a8db0: ldr             x0, [fp, x17]
    // 0x8a8db4: stur            x0, [fp, #-0xa0]
    // 0x8a8db8: RestoreReg r0
    //     0x8a8db8: ldr             x0, [SP], #8
    // 0x8a8dbc: b               #0x8a8dc4
    // 0x8a8dc0: stur            x10, [fp, #-0xa0]
    // 0x8a8dc4: r17 = -320
    //     0x8a8dc4: mov             x17, #-0x140
    // 0x8a8dc8: ldr             x10, [fp, x17]
    // 0x8a8dcc: r17 = -312
    //     0x8a8dcc: mov             x17, #-0x138
    // 0x8a8dd0: ldr             x11, [fp, x17]
    // 0x8a8dd4: r17 = -304
    //     0x8a8dd4: mov             x17, #-0x130
    // 0x8a8dd8: ldr             x12, [fp, x17]
    // 0x8a8ddc: r17 = -280
    //     0x8a8ddc: mov             x17, #-0x118
    // 0x8a8de0: ldr             x19, [fp, x17]
    // 0x8a8de4: r17 = -272
    //     0x8a8de4: mov             x17, #-0x110
    // 0x8a8de8: ldr             x20, [fp, x17]
    // 0x8a8dec: r17 = -328
    //     0x8a8dec: mov             x17, #-0x148
    // 0x8a8df0: ldr             x0, [fp, x17]
    // 0x8a8df4: r17 = -296
    //     0x8a8df4: mov             x17, #-0x128
    // 0x8a8df8: ldr             x13, [fp, x17]
    // 0x8a8dfc: r17 = -288
    //     0x8a8dfc: mov             x17, #-0x120
    // 0x8a8e00: ldr             x14, [fp, x17]
    // 0x8a8e04: r17 = -264
    //     0x8a8e04: mov             x17, #-0x108
    // 0x8a8e08: ldr             x23, [fp, x17]
    // 0x8a8e0c: ldur            x24, [fp, #-0x100]
    // 0x8a8e10: ldur            x25, [fp, #-0xf8]
    // 0x8a8e14: r0 = ColorScheme()
    //     0x8a8e14: bl              #0x8a9004  ; AllocateColorSchemeStub -> ColorScheme (size=0xd0)
    // 0x8a8e18: ldur            x1, [fp, #-0x98]
    // 0x8a8e1c: StoreField: r0->field_7 = r1
    //     0x8a8e1c: stur            w1, [x0, #7]
    // 0x8a8e20: ldur            x1, [fp, #-0x90]
    // 0x8a8e24: StoreField: r0->field_b = r1
    //     0x8a8e24: stur            w1, [x0, #0xb]
    // 0x8a8e28: ldur            x1, [fp, #-0x88]
    // 0x8a8e2c: StoreField: r0->field_f = r1
    //     0x8a8e2c: stur            w1, [x0, #0xf]
    // 0x8a8e30: ldur            x1, [fp, #-0x50]
    // 0x8a8e34: StoreField: r0->field_2b = r1
    //     0x8a8e34: stur            w1, [x0, #0x2b]
    // 0x8a8e38: ldur            x1, [fp, #-0x48]
    // 0x8a8e3c: StoreField: r0->field_2f = r1
    //     0x8a8e3c: stur            w1, [x0, #0x2f]
    // 0x8a8e40: r17 = -312
    //     0x8a8e40: mov             x17, #-0x138
    // 0x8a8e44: ldr             x1, [fp, x17]
    // 0x8a8e48: StoreField: r0->field_6b = r1
    //     0x8a8e48: stur            w1, [x0, #0x6b]
    // 0x8a8e4c: r17 = -304
    //     0x8a8e4c: mov             x17, #-0x130
    // 0x8a8e50: ldr             x1, [fp, x17]
    // 0x8a8e54: StoreField: r0->field_6f = r1
    //     0x8a8e54: stur            w1, [x0, #0x6f]
    // 0x8a8e58: r17 = -280
    //     0x8a8e58: mov             x17, #-0x118
    // 0x8a8e5c: ldr             x1, [fp, x17]
    // 0x8a8e60: StoreField: r0->field_7b = r1
    //     0x8a8e60: stur            w1, [x0, #0x7b]
    // 0x8a8e64: r17 = -272
    //     0x8a8e64: mov             x17, #-0x110
    // 0x8a8e68: ldr             x1, [fp, x17]
    // 0x8a8e6c: StoreField: r0->field_7f = r1
    //     0x8a8e6c: stur            w1, [x0, #0x7f]
    // 0x8a8e70: ldur            x1, [fp, #-0x80]
    // 0x8a8e74: StoreField: r0->field_13 = r1
    //     0x8a8e74: stur            w1, [x0, #0x13]
    // 0x8a8e78: ldur            x1, [fp, #-0x78]
    // 0x8a8e7c: ArrayStore: r0[0] = r1  ; List_4
    //     0x8a8e7c: stur            w1, [x0, #0x17]
    // 0x8a8e80: ldur            x1, [fp, #-0x70]
    // 0x8a8e84: StoreField: r0->field_1b = r1
    //     0x8a8e84: stur            w1, [x0, #0x1b]
    // 0x8a8e88: ldur            x1, [fp, #-0x68]
    // 0x8a8e8c: StoreField: r0->field_1f = r1
    //     0x8a8e8c: stur            w1, [x0, #0x1f]
    // 0x8a8e90: ldur            x1, [fp, #-0x60]
    // 0x8a8e94: StoreField: r0->field_23 = r1
    //     0x8a8e94: stur            w1, [x0, #0x23]
    // 0x8a8e98: ldur            x1, [fp, #-0x58]
    // 0x8a8e9c: StoreField: r0->field_27 = r1
    //     0x8a8e9c: stur            w1, [x0, #0x27]
    // 0x8a8ea0: ldur            x1, [fp, #-0x40]
    // 0x8a8ea4: StoreField: r0->field_33 = r1
    //     0x8a8ea4: stur            w1, [x0, #0x33]
    // 0x8a8ea8: ldur            x1, [fp, #-0x38]
    // 0x8a8eac: StoreField: r0->field_37 = r1
    //     0x8a8eac: stur            w1, [x0, #0x37]
    // 0x8a8eb0: ldur            x1, [fp, #-0x30]
    // 0x8a8eb4: StoreField: r0->field_3b = r1
    //     0x8a8eb4: stur            w1, [x0, #0x3b]
    // 0x8a8eb8: ldur            x1, [fp, #-0x28]
    // 0x8a8ebc: StoreField: r0->field_3f = r1
    //     0x8a8ebc: stur            w1, [x0, #0x3f]
    // 0x8a8ec0: ldur            x1, [fp, #-0x20]
    // 0x8a8ec4: StoreField: r0->field_43 = r1
    //     0x8a8ec4: stur            w1, [x0, #0x43]
    // 0x8a8ec8: ldur            x1, [fp, #-0x18]
    // 0x8a8ecc: StoreField: r0->field_47 = r1
    //     0x8a8ecc: stur            w1, [x0, #0x47]
    // 0x8a8ed0: ldur            x1, [fp, #-0x10]
    // 0x8a8ed4: StoreField: r0->field_4b = r1
    //     0x8a8ed4: stur            w1, [x0, #0x4b]
    // 0x8a8ed8: ldur            x1, [fp, #-8]
    // 0x8a8edc: StoreField: r0->field_4f = r1
    //     0x8a8edc: stur            w1, [x0, #0x4f]
    // 0x8a8ee0: ldur            x1, [fp, #-0xa8]
    // 0x8a8ee4: StoreField: r0->field_53 = r1
    //     0x8a8ee4: stur            w1, [x0, #0x53]
    // 0x8a8ee8: ldur            x1, [fp, #-0xb0]
    // 0x8a8eec: StoreField: r0->field_57 = r1
    //     0x8a8eec: stur            w1, [x0, #0x57]
    // 0x8a8ef0: ldur            x1, [fp, #-0xb8]
    // 0x8a8ef4: StoreField: r0->field_5b = r1
    //     0x8a8ef4: stur            w1, [x0, #0x5b]
    // 0x8a8ef8: ldur            x1, [fp, #-0xc0]
    // 0x8a8efc: StoreField: r0->field_5f = r1
    //     0x8a8efc: stur            w1, [x0, #0x5f]
    // 0x8a8f00: ldur            x1, [fp, #-0xc8]
    // 0x8a8f04: StoreField: r0->field_63 = r1
    //     0x8a8f04: stur            w1, [x0, #0x63]
    // 0x8a8f08: r17 = -320
    //     0x8a8f08: mov             x17, #-0x140
    // 0x8a8f0c: ldr             x1, [fp, x17]
    // 0x8a8f10: StoreField: r0->field_67 = r1
    //     0x8a8f10: stur            w1, [x0, #0x67]
    // 0x8a8f14: r17 = -296
    //     0x8a8f14: mov             x17, #-0x128
    // 0x8a8f18: ldr             x1, [fp, x17]
    // 0x8a8f1c: StoreField: r0->field_73 = r1
    //     0x8a8f1c: stur            w1, [x0, #0x73]
    // 0x8a8f20: r17 = -288
    //     0x8a8f20: mov             x17, #-0x120
    // 0x8a8f24: ldr             x1, [fp, x17]
    // 0x8a8f28: StoreField: r0->field_77 = r1
    //     0x8a8f28: stur            w1, [x0, #0x77]
    // 0x8a8f2c: r17 = -264
    //     0x8a8f2c: mov             x17, #-0x108
    // 0x8a8f30: ldr             x1, [fp, x17]
    // 0x8a8f34: StoreField: r0->field_87 = r1
    //     0x8a8f34: stur            w1, [x0, #0x87]
    // 0x8a8f38: ldur            x1, [fp, #-0x100]
    // 0x8a8f3c: StoreField: r0->field_8b = r1
    //     0x8a8f3c: stur            w1, [x0, #0x8b]
    // 0x8a8f40: ldur            x1, [fp, #-0xf8]
    // 0x8a8f44: StoreField: r0->field_8f = r1
    //     0x8a8f44: stur            w1, [x0, #0x8f]
    // 0x8a8f48: ldur            x1, [fp, #-0xf0]
    // 0x8a8f4c: StoreField: r0->field_93 = r1
    //     0x8a8f4c: stur            w1, [x0, #0x93]
    // 0x8a8f50: ldur            x1, [fp, #-0xe8]
    // 0x8a8f54: StoreField: r0->field_97 = r1
    //     0x8a8f54: stur            w1, [x0, #0x97]
    // 0x8a8f58: ldur            x1, [fp, #-0xe0]
    // 0x8a8f5c: StoreField: r0->field_9b = r1
    //     0x8a8f5c: stur            w1, [x0, #0x9b]
    // 0x8a8f60: ldur            x1, [fp, #-0xd8]
    // 0x8a8f64: StoreField: r0->field_9f = r1
    //     0x8a8f64: stur            w1, [x0, #0x9f]
    // 0x8a8f68: ldur            x1, [fp, #-0xd0]
    // 0x8a8f6c: StoreField: r0->field_a3 = r1
    //     0x8a8f6c: stur            w1, [x0, #0xa3]
    // 0x8a8f70: r17 = -328
    //     0x8a8f70: mov             x17, #-0x148
    // 0x8a8f74: ldr             x1, [fp, x17]
    // 0x8a8f78: StoreField: r0->field_a7 = r1
    //     0x8a8f78: stur            w1, [x0, #0xa7]
    // 0x8a8f7c: r17 = -400
    //     0x8a8f7c: mov             x17, #-0x190
    // 0x8a8f80: ldr             x1, [fp, x17]
    // 0x8a8f84: StoreField: r0->field_ab = r1
    //     0x8a8f84: stur            w1, [x0, #0xab]
    // 0x8a8f88: r17 = -392
    //     0x8a8f88: mov             x17, #-0x188
    // 0x8a8f8c: ldr             x1, [fp, x17]
    // 0x8a8f90: StoreField: r0->field_af = r1
    //     0x8a8f90: stur            w1, [x0, #0xaf]
    // 0x8a8f94: r17 = -384
    //     0x8a8f94: mov             x17, #-0x180
    // 0x8a8f98: ldr             x1, [fp, x17]
    // 0x8a8f9c: StoreField: r0->field_b3 = r1
    //     0x8a8f9c: stur            w1, [x0, #0xb3]
    // 0x8a8fa0: r17 = -376
    //     0x8a8fa0: mov             x17, #-0x178
    // 0x8a8fa4: ldr             x1, [fp, x17]
    // 0x8a8fa8: StoreField: r0->field_b7 = r1
    //     0x8a8fa8: stur            w1, [x0, #0xb7]
    // 0x8a8fac: r17 = -368
    //     0x8a8fac: mov             x17, #-0x170
    // 0x8a8fb0: ldr             x1, [fp, x17]
    // 0x8a8fb4: StoreField: r0->field_bb = r1
    //     0x8a8fb4: stur            w1, [x0, #0xbb]
    // 0x8a8fb8: r17 = -360
    //     0x8a8fb8: mov             x17, #-0x168
    // 0x8a8fbc: ldr             x1, [fp, x17]
    // 0x8a8fc0: StoreField: r0->field_bf = r1
    //     0x8a8fc0: stur            w1, [x0, #0xbf]
    // 0x8a8fc4: r17 = -352
    //     0x8a8fc4: mov             x17, #-0x160
    // 0x8a8fc8: ldr             x1, [fp, x17]
    // 0x8a8fcc: StoreField: r0->field_c3 = r1
    //     0x8a8fcc: stur            w1, [x0, #0xc3]
    // 0x8a8fd0: r17 = -344
    //     0x8a8fd0: mov             x17, #-0x158
    // 0x8a8fd4: ldr             x1, [fp, x17]
    // 0x8a8fd8: StoreField: r0->field_c7 = r1
    //     0x8a8fd8: stur            w1, [x0, #0xc7]
    // 0x8a8fdc: r17 = -336
    //     0x8a8fdc: mov             x17, #-0x150
    // 0x8a8fe0: ldr             x1, [fp, x17]
    // 0x8a8fe4: StoreField: r0->field_cb = r1
    //     0x8a8fe4: stur            w1, [x0, #0xcb]
    // 0x8a8fe8: ldur            x1, [fp, #-0xa0]
    // 0x8a8fec: StoreField: r0->field_83 = r1
    //     0x8a8fec: stur            w1, [x0, #0x83]
    // 0x8a8ff0: LeaveFrame
    //     0x8a8ff0: mov             SP, fp
    //     0x8a8ff4: ldp             fp, lr, [SP], #0x10
    // 0x8a8ff8: ret
    //     0x8a8ff8: ret             
    // 0x8a8ffc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a8ffc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a9000: b               #0x8a88c4
  }
  get _ outlineVariant(/* No info */) {
    // ** addr: 0x8a9010, size: 0x28
    // 0x8a9010: LoadField: r2 = r1->field_ab
    //     0x8a9010: ldur            w2, [x1, #0xab]
    // 0x8a9014: DecompressPointer r2
    //     0x8a9014: add             x2, x2, HEAP, lsl #32
    // 0x8a9018: cmp             w2, NULL
    // 0x8a901c: b.ne            #0x8a9030
    // 0x8a9020: LoadField: r3 = r1->field_cb
    //     0x8a9020: ldur            w3, [x1, #0xcb]
    // 0x8a9024: DecompressPointer r3
    //     0x8a9024: add             x3, x3, HEAP, lsl #32
    // 0x8a9028: mov             x0, x3
    // 0x8a902c: b               #0x8a9034
    // 0x8a9030: mov             x0, x2
    // 0x8a9034: ret
    //     0x8a9034: ret             
  }
  get _ outline(/* No info */) {
    // ** addr: 0x8a9038, size: 0x28
    // 0x8a9038: LoadField: r2 = r1->field_a7
    //     0x8a9038: ldur            w2, [x1, #0xa7]
    // 0x8a903c: DecompressPointer r2
    //     0x8a903c: add             x2, x2, HEAP, lsl #32
    // 0x8a9040: cmp             w2, NULL
    // 0x8a9044: b.ne            #0x8a9058
    // 0x8a9048: LoadField: r3 = r1->field_cb
    //     0x8a9048: ldur            w3, [x1, #0xcb]
    // 0x8a904c: DecompressPointer r3
    //     0x8a904c: add             x3, x3, HEAP, lsl #32
    // 0x8a9050: mov             x0, x3
    // 0x8a9054: b               #0x8a905c
    // 0x8a9058: mov             x0, x2
    // 0x8a905c: ret
    //     0x8a905c: ret             
  }
  get _ onTertiaryFixedVariant(/* No info */) {
    // ** addr: 0x8a9060, size: 0x44
    // 0x8a9060: LoadField: r2 = r1->field_67
    //     0x8a9060: ldur            w2, [x1, #0x67]
    // 0x8a9064: DecompressPointer r2
    //     0x8a9064: add             x2, x2, HEAP, lsl #32
    // 0x8a9068: cmp             w2, NULL
    // 0x8a906c: b.ne            #0x8a909c
    // 0x8a9070: LoadField: r3 = r1->field_4f
    //     0x8a9070: ldur            w3, [x1, #0x4f]
    // 0x8a9074: DecompressPointer r3
    //     0x8a9074: add             x3, x3, HEAP, lsl #32
    // 0x8a9078: cmp             w3, NULL
    // 0x8a907c: b.ne            #0x8a9090
    // 0x8a9080: LoadField: r4 = r1->field_2f
    //     0x8a9080: ldur            w4, [x1, #0x2f]
    // 0x8a9084: DecompressPointer r4
    //     0x8a9084: add             x4, x4, HEAP, lsl #32
    // 0x8a9088: mov             x1, x4
    // 0x8a908c: b               #0x8a9094
    // 0x8a9090: mov             x1, x3
    // 0x8a9094: mov             x0, x1
    // 0x8a9098: b               #0x8a90a0
    // 0x8a909c: mov             x0, x2
    // 0x8a90a0: ret
    //     0x8a90a0: ret             
  }
  get _ onTertiaryFixed(/* No info */) {
    // ** addr: 0x8a90a4, size: 0x44
    // 0x8a90a4: LoadField: r2 = r1->field_63
    //     0x8a90a4: ldur            w2, [x1, #0x63]
    // 0x8a90a8: DecompressPointer r2
    //     0x8a90a8: add             x2, x2, HEAP, lsl #32
    // 0x8a90ac: cmp             w2, NULL
    // 0x8a90b0: b.ne            #0x8a90e0
    // 0x8a90b4: LoadField: r3 = r1->field_4f
    //     0x8a90b4: ldur            w3, [x1, #0x4f]
    // 0x8a90b8: DecompressPointer r3
    //     0x8a90b8: add             x3, x3, HEAP, lsl #32
    // 0x8a90bc: cmp             w3, NULL
    // 0x8a90c0: b.ne            #0x8a90d4
    // 0x8a90c4: LoadField: r4 = r1->field_2f
    //     0x8a90c4: ldur            w4, [x1, #0x2f]
    // 0x8a90c8: DecompressPointer r4
    //     0x8a90c8: add             x4, x4, HEAP, lsl #32
    // 0x8a90cc: mov             x1, x4
    // 0x8a90d0: b               #0x8a90d8
    // 0x8a90d4: mov             x1, x3
    // 0x8a90d8: mov             x0, x1
    // 0x8a90dc: b               #0x8a90e4
    // 0x8a90e0: mov             x0, x2
    // 0x8a90e4: ret
    //     0x8a90e4: ret             
  }
  get _ tertiaryFixedDim(/* No info */) {
    // ** addr: 0x8a90e8, size: 0x44
    // 0x8a90e8: LoadField: r2 = r1->field_5f
    //     0x8a90e8: ldur            w2, [x1, #0x5f]
    // 0x8a90ec: DecompressPointer r2
    //     0x8a90ec: add             x2, x2, HEAP, lsl #32
    // 0x8a90f0: cmp             w2, NULL
    // 0x8a90f4: b.ne            #0x8a9124
    // 0x8a90f8: LoadField: r3 = r1->field_4b
    //     0x8a90f8: ldur            w3, [x1, #0x4b]
    // 0x8a90fc: DecompressPointer r3
    //     0x8a90fc: add             x3, x3, HEAP, lsl #32
    // 0x8a9100: cmp             w3, NULL
    // 0x8a9104: b.ne            #0x8a9118
    // 0x8a9108: LoadField: r4 = r1->field_2b
    //     0x8a9108: ldur            w4, [x1, #0x2b]
    // 0x8a910c: DecompressPointer r4
    //     0x8a910c: add             x4, x4, HEAP, lsl #32
    // 0x8a9110: mov             x1, x4
    // 0x8a9114: b               #0x8a911c
    // 0x8a9118: mov             x1, x3
    // 0x8a911c: mov             x0, x1
    // 0x8a9120: b               #0x8a9128
    // 0x8a9124: mov             x0, x2
    // 0x8a9128: ret
    //     0x8a9128: ret             
  }
  get _ tertiaryFixed(/* No info */) {
    // ** addr: 0x8a912c, size: 0x44
    // 0x8a912c: LoadField: r2 = r1->field_5b
    //     0x8a912c: ldur            w2, [x1, #0x5b]
    // 0x8a9130: DecompressPointer r2
    //     0x8a9130: add             x2, x2, HEAP, lsl #32
    // 0x8a9134: cmp             w2, NULL
    // 0x8a9138: b.ne            #0x8a9168
    // 0x8a913c: LoadField: r3 = r1->field_4b
    //     0x8a913c: ldur            w3, [x1, #0x4b]
    // 0x8a9140: DecompressPointer r3
    //     0x8a9140: add             x3, x3, HEAP, lsl #32
    // 0x8a9144: cmp             w3, NULL
    // 0x8a9148: b.ne            #0x8a915c
    // 0x8a914c: LoadField: r4 = r1->field_2b
    //     0x8a914c: ldur            w4, [x1, #0x2b]
    // 0x8a9150: DecompressPointer r4
    //     0x8a9150: add             x4, x4, HEAP, lsl #32
    // 0x8a9154: mov             x1, x4
    // 0x8a9158: b               #0x8a9160
    // 0x8a915c: mov             x1, x3
    // 0x8a9160: mov             x0, x1
    // 0x8a9164: b               #0x8a916c
    // 0x8a9168: mov             x0, x2
    // 0x8a916c: ret
    //     0x8a916c: ret             
  }
  get _ onTertiaryContainer(/* No info */) {
    // ** addr: 0x8a9170, size: 0x44
    // 0x8a9170: LoadField: r2 = r1->field_57
    //     0x8a9170: ldur            w2, [x1, #0x57]
    // 0x8a9174: DecompressPointer r2
    //     0x8a9174: add             x2, x2, HEAP, lsl #32
    // 0x8a9178: cmp             w2, NULL
    // 0x8a917c: b.ne            #0x8a91ac
    // 0x8a9180: LoadField: r3 = r1->field_4f
    //     0x8a9180: ldur            w3, [x1, #0x4f]
    // 0x8a9184: DecompressPointer r3
    //     0x8a9184: add             x3, x3, HEAP, lsl #32
    // 0x8a9188: cmp             w3, NULL
    // 0x8a918c: b.ne            #0x8a91a0
    // 0x8a9190: LoadField: r4 = r1->field_2f
    //     0x8a9190: ldur            w4, [x1, #0x2f]
    // 0x8a9194: DecompressPointer r4
    //     0x8a9194: add             x4, x4, HEAP, lsl #32
    // 0x8a9198: mov             x1, x4
    // 0x8a919c: b               #0x8a91a4
    // 0x8a91a0: mov             x1, x3
    // 0x8a91a4: mov             x0, x1
    // 0x8a91a8: b               #0x8a91b0
    // 0x8a91ac: mov             x0, x2
    // 0x8a91b0: ret
    //     0x8a91b0: ret             
  }
  get _ tertiaryContainer(/* No info */) {
    // ** addr: 0x8a91b4, size: 0x44
    // 0x8a91b4: LoadField: r2 = r1->field_53
    //     0x8a91b4: ldur            w2, [x1, #0x53]
    // 0x8a91b8: DecompressPointer r2
    //     0x8a91b8: add             x2, x2, HEAP, lsl #32
    // 0x8a91bc: cmp             w2, NULL
    // 0x8a91c0: b.ne            #0x8a91f0
    // 0x8a91c4: LoadField: r3 = r1->field_4b
    //     0x8a91c4: ldur            w3, [x1, #0x4b]
    // 0x8a91c8: DecompressPointer r3
    //     0x8a91c8: add             x3, x3, HEAP, lsl #32
    // 0x8a91cc: cmp             w3, NULL
    // 0x8a91d0: b.ne            #0x8a91e4
    // 0x8a91d4: LoadField: r4 = r1->field_2b
    //     0x8a91d4: ldur            w4, [x1, #0x2b]
    // 0x8a91d8: DecompressPointer r4
    //     0x8a91d8: add             x4, x4, HEAP, lsl #32
    // 0x8a91dc: mov             x1, x4
    // 0x8a91e0: b               #0x8a91e8
    // 0x8a91e4: mov             x1, x3
    // 0x8a91e8: mov             x0, x1
    // 0x8a91ec: b               #0x8a91f4
    // 0x8a91f0: mov             x0, x2
    // 0x8a91f4: ret
    //     0x8a91f4: ret             
  }
  factory _ ColorScheme.fromSwatch(/* No info */) {
    // ** addr: 0x8ad59c, size: 0x1d8
    // 0x8ad59c: EnterFrame
    //     0x8ad59c: stp             fp, lr, [SP, #-0x10]!
    //     0x8ad5a0: mov             fp, SP
    // 0x8ad5a4: AllocStack(0x58)
    //     0x8ad5a4: sub             SP, SP, #0x58
    // 0x8ad5a8: SetupParameters(dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */, dynamic _ /* r6 => r6, fp-0x28 */, dynamic _ /* r7 => r7, fp-0x30 */)
    //     0x8ad5a8: mov             x0, x2
    //     0x8ad5ac: stur            x2, [fp, #-0x10]
    //     0x8ad5b0: stur            x3, [fp, #-0x18]
    //     0x8ad5b4: stur            x5, [fp, #-0x20]
    //     0x8ad5b8: stur            x6, [fp, #-0x28]
    //     0x8ad5bc: stur            x7, [fp, #-0x30]
    // 0x8ad5c0: CheckStackOverflow
    //     0x8ad5c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ad5c4: cmp             SP, x16
    //     0x8ad5c8: b.ls            #0x8ad768
    // 0x8ad5cc: r16 = Instance_Brightness
    //     0x8ad5cc: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0x8ad5d0: cmp             w5, w16
    // 0x8ad5d4: r16 = true
    //     0x8ad5d4: add             x16, NULL, #0x20  ; true
    // 0x8ad5d8: r17 = false
    //     0x8ad5d8: add             x17, NULL, #0x30  ; false
    // 0x8ad5dc: csel            x2, x16, x17, eq
    // 0x8ad5e0: stur            x2, [fp, #-8]
    // 0x8ad5e4: r1 = Instance_MaterialColor
    //     0x8ad5e4: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c28] Obj!MaterialColor@12a6e31
    //     0x8ad5e8: ldr             x1, [x1, #0xc28]
    // 0x8ad5ec: r0 = estimateBrightnessForColor()
    //     0x8ad5ec: bl              #0x8ad774  ; [package:flutter/src/material/theme_data.dart] ThemeData::estimateBrightnessForColor
    // 0x8ad5f0: r16 = Instance_Brightness
    //     0x8ad5f0: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0x8ad5f4: cmp             w0, w16
    // 0x8ad5f8: r16 = true
    //     0x8ad5f8: add             x16, NULL, #0x20  ; true
    // 0x8ad5fc: r17 = false
    //     0x8ad5fc: add             x17, NULL, #0x30  ; false
    // 0x8ad600: csel            x2, x16, x17, eq
    // 0x8ad604: ldur            x1, [fp, #-0x10]
    // 0x8ad608: stur            x2, [fp, #-0x38]
    // 0x8ad60c: r0 = estimateBrightnessForColor()
    //     0x8ad60c: bl              #0x8ad774  ; [package:flutter/src/material/theme_data.dart] ThemeData::estimateBrightnessForColor
    // 0x8ad610: mov             x3, x0
    // 0x8ad614: ldur            x0, [fp, #-0x30]
    // 0x8ad618: stur            x3, [fp, #-0x40]
    // 0x8ad61c: cmp             w0, NULL
    // 0x8ad620: b.ne            #0x8ad644
    // 0x8ad624: r1 = _ConstMap len:10
    //     0x8ad624: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c68] Map<int, Color>(10)
    //     0x8ad628: ldr             x1, [x1, #0xc68]
    // 0x8ad62c: r2 = 1400
    //     0x8ad62c: mov             x2, #0x578
    // 0x8ad630: r0 = []()
    //     0x8ad630: bl              #0x13cd4a4  ; [dart:_compact_hash] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x8ad634: cmp             w0, NULL
    // 0x8ad638: b.eq            #0x8ad770
    // 0x8ad63c: mov             x1, x0
    // 0x8ad640: b               #0x8ad648
    // 0x8ad644: mov             x1, x0
    // 0x8ad648: ldur            x0, [fp, #-0x38]
    // 0x8ad64c: stur            x1, [fp, #-0x58]
    // 0x8ad650: tbnz            w0, #4, #0x8ad660
    // 0x8ad654: r3 = Instance_Color
    //     0x8ad654: add             x3, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0x8ad658: ldr             x3, [x3, #0xc38]
    // 0x8ad65c: b               #0x8ad668
    // 0x8ad660: r3 = Instance_Color
    //     0x8ad660: add             x3, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0x8ad664: ldr             x3, [x3, #0x948]
    // 0x8ad668: ldur            x2, [fp, #-0x40]
    // 0x8ad66c: stur            x3, [fp, #-0x50]
    // 0x8ad670: r16 = Instance_Brightness
    //     0x8ad670: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0x8ad674: cmp             w2, w16
    // 0x8ad678: b.ne            #0x8ad688
    // 0x8ad67c: r4 = Instance_Color
    //     0x8ad67c: add             x4, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0x8ad680: ldr             x4, [x4, #0xc38]
    // 0x8ad684: b               #0x8ad690
    // 0x8ad688: r4 = Instance_Color
    //     0x8ad688: add             x4, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0x8ad68c: ldr             x4, [x4, #0x948]
    // 0x8ad690: ldur            x2, [fp, #-8]
    // 0x8ad694: stur            x4, [fp, #-0x48]
    // 0x8ad698: tbnz            w2, #4, #0x8ad6a8
    // 0x8ad69c: r5 = Instance_Color
    //     0x8ad69c: add             x5, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0x8ad6a0: ldr             x5, [x5, #0xc38]
    // 0x8ad6a4: b               #0x8ad6b0
    // 0x8ad6a8: r5 = Instance_Color
    //     0x8ad6a8: add             x5, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0x8ad6ac: ldr             x5, [x5, #0x948]
    // 0x8ad6b0: stur            x5, [fp, #-0x40]
    // 0x8ad6b4: tbnz            w2, #4, #0x8ad6c4
    // 0x8ad6b8: r2 = Instance_Color
    //     0x8ad6b8: add             x2, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0x8ad6bc: ldr             x2, [x2, #0x948]
    // 0x8ad6c0: b               #0x8ad6cc
    // 0x8ad6c4: r2 = Instance_Color
    //     0x8ad6c4: add             x2, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0x8ad6c8: ldr             x2, [x2, #0xc38]
    // 0x8ad6cc: stur            x2, [fp, #-0x30]
    // 0x8ad6d0: tbnz            w0, #4, #0x8ad6e0
    // 0x8ad6d4: r9 = Instance_Color
    //     0x8ad6d4: add             x9, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0x8ad6d8: ldr             x9, [x9, #0xc38]
    // 0x8ad6dc: b               #0x8ad6e8
    // 0x8ad6e0: r9 = Instance_Color
    //     0x8ad6e0: add             x9, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0x8ad6e4: ldr             x9, [x9, #0x948]
    // 0x8ad6e8: ldur            x8, [fp, #-0x10]
    // 0x8ad6ec: ldur            x7, [fp, #-0x18]
    // 0x8ad6f0: ldur            x6, [fp, #-0x20]
    // 0x8ad6f4: ldur            x0, [fp, #-0x28]
    // 0x8ad6f8: stur            x9, [fp, #-8]
    // 0x8ad6fc: r0 = ColorScheme()
    //     0x8ad6fc: bl              #0x8a9004  ; AllocateColorSchemeStub -> ColorScheme (size=0xd0)
    // 0x8ad700: ldur            x1, [fp, #-0x20]
    // 0x8ad704: StoreField: r0->field_7 = r1
    //     0x8ad704: stur            w1, [x0, #7]
    // 0x8ad708: r1 = Instance_MaterialColor
    //     0x8ad708: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c28] Obj!MaterialColor@12a6e31
    //     0x8ad70c: ldr             x1, [x1, #0xc28]
    // 0x8ad710: StoreField: r0->field_b = r1
    //     0x8ad710: stur            w1, [x0, #0xb]
    // 0x8ad714: ldur            x1, [fp, #-0x50]
    // 0x8ad718: StoreField: r0->field_f = r1
    //     0x8ad718: stur            w1, [x0, #0xf]
    // 0x8ad71c: ldur            x1, [fp, #-0x10]
    // 0x8ad720: StoreField: r0->field_2b = r1
    //     0x8ad720: stur            w1, [x0, #0x2b]
    // 0x8ad724: ldur            x1, [fp, #-0x48]
    // 0x8ad728: StoreField: r0->field_2f = r1
    //     0x8ad728: stur            w1, [x0, #0x2f]
    // 0x8ad72c: ldur            x1, [fp, #-0x58]
    // 0x8ad730: StoreField: r0->field_6b = r1
    //     0x8ad730: stur            w1, [x0, #0x6b]
    // 0x8ad734: ldur            x1, [fp, #-0x30]
    // 0x8ad738: StoreField: r0->field_6f = r1
    //     0x8ad738: stur            w1, [x0, #0x6f]
    // 0x8ad73c: ldur            x1, [fp, #-0x28]
    // 0x8ad740: StoreField: r0->field_7b = r1
    //     0x8ad740: stur            w1, [x0, #0x7b]
    // 0x8ad744: ldur            x1, [fp, #-0x40]
    // 0x8ad748: StoreField: r0->field_7f = r1
    //     0x8ad748: stur            w1, [x0, #0x7f]
    // 0x8ad74c: ldur            x1, [fp, #-0x18]
    // 0x8ad750: StoreField: r0->field_c7 = r1
    //     0x8ad750: stur            w1, [x0, #0xc7]
    // 0x8ad754: ldur            x1, [fp, #-8]
    // 0x8ad758: StoreField: r0->field_cb = r1
    //     0x8ad758: stur            w1, [x0, #0xcb]
    // 0x8ad75c: LeaveFrame
    //     0x8ad75c: mov             SP, fp
    //     0x8ad760: ldp             fp, lr, [SP], #0x10
    // 0x8ad764: ret
    //     0x8ad764: ret             
    // 0x8ad768: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8ad768: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8ad76c: b               #0x8ad5cc
    // 0x8ad770: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8ad770: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  factory _ ColorScheme.fromSeed(/* No info */) {
    // ** addr: 0x8ad91c, size: 0x2e8c
    // 0x8ad91c: EnterFrame
    //     0x8ad91c: stp             fp, lr, [SP, #-0x10]!
    //     0x8ad920: mov             fp, SP
    // 0x8ad924: AllocStack(0x1b0)
    //     0x8ad924: sub             SP, SP, #0x1b0
    // 0x8ad928: SetupParameters({dynamic brightness = Instance_Brightness /* r3, fp-0x18 */, dynamic onPrimary = Null /* r5, fp-0x10 */, dynamic primary = Null /* r0, fp-0x8 */})
    //     0x8ad928: ldur            w0, [x4, #0x13]
    //     0x8ad92c: ldur            w1, [x4, #0x1f]
    //     0x8ad930: add             x1, x1, HEAP, lsl #32
    //     0x8ad934: add             x16, PP, #0x12, lsl #12  ; [pp+0x129d0] "brightness"
    //     0x8ad938: ldr             x16, [x16, #0x9d0]
    //     0x8ad93c: cmp             w1, w16
    //     0x8ad940: b.ne            #0x8ad964
    //     0x8ad944: ldur            w1, [x4, #0x23]
    //     0x8ad948: add             x1, x1, HEAP, lsl #32
    //     0x8ad94c: sub             w3, w0, w1
    //     0x8ad950: add             x1, fp, w3, sxtw #2
    //     0x8ad954: ldr             x1, [x1, #8]
    //     0x8ad958: mov             x3, x1
    //     0x8ad95c: mov             x1, #1
    //     0x8ad960: b               #0x8ad96c
    //     0x8ad964: ldr             x3, [PP, #0x6da0]  ; [pp+0x6da0] Obj!Brightness@12c71c1
    //     0x8ad968: mov             x1, #0
    //     0x8ad96c: stur            x3, [fp, #-0x18]
    //     0x8ad970: lsl             x5, x1, #1
    //     0x8ad974: lsl             w6, w5, #1
    //     0x8ad978: add             w7, w6, #8
    //     0x8ad97c: add             x16, x4, w7, sxtw #1
    //     0x8ad980: ldur            w8, [x16, #0xf]
    //     0x8ad984: add             x8, x8, HEAP, lsl #32
    //     0x8ad988: add             x16, PP, #0x12, lsl #12  ; [pp+0x12f10] "onPrimary"
    //     0x8ad98c: ldr             x16, [x16, #0xf10]
    //     0x8ad990: cmp             w8, w16
    //     0x8ad994: b.ne            #0x8ad9c8
    //     0x8ad998: add             w1, w6, #0xa
    //     0x8ad99c: add             x16, x4, w1, sxtw #1
    //     0x8ad9a0: ldur            w6, [x16, #0xf]
    //     0x8ad9a4: add             x6, x6, HEAP, lsl #32
    //     0x8ad9a8: sub             w1, w0, w6
    //     0x8ad9ac: add             x6, fp, w1, sxtw #2
    //     0x8ad9b0: ldr             x6, [x6, #8]
    //     0x8ad9b4: add             w1, w5, #2
    //     0x8ad9b8: sbfx            x5, x1, #1, #0x1f
    //     0x8ad9bc: mov             x1, x5
    //     0x8ad9c0: mov             x5, x6
    //     0x8ad9c4: b               #0x8ad9cc
    //     0x8ad9c8: mov             x5, NULL
    //     0x8ad9cc: stur            x5, [fp, #-0x10]
    //     0x8ad9d0: lsl             x6, x1, #1
    //     0x8ad9d4: lsl             w1, w6, #1
    //     0x8ad9d8: add             w6, w1, #8
    //     0x8ad9dc: add             x16, x4, w6, sxtw #1
    //     0x8ad9e0: ldur            w7, [x16, #0xf]
    //     0x8ad9e4: add             x7, x7, HEAP, lsl #32
    //     0x8ad9e8: add             x16, PP, #0x12, lsl #12  ; [pp+0x12f18] "primary"
    //     0x8ad9ec: ldr             x16, [x16, #0xf18]
    //     0x8ad9f0: cmp             w7, w16
    //     0x8ad9f4: b.ne            #0x8ada18
    //     0x8ad9f8: add             w6, w1, #0xa
    //     0x8ad9fc: add             x16, x4, w6, sxtw #1
    //     0x8ada00: ldur            w1, [x16, #0xf]
    //     0x8ada04: add             x1, x1, HEAP, lsl #32
    //     0x8ada08: sub             w4, w0, w1
    //     0x8ada0c: add             x0, fp, w4, sxtw #2
    //     0x8ada10: ldr             x0, [x0, #8]
    //     0x8ada14: b               #0x8ada1c
    //     0x8ada18: mov             x0, NULL
    //     0x8ada1c: stur            x0, [fp, #-8]
    // 0x8ada20: CheckStackOverflow
    //     0x8ada20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8ada24: cmp             SP, x16
    //     0x8ada28: b.ls            #0x8b07a0
    // 0x8ada2c: mov             x1, x3
    // 0x8ada30: r0 = _buildDynamicScheme()
    //     0x8ada30: bl              #0x8b8dc0  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::_buildDynamicScheme
    // 0x8ada34: mov             x1, x0
    // 0x8ada38: ldur            x0, [fp, #-8]
    // 0x8ada3c: stur            x1, [fp, #-0x20]
    // 0x8ada40: cmp             w0, NULL
    // 0x8ada44: b.ne            #0x8adb28
    // 0x8ada48: r0 = LoadStaticField(0x1160)
    //     0x8ada48: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8ada4c: ldr             x0, [x0, #0x22c0]
    // 0x8ada50: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8ada54: cmp             w0, w16
    // 0x8ada58: b.ne            #0x8ada68
    // 0x8ada5c: r2 = primary
    //     0x8ada5c: add             x2, PP, #0x12, lsl #12  ; [pp+0x12f20] Field <MaterialDynamicColors.primary>: static late final (offset: 0x1160)
    //     0x8ada60: ldr             x2, [x2, #0xf20]
    // 0x8ada64: r0 = InitLateFinalStaticField()
    //     0x8ada64: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8ada68: mov             x1, x0
    // 0x8ada6c: ldur            x2, [fp, #-0x20]
    // 0x8ada70: r0 = getArgb()
    //     0x8ada70: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8ada74: stur            x0, [fp, #-0x38]
    // 0x8ada78: asr             x1, x0, #0x18
    // 0x8ada7c: asr             x2, x0, #0x10
    // 0x8ada80: stur            x2, [fp, #-0x30]
    // 0x8ada84: asr             x3, x0, #8
    // 0x8ada88: stur            x3, [fp, #-0x28]
    // 0x8ada8c: ubfx            x1, x1, #0, #0x20
    // 0x8ada90: and             w4, w1, #0xff
    // 0x8ada94: ubfx            x4, x4, #0, #0x20
    // 0x8ada98: scvtf           d0, x4
    // 0x8ada9c: d1 = 255.000000
    //     0x8ada9c: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8adaa0: fdiv            d2, d0, d1
    // 0x8adaa4: r17 = -432
    //     0x8adaa4: mov             x17, #-0x1b0
    // 0x8adaa8: str             d2, [fp, x17]
    // 0x8adaac: r0 = Color()
    //     0x8adaac: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8adab0: r1 = Instance_ColorSpace
    //     0x8adab0: add             x1, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8adab4: ldr             x1, [x1, #0x298]
    // 0x8adab8: StoreField: r0->field_27 = r1
    //     0x8adab8: stur            w1, [x0, #0x27]
    // 0x8adabc: r17 = -432
    //     0x8adabc: mov             x17, #-0x1b0
    // 0x8adac0: ldr             d0, [fp, x17]
    // 0x8adac4: StoreField: r0->field_7 = d0
    //     0x8adac4: stur            d0, [x0, #7]
    // 0x8adac8: ldur            x2, [fp, #-0x30]
    // 0x8adacc: ubfx            x2, x2, #0, #0x20
    // 0x8adad0: and             w3, w2, #0xff
    // 0x8adad4: ubfx            x3, x3, #0, #0x20
    // 0x8adad8: scvtf           d0, x3
    // 0x8adadc: d1 = 255.000000
    //     0x8adadc: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8adae0: fdiv            d2, d0, d1
    // 0x8adae4: StoreField: r0->field_f = d2
    //     0x8adae4: stur            d2, [x0, #0xf]
    // 0x8adae8: ldur            x2, [fp, #-0x28]
    // 0x8adaec: ubfx            x2, x2, #0, #0x20
    // 0x8adaf0: and             w3, w2, #0xff
    // 0x8adaf4: ubfx            x3, x3, #0, #0x20
    // 0x8adaf8: scvtf           d0, x3
    // 0x8adafc: fdiv            d2, d0, d1
    // 0x8adb00: ArrayStore: r0[0] = d2  ; List_8
    //     0x8adb00: stur            d2, [x0, #0x17]
    // 0x8adb04: ldur            x2, [fp, #-0x38]
    // 0x8adb08: ubfx            x2, x2, #0, #0x20
    // 0x8adb0c: and             w3, w2, #0xff
    // 0x8adb10: ubfx            x3, x3, #0, #0x20
    // 0x8adb14: scvtf           d0, x3
    // 0x8adb18: fdiv            d2, d0, d1
    // 0x8adb1c: StoreField: r0->field_1f = d2
    //     0x8adb1c: stur            d2, [x0, #0x1f]
    // 0x8adb20: mov             x2, x0
    // 0x8adb24: b               #0x8adb38
    // 0x8adb28: d1 = 255.000000
    //     0x8adb28: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8adb2c: r1 = Instance_ColorSpace
    //     0x8adb2c: add             x1, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8adb30: ldr             x1, [x1, #0x298]
    // 0x8adb34: mov             x2, x0
    // 0x8adb38: ldur            x0, [fp, #-0x10]
    // 0x8adb3c: stur            x2, [fp, #-8]
    // 0x8adb40: cmp             w0, NULL
    // 0x8adb44: b.ne            #0x8adc28
    // 0x8adb48: r0 = LoadStaticField(0x1164)
    //     0x8adb48: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8adb4c: ldr             x0, [x0, #0x22c8]
    // 0x8adb50: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8adb54: cmp             w0, w16
    // 0x8adb58: b.ne            #0x8adb68
    // 0x8adb5c: r2 = onPrimary
    //     0x8adb5c: add             x2, PP, #0x12, lsl #12  ; [pp+0x12f28] Field <MaterialDynamicColors.onPrimary>: static late final (offset: 0x1164)
    //     0x8adb60: ldr             x2, [x2, #0xf28]
    // 0x8adb64: r0 = InitLateFinalStaticField()
    //     0x8adb64: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8adb68: mov             x1, x0
    // 0x8adb6c: ldur            x2, [fp, #-0x20]
    // 0x8adb70: r0 = getArgb()
    //     0x8adb70: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8adb74: stur            x0, [fp, #-0x38]
    // 0x8adb78: asr             x1, x0, #0x18
    // 0x8adb7c: asr             x2, x0, #0x10
    // 0x8adb80: stur            x2, [fp, #-0x30]
    // 0x8adb84: asr             x3, x0, #8
    // 0x8adb88: stur            x3, [fp, #-0x28]
    // 0x8adb8c: ubfx            x1, x1, #0, #0x20
    // 0x8adb90: and             w4, w1, #0xff
    // 0x8adb94: ubfx            x4, x4, #0, #0x20
    // 0x8adb98: scvtf           d0, x4
    // 0x8adb9c: d1 = 255.000000
    //     0x8adb9c: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8adba0: fdiv            d2, d0, d1
    // 0x8adba4: r17 = -432
    //     0x8adba4: mov             x17, #-0x1b0
    // 0x8adba8: str             d2, [fp, x17]
    // 0x8adbac: r0 = Color()
    //     0x8adbac: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8adbb0: r1 = Instance_ColorSpace
    //     0x8adbb0: add             x1, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8adbb4: ldr             x1, [x1, #0x298]
    // 0x8adbb8: StoreField: r0->field_27 = r1
    //     0x8adbb8: stur            w1, [x0, #0x27]
    // 0x8adbbc: r17 = -432
    //     0x8adbbc: mov             x17, #-0x1b0
    // 0x8adbc0: ldr             d0, [fp, x17]
    // 0x8adbc4: StoreField: r0->field_7 = d0
    //     0x8adbc4: stur            d0, [x0, #7]
    // 0x8adbc8: ldur            x2, [fp, #-0x30]
    // 0x8adbcc: ubfx            x2, x2, #0, #0x20
    // 0x8adbd0: and             w3, w2, #0xff
    // 0x8adbd4: ubfx            x3, x3, #0, #0x20
    // 0x8adbd8: scvtf           d0, x3
    // 0x8adbdc: d1 = 255.000000
    //     0x8adbdc: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8adbe0: fdiv            d2, d0, d1
    // 0x8adbe4: StoreField: r0->field_f = d2
    //     0x8adbe4: stur            d2, [x0, #0xf]
    // 0x8adbe8: ldur            x2, [fp, #-0x28]
    // 0x8adbec: ubfx            x2, x2, #0, #0x20
    // 0x8adbf0: and             w3, w2, #0xff
    // 0x8adbf4: ubfx            x3, x3, #0, #0x20
    // 0x8adbf8: scvtf           d0, x3
    // 0x8adbfc: fdiv            d2, d0, d1
    // 0x8adc00: ArrayStore: r0[0] = d2  ; List_8
    //     0x8adc00: stur            d2, [x0, #0x17]
    // 0x8adc04: ldur            x2, [fp, #-0x38]
    // 0x8adc08: ubfx            x2, x2, #0, #0x20
    // 0x8adc0c: and             w3, w2, #0xff
    // 0x8adc10: ubfx            x3, x3, #0, #0x20
    // 0x8adc14: scvtf           d0, x3
    // 0x8adc18: fdiv            d2, d0, d1
    // 0x8adc1c: StoreField: r0->field_1f = d2
    //     0x8adc1c: stur            d2, [x0, #0x1f]
    // 0x8adc20: mov             x3, x0
    // 0x8adc24: b               #0x8adc2c
    // 0x8adc28: mov             x3, x0
    // 0x8adc2c: ldur            x2, [fp, #-0x18]
    // 0x8adc30: ldur            x0, [fp, #-8]
    // 0x8adc34: stur            x3, [fp, #-0x10]
    // 0x8adc38: r0 = LoadStaticField(0x1168)
    //     0x8adc38: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8adc3c: ldr             x0, [x0, #0x22d0]
    // 0x8adc40: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8adc44: cmp             w0, w16
    // 0x8adc48: b.ne            #0x8adc58
    // 0x8adc4c: r2 = primaryContainer
    //     0x8adc4c: add             x2, PP, #0x12, lsl #12  ; [pp+0x12f30] Field <MaterialDynamicColors.primaryContainer>: static late final (offset: 0x1168)
    //     0x8adc50: ldr             x2, [x2, #0xf30]
    // 0x8adc54: r0 = InitLateFinalStaticField()
    //     0x8adc54: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8adc58: mov             x1, x0
    // 0x8adc5c: ldur            x2, [fp, #-0x20]
    // 0x8adc60: r0 = getArgb()
    //     0x8adc60: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8adc64: stur            x0, [fp, #-0x38]
    // 0x8adc68: asr             x1, x0, #0x18
    // 0x8adc6c: asr             x2, x0, #0x10
    // 0x8adc70: stur            x2, [fp, #-0x30]
    // 0x8adc74: asr             x3, x0, #8
    // 0x8adc78: stur            x3, [fp, #-0x28]
    // 0x8adc7c: ubfx            x1, x1, #0, #0x20
    // 0x8adc80: and             w4, w1, #0xff
    // 0x8adc84: ubfx            x4, x4, #0, #0x20
    // 0x8adc88: scvtf           d0, x4
    // 0x8adc8c: d1 = 255.000000
    //     0x8adc8c: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8adc90: fdiv            d2, d0, d1
    // 0x8adc94: r17 = -432
    //     0x8adc94: mov             x17, #-0x1b0
    // 0x8adc98: str             d2, [fp, x17]
    // 0x8adc9c: r0 = Color()
    //     0x8adc9c: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8adca0: mov             x1, x0
    // 0x8adca4: r0 = Instance_ColorSpace
    //     0x8adca4: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8adca8: ldr             x0, [x0, #0x298]
    // 0x8adcac: stur            x1, [fp, #-0x40]
    // 0x8adcb0: StoreField: r1->field_27 = r0
    //     0x8adcb0: stur            w0, [x1, #0x27]
    // 0x8adcb4: r17 = -432
    //     0x8adcb4: mov             x17, #-0x1b0
    // 0x8adcb8: ldr             d0, [fp, x17]
    // 0x8adcbc: StoreField: r1->field_7 = d0
    //     0x8adcbc: stur            d0, [x1, #7]
    // 0x8adcc0: ldur            x2, [fp, #-0x30]
    // 0x8adcc4: ubfx            x2, x2, #0, #0x20
    // 0x8adcc8: and             w3, w2, #0xff
    // 0x8adccc: ubfx            x3, x3, #0, #0x20
    // 0x8adcd0: scvtf           d0, x3
    // 0x8adcd4: d1 = 255.000000
    //     0x8adcd4: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8adcd8: fdiv            d2, d0, d1
    // 0x8adcdc: StoreField: r1->field_f = d2
    //     0x8adcdc: stur            d2, [x1, #0xf]
    // 0x8adce0: ldur            x2, [fp, #-0x28]
    // 0x8adce4: ubfx            x2, x2, #0, #0x20
    // 0x8adce8: and             w3, w2, #0xff
    // 0x8adcec: ubfx            x3, x3, #0, #0x20
    // 0x8adcf0: scvtf           d0, x3
    // 0x8adcf4: fdiv            d2, d0, d1
    // 0x8adcf8: ArrayStore: r1[0] = d2  ; List_8
    //     0x8adcf8: stur            d2, [x1, #0x17]
    // 0x8adcfc: ldur            x2, [fp, #-0x38]
    // 0x8add00: ubfx            x2, x2, #0, #0x20
    // 0x8add04: and             w3, w2, #0xff
    // 0x8add08: ubfx            x3, x3, #0, #0x20
    // 0x8add0c: scvtf           d0, x3
    // 0x8add10: fdiv            d2, d0, d1
    // 0x8add14: StoreField: r1->field_1f = d2
    //     0x8add14: stur            d2, [x1, #0x1f]
    // 0x8add18: r0 = LoadStaticField(0x116c)
    //     0x8add18: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8add1c: ldr             x0, [x0, #0x22d8]
    // 0x8add20: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8add24: cmp             w0, w16
    // 0x8add28: b.ne            #0x8add38
    // 0x8add2c: r2 = onPrimaryContainer
    //     0x8add2c: add             x2, PP, #0x12, lsl #12  ; [pp+0x12f38] Field <MaterialDynamicColors.onPrimaryContainer>: static late final (offset: 0x116c)
    //     0x8add30: ldr             x2, [x2, #0xf38]
    // 0x8add34: r0 = InitLateFinalStaticField()
    //     0x8add34: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8add38: mov             x1, x0
    // 0x8add3c: ldur            x2, [fp, #-0x20]
    // 0x8add40: r0 = getArgb()
    //     0x8add40: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8add44: stur            x0, [fp, #-0x38]
    // 0x8add48: asr             x1, x0, #0x18
    // 0x8add4c: asr             x2, x0, #0x10
    // 0x8add50: stur            x2, [fp, #-0x30]
    // 0x8add54: asr             x3, x0, #8
    // 0x8add58: stur            x3, [fp, #-0x28]
    // 0x8add5c: ubfx            x1, x1, #0, #0x20
    // 0x8add60: and             w4, w1, #0xff
    // 0x8add64: ubfx            x4, x4, #0, #0x20
    // 0x8add68: scvtf           d0, x4
    // 0x8add6c: d1 = 255.000000
    //     0x8add6c: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8add70: fdiv            d2, d0, d1
    // 0x8add74: r17 = -432
    //     0x8add74: mov             x17, #-0x1b0
    // 0x8add78: str             d2, [fp, x17]
    // 0x8add7c: r0 = Color()
    //     0x8add7c: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8add80: mov             x1, x0
    // 0x8add84: r0 = Instance_ColorSpace
    //     0x8add84: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8add88: ldr             x0, [x0, #0x298]
    // 0x8add8c: stur            x1, [fp, #-0x48]
    // 0x8add90: StoreField: r1->field_27 = r0
    //     0x8add90: stur            w0, [x1, #0x27]
    // 0x8add94: r17 = -432
    //     0x8add94: mov             x17, #-0x1b0
    // 0x8add98: ldr             d0, [fp, x17]
    // 0x8add9c: StoreField: r1->field_7 = d0
    //     0x8add9c: stur            d0, [x1, #7]
    // 0x8adda0: ldur            x2, [fp, #-0x30]
    // 0x8adda4: ubfx            x2, x2, #0, #0x20
    // 0x8adda8: and             w3, w2, #0xff
    // 0x8addac: ubfx            x3, x3, #0, #0x20
    // 0x8addb0: scvtf           d0, x3
    // 0x8addb4: d1 = 255.000000
    //     0x8addb4: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8addb8: fdiv            d2, d0, d1
    // 0x8addbc: StoreField: r1->field_f = d2
    //     0x8addbc: stur            d2, [x1, #0xf]
    // 0x8addc0: ldur            x2, [fp, #-0x28]
    // 0x8addc4: ubfx            x2, x2, #0, #0x20
    // 0x8addc8: and             w3, w2, #0xff
    // 0x8addcc: ubfx            x3, x3, #0, #0x20
    // 0x8addd0: scvtf           d0, x3
    // 0x8addd4: fdiv            d2, d0, d1
    // 0x8addd8: ArrayStore: r1[0] = d2  ; List_8
    //     0x8addd8: stur            d2, [x1, #0x17]
    // 0x8adddc: ldur            x2, [fp, #-0x38]
    // 0x8adde0: ubfx            x2, x2, #0, #0x20
    // 0x8adde4: and             w3, w2, #0xff
    // 0x8adde8: ubfx            x3, x3, #0, #0x20
    // 0x8addec: scvtf           d0, x3
    // 0x8addf0: fdiv            d2, d0, d1
    // 0x8addf4: StoreField: r1->field_1f = d2
    //     0x8addf4: stur            d2, [x1, #0x1f]
    // 0x8addf8: r0 = LoadStaticField(0x11a4)
    //     0x8addf8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8addfc: ldr             x0, [x0, #0x2348]
    // 0x8ade00: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8ade04: cmp             w0, w16
    // 0x8ade08: b.ne            #0x8ade18
    // 0x8ade0c: r2 = primaryFixed
    //     0x8ade0c: add             x2, PP, #0x12, lsl #12  ; [pp+0x12f40] Field <MaterialDynamicColors.primaryFixed>: static late final (offset: 0x11a4)
    //     0x8ade10: ldr             x2, [x2, #0xf40]
    // 0x8ade14: r0 = InitLateFinalStaticField()
    //     0x8ade14: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8ade18: mov             x1, x0
    // 0x8ade1c: ldur            x2, [fp, #-0x20]
    // 0x8ade20: r0 = getArgb()
    //     0x8ade20: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8ade24: stur            x0, [fp, #-0x38]
    // 0x8ade28: asr             x1, x0, #0x18
    // 0x8ade2c: asr             x2, x0, #0x10
    // 0x8ade30: stur            x2, [fp, #-0x30]
    // 0x8ade34: asr             x3, x0, #8
    // 0x8ade38: stur            x3, [fp, #-0x28]
    // 0x8ade3c: ubfx            x1, x1, #0, #0x20
    // 0x8ade40: and             w4, w1, #0xff
    // 0x8ade44: ubfx            x4, x4, #0, #0x20
    // 0x8ade48: scvtf           d0, x4
    // 0x8ade4c: d1 = 255.000000
    //     0x8ade4c: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8ade50: fdiv            d2, d0, d1
    // 0x8ade54: r17 = -432
    //     0x8ade54: mov             x17, #-0x1b0
    // 0x8ade58: str             d2, [fp, x17]
    // 0x8ade5c: r0 = Color()
    //     0x8ade5c: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8ade60: mov             x1, x0
    // 0x8ade64: r0 = Instance_ColorSpace
    //     0x8ade64: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8ade68: ldr             x0, [x0, #0x298]
    // 0x8ade6c: stur            x1, [fp, #-0x50]
    // 0x8ade70: StoreField: r1->field_27 = r0
    //     0x8ade70: stur            w0, [x1, #0x27]
    // 0x8ade74: r17 = -432
    //     0x8ade74: mov             x17, #-0x1b0
    // 0x8ade78: ldr             d0, [fp, x17]
    // 0x8ade7c: StoreField: r1->field_7 = d0
    //     0x8ade7c: stur            d0, [x1, #7]
    // 0x8ade80: ldur            x2, [fp, #-0x30]
    // 0x8ade84: ubfx            x2, x2, #0, #0x20
    // 0x8ade88: and             w3, w2, #0xff
    // 0x8ade8c: ubfx            x3, x3, #0, #0x20
    // 0x8ade90: scvtf           d0, x3
    // 0x8ade94: d1 = 255.000000
    //     0x8ade94: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8ade98: fdiv            d2, d0, d1
    // 0x8ade9c: StoreField: r1->field_f = d2
    //     0x8ade9c: stur            d2, [x1, #0xf]
    // 0x8adea0: ldur            x2, [fp, #-0x28]
    // 0x8adea4: ubfx            x2, x2, #0, #0x20
    // 0x8adea8: and             w3, w2, #0xff
    // 0x8adeac: ubfx            x3, x3, #0, #0x20
    // 0x8adeb0: scvtf           d0, x3
    // 0x8adeb4: fdiv            d2, d0, d1
    // 0x8adeb8: ArrayStore: r1[0] = d2  ; List_8
    //     0x8adeb8: stur            d2, [x1, #0x17]
    // 0x8adebc: ldur            x2, [fp, #-0x38]
    // 0x8adec0: ubfx            x2, x2, #0, #0x20
    // 0x8adec4: and             w3, w2, #0xff
    // 0x8adec8: ubfx            x3, x3, #0, #0x20
    // 0x8adecc: scvtf           d0, x3
    // 0x8aded0: fdiv            d2, d0, d1
    // 0x8aded4: StoreField: r1->field_1f = d2
    //     0x8aded4: stur            d2, [x1, #0x1f]
    // 0x8aded8: r0 = LoadStaticField(0x11a8)
    //     0x8aded8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8adedc: ldr             x0, [x0, #0x2350]
    // 0x8adee0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8adee4: cmp             w0, w16
    // 0x8adee8: b.ne            #0x8adef8
    // 0x8adeec: r2 = primaryFixedDim
    //     0x8adeec: add             x2, PP, #0x12, lsl #12  ; [pp+0x12f48] Field <MaterialDynamicColors.primaryFixedDim>: static late final (offset: 0x11a8)
    //     0x8adef0: ldr             x2, [x2, #0xf48]
    // 0x8adef4: r0 = InitLateFinalStaticField()
    //     0x8adef4: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8adef8: mov             x1, x0
    // 0x8adefc: ldur            x2, [fp, #-0x20]
    // 0x8adf00: r0 = getArgb()
    //     0x8adf00: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8adf04: stur            x0, [fp, #-0x38]
    // 0x8adf08: asr             x1, x0, #0x18
    // 0x8adf0c: asr             x2, x0, #0x10
    // 0x8adf10: stur            x2, [fp, #-0x30]
    // 0x8adf14: asr             x3, x0, #8
    // 0x8adf18: stur            x3, [fp, #-0x28]
    // 0x8adf1c: ubfx            x1, x1, #0, #0x20
    // 0x8adf20: and             w4, w1, #0xff
    // 0x8adf24: ubfx            x4, x4, #0, #0x20
    // 0x8adf28: scvtf           d0, x4
    // 0x8adf2c: d1 = 255.000000
    //     0x8adf2c: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8adf30: fdiv            d2, d0, d1
    // 0x8adf34: r17 = -432
    //     0x8adf34: mov             x17, #-0x1b0
    // 0x8adf38: str             d2, [fp, x17]
    // 0x8adf3c: r0 = Color()
    //     0x8adf3c: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8adf40: mov             x1, x0
    // 0x8adf44: r0 = Instance_ColorSpace
    //     0x8adf44: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8adf48: ldr             x0, [x0, #0x298]
    // 0x8adf4c: stur            x1, [fp, #-0x58]
    // 0x8adf50: StoreField: r1->field_27 = r0
    //     0x8adf50: stur            w0, [x1, #0x27]
    // 0x8adf54: r17 = -432
    //     0x8adf54: mov             x17, #-0x1b0
    // 0x8adf58: ldr             d0, [fp, x17]
    // 0x8adf5c: StoreField: r1->field_7 = d0
    //     0x8adf5c: stur            d0, [x1, #7]
    // 0x8adf60: ldur            x2, [fp, #-0x30]
    // 0x8adf64: ubfx            x2, x2, #0, #0x20
    // 0x8adf68: and             w3, w2, #0xff
    // 0x8adf6c: ubfx            x3, x3, #0, #0x20
    // 0x8adf70: scvtf           d0, x3
    // 0x8adf74: d1 = 255.000000
    //     0x8adf74: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8adf78: fdiv            d2, d0, d1
    // 0x8adf7c: StoreField: r1->field_f = d2
    //     0x8adf7c: stur            d2, [x1, #0xf]
    // 0x8adf80: ldur            x2, [fp, #-0x28]
    // 0x8adf84: ubfx            x2, x2, #0, #0x20
    // 0x8adf88: and             w3, w2, #0xff
    // 0x8adf8c: ubfx            x3, x3, #0, #0x20
    // 0x8adf90: scvtf           d0, x3
    // 0x8adf94: fdiv            d2, d0, d1
    // 0x8adf98: ArrayStore: r1[0] = d2  ; List_8
    //     0x8adf98: stur            d2, [x1, #0x17]
    // 0x8adf9c: ldur            x2, [fp, #-0x38]
    // 0x8adfa0: ubfx            x2, x2, #0, #0x20
    // 0x8adfa4: and             w3, w2, #0xff
    // 0x8adfa8: ubfx            x3, x3, #0, #0x20
    // 0x8adfac: scvtf           d0, x3
    // 0x8adfb0: fdiv            d2, d0, d1
    // 0x8adfb4: StoreField: r1->field_1f = d2
    //     0x8adfb4: stur            d2, [x1, #0x1f]
    // 0x8adfb8: r0 = LoadStaticField(0x11ac)
    //     0x8adfb8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8adfbc: ldr             x0, [x0, #0x2358]
    // 0x8adfc0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8adfc4: cmp             w0, w16
    // 0x8adfc8: b.ne            #0x8adfd8
    // 0x8adfcc: r2 = onPrimaryFixed
    //     0x8adfcc: add             x2, PP, #0x12, lsl #12  ; [pp+0x12f50] Field <MaterialDynamicColors.onPrimaryFixed>: static late final (offset: 0x11ac)
    //     0x8adfd0: ldr             x2, [x2, #0xf50]
    // 0x8adfd4: r0 = InitLateFinalStaticField()
    //     0x8adfd4: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8adfd8: mov             x1, x0
    // 0x8adfdc: ldur            x2, [fp, #-0x20]
    // 0x8adfe0: r0 = getArgb()
    //     0x8adfe0: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8adfe4: stur            x0, [fp, #-0x38]
    // 0x8adfe8: asr             x1, x0, #0x18
    // 0x8adfec: asr             x2, x0, #0x10
    // 0x8adff0: stur            x2, [fp, #-0x30]
    // 0x8adff4: asr             x3, x0, #8
    // 0x8adff8: stur            x3, [fp, #-0x28]
    // 0x8adffc: ubfx            x1, x1, #0, #0x20
    // 0x8ae000: and             w4, w1, #0xff
    // 0x8ae004: ubfx            x4, x4, #0, #0x20
    // 0x8ae008: scvtf           d0, x4
    // 0x8ae00c: d1 = 255.000000
    //     0x8ae00c: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8ae010: fdiv            d2, d0, d1
    // 0x8ae014: r17 = -432
    //     0x8ae014: mov             x17, #-0x1b0
    // 0x8ae018: str             d2, [fp, x17]
    // 0x8ae01c: r0 = Color()
    //     0x8ae01c: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8ae020: mov             x1, x0
    // 0x8ae024: r0 = Instance_ColorSpace
    //     0x8ae024: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8ae028: ldr             x0, [x0, #0x298]
    // 0x8ae02c: stur            x1, [fp, #-0x60]
    // 0x8ae030: StoreField: r1->field_27 = r0
    //     0x8ae030: stur            w0, [x1, #0x27]
    // 0x8ae034: r17 = -432
    //     0x8ae034: mov             x17, #-0x1b0
    // 0x8ae038: ldr             d0, [fp, x17]
    // 0x8ae03c: StoreField: r1->field_7 = d0
    //     0x8ae03c: stur            d0, [x1, #7]
    // 0x8ae040: ldur            x2, [fp, #-0x30]
    // 0x8ae044: ubfx            x2, x2, #0, #0x20
    // 0x8ae048: and             w3, w2, #0xff
    // 0x8ae04c: ubfx            x3, x3, #0, #0x20
    // 0x8ae050: scvtf           d0, x3
    // 0x8ae054: d1 = 255.000000
    //     0x8ae054: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8ae058: fdiv            d2, d0, d1
    // 0x8ae05c: StoreField: r1->field_f = d2
    //     0x8ae05c: stur            d2, [x1, #0xf]
    // 0x8ae060: ldur            x2, [fp, #-0x28]
    // 0x8ae064: ubfx            x2, x2, #0, #0x20
    // 0x8ae068: and             w3, w2, #0xff
    // 0x8ae06c: ubfx            x3, x3, #0, #0x20
    // 0x8ae070: scvtf           d0, x3
    // 0x8ae074: fdiv            d2, d0, d1
    // 0x8ae078: ArrayStore: r1[0] = d2  ; List_8
    //     0x8ae078: stur            d2, [x1, #0x17]
    // 0x8ae07c: ldur            x2, [fp, #-0x38]
    // 0x8ae080: ubfx            x2, x2, #0, #0x20
    // 0x8ae084: and             w3, w2, #0xff
    // 0x8ae088: ubfx            x3, x3, #0, #0x20
    // 0x8ae08c: scvtf           d0, x3
    // 0x8ae090: fdiv            d2, d0, d1
    // 0x8ae094: StoreField: r1->field_1f = d2
    //     0x8ae094: stur            d2, [x1, #0x1f]
    // 0x8ae098: r0 = LoadStaticField(0x11b0)
    //     0x8ae098: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8ae09c: ldr             x0, [x0, #0x2360]
    // 0x8ae0a0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8ae0a4: cmp             w0, w16
    // 0x8ae0a8: b.ne            #0x8ae0b8
    // 0x8ae0ac: r2 = onPrimaryFixedVariant
    //     0x8ae0ac: add             x2, PP, #0x12, lsl #12  ; [pp+0x12f58] Field <MaterialDynamicColors.onPrimaryFixedVariant>: static late final (offset: 0x11b0)
    //     0x8ae0b0: ldr             x2, [x2, #0xf58]
    // 0x8ae0b4: r0 = InitLateFinalStaticField()
    //     0x8ae0b4: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8ae0b8: mov             x1, x0
    // 0x8ae0bc: ldur            x2, [fp, #-0x20]
    // 0x8ae0c0: r0 = getArgb()
    //     0x8ae0c0: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8ae0c4: stur            x0, [fp, #-0x38]
    // 0x8ae0c8: asr             x1, x0, #0x18
    // 0x8ae0cc: asr             x2, x0, #0x10
    // 0x8ae0d0: stur            x2, [fp, #-0x30]
    // 0x8ae0d4: asr             x3, x0, #8
    // 0x8ae0d8: stur            x3, [fp, #-0x28]
    // 0x8ae0dc: ubfx            x1, x1, #0, #0x20
    // 0x8ae0e0: and             w4, w1, #0xff
    // 0x8ae0e4: ubfx            x4, x4, #0, #0x20
    // 0x8ae0e8: scvtf           d0, x4
    // 0x8ae0ec: d1 = 255.000000
    //     0x8ae0ec: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8ae0f0: fdiv            d2, d0, d1
    // 0x8ae0f4: r17 = -432
    //     0x8ae0f4: mov             x17, #-0x1b0
    // 0x8ae0f8: str             d2, [fp, x17]
    // 0x8ae0fc: r0 = Color()
    //     0x8ae0fc: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8ae100: mov             x1, x0
    // 0x8ae104: r0 = Instance_ColorSpace
    //     0x8ae104: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8ae108: ldr             x0, [x0, #0x298]
    // 0x8ae10c: stur            x1, [fp, #-0x68]
    // 0x8ae110: StoreField: r1->field_27 = r0
    //     0x8ae110: stur            w0, [x1, #0x27]
    // 0x8ae114: r17 = -432
    //     0x8ae114: mov             x17, #-0x1b0
    // 0x8ae118: ldr             d0, [fp, x17]
    // 0x8ae11c: StoreField: r1->field_7 = d0
    //     0x8ae11c: stur            d0, [x1, #7]
    // 0x8ae120: ldur            x2, [fp, #-0x30]
    // 0x8ae124: ubfx            x2, x2, #0, #0x20
    // 0x8ae128: and             w3, w2, #0xff
    // 0x8ae12c: ubfx            x3, x3, #0, #0x20
    // 0x8ae130: scvtf           d0, x3
    // 0x8ae134: d1 = 255.000000
    //     0x8ae134: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8ae138: fdiv            d2, d0, d1
    // 0x8ae13c: StoreField: r1->field_f = d2
    //     0x8ae13c: stur            d2, [x1, #0xf]
    // 0x8ae140: ldur            x2, [fp, #-0x28]
    // 0x8ae144: ubfx            x2, x2, #0, #0x20
    // 0x8ae148: and             w3, w2, #0xff
    // 0x8ae14c: ubfx            x3, x3, #0, #0x20
    // 0x8ae150: scvtf           d0, x3
    // 0x8ae154: fdiv            d2, d0, d1
    // 0x8ae158: ArrayStore: r1[0] = d2  ; List_8
    //     0x8ae158: stur            d2, [x1, #0x17]
    // 0x8ae15c: ldur            x2, [fp, #-0x38]
    // 0x8ae160: ubfx            x2, x2, #0, #0x20
    // 0x8ae164: and             w3, w2, #0xff
    // 0x8ae168: ubfx            x3, x3, #0, #0x20
    // 0x8ae16c: scvtf           d0, x3
    // 0x8ae170: fdiv            d2, d0, d1
    // 0x8ae174: StoreField: r1->field_1f = d2
    //     0x8ae174: stur            d2, [x1, #0x1f]
    // 0x8ae178: r0 = LoadStaticField(0x1174)
    //     0x8ae178: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8ae17c: ldr             x0, [x0, #0x22e8]
    // 0x8ae180: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8ae184: cmp             w0, w16
    // 0x8ae188: b.ne            #0x8ae198
    // 0x8ae18c: r2 = secondary
    //     0x8ae18c: add             x2, PP, #0x12, lsl #12  ; [pp+0x12f60] Field <MaterialDynamicColors.secondary>: static late final (offset: 0x1174)
    //     0x8ae190: ldr             x2, [x2, #0xf60]
    // 0x8ae194: r0 = InitLateFinalStaticField()
    //     0x8ae194: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8ae198: mov             x1, x0
    // 0x8ae19c: ldur            x2, [fp, #-0x20]
    // 0x8ae1a0: r0 = getArgb()
    //     0x8ae1a0: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8ae1a4: stur            x0, [fp, #-0x38]
    // 0x8ae1a8: asr             x1, x0, #0x18
    // 0x8ae1ac: asr             x2, x0, #0x10
    // 0x8ae1b0: stur            x2, [fp, #-0x30]
    // 0x8ae1b4: asr             x3, x0, #8
    // 0x8ae1b8: stur            x3, [fp, #-0x28]
    // 0x8ae1bc: ubfx            x1, x1, #0, #0x20
    // 0x8ae1c0: and             w4, w1, #0xff
    // 0x8ae1c4: ubfx            x4, x4, #0, #0x20
    // 0x8ae1c8: scvtf           d0, x4
    // 0x8ae1cc: d1 = 255.000000
    //     0x8ae1cc: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8ae1d0: fdiv            d2, d0, d1
    // 0x8ae1d4: r17 = -432
    //     0x8ae1d4: mov             x17, #-0x1b0
    // 0x8ae1d8: str             d2, [fp, x17]
    // 0x8ae1dc: r0 = Color()
    //     0x8ae1dc: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8ae1e0: mov             x1, x0
    // 0x8ae1e4: r0 = Instance_ColorSpace
    //     0x8ae1e4: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8ae1e8: ldr             x0, [x0, #0x298]
    // 0x8ae1ec: stur            x1, [fp, #-0x70]
    // 0x8ae1f0: StoreField: r1->field_27 = r0
    //     0x8ae1f0: stur            w0, [x1, #0x27]
    // 0x8ae1f4: r17 = -432
    //     0x8ae1f4: mov             x17, #-0x1b0
    // 0x8ae1f8: ldr             d0, [fp, x17]
    // 0x8ae1fc: StoreField: r1->field_7 = d0
    //     0x8ae1fc: stur            d0, [x1, #7]
    // 0x8ae200: ldur            x2, [fp, #-0x30]
    // 0x8ae204: ubfx            x2, x2, #0, #0x20
    // 0x8ae208: and             w3, w2, #0xff
    // 0x8ae20c: ubfx            x3, x3, #0, #0x20
    // 0x8ae210: scvtf           d0, x3
    // 0x8ae214: d1 = 255.000000
    //     0x8ae214: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8ae218: fdiv            d2, d0, d1
    // 0x8ae21c: StoreField: r1->field_f = d2
    //     0x8ae21c: stur            d2, [x1, #0xf]
    // 0x8ae220: ldur            x2, [fp, #-0x28]
    // 0x8ae224: ubfx            x2, x2, #0, #0x20
    // 0x8ae228: and             w3, w2, #0xff
    // 0x8ae22c: ubfx            x3, x3, #0, #0x20
    // 0x8ae230: scvtf           d0, x3
    // 0x8ae234: fdiv            d2, d0, d1
    // 0x8ae238: ArrayStore: r1[0] = d2  ; List_8
    //     0x8ae238: stur            d2, [x1, #0x17]
    // 0x8ae23c: ldur            x2, [fp, #-0x38]
    // 0x8ae240: ubfx            x2, x2, #0, #0x20
    // 0x8ae244: and             w3, w2, #0xff
    // 0x8ae248: ubfx            x3, x3, #0, #0x20
    // 0x8ae24c: scvtf           d0, x3
    // 0x8ae250: fdiv            d2, d0, d1
    // 0x8ae254: StoreField: r1->field_1f = d2
    //     0x8ae254: stur            d2, [x1, #0x1f]
    // 0x8ae258: r0 = LoadStaticField(0x1178)
    //     0x8ae258: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8ae25c: ldr             x0, [x0, #0x22f0]
    // 0x8ae260: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8ae264: cmp             w0, w16
    // 0x8ae268: b.ne            #0x8ae278
    // 0x8ae26c: r2 = onSecondary
    //     0x8ae26c: add             x2, PP, #0x12, lsl #12  ; [pp+0x12f68] Field <MaterialDynamicColors.onSecondary>: static late final (offset: 0x1178)
    //     0x8ae270: ldr             x2, [x2, #0xf68]
    // 0x8ae274: r0 = InitLateFinalStaticField()
    //     0x8ae274: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8ae278: mov             x1, x0
    // 0x8ae27c: ldur            x2, [fp, #-0x20]
    // 0x8ae280: r0 = getArgb()
    //     0x8ae280: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8ae284: stur            x0, [fp, #-0x38]
    // 0x8ae288: asr             x1, x0, #0x18
    // 0x8ae28c: asr             x2, x0, #0x10
    // 0x8ae290: stur            x2, [fp, #-0x30]
    // 0x8ae294: asr             x3, x0, #8
    // 0x8ae298: stur            x3, [fp, #-0x28]
    // 0x8ae29c: ubfx            x1, x1, #0, #0x20
    // 0x8ae2a0: and             w4, w1, #0xff
    // 0x8ae2a4: ubfx            x4, x4, #0, #0x20
    // 0x8ae2a8: scvtf           d0, x4
    // 0x8ae2ac: d1 = 255.000000
    //     0x8ae2ac: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8ae2b0: fdiv            d2, d0, d1
    // 0x8ae2b4: r17 = -432
    //     0x8ae2b4: mov             x17, #-0x1b0
    // 0x8ae2b8: str             d2, [fp, x17]
    // 0x8ae2bc: r0 = Color()
    //     0x8ae2bc: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8ae2c0: mov             x1, x0
    // 0x8ae2c4: r0 = Instance_ColorSpace
    //     0x8ae2c4: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8ae2c8: ldr             x0, [x0, #0x298]
    // 0x8ae2cc: stur            x1, [fp, #-0x78]
    // 0x8ae2d0: StoreField: r1->field_27 = r0
    //     0x8ae2d0: stur            w0, [x1, #0x27]
    // 0x8ae2d4: r17 = -432
    //     0x8ae2d4: mov             x17, #-0x1b0
    // 0x8ae2d8: ldr             d0, [fp, x17]
    // 0x8ae2dc: StoreField: r1->field_7 = d0
    //     0x8ae2dc: stur            d0, [x1, #7]
    // 0x8ae2e0: ldur            x2, [fp, #-0x30]
    // 0x8ae2e4: ubfx            x2, x2, #0, #0x20
    // 0x8ae2e8: and             w3, w2, #0xff
    // 0x8ae2ec: ubfx            x3, x3, #0, #0x20
    // 0x8ae2f0: scvtf           d0, x3
    // 0x8ae2f4: d1 = 255.000000
    //     0x8ae2f4: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8ae2f8: fdiv            d2, d0, d1
    // 0x8ae2fc: StoreField: r1->field_f = d2
    //     0x8ae2fc: stur            d2, [x1, #0xf]
    // 0x8ae300: ldur            x2, [fp, #-0x28]
    // 0x8ae304: ubfx            x2, x2, #0, #0x20
    // 0x8ae308: and             w3, w2, #0xff
    // 0x8ae30c: ubfx            x3, x3, #0, #0x20
    // 0x8ae310: scvtf           d0, x3
    // 0x8ae314: fdiv            d2, d0, d1
    // 0x8ae318: ArrayStore: r1[0] = d2  ; List_8
    //     0x8ae318: stur            d2, [x1, #0x17]
    // 0x8ae31c: ldur            x2, [fp, #-0x38]
    // 0x8ae320: ubfx            x2, x2, #0, #0x20
    // 0x8ae324: and             w3, w2, #0xff
    // 0x8ae328: ubfx            x3, x3, #0, #0x20
    // 0x8ae32c: scvtf           d0, x3
    // 0x8ae330: fdiv            d2, d0, d1
    // 0x8ae334: StoreField: r1->field_1f = d2
    //     0x8ae334: stur            d2, [x1, #0x1f]
    // 0x8ae338: r0 = LoadStaticField(0x117c)
    //     0x8ae338: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8ae33c: ldr             x0, [x0, #0x22f8]
    // 0x8ae340: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8ae344: cmp             w0, w16
    // 0x8ae348: b.ne            #0x8ae358
    // 0x8ae34c: r2 = secondaryContainer
    //     0x8ae34c: add             x2, PP, #0x12, lsl #12  ; [pp+0x12f70] Field <MaterialDynamicColors.secondaryContainer>: static late final (offset: 0x117c)
    //     0x8ae350: ldr             x2, [x2, #0xf70]
    // 0x8ae354: r0 = InitLateFinalStaticField()
    //     0x8ae354: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8ae358: mov             x1, x0
    // 0x8ae35c: ldur            x2, [fp, #-0x20]
    // 0x8ae360: r0 = getArgb()
    //     0x8ae360: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8ae364: stur            x0, [fp, #-0x38]
    // 0x8ae368: asr             x1, x0, #0x18
    // 0x8ae36c: asr             x2, x0, #0x10
    // 0x8ae370: stur            x2, [fp, #-0x30]
    // 0x8ae374: asr             x3, x0, #8
    // 0x8ae378: stur            x3, [fp, #-0x28]
    // 0x8ae37c: ubfx            x1, x1, #0, #0x20
    // 0x8ae380: and             w4, w1, #0xff
    // 0x8ae384: ubfx            x4, x4, #0, #0x20
    // 0x8ae388: scvtf           d0, x4
    // 0x8ae38c: d1 = 255.000000
    //     0x8ae38c: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8ae390: fdiv            d2, d0, d1
    // 0x8ae394: r17 = -432
    //     0x8ae394: mov             x17, #-0x1b0
    // 0x8ae398: str             d2, [fp, x17]
    // 0x8ae39c: r0 = Color()
    //     0x8ae39c: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8ae3a0: mov             x1, x0
    // 0x8ae3a4: r0 = Instance_ColorSpace
    //     0x8ae3a4: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8ae3a8: ldr             x0, [x0, #0x298]
    // 0x8ae3ac: stur            x1, [fp, #-0x80]
    // 0x8ae3b0: StoreField: r1->field_27 = r0
    //     0x8ae3b0: stur            w0, [x1, #0x27]
    // 0x8ae3b4: r17 = -432
    //     0x8ae3b4: mov             x17, #-0x1b0
    // 0x8ae3b8: ldr             d0, [fp, x17]
    // 0x8ae3bc: StoreField: r1->field_7 = d0
    //     0x8ae3bc: stur            d0, [x1, #7]
    // 0x8ae3c0: ldur            x2, [fp, #-0x30]
    // 0x8ae3c4: ubfx            x2, x2, #0, #0x20
    // 0x8ae3c8: and             w3, w2, #0xff
    // 0x8ae3cc: ubfx            x3, x3, #0, #0x20
    // 0x8ae3d0: scvtf           d0, x3
    // 0x8ae3d4: d1 = 255.000000
    //     0x8ae3d4: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8ae3d8: fdiv            d2, d0, d1
    // 0x8ae3dc: StoreField: r1->field_f = d2
    //     0x8ae3dc: stur            d2, [x1, #0xf]
    // 0x8ae3e0: ldur            x2, [fp, #-0x28]
    // 0x8ae3e4: ubfx            x2, x2, #0, #0x20
    // 0x8ae3e8: and             w3, w2, #0xff
    // 0x8ae3ec: ubfx            x3, x3, #0, #0x20
    // 0x8ae3f0: scvtf           d0, x3
    // 0x8ae3f4: fdiv            d2, d0, d1
    // 0x8ae3f8: ArrayStore: r1[0] = d2  ; List_8
    //     0x8ae3f8: stur            d2, [x1, #0x17]
    // 0x8ae3fc: ldur            x2, [fp, #-0x38]
    // 0x8ae400: ubfx            x2, x2, #0, #0x20
    // 0x8ae404: and             w3, w2, #0xff
    // 0x8ae408: ubfx            x3, x3, #0, #0x20
    // 0x8ae40c: scvtf           d0, x3
    // 0x8ae410: fdiv            d2, d0, d1
    // 0x8ae414: StoreField: r1->field_1f = d2
    //     0x8ae414: stur            d2, [x1, #0x1f]
    // 0x8ae418: r0 = LoadStaticField(0x1180)
    //     0x8ae418: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8ae41c: ldr             x0, [x0, #0x2300]
    // 0x8ae420: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8ae424: cmp             w0, w16
    // 0x8ae428: b.ne            #0x8ae438
    // 0x8ae42c: r2 = onSecondaryContainer
    //     0x8ae42c: add             x2, PP, #0x12, lsl #12  ; [pp+0x12f78] Field <MaterialDynamicColors.onSecondaryContainer>: static late final (offset: 0x1180)
    //     0x8ae430: ldr             x2, [x2, #0xf78]
    // 0x8ae434: r0 = InitLateFinalStaticField()
    //     0x8ae434: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8ae438: mov             x1, x0
    // 0x8ae43c: ldur            x2, [fp, #-0x20]
    // 0x8ae440: r0 = getArgb()
    //     0x8ae440: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8ae444: stur            x0, [fp, #-0x38]
    // 0x8ae448: asr             x1, x0, #0x18
    // 0x8ae44c: asr             x2, x0, #0x10
    // 0x8ae450: stur            x2, [fp, #-0x30]
    // 0x8ae454: asr             x3, x0, #8
    // 0x8ae458: stur            x3, [fp, #-0x28]
    // 0x8ae45c: ubfx            x1, x1, #0, #0x20
    // 0x8ae460: and             w4, w1, #0xff
    // 0x8ae464: ubfx            x4, x4, #0, #0x20
    // 0x8ae468: scvtf           d0, x4
    // 0x8ae46c: d1 = 255.000000
    //     0x8ae46c: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8ae470: fdiv            d2, d0, d1
    // 0x8ae474: r17 = -432
    //     0x8ae474: mov             x17, #-0x1b0
    // 0x8ae478: str             d2, [fp, x17]
    // 0x8ae47c: r0 = Color()
    //     0x8ae47c: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8ae480: mov             x1, x0
    // 0x8ae484: r0 = Instance_ColorSpace
    //     0x8ae484: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8ae488: ldr             x0, [x0, #0x298]
    // 0x8ae48c: stur            x1, [fp, #-0x88]
    // 0x8ae490: StoreField: r1->field_27 = r0
    //     0x8ae490: stur            w0, [x1, #0x27]
    // 0x8ae494: r17 = -432
    //     0x8ae494: mov             x17, #-0x1b0
    // 0x8ae498: ldr             d0, [fp, x17]
    // 0x8ae49c: StoreField: r1->field_7 = d0
    //     0x8ae49c: stur            d0, [x1, #7]
    // 0x8ae4a0: ldur            x2, [fp, #-0x30]
    // 0x8ae4a4: ubfx            x2, x2, #0, #0x20
    // 0x8ae4a8: and             w3, w2, #0xff
    // 0x8ae4ac: ubfx            x3, x3, #0, #0x20
    // 0x8ae4b0: scvtf           d0, x3
    // 0x8ae4b4: d1 = 255.000000
    //     0x8ae4b4: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8ae4b8: fdiv            d2, d0, d1
    // 0x8ae4bc: StoreField: r1->field_f = d2
    //     0x8ae4bc: stur            d2, [x1, #0xf]
    // 0x8ae4c0: ldur            x2, [fp, #-0x28]
    // 0x8ae4c4: ubfx            x2, x2, #0, #0x20
    // 0x8ae4c8: and             w3, w2, #0xff
    // 0x8ae4cc: ubfx            x3, x3, #0, #0x20
    // 0x8ae4d0: scvtf           d0, x3
    // 0x8ae4d4: fdiv            d2, d0, d1
    // 0x8ae4d8: ArrayStore: r1[0] = d2  ; List_8
    //     0x8ae4d8: stur            d2, [x1, #0x17]
    // 0x8ae4dc: ldur            x2, [fp, #-0x38]
    // 0x8ae4e0: ubfx            x2, x2, #0, #0x20
    // 0x8ae4e4: and             w3, w2, #0xff
    // 0x8ae4e8: ubfx            x3, x3, #0, #0x20
    // 0x8ae4ec: scvtf           d0, x3
    // 0x8ae4f0: fdiv            d2, d0, d1
    // 0x8ae4f4: StoreField: r1->field_1f = d2
    //     0x8ae4f4: stur            d2, [x1, #0x1f]
    // 0x8ae4f8: r0 = LoadStaticField(0x11b4)
    //     0x8ae4f8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8ae4fc: ldr             x0, [x0, #0x2368]
    // 0x8ae500: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8ae504: cmp             w0, w16
    // 0x8ae508: b.ne            #0x8ae518
    // 0x8ae50c: r2 = secondaryFixed
    //     0x8ae50c: add             x2, PP, #0x12, lsl #12  ; [pp+0x12f80] Field <MaterialDynamicColors.secondaryFixed>: static late final (offset: 0x11b4)
    //     0x8ae510: ldr             x2, [x2, #0xf80]
    // 0x8ae514: r0 = InitLateFinalStaticField()
    //     0x8ae514: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8ae518: mov             x1, x0
    // 0x8ae51c: ldur            x2, [fp, #-0x20]
    // 0x8ae520: r0 = getArgb()
    //     0x8ae520: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8ae524: stur            x0, [fp, #-0x38]
    // 0x8ae528: asr             x1, x0, #0x18
    // 0x8ae52c: asr             x2, x0, #0x10
    // 0x8ae530: stur            x2, [fp, #-0x30]
    // 0x8ae534: asr             x3, x0, #8
    // 0x8ae538: stur            x3, [fp, #-0x28]
    // 0x8ae53c: ubfx            x1, x1, #0, #0x20
    // 0x8ae540: and             w4, w1, #0xff
    // 0x8ae544: ubfx            x4, x4, #0, #0x20
    // 0x8ae548: scvtf           d0, x4
    // 0x8ae54c: d1 = 255.000000
    //     0x8ae54c: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8ae550: fdiv            d2, d0, d1
    // 0x8ae554: r17 = -432
    //     0x8ae554: mov             x17, #-0x1b0
    // 0x8ae558: str             d2, [fp, x17]
    // 0x8ae55c: r0 = Color()
    //     0x8ae55c: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8ae560: mov             x1, x0
    // 0x8ae564: r0 = Instance_ColorSpace
    //     0x8ae564: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8ae568: ldr             x0, [x0, #0x298]
    // 0x8ae56c: stur            x1, [fp, #-0x90]
    // 0x8ae570: StoreField: r1->field_27 = r0
    //     0x8ae570: stur            w0, [x1, #0x27]
    // 0x8ae574: r17 = -432
    //     0x8ae574: mov             x17, #-0x1b0
    // 0x8ae578: ldr             d0, [fp, x17]
    // 0x8ae57c: StoreField: r1->field_7 = d0
    //     0x8ae57c: stur            d0, [x1, #7]
    // 0x8ae580: ldur            x2, [fp, #-0x30]
    // 0x8ae584: ubfx            x2, x2, #0, #0x20
    // 0x8ae588: and             w3, w2, #0xff
    // 0x8ae58c: ubfx            x3, x3, #0, #0x20
    // 0x8ae590: scvtf           d0, x3
    // 0x8ae594: d1 = 255.000000
    //     0x8ae594: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8ae598: fdiv            d2, d0, d1
    // 0x8ae59c: StoreField: r1->field_f = d2
    //     0x8ae59c: stur            d2, [x1, #0xf]
    // 0x8ae5a0: ldur            x2, [fp, #-0x28]
    // 0x8ae5a4: ubfx            x2, x2, #0, #0x20
    // 0x8ae5a8: and             w3, w2, #0xff
    // 0x8ae5ac: ubfx            x3, x3, #0, #0x20
    // 0x8ae5b0: scvtf           d0, x3
    // 0x8ae5b4: fdiv            d2, d0, d1
    // 0x8ae5b8: ArrayStore: r1[0] = d2  ; List_8
    //     0x8ae5b8: stur            d2, [x1, #0x17]
    // 0x8ae5bc: ldur            x2, [fp, #-0x38]
    // 0x8ae5c0: ubfx            x2, x2, #0, #0x20
    // 0x8ae5c4: and             w3, w2, #0xff
    // 0x8ae5c8: ubfx            x3, x3, #0, #0x20
    // 0x8ae5cc: scvtf           d0, x3
    // 0x8ae5d0: fdiv            d2, d0, d1
    // 0x8ae5d4: StoreField: r1->field_1f = d2
    //     0x8ae5d4: stur            d2, [x1, #0x1f]
    // 0x8ae5d8: r0 = LoadStaticField(0x11b8)
    //     0x8ae5d8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8ae5dc: ldr             x0, [x0, #0x2370]
    // 0x8ae5e0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8ae5e4: cmp             w0, w16
    // 0x8ae5e8: b.ne            #0x8ae5f8
    // 0x8ae5ec: r2 = secondaryFixedDim
    //     0x8ae5ec: add             x2, PP, #0x12, lsl #12  ; [pp+0x12f88] Field <MaterialDynamicColors.secondaryFixedDim>: static late final (offset: 0x11b8)
    //     0x8ae5f0: ldr             x2, [x2, #0xf88]
    // 0x8ae5f4: r0 = InitLateFinalStaticField()
    //     0x8ae5f4: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8ae5f8: mov             x1, x0
    // 0x8ae5fc: ldur            x2, [fp, #-0x20]
    // 0x8ae600: r0 = getArgb()
    //     0x8ae600: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8ae604: stur            x0, [fp, #-0x38]
    // 0x8ae608: asr             x1, x0, #0x18
    // 0x8ae60c: asr             x2, x0, #0x10
    // 0x8ae610: stur            x2, [fp, #-0x30]
    // 0x8ae614: asr             x3, x0, #8
    // 0x8ae618: stur            x3, [fp, #-0x28]
    // 0x8ae61c: ubfx            x1, x1, #0, #0x20
    // 0x8ae620: and             w4, w1, #0xff
    // 0x8ae624: ubfx            x4, x4, #0, #0x20
    // 0x8ae628: scvtf           d0, x4
    // 0x8ae62c: d1 = 255.000000
    //     0x8ae62c: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8ae630: fdiv            d2, d0, d1
    // 0x8ae634: r17 = -432
    //     0x8ae634: mov             x17, #-0x1b0
    // 0x8ae638: str             d2, [fp, x17]
    // 0x8ae63c: r0 = Color()
    //     0x8ae63c: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8ae640: mov             x1, x0
    // 0x8ae644: r0 = Instance_ColorSpace
    //     0x8ae644: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8ae648: ldr             x0, [x0, #0x298]
    // 0x8ae64c: stur            x1, [fp, #-0x98]
    // 0x8ae650: StoreField: r1->field_27 = r0
    //     0x8ae650: stur            w0, [x1, #0x27]
    // 0x8ae654: r17 = -432
    //     0x8ae654: mov             x17, #-0x1b0
    // 0x8ae658: ldr             d0, [fp, x17]
    // 0x8ae65c: StoreField: r1->field_7 = d0
    //     0x8ae65c: stur            d0, [x1, #7]
    // 0x8ae660: ldur            x2, [fp, #-0x30]
    // 0x8ae664: ubfx            x2, x2, #0, #0x20
    // 0x8ae668: and             w3, w2, #0xff
    // 0x8ae66c: ubfx            x3, x3, #0, #0x20
    // 0x8ae670: scvtf           d0, x3
    // 0x8ae674: d1 = 255.000000
    //     0x8ae674: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8ae678: fdiv            d2, d0, d1
    // 0x8ae67c: StoreField: r1->field_f = d2
    //     0x8ae67c: stur            d2, [x1, #0xf]
    // 0x8ae680: ldur            x2, [fp, #-0x28]
    // 0x8ae684: ubfx            x2, x2, #0, #0x20
    // 0x8ae688: and             w3, w2, #0xff
    // 0x8ae68c: ubfx            x3, x3, #0, #0x20
    // 0x8ae690: scvtf           d0, x3
    // 0x8ae694: fdiv            d2, d0, d1
    // 0x8ae698: ArrayStore: r1[0] = d2  ; List_8
    //     0x8ae698: stur            d2, [x1, #0x17]
    // 0x8ae69c: ldur            x2, [fp, #-0x38]
    // 0x8ae6a0: ubfx            x2, x2, #0, #0x20
    // 0x8ae6a4: and             w3, w2, #0xff
    // 0x8ae6a8: ubfx            x3, x3, #0, #0x20
    // 0x8ae6ac: scvtf           d0, x3
    // 0x8ae6b0: fdiv            d2, d0, d1
    // 0x8ae6b4: StoreField: r1->field_1f = d2
    //     0x8ae6b4: stur            d2, [x1, #0x1f]
    // 0x8ae6b8: r0 = LoadStaticField(0x11bc)
    //     0x8ae6b8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8ae6bc: ldr             x0, [x0, #0x2378]
    // 0x8ae6c0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8ae6c4: cmp             w0, w16
    // 0x8ae6c8: b.ne            #0x8ae6d8
    // 0x8ae6cc: r2 = onSecondaryFixed
    //     0x8ae6cc: add             x2, PP, #0x12, lsl #12  ; [pp+0x12f90] Field <MaterialDynamicColors.onSecondaryFixed>: static late final (offset: 0x11bc)
    //     0x8ae6d0: ldr             x2, [x2, #0xf90]
    // 0x8ae6d4: r0 = InitLateFinalStaticField()
    //     0x8ae6d4: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8ae6d8: mov             x1, x0
    // 0x8ae6dc: ldur            x2, [fp, #-0x20]
    // 0x8ae6e0: r0 = getArgb()
    //     0x8ae6e0: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8ae6e4: stur            x0, [fp, #-0x38]
    // 0x8ae6e8: asr             x1, x0, #0x18
    // 0x8ae6ec: asr             x2, x0, #0x10
    // 0x8ae6f0: stur            x2, [fp, #-0x30]
    // 0x8ae6f4: asr             x3, x0, #8
    // 0x8ae6f8: stur            x3, [fp, #-0x28]
    // 0x8ae6fc: ubfx            x1, x1, #0, #0x20
    // 0x8ae700: and             w4, w1, #0xff
    // 0x8ae704: ubfx            x4, x4, #0, #0x20
    // 0x8ae708: scvtf           d0, x4
    // 0x8ae70c: d1 = 255.000000
    //     0x8ae70c: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8ae710: fdiv            d2, d0, d1
    // 0x8ae714: r17 = -432
    //     0x8ae714: mov             x17, #-0x1b0
    // 0x8ae718: str             d2, [fp, x17]
    // 0x8ae71c: r0 = Color()
    //     0x8ae71c: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8ae720: mov             x1, x0
    // 0x8ae724: r0 = Instance_ColorSpace
    //     0x8ae724: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8ae728: ldr             x0, [x0, #0x298]
    // 0x8ae72c: stur            x1, [fp, #-0xa0]
    // 0x8ae730: StoreField: r1->field_27 = r0
    //     0x8ae730: stur            w0, [x1, #0x27]
    // 0x8ae734: r17 = -432
    //     0x8ae734: mov             x17, #-0x1b0
    // 0x8ae738: ldr             d0, [fp, x17]
    // 0x8ae73c: StoreField: r1->field_7 = d0
    //     0x8ae73c: stur            d0, [x1, #7]
    // 0x8ae740: ldur            x2, [fp, #-0x30]
    // 0x8ae744: ubfx            x2, x2, #0, #0x20
    // 0x8ae748: and             w3, w2, #0xff
    // 0x8ae74c: ubfx            x3, x3, #0, #0x20
    // 0x8ae750: scvtf           d0, x3
    // 0x8ae754: d1 = 255.000000
    //     0x8ae754: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8ae758: fdiv            d2, d0, d1
    // 0x8ae75c: StoreField: r1->field_f = d2
    //     0x8ae75c: stur            d2, [x1, #0xf]
    // 0x8ae760: ldur            x2, [fp, #-0x28]
    // 0x8ae764: ubfx            x2, x2, #0, #0x20
    // 0x8ae768: and             w3, w2, #0xff
    // 0x8ae76c: ubfx            x3, x3, #0, #0x20
    // 0x8ae770: scvtf           d0, x3
    // 0x8ae774: fdiv            d2, d0, d1
    // 0x8ae778: ArrayStore: r1[0] = d2  ; List_8
    //     0x8ae778: stur            d2, [x1, #0x17]
    // 0x8ae77c: ldur            x2, [fp, #-0x38]
    // 0x8ae780: ubfx            x2, x2, #0, #0x20
    // 0x8ae784: and             w3, w2, #0xff
    // 0x8ae788: ubfx            x3, x3, #0, #0x20
    // 0x8ae78c: scvtf           d0, x3
    // 0x8ae790: fdiv            d2, d0, d1
    // 0x8ae794: StoreField: r1->field_1f = d2
    //     0x8ae794: stur            d2, [x1, #0x1f]
    // 0x8ae798: r0 = LoadStaticField(0x11c0)
    //     0x8ae798: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8ae79c: ldr             x0, [x0, #0x2380]
    // 0x8ae7a0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8ae7a4: cmp             w0, w16
    // 0x8ae7a8: b.ne            #0x8ae7b8
    // 0x8ae7ac: r2 = onSecondaryFixedVariant
    //     0x8ae7ac: add             x2, PP, #0x12, lsl #12  ; [pp+0x12f98] Field <MaterialDynamicColors.onSecondaryFixedVariant>: static late final (offset: 0x11c0)
    //     0x8ae7b0: ldr             x2, [x2, #0xf98]
    // 0x8ae7b4: r0 = InitLateFinalStaticField()
    //     0x8ae7b4: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8ae7b8: mov             x1, x0
    // 0x8ae7bc: ldur            x2, [fp, #-0x20]
    // 0x8ae7c0: r0 = getArgb()
    //     0x8ae7c0: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8ae7c4: stur            x0, [fp, #-0x38]
    // 0x8ae7c8: asr             x1, x0, #0x18
    // 0x8ae7cc: asr             x2, x0, #0x10
    // 0x8ae7d0: stur            x2, [fp, #-0x30]
    // 0x8ae7d4: asr             x3, x0, #8
    // 0x8ae7d8: stur            x3, [fp, #-0x28]
    // 0x8ae7dc: ubfx            x1, x1, #0, #0x20
    // 0x8ae7e0: and             w4, w1, #0xff
    // 0x8ae7e4: ubfx            x4, x4, #0, #0x20
    // 0x8ae7e8: scvtf           d0, x4
    // 0x8ae7ec: d1 = 255.000000
    //     0x8ae7ec: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8ae7f0: fdiv            d2, d0, d1
    // 0x8ae7f4: r17 = -432
    //     0x8ae7f4: mov             x17, #-0x1b0
    // 0x8ae7f8: str             d2, [fp, x17]
    // 0x8ae7fc: r0 = Color()
    //     0x8ae7fc: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8ae800: mov             x1, x0
    // 0x8ae804: r0 = Instance_ColorSpace
    //     0x8ae804: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8ae808: ldr             x0, [x0, #0x298]
    // 0x8ae80c: stur            x1, [fp, #-0xa8]
    // 0x8ae810: StoreField: r1->field_27 = r0
    //     0x8ae810: stur            w0, [x1, #0x27]
    // 0x8ae814: r17 = -432
    //     0x8ae814: mov             x17, #-0x1b0
    // 0x8ae818: ldr             d0, [fp, x17]
    // 0x8ae81c: StoreField: r1->field_7 = d0
    //     0x8ae81c: stur            d0, [x1, #7]
    // 0x8ae820: ldur            x2, [fp, #-0x30]
    // 0x8ae824: ubfx            x2, x2, #0, #0x20
    // 0x8ae828: and             w3, w2, #0xff
    // 0x8ae82c: ubfx            x3, x3, #0, #0x20
    // 0x8ae830: scvtf           d0, x3
    // 0x8ae834: d1 = 255.000000
    //     0x8ae834: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8ae838: fdiv            d2, d0, d1
    // 0x8ae83c: StoreField: r1->field_f = d2
    //     0x8ae83c: stur            d2, [x1, #0xf]
    // 0x8ae840: ldur            x2, [fp, #-0x28]
    // 0x8ae844: ubfx            x2, x2, #0, #0x20
    // 0x8ae848: and             w3, w2, #0xff
    // 0x8ae84c: ubfx            x3, x3, #0, #0x20
    // 0x8ae850: scvtf           d0, x3
    // 0x8ae854: fdiv            d2, d0, d1
    // 0x8ae858: ArrayStore: r1[0] = d2  ; List_8
    //     0x8ae858: stur            d2, [x1, #0x17]
    // 0x8ae85c: ldur            x2, [fp, #-0x38]
    // 0x8ae860: ubfx            x2, x2, #0, #0x20
    // 0x8ae864: and             w3, w2, #0xff
    // 0x8ae868: ubfx            x3, x3, #0, #0x20
    // 0x8ae86c: scvtf           d0, x3
    // 0x8ae870: fdiv            d2, d0, d1
    // 0x8ae874: StoreField: r1->field_1f = d2
    //     0x8ae874: stur            d2, [x1, #0x1f]
    // 0x8ae878: r0 = LoadStaticField(0x1184)
    //     0x8ae878: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8ae87c: ldr             x0, [x0, #0x2308]
    // 0x8ae880: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8ae884: cmp             w0, w16
    // 0x8ae888: b.ne            #0x8ae898
    // 0x8ae88c: r2 = tertiary
    //     0x8ae88c: add             x2, PP, #0x12, lsl #12  ; [pp+0x12fa0] Field <MaterialDynamicColors.tertiary>: static late final (offset: 0x1184)
    //     0x8ae890: ldr             x2, [x2, #0xfa0]
    // 0x8ae894: r0 = InitLateFinalStaticField()
    //     0x8ae894: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8ae898: mov             x1, x0
    // 0x8ae89c: ldur            x2, [fp, #-0x20]
    // 0x8ae8a0: r0 = getArgb()
    //     0x8ae8a0: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8ae8a4: stur            x0, [fp, #-0x38]
    // 0x8ae8a8: asr             x1, x0, #0x18
    // 0x8ae8ac: asr             x2, x0, #0x10
    // 0x8ae8b0: stur            x2, [fp, #-0x30]
    // 0x8ae8b4: asr             x3, x0, #8
    // 0x8ae8b8: stur            x3, [fp, #-0x28]
    // 0x8ae8bc: ubfx            x1, x1, #0, #0x20
    // 0x8ae8c0: and             w4, w1, #0xff
    // 0x8ae8c4: ubfx            x4, x4, #0, #0x20
    // 0x8ae8c8: scvtf           d0, x4
    // 0x8ae8cc: d1 = 255.000000
    //     0x8ae8cc: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8ae8d0: fdiv            d2, d0, d1
    // 0x8ae8d4: r17 = -432
    //     0x8ae8d4: mov             x17, #-0x1b0
    // 0x8ae8d8: str             d2, [fp, x17]
    // 0x8ae8dc: r0 = Color()
    //     0x8ae8dc: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8ae8e0: mov             x1, x0
    // 0x8ae8e4: r0 = Instance_ColorSpace
    //     0x8ae8e4: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8ae8e8: ldr             x0, [x0, #0x298]
    // 0x8ae8ec: stur            x1, [fp, #-0xb0]
    // 0x8ae8f0: StoreField: r1->field_27 = r0
    //     0x8ae8f0: stur            w0, [x1, #0x27]
    // 0x8ae8f4: r17 = -432
    //     0x8ae8f4: mov             x17, #-0x1b0
    // 0x8ae8f8: ldr             d0, [fp, x17]
    // 0x8ae8fc: StoreField: r1->field_7 = d0
    //     0x8ae8fc: stur            d0, [x1, #7]
    // 0x8ae900: ldur            x2, [fp, #-0x30]
    // 0x8ae904: ubfx            x2, x2, #0, #0x20
    // 0x8ae908: and             w3, w2, #0xff
    // 0x8ae90c: ubfx            x3, x3, #0, #0x20
    // 0x8ae910: scvtf           d0, x3
    // 0x8ae914: d1 = 255.000000
    //     0x8ae914: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8ae918: fdiv            d2, d0, d1
    // 0x8ae91c: StoreField: r1->field_f = d2
    //     0x8ae91c: stur            d2, [x1, #0xf]
    // 0x8ae920: ldur            x2, [fp, #-0x28]
    // 0x8ae924: ubfx            x2, x2, #0, #0x20
    // 0x8ae928: and             w3, w2, #0xff
    // 0x8ae92c: ubfx            x3, x3, #0, #0x20
    // 0x8ae930: scvtf           d0, x3
    // 0x8ae934: fdiv            d2, d0, d1
    // 0x8ae938: ArrayStore: r1[0] = d2  ; List_8
    //     0x8ae938: stur            d2, [x1, #0x17]
    // 0x8ae93c: ldur            x2, [fp, #-0x38]
    // 0x8ae940: ubfx            x2, x2, #0, #0x20
    // 0x8ae944: and             w3, w2, #0xff
    // 0x8ae948: ubfx            x3, x3, #0, #0x20
    // 0x8ae94c: scvtf           d0, x3
    // 0x8ae950: fdiv            d2, d0, d1
    // 0x8ae954: StoreField: r1->field_1f = d2
    //     0x8ae954: stur            d2, [x1, #0x1f]
    // 0x8ae958: r0 = LoadStaticField(0x1188)
    //     0x8ae958: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8ae95c: ldr             x0, [x0, #0x2310]
    // 0x8ae960: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8ae964: cmp             w0, w16
    // 0x8ae968: b.ne            #0x8ae978
    // 0x8ae96c: r2 = onTertiary
    //     0x8ae96c: add             x2, PP, #0x12, lsl #12  ; [pp+0x12fa8] Field <MaterialDynamicColors.onTertiary>: static late final (offset: 0x1188)
    //     0x8ae970: ldr             x2, [x2, #0xfa8]
    // 0x8ae974: r0 = InitLateFinalStaticField()
    //     0x8ae974: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8ae978: mov             x1, x0
    // 0x8ae97c: ldur            x2, [fp, #-0x20]
    // 0x8ae980: r0 = getArgb()
    //     0x8ae980: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8ae984: stur            x0, [fp, #-0x38]
    // 0x8ae988: asr             x1, x0, #0x18
    // 0x8ae98c: asr             x2, x0, #0x10
    // 0x8ae990: stur            x2, [fp, #-0x30]
    // 0x8ae994: asr             x3, x0, #8
    // 0x8ae998: stur            x3, [fp, #-0x28]
    // 0x8ae99c: ubfx            x1, x1, #0, #0x20
    // 0x8ae9a0: and             w4, w1, #0xff
    // 0x8ae9a4: ubfx            x4, x4, #0, #0x20
    // 0x8ae9a8: scvtf           d0, x4
    // 0x8ae9ac: d1 = 255.000000
    //     0x8ae9ac: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8ae9b0: fdiv            d2, d0, d1
    // 0x8ae9b4: r17 = -432
    //     0x8ae9b4: mov             x17, #-0x1b0
    // 0x8ae9b8: str             d2, [fp, x17]
    // 0x8ae9bc: r0 = Color()
    //     0x8ae9bc: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8ae9c0: mov             x1, x0
    // 0x8ae9c4: r0 = Instance_ColorSpace
    //     0x8ae9c4: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8ae9c8: ldr             x0, [x0, #0x298]
    // 0x8ae9cc: stur            x1, [fp, #-0xb8]
    // 0x8ae9d0: StoreField: r1->field_27 = r0
    //     0x8ae9d0: stur            w0, [x1, #0x27]
    // 0x8ae9d4: r17 = -432
    //     0x8ae9d4: mov             x17, #-0x1b0
    // 0x8ae9d8: ldr             d0, [fp, x17]
    // 0x8ae9dc: StoreField: r1->field_7 = d0
    //     0x8ae9dc: stur            d0, [x1, #7]
    // 0x8ae9e0: ldur            x2, [fp, #-0x30]
    // 0x8ae9e4: ubfx            x2, x2, #0, #0x20
    // 0x8ae9e8: and             w3, w2, #0xff
    // 0x8ae9ec: ubfx            x3, x3, #0, #0x20
    // 0x8ae9f0: scvtf           d0, x3
    // 0x8ae9f4: d1 = 255.000000
    //     0x8ae9f4: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8ae9f8: fdiv            d2, d0, d1
    // 0x8ae9fc: StoreField: r1->field_f = d2
    //     0x8ae9fc: stur            d2, [x1, #0xf]
    // 0x8aea00: ldur            x2, [fp, #-0x28]
    // 0x8aea04: ubfx            x2, x2, #0, #0x20
    // 0x8aea08: and             w3, w2, #0xff
    // 0x8aea0c: ubfx            x3, x3, #0, #0x20
    // 0x8aea10: scvtf           d0, x3
    // 0x8aea14: fdiv            d2, d0, d1
    // 0x8aea18: ArrayStore: r1[0] = d2  ; List_8
    //     0x8aea18: stur            d2, [x1, #0x17]
    // 0x8aea1c: ldur            x2, [fp, #-0x38]
    // 0x8aea20: ubfx            x2, x2, #0, #0x20
    // 0x8aea24: and             w3, w2, #0xff
    // 0x8aea28: ubfx            x3, x3, #0, #0x20
    // 0x8aea2c: scvtf           d0, x3
    // 0x8aea30: fdiv            d2, d0, d1
    // 0x8aea34: StoreField: r1->field_1f = d2
    //     0x8aea34: stur            d2, [x1, #0x1f]
    // 0x8aea38: r0 = LoadStaticField(0x118c)
    //     0x8aea38: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8aea3c: ldr             x0, [x0, #0x2318]
    // 0x8aea40: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8aea44: cmp             w0, w16
    // 0x8aea48: b.ne            #0x8aea58
    // 0x8aea4c: r2 = tertiaryContainer
    //     0x8aea4c: add             x2, PP, #0x12, lsl #12  ; [pp+0x12fb0] Field <MaterialDynamicColors.tertiaryContainer>: static late final (offset: 0x118c)
    //     0x8aea50: ldr             x2, [x2, #0xfb0]
    // 0x8aea54: r0 = InitLateFinalStaticField()
    //     0x8aea54: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8aea58: mov             x1, x0
    // 0x8aea5c: ldur            x2, [fp, #-0x20]
    // 0x8aea60: r0 = getArgb()
    //     0x8aea60: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8aea64: stur            x0, [fp, #-0x38]
    // 0x8aea68: asr             x1, x0, #0x18
    // 0x8aea6c: asr             x2, x0, #0x10
    // 0x8aea70: stur            x2, [fp, #-0x30]
    // 0x8aea74: asr             x3, x0, #8
    // 0x8aea78: stur            x3, [fp, #-0x28]
    // 0x8aea7c: ubfx            x1, x1, #0, #0x20
    // 0x8aea80: and             w4, w1, #0xff
    // 0x8aea84: ubfx            x4, x4, #0, #0x20
    // 0x8aea88: scvtf           d0, x4
    // 0x8aea8c: d1 = 255.000000
    //     0x8aea8c: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8aea90: fdiv            d2, d0, d1
    // 0x8aea94: r17 = -432
    //     0x8aea94: mov             x17, #-0x1b0
    // 0x8aea98: str             d2, [fp, x17]
    // 0x8aea9c: r0 = Color()
    //     0x8aea9c: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8aeaa0: mov             x1, x0
    // 0x8aeaa4: r0 = Instance_ColorSpace
    //     0x8aeaa4: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8aeaa8: ldr             x0, [x0, #0x298]
    // 0x8aeaac: stur            x1, [fp, #-0xc0]
    // 0x8aeab0: StoreField: r1->field_27 = r0
    //     0x8aeab0: stur            w0, [x1, #0x27]
    // 0x8aeab4: r17 = -432
    //     0x8aeab4: mov             x17, #-0x1b0
    // 0x8aeab8: ldr             d0, [fp, x17]
    // 0x8aeabc: StoreField: r1->field_7 = d0
    //     0x8aeabc: stur            d0, [x1, #7]
    // 0x8aeac0: ldur            x2, [fp, #-0x30]
    // 0x8aeac4: ubfx            x2, x2, #0, #0x20
    // 0x8aeac8: and             w3, w2, #0xff
    // 0x8aeacc: ubfx            x3, x3, #0, #0x20
    // 0x8aead0: scvtf           d0, x3
    // 0x8aead4: d1 = 255.000000
    //     0x8aead4: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8aead8: fdiv            d2, d0, d1
    // 0x8aeadc: StoreField: r1->field_f = d2
    //     0x8aeadc: stur            d2, [x1, #0xf]
    // 0x8aeae0: ldur            x2, [fp, #-0x28]
    // 0x8aeae4: ubfx            x2, x2, #0, #0x20
    // 0x8aeae8: and             w3, w2, #0xff
    // 0x8aeaec: ubfx            x3, x3, #0, #0x20
    // 0x8aeaf0: scvtf           d0, x3
    // 0x8aeaf4: fdiv            d2, d0, d1
    // 0x8aeaf8: ArrayStore: r1[0] = d2  ; List_8
    //     0x8aeaf8: stur            d2, [x1, #0x17]
    // 0x8aeafc: ldur            x2, [fp, #-0x38]
    // 0x8aeb00: ubfx            x2, x2, #0, #0x20
    // 0x8aeb04: and             w3, w2, #0xff
    // 0x8aeb08: ubfx            x3, x3, #0, #0x20
    // 0x8aeb0c: scvtf           d0, x3
    // 0x8aeb10: fdiv            d2, d0, d1
    // 0x8aeb14: StoreField: r1->field_1f = d2
    //     0x8aeb14: stur            d2, [x1, #0x1f]
    // 0x8aeb18: r0 = LoadStaticField(0x1190)
    //     0x8aeb18: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8aeb1c: ldr             x0, [x0, #0x2320]
    // 0x8aeb20: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8aeb24: cmp             w0, w16
    // 0x8aeb28: b.ne            #0x8aeb38
    // 0x8aeb2c: r2 = onTertiaryContainer
    //     0x8aeb2c: add             x2, PP, #0x12, lsl #12  ; [pp+0x12fb8] Field <MaterialDynamicColors.onTertiaryContainer>: static late final (offset: 0x1190)
    //     0x8aeb30: ldr             x2, [x2, #0xfb8]
    // 0x8aeb34: r0 = InitLateFinalStaticField()
    //     0x8aeb34: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8aeb38: mov             x1, x0
    // 0x8aeb3c: ldur            x2, [fp, #-0x20]
    // 0x8aeb40: r0 = getArgb()
    //     0x8aeb40: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8aeb44: stur            x0, [fp, #-0x38]
    // 0x8aeb48: asr             x1, x0, #0x18
    // 0x8aeb4c: asr             x2, x0, #0x10
    // 0x8aeb50: stur            x2, [fp, #-0x30]
    // 0x8aeb54: asr             x3, x0, #8
    // 0x8aeb58: stur            x3, [fp, #-0x28]
    // 0x8aeb5c: ubfx            x1, x1, #0, #0x20
    // 0x8aeb60: and             w4, w1, #0xff
    // 0x8aeb64: ubfx            x4, x4, #0, #0x20
    // 0x8aeb68: scvtf           d0, x4
    // 0x8aeb6c: d1 = 255.000000
    //     0x8aeb6c: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8aeb70: fdiv            d2, d0, d1
    // 0x8aeb74: r17 = -432
    //     0x8aeb74: mov             x17, #-0x1b0
    // 0x8aeb78: str             d2, [fp, x17]
    // 0x8aeb7c: r0 = Color()
    //     0x8aeb7c: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8aeb80: mov             x1, x0
    // 0x8aeb84: r0 = Instance_ColorSpace
    //     0x8aeb84: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8aeb88: ldr             x0, [x0, #0x298]
    // 0x8aeb8c: stur            x1, [fp, #-0xc8]
    // 0x8aeb90: StoreField: r1->field_27 = r0
    //     0x8aeb90: stur            w0, [x1, #0x27]
    // 0x8aeb94: r17 = -432
    //     0x8aeb94: mov             x17, #-0x1b0
    // 0x8aeb98: ldr             d0, [fp, x17]
    // 0x8aeb9c: StoreField: r1->field_7 = d0
    //     0x8aeb9c: stur            d0, [x1, #7]
    // 0x8aeba0: ldur            x2, [fp, #-0x30]
    // 0x8aeba4: ubfx            x2, x2, #0, #0x20
    // 0x8aeba8: and             w3, w2, #0xff
    // 0x8aebac: ubfx            x3, x3, #0, #0x20
    // 0x8aebb0: scvtf           d0, x3
    // 0x8aebb4: d1 = 255.000000
    //     0x8aebb4: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8aebb8: fdiv            d2, d0, d1
    // 0x8aebbc: StoreField: r1->field_f = d2
    //     0x8aebbc: stur            d2, [x1, #0xf]
    // 0x8aebc0: ldur            x2, [fp, #-0x28]
    // 0x8aebc4: ubfx            x2, x2, #0, #0x20
    // 0x8aebc8: and             w3, w2, #0xff
    // 0x8aebcc: ubfx            x3, x3, #0, #0x20
    // 0x8aebd0: scvtf           d0, x3
    // 0x8aebd4: fdiv            d2, d0, d1
    // 0x8aebd8: ArrayStore: r1[0] = d2  ; List_8
    //     0x8aebd8: stur            d2, [x1, #0x17]
    // 0x8aebdc: ldur            x2, [fp, #-0x38]
    // 0x8aebe0: ubfx            x2, x2, #0, #0x20
    // 0x8aebe4: and             w3, w2, #0xff
    // 0x8aebe8: ubfx            x3, x3, #0, #0x20
    // 0x8aebec: scvtf           d0, x3
    // 0x8aebf0: fdiv            d2, d0, d1
    // 0x8aebf4: StoreField: r1->field_1f = d2
    //     0x8aebf4: stur            d2, [x1, #0x1f]
    // 0x8aebf8: r0 = LoadStaticField(0x11c4)
    //     0x8aebf8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8aebfc: ldr             x0, [x0, #0x2388]
    // 0x8aec00: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8aec04: cmp             w0, w16
    // 0x8aec08: b.ne            #0x8aec18
    // 0x8aec0c: r2 = tertiaryFixed
    //     0x8aec0c: add             x2, PP, #0x12, lsl #12  ; [pp+0x12fc0] Field <MaterialDynamicColors.tertiaryFixed>: static late final (offset: 0x11c4)
    //     0x8aec10: ldr             x2, [x2, #0xfc0]
    // 0x8aec14: r0 = InitLateFinalStaticField()
    //     0x8aec14: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8aec18: mov             x1, x0
    // 0x8aec1c: ldur            x2, [fp, #-0x20]
    // 0x8aec20: r0 = getArgb()
    //     0x8aec20: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8aec24: stur            x0, [fp, #-0x38]
    // 0x8aec28: asr             x1, x0, #0x18
    // 0x8aec2c: asr             x2, x0, #0x10
    // 0x8aec30: stur            x2, [fp, #-0x30]
    // 0x8aec34: asr             x3, x0, #8
    // 0x8aec38: stur            x3, [fp, #-0x28]
    // 0x8aec3c: ubfx            x1, x1, #0, #0x20
    // 0x8aec40: and             w4, w1, #0xff
    // 0x8aec44: ubfx            x4, x4, #0, #0x20
    // 0x8aec48: scvtf           d0, x4
    // 0x8aec4c: d1 = 255.000000
    //     0x8aec4c: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8aec50: fdiv            d2, d0, d1
    // 0x8aec54: r17 = -432
    //     0x8aec54: mov             x17, #-0x1b0
    // 0x8aec58: str             d2, [fp, x17]
    // 0x8aec5c: r0 = Color()
    //     0x8aec5c: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8aec60: mov             x1, x0
    // 0x8aec64: r0 = Instance_ColorSpace
    //     0x8aec64: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8aec68: ldr             x0, [x0, #0x298]
    // 0x8aec6c: stur            x1, [fp, #-0xd0]
    // 0x8aec70: StoreField: r1->field_27 = r0
    //     0x8aec70: stur            w0, [x1, #0x27]
    // 0x8aec74: r17 = -432
    //     0x8aec74: mov             x17, #-0x1b0
    // 0x8aec78: ldr             d0, [fp, x17]
    // 0x8aec7c: StoreField: r1->field_7 = d0
    //     0x8aec7c: stur            d0, [x1, #7]
    // 0x8aec80: ldur            x2, [fp, #-0x30]
    // 0x8aec84: ubfx            x2, x2, #0, #0x20
    // 0x8aec88: and             w3, w2, #0xff
    // 0x8aec8c: ubfx            x3, x3, #0, #0x20
    // 0x8aec90: scvtf           d0, x3
    // 0x8aec94: d1 = 255.000000
    //     0x8aec94: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8aec98: fdiv            d2, d0, d1
    // 0x8aec9c: StoreField: r1->field_f = d2
    //     0x8aec9c: stur            d2, [x1, #0xf]
    // 0x8aeca0: ldur            x2, [fp, #-0x28]
    // 0x8aeca4: ubfx            x2, x2, #0, #0x20
    // 0x8aeca8: and             w3, w2, #0xff
    // 0x8aecac: ubfx            x3, x3, #0, #0x20
    // 0x8aecb0: scvtf           d0, x3
    // 0x8aecb4: fdiv            d2, d0, d1
    // 0x8aecb8: ArrayStore: r1[0] = d2  ; List_8
    //     0x8aecb8: stur            d2, [x1, #0x17]
    // 0x8aecbc: ldur            x2, [fp, #-0x38]
    // 0x8aecc0: ubfx            x2, x2, #0, #0x20
    // 0x8aecc4: and             w3, w2, #0xff
    // 0x8aecc8: ubfx            x3, x3, #0, #0x20
    // 0x8aeccc: scvtf           d0, x3
    // 0x8aecd0: fdiv            d2, d0, d1
    // 0x8aecd4: StoreField: r1->field_1f = d2
    //     0x8aecd4: stur            d2, [x1, #0x1f]
    // 0x8aecd8: r0 = LoadStaticField(0x11c8)
    //     0x8aecd8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8aecdc: ldr             x0, [x0, #0x2390]
    // 0x8aece0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8aece4: cmp             w0, w16
    // 0x8aece8: b.ne            #0x8aecf8
    // 0x8aecec: r2 = tertiaryFixedDim
    //     0x8aecec: add             x2, PP, #0x12, lsl #12  ; [pp+0x12fc8] Field <MaterialDynamicColors.tertiaryFixedDim>: static late final (offset: 0x11c8)
    //     0x8aecf0: ldr             x2, [x2, #0xfc8]
    // 0x8aecf4: r0 = InitLateFinalStaticField()
    //     0x8aecf4: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8aecf8: mov             x1, x0
    // 0x8aecfc: ldur            x2, [fp, #-0x20]
    // 0x8aed00: r0 = getArgb()
    //     0x8aed00: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8aed04: stur            x0, [fp, #-0x38]
    // 0x8aed08: asr             x1, x0, #0x18
    // 0x8aed0c: asr             x2, x0, #0x10
    // 0x8aed10: stur            x2, [fp, #-0x30]
    // 0x8aed14: asr             x3, x0, #8
    // 0x8aed18: stur            x3, [fp, #-0x28]
    // 0x8aed1c: ubfx            x1, x1, #0, #0x20
    // 0x8aed20: and             w4, w1, #0xff
    // 0x8aed24: ubfx            x4, x4, #0, #0x20
    // 0x8aed28: scvtf           d0, x4
    // 0x8aed2c: d1 = 255.000000
    //     0x8aed2c: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8aed30: fdiv            d2, d0, d1
    // 0x8aed34: r17 = -432
    //     0x8aed34: mov             x17, #-0x1b0
    // 0x8aed38: str             d2, [fp, x17]
    // 0x8aed3c: r0 = Color()
    //     0x8aed3c: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8aed40: mov             x1, x0
    // 0x8aed44: r0 = Instance_ColorSpace
    //     0x8aed44: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8aed48: ldr             x0, [x0, #0x298]
    // 0x8aed4c: stur            x1, [fp, #-0xd8]
    // 0x8aed50: StoreField: r1->field_27 = r0
    //     0x8aed50: stur            w0, [x1, #0x27]
    // 0x8aed54: r17 = -432
    //     0x8aed54: mov             x17, #-0x1b0
    // 0x8aed58: ldr             d0, [fp, x17]
    // 0x8aed5c: StoreField: r1->field_7 = d0
    //     0x8aed5c: stur            d0, [x1, #7]
    // 0x8aed60: ldur            x2, [fp, #-0x30]
    // 0x8aed64: ubfx            x2, x2, #0, #0x20
    // 0x8aed68: and             w3, w2, #0xff
    // 0x8aed6c: ubfx            x3, x3, #0, #0x20
    // 0x8aed70: scvtf           d0, x3
    // 0x8aed74: d1 = 255.000000
    //     0x8aed74: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8aed78: fdiv            d2, d0, d1
    // 0x8aed7c: StoreField: r1->field_f = d2
    //     0x8aed7c: stur            d2, [x1, #0xf]
    // 0x8aed80: ldur            x2, [fp, #-0x28]
    // 0x8aed84: ubfx            x2, x2, #0, #0x20
    // 0x8aed88: and             w3, w2, #0xff
    // 0x8aed8c: ubfx            x3, x3, #0, #0x20
    // 0x8aed90: scvtf           d0, x3
    // 0x8aed94: fdiv            d2, d0, d1
    // 0x8aed98: ArrayStore: r1[0] = d2  ; List_8
    //     0x8aed98: stur            d2, [x1, #0x17]
    // 0x8aed9c: ldur            x2, [fp, #-0x38]
    // 0x8aeda0: ubfx            x2, x2, #0, #0x20
    // 0x8aeda4: and             w3, w2, #0xff
    // 0x8aeda8: ubfx            x3, x3, #0, #0x20
    // 0x8aedac: scvtf           d0, x3
    // 0x8aedb0: fdiv            d2, d0, d1
    // 0x8aedb4: StoreField: r1->field_1f = d2
    //     0x8aedb4: stur            d2, [x1, #0x1f]
    // 0x8aedb8: r0 = LoadStaticField(0x11cc)
    //     0x8aedb8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8aedbc: ldr             x0, [x0, #0x2398]
    // 0x8aedc0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8aedc4: cmp             w0, w16
    // 0x8aedc8: b.ne            #0x8aedd8
    // 0x8aedcc: r2 = onTertiaryFixed
    //     0x8aedcc: add             x2, PP, #0x12, lsl #12  ; [pp+0x12fd0] Field <MaterialDynamicColors.onTertiaryFixed>: static late final (offset: 0x11cc)
    //     0x8aedd0: ldr             x2, [x2, #0xfd0]
    // 0x8aedd4: r0 = InitLateFinalStaticField()
    //     0x8aedd4: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8aedd8: mov             x1, x0
    // 0x8aeddc: ldur            x2, [fp, #-0x20]
    // 0x8aede0: r0 = getArgb()
    //     0x8aede0: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8aede4: stur            x0, [fp, #-0x38]
    // 0x8aede8: asr             x1, x0, #0x18
    // 0x8aedec: asr             x2, x0, #0x10
    // 0x8aedf0: stur            x2, [fp, #-0x30]
    // 0x8aedf4: asr             x3, x0, #8
    // 0x8aedf8: stur            x3, [fp, #-0x28]
    // 0x8aedfc: ubfx            x1, x1, #0, #0x20
    // 0x8aee00: and             w4, w1, #0xff
    // 0x8aee04: ubfx            x4, x4, #0, #0x20
    // 0x8aee08: scvtf           d0, x4
    // 0x8aee0c: d1 = 255.000000
    //     0x8aee0c: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8aee10: fdiv            d2, d0, d1
    // 0x8aee14: r17 = -432
    //     0x8aee14: mov             x17, #-0x1b0
    // 0x8aee18: str             d2, [fp, x17]
    // 0x8aee1c: r0 = Color()
    //     0x8aee1c: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8aee20: mov             x1, x0
    // 0x8aee24: r0 = Instance_ColorSpace
    //     0x8aee24: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8aee28: ldr             x0, [x0, #0x298]
    // 0x8aee2c: stur            x1, [fp, #-0xe0]
    // 0x8aee30: StoreField: r1->field_27 = r0
    //     0x8aee30: stur            w0, [x1, #0x27]
    // 0x8aee34: r17 = -432
    //     0x8aee34: mov             x17, #-0x1b0
    // 0x8aee38: ldr             d0, [fp, x17]
    // 0x8aee3c: StoreField: r1->field_7 = d0
    //     0x8aee3c: stur            d0, [x1, #7]
    // 0x8aee40: ldur            x2, [fp, #-0x30]
    // 0x8aee44: ubfx            x2, x2, #0, #0x20
    // 0x8aee48: and             w3, w2, #0xff
    // 0x8aee4c: ubfx            x3, x3, #0, #0x20
    // 0x8aee50: scvtf           d0, x3
    // 0x8aee54: d1 = 255.000000
    //     0x8aee54: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8aee58: fdiv            d2, d0, d1
    // 0x8aee5c: StoreField: r1->field_f = d2
    //     0x8aee5c: stur            d2, [x1, #0xf]
    // 0x8aee60: ldur            x2, [fp, #-0x28]
    // 0x8aee64: ubfx            x2, x2, #0, #0x20
    // 0x8aee68: and             w3, w2, #0xff
    // 0x8aee6c: ubfx            x3, x3, #0, #0x20
    // 0x8aee70: scvtf           d0, x3
    // 0x8aee74: fdiv            d2, d0, d1
    // 0x8aee78: ArrayStore: r1[0] = d2  ; List_8
    //     0x8aee78: stur            d2, [x1, #0x17]
    // 0x8aee7c: ldur            x2, [fp, #-0x38]
    // 0x8aee80: ubfx            x2, x2, #0, #0x20
    // 0x8aee84: and             w3, w2, #0xff
    // 0x8aee88: ubfx            x3, x3, #0, #0x20
    // 0x8aee8c: scvtf           d0, x3
    // 0x8aee90: fdiv            d2, d0, d1
    // 0x8aee94: StoreField: r1->field_1f = d2
    //     0x8aee94: stur            d2, [x1, #0x1f]
    // 0x8aee98: r0 = LoadStaticField(0x11d0)
    //     0x8aee98: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8aee9c: ldr             x0, [x0, #0x23a0]
    // 0x8aeea0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8aeea4: cmp             w0, w16
    // 0x8aeea8: b.ne            #0x8aeeb8
    // 0x8aeeac: r2 = onTertiaryFixedVariant
    //     0x8aeeac: add             x2, PP, #0x12, lsl #12  ; [pp+0x12fd8] Field <MaterialDynamicColors.onTertiaryFixedVariant>: static late final (offset: 0x11d0)
    //     0x8aeeb0: ldr             x2, [x2, #0xfd8]
    // 0x8aeeb4: r0 = InitLateFinalStaticField()
    //     0x8aeeb4: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8aeeb8: mov             x1, x0
    // 0x8aeebc: ldur            x2, [fp, #-0x20]
    // 0x8aeec0: r0 = getArgb()
    //     0x8aeec0: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8aeec4: stur            x0, [fp, #-0x38]
    // 0x8aeec8: asr             x1, x0, #0x18
    // 0x8aeecc: asr             x2, x0, #0x10
    // 0x8aeed0: stur            x2, [fp, #-0x30]
    // 0x8aeed4: asr             x3, x0, #8
    // 0x8aeed8: stur            x3, [fp, #-0x28]
    // 0x8aeedc: ubfx            x1, x1, #0, #0x20
    // 0x8aeee0: and             w4, w1, #0xff
    // 0x8aeee4: ubfx            x4, x4, #0, #0x20
    // 0x8aeee8: scvtf           d0, x4
    // 0x8aeeec: d1 = 255.000000
    //     0x8aeeec: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8aeef0: fdiv            d2, d0, d1
    // 0x8aeef4: r17 = -432
    //     0x8aeef4: mov             x17, #-0x1b0
    // 0x8aeef8: str             d2, [fp, x17]
    // 0x8aeefc: r0 = Color()
    //     0x8aeefc: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8aef00: mov             x1, x0
    // 0x8aef04: r0 = Instance_ColorSpace
    //     0x8aef04: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8aef08: ldr             x0, [x0, #0x298]
    // 0x8aef0c: stur            x1, [fp, #-0xe8]
    // 0x8aef10: StoreField: r1->field_27 = r0
    //     0x8aef10: stur            w0, [x1, #0x27]
    // 0x8aef14: r17 = -432
    //     0x8aef14: mov             x17, #-0x1b0
    // 0x8aef18: ldr             d0, [fp, x17]
    // 0x8aef1c: StoreField: r1->field_7 = d0
    //     0x8aef1c: stur            d0, [x1, #7]
    // 0x8aef20: ldur            x2, [fp, #-0x30]
    // 0x8aef24: ubfx            x2, x2, #0, #0x20
    // 0x8aef28: and             w3, w2, #0xff
    // 0x8aef2c: ubfx            x3, x3, #0, #0x20
    // 0x8aef30: scvtf           d0, x3
    // 0x8aef34: d1 = 255.000000
    //     0x8aef34: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8aef38: fdiv            d2, d0, d1
    // 0x8aef3c: StoreField: r1->field_f = d2
    //     0x8aef3c: stur            d2, [x1, #0xf]
    // 0x8aef40: ldur            x2, [fp, #-0x28]
    // 0x8aef44: ubfx            x2, x2, #0, #0x20
    // 0x8aef48: and             w3, w2, #0xff
    // 0x8aef4c: ubfx            x3, x3, #0, #0x20
    // 0x8aef50: scvtf           d0, x3
    // 0x8aef54: fdiv            d2, d0, d1
    // 0x8aef58: ArrayStore: r1[0] = d2  ; List_8
    //     0x8aef58: stur            d2, [x1, #0x17]
    // 0x8aef5c: ldur            x2, [fp, #-0x38]
    // 0x8aef60: ubfx            x2, x2, #0, #0x20
    // 0x8aef64: and             w3, w2, #0xff
    // 0x8aef68: ubfx            x3, x3, #0, #0x20
    // 0x8aef6c: scvtf           d0, x3
    // 0x8aef70: fdiv            d2, d0, d1
    // 0x8aef74: StoreField: r1->field_1f = d2
    //     0x8aef74: stur            d2, [x1, #0x1f]
    // 0x8aef78: r0 = LoadStaticField(0x1194)
    //     0x8aef78: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8aef7c: ldr             x0, [x0, #0x2328]
    // 0x8aef80: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8aef84: cmp             w0, w16
    // 0x8aef88: b.ne            #0x8aef98
    // 0x8aef8c: r2 = error
    //     0x8aef8c: add             x2, PP, #0x12, lsl #12  ; [pp+0x12fe0] Field <MaterialDynamicColors.error>: static late final (offset: 0x1194)
    //     0x8aef90: ldr             x2, [x2, #0xfe0]
    // 0x8aef94: r0 = InitLateFinalStaticField()
    //     0x8aef94: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8aef98: mov             x1, x0
    // 0x8aef9c: ldur            x2, [fp, #-0x20]
    // 0x8aefa0: r0 = getArgb()
    //     0x8aefa0: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8aefa4: stur            x0, [fp, #-0x38]
    // 0x8aefa8: asr             x1, x0, #0x18
    // 0x8aefac: asr             x2, x0, #0x10
    // 0x8aefb0: stur            x2, [fp, #-0x30]
    // 0x8aefb4: asr             x3, x0, #8
    // 0x8aefb8: stur            x3, [fp, #-0x28]
    // 0x8aefbc: ubfx            x1, x1, #0, #0x20
    // 0x8aefc0: and             w4, w1, #0xff
    // 0x8aefc4: ubfx            x4, x4, #0, #0x20
    // 0x8aefc8: scvtf           d0, x4
    // 0x8aefcc: d1 = 255.000000
    //     0x8aefcc: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8aefd0: fdiv            d2, d0, d1
    // 0x8aefd4: r17 = -432
    //     0x8aefd4: mov             x17, #-0x1b0
    // 0x8aefd8: str             d2, [fp, x17]
    // 0x8aefdc: r0 = Color()
    //     0x8aefdc: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8aefe0: mov             x1, x0
    // 0x8aefe4: r0 = Instance_ColorSpace
    //     0x8aefe4: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8aefe8: ldr             x0, [x0, #0x298]
    // 0x8aefec: stur            x1, [fp, #-0xf0]
    // 0x8aeff0: StoreField: r1->field_27 = r0
    //     0x8aeff0: stur            w0, [x1, #0x27]
    // 0x8aeff4: r17 = -432
    //     0x8aeff4: mov             x17, #-0x1b0
    // 0x8aeff8: ldr             d0, [fp, x17]
    // 0x8aeffc: StoreField: r1->field_7 = d0
    //     0x8aeffc: stur            d0, [x1, #7]
    // 0x8af000: ldur            x2, [fp, #-0x30]
    // 0x8af004: ubfx            x2, x2, #0, #0x20
    // 0x8af008: and             w3, w2, #0xff
    // 0x8af00c: ubfx            x3, x3, #0, #0x20
    // 0x8af010: scvtf           d0, x3
    // 0x8af014: d1 = 255.000000
    //     0x8af014: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8af018: fdiv            d2, d0, d1
    // 0x8af01c: StoreField: r1->field_f = d2
    //     0x8af01c: stur            d2, [x1, #0xf]
    // 0x8af020: ldur            x2, [fp, #-0x28]
    // 0x8af024: ubfx            x2, x2, #0, #0x20
    // 0x8af028: and             w3, w2, #0xff
    // 0x8af02c: ubfx            x3, x3, #0, #0x20
    // 0x8af030: scvtf           d0, x3
    // 0x8af034: fdiv            d2, d0, d1
    // 0x8af038: ArrayStore: r1[0] = d2  ; List_8
    //     0x8af038: stur            d2, [x1, #0x17]
    // 0x8af03c: ldur            x2, [fp, #-0x38]
    // 0x8af040: ubfx            x2, x2, #0, #0x20
    // 0x8af044: and             w3, w2, #0xff
    // 0x8af048: ubfx            x3, x3, #0, #0x20
    // 0x8af04c: scvtf           d0, x3
    // 0x8af050: fdiv            d2, d0, d1
    // 0x8af054: StoreField: r1->field_1f = d2
    //     0x8af054: stur            d2, [x1, #0x1f]
    // 0x8af058: r0 = LoadStaticField(0x1198)
    //     0x8af058: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8af05c: ldr             x0, [x0, #0x2330]
    // 0x8af060: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8af064: cmp             w0, w16
    // 0x8af068: b.ne            #0x8af078
    // 0x8af06c: r2 = onError
    //     0x8af06c: add             x2, PP, #0x12, lsl #12  ; [pp+0x12fe8] Field <MaterialDynamicColors.onError>: static late final (offset: 0x1198)
    //     0x8af070: ldr             x2, [x2, #0xfe8]
    // 0x8af074: r0 = InitLateFinalStaticField()
    //     0x8af074: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8af078: mov             x1, x0
    // 0x8af07c: ldur            x2, [fp, #-0x20]
    // 0x8af080: r0 = getArgb()
    //     0x8af080: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8af084: stur            x0, [fp, #-0x38]
    // 0x8af088: asr             x1, x0, #0x18
    // 0x8af08c: asr             x2, x0, #0x10
    // 0x8af090: stur            x2, [fp, #-0x30]
    // 0x8af094: asr             x3, x0, #8
    // 0x8af098: stur            x3, [fp, #-0x28]
    // 0x8af09c: ubfx            x1, x1, #0, #0x20
    // 0x8af0a0: and             w4, w1, #0xff
    // 0x8af0a4: ubfx            x4, x4, #0, #0x20
    // 0x8af0a8: scvtf           d0, x4
    // 0x8af0ac: d1 = 255.000000
    //     0x8af0ac: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8af0b0: fdiv            d2, d0, d1
    // 0x8af0b4: r17 = -432
    //     0x8af0b4: mov             x17, #-0x1b0
    // 0x8af0b8: str             d2, [fp, x17]
    // 0x8af0bc: r0 = Color()
    //     0x8af0bc: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8af0c0: mov             x1, x0
    // 0x8af0c4: r0 = Instance_ColorSpace
    //     0x8af0c4: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8af0c8: ldr             x0, [x0, #0x298]
    // 0x8af0cc: stur            x1, [fp, #-0xf8]
    // 0x8af0d0: StoreField: r1->field_27 = r0
    //     0x8af0d0: stur            w0, [x1, #0x27]
    // 0x8af0d4: r17 = -432
    //     0x8af0d4: mov             x17, #-0x1b0
    // 0x8af0d8: ldr             d0, [fp, x17]
    // 0x8af0dc: StoreField: r1->field_7 = d0
    //     0x8af0dc: stur            d0, [x1, #7]
    // 0x8af0e0: ldur            x2, [fp, #-0x30]
    // 0x8af0e4: ubfx            x2, x2, #0, #0x20
    // 0x8af0e8: and             w3, w2, #0xff
    // 0x8af0ec: ubfx            x3, x3, #0, #0x20
    // 0x8af0f0: scvtf           d0, x3
    // 0x8af0f4: d1 = 255.000000
    //     0x8af0f4: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8af0f8: fdiv            d2, d0, d1
    // 0x8af0fc: StoreField: r1->field_f = d2
    //     0x8af0fc: stur            d2, [x1, #0xf]
    // 0x8af100: ldur            x2, [fp, #-0x28]
    // 0x8af104: ubfx            x2, x2, #0, #0x20
    // 0x8af108: and             w3, w2, #0xff
    // 0x8af10c: ubfx            x3, x3, #0, #0x20
    // 0x8af110: scvtf           d0, x3
    // 0x8af114: fdiv            d2, d0, d1
    // 0x8af118: ArrayStore: r1[0] = d2  ; List_8
    //     0x8af118: stur            d2, [x1, #0x17]
    // 0x8af11c: ldur            x2, [fp, #-0x38]
    // 0x8af120: ubfx            x2, x2, #0, #0x20
    // 0x8af124: and             w3, w2, #0xff
    // 0x8af128: ubfx            x3, x3, #0, #0x20
    // 0x8af12c: scvtf           d0, x3
    // 0x8af130: fdiv            d2, d0, d1
    // 0x8af134: StoreField: r1->field_1f = d2
    //     0x8af134: stur            d2, [x1, #0x1f]
    // 0x8af138: r0 = LoadStaticField(0x119c)
    //     0x8af138: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8af13c: ldr             x0, [x0, #0x2338]
    // 0x8af140: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8af144: cmp             w0, w16
    // 0x8af148: b.ne            #0x8af158
    // 0x8af14c: r2 = errorContainer
    //     0x8af14c: add             x2, PP, #0x12, lsl #12  ; [pp+0x12ff0] Field <MaterialDynamicColors.errorContainer>: static late final (offset: 0x119c)
    //     0x8af150: ldr             x2, [x2, #0xff0]
    // 0x8af154: r0 = InitLateFinalStaticField()
    //     0x8af154: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8af158: mov             x1, x0
    // 0x8af15c: ldur            x2, [fp, #-0x20]
    // 0x8af160: r0 = getArgb()
    //     0x8af160: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8af164: stur            x0, [fp, #-0x38]
    // 0x8af168: asr             x1, x0, #0x18
    // 0x8af16c: asr             x2, x0, #0x10
    // 0x8af170: stur            x2, [fp, #-0x30]
    // 0x8af174: asr             x3, x0, #8
    // 0x8af178: stur            x3, [fp, #-0x28]
    // 0x8af17c: ubfx            x1, x1, #0, #0x20
    // 0x8af180: and             w4, w1, #0xff
    // 0x8af184: ubfx            x4, x4, #0, #0x20
    // 0x8af188: scvtf           d0, x4
    // 0x8af18c: d1 = 255.000000
    //     0x8af18c: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8af190: fdiv            d2, d0, d1
    // 0x8af194: r17 = -432
    //     0x8af194: mov             x17, #-0x1b0
    // 0x8af198: str             d2, [fp, x17]
    // 0x8af19c: r0 = Color()
    //     0x8af19c: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8af1a0: mov             x1, x0
    // 0x8af1a4: r0 = Instance_ColorSpace
    //     0x8af1a4: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8af1a8: ldr             x0, [x0, #0x298]
    // 0x8af1ac: stur            x1, [fp, #-0x100]
    // 0x8af1b0: StoreField: r1->field_27 = r0
    //     0x8af1b0: stur            w0, [x1, #0x27]
    // 0x8af1b4: r17 = -432
    //     0x8af1b4: mov             x17, #-0x1b0
    // 0x8af1b8: ldr             d0, [fp, x17]
    // 0x8af1bc: StoreField: r1->field_7 = d0
    //     0x8af1bc: stur            d0, [x1, #7]
    // 0x8af1c0: ldur            x2, [fp, #-0x30]
    // 0x8af1c4: ubfx            x2, x2, #0, #0x20
    // 0x8af1c8: and             w3, w2, #0xff
    // 0x8af1cc: ubfx            x3, x3, #0, #0x20
    // 0x8af1d0: scvtf           d0, x3
    // 0x8af1d4: d1 = 255.000000
    //     0x8af1d4: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8af1d8: fdiv            d2, d0, d1
    // 0x8af1dc: StoreField: r1->field_f = d2
    //     0x8af1dc: stur            d2, [x1, #0xf]
    // 0x8af1e0: ldur            x2, [fp, #-0x28]
    // 0x8af1e4: ubfx            x2, x2, #0, #0x20
    // 0x8af1e8: and             w3, w2, #0xff
    // 0x8af1ec: ubfx            x3, x3, #0, #0x20
    // 0x8af1f0: scvtf           d0, x3
    // 0x8af1f4: fdiv            d2, d0, d1
    // 0x8af1f8: ArrayStore: r1[0] = d2  ; List_8
    //     0x8af1f8: stur            d2, [x1, #0x17]
    // 0x8af1fc: ldur            x2, [fp, #-0x38]
    // 0x8af200: ubfx            x2, x2, #0, #0x20
    // 0x8af204: and             w3, w2, #0xff
    // 0x8af208: ubfx            x3, x3, #0, #0x20
    // 0x8af20c: scvtf           d0, x3
    // 0x8af210: fdiv            d2, d0, d1
    // 0x8af214: StoreField: r1->field_1f = d2
    //     0x8af214: stur            d2, [x1, #0x1f]
    // 0x8af218: r0 = LoadStaticField(0x11a0)
    //     0x8af218: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8af21c: ldr             x0, [x0, #0x2340]
    // 0x8af220: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8af224: cmp             w0, w16
    // 0x8af228: b.ne            #0x8af238
    // 0x8af22c: r2 = onErrorContainer
    //     0x8af22c: add             x2, PP, #0x12, lsl #12  ; [pp+0x12ff8] Field <MaterialDynamicColors.onErrorContainer>: static late final (offset: 0x11a0)
    //     0x8af230: ldr             x2, [x2, #0xff8]
    // 0x8af234: r0 = InitLateFinalStaticField()
    //     0x8af234: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8af238: mov             x1, x0
    // 0x8af23c: ldur            x2, [fp, #-0x20]
    // 0x8af240: r0 = getArgb()
    //     0x8af240: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8af244: stur            x0, [fp, #-0x38]
    // 0x8af248: asr             x1, x0, #0x18
    // 0x8af24c: asr             x2, x0, #0x10
    // 0x8af250: stur            x2, [fp, #-0x30]
    // 0x8af254: asr             x3, x0, #8
    // 0x8af258: stur            x3, [fp, #-0x28]
    // 0x8af25c: ubfx            x1, x1, #0, #0x20
    // 0x8af260: and             w4, w1, #0xff
    // 0x8af264: ubfx            x4, x4, #0, #0x20
    // 0x8af268: scvtf           d0, x4
    // 0x8af26c: d1 = 255.000000
    //     0x8af26c: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8af270: fdiv            d2, d0, d1
    // 0x8af274: r17 = -432
    //     0x8af274: mov             x17, #-0x1b0
    // 0x8af278: str             d2, [fp, x17]
    // 0x8af27c: r0 = Color()
    //     0x8af27c: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8af280: mov             x1, x0
    // 0x8af284: r0 = Instance_ColorSpace
    //     0x8af284: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8af288: ldr             x0, [x0, #0x298]
    // 0x8af28c: r17 = -264
    //     0x8af28c: mov             x17, #-0x108
    // 0x8af290: str             x1, [fp, x17]
    // 0x8af294: StoreField: r1->field_27 = r0
    //     0x8af294: stur            w0, [x1, #0x27]
    // 0x8af298: r17 = -432
    //     0x8af298: mov             x17, #-0x1b0
    // 0x8af29c: ldr             d0, [fp, x17]
    // 0x8af2a0: StoreField: r1->field_7 = d0
    //     0x8af2a0: stur            d0, [x1, #7]
    // 0x8af2a4: ldur            x2, [fp, #-0x30]
    // 0x8af2a8: ubfx            x2, x2, #0, #0x20
    // 0x8af2ac: and             w3, w2, #0xff
    // 0x8af2b0: ubfx            x3, x3, #0, #0x20
    // 0x8af2b4: scvtf           d0, x3
    // 0x8af2b8: d1 = 255.000000
    //     0x8af2b8: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8af2bc: fdiv            d2, d0, d1
    // 0x8af2c0: StoreField: r1->field_f = d2
    //     0x8af2c0: stur            d2, [x1, #0xf]
    // 0x8af2c4: ldur            x2, [fp, #-0x28]
    // 0x8af2c8: ubfx            x2, x2, #0, #0x20
    // 0x8af2cc: and             w3, w2, #0xff
    // 0x8af2d0: ubfx            x3, x3, #0, #0x20
    // 0x8af2d4: scvtf           d0, x3
    // 0x8af2d8: fdiv            d2, d0, d1
    // 0x8af2dc: ArrayStore: r1[0] = d2  ; List_8
    //     0x8af2dc: stur            d2, [x1, #0x17]
    // 0x8af2e0: ldur            x2, [fp, #-0x38]
    // 0x8af2e4: ubfx            x2, x2, #0, #0x20
    // 0x8af2e8: and             w3, w2, #0xff
    // 0x8af2ec: ubfx            x3, x3, #0, #0x20
    // 0x8af2f0: scvtf           d0, x3
    // 0x8af2f4: fdiv            d2, d0, d1
    // 0x8af2f8: StoreField: r1->field_1f = d2
    //     0x8af2f8: stur            d2, [x1, #0x1f]
    // 0x8af2fc: r0 = LoadStaticField(0x1150)
    //     0x8af2fc: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8af300: ldr             x0, [x0, #0x22a0]
    // 0x8af304: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8af308: cmp             w0, w16
    // 0x8af30c: b.ne            #0x8af31c
    // 0x8af310: r2 = outline
    //     0x8af310: add             x2, PP, #0x13, lsl #12  ; [pp+0x13000] Field <MaterialDynamicColors.outline>: static late final (offset: 0x1150)
    //     0x8af314: ldr             x2, [x2]
    // 0x8af318: r0 = InitLateFinalStaticField()
    //     0x8af318: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8af31c: mov             x1, x0
    // 0x8af320: ldur            x2, [fp, #-0x20]
    // 0x8af324: r0 = getArgb()
    //     0x8af324: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8af328: stur            x0, [fp, #-0x38]
    // 0x8af32c: asr             x1, x0, #0x18
    // 0x8af330: asr             x2, x0, #0x10
    // 0x8af334: stur            x2, [fp, #-0x30]
    // 0x8af338: asr             x3, x0, #8
    // 0x8af33c: stur            x3, [fp, #-0x28]
    // 0x8af340: ubfx            x1, x1, #0, #0x20
    // 0x8af344: and             w4, w1, #0xff
    // 0x8af348: ubfx            x4, x4, #0, #0x20
    // 0x8af34c: scvtf           d0, x4
    // 0x8af350: d1 = 255.000000
    //     0x8af350: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8af354: fdiv            d2, d0, d1
    // 0x8af358: r17 = -432
    //     0x8af358: mov             x17, #-0x1b0
    // 0x8af35c: str             d2, [fp, x17]
    // 0x8af360: r0 = Color()
    //     0x8af360: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8af364: mov             x1, x0
    // 0x8af368: r0 = Instance_ColorSpace
    //     0x8af368: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8af36c: ldr             x0, [x0, #0x298]
    // 0x8af370: r17 = -272
    //     0x8af370: mov             x17, #-0x110
    // 0x8af374: str             x1, [fp, x17]
    // 0x8af378: StoreField: r1->field_27 = r0
    //     0x8af378: stur            w0, [x1, #0x27]
    // 0x8af37c: r17 = -432
    //     0x8af37c: mov             x17, #-0x1b0
    // 0x8af380: ldr             d0, [fp, x17]
    // 0x8af384: StoreField: r1->field_7 = d0
    //     0x8af384: stur            d0, [x1, #7]
    // 0x8af388: ldur            x2, [fp, #-0x30]
    // 0x8af38c: ubfx            x2, x2, #0, #0x20
    // 0x8af390: and             w3, w2, #0xff
    // 0x8af394: ubfx            x3, x3, #0, #0x20
    // 0x8af398: scvtf           d0, x3
    // 0x8af39c: d1 = 255.000000
    //     0x8af39c: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8af3a0: fdiv            d2, d0, d1
    // 0x8af3a4: StoreField: r1->field_f = d2
    //     0x8af3a4: stur            d2, [x1, #0xf]
    // 0x8af3a8: ldur            x2, [fp, #-0x28]
    // 0x8af3ac: ubfx            x2, x2, #0, #0x20
    // 0x8af3b0: and             w3, w2, #0xff
    // 0x8af3b4: ubfx            x3, x3, #0, #0x20
    // 0x8af3b8: scvtf           d0, x3
    // 0x8af3bc: fdiv            d2, d0, d1
    // 0x8af3c0: ArrayStore: r1[0] = d2  ; List_8
    //     0x8af3c0: stur            d2, [x1, #0x17]
    // 0x8af3c4: ldur            x2, [fp, #-0x38]
    // 0x8af3c8: ubfx            x2, x2, #0, #0x20
    // 0x8af3cc: and             w3, w2, #0xff
    // 0x8af3d0: ubfx            x3, x3, #0, #0x20
    // 0x8af3d4: scvtf           d0, x3
    // 0x8af3d8: fdiv            d2, d0, d1
    // 0x8af3dc: StoreField: r1->field_1f = d2
    //     0x8af3dc: stur            d2, [x1, #0x1f]
    // 0x8af3e0: r0 = LoadStaticField(0x1154)
    //     0x8af3e0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8af3e4: ldr             x0, [x0, #0x22a8]
    // 0x8af3e8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8af3ec: cmp             w0, w16
    // 0x8af3f0: b.ne            #0x8af400
    // 0x8af3f4: r2 = outlineVariant
    //     0x8af3f4: add             x2, PP, #0x13, lsl #12  ; [pp+0x13008] Field <MaterialDynamicColors.outlineVariant>: static late final (offset: 0x1154)
    //     0x8af3f8: ldr             x2, [x2, #8]
    // 0x8af3fc: r0 = InitLateFinalStaticField()
    //     0x8af3fc: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8af400: mov             x1, x0
    // 0x8af404: ldur            x2, [fp, #-0x20]
    // 0x8af408: r0 = getArgb()
    //     0x8af408: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8af40c: stur            x0, [fp, #-0x38]
    // 0x8af410: asr             x1, x0, #0x18
    // 0x8af414: asr             x2, x0, #0x10
    // 0x8af418: stur            x2, [fp, #-0x30]
    // 0x8af41c: asr             x3, x0, #8
    // 0x8af420: stur            x3, [fp, #-0x28]
    // 0x8af424: ubfx            x1, x1, #0, #0x20
    // 0x8af428: and             w4, w1, #0xff
    // 0x8af42c: ubfx            x4, x4, #0, #0x20
    // 0x8af430: scvtf           d0, x4
    // 0x8af434: d1 = 255.000000
    //     0x8af434: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8af438: fdiv            d2, d0, d1
    // 0x8af43c: r17 = -432
    //     0x8af43c: mov             x17, #-0x1b0
    // 0x8af440: str             d2, [fp, x17]
    // 0x8af444: r0 = Color()
    //     0x8af444: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8af448: mov             x1, x0
    // 0x8af44c: r0 = Instance_ColorSpace
    //     0x8af44c: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8af450: ldr             x0, [x0, #0x298]
    // 0x8af454: r17 = -280
    //     0x8af454: mov             x17, #-0x118
    // 0x8af458: str             x1, [fp, x17]
    // 0x8af45c: StoreField: r1->field_27 = r0
    //     0x8af45c: stur            w0, [x1, #0x27]
    // 0x8af460: r17 = -432
    //     0x8af460: mov             x17, #-0x1b0
    // 0x8af464: ldr             d0, [fp, x17]
    // 0x8af468: StoreField: r1->field_7 = d0
    //     0x8af468: stur            d0, [x1, #7]
    // 0x8af46c: ldur            x2, [fp, #-0x30]
    // 0x8af470: ubfx            x2, x2, #0, #0x20
    // 0x8af474: and             w3, w2, #0xff
    // 0x8af478: ubfx            x3, x3, #0, #0x20
    // 0x8af47c: scvtf           d0, x3
    // 0x8af480: d1 = 255.000000
    //     0x8af480: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8af484: fdiv            d2, d0, d1
    // 0x8af488: StoreField: r1->field_f = d2
    //     0x8af488: stur            d2, [x1, #0xf]
    // 0x8af48c: ldur            x2, [fp, #-0x28]
    // 0x8af490: ubfx            x2, x2, #0, #0x20
    // 0x8af494: and             w3, w2, #0xff
    // 0x8af498: ubfx            x3, x3, #0, #0x20
    // 0x8af49c: scvtf           d0, x3
    // 0x8af4a0: fdiv            d2, d0, d1
    // 0x8af4a4: ArrayStore: r1[0] = d2  ; List_8
    //     0x8af4a4: stur            d2, [x1, #0x17]
    // 0x8af4a8: ldur            x2, [fp, #-0x38]
    // 0x8af4ac: ubfx            x2, x2, #0, #0x20
    // 0x8af4b0: and             w3, w2, #0xff
    // 0x8af4b4: ubfx            x3, x3, #0, #0x20
    // 0x8af4b8: scvtf           d0, x3
    // 0x8af4bc: fdiv            d2, d0, d1
    // 0x8af4c0: StoreField: r1->field_1f = d2
    //     0x8af4c0: stur            d2, [x1, #0x1f]
    // 0x8af4c4: r0 = LoadStaticField(0x111c)
    //     0x8af4c4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8af4c8: ldr             x0, [x0, #0x2238]
    // 0x8af4cc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8af4d0: cmp             w0, w16
    // 0x8af4d4: b.ne            #0x8af4e4
    // 0x8af4d8: r2 = surface
    //     0x8af4d8: add             x2, PP, #0x13, lsl #12  ; [pp+0x13010] Field <MaterialDynamicColors.surface>: static late final (offset: 0x111c)
    //     0x8af4dc: ldr             x2, [x2, #0x10]
    // 0x8af4e0: r0 = InitLateFinalStaticField()
    //     0x8af4e0: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8af4e4: mov             x1, x0
    // 0x8af4e8: ldur            x2, [fp, #-0x20]
    // 0x8af4ec: r0 = getArgb()
    //     0x8af4ec: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8af4f0: stur            x0, [fp, #-0x38]
    // 0x8af4f4: asr             x1, x0, #0x18
    // 0x8af4f8: asr             x2, x0, #0x10
    // 0x8af4fc: stur            x2, [fp, #-0x30]
    // 0x8af500: asr             x3, x0, #8
    // 0x8af504: stur            x3, [fp, #-0x28]
    // 0x8af508: ubfx            x1, x1, #0, #0x20
    // 0x8af50c: and             w4, w1, #0xff
    // 0x8af510: ubfx            x4, x4, #0, #0x20
    // 0x8af514: scvtf           d0, x4
    // 0x8af518: d1 = 255.000000
    //     0x8af518: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8af51c: fdiv            d2, d0, d1
    // 0x8af520: r17 = -432
    //     0x8af520: mov             x17, #-0x1b0
    // 0x8af524: str             d2, [fp, x17]
    // 0x8af528: r0 = Color()
    //     0x8af528: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8af52c: mov             x1, x0
    // 0x8af530: r0 = Instance_ColorSpace
    //     0x8af530: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8af534: ldr             x0, [x0, #0x298]
    // 0x8af538: r17 = -288
    //     0x8af538: mov             x17, #-0x120
    // 0x8af53c: str             x1, [fp, x17]
    // 0x8af540: StoreField: r1->field_27 = r0
    //     0x8af540: stur            w0, [x1, #0x27]
    // 0x8af544: r17 = -432
    //     0x8af544: mov             x17, #-0x1b0
    // 0x8af548: ldr             d0, [fp, x17]
    // 0x8af54c: StoreField: r1->field_7 = d0
    //     0x8af54c: stur            d0, [x1, #7]
    // 0x8af550: ldur            x2, [fp, #-0x30]
    // 0x8af554: ubfx            x2, x2, #0, #0x20
    // 0x8af558: and             w3, w2, #0xff
    // 0x8af55c: ubfx            x3, x3, #0, #0x20
    // 0x8af560: scvtf           d0, x3
    // 0x8af564: d1 = 255.000000
    //     0x8af564: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8af568: fdiv            d2, d0, d1
    // 0x8af56c: StoreField: r1->field_f = d2
    //     0x8af56c: stur            d2, [x1, #0xf]
    // 0x8af570: ldur            x2, [fp, #-0x28]
    // 0x8af574: ubfx            x2, x2, #0, #0x20
    // 0x8af578: and             w3, w2, #0xff
    // 0x8af57c: ubfx            x3, x3, #0, #0x20
    // 0x8af580: scvtf           d0, x3
    // 0x8af584: fdiv            d2, d0, d1
    // 0x8af588: ArrayStore: r1[0] = d2  ; List_8
    //     0x8af588: stur            d2, [x1, #0x17]
    // 0x8af58c: ldur            x2, [fp, #-0x38]
    // 0x8af590: ubfx            x2, x2, #0, #0x20
    // 0x8af594: and             w3, w2, #0xff
    // 0x8af598: ubfx            x3, x3, #0, #0x20
    // 0x8af59c: scvtf           d0, x3
    // 0x8af5a0: fdiv            d2, d0, d1
    // 0x8af5a4: StoreField: r1->field_1f = d2
    //     0x8af5a4: stur            d2, [x1, #0x1f]
    // 0x8af5a8: r0 = LoadStaticField(0x1120)
    //     0x8af5a8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8af5ac: ldr             x0, [x0, #0x2240]
    // 0x8af5b0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8af5b4: cmp             w0, w16
    // 0x8af5b8: b.ne            #0x8af5c8
    // 0x8af5bc: r2 = surfaceDim
    //     0x8af5bc: add             x2, PP, #0x13, lsl #12  ; [pp+0x13018] Field <MaterialDynamicColors.surfaceDim>: static late final (offset: 0x1120)
    //     0x8af5c0: ldr             x2, [x2, #0x18]
    // 0x8af5c4: r0 = InitLateFinalStaticField()
    //     0x8af5c4: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8af5c8: mov             x1, x0
    // 0x8af5cc: ldur            x2, [fp, #-0x20]
    // 0x8af5d0: r0 = getArgb()
    //     0x8af5d0: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8af5d4: stur            x0, [fp, #-0x38]
    // 0x8af5d8: asr             x1, x0, #0x18
    // 0x8af5dc: asr             x2, x0, #0x10
    // 0x8af5e0: stur            x2, [fp, #-0x30]
    // 0x8af5e4: asr             x3, x0, #8
    // 0x8af5e8: stur            x3, [fp, #-0x28]
    // 0x8af5ec: ubfx            x1, x1, #0, #0x20
    // 0x8af5f0: and             w4, w1, #0xff
    // 0x8af5f4: ubfx            x4, x4, #0, #0x20
    // 0x8af5f8: scvtf           d0, x4
    // 0x8af5fc: d1 = 255.000000
    //     0x8af5fc: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8af600: fdiv            d2, d0, d1
    // 0x8af604: r17 = -432
    //     0x8af604: mov             x17, #-0x1b0
    // 0x8af608: str             d2, [fp, x17]
    // 0x8af60c: r0 = Color()
    //     0x8af60c: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8af610: mov             x1, x0
    // 0x8af614: r0 = Instance_ColorSpace
    //     0x8af614: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8af618: ldr             x0, [x0, #0x298]
    // 0x8af61c: r17 = -296
    //     0x8af61c: mov             x17, #-0x128
    // 0x8af620: str             x1, [fp, x17]
    // 0x8af624: StoreField: r1->field_27 = r0
    //     0x8af624: stur            w0, [x1, #0x27]
    // 0x8af628: r17 = -432
    //     0x8af628: mov             x17, #-0x1b0
    // 0x8af62c: ldr             d0, [fp, x17]
    // 0x8af630: StoreField: r1->field_7 = d0
    //     0x8af630: stur            d0, [x1, #7]
    // 0x8af634: ldur            x2, [fp, #-0x30]
    // 0x8af638: ubfx            x2, x2, #0, #0x20
    // 0x8af63c: and             w3, w2, #0xff
    // 0x8af640: ubfx            x3, x3, #0, #0x20
    // 0x8af644: scvtf           d0, x3
    // 0x8af648: d1 = 255.000000
    //     0x8af648: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8af64c: fdiv            d2, d0, d1
    // 0x8af650: StoreField: r1->field_f = d2
    //     0x8af650: stur            d2, [x1, #0xf]
    // 0x8af654: ldur            x2, [fp, #-0x28]
    // 0x8af658: ubfx            x2, x2, #0, #0x20
    // 0x8af65c: and             w3, w2, #0xff
    // 0x8af660: ubfx            x3, x3, #0, #0x20
    // 0x8af664: scvtf           d0, x3
    // 0x8af668: fdiv            d2, d0, d1
    // 0x8af66c: ArrayStore: r1[0] = d2  ; List_8
    //     0x8af66c: stur            d2, [x1, #0x17]
    // 0x8af670: ldur            x2, [fp, #-0x38]
    // 0x8af674: ubfx            x2, x2, #0, #0x20
    // 0x8af678: and             w3, w2, #0xff
    // 0x8af67c: ubfx            x3, x3, #0, #0x20
    // 0x8af680: scvtf           d0, x3
    // 0x8af684: fdiv            d2, d0, d1
    // 0x8af688: StoreField: r1->field_1f = d2
    //     0x8af688: stur            d2, [x1, #0x1f]
    // 0x8af68c: r0 = LoadStaticField(0x1124)
    //     0x8af68c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8af690: ldr             x0, [x0, #0x2248]
    // 0x8af694: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8af698: cmp             w0, w16
    // 0x8af69c: b.ne            #0x8af6ac
    // 0x8af6a0: r2 = surfaceBright
    //     0x8af6a0: add             x2, PP, #0x13, lsl #12  ; [pp+0x13020] Field <MaterialDynamicColors.surfaceBright>: static late final (offset: 0x1124)
    //     0x8af6a4: ldr             x2, [x2, #0x20]
    // 0x8af6a8: r0 = InitLateFinalStaticField()
    //     0x8af6a8: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8af6ac: mov             x1, x0
    // 0x8af6b0: ldur            x2, [fp, #-0x20]
    // 0x8af6b4: r0 = getArgb()
    //     0x8af6b4: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8af6b8: stur            x0, [fp, #-0x38]
    // 0x8af6bc: asr             x1, x0, #0x18
    // 0x8af6c0: asr             x2, x0, #0x10
    // 0x8af6c4: stur            x2, [fp, #-0x30]
    // 0x8af6c8: asr             x3, x0, #8
    // 0x8af6cc: stur            x3, [fp, #-0x28]
    // 0x8af6d0: ubfx            x1, x1, #0, #0x20
    // 0x8af6d4: and             w4, w1, #0xff
    // 0x8af6d8: ubfx            x4, x4, #0, #0x20
    // 0x8af6dc: scvtf           d0, x4
    // 0x8af6e0: d1 = 255.000000
    //     0x8af6e0: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8af6e4: fdiv            d2, d0, d1
    // 0x8af6e8: r17 = -432
    //     0x8af6e8: mov             x17, #-0x1b0
    // 0x8af6ec: str             d2, [fp, x17]
    // 0x8af6f0: r0 = Color()
    //     0x8af6f0: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8af6f4: mov             x1, x0
    // 0x8af6f8: r0 = Instance_ColorSpace
    //     0x8af6f8: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8af6fc: ldr             x0, [x0, #0x298]
    // 0x8af700: r17 = -304
    //     0x8af700: mov             x17, #-0x130
    // 0x8af704: str             x1, [fp, x17]
    // 0x8af708: StoreField: r1->field_27 = r0
    //     0x8af708: stur            w0, [x1, #0x27]
    // 0x8af70c: r17 = -432
    //     0x8af70c: mov             x17, #-0x1b0
    // 0x8af710: ldr             d0, [fp, x17]
    // 0x8af714: StoreField: r1->field_7 = d0
    //     0x8af714: stur            d0, [x1, #7]
    // 0x8af718: ldur            x2, [fp, #-0x30]
    // 0x8af71c: ubfx            x2, x2, #0, #0x20
    // 0x8af720: and             w3, w2, #0xff
    // 0x8af724: ubfx            x3, x3, #0, #0x20
    // 0x8af728: scvtf           d0, x3
    // 0x8af72c: d1 = 255.000000
    //     0x8af72c: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8af730: fdiv            d2, d0, d1
    // 0x8af734: StoreField: r1->field_f = d2
    //     0x8af734: stur            d2, [x1, #0xf]
    // 0x8af738: ldur            x2, [fp, #-0x28]
    // 0x8af73c: ubfx            x2, x2, #0, #0x20
    // 0x8af740: and             w3, w2, #0xff
    // 0x8af744: ubfx            x3, x3, #0, #0x20
    // 0x8af748: scvtf           d0, x3
    // 0x8af74c: fdiv            d2, d0, d1
    // 0x8af750: ArrayStore: r1[0] = d2  ; List_8
    //     0x8af750: stur            d2, [x1, #0x17]
    // 0x8af754: ldur            x2, [fp, #-0x38]
    // 0x8af758: ubfx            x2, x2, #0, #0x20
    // 0x8af75c: and             w3, w2, #0xff
    // 0x8af760: ubfx            x3, x3, #0, #0x20
    // 0x8af764: scvtf           d0, x3
    // 0x8af768: fdiv            d2, d0, d1
    // 0x8af76c: StoreField: r1->field_1f = d2
    //     0x8af76c: stur            d2, [x1, #0x1f]
    // 0x8af770: r0 = LoadStaticField(0x1128)
    //     0x8af770: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8af774: ldr             x0, [x0, #0x2250]
    // 0x8af778: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8af77c: cmp             w0, w16
    // 0x8af780: b.ne            #0x8af790
    // 0x8af784: r2 = surfaceContainerLowest
    //     0x8af784: add             x2, PP, #0x13, lsl #12  ; [pp+0x13028] Field <MaterialDynamicColors.surfaceContainerLowest>: static late final (offset: 0x1128)
    //     0x8af788: ldr             x2, [x2, #0x28]
    // 0x8af78c: r0 = InitLateFinalStaticField()
    //     0x8af78c: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8af790: mov             x1, x0
    // 0x8af794: ldur            x2, [fp, #-0x20]
    // 0x8af798: r0 = getArgb()
    //     0x8af798: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8af79c: stur            x0, [fp, #-0x38]
    // 0x8af7a0: asr             x1, x0, #0x18
    // 0x8af7a4: asr             x2, x0, #0x10
    // 0x8af7a8: stur            x2, [fp, #-0x30]
    // 0x8af7ac: asr             x3, x0, #8
    // 0x8af7b0: stur            x3, [fp, #-0x28]
    // 0x8af7b4: ubfx            x1, x1, #0, #0x20
    // 0x8af7b8: and             w4, w1, #0xff
    // 0x8af7bc: ubfx            x4, x4, #0, #0x20
    // 0x8af7c0: scvtf           d0, x4
    // 0x8af7c4: d1 = 255.000000
    //     0x8af7c4: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8af7c8: fdiv            d2, d0, d1
    // 0x8af7cc: r17 = -432
    //     0x8af7cc: mov             x17, #-0x1b0
    // 0x8af7d0: str             d2, [fp, x17]
    // 0x8af7d4: r0 = Color()
    //     0x8af7d4: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8af7d8: mov             x1, x0
    // 0x8af7dc: r0 = Instance_ColorSpace
    //     0x8af7dc: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8af7e0: ldr             x0, [x0, #0x298]
    // 0x8af7e4: r17 = -312
    //     0x8af7e4: mov             x17, #-0x138
    // 0x8af7e8: str             x1, [fp, x17]
    // 0x8af7ec: StoreField: r1->field_27 = r0
    //     0x8af7ec: stur            w0, [x1, #0x27]
    // 0x8af7f0: r17 = -432
    //     0x8af7f0: mov             x17, #-0x1b0
    // 0x8af7f4: ldr             d0, [fp, x17]
    // 0x8af7f8: StoreField: r1->field_7 = d0
    //     0x8af7f8: stur            d0, [x1, #7]
    // 0x8af7fc: ldur            x2, [fp, #-0x30]
    // 0x8af800: ubfx            x2, x2, #0, #0x20
    // 0x8af804: and             w3, w2, #0xff
    // 0x8af808: ubfx            x3, x3, #0, #0x20
    // 0x8af80c: scvtf           d0, x3
    // 0x8af810: d1 = 255.000000
    //     0x8af810: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8af814: fdiv            d2, d0, d1
    // 0x8af818: StoreField: r1->field_f = d2
    //     0x8af818: stur            d2, [x1, #0xf]
    // 0x8af81c: ldur            x2, [fp, #-0x28]
    // 0x8af820: ubfx            x2, x2, #0, #0x20
    // 0x8af824: and             w3, w2, #0xff
    // 0x8af828: ubfx            x3, x3, #0, #0x20
    // 0x8af82c: scvtf           d0, x3
    // 0x8af830: fdiv            d2, d0, d1
    // 0x8af834: ArrayStore: r1[0] = d2  ; List_8
    //     0x8af834: stur            d2, [x1, #0x17]
    // 0x8af838: ldur            x2, [fp, #-0x38]
    // 0x8af83c: ubfx            x2, x2, #0, #0x20
    // 0x8af840: and             w3, w2, #0xff
    // 0x8af844: ubfx            x3, x3, #0, #0x20
    // 0x8af848: scvtf           d0, x3
    // 0x8af84c: fdiv            d2, d0, d1
    // 0x8af850: StoreField: r1->field_1f = d2
    //     0x8af850: stur            d2, [x1, #0x1f]
    // 0x8af854: r0 = LoadStaticField(0x112c)
    //     0x8af854: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8af858: ldr             x0, [x0, #0x2258]
    // 0x8af85c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8af860: cmp             w0, w16
    // 0x8af864: b.ne            #0x8af874
    // 0x8af868: r2 = surfaceContainerLow
    //     0x8af868: add             x2, PP, #0x13, lsl #12  ; [pp+0x13030] Field <MaterialDynamicColors.surfaceContainerLow>: static late final (offset: 0x112c)
    //     0x8af86c: ldr             x2, [x2, #0x30]
    // 0x8af870: r0 = InitLateFinalStaticField()
    //     0x8af870: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8af874: mov             x1, x0
    // 0x8af878: ldur            x2, [fp, #-0x20]
    // 0x8af87c: r0 = getArgb()
    //     0x8af87c: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8af880: stur            x0, [fp, #-0x38]
    // 0x8af884: asr             x1, x0, #0x18
    // 0x8af888: asr             x2, x0, #0x10
    // 0x8af88c: stur            x2, [fp, #-0x30]
    // 0x8af890: asr             x3, x0, #8
    // 0x8af894: stur            x3, [fp, #-0x28]
    // 0x8af898: ubfx            x1, x1, #0, #0x20
    // 0x8af89c: and             w4, w1, #0xff
    // 0x8af8a0: ubfx            x4, x4, #0, #0x20
    // 0x8af8a4: scvtf           d0, x4
    // 0x8af8a8: d1 = 255.000000
    //     0x8af8a8: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8af8ac: fdiv            d2, d0, d1
    // 0x8af8b0: r17 = -432
    //     0x8af8b0: mov             x17, #-0x1b0
    // 0x8af8b4: str             d2, [fp, x17]
    // 0x8af8b8: r0 = Color()
    //     0x8af8b8: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8af8bc: mov             x1, x0
    // 0x8af8c0: r0 = Instance_ColorSpace
    //     0x8af8c0: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8af8c4: ldr             x0, [x0, #0x298]
    // 0x8af8c8: r17 = -320
    //     0x8af8c8: mov             x17, #-0x140
    // 0x8af8cc: str             x1, [fp, x17]
    // 0x8af8d0: StoreField: r1->field_27 = r0
    //     0x8af8d0: stur            w0, [x1, #0x27]
    // 0x8af8d4: r17 = -432
    //     0x8af8d4: mov             x17, #-0x1b0
    // 0x8af8d8: ldr             d0, [fp, x17]
    // 0x8af8dc: StoreField: r1->field_7 = d0
    //     0x8af8dc: stur            d0, [x1, #7]
    // 0x8af8e0: ldur            x2, [fp, #-0x30]
    // 0x8af8e4: ubfx            x2, x2, #0, #0x20
    // 0x8af8e8: and             w3, w2, #0xff
    // 0x8af8ec: ubfx            x3, x3, #0, #0x20
    // 0x8af8f0: scvtf           d0, x3
    // 0x8af8f4: d1 = 255.000000
    //     0x8af8f4: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8af8f8: fdiv            d2, d0, d1
    // 0x8af8fc: StoreField: r1->field_f = d2
    //     0x8af8fc: stur            d2, [x1, #0xf]
    // 0x8af900: ldur            x2, [fp, #-0x28]
    // 0x8af904: ubfx            x2, x2, #0, #0x20
    // 0x8af908: and             w3, w2, #0xff
    // 0x8af90c: ubfx            x3, x3, #0, #0x20
    // 0x8af910: scvtf           d0, x3
    // 0x8af914: fdiv            d2, d0, d1
    // 0x8af918: ArrayStore: r1[0] = d2  ; List_8
    //     0x8af918: stur            d2, [x1, #0x17]
    // 0x8af91c: ldur            x2, [fp, #-0x38]
    // 0x8af920: ubfx            x2, x2, #0, #0x20
    // 0x8af924: and             w3, w2, #0xff
    // 0x8af928: ubfx            x3, x3, #0, #0x20
    // 0x8af92c: scvtf           d0, x3
    // 0x8af930: fdiv            d2, d0, d1
    // 0x8af934: StoreField: r1->field_1f = d2
    //     0x8af934: stur            d2, [x1, #0x1f]
    // 0x8af938: r0 = LoadStaticField(0x1130)
    //     0x8af938: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8af93c: ldr             x0, [x0, #0x2260]
    // 0x8af940: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8af944: cmp             w0, w16
    // 0x8af948: b.ne            #0x8af958
    // 0x8af94c: r2 = surfaceContainer
    //     0x8af94c: add             x2, PP, #0x13, lsl #12  ; [pp+0x13038] Field <MaterialDynamicColors.surfaceContainer>: static late final (offset: 0x1130)
    //     0x8af950: ldr             x2, [x2, #0x38]
    // 0x8af954: r0 = InitLateFinalStaticField()
    //     0x8af954: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8af958: mov             x1, x0
    // 0x8af95c: ldur            x2, [fp, #-0x20]
    // 0x8af960: r0 = getArgb()
    //     0x8af960: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8af964: stur            x0, [fp, #-0x38]
    // 0x8af968: asr             x1, x0, #0x18
    // 0x8af96c: asr             x2, x0, #0x10
    // 0x8af970: stur            x2, [fp, #-0x30]
    // 0x8af974: asr             x3, x0, #8
    // 0x8af978: stur            x3, [fp, #-0x28]
    // 0x8af97c: ubfx            x1, x1, #0, #0x20
    // 0x8af980: and             w4, w1, #0xff
    // 0x8af984: ubfx            x4, x4, #0, #0x20
    // 0x8af988: scvtf           d0, x4
    // 0x8af98c: d1 = 255.000000
    //     0x8af98c: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8af990: fdiv            d2, d0, d1
    // 0x8af994: r17 = -432
    //     0x8af994: mov             x17, #-0x1b0
    // 0x8af998: str             d2, [fp, x17]
    // 0x8af99c: r0 = Color()
    //     0x8af99c: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8af9a0: mov             x1, x0
    // 0x8af9a4: r0 = Instance_ColorSpace
    //     0x8af9a4: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8af9a8: ldr             x0, [x0, #0x298]
    // 0x8af9ac: r17 = -328
    //     0x8af9ac: mov             x17, #-0x148
    // 0x8af9b0: str             x1, [fp, x17]
    // 0x8af9b4: StoreField: r1->field_27 = r0
    //     0x8af9b4: stur            w0, [x1, #0x27]
    // 0x8af9b8: r17 = -432
    //     0x8af9b8: mov             x17, #-0x1b0
    // 0x8af9bc: ldr             d0, [fp, x17]
    // 0x8af9c0: StoreField: r1->field_7 = d0
    //     0x8af9c0: stur            d0, [x1, #7]
    // 0x8af9c4: ldur            x2, [fp, #-0x30]
    // 0x8af9c8: ubfx            x2, x2, #0, #0x20
    // 0x8af9cc: and             w3, w2, #0xff
    // 0x8af9d0: ubfx            x3, x3, #0, #0x20
    // 0x8af9d4: scvtf           d0, x3
    // 0x8af9d8: d1 = 255.000000
    //     0x8af9d8: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8af9dc: fdiv            d2, d0, d1
    // 0x8af9e0: StoreField: r1->field_f = d2
    //     0x8af9e0: stur            d2, [x1, #0xf]
    // 0x8af9e4: ldur            x2, [fp, #-0x28]
    // 0x8af9e8: ubfx            x2, x2, #0, #0x20
    // 0x8af9ec: and             w3, w2, #0xff
    // 0x8af9f0: ubfx            x3, x3, #0, #0x20
    // 0x8af9f4: scvtf           d0, x3
    // 0x8af9f8: fdiv            d2, d0, d1
    // 0x8af9fc: ArrayStore: r1[0] = d2  ; List_8
    //     0x8af9fc: stur            d2, [x1, #0x17]
    // 0x8afa00: ldur            x2, [fp, #-0x38]
    // 0x8afa04: ubfx            x2, x2, #0, #0x20
    // 0x8afa08: and             w3, w2, #0xff
    // 0x8afa0c: ubfx            x3, x3, #0, #0x20
    // 0x8afa10: scvtf           d0, x3
    // 0x8afa14: fdiv            d2, d0, d1
    // 0x8afa18: StoreField: r1->field_1f = d2
    //     0x8afa18: stur            d2, [x1, #0x1f]
    // 0x8afa1c: r0 = LoadStaticField(0x1134)
    //     0x8afa1c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8afa20: ldr             x0, [x0, #0x2268]
    // 0x8afa24: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8afa28: cmp             w0, w16
    // 0x8afa2c: b.ne            #0x8afa3c
    // 0x8afa30: r2 = surfaceContainerHigh
    //     0x8afa30: add             x2, PP, #0x13, lsl #12  ; [pp+0x13040] Field <MaterialDynamicColors.surfaceContainerHigh>: static late final (offset: 0x1134)
    //     0x8afa34: ldr             x2, [x2, #0x40]
    // 0x8afa38: r0 = InitLateFinalStaticField()
    //     0x8afa38: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8afa3c: mov             x1, x0
    // 0x8afa40: ldur            x2, [fp, #-0x20]
    // 0x8afa44: r0 = getArgb()
    //     0x8afa44: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8afa48: stur            x0, [fp, #-0x38]
    // 0x8afa4c: asr             x1, x0, #0x18
    // 0x8afa50: asr             x2, x0, #0x10
    // 0x8afa54: stur            x2, [fp, #-0x30]
    // 0x8afa58: asr             x3, x0, #8
    // 0x8afa5c: stur            x3, [fp, #-0x28]
    // 0x8afa60: ubfx            x1, x1, #0, #0x20
    // 0x8afa64: and             w4, w1, #0xff
    // 0x8afa68: ubfx            x4, x4, #0, #0x20
    // 0x8afa6c: scvtf           d0, x4
    // 0x8afa70: d1 = 255.000000
    //     0x8afa70: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8afa74: fdiv            d2, d0, d1
    // 0x8afa78: r17 = -432
    //     0x8afa78: mov             x17, #-0x1b0
    // 0x8afa7c: str             d2, [fp, x17]
    // 0x8afa80: r0 = Color()
    //     0x8afa80: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8afa84: mov             x1, x0
    // 0x8afa88: r0 = Instance_ColorSpace
    //     0x8afa88: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8afa8c: ldr             x0, [x0, #0x298]
    // 0x8afa90: r17 = -336
    //     0x8afa90: mov             x17, #-0x150
    // 0x8afa94: str             x1, [fp, x17]
    // 0x8afa98: StoreField: r1->field_27 = r0
    //     0x8afa98: stur            w0, [x1, #0x27]
    // 0x8afa9c: r17 = -432
    //     0x8afa9c: mov             x17, #-0x1b0
    // 0x8afaa0: ldr             d0, [fp, x17]
    // 0x8afaa4: StoreField: r1->field_7 = d0
    //     0x8afaa4: stur            d0, [x1, #7]
    // 0x8afaa8: ldur            x2, [fp, #-0x30]
    // 0x8afaac: ubfx            x2, x2, #0, #0x20
    // 0x8afab0: and             w3, w2, #0xff
    // 0x8afab4: ubfx            x3, x3, #0, #0x20
    // 0x8afab8: scvtf           d0, x3
    // 0x8afabc: d1 = 255.000000
    //     0x8afabc: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8afac0: fdiv            d2, d0, d1
    // 0x8afac4: StoreField: r1->field_f = d2
    //     0x8afac4: stur            d2, [x1, #0xf]
    // 0x8afac8: ldur            x2, [fp, #-0x28]
    // 0x8afacc: ubfx            x2, x2, #0, #0x20
    // 0x8afad0: and             w3, w2, #0xff
    // 0x8afad4: ubfx            x3, x3, #0, #0x20
    // 0x8afad8: scvtf           d0, x3
    // 0x8afadc: fdiv            d2, d0, d1
    // 0x8afae0: ArrayStore: r1[0] = d2  ; List_8
    //     0x8afae0: stur            d2, [x1, #0x17]
    // 0x8afae4: ldur            x2, [fp, #-0x38]
    // 0x8afae8: ubfx            x2, x2, #0, #0x20
    // 0x8afaec: and             w3, w2, #0xff
    // 0x8afaf0: ubfx            x3, x3, #0, #0x20
    // 0x8afaf4: scvtf           d0, x3
    // 0x8afaf8: fdiv            d2, d0, d1
    // 0x8afafc: StoreField: r1->field_1f = d2
    //     0x8afafc: stur            d2, [x1, #0x1f]
    // 0x8afb00: r0 = LoadStaticField(0x1138)
    //     0x8afb00: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8afb04: ldr             x0, [x0, #0x2270]
    // 0x8afb08: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8afb0c: cmp             w0, w16
    // 0x8afb10: b.ne            #0x8afb20
    // 0x8afb14: r2 = surfaceContainerHighest
    //     0x8afb14: add             x2, PP, #0x13, lsl #12  ; [pp+0x13048] Field <MaterialDynamicColors.surfaceContainerHighest>: static late final (offset: 0x1138)
    //     0x8afb18: ldr             x2, [x2, #0x48]
    // 0x8afb1c: r0 = InitLateFinalStaticField()
    //     0x8afb1c: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8afb20: mov             x1, x0
    // 0x8afb24: ldur            x2, [fp, #-0x20]
    // 0x8afb28: r0 = getArgb()
    //     0x8afb28: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8afb2c: stur            x0, [fp, #-0x38]
    // 0x8afb30: asr             x1, x0, #0x18
    // 0x8afb34: asr             x2, x0, #0x10
    // 0x8afb38: stur            x2, [fp, #-0x30]
    // 0x8afb3c: asr             x3, x0, #8
    // 0x8afb40: stur            x3, [fp, #-0x28]
    // 0x8afb44: ubfx            x1, x1, #0, #0x20
    // 0x8afb48: and             w4, w1, #0xff
    // 0x8afb4c: ubfx            x4, x4, #0, #0x20
    // 0x8afb50: scvtf           d0, x4
    // 0x8afb54: d1 = 255.000000
    //     0x8afb54: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8afb58: fdiv            d2, d0, d1
    // 0x8afb5c: r17 = -432
    //     0x8afb5c: mov             x17, #-0x1b0
    // 0x8afb60: str             d2, [fp, x17]
    // 0x8afb64: r0 = Color()
    //     0x8afb64: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8afb68: mov             x1, x0
    // 0x8afb6c: r0 = Instance_ColorSpace
    //     0x8afb6c: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8afb70: ldr             x0, [x0, #0x298]
    // 0x8afb74: r17 = -344
    //     0x8afb74: mov             x17, #-0x158
    // 0x8afb78: str             x1, [fp, x17]
    // 0x8afb7c: StoreField: r1->field_27 = r0
    //     0x8afb7c: stur            w0, [x1, #0x27]
    // 0x8afb80: r17 = -432
    //     0x8afb80: mov             x17, #-0x1b0
    // 0x8afb84: ldr             d0, [fp, x17]
    // 0x8afb88: StoreField: r1->field_7 = d0
    //     0x8afb88: stur            d0, [x1, #7]
    // 0x8afb8c: ldur            x2, [fp, #-0x30]
    // 0x8afb90: ubfx            x2, x2, #0, #0x20
    // 0x8afb94: and             w3, w2, #0xff
    // 0x8afb98: ubfx            x3, x3, #0, #0x20
    // 0x8afb9c: scvtf           d0, x3
    // 0x8afba0: d1 = 255.000000
    //     0x8afba0: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8afba4: fdiv            d2, d0, d1
    // 0x8afba8: StoreField: r1->field_f = d2
    //     0x8afba8: stur            d2, [x1, #0xf]
    // 0x8afbac: ldur            x2, [fp, #-0x28]
    // 0x8afbb0: ubfx            x2, x2, #0, #0x20
    // 0x8afbb4: and             w3, w2, #0xff
    // 0x8afbb8: ubfx            x3, x3, #0, #0x20
    // 0x8afbbc: scvtf           d0, x3
    // 0x8afbc0: fdiv            d2, d0, d1
    // 0x8afbc4: ArrayStore: r1[0] = d2  ; List_8
    //     0x8afbc4: stur            d2, [x1, #0x17]
    // 0x8afbc8: ldur            x2, [fp, #-0x38]
    // 0x8afbcc: ubfx            x2, x2, #0, #0x20
    // 0x8afbd0: and             w3, w2, #0xff
    // 0x8afbd4: ubfx            x3, x3, #0, #0x20
    // 0x8afbd8: scvtf           d0, x3
    // 0x8afbdc: fdiv            d2, d0, d1
    // 0x8afbe0: StoreField: r1->field_1f = d2
    //     0x8afbe0: stur            d2, [x1, #0x1f]
    // 0x8afbe4: r0 = LoadStaticField(0x113c)
    //     0x8afbe4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8afbe8: ldr             x0, [x0, #0x2278]
    // 0x8afbec: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8afbf0: cmp             w0, w16
    // 0x8afbf4: b.ne            #0x8afc04
    // 0x8afbf8: r2 = onSurface
    //     0x8afbf8: add             x2, PP, #0x13, lsl #12  ; [pp+0x13050] Field <MaterialDynamicColors.onSurface>: static late final (offset: 0x113c)
    //     0x8afbfc: ldr             x2, [x2, #0x50]
    // 0x8afc00: r0 = InitLateFinalStaticField()
    //     0x8afc00: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8afc04: mov             x1, x0
    // 0x8afc08: ldur            x2, [fp, #-0x20]
    // 0x8afc0c: r0 = getArgb()
    //     0x8afc0c: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8afc10: stur            x0, [fp, #-0x38]
    // 0x8afc14: asr             x1, x0, #0x18
    // 0x8afc18: asr             x2, x0, #0x10
    // 0x8afc1c: stur            x2, [fp, #-0x30]
    // 0x8afc20: asr             x3, x0, #8
    // 0x8afc24: stur            x3, [fp, #-0x28]
    // 0x8afc28: ubfx            x1, x1, #0, #0x20
    // 0x8afc2c: and             w4, w1, #0xff
    // 0x8afc30: ubfx            x4, x4, #0, #0x20
    // 0x8afc34: scvtf           d0, x4
    // 0x8afc38: d1 = 255.000000
    //     0x8afc38: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8afc3c: fdiv            d2, d0, d1
    // 0x8afc40: r17 = -432
    //     0x8afc40: mov             x17, #-0x1b0
    // 0x8afc44: str             d2, [fp, x17]
    // 0x8afc48: r0 = Color()
    //     0x8afc48: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8afc4c: mov             x1, x0
    // 0x8afc50: r0 = Instance_ColorSpace
    //     0x8afc50: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8afc54: ldr             x0, [x0, #0x298]
    // 0x8afc58: r17 = -352
    //     0x8afc58: mov             x17, #-0x160
    // 0x8afc5c: str             x1, [fp, x17]
    // 0x8afc60: StoreField: r1->field_27 = r0
    //     0x8afc60: stur            w0, [x1, #0x27]
    // 0x8afc64: r17 = -432
    //     0x8afc64: mov             x17, #-0x1b0
    // 0x8afc68: ldr             d0, [fp, x17]
    // 0x8afc6c: StoreField: r1->field_7 = d0
    //     0x8afc6c: stur            d0, [x1, #7]
    // 0x8afc70: ldur            x2, [fp, #-0x30]
    // 0x8afc74: ubfx            x2, x2, #0, #0x20
    // 0x8afc78: and             w3, w2, #0xff
    // 0x8afc7c: ubfx            x3, x3, #0, #0x20
    // 0x8afc80: scvtf           d0, x3
    // 0x8afc84: d1 = 255.000000
    //     0x8afc84: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8afc88: fdiv            d2, d0, d1
    // 0x8afc8c: StoreField: r1->field_f = d2
    //     0x8afc8c: stur            d2, [x1, #0xf]
    // 0x8afc90: ldur            x2, [fp, #-0x28]
    // 0x8afc94: ubfx            x2, x2, #0, #0x20
    // 0x8afc98: and             w3, w2, #0xff
    // 0x8afc9c: ubfx            x3, x3, #0, #0x20
    // 0x8afca0: scvtf           d0, x3
    // 0x8afca4: fdiv            d2, d0, d1
    // 0x8afca8: ArrayStore: r1[0] = d2  ; List_8
    //     0x8afca8: stur            d2, [x1, #0x17]
    // 0x8afcac: ldur            x2, [fp, #-0x38]
    // 0x8afcb0: ubfx            x2, x2, #0, #0x20
    // 0x8afcb4: and             w3, w2, #0xff
    // 0x8afcb8: ubfx            x3, x3, #0, #0x20
    // 0x8afcbc: scvtf           d0, x3
    // 0x8afcc0: fdiv            d2, d0, d1
    // 0x8afcc4: StoreField: r1->field_1f = d2
    //     0x8afcc4: stur            d2, [x1, #0x1f]
    // 0x8afcc8: r0 = LoadStaticField(0x1144)
    //     0x8afcc8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8afccc: ldr             x0, [x0, #0x2288]
    // 0x8afcd0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8afcd4: cmp             w0, w16
    // 0x8afcd8: b.ne            #0x8afce8
    // 0x8afcdc: r2 = onSurfaceVariant
    //     0x8afcdc: add             x2, PP, #0x13, lsl #12  ; [pp+0x13058] Field <MaterialDynamicColors.onSurfaceVariant>: static late final (offset: 0x1144)
    //     0x8afce0: ldr             x2, [x2, #0x58]
    // 0x8afce4: r0 = InitLateFinalStaticField()
    //     0x8afce4: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8afce8: mov             x1, x0
    // 0x8afcec: ldur            x2, [fp, #-0x20]
    // 0x8afcf0: r0 = getArgb()
    //     0x8afcf0: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8afcf4: stur            x0, [fp, #-0x38]
    // 0x8afcf8: asr             x1, x0, #0x18
    // 0x8afcfc: asr             x2, x0, #0x10
    // 0x8afd00: stur            x2, [fp, #-0x30]
    // 0x8afd04: asr             x3, x0, #8
    // 0x8afd08: stur            x3, [fp, #-0x28]
    // 0x8afd0c: ubfx            x1, x1, #0, #0x20
    // 0x8afd10: and             w4, w1, #0xff
    // 0x8afd14: ubfx            x4, x4, #0, #0x20
    // 0x8afd18: scvtf           d0, x4
    // 0x8afd1c: d1 = 255.000000
    //     0x8afd1c: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8afd20: fdiv            d2, d0, d1
    // 0x8afd24: r17 = -432
    //     0x8afd24: mov             x17, #-0x1b0
    // 0x8afd28: str             d2, [fp, x17]
    // 0x8afd2c: r0 = Color()
    //     0x8afd2c: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8afd30: mov             x1, x0
    // 0x8afd34: r0 = Instance_ColorSpace
    //     0x8afd34: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8afd38: ldr             x0, [x0, #0x298]
    // 0x8afd3c: r17 = -360
    //     0x8afd3c: mov             x17, #-0x168
    // 0x8afd40: str             x1, [fp, x17]
    // 0x8afd44: StoreField: r1->field_27 = r0
    //     0x8afd44: stur            w0, [x1, #0x27]
    // 0x8afd48: r17 = -432
    //     0x8afd48: mov             x17, #-0x1b0
    // 0x8afd4c: ldr             d0, [fp, x17]
    // 0x8afd50: StoreField: r1->field_7 = d0
    //     0x8afd50: stur            d0, [x1, #7]
    // 0x8afd54: ldur            x2, [fp, #-0x30]
    // 0x8afd58: ubfx            x2, x2, #0, #0x20
    // 0x8afd5c: and             w3, w2, #0xff
    // 0x8afd60: ubfx            x3, x3, #0, #0x20
    // 0x8afd64: scvtf           d0, x3
    // 0x8afd68: d1 = 255.000000
    //     0x8afd68: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8afd6c: fdiv            d2, d0, d1
    // 0x8afd70: StoreField: r1->field_f = d2
    //     0x8afd70: stur            d2, [x1, #0xf]
    // 0x8afd74: ldur            x2, [fp, #-0x28]
    // 0x8afd78: ubfx            x2, x2, #0, #0x20
    // 0x8afd7c: and             w3, w2, #0xff
    // 0x8afd80: ubfx            x3, x3, #0, #0x20
    // 0x8afd84: scvtf           d0, x3
    // 0x8afd88: fdiv            d2, d0, d1
    // 0x8afd8c: ArrayStore: r1[0] = d2  ; List_8
    //     0x8afd8c: stur            d2, [x1, #0x17]
    // 0x8afd90: ldur            x2, [fp, #-0x38]
    // 0x8afd94: ubfx            x2, x2, #0, #0x20
    // 0x8afd98: and             w3, w2, #0xff
    // 0x8afd9c: ubfx            x3, x3, #0, #0x20
    // 0x8afda0: scvtf           d0, x3
    // 0x8afda4: fdiv            d2, d0, d1
    // 0x8afda8: StoreField: r1->field_1f = d2
    //     0x8afda8: stur            d2, [x1, #0x1f]
    // 0x8afdac: r0 = LoadStaticField(0x1148)
    //     0x8afdac: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8afdb0: ldr             x0, [x0, #0x2290]
    // 0x8afdb4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8afdb8: cmp             w0, w16
    // 0x8afdbc: b.ne            #0x8afdcc
    // 0x8afdc0: r2 = inverseSurface
    //     0x8afdc0: add             x2, PP, #0x13, lsl #12  ; [pp+0x13060] Field <MaterialDynamicColors.inverseSurface>: static late final (offset: 0x1148)
    //     0x8afdc4: ldr             x2, [x2, #0x60]
    // 0x8afdc8: r0 = InitLateFinalStaticField()
    //     0x8afdc8: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8afdcc: mov             x1, x0
    // 0x8afdd0: ldur            x2, [fp, #-0x20]
    // 0x8afdd4: r0 = getArgb()
    //     0x8afdd4: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8afdd8: stur            x0, [fp, #-0x38]
    // 0x8afddc: asr             x1, x0, #0x18
    // 0x8afde0: asr             x2, x0, #0x10
    // 0x8afde4: stur            x2, [fp, #-0x30]
    // 0x8afde8: asr             x3, x0, #8
    // 0x8afdec: stur            x3, [fp, #-0x28]
    // 0x8afdf0: ubfx            x1, x1, #0, #0x20
    // 0x8afdf4: and             w4, w1, #0xff
    // 0x8afdf8: ubfx            x4, x4, #0, #0x20
    // 0x8afdfc: scvtf           d0, x4
    // 0x8afe00: d1 = 255.000000
    //     0x8afe00: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8afe04: fdiv            d2, d0, d1
    // 0x8afe08: r17 = -432
    //     0x8afe08: mov             x17, #-0x1b0
    // 0x8afe0c: str             d2, [fp, x17]
    // 0x8afe10: r0 = Color()
    //     0x8afe10: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8afe14: mov             x1, x0
    // 0x8afe18: r0 = Instance_ColorSpace
    //     0x8afe18: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8afe1c: ldr             x0, [x0, #0x298]
    // 0x8afe20: r17 = -368
    //     0x8afe20: mov             x17, #-0x170
    // 0x8afe24: str             x1, [fp, x17]
    // 0x8afe28: StoreField: r1->field_27 = r0
    //     0x8afe28: stur            w0, [x1, #0x27]
    // 0x8afe2c: r17 = -432
    //     0x8afe2c: mov             x17, #-0x1b0
    // 0x8afe30: ldr             d0, [fp, x17]
    // 0x8afe34: StoreField: r1->field_7 = d0
    //     0x8afe34: stur            d0, [x1, #7]
    // 0x8afe38: ldur            x2, [fp, #-0x30]
    // 0x8afe3c: ubfx            x2, x2, #0, #0x20
    // 0x8afe40: and             w3, w2, #0xff
    // 0x8afe44: ubfx            x3, x3, #0, #0x20
    // 0x8afe48: scvtf           d0, x3
    // 0x8afe4c: d1 = 255.000000
    //     0x8afe4c: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8afe50: fdiv            d2, d0, d1
    // 0x8afe54: StoreField: r1->field_f = d2
    //     0x8afe54: stur            d2, [x1, #0xf]
    // 0x8afe58: ldur            x2, [fp, #-0x28]
    // 0x8afe5c: ubfx            x2, x2, #0, #0x20
    // 0x8afe60: and             w3, w2, #0xff
    // 0x8afe64: ubfx            x3, x3, #0, #0x20
    // 0x8afe68: scvtf           d0, x3
    // 0x8afe6c: fdiv            d2, d0, d1
    // 0x8afe70: ArrayStore: r1[0] = d2  ; List_8
    //     0x8afe70: stur            d2, [x1, #0x17]
    // 0x8afe74: ldur            x2, [fp, #-0x38]
    // 0x8afe78: ubfx            x2, x2, #0, #0x20
    // 0x8afe7c: and             w3, w2, #0xff
    // 0x8afe80: ubfx            x3, x3, #0, #0x20
    // 0x8afe84: scvtf           d0, x3
    // 0x8afe88: fdiv            d2, d0, d1
    // 0x8afe8c: StoreField: r1->field_1f = d2
    //     0x8afe8c: stur            d2, [x1, #0x1f]
    // 0x8afe90: r0 = LoadStaticField(0x114c)
    //     0x8afe90: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8afe94: ldr             x0, [x0, #0x2298]
    // 0x8afe98: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8afe9c: cmp             w0, w16
    // 0x8afea0: b.ne            #0x8afeb0
    // 0x8afea4: r2 = inverseOnSurface
    //     0x8afea4: add             x2, PP, #0x13, lsl #12  ; [pp+0x13068] Field <MaterialDynamicColors.inverseOnSurface>: static late final (offset: 0x114c)
    //     0x8afea8: ldr             x2, [x2, #0x68]
    // 0x8afeac: r0 = InitLateFinalStaticField()
    //     0x8afeac: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8afeb0: mov             x1, x0
    // 0x8afeb4: ldur            x2, [fp, #-0x20]
    // 0x8afeb8: r0 = getArgb()
    //     0x8afeb8: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8afebc: stur            x0, [fp, #-0x38]
    // 0x8afec0: asr             x1, x0, #0x18
    // 0x8afec4: asr             x2, x0, #0x10
    // 0x8afec8: stur            x2, [fp, #-0x30]
    // 0x8afecc: asr             x3, x0, #8
    // 0x8afed0: stur            x3, [fp, #-0x28]
    // 0x8afed4: ubfx            x1, x1, #0, #0x20
    // 0x8afed8: and             w4, w1, #0xff
    // 0x8afedc: ubfx            x4, x4, #0, #0x20
    // 0x8afee0: scvtf           d0, x4
    // 0x8afee4: d1 = 255.000000
    //     0x8afee4: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8afee8: fdiv            d2, d0, d1
    // 0x8afeec: r17 = -432
    //     0x8afeec: mov             x17, #-0x1b0
    // 0x8afef0: str             d2, [fp, x17]
    // 0x8afef4: r0 = Color()
    //     0x8afef4: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8afef8: mov             x1, x0
    // 0x8afefc: r0 = Instance_ColorSpace
    //     0x8afefc: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8aff00: ldr             x0, [x0, #0x298]
    // 0x8aff04: r17 = -376
    //     0x8aff04: mov             x17, #-0x178
    // 0x8aff08: str             x1, [fp, x17]
    // 0x8aff0c: StoreField: r1->field_27 = r0
    //     0x8aff0c: stur            w0, [x1, #0x27]
    // 0x8aff10: r17 = -432
    //     0x8aff10: mov             x17, #-0x1b0
    // 0x8aff14: ldr             d0, [fp, x17]
    // 0x8aff18: StoreField: r1->field_7 = d0
    //     0x8aff18: stur            d0, [x1, #7]
    // 0x8aff1c: ldur            x2, [fp, #-0x30]
    // 0x8aff20: ubfx            x2, x2, #0, #0x20
    // 0x8aff24: and             w3, w2, #0xff
    // 0x8aff28: ubfx            x3, x3, #0, #0x20
    // 0x8aff2c: scvtf           d0, x3
    // 0x8aff30: d1 = 255.000000
    //     0x8aff30: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8aff34: fdiv            d2, d0, d1
    // 0x8aff38: StoreField: r1->field_f = d2
    //     0x8aff38: stur            d2, [x1, #0xf]
    // 0x8aff3c: ldur            x2, [fp, #-0x28]
    // 0x8aff40: ubfx            x2, x2, #0, #0x20
    // 0x8aff44: and             w3, w2, #0xff
    // 0x8aff48: ubfx            x3, x3, #0, #0x20
    // 0x8aff4c: scvtf           d0, x3
    // 0x8aff50: fdiv            d2, d0, d1
    // 0x8aff54: ArrayStore: r1[0] = d2  ; List_8
    //     0x8aff54: stur            d2, [x1, #0x17]
    // 0x8aff58: ldur            x2, [fp, #-0x38]
    // 0x8aff5c: ubfx            x2, x2, #0, #0x20
    // 0x8aff60: and             w3, w2, #0xff
    // 0x8aff64: ubfx            x3, x3, #0, #0x20
    // 0x8aff68: scvtf           d0, x3
    // 0x8aff6c: fdiv            d2, d0, d1
    // 0x8aff70: StoreField: r1->field_1f = d2
    //     0x8aff70: stur            d2, [x1, #0x1f]
    // 0x8aff74: r0 = LoadStaticField(0x1170)
    //     0x8aff74: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8aff78: ldr             x0, [x0, #0x22e0]
    // 0x8aff7c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8aff80: cmp             w0, w16
    // 0x8aff84: b.ne            #0x8aff94
    // 0x8aff88: r2 = inversePrimary
    //     0x8aff88: add             x2, PP, #0x13, lsl #12  ; [pp+0x13070] Field <MaterialDynamicColors.inversePrimary>: static late final (offset: 0x1170)
    //     0x8aff8c: ldr             x2, [x2, #0x70]
    // 0x8aff90: r0 = InitLateFinalStaticField()
    //     0x8aff90: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8aff94: mov             x1, x0
    // 0x8aff98: ldur            x2, [fp, #-0x20]
    // 0x8aff9c: r0 = getArgb()
    //     0x8aff9c: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8affa0: stur            x0, [fp, #-0x38]
    // 0x8affa4: asr             x1, x0, #0x18
    // 0x8affa8: asr             x2, x0, #0x10
    // 0x8affac: stur            x2, [fp, #-0x30]
    // 0x8affb0: asr             x3, x0, #8
    // 0x8affb4: stur            x3, [fp, #-0x28]
    // 0x8affb8: ubfx            x1, x1, #0, #0x20
    // 0x8affbc: and             w4, w1, #0xff
    // 0x8affc0: ubfx            x4, x4, #0, #0x20
    // 0x8affc4: scvtf           d0, x4
    // 0x8affc8: d1 = 255.000000
    //     0x8affc8: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8affcc: fdiv            d2, d0, d1
    // 0x8affd0: r17 = -432
    //     0x8affd0: mov             x17, #-0x1b0
    // 0x8affd4: str             d2, [fp, x17]
    // 0x8affd8: r0 = Color()
    //     0x8affd8: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8affdc: mov             x1, x0
    // 0x8affe0: r0 = Instance_ColorSpace
    //     0x8affe0: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8affe4: ldr             x0, [x0, #0x298]
    // 0x8affe8: r17 = -384
    //     0x8affe8: mov             x17, #-0x180
    // 0x8affec: str             x1, [fp, x17]
    // 0x8afff0: StoreField: r1->field_27 = r0
    //     0x8afff0: stur            w0, [x1, #0x27]
    // 0x8afff4: r17 = -432
    //     0x8afff4: mov             x17, #-0x1b0
    // 0x8afff8: ldr             d0, [fp, x17]
    // 0x8afffc: StoreField: r1->field_7 = d0
    //     0x8afffc: stur            d0, [x1, #7]
    // 0x8b0000: ldur            x2, [fp, #-0x30]
    // 0x8b0004: ubfx            x2, x2, #0, #0x20
    // 0x8b0008: and             w3, w2, #0xff
    // 0x8b000c: ubfx            x3, x3, #0, #0x20
    // 0x8b0010: scvtf           d0, x3
    // 0x8b0014: d1 = 255.000000
    //     0x8b0014: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8b0018: fdiv            d2, d0, d1
    // 0x8b001c: StoreField: r1->field_f = d2
    //     0x8b001c: stur            d2, [x1, #0xf]
    // 0x8b0020: ldur            x2, [fp, #-0x28]
    // 0x8b0024: ubfx            x2, x2, #0, #0x20
    // 0x8b0028: and             w3, w2, #0xff
    // 0x8b002c: ubfx            x3, x3, #0, #0x20
    // 0x8b0030: scvtf           d0, x3
    // 0x8b0034: fdiv            d2, d0, d1
    // 0x8b0038: ArrayStore: r1[0] = d2  ; List_8
    //     0x8b0038: stur            d2, [x1, #0x17]
    // 0x8b003c: ldur            x2, [fp, #-0x38]
    // 0x8b0040: ubfx            x2, x2, #0, #0x20
    // 0x8b0044: and             w3, w2, #0xff
    // 0x8b0048: ubfx            x3, x3, #0, #0x20
    // 0x8b004c: scvtf           d0, x3
    // 0x8b0050: fdiv            d2, d0, d1
    // 0x8b0054: StoreField: r1->field_1f = d2
    //     0x8b0054: stur            d2, [x1, #0x1f]
    // 0x8b0058: r0 = LoadStaticField(0x1158)
    //     0x8b0058: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8b005c: ldr             x0, [x0, #0x22b0]
    // 0x8b0060: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8b0064: cmp             w0, w16
    // 0x8b0068: b.ne            #0x8b0078
    // 0x8b006c: r2 = shadow
    //     0x8b006c: add             x2, PP, #0x13, lsl #12  ; [pp+0x13078] Field <MaterialDynamicColors.shadow>: static late final (offset: 0x1158)
    //     0x8b0070: ldr             x2, [x2, #0x78]
    // 0x8b0074: r0 = InitLateFinalStaticField()
    //     0x8b0074: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8b0078: mov             x1, x0
    // 0x8b007c: ldur            x2, [fp, #-0x20]
    // 0x8b0080: r0 = getArgb()
    //     0x8b0080: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8b0084: stur            x0, [fp, #-0x38]
    // 0x8b0088: asr             x1, x0, #0x18
    // 0x8b008c: asr             x2, x0, #0x10
    // 0x8b0090: stur            x2, [fp, #-0x30]
    // 0x8b0094: asr             x3, x0, #8
    // 0x8b0098: stur            x3, [fp, #-0x28]
    // 0x8b009c: ubfx            x1, x1, #0, #0x20
    // 0x8b00a0: and             w4, w1, #0xff
    // 0x8b00a4: ubfx            x4, x4, #0, #0x20
    // 0x8b00a8: scvtf           d0, x4
    // 0x8b00ac: d1 = 255.000000
    //     0x8b00ac: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8b00b0: fdiv            d2, d0, d1
    // 0x8b00b4: r17 = -432
    //     0x8b00b4: mov             x17, #-0x1b0
    // 0x8b00b8: str             d2, [fp, x17]
    // 0x8b00bc: r0 = Color()
    //     0x8b00bc: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b00c0: mov             x1, x0
    // 0x8b00c4: r0 = Instance_ColorSpace
    //     0x8b00c4: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8b00c8: ldr             x0, [x0, #0x298]
    // 0x8b00cc: r17 = -392
    //     0x8b00cc: mov             x17, #-0x188
    // 0x8b00d0: str             x1, [fp, x17]
    // 0x8b00d4: StoreField: r1->field_27 = r0
    //     0x8b00d4: stur            w0, [x1, #0x27]
    // 0x8b00d8: r17 = -432
    //     0x8b00d8: mov             x17, #-0x1b0
    // 0x8b00dc: ldr             d0, [fp, x17]
    // 0x8b00e0: StoreField: r1->field_7 = d0
    //     0x8b00e0: stur            d0, [x1, #7]
    // 0x8b00e4: ldur            x2, [fp, #-0x30]
    // 0x8b00e8: ubfx            x2, x2, #0, #0x20
    // 0x8b00ec: and             w3, w2, #0xff
    // 0x8b00f0: ubfx            x3, x3, #0, #0x20
    // 0x8b00f4: scvtf           d0, x3
    // 0x8b00f8: d1 = 255.000000
    //     0x8b00f8: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8b00fc: fdiv            d2, d0, d1
    // 0x8b0100: StoreField: r1->field_f = d2
    //     0x8b0100: stur            d2, [x1, #0xf]
    // 0x8b0104: ldur            x2, [fp, #-0x28]
    // 0x8b0108: ubfx            x2, x2, #0, #0x20
    // 0x8b010c: and             w3, w2, #0xff
    // 0x8b0110: ubfx            x3, x3, #0, #0x20
    // 0x8b0114: scvtf           d0, x3
    // 0x8b0118: fdiv            d2, d0, d1
    // 0x8b011c: ArrayStore: r1[0] = d2  ; List_8
    //     0x8b011c: stur            d2, [x1, #0x17]
    // 0x8b0120: ldur            x2, [fp, #-0x38]
    // 0x8b0124: ubfx            x2, x2, #0, #0x20
    // 0x8b0128: and             w3, w2, #0xff
    // 0x8b012c: ubfx            x3, x3, #0, #0x20
    // 0x8b0130: scvtf           d0, x3
    // 0x8b0134: fdiv            d2, d0, d1
    // 0x8b0138: StoreField: r1->field_1f = d2
    //     0x8b0138: stur            d2, [x1, #0x1f]
    // 0x8b013c: r0 = LoadStaticField(0x115c)
    //     0x8b013c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8b0140: ldr             x0, [x0, #0x22b8]
    // 0x8b0144: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8b0148: cmp             w0, w16
    // 0x8b014c: b.ne            #0x8b015c
    // 0x8b0150: r2 = scrim
    //     0x8b0150: add             x2, PP, #0x13, lsl #12  ; [pp+0x13080] Field <MaterialDynamicColors.scrim>: static late final (offset: 0x115c)
    //     0x8b0154: ldr             x2, [x2, #0x80]
    // 0x8b0158: r0 = InitLateFinalStaticField()
    //     0x8b0158: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8b015c: mov             x1, x0
    // 0x8b0160: ldur            x2, [fp, #-0x20]
    // 0x8b0164: r0 = getArgb()
    //     0x8b0164: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8b0168: stur            x0, [fp, #-0x38]
    // 0x8b016c: asr             x1, x0, #0x18
    // 0x8b0170: asr             x2, x0, #0x10
    // 0x8b0174: stur            x2, [fp, #-0x30]
    // 0x8b0178: asr             x3, x0, #8
    // 0x8b017c: stur            x3, [fp, #-0x28]
    // 0x8b0180: ubfx            x1, x1, #0, #0x20
    // 0x8b0184: and             w4, w1, #0xff
    // 0x8b0188: ubfx            x4, x4, #0, #0x20
    // 0x8b018c: scvtf           d0, x4
    // 0x8b0190: d1 = 255.000000
    //     0x8b0190: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8b0194: fdiv            d2, d0, d1
    // 0x8b0198: r17 = -432
    //     0x8b0198: mov             x17, #-0x1b0
    // 0x8b019c: str             d2, [fp, x17]
    // 0x8b01a0: r0 = Color()
    //     0x8b01a0: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b01a4: mov             x1, x0
    // 0x8b01a8: r0 = Instance_ColorSpace
    //     0x8b01a8: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8b01ac: ldr             x0, [x0, #0x298]
    // 0x8b01b0: r17 = -400
    //     0x8b01b0: mov             x17, #-0x190
    // 0x8b01b4: str             x1, [fp, x17]
    // 0x8b01b8: StoreField: r1->field_27 = r0
    //     0x8b01b8: stur            w0, [x1, #0x27]
    // 0x8b01bc: r17 = -432
    //     0x8b01bc: mov             x17, #-0x1b0
    // 0x8b01c0: ldr             d0, [fp, x17]
    // 0x8b01c4: StoreField: r1->field_7 = d0
    //     0x8b01c4: stur            d0, [x1, #7]
    // 0x8b01c8: ldur            x2, [fp, #-0x30]
    // 0x8b01cc: ubfx            x2, x2, #0, #0x20
    // 0x8b01d0: and             w3, w2, #0xff
    // 0x8b01d4: ubfx            x3, x3, #0, #0x20
    // 0x8b01d8: scvtf           d0, x3
    // 0x8b01dc: d1 = 255.000000
    //     0x8b01dc: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8b01e0: fdiv            d2, d0, d1
    // 0x8b01e4: StoreField: r1->field_f = d2
    //     0x8b01e4: stur            d2, [x1, #0xf]
    // 0x8b01e8: ldur            x2, [fp, #-0x28]
    // 0x8b01ec: ubfx            x2, x2, #0, #0x20
    // 0x8b01f0: and             w3, w2, #0xff
    // 0x8b01f4: ubfx            x3, x3, #0, #0x20
    // 0x8b01f8: scvtf           d0, x3
    // 0x8b01fc: fdiv            d2, d0, d1
    // 0x8b0200: ArrayStore: r1[0] = d2  ; List_8
    //     0x8b0200: stur            d2, [x1, #0x17]
    // 0x8b0204: ldur            x2, [fp, #-0x38]
    // 0x8b0208: ubfx            x2, x2, #0, #0x20
    // 0x8b020c: and             w3, w2, #0xff
    // 0x8b0210: ubfx            x3, x3, #0, #0x20
    // 0x8b0214: scvtf           d0, x3
    // 0x8b0218: fdiv            d2, d0, d1
    // 0x8b021c: StoreField: r1->field_1f = d2
    //     0x8b021c: stur            d2, [x1, #0x1f]
    // 0x8b0220: r0 = LoadStaticField(0x1160)
    //     0x8b0220: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8b0224: ldr             x0, [x0, #0x22c0]
    // 0x8b0228: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8b022c: cmp             w0, w16
    // 0x8b0230: b.ne            #0x8b0240
    // 0x8b0234: r2 = primary
    //     0x8b0234: add             x2, PP, #0x12, lsl #12  ; [pp+0x12f20] Field <MaterialDynamicColors.primary>: static late final (offset: 0x1160)
    //     0x8b0238: ldr             x2, [x2, #0xf20]
    // 0x8b023c: r0 = InitLateFinalStaticField()
    //     0x8b023c: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8b0240: mov             x1, x0
    // 0x8b0244: ldur            x2, [fp, #-0x20]
    // 0x8b0248: r0 = getArgb()
    //     0x8b0248: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8b024c: stur            x0, [fp, #-0x38]
    // 0x8b0250: asr             x1, x0, #0x18
    // 0x8b0254: asr             x2, x0, #0x10
    // 0x8b0258: stur            x2, [fp, #-0x30]
    // 0x8b025c: asr             x3, x0, #8
    // 0x8b0260: stur            x3, [fp, #-0x28]
    // 0x8b0264: ubfx            x1, x1, #0, #0x20
    // 0x8b0268: and             w4, w1, #0xff
    // 0x8b026c: ubfx            x4, x4, #0, #0x20
    // 0x8b0270: scvtf           d0, x4
    // 0x8b0274: d1 = 255.000000
    //     0x8b0274: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8b0278: fdiv            d2, d0, d1
    // 0x8b027c: r17 = -432
    //     0x8b027c: mov             x17, #-0x1b0
    // 0x8b0280: str             d2, [fp, x17]
    // 0x8b0284: r0 = Color()
    //     0x8b0284: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b0288: mov             x1, x0
    // 0x8b028c: r0 = Instance_ColorSpace
    //     0x8b028c: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8b0290: ldr             x0, [x0, #0x298]
    // 0x8b0294: r17 = -408
    //     0x8b0294: mov             x17, #-0x198
    // 0x8b0298: str             x1, [fp, x17]
    // 0x8b029c: StoreField: r1->field_27 = r0
    //     0x8b029c: stur            w0, [x1, #0x27]
    // 0x8b02a0: r17 = -432
    //     0x8b02a0: mov             x17, #-0x1b0
    // 0x8b02a4: ldr             d0, [fp, x17]
    // 0x8b02a8: StoreField: r1->field_7 = d0
    //     0x8b02a8: stur            d0, [x1, #7]
    // 0x8b02ac: ldur            x2, [fp, #-0x30]
    // 0x8b02b0: ubfx            x2, x2, #0, #0x20
    // 0x8b02b4: and             w3, w2, #0xff
    // 0x8b02b8: ubfx            x3, x3, #0, #0x20
    // 0x8b02bc: scvtf           d0, x3
    // 0x8b02c0: d1 = 255.000000
    //     0x8b02c0: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8b02c4: fdiv            d2, d0, d1
    // 0x8b02c8: StoreField: r1->field_f = d2
    //     0x8b02c8: stur            d2, [x1, #0xf]
    // 0x8b02cc: ldur            x2, [fp, #-0x28]
    // 0x8b02d0: ubfx            x2, x2, #0, #0x20
    // 0x8b02d4: and             w3, w2, #0xff
    // 0x8b02d8: ubfx            x3, x3, #0, #0x20
    // 0x8b02dc: scvtf           d0, x3
    // 0x8b02e0: fdiv            d2, d0, d1
    // 0x8b02e4: ArrayStore: r1[0] = d2  ; List_8
    //     0x8b02e4: stur            d2, [x1, #0x17]
    // 0x8b02e8: ldur            x2, [fp, #-0x38]
    // 0x8b02ec: ubfx            x2, x2, #0, #0x20
    // 0x8b02f0: and             w3, w2, #0xff
    // 0x8b02f4: ubfx            x3, x3, #0, #0x20
    // 0x8b02f8: scvtf           d0, x3
    // 0x8b02fc: fdiv            d2, d0, d1
    // 0x8b0300: StoreField: r1->field_1f = d2
    //     0x8b0300: stur            d2, [x1, #0x1f]
    // 0x8b0304: r0 = LoadStaticField(0x1114)
    //     0x8b0304: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8b0308: ldr             x0, [x0, #0x2228]
    // 0x8b030c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8b0310: cmp             w0, w16
    // 0x8b0314: b.ne            #0x8b0324
    // 0x8b0318: r2 = background
    //     0x8b0318: add             x2, PP, #0x13, lsl #12  ; [pp+0x13088] Field <MaterialDynamicColors.background>: static late final (offset: 0x1114)
    //     0x8b031c: ldr             x2, [x2, #0x88]
    // 0x8b0320: r0 = InitLateFinalStaticField()
    //     0x8b0320: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8b0324: mov             x1, x0
    // 0x8b0328: ldur            x2, [fp, #-0x20]
    // 0x8b032c: r0 = getArgb()
    //     0x8b032c: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8b0330: stur            x0, [fp, #-0x38]
    // 0x8b0334: asr             x1, x0, #0x18
    // 0x8b0338: asr             x2, x0, #0x10
    // 0x8b033c: stur            x2, [fp, #-0x30]
    // 0x8b0340: asr             x3, x0, #8
    // 0x8b0344: stur            x3, [fp, #-0x28]
    // 0x8b0348: ubfx            x1, x1, #0, #0x20
    // 0x8b034c: and             w4, w1, #0xff
    // 0x8b0350: ubfx            x4, x4, #0, #0x20
    // 0x8b0354: scvtf           d0, x4
    // 0x8b0358: d1 = 255.000000
    //     0x8b0358: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8b035c: fdiv            d2, d0, d1
    // 0x8b0360: r17 = -432
    //     0x8b0360: mov             x17, #-0x1b0
    // 0x8b0364: str             d2, [fp, x17]
    // 0x8b0368: r0 = Color()
    //     0x8b0368: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b036c: mov             x1, x0
    // 0x8b0370: r0 = Instance_ColorSpace
    //     0x8b0370: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8b0374: ldr             x0, [x0, #0x298]
    // 0x8b0378: r17 = -416
    //     0x8b0378: mov             x17, #-0x1a0
    // 0x8b037c: str             x1, [fp, x17]
    // 0x8b0380: StoreField: r1->field_27 = r0
    //     0x8b0380: stur            w0, [x1, #0x27]
    // 0x8b0384: r17 = -432
    //     0x8b0384: mov             x17, #-0x1b0
    // 0x8b0388: ldr             d0, [fp, x17]
    // 0x8b038c: StoreField: r1->field_7 = d0
    //     0x8b038c: stur            d0, [x1, #7]
    // 0x8b0390: ldur            x2, [fp, #-0x30]
    // 0x8b0394: ubfx            x2, x2, #0, #0x20
    // 0x8b0398: and             w3, w2, #0xff
    // 0x8b039c: ubfx            x3, x3, #0, #0x20
    // 0x8b03a0: scvtf           d0, x3
    // 0x8b03a4: d1 = 255.000000
    //     0x8b03a4: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8b03a8: fdiv            d2, d0, d1
    // 0x8b03ac: StoreField: r1->field_f = d2
    //     0x8b03ac: stur            d2, [x1, #0xf]
    // 0x8b03b0: ldur            x2, [fp, #-0x28]
    // 0x8b03b4: ubfx            x2, x2, #0, #0x20
    // 0x8b03b8: and             w3, w2, #0xff
    // 0x8b03bc: ubfx            x3, x3, #0, #0x20
    // 0x8b03c0: scvtf           d0, x3
    // 0x8b03c4: fdiv            d2, d0, d1
    // 0x8b03c8: ArrayStore: r1[0] = d2  ; List_8
    //     0x8b03c8: stur            d2, [x1, #0x17]
    // 0x8b03cc: ldur            x2, [fp, #-0x38]
    // 0x8b03d0: ubfx            x2, x2, #0, #0x20
    // 0x8b03d4: and             w3, w2, #0xff
    // 0x8b03d8: ubfx            x3, x3, #0, #0x20
    // 0x8b03dc: scvtf           d0, x3
    // 0x8b03e0: fdiv            d2, d0, d1
    // 0x8b03e4: StoreField: r1->field_1f = d2
    //     0x8b03e4: stur            d2, [x1, #0x1f]
    // 0x8b03e8: r0 = LoadStaticField(0x1118)
    //     0x8b03e8: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8b03ec: ldr             x0, [x0, #0x2230]
    // 0x8b03f0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8b03f4: cmp             w0, w16
    // 0x8b03f8: b.ne            #0x8b0408
    // 0x8b03fc: r2 = onBackground
    //     0x8b03fc: add             x2, PP, #0x13, lsl #12  ; [pp+0x13090] Field <MaterialDynamicColors.onBackground>: static late final (offset: 0x1118)
    //     0x8b0400: ldr             x2, [x2, #0x90]
    // 0x8b0404: r0 = InitLateFinalStaticField()
    //     0x8b0404: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8b0408: mov             x1, x0
    // 0x8b040c: ldur            x2, [fp, #-0x20]
    // 0x8b0410: r0 = getArgb()
    //     0x8b0410: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8b0414: stur            x0, [fp, #-0x38]
    // 0x8b0418: asr             x1, x0, #0x18
    // 0x8b041c: asr             x2, x0, #0x10
    // 0x8b0420: stur            x2, [fp, #-0x30]
    // 0x8b0424: asr             x3, x0, #8
    // 0x8b0428: stur            x3, [fp, #-0x28]
    // 0x8b042c: ubfx            x1, x1, #0, #0x20
    // 0x8b0430: and             w4, w1, #0xff
    // 0x8b0434: ubfx            x4, x4, #0, #0x20
    // 0x8b0438: scvtf           d0, x4
    // 0x8b043c: d1 = 255.000000
    //     0x8b043c: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8b0440: fdiv            d2, d0, d1
    // 0x8b0444: r17 = -432
    //     0x8b0444: mov             x17, #-0x1b0
    // 0x8b0448: str             d2, [fp, x17]
    // 0x8b044c: r0 = Color()
    //     0x8b044c: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b0450: mov             x1, x0
    // 0x8b0454: r0 = Instance_ColorSpace
    //     0x8b0454: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8b0458: ldr             x0, [x0, #0x298]
    // 0x8b045c: r17 = -424
    //     0x8b045c: mov             x17, #-0x1a8
    // 0x8b0460: str             x1, [fp, x17]
    // 0x8b0464: StoreField: r1->field_27 = r0
    //     0x8b0464: stur            w0, [x1, #0x27]
    // 0x8b0468: r17 = -432
    //     0x8b0468: mov             x17, #-0x1b0
    // 0x8b046c: ldr             d0, [fp, x17]
    // 0x8b0470: StoreField: r1->field_7 = d0
    //     0x8b0470: stur            d0, [x1, #7]
    // 0x8b0474: ldur            x2, [fp, #-0x30]
    // 0x8b0478: ubfx            x2, x2, #0, #0x20
    // 0x8b047c: and             w3, w2, #0xff
    // 0x8b0480: ubfx            x3, x3, #0, #0x20
    // 0x8b0484: scvtf           d0, x3
    // 0x8b0488: d1 = 255.000000
    //     0x8b0488: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8b048c: fdiv            d2, d0, d1
    // 0x8b0490: StoreField: r1->field_f = d2
    //     0x8b0490: stur            d2, [x1, #0xf]
    // 0x8b0494: ldur            x2, [fp, #-0x28]
    // 0x8b0498: ubfx            x2, x2, #0, #0x20
    // 0x8b049c: and             w3, w2, #0xff
    // 0x8b04a0: ubfx            x3, x3, #0, #0x20
    // 0x8b04a4: scvtf           d0, x3
    // 0x8b04a8: fdiv            d2, d0, d1
    // 0x8b04ac: ArrayStore: r1[0] = d2  ; List_8
    //     0x8b04ac: stur            d2, [x1, #0x17]
    // 0x8b04b0: ldur            x2, [fp, #-0x38]
    // 0x8b04b4: ubfx            x2, x2, #0, #0x20
    // 0x8b04b8: and             w3, w2, #0xff
    // 0x8b04bc: ubfx            x3, x3, #0, #0x20
    // 0x8b04c0: scvtf           d0, x3
    // 0x8b04c4: fdiv            d2, d0, d1
    // 0x8b04c8: StoreField: r1->field_1f = d2
    //     0x8b04c8: stur            d2, [x1, #0x1f]
    // 0x8b04cc: r0 = LoadStaticField(0x1140)
    //     0x8b04cc: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8b04d0: ldr             x0, [x0, #0x2280]
    // 0x8b04d4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8b04d8: cmp             w0, w16
    // 0x8b04dc: b.ne            #0x8b04ec
    // 0x8b04e0: r2 = surfaceVariant
    //     0x8b04e0: add             x2, PP, #0x13, lsl #12  ; [pp+0x13098] Field <MaterialDynamicColors.surfaceVariant>: static late final (offset: 0x1140)
    //     0x8b04e4: ldr             x2, [x2, #0x98]
    // 0x8b04e8: r0 = InitLateFinalStaticField()
    //     0x8b04e8: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8b04ec: mov             x1, x0
    // 0x8b04f0: ldur            x2, [fp, #-0x20]
    // 0x8b04f4: r0 = getArgb()
    //     0x8b04f4: bl              #0x8b07a8  ; [package:material_color_utilities/dynamiccolor/dynamic_color.dart] DynamicColor::getArgb
    // 0x8b04f8: stur            x0, [fp, #-0x38]
    // 0x8b04fc: asr             x1, x0, #0x18
    // 0x8b0500: asr             x2, x0, #0x10
    // 0x8b0504: stur            x2, [fp, #-0x30]
    // 0x8b0508: asr             x3, x0, #8
    // 0x8b050c: stur            x3, [fp, #-0x28]
    // 0x8b0510: ubfx            x1, x1, #0, #0x20
    // 0x8b0514: and             w4, w1, #0xff
    // 0x8b0518: ubfx            x4, x4, #0, #0x20
    // 0x8b051c: scvtf           d0, x4
    // 0x8b0520: d1 = 255.000000
    //     0x8b0520: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8b0524: fdiv            d2, d0, d1
    // 0x8b0528: r17 = -432
    //     0x8b0528: mov             x17, #-0x1b0
    // 0x8b052c: str             d2, [fp, x17]
    // 0x8b0530: r0 = Color()
    //     0x8b0530: bl              #0x8ad8d8  ; AllocateColorStub -> Color (size=0x2c)
    // 0x8b0534: mov             x1, x0
    // 0x8b0538: r0 = Instance_ColorSpace
    //     0x8b0538: add             x0, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!ColorSpace@12c8061
    //     0x8b053c: ldr             x0, [x0, #0x298]
    // 0x8b0540: stur            x1, [fp, #-0x20]
    // 0x8b0544: StoreField: r1->field_27 = r0
    //     0x8b0544: stur            w0, [x1, #0x27]
    // 0x8b0548: r17 = -432
    //     0x8b0548: mov             x17, #-0x1b0
    // 0x8b054c: ldr             d0, [fp, x17]
    // 0x8b0550: StoreField: r1->field_7 = d0
    //     0x8b0550: stur            d0, [x1, #7]
    // 0x8b0554: ldur            x0, [fp, #-0x30]
    // 0x8b0558: ubfx            x0, x0, #0, #0x20
    // 0x8b055c: and             w2, w0, #0xff
    // 0x8b0560: ubfx            x2, x2, #0, #0x20
    // 0x8b0564: scvtf           d0, x2
    // 0x8b0568: d1 = 255.000000
    //     0x8b0568: ldr             d1, [PP, #0x2c80]  ; [pp+0x2c80] IMM: double(255) from 0x406fe00000000000
    // 0x8b056c: fdiv            d2, d0, d1
    // 0x8b0570: StoreField: r1->field_f = d2
    //     0x8b0570: stur            d2, [x1, #0xf]
    // 0x8b0574: ldur            x0, [fp, #-0x28]
    // 0x8b0578: ubfx            x0, x0, #0, #0x20
    // 0x8b057c: and             w2, w0, #0xff
    // 0x8b0580: ubfx            x2, x2, #0, #0x20
    // 0x8b0584: scvtf           d0, x2
    // 0x8b0588: fdiv            d2, d0, d1
    // 0x8b058c: ArrayStore: r1[0] = d2  ; List_8
    //     0x8b058c: stur            d2, [x1, #0x17]
    // 0x8b0590: ldur            x0, [fp, #-0x38]
    // 0x8b0594: ubfx            x0, x0, #0, #0x20
    // 0x8b0598: and             w2, w0, #0xff
    // 0x8b059c: ubfx            x2, x2, #0, #0x20
    // 0x8b05a0: scvtf           d0, x2
    // 0x8b05a4: fdiv            d2, d0, d1
    // 0x8b05a8: StoreField: r1->field_1f = d2
    //     0x8b05a8: stur            d2, [x1, #0x1f]
    // 0x8b05ac: r0 = ColorScheme()
    //     0x8b05ac: bl              #0x8a9004  ; AllocateColorSchemeStub -> ColorScheme (size=0xd0)
    // 0x8b05b0: ldur            x1, [fp, #-0x18]
    // 0x8b05b4: StoreField: r0->field_7 = r1
    //     0x8b05b4: stur            w1, [x0, #7]
    // 0x8b05b8: ldur            x1, [fp, #-8]
    // 0x8b05bc: StoreField: r0->field_b = r1
    //     0x8b05bc: stur            w1, [x0, #0xb]
    // 0x8b05c0: ldur            x1, [fp, #-0x10]
    // 0x8b05c4: StoreField: r0->field_f = r1
    //     0x8b05c4: stur            w1, [x0, #0xf]
    // 0x8b05c8: ldur            x1, [fp, #-0x70]
    // 0x8b05cc: StoreField: r0->field_2b = r1
    //     0x8b05cc: stur            w1, [x0, #0x2b]
    // 0x8b05d0: ldur            x1, [fp, #-0x78]
    // 0x8b05d4: StoreField: r0->field_2f = r1
    //     0x8b05d4: stur            w1, [x0, #0x2f]
    // 0x8b05d8: ldur            x1, [fp, #-0xf0]
    // 0x8b05dc: StoreField: r0->field_6b = r1
    //     0x8b05dc: stur            w1, [x0, #0x6b]
    // 0x8b05e0: ldur            x1, [fp, #-0xf8]
    // 0x8b05e4: StoreField: r0->field_6f = r1
    //     0x8b05e4: stur            w1, [x0, #0x6f]
    // 0x8b05e8: r17 = -288
    //     0x8b05e8: mov             x17, #-0x120
    // 0x8b05ec: ldr             x1, [fp, x17]
    // 0x8b05f0: StoreField: r0->field_7b = r1
    //     0x8b05f0: stur            w1, [x0, #0x7b]
    // 0x8b05f4: r17 = -352
    //     0x8b05f4: mov             x17, #-0x160
    // 0x8b05f8: ldr             x1, [fp, x17]
    // 0x8b05fc: StoreField: r0->field_7f = r1
    //     0x8b05fc: stur            w1, [x0, #0x7f]
    // 0x8b0600: ldur            x1, [fp, #-0x40]
    // 0x8b0604: StoreField: r0->field_13 = r1
    //     0x8b0604: stur            w1, [x0, #0x13]
    // 0x8b0608: ldur            x1, [fp, #-0x48]
    // 0x8b060c: ArrayStore: r0[0] = r1  ; List_4
    //     0x8b060c: stur            w1, [x0, #0x17]
    // 0x8b0610: ldur            x1, [fp, #-0x50]
    // 0x8b0614: StoreField: r0->field_1b = r1
    //     0x8b0614: stur            w1, [x0, #0x1b]
    // 0x8b0618: ldur            x1, [fp, #-0x58]
    // 0x8b061c: StoreField: r0->field_1f = r1
    //     0x8b061c: stur            w1, [x0, #0x1f]
    // 0x8b0620: ldur            x1, [fp, #-0x60]
    // 0x8b0624: StoreField: r0->field_23 = r1
    //     0x8b0624: stur            w1, [x0, #0x23]
    // 0x8b0628: ldur            x1, [fp, #-0x68]
    // 0x8b062c: StoreField: r0->field_27 = r1
    //     0x8b062c: stur            w1, [x0, #0x27]
    // 0x8b0630: ldur            x1, [fp, #-0x80]
    // 0x8b0634: StoreField: r0->field_33 = r1
    //     0x8b0634: stur            w1, [x0, #0x33]
    // 0x8b0638: ldur            x1, [fp, #-0x88]
    // 0x8b063c: StoreField: r0->field_37 = r1
    //     0x8b063c: stur            w1, [x0, #0x37]
    // 0x8b0640: ldur            x1, [fp, #-0x90]
    // 0x8b0644: StoreField: r0->field_3b = r1
    //     0x8b0644: stur            w1, [x0, #0x3b]
    // 0x8b0648: ldur            x1, [fp, #-0x98]
    // 0x8b064c: StoreField: r0->field_3f = r1
    //     0x8b064c: stur            w1, [x0, #0x3f]
    // 0x8b0650: ldur            x1, [fp, #-0xa0]
    // 0x8b0654: StoreField: r0->field_43 = r1
    //     0x8b0654: stur            w1, [x0, #0x43]
    // 0x8b0658: ldur            x1, [fp, #-0xa8]
    // 0x8b065c: StoreField: r0->field_47 = r1
    //     0x8b065c: stur            w1, [x0, #0x47]
    // 0x8b0660: ldur            x1, [fp, #-0xb0]
    // 0x8b0664: StoreField: r0->field_4b = r1
    //     0x8b0664: stur            w1, [x0, #0x4b]
    // 0x8b0668: ldur            x1, [fp, #-0xb8]
    // 0x8b066c: StoreField: r0->field_4f = r1
    //     0x8b066c: stur            w1, [x0, #0x4f]
    // 0x8b0670: ldur            x1, [fp, #-0xc0]
    // 0x8b0674: StoreField: r0->field_53 = r1
    //     0x8b0674: stur            w1, [x0, #0x53]
    // 0x8b0678: ldur            x1, [fp, #-0xc8]
    // 0x8b067c: StoreField: r0->field_57 = r1
    //     0x8b067c: stur            w1, [x0, #0x57]
    // 0x8b0680: ldur            x1, [fp, #-0xd0]
    // 0x8b0684: StoreField: r0->field_5b = r1
    //     0x8b0684: stur            w1, [x0, #0x5b]
    // 0x8b0688: ldur            x1, [fp, #-0xd8]
    // 0x8b068c: StoreField: r0->field_5f = r1
    //     0x8b068c: stur            w1, [x0, #0x5f]
    // 0x8b0690: ldur            x1, [fp, #-0xe0]
    // 0x8b0694: StoreField: r0->field_63 = r1
    //     0x8b0694: stur            w1, [x0, #0x63]
    // 0x8b0698: ldur            x1, [fp, #-0xe8]
    // 0x8b069c: StoreField: r0->field_67 = r1
    //     0x8b069c: stur            w1, [x0, #0x67]
    // 0x8b06a0: ldur            x1, [fp, #-0x100]
    // 0x8b06a4: StoreField: r0->field_73 = r1
    //     0x8b06a4: stur            w1, [x0, #0x73]
    // 0x8b06a8: r17 = -264
    //     0x8b06a8: mov             x17, #-0x108
    // 0x8b06ac: ldr             x1, [fp, x17]
    // 0x8b06b0: StoreField: r0->field_77 = r1
    //     0x8b06b0: stur            w1, [x0, #0x77]
    // 0x8b06b4: r17 = -296
    //     0x8b06b4: mov             x17, #-0x128
    // 0x8b06b8: ldr             x1, [fp, x17]
    // 0x8b06bc: StoreField: r0->field_87 = r1
    //     0x8b06bc: stur            w1, [x0, #0x87]
    // 0x8b06c0: r17 = -304
    //     0x8b06c0: mov             x17, #-0x130
    // 0x8b06c4: ldr             x1, [fp, x17]
    // 0x8b06c8: StoreField: r0->field_8b = r1
    //     0x8b06c8: stur            w1, [x0, #0x8b]
    // 0x8b06cc: r17 = -312
    //     0x8b06cc: mov             x17, #-0x138
    // 0x8b06d0: ldr             x1, [fp, x17]
    // 0x8b06d4: StoreField: r0->field_8f = r1
    //     0x8b06d4: stur            w1, [x0, #0x8f]
    // 0x8b06d8: r17 = -320
    //     0x8b06d8: mov             x17, #-0x140
    // 0x8b06dc: ldr             x1, [fp, x17]
    // 0x8b06e0: StoreField: r0->field_93 = r1
    //     0x8b06e0: stur            w1, [x0, #0x93]
    // 0x8b06e4: r17 = -328
    //     0x8b06e4: mov             x17, #-0x148
    // 0x8b06e8: ldr             x1, [fp, x17]
    // 0x8b06ec: StoreField: r0->field_97 = r1
    //     0x8b06ec: stur            w1, [x0, #0x97]
    // 0x8b06f0: r17 = -336
    //     0x8b06f0: mov             x17, #-0x150
    // 0x8b06f4: ldr             x1, [fp, x17]
    // 0x8b06f8: StoreField: r0->field_9b = r1
    //     0x8b06f8: stur            w1, [x0, #0x9b]
    // 0x8b06fc: r17 = -344
    //     0x8b06fc: mov             x17, #-0x158
    // 0x8b0700: ldr             x1, [fp, x17]
    // 0x8b0704: StoreField: r0->field_9f = r1
    //     0x8b0704: stur            w1, [x0, #0x9f]
    // 0x8b0708: r17 = -360
    //     0x8b0708: mov             x17, #-0x168
    // 0x8b070c: ldr             x1, [fp, x17]
    // 0x8b0710: StoreField: r0->field_a3 = r1
    //     0x8b0710: stur            w1, [x0, #0xa3]
    // 0x8b0714: r17 = -272
    //     0x8b0714: mov             x17, #-0x110
    // 0x8b0718: ldr             x1, [fp, x17]
    // 0x8b071c: StoreField: r0->field_a7 = r1
    //     0x8b071c: stur            w1, [x0, #0xa7]
    // 0x8b0720: r17 = -280
    //     0x8b0720: mov             x17, #-0x118
    // 0x8b0724: ldr             x1, [fp, x17]
    // 0x8b0728: StoreField: r0->field_ab = r1
    //     0x8b0728: stur            w1, [x0, #0xab]
    // 0x8b072c: r17 = -392
    //     0x8b072c: mov             x17, #-0x188
    // 0x8b0730: ldr             x1, [fp, x17]
    // 0x8b0734: StoreField: r0->field_af = r1
    //     0x8b0734: stur            w1, [x0, #0xaf]
    // 0x8b0738: r17 = -400
    //     0x8b0738: mov             x17, #-0x190
    // 0x8b073c: ldr             x1, [fp, x17]
    // 0x8b0740: StoreField: r0->field_b3 = r1
    //     0x8b0740: stur            w1, [x0, #0xb3]
    // 0x8b0744: r17 = -368
    //     0x8b0744: mov             x17, #-0x170
    // 0x8b0748: ldr             x1, [fp, x17]
    // 0x8b074c: StoreField: r0->field_b7 = r1
    //     0x8b074c: stur            w1, [x0, #0xb7]
    // 0x8b0750: r17 = -376
    //     0x8b0750: mov             x17, #-0x178
    // 0x8b0754: ldr             x1, [fp, x17]
    // 0x8b0758: StoreField: r0->field_bb = r1
    //     0x8b0758: stur            w1, [x0, #0xbb]
    // 0x8b075c: r17 = -384
    //     0x8b075c: mov             x17, #-0x180
    // 0x8b0760: ldr             x1, [fp, x17]
    // 0x8b0764: StoreField: r0->field_bf = r1
    //     0x8b0764: stur            w1, [x0, #0xbf]
    // 0x8b0768: r17 = -408
    //     0x8b0768: mov             x17, #-0x198
    // 0x8b076c: ldr             x1, [fp, x17]
    // 0x8b0770: StoreField: r0->field_c3 = r1
    //     0x8b0770: stur            w1, [x0, #0xc3]
    // 0x8b0774: r17 = -416
    //     0x8b0774: mov             x17, #-0x1a0
    // 0x8b0778: ldr             x1, [fp, x17]
    // 0x8b077c: StoreField: r0->field_c7 = r1
    //     0x8b077c: stur            w1, [x0, #0xc7]
    // 0x8b0780: r17 = -424
    //     0x8b0780: mov             x17, #-0x1a8
    // 0x8b0784: ldr             x1, [fp, x17]
    // 0x8b0788: StoreField: r0->field_cb = r1
    //     0x8b0788: stur            w1, [x0, #0xcb]
    // 0x8b078c: ldur            x1, [fp, #-0x20]
    // 0x8b0790: StoreField: r0->field_83 = r1
    //     0x8b0790: stur            w1, [x0, #0x83]
    // 0x8b0794: LeaveFrame
    //     0x8b0794: mov             SP, fp
    //     0x8b0798: ldp             fp, lr, [SP], #0x10
    // 0x8b079c: ret
    //     0x8b079c: ret             
    // 0x8b07a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8b07a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8b07a4: b               #0x8ada2c
  }
  static _ _buildDynamicScheme(/* No info */) {
    // ** addr: 0x8b8dc0, size: 0x78
    // 0x8b8dc0: EnterFrame
    //     0x8b8dc0: stp             fp, lr, [SP, #-0x10]!
    //     0x8b8dc4: mov             fp, SP
    // 0x8b8dc8: AllocStack(0x10)
    //     0x8b8dc8: sub             SP, SP, #0x10
    // 0x8b8dcc: SetupParameters(dynamic _ /* r1 => r0 */, dynamic _ /* r2 => r1 */)
    //     0x8b8dcc: mov             x0, x1
    //     0x8b8dd0: mov             x1, x2
    // 0x8b8dd4: CheckStackOverflow
    //     0x8b8dd4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8b8dd8: cmp             SP, x16
    //     0x8b8ddc: b.ls            #0x8b8e30
    // 0x8b8de0: r16 = Instance_Brightness
    //     0x8b8de0: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0x8b8de4: cmp             w0, w16
    // 0x8b8de8: r16 = true
    //     0x8b8de8: add             x16, NULL, #0x20  ; true
    // 0x8b8dec: r17 = false
    //     0x8b8dec: add             x17, NULL, #0x30  ; false
    // 0x8b8df0: csel            x2, x16, x17, eq
    // 0x8b8df4: stur            x2, [fp, #-8]
    // 0x8b8df8: r0 = toARGB32()
    //     0x8b8df8: bl              #0x119defc  ; [dart:ui] Color::toARGB32
    // 0x8b8dfc: mov             x1, x0
    // 0x8b8e00: r0 = fromInt()
    //     0x8b8e00: bl              #0x8b7960  ; [package:material_color_utilities/hct/hct.dart] Hct::fromInt
    // 0x8b8e04: stur            x0, [fp, #-0x10]
    // 0x8b8e08: r0 = SchemeTonalSpot()
    //     0x8b8e08: bl              #0x8b959c  ; AllocateSchemeTonalSpotStub -> SchemeTonalSpot (size=0x34)
    // 0x8b8e0c: mov             x1, x0
    // 0x8b8e10: ldur            x2, [fp, #-8]
    // 0x8b8e14: ldur            x3, [fp, #-0x10]
    // 0x8b8e18: stur            x0, [fp, #-8]
    // 0x8b8e1c: r0 = SchemeTonalSpot()
    //     0x8b8e1c: bl              #0x8b8e38  ; [package:material_color_utilities/scheme/scheme_tonal_spot.dart] SchemeTonalSpot::SchemeTonalSpot
    // 0x8b8e20: ldur            x0, [fp, #-8]
    // 0x8b8e24: LeaveFrame
    //     0x8b8e24: mov             SP, fp
    //     0x8b8e28: ldp             fp, lr, [SP], #0x10
    // 0x8b8e2c: ret
    //     0x8b8e2c: ret             
    // 0x8b8e30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8b8e30: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8b8e34: b               #0x8b8de0
  }
  static _ of(/* No info */) {
    // ** addr: 0xfbd924, size: 0x38
    // 0xfbd924: EnterFrame
    //     0xfbd924: stp             fp, lr, [SP, #-0x10]!
    //     0xfbd928: mov             fp, SP
    // 0xfbd92c: CheckStackOverflow
    //     0xfbd92c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfbd930: cmp             SP, x16
    //     0xfbd934: b.ls            #0xfbd954
    // 0xfbd938: r0 = of()
    //     0xfbd938: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfbd93c: LoadField: r1 = r0->field_3f
    //     0xfbd93c: ldur            w1, [x0, #0x3f]
    // 0xfbd940: DecompressPointer r1
    //     0xfbd940: add             x1, x1, HEAP, lsl #32
    // 0xfbd944: mov             x0, x1
    // 0xfbd948: LeaveFrame
    //     0xfbd948: mov             SP, fp
    //     0xfbd94c: ldp             fp, lr, [SP], #0x10
    // 0xfbd950: ret
    //     0xfbd950: ret             
    // 0xfbd954: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfbd954: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfbd958: b               #0xfbd938
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x11302a8, size: 0x6c4
    // 0x11302a8: EnterFrame
    //     0x11302a8: stp             fp, lr, [SP, #-0x10]!
    //     0x11302ac: mov             fp, SP
    // 0x11302b0: AllocStack(0x1f8)
    //     0x11302b0: sub             SP, SP, #0x1f8
    // 0x11302b4: CheckStackOverflow
    //     0x11302b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11302b8: cmp             SP, x16
    //     0x11302bc: b.ls            #0x1130964
    // 0x11302c0: ldr             x0, [fp, #0x10]
    // 0x11302c4: LoadField: r2 = r0->field_7
    //     0x11302c4: ldur            w2, [x0, #7]
    // 0x11302c8: DecompressPointer r2
    //     0x11302c8: add             x2, x2, HEAP, lsl #32
    // 0x11302cc: stur            x2, [fp, #-0x58]
    // 0x11302d0: LoadField: r3 = r0->field_b
    //     0x11302d0: ldur            w3, [x0, #0xb]
    // 0x11302d4: DecompressPointer r3
    //     0x11302d4: add             x3, x3, HEAP, lsl #32
    // 0x11302d8: stur            x3, [fp, #-0x50]
    // 0x11302dc: LoadField: r4 = r0->field_f
    //     0x11302dc: ldur            w4, [x0, #0xf]
    // 0x11302e0: DecompressPointer r4
    //     0x11302e0: add             x4, x4, HEAP, lsl #32
    // 0x11302e4: stur            x4, [fp, #-0x48]
    // 0x11302e8: LoadField: r1 = r0->field_13
    //     0x11302e8: ldur            w1, [x0, #0x13]
    // 0x11302ec: DecompressPointer r1
    //     0x11302ec: add             x1, x1, HEAP, lsl #32
    // 0x11302f0: cmp             w1, NULL
    // 0x11302f4: b.ne            #0x1130300
    // 0x11302f8: mov             x5, x3
    // 0x11302fc: b               #0x1130304
    // 0x1130300: mov             x5, x1
    // 0x1130304: stur            x5, [fp, #-0x40]
    // 0x1130308: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x1130308: ldur            w1, [x0, #0x17]
    // 0x113030c: DecompressPointer r1
    //     0x113030c: add             x1, x1, HEAP, lsl #32
    // 0x1130310: cmp             w1, NULL
    // 0x1130314: b.ne            #0x1130320
    // 0x1130318: mov             x6, x4
    // 0x113031c: b               #0x1130324
    // 0x1130320: mov             x6, x1
    // 0x1130324: stur            x6, [fp, #-0x38]
    // 0x1130328: LoadField: r7 = r0->field_2b
    //     0x1130328: ldur            w7, [x0, #0x2b]
    // 0x113032c: DecompressPointer r7
    //     0x113032c: add             x7, x7, HEAP, lsl #32
    // 0x1130330: stur            x7, [fp, #-0x30]
    // 0x1130334: LoadField: r8 = r0->field_2f
    //     0x1130334: ldur            w8, [x0, #0x2f]
    // 0x1130338: DecompressPointer r8
    //     0x1130338: add             x8, x8, HEAP, lsl #32
    // 0x113033c: stur            x8, [fp, #-0x28]
    // 0x1130340: LoadField: r1 = r0->field_33
    //     0x1130340: ldur            w1, [x0, #0x33]
    // 0x1130344: DecompressPointer r1
    //     0x1130344: add             x1, x1, HEAP, lsl #32
    // 0x1130348: cmp             w1, NULL
    // 0x113034c: b.ne            #0x1130358
    // 0x1130350: mov             x9, x7
    // 0x1130354: b               #0x113035c
    // 0x1130358: mov             x9, x1
    // 0x113035c: stur            x9, [fp, #-0x20]
    // 0x1130360: LoadField: r1 = r0->field_37
    //     0x1130360: ldur            w1, [x0, #0x37]
    // 0x1130364: DecompressPointer r1
    //     0x1130364: add             x1, x1, HEAP, lsl #32
    // 0x1130368: cmp             w1, NULL
    // 0x113036c: b.ne            #0x1130378
    // 0x1130370: mov             x10, x8
    // 0x1130374: b               #0x113037c
    // 0x1130378: mov             x10, x1
    // 0x113037c: stur            x10, [fp, #-0x18]
    // 0x1130380: LoadField: r1 = r0->field_4b
    //     0x1130380: ldur            w1, [x0, #0x4b]
    // 0x1130384: DecompressPointer r1
    //     0x1130384: add             x1, x1, HEAP, lsl #32
    // 0x1130388: cmp             w1, NULL
    // 0x113038c: b.ne            #0x1130398
    // 0x1130390: mov             x11, x7
    // 0x1130394: b               #0x113039c
    // 0x1130398: mov             x11, x1
    // 0x113039c: stur            x11, [fp, #-0x10]
    // 0x11303a0: LoadField: r1 = r0->field_4f
    //     0x11303a0: ldur            w1, [x0, #0x4f]
    // 0x11303a4: DecompressPointer r1
    //     0x11303a4: add             x1, x1, HEAP, lsl #32
    // 0x11303a8: cmp             w1, NULL
    // 0x11303ac: b.ne            #0x11303b8
    // 0x11303b0: mov             x12, x8
    // 0x11303b4: b               #0x11303bc
    // 0x11303b8: mov             x12, x1
    // 0x11303bc: mov             x1, x0
    // 0x11303c0: stur            x12, [fp, #-8]
    // 0x11303c4: r0 = tertiaryContainer()
    //     0x11303c4: bl              #0x8a91b4  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::tertiaryContainer
    // 0x11303c8: ldr             x1, [fp, #0x10]
    // 0x11303cc: stur            x0, [fp, #-0x60]
    // 0x11303d0: r0 = onTertiaryContainer()
    //     0x11303d0: bl              #0x8a9170  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::onTertiaryContainer
    // 0x11303d4: mov             x2, x0
    // 0x11303d8: ldr             x0, [fp, #0x10]
    // 0x11303dc: stur            x2, [fp, #-0x68]
    // 0x11303e0: LoadField: r3 = r0->field_6b
    //     0x11303e0: ldur            w3, [x0, #0x6b]
    // 0x11303e4: DecompressPointer r3
    //     0x11303e4: add             x3, x3, HEAP, lsl #32
    // 0x11303e8: r17 = -344
    //     0x11303e8: mov             x17, #-0x158
    // 0x11303ec: str             x3, [fp, x17]
    // 0x11303f0: LoadField: r4 = r0->field_6f
    //     0x11303f0: ldur            w4, [x0, #0x6f]
    // 0x11303f4: DecompressPointer r4
    //     0x11303f4: add             x4, x4, HEAP, lsl #32
    // 0x11303f8: r17 = -336
    //     0x11303f8: mov             x17, #-0x150
    // 0x11303fc: str             x4, [fp, x17]
    // 0x1130400: LoadField: r1 = r0->field_73
    //     0x1130400: ldur            w1, [x0, #0x73]
    // 0x1130404: DecompressPointer r1
    //     0x1130404: add             x1, x1, HEAP, lsl #32
    // 0x1130408: cmp             w1, NULL
    // 0x113040c: b.ne            #0x1130418
    // 0x1130410: mov             x5, x3
    // 0x1130414: b               #0x113041c
    // 0x1130418: mov             x5, x1
    // 0x113041c: r17 = -328
    //     0x113041c: mov             x17, #-0x148
    // 0x1130420: str             x5, [fp, x17]
    // 0x1130424: LoadField: r1 = r0->field_77
    //     0x1130424: ldur            w1, [x0, #0x77]
    // 0x1130428: DecompressPointer r1
    //     0x1130428: add             x1, x1, HEAP, lsl #32
    // 0x113042c: cmp             w1, NULL
    // 0x1130430: b.ne            #0x113043c
    // 0x1130434: mov             x6, x4
    // 0x1130438: b               #0x1130440
    // 0x113043c: mov             x6, x1
    // 0x1130440: r17 = -320
    //     0x1130440: mov             x17, #-0x140
    // 0x1130444: str             x6, [fp, x17]
    // 0x1130448: LoadField: r7 = r0->field_7b
    //     0x1130448: ldur            w7, [x0, #0x7b]
    // 0x113044c: DecompressPointer r7
    //     0x113044c: add             x7, x7, HEAP, lsl #32
    // 0x1130450: r17 = -312
    //     0x1130450: mov             x17, #-0x138
    // 0x1130454: str             x7, [fp, x17]
    // 0x1130458: LoadField: r8 = r0->field_7f
    //     0x1130458: ldur            w8, [x0, #0x7f]
    // 0x113045c: DecompressPointer r8
    //     0x113045c: add             x8, x8, HEAP, lsl #32
    // 0x1130460: r17 = -304
    //     0x1130460: mov             x17, #-0x130
    // 0x1130464: str             x8, [fp, x17]
    // 0x1130468: LoadField: r1 = r0->field_87
    //     0x1130468: ldur            w1, [x0, #0x87]
    // 0x113046c: DecompressPointer r1
    //     0x113046c: add             x1, x1, HEAP, lsl #32
    // 0x1130470: cmp             w1, NULL
    // 0x1130474: b.ne            #0x1130480
    // 0x1130478: mov             x9, x7
    // 0x113047c: b               #0x1130484
    // 0x1130480: mov             x9, x1
    // 0x1130484: r17 = -296
    //     0x1130484: mov             x17, #-0x128
    // 0x1130488: str             x9, [fp, x17]
    // 0x113048c: LoadField: r1 = r0->field_8b
    //     0x113048c: ldur            w1, [x0, #0x8b]
    // 0x1130490: DecompressPointer r1
    //     0x1130490: add             x1, x1, HEAP, lsl #32
    // 0x1130494: cmp             w1, NULL
    // 0x1130498: b.ne            #0x11304a4
    // 0x113049c: mov             x10, x7
    // 0x11304a0: b               #0x11304a8
    // 0x11304a4: mov             x10, x1
    // 0x11304a8: r17 = -288
    //     0x11304a8: mov             x17, #-0x120
    // 0x11304ac: str             x10, [fp, x17]
    // 0x11304b0: LoadField: r1 = r0->field_8f
    //     0x11304b0: ldur            w1, [x0, #0x8f]
    // 0x11304b4: DecompressPointer r1
    //     0x11304b4: add             x1, x1, HEAP, lsl #32
    // 0x11304b8: cmp             w1, NULL
    // 0x11304bc: b.ne            #0x11304c8
    // 0x11304c0: mov             x11, x7
    // 0x11304c4: b               #0x11304cc
    // 0x11304c8: mov             x11, x1
    // 0x11304cc: r17 = -280
    //     0x11304cc: mov             x17, #-0x118
    // 0x11304d0: str             x11, [fp, x17]
    // 0x11304d4: LoadField: r1 = r0->field_93
    //     0x11304d4: ldur            w1, [x0, #0x93]
    // 0x11304d8: DecompressPointer r1
    //     0x11304d8: add             x1, x1, HEAP, lsl #32
    // 0x11304dc: cmp             w1, NULL
    // 0x11304e0: b.ne            #0x11304ec
    // 0x11304e4: mov             x12, x7
    // 0x11304e8: b               #0x11304f0
    // 0x11304ec: mov             x12, x1
    // 0x11304f0: r17 = -272
    //     0x11304f0: mov             x17, #-0x110
    // 0x11304f4: str             x12, [fp, x17]
    // 0x11304f8: LoadField: r1 = r0->field_97
    //     0x11304f8: ldur            w1, [x0, #0x97]
    // 0x11304fc: DecompressPointer r1
    //     0x11304fc: add             x1, x1, HEAP, lsl #32
    // 0x1130500: cmp             w1, NULL
    // 0x1130504: b.ne            #0x1130510
    // 0x1130508: mov             x13, x7
    // 0x113050c: b               #0x1130514
    // 0x1130510: mov             x13, x1
    // 0x1130514: r17 = -264
    //     0x1130514: mov             x17, #-0x108
    // 0x1130518: str             x13, [fp, x17]
    // 0x113051c: LoadField: r1 = r0->field_9b
    //     0x113051c: ldur            w1, [x0, #0x9b]
    // 0x1130520: DecompressPointer r1
    //     0x1130520: add             x1, x1, HEAP, lsl #32
    // 0x1130524: cmp             w1, NULL
    // 0x1130528: b.ne            #0x1130534
    // 0x113052c: mov             x14, x7
    // 0x1130530: b               #0x1130538
    // 0x1130534: mov             x14, x1
    // 0x1130538: stur            x14, [fp, #-0x100]
    // 0x113053c: LoadField: r1 = r0->field_9f
    //     0x113053c: ldur            w1, [x0, #0x9f]
    // 0x1130540: DecompressPointer r1
    //     0x1130540: add             x1, x1, HEAP, lsl #32
    // 0x1130544: cmp             w1, NULL
    // 0x1130548: b.ne            #0x1130554
    // 0x113054c: mov             x19, x7
    // 0x1130550: b               #0x1130558
    // 0x1130554: mov             x19, x1
    // 0x1130558: stur            x19, [fp, #-0xf8]
    // 0x113055c: LoadField: r1 = r0->field_a3
    //     0x113055c: ldur            w1, [x0, #0xa3]
    // 0x1130560: DecompressPointer r1
    //     0x1130560: add             x1, x1, HEAP, lsl #32
    // 0x1130564: cmp             w1, NULL
    // 0x1130568: b.ne            #0x1130574
    // 0x113056c: mov             x20, x8
    // 0x1130570: b               #0x1130578
    // 0x1130574: mov             x20, x1
    // 0x1130578: stur            x20, [fp, #-0xf0]
    // 0x113057c: LoadField: r1 = r0->field_a7
    //     0x113057c: ldur            w1, [x0, #0xa7]
    // 0x1130580: DecompressPointer r1
    //     0x1130580: add             x1, x1, HEAP, lsl #32
    // 0x1130584: cmp             w1, NULL
    // 0x1130588: b.ne            #0x113059c
    // 0x113058c: LoadField: r1 = r0->field_cb
    //     0x113058c: ldur            w1, [x0, #0xcb]
    // 0x1130590: DecompressPointer r1
    //     0x1130590: add             x1, x1, HEAP, lsl #32
    // 0x1130594: mov             x23, x1
    // 0x1130598: b               #0x11305a0
    // 0x113059c: mov             x23, x1
    // 0x11305a0: stur            x23, [fp, #-0xe8]
    // 0x11305a4: LoadField: r1 = r0->field_ab
    //     0x11305a4: ldur            w1, [x0, #0xab]
    // 0x11305a8: DecompressPointer r1
    //     0x11305a8: add             x1, x1, HEAP, lsl #32
    // 0x11305ac: cmp             w1, NULL
    // 0x11305b0: b.ne            #0x11305c4
    // 0x11305b4: LoadField: r1 = r0->field_cb
    //     0x11305b4: ldur            w1, [x0, #0xcb]
    // 0x11305b8: DecompressPointer r1
    //     0x11305b8: add             x1, x1, HEAP, lsl #32
    // 0x11305bc: mov             x24, x1
    // 0x11305c0: b               #0x11305c8
    // 0x11305c4: mov             x24, x1
    // 0x11305c8: stur            x24, [fp, #-0xe0]
    // 0x11305cc: LoadField: r1 = r0->field_af
    //     0x11305cc: ldur            w1, [x0, #0xaf]
    // 0x11305d0: DecompressPointer r1
    //     0x11305d0: add             x1, x1, HEAP, lsl #32
    // 0x11305d4: cmp             w1, NULL
    // 0x11305d8: b.ne            #0x11305e8
    // 0x11305dc: r25 = Instance_Color
    //     0x11305dc: add             x25, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0x11305e0: ldr             x25, [x25, #0x948]
    // 0x11305e4: b               #0x11305ec
    // 0x11305e8: mov             x25, x1
    // 0x11305ec: stur            x25, [fp, #-0xd8]
    // 0x11305f0: LoadField: r1 = r0->field_b3
    //     0x11305f0: ldur            w1, [x0, #0xb3]
    // 0x11305f4: DecompressPointer r1
    //     0x11305f4: add             x1, x1, HEAP, lsl #32
    // 0x11305f8: cmp             w1, NULL
    // 0x11305fc: b.ne            #0x1130608
    // 0x1130600: r1 = Instance_Color
    //     0x1130600: add             x1, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0x1130604: ldr             x1, [x1, #0x948]
    // 0x1130608: stur            x1, [fp, #-0xc8]
    // 0x113060c: LoadField: r2 = r0->field_b7
    //     0x113060c: ldur            w2, [x0, #0xb7]
    // 0x1130610: DecompressPointer r2
    //     0x1130610: add             x2, x2, HEAP, lsl #32
    // 0x1130614: cmp             w2, NULL
    // 0x1130618: b.ne            #0x1130620
    // 0x113061c: mov             x2, x8
    // 0x1130620: stur            x2, [fp, #-0x70]
    // 0x1130624: LoadField: r2 = r0->field_bb
    //     0x1130624: ldur            w2, [x0, #0xbb]
    // 0x1130628: DecompressPointer r2
    //     0x1130628: add             x2, x2, HEAP, lsl #32
    // 0x113062c: cmp             w2, NULL
    // 0x1130630: b.ne            #0x1130638
    // 0x1130634: mov             x2, x7
    // 0x1130638: stur            x2, [fp, #-0x78]
    // 0x113063c: LoadField: r2 = r0->field_bf
    //     0x113063c: ldur            w2, [x0, #0xbf]
    // 0x1130640: DecompressPointer r2
    //     0x1130640: add             x2, x2, HEAP, lsl #32
    // 0x1130644: cmp             w2, NULL
    // 0x1130648: b.ne            #0x1130650
    // 0x113064c: ldur            x2, [fp, #-0x48]
    // 0x1130650: stur            x2, [fp, #-0x80]
    // 0x1130654: LoadField: r2 = r0->field_c3
    //     0x1130654: ldur            w2, [x0, #0xc3]
    // 0x1130658: DecompressPointer r2
    //     0x1130658: add             x2, x2, HEAP, lsl #32
    // 0x113065c: cmp             w2, NULL
    // 0x1130660: b.ne            #0x1130668
    // 0x1130664: ldur            x2, [fp, #-0x50]
    // 0x1130668: stur            x2, [fp, #-0x88]
    // 0x113066c: LoadField: r2 = r0->field_1b
    //     0x113066c: ldur            w2, [x0, #0x1b]
    // 0x1130670: DecompressPointer r2
    //     0x1130670: add             x2, x2, HEAP, lsl #32
    // 0x1130674: cmp             w2, NULL
    // 0x1130678: b.ne            #0x1130680
    // 0x113067c: ldur            x2, [fp, #-0x50]
    // 0x1130680: stur            x2, [fp, #-0x90]
    // 0x1130684: LoadField: r2 = r0->field_1f
    //     0x1130684: ldur            w2, [x0, #0x1f]
    // 0x1130688: DecompressPointer r2
    //     0x1130688: add             x2, x2, HEAP, lsl #32
    // 0x113068c: cmp             w2, NULL
    // 0x1130690: b.ne            #0x1130698
    // 0x1130694: ldur            x2, [fp, #-0x50]
    // 0x1130698: stur            x2, [fp, #-0x98]
    // 0x113069c: LoadField: r2 = r0->field_23
    //     0x113069c: ldur            w2, [x0, #0x23]
    // 0x11306a0: DecompressPointer r2
    //     0x11306a0: add             x2, x2, HEAP, lsl #32
    // 0x11306a4: cmp             w2, NULL
    // 0x11306a8: b.ne            #0x11306b0
    // 0x11306ac: ldur            x2, [fp, #-0x48]
    // 0x11306b0: stur            x2, [fp, #-0xa0]
    // 0x11306b4: LoadField: r2 = r0->field_27
    //     0x11306b4: ldur            w2, [x0, #0x27]
    // 0x11306b8: DecompressPointer r2
    //     0x11306b8: add             x2, x2, HEAP, lsl #32
    // 0x11306bc: cmp             w2, NULL
    // 0x11306c0: b.ne            #0x11306c8
    // 0x11306c4: ldur            x2, [fp, #-0x48]
    // 0x11306c8: stur            x2, [fp, #-0xa8]
    // 0x11306cc: LoadField: r2 = r0->field_3b
    //     0x11306cc: ldur            w2, [x0, #0x3b]
    // 0x11306d0: DecompressPointer r2
    //     0x11306d0: add             x2, x2, HEAP, lsl #32
    // 0x11306d4: cmp             w2, NULL
    // 0x11306d8: b.ne            #0x11306e0
    // 0x11306dc: ldur            x2, [fp, #-0x30]
    // 0x11306e0: stur            x2, [fp, #-0xb0]
    // 0x11306e4: LoadField: r2 = r0->field_3f
    //     0x11306e4: ldur            w2, [x0, #0x3f]
    // 0x11306e8: DecompressPointer r2
    //     0x11306e8: add             x2, x2, HEAP, lsl #32
    // 0x11306ec: cmp             w2, NULL
    // 0x11306f0: b.ne            #0x11306f8
    // 0x11306f4: ldur            x2, [fp, #-0x30]
    // 0x11306f8: stur            x2, [fp, #-0xb8]
    // 0x11306fc: LoadField: r2 = r0->field_43
    //     0x11306fc: ldur            w2, [x0, #0x43]
    // 0x1130700: DecompressPointer r2
    //     0x1130700: add             x2, x2, HEAP, lsl #32
    // 0x1130704: cmp             w2, NULL
    // 0x1130708: b.ne            #0x1130710
    // 0x113070c: ldur            x2, [fp, #-0x28]
    // 0x1130710: stur            x2, [fp, #-0xc0]
    // 0x1130714: LoadField: r2 = r0->field_47
    //     0x1130714: ldur            w2, [x0, #0x47]
    // 0x1130718: DecompressPointer r2
    //     0x1130718: add             x2, x2, HEAP, lsl #32
    // 0x113071c: cmp             w2, NULL
    // 0x1130720: b.ne            #0x1130728
    // 0x1130724: ldur            x2, [fp, #-0x28]
    // 0x1130728: mov             x1, x0
    // 0x113072c: stur            x2, [fp, #-0xd0]
    // 0x1130730: r0 = tertiaryFixed()
    //     0x1130730: bl              #0x8a912c  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::tertiaryFixed
    // 0x1130734: ldr             x1, [fp, #0x10]
    // 0x1130738: r17 = -352
    //     0x1130738: mov             x17, #-0x160
    // 0x113073c: str             x0, [fp, x17]
    // 0x1130740: r0 = tertiaryFixedDim()
    //     0x1130740: bl              #0x8a90e8  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::tertiaryFixedDim
    // 0x1130744: ldr             x1, [fp, #0x10]
    // 0x1130748: r17 = -360
    //     0x1130748: mov             x17, #-0x168
    // 0x113074c: str             x0, [fp, x17]
    // 0x1130750: r0 = onTertiaryFixed()
    //     0x1130750: bl              #0x8a90a4  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::onTertiaryFixed
    // 0x1130754: ldr             x1, [fp, #0x10]
    // 0x1130758: r17 = -368
    //     0x1130758: mov             x17, #-0x170
    // 0x113075c: str             x0, [fp, x17]
    // 0x1130760: r0 = onTertiaryFixedVariant()
    //     0x1130760: bl              #0x8a9060  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::onTertiaryFixedVariant
    // 0x1130764: mov             x1, x0
    // 0x1130768: ldr             x0, [fp, #0x10]
    // 0x113076c: LoadField: r2 = r0->field_c7
    //     0x113076c: ldur            w2, [x0, #0xc7]
    // 0x1130770: DecompressPointer r2
    //     0x1130770: add             x2, x2, HEAP, lsl #32
    // 0x1130774: LoadField: r3 = r0->field_cb
    //     0x1130774: ldur            w3, [x0, #0xcb]
    // 0x1130778: DecompressPointer r3
    //     0x1130778: add             x3, x3, HEAP, lsl #32
    // 0x113077c: LoadField: r4 = r0->field_83
    //     0x113077c: ldur            w4, [x0, #0x83]
    // 0x1130780: DecompressPointer r4
    //     0x1130780: add             x4, x4, HEAP, lsl #32
    // 0x1130784: cmp             w4, NULL
    // 0x1130788: b.ne            #0x1130798
    // 0x113078c: r17 = -312
    //     0x113078c: mov             x17, #-0x138
    // 0x1130790: ldr             x0, [fp, x17]
    // 0x1130794: b               #0x113079c
    // 0x1130798: mov             x0, x4
    // 0x113079c: ldur            x16, [fp, #-0xa0]
    // 0x11307a0: ldur            lr, [fp, #-0xa8]
    // 0x11307a4: stp             lr, x16, [SP, #0x58]
    // 0x11307a8: ldur            x16, [fp, #-0xb0]
    // 0x11307ac: ldur            lr, [fp, #-0xb8]
    // 0x11307b0: stp             lr, x16, [SP, #0x48]
    // 0x11307b4: ldur            x16, [fp, #-0xc0]
    // 0x11307b8: ldur            lr, [fp, #-0xd0]
    // 0x11307bc: stp             lr, x16, [SP, #0x38]
    // 0x11307c0: r17 = -352
    //     0x11307c0: mov             x17, #-0x160
    // 0x11307c4: ldr             x16, [fp, x17]
    // 0x11307c8: r17 = -360
    //     0x11307c8: mov             x17, #-0x168
    // 0x11307cc: ldr             lr, [fp, x17]
    // 0x11307d0: stp             lr, x16, [SP, #0x28]
    // 0x11307d4: r17 = -368
    //     0x11307d4: mov             x17, #-0x170
    // 0x11307d8: ldr             x16, [fp, x17]
    // 0x11307dc: stp             x1, x16, [SP, #0x18]
    // 0x11307e0: stp             x3, x2, [SP, #8]
    // 0x11307e4: str             x0, [SP]
    // 0x11307e8: ldur            x1, [fp, #-0x90]
    // 0x11307ec: ldur            x2, [fp, #-0x98]
    // 0x11307f0: r4 = const [0, 0xf, 0xd, 0xf, null]
    //     0x11307f0: add             x4, PP, #0xd, lsl #12  ; [pp+0xdf18] List(5) [0, 0xf, 0xd, 0xf, Null]
    //     0x11307f4: ldr             x4, [x4, #0xf18]
    // 0x11307f8: r0 = hash()
    //     0x11307f8: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x11307fc: mov             x2, x0
    // 0x1130800: r0 = BoxInt64Instr(r2)
    //     0x1130800: sbfiz           x0, x2, #1, #0x1f
    //     0x1130804: cmp             x2, x0, asr #1
    //     0x1130808: b.eq            #0x1130814
    //     0x113080c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1130810: stur            x2, [x0, #7]
    // 0x1130814: r17 = -296
    //     0x1130814: mov             x17, #-0x128
    // 0x1130818: ldr             x16, [fp, x17]
    // 0x113081c: r17 = -288
    //     0x113081c: mov             x17, #-0x120
    // 0x1130820: ldr             lr, [fp, x17]
    // 0x1130824: stp             lr, x16, [SP, #0x78]
    // 0x1130828: r17 = -280
    //     0x1130828: mov             x17, #-0x118
    // 0x113082c: ldr             x16, [fp, x17]
    // 0x1130830: r17 = -272
    //     0x1130830: mov             x17, #-0x110
    // 0x1130834: ldr             lr, [fp, x17]
    // 0x1130838: stp             lr, x16, [SP, #0x68]
    // 0x113083c: r17 = -264
    //     0x113083c: mov             x17, #-0x108
    // 0x1130840: ldr             x16, [fp, x17]
    // 0x1130844: ldur            lr, [fp, #-0x100]
    // 0x1130848: stp             lr, x16, [SP, #0x58]
    // 0x113084c: ldur            x16, [fp, #-0xf8]
    // 0x1130850: ldur            lr, [fp, #-0xf0]
    // 0x1130854: stp             lr, x16, [SP, #0x48]
    // 0x1130858: ldur            x16, [fp, #-0xe8]
    // 0x113085c: ldur            lr, [fp, #-0xe0]
    // 0x1130860: stp             lr, x16, [SP, #0x38]
    // 0x1130864: ldur            x16, [fp, #-0xd8]
    // 0x1130868: ldur            lr, [fp, #-0xc8]
    // 0x113086c: stp             lr, x16, [SP, #0x28]
    // 0x1130870: ldur            x16, [fp, #-0x70]
    // 0x1130874: ldur            lr, [fp, #-0x78]
    // 0x1130878: stp             lr, x16, [SP, #0x18]
    // 0x113087c: ldur            x16, [fp, #-0x80]
    // 0x1130880: ldur            lr, [fp, #-0x88]
    // 0x1130884: stp             lr, x16, [SP, #8]
    // 0x1130888: str             x0, [SP]
    // 0x113088c: r17 = -312
    //     0x113088c: mov             x17, #-0x138
    // 0x1130890: ldr             x1, [fp, x17]
    // 0x1130894: r17 = -304
    //     0x1130894: mov             x17, #-0x130
    // 0x1130898: ldr             x2, [fp, x17]
    // 0x113089c: r4 = const [0, 0x13, 0x11, 0x13, null]
    //     0x113089c: add             x4, PP, #0x26, lsl #12  ; [pp+0x267f0] List(5) [0, 0x13, 0x11, 0x13, Null]
    //     0x11308a0: ldr             x4, [x4, #0x7f0]
    // 0x11308a4: r0 = hash()
    //     0x11308a4: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x11308a8: mov             x2, x0
    // 0x11308ac: r0 = BoxInt64Instr(r2)
    //     0x11308ac: sbfiz           x0, x2, #1, #0x1f
    //     0x11308b0: cmp             x2, x0, asr #1
    //     0x11308b4: b.eq            #0x11308c0
    //     0x11308b8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x11308bc: stur            x2, [x0, #7]
    // 0x11308c0: ldur            x16, [fp, #-0x48]
    // 0x11308c4: ldur            lr, [fp, #-0x40]
    // 0x11308c8: stp             lr, x16, [SP, #0x70]
    // 0x11308cc: ldur            x16, [fp, #-0x38]
    // 0x11308d0: ldur            lr, [fp, #-0x30]
    // 0x11308d4: stp             lr, x16, [SP, #0x60]
    // 0x11308d8: ldur            x16, [fp, #-0x28]
    // 0x11308dc: ldur            lr, [fp, #-0x20]
    // 0x11308e0: stp             lr, x16, [SP, #0x50]
    // 0x11308e4: ldur            x16, [fp, #-0x18]
    // 0x11308e8: ldur            lr, [fp, #-0x10]
    // 0x11308ec: stp             lr, x16, [SP, #0x40]
    // 0x11308f0: ldur            x16, [fp, #-8]
    // 0x11308f4: ldur            lr, [fp, #-0x60]
    // 0x11308f8: stp             lr, x16, [SP, #0x30]
    // 0x11308fc: ldur            x16, [fp, #-0x68]
    // 0x1130900: r17 = -344
    //     0x1130900: mov             x17, #-0x158
    // 0x1130904: ldr             lr, [fp, x17]
    // 0x1130908: stp             lr, x16, [SP, #0x20]
    // 0x113090c: r17 = -336
    //     0x113090c: mov             x17, #-0x150
    // 0x1130910: ldr             x16, [fp, x17]
    // 0x1130914: r17 = -328
    //     0x1130914: mov             x17, #-0x148
    // 0x1130918: ldr             lr, [fp, x17]
    // 0x113091c: stp             lr, x16, [SP, #0x10]
    // 0x1130920: r17 = -320
    //     0x1130920: mov             x17, #-0x140
    // 0x1130924: ldr             x16, [fp, x17]
    // 0x1130928: stp             x0, x16, [SP]
    // 0x113092c: ldur            x1, [fp, #-0x58]
    // 0x1130930: ldur            x2, [fp, #-0x50]
    // 0x1130934: r4 = const [0, 0x12, 0x10, 0x12, null]
    //     0x1130934: add             x4, PP, #0x26, lsl #12  ; [pp+0x267f8] List(5) [0, 0x12, 0x10, 0x12, Null]
    //     0x1130938: ldr             x4, [x4, #0x7f8]
    // 0x113093c: r0 = hash()
    //     0x113093c: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x1130940: mov             x2, x0
    // 0x1130944: r0 = BoxInt64Instr(r2)
    //     0x1130944: sbfiz           x0, x2, #1, #0x1f
    //     0x1130948: cmp             x2, x0, asr #1
    //     0x113094c: b.eq            #0x1130958
    //     0x1130950: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1130954: stur            x2, [x0, #7]
    // 0x1130958: LeaveFrame
    //     0x1130958: mov             SP, fp
    //     0x113095c: ldp             fp, lr, [SP], #0x10
    // 0x1130960: ret
    //     0x1130960: ret             
    // 0x1130964: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1130964: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1130968: b               #0x11302c0
  }
  static _ lerp(/* No info */) {
    // ** addr: 0x1169678, size: 0xf80
    // 0x1169678: EnterFrame
    //     0x1169678: stp             fp, lr, [SP, #-0x10]!
    //     0x116967c: mov             fp, SP
    // 0x1169680: AllocStack(0x1b0)
    //     0x1169680: sub             SP, SP, #0x1b0
    // 0x1169684: SetupParameters(dynamic _ /* r1 => r4, fp-0x28 */, dynamic _ /* r2 => r0, fp-0x30 */)
    //     0x1169684: mov             x4, x1
    //     0x1169688: mov             x0, x2
    //     0x116968c: stur            x1, [fp, #-0x28]
    //     0x1169690: stur            x2, [fp, #-0x30]
    // 0x1169694: CheckStackOverflow
    //     0x1169694: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1169698: cmp             SP, x16
    //     0x116969c: b.ls            #0x116a5c4
    // 0x11696a0: cmp             w4, w0
    // 0x11696a4: b.ne            #0x11696b8
    // 0x11696a8: mov             x0, x4
    // 0x11696ac: LeaveFrame
    //     0x11696ac: mov             SP, fp
    //     0x11696b0: ldp             fp, lr, [SP], #0x10
    // 0x11696b4: ret
    //     0x11696b4: ret             
    // 0x11696b8: d1 = 0.500000
    //     0x11696b8: fmov            d1, #0.50000000
    // 0x11696bc: fcmp            d1, d0
    // 0x11696c0: b.le            #0x11696d4
    // 0x11696c4: LoadField: r1 = r4->field_7
    //     0x11696c4: ldur            w1, [x4, #7]
    // 0x11696c8: DecompressPointer r1
    //     0x11696c8: add             x1, x1, HEAP, lsl #32
    // 0x11696cc: mov             x5, x1
    // 0x11696d0: b               #0x11696e0
    // 0x11696d4: LoadField: r1 = r0->field_7
    //     0x11696d4: ldur            w1, [x0, #7]
    // 0x11696d8: DecompressPointer r1
    //     0x11696d8: add             x1, x1, HEAP, lsl #32
    // 0x11696dc: mov             x5, x1
    // 0x11696e0: stur            x5, [fp, #-0x20]
    // 0x11696e4: LoadField: r6 = r4->field_b
    //     0x11696e4: ldur            w6, [x4, #0xb]
    // 0x11696e8: DecompressPointer r6
    //     0x11696e8: add             x6, x6, HEAP, lsl #32
    // 0x11696ec: stur            x6, [fp, #-0x18]
    // 0x11696f0: LoadField: r7 = r0->field_b
    //     0x11696f0: ldur            w7, [x0, #0xb]
    // 0x11696f4: DecompressPointer r7
    //     0x11696f4: add             x7, x7, HEAP, lsl #32
    // 0x11696f8: stur            x7, [fp, #-0x10]
    // 0x11696fc: r8 = inline_Allocate_Double()
    //     0x11696fc: ldp             x8, x1, [THR, #0x60]  ; THR::top
    //     0x1169700: add             x8, x8, #0x10
    //     0x1169704: cmp             x1, x8
    //     0x1169708: b.ls            #0x116a5cc
    //     0x116970c: str             x8, [THR, #0x60]  ; THR::top
    //     0x1169710: sub             x8, x8, #0xf
    //     0x1169714: mov             x1, #0xe19c
    //     0x1169718: movk            x1, #3, lsl #16
    //     0x116971c: stur            x1, [x8, #-1]
    // 0x1169720: dmb             ishst
    // 0x1169724: StoreField: r8->field_7 = d0
    //     0x1169724: stur            d0, [x8, #7]
    // 0x1169728: mov             x1, x6
    // 0x116972c: mov             x2, x7
    // 0x1169730: mov             x3, x8
    // 0x1169734: stur            x8, [fp, #-8]
    // 0x1169738: r0 = lerp()
    //     0x1169738: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x116973c: mov             x4, x0
    // 0x1169740: ldur            x0, [fp, #-0x28]
    // 0x1169744: stur            x4, [fp, #-0x48]
    // 0x1169748: LoadField: r5 = r0->field_f
    //     0x1169748: ldur            w5, [x0, #0xf]
    // 0x116974c: DecompressPointer r5
    //     0x116974c: add             x5, x5, HEAP, lsl #32
    // 0x1169750: ldur            x6, [fp, #-0x30]
    // 0x1169754: stur            x5, [fp, #-0x40]
    // 0x1169758: LoadField: r7 = r6->field_f
    //     0x1169758: ldur            w7, [x6, #0xf]
    // 0x116975c: DecompressPointer r7
    //     0x116975c: add             x7, x7, HEAP, lsl #32
    // 0x1169760: mov             x1, x5
    // 0x1169764: mov             x2, x7
    // 0x1169768: ldur            x3, [fp, #-8]
    // 0x116976c: stur            x7, [fp, #-0x38]
    // 0x1169770: r0 = lerp()
    //     0x1169770: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1169774: mov             x4, x0
    // 0x1169778: ldur            x0, [fp, #-0x28]
    // 0x116977c: stur            x4, [fp, #-0x50]
    // 0x1169780: LoadField: r1 = r0->field_13
    //     0x1169780: ldur            w1, [x0, #0x13]
    // 0x1169784: DecompressPointer r1
    //     0x1169784: add             x1, x1, HEAP, lsl #32
    // 0x1169788: cmp             w1, NULL
    // 0x116978c: b.ne            #0x1169794
    // 0x1169790: ldur            x1, [fp, #-0x18]
    // 0x1169794: ldur            x5, [fp, #-0x30]
    // 0x1169798: LoadField: r2 = r5->field_13
    //     0x1169798: ldur            w2, [x5, #0x13]
    // 0x116979c: DecompressPointer r2
    //     0x116979c: add             x2, x2, HEAP, lsl #32
    // 0x11697a0: cmp             w2, NULL
    // 0x11697a4: b.ne            #0x11697ac
    // 0x11697a8: ldur            x2, [fp, #-0x10]
    // 0x11697ac: ldur            x3, [fp, #-8]
    // 0x11697b0: r0 = lerp()
    //     0x11697b0: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x11697b4: mov             x4, x0
    // 0x11697b8: ldur            x0, [fp, #-0x28]
    // 0x11697bc: stur            x4, [fp, #-0x58]
    // 0x11697c0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x11697c0: ldur            w1, [x0, #0x17]
    // 0x11697c4: DecompressPointer r1
    //     0x11697c4: add             x1, x1, HEAP, lsl #32
    // 0x11697c8: cmp             w1, NULL
    // 0x11697cc: b.ne            #0x11697d4
    // 0x11697d0: ldur            x1, [fp, #-0x40]
    // 0x11697d4: ldur            x5, [fp, #-0x30]
    // 0x11697d8: ArrayLoad: r2 = r5[0]  ; List_4
    //     0x11697d8: ldur            w2, [x5, #0x17]
    // 0x11697dc: DecompressPointer r2
    //     0x11697dc: add             x2, x2, HEAP, lsl #32
    // 0x11697e0: cmp             w2, NULL
    // 0x11697e4: b.ne            #0x11697ec
    // 0x11697e8: ldur            x2, [fp, #-0x38]
    // 0x11697ec: ldur            x3, [fp, #-8]
    // 0x11697f0: r0 = lerp()
    //     0x11697f0: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x11697f4: mov             x4, x0
    // 0x11697f8: ldur            x0, [fp, #-0x28]
    // 0x11697fc: stur            x4, [fp, #-0x60]
    // 0x1169800: LoadField: r1 = r0->field_1b
    //     0x1169800: ldur            w1, [x0, #0x1b]
    // 0x1169804: DecompressPointer r1
    //     0x1169804: add             x1, x1, HEAP, lsl #32
    // 0x1169808: cmp             w1, NULL
    // 0x116980c: b.ne            #0x1169814
    // 0x1169810: ldur            x1, [fp, #-0x18]
    // 0x1169814: ldur            x5, [fp, #-0x30]
    // 0x1169818: LoadField: r2 = r5->field_1b
    //     0x1169818: ldur            w2, [x5, #0x1b]
    // 0x116981c: DecompressPointer r2
    //     0x116981c: add             x2, x2, HEAP, lsl #32
    // 0x1169820: cmp             w2, NULL
    // 0x1169824: b.ne            #0x116982c
    // 0x1169828: ldur            x2, [fp, #-0x10]
    // 0x116982c: ldur            x3, [fp, #-8]
    // 0x1169830: r0 = lerp()
    //     0x1169830: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1169834: mov             x4, x0
    // 0x1169838: ldur            x0, [fp, #-0x28]
    // 0x116983c: stur            x4, [fp, #-0x68]
    // 0x1169840: LoadField: r1 = r0->field_1f
    //     0x1169840: ldur            w1, [x0, #0x1f]
    // 0x1169844: DecompressPointer r1
    //     0x1169844: add             x1, x1, HEAP, lsl #32
    // 0x1169848: cmp             w1, NULL
    // 0x116984c: b.ne            #0x1169854
    // 0x1169850: ldur            x1, [fp, #-0x18]
    // 0x1169854: ldur            x5, [fp, #-0x30]
    // 0x1169858: LoadField: r2 = r5->field_1f
    //     0x1169858: ldur            w2, [x5, #0x1f]
    // 0x116985c: DecompressPointer r2
    //     0x116985c: add             x2, x2, HEAP, lsl #32
    // 0x1169860: cmp             w2, NULL
    // 0x1169864: b.ne            #0x116986c
    // 0x1169868: ldur            x2, [fp, #-0x10]
    // 0x116986c: ldur            x3, [fp, #-8]
    // 0x1169870: r0 = lerp()
    //     0x1169870: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1169874: mov             x4, x0
    // 0x1169878: ldur            x0, [fp, #-0x28]
    // 0x116987c: stur            x4, [fp, #-0x70]
    // 0x1169880: LoadField: r1 = r0->field_23
    //     0x1169880: ldur            w1, [x0, #0x23]
    // 0x1169884: DecompressPointer r1
    //     0x1169884: add             x1, x1, HEAP, lsl #32
    // 0x1169888: cmp             w1, NULL
    // 0x116988c: b.ne            #0x1169894
    // 0x1169890: ldur            x1, [fp, #-0x40]
    // 0x1169894: ldur            x5, [fp, #-0x30]
    // 0x1169898: LoadField: r2 = r5->field_23
    //     0x1169898: ldur            w2, [x5, #0x23]
    // 0x116989c: DecompressPointer r2
    //     0x116989c: add             x2, x2, HEAP, lsl #32
    // 0x11698a0: cmp             w2, NULL
    // 0x11698a4: b.ne            #0x11698ac
    // 0x11698a8: ldur            x2, [fp, #-0x38]
    // 0x11698ac: ldur            x3, [fp, #-8]
    // 0x11698b0: r0 = lerp()
    //     0x11698b0: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x11698b4: mov             x4, x0
    // 0x11698b8: ldur            x0, [fp, #-0x28]
    // 0x11698bc: stur            x4, [fp, #-0x78]
    // 0x11698c0: LoadField: r1 = r0->field_27
    //     0x11698c0: ldur            w1, [x0, #0x27]
    // 0x11698c4: DecompressPointer r1
    //     0x11698c4: add             x1, x1, HEAP, lsl #32
    // 0x11698c8: cmp             w1, NULL
    // 0x11698cc: b.ne            #0x11698d4
    // 0x11698d0: ldur            x1, [fp, #-0x40]
    // 0x11698d4: ldur            x5, [fp, #-0x30]
    // 0x11698d8: LoadField: r2 = r5->field_27
    //     0x11698d8: ldur            w2, [x5, #0x27]
    // 0x11698dc: DecompressPointer r2
    //     0x11698dc: add             x2, x2, HEAP, lsl #32
    // 0x11698e0: cmp             w2, NULL
    // 0x11698e4: b.ne            #0x11698ec
    // 0x11698e8: ldur            x2, [fp, #-0x38]
    // 0x11698ec: ldur            x3, [fp, #-8]
    // 0x11698f0: r0 = lerp()
    //     0x11698f0: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x11698f4: mov             x4, x0
    // 0x11698f8: ldur            x0, [fp, #-0x28]
    // 0x11698fc: stur            x4, [fp, #-0x90]
    // 0x1169900: LoadField: r5 = r0->field_2b
    //     0x1169900: ldur            w5, [x0, #0x2b]
    // 0x1169904: DecompressPointer r5
    //     0x1169904: add             x5, x5, HEAP, lsl #32
    // 0x1169908: ldur            x6, [fp, #-0x30]
    // 0x116990c: stur            x5, [fp, #-0x88]
    // 0x1169910: LoadField: r7 = r6->field_2b
    //     0x1169910: ldur            w7, [x6, #0x2b]
    // 0x1169914: DecompressPointer r7
    //     0x1169914: add             x7, x7, HEAP, lsl #32
    // 0x1169918: mov             x1, x5
    // 0x116991c: mov             x2, x7
    // 0x1169920: ldur            x3, [fp, #-8]
    // 0x1169924: stur            x7, [fp, #-0x80]
    // 0x1169928: r0 = lerp()
    //     0x1169928: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x116992c: mov             x4, x0
    // 0x1169930: ldur            x0, [fp, #-0x28]
    // 0x1169934: stur            x4, [fp, #-0xa8]
    // 0x1169938: LoadField: r5 = r0->field_2f
    //     0x1169938: ldur            w5, [x0, #0x2f]
    // 0x116993c: DecompressPointer r5
    //     0x116993c: add             x5, x5, HEAP, lsl #32
    // 0x1169940: ldur            x6, [fp, #-0x30]
    // 0x1169944: stur            x5, [fp, #-0xa0]
    // 0x1169948: LoadField: r7 = r6->field_2f
    //     0x1169948: ldur            w7, [x6, #0x2f]
    // 0x116994c: DecompressPointer r7
    //     0x116994c: add             x7, x7, HEAP, lsl #32
    // 0x1169950: mov             x1, x5
    // 0x1169954: mov             x2, x7
    // 0x1169958: ldur            x3, [fp, #-8]
    // 0x116995c: stur            x7, [fp, #-0x98]
    // 0x1169960: r0 = lerp()
    //     0x1169960: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1169964: mov             x4, x0
    // 0x1169968: ldur            x0, [fp, #-0x28]
    // 0x116996c: stur            x4, [fp, #-0xb0]
    // 0x1169970: LoadField: r1 = r0->field_33
    //     0x1169970: ldur            w1, [x0, #0x33]
    // 0x1169974: DecompressPointer r1
    //     0x1169974: add             x1, x1, HEAP, lsl #32
    // 0x1169978: cmp             w1, NULL
    // 0x116997c: b.ne            #0x1169984
    // 0x1169980: ldur            x1, [fp, #-0x88]
    // 0x1169984: ldur            x5, [fp, #-0x30]
    // 0x1169988: LoadField: r2 = r5->field_33
    //     0x1169988: ldur            w2, [x5, #0x33]
    // 0x116998c: DecompressPointer r2
    //     0x116998c: add             x2, x2, HEAP, lsl #32
    // 0x1169990: cmp             w2, NULL
    // 0x1169994: b.ne            #0x116999c
    // 0x1169998: ldur            x2, [fp, #-0x80]
    // 0x116999c: ldur            x3, [fp, #-8]
    // 0x11699a0: r0 = lerp()
    //     0x11699a0: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x11699a4: mov             x4, x0
    // 0x11699a8: ldur            x0, [fp, #-0x28]
    // 0x11699ac: stur            x4, [fp, #-0xb8]
    // 0x11699b0: LoadField: r1 = r0->field_37
    //     0x11699b0: ldur            w1, [x0, #0x37]
    // 0x11699b4: DecompressPointer r1
    //     0x11699b4: add             x1, x1, HEAP, lsl #32
    // 0x11699b8: cmp             w1, NULL
    // 0x11699bc: b.ne            #0x11699c4
    // 0x11699c0: ldur            x1, [fp, #-0xa0]
    // 0x11699c4: ldur            x5, [fp, #-0x30]
    // 0x11699c8: LoadField: r2 = r5->field_37
    //     0x11699c8: ldur            w2, [x5, #0x37]
    // 0x11699cc: DecompressPointer r2
    //     0x11699cc: add             x2, x2, HEAP, lsl #32
    // 0x11699d0: cmp             w2, NULL
    // 0x11699d4: b.ne            #0x11699dc
    // 0x11699d8: ldur            x2, [fp, #-0x98]
    // 0x11699dc: ldur            x3, [fp, #-8]
    // 0x11699e0: r0 = lerp()
    //     0x11699e0: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x11699e4: mov             x4, x0
    // 0x11699e8: ldur            x0, [fp, #-0x28]
    // 0x11699ec: stur            x4, [fp, #-0xc0]
    // 0x11699f0: LoadField: r1 = r0->field_3b
    //     0x11699f0: ldur            w1, [x0, #0x3b]
    // 0x11699f4: DecompressPointer r1
    //     0x11699f4: add             x1, x1, HEAP, lsl #32
    // 0x11699f8: cmp             w1, NULL
    // 0x11699fc: b.ne            #0x1169a04
    // 0x1169a00: ldur            x1, [fp, #-0x88]
    // 0x1169a04: ldur            x5, [fp, #-0x30]
    // 0x1169a08: LoadField: r2 = r5->field_3b
    //     0x1169a08: ldur            w2, [x5, #0x3b]
    // 0x1169a0c: DecompressPointer r2
    //     0x1169a0c: add             x2, x2, HEAP, lsl #32
    // 0x1169a10: cmp             w2, NULL
    // 0x1169a14: b.ne            #0x1169a1c
    // 0x1169a18: ldur            x2, [fp, #-0x80]
    // 0x1169a1c: ldur            x3, [fp, #-8]
    // 0x1169a20: r0 = lerp()
    //     0x1169a20: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1169a24: mov             x4, x0
    // 0x1169a28: ldur            x0, [fp, #-0x28]
    // 0x1169a2c: stur            x4, [fp, #-0xc8]
    // 0x1169a30: LoadField: r1 = r0->field_3f
    //     0x1169a30: ldur            w1, [x0, #0x3f]
    // 0x1169a34: DecompressPointer r1
    //     0x1169a34: add             x1, x1, HEAP, lsl #32
    // 0x1169a38: cmp             w1, NULL
    // 0x1169a3c: b.ne            #0x1169a44
    // 0x1169a40: ldur            x1, [fp, #-0x88]
    // 0x1169a44: ldur            x5, [fp, #-0x30]
    // 0x1169a48: LoadField: r2 = r5->field_3f
    //     0x1169a48: ldur            w2, [x5, #0x3f]
    // 0x1169a4c: DecompressPointer r2
    //     0x1169a4c: add             x2, x2, HEAP, lsl #32
    // 0x1169a50: cmp             w2, NULL
    // 0x1169a54: b.ne            #0x1169a5c
    // 0x1169a58: ldur            x2, [fp, #-0x80]
    // 0x1169a5c: ldur            x3, [fp, #-8]
    // 0x1169a60: r0 = lerp()
    //     0x1169a60: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1169a64: mov             x4, x0
    // 0x1169a68: ldur            x0, [fp, #-0x28]
    // 0x1169a6c: stur            x4, [fp, #-0xd0]
    // 0x1169a70: LoadField: r1 = r0->field_43
    //     0x1169a70: ldur            w1, [x0, #0x43]
    // 0x1169a74: DecompressPointer r1
    //     0x1169a74: add             x1, x1, HEAP, lsl #32
    // 0x1169a78: cmp             w1, NULL
    // 0x1169a7c: b.ne            #0x1169a84
    // 0x1169a80: ldur            x1, [fp, #-0xa0]
    // 0x1169a84: ldur            x5, [fp, #-0x30]
    // 0x1169a88: LoadField: r2 = r5->field_43
    //     0x1169a88: ldur            w2, [x5, #0x43]
    // 0x1169a8c: DecompressPointer r2
    //     0x1169a8c: add             x2, x2, HEAP, lsl #32
    // 0x1169a90: cmp             w2, NULL
    // 0x1169a94: b.ne            #0x1169a9c
    // 0x1169a98: ldur            x2, [fp, #-0x98]
    // 0x1169a9c: ldur            x3, [fp, #-8]
    // 0x1169aa0: r0 = lerp()
    //     0x1169aa0: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1169aa4: mov             x4, x0
    // 0x1169aa8: ldur            x0, [fp, #-0x28]
    // 0x1169aac: stur            x4, [fp, #-0xd8]
    // 0x1169ab0: LoadField: r1 = r0->field_47
    //     0x1169ab0: ldur            w1, [x0, #0x47]
    // 0x1169ab4: DecompressPointer r1
    //     0x1169ab4: add             x1, x1, HEAP, lsl #32
    // 0x1169ab8: cmp             w1, NULL
    // 0x1169abc: b.ne            #0x1169ac4
    // 0x1169ac0: ldur            x1, [fp, #-0xa0]
    // 0x1169ac4: ldur            x5, [fp, #-0x30]
    // 0x1169ac8: LoadField: r2 = r5->field_47
    //     0x1169ac8: ldur            w2, [x5, #0x47]
    // 0x1169acc: DecompressPointer r2
    //     0x1169acc: add             x2, x2, HEAP, lsl #32
    // 0x1169ad0: cmp             w2, NULL
    // 0x1169ad4: b.ne            #0x1169adc
    // 0x1169ad8: ldur            x2, [fp, #-0x98]
    // 0x1169adc: ldur            x3, [fp, #-8]
    // 0x1169ae0: r0 = lerp()
    //     0x1169ae0: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1169ae4: mov             x4, x0
    // 0x1169ae8: ldur            x0, [fp, #-0x28]
    // 0x1169aec: stur            x4, [fp, #-0xe0]
    // 0x1169af0: LoadField: r1 = r0->field_4b
    //     0x1169af0: ldur            w1, [x0, #0x4b]
    // 0x1169af4: DecompressPointer r1
    //     0x1169af4: add             x1, x1, HEAP, lsl #32
    // 0x1169af8: cmp             w1, NULL
    // 0x1169afc: b.ne            #0x1169b04
    // 0x1169b00: ldur            x1, [fp, #-0x88]
    // 0x1169b04: ldur            x5, [fp, #-0x30]
    // 0x1169b08: LoadField: r2 = r5->field_4b
    //     0x1169b08: ldur            w2, [x5, #0x4b]
    // 0x1169b0c: DecompressPointer r2
    //     0x1169b0c: add             x2, x2, HEAP, lsl #32
    // 0x1169b10: cmp             w2, NULL
    // 0x1169b14: b.ne            #0x1169b1c
    // 0x1169b18: ldur            x2, [fp, #-0x80]
    // 0x1169b1c: ldur            x3, [fp, #-8]
    // 0x1169b20: r0 = lerp()
    //     0x1169b20: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1169b24: mov             x4, x0
    // 0x1169b28: ldur            x0, [fp, #-0x28]
    // 0x1169b2c: stur            x4, [fp, #-0x80]
    // 0x1169b30: LoadField: r1 = r0->field_4f
    //     0x1169b30: ldur            w1, [x0, #0x4f]
    // 0x1169b34: DecompressPointer r1
    //     0x1169b34: add             x1, x1, HEAP, lsl #32
    // 0x1169b38: cmp             w1, NULL
    // 0x1169b3c: b.ne            #0x1169b44
    // 0x1169b40: ldur            x1, [fp, #-0xa0]
    // 0x1169b44: ldur            x5, [fp, #-0x30]
    // 0x1169b48: LoadField: r2 = r5->field_4f
    //     0x1169b48: ldur            w2, [x5, #0x4f]
    // 0x1169b4c: DecompressPointer r2
    //     0x1169b4c: add             x2, x2, HEAP, lsl #32
    // 0x1169b50: cmp             w2, NULL
    // 0x1169b54: b.ne            #0x1169b5c
    // 0x1169b58: ldur            x2, [fp, #-0x98]
    // 0x1169b5c: ldur            x3, [fp, #-8]
    // 0x1169b60: r0 = lerp()
    //     0x1169b60: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1169b64: ldur            x1, [fp, #-0x28]
    // 0x1169b68: stur            x0, [fp, #-0x88]
    // 0x1169b6c: r0 = tertiaryContainer()
    //     0x1169b6c: bl              #0x8a91b4  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::tertiaryContainer
    // 0x1169b70: ldur            x1, [fp, #-0x30]
    // 0x1169b74: stur            x0, [fp, #-0x98]
    // 0x1169b78: r0 = tertiaryContainer()
    //     0x1169b78: bl              #0x8a91b4  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::tertiaryContainer
    // 0x1169b7c: ldur            x1, [fp, #-0x98]
    // 0x1169b80: mov             x2, x0
    // 0x1169b84: ldur            x3, [fp, #-8]
    // 0x1169b88: r0 = lerp()
    //     0x1169b88: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1169b8c: ldur            x1, [fp, #-0x28]
    // 0x1169b90: stur            x0, [fp, #-0x98]
    // 0x1169b94: r0 = onTertiaryContainer()
    //     0x1169b94: bl              #0x8a9170  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::onTertiaryContainer
    // 0x1169b98: ldur            x1, [fp, #-0x30]
    // 0x1169b9c: stur            x0, [fp, #-0xa0]
    // 0x1169ba0: r0 = onTertiaryContainer()
    //     0x1169ba0: bl              #0x8a9170  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::onTertiaryContainer
    // 0x1169ba4: ldur            x1, [fp, #-0xa0]
    // 0x1169ba8: mov             x2, x0
    // 0x1169bac: ldur            x3, [fp, #-8]
    // 0x1169bb0: r0 = lerp()
    //     0x1169bb0: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1169bb4: ldur            x1, [fp, #-0x28]
    // 0x1169bb8: stur            x0, [fp, #-0xa0]
    // 0x1169bbc: r0 = tertiaryFixed()
    //     0x1169bbc: bl              #0x8a912c  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::tertiaryFixed
    // 0x1169bc0: ldur            x1, [fp, #-0x30]
    // 0x1169bc4: stur            x0, [fp, #-0xe8]
    // 0x1169bc8: r0 = tertiaryFixed()
    //     0x1169bc8: bl              #0x8a912c  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::tertiaryFixed
    // 0x1169bcc: ldur            x1, [fp, #-0xe8]
    // 0x1169bd0: mov             x2, x0
    // 0x1169bd4: ldur            x3, [fp, #-8]
    // 0x1169bd8: r0 = lerp()
    //     0x1169bd8: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1169bdc: ldur            x1, [fp, #-0x28]
    // 0x1169be0: stur            x0, [fp, #-0xe8]
    // 0x1169be4: r0 = tertiaryFixedDim()
    //     0x1169be4: bl              #0x8a90e8  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::tertiaryFixedDim
    // 0x1169be8: ldur            x1, [fp, #-0x30]
    // 0x1169bec: stur            x0, [fp, #-0xf0]
    // 0x1169bf0: r0 = tertiaryFixedDim()
    //     0x1169bf0: bl              #0x8a90e8  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::tertiaryFixedDim
    // 0x1169bf4: ldur            x1, [fp, #-0xf0]
    // 0x1169bf8: mov             x2, x0
    // 0x1169bfc: ldur            x3, [fp, #-8]
    // 0x1169c00: r0 = lerp()
    //     0x1169c00: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1169c04: ldur            x1, [fp, #-0x28]
    // 0x1169c08: stur            x0, [fp, #-0xf0]
    // 0x1169c0c: r0 = onTertiaryFixed()
    //     0x1169c0c: bl              #0x8a90a4  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::onTertiaryFixed
    // 0x1169c10: ldur            x1, [fp, #-0x30]
    // 0x1169c14: stur            x0, [fp, #-0xf8]
    // 0x1169c18: r0 = onTertiaryFixed()
    //     0x1169c18: bl              #0x8a90a4  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::onTertiaryFixed
    // 0x1169c1c: ldur            x1, [fp, #-0xf8]
    // 0x1169c20: mov             x2, x0
    // 0x1169c24: ldur            x3, [fp, #-8]
    // 0x1169c28: r0 = lerp()
    //     0x1169c28: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1169c2c: ldur            x1, [fp, #-0x28]
    // 0x1169c30: stur            x0, [fp, #-0xf8]
    // 0x1169c34: r0 = onTertiaryFixedVariant()
    //     0x1169c34: bl              #0x8a9060  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::onTertiaryFixedVariant
    // 0x1169c38: ldur            x1, [fp, #-0x30]
    // 0x1169c3c: stur            x0, [fp, #-0x100]
    // 0x1169c40: r0 = onTertiaryFixedVariant()
    //     0x1169c40: bl              #0x8a9060  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::onTertiaryFixedVariant
    // 0x1169c44: ldur            x1, [fp, #-0x100]
    // 0x1169c48: mov             x2, x0
    // 0x1169c4c: ldur            x3, [fp, #-8]
    // 0x1169c50: r0 = lerp()
    //     0x1169c50: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1169c54: mov             x4, x0
    // 0x1169c58: ldur            x0, [fp, #-0x28]
    // 0x1169c5c: r17 = -272
    //     0x1169c5c: mov             x17, #-0x110
    // 0x1169c60: str             x4, [fp, x17]
    // 0x1169c64: LoadField: r5 = r0->field_6b
    //     0x1169c64: ldur            w5, [x0, #0x6b]
    // 0x1169c68: DecompressPointer r5
    //     0x1169c68: add             x5, x5, HEAP, lsl #32
    // 0x1169c6c: ldur            x6, [fp, #-0x30]
    // 0x1169c70: r17 = -264
    //     0x1169c70: mov             x17, #-0x108
    // 0x1169c74: str             x5, [fp, x17]
    // 0x1169c78: LoadField: r7 = r6->field_6b
    //     0x1169c78: ldur            w7, [x6, #0x6b]
    // 0x1169c7c: DecompressPointer r7
    //     0x1169c7c: add             x7, x7, HEAP, lsl #32
    // 0x1169c80: mov             x1, x5
    // 0x1169c84: mov             x2, x7
    // 0x1169c88: ldur            x3, [fp, #-8]
    // 0x1169c8c: stur            x7, [fp, #-0x100]
    // 0x1169c90: r0 = lerp()
    //     0x1169c90: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1169c94: mov             x4, x0
    // 0x1169c98: ldur            x0, [fp, #-0x28]
    // 0x1169c9c: r17 = -296
    //     0x1169c9c: mov             x17, #-0x128
    // 0x1169ca0: str             x4, [fp, x17]
    // 0x1169ca4: LoadField: r5 = r0->field_6f
    //     0x1169ca4: ldur            w5, [x0, #0x6f]
    // 0x1169ca8: DecompressPointer r5
    //     0x1169ca8: add             x5, x5, HEAP, lsl #32
    // 0x1169cac: ldur            x6, [fp, #-0x30]
    // 0x1169cb0: r17 = -288
    //     0x1169cb0: mov             x17, #-0x120
    // 0x1169cb4: str             x5, [fp, x17]
    // 0x1169cb8: LoadField: r7 = r6->field_6f
    //     0x1169cb8: ldur            w7, [x6, #0x6f]
    // 0x1169cbc: DecompressPointer r7
    //     0x1169cbc: add             x7, x7, HEAP, lsl #32
    // 0x1169cc0: mov             x1, x5
    // 0x1169cc4: mov             x2, x7
    // 0x1169cc8: ldur            x3, [fp, #-8]
    // 0x1169ccc: r17 = -280
    //     0x1169ccc: mov             x17, #-0x118
    // 0x1169cd0: str             x7, [fp, x17]
    // 0x1169cd4: r0 = lerp()
    //     0x1169cd4: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1169cd8: mov             x4, x0
    // 0x1169cdc: ldur            x0, [fp, #-0x28]
    // 0x1169ce0: r17 = -304
    //     0x1169ce0: mov             x17, #-0x130
    // 0x1169ce4: str             x4, [fp, x17]
    // 0x1169ce8: LoadField: r1 = r0->field_73
    //     0x1169ce8: ldur            w1, [x0, #0x73]
    // 0x1169cec: DecompressPointer r1
    //     0x1169cec: add             x1, x1, HEAP, lsl #32
    // 0x1169cf0: cmp             w1, NULL
    // 0x1169cf4: b.ne            #0x1169d00
    // 0x1169cf8: r17 = -264
    //     0x1169cf8: mov             x17, #-0x108
    // 0x1169cfc: ldr             x1, [fp, x17]
    // 0x1169d00: ldur            x5, [fp, #-0x30]
    // 0x1169d04: LoadField: r2 = r5->field_73
    //     0x1169d04: ldur            w2, [x5, #0x73]
    // 0x1169d08: DecompressPointer r2
    //     0x1169d08: add             x2, x2, HEAP, lsl #32
    // 0x1169d0c: cmp             w2, NULL
    // 0x1169d10: b.ne            #0x1169d18
    // 0x1169d14: ldur            x2, [fp, #-0x100]
    // 0x1169d18: ldur            x3, [fp, #-8]
    // 0x1169d1c: r0 = lerp()
    //     0x1169d1c: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1169d20: mov             x4, x0
    // 0x1169d24: ldur            x0, [fp, #-0x28]
    // 0x1169d28: stur            x4, [fp, #-0x100]
    // 0x1169d2c: LoadField: r1 = r0->field_77
    //     0x1169d2c: ldur            w1, [x0, #0x77]
    // 0x1169d30: DecompressPointer r1
    //     0x1169d30: add             x1, x1, HEAP, lsl #32
    // 0x1169d34: cmp             w1, NULL
    // 0x1169d38: b.ne            #0x1169d44
    // 0x1169d3c: r17 = -288
    //     0x1169d3c: mov             x17, #-0x120
    // 0x1169d40: ldr             x1, [fp, x17]
    // 0x1169d44: ldur            x5, [fp, #-0x30]
    // 0x1169d48: LoadField: r2 = r5->field_77
    //     0x1169d48: ldur            w2, [x5, #0x77]
    // 0x1169d4c: DecompressPointer r2
    //     0x1169d4c: add             x2, x2, HEAP, lsl #32
    // 0x1169d50: cmp             w2, NULL
    // 0x1169d54: b.ne            #0x1169d60
    // 0x1169d58: r17 = -280
    //     0x1169d58: mov             x17, #-0x118
    // 0x1169d5c: ldr             x2, [fp, x17]
    // 0x1169d60: ldur            x3, [fp, #-8]
    // 0x1169d64: r0 = lerp()
    //     0x1169d64: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1169d68: mov             x4, x0
    // 0x1169d6c: ldur            x0, [fp, #-0x28]
    // 0x1169d70: r17 = -288
    //     0x1169d70: mov             x17, #-0x120
    // 0x1169d74: str             x4, [fp, x17]
    // 0x1169d78: LoadField: r5 = r0->field_7b
    //     0x1169d78: ldur            w5, [x0, #0x7b]
    // 0x1169d7c: DecompressPointer r5
    //     0x1169d7c: add             x5, x5, HEAP, lsl #32
    // 0x1169d80: ldur            x6, [fp, #-0x30]
    // 0x1169d84: r17 = -280
    //     0x1169d84: mov             x17, #-0x118
    // 0x1169d88: str             x5, [fp, x17]
    // 0x1169d8c: LoadField: r7 = r6->field_7b
    //     0x1169d8c: ldur            w7, [x6, #0x7b]
    // 0x1169d90: DecompressPointer r7
    //     0x1169d90: add             x7, x7, HEAP, lsl #32
    // 0x1169d94: mov             x1, x5
    // 0x1169d98: mov             x2, x7
    // 0x1169d9c: ldur            x3, [fp, #-8]
    // 0x1169da0: r17 = -264
    //     0x1169da0: mov             x17, #-0x108
    // 0x1169da4: str             x7, [fp, x17]
    // 0x1169da8: r0 = lerp()
    //     0x1169da8: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1169dac: mov             x4, x0
    // 0x1169db0: ldur            x0, [fp, #-0x28]
    // 0x1169db4: r17 = -328
    //     0x1169db4: mov             x17, #-0x148
    // 0x1169db8: str             x4, [fp, x17]
    // 0x1169dbc: LoadField: r5 = r0->field_7f
    //     0x1169dbc: ldur            w5, [x0, #0x7f]
    // 0x1169dc0: DecompressPointer r5
    //     0x1169dc0: add             x5, x5, HEAP, lsl #32
    // 0x1169dc4: ldur            x6, [fp, #-0x30]
    // 0x1169dc8: r17 = -320
    //     0x1169dc8: mov             x17, #-0x140
    // 0x1169dcc: str             x5, [fp, x17]
    // 0x1169dd0: LoadField: r7 = r6->field_7f
    //     0x1169dd0: ldur            w7, [x6, #0x7f]
    // 0x1169dd4: DecompressPointer r7
    //     0x1169dd4: add             x7, x7, HEAP, lsl #32
    // 0x1169dd8: mov             x1, x5
    // 0x1169ddc: mov             x2, x7
    // 0x1169de0: ldur            x3, [fp, #-8]
    // 0x1169de4: r17 = -312
    //     0x1169de4: mov             x17, #-0x138
    // 0x1169de8: str             x7, [fp, x17]
    // 0x1169dec: r0 = lerp()
    //     0x1169dec: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1169df0: mov             x4, x0
    // 0x1169df4: ldur            x0, [fp, #-0x28]
    // 0x1169df8: r17 = -336
    //     0x1169df8: mov             x17, #-0x150
    // 0x1169dfc: str             x4, [fp, x17]
    // 0x1169e00: LoadField: r1 = r0->field_87
    //     0x1169e00: ldur            w1, [x0, #0x87]
    // 0x1169e04: DecompressPointer r1
    //     0x1169e04: add             x1, x1, HEAP, lsl #32
    // 0x1169e08: cmp             w1, NULL
    // 0x1169e0c: b.ne            #0x1169e18
    // 0x1169e10: r17 = -280
    //     0x1169e10: mov             x17, #-0x118
    // 0x1169e14: ldr             x1, [fp, x17]
    // 0x1169e18: ldur            x5, [fp, #-0x30]
    // 0x1169e1c: LoadField: r2 = r5->field_87
    //     0x1169e1c: ldur            w2, [x5, #0x87]
    // 0x1169e20: DecompressPointer r2
    //     0x1169e20: add             x2, x2, HEAP, lsl #32
    // 0x1169e24: cmp             w2, NULL
    // 0x1169e28: b.ne            #0x1169e34
    // 0x1169e2c: r17 = -264
    //     0x1169e2c: mov             x17, #-0x108
    // 0x1169e30: ldr             x2, [fp, x17]
    // 0x1169e34: ldur            x3, [fp, #-8]
    // 0x1169e38: r0 = lerp()
    //     0x1169e38: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1169e3c: mov             x4, x0
    // 0x1169e40: ldur            x0, [fp, #-0x28]
    // 0x1169e44: r17 = -344
    //     0x1169e44: mov             x17, #-0x158
    // 0x1169e48: str             x4, [fp, x17]
    // 0x1169e4c: LoadField: r1 = r0->field_8b
    //     0x1169e4c: ldur            w1, [x0, #0x8b]
    // 0x1169e50: DecompressPointer r1
    //     0x1169e50: add             x1, x1, HEAP, lsl #32
    // 0x1169e54: cmp             w1, NULL
    // 0x1169e58: b.ne            #0x1169e64
    // 0x1169e5c: r17 = -280
    //     0x1169e5c: mov             x17, #-0x118
    // 0x1169e60: ldr             x1, [fp, x17]
    // 0x1169e64: ldur            x5, [fp, #-0x30]
    // 0x1169e68: LoadField: r2 = r5->field_8b
    //     0x1169e68: ldur            w2, [x5, #0x8b]
    // 0x1169e6c: DecompressPointer r2
    //     0x1169e6c: add             x2, x2, HEAP, lsl #32
    // 0x1169e70: cmp             w2, NULL
    // 0x1169e74: b.ne            #0x1169e80
    // 0x1169e78: r17 = -264
    //     0x1169e78: mov             x17, #-0x108
    // 0x1169e7c: ldr             x2, [fp, x17]
    // 0x1169e80: ldur            x3, [fp, #-8]
    // 0x1169e84: r0 = lerp()
    //     0x1169e84: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1169e88: mov             x4, x0
    // 0x1169e8c: ldur            x0, [fp, #-0x28]
    // 0x1169e90: r17 = -352
    //     0x1169e90: mov             x17, #-0x160
    // 0x1169e94: str             x4, [fp, x17]
    // 0x1169e98: LoadField: r1 = r0->field_8f
    //     0x1169e98: ldur            w1, [x0, #0x8f]
    // 0x1169e9c: DecompressPointer r1
    //     0x1169e9c: add             x1, x1, HEAP, lsl #32
    // 0x1169ea0: cmp             w1, NULL
    // 0x1169ea4: b.ne            #0x1169eb0
    // 0x1169ea8: r17 = -280
    //     0x1169ea8: mov             x17, #-0x118
    // 0x1169eac: ldr             x1, [fp, x17]
    // 0x1169eb0: ldur            x5, [fp, #-0x30]
    // 0x1169eb4: LoadField: r2 = r5->field_8f
    //     0x1169eb4: ldur            w2, [x5, #0x8f]
    // 0x1169eb8: DecompressPointer r2
    //     0x1169eb8: add             x2, x2, HEAP, lsl #32
    // 0x1169ebc: cmp             w2, NULL
    // 0x1169ec0: b.ne            #0x1169ecc
    // 0x1169ec4: r17 = -264
    //     0x1169ec4: mov             x17, #-0x108
    // 0x1169ec8: ldr             x2, [fp, x17]
    // 0x1169ecc: ldur            x3, [fp, #-8]
    // 0x1169ed0: r0 = lerp()
    //     0x1169ed0: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1169ed4: mov             x4, x0
    // 0x1169ed8: ldur            x0, [fp, #-0x28]
    // 0x1169edc: r17 = -360
    //     0x1169edc: mov             x17, #-0x168
    // 0x1169ee0: str             x4, [fp, x17]
    // 0x1169ee4: LoadField: r1 = r0->field_93
    //     0x1169ee4: ldur            w1, [x0, #0x93]
    // 0x1169ee8: DecompressPointer r1
    //     0x1169ee8: add             x1, x1, HEAP, lsl #32
    // 0x1169eec: cmp             w1, NULL
    // 0x1169ef0: b.ne            #0x1169efc
    // 0x1169ef4: r17 = -280
    //     0x1169ef4: mov             x17, #-0x118
    // 0x1169ef8: ldr             x1, [fp, x17]
    // 0x1169efc: ldur            x5, [fp, #-0x30]
    // 0x1169f00: LoadField: r2 = r5->field_93
    //     0x1169f00: ldur            w2, [x5, #0x93]
    // 0x1169f04: DecompressPointer r2
    //     0x1169f04: add             x2, x2, HEAP, lsl #32
    // 0x1169f08: cmp             w2, NULL
    // 0x1169f0c: b.ne            #0x1169f18
    // 0x1169f10: r17 = -264
    //     0x1169f10: mov             x17, #-0x108
    // 0x1169f14: ldr             x2, [fp, x17]
    // 0x1169f18: ldur            x3, [fp, #-8]
    // 0x1169f1c: r0 = lerp()
    //     0x1169f1c: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1169f20: mov             x4, x0
    // 0x1169f24: ldur            x0, [fp, #-0x28]
    // 0x1169f28: r17 = -368
    //     0x1169f28: mov             x17, #-0x170
    // 0x1169f2c: str             x4, [fp, x17]
    // 0x1169f30: LoadField: r1 = r0->field_97
    //     0x1169f30: ldur            w1, [x0, #0x97]
    // 0x1169f34: DecompressPointer r1
    //     0x1169f34: add             x1, x1, HEAP, lsl #32
    // 0x1169f38: cmp             w1, NULL
    // 0x1169f3c: b.ne            #0x1169f48
    // 0x1169f40: r17 = -280
    //     0x1169f40: mov             x17, #-0x118
    // 0x1169f44: ldr             x1, [fp, x17]
    // 0x1169f48: ldur            x5, [fp, #-0x30]
    // 0x1169f4c: LoadField: r2 = r5->field_97
    //     0x1169f4c: ldur            w2, [x5, #0x97]
    // 0x1169f50: DecompressPointer r2
    //     0x1169f50: add             x2, x2, HEAP, lsl #32
    // 0x1169f54: cmp             w2, NULL
    // 0x1169f58: b.ne            #0x1169f64
    // 0x1169f5c: r17 = -264
    //     0x1169f5c: mov             x17, #-0x108
    // 0x1169f60: ldr             x2, [fp, x17]
    // 0x1169f64: ldur            x3, [fp, #-8]
    // 0x1169f68: r0 = lerp()
    //     0x1169f68: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1169f6c: mov             x4, x0
    // 0x1169f70: ldur            x0, [fp, #-0x28]
    // 0x1169f74: r17 = -376
    //     0x1169f74: mov             x17, #-0x178
    // 0x1169f78: str             x4, [fp, x17]
    // 0x1169f7c: LoadField: r1 = r0->field_9b
    //     0x1169f7c: ldur            w1, [x0, #0x9b]
    // 0x1169f80: DecompressPointer r1
    //     0x1169f80: add             x1, x1, HEAP, lsl #32
    // 0x1169f84: cmp             w1, NULL
    // 0x1169f88: b.ne            #0x1169f94
    // 0x1169f8c: r17 = -280
    //     0x1169f8c: mov             x17, #-0x118
    // 0x1169f90: ldr             x1, [fp, x17]
    // 0x1169f94: ldur            x5, [fp, #-0x30]
    // 0x1169f98: LoadField: r2 = r5->field_9b
    //     0x1169f98: ldur            w2, [x5, #0x9b]
    // 0x1169f9c: DecompressPointer r2
    //     0x1169f9c: add             x2, x2, HEAP, lsl #32
    // 0x1169fa0: cmp             w2, NULL
    // 0x1169fa4: b.ne            #0x1169fb0
    // 0x1169fa8: r17 = -264
    //     0x1169fa8: mov             x17, #-0x108
    // 0x1169fac: ldr             x2, [fp, x17]
    // 0x1169fb0: ldur            x3, [fp, #-8]
    // 0x1169fb4: r0 = lerp()
    //     0x1169fb4: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x1169fb8: mov             x4, x0
    // 0x1169fbc: ldur            x0, [fp, #-0x28]
    // 0x1169fc0: r17 = -384
    //     0x1169fc0: mov             x17, #-0x180
    // 0x1169fc4: str             x4, [fp, x17]
    // 0x1169fc8: LoadField: r1 = r0->field_9f
    //     0x1169fc8: ldur            w1, [x0, #0x9f]
    // 0x1169fcc: DecompressPointer r1
    //     0x1169fcc: add             x1, x1, HEAP, lsl #32
    // 0x1169fd0: cmp             w1, NULL
    // 0x1169fd4: b.ne            #0x1169fe0
    // 0x1169fd8: r17 = -280
    //     0x1169fd8: mov             x17, #-0x118
    // 0x1169fdc: ldr             x1, [fp, x17]
    // 0x1169fe0: ldur            x5, [fp, #-0x30]
    // 0x1169fe4: LoadField: r2 = r5->field_9f
    //     0x1169fe4: ldur            w2, [x5, #0x9f]
    // 0x1169fe8: DecompressPointer r2
    //     0x1169fe8: add             x2, x2, HEAP, lsl #32
    // 0x1169fec: cmp             w2, NULL
    // 0x1169ff0: b.ne            #0x1169ffc
    // 0x1169ff4: r17 = -264
    //     0x1169ff4: mov             x17, #-0x108
    // 0x1169ff8: ldr             x2, [fp, x17]
    // 0x1169ffc: ldur            x3, [fp, #-8]
    // 0x116a000: r0 = lerp()
    //     0x116a000: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x116a004: mov             x4, x0
    // 0x116a008: ldur            x0, [fp, #-0x28]
    // 0x116a00c: r17 = -392
    //     0x116a00c: mov             x17, #-0x188
    // 0x116a010: str             x4, [fp, x17]
    // 0x116a014: LoadField: r1 = r0->field_a3
    //     0x116a014: ldur            w1, [x0, #0xa3]
    // 0x116a018: DecompressPointer r1
    //     0x116a018: add             x1, x1, HEAP, lsl #32
    // 0x116a01c: cmp             w1, NULL
    // 0x116a020: b.ne            #0x116a02c
    // 0x116a024: r17 = -320
    //     0x116a024: mov             x17, #-0x140
    // 0x116a028: ldr             x1, [fp, x17]
    // 0x116a02c: ldur            x5, [fp, #-0x30]
    // 0x116a030: LoadField: r2 = r5->field_a3
    //     0x116a030: ldur            w2, [x5, #0xa3]
    // 0x116a034: DecompressPointer r2
    //     0x116a034: add             x2, x2, HEAP, lsl #32
    // 0x116a038: cmp             w2, NULL
    // 0x116a03c: b.ne            #0x116a048
    // 0x116a040: r17 = -312
    //     0x116a040: mov             x17, #-0x138
    // 0x116a044: ldr             x2, [fp, x17]
    // 0x116a048: ldur            x3, [fp, #-8]
    // 0x116a04c: r0 = lerp()
    //     0x116a04c: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x116a050: mov             x4, x0
    // 0x116a054: ldur            x0, [fp, #-0x28]
    // 0x116a058: r17 = -400
    //     0x116a058: mov             x17, #-0x190
    // 0x116a05c: str             x4, [fp, x17]
    // 0x116a060: LoadField: r1 = r0->field_a7
    //     0x116a060: ldur            w1, [x0, #0xa7]
    // 0x116a064: DecompressPointer r1
    //     0x116a064: add             x1, x1, HEAP, lsl #32
    // 0x116a068: cmp             w1, NULL
    // 0x116a06c: b.ne            #0x116a078
    // 0x116a070: LoadField: r1 = r0->field_cb
    //     0x116a070: ldur            w1, [x0, #0xcb]
    // 0x116a074: DecompressPointer r1
    //     0x116a074: add             x1, x1, HEAP, lsl #32
    // 0x116a078: ldur            x5, [fp, #-0x30]
    // 0x116a07c: LoadField: r2 = r5->field_a7
    //     0x116a07c: ldur            w2, [x5, #0xa7]
    // 0x116a080: DecompressPointer r2
    //     0x116a080: add             x2, x2, HEAP, lsl #32
    // 0x116a084: cmp             w2, NULL
    // 0x116a088: b.ne            #0x116a094
    // 0x116a08c: LoadField: r2 = r5->field_cb
    //     0x116a08c: ldur            w2, [x5, #0xcb]
    // 0x116a090: DecompressPointer r2
    //     0x116a090: add             x2, x2, HEAP, lsl #32
    // 0x116a094: ldur            x3, [fp, #-8]
    // 0x116a098: r0 = lerp()
    //     0x116a098: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x116a09c: mov             x4, x0
    // 0x116a0a0: ldur            x0, [fp, #-0x28]
    // 0x116a0a4: r17 = -408
    //     0x116a0a4: mov             x17, #-0x198
    // 0x116a0a8: str             x4, [fp, x17]
    // 0x116a0ac: LoadField: r1 = r0->field_ab
    //     0x116a0ac: ldur            w1, [x0, #0xab]
    // 0x116a0b0: DecompressPointer r1
    //     0x116a0b0: add             x1, x1, HEAP, lsl #32
    // 0x116a0b4: cmp             w1, NULL
    // 0x116a0b8: b.ne            #0x116a0c4
    // 0x116a0bc: LoadField: r1 = r0->field_cb
    //     0x116a0bc: ldur            w1, [x0, #0xcb]
    // 0x116a0c0: DecompressPointer r1
    //     0x116a0c0: add             x1, x1, HEAP, lsl #32
    // 0x116a0c4: ldur            x5, [fp, #-0x30]
    // 0x116a0c8: LoadField: r2 = r5->field_ab
    //     0x116a0c8: ldur            w2, [x5, #0xab]
    // 0x116a0cc: DecompressPointer r2
    //     0x116a0cc: add             x2, x2, HEAP, lsl #32
    // 0x116a0d0: cmp             w2, NULL
    // 0x116a0d4: b.ne            #0x116a0e0
    // 0x116a0d8: LoadField: r2 = r5->field_cb
    //     0x116a0d8: ldur            w2, [x5, #0xcb]
    // 0x116a0dc: DecompressPointer r2
    //     0x116a0dc: add             x2, x2, HEAP, lsl #32
    // 0x116a0e0: ldur            x3, [fp, #-8]
    // 0x116a0e4: r0 = lerp()
    //     0x116a0e4: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x116a0e8: mov             x4, x0
    // 0x116a0ec: ldur            x0, [fp, #-0x28]
    // 0x116a0f0: r17 = -416
    //     0x116a0f0: mov             x17, #-0x1a0
    // 0x116a0f4: str             x4, [fp, x17]
    // 0x116a0f8: LoadField: r1 = r0->field_af
    //     0x116a0f8: ldur            w1, [x0, #0xaf]
    // 0x116a0fc: DecompressPointer r1
    //     0x116a0fc: add             x1, x1, HEAP, lsl #32
    // 0x116a100: cmp             w1, NULL
    // 0x116a104: b.ne            #0x116a110
    // 0x116a108: r1 = Instance_Color
    //     0x116a108: add             x1, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0x116a10c: ldr             x1, [x1, #0x948]
    // 0x116a110: ldur            x5, [fp, #-0x30]
    // 0x116a114: LoadField: r2 = r5->field_af
    //     0x116a114: ldur            w2, [x5, #0xaf]
    // 0x116a118: DecompressPointer r2
    //     0x116a118: add             x2, x2, HEAP, lsl #32
    // 0x116a11c: cmp             w2, NULL
    // 0x116a120: b.ne            #0x116a12c
    // 0x116a124: r2 = Instance_Color
    //     0x116a124: add             x2, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0x116a128: ldr             x2, [x2, #0x948]
    // 0x116a12c: ldur            x3, [fp, #-8]
    // 0x116a130: r0 = lerp()
    //     0x116a130: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x116a134: mov             x4, x0
    // 0x116a138: ldur            x0, [fp, #-0x28]
    // 0x116a13c: r17 = -424
    //     0x116a13c: mov             x17, #-0x1a8
    // 0x116a140: str             x4, [fp, x17]
    // 0x116a144: LoadField: r1 = r0->field_b3
    //     0x116a144: ldur            w1, [x0, #0xb3]
    // 0x116a148: DecompressPointer r1
    //     0x116a148: add             x1, x1, HEAP, lsl #32
    // 0x116a14c: cmp             w1, NULL
    // 0x116a150: b.ne            #0x116a15c
    // 0x116a154: r1 = Instance_Color
    //     0x116a154: add             x1, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0x116a158: ldr             x1, [x1, #0x948]
    // 0x116a15c: ldur            x5, [fp, #-0x30]
    // 0x116a160: LoadField: r2 = r5->field_b3
    //     0x116a160: ldur            w2, [x5, #0xb3]
    // 0x116a164: DecompressPointer r2
    //     0x116a164: add             x2, x2, HEAP, lsl #32
    // 0x116a168: cmp             w2, NULL
    // 0x116a16c: b.ne            #0x116a178
    // 0x116a170: r2 = Instance_Color
    //     0x116a170: add             x2, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0x116a174: ldr             x2, [x2, #0x948]
    // 0x116a178: ldur            x3, [fp, #-8]
    // 0x116a17c: r0 = lerp()
    //     0x116a17c: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x116a180: mov             x4, x0
    // 0x116a184: ldur            x0, [fp, #-0x28]
    // 0x116a188: r17 = -432
    //     0x116a188: mov             x17, #-0x1b0
    // 0x116a18c: str             x4, [fp, x17]
    // 0x116a190: LoadField: r1 = r0->field_b7
    //     0x116a190: ldur            w1, [x0, #0xb7]
    // 0x116a194: DecompressPointer r1
    //     0x116a194: add             x1, x1, HEAP, lsl #32
    // 0x116a198: cmp             w1, NULL
    // 0x116a19c: b.ne            #0x116a1a8
    // 0x116a1a0: r17 = -320
    //     0x116a1a0: mov             x17, #-0x140
    // 0x116a1a4: ldr             x1, [fp, x17]
    // 0x116a1a8: ldur            x5, [fp, #-0x30]
    // 0x116a1ac: LoadField: r2 = r5->field_b7
    //     0x116a1ac: ldur            w2, [x5, #0xb7]
    // 0x116a1b0: DecompressPointer r2
    //     0x116a1b0: add             x2, x2, HEAP, lsl #32
    // 0x116a1b4: cmp             w2, NULL
    // 0x116a1b8: b.ne            #0x116a1c4
    // 0x116a1bc: r17 = -312
    //     0x116a1bc: mov             x17, #-0x138
    // 0x116a1c0: ldr             x2, [fp, x17]
    // 0x116a1c4: ldur            x3, [fp, #-8]
    // 0x116a1c8: r0 = lerp()
    //     0x116a1c8: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x116a1cc: mov             x4, x0
    // 0x116a1d0: ldur            x0, [fp, #-0x28]
    // 0x116a1d4: r17 = -312
    //     0x116a1d4: mov             x17, #-0x138
    // 0x116a1d8: str             x4, [fp, x17]
    // 0x116a1dc: LoadField: r1 = r0->field_bb
    //     0x116a1dc: ldur            w1, [x0, #0xbb]
    // 0x116a1e0: DecompressPointer r1
    //     0x116a1e0: add             x1, x1, HEAP, lsl #32
    // 0x116a1e4: cmp             w1, NULL
    // 0x116a1e8: b.ne            #0x116a1f4
    // 0x116a1ec: r17 = -280
    //     0x116a1ec: mov             x17, #-0x118
    // 0x116a1f0: ldr             x1, [fp, x17]
    // 0x116a1f4: ldur            x5, [fp, #-0x30]
    // 0x116a1f8: LoadField: r2 = r5->field_bb
    //     0x116a1f8: ldur            w2, [x5, #0xbb]
    // 0x116a1fc: DecompressPointer r2
    //     0x116a1fc: add             x2, x2, HEAP, lsl #32
    // 0x116a200: cmp             w2, NULL
    // 0x116a204: b.ne            #0x116a210
    // 0x116a208: r17 = -264
    //     0x116a208: mov             x17, #-0x108
    // 0x116a20c: ldr             x2, [fp, x17]
    // 0x116a210: ldur            x3, [fp, #-8]
    // 0x116a214: r0 = lerp()
    //     0x116a214: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x116a218: mov             x4, x0
    // 0x116a21c: ldur            x0, [fp, #-0x28]
    // 0x116a220: r17 = -320
    //     0x116a220: mov             x17, #-0x140
    // 0x116a224: str             x4, [fp, x17]
    // 0x116a228: LoadField: r1 = r0->field_bf
    //     0x116a228: ldur            w1, [x0, #0xbf]
    // 0x116a22c: DecompressPointer r1
    //     0x116a22c: add             x1, x1, HEAP, lsl #32
    // 0x116a230: cmp             w1, NULL
    // 0x116a234: b.ne            #0x116a23c
    // 0x116a238: ldur            x1, [fp, #-0x40]
    // 0x116a23c: ldur            x5, [fp, #-0x30]
    // 0x116a240: LoadField: r2 = r5->field_bf
    //     0x116a240: ldur            w2, [x5, #0xbf]
    // 0x116a244: DecompressPointer r2
    //     0x116a244: add             x2, x2, HEAP, lsl #32
    // 0x116a248: cmp             w2, NULL
    // 0x116a24c: b.ne            #0x116a254
    // 0x116a250: ldur            x2, [fp, #-0x38]
    // 0x116a254: ldur            x3, [fp, #-8]
    // 0x116a258: r0 = lerp()
    //     0x116a258: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x116a25c: mov             x4, x0
    // 0x116a260: ldur            x0, [fp, #-0x28]
    // 0x116a264: stur            x4, [fp, #-0x38]
    // 0x116a268: LoadField: r1 = r0->field_c3
    //     0x116a268: ldur            w1, [x0, #0xc3]
    // 0x116a26c: DecompressPointer r1
    //     0x116a26c: add             x1, x1, HEAP, lsl #32
    // 0x116a270: cmp             w1, NULL
    // 0x116a274: b.ne            #0x116a27c
    // 0x116a278: ldur            x1, [fp, #-0x18]
    // 0x116a27c: ldur            x5, [fp, #-0x30]
    // 0x116a280: LoadField: r2 = r5->field_c3
    //     0x116a280: ldur            w2, [x5, #0xc3]
    // 0x116a284: DecompressPointer r2
    //     0x116a284: add             x2, x2, HEAP, lsl #32
    // 0x116a288: cmp             w2, NULL
    // 0x116a28c: b.ne            #0x116a294
    // 0x116a290: ldur            x2, [fp, #-0x10]
    // 0x116a294: ldur            x3, [fp, #-8]
    // 0x116a298: r0 = lerp()
    //     0x116a298: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x116a29c: mov             x4, x0
    // 0x116a2a0: ldur            x0, [fp, #-0x28]
    // 0x116a2a4: stur            x4, [fp, #-0x10]
    // 0x116a2a8: LoadField: r1 = r0->field_c7
    //     0x116a2a8: ldur            w1, [x0, #0xc7]
    // 0x116a2ac: DecompressPointer r1
    //     0x116a2ac: add             x1, x1, HEAP, lsl #32
    // 0x116a2b0: ldur            x5, [fp, #-0x30]
    // 0x116a2b4: LoadField: r2 = r5->field_c7
    //     0x116a2b4: ldur            w2, [x5, #0xc7]
    // 0x116a2b8: DecompressPointer r2
    //     0x116a2b8: add             x2, x2, HEAP, lsl #32
    // 0x116a2bc: ldur            x3, [fp, #-8]
    // 0x116a2c0: r0 = lerp()
    //     0x116a2c0: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x116a2c4: mov             x4, x0
    // 0x116a2c8: ldur            x0, [fp, #-0x28]
    // 0x116a2cc: stur            x4, [fp, #-0x18]
    // 0x116a2d0: LoadField: r1 = r0->field_cb
    //     0x116a2d0: ldur            w1, [x0, #0xcb]
    // 0x116a2d4: DecompressPointer r1
    //     0x116a2d4: add             x1, x1, HEAP, lsl #32
    // 0x116a2d8: ldur            x5, [fp, #-0x30]
    // 0x116a2dc: LoadField: r2 = r5->field_cb
    //     0x116a2dc: ldur            w2, [x5, #0xcb]
    // 0x116a2e0: DecompressPointer r2
    //     0x116a2e0: add             x2, x2, HEAP, lsl #32
    // 0x116a2e4: ldur            x3, [fp, #-8]
    // 0x116a2e8: r0 = lerp()
    //     0x116a2e8: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x116a2ec: mov             x4, x0
    // 0x116a2f0: ldur            x0, [fp, #-0x28]
    // 0x116a2f4: stur            x4, [fp, #-0x40]
    // 0x116a2f8: LoadField: r1 = r0->field_83
    //     0x116a2f8: ldur            w1, [x0, #0x83]
    // 0x116a2fc: DecompressPointer r1
    //     0x116a2fc: add             x1, x1, HEAP, lsl #32
    // 0x116a300: cmp             w1, NULL
    // 0x116a304: b.ne            #0x116a310
    // 0x116a308: r17 = -280
    //     0x116a308: mov             x17, #-0x118
    // 0x116a30c: ldr             x1, [fp, x17]
    // 0x116a310: ldur            x0, [fp, #-0x30]
    // 0x116a314: LoadField: r2 = r0->field_83
    //     0x116a314: ldur            w2, [x0, #0x83]
    // 0x116a318: DecompressPointer r2
    //     0x116a318: add             x2, x2, HEAP, lsl #32
    // 0x116a31c: cmp             w2, NULL
    // 0x116a320: b.ne            #0x116a33c
    // 0x116a324: SaveReg r0
    //     0x116a324: str             x0, [SP, #-8]!
    // 0x116a328: r17 = -264
    //     0x116a328: mov             x17, #-0x108
    // 0x116a32c: ldr             x0, [fp, x17]
    // 0x116a330: stur            x0, [fp, #-0x28]
    // 0x116a334: RestoreReg r0
    //     0x116a334: ldr             x0, [SP], #8
    // 0x116a338: b               #0x116a340
    // 0x116a33c: stur            x2, [fp, #-0x28]
    // 0x116a340: r17 = -336
    //     0x116a340: mov             x17, #-0x150
    // 0x116a344: ldr             x3, [fp, x17]
    // 0x116a348: r17 = -344
    //     0x116a348: mov             x17, #-0x158
    // 0x116a34c: ldr             x2, [fp, x17]
    // 0x116a350: r17 = -352
    //     0x116a350: mov             x17, #-0x160
    // 0x116a354: ldr             x25, [fp, x17]
    // 0x116a358: r17 = -360
    //     0x116a358: mov             x17, #-0x168
    // 0x116a35c: ldr             x24, [fp, x17]
    // 0x116a360: r17 = -368
    //     0x116a360: mov             x17, #-0x170
    // 0x116a364: ldr             x23, [fp, x17]
    // 0x116a368: r17 = -376
    //     0x116a368: mov             x17, #-0x178
    // 0x116a36c: ldr             x20, [fp, x17]
    // 0x116a370: r17 = -384
    //     0x116a370: mov             x17, #-0x180
    // 0x116a374: ldr             x19, [fp, x17]
    // 0x116a378: r17 = -392
    //     0x116a378: mov             x17, #-0x188
    // 0x116a37c: ldr             x14, [fp, x17]
    // 0x116a380: r17 = -400
    //     0x116a380: mov             x17, #-0x190
    // 0x116a384: ldr             x13, [fp, x17]
    // 0x116a388: r17 = -408
    //     0x116a388: mov             x17, #-0x198
    // 0x116a38c: ldr             x12, [fp, x17]
    // 0x116a390: r17 = -416
    //     0x116a390: mov             x17, #-0x1a0
    // 0x116a394: ldr             x11, [fp, x17]
    // 0x116a398: r17 = -424
    //     0x116a398: mov             x17, #-0x1a8
    // 0x116a39c: ldr             x10, [fp, x17]
    // 0x116a3a0: r17 = -432
    //     0x116a3a0: mov             x17, #-0x1b0
    // 0x116a3a4: ldr             x9, [fp, x17]
    // 0x116a3a8: r17 = -312
    //     0x116a3a8: mov             x17, #-0x138
    // 0x116a3ac: ldr             x8, [fp, x17]
    // 0x116a3b0: r17 = -320
    //     0x116a3b0: mov             x17, #-0x140
    // 0x116a3b4: ldr             x7, [fp, x17]
    // 0x116a3b8: ldur            x6, [fp, #-0x38]
    // 0x116a3bc: ldur            x5, [fp, #-0x10]
    // 0x116a3c0: ldur            x0, [fp, #-0x18]
    // 0x116a3c4: ldur            x2, [fp, #-0x28]
    // 0x116a3c8: ldur            x3, [fp, #-8]
    // 0x116a3cc: r0 = lerp()
    //     0x116a3cc: bl              #0xa08020  ; [dart:ui] Color::lerp
    // 0x116a3d0: stur            x0, [fp, #-8]
    // 0x116a3d4: r0 = ColorScheme()
    //     0x116a3d4: bl              #0x8a9004  ; AllocateColorSchemeStub -> ColorScheme (size=0xd0)
    // 0x116a3d8: ldur            x1, [fp, #-0x20]
    // 0x116a3dc: StoreField: r0->field_7 = r1
    //     0x116a3dc: stur            w1, [x0, #7]
    // 0x116a3e0: ldur            x1, [fp, #-0x48]
    // 0x116a3e4: StoreField: r0->field_b = r1
    //     0x116a3e4: stur            w1, [x0, #0xb]
    // 0x116a3e8: ldur            x1, [fp, #-0x50]
    // 0x116a3ec: StoreField: r0->field_f = r1
    //     0x116a3ec: stur            w1, [x0, #0xf]
    // 0x116a3f0: ldur            x1, [fp, #-0xa8]
    // 0x116a3f4: StoreField: r0->field_2b = r1
    //     0x116a3f4: stur            w1, [x0, #0x2b]
    // 0x116a3f8: ldur            x1, [fp, #-0xb0]
    // 0x116a3fc: StoreField: r0->field_2f = r1
    //     0x116a3fc: stur            w1, [x0, #0x2f]
    // 0x116a400: r17 = -296
    //     0x116a400: mov             x17, #-0x128
    // 0x116a404: ldr             x1, [fp, x17]
    // 0x116a408: StoreField: r0->field_6b = r1
    //     0x116a408: stur            w1, [x0, #0x6b]
    // 0x116a40c: r17 = -304
    //     0x116a40c: mov             x17, #-0x130
    // 0x116a410: ldr             x1, [fp, x17]
    // 0x116a414: StoreField: r0->field_6f = r1
    //     0x116a414: stur            w1, [x0, #0x6f]
    // 0x116a418: r17 = -328
    //     0x116a418: mov             x17, #-0x148
    // 0x116a41c: ldr             x1, [fp, x17]
    // 0x116a420: StoreField: r0->field_7b = r1
    //     0x116a420: stur            w1, [x0, #0x7b]
    // 0x116a424: r17 = -336
    //     0x116a424: mov             x17, #-0x150
    // 0x116a428: ldr             x1, [fp, x17]
    // 0x116a42c: StoreField: r0->field_7f = r1
    //     0x116a42c: stur            w1, [x0, #0x7f]
    // 0x116a430: ldur            x1, [fp, #-0x58]
    // 0x116a434: StoreField: r0->field_13 = r1
    //     0x116a434: stur            w1, [x0, #0x13]
    // 0x116a438: ldur            x1, [fp, #-0x60]
    // 0x116a43c: ArrayStore: r0[0] = r1  ; List_4
    //     0x116a43c: stur            w1, [x0, #0x17]
    // 0x116a440: ldur            x1, [fp, #-0x68]
    // 0x116a444: StoreField: r0->field_1b = r1
    //     0x116a444: stur            w1, [x0, #0x1b]
    // 0x116a448: ldur            x1, [fp, #-0x70]
    // 0x116a44c: StoreField: r0->field_1f = r1
    //     0x116a44c: stur            w1, [x0, #0x1f]
    // 0x116a450: ldur            x1, [fp, #-0x78]
    // 0x116a454: StoreField: r0->field_23 = r1
    //     0x116a454: stur            w1, [x0, #0x23]
    // 0x116a458: ldur            x1, [fp, #-0x90]
    // 0x116a45c: StoreField: r0->field_27 = r1
    //     0x116a45c: stur            w1, [x0, #0x27]
    // 0x116a460: ldur            x1, [fp, #-0xb8]
    // 0x116a464: StoreField: r0->field_33 = r1
    //     0x116a464: stur            w1, [x0, #0x33]
    // 0x116a468: ldur            x1, [fp, #-0xc0]
    // 0x116a46c: StoreField: r0->field_37 = r1
    //     0x116a46c: stur            w1, [x0, #0x37]
    // 0x116a470: ldur            x1, [fp, #-0xc8]
    // 0x116a474: StoreField: r0->field_3b = r1
    //     0x116a474: stur            w1, [x0, #0x3b]
    // 0x116a478: ldur            x1, [fp, #-0xd0]
    // 0x116a47c: StoreField: r0->field_3f = r1
    //     0x116a47c: stur            w1, [x0, #0x3f]
    // 0x116a480: ldur            x1, [fp, #-0xd8]
    // 0x116a484: StoreField: r0->field_43 = r1
    //     0x116a484: stur            w1, [x0, #0x43]
    // 0x116a488: ldur            x1, [fp, #-0xe0]
    // 0x116a48c: StoreField: r0->field_47 = r1
    //     0x116a48c: stur            w1, [x0, #0x47]
    // 0x116a490: ldur            x1, [fp, #-0x80]
    // 0x116a494: StoreField: r0->field_4b = r1
    //     0x116a494: stur            w1, [x0, #0x4b]
    // 0x116a498: ldur            x1, [fp, #-0x88]
    // 0x116a49c: StoreField: r0->field_4f = r1
    //     0x116a49c: stur            w1, [x0, #0x4f]
    // 0x116a4a0: ldur            x1, [fp, #-0x98]
    // 0x116a4a4: StoreField: r0->field_53 = r1
    //     0x116a4a4: stur            w1, [x0, #0x53]
    // 0x116a4a8: ldur            x1, [fp, #-0xa0]
    // 0x116a4ac: StoreField: r0->field_57 = r1
    //     0x116a4ac: stur            w1, [x0, #0x57]
    // 0x116a4b0: ldur            x1, [fp, #-0xe8]
    // 0x116a4b4: StoreField: r0->field_5b = r1
    //     0x116a4b4: stur            w1, [x0, #0x5b]
    // 0x116a4b8: ldur            x1, [fp, #-0xf0]
    // 0x116a4bc: StoreField: r0->field_5f = r1
    //     0x116a4bc: stur            w1, [x0, #0x5f]
    // 0x116a4c0: ldur            x1, [fp, #-0xf8]
    // 0x116a4c4: StoreField: r0->field_63 = r1
    //     0x116a4c4: stur            w1, [x0, #0x63]
    // 0x116a4c8: r17 = -272
    //     0x116a4c8: mov             x17, #-0x110
    // 0x116a4cc: ldr             x1, [fp, x17]
    // 0x116a4d0: StoreField: r0->field_67 = r1
    //     0x116a4d0: stur            w1, [x0, #0x67]
    // 0x116a4d4: ldur            x1, [fp, #-0x100]
    // 0x116a4d8: StoreField: r0->field_73 = r1
    //     0x116a4d8: stur            w1, [x0, #0x73]
    // 0x116a4dc: r17 = -288
    //     0x116a4dc: mov             x17, #-0x120
    // 0x116a4e0: ldr             x1, [fp, x17]
    // 0x116a4e4: StoreField: r0->field_77 = r1
    //     0x116a4e4: stur            w1, [x0, #0x77]
    // 0x116a4e8: r17 = -344
    //     0x116a4e8: mov             x17, #-0x158
    // 0x116a4ec: ldr             x1, [fp, x17]
    // 0x116a4f0: StoreField: r0->field_87 = r1
    //     0x116a4f0: stur            w1, [x0, #0x87]
    // 0x116a4f4: r17 = -352
    //     0x116a4f4: mov             x17, #-0x160
    // 0x116a4f8: ldr             x1, [fp, x17]
    // 0x116a4fc: StoreField: r0->field_8b = r1
    //     0x116a4fc: stur            w1, [x0, #0x8b]
    // 0x116a500: r17 = -360
    //     0x116a500: mov             x17, #-0x168
    // 0x116a504: ldr             x1, [fp, x17]
    // 0x116a508: StoreField: r0->field_8f = r1
    //     0x116a508: stur            w1, [x0, #0x8f]
    // 0x116a50c: r17 = -368
    //     0x116a50c: mov             x17, #-0x170
    // 0x116a510: ldr             x1, [fp, x17]
    // 0x116a514: StoreField: r0->field_93 = r1
    //     0x116a514: stur            w1, [x0, #0x93]
    // 0x116a518: r17 = -376
    //     0x116a518: mov             x17, #-0x178
    // 0x116a51c: ldr             x1, [fp, x17]
    // 0x116a520: StoreField: r0->field_97 = r1
    //     0x116a520: stur            w1, [x0, #0x97]
    // 0x116a524: r17 = -384
    //     0x116a524: mov             x17, #-0x180
    // 0x116a528: ldr             x1, [fp, x17]
    // 0x116a52c: StoreField: r0->field_9b = r1
    //     0x116a52c: stur            w1, [x0, #0x9b]
    // 0x116a530: r17 = -392
    //     0x116a530: mov             x17, #-0x188
    // 0x116a534: ldr             x1, [fp, x17]
    // 0x116a538: StoreField: r0->field_9f = r1
    //     0x116a538: stur            w1, [x0, #0x9f]
    // 0x116a53c: r17 = -400
    //     0x116a53c: mov             x17, #-0x190
    // 0x116a540: ldr             x1, [fp, x17]
    // 0x116a544: StoreField: r0->field_a3 = r1
    //     0x116a544: stur            w1, [x0, #0xa3]
    // 0x116a548: r17 = -408
    //     0x116a548: mov             x17, #-0x198
    // 0x116a54c: ldr             x1, [fp, x17]
    // 0x116a550: StoreField: r0->field_a7 = r1
    //     0x116a550: stur            w1, [x0, #0xa7]
    // 0x116a554: r17 = -416
    //     0x116a554: mov             x17, #-0x1a0
    // 0x116a558: ldr             x1, [fp, x17]
    // 0x116a55c: StoreField: r0->field_ab = r1
    //     0x116a55c: stur            w1, [x0, #0xab]
    // 0x116a560: r17 = -424
    //     0x116a560: mov             x17, #-0x1a8
    // 0x116a564: ldr             x1, [fp, x17]
    // 0x116a568: StoreField: r0->field_af = r1
    //     0x116a568: stur            w1, [x0, #0xaf]
    // 0x116a56c: r17 = -432
    //     0x116a56c: mov             x17, #-0x1b0
    // 0x116a570: ldr             x1, [fp, x17]
    // 0x116a574: StoreField: r0->field_b3 = r1
    //     0x116a574: stur            w1, [x0, #0xb3]
    // 0x116a578: r17 = -312
    //     0x116a578: mov             x17, #-0x138
    // 0x116a57c: ldr             x1, [fp, x17]
    // 0x116a580: StoreField: r0->field_b7 = r1
    //     0x116a580: stur            w1, [x0, #0xb7]
    // 0x116a584: r17 = -320
    //     0x116a584: mov             x17, #-0x140
    // 0x116a588: ldr             x1, [fp, x17]
    // 0x116a58c: StoreField: r0->field_bb = r1
    //     0x116a58c: stur            w1, [x0, #0xbb]
    // 0x116a590: ldur            x1, [fp, #-0x38]
    // 0x116a594: StoreField: r0->field_bf = r1
    //     0x116a594: stur            w1, [x0, #0xbf]
    // 0x116a598: ldur            x1, [fp, #-0x10]
    // 0x116a59c: StoreField: r0->field_c3 = r1
    //     0x116a59c: stur            w1, [x0, #0xc3]
    // 0x116a5a0: ldur            x1, [fp, #-0x18]
    // 0x116a5a4: StoreField: r0->field_c7 = r1
    //     0x116a5a4: stur            w1, [x0, #0xc7]
    // 0x116a5a8: ldur            x1, [fp, #-0x40]
    // 0x116a5ac: StoreField: r0->field_cb = r1
    //     0x116a5ac: stur            w1, [x0, #0xcb]
    // 0x116a5b0: ldur            x1, [fp, #-8]
    // 0x116a5b4: StoreField: r0->field_83 = r1
    //     0x116a5b4: stur            w1, [x0, #0x83]
    // 0x116a5b8: LeaveFrame
    //     0x116a5b8: mov             SP, fp
    //     0x116a5bc: ldp             fp, lr, [SP], #0x10
    // 0x116a5c0: ret
    //     0x116a5c0: ret             
    // 0x116a5c4: r0 = StackOverflowSharedWithFPURegs()
    //     0x116a5c4: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x116a5c8: b               #0x11696a0
    // 0x116a5cc: SaveReg d0
    //     0x116a5cc: str             q0, [SP, #-0x10]!
    // 0x116a5d0: stp             x6, x7, [SP, #-0x10]!
    // 0x116a5d4: stp             x4, x5, [SP, #-0x10]!
    // 0x116a5d8: SaveReg r0
    //     0x116a5d8: str             x0, [SP, #-8]!
    // 0x116a5dc: r0 = AllocateDouble()
    //     0x116a5dc: bl              #0x13df878  ; AllocateDoubleStub
    // 0x116a5e0: mov             x8, x0
    // 0x116a5e4: RestoreReg r0
    //     0x116a5e4: ldr             x0, [SP], #8
    // 0x116a5e8: ldp             x4, x5, [SP], #0x10
    // 0x116a5ec: ldp             x6, x7, [SP], #0x10
    // 0x116a5f0: RestoreReg d0
    //     0x116a5f0: ldr             q0, [SP], #0x10
    // 0x116a5f4: b               #0x1169724
  }
  _ ==(/* No info */) {
    // ** addr: 0x1266a28, size: 0xef4
    // 0x1266a28: EnterFrame
    //     0x1266a28: stp             fp, lr, [SP, #-0x10]!
    //     0x1266a2c: mov             fp, SP
    // 0x1266a30: AllocStack(0x50)
    //     0x1266a30: sub             SP, SP, #0x50
    // 0x1266a34: CheckStackOverflow
    //     0x1266a34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1266a38: cmp             SP, x16
    //     0x1266a3c: b.ls            #0x1267914
    // 0x1266a40: ldr             x1, [fp, #0x10]
    // 0x1266a44: cmp             w1, NULL
    // 0x1266a48: b.ne            #0x1266a5c
    // 0x1266a4c: r0 = false
    //     0x1266a4c: add             x0, NULL, #0x30  ; false
    // 0x1266a50: LeaveFrame
    //     0x1266a50: mov             SP, fp
    //     0x1266a54: ldp             fp, lr, [SP], #0x10
    // 0x1266a58: ret
    //     0x1266a58: ret             
    // 0x1266a5c: ldr             x0, [fp, #0x18]
    // 0x1266a60: cmp             w0, w1
    // 0x1266a64: b.ne            #0x1266a78
    // 0x1266a68: r0 = true
    //     0x1266a68: add             x0, NULL, #0x20  ; true
    // 0x1266a6c: LeaveFrame
    //     0x1266a6c: mov             SP, fp
    //     0x1266a70: ldp             fp, lr, [SP], #0x10
    // 0x1266a74: ret
    //     0x1266a74: ret             
    // 0x1266a78: str             x1, [SP]
    // 0x1266a7c: r0 = runtimeType()
    //     0x1266a7c: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x1266a80: r1 = LoadClassIdInstr(r0)
    //     0x1266a80: ldur            x1, [x0, #-1]
    //     0x1266a84: ubfx            x1, x1, #0xc, #0x14
    // 0x1266a88: r16 = ColorScheme
    //     0x1266a88: add             x16, PP, #0x26, lsl #12  ; [pp+0x26800] Type: ColorScheme
    //     0x1266a8c: ldr             x16, [x16, #0x800]
    // 0x1266a90: stp             x16, x0, [SP]
    // 0x1266a94: mov             x0, x1
    // 0x1266a98: mov             lr, x0
    // 0x1266a9c: ldr             lr, [x21, lr, lsl #3]
    // 0x1266aa0: blr             lr
    // 0x1266aa4: tbz             w0, #4, #0x1266ab8
    // 0x1266aa8: r0 = false
    //     0x1266aa8: add             x0, NULL, #0x30  ; false
    // 0x1266aac: LeaveFrame
    //     0x1266aac: mov             SP, fp
    //     0x1266ab0: ldp             fp, lr, [SP], #0x10
    // 0x1266ab4: ret
    //     0x1266ab4: ret             
    // 0x1266ab8: ldr             x1, [fp, #0x10]
    // 0x1266abc: r0 = 60
    //     0x1266abc: mov             x0, #0x3c
    // 0x1266ac0: branchIfSmi(r1, 0x1266acc)
    //     0x1266ac0: tbz             w1, #0, #0x1266acc
    // 0x1266ac4: r0 = LoadClassIdInstr(r1)
    //     0x1266ac4: ldur            x0, [x1, #-1]
    //     0x1266ac8: ubfx            x0, x0, #0xc, #0x14
    // 0x1266acc: r17 = 5171
    //     0x1266acc: mov             x17, #0x1433
    // 0x1266ad0: cmp             x0, x17
    // 0x1266ad4: b.ne            #0x1267904
    // 0x1266ad8: ldr             x2, [fp, #0x18]
    // 0x1266adc: LoadField: r0 = r1->field_7
    //     0x1266adc: ldur            w0, [x1, #7]
    // 0x1266ae0: DecompressPointer r0
    //     0x1266ae0: add             x0, x0, HEAP, lsl #32
    // 0x1266ae4: LoadField: r3 = r2->field_7
    //     0x1266ae4: ldur            w3, [x2, #7]
    // 0x1266ae8: DecompressPointer r3
    //     0x1266ae8: add             x3, x3, HEAP, lsl #32
    // 0x1266aec: cmp             w0, w3
    // 0x1266af0: b.ne            #0x1267904
    // 0x1266af4: LoadField: r3 = r1->field_b
    //     0x1266af4: ldur            w3, [x1, #0xb]
    // 0x1266af8: DecompressPointer r3
    //     0x1266af8: add             x3, x3, HEAP, lsl #32
    // 0x1266afc: stur            x3, [fp, #-0x10]
    // 0x1266b00: LoadField: r4 = r2->field_b
    //     0x1266b00: ldur            w4, [x2, #0xb]
    // 0x1266b04: DecompressPointer r4
    //     0x1266b04: add             x4, x4, HEAP, lsl #32
    // 0x1266b08: stur            x4, [fp, #-8]
    // 0x1266b0c: r0 = LoadClassIdInstr(r3)
    //     0x1266b0c: ldur            x0, [x3, #-1]
    //     0x1266b10: ubfx            x0, x0, #0xc, #0x14
    // 0x1266b14: stp             x4, x3, [SP]
    // 0x1266b18: mov             lr, x0
    // 0x1266b1c: ldr             lr, [x21, lr, lsl #3]
    // 0x1266b20: blr             lr
    // 0x1266b24: tbnz            w0, #4, #0x1267904
    // 0x1266b28: ldr             x2, [fp, #0x18]
    // 0x1266b2c: ldr             x1, [fp, #0x10]
    // 0x1266b30: LoadField: r3 = r1->field_f
    //     0x1266b30: ldur            w3, [x1, #0xf]
    // 0x1266b34: DecompressPointer r3
    //     0x1266b34: add             x3, x3, HEAP, lsl #32
    // 0x1266b38: stur            x3, [fp, #-0x20]
    // 0x1266b3c: LoadField: r4 = r2->field_f
    //     0x1266b3c: ldur            w4, [x2, #0xf]
    // 0x1266b40: DecompressPointer r4
    //     0x1266b40: add             x4, x4, HEAP, lsl #32
    // 0x1266b44: stur            x4, [fp, #-0x18]
    // 0x1266b48: r0 = LoadClassIdInstr(r3)
    //     0x1266b48: ldur            x0, [x3, #-1]
    //     0x1266b4c: ubfx            x0, x0, #0xc, #0x14
    // 0x1266b50: stp             x4, x3, [SP]
    // 0x1266b54: mov             lr, x0
    // 0x1266b58: ldr             lr, [x21, lr, lsl #3]
    // 0x1266b5c: blr             lr
    // 0x1266b60: tbnz            w0, #4, #0x1267904
    // 0x1266b64: ldr             x1, [fp, #0x10]
    // 0x1266b68: LoadField: r0 = r1->field_13
    //     0x1266b68: ldur            w0, [x1, #0x13]
    // 0x1266b6c: DecompressPointer r0
    //     0x1266b6c: add             x0, x0, HEAP, lsl #32
    // 0x1266b70: cmp             w0, NULL
    // 0x1266b74: b.ne            #0x1266b7c
    // 0x1266b78: ldur            x0, [fp, #-0x10]
    // 0x1266b7c: ldr             x2, [fp, #0x18]
    // 0x1266b80: LoadField: r3 = r2->field_13
    //     0x1266b80: ldur            w3, [x2, #0x13]
    // 0x1266b84: DecompressPointer r3
    //     0x1266b84: add             x3, x3, HEAP, lsl #32
    // 0x1266b88: cmp             w3, NULL
    // 0x1266b8c: b.ne            #0x1266b94
    // 0x1266b90: ldur            x3, [fp, #-8]
    // 0x1266b94: r4 = LoadClassIdInstr(r0)
    //     0x1266b94: ldur            x4, [x0, #-1]
    //     0x1266b98: ubfx            x4, x4, #0xc, #0x14
    // 0x1266b9c: stp             x3, x0, [SP]
    // 0x1266ba0: mov             x0, x4
    // 0x1266ba4: mov             lr, x0
    // 0x1266ba8: ldr             lr, [x21, lr, lsl #3]
    // 0x1266bac: blr             lr
    // 0x1266bb0: tbnz            w0, #4, #0x1267904
    // 0x1266bb4: ldr             x1, [fp, #0x10]
    // 0x1266bb8: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x1266bb8: ldur            w0, [x1, #0x17]
    // 0x1266bbc: DecompressPointer r0
    //     0x1266bbc: add             x0, x0, HEAP, lsl #32
    // 0x1266bc0: cmp             w0, NULL
    // 0x1266bc4: b.ne            #0x1266bcc
    // 0x1266bc8: ldur            x0, [fp, #-0x20]
    // 0x1266bcc: ldr             x2, [fp, #0x18]
    // 0x1266bd0: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x1266bd0: ldur            w3, [x2, #0x17]
    // 0x1266bd4: DecompressPointer r3
    //     0x1266bd4: add             x3, x3, HEAP, lsl #32
    // 0x1266bd8: cmp             w3, NULL
    // 0x1266bdc: b.ne            #0x1266be4
    // 0x1266be0: ldur            x3, [fp, #-0x18]
    // 0x1266be4: r4 = LoadClassIdInstr(r0)
    //     0x1266be4: ldur            x4, [x0, #-1]
    //     0x1266be8: ubfx            x4, x4, #0xc, #0x14
    // 0x1266bec: stp             x3, x0, [SP]
    // 0x1266bf0: mov             x0, x4
    // 0x1266bf4: mov             lr, x0
    // 0x1266bf8: ldr             lr, [x21, lr, lsl #3]
    // 0x1266bfc: blr             lr
    // 0x1266c00: tbnz            w0, #4, #0x1267904
    // 0x1266c04: ldr             x1, [fp, #0x10]
    // 0x1266c08: LoadField: r0 = r1->field_1b
    //     0x1266c08: ldur            w0, [x1, #0x1b]
    // 0x1266c0c: DecompressPointer r0
    //     0x1266c0c: add             x0, x0, HEAP, lsl #32
    // 0x1266c10: cmp             w0, NULL
    // 0x1266c14: b.ne            #0x1266c1c
    // 0x1266c18: ldur            x0, [fp, #-0x10]
    // 0x1266c1c: ldr             x2, [fp, #0x18]
    // 0x1266c20: LoadField: r3 = r2->field_1b
    //     0x1266c20: ldur            w3, [x2, #0x1b]
    // 0x1266c24: DecompressPointer r3
    //     0x1266c24: add             x3, x3, HEAP, lsl #32
    // 0x1266c28: cmp             w3, NULL
    // 0x1266c2c: b.ne            #0x1266c34
    // 0x1266c30: ldur            x3, [fp, #-8]
    // 0x1266c34: r4 = LoadClassIdInstr(r0)
    //     0x1266c34: ldur            x4, [x0, #-1]
    //     0x1266c38: ubfx            x4, x4, #0xc, #0x14
    // 0x1266c3c: stp             x3, x0, [SP]
    // 0x1266c40: mov             x0, x4
    // 0x1266c44: mov             lr, x0
    // 0x1266c48: ldr             lr, [x21, lr, lsl #3]
    // 0x1266c4c: blr             lr
    // 0x1266c50: tbnz            w0, #4, #0x1267904
    // 0x1266c54: ldr             x1, [fp, #0x10]
    // 0x1266c58: LoadField: r0 = r1->field_1f
    //     0x1266c58: ldur            w0, [x1, #0x1f]
    // 0x1266c5c: DecompressPointer r0
    //     0x1266c5c: add             x0, x0, HEAP, lsl #32
    // 0x1266c60: cmp             w0, NULL
    // 0x1266c64: b.ne            #0x1266c6c
    // 0x1266c68: ldur            x0, [fp, #-0x10]
    // 0x1266c6c: ldr             x2, [fp, #0x18]
    // 0x1266c70: LoadField: r3 = r2->field_1f
    //     0x1266c70: ldur            w3, [x2, #0x1f]
    // 0x1266c74: DecompressPointer r3
    //     0x1266c74: add             x3, x3, HEAP, lsl #32
    // 0x1266c78: cmp             w3, NULL
    // 0x1266c7c: b.ne            #0x1266c84
    // 0x1266c80: ldur            x3, [fp, #-8]
    // 0x1266c84: r4 = LoadClassIdInstr(r0)
    //     0x1266c84: ldur            x4, [x0, #-1]
    //     0x1266c88: ubfx            x4, x4, #0xc, #0x14
    // 0x1266c8c: stp             x3, x0, [SP]
    // 0x1266c90: mov             x0, x4
    // 0x1266c94: mov             lr, x0
    // 0x1266c98: ldr             lr, [x21, lr, lsl #3]
    // 0x1266c9c: blr             lr
    // 0x1266ca0: tbnz            w0, #4, #0x1267904
    // 0x1266ca4: ldr             x1, [fp, #0x10]
    // 0x1266ca8: LoadField: r0 = r1->field_23
    //     0x1266ca8: ldur            w0, [x1, #0x23]
    // 0x1266cac: DecompressPointer r0
    //     0x1266cac: add             x0, x0, HEAP, lsl #32
    // 0x1266cb0: cmp             w0, NULL
    // 0x1266cb4: b.ne            #0x1266cbc
    // 0x1266cb8: ldur            x0, [fp, #-0x20]
    // 0x1266cbc: ldr             x2, [fp, #0x18]
    // 0x1266cc0: LoadField: r3 = r2->field_23
    //     0x1266cc0: ldur            w3, [x2, #0x23]
    // 0x1266cc4: DecompressPointer r3
    //     0x1266cc4: add             x3, x3, HEAP, lsl #32
    // 0x1266cc8: cmp             w3, NULL
    // 0x1266ccc: b.ne            #0x1266cd4
    // 0x1266cd0: ldur            x3, [fp, #-0x18]
    // 0x1266cd4: r4 = LoadClassIdInstr(r0)
    //     0x1266cd4: ldur            x4, [x0, #-1]
    //     0x1266cd8: ubfx            x4, x4, #0xc, #0x14
    // 0x1266cdc: stp             x3, x0, [SP]
    // 0x1266ce0: mov             x0, x4
    // 0x1266ce4: mov             lr, x0
    // 0x1266ce8: ldr             lr, [x21, lr, lsl #3]
    // 0x1266cec: blr             lr
    // 0x1266cf0: tbnz            w0, #4, #0x1267904
    // 0x1266cf4: ldr             x1, [fp, #0x10]
    // 0x1266cf8: LoadField: r0 = r1->field_27
    //     0x1266cf8: ldur            w0, [x1, #0x27]
    // 0x1266cfc: DecompressPointer r0
    //     0x1266cfc: add             x0, x0, HEAP, lsl #32
    // 0x1266d00: cmp             w0, NULL
    // 0x1266d04: b.ne            #0x1266d0c
    // 0x1266d08: ldur            x0, [fp, #-0x20]
    // 0x1266d0c: ldr             x2, [fp, #0x18]
    // 0x1266d10: LoadField: r3 = r2->field_27
    //     0x1266d10: ldur            w3, [x2, #0x27]
    // 0x1266d14: DecompressPointer r3
    //     0x1266d14: add             x3, x3, HEAP, lsl #32
    // 0x1266d18: cmp             w3, NULL
    // 0x1266d1c: b.ne            #0x1266d24
    // 0x1266d20: ldur            x3, [fp, #-0x18]
    // 0x1266d24: r4 = LoadClassIdInstr(r0)
    //     0x1266d24: ldur            x4, [x0, #-1]
    //     0x1266d28: ubfx            x4, x4, #0xc, #0x14
    // 0x1266d2c: stp             x3, x0, [SP]
    // 0x1266d30: mov             x0, x4
    // 0x1266d34: mov             lr, x0
    // 0x1266d38: ldr             lr, [x21, lr, lsl #3]
    // 0x1266d3c: blr             lr
    // 0x1266d40: tbnz            w0, #4, #0x1267904
    // 0x1266d44: ldr             x2, [fp, #0x18]
    // 0x1266d48: ldr             x1, [fp, #0x10]
    // 0x1266d4c: LoadField: r3 = r1->field_2b
    //     0x1266d4c: ldur            w3, [x1, #0x2b]
    // 0x1266d50: DecompressPointer r3
    //     0x1266d50: add             x3, x3, HEAP, lsl #32
    // 0x1266d54: stur            x3, [fp, #-0x30]
    // 0x1266d58: LoadField: r4 = r2->field_2b
    //     0x1266d58: ldur            w4, [x2, #0x2b]
    // 0x1266d5c: DecompressPointer r4
    //     0x1266d5c: add             x4, x4, HEAP, lsl #32
    // 0x1266d60: stur            x4, [fp, #-0x28]
    // 0x1266d64: r0 = LoadClassIdInstr(r3)
    //     0x1266d64: ldur            x0, [x3, #-1]
    //     0x1266d68: ubfx            x0, x0, #0xc, #0x14
    // 0x1266d6c: stp             x4, x3, [SP]
    // 0x1266d70: mov             lr, x0
    // 0x1266d74: ldr             lr, [x21, lr, lsl #3]
    // 0x1266d78: blr             lr
    // 0x1266d7c: tbnz            w0, #4, #0x1267904
    // 0x1266d80: ldr             x2, [fp, #0x18]
    // 0x1266d84: ldr             x1, [fp, #0x10]
    // 0x1266d88: LoadField: r3 = r1->field_2f
    //     0x1266d88: ldur            w3, [x1, #0x2f]
    // 0x1266d8c: DecompressPointer r3
    //     0x1266d8c: add             x3, x3, HEAP, lsl #32
    // 0x1266d90: stur            x3, [fp, #-0x40]
    // 0x1266d94: LoadField: r4 = r2->field_2f
    //     0x1266d94: ldur            w4, [x2, #0x2f]
    // 0x1266d98: DecompressPointer r4
    //     0x1266d98: add             x4, x4, HEAP, lsl #32
    // 0x1266d9c: stur            x4, [fp, #-0x38]
    // 0x1266da0: r0 = LoadClassIdInstr(r3)
    //     0x1266da0: ldur            x0, [x3, #-1]
    //     0x1266da4: ubfx            x0, x0, #0xc, #0x14
    // 0x1266da8: stp             x4, x3, [SP]
    // 0x1266dac: mov             lr, x0
    // 0x1266db0: ldr             lr, [x21, lr, lsl #3]
    // 0x1266db4: blr             lr
    // 0x1266db8: tbnz            w0, #4, #0x1267904
    // 0x1266dbc: ldr             x1, [fp, #0x10]
    // 0x1266dc0: LoadField: r0 = r1->field_33
    //     0x1266dc0: ldur            w0, [x1, #0x33]
    // 0x1266dc4: DecompressPointer r0
    //     0x1266dc4: add             x0, x0, HEAP, lsl #32
    // 0x1266dc8: cmp             w0, NULL
    // 0x1266dcc: b.ne            #0x1266dd4
    // 0x1266dd0: ldur            x0, [fp, #-0x30]
    // 0x1266dd4: ldr             x2, [fp, #0x18]
    // 0x1266dd8: LoadField: r3 = r2->field_33
    //     0x1266dd8: ldur            w3, [x2, #0x33]
    // 0x1266ddc: DecompressPointer r3
    //     0x1266ddc: add             x3, x3, HEAP, lsl #32
    // 0x1266de0: cmp             w3, NULL
    // 0x1266de4: b.ne            #0x1266dec
    // 0x1266de8: ldur            x3, [fp, #-0x28]
    // 0x1266dec: r4 = LoadClassIdInstr(r0)
    //     0x1266dec: ldur            x4, [x0, #-1]
    //     0x1266df0: ubfx            x4, x4, #0xc, #0x14
    // 0x1266df4: stp             x3, x0, [SP]
    // 0x1266df8: mov             x0, x4
    // 0x1266dfc: mov             lr, x0
    // 0x1266e00: ldr             lr, [x21, lr, lsl #3]
    // 0x1266e04: blr             lr
    // 0x1266e08: tbnz            w0, #4, #0x1267904
    // 0x1266e0c: ldr             x1, [fp, #0x10]
    // 0x1266e10: LoadField: r0 = r1->field_37
    //     0x1266e10: ldur            w0, [x1, #0x37]
    // 0x1266e14: DecompressPointer r0
    //     0x1266e14: add             x0, x0, HEAP, lsl #32
    // 0x1266e18: cmp             w0, NULL
    // 0x1266e1c: b.ne            #0x1266e24
    // 0x1266e20: ldur            x0, [fp, #-0x40]
    // 0x1266e24: ldr             x2, [fp, #0x18]
    // 0x1266e28: LoadField: r3 = r2->field_37
    //     0x1266e28: ldur            w3, [x2, #0x37]
    // 0x1266e2c: DecompressPointer r3
    //     0x1266e2c: add             x3, x3, HEAP, lsl #32
    // 0x1266e30: cmp             w3, NULL
    // 0x1266e34: b.ne            #0x1266e3c
    // 0x1266e38: ldur            x3, [fp, #-0x38]
    // 0x1266e3c: r4 = LoadClassIdInstr(r0)
    //     0x1266e3c: ldur            x4, [x0, #-1]
    //     0x1266e40: ubfx            x4, x4, #0xc, #0x14
    // 0x1266e44: stp             x3, x0, [SP]
    // 0x1266e48: mov             x0, x4
    // 0x1266e4c: mov             lr, x0
    // 0x1266e50: ldr             lr, [x21, lr, lsl #3]
    // 0x1266e54: blr             lr
    // 0x1266e58: tbnz            w0, #4, #0x1267904
    // 0x1266e5c: ldr             x1, [fp, #0x10]
    // 0x1266e60: LoadField: r0 = r1->field_3b
    //     0x1266e60: ldur            w0, [x1, #0x3b]
    // 0x1266e64: DecompressPointer r0
    //     0x1266e64: add             x0, x0, HEAP, lsl #32
    // 0x1266e68: cmp             w0, NULL
    // 0x1266e6c: b.ne            #0x1266e74
    // 0x1266e70: ldur            x0, [fp, #-0x30]
    // 0x1266e74: ldr             x2, [fp, #0x18]
    // 0x1266e78: LoadField: r3 = r2->field_3b
    //     0x1266e78: ldur            w3, [x2, #0x3b]
    // 0x1266e7c: DecompressPointer r3
    //     0x1266e7c: add             x3, x3, HEAP, lsl #32
    // 0x1266e80: cmp             w3, NULL
    // 0x1266e84: b.ne            #0x1266e8c
    // 0x1266e88: ldur            x3, [fp, #-0x28]
    // 0x1266e8c: r4 = LoadClassIdInstr(r0)
    //     0x1266e8c: ldur            x4, [x0, #-1]
    //     0x1266e90: ubfx            x4, x4, #0xc, #0x14
    // 0x1266e94: stp             x3, x0, [SP]
    // 0x1266e98: mov             x0, x4
    // 0x1266e9c: mov             lr, x0
    // 0x1266ea0: ldr             lr, [x21, lr, lsl #3]
    // 0x1266ea4: blr             lr
    // 0x1266ea8: tbnz            w0, #4, #0x1267904
    // 0x1266eac: ldr             x1, [fp, #0x10]
    // 0x1266eb0: LoadField: r0 = r1->field_3f
    //     0x1266eb0: ldur            w0, [x1, #0x3f]
    // 0x1266eb4: DecompressPointer r0
    //     0x1266eb4: add             x0, x0, HEAP, lsl #32
    // 0x1266eb8: cmp             w0, NULL
    // 0x1266ebc: b.ne            #0x1266ec4
    // 0x1266ec0: ldur            x0, [fp, #-0x30]
    // 0x1266ec4: ldr             x2, [fp, #0x18]
    // 0x1266ec8: LoadField: r3 = r2->field_3f
    //     0x1266ec8: ldur            w3, [x2, #0x3f]
    // 0x1266ecc: DecompressPointer r3
    //     0x1266ecc: add             x3, x3, HEAP, lsl #32
    // 0x1266ed0: cmp             w3, NULL
    // 0x1266ed4: b.ne            #0x1266edc
    // 0x1266ed8: ldur            x3, [fp, #-0x28]
    // 0x1266edc: r4 = LoadClassIdInstr(r0)
    //     0x1266edc: ldur            x4, [x0, #-1]
    //     0x1266ee0: ubfx            x4, x4, #0xc, #0x14
    // 0x1266ee4: stp             x3, x0, [SP]
    // 0x1266ee8: mov             x0, x4
    // 0x1266eec: mov             lr, x0
    // 0x1266ef0: ldr             lr, [x21, lr, lsl #3]
    // 0x1266ef4: blr             lr
    // 0x1266ef8: tbnz            w0, #4, #0x1267904
    // 0x1266efc: ldr             x1, [fp, #0x10]
    // 0x1266f00: LoadField: r0 = r1->field_43
    //     0x1266f00: ldur            w0, [x1, #0x43]
    // 0x1266f04: DecompressPointer r0
    //     0x1266f04: add             x0, x0, HEAP, lsl #32
    // 0x1266f08: cmp             w0, NULL
    // 0x1266f0c: b.ne            #0x1266f14
    // 0x1266f10: ldur            x0, [fp, #-0x40]
    // 0x1266f14: ldr             x2, [fp, #0x18]
    // 0x1266f18: LoadField: r3 = r2->field_43
    //     0x1266f18: ldur            w3, [x2, #0x43]
    // 0x1266f1c: DecompressPointer r3
    //     0x1266f1c: add             x3, x3, HEAP, lsl #32
    // 0x1266f20: cmp             w3, NULL
    // 0x1266f24: b.ne            #0x1266f2c
    // 0x1266f28: ldur            x3, [fp, #-0x38]
    // 0x1266f2c: r4 = LoadClassIdInstr(r0)
    //     0x1266f2c: ldur            x4, [x0, #-1]
    //     0x1266f30: ubfx            x4, x4, #0xc, #0x14
    // 0x1266f34: stp             x3, x0, [SP]
    // 0x1266f38: mov             x0, x4
    // 0x1266f3c: mov             lr, x0
    // 0x1266f40: ldr             lr, [x21, lr, lsl #3]
    // 0x1266f44: blr             lr
    // 0x1266f48: tbnz            w0, #4, #0x1267904
    // 0x1266f4c: ldr             x1, [fp, #0x10]
    // 0x1266f50: LoadField: r0 = r1->field_47
    //     0x1266f50: ldur            w0, [x1, #0x47]
    // 0x1266f54: DecompressPointer r0
    //     0x1266f54: add             x0, x0, HEAP, lsl #32
    // 0x1266f58: cmp             w0, NULL
    // 0x1266f5c: b.ne            #0x1266f64
    // 0x1266f60: ldur            x0, [fp, #-0x40]
    // 0x1266f64: ldr             x2, [fp, #0x18]
    // 0x1266f68: LoadField: r3 = r2->field_47
    //     0x1266f68: ldur            w3, [x2, #0x47]
    // 0x1266f6c: DecompressPointer r3
    //     0x1266f6c: add             x3, x3, HEAP, lsl #32
    // 0x1266f70: cmp             w3, NULL
    // 0x1266f74: b.ne            #0x1266f7c
    // 0x1266f78: ldur            x3, [fp, #-0x38]
    // 0x1266f7c: r4 = LoadClassIdInstr(r0)
    //     0x1266f7c: ldur            x4, [x0, #-1]
    //     0x1266f80: ubfx            x4, x4, #0xc, #0x14
    // 0x1266f84: stp             x3, x0, [SP]
    // 0x1266f88: mov             x0, x4
    // 0x1266f8c: mov             lr, x0
    // 0x1266f90: ldr             lr, [x21, lr, lsl #3]
    // 0x1266f94: blr             lr
    // 0x1266f98: tbnz            w0, #4, #0x1267904
    // 0x1266f9c: ldr             x1, [fp, #0x10]
    // 0x1266fa0: LoadField: r0 = r1->field_4b
    //     0x1266fa0: ldur            w0, [x1, #0x4b]
    // 0x1266fa4: DecompressPointer r0
    //     0x1266fa4: add             x0, x0, HEAP, lsl #32
    // 0x1266fa8: cmp             w0, NULL
    // 0x1266fac: b.ne            #0x1266fb4
    // 0x1266fb0: ldur            x0, [fp, #-0x30]
    // 0x1266fb4: ldr             x2, [fp, #0x18]
    // 0x1266fb8: LoadField: r3 = r2->field_4b
    //     0x1266fb8: ldur            w3, [x2, #0x4b]
    // 0x1266fbc: DecompressPointer r3
    //     0x1266fbc: add             x3, x3, HEAP, lsl #32
    // 0x1266fc0: cmp             w3, NULL
    // 0x1266fc4: b.ne            #0x1266fcc
    // 0x1266fc8: ldur            x3, [fp, #-0x28]
    // 0x1266fcc: r4 = LoadClassIdInstr(r0)
    //     0x1266fcc: ldur            x4, [x0, #-1]
    //     0x1266fd0: ubfx            x4, x4, #0xc, #0x14
    // 0x1266fd4: stp             x3, x0, [SP]
    // 0x1266fd8: mov             x0, x4
    // 0x1266fdc: mov             lr, x0
    // 0x1266fe0: ldr             lr, [x21, lr, lsl #3]
    // 0x1266fe4: blr             lr
    // 0x1266fe8: tbnz            w0, #4, #0x1267904
    // 0x1266fec: ldr             x1, [fp, #0x10]
    // 0x1266ff0: LoadField: r0 = r1->field_4f
    //     0x1266ff0: ldur            w0, [x1, #0x4f]
    // 0x1266ff4: DecompressPointer r0
    //     0x1266ff4: add             x0, x0, HEAP, lsl #32
    // 0x1266ff8: cmp             w0, NULL
    // 0x1266ffc: b.ne            #0x1267004
    // 0x1267000: ldur            x0, [fp, #-0x40]
    // 0x1267004: ldr             x2, [fp, #0x18]
    // 0x1267008: LoadField: r3 = r2->field_4f
    //     0x1267008: ldur            w3, [x2, #0x4f]
    // 0x126700c: DecompressPointer r3
    //     0x126700c: add             x3, x3, HEAP, lsl #32
    // 0x1267010: cmp             w3, NULL
    // 0x1267014: b.ne            #0x126701c
    // 0x1267018: ldur            x3, [fp, #-0x38]
    // 0x126701c: r4 = LoadClassIdInstr(r0)
    //     0x126701c: ldur            x4, [x0, #-1]
    //     0x1267020: ubfx            x4, x4, #0xc, #0x14
    // 0x1267024: stp             x3, x0, [SP]
    // 0x1267028: mov             x0, x4
    // 0x126702c: mov             lr, x0
    // 0x1267030: ldr             lr, [x21, lr, lsl #3]
    // 0x1267034: blr             lr
    // 0x1267038: tbnz            w0, #4, #0x1267904
    // 0x126703c: ldr             x1, [fp, #0x10]
    // 0x1267040: r0 = tertiaryContainer()
    //     0x1267040: bl              #0x8a91b4  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::tertiaryContainer
    // 0x1267044: ldr             x1, [fp, #0x18]
    // 0x1267048: stur            x0, [fp, #-0x28]
    // 0x126704c: r0 = tertiaryContainer()
    //     0x126704c: bl              #0x8a91b4  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::tertiaryContainer
    // 0x1267050: mov             x1, x0
    // 0x1267054: ldur            x0, [fp, #-0x28]
    // 0x1267058: r2 = LoadClassIdInstr(r0)
    //     0x1267058: ldur            x2, [x0, #-1]
    //     0x126705c: ubfx            x2, x2, #0xc, #0x14
    // 0x1267060: stp             x1, x0, [SP]
    // 0x1267064: mov             x0, x2
    // 0x1267068: mov             lr, x0
    // 0x126706c: ldr             lr, [x21, lr, lsl #3]
    // 0x1267070: blr             lr
    // 0x1267074: tbnz            w0, #4, #0x1267904
    // 0x1267078: ldr             x1, [fp, #0x10]
    // 0x126707c: r0 = onTertiaryContainer()
    //     0x126707c: bl              #0x8a9170  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::onTertiaryContainer
    // 0x1267080: ldr             x1, [fp, #0x18]
    // 0x1267084: stur            x0, [fp, #-0x28]
    // 0x1267088: r0 = onTertiaryContainer()
    //     0x1267088: bl              #0x8a9170  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::onTertiaryContainer
    // 0x126708c: mov             x1, x0
    // 0x1267090: ldur            x0, [fp, #-0x28]
    // 0x1267094: r2 = LoadClassIdInstr(r0)
    //     0x1267094: ldur            x2, [x0, #-1]
    //     0x1267098: ubfx            x2, x2, #0xc, #0x14
    // 0x126709c: stp             x1, x0, [SP]
    // 0x12670a0: mov             x0, x2
    // 0x12670a4: mov             lr, x0
    // 0x12670a8: ldr             lr, [x21, lr, lsl #3]
    // 0x12670ac: blr             lr
    // 0x12670b0: tbnz            w0, #4, #0x1267904
    // 0x12670b4: ldr             x1, [fp, #0x10]
    // 0x12670b8: r0 = tertiaryFixed()
    //     0x12670b8: bl              #0x8a912c  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::tertiaryFixed
    // 0x12670bc: ldr             x1, [fp, #0x18]
    // 0x12670c0: stur            x0, [fp, #-0x28]
    // 0x12670c4: r0 = tertiaryFixed()
    //     0x12670c4: bl              #0x8a912c  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::tertiaryFixed
    // 0x12670c8: mov             x1, x0
    // 0x12670cc: ldur            x0, [fp, #-0x28]
    // 0x12670d0: r2 = LoadClassIdInstr(r0)
    //     0x12670d0: ldur            x2, [x0, #-1]
    //     0x12670d4: ubfx            x2, x2, #0xc, #0x14
    // 0x12670d8: stp             x1, x0, [SP]
    // 0x12670dc: mov             x0, x2
    // 0x12670e0: mov             lr, x0
    // 0x12670e4: ldr             lr, [x21, lr, lsl #3]
    // 0x12670e8: blr             lr
    // 0x12670ec: tbnz            w0, #4, #0x1267904
    // 0x12670f0: ldr             x1, [fp, #0x10]
    // 0x12670f4: r0 = tertiaryFixedDim()
    //     0x12670f4: bl              #0x8a90e8  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::tertiaryFixedDim
    // 0x12670f8: ldr             x1, [fp, #0x18]
    // 0x12670fc: stur            x0, [fp, #-0x28]
    // 0x1267100: r0 = tertiaryFixedDim()
    //     0x1267100: bl              #0x8a90e8  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::tertiaryFixedDim
    // 0x1267104: mov             x1, x0
    // 0x1267108: ldur            x0, [fp, #-0x28]
    // 0x126710c: r2 = LoadClassIdInstr(r0)
    //     0x126710c: ldur            x2, [x0, #-1]
    //     0x1267110: ubfx            x2, x2, #0xc, #0x14
    // 0x1267114: stp             x1, x0, [SP]
    // 0x1267118: mov             x0, x2
    // 0x126711c: mov             lr, x0
    // 0x1267120: ldr             lr, [x21, lr, lsl #3]
    // 0x1267124: blr             lr
    // 0x1267128: tbnz            w0, #4, #0x1267904
    // 0x126712c: ldr             x1, [fp, #0x10]
    // 0x1267130: r0 = onTertiaryFixed()
    //     0x1267130: bl              #0x8a90a4  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::onTertiaryFixed
    // 0x1267134: ldr             x1, [fp, #0x18]
    // 0x1267138: stur            x0, [fp, #-0x28]
    // 0x126713c: r0 = onTertiaryFixed()
    //     0x126713c: bl              #0x8a90a4  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::onTertiaryFixed
    // 0x1267140: mov             x1, x0
    // 0x1267144: ldur            x0, [fp, #-0x28]
    // 0x1267148: r2 = LoadClassIdInstr(r0)
    //     0x1267148: ldur            x2, [x0, #-1]
    //     0x126714c: ubfx            x2, x2, #0xc, #0x14
    // 0x1267150: stp             x1, x0, [SP]
    // 0x1267154: mov             x0, x2
    // 0x1267158: mov             lr, x0
    // 0x126715c: ldr             lr, [x21, lr, lsl #3]
    // 0x1267160: blr             lr
    // 0x1267164: tbnz            w0, #4, #0x1267904
    // 0x1267168: ldr             x1, [fp, #0x10]
    // 0x126716c: r0 = onTertiaryFixedVariant()
    //     0x126716c: bl              #0x8a9060  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::onTertiaryFixedVariant
    // 0x1267170: ldr             x1, [fp, #0x18]
    // 0x1267174: stur            x0, [fp, #-0x28]
    // 0x1267178: r0 = onTertiaryFixedVariant()
    //     0x1267178: bl              #0x8a9060  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::onTertiaryFixedVariant
    // 0x126717c: mov             x1, x0
    // 0x1267180: ldur            x0, [fp, #-0x28]
    // 0x1267184: r2 = LoadClassIdInstr(r0)
    //     0x1267184: ldur            x2, [x0, #-1]
    //     0x1267188: ubfx            x2, x2, #0xc, #0x14
    // 0x126718c: stp             x1, x0, [SP]
    // 0x1267190: mov             x0, x2
    // 0x1267194: mov             lr, x0
    // 0x1267198: ldr             lr, [x21, lr, lsl #3]
    // 0x126719c: blr             lr
    // 0x12671a0: tbnz            w0, #4, #0x1267904
    // 0x12671a4: ldr             x2, [fp, #0x18]
    // 0x12671a8: ldr             x1, [fp, #0x10]
    // 0x12671ac: LoadField: r3 = r1->field_6b
    //     0x12671ac: ldur            w3, [x1, #0x6b]
    // 0x12671b0: DecompressPointer r3
    //     0x12671b0: add             x3, x3, HEAP, lsl #32
    // 0x12671b4: stur            x3, [fp, #-0x30]
    // 0x12671b8: LoadField: r4 = r2->field_6b
    //     0x12671b8: ldur            w4, [x2, #0x6b]
    // 0x12671bc: DecompressPointer r4
    //     0x12671bc: add             x4, x4, HEAP, lsl #32
    // 0x12671c0: stur            x4, [fp, #-0x28]
    // 0x12671c4: r0 = LoadClassIdInstr(r3)
    //     0x12671c4: ldur            x0, [x3, #-1]
    //     0x12671c8: ubfx            x0, x0, #0xc, #0x14
    // 0x12671cc: stp             x4, x3, [SP]
    // 0x12671d0: mov             lr, x0
    // 0x12671d4: ldr             lr, [x21, lr, lsl #3]
    // 0x12671d8: blr             lr
    // 0x12671dc: tbnz            w0, #4, #0x1267904
    // 0x12671e0: ldr             x2, [fp, #0x18]
    // 0x12671e4: ldr             x1, [fp, #0x10]
    // 0x12671e8: LoadField: r3 = r1->field_6f
    //     0x12671e8: ldur            w3, [x1, #0x6f]
    // 0x12671ec: DecompressPointer r3
    //     0x12671ec: add             x3, x3, HEAP, lsl #32
    // 0x12671f0: stur            x3, [fp, #-0x40]
    // 0x12671f4: LoadField: r4 = r2->field_6f
    //     0x12671f4: ldur            w4, [x2, #0x6f]
    // 0x12671f8: DecompressPointer r4
    //     0x12671f8: add             x4, x4, HEAP, lsl #32
    // 0x12671fc: stur            x4, [fp, #-0x38]
    // 0x1267200: r0 = LoadClassIdInstr(r3)
    //     0x1267200: ldur            x0, [x3, #-1]
    //     0x1267204: ubfx            x0, x0, #0xc, #0x14
    // 0x1267208: stp             x4, x3, [SP]
    // 0x126720c: mov             lr, x0
    // 0x1267210: ldr             lr, [x21, lr, lsl #3]
    // 0x1267214: blr             lr
    // 0x1267218: tbnz            w0, #4, #0x1267904
    // 0x126721c: ldr             x1, [fp, #0x10]
    // 0x1267220: LoadField: r0 = r1->field_73
    //     0x1267220: ldur            w0, [x1, #0x73]
    // 0x1267224: DecompressPointer r0
    //     0x1267224: add             x0, x0, HEAP, lsl #32
    // 0x1267228: cmp             w0, NULL
    // 0x126722c: b.ne            #0x1267234
    // 0x1267230: ldur            x0, [fp, #-0x30]
    // 0x1267234: ldr             x2, [fp, #0x18]
    // 0x1267238: LoadField: r3 = r2->field_73
    //     0x1267238: ldur            w3, [x2, #0x73]
    // 0x126723c: DecompressPointer r3
    //     0x126723c: add             x3, x3, HEAP, lsl #32
    // 0x1267240: cmp             w3, NULL
    // 0x1267244: b.ne            #0x126724c
    // 0x1267248: ldur            x3, [fp, #-0x28]
    // 0x126724c: r4 = LoadClassIdInstr(r0)
    //     0x126724c: ldur            x4, [x0, #-1]
    //     0x1267250: ubfx            x4, x4, #0xc, #0x14
    // 0x1267254: stp             x3, x0, [SP]
    // 0x1267258: mov             x0, x4
    // 0x126725c: mov             lr, x0
    // 0x1267260: ldr             lr, [x21, lr, lsl #3]
    // 0x1267264: blr             lr
    // 0x1267268: tbnz            w0, #4, #0x1267904
    // 0x126726c: ldr             x1, [fp, #0x10]
    // 0x1267270: LoadField: r0 = r1->field_77
    //     0x1267270: ldur            w0, [x1, #0x77]
    // 0x1267274: DecompressPointer r0
    //     0x1267274: add             x0, x0, HEAP, lsl #32
    // 0x1267278: cmp             w0, NULL
    // 0x126727c: b.ne            #0x1267284
    // 0x1267280: ldur            x0, [fp, #-0x40]
    // 0x1267284: ldr             x2, [fp, #0x18]
    // 0x1267288: LoadField: r3 = r2->field_77
    //     0x1267288: ldur            w3, [x2, #0x77]
    // 0x126728c: DecompressPointer r3
    //     0x126728c: add             x3, x3, HEAP, lsl #32
    // 0x1267290: cmp             w3, NULL
    // 0x1267294: b.ne            #0x126729c
    // 0x1267298: ldur            x3, [fp, #-0x38]
    // 0x126729c: r4 = LoadClassIdInstr(r0)
    //     0x126729c: ldur            x4, [x0, #-1]
    //     0x12672a0: ubfx            x4, x4, #0xc, #0x14
    // 0x12672a4: stp             x3, x0, [SP]
    // 0x12672a8: mov             x0, x4
    // 0x12672ac: mov             lr, x0
    // 0x12672b0: ldr             lr, [x21, lr, lsl #3]
    // 0x12672b4: blr             lr
    // 0x12672b8: tbnz            w0, #4, #0x1267904
    // 0x12672bc: ldr             x2, [fp, #0x18]
    // 0x12672c0: ldr             x1, [fp, #0x10]
    // 0x12672c4: LoadField: r3 = r1->field_7b
    //     0x12672c4: ldur            w3, [x1, #0x7b]
    // 0x12672c8: DecompressPointer r3
    //     0x12672c8: add             x3, x3, HEAP, lsl #32
    // 0x12672cc: stur            x3, [fp, #-0x30]
    // 0x12672d0: LoadField: r4 = r2->field_7b
    //     0x12672d0: ldur            w4, [x2, #0x7b]
    // 0x12672d4: DecompressPointer r4
    //     0x12672d4: add             x4, x4, HEAP, lsl #32
    // 0x12672d8: stur            x4, [fp, #-0x28]
    // 0x12672dc: r0 = LoadClassIdInstr(r3)
    //     0x12672dc: ldur            x0, [x3, #-1]
    //     0x12672e0: ubfx            x0, x0, #0xc, #0x14
    // 0x12672e4: stp             x4, x3, [SP]
    // 0x12672e8: mov             lr, x0
    // 0x12672ec: ldr             lr, [x21, lr, lsl #3]
    // 0x12672f0: blr             lr
    // 0x12672f4: tbnz            w0, #4, #0x1267904
    // 0x12672f8: ldr             x2, [fp, #0x18]
    // 0x12672fc: ldr             x1, [fp, #0x10]
    // 0x1267300: LoadField: r3 = r1->field_7f
    //     0x1267300: ldur            w3, [x1, #0x7f]
    // 0x1267304: DecompressPointer r3
    //     0x1267304: add             x3, x3, HEAP, lsl #32
    // 0x1267308: stur            x3, [fp, #-0x40]
    // 0x126730c: LoadField: r4 = r2->field_7f
    //     0x126730c: ldur            w4, [x2, #0x7f]
    // 0x1267310: DecompressPointer r4
    //     0x1267310: add             x4, x4, HEAP, lsl #32
    // 0x1267314: stur            x4, [fp, #-0x38]
    // 0x1267318: r0 = LoadClassIdInstr(r3)
    //     0x1267318: ldur            x0, [x3, #-1]
    //     0x126731c: ubfx            x0, x0, #0xc, #0x14
    // 0x1267320: stp             x4, x3, [SP]
    // 0x1267324: mov             lr, x0
    // 0x1267328: ldr             lr, [x21, lr, lsl #3]
    // 0x126732c: blr             lr
    // 0x1267330: tbnz            w0, #4, #0x1267904
    // 0x1267334: ldr             x1, [fp, #0x10]
    // 0x1267338: LoadField: r0 = r1->field_87
    //     0x1267338: ldur            w0, [x1, #0x87]
    // 0x126733c: DecompressPointer r0
    //     0x126733c: add             x0, x0, HEAP, lsl #32
    // 0x1267340: cmp             w0, NULL
    // 0x1267344: b.ne            #0x126734c
    // 0x1267348: ldur            x0, [fp, #-0x30]
    // 0x126734c: ldr             x2, [fp, #0x18]
    // 0x1267350: LoadField: r3 = r2->field_87
    //     0x1267350: ldur            w3, [x2, #0x87]
    // 0x1267354: DecompressPointer r3
    //     0x1267354: add             x3, x3, HEAP, lsl #32
    // 0x1267358: cmp             w3, NULL
    // 0x126735c: b.ne            #0x1267364
    // 0x1267360: ldur            x3, [fp, #-0x28]
    // 0x1267364: r4 = LoadClassIdInstr(r0)
    //     0x1267364: ldur            x4, [x0, #-1]
    //     0x1267368: ubfx            x4, x4, #0xc, #0x14
    // 0x126736c: stp             x3, x0, [SP]
    // 0x1267370: mov             x0, x4
    // 0x1267374: mov             lr, x0
    // 0x1267378: ldr             lr, [x21, lr, lsl #3]
    // 0x126737c: blr             lr
    // 0x1267380: tbnz            w0, #4, #0x1267904
    // 0x1267384: ldr             x1, [fp, #0x10]
    // 0x1267388: LoadField: r0 = r1->field_8b
    //     0x1267388: ldur            w0, [x1, #0x8b]
    // 0x126738c: DecompressPointer r0
    //     0x126738c: add             x0, x0, HEAP, lsl #32
    // 0x1267390: cmp             w0, NULL
    // 0x1267394: b.ne            #0x126739c
    // 0x1267398: ldur            x0, [fp, #-0x30]
    // 0x126739c: ldr             x2, [fp, #0x18]
    // 0x12673a0: LoadField: r3 = r2->field_8b
    //     0x12673a0: ldur            w3, [x2, #0x8b]
    // 0x12673a4: DecompressPointer r3
    //     0x12673a4: add             x3, x3, HEAP, lsl #32
    // 0x12673a8: cmp             w3, NULL
    // 0x12673ac: b.ne            #0x12673b4
    // 0x12673b0: ldur            x3, [fp, #-0x28]
    // 0x12673b4: r4 = LoadClassIdInstr(r0)
    //     0x12673b4: ldur            x4, [x0, #-1]
    //     0x12673b8: ubfx            x4, x4, #0xc, #0x14
    // 0x12673bc: stp             x3, x0, [SP]
    // 0x12673c0: mov             x0, x4
    // 0x12673c4: mov             lr, x0
    // 0x12673c8: ldr             lr, [x21, lr, lsl #3]
    // 0x12673cc: blr             lr
    // 0x12673d0: tbnz            w0, #4, #0x1267904
    // 0x12673d4: ldr             x1, [fp, #0x10]
    // 0x12673d8: LoadField: r0 = r1->field_8f
    //     0x12673d8: ldur            w0, [x1, #0x8f]
    // 0x12673dc: DecompressPointer r0
    //     0x12673dc: add             x0, x0, HEAP, lsl #32
    // 0x12673e0: cmp             w0, NULL
    // 0x12673e4: b.ne            #0x12673ec
    // 0x12673e8: ldur            x0, [fp, #-0x30]
    // 0x12673ec: ldr             x2, [fp, #0x18]
    // 0x12673f0: LoadField: r3 = r2->field_8f
    //     0x12673f0: ldur            w3, [x2, #0x8f]
    // 0x12673f4: DecompressPointer r3
    //     0x12673f4: add             x3, x3, HEAP, lsl #32
    // 0x12673f8: cmp             w3, NULL
    // 0x12673fc: b.ne            #0x1267404
    // 0x1267400: ldur            x3, [fp, #-0x28]
    // 0x1267404: r4 = LoadClassIdInstr(r0)
    //     0x1267404: ldur            x4, [x0, #-1]
    //     0x1267408: ubfx            x4, x4, #0xc, #0x14
    // 0x126740c: stp             x3, x0, [SP]
    // 0x1267410: mov             x0, x4
    // 0x1267414: mov             lr, x0
    // 0x1267418: ldr             lr, [x21, lr, lsl #3]
    // 0x126741c: blr             lr
    // 0x1267420: tbnz            w0, #4, #0x1267904
    // 0x1267424: ldr             x1, [fp, #0x10]
    // 0x1267428: LoadField: r0 = r1->field_93
    //     0x1267428: ldur            w0, [x1, #0x93]
    // 0x126742c: DecompressPointer r0
    //     0x126742c: add             x0, x0, HEAP, lsl #32
    // 0x1267430: cmp             w0, NULL
    // 0x1267434: b.ne            #0x126743c
    // 0x1267438: ldur            x0, [fp, #-0x30]
    // 0x126743c: ldr             x2, [fp, #0x18]
    // 0x1267440: LoadField: r3 = r2->field_93
    //     0x1267440: ldur            w3, [x2, #0x93]
    // 0x1267444: DecompressPointer r3
    //     0x1267444: add             x3, x3, HEAP, lsl #32
    // 0x1267448: cmp             w3, NULL
    // 0x126744c: b.ne            #0x1267454
    // 0x1267450: ldur            x3, [fp, #-0x28]
    // 0x1267454: r4 = LoadClassIdInstr(r0)
    //     0x1267454: ldur            x4, [x0, #-1]
    //     0x1267458: ubfx            x4, x4, #0xc, #0x14
    // 0x126745c: stp             x3, x0, [SP]
    // 0x1267460: mov             x0, x4
    // 0x1267464: mov             lr, x0
    // 0x1267468: ldr             lr, [x21, lr, lsl #3]
    // 0x126746c: blr             lr
    // 0x1267470: tbnz            w0, #4, #0x1267904
    // 0x1267474: ldr             x1, [fp, #0x10]
    // 0x1267478: LoadField: r0 = r1->field_97
    //     0x1267478: ldur            w0, [x1, #0x97]
    // 0x126747c: DecompressPointer r0
    //     0x126747c: add             x0, x0, HEAP, lsl #32
    // 0x1267480: cmp             w0, NULL
    // 0x1267484: b.ne            #0x126748c
    // 0x1267488: ldur            x0, [fp, #-0x30]
    // 0x126748c: ldr             x2, [fp, #0x18]
    // 0x1267490: LoadField: r3 = r2->field_97
    //     0x1267490: ldur            w3, [x2, #0x97]
    // 0x1267494: DecompressPointer r3
    //     0x1267494: add             x3, x3, HEAP, lsl #32
    // 0x1267498: cmp             w3, NULL
    // 0x126749c: b.ne            #0x12674a4
    // 0x12674a0: ldur            x3, [fp, #-0x28]
    // 0x12674a4: r4 = LoadClassIdInstr(r0)
    //     0x12674a4: ldur            x4, [x0, #-1]
    //     0x12674a8: ubfx            x4, x4, #0xc, #0x14
    // 0x12674ac: stp             x3, x0, [SP]
    // 0x12674b0: mov             x0, x4
    // 0x12674b4: mov             lr, x0
    // 0x12674b8: ldr             lr, [x21, lr, lsl #3]
    // 0x12674bc: blr             lr
    // 0x12674c0: tbnz            w0, #4, #0x1267904
    // 0x12674c4: ldr             x1, [fp, #0x10]
    // 0x12674c8: LoadField: r0 = r1->field_9b
    //     0x12674c8: ldur            w0, [x1, #0x9b]
    // 0x12674cc: DecompressPointer r0
    //     0x12674cc: add             x0, x0, HEAP, lsl #32
    // 0x12674d0: cmp             w0, NULL
    // 0x12674d4: b.ne            #0x12674dc
    // 0x12674d8: ldur            x0, [fp, #-0x30]
    // 0x12674dc: ldr             x2, [fp, #0x18]
    // 0x12674e0: LoadField: r3 = r2->field_9b
    //     0x12674e0: ldur            w3, [x2, #0x9b]
    // 0x12674e4: DecompressPointer r3
    //     0x12674e4: add             x3, x3, HEAP, lsl #32
    // 0x12674e8: cmp             w3, NULL
    // 0x12674ec: b.ne            #0x12674f4
    // 0x12674f0: ldur            x3, [fp, #-0x28]
    // 0x12674f4: r4 = LoadClassIdInstr(r0)
    //     0x12674f4: ldur            x4, [x0, #-1]
    //     0x12674f8: ubfx            x4, x4, #0xc, #0x14
    // 0x12674fc: stp             x3, x0, [SP]
    // 0x1267500: mov             x0, x4
    // 0x1267504: mov             lr, x0
    // 0x1267508: ldr             lr, [x21, lr, lsl #3]
    // 0x126750c: blr             lr
    // 0x1267510: tbnz            w0, #4, #0x1267904
    // 0x1267514: ldr             x1, [fp, #0x10]
    // 0x1267518: LoadField: r0 = r1->field_9f
    //     0x1267518: ldur            w0, [x1, #0x9f]
    // 0x126751c: DecompressPointer r0
    //     0x126751c: add             x0, x0, HEAP, lsl #32
    // 0x1267520: cmp             w0, NULL
    // 0x1267524: b.ne            #0x126752c
    // 0x1267528: ldur            x0, [fp, #-0x30]
    // 0x126752c: ldr             x2, [fp, #0x18]
    // 0x1267530: LoadField: r3 = r2->field_9f
    //     0x1267530: ldur            w3, [x2, #0x9f]
    // 0x1267534: DecompressPointer r3
    //     0x1267534: add             x3, x3, HEAP, lsl #32
    // 0x1267538: cmp             w3, NULL
    // 0x126753c: b.ne            #0x1267544
    // 0x1267540: ldur            x3, [fp, #-0x28]
    // 0x1267544: r4 = LoadClassIdInstr(r0)
    //     0x1267544: ldur            x4, [x0, #-1]
    //     0x1267548: ubfx            x4, x4, #0xc, #0x14
    // 0x126754c: stp             x3, x0, [SP]
    // 0x1267550: mov             x0, x4
    // 0x1267554: mov             lr, x0
    // 0x1267558: ldr             lr, [x21, lr, lsl #3]
    // 0x126755c: blr             lr
    // 0x1267560: tbnz            w0, #4, #0x1267904
    // 0x1267564: ldr             x1, [fp, #0x10]
    // 0x1267568: LoadField: r0 = r1->field_a3
    //     0x1267568: ldur            w0, [x1, #0xa3]
    // 0x126756c: DecompressPointer r0
    //     0x126756c: add             x0, x0, HEAP, lsl #32
    // 0x1267570: cmp             w0, NULL
    // 0x1267574: b.ne            #0x126757c
    // 0x1267578: ldur            x0, [fp, #-0x40]
    // 0x126757c: ldr             x2, [fp, #0x18]
    // 0x1267580: LoadField: r3 = r2->field_a3
    //     0x1267580: ldur            w3, [x2, #0xa3]
    // 0x1267584: DecompressPointer r3
    //     0x1267584: add             x3, x3, HEAP, lsl #32
    // 0x1267588: cmp             w3, NULL
    // 0x126758c: b.ne            #0x1267594
    // 0x1267590: ldur            x3, [fp, #-0x38]
    // 0x1267594: r4 = LoadClassIdInstr(r0)
    //     0x1267594: ldur            x4, [x0, #-1]
    //     0x1267598: ubfx            x4, x4, #0xc, #0x14
    // 0x126759c: stp             x3, x0, [SP]
    // 0x12675a0: mov             x0, x4
    // 0x12675a4: mov             lr, x0
    // 0x12675a8: ldr             lr, [x21, lr, lsl #3]
    // 0x12675ac: blr             lr
    // 0x12675b0: tbnz            w0, #4, #0x1267904
    // 0x12675b4: ldr             x1, [fp, #0x10]
    // 0x12675b8: LoadField: r0 = r1->field_a7
    //     0x12675b8: ldur            w0, [x1, #0xa7]
    // 0x12675bc: DecompressPointer r0
    //     0x12675bc: add             x0, x0, HEAP, lsl #32
    // 0x12675c0: cmp             w0, NULL
    // 0x12675c4: b.ne            #0x12675d0
    // 0x12675c8: LoadField: r0 = r1->field_cb
    //     0x12675c8: ldur            w0, [x1, #0xcb]
    // 0x12675cc: DecompressPointer r0
    //     0x12675cc: add             x0, x0, HEAP, lsl #32
    // 0x12675d0: ldr             x2, [fp, #0x18]
    // 0x12675d4: LoadField: r3 = r2->field_a7
    //     0x12675d4: ldur            w3, [x2, #0xa7]
    // 0x12675d8: DecompressPointer r3
    //     0x12675d8: add             x3, x3, HEAP, lsl #32
    // 0x12675dc: cmp             w3, NULL
    // 0x12675e0: b.ne            #0x12675ec
    // 0x12675e4: LoadField: r3 = r2->field_cb
    //     0x12675e4: ldur            w3, [x2, #0xcb]
    // 0x12675e8: DecompressPointer r3
    //     0x12675e8: add             x3, x3, HEAP, lsl #32
    // 0x12675ec: r4 = LoadClassIdInstr(r0)
    //     0x12675ec: ldur            x4, [x0, #-1]
    //     0x12675f0: ubfx            x4, x4, #0xc, #0x14
    // 0x12675f4: stp             x3, x0, [SP]
    // 0x12675f8: mov             x0, x4
    // 0x12675fc: mov             lr, x0
    // 0x1267600: ldr             lr, [x21, lr, lsl #3]
    // 0x1267604: blr             lr
    // 0x1267608: tbnz            w0, #4, #0x1267904
    // 0x126760c: ldr             x1, [fp, #0x10]
    // 0x1267610: LoadField: r0 = r1->field_ab
    //     0x1267610: ldur            w0, [x1, #0xab]
    // 0x1267614: DecompressPointer r0
    //     0x1267614: add             x0, x0, HEAP, lsl #32
    // 0x1267618: cmp             w0, NULL
    // 0x126761c: b.ne            #0x1267628
    // 0x1267620: LoadField: r0 = r1->field_cb
    //     0x1267620: ldur            w0, [x1, #0xcb]
    // 0x1267624: DecompressPointer r0
    //     0x1267624: add             x0, x0, HEAP, lsl #32
    // 0x1267628: ldr             x2, [fp, #0x18]
    // 0x126762c: LoadField: r3 = r2->field_ab
    //     0x126762c: ldur            w3, [x2, #0xab]
    // 0x1267630: DecompressPointer r3
    //     0x1267630: add             x3, x3, HEAP, lsl #32
    // 0x1267634: cmp             w3, NULL
    // 0x1267638: b.ne            #0x1267644
    // 0x126763c: LoadField: r3 = r2->field_cb
    //     0x126763c: ldur            w3, [x2, #0xcb]
    // 0x1267640: DecompressPointer r3
    //     0x1267640: add             x3, x3, HEAP, lsl #32
    // 0x1267644: r4 = LoadClassIdInstr(r0)
    //     0x1267644: ldur            x4, [x0, #-1]
    //     0x1267648: ubfx            x4, x4, #0xc, #0x14
    // 0x126764c: stp             x3, x0, [SP]
    // 0x1267650: mov             x0, x4
    // 0x1267654: mov             lr, x0
    // 0x1267658: ldr             lr, [x21, lr, lsl #3]
    // 0x126765c: blr             lr
    // 0x1267660: tbnz            w0, #4, #0x1267904
    // 0x1267664: ldr             x0, [fp, #0x10]
    // 0x1267668: LoadField: r1 = r0->field_af
    //     0x1267668: ldur            w1, [x0, #0xaf]
    // 0x126766c: DecompressPointer r1
    //     0x126766c: add             x1, x1, HEAP, lsl #32
    // 0x1267670: cmp             w1, NULL
    // 0x1267674: b.ne            #0x1267684
    // 0x1267678: r2 = Instance_Color
    //     0x1267678: add             x2, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0x126767c: ldr             x2, [x2, #0x948]
    // 0x1267680: b               #0x1267688
    // 0x1267684: mov             x2, x1
    // 0x1267688: ldr             x1, [fp, #0x18]
    // 0x126768c: LoadField: r3 = r1->field_af
    //     0x126768c: ldur            w3, [x1, #0xaf]
    // 0x1267690: DecompressPointer r3
    //     0x1267690: add             x3, x3, HEAP, lsl #32
    // 0x1267694: cmp             w3, NULL
    // 0x1267698: b.ne            #0x12676a4
    // 0x126769c: r3 = Instance_Color
    //     0x126769c: add             x3, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0x12676a0: ldr             x3, [x3, #0x948]
    // 0x12676a4: stp             x3, x2, [SP]
    // 0x12676a8: r0 = ==()
    //     0x12676a8: bl              #0x128cb50  ; [dart:ui] Color::==
    // 0x12676ac: tbnz            w0, #4, #0x1267904
    // 0x12676b0: ldr             x0, [fp, #0x10]
    // 0x12676b4: LoadField: r1 = r0->field_b3
    //     0x12676b4: ldur            w1, [x0, #0xb3]
    // 0x12676b8: DecompressPointer r1
    //     0x12676b8: add             x1, x1, HEAP, lsl #32
    // 0x12676bc: cmp             w1, NULL
    // 0x12676c0: b.ne            #0x12676d0
    // 0x12676c4: r2 = Instance_Color
    //     0x12676c4: add             x2, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0x12676c8: ldr             x2, [x2, #0x948]
    // 0x12676cc: b               #0x12676d4
    // 0x12676d0: mov             x2, x1
    // 0x12676d4: ldr             x1, [fp, #0x18]
    // 0x12676d8: LoadField: r3 = r1->field_b3
    //     0x12676d8: ldur            w3, [x1, #0xb3]
    // 0x12676dc: DecompressPointer r3
    //     0x12676dc: add             x3, x3, HEAP, lsl #32
    // 0x12676e0: cmp             w3, NULL
    // 0x12676e4: b.ne            #0x12676f0
    // 0x12676e8: r3 = Instance_Color
    //     0x12676e8: add             x3, PP, #0x12, lsl #12  ; [pp+0x12948] Obj!Color@12a15c1
    //     0x12676ec: ldr             x3, [x3, #0x948]
    // 0x12676f0: stp             x3, x2, [SP]
    // 0x12676f4: r0 = ==()
    //     0x12676f4: bl              #0x128cb50  ; [dart:ui] Color::==
    // 0x12676f8: tbnz            w0, #4, #0x1267904
    // 0x12676fc: ldr             x1, [fp, #0x10]
    // 0x1267700: LoadField: r0 = r1->field_b7
    //     0x1267700: ldur            w0, [x1, #0xb7]
    // 0x1267704: DecompressPointer r0
    //     0x1267704: add             x0, x0, HEAP, lsl #32
    // 0x1267708: cmp             w0, NULL
    // 0x126770c: b.ne            #0x1267714
    // 0x1267710: ldur            x0, [fp, #-0x40]
    // 0x1267714: ldr             x2, [fp, #0x18]
    // 0x1267718: LoadField: r3 = r2->field_b7
    //     0x1267718: ldur            w3, [x2, #0xb7]
    // 0x126771c: DecompressPointer r3
    //     0x126771c: add             x3, x3, HEAP, lsl #32
    // 0x1267720: cmp             w3, NULL
    // 0x1267724: b.ne            #0x126772c
    // 0x1267728: ldur            x3, [fp, #-0x38]
    // 0x126772c: r4 = LoadClassIdInstr(r0)
    //     0x126772c: ldur            x4, [x0, #-1]
    //     0x1267730: ubfx            x4, x4, #0xc, #0x14
    // 0x1267734: stp             x3, x0, [SP]
    // 0x1267738: mov             x0, x4
    // 0x126773c: mov             lr, x0
    // 0x1267740: ldr             lr, [x21, lr, lsl #3]
    // 0x1267744: blr             lr
    // 0x1267748: tbnz            w0, #4, #0x1267904
    // 0x126774c: ldr             x1, [fp, #0x10]
    // 0x1267750: LoadField: r0 = r1->field_bb
    //     0x1267750: ldur            w0, [x1, #0xbb]
    // 0x1267754: DecompressPointer r0
    //     0x1267754: add             x0, x0, HEAP, lsl #32
    // 0x1267758: cmp             w0, NULL
    // 0x126775c: b.ne            #0x1267764
    // 0x1267760: ldur            x0, [fp, #-0x30]
    // 0x1267764: ldr             x2, [fp, #0x18]
    // 0x1267768: LoadField: r3 = r2->field_bb
    //     0x1267768: ldur            w3, [x2, #0xbb]
    // 0x126776c: DecompressPointer r3
    //     0x126776c: add             x3, x3, HEAP, lsl #32
    // 0x1267770: cmp             w3, NULL
    // 0x1267774: b.ne            #0x126777c
    // 0x1267778: ldur            x3, [fp, #-0x28]
    // 0x126777c: r4 = LoadClassIdInstr(r0)
    //     0x126777c: ldur            x4, [x0, #-1]
    //     0x1267780: ubfx            x4, x4, #0xc, #0x14
    // 0x1267784: stp             x3, x0, [SP]
    // 0x1267788: mov             x0, x4
    // 0x126778c: mov             lr, x0
    // 0x1267790: ldr             lr, [x21, lr, lsl #3]
    // 0x1267794: blr             lr
    // 0x1267798: tbnz            w0, #4, #0x1267904
    // 0x126779c: ldr             x1, [fp, #0x10]
    // 0x12677a0: LoadField: r0 = r1->field_bf
    //     0x12677a0: ldur            w0, [x1, #0xbf]
    // 0x12677a4: DecompressPointer r0
    //     0x12677a4: add             x0, x0, HEAP, lsl #32
    // 0x12677a8: cmp             w0, NULL
    // 0x12677ac: b.ne            #0x12677b4
    // 0x12677b0: ldur            x0, [fp, #-0x20]
    // 0x12677b4: ldr             x2, [fp, #0x18]
    // 0x12677b8: LoadField: r3 = r2->field_bf
    //     0x12677b8: ldur            w3, [x2, #0xbf]
    // 0x12677bc: DecompressPointer r3
    //     0x12677bc: add             x3, x3, HEAP, lsl #32
    // 0x12677c0: cmp             w3, NULL
    // 0x12677c4: b.ne            #0x12677cc
    // 0x12677c8: ldur            x3, [fp, #-0x18]
    // 0x12677cc: r4 = LoadClassIdInstr(r0)
    //     0x12677cc: ldur            x4, [x0, #-1]
    //     0x12677d0: ubfx            x4, x4, #0xc, #0x14
    // 0x12677d4: stp             x3, x0, [SP]
    // 0x12677d8: mov             x0, x4
    // 0x12677dc: mov             lr, x0
    // 0x12677e0: ldr             lr, [x21, lr, lsl #3]
    // 0x12677e4: blr             lr
    // 0x12677e8: tbnz            w0, #4, #0x1267904
    // 0x12677ec: ldr             x1, [fp, #0x10]
    // 0x12677f0: LoadField: r0 = r1->field_c3
    //     0x12677f0: ldur            w0, [x1, #0xc3]
    // 0x12677f4: DecompressPointer r0
    //     0x12677f4: add             x0, x0, HEAP, lsl #32
    // 0x12677f8: cmp             w0, NULL
    // 0x12677fc: b.ne            #0x1267804
    // 0x1267800: ldur            x0, [fp, #-0x10]
    // 0x1267804: ldr             x2, [fp, #0x18]
    // 0x1267808: LoadField: r3 = r2->field_c3
    //     0x1267808: ldur            w3, [x2, #0xc3]
    // 0x126780c: DecompressPointer r3
    //     0x126780c: add             x3, x3, HEAP, lsl #32
    // 0x1267810: cmp             w3, NULL
    // 0x1267814: b.ne            #0x126781c
    // 0x1267818: ldur            x3, [fp, #-8]
    // 0x126781c: r4 = LoadClassIdInstr(r0)
    //     0x126781c: ldur            x4, [x0, #-1]
    //     0x1267820: ubfx            x4, x4, #0xc, #0x14
    // 0x1267824: stp             x3, x0, [SP]
    // 0x1267828: mov             x0, x4
    // 0x126782c: mov             lr, x0
    // 0x1267830: ldr             lr, [x21, lr, lsl #3]
    // 0x1267834: blr             lr
    // 0x1267838: tbnz            w0, #4, #0x1267904
    // 0x126783c: ldr             x2, [fp, #0x18]
    // 0x1267840: ldr             x1, [fp, #0x10]
    // 0x1267844: LoadField: r0 = r1->field_c7
    //     0x1267844: ldur            w0, [x1, #0xc7]
    // 0x1267848: DecompressPointer r0
    //     0x1267848: add             x0, x0, HEAP, lsl #32
    // 0x126784c: LoadField: r3 = r2->field_c7
    //     0x126784c: ldur            w3, [x2, #0xc7]
    // 0x1267850: DecompressPointer r3
    //     0x1267850: add             x3, x3, HEAP, lsl #32
    // 0x1267854: r4 = LoadClassIdInstr(r0)
    //     0x1267854: ldur            x4, [x0, #-1]
    //     0x1267858: ubfx            x4, x4, #0xc, #0x14
    // 0x126785c: stp             x3, x0, [SP]
    // 0x1267860: mov             x0, x4
    // 0x1267864: mov             lr, x0
    // 0x1267868: ldr             lr, [x21, lr, lsl #3]
    // 0x126786c: blr             lr
    // 0x1267870: tbnz            w0, #4, #0x1267904
    // 0x1267874: ldr             x2, [fp, #0x18]
    // 0x1267878: ldr             x1, [fp, #0x10]
    // 0x126787c: LoadField: r0 = r1->field_cb
    //     0x126787c: ldur            w0, [x1, #0xcb]
    // 0x1267880: DecompressPointer r0
    //     0x1267880: add             x0, x0, HEAP, lsl #32
    // 0x1267884: LoadField: r3 = r2->field_cb
    //     0x1267884: ldur            w3, [x2, #0xcb]
    // 0x1267888: DecompressPointer r3
    //     0x1267888: add             x3, x3, HEAP, lsl #32
    // 0x126788c: r4 = LoadClassIdInstr(r0)
    //     0x126788c: ldur            x4, [x0, #-1]
    //     0x1267890: ubfx            x4, x4, #0xc, #0x14
    // 0x1267894: stp             x3, x0, [SP]
    // 0x1267898: mov             x0, x4
    // 0x126789c: mov             lr, x0
    // 0x12678a0: ldr             lr, [x21, lr, lsl #3]
    // 0x12678a4: blr             lr
    // 0x12678a8: tbnz            w0, #4, #0x1267904
    // 0x12678ac: ldr             x0, [fp, #0x10]
    // 0x12678b0: LoadField: r1 = r0->field_83
    //     0x12678b0: ldur            w1, [x0, #0x83]
    // 0x12678b4: DecompressPointer r1
    //     0x12678b4: add             x1, x1, HEAP, lsl #32
    // 0x12678b8: cmp             w1, NULL
    // 0x12678bc: b.ne            #0x12678c4
    // 0x12678c0: ldur            x1, [fp, #-0x30]
    // 0x12678c4: ldr             x0, [fp, #0x18]
    // 0x12678c8: LoadField: r2 = r0->field_83
    //     0x12678c8: ldur            w2, [x0, #0x83]
    // 0x12678cc: DecompressPointer r2
    //     0x12678cc: add             x2, x2, HEAP, lsl #32
    // 0x12678d0: cmp             w2, NULL
    // 0x12678d4: b.ne            #0x12678e0
    // 0x12678d8: ldur            x0, [fp, #-0x28]
    // 0x12678dc: b               #0x12678e4
    // 0x12678e0: mov             x0, x2
    // 0x12678e4: r2 = LoadClassIdInstr(r1)
    //     0x12678e4: ldur            x2, [x1, #-1]
    //     0x12678e8: ubfx            x2, x2, #0xc, #0x14
    // 0x12678ec: stp             x0, x1, [SP]
    // 0x12678f0: mov             x0, x2
    // 0x12678f4: mov             lr, x0
    // 0x12678f8: ldr             lr, [x21, lr, lsl #3]
    // 0x12678fc: blr             lr
    // 0x1267900: b               #0x1267908
    // 0x1267904: r0 = false
    //     0x1267904: add             x0, NULL, #0x30  ; false
    // 0x1267908: LeaveFrame
    //     0x1267908: mov             SP, fp
    //     0x126790c: ldp             fp, lr, [SP], #0x10
    // 0x1267910: ret
    //     0x1267910: ret             
    // 0x1267914: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1267914: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1267918: b               #0x1266a40
  }
}
