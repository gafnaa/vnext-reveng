// lib: , url: package:flutter/src/material/slider.dart

// class id: 1048945, size: 0x8
class :: {
}

// class id: 4845, size: 0x5c, field offset: 0x54
class _RenderValueIndicator extends _MixinApplication95&RenderBox&RelayoutWhenSystemFontsChangeMixin {

  late CurvedAnimation _valueIndicatorAnimation; // offset: 0x54

  _ dispose(/* No info */) {
    // ** addr: 0xc03494, size: 0x64
    // 0xc03494: EnterFrame
    //     0xc03494: stp             fp, lr, [SP, #-0x10]!
    //     0xc03498: mov             fp, SP
    // 0xc0349c: AllocStack(0x8)
    //     0xc0349c: sub             SP, SP, #8
    // 0xc034a0: SetupParameters(_RenderValueIndicator this /* r1 => r0, fp-0x8 */)
    //     0xc034a0: mov             x0, x1
    //     0xc034a4: stur            x1, [fp, #-8]
    // 0xc034a8: CheckStackOverflow
    //     0xc034a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc034ac: cmp             SP, x16
    //     0xc034b0: b.ls            #0xc034e4
    // 0xc034b4: LoadField: r1 = r0->field_53
    //     0xc034b4: ldur            w1, [x0, #0x53]
    // 0xc034b8: DecompressPointer r1
    //     0xc034b8: add             x1, x1, HEAP, lsl #32
    // 0xc034bc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc034c0: cmp             w1, w16
    // 0xc034c4: b.eq            #0xc034ec
    // 0xc034c8: r0 = dispose()
    //     0xc034c8: bl              #0xb29014  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::dispose
    // 0xc034cc: ldur            x1, [fp, #-8]
    // 0xc034d0: r0 = dispose()
    //     0xc034d0: bl              #0xc04c8c  ; [package:flutter/src/rendering/object.dart] RenderObject::dispose
    // 0xc034d4: r0 = Null
    //     0xc034d4: mov             x0, NULL
    // 0xc034d8: LeaveFrame
    //     0xc034d8: mov             SP, fp
    //     0xc034dc: ldp             fp, lr, [SP], #0x10
    // 0xc034e0: ret
    //     0xc034e0: ret             
    // 0xc034e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc034e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc034e8: b               #0xc034b4
    // 0xc034ec: r9 = _valueIndicatorAnimation
    //     0xc034ec: add             x9, PP, #0xad, lsl #12  ; [pp+0xad7c8] Field <_RenderValueIndicator@125231897._valueIndicatorAnimation@125231897>: late (offset: 0x54)
    //     0xc034f0: ldr             x9, [x9, #0x7c8]
    // 0xc034f4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc034f4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ detach(/* No info */) {
    // ** addr: 0xc06d8c, size: 0xbc
    // 0xc06d8c: EnterFrame
    //     0xc06d8c: stp             fp, lr, [SP, #-0x10]!
    //     0xc06d90: mov             fp, SP
    // 0xc06d94: AllocStack(0x10)
    //     0xc06d94: sub             SP, SP, #0x10
    // 0xc06d98: SetupParameters(_RenderValueIndicator this /* r1 => r0, fp-0x10 */)
    //     0xc06d98: mov             x0, x1
    //     0xc06d9c: stur            x1, [fp, #-0x10]
    // 0xc06da0: CheckStackOverflow
    //     0xc06da0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc06da4: cmp             SP, x16
    //     0xc06da8: b.ls            #0xc06e28
    // 0xc06dac: LoadField: r3 = r0->field_53
    //     0xc06dac: ldur            w3, [x0, #0x53]
    // 0xc06db0: DecompressPointer r3
    //     0xc06db0: add             x3, x3, HEAP, lsl #32
    // 0xc06db4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc06db8: cmp             w3, w16
    // 0xc06dbc: b.eq            #0xc06e30
    // 0xc06dc0: mov             x2, x0
    // 0xc06dc4: stur            x3, [fp, #-8]
    // 0xc06dc8: r1 = Function 'markNeedsPaint':.
    //     0xc06dc8: add             x1, PP, #0x90, lsl #12  ; [pp+0x901f0] AnonymousClosure: (0xbf0a50), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0xbf0858)
    //     0xc06dcc: ldr             x1, [x1, #0x1f0]
    // 0xc06dd0: r0 = AllocateClosure()
    //     0xc06dd0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc06dd4: ldur            x1, [fp, #-8]
    // 0xc06dd8: mov             x2, x0
    // 0xc06ddc: stur            x0, [fp, #-8]
    // 0xc06de0: r0 = removeListener()
    //     0xc06de0: bl              #0xd00b50  ; [dart:mixin_deduplication] _MixinApplication113&Animation&AnimationWithParentMixin::removeListener
    // 0xc06de4: ldur            x0, [fp, #-0x10]
    // 0xc06de8: LoadField: r1 = r0->field_57
    //     0xc06de8: ldur            w1, [x0, #0x57]
    // 0xc06dec: DecompressPointer r1
    //     0xc06dec: add             x1, x1, HEAP, lsl #32
    // 0xc06df0: LoadField: r2 = r1->field_27
    //     0xc06df0: ldur            w2, [x1, #0x27]
    // 0xc06df4: DecompressPointer r2
    //     0xc06df4: add             x2, x2, HEAP, lsl #32
    // 0xc06df8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc06dfc: cmp             w2, w16
    // 0xc06e00: b.eq            #0xc06e3c
    // 0xc06e04: mov             x1, x2
    // 0xc06e08: ldur            x2, [fp, #-8]
    // 0xc06e0c: r0 = removeListener()
    //     0xc06e0c: bl              #0xd00c74  ; [dart:mixin_deduplication] _MixinApplication455&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::removeListener
    // 0xc06e10: ldur            x1, [fp, #-0x10]
    // 0xc06e14: r0 = detach()
    //     0xc06e14: bl              #0xc067fc  ; [dart:mixin_deduplication] _MixinApplication95&RenderBox&RelayoutWhenSystemFontsChangeMixin::detach
    // 0xc06e18: r0 = Null
    //     0xc06e18: mov             x0, NULL
    // 0xc06e1c: LeaveFrame
    //     0xc06e1c: mov             SP, fp
    //     0xc06e20: ldp             fp, lr, [SP], #0x10
    // 0xc06e24: ret
    //     0xc06e24: ret             
    // 0xc06e28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc06e28: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc06e2c: b               #0xc06dac
    // 0xc06e30: r9 = _valueIndicatorAnimation
    //     0xc06e30: add             x9, PP, #0xad, lsl #12  ; [pp+0xad7c8] Field <_RenderValueIndicator@125231897._valueIndicatorAnimation@125231897>: late (offset: 0x54)
    //     0xc06e34: ldr             x9, [x9, #0x7c8]
    // 0xc06e38: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc06e38: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xc06e3c: r9 = positionController
    //     0xc06e3c: add             x9, PP, #0x99, lsl #12  ; [pp+0x99018] Field <_SliderState@125231897.positionController>: late (offset: 0x28)
    //     0xc06e40: ldr             x9, [x9, #0x18]
    // 0xc06e44: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc06e44: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ attach(/* No info */) {
    // ** addr: 0xc0a698, size: 0xc0
    // 0xc0a698: EnterFrame
    //     0xc0a698: stp             fp, lr, [SP, #-0x10]!
    //     0xc0a69c: mov             fp, SP
    // 0xc0a6a0: AllocStack(0x10)
    //     0xc0a6a0: sub             SP, SP, #0x10
    // 0xc0a6a4: SetupParameters(_RenderValueIndicator this /* r1 => r0, fp-0x8 */)
    //     0xc0a6a4: mov             x0, x1
    //     0xc0a6a8: stur            x1, [fp, #-8]
    // 0xc0a6ac: CheckStackOverflow
    //     0xc0a6ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc0a6b0: cmp             SP, x16
    //     0xc0a6b4: b.ls            #0xc0a738
    // 0xc0a6b8: mov             x1, x0
    // 0xc0a6bc: r0 = attach()
    //     0xc0a6bc: bl              #0xc0a3a4  ; [dart:mixin_deduplication] _MixinApplication95&RenderBox&RelayoutWhenSystemFontsChangeMixin::attach
    // 0xc0a6c0: ldur            x0, [fp, #-8]
    // 0xc0a6c4: LoadField: r3 = r0->field_53
    //     0xc0a6c4: ldur            w3, [x0, #0x53]
    // 0xc0a6c8: DecompressPointer r3
    //     0xc0a6c8: add             x3, x3, HEAP, lsl #32
    // 0xc0a6cc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc0a6d0: cmp             w3, w16
    // 0xc0a6d4: b.eq            #0xc0a740
    // 0xc0a6d8: mov             x2, x0
    // 0xc0a6dc: stur            x3, [fp, #-0x10]
    // 0xc0a6e0: r1 = Function 'markNeedsPaint':.
    //     0xc0a6e0: add             x1, PP, #0x90, lsl #12  ; [pp+0x901f0] AnonymousClosure: (0xbf0a50), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0xbf0858)
    //     0xc0a6e4: ldr             x1, [x1, #0x1f0]
    // 0xc0a6e8: r0 = AllocateClosure()
    //     0xc0a6e8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc0a6ec: ldur            x1, [fp, #-0x10]
    // 0xc0a6f0: mov             x2, x0
    // 0xc0a6f4: stur            x0, [fp, #-0x10]
    // 0xc0a6f8: r0 = addListener()
    //     0xc0a6f8: bl              #0xd04330  ; [dart:mixin_deduplication] _MixinApplication113&Animation&AnimationWithParentMixin::addListener
    // 0xc0a6fc: ldur            x0, [fp, #-8]
    // 0xc0a700: LoadField: r1 = r0->field_57
    //     0xc0a700: ldur            w1, [x0, #0x57]
    // 0xc0a704: DecompressPointer r1
    //     0xc0a704: add             x1, x1, HEAP, lsl #32
    // 0xc0a708: LoadField: r0 = r1->field_27
    //     0xc0a708: ldur            w0, [x1, #0x27]
    // 0xc0a70c: DecompressPointer r0
    //     0xc0a70c: add             x0, x0, HEAP, lsl #32
    // 0xc0a710: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc0a714: cmp             w0, w16
    // 0xc0a718: b.eq            #0xc0a74c
    // 0xc0a71c: mov             x1, x0
    // 0xc0a720: ldur            x2, [fp, #-0x10]
    // 0xc0a724: r0 = addListener()
    //     0xc0a724: bl              #0xd0440c  ; [dart:mixin_deduplication] _MixinApplication455&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::addListener
    // 0xc0a728: r0 = Null
    //     0xc0a728: mov             x0, NULL
    // 0xc0a72c: LeaveFrame
    //     0xc0a72c: mov             SP, fp
    //     0xc0a730: ldp             fp, lr, [SP], #0x10
    // 0xc0a734: ret
    //     0xc0a734: ret             
    // 0xc0a738: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc0a738: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc0a73c: b               #0xc0a6b8
    // 0xc0a740: r9 = _valueIndicatorAnimation
    //     0xc0a740: add             x9, PP, #0xad, lsl #12  ; [pp+0xad7c8] Field <_RenderValueIndicator@125231897._valueIndicatorAnimation@125231897>: late (offset: 0x54)
    //     0xc0a744: ldr             x9, [x9, #0x7c8]
    // 0xc0a748: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc0a748: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xc0a74c: r9 = positionController
    //     0xc0a74c: add             x9, PP, #0x99, lsl #12  ; [pp+0x99018] Field <_SliderState@125231897.positionController>: late (offset: 0x28)
    //     0xc0a750: ldr             x9, [x9, #0x18]
    // 0xc0a754: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc0a754: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ paint(/* No info */) {
    // ** addr: 0xc25558, size: 0x60
    // 0xc25558: EnterFrame
    //     0xc25558: stp             fp, lr, [SP, #-0x10]!
    //     0xc2555c: mov             fp, SP
    // 0xc25560: AllocStack(0x18)
    //     0xc25560: sub             SP, SP, #0x18
    // 0xc25564: CheckStackOverflow
    //     0xc25564: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc25568: cmp             SP, x16
    //     0xc2556c: b.ls            #0xc255b0
    // 0xc25570: LoadField: r0 = r1->field_57
    //     0xc25570: ldur            w0, [x1, #0x57]
    // 0xc25574: DecompressPointer r0
    //     0xc25574: add             x0, x0, HEAP, lsl #32
    // 0xc25578: LoadField: r1 = r0->field_37
    //     0xc25578: ldur            w1, [x0, #0x37]
    // 0xc2557c: DecompressPointer r1
    //     0xc2557c: add             x1, x1, HEAP, lsl #32
    // 0xc25580: cmp             w1, NULL
    // 0xc25584: b.eq            #0xc255a0
    // 0xc25588: stp             x2, x1, [SP, #8]
    // 0xc2558c: str             x3, [SP]
    // 0xc25590: mov             x0, x1
    // 0xc25594: ClosureCall
    //     0xc25594: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xc25598: ldur            x2, [x0, #0x1f]
    //     0xc2559c: blr             x2
    // 0xc255a0: r0 = Null
    //     0xc255a0: mov             x0, NULL
    // 0xc255a4: LeaveFrame
    //     0xc255a4: mov             SP, fp
    //     0xc255a8: ldp             fp, lr, [SP], #0x10
    // 0xc255ac: ret
    //     0xc255ac: ret             
    // 0xc255b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc255b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc255b4: b               #0xc25570
  }
  _ _RenderValueIndicator(/* No info */) {
    // ** addr: 0x11c0a20, size: 0x110
    // 0x11c0a20: EnterFrame
    //     0x11c0a20: stp             fp, lr, [SP, #-0x10]!
    //     0x11c0a24: mov             fp, SP
    // 0x11c0a28: AllocStack(0x10)
    //     0x11c0a28: sub             SP, SP, #0x10
    // 0x11c0a2c: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x11c0a30: r3 = false
    //     0x11c0a30: add             x3, NULL, #0x30  ; false
    // 0x11c0a34: stur            x1, [fp, #-8]
    // 0x11c0a38: mov             x16, x2
    // 0x11c0a3c: mov             x2, x1
    // 0x11c0a40: mov             x1, x16
    // 0x11c0a44: CheckStackOverflow
    //     0x11c0a44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11c0a48: cmp             SP, x16
    //     0x11c0a4c: b.ls            #0x11c0b1c
    // 0x11c0a50: StoreField: r2->field_53 = r0
    //     0x11c0a50: stur            w0, [x2, #0x53]
    // 0x11c0a54: mov             x0, x1
    // 0x11c0a58: StoreField: r2->field_57 = r0
    //     0x11c0a58: stur            w0, [x2, #0x57]
    //     0x11c0a5c: ldurb           w16, [x2, #-1]
    //     0x11c0a60: ldurb           w17, [x0, #-1]
    //     0x11c0a64: and             x16, x17, x16, lsr #2
    //     0x11c0a68: tst             x16, HEAP, lsr #32
    //     0x11c0a6c: b.eq            #0x11c0a74
    //     0x11c0a70: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11c0a74: StoreField: r2->field_4f = r3
    //     0x11c0a74: stur            w3, [x2, #0x4f]
    // 0x11c0a78: r0 = _LayoutCacheStorage()
    //     0x11c0a78: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11c0a7c: ldur            x2, [fp, #-8]
    // 0x11c0a80: StoreField: r2->field_47 = r0
    //     0x11c0a80: stur            w0, [x2, #0x47]
    //     0x11c0a84: ldurb           w16, [x2, #-1]
    //     0x11c0a88: ldurb           w17, [x0, #-1]
    //     0x11c0a8c: and             x16, x17, x16, lsr #2
    //     0x11c0a90: tst             x16, HEAP, lsr #32
    //     0x11c0a94: b.eq            #0x11c0a9c
    //     0x11c0a98: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11c0a9c: mov             x1, x2
    // 0x11c0aa0: r0 = RenderObject()
    //     0x11c0aa0: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11c0aa4: ldur            x0, [fp, #-8]
    // 0x11c0aa8: LoadField: r1 = r0->field_57
    //     0x11c0aa8: ldur            w1, [x0, #0x57]
    // 0x11c0aac: DecompressPointer r1
    //     0x11c0aac: add             x1, x1, HEAP, lsl #32
    // 0x11c0ab0: LoadField: r3 = r1->field_1f
    //     0x11c0ab0: ldur            w3, [x1, #0x1f]
    // 0x11c0ab4: DecompressPointer r3
    //     0x11c0ab4: add             x3, x3, HEAP, lsl #32
    // 0x11c0ab8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11c0abc: cmp             w3, w16
    // 0x11c0ac0: b.eq            #0x11c0b24
    // 0x11c0ac4: stur            x3, [fp, #-0x10]
    // 0x11c0ac8: r1 = <double>
    //     0x11c0ac8: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0x11c0acc: r0 = CurvedAnimation()
    //     0x11c0acc: bl              #0x915e4c  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x11c0ad0: mov             x1, x0
    // 0x11c0ad4: ldur            x3, [fp, #-0x10]
    // 0x11c0ad8: r2 = Instance_Cubic
    //     0x11c0ad8: ldr             x2, [PP, #0x5660]  ; [pp+0x5660] Obj!Cubic@129f451
    // 0x11c0adc: stur            x0, [fp, #-0x10]
    // 0x11c0ae0: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x11c0ae0: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x11c0ae4: r0 = CurvedAnimation()
    //     0x11c0ae4: bl              #0x915be4  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x11c0ae8: ldur            x0, [fp, #-0x10]
    // 0x11c0aec: ldur            x1, [fp, #-8]
    // 0x11c0af0: StoreField: r1->field_53 = r0
    //     0x11c0af0: stur            w0, [x1, #0x53]
    //     0x11c0af4: ldurb           w16, [x1, #-1]
    //     0x11c0af8: ldurb           w17, [x0, #-1]
    //     0x11c0afc: and             x16, x17, x16, lsr #2
    //     0x11c0b00: tst             x16, HEAP, lsr #32
    //     0x11c0b04: b.eq            #0x11c0b0c
    //     0x11c0b08: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11c0b0c: r0 = Null
    //     0x11c0b0c: mov             x0, NULL
    // 0x11c0b10: LeaveFrame
    //     0x11c0b10: mov             SP, fp
    //     0x11c0b14: ldp             fp, lr, [SP], #0x10
    // 0x11c0b18: ret
    //     0x11c0b18: ret             
    // 0x11c0b1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11c0b1c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11c0b20: b               #0x11c0a50
    // 0x11c0b24: r9 = valueIndicatorController
    //     0x11c0b24: add             x9, PP, #0x99, lsl #12  ; [pp+0x99008] Field <_SliderState@125231897.valueIndicatorController>: late (offset: 0x20)
    //     0x11c0b28: ldr             x9, [x9, #8]
    // 0x11c0b2c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x11c0b2c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 4846, size: 0xd4, field offset: 0x54
class _RenderSlider extends _MixinApplication95&RenderBox&RelayoutWhenSystemFontsChangeMixin {

  late HorizontalDragGestureRecognizer _drag; // offset: 0x68
  late TapGestureRecognizer _tap; // offset: 0x6c
  late CurvedAnimation _enableAnimation; // offset: 0x60
  late CurvedAnimation _overlayAnimation; // offset: 0x58
  late CurvedAnimation _valueIndicatorAnimation; // offset: 0x5c

  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0xb1dd50, size: 0x24
    // 0xb1dd50: EnterFrame
    //     0xb1dd50: stp             fp, lr, [SP, #-0x10]!
    //     0xb1dd54: mov             fp, SP
    // 0xb1dd58: ldr             x2, [fp, #0x10]
    // 0xb1dd5c: r1 = Function 'computeMinIntrinsicWidth':.
    //     0xb1dd5c: add             x1, PP, #0xad, lsl #12  ; [pp+0xad718] AnonymousClosure: (0xb1e1a0), in [package:flutter/src/material/slider.dart] _RenderSlider::computeMaxIntrinsicWidth (0xb2e718)
    //     0xb1dd60: ldr             x1, [x1, #0x718]
    // 0xb1dd64: r0 = AllocateClosure()
    //     0xb1dd64: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb1dd68: LeaveFrame
    //     0xb1dd68: mov             SP, fp
    //     0xb1dd6c: ldp             fp, lr, [SP], #0x10
    // 0xb1dd70: ret
    //     0xb1dd70: ret             
  }
  double dyn:get:value(_RenderSlider) {
    // ** addr: 0xb1dd8c, size: 0x70
    // 0xb1dd8c: EnterFrame
    //     0xb1dd8c: stp             fp, lr, [SP, #-0x10]!
    //     0xb1dd90: mov             fp, SP
    // 0xb1dd94: ldr             x1, [fp, #0x10]
    // 0xb1dd98: LoadField: d0 = r1->field_83
    //     0xb1dd98: ldur            d0, [x1, #0x83]
    // 0xb1dd9c: r0 = inline_Allocate_Double()
    //     0xb1dd9c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb1dda0: add             x0, x0, #0x10
    //     0xb1dda4: cmp             x1, x0
    //     0xb1dda8: b.ls            #0xb1ddd4
    //     0xb1ddac: str             x0, [THR, #0x60]  ; THR::top
    //     0xb1ddb0: sub             x0, x0, #0xf
    //     0xb1ddb4: mov             x1, #0xe19c
    //     0xb1ddb8: movk            x1, #3, lsl #16
    //     0xb1ddbc: stur            x1, [x0, #-1]
    // 0xb1ddc0: dmb             ishst
    // 0xb1ddc4: StoreField: r0->field_7 = d0
    //     0xb1ddc4: stur            d0, [x0, #7]
    // 0xb1ddc8: LeaveFrame
    //     0xb1ddc8: mov             SP, fp
    //     0xb1ddcc: ldp             fp, lr, [SP], #0x10
    // 0xb1ddd0: ret
    //     0xb1ddd0: ret             
    // 0xb1ddd4: SaveReg d0
    //     0xb1ddd4: str             q0, [SP, #-0x10]!
    // 0xb1ddd8: r0 = AllocateDouble()
    //     0xb1ddd8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb1dddc: RestoreReg d0
    //     0xb1dddc: ldr             q0, [SP], #0x10
    // 0xb1dde0: b               #0xb1ddc4
  }
  void dyn:set:value(_RenderSlider, double) {
    // ** addr: 0xb1ddfc, size: 0x80
    // 0xb1ddfc: EnterFrame
    //     0xb1ddfc: stp             fp, lr, [SP, #-0x10]!
    //     0xb1de00: mov             fp, SP
    // 0xb1de04: CheckStackOverflow
    //     0xb1de04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1de08: cmp             SP, x16
    //     0xb1de0c: b.ls            #0xb1de5c
    // 0xb1de10: ldr             x0, [fp, #0x10]
    // 0xb1de14: r2 = Null
    //     0xb1de14: mov             x2, NULL
    // 0xb1de18: r1 = Null
    //     0xb1de18: mov             x1, NULL
    // 0xb1de1c: r4 = 60
    //     0xb1de1c: mov             x4, #0x3c
    // 0xb1de20: branchIfSmi(r0, 0xb1de2c)
    //     0xb1de20: tbz             w0, #0, #0xb1de2c
    // 0xb1de24: r4 = LoadClassIdInstr(r0)
    //     0xb1de24: ldur            x4, [x0, #-1]
    //     0xb1de28: ubfx            x4, x4, #0xc, #0x14
    // 0xb1de2c: cmp             x4, #0x3e
    // 0xb1de30: b.eq            #0xb1de44
    // 0xb1de34: r8 = double
    //     0xb1de34: ldr             x8, [PP, #0x6e90]  ; [pp+0x6e90] Type: double
    // 0xb1de38: r3 = Null
    //     0xb1de38: add             x3, PP, #0xad, lsl #12  ; [pp+0xad7b8] Null
    //     0xb1de3c: ldr             x3, [x3, #0x7b8]
    // 0xb1de40: r0 = double()
    //     0xb1de40: bl              #0x13ee3d0  ; IsType_double_Stub
    // 0xb1de44: ldr             x1, [fp, #0x18]
    // 0xb1de48: ldr             x2, [fp, #0x10]
    // 0xb1de4c: r0 = value=()
    //     0xb1de4c: bl              #0xb1de64  ; [package:flutter/src/material/slider.dart] _RenderSlider::value=
    // 0xb1de50: LeaveFrame
    //     0xb1de50: mov             SP, fp
    //     0xb1de54: ldp             fp, lr, [SP], #0x10
    // 0xb1de58: ret
    //     0xb1de58: ret             
    // 0xb1de5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1de5c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1de60: b               #0xb1de10
  }
  set void value=(_RenderSlider, double) {
    // ** addr: 0xb1de64, size: 0x24c
    // 0xb1de64: EnterFrame
    //     0xb1de64: stp             fp, lr, [SP, #-0x10]!
    //     0xb1de68: mov             fp, SP
    // 0xb1de6c: AllocStack(0x28)
    //     0xb1de6c: sub             SP, SP, #0x28
    // 0xb1de70: SetupParameters(_RenderSlider this /* r1 => r0, fp-0x8 */)
    //     0xb1de70: mov             x0, x1
    //     0xb1de74: stur            x1, [fp, #-8]
    // 0xb1de78: CheckStackOverflow
    //     0xb1de78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1de7c: cmp             SP, x16
    //     0xb1de80: b.ls            #0xb1e048
    // 0xb1de84: LoadField: r1 = r0->field_97
    //     0xb1de84: ldur            x1, [x0, #0x97]
    // 0xb1de88: cmp             x1, #0
    // 0xb1de8c: b.le            #0xb1dea0
    // 0xb1de90: LoadField: d0 = r2->field_7
    //     0xb1de90: ldur            d0, [x2, #7]
    // 0xb1de94: mov             x1, x0
    // 0xb1de98: r0 = _discretize()
    //     0xb1de98: bl              #0xb1e0b0  ; [package:flutter/src/material/slider.dart] _RenderSlider::_discretize
    // 0xb1de9c: b               #0xb1dea4
    // 0xb1dea0: LoadField: d0 = r2->field_7
    //     0xb1dea0: ldur            d0, [x2, #7]
    // 0xb1dea4: ldur            x0, [fp, #-8]
    // 0xb1dea8: stur            d0, [fp, #-0x20]
    // 0xb1deac: LoadField: d1 = r0->field_83
    //     0xb1deac: ldur            d1, [x0, #0x83]
    // 0xb1deb0: r2 = inline_Allocate_Double()
    //     0xb1deb0: ldp             x2, x1, [THR, #0x60]  ; THR::top
    //     0xb1deb4: add             x2, x2, #0x10
    //     0xb1deb8: cmp             x1, x2
    //     0xb1debc: b.ls            #0xb1e050
    //     0xb1dec0: str             x2, [THR, #0x60]  ; THR::top
    //     0xb1dec4: sub             x2, x2, #0xf
    //     0xb1dec8: mov             x1, #0xe19c
    //     0xb1decc: movk            x1, #3, lsl #16
    //     0xb1ded0: stur            x1, [x2, #-1]
    // 0xb1ded4: dmb             ishst
    // 0xb1ded8: StoreField: r2->field_7 = d0
    //     0xb1ded8: stur            d0, [x2, #7]
    // 0xb1dedc: fcmp            d0, d1
    // 0xb1dee0: b.ne            #0xb1def4
    // 0xb1dee4: r0 = Null
    //     0xb1dee4: mov             x0, NULL
    // 0xb1dee8: LeaveFrame
    //     0xb1dee8: mov             SP, fp
    //     0xb1deec: ldp             fp, lr, [SP], #0x10
    // 0xb1def0: ret
    //     0xb1def0: ret             
    // 0xb1def4: StoreField: r0->field_83 = d0
    //     0xb1def4: stur            d0, [x0, #0x83]
    // 0xb1def8: LoadField: r1 = r0->field_97
    //     0xb1def8: ldur            x1, [x0, #0x97]
    // 0xb1defc: cmp             x1, #0
    // 0xb1df00: b.le            #0xb1e00c
    // 0xb1df04: d1 = 0.000000
    //     0xb1df04: eor             v1.16b, v1.16b, v1.16b
    // 0xb1df08: LoadField: r3 = r0->field_53
    //     0xb1df08: ldur            w3, [x0, #0x53]
    // 0xb1df0c: DecompressPointer r3
    //     0xb1df0c: add             x3, x3, HEAP, lsl #32
    // 0xb1df10: stur            x3, [fp, #-0x18]
    // 0xb1df14: LoadField: r4 = r3->field_27
    //     0xb1df14: ldur            w4, [x3, #0x27]
    // 0xb1df18: DecompressPointer r4
    //     0xb1df18: add             x4, x4, HEAP, lsl #32
    // 0xb1df1c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb1df20: cmp             w4, w16
    // 0xb1df24: b.eq            #0xb1e06c
    // 0xb1df28: stur            x4, [fp, #-0x10]
    // 0xb1df2c: LoadField: r1 = r4->field_37
    //     0xb1df2c: ldur            w1, [x4, #0x37]
    // 0xb1df30: DecompressPointer r1
    //     0xb1df30: add             x1, x1, HEAP, lsl #32
    // 0xb1df34: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb1df38: cmp             w1, w16
    // 0xb1df3c: b.eq            #0xb1e078
    // 0xb1df40: LoadField: d2 = r1->field_7
    //     0xb1df40: ldur            d2, [x1, #7]
    // 0xb1df44: fsub            d3, d0, d2
    // 0xb1df48: fcmp            d3, d1
    // 0xb1df4c: b.ne            #0xb1df58
    // 0xb1df50: d2 = 0.000000
    //     0xb1df50: eor             v2.16b, v2.16b, v2.16b
    // 0xb1df54: b               #0xb1df6c
    // 0xb1df58: fcmp            d1, d3
    // 0xb1df5c: b.le            #0xb1df68
    // 0xb1df60: fneg            d2, d3
    // 0xb1df64: b               #0xb1df6c
    // 0xb1df68: mov             v2.16b, v3.16b
    // 0xb1df6c: fcmp            d2, d1
    // 0xb1df70: b.eq            #0xb1dfb8
    // 0xb1df74: d1 = 1.000000
    //     0xb1df74: fmov            d1, #1.00000000
    // 0xb1df78: fdiv            d3, d1, d2
    // 0xb1df7c: r2 = inline_Allocate_Double()
    //     0xb1df7c: ldp             x2, x1, [THR, #0x60]  ; THR::top
    //     0xb1df80: add             x2, x2, #0x10
    //     0xb1df84: cmp             x1, x2
    //     0xb1df88: b.ls            #0xb1e080
    //     0xb1df8c: str             x2, [THR, #0x60]  ; THR::top
    //     0xb1df90: sub             x2, x2, #0xf
    //     0xb1df94: mov             x1, #0xe19c
    //     0xb1df98: movk            x1, #3, lsl #16
    //     0xb1df9c: stur            x1, [x2, #-1]
    // 0xb1dfa0: dmb             ishst
    // 0xb1dfa4: StoreField: r2->field_7 = d3
    //     0xb1dfa4: stur            d3, [x2, #7]
    // 0xb1dfa8: r1 = Instance_Duration
    //     0xb1dfa8: add             x1, PP, #0x84, lsl #12  ; [pp+0x84f20] Obj!Duration@12c8a11
    //     0xb1dfac: ldr             x1, [x1, #0xf20]
    // 0xb1dfb0: r0 = *()
    //     0xb1dfb0: bl              #0x7dd190  ; [dart:core] Duration::*
    // 0xb1dfb4: b               #0xb1dfbc
    // 0xb1dfb8: r0 = Instance_Duration
    //     0xb1dfb8: ldr             x0, [PP, #0x1808]  ; [pp+0x1808] Obj!Duration@12c8901
    // 0xb1dfbc: ldur            x1, [fp, #-0x18]
    // 0xb1dfc0: ldur            x2, [fp, #-0x10]
    // 0xb1dfc4: StoreField: r2->field_27 = r0
    //     0xb1dfc4: stur            w0, [x2, #0x27]
    //     0xb1dfc8: ldurb           w16, [x2, #-1]
    //     0xb1dfcc: ldurb           w17, [x0, #-1]
    //     0xb1dfd0: and             x16, x17, x16, lsr #2
    //     0xb1dfd4: tst             x16, HEAP, lsr #32
    //     0xb1dfd8: b.eq            #0xb1dfe0
    //     0xb1dfdc: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xb1dfe0: LoadField: r0 = r1->field_27
    //     0xb1dfe0: ldur            w0, [x1, #0x27]
    // 0xb1dfe4: DecompressPointer r0
    //     0xb1dfe4: add             x0, x0, HEAP, lsl #32
    // 0xb1dfe8: r16 = Instance_Cubic
    //     0xb1dfe8: add             x16, PP, #0x19, lsl #12  ; [pp+0x19668] Obj!Cubic@129f511
    //     0xb1dfec: ldr             x16, [x16, #0x668]
    // 0xb1dff0: str             x16, [SP]
    // 0xb1dff4: mov             x1, x0
    // 0xb1dff8: ldur            d0, [fp, #-0x20]
    // 0xb1dffc: r4 = const [0, 0x3, 0x1, 0x2, curve, 0x2, null]
    //     0xb1dffc: add             x4, PP, #0xa3, lsl #12  ; [pp+0xa3758] List(7) [0, 0x3, 0x1, 0x2, "curve", 0x2, Null]
    //     0xb1e000: ldr             x4, [x4, #0x758]
    // 0xb1e004: r0 = animateTo()
    //     0xb1e004: bl              #0x866084  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::animateTo
    // 0xb1e008: b               #0xb1e030
    // 0xb1e00c: LoadField: r1 = r0->field_53
    //     0xb1e00c: ldur            w1, [x0, #0x53]
    // 0xb1e010: DecompressPointer r1
    //     0xb1e010: add             x1, x1, HEAP, lsl #32
    // 0xb1e014: LoadField: r3 = r1->field_27
    //     0xb1e014: ldur            w3, [x1, #0x27]
    // 0xb1e018: DecompressPointer r3
    //     0xb1e018: add             x3, x3, HEAP, lsl #32
    // 0xb1e01c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb1e020: cmp             w3, w16
    // 0xb1e024: b.eq            #0xb1e0a4
    // 0xb1e028: mov             x1, x3
    // 0xb1e02c: r0 = value=()
    //     0xb1e02c: bl              #0x829534  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0xb1e030: ldur            x1, [fp, #-8]
    // 0xb1e034: r0 = markNeedsSemanticsUpdate()
    //     0xb1e034: bl              #0x8373c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0xb1e038: r0 = Null
    //     0xb1e038: mov             x0, NULL
    // 0xb1e03c: LeaveFrame
    //     0xb1e03c: mov             SP, fp
    //     0xb1e040: ldp             fp, lr, [SP], #0x10
    // 0xb1e044: ret
    //     0xb1e044: ret             
    // 0xb1e048: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1e048: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1e04c: b               #0xb1de84
    // 0xb1e050: stp             q0, q1, [SP, #-0x20]!
    // 0xb1e054: SaveReg r0
    //     0xb1e054: str             x0, [SP, #-8]!
    // 0xb1e058: r0 = AllocateDouble()
    //     0xb1e058: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb1e05c: mov             x2, x0
    // 0xb1e060: RestoreReg r0
    //     0xb1e060: ldr             x0, [SP], #8
    // 0xb1e064: ldp             q0, q1, [SP], #0x20
    // 0xb1e068: b               #0xb1ded8
    // 0xb1e06c: r9 = positionController
    //     0xb1e06c: add             x9, PP, #0x99, lsl #12  ; [pp+0x99018] Field <_SliderState@125231897.positionController>: late (offset: 0x28)
    //     0xb1e070: ldr             x9, [x9, #0x18]
    // 0xb1e074: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xb1e074: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xb1e078: r9 = _value
    //     0xb1e078: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0xb1e07c: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xb1e07c: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xb1e080: stp             q0, q3, [SP, #-0x20]!
    // 0xb1e084: stp             x3, x4, [SP, #-0x10]!
    // 0xb1e088: SaveReg r0
    //     0xb1e088: str             x0, [SP, #-8]!
    // 0xb1e08c: r0 = AllocateDouble()
    //     0xb1e08c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb1e090: mov             x2, x0
    // 0xb1e094: RestoreReg r0
    //     0xb1e094: ldr             x0, [SP], #8
    // 0xb1e098: ldp             x3, x4, [SP], #0x10
    // 0xb1e09c: ldp             q0, q3, [SP], #0x20
    // 0xb1e0a0: b               #0xb1dfa4
    // 0xb1e0a4: r9 = positionController
    //     0xb1e0a4: add             x9, PP, #0x99, lsl #12  ; [pp+0x99018] Field <_SliderState@125231897.positionController>: late (offset: 0x28)
    //     0xb1e0a8: ldr             x9, [x9, #0x18]
    // 0xb1e0ac: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xb1e0ac: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _discretize(/* No info */) {
    // ** addr: 0xb1e0b0, size: 0xf0
    // 0xb1e0b0: EnterFrame
    //     0xb1e0b0: stp             fp, lr, [SP, #-0x10]!
    //     0xb1e0b4: mov             fp, SP
    // 0xb1e0b8: AllocStack(0x8)
    //     0xb1e0b8: sub             SP, SP, #8
    // 0xb1e0bc: d1 = 0.000000
    //     0xb1e0bc: eor             v1.16b, v1.16b, v1.16b
    // 0xb1e0c0: fcmp            d1, d0
    // 0xb1e0c4: b.le            #0xb1e0d0
    // 0xb1e0c8: d0 = 0.000000
    //     0xb1e0c8: eor             v0.16b, v0.16b, v0.16b
    // 0xb1e0cc: b               #0xb1e0f0
    // 0xb1e0d0: d1 = 1.000000
    //     0xb1e0d0: fmov            d1, #1.00000000
    // 0xb1e0d4: fcmp            d0, d1
    // 0xb1e0d8: b.le            #0xb1e0e4
    // 0xb1e0dc: d0 = 1.000000
    //     0xb1e0dc: fmov            d0, #1.00000000
    // 0xb1e0e0: b               #0xb1e0f0
    // 0xb1e0e4: fcmp            d0, d0
    // 0xb1e0e8: b.vc            #0xb1e0f0
    // 0xb1e0ec: d0 = 1.000000
    //     0xb1e0ec: fmov            d0, #1.00000000
    // 0xb1e0f0: LoadField: r19 = r1->field_97
    //     0xb1e0f0: ldur            x19, [x1, #0x97]
    // 0xb1e0f4: cmp             x19, #0
    // 0xb1e0f8: b.le            #0xb1e178
    // 0xb1e0fc: scvtf           d1, x19
    // 0xb1e100: stur            d1, [fp, #-8]
    // 0xb1e104: fmul            d2, d0, d1
    // 0xb1e108: mov             v0.16b, v2.16b
    // 0xb1e10c: stp             fp, lr, [SP, #-0x10]!
    // 0xb1e110: mov             fp, SP
    // 0xb1e114: CallRuntime_LibcRound(double) -> double
    //     0xb1e114: and             SP, SP, #0xfffffffffffffff0
    //     0xb1e118: mov             sp, SP
    //     0xb1e11c: ldr             x16, [THR, #0x770]  ; THR::LibcRound
    //     0xb1e120: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xb1e124: blr             x16
    //     0xb1e128: mov             x16, #8
    //     0xb1e12c: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xb1e130: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xb1e134: sub             sp, x16, #1, lsl #12
    //     0xb1e138: mov             SP, fp
    //     0xb1e13c: ldp             fp, lr, [SP], #0x10
    // 0xb1e140: fcmp            d0, d0
    // 0xb1e144: b.vs            #0xb1e184
    // 0xb1e148: fcvtzs          x0, d0
    // 0xb1e14c: asr             x16, x0, #0x1e
    // 0xb1e150: cmp             x16, x0, asr #63
    // 0xb1e154: b.ne            #0xb1e184
    // 0xb1e158: lsl             x0, x0, #1
    // 0xb1e15c: r1 = LoadInt32Instr(r0)
    //     0xb1e15c: sbfx            x1, x0, #1, #0x1f
    //     0xb1e160: tbz             w0, #0, #0xb1e168
    //     0xb1e164: ldur            x1, [x0, #7]
    // 0xb1e168: scvtf           d1, x1
    // 0xb1e16c: ldur            d2, [fp, #-8]
    // 0xb1e170: fdiv            d3, d1, d2
    // 0xb1e174: mov             v0.16b, v3.16b
    // 0xb1e178: LeaveFrame
    //     0xb1e178: mov             SP, fp
    //     0xb1e17c: ldp             fp, lr, [SP], #0x10
    // 0xb1e180: ret
    //     0xb1e180: ret             
    // 0xb1e184: SaveReg d0
    //     0xb1e184: str             q0, [SP, #-0x10]!
    // 0xb1e188: r0 = 76
    //     0xb1e188: mov             x0, #0x4c
    // 0xb1e18c: r30 = DoubleToIntegerStub
    //     0xb1e18c: ldr             lr, [PP, #0x1b70]  ; [pp+0x1b70] Stub: DoubleToInteger (0x7d18e4)
    // 0xb1e190: LoadField: r30 = r30->field_7
    //     0xb1e190: ldur            lr, [lr, #7]
    // 0xb1e194: blr             lr
    // 0xb1e198: RestoreReg d0
    //     0xb1e198: ldr             q0, [SP], #0x10
    // 0xb1e19c: b               #0xb1e15c
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb1e1a0, size: 0x84
    // 0xb1e1a0: EnterFrame
    //     0xb1e1a0: stp             fp, lr, [SP, #-0x10]!
    //     0xb1e1a4: mov             fp, SP
    // 0xb1e1a8: ldr             x0, [fp, #0x18]
    // 0xb1e1ac: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb1e1ac: ldur            w1, [x0, #0x17]
    // 0xb1e1b0: DecompressPointer r1
    //     0xb1e1b0: add             x1, x1, HEAP, lsl #32
    // 0xb1e1b4: CheckStackOverflow
    //     0xb1e1b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1e1b8: cmp             SP, x16
    //     0xb1e1bc: b.ls            #0xb1e20c
    // 0xb1e1c0: r0 = _maxSliderPartWidth()
    //     0xb1e1c0: bl              #0xb1e224  ; [package:flutter/src/material/slider.dart] _RenderSlider::_maxSliderPartWidth
    // 0xb1e1c4: mov             v1.16b, v0.16b
    // 0xb1e1c8: d0 = 144.000000
    //     0xb1e1c8: add             x17, PP, #0xad, lsl #12  ; [pp+0xad708] IMM: double(144) from 0x4062000000000000
    //     0xb1e1cc: ldr             d0, [x17, #0x708]
    // 0xb1e1d0: fadd            d2, d1, d0
    // 0xb1e1d4: r0 = inline_Allocate_Double()
    //     0xb1e1d4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb1e1d8: add             x0, x0, #0x10
    //     0xb1e1dc: cmp             x1, x0
    //     0xb1e1e0: b.ls            #0xb1e214
    //     0xb1e1e4: str             x0, [THR, #0x60]  ; THR::top
    //     0xb1e1e8: sub             x0, x0, #0xf
    //     0xb1e1ec: mov             x1, #0xe19c
    //     0xb1e1f0: movk            x1, #3, lsl #16
    //     0xb1e1f4: stur            x1, [x0, #-1]
    // 0xb1e1f8: dmb             ishst
    // 0xb1e1fc: StoreField: r0->field_7 = d2
    //     0xb1e1fc: stur            d2, [x0, #7]
    // 0xb1e200: LeaveFrame
    //     0xb1e200: mov             SP, fp
    //     0xb1e204: ldp             fp, lr, [SP], #0x10
    // 0xb1e208: ret
    //     0xb1e208: ret             
    // 0xb1e20c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1e20c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1e210: b               #0xb1e1c0
    // 0xb1e214: SaveReg d2
    //     0xb1e214: str             q2, [SP, #-0x10]!
    // 0xb1e218: r0 = AllocateDouble()
    //     0xb1e218: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb1e21c: RestoreReg d2
    //     0xb1e21c: ldr             q2, [SP], #0x10
    // 0xb1e220: b               #0xb1e1fc
  }
  double _maxSliderPartWidth(_RenderSlider) {
    // ** addr: 0xb1e224, size: 0x70
    // 0xb1e224: EnterFrame
    //     0xb1e224: stp             fp, lr, [SP, #-0x10]!
    //     0xb1e228: mov             fp, SP
    // 0xb1e22c: AllocStack(0x20)
    //     0xb1e22c: sub             SP, SP, #0x20
    // 0xb1e230: CheckStackOverflow
    //     0xb1e230: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1e234: cmp             SP, x16
    //     0xb1e238: b.ls            #0xb1e28c
    // 0xb1e23c: r0 = _sliderPartSizes()
    //     0xb1e23c: bl              #0xb1e294  ; [package:flutter/src/material/slider.dart] _RenderSlider::_sliderPartSizes
    // 0xb1e240: r1 = Function '<anonymous closure>':.
    //     0xb1e240: add             x1, PP, #0xad, lsl #12  ; [pp+0xad710] AnonymousClosure: static (0xb1e51c), in [package:syncfusion_flutter_core/core.dart] ::rotatedTextSize (0xb1e574)
    //     0xb1e244: ldr             x1, [x1, #0x710]
    // 0xb1e248: r2 = Null
    //     0xb1e248: mov             x2, NULL
    // 0xb1e24c: stur            x0, [fp, #-8]
    // 0xb1e250: r0 = AllocateClosure()
    //     0xb1e250: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb1e254: r16 = <double>
    //     0xb1e254: ldr             x16, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xb1e258: ldur            lr, [fp, #-8]
    // 0xb1e25c: stp             lr, x16, [SP, #8]
    // 0xb1e260: str             x0, [SP]
    // 0xb1e264: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xb1e264: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xb1e268: r0 = map()
    //     0xb1e268: bl              #0xba574c  ; [dart:collection] ListBase::map
    // 0xb1e26c: mov             x1, x0
    // 0xb1e270: r2 = Closure: (double, double) => double from Function 'max': static.
    //     0xb1e270: add             x2, PP, #0x7f, lsl #12  ; [pp+0x7fee8] Closure: (double, double) => double from Function 'max': static. (0x7f2ada95ae8c)
    //     0xb1e274: ldr             x2, [x2, #0xee8]
    // 0xb1e278: r0 = reduce()
    //     0xb1e278: bl              #0xade490  ; [dart:_internal] ListIterable::reduce
    // 0xb1e27c: LoadField: d0 = r0->field_7
    //     0xb1e27c: ldur            d0, [x0, #7]
    // 0xb1e280: LeaveFrame
    //     0xb1e280: mov             SP, fp
    //     0xb1e284: ldp             fp, lr, [SP], #0x10
    // 0xb1e288: ret
    //     0xb1e288: ret             
    // 0xb1e28c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1e28c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1e290: b               #0xb1e23c
  }
  get _ _sliderPartSizes(/* No info */) {
    // ** addr: 0xb1e294, size: 0x15c
    // 0xb1e294: EnterFrame
    //     0xb1e294: stp             fp, lr, [SP, #-0x10]!
    //     0xb1e298: mov             fp, SP
    // 0xb1e29c: AllocStack(0x30)
    //     0xb1e29c: sub             SP, SP, #0x30
    // 0xb1e2a0: SetupParameters(_RenderSlider this /* r1 => r0, fp-0x8 */)
    //     0xb1e2a0: mov             x0, x1
    //     0xb1e2a4: stur            x1, [fp, #-8]
    // 0xb1e2a8: CheckStackOverflow
    //     0xb1e2a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1e2ac: cmp             SP, x16
    //     0xb1e2b0: b.ls            #0xb1e3dc
    // 0xb1e2b4: LoadField: r1 = r0->field_a3
    //     0xb1e2b4: ldur            w1, [x0, #0xa3]
    // 0xb1e2b8: DecompressPointer r1
    //     0xb1e2b8: add             x1, x1, HEAP, lsl #32
    // 0xb1e2bc: LoadField: r2 = r1->field_4b
    //     0xb1e2bc: ldur            w2, [x1, #0x4b]
    // 0xb1e2c0: DecompressPointer r2
    //     0xb1e2c0: add             x2, x2, HEAP, lsl #32
    // 0xb1e2c4: cmp             w2, NULL
    // 0xb1e2c8: b.eq            #0xb1e3e4
    // 0xb1e2cc: LoadField: r1 = r0->field_b3
    //     0xb1e2cc: ldur            w1, [x0, #0xb3]
    // 0xb1e2d0: DecompressPointer r1
    //     0xb1e2d0: add             x1, x1, HEAP, lsl #32
    // 0xb1e2d4: cmp             w1, NULL
    // 0xb1e2d8: r16 = true
    //     0xb1e2d8: add             x16, NULL, #0x20  ; true
    // 0xb1e2dc: r17 = false
    //     0xb1e2dc: add             x17, NULL, #0x30  ; false
    // 0xb1e2e0: csel            x3, x16, x17, ne
    // 0xb1e2e4: mov             x1, x2
    // 0xb1e2e8: mov             x2, x3
    // 0xb1e2ec: r0 = getPreferredSize()
    //     0xb1e2ec: bl              #0xb1e4f8  ; [package:flutter/src/material/slider_value_indicator_shape.dart] RoundSliderOverlayShape::getPreferredSize
    // 0xb1e2f0: LoadField: d0 = r0->field_7
    //     0xb1e2f0: ldur            d0, [x0, #7]
    // 0xb1e2f4: ldur            x1, [fp, #-8]
    // 0xb1e2f8: stur            d0, [fp, #-0x28]
    // 0xb1e2fc: r0 = _overlayHeight()
    //     0xb1e2fc: bl              #0xb1e488  ; [package:flutter/src/material/slider.dart] _RenderSlider::_overlayHeight
    // 0xb1e300: stur            d0, [fp, #-0x30]
    // 0xb1e304: r0 = Size()
    //     0xb1e304: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb1e308: ldur            d0, [fp, #-0x28]
    // 0xb1e30c: stur            x0, [fp, #-0x10]
    // 0xb1e310: StoreField: r0->field_7 = d0
    //     0xb1e310: stur            d0, [x0, #7]
    // 0xb1e314: ldur            d0, [fp, #-0x30]
    // 0xb1e318: StoreField: r0->field_f = d0
    //     0xb1e318: stur            d0, [x0, #0xf]
    // 0xb1e31c: ldur            x3, [fp, #-8]
    // 0xb1e320: LoadField: r1 = r3->field_a3
    //     0xb1e320: ldur            w1, [x3, #0xa3]
    // 0xb1e324: DecompressPointer r1
    //     0xb1e324: add             x1, x1, HEAP, lsl #32
    // 0xb1e328: LoadField: r2 = r1->field_53
    //     0xb1e328: ldur            w2, [x1, #0x53]
    // 0xb1e32c: DecompressPointer r2
    //     0xb1e32c: add             x2, x2, HEAP, lsl #32
    // 0xb1e330: cmp             w2, NULL
    // 0xb1e334: b.eq            #0xb1e3e8
    // 0xb1e338: LoadField: r1 = r3->field_b3
    //     0xb1e338: ldur            w1, [x3, #0xb3]
    // 0xb1e33c: DecompressPointer r1
    //     0xb1e33c: add             x1, x1, HEAP, lsl #32
    // 0xb1e340: cmp             w1, NULL
    // 0xb1e344: r16 = true
    //     0xb1e344: add             x16, NULL, #0x20  ; true
    // 0xb1e348: r17 = false
    //     0xb1e348: add             x17, NULL, #0x30  ; false
    // 0xb1e34c: csel            x4, x16, x17, ne
    // 0xb1e350: mov             x1, x2
    // 0xb1e354: mov             x2, x4
    // 0xb1e358: r0 = getPreferredSize()
    //     0xb1e358: bl              #0xb1e464  ; [package:flutter/src/material/slider_parts.dart] RoundSliderThumbShape::getPreferredSize
    // 0xb1e35c: mov             x3, x0
    // 0xb1e360: ldur            x0, [fp, #-8]
    // 0xb1e364: stur            x3, [fp, #-0x18]
    // 0xb1e368: LoadField: r2 = r0->field_a3
    //     0xb1e368: ldur            w2, [x0, #0xa3]
    // 0xb1e36c: DecompressPointer r2
    //     0xb1e36c: add             x2, x2, HEAP, lsl #32
    // 0xb1e370: LoadField: r1 = r2->field_4f
    //     0xb1e370: ldur            w1, [x2, #0x4f]
    // 0xb1e374: DecompressPointer r1
    //     0xb1e374: add             x1, x1, HEAP, lsl #32
    // 0xb1e378: cmp             w1, NULL
    // 0xb1e37c: b.eq            #0xb1e3ec
    // 0xb1e380: r0 = getPreferredSize()
    //     0xb1e380: bl              #0xb1e3f0  ; [package:flutter/src/material/slider_parts.dart] RoundSliderTickMarkShape::getPreferredSize
    // 0xb1e384: r1 = Null
    //     0xb1e384: mov             x1, NULL
    // 0xb1e388: r2 = 6
    //     0xb1e388: mov             x2, #6
    // 0xb1e38c: stur            x0, [fp, #-8]
    // 0xb1e390: r0 = AllocateArray()
    //     0xb1e390: bl              #0x13df928  ; AllocateArrayStub
    // 0xb1e394: mov             x2, x0
    // 0xb1e398: ldur            x0, [fp, #-0x10]
    // 0xb1e39c: stur            x2, [fp, #-0x20]
    // 0xb1e3a0: StoreField: r2->field_f = r0
    //     0xb1e3a0: stur            w0, [x2, #0xf]
    // 0xb1e3a4: ldur            x0, [fp, #-0x18]
    // 0xb1e3a8: StoreField: r2->field_13 = r0
    //     0xb1e3a8: stur            w0, [x2, #0x13]
    // 0xb1e3ac: ldur            x0, [fp, #-8]
    // 0xb1e3b0: ArrayStore: r2[0] = r0  ; List_4
    //     0xb1e3b0: stur            w0, [x2, #0x17]
    // 0xb1e3b4: r1 = <Size>
    //     0xb1e3b4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15aa0] TypeArguments: <Size>
    //     0xb1e3b8: ldr             x1, [x1, #0xaa0]
    // 0xb1e3bc: r0 = AllocateGrowableArray()
    //     0xb1e3bc: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xb1e3c0: ldur            x1, [fp, #-0x20]
    // 0xb1e3c4: StoreField: r0->field_f = r1
    //     0xb1e3c4: stur            w1, [x0, #0xf]
    // 0xb1e3c8: r1 = 6
    //     0xb1e3c8: mov             x1, #6
    // 0xb1e3cc: StoreField: r0->field_b = r1
    //     0xb1e3cc: stur            w1, [x0, #0xb]
    // 0xb1e3d0: LeaveFrame
    //     0xb1e3d0: mov             SP, fp
    //     0xb1e3d4: ldp             fp, lr, [SP], #0x10
    // 0xb1e3d8: ret
    //     0xb1e3d8: ret             
    // 0xb1e3dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1e3dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1e3e0: b               #0xb1e2b4
    // 0xb1e3e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb1e3e4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb1e3e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb1e3e8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb1e3ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb1e3ec: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  double _overlayHeight(_RenderSlider) {
    // ** addr: 0xb1e488, size: 0x70
    // 0xb1e488: EnterFrame
    //     0xb1e488: stp             fp, lr, [SP, #-0x10]!
    //     0xb1e48c: mov             fp, SP
    // 0xb1e490: CheckStackOverflow
    //     0xb1e490: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1e494: cmp             SP, x16
    //     0xb1e498: b.ls            #0xb1e4ec
    // 0xb1e49c: LoadField: r0 = r1->field_a3
    //     0xb1e49c: ldur            w0, [x1, #0xa3]
    // 0xb1e4a0: DecompressPointer r0
    //     0xb1e4a0: add             x0, x0, HEAP, lsl #32
    // 0xb1e4a4: LoadField: r2 = r0->field_4b
    //     0xb1e4a4: ldur            w2, [x0, #0x4b]
    // 0xb1e4a8: DecompressPointer r2
    //     0xb1e4a8: add             x2, x2, HEAP, lsl #32
    // 0xb1e4ac: cmp             w2, NULL
    // 0xb1e4b0: b.eq            #0xb1e4f4
    // 0xb1e4b4: LoadField: r0 = r1->field_b3
    //     0xb1e4b4: ldur            w0, [x1, #0xb3]
    // 0xb1e4b8: DecompressPointer r0
    //     0xb1e4b8: add             x0, x0, HEAP, lsl #32
    // 0xb1e4bc: cmp             w0, NULL
    // 0xb1e4c0: r16 = true
    //     0xb1e4c0: add             x16, NULL, #0x20  ; true
    // 0xb1e4c4: r17 = false
    //     0xb1e4c4: add             x17, NULL, #0x30  ; false
    // 0xb1e4c8: csel            x1, x16, x17, ne
    // 0xb1e4cc: mov             x16, x1
    // 0xb1e4d0: mov             x1, x2
    // 0xb1e4d4: mov             x2, x16
    // 0xb1e4d8: r0 = getPreferredSize()
    //     0xb1e4d8: bl              #0xb1e4f8  ; [package:flutter/src/material/slider_value_indicator_shape.dart] RoundSliderOverlayShape::getPreferredSize
    // 0xb1e4dc: LoadField: d0 = r0->field_f
    //     0xb1e4dc: ldur            d0, [x0, #0xf]
    // 0xb1e4e0: LeaveFrame
    //     0xb1e4e0: mov             SP, fp
    //     0xb1e4e4: ldp             fp, lr, [SP], #0x10
    // 0xb1e4e8: ret
    //     0xb1e4e8: ret             
    // 0xb1e4ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1e4ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1e4f0: b               #0xb1e49c
    // 0xb1e4f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb1e4f4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ computeMaxIntrinsicHeight(/* No info */) {
    // ** addr: 0xb2b248, size: 0x60
    // 0xb2b248: EnterFrame
    //     0xb2b248: stp             fp, lr, [SP, #-0x10]!
    //     0xb2b24c: mov             fp, SP
    // 0xb2b250: AllocStack(0x8)
    //     0xb2b250: sub             SP, SP, #8
    // 0xb2b254: CheckStackOverflow
    //     0xb2b254: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2b258: cmp             SP, x16
    //     0xb2b25c: b.ls            #0xb2b29c
    // 0xb2b260: LoadField: r0 = r1->field_a3
    //     0xb2b260: ldur            w0, [x1, #0xa3]
    // 0xb2b264: DecompressPointer r0
    //     0xb2b264: add             x0, x0, HEAP, lsl #32
    // 0xb2b268: LoadField: r2 = r0->field_7
    //     0xb2b268: ldur            w2, [x0, #7]
    // 0xb2b26c: DecompressPointer r2
    //     0xb2b26c: add             x2, x2, HEAP, lsl #32
    // 0xb2b270: stur            x2, [fp, #-8]
    // 0xb2b274: cmp             w2, NULL
    // 0xb2b278: b.eq            #0xb2b2a4
    // 0xb2b27c: r0 = _maxSliderPartHeight()
    //     0xb2b27c: bl              #0xb2b320  ; [package:flutter/src/material/slider.dart] _RenderSlider::_maxSliderPartHeight
    // 0xb2b280: ldur            x0, [fp, #-8]
    // 0xb2b284: LoadField: d1 = r0->field_7
    //     0xb2b284: ldur            d1, [x0, #7]
    // 0xb2b288: fmax            v2.2d, v1.2d, v0.2d
    // 0xb2b28c: mov             v0.16b, v2.16b
    // 0xb2b290: LeaveFrame
    //     0xb2b290: mov             SP, fp
    //     0xb2b294: ldp             fp, lr, [SP], #0x10
    // 0xb2b298: ret
    //     0xb2b298: ret             
    // 0xb2b29c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2b29c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2b2a0: b               #0xb2b260
    // 0xb2b2a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb2b2a4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0xb2b2a8, size: 0x78
    // 0xb2b2a8: EnterFrame
    //     0xb2b2a8: stp             fp, lr, [SP, #-0x10]!
    //     0xb2b2ac: mov             fp, SP
    // 0xb2b2b0: ldr             x0, [fp, #0x18]
    // 0xb2b2b4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb2b2b4: ldur            w1, [x0, #0x17]
    // 0xb2b2b8: DecompressPointer r1
    //     0xb2b2b8: add             x1, x1, HEAP, lsl #32
    // 0xb2b2bc: CheckStackOverflow
    //     0xb2b2bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2b2c0: cmp             SP, x16
    //     0xb2b2c4: b.ls            #0xb2b308
    // 0xb2b2c8: ldr             x2, [fp, #0x10]
    // 0xb2b2cc: r0 = computeMaxIntrinsicHeight()
    //     0xb2b2cc: bl              #0xb2b248  ; [package:flutter/src/material/slider.dart] _RenderSlider::computeMaxIntrinsicHeight
    // 0xb2b2d0: r0 = inline_Allocate_Double()
    //     0xb2b2d0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2b2d4: add             x0, x0, #0x10
    //     0xb2b2d8: cmp             x1, x0
    //     0xb2b2dc: b.ls            #0xb2b310
    //     0xb2b2e0: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2b2e4: sub             x0, x0, #0xf
    //     0xb2b2e8: mov             x1, #0xe19c
    //     0xb2b2ec: movk            x1, #3, lsl #16
    //     0xb2b2f0: stur            x1, [x0, #-1]
    // 0xb2b2f4: dmb             ishst
    // 0xb2b2f8: StoreField: r0->field_7 = d0
    //     0xb2b2f8: stur            d0, [x0, #7]
    // 0xb2b2fc: LeaveFrame
    //     0xb2b2fc: mov             SP, fp
    //     0xb2b300: ldp             fp, lr, [SP], #0x10
    // 0xb2b304: ret
    //     0xb2b304: ret             
    // 0xb2b308: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2b308: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2b30c: b               #0xb2b2c8
    // 0xb2b310: SaveReg d0
    //     0xb2b310: str             q0, [SP, #-0x10]!
    // 0xb2b314: r0 = AllocateDouble()
    //     0xb2b314: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2b318: RestoreReg d0
    //     0xb2b318: ldr             q0, [SP], #0x10
    // 0xb2b31c: b               #0xb2b2f8
  }
  double _maxSliderPartHeight(_RenderSlider) {
    // ** addr: 0xb2b320, size: 0x70
    // 0xb2b320: EnterFrame
    //     0xb2b320: stp             fp, lr, [SP, #-0x10]!
    //     0xb2b324: mov             fp, SP
    // 0xb2b328: AllocStack(0x20)
    //     0xb2b328: sub             SP, SP, #0x20
    // 0xb2b32c: CheckStackOverflow
    //     0xb2b32c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2b330: cmp             SP, x16
    //     0xb2b334: b.ls            #0xb2b388
    // 0xb2b338: r0 = _sliderPartSizes()
    //     0xb2b338: bl              #0xb1e294  ; [package:flutter/src/material/slider.dart] _RenderSlider::_sliderPartSizes
    // 0xb2b33c: r1 = Function '<anonymous closure>':.
    //     0xb2b33c: add             x1, PP, #0xad, lsl #12  ; [pp+0xad7a0] AnonymousClosure: static (0xb1fb44), in [package:syncfusion_flutter_core/core.dart] ::rotatedTextSize (0xb1e574)
    //     0xb2b340: ldr             x1, [x1, #0x7a0]
    // 0xb2b344: r2 = Null
    //     0xb2b344: mov             x2, NULL
    // 0xb2b348: stur            x0, [fp, #-8]
    // 0xb2b34c: r0 = AllocateClosure()
    //     0xb2b34c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb2b350: r16 = <double>
    //     0xb2b350: ldr             x16, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xb2b354: ldur            lr, [fp, #-8]
    // 0xb2b358: stp             lr, x16, [SP, #8]
    // 0xb2b35c: str             x0, [SP]
    // 0xb2b360: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xb2b360: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xb2b364: r0 = map()
    //     0xb2b364: bl              #0xba574c  ; [dart:collection] ListBase::map
    // 0xb2b368: mov             x1, x0
    // 0xb2b36c: r2 = Closure: (double, double) => double from Function 'max': static.
    //     0xb2b36c: add             x2, PP, #0x7f, lsl #12  ; [pp+0x7fee8] Closure: (double, double) => double from Function 'max': static. (0x7f2ada95ae8c)
    //     0xb2b370: ldr             x2, [x2, #0xee8]
    // 0xb2b374: r0 = reduce()
    //     0xb2b374: bl              #0xade490  ; [dart:_internal] ListIterable::reduce
    // 0xb2b378: LoadField: d0 = r0->field_7
    //     0xb2b378: ldur            d0, [x0, #7]
    // 0xb2b37c: LeaveFrame
    //     0xb2b37c: mov             SP, fp
    //     0xb2b380: ldp             fp, lr, [SP], #0x10
    // 0xb2b384: ret
    //     0xb2b384: ret             
    // 0xb2b388: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2b388: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2b38c: b               #0xb2b338
  }
  _ computeMaxIntrinsicWidth(/* No info */) {
    // ** addr: 0xb2e718, size: 0x3c
    // 0xb2e718: EnterFrame
    //     0xb2e718: stp             fp, lr, [SP, #-0x10]!
    //     0xb2e71c: mov             fp, SP
    // 0xb2e720: CheckStackOverflow
    //     0xb2e720: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2e724: cmp             SP, x16
    //     0xb2e728: b.ls            #0xb2e74c
    // 0xb2e72c: r0 = _maxSliderPartWidth()
    //     0xb2e72c: bl              #0xb1e224  ; [package:flutter/src/material/slider.dart] _RenderSlider::_maxSliderPartWidth
    // 0xb2e730: d1 = 144.000000
    //     0xb2e730: add             x17, PP, #0xad, lsl #12  ; [pp+0xad708] IMM: double(144) from 0x4062000000000000
    //     0xb2e734: ldr             d1, [x17, #0x708]
    // 0xb2e738: fadd            d2, d0, d1
    // 0xb2e73c: mov             v0.16b, v2.16b
    // 0xb2e740: LeaveFrame
    //     0xb2e740: mov             SP, fp
    //     0xb2e744: ldp             fp, lr, [SP], #0x10
    // 0xb2e748: ret
    //     0xb2e748: ret             
    // 0xb2e74c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2e74c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2e750: b               #0xb2e72c
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xb51860, size: 0xe4
    // 0xb51860: EnterFrame
    //     0xb51860: stp             fp, lr, [SP, #-0x10]!
    //     0xb51864: mov             fp, SP
    // 0xb51868: AllocStack(0x20)
    //     0xb51868: sub             SP, SP, #0x20
    // 0xb5186c: d0 = inf
    //     0xb5186c: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb51870: mov             x0, x1
    // 0xb51874: stur            x1, [fp, #-8]
    // 0xb51878: stur            x2, [fp, #-0x10]
    // 0xb5187c: CheckStackOverflow
    //     0xb5187c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb51880: cmp             SP, x16
    //     0xb51884: b.ls            #0xb51938
    // 0xb51888: LoadField: d1 = r2->field_f
    //     0xb51888: ldur            d1, [x2, #0xf]
    // 0xb5188c: fcmp            d0, d1
    // 0xb51890: b.le            #0xb5189c
    // 0xb51894: mov             x0, x2
    // 0xb51898: b               #0xb518c0
    // 0xb5189c: mov             x1, x0
    // 0xb518a0: r0 = _maxSliderPartWidth()
    //     0xb518a0: bl              #0xb1e224  ; [package:flutter/src/material/slider.dart] _RenderSlider::_maxSliderPartWidth
    // 0xb518a4: mov             v1.16b, v0.16b
    // 0xb518a8: d0 = 144.000000
    //     0xb518a8: add             x17, PP, #0xad, lsl #12  ; [pp+0xad708] IMM: double(144) from 0x4062000000000000
    //     0xb518ac: ldr             d0, [x17, #0x708]
    // 0xb518b0: fadd            d2, d1, d0
    // 0xb518b4: mov             v1.16b, v2.16b
    // 0xb518b8: ldur            x0, [fp, #-0x10]
    // 0xb518bc: d0 = inf
    //     0xb518bc: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb518c0: stur            d1, [fp, #-0x18]
    // 0xb518c4: LoadField: d2 = r0->field_1f
    //     0xb518c4: ldur            d2, [x0, #0x1f]
    // 0xb518c8: fcmp            d0, d2
    // 0xb518cc: b.le            #0xb518dc
    // 0xb518d0: mov             v0.16b, v1.16b
    // 0xb518d4: mov             v1.16b, v2.16b
    // 0xb518d8: b               #0xb51914
    // 0xb518dc: ldur            x1, [fp, #-8]
    // 0xb518e0: LoadField: r0 = r1->field_a3
    //     0xb518e0: ldur            w0, [x1, #0xa3]
    // 0xb518e4: DecompressPointer r0
    //     0xb518e4: add             x0, x0, HEAP, lsl #32
    // 0xb518e8: LoadField: r2 = r0->field_7
    //     0xb518e8: ldur            w2, [x0, #7]
    // 0xb518ec: DecompressPointer r2
    //     0xb518ec: add             x2, x2, HEAP, lsl #32
    // 0xb518f0: stur            x2, [fp, #-0x10]
    // 0xb518f4: cmp             w2, NULL
    // 0xb518f8: b.eq            #0xb51940
    // 0xb518fc: r0 = _maxSliderPartHeight()
    //     0xb518fc: bl              #0xb2b320  ; [package:flutter/src/material/slider.dart] _RenderSlider::_maxSliderPartHeight
    // 0xb51900: ldur            x0, [fp, #-0x10]
    // 0xb51904: LoadField: d1 = r0->field_7
    //     0xb51904: ldur            d1, [x0, #7]
    // 0xb51908: fmax            v2.2d, v1.2d, v0.2d
    // 0xb5190c: mov             v1.16b, v2.16b
    // 0xb51910: ldur            d0, [fp, #-0x18]
    // 0xb51914: stur            d1, [fp, #-0x20]
    // 0xb51918: r0 = Size()
    //     0xb51918: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb5191c: ldur            d0, [fp, #-0x18]
    // 0xb51920: StoreField: r0->field_7 = d0
    //     0xb51920: stur            d0, [x0, #7]
    // 0xb51924: ldur            d0, [fp, #-0x20]
    // 0xb51928: StoreField: r0->field_f = d0
    //     0xb51928: stur            d0, [x0, #0xf]
    // 0xb5192c: LeaveFrame
    //     0xb5192c: mov             SP, fp
    //     0xb51930: ldp             fp, lr, [SP], #0x10
    // 0xb51934: ret
    //     0xb51934: ret             
    // 0xb51938: r0 = StackOverflowSharedWithFPURegs()
    //     0xb51938: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb5193c: b               #0xb51888
    // 0xb51940: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb51940: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0xb58630, size: 0x24
    // 0xb58630: EnterFrame
    //     0xb58630: stp             fp, lr, [SP, #-0x10]!
    //     0xb58634: mov             fp, SP
    // 0xb58638: ldr             x2, [fp, #0x10]
    // 0xb5863c: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0xb5863c: add             x1, PP, #0xad, lsl #12  ; [pp+0xad700] AnonymousClosure: (0xb1e1a0), in [package:flutter/src/material/slider.dart] _RenderSlider::computeMaxIntrinsicWidth (0xb2e718)
    //     0xb58640: ldr             x1, [x1, #0x700]
    // 0xb58644: r0 = AllocateClosure()
    //     0xb58644: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb58648: LeaveFrame
    //     0xb58648: mov             SP, fp
    //     0xb5864c: ldp             fp, lr, [SP], #0x10
    // 0xb58650: ret
    //     0xb58650: ret             
  }
  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0xb5e7dc, size: 0x24
    // 0xb5e7dc: EnterFrame
    //     0xb5e7dc: stp             fp, lr, [SP, #-0x10]!
    //     0xb5e7e0: mov             fp, SP
    // 0xb5e7e4: ldr             x2, [fp, #0x10]
    // 0xb5e7e8: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0xb5e7e8: add             x1, PP, #0xad, lsl #12  ; [pp+0xad6f0] AnonymousClosure: (0xb2b2a8), in [package:flutter/src/material/slider.dart] _RenderSlider::computeMaxIntrinsicHeight (0xb2b248)
    //     0xb5e7ec: ldr             x1, [x1, #0x6f0]
    // 0xb5e7f0: r0 = AllocateClosure()
    //     0xb5e7f0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb5e7f4: LeaveFrame
    //     0xb5e7f4: mov             SP, fp
    //     0xb5e7f8: ldp             fp, lr, [SP], #0x10
    // 0xb5e7fc: ret
    //     0xb5e7fc: ret             
  }
  _ describeSemanticsConfiguration(/* No info */) {
    // ** addr: 0xbf8d10, size: 0x4a4
    // 0xbf8d10: EnterFrame
    //     0xbf8d10: stp             fp, lr, [SP, #-0x10]!
    //     0xbf8d14: mov             fp, SP
    // 0xbf8d18: AllocStack(0x20)
    //     0xbf8d18: sub             SP, SP, #0x20
    // 0xbf8d1c: r0 = true
    //     0xbf8d1c: add             x0, NULL, #0x20  ; true
    // 0xbf8d20: mov             x4, x1
    // 0xbf8d24: mov             x3, x2
    // 0xbf8d28: stur            x1, [fp, #-8]
    // 0xbf8d2c: stur            x2, [fp, #-0x10]
    // 0xbf8d30: CheckStackOverflow
    //     0xbf8d30: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf8d34: cmp             SP, x16
    //     0xbf8d38: b.ls            #0xbf9148
    // 0xbf8d3c: StoreField: r3->field_7 = r0
    //     0xbf8d3c: stur            w0, [x3, #7]
    // 0xbf8d40: LoadField: r1 = r4->field_b3
    //     0xbf8d40: ldur            w1, [x4, #0xb3]
    // 0xbf8d44: DecompressPointer r1
    //     0xbf8d44: add             x1, x1, HEAP, lsl #32
    // 0xbf8d48: cmp             w1, NULL
    // 0xbf8d4c: r16 = true
    //     0xbf8d4c: add             x16, NULL, #0x20  ; true
    // 0xbf8d50: r17 = false
    //     0xbf8d50: add             x17, NULL, #0x30  ; false
    // 0xbf8d54: csel            x2, x16, x17, ne
    // 0xbf8d58: mov             x1, x3
    // 0xbf8d5c: r0 = isEnabled=()
    //     0xbf8d5c: bl              #0xbf4520  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::isEnabled=
    // 0xbf8d60: ldur            x0, [fp, #-8]
    // 0xbf8d64: LoadField: r2 = r0->field_9f
    //     0xbf8d64: ldur            w2, [x0, #0x9f]
    // 0xbf8d68: DecompressPointer r2
    //     0xbf8d68: add             x2, x2, HEAP, lsl #32
    // 0xbf8d6c: cmp             w2, NULL
    // 0xbf8d70: b.eq            #0xbf8d7c
    // 0xbf8d74: ldur            x1, [fp, #-0x10]
    // 0xbf8d78: r0 = label=()
    //     0xbf8d78: bl              #0xbf91d0  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::label=
    // 0xbf8d7c: ldur            x0, [fp, #-8]
    // 0xbf8d80: ldur            x1, [fp, #-0x10]
    // 0xbf8d84: r2 = true
    //     0xbf8d84: add             x2, NULL, #0x20  ; true
    // 0xbf8d88: r0 = isSlider=()
    //     0xbf8d88: bl              #0xbf51e0  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::isSlider=
    // 0xbf8d8c: ldur            x0, [fp, #-8]
    // 0xbf8d90: LoadField: r1 = r0->field_b3
    //     0xbf8d90: ldur            w1, [x0, #0xb3]
    // 0xbf8d94: DecompressPointer r1
    //     0xbf8d94: add             x1, x1, HEAP, lsl #32
    // 0xbf8d98: cmp             w1, NULL
    // 0xbf8d9c: r16 = true
    //     0xbf8d9c: add             x16, NULL, #0x20  ; true
    // 0xbf8da0: r17 = false
    //     0xbf8da0: add             x17, NULL, #0x30  ; false
    // 0xbf8da4: csel            x2, x16, x17, ne
    // 0xbf8da8: ldur            x1, [fp, #-0x10]
    // 0xbf8dac: r0 = isFocusable=()
    //     0xbf8dac: bl              #0xbf4060  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::isFocusable=
    // 0xbf8db0: ldur            x0, [fp, #-8]
    // 0xbf8db4: LoadField: r2 = r0->field_c3
    //     0xbf8db4: ldur            w2, [x0, #0xc3]
    // 0xbf8db8: DecompressPointer r2
    //     0xbf8db8: add             x2, x2, HEAP, lsl #32
    // 0xbf8dbc: ldur            x1, [fp, #-0x10]
    // 0xbf8dc0: r0 = isFocused=()
    //     0xbf8dc0: bl              #0xbf3fc8  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::isFocused=
    // 0xbf8dc4: ldur            x0, [fp, #-8]
    // 0xbf8dc8: LoadField: r3 = r0->field_73
    //     0xbf8dc8: ldur            w3, [x0, #0x73]
    // 0xbf8dcc: DecompressPointer r3
    //     0xbf8dcc: add             x3, x3, HEAP, lsl #32
    // 0xbf8dd0: cmp             w3, NULL
    // 0xbf8dd4: b.eq            #0xbf8de8
    // 0xbf8dd8: ldur            x1, [fp, #-0x10]
    // 0xbf8ddc: r2 = Instance_SemanticsAction
    //     0xbf8ddc: add             x2, PP, #0x85, lsl #12  ; [pp+0x85740] Obj!SemanticsAction@12a0701
    //     0xbf8de0: ldr             x2, [x2, #0x740]
    // 0xbf8de4: r0 = _addArgumentlessAction()
    //     0xbf8de4: bl              #0xbf36cc  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::_addArgumentlessAction
    // 0xbf8de8: ldur            x3, [fp, #-8]
    // 0xbf8dec: ldur            x5, [fp, #-0x10]
    // 0xbf8df0: r4 = true
    //     0xbf8df0: add             x4, NULL, #0x20  ; true
    // 0xbf8df4: LoadField: r0 = r3->field_bf
    //     0xbf8df4: ldur            w0, [x3, #0xbf]
    // 0xbf8df8: DecompressPointer r0
    //     0xbf8df8: add             x0, x0, HEAP, lsl #32
    // 0xbf8dfc: StoreField: r5->field_83 = r0
    //     0xbf8dfc: stur            w0, [x5, #0x83]
    //     0xbf8e00: ldurb           w16, [x5, #-1]
    //     0xbf8e04: ldurb           w17, [x0, #-1]
    //     0xbf8e08: and             x16, x17, x16, lsr #2
    //     0xbf8e0c: tst             x16, HEAP, lsr #32
    //     0xbf8e10: b.eq            #0xbf8e18
    //     0xbf8e14: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0xbf8e18: StoreField: r5->field_1f = r4
    //     0xbf8e18: stur            w4, [x5, #0x1f]
    // 0xbf8e1c: LoadField: r0 = r3->field_b3
    //     0xbf8e1c: ldur            w0, [x3, #0xb3]
    // 0xbf8e20: DecompressPointer r0
    //     0xbf8e20: add             x0, x0, HEAP, lsl #32
    // 0xbf8e24: cmp             w0, NULL
    // 0xbf8e28: b.eq            #0xbf8e88
    // 0xbf8e2c: mov             x2, x3
    // 0xbf8e30: r1 = Function 'increaseAction':.
    //     0xbf8e30: add             x1, PP, #0xad, lsl #12  ; [pp+0xad720] AnonymousClosure: (0xbf99b4), in [package:flutter/src/material/slider.dart] _RenderSlider::increaseAction (0xbf99ec)
    //     0xbf8e34: ldr             x1, [x1, #0x720]
    // 0xbf8e38: r0 = AllocateClosure()
    //     0xbf8e38: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xbf8e3c: ldur            x1, [fp, #-0x10]
    // 0xbf8e40: mov             x2, x0
    // 0xbf8e44: r0 = onIncrease=()
    //     0xbf8e44: bl              #0xbf51a4  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::onIncrease=
    // 0xbf8e48: ldur            x2, [fp, #-8]
    // 0xbf8e4c: r1 = Function 'decreaseAction':.
    //     0xbf8e4c: add             x1, PP, #0xad, lsl #12  ; [pp+0xad728] AnonymousClosure: (0xbf9344), in [package:flutter/src/material/slider.dart] _RenderSlider::decreaseAction (0xbf937c)
    //     0xbf8e50: ldr             x1, [x1, #0x728]
    // 0xbf8e54: r0 = AllocateClosure()
    //     0xbf8e54: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xbf8e58: ldur            x1, [fp, #-0x10]
    // 0xbf8e5c: mov             x2, x0
    // 0xbf8e60: r0 = onDecrease=()
    //     0xbf8e60: bl              #0xbf5168  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::onDecrease=
    // 0xbf8e64: ldur            x2, [fp, #-8]
    // 0xbf8e68: r1 = Function 'onFocusAction':.
    //     0xbf8e68: add             x1, PP, #0xad, lsl #12  ; [pp+0xad730] AnonymousClosure: (0xbf9230), in [package:flutter/src/material/slider.dart] _RenderSlider::onFocusAction (0xbf9268)
    //     0xbf8e6c: ldr             x1, [x1, #0x730]
    // 0xbf8e70: r0 = AllocateClosure()
    //     0xbf8e70: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xbf8e74: ldur            x1, [fp, #-0x10]
    // 0xbf8e78: mov             x3, x0
    // 0xbf8e7c: r2 = Instance_SemanticsAction
    //     0xbf8e7c: add             x2, PP, #0x85, lsl #12  ; [pp+0x85728] Obj!SemanticsAction@12a0621
    //     0xbf8e80: ldr             x2, [x2, #0x728]
    // 0xbf8e84: r0 = _addArgumentlessAction()
    //     0xbf8e84: bl              #0xbf36cc  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::_addArgumentlessAction
    // 0xbf8e88: ldur            x19, [fp, #-8]
    // 0xbf8e8c: ldur            x20, [fp, #-0x10]
    // 0xbf8e90: d1 = 100.000000
    //     0xbf8e90: add             x17, PP, #0x13, lsl #12  ; [pp+0x130a8] IMM: double(100) from 0x4059000000000000
    //     0xbf8e94: ldr             d1, [x17, #0xa8]
    // 0xbf8e98: LoadField: d0 = r19->field_83
    //     0xbf8e98: ldur            d0, [x19, #0x83]
    // 0xbf8e9c: fmul            d2, d0, d1
    // 0xbf8ea0: mov             v0.16b, v2.16b
    // 0xbf8ea4: stp             fp, lr, [SP, #-0x10]!
    // 0xbf8ea8: mov             fp, SP
    // 0xbf8eac: CallRuntime_LibcRound(double) -> double
    //     0xbf8eac: and             SP, SP, #0xfffffffffffffff0
    //     0xbf8eb0: mov             sp, SP
    //     0xbf8eb4: ldr             x16, [THR, #0x770]  ; THR::LibcRound
    //     0xbf8eb8: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xbf8ebc: blr             x16
    //     0xbf8ec0: mov             x16, #8
    //     0xbf8ec4: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xbf8ec8: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xbf8ecc: sub             sp, x16, #1, lsl #12
    //     0xbf8ed0: mov             SP, fp
    //     0xbf8ed4: ldp             fp, lr, [SP], #0x10
    // 0xbf8ed8: fcmp            d0, d0
    // 0xbf8edc: b.vs            #0xbf9150
    // 0xbf8ee0: fcvtzs          x0, d0
    // 0xbf8ee4: asr             x16, x0, #0x1e
    // 0xbf8ee8: cmp             x16, x0, asr #63
    // 0xbf8eec: b.ne            #0xbf9150
    // 0xbf8ef0: lsl             x0, x0, #1
    // 0xbf8ef4: stur            x0, [fp, #-0x18]
    // 0xbf8ef8: r1 = Null
    //     0xbf8ef8: mov             x1, NULL
    // 0xbf8efc: r2 = 4
    //     0xbf8efc: mov             x2, #4
    // 0xbf8f00: r0 = AllocateArray()
    //     0xbf8f00: bl              #0x13df928  ; AllocateArrayStub
    // 0xbf8f04: mov             x1, x0
    // 0xbf8f08: ldur            x0, [fp, #-0x18]
    // 0xbf8f0c: StoreField: r1->field_f = r0
    //     0xbf8f0c: stur            w0, [x1, #0xf]
    // 0xbf8f10: r16 = "%"
    //     0xbf8f10: ldr             x16, [PP, #0x10c0]  ; [pp+0x10c0] "%"
    // 0xbf8f14: StoreField: r1->field_13 = r16
    //     0xbf8f14: stur            w16, [x1, #0x13]
    // 0xbf8f18: str             x1, [SP]
    // 0xbf8f1c: r0 = _interpolate()
    //     0xbf8f1c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xbf8f20: stur            x0, [fp, #-0x18]
    // 0xbf8f24: r0 = AttributedString()
    //     0xbf8f24: bl              #0x837ffc  ; AllocateAttributedStringStub -> AttributedString (size=0x10)
    // 0xbf8f28: mov             x1, x0
    // 0xbf8f2c: ldur            x0, [fp, #-0x18]
    // 0xbf8f30: StoreField: r1->field_7 = r0
    //     0xbf8f30: stur            w0, [x1, #7]
    // 0xbf8f34: r0 = const []
    //     0xbf8f34: ldr             x0, [PP, #0x2708]  ; [pp+0x2708] List<StringAttribute>(0)
    // 0xbf8f38: StoreField: r1->field_b = r0
    //     0xbf8f38: stur            w0, [x1, #0xb]
    // 0xbf8f3c: mov             x0, x1
    // 0xbf8f40: ldur            x19, [fp, #-0x10]
    // 0xbf8f44: StoreField: r19->field_6b = r0
    //     0xbf8f44: stur            w0, [x19, #0x6b]
    //     0xbf8f48: ldurb           w16, [x19, #-1]
    //     0xbf8f4c: ldurb           w17, [x0, #-1]
    //     0xbf8f50: and             x16, x17, x16, lsr #2
    //     0xbf8f54: tst             x16, HEAP, lsr #32
    //     0xbf8f58: b.eq            #0xbf8f60
    //     0xbf8f5c: bl              #0x13de154  ; WriteBarrierWrappersStub
    // 0xbf8f60: r0 = true
    //     0xbf8f60: add             x0, NULL, #0x20  ; true
    // 0xbf8f64: StoreField: r19->field_1f = r0
    //     0xbf8f64: stur            w0, [x19, #0x1f]
    // 0xbf8f68: ldur            x20, [fp, #-8]
    // 0xbf8f6c: LoadField: d0 = r20->field_83
    //     0xbf8f6c: ldur            d0, [x20, #0x83]
    // 0xbf8f70: LoadField: r0 = r20->field_97
    //     0xbf8f70: ldur            x0, [x20, #0x97]
    // 0xbf8f74: scvtf           d1, x0
    // 0xbf8f78: d2 = 1.000000
    //     0xbf8f78: fmov            d2, #1.00000000
    // 0xbf8f7c: fdiv            d3, d2, d1
    // 0xbf8f80: fadd            d1, d0, d3
    // 0xbf8f84: d3 = 0.000000
    //     0xbf8f84: eor             v3.16b, v3.16b, v3.16b
    // 0xbf8f88: fcmp            d3, d1
    // 0xbf8f8c: b.le            #0xbf8f98
    // 0xbf8f90: d0 = 0.000000
    //     0xbf8f90: eor             v0.16b, v0.16b, v0.16b
    // 0xbf8f94: b               #0xbf8fbc
    // 0xbf8f98: fcmp            d1, d2
    // 0xbf8f9c: b.le            #0xbf8fa8
    // 0xbf8fa0: d0 = 1.000000
    //     0xbf8fa0: fmov            d0, #1.00000000
    // 0xbf8fa4: b               #0xbf8fbc
    // 0xbf8fa8: fcmp            d1, d1
    // 0xbf8fac: b.vc            #0xbf8fb8
    // 0xbf8fb0: d0 = 1.000000
    //     0xbf8fb0: fmov            d0, #1.00000000
    // 0xbf8fb4: b               #0xbf8fbc
    // 0xbf8fb8: mov             v0.16b, v1.16b
    // 0xbf8fbc: d1 = 100.000000
    //     0xbf8fbc: add             x17, PP, #0x13, lsl #12  ; [pp+0x130a8] IMM: double(100) from 0x4059000000000000
    //     0xbf8fc0: ldr             d1, [x17, #0xa8]
    // 0xbf8fc4: fmul            d4, d0, d1
    // 0xbf8fc8: mov             v0.16b, v4.16b
    // 0xbf8fcc: stp             fp, lr, [SP, #-0x10]!
    // 0xbf8fd0: mov             fp, SP
    // 0xbf8fd4: CallRuntime_LibcRound(double) -> double
    //     0xbf8fd4: and             SP, SP, #0xfffffffffffffff0
    //     0xbf8fd8: mov             sp, SP
    //     0xbf8fdc: ldr             x16, [THR, #0x770]  ; THR::LibcRound
    //     0xbf8fe0: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xbf8fe4: blr             x16
    //     0xbf8fe8: mov             x16, #8
    //     0xbf8fec: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xbf8ff0: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xbf8ff4: sub             sp, x16, #1, lsl #12
    //     0xbf8ff8: mov             SP, fp
    //     0xbf8ffc: ldp             fp, lr, [SP], #0x10
    // 0xbf9000: fcmp            d0, d0
    // 0xbf9004: b.vs            #0xbf9174
    // 0xbf9008: fcvtzs          x0, d0
    // 0xbf900c: asr             x16, x0, #0x1e
    // 0xbf9010: cmp             x16, x0, asr #63
    // 0xbf9014: b.ne            #0xbf9174
    // 0xbf9018: lsl             x0, x0, #1
    // 0xbf901c: stur            x0, [fp, #-0x18]
    // 0xbf9020: r1 = Null
    //     0xbf9020: mov             x1, NULL
    // 0xbf9024: r2 = 4
    //     0xbf9024: mov             x2, #4
    // 0xbf9028: r0 = AllocateArray()
    //     0xbf9028: bl              #0x13df928  ; AllocateArrayStub
    // 0xbf902c: mov             x1, x0
    // 0xbf9030: ldur            x0, [fp, #-0x18]
    // 0xbf9034: StoreField: r1->field_f = r0
    //     0xbf9034: stur            w0, [x1, #0xf]
    // 0xbf9038: r16 = "%"
    //     0xbf9038: ldr             x16, [PP, #0x10c0]  ; [pp+0x10c0] "%"
    // 0xbf903c: StoreField: r1->field_13 = r16
    //     0xbf903c: stur            w16, [x1, #0x13]
    // 0xbf9040: str             x1, [SP]
    // 0xbf9044: r0 = _interpolate()
    //     0xbf9044: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xbf9048: ldur            x1, [fp, #-0x10]
    // 0xbf904c: mov             x2, x0
    // 0xbf9050: r0 = increasedValue=()
    //     0xbf9050: bl              #0xbf5108  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::increasedValue=
    // 0xbf9054: ldur            x0, [fp, #-8]
    // 0xbf9058: LoadField: d0 = r0->field_83
    //     0xbf9058: ldur            d0, [x0, #0x83]
    // 0xbf905c: LoadField: r1 = r0->field_97
    //     0xbf905c: ldur            x1, [x0, #0x97]
    // 0xbf9060: scvtf           d1, x1
    // 0xbf9064: d2 = 1.000000
    //     0xbf9064: fmov            d2, #1.00000000
    // 0xbf9068: fdiv            d3, d2, d1
    // 0xbf906c: fsub            d1, d0, d3
    // 0xbf9070: d0 = 0.000000
    //     0xbf9070: eor             v0.16b, v0.16b, v0.16b
    // 0xbf9074: fcmp            d0, d1
    // 0xbf9078: b.le            #0xbf9084
    // 0xbf907c: d1 = 0.000000
    //     0xbf907c: eor             v1.16b, v1.16b, v1.16b
    // 0xbf9080: b               #0xbf90a0
    // 0xbf9084: fcmp            d1, d2
    // 0xbf9088: b.le            #0xbf9094
    // 0xbf908c: d1 = 1.000000
    //     0xbf908c: fmov            d1, #1.00000000
    // 0xbf9090: b               #0xbf90a0
    // 0xbf9094: fcmp            d1, d1
    // 0xbf9098: b.vc            #0xbf90a0
    // 0xbf909c: d1 = 1.000000
    //     0xbf909c: fmov            d1, #1.00000000
    // 0xbf90a0: d0 = 100.000000
    //     0xbf90a0: add             x17, PP, #0x13, lsl #12  ; [pp+0x130a8] IMM: double(100) from 0x4059000000000000
    //     0xbf90a4: ldr             d0, [x17, #0xa8]
    // 0xbf90a8: fmul            d2, d1, d0
    // 0xbf90ac: mov             v0.16b, v2.16b
    // 0xbf90b0: stp             fp, lr, [SP, #-0x10]!
    // 0xbf90b4: mov             fp, SP
    // 0xbf90b8: CallRuntime_LibcRound(double) -> double
    //     0xbf90b8: and             SP, SP, #0xfffffffffffffff0
    //     0xbf90bc: mov             sp, SP
    //     0xbf90c0: ldr             x16, [THR, #0x770]  ; THR::LibcRound
    //     0xbf90c4: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xbf90c8: blr             x16
    //     0xbf90cc: mov             x16, #8
    //     0xbf90d0: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xbf90d4: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xbf90d8: sub             sp, x16, #1, lsl #12
    //     0xbf90dc: mov             SP, fp
    //     0xbf90e0: ldp             fp, lr, [SP], #0x10
    // 0xbf90e4: fcmp            d0, d0
    // 0xbf90e8: b.vs            #0xbf9198
    // 0xbf90ec: fcvtzs          x0, d0
    // 0xbf90f0: asr             x16, x0, #0x1e
    // 0xbf90f4: cmp             x16, x0, asr #63
    // 0xbf90f8: b.ne            #0xbf9198
    // 0xbf90fc: lsl             x0, x0, #1
    // 0xbf9100: stur            x0, [fp, #-8]
    // 0xbf9104: r1 = Null
    //     0xbf9104: mov             x1, NULL
    // 0xbf9108: r2 = 4
    //     0xbf9108: mov             x2, #4
    // 0xbf910c: r0 = AllocateArray()
    //     0xbf910c: bl              #0x13df928  ; AllocateArrayStub
    // 0xbf9110: mov             x1, x0
    // 0xbf9114: ldur            x0, [fp, #-8]
    // 0xbf9118: StoreField: r1->field_f = r0
    //     0xbf9118: stur            w0, [x1, #0xf]
    // 0xbf911c: r16 = "%"
    //     0xbf911c: ldr             x16, [PP, #0x10c0]  ; [pp+0x10c0] "%"
    // 0xbf9120: StoreField: r1->field_13 = r16
    //     0xbf9120: stur            w16, [x1, #0x13]
    // 0xbf9124: str             x1, [SP]
    // 0xbf9128: r0 = _interpolate()
    //     0xbf9128: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xbf912c: ldur            x1, [fp, #-0x10]
    // 0xbf9130: mov             x2, x0
    // 0xbf9134: r0 = decreasedValue=()
    //     0xbf9134: bl              #0xbf50a8  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::decreasedValue=
    // 0xbf9138: r0 = Null
    //     0xbf9138: mov             x0, NULL
    // 0xbf913c: LeaveFrame
    //     0xbf913c: mov             SP, fp
    //     0xbf9140: ldp             fp, lr, [SP], #0x10
    // 0xbf9144: ret
    //     0xbf9144: ret             
    // 0xbf9148: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf9148: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf914c: b               #0xbf8d3c
    // 0xbf9150: SaveReg d0
    //     0xbf9150: str             q0, [SP, #-0x10]!
    // 0xbf9154: stp             x19, x20, [SP, #-0x10]!
    // 0xbf9158: r0 = 76
    //     0xbf9158: mov             x0, #0x4c
    // 0xbf915c: r30 = DoubleToIntegerStub
    //     0xbf915c: ldr             lr, [PP, #0x1b70]  ; [pp+0x1b70] Stub: DoubleToInteger (0x7d18e4)
    // 0xbf9160: LoadField: r30 = r30->field_7
    //     0xbf9160: ldur            lr, [lr, #7]
    // 0xbf9164: blr             lr
    // 0xbf9168: ldp             x19, x20, [SP], #0x10
    // 0xbf916c: RestoreReg d0
    //     0xbf916c: ldr             q0, [SP], #0x10
    // 0xbf9170: b               #0xbf8ef4
    // 0xbf9174: SaveReg d0
    //     0xbf9174: str             q0, [SP, #-0x10]!
    // 0xbf9178: stp             x19, x20, [SP, #-0x10]!
    // 0xbf917c: r0 = 76
    //     0xbf917c: mov             x0, #0x4c
    // 0xbf9180: r30 = DoubleToIntegerStub
    //     0xbf9180: ldr             lr, [PP, #0x1b70]  ; [pp+0x1b70] Stub: DoubleToInteger (0x7d18e4)
    // 0xbf9184: LoadField: r30 = r30->field_7
    //     0xbf9184: ldur            lr, [lr, #7]
    // 0xbf9188: blr             lr
    // 0xbf918c: ldp             x19, x20, [SP], #0x10
    // 0xbf9190: RestoreReg d0
    //     0xbf9190: ldr             q0, [SP], #0x10
    // 0xbf9194: b               #0xbf901c
    // 0xbf9198: SaveReg d0
    //     0xbf9198: str             q0, [SP, #-0x10]!
    // 0xbf919c: r0 = 76
    //     0xbf919c: mov             x0, #0x4c
    // 0xbf91a0: r30 = DoubleToIntegerStub
    //     0xbf91a0: ldr             lr, [PP, #0x1b70]  ; [pp+0x1b70] Stub: DoubleToInteger (0x7d18e4)
    // 0xbf91a4: LoadField: r30 = r30->field_7
    //     0xbf91a4: ldur            lr, [lr, #7]
    // 0xbf91a8: blr             lr
    // 0xbf91ac: RestoreReg d0
    //     0xbf91ac: ldr             q0, [SP], #0x10
    // 0xbf91b0: b               #0xbf9100
  }
  get _ isInteractive(/* No info */) {
    // ** addr: 0xbf91b4, size: 0x1c
    // 0xbf91b4: LoadField: r2 = r1->field_b3
    //     0xbf91b4: ldur            w2, [x1, #0xb3]
    // 0xbf91b8: DecompressPointer r2
    //     0xbf91b8: add             x2, x2, HEAP, lsl #32
    // 0xbf91bc: cmp             w2, NULL
    // 0xbf91c0: r16 = true
    //     0xbf91c0: add             x16, NULL, #0x20  ; true
    // 0xbf91c4: r17 = false
    //     0xbf91c4: add             x17, NULL, #0x30  ; false
    // 0xbf91c8: csel            x0, x16, x17, ne
    // 0xbf91cc: ret
    //     0xbf91cc: ret             
  }
  [closure] void onFocusAction(dynamic) {
    // ** addr: 0xbf9230, size: 0x38
    // 0xbf9230: EnterFrame
    //     0xbf9230: stp             fp, lr, [SP, #-0x10]!
    //     0xbf9234: mov             fp, SP
    // 0xbf9238: ldr             x0, [fp, #0x10]
    // 0xbf923c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbf923c: ldur            w1, [x0, #0x17]
    // 0xbf9240: DecompressPointer r1
    //     0xbf9240: add             x1, x1, HEAP, lsl #32
    // 0xbf9244: CheckStackOverflow
    //     0xbf9244: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf9248: cmp             SP, x16
    //     0xbf924c: b.ls            #0xbf9260
    // 0xbf9250: r0 = onFocusAction()
    //     0xbf9250: bl              #0xbf9268  ; [package:flutter/src/material/slider.dart] _RenderSlider::onFocusAction
    // 0xbf9254: LeaveFrame
    //     0xbf9254: mov             SP, fp
    //     0xbf9258: ldp             fp, lr, [SP], #0x10
    // 0xbf925c: ret
    //     0xbf925c: ret             
    // 0xbf9260: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf9260: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf9264: b               #0xbf9250
  }
  _ onFocusAction(/* No info */) {
    // ** addr: 0xbf9268, size: 0xa0
    // 0xbf9268: EnterFrame
    //     0xbf9268: stp             fp, lr, [SP, #-0x10]!
    //     0xbf926c: mov             fp, SP
    // 0xbf9270: CheckStackOverflow
    //     0xbf9270: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf9274: cmp             SP, x16
    //     0xbf9278: b.ls            #0xbf92f8
    // 0xbf927c: LoadField: r0 = r1->field_b3
    //     0xbf927c: ldur            w0, [x1, #0xb3]
    // 0xbf9280: DecompressPointer r0
    //     0xbf9280: add             x0, x0, HEAP, lsl #32
    // 0xbf9284: cmp             w0, NULL
    // 0xbf9288: b.eq            #0xbf92e8
    // 0xbf928c: LoadField: r0 = r1->field_53
    //     0xbf928c: ldur            w0, [x1, #0x53]
    // 0xbf9290: DecompressPointer r0
    //     0xbf9290: add             x0, x0, HEAP, lsl #32
    // 0xbf9294: LoadField: r2 = r0->field_f
    //     0xbf9294: ldur            w2, [x0, #0xf]
    // 0xbf9298: DecompressPointer r2
    //     0xbf9298: add             x2, x2, HEAP, lsl #32
    // 0xbf929c: cmp             w2, NULL
    // 0xbf92a0: b.ne            #0xbf92b4
    // 0xbf92a4: r0 = Null
    //     0xbf92a4: mov             x0, NULL
    // 0xbf92a8: LeaveFrame
    //     0xbf92a8: mov             SP, fp
    //     0xbf92ac: ldp             fp, lr, [SP], #0x10
    // 0xbf92b0: ret
    //     0xbf92b0: ret             
    // 0xbf92b4: LoadField: r2 = r1->field_c3
    //     0xbf92b4: ldur            w2, [x1, #0xc3]
    // 0xbf92b8: DecompressPointer r2
    //     0xbf92b8: add             x2, x2, HEAP, lsl #32
    // 0xbf92bc: tbz             w2, #4, #0xbf92e8
    // 0xbf92c0: LoadField: r1 = r0->field_b
    //     0xbf92c0: ldur            w1, [x0, #0xb]
    // 0xbf92c4: DecompressPointer r1
    //     0xbf92c4: add             x1, x1, HEAP, lsl #32
    // 0xbf92c8: cmp             w1, NULL
    // 0xbf92cc: b.eq            #0xbf9300
    // 0xbf92d0: LoadField: r1 = r0->field_43
    //     0xbf92d0: ldur            w1, [x0, #0x43]
    // 0xbf92d4: DecompressPointer r1
    //     0xbf92d4: add             x1, x1, HEAP, lsl #32
    // 0xbf92d8: cmp             w1, NULL
    // 0xbf92dc: b.eq            #0xbf9304
    // 0xbf92e0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xbf92e0: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xbf92e4: r0 = requestFocus()
    //     0xbf92e4: bl              #0x83e7b8  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::requestFocus
    // 0xbf92e8: r0 = Null
    //     0xbf92e8: mov             x0, NULL
    // 0xbf92ec: LeaveFrame
    //     0xbf92ec: mov             SP, fp
    //     0xbf92f0: ldp             fp, lr, [SP], #0x10
    // 0xbf92f4: ret
    //     0xbf92f4: ret             
    // 0xbf92f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf92f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf92fc: b               #0xbf927c
    // 0xbf9300: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf9300: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf9304: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf9304: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void decreaseAction(dynamic) {
    // ** addr: 0xbf9344, size: 0x38
    // 0xbf9344: EnterFrame
    //     0xbf9344: stp             fp, lr, [SP, #-0x10]!
    //     0xbf9348: mov             fp, SP
    // 0xbf934c: ldr             x0, [fp, #0x10]
    // 0xbf9350: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbf9350: ldur            w1, [x0, #0x17]
    // 0xbf9354: DecompressPointer r1
    //     0xbf9354: add             x1, x1, HEAP, lsl #32
    // 0xbf9358: CheckStackOverflow
    //     0xbf9358: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf935c: cmp             SP, x16
    //     0xbf9360: b.ls            #0xbf9374
    // 0xbf9364: r0 = decreaseAction()
    //     0xbf9364: bl              #0xbf937c  ; [package:flutter/src/material/slider.dart] _RenderSlider::decreaseAction
    // 0xbf9368: LeaveFrame
    //     0xbf9368: mov             SP, fp
    //     0xbf936c: ldp             fp, lr, [SP], #0x10
    // 0xbf9370: ret
    //     0xbf9370: ret             
    // 0xbf9374: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf9374: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf9378: b               #0xbf9364
  }
  _ decreaseAction(/* No info */) {
    // ** addr: 0xbf937c, size: 0x198
    // 0xbf937c: EnterFrame
    //     0xbf937c: stp             fp, lr, [SP, #-0x10]!
    //     0xbf9380: mov             fp, SP
    // 0xbf9384: AllocStack(0x10)
    //     0xbf9384: sub             SP, SP, #0x10
    // 0xbf9388: SetupParameters(_RenderSlider this /* r1 => r0, fp-0x8 */)
    //     0xbf9388: mov             x0, x1
    //     0xbf938c: stur            x1, [fp, #-8]
    // 0xbf9390: CheckStackOverflow
    //     0xbf9390: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf9394: cmp             SP, x16
    //     0xbf9398: b.ls            #0xbf94c8
    // 0xbf939c: mov             x1, x0
    // 0xbf93a0: r0 = isInteractive()
    //     0xbf93a0: bl              #0xbf91b4  ; [package:flutter/src/material/slider.dart] _RenderSlider::isInteractive
    // 0xbf93a4: tbnz            w0, #4, #0xbf94b8
    // 0xbf93a8: ldur            x0, [fp, #-8]
    // 0xbf93ac: LoadField: r2 = r0->field_b7
    //     0xbf93ac: ldur            w2, [x0, #0xb7]
    // 0xbf93b0: DecompressPointer r2
    //     0xbf93b0: add             x2, x2, HEAP, lsl #32
    // 0xbf93b4: mov             x1, x0
    // 0xbf93b8: stur            x2, [fp, #-0x10]
    // 0xbf93bc: r0 = currentValue()
    //     0xbf93bc: bl              #0xbf9970  ; [package:flutter/src/material/slider.dart] _RenderSlider::currentValue
    // 0xbf93c0: ldur            x0, [fp, #-0x10]
    // 0xbf93c4: cmp             w0, NULL
    // 0xbf93c8: b.eq            #0xbf94d0
    // 0xbf93cc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbf93cc: ldur            w1, [x0, #0x17]
    // 0xbf93d0: DecompressPointer r1
    //     0xbf93d0: add             x1, x1, HEAP, lsl #32
    // 0xbf93d4: r2 = inline_Allocate_Double()
    //     0xbf93d4: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0xbf93d8: add             x2, x2, #0x10
    //     0xbf93dc: cmp             x0, x2
    //     0xbf93e0: b.ls            #0xbf94d4
    //     0xbf93e4: str             x2, [THR, #0x60]  ; THR::top
    //     0xbf93e8: sub             x2, x2, #0xf
    //     0xbf93ec: mov             x0, #0xe19c
    //     0xbf93f0: movk            x0, #3, lsl #16
    //     0xbf93f4: stur            x0, [x2, #-1]
    // 0xbf93f8: dmb             ishst
    // 0xbf93fc: StoreField: r2->field_7 = d0
    //     0xbf93fc: stur            d0, [x2, #7]
    // 0xbf9400: r0 = _handleDragStart()
    //     0xbf9400: bl              #0xbf98d0  ; [package:flutter/src/material/slider.dart] _SliderState::_handleDragStart
    // 0xbf9404: ldur            x1, [fp, #-8]
    // 0xbf9408: r0 = decreaseValue()
    //     0xbf9408: bl              #0xbf9840  ; [package:flutter/src/material/slider.dart] _RenderSlider::decreaseValue
    // 0xbf940c: ldur            x0, [fp, #-8]
    // 0xbf9410: LoadField: r1 = r0->field_b3
    //     0xbf9410: ldur            w1, [x0, #0xb3]
    // 0xbf9414: DecompressPointer r1
    //     0xbf9414: add             x1, x1, HEAP, lsl #32
    // 0xbf9418: cmp             w1, NULL
    // 0xbf941c: b.eq            #0xbf94f0
    // 0xbf9420: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xbf9420: ldur            w2, [x1, #0x17]
    // 0xbf9424: DecompressPointer r2
    //     0xbf9424: add             x2, x2, HEAP, lsl #32
    // 0xbf9428: r3 = inline_Allocate_Double()
    //     0xbf9428: ldp             x3, x1, [THR, #0x60]  ; THR::top
    //     0xbf942c: add             x3, x3, #0x10
    //     0xbf9430: cmp             x1, x3
    //     0xbf9434: b.ls            #0xbf94f4
    //     0xbf9438: str             x3, [THR, #0x60]  ; THR::top
    //     0xbf943c: sub             x3, x3, #0xf
    //     0xbf9440: mov             x1, #0xe19c
    //     0xbf9444: movk            x1, #3, lsl #16
    //     0xbf9448: stur            x1, [x3, #-1]
    // 0xbf944c: dmb             ishst
    // 0xbf9450: StoreField: r3->field_7 = d0
    //     0xbf9450: stur            d0, [x3, #7]
    // 0xbf9454: mov             x1, x2
    // 0xbf9458: mov             x2, x3
    // 0xbf945c: stur            x3, [fp, #-0x10]
    // 0xbf9460: r0 = _handleChanged()
    //     0xbf9460: bl              #0xbf966c  ; [package:flutter/src/material/slider.dart] _SliderState::_handleChanged
    // 0xbf9464: ldur            x0, [fp, #-8]
    // 0xbf9468: LoadField: r1 = r0->field_bb
    //     0xbf9468: ldur            w1, [x0, #0xbb]
    // 0xbf946c: DecompressPointer r1
    //     0xbf946c: add             x1, x1, HEAP, lsl #32
    // 0xbf9470: cmp             w1, NULL
    // 0xbf9474: b.eq            #0xbf9510
    // 0xbf9478: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xbf9478: ldur            w2, [x1, #0x17]
    // 0xbf947c: DecompressPointer r2
    //     0xbf947c: add             x2, x2, HEAP, lsl #32
    // 0xbf9480: mov             x1, x2
    // 0xbf9484: ldur            x2, [fp, #-0x10]
    // 0xbf9488: r0 = _handleDragEnd()
    //     0xbf9488: bl              #0xbf95c8  ; [package:flutter/src/material/slider.dart] _SliderState::_handleDragEnd
    // 0xbf948c: ldur            x1, [fp, #-8]
    // 0xbf9490: LoadField: r2 = r1->field_53
    //     0xbf9490: ldur            w2, [x1, #0x53]
    // 0xbf9494: DecompressPointer r2
    //     0xbf9494: add             x2, x2, HEAP, lsl #32
    // 0xbf9498: LoadField: r1 = r2->field_f
    //     0xbf9498: ldur            w1, [x2, #0xf]
    // 0xbf949c: DecompressPointer r1
    //     0xbf949c: add             x1, x1, HEAP, lsl #32
    // 0xbf94a0: cmp             w1, NULL
    // 0xbf94a4: b.ne            #0xbf94b8
    // 0xbf94a8: r0 = Null
    //     0xbf94a8: mov             x0, NULL
    // 0xbf94ac: LeaveFrame
    //     0xbf94ac: mov             SP, fp
    //     0xbf94b0: ldp             fp, lr, [SP], #0x10
    // 0xbf94b4: ret
    //     0xbf94b4: ret             
    // 0xbf94b8: r0 = Null
    //     0xbf94b8: mov             x0, NULL
    // 0xbf94bc: LeaveFrame
    //     0xbf94bc: mov             SP, fp
    //     0xbf94c0: ldp             fp, lr, [SP], #0x10
    // 0xbf94c4: ret
    //     0xbf94c4: ret             
    // 0xbf94c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf94c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf94cc: b               #0xbf939c
    // 0xbf94d0: r0 = NullErrorSharedWithFPURegs()
    //     0xbf94d0: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0xbf94d4: SaveReg d0
    //     0xbf94d4: str             q0, [SP, #-0x10]!
    // 0xbf94d8: SaveReg r1
    //     0xbf94d8: str             x1, [SP, #-8]!
    // 0xbf94dc: r0 = AllocateDouble()
    //     0xbf94dc: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbf94e0: mov             x2, x0
    // 0xbf94e4: RestoreReg r1
    //     0xbf94e4: ldr             x1, [SP], #8
    // 0xbf94e8: RestoreReg d0
    //     0xbf94e8: ldr             q0, [SP], #0x10
    // 0xbf94ec: b               #0xbf93fc
    // 0xbf94f0: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbf94f0: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbf94f4: SaveReg d0
    //     0xbf94f4: str             q0, [SP, #-0x10]!
    // 0xbf94f8: stp             x0, x2, [SP, #-0x10]!
    // 0xbf94fc: r0 = AllocateDouble()
    //     0xbf94fc: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbf9500: mov             x3, x0
    // 0xbf9504: ldp             x0, x2, [SP], #0x10
    // 0xbf9508: RestoreReg d0
    //     0xbf9508: ldr             q0, [SP], #0x10
    // 0xbf950c: b               #0xbf9450
    // 0xbf9510: r0 = NullErrorSharedWithoutFPURegs()
    //     0xbf9510: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  double decreaseValue(_RenderSlider) {
    // ** addr: 0xbf9840, size: 0x7c
    // 0xbf9840: EnterFrame
    //     0xbf9840: stp             fp, lr, [SP, #-0x10]!
    //     0xbf9844: mov             fp, SP
    // 0xbf9848: AllocStack(0x8)
    //     0xbf9848: sub             SP, SP, #8
    // 0xbf984c: CheckStackOverflow
    //     0xbf984c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf9850: cmp             SP, x16
    //     0xbf9854: b.ls            #0xbf98b4
    // 0xbf9858: LoadField: d0 = r1->field_83
    //     0xbf9858: ldur            d0, [x1, #0x83]
    // 0xbf985c: stur            d0, [fp, #-8]
    // 0xbf9860: r0 = _semanticActionUnit()
    //     0xbf9860: bl              #0xbf98bc  ; [package:flutter/src/material/slider.dart] _RenderSlider::_semanticActionUnit
    // 0xbf9864: ldur            d1, [fp, #-8]
    // 0xbf9868: fsub            d2, d1, d0
    // 0xbf986c: d1 = 0.000000
    //     0xbf986c: eor             v1.16b, v1.16b, v1.16b
    // 0xbf9870: fcmp            d1, d2
    // 0xbf9874: b.le            #0xbf9880
    // 0xbf9878: d0 = 0.000000
    //     0xbf9878: eor             v0.16b, v0.16b, v0.16b
    // 0xbf987c: b               #0xbf98a8
    // 0xbf9880: d1 = 1.000000
    //     0xbf9880: fmov            d1, #1.00000000
    // 0xbf9884: fcmp            d2, d1
    // 0xbf9888: b.le            #0xbf9894
    // 0xbf988c: d0 = 1.000000
    //     0xbf988c: fmov            d0, #1.00000000
    // 0xbf9890: b               #0xbf98a8
    // 0xbf9894: fcmp            d2, d2
    // 0xbf9898: b.vc            #0xbf98a4
    // 0xbf989c: d0 = 1.000000
    //     0xbf989c: fmov            d0, #1.00000000
    // 0xbf98a0: b               #0xbf98a8
    // 0xbf98a4: mov             v0.16b, v2.16b
    // 0xbf98a8: LeaveFrame
    //     0xbf98a8: mov             SP, fp
    //     0xbf98ac: ldp             fp, lr, [SP], #0x10
    // 0xbf98b0: ret
    //     0xbf98b0: ret             
    // 0xbf98b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf98b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf98b8: b               #0xbf9858
  }
  double _semanticActionUnit(_RenderSlider) {
    // ** addr: 0xbf98bc, size: 0x14
    // 0xbf98bc: d1 = 1.000000
    //     0xbf98bc: fmov            d1, #1.00000000
    // 0xbf98c0: LoadField: r0 = r1->field_97
    //     0xbf98c0: ldur            x0, [x1, #0x97]
    // 0xbf98c4: scvtf           d2, x0
    // 0xbf98c8: fdiv            d0, d1, d2
    // 0xbf98cc: ret
    //     0xbf98cc: ret             
  }
  double currentValue(_RenderSlider) {
    // ** addr: 0xbf9970, size: 0x44
    // 0xbf9970: d1 = 0.000000
    //     0xbf9970: eor             v1.16b, v1.16b, v1.16b
    // 0xbf9974: LoadField: d2 = r1->field_83
    //     0xbf9974: ldur            d2, [x1, #0x83]
    // 0xbf9978: fcmp            d1, d2
    // 0xbf997c: b.le            #0xbf9988
    // 0xbf9980: d0 = 0.000000
    //     0xbf9980: eor             v0.16b, v0.16b, v0.16b
    // 0xbf9984: b               #0xbf99b0
    // 0xbf9988: d1 = 1.000000
    //     0xbf9988: fmov            d1, #1.00000000
    // 0xbf998c: fcmp            d2, d1
    // 0xbf9990: b.le            #0xbf999c
    // 0xbf9994: d0 = 1.000000
    //     0xbf9994: fmov            d0, #1.00000000
    // 0xbf9998: b               #0xbf99b0
    // 0xbf999c: fcmp            d2, d2
    // 0xbf99a0: b.vc            #0xbf99ac
    // 0xbf99a4: d0 = 1.000000
    //     0xbf99a4: fmov            d0, #1.00000000
    // 0xbf99a8: b               #0xbf99b0
    // 0xbf99ac: mov             v0.16b, v2.16b
    // 0xbf99b0: ret
    //     0xbf99b0: ret             
  }
  [closure] void increaseAction(dynamic) {
    // ** addr: 0xbf99b4, size: 0x38
    // 0xbf99b4: EnterFrame
    //     0xbf99b4: stp             fp, lr, [SP, #-0x10]!
    //     0xbf99b8: mov             fp, SP
    // 0xbf99bc: ldr             x0, [fp, #0x10]
    // 0xbf99c0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbf99c0: ldur            w1, [x0, #0x17]
    // 0xbf99c4: DecompressPointer r1
    //     0xbf99c4: add             x1, x1, HEAP, lsl #32
    // 0xbf99c8: CheckStackOverflow
    //     0xbf99c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf99cc: cmp             SP, x16
    //     0xbf99d0: b.ls            #0xbf99e4
    // 0xbf99d4: r0 = increaseAction()
    //     0xbf99d4: bl              #0xbf99ec  ; [package:flutter/src/material/slider.dart] _RenderSlider::increaseAction
    // 0xbf99d8: LeaveFrame
    //     0xbf99d8: mov             SP, fp
    //     0xbf99dc: ldp             fp, lr, [SP], #0x10
    // 0xbf99e0: ret
    //     0xbf99e0: ret             
    // 0xbf99e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf99e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf99e8: b               #0xbf99d4
  }
  _ increaseAction(/* No info */) {
    // ** addr: 0xbf99ec, size: 0x1d4
    // 0xbf99ec: EnterFrame
    //     0xbf99ec: stp             fp, lr, [SP, #-0x10]!
    //     0xbf99f0: mov             fp, SP
    // 0xbf99f4: AllocStack(0x10)
    //     0xbf99f4: sub             SP, SP, #0x10
    // 0xbf99f8: SetupParameters(_RenderSlider this /* r1 => r0, fp-0x8 */)
    //     0xbf99f8: mov             x0, x1
    //     0xbf99fc: stur            x1, [fp, #-8]
    // 0xbf9a00: CheckStackOverflow
    //     0xbf9a00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf9a04: cmp             SP, x16
    //     0xbf9a08: b.ls            #0xbf9b74
    // 0xbf9a0c: LoadField: r1 = r0->field_b3
    //     0xbf9a0c: ldur            w1, [x0, #0xb3]
    // 0xbf9a10: DecompressPointer r1
    //     0xbf9a10: add             x1, x1, HEAP, lsl #32
    // 0xbf9a14: cmp             w1, NULL
    // 0xbf9a18: b.eq            #0xbf9b64
    // 0xbf9a1c: d0 = 0.000000
    //     0xbf9a1c: eor             v0.16b, v0.16b, v0.16b
    // 0xbf9a20: LoadField: r1 = r0->field_b7
    //     0xbf9a20: ldur            w1, [x0, #0xb7]
    // 0xbf9a24: DecompressPointer r1
    //     0xbf9a24: add             x1, x1, HEAP, lsl #32
    // 0xbf9a28: LoadField: d1 = r0->field_83
    //     0xbf9a28: ldur            d1, [x0, #0x83]
    // 0xbf9a2c: fcmp            d0, d1
    // 0xbf9a30: b.le            #0xbf9a3c
    // 0xbf9a34: d0 = 0.000000
    //     0xbf9a34: eor             v0.16b, v0.16b, v0.16b
    // 0xbf9a38: b               #0xbf9a64
    // 0xbf9a3c: d0 = 1.000000
    //     0xbf9a3c: fmov            d0, #1.00000000
    // 0xbf9a40: fcmp            d1, d0
    // 0xbf9a44: b.le            #0xbf9a50
    // 0xbf9a48: d0 = 1.000000
    //     0xbf9a48: fmov            d0, #1.00000000
    // 0xbf9a4c: b               #0xbf9a64
    // 0xbf9a50: fcmp            d1, d1
    // 0xbf9a54: b.vc            #0xbf9a60
    // 0xbf9a58: d0 = 1.000000
    //     0xbf9a58: fmov            d0, #1.00000000
    // 0xbf9a5c: b               #0xbf9a64
    // 0xbf9a60: mov             v0.16b, v1.16b
    // 0xbf9a64: cmp             w1, NULL
    // 0xbf9a68: b.eq            #0xbf9b7c
    // 0xbf9a6c: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xbf9a6c: ldur            w2, [x1, #0x17]
    // 0xbf9a70: DecompressPointer r2
    //     0xbf9a70: add             x2, x2, HEAP, lsl #32
    // 0xbf9a74: r1 = inline_Allocate_Double()
    //     0xbf9a74: ldp             x1, x3, [THR, #0x60]  ; THR::top
    //     0xbf9a78: add             x1, x1, #0x10
    //     0xbf9a7c: cmp             x3, x1
    //     0xbf9a80: b.ls            #0xbf9b80
    //     0xbf9a84: str             x1, [THR, #0x60]  ; THR::top
    //     0xbf9a88: sub             x1, x1, #0xf
    //     0xbf9a8c: mov             x3, #0xe19c
    //     0xbf9a90: movk            x3, #3, lsl #16
    //     0xbf9a94: stur            x3, [x1, #-1]
    // 0xbf9a98: dmb             ishst
    // 0xbf9a9c: StoreField: r1->field_7 = d0
    //     0xbf9a9c: stur            d0, [x1, #7]
    // 0xbf9aa0: mov             x16, x1
    // 0xbf9aa4: mov             x1, x2
    // 0xbf9aa8: mov             x2, x16
    // 0xbf9aac: r0 = _handleDragStart()
    //     0xbf9aac: bl              #0xbf98d0  ; [package:flutter/src/material/slider.dart] _SliderState::_handleDragStart
    // 0xbf9ab0: ldur            x1, [fp, #-8]
    // 0xbf9ab4: r0 = increaseValue()
    //     0xbf9ab4: bl              #0xbf9bc0  ; [package:flutter/src/material/slider.dart] _RenderSlider::increaseValue
    // 0xbf9ab8: ldur            x0, [fp, #-8]
    // 0xbf9abc: LoadField: r1 = r0->field_b3
    //     0xbf9abc: ldur            w1, [x0, #0xb3]
    // 0xbf9ac0: DecompressPointer r1
    //     0xbf9ac0: add             x1, x1, HEAP, lsl #32
    // 0xbf9ac4: cmp             w1, NULL
    // 0xbf9ac8: b.eq            #0xbf9b9c
    // 0xbf9acc: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xbf9acc: ldur            w2, [x1, #0x17]
    // 0xbf9ad0: DecompressPointer r2
    //     0xbf9ad0: add             x2, x2, HEAP, lsl #32
    // 0xbf9ad4: r3 = inline_Allocate_Double()
    //     0xbf9ad4: ldp             x3, x1, [THR, #0x60]  ; THR::top
    //     0xbf9ad8: add             x3, x3, #0x10
    //     0xbf9adc: cmp             x1, x3
    //     0xbf9ae0: b.ls            #0xbf9ba0
    //     0xbf9ae4: str             x3, [THR, #0x60]  ; THR::top
    //     0xbf9ae8: sub             x3, x3, #0xf
    //     0xbf9aec: mov             x1, #0xe19c
    //     0xbf9af0: movk            x1, #3, lsl #16
    //     0xbf9af4: stur            x1, [x3, #-1]
    // 0xbf9af8: dmb             ishst
    // 0xbf9afc: StoreField: r3->field_7 = d0
    //     0xbf9afc: stur            d0, [x3, #7]
    // 0xbf9b00: mov             x1, x2
    // 0xbf9b04: mov             x2, x3
    // 0xbf9b08: stur            x3, [fp, #-0x10]
    // 0xbf9b0c: r0 = _handleChanged()
    //     0xbf9b0c: bl              #0xbf966c  ; [package:flutter/src/material/slider.dart] _SliderState::_handleChanged
    // 0xbf9b10: ldur            x0, [fp, #-8]
    // 0xbf9b14: LoadField: r1 = r0->field_bb
    //     0xbf9b14: ldur            w1, [x0, #0xbb]
    // 0xbf9b18: DecompressPointer r1
    //     0xbf9b18: add             x1, x1, HEAP, lsl #32
    // 0xbf9b1c: cmp             w1, NULL
    // 0xbf9b20: b.eq            #0xbf9bbc
    // 0xbf9b24: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xbf9b24: ldur            w2, [x1, #0x17]
    // 0xbf9b28: DecompressPointer r2
    //     0xbf9b28: add             x2, x2, HEAP, lsl #32
    // 0xbf9b2c: mov             x1, x2
    // 0xbf9b30: ldur            x2, [fp, #-0x10]
    // 0xbf9b34: r0 = _handleDragEnd()
    //     0xbf9b34: bl              #0xbf95c8  ; [package:flutter/src/material/slider.dart] _SliderState::_handleDragEnd
    // 0xbf9b38: ldur            x1, [fp, #-8]
    // 0xbf9b3c: LoadField: r2 = r1->field_53
    //     0xbf9b3c: ldur            w2, [x1, #0x53]
    // 0xbf9b40: DecompressPointer r2
    //     0xbf9b40: add             x2, x2, HEAP, lsl #32
    // 0xbf9b44: LoadField: r1 = r2->field_f
    //     0xbf9b44: ldur            w1, [x2, #0xf]
    // 0xbf9b48: DecompressPointer r1
    //     0xbf9b48: add             x1, x1, HEAP, lsl #32
    // 0xbf9b4c: cmp             w1, NULL
    // 0xbf9b50: b.ne            #0xbf9b64
    // 0xbf9b54: r0 = Null
    //     0xbf9b54: mov             x0, NULL
    // 0xbf9b58: LeaveFrame
    //     0xbf9b58: mov             SP, fp
    //     0xbf9b5c: ldp             fp, lr, [SP], #0x10
    // 0xbf9b60: ret
    //     0xbf9b60: ret             
    // 0xbf9b64: r0 = Null
    //     0xbf9b64: mov             x0, NULL
    // 0xbf9b68: LeaveFrame
    //     0xbf9b68: mov             SP, fp
    //     0xbf9b6c: ldp             fp, lr, [SP], #0x10
    // 0xbf9b70: ret
    //     0xbf9b70: ret             
    // 0xbf9b74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf9b74: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf9b78: b               #0xbf9a0c
    // 0xbf9b7c: r0 = NullErrorSharedWithFPURegs()
    //     0xbf9b7c: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0xbf9b80: SaveReg d0
    //     0xbf9b80: str             q0, [SP, #-0x10]!
    // 0xbf9b84: stp             x0, x2, [SP, #-0x10]!
    // 0xbf9b88: r0 = AllocateDouble()
    //     0xbf9b88: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbf9b8c: mov             x1, x0
    // 0xbf9b90: ldp             x0, x2, [SP], #0x10
    // 0xbf9b94: RestoreReg d0
    //     0xbf9b94: ldr             q0, [SP], #0x10
    // 0xbf9b98: b               #0xbf9a9c
    // 0xbf9b9c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbf9b9c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbf9ba0: SaveReg d0
    //     0xbf9ba0: str             q0, [SP, #-0x10]!
    // 0xbf9ba4: stp             x0, x2, [SP, #-0x10]!
    // 0xbf9ba8: r0 = AllocateDouble()
    //     0xbf9ba8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbf9bac: mov             x3, x0
    // 0xbf9bb0: ldp             x0, x2, [SP], #0x10
    // 0xbf9bb4: RestoreReg d0
    //     0xbf9bb4: ldr             q0, [SP], #0x10
    // 0xbf9bb8: b               #0xbf9afc
    // 0xbf9bbc: r0 = NullErrorSharedWithoutFPURegs()
    //     0xbf9bbc: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  double increaseValue(_RenderSlider) {
    // ** addr: 0xbf9bc0, size: 0x54
    // 0xbf9bc0: d2 = 1.000000
    //     0xbf9bc0: fmov            d2, #1.00000000
    // 0xbf9bc4: d1 = 0.000000
    //     0xbf9bc4: eor             v1.16b, v1.16b, v1.16b
    // 0xbf9bc8: LoadField: d3 = r1->field_83
    //     0xbf9bc8: ldur            d3, [x1, #0x83]
    // 0xbf9bcc: LoadField: r0 = r1->field_97
    //     0xbf9bcc: ldur            x0, [x1, #0x97]
    // 0xbf9bd0: scvtf           d4, x0
    // 0xbf9bd4: fdiv            d5, d2, d4
    // 0xbf9bd8: fadd            d4, d3, d5
    // 0xbf9bdc: fcmp            d1, d4
    // 0xbf9be0: b.le            #0xbf9bec
    // 0xbf9be4: d0 = 0.000000
    //     0xbf9be4: eor             v0.16b, v0.16b, v0.16b
    // 0xbf9be8: b               #0xbf9c10
    // 0xbf9bec: fcmp            d4, d2
    // 0xbf9bf0: b.le            #0xbf9bfc
    // 0xbf9bf4: d0 = 1.000000
    //     0xbf9bf4: fmov            d0, #1.00000000
    // 0xbf9bf8: b               #0xbf9c10
    // 0xbf9bfc: fcmp            d4, d4
    // 0xbf9c00: b.vc            #0xbf9c0c
    // 0xbf9c04: d0 = 1.000000
    //     0xbf9c04: fmov            d0, #1.00000000
    // 0xbf9c08: b               #0xbf9c10
    // 0xbf9c0c: mov             v0.16b, v4.16b
    // 0xbf9c10: ret
    //     0xbf9c10: ret             
  }
  _ dispose(/* No info */) {
    // ** addr: 0xc03380, size: 0x114
    // 0xc03380: EnterFrame
    //     0xc03380: stp             fp, lr, [SP, #-0x10]!
    //     0xc03384: mov             fp, SP
    // 0xc03388: AllocStack(0x8)
    //     0xc03388: sub             SP, SP, #8
    // 0xc0338c: SetupParameters(_RenderSlider this /* r1 => r0, fp-0x8 */)
    //     0xc0338c: mov             x0, x1
    //     0xc03390: stur            x1, [fp, #-8]
    // 0xc03394: CheckStackOverflow
    //     0xc03394: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc03398: cmp             SP, x16
    //     0xc0339c: b.ls            #0xc03450
    // 0xc033a0: LoadField: r1 = r0->field_67
    //     0xc033a0: ldur            w1, [x0, #0x67]
    // 0xc033a4: DecompressPointer r1
    //     0xc033a4: add             x1, x1, HEAP, lsl #32
    // 0xc033a8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc033ac: cmp             w1, w16
    // 0xc033b0: b.eq            #0xc03458
    // 0xc033b4: r0 = dispose()
    //     0xc033b4: bl              #0xbb16bc  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::dispose
    // 0xc033b8: ldur            x0, [fp, #-8]
    // 0xc033bc: LoadField: r1 = r0->field_6b
    //     0xc033bc: ldur            w1, [x0, #0x6b]
    // 0xc033c0: DecompressPointer r1
    //     0xc033c0: add             x1, x1, HEAP, lsl #32
    // 0xc033c4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc033c8: cmp             w1, w16
    // 0xc033cc: b.eq            #0xc03464
    // 0xc033d0: r0 = dispose()
    //     0xc033d0: bl              #0xbb1708  ; [package:flutter/src/gestures/recognizer.dart] PrimaryPointerGestureRecognizer::dispose
    // 0xc033d4: ldur            x0, [fp, #-8]
    // 0xc033d8: LoadField: r1 = r0->field_63
    //     0xc033d8: ldur            w1, [x0, #0x63]
    // 0xc033dc: DecompressPointer r1
    //     0xc033dc: add             x1, x1, HEAP, lsl #32
    // 0xc033e0: r0 = dispose()
    //     0xc033e0: bl              #0xbcb780  ; [package:flutter/src/painting/text_painter.dart] TextPainter::dispose
    // 0xc033e4: ldur            x0, [fp, #-8]
    // 0xc033e8: LoadField: r1 = r0->field_5f
    //     0xc033e8: ldur            w1, [x0, #0x5f]
    // 0xc033ec: DecompressPointer r1
    //     0xc033ec: add             x1, x1, HEAP, lsl #32
    // 0xc033f0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc033f4: cmp             w1, w16
    // 0xc033f8: b.eq            #0xc03470
    // 0xc033fc: r0 = dispose()
    //     0xc033fc: bl              #0xb29014  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::dispose
    // 0xc03400: ldur            x0, [fp, #-8]
    // 0xc03404: LoadField: r1 = r0->field_5b
    //     0xc03404: ldur            w1, [x0, #0x5b]
    // 0xc03408: DecompressPointer r1
    //     0xc03408: add             x1, x1, HEAP, lsl #32
    // 0xc0340c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc03410: cmp             w1, w16
    // 0xc03414: b.eq            #0xc0347c
    // 0xc03418: r0 = dispose()
    //     0xc03418: bl              #0xb29014  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::dispose
    // 0xc0341c: ldur            x0, [fp, #-8]
    // 0xc03420: LoadField: r1 = r0->field_57
    //     0xc03420: ldur            w1, [x0, #0x57]
    // 0xc03424: DecompressPointer r1
    //     0xc03424: add             x1, x1, HEAP, lsl #32
    // 0xc03428: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc0342c: cmp             w1, w16
    // 0xc03430: b.eq            #0xc03488
    // 0xc03434: r0 = dispose()
    //     0xc03434: bl              #0xb29014  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::dispose
    // 0xc03438: ldur            x1, [fp, #-8]
    // 0xc0343c: r0 = dispose()
    //     0xc0343c: bl              #0xc04c8c  ; [package:flutter/src/rendering/object.dart] RenderObject::dispose
    // 0xc03440: r0 = Null
    //     0xc03440: mov             x0, NULL
    // 0xc03444: LeaveFrame
    //     0xc03444: mov             SP, fp
    //     0xc03448: ldp             fp, lr, [SP], #0x10
    // 0xc0344c: ret
    //     0xc0344c: ret             
    // 0xc03450: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc03450: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc03454: b               #0xc033a0
    // 0xc03458: r9 = _drag
    //     0xc03458: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa3720] Field <_RenderSlider@125231897._drag@125231897>: late (offset: 0x68)
    //     0xc0345c: ldr             x9, [x9, #0x720]
    // 0xc03460: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc03460: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xc03464: r9 = _tap
    //     0xc03464: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa3728] Field <_RenderSlider@125231897._tap@125231897>: late (offset: 0x6c)
    //     0xc03468: ldr             x9, [x9, #0x728]
    // 0xc0346c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc0346c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xc03470: r9 = _enableAnimation
    //     0xc03470: add             x9, PP, #0xad, lsl #12  ; [pp+0xad760] Field <_RenderSlider@125231897._enableAnimation@125231897>: late (offset: 0x60)
    //     0xc03474: ldr             x9, [x9, #0x760]
    // 0xc03478: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc03478: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xc0347c: r9 = _valueIndicatorAnimation
    //     0xc0347c: add             x9, PP, #0xad, lsl #12  ; [pp+0xad770] Field <_RenderSlider@125231897._valueIndicatorAnimation@125231897>: late (offset: 0x5c)
    //     0xc03480: ldr             x9, [x9, #0x770]
    // 0xc03484: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc03484: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xc03488: r9 = _overlayAnimation
    //     0xc03488: add             x9, PP, #0xad, lsl #12  ; [pp+0xad768] Field <_RenderSlider@125231897._overlayAnimation@125231897>: late (offset: 0x58)
    //     0xc0348c: ldr             x9, [x9, #0x768]
    // 0xc03490: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc03490: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _updateLabelPainter(/* No info */) {
    // ** addr: 0xc06a40, size: 0xe4
    // 0xc06a40: EnterFrame
    //     0xc06a40: stp             fp, lr, [SP, #-0x10]!
    //     0xc06a44: mov             fp, SP
    // 0xc06a48: AllocStack(0x20)
    //     0xc06a48: sub             SP, SP, #0x20
    // 0xc06a4c: SetupParameters(_RenderSlider this /* r1 => r1, fp-0x20 */)
    //     0xc06a4c: stur            x1, [fp, #-0x20]
    // 0xc06a50: CheckStackOverflow
    //     0xc06a50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc06a54: cmp             SP, x16
    //     0xc06a58: b.ls            #0xc06b1c
    // 0xc06a5c: LoadField: r0 = r1->field_9f
    //     0xc06a5c: ldur            w0, [x1, #0x9f]
    // 0xc06a60: DecompressPointer r0
    //     0xc06a60: add             x0, x0, HEAP, lsl #32
    // 0xc06a64: stur            x0, [fp, #-0x18]
    // 0xc06a68: cmp             w0, NULL
    // 0xc06a6c: b.eq            #0xc06af0
    // 0xc06a70: LoadField: r2 = r1->field_63
    //     0xc06a70: ldur            w2, [x1, #0x63]
    // 0xc06a74: DecompressPointer r2
    //     0xc06a74: add             x2, x2, HEAP, lsl #32
    // 0xc06a78: stur            x2, [fp, #-0x10]
    // 0xc06a7c: LoadField: r3 = r1->field_a3
    //     0xc06a7c: ldur            w3, [x1, #0xa3]
    // 0xc06a80: DecompressPointer r3
    //     0xc06a80: add             x3, x3, HEAP, lsl #32
    // 0xc06a84: LoadField: r4 = r3->field_73
    //     0xc06a84: ldur            w4, [x3, #0x73]
    // 0xc06a88: DecompressPointer r4
    //     0xc06a88: add             x4, x4, HEAP, lsl #32
    // 0xc06a8c: stur            x4, [fp, #-8]
    // 0xc06a90: r0 = TextSpan()
    //     0xc06a90: bl              #0xb57880  ; AllocateTextSpanStub -> TextSpan (size=0x34)
    // 0xc06a94: mov             x1, x0
    // 0xc06a98: ldur            x0, [fp, #-0x18]
    // 0xc06a9c: StoreField: r1->field_b = r0
    //     0xc06a9c: stur            w0, [x1, #0xb]
    // 0xc06aa0: r0 = Instance__DeferringMouseCursor
    //     0xc06aa0: ldr             x0, [PP, #0x2208]  ; [pp+0x2208] Obj!_DeferringMouseCursor@12b3241
    // 0xc06aa4: ArrayStore: r1[0] = r0  ; List_4
    //     0xc06aa4: stur            w0, [x1, #0x17]
    // 0xc06aa8: ldur            x0, [fp, #-8]
    // 0xc06aac: StoreField: r1->field_7 = r0
    //     0xc06aac: stur            w0, [x1, #7]
    // 0xc06ab0: mov             x2, x1
    // 0xc06ab4: ldur            x1, [fp, #-0x10]
    // 0xc06ab8: r0 = text=()
    //     0xc06ab8: bl              #0xb1d2b8  ; [package:flutter/src/painting/text_painter.dart] TextPainter::text=
    // 0xc06abc: ldur            x0, [fp, #-0x20]
    // 0xc06ac0: LoadField: r2 = r0->field_bf
    //     0xc06ac0: ldur            w2, [x0, #0xbf]
    // 0xc06ac4: DecompressPointer r2
    //     0xc06ac4: add             x2, x2, HEAP, lsl #32
    // 0xc06ac8: ldur            x1, [fp, #-0x10]
    // 0xc06acc: r0 = textDirection=()
    //     0xc06acc: bl              #0xb1d1c8  ; [package:flutter/src/painting/text_painter.dart] TextPainter::textDirection=
    // 0xc06ad0: ldur            x0, [fp, #-0x20]
    // 0xc06ad4: LoadField: d0 = r0->field_a7
    //     0xc06ad4: ldur            d0, [x0, #0xa7]
    // 0xc06ad8: ldur            x1, [fp, #-0x10]
    // 0xc06adc: r0 = textScaleFactor=()
    //     0xc06adc: bl              #0xc06b24  ; [package:flutter/src/painting/text_painter.dart] TextPainter::textScaleFactor=
    // 0xc06ae0: ldur            x1, [fp, #-0x10]
    // 0xc06ae4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xc06ae4: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xc06ae8: r0 = layout()
    //     0xc06ae8: bl              #0x86018c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::layout
    // 0xc06aec: b               #0xc06b04
    // 0xc06af0: mov             x0, x1
    // 0xc06af4: LoadField: r1 = r0->field_63
    //     0xc06af4: ldur            w1, [x0, #0x63]
    // 0xc06af8: DecompressPointer r1
    //     0xc06af8: add             x1, x1, HEAP, lsl #32
    // 0xc06afc: r2 = Null
    //     0xc06afc: mov             x2, NULL
    // 0xc06b00: r0 = text=()
    //     0xc06b00: bl              #0xb1d2b8  ; [package:flutter/src/painting/text_painter.dart] TextPainter::text=
    // 0xc06b04: ldur            x1, [fp, #-0x20]
    // 0xc06b08: r0 = markNeedsLayout()
    //     0xc06b08: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xc06b0c: r0 = Null
    //     0xc06b0c: mov             x0, NULL
    // 0xc06b10: LeaveFrame
    //     0xc06b10: mov             SP, fp
    //     0xc06b14: ldp             fp, lr, [SP], #0x10
    // 0xc06b18: ret
    //     0xc06b18: ret             
    // 0xc06b1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc06b1c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc06b20: b               #0xc06a5c
  }
  _ detach(/* No info */) {
    // ** addr: 0xc06c78, size: 0x114
    // 0xc06c78: EnterFrame
    //     0xc06c78: stp             fp, lr, [SP, #-0x10]!
    //     0xc06c7c: mov             fp, SP
    // 0xc06c80: AllocStack(0x10)
    //     0xc06c80: sub             SP, SP, #0x10
    // 0xc06c84: SetupParameters(_RenderSlider this /* r1 => r0, fp-0x10 */)
    //     0xc06c84: mov             x0, x1
    //     0xc06c88: stur            x1, [fp, #-0x10]
    // 0xc06c8c: CheckStackOverflow
    //     0xc06c8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc06c90: cmp             SP, x16
    //     0xc06c94: b.ls            #0xc06d54
    // 0xc06c98: LoadField: r3 = r0->field_57
    //     0xc06c98: ldur            w3, [x0, #0x57]
    // 0xc06c9c: DecompressPointer r3
    //     0xc06c9c: add             x3, x3, HEAP, lsl #32
    // 0xc06ca0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc06ca4: cmp             w3, w16
    // 0xc06ca8: b.eq            #0xc06d5c
    // 0xc06cac: mov             x2, x0
    // 0xc06cb0: stur            x3, [fp, #-8]
    // 0xc06cb4: r1 = Function 'markNeedsPaint':.
    //     0xc06cb4: add             x1, PP, #0x90, lsl #12  ; [pp+0x901f0] AnonymousClosure: (0xbf0a50), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0xbf0858)
    //     0xc06cb8: ldr             x1, [x1, #0x1f0]
    // 0xc06cbc: r0 = AllocateClosure()
    //     0xc06cbc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc06cc0: ldur            x1, [fp, #-8]
    // 0xc06cc4: mov             x2, x0
    // 0xc06cc8: stur            x0, [fp, #-8]
    // 0xc06ccc: r0 = removeListener()
    //     0xc06ccc: bl              #0xd00b50  ; [dart:mixin_deduplication] _MixinApplication113&Animation&AnimationWithParentMixin::removeListener
    // 0xc06cd0: ldur            x0, [fp, #-0x10]
    // 0xc06cd4: LoadField: r1 = r0->field_5b
    //     0xc06cd4: ldur            w1, [x0, #0x5b]
    // 0xc06cd8: DecompressPointer r1
    //     0xc06cd8: add             x1, x1, HEAP, lsl #32
    // 0xc06cdc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc06ce0: cmp             w1, w16
    // 0xc06ce4: b.eq            #0xc06d68
    // 0xc06ce8: ldur            x2, [fp, #-8]
    // 0xc06cec: r0 = removeListener()
    //     0xc06cec: bl              #0xd00b50  ; [dart:mixin_deduplication] _MixinApplication113&Animation&AnimationWithParentMixin::removeListener
    // 0xc06cf0: ldur            x0, [fp, #-0x10]
    // 0xc06cf4: LoadField: r1 = r0->field_5f
    //     0xc06cf4: ldur            w1, [x0, #0x5f]
    // 0xc06cf8: DecompressPointer r1
    //     0xc06cf8: add             x1, x1, HEAP, lsl #32
    // 0xc06cfc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc06d00: cmp             w1, w16
    // 0xc06d04: b.eq            #0xc06d74
    // 0xc06d08: ldur            x2, [fp, #-8]
    // 0xc06d0c: r0 = removeListener()
    //     0xc06d0c: bl              #0xd00b50  ; [dart:mixin_deduplication] _MixinApplication113&Animation&AnimationWithParentMixin::removeListener
    // 0xc06d10: ldur            x0, [fp, #-0x10]
    // 0xc06d14: LoadField: r1 = r0->field_53
    //     0xc06d14: ldur            w1, [x0, #0x53]
    // 0xc06d18: DecompressPointer r1
    //     0xc06d18: add             x1, x1, HEAP, lsl #32
    // 0xc06d1c: LoadField: r2 = r1->field_27
    //     0xc06d1c: ldur            w2, [x1, #0x27]
    // 0xc06d20: DecompressPointer r2
    //     0xc06d20: add             x2, x2, HEAP, lsl #32
    // 0xc06d24: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc06d28: cmp             w2, w16
    // 0xc06d2c: b.eq            #0xc06d80
    // 0xc06d30: mov             x1, x2
    // 0xc06d34: ldur            x2, [fp, #-8]
    // 0xc06d38: r0 = removeListener()
    //     0xc06d38: bl              #0xd00c74  ; [dart:mixin_deduplication] _MixinApplication455&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::removeListener
    // 0xc06d3c: ldur            x1, [fp, #-0x10]
    // 0xc06d40: r0 = detach()
    //     0xc06d40: bl              #0xc067fc  ; [dart:mixin_deduplication] _MixinApplication95&RenderBox&RelayoutWhenSystemFontsChangeMixin::detach
    // 0xc06d44: r0 = Null
    //     0xc06d44: mov             x0, NULL
    // 0xc06d48: LeaveFrame
    //     0xc06d48: mov             SP, fp
    //     0xc06d4c: ldp             fp, lr, [SP], #0x10
    // 0xc06d50: ret
    //     0xc06d50: ret             
    // 0xc06d54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc06d54: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc06d58: b               #0xc06c98
    // 0xc06d5c: r9 = _overlayAnimation
    //     0xc06d5c: add             x9, PP, #0xad, lsl #12  ; [pp+0xad768] Field <_RenderSlider@125231897._overlayAnimation@125231897>: late (offset: 0x58)
    //     0xc06d60: ldr             x9, [x9, #0x768]
    // 0xc06d64: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc06d64: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xc06d68: r9 = _valueIndicatorAnimation
    //     0xc06d68: add             x9, PP, #0xad, lsl #12  ; [pp+0xad770] Field <_RenderSlider@125231897._valueIndicatorAnimation@125231897>: late (offset: 0x5c)
    //     0xc06d6c: ldr             x9, [x9, #0x770]
    // 0xc06d70: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc06d70: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xc06d74: r9 = _enableAnimation
    //     0xc06d74: add             x9, PP, #0xad, lsl #12  ; [pp+0xad760] Field <_RenderSlider@125231897._enableAnimation@125231897>: late (offset: 0x60)
    //     0xc06d78: ldr             x9, [x9, #0x760]
    // 0xc06d7c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc06d7c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xc06d80: r9 = positionController
    //     0xc06d80: add             x9, PP, #0x99, lsl #12  ; [pp+0x99018] Field <_SliderState@125231897.positionController>: late (offset: 0x28)
    //     0xc06d84: ldr             x9, [x9, #0x18]
    // 0xc06d88: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc06d88: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ attach(/* No info */) {
    // ** addr: 0xc0a580, size: 0x118
    // 0xc0a580: EnterFrame
    //     0xc0a580: stp             fp, lr, [SP, #-0x10]!
    //     0xc0a584: mov             fp, SP
    // 0xc0a588: AllocStack(0x10)
    //     0xc0a588: sub             SP, SP, #0x10
    // 0xc0a58c: SetupParameters(_RenderSlider this /* r1 => r0, fp-0x8 */)
    //     0xc0a58c: mov             x0, x1
    //     0xc0a590: stur            x1, [fp, #-8]
    // 0xc0a594: CheckStackOverflow
    //     0xc0a594: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc0a598: cmp             SP, x16
    //     0xc0a59c: b.ls            #0xc0a660
    // 0xc0a5a0: mov             x1, x0
    // 0xc0a5a4: r0 = attach()
    //     0xc0a5a4: bl              #0xc0a3a4  ; [dart:mixin_deduplication] _MixinApplication95&RenderBox&RelayoutWhenSystemFontsChangeMixin::attach
    // 0xc0a5a8: ldur            x0, [fp, #-8]
    // 0xc0a5ac: LoadField: r3 = r0->field_57
    //     0xc0a5ac: ldur            w3, [x0, #0x57]
    // 0xc0a5b0: DecompressPointer r3
    //     0xc0a5b0: add             x3, x3, HEAP, lsl #32
    // 0xc0a5b4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc0a5b8: cmp             w3, w16
    // 0xc0a5bc: b.eq            #0xc0a668
    // 0xc0a5c0: mov             x2, x0
    // 0xc0a5c4: stur            x3, [fp, #-0x10]
    // 0xc0a5c8: r1 = Function 'markNeedsPaint':.
    //     0xc0a5c8: add             x1, PP, #0x90, lsl #12  ; [pp+0x901f0] AnonymousClosure: (0xbf0a50), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0xbf0858)
    //     0xc0a5cc: ldr             x1, [x1, #0x1f0]
    // 0xc0a5d0: r0 = AllocateClosure()
    //     0xc0a5d0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc0a5d4: ldur            x1, [fp, #-0x10]
    // 0xc0a5d8: mov             x2, x0
    // 0xc0a5dc: stur            x0, [fp, #-0x10]
    // 0xc0a5e0: r0 = addListener()
    //     0xc0a5e0: bl              #0xd04330  ; [dart:mixin_deduplication] _MixinApplication113&Animation&AnimationWithParentMixin::addListener
    // 0xc0a5e4: ldur            x0, [fp, #-8]
    // 0xc0a5e8: LoadField: r1 = r0->field_5b
    //     0xc0a5e8: ldur            w1, [x0, #0x5b]
    // 0xc0a5ec: DecompressPointer r1
    //     0xc0a5ec: add             x1, x1, HEAP, lsl #32
    // 0xc0a5f0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc0a5f4: cmp             w1, w16
    // 0xc0a5f8: b.eq            #0xc0a674
    // 0xc0a5fc: ldur            x2, [fp, #-0x10]
    // 0xc0a600: r0 = addListener()
    //     0xc0a600: bl              #0xd04330  ; [dart:mixin_deduplication] _MixinApplication113&Animation&AnimationWithParentMixin::addListener
    // 0xc0a604: ldur            x0, [fp, #-8]
    // 0xc0a608: LoadField: r1 = r0->field_5f
    //     0xc0a608: ldur            w1, [x0, #0x5f]
    // 0xc0a60c: DecompressPointer r1
    //     0xc0a60c: add             x1, x1, HEAP, lsl #32
    // 0xc0a610: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc0a614: cmp             w1, w16
    // 0xc0a618: b.eq            #0xc0a680
    // 0xc0a61c: ldur            x2, [fp, #-0x10]
    // 0xc0a620: r0 = addListener()
    //     0xc0a620: bl              #0xd04330  ; [dart:mixin_deduplication] _MixinApplication113&Animation&AnimationWithParentMixin::addListener
    // 0xc0a624: ldur            x0, [fp, #-8]
    // 0xc0a628: LoadField: r1 = r0->field_53
    //     0xc0a628: ldur            w1, [x0, #0x53]
    // 0xc0a62c: DecompressPointer r1
    //     0xc0a62c: add             x1, x1, HEAP, lsl #32
    // 0xc0a630: LoadField: r0 = r1->field_27
    //     0xc0a630: ldur            w0, [x1, #0x27]
    // 0xc0a634: DecompressPointer r0
    //     0xc0a634: add             x0, x0, HEAP, lsl #32
    // 0xc0a638: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc0a63c: cmp             w0, w16
    // 0xc0a640: b.eq            #0xc0a68c
    // 0xc0a644: mov             x1, x0
    // 0xc0a648: ldur            x2, [fp, #-0x10]
    // 0xc0a64c: r0 = addListener()
    //     0xc0a64c: bl              #0xd0440c  ; [dart:mixin_deduplication] _MixinApplication455&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::addListener
    // 0xc0a650: r0 = Null
    //     0xc0a650: mov             x0, NULL
    // 0xc0a654: LeaveFrame
    //     0xc0a654: mov             SP, fp
    //     0xc0a658: ldp             fp, lr, [SP], #0x10
    // 0xc0a65c: ret
    //     0xc0a65c: ret             
    // 0xc0a660: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc0a660: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc0a664: b               #0xc0a5a0
    // 0xc0a668: r9 = _overlayAnimation
    //     0xc0a668: add             x9, PP, #0xad, lsl #12  ; [pp+0xad768] Field <_RenderSlider@125231897._overlayAnimation@125231897>: late (offset: 0x58)
    //     0xc0a66c: ldr             x9, [x9, #0x768]
    // 0xc0a670: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc0a670: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xc0a674: r9 = _valueIndicatorAnimation
    //     0xc0a674: add             x9, PP, #0xad, lsl #12  ; [pp+0xad770] Field <_RenderSlider@125231897._valueIndicatorAnimation@125231897>: late (offset: 0x5c)
    //     0xc0a678: ldr             x9, [x9, #0x770]
    // 0xc0a67c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc0a67c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xc0a680: r9 = _enableAnimation
    //     0xc0a680: add             x9, PP, #0xad, lsl #12  ; [pp+0xad760] Field <_RenderSlider@125231897._enableAnimation@125231897>: late (offset: 0x60)
    //     0xc0a684: ldr             x9, [x9, #0x760]
    // 0xc0a688: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc0a688: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xc0a68c: r9 = positionController
    //     0xc0a68c: add             x9, PP, #0x99, lsl #12  ; [pp+0x99018] Field <_SliderState@125231897.positionController>: late (offset: 0x28)
    //     0xc0a690: ldr             x9, [x9, #0x18]
    // 0xc0a694: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc0a694: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ assembleSemanticsNode(/* No info */) {
    // ** addr: 0xc12278, size: 0x80
    // 0xc12278: EnterFrame
    //     0xc12278: stp             fp, lr, [SP, #-0x10]!
    //     0xc1227c: mov             fp, SP
    // 0xc12280: AllocStack(0x18)
    //     0xc12280: sub             SP, SP, #0x18
    // 0xc12284: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */, dynamic _ /* r3 => r2, fp-0x10 */)
    //     0xc12284: mov             x0, x2
    //     0xc12288: stur            x2, [fp, #-8]
    //     0xc1228c: mov             x2, x3
    //     0xc12290: stur            x3, [fp, #-0x10]
    // 0xc12294: CheckStackOverflow
    //     0xc12294: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc12298: cmp             SP, x16
    //     0xc1229c: b.ls            #0xc122f0
    // 0xc122a0: r0 = _semanticThumbCenter()
    //     0xc122a0: bl              #0xc122f8  ; [package:flutter/src/material/slider.dart] _RenderSlider::_semanticThumbCenter
    // 0xc122a4: stur            x0, [fp, #-0x18]
    // 0xc122a8: r0 = Rect()
    //     0xc122a8: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0xc122ac: mov             x1, x0
    // 0xc122b0: ldur            x2, [fp, #-0x18]
    // 0xc122b4: d0 = 48.000000
    //     0xc122b4: ldr             d0, [PP, #0x5650]  ; [pp+0x5650] IMM: double(48) from 0x4048000000000000
    // 0xc122b8: d1 = 48.000000
    //     0xc122b8: ldr             d1, [PP, #0x5650]  ; [pp+0x5650] IMM: double(48) from 0x4048000000000000
    // 0xc122bc: stur            x0, [fp, #-0x18]
    // 0xc122c0: r0 = Rect.fromCenter()
    //     0xc122c0: bl              #0x86ddc8  ; [dart:ui] Rect::Rect.fromCenter
    // 0xc122c4: ldur            x1, [fp, #-8]
    // 0xc122c8: ldur            x2, [fp, #-0x18]
    // 0xc122cc: r0 = rect=()
    //     0xc122cc: bl              #0x892bd8  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::rect=
    // 0xc122d0: ldur            x1, [fp, #-8]
    // 0xc122d4: ldur            x2, [fp, #-0x10]
    // 0xc122d8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xc122d8: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xc122dc: r0 = updateWith()
    //     0xc122dc: bl              #0x88e2a8  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::updateWith
    // 0xc122e0: r0 = Null
    //     0xc122e0: mov             x0, NULL
    // 0xc122e4: LeaveFrame
    //     0xc122e4: mov             SP, fp
    //     0xc122e8: ldp             fp, lr, [SP], #0x10
    // 0xc122ec: ret
    //     0xc122ec: ret             
    // 0xc122f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc122f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc122f4: b               #0xc122a0
  }
  get _ _semanticThumbCenter(/* No info */) {
    // ** addr: 0xc122f8, size: 0x9c
    // 0xc122f8: EnterFrame
    //     0xc122f8: stp             fp, lr, [SP, #-0x10]!
    //     0xc122fc: mov             fp, SP
    // 0xc12300: AllocStack(0x10)
    //     0xc12300: sub             SP, SP, #0x10
    // 0xc12304: SetupParameters(_RenderSlider this /* r1 => r0, fp-0x8 */)
    //     0xc12304: mov             x0, x1
    //     0xc12308: stur            x1, [fp, #-8]
    // 0xc1230c: CheckStackOverflow
    //     0xc1230c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc12310: cmp             SP, x16
    //     0xc12314: b.ls            #0xc12388
    // 0xc12318: LoadField: r1 = r0->field_bf
    //     0xc12318: ldur            w1, [x0, #0xbf]
    // 0xc1231c: DecompressPointer r1
    //     0xc1231c: add             x1, x1, HEAP, lsl #32
    // 0xc12320: LoadField: r2 = r1->field_7
    //     0xc12320: ldur            x2, [x1, #7]
    // 0xc12324: cmp             x2, #0
    // 0xc12328: b.gt            #0xc12340
    // 0xc1232c: d0 = 1.000000
    //     0xc1232c: fmov            d0, #1.00000000
    // 0xc12330: LoadField: d1 = r0->field_83
    //     0xc12330: ldur            d1, [x0, #0x83]
    // 0xc12334: fsub            d2, d0, d1
    // 0xc12338: mov             v0.16b, v2.16b
    // 0xc1233c: b               #0xc12344
    // 0xc12340: LoadField: d0 = r0->field_83
    //     0xc12340: ldur            d0, [x0, #0x83]
    // 0xc12344: stur            d0, [fp, #-0x10]
    // 0xc12348: LoadField: r3 = r0->field_a3
    //     0xc12348: ldur            w3, [x0, #0xa3]
    // 0xc1234c: DecompressPointer r3
    //     0xc1234c: add             x3, x3, HEAP, lsl #32
    // 0xc12350: LoadField: r1 = r3->field_57
    //     0xc12350: ldur            w1, [x3, #0x57]
    // 0xc12354: DecompressPointer r1
    //     0xc12354: add             x1, x1, HEAP, lsl #32
    // 0xc12358: cmp             w1, NULL
    // 0xc1235c: b.eq            #0xc12390
    // 0xc12360: mov             x2, x0
    // 0xc12364: r4 = const [0, 0x3, 0, 0x3, null]
    //     0xc12364: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0xc12368: r0 = getPreferredRect()
    //     0xc12368: bl              #0xc12580  ; [dart:mixin_deduplication] _MixinApplication107&SliderTrackShape&BaseSliderTrackShape::getPreferredRect
    // 0xc1236c: ldur            x1, [fp, #-8]
    // 0xc12370: mov             x2, x0
    // 0xc12374: ldur            d0, [fp, #-0x10]
    // 0xc12378: r0 = _calcThumbCenter()
    //     0xc12378: bl              #0xc123e4  ; [package:flutter/src/material/slider.dart] _RenderSlider::_calcThumbCenter
    // 0xc1237c: LeaveFrame
    //     0xc1237c: mov             SP, fp
    //     0xc12380: ldp             fp, lr, [SP], #0x10
    // 0xc12384: ret
    //     0xc12384: ret             
    // 0xc12388: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc12388: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1238c: b               #0xc12318
    // 0xc12390: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc12390: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  get _ _trackRect(/* No info */) {
    // ** addr: 0xc12394, size: 0x50
    // 0xc12394: EnterFrame
    //     0xc12394: stp             fp, lr, [SP, #-0x10]!
    //     0xc12398: mov             fp, SP
    // 0xc1239c: mov             x2, x1
    // 0xc123a0: CheckStackOverflow
    //     0xc123a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc123a4: cmp             SP, x16
    //     0xc123a8: b.ls            #0xc123d8
    // 0xc123ac: LoadField: r3 = r2->field_a3
    //     0xc123ac: ldur            w3, [x2, #0xa3]
    // 0xc123b0: DecompressPointer r3
    //     0xc123b0: add             x3, x3, HEAP, lsl #32
    // 0xc123b4: LoadField: r1 = r3->field_57
    //     0xc123b4: ldur            w1, [x3, #0x57]
    // 0xc123b8: DecompressPointer r1
    //     0xc123b8: add             x1, x1, HEAP, lsl #32
    // 0xc123bc: cmp             w1, NULL
    // 0xc123c0: b.eq            #0xc123e0
    // 0xc123c4: r4 = const [0, 0x3, 0, 0x3, null]
    //     0xc123c4: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0xc123c8: r0 = getPreferredRect()
    //     0xc123c8: bl              #0xc12580  ; [dart:mixin_deduplication] _MixinApplication107&SliderTrackShape&BaseSliderTrackShape::getPreferredRect
    // 0xc123cc: LeaveFrame
    //     0xc123cc: mov             SP, fp
    //     0xc123d0: ldp             fp, lr, [SP], #0x10
    // 0xc123d4: ret
    //     0xc123d4: ret             
    // 0xc123d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc123d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc123dc: b               #0xc123ac
    // 0xc123e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc123e0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _calcThumbCenter(/* No info */) {
    // ** addr: 0xc123e4, size: 0x19c
    // 0xc123e4: EnterFrame
    //     0xc123e4: stp             fp, lr, [SP, #-0x10]!
    //     0xc123e8: mov             fp, SP
    // 0xc123ec: AllocStack(0x28)
    //     0xc123ec: sub             SP, SP, #0x28
    // 0xc123f0: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0xc123f0: mov             x0, x2
    //     0xc123f4: stur            x2, [fp, #-8]
    // 0xc123f8: CheckStackOverflow
    //     0xc123f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc123fc: cmp             SP, x16
    //     0xc12400: b.ls            #0xc12570
    // 0xc12404: LoadField: r2 = r1->field_a3
    //     0xc12404: ldur            w2, [x1, #0xa3]
    // 0xc12408: DecompressPointer r2
    //     0xc12408: add             x2, x2, HEAP, lsl #32
    // 0xc1240c: LoadField: r3 = r2->field_57
    //     0xc1240c: ldur            w3, [x2, #0x57]
    // 0xc12410: DecompressPointer r3
    //     0xc12410: add             x3, x3, HEAP, lsl #32
    // 0xc12414: cmp             w3, NULL
    // 0xc12418: b.eq            #0xc12578
    // 0xc1241c: LoadField: d1 = r0->field_1f
    //     0xc1241c: ldur            d1, [x0, #0x1f]
    // 0xc12420: LoadField: d2 = r0->field_f
    //     0xc12420: ldur            d2, [x0, #0xf]
    // 0xc12424: fsub            d3, d1, d2
    // 0xc12428: stur            d3, [fp, #-0x28]
    // 0xc1242c: LoadField: r3 = r1->field_97
    //     0xc1242c: ldur            x3, [x1, #0x97]
    // 0xc12430: cmp             x3, #0
    // 0xc12434: b.le            #0xc12468
    // 0xc12438: d1 = 2.000000
    //     0xc12438: fmov            d1, #2.00000000
    // 0xc1243c: LoadField: d2 = r0->field_7
    //     0xc1243c: ldur            d2, [x0, #7]
    // 0xc12440: ArrayLoad: d4 = r0[0]  ; List_8
    //     0xc12440: ldur            d4, [x0, #0x17]
    // 0xc12444: fsub            d5, d4, d2
    // 0xc12448: fsub            d6, d5, d3
    // 0xc1244c: fmul            d5, d0, d6
    // 0xc12450: fadd            d0, d2, d5
    // 0xc12454: fdiv            d5, d3, d1
    // 0xc12458: fadd            d6, d0, d5
    // 0xc1245c: mov             v0.16b, v4.16b
    // 0xc12460: mov             v4.16b, v6.16b
    // 0xc12464: b               #0xc1248c
    // 0xc12468: d1 = 2.000000
    //     0xc12468: fmov            d1, #2.00000000
    // 0xc1246c: LoadField: d2 = r0->field_7
    //     0xc1246c: ldur            d2, [x0, #7]
    // 0xc12470: ArrayLoad: d4 = r0[0]  ; List_8
    //     0xc12470: ldur            d4, [x0, #0x17]
    // 0xc12474: fsub            d5, d4, d2
    // 0xc12478: fmul            d6, d0, d5
    // 0xc1247c: fadd            d0, d2, d6
    // 0xc12480: mov             v31.16b, v4.16b
    // 0xc12484: mov             v4.16b, v0.16b
    // 0xc12488: mov             v0.16b, v31.16b
    // 0xc1248c: stur            d4, [fp, #-0x10]
    // 0xc12490: stur            d2, [fp, #-0x18]
    // 0xc12494: stur            d0, [fp, #-0x20]
    // 0xc12498: LoadField: r3 = r2->field_53
    //     0xc12498: ldur            w3, [x2, #0x53]
    // 0xc1249c: DecompressPointer r3
    //     0xc1249c: add             x3, x3, HEAP, lsl #32
    // 0xc124a0: cmp             w3, NULL
    // 0xc124a4: b.eq            #0xc1257c
    // 0xc124a8: LoadField: r2 = r1->field_b3
    //     0xc124a8: ldur            w2, [x1, #0xb3]
    // 0xc124ac: DecompressPointer r2
    //     0xc124ac: add             x2, x2, HEAP, lsl #32
    // 0xc124b0: cmp             w2, NULL
    // 0xc124b4: r16 = true
    //     0xc124b4: add             x16, NULL, #0x20  ; true
    // 0xc124b8: r17 = false
    //     0xc124b8: add             x17, NULL, #0x30  ; false
    // 0xc124bc: csel            x1, x16, x17, ne
    // 0xc124c0: mov             x2, x1
    // 0xc124c4: mov             x1, x3
    // 0xc124c8: r0 = getPreferredSize()
    //     0xc124c8: bl              #0xb1e464  ; [package:flutter/src/material/slider_parts.dart] RoundSliderThumbShape::getPreferredSize
    // 0xc124cc: LoadField: d0 = r0->field_7
    //     0xc124cc: ldur            d0, [x0, #7]
    // 0xc124d0: d1 = 2.000000
    //     0xc124d0: fmov            d1, #2.00000000
    // 0xc124d4: fdiv            d2, d0, d1
    // 0xc124d8: ldur            d0, [fp, #-0x28]
    // 0xc124dc: fcmp            d0, d2
    // 0xc124e0: b.le            #0xc124f0
    // 0xc124e4: fdiv            d2, d0, d1
    // 0xc124e8: mov             v3.16b, v2.16b
    // 0xc124ec: b               #0xc124f4
    // 0xc124f0: d3 = 0.000000
    //     0xc124f0: eor             v3.16b, v3.16b, v3.16b
    // 0xc124f4: ldur            d2, [fp, #-0x10]
    // 0xc124f8: ldur            d1, [fp, #-0x18]
    // 0xc124fc: ldur            d0, [fp, #-0x20]
    // 0xc12500: fadd            d4, d1, d3
    // 0xc12504: fsub            d1, d0, d3
    // 0xc12508: fcmp            d4, d2
    // 0xc1250c: b.le            #0xc12518
    // 0xc12510: mov             v0.16b, v4.16b
    // 0xc12514: b               #0xc1253c
    // 0xc12518: fcmp            d2, d1
    // 0xc1251c: b.le            #0xc12528
    // 0xc12520: mov             v0.16b, v1.16b
    // 0xc12524: b               #0xc1253c
    // 0xc12528: fcmp            d2, d2
    // 0xc1252c: b.vc            #0xc12538
    // 0xc12530: mov             v0.16b, v1.16b
    // 0xc12534: b               #0xc1253c
    // 0xc12538: mov             v0.16b, v2.16b
    // 0xc1253c: ldur            x1, [fp, #-8]
    // 0xc12540: stur            d0, [fp, #-0x10]
    // 0xc12544: r0 = center()
    //     0xc12544: bl              #0x869350  ; [dart:ui] Rect::center
    // 0xc12548: LoadField: d0 = r0->field_f
    //     0xc12548: ldur            d0, [x0, #0xf]
    // 0xc1254c: stur            d0, [fp, #-0x18]
    // 0xc12550: r0 = Offset()
    //     0xc12550: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xc12554: ldur            d0, [fp, #-0x10]
    // 0xc12558: StoreField: r0->field_7 = d0
    //     0xc12558: stur            d0, [x0, #7]
    // 0xc1255c: ldur            d0, [fp, #-0x18]
    // 0xc12560: StoreField: r0->field_f = d0
    //     0xc12560: stur            d0, [x0, #0xf]
    // 0xc12564: LeaveFrame
    //     0xc12564: mov             SP, fp
    //     0xc12568: ldp             fp, lr, [SP], #0x10
    // 0xc1256c: ret
    //     0xc1256c: ret             
    // 0xc12570: r0 = StackOverflowSharedWithFPURegs()
    //     0xc12570: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xc12574: b               #0xc12404
    // 0xc12578: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc12578: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xc1257c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc1257c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  _ paint(/* No info */) {
    // ** addr: 0xc23664, size: 0x760
    // 0xc23664: EnterFrame
    //     0xc23664: stp             fp, lr, [SP, #-0x10]!
    //     0xc23668: mov             fp, SP
    // 0xc2366c: AllocStack(0xa8)
    //     0xc2366c: sub             SP, SP, #0xa8
    // 0xc23670: SetupParameters(_RenderSlider this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xc23670: mov             x0, x1
    //     0xc23674: stur            x1, [fp, #-8]
    //     0xc23678: stur            x2, [fp, #-0x10]
    //     0xc2367c: stur            x3, [fp, #-0x18]
    // 0xc23680: CheckStackOverflow
    //     0xc23680: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc23684: cmp             SP, x16
    //     0xc23688: b.ls            #0xc23d30
    // 0xc2368c: r1 = 2
    //     0xc2368c: mov             x1, #2
    // 0xc23690: r0 = AllocateContext()
    //     0xc23690: bl              #0x13de838  ; AllocateContextStub
    // 0xc23694: mov             x1, x0
    // 0xc23698: ldur            x0, [fp, #-8]
    // 0xc2369c: stur            x1, [fp, #-0x28]
    // 0xc236a0: StoreField: r1->field_f = r0
    //     0xc236a0: stur            w0, [x1, #0xf]
    // 0xc236a4: LoadField: r4 = r0->field_53
    //     0xc236a4: ldur            w4, [x0, #0x53]
    // 0xc236a8: DecompressPointer r4
    //     0xc236a8: add             x4, x4, HEAP, lsl #32
    // 0xc236ac: stur            x4, [fp, #-0x20]
    // 0xc236b0: LoadField: r2 = r4->field_27
    //     0xc236b0: ldur            w2, [x4, #0x27]
    // 0xc236b4: DecompressPointer r2
    //     0xc236b4: add             x2, x2, HEAP, lsl #32
    // 0xc236b8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc236bc: cmp             w2, w16
    // 0xc236c0: b.eq            #0xc23d38
    // 0xc236c4: LoadField: r3 = r2->field_37
    //     0xc236c4: ldur            w3, [x2, #0x37]
    // 0xc236c8: DecompressPointer r3
    //     0xc236c8: add             x3, x3, HEAP, lsl #32
    // 0xc236cc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc236d0: cmp             w3, w16
    // 0xc236d4: b.eq            #0xc23d44
    // 0xc236d8: LoadField: r2 = r0->field_bf
    //     0xc236d8: ldur            w2, [x0, #0xbf]
    // 0xc236dc: DecompressPointer r2
    //     0xc236dc: add             x2, x2, HEAP, lsl #32
    // 0xc236e0: r16 = Instance_TextDirection
    //     0xc236e0: ldr             x16, [PP, #0x2578]  ; [pp+0x2578] Obj!TextDirection@12c7381
    // 0xc236e4: cmp             w2, w16
    // 0xc236e8: b.ne            #0xc23734
    // 0xc236ec: d0 = 1.000000
    //     0xc236ec: fmov            d0, #1.00000000
    // 0xc236f0: LoadField: d1 = r3->field_7
    //     0xc236f0: ldur            d1, [x3, #7]
    // 0xc236f4: fsub            d2, d0, d1
    // 0xc236f8: r2 = inline_Allocate_Double()
    //     0xc236f8: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xc236fc: add             x2, x2, #0x10
    //     0xc23700: cmp             x3, x2
    //     0xc23704: b.ls            #0xc23d4c
    //     0xc23708: str             x2, [THR, #0x60]  ; THR::top
    //     0xc2370c: sub             x2, x2, #0xf
    //     0xc23710: mov             x3, #0xe19c
    //     0xc23714: movk            x3, #3, lsl #16
    //     0xc23718: stur            x3, [x2, #-1]
    // 0xc2371c: dmb             ishst
    // 0xc23720: StoreField: r2->field_7 = d2
    //     0xc23720: stur            d2, [x2, #7]
    // 0xc23724: r3 = Null
    //     0xc23724: mov             x3, NULL
    // 0xc23728: r0 = AllocateRecord2()
    //     0xc23728: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xc2372c: mov             x1, x0
    // 0xc23730: b               #0xc23758
    // 0xc23734: r16 = Instance_TextDirection
    //     0xc23734: ldr             x16, [PP, #0x25b0]  ; [pp+0x25b0] Obj!TextDirection@12c73a1
    // 0xc23738: cmp             w2, w16
    // 0xc2373c: b.ne            #0xc23754
    // 0xc23740: mov             x2, x3
    // 0xc23744: r3 = Null
    //     0xc23744: mov             x3, NULL
    // 0xc23748: r0 = AllocateRecord2()
    //     0xc23748: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xc2374c: mov             x1, x0
    // 0xc23750: b               #0xc23758
    // 0xc23754: r1 = Null
    //     0xc23754: mov             x1, NULL
    // 0xc23758: ldur            x0, [fp, #-8]
    // 0xc2375c: ldur            x4, [fp, #-0x28]
    // 0xc23760: LoadField: r5 = r1->field_f
    //     0xc23760: ldur            w5, [x1, #0xf]
    // 0xc23764: DecompressPointer r5
    //     0xc23764: add             x5, x5, HEAP, lsl #32
    // 0xc23768: stur            x5, [fp, #-0x38]
    // 0xc2376c: LoadField: r6 = r1->field_13
    //     0xc2376c: ldur            w6, [x1, #0x13]
    // 0xc23770: DecompressPointer r6
    //     0xc23770: add             x6, x6, HEAP, lsl #32
    // 0xc23774: stur            x6, [fp, #-0x30]
    // 0xc23778: LoadField: r3 = r0->field_a3
    //     0xc23778: ldur            w3, [x0, #0xa3]
    // 0xc2377c: DecompressPointer r3
    //     0xc2377c: add             x3, x3, HEAP, lsl #32
    // 0xc23780: LoadField: r1 = r3->field_57
    //     0xc23780: ldur            w1, [x3, #0x57]
    // 0xc23784: DecompressPointer r1
    //     0xc23784: add             x1, x1, HEAP, lsl #32
    // 0xc23788: cmp             w1, NULL
    // 0xc2378c: b.eq            #0xc23d70
    // 0xc23790: ldur            x16, [fp, #-0x18]
    // 0xc23794: str             x16, [SP]
    // 0xc23798: mov             x2, x0
    // 0xc2379c: r4 = const [0, 0x4, 0x1, 0x3, offset, 0x3, null]
    //     0xc2379c: add             x4, PP, #0xad, lsl #12  ; [pp+0xad750] List(7) [0, 0x4, 0x1, 0x3, "offset", 0x3, Null]
    //     0xc237a0: ldr             x4, [x4, #0x750]
    // 0xc237a4: r0 = getPreferredRect()
    //     0xc237a4: bl              #0xc12580  ; [dart:mixin_deduplication] _MixinApplication107&SliderTrackShape&BaseSliderTrackShape::getPreferredRect
    // 0xc237a8: mov             x3, x0
    // 0xc237ac: ldur            x0, [fp, #-0x38]
    // 0xc237b0: stur            x3, [fp, #-0x40]
    // 0xc237b4: LoadField: d0 = r0->field_7
    //     0xc237b4: ldur            d0, [x0, #7]
    // 0xc237b8: ldur            x1, [fp, #-8]
    // 0xc237bc: mov             x2, x3
    // 0xc237c0: r0 = _calcThumbCenter()
    //     0xc237c0: bl              #0xc123e4  ; [package:flutter/src/material/slider.dart] _RenderSlider::_calcThumbCenter
    // 0xc237c4: mov             x4, x0
    // 0xc237c8: ldur            x3, [fp, #-0x28]
    // 0xc237cc: stur            x4, [fp, #-0x38]
    // 0xc237d0: StoreField: r3->field_13 = r0
    //     0xc237d0: stur            w0, [x3, #0x13]
    //     0xc237d4: ldurb           w16, [x3, #-1]
    //     0xc237d8: ldurb           w17, [x0, #-1]
    //     0xc237dc: and             x16, x17, x16, lsr #2
    //     0xc237e0: tst             x16, HEAP, lsr #32
    //     0xc237e4: b.eq            #0xc237ec
    //     0xc237e8: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xc237ec: ldur            x7, [fp, #-8]
    // 0xc237f0: LoadField: r0 = r7->field_b3
    //     0xc237f0: ldur            w0, [x7, #0xb3]
    // 0xc237f4: DecompressPointer r0
    //     0xc237f4: add             x0, x0, HEAP, lsl #32
    // 0xc237f8: cmp             w0, NULL
    // 0xc237fc: b.eq            #0xc23874
    // 0xc23800: LoadField: r0 = r7->field_a3
    //     0xc23800: ldur            w0, [x7, #0xa3]
    // 0xc23804: DecompressPointer r0
    //     0xc23804: add             x0, x0, HEAP, lsl #32
    // 0xc23808: LoadField: r1 = r0->field_4b
    //     0xc23808: ldur            w1, [x0, #0x4b]
    // 0xc2380c: DecompressPointer r1
    //     0xc2380c: add             x1, x1, HEAP, lsl #32
    // 0xc23810: cmp             w1, NULL
    // 0xc23814: b.eq            #0xc23d74
    // 0xc23818: r2 = true
    //     0xc23818: add             x2, NULL, #0x20  ; true
    // 0xc2381c: r0 = getPreferredSize()
    //     0xc2381c: bl              #0xb1e4f8  ; [package:flutter/src/material/slider_value_indicator_shape.dart] RoundSliderOverlayShape::getPreferredSize
    // 0xc23820: LoadField: d0 = r0->field_7
    //     0xc23820: ldur            d0, [x0, #7]
    // 0xc23824: d1 = 2.000000
    //     0xc23824: fmov            d1, #2.00000000
    // 0xc23828: fdiv            d2, d0, d1
    // 0xc2382c: fmul            d0, d2, d1
    // 0xc23830: stur            d0, [fp, #-0x68]
    // 0xc23834: r0 = Rect()
    //     0xc23834: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0xc23838: mov             x1, x0
    // 0xc2383c: ldur            x2, [fp, #-0x38]
    // 0xc23840: ldur            d0, [fp, #-0x68]
    // 0xc23844: ldur            d1, [fp, #-0x68]
    // 0xc23848: stur            x0, [fp, #-0x48]
    // 0xc2384c: r0 = Rect.fromCenter()
    //     0xc2384c: bl              #0x86ddc8  ; [dart:ui] Rect::Rect.fromCenter
    // 0xc23850: ldur            x0, [fp, #-0x48]
    // 0xc23854: ldur            x7, [fp, #-8]
    // 0xc23858: StoreField: r7->field_7f = r0
    //     0xc23858: stur            w0, [x7, #0x7f]
    //     0xc2385c: ldurb           w16, [x7, #-1]
    //     0xc23860: ldurb           w17, [x0, #-1]
    //     0xc23864: and             x16, x17, x16, lsr #2
    //     0xc23868: tst             x16, HEAP, lsr #32
    //     0xc2386c: b.eq            #0xc23874
    //     0xc23870: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0xc23874: ldur            x0, [fp, #-0x30]
    // 0xc23878: cmp             w0, NULL
    // 0xc2387c: b.eq            #0xc238c8
    // 0xc23880: ldur            x2, [fp, #-0x40]
    // 0xc23884: LoadField: d0 = r2->field_7
    //     0xc23884: ldur            d0, [x2, #7]
    // 0xc23888: ArrayLoad: d1 = r2[0]  ; List_8
    //     0xc23888: ldur            d1, [x2, #0x17]
    // 0xc2388c: fsub            d2, d1, d0
    // 0xc23890: LoadField: d1 = r0->field_7
    //     0xc23890: ldur            d1, [x0, #7]
    // 0xc23894: fmul            d3, d1, d2
    // 0xc23898: fadd            d1, d0, d3
    // 0xc2389c: mov             x1, x2
    // 0xc238a0: stur            d1, [fp, #-0x68]
    // 0xc238a4: r0 = center()
    //     0xc238a4: bl              #0x869350  ; [dart:ui] Rect::center
    // 0xc238a8: LoadField: d0 = r0->field_f
    //     0xc238a8: ldur            d0, [x0, #0xf]
    // 0xc238ac: stur            d0, [fp, #-0x70]
    // 0xc238b0: r0 = Offset()
    //     0xc238b0: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xc238b4: ldur            d0, [fp, #-0x68]
    // 0xc238b8: StoreField: r0->field_7 = d0
    //     0xc238b8: stur            d0, [x0, #7]
    // 0xc238bc: ldur            d0, [fp, #-0x70]
    // 0xc238c0: StoreField: r0->field_f = d0
    //     0xc238c0: stur            d0, [x0, #0xf]
    // 0xc238c4: b               #0xc238cc
    // 0xc238c8: r0 = Null
    //     0xc238c8: mov             x0, NULL
    // 0xc238cc: ldur            x7, [fp, #-8]
    // 0xc238d0: stur            x0, [fp, #-0x48]
    // 0xc238d4: LoadField: r1 = r7->field_a3
    //     0xc238d4: ldur            w1, [x7, #0xa3]
    // 0xc238d8: DecompressPointer r1
    //     0xc238d8: add             x1, x1, HEAP, lsl #32
    // 0xc238dc: LoadField: r2 = r1->field_8f
    //     0xc238dc: ldur            w2, [x1, #0x8f]
    // 0xc238e0: DecompressPointer r2
    //     0xc238e0: add             x2, x2, HEAP, lsl #32
    // 0xc238e4: LoadField: r3 = r1->field_57
    //     0xc238e4: ldur            w3, [x1, #0x57]
    // 0xc238e8: DecompressPointer r3
    //     0xc238e8: add             x3, x3, HEAP, lsl #32
    // 0xc238ec: stur            x3, [fp, #-0x30]
    // 0xc238f0: cmp             w3, NULL
    // 0xc238f4: b.eq            #0xc23d78
    // 0xc238f8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xc238f8: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xc238fc: r0 = copyWith()
    //     0xc238fc: bl              #0xc24850  ; [package:flutter/src/material/slider_theme.dart] SliderThemeData::copyWith
    // 0xc23900: mov             x1, x0
    // 0xc23904: ldur            x0, [fp, #-8]
    // 0xc23908: LoadField: r5 = r0->field_5f
    //     0xc23908: ldur            w5, [x0, #0x5f]
    // 0xc2390c: DecompressPointer r5
    //     0xc2390c: add             x5, x5, HEAP, lsl #32
    // 0xc23910: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc23914: cmp             w5, w16
    // 0xc23918: b.eq            #0xc23d7c
    // 0xc2391c: LoadField: r2 = r0->field_bf
    //     0xc2391c: ldur            w2, [x0, #0xbf]
    // 0xc23920: DecompressPointer r2
    //     0xc23920: add             x2, x2, HEAP, lsl #32
    // 0xc23924: LoadField: r3 = r0->field_b3
    //     0xc23924: ldur            w3, [x0, #0xb3]
    // 0xc23928: DecompressPointer r3
    //     0xc23928: add             x3, x3, HEAP, lsl #32
    // 0xc2392c: cmp             w3, NULL
    // 0xc23930: r16 = true
    //     0xc23930: add             x16, NULL, #0x20  ; true
    // 0xc23934: r17 = false
    //     0xc23934: add             x17, NULL, #0x30  ; false
    // 0xc23938: csel            x6, x16, x17, ne
    // 0xc2393c: ldur            x16, [fp, #-0x48]
    // 0xc23940: stp             x1, x16, [SP, #0x10]
    // 0xc23944: ldur            x16, [fp, #-0x38]
    // 0xc23948: stp             x16, x2, [SP]
    // 0xc2394c: ldur            x1, [fp, #-0x30]
    // 0xc23950: ldur            x2, [fp, #-0x10]
    // 0xc23954: ldur            x3, [fp, #-0x18]
    // 0xc23958: mov             x7, x0
    // 0xc2395c: r0 = paint()
    //     0xc2395c: bl              #0xc2408c  ; [package:flutter/src/material/slider_parts.dart] RoundedRectSliderTrackShape::paint
    // 0xc23960: ldur            x0, [fp, #-8]
    // 0xc23964: LoadField: r1 = r0->field_57
    //     0xc23964: ldur            w1, [x0, #0x57]
    // 0xc23968: DecompressPointer r1
    //     0xc23968: add             x1, x1, HEAP, lsl #32
    // 0xc2396c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc23970: cmp             w1, w16
    // 0xc23974: b.eq            #0xc23d88
    // 0xc23978: r0 = status()
    //     0xc23978: bl              #0x1284c0c  ; [dart:mixin_deduplication] _MixinApplication113&Animation&AnimationWithParentMixin::status
    // 0xc2397c: r16 = Instance_AnimationStatus
    //     0xc2397c: ldr             x16, [PP, #0x51a8]  ; [pp+0x51a8] Obj!AnimationStatus@12c61c1
    // 0xc23980: cmp             w0, w16
    // 0xc23984: b.eq            #0xc23a3c
    // 0xc23988: ldur            x0, [fp, #-8]
    // 0xc2398c: d0 = 0.000000
    //     0xc2398c: eor             v0.16b, v0.16b, v0.16b
    // 0xc23990: LoadField: r2 = r0->field_a3
    //     0xc23990: ldur            w2, [x0, #0xa3]
    // 0xc23994: DecompressPointer r2
    //     0xc23994: add             x2, x2, HEAP, lsl #32
    // 0xc23998: stur            x2, [fp, #-0x58]
    // 0xc2399c: LoadField: r3 = r2->field_4b
    //     0xc2399c: ldur            w3, [x2, #0x4b]
    // 0xc239a0: DecompressPointer r3
    //     0xc239a0: add             x3, x3, HEAP, lsl #32
    // 0xc239a4: stur            x3, [fp, #-0x50]
    // 0xc239a8: cmp             w3, NULL
    // 0xc239ac: b.eq            #0xc23d94
    // 0xc239b0: LoadField: r5 = r0->field_57
    //     0xc239b0: ldur            w5, [x0, #0x57]
    // 0xc239b4: DecompressPointer r5
    //     0xc239b4: add             x5, x5, HEAP, lsl #32
    // 0xc239b8: stur            x5, [fp, #-0x48]
    // 0xc239bc: LoadField: r6 = r0->field_5f
    //     0xc239bc: ldur            w6, [x0, #0x5f]
    // 0xc239c0: DecompressPointer r6
    //     0xc239c0: add             x6, x6, HEAP, lsl #32
    // 0xc239c4: stur            x6, [fp, #-0x30]
    // 0xc239c8: LoadField: r7 = r0->field_63
    //     0xc239c8: ldur            w7, [x0, #0x63]
    // 0xc239cc: DecompressPointer r7
    //     0xc239cc: add             x7, x7, HEAP, lsl #32
    // 0xc239d0: stur            x7, [fp, #-0x18]
    // 0xc239d4: LoadField: d1 = r0->field_a7
    //     0xc239d4: ldur            d1, [x0, #0xa7]
    // 0xc239d8: stur            d1, [fp, #-0x68]
    // 0xc239dc: LoadField: r1 = r0->field_af
    //     0xc239dc: ldur            w1, [x0, #0xaf]
    // 0xc239e0: DecompressPointer r1
    //     0xc239e0: add             x1, x1, HEAP, lsl #32
    // 0xc239e4: LoadField: d2 = r1->field_7
    //     0xc239e4: ldur            d2, [x1, #7]
    // 0xc239e8: fcmp            d0, d2
    // 0xc239ec: b.ge            #0xc239fc
    // 0xc239f0: LoadField: d2 = r1->field_f
    //     0xc239f0: ldur            d2, [x1, #0xf]
    // 0xc239f4: fcmp            d0, d2
    // 0xc239f8: b.lt            #0xc23a08
    // 0xc239fc: mov             x1, x0
    // 0xc23a00: r0 = size()
    //     0xc23a00: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc23a04: b               #0xc23a0c
    // 0xc23a08: mov             x0, x1
    // 0xc23a0c: ldur            x16, [fp, #-8]
    // 0xc23a10: stp             x0, x16, [SP, #8]
    // 0xc23a14: ldur            x16, [fp, #-0x58]
    // 0xc23a18: str             x16, [SP]
    // 0xc23a1c: ldur            x1, [fp, #-0x50]
    // 0xc23a20: ldur            x2, [fp, #-0x10]
    // 0xc23a24: ldur            x3, [fp, #-0x38]
    // 0xc23a28: ldur            x5, [fp, #-0x48]
    // 0xc23a2c: ldur            x6, [fp, #-0x30]
    // 0xc23a30: ldur            x7, [fp, #-0x18]
    // 0xc23a34: ldur            d0, [fp, #-0x68]
    // 0xc23a38: r0 = paint()
    //     0xc23a38: bl              #0x12eb0f0  ; [package:flutter/src/material/slider_value_indicator_shape.dart] RoundSliderOverlayShape::paint
    // 0xc23a3c: ldur            x0, [fp, #-8]
    // 0xc23a40: LoadField: r1 = r0->field_97
    //     0xc23a40: ldur            x1, [x0, #0x97]
    // 0xc23a44: cmp             x1, #0
    // 0xc23a48: b.le            #0xc23b8c
    // 0xc23a4c: ldur            x3, [fp, #-0x40]
    // 0xc23a50: LoadField: r2 = r0->field_a3
    //     0xc23a50: ldur            w2, [x0, #0xa3]
    // 0xc23a54: DecompressPointer r2
    //     0xc23a54: add             x2, x2, HEAP, lsl #32
    // 0xc23a58: LoadField: r1 = r2->field_4f
    //     0xc23a58: ldur            w1, [x2, #0x4f]
    // 0xc23a5c: DecompressPointer r1
    //     0xc23a5c: add             x1, x1, HEAP, lsl #32
    // 0xc23a60: cmp             w1, NULL
    // 0xc23a64: b.eq            #0xc23d98
    // 0xc23a68: r0 = getPreferredSize()
    //     0xc23a68: bl              #0xb1e3f0  ; [package:flutter/src/material/slider_parts.dart] RoundSliderTickMarkShape::getPreferredSize
    // 0xc23a6c: LoadField: d0 = r0->field_7
    //     0xc23a6c: ldur            d0, [x0, #7]
    // 0xc23a70: ldur            x1, [fp, #-0x40]
    // 0xc23a74: LoadField: d1 = r1->field_1f
    //     0xc23a74: ldur            d1, [x1, #0x1f]
    // 0xc23a78: LoadField: d2 = r1->field_f
    //     0xc23a78: ldur            d2, [x1, #0xf]
    // 0xc23a7c: fsub            d3, d1, d2
    // 0xc23a80: stur            d3, [fp, #-0x78]
    // 0xc23a84: ArrayLoad: d1 = r1[0]  ; List_8
    //     0xc23a84: ldur            d1, [x1, #0x17]
    // 0xc23a88: LoadField: d2 = r1->field_7
    //     0xc23a88: ldur            d2, [x1, #7]
    // 0xc23a8c: stur            d2, [fp, #-0x70]
    // 0xc23a90: fsub            d4, d1, d2
    // 0xc23a94: fsub            d1, d4, d3
    // 0xc23a98: ldur            x0, [fp, #-8]
    // 0xc23a9c: stur            d1, [fp, #-0x68]
    // 0xc23aa0: LoadField: r2 = r0->field_97
    //     0xc23aa0: ldur            x2, [x0, #0x97]
    // 0xc23aa4: scvtf           d4, x2
    // 0xc23aa8: fdiv            d5, d1, d4
    // 0xc23aac: d4 = 3.000000
    //     0xc23aac: fmov            d4, #3.00000000
    // 0xc23ab0: fmul            d6, d0, d4
    // 0xc23ab4: fcmp            d5, d6
    // 0xc23ab8: b.lt            #0xc23b8c
    // 0xc23abc: r0 = center()
    //     0xc23abc: bl              #0x869350  ; [dart:ui] Rect::center
    // 0xc23ac0: LoadField: d0 = r0->field_f
    //     0xc23ac0: ldur            d0, [x0, #0xf]
    // 0xc23ac4: ldur            d1, [fp, #-0x78]
    // 0xc23ac8: stur            d0, [fp, #-0x88]
    // 0xc23acc: d2 = 2.000000
    //     0xc23acc: fmov            d2, #2.00000000
    // 0xc23ad0: fdiv            d3, d1, d2
    // 0xc23ad4: stur            d3, [fp, #-0x80]
    // 0xc23ad8: r0 = 0
    //     0xc23ad8: mov             x0, #0
    // 0xc23adc: ldur            x1, [fp, #-8]
    // 0xc23ae0: ldur            d2, [fp, #-0x68]
    // 0xc23ae4: ldur            d1, [fp, #-0x70]
    // 0xc23ae8: stur            x0, [fp, #-0x60]
    // 0xc23aec: CheckStackOverflow
    //     0xc23aec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc23af0: cmp             SP, x16
    //     0xc23af4: b.ls            #0xc23d9c
    // 0xc23af8: LoadField: r2 = r1->field_97
    //     0xc23af8: ldur            x2, [x1, #0x97]
    // 0xc23afc: cmp             x0, x2
    // 0xc23b00: b.gt            #0xc23b8c
    // 0xc23b04: scvtf           d4, x0
    // 0xc23b08: scvtf           d5, x2
    // 0xc23b0c: fdiv            d6, d4, d5
    // 0xc23b10: fmul            d4, d6, d2
    // 0xc23b14: fadd            d5, d1, d4
    // 0xc23b18: fadd            d4, d5, d3
    // 0xc23b1c: stur            d4, [fp, #-0x78]
    // 0xc23b20: r0 = Offset()
    //     0xc23b20: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xc23b24: ldur            d0, [fp, #-0x78]
    // 0xc23b28: StoreField: r0->field_7 = d0
    //     0xc23b28: stur            d0, [x0, #7]
    // 0xc23b2c: ldur            d0, [fp, #-0x88]
    // 0xc23b30: StoreField: r0->field_f = d0
    //     0xc23b30: stur            d0, [x0, #0xf]
    // 0xc23b34: ldur            x4, [fp, #-8]
    // 0xc23b38: LoadField: r6 = r4->field_a3
    //     0xc23b38: ldur            w6, [x4, #0xa3]
    // 0xc23b3c: DecompressPointer r6
    //     0xc23b3c: add             x6, x6, HEAP, lsl #32
    // 0xc23b40: LoadField: r1 = r6->field_4f
    //     0xc23b40: ldur            w1, [x6, #0x4f]
    // 0xc23b44: DecompressPointer r1
    //     0xc23b44: add             x1, x1, HEAP, lsl #32
    // 0xc23b48: cmp             w1, NULL
    // 0xc23b4c: b.eq            #0xc23da4
    // 0xc23b50: LoadField: r5 = r4->field_5f
    //     0xc23b50: ldur            w5, [x4, #0x5f]
    // 0xc23b54: DecompressPointer r5
    //     0xc23b54: add             x5, x5, HEAP, lsl #32
    // 0xc23b58: LoadField: r7 = r4->field_bf
    //     0xc23b58: ldur            w7, [x4, #0xbf]
    // 0xc23b5c: DecompressPointer r7
    //     0xc23b5c: add             x7, x7, HEAP, lsl #32
    // 0xc23b60: ldur            x16, [fp, #-0x38]
    // 0xc23b64: str             x16, [SP]
    // 0xc23b68: ldur            x2, [fp, #-0x10]
    // 0xc23b6c: mov             x3, x0
    // 0xc23b70: r0 = paint()
    //     0xc23b70: bl              #0xc23ec0  ; [package:flutter/src/material/slider_parts.dart] RoundSliderTickMarkShape::paint
    // 0xc23b74: ldur            x0, [fp, #-0x60]
    // 0xc23b78: add             x1, x0, #1
    // 0xc23b7c: mov             x0, x1
    // 0xc23b80: ldur            d3, [fp, #-0x80]
    // 0xc23b84: ldur            d0, [fp, #-0x88]
    // 0xc23b88: b               #0xc23adc
    // 0xc23b8c: ldur            x0, [fp, #-8]
    // 0xc23b90: LoadField: r1 = r0->field_b3
    //     0xc23b90: ldur            w1, [x0, #0xb3]
    // 0xc23b94: DecompressPointer r1
    //     0xc23b94: add             x1, x1, HEAP, lsl #32
    // 0xc23b98: cmp             w1, NULL
    // 0xc23b9c: b.eq            #0xc23c58
    // 0xc23ba0: LoadField: r1 = r0->field_9f
    //     0xc23ba0: ldur            w1, [x0, #0x9f]
    // 0xc23ba4: DecompressPointer r1
    //     0xc23ba4: add             x1, x1, HEAP, lsl #32
    // 0xc23ba8: cmp             w1, NULL
    // 0xc23bac: b.eq            #0xc23c50
    // 0xc23bb0: mov             x1, x0
    // 0xc23bb4: r0 = shouldShowValueIndicatorWhenDragged()
    //     0xc23bb4: bl              #0xc23dc4  ; [package:flutter/src/material/slider.dart] _RenderSlider::shouldShowValueIndicatorWhenDragged
    // 0xc23bb8: tbnz            w0, #4, #0xc23bec
    // 0xc23bbc: ldur            x0, [fp, #-8]
    // 0xc23bc0: LoadField: r1 = r0->field_5b
    //     0xc23bc0: ldur            w1, [x0, #0x5b]
    // 0xc23bc4: DecompressPointer r1
    //     0xc23bc4: add             x1, x1, HEAP, lsl #32
    // 0xc23bc8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc23bcc: cmp             w1, w16
    // 0xc23bd0: b.eq            #0xc23da8
    // 0xc23bd4: r0 = status()
    //     0xc23bd4: bl              #0x1284c0c  ; [dart:mixin_deduplication] _MixinApplication113&Animation&AnimationWithParentMixin::status
    // 0xc23bd8: r16 = Instance_AnimationStatus
    //     0xc23bd8: ldr             x16, [PP, #0x51a8]  ; [pp+0x51a8] Obj!AnimationStatus@12c61c1
    // 0xc23bdc: cmp             w0, w16
    // 0xc23be0: b.eq            #0xc23bec
    // 0xc23be4: ldur            x0, [fp, #-8]
    // 0xc23be8: b               #0xc23c10
    // 0xc23bec: ldur            x0, [fp, #-8]
    // 0xc23bf0: LoadField: r1 = r0->field_a3
    //     0xc23bf0: ldur            w1, [x0, #0xa3]
    // 0xc23bf4: DecompressPointer r1
    //     0xc23bf4: add             x1, x1, HEAP, lsl #32
    // 0xc23bf8: LoadField: r2 = r1->field_6f
    //     0xc23bf8: ldur            w2, [x1, #0x6f]
    // 0xc23bfc: DecompressPointer r2
    //     0xc23bfc: add             x2, x2, HEAP, lsl #32
    // 0xc23c00: r16 = Instance_ShowValueIndicator
    //     0xc23c00: add             x16, PP, #0xa3, lsl #12  ; [pp+0xa3750] Obj!ShowValueIndicator@12c4ea1
    //     0xc23c04: ldr             x16, [x16, #0x750]
    // 0xc23c08: cmp             w2, w16
    // 0xc23c0c: b.ne            #0xc23c48
    // 0xc23c10: ldur            x3, [fp, #-0x20]
    // 0xc23c14: ldur            x2, [fp, #-0x28]
    // 0xc23c18: r1 = Function '<anonymous closure>':.
    //     0xc23c18: add             x1, PP, #0xad, lsl #12  ; [pp+0xad758] AnonymousClosure: (0xc25380), in [package:flutter/src/material/slider.dart] _RenderSlider::paint (0xc23664)
    //     0xc23c1c: ldr             x1, [x1, #0x758]
    // 0xc23c20: r0 = AllocateClosure()
    //     0xc23c20: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc23c24: ldur            x1, [fp, #-0x20]
    // 0xc23c28: StoreField: r1->field_37 = r0
    //     0xc23c28: stur            w0, [x1, #0x37]
    //     0xc23c2c: ldurb           w16, [x1, #-1]
    //     0xc23c30: ldurb           w17, [x0, #-1]
    //     0xc23c34: and             x16, x17, x16, lsr #2
    //     0xc23c38: tst             x16, HEAP, lsr #32
    //     0xc23c3c: b.eq            #0xc23c44
    //     0xc23c40: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc23c44: b               #0xc23c60
    // 0xc23c48: ldur            x1, [fp, #-0x20]
    // 0xc23c4c: b               #0xc23c5c
    // 0xc23c50: ldur            x1, [fp, #-0x20]
    // 0xc23c54: b               #0xc23c5c
    // 0xc23c58: ldur            x1, [fp, #-0x20]
    // 0xc23c5c: StoreField: r1->field_37 = rNULL
    //     0xc23c5c: stur            NULL, [x1, #0x37]
    // 0xc23c60: ldur            x0, [fp, #-8]
    // 0xc23c64: d0 = 0.000000
    //     0xc23c64: eor             v0.16b, v0.16b, v0.16b
    // 0xc23c68: LoadField: r2 = r0->field_a3
    //     0xc23c68: ldur            w2, [x0, #0xa3]
    // 0xc23c6c: DecompressPointer r2
    //     0xc23c6c: add             x2, x2, HEAP, lsl #32
    // 0xc23c70: stur            x2, [fp, #-0x40]
    // 0xc23c74: LoadField: r3 = r2->field_53
    //     0xc23c74: ldur            w3, [x2, #0x53]
    // 0xc23c78: DecompressPointer r3
    //     0xc23c78: add             x3, x3, HEAP, lsl #32
    // 0xc23c7c: stur            x3, [fp, #-0x30]
    // 0xc23c80: cmp             w3, NULL
    // 0xc23c84: b.eq            #0xc23db4
    // 0xc23c88: LoadField: r5 = r0->field_57
    //     0xc23c88: ldur            w5, [x0, #0x57]
    // 0xc23c8c: DecompressPointer r5
    //     0xc23c8c: add             x5, x5, HEAP, lsl #32
    // 0xc23c90: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc23c94: cmp             w5, w16
    // 0xc23c98: b.eq            #0xc23db8
    // 0xc23c9c: stur            x5, [fp, #-0x28]
    // 0xc23ca0: LoadField: r6 = r0->field_5f
    //     0xc23ca0: ldur            w6, [x0, #0x5f]
    // 0xc23ca4: DecompressPointer r6
    //     0xc23ca4: add             x6, x6, HEAP, lsl #32
    // 0xc23ca8: stur            x6, [fp, #-0x20]
    // 0xc23cac: LoadField: r7 = r0->field_63
    //     0xc23cac: ldur            w7, [x0, #0x63]
    // 0xc23cb0: DecompressPointer r7
    //     0xc23cb0: add             x7, x7, HEAP, lsl #32
    // 0xc23cb4: stur            x7, [fp, #-0x18]
    // 0xc23cb8: LoadField: d1 = r0->field_a7
    //     0xc23cb8: ldur            d1, [x0, #0xa7]
    // 0xc23cbc: stur            d1, [fp, #-0x68]
    // 0xc23cc0: LoadField: r1 = r0->field_af
    //     0xc23cc0: ldur            w1, [x0, #0xaf]
    // 0xc23cc4: DecompressPointer r1
    //     0xc23cc4: add             x1, x1, HEAP, lsl #32
    // 0xc23cc8: LoadField: d2 = r1->field_7
    //     0xc23cc8: ldur            d2, [x1, #7]
    // 0xc23ccc: fcmp            d0, d2
    // 0xc23cd0: b.ge            #0xc23ce0
    // 0xc23cd4: LoadField: d2 = r1->field_f
    //     0xc23cd4: ldur            d2, [x1, #0xf]
    // 0xc23cd8: fcmp            d0, d2
    // 0xc23cdc: b.lt            #0xc23cec
    // 0xc23ce0: mov             x1, x0
    // 0xc23ce4: r0 = size()
    //     0xc23ce4: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc23ce8: b               #0xc23cf0
    // 0xc23cec: mov             x0, x1
    // 0xc23cf0: ldur            x16, [fp, #-8]
    // 0xc23cf4: stp             x0, x16, [SP, #8]
    // 0xc23cf8: ldur            x16, [fp, #-0x40]
    // 0xc23cfc: str             x16, [SP]
    // 0xc23d00: ldur            x1, [fp, #-0x30]
    // 0xc23d04: ldur            x2, [fp, #-0x10]
    // 0xc23d08: ldur            x3, [fp, #-0x38]
    // 0xc23d0c: ldur            x5, [fp, #-0x28]
    // 0xc23d10: ldur            x6, [fp, #-0x20]
    // 0xc23d14: ldur            x7, [fp, #-0x18]
    // 0xc23d18: ldur            d0, [fp, #-0x68]
    // 0xc23d1c: r0 = paint()
    //     0xc23d1c: bl              #0x12ea4d0  ; [package:flutter/src/material/slider_parts.dart] RoundSliderThumbShape::paint
    // 0xc23d20: r0 = Null
    //     0xc23d20: mov             x0, NULL
    // 0xc23d24: LeaveFrame
    //     0xc23d24: mov             SP, fp
    //     0xc23d28: ldp             fp, lr, [SP], #0x10
    // 0xc23d2c: ret
    //     0xc23d2c: ret             
    // 0xc23d30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc23d30: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc23d34: b               #0xc2368c
    // 0xc23d38: r9 = positionController
    //     0xc23d38: add             x9, PP, #0x99, lsl #12  ; [pp+0x99018] Field <_SliderState@125231897.positionController>: late (offset: 0x28)
    //     0xc23d3c: ldr             x9, [x9, #0x18]
    // 0xc23d40: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc23d40: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xc23d44: r9 = _value
    //     0xc23d44: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0xc23d48: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc23d48: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xc23d4c: SaveReg d2
    //     0xc23d4c: str             q2, [SP, #-0x10]!
    // 0xc23d50: stp             x1, x4, [SP, #-0x10]!
    // 0xc23d54: SaveReg r0
    //     0xc23d54: str             x0, [SP, #-8]!
    // 0xc23d58: r0 = AllocateDouble()
    //     0xc23d58: bl              #0x13df878  ; AllocateDoubleStub
    // 0xc23d5c: mov             x2, x0
    // 0xc23d60: RestoreReg r0
    //     0xc23d60: ldr             x0, [SP], #8
    // 0xc23d64: ldp             x1, x4, [SP], #0x10
    // 0xc23d68: RestoreReg d2
    //     0xc23d68: ldr             q2, [SP], #0x10
    // 0xc23d6c: b               #0xc23720
    // 0xc23d70: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc23d70: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc23d74: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc23d74: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc23d78: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc23d78: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc23d7c: r9 = _enableAnimation
    //     0xc23d7c: add             x9, PP, #0xad, lsl #12  ; [pp+0xad760] Field <_RenderSlider@125231897._enableAnimation@125231897>: late (offset: 0x60)
    //     0xc23d80: ldr             x9, [x9, #0x760]
    // 0xc23d84: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc23d84: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xc23d88: r9 = _overlayAnimation
    //     0xc23d88: add             x9, PP, #0xad, lsl #12  ; [pp+0xad768] Field <_RenderSlider@125231897._overlayAnimation@125231897>: late (offset: 0x58)
    //     0xc23d8c: ldr             x9, [x9, #0x768]
    // 0xc23d90: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc23d90: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xc23d94: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc23d94: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xc23d98: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc23d98: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc23d9c: r0 = StackOverflowSharedWithFPURegs()
    //     0xc23d9c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xc23da0: b               #0xc23af8
    // 0xc23da4: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc23da4: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xc23da8: r9 = _valueIndicatorAnimation
    //     0xc23da8: add             x9, PP, #0xad, lsl #12  ; [pp+0xad770] Field <_RenderSlider@125231897._valueIndicatorAnimation@125231897>: late (offset: 0x5c)
    //     0xc23dac: ldr             x9, [x9, #0x770]
    // 0xc23db0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc23db0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xc23db4: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc23db4: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xc23db8: r9 = _overlayAnimation
    //     0xc23db8: add             x9, PP, #0xad, lsl #12  ; [pp+0xad768] Field <_RenderSlider@125231897._overlayAnimation@125231897>: late (offset: 0x58)
    //     0xc23dbc: ldr             x9, [x9, #0x768]
    // 0xc23dc0: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xc23dc0: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
  }
  get _ shouldShowValueIndicatorWhenDragged(/* No info */) {
    // ** addr: 0xc23dc4, size: 0xe4
    // 0xc23dc4: EnterFrame
    //     0xc23dc4: stp             fp, lr, [SP, #-0x10]!
    //     0xc23dc8: mov             fp, SP
    // 0xc23dcc: CheckStackOverflow
    //     0xc23dcc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc23dd0: cmp             SP, x16
    //     0xc23dd4: b.ls            #0xc23e9c
    // 0xc23dd8: LoadField: r0 = r1->field_a3
    //     0xc23dd8: ldur            w0, [x1, #0xa3]
    // 0xc23ddc: DecompressPointer r0
    //     0xc23ddc: add             x0, x0, HEAP, lsl #32
    // 0xc23de0: LoadField: r2 = r0->field_6f
    //     0xc23de0: ldur            w2, [x0, #0x6f]
    // 0xc23de4: DecompressPointer r2
    //     0xc23de4: add             x2, x2, HEAP, lsl #32
    // 0xc23de8: cmp             w2, NULL
    // 0xc23dec: b.eq            #0xc23ea4
    // 0xc23df0: r16 = Instance_ShowValueIndicator
    //     0xc23df0: add             x16, PP, #0x98, lsl #12  ; [pp+0x98ec8] Obj!ShowValueIndicator@12c4e81
    //     0xc23df4: ldr             x16, [x16, #0xec8]
    // 0xc23df8: cmp             w2, w16
    // 0xc23dfc: b.ne            #0xc23e1c
    // 0xc23e00: LoadField: r0 = r1->field_97
    //     0xc23e00: ldur            x0, [x1, #0x97]
    // 0xc23e04: cmp             x0, #0
    // 0xc23e08: r16 = true
    //     0xc23e08: add             x16, NULL, #0x20  ; true
    // 0xc23e0c: r17 = false
    //     0xc23e0c: add             x17, NULL, #0x30  ; false
    // 0xc23e10: csel            x1, x16, x17, gt
    // 0xc23e14: mov             x0, x1
    // 0xc23e18: b               #0xc23e90
    // 0xc23e1c: r16 = Instance_ShowValueIndicator
    //     0xc23e1c: add             x16, PP, #0xa3, lsl #12  ; [pp+0xa3730] Obj!ShowValueIndicator@12c4e61
    //     0xc23e20: ldr             x16, [x16, #0x730]
    // 0xc23e24: cmp             w2, w16
    // 0xc23e28: b.ne            #0xc23e3c
    // 0xc23e2c: r0 = isDiscrete()
    //     0xc23e2c: bl              #0xc23ea8  ; [package:flutter/src/material/slider.dart] _RenderSlider::isDiscrete
    // 0xc23e30: eor             x1, x0, #0x10
    // 0xc23e34: mov             x0, x1
    // 0xc23e38: b               #0xc23e90
    // 0xc23e3c: r16 = Instance_ShowValueIndicator
    //     0xc23e3c: add             x16, PP, #0xa3, lsl #12  ; [pp+0xa3738] Obj!ShowValueIndicator@12c4e41
    //     0xc23e40: ldr             x16, [x16, #0x738]
    // 0xc23e44: cmp             w2, w16
    // 0xc23e48: b.eq            #0xc23e5c
    // 0xc23e4c: r16 = Instance_ShowValueIndicator
    //     0xc23e4c: add             x16, PP, #0xa3, lsl #12  ; [pp+0xa3740] Obj!ShowValueIndicator@12c4e21
    //     0xc23e50: ldr             x16, [x16, #0x740]
    // 0xc23e54: cmp             w2, w16
    // 0xc23e58: b.ne            #0xc23e64
    // 0xc23e5c: r0 = true
    //     0xc23e5c: add             x0, NULL, #0x20  ; true
    // 0xc23e60: b               #0xc23e90
    // 0xc23e64: r16 = Instance_ShowValueIndicator
    //     0xc23e64: add             x16, PP, #0xa3, lsl #12  ; [pp+0xa3748] Obj!ShowValueIndicator@12c4e01
    //     0xc23e68: ldr             x16, [x16, #0x748]
    // 0xc23e6c: cmp             w2, w16
    // 0xc23e70: b.eq            #0xc23e84
    // 0xc23e74: r16 = Instance_ShowValueIndicator
    //     0xc23e74: add             x16, PP, #0xa3, lsl #12  ; [pp+0xa3750] Obj!ShowValueIndicator@12c4ea1
    //     0xc23e78: ldr             x16, [x16, #0x750]
    // 0xc23e7c: cmp             w2, w16
    // 0xc23e80: b.ne            #0xc23e8c
    // 0xc23e84: r0 = false
    //     0xc23e84: add             x0, NULL, #0x30  ; false
    // 0xc23e88: b               #0xc23e90
    // 0xc23e8c: r0 = Null
    //     0xc23e8c: mov             x0, NULL
    // 0xc23e90: LeaveFrame
    //     0xc23e90: mov             SP, fp
    //     0xc23e94: ldp             fp, lr, [SP], #0x10
    // 0xc23e98: ret
    //     0xc23e98: ret             
    // 0xc23e9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc23e9c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc23ea0: b               #0xc23dd8
    // 0xc23ea4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc23ea4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ isDiscrete(/* No info */) {
    // ** addr: 0xc23ea8, size: 0x18
    // 0xc23ea8: LoadField: r2 = r1->field_97
    //     0xc23ea8: ldur            x2, [x1, #0x97]
    // 0xc23eac: cmp             x2, #0
    // 0xc23eb0: r16 = true
    //     0xc23eb0: add             x16, NULL, #0x20  ; true
    // 0xc23eb4: r17 = false
    //     0xc23eb4: add             x17, NULL, #0x30  ; false
    // 0xc23eb8: csel            x0, x16, x17, gt
    // 0xc23ebc: ret
    //     0xc23ebc: ret             
  }
  [closure] void <anonymous closure>(dynamic, PaintingContext, Offset) {
    // ** addr: 0xc25380, size: 0x1d8
    // 0xc25380: EnterFrame
    //     0xc25380: stp             fp, lr, [SP, #-0x10]!
    //     0xc25384: mov             fp, SP
    // 0xc25388: AllocStack(0x58)
    //     0xc25388: sub             SP, SP, #0x58
    // 0xc2538c: SetupParameters([dynamic _ /* r0 */])
    //     0xc2538c: ldr             x0, [fp, #0x20]
    //     0xc25390: ldur            w3, [x0, #0x17]
    //     0xc25394: add             x3, x3, HEAP, lsl #32
    //     0xc25398: stur            x3, [fp, #-0x10]
    // 0xc2539c: CheckStackOverflow
    //     0xc2539c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc253a0: cmp             SP, x16
    //     0xc253a4: b.ls            #0xc25538
    // 0xc253a8: LoadField: r0 = r3->field_f
    //     0xc253a8: ldur            w0, [x3, #0xf]
    // 0xc253ac: DecompressPointer r0
    //     0xc253ac: add             x0, x0, HEAP, lsl #32
    // 0xc253b0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xc253b0: ldur            w1, [x0, #0x17]
    // 0xc253b4: DecompressPointer r1
    //     0xc253b4: add             x1, x1, HEAP, lsl #32
    // 0xc253b8: cmp             w1, NULL
    // 0xc253bc: b.eq            #0xc25528
    // 0xc253c0: LoadField: r1 = r0->field_63
    //     0xc253c0: ldur            w1, [x0, #0x63]
    // 0xc253c4: DecompressPointer r1
    //     0xc253c4: add             x1, x1, HEAP, lsl #32
    // 0xc253c8: LoadField: r2 = r1->field_f
    //     0xc253c8: ldur            w2, [x1, #0xf]
    // 0xc253cc: DecompressPointer r2
    //     0xc253cc: add             x2, x2, HEAP, lsl #32
    // 0xc253d0: cmp             w2, NULL
    // 0xc253d4: b.eq            #0xc25528
    // 0xc253d8: LoadField: r1 = r0->field_a3
    //     0xc253d8: ldur            w1, [x0, #0xa3]
    // 0xc253dc: DecompressPointer r1
    //     0xc253dc: add             x1, x1, HEAP, lsl #32
    // 0xc253e0: LoadField: r0 = r1->field_5b
    //     0xc253e0: ldur            w0, [x1, #0x5b]
    // 0xc253e4: DecompressPointer r0
    //     0xc253e4: add             x0, x0, HEAP, lsl #32
    // 0xc253e8: stur            x0, [fp, #-8]
    // 0xc253ec: cmp             w0, NULL
    // 0xc253f0: b.eq            #0xc25528
    // 0xc253f4: LoadField: r2 = r3->field_13
    //     0xc253f4: ldur            w2, [x3, #0x13]
    // 0xc253f8: DecompressPointer r2
    //     0xc253f8: add             x2, x2, HEAP, lsl #32
    // 0xc253fc: ldr             x1, [fp, #0x10]
    // 0xc25400: r0 = +()
    //     0xc25400: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0xc25404: mov             x2, x0
    // 0xc25408: ldur            x0, [fp, #-0x10]
    // 0xc2540c: stur            x2, [fp, #-0x38]
    // 0xc25410: LoadField: r1 = r0->field_f
    //     0xc25410: ldur            w1, [x0, #0xf]
    // 0xc25414: DecompressPointer r1
    //     0xc25414: add             x1, x1, HEAP, lsl #32
    // 0xc25418: LoadField: r3 = r1->field_a3
    //     0xc25418: ldur            w3, [x1, #0xa3]
    // 0xc2541c: DecompressPointer r3
    //     0xc2541c: add             x3, x3, HEAP, lsl #32
    // 0xc25420: stur            x3, [fp, #-0x30]
    // 0xc25424: LoadField: r4 = r3->field_6f
    //     0xc25424: ldur            w4, [x3, #0x6f]
    // 0xc25428: DecompressPointer r4
    //     0xc25428: add             x4, x4, HEAP, lsl #32
    // 0xc2542c: r16 = Instance_ShowValueIndicator
    //     0xc2542c: add             x16, PP, #0xa3, lsl #12  ; [pp+0xa3750] Obj!ShowValueIndicator@12c4ea1
    //     0xc25430: ldr             x16, [x16, #0x750]
    // 0xc25434: cmp             w4, w16
    // 0xc25438: b.ne            #0xc25448
    // 0xc2543c: r5 = Instance_AlwaysStoppedAnimation
    //     0xc2543c: add             x5, PP, #0x82, lsl #12  ; [pp+0x82a08] Obj!AlwaysStoppedAnimation<double>@12aa3b1
    //     0xc25440: ldr             x5, [x5, #0xa08]
    // 0xc25444: b               #0xc2545c
    // 0xc25448: LoadField: r5 = r1->field_5b
    //     0xc25448: ldur            w5, [x1, #0x5b]
    // 0xc2544c: DecompressPointer r5
    //     0xc2544c: add             x5, x5, HEAP, lsl #32
    // 0xc25450: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc25454: cmp             w5, w16
    // 0xc25458: b.eq            #0xc25540
    // 0xc2545c: stur            x5, [fp, #-0x28]
    // 0xc25460: r16 = Instance_ShowValueIndicator
    //     0xc25460: add             x16, PP, #0xa3, lsl #12  ; [pp+0xa3750] Obj!ShowValueIndicator@12c4ea1
    //     0xc25464: ldr             x16, [x16, #0x750]
    // 0xc25468: cmp             w4, w16
    // 0xc2546c: b.ne            #0xc2547c
    // 0xc25470: r6 = Instance_AlwaysStoppedAnimation
    //     0xc25470: add             x6, PP, #0x82, lsl #12  ; [pp+0x82a08] Obj!AlwaysStoppedAnimation<double>@12aa3b1
    //     0xc25474: ldr             x6, [x6, #0xa08]
    // 0xc25478: b               #0xc25494
    // 0xc2547c: LoadField: r4 = r1->field_5f
    //     0xc2547c: ldur            w4, [x1, #0x5f]
    // 0xc25480: DecompressPointer r4
    //     0xc25480: add             x4, x4, HEAP, lsl #32
    // 0xc25484: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc25488: cmp             w4, w16
    // 0xc2548c: b.eq            #0xc2554c
    // 0xc25490: mov             x6, x4
    // 0xc25494: d0 = 0.000000
    //     0xc25494: eor             v0.16b, v0.16b, v0.16b
    // 0xc25498: stur            x6, [fp, #-0x20]
    // 0xc2549c: LoadField: r7 = r1->field_63
    //     0xc2549c: ldur            w7, [x1, #0x63]
    // 0xc254a0: DecompressPointer r7
    //     0xc254a0: add             x7, x7, HEAP, lsl #32
    // 0xc254a4: stur            x7, [fp, #-0x18]
    // 0xc254a8: LoadField: d1 = r1->field_a7
    //     0xc254a8: ldur            d1, [x1, #0xa7]
    // 0xc254ac: stur            d1, [fp, #-0x40]
    // 0xc254b0: LoadField: r4 = r1->field_af
    //     0xc254b0: ldur            w4, [x1, #0xaf]
    // 0xc254b4: DecompressPointer r4
    //     0xc254b4: add             x4, x4, HEAP, lsl #32
    // 0xc254b8: LoadField: d2 = r4->field_7
    //     0xc254b8: ldur            d2, [x4, #7]
    // 0xc254bc: fcmp            d0, d2
    // 0xc254c0: b.ge            #0xc254d0
    // 0xc254c4: LoadField: d2 = r4->field_f
    //     0xc254c4: ldur            d2, [x4, #0xf]
    // 0xc254c8: fcmp            d0, d2
    // 0xc254cc: b.lt            #0xc254dc
    // 0xc254d0: r0 = size()
    //     0xc254d0: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc254d4: mov             x2, x0
    // 0xc254d8: b               #0xc254e0
    // 0xc254dc: mov             x2, x4
    // 0xc254e0: ldur            x0, [fp, #-0x10]
    // 0xc254e4: ldur            x1, [fp, #-8]
    // 0xc254e8: LoadField: r3 = r0->field_f
    //     0xc254e8: ldur            w3, [x0, #0xf]
    // 0xc254ec: DecompressPointer r3
    //     0xc254ec: add             x3, x3, HEAP, lsl #32
    // 0xc254f0: r0 = LoadClassIdInstr(r1)
    //     0xc254f0: ldur            x0, [x1, #-1]
    //     0xc254f4: ubfx            x0, x0, #0xc, #0x14
    // 0xc254f8: stp             x2, x3, [SP, #8]
    // 0xc254fc: ldur            x16, [fp, #-0x30]
    // 0xc25500: str             x16, [SP]
    // 0xc25504: ldr             x2, [fp, #0x18]
    // 0xc25508: ldur            x3, [fp, #-0x38]
    // 0xc2550c: ldur            x5, [fp, #-0x28]
    // 0xc25510: ldur            x6, [fp, #-0x20]
    // 0xc25514: ldur            x7, [fp, #-0x18]
    // 0xc25518: ldur            d0, [fp, #-0x40]
    // 0xc2551c: r0 = GDT[cid_x0 + -0xdf6]()
    //     0xc2551c: sub             lr, x0, #0xdf6
    //     0xc25520: ldr             lr, [x21, lr, lsl #3]
    //     0xc25524: blr             lr
    // 0xc25528: r0 = Null
    //     0xc25528: mov             x0, NULL
    // 0xc2552c: LeaveFrame
    //     0xc2552c: mov             SP, fp
    //     0xc25530: ldp             fp, lr, [SP], #0x10
    // 0xc25534: ret
    //     0xc25534: ret             
    // 0xc25538: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc25538: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc2553c: b               #0xc253a8
    // 0xc25540: r9 = _valueIndicatorAnimation
    //     0xc25540: add             x9, PP, #0xad, lsl #12  ; [pp+0xad770] Field <_RenderSlider@125231897._valueIndicatorAnimation@125231897>: late (offset: 0x5c)
    //     0xc25544: ldr             x9, [x9, #0x770]
    // 0xc25548: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc25548: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xc2554c: r9 = _enableAnimation
    //     0xc2554c: add             x9, PP, #0xad, lsl #12  ; [pp+0xad760] Field <_RenderSlider@125231897._enableAnimation@125231897>: late (offset: 0x60)
    //     0xc25550: ldr             x9, [x9, #0x760]
    // 0xc25554: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc25554: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ handleEvent(/* No info */) {
    // ** addr: 0xcd1c28, size: 0x1b4
    // 0xcd1c28: EnterFrame
    //     0xcd1c28: stp             fp, lr, [SP, #-0x10]!
    //     0xcd1c2c: mov             fp, SP
    // 0xcd1c30: AllocStack(0x18)
    //     0xcd1c30: sub             SP, SP, #0x18
    // 0xcd1c34: SetupParameters(_RenderSlider this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */, dynamic _ /* r3 => r0 */)
    //     0xcd1c34: mov             x4, x1
    //     0xcd1c38: mov             x0, x3
    //     0xcd1c3c: mov             x3, x2
    //     0xcd1c40: stur            x1, [fp, #-8]
    //     0xcd1c44: stur            x2, [fp, #-0x10]
    // 0xcd1c48: CheckStackOverflow
    //     0xcd1c48: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcd1c4c: cmp             SP, x16
    //     0xcd1c50: b.ls            #0xcd1dbc
    // 0xcd1c54: r2 = Null
    //     0xcd1c54: mov             x2, NULL
    // 0xcd1c58: r1 = Null
    //     0xcd1c58: mov             x1, NULL
    // 0xcd1c5c: r4 = 60
    //     0xcd1c5c: mov             x4, #0x3c
    // 0xcd1c60: branchIfSmi(r0, 0xcd1c6c)
    //     0xcd1c60: tbz             w0, #0, #0xcd1c6c
    // 0xcd1c64: r4 = LoadClassIdInstr(r0)
    //     0xcd1c64: ldur            x4, [x0, #-1]
    //     0xcd1c68: ubfx            x4, x4, #0xc, #0x14
    // 0xcd1c6c: cmp             x4, #0xc65
    // 0xcd1c70: b.eq            #0xcd1c88
    // 0xcd1c74: r8 = BoxHitTestEntry
    //     0xcd1c74: add             x8, PP, #0x15, lsl #12  ; [pp+0x155d0] Type: BoxHitTestEntry
    //     0xcd1c78: ldr             x8, [x8, #0x5d0]
    // 0xcd1c7c: r3 = Null
    //     0xcd1c7c: add             x3, PP, #0xad, lsl #12  ; [pp+0xad7a8] Null
    //     0xcd1c80: ldr             x3, [x3, #0x7a8]
    // 0xcd1c84: r0 = DefaultTypeTest()
    //     0xcd1c84: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcd1c88: ldur            x3, [fp, #-8]
    // 0xcd1c8c: LoadField: r0 = r3->field_53
    //     0xcd1c8c: ldur            w0, [x3, #0x53]
    // 0xcd1c90: DecompressPointer r0
    //     0xcd1c90: add             x0, x0, HEAP, lsl #32
    // 0xcd1c94: LoadField: r1 = r0->field_f
    //     0xcd1c94: ldur            w1, [x0, #0xf]
    // 0xcd1c98: DecompressPointer r1
    //     0xcd1c98: add             x1, x1, HEAP, lsl #32
    // 0xcd1c9c: cmp             w1, NULL
    // 0xcd1ca0: b.ne            #0xcd1cb4
    // 0xcd1ca4: r0 = Null
    //     0xcd1ca4: mov             x0, NULL
    // 0xcd1ca8: LeaveFrame
    //     0xcd1ca8: mov             SP, fp
    //     0xcd1cac: ldp             fp, lr, [SP], #0x10
    // 0xcd1cb0: ret
    //     0xcd1cb0: ret             
    // 0xcd1cb4: ldur            x0, [fp, #-0x10]
    // 0xcd1cb8: r2 = Null
    //     0xcd1cb8: mov             x2, NULL
    // 0xcd1cbc: r1 = Null
    //     0xcd1cbc: mov             x1, NULL
    // 0xcd1cc0: cmp             w0, NULL
    // 0xcd1cc4: b.eq            #0xcd1cec
    // 0xcd1cc8: branchIfSmi(r0, 0xcd1cec)
    //     0xcd1cc8: tbz             w0, #0, #0xcd1cec
    // 0xcd1ccc: r3 = LoadClassIdInstr(r0)
    //     0xcd1ccc: ldur            x3, [x0, #-1]
    //     0xcd1cd0: ubfx            x3, x3, #0xc, #0x14
    // 0xcd1cd4: r17 = 4159
    //     0xcd1cd4: mov             x17, #0x103f
    // 0xcd1cd8: cmp             x3, x17
    // 0xcd1cdc: b.eq            #0xcd1cf4
    // 0xcd1ce0: r17 = 5288
    //     0xcd1ce0: mov             x17, #0x14a8
    // 0xcd1ce4: cmp             x3, x17
    // 0xcd1ce8: b.eq            #0xcd1cf4
    // 0xcd1cec: r0 = false
    //     0xcd1cec: add             x0, NULL, #0x30  ; false
    // 0xcd1cf0: b               #0xcd1cf8
    // 0xcd1cf4: r0 = true
    //     0xcd1cf4: add             x0, NULL, #0x20  ; true
    // 0xcd1cf8: tbnz            w0, #4, #0xcd1d4c
    // 0xcd1cfc: ldur            x0, [fp, #-8]
    // 0xcd1d00: LoadField: r1 = r0->field_b3
    //     0xcd1d00: ldur            w1, [x0, #0xb3]
    // 0xcd1d04: DecompressPointer r1
    //     0xcd1d04: add             x1, x1, HEAP, lsl #32
    // 0xcd1d08: cmp             w1, NULL
    // 0xcd1d0c: b.eq            #0xcd1d4c
    // 0xcd1d10: LoadField: r1 = r0->field_67
    //     0xcd1d10: ldur            w1, [x0, #0x67]
    // 0xcd1d14: DecompressPointer r1
    //     0xcd1d14: add             x1, x1, HEAP, lsl #32
    // 0xcd1d18: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xcd1d1c: cmp             w1, w16
    // 0xcd1d20: b.eq            #0xcd1dc4
    // 0xcd1d24: ldur            x2, [fp, #-0x10]
    // 0xcd1d28: r0 = addPointer()
    //     0xcd1d28: bl              #0xd04e70  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::addPointer
    // 0xcd1d2c: ldur            x0, [fp, #-8]
    // 0xcd1d30: LoadField: r1 = r0->field_6b
    //     0xcd1d30: ldur            w1, [x0, #0x6b]
    // 0xcd1d34: DecompressPointer r1
    //     0xcd1d34: add             x1, x1, HEAP, lsl #32
    // 0xcd1d38: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xcd1d3c: cmp             w1, w16
    // 0xcd1d40: b.eq            #0xcd1dd0
    // 0xcd1d44: ldur            x2, [fp, #-0x10]
    // 0xcd1d48: r0 = addPointer()
    //     0xcd1d48: bl              #0xd04e70  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::addPointer
    // 0xcd1d4c: ldur            x2, [fp, #-8]
    // 0xcd1d50: LoadField: r0 = r2->field_b3
    //     0xcd1d50: ldur            w0, [x2, #0xb3]
    // 0xcd1d54: DecompressPointer r0
    //     0xcd1d54: add             x0, x0, HEAP, lsl #32
    // 0xcd1d58: cmp             w0, NULL
    // 0xcd1d5c: b.eq            #0xcd1dac
    // 0xcd1d60: LoadField: r3 = r2->field_7f
    //     0xcd1d60: ldur            w3, [x2, #0x7f]
    // 0xcd1d64: DecompressPointer r3
    //     0xcd1d64: add             x3, x3, HEAP, lsl #32
    // 0xcd1d68: stur            x3, [fp, #-0x18]
    // 0xcd1d6c: cmp             w3, NULL
    // 0xcd1d70: b.eq            #0xcd1dac
    // 0xcd1d74: ldur            x1, [fp, #-0x10]
    // 0xcd1d78: r0 = LoadClassIdInstr(r1)
    //     0xcd1d78: ldur            x0, [x1, #-1]
    //     0xcd1d7c: ubfx            x0, x0, #0xc, #0x14
    // 0xcd1d80: r0 = GDT[cid_x0 + 0x154ea]()
    //     0xcd1d80: mov             x17, #0x54ea
    //     0xcd1d84: movk            x17, #1, lsl #16
    //     0xcd1d88: add             lr, x0, x17
    //     0xcd1d8c: ldr             lr, [x21, lr, lsl #3]
    //     0xcd1d90: blr             lr
    // 0xcd1d94: ldur            x1, [fp, #-0x18]
    // 0xcd1d98: mov             x2, x0
    // 0xcd1d9c: r0 = contains()
    //     0xcd1d9c: bl              #0x81cce0  ; [dart:ui] Rect::contains
    // 0xcd1da0: ldur            x1, [fp, #-8]
    // 0xcd1da4: mov             x2, x0
    // 0xcd1da8: r0 = hoveringThumb=()
    //     0xcd1da8: bl              #0xcd1ddc  ; [package:flutter/src/material/slider.dart] _RenderSlider::hoveringThumb=
    // 0xcd1dac: r0 = Null
    //     0xcd1dac: mov             x0, NULL
    // 0xcd1db0: LeaveFrame
    //     0xcd1db0: mov             SP, fp
    //     0xcd1db4: ldp             fp, lr, [SP], #0x10
    // 0xcd1db8: ret
    //     0xcd1db8: ret             
    // 0xcd1dbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd1dbc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd1dc0: b               #0xcd1c54
    // 0xcd1dc4: r9 = _drag
    //     0xcd1dc4: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa3720] Field <_RenderSlider@125231897._drag@125231897>: late (offset: 0x68)
    //     0xcd1dc8: ldr             x9, [x9, #0x720]
    // 0xcd1dcc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xcd1dcc: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xcd1dd0: r9 = _tap
    //     0xcd1dd0: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa3728] Field <_RenderSlider@125231897._tap@125231897>: late (offset: 0x6c)
    //     0xcd1dd4: ldr             x9, [x9, #0x728]
    // 0xcd1dd8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xcd1dd8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  set _ hoveringThumb=(/* No info */) {
    // ** addr: 0xcd1ddc, size: 0x5c
    // 0xcd1ddc: EnterFrame
    //     0xcd1ddc: stp             fp, lr, [SP, #-0x10]!
    //     0xcd1de0: mov             fp, SP
    // 0xcd1de4: CheckStackOverflow
    //     0xcd1de4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcd1de8: cmp             SP, x16
    //     0xcd1dec: b.ls            #0xcd1e30
    // 0xcd1df0: LoadField: r0 = r1->field_cb
    //     0xcd1df0: ldur            w0, [x1, #0xcb]
    // 0xcd1df4: DecompressPointer r0
    //     0xcd1df4: add             x0, x0, HEAP, lsl #32
    // 0xcd1df8: cmp             w2, w0
    // 0xcd1dfc: b.ne            #0xcd1e10
    // 0xcd1e00: r0 = Null
    //     0xcd1e00: mov             x0, NULL
    // 0xcd1e04: LeaveFrame
    //     0xcd1e04: mov             SP, fp
    //     0xcd1e08: ldp             fp, lr, [SP], #0x10
    // 0xcd1e0c: ret
    //     0xcd1e0c: ret             
    // 0xcd1e10: StoreField: r1->field_cb = r2
    //     0xcd1e10: stur            w2, [x1, #0xcb]
    // 0xcd1e14: LoadField: r2 = r1->field_c7
    //     0xcd1e14: ldur            w2, [x1, #0xc7]
    // 0xcd1e18: DecompressPointer r2
    //     0xcd1e18: add             x2, x2, HEAP, lsl #32
    // 0xcd1e1c: r0 = _updateForHover()
    //     0xcd1e1c: bl              #0xcd1e38  ; [package:flutter/src/material/slider.dart] _RenderSlider::_updateForHover
    // 0xcd1e20: r0 = Null
    //     0xcd1e20: mov             x0, NULL
    // 0xcd1e24: LeaveFrame
    //     0xcd1e24: mov             SP, fp
    //     0xcd1e28: ldp             fp, lr, [SP], #0x10
    // 0xcd1e2c: ret
    //     0xcd1e2c: ret             
    // 0xcd1e30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd1e30: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd1e34: b               #0xcd1df0
  }
  _ _updateForHover(/* No info */) {
    // ** addr: 0xcd1e38, size: 0xb8
    // 0xcd1e38: EnterFrame
    //     0xcd1e38: stp             fp, lr, [SP, #-0x10]!
    //     0xcd1e3c: mov             fp, SP
    // 0xcd1e40: CheckStackOverflow
    //     0xcd1e40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcd1e44: cmp             SP, x16
    //     0xcd1e48: b.ls            #0xcd1ed0
    // 0xcd1e4c: tbnz            w2, #4, #0xcd1e84
    // 0xcd1e50: LoadField: r0 = r1->field_cb
    //     0xcd1e50: ldur            w0, [x1, #0xcb]
    // 0xcd1e54: DecompressPointer r0
    //     0xcd1e54: add             x0, x0, HEAP, lsl #32
    // 0xcd1e58: tbnz            w0, #4, #0xcd1e84
    // 0xcd1e5c: LoadField: r0 = r1->field_53
    //     0xcd1e5c: ldur            w0, [x1, #0x53]
    // 0xcd1e60: DecompressPointer r0
    //     0xcd1e60: add             x0, x0, HEAP, lsl #32
    // 0xcd1e64: LoadField: r1 = r0->field_1b
    //     0xcd1e64: ldur            w1, [x0, #0x1b]
    // 0xcd1e68: DecompressPointer r1
    //     0xcd1e68: add             x1, x1, HEAP, lsl #32
    // 0xcd1e6c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xcd1e70: cmp             w1, w16
    // 0xcd1e74: b.eq            #0xcd1ed8
    // 0xcd1e78: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xcd1e78: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xcd1e7c: r0 = forward()
    //     0xcd1e7c: bl              #0x8cd83c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0xcd1e80: b               #0xcd1ec0
    // 0xcd1e84: LoadField: r0 = r1->field_6f
    //     0xcd1e84: ldur            w0, [x1, #0x6f]
    // 0xcd1e88: DecompressPointer r0
    //     0xcd1e88: add             x0, x0, HEAP, lsl #32
    // 0xcd1e8c: tbz             w0, #4, #0xcd1ec0
    // 0xcd1e90: LoadField: r0 = r1->field_c3
    //     0xcd1e90: ldur            w0, [x1, #0xc3]
    // 0xcd1e94: DecompressPointer r0
    //     0xcd1e94: add             x0, x0, HEAP, lsl #32
    // 0xcd1e98: tbz             w0, #4, #0xcd1ec0
    // 0xcd1e9c: LoadField: r0 = r1->field_53
    //     0xcd1e9c: ldur            w0, [x1, #0x53]
    // 0xcd1ea0: DecompressPointer r0
    //     0xcd1ea0: add             x0, x0, HEAP, lsl #32
    // 0xcd1ea4: LoadField: r1 = r0->field_1b
    //     0xcd1ea4: ldur            w1, [x0, #0x1b]
    // 0xcd1ea8: DecompressPointer r1
    //     0xcd1ea8: add             x1, x1, HEAP, lsl #32
    // 0xcd1eac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xcd1eb0: cmp             w1, w16
    // 0xcd1eb4: b.eq            #0xcd1ee4
    // 0xcd1eb8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xcd1eb8: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xcd1ebc: r0 = reverse()
    //     0xcd1ebc: bl              #0x8c8688  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0xcd1ec0: r0 = Null
    //     0xcd1ec0: mov             x0, NULL
    // 0xcd1ec4: LeaveFrame
    //     0xcd1ec4: mov             SP, fp
    //     0xcd1ec8: ldp             fp, lr, [SP], #0x10
    // 0xcd1ecc: ret
    //     0xcd1ecc: ret             
    // 0xcd1ed0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd1ed0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd1ed4: b               #0xcd1e4c
    // 0xcd1ed8: r9 = overlayController
    //     0xcd1ed8: add             x9, PP, #0x99, lsl #12  ; [pp+0x99000] Field <_SliderState@125231897.overlayController>: late (offset: 0x1c)
    //     0xcd1edc: ldr             x9, [x9]
    // 0xcd1ee0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xcd1ee0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xcd1ee4: r9 = overlayController
    //     0xcd1ee4: add             x9, PP, #0x99, lsl #12  ; [pp+0x99000] Field <_SliderState@125231897.overlayController>: late (offset: 0x1c)
    //     0xcd1ee8: ldr             x9, [x9]
    // 0xcd1eec: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xcd1eec: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  set _ gestureSettings=(/* No info */) {
    // ** addr: 0xce286c, size: 0xa4
    // 0xce286c: EnterFrame
    //     0xce286c: stp             fp, lr, [SP, #-0x10]!
    //     0xce2870: mov             fp, SP
    // 0xce2874: mov             x16, x2
    // 0xce2878: mov             x2, x1
    // 0xce287c: mov             x1, x16
    // 0xce2880: LoadField: r3 = r2->field_67
    //     0xce2880: ldur            w3, [x2, #0x67]
    // 0xce2884: DecompressPointer r3
    //     0xce2884: add             x3, x3, HEAP, lsl #32
    // 0xce2888: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xce288c: cmp             w3, w16
    // 0xce2890: b.eq            #0xce28f8
    // 0xce2894: mov             x0, x1
    // 0xce2898: StoreField: r3->field_7 = r0
    //     0xce2898: stur            w0, [x3, #7]
    //     0xce289c: ldurb           w16, [x3, #-1]
    //     0xce28a0: ldurb           w17, [x0, #-1]
    //     0xce28a4: and             x16, x17, x16, lsr #2
    //     0xce28a8: tst             x16, HEAP, lsr #32
    //     0xce28ac: b.eq            #0xce28b4
    //     0xce28b0: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xce28b4: LoadField: r3 = r2->field_6b
    //     0xce28b4: ldur            w3, [x2, #0x6b]
    // 0xce28b8: DecompressPointer r3
    //     0xce28b8: add             x3, x3, HEAP, lsl #32
    // 0xce28bc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xce28c0: cmp             w3, w16
    // 0xce28c4: b.eq            #0xce2904
    // 0xce28c8: mov             x0, x1
    // 0xce28cc: StoreField: r3->field_7 = r0
    //     0xce28cc: stur            w0, [x3, #7]
    //     0xce28d0: ldurb           w16, [x3, #-1]
    //     0xce28d4: ldurb           w17, [x0, #-1]
    //     0xce28d8: and             x16, x17, x16, lsr #2
    //     0xce28dc: tst             x16, HEAP, lsr #32
    //     0xce28e0: b.eq            #0xce28e8
    //     0xce28e4: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xce28e8: r0 = Null
    //     0xce28e8: mov             x0, NULL
    // 0xce28ec: LeaveFrame
    //     0xce28ec: mov             SP, fp
    //     0xce28f0: ldp             fp, lr, [SP], #0x10
    // 0xce28f4: ret
    //     0xce28f4: ret             
    // 0xce28f8: r9 = _drag
    //     0xce28f8: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa3720] Field <_RenderSlider@125231897._drag@125231897>: late (offset: 0x68)
    //     0xce28fc: ldr             x9, [x9, #0x720]
    // 0xce2900: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xce2900: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xce2904: r9 = _tap
    //     0xce2904: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa3728] Field <_RenderSlider@125231897._tap@125231897>: late (offset: 0x6c)
    //     0xce2908: ldr             x9, [x9, #0x728]
    // 0xce290c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xce290c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  set _ hovering=(/* No info */) {
    // ** addr: 0xce295c, size: 0x54
    // 0xce295c: EnterFrame
    //     0xce295c: stp             fp, lr, [SP, #-0x10]!
    //     0xce2960: mov             fp, SP
    // 0xce2964: CheckStackOverflow
    //     0xce2964: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce2968: cmp             SP, x16
    //     0xce296c: b.ls            #0xce29a8
    // 0xce2970: LoadField: r0 = r1->field_c7
    //     0xce2970: ldur            w0, [x1, #0xc7]
    // 0xce2974: DecompressPointer r0
    //     0xce2974: add             x0, x0, HEAP, lsl #32
    // 0xce2978: cmp             w2, w0
    // 0xce297c: b.ne            #0xce2990
    // 0xce2980: r0 = Null
    //     0xce2980: mov             x0, NULL
    // 0xce2984: LeaveFrame
    //     0xce2984: mov             SP, fp
    //     0xce2988: ldp             fp, lr, [SP], #0x10
    // 0xce298c: ret
    //     0xce298c: ret             
    // 0xce2990: StoreField: r1->field_c7 = r2
    //     0xce2990: stur            w2, [x1, #0xc7]
    // 0xce2994: r0 = _updateForHover()
    //     0xce2994: bl              #0xcd1e38  ; [package:flutter/src/material/slider.dart] _RenderSlider::_updateForHover
    // 0xce2998: r0 = Null
    //     0xce2998: mov             x0, NULL
    // 0xce299c: LeaveFrame
    //     0xce299c: mov             SP, fp
    //     0xce29a0: ldp             fp, lr, [SP], #0x10
    // 0xce29a4: ret
    //     0xce29a4: ret             
    // 0xce29a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce29a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce29ac: b               #0xce2970
  }
  set _ hasFocus=(/* No info */) {
    // ** addr: 0xce29b0, size: 0x6c
    // 0xce29b0: EnterFrame
    //     0xce29b0: stp             fp, lr, [SP, #-0x10]!
    //     0xce29b4: mov             fp, SP
    // 0xce29b8: AllocStack(0x8)
    //     0xce29b8: sub             SP, SP, #8
    // 0xce29bc: SetupParameters(_RenderSlider this /* r1 => r0, fp-0x8 */)
    //     0xce29bc: mov             x0, x1
    //     0xce29c0: stur            x1, [fp, #-8]
    // 0xce29c4: CheckStackOverflow
    //     0xce29c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce29c8: cmp             SP, x16
    //     0xce29cc: b.ls            #0xce2a14
    // 0xce29d0: LoadField: r1 = r0->field_c3
    //     0xce29d0: ldur            w1, [x0, #0xc3]
    // 0xce29d4: DecompressPointer r1
    //     0xce29d4: add             x1, x1, HEAP, lsl #32
    // 0xce29d8: cmp             w2, w1
    // 0xce29dc: b.ne            #0xce29f0
    // 0xce29e0: r0 = Null
    //     0xce29e0: mov             x0, NULL
    // 0xce29e4: LeaveFrame
    //     0xce29e4: mov             SP, fp
    //     0xce29e8: ldp             fp, lr, [SP], #0x10
    // 0xce29ec: ret
    //     0xce29ec: ret             
    // 0xce29f0: StoreField: r0->field_c3 = r2
    //     0xce29f0: stur            w2, [x0, #0xc3]
    // 0xce29f4: mov             x1, x0
    // 0xce29f8: r0 = _updateForFocus()
    //     0xce29f8: bl              #0xce2a1c  ; [package:flutter/src/material/slider.dart] _RenderSlider::_updateForFocus
    // 0xce29fc: ldur            x1, [fp, #-8]
    // 0xce2a00: r0 = markNeedsSemanticsUpdate()
    //     0xce2a00: bl              #0x8373c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0xce2a04: r0 = Null
    //     0xce2a04: mov             x0, NULL
    // 0xce2a08: LeaveFrame
    //     0xce2a08: mov             SP, fp
    //     0xce2a0c: ldp             fp, lr, [SP], #0x10
    // 0xce2a10: ret
    //     0xce2a10: ret             
    // 0xce2a14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce2a14: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce2a18: b               #0xce29d0
  }
  _ _updateForFocus(/* No info */) {
    // ** addr: 0xce2a1c, size: 0x118
    // 0xce2a1c: EnterFrame
    //     0xce2a1c: stp             fp, lr, [SP, #-0x10]!
    //     0xce2a20: mov             fp, SP
    // 0xce2a24: AllocStack(0x10)
    //     0xce2a24: sub             SP, SP, #0x10
    // 0xce2a28: SetupParameters(_RenderSlider this /* r1 => r0, fp-0x10 */)
    //     0xce2a28: mov             x0, x1
    //     0xce2a2c: stur            x1, [fp, #-0x10]
    // 0xce2a30: CheckStackOverflow
    //     0xce2a30: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce2a34: cmp             SP, x16
    //     0xce2a38: b.ls            #0xce2afc
    // 0xce2a3c: tbnz            w2, #4, #0xce2a98
    // 0xce2a40: LoadField: r2 = r0->field_53
    //     0xce2a40: ldur            w2, [x0, #0x53]
    // 0xce2a44: DecompressPointer r2
    //     0xce2a44: add             x2, x2, HEAP, lsl #32
    // 0xce2a48: stur            x2, [fp, #-8]
    // 0xce2a4c: LoadField: r1 = r2->field_1b
    //     0xce2a4c: ldur            w1, [x2, #0x1b]
    // 0xce2a50: DecompressPointer r1
    //     0xce2a50: add             x1, x1, HEAP, lsl #32
    // 0xce2a54: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xce2a58: cmp             w1, w16
    // 0xce2a5c: b.eq            #0xce2b04
    // 0xce2a60: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xce2a60: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xce2a64: r0 = forward()
    //     0xce2a64: bl              #0x8cd83c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0xce2a68: ldur            x1, [fp, #-0x10]
    // 0xce2a6c: r0 = shouldShowValueIndicatorWhenDragged()
    //     0xce2a6c: bl              #0xc23dc4  ; [package:flutter/src/material/slider.dart] _RenderSlider::shouldShowValueIndicatorWhenDragged
    // 0xce2a70: tbnz            w0, #4, #0xce2aec
    // 0xce2a74: ldur            x0, [fp, #-8]
    // 0xce2a78: LoadField: r1 = r0->field_1f
    //     0xce2a78: ldur            w1, [x0, #0x1f]
    // 0xce2a7c: DecompressPointer r1
    //     0xce2a7c: add             x1, x1, HEAP, lsl #32
    // 0xce2a80: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xce2a84: cmp             w1, w16
    // 0xce2a88: b.eq            #0xce2b10
    // 0xce2a8c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xce2a8c: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xce2a90: r0 = forward()
    //     0xce2a90: bl              #0x8cd83c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0xce2a94: b               #0xce2aec
    // 0xce2a98: LoadField: r2 = r0->field_53
    //     0xce2a98: ldur            w2, [x0, #0x53]
    // 0xce2a9c: DecompressPointer r2
    //     0xce2a9c: add             x2, x2, HEAP, lsl #32
    // 0xce2aa0: stur            x2, [fp, #-8]
    // 0xce2aa4: LoadField: r1 = r2->field_1b
    //     0xce2aa4: ldur            w1, [x2, #0x1b]
    // 0xce2aa8: DecompressPointer r1
    //     0xce2aa8: add             x1, x1, HEAP, lsl #32
    // 0xce2aac: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xce2ab0: cmp             w1, w16
    // 0xce2ab4: b.eq            #0xce2b1c
    // 0xce2ab8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xce2ab8: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xce2abc: r0 = reverse()
    //     0xce2abc: bl              #0x8c8688  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0xce2ac0: ldur            x1, [fp, #-0x10]
    // 0xce2ac4: r0 = shouldShowValueIndicatorWhenDragged()
    //     0xce2ac4: bl              #0xc23dc4  ; [package:flutter/src/material/slider.dart] _RenderSlider::shouldShowValueIndicatorWhenDragged
    // 0xce2ac8: tbnz            w0, #4, #0xce2aec
    // 0xce2acc: ldur            x0, [fp, #-8]
    // 0xce2ad0: LoadField: r1 = r0->field_1f
    //     0xce2ad0: ldur            w1, [x0, #0x1f]
    // 0xce2ad4: DecompressPointer r1
    //     0xce2ad4: add             x1, x1, HEAP, lsl #32
    // 0xce2ad8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xce2adc: cmp             w1, w16
    // 0xce2ae0: b.eq            #0xce2b28
    // 0xce2ae4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xce2ae4: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xce2ae8: r0 = reverse()
    //     0xce2ae8: bl              #0x8c8688  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0xce2aec: r0 = Null
    //     0xce2aec: mov             x0, NULL
    // 0xce2af0: LeaveFrame
    //     0xce2af0: mov             SP, fp
    //     0xce2af4: ldp             fp, lr, [SP], #0x10
    // 0xce2af8: ret
    //     0xce2af8: ret             
    // 0xce2afc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce2afc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce2b00: b               #0xce2a3c
    // 0xce2b04: r9 = overlayController
    //     0xce2b04: add             x9, PP, #0x99, lsl #12  ; [pp+0x99000] Field <_SliderState@125231897.overlayController>: late (offset: 0x1c)
    //     0xce2b08: ldr             x9, [x9]
    // 0xce2b0c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xce2b0c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xce2b10: r9 = valueIndicatorController
    //     0xce2b10: add             x9, PP, #0x99, lsl #12  ; [pp+0x99008] Field <_SliderState@125231897.valueIndicatorController>: late (offset: 0x20)
    //     0xce2b14: ldr             x9, [x9, #8]
    // 0xce2b18: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xce2b18: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xce2b1c: r9 = overlayController
    //     0xce2b1c: add             x9, PP, #0x99, lsl #12  ; [pp+0x99000] Field <_SliderState@125231897.overlayController>: late (offset: 0x1c)
    //     0xce2b20: ldr             x9, [x9]
    // 0xce2b24: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xce2b24: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xce2b28: r9 = valueIndicatorController
    //     0xce2b28: add             x9, PP, #0x99, lsl #12  ; [pp+0x99008] Field <_SliderState@125231897.valueIndicatorController>: late (offset: 0x20)
    //     0xce2b2c: ldr             x9, [x9, #8]
    // 0xce2b30: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xce2b30: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  set _ textDirection=(/* No info */) {
    // ** addr: 0xce2b34, size: 0x70
    // 0xce2b34: EnterFrame
    //     0xce2b34: stp             fp, lr, [SP, #-0x10]!
    //     0xce2b38: mov             fp, SP
    // 0xce2b3c: mov             x0, x2
    // 0xce2b40: CheckStackOverflow
    //     0xce2b40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce2b44: cmp             SP, x16
    //     0xce2b48: b.ls            #0xce2b9c
    // 0xce2b4c: LoadField: r2 = r1->field_bf
    //     0xce2b4c: ldur            w2, [x1, #0xbf]
    // 0xce2b50: DecompressPointer r2
    //     0xce2b50: add             x2, x2, HEAP, lsl #32
    // 0xce2b54: cmp             w0, w2
    // 0xce2b58: b.ne            #0xce2b6c
    // 0xce2b5c: r0 = Null
    //     0xce2b5c: mov             x0, NULL
    // 0xce2b60: LeaveFrame
    //     0xce2b60: mov             SP, fp
    //     0xce2b64: ldp             fp, lr, [SP], #0x10
    // 0xce2b68: ret
    //     0xce2b68: ret             
    // 0xce2b6c: StoreField: r1->field_bf = r0
    //     0xce2b6c: stur            w0, [x1, #0xbf]
    //     0xce2b70: ldurb           w16, [x1, #-1]
    //     0xce2b74: ldurb           w17, [x0, #-1]
    //     0xce2b78: and             x16, x17, x16, lsr #2
    //     0xce2b7c: tst             x16, HEAP, lsr #32
    //     0xce2b80: b.eq            #0xce2b88
    //     0xce2b84: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xce2b88: r0 = _updateLabelPainter()
    //     0xce2b88: bl              #0xc06a40  ; [package:flutter/src/material/slider.dart] _RenderSlider::_updateLabelPainter
    // 0xce2b8c: r0 = Null
    //     0xce2b8c: mov             x0, NULL
    // 0xce2b90: LeaveFrame
    //     0xce2b90: mov             SP, fp
    //     0xce2b94: ldp             fp, lr, [SP], #0x10
    // 0xce2b98: ret
    //     0xce2b98: ret             
    // 0xce2b9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce2b9c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce2ba0: b               #0xce2b4c
  }
  set _ onChanged=(/* No info */) {
    // ** addr: 0xce2ba4, size: 0x158
    // 0xce2ba4: EnterFrame
    //     0xce2ba4: stp             fp, lr, [SP, #-0x10]!
    //     0xce2ba8: mov             fp, SP
    // 0xce2bac: AllocStack(0x20)
    //     0xce2bac: sub             SP, SP, #0x20
    // 0xce2bb0: SetupParameters(_RenderSlider this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xce2bb0: stur            x1, [fp, #-8]
    //     0xce2bb4: mov             x16, x2
    //     0xce2bb8: mov             x2, x1
    //     0xce2bbc: mov             x1, x16
    //     0xce2bc0: stur            x1, [fp, #-0x10]
    // 0xce2bc4: CheckStackOverflow
    //     0xce2bc4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce2bc8: cmp             SP, x16
    //     0xce2bcc: b.ls            #0xce2cdc
    // 0xce2bd0: LoadField: r0 = r2->field_b3
    //     0xce2bd0: ldur            w0, [x2, #0xb3]
    // 0xce2bd4: DecompressPointer r0
    //     0xce2bd4: add             x0, x0, HEAP, lsl #32
    // 0xce2bd8: r3 = LoadClassIdInstr(r1)
    //     0xce2bd8: ldur            x3, [x1, #-1]
    //     0xce2bdc: ubfx            x3, x3, #0xc, #0x14
    // 0xce2be0: stp             x0, x1, [SP]
    // 0xce2be4: mov             x0, x3
    // 0xce2be8: mov             lr, x0
    // 0xce2bec: ldr             lr, [x21, lr, lsl #3]
    // 0xce2bf0: blr             lr
    // 0xce2bf4: tbnz            w0, #4, #0xce2c08
    // 0xce2bf8: r0 = Null
    //     0xce2bf8: mov             x0, NULL
    // 0xce2bfc: LeaveFrame
    //     0xce2bfc: mov             SP, fp
    //     0xce2c00: ldp             fp, lr, [SP], #0x10
    // 0xce2c04: ret
    //     0xce2c04: ret             
    // 0xce2c08: ldur            x2, [fp, #-8]
    // 0xce2c0c: ldur            x1, [fp, #-0x10]
    // 0xce2c10: LoadField: r0 = r2->field_b3
    //     0xce2c10: ldur            w0, [x2, #0xb3]
    // 0xce2c14: DecompressPointer r0
    //     0xce2c14: add             x0, x0, HEAP, lsl #32
    // 0xce2c18: cmp             w0, NULL
    // 0xce2c1c: r16 = true
    //     0xce2c1c: add             x16, NULL, #0x20  ; true
    // 0xce2c20: r17 = false
    //     0xce2c20: add             x17, NULL, #0x30  ; false
    // 0xce2c24: csel            x3, x16, x17, ne
    // 0xce2c28: mov             x0, x1
    // 0xce2c2c: StoreField: r2->field_b3 = r0
    //     0xce2c2c: stur            w0, [x2, #0xb3]
    //     0xce2c30: ldurb           w16, [x2, #-1]
    //     0xce2c34: ldurb           w17, [x0, #-1]
    //     0xce2c38: and             x16, x17, x16, lsr #2
    //     0xce2c3c: tst             x16, HEAP, lsr #32
    //     0xce2c40: b.eq            #0xce2c48
    //     0xce2c44: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xce2c48: cmp             w1, NULL
    // 0xce2c4c: r16 = true
    //     0xce2c4c: add             x16, NULL, #0x20  ; true
    // 0xce2c50: r17 = false
    //     0xce2c50: add             x17, NULL, #0x30  ; false
    // 0xce2c54: csel            x0, x16, x17, ne
    // 0xce2c58: cmp             w3, w0
    // 0xce2c5c: b.eq            #0xce2ccc
    // 0xce2c60: cmp             w1, NULL
    // 0xce2c64: b.eq            #0xce2c90
    // 0xce2c68: LoadField: r0 = r2->field_53
    //     0xce2c68: ldur            w0, [x2, #0x53]
    // 0xce2c6c: DecompressPointer r0
    //     0xce2c6c: add             x0, x0, HEAP, lsl #32
    // 0xce2c70: LoadField: r1 = r0->field_23
    //     0xce2c70: ldur            w1, [x0, #0x23]
    // 0xce2c74: DecompressPointer r1
    //     0xce2c74: add             x1, x1, HEAP, lsl #32
    // 0xce2c78: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xce2c7c: cmp             w1, w16
    // 0xce2c80: b.eq            #0xce2ce4
    // 0xce2c84: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xce2c84: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xce2c88: r0 = forward()
    //     0xce2c88: bl              #0x8cd83c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0xce2c8c: b               #0xce2cbc
    // 0xce2c90: mov             x0, x2
    // 0xce2c94: LoadField: r1 = r0->field_53
    //     0xce2c94: ldur            w1, [x0, #0x53]
    // 0xce2c98: DecompressPointer r1
    //     0xce2c98: add             x1, x1, HEAP, lsl #32
    // 0xce2c9c: LoadField: r2 = r1->field_23
    //     0xce2c9c: ldur            w2, [x1, #0x23]
    // 0xce2ca0: DecompressPointer r2
    //     0xce2ca0: add             x2, x2, HEAP, lsl #32
    // 0xce2ca4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xce2ca8: cmp             w2, w16
    // 0xce2cac: b.eq            #0xce2cf0
    // 0xce2cb0: mov             x1, x2
    // 0xce2cb4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xce2cb4: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xce2cb8: r0 = reverse()
    //     0xce2cb8: bl              #0x8c8688  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0xce2cbc: ldur            x1, [fp, #-8]
    // 0xce2cc0: r0 = markNeedsPaint()
    //     0xce2cc0: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xce2cc4: ldur            x1, [fp, #-8]
    // 0xce2cc8: r0 = markNeedsSemanticsUpdate()
    //     0xce2cc8: bl              #0x8373c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0xce2ccc: r0 = Null
    //     0xce2ccc: mov             x0, NULL
    // 0xce2cd0: LeaveFrame
    //     0xce2cd0: mov             SP, fp
    //     0xce2cd4: ldp             fp, lr, [SP], #0x10
    // 0xce2cd8: ret
    //     0xce2cd8: ret             
    // 0xce2cdc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce2cdc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce2ce0: b               #0xce2bd0
    // 0xce2ce4: r9 = enableController
    //     0xce2ce4: add             x9, PP, #0x99, lsl #12  ; [pp+0x99010] Field <_SliderState@125231897.enableController>: late (offset: 0x24)
    //     0xce2ce8: ldr             x9, [x9, #0x10]
    // 0xce2cec: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xce2cec: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xce2cf0: r9 = enableController
    //     0xce2cf0: add             x9, PP, #0x99, lsl #12  ; [pp+0x99010] Field <_SliderState@125231897.enableController>: late (offset: 0x24)
    //     0xce2cf4: ldr             x9, [x9, #0x10]
    // 0xce2cf8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xce2cf8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  set _ screenSize=(/* No info */) {
    // ** addr: 0xce2cfc, size: 0x88
    // 0xce2cfc: EnterFrame
    //     0xce2cfc: stp             fp, lr, [SP, #-0x10]!
    //     0xce2d00: mov             fp, SP
    // 0xce2d04: mov             x0, x2
    // 0xce2d08: CheckStackOverflow
    //     0xce2d08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce2d0c: cmp             SP, x16
    //     0xce2d10: b.ls            #0xce2d7c
    // 0xce2d14: LoadField: r2 = r1->field_af
    //     0xce2d14: ldur            w2, [x1, #0xaf]
    // 0xce2d18: DecompressPointer r2
    //     0xce2d18: add             x2, x2, HEAP, lsl #32
    // 0xce2d1c: LoadField: d0 = r2->field_7
    //     0xce2d1c: ldur            d0, [x2, #7]
    // 0xce2d20: LoadField: d1 = r0->field_7
    //     0xce2d20: ldur            d1, [x0, #7]
    // 0xce2d24: fcmp            d0, d1
    // 0xce2d28: b.ne            #0xce2d4c
    // 0xce2d2c: LoadField: d0 = r2->field_f
    //     0xce2d2c: ldur            d0, [x2, #0xf]
    // 0xce2d30: LoadField: d1 = r0->field_f
    //     0xce2d30: ldur            d1, [x0, #0xf]
    // 0xce2d34: fcmp            d0, d1
    // 0xce2d38: b.ne            #0xce2d4c
    // 0xce2d3c: r0 = Null
    //     0xce2d3c: mov             x0, NULL
    // 0xce2d40: LeaveFrame
    //     0xce2d40: mov             SP, fp
    //     0xce2d44: ldp             fp, lr, [SP], #0x10
    // 0xce2d48: ret
    //     0xce2d48: ret             
    // 0xce2d4c: StoreField: r1->field_af = r0
    //     0xce2d4c: stur            w0, [x1, #0xaf]
    //     0xce2d50: ldurb           w16, [x1, #-1]
    //     0xce2d54: ldurb           w17, [x0, #-1]
    //     0xce2d58: and             x16, x17, x16, lsr #2
    //     0xce2d5c: tst             x16, HEAP, lsr #32
    //     0xce2d60: b.eq            #0xce2d68
    //     0xce2d64: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xce2d68: r0 = markNeedsPaint()
    //     0xce2d68: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xce2d6c: r0 = Null
    //     0xce2d6c: mov             x0, NULL
    // 0xce2d70: LeaveFrame
    //     0xce2d70: mov             SP, fp
    //     0xce2d74: ldp             fp, lr, [SP], #0x10
    // 0xce2d78: ret
    //     0xce2d78: ret             
    // 0xce2d7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce2d7c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce2d80: b               #0xce2d14
  }
  set void textScaleFactor=(_RenderSlider, double) {
    // ** addr: 0xce2d84, size: 0x50
    // 0xce2d84: EnterFrame
    //     0xce2d84: stp             fp, lr, [SP, #-0x10]!
    //     0xce2d88: mov             fp, SP
    // 0xce2d8c: CheckStackOverflow
    //     0xce2d8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce2d90: cmp             SP, x16
    //     0xce2d94: b.ls            #0xce2dcc
    // 0xce2d98: LoadField: d1 = r1->field_a7
    //     0xce2d98: ldur            d1, [x1, #0xa7]
    // 0xce2d9c: fcmp            d0, d1
    // 0xce2da0: b.ne            #0xce2db4
    // 0xce2da4: r0 = Null
    //     0xce2da4: mov             x0, NULL
    // 0xce2da8: LeaveFrame
    //     0xce2da8: mov             SP, fp
    //     0xce2dac: ldp             fp, lr, [SP], #0x10
    // 0xce2db0: ret
    //     0xce2db0: ret             
    // 0xce2db4: StoreField: r1->field_a7 = d0
    //     0xce2db4: stur            d0, [x1, #0xa7]
    // 0xce2db8: r0 = _updateLabelPainter()
    //     0xce2db8: bl              #0xc06a40  ; [package:flutter/src/material/slider.dart] _RenderSlider::_updateLabelPainter
    // 0xce2dbc: r0 = Null
    //     0xce2dbc: mov             x0, NULL
    // 0xce2dc0: LeaveFrame
    //     0xce2dc0: mov             SP, fp
    //     0xce2dc4: ldp             fp, lr, [SP], #0x10
    // 0xce2dc8: ret
    //     0xce2dc8: ret             
    // 0xce2dcc: r0 = StackOverflowSharedWithFPURegs()
    //     0xce2dcc: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xce2dd0: b               #0xce2d98
  }
  set _ sliderTheme=(/* No info */) {
    // ** addr: 0xce2dd4, size: 0x88
    // 0xce2dd4: EnterFrame
    //     0xce2dd4: stp             fp, lr, [SP, #-0x10]!
    //     0xce2dd8: mov             fp, SP
    // 0xce2ddc: AllocStack(0x20)
    //     0xce2ddc: sub             SP, SP, #0x20
    // 0xce2de0: SetupParameters(_RenderSlider this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xce2de0: mov             x0, x2
    //     0xce2de4: stur            x1, [fp, #-8]
    //     0xce2de8: stur            x2, [fp, #-0x10]
    // 0xce2dec: CheckStackOverflow
    //     0xce2dec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce2df0: cmp             SP, x16
    //     0xce2df4: b.ls            #0xce2e54
    // 0xce2df8: LoadField: r2 = r1->field_a3
    //     0xce2df8: ldur            w2, [x1, #0xa3]
    // 0xce2dfc: DecompressPointer r2
    //     0xce2dfc: add             x2, x2, HEAP, lsl #32
    // 0xce2e00: stp             x2, x0, [SP]
    // 0xce2e04: r0 = ==()
    //     0xce2e04: bl              #0x1271b94  ; [package:flutter/src/material/slider_theme.dart] SliderThemeData::==
    // 0xce2e08: tbnz            w0, #4, #0xce2e1c
    // 0xce2e0c: r0 = Null
    //     0xce2e0c: mov             x0, NULL
    // 0xce2e10: LeaveFrame
    //     0xce2e10: mov             SP, fp
    //     0xce2e14: ldp             fp, lr, [SP], #0x10
    // 0xce2e18: ret
    //     0xce2e18: ret             
    // 0xce2e1c: ldur            x1, [fp, #-8]
    // 0xce2e20: ldur            x0, [fp, #-0x10]
    // 0xce2e24: StoreField: r1->field_a3 = r0
    //     0xce2e24: stur            w0, [x1, #0xa3]
    //     0xce2e28: ldurb           w16, [x1, #-1]
    //     0xce2e2c: ldurb           w17, [x0, #-1]
    //     0xce2e30: and             x16, x17, x16, lsr #2
    //     0xce2e34: tst             x16, HEAP, lsr #32
    //     0xce2e38: b.eq            #0xce2e40
    //     0xce2e3c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xce2e40: r0 = _updateLabelPainter()
    //     0xce2e40: bl              #0xc06a40  ; [package:flutter/src/material/slider.dart] _RenderSlider::_updateLabelPainter
    // 0xce2e44: r0 = Null
    //     0xce2e44: mov             x0, NULL
    // 0xce2e48: LeaveFrame
    //     0xce2e48: mov             SP, fp
    //     0xce2e4c: ldp             fp, lr, [SP], #0x10
    // 0xce2e50: ret
    //     0xce2e50: ret             
    // 0xce2e54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce2e54: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce2e58: b               #0xce2df8
  }
  set _ label=(/* No info */) {
    // ** addr: 0xce2e5c, size: 0xa4
    // 0xce2e5c: EnterFrame
    //     0xce2e5c: stp             fp, lr, [SP, #-0x10]!
    //     0xce2e60: mov             fp, SP
    // 0xce2e64: AllocStack(0x20)
    //     0xce2e64: sub             SP, SP, #0x20
    // 0xce2e68: SetupParameters(_RenderSlider this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xce2e68: stur            x1, [fp, #-8]
    //     0xce2e6c: mov             x16, x2
    //     0xce2e70: mov             x2, x1
    //     0xce2e74: mov             x1, x16
    //     0xce2e78: stur            x1, [fp, #-0x10]
    // 0xce2e7c: CheckStackOverflow
    //     0xce2e7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce2e80: cmp             SP, x16
    //     0xce2e84: b.ls            #0xce2ef8
    // 0xce2e88: LoadField: r0 = r2->field_9f
    //     0xce2e88: ldur            w0, [x2, #0x9f]
    // 0xce2e8c: DecompressPointer r0
    //     0xce2e8c: add             x0, x0, HEAP, lsl #32
    // 0xce2e90: r3 = LoadClassIdInstr(r1)
    //     0xce2e90: ldur            x3, [x1, #-1]
    //     0xce2e94: ubfx            x3, x3, #0xc, #0x14
    // 0xce2e98: stp             x0, x1, [SP]
    // 0xce2e9c: mov             x0, x3
    // 0xce2ea0: mov             lr, x0
    // 0xce2ea4: ldr             lr, [x21, lr, lsl #3]
    // 0xce2ea8: blr             lr
    // 0xce2eac: tbnz            w0, #4, #0xce2ec0
    // 0xce2eb0: r0 = Null
    //     0xce2eb0: mov             x0, NULL
    // 0xce2eb4: LeaveFrame
    //     0xce2eb4: mov             SP, fp
    //     0xce2eb8: ldp             fp, lr, [SP], #0x10
    // 0xce2ebc: ret
    //     0xce2ebc: ret             
    // 0xce2ec0: ldur            x1, [fp, #-8]
    // 0xce2ec4: ldur            x0, [fp, #-0x10]
    // 0xce2ec8: StoreField: r1->field_9f = r0
    //     0xce2ec8: stur            w0, [x1, #0x9f]
    //     0xce2ecc: ldurb           w16, [x1, #-1]
    //     0xce2ed0: ldurb           w17, [x0, #-1]
    //     0xce2ed4: and             x16, x17, x16, lsr #2
    //     0xce2ed8: tst             x16, HEAP, lsr #32
    //     0xce2edc: b.eq            #0xce2ee4
    //     0xce2ee0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xce2ee4: r0 = _updateLabelPainter()
    //     0xce2ee4: bl              #0xc06a40  ; [package:flutter/src/material/slider.dart] _RenderSlider::_updateLabelPainter
    // 0xce2ee8: r0 = Null
    //     0xce2ee8: mov             x0, NULL
    // 0xce2eec: LeaveFrame
    //     0xce2eec: mov             SP, fp
    //     0xce2ef0: ldp             fp, lr, [SP], #0x10
    // 0xce2ef4: ret
    //     0xce2ef4: ret             
    // 0xce2ef8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce2ef8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce2efc: b               #0xce2e88
  }
  set _ divisions=(/* No info */) {
    // ** addr: 0xce2f00, size: 0x50
    // 0xce2f00: EnterFrame
    //     0xce2f00: stp             fp, lr, [SP, #-0x10]!
    //     0xce2f04: mov             fp, SP
    // 0xce2f08: CheckStackOverflow
    //     0xce2f08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce2f0c: cmp             SP, x16
    //     0xce2f10: b.ls            #0xce2f48
    // 0xce2f14: LoadField: r0 = r1->field_97
    //     0xce2f14: ldur            x0, [x1, #0x97]
    // 0xce2f18: cmp             x2, x0
    // 0xce2f1c: b.ne            #0xce2f30
    // 0xce2f20: r0 = Null
    //     0xce2f20: mov             x0, NULL
    // 0xce2f24: LeaveFrame
    //     0xce2f24: mov             SP, fp
    //     0xce2f28: ldp             fp, lr, [SP], #0x10
    // 0xce2f2c: ret
    //     0xce2f2c: ret             
    // 0xce2f30: StoreField: r1->field_97 = r2
    //     0xce2f30: stur            x2, [x1, #0x97]
    // 0xce2f34: r0 = markNeedsPaint()
    //     0xce2f34: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xce2f38: r0 = Null
    //     0xce2f38: mov             x0, NULL
    // 0xce2f3c: LeaveFrame
    //     0xce2f3c: mov             SP, fp
    //     0xce2f40: ldp             fp, lr, [SP], #0x10
    // 0xce2f44: ret
    //     0xce2f44: ret             
    // 0xce2f48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce2f48: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce2f4c: b               #0xce2f14
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x10f0060, size: 0x24
    // 0x10f0060: EnterFrame
    //     0x10f0060: stp             fp, lr, [SP, #-0x10]!
    //     0x10f0064: mov             fp, SP
    // 0x10f0068: ldr             x2, [fp, #0x10]
    // 0x10f006c: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x10f006c: add             x1, PP, #0xad, lsl #12  ; [pp+0xad6f8] AnonymousClosure: (0x10f0084), in [package:flutter/src/material/slider.dart] _RenderSlider::computeMaxIntrinsicHeight (0xb2b248)
    //     0x10f0070: ldr             x1, [x1, #0x6f8]
    // 0x10f0074: r0 = AllocateClosure()
    //     0x10f0074: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10f0078: LeaveFrame
    //     0x10f0078: mov             SP, fp
    //     0x10f007c: ldp             fp, lr, [SP], #0x10
    // 0x10f0080: ret
    //     0x10f0080: ret             
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0x10f0084, size: 0x78
    // 0x10f0084: EnterFrame
    //     0x10f0084: stp             fp, lr, [SP, #-0x10]!
    //     0x10f0088: mov             fp, SP
    // 0x10f008c: ldr             x0, [fp, #0x18]
    // 0x10f0090: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x10f0090: ldur            w1, [x0, #0x17]
    // 0x10f0094: DecompressPointer r1
    //     0x10f0094: add             x1, x1, HEAP, lsl #32
    // 0x10f0098: CheckStackOverflow
    //     0x10f0098: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f009c: cmp             SP, x16
    //     0x10f00a0: b.ls            #0x10f00e4
    // 0x10f00a4: ldr             x2, [fp, #0x10]
    // 0x10f00a8: r0 = computeMaxIntrinsicHeight()
    //     0x10f00a8: bl              #0xb2b248  ; [package:flutter/src/material/slider.dart] _RenderSlider::computeMaxIntrinsicHeight
    // 0x10f00ac: r0 = inline_Allocate_Double()
    //     0x10f00ac: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x10f00b0: add             x0, x0, #0x10
    //     0x10f00b4: cmp             x1, x0
    //     0x10f00b8: b.ls            #0x10f00ec
    //     0x10f00bc: str             x0, [THR, #0x60]  ; THR::top
    //     0x10f00c0: sub             x0, x0, #0xf
    //     0x10f00c4: mov             x1, #0xe19c
    //     0x10f00c8: movk            x1, #3, lsl #16
    //     0x10f00cc: stur            x1, [x0, #-1]
    // 0x10f00d0: dmb             ishst
    // 0x10f00d4: StoreField: r0->field_7 = d0
    //     0x10f00d4: stur            d0, [x0, #7]
    // 0x10f00d8: LeaveFrame
    //     0x10f00d8: mov             SP, fp
    //     0x10f00dc: ldp             fp, lr, [SP], #0x10
    // 0x10f00e0: ret
    //     0x10f00e0: ret             
    // 0x10f00e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10f00e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10f00e8: b               #0x10f00a4
    // 0x10f00ec: SaveReg d0
    //     0x10f00ec: str             q0, [SP, #-0x10]!
    // 0x10f00f0: r0 = AllocateDouble()
    //     0x10f00f0: bl              #0x13df878  ; AllocateDoubleStub
    // 0x10f00f4: RestoreReg d0
    //     0x10f00f4: ldr             q0, [SP], #0x10
    // 0x10f00f8: b               #0x10f00d4
  }
  _ _RenderSlider(/* No info */) {
    // ** addr: 0x11bfb70, size: 0x600
    // 0x11bfb70: EnterFrame
    //     0x11bfb70: stp             fp, lr, [SP, #-0x10]!
    //     0x11bfb74: mov             fp, SP
    // 0x11bfb78: AllocStack(0x58)
    //     0x11bfb78: sub             SP, SP, #0x58
    // 0x11bfb7c: ldr             x4, [THR, #0x90]  ; THR::object_sentinel
    // 0x11bfb80: r0 = false
    //     0x11bfb80: add             x0, NULL, #0x30  ; false
    // 0x11bfb84: stur            x1, [fp, #-8]
    // 0x11bfb88: mov             x16, x7
    // 0x11bfb8c: mov             x7, x1
    // 0x11bfb90: mov             x1, x16
    // 0x11bfb94: stur            x2, [fp, #-0x10]
    // 0x11bfb98: mov             x16, x3
    // 0x11bfb9c: mov             x3, x2
    // 0x11bfba0: mov             x2, x16
    // 0x11bfba4: stur            x2, [fp, #-0x18]
    // 0x11bfba8: stur            x5, [fp, #-0x20]
    // 0x11bfbac: stur            x6, [fp, #-0x28]
    // 0x11bfbb0: stur            x1, [fp, #-0x30]
    // 0x11bfbb4: stur            d0, [fp, #-0x40]
    // 0x11bfbb8: stur            d1, [fp, #-0x48]
    // 0x11bfbbc: CheckStackOverflow
    //     0x11bfbbc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11bfbc0: cmp             SP, x16
    //     0x11bfbc4: b.ls            #0x11c0144
    // 0x11bfbc8: StoreField: r7->field_57 = r4
    //     0x11bfbc8: stur            w4, [x7, #0x57]
    // 0x11bfbcc: StoreField: r7->field_5b = r4
    //     0x11bfbcc: stur            w4, [x7, #0x5b]
    // 0x11bfbd0: StoreField: r7->field_5f = r4
    //     0x11bfbd0: stur            w4, [x7, #0x5f]
    // 0x11bfbd4: StoreField: r7->field_67 = r4
    //     0x11bfbd4: stur            w4, [x7, #0x67]
    // 0x11bfbd8: StoreField: r7->field_6b = r4
    //     0x11bfbd8: stur            w4, [x7, #0x6b]
    // 0x11bfbdc: StoreField: r7->field_6f = r0
    //     0x11bfbdc: stur            w0, [x7, #0x6f]
    // 0x11bfbe0: StoreField: r7->field_77 = rZR
    //     0x11bfbe0: stur            xzr, [x7, #0x77]
    // 0x11bfbe4: StoreField: r7->field_cb = r0
    //     0x11bfbe4: stur            w0, [x7, #0xcb]
    // 0x11bfbe8: r0 = TextPainter()
    //     0x11bfbe8: bl              #0xb13a1c  ; AllocateTextPainterStub -> TextPainter (size=0x48)
    // 0x11bfbec: mov             x1, x0
    // 0x11bfbf0: stur            x0, [fp, #-0x38]
    // 0x11bfbf4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x11bfbf4: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x11bfbf8: r0 = TextPainter()
    //     0x11bfbf8: bl              #0xb135d4  ; [package:flutter/src/painting/text_painter.dart] TextPainter::TextPainter
    // 0x11bfbfc: ldur            x0, [fp, #-0x38]
    // 0x11bfc00: ldur            x1, [fp, #-8]
    // 0x11bfc04: StoreField: r1->field_63 = r0
    //     0x11bfc04: stur            w0, [x1, #0x63]
    //     0x11bfc08: ldurb           w16, [x1, #-1]
    //     0x11bfc0c: ldurb           w17, [x0, #-1]
    //     0x11bfc10: and             x16, x17, x16, lsr #2
    //     0x11bfc14: tst             x16, HEAP, lsr #32
    //     0x11bfc18: b.eq            #0x11bfc20
    //     0x11bfc1c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11bfc20: ldr             x0, [fp, #0x30]
    // 0x11bfc24: StoreField: r1->field_73 = r0
    //     0x11bfc24: stur            w0, [x1, #0x73]
    //     0x11bfc28: ldurb           w16, [x1, #-1]
    //     0x11bfc2c: ldurb           w17, [x0, #-1]
    //     0x11bfc30: and             x16, x17, x16, lsr #2
    //     0x11bfc34: tst             x16, HEAP, lsr #32
    //     0x11bfc38: b.eq            #0x11bfc40
    //     0x11bfc3c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11bfc40: ldr             x0, [fp, #0x40]
    // 0x11bfc44: StoreField: r1->field_b7 = r0
    //     0x11bfc44: stur            w0, [x1, #0xb7]
    //     0x11bfc48: ldurb           w16, [x1, #-1]
    //     0x11bfc4c: ldurb           w17, [x0, #-1]
    //     0x11bfc50: and             x16, x17, x16, lsr #2
    //     0x11bfc54: tst             x16, HEAP, lsr #32
    //     0x11bfc58: b.eq            #0x11bfc60
    //     0x11bfc5c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11bfc60: ldr             x0, [fp, #0x48]
    // 0x11bfc64: StoreField: r1->field_bb = r0
    //     0x11bfc64: stur            w0, [x1, #0xbb]
    //     0x11bfc68: ldurb           w16, [x1, #-1]
    //     0x11bfc6c: ldurb           w17, [x0, #-1]
    //     0x11bfc70: and             x16, x17, x16, lsr #2
    //     0x11bfc74: tst             x16, HEAP, lsr #32
    //     0x11bfc78: b.eq            #0x11bfc80
    //     0x11bfc7c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11bfc80: r0 = Instance_TargetPlatform
    //     0x11bfc80: add             x0, PP, #0x12, lsl #12  ; [pp+0x12940] Obj!TargetPlatform@12c5e81
    //     0x11bfc84: ldr             x0, [x0, #0x940]
    // 0x11bfc88: StoreField: r1->field_8f = r0
    //     0x11bfc88: stur            w0, [x1, #0x8f]
    // 0x11bfc8c: ldur            x0, [fp, #-0x30]
    // 0x11bfc90: StoreField: r1->field_9f = r0
    //     0x11bfc90: stur            w0, [x1, #0x9f]
    //     0x11bfc94: ldurb           w16, [x1, #-1]
    //     0x11bfc98: ldurb           w17, [x0, #-1]
    //     0x11bfc9c: and             x16, x17, x16, lsr #2
    //     0x11bfca0: tst             x16, HEAP, lsr #32
    //     0x11bfca4: b.eq            #0x11bfcac
    //     0x11bfca8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11bfcac: ldur            d0, [fp, #-0x48]
    // 0x11bfcb0: StoreField: r1->field_83 = d0
    //     0x11bfcb0: stur            d0, [x1, #0x83]
    // 0x11bfcb4: ldur            x0, [fp, #-0x10]
    // 0x11bfcb8: StoreField: r1->field_97 = r0
    //     0x11bfcb8: stur            x0, [x1, #0x97]
    // 0x11bfcbc: ldr             x0, [fp, #0x20]
    // 0x11bfcc0: StoreField: r1->field_a3 = r0
    //     0x11bfcc0: stur            w0, [x1, #0xa3]
    //     0x11bfcc4: ldurb           w16, [x1, #-1]
    //     0x11bfcc8: ldurb           w17, [x0, #-1]
    //     0x11bfccc: and             x16, x17, x16, lsr #2
    //     0x11bfcd0: tst             x16, HEAP, lsr #32
    //     0x11bfcd4: b.eq            #0x11bfcdc
    //     0x11bfcd8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11bfcdc: ldur            d0, [fp, #-0x40]
    // 0x11bfce0: StoreField: r1->field_a7 = d0
    //     0x11bfce0: stur            d0, [x1, #0xa7]
    // 0x11bfce4: ldr             x0, [fp, #0x28]
    // 0x11bfce8: StoreField: r1->field_af = r0
    //     0x11bfce8: stur            w0, [x1, #0xaf]
    //     0x11bfcec: ldurb           w16, [x1, #-1]
    //     0x11bfcf0: ldurb           w17, [x0, #-1]
    //     0x11bfcf4: and             x16, x17, x16, lsr #2
    //     0x11bfcf8: tst             x16, HEAP, lsr #32
    //     0x11bfcfc: b.eq            #0x11bfd04
    //     0x11bfd00: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11bfd04: ldr             x0, [fp, #0x38]
    // 0x11bfd08: StoreField: r1->field_b3 = r0
    //     0x11bfd08: stur            w0, [x1, #0xb3]
    //     0x11bfd0c: ldurb           w16, [x1, #-1]
    //     0x11bfd10: ldurb           w17, [x0, #-1]
    //     0x11bfd14: and             x16, x17, x16, lsr #2
    //     0x11bfd18: tst             x16, HEAP, lsr #32
    //     0x11bfd1c: b.eq            #0x11bfd24
    //     0x11bfd20: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11bfd24: ldr             x0, [fp, #0x18]
    // 0x11bfd28: StoreField: r1->field_53 = r0
    //     0x11bfd28: stur            w0, [x1, #0x53]
    //     0x11bfd2c: ldurb           w16, [x1, #-1]
    //     0x11bfd30: ldurb           w17, [x0, #-1]
    //     0x11bfd34: and             x16, x17, x16, lsr #2
    //     0x11bfd38: tst             x16, HEAP, lsr #32
    //     0x11bfd3c: b.eq            #0x11bfd44
    //     0x11bfd40: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11bfd44: ldr             x0, [fp, #0x10]
    // 0x11bfd48: StoreField: r1->field_bf = r0
    //     0x11bfd48: stur            w0, [x1, #0xbf]
    //     0x11bfd4c: ldurb           w16, [x1, #-1]
    //     0x11bfd50: ldurb           w17, [x0, #-1]
    //     0x11bfd54: and             x16, x17, x16, lsr #2
    //     0x11bfd58: tst             x16, HEAP, lsr #32
    //     0x11bfd5c: b.eq            #0x11bfd64
    //     0x11bfd60: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11bfd64: ldur            x0, [fp, #-0x20]
    // 0x11bfd68: StoreField: r1->field_c3 = r0
    //     0x11bfd68: stur            w0, [x1, #0xc3]
    // 0x11bfd6c: ldur            x0, [fp, #-0x28]
    // 0x11bfd70: StoreField: r1->field_c7 = r0
    //     0x11bfd70: stur            w0, [x1, #0xc7]
    // 0x11bfd74: r0 = Instance_SliderInteraction
    //     0x11bfd74: add             x0, PP, #0x98, lsl #12  ; [pp+0x98f08] Obj!SliderInteraction@12c4f41
    //     0x11bfd78: ldr             x0, [x0, #0xf08]
    // 0x11bfd7c: StoreField: r1->field_cf = r0
    //     0x11bfd7c: stur            w0, [x1, #0xcf]
    // 0x11bfd80: r0 = false
    //     0x11bfd80: add             x0, NULL, #0x30  ; false
    // 0x11bfd84: StoreField: r1->field_4f = r0
    //     0x11bfd84: stur            w0, [x1, #0x4f]
    // 0x11bfd88: r0 = _LayoutCacheStorage()
    //     0x11bfd88: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11bfd8c: ldur            x2, [fp, #-8]
    // 0x11bfd90: StoreField: r2->field_47 = r0
    //     0x11bfd90: stur            w0, [x2, #0x47]
    //     0x11bfd94: ldurb           w16, [x2, #-1]
    //     0x11bfd98: ldurb           w17, [x0, #-1]
    //     0x11bfd9c: and             x16, x17, x16, lsr #2
    //     0x11bfda0: tst             x16, HEAP, lsr #32
    //     0x11bfda4: b.eq            #0x11bfdac
    //     0x11bfda8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11bfdac: mov             x1, x2
    // 0x11bfdb0: r0 = RenderObject()
    //     0x11bfdb0: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11bfdb4: ldur            x1, [fp, #-8]
    // 0x11bfdb8: r0 = _updateLabelPainter()
    //     0x11bfdb8: bl              #0xc06a40  ; [package:flutter/src/material/slider.dart] _RenderSlider::_updateLabelPainter
    // 0x11bfdbc: r16 = <int, _CombiningGestureArenaMember>
    //     0x11bfdbc: add             x16, PP, #0x97, lsl #12  ; [pp+0x97d10] TypeArguments: <int, _CombiningGestureArenaMember>
    //     0x11bfdc0: ldr             x16, [x16, #0xd10]
    // 0x11bfdc4: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x11bfdc8: stp             lr, x16, [SP]
    // 0x11bfdcc: r0 = Map._fromLiteral()
    //     0x11bfdcc: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x11bfdd0: stur            x0, [fp, #-0x20]
    // 0x11bfdd4: r0 = GestureArenaTeam()
    //     0x11bfdd4: bl              #0xb8d888  ; AllocateGestureArenaTeamStub -> GestureArenaTeam (size=0x10)
    // 0x11bfdd8: mov             x1, x0
    // 0x11bfddc: ldur            x0, [fp, #-0x20]
    // 0x11bfde0: stur            x1, [fp, #-0x28]
    // 0x11bfde4: StoreField: r1->field_7 = r0
    //     0x11bfde4: stur            w0, [x1, #7]
    // 0x11bfde8: r0 = HorizontalDragGestureRecognizer()
    //     0x11bfde8: bl              #0xb8d854  ; AllocateHorizontalDragGestureRecognizerStub -> HorizontalDragGestureRecognizer (size=0x90)
    // 0x11bfdec: mov             x1, x0
    // 0x11bfdf0: r2 = Null
    //     0x11bfdf0: mov             x2, NULL
    // 0x11bfdf4: stur            x0, [fp, #-0x20]
    // 0x11bfdf8: r0 = DragGestureRecognizer()
    //     0x11bfdf8: bl              #0xb8d344  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::DragGestureRecognizer
    // 0x11bfdfc: ldur            x0, [fp, #-0x28]
    // 0x11bfe00: ldur            x3, [fp, #-0x20]
    // 0x11bfe04: StoreField: r3->field_1f = r0
    //     0x11bfe04: stur            w0, [x3, #0x1f]
    //     0x11bfe08: ldurb           w16, [x3, #-1]
    //     0x11bfe0c: ldurb           w17, [x0, #-1]
    //     0x11bfe10: and             x16, x17, x16, lsr #2
    //     0x11bfe14: tst             x16, HEAP, lsr #32
    //     0x11bfe18: b.eq            #0x11bfe20
    //     0x11bfe1c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x11bfe20: ldur            x2, [fp, #-8]
    // 0x11bfe24: r1 = Function '_handleDragStart@125231897':.
    //     0x11bfe24: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3760] AnonymousClosure: (0x11c0988), in [package:flutter/src/material/slider.dart] _RenderSlider::_handleDragStart (0x11c0358)
    //     0x11bfe28: ldr             x1, [x1, #0x760]
    // 0x11bfe2c: r0 = AllocateClosure()
    //     0x11bfe2c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11bfe30: ldur            x3, [fp, #-0x20]
    // 0x11bfe34: StoreField: r3->field_2f = r0
    //     0x11bfe34: stur            w0, [x3, #0x2f]
    //     0x11bfe38: ldurb           w16, [x3, #-1]
    //     0x11bfe3c: ldurb           w17, [x0, #-1]
    //     0x11bfe40: and             x16, x17, x16, lsr #2
    //     0x11bfe44: tst             x16, HEAP, lsr #32
    //     0x11bfe48: b.eq            #0x11bfe50
    //     0x11bfe4c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x11bfe50: ldur            x2, [fp, #-8]
    // 0x11bfe54: r1 = Function '_handleDragUpdate@125231897':.
    //     0x11bfe54: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3768] AnonymousClosure: (0x11c07d4), in [package:flutter/src/material/slider.dart] _RenderSlider::_handleDragUpdate (0x11c0810)
    //     0x11bfe58: ldr             x1, [x1, #0x768]
    // 0x11bfe5c: r0 = AllocateClosure()
    //     0x11bfe5c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11bfe60: ldur            x3, [fp, #-0x20]
    // 0x11bfe64: StoreField: r3->field_33 = r0
    //     0x11bfe64: stur            w0, [x3, #0x33]
    //     0x11bfe68: ldurb           w16, [x3, #-1]
    //     0x11bfe6c: ldurb           w17, [x0, #-1]
    //     0x11bfe70: and             x16, x17, x16, lsr #2
    //     0x11bfe74: tst             x16, HEAP, lsr #32
    //     0x11bfe78: b.eq            #0x11bfe80
    //     0x11bfe7c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x11bfe80: ldur            x2, [fp, #-8]
    // 0x11bfe84: r1 = Function '_handleDragEnd@125231897':.
    //     0x11bfe84: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3770] AnonymousClosure: (0x11c0170), of [package:flutter/src/material/slider.dart] _RenderSlider
    //     0x11bfe88: ldr             x1, [x1, #0x770]
    // 0x11bfe8c: r0 = AllocateClosure()
    //     0x11bfe8c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11bfe90: ldur            x3, [fp, #-0x20]
    // 0x11bfe94: StoreField: r3->field_37 = r0
    //     0x11bfe94: stur            w0, [x3, #0x37]
    //     0x11bfe98: ldurb           w16, [x3, #-1]
    //     0x11bfe9c: ldurb           w17, [x0, #-1]
    //     0x11bfea0: and             x16, x17, x16, lsr #2
    //     0x11bfea4: tst             x16, HEAP, lsr #32
    //     0x11bfea8: b.eq            #0x11bfeb0
    //     0x11bfeac: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x11bfeb0: ldur            x2, [fp, #-8]
    // 0x11bfeb4: r1 = Function '_endInteraction@125231897':.
    //     0x11bfeb4: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3778] AnonymousClosure: (0x11c079c), in [package:flutter/src/material/slider.dart] _RenderSlider::_endInteraction (0x11c01ac)
    //     0x11bfeb8: ldr             x1, [x1, #0x778]
    // 0x11bfebc: r0 = AllocateClosure()
    //     0x11bfebc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11bfec0: ldur            x1, [fp, #-0x20]
    // 0x11bfec4: StoreField: r1->field_3b = r0
    //     0x11bfec4: stur            w0, [x1, #0x3b]
    //     0x11bfec8: ldurb           w16, [x1, #-1]
    //     0x11bfecc: ldurb           w17, [x0, #-1]
    //     0x11bfed0: and             x16, x17, x16, lsr #2
    //     0x11bfed4: tst             x16, HEAP, lsr #32
    //     0x11bfed8: b.eq            #0x11bfee0
    //     0x11bfedc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11bfee0: ldur            x0, [fp, #-0x18]
    // 0x11bfee4: StoreField: r1->field_7 = r0
    //     0x11bfee4: stur            w0, [x1, #7]
    //     0x11bfee8: ldurb           w16, [x1, #-1]
    //     0x11bfeec: ldurb           w17, [x0, #-1]
    //     0x11bfef0: and             x16, x17, x16, lsr #2
    //     0x11bfef4: tst             x16, HEAP, lsr #32
    //     0x11bfef8: b.eq            #0x11bff00
    //     0x11bfefc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11bff00: mov             x0, x1
    // 0x11bff04: ldur            x2, [fp, #-8]
    // 0x11bff08: StoreField: r2->field_67 = r0
    //     0x11bff08: stur            w0, [x2, #0x67]
    //     0x11bff0c: ldurb           w16, [x2, #-1]
    //     0x11bff10: ldurb           w17, [x0, #-1]
    //     0x11bff14: and             x16, x17, x16, lsr #2
    //     0x11bff18: tst             x16, HEAP, lsr #32
    //     0x11bff1c: b.eq            #0x11bff24
    //     0x11bff20: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11bff24: r0 = TapGestureRecognizer()
    //     0x11bff24: bl              #0xc0a29c  ; AllocateTapGestureRecognizerStub -> TapGestureRecognizer (size=0x88)
    // 0x11bff28: stur            x0, [fp, #-0x20]
    // 0x11bff2c: r16 = -1.000000
    //     0x11bff2c: add             x16, PP, #0x13, lsl #12  ; [pp+0x132a8] -1
    //     0x11bff30: ldr             x16, [x16, #0x2a8]
    // 0x11bff34: stp             x16, NULL, [SP]
    // 0x11bff38: mov             x1, x0
    // 0x11bff3c: r4 = const [0, 0x3, 0x2, 0x1, postAcceptSlopTolerance, 0x2, supportedDevices, 0x1, null]
    //     0x11bff3c: add             x4, PP, #0x7a, lsl #12  ; [pp+0x7ab70] List(9) [0, 0x3, 0x2, 0x1, "postAcceptSlopTolerance", 0x2, "supportedDevices", 0x1, Null]
    //     0x11bff40: ldr             x4, [x4, #0xb70]
    // 0x11bff44: r0 = BaseTapGestureRecognizer()
    //     0x11bff44: bl              #0xc0a1bc  ; [package:flutter/src/gestures/tap.dart] BaseTapGestureRecognizer::BaseTapGestureRecognizer
    // 0x11bff48: ldur            x0, [fp, #-0x28]
    // 0x11bff4c: ldur            x3, [fp, #-0x20]
    // 0x11bff50: StoreField: r3->field_1f = r0
    //     0x11bff50: stur            w0, [x3, #0x1f]
    //     0x11bff54: ldurb           w16, [x3, #-1]
    //     0x11bff58: ldurb           w17, [x0, #-1]
    //     0x11bff5c: and             x16, x17, x16, lsr #2
    //     0x11bff60: tst             x16, HEAP, lsr #32
    //     0x11bff64: b.eq            #0x11bff6c
    //     0x11bff68: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x11bff6c: ldur            x2, [fp, #-8]
    // 0x11bff70: r1 = Function '_handleTapDown@125231897':.
    //     0x11bff70: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3780] AnonymousClosure: (0x11c031c), in [package:flutter/src/material/slider.dart] _RenderSlider::_handleDragStart (0x11c0358)
    //     0x11bff74: ldr             x1, [x1, #0x780]
    // 0x11bff78: r0 = AllocateClosure()
    //     0x11bff78: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11bff7c: ldur            x3, [fp, #-0x20]
    // 0x11bff80: StoreField: r3->field_57 = r0
    //     0x11bff80: stur            w0, [x3, #0x57]
    //     0x11bff84: ldurb           w16, [x3, #-1]
    //     0x11bff88: ldurb           w17, [x0, #-1]
    //     0x11bff8c: and             x16, x17, x16, lsr #2
    //     0x11bff90: tst             x16, HEAP, lsr #32
    //     0x11bff94: b.eq            #0x11bff9c
    //     0x11bff98: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x11bff9c: ldur            x2, [fp, #-8]
    // 0x11bffa0: r1 = Function '_handleTapUp@125231897':.
    //     0x11bffa0: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3788] AnonymousClosure: (0x11c0170), of [package:flutter/src/material/slider.dart] _RenderSlider
    //     0x11bffa4: ldr             x1, [x1, #0x788]
    // 0x11bffa8: r0 = AllocateClosure()
    //     0x11bffa8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11bffac: ldur            x1, [fp, #-0x20]
    // 0x11bffb0: StoreField: r1->field_5b = r0
    //     0x11bffb0: stur            w0, [x1, #0x5b]
    //     0x11bffb4: ldurb           w16, [x1, #-1]
    //     0x11bffb8: ldurb           w17, [x0, #-1]
    //     0x11bffbc: and             x16, x17, x16, lsr #2
    //     0x11bffc0: tst             x16, HEAP, lsr #32
    //     0x11bffc4: b.eq            #0x11bffcc
    //     0x11bffc8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11bffcc: ldur            x0, [fp, #-0x18]
    // 0x11bffd0: StoreField: r1->field_7 = r0
    //     0x11bffd0: stur            w0, [x1, #7]
    //     0x11bffd4: ldurb           w16, [x1, #-1]
    //     0x11bffd8: ldurb           w17, [x0, #-1]
    //     0x11bffdc: and             x16, x17, x16, lsr #2
    //     0x11bffe0: tst             x16, HEAP, lsr #32
    //     0x11bffe4: b.eq            #0x11bffec
    //     0x11bffe8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11bffec: mov             x0, x1
    // 0x11bfff0: ldur            x2, [fp, #-8]
    // 0x11bfff4: StoreField: r2->field_6b = r0
    //     0x11bfff4: stur            w0, [x2, #0x6b]
    //     0x11bfff8: ldurb           w16, [x2, #-1]
    //     0x11bfffc: ldurb           w17, [x0, #-1]
    //     0x11c0000: and             x16, x17, x16, lsr #2
    //     0x11c0004: tst             x16, HEAP, lsr #32
    //     0x11c0008: b.eq            #0x11c0010
    //     0x11c000c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11c0010: ldr             x0, [fp, #0x18]
    // 0x11c0014: LoadField: r3 = r0->field_1b
    //     0x11c0014: ldur            w3, [x0, #0x1b]
    // 0x11c0018: DecompressPointer r3
    //     0x11c0018: add             x3, x3, HEAP, lsl #32
    // 0x11c001c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11c0020: cmp             w3, w16
    // 0x11c0024: b.eq            #0x11c014c
    // 0x11c0028: stur            x3, [fp, #-0x18]
    // 0x11c002c: r1 = <double>
    //     0x11c002c: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0x11c0030: r0 = CurvedAnimation()
    //     0x11c0030: bl              #0x915e4c  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x11c0034: mov             x1, x0
    // 0x11c0038: ldur            x3, [fp, #-0x18]
    // 0x11c003c: r2 = Instance_Cubic
    //     0x11c003c: ldr             x2, [PP, #0x5660]  ; [pp+0x5660] Obj!Cubic@129f451
    // 0x11c0040: stur            x0, [fp, #-0x18]
    // 0x11c0044: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x11c0044: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x11c0048: r0 = CurvedAnimation()
    //     0x11c0048: bl              #0x915be4  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x11c004c: ldur            x0, [fp, #-0x18]
    // 0x11c0050: ldur            x2, [fp, #-8]
    // 0x11c0054: StoreField: r2->field_57 = r0
    //     0x11c0054: stur            w0, [x2, #0x57]
    //     0x11c0058: ldurb           w16, [x2, #-1]
    //     0x11c005c: ldurb           w17, [x0, #-1]
    //     0x11c0060: and             x16, x17, x16, lsr #2
    //     0x11c0064: tst             x16, HEAP, lsr #32
    //     0x11c0068: b.eq            #0x11c0070
    //     0x11c006c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11c0070: ldr             x0, [fp, #0x18]
    // 0x11c0074: LoadField: r3 = r0->field_1f
    //     0x11c0074: ldur            w3, [x0, #0x1f]
    // 0x11c0078: DecompressPointer r3
    //     0x11c0078: add             x3, x3, HEAP, lsl #32
    // 0x11c007c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11c0080: cmp             w3, w16
    // 0x11c0084: b.eq            #0x11c0158
    // 0x11c0088: stur            x3, [fp, #-0x18]
    // 0x11c008c: r1 = <double>
    //     0x11c008c: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0x11c0090: r0 = CurvedAnimation()
    //     0x11c0090: bl              #0x915e4c  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x11c0094: mov             x1, x0
    // 0x11c0098: ldur            x3, [fp, #-0x18]
    // 0x11c009c: r2 = Instance_Cubic
    //     0x11c009c: ldr             x2, [PP, #0x5660]  ; [pp+0x5660] Obj!Cubic@129f451
    // 0x11c00a0: stur            x0, [fp, #-0x18]
    // 0x11c00a4: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x11c00a4: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x11c00a8: r0 = CurvedAnimation()
    //     0x11c00a8: bl              #0x915be4  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x11c00ac: ldur            x0, [fp, #-0x18]
    // 0x11c00b0: ldur            x2, [fp, #-8]
    // 0x11c00b4: StoreField: r2->field_5b = r0
    //     0x11c00b4: stur            w0, [x2, #0x5b]
    //     0x11c00b8: ldurb           w16, [x2, #-1]
    //     0x11c00bc: ldurb           w17, [x0, #-1]
    //     0x11c00c0: and             x16, x17, x16, lsr #2
    //     0x11c00c4: tst             x16, HEAP, lsr #32
    //     0x11c00c8: b.eq            #0x11c00d0
    //     0x11c00cc: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11c00d0: ldr             x0, [fp, #0x18]
    // 0x11c00d4: LoadField: r3 = r0->field_23
    //     0x11c00d4: ldur            w3, [x0, #0x23]
    // 0x11c00d8: DecompressPointer r3
    //     0x11c00d8: add             x3, x3, HEAP, lsl #32
    // 0x11c00dc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11c00e0: cmp             w3, w16
    // 0x11c00e4: b.eq            #0x11c0164
    // 0x11c00e8: stur            x3, [fp, #-0x18]
    // 0x11c00ec: r1 = <double>
    //     0x11c00ec: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0x11c00f0: r0 = CurvedAnimation()
    //     0x11c00f0: bl              #0x915e4c  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x11c00f4: mov             x1, x0
    // 0x11c00f8: ldur            x3, [fp, #-0x18]
    // 0x11c00fc: r2 = Instance_Cubic
    //     0x11c00fc: add             x2, PP, #0x19, lsl #12  ; [pp+0x19668] Obj!Cubic@129f511
    //     0x11c0100: ldr             x2, [x2, #0x668]
    // 0x11c0104: stur            x0, [fp, #-0x18]
    // 0x11c0108: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x11c0108: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x11c010c: r0 = CurvedAnimation()
    //     0x11c010c: bl              #0x915be4  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x11c0110: ldur            x0, [fp, #-0x18]
    // 0x11c0114: ldur            x1, [fp, #-8]
    // 0x11c0118: StoreField: r1->field_5f = r0
    //     0x11c0118: stur            w0, [x1, #0x5f]
    //     0x11c011c: ldurb           w16, [x1, #-1]
    //     0x11c0120: ldurb           w17, [x0, #-1]
    //     0x11c0124: and             x16, x17, x16, lsr #2
    //     0x11c0128: tst             x16, HEAP, lsr #32
    //     0x11c012c: b.eq            #0x11c0134
    //     0x11c0130: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11c0134: r0 = Null
    //     0x11c0134: mov             x0, NULL
    // 0x11c0138: LeaveFrame
    //     0x11c0138: mov             SP, fp
    //     0x11c013c: ldp             fp, lr, [SP], #0x10
    // 0x11c0140: ret
    //     0x11c0140: ret             
    // 0x11c0144: r0 = StackOverflowSharedWithFPURegs()
    //     0x11c0144: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x11c0148: b               #0x11bfbc8
    // 0x11c014c: r9 = overlayController
    //     0x11c014c: add             x9, PP, #0x99, lsl #12  ; [pp+0x99000] Field <_SliderState@125231897.overlayController>: late (offset: 0x1c)
    //     0x11c0150: ldr             x9, [x9]
    // 0x11c0154: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x11c0154: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x11c0158: r9 = valueIndicatorController
    //     0x11c0158: add             x9, PP, #0x99, lsl #12  ; [pp+0x99008] Field <_SliderState@125231897.valueIndicatorController>: late (offset: 0x20)
    //     0x11c015c: ldr             x9, [x9, #8]
    // 0x11c0160: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x11c0160: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x11c0164: r9 = enableController
    //     0x11c0164: add             x9, PP, #0x99, lsl #12  ; [pp+0x99010] Field <_SliderState@125231897.enableController>: late (offset: 0x24)
    //     0x11c0168: ldr             x9, [x9, #0x10]
    // 0x11c016c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x11c016c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleDragEnd(dynamic, DragEndDetails) {
    // ** addr: 0x11c0170, size: 0x3c
    // 0x11c0170: EnterFrame
    //     0x11c0170: stp             fp, lr, [SP, #-0x10]!
    //     0x11c0174: mov             fp, SP
    // 0x11c0178: ldr             x0, [fp, #0x18]
    // 0x11c017c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x11c017c: ldur            w1, [x0, #0x17]
    // 0x11c0180: DecompressPointer r1
    //     0x11c0180: add             x1, x1, HEAP, lsl #32
    // 0x11c0184: CheckStackOverflow
    //     0x11c0184: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11c0188: cmp             SP, x16
    //     0x11c018c: b.ls            #0x11c01a4
    // 0x11c0190: r0 = _endInteraction()
    //     0x11c0190: bl              #0x11c01ac  ; [package:flutter/src/material/slider.dart] _RenderSlider::_endInteraction
    // 0x11c0194: r0 = Null
    //     0x11c0194: mov             x0, NULL
    // 0x11c0198: LeaveFrame
    //     0x11c0198: mov             SP, fp
    //     0x11c019c: ldp             fp, lr, [SP], #0x10
    // 0x11c01a0: ret
    //     0x11c01a0: ret             
    // 0x11c01a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11c01a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11c01a8: b               #0x11c0190
  }
  _ _endInteraction(/* No info */) {
    // ** addr: 0x11c01ac, size: 0x170
    // 0x11c01ac: EnterFrame
    //     0x11c01ac: stp             fp, lr, [SP, #-0x10]!
    //     0x11c01b0: mov             fp, SP
    // 0x11c01b4: AllocStack(0x18)
    //     0x11c01b4: sub             SP, SP, #0x18
    // 0x11c01b8: SetupParameters(_RenderSlider this /* r1 => r0, fp-0x18 */)
    //     0x11c01b8: mov             x0, x1
    //     0x11c01bc: stur            x1, [fp, #-0x18]
    // 0x11c01c0: CheckStackOverflow
    //     0x11c01c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11c01c4: cmp             SP, x16
    //     0x11c01c8: b.ls            #0x11c02dc
    // 0x11c01cc: LoadField: r2 = r0->field_53
    //     0x11c01cc: ldur            w2, [x0, #0x53]
    // 0x11c01d0: DecompressPointer r2
    //     0x11c01d0: add             x2, x2, HEAP, lsl #32
    // 0x11c01d4: stur            x2, [fp, #-0x10]
    // 0x11c01d8: LoadField: r1 = r2->field_f
    //     0x11c01d8: ldur            w1, [x2, #0xf]
    // 0x11c01dc: DecompressPointer r1
    //     0x11c01dc: add             x1, x1, HEAP, lsl #32
    // 0x11c01e0: cmp             w1, NULL
    // 0x11c01e4: b.ne            #0x11c01f8
    // 0x11c01e8: r0 = Null
    //     0x11c01e8: mov             x0, NULL
    // 0x11c01ec: LeaveFrame
    //     0x11c01ec: mov             SP, fp
    //     0x11c01f0: ldp             fp, lr, [SP], #0x10
    // 0x11c01f4: ret
    //     0x11c01f4: ret             
    // 0x11c01f8: LoadField: r1 = r0->field_6f
    //     0x11c01f8: ldur            w1, [x0, #0x6f]
    // 0x11c01fc: DecompressPointer r1
    //     0x11c01fc: add             x1, x1, HEAP, lsl #32
    // 0x11c0200: tbnz            w1, #4, #0x11c02cc
    // 0x11c0204: LoadField: r3 = r0->field_bb
    //     0x11c0204: ldur            w3, [x0, #0xbb]
    // 0x11c0208: DecompressPointer r3
    //     0x11c0208: add             x3, x3, HEAP, lsl #32
    // 0x11c020c: stur            x3, [fp, #-8]
    // 0x11c0210: LoadField: d0 = r0->field_77
    //     0x11c0210: ldur            d0, [x0, #0x77]
    // 0x11c0214: mov             x1, x0
    // 0x11c0218: r0 = _discretize()
    //     0x11c0218: bl              #0xb1e0b0  ; [package:flutter/src/material/slider.dart] _RenderSlider::_discretize
    // 0x11c021c: ldur            x0, [fp, #-8]
    // 0x11c0220: cmp             w0, NULL
    // 0x11c0224: b.eq            #0x11c02e4
    // 0x11c0228: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x11c0228: ldur            w1, [x0, #0x17]
    // 0x11c022c: DecompressPointer r1
    //     0x11c022c: add             x1, x1, HEAP, lsl #32
    // 0x11c0230: r2 = inline_Allocate_Double()
    //     0x11c0230: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0x11c0234: add             x2, x2, #0x10
    //     0x11c0238: cmp             x0, x2
    //     0x11c023c: b.ls            #0x11c02e8
    //     0x11c0240: str             x2, [THR, #0x60]  ; THR::top
    //     0x11c0244: sub             x2, x2, #0xf
    //     0x11c0248: mov             x0, #0xe19c
    //     0x11c024c: movk            x0, #3, lsl #16
    //     0x11c0250: stur            x0, [x2, #-1]
    // 0x11c0254: dmb             ishst
    // 0x11c0258: StoreField: r2->field_7 = d0
    //     0x11c0258: stur            d0, [x2, #7]
    // 0x11c025c: r0 = _handleDragEnd()
    //     0x11c025c: bl              #0xbf95c8  ; [package:flutter/src/material/slider.dart] _SliderState::_handleDragEnd
    // 0x11c0260: ldur            x0, [fp, #-0x18]
    // 0x11c0264: r1 = false
    //     0x11c0264: add             x1, NULL, #0x30  ; false
    // 0x11c0268: StoreField: r0->field_6f = r1
    //     0x11c0268: stur            w1, [x0, #0x6f]
    // 0x11c026c: StoreField: r0->field_77 = rZR
    //     0x11c026c: stur            xzr, [x0, #0x77]
    // 0x11c0270: ldur            x2, [fp, #-0x10]
    // 0x11c0274: LoadField: r1 = r2->field_1b
    //     0x11c0274: ldur            w1, [x2, #0x1b]
    // 0x11c0278: DecompressPointer r1
    //     0x11c0278: add             x1, x1, HEAP, lsl #32
    // 0x11c027c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11c0280: cmp             w1, w16
    // 0x11c0284: b.eq            #0x11c0304
    // 0x11c0288: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x11c0288: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x11c028c: r0 = reverse()
    //     0x11c028c: bl              #0x8c8688  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0x11c0290: ldur            x1, [fp, #-0x18]
    // 0x11c0294: r0 = shouldShowValueIndicatorWhenDragged()
    //     0x11c0294: bl              #0xc23dc4  ; [package:flutter/src/material/slider.dart] _RenderSlider::shouldShowValueIndicatorWhenDragged
    // 0x11c0298: tbnz            w0, #4, #0x11c02cc
    // 0x11c029c: ldur            x0, [fp, #-0x10]
    // 0x11c02a0: LoadField: r1 = r0->field_2b
    //     0x11c02a0: ldur            w1, [x0, #0x2b]
    // 0x11c02a4: DecompressPointer r1
    //     0x11c02a4: add             x1, x1, HEAP, lsl #32
    // 0x11c02a8: cmp             w1, NULL
    // 0x11c02ac: b.ne            #0x11c02cc
    // 0x11c02b0: LoadField: r1 = r0->field_1f
    //     0x11c02b0: ldur            w1, [x0, #0x1f]
    // 0x11c02b4: DecompressPointer r1
    //     0x11c02b4: add             x1, x1, HEAP, lsl #32
    // 0x11c02b8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11c02bc: cmp             w1, w16
    // 0x11c02c0: b.eq            #0x11c0310
    // 0x11c02c4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x11c02c4: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x11c02c8: r0 = reverse()
    //     0x11c02c8: bl              #0x8c8688  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0x11c02cc: r0 = Null
    //     0x11c02cc: mov             x0, NULL
    // 0x11c02d0: LeaveFrame
    //     0x11c02d0: mov             SP, fp
    //     0x11c02d4: ldp             fp, lr, [SP], #0x10
    // 0x11c02d8: ret
    //     0x11c02d8: ret             
    // 0x11c02dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11c02dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11c02e0: b               #0x11c01cc
    // 0x11c02e4: r0 = NullErrorSharedWithFPURegs()
    //     0x11c02e4: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0x11c02e8: SaveReg d0
    //     0x11c02e8: str             q0, [SP, #-0x10]!
    // 0x11c02ec: SaveReg r1
    //     0x11c02ec: str             x1, [SP, #-8]!
    // 0x11c02f0: r0 = AllocateDouble()
    //     0x11c02f0: bl              #0x13df878  ; AllocateDoubleStub
    // 0x11c02f4: mov             x2, x0
    // 0x11c02f8: RestoreReg r1
    //     0x11c02f8: ldr             x1, [SP], #8
    // 0x11c02fc: RestoreReg d0
    //     0x11c02fc: ldr             q0, [SP], #0x10
    // 0x11c0300: b               #0x11c0258
    // 0x11c0304: r9 = overlayController
    //     0x11c0304: add             x9, PP, #0x99, lsl #12  ; [pp+0x99000] Field <_SliderState@125231897.overlayController>: late (offset: 0x1c)
    //     0x11c0308: ldr             x9, [x9]
    // 0x11c030c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x11c030c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x11c0310: r9 = valueIndicatorController
    //     0x11c0310: add             x9, PP, #0x99, lsl #12  ; [pp+0x99008] Field <_SliderState@125231897.valueIndicatorController>: late (offset: 0x20)
    //     0x11c0314: ldr             x9, [x9, #8]
    // 0x11c0318: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x11c0318: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleTapDown(dynamic, TapDownDetails) {
    // ** addr: 0x11c031c, size: 0x3c
    // 0x11c031c: EnterFrame
    //     0x11c031c: stp             fp, lr, [SP, #-0x10]!
    //     0x11c0320: mov             fp, SP
    // 0x11c0324: ldr             x0, [fp, #0x18]
    // 0x11c0328: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x11c0328: ldur            w1, [x0, #0x17]
    // 0x11c032c: DecompressPointer r1
    //     0x11c032c: add             x1, x1, HEAP, lsl #32
    // 0x11c0330: CheckStackOverflow
    //     0x11c0330: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11c0334: cmp             SP, x16
    //     0x11c0338: b.ls            #0x11c0350
    // 0x11c033c: ldr             x2, [fp, #0x10]
    // 0x11c0340: r0 = _handleDragStart()
    //     0x11c0340: bl              #0x11c0358  ; [package:flutter/src/material/slider.dart] _RenderSlider::_handleDragStart
    // 0x11c0344: LeaveFrame
    //     0x11c0344: mov             SP, fp
    //     0x11c0348: ldp             fp, lr, [SP], #0x10
    // 0x11c034c: ret
    //     0x11c034c: ret             
    // 0x11c0350: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11c0350: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11c0354: b               #0x11c033c
  }
  _ _handleDragStart(/* No info */) {
    // ** addr: 0x11c0358, size: 0x3c
    // 0x11c0358: EnterFrame
    //     0x11c0358: stp             fp, lr, [SP, #-0x10]!
    //     0x11c035c: mov             fp, SP
    // 0x11c0360: CheckStackOverflow
    //     0x11c0360: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11c0364: cmp             SP, x16
    //     0x11c0368: b.ls            #0x11c038c
    // 0x11c036c: LoadField: r0 = r2->field_7
    //     0x11c036c: ldur            w0, [x2, #7]
    // 0x11c0370: DecompressPointer r0
    //     0x11c0370: add             x0, x0, HEAP, lsl #32
    // 0x11c0374: mov             x2, x0
    // 0x11c0378: r0 = _startInteraction()
    //     0x11c0378: bl              #0x11c0394  ; [package:flutter/src/material/slider.dart] _RenderSlider::_startInteraction
    // 0x11c037c: r0 = Null
    //     0x11c037c: mov             x0, NULL
    // 0x11c0380: LeaveFrame
    //     0x11c0380: mov             SP, fp
    //     0x11c0384: ldp             fp, lr, [SP], #0x10
    // 0x11c0388: ret
    //     0x11c0388: ret             
    // 0x11c038c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11c038c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11c0390: b               #0x11c036c
  }
  _ _startInteraction(/* No info */) {
    // ** addr: 0x11c0394, size: 0x290
    // 0x11c0394: EnterFrame
    //     0x11c0394: stp             fp, lr, [SP, #-0x10]!
    //     0x11c0398: mov             fp, SP
    // 0x11c039c: AllocStack(0x20)
    //     0x11c039c: sub             SP, SP, #0x20
    // 0x11c03a0: SetupParameters(_RenderSlider this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x11c03a0: stur            x1, [fp, #-8]
    //     0x11c03a4: stur            x2, [fp, #-0x10]
    // 0x11c03a8: CheckStackOverflow
    //     0x11c03a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11c03ac: cmp             SP, x16
    //     0x11c03b0: b.ls            #0x11c05c4
    // 0x11c03b4: r1 = 1
    //     0x11c03b4: mov             x1, #1
    // 0x11c03b8: r0 = AllocateContext()
    //     0x11c03b8: bl              #0x13de838  ; AllocateContextStub
    // 0x11c03bc: mov             x3, x0
    // 0x11c03c0: ldur            x0, [fp, #-8]
    // 0x11c03c4: stur            x3, [fp, #-0x20]
    // 0x11c03c8: StoreField: r3->field_f = r0
    //     0x11c03c8: stur            w0, [x3, #0xf]
    // 0x11c03cc: LoadField: r4 = r0->field_53
    //     0x11c03cc: ldur            w4, [x0, #0x53]
    // 0x11c03d0: DecompressPointer r4
    //     0x11c03d0: add             x4, x4, HEAP, lsl #32
    // 0x11c03d4: stur            x4, [fp, #-0x18]
    // 0x11c03d8: LoadField: r1 = r4->field_f
    //     0x11c03d8: ldur            w1, [x4, #0xf]
    // 0x11c03dc: DecompressPointer r1
    //     0x11c03dc: add             x1, x1, HEAP, lsl #32
    // 0x11c03e0: cmp             w1, NULL
    // 0x11c03e4: b.ne            #0x11c03f8
    // 0x11c03e8: r0 = Null
    //     0x11c03e8: mov             x0, NULL
    // 0x11c03ec: LeaveFrame
    //     0x11c03ec: mov             SP, fp
    //     0x11c03f0: ldp             fp, lr, [SP], #0x10
    // 0x11c03f4: ret
    //     0x11c03f4: ret             
    // 0x11c03f8: LoadField: r1 = r0->field_6f
    //     0x11c03f8: ldur            w1, [x0, #0x6f]
    // 0x11c03fc: DecompressPointer r1
    //     0x11c03fc: add             x1, x1, HEAP, lsl #32
    // 0x11c0400: tbz             w1, #4, #0x11c05b4
    // 0x11c0404: LoadField: r1 = r0->field_b3
    //     0x11c0404: ldur            w1, [x0, #0xb3]
    // 0x11c0408: DecompressPointer r1
    //     0x11c0408: add             x1, x1, HEAP, lsl #32
    // 0x11c040c: cmp             w1, NULL
    // 0x11c0410: b.eq            #0x11c05b4
    // 0x11c0414: r1 = true
    //     0x11c0414: add             x1, NULL, #0x20  ; true
    // 0x11c0418: StoreField: r0->field_6f = r1
    //     0x11c0418: stur            w1, [x0, #0x6f]
    // 0x11c041c: mov             x1, x0
    // 0x11c0420: ldur            x2, [fp, #-0x10]
    // 0x11c0424: r0 = _getValueFromGlobalPosition()
    //     0x11c0424: bl              #0x11c0624  ; [package:flutter/src/material/slider.dart] _RenderSlider::_getValueFromGlobalPosition
    // 0x11c0428: ldur            x0, [fp, #-8]
    // 0x11c042c: StoreField: r0->field_77 = d0
    //     0x11c042c: stur            d0, [x0, #0x77]
    // 0x11c0430: LoadField: r1 = r0->field_6f
    //     0x11c0430: ldur            w1, [x0, #0x6f]
    // 0x11c0434: DecompressPointer r1
    //     0x11c0434: add             x1, x1, HEAP, lsl #32
    // 0x11c0438: tbnz            w1, #4, #0x11c05b4
    // 0x11c043c: ldur            x2, [fp, #-0x18]
    // 0x11c0440: LoadField: r3 = r0->field_b7
    //     0x11c0440: ldur            w3, [x0, #0xb7]
    // 0x11c0444: DecompressPointer r3
    //     0x11c0444: add             x3, x3, HEAP, lsl #32
    // 0x11c0448: stur            x3, [fp, #-0x10]
    // 0x11c044c: LoadField: d0 = r0->field_83
    //     0x11c044c: ldur            d0, [x0, #0x83]
    // 0x11c0450: mov             x1, x0
    // 0x11c0454: r0 = _discretize()
    //     0x11c0454: bl              #0xb1e0b0  ; [package:flutter/src/material/slider.dart] _RenderSlider::_discretize
    // 0x11c0458: ldur            x0, [fp, #-0x10]
    // 0x11c045c: cmp             w0, NULL
    // 0x11c0460: b.eq            #0x11c05cc
    // 0x11c0464: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x11c0464: ldur            w1, [x0, #0x17]
    // 0x11c0468: DecompressPointer r1
    //     0x11c0468: add             x1, x1, HEAP, lsl #32
    // 0x11c046c: r2 = inline_Allocate_Double()
    //     0x11c046c: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0x11c0470: add             x2, x2, #0x10
    //     0x11c0474: cmp             x0, x2
    //     0x11c0478: b.ls            #0x11c05d0
    //     0x11c047c: str             x2, [THR, #0x60]  ; THR::top
    //     0x11c0480: sub             x2, x2, #0xf
    //     0x11c0484: mov             x0, #0xe19c
    //     0x11c0488: movk            x0, #3, lsl #16
    //     0x11c048c: stur            x0, [x2, #-1]
    // 0x11c0490: dmb             ishst
    // 0x11c0494: StoreField: r2->field_7 = d0
    //     0x11c0494: stur            d0, [x2, #7]
    // 0x11c0498: r0 = _handleDragStart()
    //     0x11c0498: bl              #0xbf98d0  ; [package:flutter/src/material/slider.dart] _SliderState::_handleDragStart
    // 0x11c049c: ldur            x0, [fp, #-8]
    // 0x11c04a0: LoadField: r2 = r0->field_b3
    //     0x11c04a0: ldur            w2, [x0, #0xb3]
    // 0x11c04a4: DecompressPointer r2
    //     0x11c04a4: add             x2, x2, HEAP, lsl #32
    // 0x11c04a8: stur            x2, [fp, #-0x10]
    // 0x11c04ac: cmp             w2, NULL
    // 0x11c04b0: b.eq            #0x11c05ec
    // 0x11c04b4: LoadField: d0 = r0->field_77
    //     0x11c04b4: ldur            d0, [x0, #0x77]
    // 0x11c04b8: mov             x1, x0
    // 0x11c04bc: r0 = _discretize()
    //     0x11c04bc: bl              #0xb1e0b0  ; [package:flutter/src/material/slider.dart] _RenderSlider::_discretize
    // 0x11c04c0: ldur            x0, [fp, #-0x10]
    // 0x11c04c4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x11c04c4: ldur            w1, [x0, #0x17]
    // 0x11c04c8: DecompressPointer r1
    //     0x11c04c8: add             x1, x1, HEAP, lsl #32
    // 0x11c04cc: r2 = inline_Allocate_Double()
    //     0x11c04cc: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0x11c04d0: add             x2, x2, #0x10
    //     0x11c04d4: cmp             x0, x2
    //     0x11c04d8: b.ls            #0x11c05f0
    //     0x11c04dc: str             x2, [THR, #0x60]  ; THR::top
    //     0x11c04e0: sub             x2, x2, #0xf
    //     0x11c04e4: mov             x0, #0xe19c
    //     0x11c04e8: movk            x0, #3, lsl #16
    //     0x11c04ec: stur            x0, [x2, #-1]
    // 0x11c04f0: dmb             ishst
    // 0x11c04f4: StoreField: r2->field_7 = d0
    //     0x11c04f4: stur            d0, [x2, #7]
    // 0x11c04f8: r0 = _handleChanged()
    //     0x11c04f8: bl              #0xbf966c  ; [package:flutter/src/material/slider.dart] _SliderState::_handleChanged
    // 0x11c04fc: ldur            x0, [fp, #-0x18]
    // 0x11c0500: LoadField: r1 = r0->field_1b
    //     0x11c0500: ldur            w1, [x0, #0x1b]
    // 0x11c0504: DecompressPointer r1
    //     0x11c0504: add             x1, x1, HEAP, lsl #32
    // 0x11c0508: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11c050c: cmp             w1, w16
    // 0x11c0510: b.eq            #0x11c060c
    // 0x11c0514: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x11c0514: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x11c0518: r0 = forward()
    //     0x11c0518: bl              #0x8cd83c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x11c051c: ldur            x1, [fp, #-8]
    // 0x11c0520: r0 = shouldShowValueIndicatorWhenDragged()
    //     0x11c0520: bl              #0xc23dc4  ; [package:flutter/src/material/slider.dart] _RenderSlider::shouldShowValueIndicatorWhenDragged
    // 0x11c0524: tbnz            w0, #4, #0x11c05b4
    // 0x11c0528: ldur            x0, [fp, #-0x18]
    // 0x11c052c: LoadField: r1 = r0->field_1f
    //     0x11c052c: ldur            w1, [x0, #0x1f]
    // 0x11c0530: DecompressPointer r1
    //     0x11c0530: add             x1, x1, HEAP, lsl #32
    // 0x11c0534: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11c0538: cmp             w1, w16
    // 0x11c053c: b.eq            #0x11c0618
    // 0x11c0540: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x11c0540: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x11c0544: r0 = forward()
    //     0x11c0544: bl              #0x8cd83c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x11c0548: ldur            x0, [fp, #-0x18]
    // 0x11c054c: LoadField: r1 = r0->field_2b
    //     0x11c054c: ldur            w1, [x0, #0x2b]
    // 0x11c0550: DecompressPointer r1
    //     0x11c0550: add             x1, x1, HEAP, lsl #32
    // 0x11c0554: cmp             w1, NULL
    // 0x11c0558: b.eq            #0x11c0564
    // 0x11c055c: r0 = cancel()
    //     0x11c055c: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0x11c0560: ldur            x0, [fp, #-0x18]
    // 0x11c0564: r1 = Instance_Duration
    //     0x11c0564: ldr             x1, [PP, #0x5248]  ; [pp+0x5248] Obj!Duration@12c8931
    // 0x11c0568: r2 = 1.000000
    //     0x11c0568: ldr             x2, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0x11c056c: r0 = *()
    //     0x11c056c: bl              #0x7dd190  ; [dart:core] Duration::*
    // 0x11c0570: ldur            x2, [fp, #-0x20]
    // 0x11c0574: r1 = Function '<anonymous closure>':.
    //     0x11c0574: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3790] AnonymousClosure: (0x11c06f0), in [package:flutter/src/material/slider.dart] _RenderSlider::_startInteraction (0x11c0394)
    //     0x11c0578: ldr             x1, [x1, #0x790]
    // 0x11c057c: stur            x0, [fp, #-8]
    // 0x11c0580: r0 = AllocateClosure()
    //     0x11c0580: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11c0584: ldur            x2, [fp, #-8]
    // 0x11c0588: mov             x3, x0
    // 0x11c058c: r1 = Null
    //     0x11c058c: mov             x1, NULL
    // 0x11c0590: r0 = Timer()
    //     0x11c0590: bl              #0x7eed74  ; [dart:async] Timer::Timer
    // 0x11c0594: ldur            x1, [fp, #-0x18]
    // 0x11c0598: StoreField: r1->field_2b = r0
    //     0x11c0598: stur            w0, [x1, #0x2b]
    //     0x11c059c: ldurb           w16, [x1, #-1]
    //     0x11c05a0: ldurb           w17, [x0, #-1]
    //     0x11c05a4: and             x16, x17, x16, lsr #2
    //     0x11c05a8: tst             x16, HEAP, lsr #32
    //     0x11c05ac: b.eq            #0x11c05b4
    //     0x11c05b0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11c05b4: r0 = Null
    //     0x11c05b4: mov             x0, NULL
    // 0x11c05b8: LeaveFrame
    //     0x11c05b8: mov             SP, fp
    //     0x11c05bc: ldp             fp, lr, [SP], #0x10
    // 0x11c05c0: ret
    //     0x11c05c0: ret             
    // 0x11c05c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11c05c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11c05c8: b               #0x11c03b4
    // 0x11c05cc: r0 = NullErrorSharedWithFPURegs()
    //     0x11c05cc: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0x11c05d0: SaveReg d0
    //     0x11c05d0: str             q0, [SP, #-0x10]!
    // 0x11c05d4: SaveReg r1
    //     0x11c05d4: str             x1, [SP, #-8]!
    // 0x11c05d8: r0 = AllocateDouble()
    //     0x11c05d8: bl              #0x13df878  ; AllocateDoubleStub
    // 0x11c05dc: mov             x2, x0
    // 0x11c05e0: RestoreReg r1
    //     0x11c05e0: ldr             x1, [SP], #8
    // 0x11c05e4: RestoreReg d0
    //     0x11c05e4: ldr             q0, [SP], #0x10
    // 0x11c05e8: b               #0x11c0494
    // 0x11c05ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x11c05ec: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x11c05f0: SaveReg d0
    //     0x11c05f0: str             q0, [SP, #-0x10]!
    // 0x11c05f4: SaveReg r1
    //     0x11c05f4: str             x1, [SP, #-8]!
    // 0x11c05f8: r0 = AllocateDouble()
    //     0x11c05f8: bl              #0x13df878  ; AllocateDoubleStub
    // 0x11c05fc: mov             x2, x0
    // 0x11c0600: RestoreReg r1
    //     0x11c0600: ldr             x1, [SP], #8
    // 0x11c0604: RestoreReg d0
    //     0x11c0604: ldr             q0, [SP], #0x10
    // 0x11c0608: b               #0x11c04f4
    // 0x11c060c: r9 = overlayController
    //     0x11c060c: add             x9, PP, #0x99, lsl #12  ; [pp+0x99000] Field <_SliderState@125231897.overlayController>: late (offset: 0x1c)
    //     0x11c0610: ldr             x9, [x9]
    // 0x11c0614: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x11c0614: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x11c0618: r9 = valueIndicatorController
    //     0x11c0618: add             x9, PP, #0x99, lsl #12  ; [pp+0x99008] Field <_SliderState@125231897.valueIndicatorController>: late (offset: 0x20)
    //     0x11c061c: ldr             x9, [x9, #8]
    // 0x11c0620: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x11c0620: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _getValueFromGlobalPosition(/* No info */) {
    // ** addr: 0x11c0624, size: 0xa8
    // 0x11c0624: EnterFrame
    //     0x11c0624: stp             fp, lr, [SP, #-0x10]!
    //     0x11c0628: mov             fp, SP
    // 0x11c062c: AllocStack(0x18)
    //     0x11c062c: sub             SP, SP, #0x18
    // 0x11c0630: SetupParameters(_RenderSlider this /* r1 => r0, fp-0x8 */)
    //     0x11c0630: mov             x0, x1
    //     0x11c0634: stur            x1, [fp, #-8]
    // 0x11c0638: CheckStackOverflow
    //     0x11c0638: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11c063c: cmp             SP, x16
    //     0x11c0640: b.ls            #0x11c06c0
    // 0x11c0644: mov             x1, x0
    // 0x11c0648: r0 = globalToLocal()
    //     0x11c0648: bl              #0x867840  ; [package:flutter/src/rendering/box.dart] RenderBox::globalToLocal
    // 0x11c064c: LoadField: d0 = r0->field_7
    //     0x11c064c: ldur            d0, [x0, #7]
    // 0x11c0650: ldur            x1, [fp, #-8]
    // 0x11c0654: stur            d0, [fp, #-0x10]
    // 0x11c0658: r0 = _trackRect()
    //     0x11c0658: bl              #0xc12394  ; [package:flutter/src/material/slider.dart] _RenderSlider::_trackRect
    // 0x11c065c: LoadField: d0 = r0->field_7
    //     0x11c065c: ldur            d0, [x0, #7]
    // 0x11c0660: ldur            d1, [fp, #-0x10]
    // 0x11c0664: fsub            d2, d1, d0
    // 0x11c0668: ldur            x0, [fp, #-8]
    // 0x11c066c: stur            d2, [fp, #-0x18]
    // 0x11c0670: LoadField: r3 = r0->field_a3
    //     0x11c0670: ldur            w3, [x0, #0xa3]
    // 0x11c0674: DecompressPointer r3
    //     0x11c0674: add             x3, x3, HEAP, lsl #32
    // 0x11c0678: LoadField: r1 = r3->field_57
    //     0x11c0678: ldur            w1, [x3, #0x57]
    // 0x11c067c: DecompressPointer r1
    //     0x11c067c: add             x1, x1, HEAP, lsl #32
    // 0x11c0680: cmp             w1, NULL
    // 0x11c0684: b.eq            #0x11c06c8
    // 0x11c0688: mov             x2, x0
    // 0x11c068c: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x11c068c: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x11c0690: r0 = getPreferredRect()
    //     0x11c0690: bl              #0xc12580  ; [dart:mixin_deduplication] _MixinApplication107&SliderTrackShape&BaseSliderTrackShape::getPreferredRect
    // 0x11c0694: ArrayLoad: d0 = r0[0]  ; List_8
    //     0x11c0694: ldur            d0, [x0, #0x17]
    // 0x11c0698: LoadField: d1 = r0->field_7
    //     0x11c0698: ldur            d1, [x0, #7]
    // 0x11c069c: fsub            d2, d0, d1
    // 0x11c06a0: ldur            d0, [fp, #-0x18]
    // 0x11c06a4: fdiv            d1, d0, d2
    // 0x11c06a8: ldur            x1, [fp, #-8]
    // 0x11c06ac: mov             v0.16b, v1.16b
    // 0x11c06b0: r0 = _getValueFromVisualPosition()
    //     0x11c06b0: bl              #0x11c06cc  ; [package:flutter/src/material/slider.dart] _RenderSlider::_getValueFromVisualPosition
    // 0x11c06b4: LeaveFrame
    //     0x11c06b4: mov             SP, fp
    //     0x11c06b8: ldp             fp, lr, [SP], #0x10
    // 0x11c06bc: ret
    //     0x11c06bc: ret             
    // 0x11c06c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11c06c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11c06c4: b               #0x11c0644
    // 0x11c06c8: r0 = NullCastErrorSharedWithFPURegs()
    //     0x11c06c8: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  _ _getValueFromVisualPosition(/* No info */) {
    // ** addr: 0x11c06cc, size: 0x24
    // 0x11c06cc: LoadField: r0 = r1->field_bf
    //     0x11c06cc: ldur            w0, [x1, #0xbf]
    // 0x11c06d0: DecompressPointer r0
    //     0x11c06d0: add             x0, x0, HEAP, lsl #32
    // 0x11c06d4: LoadField: r1 = r0->field_7
    //     0x11c06d4: ldur            x1, [x0, #7]
    // 0x11c06d8: cmp             x1, #0
    // 0x11c06dc: b.gt            #0x11c06ec
    // 0x11c06e0: d1 = 1.000000
    //     0x11c06e0: fmov            d1, #1.00000000
    // 0x11c06e4: fsub            d2, d1, d0
    // 0x11c06e8: mov             v0.16b, v2.16b
    // 0x11c06ec: ret
    //     0x11c06ec: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x11c06f0, size: 0xac
    // 0x11c06f0: EnterFrame
    //     0x11c06f0: stp             fp, lr, [SP, #-0x10]!
    //     0x11c06f4: mov             fp, SP
    // 0x11c06f8: ldr             x0, [fp, #0x10]
    // 0x11c06fc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x11c06fc: ldur            w1, [x0, #0x17]
    // 0x11c0700: DecompressPointer r1
    //     0x11c0700: add             x1, x1, HEAP, lsl #32
    // 0x11c0704: CheckStackOverflow
    //     0x11c0704: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11c0708: cmp             SP, x16
    //     0x11c070c: b.ls            #0x11c0780
    // 0x11c0710: LoadField: r0 = r1->field_f
    //     0x11c0710: ldur            w0, [x1, #0xf]
    // 0x11c0714: DecompressPointer r0
    //     0x11c0714: add             x0, x0, HEAP, lsl #32
    // 0x11c0718: LoadField: r1 = r0->field_53
    //     0x11c0718: ldur            w1, [x0, #0x53]
    // 0x11c071c: DecompressPointer r1
    //     0x11c071c: add             x1, x1, HEAP, lsl #32
    // 0x11c0720: StoreField: r1->field_2b = rNULL
    //     0x11c0720: stur            NULL, [x1, #0x2b]
    // 0x11c0724: LoadField: r2 = r0->field_6f
    //     0x11c0724: ldur            w2, [x0, #0x6f]
    // 0x11c0728: DecompressPointer r2
    //     0x11c0728: add             x2, x2, HEAP, lsl #32
    // 0x11c072c: tbz             w2, #4, #0x11c0770
    // 0x11c0730: LoadField: r0 = r1->field_1f
    //     0x11c0730: ldur            w0, [x1, #0x1f]
    // 0x11c0734: DecompressPointer r0
    //     0x11c0734: add             x0, x0, HEAP, lsl #32
    // 0x11c0738: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11c073c: cmp             w0, w16
    // 0x11c0740: b.eq            #0x11c0788
    // 0x11c0744: LoadField: r1 = r0->field_43
    //     0x11c0744: ldur            w1, [x0, #0x43]
    // 0x11c0748: DecompressPointer r1
    //     0x11c0748: add             x1, x1, HEAP, lsl #32
    // 0x11c074c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11c0750: cmp             w1, w16
    // 0x11c0754: b.eq            #0x11c0794
    // 0x11c0758: r16 = Instance_AnimationStatus
    //     0x11c0758: ldr             x16, [PP, #0x51a0]  ; [pp+0x51a0] Obj!AnimationStatus@12c61a1
    // 0x11c075c: cmp             w1, w16
    // 0x11c0760: b.ne            #0x11c0770
    // 0x11c0764: mov             x1, x0
    // 0x11c0768: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x11c0768: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x11c076c: r0 = reverse()
    //     0x11c076c: bl              #0x8c8688  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0x11c0770: r0 = Null
    //     0x11c0770: mov             x0, NULL
    // 0x11c0774: LeaveFrame
    //     0x11c0774: mov             SP, fp
    //     0x11c0778: ldp             fp, lr, [SP], #0x10
    // 0x11c077c: ret
    //     0x11c077c: ret             
    // 0x11c0780: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11c0780: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11c0784: b               #0x11c0710
    // 0x11c0788: r9 = valueIndicatorController
    //     0x11c0788: add             x9, PP, #0x99, lsl #12  ; [pp+0x99008] Field <_SliderState@125231897.valueIndicatorController>: late (offset: 0x20)
    //     0x11c078c: ldr             x9, [x9, #8]
    // 0x11c0790: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x11c0790: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x11c0794: r9 = _status
    //     0x11c0794: ldr             x9, [PP, #0x51e8]  ; [pp+0x51e8] Field <AnimationController._status@62066280>: late (offset: 0x44)
    // 0x11c0798: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x11c0798: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void _endInteraction(dynamic) {
    // ** addr: 0x11c079c, size: 0x38
    // 0x11c079c: EnterFrame
    //     0x11c079c: stp             fp, lr, [SP, #-0x10]!
    //     0x11c07a0: mov             fp, SP
    // 0x11c07a4: ldr             x0, [fp, #0x10]
    // 0x11c07a8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x11c07a8: ldur            w1, [x0, #0x17]
    // 0x11c07ac: DecompressPointer r1
    //     0x11c07ac: add             x1, x1, HEAP, lsl #32
    // 0x11c07b0: CheckStackOverflow
    //     0x11c07b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11c07b4: cmp             SP, x16
    //     0x11c07b8: b.ls            #0x11c07cc
    // 0x11c07bc: r0 = _endInteraction()
    //     0x11c07bc: bl              #0x11c01ac  ; [package:flutter/src/material/slider.dart] _RenderSlider::_endInteraction
    // 0x11c07c0: LeaveFrame
    //     0x11c07c0: mov             SP, fp
    //     0x11c07c4: ldp             fp, lr, [SP], #0x10
    // 0x11c07c8: ret
    //     0x11c07c8: ret             
    // 0x11c07cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11c07cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11c07d0: b               #0x11c07bc
  }
  [closure] void _handleDragUpdate(dynamic, DragUpdateDetails) {
    // ** addr: 0x11c07d4, size: 0x3c
    // 0x11c07d4: EnterFrame
    //     0x11c07d4: stp             fp, lr, [SP, #-0x10]!
    //     0x11c07d8: mov             fp, SP
    // 0x11c07dc: ldr             x0, [fp, #0x18]
    // 0x11c07e0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x11c07e0: ldur            w1, [x0, #0x17]
    // 0x11c07e4: DecompressPointer r1
    //     0x11c07e4: add             x1, x1, HEAP, lsl #32
    // 0x11c07e8: CheckStackOverflow
    //     0x11c07e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11c07ec: cmp             SP, x16
    //     0x11c07f0: b.ls            #0x11c0808
    // 0x11c07f4: ldr             x2, [fp, #0x10]
    // 0x11c07f8: r0 = _handleDragUpdate()
    //     0x11c07f8: bl              #0x11c0810  ; [package:flutter/src/material/slider.dart] _RenderSlider::_handleDragUpdate
    // 0x11c07fc: LeaveFrame
    //     0x11c07fc: mov             SP, fp
    //     0x11c0800: ldp             fp, lr, [SP], #0x10
    // 0x11c0804: ret
    //     0x11c0804: ret             
    // 0x11c0808: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11c0808: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11c080c: b               #0x11c07f4
  }
  _ _handleDragUpdate(/* No info */) {
    // ** addr: 0x11c0810, size: 0x178
    // 0x11c0810: EnterFrame
    //     0x11c0810: stp             fp, lr, [SP, #-0x10]!
    //     0x11c0814: mov             fp, SP
    // 0x11c0818: AllocStack(0x10)
    //     0x11c0818: sub             SP, SP, #0x10
    // 0x11c081c: SetupParameters(_RenderSlider this /* r1 => r0, fp-0x10 */)
    //     0x11c081c: mov             x0, x1
    //     0x11c0820: stur            x1, [fp, #-0x10]
    // 0x11c0824: CheckStackOverflow
    //     0x11c0824: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11c0828: cmp             SP, x16
    //     0x11c082c: b.ls            #0x11c0958
    // 0x11c0830: LoadField: r1 = r0->field_53
    //     0x11c0830: ldur            w1, [x0, #0x53]
    // 0x11c0834: DecompressPointer r1
    //     0x11c0834: add             x1, x1, HEAP, lsl #32
    // 0x11c0838: LoadField: r3 = r1->field_f
    //     0x11c0838: ldur            w3, [x1, #0xf]
    // 0x11c083c: DecompressPointer r3
    //     0x11c083c: add             x3, x3, HEAP, lsl #32
    // 0x11c0840: cmp             w3, NULL
    // 0x11c0844: b.ne            #0x11c0858
    // 0x11c0848: r0 = Null
    //     0x11c0848: mov             x0, NULL
    // 0x11c084c: LeaveFrame
    //     0x11c084c: mov             SP, fp
    //     0x11c0850: ldp             fp, lr, [SP], #0x10
    // 0x11c0854: ret
    //     0x11c0854: ret             
    // 0x11c0858: LoadField: r1 = r0->field_6f
    //     0x11c0858: ldur            w1, [x0, #0x6f]
    // 0x11c085c: DecompressPointer r1
    //     0x11c085c: add             x1, x1, HEAP, lsl #32
    // 0x11c0860: tbnz            w1, #4, #0x11c0948
    // 0x11c0864: LoadField: r1 = r0->field_b3
    //     0x11c0864: ldur            w1, [x0, #0xb3]
    // 0x11c0868: DecompressPointer r1
    //     0x11c0868: add             x1, x1, HEAP, lsl #32
    // 0x11c086c: cmp             w1, NULL
    // 0x11c0870: b.eq            #0x11c0948
    // 0x11c0874: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x11c0874: ldur            w4, [x2, #0x17]
    // 0x11c0878: DecompressPointer r4
    //     0x11c0878: add             x4, x4, HEAP, lsl #32
    // 0x11c087c: stur            x4, [fp, #-8]
    // 0x11c0880: cmp             w4, NULL
    // 0x11c0884: b.eq            #0x11c0960
    // 0x11c0888: LoadField: r3 = r0->field_a3
    //     0x11c0888: ldur            w3, [x0, #0xa3]
    // 0x11c088c: DecompressPointer r3
    //     0x11c088c: add             x3, x3, HEAP, lsl #32
    // 0x11c0890: LoadField: r1 = r3->field_57
    //     0x11c0890: ldur            w1, [x3, #0x57]
    // 0x11c0894: DecompressPointer r1
    //     0x11c0894: add             x1, x1, HEAP, lsl #32
    // 0x11c0898: cmp             w1, NULL
    // 0x11c089c: b.eq            #0x11c0964
    // 0x11c08a0: mov             x2, x0
    // 0x11c08a4: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x11c08a4: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x11c08a8: r0 = getPreferredRect()
    //     0x11c08a8: bl              #0xc12580  ; [dart:mixin_deduplication] _MixinApplication107&SliderTrackShape&BaseSliderTrackShape::getPreferredRect
    // 0x11c08ac: ArrayLoad: d0 = r0[0]  ; List_8
    //     0x11c08ac: ldur            d0, [x0, #0x17]
    // 0x11c08b0: LoadField: d1 = r0->field_7
    //     0x11c08b0: ldur            d1, [x0, #7]
    // 0x11c08b4: fsub            d2, d0, d1
    // 0x11c08b8: ldur            x0, [fp, #-8]
    // 0x11c08bc: LoadField: d0 = r0->field_7
    //     0x11c08bc: ldur            d0, [x0, #7]
    // 0x11c08c0: fdiv            d1, d0, d2
    // 0x11c08c4: ldur            x1, [fp, #-0x10]
    // 0x11c08c8: LoadField: d0 = r1->field_77
    //     0x11c08c8: ldur            d0, [x1, #0x77]
    // 0x11c08cc: LoadField: r0 = r1->field_bf
    //     0x11c08cc: ldur            w0, [x1, #0xbf]
    // 0x11c08d0: DecompressPointer r0
    //     0x11c08d0: add             x0, x0, HEAP, lsl #32
    // 0x11c08d4: LoadField: r2 = r0->field_7
    //     0x11c08d4: ldur            x2, [x0, #7]
    // 0x11c08d8: cmp             x2, #0
    // 0x11c08dc: b.gt            #0x11c08e8
    // 0x11c08e0: fneg            d2, d1
    // 0x11c08e4: mov             v1.16b, v2.16b
    // 0x11c08e8: fadd            d2, d0, d1
    // 0x11c08ec: StoreField: r1->field_77 = d2
    //     0x11c08ec: stur            d2, [x1, #0x77]
    // 0x11c08f0: LoadField: r0 = r1->field_b3
    //     0x11c08f0: ldur            w0, [x1, #0xb3]
    // 0x11c08f4: DecompressPointer r0
    //     0x11c08f4: add             x0, x0, HEAP, lsl #32
    // 0x11c08f8: stur            x0, [fp, #-8]
    // 0x11c08fc: cmp             w0, NULL
    // 0x11c0900: b.eq            #0x11c0968
    // 0x11c0904: mov             v0.16b, v2.16b
    // 0x11c0908: r0 = _discretize()
    //     0x11c0908: bl              #0xb1e0b0  ; [package:flutter/src/material/slider.dart] _RenderSlider::_discretize
    // 0x11c090c: ldur            x0, [fp, #-8]
    // 0x11c0910: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x11c0910: ldur            w1, [x0, #0x17]
    // 0x11c0914: DecompressPointer r1
    //     0x11c0914: add             x1, x1, HEAP, lsl #32
    // 0x11c0918: r2 = inline_Allocate_Double()
    //     0x11c0918: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0x11c091c: add             x2, x2, #0x10
    //     0x11c0920: cmp             x0, x2
    //     0x11c0924: b.ls            #0x11c096c
    //     0x11c0928: str             x2, [THR, #0x60]  ; THR::top
    //     0x11c092c: sub             x2, x2, #0xf
    //     0x11c0930: mov             x0, #0xe19c
    //     0x11c0934: movk            x0, #3, lsl #16
    //     0x11c0938: stur            x0, [x2, #-1]
    // 0x11c093c: dmb             ishst
    // 0x11c0940: StoreField: r2->field_7 = d0
    //     0x11c0940: stur            d0, [x2, #7]
    // 0x11c0944: r0 = _handleChanged()
    //     0x11c0944: bl              #0xbf966c  ; [package:flutter/src/material/slider.dart] _SliderState::_handleChanged
    // 0x11c0948: r0 = Null
    //     0x11c0948: mov             x0, NULL
    // 0x11c094c: LeaveFrame
    //     0x11c094c: mov             SP, fp
    //     0x11c0950: ldp             fp, lr, [SP], #0x10
    // 0x11c0954: ret
    //     0x11c0954: ret             
    // 0x11c0958: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11c0958: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11c095c: b               #0x11c0830
    // 0x11c0960: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x11c0960: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x11c0964: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x11c0964: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x11c0968: r0 = NullCastErrorSharedWithFPURegs()
    //     0x11c0968: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0x11c096c: SaveReg d0
    //     0x11c096c: str             q0, [SP, #-0x10]!
    // 0x11c0970: SaveReg r1
    //     0x11c0970: str             x1, [SP, #-8]!
    // 0x11c0974: r0 = AllocateDouble()
    //     0x11c0974: bl              #0x13df878  ; AllocateDoubleStub
    // 0x11c0978: mov             x2, x0
    // 0x11c097c: RestoreReg r1
    //     0x11c097c: ldr             x1, [SP], #8
    // 0x11c0980: RestoreReg d0
    //     0x11c0980: ldr             q0, [SP], #0x10
    // 0x11c0984: b               #0x11c0940
  }
  [closure] void _handleDragStart(dynamic, DragStartDetails) {
    // ** addr: 0x11c0988, size: 0x3c
    // 0x11c0988: EnterFrame
    //     0x11c0988: stp             fp, lr, [SP, #-0x10]!
    //     0x11c098c: mov             fp, SP
    // 0x11c0990: ldr             x0, [fp, #0x18]
    // 0x11c0994: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x11c0994: ldur            w1, [x0, #0x17]
    // 0x11c0998: DecompressPointer r1
    //     0x11c0998: add             x1, x1, HEAP, lsl #32
    // 0x11c099c: CheckStackOverflow
    //     0x11c099c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11c09a0: cmp             SP, x16
    //     0x11c09a4: b.ls            #0x11c09bc
    // 0x11c09a8: ldr             x2, [fp, #0x10]
    // 0x11c09ac: r0 = _handleDragStart()
    //     0x11c09ac: bl              #0x11c0358  ; [package:flutter/src/material/slider.dart] _RenderSlider::_handleDragStart
    // 0x11c09b0: LeaveFrame
    //     0x11c09b0: mov             SP, fp
    //     0x11c09b4: ldp             fp, lr, [SP], #0x10
    // 0x11c09b8: ret
    //     0x11c09b8: ret             
    // 0x11c09bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11c09bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11c09c0: b               #0x11c09a8
  }
}

// class id: 5070, size: 0xa0, field offset: 0x98
class _SliderDefaultsM3 extends SliderThemeData {

  late final ColorScheme _colors; // offset: 0x9c

  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xd3df80, size: 0x178
    // 0xd3df80: EnterFrame
    //     0xd3df80: stp             fp, lr, [SP, #-0x10]!
    //     0xd3df84: mov             fp, SP
    // 0xd3df88: AllocStack(0x8)
    //     0xd3df88: sub             SP, SP, #8
    // 0xd3df8c: SetupParameters([dynamic _ /* r0 */])
    //     0xd3df8c: ldr             x0, [fp, #0x18]
    //     0xd3df90: ldur            w3, [x0, #0x17]
    //     0xd3df94: add             x3, x3, HEAP, lsl #32
    //     0xd3df98: stur            x3, [fp, #-8]
    // 0xd3df9c: CheckStackOverflow
    //     0xd3df9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd3dfa0: cmp             SP, x16
    //     0xd3dfa4: b.ls            #0xd3e0f0
    // 0xd3dfa8: ldr             x4, [fp, #0x10]
    // 0xd3dfac: r0 = LoadClassIdInstr(r4)
    //     0xd3dfac: ldur            x0, [x4, #-1]
    //     0xd3dfb0: ubfx            x0, x0, #0xc, #0x14
    // 0xd3dfb4: mov             x1, x4
    // 0xd3dfb8: r2 = Instance_WidgetState
    //     0xd3dfb8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ad0] Obj!WidgetState@12c87a1
    //     0xd3dfbc: ldr             x2, [x2, #0xad0]
    // 0xd3dfc0: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd3dfc0: mov             x17, #0x2929
    //     0xd3dfc4: movk            x17, #1, lsl #16
    //     0xd3dfc8: add             lr, x0, x17
    //     0xd3dfcc: ldr             lr, [x21, lr, lsl #3]
    //     0xd3dfd0: blr             lr
    // 0xd3dfd4: tbz             w0, #4, #0xd3e048
    // 0xd3dfd8: ldr             x3, [fp, #0x10]
    // 0xd3dfdc: r0 = LoadClassIdInstr(r3)
    //     0xd3dfdc: ldur            x0, [x3, #-1]
    //     0xd3dfe0: ubfx            x0, x0, #0xc, #0x14
    // 0xd3dfe4: mov             x1, x3
    // 0xd3dfe8: r2 = Instance_WidgetState
    //     0xd3dfe8: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xd3dfec: ldr             x2, [x2, #0xa50]
    // 0xd3dff0: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd3dff0: mov             x17, #0x2929
    //     0xd3dff4: movk            x17, #1, lsl #16
    //     0xd3dff8: add             lr, x0, x17
    //     0xd3dffc: ldr             lr, [x21, lr, lsl #3]
    //     0xd3e000: blr             lr
    // 0xd3e004: tbz             w0, #4, #0xd3e080
    // 0xd3e008: ldr             x1, [fp, #0x10]
    // 0xd3e00c: r0 = LoadClassIdInstr(r1)
    //     0xd3e00c: ldur            x0, [x1, #-1]
    //     0xd3e010: ubfx            x0, x0, #0xc, #0x14
    // 0xd3e014: r2 = Instance_WidgetState
    //     0xd3e014: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xd3e018: ldr             x2, [x2, #0xa60]
    // 0xd3e01c: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd3e01c: mov             x17, #0x2929
    //     0xd3e020: movk            x17, #1, lsl #16
    //     0xd3e024: add             lr, x0, x17
    //     0xd3e028: ldr             lr, [x21, lr, lsl #3]
    //     0xd3e02c: blr             lr
    // 0xd3e030: tbz             w0, #4, #0xd3e0b8
    // 0xd3e034: r0 = Instance_Color
    //     0xd3e034: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xd3e038: ldr             x0, [x0, #0x810]
    // 0xd3e03c: LeaveFrame
    //     0xd3e03c: mov             SP, fp
    //     0xd3e040: ldp             fp, lr, [SP], #0x10
    // 0xd3e044: ret
    //     0xd3e044: ret             
    // 0xd3e048: ldur            x0, [fp, #-8]
    // 0xd3e04c: LoadField: r1 = r0->field_f
    //     0xd3e04c: ldur            w1, [x0, #0xf]
    // 0xd3e050: DecompressPointer r1
    //     0xd3e050: add             x1, x1, HEAP, lsl #32
    // 0xd3e054: LoadField: r0 = r1->field_9b
    //     0xd3e054: ldur            w0, [x1, #0x9b]
    // 0xd3e058: DecompressPointer r0
    //     0xd3e058: add             x0, x0, HEAP, lsl #32
    // 0xd3e05c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3e060: cmp             w0, w16
    // 0xd3e064: b.ne            #0xd3e074
    // 0xd3e068: r2 = _colors
    //     0xd3e068: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0xd3e06c: ldr             x2, [x2, #0xab0]
    // 0xd3e070: r0 = InitLateFinalInstanceField()
    //     0xd3e070: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3e074: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xd3e074: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xd3e078: r0 = Throw()
    //     0xd3e078: bl              #0x13ddb2c  ; ThrowStub
    // 0xd3e07c: brk             #0
    // 0xd3e080: ldur            x0, [fp, #-8]
    // 0xd3e084: LoadField: r1 = r0->field_f
    //     0xd3e084: ldur            w1, [x0, #0xf]
    // 0xd3e088: DecompressPointer r1
    //     0xd3e088: add             x1, x1, HEAP, lsl #32
    // 0xd3e08c: LoadField: r0 = r1->field_9b
    //     0xd3e08c: ldur            w0, [x1, #0x9b]
    // 0xd3e090: DecompressPointer r0
    //     0xd3e090: add             x0, x0, HEAP, lsl #32
    // 0xd3e094: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3e098: cmp             w0, w16
    // 0xd3e09c: b.ne            #0xd3e0ac
    // 0xd3e0a0: r2 = _colors
    //     0xd3e0a0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0xd3e0a4: ldr             x2, [x2, #0xab0]
    // 0xd3e0a8: r0 = InitLateFinalInstanceField()
    //     0xd3e0a8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3e0ac: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xd3e0ac: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xd3e0b0: r0 = Throw()
    //     0xd3e0b0: bl              #0x13ddb2c  ; ThrowStub
    // 0xd3e0b4: brk             #0
    // 0xd3e0b8: ldur            x0, [fp, #-8]
    // 0xd3e0bc: LoadField: r1 = r0->field_f
    //     0xd3e0bc: ldur            w1, [x0, #0xf]
    // 0xd3e0c0: DecompressPointer r1
    //     0xd3e0c0: add             x1, x1, HEAP, lsl #32
    // 0xd3e0c4: LoadField: r0 = r1->field_9b
    //     0xd3e0c4: ldur            w0, [x1, #0x9b]
    // 0xd3e0c8: DecompressPointer r0
    //     0xd3e0c8: add             x0, x0, HEAP, lsl #32
    // 0xd3e0cc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3e0d0: cmp             w0, w16
    // 0xd3e0d4: b.ne            #0xd3e0e4
    // 0xd3e0d8: r2 = _colors
    //     0xd3e0d8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0xd3e0dc: ldr             x2, [x2, #0xab0]
    // 0xd3e0e0: r0 = InitLateFinalInstanceField()
    //     0xd3e0e0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3e0e4: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xd3e0e4: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xd3e0e8: r0 = Throw()
    //     0xd3e0e8: bl              #0x13ddb2c  ; ThrowStub
    // 0xd3e0ec: brk             #0
    // 0xd3e0f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd3e0f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd3e0f4: b               #0xd3dfa8
  }
  [closure] Size <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0x1136ed8, size: 0x13c
    // 0x1136ed8: EnterFrame
    //     0x1136ed8: stp             fp, lr, [SP, #-0x10]!
    //     0x1136edc: mov             fp, SP
    // 0x1136ee0: CheckStackOverflow
    //     0x1136ee0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1136ee4: cmp             SP, x16
    //     0x1136ee8: b.ls            #0x113700c
    // 0x1136eec: ldr             x3, [fp, #0x10]
    // 0x1136ef0: r0 = LoadClassIdInstr(r3)
    //     0x1136ef0: ldur            x0, [x3, #-1]
    //     0x1136ef4: ubfx            x0, x0, #0xc, #0x14
    // 0x1136ef8: mov             x1, x3
    // 0x1136efc: r2 = Instance_WidgetState
    //     0x1136efc: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a70] Obj!WidgetState@12c86e1
    //     0x1136f00: ldr             x2, [x2, #0xa70]
    // 0x1136f04: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1136f04: mov             x17, #0x2929
    //     0x1136f08: movk            x17, #1, lsl #16
    //     0x1136f0c: add             lr, x0, x17
    //     0x1136f10: ldr             lr, [x21, lr, lsl #3]
    //     0x1136f14: blr             lr
    // 0x1136f18: tbnz            w0, #4, #0x1136f30
    // 0x1136f1c: r0 = Instance_Size
    //     0x1136f1c: add             x0, PP, #0x26, lsl #12  ; [pp+0x26ab8] Obj!Size@12a7991
    //     0x1136f20: ldr             x0, [x0, #0xab8]
    // 0x1136f24: LeaveFrame
    //     0x1136f24: mov             SP, fp
    //     0x1136f28: ldp             fp, lr, [SP], #0x10
    // 0x1136f2c: ret
    //     0x1136f2c: ret             
    // 0x1136f30: ldr             x3, [fp, #0x10]
    // 0x1136f34: r0 = LoadClassIdInstr(r3)
    //     0x1136f34: ldur            x0, [x3, #-1]
    //     0x1136f38: ubfx            x0, x0, #0xc, #0x14
    // 0x1136f3c: mov             x1, x3
    // 0x1136f40: r2 = Instance_WidgetState
    //     0x1136f40: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0x1136f44: ldr             x2, [x2, #0xa50]
    // 0x1136f48: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1136f48: mov             x17, #0x2929
    //     0x1136f4c: movk            x17, #1, lsl #16
    //     0x1136f50: add             lr, x0, x17
    //     0x1136f54: ldr             lr, [x21, lr, lsl #3]
    //     0x1136f58: blr             lr
    // 0x1136f5c: tbnz            w0, #4, #0x1136f74
    // 0x1136f60: r0 = Instance_Size
    //     0x1136f60: add             x0, PP, #0x26, lsl #12  ; [pp+0x26ab8] Obj!Size@12a7991
    //     0x1136f64: ldr             x0, [x0, #0xab8]
    // 0x1136f68: LeaveFrame
    //     0x1136f68: mov             SP, fp
    //     0x1136f6c: ldp             fp, lr, [SP], #0x10
    // 0x1136f70: ret
    //     0x1136f70: ret             
    // 0x1136f74: ldr             x3, [fp, #0x10]
    // 0x1136f78: r0 = LoadClassIdInstr(r3)
    //     0x1136f78: ldur            x0, [x3, #-1]
    //     0x1136f7c: ubfx            x0, x0, #0xc, #0x14
    // 0x1136f80: mov             x1, x3
    // 0x1136f84: r2 = Instance_WidgetState
    //     0x1136f84: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0x1136f88: ldr             x2, [x2, #0xa60]
    // 0x1136f8c: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1136f8c: mov             x17, #0x2929
    //     0x1136f90: movk            x17, #1, lsl #16
    //     0x1136f94: add             lr, x0, x17
    //     0x1136f98: ldr             lr, [x21, lr, lsl #3]
    //     0x1136f9c: blr             lr
    // 0x1136fa0: tbnz            w0, #4, #0x1136fb8
    // 0x1136fa4: r0 = Instance_Size
    //     0x1136fa4: add             x0, PP, #0x26, lsl #12  ; [pp+0x26ac0] Obj!Size@12a7971
    //     0x1136fa8: ldr             x0, [x0, #0xac0]
    // 0x1136fac: LeaveFrame
    //     0x1136fac: mov             SP, fp
    //     0x1136fb0: ldp             fp, lr, [SP], #0x10
    // 0x1136fb4: ret
    //     0x1136fb4: ret             
    // 0x1136fb8: ldr             x1, [fp, #0x10]
    // 0x1136fbc: r0 = LoadClassIdInstr(r1)
    //     0x1136fbc: ldur            x0, [x1, #-1]
    //     0x1136fc0: ubfx            x0, x0, #0xc, #0x14
    // 0x1136fc4: r2 = Instance_WidgetState
    //     0x1136fc4: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a48] Obj!WidgetState@12c8741
    //     0x1136fc8: ldr             x2, [x2, #0xa48]
    // 0x1136fcc: r0 = GDT[cid_x0 + 0x12929]()
    //     0x1136fcc: mov             x17, #0x2929
    //     0x1136fd0: movk            x17, #1, lsl #16
    //     0x1136fd4: add             lr, x0, x17
    //     0x1136fd8: ldr             lr, [x21, lr, lsl #3]
    //     0x1136fdc: blr             lr
    // 0x1136fe0: tbnz            w0, #4, #0x1136ff8
    // 0x1136fe4: r0 = Instance_Size
    //     0x1136fe4: add             x0, PP, #0x26, lsl #12  ; [pp+0x26ac0] Obj!Size@12a7971
    //     0x1136fe8: ldr             x0, [x0, #0xac0]
    // 0x1136fec: LeaveFrame
    //     0x1136fec: mov             SP, fp
    //     0x1136ff0: ldp             fp, lr, [SP], #0x10
    // 0x1136ff4: ret
    //     0x1136ff4: ret             
    // 0x1136ff8: r0 = Instance_Size
    //     0x1136ff8: add             x0, PP, #0x26, lsl #12  ; [pp+0x26ab8] Obj!Size@12a7991
    //     0x1136ffc: ldr             x0, [x0, #0xab8]
    // 0x1137000: LeaveFrame
    //     0x1137000: mov             SP, fp
    //     0x1137004: ldp             fp, lr, [SP], #0x10
    // 0x1137008: ret
    //     0x1137008: ret             
    // 0x113700c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x113700c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1137010: b               #0x1136eec
  }
}

// class id: 5071, size: 0xa0, field offset: 0x98
class _SliderDefaultsM3Year2023 extends SliderThemeData {

  late final ColorScheme _colors; // offset: 0x9c

  [closure] Color <anonymous closure>(dynamic, Set<WidgetState>) {
    // ** addr: 0xd3ddc4, size: 0x1bc
    // 0xd3ddc4: EnterFrame
    //     0xd3ddc4: stp             fp, lr, [SP, #-0x10]!
    //     0xd3ddc8: mov             fp, SP
    // 0xd3ddcc: AllocStack(0x8)
    //     0xd3ddcc: sub             SP, SP, #8
    // 0xd3ddd0: SetupParameters([dynamic _ /* r0 */])
    //     0xd3ddd0: ldr             x0, [fp, #0x18]
    //     0xd3ddd4: ldur            w3, [x0, #0x17]
    //     0xd3ddd8: add             x3, x3, HEAP, lsl #32
    //     0xd3dddc: stur            x3, [fp, #-8]
    // 0xd3dde0: CheckStackOverflow
    //     0xd3dde0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd3dde4: cmp             SP, x16
    //     0xd3dde8: b.ls            #0xd3df78
    // 0xd3ddec: ldr             x4, [fp, #0x10]
    // 0xd3ddf0: r0 = LoadClassIdInstr(r4)
    //     0xd3ddf0: ldur            x0, [x4, #-1]
    //     0xd3ddf4: ubfx            x0, x0, #0xc, #0x14
    // 0xd3ddf8: mov             x1, x4
    // 0xd3ddfc: r2 = Instance_WidgetState
    //     0xd3ddfc: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ad0] Obj!WidgetState@12c87a1
    //     0xd3de00: ldr             x2, [x2, #0xad0]
    // 0xd3de04: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd3de04: mov             x17, #0x2929
    //     0xd3de08: movk            x17, #1, lsl #16
    //     0xd3de0c: add             lr, x0, x17
    //     0xd3de10: ldr             lr, [x21, lr, lsl #3]
    //     0xd3de14: blr             lr
    // 0xd3de18: tbnz            w0, #4, #0xd3de68
    // 0xd3de1c: ldur            x3, [fp, #-8]
    // 0xd3de20: LoadField: r1 = r3->field_f
    //     0xd3de20: ldur            w1, [x3, #0xf]
    // 0xd3de24: DecompressPointer r1
    //     0xd3de24: add             x1, x1, HEAP, lsl #32
    // 0xd3de28: LoadField: r0 = r1->field_9b
    //     0xd3de28: ldur            w0, [x1, #0x9b]
    // 0xd3de2c: DecompressPointer r0
    //     0xd3de2c: add             x0, x0, HEAP, lsl #32
    // 0xd3de30: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3de34: cmp             w0, w16
    // 0xd3de38: b.ne            #0xd3de48
    // 0xd3de3c: r2 = _colors
    //     0xd3de3c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0xd3de40: ldr             x2, [x2, #0xa10]
    // 0xd3de44: r0 = InitLateFinalInstanceField()
    //     0xd3de44: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3de48: LoadField: r1 = r0->field_b
    //     0xd3de48: ldur            w1, [x0, #0xb]
    // 0xd3de4c: DecompressPointer r1
    //     0xd3de4c: add             x1, x1, HEAP, lsl #32
    // 0xd3de50: d0 = 0.100000
    //     0xd3de50: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0xd3de54: ldr             d0, [x17, #0x1e0]
    // 0xd3de58: r0 = withOpacity()
    //     0xd3de58: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xd3de5c: LeaveFrame
    //     0xd3de5c: mov             SP, fp
    //     0xd3de60: ldp             fp, lr, [SP], #0x10
    // 0xd3de64: ret
    //     0xd3de64: ret             
    // 0xd3de68: ldr             x4, [fp, #0x10]
    // 0xd3de6c: ldur            x3, [fp, #-8]
    // 0xd3de70: r0 = LoadClassIdInstr(r4)
    //     0xd3de70: ldur            x0, [x4, #-1]
    //     0xd3de74: ubfx            x0, x0, #0xc, #0x14
    // 0xd3de78: mov             x1, x4
    // 0xd3de7c: r2 = Instance_WidgetState
    //     0xd3de7c: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xd3de80: ldr             x2, [x2, #0xa50]
    // 0xd3de84: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd3de84: mov             x17, #0x2929
    //     0xd3de88: movk            x17, #1, lsl #16
    //     0xd3de8c: add             lr, x0, x17
    //     0xd3de90: ldr             lr, [x21, lr, lsl #3]
    //     0xd3de94: blr             lr
    // 0xd3de98: tbnz            w0, #4, #0xd3dee8
    // 0xd3de9c: ldur            x3, [fp, #-8]
    // 0xd3dea0: LoadField: r1 = r3->field_f
    //     0xd3dea0: ldur            w1, [x3, #0xf]
    // 0xd3dea4: DecompressPointer r1
    //     0xd3dea4: add             x1, x1, HEAP, lsl #32
    // 0xd3dea8: LoadField: r0 = r1->field_9b
    //     0xd3dea8: ldur            w0, [x1, #0x9b]
    // 0xd3deac: DecompressPointer r0
    //     0xd3deac: add             x0, x0, HEAP, lsl #32
    // 0xd3deb0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3deb4: cmp             w0, w16
    // 0xd3deb8: b.ne            #0xd3dec8
    // 0xd3debc: r2 = _colors
    //     0xd3debc: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0xd3dec0: ldr             x2, [x2, #0xa10]
    // 0xd3dec4: r0 = InitLateFinalInstanceField()
    //     0xd3dec4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3dec8: LoadField: r1 = r0->field_b
    //     0xd3dec8: ldur            w1, [x0, #0xb]
    // 0xd3decc: DecompressPointer r1
    //     0xd3decc: add             x1, x1, HEAP, lsl #32
    // 0xd3ded0: d0 = 0.080000
    //     0xd3ded0: add             x17, PP, #0x15, lsl #12  ; [pp+0x15a58] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0xd3ded4: ldr             d0, [x17, #0xa58]
    // 0xd3ded8: r0 = withOpacity()
    //     0xd3ded8: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xd3dedc: LeaveFrame
    //     0xd3dedc: mov             SP, fp
    //     0xd3dee0: ldp             fp, lr, [SP], #0x10
    // 0xd3dee4: ret
    //     0xd3dee4: ret             
    // 0xd3dee8: ldr             x1, [fp, #0x10]
    // 0xd3deec: ldur            x3, [fp, #-8]
    // 0xd3def0: r0 = LoadClassIdInstr(r1)
    //     0xd3def0: ldur            x0, [x1, #-1]
    //     0xd3def4: ubfx            x0, x0, #0xc, #0x14
    // 0xd3def8: r2 = Instance_WidgetState
    //     0xd3def8: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xd3defc: ldr             x2, [x2, #0xa60]
    // 0xd3df00: r0 = GDT[cid_x0 + 0x12929]()
    //     0xd3df00: mov             x17, #0x2929
    //     0xd3df04: movk            x17, #1, lsl #16
    //     0xd3df08: add             lr, x0, x17
    //     0xd3df0c: ldr             lr, [x21, lr, lsl #3]
    //     0xd3df10: blr             lr
    // 0xd3df14: tbnz            w0, #4, #0xd3df64
    // 0xd3df18: ldur            x0, [fp, #-8]
    // 0xd3df1c: LoadField: r1 = r0->field_f
    //     0xd3df1c: ldur            w1, [x0, #0xf]
    // 0xd3df20: DecompressPointer r1
    //     0xd3df20: add             x1, x1, HEAP, lsl #32
    // 0xd3df24: LoadField: r0 = r1->field_9b
    //     0xd3df24: ldur            w0, [x1, #0x9b]
    // 0xd3df28: DecompressPointer r0
    //     0xd3df28: add             x0, x0, HEAP, lsl #32
    // 0xd3df2c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3df30: cmp             w0, w16
    // 0xd3df34: b.ne            #0xd3df44
    // 0xd3df38: r2 = _colors
    //     0xd3df38: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0xd3df3c: ldr             x2, [x2, #0xa10]
    // 0xd3df40: r0 = InitLateFinalInstanceField()
    //     0xd3df40: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3df44: LoadField: r1 = r0->field_b
    //     0xd3df44: ldur            w1, [x0, #0xb]
    // 0xd3df48: DecompressPointer r1
    //     0xd3df48: add             x1, x1, HEAP, lsl #32
    // 0xd3df4c: d0 = 0.100000
    //     0xd3df4c: add             x17, PP, #0x13, lsl #12  ; [pp+0x131e0] IMM: double(0.1) from 0x3fb999999999999a
    //     0xd3df50: ldr             d0, [x17, #0x1e0]
    // 0xd3df54: r0 = withOpacity()
    //     0xd3df54: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xd3df58: LeaveFrame
    //     0xd3df58: mov             SP, fp
    //     0xd3df5c: ldp             fp, lr, [SP], #0x10
    // 0xd3df60: ret
    //     0xd3df60: ret             
    // 0xd3df64: r0 = Instance_Color
    //     0xd3df64: add             x0, PP, #0x12, lsl #12  ; [pp+0x12810] Obj!Color@12a26d1
    //     0xd3df68: ldr             x0, [x0, #0x810]
    // 0xd3df6c: LeaveFrame
    //     0xd3df6c: mov             SP, fp
    //     0xd3df70: ldp             fp, lr, [SP], #0x10
    // 0xd3df74: ret
    //     0xd3df74: ret             
    // 0xd3df78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd3df78: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd3df7c: b               #0xd3ddec
  }
}

// class id: 5072, size: 0xa4, field offset: 0x98
class _SliderDefaultsM2 extends SliderThemeData {

  late final ColorScheme _colors; // offset: 0x9c
  late final SliderThemeData sliderTheme; // offset: 0xa0

  ColorScheme _colors(_SliderDefaultsM2) {
    // ** addr: 0xd3e0f8, size: 0x44
    // 0xd3e0f8: EnterFrame
    //     0xd3e0f8: stp             fp, lr, [SP, #-0x10]!
    //     0xd3e0fc: mov             fp, SP
    // 0xd3e100: CheckStackOverflow
    //     0xd3e100: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd3e104: cmp             SP, x16
    //     0xd3e108: b.ls            #0xd3e134
    // 0xd3e10c: ldr             x0, [fp, #0x10]
    // 0xd3e110: LoadField: r1 = r0->field_97
    //     0xd3e110: ldur            w1, [x0, #0x97]
    // 0xd3e114: DecompressPointer r1
    //     0xd3e114: add             x1, x1, HEAP, lsl #32
    // 0xd3e118: r0 = of()
    //     0xd3e118: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd3e11c: LoadField: r1 = r0->field_3f
    //     0xd3e11c: ldur            w1, [x0, #0x3f]
    // 0xd3e120: DecompressPointer r1
    //     0xd3e120: add             x1, x1, HEAP, lsl #32
    // 0xd3e124: mov             x0, x1
    // 0xd3e128: LeaveFrame
    //     0xd3e128: mov             SP, fp
    //     0xd3e12c: ldp             fp, lr, [SP], #0x10
    // 0xd3e130: ret
    //     0xd3e130: ret             
    // 0xd3e134: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd3e134: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd3e138: b               #0xd3e10c
  }
  SliderThemeData sliderTheme(_SliderDefaultsM2) {
    // ** addr: 0xd3e13c, size: 0x38
    // 0xd3e13c: EnterFrame
    //     0xd3e13c: stp             fp, lr, [SP, #-0x10]!
    //     0xd3e140: mov             fp, SP
    // 0xd3e144: CheckStackOverflow
    //     0xd3e144: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd3e148: cmp             SP, x16
    //     0xd3e14c: b.ls            #0xd3e16c
    // 0xd3e150: ldr             x0, [fp, #0x10]
    // 0xd3e154: LoadField: r1 = r0->field_97
    //     0xd3e154: ldur            w1, [x0, #0x97]
    // 0xd3e158: DecompressPointer r1
    //     0xd3e158: add             x1, x1, HEAP, lsl #32
    // 0xd3e15c: r0 = of()
    //     0xd3e15c: bl              #0xd3d7b8  ; [package:flutter/src/material/slider_theme.dart] SliderTheme::of
    // 0xd3e160: LeaveFrame
    //     0xd3e160: mov             SP, fp
    //     0xd3e164: ldp             fp, lr, [SP], #0x10
    // 0xd3e168: ret
    //     0xd3e168: ret             
    // 0xd3e16c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd3e16c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd3e170: b               #0xd3e150
  }
}

// class id: 5114, size: 0xc, field offset: 0x8
//   const constructor, 
class _AdjustSliderIntent extends Intent {

  _SliderAdjustmentType field_8;
}

// class id: 5702, size: 0x58, field offset: 0x1c
class _SliderState extends _MixinApplication106&State&TickerProviderStateMixin {

  late Map<Type, Action<Intent>> _actionMap; // offset: 0x34
  late AnimationController overlayController; // offset: 0x1c
  late AnimationController valueIndicatorController; // offset: 0x20
  late AnimationController enableController; // offset: 0x24
  late AnimationController positionController; // offset: 0x28

  get _ focusNode(/* No info */) {
    // ** addr: 0xbf9308, size: 0x3c
    // 0xbf9308: EnterFrame
    //     0xbf9308: stp             fp, lr, [SP, #-0x10]!
    //     0xbf930c: mov             fp, SP
    // 0xbf9310: LoadField: r2 = r1->field_b
    //     0xbf9310: ldur            w2, [x1, #0xb]
    // 0xbf9314: DecompressPointer r2
    //     0xbf9314: add             x2, x2, HEAP, lsl #32
    // 0xbf9318: cmp             w2, NULL
    // 0xbf931c: b.eq            #0xbf933c
    // 0xbf9320: LoadField: r0 = r1->field_43
    //     0xbf9320: ldur            w0, [x1, #0x43]
    // 0xbf9324: DecompressPointer r0
    //     0xbf9324: add             x0, x0, HEAP, lsl #32
    // 0xbf9328: cmp             w0, NULL
    // 0xbf932c: b.eq            #0xbf9340
    // 0xbf9330: LeaveFrame
    //     0xbf9330: mov             SP, fp
    //     0xbf9334: ldp             fp, lr, [SP], #0x10
    // 0xbf9338: ret
    //     0xbf9338: ret             
    // 0xbf933c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf933c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf9340: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf9340: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleDragEnd(dynamic, double) {
    // ** addr: 0xbf9514, size: 0x3c
    // 0xbf9514: EnterFrame
    //     0xbf9514: stp             fp, lr, [SP, #-0x10]!
    //     0xbf9518: mov             fp, SP
    // 0xbf951c: ldr             x0, [fp, #0x18]
    // 0xbf9520: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbf9520: ldur            w1, [x0, #0x17]
    // 0xbf9524: DecompressPointer r1
    //     0xbf9524: add             x1, x1, HEAP, lsl #32
    // 0xbf9528: CheckStackOverflow
    //     0xbf9528: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf952c: cmp             SP, x16
    //     0xbf9530: b.ls            #0xbf9548
    // 0xbf9534: ldr             x2, [fp, #0x10]
    // 0xbf9538: r0 = _handleDragEnd()
    //     0xbf9538: bl              #0xbf95c8  ; [package:flutter/src/material/slider.dart] _SliderState::_handleDragEnd
    // 0xbf953c: LeaveFrame
    //     0xbf953c: mov             SP, fp
    //     0xbf9540: ldp             fp, lr, [SP], #0x10
    // 0xbf9544: ret
    //     0xbf9544: ret             
    // 0xbf9548: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf9548: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf954c: b               #0xbf9534
  }
  [closure] void _handleChanged(dynamic, double) {
    // ** addr: 0xbf9550, size: 0x3c
    // 0xbf9550: EnterFrame
    //     0xbf9550: stp             fp, lr, [SP, #-0x10]!
    //     0xbf9554: mov             fp, SP
    // 0xbf9558: ldr             x0, [fp, #0x18]
    // 0xbf955c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbf955c: ldur            w1, [x0, #0x17]
    // 0xbf9560: DecompressPointer r1
    //     0xbf9560: add             x1, x1, HEAP, lsl #32
    // 0xbf9564: CheckStackOverflow
    //     0xbf9564: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf9568: cmp             SP, x16
    //     0xbf956c: b.ls            #0xbf9584
    // 0xbf9570: ldr             x2, [fp, #0x10]
    // 0xbf9574: r0 = _handleChanged()
    //     0xbf9574: bl              #0xbf966c  ; [package:flutter/src/material/slider.dart] _SliderState::_handleChanged
    // 0xbf9578: LeaveFrame
    //     0xbf9578: mov             SP, fp
    //     0xbf957c: ldp             fp, lr, [SP], #0x10
    // 0xbf9580: ret
    //     0xbf9580: ret             
    // 0xbf9584: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf9584: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf9588: b               #0xbf9570
  }
  [closure] void _handleDragStart(dynamic, double) {
    // ** addr: 0xbf958c, size: 0x3c
    // 0xbf958c: EnterFrame
    //     0xbf958c: stp             fp, lr, [SP, #-0x10]!
    //     0xbf9590: mov             fp, SP
    // 0xbf9594: ldr             x0, [fp, #0x18]
    // 0xbf9598: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbf9598: ldur            w1, [x0, #0x17]
    // 0xbf959c: DecompressPointer r1
    //     0xbf959c: add             x1, x1, HEAP, lsl #32
    // 0xbf95a0: CheckStackOverflow
    //     0xbf95a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf95a4: cmp             SP, x16
    //     0xbf95a8: b.ls            #0xbf95c0
    // 0xbf95ac: ldr             x2, [fp, #0x10]
    // 0xbf95b0: r0 = _handleDragStart()
    //     0xbf95b0: bl              #0xbf98d0  ; [package:flutter/src/material/slider.dart] _SliderState::_handleDragStart
    // 0xbf95b4: LeaveFrame
    //     0xbf95b4: mov             SP, fp
    //     0xbf95b8: ldp             fp, lr, [SP], #0x10
    // 0xbf95bc: ret
    //     0xbf95bc: ret             
    // 0xbf95c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf95c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf95c4: b               #0xbf95ac
  }
  _ _handleDragEnd(/* No info */) {
    // ** addr: 0xbf95c8, size: 0x80
    // 0xbf95c8: EnterFrame
    //     0xbf95c8: stp             fp, lr, [SP, #-0x10]!
    //     0xbf95cc: mov             fp, SP
    // 0xbf95d0: AllocStack(0x8)
    //     0xbf95d0: sub             SP, SP, #8
    // 0xbf95d4: SetupParameters(_SliderState this /* r1 => r1, fp-0x8 */)
    //     0xbf95d4: stur            x1, [fp, #-8]
    // 0xbf95d8: CheckStackOverflow
    //     0xbf95d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf95dc: cmp             SP, x16
    //     0xbf95e0: b.ls            #0xbf963c
    // 0xbf95e4: r1 = 1
    //     0xbf95e4: mov             x1, #1
    // 0xbf95e8: r0 = AllocateContext()
    //     0xbf95e8: bl              #0x13de838  ; AllocateContextStub
    // 0xbf95ec: mov             x1, x0
    // 0xbf95f0: ldur            x0, [fp, #-8]
    // 0xbf95f4: StoreField: r1->field_f = r0
    //     0xbf95f4: stur            w0, [x1, #0xf]
    // 0xbf95f8: mov             x2, x1
    // 0xbf95fc: r1 = Function '<anonymous closure>':.
    //     0xbf95fc: add             x1, PP, #0x98, lsl #12  ; [pp+0x98f48] AnonymousClosure: (0xbf9648), in [package:flutter/src/material/slider.dart] _SliderState::_handleDragEnd (0xbf95c8)
    //     0xbf9600: ldr             x1, [x1, #0xf48]
    // 0xbf9604: r0 = AllocateClosure()
    //     0xbf9604: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xbf9608: ldur            x1, [fp, #-8]
    // 0xbf960c: mov             x2, x0
    // 0xbf9610: r0 = setState()
    //     0xbf9610: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xbf9614: ldur            x1, [fp, #-8]
    // 0xbf9618: StoreField: r1->field_3f = rNULL
    //     0xbf9618: stur            NULL, [x1, #0x3f]
    // 0xbf961c: LoadField: r2 = r1->field_b
    //     0xbf961c: ldur            w2, [x1, #0xb]
    // 0xbf9620: DecompressPointer r2
    //     0xbf9620: add             x2, x2, HEAP, lsl #32
    // 0xbf9624: cmp             w2, NULL
    // 0xbf9628: b.eq            #0xbf9644
    // 0xbf962c: r0 = Null
    //     0xbf962c: mov             x0, NULL
    // 0xbf9630: LeaveFrame
    //     0xbf9630: mov             SP, fp
    //     0xbf9634: ldp             fp, lr, [SP], #0x10
    // 0xbf9638: ret
    //     0xbf9638: ret             
    // 0xbf963c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf963c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf9640: b               #0xbf95e4
    // 0xbf9644: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf9644: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xbf9648, size: 0x24
    // 0xbf9648: r1 = false
    //     0xbf9648: add             x1, NULL, #0x30  ; false
    // 0xbf964c: ldr             x2, [SP]
    // 0xbf9650: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xbf9650: ldur            w3, [x2, #0x17]
    // 0xbf9654: DecompressPointer r3
    //     0xbf9654: add             x3, x3, HEAP, lsl #32
    // 0xbf9658: LoadField: r2 = r3->field_f
    //     0xbf9658: ldur            w2, [x3, #0xf]
    // 0xbf965c: DecompressPointer r2
    //     0xbf965c: add             x2, x2, HEAP, lsl #32
    // 0xbf9660: StoreField: r2->field_3b = r1
    //     0xbf9660: stur            w1, [x2, #0x3b]
    // 0xbf9664: r0 = Null
    //     0xbf9664: mov             x0, NULL
    // 0xbf9668: ret
    //     0xbf9668: ret             
  }
  _ _handleChanged(/* No info */) {
    // ** addr: 0xbf966c, size: 0x1a0
    // 0xbf966c: EnterFrame
    //     0xbf966c: stp             fp, lr, [SP, #-0x10]!
    //     0xbf9670: mov             fp, SP
    // 0xbf9674: AllocStack(0x20)
    //     0xbf9674: sub             SP, SP, #0x20
    // 0xbf9678: SetupParameters(_SliderState this /* r1 => r0, fp-0x8 */)
    //     0xbf9678: mov             x0, x1
    //     0xbf967c: stur            x1, [fp, #-8]
    // 0xbf9680: CheckStackOverflow
    //     0xbf9680: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf9684: cmp             SP, x16
    //     0xbf9688: b.ls            #0xbf97c0
    // 0xbf968c: LoadField: d0 = r2->field_7
    //     0xbf968c: ldur            d0, [x2, #7]
    // 0xbf9690: mov             x1, x0
    // 0xbf9694: r0 = _lerp()
    //     0xbf9694: bl              #0xbf980c  ; [package:flutter/src/material/slider.dart] _SliderState::_lerp
    // 0xbf9698: ldur            x1, [fp, #-8]
    // 0xbf969c: LoadField: r0 = r1->field_3f
    //     0xbf969c: ldur            w0, [x1, #0x3f]
    // 0xbf96a0: DecompressPointer r0
    //     0xbf96a0: add             x0, x0, HEAP, lsl #32
    // 0xbf96a4: r2 = inline_Allocate_Double()
    //     0xbf96a4: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xbf96a8: add             x2, x2, #0x10
    //     0xbf96ac: cmp             x3, x2
    //     0xbf96b0: b.ls            #0xbf97c8
    //     0xbf96b4: str             x2, [THR, #0x60]  ; THR::top
    //     0xbf96b8: sub             x2, x2, #0xf
    //     0xbf96bc: mov             x3, #0xe19c
    //     0xbf96c0: movk            x3, #3, lsl #16
    //     0xbf96c4: stur            x3, [x2, #-1]
    // 0xbf96c8: dmb             ishst
    // 0xbf96cc: StoreField: r2->field_7 = d0
    //     0xbf96cc: stur            d0, [x2, #7]
    // 0xbf96d0: stur            x2, [fp, #-0x10]
    // 0xbf96d4: r3 = LoadClassIdInstr(r0)
    //     0xbf96d4: ldur            x3, [x0, #-1]
    //     0xbf96d8: ubfx            x3, x3, #0xc, #0x14
    // 0xbf96dc: stp             x2, x0, [SP]
    // 0xbf96e0: mov             x0, x3
    // 0xbf96e4: mov             lr, x0
    // 0xbf96e8: ldr             lr, [x21, lr, lsl #3]
    // 0xbf96ec: blr             lr
    // 0xbf96f0: tbz             w0, #4, #0xbf97b0
    // 0xbf96f4: ldur            x1, [fp, #-8]
    // 0xbf96f8: ldur            x0, [fp, #-0x10]
    // 0xbf96fc: StoreField: r1->field_3f = r0
    //     0xbf96fc: stur            w0, [x1, #0x3f]
    //     0xbf9700: ldurb           w16, [x1, #-1]
    //     0xbf9704: ldurb           w17, [x0, #-1]
    //     0xbf9708: and             x16, x17, x16, lsr #2
    //     0xbf970c: tst             x16, HEAP, lsr #32
    //     0xbf9710: b.eq            #0xbf9718
    //     0xbf9714: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbf9718: LoadField: r0 = r1->field_b
    //     0xbf9718: ldur            w0, [x1, #0xb]
    // 0xbf971c: DecompressPointer r0
    //     0xbf971c: add             x0, x0, HEAP, lsl #32
    // 0xbf9720: cmp             w0, NULL
    // 0xbf9724: b.eq            #0xbf97e4
    // 0xbf9728: LoadField: d0 = r0->field_b
    //     0xbf9728: ldur            d0, [x0, #0xb]
    // 0xbf972c: r0 = inline_Allocate_Double()
    //     0xbf972c: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xbf9730: add             x0, x0, #0x10
    //     0xbf9734: cmp             x2, x0
    //     0xbf9738: b.ls            #0xbf97e8
    //     0xbf973c: str             x0, [THR, #0x60]  ; THR::top
    //     0xbf9740: sub             x0, x0, #0xf
    //     0xbf9744: mov             x2, #0xe19c
    //     0xbf9748: movk            x2, #3, lsl #16
    //     0xbf974c: stur            x2, [x0, #-1]
    // 0xbf9750: dmb             ishst
    // 0xbf9754: StoreField: r0->field_7 = d0
    //     0xbf9754: stur            d0, [x0, #7]
    // 0xbf9758: ldur            x16, [fp, #-0x10]
    // 0xbf975c: stp             x0, x16, [SP]
    // 0xbf9760: r0 = ==()
    //     0xbf9760: bl              #0x12b7c00  ; [dart:core] _Double::==
    // 0xbf9764: tbz             w0, #4, #0xbf97b0
    // 0xbf9768: ldur            x0, [fp, #-8]
    // 0xbf976c: LoadField: r1 = r0->field_b
    //     0xbf976c: ldur            w1, [x0, #0xb]
    // 0xbf9770: DecompressPointer r1
    //     0xbf9770: add             x1, x1, HEAP, lsl #32
    // 0xbf9774: cmp             w1, NULL
    // 0xbf9778: b.eq            #0xbf9800
    // 0xbf977c: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xbf977c: ldur            w2, [x1, #0x17]
    // 0xbf9780: DecompressPointer r2
    //     0xbf9780: add             x2, x2, HEAP, lsl #32
    // 0xbf9784: LoadField: r1 = r0->field_3f
    //     0xbf9784: ldur            w1, [x0, #0x3f]
    // 0xbf9788: DecompressPointer r1
    //     0xbf9788: add             x1, x1, HEAP, lsl #32
    // 0xbf978c: cmp             w1, NULL
    // 0xbf9790: b.eq            #0xbf9804
    // 0xbf9794: cmp             w2, NULL
    // 0xbf9798: b.eq            #0xbf9808
    // 0xbf979c: stp             x1, x2, [SP]
    // 0xbf97a0: mov             x0, x2
    // 0xbf97a4: ClosureCall
    //     0xbf97a4: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xbf97a8: ldur            x2, [x0, #0x1f]
    //     0xbf97ac: blr             x2
    // 0xbf97b0: r0 = Null
    //     0xbf97b0: mov             x0, NULL
    // 0xbf97b4: LeaveFrame
    //     0xbf97b4: mov             SP, fp
    //     0xbf97b8: ldp             fp, lr, [SP], #0x10
    // 0xbf97bc: ret
    //     0xbf97bc: ret             
    // 0xbf97c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf97c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf97c4: b               #0xbf968c
    // 0xbf97c8: SaveReg d0
    //     0xbf97c8: str             q0, [SP, #-0x10]!
    // 0xbf97cc: stp             x0, x1, [SP, #-0x10]!
    // 0xbf97d0: r0 = AllocateDouble()
    //     0xbf97d0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbf97d4: mov             x2, x0
    // 0xbf97d8: ldp             x0, x1, [SP], #0x10
    // 0xbf97dc: RestoreReg d0
    //     0xbf97dc: ldr             q0, [SP], #0x10
    // 0xbf97e0: b               #0xbf96cc
    // 0xbf97e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf97e4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf97e8: SaveReg d0
    //     0xbf97e8: str             q0, [SP, #-0x10]!
    // 0xbf97ec: SaveReg r1
    //     0xbf97ec: str             x1, [SP, #-8]!
    // 0xbf97f0: r0 = AllocateDouble()
    //     0xbf97f0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbf97f4: RestoreReg r1
    //     0xbf97f4: ldr             x1, [SP], #8
    // 0xbf97f8: RestoreReg d0
    //     0xbf97f8: ldr             q0, [SP], #0x10
    // 0xbf97fc: b               #0xbf9754
    // 0xbf9800: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf9800: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf9804: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf9804: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf9808: r0 = NullErrorSharedWithoutFPURegs()
    //     0xbf9808: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ _lerp(/* No info */) {
    // ** addr: 0xbf980c, size: 0x34
    // 0xbf980c: d1 = 0.000000
    //     0xbf980c: eor             v1.16b, v1.16b, v1.16b
    // 0xbf9810: LoadField: r0 = r1->field_b
    //     0xbf9810: ldur            w0, [x1, #0xb]
    // 0xbf9814: DecompressPointer r0
    //     0xbf9814: add             x0, x0, HEAP, lsl #32
    // 0xbf9818: cmp             w0, NULL
    // 0xbf981c: b.eq            #0xbf9834
    // 0xbf9820: LoadField: d2 = r0->field_2b
    //     0xbf9820: ldur            d2, [x0, #0x2b]
    // 0xbf9824: fsub            d3, d2, d1
    // 0xbf9828: fmul            d2, d0, d3
    // 0xbf982c: fadd            d0, d2, d1
    // 0xbf9830: ret
    //     0xbf9830: ret             
    // 0xbf9834: EnterFrame
    //     0xbf9834: stp             fp, lr, [SP, #-0x10]!
    //     0xbf9838: mov             fp, SP
    // 0xbf983c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbf983c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  _ _handleDragStart(/* No info */) {
    // ** addr: 0xbf98d0, size: 0x7c
    // 0xbf98d0: EnterFrame
    //     0xbf98d0: stp             fp, lr, [SP, #-0x10]!
    //     0xbf98d4: mov             fp, SP
    // 0xbf98d8: AllocStack(0x8)
    //     0xbf98d8: sub             SP, SP, #8
    // 0xbf98dc: SetupParameters(_SliderState this /* r1 => r1, fp-0x8 */)
    //     0xbf98dc: stur            x1, [fp, #-8]
    // 0xbf98e0: CheckStackOverflow
    //     0xbf98e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf98e4: cmp             SP, x16
    //     0xbf98e8: b.ls            #0xbf9940
    // 0xbf98ec: r1 = 1
    //     0xbf98ec: mov             x1, #1
    // 0xbf98f0: r0 = AllocateContext()
    //     0xbf98f0: bl              #0x13de838  ; AllocateContextStub
    // 0xbf98f4: mov             x1, x0
    // 0xbf98f8: ldur            x0, [fp, #-8]
    // 0xbf98fc: StoreField: r1->field_f = r0
    //     0xbf98fc: stur            w0, [x1, #0xf]
    // 0xbf9900: mov             x2, x1
    // 0xbf9904: r1 = Function '<anonymous closure>':.
    //     0xbf9904: add             x1, PP, #0x98, lsl #12  ; [pp+0x98f50] AnonymousClosure: (0xbf994c), in [package:flutter/src/material/slider.dart] _SliderState::_handleDragStart (0xbf98d0)
    //     0xbf9908: ldr             x1, [x1, #0xf50]
    // 0xbf990c: r0 = AllocateClosure()
    //     0xbf990c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xbf9910: ldur            x1, [fp, #-8]
    // 0xbf9914: mov             x2, x0
    // 0xbf9918: r0 = setState()
    //     0xbf9918: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xbf991c: ldur            x1, [fp, #-8]
    // 0xbf9920: LoadField: r2 = r1->field_b
    //     0xbf9920: ldur            w2, [x1, #0xb]
    // 0xbf9924: DecompressPointer r2
    //     0xbf9924: add             x2, x2, HEAP, lsl #32
    // 0xbf9928: cmp             w2, NULL
    // 0xbf992c: b.eq            #0xbf9948
    // 0xbf9930: r0 = Null
    //     0xbf9930: mov             x0, NULL
    // 0xbf9934: LeaveFrame
    //     0xbf9934: mov             SP, fp
    //     0xbf9938: ldp             fp, lr, [SP], #0x10
    // 0xbf993c: ret
    //     0xbf993c: ret             
    // 0xbf9940: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf9940: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf9944: b               #0xbf98ec
    // 0xbf9948: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf9948: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xbf994c, size: 0x24
    // 0xbf994c: r1 = true
    //     0xbf994c: add             x1, NULL, #0x20  ; true
    // 0xbf9950: ldr             x2, [SP]
    // 0xbf9954: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xbf9954: ldur            w3, [x2, #0x17]
    // 0xbf9958: DecompressPointer r3
    //     0xbf9958: add             x3, x3, HEAP, lsl #32
    // 0xbf995c: LoadField: r2 = r3->field_f
    //     0xbf995c: ldur            w2, [x3, #0xf]
    // 0xbf9960: DecompressPointer r2
    //     0xbf9960: add             x2, x2, HEAP, lsl #32
    // 0xbf9964: StoreField: r2->field_3b = r1
    //     0xbf9964: stur            w1, [x2, #0x3b]
    // 0xbf9968: r0 = Null
    //     0xbf9968: mov             x0, NULL
    // 0xbf996c: ret
    //     0xbf996c: ret             
  }
  _ build(/* No info */) {
    // ** addr: 0xd3b7f0, size: 0xcc
    // 0xd3b7f0: EnterFrame
    //     0xd3b7f0: stp             fp, lr, [SP, #-0x10]!
    //     0xd3b7f4: mov             fp, SP
    // 0xd3b7f8: AllocStack(0x10)
    //     0xd3b7f8: sub             SP, SP, #0x10
    // 0xd3b7fc: SetupParameters(_SliderState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xd3b7fc: mov             x0, x1
    //     0xd3b800: stur            x1, [fp, #-8]
    //     0xd3b804: stur            x2, [fp, #-0x10]
    // 0xd3b808: CheckStackOverflow
    //     0xd3b808: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd3b80c: cmp             SP, x16
    //     0xd3b810: b.ls            #0xd3b8b0
    // 0xd3b814: LoadField: r1 = r0->field_b
    //     0xd3b814: ldur            w1, [x0, #0xb]
    // 0xd3b818: DecompressPointer r1
    //     0xd3b818: add             x1, x1, HEAP, lsl #32
    // 0xd3b81c: cmp             w1, NULL
    // 0xd3b820: b.eq            #0xd3b8b8
    // 0xd3b824: LoadField: r3 = r1->field_73
    //     0xd3b824: ldur            w3, [x1, #0x73]
    // 0xd3b828: DecompressPointer r3
    //     0xd3b828: add             x3, x3, HEAP, lsl #32
    // 0xd3b82c: LoadField: r1 = r3->field_7
    //     0xd3b82c: ldur            x1, [x3, #7]
    // 0xd3b830: cmp             x1, #0
    // 0xd3b834: b.gt            #0xd3b84c
    // 0xd3b838: mov             x1, x0
    // 0xd3b83c: r0 = _buildMaterialSlider()
    //     0xd3b83c: bl              #0xd3b97c  ; [package:flutter/src/material/slider.dart] _SliderState::_buildMaterialSlider
    // 0xd3b840: LeaveFrame
    //     0xd3b840: mov             SP, fp
    //     0xd3b844: ldp             fp, lr, [SP], #0x10
    // 0xd3b848: ret
    //     0xd3b848: ret             
    // 0xd3b84c: mov             x1, x2
    // 0xd3b850: r0 = of()
    //     0xd3b850: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd3b854: LoadField: r1 = r0->field_23
    //     0xd3b854: ldur            w1, [x0, #0x23]
    // 0xd3b858: DecompressPointer r1
    //     0xd3b858: add             x1, x1, HEAP, lsl #32
    // 0xd3b85c: LoadField: r0 = r1->field_7
    //     0xd3b85c: ldur            x0, [x1, #7]
    // 0xd3b860: cmp             x0, #2
    // 0xd3b864: b.gt            #0xd3b874
    // 0xd3b868: cmp             x0, #1
    // 0xd3b86c: b.gt            #0xd3b884
    // 0xd3b870: b               #0xd3b898
    // 0xd3b874: cmp             x0, #4
    // 0xd3b878: b.gt            #0xd3b898
    // 0xd3b87c: cmp             x0, #3
    // 0xd3b880: b.le            #0xd3b898
    // 0xd3b884: ldur            x1, [fp, #-8]
    // 0xd3b888: r0 = _buildCupertinoSlider()
    //     0xd3b888: bl              #0xd3b8bc  ; [package:flutter/src/material/slider.dart] _SliderState::_buildCupertinoSlider
    // 0xd3b88c: LeaveFrame
    //     0xd3b88c: mov             SP, fp
    //     0xd3b890: ldp             fp, lr, [SP], #0x10
    // 0xd3b894: ret
    //     0xd3b894: ret             
    // 0xd3b898: ldur            x1, [fp, #-8]
    // 0xd3b89c: ldur            x2, [fp, #-0x10]
    // 0xd3b8a0: r0 = _buildMaterialSlider()
    //     0xd3b8a0: bl              #0xd3b97c  ; [package:flutter/src/material/slider.dart] _SliderState::_buildMaterialSlider
    // 0xd3b8a4: LeaveFrame
    //     0xd3b8a4: mov             SP, fp
    //     0xd3b8a8: ldp             fp, lr, [SP], #0x10
    // 0xd3b8ac: ret
    //     0xd3b8ac: ret             
    // 0xd3b8b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd3b8b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd3b8b4: b               #0xd3b814
    // 0xd3b8b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd3b8b8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _buildCupertinoSlider(/* No info */) {
    // ** addr: 0xd3b8bc, size: 0xb4
    // 0xd3b8bc: EnterFrame
    //     0xd3b8bc: stp             fp, lr, [SP, #-0x10]!
    //     0xd3b8c0: mov             fp, SP
    // 0xd3b8c4: AllocStack(0x30)
    //     0xd3b8c4: sub             SP, SP, #0x30
    // 0xd3b8c8: LoadField: r0 = r1->field_b
    //     0xd3b8c8: ldur            w0, [x1, #0xb]
    // 0xd3b8cc: DecompressPointer r0
    //     0xd3b8cc: add             x0, x0, HEAP, lsl #32
    // 0xd3b8d0: cmp             w0, NULL
    // 0xd3b8d4: b.eq            #0xd3b96c
    // 0xd3b8d8: LoadField: d0 = r0->field_b
    //     0xd3b8d8: ldur            d0, [x0, #0xb]
    // 0xd3b8dc: stur            d0, [fp, #-0x30]
    // 0xd3b8e0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd3b8e0: ldur            w1, [x0, #0x17]
    // 0xd3b8e4: DecompressPointer r1
    //     0xd3b8e4: add             x1, x1, HEAP, lsl #32
    // 0xd3b8e8: stur            x1, [fp, #-0x18]
    // 0xd3b8ec: LoadField: d1 = r0->field_2b
    //     0xd3b8ec: ldur            d1, [x0, #0x2b]
    // 0xd3b8f0: stur            d1, [fp, #-0x28]
    // 0xd3b8f4: LoadField: r2 = r0->field_33
    //     0xd3b8f4: ldur            x2, [x0, #0x33]
    // 0xd3b8f8: stur            x2, [fp, #-0x10]
    // 0xd3b8fc: LoadField: r3 = r0->field_3f
    //     0xd3b8fc: ldur            w3, [x0, #0x3f]
    // 0xd3b900: DecompressPointer r3
    //     0xd3b900: add             x3, x3, HEAP, lsl #32
    // 0xd3b904: stur            x3, [fp, #-8]
    // 0xd3b908: r0 = CupertinoSlider()
    //     0xd3b908: bl              #0xd3b970  ; AllocateCupertinoSliderStub -> CupertinoSlider (size=0x40)
    // 0xd3b90c: ldur            d0, [fp, #-0x30]
    // 0xd3b910: stur            x0, [fp, #-0x20]
    // 0xd3b914: StoreField: r0->field_b = d0
    //     0xd3b914: stur            d0, [x0, #0xb]
    // 0xd3b918: ldur            x1, [fp, #-0x18]
    // 0xd3b91c: StoreField: r0->field_13 = r1
    //     0xd3b91c: stur            w1, [x0, #0x13]
    // 0xd3b920: StoreField: r0->field_1f = rZR
    //     0xd3b920: stur            xzr, [x0, #0x1f]
    // 0xd3b924: ldur            d0, [fp, #-0x28]
    // 0xd3b928: StoreField: r0->field_27 = d0
    //     0xd3b928: stur            d0, [x0, #0x27]
    // 0xd3b92c: ldur            x1, [fp, #-0x10]
    // 0xd3b930: StoreField: r0->field_2f = r1
    //     0xd3b930: stur            x1, [x0, #0x2f]
    // 0xd3b934: ldur            x1, [fp, #-8]
    // 0xd3b938: StoreField: r0->field_37 = r1
    //     0xd3b938: stur            w1, [x0, #0x37]
    // 0xd3b93c: r1 = Instance_Color
    //     0xd3b93c: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0xd3b940: ldr             x1, [x1, #0xc38]
    // 0xd3b944: StoreField: r0->field_3b = r1
    //     0xd3b944: stur            w1, [x0, #0x3b]
    // 0xd3b948: r0 = SizedBox()
    //     0xd3b948: bl              #0x8a7210  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0xd3b94c: r1 = inf
    //     0xd3b94c: add             x1, PP, #0x15, lsl #12  ; [pp+0x158a8] inf
    //     0xd3b950: ldr             x1, [x1, #0x8a8]
    // 0xd3b954: StoreField: r0->field_f = r1
    //     0xd3b954: stur            w1, [x0, #0xf]
    // 0xd3b958: ldur            x1, [fp, #-0x20]
    // 0xd3b95c: StoreField: r0->field_b = r1
    //     0xd3b95c: stur            w1, [x0, #0xb]
    // 0xd3b960: LeaveFrame
    //     0xd3b960: mov             SP, fp
    //     0xd3b964: ldp             fp, lr, [SP], #0x10
    // 0xd3b968: ret
    //     0xd3b968: ret             
    // 0xd3b96c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd3b96c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _buildMaterialSlider(/* No info */) {
    // ** addr: 0xd3b97c, size: 0x1bc0
    // 0xd3b97c: EnterFrame
    //     0xd3b97c: stp             fp, lr, [SP, #-0x10]!
    //     0xd3b980: mov             fp, SP
    // 0xd3b984: AllocStack(0x180)
    //     0xd3b984: sub             SP, SP, #0x180
    // 0xd3b988: SetupParameters(_SliderState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xd3b988: mov             x0, x1
    //     0xd3b98c: stur            x1, [fp, #-8]
    //     0xd3b990: mov             x1, x2
    //     0xd3b994: stur            x2, [fp, #-0x10]
    // 0xd3b998: CheckStackOverflow
    //     0xd3b998: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd3b99c: cmp             SP, x16
    //     0xd3b9a0: b.ls            #0xd3d4ac
    // 0xd3b9a4: r1 = 5
    //     0xd3b9a4: mov             x1, #5
    // 0xd3b9a8: r0 = AllocateContext()
    //     0xd3b9a8: bl              #0x13de838  ; AllocateContextStub
    // 0xd3b9ac: mov             x2, x0
    // 0xd3b9b0: ldur            x0, [fp, #-8]
    // 0xd3b9b4: stur            x2, [fp, #-0x18]
    // 0xd3b9b8: StoreField: r2->field_f = r0
    //     0xd3b9b8: stur            w0, [x2, #0xf]
    // 0xd3b9bc: ldur            x1, [fp, #-0x10]
    // 0xd3b9c0: StoreField: r2->field_13 = r1
    //     0xd3b9c0: stur            w1, [x2, #0x13]
    // 0xd3b9c4: r0 = of()
    //     0xd3b9c4: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd3b9c8: ldur            x2, [fp, #-0x18]
    // 0xd3b9cc: stur            x0, [fp, #-0x10]
    // 0xd3b9d0: LoadField: r1 = r2->field_13
    //     0xd3b9d0: ldur            w1, [x2, #0x13]
    // 0xd3b9d4: DecompressPointer r1
    //     0xd3b9d4: add             x1, x1, HEAP, lsl #32
    // 0xd3b9d8: r0 = of()
    //     0xd3b9d8: bl              #0xd3d7b8  ; [package:flutter/src/material/slider_theme.dart] SliderTheme::of
    // 0xd3b9dc: ldur            x2, [fp, #-0x18]
    // 0xd3b9e0: ArrayStore: r2[0] = r0  ; List_4
    //     0xd3b9e0: stur            w0, [x2, #0x17]
    //     0xd3b9e4: ldurb           w16, [x2, #-1]
    //     0xd3b9e8: ldurb           w17, [x0, #-1]
    //     0xd3b9ec: and             x16, x17, x16, lsr #2
    //     0xd3b9f0: tst             x16, HEAP, lsr #32
    //     0xd3b9f4: b.eq            #0xd3b9fc
    //     0xd3b9f8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd3b9fc: ldur            x1, [fp, #-8]
    // 0xd3ba00: LoadField: r0 = r1->field_b
    //     0xd3ba00: ldur            w0, [x1, #0xb]
    // 0xd3ba04: DecompressPointer r0
    //     0xd3ba04: add             x0, x0, HEAP, lsl #32
    // 0xd3ba08: cmp             w0, NULL
    // 0xd3ba0c: b.eq            #0xd3d4b4
    // 0xd3ba10: ldur            x0, [fp, #-0x10]
    // 0xd3ba14: LoadField: r3 = r0->field_2f
    //     0xd3ba14: ldur            w3, [x0, #0x2f]
    // 0xd3ba18: DecompressPointer r3
    //     0xd3ba18: add             x3, x3, HEAP, lsl #32
    // 0xd3ba1c: stur            x3, [fp, #-0x28]
    // 0xd3ba20: tbnz            w3, #4, #0xd3ba5c
    // 0xd3ba24: LoadField: r4 = r2->field_13
    //     0xd3ba24: ldur            w4, [x2, #0x13]
    // 0xd3ba28: DecompressPointer r4
    //     0xd3ba28: add             x4, x4, HEAP, lsl #32
    // 0xd3ba2c: stur            x4, [fp, #-0x20]
    // 0xd3ba30: r0 = _SliderDefaultsM3Year2023()
    //     0xd3ba30: bl              #0xd3d7ac  ; Allocate_SliderDefaultsM3Year2023Stub -> _SliderDefaultsM3Year2023 (size=0xa0)
    // 0xd3ba34: mov             x1, x0
    // 0xd3ba38: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3ba3c: StoreField: r1->field_9b = r0
    //     0xd3ba3c: stur            w0, [x1, #0x9b]
    // 0xd3ba40: ldur            x0, [fp, #-0x20]
    // 0xd3ba44: StoreField: r1->field_97 = r0
    //     0xd3ba44: stur            w0, [x1, #0x97]
    // 0xd3ba48: r2 = 4.000000
    //     0xd3ba48: add             x2, PP, #0x19, lsl #12  ; [pp+0x19e28] 4
    //     0xd3ba4c: ldr             x2, [x2, #0xe28]
    // 0xd3ba50: StoreField: r1->field_7 = r2
    //     0xd3ba50: stur            w2, [x1, #7]
    // 0xd3ba54: mov             x4, x1
    // 0xd3ba58: b               #0xd3baa4
    // 0xd3ba5c: mov             x1, x2
    // 0xd3ba60: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3ba64: r2 = 4.000000
    //     0xd3ba64: add             x2, PP, #0x19, lsl #12  ; [pp+0x19e28] 4
    //     0xd3ba68: ldr             x2, [x2, #0xe28]
    // 0xd3ba6c: LoadField: r3 = r1->field_13
    //     0xd3ba6c: ldur            w3, [x1, #0x13]
    // 0xd3ba70: DecompressPointer r3
    //     0xd3ba70: add             x3, x3, HEAP, lsl #32
    // 0xd3ba74: stur            x3, [fp, #-0x20]
    // 0xd3ba78: r0 = _SliderDefaultsM2()
    //     0xd3ba78: bl              #0xd3d7a0  ; Allocate_SliderDefaultsM2Stub -> _SliderDefaultsM2 (size=0xa4)
    // 0xd3ba7c: mov             x1, x0
    // 0xd3ba80: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3ba84: StoreField: r1->field_9b = r0
    //     0xd3ba84: stur            w0, [x1, #0x9b]
    // 0xd3ba88: StoreField: r1->field_9f = r0
    //     0xd3ba88: stur            w0, [x1, #0x9f]
    // 0xd3ba8c: ldur            x0, [fp, #-0x20]
    // 0xd3ba90: StoreField: r1->field_97 = r0
    //     0xd3ba90: stur            w0, [x1, #0x97]
    // 0xd3ba94: r0 = 4.000000
    //     0xd3ba94: add             x0, PP, #0x19, lsl #12  ; [pp+0x19e28] 4
    //     0xd3ba98: ldr             x0, [x0, #0xe28]
    // 0xd3ba9c: StoreField: r1->field_7 = r0
    //     0xd3ba9c: stur            w0, [x1, #7]
    // 0xd3baa0: mov             x4, x1
    // 0xd3baa4: ldur            x3, [fp, #-8]
    // 0xd3baa8: ldur            x2, [fp, #-0x18]
    // 0xd3baac: mov             x0, x4
    // 0xd3bab0: stur            x4, [fp, #-0x20]
    // 0xd3bab4: StoreField: r2->field_1b = r0
    //     0xd3bab4: stur            w0, [x2, #0x1b]
    //     0xd3bab8: ldurb           w16, [x2, #-1]
    //     0xd3babc: ldurb           w17, [x0, #-1]
    //     0xd3bac0: and             x16, x17, x16, lsr #2
    //     0xd3bac4: tst             x16, HEAP, lsr #32
    //     0xd3bac8: b.eq            #0xd3bad0
    //     0xd3bacc: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd3bad0: r1 = <WidgetState>
    //     0xd3bad0: add             x1, PP, #0x84, lsl #12  ; [pp+0x84a10] TypeArguments: <WidgetState>
    //     0xd3bad4: ldr             x1, [x1, #0xa10]
    // 0xd3bad8: r0 = _Set()
    //     0xd3bad8: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0xd3badc: mov             x3, x0
    // 0xd3bae0: r0 = _Uint32List
    //     0xd3bae0: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0xd3bae4: stur            x3, [fp, #-0x30]
    // 0xd3bae8: StoreField: r3->field_1b = r0
    //     0xd3bae8: stur            w0, [x3, #0x1b]
    // 0xd3baec: StoreField: r3->field_b = rZR
    //     0xd3baec: stur            wzr, [x3, #0xb]
    // 0xd3baf0: r0 = const []
    //     0xd3baf0: ldr             x0, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0xd3baf4: StoreField: r3->field_f = r0
    //     0xd3baf4: stur            w0, [x3, #0xf]
    // 0xd3baf8: StoreField: r3->field_13 = rZR
    //     0xd3baf8: stur            wzr, [x3, #0x13]
    // 0xd3bafc: ArrayStore: r3[0] = rZR  ; List_4
    //     0xd3bafc: stur            wzr, [x3, #0x17]
    // 0xd3bb00: ldur            x0, [fp, #-8]
    // 0xd3bb04: LoadField: r1 = r0->field_4f
    //     0xd3bb04: ldur            w1, [x0, #0x4f]
    // 0xd3bb08: DecompressPointer r1
    //     0xd3bb08: add             x1, x1, HEAP, lsl #32
    // 0xd3bb0c: tbnz            w1, #4, #0xd3bb20
    // 0xd3bb10: mov             x1, x3
    // 0xd3bb14: r2 = Instance_WidgetState
    //     0xd3bb14: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a50] Obj!WidgetState@12c8721
    //     0xd3bb18: ldr             x2, [x2, #0xa50]
    // 0xd3bb1c: r0 = add()
    //     0xd3bb1c: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xd3bb20: ldur            x0, [fp, #-8]
    // 0xd3bb24: LoadField: r1 = r0->field_4b
    //     0xd3bb24: ldur            w1, [x0, #0x4b]
    // 0xd3bb28: DecompressPointer r1
    //     0xd3bb28: add             x1, x1, HEAP, lsl #32
    // 0xd3bb2c: tbnz            w1, #4, #0xd3bb40
    // 0xd3bb30: ldur            x1, [fp, #-0x30]
    // 0xd3bb34: r2 = Instance_WidgetState
    //     0xd3bb34: add             x2, PP, #0x15, lsl #12  ; [pp+0x15a60] Obj!WidgetState@12c8761
    //     0xd3bb38: ldr             x2, [x2, #0xa60]
    // 0xd3bb3c: r0 = add()
    //     0xd3bb3c: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xd3bb40: ldur            x0, [fp, #-8]
    // 0xd3bb44: LoadField: r1 = r0->field_3b
    //     0xd3bb44: ldur            w1, [x0, #0x3b]
    // 0xd3bb48: DecompressPointer r1
    //     0xd3bb48: add             x1, x1, HEAP, lsl #32
    // 0xd3bb4c: tbnz            w1, #4, #0xd3bb60
    // 0xd3bb50: ldur            x1, [fp, #-0x30]
    // 0xd3bb54: r2 = Instance_WidgetState
    //     0xd3bb54: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ad0] Obj!WidgetState@12c87a1
    //     0xd3bb58: ldr             x2, [x2, #0xad0]
    // 0xd3bb5c: r0 = add()
    //     0xd3bb5c: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xd3bb60: ldur            x2, [fp, #-0x18]
    // 0xd3bb64: ldur            x0, [fp, #-0x30]
    // 0xd3bb68: StoreField: r2->field_1f = r0
    //     0xd3bb68: stur            w0, [x2, #0x1f]
    //     0xd3bb6c: ldurb           w16, [x2, #-1]
    //     0xd3bb70: ldurb           w17, [x0, #-1]
    //     0xd3bb74: and             x16, x17, x16, lsr #2
    //     0xd3bb78: tst             x16, HEAP, lsr #32
    //     0xd3bb7c: b.eq            #0xd3bb84
    //     0xd3bb80: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd3bb84: ArrayLoad: r0 = r2[0]  ; List_4
    //     0xd3bb84: ldur            w0, [x2, #0x17]
    // 0xd3bb88: DecompressPointer r0
    //     0xd3bb88: add             x0, x0, HEAP, lsl #32
    // 0xd3bb8c: LoadField: r1 = r0->field_5b
    //     0xd3bb8c: ldur            w1, [x0, #0x5b]
    // 0xd3bb90: DecompressPointer r1
    //     0xd3bb90: add             x1, x1, HEAP, lsl #32
    // 0xd3bb94: cmp             w1, NULL
    // 0xd3bb98: b.ne            #0xd3bc00
    // 0xd3bb9c: ldur            x3, [fp, #-0x20]
    // 0xd3bba0: r1 = LoadClassIdInstr(r3)
    //     0xd3bba0: ldur            x1, [x3, #-1]
    //     0xd3bba4: ubfx            x1, x1, #0xc, #0x14
    // 0xd3bba8: r17 = 5069
    //     0xd3bba8: mov             x17, #0x13cd
    // 0xd3bbac: cmp             x1, x17
    // 0xd3bbb0: b.ne            #0xd3bbc0
    // 0xd3bbb4: LoadField: r1 = r3->field_5b
    //     0xd3bbb4: ldur            w1, [x3, #0x5b]
    // 0xd3bbb8: DecompressPointer r1
    //     0xd3bbb8: add             x1, x1, HEAP, lsl #32
    // 0xd3bbbc: b               #0xd3bbf8
    // 0xd3bbc0: r17 = 5070
    //     0xd3bbc0: mov             x17, #0x13ce
    // 0xd3bbc4: cmp             x1, x17
    // 0xd3bbc8: b.ne            #0xd3bbd8
    // 0xd3bbcc: r1 = Instance_RoundedRectSliderValueIndicatorShape
    //     0xd3bbcc: add             x1, PP, #0x26, lsl #12  ; [pp+0x26a88] Obj!RoundedRectSliderValueIndicatorShape@129e8b1
    //     0xd3bbd0: ldr             x1, [x1, #0xa88]
    // 0xd3bbd4: b               #0xd3bbf8
    // 0xd3bbd8: r17 = 5071
    //     0xd3bbd8: mov             x17, #0x13cf
    // 0xd3bbdc: cmp             x1, x17
    // 0xd3bbe0: b.ne            #0xd3bbf0
    // 0xd3bbe4: r1 = Instance_DropSliderValueIndicatorShape
    //     0xd3bbe4: add             x1, PP, #0x26, lsl #12  ; [pp+0x26a90] Obj!DropSliderValueIndicatorShape@129e8d1
    //     0xd3bbe8: ldr             x1, [x1, #0xa90]
    // 0xd3bbec: b               #0xd3bbf8
    // 0xd3bbf0: r1 = Instance_RectangularSliderValueIndicatorShape
    //     0xd3bbf0: add             x1, PP, #0x26, lsl #12  ; [pp+0x26a98] Obj!RectangularSliderValueIndicatorShape@129e891
    //     0xd3bbf4: ldr             x1, [x1, #0xa98]
    // 0xd3bbf8: mov             x4, x1
    // 0xd3bbfc: b               #0xd3bc08
    // 0xd3bc00: ldur            x3, [fp, #-0x20]
    // 0xd3bc04: mov             x4, x1
    // 0xd3bc08: stur            x4, [fp, #-0x40]
    // 0xd3bc0c: r1 = LoadClassIdInstr(r4)
    //     0xd3bc0c: ldur            x1, [x4, #-1]
    //     0xd3bc10: ubfx            x1, x1, #0xc, #0x14
    // 0xd3bc14: cmp             x1, #0xba1
    // 0xd3bc18: b.ne            #0xd3bcac
    // 0xd3bc1c: LoadField: r1 = r0->field_43
    //     0xd3bc1c: ldur            w1, [x0, #0x43]
    // 0xd3bc20: DecompressPointer r1
    //     0xd3bc20: add             x1, x1, HEAP, lsl #32
    // 0xd3bc24: cmp             w1, NULL
    // 0xd3bc28: b.ne            #0xd3bca0
    // 0xd3bc2c: ldur            x5, [fp, #-0x10]
    // 0xd3bc30: LoadField: r6 = r5->field_3f
    //     0xd3bc30: ldur            w6, [x5, #0x3f]
    // 0xd3bc34: DecompressPointer r6
    //     0xd3bc34: add             x6, x6, HEAP, lsl #32
    // 0xd3bc38: stur            x6, [fp, #-0x38]
    // 0xd3bc3c: LoadField: r1 = r6->field_7f
    //     0xd3bc3c: ldur            w1, [x6, #0x7f]
    // 0xd3bc40: DecompressPointer r1
    //     0xd3bc40: add             x1, x1, HEAP, lsl #32
    // 0xd3bc44: r0 = LoadClassIdInstr(r1)
    //     0xd3bc44: ldur            x0, [x1, #-1]
    //     0xd3bc48: ubfx            x0, x0, #0xc, #0x14
    // 0xd3bc4c: d0 = 0.600000
    //     0xd3bc4c: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c88] IMM: double(0.6) from 0x3fe3333333333333
    //     0xd3bc50: ldr             d0, [x17, #0xc88]
    // 0xd3bc54: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd3bc54: sub             lr, x0, #1, lsl #12
    //     0xd3bc58: ldr             lr, [x21, lr, lsl #3]
    //     0xd3bc5c: blr             lr
    // 0xd3bc60: mov             x2, x0
    // 0xd3bc64: ldur            x0, [fp, #-0x38]
    // 0xd3bc68: stur            x2, [fp, #-0x48]
    // 0xd3bc6c: LoadField: r1 = r0->field_7b
    //     0xd3bc6c: ldur            w1, [x0, #0x7b]
    // 0xd3bc70: DecompressPointer r1
    //     0xd3bc70: add             x1, x1, HEAP, lsl #32
    // 0xd3bc74: r0 = LoadClassIdInstr(r1)
    //     0xd3bc74: ldur            x0, [x1, #-1]
    //     0xd3bc78: ubfx            x0, x0, #0xc, #0x14
    // 0xd3bc7c: d0 = 0.900000
    //     0xd3bc7c: add             x17, PP, #0x12, lsl #12  ; [pp+0x12818] IMM: double(0.9) from 0x3feccccccccccccd
    //     0xd3bc80: ldr             d0, [x17, #0x818]
    // 0xd3bc84: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd3bc84: sub             lr, x0, #1, lsl #12
    //     0xd3bc88: ldr             lr, [x21, lr, lsl #3]
    //     0xd3bc8c: blr             lr
    // 0xd3bc90: ldur            x1, [fp, #-0x48]
    // 0xd3bc94: mov             x2, x0
    // 0xd3bc98: r0 = alphaBlend()
    //     0xd3bc98: bl              #0xb6ea90  ; [dart:ui] Color::alphaBlend
    // 0xd3bc9c: b               #0xd3bca4
    // 0xd3bca0: mov             x0, x1
    // 0xd3bca4: mov             x3, x0
    // 0xd3bca8: b               #0xd3bdb8
    // 0xd3bcac: ldur            x2, [fp, #-8]
    // 0xd3bcb0: LoadField: r1 = r2->field_b
    //     0xd3bcb0: ldur            w1, [x2, #0xb]
    // 0xd3bcb4: DecompressPointer r1
    //     0xd3bcb4: add             x1, x1, HEAP, lsl #32
    // 0xd3bcb8: cmp             w1, NULL
    // 0xd3bcbc: b.eq            #0xd3d4b8
    // 0xd3bcc0: LoadField: r3 = r1->field_3f
    //     0xd3bcc0: ldur            w3, [x1, #0x3f]
    // 0xd3bcc4: DecompressPointer r3
    //     0xd3bcc4: add             x3, x3, HEAP, lsl #32
    // 0xd3bcc8: cmp             w3, NULL
    // 0xd3bccc: b.ne            #0xd3bce0
    // 0xd3bcd0: LoadField: r1 = r0->field_43
    //     0xd3bcd0: ldur            w1, [x0, #0x43]
    // 0xd3bcd4: DecompressPointer r1
    //     0xd3bcd4: add             x1, x1, HEAP, lsl #32
    // 0xd3bcd8: mov             x0, x1
    // 0xd3bcdc: b               #0xd3bce4
    // 0xd3bce0: mov             x0, x3
    // 0xd3bce4: cmp             w0, NULL
    // 0xd3bce8: b.ne            #0xd3bdb4
    // 0xd3bcec: ldur            x0, [fp, #-0x20]
    // 0xd3bcf0: r1 = LoadClassIdInstr(r0)
    //     0xd3bcf0: ldur            x1, [x0, #-1]
    //     0xd3bcf4: ubfx            x1, x1, #0xc, #0x14
    // 0xd3bcf8: r17 = 5069
    //     0xd3bcf8: mov             x17, #0x13cd
    // 0xd3bcfc: cmp             x1, x17
    // 0xd3bd00: b.ne            #0xd3bd14
    // 0xd3bd04: LoadField: r1 = r0->field_43
    //     0xd3bd04: ldur            w1, [x0, #0x43]
    // 0xd3bd08: DecompressPointer r1
    //     0xd3bd08: add             x1, x1, HEAP, lsl #32
    // 0xd3bd0c: mov             x0, x1
    // 0xd3bd10: b               #0xd3bdb4
    // 0xd3bd14: r17 = 5070
    //     0xd3bd14: mov             x17, #0x13ce
    // 0xd3bd18: cmp             x1, x17
    // 0xd3bd1c: b.eq            #0xd3d1fc
    // 0xd3bd20: r17 = 5071
    //     0xd3bd20: mov             x17, #0x13cf
    // 0xd3bd24: cmp             x1, x17
    // 0xd3bd28: b.ne            #0xd3bd60
    // 0xd3bd2c: mov             x1, x0
    // 0xd3bd30: LoadField: r0 = r1->field_9b
    //     0xd3bd30: ldur            w0, [x1, #0x9b]
    // 0xd3bd34: DecompressPointer r0
    //     0xd3bd34: add             x0, x0, HEAP, lsl #32
    // 0xd3bd38: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3bd3c: cmp             w0, w16
    // 0xd3bd40: b.ne            #0xd3bd50
    // 0xd3bd44: r2 = _colors
    //     0xd3bd44: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0xd3bd48: ldr             x2, [x2, #0xa10]
    // 0xd3bd4c: r0 = InitLateFinalInstanceField()
    //     0xd3bd4c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3bd50: LoadField: r1 = r0->field_b
    //     0xd3bd50: ldur            w1, [x0, #0xb]
    // 0xd3bd54: DecompressPointer r1
    //     0xd3bd54: add             x1, x1, HEAP, lsl #32
    // 0xd3bd58: mov             x0, x1
    // 0xd3bd5c: b               #0xd3bdb4
    // 0xd3bd60: ldur            x1, [fp, #-0x20]
    // 0xd3bd64: LoadField: r0 = r1->field_9f
    //     0xd3bd64: ldur            w0, [x1, #0x9f]
    // 0xd3bd68: DecompressPointer r0
    //     0xd3bd68: add             x0, x0, HEAP, lsl #32
    // 0xd3bd6c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3bd70: cmp             w0, w16
    // 0xd3bd74: b.ne            #0xd3bd84
    // 0xd3bd78: r2 = sliderTheme
    //     0xd3bd78: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a48] Field <_SliderDefaultsM2@125231897.sliderTheme>: late final (offset: 0xa0)
    //     0xd3bd7c: ldr             x2, [x2, #0xa48]
    // 0xd3bd80: r0 = InitLateFinalInstanceField()
    //     0xd3bd80: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3bd84: ldur            x1, [fp, #-0x20]
    // 0xd3bd88: LoadField: r0 = r1->field_9b
    //     0xd3bd88: ldur            w0, [x1, #0x9b]
    // 0xd3bd8c: DecompressPointer r0
    //     0xd3bd8c: add             x0, x0, HEAP, lsl #32
    // 0xd3bd90: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3bd94: cmp             w0, w16
    // 0xd3bd98: b.ne            #0xd3bda8
    // 0xd3bd9c: r2 = _colors
    //     0xd3bd9c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0xd3bda0: ldr             x2, [x2, #0xa18]
    // 0xd3bda4: r0 = InitLateFinalInstanceField()
    //     0xd3bda4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3bda8: LoadField: r1 = r0->field_b
    //     0xd3bda8: ldur            w1, [x0, #0xb]
    // 0xd3bdac: DecompressPointer r1
    //     0xd3bdac: add             x1, x1, HEAP, lsl #32
    // 0xd3bdb0: mov             x0, x1
    // 0xd3bdb4: mov             x3, x0
    // 0xd3bdb8: ldur            x0, [fp, #-0x18]
    // 0xd3bdbc: mov             x2, x0
    // 0xd3bdc0: stur            x3, [fp, #-0x38]
    // 0xd3bdc4: r1 = Function 'effectiveOverlayColor':.
    //     0xd3bdc4: add             x1, PP, #0x98, lsl #12  ; [pp+0x98ec0] AnonymousClosure: (0xd3dbd0), in [package:flutter/src/material/slider.dart] _SliderState::_buildMaterialSlider (0xd3b97c)
    //     0xd3bdc8: ldr             x1, [x1, #0xec0]
    // 0xd3bdcc: r0 = AllocateClosure()
    //     0xd3bdcc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3bdd0: ldur            x2, [fp, #-0x18]
    // 0xd3bdd4: stur            x0, [fp, #-0x48]
    // 0xd3bdd8: ArrayLoad: r1 = r2[0]  ; List_4
    //     0xd3bdd8: ldur            w1, [x2, #0x17]
    // 0xd3bddc: DecompressPointer r1
    //     0xd3bddc: add             x1, x1, HEAP, lsl #32
    // 0xd3bde0: LoadField: r3 = r1->field_73
    //     0xd3bde0: ldur            w3, [x1, #0x73]
    // 0xd3bde4: DecompressPointer r3
    //     0xd3bde4: add             x3, x3, HEAP, lsl #32
    // 0xd3bde8: cmp             w3, NULL
    // 0xd3bdec: b.ne            #0xd3bf04
    // 0xd3bdf0: ldur            x3, [fp, #-0x20]
    // 0xd3bdf4: r1 = LoadClassIdInstr(r3)
    //     0xd3bdf4: ldur            x1, [x3, #-1]
    //     0xd3bdf8: ubfx            x1, x1, #0xc, #0x14
    // 0xd3bdfc: r17 = 5069
    //     0xd3bdfc: mov             x17, #0x13cd
    // 0xd3be00: cmp             x1, x17
    // 0xd3be04: b.ne            #0xd3be18
    // 0xd3be08: LoadField: r1 = r3->field_73
    //     0xd3be08: ldur            w1, [x3, #0x73]
    // 0xd3be0c: DecompressPointer r1
    //     0xd3be0c: add             x1, x1, HEAP, lsl #32
    // 0xd3be10: mov             x0, x1
    // 0xd3be14: b               #0xd3bf08
    // 0xd3be18: r17 = 5070
    //     0xd3be18: mov             x17, #0x13ce
    // 0xd3be1c: cmp             x1, x17
    // 0xd3be20: b.eq            #0xd3d230
    // 0xd3be24: r17 = 5071
    //     0xd3be24: mov             x17, #0x13cf
    // 0xd3be28: cmp             x1, x17
    // 0xd3be2c: b.ne            #0xd3be9c
    // 0xd3be30: LoadField: r1 = r3->field_97
    //     0xd3be30: ldur            w1, [x3, #0x97]
    // 0xd3be34: DecompressPointer r1
    //     0xd3be34: add             x1, x1, HEAP, lsl #32
    // 0xd3be38: r0 = of()
    //     0xd3be38: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd3be3c: LoadField: r1 = r0->field_87
    //     0xd3be3c: ldur            w1, [x0, #0x87]
    // 0xd3be40: DecompressPointer r1
    //     0xd3be40: add             x1, x1, HEAP, lsl #32
    // 0xd3be44: LoadField: r0 = r1->field_3b
    //     0xd3be44: ldur            w0, [x1, #0x3b]
    // 0xd3be48: DecompressPointer r0
    //     0xd3be48: add             x0, x0, HEAP, lsl #32
    // 0xd3be4c: stur            x0, [fp, #-0x50]
    // 0xd3be50: cmp             w0, NULL
    // 0xd3be54: b.eq            #0xd3d4bc
    // 0xd3be58: ldur            x1, [fp, #-0x20]
    // 0xd3be5c: LoadField: r0 = r1->field_9b
    //     0xd3be5c: ldur            w0, [x1, #0x9b]
    // 0xd3be60: DecompressPointer r0
    //     0xd3be60: add             x0, x0, HEAP, lsl #32
    // 0xd3be64: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3be68: cmp             w0, w16
    // 0xd3be6c: b.ne            #0xd3be7c
    // 0xd3be70: r2 = _colors
    //     0xd3be70: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0xd3be74: ldr             x2, [x2, #0xa10]
    // 0xd3be78: r0 = InitLateFinalInstanceField()
    //     0xd3be78: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3be7c: LoadField: r1 = r0->field_f
    //     0xd3be7c: ldur            w1, [x0, #0xf]
    // 0xd3be80: DecompressPointer r1
    //     0xd3be80: add             x1, x1, HEAP, lsl #32
    // 0xd3be84: str             x1, [SP]
    // 0xd3be88: ldur            x1, [fp, #-0x50]
    // 0xd3be8c: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0xd3be8c: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0xd3be90: ldr             x4, [x4, #0x7f0]
    // 0xd3be94: r0 = copyWith()
    //     0xd3be94: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xd3be98: b               #0xd3bf08
    // 0xd3be9c: mov             x0, x3
    // 0xd3bea0: LoadField: r1 = r0->field_97
    //     0xd3bea0: ldur            w1, [x0, #0x97]
    // 0xd3bea4: DecompressPointer r1
    //     0xd3bea4: add             x1, x1, HEAP, lsl #32
    // 0xd3bea8: r0 = of()
    //     0xd3bea8: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xd3beac: LoadField: r1 = r0->field_87
    //     0xd3beac: ldur            w1, [x0, #0x87]
    // 0xd3beb0: DecompressPointer r1
    //     0xd3beb0: add             x1, x1, HEAP, lsl #32
    // 0xd3beb4: LoadField: r0 = r1->field_2b
    //     0xd3beb4: ldur            w0, [x1, #0x2b]
    // 0xd3beb8: DecompressPointer r0
    //     0xd3beb8: add             x0, x0, HEAP, lsl #32
    // 0xd3bebc: ldur            x1, [fp, #-0x20]
    // 0xd3bec0: stur            x0, [fp, #-0x50]
    // 0xd3bec4: LoadField: r0 = r1->field_9b
    //     0xd3bec4: ldur            w0, [x1, #0x9b]
    // 0xd3bec8: DecompressPointer r0
    //     0xd3bec8: add             x0, x0, HEAP, lsl #32
    // 0xd3becc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3bed0: cmp             w0, w16
    // 0xd3bed4: b.ne            #0xd3bee4
    // 0xd3bed8: r2 = _colors
    //     0xd3bed8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0xd3bedc: ldr             x2, [x2, #0xa18]
    // 0xd3bee0: r0 = InitLateFinalInstanceField()
    //     0xd3bee0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3bee4: LoadField: r1 = r0->field_f
    //     0xd3bee4: ldur            w1, [x0, #0xf]
    // 0xd3bee8: DecompressPointer r1
    //     0xd3bee8: add             x1, x1, HEAP, lsl #32
    // 0xd3beec: str             x1, [SP]
    // 0xd3bef0: ldur            x1, [fp, #-0x50]
    // 0xd3bef4: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0xd3bef4: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0xd3bef8: ldr             x4, [x4, #0x7f0]
    // 0xd3befc: r0 = copyWith()
    //     0xd3befc: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xd3bf00: b               #0xd3bf08
    // 0xd3bf04: mov             x0, x3
    // 0xd3bf08: ldur            x2, [fp, #-0x18]
    // 0xd3bf0c: stur            x0, [fp, #-0x50]
    // 0xd3bf10: LoadField: r1 = r2->field_13
    //     0xd3bf10: ldur            w1, [x2, #0x13]
    // 0xd3bf14: DecompressPointer r1
    //     0xd3bf14: add             x1, x1, HEAP, lsl #32
    // 0xd3bf18: r0 = boldTextOf()
    //     0xd3bf18: bl              #0xd3d70c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::boldTextOf
    // 0xd3bf1c: tbnz            w0, #4, #0xd3bf34
    // 0xd3bf20: ldur            x1, [fp, #-0x50]
    // 0xd3bf24: r2 = Instance_TextStyle
    //     0xd3bf24: add             x2, PP, #0x28, lsl #12  ; [pp+0x288c8] Obj!TextStyle@12b08c1
    //     0xd3bf28: ldr             x2, [x2, #0x8c8]
    // 0xd3bf2c: r0 = merge()
    //     0xd3bf2c: bl              #0x8a98e8  ; [package:flutter/src/painting/text_style.dart] TextStyle::merge
    // 0xd3bf30: b               #0xd3bf38
    // 0xd3bf34: ldur            x0, [fp, #-0x50]
    // 0xd3bf38: ldur            x2, [fp, #-0x18]
    // 0xd3bf3c: stur            x0, [fp, #-0x58]
    // 0xd3bf40: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xd3bf40: ldur            w3, [x2, #0x17]
    // 0xd3bf44: DecompressPointer r3
    //     0xd3bf44: add             x3, x3, HEAP, lsl #32
    // 0xd3bf48: stur            x3, [fp, #-0x50]
    // 0xd3bf4c: LoadField: r1 = r3->field_7
    //     0xd3bf4c: ldur            w1, [x3, #7]
    // 0xd3bf50: DecompressPointer r1
    //     0xd3bf50: add             x1, x1, HEAP, lsl #32
    // 0xd3bf54: cmp             w1, NULL
    // 0xd3bf58: b.ne            #0xd3bf64
    // 0xd3bf5c: d0 = 4.000000
    //     0xd3bf5c: fmov            d0, #4.00000000
    // 0xd3bf60: b               #0xd3bf68
    // 0xd3bf64: LoadField: d0 = r1->field_7
    //     0xd3bf64: ldur            d0, [x1, #7]
    // 0xd3bf68: ldur            x4, [fp, #-8]
    // 0xd3bf6c: stur            d0, [fp, #-0xc8]
    // 0xd3bf70: LoadField: r1 = r4->field_b
    //     0xd3bf70: ldur            w1, [x4, #0xb]
    // 0xd3bf74: DecompressPointer r1
    //     0xd3bf74: add             x1, x1, HEAP, lsl #32
    // 0xd3bf78: cmp             w1, NULL
    // 0xd3bf7c: b.eq            #0xd3d4c0
    // 0xd3bf80: LoadField: r5 = r1->field_3f
    //     0xd3bf80: ldur            w5, [x1, #0x3f]
    // 0xd3bf84: DecompressPointer r5
    //     0xd3bf84: add             x5, x5, HEAP, lsl #32
    // 0xd3bf88: cmp             w5, NULL
    // 0xd3bf8c: b.ne            #0xd3bf9c
    // 0xd3bf90: LoadField: r1 = r3->field_b
    //     0xd3bf90: ldur            w1, [x3, #0xb]
    // 0xd3bf94: DecompressPointer r1
    //     0xd3bf94: add             x1, x1, HEAP, lsl #32
    // 0xd3bf98: b               #0xd3bfa0
    // 0xd3bf9c: mov             x1, x5
    // 0xd3bfa0: cmp             w1, NULL
    // 0xd3bfa4: b.ne            #0xd3c054
    // 0xd3bfa8: ldur            x5, [fp, #-0x20]
    // 0xd3bfac: r1 = LoadClassIdInstr(r5)
    //     0xd3bfac: ldur            x1, [x5, #-1]
    //     0xd3bfb0: ubfx            x1, x1, #0xc, #0x14
    // 0xd3bfb4: r17 = 5069
    //     0xd3bfb4: mov             x17, #0x13cd
    // 0xd3bfb8: cmp             x1, x17
    // 0xd3bfbc: b.ne            #0xd3bfd0
    // 0xd3bfc0: LoadField: r1 = r5->field_b
    //     0xd3bfc0: ldur            w1, [x5, #0xb]
    // 0xd3bfc4: DecompressPointer r1
    //     0xd3bfc4: add             x1, x1, HEAP, lsl #32
    // 0xd3bfc8: mov             x0, x1
    // 0xd3bfcc: b               #0xd3c04c
    // 0xd3bfd0: r17 = 5070
    //     0xd3bfd0: mov             x17, #0x13ce
    // 0xd3bfd4: cmp             x1, x17
    // 0xd3bfd8: b.eq            #0xd3d23c
    // 0xd3bfdc: r17 = 5071
    //     0xd3bfdc: mov             x17, #0x13cf
    // 0xd3bfe0: cmp             x1, x17
    // 0xd3bfe4: b.ne            #0xd3c01c
    // 0xd3bfe8: mov             x1, x5
    // 0xd3bfec: LoadField: r0 = r1->field_9b
    //     0xd3bfec: ldur            w0, [x1, #0x9b]
    // 0xd3bff0: DecompressPointer r0
    //     0xd3bff0: add             x0, x0, HEAP, lsl #32
    // 0xd3bff4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3bff8: cmp             w0, w16
    // 0xd3bffc: b.ne            #0xd3c00c
    // 0xd3c000: r2 = _colors
    //     0xd3c000: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0xd3c004: ldr             x2, [x2, #0xa10]
    // 0xd3c008: r0 = InitLateFinalInstanceField()
    //     0xd3c008: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3c00c: LoadField: r1 = r0->field_b
    //     0xd3c00c: ldur            w1, [x0, #0xb]
    // 0xd3c010: DecompressPointer r1
    //     0xd3c010: add             x1, x1, HEAP, lsl #32
    // 0xd3c014: mov             x0, x1
    // 0xd3c018: b               #0xd3c04c
    // 0xd3c01c: ldur            x1, [fp, #-0x20]
    // 0xd3c020: LoadField: r0 = r1->field_9b
    //     0xd3c020: ldur            w0, [x1, #0x9b]
    // 0xd3c024: DecompressPointer r0
    //     0xd3c024: add             x0, x0, HEAP, lsl #32
    // 0xd3c028: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3c02c: cmp             w0, w16
    // 0xd3c030: b.ne            #0xd3c040
    // 0xd3c034: r2 = _colors
    //     0xd3c034: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0xd3c038: ldr             x2, [x2, #0xa18]
    // 0xd3c03c: r0 = InitLateFinalInstanceField()
    //     0xd3c03c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3c040: LoadField: r1 = r0->field_b
    //     0xd3c040: ldur            w1, [x0, #0xb]
    // 0xd3c044: DecompressPointer r1
    //     0xd3c044: add             x1, x1, HEAP, lsl #32
    // 0xd3c048: mov             x0, x1
    // 0xd3c04c: mov             x3, x0
    // 0xd3c050: b               #0xd3c058
    // 0xd3c054: mov             x3, x1
    // 0xd3c058: ldur            x0, [fp, #-8]
    // 0xd3c05c: ldur            x2, [fp, #-0x18]
    // 0xd3c060: stur            x3, [fp, #-0x60]
    // 0xd3c064: LoadField: r1 = r0->field_b
    //     0xd3c064: ldur            w1, [x0, #0xb]
    // 0xd3c068: DecompressPointer r1
    //     0xd3c068: add             x1, x1, HEAP, lsl #32
    // 0xd3c06c: cmp             w1, NULL
    // 0xd3c070: b.eq            #0xd3d4c4
    // 0xd3c074: ArrayLoad: r1 = r2[0]  ; List_4
    //     0xd3c074: ldur            w1, [x2, #0x17]
    // 0xd3c078: DecompressPointer r1
    //     0xd3c078: add             x1, x1, HEAP, lsl #32
    // 0xd3c07c: LoadField: r4 = r1->field_f
    //     0xd3c07c: ldur            w4, [x1, #0xf]
    // 0xd3c080: DecompressPointer r4
    //     0xd3c080: add             x4, x4, HEAP, lsl #32
    // 0xd3c084: cmp             w4, NULL
    // 0xd3c088: b.ne            #0xd3c158
    // 0xd3c08c: ldur            x4, [fp, #-0x20]
    // 0xd3c090: r1 = LoadClassIdInstr(r4)
    //     0xd3c090: ldur            x1, [x4, #-1]
    //     0xd3c094: ubfx            x1, x1, #0xc, #0x14
    // 0xd3c098: r17 = 5069
    //     0xd3c098: mov             x17, #0x13cd
    // 0xd3c09c: cmp             x1, x17
    // 0xd3c0a0: b.ne            #0xd3c0b4
    // 0xd3c0a4: LoadField: r1 = r4->field_f
    //     0xd3c0a4: ldur            w1, [x4, #0xf]
    // 0xd3c0a8: DecompressPointer r1
    //     0xd3c0a8: add             x1, x1, HEAP, lsl #32
    // 0xd3c0ac: mov             x0, x1
    // 0xd3c0b0: b               #0xd3c150
    // 0xd3c0b4: r17 = 5070
    //     0xd3c0b4: mov             x17, #0x13ce
    // 0xd3c0b8: cmp             x1, x17
    // 0xd3c0bc: b.eq            #0xd3d270
    // 0xd3c0c0: r17 = 5071
    //     0xd3c0c0: mov             x17, #0x13cf
    // 0xd3c0c4: cmp             x1, x17
    // 0xd3c0c8: b.ne            #0xd3c118
    // 0xd3c0cc: mov             x1, x4
    // 0xd3c0d0: LoadField: r0 = r1->field_9b
    //     0xd3c0d0: ldur            w0, [x1, #0x9b]
    // 0xd3c0d4: DecompressPointer r0
    //     0xd3c0d4: add             x0, x0, HEAP, lsl #32
    // 0xd3c0d8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3c0dc: cmp             w0, w16
    // 0xd3c0e0: b.ne            #0xd3c0f0
    // 0xd3c0e4: r2 = _colors
    //     0xd3c0e4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0xd3c0e8: ldr             x2, [x2, #0xa10]
    // 0xd3c0ec: r0 = InitLateFinalInstanceField()
    //     0xd3c0ec: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3c0f0: LoadField: r1 = r0->field_9f
    //     0xd3c0f0: ldur            w1, [x0, #0x9f]
    // 0xd3c0f4: DecompressPointer r1
    //     0xd3c0f4: add             x1, x1, HEAP, lsl #32
    // 0xd3c0f8: cmp             w1, NULL
    // 0xd3c0fc: b.ne            #0xd3c110
    // 0xd3c100: LoadField: r1 = r0->field_7b
    //     0xd3c100: ldur            w1, [x0, #0x7b]
    // 0xd3c104: DecompressPointer r1
    //     0xd3c104: add             x1, x1, HEAP, lsl #32
    // 0xd3c108: mov             x0, x1
    // 0xd3c10c: b               #0xd3c150
    // 0xd3c110: mov             x0, x1
    // 0xd3c114: b               #0xd3c150
    // 0xd3c118: ldur            x1, [fp, #-0x20]
    // 0xd3c11c: LoadField: r0 = r1->field_9b
    //     0xd3c11c: ldur            w0, [x1, #0x9b]
    // 0xd3c120: DecompressPointer r0
    //     0xd3c120: add             x0, x0, HEAP, lsl #32
    // 0xd3c124: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3c128: cmp             w0, w16
    // 0xd3c12c: b.ne            #0xd3c13c
    // 0xd3c130: r2 = _colors
    //     0xd3c130: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0xd3c134: ldr             x2, [x2, #0xa18]
    // 0xd3c138: r0 = InitLateFinalInstanceField()
    //     0xd3c138: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3c13c: LoadField: r1 = r0->field_b
    //     0xd3c13c: ldur            w1, [x0, #0xb]
    // 0xd3c140: DecompressPointer r1
    //     0xd3c140: add             x1, x1, HEAP, lsl #32
    // 0xd3c144: d0 = 0.240000
    //     0xd3c144: add             x17, PP, #0x26, lsl #12  ; [pp+0x26a20] IMM: double(0.24) from 0x3fceb851eb851eb8
    //     0xd3c148: ldr             d0, [x17, #0xa20]
    // 0xd3c14c: r0 = withOpacity()
    //     0xd3c14c: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xd3c150: mov             x3, x0
    // 0xd3c154: b               #0xd3c15c
    // 0xd3c158: mov             x3, x4
    // 0xd3c15c: ldur            x0, [fp, #-8]
    // 0xd3c160: ldur            x2, [fp, #-0x18]
    // 0xd3c164: stur            x3, [fp, #-0x68]
    // 0xd3c168: LoadField: r1 = r0->field_b
    //     0xd3c168: ldur            w1, [x0, #0xb]
    // 0xd3c16c: DecompressPointer r1
    //     0xd3c16c: add             x1, x1, HEAP, lsl #32
    // 0xd3c170: cmp             w1, NULL
    // 0xd3c174: b.eq            #0xd3d4c8
    // 0xd3c178: ArrayLoad: r1 = r2[0]  ; List_4
    //     0xd3c178: ldur            w1, [x2, #0x17]
    // 0xd3c17c: DecompressPointer r1
    //     0xd3c17c: add             x1, x1, HEAP, lsl #32
    // 0xd3c180: LoadField: r4 = r1->field_13
    //     0xd3c180: ldur            w4, [x1, #0x13]
    // 0xd3c184: DecompressPointer r4
    //     0xd3c184: add             x4, x4, HEAP, lsl #32
    // 0xd3c188: cmp             w4, NULL
    // 0xd3c18c: b.ne            #0xd3c248
    // 0xd3c190: ldur            x4, [fp, #-0x20]
    // 0xd3c194: r1 = LoadClassIdInstr(r4)
    //     0xd3c194: ldur            x1, [x4, #-1]
    //     0xd3c198: ubfx            x1, x1, #0xc, #0x14
    // 0xd3c19c: r17 = 5069
    //     0xd3c19c: mov             x17, #0x13cd
    // 0xd3c1a0: cmp             x1, x17
    // 0xd3c1a4: b.ne            #0xd3c1b8
    // 0xd3c1a8: LoadField: r1 = r4->field_13
    //     0xd3c1a8: ldur            w1, [x4, #0x13]
    // 0xd3c1ac: DecompressPointer r1
    //     0xd3c1ac: add             x1, x1, HEAP, lsl #32
    // 0xd3c1b0: mov             x0, x1
    // 0xd3c1b4: b               #0xd3c24c
    // 0xd3c1b8: r17 = 5070
    //     0xd3c1b8: mov             x17, #0x13ce
    // 0xd3c1bc: cmp             x1, x17
    // 0xd3c1c0: b.eq            #0xd3d2a4
    // 0xd3c1c4: r17 = 5071
    //     0xd3c1c4: mov             x17, #0x13cf
    // 0xd3c1c8: cmp             x1, x17
    // 0xd3c1cc: b.ne            #0xd3c20c
    // 0xd3c1d0: mov             x1, x4
    // 0xd3c1d4: LoadField: r0 = r1->field_9b
    //     0xd3c1d4: ldur            w0, [x1, #0x9b]
    // 0xd3c1d8: DecompressPointer r0
    //     0xd3c1d8: add             x0, x0, HEAP, lsl #32
    // 0xd3c1dc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3c1e0: cmp             w0, w16
    // 0xd3c1e4: b.ne            #0xd3c1f4
    // 0xd3c1e8: r2 = _colors
    //     0xd3c1e8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0xd3c1ec: ldr             x2, [x2, #0xa10]
    // 0xd3c1f0: r0 = InitLateFinalInstanceField()
    //     0xd3c1f0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3c1f4: LoadField: r1 = r0->field_b
    //     0xd3c1f4: ldur            w1, [x0, #0xb]
    // 0xd3c1f8: DecompressPointer r1
    //     0xd3c1f8: add             x1, x1, HEAP, lsl #32
    // 0xd3c1fc: d0 = 0.540000
    //     0xd3c1fc: add             x17, PP, #0x26, lsl #12  ; [pp+0x26a28] IMM: double(0.54) from 0x3fe147ae147ae148
    //     0xd3c200: ldr             d0, [x17, #0xa28]
    // 0xd3c204: r0 = withOpacity()
    //     0xd3c204: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xd3c208: b               #0xd3c24c
    // 0xd3c20c: ldur            x1, [fp, #-0x20]
    // 0xd3c210: LoadField: r0 = r1->field_9b
    //     0xd3c210: ldur            w0, [x1, #0x9b]
    // 0xd3c214: DecompressPointer r0
    //     0xd3c214: add             x0, x0, HEAP, lsl #32
    // 0xd3c218: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3c21c: cmp             w0, w16
    // 0xd3c220: b.ne            #0xd3c230
    // 0xd3c224: r2 = _colors
    //     0xd3c224: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0xd3c228: ldr             x2, [x2, #0xa18]
    // 0xd3c22c: r0 = InitLateFinalInstanceField()
    //     0xd3c22c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3c230: LoadField: r1 = r0->field_b
    //     0xd3c230: ldur            w1, [x0, #0xb]
    // 0xd3c234: DecompressPointer r1
    //     0xd3c234: add             x1, x1, HEAP, lsl #32
    // 0xd3c238: d0 = 0.540000
    //     0xd3c238: add             x17, PP, #0x26, lsl #12  ; [pp+0x26a28] IMM: double(0.54) from 0x3fe147ae147ae148
    //     0xd3c23c: ldr             d0, [x17, #0xa28]
    // 0xd3c240: r0 = withOpacity()
    //     0xd3c240: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xd3c244: b               #0xd3c24c
    // 0xd3c248: mov             x0, x4
    // 0xd3c24c: ldur            x2, [fp, #-0x18]
    // 0xd3c250: stur            x0, [fp, #-0x70]
    // 0xd3c254: ArrayLoad: r1 = r2[0]  ; List_4
    //     0xd3c254: ldur            w1, [x2, #0x17]
    // 0xd3c258: DecompressPointer r1
    //     0xd3c258: add             x1, x1, HEAP, lsl #32
    // 0xd3c25c: ArrayLoad: r3 = r1[0]  ; List_4
    //     0xd3c25c: ldur            w3, [x1, #0x17]
    // 0xd3c260: DecompressPointer r3
    //     0xd3c260: add             x3, x3, HEAP, lsl #32
    // 0xd3c264: cmp             w3, NULL
    // 0xd3c268: b.ne            #0xd3c344
    // 0xd3c26c: ldur            x3, [fp, #-0x20]
    // 0xd3c270: r1 = LoadClassIdInstr(r3)
    //     0xd3c270: ldur            x1, [x3, #-1]
    //     0xd3c274: ubfx            x1, x1, #0xc, #0x14
    // 0xd3c278: r17 = 5069
    //     0xd3c278: mov             x17, #0x13cd
    // 0xd3c27c: cmp             x1, x17
    // 0xd3c280: b.ne            #0xd3c294
    // 0xd3c284: ArrayLoad: r1 = r3[0]  ; List_4
    //     0xd3c284: ldur            w1, [x3, #0x17]
    // 0xd3c288: DecompressPointer r1
    //     0xd3c288: add             x1, x1, HEAP, lsl #32
    // 0xd3c28c: mov             x0, x1
    // 0xd3c290: b               #0xd3c348
    // 0xd3c294: r17 = 5070
    //     0xd3c294: mov             x17, #0x13ce
    // 0xd3c298: cmp             x1, x17
    // 0xd3c29c: b.eq            #0xd3d2d8
    // 0xd3c2a0: r17 = 5071
    //     0xd3c2a0: mov             x17, #0x13cf
    // 0xd3c2a4: cmp             x1, x17
    // 0xd3c2a8: b.ne            #0xd3c2f8
    // 0xd3c2ac: mov             x1, x3
    // 0xd3c2b0: LoadField: r0 = r1->field_9b
    //     0xd3c2b0: ldur            w0, [x1, #0x9b]
    // 0xd3c2b4: DecompressPointer r0
    //     0xd3c2b4: add             x0, x0, HEAP, lsl #32
    // 0xd3c2b8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3c2bc: cmp             w0, w16
    // 0xd3c2c0: b.ne            #0xd3c2d0
    // 0xd3c2c4: r2 = _colors
    //     0xd3c2c4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0xd3c2c8: ldr             x2, [x2, #0xa10]
    // 0xd3c2cc: r0 = InitLateFinalInstanceField()
    //     0xd3c2cc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3c2d0: LoadField: r1 = r0->field_7f
    //     0xd3c2d0: ldur            w1, [x0, #0x7f]
    // 0xd3c2d4: DecompressPointer r1
    //     0xd3c2d4: add             x1, x1, HEAP, lsl #32
    // 0xd3c2d8: r0 = LoadClassIdInstr(r1)
    //     0xd3c2d8: ldur            x0, [x1, #-1]
    //     0xd3c2dc: ubfx            x0, x0, #0xc, #0x14
    // 0xd3c2e0: d0 = 0.380000
    //     0xd3c2e0: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xd3c2e4: ldr             d0, [x17, #0x1f0]
    // 0xd3c2e8: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd3c2e8: sub             lr, x0, #1, lsl #12
    //     0xd3c2ec: ldr             lr, [x21, lr, lsl #3]
    //     0xd3c2f0: blr             lr
    // 0xd3c2f4: b               #0xd3c348
    // 0xd3c2f8: ldur            x1, [fp, #-0x20]
    // 0xd3c2fc: LoadField: r0 = r1->field_9b
    //     0xd3c2fc: ldur            w0, [x1, #0x9b]
    // 0xd3c300: DecompressPointer r0
    //     0xd3c300: add             x0, x0, HEAP, lsl #32
    // 0xd3c304: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3c308: cmp             w0, w16
    // 0xd3c30c: b.ne            #0xd3c31c
    // 0xd3c310: r2 = _colors
    //     0xd3c310: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0xd3c314: ldr             x2, [x2, #0xa18]
    // 0xd3c318: r0 = InitLateFinalInstanceField()
    //     0xd3c318: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3c31c: LoadField: r1 = r0->field_7f
    //     0xd3c31c: ldur            w1, [x0, #0x7f]
    // 0xd3c320: DecompressPointer r1
    //     0xd3c320: add             x1, x1, HEAP, lsl #32
    // 0xd3c324: r0 = LoadClassIdInstr(r1)
    //     0xd3c324: ldur            x0, [x1, #-1]
    //     0xd3c328: ubfx            x0, x0, #0xc, #0x14
    // 0xd3c32c: d0 = 0.320000
    //     0xd3c32c: add             x17, PP, #0x26, lsl #12  ; [pp+0x26a30] IMM: double(0.32) from 0x3fd47ae147ae147b
    //     0xd3c330: ldr             d0, [x17, #0xa30]
    // 0xd3c334: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd3c334: sub             lr, x0, #1, lsl #12
    //     0xd3c338: ldr             lr, [x21, lr, lsl #3]
    //     0xd3c33c: blr             lr
    // 0xd3c340: b               #0xd3c348
    // 0xd3c344: mov             x0, x3
    // 0xd3c348: ldur            x2, [fp, #-0x18]
    // 0xd3c34c: stur            x0, [fp, #-0x78]
    // 0xd3c350: ArrayLoad: r1 = r2[0]  ; List_4
    //     0xd3c350: ldur            w1, [x2, #0x17]
    // 0xd3c354: DecompressPointer r1
    //     0xd3c354: add             x1, x1, HEAP, lsl #32
    // 0xd3c358: LoadField: r3 = r1->field_1f
    //     0xd3c358: ldur            w3, [x1, #0x1f]
    // 0xd3c35c: DecompressPointer r3
    //     0xd3c35c: add             x3, x3, HEAP, lsl #32
    // 0xd3c360: cmp             w3, NULL
    // 0xd3c364: b.ne            #0xd3c440
    // 0xd3c368: ldur            x3, [fp, #-0x20]
    // 0xd3c36c: r1 = LoadClassIdInstr(r3)
    //     0xd3c36c: ldur            x1, [x3, #-1]
    //     0xd3c370: ubfx            x1, x1, #0xc, #0x14
    // 0xd3c374: r17 = 5069
    //     0xd3c374: mov             x17, #0x13cd
    // 0xd3c378: cmp             x1, x17
    // 0xd3c37c: b.ne            #0xd3c390
    // 0xd3c380: LoadField: r1 = r3->field_1f
    //     0xd3c380: ldur            w1, [x3, #0x1f]
    // 0xd3c384: DecompressPointer r1
    //     0xd3c384: add             x1, x1, HEAP, lsl #32
    // 0xd3c388: mov             x0, x1
    // 0xd3c38c: b               #0xd3c444
    // 0xd3c390: r17 = 5070
    //     0xd3c390: mov             x17, #0x13ce
    // 0xd3c394: cmp             x1, x17
    // 0xd3c398: b.eq            #0xd3d30c
    // 0xd3c39c: r17 = 5071
    //     0xd3c39c: mov             x17, #0x13cf
    // 0xd3c3a0: cmp             x1, x17
    // 0xd3c3a4: b.ne            #0xd3c3f4
    // 0xd3c3a8: mov             x1, x3
    // 0xd3c3ac: LoadField: r0 = r1->field_9b
    //     0xd3c3ac: ldur            w0, [x1, #0x9b]
    // 0xd3c3b0: DecompressPointer r0
    //     0xd3c3b0: add             x0, x0, HEAP, lsl #32
    // 0xd3c3b4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3c3b8: cmp             w0, w16
    // 0xd3c3bc: b.ne            #0xd3c3cc
    // 0xd3c3c0: r2 = _colors
    //     0xd3c3c0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0xd3c3c4: ldr             x2, [x2, #0xa10]
    // 0xd3c3c8: r0 = InitLateFinalInstanceField()
    //     0xd3c3c8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3c3cc: LoadField: r1 = r0->field_7f
    //     0xd3c3cc: ldur            w1, [x0, #0x7f]
    // 0xd3c3d0: DecompressPointer r1
    //     0xd3c3d0: add             x1, x1, HEAP, lsl #32
    // 0xd3c3d4: r0 = LoadClassIdInstr(r1)
    //     0xd3c3d4: ldur            x0, [x1, #-1]
    //     0xd3c3d8: ubfx            x0, x0, #0xc, #0x14
    // 0xd3c3dc: d0 = 0.120000
    //     0xd3c3dc: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xd3c3e0: ldr             d0, [x17, #0xc40]
    // 0xd3c3e4: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd3c3e4: sub             lr, x0, #1, lsl #12
    //     0xd3c3e8: ldr             lr, [x21, lr, lsl #3]
    //     0xd3c3ec: blr             lr
    // 0xd3c3f0: b               #0xd3c444
    // 0xd3c3f4: ldur            x1, [fp, #-0x20]
    // 0xd3c3f8: LoadField: r0 = r1->field_9b
    //     0xd3c3f8: ldur            w0, [x1, #0x9b]
    // 0xd3c3fc: DecompressPointer r0
    //     0xd3c3fc: add             x0, x0, HEAP, lsl #32
    // 0xd3c400: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3c404: cmp             w0, w16
    // 0xd3c408: b.ne            #0xd3c418
    // 0xd3c40c: r2 = _colors
    //     0xd3c40c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0xd3c410: ldr             x2, [x2, #0xa18]
    // 0xd3c414: r0 = InitLateFinalInstanceField()
    //     0xd3c414: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3c418: LoadField: r1 = r0->field_7f
    //     0xd3c418: ldur            w1, [x0, #0x7f]
    // 0xd3c41c: DecompressPointer r1
    //     0xd3c41c: add             x1, x1, HEAP, lsl #32
    // 0xd3c420: r0 = LoadClassIdInstr(r1)
    //     0xd3c420: ldur            x0, [x1, #-1]
    //     0xd3c424: ubfx            x0, x0, #0xc, #0x14
    // 0xd3c428: d0 = 0.120000
    //     0xd3c428: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xd3c42c: ldr             d0, [x17, #0xc40]
    // 0xd3c430: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd3c430: sub             lr, x0, #1, lsl #12
    //     0xd3c434: ldr             lr, [x21, lr, lsl #3]
    //     0xd3c438: blr             lr
    // 0xd3c43c: b               #0xd3c444
    // 0xd3c440: mov             x0, x3
    // 0xd3c444: ldur            x2, [fp, #-0x18]
    // 0xd3c448: stur            x0, [fp, #-0x80]
    // 0xd3c44c: ArrayLoad: r1 = r2[0]  ; List_4
    //     0xd3c44c: ldur            w1, [x2, #0x17]
    // 0xd3c450: DecompressPointer r1
    //     0xd3c450: add             x1, x1, HEAP, lsl #32
    // 0xd3c454: LoadField: r3 = r1->field_1b
    //     0xd3c454: ldur            w3, [x1, #0x1b]
    // 0xd3c458: DecompressPointer r3
    //     0xd3c458: add             x3, x3, HEAP, lsl #32
    // 0xd3c45c: cmp             w3, NULL
    // 0xd3c460: b.ne            #0xd3c53c
    // 0xd3c464: ldur            x3, [fp, #-0x20]
    // 0xd3c468: r1 = LoadClassIdInstr(r3)
    //     0xd3c468: ldur            x1, [x3, #-1]
    //     0xd3c46c: ubfx            x1, x1, #0xc, #0x14
    // 0xd3c470: r17 = 5069
    //     0xd3c470: mov             x17, #0x13cd
    // 0xd3c474: cmp             x1, x17
    // 0xd3c478: b.ne            #0xd3c48c
    // 0xd3c47c: LoadField: r1 = r3->field_1b
    //     0xd3c47c: ldur            w1, [x3, #0x1b]
    // 0xd3c480: DecompressPointer r1
    //     0xd3c480: add             x1, x1, HEAP, lsl #32
    // 0xd3c484: mov             x0, x1
    // 0xd3c488: b               #0xd3c538
    // 0xd3c48c: r17 = 5070
    //     0xd3c48c: mov             x17, #0x13ce
    // 0xd3c490: cmp             x1, x17
    // 0xd3c494: b.eq            #0xd3d340
    // 0xd3c498: r17 = 5071
    //     0xd3c498: mov             x17, #0x13cf
    // 0xd3c49c: cmp             x1, x17
    // 0xd3c4a0: b.ne            #0xd3c4f0
    // 0xd3c4a4: mov             x1, x3
    // 0xd3c4a8: LoadField: r0 = r1->field_9b
    //     0xd3c4a8: ldur            w0, [x1, #0x9b]
    // 0xd3c4ac: DecompressPointer r0
    //     0xd3c4ac: add             x0, x0, HEAP, lsl #32
    // 0xd3c4b0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3c4b4: cmp             w0, w16
    // 0xd3c4b8: b.ne            #0xd3c4c8
    // 0xd3c4bc: r2 = _colors
    //     0xd3c4bc: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0xd3c4c0: ldr             x2, [x2, #0xa10]
    // 0xd3c4c4: r0 = InitLateFinalInstanceField()
    //     0xd3c4c4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3c4c8: LoadField: r1 = r0->field_7f
    //     0xd3c4c8: ldur            w1, [x0, #0x7f]
    // 0xd3c4cc: DecompressPointer r1
    //     0xd3c4cc: add             x1, x1, HEAP, lsl #32
    // 0xd3c4d0: r0 = LoadClassIdInstr(r1)
    //     0xd3c4d0: ldur            x0, [x1, #-1]
    //     0xd3c4d4: ubfx            x0, x0, #0xc, #0x14
    // 0xd3c4d8: d0 = 0.120000
    //     0xd3c4d8: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xd3c4dc: ldr             d0, [x17, #0xc40]
    // 0xd3c4e0: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd3c4e0: sub             lr, x0, #1, lsl #12
    //     0xd3c4e4: ldr             lr, [x21, lr, lsl #3]
    //     0xd3c4e8: blr             lr
    // 0xd3c4ec: b               #0xd3c538
    // 0xd3c4f0: ldur            x1, [fp, #-0x20]
    // 0xd3c4f4: LoadField: r0 = r1->field_9b
    //     0xd3c4f4: ldur            w0, [x1, #0x9b]
    // 0xd3c4f8: DecompressPointer r0
    //     0xd3c4f8: add             x0, x0, HEAP, lsl #32
    // 0xd3c4fc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3c500: cmp             w0, w16
    // 0xd3c504: b.ne            #0xd3c514
    // 0xd3c508: r2 = _colors
    //     0xd3c508: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0xd3c50c: ldr             x2, [x2, #0xa18]
    // 0xd3c510: r0 = InitLateFinalInstanceField()
    //     0xd3c510: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3c514: LoadField: r1 = r0->field_7f
    //     0xd3c514: ldur            w1, [x0, #0x7f]
    // 0xd3c518: DecompressPointer r1
    //     0xd3c518: add             x1, x1, HEAP, lsl #32
    // 0xd3c51c: r0 = LoadClassIdInstr(r1)
    //     0xd3c51c: ldur            x0, [x1, #-1]
    //     0xd3c520: ubfx            x0, x0, #0xc, #0x14
    // 0xd3c524: d0 = 0.120000
    //     0xd3c524: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xd3c528: ldr             d0, [x17, #0xc40]
    // 0xd3c52c: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd3c52c: sub             lr, x0, #1, lsl #12
    //     0xd3c530: ldr             lr, [x21, lr, lsl #3]
    //     0xd3c534: blr             lr
    // 0xd3c538: mov             x3, x0
    // 0xd3c53c: ldur            x0, [fp, #-8]
    // 0xd3c540: ldur            x2, [fp, #-0x18]
    // 0xd3c544: stur            x3, [fp, #-0x88]
    // 0xd3c548: LoadField: r1 = r0->field_b
    //     0xd3c548: ldur            w1, [x0, #0xb]
    // 0xd3c54c: DecompressPointer r1
    //     0xd3c54c: add             x1, x1, HEAP, lsl #32
    // 0xd3c550: cmp             w1, NULL
    // 0xd3c554: b.eq            #0xd3d4cc
    // 0xd3c558: ArrayLoad: r1 = r2[0]  ; List_4
    //     0xd3c558: ldur            w1, [x2, #0x17]
    // 0xd3c55c: DecompressPointer r1
    //     0xd3c55c: add             x1, x1, HEAP, lsl #32
    // 0xd3c560: LoadField: r4 = r1->field_23
    //     0xd3c560: ldur            w4, [x1, #0x23]
    // 0xd3c564: DecompressPointer r4
    //     0xd3c564: add             x4, x4, HEAP, lsl #32
    // 0xd3c568: cmp             w4, NULL
    // 0xd3c56c: b.ne            #0xd3c62c
    // 0xd3c570: ldur            x4, [fp, #-0x20]
    // 0xd3c574: r1 = LoadClassIdInstr(r4)
    //     0xd3c574: ldur            x1, [x4, #-1]
    //     0xd3c578: ubfx            x1, x1, #0xc, #0x14
    // 0xd3c57c: r17 = 5069
    //     0xd3c57c: mov             x17, #0x13cd
    // 0xd3c580: cmp             x1, x17
    // 0xd3c584: b.ne            #0xd3c598
    // 0xd3c588: LoadField: r1 = r4->field_23
    //     0xd3c588: ldur            w1, [x4, #0x23]
    // 0xd3c58c: DecompressPointer r1
    //     0xd3c58c: add             x1, x1, HEAP, lsl #32
    // 0xd3c590: mov             x0, x1
    // 0xd3c594: b               #0xd3c624
    // 0xd3c598: r17 = 5070
    //     0xd3c598: mov             x17, #0x13ce
    // 0xd3c59c: cmp             x1, x17
    // 0xd3c5a0: b.eq            #0xd3d374
    // 0xd3c5a4: r17 = 5071
    //     0xd3c5a4: mov             x17, #0x13cf
    // 0xd3c5a8: cmp             x1, x17
    // 0xd3c5ac: b.ne            #0xd3c5ec
    // 0xd3c5b0: mov             x1, x4
    // 0xd3c5b4: LoadField: r0 = r1->field_9b
    //     0xd3c5b4: ldur            w0, [x1, #0x9b]
    // 0xd3c5b8: DecompressPointer r0
    //     0xd3c5b8: add             x0, x0, HEAP, lsl #32
    // 0xd3c5bc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3c5c0: cmp             w0, w16
    // 0xd3c5c4: b.ne            #0xd3c5d4
    // 0xd3c5c8: r2 = _colors
    //     0xd3c5c8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0xd3c5cc: ldr             x2, [x2, #0xa10]
    // 0xd3c5d0: r0 = InitLateFinalInstanceField()
    //     0xd3c5d0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3c5d4: LoadField: r1 = r0->field_f
    //     0xd3c5d4: ldur            w1, [x0, #0xf]
    // 0xd3c5d8: DecompressPointer r1
    //     0xd3c5d8: add             x1, x1, HEAP, lsl #32
    // 0xd3c5dc: d0 = 0.380000
    //     0xd3c5dc: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xd3c5e0: ldr             d0, [x17, #0x1f0]
    // 0xd3c5e4: r0 = withOpacity()
    //     0xd3c5e4: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xd3c5e8: b               #0xd3c624
    // 0xd3c5ec: ldur            x1, [fp, #-0x20]
    // 0xd3c5f0: LoadField: r0 = r1->field_9b
    //     0xd3c5f0: ldur            w0, [x1, #0x9b]
    // 0xd3c5f4: DecompressPointer r0
    //     0xd3c5f4: add             x0, x0, HEAP, lsl #32
    // 0xd3c5f8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3c5fc: cmp             w0, w16
    // 0xd3c600: b.ne            #0xd3c610
    // 0xd3c604: r2 = _colors
    //     0xd3c604: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0xd3c608: ldr             x2, [x2, #0xa18]
    // 0xd3c60c: r0 = InitLateFinalInstanceField()
    //     0xd3c60c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3c610: LoadField: r1 = r0->field_f
    //     0xd3c610: ldur            w1, [x0, #0xf]
    // 0xd3c614: DecompressPointer r1
    //     0xd3c614: add             x1, x1, HEAP, lsl #32
    // 0xd3c618: d0 = 0.540000
    //     0xd3c618: add             x17, PP, #0x26, lsl #12  ; [pp+0x26a28] IMM: double(0.54) from 0x3fe147ae147ae148
    //     0xd3c61c: ldr             d0, [x17, #0xa28]
    // 0xd3c620: r0 = withOpacity()
    //     0xd3c620: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xd3c624: mov             x2, x0
    // 0xd3c628: b               #0xd3c630
    // 0xd3c62c: mov             x2, x4
    // 0xd3c630: ldur            x0, [fp, #-8]
    // 0xd3c634: stur            x2, [fp, #-0x90]
    // 0xd3c638: LoadField: r1 = r0->field_b
    //     0xd3c638: ldur            w1, [x0, #0xb]
    // 0xd3c63c: DecompressPointer r1
    //     0xd3c63c: add             x1, x1, HEAP, lsl #32
    // 0xd3c640: cmp             w1, NULL
    // 0xd3c644: b.eq            #0xd3d4d0
    // 0xd3c648: LoadField: r3 = r1->field_3f
    //     0xd3c648: ldur            w3, [x1, #0x3f]
    // 0xd3c64c: DecompressPointer r3
    //     0xd3c64c: add             x3, x3, HEAP, lsl #32
    // 0xd3c650: cmp             w3, NULL
    // 0xd3c654: b.ne            #0xd3c674
    // 0xd3c658: ldur            x4, [fp, #-0x18]
    // 0xd3c65c: ArrayLoad: r1 = r4[0]  ; List_4
    //     0xd3c65c: ldur            w1, [x4, #0x17]
    // 0xd3c660: DecompressPointer r1
    //     0xd3c660: add             x1, x1, HEAP, lsl #32
    // 0xd3c664: LoadField: r3 = r1->field_27
    //     0xd3c664: ldur            w3, [x1, #0x27]
    // 0xd3c668: DecompressPointer r3
    //     0xd3c668: add             x3, x3, HEAP, lsl #32
    // 0xd3c66c: mov             x1, x3
    // 0xd3c670: b               #0xd3c67c
    // 0xd3c674: ldur            x4, [fp, #-0x18]
    // 0xd3c678: mov             x1, x3
    // 0xd3c67c: cmp             w1, NULL
    // 0xd3c680: b.ne            #0xd3c75c
    // 0xd3c684: ldur            x3, [fp, #-0x20]
    // 0xd3c688: r1 = LoadClassIdInstr(r3)
    //     0xd3c688: ldur            x1, [x3, #-1]
    //     0xd3c68c: ubfx            x1, x1, #0xc, #0x14
    // 0xd3c690: r17 = 5069
    //     0xd3c690: mov             x17, #0x13cd
    // 0xd3c694: cmp             x1, x17
    // 0xd3c698: b.ne            #0xd3c6ac
    // 0xd3c69c: LoadField: r1 = r3->field_27
    //     0xd3c69c: ldur            w1, [x3, #0x27]
    // 0xd3c6a0: DecompressPointer r1
    //     0xd3c6a0: add             x1, x1, HEAP, lsl #32
    // 0xd3c6a4: mov             x0, x1
    // 0xd3c6a8: b               #0xd3c760
    // 0xd3c6ac: r17 = 5070
    //     0xd3c6ac: mov             x17, #0x13ce
    // 0xd3c6b0: cmp             x1, x17
    // 0xd3c6b4: b.eq            #0xd3d3a8
    // 0xd3c6b8: r17 = 5071
    //     0xd3c6b8: mov             x17, #0x13cf
    // 0xd3c6bc: cmp             x1, x17
    // 0xd3c6c0: b.ne            #0xd3c720
    // 0xd3c6c4: mov             x1, x3
    // 0xd3c6c8: LoadField: r0 = r1->field_9b
    //     0xd3c6c8: ldur            w0, [x1, #0x9b]
    // 0xd3c6cc: DecompressPointer r0
    //     0xd3c6cc: add             x0, x0, HEAP, lsl #32
    // 0xd3c6d0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3c6d4: cmp             w0, w16
    // 0xd3c6d8: b.ne            #0xd3c6e8
    // 0xd3c6dc: r2 = _colors
    //     0xd3c6dc: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0xd3c6e0: ldr             x2, [x2, #0xa10]
    // 0xd3c6e4: r0 = InitLateFinalInstanceField()
    //     0xd3c6e4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3c6e8: LoadField: r1 = r0->field_a3
    //     0xd3c6e8: ldur            w1, [x0, #0xa3]
    // 0xd3c6ec: DecompressPointer r1
    //     0xd3c6ec: add             x1, x1, HEAP, lsl #32
    // 0xd3c6f0: cmp             w1, NULL
    // 0xd3c6f4: b.ne            #0xd3c700
    // 0xd3c6f8: LoadField: r1 = r0->field_7f
    //     0xd3c6f8: ldur            w1, [x0, #0x7f]
    // 0xd3c6fc: DecompressPointer r1
    //     0xd3c6fc: add             x1, x1, HEAP, lsl #32
    // 0xd3c700: r0 = LoadClassIdInstr(r1)
    //     0xd3c700: ldur            x0, [x1, #-1]
    //     0xd3c704: ubfx            x0, x0, #0xc, #0x14
    // 0xd3c708: d0 = 0.380000
    //     0xd3c708: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xd3c70c: ldr             d0, [x17, #0x1f0]
    // 0xd3c710: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd3c710: sub             lr, x0, #1, lsl #12
    //     0xd3c714: ldr             lr, [x21, lr, lsl #3]
    //     0xd3c718: blr             lr
    // 0xd3c71c: b               #0xd3c760
    // 0xd3c720: ldur            x1, [fp, #-0x20]
    // 0xd3c724: LoadField: r0 = r1->field_9b
    //     0xd3c724: ldur            w0, [x1, #0x9b]
    // 0xd3c728: DecompressPointer r0
    //     0xd3c728: add             x0, x0, HEAP, lsl #32
    // 0xd3c72c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3c730: cmp             w0, w16
    // 0xd3c734: b.ne            #0xd3c744
    // 0xd3c738: r2 = _colors
    //     0xd3c738: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0xd3c73c: ldr             x2, [x2, #0xa18]
    // 0xd3c740: r0 = InitLateFinalInstanceField()
    //     0xd3c740: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3c744: LoadField: r1 = r0->field_b
    //     0xd3c744: ldur            w1, [x0, #0xb]
    // 0xd3c748: DecompressPointer r1
    //     0xd3c748: add             x1, x1, HEAP, lsl #32
    // 0xd3c74c: d0 = 0.540000
    //     0xd3c74c: add             x17, PP, #0x26, lsl #12  ; [pp+0x26a28] IMM: double(0.54) from 0x3fe147ae147ae148
    //     0xd3c750: ldr             d0, [x17, #0xa28]
    // 0xd3c754: r0 = withOpacity()
    //     0xd3c754: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xd3c758: b               #0xd3c760
    // 0xd3c75c: mov             x0, x1
    // 0xd3c760: ldur            x2, [fp, #-0x18]
    // 0xd3c764: stur            x0, [fp, #-0x98]
    // 0xd3c768: ArrayLoad: r1 = r2[0]  ; List_4
    //     0xd3c768: ldur            w1, [x2, #0x17]
    // 0xd3c76c: DecompressPointer r1
    //     0xd3c76c: add             x1, x1, HEAP, lsl #32
    // 0xd3c770: LoadField: r3 = r1->field_2b
    //     0xd3c770: ldur            w3, [x1, #0x2b]
    // 0xd3c774: DecompressPointer r3
    //     0xd3c774: add             x3, x3, HEAP, lsl #32
    // 0xd3c778: cmp             w3, NULL
    // 0xd3c77c: b.ne            #0xd3c848
    // 0xd3c780: ldur            x3, [fp, #-0x20]
    // 0xd3c784: r1 = LoadClassIdInstr(r3)
    //     0xd3c784: ldur            x1, [x3, #-1]
    //     0xd3c788: ubfx            x1, x1, #0xc, #0x14
    // 0xd3c78c: r17 = 5069
    //     0xd3c78c: mov             x17, #0x13cd
    // 0xd3c790: cmp             x1, x17
    // 0xd3c794: b.ne            #0xd3c7a8
    // 0xd3c798: LoadField: r1 = r3->field_2b
    //     0xd3c798: ldur            w1, [x3, #0x2b]
    // 0xd3c79c: DecompressPointer r1
    //     0xd3c79c: add             x1, x1, HEAP, lsl #32
    // 0xd3c7a0: mov             x0, x1
    // 0xd3c7a4: b               #0xd3c84c
    // 0xd3c7a8: r17 = 5070
    //     0xd3c7a8: mov             x17, #0x13ce
    // 0xd3c7ac: cmp             x1, x17
    // 0xd3c7b0: b.eq            #0xd3d3dc
    // 0xd3c7b4: r17 = 5071
    //     0xd3c7b4: mov             x17, #0x13cf
    // 0xd3c7b8: cmp             x1, x17
    // 0xd3c7bc: b.ne            #0xd3c80c
    // 0xd3c7c0: mov             x1, x3
    // 0xd3c7c4: LoadField: r0 = r1->field_9b
    //     0xd3c7c4: ldur            w0, [x1, #0x9b]
    // 0xd3c7c8: DecompressPointer r0
    //     0xd3c7c8: add             x0, x0, HEAP, lsl #32
    // 0xd3c7cc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3c7d0: cmp             w0, w16
    // 0xd3c7d4: b.ne            #0xd3c7e4
    // 0xd3c7d8: r2 = _colors
    //     0xd3c7d8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0xd3c7dc: ldr             x2, [x2, #0xa10]
    // 0xd3c7e0: r0 = InitLateFinalInstanceField()
    //     0xd3c7e0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3c7e4: LoadField: r1 = r0->field_7f
    //     0xd3c7e4: ldur            w1, [x0, #0x7f]
    // 0xd3c7e8: DecompressPointer r1
    //     0xd3c7e8: add             x1, x1, HEAP, lsl #32
    // 0xd3c7ec: r0 = LoadClassIdInstr(r1)
    //     0xd3c7ec: ldur            x0, [x1, #-1]
    //     0xd3c7f0: ubfx            x0, x0, #0xc, #0x14
    // 0xd3c7f4: d0 = 0.380000
    //     0xd3c7f4: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xd3c7f8: ldr             d0, [x17, #0x1f0]
    // 0xd3c7fc: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd3c7fc: sub             lr, x0, #1, lsl #12
    //     0xd3c800: ldr             lr, [x21, lr, lsl #3]
    //     0xd3c804: blr             lr
    // 0xd3c808: b               #0xd3c84c
    // 0xd3c80c: ldur            x1, [fp, #-0x20]
    // 0xd3c810: LoadField: r0 = r1->field_9b
    //     0xd3c810: ldur            w0, [x1, #0x9b]
    // 0xd3c814: DecompressPointer r0
    //     0xd3c814: add             x0, x0, HEAP, lsl #32
    // 0xd3c818: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3c81c: cmp             w0, w16
    // 0xd3c820: b.ne            #0xd3c830
    // 0xd3c824: r2 = _colors
    //     0xd3c824: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0xd3c828: ldr             x2, [x2, #0xa18]
    // 0xd3c82c: r0 = InitLateFinalInstanceField()
    //     0xd3c82c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3c830: LoadField: r1 = r0->field_f
    //     0xd3c830: ldur            w1, [x0, #0xf]
    // 0xd3c834: DecompressPointer r1
    //     0xd3c834: add             x1, x1, HEAP, lsl #32
    // 0xd3c838: d0 = 0.120000
    //     0xd3c838: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xd3c83c: ldr             d0, [x17, #0xc40]
    // 0xd3c840: r0 = withOpacity()
    //     0xd3c840: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xd3c844: b               #0xd3c84c
    // 0xd3c848: mov             x0, x3
    // 0xd3c84c: ldur            x2, [fp, #-0x18]
    // 0xd3c850: stur            x0, [fp, #-0xa0]
    // 0xd3c854: ArrayLoad: r1 = r2[0]  ; List_4
    //     0xd3c854: ldur            w1, [x2, #0x17]
    // 0xd3c858: DecompressPointer r1
    //     0xd3c858: add             x1, x1, HEAP, lsl #32
    // 0xd3c85c: LoadField: r3 = r1->field_2f
    //     0xd3c85c: ldur            w3, [x1, #0x2f]
    // 0xd3c860: DecompressPointer r3
    //     0xd3c860: add             x3, x3, HEAP, lsl #32
    // 0xd3c864: cmp             w3, NULL
    // 0xd3c868: b.ne            #0xd3c948
    // 0xd3c86c: ldur            x3, [fp, #-0x20]
    // 0xd3c870: r1 = LoadClassIdInstr(r3)
    //     0xd3c870: ldur            x1, [x3, #-1]
    //     0xd3c874: ubfx            x1, x1, #0xc, #0x14
    // 0xd3c878: r17 = 5069
    //     0xd3c878: mov             x17, #0x13cd
    // 0xd3c87c: cmp             x1, x17
    // 0xd3c880: b.ne            #0xd3c894
    // 0xd3c884: LoadField: r1 = r3->field_2f
    //     0xd3c884: ldur            w1, [x3, #0x2f]
    // 0xd3c888: DecompressPointer r1
    //     0xd3c888: add             x1, x1, HEAP, lsl #32
    // 0xd3c88c: mov             x0, x1
    // 0xd3c890: b               #0xd3c940
    // 0xd3c894: r17 = 5070
    //     0xd3c894: mov             x17, #0x13ce
    // 0xd3c898: cmp             x1, x17
    // 0xd3c89c: b.eq            #0xd3d410
    // 0xd3c8a0: r17 = 5071
    //     0xd3c8a0: mov             x17, #0x13cf
    // 0xd3c8a4: cmp             x1, x17
    // 0xd3c8a8: b.ne            #0xd3c8f8
    // 0xd3c8ac: mov             x1, x3
    // 0xd3c8b0: LoadField: r0 = r1->field_9b
    //     0xd3c8b0: ldur            w0, [x1, #0x9b]
    // 0xd3c8b4: DecompressPointer r0
    //     0xd3c8b4: add             x0, x0, HEAP, lsl #32
    // 0xd3c8b8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3c8bc: cmp             w0, w16
    // 0xd3c8c0: b.ne            #0xd3c8d0
    // 0xd3c8c4: r2 = _colors
    //     0xd3c8c4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0xd3c8c8: ldr             x2, [x2, #0xa10]
    // 0xd3c8cc: r0 = InitLateFinalInstanceField()
    //     0xd3c8cc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3c8d0: LoadField: r1 = r0->field_7f
    //     0xd3c8d0: ldur            w1, [x0, #0x7f]
    // 0xd3c8d4: DecompressPointer r1
    //     0xd3c8d4: add             x1, x1, HEAP, lsl #32
    // 0xd3c8d8: r0 = LoadClassIdInstr(r1)
    //     0xd3c8d8: ldur            x0, [x1, #-1]
    //     0xd3c8dc: ubfx            x0, x0, #0xc, #0x14
    // 0xd3c8e0: d0 = 0.380000
    //     0xd3c8e0: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xd3c8e4: ldr             d0, [x17, #0x1f0]
    // 0xd3c8e8: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd3c8e8: sub             lr, x0, #1, lsl #12
    //     0xd3c8ec: ldr             lr, [x21, lr, lsl #3]
    //     0xd3c8f0: blr             lr
    // 0xd3c8f4: b               #0xd3c940
    // 0xd3c8f8: ldur            x1, [fp, #-0x20]
    // 0xd3c8fc: LoadField: r0 = r1->field_9b
    //     0xd3c8fc: ldur            w0, [x1, #0x9b]
    // 0xd3c900: DecompressPointer r0
    //     0xd3c900: add             x0, x0, HEAP, lsl #32
    // 0xd3c904: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3c908: cmp             w0, w16
    // 0xd3c90c: b.ne            #0xd3c91c
    // 0xd3c910: r2 = _colors
    //     0xd3c910: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0xd3c914: ldr             x2, [x2, #0xa18]
    // 0xd3c918: r0 = InitLateFinalInstanceField()
    //     0xd3c918: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3c91c: LoadField: r1 = r0->field_7f
    //     0xd3c91c: ldur            w1, [x0, #0x7f]
    // 0xd3c920: DecompressPointer r1
    //     0xd3c920: add             x1, x1, HEAP, lsl #32
    // 0xd3c924: r0 = LoadClassIdInstr(r1)
    //     0xd3c924: ldur            x0, [x1, #-1]
    //     0xd3c928: ubfx            x0, x0, #0xc, #0x14
    // 0xd3c92c: d0 = 0.120000
    //     0xd3c92c: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xd3c930: ldr             d0, [x17, #0xc40]
    // 0xd3c934: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd3c934: sub             lr, x0, #1, lsl #12
    //     0xd3c938: ldr             lr, [x21, lr, lsl #3]
    //     0xd3c93c: blr             lr
    // 0xd3c940: mov             x2, x0
    // 0xd3c944: b               #0xd3c94c
    // 0xd3c948: mov             x2, x3
    // 0xd3c94c: ldur            x0, [fp, #-8]
    // 0xd3c950: stur            x2, [fp, #-0xa8]
    // 0xd3c954: LoadField: r1 = r0->field_b
    //     0xd3c954: ldur            w1, [x0, #0xb]
    // 0xd3c958: DecompressPointer r1
    //     0xd3c958: add             x1, x1, HEAP, lsl #32
    // 0xd3c95c: cmp             w1, NULL
    // 0xd3c960: b.eq            #0xd3d4d4
    // 0xd3c964: LoadField: r3 = r1->field_3f
    //     0xd3c964: ldur            w3, [x1, #0x3f]
    // 0xd3c968: DecompressPointer r3
    //     0xd3c968: add             x3, x3, HEAP, lsl #32
    // 0xd3c96c: cmp             w3, NULL
    // 0xd3c970: b.ne            #0xd3c990
    // 0xd3c974: ldur            x4, [fp, #-0x18]
    // 0xd3c978: ArrayLoad: r1 = r4[0]  ; List_4
    //     0xd3c978: ldur            w1, [x4, #0x17]
    // 0xd3c97c: DecompressPointer r1
    //     0xd3c97c: add             x1, x1, HEAP, lsl #32
    // 0xd3c980: LoadField: r3 = r1->field_33
    //     0xd3c980: ldur            w3, [x1, #0x33]
    // 0xd3c984: DecompressPointer r3
    //     0xd3c984: add             x3, x3, HEAP, lsl #32
    // 0xd3c988: mov             x1, x3
    // 0xd3c98c: b               #0xd3c998
    // 0xd3c990: ldur            x4, [fp, #-0x18]
    // 0xd3c994: mov             x1, x3
    // 0xd3c998: cmp             w1, NULL
    // 0xd3c99c: b.ne            #0xd3ca48
    // 0xd3c9a0: ldur            x3, [fp, #-0x20]
    // 0xd3c9a4: r1 = LoadClassIdInstr(r3)
    //     0xd3c9a4: ldur            x1, [x3, #-1]
    //     0xd3c9a8: ubfx            x1, x1, #0xc, #0x14
    // 0xd3c9ac: r17 = 5069
    //     0xd3c9ac: mov             x17, #0x13cd
    // 0xd3c9b0: cmp             x1, x17
    // 0xd3c9b4: b.ne            #0xd3c9c8
    // 0xd3c9b8: LoadField: r1 = r3->field_33
    //     0xd3c9b8: ldur            w1, [x3, #0x33]
    // 0xd3c9bc: DecompressPointer r1
    //     0xd3c9bc: add             x1, x1, HEAP, lsl #32
    // 0xd3c9c0: mov             x0, x1
    // 0xd3c9c4: b               #0xd3ca4c
    // 0xd3c9c8: r17 = 5070
    //     0xd3c9c8: mov             x17, #0x13ce
    // 0xd3c9cc: cmp             x1, x17
    // 0xd3c9d0: b.eq            #0xd3d444
    // 0xd3c9d4: r17 = 5071
    //     0xd3c9d4: mov             x17, #0x13cf
    // 0xd3c9d8: cmp             x1, x17
    // 0xd3c9dc: b.ne            #0xd3ca14
    // 0xd3c9e0: mov             x1, x3
    // 0xd3c9e4: LoadField: r0 = r1->field_9b
    //     0xd3c9e4: ldur            w0, [x1, #0x9b]
    // 0xd3c9e8: DecompressPointer r0
    //     0xd3c9e8: add             x0, x0, HEAP, lsl #32
    // 0xd3c9ec: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3c9f0: cmp             w0, w16
    // 0xd3c9f4: b.ne            #0xd3ca04
    // 0xd3c9f8: r2 = _colors
    //     0xd3c9f8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0xd3c9fc: ldr             x2, [x2, #0xa10]
    // 0xd3ca00: r0 = InitLateFinalInstanceField()
    //     0xd3ca00: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3ca04: LoadField: r1 = r0->field_b
    //     0xd3ca04: ldur            w1, [x0, #0xb]
    // 0xd3ca08: DecompressPointer r1
    //     0xd3ca08: add             x1, x1, HEAP, lsl #32
    // 0xd3ca0c: mov             x0, x1
    // 0xd3ca10: b               #0xd3ca4c
    // 0xd3ca14: ldur            x1, [fp, #-0x20]
    // 0xd3ca18: LoadField: r0 = r1->field_9b
    //     0xd3ca18: ldur            w0, [x1, #0x9b]
    // 0xd3ca1c: DecompressPointer r0
    //     0xd3ca1c: add             x0, x0, HEAP, lsl #32
    // 0xd3ca20: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3ca24: cmp             w0, w16
    // 0xd3ca28: b.ne            #0xd3ca38
    // 0xd3ca2c: r2 = _colors
    //     0xd3ca2c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0xd3ca30: ldr             x2, [x2, #0xa18]
    // 0xd3ca34: r0 = InitLateFinalInstanceField()
    //     0xd3ca34: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3ca38: LoadField: r1 = r0->field_b
    //     0xd3ca38: ldur            w1, [x0, #0xb]
    // 0xd3ca3c: DecompressPointer r1
    //     0xd3ca3c: add             x1, x1, HEAP, lsl #32
    // 0xd3ca40: mov             x0, x1
    // 0xd3ca44: b               #0xd3ca4c
    // 0xd3ca48: mov             x0, x1
    // 0xd3ca4c: ldur            x2, [fp, #-0x18]
    // 0xd3ca50: stur            x0, [fp, #-0xb0]
    // 0xd3ca54: ArrayLoad: r1 = r2[0]  ; List_4
    //     0xd3ca54: ldur            w1, [x2, #0x17]
    // 0xd3ca58: DecompressPointer r1
    //     0xd3ca58: add             x1, x1, HEAP, lsl #32
    // 0xd3ca5c: LoadField: r3 = r1->field_3b
    //     0xd3ca5c: ldur            w3, [x1, #0x3b]
    // 0xd3ca60: DecompressPointer r3
    //     0xd3ca60: add             x3, x3, HEAP, lsl #32
    // 0xd3ca64: cmp             w3, NULL
    // 0xd3ca68: b.ne            #0xd3cb8c
    // 0xd3ca6c: ldur            x3, [fp, #-0x20]
    // 0xd3ca70: r1 = LoadClassIdInstr(r3)
    //     0xd3ca70: ldur            x1, [x3, #-1]
    //     0xd3ca74: ubfx            x1, x1, #0xc, #0x14
    // 0xd3ca78: r17 = 5069
    //     0xd3ca78: mov             x17, #0x13cd
    // 0xd3ca7c: cmp             x1, x17
    // 0xd3ca80: b.ne            #0xd3ca94
    // 0xd3ca84: LoadField: r1 = r3->field_3b
    //     0xd3ca84: ldur            w1, [x3, #0x3b]
    // 0xd3ca88: DecompressPointer r1
    //     0xd3ca88: add             x1, x1, HEAP, lsl #32
    // 0xd3ca8c: mov             x0, x1
    // 0xd3ca90: b               #0xd3cb84
    // 0xd3ca94: r17 = 5070
    //     0xd3ca94: mov             x17, #0x13ce
    // 0xd3ca98: cmp             x1, x17
    // 0xd3ca9c: b.eq            #0xd3d478
    // 0xd3caa0: r17 = 5071
    //     0xd3caa0: mov             x17, #0x13cf
    // 0xd3caa4: cmp             x1, x17
    // 0xd3caa8: b.ne            #0xd3cb18
    // 0xd3caac: mov             x1, x3
    // 0xd3cab0: LoadField: r0 = r1->field_9b
    //     0xd3cab0: ldur            w0, [x1, #0x9b]
    // 0xd3cab4: DecompressPointer r0
    //     0xd3cab4: add             x0, x0, HEAP, lsl #32
    // 0xd3cab8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3cabc: cmp             w0, w16
    // 0xd3cac0: b.ne            #0xd3cad0
    // 0xd3cac4: r2 = _colors
    //     0xd3cac4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a10] Field <_SliderDefaultsM3Year2023@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0xd3cac8: ldr             x2, [x2, #0xa10]
    // 0xd3cacc: r0 = InitLateFinalInstanceField()
    //     0xd3cacc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3cad0: LoadField: r1 = r0->field_7f
    //     0xd3cad0: ldur            w1, [x0, #0x7f]
    // 0xd3cad4: DecompressPointer r1
    //     0xd3cad4: add             x1, x1, HEAP, lsl #32
    // 0xd3cad8: r0 = LoadClassIdInstr(r1)
    //     0xd3cad8: ldur            x0, [x1, #-1]
    //     0xd3cadc: ubfx            x0, x0, #0xc, #0x14
    // 0xd3cae0: d0 = 0.380000
    //     0xd3cae0: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xd3cae4: ldr             d0, [x17, #0x1f0]
    // 0xd3cae8: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd3cae8: sub             lr, x0, #1, lsl #12
    //     0xd3caec: ldr             lr, [x21, lr, lsl #3]
    //     0xd3caf0: blr             lr
    // 0xd3caf4: mov             x1, x0
    // 0xd3caf8: ldur            x0, [fp, #-0x20]
    // 0xd3cafc: LoadField: r2 = r0->field_9b
    //     0xd3cafc: ldur            w2, [x0, #0x9b]
    // 0xd3cb00: DecompressPointer r2
    //     0xd3cb00: add             x2, x2, HEAP, lsl #32
    // 0xd3cb04: LoadField: r3 = r2->field_7b
    //     0xd3cb04: ldur            w3, [x2, #0x7b]
    // 0xd3cb08: DecompressPointer r3
    //     0xd3cb08: add             x3, x3, HEAP, lsl #32
    // 0xd3cb0c: mov             x2, x3
    // 0xd3cb10: r0 = alphaBlend()
    //     0xd3cb10: bl              #0xb6ea90  ; [dart:ui] Color::alphaBlend
    // 0xd3cb14: b               #0xd3cb84
    // 0xd3cb18: mov             x0, x3
    // 0xd3cb1c: mov             x1, x0
    // 0xd3cb20: LoadField: r0 = r1->field_9b
    //     0xd3cb20: ldur            w0, [x1, #0x9b]
    // 0xd3cb24: DecompressPointer r0
    //     0xd3cb24: add             x0, x0, HEAP, lsl #32
    // 0xd3cb28: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3cb2c: cmp             w0, w16
    // 0xd3cb30: b.ne            #0xd3cb40
    // 0xd3cb34: r2 = _colors
    //     0xd3cb34: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0xd3cb38: ldr             x2, [x2, #0xa18]
    // 0xd3cb3c: r0 = InitLateFinalInstanceField()
    //     0xd3cb3c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3cb40: LoadField: r1 = r0->field_7f
    //     0xd3cb40: ldur            w1, [x0, #0x7f]
    // 0xd3cb44: DecompressPointer r1
    //     0xd3cb44: add             x1, x1, HEAP, lsl #32
    // 0xd3cb48: r0 = LoadClassIdInstr(r1)
    //     0xd3cb48: ldur            x0, [x1, #-1]
    //     0xd3cb4c: ubfx            x0, x0, #0xc, #0x14
    // 0xd3cb50: d0 = 0.380000
    //     0xd3cb50: add             x17, PP, #0x26, lsl #12  ; [pp+0x261f0] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xd3cb54: ldr             d0, [x17, #0x1f0]
    // 0xd3cb58: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd3cb58: sub             lr, x0, #1, lsl #12
    //     0xd3cb5c: ldr             lr, [x21, lr, lsl #3]
    //     0xd3cb60: blr             lr
    // 0xd3cb64: mov             x1, x0
    // 0xd3cb68: ldur            x0, [fp, #-0x20]
    // 0xd3cb6c: LoadField: r2 = r0->field_9b
    //     0xd3cb6c: ldur            w2, [x0, #0x9b]
    // 0xd3cb70: DecompressPointer r2
    //     0xd3cb70: add             x2, x2, HEAP, lsl #32
    // 0xd3cb74: LoadField: r3 = r2->field_7b
    //     0xd3cb74: ldur            w3, [x2, #0x7b]
    // 0xd3cb78: DecompressPointer r3
    //     0xd3cb78: add             x3, x3, HEAP, lsl #32
    // 0xd3cb7c: mov             x2, x3
    // 0xd3cb80: r0 = alphaBlend()
    //     0xd3cb80: bl              #0xb6ea90  ; [dart:ui] Color::alphaBlend
    // 0xd3cb84: mov             x1, x0
    // 0xd3cb88: b               #0xd3cb90
    // 0xd3cb8c: mov             x1, x3
    // 0xd3cb90: ldur            x2, [fp, #-0x18]
    // 0xd3cb94: stur            x1, [fp, #-0xb8]
    // 0xd3cb98: ldur            x16, [fp, #-0x48]
    // 0xd3cb9c: str             x16, [SP]
    // 0xd3cba0: ldur            x0, [fp, #-0x48]
    // 0xd3cba4: ClosureCall
    //     0xd3cba4: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xd3cba8: ldur            x2, [x0, #0x1f]
    //     0xd3cbac: blr             x2
    // 0xd3cbb0: mov             x1, x0
    // 0xd3cbb4: ldur            x0, [fp, #-0x18]
    // 0xd3cbb8: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xd3cbb8: ldur            w2, [x0, #0x17]
    // 0xd3cbbc: DecompressPointer r2
    //     0xd3cbbc: add             x2, x2, HEAP, lsl #32
    // 0xd3cbc0: LoadField: r3 = r2->field_57
    //     0xd3cbc0: ldur            w3, [x2, #0x57]
    // 0xd3cbc4: DecompressPointer r3
    //     0xd3cbc4: add             x3, x3, HEAP, lsl #32
    // 0xd3cbc8: cmp             w3, NULL
    // 0xd3cbcc: b.ne            #0xd3cbd8
    // 0xd3cbd0: r3 = Instance_RoundedRectSliderTrackShape
    //     0xd3cbd0: add             x3, PP, #0x26, lsl #12  ; [pp+0x26a80] Obj!RoundedRectSliderTrackShape@12aa541
    //     0xd3cbd4: ldr             x3, [x3, #0xa80]
    // 0xd3cbd8: LoadField: r4 = r2->field_4f
    //     0xd3cbd8: ldur            w4, [x2, #0x4f]
    // 0xd3cbdc: DecompressPointer r4
    //     0xd3cbdc: add             x4, x4, HEAP, lsl #32
    // 0xd3cbe0: cmp             w4, NULL
    // 0xd3cbe4: b.ne            #0xd3cbf0
    // 0xd3cbe8: r4 = Instance_RoundSliderTickMarkShape
    //     0xd3cbe8: add             x4, PP, #0x26, lsl #12  ; [pp+0x26a60] Obj!RoundSliderTickMarkShape@129e911
    //     0xd3cbec: ldr             x4, [x4, #0xa60]
    // 0xd3cbf0: LoadField: r5 = r2->field_53
    //     0xd3cbf0: ldur            w5, [x2, #0x53]
    // 0xd3cbf4: DecompressPointer r5
    //     0xd3cbf4: add             x5, x5, HEAP, lsl #32
    // 0xd3cbf8: cmp             w5, NULL
    // 0xd3cbfc: b.ne            #0xd3cc08
    // 0xd3cc00: r5 = Instance_RoundSliderThumbShape
    //     0xd3cc00: add             x5, PP, #0x26, lsl #12  ; [pp+0x26a70] Obj!RoundSliderThumbShape@129e8e1
    //     0xd3cc04: ldr             x5, [x5, #0xa70]
    // 0xd3cc08: LoadField: r6 = r2->field_4b
    //     0xd3cc08: ldur            w6, [x2, #0x4b]
    // 0xd3cc0c: DecompressPointer r6
    //     0xd3cc0c: add             x6, x6, HEAP, lsl #32
    // 0xd3cc10: cmp             w6, NULL
    // 0xd3cc14: b.ne            #0xd3cc24
    // 0xd3cc18: r7 = Instance_RoundSliderOverlayShape
    //     0xd3cc18: add             x7, PP, #0x26, lsl #12  ; [pp+0x26a50] Obj!RoundSliderOverlayShape@129e8a1
    //     0xd3cc1c: ldr             x7, [x7, #0xa50]
    // 0xd3cc20: b               #0xd3cc28
    // 0xd3cc24: mov             x7, x6
    // 0xd3cc28: ldur            x6, [fp, #-8]
    // 0xd3cc2c: LoadField: r8 = r6->field_b
    //     0xd3cc2c: ldur            w8, [x6, #0xb]
    // 0xd3cc30: DecompressPointer r8
    //     0xd3cc30: add             x8, x8, HEAP, lsl #32
    // 0xd3cc34: cmp             w8, NULL
    // 0xd3cc38: b.eq            #0xd3d4d8
    // 0xd3cc3c: LoadField: r8 = r2->field_6f
    //     0xd3cc3c: ldur            w8, [x2, #0x6f]
    // 0xd3cc40: DecompressPointer r8
    //     0xd3cc40: add             x8, x8, HEAP, lsl #32
    // 0xd3cc44: cmp             w8, NULL
    // 0xd3cc48: b.ne            #0xd3cc54
    // 0xd3cc4c: r8 = Instance_ShowValueIndicator
    //     0xd3cc4c: add             x8, PP, #0x98, lsl #12  ; [pp+0x98ec8] Obj!ShowValueIndicator@12c4e81
    //     0xd3cc50: ldr             x8, [x8, #0xec8]
    // 0xd3cc54: LoadField: r9 = r2->field_8f
    //     0xd3cc54: ldur            w9, [x2, #0x8f]
    // 0xd3cc58: DecompressPointer r9
    //     0xd3cc58: add             x9, x9, HEAP, lsl #32
    // 0xd3cc5c: cmp             w9, NULL
    // 0xd3cc60: b.ne            #0xd3cc78
    // 0xd3cc64: ldur            x2, [fp, #-0x20]
    // 0xd3cc68: LoadField: r9 = r2->field_8f
    //     0xd3cc68: ldur            w9, [x2, #0x8f]
    // 0xd3cc6c: DecompressPointer r9
    //     0xd3cc6c: add             x9, x9, HEAP, lsl #32
    // 0xd3cc70: mov             x2, x9
    // 0xd3cc74: b               #0xd3cc7c
    // 0xd3cc78: mov             x2, x9
    // 0xd3cc7c: ldur            x9, [fp, #-0x10]
    // 0xd3cc80: ldur            d0, [fp, #-0xc8]
    // 0xd3cc84: r10 = inline_Allocate_Double()
    //     0xd3cc84: ldp             x10, x11, [THR, #0x60]  ; THR::top
    //     0xd3cc88: add             x10, x10, #0x10
    //     0xd3cc8c: cmp             x11, x10
    //     0xd3cc90: b.ls            #0xd3d4dc
    //     0xd3cc94: str             x10, [THR, #0x60]  ; THR::top
    //     0xd3cc98: sub             x10, x10, #0xf
    //     0xd3cc9c: mov             x11, #0xe19c
    //     0xd3cca0: movk            x11, #3, lsl #16
    //     0xd3cca4: stur            x11, [x10, #-1]
    // 0xd3cca8: dmb             ishst
    // 0xd3ccac: StoreField: r10->field_7 = d0
    //     0xd3ccac: stur            d0, [x10, #7]
    // 0xd3ccb0: ldur            x16, [fp, #-0x60]
    // 0xd3ccb4: stp             x16, x10, [SP, #0xa0]
    // 0xd3ccb8: ldur            x16, [fp, #-0x68]
    // 0xd3ccbc: ldur            lr, [fp, #-0x70]
    // 0xd3ccc0: stp             lr, x16, [SP, #0x90]
    // 0xd3ccc4: ldur            x16, [fp, #-0x78]
    // 0xd3ccc8: ldur            lr, [fp, #-0x80]
    // 0xd3cccc: stp             lr, x16, [SP, #0x80]
    // 0xd3ccd0: ldur            x16, [fp, #-0x88]
    // 0xd3ccd4: ldur            lr, [fp, #-0x90]
    // 0xd3ccd8: stp             lr, x16, [SP, #0x70]
    // 0xd3ccdc: ldur            x16, [fp, #-0x98]
    // 0xd3cce0: ldur            lr, [fp, #-0xa0]
    // 0xd3cce4: stp             lr, x16, [SP, #0x60]
    // 0xd3cce8: ldur            x16, [fp, #-0xa8]
    // 0xd3ccec: ldur            lr, [fp, #-0xb0]
    // 0xd3ccf0: stp             lr, x16, [SP, #0x50]
    // 0xd3ccf4: ldur            x16, [fp, #-0xb8]
    // 0xd3ccf8: stp             x1, x16, [SP, #0x40]
    // 0xd3ccfc: ldur            x16, [fp, #-0x38]
    // 0xd3cd00: stp             x3, x16, [SP, #0x30]
    // 0xd3cd04: stp             x5, x4, [SP, #0x20]
    // 0xd3cd08: ldur            x16, [fp, #-0x40]
    // 0xd3cd0c: stp             x16, x7, [SP, #0x10]
    // 0xd3cd10: ldur            x16, [fp, #-0x58]
    // 0xd3cd14: stp             x16, x8, [SP]
    // 0xd3cd18: ldur            x1, [fp, #-0x50]
    // 0xd3cd1c: r4 = const [0, 0x18, 0x16, 0x2, activeTickMarkColor, 0x9, activeTrackColor, 0x3, disabledActiveTickMarkColor, 0xb, disabledActiveTrackColor, 0x6, disabledInactiveTickMarkColor, 0xc, disabledInactiveTrackColor, 0x7, disabledSecondaryActiveTrackColor, 0x8, disabledThumbColor, 0xe, inactiveTickMarkColor, 0xa, inactiveTrackColor, 0x4, overlayColor, 0xf, overlayShape, 0x14, secondaryActiveTrackColor, 0x5, showValueIndicator, 0x16, thumbColor, 0xd, thumbShape, 0x13, tickMarkShape, 0x12, trackHeight, 0x2, trackShape, 0x11, valueIndicatorColor, 0x10, valueIndicatorShape, 0x15, valueIndicatorTextStyle, 0x17, null]
    //     0xd3cd1c: add             x4, PP, #0x98, lsl #12  ; [pp+0x98ed0] List(49) [0, 0x18, 0x16, 0x2, "activeTickMarkColor", 0x9, "activeTrackColor", 0x3, "disabledActiveTickMarkColor", 0xb, "disabledActiveTrackColor", 0x6, "disabledInactiveTickMarkColor", 0xc, "disabledInactiveTrackColor", 0x7, "disabledSecondaryActiveTrackColor", 0x8, "disabledThumbColor", 0xe, "inactiveTickMarkColor", 0xa, "inactiveTrackColor", 0x4, "overlayColor", 0xf, "overlayShape", 0x14, "secondaryActiveTrackColor", 0x5, "showValueIndicator", 0x16, "thumbColor", 0xd, "thumbShape", 0x13, "tickMarkShape", 0x12, "trackHeight", 0x2, "trackShape", 0x11, "valueIndicatorColor", 0x10, "valueIndicatorShape", 0x15, "valueIndicatorTextStyle", 0x17, Null]
    //     0xd3cd20: ldr             x4, [x4, #0xed0]
    // 0xd3cd24: r0 = copyWith()
    //     0xd3cd24: bl              #0xc24850  ; [package:flutter/src/material/slider_theme.dart] SliderThemeData::copyWith
    // 0xd3cd28: ldur            x2, [fp, #-0x18]
    // 0xd3cd2c: ArrayStore: r2[0] = r0  ; List_4
    //     0xd3cd2c: stur            w0, [x2, #0x17]
    //     0xd3cd30: ldurb           w16, [x2, #-1]
    //     0xd3cd34: ldurb           w17, [x0, #-1]
    //     0xd3cd38: and             x16, x17, x16, lsr #2
    //     0xd3cd3c: tst             x16, HEAP, lsr #32
    //     0xd3cd40: b.eq            #0xd3cd48
    //     0xd3cd44: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd3cd48: ldur            x1, [fp, #-8]
    // 0xd3cd4c: LoadField: r0 = r1->field_b
    //     0xd3cd4c: ldur            w0, [x1, #0xb]
    // 0xd3cd50: DecompressPointer r0
    //     0xd3cd50: add             x0, x0, HEAP, lsl #32
    // 0xd3cd54: cmp             w0, NULL
    // 0xd3cd58: b.eq            #0xd3d518
    // 0xd3cd5c: r16 = <MouseCursor?>
    //     0xd3cd5c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15ab8] TypeArguments: <MouseCursor?>
    //     0xd3cd60: ldr             x16, [x16, #0xab8]
    // 0xd3cd64: stp             NULL, x16, [SP, #8]
    // 0xd3cd68: ldur            x16, [fp, #-0x30]
    // 0xd3cd6c: str             x16, [SP]
    // 0xd3cd70: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xd3cd70: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xd3cd74: r0 = resolveAs()
    //     0xd3cd74: bl              #0x8de57c  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveAs
    // 0xd3cd78: ldur            x2, [fp, #-0x30]
    // 0xd3cd7c: r1 = Instance__WidgetStateMouseCursor
    //     0xd3cd7c: add             x1, PP, #0x26, lsl #12  ; [pp+0x261c0] Obj!_WidgetStateMouseCursor@12b3261
    //     0xd3cd80: ldr             x1, [x1, #0x1c0]
    // 0xd3cd84: r0 = resolve()
    //     0xd3cd84: bl              #0x8de794  ; [package:flutter/src/widgets/widget_state.dart] _WidgetStateMouseCursor::resolve
    // 0xd3cd88: mov             x3, x0
    // 0xd3cd8c: ldur            x0, [fp, #-8]
    // 0xd3cd90: stur            x3, [fp, #-0x30]
    // 0xd3cd94: LoadField: r1 = r0->field_b
    //     0xd3cd94: ldur            w1, [x0, #0xb]
    // 0xd3cd98: DecompressPointer r1
    //     0xd3cd98: add             x1, x1, HEAP, lsl #32
    // 0xd3cd9c: cmp             w1, NULL
    // 0xd3cda0: b.eq            #0xd3d51c
    // 0xd3cda4: ldur            x1, [fp, #-0x10]
    // 0xd3cda8: LoadField: r2 = r1->field_23
    //     0xd3cda8: ldur            w2, [x1, #0x23]
    // 0xd3cdac: DecompressPointer r2
    //     0xd3cdac: add             x2, x2, HEAP, lsl #32
    // 0xd3cdb0: LoadField: r1 = r2->field_7
    //     0xd3cdb0: ldur            x1, [x2, #7]
    // 0xd3cdb4: cmp             x1, #2
    // 0xd3cdb8: b.le            #0xd3cdc4
    // 0xd3cdbc: cmp             x1, #4
    // 0xd3cdc0: b.gt            #0xd3cdcc
    // 0xd3cdc4: r0 = Null
    //     0xd3cdc4: mov             x0, NULL
    // 0xd3cdc8: b               #0xd3cddc
    // 0xd3cdcc: ldur            x2, [fp, #-0x18]
    // 0xd3cdd0: r1 = Function '<anonymous closure>':.
    //     0xd3cdd0: add             x1, PP, #0x98, lsl #12  ; [pp+0x98ed8] AnonymousClosure: (0xd3dad8), in [package:flutter/src/material/slider.dart] _SliderState::_buildMaterialSlider (0xd3b97c)
    //     0xd3cdd4: ldr             x1, [x1, #0xed8]
    // 0xd3cdd8: r0 = AllocateClosure()
    //     0xd3cdd8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3cddc: ldur            x2, [fp, #-0x18]
    // 0xd3cde0: stur            x0, [fp, #-0x10]
    // 0xd3cde4: LoadField: r1 = r2->field_13
    //     0xd3cde4: ldur            w1, [x2, #0x13]
    // 0xd3cde8: DecompressPointer r1
    //     0xd3cde8: add             x1, x1, HEAP, lsl #32
    // 0xd3cdec: r0 = navigationModeOf()
    //     0xd3cdec: bl              #0xd3d6c4  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::navigationModeOf
    // 0xd3cdf0: LoadField: r1 = r0->field_7
    //     0xd3cdf0: ldur            x1, [x0, #7]
    // 0xd3cdf4: cmp             x1, #0
    // 0xd3cdf8: b.gt            #0xd3ce08
    // 0xd3cdfc: r0 = _ConstMap len:4
    //     0xd3cdfc: add             x0, PP, #0x98, lsl #12  ; [pp+0x98ee0] Map<ShortcutActivator, Intent>(4)
    //     0xd3ce00: ldr             x0, [x0, #0xee0]
    // 0xd3ce04: b               #0xd3ce10
    // 0xd3ce08: r0 = _ConstMap len:2
    //     0xd3ce08: add             x0, PP, #0x98, lsl #12  ; [pp+0x98ee8] Map<ShortcutActivator, Intent>(2)
    //     0xd3ce0c: ldr             x0, [x0, #0xee8]
    // 0xd3ce10: ldur            x2, [fp, #-0x18]
    // 0xd3ce14: stur            x0, [fp, #-0x38]
    // 0xd3ce18: ArrayLoad: r1 = r2[0]  ; List_4
    //     0xd3ce18: ldur            w1, [x2, #0x17]
    // 0xd3ce1c: DecompressPointer r1
    //     0xd3ce1c: add             x1, x1, HEAP, lsl #32
    // 0xd3ce20: LoadField: r3 = r1->field_73
    //     0xd3ce20: ldur            w3, [x1, #0x73]
    // 0xd3ce24: DecompressPointer r3
    //     0xd3ce24: add             x3, x3, HEAP, lsl #32
    // 0xd3ce28: cmp             w3, NULL
    // 0xd3ce2c: b.ne            #0xd3ce38
    // 0xd3ce30: r1 = Null
    //     0xd3ce30: mov             x1, NULL
    // 0xd3ce34: b               #0xd3ce40
    // 0xd3ce38: LoadField: r1 = r3->field_1f
    //     0xd3ce38: ldur            w1, [x3, #0x1f]
    // 0xd3ce3c: DecompressPointer r1
    //     0xd3ce3c: add             x1, x1, HEAP, lsl #32
    // 0xd3ce40: cmp             w1, NULL
    // 0xd3ce44: b.ne            #0xd3ce50
    // 0xd3ce48: d1 = 14.000000
    //     0xd3ce48: fmov            d1, #14.00000000
    // 0xd3ce4c: b               #0xd3ce58
    // 0xd3ce50: LoadField: d0 = r1->field_7
    //     0xd3ce50: ldur            d0, [x1, #7]
    // 0xd3ce54: mov             v1.16b, v0.16b
    // 0xd3ce58: d0 = 0.000000
    //     0xd3ce58: eor             v0.16b, v0.16b, v0.16b
    // 0xd3ce5c: fcmp            d1, d0
    // 0xd3ce60: b.ne            #0xd3ce68
    // 0xd3ce64: d1 = 14.000000
    //     0xd3ce64: fmov            d1, #14.00000000
    // 0xd3ce68: ldur            x1, [fp, #-0x28]
    // 0xd3ce6c: stur            d1, [fp, #-0xc8]
    // 0xd3ce70: tbnz            w1, #4, #0xd3ceb4
    // 0xd3ce74: LoadField: r1 = r2->field_13
    //     0xd3ce74: ldur            w1, [x2, #0x13]
    // 0xd3ce78: DecompressPointer r1
    //     0xd3ce78: add             x1, x1, HEAP, lsl #32
    // 0xd3ce7c: r0 = textScalerOf()
    //     0xd3ce7c: bl              #0xd16168  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::textScalerOf
    // 0xd3ce80: r1 = LoadClassIdInstr(r0)
    //     0xd3ce80: ldur            x1, [x0, #-1]
    //     0xd3ce84: ubfx            x1, x1, #0xc, #0x14
    // 0xd3ce88: mov             x16, x0
    // 0xd3ce8c: mov             x0, x1
    // 0xd3ce90: mov             x1, x16
    // 0xd3ce94: d0 = 1.300000
    //     0xd3ce94: add             x17, PP, #0x1f, lsl #12  ; [pp+0x1f200] IMM: double(1.3) from 0x3ff4cccccccccccd
    //     0xd3ce98: ldr             d0, [x17, #0x200]
    // 0xd3ce9c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xd3ce9c: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xd3cea0: r0 = GDT[cid_x0 + -0xffa]()
    //     0xd3cea0: sub             lr, x0, #0xffa
    //     0xd3cea4: ldr             lr, [x21, lr, lsl #3]
    //     0xd3cea8: blr             lr
    // 0xd3ceac: mov             x1, x0
    // 0xd3ceb0: b               #0xd3cec4
    // 0xd3ceb4: LoadField: r1 = r2->field_13
    //     0xd3ceb4: ldur            w1, [x2, #0x13]
    // 0xd3ceb8: DecompressPointer r1
    //     0xd3ceb8: add             x1, x1, HEAP, lsl #32
    // 0xd3cebc: r0 = textScalerOf()
    //     0xd3cebc: bl              #0xd16168  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::textScalerOf
    // 0xd3cec0: mov             x1, x0
    // 0xd3cec4: ldur            x3, [fp, #-8]
    // 0xd3cec8: ldur            x2, [fp, #-0x18]
    // 0xd3cecc: ldur            d1, [fp, #-0xc8]
    // 0xd3ced0: r0 = LoadClassIdInstr(r1)
    //     0xd3ced0: ldur            x0, [x1, #-1]
    //     0xd3ced4: ubfx            x0, x0, #0xc, #0x14
    // 0xd3ced8: mov             v0.16b, v1.16b
    // 0xd3cedc: r0 = GDT[cid_x0 + -0x1000]()
    //     0xd3cedc: sub             lr, x0, #1, lsl #12
    //     0xd3cee0: ldr             lr, [x21, lr, lsl #3]
    //     0xd3cee4: blr             lr
    // 0xd3cee8: LoadField: d0 = r0->field_7
    //     0xd3cee8: ldur            d0, [x0, #7]
    // 0xd3ceec: ldur            d1, [fp, #-0xc8]
    // 0xd3cef0: fdiv            d2, d0, d1
    // 0xd3cef4: ldur            x0, [fp, #-8]
    // 0xd3cef8: stur            d2, [fp, #-0xd0]
    // 0xd3cefc: LoadField: r2 = r0->field_53
    //     0xd3cefc: ldur            w2, [x0, #0x53]
    // 0xd3cf00: DecompressPointer r2
    //     0xd3cf00: add             x2, x2, HEAP, lsl #32
    // 0xd3cf04: stur            x2, [fp, #-0x40]
    // 0xd3cf08: LoadField: r3 = r0->field_2f
    //     0xd3cf08: ldur            w3, [x0, #0x2f]
    // 0xd3cf0c: DecompressPointer r3
    //     0xd3cf0c: add             x3, x3, HEAP, lsl #32
    // 0xd3cf10: stur            x3, [fp, #-0x28]
    // 0xd3cf14: LoadField: r1 = r0->field_b
    //     0xd3cf14: ldur            w1, [x0, #0xb]
    // 0xd3cf18: DecompressPointer r1
    //     0xd3cf18: add             x1, x1, HEAP, lsl #32
    // 0xd3cf1c: cmp             w1, NULL
    // 0xd3cf20: b.eq            #0xd3d520
    // 0xd3cf24: LoadField: d0 = r1->field_b
    //     0xd3cf24: ldur            d0, [x1, #0xb]
    // 0xd3cf28: mov             x1, x0
    // 0xd3cf2c: r0 = _convert()
    //     0xd3cf2c: bl              #0xd3d560  ; [package:flutter/src/material/slider.dart] _SliderState::_convert
    // 0xd3cf30: ldur            x2, [fp, #-8]
    // 0xd3cf34: stur            d0, [fp, #-0xc8]
    // 0xd3cf38: LoadField: r0 = r2->field_b
    //     0xd3cf38: ldur            w0, [x2, #0xb]
    // 0xd3cf3c: DecompressPointer r0
    //     0xd3cf3c: add             x0, x0, HEAP, lsl #32
    // 0xd3cf40: cmp             w0, NULL
    // 0xd3cf44: b.eq            #0xd3d524
    // 0xd3cf48: LoadField: r3 = r0->field_33
    //     0xd3cf48: ldur            x3, [x0, #0x33]
    // 0xd3cf4c: stur            x3, [fp, #-0xc0]
    // 0xd3cf50: LoadField: r4 = r0->field_3b
    //     0xd3cf50: ldur            w4, [x0, #0x3b]
    // 0xd3cf54: DecompressPointer r4
    //     0xd3cf54: add             x4, x4, HEAP, lsl #32
    // 0xd3cf58: ldur            x0, [fp, #-0x18]
    // 0xd3cf5c: stur            x4, [fp, #-0x50]
    // 0xd3cf60: ArrayLoad: r5 = r0[0]  ; List_4
    //     0xd3cf60: ldur            w5, [x0, #0x17]
    // 0xd3cf64: DecompressPointer r5
    //     0xd3cf64: add             x5, x5, HEAP, lsl #32
    // 0xd3cf68: stur            x5, [fp, #-0x48]
    // 0xd3cf6c: LoadField: r1 = r0->field_13
    //     0xd3cf6c: ldur            w1, [x0, #0x13]
    // 0xd3cf70: DecompressPointer r1
    //     0xd3cf70: add             x1, x1, HEAP, lsl #32
    // 0xd3cf74: r0 = sizeOf()
    //     0xd3cf74: bl              #0x865078  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::sizeOf
    // 0xd3cf78: mov             x3, x0
    // 0xd3cf7c: ldur            x0, [fp, #-8]
    // 0xd3cf80: stur            x3, [fp, #-0x58]
    // 0xd3cf84: LoadField: r1 = r0->field_b
    //     0xd3cf84: ldur            w1, [x0, #0xb]
    // 0xd3cf88: DecompressPointer r1
    //     0xd3cf88: add             x1, x1, HEAP, lsl #32
    // 0xd3cf8c: cmp             w1, NULL
    // 0xd3cf90: b.eq            #0xd3d528
    // 0xd3cf94: LoadField: d0 = r1->field_2b
    //     0xd3cf94: ldur            d0, [x1, #0x2b]
    // 0xd3cf98: d1 = 0.000000
    //     0xd3cf98: eor             v1.16b, v1.16b, v1.16b
    // 0xd3cf9c: fcmp            d0, d1
    // 0xd3cfa0: b.le            #0xd3cfbc
    // 0xd3cfa4: mov             x2, x0
    // 0xd3cfa8: r1 = Function '_handleChanged@125231897':.
    //     0xd3cfa8: add             x1, PP, #0x98, lsl #12  ; [pp+0x98ef0] AnonymousClosure: (0xbf9550), in [package:flutter/src/material/slider.dart] _SliderState::_handleChanged (0xbf966c)
    //     0xd3cfac: ldr             x1, [x1, #0xef0]
    // 0xd3cfb0: r0 = AllocateClosure()
    //     0xd3cfb0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3cfb4: mov             x10, x0
    // 0xd3cfb8: b               #0xd3cfc0
    // 0xd3cfbc: r10 = Null
    //     0xd3cfbc: mov             x10, NULL
    // 0xd3cfc0: ldur            x2, [fp, #-8]
    // 0xd3cfc4: ldur            x8, [fp, #-0x10]
    // 0xd3cfc8: ldur            x7, [fp, #-0x38]
    // 0xd3cfcc: ldur            d1, [fp, #-0xd0]
    // 0xd3cfd0: ldur            x5, [fp, #-0x40]
    // 0xd3cfd4: ldur            x6, [fp, #-0x28]
    // 0xd3cfd8: ldur            d0, [fp, #-0xc8]
    // 0xd3cfdc: ldur            x1, [fp, #-0xc0]
    // 0xd3cfe0: ldur            x3, [fp, #-0x50]
    // 0xd3cfe4: ldur            x4, [fp, #-0x48]
    // 0xd3cfe8: ldur            x9, [fp, #-0x30]
    // 0xd3cfec: ldur            x0, [fp, #-0x58]
    // 0xd3cff0: stur            x10, [fp, #-0x70]
    // 0xd3cff4: LoadField: r11 = r2->field_4b
    //     0xd3cff4: ldur            w11, [x2, #0x4b]
    // 0xd3cff8: DecompressPointer r11
    //     0xd3cff8: add             x11, x11, HEAP, lsl #32
    // 0xd3cffc: stur            x11, [fp, #-0x68]
    // 0xd3d000: LoadField: r12 = r2->field_4f
    //     0xd3d000: ldur            w12, [x2, #0x4f]
    // 0xd3d004: DecompressPointer r12
    //     0xd3d004: add             x12, x12, HEAP, lsl #32
    // 0xd3d008: stur            x12, [fp, #-0x60]
    // 0xd3d00c: r0 = _SliderRenderObjectWidget()
    //     0xd3d00c: bl              #0xd3d554  ; Allocate_SliderRenderObjectWidgetStub -> _SliderRenderObjectWidget (size=0x58)
    // 0xd3d010: ldur            d0, [fp, #-0xc8]
    // 0xd3d014: stur            x0, [fp, #-0x78]
    // 0xd3d018: StoreField: r0->field_b = d0
    //     0xd3d018: stur            d0, [x0, #0xb]
    // 0xd3d01c: ldur            x1, [fp, #-0xc0]
    // 0xd3d020: ArrayStore: r0[0] = r1  ; List_8
    //     0xd3d020: stur            x1, [x0, #0x17]
    // 0xd3d024: ldur            x1, [fp, #-0x50]
    // 0xd3d028: StoreField: r0->field_1f = r1
    //     0xd3d028: stur            w1, [x0, #0x1f]
    // 0xd3d02c: ldur            x1, [fp, #-0x48]
    // 0xd3d030: StoreField: r0->field_23 = r1
    //     0xd3d030: stur            w1, [x0, #0x23]
    // 0xd3d034: ldur            d0, [fp, #-0xd0]
    // 0xd3d038: StoreField: r0->field_27 = d0
    //     0xd3d038: stur            d0, [x0, #0x27]
    // 0xd3d03c: ldur            x1, [fp, #-0x58]
    // 0xd3d040: StoreField: r0->field_2f = r1
    //     0xd3d040: stur            w1, [x0, #0x2f]
    // 0xd3d044: ldur            x1, [fp, #-0x70]
    // 0xd3d048: StoreField: r0->field_33 = r1
    //     0xd3d048: stur            w1, [x0, #0x33]
    // 0xd3d04c: ldur            x2, [fp, #-8]
    // 0xd3d050: r1 = Function '_handleDragStart@125231897':.
    //     0xd3d050: add             x1, PP, #0x98, lsl #12  ; [pp+0x98ef8] AnonymousClosure: (0xbf958c), in [package:flutter/src/material/slider.dart] _SliderState::_handleDragStart (0xbf98d0)
    //     0xd3d054: ldr             x1, [x1, #0xef8]
    // 0xd3d058: r0 = AllocateClosure()
    //     0xd3d058: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3d05c: mov             x1, x0
    // 0xd3d060: ldur            x0, [fp, #-0x78]
    // 0xd3d064: StoreField: r0->field_37 = r1
    //     0xd3d064: stur            w1, [x0, #0x37]
    // 0xd3d068: ldur            x2, [fp, #-8]
    // 0xd3d06c: r1 = Function '_handleDragEnd@125231897':.
    //     0xd3d06c: add             x1, PP, #0x98, lsl #12  ; [pp+0x98f00] AnonymousClosure: (0xbf9514), in [package:flutter/src/material/slider.dart] _SliderState::_handleDragEnd (0xbf95c8)
    //     0xd3d070: ldr             x1, [x1, #0xf00]
    // 0xd3d074: r0 = AllocateClosure()
    //     0xd3d074: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3d078: mov             x1, x0
    // 0xd3d07c: ldur            x0, [fp, #-0x78]
    // 0xd3d080: StoreField: r0->field_3b = r1
    //     0xd3d080: stur            w1, [x0, #0x3b]
    // 0xd3d084: ldur            x1, [fp, #-8]
    // 0xd3d088: StoreField: r0->field_47 = r1
    //     0xd3d088: stur            w1, [x0, #0x47]
    // 0xd3d08c: ldur            x2, [fp, #-0x10]
    // 0xd3d090: StoreField: r0->field_43 = r2
    //     0xd3d090: stur            w2, [x0, #0x43]
    // 0xd3d094: ldur            x2, [fp, #-0x68]
    // 0xd3d098: StoreField: r0->field_4b = r2
    //     0xd3d098: stur            w2, [x0, #0x4b]
    // 0xd3d09c: ldur            x2, [fp, #-0x60]
    // 0xd3d0a0: StoreField: r0->field_4f = r2
    //     0xd3d0a0: stur            w2, [x0, #0x4f]
    // 0xd3d0a4: r2 = Instance_SliderInteraction
    //     0xd3d0a4: add             x2, PP, #0x98, lsl #12  ; [pp+0x98f08] Obj!SliderInteraction@12c4f41
    //     0xd3d0a8: ldr             x2, [x2, #0xf08]
    // 0xd3d0ac: StoreField: r0->field_53 = r2
    //     0xd3d0ac: stur            w2, [x0, #0x53]
    // 0xd3d0b0: ldur            x2, [fp, #-0x28]
    // 0xd3d0b4: StoreField: r0->field_7 = r2
    //     0xd3d0b4: stur            w2, [x0, #7]
    // 0xd3d0b8: r0 = CompositedTransformTarget()
    //     0xd3d0b8: bl              #0xd3d548  ; AllocateCompositedTransformTargetStub -> CompositedTransformTarget (size=0x14)
    // 0xd3d0bc: mov             x1, x0
    // 0xd3d0c0: ldur            x0, [fp, #-0x40]
    // 0xd3d0c4: stur            x1, [fp, #-0x28]
    // 0xd3d0c8: StoreField: r1->field_f = r0
    //     0xd3d0c8: stur            w0, [x1, #0xf]
    // 0xd3d0cc: ldur            x0, [fp, #-0x78]
    // 0xd3d0d0: StoreField: r1->field_b = r0
    //     0xd3d0d0: stur            w0, [x1, #0xb]
    // 0xd3d0d4: ldur            x0, [fp, #-8]
    // 0xd3d0d8: LoadField: r2 = r0->field_47
    //     0xd3d0d8: ldur            w2, [x0, #0x47]
    // 0xd3d0dc: DecompressPointer r2
    //     0xd3d0dc: add             x2, x2, HEAP, lsl #32
    // 0xd3d0e0: stur            x2, [fp, #-0x10]
    // 0xd3d0e4: r0 = OverlayPortal()
    //     0xd3d0e4: bl              #0xd3d53c  ; AllocateOverlayPortalStub -> OverlayPortal (size=0x1c)
    // 0xd3d0e8: mov             x3, x0
    // 0xd3d0ec: ldur            x0, [fp, #-0x10]
    // 0xd3d0f0: stur            x3, [fp, #-0x40]
    // 0xd3d0f4: StoreField: r3->field_b = r0
    //     0xd3d0f4: stur            w0, [x3, #0xb]
    // 0xd3d0f8: ldur            x2, [fp, #-0x18]
    // 0xd3d0fc: r1 = Function '<anonymous closure>':.
    //     0xd3d0fc: add             x1, PP, #0x98, lsl #12  ; [pp+0x98f10] AnonymousClosure: (0xd3d9b4), in [package:flutter/src/material/slider.dart] _SliderState::_buildMaterialSlider (0xd3b97c)
    //     0xd3d100: ldr             x1, [x1, #0xf10]
    // 0xd3d104: r0 = AllocateClosure()
    //     0xd3d104: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3d108: mov             x1, x0
    // 0xd3d10c: ldur            x0, [fp, #-0x40]
    // 0xd3d110: StoreField: r0->field_f = r1
    //     0xd3d110: stur            w1, [x0, #0xf]
    // 0xd3d114: r1 = Instance_OverlayChildLocation
    //     0xd3d114: add             x1, PP, #0x98, lsl #12  ; [pp+0x98f18] Obj!OverlayChildLocation@12c2841
    //     0xd3d118: ldr             x1, [x1, #0xf18]
    // 0xd3d11c: ArrayStore: r0[0] = r1  ; List_4
    //     0xd3d11c: stur            w1, [x0, #0x17]
    // 0xd3d120: ldur            x1, [fp, #-0x28]
    // 0xd3d124: StoreField: r0->field_13 = r1
    //     0xd3d124: stur            w1, [x0, #0x13]
    // 0xd3d128: ldur            x2, [fp, #-8]
    // 0xd3d12c: LoadField: r3 = r2->field_33
    //     0xd3d12c: ldur            w3, [x2, #0x33]
    // 0xd3d130: DecompressPointer r3
    //     0xd3d130: add             x3, x3, HEAP, lsl #32
    // 0xd3d134: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3d138: cmp             w3, w16
    // 0xd3d13c: b.eq            #0xd3d52c
    // 0xd3d140: mov             x1, x2
    // 0xd3d144: stur            x3, [fp, #-0x10]
    // 0xd3d148: r0 = focusNode()
    //     0xd3d148: bl              #0xbf9308  ; [package:flutter/src/material/slider.dart] _SliderState::focusNode
    // 0xd3d14c: ldur            x2, [fp, #-8]
    // 0xd3d150: stur            x0, [fp, #-0x18]
    // 0xd3d154: LoadField: r1 = r2->field_b
    //     0xd3d154: ldur            w1, [x2, #0xb]
    // 0xd3d158: DecompressPointer r1
    //     0xd3d158: add             x1, x1, HEAP, lsl #32
    // 0xd3d15c: cmp             w1, NULL
    // 0xd3d160: b.eq            #0xd3d538
    // 0xd3d164: r0 = FocusableActionDetector()
    //     0xd3d164: bl              #0xd11ab4  ; AllocateFocusableActionDetectorStub -> FocusableActionDetector (size=0x40)
    // 0xd3d168: mov             x3, x0
    // 0xd3d16c: r0 = true
    //     0xd3d16c: add             x0, NULL, #0x20  ; true
    // 0xd3d170: stur            x3, [fp, #-0x28]
    // 0xd3d174: StoreField: r3->field_b = r0
    //     0xd3d174: stur            w0, [x3, #0xb]
    // 0xd3d178: ldur            x1, [fp, #-0x18]
    // 0xd3d17c: StoreField: r3->field_f = r1
    //     0xd3d17c: stur            w1, [x3, #0xf]
    // 0xd3d180: r4 = false
    //     0xd3d180: add             x4, NULL, #0x30  ; false
    // 0xd3d184: StoreField: r3->field_13 = r4
    //     0xd3d184: stur            w4, [x3, #0x13]
    // 0xd3d188: ArrayStore: r3[0] = r0  ; List_4
    //     0xd3d188: stur            w0, [x3, #0x17]
    // 0xd3d18c: StoreField: r3->field_1b = r0
    //     0xd3d18c: stur            w0, [x3, #0x1b]
    // 0xd3d190: ldur            x0, [fp, #-0x38]
    // 0xd3d194: StoreField: r3->field_23 = r0
    //     0xd3d194: stur            w0, [x3, #0x23]
    // 0xd3d198: ldur            x0, [fp, #-0x10]
    // 0xd3d19c: StoreField: r3->field_1f = r0
    //     0xd3d19c: stur            w0, [x3, #0x1f]
    // 0xd3d1a0: ldur            x2, [fp, #-8]
    // 0xd3d1a4: r1 = Function '_handleFocusHighlightChanged@125231897':.
    //     0xd3d1a4: add             x1, PP, #0x98, lsl #12  ; [pp+0x98f20] AnonymousClosure: (0xd3d8f8), in [package:flutter/src/material/slider.dart] _SliderState::_handleFocusHighlightChanged (0xd3d934)
    //     0xd3d1a8: ldr             x1, [x1, #0xf20]
    // 0xd3d1ac: r0 = AllocateClosure()
    //     0xd3d1ac: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3d1b0: mov             x1, x0
    // 0xd3d1b4: ldur            x0, [fp, #-0x28]
    // 0xd3d1b8: StoreField: r0->field_27 = r1
    //     0xd3d1b8: stur            w1, [x0, #0x27]
    // 0xd3d1bc: ldur            x2, [fp, #-8]
    // 0xd3d1c0: r1 = Function '_handleHoverChanged@125231897':.
    //     0xd3d1c0: add             x1, PP, #0x98, lsl #12  ; [pp+0x98f28] AnonymousClosure: (0xd3d814), in [package:flutter/src/material/slider.dart] _SliderState::_handleHoverChanged (0xd3d850)
    //     0xd3d1c4: ldr             x1, [x1, #0xf28]
    // 0xd3d1c8: r0 = AllocateClosure()
    //     0xd3d1c8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3d1cc: mov             x1, x0
    // 0xd3d1d0: ldur            x0, [fp, #-0x28]
    // 0xd3d1d4: StoreField: r0->field_2b = r1
    //     0xd3d1d4: stur            w1, [x0, #0x2b]
    // 0xd3d1d8: ldur            x1, [fp, #-0x30]
    // 0xd3d1dc: StoreField: r0->field_33 = r1
    //     0xd3d1dc: stur            w1, [x0, #0x33]
    // 0xd3d1e0: r1 = false
    //     0xd3d1e0: add             x1, NULL, #0x30  ; false
    // 0xd3d1e4: StoreField: r0->field_37 = r1
    //     0xd3d1e4: stur            w1, [x0, #0x37]
    // 0xd3d1e8: ldur            x1, [fp, #-0x40]
    // 0xd3d1ec: StoreField: r0->field_3b = r1
    //     0xd3d1ec: stur            w1, [x0, #0x3b]
    // 0xd3d1f0: LeaveFrame
    //     0xd3d1f0: mov             SP, fp
    //     0xd3d1f4: ldp             fp, lr, [SP], #0x10
    // 0xd3d1f8: ret
    //     0xd3d1f8: ret             
    // 0xd3d1fc: mov             x2, x0
    // 0xd3d200: mov             x1, x2
    // 0xd3d204: LoadField: r0 = r1->field_9b
    //     0xd3d204: ldur            w0, [x1, #0x9b]
    // 0xd3d208: DecompressPointer r0
    //     0xd3d208: add             x0, x0, HEAP, lsl #32
    // 0xd3d20c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3d210: cmp             w0, w16
    // 0xd3d214: b.ne            #0xd3d224
    // 0xd3d218: r2 = _colors
    //     0xd3d218: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0xd3d21c: ldr             x2, [x2, #0xab0]
    // 0xd3d220: r0 = InitLateFinalInstanceField()
    //     0xd3d220: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3d224: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xd3d224: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xd3d228: r0 = Throw()
    //     0xd3d228: bl              #0x13ddb2c  ; ThrowStub
    // 0xd3d22c: brk             #0
    // 0xd3d230: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xd3d230: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xd3d234: r0 = Throw()
    //     0xd3d234: bl              #0x13ddb2c  ; ThrowStub
    // 0xd3d238: brk             #0
    // 0xd3d23c: mov             x2, x5
    // 0xd3d240: mov             x1, x2
    // 0xd3d244: LoadField: r0 = r1->field_9b
    //     0xd3d244: ldur            w0, [x1, #0x9b]
    // 0xd3d248: DecompressPointer r0
    //     0xd3d248: add             x0, x0, HEAP, lsl #32
    // 0xd3d24c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3d250: cmp             w0, w16
    // 0xd3d254: b.ne            #0xd3d264
    // 0xd3d258: r2 = _colors
    //     0xd3d258: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0xd3d25c: ldr             x2, [x2, #0xab0]
    // 0xd3d260: r0 = InitLateFinalInstanceField()
    //     0xd3d260: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3d264: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xd3d264: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xd3d268: r0 = Throw()
    //     0xd3d268: bl              #0x13ddb2c  ; ThrowStub
    // 0xd3d26c: brk             #0
    // 0xd3d270: mov             x2, x4
    // 0xd3d274: mov             x1, x2
    // 0xd3d278: LoadField: r0 = r1->field_9b
    //     0xd3d278: ldur            w0, [x1, #0x9b]
    // 0xd3d27c: DecompressPointer r0
    //     0xd3d27c: add             x0, x0, HEAP, lsl #32
    // 0xd3d280: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3d284: cmp             w0, w16
    // 0xd3d288: b.ne            #0xd3d298
    // 0xd3d28c: r2 = _colors
    //     0xd3d28c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0xd3d290: ldr             x2, [x2, #0xab0]
    // 0xd3d294: r0 = InitLateFinalInstanceField()
    //     0xd3d294: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3d298: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xd3d298: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xd3d29c: r0 = Throw()
    //     0xd3d29c: bl              #0x13ddb2c  ; ThrowStub
    // 0xd3d2a0: brk             #0
    // 0xd3d2a4: mov             x2, x4
    // 0xd3d2a8: mov             x1, x2
    // 0xd3d2ac: LoadField: r0 = r1->field_9b
    //     0xd3d2ac: ldur            w0, [x1, #0x9b]
    // 0xd3d2b0: DecompressPointer r0
    //     0xd3d2b0: add             x0, x0, HEAP, lsl #32
    // 0xd3d2b4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3d2b8: cmp             w0, w16
    // 0xd3d2bc: b.ne            #0xd3d2cc
    // 0xd3d2c0: r2 = _colors
    //     0xd3d2c0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0xd3d2c4: ldr             x2, [x2, #0xab0]
    // 0xd3d2c8: r0 = InitLateFinalInstanceField()
    //     0xd3d2c8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3d2cc: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xd3d2cc: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xd3d2d0: r0 = Throw()
    //     0xd3d2d0: bl              #0x13ddb2c  ; ThrowStub
    // 0xd3d2d4: brk             #0
    // 0xd3d2d8: mov             x2, x3
    // 0xd3d2dc: mov             x1, x2
    // 0xd3d2e0: LoadField: r0 = r1->field_9b
    //     0xd3d2e0: ldur            w0, [x1, #0x9b]
    // 0xd3d2e4: DecompressPointer r0
    //     0xd3d2e4: add             x0, x0, HEAP, lsl #32
    // 0xd3d2e8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3d2ec: cmp             w0, w16
    // 0xd3d2f0: b.ne            #0xd3d300
    // 0xd3d2f4: r2 = _colors
    //     0xd3d2f4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0xd3d2f8: ldr             x2, [x2, #0xab0]
    // 0xd3d2fc: r0 = InitLateFinalInstanceField()
    //     0xd3d2fc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3d300: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xd3d300: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xd3d304: r0 = Throw()
    //     0xd3d304: bl              #0x13ddb2c  ; ThrowStub
    // 0xd3d308: brk             #0
    // 0xd3d30c: mov             x2, x3
    // 0xd3d310: mov             x1, x2
    // 0xd3d314: LoadField: r0 = r1->field_9b
    //     0xd3d314: ldur            w0, [x1, #0x9b]
    // 0xd3d318: DecompressPointer r0
    //     0xd3d318: add             x0, x0, HEAP, lsl #32
    // 0xd3d31c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3d320: cmp             w0, w16
    // 0xd3d324: b.ne            #0xd3d334
    // 0xd3d328: r2 = _colors
    //     0xd3d328: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0xd3d32c: ldr             x2, [x2, #0xab0]
    // 0xd3d330: r0 = InitLateFinalInstanceField()
    //     0xd3d330: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3d334: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xd3d334: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xd3d338: r0 = Throw()
    //     0xd3d338: bl              #0x13ddb2c  ; ThrowStub
    // 0xd3d33c: brk             #0
    // 0xd3d340: mov             x2, x3
    // 0xd3d344: mov             x1, x2
    // 0xd3d348: LoadField: r0 = r1->field_9b
    //     0xd3d348: ldur            w0, [x1, #0x9b]
    // 0xd3d34c: DecompressPointer r0
    //     0xd3d34c: add             x0, x0, HEAP, lsl #32
    // 0xd3d350: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3d354: cmp             w0, w16
    // 0xd3d358: b.ne            #0xd3d368
    // 0xd3d35c: r2 = _colors
    //     0xd3d35c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0xd3d360: ldr             x2, [x2, #0xab0]
    // 0xd3d364: r0 = InitLateFinalInstanceField()
    //     0xd3d364: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3d368: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xd3d368: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xd3d36c: r0 = Throw()
    //     0xd3d36c: bl              #0x13ddb2c  ; ThrowStub
    // 0xd3d370: brk             #0
    // 0xd3d374: mov             x2, x4
    // 0xd3d378: mov             x1, x2
    // 0xd3d37c: LoadField: r0 = r1->field_9b
    //     0xd3d37c: ldur            w0, [x1, #0x9b]
    // 0xd3d380: DecompressPointer r0
    //     0xd3d380: add             x0, x0, HEAP, lsl #32
    // 0xd3d384: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3d388: cmp             w0, w16
    // 0xd3d38c: b.ne            #0xd3d39c
    // 0xd3d390: r2 = _colors
    //     0xd3d390: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0xd3d394: ldr             x2, [x2, #0xab0]
    // 0xd3d398: r0 = InitLateFinalInstanceField()
    //     0xd3d398: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3d39c: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xd3d39c: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xd3d3a0: r0 = Throw()
    //     0xd3d3a0: bl              #0x13ddb2c  ; ThrowStub
    // 0xd3d3a4: brk             #0
    // 0xd3d3a8: mov             x2, x3
    // 0xd3d3ac: mov             x1, x2
    // 0xd3d3b0: LoadField: r0 = r1->field_9b
    //     0xd3d3b0: ldur            w0, [x1, #0x9b]
    // 0xd3d3b4: DecompressPointer r0
    //     0xd3d3b4: add             x0, x0, HEAP, lsl #32
    // 0xd3d3b8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3d3bc: cmp             w0, w16
    // 0xd3d3c0: b.ne            #0xd3d3d0
    // 0xd3d3c4: r2 = _colors
    //     0xd3d3c4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0xd3d3c8: ldr             x2, [x2, #0xab0]
    // 0xd3d3cc: r0 = InitLateFinalInstanceField()
    //     0xd3d3cc: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3d3d0: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xd3d3d0: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xd3d3d4: r0 = Throw()
    //     0xd3d3d4: bl              #0x13ddb2c  ; ThrowStub
    // 0xd3d3d8: brk             #0
    // 0xd3d3dc: mov             x2, x3
    // 0xd3d3e0: mov             x1, x2
    // 0xd3d3e4: LoadField: r0 = r1->field_9b
    //     0xd3d3e4: ldur            w0, [x1, #0x9b]
    // 0xd3d3e8: DecompressPointer r0
    //     0xd3d3e8: add             x0, x0, HEAP, lsl #32
    // 0xd3d3ec: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3d3f0: cmp             w0, w16
    // 0xd3d3f4: b.ne            #0xd3d404
    // 0xd3d3f8: r2 = _colors
    //     0xd3d3f8: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0xd3d3fc: ldr             x2, [x2, #0xab0]
    // 0xd3d400: r0 = InitLateFinalInstanceField()
    //     0xd3d400: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3d404: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xd3d404: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xd3d408: r0 = Throw()
    //     0xd3d408: bl              #0x13ddb2c  ; ThrowStub
    // 0xd3d40c: brk             #0
    // 0xd3d410: mov             x2, x3
    // 0xd3d414: mov             x1, x2
    // 0xd3d418: LoadField: r0 = r1->field_9b
    //     0xd3d418: ldur            w0, [x1, #0x9b]
    // 0xd3d41c: DecompressPointer r0
    //     0xd3d41c: add             x0, x0, HEAP, lsl #32
    // 0xd3d420: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3d424: cmp             w0, w16
    // 0xd3d428: b.ne            #0xd3d438
    // 0xd3d42c: r2 = _colors
    //     0xd3d42c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0xd3d430: ldr             x2, [x2, #0xab0]
    // 0xd3d434: r0 = InitLateFinalInstanceField()
    //     0xd3d434: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3d438: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xd3d438: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xd3d43c: r0 = Throw()
    //     0xd3d43c: bl              #0x13ddb2c  ; ThrowStub
    // 0xd3d440: brk             #0
    // 0xd3d444: mov             x2, x3
    // 0xd3d448: mov             x1, x2
    // 0xd3d44c: LoadField: r0 = r1->field_9b
    //     0xd3d44c: ldur            w0, [x1, #0x9b]
    // 0xd3d450: DecompressPointer r0
    //     0xd3d450: add             x0, x0, HEAP, lsl #32
    // 0xd3d454: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3d458: cmp             w0, w16
    // 0xd3d45c: b.ne            #0xd3d46c
    // 0xd3d460: r2 = _colors
    //     0xd3d460: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0xd3d464: ldr             x2, [x2, #0xab0]
    // 0xd3d468: r0 = InitLateFinalInstanceField()
    //     0xd3d468: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3d46c: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xd3d46c: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xd3d470: r0 = Throw()
    //     0xd3d470: bl              #0x13ddb2c  ; ThrowStub
    // 0xd3d474: brk             #0
    // 0xd3d478: mov             x2, x3
    // 0xd3d47c: mov             x1, x2
    // 0xd3d480: LoadField: r0 = r1->field_9b
    //     0xd3d480: ldur            w0, [x1, #0x9b]
    // 0xd3d484: DecompressPointer r0
    //     0xd3d484: add             x0, x0, HEAP, lsl #32
    // 0xd3d488: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3d48c: cmp             w0, w16
    // 0xd3d490: b.ne            #0xd3d4a0
    // 0xd3d494: r2 = _colors
    //     0xd3d494: add             x2, PP, #0x26, lsl #12  ; [pp+0x26ab0] Field <_SliderDefaultsM3@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0xd3d498: ldr             x2, [x2, #0xab0]
    // 0xd3d49c: r0 = InitLateFinalInstanceField()
    //     0xd3d49c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3d4a0: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xd3d4a0: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xd3d4a4: r0 = Throw()
    //     0xd3d4a4: bl              #0x13ddb2c  ; ThrowStub
    // 0xd3d4a8: brk             #0
    // 0xd3d4ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd3d4ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd3d4b0: b               #0xd3b9a4
    // 0xd3d4b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd3d4b4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd3d4b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd3d4b8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd3d4bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd3d4bc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd3d4c0: r0 = NullCastErrorSharedWithFPURegs()
    //     0xd3d4c0: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xd3d4c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd3d4c4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd3d4c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd3d4c8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd3d4cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd3d4cc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd3d4d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd3d4d0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd3d4d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd3d4d4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd3d4d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd3d4d8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd3d4dc: SaveReg d0
    //     0xd3d4dc: str             q0, [SP, #-0x10]!
    // 0xd3d4e0: stp             x8, x9, [SP, #-0x10]!
    // 0xd3d4e4: stp             x6, x7, [SP, #-0x10]!
    // 0xd3d4e8: stp             x4, x5, [SP, #-0x10]!
    // 0xd3d4ec: stp             x2, x3, [SP, #-0x10]!
    // 0xd3d4f0: stp             x0, x1, [SP, #-0x10]!
    // 0xd3d4f4: r0 = AllocateDouble()
    //     0xd3d4f4: bl              #0x13df878  ; AllocateDoubleStub
    // 0xd3d4f8: mov             x10, x0
    // 0xd3d4fc: ldp             x0, x1, [SP], #0x10
    // 0xd3d500: ldp             x2, x3, [SP], #0x10
    // 0xd3d504: ldp             x4, x5, [SP], #0x10
    // 0xd3d508: ldp             x6, x7, [SP], #0x10
    // 0xd3d50c: ldp             x8, x9, [SP], #0x10
    // 0xd3d510: RestoreReg d0
    //     0xd3d510: ldr             q0, [SP], #0x10
    // 0xd3d514: b               #0xd3ccac
    // 0xd3d518: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd3d518: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd3d51c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd3d51c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd3d520: r0 = NullCastErrorSharedWithFPURegs()
    //     0xd3d520: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xd3d524: r0 = NullCastErrorSharedWithFPURegs()
    //     0xd3d524: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xd3d528: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd3d528: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd3d52c: r9 = _actionMap
    //     0xd3d52c: add             x9, PP, #0x98, lsl #12  ; [pp+0x98f30] Field <_SliderState@125231897._actionMap@125231897>: late (offset: 0x34)
    //     0xd3d530: ldr             x9, [x9, #0xf30]
    // 0xd3d534: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xd3d534: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xd3d538: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd3d538: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _convert(/* No info */) {
    // ** addr: 0xd3d560, size: 0x58
    // 0xd3d560: EnterFrame
    //     0xd3d560: stp             fp, lr, [SP, #-0x10]!
    //     0xd3d564: mov             fp, SP
    // 0xd3d568: AllocStack(0x8)
    //     0xd3d568: sub             SP, SP, #8
    // 0xd3d56c: SetupParameters(_SliderState this /* r1 => r0, fp-0x8 */)
    //     0xd3d56c: mov             x0, x1
    //     0xd3d570: stur            x1, [fp, #-8]
    // 0xd3d574: CheckStackOverflow
    //     0xd3d574: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd3d578: cmp             SP, x16
    //     0xd3d57c: b.ls            #0xd3d5ac
    // 0xd3d580: mov             x1, x0
    // 0xd3d584: r0 = _unlerp()
    //     0xd3d584: bl              #0xd3d67c  ; [package:flutter/src/material/slider.dart] _SliderState::_unlerp
    // 0xd3d588: ldur            x1, [fp, #-8]
    // 0xd3d58c: LoadField: r0 = r1->field_b
    //     0xd3d58c: ldur            w0, [x1, #0xb]
    // 0xd3d590: DecompressPointer r0
    //     0xd3d590: add             x0, x0, HEAP, lsl #32
    // 0xd3d594: cmp             w0, NULL
    // 0xd3d598: b.eq            #0xd3d5b4
    // 0xd3d59c: r0 = _discretize()
    //     0xd3d59c: bl              #0xd3d5b8  ; [package:flutter/src/material/slider.dart] _SliderState::_discretize
    // 0xd3d5a0: LeaveFrame
    //     0xd3d5a0: mov             SP, fp
    //     0xd3d5a4: ldp             fp, lr, [SP], #0x10
    // 0xd3d5a8: ret
    //     0xd3d5a8: ret             
    // 0xd3d5ac: r0 = StackOverflowSharedWithFPURegs()
    //     0xd3d5ac: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xd3d5b0: b               #0xd3d580
    // 0xd3d5b4: r0 = NullCastErrorSharedWithFPURegs()
    //     0xd3d5b4: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  _ _discretize(/* No info */) {
    // ** addr: 0xd3d5b8, size: 0xc4
    // 0xd3d5b8: EnterFrame
    //     0xd3d5b8: stp             fp, lr, [SP, #-0x10]!
    //     0xd3d5bc: mov             fp, SP
    // 0xd3d5c0: AllocStack(0x8)
    //     0xd3d5c0: sub             SP, SP, #8
    // 0xd3d5c4: LoadField: r19 = r1->field_b
    //     0xd3d5c4: ldur            w19, [x1, #0xb]
    // 0xd3d5c8: DecompressPointer r19
    //     0xd3d5c8: add             x19, x19, HEAP, lsl #32
    // 0xd3d5cc: cmp             w19, NULL
    // 0xd3d5d0: b.eq            #0xd3d65c
    // 0xd3d5d4: LoadField: r20 = r19->field_33
    //     0xd3d5d4: ldur            x20, [x19, #0x33]
    // 0xd3d5d8: scvtf           d1, x20
    // 0xd3d5dc: stur            d1, [fp, #-8]
    // 0xd3d5e0: fmul            d2, d0, d1
    // 0xd3d5e4: mov             v0.16b, v2.16b
    // 0xd3d5e8: stp             fp, lr, [SP, #-0x10]!
    // 0xd3d5ec: mov             fp, SP
    // 0xd3d5f0: CallRuntime_LibcRound(double) -> double
    //     0xd3d5f0: and             SP, SP, #0xfffffffffffffff0
    //     0xd3d5f4: mov             sp, SP
    //     0xd3d5f8: ldr             x16, [THR, #0x770]  ; THR::LibcRound
    //     0xd3d5fc: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xd3d600: blr             x16
    //     0xd3d604: mov             x16, #8
    //     0xd3d608: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xd3d60c: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xd3d610: sub             sp, x16, #1, lsl #12
    //     0xd3d614: mov             SP, fp
    //     0xd3d618: ldp             fp, lr, [SP], #0x10
    // 0xd3d61c: fcmp            d0, d0
    // 0xd3d620: b.vs            #0xd3d660
    // 0xd3d624: fcvtzs          x0, d0
    // 0xd3d628: asr             x16, x0, #0x1e
    // 0xd3d62c: cmp             x16, x0, asr #63
    // 0xd3d630: b.ne            #0xd3d660
    // 0xd3d634: lsl             x0, x0, #1
    // 0xd3d638: r1 = LoadInt32Instr(r0)
    //     0xd3d638: sbfx            x1, x0, #1, #0x1f
    //     0xd3d63c: tbz             w0, #0, #0xd3d644
    //     0xd3d640: ldur            x1, [x0, #7]
    // 0xd3d644: scvtf           d1, x1
    // 0xd3d648: ldur            d2, [fp, #-8]
    // 0xd3d64c: fdiv            d0, d1, d2
    // 0xd3d650: LeaveFrame
    //     0xd3d650: mov             SP, fp
    //     0xd3d654: ldp             fp, lr, [SP], #0x10
    // 0xd3d658: ret
    //     0xd3d658: ret             
    // 0xd3d65c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xd3d65c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xd3d660: SaveReg d0
    //     0xd3d660: str             q0, [SP, #-0x10]!
    // 0xd3d664: r0 = 76
    //     0xd3d664: mov             x0, #0x4c
    // 0xd3d668: r30 = DoubleToIntegerStub
    //     0xd3d668: ldr             lr, [PP, #0x1b70]  ; [pp+0x1b70] Stub: DoubleToInteger (0x7d18e4)
    // 0xd3d66c: LoadField: r30 = r30->field_7
    //     0xd3d66c: ldur            lr, [lr, #7]
    // 0xd3d670: blr             lr
    // 0xd3d674: RestoreReg d0
    //     0xd3d674: ldr             q0, [SP], #0x10
    // 0xd3d678: b               #0xd3d638
  }
  _ _unlerp(/* No info */) {
    // ** addr: 0xd3d67c, size: 0x48
    // 0xd3d67c: d1 = 0.000000
    //     0xd3d67c: eor             v1.16b, v1.16b, v1.16b
    // 0xd3d680: LoadField: r0 = r1->field_b
    //     0xd3d680: ldur            w0, [x1, #0xb]
    // 0xd3d684: DecompressPointer r0
    //     0xd3d684: add             x0, x0, HEAP, lsl #32
    // 0xd3d688: cmp             w0, NULL
    // 0xd3d68c: b.eq            #0xd3d6b8
    // 0xd3d690: LoadField: d2 = r0->field_2b
    //     0xd3d690: ldur            d2, [x0, #0x2b]
    // 0xd3d694: fcmp            d2, d1
    // 0xd3d698: b.le            #0xd3d6b0
    // 0xd3d69c: fsub            d3, d0, d1
    // 0xd3d6a0: fsub            d4, d2, d1
    // 0xd3d6a4: fdiv            d1, d3, d4
    // 0xd3d6a8: mov             v0.16b, v1.16b
    // 0xd3d6ac: b               #0xd3d6b4
    // 0xd3d6b0: d0 = 0.000000
    //     0xd3d6b0: eor             v0.16b, v0.16b, v0.16b
    // 0xd3d6b4: ret
    //     0xd3d6b4: ret             
    // 0xd3d6b8: EnterFrame
    //     0xd3d6b8: stp             fp, lr, [SP, #-0x10]!
    //     0xd3d6bc: mov             fp, SP
    // 0xd3d6c0: r0 = NullCastErrorSharedWithFPURegs()
    //     0xd3d6c0: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  [closure] void _handleHoverChanged(dynamic, bool) {
    // ** addr: 0xd3d814, size: 0x3c
    // 0xd3d814: EnterFrame
    //     0xd3d814: stp             fp, lr, [SP, #-0x10]!
    //     0xd3d818: mov             fp, SP
    // 0xd3d81c: ldr             x0, [fp, #0x18]
    // 0xd3d820: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd3d820: ldur            w1, [x0, #0x17]
    // 0xd3d824: DecompressPointer r1
    //     0xd3d824: add             x1, x1, HEAP, lsl #32
    // 0xd3d828: CheckStackOverflow
    //     0xd3d828: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd3d82c: cmp             SP, x16
    //     0xd3d830: b.ls            #0xd3d848
    // 0xd3d834: ldr             x2, [fp, #0x10]
    // 0xd3d838: r0 = _handleHoverChanged()
    //     0xd3d838: bl              #0xd3d850  ; [package:flutter/src/material/slider.dart] _SliderState::_handleHoverChanged
    // 0xd3d83c: LeaveFrame
    //     0xd3d83c: mov             SP, fp
    //     0xd3d840: ldp             fp, lr, [SP], #0x10
    // 0xd3d844: ret
    //     0xd3d844: ret             
    // 0xd3d848: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd3d848: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd3d84c: b               #0xd3d834
  }
  _ _handleHoverChanged(/* No info */) {
    // ** addr: 0xd3d850, size: 0x80
    // 0xd3d850: EnterFrame
    //     0xd3d850: stp             fp, lr, [SP, #-0x10]!
    //     0xd3d854: mov             fp, SP
    // 0xd3d858: AllocStack(0x10)
    //     0xd3d858: sub             SP, SP, #0x10
    // 0xd3d85c: SetupParameters(_SliderState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xd3d85c: stur            x1, [fp, #-8]
    //     0xd3d860: stur            x2, [fp, #-0x10]
    // 0xd3d864: CheckStackOverflow
    //     0xd3d864: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd3d868: cmp             SP, x16
    //     0xd3d86c: b.ls            #0xd3d8c8
    // 0xd3d870: r1 = 2
    //     0xd3d870: mov             x1, #2
    // 0xd3d874: r0 = AllocateContext()
    //     0xd3d874: bl              #0x13de838  ; AllocateContextStub
    // 0xd3d878: mov             x1, x0
    // 0xd3d87c: ldur            x0, [fp, #-8]
    // 0xd3d880: StoreField: r1->field_f = r0
    //     0xd3d880: stur            w0, [x1, #0xf]
    // 0xd3d884: ldur            x2, [fp, #-0x10]
    // 0xd3d888: StoreField: r1->field_13 = r2
    //     0xd3d888: stur            w2, [x1, #0x13]
    // 0xd3d88c: LoadField: r3 = r0->field_4f
    //     0xd3d88c: ldur            w3, [x0, #0x4f]
    // 0xd3d890: DecompressPointer r3
    //     0xd3d890: add             x3, x3, HEAP, lsl #32
    // 0xd3d894: cmp             w2, w3
    // 0xd3d898: b.eq            #0xd3d8b8
    // 0xd3d89c: mov             x2, x1
    // 0xd3d8a0: r1 = Function '<anonymous closure>':.
    //     0xd3d8a0: add             x1, PP, #0x98, lsl #12  ; [pp+0x98f38] AnonymousClosure: (0xd3d8d0), in [package:flutter/src/material/slider.dart] _SliderState::_handleHoverChanged (0xd3d850)
    //     0xd3d8a4: ldr             x1, [x1, #0xf38]
    // 0xd3d8a8: r0 = AllocateClosure()
    //     0xd3d8a8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3d8ac: ldur            x1, [fp, #-8]
    // 0xd3d8b0: mov             x2, x0
    // 0xd3d8b4: r0 = setState()
    //     0xd3d8b4: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xd3d8b8: r0 = Null
    //     0xd3d8b8: mov             x0, NULL
    // 0xd3d8bc: LeaveFrame
    //     0xd3d8bc: mov             SP, fp
    //     0xd3d8c0: ldp             fp, lr, [SP], #0x10
    // 0xd3d8c4: ret
    //     0xd3d8c4: ret             
    // 0xd3d8c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd3d8c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd3d8cc: b               #0xd3d870
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xd3d8d0, size: 0x28
    // 0xd3d8d0: ldr             x1, [SP]
    // 0xd3d8d4: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xd3d8d4: ldur            w2, [x1, #0x17]
    // 0xd3d8d8: DecompressPointer r2
    //     0xd3d8d8: add             x2, x2, HEAP, lsl #32
    // 0xd3d8dc: LoadField: r1 = r2->field_f
    //     0xd3d8dc: ldur            w1, [x2, #0xf]
    // 0xd3d8e0: DecompressPointer r1
    //     0xd3d8e0: add             x1, x1, HEAP, lsl #32
    // 0xd3d8e4: LoadField: r3 = r2->field_13
    //     0xd3d8e4: ldur            w3, [x2, #0x13]
    // 0xd3d8e8: DecompressPointer r3
    //     0xd3d8e8: add             x3, x3, HEAP, lsl #32
    // 0xd3d8ec: StoreField: r1->field_4f = r3
    //     0xd3d8ec: stur            w3, [x1, #0x4f]
    // 0xd3d8f0: r0 = Null
    //     0xd3d8f0: mov             x0, NULL
    // 0xd3d8f4: ret
    //     0xd3d8f4: ret             
  }
  [closure] void _handleFocusHighlightChanged(dynamic, bool) {
    // ** addr: 0xd3d8f8, size: 0x3c
    // 0xd3d8f8: EnterFrame
    //     0xd3d8f8: stp             fp, lr, [SP, #-0x10]!
    //     0xd3d8fc: mov             fp, SP
    // 0xd3d900: ldr             x0, [fp, #0x18]
    // 0xd3d904: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd3d904: ldur            w1, [x0, #0x17]
    // 0xd3d908: DecompressPointer r1
    //     0xd3d908: add             x1, x1, HEAP, lsl #32
    // 0xd3d90c: CheckStackOverflow
    //     0xd3d90c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd3d910: cmp             SP, x16
    //     0xd3d914: b.ls            #0xd3d92c
    // 0xd3d918: ldr             x2, [fp, #0x10]
    // 0xd3d91c: r0 = _handleFocusHighlightChanged()
    //     0xd3d91c: bl              #0xd3d934  ; [package:flutter/src/material/slider.dart] _SliderState::_handleFocusHighlightChanged
    // 0xd3d920: LeaveFrame
    //     0xd3d920: mov             SP, fp
    //     0xd3d924: ldp             fp, lr, [SP], #0x10
    // 0xd3d928: ret
    //     0xd3d928: ret             
    // 0xd3d92c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd3d92c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd3d930: b               #0xd3d918
  }
  _ _handleFocusHighlightChanged(/* No info */) {
    // ** addr: 0xd3d934, size: 0x80
    // 0xd3d934: EnterFrame
    //     0xd3d934: stp             fp, lr, [SP, #-0x10]!
    //     0xd3d938: mov             fp, SP
    // 0xd3d93c: AllocStack(0x10)
    //     0xd3d93c: sub             SP, SP, #0x10
    // 0xd3d940: SetupParameters(_SliderState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xd3d940: stur            x1, [fp, #-8]
    //     0xd3d944: stur            x2, [fp, #-0x10]
    // 0xd3d948: CheckStackOverflow
    //     0xd3d948: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd3d94c: cmp             SP, x16
    //     0xd3d950: b.ls            #0xd3d9ac
    // 0xd3d954: r1 = 2
    //     0xd3d954: mov             x1, #2
    // 0xd3d958: r0 = AllocateContext()
    //     0xd3d958: bl              #0x13de838  ; AllocateContextStub
    // 0xd3d95c: mov             x1, x0
    // 0xd3d960: ldur            x0, [fp, #-8]
    // 0xd3d964: StoreField: r1->field_f = r0
    //     0xd3d964: stur            w0, [x1, #0xf]
    // 0xd3d968: ldur            x2, [fp, #-0x10]
    // 0xd3d96c: StoreField: r1->field_13 = r2
    //     0xd3d96c: stur            w2, [x1, #0x13]
    // 0xd3d970: LoadField: r3 = r0->field_4b
    //     0xd3d970: ldur            w3, [x0, #0x4b]
    // 0xd3d974: DecompressPointer r3
    //     0xd3d974: add             x3, x3, HEAP, lsl #32
    // 0xd3d978: cmp             w2, w3
    // 0xd3d97c: b.eq            #0xd3d99c
    // 0xd3d980: mov             x2, x1
    // 0xd3d984: r1 = Function '<anonymous closure>':.
    //     0xd3d984: add             x1, PP, #0x98, lsl #12  ; [pp+0x98f40] AnonymousClosure: (0xd11c48), in [dart:mixin_deduplication] _MixinApplication26&State&TickerProviderStateMixin&ToggleableStateMixin::_handleHoverChanged (0xd11b58)
    //     0xd3d988: ldr             x1, [x1, #0xf40]
    // 0xd3d98c: r0 = AllocateClosure()
    //     0xd3d98c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3d990: ldur            x1, [fp, #-8]
    // 0xd3d994: mov             x2, x0
    // 0xd3d998: r0 = setState()
    //     0xd3d998: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xd3d99c: r0 = Null
    //     0xd3d99c: mov             x0, NULL
    // 0xd3d9a0: LeaveFrame
    //     0xd3d9a0: mov             SP, fp
    //     0xd3d9a4: ldp             fp, lr, [SP], #0x10
    // 0xd3d9a8: ret
    //     0xd3d9a8: ret             
    // 0xd3d9ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd3d9ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd3d9b0: b               #0xd3d954
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0xd3d9b4, size: 0x60
    // 0xd3d9b4: EnterFrame
    //     0xd3d9b4: stp             fp, lr, [SP, #-0x10]!
    //     0xd3d9b8: mov             fp, SP
    // 0xd3d9bc: ldr             x0, [fp, #0x18]
    // 0xd3d9c0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd3d9c0: ldur            w1, [x0, #0x17]
    // 0xd3d9c4: DecompressPointer r1
    //     0xd3d9c4: add             x1, x1, HEAP, lsl #32
    // 0xd3d9c8: CheckStackOverflow
    //     0xd3d9c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd3d9cc: cmp             SP, x16
    //     0xd3d9d0: b.ls            #0xd3da08
    // 0xd3d9d4: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xd3d9d4: ldur            w0, [x1, #0x17]
    // 0xd3d9d8: DecompressPointer r0
    //     0xd3d9d8: add             x0, x0, HEAP, lsl #32
    // 0xd3d9dc: LoadField: r2 = r0->field_6f
    //     0xd3d9dc: ldur            w2, [x0, #0x6f]
    // 0xd3d9e0: DecompressPointer r2
    //     0xd3d9e0: add             x2, x2, HEAP, lsl #32
    // 0xd3d9e4: cmp             w2, NULL
    // 0xd3d9e8: b.eq            #0xd3da10
    // 0xd3d9ec: LoadField: r0 = r1->field_f
    //     0xd3d9ec: ldur            w0, [x1, #0xf]
    // 0xd3d9f0: DecompressPointer r0
    //     0xd3d9f0: add             x0, x0, HEAP, lsl #32
    // 0xd3d9f4: mov             x1, x0
    // 0xd3d9f8: r0 = _buildValueIndicator()
    //     0xd3d9f8: bl              #0xd3da14  ; [package:flutter/src/material/slider.dart] _SliderState::_buildValueIndicator
    // 0xd3d9fc: LeaveFrame
    //     0xd3d9fc: mov             SP, fp
    //     0xd3da00: ldp             fp, lr, [SP], #0x10
    // 0xd3da04: ret
    //     0xd3da04: ret             
    // 0xd3da08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd3da08: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd3da0c: b               #0xd3d9d4
    // 0xd3da10: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd3da10: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _buildValueIndicator(/* No info */) {
    // ** addr: 0xd3da14, size: 0x88
    // 0xd3da14: EnterFrame
    //     0xd3da14: stp             fp, lr, [SP, #-0x10]!
    //     0xd3da18: mov             fp, SP
    // 0xd3da1c: AllocStack(0x18)
    //     0xd3da1c: sub             SP, SP, #0x18
    // 0xd3da20: SetupParameters(_SliderState this /* r1 => r1, fp-0x10 */)
    //     0xd3da20: stur            x1, [fp, #-0x10]
    // 0xd3da24: LoadField: r0 = r1->field_53
    //     0xd3da24: ldur            w0, [x1, #0x53]
    // 0xd3da28: DecompressPointer r0
    //     0xd3da28: add             x0, x0, HEAP, lsl #32
    // 0xd3da2c: stur            x0, [fp, #-8]
    // 0xd3da30: r0 = _ValueIndicatorRenderObjectWidget()
    //     0xd3da30: bl              #0xd3daa8  ; Allocate_ValueIndicatorRenderObjectWidgetStub -> _ValueIndicatorRenderObjectWidget (size=0x10)
    // 0xd3da34: mov             x1, x0
    // 0xd3da38: ldur            x0, [fp, #-0x10]
    // 0xd3da3c: stur            x1, [fp, #-0x18]
    // 0xd3da40: StoreField: r1->field_b = r0
    //     0xd3da40: stur            w0, [x1, #0xb]
    // 0xd3da44: r0 = CompositedTransformFollower()
    //     0xd3da44: bl              #0xd3da9c  ; AllocateCompositedTransformFollowerStub -> CompositedTransformFollower (size=0x24)
    // 0xd3da48: ldur            x1, [fp, #-8]
    // 0xd3da4c: StoreField: r0->field_f = r1
    //     0xd3da4c: stur            w1, [x0, #0xf]
    // 0xd3da50: r1 = true
    //     0xd3da50: add             x1, NULL, #0x20  ; true
    // 0xd3da54: StoreField: r0->field_13 = r1
    //     0xd3da54: stur            w1, [x0, #0x13]
    // 0xd3da58: r1 = Instance_Offset
    //     0xd3da58: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xd3da5c: StoreField: r0->field_1f = r1
    //     0xd3da5c: stur            w1, [x0, #0x1f]
    // 0xd3da60: r1 = Instance_Alignment
    //     0xd3da60: add             x1, PP, #0x15, lsl #12  ; [pp+0x15510] Obj!Alignment@129e7b1
    //     0xd3da64: ldr             x1, [x1, #0x510]
    // 0xd3da68: ArrayStore: r0[0] = r1  ; List_4
    //     0xd3da68: stur            w1, [x0, #0x17]
    // 0xd3da6c: StoreField: r0->field_1b = r1
    //     0xd3da6c: stur            w1, [x0, #0x1b]
    // 0xd3da70: ldur            x1, [fp, #-0x18]
    // 0xd3da74: StoreField: r0->field_b = r1
    //     0xd3da74: stur            w1, [x0, #0xb]
    // 0xd3da78: ldur            x1, [fp, #-0x10]
    // 0xd3da7c: LoadField: r2 = r1->field_b
    //     0xd3da7c: ldur            w2, [x1, #0xb]
    // 0xd3da80: DecompressPointer r2
    //     0xd3da80: add             x2, x2, HEAP, lsl #32
    // 0xd3da84: cmp             w2, NULL
    // 0xd3da88: b.eq            #0xd3da98
    // 0xd3da8c: LeaveFrame
    //     0xd3da8c: mov             SP, fp
    //     0xd3da90: ldp             fp, lr, [SP], #0x10
    // 0xd3da94: ret
    //     0xd3da94: ret             
    // 0xd3da98: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd3da98: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xd3dad8, size: 0xf8
    // 0xd3dad8: EnterFrame
    //     0xd3dad8: stp             fp, lr, [SP, #-0x10]!
    //     0xd3dadc: mov             fp, SP
    // 0xd3dae0: AllocStack(0x8)
    //     0xd3dae0: sub             SP, SP, #8
    // 0xd3dae4: SetupParameters([dynamic _ /* r0 */])
    //     0xd3dae4: ldr             x0, [fp, #0x10]
    //     0xd3dae8: ldur            w2, [x0, #0x17]
    //     0xd3daec: add             x2, x2, HEAP, lsl #32
    //     0xd3daf0: stur            x2, [fp, #-8]
    // 0xd3daf4: CheckStackOverflow
    //     0xd3daf4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd3daf8: cmp             SP, x16
    //     0xd3dafc: b.ls            #0xd3dbb0
    // 0xd3db00: LoadField: r0 = r2->field_f
    //     0xd3db00: ldur            w0, [x2, #0xf]
    // 0xd3db04: DecompressPointer r0
    //     0xd3db04: add             x0, x0, HEAP, lsl #32
    // 0xd3db08: LoadField: r1 = r0->field_b
    //     0xd3db08: ldur            w1, [x0, #0xb]
    // 0xd3db0c: DecompressPointer r1
    //     0xd3db0c: add             x1, x1, HEAP, lsl #32
    // 0xd3db10: cmp             w1, NULL
    // 0xd3db14: b.eq            #0xd3dbb8
    // 0xd3db18: LoadField: r1 = r0->field_43
    //     0xd3db18: ldur            w1, [x0, #0x43]
    // 0xd3db1c: DecompressPointer r1
    //     0xd3db1c: add             x1, x1, HEAP, lsl #32
    // 0xd3db20: cmp             w1, NULL
    // 0xd3db24: b.eq            #0xd3dbbc
    // 0xd3db28: r0 = hasFocus()
    //     0xd3db28: bl              #0x843d08  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::hasFocus
    // 0xd3db2c: tbz             w0, #4, #0xd3dba0
    // 0xd3db30: ldur            x0, [fp, #-8]
    // 0xd3db34: LoadField: r1 = r0->field_f
    //     0xd3db34: ldur            w1, [x0, #0xf]
    // 0xd3db38: DecompressPointer r1
    //     0xd3db38: add             x1, x1, HEAP, lsl #32
    // 0xd3db3c: LoadField: r2 = r1->field_b
    //     0xd3db3c: ldur            w2, [x1, #0xb]
    // 0xd3db40: DecompressPointer r2
    //     0xd3db40: add             x2, x2, HEAP, lsl #32
    // 0xd3db44: cmp             w2, NULL
    // 0xd3db48: b.eq            #0xd3dbc0
    // 0xd3db4c: LoadField: r2 = r1->field_43
    //     0xd3db4c: ldur            w2, [x1, #0x43]
    // 0xd3db50: DecompressPointer r2
    //     0xd3db50: add             x2, x2, HEAP, lsl #32
    // 0xd3db54: cmp             w2, NULL
    // 0xd3db58: b.eq            #0xd3dbc4
    // 0xd3db5c: mov             x1, x2
    // 0xd3db60: r0 = canRequestFocus()
    //     0xd3db60: bl              #0x83fac0  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::canRequestFocus
    // 0xd3db64: tbnz            w0, #4, #0xd3dba0
    // 0xd3db68: ldur            x0, [fp, #-8]
    // 0xd3db6c: LoadField: r1 = r0->field_f
    //     0xd3db6c: ldur            w1, [x0, #0xf]
    // 0xd3db70: DecompressPointer r1
    //     0xd3db70: add             x1, x1, HEAP, lsl #32
    // 0xd3db74: LoadField: r0 = r1->field_b
    //     0xd3db74: ldur            w0, [x1, #0xb]
    // 0xd3db78: DecompressPointer r0
    //     0xd3db78: add             x0, x0, HEAP, lsl #32
    // 0xd3db7c: cmp             w0, NULL
    // 0xd3db80: b.eq            #0xd3dbc8
    // 0xd3db84: LoadField: r0 = r1->field_43
    //     0xd3db84: ldur            w0, [x1, #0x43]
    // 0xd3db88: DecompressPointer r0
    //     0xd3db88: add             x0, x0, HEAP, lsl #32
    // 0xd3db8c: cmp             w0, NULL
    // 0xd3db90: b.eq            #0xd3dbcc
    // 0xd3db94: mov             x1, x0
    // 0xd3db98: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xd3db98: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xd3db9c: r0 = requestFocus()
    //     0xd3db9c: bl              #0x83e7b8  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::requestFocus
    // 0xd3dba0: r0 = Null
    //     0xd3dba0: mov             x0, NULL
    // 0xd3dba4: LeaveFrame
    //     0xd3dba4: mov             SP, fp
    //     0xd3dba8: ldp             fp, lr, [SP], #0x10
    // 0xd3dbac: ret
    //     0xd3dbac: ret             
    // 0xd3dbb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd3dbb0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd3dbb4: b               #0xd3db00
    // 0xd3dbb8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd3dbb8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd3dbbc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd3dbbc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd3dbc0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd3dbc0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd3dbc4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd3dbc4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd3dbc8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd3dbc8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd3dbcc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd3dbcc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Color? effectiveOverlayColor(dynamic) {
    // ** addr: 0xd3dbd0, size: 0x1f4
    // 0xd3dbd0: EnterFrame
    //     0xd3dbd0: stp             fp, lr, [SP, #-0x10]!
    //     0xd3dbd4: mov             fp, SP
    // 0xd3dbd8: AllocStack(0x30)
    //     0xd3dbd8: sub             SP, SP, #0x30
    // 0xd3dbdc: SetupParameters([dynamic _ /* r0 */])
    //     0xd3dbdc: ldr             x0, [fp, #0x10]
    //     0xd3dbe0: ldur            w2, [x0, #0x17]
    //     0xd3dbe4: add             x2, x2, HEAP, lsl #32
    //     0xd3dbe8: stur            x2, [fp, #-8]
    // 0xd3dbec: CheckStackOverflow
    //     0xd3dbec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd3dbf0: cmp             SP, x16
    //     0xd3dbf4: b.ls            #0xd3ddb8
    // 0xd3dbf8: LoadField: r0 = r2->field_f
    //     0xd3dbf8: ldur            w0, [x2, #0xf]
    // 0xd3dbfc: DecompressPointer r0
    //     0xd3dbfc: add             x0, x0, HEAP, lsl #32
    // 0xd3dc00: LoadField: r1 = r0->field_b
    //     0xd3dc00: ldur            w1, [x0, #0xb]
    // 0xd3dc04: DecompressPointer r1
    //     0xd3dc04: add             x1, x1, HEAP, lsl #32
    // 0xd3dc08: cmp             w1, NULL
    // 0xd3dc0c: b.eq            #0xd3ddc0
    // 0xd3dc10: LoadField: r0 = r1->field_3f
    //     0xd3dc10: ldur            w0, [x1, #0x3f]
    // 0xd3dc14: DecompressPointer r0
    //     0xd3dc14: add             x0, x0, HEAP, lsl #32
    // 0xd3dc18: cmp             w0, NULL
    // 0xd3dc1c: b.ne            #0xd3dc28
    // 0xd3dc20: r0 = Null
    //     0xd3dc20: mov             x0, NULL
    // 0xd3dc24: b               #0xd3dc38
    // 0xd3dc28: mov             x1, x0
    // 0xd3dc2c: d0 = 0.120000
    //     0xd3dc2c: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xd3dc30: ldr             d0, [x17, #0xc40]
    // 0xd3dc34: r0 = withOpacity()
    //     0xd3dc34: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xd3dc38: cmp             w0, NULL
    // 0xd3dc3c: b.ne            #0xd3dc74
    // 0xd3dc40: ldur            x0, [fp, #-8]
    // 0xd3dc44: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd3dc44: ldur            w1, [x0, #0x17]
    // 0xd3dc48: DecompressPointer r1
    //     0xd3dc48: add             x1, x1, HEAP, lsl #32
    // 0xd3dc4c: LoadField: r2 = r1->field_3f
    //     0xd3dc4c: ldur            w2, [x1, #0x3f]
    // 0xd3dc50: DecompressPointer r2
    //     0xd3dc50: add             x2, x2, HEAP, lsl #32
    // 0xd3dc54: LoadField: r1 = r0->field_1f
    //     0xd3dc54: ldur            w1, [x0, #0x1f]
    // 0xd3dc58: DecompressPointer r1
    //     0xd3dc58: add             x1, x1, HEAP, lsl #32
    // 0xd3dc5c: r16 = <Color?>
    //     0xd3dc5c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xd3dc60: ldr             x16, [x16, #0xa40]
    // 0xd3dc64: stp             x2, x16, [SP, #8]
    // 0xd3dc68: str             x1, [SP]
    // 0xd3dc6c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xd3dc6c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xd3dc70: r0 = resolveAs()
    //     0xd3dc70: bl              #0x8de57c  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveAs
    // 0xd3dc74: cmp             w0, NULL
    // 0xd3dc78: b.ne            #0xd3ddac
    // 0xd3dc7c: ldur            x0, [fp, #-8]
    // 0xd3dc80: LoadField: r1 = r0->field_1b
    //     0xd3dc80: ldur            w1, [x0, #0x1b]
    // 0xd3dc84: DecompressPointer r1
    //     0xd3dc84: add             x1, x1, HEAP, lsl #32
    // 0xd3dc88: stur            x1, [fp, #-0x10]
    // 0xd3dc8c: r2 = LoadClassIdInstr(r1)
    //     0xd3dc8c: ldur            x2, [x1, #-1]
    //     0xd3dc90: ubfx            x2, x2, #0xc, #0x14
    // 0xd3dc94: r17 = 5069
    //     0xd3dc94: mov             x17, #0x13cd
    // 0xd3dc98: cmp             x2, x17
    // 0xd3dc9c: b.ne            #0xd3dcb0
    // 0xd3dca0: LoadField: r2 = r1->field_3f
    //     0xd3dca0: ldur            w2, [x1, #0x3f]
    // 0xd3dca4: DecompressPointer r2
    //     0xd3dca4: add             x2, x2, HEAP, lsl #32
    // 0xd3dca8: mov             x1, x2
    // 0xd3dcac: b               #0xd3dd8c
    // 0xd3dcb0: r17 = 5070
    //     0xd3dcb0: mov             x17, #0x13ce
    // 0xd3dcb4: cmp             x2, x17
    // 0xd3dcb8: b.ne            #0xd3dd00
    // 0xd3dcbc: r1 = 1
    //     0xd3dcbc: mov             x1, #1
    // 0xd3dcc0: r0 = AllocateContext()
    //     0xd3dcc0: bl              #0x13de838  ; AllocateContextStub
    // 0xd3dcc4: ldur            x1, [fp, #-0x10]
    // 0xd3dcc8: stur            x0, [fp, #-0x18]
    // 0xd3dccc: StoreField: r0->field_f = r1
    //     0xd3dccc: stur            w1, [x0, #0xf]
    // 0xd3dcd0: r0 = _WidgetStateColor()
    //     0xd3dcd0: bl              #0xd29244  ; Allocate_WidgetStateColorStub -> _WidgetStateColor (size=0x30)
    // 0xd3dcd4: ldur            x2, [fp, #-0x18]
    // 0xd3dcd8: r1 = Function '<anonymous closure>':.
    //     0xd3dcd8: add             x1, PP, #0x26, lsl #12  ; [pp+0x26a38] AnonymousClosure: (0xd3df80), of [package:flutter/src/material/slider.dart] _SliderDefaultsM3
    //     0xd3dcdc: ldr             x1, [x1, #0xa38]
    // 0xd3dce0: stur            x0, [fp, #-0x18]
    // 0xd3dce4: r0 = AllocateClosure()
    //     0xd3dce4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3dce8: ldur            x1, [fp, #-0x18]
    // 0xd3dcec: mov             x2, x0
    // 0xd3dcf0: r0 = _WidgetStateColor()
    //     0xd3dcf0: bl              #0xd29128  ; [package:flutter/src/widgets/widget_state.dart] _WidgetStateColor::_WidgetStateColor
    // 0xd3dcf4: ldur            x1, [fp, #-0x18]
    // 0xd3dcf8: ldur            x0, [fp, #-8]
    // 0xd3dcfc: b               #0xd3dd8c
    // 0xd3dd00: r17 = 5071
    //     0xd3dd00: mov             x17, #0x13cf
    // 0xd3dd04: cmp             x2, x17
    // 0xd3dd08: b.ne            #0xd3dd50
    // 0xd3dd0c: r1 = 1
    //     0xd3dd0c: mov             x1, #1
    // 0xd3dd10: r0 = AllocateContext()
    //     0xd3dd10: bl              #0x13de838  ; AllocateContextStub
    // 0xd3dd14: ldur            x1, [fp, #-0x10]
    // 0xd3dd18: stur            x0, [fp, #-0x18]
    // 0xd3dd1c: StoreField: r0->field_f = r1
    //     0xd3dd1c: stur            w1, [x0, #0xf]
    // 0xd3dd20: r0 = _WidgetStateColor()
    //     0xd3dd20: bl              #0xd29244  ; Allocate_WidgetStateColorStub -> _WidgetStateColor (size=0x30)
    // 0xd3dd24: ldur            x2, [fp, #-0x18]
    // 0xd3dd28: r1 = Function '<anonymous closure>':.
    //     0xd3dd28: add             x1, PP, #0x26, lsl #12  ; [pp+0x26a40] AnonymousClosure: (0xd3ddc4), of [package:flutter/src/material/slider.dart] _SliderDefaultsM3Year2023
    //     0xd3dd2c: ldr             x1, [x1, #0xa40]
    // 0xd3dd30: stur            x0, [fp, #-0x18]
    // 0xd3dd34: r0 = AllocateClosure()
    //     0xd3dd34: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd3dd38: ldur            x1, [fp, #-0x18]
    // 0xd3dd3c: mov             x2, x0
    // 0xd3dd40: r0 = _WidgetStateColor()
    //     0xd3dd40: bl              #0xd29128  ; [package:flutter/src/widgets/widget_state.dart] _WidgetStateColor::_WidgetStateColor
    // 0xd3dd44: ldur            x1, [fp, #-0x18]
    // 0xd3dd48: ldur            x0, [fp, #-8]
    // 0xd3dd4c: b               #0xd3dd8c
    // 0xd3dd50: LoadField: r0 = r1->field_9b
    //     0xd3dd50: ldur            w0, [x1, #0x9b]
    // 0xd3dd54: DecompressPointer r0
    //     0xd3dd54: add             x0, x0, HEAP, lsl #32
    // 0xd3dd58: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd3dd5c: cmp             w0, w16
    // 0xd3dd60: b.ne            #0xd3dd70
    // 0xd3dd64: r2 = _colors
    //     0xd3dd64: add             x2, PP, #0x26, lsl #12  ; [pp+0x26a18] Field <_SliderDefaultsM2@125231897._colors@125231897>: late final (offset: 0x9c)
    //     0xd3dd68: ldr             x2, [x2, #0xa18]
    // 0xd3dd6c: r0 = InitLateFinalInstanceField()
    //     0xd3dd6c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd3dd70: LoadField: r1 = r0->field_b
    //     0xd3dd70: ldur            w1, [x0, #0xb]
    // 0xd3dd74: DecompressPointer r1
    //     0xd3dd74: add             x1, x1, HEAP, lsl #32
    // 0xd3dd78: d0 = 0.120000
    //     0xd3dd78: add             x17, PP, #0x12, lsl #12  ; [pp+0x12c40] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xd3dd7c: ldr             d0, [x17, #0xc40]
    // 0xd3dd80: r0 = withOpacity()
    //     0xd3dd80: bl              #0x12d8a58  ; [dart:ui] Color::withOpacity
    // 0xd3dd84: mov             x1, x0
    // 0xd3dd88: ldur            x0, [fp, #-8]
    // 0xd3dd8c: LoadField: r2 = r0->field_1f
    //     0xd3dd8c: ldur            w2, [x0, #0x1f]
    // 0xd3dd90: DecompressPointer r2
    //     0xd3dd90: add             x2, x2, HEAP, lsl #32
    // 0xd3dd94: r16 = <Color?>
    //     0xd3dd94: add             x16, PP, #0x15, lsl #12  ; [pp+0x15a40] TypeArguments: <Color?>
    //     0xd3dd98: ldr             x16, [x16, #0xa40]
    // 0xd3dd9c: stp             x1, x16, [SP, #8]
    // 0xd3dda0: str             x2, [SP]
    // 0xd3dda4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xd3dda4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xd3dda8: r0 = resolveAs()
    //     0xd3dda8: bl              #0x8de57c  ; [package:flutter/src/widgets/widget_state.dart] WidgetStateProperty::resolveAs
    // 0xd3ddac: LeaveFrame
    //     0xd3ddac: mov             SP, fp
    //     0xd3ddb0: ldp             fp, lr, [SP], #0x10
    // 0xd3ddb4: ret
    //     0xd3ddb4: ret             
    // 0xd3ddb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd3ddb8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd3ddbc: b               #0xd3dbf8
    // 0xd3ddc0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd3ddc0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0xf7be7c, size: 0x388
    // 0xf7be7c: EnterFrame
    //     0xf7be7c: stp             fp, lr, [SP, #-0x10]!
    //     0xf7be80: mov             fp, SP
    // 0xf7be84: AllocStack(0x30)
    //     0xf7be84: sub             SP, SP, #0x30
    // 0xf7be88: SetupParameters(_SliderState this /* r1 => r2, fp-0x8 */)
    //     0xf7be88: mov             x2, x1
    //     0xf7be8c: stur            x1, [fp, #-8]
    // 0xf7be90: CheckStackOverflow
    //     0xf7be90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf7be94: cmp             SP, x16
    //     0xf7be98: b.ls            #0xf7c1dc
    // 0xf7be9c: r1 = <double>
    //     0xf7be9c: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf7bea0: r0 = AnimationController()
    //     0xf7bea0: bl              #0x87522c  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0xf7bea4: stur            x0, [fp, #-0x10]
    // 0xf7bea8: r16 = Instance_Duration
    //     0xf7bea8: ldr             x16, [PP, #0x5668]  ; [pp+0x5668] Obj!Duration@12c8941
    // 0xf7beac: str             x16, [SP]
    // 0xf7beb0: mov             x1, x0
    // 0xf7beb4: ldur            x2, [fp, #-8]
    // 0xf7beb8: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0xf7beb8: add             x4, PP, #0x15, lsl #12  ; [pp+0x155a0] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0xf7bebc: ldr             x4, [x4, #0x5a0]
    // 0xf7bec0: r0 = AnimationController()
    //     0xf7bec0: bl              #0x874ea4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0xf7bec4: ldur            x0, [fp, #-0x10]
    // 0xf7bec8: ldur            x2, [fp, #-8]
    // 0xf7becc: StoreField: r2->field_1b = r0
    //     0xf7becc: stur            w0, [x2, #0x1b]
    //     0xf7bed0: ldurb           w16, [x2, #-1]
    //     0xf7bed4: ldurb           w17, [x0, #-1]
    //     0xf7bed8: and             x16, x17, x16, lsr #2
    //     0xf7bedc: tst             x16, HEAP, lsr #32
    //     0xf7bee0: b.eq            #0xf7bee8
    //     0xf7bee4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf7bee8: r1 = <double>
    //     0xf7bee8: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf7beec: r0 = AnimationController()
    //     0xf7beec: bl              #0x87522c  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0xf7bef0: stur            x0, [fp, #-0x10]
    // 0xf7bef4: r16 = Instance_Duration
    //     0xf7bef4: ldr             x16, [PP, #0x5668]  ; [pp+0x5668] Obj!Duration@12c8941
    // 0xf7bef8: str             x16, [SP]
    // 0xf7befc: mov             x1, x0
    // 0xf7bf00: ldur            x2, [fp, #-8]
    // 0xf7bf04: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0xf7bf04: add             x4, PP, #0x15, lsl #12  ; [pp+0x155a0] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0xf7bf08: ldr             x4, [x4, #0x5a0]
    // 0xf7bf0c: r0 = AnimationController()
    //     0xf7bf0c: bl              #0x874ea4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0xf7bf10: ldur            x0, [fp, #-0x10]
    // 0xf7bf14: ldur            x2, [fp, #-8]
    // 0xf7bf18: StoreField: r2->field_1f = r0
    //     0xf7bf18: stur            w0, [x2, #0x1f]
    //     0xf7bf1c: ldurb           w16, [x2, #-1]
    //     0xf7bf20: ldurb           w17, [x0, #-1]
    //     0xf7bf24: and             x16, x17, x16, lsr #2
    //     0xf7bf28: tst             x16, HEAP, lsr #32
    //     0xf7bf2c: b.eq            #0xf7bf34
    //     0xf7bf30: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf7bf34: r1 = <double>
    //     0xf7bf34: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf7bf38: r0 = AnimationController()
    //     0xf7bf38: bl              #0x87522c  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0xf7bf3c: stur            x0, [fp, #-0x10]
    // 0xf7bf40: r16 = Instance_Duration
    //     0xf7bf40: add             x16, PP, #0x84, lsl #12  ; [pp+0x84f20] Obj!Duration@12c8a11
    //     0xf7bf44: ldr             x16, [x16, #0xf20]
    // 0xf7bf48: str             x16, [SP]
    // 0xf7bf4c: mov             x1, x0
    // 0xf7bf50: ldur            x2, [fp, #-8]
    // 0xf7bf54: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0xf7bf54: add             x4, PP, #0x15, lsl #12  ; [pp+0x155a0] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0xf7bf58: ldr             x4, [x4, #0x5a0]
    // 0xf7bf5c: r0 = AnimationController()
    //     0xf7bf5c: bl              #0x874ea4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0xf7bf60: ldur            x0, [fp, #-0x10]
    // 0xf7bf64: ldur            x2, [fp, #-8]
    // 0xf7bf68: StoreField: r2->field_23 = r0
    //     0xf7bf68: stur            w0, [x2, #0x23]
    //     0xf7bf6c: ldurb           w16, [x2, #-1]
    //     0xf7bf70: ldurb           w17, [x0, #-1]
    //     0xf7bf74: and             x16, x17, x16, lsr #2
    //     0xf7bf78: tst             x16, HEAP, lsr #32
    //     0xf7bf7c: b.eq            #0xf7bf84
    //     0xf7bf80: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf7bf84: r1 = <double>
    //     0xf7bf84: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xf7bf88: r0 = AnimationController()
    //     0xf7bf88: bl              #0x87522c  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0xf7bf8c: stur            x0, [fp, #-0x10]
    // 0xf7bf90: r16 = Instance_Duration
    //     0xf7bf90: ldr             x16, [PP, #0x1808]  ; [pp+0x1808] Obj!Duration@12c8901
    // 0xf7bf94: str             x16, [SP]
    // 0xf7bf98: mov             x1, x0
    // 0xf7bf9c: ldur            x2, [fp, #-8]
    // 0xf7bfa0: r4 = const [0, 0x3, 0x1, 0x2, duration, 0x2, null]
    //     0xf7bfa0: add             x4, PP, #0x15, lsl #12  ; [pp+0x155a0] List(7) [0, 0x3, 0x1, 0x2, "duration", 0x2, Null]
    //     0xf7bfa4: ldr             x4, [x4, #0x5a0]
    // 0xf7bfa8: r0 = AnimationController()
    //     0xf7bfa8: bl              #0x874ea4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0xf7bfac: ldur            x0, [fp, #-0x10]
    // 0xf7bfb0: ldur            x3, [fp, #-8]
    // 0xf7bfb4: StoreField: r3->field_27 = r0
    //     0xf7bfb4: stur            w0, [x3, #0x27]
    //     0xf7bfb8: ldurb           w16, [x3, #-1]
    //     0xf7bfbc: ldurb           w17, [x0, #-1]
    //     0xf7bfc0: and             x16, x17, x16, lsr #2
    //     0xf7bfc4: tst             x16, HEAP, lsr #32
    //     0xf7bfc8: b.eq            #0xf7bfd0
    //     0xf7bfcc: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xf7bfd0: LoadField: r1 = r3->field_23
    //     0xf7bfd0: ldur            w1, [x3, #0x23]
    // 0xf7bfd4: DecompressPointer r1
    //     0xf7bfd4: add             x1, x1, HEAP, lsl #32
    // 0xf7bfd8: LoadField: r0 = r3->field_b
    //     0xf7bfd8: ldur            w0, [x3, #0xb]
    // 0xf7bfdc: DecompressPointer r0
    //     0xf7bfdc: add             x0, x0, HEAP, lsl #32
    // 0xf7bfe0: cmp             w0, NULL
    // 0xf7bfe4: b.eq            #0xf7c1e4
    // 0xf7bfe8: r2 = 1.000000
    //     0xf7bfe8: ldr             x2, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xf7bfec: r0 = value=()
    //     0xf7bfec: bl              #0x829534  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0xf7bff0: ldur            x0, [fp, #-8]
    // 0xf7bff4: LoadField: r2 = r0->field_27
    //     0xf7bff4: ldur            w2, [x0, #0x27]
    // 0xf7bff8: DecompressPointer r2
    //     0xf7bff8: add             x2, x2, HEAP, lsl #32
    // 0xf7bffc: stur            x2, [fp, #-0x10]
    // 0xf7c000: LoadField: r1 = r0->field_b
    //     0xf7c000: ldur            w1, [x0, #0xb]
    // 0xf7c004: DecompressPointer r1
    //     0xf7c004: add             x1, x1, HEAP, lsl #32
    // 0xf7c008: cmp             w1, NULL
    // 0xf7c00c: b.eq            #0xf7c1e8
    // 0xf7c010: LoadField: d0 = r1->field_b
    //     0xf7c010: ldur            d0, [x1, #0xb]
    // 0xf7c014: mov             x1, x0
    // 0xf7c018: r0 = _convert()
    //     0xf7c018: bl              #0xd3d560  ; [package:flutter/src/material/slider.dart] _SliderState::_convert
    // 0xf7c01c: r2 = inline_Allocate_Double()
    //     0xf7c01c: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0xf7c020: add             x2, x2, #0x10
    //     0xf7c024: cmp             x0, x2
    //     0xf7c028: b.ls            #0xf7c1ec
    //     0xf7c02c: str             x2, [THR, #0x60]  ; THR::top
    //     0xf7c030: sub             x2, x2, #0xf
    //     0xf7c034: mov             x0, #0xe19c
    //     0xf7c038: movk            x0, #3, lsl #16
    //     0xf7c03c: stur            x0, [x2, #-1]
    // 0xf7c040: dmb             ishst
    // 0xf7c044: StoreField: r2->field_7 = d0
    //     0xf7c044: stur            d0, [x2, #7]
    // 0xf7c048: ldur            x1, [fp, #-0x10]
    // 0xf7c04c: r0 = value=()
    //     0xf7c04c: bl              #0x829534  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0xf7c050: r1 = Null
    //     0xf7c050: mov             x1, NULL
    // 0xf7c054: r2 = 4
    //     0xf7c054: mov             x2, #4
    // 0xf7c058: r0 = AllocateArray()
    //     0xf7c058: bl              #0x13df928  ; AllocateArrayStub
    // 0xf7c05c: stur            x0, [fp, #-0x10]
    // 0xf7c060: r16 = _AdjustSliderIntent
    //     0xf7c060: add             x16, PP, #0x99, lsl #12  ; [pp+0x99020] Type: _AdjustSliderIntent
    //     0xf7c064: ldr             x16, [x16, #0x20]
    // 0xf7c068: StoreField: r0->field_f = r16
    //     0xf7c068: stur            w16, [x0, #0xf]
    // 0xf7c06c: ldur            x2, [fp, #-8]
    // 0xf7c070: r1 = Function '_actionHandler@125231897':.
    //     0xf7c070: add             x1, PP, #0x99, lsl #12  ; [pp+0x99028] AnonymousClosure: (0xf7c204), in [package:flutter/src/material/slider.dart] _SliderState::_actionHandler (0xf7c240)
    //     0xf7c074: ldr             x1, [x1, #0x28]
    // 0xf7c078: r0 = AllocateClosure()
    //     0xf7c078: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf7c07c: r1 = <_AdjustSliderIntent>
    //     0xf7c07c: add             x1, PP, #0x99, lsl #12  ; [pp+0x99030] TypeArguments: <_AdjustSliderIntent>
    //     0xf7c080: ldr             x1, [x1, #0x30]
    // 0xf7c084: stur            x0, [fp, #-0x18]
    // 0xf7c088: r0 = CallbackAction()
    //     0xf7c088: bl              #0xd126e8  ; AllocateCallbackActionStub -> CallbackAction<X0 bound Intent> (size=0x18)
    // 0xf7c08c: mov             x2, x0
    // 0xf7c090: ldur            x0, [fp, #-0x18]
    // 0xf7c094: stur            x2, [fp, #-0x20]
    // 0xf7c098: StoreField: r2->field_13 = r0
    //     0xf7c098: stur            w0, [x2, #0x13]
    // 0xf7c09c: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0xf7c09c: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a7a0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0xf7c0a0: ldr             x1, [x1, #0x7a0]
    // 0xf7c0a4: r0 = ObserverList()
    //     0xf7c0a4: bl              #0x89f8bc  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0xf7c0a8: mov             x3, x0
    // 0xf7c0ac: r0 = false
    //     0xf7c0ac: add             x0, NULL, #0x30  ; false
    // 0xf7c0b0: stur            x3, [fp, #-0x18]
    // 0xf7c0b4: StoreField: r3->field_f = r0
    //     0xf7c0b4: stur            w0, [x3, #0xf]
    // 0xf7c0b8: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xf7c0bc: StoreField: r3->field_13 = r0
    //     0xf7c0bc: stur            w0, [x3, #0x13]
    // 0xf7c0c0: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0xf7c0c0: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a7a0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0xf7c0c4: ldr             x1, [x1, #0x7a0]
    // 0xf7c0c8: r2 = 0
    //     0xf7c0c8: mov             x2, #0
    // 0xf7c0cc: r0 = _GrowableList()
    //     0xf7c0cc: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xf7c0d0: ldur            x1, [fp, #-0x18]
    // 0xf7c0d4: StoreField: r1->field_b = r0
    //     0xf7c0d4: stur            w0, [x1, #0xb]
    //     0xf7c0d8: ldurb           w16, [x1, #-1]
    //     0xf7c0dc: ldurb           w17, [x0, #-1]
    //     0xf7c0e0: and             x16, x17, x16, lsr #2
    //     0xf7c0e4: tst             x16, HEAP, lsr #32
    //     0xf7c0e8: b.eq            #0xf7c0f0
    //     0xf7c0ec: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf7c0f0: mov             x0, x1
    // 0xf7c0f4: ldur            x1, [fp, #-0x20]
    // 0xf7c0f8: StoreField: r1->field_b = r0
    //     0xf7c0f8: stur            w0, [x1, #0xb]
    //     0xf7c0fc: ldurb           w16, [x1, #-1]
    //     0xf7c100: ldurb           w17, [x0, #-1]
    //     0xf7c104: and             x16, x17, x16, lsr #2
    //     0xf7c108: tst             x16, HEAP, lsr #32
    //     0xf7c10c: b.eq            #0xf7c114
    //     0xf7c110: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf7c114: mov             x0, x1
    // 0xf7c118: ldur            x1, [fp, #-0x10]
    // 0xf7c11c: ArrayStore: r1[1] = r0  ; List_4
    //     0xf7c11c: add             x25, x1, #0x13
    //     0xf7c120: str             w0, [x25]
    //     0xf7c124: tbz             w0, #0, #0xf7c140
    //     0xf7c128: ldurb           w16, [x1, #-1]
    //     0xf7c12c: ldurb           w17, [x0, #-1]
    //     0xf7c130: and             x16, x17, x16, lsr #2
    //     0xf7c134: tst             x16, HEAP, lsr #32
    //     0xf7c138: b.eq            #0xf7c140
    //     0xf7c13c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xf7c140: r16 = <Type, Action<Intent>>
    //     0xf7c140: add             x16, PP, #0x84, lsl #12  ; [pp+0x84b80] TypeArguments: <Type, Action<Intent>>
    //     0xf7c144: ldr             x16, [x16, #0xb80]
    // 0xf7c148: ldur            lr, [fp, #-0x10]
    // 0xf7c14c: stp             lr, x16, [SP]
    // 0xf7c150: r0 = Map._fromLiteral()
    //     0xf7c150: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xf7c154: ldur            x1, [fp, #-8]
    // 0xf7c158: StoreField: r1->field_33 = r0
    //     0xf7c158: stur            w0, [x1, #0x33]
    //     0xf7c15c: ldurb           w16, [x1, #-1]
    //     0xf7c160: ldurb           w17, [x0, #-1]
    //     0xf7c164: and             x16, x17, x16, lsr #2
    //     0xf7c168: tst             x16, HEAP, lsr #32
    //     0xf7c16c: b.eq            #0xf7c174
    //     0xf7c170: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf7c174: LoadField: r0 = r1->field_b
    //     0xf7c174: ldur            w0, [x1, #0xb]
    // 0xf7c178: DecompressPointer r0
    //     0xf7c178: add             x0, x0, HEAP, lsl #32
    // 0xf7c17c: cmp             w0, NULL
    // 0xf7c180: b.eq            #0xf7c200
    // 0xf7c184: LoadField: r0 = r1->field_43
    //     0xf7c184: ldur            w0, [x1, #0x43]
    // 0xf7c188: DecompressPointer r0
    //     0xf7c188: add             x0, x0, HEAP, lsl #32
    // 0xf7c18c: cmp             w0, NULL
    // 0xf7c190: b.ne            #0xf7c1cc
    // 0xf7c194: r0 = FocusNode()
    //     0xf7c194: bl              #0xd4952c  ; AllocateFocusNodeStub -> FocusNode (size=0x68)
    // 0xf7c198: mov             x1, x0
    // 0xf7c19c: stur            x0, [fp, #-0x10]
    // 0xf7c1a0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xf7c1a0: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xf7c1a4: r0 = FocusNode()
    //     0xf7c1a4: bl              #0x83cf84  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::FocusNode
    // 0xf7c1a8: ldur            x0, [fp, #-0x10]
    // 0xf7c1ac: ldur            x1, [fp, #-8]
    // 0xf7c1b0: StoreField: r1->field_43 = r0
    //     0xf7c1b0: stur            w0, [x1, #0x43]
    //     0xf7c1b4: ldurb           w16, [x1, #-1]
    //     0xf7c1b8: ldurb           w17, [x0, #-1]
    //     0xf7c1bc: and             x16, x17, x16, lsr #2
    //     0xf7c1c0: tst             x16, HEAP, lsr #32
    //     0xf7c1c4: b.eq            #0xf7c1cc
    //     0xf7c1c8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xf7c1cc: r0 = Null
    //     0xf7c1cc: mov             x0, NULL
    // 0xf7c1d0: LeaveFrame
    //     0xf7c1d0: mov             SP, fp
    //     0xf7c1d4: ldp             fp, lr, [SP], #0x10
    // 0xf7c1d8: ret
    //     0xf7c1d8: ret             
    // 0xf7c1dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf7c1dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf7c1e0: b               #0xf7be9c
    // 0xf7c1e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf7c1e4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf7c1e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf7c1e8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf7c1ec: SaveReg d0
    //     0xf7c1ec: str             q0, [SP, #-0x10]!
    // 0xf7c1f0: r0 = AllocateDouble()
    //     0xf7c1f0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xf7c1f4: mov             x2, x0
    // 0xf7c1f8: RestoreReg d0
    //     0xf7c1f8: ldr             q0, [SP], #0x10
    // 0xf7c1fc: b               #0xf7c044
    // 0xf7c200: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf7c200: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _actionHandler(dynamic, _AdjustSliderIntent) {
    // ** addr: 0xf7c204, size: 0x3c
    // 0xf7c204: EnterFrame
    //     0xf7c204: stp             fp, lr, [SP, #-0x10]!
    //     0xf7c208: mov             fp, SP
    // 0xf7c20c: ldr             x0, [fp, #0x18]
    // 0xf7c210: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf7c210: ldur            w1, [x0, #0x17]
    // 0xf7c214: DecompressPointer r1
    //     0xf7c214: add             x1, x1, HEAP, lsl #32
    // 0xf7c218: CheckStackOverflow
    //     0xf7c218: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf7c21c: cmp             SP, x16
    //     0xf7c220: b.ls            #0xf7c238
    // 0xf7c224: ldr             x2, [fp, #0x10]
    // 0xf7c228: r0 = _actionHandler()
    //     0xf7c228: bl              #0xf7c240  ; [package:flutter/src/material/slider.dart] _SliderState::_actionHandler
    // 0xf7c22c: LeaveFrame
    //     0xf7c22c: mov             SP, fp
    //     0xf7c230: ldp             fp, lr, [SP], #0x10
    // 0xf7c234: ret
    //     0xf7c234: ret             
    // 0xf7c238: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf7c238: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf7c23c: b               #0xf7c224
  }
  _ _actionHandler(/* No info */) {
    // ** addr: 0xf7c240, size: 0x148
    // 0xf7c240: EnterFrame
    //     0xf7c240: stp             fp, lr, [SP, #-0x10]!
    //     0xf7c244: mov             fp, SP
    // 0xf7c248: AllocStack(0x10)
    //     0xf7c248: sub             SP, SP, #0x10
    // 0xf7c24c: SetupParameters(dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xf7c24c: stur            x2, [fp, #-0x10]
    // 0xf7c250: CheckStackOverflow
    //     0xf7c250: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf7c254: cmp             SP, x16
    //     0xf7c258: b.ls            #0xf7c374
    // 0xf7c25c: LoadField: r0 = r1->field_2f
    //     0xf7c25c: ldur            w0, [x1, #0x2f]
    // 0xf7c260: DecompressPointer r0
    //     0xf7c260: add             x0, x0, HEAP, lsl #32
    // 0xf7c264: mov             x1, x0
    // 0xf7c268: stur            x0, [fp, #-8]
    // 0xf7c26c: r0 = _currentElement()
    //     0xf7c26c: bl              #0x859318  ; [package:flutter/src/widgets/framework.dart] GlobalKey::_currentElement
    // 0xf7c270: cmp             w0, NULL
    // 0xf7c274: b.eq            #0xf7c37c
    // 0xf7c278: mov             x1, x0
    // 0xf7c27c: r0 = of()
    //     0xf7c27c: bl              #0x87371c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0xf7c280: mov             x1, x0
    // 0xf7c284: ldur            x0, [fp, #-0x10]
    // 0xf7c288: LoadField: r2 = r0->field_7
    //     0xf7c288: ldur            w2, [x0, #7]
    // 0xf7c28c: DecompressPointer r2
    //     0xf7c28c: add             x2, x2, HEAP, lsl #32
    // 0xf7c290: LoadField: r0 = r2->field_7
    //     0xf7c290: ldur            x0, [x2, #7]
    // 0xf7c294: cmp             x0, #1
    // 0xf7c298: b.gt            #0xf7c2d4
    // 0xf7c29c: cmp             x0, #0
    // 0xf7c2a0: b.gt            #0xf7c2bc
    // 0xf7c2a4: r16 = Instance_TextDirection
    //     0xf7c2a4: ldr             x16, [PP, #0x25b0]  ; [pp+0x25b0] Obj!TextDirection@12c73a1
    // 0xf7c2a8: cmp             w1, w16
    // 0xf7c2ac: r16 = true
    //     0xf7c2ac: add             x16, NULL, #0x20  ; true
    // 0xf7c2b0: r17 = false
    //     0xf7c2b0: add             x17, NULL, #0x30  ; false
    // 0xf7c2b4: csel            x0, x16, x17, eq
    // 0xf7c2b8: b               #0xf7c2e8
    // 0xf7c2bc: r16 = Instance_TextDirection
    //     0xf7c2bc: ldr             x16, [PP, #0x2578]  ; [pp+0x2578] Obj!TextDirection@12c7381
    // 0xf7c2c0: cmp             w1, w16
    // 0xf7c2c4: r16 = true
    //     0xf7c2c4: add             x16, NULL, #0x20  ; true
    // 0xf7c2c8: r17 = false
    //     0xf7c2c8: add             x17, NULL, #0x30  ; false
    // 0xf7c2cc: csel            x0, x16, x17, eq
    // 0xf7c2d0: b               #0xf7c2e8
    // 0xf7c2d4: cmp             x0, #2
    // 0xf7c2d8: b.gt            #0xf7c2e4
    // 0xf7c2dc: r0 = true
    //     0xf7c2dc: add             x0, NULL, #0x20  ; true
    // 0xf7c2e0: b               #0xf7c2e8
    // 0xf7c2e4: r0 = false
    //     0xf7c2e4: add             x0, NULL, #0x30  ; false
    // 0xf7c2e8: ldur            x1, [fp, #-8]
    // 0xf7c2ec: stur            x0, [fp, #-0x10]
    // 0xf7c2f0: r0 = _currentElement()
    //     0xf7c2f0: bl              #0x859318  ; [package:flutter/src/widgets/framework.dart] GlobalKey::_currentElement
    // 0xf7c2f4: cmp             w0, NULL
    // 0xf7c2f8: b.eq            #0xf7c380
    // 0xf7c2fc: mov             x1, x0
    // 0xf7c300: r0 = findRenderObject()
    //     0xf7c300: bl              #0x8418fc  ; [package:flutter/src/widgets/framework.dart] Element::findRenderObject
    // 0xf7c304: mov             x3, x0
    // 0xf7c308: stur            x3, [fp, #-8]
    // 0xf7c30c: cmp             w3, NULL
    // 0xf7c310: b.eq            #0xf7c384
    // 0xf7c314: mov             x0, x3
    // 0xf7c318: r2 = Null
    //     0xf7c318: mov             x2, NULL
    // 0xf7c31c: r1 = Null
    //     0xf7c31c: mov             x1, NULL
    // 0xf7c320: r4 = LoadClassIdInstr(r0)
    //     0xf7c320: ldur            x4, [x0, #-1]
    //     0xf7c324: ubfx            x4, x4, #0xc, #0x14
    // 0xf7c328: r17 = 4846
    //     0xf7c328: mov             x17, #0x12ee
    // 0xf7c32c: cmp             x4, x17
    // 0xf7c330: b.eq            #0xf7c348
    // 0xf7c334: r8 = _RenderSlider
    //     0xf7c334: add             x8, PP, #0x99, lsl #12  ; [pp+0x99038] Type: _RenderSlider
    //     0xf7c338: ldr             x8, [x8, #0x38]
    // 0xf7c33c: r3 = Null
    //     0xf7c33c: add             x3, PP, #0x99, lsl #12  ; [pp+0x99040] Null
    //     0xf7c340: ldr             x3, [x3, #0x40]
    // 0xf7c344: r0 = DefaultTypeTest()
    //     0xf7c344: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xf7c348: ldur            x0, [fp, #-0x10]
    // 0xf7c34c: tbnz            w0, #4, #0xf7c35c
    // 0xf7c350: ldur            x1, [fp, #-8]
    // 0xf7c354: r0 = increaseAction()
    //     0xf7c354: bl              #0xbf99ec  ; [package:flutter/src/material/slider.dart] _RenderSlider::increaseAction
    // 0xf7c358: b               #0xf7c364
    // 0xf7c35c: ldur            x1, [fp, #-8]
    // 0xf7c360: r0 = decreaseAction()
    //     0xf7c360: bl              #0xbf937c  ; [package:flutter/src/material/slider.dart] _RenderSlider::decreaseAction
    // 0xf7c364: r0 = Null
    //     0xf7c364: mov             x0, NULL
    // 0xf7c368: LeaveFrame
    //     0xf7c368: mov             SP, fp
    //     0xf7c36c: ldp             fp, lr, [SP], #0x10
    // 0xf7c370: ret
    //     0xf7c370: ret             
    // 0xf7c374: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf7c374: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf7c378: b               #0xf7c25c
    // 0xf7c37c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf7c37c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf7c380: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf7c380: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf7c384: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf7c384: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _SliderState(/* No info */) {
    // ** addr: 0xfa2eb8, size: 0xe0
    // 0xfa2eb8: EnterFrame
    //     0xfa2eb8: stp             fp, lr, [SP, #-0x10]!
    //     0xfa2ebc: mov             fp, SP
    // 0xfa2ec0: AllocStack(0x10)
    //     0xfa2ec0: sub             SP, SP, #0x10
    // 0xfa2ec4: ldr             x2, [THR, #0x90]  ; THR::object_sentinel
    // 0xfa2ec8: r0 = false
    //     0xfa2ec8: add             x0, NULL, #0x30  ; false
    // 0xfa2ecc: mov             x3, x1
    // 0xfa2ed0: stur            x1, [fp, #-8]
    // 0xfa2ed4: CheckStackOverflow
    //     0xfa2ed4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa2ed8: cmp             SP, x16
    //     0xfa2edc: b.ls            #0xfa2f90
    // 0xfa2ee0: StoreField: r3->field_1b = r2
    //     0xfa2ee0: stur            w2, [x3, #0x1b]
    // 0xfa2ee4: StoreField: r3->field_1f = r2
    //     0xfa2ee4: stur            w2, [x3, #0x1f]
    // 0xfa2ee8: StoreField: r3->field_23 = r2
    //     0xfa2ee8: stur            w2, [x3, #0x23]
    // 0xfa2eec: StoreField: r3->field_27 = r2
    //     0xfa2eec: stur            w2, [x3, #0x27]
    // 0xfa2ef0: StoreField: r3->field_33 = r2
    //     0xfa2ef0: stur            w2, [x3, #0x33]
    // 0xfa2ef4: StoreField: r3->field_3b = r0
    //     0xfa2ef4: stur            w0, [x3, #0x3b]
    // 0xfa2ef8: StoreField: r3->field_4b = r0
    //     0xfa2ef8: stur            w0, [x3, #0x4b]
    // 0xfa2efc: StoreField: r3->field_4f = r0
    //     0xfa2efc: stur            w0, [x3, #0x4f]
    // 0xfa2f00: r1 = <State<StatefulWidget>>
    //     0xfa2f00: ldr             x1, [PP, #0x4df8]  ; [pp+0x4df8] TypeArguments: <State<StatefulWidget>>
    // 0xfa2f04: r0 = LabeledGlobalKey()
    //     0xfa2f04: bl              #0x856cf8  ; AllocateLabeledGlobalKeyStub -> LabeledGlobalKey<X0 bound State> (size=0x10)
    // 0xfa2f08: ldur            x1, [fp, #-8]
    // 0xfa2f0c: StoreField: r1->field_2f = r0
    //     0xfa2f0c: stur            w0, [x1, #0x2f]
    //     0xfa2f10: ldurb           w16, [x1, #-1]
    //     0xfa2f14: ldurb           w17, [x0, #-1]
    //     0xfa2f18: and             x16, x17, x16, lsr #2
    //     0xfa2f1c: tst             x16, HEAP, lsr #32
    //     0xfa2f20: b.eq            #0xfa2f28
    //     0xfa2f24: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfa2f28: r0 = OverlayPortalController()
    //     0xfa2f28: bl              #0xfa2fa4  ; AllocateOverlayPortalControllerStub -> OverlayPortalController (size=0x10)
    // 0xfa2f2c: mov             x1, x0
    // 0xfa2f30: stur            x0, [fp, #-0x10]
    // 0xfa2f34: r0 = show()
    //     0xfa2f34: bl              #0xcfba50  ; [package:flutter/src/widgets/overlay.dart] OverlayPortalController::show
    // 0xfa2f38: ldur            x0, [fp, #-0x10]
    // 0xfa2f3c: ldur            x1, [fp, #-8]
    // 0xfa2f40: StoreField: r1->field_47 = r0
    //     0xfa2f40: stur            w0, [x1, #0x47]
    //     0xfa2f44: ldurb           w16, [x1, #-1]
    //     0xfa2f48: ldurb           w17, [x0, #-1]
    //     0xfa2f4c: and             x16, x17, x16, lsr #2
    //     0xfa2f50: tst             x16, HEAP, lsr #32
    //     0xfa2f54: b.eq            #0xfa2f5c
    //     0xfa2f58: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfa2f5c: r0 = LayerLink()
    //     0xfa2f5c: bl              #0xfa2f98  ; AllocateLayerLinkStub -> LayerLink (size=0x10)
    // 0xfa2f60: ldur            x1, [fp, #-8]
    // 0xfa2f64: StoreField: r1->field_53 = r0
    //     0xfa2f64: stur            w0, [x1, #0x53]
    //     0xfa2f68: ldurb           w16, [x1, #-1]
    //     0xfa2f6c: ldurb           w17, [x0, #-1]
    //     0xfa2f70: and             x16, x17, x16, lsr #2
    //     0xfa2f74: tst             x16, HEAP, lsr #32
    //     0xfa2f78: b.eq            #0xfa2f80
    //     0xfa2f7c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfa2f80: r0 = Null
    //     0xfa2f80: mov             x0, NULL
    // 0xfa2f84: LeaveFrame
    //     0xfa2f84: mov             SP, fp
    //     0xfa2f88: ldp             fp, lr, [SP], #0x10
    // 0xfa2f8c: ret
    //     0xfa2f8c: ret             
    // 0xfa2f90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa2f90: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa2f94: b               #0xfa2ee0
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10ddfa0, size: 0x10c
    // 0x10ddfa0: EnterFrame
    //     0x10ddfa0: stp             fp, lr, [SP, #-0x10]!
    //     0x10ddfa4: mov             fp, SP
    // 0x10ddfa8: AllocStack(0x8)
    //     0x10ddfa8: sub             SP, SP, #8
    // 0x10ddfac: SetupParameters(_SliderState this /* r1 => r0, fp-0x8 */)
    //     0x10ddfac: mov             x0, x1
    //     0x10ddfb0: stur            x1, [fp, #-8]
    // 0x10ddfb4: CheckStackOverflow
    //     0x10ddfb4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10ddfb8: cmp             SP, x16
    //     0x10ddfbc: b.ls            #0x10de074
    // 0x10ddfc0: LoadField: r1 = r0->field_2b
    //     0x10ddfc0: ldur            w1, [x0, #0x2b]
    // 0x10ddfc4: DecompressPointer r1
    //     0x10ddfc4: add             x1, x1, HEAP, lsl #32
    // 0x10ddfc8: cmp             w1, NULL
    // 0x10ddfcc: b.eq            #0x10ddfd8
    // 0x10ddfd0: r0 = cancel()
    //     0x10ddfd0: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0x10ddfd4: ldur            x0, [fp, #-8]
    // 0x10ddfd8: LoadField: r1 = r0->field_1b
    //     0x10ddfd8: ldur            w1, [x0, #0x1b]
    // 0x10ddfdc: DecompressPointer r1
    //     0x10ddfdc: add             x1, x1, HEAP, lsl #32
    // 0x10ddfe0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10ddfe4: cmp             w1, w16
    // 0x10ddfe8: b.eq            #0x10de07c
    // 0x10ddfec: r0 = dispose()
    //     0x10ddfec: bl              #0x9164f4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x10ddff0: ldur            x0, [fp, #-8]
    // 0x10ddff4: LoadField: r1 = r0->field_1f
    //     0x10ddff4: ldur            w1, [x0, #0x1f]
    // 0x10ddff8: DecompressPointer r1
    //     0x10ddff8: add             x1, x1, HEAP, lsl #32
    // 0x10ddffc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10de000: cmp             w1, w16
    // 0x10de004: b.eq            #0x10de088
    // 0x10de008: r0 = dispose()
    //     0x10de008: bl              #0x9164f4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x10de00c: ldur            x0, [fp, #-8]
    // 0x10de010: LoadField: r1 = r0->field_23
    //     0x10de010: ldur            w1, [x0, #0x23]
    // 0x10de014: DecompressPointer r1
    //     0x10de014: add             x1, x1, HEAP, lsl #32
    // 0x10de018: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10de01c: cmp             w1, w16
    // 0x10de020: b.eq            #0x10de094
    // 0x10de024: r0 = dispose()
    //     0x10de024: bl              #0x9164f4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x10de028: ldur            x0, [fp, #-8]
    // 0x10de02c: LoadField: r1 = r0->field_27
    //     0x10de02c: ldur            w1, [x0, #0x27]
    // 0x10de030: DecompressPointer r1
    //     0x10de030: add             x1, x1, HEAP, lsl #32
    // 0x10de034: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x10de038: cmp             w1, w16
    // 0x10de03c: b.eq            #0x10de0a0
    // 0x10de040: r0 = dispose()
    //     0x10de040: bl              #0x9164f4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x10de044: ldur            x0, [fp, #-8]
    // 0x10de048: LoadField: r1 = r0->field_43
    //     0x10de048: ldur            w1, [x0, #0x43]
    // 0x10de04c: DecompressPointer r1
    //     0x10de04c: add             x1, x1, HEAP, lsl #32
    // 0x10de050: cmp             w1, NULL
    // 0x10de054: b.eq            #0x10de05c
    // 0x10de058: r0 = dispose()
    //     0x10de058: bl              #0x10ec024  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::dispose
    // 0x10de05c: ldur            x1, [fp, #-8]
    // 0x10de060: r0 = dispose()
    //     0x10de060: bl              #0x10de0ac  ; [dart:mixin_deduplication] _MixinApplication106&State&TickerProviderStateMixin::dispose
    // 0x10de064: r0 = Null
    //     0x10de064: mov             x0, NULL
    // 0x10de068: LeaveFrame
    //     0x10de068: mov             SP, fp
    //     0x10de06c: ldp             fp, lr, [SP], #0x10
    // 0x10de070: ret
    //     0x10de070: ret             
    // 0x10de074: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10de074: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10de078: b               #0x10ddfc0
    // 0x10de07c: r9 = overlayController
    //     0x10de07c: add             x9, PP, #0x99, lsl #12  ; [pp+0x99000] Field <_SliderState@125231897.overlayController>: late (offset: 0x1c)
    //     0x10de080: ldr             x9, [x9]
    // 0x10de084: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x10de084: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x10de088: r9 = valueIndicatorController
    //     0x10de088: add             x9, PP, #0x99, lsl #12  ; [pp+0x99008] Field <_SliderState@125231897.valueIndicatorController>: late (offset: 0x20)
    //     0x10de08c: ldr             x9, [x9, #8]
    // 0x10de090: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x10de090: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x10de094: r9 = enableController
    //     0x10de094: add             x9, PP, #0x99, lsl #12  ; [pp+0x99010] Field <_SliderState@125231897.enableController>: late (offset: 0x24)
    //     0x10de098: ldr             x9, [x9, #0x10]
    // 0x10de09c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x10de09c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x10de0a0: r9 = positionController
    //     0x10de0a0: add             x9, PP, #0x99, lsl #12  ; [pp+0x99018] Field <_SliderState@125231897.positionController>: late (offset: 0x28)
    //     0x10de0a4: ldr             x9, [x9, #0x18]
    // 0x10de0a8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x10de0a8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 6434, size: 0x78, field offset: 0xc
//   const constructor, 
class Slider extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xfa2e70, size: 0x48
    // 0xfa2e70: EnterFrame
    //     0xfa2e70: stp             fp, lr, [SP, #-0x10]!
    //     0xfa2e74: mov             fp, SP
    // 0xfa2e78: AllocStack(0x8)
    //     0xfa2e78: sub             SP, SP, #8
    // 0xfa2e7c: CheckStackOverflow
    //     0xfa2e7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa2e80: cmp             SP, x16
    //     0xfa2e84: b.ls            #0xfa2eb0
    // 0xfa2e88: r1 = <Slider>
    //     0xfa2e88: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f9d8] TypeArguments: <Slider>
    //     0xfa2e8c: ldr             x1, [x1, #0x9d8]
    // 0xfa2e90: r0 = _SliderState()
    //     0xfa2e90: bl              #0xfa2fb0  ; Allocate_SliderStateStub -> _SliderState (size=0x58)
    // 0xfa2e94: mov             x1, x0
    // 0xfa2e98: stur            x0, [fp, #-8]
    // 0xfa2e9c: r0 = _SliderState()
    //     0xfa2e9c: bl              #0xfa2eb8  ; [package:flutter/src/material/slider.dart] _SliderState::_SliderState
    // 0xfa2ea0: ldur            x0, [fp, #-8]
    // 0xfa2ea4: LeaveFrame
    //     0xfa2ea4: mov             SP, fp
    //     0xfa2ea8: ldp             fp, lr, [SP], #0x10
    // 0xfa2eac: ret
    //     0xfa2eac: ret             
    // 0xfa2eb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa2eb0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa2eb4: b               #0xfa2e88
  }
}

// class id: 6729, size: 0x10, field offset: 0xc
//   const constructor, 
class _ValueIndicatorRenderObjectWidget extends LeafRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xce2f50, size: 0x94
    // 0xce2f50: EnterFrame
    //     0xce2f50: stp             fp, lr, [SP, #-0x10]!
    //     0xce2f54: mov             fp, SP
    // 0xce2f58: AllocStack(0x10)
    //     0xce2f58: sub             SP, SP, #0x10
    // 0xce2f5c: SetupParameters(_ValueIndicatorRenderObjectWidget this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4 */, dynamic _ /* r3 => r0, fp-0x10 */)
    //     0xce2f5c: mov             x0, x3
    //     0xce2f60: mov             x5, x1
    //     0xce2f64: mov             x4, x2
    //     0xce2f68: stur            x1, [fp, #-8]
    //     0xce2f6c: stur            x3, [fp, #-0x10]
    // 0xce2f70: r2 = Null
    //     0xce2f70: mov             x2, NULL
    // 0xce2f74: r1 = Null
    //     0xce2f74: mov             x1, NULL
    // 0xce2f78: r4 = 60
    //     0xce2f78: mov             x4, #0x3c
    // 0xce2f7c: branchIfSmi(r0, 0xce2f88)
    //     0xce2f7c: tbz             w0, #0, #0xce2f88
    // 0xce2f80: r4 = LoadClassIdInstr(r0)
    //     0xce2f80: ldur            x4, [x0, #-1]
    //     0xce2f84: ubfx            x4, x4, #0xc, #0x14
    // 0xce2f88: r17 = 4845
    //     0xce2f88: mov             x17, #0x12ed
    // 0xce2f8c: cmp             x4, x17
    // 0xce2f90: b.eq            #0xce2fa8
    // 0xce2f94: r8 = _RenderValueIndicator
    //     0xce2f94: add             x8, PP, #0xa3, lsl #12  ; [pp+0xa3798] Type: _RenderValueIndicator
    //     0xce2f98: ldr             x8, [x8, #0x798]
    // 0xce2f9c: r3 = Null
    //     0xce2f9c: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa37a0] Null
    //     0xce2fa0: ldr             x3, [x3, #0x7a0]
    // 0xce2fa4: r0 = DefaultTypeTest()
    //     0xce2fa4: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xce2fa8: ldur            x1, [fp, #-8]
    // 0xce2fac: LoadField: r0 = r1->field_b
    //     0xce2fac: ldur            w0, [x1, #0xb]
    // 0xce2fb0: DecompressPointer r0
    //     0xce2fb0: add             x0, x0, HEAP, lsl #32
    // 0xce2fb4: ldur            x1, [fp, #-0x10]
    // 0xce2fb8: StoreField: r1->field_57 = r0
    //     0xce2fb8: stur            w0, [x1, #0x57]
    //     0xce2fbc: ldurb           w16, [x1, #-1]
    //     0xce2fc0: ldurb           w17, [x0, #-1]
    //     0xce2fc4: and             x16, x17, x16, lsr #2
    //     0xce2fc8: tst             x16, HEAP, lsr #32
    //     0xce2fcc: b.eq            #0xce2fd4
    //     0xce2fd0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xce2fd4: r0 = Null
    //     0xce2fd4: mov             x0, NULL
    // 0xce2fd8: LeaveFrame
    //     0xce2fd8: mov             SP, fp
    //     0xce2fdc: ldp             fp, lr, [SP], #0x10
    // 0xce2fe0: ret
    //     0xce2fe0: ret             
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11c09d0, size: 0x50
    // 0x11c09d0: EnterFrame
    //     0x11c09d0: stp             fp, lr, [SP, #-0x10]!
    //     0x11c09d4: mov             fp, SP
    // 0x11c09d8: AllocStack(0x8)
    //     0x11c09d8: sub             SP, SP, #8
    // 0x11c09dc: CheckStackOverflow
    //     0x11c09dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11c09e0: cmp             SP, x16
    //     0x11c09e4: b.ls            #0x11c0a18
    // 0x11c09e8: LoadField: r2 = r1->field_b
    //     0x11c09e8: ldur            w2, [x1, #0xb]
    // 0x11c09ec: DecompressPointer r2
    //     0x11c09ec: add             x2, x2, HEAP, lsl #32
    // 0x11c09f0: stur            x2, [fp, #-8]
    // 0x11c09f4: r0 = _RenderValueIndicator()
    //     0x11c09f4: bl              #0x11c0b30  ; Allocate_RenderValueIndicatorStub -> _RenderValueIndicator (size=0x5c)
    // 0x11c09f8: mov             x1, x0
    // 0x11c09fc: ldur            x2, [fp, #-8]
    // 0x11c0a00: stur            x0, [fp, #-8]
    // 0x11c0a04: r0 = _RenderValueIndicator()
    //     0x11c0a04: bl              #0x11c0a20  ; [package:flutter/src/material/slider.dart] _RenderValueIndicator::_RenderValueIndicator
    // 0x11c0a08: ldur            x0, [fp, #-8]
    // 0x11c0a0c: LeaveFrame
    //     0x11c0a0c: mov             SP, fp
    //     0x11c0a10: ldp             fp, lr, [SP], #0x10
    // 0x11c0a14: ret
    //     0x11c0a14: ret             
    // 0x11c0a18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11c0a18: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11c0a1c: b               #0x11c09e8
  }
}

// class id: 6730, size: 0x58, field offset: 0xc
//   const constructor, 
class _SliderRenderObjectWidget extends LeafRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0xce2618, size: 0x254
    // 0xce2618: EnterFrame
    //     0xce2618: stp             fp, lr, [SP, #-0x10]!
    //     0xce261c: mov             fp, SP
    // 0xce2620: AllocStack(0x18)
    //     0xce2620: sub             SP, SP, #0x18
    // 0xce2624: SetupParameters(_SliderRenderObjectWidget this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xce2624: mov             x5, x1
    //     0xce2628: mov             x4, x2
    //     0xce262c: stur            x1, [fp, #-8]
    //     0xce2630: stur            x2, [fp, #-0x10]
    //     0xce2634: stur            x3, [fp, #-0x18]
    // 0xce2638: CheckStackOverflow
    //     0xce2638: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce263c: cmp             SP, x16
    //     0xce2640: b.ls            #0xce2848
    // 0xce2644: mov             x0, x3
    // 0xce2648: r2 = Null
    //     0xce2648: mov             x2, NULL
    // 0xce264c: r1 = Null
    //     0xce264c: mov             x1, NULL
    // 0xce2650: r4 = 60
    //     0xce2650: mov             x4, #0x3c
    // 0xce2654: branchIfSmi(r0, 0xce2660)
    //     0xce2654: tbz             w0, #0, #0xce2660
    // 0xce2658: r4 = LoadClassIdInstr(r0)
    //     0xce2658: ldur            x4, [x0, #-1]
    //     0xce265c: ubfx            x4, x4, #0xc, #0x14
    // 0xce2660: r17 = 4846
    //     0xce2660: mov             x17, #0x12ee
    // 0xce2664: cmp             x4, x17
    // 0xce2668: b.eq            #0xce2680
    // 0xce266c: r8 = _RenderSlider
    //     0xce266c: add             x8, PP, #0x99, lsl #12  ; [pp+0x99038] Type: _RenderSlider
    //     0xce2670: ldr             x8, [x8, #0x38]
    // 0xce2674: r3 = Null
    //     0xce2674: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa3710] Null
    //     0xce2678: ldr             x3, [x3, #0x710]
    // 0xce267c: r0 = DefaultTypeTest()
    //     0xce267c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xce2680: ldur            x0, [fp, #-8]
    // 0xce2684: ArrayLoad: r2 = r0[0]  ; List_8
    //     0xce2684: ldur            x2, [x0, #0x17]
    // 0xce2688: ldur            x1, [fp, #-0x18]
    // 0xce268c: r0 = divisions=()
    //     0xce268c: bl              #0xce2f00  ; [package:flutter/src/material/slider.dart] _RenderSlider::divisions=
    // 0xce2690: ldur            x0, [fp, #-8]
    // 0xce2694: LoadField: d0 = r0->field_b
    //     0xce2694: ldur            d0, [x0, #0xb]
    // 0xce2698: r2 = inline_Allocate_Double()
    //     0xce2698: ldp             x2, x1, [THR, #0x60]  ; THR::top
    //     0xce269c: add             x2, x2, #0x10
    //     0xce26a0: cmp             x1, x2
    //     0xce26a4: b.ls            #0xce2850
    //     0xce26a8: str             x2, [THR, #0x60]  ; THR::top
    //     0xce26ac: sub             x2, x2, #0xf
    //     0xce26b0: mov             x1, #0xe19c
    //     0xce26b4: movk            x1, #3, lsl #16
    //     0xce26b8: stur            x1, [x2, #-1]
    // 0xce26bc: dmb             ishst
    // 0xce26c0: StoreField: r2->field_7 = d0
    //     0xce26c0: stur            d0, [x2, #7]
    // 0xce26c4: ldur            x1, [fp, #-0x18]
    // 0xce26c8: r0 = value=()
    //     0xce26c8: bl              #0xb1de64  ; [package:flutter/src/material/slider.dart] _RenderSlider::value=
    // 0xce26cc: ldur            x1, [fp, #-0x18]
    // 0xce26d0: r2 = Null
    //     0xce26d0: mov             x2, NULL
    // 0xce26d4: r0 = Shader._()
    //     0xce26d4: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xce26d8: ldur            x0, [fp, #-8]
    // 0xce26dc: LoadField: r2 = r0->field_1f
    //     0xce26dc: ldur            w2, [x0, #0x1f]
    // 0xce26e0: DecompressPointer r2
    //     0xce26e0: add             x2, x2, HEAP, lsl #32
    // 0xce26e4: ldur            x1, [fp, #-0x18]
    // 0xce26e8: r0 = label=()
    //     0xce26e8: bl              #0xce2e5c  ; [package:flutter/src/material/slider.dart] _RenderSlider::label=
    // 0xce26ec: ldur            x0, [fp, #-8]
    // 0xce26f0: LoadField: r2 = r0->field_23
    //     0xce26f0: ldur            w2, [x0, #0x23]
    // 0xce26f4: DecompressPointer r2
    //     0xce26f4: add             x2, x2, HEAP, lsl #32
    // 0xce26f8: ldur            x1, [fp, #-0x18]
    // 0xce26fc: r0 = sliderTheme=()
    //     0xce26fc: bl              #0xce2dd4  ; [package:flutter/src/material/slider.dart] _RenderSlider::sliderTheme=
    // 0xce2700: ldur            x0, [fp, #-8]
    // 0xce2704: LoadField: d0 = r0->field_27
    //     0xce2704: ldur            d0, [x0, #0x27]
    // 0xce2708: ldur            x1, [fp, #-0x18]
    // 0xce270c: r0 = textScaleFactor=()
    //     0xce270c: bl              #0xce2d84  ; [package:flutter/src/material/slider.dart] _RenderSlider::textScaleFactor=
    // 0xce2710: ldur            x0, [fp, #-8]
    // 0xce2714: LoadField: r2 = r0->field_2f
    //     0xce2714: ldur            w2, [x0, #0x2f]
    // 0xce2718: DecompressPointer r2
    //     0xce2718: add             x2, x2, HEAP, lsl #32
    // 0xce271c: ldur            x1, [fp, #-0x18]
    // 0xce2720: r0 = screenSize=()
    //     0xce2720: bl              #0xce2cfc  ; [package:flutter/src/material/slider.dart] _RenderSlider::screenSize=
    // 0xce2724: ldur            x0, [fp, #-8]
    // 0xce2728: LoadField: r2 = r0->field_33
    //     0xce2728: ldur            w2, [x0, #0x33]
    // 0xce272c: DecompressPointer r2
    //     0xce272c: add             x2, x2, HEAP, lsl #32
    // 0xce2730: ldur            x1, [fp, #-0x18]
    // 0xce2734: r0 = onChanged=()
    //     0xce2734: bl              #0xce2ba4  ; [package:flutter/src/material/slider.dart] _RenderSlider::onChanged=
    // 0xce2738: ldur            x2, [fp, #-8]
    // 0xce273c: LoadField: r0 = r2->field_37
    //     0xce273c: ldur            w0, [x2, #0x37]
    // 0xce2740: DecompressPointer r0
    //     0xce2740: add             x0, x0, HEAP, lsl #32
    // 0xce2744: ldur            x3, [fp, #-0x18]
    // 0xce2748: StoreField: r3->field_b7 = r0
    //     0xce2748: stur            w0, [x3, #0xb7]
    //     0xce274c: ldurb           w16, [x3, #-1]
    //     0xce2750: ldurb           w17, [x0, #-1]
    //     0xce2754: and             x16, x17, x16, lsr #2
    //     0xce2758: tst             x16, HEAP, lsr #32
    //     0xce275c: b.eq            #0xce2764
    //     0xce2760: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xce2764: LoadField: r0 = r2->field_3b
    //     0xce2764: ldur            w0, [x2, #0x3b]
    // 0xce2768: DecompressPointer r0
    //     0xce2768: add             x0, x0, HEAP, lsl #32
    // 0xce276c: StoreField: r3->field_bb = r0
    //     0xce276c: stur            w0, [x3, #0xbb]
    //     0xce2770: ldurb           w16, [x3, #-1]
    //     0xce2774: ldurb           w17, [x0, #-1]
    //     0xce2778: and             x16, x17, x16, lsr #2
    //     0xce277c: tst             x16, HEAP, lsr #32
    //     0xce2780: b.eq            #0xce2788
    //     0xce2784: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xce2788: ldur            x1, [fp, #-0x10]
    // 0xce278c: r0 = of()
    //     0xce278c: bl              #0x87371c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0xce2790: ldur            x1, [fp, #-0x18]
    // 0xce2794: mov             x2, x0
    // 0xce2798: r0 = textDirection=()
    //     0xce2798: bl              #0xce2b34  ; [package:flutter/src/material/slider.dart] _RenderSlider::textDirection=
    // 0xce279c: ldur            x1, [fp, #-0x18]
    // 0xce27a0: r2 = Null
    //     0xce27a0: mov             x2, NULL
    // 0xce27a4: r0 = Shader._()
    //     0xce27a4: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xce27a8: ldur            x2, [fp, #-8]
    // 0xce27ac: LoadField: r0 = r2->field_43
    //     0xce27ac: ldur            w0, [x2, #0x43]
    // 0xce27b0: DecompressPointer r0
    //     0xce27b0: add             x0, x0, HEAP, lsl #32
    // 0xce27b4: ldur            x3, [fp, #-0x18]
    // 0xce27b8: StoreField: r3->field_73 = r0
    //     0xce27b8: stur            w0, [x3, #0x73]
    //     0xce27bc: ldurb           w16, [x3, #-1]
    //     0xce27c0: ldurb           w17, [x0, #-1]
    //     0xce27c4: and             x16, x17, x16, lsr #2
    //     0xce27c8: tst             x16, HEAP, lsr #32
    //     0xce27cc: b.eq            #0xce27d4
    //     0xce27d0: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xce27d4: ldur            x1, [fp, #-0x10]
    // 0xce27d8: r0 = of()
    //     0xce27d8: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xce27dc: ldur            x1, [fp, #-0x18]
    // 0xce27e0: r2 = Instance_TargetPlatform
    //     0xce27e0: add             x2, PP, #0x12, lsl #12  ; [pp+0x12940] Obj!TargetPlatform@12c5e81
    //     0xce27e4: ldr             x2, [x2, #0x940]
    // 0xce27e8: r0 = Shader._()
    //     0xce27e8: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xce27ec: ldur            x0, [fp, #-8]
    // 0xce27f0: LoadField: r2 = r0->field_4b
    //     0xce27f0: ldur            w2, [x0, #0x4b]
    // 0xce27f4: DecompressPointer r2
    //     0xce27f4: add             x2, x2, HEAP, lsl #32
    // 0xce27f8: ldur            x1, [fp, #-0x18]
    // 0xce27fc: r0 = hasFocus=()
    //     0xce27fc: bl              #0xce29b0  ; [package:flutter/src/material/slider.dart] _RenderSlider::hasFocus=
    // 0xce2800: ldur            x0, [fp, #-8]
    // 0xce2804: LoadField: r2 = r0->field_4f
    //     0xce2804: ldur            w2, [x0, #0x4f]
    // 0xce2808: DecompressPointer r2
    //     0xce2808: add             x2, x2, HEAP, lsl #32
    // 0xce280c: ldur            x1, [fp, #-0x18]
    // 0xce2810: r0 = hovering=()
    //     0xce2810: bl              #0xce295c  ; [package:flutter/src/material/slider.dart] _RenderSlider::hovering=
    // 0xce2814: ldur            x1, [fp, #-0x10]
    // 0xce2818: r0 = gestureSettingsOf()
    //     0xce2818: bl              #0xce2910  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::gestureSettingsOf
    // 0xce281c: ldur            x1, [fp, #-0x18]
    // 0xce2820: mov             x2, x0
    // 0xce2824: r0 = gestureSettings=()
    //     0xce2824: bl              #0xce286c  ; [package:flutter/src/material/slider.dart] _RenderSlider::gestureSettings=
    // 0xce2828: ldur            x1, [fp, #-0x18]
    // 0xce282c: r2 = Instance_SliderInteraction
    //     0xce282c: add             x2, PP, #0x98, lsl #12  ; [pp+0x98f08] Obj!SliderInteraction@12c4f41
    //     0xce2830: ldr             x2, [x2, #0xf08]
    // 0xce2834: r0 = Shader._()
    //     0xce2834: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xce2838: r0 = Null
    //     0xce2838: mov             x0, NULL
    // 0xce283c: LeaveFrame
    //     0xce283c: mov             SP, fp
    //     0xce2840: ldp             fp, lr, [SP], #0x10
    // 0xce2844: ret
    //     0xce2844: ret             
    // 0xce2848: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce2848: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce284c: b               #0xce2644
    // 0xce2850: SaveReg d0
    //     0xce2850: str             q0, [SP, #-0x10]!
    // 0xce2854: SaveReg r0
    //     0xce2854: str             x0, [SP, #-8]!
    // 0xce2858: r0 = AllocateDouble()
    //     0xce2858: bl              #0x13df878  ; AllocateDoubleStub
    // 0xce285c: mov             x2, x0
    // 0xce2860: RestoreReg r0
    //     0xce2860: ldr             x0, [SP], #8
    // 0xce2864: RestoreReg d0
    //     0xce2864: ldr             q0, [SP], #0x10
    // 0xce2868: b               #0xce26c0
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x11bfa18, size: 0x158
    // 0x11bfa18: EnterFrame
    //     0x11bfa18: stp             fp, lr, [SP, #-0x10]!
    //     0x11bfa1c: mov             fp, SP
    // 0x11bfa20: AllocStack(0xc0)
    //     0x11bfa20: sub             SP, SP, #0xc0
    // 0x11bfa24: SetupParameters(_SliderRenderObjectWidget this /* r1 => r2, fp-0x48 */, dynamic _ /* r2 => r0, fp-0x50 */)
    //     0x11bfa24: mov             x0, x2
    //     0x11bfa28: stur            x2, [fp, #-0x50]
    //     0x11bfa2c: mov             x2, x1
    //     0x11bfa30: stur            x1, [fp, #-0x48]
    // 0x11bfa34: CheckStackOverflow
    //     0x11bfa34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11bfa38: cmp             SP, x16
    //     0x11bfa3c: b.ls            #0x11bfb68
    // 0x11bfa40: LoadField: d1 = r2->field_b
    //     0x11bfa40: ldur            d1, [x2, #0xb]
    // 0x11bfa44: stur            d1, [fp, #-0x80]
    // 0x11bfa48: ArrayLoad: r3 = r2[0]  ; List_8
    //     0x11bfa48: ldur            x3, [x2, #0x17]
    // 0x11bfa4c: stur            x3, [fp, #-0x40]
    // 0x11bfa50: LoadField: r7 = r2->field_1f
    //     0x11bfa50: ldur            w7, [x2, #0x1f]
    // 0x11bfa54: DecompressPointer r7
    //     0x11bfa54: add             x7, x7, HEAP, lsl #32
    // 0x11bfa58: stur            x7, [fp, #-0x38]
    // 0x11bfa5c: LoadField: r4 = r2->field_23
    //     0x11bfa5c: ldur            w4, [x2, #0x23]
    // 0x11bfa60: DecompressPointer r4
    //     0x11bfa60: add             x4, x4, HEAP, lsl #32
    // 0x11bfa64: stur            x4, [fp, #-0x30]
    // 0x11bfa68: LoadField: d0 = r2->field_27
    //     0x11bfa68: ldur            d0, [x2, #0x27]
    // 0x11bfa6c: stur            d0, [fp, #-0x78]
    // 0x11bfa70: LoadField: r5 = r2->field_2f
    //     0x11bfa70: ldur            w5, [x2, #0x2f]
    // 0x11bfa74: DecompressPointer r5
    //     0x11bfa74: add             x5, x5, HEAP, lsl #32
    // 0x11bfa78: stur            x5, [fp, #-0x28]
    // 0x11bfa7c: LoadField: r6 = r2->field_33
    //     0x11bfa7c: ldur            w6, [x2, #0x33]
    // 0x11bfa80: DecompressPointer r6
    //     0x11bfa80: add             x6, x6, HEAP, lsl #32
    // 0x11bfa84: stur            x6, [fp, #-0x20]
    // 0x11bfa88: LoadField: r8 = r2->field_37
    //     0x11bfa88: ldur            w8, [x2, #0x37]
    // 0x11bfa8c: DecompressPointer r8
    //     0x11bfa8c: add             x8, x8, HEAP, lsl #32
    // 0x11bfa90: stur            x8, [fp, #-0x18]
    // 0x11bfa94: LoadField: r9 = r2->field_3b
    //     0x11bfa94: ldur            w9, [x2, #0x3b]
    // 0x11bfa98: DecompressPointer r9
    //     0x11bfa98: add             x9, x9, HEAP, lsl #32
    // 0x11bfa9c: stur            x9, [fp, #-0x10]
    // 0x11bfaa0: LoadField: r10 = r2->field_47
    //     0x11bfaa0: ldur            w10, [x2, #0x47]
    // 0x11bfaa4: DecompressPointer r10
    //     0x11bfaa4: add             x10, x10, HEAP, lsl #32
    // 0x11bfaa8: mov             x1, x0
    // 0x11bfaac: stur            x10, [fp, #-8]
    // 0x11bfab0: r0 = of()
    //     0x11bfab0: bl              #0x87371c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0x11bfab4: mov             x2, x0
    // 0x11bfab8: ldur            x0, [fp, #-0x48]
    // 0x11bfabc: stur            x2, [fp, #-0x60]
    // 0x11bfac0: LoadField: r3 = r0->field_43
    //     0x11bfac0: ldur            w3, [x0, #0x43]
    // 0x11bfac4: DecompressPointer r3
    //     0x11bfac4: add             x3, x3, HEAP, lsl #32
    // 0x11bfac8: ldur            x1, [fp, #-0x50]
    // 0x11bfacc: stur            x3, [fp, #-0x58]
    // 0x11bfad0: r0 = of()
    //     0x11bfad0: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x11bfad4: ldur            x0, [fp, #-0x48]
    // 0x11bfad8: LoadField: r5 = r0->field_4b
    //     0x11bfad8: ldur            w5, [x0, #0x4b]
    // 0x11bfadc: DecompressPointer r5
    //     0x11bfadc: add             x5, x5, HEAP, lsl #32
    // 0x11bfae0: stur            x5, [fp, #-0x70]
    // 0x11bfae4: LoadField: r6 = r0->field_4f
    //     0x11bfae4: ldur            w6, [x0, #0x4f]
    // 0x11bfae8: DecompressPointer r6
    //     0x11bfae8: add             x6, x6, HEAP, lsl #32
    // 0x11bfaec: ldur            x1, [fp, #-0x50]
    // 0x11bfaf0: stur            x6, [fp, #-0x68]
    // 0x11bfaf4: r0 = gestureSettingsOf()
    //     0x11bfaf4: bl              #0xce2910  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::gestureSettingsOf
    // 0x11bfaf8: stur            x0, [fp, #-0x48]
    // 0x11bfafc: r0 = _RenderSlider()
    //     0x11bfafc: bl              #0x11c09c4  ; Allocate_RenderSliderStub -> _RenderSlider (size=0xd4)
    // 0x11bfb00: stur            x0, [fp, #-0x50]
    // 0x11bfb04: ldur            x16, [fp, #-0x10]
    // 0x11bfb08: ldur            lr, [fp, #-0x18]
    // 0x11bfb0c: stp             lr, x16, [SP, #0x30]
    // 0x11bfb10: ldur            x16, [fp, #-0x20]
    // 0x11bfb14: ldur            lr, [fp, #-0x58]
    // 0x11bfb18: stp             lr, x16, [SP, #0x20]
    // 0x11bfb1c: ldur            x16, [fp, #-0x28]
    // 0x11bfb20: ldur            lr, [fp, #-0x30]
    // 0x11bfb24: stp             lr, x16, [SP, #0x10]
    // 0x11bfb28: ldur            x16, [fp, #-8]
    // 0x11bfb2c: ldur            lr, [fp, #-0x60]
    // 0x11bfb30: stp             lr, x16, [SP]
    // 0x11bfb34: mov             x1, x0
    // 0x11bfb38: ldur            x2, [fp, #-0x40]
    // 0x11bfb3c: ldur            x3, [fp, #-0x48]
    // 0x11bfb40: ldur            x5, [fp, #-0x70]
    // 0x11bfb44: ldur            x6, [fp, #-0x68]
    // 0x11bfb48: ldur            x7, [fp, #-0x38]
    // 0x11bfb4c: ldur            d0, [fp, #-0x78]
    // 0x11bfb50: ldur            d1, [fp, #-0x80]
    // 0x11bfb54: r0 = _RenderSlider()
    //     0x11bfb54: bl              #0x11bfb70  ; [package:flutter/src/material/slider.dart] _RenderSlider::_RenderSlider
    // 0x11bfb58: ldur            x0, [fp, #-0x50]
    // 0x11bfb5c: LeaveFrame
    //     0x11bfb5c: mov             SP, fp
    //     0x11bfb60: ldp             fp, lr, [SP], #0x10
    // 0x11bfb64: ret
    //     0x11bfb64: ret             
    // 0x11bfb68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11bfb68: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11bfb6c: b               #0x11bfa40
  }
}

// class id: 8265, size: 0x14, field offset: 0x14
enum _SliderAdjustmentType extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11aa800, size: 0x64
    // 0x11aa800: EnterFrame
    //     0x11aa800: stp             fp, lr, [SP, #-0x10]!
    //     0x11aa804: mov             fp, SP
    // 0x11aa808: AllocStack(0x10)
    //     0x11aa808: sub             SP, SP, #0x10
    // 0x11aa80c: SetupParameters(_SliderAdjustmentType this /* r1 => r0, fp-0x8 */)
    //     0x11aa80c: mov             x0, x1
    //     0x11aa810: stur            x1, [fp, #-8]
    // 0x11aa814: CheckStackOverflow
    //     0x11aa814: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11aa818: cmp             SP, x16
    //     0x11aa81c: b.ls            #0x11aa85c
    // 0x11aa820: r1 = Null
    //     0x11aa820: mov             x1, NULL
    // 0x11aa824: r2 = 4
    //     0x11aa824: mov             x2, #4
    // 0x11aa828: r0 = AllocateArray()
    //     0x11aa828: bl              #0x13df928  ; AllocateArrayStub
    // 0x11aa82c: r16 = "_SliderAdjustmentType."
    //     0x11aa82c: add             x16, PP, #0xa3, lsl #12  ; [pp+0xa3700] "_SliderAdjustmentType."
    //     0x11aa830: ldr             x16, [x16, #0x700]
    // 0x11aa834: StoreField: r0->field_f = r16
    //     0x11aa834: stur            w16, [x0, #0xf]
    // 0x11aa838: ldur            x1, [fp, #-8]
    // 0x11aa83c: LoadField: r2 = r1->field_f
    //     0x11aa83c: ldur            w2, [x1, #0xf]
    // 0x11aa840: DecompressPointer r2
    //     0x11aa840: add             x2, x2, HEAP, lsl #32
    // 0x11aa844: StoreField: r0->field_13 = r2
    //     0x11aa844: stur            w2, [x0, #0x13]
    // 0x11aa848: str             x0, [SP]
    // 0x11aa84c: r0 = _interpolate()
    //     0x11aa84c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11aa850: LeaveFrame
    //     0x11aa850: mov             SP, fp
    //     0x11aa854: ldp             fp, lr, [SP], #0x10
    // 0x11aa858: ret
    //     0x11aa858: ret             
    // 0x11aa85c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11aa85c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11aa860: b               #0x11aa820
  }
}

// class id: 8266, size: 0x14, field offset: 0x14
enum SliderInteraction extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11aa79c, size: 0x64
    // 0x11aa79c: EnterFrame
    //     0x11aa79c: stp             fp, lr, [SP, #-0x10]!
    //     0x11aa7a0: mov             fp, SP
    // 0x11aa7a4: AllocStack(0x10)
    //     0x11aa7a4: sub             SP, SP, #0x10
    // 0x11aa7a8: SetupParameters(SliderInteraction this /* r1 => r0, fp-0x8 */)
    //     0x11aa7a8: mov             x0, x1
    //     0x11aa7ac: stur            x1, [fp, #-8]
    // 0x11aa7b0: CheckStackOverflow
    //     0x11aa7b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11aa7b4: cmp             SP, x16
    //     0x11aa7b8: b.ls            #0x11aa7f8
    // 0x11aa7bc: r1 = Null
    //     0x11aa7bc: mov             x1, NULL
    // 0x11aa7c0: r2 = 4
    //     0x11aa7c0: mov             x2, #4
    // 0x11aa7c4: r0 = AllocateArray()
    //     0x11aa7c4: bl              #0x13df928  ; AllocateArrayStub
    // 0x11aa7c8: r16 = "SliderInteraction."
    //     0x11aa7c8: add             x16, PP, #0xa3, lsl #12  ; [pp+0xa3708] "SliderInteraction."
    //     0x11aa7cc: ldr             x16, [x16, #0x708]
    // 0x11aa7d0: StoreField: r0->field_f = r16
    //     0x11aa7d0: stur            w16, [x0, #0xf]
    // 0x11aa7d4: ldur            x1, [fp, #-8]
    // 0x11aa7d8: LoadField: r2 = r1->field_f
    //     0x11aa7d8: ldur            w2, [x1, #0xf]
    // 0x11aa7dc: DecompressPointer r2
    //     0x11aa7dc: add             x2, x2, HEAP, lsl #32
    // 0x11aa7e0: StoreField: r0->field_13 = r2
    //     0x11aa7e0: stur            w2, [x0, #0x13]
    // 0x11aa7e4: str             x0, [SP]
    // 0x11aa7e8: r0 = _interpolate()
    //     0x11aa7e8: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11aa7ec: LeaveFrame
    //     0x11aa7ec: mov             SP, fp
    //     0x11aa7f0: ldp             fp, lr, [SP], #0x10
    // 0x11aa7f4: ret
    //     0x11aa7f4: ret             
    // 0x11aa7f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11aa7f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11aa7fc: b               #0x11aa7bc
  }
}

// class id: 8267, size: 0x14, field offset: 0x14
enum _SliderType extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11aa738, size: 0x64
    // 0x11aa738: EnterFrame
    //     0x11aa738: stp             fp, lr, [SP, #-0x10]!
    //     0x11aa73c: mov             fp, SP
    // 0x11aa740: AllocStack(0x10)
    //     0x11aa740: sub             SP, SP, #0x10
    // 0x11aa744: SetupParameters(_SliderType this /* r1 => r0, fp-0x8 */)
    //     0x11aa744: mov             x0, x1
    //     0x11aa748: stur            x1, [fp, #-8]
    // 0x11aa74c: CheckStackOverflow
    //     0x11aa74c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11aa750: cmp             SP, x16
    //     0x11aa754: b.ls            #0x11aa794
    // 0x11aa758: r1 = Null
    //     0x11aa758: mov             x1, NULL
    // 0x11aa75c: r2 = 4
    //     0x11aa75c: mov             x2, #4
    // 0x11aa760: r0 = AllocateArray()
    //     0x11aa760: bl              #0x13df928  ; AllocateArrayStub
    // 0x11aa764: r16 = "_SliderType."
    //     0x11aa764: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8f9d0] "_SliderType."
    //     0x11aa768: ldr             x16, [x16, #0x9d0]
    // 0x11aa76c: StoreField: r0->field_f = r16
    //     0x11aa76c: stur            w16, [x0, #0xf]
    // 0x11aa770: ldur            x1, [fp, #-8]
    // 0x11aa774: LoadField: r2 = r1->field_f
    //     0x11aa774: ldur            w2, [x1, #0xf]
    // 0x11aa778: DecompressPointer r2
    //     0x11aa778: add             x2, x2, HEAP, lsl #32
    // 0x11aa77c: StoreField: r0->field_13 = r2
    //     0x11aa77c: stur            w2, [x0, #0x13]
    // 0x11aa780: str             x0, [SP]
    // 0x11aa784: r0 = _interpolate()
    //     0x11aa784: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11aa788: LeaveFrame
    //     0x11aa788: mov             SP, fp
    //     0x11aa78c: ldp             fp, lr, [SP], #0x10
    // 0x11aa790: ret
    //     0x11aa790: ret             
    // 0x11aa794: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11aa794: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11aa798: b               #0x11aa758
  }
}
