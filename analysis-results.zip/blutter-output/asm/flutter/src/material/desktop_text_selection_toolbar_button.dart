// lib: , url: package:flutter/src/material/desktop_text_selection_toolbar_button.dart

// class id: 1048879, size: 0x8
class :: {
}

// class id: 6167, size: 0x14, field offset: 0xc
//   const constructor, 
class DesktopTextSelectionToolbarButton extends StatelessWidget {

  _ DesktopTextSelectionToolbarButton.text(/* No info */) {
    // ** addr: 0xfaf5ec, size: 0xfc
    // 0xfaf5ec: EnterFrame
    //     0xfaf5ec: stp             fp, lr, [SP, #-0x10]!
    //     0xfaf5f0: mov             fp, SP
    // 0xfaf5f4: AllocStack(0x20)
    //     0xfaf5f4: sub             SP, SP, #0x20
    // 0xfaf5f8: SetupParameters(DesktopTextSelectionToolbarButton this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xfaf5f8: stur            x1, [fp, #-8]
    //     0xfaf5fc: mov             x16, x2
    //     0xfaf600: mov             x2, x1
    //     0xfaf604: mov             x1, x16
    //     0xfaf608: mov             x0, x3
    //     0xfaf60c: stur            x5, [fp, #-0x10]
    // 0xfaf610: CheckStackOverflow
    //     0xfaf610: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfaf614: cmp             SP, x16
    //     0xfaf618: b.ls            #0xfaf6e0
    // 0xfaf61c: StoreField: r2->field_b = r0
    //     0xfaf61c: stur            w0, [x2, #0xb]
    //     0xfaf620: ldurb           w16, [x2, #-1]
    //     0xfaf624: ldurb           w17, [x0, #-1]
    //     0xfaf628: and             x16, x17, x16, lsr #2
    //     0xfaf62c: tst             x16, HEAP, lsr #32
    //     0xfaf630: b.eq            #0xfaf638
    //     0xfaf634: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xfaf638: r0 = of()
    //     0xfaf638: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfaf63c: LoadField: r1 = r0->field_3f
    //     0xfaf63c: ldur            w1, [x0, #0x3f]
    // 0xfaf640: DecompressPointer r1
    //     0xfaf640: add             x1, x1, HEAP, lsl #32
    // 0xfaf644: LoadField: r0 = r1->field_7
    //     0xfaf644: ldur            w0, [x1, #7]
    // 0xfaf648: DecompressPointer r0
    //     0xfaf648: add             x0, x0, HEAP, lsl #32
    // 0xfaf64c: r16 = Instance_Brightness
    //     0xfaf64c: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0xfaf650: cmp             w0, w16
    // 0xfaf654: b.ne            #0xfaf664
    // 0xfaf658: r1 = Instance_Color
    //     0xfaf658: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0xfaf65c: ldr             x1, [x1, #0xc38]
    // 0xfaf660: b               #0xfaf66c
    // 0xfaf664: r1 = Instance_Color
    //     0xfaf664: add             x1, PP, #0x19, lsl #12  ; [pp+0x19c48] Obj!Color@12a15f1
    //     0xfaf668: ldr             x1, [x1, #0xc48]
    // 0xfaf66c: ldur            x2, [fp, #-8]
    // 0xfaf670: ldur            x0, [fp, #-0x10]
    // 0xfaf674: str             x1, [SP]
    // 0xfaf678: r1 = Instance_TextStyle
    //     0xfaf678: add             x1, PP, #0x80, lsl #12  ; [pp+0x80a20] Obj!TextStyle@12b0c41
    //     0xfaf67c: ldr             x1, [x1, #0xa20]
    // 0xfaf680: r4 = const [0, 0x2, 0x1, 0x1, color, 0x1, null]
    //     0xfaf680: add             x4, PP, #0x15, lsl #12  ; [pp+0x157f0] List(7) [0, 0x2, 0x1, 0x1, "color", 0x1, Null]
    //     0xfaf684: ldr             x4, [x4, #0x7f0]
    // 0xfaf688: r0 = copyWith()
    //     0xfaf688: bl              #0x8a5ba4  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xfaf68c: stur            x0, [fp, #-0x18]
    // 0xfaf690: r0 = Text()
    //     0xfaf690: bl              #0x8a70a4  ; AllocateTextStub -> Text (size=0x50)
    // 0xfaf694: ldur            x1, [fp, #-0x10]
    // 0xfaf698: StoreField: r0->field_b = r1
    //     0xfaf698: stur            w1, [x0, #0xb]
    // 0xfaf69c: ldur            x1, [fp, #-0x18]
    // 0xfaf6a0: StoreField: r0->field_13 = r1
    //     0xfaf6a0: stur            w1, [x0, #0x13]
    // 0xfaf6a4: r1 = Instance_TextOverflow
    //     0xfaf6a4: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1ac18] Obj!TextOverflow@12c47a1
    //     0xfaf6a8: ldr             x1, [x1, #0xc18]
    // 0xfaf6ac: StoreField: r0->field_2b = r1
    //     0xfaf6ac: stur            w1, [x0, #0x2b]
    // 0xfaf6b0: ldur            x1, [fp, #-8]
    // 0xfaf6b4: StoreField: r1->field_f = r0
    //     0xfaf6b4: stur            w0, [x1, #0xf]
    //     0xfaf6b8: ldurb           w16, [x1, #-1]
    //     0xfaf6bc: ldurb           w17, [x0, #-1]
    //     0xfaf6c0: and             x16, x17, x16, lsr #2
    //     0xfaf6c4: tst             x16, HEAP, lsr #32
    //     0xfaf6c8: b.eq            #0xfaf6d0
    //     0xfaf6cc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfaf6d0: r0 = Null
    //     0xfaf6d0: mov             x0, NULL
    // 0xfaf6d4: LeaveFrame
    //     0xfaf6d4: mov             SP, fp
    //     0xfaf6d8: ldp             fp, lr, [SP], #0x10
    // 0xfaf6dc: ret
    //     0xfaf6dc: ret             
    // 0xfaf6e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfaf6e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfaf6e4: b               #0xfaf61c
  }
  _ build(/* No info */) {
    // ** addr: 0xfb71bc, size: 0x128
    // 0xfb71bc: EnterFrame
    //     0xfb71bc: stp             fp, lr, [SP, #-0x10]!
    //     0xfb71c0: mov             fp, SP
    // 0xfb71c4: AllocStack(0x58)
    //     0xfb71c4: sub             SP, SP, #0x58
    // 0xfb71c8: SetupParameters(DesktopTextSelectionToolbarButton this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1 */)
    //     0xfb71c8: mov             x0, x1
    //     0xfb71cc: stur            x1, [fp, #-8]
    //     0xfb71d0: mov             x1, x2
    // 0xfb71d4: CheckStackOverflow
    //     0xfb71d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfb71d8: cmp             SP, x16
    //     0xfb71dc: b.ls            #0xfb72dc
    // 0xfb71e0: r0 = of()
    //     0xfb71e0: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xfb71e4: LoadField: r1 = r0->field_3f
    //     0xfb71e4: ldur            w1, [x0, #0x3f]
    // 0xfb71e8: DecompressPointer r1
    //     0xfb71e8: add             x1, x1, HEAP, lsl #32
    // 0xfb71ec: LoadField: r0 = r1->field_7
    //     0xfb71ec: ldur            w0, [x1, #7]
    // 0xfb71f0: DecompressPointer r0
    //     0xfb71f0: add             x0, x0, HEAP, lsl #32
    // 0xfb71f4: r16 = Instance_Brightness
    //     0xfb71f4: ldr             x16, [PP, #0x6d90]  ; [pp+0x6d90] Obj!Brightness@12c71e1
    // 0xfb71f8: cmp             w0, w16
    // 0xfb71fc: b.ne            #0xfb720c
    // 0xfb7200: r1 = Instance_Color
    //     0xfb7200: add             x1, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0xfb7204: ldr             x1, [x1, #0xc38]
    // 0xfb7208: b               #0xfb7214
    // 0xfb720c: r1 = Instance_Color
    //     0xfb720c: add             x1, PP, #0x19, lsl #12  ; [pp+0x19c48] Obj!Color@12a15f1
    //     0xfb7210: ldr             x1, [x1, #0xc48]
    // 0xfb7214: ldur            x0, [fp, #-8]
    // 0xfb7218: r16 = Instance_Alignment
    //     0xfb7218: add             x16, PP, #0x19, lsl #12  ; [pp+0x19f88] Obj!Alignment@129e811
    //     0xfb721c: ldr             x16, [x16, #0xf88]
    // 0xfb7220: r30 = Instance_SystemMouseCursor
    //     0xfb7220: ldr             lr, [PP, #0x21b0]  ; [pp+0x21b0] Obj!SystemMouseCursor@12b3201
    // 0xfb7224: stp             lr, x16, [SP, #0x28]
    // 0xfb7228: r16 = Instance_SystemMouseCursor
    //     0xfb7228: ldr             x16, [PP, #0x21b0]  ; [pp+0x21b0] Obj!SystemMouseCursor@12b3201
    // 0xfb722c: stp             x1, x16, [SP, #0x18]
    // 0xfb7230: r16 = Instance_RoundedRectangleBorder
    //     0xfb7230: add             x16, PP, #0x26, lsl #12  ; [pp+0x26600] Obj!RoundedRectangleBorder@129ec31
    //     0xfb7234: ldr             x16, [x16, #0x600]
    // 0xfb7238: r30 = Instance_Size
    //     0xfb7238: add             lr, PP, #0x8c, lsl #12  ; [pp+0x8c970] Obj!Size@12a7891
    //     0xfb723c: ldr             lr, [lr, #0x970]
    // 0xfb7240: stp             lr, x16, [SP, #8]
    // 0xfb7244: r16 = Instance_EdgeInsets
    //     0xfb7244: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8c978] Obj!EdgeInsets@129dc81
    //     0xfb7248: ldr             x16, [x16, #0x978]
    // 0xfb724c: str             x16, [SP]
    // 0xfb7250: r4 = const [0, 0x7, 0x7, 0, alignment, 0, disabledMouseCursor, 0x2, enabledMouseCursor, 0x1, foregroundColor, 0x3, minimumSize, 0x5, padding, 0x6, shape, 0x4, null]
    //     0xfb7250: add             x4, PP, #0x8c, lsl #12  ; [pp+0x8c980] List(19) [0, 0x7, 0x7, 0, "alignment", 0, "disabledMouseCursor", 0x2, "enabledMouseCursor", 0x1, "foregroundColor", 0x3, "minimumSize", 0x5, "padding", 0x6, "shape", 0x4, Null]
    //     0xfb7254: ldr             x4, [x4, #0x980]
    // 0xfb7258: r0 = styleFrom()
    //     0xfb7258: bl              #0xd16538  ; [package:flutter/src/material/text_button.dart] TextButton::styleFrom
    // 0xfb725c: mov             x1, x0
    // 0xfb7260: ldur            x0, [fp, #-8]
    // 0xfb7264: stur            x1, [fp, #-0x20]
    // 0xfb7268: LoadField: r2 = r0->field_b
    //     0xfb7268: ldur            w2, [x0, #0xb]
    // 0xfb726c: DecompressPointer r2
    //     0xfb726c: add             x2, x2, HEAP, lsl #32
    // 0xfb7270: stur            x2, [fp, #-0x18]
    // 0xfb7274: LoadField: r3 = r0->field_f
    //     0xfb7274: ldur            w3, [x0, #0xf]
    // 0xfb7278: DecompressPointer r3
    //     0xfb7278: add             x3, x3, HEAP, lsl #32
    // 0xfb727c: stur            x3, [fp, #-0x10]
    // 0xfb7280: r0 = TextButton()
    //     0xfb7280: bl              #0xd1652c  ; AllocateTextButtonStub -> TextButton (size=0x40)
    // 0xfb7284: mov             x1, x0
    // 0xfb7288: r0 = false
    //     0xfb7288: add             x0, NULL, #0x30  ; false
    // 0xfb728c: stur            x1, [fp, #-8]
    // 0xfb7290: StoreField: r1->field_3b = r0
    //     0xfb7290: stur            w0, [x1, #0x3b]
    // 0xfb7294: ldur            x2, [fp, #-0x18]
    // 0xfb7298: StoreField: r1->field_b = r2
    //     0xfb7298: stur            w2, [x1, #0xb]
    // 0xfb729c: ldur            x2, [fp, #-0x20]
    // 0xfb72a0: StoreField: r1->field_1b = r2
    //     0xfb72a0: stur            w2, [x1, #0x1b]
    // 0xfb72a4: StoreField: r1->field_27 = r0
    //     0xfb72a4: stur            w0, [x1, #0x27]
    // 0xfb72a8: r0 = true
    //     0xfb72a8: add             x0, NULL, #0x20  ; true
    // 0xfb72ac: StoreField: r1->field_2f = r0
    //     0xfb72ac: stur            w0, [x1, #0x2f]
    // 0xfb72b0: ldur            x0, [fp, #-0x10]
    // 0xfb72b4: StoreField: r1->field_37 = r0
    //     0xfb72b4: stur            w0, [x1, #0x37]
    // 0xfb72b8: r0 = SizedBox()
    //     0xfb72b8: bl              #0x8a7210  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0xfb72bc: r1 = inf
    //     0xfb72bc: add             x1, PP, #0x15, lsl #12  ; [pp+0x158a8] inf
    //     0xfb72c0: ldr             x1, [x1, #0x8a8]
    // 0xfb72c4: StoreField: r0->field_f = r1
    //     0xfb72c4: stur            w1, [x0, #0xf]
    // 0xfb72c8: ldur            x1, [fp, #-8]
    // 0xfb72cc: StoreField: r0->field_b = r1
    //     0xfb72cc: stur            w1, [x0, #0xb]
    // 0xfb72d0: LeaveFrame
    //     0xfb72d0: mov             SP, fp
    //     0xfb72d4: ldp             fp, lr, [SP], #0x10
    // 0xfb72d8: ret
    //     0xfb72d8: ret             
    // 0xfb72dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfb72dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfb72e0: b               #0xfb71e0
  }
}
