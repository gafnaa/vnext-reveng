// lib: , url: package:flutter/src/material/menu_button_theme.dart

// class id: 1048916, size: 0x8
class :: {
}

// class id: 5138, size: 0xc, field offset: 0x8
//   const constructor, 
class MenuButtonThemeData extends _MixinApplication3&Object&Diagnosticable {

  static _ lerp(/* No info */) {
    // ** addr: 0x1166a18, size: 0x6c
    // 0x1166a18: EnterFrame
    //     0x1166a18: stp             fp, lr, [SP, #-0x10]!
    //     0x1166a1c: mov             fp, SP
    // 0x1166a20: AllocStack(0x8)
    //     0x1166a20: sub             SP, SP, #8
    // 0x1166a24: SetupParameters(dynamic _ /* r1 => r0 */)
    //     0x1166a24: mov             x0, x1
    // 0x1166a28: CheckStackOverflow
    //     0x1166a28: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1166a2c: cmp             SP, x16
    //     0x1166a30: b.ls            #0x1166a7c
    // 0x1166a34: cmp             w0, w2
    // 0x1166a38: b.ne            #0x1166a48
    // 0x1166a3c: LeaveFrame
    //     0x1166a3c: mov             SP, fp
    //     0x1166a40: ldp             fp, lr, [SP], #0x10
    // 0x1166a44: ret
    //     0x1166a44: ret             
    // 0x1166a48: LoadField: r1 = r0->field_7
    //     0x1166a48: ldur            w1, [x0, #7]
    // 0x1166a4c: DecompressPointer r1
    //     0x1166a4c: add             x1, x1, HEAP, lsl #32
    // 0x1166a50: LoadField: r0 = r2->field_7
    //     0x1166a50: ldur            w0, [x2, #7]
    // 0x1166a54: DecompressPointer r0
    //     0x1166a54: add             x0, x0, HEAP, lsl #32
    // 0x1166a58: mov             x2, x0
    // 0x1166a5c: r0 = lerp()
    //     0x1166a5c: bl              #0x1164644  ; [package:flutter/src/material/button_style.dart] ButtonStyle::lerp
    // 0x1166a60: stur            x0, [fp, #-8]
    // 0x1166a64: r0 = MenuButtonThemeData()
    //     0x1166a64: bl              #0x1166a84  ; AllocateMenuButtonThemeDataStub -> MenuButtonThemeData (size=0xc)
    // 0x1166a68: ldur            x1, [fp, #-8]
    // 0x1166a6c: StoreField: r0->field_7 = r1
    //     0x1166a6c: stur            w1, [x0, #7]
    // 0x1166a70: LeaveFrame
    //     0x1166a70: mov             SP, fp
    //     0x1166a74: ldp             fp, lr, [SP], #0x10
    // 0x1166a78: ret
    //     0x1166a78: ret             
    // 0x1166a7c: r0 = StackOverflowSharedWithFPURegs()
    //     0x1166a7c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1166a80: b               #0x1166a34
  }
  _ ==(/* No info */) {
    // ** addr: 0x126fb18, size: 0xfc
    // 0x126fb18: EnterFrame
    //     0x126fb18: stp             fp, lr, [SP, #-0x10]!
    //     0x126fb1c: mov             fp, SP
    // 0x126fb20: AllocStack(0x10)
    //     0x126fb20: sub             SP, SP, #0x10
    // 0x126fb24: CheckStackOverflow
    //     0x126fb24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x126fb28: cmp             SP, x16
    //     0x126fb2c: b.ls            #0x126fc0c
    // 0x126fb30: ldr             x0, [fp, #0x10]
    // 0x126fb34: cmp             w0, NULL
    // 0x126fb38: b.ne            #0x126fb4c
    // 0x126fb3c: r0 = false
    //     0x126fb3c: add             x0, NULL, #0x30  ; false
    // 0x126fb40: LeaveFrame
    //     0x126fb40: mov             SP, fp
    //     0x126fb44: ldp             fp, lr, [SP], #0x10
    // 0x126fb48: ret
    //     0x126fb48: ret             
    // 0x126fb4c: ldr             x1, [fp, #0x18]
    // 0x126fb50: cmp             w1, w0
    // 0x126fb54: b.ne            #0x126fb68
    // 0x126fb58: r0 = true
    //     0x126fb58: add             x0, NULL, #0x20  ; true
    // 0x126fb5c: LeaveFrame
    //     0x126fb5c: mov             SP, fp
    //     0x126fb60: ldp             fp, lr, [SP], #0x10
    // 0x126fb64: ret
    //     0x126fb64: ret             
    // 0x126fb68: str             x0, [SP]
    // 0x126fb6c: r0 = runtimeType()
    //     0x126fb6c: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x126fb70: r1 = LoadClassIdInstr(r0)
    //     0x126fb70: ldur            x1, [x0, #-1]
    //     0x126fb74: ubfx            x1, x1, #0xc, #0x14
    // 0x126fb78: r16 = MenuButtonThemeData
    //     0x126fb78: add             x16, PP, #0x26, lsl #12  ; [pp+0x26688] Type: MenuButtonThemeData
    //     0x126fb7c: ldr             x16, [x16, #0x688]
    // 0x126fb80: stp             x16, x0, [SP]
    // 0x126fb84: mov             x0, x1
    // 0x126fb88: mov             lr, x0
    // 0x126fb8c: ldr             lr, [x21, lr, lsl #3]
    // 0x126fb90: blr             lr
    // 0x126fb94: tbz             w0, #4, #0x126fba8
    // 0x126fb98: r0 = false
    //     0x126fb98: add             x0, NULL, #0x30  ; false
    // 0x126fb9c: LeaveFrame
    //     0x126fb9c: mov             SP, fp
    //     0x126fba0: ldp             fp, lr, [SP], #0x10
    // 0x126fba4: ret
    //     0x126fba4: ret             
    // 0x126fba8: ldr             x0, [fp, #0x10]
    // 0x126fbac: r1 = 60
    //     0x126fbac: mov             x1, #0x3c
    // 0x126fbb0: branchIfSmi(r0, 0x126fbbc)
    //     0x126fbb0: tbz             w0, #0, #0x126fbbc
    // 0x126fbb4: r1 = LoadClassIdInstr(r0)
    //     0x126fbb4: ldur            x1, [x0, #-1]
    //     0x126fbb8: ubfx            x1, x1, #0xc, #0x14
    // 0x126fbbc: r17 = 5138
    //     0x126fbbc: mov             x17, #0x1412
    // 0x126fbc0: cmp             x1, x17
    // 0x126fbc4: b.ne            #0x126fbfc
    // 0x126fbc8: ldr             x1, [fp, #0x18]
    // 0x126fbcc: LoadField: r2 = r0->field_7
    //     0x126fbcc: ldur            w2, [x0, #7]
    // 0x126fbd0: DecompressPointer r2
    //     0x126fbd0: add             x2, x2, HEAP, lsl #32
    // 0x126fbd4: LoadField: r0 = r1->field_7
    //     0x126fbd4: ldur            w0, [x1, #7]
    // 0x126fbd8: DecompressPointer r0
    //     0x126fbd8: add             x0, x0, HEAP, lsl #32
    // 0x126fbdc: r1 = LoadClassIdInstr(r2)
    //     0x126fbdc: ldur            x1, [x2, #-1]
    //     0x126fbe0: ubfx            x1, x1, #0xc, #0x14
    // 0x126fbe4: stp             x0, x2, [SP]
    // 0x126fbe8: mov             x0, x1
    // 0x126fbec: mov             lr, x0
    // 0x126fbf0: ldr             lr, [x21, lr, lsl #3]
    // 0x126fbf4: blr             lr
    // 0x126fbf8: b               #0x126fc00
    // 0x126fbfc: r0 = false
    //     0x126fbfc: add             x0, NULL, #0x30  ; false
    // 0x126fc00: LeaveFrame
    //     0x126fc00: mov             SP, fp
    //     0x126fc04: ldp             fp, lr, [SP], #0x10
    // 0x126fc08: ret
    //     0x126fc08: ret             
    // 0x126fc0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x126fc0c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x126fc10: b               #0x126fb30
  }
}
