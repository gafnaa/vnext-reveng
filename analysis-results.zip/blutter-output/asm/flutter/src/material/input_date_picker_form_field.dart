// lib: , url: package:flutter/src/material/input_date_picker_form_field.dart

// class id: 1048907, size: 0x8
class :: {
}

// class id: 5465, size: 0x24, field offset: 0x14
class _InputDatePickerFormFieldState extends State<dynamic> {

  [closure] void _handleSaved(dynamic, String?) {
    // ** addr: 0xd17efc, size: 0x3c
    // 0xd17efc: EnterFrame
    //     0xd17efc: stp             fp, lr, [SP, #-0x10]!
    //     0xd17f00: mov             fp, SP
    // 0xd17f04: ldr             x0, [fp, #0x18]
    // 0xd17f08: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd17f08: ldur            w1, [x0, #0x17]
    // 0xd17f0c: DecompressPointer r1
    //     0xd17f0c: add             x1, x1, HEAP, lsl #32
    // 0xd17f10: CheckStackOverflow
    //     0xd17f10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd17f14: cmp             SP, x16
    //     0xd17f18: b.ls            #0xd17f30
    // 0xd17f1c: ldr             x2, [fp, #0x10]
    // 0xd17f20: r0 = _handleSaved()
    //     0xd17f20: bl              #0xd180cc  ; [package:flutter/src/material/input_date_picker_form_field.dart] _InputDatePickerFormFieldState::_handleSaved
    // 0xd17f24: LeaveFrame
    //     0xd17f24: mov             SP, fp
    //     0xd17f28: ldp             fp, lr, [SP], #0x10
    // 0xd17f2c: ret
    //     0xd17f2c: ret             
    // 0xd17f30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd17f30: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd17f34: b               #0xd17f1c
  }
  _ _handleSaved(/* No info */) {
    // ** addr: 0xd180cc, size: 0x4c
    // 0xd180cc: EnterFrame
    //     0xd180cc: stp             fp, lr, [SP, #-0x10]!
    //     0xd180d0: mov             fp, SP
    // 0xd180d4: CheckStackOverflow
    //     0xd180d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd180d8: cmp             SP, x16
    //     0xd180dc: b.ls            #0xd1810c
    // 0xd180e0: LoadField: r0 = r1->field_b
    //     0xd180e0: ldur            w0, [x1, #0xb]
    // 0xd180e4: DecompressPointer r0
    //     0xd180e4: add             x0, x0, HEAP, lsl #32
    // 0xd180e8: cmp             w0, NULL
    // 0xd180ec: b.eq            #0xd18114
    // 0xd180f0: LoadField: r3 = r0->field_1b
    //     0xd180f0: ldur            w3, [x0, #0x1b]
    // 0xd180f4: DecompressPointer r3
    //     0xd180f4: add             x3, x3, HEAP, lsl #32
    // 0xd180f8: r0 = _updateDate()
    //     0xd180f8: bl              #0xd18118  ; [package:flutter/src/material/input_date_picker_form_field.dart] _InputDatePickerFormFieldState::_updateDate
    // 0xd180fc: r0 = Null
    //     0xd180fc: mov             x0, NULL
    // 0xd18100: LeaveFrame
    //     0xd18100: mov             SP, fp
    //     0xd18104: ldp             fp, lr, [SP], #0x10
    // 0xd18108: ret
    //     0xd18108: ret             
    // 0xd1810c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1810c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd18110: b               #0xd180e0
    // 0xd18114: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd18114: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateDate(/* No info */) {
    // ** addr: 0xd18118, size: 0xd0
    // 0xd18118: EnterFrame
    //     0xd18118: stp             fp, lr, [SP, #-0x10]!
    //     0xd1811c: mov             fp, SP
    // 0xd18120: AllocStack(0x20)
    //     0xd18120: sub             SP, SP, #0x20
    // 0xd18124: SetupParameters(_InputDatePickerFormFieldState this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xd18124: mov             x4, x1
    //     0xd18128: mov             x0, x2
    //     0xd1812c: stur            x1, [fp, #-8]
    //     0xd18130: stur            x2, [fp, #-0x10]
    //     0xd18134: stur            x3, [fp, #-0x18]
    // 0xd18138: CheckStackOverflow
    //     0xd18138: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd1813c: cmp             SP, x16
    //     0xd18140: b.ls            #0xd181dc
    // 0xd18144: mov             x1, x4
    // 0xd18148: mov             x2, x0
    // 0xd1814c: r0 = _parseDate()
    //     0xd1814c: bl              #0xd1840c  ; [package:flutter/src/material/input_date_picker_form_field.dart] _InputDatePickerFormFieldState::_parseDate
    // 0xd18150: ldur            x1, [fp, #-8]
    // 0xd18154: mov             x2, x0
    // 0xd18158: stur            x0, [fp, #-0x20]
    // 0xd1815c: r0 = _isValidAcceptableDate()
    //     0xd1815c: bl              #0xd18318  ; [package:flutter/src/material/input_date_picker_form_field.dart] _InputDatePickerFormFieldState::_isValidAcceptableDate
    // 0xd18160: tbnz            w0, #4, #0xd181cc
    // 0xd18164: ldur            x3, [fp, #-8]
    // 0xd18168: ldur            x2, [fp, #-0x18]
    // 0xd1816c: ldur            x1, [fp, #-0x20]
    // 0xd18170: mov             x0, x1
    // 0xd18174: ArrayStore: r3[0] = r0  ; List_4
    //     0xd18174: stur            w0, [x3, #0x17]
    //     0xd18178: ldurb           w16, [x3, #-1]
    //     0xd1817c: ldurb           w17, [x0, #-1]
    //     0xd18180: and             x16, x17, x16, lsr #2
    //     0xd18184: tst             x16, HEAP, lsr #32
    //     0xd18188: b.eq            #0xd18190
    //     0xd1818c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xd18190: ldur            x0, [fp, #-0x10]
    // 0xd18194: StoreField: r3->field_1b = r0
    //     0xd18194: stur            w0, [x3, #0x1b]
    //     0xd18198: ldurb           w16, [x3, #-1]
    //     0xd1819c: ldurb           w17, [x0, #-1]
    //     0xd181a0: and             x16, x17, x16, lsr #2
    //     0xd181a4: tst             x16, HEAP, lsr #32
    //     0xd181a8: b.eq            #0xd181b0
    //     0xd181ac: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xd181b0: cmp             w1, NULL
    // 0xd181b4: b.eq            #0xd181e4
    // 0xd181b8: ArrayLoad: r0 = r2[0]  ; List_4
    //     0xd181b8: ldur            w0, [x2, #0x17]
    // 0xd181bc: DecompressPointer r0
    //     0xd181bc: add             x0, x0, HEAP, lsl #32
    // 0xd181c0: mov             x2, x1
    // 0xd181c4: mov             x1, x0
    // 0xd181c8: r0 = _handleDateChanged()
    //     0xd181c8: bl              #0xd18224  ; [package:flutter/src/material/date_picker.dart] _DatePickerDialogState::_handleDateChanged
    // 0xd181cc: r0 = Null
    //     0xd181cc: mov             x0, NULL
    // 0xd181d0: LeaveFrame
    //     0xd181d0: mov             SP, fp
    //     0xd181d4: ldp             fp, lr, [SP], #0x10
    // 0xd181d8: ret
    //     0xd181d8: ret             
    // 0xd181dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd181dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd181e0: b               #0xd18144
    // 0xd181e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd181e4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _isValidAcceptableDate(/* No info */) {
    // ** addr: 0xd18318, size: 0xbc
    // 0xd18318: EnterFrame
    //     0xd18318: stp             fp, lr, [SP, #-0x10]!
    //     0xd1831c: mov             fp, SP
    // 0xd18320: AllocStack(0x10)
    //     0xd18320: sub             SP, SP, #0x10
    // 0xd18324: SetupParameters(_InputDatePickerFormFieldState this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xd18324: mov             x3, x1
    //     0xd18328: mov             x0, x2
    //     0xd1832c: stur            x1, [fp, #-8]
    //     0xd18330: stur            x2, [fp, #-0x10]
    // 0xd18334: CheckStackOverflow
    //     0xd18334: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd18338: cmp             SP, x16
    //     0xd1833c: b.ls            #0xd183c0
    // 0xd18340: cmp             w0, NULL
    // 0xd18344: b.eq            #0xd183b0
    // 0xd18348: LoadField: r1 = r3->field_b
    //     0xd18348: ldur            w1, [x3, #0xb]
    // 0xd1834c: DecompressPointer r1
    //     0xd1834c: add             x1, x1, HEAP, lsl #32
    // 0xd18350: cmp             w1, NULL
    // 0xd18354: b.eq            #0xd183c8
    // 0xd18358: LoadField: r2 = r1->field_f
    //     0xd18358: ldur            w2, [x1, #0xf]
    // 0xd1835c: DecompressPointer r2
    //     0xd1835c: add             x2, x2, HEAP, lsl #32
    // 0xd18360: mov             x1, x0
    // 0xd18364: r0 = isBefore()
    //     0xd18364: bl              #0xd183f0  ; [dart:core] DateTime::isBefore
    // 0xd18368: tbz             w0, #4, #0xd183b0
    // 0xd1836c: ldur            x0, [fp, #-8]
    // 0xd18370: LoadField: r1 = r0->field_b
    //     0xd18370: ldur            w1, [x0, #0xb]
    // 0xd18374: DecompressPointer r1
    //     0xd18374: add             x1, x1, HEAP, lsl #32
    // 0xd18378: cmp             w1, NULL
    // 0xd1837c: b.eq            #0xd183cc
    // 0xd18380: LoadField: r2 = r1->field_13
    //     0xd18380: ldur            w2, [x1, #0x13]
    // 0xd18384: DecompressPointer r2
    //     0xd18384: add             x2, x2, HEAP, lsl #32
    // 0xd18388: ldur            x1, [fp, #-0x10]
    // 0xd1838c: r0 = isAfter()
    //     0xd1838c: bl              #0xd183d4  ; [dart:core] DateTime::isAfter
    // 0xd18390: tbz             w0, #4, #0xd183b0
    // 0xd18394: ldur            x1, [fp, #-8]
    // 0xd18398: LoadField: r2 = r1->field_b
    //     0xd18398: ldur            w2, [x1, #0xb]
    // 0xd1839c: DecompressPointer r2
    //     0xd1839c: add             x2, x2, HEAP, lsl #32
    // 0xd183a0: cmp             w2, NULL
    // 0xd183a4: b.eq            #0xd183d0
    // 0xd183a8: r0 = true
    //     0xd183a8: add             x0, NULL, #0x20  ; true
    // 0xd183ac: b               #0xd183b4
    // 0xd183b0: r0 = false
    //     0xd183b0: add             x0, NULL, #0x30  ; false
    // 0xd183b4: LeaveFrame
    //     0xd183b4: mov             SP, fp
    //     0xd183b8: ldp             fp, lr, [SP], #0x10
    // 0xd183bc: ret
    //     0xd183bc: ret             
    // 0xd183c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd183c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd183c4: b               #0xd18340
    // 0xd183c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd183c8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd183cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd183cc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd183d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd183d0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _parseDate(/* No info */) {
    // ** addr: 0xd1840c, size: 0x80
    // 0xd1840c: EnterFrame
    //     0xd1840c: stp             fp, lr, [SP, #-0x10]!
    //     0xd18410: mov             fp, SP
    // 0xd18414: AllocStack(0x10)
    //     0xd18414: sub             SP, SP, #0x10
    // 0xd18418: SetupParameters(_InputDatePickerFormFieldState this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xd18418: mov             x0, x1
    //     0xd1841c: stur            x1, [fp, #-8]
    //     0xd18420: stur            x2, [fp, #-0x10]
    // 0xd18424: CheckStackOverflow
    //     0xd18424: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd18428: cmp             SP, x16
    //     0xd1842c: b.ls            #0xd1847c
    // 0xd18430: LoadField: r1 = r0->field_f
    //     0xd18430: ldur            w1, [x0, #0xf]
    // 0xd18434: DecompressPointer r1
    //     0xd18434: add             x1, x1, HEAP, lsl #32
    // 0xd18438: cmp             w1, NULL
    // 0xd1843c: b.eq            #0xd18484
    // 0xd18440: r0 = of()
    //     0xd18440: bl              #0xd0bbf8  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0xd18444: mov             x1, x0
    // 0xd18448: ldur            x0, [fp, #-8]
    // 0xd1844c: LoadField: r2 = r0->field_b
    //     0xd1844c: ldur            w2, [x0, #0xb]
    // 0xd18450: DecompressPointer r2
    //     0xd18450: add             x2, x2, HEAP, lsl #32
    // 0xd18454: cmp             w2, NULL
    // 0xd18458: b.eq            #0xd18488
    // 0xd1845c: ldur            x2, [fp, #-0x10]
    // 0xd18460: mov             x3, x1
    // 0xd18464: r1 = Instance_GregorianCalendarDelegate
    //     0xd18464: add             x1, PP, #0x28, lsl #12  ; [pp+0x28538] Obj!GregorianCalendarDelegate@129edd1
    //     0xd18468: ldr             x1, [x1, #0x538]
    // 0xd1846c: r0 = parseCompactDate()
    //     0xd1846c: bl              #0xd1848c  ; [package:flutter/src/material/date.dart] GregorianCalendarDelegate::parseCompactDate
    // 0xd18470: LeaveFrame
    //     0xd18470: mov             SP, fp
    //     0xd18474: ldp             fp, lr, [SP], #0x10
    // 0xd18478: ret
    //     0xd18478: ret             
    // 0xd1847c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1847c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd18480: b               #0xd18430
    // 0xd18484: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd18484: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd18488: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd18488: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ build(/* No info */) {
    // ** addr: 0xdf77e4, size: 0x238
    // 0xdf77e4: EnterFrame
    //     0xdf77e4: stp             fp, lr, [SP, #-0x10]!
    //     0xdf77e8: mov             fp, SP
    // 0xdf77ec: AllocStack(0x60)
    //     0xdf77ec: sub             SP, SP, #0x60
    // 0xdf77f0: SetupParameters(_InputDatePickerFormFieldState this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xdf77f0: mov             x0, x2
    //     0xdf77f4: stur            x2, [fp, #-0x10]
    //     0xdf77f8: mov             x2, x1
    //     0xdf77fc: stur            x1, [fp, #-8]
    // 0xdf7800: CheckStackOverflow
    //     0xdf7800: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf7804: cmp             SP, x16
    //     0xdf7808: b.ls            #0xdf7a08
    // 0xdf780c: mov             x1, x0
    // 0xdf7810: r0 = of()
    //     0xdf7810: bl              #0x8a76d4  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xdf7814: LoadField: r2 = r0->field_2f
    //     0xdf7814: ldur            w2, [x0, #0x2f]
    // 0xdf7818: DecompressPointer r2
    //     0xdf7818: add             x2, x2, HEAP, lsl #32
    // 0xdf781c: ldur            x1, [fp, #-0x10]
    // 0xdf7820: stur            x2, [fp, #-0x18]
    // 0xdf7824: r0 = of()
    //     0xdf7824: bl              #0xd0bbf8  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0xdf7828: ldur            x1, [fp, #-0x10]
    // 0xdf782c: stur            x0, [fp, #-0x10]
    // 0xdf7830: r0 = of()
    //     0xdf7830: bl              #0xd1e0d0  ; [package:flutter/src/material/input_decorator.dart] InputDecorationTheme::of
    // 0xdf7834: stur            x0, [fp, #-0x20]
    // 0xdf7838: LoadField: r1 = r0->field_8b
    //     0xdf7838: ldur            w1, [x0, #0x8b]
    // 0xdf783c: DecompressPointer r1
    //     0xdf783c: add             x1, x1, HEAP, lsl #32
    // 0xdf7840: cmp             w1, NULL
    // 0xdf7844: b.ne            #0xdf786c
    // 0xdf7848: ldur            x1, [fp, #-0x18]
    // 0xdf784c: tbnz            w1, #4, #0xdf785c
    // 0xdf7850: r1 = Instance_OutlineInputBorder
    //     0xdf7850: add             x1, PP, #0xab, lsl #12  ; [pp+0xab028] Obj!OutlineInputBorder@129eba1
    //     0xdf7854: ldr             x1, [x1, #0x28]
    // 0xdf7858: b               #0xdf7864
    // 0xdf785c: r1 = Instance_UnderlineInputBorder
    //     0xdf785c: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3c60] Obj!UnderlineInputBorder@129ebc1
    //     0xdf7860: ldr             x1, [x1, #0xc60]
    // 0xdf7864: mov             x5, x1
    // 0xdf7868: b               #0xdf7870
    // 0xdf786c: mov             x5, x1
    // 0xdf7870: ldur            x4, [fp, #-8]
    // 0xdf7874: ldur            x3, [fp, #-0x10]
    // 0xdf7878: stur            x5, [fp, #-0x18]
    // 0xdf787c: LoadField: r1 = r4->field_b
    //     0xdf787c: ldur            w1, [x4, #0xb]
    // 0xdf7880: DecompressPointer r1
    //     0xdf7880: add             x1, x1, HEAP, lsl #32
    // 0xdf7884: cmp             w1, NULL
    // 0xdf7888: b.eq            #0xdf7a10
    // 0xdf788c: mov             x2, x3
    // 0xdf7890: r1 = Instance_GregorianCalendarDelegate
    //     0xdf7890: add             x1, PP, #0x28, lsl #12  ; [pp+0x28538] Obj!GregorianCalendarDelegate@129edd1
    //     0xdf7894: ldr             x1, [x1, #0x538]
    // 0xdf7898: r0 = dateHelpText()
    //     0xdf7898: bl              #0xdf7aac  ; [package:flutter/src/material/date.dart] GregorianCalendarDelegate::dateHelpText
    // 0xdf789c: mov             x3, x0
    // 0xdf78a0: ldur            x2, [fp, #-8]
    // 0xdf78a4: stur            x3, [fp, #-0x28]
    // 0xdf78a8: LoadField: r0 = r2->field_b
    //     0xdf78a8: ldur            w0, [x2, #0xb]
    // 0xdf78ac: DecompressPointer r0
    //     0xdf78ac: add             x0, x0, HEAP, lsl #32
    // 0xdf78b0: cmp             w0, NULL
    // 0xdf78b4: b.eq            #0xdf7a14
    // 0xdf78b8: ldur            x1, [fp, #-0x10]
    // 0xdf78bc: r0 = LoadClassIdInstr(r1)
    //     0xdf78bc: ldur            x0, [x1, #-1]
    //     0xdf78c0: ubfx            x0, x0, #0xc, #0x14
    // 0xdf78c4: r0 = GDT[cid_x0 + 0x162ba]()
    //     0xdf78c4: mov             x17, #0x62ba
    //     0xdf78c8: movk            x17, #1, lsl #16
    //     0xdf78cc: add             lr, x0, x17
    //     0xdf78d0: ldr             lr, [x21, lr, lsl #3]
    //     0xdf78d4: blr             lr
    // 0xdf78d8: stur            x0, [fp, #-0x10]
    // 0xdf78dc: r0 = InputDecoration()
    //     0xdf78dc: bl              #0xd1e0c4  ; AllocateInputDecorationStub -> InputDecoration (size=0xf0)
    // 0xdf78e0: mov             x3, x0
    // 0xdf78e4: ldur            x0, [fp, #-0x10]
    // 0xdf78e8: stur            x3, [fp, #-0x30]
    // 0xdf78ec: StoreField: r3->field_13 = r0
    //     0xdf78ec: stur            w0, [x3, #0x13]
    // 0xdf78f0: ldur            x0, [fp, #-0x28]
    // 0xdf78f4: StoreField: r3->field_2f = r0
    //     0xdf78f4: stur            w0, [x3, #0x2f]
    // 0xdf78f8: r0 = true
    //     0xdf78f8: add             x0, NULL, #0x20  ; true
    // 0xdf78fc: StoreField: r3->field_47 = r0
    //     0xdf78fc: stur            w0, [x3, #0x47]
    // 0xdf7900: StoreField: r3->field_4b = r0
    //     0xdf7900: stur            w0, [x3, #0x4b]
    // 0xdf7904: r1 = false
    //     0xdf7904: add             x1, NULL, #0x30  ; false
    // 0xdf7908: StoreField: r3->field_4f = r1
    //     0xdf7908: stur            w1, [x3, #0x4f]
    // 0xdf790c: StoreField: r3->field_db = r0
    //     0xdf790c: stur            w0, [x3, #0xdb]
    // 0xdf7910: ldur            x1, [fp, #-0x20]
    // 0xdf7914: ldur            x2, [fp, #-0x18]
    // 0xdf7918: r0 = copyWith()
    //     0xdf7918: bl              #0xdf7a1c  ; [package:flutter/src/material/input_decorator.dart] InputDecorationThemeData::copyWith
    // 0xdf791c: ldur            x1, [fp, #-0x30]
    // 0xdf7920: mov             x2, x0
    // 0xdf7924: r0 = applyDefaults()
    //     0xdf7924: bl              #0xd2d7ec  ; [package:flutter/src/material/input_decorator.dart] InputDecoration::applyDefaults
    // 0xdf7928: mov             x3, x0
    // 0xdf792c: ldur            x0, [fp, #-8]
    // 0xdf7930: stur            x3, [fp, #-0x18]
    // 0xdf7934: LoadField: r1 = r0->field_b
    //     0xdf7934: ldur            w1, [x0, #0xb]
    // 0xdf7938: DecompressPointer r1
    //     0xdf7938: add             x1, x1, HEAP, lsl #32
    // 0xdf793c: cmp             w1, NULL
    // 0xdf7940: b.eq            #0xdf7a18
    // 0xdf7944: LoadField: r4 = r0->field_13
    //     0xdf7944: ldur            w4, [x0, #0x13]
    // 0xdf7948: DecompressPointer r4
    //     0xdf7948: add             x4, x4, HEAP, lsl #32
    // 0xdf794c: mov             x2, x0
    // 0xdf7950: stur            x4, [fp, #-0x10]
    // 0xdf7954: r1 = Function '_validateDate@758491759':.
    //     0xdf7954: add             x1, PP, #0xab, lsl #12  ; [pp+0xab030] AnonymousClosure: (0xdf7b80), in [package:flutter/src/material/input_date_picker_form_field.dart] _InputDatePickerFormFieldState::_validateDate (0xdf7bbc)
    //     0xdf7958: ldr             x1, [x1, #0x30]
    // 0xdf795c: r0 = AllocateClosure()
    //     0xdf795c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf7960: ldur            x2, [fp, #-8]
    // 0xdf7964: r1 = Function '_handleSaved@758491759':.
    //     0xdf7964: add             x1, PP, #0xab, lsl #12  ; [pp+0xab038] AnonymousClosure: (0xd17efc), in [package:flutter/src/material/input_date_picker_form_field.dart] _InputDatePickerFormFieldState::_handleSaved (0xd180cc)
    //     0xdf7968: ldr             x1, [x1, #0x38]
    // 0xdf796c: stur            x0, [fp, #-0x20]
    // 0xdf7970: r0 = AllocateClosure()
    //     0xdf7970: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf7974: ldur            x2, [fp, #-8]
    // 0xdf7978: r1 = Function '_handleSubmitted@758491759':.
    //     0xdf7978: add             x1, PP, #0xab, lsl #12  ; [pp+0xab040] AnonymousClosure: (0xdf7af8), in [package:flutter/src/material/input_date_picker_form_field.dart] _InputDatePickerFormFieldState::_handleSubmitted (0xdf7b34)
    //     0xdf797c: ldr             x1, [x1, #0x40]
    // 0xdf7980: stur            x0, [fp, #-8]
    // 0xdf7984: r0 = AllocateClosure()
    //     0xdf7984: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xdf7988: r1 = <String>
    //     0xdf7988: ldr             x1, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    // 0xdf798c: stur            x0, [fp, #-0x28]
    // 0xdf7990: r0 = TextFormField()
    //     0xdf7990: bl              #0xd93f34  ; AllocateTextFormFieldStub -> TextFormField (size=0x34)
    // 0xdf7994: stur            x0, [fp, #-0x30]
    // 0xdf7998: ldur            x16, [fp, #-0x20]
    // 0xdf799c: r30 = Instance_TextInputType
    //     0xdf799c: add             lr, PP, #0x28, lsl #12  ; [pp+0x284a0] Obj!TextInputType@129b861
    //     0xdf79a0: ldr             lr, [lr, #0x4a0]
    // 0xdf79a4: stp             lr, x16, [SP, #0x20]
    // 0xdf79a8: ldur            x16, [fp, #-8]
    // 0xdf79ac: ldur            lr, [fp, #-0x28]
    // 0xdf79b0: stp             lr, x16, [SP, #0x10]
    // 0xdf79b4: r16 = true
    //     0xdf79b4: add             x16, NULL, #0x20  ; true
    // 0xdf79b8: stp             NULL, x16, [SP]
    // 0xdf79bc: mov             x1, x0
    // 0xdf79c0: ldur            x2, [fp, #-0x10]
    // 0xdf79c4: ldur            x3, [fp, #-0x18]
    // 0xdf79c8: r4 = const [0, 0x9, 0x6, 0x3, autofocus, 0x7, focusNode, 0x8, keyboardType, 0x4, onFieldSubmitted, 0x6, onSaved, 0x5, validator, 0x3, null]
    //     0xdf79c8: add             x4, PP, #0xab, lsl #12  ; [pp+0xab048] List(17) [0, 0x9, 0x6, 0x3, "autofocus", 0x7, "focusNode", 0x8, "keyboardType", 0x4, "onFieldSubmitted", 0x6, "onSaved", 0x5, "validator", 0x3, Null]
    //     0xdf79cc: ldr             x4, [x4, #0x48]
    // 0xdf79d0: r0 = TextFormField()
    //     0xdf79d0: bl              #0xd8ff70  ; [package:flutter/src/material/text_form_field.dart] TextFormField::TextFormField
    // 0xdf79d4: r0 = Semantics()
    //     0xdf79d4: bl              #0x917ec0  ; AllocateSemanticsStub -> Semantics (size=0x28)
    // 0xdf79d8: stur            x0, [fp, #-8]
    // 0xdf79dc: r16 = true
    //     0xdf79dc: add             x16, NULL, #0x20  ; true
    // 0xdf79e0: ldur            lr, [fp, #-0x30]
    // 0xdf79e4: stp             lr, x16, [SP]
    // 0xdf79e8: mov             x1, x0
    // 0xdf79ec: r4 = const [0, 0x3, 0x2, 0x1, child, 0x2, container, 0x1, null]
    //     0xdf79ec: add             x4, PP, #0x8c, lsl #12  ; [pp+0x8c9b8] List(9) [0, 0x3, 0x2, 0x1, "child", 0x2, "container", 0x1, Null]
    //     0xdf79f0: ldr             x4, [x4, #0x9b8]
    // 0xdf79f4: r0 = Semantics()
    //     0xdf79f4: bl              #0x9169c0  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xdf79f8: ldur            x0, [fp, #-8]
    // 0xdf79fc: LeaveFrame
    //     0xdf79fc: mov             SP, fp
    //     0xdf7a00: ldp             fp, lr, [SP], #0x10
    // 0xdf7a04: ret
    //     0xdf7a04: ret             
    // 0xdf7a08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf7a08: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf7a0c: b               #0xdf780c
    // 0xdf7a10: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf7a10: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf7a14: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf7a14: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf7a18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf7a18: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleSubmitted(dynamic, String) {
    // ** addr: 0xdf7af8, size: 0x3c
    // 0xdf7af8: EnterFrame
    //     0xdf7af8: stp             fp, lr, [SP, #-0x10]!
    //     0xdf7afc: mov             fp, SP
    // 0xdf7b00: ldr             x0, [fp, #0x18]
    // 0xdf7b04: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdf7b04: ldur            w1, [x0, #0x17]
    // 0xdf7b08: DecompressPointer r1
    //     0xdf7b08: add             x1, x1, HEAP, lsl #32
    // 0xdf7b0c: CheckStackOverflow
    //     0xdf7b0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf7b10: cmp             SP, x16
    //     0xdf7b14: b.ls            #0xdf7b2c
    // 0xdf7b18: ldr             x2, [fp, #0x10]
    // 0xdf7b1c: r0 = _handleSubmitted()
    //     0xdf7b1c: bl              #0xdf7b34  ; [package:flutter/src/material/input_date_picker_form_field.dart] _InputDatePickerFormFieldState::_handleSubmitted
    // 0xdf7b20: LeaveFrame
    //     0xdf7b20: mov             SP, fp
    //     0xdf7b24: ldp             fp, lr, [SP], #0x10
    // 0xdf7b28: ret
    //     0xdf7b28: ret             
    // 0xdf7b2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf7b2c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf7b30: b               #0xdf7b18
  }
  _ _handleSubmitted(/* No info */) {
    // ** addr: 0xdf7b34, size: 0x4c
    // 0xdf7b34: EnterFrame
    //     0xdf7b34: stp             fp, lr, [SP, #-0x10]!
    //     0xdf7b38: mov             fp, SP
    // 0xdf7b3c: CheckStackOverflow
    //     0xdf7b3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf7b40: cmp             SP, x16
    //     0xdf7b44: b.ls            #0xdf7b74
    // 0xdf7b48: LoadField: r0 = r1->field_b
    //     0xdf7b48: ldur            w0, [x1, #0xb]
    // 0xdf7b4c: DecompressPointer r0
    //     0xdf7b4c: add             x0, x0, HEAP, lsl #32
    // 0xdf7b50: cmp             w0, NULL
    // 0xdf7b54: b.eq            #0xdf7b7c
    // 0xdf7b58: ArrayLoad: r3 = r0[0]  ; List_4
    //     0xdf7b58: ldur            w3, [x0, #0x17]
    // 0xdf7b5c: DecompressPointer r3
    //     0xdf7b5c: add             x3, x3, HEAP, lsl #32
    // 0xdf7b60: r0 = _updateDate()
    //     0xdf7b60: bl              #0xd18118  ; [package:flutter/src/material/input_date_picker_form_field.dart] _InputDatePickerFormFieldState::_updateDate
    // 0xdf7b64: r0 = Null
    //     0xdf7b64: mov             x0, NULL
    // 0xdf7b68: LeaveFrame
    //     0xdf7b68: mov             SP, fp
    //     0xdf7b6c: ldp             fp, lr, [SP], #0x10
    // 0xdf7b70: ret
    //     0xdf7b70: ret             
    // 0xdf7b74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf7b74: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf7b78: b               #0xdf7b48
    // 0xdf7b7c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf7b7c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] String? _validateDate(dynamic, String?) {
    // ** addr: 0xdf7b80, size: 0x3c
    // 0xdf7b80: EnterFrame
    //     0xdf7b80: stp             fp, lr, [SP, #-0x10]!
    //     0xdf7b84: mov             fp, SP
    // 0xdf7b88: ldr             x0, [fp, #0x18]
    // 0xdf7b8c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xdf7b8c: ldur            w1, [x0, #0x17]
    // 0xdf7b90: DecompressPointer r1
    //     0xdf7b90: add             x1, x1, HEAP, lsl #32
    // 0xdf7b94: CheckStackOverflow
    //     0xdf7b94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf7b98: cmp             SP, x16
    //     0xdf7b9c: b.ls            #0xdf7bb4
    // 0xdf7ba0: ldr             x2, [fp, #0x10]
    // 0xdf7ba4: r0 = _validateDate()
    //     0xdf7ba4: bl              #0xdf7bbc  ; [package:flutter/src/material/input_date_picker_form_field.dart] _InputDatePickerFormFieldState::_validateDate
    // 0xdf7ba8: LeaveFrame
    //     0xdf7ba8: mov             SP, fp
    //     0xdf7bac: ldp             fp, lr, [SP], #0x10
    // 0xdf7bb0: ret
    //     0xdf7bb0: ret             
    // 0xdf7bb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf7bb4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf7bb8: b               #0xdf7ba0
  }
  _ _validateDate(/* No info */) {
    // ** addr: 0xdf7bbc, size: 0x148
    // 0xdf7bbc: EnterFrame
    //     0xdf7bbc: stp             fp, lr, [SP, #-0x10]!
    //     0xdf7bc0: mov             fp, SP
    // 0xdf7bc4: AllocStack(0x8)
    //     0xdf7bc4: sub             SP, SP, #8
    // 0xdf7bc8: SetupParameters(_InputDatePickerFormFieldState this /* r1 => r0, fp-0x8 */)
    //     0xdf7bc8: mov             x0, x1
    //     0xdf7bcc: stur            x1, [fp, #-8]
    // 0xdf7bd0: CheckStackOverflow
    //     0xdf7bd0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xdf7bd4: cmp             SP, x16
    //     0xdf7bd8: b.ls            #0xdf7ce8
    // 0xdf7bdc: cmp             w2, NULL
    // 0xdf7be0: b.eq            #0xdf7bec
    // 0xdf7be4: LoadField: r1 = r2->field_7
    //     0xdf7be4: ldur            w1, [x2, #7]
    // 0xdf7be8: cbnz            w1, #0xdf7bfc
    // 0xdf7bec: LoadField: r1 = r0->field_b
    //     0xdf7bec: ldur            w1, [x0, #0xb]
    // 0xdf7bf0: DecompressPointer r1
    //     0xdf7bf0: add             x1, x1, HEAP, lsl #32
    // 0xdf7bf4: cmp             w1, NULL
    // 0xdf7bf8: b.eq            #0xdf7cf0
    // 0xdf7bfc: mov             x1, x0
    // 0xdf7c00: r0 = _parseDate()
    //     0xdf7c00: bl              #0xd1840c  ; [package:flutter/src/material/input_date_picker_form_field.dart] _InputDatePickerFormFieldState::_parseDate
    // 0xdf7c04: cmp             w0, NULL
    // 0xdf7c08: b.ne            #0xdf7c68
    // 0xdf7c0c: ldur            x3, [fp, #-8]
    // 0xdf7c10: LoadField: r0 = r3->field_b
    //     0xdf7c10: ldur            w0, [x3, #0xb]
    // 0xdf7c14: DecompressPointer r0
    //     0xdf7c14: add             x0, x0, HEAP, lsl #32
    // 0xdf7c18: cmp             w0, NULL
    // 0xdf7c1c: b.eq            #0xdf7cf4
    // 0xdf7c20: LoadField: r1 = r3->field_f
    //     0xdf7c20: ldur            w1, [x3, #0xf]
    // 0xdf7c24: DecompressPointer r1
    //     0xdf7c24: add             x1, x1, HEAP, lsl #32
    // 0xdf7c28: cmp             w1, NULL
    // 0xdf7c2c: b.eq            #0xdf7cf8
    // 0xdf7c30: r0 = of()
    //     0xdf7c30: bl              #0xd0bbf8  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0xdf7c34: r1 = LoadClassIdInstr(r0)
    //     0xdf7c34: ldur            x1, [x0, #-1]
    //     0xdf7c38: ubfx            x1, x1, #0xc, #0x14
    // 0xdf7c3c: mov             x16, x0
    // 0xdf7c40: mov             x0, x1
    // 0xdf7c44: mov             x1, x16
    // 0xdf7c48: r0 = GDT[cid_x0 + 0x16b58]()
    //     0xdf7c48: mov             x17, #0x6b58
    //     0xdf7c4c: movk            x17, #1, lsl #16
    //     0xdf7c50: add             lr, x0, x17
    //     0xdf7c54: ldr             lr, [x21, lr, lsl #3]
    //     0xdf7c58: blr             lr
    // 0xdf7c5c: LeaveFrame
    //     0xdf7c5c: mov             SP, fp
    //     0xdf7c60: ldp             fp, lr, [SP], #0x10
    // 0xdf7c64: ret
    //     0xdf7c64: ret             
    // 0xdf7c68: ldur            x3, [fp, #-8]
    // 0xdf7c6c: mov             x1, x3
    // 0xdf7c70: mov             x2, x0
    // 0xdf7c74: r0 = _isValidAcceptableDate()
    //     0xdf7c74: bl              #0xd18318  ; [package:flutter/src/material/input_date_picker_form_field.dart] _InputDatePickerFormFieldState::_isValidAcceptableDate
    // 0xdf7c78: tbz             w0, #4, #0xdf7cd8
    // 0xdf7c7c: ldur            x0, [fp, #-8]
    // 0xdf7c80: LoadField: r1 = r0->field_b
    //     0xdf7c80: ldur            w1, [x0, #0xb]
    // 0xdf7c84: DecompressPointer r1
    //     0xdf7c84: add             x1, x1, HEAP, lsl #32
    // 0xdf7c88: cmp             w1, NULL
    // 0xdf7c8c: b.eq            #0xdf7cfc
    // 0xdf7c90: LoadField: r1 = r0->field_f
    //     0xdf7c90: ldur            w1, [x0, #0xf]
    // 0xdf7c94: DecompressPointer r1
    //     0xdf7c94: add             x1, x1, HEAP, lsl #32
    // 0xdf7c98: cmp             w1, NULL
    // 0xdf7c9c: b.eq            #0xdf7d00
    // 0xdf7ca0: r0 = of()
    //     0xdf7ca0: bl              #0xd0bbf8  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0xdf7ca4: r1 = LoadClassIdInstr(r0)
    //     0xdf7ca4: ldur            x1, [x0, #-1]
    //     0xdf7ca8: ubfx            x1, x1, #0xc, #0x14
    // 0xdf7cac: mov             x16, x0
    // 0xdf7cb0: mov             x0, x1
    // 0xdf7cb4: mov             x1, x16
    // 0xdf7cb8: r0 = GDT[cid_x0 + 0x1727a]()
    //     0xdf7cb8: mov             x17, #0x727a
    //     0xdf7cbc: movk            x17, #1, lsl #16
    //     0xdf7cc0: add             lr, x0, x17
    //     0xdf7cc4: ldr             lr, [x21, lr, lsl #3]
    //     0xdf7cc8: blr             lr
    // 0xdf7ccc: LeaveFrame
    //     0xdf7ccc: mov             SP, fp
    //     0xdf7cd0: ldp             fp, lr, [SP], #0x10
    // 0xdf7cd4: ret
    //     0xdf7cd4: ret             
    // 0xdf7cd8: r0 = Null
    //     0xdf7cd8: mov             x0, NULL
    // 0xdf7cdc: LeaveFrame
    //     0xdf7cdc: mov             SP, fp
    //     0xdf7ce0: ldp             fp, lr, [SP], #0x10
    // 0xdf7ce4: ret
    //     0xdf7ce4: ret             
    // 0xdf7ce8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xdf7ce8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xdf7cec: b               #0xdf7bdc
    // 0xdf7cf0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf7cf0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf7cf4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf7cf4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf7cf8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf7cf8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf7cfc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf7cfc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xdf7d00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xdf7d00: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0xef5110, size: 0x30
    // 0xef5110: EnterFrame
    //     0xef5110: stp             fp, lr, [SP, #-0x10]!
    //     0xef5114: mov             fp, SP
    // 0xef5118: CheckStackOverflow
    //     0xef5118: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef511c: cmp             SP, x16
    //     0xef5120: b.ls            #0xef5138
    // 0xef5124: r0 = _updateValueForSelectedDate()
    //     0xef5124: bl              #0xef5140  ; [package:flutter/src/material/input_date_picker_form_field.dart] _InputDatePickerFormFieldState::_updateValueForSelectedDate
    // 0xef5128: r0 = Null
    //     0xef5128: mov             x0, NULL
    // 0xef512c: LeaveFrame
    //     0xef512c: mov             SP, fp
    //     0xef5130: ldp             fp, lr, [SP], #0x10
    // 0xef5134: ret
    //     0xef5134: ret             
    // 0xef5138: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef5138: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef513c: b               #0xef5124
  }
  _ _updateValueForSelectedDate(/* No info */) {
    // ** addr: 0xef5140, size: 0x200
    // 0xef5140: EnterFrame
    //     0xef5140: stp             fp, lr, [SP, #-0x10]!
    //     0xef5144: mov             fp, SP
    // 0xef5148: AllocStack(0x28)
    //     0xef5148: sub             SP, SP, #0x28
    // 0xef514c: SetupParameters(_InputDatePickerFormFieldState this /* r1 => r0, fp-0x8 */)
    //     0xef514c: mov             x0, x1
    //     0xef5150: stur            x1, [fp, #-8]
    // 0xef5154: CheckStackOverflow
    //     0xef5154: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xef5158: cmp             SP, x16
    //     0xef515c: b.ls            #0xef5328
    // 0xef5160: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xef5160: ldur            w1, [x0, #0x17]
    // 0xef5164: DecompressPointer r1
    //     0xef5164: add             x1, x1, HEAP, lsl #32
    // 0xef5168: cmp             w1, NULL
    // 0xef516c: b.eq            #0xef52c8
    // 0xef5170: LoadField: r1 = r0->field_f
    //     0xef5170: ldur            w1, [x0, #0xf]
    // 0xef5174: DecompressPointer r1
    //     0xef5174: add             x1, x1, HEAP, lsl #32
    // 0xef5178: cmp             w1, NULL
    // 0xef517c: b.eq            #0xef5330
    // 0xef5180: r0 = of()
    //     0xef5180: bl              #0xd0bbf8  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0xef5184: mov             x1, x0
    // 0xef5188: ldur            x0, [fp, #-8]
    // 0xef518c: LoadField: r2 = r0->field_b
    //     0xef518c: ldur            w2, [x0, #0xb]
    // 0xef5190: DecompressPointer r2
    //     0xef5190: add             x2, x2, HEAP, lsl #32
    // 0xef5194: cmp             w2, NULL
    // 0xef5198: b.eq            #0xef5334
    // 0xef519c: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xef519c: ldur            w2, [x0, #0x17]
    // 0xef51a0: DecompressPointer r2
    //     0xef51a0: add             x2, x2, HEAP, lsl #32
    // 0xef51a4: cmp             w2, NULL
    // 0xef51a8: b.eq            #0xef5338
    // 0xef51ac: mov             x3, x1
    // 0xef51b0: r1 = Instance_GregorianCalendarDelegate
    //     0xef51b0: add             x1, PP, #0x28, lsl #12  ; [pp+0x28538] Obj!GregorianCalendarDelegate@129edd1
    //     0xef51b4: ldr             x1, [x1, #0x538]
    // 0xef51b8: r0 = formatCompactDate()
    //     0xef51b8: bl              #0xef5340  ; [package:flutter/src/material/date.dart] GregorianCalendarDelegate::formatCompactDate
    // 0xef51bc: mov             x2, x0
    // 0xef51c0: ldur            x1, [fp, #-8]
    // 0xef51c4: stur            x2, [fp, #-0x10]
    // 0xef51c8: StoreField: r1->field_1b = r0
    //     0xef51c8: stur            w0, [x1, #0x1b]
    //     0xef51cc: ldurb           w16, [x1, #-1]
    //     0xef51d0: ldurb           w17, [x0, #-1]
    //     0xef51d4: and             x16, x17, x16, lsr #2
    //     0xef51d8: tst             x16, HEAP, lsr #32
    //     0xef51dc: b.eq            #0xef51e4
    //     0xef51e0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xef51e4: r0 = TextEditingValue()
    //     0xef51e4: bl              #0x86e1d4  ; AllocateTextEditingValueStub -> TextEditingValue (size=0x14)
    // 0xef51e8: mov             x1, x0
    // 0xef51ec: ldur            x0, [fp, #-0x10]
    // 0xef51f0: stur            x1, [fp, #-0x20]
    // 0xef51f4: StoreField: r1->field_7 = r0
    //     0xef51f4: stur            w0, [x1, #7]
    // 0xef51f8: r2 = Instance_TextSelection
    //     0xef51f8: add             x2, PP, #0x14, lsl #12  ; [pp+0x14b30] Obj!TextSelection@12a0491
    //     0xef51fc: ldr             x2, [x2, #0xb30]
    // 0xef5200: StoreField: r1->field_b = r2
    //     0xef5200: stur            w2, [x1, #0xb]
    // 0xef5204: r3 = Instance_TextRange
    //     0xef5204: ldr             x3, [PP, #0x53d8]  ; [pp+0x53d8] Obj!TextRange@12a0471
    // 0xef5208: StoreField: r1->field_f = r3
    //     0xef5208: stur            w3, [x1, #0xf]
    // 0xef520c: ldur            x2, [fp, #-8]
    // 0xef5210: LoadField: r3 = r2->field_b
    //     0xef5210: ldur            w3, [x2, #0xb]
    // 0xef5214: DecompressPointer r3
    //     0xef5214: add             x3, x3, HEAP, lsl #32
    // 0xef5218: cmp             w3, NULL
    // 0xef521c: b.eq            #0xef533c
    // 0xef5220: LoadField: r3 = r2->field_1f
    //     0xef5220: ldur            w3, [x2, #0x1f]
    // 0xef5224: DecompressPointer r3
    //     0xef5224: add             x3, x3, HEAP, lsl #32
    // 0xef5228: tbz             w3, #4, #0xef52b0
    // 0xef522c: LoadField: r3 = r0->field_7
    //     0xef522c: ldur            w3, [x0, #7]
    // 0xef5230: stur            x3, [fp, #-0x18]
    // 0xef5234: r0 = TextSelection()
    //     0xef5234: bl              #0x861260  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0xef5238: ArrayStore: r0[0] = rZR  ; List_8
    //     0xef5238: stur            xzr, [x0, #0x17]
    // 0xef523c: ldur            x1, [fp, #-0x18]
    // 0xef5240: r2 = LoadInt32Instr(r1)
    //     0xef5240: sbfx            x2, x1, #1, #0x1f
    // 0xef5244: StoreField: r0->field_1f = r2
    //     0xef5244: stur            x2, [x0, #0x1f]
    // 0xef5248: r1 = Instance_TextAffinity
    //     0xef5248: ldr             x1, [PP, #0x4bb0]  ; [pp+0x4bb0] Obj!TextAffinity@12c7361
    // 0xef524c: StoreField: r0->field_27 = r1
    //     0xef524c: stur            w1, [x0, #0x27]
    // 0xef5250: r1 = false
    //     0xef5250: add             x1, NULL, #0x30  ; false
    // 0xef5254: StoreField: r0->field_2b = r1
    //     0xef5254: stur            w1, [x0, #0x2b]
    // 0xef5258: cmp             x2, #0
    // 0xef525c: b.le            #0xef5268
    // 0xef5260: r1 = 0
    //     0xef5260: mov             x1, #0
    // 0xef5264: b               #0xef526c
    // 0xef5268: mov             x1, x2
    // 0xef526c: cmp             x2, #0
    // 0xef5270: b.le            #0xef527c
    // 0xef5274: mov             x3, x2
    // 0xef5278: b               #0xef5280
    // 0xef527c: r3 = 0
    //     0xef527c: mov             x3, #0
    // 0xef5280: ldur            x2, [fp, #-8]
    // 0xef5284: StoreField: r0->field_7 = r1
    //     0xef5284: stur            x1, [x0, #7]
    // 0xef5288: StoreField: r0->field_f = r3
    //     0xef5288: stur            x3, [x0, #0xf]
    // 0xef528c: str             x0, [SP]
    // 0xef5290: ldur            x1, [fp, #-0x20]
    // 0xef5294: r4 = const [0, 0x2, 0x1, 0x1, selection, 0x1, null]
    //     0xef5294: ldr             x4, [PP, #0x5398]  ; [pp+0x5398] List(7) [0, 0x2, 0x1, 0x1, "selection", 0x1, Null]
    // 0xef5298: r0 = copyWith()
    //     0xef5298: bl              #0x86ff64  ; [package:flutter/src/services/text_input.dart] TextEditingValue::copyWith
    // 0xef529c: mov             x2, x0
    // 0xef52a0: ldur            x0, [fp, #-8]
    // 0xef52a4: r1 = true
    //     0xef52a4: add             x1, NULL, #0x20  ; true
    // 0xef52a8: StoreField: r0->field_1f = r1
    //     0xef52a8: stur            w1, [x0, #0x1f]
    // 0xef52ac: b               #0xef52b8
    // 0xef52b0: mov             x0, x2
    // 0xef52b4: ldur            x2, [fp, #-0x20]
    // 0xef52b8: LoadField: r1 = r0->field_13
    //     0xef52b8: ldur            w1, [x0, #0x13]
    // 0xef52bc: DecompressPointer r1
    //     0xef52bc: add             x1, x1, HEAP, lsl #32
    // 0xef52c0: r0 = value=()
    //     0xef52c0: bl              #0xb68ce8  ; [package:flutter/src/foundation/change_notifier.dart] ValueNotifier::value=
    // 0xef52c4: b               #0xef5318
    // 0xef52c8: r1 = ""
    //     0xef52c8: ldr             x1, [PP, #0x900]  ; [pp+0x900] ""
    // 0xef52cc: r3 = Instance_TextRange
    //     0xef52cc: ldr             x3, [PP, #0x53d8]  ; [pp+0x53d8] Obj!TextRange@12a0471
    // 0xef52d0: r2 = Instance_TextSelection
    //     0xef52d0: add             x2, PP, #0x14, lsl #12  ; [pp+0x14b30] Obj!TextSelection@12a0491
    //     0xef52d4: ldr             x2, [x2, #0xb30]
    // 0xef52d8: StoreField: r0->field_1b = r1
    //     0xef52d8: stur            w1, [x0, #0x1b]
    // 0xef52dc: LoadField: r4 = r0->field_13
    //     0xef52dc: ldur            w4, [x0, #0x13]
    // 0xef52e0: DecompressPointer r4
    //     0xef52e0: add             x4, x4, HEAP, lsl #32
    // 0xef52e4: stur            x4, [fp, #-0x10]
    // 0xef52e8: r0 = TextEditingValue()
    //     0xef52e8: bl              #0x86e1d4  ; AllocateTextEditingValueStub -> TextEditingValue (size=0x14)
    // 0xef52ec: mov             x1, x0
    // 0xef52f0: r0 = ""
    //     0xef52f0: ldr             x0, [PP, #0x900]  ; [pp+0x900] ""
    // 0xef52f4: StoreField: r1->field_7 = r0
    //     0xef52f4: stur            w0, [x1, #7]
    // 0xef52f8: r0 = Instance_TextSelection
    //     0xef52f8: add             x0, PP, #0x14, lsl #12  ; [pp+0x14b30] Obj!TextSelection@12a0491
    //     0xef52fc: ldr             x0, [x0, #0xb30]
    // 0xef5300: StoreField: r1->field_b = r0
    //     0xef5300: stur            w0, [x1, #0xb]
    // 0xef5304: r0 = Instance_TextRange
    //     0xef5304: ldr             x0, [PP, #0x53d8]  ; [pp+0x53d8] Obj!TextRange@12a0471
    // 0xef5308: StoreField: r1->field_f = r0
    //     0xef5308: stur            w0, [x1, #0xf]
    // 0xef530c: mov             x2, x1
    // 0xef5310: ldur            x1, [fp, #-0x10]
    // 0xef5314: r0 = value=()
    //     0xef5314: bl              #0xb68ce8  ; [package:flutter/src/foundation/change_notifier.dart] ValueNotifier::value=
    // 0xef5318: r0 = Null
    //     0xef5318: mov             x0, NULL
    // 0xef531c: LeaveFrame
    //     0xef531c: mov             SP, fp
    //     0xef5320: ldp             fp, lr, [SP], #0x10
    // 0xef5324: ret
    //     0xef5324: ret             
    // 0xef5328: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xef5328: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xef532c: b               #0xef5160
    // 0xef5330: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef5330: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef5334: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef5334: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef5338: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef5338: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xef533c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xef533c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0xf6dba4, size: 0x200
    // 0xf6dba4: EnterFrame
    //     0xf6dba4: stp             fp, lr, [SP, #-0x10]!
    //     0xf6dba8: mov             fp, SP
    // 0xf6dbac: AllocStack(0x30)
    //     0xf6dbac: sub             SP, SP, #0x30
    // 0xf6dbb0: SetupParameters(_InputDatePickerFormFieldState this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xf6dbb0: mov             x0, x2
    //     0xf6dbb4: stur            x1, [fp, #-8]
    //     0xf6dbb8: stur            x2, [fp, #-0x10]
    // 0xf6dbbc: CheckStackOverflow
    //     0xf6dbbc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6dbc0: cmp             SP, x16
    //     0xf6dbc4: b.ls            #0xf6dd94
    // 0xf6dbc8: r1 = 1
    //     0xf6dbc8: mov             x1, #1
    // 0xf6dbcc: r0 = AllocateContext()
    //     0xf6dbcc: bl              #0x13de838  ; AllocateContextStub
    // 0xf6dbd0: mov             x4, x0
    // 0xf6dbd4: ldur            x3, [fp, #-8]
    // 0xf6dbd8: stur            x4, [fp, #-0x18]
    // 0xf6dbdc: StoreField: r4->field_f = r3
    //     0xf6dbdc: stur            w3, [x4, #0xf]
    // 0xf6dbe0: ldur            x0, [fp, #-0x10]
    // 0xf6dbe4: r2 = Null
    //     0xf6dbe4: mov             x2, NULL
    // 0xf6dbe8: r1 = Null
    //     0xf6dbe8: mov             x1, NULL
    // 0xf6dbec: r4 = 60
    //     0xf6dbec: mov             x4, #0x3c
    // 0xf6dbf0: branchIfSmi(r0, 0xf6dbfc)
    //     0xf6dbf0: tbz             w0, #0, #0xf6dbfc
    // 0xf6dbf4: r4 = LoadClassIdInstr(r0)
    //     0xf6dbf4: ldur            x4, [x0, #-1]
    //     0xf6dbf8: ubfx            x4, x4, #0xc, #0x14
    // 0xf6dbfc: r17 = 6472
    //     0xf6dbfc: mov             x17, #0x1948
    // 0xf6dc00: cmp             x4, x17
    // 0xf6dc04: b.eq            #0xf6dc1c
    // 0xf6dc08: r8 = InputDatePickerFormField
    //     0xf6dc08: add             x8, PP, #0xab, lsl #12  ; [pp+0xab050] Type: InputDatePickerFormField
    //     0xf6dc0c: ldr             x8, [x8, #0x50]
    // 0xf6dc10: r3 = Null
    //     0xf6dc10: add             x3, PP, #0xab, lsl #12  ; [pp+0xab058] Null
    //     0xf6dc14: ldr             x3, [x3, #0x58]
    // 0xf6dc18: r0 = InputDatePickerFormField()
    //     0xf6dc18: bl              #0xd17f38  ; IsType_InputDatePickerFormField_Stub
    // 0xf6dc1c: ldur            x3, [fp, #-8]
    // 0xf6dc20: LoadField: r2 = r3->field_7
    //     0xf6dc20: ldur            w2, [x3, #7]
    // 0xf6dc24: DecompressPointer r2
    //     0xf6dc24: add             x2, x2, HEAP, lsl #32
    // 0xf6dc28: ldur            x0, [fp, #-0x10]
    // 0xf6dc2c: r1 = Null
    //     0xf6dc2c: mov             x1, NULL
    // 0xf6dc30: cmp             w2, NULL
    // 0xf6dc34: b.eq            #0xf6dc58
    // 0xf6dc38: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf6dc38: ldur            w4, [x2, #0x17]
    // 0xf6dc3c: DecompressPointer r4
    //     0xf6dc3c: add             x4, x4, HEAP, lsl #32
    // 0xf6dc40: r8 = X0 bound StatefulWidget
    //     0xf6dc40: add             x8, PP, #0x12, lsl #12  ; [pp+0x12498] TypeParameter: X0 bound StatefulWidget
    //     0xf6dc44: ldr             x8, [x8, #0x498]
    // 0xf6dc48: LoadField: r9 = r4->field_7
    //     0xf6dc48: ldur            x9, [x4, #7]
    // 0xf6dc4c: r3 = Null
    //     0xf6dc4c: add             x3, PP, #0xab, lsl #12  ; [pp+0xab068] Null
    //     0xf6dc50: ldr             x3, [x3, #0x68]
    // 0xf6dc54: blr             x9
    // 0xf6dc58: ldur            x0, [fp, #-8]
    // 0xf6dc5c: LoadField: r1 = r0->field_b
    //     0xf6dc5c: ldur            w1, [x0, #0xb]
    // 0xf6dc60: DecompressPointer r1
    //     0xf6dc60: add             x1, x1, HEAP, lsl #32
    // 0xf6dc64: cmp             w1, NULL
    // 0xf6dc68: b.eq            #0xf6dd9c
    // 0xf6dc6c: LoadField: r0 = r1->field_b
    //     0xf6dc6c: ldur            w0, [x1, #0xb]
    // 0xf6dc70: DecompressPointer r0
    //     0xf6dc70: add             x0, x0, HEAP, lsl #32
    // 0xf6dc74: ldur            x1, [fp, #-0x10]
    // 0xf6dc78: LoadField: r2 = r1->field_b
    //     0xf6dc78: ldur            w2, [x1, #0xb]
    // 0xf6dc7c: DecompressPointer r2
    //     0xf6dc7c: add             x2, x2, HEAP, lsl #32
    // 0xf6dc80: r1 = LoadClassIdInstr(r0)
    //     0xf6dc80: ldur            x1, [x0, #-1]
    //     0xf6dc84: ubfx            x1, x1, #0xc, #0x14
    // 0xf6dc88: stp             x2, x0, [SP]
    // 0xf6dc8c: mov             x0, x1
    // 0xf6dc90: mov             lr, x0
    // 0xf6dc94: ldr             lr, [x21, lr, lsl #3]
    // 0xf6dc98: blr             lr
    // 0xf6dc9c: tbz             w0, #4, #0xf6dd84
    // 0xf6dca0: r0 = LoadStaticField(0x6a0)
    //     0xf6dca0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xf6dca4: ldr             x0, [x0, #0xd40]
    // 0xf6dca8: cmp             w0, NULL
    // 0xf6dcac: b.eq            #0xf6dda0
    // 0xf6dcb0: LoadField: r3 = r0->field_53
    //     0xf6dcb0: ldur            w3, [x0, #0x53]
    // 0xf6dcb4: DecompressPointer r3
    //     0xf6dcb4: add             x3, x3, HEAP, lsl #32
    // 0xf6dcb8: stur            x3, [fp, #-0x10]
    // 0xf6dcbc: LoadField: r0 = r3->field_7
    //     0xf6dcbc: ldur            w0, [x3, #7]
    // 0xf6dcc0: DecompressPointer r0
    //     0xf6dcc0: add             x0, x0, HEAP, lsl #32
    // 0xf6dcc4: ldur            x2, [fp, #-0x18]
    // 0xf6dcc8: stur            x0, [fp, #-8]
    // 0xf6dccc: r1 = Function '<anonymous closure>':.
    //     0xf6dccc: add             x1, PP, #0xab, lsl #12  ; [pp+0xab078] AnonymousClosure: (0xf6dda4), in [package:flutter/src/material/input_date_picker_form_field.dart] _InputDatePickerFormFieldState::didUpdateWidget (0xf6dba4)
    //     0xf6dcd0: ldr             x1, [x1, #0x78]
    // 0xf6dcd4: r0 = AllocateClosure()
    //     0xf6dcd4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf6dcd8: ldur            x2, [fp, #-8]
    // 0xf6dcdc: mov             x3, x0
    // 0xf6dce0: r1 = Null
    //     0xf6dce0: mov             x1, NULL
    // 0xf6dce4: stur            x3, [fp, #-8]
    // 0xf6dce8: cmp             w2, NULL
    // 0xf6dcec: b.eq            #0xf6dd0c
    // 0xf6dcf0: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf6dcf0: ldur            w4, [x2, #0x17]
    // 0xf6dcf4: DecompressPointer r4
    //     0xf6dcf4: add             x4, x4, HEAP, lsl #32
    // 0xf6dcf8: r8 = X0
    //     0xf6dcf8: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xf6dcfc: LoadField: r9 = r4->field_7
    //     0xf6dcfc: ldur            x9, [x4, #7]
    // 0xf6dd00: r3 = Null
    //     0xf6dd00: add             x3, PP, #0xab, lsl #12  ; [pp+0xab080] Null
    //     0xf6dd04: ldr             x3, [x3, #0x80]
    // 0xf6dd08: blr             x9
    // 0xf6dd0c: ldur            x0, [fp, #-0x10]
    // 0xf6dd10: LoadField: r1 = r0->field_b
    //     0xf6dd10: ldur            w1, [x0, #0xb]
    // 0xf6dd14: LoadField: r2 = r0->field_f
    //     0xf6dd14: ldur            w2, [x0, #0xf]
    // 0xf6dd18: DecompressPointer r2
    //     0xf6dd18: add             x2, x2, HEAP, lsl #32
    // 0xf6dd1c: LoadField: r3 = r2->field_b
    //     0xf6dd1c: ldur            w3, [x2, #0xb]
    // 0xf6dd20: r2 = LoadInt32Instr(r1)
    //     0xf6dd20: sbfx            x2, x1, #1, #0x1f
    // 0xf6dd24: stur            x2, [fp, #-0x20]
    // 0xf6dd28: r1 = LoadInt32Instr(r3)
    //     0xf6dd28: sbfx            x1, x3, #1, #0x1f
    // 0xf6dd2c: cmp             x2, x1
    // 0xf6dd30: b.ne            #0xf6dd3c
    // 0xf6dd34: mov             x1, x0
    // 0xf6dd38: r0 = _growToNextCapacity()
    //     0xf6dd38: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xf6dd3c: ldur            x2, [fp, #-0x10]
    // 0xf6dd40: ldur            x3, [fp, #-0x20]
    // 0xf6dd44: add             x4, x3, #1
    // 0xf6dd48: lsl             x5, x4, #1
    // 0xf6dd4c: StoreField: r2->field_b = r5
    //     0xf6dd4c: stur            w5, [x2, #0xb]
    // 0xf6dd50: LoadField: r1 = r2->field_f
    //     0xf6dd50: ldur            w1, [x2, #0xf]
    // 0xf6dd54: DecompressPointer r1
    //     0xf6dd54: add             x1, x1, HEAP, lsl #32
    // 0xf6dd58: ldur            x0, [fp, #-8]
    // 0xf6dd5c: ArrayStore: r1[r3] = r0  ; List_4
    //     0xf6dd5c: add             x25, x1, x3, lsl #2
    //     0xf6dd60: add             x25, x25, #0xf
    //     0xf6dd64: str             w0, [x25]
    //     0xf6dd68: tbz             w0, #0, #0xf6dd84
    //     0xf6dd6c: ldurb           w16, [x1, #-1]
    //     0xf6dd70: ldurb           w17, [x0, #-1]
    //     0xf6dd74: and             x16, x17, x16, lsr #2
    //     0xf6dd78: tst             x16, HEAP, lsr #32
    //     0xf6dd7c: b.eq            #0xf6dd84
    //     0xf6dd80: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xf6dd84: r0 = Null
    //     0xf6dd84: mov             x0, NULL
    // 0xf6dd88: LeaveFrame
    //     0xf6dd88: mov             SP, fp
    //     0xf6dd8c: ldp             fp, lr, [SP], #0x10
    // 0xf6dd90: ret
    //     0xf6dd90: ret             
    // 0xf6dd94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6dd94: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6dd98: b               #0xf6dbc8
    // 0xf6dd9c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6dd9c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xf6dda0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6dda0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, Duration) {
    // ** addr: 0xf6dda4, size: 0x60
    // 0xf6dda4: EnterFrame
    //     0xf6dda4: stp             fp, lr, [SP, #-0x10]!
    //     0xf6dda8: mov             fp, SP
    // 0xf6ddac: AllocStack(0x8)
    //     0xf6ddac: sub             SP, SP, #8
    // 0xf6ddb0: SetupParameters([dynamic _ /* r0 */])
    //     0xf6ddb0: ldr             x0, [fp, #0x18]
    //     0xf6ddb4: ldur            w2, [x0, #0x17]
    //     0xf6ddb8: add             x2, x2, HEAP, lsl #32
    // 0xf6ddbc: CheckStackOverflow
    //     0xf6ddbc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6ddc0: cmp             SP, x16
    //     0xf6ddc4: b.ls            #0xf6ddfc
    // 0xf6ddc8: LoadField: r0 = r2->field_f
    //     0xf6ddc8: ldur            w0, [x2, #0xf]
    // 0xf6ddcc: DecompressPointer r0
    //     0xf6ddcc: add             x0, x0, HEAP, lsl #32
    // 0xf6ddd0: stur            x0, [fp, #-8]
    // 0xf6ddd4: r1 = Function '<anonymous closure>':.
    //     0xf6ddd4: add             x1, PP, #0xab, lsl #12  ; [pp+0xab090] AnonymousClosure: (0xf6de04), in [package:flutter/src/material/input_date_picker_form_field.dart] _InputDatePickerFormFieldState::didUpdateWidget (0xf6dba4)
    //     0xf6ddd8: ldr             x1, [x1, #0x90]
    // 0xf6dddc: r0 = AllocateClosure()
    //     0xf6dddc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xf6dde0: ldur            x1, [fp, #-8]
    // 0xf6dde4: mov             x2, x0
    // 0xf6dde8: r0 = setState()
    //     0xf6dde8: bl              #0x82938c  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xf6ddec: r0 = Null
    //     0xf6ddec: mov             x0, NULL
    // 0xf6ddf0: LeaveFrame
    //     0xf6ddf0: mov             SP, fp
    //     0xf6ddf4: ldp             fp, lr, [SP], #0x10
    // 0xf6ddf8: ret
    //     0xf6ddf8: ret             
    // 0xf6ddfc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6ddfc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6de00: b               #0xf6ddc8
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xf6de04, size: 0x84
    // 0xf6de04: EnterFrame
    //     0xf6de04: stp             fp, lr, [SP, #-0x10]!
    //     0xf6de08: mov             fp, SP
    // 0xf6de0c: ldr             x0, [fp, #0x10]
    // 0xf6de10: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xf6de10: ldur            w1, [x0, #0x17]
    // 0xf6de14: DecompressPointer r1
    //     0xf6de14: add             x1, x1, HEAP, lsl #32
    // 0xf6de18: CheckStackOverflow
    //     0xf6de18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf6de1c: cmp             SP, x16
    //     0xf6de20: b.ls            #0xf6de7c
    // 0xf6de24: LoadField: r2 = r1->field_f
    //     0xf6de24: ldur            w2, [x1, #0xf]
    // 0xf6de28: DecompressPointer r2
    //     0xf6de28: add             x2, x2, HEAP, lsl #32
    // 0xf6de2c: LoadField: r0 = r2->field_b
    //     0xf6de2c: ldur            w0, [x2, #0xb]
    // 0xf6de30: DecompressPointer r0
    //     0xf6de30: add             x0, x0, HEAP, lsl #32
    // 0xf6de34: cmp             w0, NULL
    // 0xf6de38: b.eq            #0xf6de84
    // 0xf6de3c: LoadField: r1 = r0->field_b
    //     0xf6de3c: ldur            w1, [x0, #0xb]
    // 0xf6de40: DecompressPointer r1
    //     0xf6de40: add             x1, x1, HEAP, lsl #32
    // 0xf6de44: mov             x0, x1
    // 0xf6de48: ArrayStore: r2[0] = r0  ; List_4
    //     0xf6de48: stur            w0, [x2, #0x17]
    //     0xf6de4c: ldurb           w16, [x2, #-1]
    //     0xf6de50: ldurb           w17, [x0, #-1]
    //     0xf6de54: and             x16, x17, x16, lsr #2
    //     0xf6de58: tst             x16, HEAP, lsr #32
    //     0xf6de5c: b.eq            #0xf6de64
    //     0xf6de60: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xf6de64: mov             x1, x2
    // 0xf6de68: r0 = _updateValueForSelectedDate()
    //     0xf6de68: bl              #0xef5140  ; [package:flutter/src/material/input_date_picker_form_field.dart] _InputDatePickerFormFieldState::_updateValueForSelectedDate
    // 0xf6de6c: r0 = Null
    //     0xf6de6c: mov             x0, NULL
    // 0xf6de70: LeaveFrame
    //     0xf6de70: mov             SP, fp
    //     0xf6de74: ldp             fp, lr, [SP], #0x10
    // 0xf6de78: ret
    //     0xf6de78: ret             
    // 0xf6de7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf6de7c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf6de80: b               #0xf6de24
    // 0xf6de84: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf6de84: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0xf90f04, size: 0x50
    // 0xf90f04: LoadField: r2 = r1->field_b
    //     0xf90f04: ldur            w2, [x1, #0xb]
    // 0xf90f08: DecompressPointer r2
    //     0xf90f08: add             x2, x2, HEAP, lsl #32
    // 0xf90f0c: cmp             w2, NULL
    // 0xf90f10: b.eq            #0xf90f48
    // 0xf90f14: LoadField: r0 = r2->field_b
    //     0xf90f14: ldur            w0, [x2, #0xb]
    // 0xf90f18: DecompressPointer r0
    //     0xf90f18: add             x0, x0, HEAP, lsl #32
    // 0xf90f1c: ArrayStore: r1[0] = r0  ; List_4
    //     0xf90f1c: stur            w0, [x1, #0x17]
    //     0xf90f20: ldurb           w16, [x1, #-1]
    //     0xf90f24: ldurb           w17, [x0, #-1]
    //     0xf90f28: and             x16, x17, x16, lsr #2
    //     0xf90f2c: tst             x16, HEAP, lsr #32
    //     0xf90f30: b.eq            #0xf90f40
    //     0xf90f34: str             lr, [SP, #-8]!
    //     0xf90f38: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    //     0xf90f3c: ldr             lr, [SP], #8
    // 0xf90f40: r0 = Null
    //     0xf90f40: mov             x0, NULL
    // 0xf90f44: ret
    //     0xf90f44: ret             
    // 0xf90f48: EnterFrame
    //     0xf90f48: stp             fp, lr, [SP, #-0x10]!
    //     0xf90f4c: mov             fp, SP
    // 0xf90f50: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xf90f50: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 6472, size: 0x48, field offset: 0xc
class InputDatePickerFormField extends StatefulWidget {

  _ InputDatePickerFormField(/* No info */) {
    // ** addr: 0xd188e8, size: 0x138
    // 0xd188e8: EnterFrame
    //     0xd188e8: stp             fp, lr, [SP, #-0x10]!
    //     0xd188ec: mov             fp, SP
    // 0xd188f0: AllocStack(0x18)
    //     0xd188f0: sub             SP, SP, #0x18
    // 0xd188f4: r9 = true
    //     0xd188f4: add             x9, NULL, #0x20  ; true
    // 0xd188f8: r8 = false
    //     0xd188f8: add             x8, NULL, #0x30  ; false
    // 0xd188fc: r4 = Instance_GregorianCalendarDelegate
    //     0xd188fc: add             x4, PP, #0x28, lsl #12  ; [pp+0x28538] Obj!GregorianCalendarDelegate@129edd1
    //     0xd18900: ldr             x4, [x4, #0x538]
    // 0xd18904: stur            x1, [fp, #-8]
    // 0xd18908: mov             x16, x6
    // 0xd1890c: mov             x6, x1
    // 0xd18910: mov             x1, x16
    // 0xd18914: stur            x2, [fp, #-0x10]
    // 0xd18918: mov             x16, x5
    // 0xd1891c: mov             x5, x2
    // 0xd18920: mov             x2, x16
    // 0xd18924: mov             x0, x7
    // 0xd18928: stur            x2, [fp, #-0x18]
    // 0xd1892c: CheckStackOverflow
    //     0xd1892c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd18930: cmp             SP, x16
    //     0xd18934: b.ls            #0xd18a18
    // 0xd18938: ArrayStore: r6[0] = r0  ; List_4
    //     0xd18938: stur            w0, [x6, #0x17]
    //     0xd1893c: ldurb           w16, [x6, #-1]
    //     0xd18940: ldurb           w17, [x0, #-1]
    //     0xd18944: and             x16, x17, x16, lsr #2
    //     0xd18948: tst             x16, HEAP, lsr #32
    //     0xd1894c: b.eq            #0xd18954
    //     0xd18950: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0xd18954: mov             x0, x1
    // 0xd18958: StoreField: r6->field_1b = r0
    //     0xd18958: stur            w0, [x6, #0x1b]
    //     0xd1895c: ldurb           w16, [x6, #-1]
    //     0xd18960: ldurb           w17, [x0, #-1]
    //     0xd18964: and             x16, x17, x16, lsr #2
    //     0xd18968: tst             x16, HEAP, lsr #32
    //     0xd1896c: b.eq            #0xd18974
    //     0xd18970: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0xd18974: StoreField: r6->field_37 = r9
    //     0xd18974: stur            w9, [x6, #0x37]
    // 0xd18978: StoreField: r6->field_3b = r8
    //     0xd18978: stur            w8, [x6, #0x3b]
    // 0xd1897c: StoreField: r6->field_43 = r4
    //     0xd1897c: stur            w4, [x6, #0x43]
    // 0xd18980: cmp             w3, NULL
    // 0xd18984: b.eq            #0xd18994
    // 0xd18988: mov             x1, x3
    // 0xd1898c: r0 = dateOnly()
    //     0xd1898c: bl              #0xd18a20  ; [package:flutter/src/material/date.dart] DateUtils::dateOnly
    // 0xd18990: b               #0xd18998
    // 0xd18994: r0 = Null
    //     0xd18994: mov             x0, NULL
    // 0xd18998: ldur            x2, [fp, #-8]
    // 0xd1899c: StoreField: r2->field_b = r0
    //     0xd1899c: stur            w0, [x2, #0xb]
    //     0xd189a0: ldurb           w16, [x2, #-1]
    //     0xd189a4: ldurb           w17, [x0, #-1]
    //     0xd189a8: and             x16, x17, x16, lsr #2
    //     0xd189ac: tst             x16, HEAP, lsr #32
    //     0xd189b0: b.eq            #0xd189b8
    //     0xd189b4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd189b8: ldur            x1, [fp, #-0x10]
    // 0xd189bc: r0 = dateOnly()
    //     0xd189bc: bl              #0xd18a20  ; [package:flutter/src/material/date.dart] DateUtils::dateOnly
    // 0xd189c0: ldur            x2, [fp, #-8]
    // 0xd189c4: StoreField: r2->field_f = r0
    //     0xd189c4: stur            w0, [x2, #0xf]
    //     0xd189c8: ldurb           w16, [x2, #-1]
    //     0xd189cc: ldurb           w17, [x0, #-1]
    //     0xd189d0: and             x16, x17, x16, lsr #2
    //     0xd189d4: tst             x16, HEAP, lsr #32
    //     0xd189d8: b.eq            #0xd189e0
    //     0xd189dc: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd189e0: ldur            x1, [fp, #-0x18]
    // 0xd189e4: r0 = dateOnly()
    //     0xd189e4: bl              #0xd18a20  ; [package:flutter/src/material/date.dart] DateUtils::dateOnly
    // 0xd189e8: ldur            x1, [fp, #-8]
    // 0xd189ec: StoreField: r1->field_13 = r0
    //     0xd189ec: stur            w0, [x1, #0x13]
    //     0xd189f0: ldurb           w16, [x1, #-1]
    //     0xd189f4: ldurb           w17, [x0, #-1]
    //     0xd189f8: and             x16, x17, x16, lsr #2
    //     0xd189fc: tst             x16, HEAP, lsr #32
    //     0xd18a00: b.eq            #0xd18a08
    //     0xd18a04: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd18a08: r0 = Null
    //     0xd18a08: mov             x0, NULL
    // 0xd18a0c: LeaveFrame
    //     0xd18a0c: mov             SP, fp
    //     0xd18a10: ldp             fp, lr, [SP], #0x10
    // 0xd18a14: ret
    //     0xd18a14: ret             
    // 0xd18a18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd18a18: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd18a1c: b               #0xd18938
  }
  _ createState(/* No info */) {
    // ** addr: 0xfa1b98, size: 0x88
    // 0xfa1b98: EnterFrame
    //     0xfa1b98: stp             fp, lr, [SP, #-0x10]!
    //     0xfa1b9c: mov             fp, SP
    // 0xfa1ba0: AllocStack(0x10)
    //     0xfa1ba0: sub             SP, SP, #0x10
    // 0xfa1ba4: CheckStackOverflow
    //     0xfa1ba4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa1ba8: cmp             SP, x16
    //     0xfa1bac: b.ls            #0xfa1c18
    // 0xfa1bb0: r1 = <InputDatePickerFormField>
    //     0xfa1bb0: add             x1, PP, #0xa0, lsl #12  ; [pp+0xa0ee0] TypeArguments: <InputDatePickerFormField>
    //     0xfa1bb4: ldr             x1, [x1, #0xee0]
    // 0xfa1bb8: r0 = _InputDatePickerFormFieldState()
    //     0xfa1bb8: bl              #0xfa1c20  ; Allocate_InputDatePickerFormFieldStateStub -> _InputDatePickerFormFieldState (size=0x24)
    // 0xfa1bbc: mov             x2, x0
    // 0xfa1bc0: r0 = false
    //     0xfa1bc0: add             x0, NULL, #0x30  ; false
    // 0xfa1bc4: stur            x2, [fp, #-8]
    // 0xfa1bc8: StoreField: r2->field_1f = r0
    //     0xfa1bc8: stur            w0, [x2, #0x1f]
    // 0xfa1bcc: r1 = <TextEditingValue>
    //     0xfa1bcc: ldr             x1, [PP, #0x53b8]  ; [pp+0x53b8] TypeArguments: <TextEditingValue>
    // 0xfa1bd0: r0 = TextEditingController()
    //     0xfa1bd0: bl              #0xd7f070  ; AllocateTextEditingControllerStub -> TextEditingController (size=0x2c)
    // 0xfa1bd4: mov             x1, x0
    // 0xfa1bd8: stur            x0, [fp, #-0x10]
    // 0xfa1bdc: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xfa1bdc: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xfa1be0: r0 = TextEditingController()
    //     0xfa1be0: bl              #0xd7ef60  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::TextEditingController
    // 0xfa1be4: ldur            x0, [fp, #-0x10]
    // 0xfa1be8: ldur            x1, [fp, #-8]
    // 0xfa1bec: StoreField: r1->field_13 = r0
    //     0xfa1bec: stur            w0, [x1, #0x13]
    //     0xfa1bf0: ldurb           w16, [x1, #-1]
    //     0xfa1bf4: ldurb           w17, [x0, #-1]
    //     0xfa1bf8: and             x16, x17, x16, lsr #2
    //     0xfa1bfc: tst             x16, HEAP, lsr #32
    //     0xfa1c00: b.eq            #0xfa1c08
    //     0xfa1c04: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xfa1c08: mov             x0, x1
    // 0xfa1c0c: LeaveFrame
    //     0xfa1c0c: mov             SP, fp
    //     0xfa1c10: ldp             fp, lr, [SP], #0x10
    // 0xfa1c14: ret
    //     0xfa1c14: ret             
    // 0xfa1c18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa1c18: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa1c1c: b               #0xfa1bb0
  }
}
